/**
 * Browser half smoke test — no browser, no React installed, yet still runs the Panel's render body for real.
 *
 * Why this layer is needed: `node --check` only proves syntax passes, and `selftest`/`smoke-host`
 * don't execute a single byte of the browser half's 700+ lines. What users see is exactly this half —
 * if it crashes on start, the panel is blank. Here, stub React (a mini hooks runtime) + the **real**
 * /summary data produced by the host half's apply() are used to render through three states —
 * loading → data → guide seen — asserting the rendering tree contains everything it should.
 *
 * Safety: DSH_HOME points at a temporary directory, never touching the real config; no files written.
 *
 * Run: node scripts/smoke-client.mjs
 */
import { EventEmitter } from 'node:events'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const API_PREFIX = '/api/agent-dispatch'
const home = fs.mkdtempSync(path.join(os.tmpdir(), 'agent-dispatch-client-smoke-'))
process.env.DSH_HOME = home

const results = []
function check(name, ok, detail = '') {
  results.push({ name, ok: ok === true })
  console.log(`${ok === true ? 'ok  ' : 'FAIL'} - ${name}${ok === true || detail === '' ? '' : ` — ${detail}`}`)
}

// ── Fake host half (same shape as smoke-host.mjs): gets the **real** /summary data ───
const routes = []
const disposers = []
const webServer = { register(route) { routes.push(route); return () => {} } }
const systemPrompt = { section() { return () => {} } }
const llm = {
  listProviders() { return [{ id: 'our-free-model', name: 'Our free model' }, { id: 'deepseek', name: 'DeepSeek' }] },
  async listModels(provider) {
    if (provider === 'our-free-model') {
      return [
        { provider, id: 'nemotron-3-ultra-free', name: 'Nemotron 3 Ultra' },
        { provider, id: 'ling-3.0-flash-fin-free', name: 'Ling 3.0 Flash Fin' },
      ]
    }
    return [{ provider, id: 'deepseek-v4-flash', name: 'DeepSeek V4 Flash' }]
  },
}
const withEffect = scoped => ({ ...scoped, effect(fn) { const d = fn(); if (typeof d === 'function') disposers.push(d); return d } })
const hostCtx = {
  logger: { info() {}, warn() {}, error() {}, debug() {} },
  effect: withEffect({}).effect,
  inject(deps, scoped) {
    const bag = {}
    if (deps.includes('webServer')) bag.webServer = webServer
    if (deps.includes('systemPrompt')) bag.systemPrompt = systemPrompt
    if (deps.includes('llm')) bag.llm = llm
    scoped(withEffect(bag))
  },
  get(name) { return name === 'webServer' ? webServer : name === 'systemPrompt' ? systemPrompt : name === 'llm' ? llm : undefined },
}

function call(method, route, options = {}) {
  const handler = routes[0]?.handler
  if (typeof handler !== 'function') throw new Error('宿主半身没有注册路由处理器')
  return new Promise((resolve, reject) => {
    const req = new EventEmitter()
    req.method = method
    req.url = `${API_PREFIX}${route}`
    req.headers = { host: '127.0.0.1:3080' }
    req.destroy = () => {}
    const res = {
      status: 0, headers: undefined, body: '',
      writeHead(status, headers) { this.status = status; this.headers = headers },
      end(chunk) { this.body = String(chunk ?? ''); resolve({ status: this.status, headers: this.headers, body: this.body }) },
    }
    Promise.resolve(handler(req, res)).catch(reject)
    process.nextTick(() => { if (options.body !== undefined) req.emit('data', Buffer.from(JSON.stringify(options.body), 'utf8')); req.emit('end') })
  })
}

const host = await import(new URL('../index.js', import.meta.url))
host.apply(hostCtx, {})
const summary = JSON.parse((await call('GET', '/summary')).body)
check('前置：宿主半身产出真实 /summary（v3 配置 + 名册）', summary?.config?.version === 3 && Array.isArray(summary?.roster?.rows) && typeof summary?.preview === 'string', `rows=${summary?.roster?.rows?.length}`)

// ── Stub DOM ───────────────────────────────────────────────────────────────────
const styles = []
globalThis.document = {
  createElement(tag) {
    return {
      tag, attrs: {}, textContent: '', removed: false,
      setAttribute(key, value) { this.attrs[key] = value },
      remove() { this.removed = true },
    }
  },
  head: { appendChild(element) { styles.push(element) } },
}

// ── Stub React: mini hooks runtime (enough for Panel: state, effects, memo, refs) ───
let hooks = []
let hookIndex = 0
let pendingEffects = []
const flatten = (into, value) => {
  if (Array.isArray(value)) { for (const item of value) flatten(into, item); return into }
  if (value === null || value === undefined || value === false || value === true) return into
  into.push(value)
  return into
}
const React = {
  Fragment: Symbol('Fragment'),
  createElement(type, props, ...children) {
    const kids = []
    for (const child of children) flatten(kids, child)
    return { type, props: props ?? {}, children: kids }
  },
  useState(initial) {
    const index = hookIndex++
    if (!(index in hooks)) hooks[index] = typeof initial === 'function' ? initial() : initial
    return [hooks[index], value => { hooks[index] = typeof value === 'function' ? value(hooks[index]) : value }]
  },
  useEffect(fn) { pendingEffects.push(fn) },
  useMemo(fn) { hookIndex++; return typeof fn === 'function' ? fn() : fn },
  useCallback(fn) { hookIndex++; return fn },
  useRef(initial) { const index = hookIndex++; if (!(index in hooks)) hooks[index] = { current: initial }; return hooks[index] },
}

/** Actually "instantiate" functional components — the stub runtime also needs to recursively expand components like React does. */
function instantiate(node) {
  if (Array.isArray(node)) return node.map(instantiate)
  if (!node || typeof node !== 'object') return node
  const { type, props, children } = node
  if (typeof type === 'function') return instantiate(type({ ...props, children }))
  return { ...node, children: (children ?? []).map(instantiate) }
}

/** Render once: reset cursor → instantiate component tree → run the effects registered for this pass. */
function renderOnce(render, props) {
  hookIndex = 0
  pendingEffects = []
  const tree = instantiate(render(props))
  const cleanup = []
  for (const fn of pendingEffects) {
    const disposer = fn()
    if (typeof disposer === 'function') cleanup.push(disposer)
  }
  return { tree, cleanup }
}
const tick = () => new Promise(resolve => setTimeout(resolve, 25))

function collectText(node, out = []) {
  if (typeof node === 'string' || typeof node === 'number') { out.push(String(node)); return out }
  if (Array.isArray(node)) { for (const child of node) collectText(child, out); return out }
  if (!node || typeof node !== 'object') return out
  for (const value of Object.values(node.props ?? {})) {
    if (typeof value === 'string' || typeof value === 'number') out.push(String(value))
  }
  for (const child of node.children ?? []) collectText(child, out)
  return out
}
function collectClasses(node, out = []) {
  if (Array.isArray(node)) { for (const child of node) collectClasses(child, out); return out }
  if (!node || typeof node !== 'object') return out
  const className = node.props?.className
  if (typeof className === 'string') out.push(...className.split(/\s+/).filter(Boolean))
  for (const child of node.children ?? []) collectClasses(child, out)
  return out
}
function collectTypes(node, out = []) {
  if (Array.isArray(node)) { for (const child of node) collectTypes(child, out); return out }
  if (!node || typeof node !== 'object') return out
  out.push(node.type)
  for (const child of node.children ?? []) collectTypes(child, out)
  return out
}
function findAll(node, predicate, out = []) {
  if (Array.isArray(node)) { for (const child of node) findAll(child, predicate, out); return out }
  if (!node || typeof node !== 'object') return out
  if (predicate(node)) out.push(node)
  for (const child of node.children ?? []) findAll(child, predicate, out)
  return out
}

// ── Load the browser half ───────────────────────────────────────────────────
let spec
globalThis.window = { __ModuleLoader__: { load(candidate) { spec = candidate } } }
const fetched = []
globalThis.fetch = async (url, options = {}) => {
  fetched.push({ url, method: options.method ?? 'GET' })
  if (url === `${API_PREFIX}/summary`) return { ok: true, status: 200, async text() { return JSON.stringify(summary) } }
  return { ok: false, status: 404, async text() { return JSON.stringify({ error: 'not found' }) } }
}

await import(new URL('../client.js', import.meta.url))

check('client.js 通过 ModuleLoader 注册，id 与包名一致', spec?.id === 'dsh-agent-dispatch' && typeof spec?.factory === 'function', `id=${spec?.id}`)

const dicts = {}
const registered = []
const NS = 'settings.agentDispatch'
const clientCtx = {
  effect(fn) { const d = fn(); if (typeof d === 'function') disposers.push(d); return d },
  locale: {
    bind: () => key => (dicts[NS]?.zh ?? {})[key] ?? key,
    register: (ns, dictionary) => { dicts[ns] = dictionary; return () => {} },
  },
  slots: {
    inject: (name, contribute) => { contribute(); return () => {} },
    register: (definition, render) => { registered.push({ definition, render }); return () => {} },
  },
}

const client = spec.factory(name => {
  if (name === 'react') return React
  throw new Error(`浏览器半身 require 了未预期的模块：${name}`)
})

check('client.js 导出 name / inject / apply', client.name === 'agent-dispatch' && Array.isArray(client.inject) && client.inject.join(',') === 'slots,locale' && typeof client.apply === 'function', `name=${client.name} inject=${client.inject}`)

client.apply(clientCtx)

const section = registered.find(item => item.definition.name === 'settings.section')
const onboarding = registered.find(item => item.definition.name === 'settings.onboarding')
check('贡献 settings.section（id agent-dispatch，order 40）', section?.definition?.id === 'agent-dispatch' && section?.definition?.order === 40 && typeof section?.render === 'function')
check('贡献 settings.onboarding（order -40），缺席也不致命', onboarding?.definition?.id === 'agent-dispatch' && onboarding?.definition?.order === -40 && typeof onboarding?.render === 'function')

check('注入样式表到 document.head，带 data-plugin 标记', styles.length === 1 && styles[0].attrs['data-plugin'] === 'dsh-agent-dispatch' && styles[0].textContent.length > 500, `styles=${styles.length} len=${styles[0]?.textContent?.length}`)
check('样式 disposer 可安全执行（热卸载不留残渣）', typeof section?.definition && disposers.length >= 1 && (() => { try { for (const d of disposers) d(); return true } catch { return false } })())
check('样式 disposer 真的会移除元素', styles[0].removed === true)

const dictionaries = dicts[NS]
const zhKeys = Object.keys(dictionaries?.zh ?? {})
const enKeys = Object.keys(dictionaries?.en ?? {})
check('注册 zh/en 字典且键完全相同', zhKeys.length > 60 && zhKeys.length === enKeys.length && zhKeys.every(key => key in (dictionaries?.en ?? {})), `zh=${zhKeys.length} en=${enKeys.length}`)

// ── Render three passes ─────────────────────────────────────────────────────────
const props = { t: key => (dictionaries?.zh ?? {})[key] ?? key }

let first
try { first = renderOnce(section.render, props) } catch (error) { check('第一遍渲染（加载态）不抛异常', false, String(error?.stack ?? error)) }
if (first) check('第一遍渲染（加载态）不抛异常', true)
await tick()

let second
try { second = renderOnce(section.render, props) } catch (error) { check('第二遍渲染（有数据态）不抛异常', false, String(error?.stack ?? error)) }
if (second) check('第二遍渲染（有数据态）不抛异常', true)

const text = collectText(second?.tree).join(' ')
const classes = collectClasses(second?.tree)
const types = collectTypes(second?.tree)

check('数据来自插件自己的同源路由 /api/agent-dispatch/summary', fetched.some(item => item.url === `${API_PREFIX}/summary`), JSON.stringify(fetched))
check('根节点是 ad_root', second?.tree?.props?.className === 'ad_root', String(second?.tree?.props?.className))
check('没有 undefined 元素类型（h(undefined) 一崩就是空白面板）', types.every(type => type !== undefined && type !== null), JSON.stringify(types.filter(type => type === undefined).length))
check('渲染树里出现名册里的 provider:model 键', /our-free-model:[a-z0-9.-]+free/.test(text), text.slice(0, 120))
check('渲染树里出现真实注入策略的原文（面板预览 = 真发给 agent 的那段）', text.includes(summary.preview.slice(0, 20)), `preview[:20]=${summary.preview.slice(0, 20)}`)
check('渲染树里出现面板标题与四个通道区块', text.includes(dictionaries.zh.title) && classes.includes('ad_card'), `cards=${classes.filter(c => c === 'ad_card').length}`)
check('首次引导卡在 onboardingSeen=false 时出现', classes.includes('ad_guide'))
check('没有渲染出未定义文案（t() 返回 key 本身说明漏键）', !text.includes('undefined') && !text.includes('NaN'), text.includes('undefined') ? '文本里出现 undefined' : '')

// ── v3 controls: pre-flight estimate + stall failover must render, disabled states included ──
check('面板渲染出「动工前预估」与「卡住改派」两个新区块', text.includes(dictionaries.zh.plan) && text.includes(dictionaries.zh.planHint) && text.includes(dictionaries.zh.failTitle) && text.includes(dictionaries.zh.failHint))
const numberInputs = findAll(second.tree, node => node.type === 'input' && node.props?.type === 'number')
check('数值输入覆盖建队门槛 / 等待步数 / 改派次数（加原有的并发与步数）', numberInputs.length >= 4, `numberInputs=${numberInputs.length}`)
const selects = findAll(second.tree, node => node.type === 'select')
check('兜底对象渲染成 select，默认项是「主 agent 自己接手」', selects.length === 1 && String(selects[0].props?.value) === 'main' && String(selects[0].children?.[0]?.children?.[0] ?? '') === dictionaries.zh.failFallbackMain, JSON.stringify(selects[0]?.children?.length))
check('teams 未勾选时建队开关禁用并给出锁定说明', text.includes(dictionaries.zh.planAutoTeamLocked) && findAll(second.tree, node => node.props?.disabled === true).length >= 2)

// ── v4: initiative modes — four buttons, exactly one pressed, the hint matching the mode ──
const MODE_ORDER = ['off', 'ask', 'proactive', 'auto']
const segRow = findAll(second.tree, node => node.props?.className === 'ad_seg')
const modeButtons = segRow[0]?.children ?? []
const modeLabels = modeButtons.map(node => (Array.isArray(node.children) ? node.children.join('') : String(node.children ?? '')))
check('派活模式渲染成四态选择器（关闭 / 先问我 / 主动派 / 直接派）', modeButtons.length === 4 && modeLabels.every((label, index) => label === dictionaries.zh[`mode.${MODE_ORDER[index]}`]), modeLabels.join(' / '))
check('四态选择器只高亮当前模式，并按模式给出节奏说明', modeButtons.filter(node => node.props?.['aria-pressed'] === 'true').length === 1 && modeButtons[MODE_ORDER.indexOf(summary.config.mode)]?.props?.['aria-pressed'] === 'true' && text.includes(dictionaries.zh[`modeHint.${summary.config.mode}`]), `mode=${summary.config.mode} pressed=${modeButtons.map(node => node.props?.['aria-pressed']).join(',')}`)
check('面板的模式标签与注入文本里的模式标签逐字一致（预览 = 真发出去的那段）', summary.preview.includes(`模式：${dictionaries.zh[`mode.${summary.config.mode}`]}`) && summary.preview.includes('默认姿态：主动分工'))

// Third pass: after the guide has been seen, the guide card should disappear
summary.health.onboardingSeen = true
renderOnce(section.render, props)
await tick()
const third = renderOnce(section.render, props)
check('onboardingSeen=true 后引导卡消失（只看一次）', !collectClasses(third.tree).includes('ad_guide'))

// ── v3 unlocked path: arm Agent Teams and tune the estimate / failover, then re-render ──
// The panel adopts whatever /summary reports (the effect re-runs on every renderOnce here), so the
// snapshot is edited in place. `preview` is left exactly as the host rendered it — the panel only
// prints that string, it never recomputes it.
summary.config.channels = { ...summary.config.channels, teams: true }
summary.config.plan = { enabled: true, minBlocks: 4, autoTeam: true }
summary.config.failover = { enabled: true, waitSteps: 12, maxRetry: 2, fallback: 'our-free-model:nemotron-3-ultra-free' }
renderOnce(section.render, props)
await tick()
const fourth = renderOnce(section.render, props)
const tunedText = collectText(fourth.tree).join(' ')
const tunedSelects = findAll(fourth.tree, node => node.type === 'select')
check('勾上 Agent Teams 后建队开关解锁（锁定说明换成解锁说明）', !tunedText.includes(dictionaries.zh.planAutoTeamLocked) && tunedText.includes(dictionaries.zh.planAutoTeamHint))
check('面板回显调过的建队门槛 / 等待步数 / 改派次数', (() => {
  const values = findAll(fourth.tree, node => node.type === 'input' && node.props?.type === 'number').map(node => Number(node.props.value))
  return values.includes(4) && values.includes(12) && values.includes(2)
})(), JSON.stringify(findAll(fourth.tree, node => node.type === 'input' && node.props?.type === 'number').map(node => node.props.value)))
check('兜底下拉的选项来自名册里已勾选的帮手键，并回显当前值', tunedSelects.length === 1 && String(tunedSelects[0].props.value) === 'our-free-model:nemotron-3-ultra-free' && tunedSelects[0].children.some(option => String(option.props?.value ?? '') === 'our-free-model:nemotron-3-ultra-free'), JSON.stringify(tunedSelects[0]?.children?.map(option => option.props?.value)))

// ── Onboarding entry (settings.onboarding): the host mounts it in the narrow sidebar column ──
// This is the regression this suite exists to catch: that slot must carry a card of its own, never the panel.
summary.health.onboardingSeen = false
hooks = [] // a different component tree gets its own hook slots
let openedSection = ''
let completed = 0
const stepProps = { ...props, stepId: 'agent-dispatch', openSection: id => { openedSection = id }, complete: () => { completed += 1 } }

const stepLoading = renderOnce(onboarding.render, stepProps)
check('onboarding 步骤在事实未就绪时渲染 null（不占位、不挡路）', stepLoading.tree === null, JSON.stringify(stepLoading.tree))
await tick()
const stepCard = renderOnce(onboarding.render, stepProps)
const stepText = collectText(stepCard.tree).join(' ')
check('onboarding 渲染的是自成一体的卡片而非设置面板（ad_ob，不是 ad_root）',
  stepCard.tree?.props?.className === 'ad_ob' && !collectClasses(stepCard.tree).includes('ad_root'), String(stepCard.tree?.props?.className))
check('onboarding 卡片带标题与四步要点（复用字典，不另写一份文案）',
  stepText.includes(dictionaries.zh.obTitle) && ['guideS1', 'guideS2', 'guideS3', 'guideS4'].every(key => stepText.includes(dictionaries.zh[key])))
const stepButtons = findAll(stepCard.tree, node => node.type === 'button' && typeof node.props?.onClick === 'function')
check('onboarding 卡片给出「打开设置」与「暂时不用」两个出口', stepButtons.length === 2, `buttons=${stepButtons.length}`)
stepButtons[0]?.props?.onClick()
await tick()
check('「打开设置」把引导权交回宿主并跳到设置分区', openedSection === 'agent-dispatch' && completed === 1, `openSection=${openedSection} completed=${completed}`)
stepButtons[1]?.props?.onClick()
await tick()
check('「暂时不用」调 POST /config 记下「已看过」（重载后也不再冒出来）',
  fetched.some(item => item.url === `${API_PREFIX}/config` && item.method === 'POST'), JSON.stringify(fetched.slice(-2)))

hooks = []
summary.health.onboardingSeen = true // the "read" flag now comes back from the host fact
renderOnce(onboarding.render, stepProps)
await tick()
const stepSeen = renderOnce(onboarding.render, stepProps)
check('onboardingSeen=true 后侧栏卡片不再渲染', stepSeen.tree === null, JSON.stringify(stepSeen.tree))

// ── Summary ─────────────────────────────────────────────────────────────────────
fs.rmSync(home, { recursive: true, force: true })
const failed = results.filter(item => item.ok !== true)
console.log(`\n${results.length - failed.length} passed, ${failed.length} failed（浏览器半身冒烟）`)
if (failed.length > 0) {
  for (const item of failed) console.log(` - ${item.name}`)
  process.exit(1)
}
