/**
 * Build: regenerate lib/ from src/ (plain-JS plugin, zero dependencies).
 *
 * lib/ 是构建产物，不入库（见 .gitignore）；源码唯一权威在 src/。
 * 打包与安装时的强制构建入口：
 *   - `prepare`  — git 方式安装（dsh plugin add git+…）时由 pnpm 触发
 *   - `prepack`  — npm/pnpm pack 打 tarball 前触发，杜绝打进旧 lib
 *   - `npm run build` — 手动构建（link: 安装前请先执行一次）
 */
import { cpSync, rmSync } from 'node:fs'

rmSync('lib', { recursive: true, force: true })
cpSync('src', 'lib', { recursive: true })

console.log('built lib/ from src/ (build output, not tracked in git)')
