## Description
<!-- Please include a summary of the change and which issue is fixed. -->

## Type of Change
<!-- Please check the one that applies to this PR using "x". -->
- [ ] 🐛 Bug fix (non-breaking change which fixes an issue)
- [ ] ✨ New feature (non-breaking change which adds functionality)
- [ ] 📝 Documentation update
- [ ] 🧹 Code refactoring / cleanup

## How Has This Been Tested?
<!-- Please describe the tests that you ran to verify your changes. -->
- [ ] Tested locally with `pnpm dsh web --patch ./cordis.yml`
- [ ] Verified TypeScript compilation (`pnpm run build`)

## Checklist:
- [ ] My code follows the style guidelines of this project
- [ ] I have performed a self-review of my own code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] I have updated the `CHANGELOG.md` (if applicable)