# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-08-24

### Added
- Initial stable release of the Cat Companion plugin.
- `get_cat_fact` tool with optional `maxLength` parameter and robust error handling.
- `get_cat_image` tool to fetch and render random cat pictures.
- Strict TypeScript interfaces for API responses.
- Plugin configuration support (`defaultMaxLength`).
- Comprehensive documentation (README, LICENSE, CHANGELOG).
- GitHub PR templates and contribution guidelines.
- DSH bundle configuration for seamless `dsh plugin add` installation.
