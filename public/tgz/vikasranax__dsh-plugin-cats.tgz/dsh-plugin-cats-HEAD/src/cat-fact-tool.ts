import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'

// --- 1. Define TypeScript Interfaces for API Responses ---
interface CatFactResponse {
  fact: string;
  length: number;
}

interface CatImageResponse {
  id: string;
  url: string;
  width: number;
  height: number;
}

// --- 2. Define Plugin Configuration ---
interface PluginConfig {
  defaultMaxLength: number;
}

// This acts as the fallback configuration if the user doesn't specify one
const DEFAULT_CONFIG: PluginConfig = {
  defaultMaxLength: 200,
};

export const name = 'cat-companion-tools'
export const inject = ['tools']

export function apply(ctx: Context) {
  // In a full Cordis setup, we would merge DEFAULT_CONFIG with ctx.config here.
  // For this step, we use our robust default config object.
  const config = DEFAULT_CONFIG;

  // --- Tool 1: Cat Fact ---
  ctx.tools.register(defineTool({
    name: 'get_cat_fact',
    description: 'Fetches a random, interesting fact about cats from a public API.',
    parameters: {
      maxLength: { 
        type: 'number',
        description: 'Maximum length of the cat fact in characters. Uses plugin default if not specified.'
      },
    },
    output: {
      schema: { type: 'string' },
      render: (_args: Record<string, unknown>, value: string) => [{ type: 'text', text: value }],
    },
    async execute(args: { maxLength?: number }) {
      try {
        // 3. Use the config value instead of a hardcoded number
        const limit = args.maxLength || config.defaultMaxLength;
        const response = await fetch(`https://catfact.ninja/fact?max_length=${limit}`)
        if (!response.ok) throw new Error(`API responded with status: ${response.status}`)
        
        const data: CatFactResponse = await response.json()
        return data.fact
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error'
        return `Failed to fetch cat fact: ${errorMessage}. Please try again later.`
      }
    },
  }))

  // --- Tool 2: Cat Image ---
  ctx.tools.register(defineTool({
    name: 'get_cat_image',
    description: 'Fetches a random cat image URL from a public API.',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: (_args: Record<string, unknown>, value: string) => [{ type: 'text', text: `![Random Cat](${value})` }],
    },
    async execute() {
      try {
        const response = await fetch('https://api.thecatapi.com/v1/images/search')
        if (!response.ok) throw new Error(`API responded with status: ${response.status}`)
        
        const data: CatImageResponse[] = await response.json()
        return data[0].url 
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error'
        return `Failed to fetch cat image: ${errorMessage}. Please try again later.`
      }
    },
  }))
}