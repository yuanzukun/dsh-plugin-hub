# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2026-08-23
- Initial release: browse, search, star-sort, favorite, and one-click download community plugins from inside DeepSeek Harness settings.