# Security Policy

## Scope

This plugin only runs `git clone --depth 1` (never build scripts) and reads the awesome-dsh-plugin catalog. It does not collect or transmit any user data.

## Reporting a vulnerability

Please open an issue at https://github.com/PetCT/dsh-plugin-marketplace/issues.