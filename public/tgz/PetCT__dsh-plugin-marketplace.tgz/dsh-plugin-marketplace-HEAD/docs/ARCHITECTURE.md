# Architecture

Two halves, both plain source committed to this repo:

- **Host** (`src/index.js`) — runs in the DSH Node process. Loads the catalog (live fetch with a bundled snapshot fallback), serves HTTP routes via `webServer`, and installs plugins with `git clone` through `child_process`.
- **Client** (`src/client/index.tsx`) — browser UI bundled by tsdown into `client/client.js`. Registers a `settings.section` and talks to the host over `/dsh-plugin-marketplace/*` HTTP routes.

## Data flow

Client `fetch` -> Host route -> catalog load (live/snapshot) -> JSON response -> React list.
Install: Client `POST /install` -> Host `git clone` -> `installed/<owner>--<name>/` -> `meta.json`.