# FAQ

## Where are plugins downloaded?

`~/.dsh/dsh-plugin-marketplace/installed/<owner>--<name>/`

## Does this plugin run build scripts?

No. It only runs `git clone --depth 1`; it never executes the downloaded plugin's build scripts.

## Where does the catalog come from?

The live `https://awesome-dsh-plugin.com/plugins.json`, with `data/registry-snapshot.json` as an offline fallback.