import { readFile, writeFile, mkdir, stat, readdir } from 'node:fs/promises'
import { spawn } from 'node:child_process'
import { homedir } from 'node:os'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

export const name = 'dsh-plugin-marketplace'

const LIVE_URL = 'https://awesome-dsh-plugin.com/plugins.json'
const SNAPSHOT_PATH = join(dirname(fileURLToPath(import.meta.url)), '..', 'data', 'registry-snapshot.json')

function dataDir() {
  const home = process.env.DSH_HOME || join(homedir(), '.dsh')
  return join(home, 'dsh-plugin-marketplace')
}
function installedDir() { return join(dataDir(), 'installed') }
function favoritesPath() { return join(dataDir(), 'favorites.json') }

const sanitizeSeg = (s) => String(s).replace(/[^A-Za-z0-9._-]/g, '-').slice(0, 80)
const dirKeyOf = (p) => sanitizeSeg(p.owner) + '--' + sanitizeSeg(p.name)
const entryOf = (p) => ({
  key: String(p.owner ?? '') + '--' + String(p.name ?? ''),
  dirKey: dirKeyOf(p),
  name: p.name ?? '',
  owner: p.owner ?? '',
  url: typeof p.url === 'string' ? p.url : '',
  category: typeof p.category === 'string' ? p.category : '',
  npm: p.npm == null ? null : p.npm,
  stars: typeof p.stars === 'number' ? p.stars : 0,
  downloads: typeof p.downloads === 'number' ? p.downloads : null,
  added: typeof p.added === 'string' ? p.added : '',
  install: typeof p.install === 'string' ? p.install : '',
  deprecated: p.deprecated === true,
  replacement: typeof p.replacement === 'string' ? p.replacement : null,
  screenshots: Array.isArray(p.screenshots) ? p.screenshots.filter((s) => typeof s === 'string').slice(0, 6) : [],
  descZh: (p.description && typeof p.description.zh === 'string') ? p.description.zh.slice(0, 400) : '',
  descEn: (p.description && typeof p.description.en === 'string') ? p.description.en.slice(0, 400) : '',
})

let catalogCache = null

async function loadCatalog(force) {
  if (!force && catalogCache !== null) return catalogCache
  try {
    const res = await fetch(LIVE_URL, { signal: AbortSignal.timeout(15000) })
    if (res.ok) {
      const data = await res.json()
      if (Array.isArray(data.plugins) && data.plugins.length > 0) {
        catalogCache = { source: 'live', updated: typeof data.updated === 'string' ? data.updated : '', categories: (data.categories && typeof data.categories === 'object') ? data.categories : {}, entries: data.plugins.map(entryOf) }
        return catalogCache
      }
    }
  } catch (err) { /* fall back to snapshot */ }
  const text = await readFile(SNAPSHOT_PATH, 'utf8')
  const data = JSON.parse(text)
  catalogCache = { source: 'snapshot', updated: typeof data.updated === 'string' ? data.updated : '', categories: (data.categories && typeof data.categories === 'object') ? data.categories : {}, entries: data.plugins.map(entryOf) }
  return catalogCache
}

function repoUrl(url) {
  if (typeof url !== 'string' || url === '') return null
  const gh = /^https:\/\/github\.com\/([A-Za-z0-9._-]+)\/([A-Za-z0-9._-]+)/.exec(url)
  if (gh !== null) return 'https://github.com/' + gh[1] + '/' + gh[2]
  if (/^https:\/\/[^\s]+$/.test(url)) return url
  return null
}

function gitClone(url, dir) {
  return new Promise((resolve) => {
    let child
    try { child = spawn('git', ['clone', '--depth', '1', '--', url, dir], { stdio: ['ignore', 'pipe', 'pipe'] }) }
    catch (err) { resolve({ ok: false, err: '启动 git 失败：' + String(err && err.message ? err.message : err) }); return }
    let errText = ''
    let outText = ''
    child.stdout.on('data', (d) => { outText += d.toString() })
    child.stderr.on('data', (d) => { errText += d.toString() })
    const timer = setTimeout(() => { try { child.kill() } catch (e) {} resolve({ ok: false, err: '安装超时（180s）', timedOut: true }) }, 180000)
    child.on('close', (code) => { clearTimeout(timer); resolve({ ok: code === 0, exitCode: code, err: errText.slice(-2000), out: outText.slice(-2000) }) })
    child.on('error', (e) => { clearTimeout(timer); resolve({ ok: false, err: String(e.message) }) })
  })
}

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj)
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
  res.end(body)
}

async function readJsonBody(req) {
  const chunks = []
  for await (const c of req) chunks.push(c)
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}') } catch (err) { return {} }
}

async function readFavorites() {
  try { const arr = JSON.parse(await readFile(favoritesPath(), 'utf8')); return Array.isArray(arr) ? arr.filter((k) => typeof k === 'string') : [] }
  catch (err) { return [] }
}
async function writeFavorites(keys) {
  try { await mkdir(dataDir(), { recursive: true }); await writeFile(favoritesPath(), JSON.stringify(keys)); return true }
  catch (err) { return false }
}
async function listInstalled() {
  const items = []
  try {
    const entries = await readdir(installedDir(), { withFileTypes: true })
    for (const e of entries) {
      if (!e.isDirectory()) continue
      const item = { key: e.name, dir: join(installedDir(), e.name), meta: null }
      try { item.meta = JSON.parse(await readFile(join(installedDir(), e.name, 'meta.json'), 'utf8')) } catch (err) { /* no meta */ }
      items.push(item)
    }
  } catch (err) { /* no installed dir */ }
  return items
}

const detailCache = {}
async function detail(entry) {
  if (detailCache[entry.key]) return detailCache[entry.key]
  const out = { ok: true, key: entry.key, pushedAt: null, description: null, topics: [], source: 'none' }
  try {
    const res = await fetch('https://api.github.com/repos/' + entry.owner + '/' + entry.name, { signal: AbortSignal.timeout(8000), headers: { 'user-agent': 'dsh-plugin-marketplace' } })
    if (res.status === 200) {
      const g = await res.json()
      out.pushedAt = typeof g.pushed_at === 'string' ? g.pushed_at.slice(0, 10) : null
      out.description = typeof g.description === 'string' ? g.description : null
      out.topics = Array.isArray(g.topics) ? g.topics.slice(0, 12) : []
      out.source = 'github'
    } else if (res.status === 403 || res.status === 429) out.source = 'rate-limited'
    else out.source = 'not-found'
  } catch (err) { out.source = 'error' }
  detailCache[entry.key] = out
  return out
}

export function apply(ctx) {
  ctx.inject(['webServer'], (host) => {
    const disposers = []
    const reg = (path, handler) => disposers.push(host.webServer.register({ kind: 'exact', path, handler }))

    reg('/dsh-plugin-marketplace/registry', async (req, res) => {
      if (req.method !== 'GET') return sendJson(res, 405, { error: 'method not allowed' })
      try { const c = await loadCatalog(false); sendJson(res, 200, { ok: true, source: c.source, updated: c.updated, categories: c.categories, entries: c.entries }) }
      catch (err) { sendJson(res, 502, { ok: false, error: String(err && err.message ? err.message : err) }) }
    })

    reg('/dsh-plugin-marketplace/installed', async (req, res) => {
      if (req.method !== 'GET') return sendJson(res, 405, { error: 'method not allowed' })
      sendJson(res, 200, { items: await listInstalled() })
    })

    reg('/dsh-plugin-marketplace/install', async (req, res) => {
      if (req.method !== 'POST') return sendJson(res, 405, { error: 'method not allowed' })
      try {
        const body = await readJsonBody(req)
        const catalog = await loadCatalog(false)
        const entry = catalog.entries.find((e) => e.key === body.key)
        if (entry === undefined) return sendJson(res, 404, { status: 'unknown' })
        const cloneUrl = repoUrl(entry.url)
        if (cloneUrl === null) return sendJson(res, 400, { status: 'blocked', detail: '无法解析仓库地址：' + entry.url })
        const absDir = join(installedDir(), entry.dirKey)
        try { const st = await stat(absDir); if (st !== undefined) return sendJson(res, 200, { status: 'exists', dir: absDir }) } catch (err) { /* absent */ }
        await mkdir(installedDir(), { recursive: true })
        const clone = await gitClone(cloneUrl, absDir)
        if (!clone.ok) return sendJson(res, 502, { status: 'failed', detail: clone.timedOut ? '安装超时（180s）' : (clone.err || clone.out || 'git 退出码 ' + clone.exitCode) })
        let meta = false
        try { await writeFile(join(absDir, 'meta.json'), JSON.stringify({ name: entry.name, owner: entry.owner, url: entry.url, npm: entry.npm, stars: entry.stars, installedAt: new Date().toISOString() })); meta = true } catch (err) { /* non-fatal */ }
        sendJson(res, 200, { status: 'ok', dir: absDir, meta })
      } catch (err) { sendJson(res, 500, { status: 'failed', detail: String(err && err.message ? err.message : err) }) }
    })

    reg('/dsh-plugin-marketplace/favorites', async (req, res) => {
      if (req.method !== 'GET') return sendJson(res, 405, { error: 'method not allowed' })
      sendJson(res, 200, { keys: await readFavorites() })
    })

    reg('/dsh-plugin-marketplace/favorite', async (req, res) => {
      if (req.method !== 'POST') return sendJson(res, 405, { error: 'method not allowed' })
      const body = await readJsonBody(req)
      const keys = await readFavorites()
      const idx = keys.indexOf(body.key)
      if (body.value && idx === -1) keys.push(body.key)
      if (!body.value && idx !== -1) keys.splice(idx, 1)
      const saved = await writeFavorites(keys)
      sendJson(res, 200, { ok: saved, keys })
    })

    reg('/dsh-plugin-marketplace/detail', async (req, res) => {
      if (req.method !== 'POST') return sendJson(res, 405, { error: 'method not allowed' })
      const body = await readJsonBody(req)
      const catalog = await loadCatalog(false)
      const entry = catalog.entries.find((e) => e.key === body.key)
      if (entry === undefined) return sendJson(res, 404, { ok: false, error: 'unknown' })
      sendJson(res, 200, await detail(entry))
    })

    reg('/dsh-plugin-marketplace/reveal', async (req, res) => {
      if (req.method !== 'POST') return sendJson(res, 405, { error: 'method not allowed' })
      const body = await readJsonBody(req)
      const catalog = await loadCatalog(false)
      const entry = catalog.entries.find((e) => e.key === body.key)
      if (entry === undefined) return sendJson(res, 404, { ok: false, error: 'unknown' })
      const absDir = join(installedDir(), entry.dirKey)
      const cmd = process.platform === 'win32' ? 'explorer' : (process.platform === 'darwin' ? 'open' : 'xdg-open')
      try { spawn(cmd, [absDir], { stdio: 'ignore', detached: true }).unref(); sendJson(res, 200, { ok: true }) }
      catch (err) { sendJson(res, 500, { ok: false, error: String(err && err.message ? err.message : err) }) }
    })

    ctx.effect(() => () => { for (const d of disposers) { try { d() } catch (err) { /* noop */ } } })
  })
}
