import { createElement as h, useEffect, useState } from 'react'

export const name = 'dsh-plugin-marketplace'
export const inject = ['slots']

const CSS = `
.mk-root{display:flex;flex-direction:column;gap:12px;padding:4px 2px 24px;min-width:0}
.mk-head{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.mk-title{font-size:16px;font-weight:650}
.mk-badge{font-size:11px;padding:2px 8px;border-radius:999px;background:rgba(47,111,237,.16);color:#4d86ff}
.mk-badge.snap{background:rgba(128,128,128,.16);color:inherit}
.mk-meta{font-size:12px;opacity:.75}
.mk-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.mk-btn{font-size:12px;padding:5px 12px;border-radius:8px;border:1px solid rgba(128,128,128,.35);background:transparent;color:inherit;cursor:pointer;text-decoration:none;display:inline-block}
.mk-btn:hover{background:rgba(128,128,128,.12)}
.mk-btn.primary{background:#2f6fed;border-color:#2f6fed;color:#fff}
.mk-btn.primary:disabled{opacity:.55;cursor:default}
.mk-btn.done{color:#2fbf7f;border-color:rgba(47,191,127,.55);cursor:default}
.mk-input{flex:1;min-width:220px;font-size:13px;padding:7px 12px;border-radius:8px;border:1px solid rgba(128,128,128,.35);background:rgba(128,128,128,.06);color:inherit}
.mk-select{font-size:12px;padding:6px 10px;border-radius:8px;border:1px solid rgba(128,128,128,.35);background:rgba(128,128,128,.06);color:inherit;cursor:pointer}
.mk-chip{font-size:12px;padding:4px 10px;border-radius:999px;border:1px solid rgba(128,128,128,.3);cursor:pointer;background:transparent;color:inherit}
.mk-chip.on{background:#2f6fed;border-color:#2f6fed;color:#fff}
.mk-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:10px}
.mk-card{border:1px solid rgba(128,128,128,.28);border-radius:10px;padding:10px 12px;display:flex;flex-direction:column;gap:6px;cursor:pointer;min-width:0;position:relative}
.mk-card:hover{border-color:#2f6fed}
.mk-card-top{display:flex;align-items:baseline;justify-content:space-between;gap:8px}
.mk-name{font-size:13.5px;font-weight:620;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-right:22px}
.mk-owner{font-size:11.5px;opacity:.65;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.mk-desc{font-size:12px;line-height:1.5;opacity:.85;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.mk-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:2px}
.mk-stars{font-size:11.5px;opacity:.7}
.mk-fav{position:absolute;top:8px;right:8px;border:none;background:transparent;cursor:pointer;font-size:15px;line-height:1;color:rgba(128,128,128,.55);padding:2px}
.mk-fav.on{color:#ff5a7a}
.mk-detail{border:1px solid rgba(128,128,128,.28);border-radius:10px;padding:14px 16px;display:flex;flex-direction:column;gap:8px;min-width:0}
.mk-cmd{font-family:Consolas,monospace;font-size:11.5px;background:rgba(128,128,128,.1);border-radius:6px;padding:6px 8px;overflow-wrap:anywhere}
.mk-banner{font-size:12px;border-radius:8px;padding:8px 12px;overflow-wrap:anywhere}
.mk-banner.err{background:rgba(214,69,69,.12);color:#ff7a7a}
.mk-banner.ok{background:rgba(34,160,107,.14);color:#2fbf7f}
.mk-warn{background:rgba(255,166,0,.14);color:#e8a020}
.mk-empty{font-size:13px;opacity:.7;padding:24px 8px;text-align:center}
.mk-tag{font-size:11px;padding:2px 8px;border-radius:999px;background:rgba(47,111,237,.12);color:#4d86ff}
.mk-shots{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px}
.mk-shots img{width:100%;border-radius:8px;border:1px solid rgba(128,128,128,.25)}
.mk-sec-title{font-size:12px;font-weight:650;opacity:.85;margin-top:4px}
`

function call(path, body) {
  const init = body === undefined
    ? { method: 'GET' }
    : { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }
  return fetch('/dsh-plugin-marketplace/' + path, init).then((r) => r.json())
}

const seg = (s) => String(s).replace(/[^A-Za-z0-9._-]/g, '-').slice(0, 80)
const dirKeyOf = (p) => seg(p.owner) + '--' + seg(p.name)

function MarketSection() {
  const [view, setView] = useState({ phase: 'loading', error: null, catalog: null, query: '', category: 'all', status: 'all', sort: 'default', selected: null, detail: null, installed: {}, favorites: {}, installing: null, banner: null })
  const patch = (p) => setView((s) => Object.assign({}, s, p))

  const load = () => {
    patch({ phase: 'loading', error: null })
    call('registry').then((res) => {
      if (res && res.ok === true) patch({ phase: 'ready', catalog: res })
      else patch({ phase: 'error', error: (res && res.error) ? String(res.error) : '目录加载失败' })
    }).catch((err) => patch({ phase: 'error', error: String(err && err.message ? err.message : err) }))
  }
  const loadInstalled = () => {
    call('installed').then((res) => {
      if (res && Array.isArray(res.items)) {
        const map = {}
        res.items.forEach((it) => { map[it.key] = it })
        patch({ installed: map })
      }
    }).catch(() => {})
  }
  const loadFavorites = () => {
    call('favorites').then((res) => {
      if (res && Array.isArray(res.keys)) {
        const m = {}
        res.keys.forEach((k) => { m[k] = true })
        patch({ favorites: m })
      }
    }).catch(() => {})
  }
  useEffect(() => { load(); loadInstalled(); loadFavorites() }, [])

  const catalog = view.catalog
  const catMap = (catalog && catalog.categories) ? catalog.categories : {}
  const catIds = Object.keys(catMap)
  const catLabel = (id) => { const c = catMap[id]; return (c && (c.zh || c.en)) ? (c.zh || c.en) : id }
  const isInstalled = (p) => view.installed[dirKeyOf(p)] !== undefined
  const isFav = (p) => view.favorites[p.key] === true

  let entries = []
  if (catalog && Array.isArray(catalog.entries)) {
    const q = view.query.trim().toLowerCase()
    entries = catalog.entries.filter((p) => {
      if (view.category !== 'all' && p.category !== view.category) return false
      const inst = isInstalled(p)
      if (view.status === 'installed' && !inst) return false
      if (view.status === 'not-installed' && inst) return false
      if (view.status === 'favorites' && !isFav(p)) return false
      if (q !== '') {
        const hay = String((p.name || '') + ' ' + (p.owner || '') + ' ' + (p.npm || '') + ' ' + (p.descZh || '') + ' ' + (p.descEn || '') + ' ' + (p.install || '')).toLowerCase()
        if (hay.indexOf(q) === -1) return false
      }
      return true
    })
    if (view.sort === 'stars-desc') entries = entries.slice().sort((a, b) => (b.stars || 0) - (a.stars || 0))
    else if (view.sort === 'stars-asc') entries = entries.slice().sort((a, b) => (a.stars || 0) - (b.stars || 0))
    else if (view.sort === 'added-desc') entries = entries.slice().sort((a, b) => String(b.added || '').localeCompare(String(a.added || '')))
    else if (view.sort === 'downloads-desc') entries = entries.slice().sort((a, b) => (b.downloads || 0) - (a.downloads || 0))
  }

  const onInstall = (p) => {
    patch({ installing: p.key, banner: null })
    call('install', { key: p.key }).then((res) => {
      if (res && res.status === 'ok') patch({ installing: null, banner: { kind: 'ok', text: '已安装到 ' + (res.dir || '') } })
      else if (res && res.status === 'exists') patch({ installing: null, banner: { kind: 'ok', text: '该插件已安装：' + (res.dir || '') } })
      else patch({ installing: null, banner: { kind: 'err', text: '安装失败：' + ((res && res.detail) ? String(res.detail) : '未知错误') } })
      loadInstalled()
    }).catch((err) => patch({ installing: null, banner: { kind: 'err', text: '安装失败：' + String(err && err.message ? err.message : err) } }))
  }
  const onReveal = (p) => {
    call('reveal', { key: p.key }).then((res) => {
      if (!res || res.ok !== true) patch({ banner: { kind: 'err', text: '打开目录失败：' + ((res && res.error) || '未知错误') } })
    }).catch((err) => patch({ banner: { kind: 'err', text: '打开目录失败：' + String(err && err.message ? err.message : err) } }))
  }
  const onFav = (p, ev) => {
    if (ev) ev.stopPropagation()
    const next = !isFav(p)
    const fm = Object.assign({}, view.favorites)
    if (next) fm[p.key] = true; else delete fm[p.key]
    patch({ favorites: fm })
    call('favorite', { key: p.key, value: next }).then((res) => {
      if (res && Array.isArray(res.keys)) {
        const m = {}
        res.keys.forEach((k) => { m[k] = true })
        patch({ favorites: m })
      }
    }).catch(() => {})
  }
  const openDetail = (p) => {
    patch({ selected: p, detail: null })
    call('detail', { key: p.key }).then((res) => { if (res && res.ok) patch({ detail: res }) }).catch(() => {})
  }

  const bannerEl = view.banner ? h('div', { className: 'mk-banner ' + (view.banner.kind === 'err' ? 'err' : 'ok') }, view.banner.text) : null
  const chip = (label, active, onClick) => h('button', { className: 'mk-chip' + (active ? ' on' : ''), onClick: onClick }, label)

  const head = h('div', { className: 'mk-head' },
    h('div', { className: 'mk-title' }, '插件市场'),
    catalog ? h('span', { className: 'mk-badge' + (catalog.source === 'snapshot' ? ' snap' : '') }, catalog.source === 'live' ? '实时目录' : '本地快照') : null,
    catalog && catalog.updated ? h('span', { className: 'mk-meta' }, '目录更新 ' + catalog.updated) : null,
    catalog ? h('span', { className: 'mk-meta' }, (catalog.entries ? catalog.entries.length : 0) + ' 个插件') : null,
    h('span', { style: { flex: 1 } }),
    h('button', { className: 'mk-btn', onClick: () => { load(); loadInstalled(); loadFavorites() } }, '刷新')
  )

  const toolbar = h('div', { style: { display: 'flex', flexDirection: 'column', gap: 8 } },
    h('div', { className: 'mk-row' },
      h('input', { className: 'mk-input', placeholder: '搜索插件名 / 作者 / 描述 / npm 包…', value: view.query, onChange: (ev) => patch({ query: ev.target.value }) }),
      h('select', { className: 'mk-select', value: view.sort, onChange: (ev) => patch({ sort: ev.target.value }) },
        h('option', { value: 'default' }, '默认排序'),
        h('option', { value: 'stars-desc' }, '星标 · 高 → 低'),
        h('option', { value: 'stars-asc' }, '星标 · 低 → 高'),
        h('option', { value: 'added-desc' }, '最新收录'),
        h('option', { value: 'downloads-desc' }, '下载量')
      )
    ),
    h('div', { className: 'mk-row' },
      chip('全部', view.status === 'all', () => patch({ status: 'all' })),
      chip('已安装', view.status === 'installed', () => patch({ status: 'installed' })),
      chip('未安装', view.status === 'not-installed', () => patch({ status: 'not-installed' })),
      chip('♥ 收藏', view.status === 'favorites', () => patch({ status: 'favorites' })),
      h('span', { className: 'mk-meta', style: { margin: '0 4px' } }, '|'),
      chip('全部分类', view.category === 'all', () => patch({ category: 'all' })),
      ...catIds.map((id) => chip(catLabel(id), view.category === id, () => patch({ category: id })))
    )
  )

  const detail = view.selected ? h('div', { className: 'mk-detail' },
    h('div', { className: 'mk-row' }, h('button', { className: 'mk-btn', onClick: () => patch({ selected: null, detail: null }) }, '← 返回列表'), h('span', { style: { flex: 1 } })),
    h('div', { className: 'mk-card-top' },
      h('div', null,
        h('div', { className: 'mk-name', style: { paddingRight: 0 } }, view.selected.name),
        h('div', { className: 'mk-owner' }, view.selected.owner + (view.selected.npm ? ' · ' + view.selected.npm : ''))),
      h('button', { className: 'mk-fav' + (isFav(view.selected) ? ' on' : ''), style: { position: 'static' }, onClick: (ev) => onFav(view.selected, ev) }, isFav(view.selected) ? '♥' : '♡')
    ),
    view.selected.deprecated ? h('div', { className: 'mk-banner mk-warn' }, '该插件已被弃用' + (view.selected.replacement ? '，建议改用：' + view.selected.replacement : '')) : null,
    h('div', { className: 'mk-row' },
      h('span', { className: 'mk-stars' }, '★ ' + view.selected.stars),
      view.selected.downloads != null ? h('span', { className: 'mk-meta' }, '↓ ' + view.selected.downloads + ' / 30天') : null,
      h('span', { className: 'mk-meta' }, '分类 ' + catLabel(view.selected.category)),
      view.selected.added ? h('span', { className: 'mk-meta' }, '收录 ' + view.selected.added) : null,
      h('span', { className: 'mk-meta' }, '最近更新 ' + (view.detail && view.detail.pushedAt ? view.detail.pushedAt : (view.detail && view.detail.source === 'rate-limited' ? '限流稍后再试' : (view.detail ? '—' : '查询中…'))))
    ),
    h('div', { className: 'mk-sec-title' }, '功能说明'),
    (view.selected.descZh || view.selected.descEn) ? h('div', { className: 'mk-desc', style: { display: 'block', WebkitLineClamp: 'unset' } }, view.selected.descZh || view.selected.descEn) : h('div', { className: 'mk-meta' }, '（无描述）'),
    (view.selected.descZh && view.selected.descEn) ? h('div', { className: 'mk-desc', style: { display: 'block', opacity: 0.6, WebkitLineClamp: 'unset' } }, view.selected.descEn) : null,
    (view.detail && view.detail.description && view.detail.description !== (view.selected.descEn || view.selected.descZh)) ? h('div', { className: 'mk-desc', style: { display: 'block', WebkitLineClamp: 'unset' } }, view.detail.description) : null,
    (view.detail && view.detail.topics && view.detail.topics.length > 0) ? h('div', { className: 'mk-row' }, ...view.detail.topics.map((t) => h('span', { className: 'mk-tag', key: 't-' + t }, t))) : null,
    (view.selected.screenshots && view.selected.screenshots.length > 0) ? h('div', null, h('div', { className: 'mk-sec-title' }, '截图'), h('div', { className: 'mk-shots' }, ...view.selected.screenshots.map((s, i) => h('img', { key: 's-' + i, src: s, loading: 'lazy' })))) : null,
    h('div', { className: 'mk-sec-title' }, '安装'),
    h('div', { className: 'mk-cmd' }, view.selected.install || ('git clone ' + view.selected.url)),
    h('div', { className: 'mk-row' },
      isInstalled(view.selected)
        ? h('button', { className: 'mk-btn done', disabled: true }, '已安装 ✓')
        : h('button', { className: 'mk-btn primary', disabled: view.installing === view.selected.key, onClick: () => onInstall(view.selected) }, view.installing === view.selected.key ? '安装中…' : '一键安装'),
      isInstalled(view.selected) ? h('button', { className: 'mk-btn', onClick: () => onReveal(view.selected) }, '打开目录') : null,
      h('a', { className: 'mk-btn', href: view.selected.url, target: '_blank', rel: 'noreferrer' }, 'GitHub 主页')
    )
  ) : null

  let body = null
  if (view.phase === 'loading') body = h('div', { className: 'mk-empty' }, '正在加载插件目录…')
  else if (view.phase === 'error') body = h('div', { className: 'mk-empty' },
    h('div', null, '目录加载失败：' + view.error),
    h('button', { className: 'mk-btn', style: { marginTop: 10 }, onClick: load }, '重试'))
  else if (entries.length === 0) body = h('div', { className: 'mk-empty' }, '没有匹配的插件')
  else body = h('div', { className: 'mk-list' }, entries.slice(0, 400).map((p) => h('div', { className: 'mk-card', key: p.key, onClick: () => openDetail(p) },
    h('button', { className: 'mk-fav' + (isFav(p) ? ' on' : ''), onClick: (ev) => onFav(p, ev) }, isFav(p) ? '♥' : '♡'),
    h('div', { className: 'mk-card-top' },
      h('div', { className: 'mk-name', title: p.name }, p.name),
      h('span', { className: 'mk-stars' }, '★ ' + p.stars)
    ),
    h('div', { className: 'mk-owner' }, p.owner + ' · ' + catLabel(p.category)),
    (p.descZh || p.descEn) ? h('div', { className: 'mk-desc' }, p.descZh || p.descEn) : null,
    h('div', { className: 'mk-foot' },
      h('span', { className: 'mk-meta' }, (p.npm ? 'npm' : 'git') + (p.added ? ' · ' + p.added : '') + (p.downloads != null ? ' · ↓' + p.downloads : '')),
      isInstalled(p)
        ? h('span', { className: 'mk-btn done' }, '已安装 ✓')
        : h('button', { className: 'mk-btn primary', disabled: view.installing === p.key, onClick: (ev) => { ev.stopPropagation(); onInstall(p) } }, view.installing === p.key ? '安装中…' : '安装')
    )
  )))

  return h('div', { className: 'mk-root' }, head, toolbar, bannerEl, detail, body)
}

export function apply(ctx) {
  if (typeof document !== 'undefined') {
    const styleId = 'dsh-plugin-marketplace-css'
    if (!document.getElementById(styleId)) {
      const tag = document.createElement('style')
      tag.id = styleId
      tag.textContent = CSS
      document.head.appendChild(tag)
    }
  }
  ctx.slots.inject('settings.section', () => ctx.slots.register(
    { name: 'settings.section', id: 'dsh-plugin-marketplace', order: 40, label: '插件市场' },
    () => h(MarketSection),
  ))
}
