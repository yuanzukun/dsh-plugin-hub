# Contributing

Thanks for your interest in contributing!

## Development

```sh
npm install
npm run build   # builds the client bundle into client/client.js
```

## Submitting changes

1. Open a pull request against `main`.
2. Run `npm run build` and commit the regenerated `client/client.js`.