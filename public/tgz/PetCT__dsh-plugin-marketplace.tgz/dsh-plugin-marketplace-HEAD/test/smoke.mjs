import { readFile } from 'node:fs/promises'

const mod = await import('../src/index.js')
if (typeof mod.name !== 'string' || typeof mod.apply !== 'function') {
  console.error('smoke: host entry must export name and apply')
  process.exit(1)
}
const pkg = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'))
if (!pkg.dsh || !pkg.dsh.bundle || !pkg.dsh.bundle.patch) {
  console.error('smoke: package.json must declare dsh.bundle.patch')
  process.exit(1)
}
console.log('smoke: OK')