# Code of Conduct

Be respectful, be kind, and assume good faith. Harassment of any kind will not be tolerated.