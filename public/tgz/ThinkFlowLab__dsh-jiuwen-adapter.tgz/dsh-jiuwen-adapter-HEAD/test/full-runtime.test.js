/**
 * Round 7: role-less host messages (as dsh-agent-loop sends them) and the full-agent-runtime A/B
 * compatibility matrix. The matrix needs the dsh packages (DSH_NM) and is skipped without them;
 * JIUWEN_LIVE=1 adds the live-Gateway variants.
 */
import { test, describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { existsSync } from 'node:fs'
import { withInferredRoles } from '../src/messages.js'
import { buildQuery } from '../src/adapter.js'

const sys = Object.freeze({ role: 'system', content: [{ type: 'text', text: 'You are a test agent. create_goal may infer goals.' }], source: { kind: 'system-prompt' } })
const user = text => Object.freeze({ content: Object.freeze([{ type: 'text', text }]), source: Object.freeze({ kind: 'user' }) })

test('withInferredRoles: infers user/assistant/tool/system, keeps explicit roles, never mutates', () => {
  const msgs = Object.freeze([sys, user('hi'), Object.freeze({ content: [], source: { kind: 'model' } }), Object.freeze({ toolCallId: 'c1', content: [] }), Object.freeze({ role: 'developer', content: [] })])
  const out = withInferredRoles(msgs)
  assert.deepEqual(out.map(m => m.role), ['system', 'user', 'assistant', 'tool', 'developer'])
  assert.equal(out[0], sys, 'messages with a role are passed through by reference')
  assert.equal(msgs[1].role, undefined, 'host message not mutated')
  const typed = [sys, { role: 'user', content: [] }]
  assert.equal(withInferredRoles(typed), typed, 'fully-typed arrays are returned unchanged')
  assert.equal(withInferredRoles(undefined), undefined)
})

test('buildQuery sends the role-less user text, not the system prompt (dsh-agent-loop shape)', () => {
  const options = { messages: withInferredRoles([sys, user('Reply with exactly: mixed-ok')]) }
  const q = buildQuery(options, { turns: 0 }, { historyMode: 'gateway', ignoreMessagePatterns: [] }, {})
  assert.equal(q, 'Reply with exactly: mixed-ok')
  const q2 = buildQuery({ messages: withInferredRoles([sys, user('first'), { role: 'assistant', content: [{ type: 'text', text: 'ok' }] }, user('second')]) }, { turns: 1 }, { historyMode: 'gateway', ignoreMessagePatterns: [] }, {})
  assert.equal(q2, 'second')
})

const ROOT = new URL('..', import.meta.url).pathname
const NM = `${process.env.DSH_NM || '/workspace/fb-busyack3/core/dev/harness/node_modules'}/@deepseek-ai`
const hasRuntime = ['cordis', 'dsh-agent', 'dsh-agent-loop', 'dsh-llm', 'dsh-session', 'dsh-tools', 'dsh-commands'].every(p => existsSync(`${NM}/${p}/lib/index.js`))

describe('full agent runtime A/B matrix', { skip: !hasRuntime && 'dsh agent runtime packages not found (set DSH_NM)' }, () => {
  it('every feature identical with and without the adapter (down/after, before, two, mixed)', async () => {
    let out
    // --live drives a real Jiuwen (the read-only preset flips its global bash/write/edit levels): snapshot + exact restore.
    const live = process.env.JIUWEN_LIVE === '1' ? await import('./live/lib.mjs') : null
    const snap = live && await live.gatewayUp() ? await live.snapshot() : null
    try { out = execFileSync(process.execPath, [`${ROOT}scripts/compat-matrix.mjs`, ...(process.env.JIUWEN_LIVE ? ['--live'] : [])], { encoding: 'utf8', timeout: 700_000, stdio: ['ignore', 'pipe', 'pipe'] }) } catch (e) { out = e.stdout }
    if (snap) assert.deepEqual(await live.restore(snap), [], 'Jiuwen state restored after the --live matrix')
    const m = JSON.parse(out)
    const bad = m.rows.filter(r => r.slice(1).some(c => c !== 'identical'))
    assert.deepEqual(bad, [], JSON.stringify({ header: m.header, diffs: m.diffs }))
    assert.ok(m.baseline.events > 100, 'scenario exercised the runtime')
    assert.equal(m.baseline.deepseek, 'loaded', 'dsh-llm-deepseek-api-key coexists')
    for (const [name, x] of Object.entries(m.extra)) {
      assert.deepEqual(x.nonNamespaced, [], name)
      assert.equal(x.serviceAfterDispose, 'gone', name)
      if (x.jwOut) assert.ok(x.jwOut.includes('jiuwenInAgentView:cmd=true') && !x.jwOut.some(s => s.startsWith('THROW')), `${name}: ${x.jwOut}`)
    }
    // injectSystem defaults to 'full' (whole host system prompt, persona first); persona-only mode is covered by the --sync2 persona rows.
    assert.match(String(m.extra['mock/mixed'].jwOut), /agent:gateway-mock: \[System instructions from host\]\nYou are a test agent\.\n/, 'jiuwen agent sends the host system prompt (starting with the dsh persona) + user text')
    assert.ok(!String(m.extra['mock/mixed'].jwOut).includes('exit code'), 'no dsh boilerplate forwarded')
    assert.equal(m.ok, true)
  })
  it('baseline scenario covers approval, tools, compaction (manual + automatic), commands, retry, title, plan exit, goal rounds, subagent, bash', () => {
    const r = JSON.parse(execFileSync(process.execPath, [`${ROOT}scripts/compat-runtime.mjs`], { encoding: 'utf8', timeout: 120_000, stdio: ['ignore', 'pipe', 'ignore'] }))
    for (const t of ['approval/asked', 'approval/decided', 'tool/result', 'todo/write', 'compaction/summary', 'command/done', 'llm/retry', 'session/title', 'plan/mode', 'goal/change']) assert.ok(r.types.includes(t), t)
    assert.deepEqual(r.approvals, ['guarded:allowed-once', 'guarded:rejected'])
    assert.deepEqual(r.questions, ['q1', 'plan-review:plan-review'], 'exit_plan_mode approval goes through user-questions')
    for (const w of ['wait-subagent:settled', 'wait-goal:complete']) assert.ok(r.results.includes(w), w)
    assert.ok(r.types.includes('subagent/catalog'), 'subagent ran')
    const sc = r.scenarios
    assert.equal(sc.planExit, 1); assert.equal(sc.goalRounds, 1); assert.equal(sc.subagent, 1); assert.equal(sc.bash, 1); assert.equal(sc.manualCompactions, 1)
    assert.ok(sc.goalOps.includes('complete'), 'goal completed by a round')
    assert.ok(sc.autoCompactions >= 1, 'token pressure triggered automatic compaction')
    assert.ok(r.results.some(x => x.startsWith('say:CALL bash')), 'bash ran')
    assert.ok(r.results.filter(x => x.startsWith('small:')).length === 6, 'small-window agent ran')
    assert.ok(r.results.some(x => x.startsWith('/compact => success')))
    assert.ok(r.tools.includes('mcp__echo__echo'))
    assert.deepEqual(r.failed, [])
  })
})
