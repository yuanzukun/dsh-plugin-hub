/**
 * Extended `/jiuwen` subcommands (JiuwenSwarm 0.2.7 /ws). Each entry declares the Gateway methods it
 * needs so `/jiuwen help` hides entries whose methods this Gateway answered `unknown method` for.
 * Writes are reversible; deletes need an explicit trailing `confirm` argument.
 */

const SECRET_KEY = /(api_?key|token|secret|passw(or)?d|cookie|authorization|credential|private_?key|access_?key|client_?secret|encrypt_?key|aes_?key|signing_?key|webhook_?url)/i

/** Deep-copy `value` replacing secret-looking fields with `***` (or `(empty)`). */
export function maskSecrets(value, depth = 0) {
  if (depth > 12) return '…'
  if (Array.isArray(value)) return value.map(v => maskSecrets(v, depth + 1))
  if (!value || typeof value !== 'object') return value
  const out = {}
  for (const [k, v] of Object.entries(value)) {
    if (SECRET_KEY.test(k) && (typeof v === 'string' || typeof v === 'number')) out[k] = String(v).length ? '***' : '(empty)'
    else out[k] = maskSecrets(v, depth + 1)
  }
  return out
}

/** Split on whitespace, honouring "double" / 'single' quotes. */
export function tokenize(input) {
  const out = []
  const str = String(input || '')
  let cur = null
  let quote = null
  for (let i = 0; i < str.length; i++) {
    const ch = str[i]
    if (quote) {
      if (ch === '\\' && quote === '"' && i + 1 < str.length) { cur += str[++i]; continue }
      if (ch === quote) { quote = null; continue }
      cur += ch
    } else if (ch === '"' || ch === "'") { quote = ch; cur ??= '' } else if (/\s/.test(ch)) {
      if (cur !== null) { out.push(cur); cur = null }
    } else cur = (cur ?? '') + ch
  }
  if (cur !== null) out.push(cur)
  return out
}

/** `key=value` pairs (value may be quoted as a whole token: key="a b"). */
export function kv(tokens) {
  const o = {}
  for (const t of tokens) {
    const i = t.indexOf('=')
    if (i > 0) o[t.slice(0, i)] = t.slice(i + 1)
  }
  return o
}

const short = (s, n = 120) => String(s ?? '').replace(/\s+/g, ' ').trim().slice(0, n)
const j = (v, n = 600) => short(JSON.stringify(v), n)
const label = (d) => (d && typeof d === 'object' ? (d.zh || d.en || Object.values(d)[0]) : d)
const onOff = (raw) => { const v = String(raw || '').toLowerCase(); return ['on', 'true', '1', 'enable', 'enabled'].includes(v) ? true : (['off', 'false', '0', 'disable', 'disabled'].includes(v) ? false : undefined) }
const getPath = (obj, path) => String(path).split('.').filter(Boolean).reduce((o, k) => (o == null ? undefined : o[k]), obj)
const jobLine = j2 => `- ${j2.id || j2.job_id}${j2.name ? `  ${short(j2.name, 40)}` : ''}${j2.enabled === false ? ' [disabled]' : (j2.enabled ? ' [enabled]' : '')}${j2.cron_expr ? `  "${j2.cron_expr}"` : ''}`

const softGitMsg = (msg) => /git (operations )?not available|FORBIDDEN|git (is )?disabled|not enabled for this project/i.test(String(msg || ''))
async function resolveProjectId(g, raw) {
  if (raw) return raw
  const l = await g.rpc('project.list', {}).catch(() => null)
  const ps = l?.projects || []
  return (ps.find(p => p.is_default) || ps[0])?.project_id || 'default'
}
function flattenTree(nodes, out = [], depth = 0) {
  for (const n of nodes || []) {
    const mark = (n.type === 'dir' || n.type === 'directory') ? '📁' : '📄'
    out.push(`${'  '.repeat(depth)}${mark} ${n.path || n.name || '?'}${n.size != null ? ` (${n.size}b)` : ''}`)
    if (Array.isArray(n.children)) flattenTree(n.children, out, depth + 1)
  }
  return out
}
function fileLines(files) {
  if (!Array.isArray(files)) return []
  return files.slice(0, 40).map(f => {
    if (typeof f === 'string') return `- ${f}`
    const mark = (f.type === 'dir' || f.type === 'directory') ? '📁' : '📄'
    return `- ${mark} ${f.path || f.name || j(f, 40)}${f.size != null ? ` (${f.size}b)` : ''}`
  })
}

/** Normalise a cron expr to 5 or 7 fields (Gateway rejects 6). 5-field → Quartz 7-field with second=0, year=*. */
export function normalizeCronExpr(expr) {
  const parts = String(expr || '').trim().split(/\s+/).filter(Boolean)
  if (parts.length === 5) return ['0', ...parts, '*'].join(' ')
  if (parts.length === 6) return ['0', ...parts].join(' ') // minute…dow year → add seconds
  return parts.join(' ')
}

const needConfirm = (tokens, what) => (tokens.some(t => t === 'confirm' || t === '--confirm') ? null : `Refusing to ${what} without confirmation: re-run with a trailing \`confirm\`.`)

/** One readable line per team.history record (0.2.7 records carry empty `content` for tool/team events). */
export function teamRecordLine(x) {
  const who = x?.member_name || x?.from_member || x?.role || '?'
  const text = (typeof x?.content === 'string' && x.content.trim()) ? x.content
    : x?.summary || x?.message
    || (x?.event_type === 'chat.tool_call' ? `🔧 ${x.tool_call?.name || x.tool_call?.function?.name || 'tool'}` : '')
    || (x?.event_type === 'chat.tool_result' ? `↳ ${x.tool_name || 'tool'} ${x.success === false ? 'failed' : 'ok'}` : '')
    || (x?.event_type ? `${x.event_type}${x.event?.type || typeof x.event === 'string' ? ` ${x.event?.type || x.event}` : ''}` : j(x, 100))
  return `[${who}] ${short(text, 120)}`
}

/**
 * @typedef {{ g: any, sid: string, dshId: string, rest: string[], tokens: string[], deps: any }} ExtCtx
 * @type {Record<string, { usage: string, group: string, methods: string[], run: (c: ExtCtx) => Promise<string> }>}
 */
export const EXT = {
  // ── P1 read-only ──
  'config': {
    usage: 'config [get] [dot.path]', group: 'Config & policy', methods: ['config.get'],
    async run({ g, tokens }) {
      const path = tokens[0] === 'get' ? tokens[1] : tokens[0]
      const r = maskSecrets(await g.rpc('config.get', {}))
      if (path) {
        const v = getPath(r, path)
        return v === undefined ? `Jiuwen config: no key "${path}"` : `Jiuwen config ${path} = ${j(v, 1500)}`
      }
      const lines = Object.entries(r || {}).slice(0, 60).map(([k, v]) => `${k}=${v && typeof v === 'object' ? (Array.isArray(v) ? `[${v.length}]` : `{${Object.keys(v).length} keys}`) : short(v, 80)}`)
      return `Jiuwen config (secrets masked; ${Object.keys(r || {}).length} keys):\n${lines.join('\n')}`
    },
  },
  'mcp show': {
    usage: 'mcp show <name|id>', group: 'System', methods: ['mcp.show'],
    async run({ g, rest }) {
      const q = rest[1]
      if (!q) return 'Usage: /jiuwen mcp show <name|id> (see /jiuwen mcp)'
      let id = q
      const listed = await g.rpc('mcp.list', { filter: 'all' }).catch(() => null)
      const hit = (listed?.items || []).find(x => [x.id, x.name, x.package_name].includes(q))
      if (hit?.id) id = hit.id
      const r = await g.rpc('mcp.show', { id })
      const it = maskSecrets(r?.item || r || {})
      return `Jiuwen MCP ${it.name || q}${it.display_name ? ` (${it.display_name})` : ''}: ${short(it.description, 200) || '(no description)'}${it.connection_state ? `\nstate: ${it.connection_state}` : ''}${it.category ? `\ncategory: ${it.category}` : ''}${Array.isArray(it.tools) ? `\ntools: ${it.tools.map(t => t.name || t).join(', ')}` : ''}`
    },
  },
  'skills search': {
    usage: 'skills search <query>', group: 'Skills & agents', methods: ['skills.retrieval.search'],
    async run({ g, tokens }) {
      const query = tokens.slice(1).join(' ')
      if (!query) return 'Usage: /jiuwen skills search <query>'
      const r = await g.rpc('skills.retrieval.search', { query })
      const text = typeof r?.result === 'string' ? r.result : j(r?.results || r, 1200)
      return `Jiuwen skill search "${query}" (${r?.mode || 'auto'}):\n${String(text).split('\n').slice(0, 15).map(l => short(l, 200)).join('\n') || 'no matches'}`
    },
  },
  'skills online': {
    usage: 'skills online <query>', group: 'Skills & agents', methods: ['skills.online_search.search'],
    async run({ g, tokens }) {
      const query = tokens.slice(1).join(' ')
      if (!query) return 'Usage: /jiuwen skills online <query>'
      const r = await g.rpc('skills.online_search.search', { query })
      const items = Array.isArray(r?.items) ? r.items : []
      return items.length
        ? `Jiuwen online skills "${query}" (${items.length}; read-only, nothing installed):\n${items.slice(0, 10).map(x => `- ${x.name}${x.source ? ` [${x.source}]` : ''}: ${short(x.display_name || x.description, 80)}`).join('\n')}`
        : `No online skills for "${query}"`
    },
  },
  'skills show': {
    usage: 'skills show <name>', group: 'Skills & agents', methods: ['skills.get'],
    async run({ g, rest }) {
      const name = rest[1]
      if (!name) return 'Usage: /jiuwen skills show <name>'
      const s = await g.rpc('skills.get', { name })
      return `Jiuwen skill ${s?.name || name}: ${short(s?.description, 200) || '(no description)'}${s?.category ? `\ncategory: ${s.category}` : ''}${Array.isArray(s?.tags) && s.tags.length ? `\ntags: ${s.tags.join(', ')}` : ''}${s?.author ? `\nauthor: ${s.author}` : ''}${s?.enabled === false ? '\n[disabled]' : ''}`
    },
  },
  'memory': {
    usage: 'memory [forbidden|context [status|config|services]]', group: 'Config & policy', methods: ['memory.forbidden.get', 'personal_context.runtime.status'],
    async run({ g, rest }) {
      const what = (rest[0] || 'forbidden').toLowerCase()
      if (what === 'forbidden') {
        const r = await g.rpc('memory.forbidden.get', {})
        return `Jiuwen memory forbidden-list: ${r?.enabled ? 'enabled' : 'disabled'}; patterns: ${(r?.patterns || []).join(', ') || 'none'}`
      }
      if (what === 'context') {
        const sub = (rest[1] || 'status').toLowerCase()
        if (sub === 'config') {
          const r = maskSecrets(await g.rpc('personal_context.runtime.get_config', {}))
          return `Jiuwen personal context config: configured=${r?.configured}, collection=${r?.collection_enabled}, agent_use=${r?.agent_use_enabled}, model=${r?.model_id || '?'}, fetch_services=${(r?.fetch_services || []).length}`
        }
        if (sub === 'services') {
          const r = await g.rpc('personal_context.fetch.list_services', {})
          const s = r?.services || []
          return `Jiuwen personal context fetch services (${s.length}): ${s.map(x => x.name || x.id || x.service_id).join(', ') || 'none'}`
        }
        const r = await g.rpc('personal_context.runtime.status', {})
        return `Jiuwen personal context: state=${r?.state || '?'}, configured=${r?.configured}, collection=${r?.collection_enabled}, agent_use=${r?.agent_use_enabled}, pipeline_running=${r?.pipeline_running}, context_ready=${r?.context_ready}${r?.last_error ? `, last_error=${short(r.last_error, 80)}` : ''}`
      }
      return 'Usage: /jiuwen memory [forbidden|context [status|config|services]]'
    },
  },
  'cron get': {
    usage: 'cron get <id>', group: 'Schedules', methods: ['cron.job.get'],
    async run({ g, rest }) {
      if (!rest[1]) return 'Usage: /jiuwen cron get <id>'
      const r = await g.rpc('cron.job.get', { id: rest[1] })
      const job = maskSecrets(r?.job || r)
      return `Jiuwen cron job ${job?.id || rest[1]}: ${j(job, 900)}`
    },
  },
  'cron preview': {
    usage: 'cron preview <id>', group: 'Schedules', methods: ['cron.job.preview'],
    async run({ g, rest }) {
      if (!rest[1]) return 'Usage: /jiuwen cron preview <id>'
      const r = await g.rpc('cron.job.preview', { id: rest[1] })
      const runs = r?.next || r?.next_runs || r?.runs || r?.items
      return `Jiuwen cron preview ${rest[1]}: ${Array.isArray(runs) ? runs.slice(0, 10).map(x => (typeof x === 'object' ? x.wake_at || x.at || x.time || j(x, 60) : x)).join(', ') : j(r, 600)}`
    },
  },
  'cron meta': {
    usage: 'cron meta', group: 'Schedules', methods: ['cron.job.meta'],
    async run({ g }) {
      const r = await g.rpc('cron.job.meta', {})
      return `Jiuwen cron meta: default_mode=${r?.default_mode || '?'}, default_timeout=${r?.default_timeout_seconds ?? '?'}s, modes: ${(r?.modes || []).join(', ')}`
    },
  },
  'heartbeat job': {
    usage: 'heartbeat job <id>', group: 'Schedules', methods: ['heartbeat.job.get'],
    async run({ g, sid, rest }) {
      if (!rest[1]) return 'Usage: /jiuwen heartbeat job <id>'
      const r = await g.rpc('heartbeat.job.get', { id: rest[1], session_id: sid })
      return `Jiuwen heartbeat job ${rest[1]}: ${j(maskSecrets(r?.job || r), 900)}`
    },
  },
  'heartbeat preview': {
    usage: 'heartbeat preview <id>', group: 'Schedules', methods: ['heartbeat.job.preview'],
    async run({ g, sid, rest }) {
      if (!rest[1]) return 'Usage: /jiuwen heartbeat preview <id>'
      return `Jiuwen heartbeat preview ${rest[1]}: ${j(await g.rpc('heartbeat.job.preview', { id: rest[1], session_id: sid }), 700)}`
    },
  },
  'heartbeat meta': {
    usage: 'heartbeat meta', group: 'Schedules', methods: ['heartbeat.job.meta'],
    async run({ g }) {
      const r = await g.rpc('heartbeat.job.meta', {})
      const l = r?.limits || {}
      return `Jiuwen heartbeat meta: min_interval=${l.min_interval_seconds ?? '?'}s, max_active/session=${l.max_active_jobs_per_session ?? '?'}, schedule_types=${(r?.schedule_types || []).join('/')}, concurrency=${(r?.concurrency_policies || []).join('/')}`
    },
  },
  'schedule': {
    usage: 'schedule [list|status|logs|check|create|run|cancel]', group: 'Schedules', methods: ['schedule.list'],
    async run({ g, rest, sid, tokens }) {
      const a = (rest[0] || 'list').toLowerCase()
      const method = { list: 'schedule.list', status: 'schedule.status', logs: 'schedule.logs', check: 'schedule.check_config', create: 'schedule.create', run: 'schedule.run', cancel: 'schedule.cancel' }[a]
      if (!method) return 'Usage: /jiuwen schedule [list|status|logs|check|create key=value…|run <id>|cancel <id>]'
      const params = { session_id: sid }
      if (a === 'create') Object.assign(params, kv(tokens.slice(1)))
      if (a === 'run' || a === 'cancel') { if (!rest[1]) return `Usage: /jiuwen schedule ${a} <id>`; params.id = rest[1] }
      return `Jiuwen schedule ${a}: ${j(await g.rpc(method, params), 900)}`
    },
  },
  'team': {
    usage: 'team [history|snapshot]', group: 'Skills & agents', methods: ['team.history.get', 'team.snapshot'],
    async run({ g, rest, sid }) {
      const a = (rest[0] || 'snapshot').toLowerCase()
      if (a === 'history') {
        const r = await g.rpc('team.history.get', { session_id: sid })
        const recs = r?.records || []
        return recs.length
          ? `Jiuwen team history for ${sid} (${r?.total ?? recs.length}):\n${recs.slice(-15).map((x, i) => `${i + 1}. ${teamRecordLine(x)}`).join('\n')}`
          : `No team history for session ${sid}`
      }
      if (a === 'snapshot') {
        const r = await g.rpc('team.snapshot', { session_id: sid })
        return `Jiuwen team snapshot for ${sid}: team=${r?.team_id || 'none'}, members=${(r?.members || []).length}, tasks=${(r?.tasks || []).length}${(r?.members || []).length ? `\nmembers: ${(r.members).map(m => m.name || m.member_id || m.id).join(', ')}` : ''}`
      }
      return 'Usage: /jiuwen team [history|snapshot]'
    },
  },
  'template': {
    usage: 'template show <id>', group: 'Skills & agents', methods: ['agent_templates.show'],
    async run({ g, rest }) {
      if ((rest[0] || '').toLowerCase() !== 'show' || !rest[1]) return 'Usage: /jiuwen template show <id|packageName> (see /jiuwen templates)'
      let id = rest[1]
      if (!/^[0-9a-f]{16,}$/i.test(id)) {
        const l = await g.rpc('agent_templates.list', {}).catch(() => null)
        const hit = (l?.templates || []).find(t => [t.id, t.packageName, label(t.displayName)].includes(id))
        if (hit?.id) id = hit.id
      }
      const r = await g.rpc('agent_templates.show', { id })
      const t = r?.template || r || {}
      return `Jiuwen agent template ${label(t.displayName) || t.packageName || id} (${t.id || id}): ${short(label(t.displayDescription), 200) || '(no description)'}${t.category ? `\ncategory: ${t.category}` : ''}${t.installed !== undefined ? `\ninstalled: ${t.installed}` : ''}`
    },
  },
  'group': {
    usage: 'group [list|show <id>]', group: 'Skills & agents', methods: ['agent_groups.list'],
    async run({ g, rest }) {
      const a = (rest[0] || 'list').toLowerCase()
      if (a === 'show') {
        if (!rest[1]) return 'Usage: /jiuwen group show <id>'
        const r = await g.rpc('agent_groups.show', { id: rest[1] })
        const gr = r?.group || r || {}
        const members = Array.isArray(gr.members) ? gr.members : []
        return `Jiuwen agent group ${gr.id || rest[1]} (${label(gr.displayName) || gr.name || ''}): ${short(label(gr.displayDescription), 160)}${members.length ? `\nmembers (${members.length}): ${members.map(m => label(m.displayName) || m.id).join(', ')}` : ''}`
      }
      if (a !== 'list') return 'Usage: /jiuwen group [list|show <id>]'
      const r = await g.rpc('agent_groups.list', {})
      const list = r?.agentGroups || r?.groups || []
      return `Jiuwen agent groups (${list.length}): ${list.map(x => `${x.id}${x.installed === false ? ' (not installed)' : ''}`).join(', ') || 'none'}`
    },
  },
  'git': {
    usage: 'git [status|diff|probe|turns|turn <id>] [project_id]', group: 'Config & policy', methods: ['project.git.status', 'project.git.probe', 'project.git.turn_diff_list', 'project.git.turn_diff'],
    async run({ g, rest }) {
      const a = (rest[0] || 'status').toLowerCase()
      if (!['status', 'diff', 'probe', 'turns', 'turn'].includes(a)) return 'Usage: /jiuwen git [status|diff|probe|turns|turn <id>] [project_id]'
      const pid = await resolveProjectId(g, a === 'turn' ? rest[2] : rest[1])
      const call = async (method, params) => {
        try { return await g.rpc(method, params) }
        catch (e) {
          const msg = String(e?.message || e)
          if (softGitMsg(msg)) return { __soft: true, message: msg }
          throw e
        }
      }
      if (a === 'probe') {
        const r = await call('project.git.probe', { project_id: pid })
        if (r?.__soft) return `Jiuwen git probe (${pid}): soft-failed — git disabled or unavailable (${short(r.message, 120)}).`
        return `Jiuwen git probe (${pid}): ${r?.enabled === false ? 'disabled' : 'ok'}${r?.repo_root ? `, root=${r.repo_root}` : ''}${r?.status ? `, status=${r.status}` : ''}${r?.hint ? ` — ${short(r.hint, 120)}` : (r && !r.__soft ? `: ${j(r, 400)}` : '')}`
      }
      if (a === 'turns') {
        const r = await call('project.git.turn_diff_list', { project_id: pid })
        if (r?.__soft) return `Jiuwen git turns (${pid}): soft-failed — git disabled or unavailable (${short(r.message, 120)}).`
        const turns = r?.turns || r?.items || r?.diffs || []
        return Array.isArray(turns) && turns.length
          ? `Jiuwen git turn diffs (${pid}, ${turns.length}):
${turns.slice(0, 15).map(t => `- ${t.turn_id || t.id || '?'}: ${(t.files || t.changed_files || []).length || t.file_count || '?'} files${t.summary ? ` — ${short(t.summary, 60)}` : ''}`).join('\n')}`
          : `Jiuwen git turn diffs (${pid}): none${r ? ` — ${j(r, 300)}` : ''}`
      }
      if (a === 'turn') {
        const tid = rest[1]
        if (!tid) return 'Usage: /jiuwen git turn <turn_id> [project_id]'
        const r = await call('project.git.turn_diff', { project_id: pid, turn_id: tid })
        if (r?.__soft) return `Jiuwen git turn ${tid} (${pid}): soft-failed — git disabled or unavailable (${short(r.message, 120)}).`
        const files = r?.files || r?.changes || []
        return `Jiuwen git turn ${tid} (${pid}): ${Array.isArray(files) && files.length ? files.slice(0, 30).map(f => `${f.status || '?'} ${f.path || f.file || j(f, 60)}`).join(', ') : j(r, 600)}`
      }
      const r = await call(a === 'diff' ? 'project.git.diff_status' : 'project.git.status', { project_id: pid })
      if (r?.__soft) return `Jiuwen git ${a} (${pid}): soft-failed — git disabled or unavailable (${short(r.message, 120)}).`
      if (a === 'diff') {
        const files = r?.files || r?.changes || []
        return `Jiuwen git diff (${pid}): ${Array.isArray(files) && files.length ? files.slice(0, 30).map(f => `${f.status || '?'} ${f.path || f.file || j(f, 60)}`).join(', ') : j(r, 600)}`
      }
      return `Jiuwen git status (${pid}): branch=${r?.branch || '?'}${r?.is_dirty !== undefined ? `, dirty=${r.is_dirty}` : ''}${r?.repo_root ? `, root=${r.repo_root}` : ''}${r?.ahead != null ? `, ahead=${r.ahead}` : ''}${r?.behind != null ? `, behind=${r.behind}` : ''}`
    },
  },
  'models validate': {
    usage: 'models validate [model_provider=.. api_base=.. model=..]', group: 'Models & mode', methods: ['models.validate'],
    async run({ g, tokens }) {
      // Never takes or prints API keys: the Gateway uses its own stored credentials when it can.
      const p = kv(tokens.slice(1))
      if (Object.keys(p).some(k => SECRET_KEY.test(k))) return 'Refusing to pass credentials through a slash command; configure keys in Jiuwen itself.'
      const cfg = await g.rpc('config.get', {}).catch(() => ({}))
      const params = { model_provider: p.model_provider || cfg?.model_provider, api_base: p.api_base || cfg?.api_base, model: p.model || cfg?.model }
      const r = await g.rpc('models.validate', params)
      return `Jiuwen models.validate ${params.model || '?'}: ${r?.ok === false || r?.valid === false ? 'FAILED' : 'ok'}${r?.message || r?.error ? ` — ${short(r.message || r.error, 200)}` : ''}`
    },
  },
  'permissions overrides': {
    usage: 'permissions overrides', group: 'Config & policy', methods: ['permissions.approval_overrides.get'],
    async run({ g }) {
      const r = await g.rpc('permissions.approval_overrides.get', {})
      const o = r?.approval_overrides || []
      return `Jiuwen approval overrides (${o.length}): ${o.map(x => `${x.id}${x.tool ? `:${x.tool}` : ''}`).join(', ') || 'none'}`
    },
  },
  'permissions scopes': {
    usage: 'permissions scopes', group: 'Config & policy', methods: ['permissions.owner_scopes.get'],
    async run({ g }) {
      const r = await g.rpc('permissions.owner_scopes.get', {})
      return `Jiuwen owner scopes: ${r?.owner_scopes == null ? 'none' : j(maskSecrets(r.owner_scopes), 500)}${r?.deny_guidance_message ? `\ndeny guidance: ${short(r.deny_guidance_message, 200)}` : ''}`
    },
  },
  'document': {
    usage: 'document formats', group: 'System', methods: ['document.formats'],
    async run({ g, rest }) {
      if ((rest[0] || 'formats') !== 'formats') return 'Usage: /jiuwen document formats (persist a file with /jiuwen doc persist <absolute host path>)'
      const r = await g.rpc('document.formats', {})
      return `Jiuwen forbidden document formats (${(r?.forbidden_formats || []).length}): ${(r?.forbidden_formats || []).join(' ')}`
    },
  },


  // ── Round 4 read-only / soft-fail reversible ──
  'skills files': {
    usage: 'skills files <name> [path]', group: 'Skills & agents', methods: ['skills.files.list', 'skills.files.get'],
    async run({ g, rest }) {
      const name = rest[1]
      if (!name) return 'Usage: /jiuwen skills files <name> [path]'
      if (rest[2]) {
        const path = rest.slice(2).join(' ')
        const r = await g.rpc('skills.files.get', { name, path })
        const body = r?.preview || r?.content || r?.text
        return `Jiuwen skill file ${name}:${path}${r?.mime_type ? ` (${r.mime_type})` : ''}${r?.size != null ? `, ${r.size}b` : ''}:\n${body != null ? String(body).slice(0, 1500) : j(maskSecrets(r), 800)}`
      }
      const r = await g.rpc('skills.files.list', { name })
      const files = r?.files || []
      return `Jiuwen skill files ${r?.name || name} (${files.length}):\n${fileLines(files).join('\n') || 'none'}`
    },
  },
  'skills retrieval': {
    usage: 'skills retrieval [status|tree]', group: 'Skills & agents', methods: ['skills.retrieval.status', 'skills.retrieval.tree'],
    async run({ g, rest }) {
      const a = (rest[1] || 'status').toLowerCase()
      if (a === 'tree') {
        const r = await g.rpc('skills.retrieval.tree', {})
        if (r?.unsupported || r?.tree_supported === false) return `Jiuwen skill retrieval tree: unsupported on this Gateway (${short(r?.detail, 160) || 'use skills list / search'}).`
        const nodes = r?.nodes || r?.tree || []
        return `Jiuwen skill retrieval tree (${nodes.length} top):\n${flattenTree(nodes).slice(0, 40).join('\n') || j(r, 600)}`
      }
      if (a !== 'status') return 'Usage: /jiuwen skills retrieval [status|tree]'
      const r = await g.rpc('skills.retrieval.status', {})
      return `Jiuwen skill retrieval: enabled=${r?.enabled}, index=${r?.index_enabled}, mode=${r?.mode || '?'}, strategy=${r?.effective_strategy || '?'}, candidates=${r?.candidate_scale || '?'} (~${r?.estimated_candidate_tokens ?? '?'} / budget ${r?.candidate_budget_tokens ?? '?'} tok)`
    },
  },
  'skills graph': {
    usage: 'skills graph [status|get]', group: 'Skills & agents', methods: ['skills.graph.status', 'skills.graph.get'],
    async run({ g, rest }) {
      const a = (rest[1] || 'status').toLowerCase()
      if (a === 'get') {
        const r = await g.rpc('skills.graph.get', {})
        if (r?.success === false) return `Jiuwen skill graph: not ready — ${short(r?.detail || r?.error, 200)}`
        return `Jiuwen skill graph: ${j(maskSecrets(r), 900)}`
      }
      if (a !== 'status') return 'Usage: /jiuwen skills graph [status|get]'
      const r = await g.rpc('skills.graph.status', {})
      return `Jiuwen skill graph status: exists=${r?.exists}, stale=${r?.stale}, skills=${r?.skill_count ?? '?'}, added=${r?.added_count ?? '?'}, removed=${r?.removed_count ?? '?'}${r?.graph_dir ? `, dir=${r.graph_dir}` : ''}`
    },
  },
  'skills evolution': {
    usage: 'skills evolution <name> [status|get]', group: 'Skills & agents', methods: ['skills.evolution.status', 'skills.evolution.get'],
    async run({ g, rest }) {
      const name = rest[1]
      if (!name) return 'Usage: /jiuwen skills evolution <name> [status|get]'
      const a = (rest[2] || 'status').toLowerCase()
      if (a === 'get') {
        const r = await g.rpc('skills.evolution.get', { name })
        return `Jiuwen skill evolution ${r?.name || name}: exists=${r?.exists}, valid=${r?.valid}, version=${r?.version || '?'}, entries=${(r?.entries || []).length}`
      }
      if (a !== 'status') return 'Usage: /jiuwen skills evolution <name> [status|get]'
      const r = await g.rpc('skills.evolution.status', { name })
      return `Jiuwen skill evolution status ${r?.name || name}: exists=${r?.exists}${r?.updated_at ? `, updated=${r.updated_at}` : ''}`
    },
  },
  'skills experience': {
    usage: 'skills experience', group: 'Skills & agents', methods: ['skills.experience.list'],
    async run({ g }) {
      const r = await g.rpc('skills.experience.list', {})
      const c = r?.candidates || r?.items || r?.experiences || []
      return `Jiuwen skill experience: enabled=${r?.enabled}, candidates=${c.length}${c.length ? `:\n${c.slice(0, 10).map(x => `- ${x.name || x.id || j(x, 80)}`).join('\n')}` : ''}`
    },
  },
  'template files': {
    usage: 'template files <id> [path]', group: 'Skills & agents', methods: ['agent_templates.file.list', 'agent_templates.file.read'],
    async run({ g, rest }) {
      let id = rest[1]
      if (!id) return 'Usage: /jiuwen template files <id|packageName> [path]'
      if (!/^[0-9a-f]{16,}$/i.test(id)) {
        const l = await g.rpc('agent_templates.list', {}).catch(() => null)
        const hit = (l?.templates || []).find(t => [t.id, t.packageName, label(t.displayName)].includes(id))
        if (hit?.id) id = hit.id
      }
      if (rest[2]) {
        const path = rest.slice(2).join(' ')
        const r = await g.rpc('agent_templates.file.read', { id, path })
        const body = r?.preview || r?.content || r?.text
        return `Jiuwen template file ${id}:${path}:\n${body != null ? String(body).slice(0, 1500) : j(maskSecrets(r), 800)}`
      }
      const r = await g.rpc('agent_templates.file.list', { id })
      const tree = r?.tree || r?.files || []
      const lines = Array.isArray(tree) && tree[0]?.children !== undefined ? flattenTree(tree) : fileLines(tree)
      return `Jiuwen template files ${id} (${lines.length}):\n${lines.slice(0, 40).join('\n') || 'none'}`
    },
  },
  'group files': {
    usage: 'group files <id> [path]', group: 'Skills & agents', methods: ['agent_groups.file.list', 'agent_groups.file.read'],
    async run({ g, rest }) {
      const id = rest[1]
      if (!id) return 'Usage: /jiuwen group files <id> [path]'
      if (rest[2]) {
        const path = rest.slice(2).join(' ')
        const r = await g.rpc('agent_groups.file.read', { id, path })
        const body = r?.preview || r?.content || r?.text
        return `Jiuwen group file ${id}:${path}:\n${body != null ? String(body).slice(0, 1500) : j(maskSecrets(r), 800)}`
      }
      const r = await g.rpc('agent_groups.file.list', { id })
      const tree = r?.tree || r?.files || []
      const lines = Array.isArray(tree) && tree[0]?.children !== undefined ? flattenTree(tree) : fileLines(tree)
      return `Jiuwen group files ${id} (${lines.length}):\n${lines.slice(0, 40).join('\n') || 'none'}`
    },
  },
  'packages': {
    usage: 'packages [list|show <id|name>]', group: 'System', methods: ['plugin_packages.list', 'plugin_packages.show'],
    async run({ g, rest }) {
      const a = (rest[0] || 'list').toLowerCase()
      if (a === 'show') {
        if (!rest[1]) return 'Usage: /jiuwen packages show <id|packageName>'
        let id = rest[1]
        if (!/^[0-9a-f]{16,}$/i.test(id)) {
          const l = await g.rpc('plugin_packages.list', {}).catch(() => null)
          const hit = (l?.packages || []).find(p => [p.id, p.packageName, label(p.displayName)].includes(id))
          if (hit?.id) id = hit.id
        }
        const r = await g.rpc('plugin_packages.show', { id })
        const p = r?.package || r || {}
        return `Jiuwen plugin package ${label(p.displayName) || p.packageName || id} (${p.id || id}): ${short(label(p.displayDescription), 200) || '(no description)'}${p.installed !== undefined ? `\ninstalled: ${p.installed}` : ''}`
      }
      if (a !== 'list') return 'Usage: /jiuwen packages [list|show <id|name>]'
      const r = await g.rpc('plugin_packages.list', {})
      const list = r?.packages || []
      return `Jiuwen plugin packages (${list.length}): ${list.slice(0, 20).map(p => `${p.packageName || label(p.displayName) || p.id}${p.installed === false ? ' (not installed)' : ''}`).join(', ') || 'none'}`
    },
  },
  'extensions': {
    usage: 'extensions', group: 'System', methods: ['extensions.list'],
    async run({ g }) {
      const r = await g.rpc('extensions.list', {})
      const list = r?.extensions || r?.items || []
      return `Jiuwen extensions (${list.length}): ${list.map(x => x.name || x.id || j(x, 40)).join(', ') || 'none'}`
    },
  },
  'vendors': {
    usage: 'vendors [list|models <vendor_key> <plan>]', group: 'Models & mode', methods: ['vendors.list', 'vendors.fetch_models'],
    async run({ g, rest, tokens }) {
      const a = (rest[0] || 'list').toLowerCase()
      if (a === 'models') {
        const vendor_key = rest[1]
        const plan = rest[2]
        if (!vendor_key || !plan) return 'Usage: /jiuwen vendors models <vendor_key> <plan>  (plan: token_plan|coding_plan|custom_api; never passes api_key — Gateway falls back to preset)'
        if (Object.keys(kv(tokens.slice(1))).some(k => SECRET_KEY.test(k))) return 'Refusing to pass credentials through a slash command; configure keys in Jiuwen itself.'
        const r = await g.rpc('vendors.fetch_models', { vendor_key, plan })
        const models = r?.models || []
        return `Jiuwen vendor models ${vendor_key}/${plan} (source=${r?.source || 'remote'}${r?.reason ? `, ${short(r.reason, 80)}` : ''}): ${models.slice(0, 20).join(', ') || 'none'}${models.length > 20 ? ` …+${models.length - 20}` : ''}`
      }
      if (a !== 'list') return 'Usage: /jiuwen vendors [list|models <vendor_key> <plan>]'
      const r = await g.rpc('vendors.list', {})
      const vendors = r?.vendors || r || {}
      const keys = typeof vendors === 'object' && !Array.isArray(vendors) ? Object.keys(vendors) : (Array.isArray(vendors) ? vendors.map(v => v.key || v.name || v.id) : [])
      return `Jiuwen vendors (${keys.length} groups): ${keys.slice(0, 30).join(', ') || j(maskSecrets(r), 500)}`
    },
  },
  'openai': {
    usage: 'openai [auth|models]', group: 'Models & mode', methods: ['openai_account.auth.status', 'openai_account.models.list'],
    async run({ g, rest }) {
      const a = (rest[0] || 'auth').toLowerCase()
      if (a === 'models') {
        const r = maskSecrets(await g.rpc('openai_account.models.list', {}))
        const models = r?.models || []
        return `Jiuwen OpenAI-account models (${models.length}${r?.auth?.authenticated === false ? ', not authenticated' : ''}): ${models.slice(0, 15).join(', ') || 'none'}`
      }
      if (!['auth', 'status'].includes(a)) return 'Usage: /jiuwen openai [auth|models]'
      const r = maskSecrets(await g.rpc('openai_account.auth.status', {}))
      return `Jiuwen OpenAI-account auth: authenticated=${r?.authenticated}, has_refresh=${r?.has_refresh_token}, needs_refresh=${r?.needs_refresh}${r?.error ? `, error=${short(r.error, 80)}` : ''}${r?.base_url ? `\nbase: ${r.base_url}` : ''}`
    },
  },
  'health': {
    usage: 'health', group: 'System', methods: ['health_check.get_conf'],
    async run({ g }) {
      const r = await g.rpc('health_check.get_conf', {})
      const ah = r?.active_hours || {}
      return `Jiuwen health_check: every=${r?.every ?? '?'}s, target=${r?.target || '?'}, active_hours=${ah.start || '?'}-${ah.end || '?'}`
    },
  },
  'projects pinned': {
    usage: 'projects pinned [project_id]', group: 'Config & policy', methods: ['project.pinned_sessions'],
    async run({ g, rest }) {
      const pid = await resolveProjectId(g, rest[1])
      const r = await g.rpc('project.pinned_sessions', { project_id: pid })
      const list = r?.sessions || []
      return list.length
        ? `Jiuwen pinned sessions (${pid}, ${list.length}):\n${list.slice(0, 15).map(s => `- ${s.session_id || s.id}${s.title ? `  ${short(s.title, 40)}` : ''}`).join('\n')}`
        : `No pinned sessions for project ${pid}`
    },
  },
  'projects cron': {
    usage: 'projects cron [project_id]', group: 'Config & policy', methods: ['project.get_cron_sessions'],
    async run({ g, rest }) {
      const pid = await resolveProjectId(g, rest[1])
      const r = await g.rpc('project.get_cron_sessions', { project_id: pid })
      const list = r?.sessions || []
      return list.length
        ? `Jiuwen cron sessions (${pid}, ${r?.total ?? list.length}):\n${list.slice(0, 15).map(s => `- ${s.session_id || s.id}${s.cron_id ? ` cron=${s.cron_id}` : ''}${s.title ? `  ${short(s.title, 40)}` : ''}`).join('\n')}`
        : `No cron-triggered sessions for project ${pid}`
    },
  },
  'publish': {
    usage: 'publish [describe|status|records|local] kind=<skill|agent_template|agent_group|plugin|mcp> local_id=<id>', group: 'System', methods: ['assets.publish.describe', 'assets.publish.status', 'assets.publish.records', 'assets.publish.local_status'],
    async run({ g, rest, tokens }) {
      const a = (rest[0] || 'describe').toLowerCase()
      const method = { describe: 'assets.publish.describe', status: 'assets.publish.status', records: 'assets.publish.records', local: 'assets.publish.local_status', local_status: 'assets.publish.local_status' }[a]
      if (!method) return 'Usage: /jiuwen publish [describe|status|records|local] kind=<kind> local_id=<id>  (read-only; Hub auth soft-fails)'
      const p = kv(tokens.slice(1))
      if (Object.keys(p).some(k => SECRET_KEY.test(k)) || p.auth) return 'Refusing to pass Hub credentials through a slash command.'
      if (!p.kind || !p.local_id) return 'Usage: /jiuwen publish [describe|status|records|local] kind=<skill|agent_template|agent_group|plugin|mcp> local_id=<id>'
      try {
        const r = maskSecrets(await g.rpc(method, { kind: p.kind, local_id: p.local_id }))
        return `Jiuwen assets.publish ${a} ${p.kind}/${p.local_id}: ${j(r, 900)}`
      } catch (e) {
        const msg = String(e?.message || e)
        if (/AUTH_REQUIRED|RESOURCE_NOT_FOUND|INVALID_KIND|INVALID_PARAMETERS/i.test(msg)) {
          return `Jiuwen assets.publish ${a} ${p.kind}/${p.local_id}: soft-failed — ${short(msg, 160)} (read-only Hub publish; sign in via Jiuwen UI if needed).`
        }
        throw e
      }
    },
  },
  'mcp cancel': {
    usage: 'mcp cancel <name>', group: 'System', methods: ['mcp.cancel_connect'],
    async run({ g, rest }) {
      const name = rest[1]
      if (!name) return 'Usage: /jiuwen mcp cancel <name>  (abort in-flight mcp.connect / wait_auth; idempotent)'
      const r = await g.rpc('mcp.cancel_connect', { name })
      return `Jiuwen mcp.cancel_connect ${name}: ${j(r, 400)}`
    },
  },


  // ── Round 5 reads / reversible toggles ──
  'channels': {
    usage: 'channels [conf <name>]', group: 'System', methods: ['channel.get'],
    async run({ g, rest }) {
      const a = (rest[0] || 'list').toLowerCase()
      const NAMES = ['dingtalk', 'discord', 'feishu', 'slack', 'telegram', 'wechat', 'wecom', 'whatsapp', 'xiaoyi']
      if (a === 'conf') {
        const name = String(rest[1] || '').toLowerCase()
        if (!NAMES.includes(name)) return `Usage: /jiuwen channels conf <${NAMES.join('|')}> (secrets masked)`
        const r = maskSecrets(await g.rpc(`channel.${name}.get_conf`, {}))
        return `Jiuwen channel ${name} conf (secrets masked): ${j(r?.config ?? r, 1200)}`
      }
      if (a !== 'list') return 'Usage: /jiuwen channels [conf <name>]'
      const r = await g.rpc('channel.get', {})
      const list = r?.channels || []
      return `Jiuwen channels (${list.length}): ${list.map(c => c.channel_id || c.name || c.id).join(', ') || 'none'}`
    },
  },
  'rsi': {
    usage: 'rsi [tasks|task|report|tree|usage|files <task_id> [path]|versions]', group: 'System', methods: ['rsi.task.list'],
    async run({ g, rest }) {
      const a = (rest[0] || 'tasks').toLowerCase()
      if (a === 'tasks' || a === 'list') {
        const r = await g.rpc('rsi.task.list', {})
        const ts = r?.tasks || []
        return `Jiuwen RSI tasks (${ts.length}): ${ts.slice(0, 20).map(x => `${x.task_id || x.id}${x.status ? ` [${x.status}]` : ''}`).join(', ') || 'none'}`
      }
      if (a === 'versions') {
        const r = await g.rpc('rsi.harness.versions.list', {})
        return `Jiuwen RSI harness versions (${(r?.versions || []).length}; active=${r?.active_installation_id || 'none'}): ${(r?.versions || []).slice(0, 15).map(v => v.version || v.installation_id || v.id).join(', ') || 'none'}`
      }
      const m = { task: 'rsi.task.get', report: 'rsi.report.get', tree: 'rsi.tree.get', usage: 'rsi.usage.get', files: 'rsi.artifact.files.list' }[a]
      const id = rest[1]
      if (!m || !id) return 'Usage: /jiuwen rsi [tasks|versions|task|report|tree|usage <task_id>|files <task_id> [path]]'
      if (a === 'files' && rest[2]) {
        const r = maskSecrets(await g.rpc('rsi.artifact.files.get', { task_id: id, path: rest.slice(2).join(' ') }))
        return `Jiuwen RSI artifact ${id}:${rest.slice(2).join(' ')}:\n${String(r?.preview ?? r?.content ?? j(r, 1200)).slice(0, 1500)}`
      }
      return `Jiuwen RSI ${a} ${id}: ${j(maskSecrets(await g.rpc(m, { task_id: id })), 1200)}`
    },
  },
  'context': {
    usage: 'context [search <q>|node <id>|source <id>|auth <provider>|runs]', group: 'Config & policy', methods: ['personal_context.context.search_pages'],
    async run({ g, rest }) {
      const a = (rest[0] || '').toLowerCase()
      const arg = rest.slice(1).join(' ')
      if (a === 'runs') {
        const r = await g.rpc('personal_context.fetch.get_run_status', {})
        const s = r?.services || []
        return `Jiuwen personal context fetch runs (${s.length}): ${s.map(x => `${x.service_id || x.name}${x.state ? `=${x.state}` : ''}`).join(', ') || 'none'}`
      }
      const m = { search: ['personal_context.context.search_pages', 'query'], node: ['personal_context.context.get_node', 'node_id'], source: ['personal_context.context.get_source', 'source_id'], auth: ['personal_context.fetch.get_authorization_status', 'provider'] }[a]
      if (!m || !arg) return 'Usage: /jiuwen context [search <query>|node <id>|source <id>|auth <provider>|runs] (personal context, read-only)'
      const r = maskSecrets(await g.rpc(m[0], { [m[1]]: arg }))
      if (a === 'search') {
        const res = r?.results || []
        return `Jiuwen personal context search "${arg}" (${res.length}): ${res.slice(0, 10).map(x => x.title || x.node_id || x.id || j(x, 60)).join('; ') || 'none'}`
      }
      return `Jiuwen personal context ${a} ${arg}: ${j(r, 1200)}`
    },
  },
  'issues': {
    usage: 'issues [matrix|states]', group: 'System', methods: ['issue.matrix', 'issue.state.list'],
    async run({ g, rest }) {
      const a = (rest[0] || 'states').toLowerCase()
      const m = { matrix: 'issue.matrix', states: 'issue.state.list', state: 'issue.state.list' }[a]
      if (!m) return 'Usage: /jiuwen issues [matrix|states]'
      return `Jiuwen ${m}: ${j(maskSecrets(await g.rpc(m, {})), 900)}`
    },
  },
  'harness': {
    usage: 'harness packages', group: 'System', methods: ['harness.packages'],
    async run({ g, rest }) {
      if ((rest[0] || 'packages').toLowerCase() !== 'packages') return 'Usage: /jiuwen harness packages (read-only)'
      const r = maskSecrets(await g.rpc('harness.packages', {}))
      if (r?.error) return `Jiuwen harness packages: soft-failed — ${short(r.error, 200)}`
      const ps = r?.packages || r?.items || []
      return `Jiuwen harness packages (${ps.length}): ${ps.slice(0, 20).map(x => x.name || x.id || j(x, 40)).join(', ') || 'none'}`
    },
  },
  'skills hub': {
    usage: 'skills hub <team|team-info|swarm <asset_id>|recommend <asset_id>|skillnet|clawhub> [query]', group: 'Skills & agents', methods: ['skills.teamskillshub.search', 'skills.teamskillshub.info', 'skills.swarmskillshub.detail', 'skills.swarmskillshub.recommend', 'skills.skillnet.search', 'skills.clawhub.search'],
    async run({ g, rest }) {
      const which = (rest[1] || '').toLowerCase()
      const q = rest.slice(2).join(' ')
      const soft = r => (r?.success === false ? `soft-failed — ${short(r.detail || r.error || r.code, 160)}` : null)
      if (which === 'team-info') {
        const r = await g.rpc('skills.teamskillshub.info', {})
        return `Jiuwen TeamSkillsHub: packages=${(r?.packages || []).length}, active=${(r?.active_package_ids || []).join(', ') || 'none'}${r?.native_version ? `, native=${r.native_version.extension_name || r.native_version.id}` : ''}`
      }
      const spec = {
        team: ['skills.teamskillshub.search', { query: q, q }, r => r?.issues || r?.items || r?.results],
        swarm: ['skills.swarmskillshub.detail', { asset_id: q }, null],
        recommend: ['skills.swarmskillshub.recommend', { asset_id: q }, r => r?.items || r?.recommendations],
        skillnet: ['skills.skillnet.search', { q, query: q }, r => r?.items || r?.results || r?.skills],
        clawhub: ['skills.clawhub.search', { q, query: q }, r => r?.items || r?.results || r?.skills],
      }[which]
      if (!spec || (!q && which !== 'team')) return 'Usage: /jiuwen skills hub <team [query]|team-info|swarm <asset_id>|recommend <asset_id>|skillnet <query>|clawhub <query>> (read-only; nothing installed)'
      const r = maskSecrets(await g.rpc(spec[0], spec[1]))
      const s = soft(r); if (s) return `Jiuwen skills hub ${which}: ${s}`
      const items = spec[2] ? spec[2](r) : null
      if (Array.isArray(items)) return `Jiuwen skills hub ${which}${q ? ` "${q}"` : ''} (${items.length}; read-only): ${items.slice(0, 10).map(x => x.name || x.title || x.id || j(x, 60)).join('; ') || 'none'}`
      return `Jiuwen skills hub ${which} ${q}: ${j(r, 900)}`
    },
  },
  'marketplace': {
    usage: 'marketplace toggle <name> <on|off>', group: 'Skills & agents', methods: ['skills.marketplace.toggle'],
    async run({ g, rest }) {
      const enabled = onOff(rest[2])
      if ((rest[0] || '').toLowerCase() !== 'toggle' || !rest[1] || enabled === undefined) return 'Usage: /jiuwen marketplace toggle <name> <on|off> (see /jiuwen marketplaces)'
      const r = await g.rpc('skills.marketplace.toggle', { name: rest[1], enabled })
      return `Jiuwen skill marketplace ${rest[1]} ${(r?.enabled ?? r?.marketplace?.enabled ?? enabled) ? 'enabled' : 'disabled'}.`
    },
  },
  'extensions toggle': {
    usage: 'extensions toggle <name> <on|off>', group: 'System', methods: ['extensions.toggle'],
    async run({ g, rest }) {
      const enabled = onOff(rest[2])
      if (!rest[1] || enabled === undefined) return 'Usage: /jiuwen extensions toggle <name> <on|off>'
      const r = await g.rpc('extensions.toggle', { name: rest[1], enabled })
      return `Jiuwen extension ${rest[1]} ${(r?.enabled ?? enabled) ? 'enabled' : 'disabled'}.`
    },
  },
  'projects rename': {
    usage: 'projects rename <project_id> <name>', group: 'Config & policy', methods: ['project.rename'],
    async run({ g, rest }) {
      const pid = rest[1]; const name = rest.slice(2).join(' ')
      if (!pid || !name) return 'Usage: /jiuwen projects rename <project_id> <new name>'
      const r = await g.rpc('project.rename', { project_id: pid, name })
      return `Renamed Jiuwen project ${pid} → ${r?.project?.name || r?.name || name}.`
    },
  },
  'projects pin': {
    usage: 'projects pin <project_id> [on|off]', group: 'Config & policy', methods: ['project.pin'],
    async run({ g, rest }) {
      const pid = rest[1]; const pinned = rest[2] === undefined ? true : onOff(rest[2])
      if (!pid || pinned === undefined) return 'Usage: /jiuwen projects pin <project_id> [on|off]'
      const r = await g.rpc('project.pin', { project_id: pid, pinned })
      return `Jiuwen project ${pid} ${(r?.project?.pinned ?? r?.pinned ?? pinned) ? 'pinned' : 'unpinned'}.`
    },
  },
  // ── P2 safe writes (reversible; deletes need `confirm`) ──
  'cron create': {
    usage: 'cron create name=<n> expr="<m h dom mon dow>" [desc=..] [tz=..] [target=web] [mode=agent] [enabled=off]', group: 'Schedules', methods: ['cron.job.create'],
    async run({ g, tokens, sid }) {
      const p = kv(tokens.slice(1))
      const expr = normalizeCronExpr(p.expr || p.cron_expr)
      if (!p.name || !expr) return 'Usage: /jiuwen cron create name=<name> expr="*/30 * * * *" [desc=<text>] [tz=Asia/Shanghai] [target=web] [mode=agent] [enabled=off]'
      const enabled = onOff(p.enabled) ?? false // created disabled unless asked: nothing runs by surprise
      const params = {
        name: p.name, cron_expr: expr, description: p.desc || p.description || p.name,
        timezone: p.tz || p.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
        targets: p.target || p.targets || 'web', enabled, session_id: sid, ...(p.mode ? { mode: p.mode } : {}),
      }
      const r = await g.rpc('cron.job.create', params)
      const job = r?.job || r || {}
      return `Created Jiuwen cron job ${job.id || '?'} "${job.name || p.name}" (${job.cron_expr || expr}, ${job.timezone || params.timezone}) ${job.enabled ?? enabled ? 'enabled' : 'disabled'}. Remove with /jiuwen cron delete ${job.id || '<id>'} confirm`
    },
  },

  'cron update': {
    usage: 'cron update <id> key=value…', group: 'Schedules', methods: ['cron.job.update'],
    async run({ g, rest, tokens }) {
      const id = rest[1]
      const patch = kv(tokens.slice(2))
      if (!id || !Object.keys(patch).length) return 'Usage: /jiuwen cron update <id> name=<n> [expr="<cron>"] [desc=..] [tz=..] [target=web] [enabled=on|off]'
      if (patch.expr && !patch.cron_expr) { patch.cron_expr = patch.expr; delete patch.expr }
      if (patch.cron_expr) patch.cron_expr = normalizeCronExpr(patch.cron_expr)
      if (patch.desc && !patch.description) { patch.description = patch.desc; delete patch.desc }
      if (patch.tz && !patch.timezone) { patch.timezone = patch.tz; delete patch.tz }
      if (patch.target && !patch.targets) { patch.targets = patch.target; delete patch.target }
      const en = onOff(patch.enabled); if (en !== undefined) patch.enabled = en
      const r = await g.rpc('cron.job.update', { id, patch })
      const job = r?.job || r || {}
      return `Updated Jiuwen cron job ${id}: ${job.name || patch.name || ''} ${job.cron_expr || patch.cron_expr || ''} ${job.enabled === false ? 'disabled' : (job.enabled ? 'enabled' : '')}`.replace(/\s+/g, ' ').trim()
    },
  },
  'cron toggle': {
    usage: 'cron toggle <id> <on|off>', group: 'Schedules', methods: ['cron.job.toggle'],
    async run({ g, rest }) {
      const enabled = onOff(rest[2])
      if (!rest[1] || enabled === undefined) return 'Usage: /jiuwen cron toggle <id> <on|off>'
      const r = await g.rpc('cron.job.toggle', { id: rest[1], enabled })
      return `Jiuwen cron job ${rest[1]} ${(r?.job?.enabled ?? r?.enabled ?? enabled) ? 'enabled' : 'disabled'}.`
    },
  },
  'cron run': {
    usage: 'cron run <id>', group: 'Schedules', methods: ['cron.job.run_now'],
    async run({ g, rest }) {
      if (!rest[1]) return 'Usage: /jiuwen cron run <id>'
      const r = await g.rpc('cron.job.run_now', { id: rest[1] })
      return `Triggered Jiuwen cron job ${rest[1]} now${r?.run_id ? ` (run ${r.run_id})` : ''}.`
    },
  },
  'cron delete': {
    usage: 'cron delete <id> confirm', group: 'Schedules', methods: ['cron.job.delete'],
    async run({ g, rest, tokens }) {
      if (!rest[1] || rest[1] === 'confirm') return 'Usage: /jiuwen cron delete <id> confirm'
      const no = needConfirm(tokens.slice(2), `delete cron job ${rest[1]}`)
      if (no) return no
      await g.rpc('cron.job.delete', { id: rest[1] })
      return `Deleted Jiuwen cron job ${rest[1]}.`
    },
  },

  'heartbeat create': {
    usage: 'heartbeat create name=<n> prompt="<text>" [every=<seconds>] [enabled=off]', group: 'Schedules', methods: ['heartbeat.job.create'],
    async run({ g, tokens, sid }) {
      const p = kv(tokens.slice(1))
      if (!p.name || !p.prompt) return 'Usage: /jiuwen heartbeat create name=<name> prompt="<text>" [every=<seconds≥60>] [enabled=off]'
      const every = Number(p.every || p.interval_seconds || 3600)
      if (!Number.isFinite(every) || every < 60) return 'heartbeat create: every must be ≥ 60 seconds (Gateway min_interval_seconds)'
      const enabled = onOff(p.enabled) ?? false
      const params = {
        session_id: sid, name: p.name, prompt: p.prompt, enabled,
        schedule: { type: 'interval', interval_seconds: every },
      }
      const r = await g.rpc('heartbeat.job.create', params)
      const job = r?.job || r || {}
      return `Created Jiuwen heartbeat job ${job.id || '?'} "${job.name || p.name}" every ${every}s ${job.enabled ?? enabled ? 'enabled' : 'disabled'}. Remove with /jiuwen heartbeat delete ${job.id || '<id>'} confirm`
    },
  },

  'heartbeat update': {
    usage: 'heartbeat update <id> key=value…', group: 'Schedules', methods: ['heartbeat.job.update'],
    async run({ g, sid, rest, tokens }) {
      const id = rest[1]
      const patch = kv(tokens.slice(2))
      if (!id || !Object.keys(patch).length) return 'Usage: /jiuwen heartbeat update <id> name=<n> [prompt="<text>"] [every=<seconds>] [enabled=on|off]'
      if (patch.every || patch.interval_seconds) {
        const every = Number(patch.every || patch.interval_seconds)
        if (!Number.isFinite(every) || every < 60) return 'heartbeat update: every must be ≥ 60 seconds'
        patch.schedule = { type: 'interval', interval_seconds: every }
        delete patch.every; delete patch.interval_seconds
      }
      const en = onOff(patch.enabled); if (en !== undefined) patch.enabled = en
      const r = await g.rpc('heartbeat.job.update', { id, session_id: sid, patch })
      const job = r?.job || r || {}
      return `Updated Jiuwen heartbeat job ${id}: ${job.name || patch.name || ''} ${job.enabled === false ? 'disabled' : (job.enabled ? 'enabled' : '')}`.replace(/\s+/g, ' ').trim()
    },
  },
  'heartbeat toggle': {
    usage: 'heartbeat toggle <id> <on|off>', group: 'Schedules', methods: ['heartbeat.job.toggle'],
    async run({ g, sid, rest }) {
      const enabled = onOff(rest[2])
      if (!rest[1] || enabled === undefined) return 'Usage: /jiuwen heartbeat toggle <id> <on|off>'
      const r = await g.rpc('heartbeat.job.toggle', { id: rest[1], session_id: sid, enabled })
      return `Jiuwen heartbeat job ${rest[1]} ${(r?.job?.enabled ?? enabled) ? 'enabled' : 'disabled'}.`
    },
  },
  'heartbeat run': {
    usage: 'heartbeat run <id>', group: 'Schedules', methods: ['heartbeat.job.run_now'],
    async run({ g, sid, rest }) { if (!rest[1]) return 'Usage: /jiuwen heartbeat run <id>'; await g.rpc('heartbeat.job.run_now', { id: rest[1], session_id: sid }); return `Triggered Jiuwen heartbeat job ${rest[1]} now.` },
  },
  'heartbeat cancel': {
    usage: 'heartbeat cancel <id>', group: 'Schedules', methods: ['heartbeat.job.cancel'],
    async run({ g, sid, rest }) { if (!rest[1]) return 'Usage: /jiuwen heartbeat cancel <id>'; await g.rpc('heartbeat.job.cancel', { id: rest[1], session_id: sid }); return `Cancelled the running Jiuwen heartbeat job ${rest[1]}.` },
  },
  'heartbeat delete': {
    usage: 'heartbeat delete <id> confirm', group: 'Schedules', methods: ['heartbeat.job.delete'],
    async run({ g, sid, rest, tokens }) {
      if (!rest[1] || rest[1] === 'confirm') return 'Usage: /jiuwen heartbeat delete <id> confirm'
      const no = needConfirm(tokens.slice(2), `delete heartbeat job ${rest[1]}`)
      if (no) return no
      await g.rpc('heartbeat.job.delete', { id: rest[1], session_id: sid })
      return `Deleted Jiuwen heartbeat job ${rest[1]}.`
    },
  },
  'permissions rule': {
    usage: 'permissions rule add tools=a,b pattern=<p> action=<allow|ask|deny> [severity=..] [desc=..] | rule update <id> key=value… | rule delete <id> confirm', group: 'Config & policy', methods: ['permissions.rules.create'],
    async run({ g, rest, tokens }) {
      const a = (rest[1] || '').toLowerCase()
      const fields = (p) => {
        const o = {}
        if (p.tools) o.tools = String(p.tools).split(',').map(x => x.trim()).filter(Boolean)
        for (const k of ['pattern', 'action', 'severity', 'match_type']) if (p[k] !== undefined) o[k] = p[k]
        if (p.desc ?? p.description) o.description = p.desc ?? p.description
        return o
      }
      if (a === 'add' || a === 'create') {
        const rule = fields(kv(tokens.slice(2)))
        if (!rule.tools?.length || !rule.pattern) return 'Usage: /jiuwen permissions rule add tools=<a,b> pattern=<pattern> action=<allow|ask|deny> [severity=LOW|MEDIUM|HIGH|CRITICAL] [desc=<text>]'
        const r = await g.rpc('permissions.rules.create', { rule })
        return `Created Jiuwen permission rule ${r?.rule?.id || '?'} (${(r?.rule?.tools || rule.tools).join(',')} ~ ${r?.rule?.pattern || rule.pattern} → ${r?.rule?.action || rule.action || 'default'}). Remove with /jiuwen permissions rule delete ${r?.rule?.id || '<id>'} confirm`
      }
      if (a === 'update') {
        const id = rest[2]
        const patch = fields(kv(tokens.slice(3)))
        if (!id || !Object.keys(patch).length) return 'Usage: /jiuwen permissions rule update <id> [tools=..] [pattern=..] [action=..] [severity=..] [desc=..]'
        const r = await g.rpc('permissions.rules.update', { id, patch })
        return `Updated Jiuwen permission rule ${id}: ${j(r?.rule || patch, 300)}`
      }
      if (a === 'delete') {
        const id = rest[2]
        if (!id || id === 'confirm') return 'Usage: /jiuwen permissions rule delete <id> confirm'
        const no = needConfirm(tokens.slice(3), `delete permission rule ${id}`)
        if (no) return no
        await g.rpc('permissions.rules.delete', { id })
        return `Deleted Jiuwen permission rule ${id}.`
      }
      return 'Usage: /jiuwen permissions rule [add|update|delete] …'
    },
  },

  'permissions set-all': {
    usage: 'permissions set-all tool=level… confirm', group: 'Config & policy', methods: ['permissions.tools.set'],
    async run({ g, tokens }) {
      // Distinct from permissions.tools.update (single tool): replaces the entire user overlay.
      const pairs = kv(tokens.slice(1))
      const tools = {}
      for (const [k, v] of Object.entries(pairs)) {
        if (k === 'confirm' || k === '--confirm') continue
        const level = String(v || '').toLowerCase()
        if (!['allow', 'ask', 'deny'].includes(level)) return `Usage: /jiuwen permissions set-all tool=allow|ask|deny … confirm  (replaces user overlay; invalid level for ${k})`
        tools[k] = level
      }
      if (!Object.keys(tools).length) return 'Usage: /jiuwen permissions set-all tool=allow|ask|deny … confirm  (bulk replace of user tool overlay; prefer /jiuwen permissions set for one tool)'
      const no = needConfirm(tokens, 'replace the entire user permissions.tools overlay')
      if (no) return no
      await g.rpc('permissions.tools.set', { tools })
      return `Replaced Jiuwen user permissions.tools overlay (${Object.keys(tools).length} tools): ${Object.entries(tools).map(([k, v]) => `${k}=${v}`).join(', ')}. Single-tool edits: /jiuwen permissions set|unset.`
    },
  },
  'continue-queued': {
    usage: 'continue-queued', group: 'Turn control', methods: ['session.message.continue_queued'],
    async run({ g, sid }) {
      try {
        const r = await g.rpc('session.message.continue_queued', { session_id: sid })
        return `Asked Jiuwen to continue queued messages for ${sid}: ${j(r, 200)}`
      } catch (e) {
        const msg = String(e?.message || e)
        // Session is created lazily on the first turn; a brand-new mapping has nothing queued.
        if (/session (was )?not found/i.test(msg)) {
          return `Jiuwen: no queued messages to continue for ${sid} (session has no turns yet, or was deleted). Send a normal message first; after a mid-turn drop, the next user message reconnects automatically.`
        }
        throw e
      }
    },
  },
  'swarm-stop': {
    usage: 'swarm-stop [run_id]', group: 'Turn control', methods: ['swarmflow.stop'],
    async run({ g, rest, sid, mapping }) {
      const runId = rest[0] || mapping?.swarmRunId
      if (!runId) return 'Usage: /jiuwen swarm-stop <run_id> (no SwarmFlow run seen for this session yet)'
      try {
        const r = await g.rpc('swarmflow.stop', { session_id: sid, run_id: runId })
        return `Sent swarmflow.stop for run ${runId}${r?.ok === false ? ` — ${short(r.reason || r.error, 120)}` : ''}.`
      } catch (e) {
        const msg = String(e?.message || e)
        // Team idle / no active SwarmFlow: Gateway Chinese "工作流控制不可用…"
        if (/工作流控制不可用|workflow (control )?unavailable|no (active )?swarm/i.test(msg)) {
          return `Jiuwen: swarmflow.stop soft-failed — no active SwarmFlow run for ${sid} (team idle or already stopped). ${short(msg, 160)}`
        }
        throw e
      }
    },
  },
  'doc': {
    usage: 'doc persist <host-path>', group: 'System', methods: ['document.persist'],
    async run({ g, rest, sid }) {
      if ((rest[0] || '').toLowerCase() !== 'persist' || !rest[1]) return 'Usage: /jiuwen doc persist <absolute host path>'
      const path = rest.slice(1).join(' ')
      const filename = path.split(/[\\/]/).pop()
      const r = await g.rpc('document.persist', { session_id: sid, documents: [{ type: 'document', path, filename, name: filename }] })
      const items = r?.media_items || []
      const errs = r?.document_errors || []
      return `Jiuwen document.persist: ${items.map(x => x.path || x.filename).join(', ') || 'nothing stored'}${errs.length ? `; errors: ${errs.map(e => `${e.filename}: ${short(e.error, 80)}`).join('; ')}` : ''}`
    },
  },
  'media': {
    usage: 'media discard <uploads-path> confirm', group: 'System', methods: ['media.discard'],
    async run({ g, rest, tokens, sid }) {
      if ((rest[0] || '').toLowerCase() !== 'discard' || !rest[1] || rest[1] === 'confirm') return 'Usage: /jiuwen media discard <session uploads path> confirm'
      const no = needConfirm(tokens.slice(2), `discard ${rest[1]}`)
      if (no) return no
      await g.rpc('media.discard', { session_id: sid, path: rest[1] })
      return `Discarded unsent Jiuwen upload ${rest[1]}.`
    },
  },
}

/** Resolve an extension handler for `sub rest…` (two-word keys win). */
export function findExt(sub, rest) {
  const two = `${sub} ${String(rest[0] || '').toLowerCase()}`
  if (EXT[two]) return EXT[two]
  return EXT[sub]
}

/** Help lines for extensions, hiding those whose methods are all cached unsupported. */
export function extHelp(isUnsupported = () => false) {
  const groups = new Map()
  for (const e of Object.values(EXT)) {
    if (e.methods.length && e.methods.every(m => isUnsupported(m))) continue
    if (!groups.has(e.group)) groups.set(e.group, [])
    groups.get(e.group).push(e.usage)
  }
  return [...groups].map(([k, v]) => `${k} (more): ${v.join(', ')}`)
}
