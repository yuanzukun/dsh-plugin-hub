/**
 * LlmAdapter: DSH Cordis ABI → JiuwenSwarm brain.
 *
 * Product path (mode=gateway): one GenerateOptions turn → Gateway chat.send.
 * Jiuwen owns loop/tools/memory; we only stream assistant text back and finish
 * with stop so DSH agent-loop does not re-execute tools.
 *
 * See ARCHITECTURE.md.
 */

import { OpenAiTransport } from './openai-transport.js'
import { GatewayTransport } from './gateway-transport.js'
import { createToolBridge } from './tool-bridge.js'
import { prepareBrainRequest, callKind } from './agent-brain.js'
import { appendFileSync } from 'node:fs'
import { failureFromError, emitTextReply } from './stream-emit.js'
import { applySystemInjection, applyFsRouteInjection } from './system-inject.js'
import { applySkillBodyInjection } from './host-sync.js'
import { toGatewayQuery, contentToText, withInferredRoles } from './messages.js'
import { fileBlocksFromHandles } from './multimodal.js'
import { carryBlock } from './busy-interrupt.js'

/**
 * @param {typeof import('@deepseek-ai/dsh-llm').LlmAdapter | null} LlmAdapterBase
 * @param {{
 *   config: () => import('./config.js').ResolvedConfig,
 *   sessions: import('./session-store.js').SessionStore,
 *   logger?: { warn: Function, error: Function, info?: Function },
 *   fetchImpl?: typeof fetch,
 *   WebSocketImpl?: typeof WebSocket,
 * }} deps
 */
export function createJiuwenAdapter(LlmAdapterBase, deps) {
  const Base = LlmAdapterBase ?? class {
    providerInfo(provider) { return { id: provider, name: provider } }
    listModels() { return Promise.resolve([]) }
    resolveModel(provider, model) { return Promise.resolve({ provider, id: model, name: model }) }
    prepareCall(provider, model) {
      return Promise.resolve({ model: { provider, id: model, name: model }, stream: o => this.stream(o) })
    }
    /** Required by dsh-llm registerAdapter; undefined => framework defaults. */
    providerRetryPolicy(_provider) {}
    stream() { throw new Error('not implemented') }
  }

  class JiuwenLlmAdapter extends Base {
    constructor() {
      super()
      this._openai = null
      this._gateway = null
    }

    _cfg() {
      return deps.config()
    }

    _openaiTransport() {
      const cfg = this._cfg()
      const key = `${cfg.baseURL}|${cfg.apiKey || ''}`
      if (!this._openai || this._openaiKey !== key) {
        this._openai = new OpenAiTransport({
          baseURL: cfg.baseURL,
          apiKey: cfg.apiKey,
          requestTimeoutMs: cfg.requestTimeoutMs,
          fetchImpl: deps.fetchImpl,
        })
        this._openaiKey = key
      }
      return this._openai
    }

    _gatewayTransport() {
      const cfg = this._cfg()
      const key = JSON.stringify([cfg.gatewayURL, cfg.authToken, cfg.userId, cfg.eventDisplay, cfg.forwardReasoning,
        cfg.showProcessingStatus, cfg.emitUsage, cfg.interruptOnAbort, cfg.swarmflowStopOnAbort, cfg.swarmflowReply, cfg.documentPersist, cfg.finalGraceMs, cfg.terminalFinalGraceMs, cfg.recoverOnDrop, cfg.recoverWindowMs, cfg.postCancelSettleMs, cfg.interruptSettleMs, cfg.chatMode, cfg.workMode, cfg.projectDir])
      if (!this._gateway || this._gatewayKey !== key) {
        this._gateway = new GatewayTransport({
          gatewayURL: cfg.gatewayURL,
          userId: cfg.userId,
          authToken: cfg.authToken,
          accessToken: cfg.accessToken,
          cookie: cfg.cookie,
          authorization: cfg.authorization,
          xToken: cfg.xToken,
          workMode: cfg.workMode,
          projectDir: cfg.projectDir,
          requestTimeoutMs: cfg.requestTimeoutMs,
          surfaceToolEvents: cfg.surfaceGatewayToolEvents,
          chatMode: cfg.chatMode,
          eventDisplay: cfg.eventDisplay,
          trajectoryDetail: cfg.trajectoryDetail,
          forwardReasoning: cfg.forwardReasoning,
          showProcessingStatus: cfg.showProcessingStatus,
          emitUsage: cfg.emitUsage,
          interruptOnAbort: cfg.interruptOnAbort,
          swarmflowStopOnAbort: cfg.swarmflowStopOnAbort,
          swarmflowReply: cfg.swarmflowReply,
          documentPersist: cfg.documentPersist,
          finalGraceMs: cfg.finalGraceMs,
          postCancelSettleMs: cfg.postCancelSettleMs,
          interruptSettleMs: cfg.interruptSettleMs,
          terminalFinalGraceMs: cfg.terminalFinalGraceMs,
          recoverOnDrop: cfg.recoverOnDrop,
          recoverWindowMs: cfg.recoverWindowMs,
          WebSocketImpl: deps.WebSocketImpl,
        })
        this._gatewayKey = key
      }
      return this._gateway
    }

    providerInfo(provider) {
      const cfg = this._cfg()
      return { id: provider, name: cfg.displayName || 'JiuwenSwarm' }
    }

    async listModels(provider) {
      const cfg = this._cfg()
      const own = cfg.models.map(m => ({
        provider,
        id: m.id,
        name: m.name,
        inputModalities: ['text', 'image'],
      }))
      if (!cfg.modelDiscovery || typeof deps.discoverModels !== 'function') return own
      let found = []
      try { found = await deps.discoverModels() } catch { found = [] }
      const ids = new Set(own.map(m => m.id))
      return [...own, ...found.filter(m => !ids.has(m.id)).map(m => ({ provider, id: m.id, name: m.name, inputModalities: ['text', 'image'] }))]
    }

    resolveModel(provider, model) {
      const cfg = this._cfg()
      const hit = cfg.models.find(m => m.id === model)
      return Promise.resolve({
        provider,
        id: model,
        name: hit?.name || model,
        inputModalities: ['text', 'image'],
        ...(hit?.contextWindow ? { context: { contextWindow: hit.contextWindow } } : {}),
        ...(hit?.maxTokens ? { defaultMaxTokens: hit.maxTokens } : {}),
        // Gateway brain owns mid-turn tool changes; DSH must not project tool updates.
        systemPromptUpdate: 'in-history',
        toolUpdate: 'in-history',
      })
    }

    prepareCall(provider, model, _signal) {
      return this.resolveModel(provider, model).then(info => ({
        model: info,
        stream: options => this.stream(options),
      }))
    }

    async *stream(options) {
      // Real dsh agent loops send role-less user messages; infer roles once, without mutating host data.
      const inferred = withInferredRoles(options?.messages)
      if (inferred !== options?.messages) options = { ...options, messages: inferred }
      const cfg = this._cfg()
      const dshSessionId = String(options.sessionId || 'anonymous')
      const reqSession = options?.providerOptions?.jiuwen?.sessionId || options?.metadata?.jiuwen?.sessionId || options?.jiuwen?.sessionId
      try { await deps.awaitHostSync?.(dshSessionId) } catch { /* never blocks a turn */ }
      const mapping = deps.sessions.ensure(dshSessionId, reqSession ? { preferredJiuwenId: String(reqSession) } : {})
      const bridge = createToolBridge(cfg, { fetchImpl: deps.fetchImpl })
      let request = prepareBrainRequest(options, cfg, bridge, deps.logger)
      const kind = callKind(options)

      try {
        if (cfg.mode === 'gateway' && options.purpose === 'session-title' && cfg.titleMode === 'local') {
          // Don't spend a full Jiuwen agent turn (and pollute its session) on a title.
          const title = localTitle(options, cfg.ignoreMessagePatterns)
          makeTrace(cfg.traceFile)({ at: 'local-title', title, system: String(options.system || '').slice(0, 300), messages: JSON.stringify(options.messages).slice(0, 1500) })
          // Compatibility: also push the local title to Jiuwen via session.rename (fire-and-forget).
          if (title && title !== mapping.title) {
            const jwSid = mapping.jiuwenSessionId
            Promise.resolve()
              .then(() => this._gatewayTransport().sessionRename(jwSid, title))
              .then(() => { try { deps.sessions.update?.(dshSessionId, { title }) } catch { /* ignore */ } })
              .catch((error) => deps.logger?.debug?.(`[dsh-jiuwen] session.rename after local title failed: ${String(error?.message || error).slice(0, 200)}`))
          }
          yield *emitTextReply(title)
          return
        }
        if (cfg.mode === 'gateway' && options.purpose === 'compaction' && cfg.compactionMode !== 'jiuwen') {
          // Jiuwen owns the real history (historyMode=gateway sends only new user text), so dsh's checkpoint
          // only needs to be a faithful local digest — no throwaway Jiuwen agent turn (~7 s + a new Jiuwen session).
          const summary = localCompaction(options, cfg.ignoreMessagePatterns, mapping.jiuwenSessionId)
          let compacted
          if (cfg.compactionMode === 'local+jiuwen' && mapping.turns > 0) {
            try { await this._gatewayTransport().rpc('command.compact', { session_id: mapping.jiuwenSessionId }, { timeoutMs: 60_000 }); compacted = true; try { deps.sessions.update?.(dshSessionId, { systemHash: undefined }) } catch { /* ignore */ } } catch (error) { compacted = String(error?.message || error).slice(0, 200) }
          }
          makeTrace(cfg.traceFile)({ at: 'local-compaction', chars: summary.length, jiuwenCompact: compacted })
          yield *emitTextReply(summary)
          return
        }
        if (cfg.mode === 'gateway') {
          deps.logger?.info?.(
            `[dsh-jiuwen] brain=jiuwen gateway chat.send kind=${kind} dsh=${dshSessionId} jiuwen=${mapping.jiuwenSessionId} model=${options.model}`,
          )
          options = await hydrateAttachments(options, deps.attachments?.(), deps.logger)
          if (cfg.documentPersist) options = fileBlocksFromHandles(options)
          const overrides = turnOverrides(cfg, options)
          if (!overrides.modelName && mapping.modelName) overrides.modelName = mapping.modelName // /jiuwen model <name>
          // Per-session overrides from /jiuwen mode (and future skills/agentTemplate): request + catalog
          // win over mapping; mapping wins over bare plugin defaults when those fields were only filled from cfg.
          {
            const req = options?.providerOptions?.jiuwen || options?.metadata?.jiuwen || options?.jiuwen || {}
            const catalog = cfg.models.find(m => m.id === options?.model)
            if (!req.chatMode && !catalog?.chatMode && mapping.chatMode) overrides.chatMode = mapping.chatMode
            if (req.skills === undefined && mapping.skills) overrides.skills = mapping.skills
            if (!req.agentTemplateName && !catalog?.agentTemplateName && mapping.agentTemplateName) {
              overrides.agentTemplateName = mapping.agentTemplateName
            }
            if (!req.projectDir && mapping.projectDir) overrides.projectDir = mapping.projectDir
            if (!req.mcp && Array.isArray(mapping.mcpNames) && mapping.mcpNames.length) {
              overrides.mcp = [...(overrides.mcp || []), ...mapping.mcpNames]
            }
          }
          // sessionOverrides: per-profile defaults (host agent preset / profile, or a session-id glob).
          // Precedence: request > catalog model > /jiuwen mode|model (mapping) > sessionOverrides > plugin defaults.
          {
            let profile
            try { profile = deps.profileFor?.(dshSessionId) } catch { profile = undefined }
            const so = matchSessionOverride(cfg.sessionOverrides, dshSessionId, profile)
            if (so) {
              const req = options?.providerOptions?.jiuwen || options?.metadata?.jiuwen || options?.jiuwen || {}
              const catalog = cfg.models.find(m => m.id === options?.model)
              const explicit = (k) => req[k] !== undefined || catalog?.[k] !== undefined || mapping[k] !== undefined
              if (so.modelName && !explicit('modelName') && !(cfg.forwardModelName && options?.model && !catalog) && !(cfg.discoveryPrefix && String(options?.model || '').startsWith(cfg.discoveryPrefix))) overrides.modelName = so.modelName
              if (so.chatMode && !explicit('chatMode')) overrides.chatMode = so.chatMode
              if (so.agentTemplateName && !explicit('agentTemplateName')) overrides.agentTemplateName = so.agentTemplateName
            }
          }
          if (overrides.supportsUserInteraction === 'auto') overrides.supportsUserInteraction = Boolean(deps.hasUserQuestions?.())
          // Auxiliary calls (compaction, jiuwen titles) run in a separate Jiuwen session with the full
          // transcript, isolated from the main one: one stable `<id>-aux` per dsh session (default) or a
          // fresh one per call (auxSession: 'fresh'). The stable one is deleted with the main session.
          const aux = Boolean(options.purpose)
          const turnMapping = aux ? { ...mapping, jiuwenSessionId: auxSessionId(mapping.jiuwenSessionId, cfg.auxSession), turns: 0 } : mapping
          if (aux) overrides.historyMode = 'transcript'
          let query = buildQuery(options, turnMapping, cfg, overrides)
          // Interrupt-on-busy: the previous turn was cut by a new user message → say so (once), before system injection.
          // A carried text (the interrupted turn never reached Jiuwen) is resent ahead of the new message(s).
          let busyText = query
          let busyCount = 1
          if (!aux && deps.busy) {
            const r = deps.busy.takeResend?.(dshSessionId)
            if (r && !turnMapping.pendingQuestion) {
              if (r.carry) { busyText = `${r.carry}\n\n${query}`; busyCount = r.count }
              query = r.carry ? `${r.note}\n\n${carryBlock(r.carry)}\n${query}` : `${r.note}\n\n${query}`
              makeTrace(cfg.traceFile)({ at: 'turn-interrupt', phase: 'resend', dshSessionId, carried: r.carry ? r.carry.length : undefined, query: query.slice(0, 300) })
            }
          }
          // injectSystem (jiuwen sessions only; fail soft). Skipped for aux calls and ask_user answers.
          let systemHash, systemSections, skillInjectHash, fsRouteHash
      if (!aux && cfg.injectSystem !== 'off' && !turnMapping.pendingQuestion) {
            const inj = applySystemInjection(query, options, turnMapping, cfg.injectSystem, deps.personaFor?.(dshSessionId), cfg.injectSystemMaxBytes, cfg.injectSystemUpdate, cfg.hostProfile, { allow: cfg.hostSystemSectionsAllow, deny: cfg.hostSystemSectionsDeny })
            query = inj.query; systemHash = inj.hash; systemSections = inj.sections
            if (inj.hash) makeTrace(cfg.traceFile)({ at: 'system-inject', dshSessionId, mode: cfg.injectSystem, bytes: inj.bytes, updated: inj.updated, hash: inj.hash, ...(inj.delta ? { delta: true, fullBytes: inj.fullBytes } : {}) })
          }
          const trace = makeTrace(cfg.traceFile)
          let mcpName = cfg.mcpServerName
          let mcpAttached = false
          if (!aux && cfg.toolPassthrough === 'mcp' && deps.mcpBridge && options.tools?.length) {
            const r = await deps.mcpBridge.prepare(options.tools, dshSessionId, { signal: options.signal })
            mcpName = r?.mcpServerName || cfg.mcpServerName
            trace({ at: 'mcp-passthrough', exposed: deps.mcpBridge.exposed?.(dshSessionId) ?? deps.mcpBridge.exposed(), mcpServerName: mcpName, error: r?.error })
            if (r && !r.error) { overrides.mcp = [...(overrides.mcp || []), mcpName]; mcpAttached = true }
          }
          // Only point the model at mcp_<server>_* when the passthrough server is actually attached this turn.
          if (!aux && cfg.mapJiuwenFsToDsh && mcpAttached && !turnMapping.pendingQuestion) {
            const fs = applyFsRouteInjection(query, turnMapping, true, mcpName, deps.mcpBridge.exposed?.(dshSessionId), cfg.hideJiuwenBuiltins)
            query = fs.query
            if (fs.hash) fsRouteHash = fs.hash
          }
          const exposedNow = mcpAttached ? (deps.mcpBridge.exposed?.(dshSessionId) || []) : []
          if (!aux && cfg.syncSkillInstall !== false && turnMapping.skillBodies?.length) {
            const loader = cfg.skillLoaderTool && exposedNow.includes(cfg.skillLoaderTool) ? `mcp_${mcpName}_${cfg.skillLoaderTool}` : undefined
            query = applySkillBodyInjection(query, turnMapping, { mode: cfg.hostSkillInject, loaderTool: loader,
              onMissingLoader: () => {
                deps.logger?.warn?.(`[dsh-jiuwen] hostSkillInject:index — skill loader tool "${cfg.skillLoaderTool || 'skill'}" not passed through; injecting index-only (no silent body fallback). Set hostSkillInject: body for inline bodies.`)
                trace({ at: 'skill-inject', warn: 'index-without-loader', dshSessionId, skillLoaderTool: cfg.skillLoaderTool || 'skill' })
              },
              onInjected: (h, mode) => { skillInjectHash = h; trace({ at: 'skill-inject', dshSessionId, mode, skills: turnMapping.skillBodies.length, hash: h, loader: Boolean(loader) }) } })
          }
          trace({ at: 'turn-start', dshSessionId, jiuwen: turnMapping.jiuwenSessionId, purpose: options.purpose, query: query.slice(0, 500), messages: (options.messages || []).length,
            blocks: JSON.stringify((options.messages || []).flatMap(m => Array.isArray(m.content) ? m.content.filter(b => b?.type !== 'text') : [])).slice(0, 1500) })
          let recorded = false
          // Everything injected into this query (system block, FS hint, skill index/bodies) is pending
          // until Jiuwen shows it accepted the turn (first event) and is then committed together, so a
          // failed send never marks an injection as delivered and nothing is committed piecemeal.
          let committed = aux
          const commitInjected = () => {
            if (committed) return
            committed = true
            const patch = { ...(systemHash ? { systemHash, systemSections } : {}), ...(skillInjectHash ? { skillInjectHash } : {}), ...(fsRouteHash ? { fsRouteHash } : {}) }
            if (Object.keys(patch).length) { try { deps.sessions.update?.(dshSessionId, patch) } catch { /* ignore */ } }
          }
          const endTurn = aux ? () => {} : (deps.sessions.beginTurn?.(dshSessionId) || (() => {}))
          const busy = !aux && deps.busy && cfg.onBusyMessage === 'interrupt' ? deps.busy.begin(dshSessionId) : undefined
          if (busy) { busy.userText = busyText; busy.userCount = busyCount }
          try {
          request = { ...request, messages: options.messages }
          // Goal bridge (Jiuwen submit_goal_report → dsh update_goal): finish the update while this
          // dsh turn is still open, i.e. before passing the turn's `finish` on.
          const goalUpdates = new Set()
          const gwStream = this._gatewayTransport().stream(request, turnMapping, {
            query,
            mark: (name) => trace({ at: 'mark', name }),
            traceParams: (p) => trace({ at: 'params', params: { ...p, content: undefined, query: String(p.query).slice(0, 300) } }),
            overrides,
            ...(busy ? { busy } : {}),
            ...(deps.interact && !aux ? { interact: async (q) => {
              // Approval cards defer an interrupt-on-busy until answered; question cards are superseded by interaction.js.
              const approvalLike = q?.eventType === 'plan.approval_required' || /^(permission|confirm)_interrupt$|^swarmflow_human$/.test(String(q?.payload?.source || ''))
              deps.busy?.setAwaiting(dshSessionId, approvalLike ? 'approval' : 'question')
              try { return await deps.interact({ ...q, told: overrides.supportsUserInteraction === true }, dshSessionId) } finally { deps.busy?.setAwaiting(dshSessionId, null) }
            } } : {}),
            onEvent: (e) => {
              commitInjected()
              if (!aux && deps.goalBridge) {
                try { const p = deps.goalBridge.observe(dshSessionId, e); if (p) { goalUpdates.add(p); p.finally(() => goalUpdates.delete(p)) } } catch { /* ignore */ }
              }
              trace({ at: 'event', type: e.type, name: e.name, event: e.event, ...(e.type === 'interaction_answered' ? { eventType: e.eventType, source: e.source, outcome: e.outcome, raw: JSON.stringify(e.raw).slice(0, 1500) } : {}) })
              try { overrides.onEvent?.(e) } catch { /* ignore */ }
              try { deps.onEvent?.({ dshSessionId, ...e }) } catch { /* ignore */ }
            },
            onTurnEnd: (info) => {
              trace({ at: 'turn-end', reason: info.reason, chars: info.text?.length, ...(info.interrupted ? { interrupted: true } : {}) })
              recorded = true
              if (!aux && (info.reason?.kind === 'stop' || info.reason?.kind === 'aborted')) {
                commitInjected()
                deps.sessions.recordTurn?.(dshSessionId, { requestId: info.requestId, pendingQuestion: info.pendingQuestion })
              }
              // Turns usually end on the terminal chat.final grace, before Gateway's processing_status
              // {is_complete} arrives, so bridges (planBridge) key off this explicit turn_end event.
              if (!aux) { try { deps.onEvent?.({ dshSessionId, type: 'turn_end', sessionId: turnMapping.jiuwenSessionId, requestId: info.requestId, reason: info.reason }) } catch { /* ignore */ } }
            },
          })
          for await (const chunk of gwStream) {
            if (chunk?.type === 'finish' && goalUpdates.size) await Promise.allSettled([...goalUpdates])
            yield chunk
          }
          } finally {
            // Host may stop iterating right after abort; Jiuwen already holds the user message.
            if (!recorded && !aux && options.signal?.aborted) {
              trace({ at: 'turn-end', reason: { kind: 'aborted' } })
              deps.sessions.recordTurn?.(dshSessionId, {})
            }
            busy?.end()
            // Host stop/cancel wins over a pending interrupt note.
            if (options.signal?.aborted) deps.busy?.clearNote(dshSessionId)
            endTurn()
          }
          return
        }

        deps.logger?.info?.(
          `[dsh-jiuwen] mode=openai (fallback) base=${cfg.baseURL} kind=${kind} session=${mapping.jiuwenSessionId} allowDshAgentLoop=${cfg.allowDshAgentLoop}`,
        )
        yield *this._openaiTransport().stream(request)
      } catch (error) {
        deps.logger?.error?.(error)
        yield failureFromError(error, options.signal)
      }
    }
  }

  return JiuwenLlmAdapter
}

/**
 * Per-request Jiuwen options: options.providerOptions.jiuwen | options.metadata.jiuwen | options.jiuwen,
 * layered over plugin config and the selected catalog model.
 */
export function turnOverrides(cfg, options) {
  const req = options?.providerOptions?.jiuwen || options?.metadata?.jiuwen || options?.jiuwen || {}
  const model = cfg.models.find(m => m.id === options?.model)
  let modelName = req.modelName ?? model?.modelName
  if (modelName === undefined && cfg.forwardModelName && options?.model && !model) modelName = options.model
  // modelDiscovery ids: `<discoveryPrefix><model_name>` → model_name
  if (req.modelName === undefined && !model && cfg.discoveryPrefix && String(options?.model || '').startsWith(cfg.discoveryPrefix)) {
    modelName = String(options.model).slice(cfg.discoveryPrefix.length) || undefined
  }
  const pick = (k) => req[k] ?? model?.[k] ?? cfg[k]
  return {
    chatMode: pick('chatMode'),
    agentTemplateName: pick('agentTemplateName'),
    agentGroupName: pick('agentGroupName'),
    skills: req.skills ?? cfg.skills,
    pluginNames: req.pluginNames,
    ...(Array.isArray(req.mcp) ? { mcp: req.mcp.map(String) } : {}),
    metadata: req.metadata,
    projectDir: req.projectDir,
    supportsUserInteraction: req.supportsUserInteraction ?? cfg.supportsUserInteraction,
    sessionId: req.sessionId,
    historyMode: req.historyMode ?? cfg.historyMode,
    ...(modelName ? { modelName } : {}),
    ...(typeof req.onEvent === 'function' ? { onEvent: req.onEvent } : {}),
  }
}

/** Jiuwen session id for aux calls (compaction/titles) of one main Jiuwen session. */
export function auxSessionId(jiuwenSessionId, mode = 'stable') {
  return mode === 'fresh' ? `${jiuwenSessionId}-aux-${Date.now().toString(36)}` : `${jiuwenSessionId}-aux`
}

/**
 * Gateway query text honoring session continuity: once the Jiuwen session has turns,
 * send only the user messages after the last assistant message (hosts may append
 * several, e.g. task + runtime-context), since Jiuwen keeps its own history.
 */
export function buildQuery(options, mapping, cfg, overrides) {
  if ((overrides.historyMode || cfg.historyMode) === 'gateway') {
    const tail = trailingUserText(options.messages || [], cfg.ignoreMessagePatterns)
    if ((mapping.turns || 0) > 0 && tail) return tail
    const hasAssistant = (options.messages || []).some(m => m.role === 'assistant')
    if (!hasAssistant && tail) return tail
  }
  const ignore = cfg.ignoreMessagePatterns || []
  const messages = (options.messages || [])
    .map(m => (m.role === 'user' ? { ...m, content: stripIgnored(m.content, ignore) } : m))
    .filter(m => m.role !== 'user' || m.content)
  return toGatewayQuery({ ...options, messages })
}

function trailingUserText(messages, ignore = []) {
  const out = []
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i]
    if (m.role === 'assistant') break
    if (m.role === 'user') {
      const t = stripIgnored(m.content, ignore)
      if (t) out.unshift(t)
    }
  }
  return out.join('\n\n')
}

/** Text of a message minus host-context blocks (a matching block is cut from the match onward). */
export function stripIgnored(content, ignore = []) {
  const blocks = Array.isArray(content) ? content : [{ type: 'text', text: contentToText(content) }]
  const out = []
  for (const b of blocks) {
    let t = b?.type === 'text' ? String(b.text || '') : contentToText([b])
    for (const re of ignore) {
      const m = re.exec(t)
      if (m) t = t.slice(0, m.index)
    }
    t = t.trim()
    if (t) out.push(t)
  }
  return out.join('\n')
}

/**
 * Optional: resolve content-addressed attachments through a host `attachments`
 * service (Cordis AttachmentStore shape: readImageRequest / fileHostPath) so images
 * and files reach Jiuwen as base64Data. No-op when the host has no such service.
 */
export async function hydrateAttachments(options, store, logger) {
  if (!store || !Array.isArray(options.messages)) return options
  let changed = false
  const messages = []
  for (const m of options.messages) {
    if (!Array.isArray(m.content)) { messages.push(m); continue }
    const content = []
    for (const b of m.content) {
      const att = b?.attachment
      if (!att?.attachmentId || att.base64 || att.dataUrl || att.path) { content.push(b); continue }
      try {
        if (b.type === 'image' && typeof store.readImageRequest === 'function') {
          const scale = Math.min(1, 2048 / Math.max(att.width || 2048, att.height || 2048))
          const img = await store.readImageRequest(att, {
            width: Math.max(1, Math.round((att.width || 2048) * scale)),
            height: Math.max(1, Math.round((att.height || 2048) * scale)),
            maxBytes: 4 * 1024 * 1024,
          }, options.signal)
          content.push({ ...b, attachment: { ...att, mimeType: img.mediaType || att.mediaType, base64: Buffer.from(img.data).toString('base64') } })
          changed = true
          continue
        }
        if (b.type === 'file' && typeof store.fileHostPath === 'function') {
          const path = store.fileHostPath(att)
          if (path) { content.push({ ...b, attachment: { ...att, path, mimeType: att.mimeType || att.mediaType } }); changed = true; continue }
        }
      } catch (error) {
        logger?.warn?.(`[dsh-jiuwen] attachment ${att.attachmentId} unresolved: ${error?.message || error}`)
      }
      content.push(b)
    }
    messages.push({ ...m, content })
  }
  return changed ? { ...options, messages } : options
}

/**
 * Local compaction digest: the conversation as role-tagged lines, newest kept when over budget.
 * The trailing compaction instruction (last user message) is dropped.
 */
export function localCompaction(options, ignore = [], jiuwenSessionId, budget = 6000) {
  const msgs = [...(options.messages || [])]
  if (msgs.at(-1)?.role === 'user') msgs.pop()
  const lines = []
  for (const m of msgs) {
    if (m.role !== 'user' && m.role !== 'assistant') continue
    const t = stripIgnored(m.content, ignore).replace(/\s+/g, ' ').trim()
    if (t) lines.push(`- ${m.role}: ${t.length > 600 ? `${t.slice(0, 600)}…` : t}`)
  }
  const kept = []
  let size = 0
  for (let i = lines.length - 1; i >= 0; i--) {
    if (size + lines[i].length > budget && kept.length) break
    kept.unshift(lines[i]); size += lines[i].length
  }
  const head = `Conversation checkpoint (local digest${jiuwenSessionId ? `; JiuwenSwarm session ${jiuwenSessionId} keeps the full history` : ''}).`
  const omitted = lines.length - kept.length
  return [head, ...(omitted > 0 ? [`(${omitted} earlier message(s) omitted)`] : []), ...kept].join('\n')
}

/** Instant session title from the first user message. */
export function localTitle(options, ignore = []) {
  const first = (options.messages || []).find(m => m.role === 'user')
  let raw = stripIgnored(first?.content, ignore)
  // Title prompts often embed the conversation as a JSON array ([{text}] / [{content}]).
  const a = raw.indexOf('['), b = raw.lastIndexOf(']')
  if (a >= 0 && b > a) {
    try {
      const arr = JSON.parse(raw.slice(a, b + 1))
      const item = Array.isArray(arr) ? arr.find(x => x && (typeof x === 'string' || x.text || x.content)) : undefined
      const inner = typeof item === 'string' ? item : (item?.text ?? contentToText(item?.content))
      if (inner) raw = stripIgnored(String(inner), ignore)
    } catch { /* not JSON */ }
  }
  const t = raw.replace(/\s+/g, ' ').trim()
  return t ? (t.length > 40 ? `${t.slice(0, 40)}…` : t) : 'Jiuwen chat'
}

function makeTrace(file) {
  if (!file) return () => {}
  return (rec) => {
    try { appendFileSync(file, `${JSON.stringify({ t: new Date().toISOString(), up: Math.round(performance.now()), ...rec })}\n`) } catch { /* ignore */ }
  }
}

/** Convenience: construct with optional peer package. */
export async function loadJiuwenAdapterClass() {
  const stubCfg = {
    provider: 'jiuwen',
    displayName: 'JiuwenSwarm',
    mode: 'gateway',
    brainOwnership: 'jiuwen',
    baseURL: 'http://127.0.0.1',
    gatewayURL: 'ws://127.0.0.1',
    models: [],
    defaultModel: 'x',
    mappingPath: '/tmp/x',
    allowDshAgentLoop: false,
    exposeJiuwenTools: false,
    surfaceGatewayToolEvents: true,
    requestTimeoutMs: 1000,
    apiKeyEnv: 'JIUWEN_API_KEY',
    userId: 'x',
    workMode: 'agent',
  }
  const deps = {
    config: () => stubCfg,
    sessions: { ensure: id => ({ dshSessionId: id, jiuwenSessionId: id, updatedAt: '' }) },
  }
  try {
    const mod = await import('@deepseek-ai/dsh-llm')
    return createJiuwenAdapter(mod.LlmAdapter, deps)
  } catch {
    return createJiuwenAdapter(null, deps)
  }
}

const globRe = (g) => new RegExp(`^${String(g).split('*').map(x => x.replace(/[.+?^${}()|[\]\\]/g, '\\$&')).join('.*')}$`)
/**
 * First sessionOverrides entry that matches. An entry may set `preset` (glob on the host agent
 * preset / profile name, preferred) and/or `match` (glob on the dsh session id, legacy); every key
 * it sets must match. Entries with neither never match.
 */
export function matchSessionOverride(list, id, profile) {
  if (!Array.isArray(list) || !list.length || !id) return undefined
  for (const o of list) {
    if (!o || (typeof o.preset !== 'string' && typeof o.match !== 'string')) continue
    if (typeof o.preset === 'string' && !(profile && globRe(o.preset).test(String(profile)))) continue
    if (typeof o.match === 'string' && !globRe(o.match).test(String(id))) continue
    return o
  }
  return undefined
}
