/* assets/panel.js —— 通用 Comfy 控制层面板（非 ESM，`<script defer>` 单文件）
 *
 * ## 硬约束（别改成 import）
 *   DSH 的客户端形态是 `window.__ModuleLoader__` 单入口的纯脚本，**不能 import ESM**；
 *   `lib/` 也不经 web 暴露。所以契约数据一律从
 *   `GET /api/comfy-pipeline/schema`（已挂到 `window.ComfyPipelineSchema`）读，
 *   控制项存到 `GET/POST /api/comfy-pipeline/controls`。
 *
 * ## 这个面板**不装**什么
 *   视频链（wan22 / XT-5B）已接进 lib/video-workflow.js ⇒ 可选。
 *   混合模式（image → tts → video）是否可选由 `GET /api/comfy-pipeline/modes` 探测决定：
 *   探到 TTS 节点+权重就自动放行，缺件时 tab 禁用并把**缺什么、放哪**放进 title（如实，
 *   不假装能出音频）—— 摆一个拨了没反应的滑块，比不给更坏（本项目历史上被"假报告"坑过）。
 *   `denoise` / `tileSize` 两项暂无消费方，禁用并注明；`frames` / `fps` 已接视频链、
 *   `chunkOverlap` 供混合链分段拼接消费（advanced 里仍禁用，值走 controls 默认，不谎称没消费方）。
 *
 * ## 速度%的真实语义
 *   只压**画幅像素预算**（长边 1024→896→768→640）与参考图张数上限。
 *   **绝不改蒸馏步数** —— 官方 Turbo 是 8/9 步蒸馏模型，改步数不是"快"而是"糊"。
 */
(function () {
  'use strict'

  var existing = window.ComfyPipelinePanel
  if (existing && existing.__cp === true) return

  var SCHEMA_PATH = 'api/comfy-pipeline/schema'
  var CONTROLS_PATH = 'api/comfy-pipeline/controls'
  var PROGRESS_PATH = 'api/comfy-pipeline/progress'
  var LIBRARY_PATH = 'api/comfy-pipeline/library'
  var MODES_PATH = 'api/comfy-pipeline/modes'
  var FALLBACK_TIERS = [25, 50, 75, 100]

  // 默认与「本地没探到 modes 端点」一致：图/视频可用、混合禁用。
  // 端点回来后按 modes[].available 覆写 —— 探测失败绝不把已可用模式误关。
  var modeAvailability = { image: true, video: true, hybrid: false }
  var modeReason = { hybrid: '' }

  var schema = null
  var state = null
  var nodes = null
  var saveTimer = null
  var saveSeq = 0
  var progressTimer = null

  /* ============================ 纯函数（可被回归直接测） ============================ */

  function defsByKey() {
    var out = {}
    var groups = (schema && schema.controls) || {}
    Object.keys(groups).forEach(function (g) {
      var list = groups[g] || []
      for (var i = 0; i < list.length; i += 1) {
        if (list[i] && typeof list[i].key === 'string') out[list[i].key] = list[i]
      }
    })
    return out
  }

  /** 按契约定义 clamp 到 [min,max] 并对齐 step（从 min 起算，不是从 0）。 */
  function clampByDef(def, value) {
    var v = typeof value === 'number' ? value : Number(value)
    if (!Number.isFinite(v)) return def && Number.isFinite(def['default']) ? def['default'] : 0
    var min = def && Number.isFinite(def.min) ? def.min : -Infinity
    var max = def && Number.isFinite(def.max) ? def.max : Infinity
    var step = def && Number.isFinite(def.step) && def.step > 0 ? def.step : 0
    v = Math.min(max, Math.max(min, v))
    if (step > 0) {
      var base = def && Number.isFinite(def.min) ? def.min : 0
      v = base + Math.round((v - base) / step) * step
      v = Math.min(max, Math.max(min, v))
      v = Number(v.toFixed(4))
    }
    if (def && (def.type === 'number' || def.type === 'integer')) v = Math.trunc(v)
    return v
  }

  function speedTiers() {
    var t = schema && schema.speedTiers
    return Array.isArray(t) && t.length > 0 ? t : FALLBACK_TIERS
  }

  /** 16 档滑块值 → 最近的 4 档之一。 */
  function quantize(speed) {
    var tiers = speedTiers()
    var v = Number(speed)
    if (!Number.isFinite(v)) return tiers[tiers.length - 1]
    return tiers.reduce(function (best, t) {
      return Math.abs(t - v) < Math.abs(best - v) ? t : best
    }, tiers[0])
  }

  /** 该档的描述（生图看 size/refs，视频看 frames/fps/height）。契约里没有就返回 null，绝不编。 */
  function speedSlot(speed, mode) {
    var map = schema && schema.speedMap
    var key = mode === 'video' ? 'video' : 'image'
    var slot = map && map[key] ? map[key][quantize(speed)] : null
    return slot && typeof slot === 'object' ? slot : null
  }

  function speedEdge(speed, mode) {
    var slot = speedSlot(speed, mode)
    return slot && Number.isFinite(slot.size) ? slot.size : null
  }

  function speedRefs(speed, mode) {
    var slot = speedSlot(speed, mode)
    return slot && Number.isFinite(slot.refs) ? slot.refs : null
  }

  function aspectTicks() {
    var def = defsByKey().aspect
    return def && Array.isArray(def.ticks) ? def.ticks : ['1:1']
  }

  /**
   * 状态 → POST 载荷。**只输出契约里认识的键**，其余一律不出现（服务端还会再洗一遍，
   * 但前端先洗的好处是：UI 上就不可能拨出非法值）。
   */
  function buildPayload(input) {
    var defs = defsByKey()
    var src = input && typeof input === 'object' ? input : {}
    var out = {}
    var modes = (schema && schema.modes) || []
    var okMode = false
    for (var i = 0; i < modes.length; i += 1) if (modes[i].id === src.mode) okMode = true
    out.mode = okMode ? src.mode : 'image'
    Object.keys(defs).forEach(function (key) {
      if (!Object.prototype.hasOwnProperty.call(src, key)) return
      var def = defs[key]
      // ★ 自由文本控制项（负面提示词）：按字符截断，不参与数字 clamp。
      if (def && def.type === 'text') {
        var raw = typeof src[key] === 'string' ? src[key] : String(src[key] == null ? '' : src[key])
        out[key] = def.max && def.max > 0 ? raw.slice(0, def.max) : raw
        return
      }
      out[key] = clampByDef(def, src[key])
    })
    return out
  }

  /** 人话摘要：档位一律标「吸附」，没实测基准就不编 ETA 数字。 */
  function describe(input) {
    var c = buildPayload(input)
    var ticks = aspectTicks()
    var idx = Math.min(ticks.length - 1, Math.max(0, Math.trunc(c.aspect || 0)))
    var slot = speedSlot(c.speedPercent, c.mode)
    var parts = [ticks[idx], '速度 ' + c.speedPercent + '%（吸附 ' + quantize(c.speedPercent) + ' 档）']
    if (slot) {
      if (Number.isFinite(slot.size)) parts.push('长边 ' + slot.size)
      if (Number.isFinite(slot.refs)) parts.push('该档参考图预算 ' + slot.refs)
      if (Number.isFinite(slot.frames)) parts.push(slot.frames + ' 帧')
      if (Number.isFinite(slot.fps)) parts.push(slot.fps + ' fps')
      if (Number.isFinite(slot.height)) parts.push('高 ' + slot.height)
    }
    return parts.join(' · ')
  }

  /* ============================ 契约加载 ============================ */

  function loadSchema() {
    if (schema) return Promise.resolve(schema)
    if (window.ComfyPipelineSchema) {
      schema = window.ComfyPipelineSchema
      return Promise.resolve(schema)
    }
    return fetch(SCHEMA_PATH, { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null })
      .then(function (j) {
        if (j && j.ok && j.schema) {
          schema = j.schema
          window.ComfyPipelineSchema = j.schema
        }
        return schema
      })
      .catch(function () { return null })
  }

  function loadControls() {
    return fetch(CONTROLS_PATH, { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null })
      .then(function (j) {
        if (j && j.ok && j.controls) return sanitizeLocal(j.controls)
        return sanitizeLocal({})
      })
      .catch(function () { return sanitizeLocal({}) })
  }

  /** 模式可用性探测：只在端点明确回 available=true 时放行，拿不到就保持默认。 */
  function loadModes() {
    return fetch(MODES_PATH, { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null })
      .then(function (j) {
        if (j && j.ok && Array.isArray(j.modes)) {
          for (var i = 0; i < j.modes.length; i += 1) {
            var m = j.modes[i]
            if (m && typeof m.id === 'string') modeAvailability[m.id] = m.available === true
          }
          if (j.hybrid && typeof j.hybrid.reason === 'string') modeReason.hybrid = j.hybrid.reason
        }
        return modeAvailability
      })
      .catch(function () { return modeAvailability })
  }

  function sanitizeLocal(raw) {
    var defs = defsByKey()
    var out = buildPayload(raw)
    Object.keys(defs).forEach(function (key) {
      if (!Object.prototype.hasOwnProperty.call(out, key) && Number.isFinite(defs[key]['default'])) {
        out[key] = defs[key]['default']
      }
    })
    if (!out.mode) out.mode = 'image'
    return out
  }

  /* ============================ DOM ============================ */

  function el(tag, cls, text) {
    var n = document.createElement(tag)
    if (cls) n.className = cls
    if (text !== undefined && text !== null) n.textContent = String(text)
    return n
  }

  /** 卡片化分区容器：统一 .cp-card 外观 + 一行小标题（UI 现代化重构）。 */
  function card(title, cls) {
    var c = el('div', 'cp-card' + (cls ? ' ' + cls : ''))
    if (title) c.appendChild(el('div', 'cp-card-title', title))
    return c
  }

  function setStatus(text, kind) {
    if (!nodes || !nodes.status) return
    nodes.status.textContent = text
    nodes.status.className = 'cp-status' + (kind ? ' is-' + kind : '')
  }

  /**
   * 生成进度（v3 需求第 3 条）。
   * ⚠ 只渲染它自己拿到的东西：
   *   · 队列位置与已等时长来自 host 的 `/queue` 反查（真数据）；
   *   · 百分比**只在有自家实测基准时**才画，否则走不定长进度条——
   *     拿"时间比例"冒充"采样百分比"就是假进度条，宁可不给。
   */
  function paintProgress(payload) {
    if (!nodes || !nodes.progress) return
    var wrap = nodes.progress
    var items = payload && Array.isArray(payload.items) ? payload.items : []
    if (items.length === 0) { wrap.hidden = true; return }
    var it = items[0]
    wrap.hidden = false
    var fill = wrap.querySelector('.cp-progress-fill')
    var note = wrap.querySelector('.cp-progress-note')
    if (fill) {
      fill.style.width = (it.percent === null || it.percent === undefined ? 100 : it.percent) + '%'
      fill.className = 'cp-progress-fill' + (it.percent === null || it.percent === undefined ? ' is-indeterminate' : '')
    }
    if (note) note.textContent = String(it.note || '')
  }

  function pollProgress() {
    try {
      fetch(PROGRESS_PATH, { cache: 'no-store' })
        .then(function (r) { return r.ok ? r.json() : null })
        .then(function (j) { if (j && j.ok) paintProgress(j) })
        .catch(function () { /* 进度拿不到就不显示，不报错弹窗 */ })
    } catch (err) { /* 同上 */ }
  }

  function startPolling() {
    if (progressTimer !== null) return
    pollProgress()
    progressTimer = setInterval(pollProgress, 1500)
  }

  function stopPolling() {
    if (progressTimer === null) return
    clearInterval(progressTimer)
    progressTimer = null
  }

  /* ---------- 素材库：设计风格 / 用户指令 / 装载 skill ---------- */

  var libState = { styles: [], skillsAvailable: [], selected: 'none', instruction: '', skills: [] }

  function loadLibrary() {
    return fetch(LIBRARY_PATH, { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null })
      .then(function (j) {
        if (j && j.ok) {
          libState = {
            styles: Array.isArray(j.styles) ? j.styles : [],
            skillsAvailable: Array.isArray(j.skillsAvailable) ? j.skillsAvailable : [],
            selected: j.selected || 'none',
            instruction: j.instruction || '',
            skills: Array.isArray(j.skills) ? j.skills : [],
          }
        }
        paintLibrary()
      })
      .catch(function () { /* 素材库拿不到就不显示，不影响出图 */ })
  }

  function saveLibrary(patch) {
    Object.assign(libState, patch)
    return fetch(LIBRARY_PATH, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ selected: libState.selected, instruction: libState.instruction, skills: libState.skills }),
    })
      .then(function (r) { return r.json() })
      .then(function (j) {
        if (!j || j.ok !== true) { setStatus('素材库保存失败：' + ((j && j.reason) || '未知原因'), 'err'); return }
        setStatus(j.saved === false ? '素材库已生效（写盘失败：' + (j.reason || '目录只读') + '）' : '素材库已保存', j.saved === false ? 'err' : 'ok')
      })
      .catch(function (err) { setStatus('素材库保存失败：' + (err && err.message ? err.message : err), 'err') })
  }

  function paintLibrary() {
    if (!nodes || !nodes.library) return
    var box = nodes.library
    var sel = box.querySelector('.cp-select')
    var ta = box.querySelector('.cp-textarea')
    var list = box.querySelector('.cp-skills')
    if (!sel || !ta || !list) return
    // 风格下拉
    while (sel.children.length > 0) sel.removeChild(sel.children[0])
    for (var i = 0; i < libState.styles.length; i += 1) {
      var o = el('option', null, libState.styles[i].name)
      o.value = libState.styles[i].id
      sel.appendChild(o)
    }
    sel.value = libState.selected
    ta.value = libState.instruction
    // ★ 技能装载：带颜色圆点的 Tag 胶囊，整块可点、点整块变色（不再用原生小方块）
    while (list.children.length > 0) list.removeChild(list.children[0])
    for (var k = 0; k < libState.skillsAvailable.length; k += 1) {
      var sk = libState.skillsAvailable[k]
      var on = libState.skills.indexOf(sk.id) >= 0
      var tag = el('button', 'cp-skill-tag' + (on ? ' is-on' : ''))
      tag.type = 'button'
      tag.value = sk.id
      tag.title = sk.desc || ''
      if (typeof tag.setAttribute === 'function') {
        tag.setAttribute('role', 'checkbox')
        tag.setAttribute('aria-checked', on ? 'true' : 'false')
      }
      tag.appendChild(el('span', 'cp-skill-dot'))
      tag.appendChild(el('span', 'cp-skill-name', sk.name || sk.id))
      if (sk.desc) tag.appendChild(el('span', 'cp-skill-desc', sk.desc))
      tag.addEventListener('click', (function (id) {
        return function () {
          var tags = list.querySelectorAll('.cp-skill-tag')
          var picked = []
          for (var n = 0; n < tags.length; n += 1) {
            if (String(tags[n].className).indexOf('is-on') >= 0) picked.push(tags[n].value)
          }
          var at = picked.indexOf(id)
          if (at >= 0) picked.splice(at, 1); else picked.push(id)
          for (var m = 0; m < tags.length; m += 1) {
            var t = tags[m]
            var isOn = picked.indexOf(t.value) >= 0
            t.className = 'cp-skill-tag' + (isOn ? ' is-on' : '')
            if (typeof t.setAttribute === 'function') t.setAttribute('aria-checked', isOn ? 'true' : 'false')
          }
          libState.skills = picked
          saveLibrary({ skills: picked })
        }
      })(sk.id))
      list.appendChild(tag)
    }
    var hint = box.querySelector('.cp-library-hint')
    if (hint) {
      hint.textContent = libState.skillsAvailable.length === 0
        ? '没找到本机已装的 skill（~/.dsh/skills）。请先装载美术、画风、配色相关的 skill。'
        : '共 ' + libState.skillsAvailable.length + ' 个可装载；建议勾美术 / 画风 / 配色相关的，勾上后会把名字与摘要拼进提示词。'
    }
  }

  function scheduleSave() {
    if (saveTimer !== null) clearTimeout(saveTimer)
    saveTimer = setTimeout(save, 300)
  }

  function save() {
    saveTimer = null
    var payload = buildPayload(state)
    var seq = (saveSeq += 1)
    if (nodes && nodes.fab) nodes.fab.classList.add('is-busy')
    setStatus('保存中…')
    fetch(CONTROLS_PATH, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
    })
      .then(function (r) { return r.json() })
      .then(function (j) {
        if (seq !== saveSeq) return // 有更新的保存在路上，丢弃这次的旧结果
        if (nodes && nodes.fab) nodes.fab.classList.remove('is-busy')
        if (!j || j.ok !== true) {
          setStatus('保存失败：' + ((j && j.reason) || '未知原因'), 'err')
          return
        }
        if (j.controls) state = sanitizeLocal(j.controls)
        setStatus(j.saved === false
          ? '已生效（写盘失败：' + (j.reason || '目录只读') + '，重启后回到默认）'
          : '已保存 · ' + (j.summary || describe(state)),
        j.saved === false ? 'err' : 'ok')
      })
      .catch(function (err) {
        if (nodes && nodes.fab) nodes.fab.classList.remove('is-busy')
        setStatus('保存失败：' + (err && err.message ? err.message : err), 'err')
      })
  }

  function field(label, key, opts) {
    var def = defsByKey()[key] || {}
    var wrap = el('div', 'cp-field' + (opts && opts.disabled ? ' cp-off' : ''))
    var top = el('div', 'cp-field-top')
    top.appendChild(el('span', 'cp-label', label))
    var val = el('span', 'cp-value')
    top.appendChild(val)
    wrap.appendChild(top)

    var input
    if (def.type === 'number' || def.type === 'integer' || key === 'seed') {
      input = el('input')
      input.type = 'number'
      if (Number.isFinite(def.min)) input.min = String(def.min)
      if (Number.isFinite(def.max)) input.max = String(def.max)
      if (Number.isFinite(def.step)) input.step = String(def.step)
    } else {
      input = el('input')
      input.type = 'range'
      input.min = String(Number.isFinite(def.min) ? def.min : 0)
      input.max = String(Number.isFinite(def.max) ? def.max : 100)
      input.step = String(Number.isFinite(def.step) ? def.step : 1)
    }
    input.value = String(state[key] !== undefined ? state[key] : (def['default'] !== undefined ? def['default'] : 0))
    if (opts && opts.disabled) input.disabled = true
    wrap.appendChild(input)

    var hint = null
    if (opts && opts.hint) {
      hint = el('p', 'cp-hint' + (opts.warn ? ' is-warn' : ''), opts.hint)
      wrap.appendChild(hint)
    }
    var ticks = null
    if (opts && Array.isArray(opts.ticks)) {
      ticks = el('div', 'cp-ticks')
      opts.ticks.forEach(function (t) { ticks.appendChild(el('span', null, t)) })
      wrap.appendChild(ticks)
    }

    var paint = function () {
      var v = state[key]
      if (key === 'seed') {
        val.textContent = v < 0 ? '随机' : String(v)
      } else if (Array.isArray(opts && opts.ticks) && Number.isFinite(Number(v))) {
        var i = Math.min(opts.ticks.length - 1, Math.max(0, Math.trunc(Number(v))))
        val.textContent = opts.ticks[i]
        if (ticks) {
          for (var k = 0; k < ticks.children.length; k += 1) {
            ticks.children[k].className = k === i ? 'is-on' : ''
          }
        }
      } else {
        val.textContent = String(v)
      }
      // 胶囊滑块「已划过」的填充色：把当前值换算成轨道百分比写进 CSS 变量。
      // 假 DOM 的 style 是普通对象（无 setProperty），守卫后跳过即可，不影响真渲染。
      if (input.type === 'range' && input.style && typeof input.style.setProperty === 'function') {
        var lo = Number(input.min)
        var hi = Number(input.max)
        var num = Number(v)
        var pct = Number.isFinite(num) && hi > lo ? ((num - lo) / (hi - lo)) * 100 : 0
        input.style.setProperty('--cp-fill', Math.max(0, Math.min(100, pct)) + '%')
      }
      if (opts && typeof opts.onPaint === 'function') opts.onPaint(v, hint)
    }
    paint()

    input.addEventListener('input', function () {
      state[key] = clampByDef(def, input.value)
      // 数字框允许输入中间态（如先敲 "-"），但存储值始终是洗过的
      paint()
      scheduleSave()
      if (opts && opts.onAfter) opts.onAfter()
    })
    wrap._paint = paint
    return wrap
  }

  /** 自由文本控制项（负面提示词）：渲染成 textarea。 */
  function textField(label, key, opts) {
    var def = defsByKey()[key] || {}
    var wrap = el('div', 'cp-field' + (opts && opts.disabled ? ' cp-off' : ''))
    var top = el('div', 'cp-field-top')
    top.appendChild(el('span', 'cp-label', label))
    wrap.appendChild(top)
    var ta = el('textarea', 'cp-textarea cp-text')
    ta.rows = 2
    ta.placeholder = (opts && opts.placeholder) || ''
    ta.value = String(state[key] !== undefined ? state[key] : (def['default'] !== undefined ? def['default'] : ''))
    if (opts && opts.hint) ta.placeholder = ta.placeholder
    wrap.appendChild(ta)
    if (opts && opts.hint) wrap.appendChild(el('p', 'cp-hint', opts.hint))
    ta.addEventListener('input', function () {
      var raw = String(ta.value)
      state[key] = def.max && def.max > 0 ? raw.slice(0, def.max) : raw
      scheduleSave()
    })
    wrap._paint = function () { ta.value = String(state[key] != null ? state[key] : '') }
    return wrap
  }

  function render() {
    var modes = (schema && schema.modes) || []
    var ticks = aspectTicks()

    // 重建时复用已有浮标（否则每切一次模式就多一个按钮）
    // ⚠ 必须写 document.body，不能写 `body`——本函数后面有个 `var body` 是高级区容器，
    //   `var` 提升会让这里读到 undefined（这类错本套回归专门抓，它确实当场抓到了）。
    var fab = (nodes && nodes.fab) || document.body.querySelector('.cp-fab')
    if (!fab) {
      fab = el('button', 'cp-fab')
      fab.type = 'button'
      fab.appendChild(el('span', 'cp-fab-dot'))
      fab.appendChild(el('span', null, 'Comfy 控制'))
      document.body.appendChild(fab)
    }

    var panel = el('div', 'cp-panel')
    panel.hidden = true

    var head = el('div', 'cp-head')
    head.appendChild(el('h4', null, '通用 Comfy 控制层'))
    var x = el('button', 'cp-x', '×')
    x.type = 'button'
    head.appendChild(x)
    panel.appendChild(head)

    // 进度块（默认隐藏：没任务时不占地方）
    var progress = el('div', 'cp-progress')
    progress.hidden = true
    var track = el('div', 'cp-progress-track')
    var fill = el('i', 'cp-progress-fill')
    fill.style.width = '0%'
    track.appendChild(fill)
    progress.appendChild(track)
    progress.appendChild(el('span', 'cp-progress-note', ''))
    panel.appendChild(progress)

    var tabs = el('nav', 'cp-tabs')
    var tabEls = {}
    modes.forEach(function (m) {
      // ★ 2026-11-10：可用性由 /api/comfy-pipeline/modes 探测决定（TTS 装好就自动放行）。
      //   缺件时把 ttsMissingReport 的完整清单放进 title，不在 note 里塞一大段。
      var available = modeAvailability[m.id] !== false
      var b = el('button', 'cp-tab' + (m.id === state.mode ? ' is-on' : ''), m.label || m.id)
      b.type = 'button'
      b.title = available
        ? ('交付 ' + (m.deliver || ''))
        : (modeReason[m.id] || '后端工作流未接入，暂不可选')
      if (!available) b.disabled = true
      b.addEventListener('click', function () {
        if (!available) return
        state.mode = m.id
        Object.keys(tabEls).forEach(function (id) { tabEls[id].className = 'cp-tab' + (id === state.mode ? ' is-on' : '') })
        scheduleSave()
        // 切模式要重建 DOM：视频组的可用态依赖它（重建不动 state，不丢已拨的值）
        rebuild()
      })
      tabEls[m.id] = b
      tabs.appendChild(b)
    })
    panel.appendChild(tabs)

    var note = el('p', 'cp-note', '')
    panel.appendChild(note)

    var common = card('画面设置', 'cp-common')
    common.appendChild(field('画幅比例', 'aspect', { ticks: ticks }))
    common.appendChild(field('速度百分比', 'speedPercent', {
      hint: '',
      onPaint: function (v, hint) {
        if (!hint) return
        var d = describe({ aspect: state.aspect, speedPercent: v })
        hint.textContent = d + '（只压画幅像素预算，不改蒸馏步数 —— 不掉画质）'
      },
    }))
    // ★ 0.19.2：负面提示词升为一级可调（之前只藏在风格包里）。
    common.appendChild(textField('负面提示词', 'negative', {
      hint: '不想出现的东西：blurry、多余文字、畸变等。留空用模型默认。',
    }))
    panel.appendChild(common)

    // ★ 视频参数组：帧数与帧率**真接** generate_video（见 lib/video-workflow.js）。
    //   没切到视频模式时禁用，但仍展示——先看得见能拨什么，再决定切不切。
    var videoOn = state.mode === 'video'
    var vgroup = card('视频参数', 'cp-video-group')
    vgroup.appendChild(field('帧数', 'frames', {
      disabled: !videoOn,
      hint: videoOn ? '' : '先切到视频模式。',
      onPaint: function (v, hint) {
        if (!hint) return
        var f = Number(state.frames)
        var fps = Number(state.fps) || 24
        hint.textContent = f + ' 帧 @' + fps + 'fps ≈ ' + (f / fps).toFixed(2) + 's 成片（帧数自动对齐 4n+1）'
      },
    }))
    vgroup.appendChild(field('帧率 fps', 'fps', { disabled: !videoOn, hint: videoOn ? '' : '先切到视频模式。' }))
    vgroup.appendChild(field('运动幅度', 'motion', {
      disabled: true,
      hint: 'XT-5B 链没有运动幅度参数（只有提示词里写运镜）—— 不装能拨的假滑块。',
    }))
    panel.appendChild(vgroup)

    // ★ 素材库（用户定义：设计风格 + 用户指令 + 自行装载的 skill）
    var library = card('素材库', 'cp-library')
    library.appendChild(el('div', 'cp-field-label', '设计风格'))
    var styleSel = el('select', 'cp-select')
    styleSel.addEventListener('change', function () { saveLibrary({ selected: styleSel.value }) })
    library.appendChild(styleSel)
    library.appendChild(el('div', 'cp-field-label', '用户指令（每次生成都带上）'))
    var instr = el('textarea', 'cp-textarea')
    instr.rows = 2
    instr.placeholder = '例：不要卡通、要 35mm 胶片感'
    instr.addEventListener('change', function () { saveLibrary({ instruction: instr.value }) })
    library.appendChild(instr)
    library.appendChild(el('div', 'cp-field-label', '可装载的技能（请装载美术、画风、配色相关的 skill）'))
    library.appendChild(el('div', 'cp-skills'))
    library.appendChild(el('p', 'cp-hint cp-library-hint', ''))
    panel.appendChild(library)

    var adv = el('details', 'cp-card cp-adv')
    adv.appendChild(el('summary', null, '高级设置'))
    var body = el('div', 'cp-adv-body')
    body.appendChild(field('种子（-1 = 每次随机）', 'seed', { hint: '同提示词 + 同种子 = 同一张图；-1 每次都不一样。' }))
    body.appendChild(field('采样步数', 'steps', {
      hint: '仅在原生链路（textControl=native）真正按它采样；官方 Turbo 链固定 8/9 步蒸馏，会忽略本值。',
      warn: true,
    }))
    body.appendChild(field('提示词引导 CFG', 'cfg', {
      hint: '引导尺度。蒸馏链（Turbo）强制 1.0；原生链默认 2.5，可调。',
    }))
    body.appendChild(field('每轮张数', 'count', { hint: '同一次调用出多张只加载一次模型。' }))
    body.appendChild(field('降噪 denoise', 'denoise', { disabled: true, hint: '编辑链的降噪由任务链内部按 LoRA 工作点定，暂不由面板接管。' }))
    body.appendChild(field('VAE 分块 tileSize', 'tileSize', { disabled: true, hint: 'VAE 分块由优化开关接管，暂不走面板。' }))
    body.appendChild(field('分块重叠 chunkOverlap', 'chunkOverlap', { disabled: true, hint: '混合链分段拼接会读取本值（默认 8 帧重叠），面板暂不开放调节。' }))
    adv.appendChild(body)
    panel.appendChild(adv)

    var foot = el('div', 'cp-foot')
    var status = el('span', 'cp-status', '就绪')
    var reset = el('button', 'cp-reset', '恢复默认')
    reset.type = 'button'
    reset.addEventListener('click', function () {
      var defs = defsByKey()
      Object.keys(defs).forEach(function (k) {
        if (defs[k] && defs[k].type === 'text') state[k] = defs[k]['default'] != null ? defs[k]['default'] : ''
        else if (Number.isFinite(defs[k]['default'])) state[k] = defs[k]['default']
      })
      state.mode = 'image'
      syncInputs()
      scheduleSave()
      setStatus('已恢复默认值')
    })
    foot.appendChild(status)
    foot.appendChild(reset)
    panel.appendChild(foot)

    document.body.appendChild(panel)
    nodes = { fab: fab, panel: panel, status: status, note: note, progress: progress, library: library }
    return nodes
  }

  function syncInputs() {
    if (!nodes || !nodes.panel) return
    var wraps = nodes.panel.querySelectorAll('.cp-field')
    for (var i = 0; i < wraps.length; i += 1) {
      if (typeof wraps[i]._paint === 'function') wraps[i]._paint()
    }
    var inputs = nodes.panel.querySelectorAll('.cp-field input')
    for (var j = 0; j < inputs.length; j += 1) {
      // 用 _paint 的格子顺序对不上时，退化成"从 state 重新填一遍"
      void inputs[j]
    }
  }

  function refreshNote() {
    if (!nodes || !nodes.note) return
    var modes = (schema && schema.modes) || []
    var off = modes.filter(function (m) { return modeAvailability[m.id] === false })
    nodes.note.textContent = off.length === 0
      ? ''
      : off.map(function (m) { return (m.label || m.id) + '（' + (m.backends || m.chain || []).join(' / ') + '）'; }).join('、')
        + '：链里还有本插件没有的后端段，暂不可选。'
        + (modeReason.hybrid !== '' ? '（混合模式缺件清单见 tab 标题悬浮）' : '')
  }

  /** 重建面板 DOM（保留 state）。模式切换后视频组的 disabled 要变。 */
  function rebuild() {
    if (!nodes) return
    var wasOpen = nodes.panel.hidden === false
    try { nodes.panel.parentNode.removeChild(nodes.panel) } catch (err) { /* 已离体 */ }
    nodes = { fab: nodes.fab, panel: null, status: null, note: null, progress: null, library: null }
    render()
    if (wasOpen) open()
  }

  function open() {
    if (!nodes) return
    nodes.panel.hidden = false
    if (nodes.fab) syncPanelPos(nodes.fab, nodes.panel)
    refreshNote()
    startPolling() // 面板开着才轮询进度（关了就停，不白刷接口）
  }

  function close() {
    if (!nodes) return
    nodes.panel.hidden = true
    stopPolling()
  }

  /* ---------- 浮标拖动 ----------
   * 两个「点不动」根因一起修：
   *   ① 原开关绑在 click 上，而 click 是「按下+抬起+无拖动+无取消」的复合事件：
   *      指针轻移、文字被选中、或宿主在 pointerdown 上 preventDefault 都会让它不派发。
   *      改为在 pointerup 自行判定点按 —— 只要按下并抬起就一定有 pointerup，
   *      配合 setPointerCapture 把后续 move/up 锁到浮标，手势不再被吞。
   *   ② rebuild()（切模式）会换掉 nodes.panel，但旧开关闭包缓存了第一个 panel，
   *      之后它的 hidden 再不更新 ⇒ 判断永久卡在 close() 分支，面板再也打不开。
   *      toggle / 外部点击判定一律改读当前 nodes.panel，不缓存旧引用。
   * 位置存 localStorage；无 Pointer Events 的环境退化为「只点不拖」，按钮仍可用。
   * 所有宿主 API（localStorage / getBoundingClientRect / PointerEvent / setPointerCapture）
   * 都带 typeof 守卫，保证 node:vm 假 DOM 下 mount() 不抛错。
   */
  var FAB_POS_KEY = 'comfyPipelineFabPos'
  var DRAG_THRESHOLD = 5 // px：位移小于它算点按，否则算拖动

  function getStorage() {
    try { return (typeof window !== 'undefined' && window.localStorage) ? window.localStorage : null }
    catch (err) { return null }
  }
  function readFabPos() {
    var s = getStorage()
    if (!s) return null
    try {
      var p = JSON.parse(s.getItem(FAB_POS_KEY) || 'null')
      return (p && Number.isFinite(p.left) && Number.isFinite(p.top)) ? p : null
    } catch (err) { return null }
  }
  function writeFabPos(p) {
    var s = getStorage()
    if (!s) return
    try { s.setItem(FAB_POS_KEY, JSON.stringify(p)) } catch (err) { /* 配额 / 隐私模式 */ }
  }
  function vpSize() {
    var w = (typeof window !== 'undefined' && Number.isFinite(window.innerWidth)) ? window.innerWidth : 1280
    var h = (typeof window !== 'undefined' && Number.isFinite(window.innerHeight)) ? window.innerHeight : 800
    return { w: w, h: h }
  }
  function fabSize(fab) {
    return {
      w: Number.isFinite(fab.offsetWidth) && fab.offsetWidth > 0 ? fab.offsetWidth : 132,
      h: Number.isFinite(fab.offsetHeight) && fab.offsetHeight > 0 ? fab.offsetHeight : 40,
    }
  }
  /** 把 (left,top) 夹进视口并写到 style，返回夹后的坐标。 */
  function setFabPos(fab, left, top) {
    var vp = vpSize(), fs = fabSize(fab)
    var l = Math.min(Math.max(8, left), Math.max(8, vp.w - fs.w - 8))
    var t = Math.min(Math.max(8, top), Math.max(8, vp.h - fs.h - 8))
    if (fab.style) {
      fab.style.left = l + 'px'; fab.style.top = t + 'px'
      fab.style.right = 'auto'; fab.style.bottom = 'auto'
    }
    return { left: l, top: t }
  }
  /** 面板贴浮标：优先在浮标上方、右缘对齐，越界则改下方；用当前 nodes.panel。 */
  function syncPanelPos(fab, panel) {
    if (!panel || !panel.style) return
    var l = Number.parseFloat(fab.style && fab.style.left)
    var t = Number.parseFloat(fab.style && fab.style.top)
    if (!Number.isFinite(l) || !Number.isFinite(t)) return // 仍用 CSS 默认右下角
    var vp = vpSize(), fs = fabSize(fab)
    var pw = Math.min(392, vp.w - 16)
    var ph = (Number.isFinite(panel.offsetHeight) && panel.offsetHeight > 0) ? panel.offsetHeight : 420
    var px = Math.min(Math.max(8, l + fs.w - pw), Math.max(8, vp.w - pw - 8))
    var above = t - ph - 12
    var py = above >= 8 ? above : Math.min(t + fs.h + 12, Math.max(8, vp.h - ph - 8))
    panel.style.left = px + 'px'; panel.style.right = 'auto'
    panel.style.top = Math.max(8, py) + 'px'; panel.style.bottom = 'auto'
  }

  function toggle() {
    if (!nodes || !nodes.panel) return
    if (nodes.panel.hidden) open(); else close()
  }

  function wire() {
    var fab = nodes.fab
    var firstPanel = nodes.panel
    var x = firstPanel.querySelector('.cp-x')
    if (x) x.addEventListener('click', close)

    // 恢复上次拖动位置
    var saved = readFabPos()
    if (saved) setFabPos(fab, saved.left, saved.top)

    // 点面板外收起：读当前 nodes.panel（rebuild 换节点后仍成立），不缓存旧引用
    document.addEventListener('click', function (ev) {
      if (!nodes || !nodes.panel || nodes.panel.hidden) return
      if (nodes.panel.contains(ev.target) || fab.contains(ev.target)) return
      close()
    }, true)

    var hasPointer = (typeof window !== 'undefined' && typeof window.PointerEvent === 'function')

    // 键盘兜底：Enter / Space 自己开关，并阻止默认 click 造成重复
    fab.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter' || ev.key === ' ' || ev.key === 'Spacebar') {
        if (typeof ev.preventDefault === 'function') ev.preventDefault()
        toggle()
      }
    })

    if (!hasPointer) {
      fab.addEventListener('click', toggle) // 无 Pointer Events：不拖动，但按钮一定能点
      return
    }

    var press = null

    function originOf() {
      var l = Number.parseFloat(fab.style && fab.style.left)
      var t = Number.parseFloat(fab.style && fab.style.top)
      if (Number.isFinite(l) && Number.isFinite(t)) return { left: l, top: t }
      if (typeof fab.getBoundingClientRect === 'function') {
        var r = fab.getBoundingClientRect()
        if (r && Number.isFinite(r.left) && Number.isFinite(r.top)) return { left: r.left, top: r.top }
      }
      var vp = vpSize(), fs = fabSize(fab)
      return { left: vp.w - fs.w - 16, top: vp.h - fs.h - 16 }
    }

    fab.addEventListener('pointerdown', function (ev) {
      if (ev.button !== undefined && ev.button !== 0) return
      var o = originOf()
      press = { startX: ev.clientX, startY: ev.clientY, originLeft: o.left, originTop: o.top, dragging: false }
      if (typeof fab.setPointerCapture === 'function' && ev.pointerId !== undefined) {
        try { fab.setPointerCapture(ev.pointerId) } catch (err) { /* 忽略 */ }
      }
    })

    fab.addEventListener('pointermove', function (ev) {
      if (!press) return
      var dx = ev.clientX - press.startX, dy = ev.clientY - press.startY
      if (!press.dragging && Math.sqrt(dx * dx + dy * dy) < DRAG_THRESHOLD) return
      press.dragging = true
      if (fab.classList && typeof fab.classList.add === 'function') fab.classList.add('is-dragging')
      setFabPos(fab, press.originLeft + dx, press.originTop + dy)
      syncPanelPos(fab, nodes.panel)
      if (typeof ev.preventDefault === 'function') ev.preventDefault()
    })

    function finish(ev) {
      if (!press) return
      var dragged = press.dragging
      var p = dragged ? setFabPos(fab,
        press.originLeft + (ev.clientX - press.startX),
        press.originTop + (ev.clientY - press.startY)) : null
      press = null
      if (fab.classList && typeof fab.classList.remove === 'function') fab.classList.remove('is-dragging')
      if (typeof fab.releasePointerCapture === 'function' && ev.pointerId !== undefined) {
        try { fab.releasePointerCapture(ev.pointerId) } catch (err) { /* 忽略 */ }
      }
      if (dragged) {
        if (p) writeFabPos(p)
      } else {
        toggle() // 纯点按：由 pointerup 判定，不依赖会被吞掉的 click
      }
    }
    fab.addEventListener('pointerup', finish)
    fab.addEventListener('pointercancel', function () {
      press = null
      if (fab.classList && typeof fab.classList.remove === 'function') fab.classList.remove('is-dragging')
    })
  }

  function mount() {
    if (nodes) return Promise.resolve(nodes)
    return loadSchema()
      .then(function () { return Promise.all([loadControls(), loadModes()]) })
      .then(function (pair) {
        state = pair[0]
        render()
        wire()
        refreshNote()
        loadLibrary()
        setStatus('就绪 · ' + describe(state))
        return nodes
      })
  }

  /* ============================ 导出 ============================ */
  window.ComfyPipelinePanel = {
    __cp: true,
    mount: mount,
    open: open,
    close: close,
    getState: function () { return state ? JSON.parse(JSON.stringify(state)) : null },
    getModes: function () { return JSON.parse(JSON.stringify(modeAvailability)) },
    api: {
      clampByDef: clampByDef,
      quantize: quantize,
      speedEdge: speedEdge,
      speedRefs: speedRefs,
      aspectTicks: aspectTicks,
      buildPayload: buildPayload,
      describe: describe,
    },
  }

  // 自挂载：脚本是 defer 加载的，DOM 已就绪；宿主没准备好就等 DOMContentLoaded。
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { mount() })
  } else {
    mount()
  }
})()
