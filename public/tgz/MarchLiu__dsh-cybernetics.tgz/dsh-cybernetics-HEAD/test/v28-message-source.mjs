// Offline harness test for dsh-cybernetics v0.27.0: structured message-level
// reference anchors on revise audit records (docs/message-reference-design.md
// Phase 1). Covers:
//   - extractRevisionSource: canonical `dsh-session:<id>#seq=N[-M]` parsing,
//     inverted window rejection, non-reference text, first-match wins,
//     verbatim base64url token (no decoding),
//   - revise with a reference in the reason: the revisions-<goalId>.jsonl
//     audit line carries source { sessionId, fromSeq, toSeq, capturedAt },
//   - revise without a reference: no source key (byte-level backward compat
//     for old audit readers),
//   - the grep-back path: the JSONL is findable from (sessionId, seq).
// Run: node test/v28-message-source.mjs

import assert from 'node:assert/strict'
import { readFile, mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { apply } from '../src/index.ts'
import { extractRevisionSource, normalizeRevisionSource } from '../src/controller.ts'

// --- 0. normalizeRevisionSource -------------------------------------------------
{
  assert.deepEqual(
    normalizeRevisionSource({ sessionId: 's1', fromSeq: 3, toSeq: 9, capturedAt: 123 }),
    { sessionId: 's1', fromSeq: 3, toSeq: 9, capturedAt: 123 },
    '0a valid range + capturedAt passes through',
  )
  assert.deepEqual(
    normalizeRevisionSource({ sessionId: 's1', fromSeq: 3 }),
    { sessionId: 's1', fromSeq: 3 },
    '0b capturedAt absent: stays absent (revise stamps it)',
  )
  const bad = [undefined, null, 42, [], {}, { fromSeq: 1 }, { sessionId: 's' }, { sessionId: 's', fromSeq: 'x' }, { sessionId: 's', fromSeq: 5, toSeq: 4 }, { sessionId: '', fromSeq: 1 }]
  for (const b of bad) assert.equal(normalizeRevisionSource(b), undefined, `0c malformed rejected: ${JSON.stringify(b)}`)
  console.log('✓ 0 normalizeRevisionSource: valid passthrough + 9 malformed rejections')
}

// --- 1. pure extraction --------------------------------------------------------
{
  // Single message.
  assert.deepEqual(
    extractRevisionSource('用户要求按 dsh-session:abc123_-X#seq=42 修改目标'),
    { sessionId: 'abc123_-X', fromSeq: 42 },
    '1a single-seq reference parsed',
  )
  // Range.
  assert.deepEqual(
    extractRevisionSource('依据 dsh-session:A-b_C9#seq=42-57 重定目标'),
    { sessionId: 'A-b_C9', fromSeq: 42, toSeq: 57 },
    '1b range reference parsed (inclusive toSeq)',
  )
  // Inverted window is rejected (caller typo, not a reference).
  assert.equal(
    extractRevisionSource('dsh-session:abc#seq=57-42'),
    undefined,
    '1c inverted window rejected',
  )
  // No reference at all.
  assert.equal(extractRevisionSource('目标本身被校准'), undefined, '1d plain reason: no source')
  // First match wins.
  const first = extractRevisionSource('see dsh-session:aaa#seq=1 then dsh-session:bbb#seq=2-3')
  assert.equal(first.sessionId, 'aaa', '1e first match wins')
  // Verbatim token: base64url chars survive, nothing is decoded.
  const raw = extractRevisionSource('dsh-session:cxR9_-Ab#seq=7')
  assert.equal(raw.sessionId, 'cxR9_-Ab', '1f token kept verbatim (no decode)')
  // Malformed scheme without #seq is not a reference (whole-session mention).
  assert.equal(extractRevisionSource('见 dsh-session:abc 的快照'), undefined, '1g mention without fragment is not a message reference')
  console.log('✓ 1 extractRevisionSource: 7 pure-parse cases pass')
}

// --- shared end-to-end harness (same shape as v27) ------------------------------
const MET_ROUND = (round) => ({
  round,
  report: { summary: 's', done: true, artifacts: [], evidence: 'e', nextStepThoughts: [] },
  verdict: { met: true, criteria: [], gaps: [], goalItselfQuestionable: false },
  triage: { auto: [], defer: [], reject: [], human: [] },
})

async function makeTool({ noticePolicy = 'decision' } = {}) {
  const root = await mkdtemp(join(tmpdir(), 'cyb-v28-'))
  const engine = {
    runs: [],
    start() {
      let settle
      const result = new Promise((resolve) => { settle = resolve })
      this.runs.push({ result, settle: (v) => settle(v) })
      return { result, cancel: () => {} }
    },
  }
  const tools = []
  const parent = {
    session: { id: 's28-' + Math.random().toString(36).slice(2, 8) },
    status: 'idle',
    steer: () => {},
    followup: () => {},
  }
  apply({
    tools: { register: (d) => { tools.push(d); return () => {} } },
    systemPrompt: { section: () => () => {}, getSectionOrder: () => 0 },
    goals: { get: () => null, create: () => ({ id: 'goal-focused' }), disarm: () => {} },
    workingDirectory: { get: () => root },
    agentPresets: { serviceFor: (_a, n) => (n === 'workflowEngine' ? engine : undefined) },
    agents: { roots: () => [] },
    sessionProjections: { register: () => () => {} },
  }, { noticePolicy })
  return { tool: tools[0], parent, engine, root }
}

const drain = async () => { for (let i = 0; i < 20; i++) await new Promise((r) => setTimeout(r, 20)) }

// --- 2. revise with a reference: source lands in the audit JSONL ----------------
{
  const { tool, parent, engine, root } = await makeTool()
  const started = await tool.execute({ action: 'start', title: '引用锚点', brief: 'b' }, { agent: parent, signal: undefined })
  const reason = '用户引用 dsh-session:c2Vzc2lvbi0x#seq=42-57 后要求收紧验收口径'
  const revised = await tool.execute({ action: 'revise', goalId: started.goalId, reason }, { agent: parent, signal: undefined })
  assert.equal(revised.revised, true, '2a revise succeeded')
  assert.deepEqual(
    revised.source,
    { sessionId: 'c2Vzc2lvbi0x', fromSeq: 42, toSeq: 57, capturedAt: revised.revision.at },
    '2b revise result carries the structured source (capturedAt = revision time)',
  )
  await drain()
  const line = JSON.parse(await readFile(join(root, '.cybernetics', `revisions-${revised.goalId}.jsonl`), 'utf8'))
  assert.deepEqual(
    { from: line.from, to: line.to, source: line.source },
    { from: started.goalId, to: revised.goalId, source: revised.source },
    '2c audit JSONL carries the same structured source',
  )
  console.log('✓ 2 revise with reference: structured source in result + audit JSONL')
}

// --- 3. revise without a reference: no source key (backward compat) -------------
{
  const { tool, parent, engine, root } = await makeTool()
  const started = await tool.execute({ action: 'start', title: '无引用', brief: 'b' }, { agent: parent, signal: undefined })
  const revised = await tool.execute({ action: 'revise', goalId: started.goalId, reason: '目标本身被校准' }, { agent: parent, signal: undefined })
  assert.equal(revised.source, undefined, '3a no reference: no source in the result')
  await drain()
  const line = JSON.parse(await readFile(join(root, '.cybernetics', `revisions-${revised.goalId}.jsonl`), 'utf8'))
  assert.equal('source' in line, false, '3b no reference: audit line has no source key at all')
  console.log('✓ 3 revise without reference: zero source key (old readers unaffected)')
}

// --- 4. grep-back path: find the goal from (sessionId, seq) ----------------------
{
  const { tool, parent, engine, root } = await makeTool()
  const started = await tool.execute({ action: 'start', title: '反查', brief: 'b' }, { agent: parent, signal: undefined })
  await tool.execute(
    { action: 'revise', goalId: started.goalId, reason: '源于 dsh-session:Zm9v#seq=7 的新要求' },
    { agent: parent, signal: undefined },
  )
  await drain()
  // Simulate the reverse lookup: which revision cites this message?
  const { readdir } = await import('node:fs/promises')
  const files = (await readdir(join(root, '.cybernetics'))).filter((f) => f.startsWith('revisions-'))
  const hits = []
  for (const f of files) {
    const line = JSON.parse(await readFile(join(root, '.cybernetics', f), 'utf8'))
    if (line.source?.sessionId === 'Zm9v' && line.source.fromSeq === 7) hits.push(line)
  }
  assert.equal(hits.length, 1, '4a exactly one revision cites dsh-session:Zm9v#seq=7')
  assert.equal(typeof hits[0].to, 'string', '4b the hit names the successor goal')
  console.log('✓ 4 grep-back: (sessionId, seq) resolves to the revision and successor goal')
}

// --- 5. explicit source arg wins; anchor lands on the board + list + GUI view ---
{
  const { tool, parent, engine, root } = await makeTool()
  const started = await tool.execute({ action: 'start', title: '显式锚点', brief: 'b' }, { agent: parent, signal: undefined })
  // Explicit source + a reason that also embeds a DIFFERENT reference: the
  // explicit arg must win.
  const revised = await tool.execute(
    {
      action: 'revise', goalId: started.goalId,
      reason: '误 导 dsh-session:wrong#seq=1 的旧约定不再适用',
      source: { sessionId: 'right-session', fromSeq: 11, toSeq: 12 },
    },
    { agent: parent, signal: undefined },
  )
  assert.deepEqual(
    revised.source && { sessionId: revised.source.sessionId, fromSeq: revised.source.fromSeq, toSeq: revised.source.toSeq },
    { sessionId: 'right-session', fromSeq: 11, toSeq: 12 },
    '5a explicit source arg beats the reason-embedded reference',
  )
  // The successor board state carries the anchor.
  const listed = await tool.execute({ action: 'list' }, { agent: parent, signal: undefined })
  const entry = listed.board.find((g) => g.goalId === revised.goalId)
  assert.deepEqual(
    entry?.source && { sessionId: entry.source.sessionId, fromSeq: entry.source.fromSeq, toSeq: entry.source.toSeq },
    { sessionId: 'right-session', fromSeq: 11, toSeq: 12 },
    '5b list output carries the source anchor',
  )
  // The client projection (「目标」tab) carries it too.
  const { goalsFromBoard } = await import('../src/projection.ts')
  const boards = await import('../src/index.ts')
  // Re-fetch the board snapshot file to exercise the full persistence path.
  const snapshot = JSON.parse(await readFile(join(root, '.cybernetics', `board-${parent.session.id}.json`), 'utf8'))
  const snapGoal = snapshot.goals.find((g) => g.goalId === revised.goalId)
  assert.equal(snapGoal?.source?.sessionId, 'right-session', '5c board snapshot persists the anchor')
  // And the projection view renders it (client tab wire value).
  const view = goalsFromBoard([{ goalId: 'g', round: 0, doneSummary: '', subgoal: 's', role: 'default', source: revised.source }])
  assert.equal(view.goals[0].source?.sessionId, 'right-session', '5d GoalView projection carries the anchor')
  console.log('✓ 5 explicit source: arg precedence + board state + snapshot + projection view')
}

// --- 6. board snapshot round-trip: anchor survives a host restart ----------------
{
  const { tool, parent, engine, root } = await makeTool()
  const started = await tool.execute({ action: 'start', title: '重启往返', brief: 'b' }, { agent: parent, signal: undefined })
  const revised = await tool.execute(
    { action: 'revise', goalId: started.goalId, reason: '按 dsh-session:persist#seq=9 收紧', source: { sessionId: 'persist', fromSeq: 9, capturedAt: 1700000000000 } },
    { agent: parent, signal: undefined },
  )
  await drain()
  const snapshot = JSON.parse(await readFile(join(root, '.cybernetics', `board-${parent.session.id}.json`), 'utf8'))
  const snapGoal = snapshot.goals.find((g) => g.goalId === revised.goalId)
  assert.equal(snapGoal?.source?.capturedAt, 1700000000000, '6a explicit capturedAt survives in the snapshot')
  // restoreLoop is exercised through the module's exported loader.
  const { loadBoardFile } = await import('../src/index.ts')
  const restored = await loadBoardFile(root, parent.session.id)
  const back = restored?.find((g) => g.goalId === revised.goalId)
  assert.deepEqual(
    back?.source,
    { sessionId: 'persist', fromSeq: 9, capturedAt: 1700000000000 },
    '6b loadBoardFile round-trips the anchor byte-faithfully',
  )
  console.log('✓ 6 snapshot round-trip: anchor + capturedAt survive a restart')
}

console.log('\nv28 message-source: all sections passed')
