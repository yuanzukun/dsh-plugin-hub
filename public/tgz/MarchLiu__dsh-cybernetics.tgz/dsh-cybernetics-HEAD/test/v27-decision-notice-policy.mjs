// Offline harness test for dsh-cybernetics v0.26.0: decision-graded notices
// (noticePolicy 'decision', items ①–④ of the notice-noise improvement).
// Covers:
//   - legacy default noticePolicy 'insert' is byte-identical: every settled
//     background round sends a kind 'cybernetics' collect notice (compat),
//   - 'decision' + continue verdict: NO notice, the background path folds and
//     silently launches the next round (engine.runs grows),
//   - 'decision' + pause (human-input): exactly ONE notice, source kind
//     'cybernetics-round-notice', text carries the dsh-ui panel wait-card
//     instruction and the decision note, and the goal-round driver is
//     disarmed (goals.disarm called — item ④ driver dead-loop fix),
//   - superseded goal: no notice (existing guard, kept),
//   - cancelled goal: no notice (new guard, item ④),
//   - pauseNoticeText export: human-input/met/failed render the card
//     instruction; round-cap does not; continue renders '',
//   - relay: under 'decision' a queued kind 'cybernetics-round-notice' is
//     steered, the legacy kind 'cybernetics' is ignored (and vice versa).
// Run: node test/v27-decision-notice-policy.mjs

import assert from 'node:assert/strict'
import { apply, pauseNoticeText } from '../src/index.ts'
import { MODE_EVENT_TYPE, MODE_PROJECTION_KEY } from '../src/sessionMode.ts'

// Same fake-host shape test/v13-notice-auto-insert.mjs uses.
function fakeHost({ allGoalsMode = false } = {}) {
  const projections = new Map()
  const states = new Map()
  const listeners = []
  const commands = []
  const injections = []
  const ctx = {
    tools: { register: () => () => {} },
    projections: {
      register(definition) { projections.set(definition.key, definition); return () => {} },
    },
    sessionProjections: {
      register(definition) {
        projections.set(definition.key, definition)
        states.set(definition.key, new Map())
        return () => { projections.delete(definition.key) }
      },
      stateOf(session, key) { return states.get(key)?.get(session) },
    },
    states,
    on: (event, fn) => { listeners.push({ event, fn }); return () => {} },

    inject(names, cb) {
      injections.push({ names, cb })
      cb({ ...ctx, commands: { register: (d) => { commands.push(d); return () => {} } } })
    },
    systemPrompt: { section: () => () => {}, getSectionOrder: () => 0 },
    agents: {
      roots: () => [],
      get: (id) => undefined,
      list: () => [],
    },
  }
  apply(ctx, { allGoalsMode })
  const makeSession = (id) => ({
    id,
    header: allGoalsMode ? { parentSession: undefined } : { parentSession: 'parent-of-' + id },
  })
  return { ctx, projections, states, listeners, commands, injections, makeSession }
}

function enableMode(host, session) {
  const unit = host.projections.get(MODE_PROJECTION_KEY)
  const perSession = host.states.get(MODE_PROJECTION_KEY)
  if (!perSession.has(session)) perSession.set(session, unit.init())
  perSession.set(session, unit.apply(perSession.get(session), { type: MODE_EVENT_TYPE, data: { enabled: true } }))
}

const relayOf = (host) => host.listeners.filter((l) => l.event === 'agent/inbox/inserted').at(-1)

// Continue verdict for round N (verify passed with gaps → next round).
const CONTINUE_ROUND = (round) => ({
  round,
  report: { summary: `r${round}`, done: false, artifacts: [], evidence: 'e', nextStepThoughts: [] },
  verdict: { met: false, criteria: [], gaps: ['g1'], goalItselfQuestionable: false },
  triage: { auto: [], defer: [], reject: [], human: [] },
})
// Human-input pause verdict.
const HUMAN_ROUND = (round, question) => ({
  round,
  report: { summary: 's', done: false, artifacts: [], evidence: 'e', nextStepThoughts: [] },
  verdict: { met: false, criteria: [], gaps: [], goalItselfQuestionable: false },
  triage: { auto: [], defer: [], reject: [], human: [{ question }] },
})
const MET_ROUND = (round) => ({
  round,
  report: { summary: 's', done: true, artifacts: [], evidence: 'e', nextStepThoughts: [] },
  verdict: { met: true, criteria: [], gaps: [], goalItselfQuestionable: false },
  triage: { auto: [], defer: [], reject: [], human: [] },
})

async function runDecisionPath({ status = 'idle', settleWith, rounds = 1, noticePolicy = 'decision' } = {}) {
  const { mkdtemp } = await import('node:fs/promises')
  const { tmpdir } = await import('node:os')
  const { join } = await import('node:path')
  const root = await mkdtemp(join(tmpdir(), 'cyb-v27-'))
  const engine = {
    runs: [],
    start() {
      let settle
      const result = new Promise((resolve) => { settle = resolve })
      this.runs.push({ result, settle: (v) => settle(v) })
      return { result, cancel: () => {} }
    },
  }
  const steered = []
  const followups = []
  const disarmCalls = []
  const parent = {
    session: { id: 's27-decision-' + Math.random().toString(36).slice(2, 8) },
    status,
    steer: (m) => steered.push(m),
    followup: (m) => followups.push(m),
  }
  const tools = []
  apply({
    tools: { register: (d) => { tools.push(d); return () => {} } },
    systemPrompt: { section: () => () => {}, getSectionOrder: () => 0 },
    goals: {
      get: () => null,
      create: () => ({ id: 'goal-focused' }),
      disarm: (agent) => disarmCalls.push(agent),
    },
    workingDirectory: { get: () => root },
    agentPresets: { serviceFor: (_a, n) => (n === 'workflowEngine' ? engine : undefined) },
    agents: { roots: () => [] },
    sessionProjections: { register: () => () => {} },
  }, { noticePolicy })
  const tool = tools[0]
  await tool.execute({ action: 'start', title: '分级通知', brief: 'b' }, { agent: parent, signal: undefined })
  const drain = async () => { for (let i = 0; i < 20; i++) await new Promise((r) => setTimeout(r, 20)) }
  for (let i = 0; i < rounds; i++) {
    engine.runs[engine.runs.length - 1].settle({ stopReason: 'completed', value: settleWith(engine.runs.length) })
    await drain()
  }
  return { engine, steered, followups, disarmCalls }
}

// --- 1. legacy default 'insert': unchanged full-notice behavior ---------------
{
  const { steered, followups, disarmCalls } = await runDecisionPath({ settleWith: (r) => CONTINUE_ROUND(r), rounds: 1, noticePolicy: 'insert' })
  assert.equal(steered.length + followups.length, 1, "default 'insert': legacy collect notice still sent")
  const notice = steered[0] ?? followups[0]
  assert.equal(notice.source.kind, 'cybernetics', "default 'insert': legacy source kind")
  assert.equal(notice.content[0].text.includes('collect'), true, 'legacy text asks the agent to collect')
  assert.equal(disarmCalls.length, 0, "legacy 'insert' path: no disarm from the settle handler")
  console.log("✓ 1 default 'insert': legacy full collect notice preserved (backward compat)")
}

// --- 2. 'decision' + continue: silent fold, auto-relaunch, zero notice --------
{
  const { engine, steered, followups, disarmCalls } = await runDecisionPath({ settleWith: (r) => CONTINUE_ROUND(r), rounds: 1 })
  assert.equal(engine.runs.length, 2, "'decision' continue: next round launched in the background")
  assert.equal(steered.length, 0, "'decision' continue: no steered notice")
  assert.equal(followups.length, 0, "'decision' continue: no followup notice")
  assert.equal(disarmCalls.length, 0, "'decision' continue: driver stays armed")
  console.log('✓ 2 decision+continue: silent fold + auto-relaunch, zero notices')
}

// --- 3. 'decision' + human-input pause: ONE graded notice + driver disarm -----
{
  const { engine, steered, followups, disarmCalls } = await runDecisionPath({
    settleWith: (r) => (r === 1 ? CONTINUE_ROUND(r) : HUMAN_ROUND(r, '选择部署窗口')),
    rounds: 2,
  })
  assert.equal(engine.runs.length, 2, 'pause after round 2: no further auto rounds')
  assert.equal(steered.length + followups.length, 1, "'decision' human-input: exactly ONE notice")
  const notice = steered[0] ?? followups[0]
  assert.equal(notice.source.kind, 'cybernetics-round-notice', 'notice carries the new GUI folding kind')
  const text = notice.content[0].text
  assert.equal(text.includes('human-input'), true, 'text names the decision reason')
  assert.equal(text.includes('选择部署窗口'), true, 'text carries the decision note')
  assert.equal(text.includes('dsh-ui'), true, 'text instructs the dsh-ui wait card (item ②)')
  assert.equal(text.includes('"panel": true'), true, 'card instruction demands panel:true')
  assert.equal(disarmCalls.length, 1, 'pause: goal-round driver disarmed (item ④)')
  console.log('✓ 3 decision+human-input: one graded notice (dsh-ui card) + driver disarm')
}

// --- 4. superseded / cancelled goals: no notice of any kind --------------------
{
  const { mkdtemp } = await import('node:fs/promises')
  const { tmpdir } = await import('node:os')
  const { join } = await import('node:path')
  const root = await mkdtemp(join(tmpdir(), 'cyb-v27-guard-'))
  const engine = {
    runs: [],
    start() {
      let settle
      const result = new Promise((resolve) => { settle = resolve })
      this.runs.push({ result, settle: (v) => settle(v) })
      return { result, cancel: () => {} }
    },
  }
  const steered = []
  const followups = []
  const parent = {
    session: { id: 's27-guard' },
    status: 'idle',
    steer: (m) => steered.push(m),
    followup: (m) => followups.push(m),
  }
  const tools = []
  apply({
    tools: { register: (d) => { tools.push(d); return () => {} } },
    systemPrompt: { section: () => () => {}, getSectionOrder: () => 0 },
    goals: { get: () => null, create: () => ({ id: 'goal-focused' }), disarm: () => {} },
    workingDirectory: { get: () => root },
    agentPresets: { serviceFor: (_a, n) => (n === 'workflowEngine' ? engine : undefined) },
    agents: { roots: () => [] },
    sessionProjections: { register: () => () => {} },
  }, { noticePolicy: 'decision' })
  const tool = tools[0]
  const started = await tool.execute({ action: 'start', title: '守卫', brief: 'b' }, { agent: parent, signal: undefined })
  await tool.execute({ action: 'cancel', goalId: started.goalId }, { agent: parent, signal: undefined })
  engine.runs[engine.runs.length - 1].settle({ stopReason: 'completed', value: MET_ROUND(1) })
  for (let i = 0; i < 20; i++) await new Promise((r) => setTimeout(r, 20))
  assert.equal(steered.length, 0, 'cancelled goal: no steered notice')
  assert.equal(followups.length, 0, 'cancelled goal: no followup notice')
  // Under 'decision' the fold already happened silently (no handle left):
  // the board shows the folded outcome instead of a pending round.
  const listed = await tool.execute({ action: 'list' }, { agent: parent, signal: undefined })
  const entry = listed.board.find((g) => g.goalId === started.goalId)
  assert.equal(entry?.status, 'met', 'cancelled goal: outcome folded onto the board')
  assert.equal(entry?.running, false, 'cancelled goal: no handle kept after the silent fold')
  console.log('✓ 4 cancelled goal: silent decision fold, no notice, no handle')
}

// --- 5. pauseNoticeText: graded card instruction -------------------------------
{
  const loop = { goalId: 'g27', title: 'T', status: 'paused' }
  const human = pauseNoticeText(loop, 2, { action: 'pause', reason: 'human-input', note: 'n1' })
  assert.equal(human.includes('dsh-ui'), true, 'human-input renders the card instruction')
  const met = pauseNoticeText(loop, 2, { action: 'pause', reason: 'met', note: 'done' })
  assert.equal(met.includes('dsh-ui'), true, 'met renders the card instruction')
  const failed = pauseNoticeText(loop, 2, { action: 'pause', reason: 'failed', note: 'boom' })
  assert.equal(failed.includes('dsh-ui'), true, 'failed renders the card instruction')
  const cap = pauseNoticeText(loop, 3, { action: 'pause', reason: 'round-cap', note: 'cap' })
  assert.equal(cap.includes('dsh-ui'), false, 'round-cap stays plain text')
  assert.equal(cap.includes('round-cap'), true, 'round-cap still names its reason')
  const cont = pauseNoticeText(loop, 2, { action: 'continue', subgoal: 'x', note: 'n' })
  assert.equal(cont, '', 'continue decisions are silent (no notice text)')
  const wrap = human.startsWith('<cybernetics_round notice="cybernetics-round-notice">') && human.endsWith('</cybernetics_round>')
  assert.equal(wrap, true, 'notice wrapped in the versioned tag')
  console.log('✓ 5 pauseNoticeText: card instruction only for human-input/met/failed')
}

// --- 6. relay: 'decision' relocates the new notice kind, ignores the legacy kind
{
  const host = fakeHost({ allGoalsMode: true })
  apply(host.ctx, { allGoalsMode: true, noticePolicy: 'decision' })
  const relay = relayOf(host)
  const session = host.makeSession('s27-relay')
  enableMode(host, session)
  const mk = (id, kind) => {
    const calls = { removed: [], steered: [] }
    const agent = {
      id: 'agent-' + id, session, status: 'running',
      inbox: { nextTurn: [], nextStep: [], remove(x) { calls.removed.push(x); return true } },
      steer(m) { calls.steered.push(m) },
    }
    const message = { id, role: 'user', source: { kind, goalId: 'g1', round: 1 } }
    agent.inbox.nextTurn = [message]
    return { agent, calls, message }
  }
  const a = mk('rn-1', 'cybernetics-round-notice')
  relay.fn({ agent: a.agent, message: a.message })
  assert.deepEqual(a.calls.removed, ['rn-1'], "'decision': new-kind notice relocated")
  assert.equal(a.calls.steered.length, 1, "'decision': new-kind notice steered")
  const b = mk('lg-1', 'cybernetics')
  relay.fn({ agent: b.agent, message: b.message })
  assert.equal(b.calls.removed.length, 0, "'decision': legacy kind ignored (no double policy)")
  console.log("✓ 6 relay under 'decision': kind 'cybernetics-round-notice' steered, legacy kind untouched")
}

console.log('v27 decision-notice-policy: all sections passed')
