# 演进历史 / Changelog

> 本文件承接自项目早期的 README「状态」与「实测修正」记录，按版本倒序整理。
> 当下的功能与使用方式以 [README.md](../README.md) 为准；协议细节见 [protocol.md](protocol.md)。
> 约定：`src/` 改动需宿主重载生效；`lib/client.js` 改动需重启宿主（客户端模块图在宿主启动时构建）并刷新浏览器；`workflows/round.js` 改动热生效。

## v0.20.0（2026-11-07）：控制模式状态指示统一——静止整环/旋转缺口环、pill 计数语义「停止数/总数」、状态提示位置配置

**背景（用户多轮反馈）**：控制模式 pill 的运行指示器从绿点演进为圆环后，仍有三处体验问题——空闲态仍是实心绿点与运行态形状不一致；pill 与提示条（ComposerHint）文案/指示器各说各话；缺少「状态提示显示在哪」的配置入口。本轮统一收敛。

- **运行指示器统一为圆环（`lib/client.js`）**：新增共享渲染器 `renderModeRing(running, color)`——14×14 盒、`viewBox 0 0 14 14`、`circle cx/cy=7 r=6 stroke 2`、`MODE_ON_COLOR #3fb950`（尺寸先浏览器实测 GUI 既有 context 圆环后取整）；`running=true` 为缺口环（`strokeDasharray '28.3 9.4'`，3:1 缺口）+ 3s/圈旋转动画类，`running=false` 为静止完整整环（无 dasharray、无动画）。语义：**静止整环 = 开但空闲；转动缺口环 = 运行中**。ModePill 空闲态由实心绿点改为静态整环；关闭/未加载态维持灰色实心圆点；`prefers-reduced-motion` 下运行态静态呈现。
- **pill/提示条文案统一（`lib/client.js`）**：新增纯 reducer `countGoals(board)`（返回 `{stopped, total}`：stopped = total − running 并 clamp 到 [0,total]，畸形输入降级 `{stopped:0,total:0}` 绝不抛错，已导出）；ModePill 与 ComposerHint 可见文案统一为「控制模式：{stopped}/{total}」（zh）/ "Control {stopped}/{total}"（en），分子为**停止数**（settle 的目标数）而非运行数；ComposerHint 原 6px hintDot 换成同一 `renderModeRing`，原 insert/queue 长文案移入 title/aria-label 作 tooltip，`role:'note'` 与 `data-cybernetics-hint` 保留；未知/未就绪态显示「控制模式：…」。
- **新增配置字段 `hintLocation`（`src/index.ts` + `lib/client.js`）**：`'both' | 'pill' | 'composer' | 'none'`，默认 `'both'`，声明为 volatile；客户端 `readHintLocation` 快照读取器（未加载/旧宿主/畸形值一律回退 `'both'`）；ModePill 在 `'none'/'composer'` 时不渲染、ComposerHint 在 `'none'/'pill'` 时不渲染（均在全部 hooks 之后 early-return，不破坏 hook 顺序）；设置卡片新增 kind:'enum' 下拉行「状态提示位置」。
- **测试**：`test/v12-mode-pill-running.mjs` 重写为 stopped 语义 + 三态圆环断言（空闲整环无动画类/运行态缺口旋转/关闭灰点）+ 30 个 mode.* locale 键两侧一致性；新增 `test/v21-hint-location.mjs`（readHintLocation 回退矩阵、两组件门控、统一渲染、schema 声明）；`test/v03-offline.mjs` volatile 字段清单更新为 17 个。全仓 15 个离线测试全绿，`node --check lib/client.js` OK。
- **生效手段**：`lib/client.js` 改动需重启宿主 + 刷新浏览器；`src/index.ts` 改动宿主重载生效。

## v0.19.1（2026-11-07）：预置方案模型命名校准——对齐厂商官方 API id 与本部署模型目录

**背景（用户反馈）**：选择厂商方案普遍报错——卡片显示「该模型已不在当前系统模型列表中，运行时将回退到 session agent 模型」。根因：`VENDOR_PRESETS` 注册表中大量 `provider/model` 是商品名/编造名或未对齐本部署渠道（如 `deepseek/V4-Pro`、`anthropic/Sonnet-5.5`、`volcano/Seed-2.1-lite`、`moonshot/kimi-k3.1-pro-highspeed`），而厂商方案的 apply 路径把该字符串直接写入扁平模型字段、不做目录校验，名字必须事先正确。本轮以「本部署实时模型目录（2026-11-07 经 preset_recommend 第一跳实测）+ 各厂商官方 API 模型列表」为唯一基准做逐厂商调研并全表校准。

- **注册表（`src/modelPresets.ts`）**：结构与行为零变更（接口/variants 数量与 id/status/PRESET_IDS/session 范围裁定/ALLOWED_OP_PATHS/reasoningEffort 取值一律不动），只改数据与文案：
  - **目录内四家族逐字对齐**：DeepSeek provider `deepseek`→`deepseek-official`，模型 `V4-Pro`/`V4-Flash`→`deepseek-v4-pro`/`deepseek-flash`（官方现行 API id 仅此两个，旧 R1/V3.2 兜底移除并披露）；Kimi provider `moonshot`→`kimi`，`kimi-k3.1-pro-highspeed`→`kimi-for-coding-highspeed`、verify `kimi-k3`→`k3`、最高验收档 `kimi-k3.1-pro`（部署目录不存在，不编造）→就近替换 `k3-256k` 并在 note/rationale 披露；火山 provider `volcano`→`bza-plan`，`Seed-2.1-pro/Seed-2.1-lite/Seed-2.0-mini/Seed-Evolving`→`doubao-seed-2.1-pro/doubao-seed-2.1-lite/doubao-seed-2.0-mini/doubao-seed-evolving`；GLM（`zai-coding-cn/glm-5.3(-flash)`）与本部署逐字一致，保持不变。
  - **目录外五厂商对齐官方 API id**：Anthropic 商品名形式更正为官方小写连字符 API id——`Sonnet-5.5`/`Opus-5.5`/`Haiku-5.5`/`Fable-5.1`→`claude-sonnet-5-5`/`claude-opus-5-5`/`claude-haiku-5-5`/`claude-fable-5-1`（调研证实 Fable 5.1 为真实产品线，非编造；deepseek 外置 verify 变体引用同步）；Qwen `qwen-plus`/`qwen-max`/`qwen-turbo`→官方当前推荐代际 `qwen3.7-plus`/`qwen3.8-max`/`qwen3.8-flash`（qwen-turbo 已下架由 flash 系接替、qwen-max 旧版 32k 无思考档，「Turbo 幻觉共振」警示改指 Flash 档）；OpenAI `gpt-6.1-sol`/`gpt-6-luna`/`gpt-6-astra` 与 Gemini `gemini-flash-latest`/`gemini-pro-latest`、Minimax `MiniMax-M3`/`MiniMax-M3.1-Flash` 经官方文档核对均为真实现行 id，保持不变。五厂商 note 统一追加「本部署目录未含该厂商，需部署侧具备对应 provider 方可应用」；五个 id 有出处的条目新增 `source` 字段（官方文档 URL，卡片与交办单渲染「来源」）。
- **测试（`test/v17-model-presets.mjs`）**：旧名断言全部更新（qwen 系 turbo/plus/max→flash/plus/max 新代际、claude demanding `Fable-5.1`→`claude-fable-5-1`、volcano `volcano/Seed-2.1-lite`→`bza-plan/doubao-seed-2.1-lite`、Qwen note 警示 `/Turbo/`→`/Flash/`）；section (1) 新增 v0.19.1 命名核对断言组（deepseek-official / kimi / bza-plan provider 逐字命中、就近替换披露、五厂商部署 note 存在）。全量离线测试全绿。
- **文档**：README 中英文未引用旧模型名，无需改动；历史 CHANGELOG 条目不回改。
- **生效手段**：`src/` 改动宿主重载生效（厂商方案是服务端内置数据，客户端下拉 id 不变）。

## v0.19.0（2026-11-07）：预置方案支持「自定义方案」（保存/覆盖/删除/分区显示/一键应用）

- **存储（`src/modelPresets.ts` 新增 + `src/index.ts` 新字段）**：新增 volatile 配置字段 `customPresets`（缺省 `''`），以单个 JSON 数组（`CustomPreset[]`：`{id, name, at, roles:{task/verify/triage}}`）保存用户组合——宿主把 volatile 写入落进 profile 的用户 patch 行，重启后仍在；缺省空串对旧配置/旧读者完全向后兼容。配套纯函数：`captureCustomRoles`（从卡片六个平铺字段捕获组合，空白字段丢弃、`provider/model` 按 `/` 拆分）、`parseCustomPresets`/`serializeCustomPresets`（防御式解析：损坏载荷降级为空列表，绝不 throw；非 task/verify/triage 角色键——含 session——永不成为条目角色）、`customPresetAsVendor`（把自定义条目适配成 VendorPreset 形状，复用 `vendorPresetApplyOps` 构建 ops，六字段 `ALLOWED_OP_PATHS` 边界与内置方案完全一致）。
- **选择处理（`src/index.ts`）**：`presetPlan` 由固定 union 放宽为自由字符串（v0.19 起接受 `custom:<id>`）；`handlePresetSelection` 在内置查找前新增自定义分支：从 `customPresets` 解析条目→适配→应用 ops→写 ok 记录（label=用户命名，notes 带 session-scope 声明）；条目已被删除时写 degraded 记录「自定义方案不存在」，未知 id 与以往一样 warn 后忽略。内置厂商方案是代码内置数据，不经该字段，结构上不可覆盖/删除。
- **客户端（`lib/client.js`）**：预置方案下拉在内置 10 项之后渲染禁用的分割项「── 自定义方案 ──」，其下为自定义方案（值 `custom:<id>`，label=名称）；下拉下方新增「保存为自定义方案」按钮——`window.prompt` 命名、重名时 `window.confirm` 确认覆盖（覆盖保留原 id，选择器始终有效）；选中自定义方案时出现「删除」按钮——`window.confirm` 确认后单次 combine mutate 同时改写列表并 unset 选择器。zh/en 各新增 8 个 locale 键，hint 文案说明自定义方案。保存仅写 `customPresets` 字段，结构上不可能触及内置方案。
- **测试**：`test/v17-model-presets.mjs` 新增（13）自定义方案全链路（捕获/解析/序列化/ops 边界/handler 应用/缺条目降级），（12）卡片段更新为 12 选项+分割项断言并新增保存/覆盖确认/删除合并写入/取消不写入四组交互流；(12) locale 键清单加新键。`test/v03-offline.mjs` 两处 volatile 表单字段清单 15→16（+`customPresets`）。全仓 14 个离线/探针测试全绿；`tsc --noEmit` 除既有基线（.ts 扩展导入 TS5097、peer 模块 TS2307）外零新增错误。

## v0.18.4（2026-11-06）：预置方案注册表新增第 9 家厂商「GLM」

- **注册表（`src/modelPresets.ts`）**：`PRESET_IDS` 追加 `'glm'`（minimax 之后）；`VENDOR_PRESETS` 末尾新增完整 `ready` 条目，provider 一律 `zai-coding-cn`。两个变体：**标准组合** = task `glm-5.3-flash`(effort high，可升 glm-5.3 max) / verify `glm-5.3`(effort max) / triage `glm-5.3-flash`(effort low)；**重活命名角色（frontend 等）** = task/verify `glm-5.3`(effort max) / triage `glm-5.3-flash`(effort low)。session 参考项 `glm-5.3`(effort high)，仅展示不应用。vendor note 写明：命名角色的 max effort 只按需生效（智能选择命中难 subgoal 时），避免全量 max。`roles === variants[0].roles` 镜像不变量由既有归一化循环自动保证。
- **客户端（`lib/client.js`）**：zh/en 两处 i18n 各加 `settings.preset.optGlm`；`PRESET_CHOICES` 注册 `{ id: 'glm', labelKey: 'settings.preset.optGlm' }`；两处 `presetPlanHint` 文案「八家厂商」改「九家厂商」并追加 GLM。
- **服务端（`src/index.ts`）**：`presetPlan` 字段 description 的厂商清单追加 GLM。
- **测试（`test/v17-model-presets.mjs`）**：厂商数 8→9；`expectedVariants` 加 `glm: 2`；新增 GLM 断言（task `glm-5.3-flash`/high、triage low、verify `glm-5.3`/max、provider `zai-coding-cn`、重活变体 task `glm-5.3`、note 按需语义）；locale 键清单加 `settings.preset.optGlm`。
- **文档**：README 中英文预置方案小节改为 10 选项 / 9 家厂商并列举 GLM 变体。
- **生效手段**：`src/` 改动宿主重载生效；`lib/client.js` 改动需重启宿主 + 刷新浏览器。

## v0.18.3（2026-11-06）：顶部「对话」入口改为「回到主 agent 对话」——跨会话回主页导航

**背景（用户重启后实测）**：「刚才在主 agent 的目标页点击返回对话，返回主 agent，这是对的，但是我在子 agent 的目标页点击返回对话，进入的也是子 agent，这不对……无论在哪个 agent 的目标页点击最顶端的那个返回，都应该回到主 agent 的对话页，这相当于 web 站的『回到主页』导航。」v0.18.1 的入口调用的是 `openView('chat', …)`，而会话内「当前页签」是 **per-session** conversation store 的 `view` 字段（persist 键 `dsh.conversation.<sessionId>`），所以子 agent 页签上的点击只会切换**子会话自己**的视图——语义上像页签切换，不是主页导航。宿主**没有**「按 sessionId 选择另一个会话视图」的插件 API，跨会话只能「先切到根会话 + 根会话里我们的视图消费一次性请求并调用自己的 `openView`」。

- **根会话解析（`homeSessionOf(list, sessionId)`，可导出）**：复用 v0.18 的 `ancestorSessions`（`byId[id].parentId` 优先、`subagentCatalog` 兜底、visited 防环、16 跳上限），取祖先链**最后一个**元素即根 session；链为空或无会话列表时返回 `sessionId`（当前会话即根）。不抛错。
- **一次性 home 请求通道（模块级 `HOME_REQUESTS`）**：`requestHome(sessionId)` 记录时间戳；`consumeHomeRequest(sessionId)` 读取即删除并返回 boolean，超过 **4000 ms** 视为过期（同样清除），非法/空 id 直接 false。模块是页面单例，切会话后状态仍在——这正是两段式导航的载体。
- **入口点击两段式（`ConversationEntry`）**：`home = homeSessionOf(list, sessionId)`；`home === sessionId` → 一步 `openView('chat', 'cybernetics-home')`（根会话行为与 v0.18.1 等价）；否则 `requestHome(home)` 后调用 inject 新注入的 `props.openHome(home)`（`ctx.uiWorkspace.openSession(id)`，`SessionTarget = SessionId | SubagentAddress`，字符串即根会话 id，已核 rc.3 的 `replaceMain → sessions.retain → resolveTarget` 对字符串的处理）。`openHome` 缺失（旧宿主无 uiWorkspace）→ 降级为当前会话视图切换，不再有跨会话跳转；`openView` 缺失 → 入口整体不渲染（旧行为）；`openHome` 抛错 → 兜底当前会话切换，点击绝不变成死键。
- **消费点（`GoalView` / `ControlView`）**：各加一个无依赖数组的 `react.useEffect(function () { if (consumeHomeRequest(props.sessionId) && typeof props.openView === 'function') props.openView('chat', 'cybernetics-home'); })`。GoalView 的所有分支（多目标自板 / v0.18 祖先板 / 单 goal / 空板 / 投影在途）都经过该组件，故一处覆盖；ControlView 同点消费（根会话上次停在控制页也能回 chat）。读即删保证只触发一次，重复渲染与 StrictMode 双执行都安全；请求只对目标 sessionId 生效，不会跨会话误触发。
- **已知限制（写入 README）**：跨会话切换「视图」依赖根会话**挂载我们的视图**；若根会话当下显示的是别的视图（chat 本身、或第三方页签），消费点不挂载，请求 4 s 后自然过期——用户仍会被切到根会话，只是视图停在根原本的状态（这仍优于 v0.18.2 的「回到子 agent chat」）。此外整个链路需要**重启宿主 + 刷新浏览器**才加载新的客户端模块。
- **文案**：`view.chatEntryHint` 改为「回到主 agent 的对话」/ `Back to the main agent's conversation`（zh/en 键集仍逐字成对）；入口标签保留「对话 / Conversation」而不改叫「主页」——目的地就是对话视图，且与宿主页签命名一致，避免同一个 chat 出现两种叫法；hint 明确写出「主 agent」以消除 v0.18.2 的歧义。
- **测试**：新增 `test/v20-home-entry.mjs`（(a) `homeSessionOf` 多级链 / catalog 兜底 / 环 / 无 list / 空 id；(b) 根会话点击只调 `openView('chat','cybernetics-home')`、不调 openHome、不留请求；(c) 子会话点击 `openHome(rootId)` 一次且此刻不调 openView（孙代同样取根）、根 GoalView 消费后 `openView` 恰好一次、二次渲染不重复、他会话请求不误触发、超过 4 s 过期不触发；(d) 控制页签同样消费、无 openView 不渲染不抛错、无 openHome 降级当前会话且不留请求、openHome 抛错被兜底；(e) 请求/消费原语（非法 id、读即删、TTL 边界 4000/4001 ms）；(f) 回归：入口仍在内容第一行、GoalRow props 与 chips 行为不变）。`test/v19-conversation-entry.mjs` 保留原 10 组覆盖，按新语义更新文案与 focus 断言（根会话/祖先板无 openHome 时走一步链路）。`test/v03-offline.mjs` 的 fake react 补 `useEffect` 存根（新 hook 是必需的；组件必须无条件调用 hook）。全量复跑 v03（75 项）/ v09–v20 全绿；`node --check lib/client.js` 通过；`effort-patch/patch-v2.mjs check` = 0/22 anchor ready、0 failure（locale 尾部改动不触碰 v0.15 effort 补丁段）。
- **生效手段**：仅客户端改动（`lib/client.js`），**重启 DSH 宿主 + 刷新浏览器**后生效。本轮未自行重启宿主（工作纪律），证据为离线渲染断言与宿主源码核证；用户重启后按执行报告步骤复核。

## v0.18.2（2026-11-06）：删除「自动推荐所用模型」配置——auto 推荐改为 session agent 交办（零独立 LLM 调用）

**用户裁定（原话）**：「我要求删除的是『自动推荐所用的模型』这个配置，开启自动配置时，不应该在另外调用其它 Agent 来选择 sub agent 配置，而是直接让 session agent 在自己的 context 中读取可用的模型列表，给出答案。」补充理由：另起一次调用等于把 context 再提交一遍，时间和经济性上都不合理。

- **删除（配置项）**：「自动推荐所用模型」配置项（schema 字段名见 git 历史）彻底移除——schema 字段（`src/index.ts`）、Config 接口字段、客户端卡片「自动推荐所用模型」输入框与其 zh/en locale 键（`lib/client.js`）、README 中英文提及、测试字段清单与断言（v17/v03）全部清除；全仓库 grep 该字段名零命中（测试里的否定断言用运行时拼名，不携带字面量；历史条目中的字段名改写为描述语，本条目同理）。`src/modelPresets.ts` 依赖该字段的整条调用链一并删除：`pickRecommendRoute`（显式路由 + 顶配档推导）、`callLlmOneShot`（`ctx.llm.prepareCall().stream()` 一次性调用）、消息构造与 text-delta 收集器、`recommendModels` 编排器——插件侧不再有任何模型补全调用面。
- **重写（auto 流程 = session agent 交办）**：选择「根据现有配置自动推荐」时，插件探测实时目录 → `buildRecommendationBrief` 构建交办单（系统侧输出契约 + 目录/原则/当前配置/厂商参考 + 两跳作答协议，目录空则直接 `degraded`）→ 写入 `pending` 结果记录（卡片显示已交办）→ 向在线顶层 session agent（`ctx.agents.roots()`，跳过委派子代理）投递 steer/followup 提醒。session agent 在**自己的上下文**中读取目录并作答，经插件注册的 `preset_recommend` 工具（`ctx.tools.register`，与 cybernetics 工具同面、硬门禁 allowlist 下同被保留）完成两跳：第一跳（无 `recommendation` 参数）返回交办单；第二跳（携带推荐 JSON）由插件校验并写入——`parseRecommendation`（逐字命中目录、session 键丢弃并注明）→ `validatePickEfforts`（effort 支持性软校验）→ `recommendationApplyOps`（六扁平字段围栏）→ `writePresetRecord`（结果记录同一写路径）。不可用的答案回执具体原因给 session agent 修正重交，不写入任何模型字段。工具可独立使用（会话中直接请求自动推荐亦走此径）；`PresetRecommendationRecord` 状态新增 `pending`，删除仅由旧 auto 路径写入的 `route` 字段。
- **约束保持**：`ALLOWED_OP_PATHS` 仍恰好六个扁平子 agent 字段（session 配置结构性不可达，测试继续钉死）；8 家厂商方案数据与 `vendorPresetApplyOps` 逻辑原样未动；smartAgentModelSelection 行为不变；门禁 allowlist keep 集新增 `preset_recommend`（与 cybernetics 工具并列）。
- **测试**：`test/v17-model-presets.mjs` 重写 (2)/(7)/(8)/(11)、新增 (9)：(2) 交办单内容契约；(7) **零调用证据**——间谍 llm 面 `prepareCall` 计数器在 brief 构建 + 答案校验全流程后恒为 0（并保留全部降级语义断言）；(8) auto 分支在 `prepareCall` 直接抛错的面下仍产出 `pending` 记录（若有隐藏调用必然爆响且降级）且仅写一条记录、零模型字段；(9) 工具两跳往返（brief/applied/rejected/degraded）+ 门禁装配瀑布下 `preset_recommend` 与 cybernetics 一同存活；(12) 卡片 pending 渲染 + zh/en locale 完整 + 客户端源零残留。`test/v03-offline.mjs` volatile 字段清单 16→15。全量复跑 v17 / v03（75 项）/ v09–v16 全绿；`tsc --noEmit` 无新增错误。
- **文档**：README 中英文「预置方案」小节改写（删字段、写明交办机制与 pending 语义）；`package.json` → 0.18.2。
- **生效手段**：`src/` 改动宿主重载生效；`lib/client.js` 改动需重启宿主 + 刷新浏览器。本轮未重启宿主（见执行报告）。

## v0.18.1（2026-11-06）：「目标 / 控制」页签顶部新增「对话」入口——一键切回会话对话视图

**背景**：在「目标」页签点「关联智能体」chip 进入子 agent 会话后，从子 agent 视图顶部 pill 点主 agent 回到根会话时，会话视图会恢复上次选中的「目标」页签——用户停在目标页签而不是主对话，还需再点顶部「对话」页签才能回去。本轮在「目标」「控制」页签内容的最上面加一个页签样式的「对话」入口，一键把**当前会话**的会话视图切回 chat（SPA 内切换：不刷新页面、不改 URL、不重开会话、不新增服务端 API）。

- **入口（lib/client.js 的 `ConversationEntry`）**：原生 button（键盘可达 + aria-label「对话 · 返回会话智能体的对话」），沿用既有内联 style 体系（rgba hairline 边框、inherit 颜色、`font: 'inherit'`），内容第一行、shrink-wrap 不遮挡既有内容。Seam：conversation.view 渲染层给每个视图组件注入 owner prop `openView(view, focus)`（@deepseek-ai/dsh-client-ui-conversation 的 slots.d.ts ConversationViewProps；实现先校验已注册视图再 activateView + actions.openView，owner props 在 inject props 之后合并、owner 胜出）；chat 视图注册 id 固定 `'chat'`（@deepseek-ai/dsh-client-ui-chat）。点击回调 `openView('chat', 'cybernetics-goal')`（控制页签传 `'cybernetics-control'`）。**守卫**：`typeof props.openView !== 'function'` 时组件返回 null——旧宿主不渲染入口、绝不抛错，且 GoalsList/SingleGoalView 的 children 序列保持与改动前一致。已知宿主语义（接受，不处理）：openView 会顺带写 viewRequest，而 chat 视图不消费该字段——宿主既有行为，本插件不触碰。
- **放置（GoalView 全部分支）**：多目标自板 / v0.18 祖先板 / 单 goal 回退 / 空板 / 投影未到达（该状态原来什么都不渲染）五种状态下入口都出现在内容第一行且可点（GoalsList 以 `leading` prop 首插；SingleGoalView 空板分支改挂 root 列，空态文案不再自带 padding）。ControlView 顶部同样加入口，保持两页签一致。
- **文案**：zh/en 成对新增 `view.chatEntry`（对话 / Conversation）与 `view.chatEntryHint`（返回会话智能体的对话 / Back to the session agent conversation）。
- **测试**：新增 `test/v19-conversation-entry.mjs`（10 组：zh/en 键集配对与逐字文案、多目标自板入口在首行且点击 `openView('chat', 'cybernetics-goal')`、英文文案、无 openView 时不渲染且不抛错 + GoalRow props 与 children 序列不变、单 goal / 空板 / 投影在途三个回退分支、祖先板入口在 banner 之上、控制页签入口与独立 focus、入口可见时 goal 行与「关联智能体」chips 行为不变）。`node --check lib/client.js` 通过；`effort-patch/patch-v2.mjs check` = 0/22 anchor ready、0 failure（词典尾部新增不触碰 v0.15 effort 补丁段，补丁表仍逐字同步）。
- **回归**：`test/v03-offline.mjs` 在隔离副本（`git archive HEAD src test workflows` + 本轮 lib/client.js + node_modules 软链）75 项全绿；工作区内 v03 第 1 组失败源于同仓另一并发任务的 src/index.ts 未提交中间态（与本客户端改动无关——v03 只 import src/，不读 lib/client.js；其第 57 组断言也是该并发任务改到一半的测试文案）。v09/v10/v12/v13/v14/v15/v16/v17/v18 在工作区全绿。
- **生效手段**：`lib/client.js` 改动需 **重启 DSH 宿主 + 刷新浏览器**（客户端模块图在宿主启动时构建）。本轮未自行重启宿主，证据为离线渲染断言；重启后打开任一会话的「目标」页签即可复核。

## v0.18.0（2026-11-06）：子智能体会话复用祖先 goal 板（「目标 / Goal」页签 + 焦点滚动 + 跳转修正）

**背景**：workflow 的 task/verify/triage 子会话与 Agent Teams teammate 都是各自的会话，自身的 `cyberneticsGoals` 板为空，打开它们的「目标 / Goal」页签只有空态。而用户往往正是从这些子会话里想跳到别的 agent。**用户裁定**：子会话的目标页显示整个 session 的目标页（沿父链取最近的非空祖先板，通常即主会话），并把焦点滚动到「自己的目标项」，以便随时跳转到当前会话的其它 agents。

- **板解析（lib/client.js 的 GoalView/GoalsList）**：本会话自板 `goals.length > 0` → 完全维持 v0.17.3 行为（自板、无提示行、无自动滚动）；否则经 `ctx.sessions.list`（`useSyncExternalStore` 订阅，列表/投影晚到会自动出现；list 缺失或无 subscribe 时安全回退旧行为）沿父链上溯最近的非空祖先板。父链解析：优先 `byId[id].parentId`（会话 header.parentSession），缺失时扫描各会话 `projectionsBySession[*].values.subagentCatalog` 中 `entry.id === id` 的条目得到父会话（与 dsh-client-ui-subagent 同法），visited 防环 + 最多 16 跳；板值取 `projectionsBySession[ancestor].values.cyberneticsGoals`，兜底 `byId[ancestor].projectionValues.cyberneticsGoals`。找不到非空祖先板 → 保持原空态回退（SingleGoalView/noGoal），绝不抛错。
- **焦点与滚动**：在展示板中找 `agents` 含本会话 id 的 goal；没有则按「本会话 → 父 → …」找最近命中（孙代也能落回孵化其父的 goal）。该卡片加左侧 accent 边框（#58a6ff）+「当前」小徽标 + `data-cyb-current="true"`。仅祖先板模式首次出现时 `scrollIntoView({ block: 'center' })`：用 ref 回调实现（**不新增 hook**——客户端测试的 fake react 只实现部分 hook），去重标记写在滚动容器 DOM 节点上（`__cybFocusedGoal` + `__cybFocusedBoard`），同一容器同一焦点重渲染不重复滚动、`focusGoalId`/`boardSessionId` 变化才再滚；方法缺失或抛错一律静默；根会话自板永不自动滚。
- **跳转正确性**：`openAgent` 改为 `open(agent, boardSessionId)`，第二参缺省 = 当前会话（v0.14 的调用形状不变）；祖先板下 chips 以板会话作为 `parentSessionId` 与 catalog 查询键，`agentChipStatus` 的 catalog 查询同步改用板会话——「关联智能体」跳转始终落在该板会话的目录内。
- **文案**：zh/en 成对新增 `goal.current` / `goal.subagentBoard`（含 `{title}`，取 `list.byId[boardSessionId].displayTitle/title`，缺省即 boardSessionId）/ `goal.jumpHint`；祖先板顶部一行说明 + 跳转提示。
- **兼容**：自板渲染与改动前的 `lib/client.js` 逐字节等价——以同一 props 序列化新旧 GoalView 输出对比（含/不含 sessions 两种 props）完全一致；老宿主无 `sessions.list`/`uiWorkspace` 不崩。
- **测试**：新增 `test/v18-subagent-goal-board.mjs`（10 组：zh/en 键集配对与文案、祖先板 + banner + 焦点 + 一次性滚动（重渲染不重复、焦点变化再滚、无焦点不滚）、最近非空祖先（跨空板两级）、父链两条解析路径与 parentId 优先级、防环、无 list 回退、根会话自板无提示/无标记/无 ref 且 GoalRow props 与旧版相同、chips 以板会话为 parent 且用板 catalog 判活性、孙代 focus 回退与 scrollIntoView 缺失/抛错静默、列表晚到与 subscribe/unsubscribe 安全）。`node --check lib/client.js` 通过。
- **回归**：v14-goal-agents、v03-offline（75 项）、v15-effort-reasoning、v16-smart-selection、v17-model-presets、v10-mode-indicator、v12-mode-pill-running 全绿。复跑在 `/tmp` 隔离副本中进行（`git archive HEAD src` 恢复服务端源码 + 本客户端改动）。原因：本轮工作区的 `src/` 带着另一并发任务的未提交中间态，直接用工作区源码跑 v03/v16/v17 会红（v17 缺 `callLlmOneShot` 导出、v16 `engine.runs[0]` 未启动、v03 板/字段断言），且「工作区 src + HEAD 版 client.js」同样红、「HEAD src + 本客户端改动」全绿——失败与服务端中间态同源，与本客户端改动无关。
- **生效手段**：`lib/client.js` 改动需 **重启 DSH 宿主 + 刷新浏览器**（客户端模块图在宿主启动时构建）。本轮未重启宿主，证据为离线渲染断言；重启后打开任一子智能体会话的「目标」页即可复核。

## v0.17.3（2026-11-06）：设置页思考强度语义校正——无档位模型不再禁用/报警，纯 off 折叠

**背景**：设置页「Triage agent 思考强度」在模型没有 reasoning 配置时（实测 `ollama/qwen3.8:latest`）被禁用并显示黄色警告「该模型不支持思考强度」。但「跟随模型默认」本就不发送 strength 参数，恰恰是这类模型需要的形态——禁用 + 报警属于误报。同时档位列表里的 off/none 与「跟随模型默认」实质同义，应只留一个。**用户裁定**：(1) 无强度模型仍保留下拉、可点击，只含「跟随模型默认」一项，不显示任何警告；(2) off 去重范围只限「纯 off」模型，有真实档位的模型（glm-5.3 的 off/minimal/low/medium/high/max）保留 off。

- **行为 A（无强度模型）**：`lib/client.js` 的 `effortRow` 去掉 `efforts.length === 0` 这个禁用条件与 `settings.effortUnsupported` 警告。模型已解析但 reasoning 缺失 / efforts 为空时：下拉可点击、仅一项「跟随模型默认」(value `''`)，无黄色警告、不改写配置；存储值为空 → 无提示；若存储了具体档位 token 而该模型没有任何档位 → **同样零提示**（v0.17.3 后续修正，见下条）。既有三类禁用条件（全局开关 / 目录未就绪 / 未配置或未解析模型）及其文案不变。
- **行为 B（纯 off 折叠）**：`offLike` 判定 = 档位 id **或** name（trim 后）大小写不敏感匹配 `^(off|none)$`；当 efforts 非空且**每一项**都命中时，列表折叠为「跟随模型默认」（存储的 off/none id 显示为默认，不报警、不写）。含任一真实档位的模型完整保留 off 及其余档位——去重范围不扩大；minimal/low 等真实档位永远不会被判为关闭档。
- **后续修正（同日，用户实测裁定）**：行为 A 的落地版在无档位模型上仍渲染黄色回退说明「配置的档位「off」不在当前模型支持列表中…」（`settings.effortFallback`）——实测 `ollama/qwen3.8:latest` + 存量 `triageAgentReasoningEffort: off`。用户原话：「看到的是一条新的警告，去掉这条警告，没有必要存在」。`effortRow` 的回退提示判定由「存量值不在生效列表（`storedValid`）」改为「模型**确实声明了至少一个档位**、且存量值不在声明列表（`declaredLevel`）」：`opt !== undefined && efforts.length > 0 && stored !== '' && !declaredLevel`。四个语义场景：(a) 无档位模型（efforts 为空，如 `ollama/qwen3.8:latest`、`deepseek/no-effort-model`）+ 任意存量 token → 零提示，下拉 enabled、仅「跟随模型默认」、显示 `value=''`、渲染零写入；(b) 纯 off 模型 + 存量 `off`/`NONE` → 仍零提示（`declaredLevel` 命中声明档位，折叠语义不变）；(c) 有真实档位的模型（glm-5.3-flash / glm-5.3）+ 非法存量（如 `bogus-level`）→ **保留**原回退说明（对用户是有效信息）；(d) 纯 off 模型 + 非 off/none 的存量（如 `high`）→ **保留**回退说明（确实不在声明档位中）。`storedCollapsedOff` 随之成为死代码并删除；`settings.effortFallback` 词条保留（场景 c/d 仍用）。**风险说明**：提示移除只发生在 UI 层——存量旧 token 仍按配置透传给适配器；若适配器拒绝该档位，`workflows/round.js` 的调用级回退（v0.8 式：整包撤销覆盖、以 session 默认模型重试一次）仍会兜底并记入 fallbacks 审计，因此用户不会再被提前告知，但运行时不会静默失败。
- **locale / 补丁表**：`settings.effortUnsupported` 已无引用，从 zh/en 词典与 `effort-patch/patches.mjs` 一并删除（zh/en 各剩 8 个 effort key）。`CLIENT_EFFORT_ROW`、`CLIENT_LOCALES_ZH/EN` 已按改后的 `lib/client.js` 逐字重同步；`client:effort-row-renderer` 增加显式 `done` 标记——此前 v0.17 preset 行使整段 replace 永不命中，`check` 会把它报为 ready、`apply` 会重复插入 effortRow。现 `node effort-patch/patch-v2.mjs check` = **0/22 anchor ready, 0 failure（22 项全部 SKIP）**，`dry-run` 同，重打补丁既不会回退也不会重复。
- **测试**：`test/v15-effort-reasoning.mjs` 第 (3) 组改写为新语义，并新增 (3b)/(3c)/(6)/(7)/(8)：无档位模型 → 启用 + 单项 + 无警告 + `onChange('')` 落 volatile unset；(3b) 无档位模型 + 存量 token（`high`/`high`/`off`）→ **零提示**（既不出现「不在当前模型支持列表」也不出现存量 token），仍保留渲染零写入断言；(3c) 纯 off 模型 + `high` → 仍显示回退说明（真实不匹配）；纯 off（off/NONE，含大小写）→ 折叠、存 off 显示默认、无警告无写；真实档位模型（glm-5.3-flash）非法存量 → 回退说明不变；另断言 zh/en 词典不再含 `settings.effortUnsupported`；(8) 以 `patch-v2` 同款三态检测锁定补丁表与 `lib/client.js` 的逐字同步（anchor/done 标记存在、重打补丁不会回退或重复）。复跑 `test/v15-effort-reasoning.mjs`、`test/v03-offline.mjs`、`node effort-patch/patch-v2.mjs check` 与 `node --check lib/client.js`。
- **生效手段**：`lib/client.js` 改动需 **重启 DSH 宿主 + 刷新浏览器**（客户端模块图在宿主启动时构建）。本轮未自行重启宿主，也未做活体浏览器复验（live bundle 仍为旧版）；证据为离线渲染断言，重启后可按 `effort-patch/README.md` 手动验证第 2 条复核。后续修正同样只落在源码种子：仍需重启宿主 + 刷新浏览器，活体才会消失该警告。

## v0.17.2（2026-11-06）：预置方案活体验收修复（二）——HMR 事务逃逸 + 推荐结果诊断

**背景**：v0.17.1 随宿主重启加载后，活体 OpenAI 方案选择的诊断链首次完整落地：`volatile-update (willHandle:true)` → `settings-resolved (scope:entry)` → **`write-refused "HMR transactions cannot be nested"`**。根因实锤：宿主把一切配置写经 `dsh-hmr.runExclusive` 串行化（settings.mutate → configEditor.edit → `ownerContext.get("hmr")` → `hmr.runExclusive`），而预置处理器恰在该事务提交 volatile 写的 `loader/volatile-update` 同步发射中执行——该事务的 AsyncLocalStorage 存储会泄漏进事务期间调度的全部异步续体（实测：`run()` 完成后触发的定时器仍读到存储），于是处理器发起的 mutate 被判为嵌套而拒绝。v0.17.1 的 settings 解析回退本身工作正常（entry 作用域即可解析），缺陷在更深的写互斥层。

- **修复（HMR 事务逃逸）**：`settingsMutate()` 解析 settings 服务后，再经 `ctx.get('hmr')`（root 回退同款）解析 dsh-hmr 服务，把 mutate 调用包进 `hmr.executing.exit(...)`——与 dsh-hmr 自身 `watchConfig` 使用的逃逸手法完全一致：清空事务存储后 runExclusive 视为全新调用方，写操作排队到在飞事务**之后**执行（loader 发射 volatile-update 不 await 监听器，排队不会死锁）。hmr 服务不可达（离线 stub/组合变化）时保持 v0.17.1 的裸调用；exit 同步抛错时回退裸调用并记 `write-escape-fallback` 诊断。
- **诊断增强**：(1) boot 行新增 `hmr` 探测（`ok-exit`/`undefined`/`threw`）与 `llm` 双作用域探测（entry/root 的 `prepareCall`+`listProviders` 面）；`settings-resolved` 行新增 `hmr: exit|plain` 标记。(2) auto 推荐分支新增 `recommend-outcome` 事件——ok 记 route/catalogSize/picks/ignoredSession/notes，degraded 记 reason/目录大小与已构建请求的形状摘要（`request:{systemChars,userChars,hasPrinciples}`）——写入被拒也不丢推荐管线的可观测性。
- **修复（llm 调用面 root 回退）**：活体 auto 推荐首鸣即 `write-refused status:'degraded'`（v0.17.1 无 reason 级诊断，原因不可见）。头号嫌疑与 settings 同类：`probeCatalogOptions`/`callLlmOneShot`/`validatePickEfforts` 都以**上下文属性**形式读 `ctx.llm`，entry 作用域的 volatile-update ctx 未必携带宿主 llm 服务。修复：`resolveLlmFace()` entry→root 渐进解析，命中时以 `{ llm }` 包装上下文传入 `recommendModels`（该函数只触 `ctx.llm`，包装即完整替身）；双 scope 皆空时保持原行为。
- **验证**：v17 新增第 10 组（真 AsyncLocalStorage 模拟在飞事务：escape 路径下 stub mutate 内 `getStore()===undefined` 且写成功落账；无 hmr 服务时回退裸调用行为不变）与第 11 组（entry ctx 无 llm 面、root 携带服务时 auto 推荐 ok 落地）；v17/v16/v03 全量复跑通过；`tsc --noEmit` 零有效错误。
- **生效手段**：`src/` 改动宿主重载生效（部署同步 + 重启需另行授权）。

## v0.17.1（2026-11-06）：预置方案活体验收修复——settings 服务解析回退 + 处理器诊断

**背景**：重启后的活体验收发现真实缺陷：GUI 预置方案选择在客户端写路径完整生效（`presetPlan` 与自动推荐请求路由字段经 `remote.settings.mutate` 持久化、卡片即时渲染），但服务端一次性处理器从未产出 `presetRecommendation`、六字段从未被方案写入（openai/claude/auto/gemini 多次选择均复现；离线 v17 套件 9/9 全绿——缺陷在宿主组合层，离线 stub 测不到）。宿主 warn 仅落 stdout（用户终端），无可读日志。

- **修复（settings 服务解析回退）**：`settingsMutate()` 在 `ctx.get('settings')` 不可用（undefined/代理守卫抛错）时，回退到 `ctx.root.get('settings')`——settings 服务由 dsh-base 以根级条目提供，entry 作用域解析失败时 root 解析可命中。刻意**不**把 `settings` 加入 `static inject`：缺依赖会让 fiber 在启动时 pend（挂启动）；惰性回退零风险。
- **诊断（presetDiag）**：处理器全部决策点（boot 种子/presetPlan 绑定形态/ctx.on·get 可用性/settings 双作用域探测/volatile-update 事件与 willHandle 判定/write ok·skipped·refused）追加 JSON 行到 `/tmp/dsh-cyb-preset-diag.jsonl`——重启后一次选择即可实锤剩余根因（loader 级静默吞事件 vs 服务解析）。诊断写入全部 try/catch 包裹，绝不影响行为。
- **验证**：`tsc --noEmit` 零有效错误；v17/v16/v03 全量复跑通过（诊断与回退对离线 stub 全透明）。

## v0.17（2026-11-06）：预置方案（厂商方案下拉 + AI 自动推荐，作用范围仅 task/verify/triage）

**需求**：模型配置完全靠手工逐字段填，希望提供整套方案：设置卡片「预置方案」下拉（9 选项 = 自动推荐 + 8 家厂商），厂商方案数据（变体/思考强度/可升级档/fallback/rationale/备注）数据驱动入库；「根据现有配置自动推荐」读取当前系统模型列表、经一次 AI 调用产出推荐并写入。**用户裁定（最高优先）**：session agent 不在功能范围内——用户随时自行调整 session 模型，方案与自动推荐只应用 task/verify/triage；厂商 session 推荐仅作参考展示。

- **两轮接续**：本轮前半（上一轮次产出）建立了骨架——`src/modelPresets.ts`（注册表/请求构建/解析/apply-ops/一次性 LLM 调用 `callLlmOneShot`，消息与 text-delta 收集器内联实现保持零 `@deepseek-ai` 依赖）、`src/index.ts` 的 `loader/volatile-update` 一次性处理器 + `presetPlan`/自动推荐请求路由字段/`presetRecommendation` 三个 volatile 字段（经 `ctx.get('settings').mutate` 写入，与面板同一写路径）、`lib/client.js` 的 `preset` 行（下拉 + 结果记录渲染）。本轮按最新裁定修正并填全：
- **注册表填全 8 家厂商（全 `status: 'ready'`）**：OpenAI（gpt-6.1-sol task/verify + gpt-6-luna triage，effort 五档）、Claude（常规/高要求两变体，verify 恒高一档补偿单家族）、Gemini（家族 + 最新版本运行时解析，不硬编码旧版本号）、DeepSeek（仅本家/verify 外置两变体，verify thinking 档，「成本不应成为降级 verify 的理由」）、Kimi（长期组合/最高验收质量两变体，避开退役 K2）、Qwen（A/B/C 三变体，⚠️ verify 绝不用 Turbo——幻觉共振）、火山 Coding Plan（A/B 两变体，Seed 池 + GLM-5.3 备选边界）、Minimax（M3.1-Flash high/xhigh + M3 verify，缓存读 4 倍差价备注）。每厂商：多变体（`variants`，`roles` 恒为默认变体的同一对象引用）、逐角色 effort token/可升级档/fallback/rationale、厂商 note、session 参考（`variant.session`）+ 常量 `PRESET_SESSION_NOTE`。
- **session 范围结构性钉死**：`ALLOWED_OP_PATHS` = 恰好六个扁平子 agent 字段（task/verify/triage × model/effort），所有 apply-ops 构建器经 `filterAllowedOps` 过滤；推荐 prompt 明令「输出 JSON 只允许 task/verify/triage 三个键，禁止 session 键」；`parseRecommendation` 对万一直出的 session 键丢弃并置 `ignoredSession`；厂商 session 数据只存 `variant.session`，卡片常驻「session 由用户自行管理」提示——任何代码路径都触不到 session 配置。
- **effort 全链路**：`SettingsOp` 扩展 `unset`（角色换模型时清掉旧档位回模型默认）；厂商方案按变体配置写入 effort token（异构：五档/thinking/默认），`recommendationApplyOps` 携带 AI 推荐的 effort；自动推荐的 effort 经 `validatePickEfforts` 软校验（`ctx.llm.resolveModelInfo`，不支持 → 丢档保模型 + 注明；调用面缺失/抛错 → 保留不阻断）。
- **跨厂商通用原则注入推荐 prompt**（仅作用于 task/verify/triage）：verify 档位不低于 task；跨代际/跨家族独立（同家族时 verify 升高一档补偿）；verify 不能过度自信；省成本先压 task/triage、verify 最后动、成本不是降级 verify 的理由；triage 轻量。
- **结果记录增润**：`PresetRecommendationRecord` 增加 `efforts`/`variant`/`otherVariants`/`notes`（session 范围声明 + 厂商 ⚠️ 备注 + effort 校验注记），卡片渲染逐角色「模型（effort X | 模型默认）」+ 变体 + 备注。
- **顺手修复（本轮 typecheck 发现的既有缺口）**：Config 接口补齐 `presetPlan`/自动推荐请求路由字段/`presetRecommendation` 三个字段（schema 有、接口漏）；`controller.ts` 的 `startRound`/`runRound` `parent: unknown` → `Agent`（`@deepseek-ai/dsh-workflow` 的 `WorkflowStartRequest.parent` 本就要求 Agent 类型，types 可解析时 strict 检查暴露）；`tsc --noEmit` 现已零错误（仅存代码库级 TS5097 风格噪声）。
- **测试**：`test/v17-model-presets.mjs` 全量重写（接替占位版）——注册表完整性（9 id、8 家全 ready、变体数对表、roles===variants[0].roles 同一性、session 仅存 variant.session）、请求构建（session 禁令/原则/effort 契约/目录 200 行上限）、解析（fenced/裸模型/`{"task":42}` 形状容忍/session 键忽略/effort 形状丢弃）、effort 软校验三态、apply-ops 六字段围栏 + `filterAllowedOps`、全注册表变体应用（显式/未知 variantId 回退默认、effort set/unset、session 数据零泄漏）、`recommendModels` 端到端（ok 带 notes/全降级带原因与请求）、插件处理器 7 场景（one-shot、记录增润、降级、未知 id、启动种子不重放、清除零写入、新选择触发）、设置卡片（9+1 选项镜像服务端 id 序、session 提示、记录渲染含 effort 后缀/变体/备注、volatile 写路径、zh/en 26 个 locale key 完整）。复跑 `node test/v17-model-presets.mjs` 全过；v03（75 checks）/v09–v16 全绿。
- **生效手段**：`src/` 改动宿主重载生效；`lib/client.js` 改动重启宿主 + 刷新浏览器；`workflows/round.js` 改动热生效。

## v0.16（2026-11-06）：智能选择 Agent 配置（`smartAgentModelSelection` 二元开关 + 首轮启发式自动选配）

**需求**：v0.15 已打通 per-role 模型+档位全链路，但选择完全靠配置或 session agent 手工指定；希望每轮启动时按任务内容自动为 task/verify/triage 选配合适模型——简单任务（删文件、git 提交等）用轻量模型提速省资源，困难任务（不常见语言、复杂数学等）落顶配，写作类落写作特长模型；显式配置恒优先，选不到/分类失败静默回退继承并记审计。

- **新模块 `src/modelSelection.ts`**（纯函数 + 宿主软探测）：`classifyTaskText` 规则启发式分类（trivial/writing/hard/standard，优先级 hard > writing > trivial > standard，standard 完全不介入）；`modelTier` generic 档位推导（参数量 token `8b/30b/70b` 优先于命名 token mini/flash/…/opus/ultra/…，session 路由 = 顶配参照，无信号 = mid）；`picksForClass`（trivial → 轻量×3；hard → 顶配 task+verify + 轻量 triage；writing → 写作特长模型 task + 继承 verify + 轻量 triage）；`computeSmartSelection` 合并/审计（显式 provider/model 恒优先、effort-only 行不换路由、named task 角色行、quick 只产 task 行、persistent task 行显式 skipped、selected/kept-explicit/kept-inherit/skipped 四态决策 + 理由，永不抛错）；`probeCatalogOptions`（宿主根级 `llm` 服务 `listProviders/listModels`，provider 级失败隔离，软探测永不抛）；`sessionRouteOf`（requestHeader 优先、options 兜底，与 dsh-subagent 继承解析一致）。
- **模型目录真实获取**：候选只来自宿主实时目录（`buildModelCatalog` 同源），绝不硬编码模型名；目录不可用/为空 → 全角色 kept-inherit + `catalogStatus: 'unavailable'`。
- **选择时机 = 每次 launch**：`src/index.ts` 新增 `roundConfigFor(target)`——revise 会启动 successor goal（brief/objective/depth 可能与调用目标不同），分类针对实际启动的 target；合并产出 per-launch 的 roles 副本 + 审计，`startAnyRound` 返回值携带 config，`launchBackground` 把实际生效配置存进 handle（collect 折叠所见即所发）。volatile 开关逐 launch 读取，面板保存下一轮即生效。
- **下发与审计链**：`ControllerConfig.smartSelection` → `startRound` 注入 workflow args（关闭时缺省键，binder 拒绝 undefined）→ `workflows/round.js` 四种结果形态经 `withFallbacks` 原样回传 → `foldRound` 落盘 `.cybernetics/round-<goalId>-<N>.json`（仿 v0.8 fallbacks 先例）；persistent 路径经 `executor.ts` 同步携带（quick 结果 + full 的 round.js args）。
- **persistent executor 显式跳过**：`spawnTeammate` 不接受模型覆盖——task 行审计 `skipped` + 理由，verify/triage（full 持久轮）照常可选；quick 持久轮审计只有 skipped 的 task 行。
- **v0.16 不自动分配 reasoningEffort**（设计裁定）：档位 id 模型相关，自动分配需逐选中模型 `resolveModelInfo` 探测（每轮每角色适配器 I/O + 额外失败面）；本轮只选路由，档位留给模型默认或现有平面 effort 字段。
- **为什么规则启发式而非廉价模型调用**（宿主能力核实结论）：宿主有裸补全面（`ctx.llm.prepareCall().stream()`，session-title-llm 模式）但要求引入 `@deepseek-ai/dsh-llm` 运行时依赖（本插件刻意零依赖）+ 每轮一次 provider 往返 + 第二失败面；确定性分类零成本、离线可测、误分类经审计可见且可被显式配置覆盖。
- **设置卡片**（lib/client.js）：`smartAgentModelSelection` 布尔开关（硬门下方、三个 agent 分组上方——它重新解释下方分组行的语义）；zh/en locale 各 2 个新 key（含回退语义说明）。
- **文档**：README.md / README.zh-CN.md 新增「Smart agent model selection / 智能选择 Agent 配置」小节（分类规则表 + 档位推导 + 合并优先级 + 回退 + 审计示例 JSON + 两项设计裁定），配置卡片/插件页配置清单同步；`cybernetics` 工具 description 补充自动选配与审计说明。
- **测试**：`test/v16-smart-selection.mjs` 新增 10 组（分类规则+优先级、档位推导、逐类选择、合并优先级 4 例、回退 3 例、审计形态 + quick/persistent 语义、宿主软探测、startRound/round.js/executor 三层透传、插件端到端 8 例〔开关关闭 = 旧参逐字节一致、trivial/hard/显式优先/live-ref/无 llm 服务/revise 分类 successor brief/审计文件落盘〕、设置卡片开关渲染 + zh/en key + 写入路径）；`test/v03-offline.mjs` volatile 表单断言 12 → 13 字段（+`smartAgentModelSelection`）。复跑 `node test/v03-offline.mjs` → **ALL 75 CHECKS PASSED**，v09/v10/v12/v13/v14/v15/v16 全绿。
- **生效手段**：`src/` 改动——宿主重载生效；`lib/client.js` 改动——重启宿主并刷新浏览器；`workflows/round.js` 改动热生效。

## v0.15（2026-11-06）：sub agent 思考强度（设置页档位选择 + round 透传与回退 + ptc 接缝补丁工具）

**需求**：task/verify/triage 三类 sub agent 此前只能指定 provider/model，无法单独调思考强度；希望按 agent 选配 reasoning effort 档位（只钉档位、保留会话模型也有效），档位选项动态来自模型能力元数据而非硬编码，档位不被支持时安全回退并可审计。

- **设置页（lib/client.js）**：task/verify/triage 三个 sub agent 各一组「模型 + 思考强度」配对分组（Task → Verify → Triage 顺序，v0.15.1 卡面布局）；强度下拉实时从 model-catalog 的 reasoning 元数据解析可选档位（与会话模型选择器读同一份目录；无档位模型禁用下拉并提示「不支持思考强度」，绝不渲染空下拉）；无模型配置 / 模型不支持档位 / 目录加载中 → 下拉禁用 + 提示；存储的档位 id 已失效 → 按模型默认档位显示并附回退说明；zh/en locale 各 9 个新 key。（**v0.17.3 语义变更**：无档位模型改为保留下拉、仅「跟随模型默认」一项、无警告；纯 off 模型折叠为同一项。以上为 v0.15 交付时的历史事实。）
- **配置（src/index.ts + src/controller.ts）**：新增三个 volatile 字段 `taskAgentReasoningEffort` / `verifyAgentReasoningEffort` / `triageAgentReasoningEffort`（缺省 `''` = 模型默认，保存即时生效）；`sanitizeReasoningEffort`（token 形态：字母/数字/`._-`，≤64 字符）在透传前校验，损坏的存储值**丢弃**（不发档位字段 = 模型默认）而非污染请求；`RoleSpec` 增加 `reasoningEffort` 字段与注释说明模型相关性校验边界。
- **round 透传与回退（workflows/round.js）**：`specFor` 将 `reasoningEffort` 与 provider/model 并行携带（仅档位无模型也有效——agent 保留会话模型、只钉档位）；可用性失败模式新增「档位不被当前模型支持」形态（reasoning/thinking effort not supported 等），命中即按 v0.8 式 call 级回退：以 session 模型 + 默认档位重试一次（回退调用不携带 spec、天然不发送 reasoningEffort），并记入 fallbacks 审计；`specLabel` 含档位 id。
- **effort-patch/（新增，已入库）**：dsh-workflow-ptc 接缝补丁工具——宿主升级后重新施接缝的安装器（apply-ptc.mjs / patch*.mjs / patches.mjs）+ 端到端探针 e2e-ptc-effort.mjs + stage/ 副本；其 diag/session 文档快照刻意不入库（用户裁定：诊断/会话产物永不入库）。早期整树恢复脚本 apply.sh 同日废弃删除（方案 B，2026-11-06）：其消费的 stage/dsh-cybernetics 旧版快照会回退 live，部署路径正式收敛为 patch-v2.mjs/patches.mjs + apply-ptc.mjs。
- **测试**：`test/v15-effort-reasoning.mjs` 新增（catalog 透传、档位启用、无档位模型禁用、失效档位回退、分组 + locale 覆盖 5 组）；`test/v03-offline.mjs` volatile 表单断言扩至 12 字段（9 既有 + 3 个 effort）；`test/v12-mode-pill-running.mjs` 随 v0.14 client.js 对齐 inject 断言。
- **生效手段**：`src/` 改动——宿主重载生效；`lib/client.js` 改动——重启宿主并刷新浏览器；`workflows/round.js` 改动热生效。

## v0.13.0（2026-11-05）：内环消息自动插入（免手动推送）

**需求**：后台 goal 轮结束产生的内环完成通知（`<cybernetics_round>` followup）此前只在 session agent 空闲时立即唤醒；agent 仍在跑时通知排队在 next-turn，要等当前回合自然结束才被读到，反馈折叠滞后。希望与 v0.9.0 的外环新输入插入对称：内环消息也自动插入（next-step/steer），免手动推送、免等轮后。

- **src/index.ts（主路径：notifyRoundSettled 直送）**：轮完成通知的投递从无条件 `followup`（next-turn）升级为按策略投递——session agent 仍在跑（`status === 'running'`）且 `noticePolicy='insert'` 时改用 `steer`（next-step），通知在 settle 时刻直接插入当前回合，**根本不进 next-turn 队列**（Web GUI 排队坞不再出现待手动推送的气泡）；空闲 agent 保持原生 `followup`（本就立即唤醒）。steer 与 followup 都带唤醒（`send(_, _, true)`），状态读取竞态（检查后 running→idle）安全；无 `steer` 方法的宿主回退 followup。
- **src/index.ts（兜底：input relay 扩展）**：v0.9.0 的 `agent/inbox/inserted` 监听原样保留，过滤条件从「仅 `source.kind === 'user'`」扩展为双策略：user 输入走 `inputPolicy`（v0.9.0 不变），`source.kind === 'cybernetics'` 的轮完成通知走新配置 `noticePolicy`（缺省 `insert`）。两条路径共享同一组非干预守卫（委派子会话不碰、cybernetics 关闭的会话不碰、空闲 agent 不碰——followup 本就立即唤醒、不在 next-turn 的消息不碰——天然防递归）。主路径与兜底读同一个旋钮，语义一致：noticePolicy='queue' 时直送恢复 followup、中继不再重定位。
- **新配置 `noticePolicy: 'insert' | 'queue'`**（缺省 `insert`，volatile，保存即时生效）：`queue` 恢复原生 next-turn 排队。与 `inputPolicy` 是两个独立旋钮。
- **/cybernetics status**：状态回执新增「轮完成通知策略 noticePolicy」一行；`cybernetics` 工具 description 与 ALL-GOALS guidance 的 FEEDBACK 段同步改为「auto-inserted（免手动推送）」措辞。
- **test/v13-notice-auto-insert.mjs 新增**：缺省插桩（通知从 next-turn 摘除并 steer 进 next-step、对象原样重定位、next-step 重插不递归）、`noticePolicy 'queue'` 恢复排队且与外环 user 输入中继互不影响、四类非干预守卫（空闲/override off/委派子/竞态安全）、status 回执展示 noticePolicy、第 5 组直送路径（running→steer 且零队列滞留、idle→followup 唤醒、queue→followup，三条全走真实 tool.execute→settle 链路）。
- **test/v09-session-mode.mjs、test/v03-offline.mjs 更新**：v0.13 起 cybernetics 通知缺省被中继重定位（v09 原断言「非 user 来源不动」按新语义翻转，补 unknown source kind 反例）；v03 面板 schema 检查补 `noticePolicy` volatile 断言。
- **生效手段**：`src/` 改动——宿主重载生效。

## v0.12.0（2026-11-05）：控制徽标「内环运行中」脉冲动画（ModePill × cyberneticsGoals）

**需求**：用户此前靠 better sidebar 任务管理页或顶栏「N 个子智能体」pill 监控内环任务；希望控制徽标本身即可传达「内环还有任务在跑」——控制开且会话存在 running goal 时，绿点呼吸脉冲 + tooltip 追加运行细节。

- **lib/client.js（ModePill）**：复用 `modeIndicatorInject` 已有的 `ctx.sessions.binding(sessionId)` 路径补取 `cyberneticsGoals` 投影 face（与 v0.10.0 起 `cyberneticsMode` face 同一 binding 形态，header.utilities 槽位实测可用，无需新 inject）；新增纯函数 `countRunningGoals(board)`（统计 `status === 'running'` 的 goal 数 + running 目标中的最高 `round`，任意坏形态退化为 0 不抛错），经 `module.exports` 导出供离线单测。
- **视觉**：控制开 + running count > 0 → 绿点 `dsh-cybernetics-pill-dot-running` 类（`@keyframes` 1.6s 呼吸，`document.head` 单次注入、id 防重）；`@media (prefers-reduced-motion: reduce)` 时 `animation: none` 退回静态点。控制关 / 无 running goal / face 未加载 → 无动画，行为与 v0.11.2 完全一致。
- **tooltip**：追加 `mode.tip.running`（zh「{count} 个目标运行中 · 第 {round} 轮」/ en「{count} goal(s) running · round {round}」）；点击切换 on/off 的现有行为不变。
- **test/v12-mode-pill-running.mjs 新增**：countRunningGoals 真实/坏形态矩阵、双语 `mode.tip.running` key 与 zh/en `mode.*` key 集 parity、脉冲 CSS 单次注入 + reduced-motion 回退 + pulsing 门控条件、factory 导出与 inject 列表不变性。
- **生效手段**：`lib/client.js` 改动——重启宿主并刷新浏览器。

## v0.11.2（2026-11-05）：术语统一修正轮——补漏命令 description 与文档残留

**需求**：v0.11.1 验证轮发现的硬性缺口——`/cybernetics` 命令 description 残留英文 `orchestration`（命令面板用户可见），违反「英文 UI 不再用 orchestration 指代本模式」；另有文档注释残留「编排」。

- **src/index.ts**：`/cybernetics` 命令 description「Toggle cybernetics orchestration …」→「Toggle cybernetics control loop …」（其余 `orchestration` 出现为代码注释与内部提示词，非用户可见 UI，按 v0.11.1 决策保留）。
- **src/index.ts（缺口 B，用户真机目检发现）**：命令注册的 input 提示 `[on|off]` → `[on|off|status]`，与 v0.9.0 起实际可用的 status 子命令解析对齐；description 补「no argument shows status」，status 回执用法行同步补「无参数或 status = 显示状态」。
- **docs/protocol.md**：残留 8 处「编排/编排者」→「控制/控制者」（纯文档措辞，不动标识符）。
- **cordis.patch.yml**：两处英文注释 `read/orchestration`、`orchestration verbs` → control 措辞（纯注释）。
- **版本**：0.11.1 → 0.11.2。

## v0.11.1（2026-11-05）：用户可见术语统一——「编排/orchestration」→「控制/control」

**需求**：用户 2026-11-05 提出——control 比 orchestration 更贴切（cybernetics = 控制论），且插件内已有「控制」标签页（`view.control`），同一概念两处叫法需要统一，同时避免与泛用的多 agent「编排」概念混淆。

**术语决策**：所有用户可见 UI 文案（lib/client.js zh/en 双字典 + `src/index.ts` 斜杠命令回执）统一为「控制模式 / Control」；`hardGate` 中文标签定为「硬控制门」（与「控制模式」保持同一词根，比保留「硬门」简写更可检索）；代码内部英文标识符与注释**不重命名**（避免无意义 diff），历史 CHANGELOG 条目保持原样不改写。

- **lib/client.js（zh）**：`settings.cardLabel`「Cybernetics 编排循环」→「Cybernetics 控制循环」；`settings.hardGate`「硬编排门」→「硬控制门」；`mode.pill`「编排」→「控制」；`mode.tip.*`「编排模式：…」→「控制模式：…」；`hint.insert/queue`「编排模式生效中：…」→「控制模式生效中：…」。
- **lib/client.js（en）**：`settings.hardGate`「Hard orchestration gate」→「Hard control gate」；`mode.pill`「Orchestration」→「Control」；`mode.tip.*`「Orchestration: …」→「Control: …」；`hint.insert/queue`「Orchestration active: …」→「Control mode active: …」。
- **src/index.ts（用户可见回执/描述）**：`hardGate` schema description「硬编排门」→「硬控制门」；`/cybernetics on|off` 成功回执「cybernetics 编排已…」→「cybernetics 控制已…」。
- **文档**：README.zh-CN.md 全文改用新术语（含架构叙述：「编排者」→「控制器」）；README.md 模式指示器章节标题与正文改用 control-mode（架构性角色词 orchestrator 作为英文概念保留）。
- **测试**：test/ 无对「编排」的字符串断言，零改动；v03/v09/v10/plan-precedence 四套全部通过，`tsc --noEmit` 与基线（5 条既有 TS5097 同类）无新增。
- **生效手段**：`lib/client.js` 改动——重启宿主（客户端模块图在宿主启动时构建）并刷新浏览器。

## v0.11.0（2026-11-05）：plan mode ⊃ cybernetics 优先级语义（plan 期间豁免硬门）

**需求**：会话进入 plan 模式时按 plan 语义执行（只读规划 + `exit_plan_mode` 审批），cybernetics 的 ALL-GOALS 路由与硬门禁在该会话**暂停**；批准退出或 `/plan off` 后，下一请求自动恢复 cybernetics 配置语义（实施请求走 goal 循环、写工具重新被门禁约束）。一句话：**plan 决定"能不能动手"，cybernetics 决定"动手走不走循环"**。

**设计决策来源**：`docs/plan-precedence.md`（v0.10.0 定稿设计 + 用户 2026-11-05 裁定「plan 期间关硬门，退出自动恢复」；硬门豁免走按会话、按请求的投影谓词，否决 hook 翻转 volatile 配置的全局方案）。

- **`src/sessionMode.ts` 新增共用谓词**：`PLAN_PROJECTION_KEY = 'plan'` + `planWanted(ctx, session)`——直读本插件已 inject 的同一 `sessionProjections` 注册表里 dsh-plan-mode 的投影（零镜像状态、零 plan-mode 侧配合）。三态判定：`active===true` / `running.wanted===true`（/plan 进行中）/ `wanted===true`（已选待生效）均视为 plan 优先；`wanted===false`（退出待生效）不算。任何失败（plan-mode 未挂载、键未重放、stateOf throw、坏状态）fail-safe 为 false。guidance（一处）与硬门（两层）三处共用，单一事实源，永不失配。
- **guidance（修 C2/C3）**：`registerGuidanceSection` 的 text 函数在 `override===false` 之后加 `planWanted` 分支——plan 会话整段替换为 `PLAN_PRECEDENCE_GUIDANCE`（禁止建 goal/delegate、只读研究、`exit_plan_mode` 提审；文案为 v0.10.0「本会话硬门豁免」版本），ALL-GOALS 协议与硬门文案（诱导跳过审批的 C3 文案）在 plan 期间完全不出现在 prompt。
- **硬门两层豁免（v0.10.0 核心）**：`installGate()` 的装配过滤与 `tools/pre-execute` 拒绝都在 `modeOverrideOf` 检查旁加 `planWanted(session) === true → return next()`——plan 激活会话工具全量保留、调用不拒绝，对 allowlist/denylist 两种 gateMode 一致；豁免按会话按请求生效，投影翻转后下一请求自动恢复强制，**零恢复逻辑**（无全局/volatile 状态被翻转，崩溃/被杀无悬挂态）。
- **C1 兜底**：`DEFAULT_GATE_ALLOWLIST` 头部加 `exit_plan_mode`（只读审批工具，非 plan 会话调用由 plan-mode 侧 throw，无副作用），dispatch 层对两种 gateMode 显式 `next()` 放行——即使 planWanted 检测失效，plan 审批也绝不被双杀。
- **行为边界**：`/cybernetics off` × plan 保持纯 plan 行为（override off 优先，回归 C4）；denylist 部署下 plan 会话同样 gate 直通（v0.10.0 裁定，文档 §5 矩阵对应行已随本版修正为 v0.10.0 语义）；`hardGate=false` 部署零行为变化。
- **测试**：新增 `test/plan-precedence.test.ts` 12 组断言（planWanted 三态+fail-safe、guidance 整段替换、allowlist/denylist 两层豁免、pending 三态提前切换、plan 退出自动恢复、C4 回归、C1 兜底双保险、批准→boundary flip 接力、keep planning 豁免保持、hardGate=false 零变化）；`v03-offline`（75 项）/v09/v10 全部不回归；`tsc --noEmit` 与基线 diff 零新增诊断（基线 5 条，TS5097 同类）。
- **文档**：`docs/plan-precedence.md` 纳入版本控制（顺带修正 :545-595 → :545-575 行号笔误；§5 denylist 非 cyb 会话行更新为 v0.10.0 豁免语义）。
- **生效手段**：`src/` 改动——重启宿主一次加载新代码。

## v0.10.0（2026-11-05）：编排模式可视化状态指示（会话头部徽标 + 输入框提示条）

**需求**：让用户一眼区分当前会话是否处于 cybernetics 控制状态（ALL-GOALS 路由 + 硬门禁 + 外环输入插入），并区分「显式 override」与「继承全局」两种生效来源；点击即切换。

- **会话头部徽标（`lib/client.js`，插槽 `conversation.session.header.utilities`）**：常驻 Pill——绿点「开」= 生效中（override on 或继承全局 on），灰点「关」= 生效关闭，暗「…」= 投影/配置未就绪（加载态，非错误态）。tooltip 注明生效来源（本会话显式设置 vs 继承全局配置）。点击 = `remote.commands.execute(sessionId, '/cybernetics on|off')`——与斜杠菜单、dsh-client-ui-plan（/plan off）完全同款命令通道，不新增服务端 API；写入的是 v0.9.0 同一条 durable 会话事件，徽标经投影实时回流刷新。切换失败把宿主错误折进 tooltip 6 秒（快照仍是唯一被确认的状态）；宿主无 `remote.commands` 命名空间时徽标呈禁用态 + 提示（inject 声明 `remote.commands`，运行时 guard）。
- **输入框提示条（插槽 `conversation.composer.dock`）**：仅当编排模式在本会话生效时渲染一条细提示条，文案随 volatile `inputPolicy` 变化：insert（默认）→「新输入将作为外环控制即时插入当前回合」；queue →「新输入将排队为下一轮输入（inputPolicy=queue）」。
- **数据联接（设计偏差，已验证）**：生效态由客户端就地联接，而非服务端算好投进投影——`cyberneticsMode` 投影只在会话事件时重发布，全局 `allGoalsMode`（volatile）翻转不会产生会话事件，服务端投影无法把全局变化反映进投影值（除非新增 API，违反「优先不新增服务端 API」边界）。客户端两个输入都是响应式的：会话投影 face（`projections.faceOf('cyberneticsMode')`，宿主实时推送）+ 插件 ConfigForm（`configForms.get` live face，设置卡片 v0.7.2 起已验证的同一响应式通道，allGoalsMode / inputPolicy 同源）。联接规则与新增的 `src/sessionMode.ts resolveMode(override, globalMode)`（canonical，返回 `{enabled, source}`）逐字一致；服务端 `effectiveEnabled` 重构为其上封装，行为不变。投影 wire 不变（`{override}`，stateVersion 1）——v0.9 客户端零影响。
- **locale**：新增 `mode.*` / `hint.*` 共 14 个 key，zh/en 双语（zh 为 key-set 基准）。
- **测试**：`test/v10-mode-indicator.mjs` 新增——resolveMode 三值矩阵（override/global/effective + source）、effectiveEnabled null 继承与 fail-safe 语义、resume/fork 重放前缀折叠一致性、投影 wire 向后兼容断言、client.js 工厂求值 + `remote.commands` inject 声明 smoke；既有 `test/v03-offline.mjs` 75 项、`test/v09-session-mode.mjs` 全部通过。`tsc --noEmit` 基线 4 条 + 1 条 TS5097（sessionMode.ts 的 `.ts` 导入，v0.9.0 引入，同类可接受）。
- **生效手段**：`lib/client.js` 改动——重启宿主 + 刷新浏览器。

## v0.9.0（2026-11-05）：按会话 /cybernetics 开关 + 新输入外环插入

**需求**：(A) 同一会话粒度地开关 cybernetics 编排（ALL-GOALS 路由 + 硬门禁），未设置的会话遵循全局 volatile 配置；(B) 会话有活跃 goal 轮时，新用户输入不再排队到轮后，而是作为外环控制直接插入当前回合——且与 DSH 原生输入路由互不干扰。

- **按会话 override（`src/sessionMode.ts` 新模块）**：会话日志事件 `cybernetics/mode { enabled: true|false|null }` + 同 key 注册投影 `cyberneticsMode`（dsh-plan-mode 同款模式，resume/fork 重放可恢复；`null` = 清除 override 回落全局）。`effectiveEnabled(ctx, session, allGoalsMode)` 统一解析：override 优先，无 override 用全局 `allGoalsMode`。任何读取失败（无注册表/键未重放/坏状态）都解析为「无 override」——fail-safe。
- **/cybernetics 命令（`src/index.ts`）**：`ctx.inject(['commands'])` 子作用域注册（/plan 同款，handler 直执行不进模型）。`on`/`off` 写一条 durable 模式事件；无参数/status 输出会话 override、全局 allGoalsMode、hardGate、inputPolicy 与生效态。
- **guidance 函数化**：`systemPrompt.section` 的 `text` 从字符串改为 `(context) => string`（dsh-plan-mode 同款）。override off 会话输出空串；override on 无视全局注入含 ALL-GOALS 的完整编排 guidance；无 override 沿用旧行为（ALL-GOALS 段随全局 `allGoalsMode`）。
- **硬门禁尊重 override**：装配 waterfall 与 `tools/pre-execute` 两层都先查 `modeOverrideOf === false`——显式 off 的会话工具原样保留、调用不拒绝。注意 hardGate 与 allGoalsMode 互相独立：无 override 时门禁仍按 `hardGate` 配置生效（null override 不改变门禁）。
- **新输入外环插入（inputPolicy，默认 'insert'，volatile）**：DSH 原生调研结论——输入排队/插入由浏览器端用户设置 `ui-conversation.busyEnter`（缺省 'queue'）决定，客户端按其选择 mode 提交，服务端 `dsh-api-session-controller` `prompt()` 依 mode 调 `agent.steer`（next-step）或 `agent.followup`（next-turn），prompt 路径无服务端扩展点；可用扩展点是 agent loop 发出的 `agent/inbox/inserted` 事件（dsh-goal-round-driver 同款 seam），且 api-session-controller 自己的 updateQueue 'steer' 动作示范了合规搬迁 API：`inbox.remove(id)` + `agent.steer(message)`。本插件监听该事件：仅当会话 cybernetics 生效（override 或全局 allGoalsMode）、`inputPolicy==='insert'`、agent running、消息是排队 next-turn 的用户输入时才搬迁为 next-step；其余（override off / 全局关 / policy queue / 空闲 / 非 user source / 委派子 agent）一律不动，原生行为零修改。搬迁失败静默回落原生位置。
- **配置矩阵（预期行为）**：{cybernetics on, off, 未 override} × {轮运行中, 空闲}：
  - on + 运行中 → 新输入插队 next-step（外环控制，session agent 立即可见）；
  - on + 空闲 → 正常 followup 立即唤醒（无排队，无需干预）；
  - off + 任意 → 完全走 DSH 原生 busyEnter（缺省排队 next-turn），插件零介入；
  - 未 override + 全局 on + 运行中 → 同 on；未 override + 全局 off → 原生行为。
- **测试**：`test/v09-session-mode.mjs` 新增（投影折叠 / guidance 会话化 / 门禁两层放行 / 命令 on|off|status / input relay 全矩阵守卫）；`test/v03-offline.mjs` 适配 guidance 函数化与双投影、volatile 字段七→八，全部 75 项通过。
- **生效手段**：`src/` 改动——重启宿主一次加载新代码；之后 /cybernetics 与 inputPolicy 即时生效。

## v0.8.10（2026-11-05）：hardGate 上设置卡片，volatile 热切换

**需求**：用户要在插件页配置卡片上直接开关硬编排门（像 `allGoalsMode` 一样保存即时生效，无需重启）。此前 `hardGate` 是非 volatile 字段，宿主设置表单只服务 volatile 路径，GUI 完全写不了它。

- **schema（`src/index.ts`）**：`hardGate` 加 `.volatile()`（保留 `default(true)`），description 更新为「设置卡片可开关，保存后即时生效（热装卸门禁监听），无需重启宿主」。`gateMode`/`gatedTools`/`gateAllowlist`/`gateAllowlistExtra`/`gateApprovalRelay` 保持非 volatile 不动。
- **apply() 门禁接线可装卸**：装配 waterfall 摘工具 + `tools/pre-execute` 分发拒绝 + `gateApprovalRelay` 透传（hardGate 伴随项）提取为 `installGate()`（内部 `gateDisposers`，每次调用先卸旧装再按需安装，幂等）。`hardGate` 改为按使用时读取的函数（`readConfigField` 解 volatile live reference；普通配置缺省仍为不装门，与旧语义一致，schema 默认 true 经 live ref 到达运行时）。监听 `loader/volatile-update`：翻转时先 `registerGuidanceSection()`（HARD GATE 提示段随开关重推导）再 `installGate()`——与 `registerGuidanceSection` 同一重建模式。热关→开按当刻 `resolveGateMode()` 解析结果接线（显式 gateMode 优先，否则结构性 allowlist）。插件卸载 disposer 链不变。
- **client 卡片（`lib/client.js`）**：`SETTINGS_FIELDS` 首位新增 `{ field: 'hardGate', kind: 'boolean' }`；`fieldRow` 新增 boolean 分支（`booleanRow`，与头部 allGoalsMode 开关同款 switch 控件，走同一 `writeField` 写路径）。双语 locale 补 `settings.hardGate` / `settings.hardGateHint`：开启后顶层 agent 写工具被摘除、所有变更经 goal 循环；即时生效，无需重启。
- **测试（`test/v03-offline.mjs`，增至 72 项）**：新增用例 71——(a) 初始 `hardGate=false` 经 live ref 热切 true：装配中 bash 被摘、pre-execute 拒绝、guidance 含 HARD GATE；(b) true→false：bash 恢复、assemble/pre-execute 监听已 dispose、guidance 摘除段；(c) 反复切换幂等（始终恰好一组活监听，末态 hardGate=true 仍拒绝）；(d) schema 断言 hardGate volatile、其余门字段非 volatile。同步更新既有断言：用例 51/56/57 中 hardGate 从「非 volatile 负向对照」改为 volatile 正向（负向对照换 `gateMode`），volatileForm 服务字段六→七。既有全部用例通过。
- **文档**：README / README.zh-CN「硬门」小节与「插件页配置」「已知限制」更新——hardGate 从「配置文件维护/重启生效」改为「GUI 卡片开关、volatile 即时生效」；注明首次部署需重启宿主一次加载新代码，此后开关热生效。
- **生效手段**：`src/index.ts` 改动——重启宿主一次加载新代码，此后开关热生效；`lib/client.js` 改动——重启宿主 + 刷新浏览器（本仓库 `lib/` 即源码）。

## v0.8.7（2026-11-04）：模型下拉 focus-parking（lib/client.js，仅客户端）

**问题**：原生 datalist 按输入框当前文本过滤选项——已配置模型的字段聚焦后下拉只剩当前那一个模型，用户看不到完整目录，容易误以为没有别的选择。改进方向不是自绘下拉，而是顺应原生 datalist 的过滤语义。

- **聚焦占位（focus parking）**：model 字段（task/verify/session/triage 共四个）聚焦或点击时，把已有文本收进 `placeholder`（value 收进占位符、输入框清空），datalist 因此展开全部系统模型；焦点离开（blur/Enter/Escape）且未编辑时恢复占位文本并**不写任何东西**——只是看看列表永远不会把已配置模型置空。
- **编辑语义保持**：占位状态下输入或选中选项即视为真实编辑，走 v0.8.1 的常规提交路径（blank = unset，回车提交）；`hadDraft` 区分占位文本是未提交草稿（保留草稿）还是快照值（恢复即清草稿）。Escape 关闭列表后值已恢复但字段仍持有焦点，此时 `onClick` 也挂 parkCurrent，保证再点一次仍能展开全列表（不再触发 onFocus）。
- **提示文案**（双语 `settings.modelFieldHint` / `settings.triageModelHint`）同步改写：点开输入框即可看到全部可选模型，已有值先收进占位符、离开且未改动不会保存。
- **生效手段**：`lib/client.js` 改动，重启宿主 + 刷新浏览器后生效。`lib/` 是源码同目录（构建产物即源），无需额外构建。

## v0.8.9（2026-11-04）：relay 卡片回退真因修复 + relay-log 落盘

- **根因修复**（src/index.ts）：问题卡片回退改用 `ctx.get('userQuestions')` 解析宿主服务（免 inject 的反射式读取，与 dsh-plan-mode 同法）。旧构建用普通属性访问 `ctx.userQuestions`——cordis 对未 inject 服务的属性访问直接抛 "cannot get property without inject"（cordis/lib/index.js:88-96），try/catch 吞掉后立即返回终态 `unavailable`，这就是 v0.8.8 真机「原生面板 unavailable 后卡片从未出现、12ms 内终结」的直接原因。
- **relay-log 落盘**：每次 relay 决策在 host logger 行之外追加一条 JSON 到 `<workspace>/.cybernetics/relay-log.jsonl`（`{ts, root, path, outcome, elapsedMs}`，fire-and-forget 不影响审批链路），验收无需宿主 stdout / 浏览器 console 即可读取 path/outcome。
- **测试**：test/relay-host-probe.mjs 新增场景 5——cordis 忠实 stub（属性访问抛错、仅 ctx.get 可达）下卡片回退依然可达用户 + relay-log.jsonl 落盘断言；test/v03-offline.mjs 全部通过。
- **文档**：README 双语排障指引更新（relay-log 读取方法与「零记录 = 请求没到 relay」判据）。

## v0.8.6（2026-11-04）：hardGate 门禁语义默认安全 + guidance 与模式一致（P1）

**问题（cyb-3e1ab616 诊断核实）**：`gateMode` 在 schema 里 `.default('denylist')`，而 `DEFAULT_GATED_TOOLS` 只有 `['bash','edit','write']`——任何只写 `hardGate: true` 的部署都得到一道半门：`bsk_*`、`taskboard_create`、`schedule_create`、`farm_start`、`uno_*`、`ppt_create`、`config_restore` 等写工具全部存活；另一会话因此退化成 810 次 `bsk_session` start/stop 死循环。同时 `HARD_GATE_GUIDANCE` 在 denylist 模式下仍宣称“所有改世界的工具结构性不可用”，属假陈述。

- **`src/index.ts` schema**：`gateMode` 去掉 `.default('denylist')`，改为无默认的可选字段（schemastery 对未设置值保留 `undefined`，离线实测 `validate({})` 结果为 `{hardGate:true}`，不含 gateMode）。**用户沉默不再被默认值抹掉**，apply() 才做推导。
- **`src/index.ts` apply()**：新增 `resolveGateMode(config, hardGate)`——显式 `'denylist'`/`'allowlist'` 原样尊重；未设置时 `hardGate ? 'allowlist' : 'denylist'`。`hardGate=false` 时不装任何门禁监听，行为与旧版完全一致。装配过滤与 `tools/pre-execute` 分发拒绝共用同一个 `allowlistMode`。
- **`HARD_GATE_GUIDANCE` 按模式生成**：拆成 `HARD_GATE_GUIDANCE_ALLOWLIST`（保留“所有改世界的工具 STRUCTURALLY unavailable”的强表述）与 `HARD_GATE_GUIDANCE_DENYLIST`（如实说明“只摘 gatedTools，bsk_*/taskboard_*/schedule_*/farm_*/uno_*/ppt_*/config_restore 等仍可调用，这是 PARTIAL 而非结构性门”，并明确禁止“换一个写工具绕过编排流程”）。`registerGuidanceSection()` 在生成时按解析后的模式拼接；hardGate/gateMode 非 volatile，重载后重新生成即可（沿用 volatile 重建模式，不受影响）。
- **文档**：README / README.zh-CN「硬门」小节重写——默认语义（hardGate 伴生 allowlist）、`gateMode` 无默认值、显式 denylist 的残留风险与仍可用工具清单（bsk_*/taskboard_*/schedule_*/farm_*/uno_*/ppt_*/config_restore/subagent 等）、以及“denylist 永远不可能完备（集合随插件增长）”。
- **测试**：离线测试增至 **71 项**——新增 16b 覆盖三种组合：(a) `hardGate:true` 无 `gateMode` → allowlist 生效（长尾写工具在装配期移除且分发期 deny）；(b) `hardGate:true + gateMode:'denylist'` → 仅 bash/edit/write 被摘，farm_start 仍在分发层放行（尊重显式配置、不静默升级）；(c) `hardGate:false` → 无门禁监听、无 HARD GATE guidance。用例同时断言双模式 guidance 文案：allowlist 含 `(allowlist mode)` + `STRUCTURALLY unavailable`；denylist 含 `(denylist mode)` + `gatedTools` + `PARTIAL, not structural`，且**不含** `STRUCTURALLY unavailable` 假陈述；另加 schema 断言 `validate({})` 的 `gateMode` 为 `undefined`、显式 denylist 经校验仍为 denylist。既有 70 项全过。
- **生效手段**：`src/` 改动，**重启 dsh web（宿主重载）后生效**。profile 端 `/Users/mars/.dsh/profiles/web/node_modules/dsh-cybernetics` 是指向源码目录的软链，无需复制；`cordis.patch.yml` 未改动（其中已显式 `gateMode: allowlist`）。

## v0.8.5（2026-11-04）：hardGate 子代理审批透传（`gateApprovalRelay`，最后一跳修复）

**问题**：宿主在委派边界把子代理审批策略钉死为 `never`（`dsh-subagent/lib/index.js:413` `captureDelegatedPolicyOverrides`；`dsh-user-approval/lib/index.js:175` 在 waterfall 之前直接 `rejected`），task agent 的沙箱越权请求到不了用户。**第一跳**：`agent/created` 时给子代理 session 追加 `approval/policy {policy:'ask'}`（真机证据：本任务子代理 session 日志 seq 2 为 `never`/`source:delegation`，seq 3 为插件追加的 `ask`，相隔 52 ms）。**最后一跳（本轮修复）**：原实现把 `approval/request` answerer 注册在内层、先 `next()` 给原生链一个限时窗口——但宿主 `api-remotes` 在启动时（早于所有用户插件）注册了 `approval/request` 转发器（`dsh-api-remotes/lib/index.js:21-28,147,233`），浏览器审批 answerer（`dsh-client-ui-approval/lib/client.js:284`）claim 子代理请求后等待一张"用户看不见的子会话面板"且永不 `next()`；cordis waterfall 由外向内执行（`cordis/lib/index.js:317-325`），内层 relay 因此**永远轮不到执行**，子代理只能挂死。改为 `{ prepend: true }` 最外层接管：沿 `parentSession` 链解析顶层活祖先，用宿主自己的 `ApprovalService.request` 在**用户正在看的会话**上重新发起请求（原生"允许一次/拒绝"面板 + 该 session 的 `approval/asked`/`approval/decided` 审计对，不转发子代理 callId），顶层回合已关闭时回退同一 agent 的 `ask_user_question` 卡片，无活顶层 agent 再回落原生链。旧的 `gateApprovalRelayTimeoutMs` 竞态窗口字段删除（relay 不再与原生链赛跑，等待语义与普通审批一致，由调用方的 signal/超时取消）。**验证**：离线测试 70 重写为最外层注册 + child→mid→root 攀爬 + 原生面板/问题/原生链三层回退 + 排序回归与负向对照；新增 `test/relay-host-probe.mjs` 用真机 cordis + 真机 `ApprovalService` + 真实插件 `apply()` 端到端跑通（子代理请求只落到顶层会话面板、隐藏子会话面板 0 次 claim；顶层拒绝/回合关闭回退均验证）。**生效手段**：`src/` 改动，宿主重载后生效（运行中的宿主仍加载旧构建，需重载/重启才能实测 GUI 弹窗）。

## v0.8.4（2026-11-04）：配置卡片移除 roles JSON 编辑项（roles 改经 profile yaml 高级配置）

**决策理由（记录在案）**：v0.8.1 起 roles 以 JSON 文本域 +「应用」按钮的形式上卡片，用户实测反馈：在 GUI 卡片里手工编辑一个 JSON 对象（`role → {provider, model}`）对用户不友善——JSON 语法错误校验、转义、role 名拼写全暴露给用户。roles 能力本身保留在 schema/运行时（命名角色进阶场景仍可用），但 GUI 不再暴露；确需配置时由 agent 指导用户直接编辑 profile 配置 yaml（用户 patch 行），README/README.zh-CN 各新增「roles 高级配置」小节记录字段位置示例与重载要求。

- **`src/index.ts`**：`roles` 去掉 `.volatile()` 标记（description 文案同步改为「高级配置：直接编辑 profile 配置 yaml 后需宿主重载生效」）。面板语义后果：宿主 `volatileForm` 只服务 volatile 字段，roles 从面板消失且不可经面板写入——这正是想要的行为（同 `hardGate` 等结构字段的既有处置）。**运行时语义核实（双语义均正确）**：接线处 `roleOverrides = { ...readConfigField(config.roles, {}) }` 的 `readConfigField` 同时接受 live reference（volatile，`{get}` → 解引用）与普通对象（非 volatile，原样返回）——`hardGate` 等非 volatile 字段走的就是同一条「普通值」路径，roles 与之同构，无需解 ref 的特殊处理；宿主重载后经 schemastery resolve 出的 roles 就是普通对象，合并逻辑（扁平字段覆盖 `roles.default`/`roles.verify`/`roles.triage`、命名角色透传）完全不变。兼容性：早前经面板写入的 volatile roles 配置在宿主重启后同样 resolve 为普通对象，读取路径不变。
- **`lib/client.js`**：卡片移除 roles JSON 文本域、「应用」按钮及其全部配套（`settings.roles` / `settings.rolesHint` / `settings.apply` / `settings.invalidJson` 四条 locale 词条 ×2 语言、`isRolesValue` 校验、`commitRoles` 提交逻辑、`rolesRow` JSX、`textarea`/`apply` 两条样式）。字段清单回到**六个**：allGoalsMode / taskAgentModel / verifyAgentModel / triageAgentModel / roundsPerSubgoal / maxConcurrentRounds。
- **文档**：README / README.zh-CN 新增「roles 高级配置（profile yaml，agent 指导）」小节——何时需要 roles（命名角色分模型）、`cordis.patch.yml` 用户 patch 行的字段位置 yaml 示例、保存后需宿主重载生效、agent 可指导用户完成；两份 README 的卡片字段清单、GUI 验证步骤与 volatile/非 volatile 语义清单同步为六字段版本。
- **测试**：离线测试增至 **69 项**——51（roles 非 volatile 断言、普通对象 resolve）、57（volatileForm/isVolatilePath 收敛到六字段，roles 路径断言转为非 volatile 负向控制，含宿主真实函数交叉验证）、65（卡片断言：无 roles 文本域、无「应用」按钮、六字段清单）更新；新增 69（roles 非 volatile 双语义：profile yaml 配置 resolve 为普通对象、`readConfigField` 对普通对象与遗留 live ref 双语义、命名角色在扁平字段合并后透传、README yaml 配置路径文档断言）。
- **生效手段**：`src/` 与 `lib/client.js` 均有改动——**重启宿主 + 强刷浏览器**后卡片即为六字段版本；已有 yaml roles 配置经宿主重载照常生效（含命名角色）。

## v0.8.3（2026-11-04）：模型下拉选择 + 失效模型处理（配置卡可用性闭环）

**数据源核实（宿主源码，2026-11-04）**：官方「子智能体」设置页（`@deepseek-ai/dsh-client-ui-settings-subagent`）的模型勾选列表读的是 `ctx.remote.session.modelCatalog()`（`@deepseek-ai/dsh-api-session-controller` 的 `@Remote('modelCatalog')`），返回 `{ ok, value: { groups: [{id, name, models: [{id, name}]}], failures } }` = 当前全部可路由模型按 provider 分组；provider 变更经 `ctx.remote.$on('llm/adapters-updated', …)` 推送刷新。本插件客户端照同一契约接入。

- **模型下拉**（`lib/client.js`）：三个模型字段（taskAgentModel / verifyAgentModel / triageAgentModel）从纯文本框改为 **datalist 加持的文本框**——`<datalist>` 逐项列出目录模型（value = `provider/model`，label = `providerName · provider/model` 便于识别），输入框本体仍是自由文本，**手工输入兜底天然保留**（datalist 不是锁定 select，目录外的值照常提交——与运行时 `parseAgentModelSpec` 接受任意「provider/model」/裸模型名的语义一致）。目录经 `remote.session` 命名空间异步加载（新增 inject 声明 `remote.session`，全程 try/guard：宿主不服务该命名空间或 `modelCatalog` 缺失时下拉为空、不警告、行为与 v0.8.2 完全一致，绝不崩），并订阅 `llm/adapters-updated` 实时刷新（模型设置增删订阅即时反映）。
- **失效模型处理（配置页）**：卡片渲染时把**已保存的配置值**与实时目录比对（`provider/model` 精确匹配选项 value；裸模型名匹配任意 provider 的 model id）——命中失败即显示「该模型已不在当前系统模型列表中，运行时将回退到 session agent 模型」警告 + 一键「清除」按钮（走与留空保存完全相同的 `unset` op 写路径）。**取舍（记录在案）**：选择「警告 + 显式清除」而非「渲染时自动 unset」——自动改写用户配置有副作用（重新订阅后原值即恢复有效；用户应保有对已存配置的所有权），且 unset 本身就是一次面板写入、失败时还会弹保存失败提示，静默化反而更危险。目录未加载/加载失败时**永不**警告（判定必须可证，避免误报）；警告只针对快照值，草稿未提交文本不触发。roles JSON 内的失效项本轮不做逐行校验（委托书明确允许，扁平三字段已覆盖主要交互面）。
- **失效模型处理（运行时，核实 + 补充）**：核实 v0.8.0 回退路径确实覆盖「模型订阅已删」——provider 被删时 dsh-subagent 在 spawn 前抛 `no subagent provider registered for "x"`（`SubagentError NO_PROVIDER`），workflow runtime 包装为 `WorkflowError code AGENT_START`，`round.js` 的 `isAvailabilityFailure` 恒判真 → 撤销覆盖重试（既有测试 59 已锁）。**补充**：provider 仍在但该 model 订阅被删时，失败以模型级报错形态出现（AGENT_RESULT 内嵌或无 code 直抛），本次在 `AVAILABILITY_PATTERNS` 加入 `model not found / no such model / unknown model / invalid model / not subscribed / model …not available/enabled/found` 模式（测试 63 矩阵新增三行触发器）。`workflows/round.js` 改动热生效。
- **测试**：离线测试增至 **68 项**——新增 68（下拉数据源：datalist/option 形状与 providerName 标注、手工输入保留；失效判定：provider/model 与裸名两形态、有效值与目录失败时零警告；清除交互：显式 unset 写入、纯渲染零写入；`llm/adapters-updated` 触发目录重取），63 矩阵扩展删除订阅触发器，67 的字段 kind 断言同步为 `model`。
- **生效手段**：`lib/client.js` 改动需**重启宿主 + 强刷浏览器**；`workflows/round.js` 热生效。验证：重启后打开插件页卡片 → 三个模型字段出现下拉（选项为 `providerName · provider/model`）→ 填入一个已删除订阅的模型回车保存 → 字段下方出现不可用警告 → 点「清除」恢复继承。

## v0.8.2（2026-11-04）：新增 triageAgentModel（第三个扁平角色模型字段，卡片覆盖全部七个 volatile 字段）

- **新增 `triageAgentModel`**（`src/index.ts` schema + Config 接口）：与 `taskAgentModel` / `verifyAgentModel` 完全同构的扁平 volatile 字段——「provider/model」或裸模型名，**留空 = 继承 session agent**；经 `readConfigField` 解 live ref 后由 `parseAgentModelSpec` 解析，在轮启动接线处合并进 `roles.triage`（与 task→roles.default、verify→roles.verify 同一模式）。description 文案写明 triage 角色职责：读 task/verify 结果输出本轮收敛决策（met/continue/human-input 等），**quick 轮不启用**（quick 深度在 verify/triage 之前直接返回）。
- **fallback 语义**：沿用 v0.8.0 `callRoleAgent`——triage 调用点（普通轮与 persistent executor 的 `taskReport` 分支共两处）本就走 `callRoleAgent('triage', …)`，本次零改动；测试 67 锁死：triage 覆盖 + 可用性失败 → 撤销覆盖以 session 模型重试一次并记录 `{role:'triage', trigger:'availability-error'}`；**空配置（无覆盖）时 triage 返回 null 不触发多余重试**、无伪造回退记录；quick 轮完全不调用 triage。`src/controller.ts` 无需改动：`RolesConfig` 本就有 `triage?: RoleSpec`，扁平字段只落在 `src/index.ts` 的 Config 接口上。
- **设置卡片**（`lib/client.js`）：字段清单加入 `triageAgentModel` 文本框（专属 hint 写明 triage 职责与 quick 轮语义），卡片现覆盖全部**七个** volatile 字段（allGoalsMode / taskAgentModel / verifyAgentModel / triageAgentModel / roundsPerSubgoal / maxConcurrentRounds / roles）；读写路径、留空=unset、失败兜底与既有字段完全同构。
- **生效手段**：`src/index.ts`（schema + 接线）改动需**宿主重载**；`lib/client.js`（卡片）改动需**重启宿主 + 强刷浏览器**（客户端模块图在宿主启动时构建，无 watcher）。验证步骤：重启宿主后强刷「插件」页 → 打开 cybernetics 卡片 → 应看到「Triage agent 模型」文本框（位于 Verify agent 模型之下），填入「provider/model」回车保存，下一轮 goal 的 triage 角色即用该模型；留空保存 = 恢复继承。
- **测试**：离线测试增至 **67 项**——新增 67（triageAgentModel：volatile/live-ref/解析/合并接线/三处 fallback 语义/quick 轮跳过/卡片字段清单）；57（volatileForm 服务清单改断言七字段，含真实宿主 volatileForm 交叉核对）与 65（卡片快照 + 字段清单 + triage 字段 set/unset 写路径）同步扩展。

## v0.8.1（2026-11-04）：设置卡片覆盖全部六个 volatile 字段（面板缺字段的真根因）

用户实测（重启宿主 + 刷新浏览器后）：插件详情页的 cybernetics 卡片仍只有「全目标模式」一个开关，roles / roundsPerSubgoal / maxConcurrentRounds / taskAgentModel / verifyAgentModel 五个 volatile 字段在 GUI 无处可见。本轮重读宿主源码后定位到**与 v0.7.10 不同的第三层根因**：

- **渲染来源核实**：插件详情页（`ItemDetail`，@deepseek-ai/dsh-client-ui-plugin-manager lib/client.js:2710）对插件配置的渲染**完全交给 slot 卡片**（`plugins.item` view "page"），页面自身一个字段都不画；@deepseek-ai/dsh-client-ui-settings 只提供 `configForms` **服务**（传输层 + `volatileForm` 决定服务/接受哪些字段），**没有按 schema 自动渲染字段的通用 ConfigForm UI**；dsh-client-ui-settings-plugins 是只读 inventory 壳（其 README 明言："Configuring a built-in plugin happens on the sidebar's Plugins page, where each official plugin's own companion package registers its page"）；官方插件（agent-loop / web-search 等）各自带手绘卡片。**结论：本插件自定义卡没画的 volatile 字段在整个 GUI 中不可见也不可配**——v0.7.2/0.7.3 起的卡片只渲染 allGoalsMode 开关 + summary 文案，这就是重启后其余五字段仍缺席的原因。宿主侧「通用 ConfigForm 服务全部六字段」指的是传输层（测试 57 已证），不是一张实际存在的表单 UI；两张 UI 并不并存，唯一 surface 就是自定义卡。
- **卡片扩展**（`lib/client.js`）：同一 `SettingsCard` 现在渲染全部六个 volatile 字段——allGoalsMode 开关（不变）+ taskAgentModel / verifyAgentModel 文本框 + roundsPerSubgoal / maxConcurrentRounds 数字框 + roles JSON 文本域（「应用」按钮提交，写入前校验 `{role: {provider, model}}` 形状）。单行字段回车或失焦即提交；**留空 = 恢复默认**（`unset` op）；数字越界（<1 / <0）只标红不写；内容未变不写。写路径与开关完全同构：live ConfigForm `set`/`unset`（plugins.bundle.config 页）或宿主 ConfigPageForm `mutate(ops, revision)`（plugins.item / plugins.row.config 详情页），被拒时经 `remote.settings.mutate` 无 revision 兜底重试一次并原样展示宿主拒绝信息（v0.7.6 path-(b)），未就绪显示「配置不可用」行且不挂控件、15s 看守防挂起、控件值始终以宿主确认的快照为准——既有行为全部保留。
- **生效手段**（`lib/client.js` 改动的固有约定）：**重启宿主 + 强刷浏览器**（客户端模块图在宿主启动时构建，无源码 watcher）。验证步骤见 README「插件页配置」。
- **测试**：离线测试增至 **66 项**——新增 65（live ConfigForm 形状：六字段清单渲染、数字解析/越界标红、留空=unset、未变不写、roles JSON 校验与解析后写入、Escape 还原）与 66（宿主 ConfigPageForm 形状：字段写经 `mutate(ops, revision)`、blank=unset op、拒绝→directMutate 无 revision 重试并展示原文、未就绪只渲染标签不挂控件）。

## v0.8.0（2026-11-04）：task/verify agent 模型覆盖的调用级回退（call-level fallback）

为角色设定的模型无法调用时（限额/quota 耗尽、网络不可达、provider 报错等**可用性失败**），不再让整个 goal 轮失败：`workflows/round.js` 对每个角色的 `agent()` 调用包一层 `callRoleAgent`，命中可用性失败即**撤销该角色的 provider/model 覆盖**（不传覆盖 = 继承 session agent 的模型配置）重试一次。覆盖 task（含命名角色）、verify、triage 三个调用点；persistent executor 的 full 轮经 `taskReport` 分支同样走 verify/triage 的 `callRoleAgent`。

**判定信号来自 workflow runtime（`@deepseek-ai/dsh-workflow-ptc`）`agent()` hook 的错误类型/消息**（对该 runtime 源码逐行核实）：

- **抛出 `WorkflowError`** —— `code: 'AGENT_START'`（消息 `agent() could not start a child: …`，provider 解析/spawn/首调失败，**恒为可用性失败**，如 `no subagent provider registered for "x"`）；`code: 'AGENT_RESULT'`（`child agent run failed: …`，消息内嵌失败原因，命中可用性模式才回退）。模式表：限流（429/rate limit/too many requests）、限额（quota/insufficient/额度/余额/配额）、鉴权（401/403/unauthorized/invalid api key）、服务端不可用（502/503/529/overloaded/service unavailable）、网络（ECONNREFUSED/ETIMEDOUT/ENOTFOUND/fetch failed/network 等）。无 `code` 的错误（如离线 harness 的 mock）按消息模式判定。其余抛出（`INVALID_ARGUMENT`/`UNSUPPORTED_*`/`AGENT_CAP` 等脚本或守卫错误）**原样上抛，绝不换模型**。
- **返回 `null`** —— runtime 把子 agent 的失败压成 null 且不透传原因（子 run `stopReason ≠ 'completed'`：LLM 调用中途失败经 dsh-subagent 的 `agent/error` → `stopReason: 'error'`，是限额/网络/provider 报错**最常见的形态**；或 completed 但无结构化产出）。仅当该角色**配置了模型覆盖**时把 null 视为「覆盖模型疑似不可调用」重试一次；无覆盖时 null 维持原失败语义（本来就跑在 session 模型上，无处可退）。重试再败降级为既有「本轮无结果」路径，回退记录仍保留。
- **逻辑失败永不触发回退**：task agent 正常交付 `done=false` 报告、verify 给出未达成 verdict，都是返回值层面的判定，不换模型（离线测试 61 锁死）。

**可见性**：每次回退记录 `{role, from, trigger: 'availability-error'|'null-result', reason}` 进轮结果的 `fallbacks` 数组（所有返回路径经 `withFallbacks` 携带），随 `.cybernetics/round-<goalId>-<n>.json` 审计日志落盘；`log()` 把回退原因 narrate 进 `workflow/log` 事件流；controller 的 `decide()` 把「⚠ 模型回退 N 次：role(覆盖→session 模型)」后缀追加进决策 note（cybernetics 工具结果行可见）。配置语义向后兼容：空配置 = 继承 session agent（无回退必要）；已配置 = 优先用配置模型，可用性失败时回退。离线测试增至 **64 项**（新增 59–64：AGENT_START/quota 触发、逻辑失败不触发、null-result 回退与再败降级、可用性判定矩阵、controller 层可见性）。`workflows/round.js` 改动**热生效**，无需宿主重载；`src/controller.ts` 的类型与决策 note 改动需宿主重载。

另：用户已按 v0.7.10 第 2 条修复宿主部署（profile 侧 dsh-app-boot 收敛到 CLI 同一份模块实例），离线测试 58 的 inode 探针相应改为双态断言——两份拷贝 realpath 相同即认证「部署已修复」（面板保存恢复可用），相异则维持原有的双实例机制断言。

## v0.7.10（2026-11-04）：基于真实宿主源码的双根因定位（面板渲染 + 保存拒绝）与测试忠实化

用户实测（2026-11-04 真实 GUI）：面板只显示「全目标模式」一项，v0.7.9 新 volatile 字段（roles / roundsPerSubgoal / maxConcurrentRounds / taskAgentModel / verifyAgentModel）全部缺席；且「全目标模式」开关保存被宿主拒绝："dsh: profile reload requires the root Include entry"。本轮重读宿主源码（@deepseek-ai/dsh-settings volatileForm/describe/write、@deepseek-ai/dsh-config-editor edit、@deepseek-ai/dsh-app-boot boot/mountRootInclude/recompose）后**修正 v0.7.9 的两个错误结论**：

1. **渲染根因 = 运行时陈旧（stale runtime），不是 schema 缺陷。** 本插件是 `link:` 安装（profile node_modules 软链回本仓库），宿主 loader 在启动时一次性 import `src/index.ts` 并缓存模块图，没有源码 watcher——源码改动只在宿主重启后进入 `entry.fiber.runtime.Config`。实测面板恰好只有「全目标模式」一项，正对应 v0.7.0–v0.7.6 的 schema（当时只有 allGoalsMode 是 volatile；task/verify 两字段 v0.7.7 01:10 才 volatile，roles/rounds/maxConcurrent v0.7.8–0.7.9 才 volatile）：运行中的宿主进程装配的是早于 v0.7.7 的运行时。v0.7.9「渲染失败是因为宿主不认新字段」的判断不成立——真实宿主的 `volatileForm`（dsh-settings lib/index.js:122-131）对**每个 volatile 字段**都会生成表单，`describe()` 按 `entry.fiber.runtime.Config` 服务；离线测试 57 证明：当前 schema 经宿主 `validateVolatilePlacement`（app-boot lib/index.js:2606-2621，volatile 必须落在无 volatile 祖先的固定对象路径上——当前六个字段全部合法，含 volatile 的 roles dict）与 `volatileForm` 后，表单恰好服务全部六个字段；而把 face 回退成 pre-0.7.7（仅 allGoalsMode volatile）即逐字段复现用户截图的「单字段面板」。**生效手段：重启宿主**（`src/` 改动需宿主重载，本文件头注约定）+ 浏览器刷新。

2. **保存拒绝根因 = 宿主 dsh-app-boot 双模块实例（部署层），不是插件声明/写入路径问题，插件仓库内无法修复。** 真实写路径是 `settings.write/mutate`（dsh-settings）→ `ConfigEditor.edit`（dsh-config-editor lib/index.js:69-131），而 edit **无条件先跑一遍预检** `reconcileProfilePatches(root, beforePatches, "dsh")`（第 74-75 行，先于任何文档读写）；该调用进入 dsh-app-boot 的 `recompose`（lib/index.js:3803），其守卫是**模块级全局 WeakMap** `bootstrapIncludes.get(ctx)`——由 `boot()`/`mountRootInclude`（lib/index.js:4151）在**引导进程自己的 dsh-app-boot 拷贝**里登记。本机部署里引导方（全局 CLI：/opt/homebrew/lib/node_modules/@deepseek-ai/dsh，npm 树）与 profile 侧的 dsh-config-editor（pnpm 树，依赖解析到 profile 自己的 @deepseek-ai/dsh-app-boot 拷贝，两份 lib/index.js inode 不同）各持一份模块实例，WeakMap 永远 miss → **任何**插件的面板保存都在落盘前被拒，报错正是 "dsh: profile reload requires the root Include entry"；预检先于 `writeFileAtomic`（第 123 行）的顺序也解释了实测「profile cordis.patch.yml mtime 不变、快速 rejected」的签名。此前 v0.7.4–v0.7.8 依次排查的「非 volatile 拒绝 / revision 冲突 / 落点形状」都不是真实拒绝点。**让面板写入生效的正确装配**（宿主侧，超出本仓库边界）：把引导方与 profile 收敛到**同一份** dsh-app-boot 模块实例——最直接是把 profile 的 `node_modules/@deepseek-ai/dsh-app-boot` 软链到 CLI 引导用的那份（Node ESM 按 realpath 去重，同 realpath = 同 WeakMap；注意 pnpm 重装会还原软链），或上游修复 `recompose` 的守卫（改为显式传递 root Include entry，而非模块级 WeakMap）。修复后 volatile 保存将按 v0.7.8 测试 56 已证明的形状落为 profile 用户 patch 行 `{id, name, config}` 并即时生效（volatile 语义 = 不 remount 的活提交，落盘 + loader/volatile-update）。

插件侧本轮改动：`src/index.ts` schema **无需变更**（经真实宿主闸门逐项验证合法）；离线测试增至 **58 项**——新增测试 57（validateVolatilePlacement + volatileForm 全字段断言 + roles 子路径 isVolatilePath + pre-0.7.7 陈旧运行时单字段负向对照；并在宿主 profile 在场时**直接 import 宿主自己的** `dsh-settings/lib/types/schema.js` 的 `volatileForm`/`isVolatilePath` 对当前 Config 重放——六个字段全被服务、写闸门全过、非 volatile 字段全被拒，把离线模拟钉死在宿主真实代码上，宿主将来改闸门此处先红）与测试 58（bootstrapIncludes WeakMap 按模块实例失配复现精确拒绝串 + 预检先于落盘的顺序断言 + 同实例去重对照 + 本机双拷贝 inode 探针，实测 CLI 拷贝 inode 548644475 ≠ profile 拷贝 inode 548688631）。README 的 GUI 验证步骤同步更新。


## v0.7.9（2026-11-04）：面板暴露 goal 编排核心参数

根因：宿主 0.1.7 settings model 的插件面板**只服务 `.volatile()` 字段**（`@deepseek-ai/dsh-settings` 的 `volatileForm`：无 volatile 字段的插件条目不出现在 describe() 里，`write()` 对非 volatile 路径直接抛 "Config field ... is not volatile"）。v0.7.8 只有 taskAgentModel / verifyAgentModel / allGoalsMode 是 volatile，`roles`、`roundsPerSubgoal`（递归深度上限）与并行上限完全无法在 GUI 配置。本版将 `roles`（role → {provider, model}）与新增的 `roundsPerSubgoal`（同一子目标最大连续轮数，缺省 3）、`maxConcurrentRounds`（全局并行轮数上限，缺省 0 = 不限；`launchBackground` 与阻塞 round 路径启动前检查 `running.size`，超限拒绝并提示）全部标 volatile；运行时经 `readConfigField` 解 live ref（roles 不再直接 spread，避免把 ref 对象当 override）。`hardGate`/`gateMode`/`gatedTools`/`gateAllowlist`/`gateAllowlistExtra`/`toolName`/`implicitTrigger` 保持非 volatile：面板写不了它们（结构性装配，属 profile 配置文档职责）。volatile 保存即时生效、下一轮 goal 生效，无需宿主重载。客户端 `lib/client.js` 无需改动：通用 ConfigForm 从 configForms describe() 的 volatileForm 派生字段，新字段自动出现。离线测试 51 扩展锁死三个新 volatile 字段与 roles live-ref 解析（共 56 项全过）。

## v0.7.x（2026-11-03 ~ 2026-11-04）

### v0.7：全量 goal 模式（`allGoalsMode`，默认 false）

开启后注入「ALL-GOALS MODE ACTIVE」路由协议：任何用户请求一律先建 goal 再执行（禁止就地分析）；简单只读 → quick 单轮；复杂分析/写任务 → full 多轮渐进（start 异步 + collect 收敛）；revise 缺省 `abortPrevious` 改为自动决策树（查 goal 板 running 状态：旧轮在跑且 objective/depth 被改写 → 自动中止；旧轮在跑但目标不变 → 等待自然结束；旧轮未跑 → 直启），显式传值仍是人工控制。每次修订的 `revisions-<新goalId>.jsonl` 审计行新增 `abort: {abort, mode, basis}`；`revise` 返回值同样携带 `abort`。决策树纯函数在 `src/controller.ts` 的 `decideAbort`。关闭模式时提示段与 revise 行为与 v0.6 完全一致（离线测试 48–50 锁死）。同版在 settings schema 上新增扁平 agent 模型字段 taskAgentModel / verifyAgentModel（空 = 继承 session agent）。

### v0.7.1：插件配置面板可视化配置

`src/index.ts` 导出 schemastery `Config` schema，宿主 0.1.7 settings model 据此派生 Web 编辑器插件条目的设置页（机制同 `@linxin666/dsh-ssh` / `@linxin666/dsh-usage`：loader 经 `runtime.Config['~standard'].validate` 解析配置，面板由 dsh-client-ui-settings 的共享配置表单渲染，含每个字段的 `description` 文案）。`allGoalsMode` 标记 `.volatile()`：在面板上切换保存后 loader 直接把新值提交进运行实例（不 remount），提示段经 `loader/volatile-update` 重挂即时生效；`hardGate`/`gateMode`/`gatedTools`/`roles` 等结构性字段为普通字段，保存后触发插件行 remount（需宿主重载完成）。注意：schema 解析会把未设置的 `z.array` 字段变成 `[]` 而非 `undefined`，`apply()` 的门回退因此按「空数组 = 未设置」处理（离线测试 51 锁死）。此前版本只能手改 profile JSON 里的 `allGoalsMode: true`；现在在 Web 编辑器「插件」页的本插件卡片上直接切换即可（保存 volatile 字段无需重启宿主，刷新浏览器可见最新面板）。

### v0.7.2 / v0.7.3：插件页设置卡片

实测仅有服务端 Config schema 不会在「插件」页产生任何卡片（本 profile 的 @linxin666/dsh-client-ui-plugin-manager 停用了官方 ui-settings-plugins 设置分区，schema 自动面板无处落脚）。官方插件页（@deepseek-ai/dsh-client-ui-plugin-manager）只通过它声明的 slot 渲染插件配置：`plugins.item`（「内置插件配置」分组列表卡）、`plugins.bundle.config`（按 bundle 名分发，bundle 详情页配置区）、`plugins.row.config`（按 `<bundle>#<rowId>` 分发，组件详情页）。`lib/client.js` 因此注册三个席位：`plugins.item`（id = `dsh-cybernetics`）、`plugins.bundle.config`（key 同时注册 profile 依赖名 `dsh-cybernetics` 与包名 `@mars.liu/dsh-cybernetics`）、`plugins.row.config`（key `<bundle>#dsh-cybernetics`）。`plugins.item` 无条件注册（v0.7.5 加固）：早先的 cut 用 `configForms.whileServed` 门控，宿主尚未服务该命名空间时整张卡消失，与「注册从未运行」不可区分；现改为 `ctx.configForms.get()` 绑定一个跟随共享 describe mirror 的活 ConfigFormController，命名空间就绪的瞬间卡片翻成开关，未就绪时渲染「配置不可用」行——可见、可诊断。卡片读写 `ctx.configForms.get('dsh-cybernetics')` 的 ConfigForm；v0.7.3 修复：详情页的 owner prop `form`（宿主 ConfigPageForm `{state, mutate}`）在渲染 seam 上覆盖 inject 的 form（renderer renderEntry 先展开 inject 后展开 ownerProps），卡片两种形态都支持（离线测试 52/53 锁死）。`dsh.client.inject` 增补 `@deepseek-ai/dsh-client-ui-settings` 保证 configForms 提供方先到。

### v0.7.4：保存失败可见化

实机验证（2026-11-03，浏览器实测）：卡片注册、summary 文案、开关渲染均正常，但切换保存经 `configForms`→`remote.settings.mutate` 到宿主后被**静默拒绝**（写不落盘：profile `cordis.patch.yml` 未变更，RPC 错误不上控制台，卡片此前 `.catch(() => {})` 吞掉失败，第一次点击甚至把 promise 挂死在「保存中」）。离线模拟宿主 `dsh-config-editor.edit` 的文档校验（`composeEntries([patches])` 含 bundle insert 层 + 新增 override 行）是**通过**的，说明拒绝发生在更早的环节（`reconcileProfilePatches` 预检 / loader 热重载路径），宿主日志在本环境不可读，确切拒绝原因待宿主侧确认。本轮改动：卡片不再吞错——写入被拒（settles false / reject）或 15 s 未返回都显示「保存未生效（宿主拒绝了写入）」并立即把开关还原到宿主确认的快照值；成功路径语义不变（volatile 即时生效）。根治写路径需要宿主侧 settings.mutate 的拒绝日志（`harness-log` 或 `dsh plugin --profile web` 诊断），超出插件仓库边界。

### v0.7.5：卡片注册无条件化

见 v0.7.2/0.7.3 段的 `plugins.item` 说明；宿主日志复核（2026-11-03，`~/.dsh/logs/`）：未发现 cybernetics settings mutate 的拒绝记录（最近一次启动日志是 EADDRINUSE 的失败实例，当前宿主进程无对应落盘日志），写路径的宿主侧根因仍待带日志的复现。

### v0.7.6：路径 (b) 落点取证 + 拒绝原因透出

代码级取证（2026-11-04，宿主 checkout 只读）确认：`settings.mutate` 的唯一宿主写路径是 `@deepseek-ai/dsh-settings SettingsForms.write` → `@deepseek-ai/dsh-config-editor ConfigEditor.edit`，后者写入的就是**用户 patch 行**（在 profile `cordis.patch.yml` 追加/更新 `{id, name, config}` 非 insert 行，再以 `reconcileProfilePatches(root, patches, "dsh", [entry.id])` 应用——见 `dsh-config-editor/lib/index.js` edit() 的 `findLastIndex` + `document.add({id, name, config})`）。即插件侧写入落点**从来就是**宿主允许的用户 patch 行，"写到了 bundle insert 行"的假设不成立；实测复现（2026-11-04 浏览器点击开关 + `cordis.patch.yml` mtime 前后比对）显示拒绝发生在宿主 `edit()` **落盘之前**（文件未被触碰、快速返回 settings/rejected），确切 throw 行仍需宿主侧 stderr（tty，本环境不可读）。本轮插件侧改动：写入被拒时经插件自有的 `remote.settings.mutate`（同一宿主写路径）做**一次无条件 revision 回退写**（expectedRevision 省略 = 宿主文档化的无条件写），陈旧 revision 冲突可就地自愈；仍被拒时卡片以「保存未生效，宿主拒绝原因：{message}」透出宿主 RemoteError 原文（ConfigFormController 原本把错误坍缩成裸 `false`）。离线测试增至 54 项，新增写入落点断言（回退写无 revision、主写成功不触回退、无 remote 降级不崩）。

### v0.7.7：agent 模型字段 volatile 化（表单可写性根治）

本轮实机复现（2026-11-04 浏览器点击插件详情页开关）：写仍被宿主拒绝（快照回弹「全目标模式：关」，profile `cordis.patch.yml` mtime 21:58:35 未变，拒绝发生在落盘之前），且当前宿主进程 2026-11-03 22:04 启动、早于 v0.7.6 提交（00:40），运行中的仍是旧客户端模块。新增宿主侧取证：`@deepseek-ai/dsh-settings` 的 `volatileForm(schema)`（lib/index.js:122-131）只保留 `.volatile()` 字段作为整个设置表单，`write()`（同文件 502-531 行）对每个写入路径做 `isVolatilePath` 检查并抛「Config field "…" is not volatile」——即宿主表单**只服务也只接受** volatile 字段；据此把 taskAgentModel / verifyAgentModel 两个扁平字段也改为 `.volatile()`（此前非 volatile = 在插件页既不可见也不可写），读取点改为 `readConfigField(config.taskAgentModel, '')` 解包活引用（'' = 与 session agent 一致），语义保持「保存后下一轮 goal 即生效，无需重载」。离线测试 55 项全过（测试 55 改为断言两字段 volatile + 活引用解析 + readConfigField 解包布线）。生效步骤：重启宿主（客户端模块图 + 服务端 schema 都在启动时装配）+ 强刷浏览器。

### v0.7.8：写入落点证明测试（测试 56）

把宿主 `@deepseek-ai/dsh-settings` write() 的全部预写闸门（volatileForm / isVolatilePath / projectForm / mutate op reduce / validatePaths / strip + mergeLayers，lib/index.js 122-179 与 488-534 行）逐行复刻，对**真实导出的 Config schema** 重放卡片的 toggle 写：开关写通过每一道闸门、经 schemastery 校验（= cordis `resolveConfig` 的精确检查）后产出持久化 config，最终落点形状恰为 `ConfigEditor.edit`（dsh-config-editor lib/index.js 150-155 行）追加到 profile `cordis.patch.yml` 的**用户 patch 行** `{id, name, config}`（无 `insert` 键）——即 `reconcileProfilePatches`（dsh-app-boot lib/index.js:3794）唯一接受的落点。负向对照：`hardGate` 等非 volatile 路径在写前即被同一闸门以「Config field "hardGate" is not volatile」拒绝、文件不被触碰——这正是 v0.7.4/v0.7.5 实机观测到的拒绝签名（profile patch mtime 不变、快速 rejected）：**运行中宿主装配的插件 schema 若早于 volatile 标注，宿主即在写前拒绝**；生效手段不变：重启宿主装配 v0.7.7 schema + 强刷浏览器。离线测试增至 56 项。

## v0.6（2026-11-02）

- **多 goal session 投影（`cyberneticsGoals`）**——goal 板每次变化把本 session 全部 goal 的整值快照 append 成一条 `plugin:cybernetics/goals` 事件（可跳过的插件记录，宿主持久化读取安全），服务端纯折叠、宿主整值推送，「目标」页签逐条渲染并就地更新；空板回退到 dsh-goal 单 goal 渲染。
- **执行者适配层**：`executor: 'ephemeral' | 'persistent'`（与 depth 正交）——persistent 用 Agent Teams 持久 teammate 执行 task 工作（首轮 spawn fresh，后续轮 sendMessage 投递委托书修订，`subagent/end` 捕获输出）；quick 由输出契约派生 verdict，full 把报告作为 `taskReport` 交给 round.js，verify/triage 仍以临时 agent 独立运行。审计日志记录 `executor`，goal 板记录 `memberName`。
- **只新增目标模型（append-only goals）**——goal 一经存在不再原地修改。`action: 'revise'`（必填 `reason`，可选 `objective`/`title`/`depth`/`executor`/`abortPrevious`）创建一个带 `parentGoalId` 的新 goal 并立即启动其第 1 轮，旧 goal 置 `superseded` + `supersededBy` 保留最终状态；已完成的 goal 同样走这条路径。`abortPrevious` 默认 false（旧轮跑完由 session agent 决定是否打断），true 时复用 cancel 路径。每次修订追加 `.cybernetics/revisions-<新goalId>.jsonl`。页签按两段排序（未完成在前、已完成 met/cancelled/superseded 在后，组内 `updatedAt` 倒序；服务端排序、客户端不重排），并显示「已被 <新标题> 取代」/「修订自 <旧标题>」；`GoalStatus` 增加 `superseded`。
- **板持久化与 rehydrate**——controller 的 goal 板在每个写点整值快照到 `<workspace>/.cybernetics/board-<sessionId>.json`（`{version, sessionId, savedAt, goals}`，同目录临时文件 + rename 原子替换，失败不阻断）；重启后首次工具调用拿到空内存板时从快照恢复（缺失/损坏/版本不符/非法记录一律空板，不抛错）并立即重推一次 `cyberneticsGoals` 投影，「目标」页签因此不再在重启后清空。「控制」页签新增每个 goal 的执行者行（状态 + 标题 + executor 临时/持久 + 持久 teammate 名称 + 第 N 轮，未完成在前、已完成在后）；`GoalView` 增加可选 `memberName`，投影折叠保留。快照是当前状态而非事件日志，`updatedAt` 不持久化。
- **第 0 步实验**（2026-11-02）：持久 teammate `analyst` 两轮真实知识库分析，持久记忆生效（次轮复用首轮结论，墙钟约减半）、委托书修订语义可行、自主分析质量超出委托书（fresh 上下文 + 详细委托书足以支撑领域判断）。记录见 docs/protocol.md 文末。

## v0.5

双档轮次（depth）——轻量分析 quick 单 agent 一轮直接反馈；复杂分析与变更走完整工作-验证循环（full）。

## v0.4 / v0.4.1

- v0.4：可选硬门（`hardGate: true`）——装配期从顶层 session agent 物理摘除执行工具（默认 bash/edit/write），编排从劝告变成结构；task agent 不受影响。
- v0.4.1：硬门增加 allowlist 模式（只保留读+编排工具，挡住 farm_unregister 类长尾变更工具）。

## v0.3

多 goal 板 + 编排者协议 + 异步轮（`start`/`collect`/`cancel`/`list`）+ task agent 工作委托书（brief）。

## v0.2

session-goal 模式 + 隐式触发 + 角色化 sub agent + 客户端 goal 页签。服务端已按 dsh 0.2.1-rc.3 真实 API 核对（tools.register / goals service / workingDirectory），客户端按 ModuleLoader 包装格式手写（参照 dsh-client-ui-goal / dsh-context）。**端到端回路尚未实跑**（此后的实测修正补上了这一课）。

## 实测修正记录（2026-11-02，dogfooding）

- **触发链路实测**：隐式提示注入 ✅、工具注册 ✅；执行原在 `ctx.get('workflowEngine')` 处报 "cannot get property ... without inject"（宿主 cordis 对未注入服务的属性访问直接抛错，goal 护栏不可达）。已改为静态 inject `workflowEngine` / `goals` / `workingDirectory`。
- **第二次实测修正**：首次重启后插件仍 pending——`workflowEngine` 是在 `delegation` group 的 isolate 里提供的（`isolate: workflowEngine: true`），顶层 insert 的行拿不到它。`cordis.patch.yml` 改为按组 id 插入（loader 方言：patch id 指向 group 行时追加进该组 config）。
- **第三次实测修正**：按组 id 插入也被跳过（dump-config 报 `entry "delegation" not found`）——`delegation` 组不在顶层 patch 索引，而是嵌在 `preset-standard`（`@deepseek-ai/dsh-agent-preset`）的 `config.plugins` 里。最终方案：profile 层 patch 整体重写 `preset-standard` 的 config，把 `dsh-cybernetics` 加进其 delegation 组；本插件的 bundle patch 清空为 `[]`。
- **第四次实测修正**：页签仍未出现——浏览器实测发现 boot graph 的 client combo 不含本包：客户端扫描只枚举**顶层** loader entries。最终方案：插件回到顶层行，`workflowEngine` 不再静态 inject，执行时经 `ctx.agentPresets.serviceFor(agent, 'workflowEngine')` 从 Agent 的 preset mount 读取（registry 的官方 root-realm 访问器）；inject 收窄为根级服务。同轮修复 goal 护栏：`goals.get()` 现严格要求 `phase === 'active'`，并按 goal id 重置轮次状态。
- **页签渲染两连修**：① inject 手动传的 `t` 遮蔽了槽位按 `locale: NS` 注入的正确翻译函数（字典注册前 bind 会解析为空串）——inject 不再传 t；② 宿主 jsx 变体忽略 `jsx(type, props, children)` 的第三参，children 必须放进 `props.children`，否则所有文本静默丢失、元素塌缩成空胶囊。修复后「目标 / 控制」两页签均完整渲染。
- **改名回归**：`@mars.liu` 改名把包名从 `dsh-cybernetics` 变成 `@mars.liu/dsh-cybernetics`，loader 行名同步了，但 `lib/client.js` 里 `__ModuleLoader__.load({ id })` 仍是短名 → boot 报 `loaded without registering`。不变量：**客户端 bundle 的注册 id 必须等于 package.json 的 `name`**（client-modules boot graph 以包名为行键，`dsh.client.inject` 里的依赖同样按包名解析）；短名只用于 loader 行 id。离线测试有断言锁死这条不变量。
