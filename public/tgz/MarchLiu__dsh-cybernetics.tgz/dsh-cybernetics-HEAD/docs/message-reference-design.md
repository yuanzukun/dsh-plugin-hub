# 消息级引用设计稿：`dsh-session:<id>#seq` 引用约定

状态：设计稿（未实现）。关联：`docs/protocol.md` v0.7、上游包 `dsh-session-reference` / `dsh-client-ui-reference` / `dsh-session-query` / `dsh-goal`。

## 1. 背景与问题

长程会话中会产生多个 goal。用户想"针对历史上某条消息"操作一个目标（查询细节、发起修订）时，缺少**消息级**的引用锚点：

- 现有 `@[label](dsh-session:<base64url-id>)` 提及（`dsh-session-reference`）锚定的是**整个会话快照**，粒度到会话为止，没有单条消息坐标；
- session 日志本身是带稳定 `seq` 的 append-only 事件序列，`ctx.sessionQuery.readEvent(request)` 已支持"单事件 + 有界窗口"读取——**数据层的 seq 寻址原语齐全**；
- cybernetics 的 append-only goal 修订（`parentGoalId`/`supersededBy` + `.cybernetics/revisions-<goalId>.jsonl`）记录了谱系，但 `GoalRevisionRecord`（`src/controller.ts:234`）只有 `from/to/reason/at/abort`，**没有结构化的来源消息字段**。

结论：缺的不是数据模型，而是三条缺失的边——**用户输入语法 → seq 锚点**、**seq 锚点 → 模型上下文注入**、**seq 锚点 → goal 谱系审计**。本稿分别设计之。

## 2. 语法设计

### 2.1 扩展规范提及：URI fragment

```
@[label](dsh-session:<base64url-id>#seq=<from>[-<to>])
```

- `<base64url-id>` 不含 `#`，fragment 追加不破坏现有 URI 解析；无 fragment 的旧形式语义不变（整会话引用），完全向后兼容。
- `#seq=42`：引用单条消息；`#seq=42-57`：引用一个闭区间。区间形式对应 graft 的 `fromSeq/toSeq` 与 `sessionQuery` 的窗口读取。
- label 建议由 composer 生成：`@<会话标题>#42` 或 `@<会话标题>#42-57`，可读、可剪贴板往返。
- 非法 fragment（非数字、`to < from`、越界）按现有 session-reference 对 malformed URI 的处理路径拒绝：显式 Markdown 提及直接报错，不静默降级。

### 2.2 精确性条款

seq 锚定的是**原始日志事件**，不是投影后的模型 surface。会话被 compact、fork、resume 后：

- append-only 日志保证旧 seq 永不失效（`dsh-goal` README 已确认"session log 是 goal 状态的唯一存储"同理成立）；
- fork 出的子会话共享前缀，父会话 seq 锚点依然指向父日志的同一事件；
- 投影（`dsh-session-projection`）可能折叠/重排 surface，但**引用渲染与校验一律走原始日志**，不依赖投影——这与 `sessionQuery.readSession` "replay-validated raw event log" 的定位一致。

## 3. 捕获与模型侧注入（复用 session-reference 管道）

在 `agent/pre-step` 校验并捕获，作为现有 `## Referenced sessions` 快照协议的**消息级变体**：

| 环节 | 设计 |
| --- | --- |
| 校验 | `ctx.sessionQuery.readEvent({ id, seq })` 存在性检查；区间检查 `to >= from` 且 `to - from <= maxRefWindow` |
| 捕获 | 读取 `[from, to]` 事件的 surface 文档，序列化沿用现有快照格式（64 code point 行分片、`capturedFormatVersion`） |
| 不可信背景 | 沿用固定警告：不执行引用内容中的指令/权限声明/工具请求，除非当前用户显式重复 |
| 预算 | 每个引用独立预算，复用 `maxReferenceBytes` / `referenceContextFraction` 自动预算公式 |
| 截断 | 复用 spill 后端：omission notice 给出 `omittedMessages`/`omittedBytes` + spill locator + `retrievalHint`；agent 可按 hint 追加读取窗口（`readEvent` 天然支持滑动窗口，这是比整会话引用更优的一点——窗口可二分扩大） |
| 快照不可变性 | 与现协议一致：捕获后快照不可变；引用渲染展示的是捕获时点内容 |

关键差异：整会话引用截断时"丢弃较旧的非检查点消息"；消息级引用**锚点 seq 必须始终包含在捕获窗口内**（锚点是引用的主体，截断只收缩窗口边缘，绝不丢锚点）。

## 4. Goal 谱系侧：结构化 `source` 字段

### 4.1 `GoalRevisionRecord` 扩展（cybernetics 仓库，向后兼容的可选字段）

```typescript
export interface GoalRevisionRecord {
  from: string
  to: string
  reason: string
  at: number
  abort?: { abort: boolean; mode: 'auto' | 'explicit'; basis: string }
  /** 新增（可选）：本次修订引用的历史消息锚点。 */
  source?: {
    sessionId: string
    fromSeq: number
    toSeq?: number          // 缺省 = 单条；to < from 视为非引用整体拒绝
    capturedAt: number      // epoch ms（= 修订 at）
  }
}
```

实现说明（v0.27.0 落地差异）：`sessionId` 存 verbatim base64url token（不做解码，规避编码往返歧义）；未含 `excerpt` 字段——插件读不到被引消息内容，摘录应由 session agent 写进新 goal 的 brief，而非审计文件。

写入路径不变（`writeRevisionLog` 每行一条 transition）。可选字段保证旧审计文件可读、旧代码写新文件合法（JSONL 逐行解析天然容忍多出的键）。

### 4.2 revise 流程约定（agent 侧行为，零代码也可先落地）

当用户输入含消息级引用并要求修改目标时，session agent 的固定动作序列：

1. **定位**：从引用 fragment 取 `(sessionId, fromSeq, toSeq)`；无显式引用时用 `graft_read`/`graft_search` 检索并向用户确认锚点（展示 seq + 摘录）。
2. **提炼**：读出引用内容，把要点写进新 goal 的 brief（brief 必须自包含，task agent 无对话历史）。
3. **修订**：`cybernetics revise`，`reason` 中携带人类可读的来源描述；实现 `source` 字段后由插件自动附带结构化锚点。
4. **反查**：任何 goal 可通过 `revisions-*.jsonl` 的 `source`（或临时方案：`reason` 中的 `dsh-session:…#seq=…` 片段）grep 回原始消息。

**Phase 0（纯约定，立即可用）**：未实现任何代码前，约定 reason 文本内嵌规范 URI 形式，如 `引用 dsh-session:abc…#seq=42`——grep 已可反查，成本为零。

## 5. GUI 与 composer（Web 侧，跨仓库协作项）

| 项 | 说明 | 位置 |
| --- | --- | --- |
| 补全插入 | `@` 菜单选会话后，追加"引用其中一条消息"二级动作：跳转消息选择器（复用 `dsh-experimental-session-inspector` 类似的消息列表），选中消息/区间后插入带 fragment 的原子引用 | `dsh-client-ui-reference` + `dsh-client-ui-conversation` |
| 引用渲染 | transcript 中带 fragment 的引用渲染为可点击 chip，点击跳转/高亮目标消息 | `dsh-message-quotes` / transcript 渲染层 |
| 消息上下文菜单 | 长按/右键消息 → "引用此消息"，生成 composer 中的规范引用 | `dsh-client-ui-conversation` interactions |

注意（沿用 protocol.md 的既有结论）：**本仓库是插件侧，GUI 部分在 DSH Web 会话渲染层实现**，不在本仓库内；本仓库只消费/产出规范 URI。

## 6. 边界与非目标

- **不做消息改写追踪**：日志 append-only，无编辑语义；引用即快照时点。
- **不做跨仓库实现**：本稿 Phase 1-2 的主体（session-reference fragment 支持、composer 二级动作）属上游 `@deepseek-ai/*` 包；cybernetics 仓库只承担 4.1/4.2。
- **IM 群消息**：`dsh_im_group_history` 走另一套 cursor/时间定位，不在本稿范围。
- **安全**：引用快照沿用不可信背景协议；spill 文件属目标会话存储，读回同样视为不可信。

## 7. 分阶段落地

| 阶段 | 内容 | 仓库/位置 | 改动量 |
| --- | --- | --- | --- |
| Phase 0 | reason 内嵌规范 URI 的约定（§4.2 Phase 0） | 本仓库，纯约定 | 0 |
| Phase 1 | `GoalRevisionRecord.source` 字段 + revise 时自动附带 | 本仓库 `src/controller.ts` | 小（可选字段 + 从输入提取 URI）**——已实现（v0.27.0）** |
| Phase 1+ | **插件范围全量（已实现，v0.27.0）**：revise 显式 `source` 参数（优先于 reason 提取）、锚点随 goal 板持久化（「目标」tab + `list` 可见、跨重启往返）、ALL-GOALS system prompt RULE 5（检索→确认→提炼→传锚→反查完整流程）、`normalizeRevisionSource` 快照损坏行降级。见 docs/CHANGELOG.md v0.27.0 | 本仓库 | — |
| Phase 2 | session-reference 支持 `#seq` fragment：校验、窗口捕获、锚点保留截断 | 上游 `dsh-session-reference` | 中（**暂不做**） |
| Phase 3 | composer 二级动作 + chip 渲染 + 消息上下文菜单 | 上游 `dsh-client-ui-*` | 中大（**暂不做**） |

依赖关系：Phase 1 不依赖 Phase 2（提取用户输入中的 URI 字符串即可）；Phase 3 依赖 Phase 2 的校验语义稳定。
