# VeriPower 用户指南

[English](USER-MANUAL.md)

本指南面向使用 coding agent 开展芯片前端开发的工程师，介绍如何准备任务、运行流程、复核成果，以及在修改或中断后继续工作。下文提示语中的 `{module_dir}` 请替换为模块工作目录的绝对路径；该目录保存原始需求、生成的成果和运行历史。

## 1. 准备环境

选择 agent harness，例如 Claude Code、OpenCode、DeepSeek Harness 或 Codex，按对应的平台指南安装：

[Claude Code](../.claude/README.md) · [OpenCode](../.opencode/README.md) · [DeepSeek Harness](../.dsh/README.md) · [Codex](../.codex-plugin/README.md)

平台指南说明安装、启用、更新及专用配置。启用插件后开启会话，让 agent 列出可用的 VeriPower skills，确认已加载。

流程脚本需要 Python 3.10 或更高版本，以及 [requirements.txt](../requirements.txt) 中列出的依赖。将依赖安装到 agent 使用的 Python 环境中。在源码仓库目录下可执行：

```bash
python3 -m pip install -r requirements.txt
```

随插件提供的完整流程使用 Synopsys SpyGlass、VCS/UVM、Verdi 波形工具、Design Compiler，以及用于时序和功耗分析的 PrimeTime。准备相应工具、许可证和单元库，并在启动 agent harness 的环境中提供相关配置。具体设置与工具排障见 [EDA 环境说明](eda-env.zh.md)。

可在独立会话中检查环境是否就绪：

> 使用 env-precheck skill，检查 VeriPower 全部阶段所需的环境。

该检查确认工具是否可用，并通过小型任务检查许可证与实际执行情况，报告哪些阶段可以运行、哪些问题需要处理。运行相关阶段前，先解决报告中的环境问题。配置工具期间可以先准备需求。

## 2. 明确任务

选定模块工作目录，将原始需求和参考材料放入 `intent/`：

```text
module_dir/
└── intent/
    ├── brainstorm.md
    └── ...                 参考模型、寄存器表或其他依据
```

输入文件名固定为 `intent/brainstorm.md`，内容可以沿用已有规格文档的格式。请说明：

- 要求的行为、接口、时钟与复位。
- 时序、面积、功耗和覆盖率目标，以及单位和适用条件。
- 各项参考材料的用途，包括已有 RTL 或测试。
- 尚未确定的设计选择、委托 agent 作出的决定，以及明确不设限制的指标。

将参考文件复制到 `intent/`，并在需求中引用。其他位置的文件不会自动纳入原始输入。符号链接不会跟踪目标文件内容的变化，因此应复制作为依据的材料，避免仅链接到外部文件。

如果需要讨论和梳理需求，可在独立会话中使用 `brainstorm`：

> 为 {module_dir} 运行 brainstorm skill，依据提供的需求和参考材料明确设计任务。

开始流程前，复核生成的 `intent/brainstorm.md` 及其引用材料。已有合适规格时可以直接使用；`brainstorm` 是准备输入的一种方式。已有 RTL 和测试可以作为参考提供，但仅将文件放入工作目录不会登记已完成的阶段。

## 3. 启动并跟进工作

开启已启用 VeriPower 的新会话，提出：

> 为 {module_dir} 运行 design-flow skill。

Agent 负责规格形成、RTL 实现和验证工作，并协调工具分析与返工。请说明哪些决定需要由你作出，以及任务是否需要形成接受记录。Agent 在已有授权范围内继续工作，遇到需要你补充信息或作出决定的问题时再提出。工具执行仍受 agent harness 的权限控制。

查看进度时，可以问：

> 报告 {module_dir} 的当前状态，包括未完成的工作、失败的检查，以及需要我决定的事项。

状态视图使用以下标记：

| 状态 | 含义与后续处理 |
|---|---|
| `missing` | 尚未收取过结果，由流程安排所需工作。 |
| `in-flight` | 已派发运行尚未收取；agent 确认执行者结束后收取结果。 |
| `valid` | 最新结果通过，且当前文件仍与记录一致。 |
| `stale` | 通过后，记录的输入或输出发生变化，需要重新评估受影响的工作。 |
| `failed` | 最新阶段判定失败，由 agent 调查原因并安排修复。 |
| `blocked` | 收取时未能取得可用的阶段结果，需要处理报告的原因。 |

工作停住时，让 agent 说明涉及的阶段、相关证据和下一步建议。缺少工具或许可证时，参照环境说明并使用 `env-precheck` 检查。设计或验证发现问题时，按需补充需求说明，由 agent 调查并修复。

## 4. 复核与保存成果

工作进行期间即可查看已发布的结果。可以要求 agent 对照原始需求汇总交付情况：

> 对照原始需求汇总 {module_dir} 的成果，列出每项需求的判定与技术证据，并说明测量条件、未解决的问题，以及需要在流程外另行判定的需求。

下表提供主要复核入口。目录相对于 `{module_dir}`，文件名相对于所在行的目录。各阶段的 `result.json` 记录判定和实际发布的成果清单。

| 复核内容 | 目录 | 优先查看 |
|---|---|---|
| 方案说明与需求台账 | `Design/specification/` | `design.md`、`requirements.json` |
| 验证规划 | `Verification/simulation-plan/` | `verification-plan.md` |
| RTL 实现 | `Design/rtl-design/` | `src/`、`rtl-files.json` |
| 功能仿真 | `Verification/simulation/` | `case-results-summary.md`、`structural-coverage.json`、`check-review.md` |
| Lint / CDC | `Design/lint-cdc/` | `lint-report.txt`、`cdc-report.txt` |
| 逻辑综合 | `Design/synthesis/` | `out/`、`reports/` |
| 时序分析 | `Design/timing-analysis/` | `timing-report.txt` |
| 功耗分析 | `Verification/power-analysis/` | `analysis.md`、`reports_ptpx/` |

从需求台账中的需求标识出发，核对设计决定、测试点和阶段判定是否对应原始要求，有无遗漏或放宽。再检查以下内容：

- 对照测试计划与实际执行结果，检查尚未验证的要求。预期行为应依据需求和独立参考材料建立。
- 核对单位、条件和分析范围。功耗结果是已执行场景在测量区间内的平均功耗。
- 查看豁免的技术依据、尚未解决的问题，以及由流程外部负责判定的需求。

### 完成与接受

所有必需阶段都有适用于当前成果的通过结果，且全部已派发运行均已收取时，流程完成。让 agent 在交付摘要中说明仍然存在的限制。

任务要求形成接受记录时，让 agent 核查当前结论，以及必需阶段的发布文件是否被最新输出记录覆盖，再按授权通过 `signoff` 记录接受决定。如果这一决定需要由你作出，agent 会提供技术依据并等待你确认。接受记录绑定当时的证据；产生新的阶段结论后，按任务要求重新接受。

### 保存工程

保留原始需求、设计与验证源码、约束，以及复核交付所需的证据。发布的 RTL、UVM 源码、约束、网表和报告，配齐所需文件、库和环境配置后，可以在 VeriPower 之外使用。

需要保存可继续工作的工程时，先等待正在执行的工作结束，再为整个模块目录保存独立副本，包括 `events.jsonl`、已发布结果和 `runs/`，同时保存工具与库的配置。发布文件与运行文件可能通过硬链接共享内容，因此归档副本必须独立于工作中的原件。

## 5. 修订与恢复

### 修改设计或验证

说明修改目的以及必须保留的要求。例如：

> 分析并解决 {module_dir} 中这项时序问题，再执行受影响的检查，保持要求的功能和接口。

如果已经手工修改文件，请说明位置，将修改纳入版本管理，并让流程重新评估，同时说明哪些修改必须保留。Agent 会分析修改的实际影响，确定可复用的证据和需要重新开展的检验，再根据实现、分析条件和测量范围，选择重新运行工具或重新评价已有测量，形成新的阶段结论。

### 修订需求

先让 agent 完成或停止正在执行的工作，并收取结果。更新 `intent/brainstorm.md` 中的原始需求及受影响的参考材料。

流程将 `intent/` 保持为只读。让 agent 恢复待修订文件和目录的写权限后再修改。需要讨论修订时，可以在独立会话中再次使用 `brainstorm`，以现有文档为输入。复核修订后的需求，再继续 `design-flow`。原始需求或参考材料内容的变化会引起整个流程的重新评估。

### 中断后继续

保留模块工作目录，在启用 VeriPower 的新会话中提出：

> 继续 {module_dir} 的设计流程。先检查尚未收取的运行，确认执行者结束后收取结果，再继续未完成的工作。

Agent 会检查工程历史和当前文件，确认先前启动的工作是否仍在运行，收取已结束运行的结果后继续。缺失或不可用的结果按 `blocked` 处理。已有通过结果在记录的输入和输出仍然一致时可以继续复用。

上述操作背后的方法与协调机制见[架构文档](ARCHITECTURE.zh.md)。
