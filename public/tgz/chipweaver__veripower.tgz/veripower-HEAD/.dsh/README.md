# VeriPower on DeepSeek Harness

VeriPower installs as a DeepSeek Harness profile layer. The adapter registers
the shared skills through the native provider.

## Install

Use DeepSeek Harness 0.2.1-alpha.2 or later in the 0.2.1 release line. With
[DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) installed,
add VeriPower to the profile you will run:

```bash
dsh plugin --profile web add "veripower@git+https://github.com/chipweaver/veripower.git"
dsh web
```

For a working copy:

```bash
dsh plugin --profile web add /path/to/veripower
dsh web
```

Use the long-lived `web` profile for the design flow: it keeps the session
available for stage completions and human approval prompts. `headless` is a
one-shot task runner.

Ask the agent to list the VeriPower skills, then run `brainstorm` and
`design-flow`. Python and EDA prerequisites are in the
[user manual](../docs/USER-MANUAL.md). DeepSeek Harness's
[bundle guide](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/publish.md)
explains profile installation and layer ordering.

## Runtime behavior

The root [package.json](../package.json) declares the bundle patch at
[cordis.patch.yml](cordis.patch.yml), which loads
[plugins/veripower.js](plugins/veripower.js).

The adapter locates this installation's `skills/` directory and registers it
through an isolated filesystem skill provider. No global skill symlink or
manually configured skill path is needed.

The adapter loads bare skill names through `skill`. Background executors use native
`subagent` activations, which return `subagentId` immediately and deliver completion
notices to the parent. The host's system prompt supplies these native operations to
both parent and child agents.

The adapter supplies post-dispatch scheduling context. The profile supplies execution tools
and permissions. The shared design-flow skill coordinates
execution and collection; the kernel owns stage routing and validity.

## Update or remove

To update:

```bash
dsh plugin --profile web update veripower
```

To remove:

```bash
dsh plugin --profile web remove veripower
```

Restart the profile after either operation. Plugin management forwards to pnpm
in that profile and updates its bundle layers.

Collect active stage runs before uninstalling. Removal can delete the CLI files
that an executor or its parent still needs. Restore the bundle and resume the
session before collecting work interrupted by removal.

To disable the installed adapter, add this entry to the profile's `cordis.patch.yml`:

```yaml
- id: veripower-dsh
  disabled: true
```

Remove the entry to re-enable it and restart the profile. After removal, the profile
should contain neither the `veripower` dependency nor its bundle layer, and a fresh
runtime should expose neither its skills nor its tool mapping.

## Check the integration

```bash
dsh --profile web --dump-config
```

The composed configuration should include the `veripower-dsh` layer entry. In the
web session, check that skills are available, task completions return to the
parent, and host permissions remain effective.

From a VeriPower checkout, `node --check .dsh/plugins/veripower.js` checks adapter
syntax. Shared tests and the distinction between runtime, model and EDA checks
are described in [testing](../tests/README.md).
