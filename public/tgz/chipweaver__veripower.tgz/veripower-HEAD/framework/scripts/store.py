"""Module storage: event I/O, artifact validation, input protection and publication."""

from __future__ import annotations

import fnmatch
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

import jsonschema
from referencing import Registry, Resource
from referencing.jsonschema import DRAFT202012

sys.path.insert(0, str(Path(__file__).parent))
import rules  # noqa: E402

PLUGIN_ROOT = Path(__file__).resolve().parents[2]
EVENT_SCHEMA_DIR = PLUGIN_ROOT / "framework" / "references" / "schemas" / "events"


def read_events(module: str) -> list[dict]:
    p = Path(module) / "events.jsonl"
    if not p.exists():
        return []
    out = []
    for i, line in enumerate(p.read_text().splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError as e:
            sys.exit(f"read_events: corrupt line {i} of {p}: {e.msg}")
    return out


ENVELOPE_URI = "https://veripower.local/schemas/envelope.schema.json"
ENVELOPE_SCHEMA_PATH = (
    PLUGIN_ROOT / "framework" / "references" / "schemas" / "envelope.schema.json"
)


def envelope_registry() -> Registry:
    """Register the shared envelope for event and stage schema references."""
    envelope = Resource.from_contents(
        json.loads(ENVELOPE_SCHEMA_PATH.read_text()),
        default_specification=DRAFT202012,
    )
    return Registry().with_resource(ENVELOPE_URI, envelope)


def freeze_inputs(module: str) -> None:
    """Keep intent owner-read-only, including between runs and during queries.

    Preserve other permission bits and leave symlink targets unchanged."""
    for key in rules.PIPELINE_INPUTS:
        root = Path(module) / key
        if not root.exists():
            continue
        for q in (root, *root.rglob("*")):
            if (
                q.is_symlink()
            ):  # chmod follows a link; its target may be outside the tree
                continue
            mode = q.stat().st_mode
            if mode & 0o200:
                q.chmod(mode & ~0o200)


def append_event(module: str, event: dict, ts: str) -> None:
    etype = event.get("type")
    schema_path = EVENT_SCHEMA_DIR / f"{etype}.schema.json"
    if not schema_path.is_file():
        sys.exit(f"append_event: no schema for event type {etype!r}")
    schema = json.loads(schema_path.read_text())
    record = {"ts": ts, **event}  # ts first
    try:
        jsonschema.Draft202012Validator(schema, registry=envelope_registry()).validate(
            record
        )
    except jsonschema.ValidationError as e:
        sys.exit(f"append_event: {etype} schema violation: {e.message}")
    read_events(module)
    p = Path(module) / "events.jsonl"
    p.parent.mkdir(parents=True, exist_ok=True)
    previous = p.read_bytes() if p.exists() else b""
    separator = b"\n" if previous and not previous.endswith(b"\n") else b""
    record_bytes = json.dumps(record, ensure_ascii=False).encode() + b"\n"
    payload = separator + record_bytes
    file_descriptor = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o666)
    try:
        if os.write(file_descriptor, payload) != len(payload):
            raise OSError(f"append_event: incomplete write to {p}")
    finally:
        os.close(file_descriptor)


def validate_result(rule_name: str, result: dict) -> str | None:
    """Return the first stage-schema error, or None for a valid result.

    Schema files are maintained with the plugin; loading errors propagate."""
    skill_name = rules.RULES[rule_name].skill
    schema_path = PLUGIN_ROOT / "skills" / skill_name / "references/result.schema.json"
    stage_schema = json.loads(schema_path.read_text())
    validator = jsonschema.Draft202012Validator(
        stage_schema, registry=envelope_registry()
    )
    errors = sorted(validator.iter_errors(result), key=lambda e: list(e.absolute_path))
    if not errors:
        return None
    err = errors[0]
    path = "$" + "".join(
        f"[{p!r}]" if isinstance(p, int) else f".{p}" for p in err.absolute_path
    )
    return f"schema violation at {path}: {err.message}"


def is_contained_relative_path(rel: str) -> bool:
    """True iff `rel` is a containment-safe relative path: not absolute and not
    escaping its base after normalization. Lexical only — does NOT resolve()
    (so a legitimate symlink artifact is unaffected; symlink-traversal is handled
    separately by copy_artifact's follow_symlinks=False)."""
    if os.path.isabs(rel):
        return False
    norm = os.path.normpath(rel)
    return not (norm == ".." or norm.startswith(".." + os.sep))


def resolve_sim_run(root: Path, sim_run) -> str:
    """Absolute location of a specific past simulation run: <sim-stage>/runs/<N>.
    Dedicated runtime guard (NOT is_contained_relative_path, which rejects absolute paths): N must
    be a positive integer and the resolved runs/<N> must sit directly under the
    simulation stage's runs/ directory."""
    try:
        n = int(str(sim_run))
    except ValueError:
        raise ValueError(f"sim_run not an integer: {sim_run!r}")
    if n < 1:
        raise ValueError(f"sim_run must be a positive integer: {n}")
    sim_root = (root / Path(*rules.RULES["simulation"].workdir_root)).resolve()
    runs = sim_root / "runs"
    run_dir = (runs / str(n)).resolve()
    if run_dir.parent != runs:
        raise ValueError(f"sim_run escapes simulation runs/: {run_dir}")
    return str(run_dir)


def write_dispatch(
    root: Path,
    rule: str,
    workdir,
    params=None,
    scope=None,
    caused_by=None,
    reasons=None,
) -> None:
    """Write absolute input locations and supplied rework context to dispatch.json.

    Stage inputs name their producer's canonical directory; external inputs name
    their own root. The sim_run parameter selects a historical simulation run.
    Scope, source records and decision reasons are supplied by the kernel."""
    r = rules.RULES[rule]
    table: dict[str, str] = {}
    for key, globs in r.inputs.items():
        g0 = globs[0]
        if g0 in rules.PIPELINE_INPUTS:
            table[key] = str((root / g0).resolve())
            continue
        # Every glob under one input key shares a single producer, so globs[0]'s
        # producer represents the whole key.
        prod = rules.producer_of(g0)
        if prod is None:
            raise ValueError(f"{rule}: input key {key!r} glob {g0!r} has no producer")
        table[key] = str((root / Path(*rules.RULES[prod].workdir_root)).resolve())
    if params and "sim_run" in r.params and "sim_run" in params:
        table["sim_run"] = resolve_sim_run(root, params["sim_run"])
    doc: dict = {"inputs": table}
    if scope:
        doc["scope"] = list(scope)
    if caused_by:
        doc["caused_by"] = list(caused_by)
    if reasons:
        doc["reasons"] = list(reasons)
    (Path(workdir) / "dispatch.json").write_text(
        json.dumps(doc, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


CARRY_EXCLUDE = (
    "result.json",
    "runs",
    "dispatch.json",
)


def carry_self(root: Path, rule: str, workdir) -> None:
    """Copy the rule's selected canonical products into a fresh run directory.

    Preserve links between copied products; copy the content of references outside
    that set. All copies are writable without modifying the original targets.
    Exclude framework files and the rule's per-round review records."""
    r = rules.RULES[rule]
    if not r.carry:
        return
    stage_dir = (root / Path(*rules.RULES[rule].workdir_root)).resolve()
    if not stage_dir.is_dir():
        return
    dest = Path(workdir).resolve()
    products = (p for p in stage_dir.iterdir() if p.name not in CARRY_EXCLUDE)
    sources = (
        src
        for p in products
        for src in ([p, *p.rglob("*")] if p.is_dir() and not p.is_symlink() else [p])
    )
    copies = {}
    for src in sources:
        rel = src.relative_to(stage_dir)
        rel_str = rel.as_posix()
        if not any(fnmatch.fnmatch(rel_str, g) for g in r.carry):
            continue
        if any(fnmatch.fnmatch(rel_str, ng) for ng in r.no_carry):
            continue
        copies[src] = rel
    with tempfile.TemporaryDirectory(prefix=".carry-", dir=dest.parent) as temporary:
        pending = Path(temporary)
        copy_products({src: pending / rel for src, rel in copies.items()})
        pending.chmod(dest.stat().st_mode)
        os.replace(pending, dest)


def copy_products(copies: dict[Path, Path], ancestors=frozenset()) -> None:
    for src, dst in copies.items():
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.is_symlink():
            target = src.parent / os.readlink(src)
            if target not in copies:
                target = src.resolve(strict=True)
            if target in copies:
                dst.symlink_to(os.path.relpath(copies[target], dst.parent))
            else:
                copy_referenced_content(src, dst, ancestors)
        elif src.is_dir():
            dst.mkdir(exist_ok=True)
        else:
            copy_referenced_content(src, dst, ancestors)


def copy_referenced_content(src: Path, dst: Path, ancestors=frozenset()) -> None:
    """Materialize a referenced file or tree as independent, writable content."""
    resolved = src.resolve(strict=True)
    if src.is_dir():
        if resolved in ancestors or dst.is_relative_to(resolved):
            raise ValueError(f"cannot copy recursive directory reference: {src}")
        copies = {
            p: dst / p.relative_to(resolved) for p in [resolved, *resolved.rglob("*")]
        }
        copy_products(copies, ancestors | {resolved})
    else:
        shutil.copy2(src, dst)
        dst.chmod(dst.stat().st_mode | 0o200)


def copy_artifact(src: Path, dst: Path) -> None:
    """Hardlink a directory tree, preserving symlink inodes without following them."""
    if dst.exists():
        raise FileExistsError(f"artifact destination exists: {dst}")
    dst.mkdir()
    for entry in src.iterdir():
        if entry.is_symlink():
            # Preserve the symlink inode without traversing its target.
            os.link(str(entry), str(dst / entry.name), follow_symlinks=False)
        elif entry.is_dir():
            copy_artifact(entry, dst / entry.name)
        else:
            os.link(str(entry), str(dst / entry.name))


def artifact_roots(artifacts: list[dict]) -> list[Path]:
    """Select each declared file once, including files covered by a directory."""
    roots: list[Path] = []
    for rel in sorted(
        {Path(a["path"]) for a in artifacts}, key=lambda p: (len(p.parts), str(p))
    ):
        if rel == Path("result.json"):
            continue
        if not is_contained_relative_path(str(rel)):
            raise ValueError(f"artifact path escapes run dir: {rel}")
        if not rel.parts or rel.parts[0] == "runs":
            raise ValueError(f"artifact path conflicts with run storage: {rel}")
        if not any(parent in rel.parents for parent in roots):
            roots.append(rel)
    return roots


def promote(root: Path, rule: str, run_n: int) -> None:
    """Publish a prepared view; restore the previous view if a move fails.

    Run directories retain the source artifacts. Interrupted process termination
    can leave a staging directory; an explicit reap rebuilds the requested view.
    """
    stage_dir = (root / Path(*rules.RULES[rule].workdir_root)).resolve()
    run_dir = stage_dir / "runs" / str(run_n)
    rj_src = run_dir / "result.json"
    artifacts = artifact_roots(json.loads(rj_src.read_text()).get("artifacts", []))
    temporary = Path(tempfile.mkdtemp(prefix=".promote-", dir=stage_dir))
    ready, previous = temporary / "ready", temporary / "previous"
    moved, published = [], []
    try:
        ready.mkdir()
        previous.mkdir()
        os.link(rj_src, ready / "result.json")
        for rel in artifacts:
            src, dst = run_dir / rel, ready / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            if not src.is_symlink() and src.is_dir():
                copy_artifact(src, dst)
            else:
                os.link(src, dst, follow_symlinks=False)

        for entry in list(stage_dir.iterdir()):
            if entry.name == "runs" or entry == temporary:
                continue
            os.rename(entry, previous / entry.name)
            moved.append(entry.name)
        for entry in list(ready.iterdir()):
            os.rename(entry, stage_dir / entry.name)
            published.append(entry.name)
    except BaseException:
        for name in reversed(published):
            os.rename(stage_dir / name, ready / name)
        for name in reversed(moved):
            os.rename(previous / name, stage_dir / name)
        shutil.rmtree(temporary)
        raise
    shutil.rmtree(temporary)
