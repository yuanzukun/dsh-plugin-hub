"""Read the authored JSON sidecars this stage emits — validating on the way in.

The transcriber authors requirements.json; the decomposer authors clocks.json and top-io.json;
a third sub-Task authors check-hints.json. Every read goes through `read_sidecar`, so a
malformed sidecar is reported by **whichever verb needed it, at the moment it needed it**.
That placement is the point: a file's own shape is not a cross-file property, so it has no
business waiting for a gate that runs after every author has finished.

The error names every violation at once, not the first — whoever is fixing the sidecar wants
the whole list.

Schemas are LOADED from references/, never restated in Python. The rules JSON Schema cannot
carry — cross-field arithmetic, uniqueness, the finiteness of a number `json.loads` already
accepted — are registered below against the files they belong to, so a file's content rules
stay in one place whether or not the schema language can express them.
"""

import json
import math
import re
from pathlib import Path

from jsonschema import Draft202012Validator

REFERENCES = Path(__file__).resolve().parent.parent.parent / "references"
BIT_RANGE_RE = re.compile(r"\[(\d+):(\d+)\]$")


class SidecarError(Exception):
    """A sidecar is missing, unreadable, or violates its own contract."""

    def __init__(self, name: str, violations: list[dict]):
        self.name = name
        self.violations = violations
        detail = "; ".join(
            f"{v.get('at', '')} {v['error']}".strip() for v in violations
        )
        super().__init__(f"{name}: {detail}")


def base_name_rule(doc) -> list[dict]:
    """A top-IO `name` is the base identifier alone; `width` carries the width.

    The string reaches `get_ports` and `abstract_port` verbatim, and the TB signal and
    transaction-field declarations verbatim. A bit range survives none of that trip: DC and
    PrimeTime match zero ports for `get_ports token_in[4:0]`, so the port loses its IO
    constraint and the STA grades a design it never fully timed; the UVM field macro built
    from the same string will not compile. A parameterized declaration is worse still —
    `[DATA_WIDTH-1:0]` names a parameter no tool downstream evaluates.

    A `width` that agrees with the range in the name does not make this any better: the range
    is wrong here either way.
    """
    out: list[dict] = []
    if not isinstance(doc, list):
        return out
    for e in doc:
        if not isinstance(e, dict):
            continue
        n = e.get("name")
        if isinstance(n, str) and "[" in n:
            out.append(
                {
                    "at": f"${n}",
                    "error": "name carries a bit range; write the base identifier and "
                    "let width carry it",
                }
            )
    return out


# The dims a judging stage's script compares; every other judge takes no target.
def requirements_rule(doc) -> list[dict]:
    """What the ledger's schema cannot say: ids are unique; a scenario only qualifies
    power_mw; a value is finite (which dim a judge can compare is the judge's own fact, refused
    by the stage that would have to measure it) (`json.loads` accepts NaN / Infinity and `type: number` admits them, and a NaN
    bound makes every comparison false — a gate silently disarmed)."""
    out: list[dict] = []
    if not isinstance(doc, list):
        return out
    seen: dict[str, int] = {}
    for i, r in enumerate(doc):
        if not isinstance(r, dict):
            continue
        rid = r.get("id")
        if rid in seen:
            out.append(
                {"at": f"$[{i}].id", "error": f"{rid!r} already used at $[{seen[rid]}]"}
            )
        seen.setdefault(rid, i)
        t = r.get("target")
        if not isinstance(t, dict):
            continue
        if "scenario" in t and t.get("dim") != "power_mw":
            out.append(
                {
                    "at": f"$[{i}].target.scenario",
                    "error": "only a power_mw bound names a scenario",
                }
            )
        v = t.get("value")
        if isinstance(v, float) and not math.isfinite(v):
            out.append(
                {"at": f"$[{i}].target.value", "error": f"must be finite (got {v!r})"}
            )
    return out


CONTENT_RULES = {
    # A top-io name reaches three tools verbatim, so a range in it is banned outright rather
    # than cross-checked against `width`.
    "top-io.json": base_name_rule,
    "requirements.json": requirements_rule,
}


def validate_doc(name: str, doc) -> list[dict]:
    """Every violation in an already-parsed sidecar doc — schema first, then the content
    rules JSON Schema cannot carry.

    Schema files belong to the plugin; loading errors propagate."""
    schema_path = REFERENCES / f"{Path(name).stem}.schema.json"
    schema_doc = json.loads(schema_path.read_text(encoding="utf-8"))
    violations = [
        {
            "at": "$"
            + "".join(
                f"[{q!r}]" if isinstance(q, int) else f".{q}" for q in err.absolute_path
            ),
            "error": err.message,
        }
        for err in sorted(
            Draft202012Validator(schema_doc).iter_errors(doc),
            key=lambda e: list(e.absolute_path),
        )
    ]
    return violations + CONTENT_RULES.get(name, lambda document: [])(doc)


def read_sidecar(workdir, name: str) -> list[dict]:
    """One sidecar's entries, validated against references/<name>.schema.json. Raises
    SidecarError naming every violation."""
    try:
        doc = json.loads((Path(workdir) / name).read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise SidecarError(name, [{"error": "missing"}]) from None
    except (OSError, json.JSONDecodeError) as exc:
        raise SidecarError(name, [{"error": f"unreadable: {exc}"}]) from None
    violations = validate_doc(name, doc)
    if violations:
        raise SidecarError(name, violations)
    return doc
