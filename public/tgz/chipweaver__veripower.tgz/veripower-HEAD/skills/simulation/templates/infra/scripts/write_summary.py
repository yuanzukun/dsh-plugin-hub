#!/usr/bin/env python3
"""Generate case-results.json and the summary a human reads off a run.

Goal: stable PASS / FAIL / NOT_RUN per testcase. Which requirement a test serves is not on this
page: a testpoint's covers[] names the check hints, and each hint names the requirements.json
rows it establishes, so the trace runs plan -> hint -> row and this page adds nothing to it.
"""

import argparse
import json
import os
import re
import sys
from pathlib import Path


def load_results(log_path):
    """Parse regression-log.txt and return list of result dicts.

    Stable RESULT line format (see run_vcs_regression.sh):
        RESULT <test_id> <PASS|FAIL> [...]
    """
    if not log_path.is_file():
        sys.exit(
            f"write_summary: missing {log_path}; run `make smoke` or `make regress` first"
        )
    results = []
    pattern = re.compile(r"^RESULT\s+(\S+)\s+(PASS|FAIL)(?:\s+.*)?$")
    for line in log_path.read_text(encoding="utf-8").splitlines():
        match = pattern.match(line.strip())
        if match:
            results.append({"test_id": match.group(1), "status": match.group(2)})
    return results


def main():
    parser = argparse.ArgumentParser(
        description="Generate simulation summary artifacts."
    )
    parser.add_argument(
        "--verification-dir", required=True, help="Verification directory root."
    )
    args = parser.parse_args()
    root = Path(args.verification_dir).resolve()
    # Where run_vcs_regression.sh put the per-test logs this run: same env var, so the
    # summary points a reader at the directory that exists rather than a fixed guess.
    log_dir = os.environ.get("RUN_LOG_DIR") or "logs"
    testlist_path = root / "tests" / "testlist.json"
    log_path = root / "regression-log.txt"
    counts_path = root / "case-results.json"
    summary_path = root / "case-results-summary.md"
    for path in (root / "result.json", counts_path, summary_path):
        path.unlink(missing_ok=True)

    if not testlist_path.is_file():
        sys.exit(
            f"write_summary: missing {testlist_path}; "
            "run sim bootstrap --plan <simulation-plan workdir> first to generate the scaffold"
        )

    testlist = json.loads(testlist_path.read_text(encoding="utf-8"))
    results = load_results(log_path)
    result_by_test = {item["test_id"]: item for item in results}

    tests = testlist.get("tests", [])

    total = len(results)
    passed = sum(1 for r in results if r["status"] == "PASS")
    failed = sum(1 for r in results if r["status"] == "FAIL")
    not_run = sum(1 for t in tests if t["test_id"] not in result_by_test)
    testcase_pass_rate = 0.0 if total == 0 else 100.0 * passed / total

    counts = {
        "total_tests": total,
        "passed_tests": passed,
        "failed_tests": failed,
        "not_run_tests": not_run,
        "testcase_pass_rate_percent": round(testcase_pass_rate, 1),
    }
    # The structured home. `sim finalize` reads its counts here rather than re-parsing the
    # rendering below, which exists for a human.
    counts_path.write_text(
        json.dumps(counts, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    # Per-test table.
    trace_rows = []
    for test in tests:
        result = result_by_test.get(test["test_id"])
        status = result["status"] if result else "NOT_RUN"
        trace_rows.append(
            f"| {test['test_id']} | {','.join(test['suites'])} | **{status}** |"
        )
    trace_table = "\n".join(trace_rows) or "| n/a | n/a | n/a |"

    # Failed-case detail table.
    action_rows = []
    for item in results:
        if item["status"] == "FAIL":
            action_rows.append(
                f"| {item['test_id']} | FAIL | Fix; see {log_dir}/{item['test_id']}.log |"
            )
    for test in tests:
        if test["test_id"] not in result_by_test:
            action_rows.append(
                f"| {test['test_id']} | NOT_RUN | Recompile and re-run |"
            )
    action_table = "\n".join(action_rows) or "| - | - | - |"

    # Overall verdict line.
    if failed == 0 and not_run == 0:
        verdict_line = "> **ALL PASS** — ready for human review."
    else:
        issues = []
        if failed:
            issues.append(f"FAIL={failed}")
        if not_run:
            issues.append(f"NOT_RUN={not_run}")
        verdict_line = f"> **Attention required**: {', '.join(issues)}."

    summary_text = f"""# Case Results Summary

## Run Context

- Module: `{testlist.get("module", "unknown")}`
- Top: `{testlist.get("top", "unknown")}`
- Regression log: `regression-log.txt`

## Overall Status

{verdict_line}

| Metric | Value |
|--------|-------|
| Total executed | {total} |
| PASS | {passed} |
| FAIL | {failed} |
| NOT_RUN | {not_run} |
| Testcase pass rate | {testcase_pass_rate:.1f}% |

## Results

| Testcase | Suites | Result |
|----------|--------|--------|
{trace_table}

## Action Items

| Testcase | Status | Action |
|----------|--------|--------|
{action_table}

## Status Legend

- `PASS`: UVM completed without UVM_FATAL/UVM_ERROR and the simulator exited successfully.
- `FAIL`: errors reported; investigate per-test log in `{log_dir}/`.
- `NOT_RUN`: testcase declared but no result line present (likely a compile or selection issue).
"""
    summary_path.write_text(summary_text.rstrip() + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
