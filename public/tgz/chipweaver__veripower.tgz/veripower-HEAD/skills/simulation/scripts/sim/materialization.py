#!/usr/bin/env python3
"""sim check-materialization — the env-build child's own exit gate.

That child gates its STATUS: DONE on this verb's exit code; it writes no result.json, and
finalize's run remains the authoritative verdict. Exit 1 when a required scaffold SV file is
missing or a TODO marker survives in tb/uvm/**, which the orchestrator records as
the compile route-out. Presence only: whether a check verifies the right thing is the
check-adequacy review's question, not this one.
"""

from __future__ import annotations

import sys
from pathlib import Path

from sim.checks import materialization_errors
from sim.plan import load_plan


def run(workdir, plan_dir) -> int:
    workdir = Path(workdir).resolve()
    scaffold_doc = load_plan(plan_dir)
    errs = materialization_errors(workdir, scaffold_doc)
    if errs:
        print(
            "[sim check-materialization] incomplete:\n  - "
            + "\n  - ".join(errs)
            + "\nFill the scaffold (no TODO may survive; all required files present), then re-run.",
            file=sys.stderr,
        )
        return 1
    print("check-materialization: OK")
    return 0
