#!/usr/bin/env python3
"""Generate the UVM scaffold from the simulation-plan sidecars, for the bootstrap verb.

Renders one tree of UVM source under <output-dir>/tb/uvm/ (interfaces, transactions, drivers,
monitors, agents, sequences, tests, RM, scoreboard, env, tb_top, tb_pkg.sv, filelist.f,
generated_tests.svh, tests/testlist.json), each carrying TODO markers for the simulation agent
to fill. Consumes the authored tb-scaffold.json and sequences.json: `rm.inports`
and `scoreboard.observer` name agents, and the `<module>_<agent>_txn` type is built here, so
nothing has to un-wrap a name to recover the identity inside it.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from sim.boundary import Boundary, dut_port_map
from sim.plan import load_plan
from sim.rendering import (
    render_template_file,
    signal_declarations,
)


def run_scaffold(plan_dir, template_dir: Path, out_dir: Path, spec_dir) -> int:
    spec = load_plan(plan_dir)
    boundary = Boundary(spec_dir)
    module = spec["module"]
    top = spec["top"]
    agents = spec.get("agents", [])
    if not agents:
        sys.exit(
            "[sim bootstrap] tb-scaffold.json declares no agents. Nothing would drive or observe the "
            "DUT, and the tree this renders would compile against transaction types no agent "
            "produces. Author the agents and their interface_groups in simulation-plan's "
            "tb-scaffold.json, then rerun check-scaffold."
        )
    rm_cfg = spec.get("rm", {})
    sb_cfg = spec.get("scoreboard", {})
    sequences = spec.get("sequences", [])
    tests = spec.get("tests", [])

    rm_name = rm_cfg.get("name", "rule_rm")
    sb_name = sb_cfg.get("name", "scoreboard")
    # Determine the agent whose transactions the scoreboard checks.
    obs_agent = sb_cfg.get("observer", "")
    if not obs_agent:
        # Omitting it is legal only with one agent (simplan check-scaffold rejects the rest),
        # so the one agent IS the observer; anything else here means the gate was bypassed.
        if len(agents) != 1:
            sys.exit(
                f"[sim bootstrap] scoreboard.observer is absent with {len(agents)} agents. "
                "It is authored in simulation-plan and check-scaffold requires it whenever "
                "more than one agent is declared."
            )
        obs_agent = agents[0]["name"]

    # Agent monitor streams feeding the RM.
    rm_inports = rm_cfg.get("inports", [])

    # Two sets, split on who owns the content. `pending` is stubs: created once, then the
    # round that filled them owns them. `derived` is everything computed from the sidecars —
    # rewritten every round, because a stub kept for its author's sake is the right default
    # and a stale derivation is not: the plan or the boundary moving has to reach the SV.
    pending: list[tuple[Path, str]] = []
    derived: list[tuple[Path, str]] = []

    reset_connections = "".join(f", .{r['name']}({r['name']})" for r in boundary.resets)
    reset_ports = "\n".join(
        f"{', ' if i else ''}input logic [{r['width'] - 1}:0] {r['name']}  // active {r['reset_polarity']}, "
        f"{r['reset_kind']}, clock domain {r['clock_domain']}"
        for i, r in enumerate(boundary.resets)
    )
    # Keep the derived port list outside the authored clocking blocks and modports.
    derived.append(
        (out_dir / "tb/uvm/interface" / f"{module}_reset_ports.svh", reset_ports)
    )

    # --- Per-agent files ---
    for agent in agents:
        aname = agent["name"]
        mode = agent["mode"]
        # Data ports come from the agent groups; clocks and resets connect separately at tb_top.
        signals = [
            port
            for group in agent["interface_groups"]
            for port in boundary.groups.get(group, [])
        ]

        base = {"MODULE": module, "TOP": top, "AGENT_NAME": aname}

        # Interface: the clocking blocks are authored, the signal list is not.
        content = render_template_file(template_dir, "agent_if.sv", base)
        dest = out_dir / "tb" / "uvm" / "interface" / f"{module}_{aname}_if.sv"
        pending.append((dest, content))
        content = render_template_file(
            template_dir,
            "agent_signals.svh",
            {**base, "SIGNAL_DECLARATIONS": signal_declarations(signals)},
        )
        derived.append(
            (
                out_dir / "tb" / "uvm" / "interface" / f"{module}_{aname}_signals.svh",
                content,
            )
        )

        # Transaction: the debug formatter is authored, the field list is not.
        content = render_template_file(template_dir, "agent_txn.sv", base)
        dest = out_dir / "tb" / "uvm" / "transaction" / f"{module}_{aname}_txn.sv"
        pending.append((dest, content))
        for tmpl, slot, val, suffix in (
            (
                "agent_fields.svh",
                "FIELD_DECLARATIONS",
                "\n".join(
                    f"  rand logic [{signal['width'] - 1}:0] {signal['name']};"
                    if signal["width"] > 1
                    else f"  rand logic        {signal['name']};"
                    for signal in signals
                ),
                "fields",
            ),
            (
                "agent_field_macros.svh",
                "FIELD_MACROS",
                "\n".join(
                    f"    `uvm_field_int({signal['name']}, UVM_ALL_ON)"
                    for signal in signals
                ),
                "field_macros",
            ),
        ):
            content = render_template_file(template_dir, tmpl, {**base, slot: val})
            derived.append(
                (
                    out_dir
                    / "tb"
                    / "uvm"
                    / "transaction"
                    / f"{module}_{aname}_{suffix}.svh",
                    content,
                )
            )

        # Monitor (all agents have a monitor)
        content = render_template_file(template_dir, "agent_monitor.sv", base)
        dest = out_dir / "tb" / "uvm" / "agent" / f"{module}_{aname}_monitor.sv"
        pending.append((dest, content))

        # Driver (rendered for every agent so agent_agent.sv's `m_driver` type
        # declaration always resolves; a passive agent's driver class compiles but is
        # never instantiated -- agent_agent.sv guards creation with get_is_active()).
        content = render_template_file(
            template_dir,
            "agent_driver.sv",
            {
                **base,
                "DRIVER_TASK_NOTE": "  // TODO(driver): Implement the drive protocol through vif."
                if mode == "active"
                else "",
            },
        )
        dest = out_dir / "tb" / "uvm" / "agent" / f"{module}_{aname}_driver.sv"
        pending.append((dest, content))

        # Agent assembly
        content = render_template_file(template_dir, "agent_agent.sv", base)
        dest = out_dir / "tb" / "uvm" / "agent" / f"{module}_{aname}_agent.sv"
        pending.append((dest, content))

    # --- Sequences ---
    for seq in sequences:
        seq_agent = seq.get("agent", agents[0]["name"])
        content = render_template_file(
            template_dir,
            "seq.sv",
            {
                "MODULE": module,
                "TOP": top,
                "SEQ_NAME": seq["name"],
                "AGENT_NAME": seq_agent,
                "SEQ_DESC": seq.get("desc", ""),
            },
        )
        dest = out_dir / "tb" / "uvm" / "seq" / f"{module}_{seq['name']}_seq.sv"
        pending.append((dest, content))

    # --- RM ---
    # Build analysis_imp declarations for each inport
    rm_imp_decl_macros: list[str] = []  # `uvm_analysis_imp_decl(_suffix) before class
    rm_imp_lines: list[str] = []
    rm_imp_new_lines: list[str] = []
    rm_write_lines: list[str] = []
    for inport_agent in rm_inports:
        imp_name = f"ai_{inport_agent}"
        txn_type = f"{module}_{inport_agent}_txn"
        rm_imp_decl_macros.append(f"`uvm_analysis_imp_decl(_{inport_agent})")
        # Pre-substitute module/rm_name here (rendered as literals) so the
        # strict renderer doesn't see unresolved {{...}} in the joined block.
        rm_imp_lines.append(
            f"  uvm_analysis_imp_{inport_agent} #({txn_type}, {module}_{rm_name}) {imp_name};"
        )
        rm_imp_new_lines.append(f'    {imp_name} = new("{imp_name}", this);')
        rm_write_lines.append(
            f"  // Called when {inport_agent} monitor sends a transaction.\n"
            f"  virtual function void write_{inport_agent}({txn_type} txn);\n"
            f"    // TODO(rm): Process {inport_agent} input — update internal state.\n"
            f"  endfunction\n"
        )

    # If no explicit inports, create a simple single-write RM (no decl macro needed)
    if not rm_imp_lines:
        first_agent = agents[0]["name"]
        txn_type = f"{module}_{first_agent}_txn"
        rm_imp_lines.append(f"  uvm_analysis_imp #({txn_type}, {module}_{rm_name}) ai;")
        rm_imp_new_lines.append('    ai = new("ai", this);')
        rm_write_lines.append(
            f"  virtual function void write({txn_type} txn);\n"
            f"    // TODO(rm): Process input — update internal state.\n"
            f"  endfunction\n"
        )

    content = render_template_file(
        template_dir,
        "rule_rm.sv",
        {
            "MODULE": module,
            "TOP": top,
            "RM_NAME": rm_name,
            "OBS_AGENT": obs_agent,
            "RM_IMP_DECL_MACROS": "\n".join(rm_imp_decl_macros),
            "RM_ANALYSIS_IMPS": "\n".join(rm_imp_lines),
            "RM_ANALYSIS_IMP_NEWS": "\n".join(rm_imp_new_lines),
            "RM_WRITE_FUNCTIONS": "\n".join(rm_write_lines),
        },
    )
    dest = out_dir / "tb" / "uvm" / "refmodel" / f"{module}_{rm_name}.sv"
    pending.append((dest, content))

    # --- Scoreboard ---
    content = render_template_file(
        template_dir,
        "scoreboard.sv",
        {
            "MODULE": module,
            "TOP": top,
            "SB_NAME": sb_name,
            "RM_NAME": rm_name,
            "OBS_AGENT": obs_agent,
        },
    )
    dest = out_dir / "tb" / "uvm" / "checker" / f"{module}_{sb_name}.sv"
    pending.append((dest, content))

    # --- Env ---
    agent_decl_lines: list[str] = []
    agent_create_lines: list[str] = []
    agent_connect_lines: list[str] = []
    for agent in agents:
        aname = agent["name"]
        mode = agent.get("mode", "active")
        agent_decl_lines.append(f"  {module}_{aname}_agent m_{aname}_agent;")
        if mode == "active":
            agent_create_lines.append(
                f'    m_{aname}_agent = {module}_{aname}_agent::type_id::create("m_{aname}_agent", this);\n'
                f"    m_{aname}_agent.is_active = UVM_ACTIVE;"
            )
        else:
            agent_create_lines.append(
                f'    m_{aname}_agent = {module}_{aname}_agent::type_id::create("m_{aname}_agent", this);\n'
                f"    m_{aname}_agent.is_active = UVM_PASSIVE;"
            )
        # Connect observer agent to scoreboard
        if aname == obs_agent:
            agent_connect_lines.append(
                f"    m_{aname}_agent.ap.connect(m_scoreboard.analysis_export);"
            )
        # Inport agents feed the RM, which lives in the scoreboard. The observer is the
        # exception: its stream already arrives at the scoreboard, and connecting it here as
        # well would fan one port out to both the ingest and the compare with no order
        # between them. The scoreboard forwards that one itself.
        if aname in rm_inports and aname != obs_agent:
            agent_connect_lines.append(
                f"    m_{aname}_agent.ap.connect(m_scoreboard.rm.ai_{aname});"
            )

    content = render_template_file(
        template_dir,
        "env.sv",
        {
            "MODULE": module,
            "TOP": top,
            "RM_NAME": rm_name,
            "SB_NAME": sb_name,
            "AGENT_DECLARATIONS": "\n".join(agent_decl_lines),
            "AGENT_CREATES": "\n".join(agent_create_lines),
            "AGENT_CONNECTS": "\n".join(agent_connect_lines),
        },
    )
    dest = out_dir / "tb" / "uvm" / "env" / f"{module}_env.sv"
    pending.append((dest, content))

    # --- Tests (generated_tests.svh) ---
    test_lines = ["// Auto-generated from tb-scaffold.json."]
    for test in tests:
        tname = test["name"]
        test_id = test["test_id"]
        # Build sequence start calls
        seq_calls: list[str] = []
        test_seqs = test.get("seqs", [])
        for sname in test_seqs:
            # Find the sequence's agent
            seq_agent = "default"
            for s in sequences:
                if s["name"] == sname:
                    seq_agent = s.get("agent", agents[0]["name"])
                    break
            seq_calls.append(
                f"    begin\n"
                f'      {module}_{sname}_seq seq = {module}_{sname}_seq::type_id::create("{sname}");\n'
                f"      seq.start(m_env.m_{seq_agent}_agent.m_sequencer);\n"
                f"    end"
            )
        seq_start_text = (
            "\n".join(seq_calls) if seq_calls else "    // TODO: Start sequences here."
        )

        content = render_template_file(
            template_dir,
            "test.sv",
            {
                "MODULE": module,
                "TOP": top,
                "TEST_NAME": tname,
                "TEST_ID": test_id,
                "SEQ_START_CALLS": seq_start_text,
            },
        )
        test_lines.append(content)

    dest = out_dir / "tb" / "uvm" / "test" / "generated_tests.svh"
    pending.append((dest, "\n".join(test_lines)))

    # --- tb_top ---
    if_inst_lines: list[str] = []
    clock_connections: list[str] = []
    config_db_lines: list[str] = []
    for agent in agents:
        aname = agent["name"]
        groups = agent["interface_groups"]
        clock = boundary.clock_for(groups)
        if clock is None:
            domains = sorted(
                {d for g in groups for d in boundary.group_domain.get(g, set())}
            )
            clock_connections.append(
                f"// TODO(interface): Connect {aname}_if.clk or author the required clocking; "
                f"hardware domains: {', '.join(domains)}."
            )
        else:
            clock_connections.append(f"assign {aname}_if.clk = {clock};")
        if_inst_lines.append(
            f"  {module}_{aname}_if {aname}_if({reset_connections.removeprefix(', ')});"
        )
        config_db_lines.append(
            f'    uvm_config_db#(virtual {module}_{aname}_if)::set(null, "uvm_test_top.*", "{aname}_vif", {aname}_if);'
        )

    port_map = dut_port_map(agents, boundary)
    clock_decls = "\n".join(
        f"  {'wire' if c['direction'] == 'inout' else 'logic'} "
        f"[{c['width'] - 1}:0] {c['name']};"
        for c in boundary.clocks
    )
    clock_gens = "\n".join(
        f"  initial begin\n"
        f"    {c['name']} = '0;\n"
        f"    forever #{float(c['period_ns']) / 2:g} {c['name']} = ~{c['name']};\n"
        f"  end"
        for c in boundary.clocks
        if c["direction"] == "input"
    )
    for c in boundary.clocks:
        if c["direction"] == "inout":
            clock_connections.append(
                f"// TODO(interface): Connect the bidirectional clock {c['name']} for this test."
            )
    pending.append(
        (
            out_dir / "tb/uvm/top" / f"{module}_clocks.svh",
            "// Agent observation clocks; authored and preserved across rounds.\n"
            "// Included inside the TB top; DUT and top-level control signals are in scope.\n"
            + "\n".join(clock_connections)
            + "\n",
        )
    )
    control_ports = ",\n".join(
        f"    .{p['name']}({p['name']})" for p in boundary.clocks + boundary.resets
    )
    dut_connections = (control_ports + port_map).lstrip(",\n")

    content = render_template_file(
        template_dir,
        "tb_top.sv",
        {
            "MODULE": module,
            "TOP": top,
            "IF_INSTANTIATIONS": "\n".join(if_inst_lines),
            "CLOCK_DECLS": clock_decls,
            "CLOCK_GENS": clock_gens,
            "RESET_DECLS": "\n".join(
                f"  {'wire' if r['direction'] == 'inout' else 'logic'} "
                f"[{r['width'] - 1}:0] {r['name']};"
                for r in boundary.resets
            ),
            "DUT_CONNECTIONS": dut_connections,
            "CONFIG_DB_SETS": "\n".join(config_db_lines),
        },
    )
    dest = out_dir / "tb" / "uvm" / "top" / f"{top}_tb_top.sv"
    derived.append((dest, content))

    # The reset schedule, which tb_top includes. Authored, so it is a stub: tb_top is derived
    # from the plan and rewritten every round, and a reset placed to reach a state the design
    # only passes through has to outlive that.
    content = render_template_file(
        template_dir,
        "reset.svh",
        {
            "MODULE": module,
            "TOP": top,
            "RESET_TASKS": "\n".join(
                f"// {r['name']}: active {r['reset_polarity']}, {r['reset_kind']}, "
                f"clock domain {r['clock_domain']}.\n"
                f"// TODO(reset): Drive {r['name']} for the planned initialization and reset tests."
                for r in boundary.resets
                if r["direction"] != "output"
            ),
        },
    )
    dest = out_dir / "tb" / "uvm" / "top" / f"{module}_reset.svh"
    pending.append((dest, content))

    # --- tb_pkg.sv ---
    txn_includes: list[str] = []
    agent_includes: list[str] = []
    for agent in agents:
        aname = agent["name"]
        txn_includes.append(f'  `include "{module}_{aname}_txn.sv"')
        agent_includes.append(f'  `include "{module}_{aname}_driver.sv"')
        agent_includes.append(f'  `include "{module}_{aname}_monitor.sv"')
        agent_includes.append(f'  `include "{module}_{aname}_agent.sv"')

    seq_includes: list[str] = []
    for seq in sequences:
        seq_includes.append(f'  `include "{module}_{seq["name"]}_seq.sv"')

    content = render_template_file(
        template_dir,
        "tb_pkg.sv",
        {
            "MODULE": module,
            "TOP": top,
            "RM_NAME": f"{module}_{rm_name}",
            "SB_NAME": f"{module}_{sb_name}",
            "TXN_INCLUDES": "\n".join(txn_includes),
            "AGENT_INCLUDES": "\n".join(agent_includes),
            "SEQ_INCLUDES": "\n".join(seq_includes),
        },
    )
    dest = out_dir / "tb" / "uvm" / "pkg" / "tb_pkg.sv"
    derived.append((dest, content))

    # --- filelist.f ---
    if_file_lines: list[str] = []
    for agent in agents:
        aname = agent["name"]
        if_file_lines.append(f"tb/uvm/interface/{module}_{aname}_if.sv")

    content = render_template_file(
        template_dir,
        "filelist.f",
        {
            "MODULE": module,
            "TOP": top,
            "INTERFACE_FILES": "\n".join(if_file_lines),
        },
    )
    dest = out_dir / "filelist.f"
    derived.append((dest, content))

    # The list filelist.f pulls in for what this file cannot derive — a DPI implementation is
    # C, so no plan describes it and no renderer emits it. A stub, therefore, not a derivation.
    content = render_template_file(
        template_dir, "tb_sources.f", {"MODULE": module, "TOP": top}
    )
    pending.append((out_dir / "tb" / "uvm" / "tb_sources.f", content))

    # --- testlist.json ---
    testlist_entries: list[dict] = []
    for test in tests:
        tname = test["name"]
        missing = [k for k in ("test_id", "suites") if not test.get(k)]
        if missing:
            sys.exit(
                f"[sim bootstrap] test {tname!r} is missing {missing}. Rerun simulation-plan: "
                f"both are authored there and simplan check-scaffold requires them."
            )
        testlist_entries.append(
            {
                "test_id": test["test_id"],
                "uvm_testname": f"{module}_{tname}_test",
                "suites": test["suites"],
                "seqs": test.get("seqs", []),
            }
        )
    testlist = {
        "module": module,
        "top": top,
        "tests": testlist_entries,
    }
    dest = out_dir / "tests" / "testlist.json"
    derived.append((dest, json.dumps(testlist, indent=2, ensure_ascii=False)))

    # Everything above was rendered and validated in memory; write it now.
    #
    # `pending` is stubs, written only where no file is there yet: once a path exists it
    # belongs to whoever filled it, and on a rework the carried testbench is already on disk,
    # so writing over it would replace a round of authored checks with `// TODO`.
    #
    # `derived` is rewritten unconditionally. Everything in it is computed from the plan and
    # the boundary, so keeping a carried copy is keeping a stale one — which is what used to
    # happen: a rework re-read the sidecars, rendered the right tb_top in memory, found the
    # old one on disk and kept it, and the round ran against a DUT instantiation, a clock set
    # and a reset polarity from whenever the workdir was first created.
    #
    # A failed write rolls back only what this call wrote, so the outcome is the complete new
    # set or none of it rather than a half-tree.
    written: list[Path] = []
    kept: list[Path] = []
    replaced: list[tuple[Path, str | None]] = []
    try:
        for dest, content in pending:
            if dest.exists():
                kept.append(dest)
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(content.rstrip() + "\n", encoding="utf-8")
            written.append(dest)
        for dest, content in derived:
            replaced.append((dest, dest.read_text() if dest.exists() else None))
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(content.rstrip() + "\n", encoding="utf-8")
    except OSError:
        for p in written:
            p.unlink(missing_ok=True)
        for p, before in replaced:
            if before is None:
                p.unlink(missing_ok=True)
            else:
                p.write_text(before)
        raise

    print(
        f"[sim bootstrap] wrote {len(written)} stub(s) in {out_dir}, kept {len(kept)}, "
        f"regenerated {len(derived)} derived file(s)"
    )
    for dest in written:
        print(f"  {dest.relative_to(out_dir)}")
    return 0


def render(plan_dir, out_dir, spec_dir, template_dir=None) -> int:
    """Render the scaffold tree, creating only what is not there yet. Exits on a missing
    sidecar or template dir; returns run_scaffold's int (0). A run_scaffold sys.exit or raise
    propagates to the caller."""
    out_dir = Path(out_dir).resolve()
    for p in (Path(plan_dir) / name for name in ("tb-scaffold.json", "sequences.json")):
        if not p.is_file():
            sys.exit(f"[sim bootstrap] missing {p.name}: {p}")
    if template_dir:
        tmpl_dir = Path(template_dir).resolve()
    else:
        tmpl_dir = (
            Path(__file__).resolve().parent.parent.parent / "templates" / "scaffold"
        )
    if not tmpl_dir.is_dir():
        sys.exit(f"[sim bootstrap] missing template directory: {tmpl_dir}")
    return run_scaffold(plan_dir, tmpl_dir, out_dir, spec_dir)
