#!/usr/bin/env python3
"""sim bootstrap — deploy the simulation templates into a run workdir, then optionally render the UVM scaffold.

Deploy the infra templates without clobbering anything already there, substitute the MY_TOP
and MY_MODULE placeholders, generate rtl_filelist.f (sim.rtl_sources) from the injected
absolute rtl-design root, and when --plan is given render the full UVM scaffold via
sim.scaffold.render.

Exit codes (returned as int; __main__ does sys.exit):
  0  deployed (infra only, or infra + scaffold; rework when a carried Makefile is
     already present in workdir, first run otherwise — the no-clobber deploy never
     overwrites a carried TB)
  1  fail-closed guard (missing infra template dir / unusable top / missing RTL
     filelist / missing --plan sidecar)
  (2 = usage is owned by argparse in __main__.py)
"""

from __future__ import annotations

import json
import re
import shutil
import sys
from pathlib import Path

# This file: skills/simulation/scripts/sim/bootstrap.py
#   parents[2] = skills/simulation   (-> templates/, ships with the skill)
# The kernel hands this verb an ABSOLUTE workdir, so nothing here depends on where it
# was launched from. A relative --workdir is still resolved against the CWD, for a
# human running the verb by hand from inside the module.
SCRIPT_PATH = Path(__file__).resolve()
TEMPLATE_DIR = SCRIPT_PATH.parents[2] / "templates"

IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
UVM_SUBDIRS = (
    "interface",
    "transaction",
    "agent",
    "checker",
    "refmodel",
    "env",
    "seq",
    "test",
    "pkg",
    "top",
)
PLACEHOLDERS = ("MY_TOP", "MY_MODULE")


SCAFFOLD_NAME = "tb-scaffold.json"


def report_error(msg: str) -> None:
    print(f"[sim bootstrap] {msg}", file=sys.stderr)


def deploy_no_clobber(src_root: Path, dest: Path) -> list[Path]:
    """Copy every template file into dest unless dest already has one at that path: a file
    carried from the prior round always wins over the pristine template. Returns the files
    actually written."""
    written: list[Path] = []
    for p in src_root.rglob("*"):
        if p.is_dir() or "__pycache__" in p.parts:
            continue  # bytecode the test suite left beside the shipped scripts
        d = dest / p.relative_to(src_root)
        if d.exists():
            continue  # carried file — never overwrite
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, d)
        written.append(d)
    return written


def run(workdir, scaffold=None) -> int:
    infra = TEMPLATE_DIR / "infra"
    if not infra.is_dir():
        report_error(f"missing infra template directory: {infra}")
        return 1

    # The design tree is the CWD (kernel.py + stage-subagent contract). Resolve a
    # relative workdir against it + drop trailing slash.
    tree_root = Path.cwd()
    dest = Path(workdir)
    if not dest.is_absolute():
        dest = tree_root / dest
    dest = Path(str(dest).rstrip("/"))

    # The rtl-design / scaffold (simulation-plan) stage roots are injected into
    # dispatch.json (dispatch-time), not self-navigated via <module>/....
    inputs = json.loads((dest / "dispatch.json").read_text(encoding="utf-8"))["inputs"]
    rtl_dir = Path(inputs["rtl"])

    plan = json.loads((Path(inputs["scaffold"]) / SCAFFOLD_NAME).read_text())
    top, prefix = plan["top"], plan["module"]
    for field, name in (("top", top), ("module", prefix)):
        if not IDENT_RE.match(name):
            # The schema types both as plain strings without pinning their shape, so this is
            # the one place a name that cannot be a Verilog identifier is reported. Left
            # through, it reaches VCS as a syntax error in generated code nobody wrote by hand.
            report_error(
                f"{SCAFFOLD_NAME} `{field}` is not a Verilog identifier: {name!r}"
            )
            return 1

    # A Makefile present means the prior round's TB was carried in before this verb ran:
    # a rework, not an abort. Absent means a first run.
    dest.mkdir(parents=True, exist_ok=True)
    if (dest / "Makefile").is_file():
        print(f"[sim bootstrap] rework — carried TB detected ({dest / 'Makefile'})")

    # Step 1: deploy infra, never over a file already there.
    deployed = deploy_no_clobber(infra, dest)
    for d in UVM_SUBDIRS:
        (dest / "tb" / "uvm" / d).mkdir(parents=True, exist_ok=True)
    (dest / "tests").mkdir(parents=True, exist_ok=True)

    # Substitute MY_TOP / MY_MODULE in what was just deployed, and only there. A carried file
    # had its placeholders substituted the round it was deployed, so re-reading it can only
    # find the literal text somewhere an author wrote it, and rewriting that would edit
    # carried work. Scanning the whole workdir instead would also mean reading every file the
    # tools left behind: on a real run directory that is 311 files and 56 MB, 170 of them
    # binary, to reach the three template files that actually carry a placeholder.
    repl = {"MY_TOP": top, "MY_MODULE": prefix}
    for path in deployed:
        text = path.read_text()
        if any(ph in text for ph in PLACEHOLDERS):
            for ph, val in repl.items():
                text = text.replace(ph, val)
            path.write_text(text)

    # chmod +x the deployed shell scripts (best-effort; shell did chmod +x scripts/*.sh).
    for sh in (dest / "scripts").glob("*.sh"):
        try:
            sh.chmod(sh.stat().st_mode | 0o111)
        except OSError:
            pass

    # Step 2: generate rtl_filelist.f from the injected rtl-files.json (paths anchored at
    # the ABSOLUTE rtl root). ALWAYS overwrites — a cross-stage-derived filelist must
    # re-anchor every round, so this is never no-clobbered.
    from sim.rtl_sources import load_rtl_files, write_rtl_filelist

    write_rtl_filelist(load_rtl_files(rtl_dir), dest / "rtl_filelist.f", str(rtl_dir))

    # Step 3: render the UVM scaffold when --plan is provided.
    if scaffold:
        plan_dir = Path(scaffold)
        if not plan_dir.is_absolute():
            plan_dir = tree_root / plan_dir
        from sim import scaffold as scaffold_mod

        # spec: the DUT boundary the TB is built against, read at render time rather
        # than from a copy the plan made of it.
        scaffold_mod.render(plan_dir, dest, inputs["spec"])
        print(f"[sim bootstrap] rendered UVM scaffold from {plan_dir}")
    else:
        print("[sim bootstrap] --plan not supplied; deployed infra only.")

    print(f"[sim bootstrap] done — {dest}")
    print(f"  MODULE={prefix}  TOP={top}")
    return 0
