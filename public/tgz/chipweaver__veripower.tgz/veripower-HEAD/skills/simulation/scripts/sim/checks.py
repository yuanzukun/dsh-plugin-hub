#!/usr/bin/env python3
"""The three gate primitives finalize re-runs before it will write a pass.

  materialization_errors  every sequences[]/agents[] SV file present; no TODO residue.
  check_review_flagged     the testpoints the reviewer marked BLOCKING in its own record.
  coverage_gate           structural-coverage.json carries the full DUT instance subtree;
                          every bounded dimension must have a measurement and meet its bound.

check-materialization calls the first as the env child's own early exit, which saves a
regression run on a hollow TB. The other two have no caller but finalize: reading them is
what makes the pass conditional on something other than the main thread's account of them.
Status truth is the caller's exit code, not narration.
"""

from __future__ import annotations

import json
import math
import operator
import re
from pathlib import Path

OPS = {"<": operator.lt, "<=": operator.le, ">": operator.gt, ">=": operator.ge}

# A finding heading in check-review.md. The testpoint is the first token after the
# hashes and the marker is the last, so a locus carrying spaces still parses.
BLOCKING_FINDING_PATTERN = re.compile(r"^##\s+(?P<tp_id>\S+)\s+(?P<rest>.*?)\s*$")

# Policy: ANY "TODO" in a materialized TB == unfinished work -> fail (a completed TB carries zero
# "TODO" anywhere) — the deliberate deliverable rule the env child's contract states as "any TODO
# marker survives in tb/uvm/**". The broad match rests on canonical templates carrying no
# non-marker "TODO" prose (base_seq.sv uses NOTE), which is not left to this comment:
# tests/contracts/test_templates_todo_free.py asserts it over every shipped template, so a
# template edit that broke it fails there rather than failing every run of this gate.
TODO_RE = re.compile(r"TODO")


def coverage_rows(requirements_path: Path) -> list[dict]:
    """The requirements.json rows simulation judges with a bound: the engineer's own
    thresholds, in the engineer's own comparison. No row for a dim means that dim is reported,
    not gated.

    Every targeted `simulation` row is returned, not only the `coverage_*` ones. A dim this
    stage does not measure must be REFUSED BY NAME here — which is what requirements.schema.json
    promises of every judging stage — and coverage_gate below does refuse it. Filtering on the
    prefix instead dropped such a row before the gate that would have failed it, leaving a bound
    the engineer wrote silently ungated and nothing anywhere complaining."""
    rows = json.loads(Path(requirements_path).read_text(encoding="utf-8"))
    return [r for r in rows if r["judge"] == "simulation" and "target" in r]


def materialization_errors(workdir: Path, scaffold: dict) -> list[str]:
    """Required SV files present, and no TODO residue. The renderer guarantees most of the
    files, so what this catches is a stub the agent left unfilled or a file it deleted or
    overwrote. Canonical templates carry no non-marker TODO prose, so a match is always a real
    unfilled marker."""
    module = scaffold.get("module", "")
    errs: list[str] = []
    for seq in scaffold.get("sequences", []):
        f = workdir / "tb/uvm/seq" / f"{module}_{seq.get('name')}_seq.sv"
        if not f.is_file():
            errs.append(
                f"missing sequence file {f.relative_to(workdir)} "
                f"(bootstrap renders it; was it deleted?)"
            )
    for ag in scaffold.get("agents", []):
        name = ag.get("name")
        need = [f"{module}_{name}_monitor.sv", f"{module}_{name}_agent.sv"]
        if ag.get("mode") == "active":
            need.append(f"{module}_{name}_driver.sv")
        for fn in need:
            f = workdir / "tb/uvm/agent" / fn
            if not f.is_file():
                errs.append(f"missing agent file {f.relative_to(workdir)}")
    # An agent the plan gained gets its classes rendered and its interface instantiated in
    # tb_top, and stops there: the env is carried, so it neither builds nor connects the new
    # agent. That compiles clean and drives nothing, which is why it is caught here — measured
    # on tpu_top, and every shipped TB across two designs already satisfies it.
    env = workdir / "tb/uvm/env" / f"{module}_env.sv"
    if not env.is_file():
        errs.append(f"missing env file {env.relative_to(workdir)}")
    else:
        env_text = env.read_text(encoding="utf-8", errors="ignore")
        for ag in scaffold.get("agents", []):
            name = ag.get("name")
            if name and name not in env_text:
                errs.append(
                    f"{env.name} never names {name} (the plan declares it; the renderer wrote "
                    f"its classes and tb_top's interface, and an env that does not build it "
                    f"compiles clean and drives nothing)"
                )
    tb = workdir / "tb" / "uvm"
    if tb.is_dir():
        for sv in sorted(set(tb.rglob("*.sv")) | set(tb.rglob("*.svh"))):
            if TODO_RE.search(sv.read_text(encoding="utf-8", errors="ignore")):
                errs.append(
                    f"TODO residue in {sv.relative_to(workdir)} "
                    f"(fill the scaffold; no TODO may survive in a completed TB)"
                )
    return errs


def coverage_gate(
    cov: dict | None, rows: list[dict], dut: str
) -> tuple[list[str], list[dict]]:
    """Judge the subtree at the exact DUT instance path, including its children.

    Missing or N/A measurements do not satisfy numeric requirements. No module-self
    or TB aggregate value can stand in for the requested instance subtree.
    """
    per = (cov or {}).get("per_instance")
    if not isinstance(per, list) or not per:
        return (
            [
                "coverage not extractable: structural-coverage.json missing or carries no "
                "instance subtree rows (urg did not produce a parseable report; cannot gate -> "
                "fail, never claim met)"
            ],
            [],
        )
    matches = [m for m in per if m.get("name") == dut]
    if len(matches) != 1:
        return (
            [
                f"coverage not attributable: expected one instance subtree named {dut!r} in "
                f"structural-coverage.json (rows: {sorted(m.get('name') for m in per)}) — "
                "the DUT's own coverage is what the row bounds"
            ],
            [],
        )
    agg = matches[0]
    errs: list[str] = []
    judged: list[dict] = []
    for r in rows:
        t = r["target"]
        dim = t["dim"].removeprefix("coverage_")
        if (
            dim not in agg
        ):  # urg never measured this dim -> cannot gate it -> fail (not silent skip)
            judged.append(
                {
                    "id": r["id"],
                    "met": False,
                    "actual": None,
                    "measured": f"{dim} of {dut!r}: simulation measures no such dimension",
                }
            )
            errs.append(
                f"{r['id']}: {dim} is bounded but simulation's coverage report carries no "
                f"such dimension (cannot gate)"
            )
            continue
        val = agg[dim]
        if (
            isinstance(val, bool)
            or not isinstance(val, (int, float))
            or not math.isfinite(val)
            or not 0 <= val <= 100
        ):
            judged.append(
                {
                    "id": r["id"],
                    "met": False,
                    "actual": None,
                    "measured": f"{dim} coverage of {dut!r}: no numeric measurement from urg",
                }
            )
            errs.append(
                f"{r['id']}: {dim} of {dut!r} has no numeric measurement; cannot judge the bound"
            )
            continue
        ok = OPS[t["op"]](val, t["value"])
        judged.append(
            {
                "id": r["id"],
                "met": ok,
                "actual": val,
                "measured": f"{dim} coverage of the DUT {dut!r}, from the instance subtree row of "
                f"structural-coverage.json (complete instance subtree)",
            }
        )
        if not ok:
            errs.append(
                f"{r['id']}: {dim} coverage {val} is not {t['op']} {t['value']}"
            )
    return errs, judged


def check_review_flagged(review_path: Path) -> list[str]:
    """Read unresolved review markers; the stage owner also assesses the underlying evidence."""
    text = Path(review_path).read_text(encoding="utf-8")
    if not text.strip():
        raise ValueError("check-review.md is empty; review did not establish adequacy")
    flagged = [
        m.group("tp_id")
        for m in (BLOCKING_FINDING_PATTERN.match(ln) for ln in text.splitlines())
        if m and m.group("rest").split()[-1:] == ["BLOCKING"]
    ]
    return sorted(set(flagged))
