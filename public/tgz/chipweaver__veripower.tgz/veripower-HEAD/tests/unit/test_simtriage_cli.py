import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MAIN = ROOT / "skills/simulation-triage/scripts/simtriage/__main__.py"


def run(*argv):
    return subprocess.run(["python3", str(MAIN), *argv], capture_output=True, text=True)


def test_cli_help_lists_verb():
    r = run("--help")
    assert r.returncode == 0, r.stderr
    assert "finalize" in r.stdout


def test_cli_unknown_verb_exits_2():
    assert run("bogus").returncode == 2


def test_cli_no_verb_exits_2():
    assert run().returncode == 2
