import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "framework" / "scripts"))
import facts  # noqa: E402


def test_file_fingerprint_deterministic(tmp_path):
    f = tmp_path / "a.v"
    f.write_text("module a; endmodule\n")
    fp1 = facts.fingerprint(f)
    fp2 = facts.fingerprint(f)
    assert fp1 == fp2 and fp1.startswith("sha256:")


def test_file_fingerprint_changes_with_content(tmp_path):
    f = tmp_path / "a.v"
    f.write_text("x")
    a = facts.fingerprint(f)
    f.write_text("y")
    assert facts.fingerprint(f) != a


def test_same_size_and_mtime_replacement_invalidates_recorded_input(tmp_path):
    path = tmp_path / "netlist.v"
    path.write_text("old")
    recorded = facts.fingerprint(path)
    outcome = {
        "type": "outcome",
        "rule": "timing-analysis",
        "outputs": {},
        "proofs": [
            {
                "name": "timing-analysis",
                "verdict": "pass",
                "inputs": {"netlist.v": recorded},
            }
        ],
    }
    assert facts.proof_valid(str(tmp_path), [outcome], "timing-analysis")
    st = path.stat()
    replacement = tmp_path / "replacement.v"
    replacement.write_text("new")
    os.utime(replacement, ns=(st.st_atime_ns, st.st_mtime_ns))
    replacement.replace(path)
    assert not facts.proof_valid(str(tmp_path), [outcome], "timing-analysis")


def test_dir_merkle_order_independent(tmp_path):
    d = tmp_path / "d"
    d.mkdir()
    (d / "b.txt").write_text("2")
    (d / "a.txt").write_text("1")
    fp = facts.fingerprint(d)
    # rewrite in different creation order, same content -> same merkle
    d2 = tmp_path / "d2"
    d2.mkdir()
    (d2 / "a.txt").write_text("1")
    (d2 / "b.txt").write_text("2")
    assert facts.fingerprint(d2) == fp and fp.startswith("merkle:")


def test_symlink_hashed_by_target_not_followed(tmp_path):
    (tmp_path / "real").write_text("payload")
    link = tmp_path / "lnk"
    os.symlink("real", link)
    fp_target_a = facts.fingerprint(link)
    os.remove(link)
    os.symlink("other", link)  # different target string, dangling
    assert facts.fingerprint(link) != fp_target_a  # target string participates


def test_missing_is_unknown_and_never_matches(tmp_path):
    assert facts.fingerprint(tmp_path / "nope") == facts.UNKNOWN
    assert not facts.versions_match(facts.UNKNOWN, facts.UNKNOWN)
    assert not facts.versions_match("sha256:x", facts.UNKNOWN)
    assert facts.versions_match("sha256:x", "sha256:x")


def test_symlink_not_followed_and_no_collision(tmp_path):
    # file-first then link
    root = tmp_path / "r1"
    root.mkdir()
    target = root / "target.txt"
    target.write_text("AAAA")
    lnk = root / "lnk"
    os.symlink("target.txt", lnk)
    fp_file = facts.fingerprint(target)
    fp_link = facts.fingerprint(lnk)
    assert fp_file == facts.fingerprint(target)
    assert fp_link == facts.fingerprint(lnk)
    assert fp_link != fp_file
    # fresh root, link-first then file
    root2 = tmp_path / "r2"
    root2.mkdir()
    target2 = root2 / "target.txt"
    target2.write_text("AAAA")
    lnk2 = root2 / "lnk"
    os.symlink("target.txt", lnk2)
    fp_link2 = facts.fingerprint(lnk2)
    fp_file2 = facts.fingerprint(target2)
    assert fp_link2 == facts.fingerprint(lnk2)
    assert fp_file2 == facts.fingerprint(target2)
    assert fp_link2 != fp_file2


def test_dir_reflects_nested_edit(tmp_path):
    d = tmp_path / "d"
    (d / "sub").mkdir(parents=True)
    f = d / "sub" / "f.txt"
    f.write_text("before")
    fp1 = facts.fingerprint(d)
    # editing the nested file does NOT change d's own mtime
    f.write_text("after-edit")
    fp2 = facts.fingerprint(d)
    assert fp2 != fp1
    assert fp2 == facts.fingerprint(d)


@pytest.mark.skipif(os.geteuid() == 0, reason="permissions ineffective as root")
def test_unreadable_parent_returns_unknown(tmp_path):
    locked = tmp_path / "locked"
    locked.mkdir()
    f = locked / "f.txt"
    f.write_text("secret")
    locked.chmod(0o000)
    try:
        assert facts.fingerprint(f) == facts.UNKNOWN
    finally:
        locked.chmod(0o755)  # restore so tmp cleanup works
