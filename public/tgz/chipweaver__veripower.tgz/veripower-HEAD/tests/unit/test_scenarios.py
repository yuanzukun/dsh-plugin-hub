"""Code-level scenario replays against the REAL kernel.

Template: test_state.py::TestFullLoop (multi-round dispatch/reap loop). Idioms are
reused verbatim from the two landed kernel suites the brief names:
  * test_schedule.py — in-process event construction (store.append_event) with real
    fingerprints and a per-run content marker so a rebuild genuinely drifts bytes;
  * test_kernel_cli.py — real kernel verbs (kernel.cmd_dispatch / cmd_reap with a
    crafted, schema-valid result.json) so triage mints a real diagnosis + a canonical
    result.json, and dispatch writes a real dispatch.json.
No mocks: every proof, fingerprint, scope, and diagnosis is produced by the
landed facts/schedule/kernel code over a real asic/<module>/ tree.

Each scenario replays a multi-step pipeline flow and asserts the BINDING per-step
assertions. Scenario replays against already-landed semantics
are GREEN-first by construction (the kernel is built + task-reviewed); where a step
demands RED evidence that a change actually bit, the test pins a baseline BEFORE the
mutation and asserts the flip (e.g. Step 1 checks the scaffold consumer really goes
invalid; Step 2/2b assert the edited file's fingerprint actually changed).
"""

from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "framework" / "scripts"))
import facts  # noqa: E402
import kernel  # noqa: E402
import rules  # noqa: E402
import schedule  # noqa: E402
import store  # noqa: E402

TS = "2026-07-10T00:00:00.000000Z"


def utc_timestamp() -> str:
    """Fresh second-resolution UTC stamp (mirrors skill finalizers) so a mid-test
    result.json passes the reap temporal-integrity check."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ── test_schedule.py helper idioms (copied verbatim — real event logs) ──────────

OUTPUTS = {
    "specification": [
        "Design/specification/design.md",
        "Design/specification/manifest.json",
        "Design/specification/requirements.json",
        "Design/specification/clocks.json",
        "Design/specification/check-hints.json",
        "Design/specification/top-io.json",
        "Design/specification/constraints/top.sdc",
        "Design/specification/constraints/top.sgdc",
    ],
    "simulation-plan": [
        "Verification/simulation-plan/verification-plan.md",
        "Verification/simulation-plan/tb-scaffold.json",
        "Verification/simulation-plan/sequences.json",
        "Verification/simulation-plan/power-scenarios.json",
    ],
    "rtl-design": [
        "Design/rtl-design/src",
        "Design/rtl-design/rtl-files.json",
        "Design/rtl-design/constraint-annotations.json",
    ],
    "lint-cdc": ["Design/lint-cdc/lint-report.txt", "Design/lint-cdc/cdc-report.txt"],
    "synthesis": [
        "Design/synthesis/out/top_syn.v",
        "Design/synthesis/out/top_syn.sdc",
        "Design/synthesis/out/top_syn.sdf",
        "Design/synthesis/reports/qor.rpt",
    ],
    "timing-analysis": [
        "Design/timing-analysis/timing-report.txt",
    ],
    "simulation": [
        "Verification/simulation/case-results-summary.md",
        "Verification/simulation/env.sh",
        "Verification/simulation/rtl_filelist.f",
        "Verification/simulation/tb/uvm/agent.sv",
        "Verification/simulation/filelist.f",
    ],
    "power-analysis": [
        "Verification/power-analysis/reports_ptpx/S1/power_hier.rpt",
    ],
}


def fp(module, rel):
    return facts.fingerprint(Path(module) / rel)


def mk(module, rel, content):
    if not Path(rel).suffix:  # tree artifact (Design/rtl-design/src): one file inside
        return mk(module, rel + "/rtl.v", content)
    p = Path(module) / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content)


def dispatch(module, rule, run, inputs):
    store.append_event(
        module,
        {
            "type": "dispatch",
            "rule": rule,
            "run": run,
            "workdir": f"{rule}/runs/{run}",
            "inputs": inputs,
            "params": {},
        },
        TS,
    )


def outcome(module, rule, run, verdict, outputs, proofs, **extra):
    ev = {
        "type": "outcome",
        "rule": rule,
        "run": run,
        "verdict": verdict,
        "outputs": outputs,
        "proofs": proofs,
        "tool_versions": {},
    }
    ev.update(extra)
    store.append_event(module, ev, TS)


def recorded_inputs(module, rule, extra=()):
    root = Path(module)
    rec = {}
    for globs in rules.RULES[rule].inputs.values():
        for g in globs:
            if rules.producer_of(g) == rule:
                continue
            for p in sorted(root.glob(g)):
                rec[str(p.relative_to(root))] = facts.fingerprint(p)
    for rel in extra:
        rec[rel] = fp(module, rel)
    return rec


def valid(module, rule, run, *, tag=None, out_content=None):
    """Dispatch+pass `rule`: write its declared outputs (content per `out_content`
    override else the run-tagged default), record inputs/outputs at current-disk
    fingerprints, and emit a passing same-name proof."""
    marker = tag if tag is not None else f"r{run}"
    for rel in OUTPUTS[rule]:
        content = (out_content or {}).get(rel, f"{rule}:{rel}:{marker}")
        mk(module, rel, content)
    inputs = recorded_inputs(module, rule)
    outputs = {rel: fp(module, rel) for rel in OUTPUTS[rule]}
    dispatch(module, rule, run, inputs)
    outcome(
        module,
        rule,
        run,
        "pass",
        outputs,
        [
            {
                "name": rule,
                "verdict": "pass",
                "inputs": inputs,
            }
        ],
    )


def fail(module, rule, run, owner="auto"):
    """Dispatch+fail `rule`, recording current-disk inputs and no outputs.

    Also writes the canonical envelope naming a fix owner, because every stage contract
    requires one on a failure (`--fix-owner` on every failure) and the scheduler now stops
    the round on a failure nobody attributed. `owner="auto"` picks the first legal target;
    pass `owner=None` for the deliberately-unattributed case."""
    if owner == "auto":
        legal = sorted(rules.input_closure(rule), key=rules.FORWARD_PRIORITY.index)
        owner = legal[0] if legal else None
    ss = {"fail_reason": f"synthetic {rule} failure"}
    if owner:
        ss["fix_owner"] = owner
    mk(
        module,
        "/".join(rules.RULES[rule].workdir_root) + "/result.json",
        json.dumps({"status": "fail", "stage_specific": ss}),
    )
    inputs = recorded_inputs(module, rule)
    dispatch(module, rule, run, inputs)
    outcome(
        module,
        rule,
        run,
        "fail",
        {},
        [
            {
                "name": rule,
                "verdict": "fail",
                "inputs": inputs,
            }
        ],
    )


def chain_through_simulation(module):
    """spec/plan/rtl proofs valid on disk — simulation's whole input closure."""
    mk(module, "intent/brainstorm.md", "b1")
    valid(module, "specification", 1)
    valid(module, "simulation-plan", 1)
    valid(module, "rtl-design", 1)


# ── Step 1 ──────────────────────────────────────────────────────────────────────


def test_step1_scaffold_fix_keeps_upstream_proofs_valid(tmp_path, monkeypatch):
    """Round-1: after lint/synth/timing pass, a scaffold-only change re-invalidates
    ONLY the scaffold consumer (simulation) — lint/synth/timing proofs stay valid
    because none of them consume the plan sidecars."""
    monkeypatch.chdir(tmp_path)
    m = "round1"
    mk(m, "intent/brainstorm.md", "b1")
    for rule in (
        "specification",
        "simulation-plan",
        "rtl-design",
        "lint-cdc",
        "synthesis",
        "timing-analysis",
        "simulation",
    ):
        valid(m, rule, 1)

    evs = store.read_events(m)
    # baseline (non-vacuous): every proof valid before the scaffold change.
    for rule in ("lint-cdc", "synthesis", "timing-analysis", "simulation"):
        assert facts.proof_valid(m, evs, rule), f"{rule} should start valid"

    # scaffold-only change: drift simulation-plan's tb-scaffold.json.
    mk(m, "Verification/simulation-plan/tb-scaffold.json", "scaffold-v2")
    evs = store.read_events(m)

    # BINDING: lint / synth / timing proofs stay valid (no scaffold in their inputs).
    assert facts.proof_valid(m, evs, "lint-cdc")
    assert facts.proof_valid(m, evs, "synthesis")
    assert facts.proof_valid(m, evs, "timing-analysis")
    # only the scaffold consumer flips — proves the change actually bit.
    assert not facts.proof_valid(m, evs, "simulation")


def test_plan_sidecars_invalidate_only_their_own_consumer(tmp_path, monkeypatch):
    """The reason the plan's machine half is three files and not one.

    simulation reads tb-scaffold.json + sequences.json; power-analysis reads
    sequences.json + power-scenarios.json. A scenario-only edit must not cost a full
    compile + smoke + regress + coverage that cannot even observe it, and a testpoint-only
    edit must not cost a GLS + PT-PX run. Only sequences.json, which both genuinely read,
    invalidates both.
    """
    monkeypatch.chdir(tmp_path)
    m = "granularity"
    mk(m, "intent/brainstorm.md", "b1")
    for rule in (
        "specification",
        "simulation-plan",
        "rtl-design",
        "synthesis",
        "simulation",
        "power-analysis",
    ):
        valid(m, rule, 1)
    base = "Verification/simulation-plan"

    def _flip(sidecar, content):
        mk(m, f"{base}/{sidecar}", content)
        evs = store.read_events(m)
        return facts.proof_valid(m, evs, "simulation"), facts.proof_valid(
            m, evs, "power-analysis"
        )

    evs = store.read_events(m)
    assert facts.proof_valid(m, evs, "simulation")  # baseline: both start valid
    assert facts.proof_valid(m, evs, "power-analysis")

    assert _flip("power-scenarios.json", "[1]") == (True, False)
    valid(m, "power-analysis", 2)  # re-establish before the next probe
    assert _flip("tb-scaffold.json", "{}") == (False, True)
    valid(m, "simulation", 2)
    assert _flip("sequences.json", "[2]") == (False, False)


# ── Step 2 ──────────────────────────────────────────────────────────────────────


def triage(module, sim_run, root_cause):
    """Real triage dispatch+reap: crafted schema-valid result.json -> a promoted
    canonical result.json + a minted diagnosis event (kernel derive_triage)."""
    d = kernel.cmd_dispatch(module, "simulation-triage", None, {"sim_run": sim_run})
    assert d["ok"], d
    result = {
        "stage": "simulation-triage",
        "module": module,
        "produced_at": utc_timestamp(),
        "status": "pass",
        "artifacts": [],
        "stage_specific": {
            # the attribution lives on the finding, with its anchor and its argument
            "findings": [
                {
                    "anchor": "matvec.v:1",
                    "root_cause": root_cause,
                    "reason": "the check reads the wrong tap",
                }
            ],
        },
    }
    mk(module, f"{d['workdir']}/result.json", json.dumps(result))
    r = kernel.cmd_reap(module, "simulation-triage", d["run"])
    assert r["ok"] and r["verdict"] == "pass", r
    return d


def test_step2_repair_direct_hash_invariance_triage_handoff(tmp_path, monkeypatch):
    """Round-2: smoke fail -> triage(rtl-design, high) -> DISPATCH rtl-design ->
    the fix drifts only matvec.v -> the sim fail proof's recorded input drifts ->
    fail stale -> a repair forwards DIRECT to simulation, not rtl-design again."""
    monkeypatch.chdir(tmp_path)
    m = "round2"
    chain_through_simulation(m)
    valid(m, "lint-cdc", 1)  # a real lint proof, so (c) is non-vacuous
    rtl1 = facts.latest_outcome(store.read_events(m), "rtl-design")["outputs"]

    fail(m, "simulation", 1)  # smoke fail — records matvec.v@r1 as an input
    triage(m, sim_run=1, root_cause="rtl-design")

    # fresh sim fail + reliable triage diagnosis -> DISPATCH the fix owner rtl-design.
    evs = store.read_events(m)
    d1_id = [e for e in evs if e["type"] == "diagnosis"][-1]["id"]
    a = schedule.decide(m)
    assert a["action"] == "DISPATCH" and a["rule"] == "rtl-design"
    assert a["diagnosis_refs"] == [d1_id]
    assert a["caused_by"] == [["simulation", 1]]

    # (d) the triage analysis reaches rtl-design as data, not as a copy: `caused_by` names
    # both the regression and the analysis that read it — the second derived from the
    # diagnosis's own subject, not stored on it — and `scope` carries the diagnosis's
    # anchors. Nothing is transcribed, and the fix owner never navigates to another stage.
    mk(m, "Verification/simulation/runs/1/result.json", json.dumps({"status": "fail"}))
    dr = kernel.cmd_dispatch(
        m, "rtl-design", a["diagnosis_refs"], None, [("simulation", 1)]
    )
    assert dr["ok"], dr
    doc = json.loads((Path(m) / dr["workdir"] / "dispatch.json").read_text())
    assert doc["caused_by"] == [
        "Verification/simulation/runs/1/result.json",
        "Verification/simulation-triage/runs/1/result.json",
    ]
    # scope means one thing now — what drifted under this rule since its last run. The
    # finding's anchor reaches it through the analysis named in caused_by, not through here.
    assert "matvec.v:1" not in doc.get("scope", [])

    # the fix lands (run 2): outcome changes ONLY matvec.v; filelist/README untouched.
    mk(m, "Design/rtl-design/src", "rtl-design:matvec.v:FIX")  # drift on disk
    outputs = {rel: fp(m, rel) for rel in OUTPUTS["rtl-design"]}
    inputs = recorded_inputs(m, "rtl-design")
    outcome(
        m,
        "rtl-design",
        dr["run"],
        "pass",
        outputs,
        [
            {
                "name": "rtl-design",
                "verdict": "pass",
                "inputs": inputs,
            }
        ],
    )
    rtl2 = facts.latest_outcome(store.read_events(m), "rtl-design")["outputs"]

    # (b) minimal-edit / hash-invariance: untouched outputs' fingerprints unchanged;
    # the edited file's fingerprint DID change (proves the edit landed).
    for untouched in (
        "Design/rtl-design/rtl-files.json",
        "Design/rtl-design/constraint-annotations.json",
    ):
        assert rtl2[untouched] == rtl1[untouched]
    assert rtl2["Design/rtl-design/src"] != rtl1["Design/rtl-design/src"]

    # (a) the round re-verifies simulation — the fix owner has had its turn, so what is left
    # is to find out whether the fix worked. (c) lint went stale under the same RTL edit and
    # has no artifact edge to the failure, so the same turn opens it too — a `task`, sorted
    # first, costing the re-verify nothing.
    assert not facts.proof_valid(m, store.read_events(m), "lint-cdc")  # lint IS stale
    opened = []
    while len(opened) < 2:
        a = schedule.decide(m)
        assert a["action"] == "DISPATCH", a
        opened.append(a["rule"])
        assert kernel.cmd_dispatch(m, a["rule"], None)["ok"]
    assert opened == ["lint-cdc", "simulation"]


# ── Step 2b ─────────────────────────────────────────────────────────────────────


def test_step2b_minimal_edit_on_directiveless_forward(tmp_path, monkeypatch):
    """A design.md prose tweak expires the specification proof and forces a forward
    re-dispatch with NO directive; the producer carries its prior outputs forward:
    every untouched output's fingerprint in the new outcome is byte-identical to the
    previous run's (义务无条件 / 同式覆盖 — Step 2's minimal-edit invariant on a
    directive-LESS forward path)."""
    monkeypatch.chdir(tmp_path)
    m = "round2b"
    mk(m, "intent/brainstorm.md", "b1")
    valid(m, "specification", 1)
    spec1 = facts.latest_outcome(store.read_events(m), "specification")["outputs"]
    assert facts.proof_valid(m, store.read_events(m), "specification")

    # a design.md prose tweak (hand-edit spec's own output) expires the proof.
    mk(m, "Design/specification/design.md", "design v2 — one prose sentence added")
    assert not facts.proof_valid(m, store.read_events(m), "specification")

    # forward re-dispatch with NO directive.
    a = schedule.decide(m)
    assert a["action"] == "DISPATCH" and a["rule"] == "specification"
    assert "caused_by" not in a  # a forward dispatch answers no failure

    # the producer carries prior outputs forward: it re-runs (run 2) re-emitting every
    # untouched artifact byte-for-byte (only design.md, the tweaked file, differs).
    inputs = recorded_inputs(m, "specification")
    outputs = {rel: fp(m, rel) for rel in OUTPUTS["specification"]}
    dispatch(m, "specification", 2, inputs)
    outcome(
        m,
        "specification",
        2,
        "pass",
        outputs,
        [
            {
                "name": "specification",
                "verdict": "pass",
                "inputs": inputs,
            }
        ],
    )
    spec2 = facts.latest_outcome(store.read_events(m), "specification")["outputs"]

    # BINDING: every untouched output byte-identical to the previous run.
    touched = "Design/specification/design.md"
    for rel in OUTPUTS["specification"]:
        if rel == touched:
            continue
        assert spec2[rel] == spec1[rel], f"{rel} must carry forward (byte-identical)"
    assert spec2[touched] != spec1[touched]  # non-vacuous: the tweak actually bit


# ── Step 3 ──────────────────────────────────────────────────────────────────────


def test_step3_supersede_is_auditable(tmp_path, monkeypatch):
    """Round-3: a new diagnosis supersedes the old -> the old attribution goes inactive,
    rtl-design is re-dispatched on the new one, the supersede link on the ledger."""
    monkeypatch.chdir(tmp_path)
    m = "round3"
    chain_through_simulation(m)
    fail(m, "simulation", 1)

    # d1: original diagnosis blaming simulation-plan.
    store.append_event(
        m,
        {
            "type": "diagnosis",
            "id": "d1",
            "subject": {"proof": "simulation", "outcome_run": 1},
            "attribution": "simulation-plan",
            "fix_owner": "simulation-plan",
            "source": "triage",
        },
        TS,
    )
    # d2: a new diagnosis supersedes d1, re-attributing to rtl-design.
    store.append_event(
        m,
        {
            "type": "diagnosis",
            "id": "d2",
            "supersedes": "d1",
            "subject": {"proof": "simulation", "outcome_run": 1},
            "attribution": "rtl-design",
            "fix_owner": "rtl-design",
            "source": "triage",
        },
        TS,
    )

    evs = store.read_events(m)
    sim_out = facts.latest_outcome(evs, "simulation")
    # the old attribution goes inactive (superseded); only d2 is active.
    active = schedule.active_diagnoses(evs, "simulation", sim_out)
    assert [d["id"] for d in active] == ["d2"]
    assert not any(d["id"] == "d1" for d in active)

    # rtl-design re-dispatched on the surviving diagnosis.
    a = schedule.decide(m)
    assert a["action"] == "DISPATCH" and a["rule"] == "rtl-design"
    assert a["diagnosis_refs"] == ["d2"]

    # the supersede link is on the ledger.
    d2 = next(e for e in evs if e["type"] == "diagnosis" and e["id"] == "d2")
    assert d2["supersedes"] == "d1"


# ── Step 4 ──────────────────────────────────────────────────────────────────────


def timing_owed(module):
    """Is timing-analysis still owed a fix — i.e. has its owner not been dispatched since?"""
    evs = store.read_events(module)
    fails = schedule.failures(module, evs)
    return any(f["rule"] == "timing-analysis" for f in schedule.owed(evs, fails))


def test_step4_multihop_synthesis_first_then_timing(tmp_path, monkeypatch):
    """Multi-hop: timing fail -> rtl-design fix -> synthesis rebuilds FIRST (timing's
    input _syn.v is a synthesis product), then timing re-verifies LAST. Driven purely by
    fail-freshness + condition 2 (no rework counter); never ESCALATE."""
    monkeypatch.chdir(tmp_path)
    m = "multihop"
    mk(m, "intent/brainstorm.md", "b1")
    valid(m, "specification", 1)
    valid(m, "rtl-design", 1)
    valid(m, "synthesis", 1)
    fail(
        m, "timing-analysis", 1, owner="synthesis"
    )  # a setup violation is synthesis's to fix

    assert timing_owed(m)  # baseline (non-vacuous)

    # rtl-design fix lands -> synthesis proof invalid (its recorded RTL input drifts), but
    # _syn.v not yet regenerated, so timing's OWN inputs have not moved. The complaint stays
    # open: an upstream rebuild two hops away does not retract what timing reported.
    valid(m, "rtl-design", 2)
    assert not facts.proof_valid(m, store.read_events(m), "synthesis")
    assert timing_owed(m)

    # the round rebuilds the producer (synthesis) — not timing, never ESCALATE. lint-cdc goes
    # first: the RTL edit staled it too, and synthesis's advisory edge waits on it.
    a = schedule.decide(m)
    assert a["action"] == "DISPATCH" and a["rule"] == "lint-cdc"
    valid(m, "lint-cdc", 2)
    a = schedule.decide(m)
    assert a["action"] == "DISPATCH" and a["rule"] == "synthesis"

    # synthesis rebuilds -> _syn.v drifts -> timing's OWN recorded input now mismatches, and
    # this envelope names nobody, so there is no longer a specific thing to do about the
    # failure: it closes, and forward re-verification takes over.
    # synthesis has now had its turn, so timing is no longer owed anything and the forward
    # step re-verifies it.
    valid(m, "synthesis", 2)
    assert facts.proof_valid(m, store.read_events(m), "synthesis")
    assert not timing_owed(m)

    # timing re-verifies LAST.
    b = schedule.decide(m)
    assert b["action"] == "DISPATCH" and b["rule"] == "timing-analysis"


# ── Step 5 ──────────────────────────────────────────────────────────────────────

SPEC_MAIN = ROOT / "skills/specification/scripts/spec/__main__.py"


def derive_constraints(workdir):
    return subprocess.run(
        ["python3", str(SPEC_MAIN), "derive-constraints", "--workdir", str(workdir)],
        capture_output=True,
        text=True,
        check=True,
    )


def spec_workdir(tmp_path):
    (tmp_path / "manifest.json").write_text(
        json.dumps(
            {
                "module": "m",
            }
        )
    )
    (tmp_path / "design.md").write_text(
        "# m Design\n\n#### 1.4.1 Top-Level IO\n\nPorts live in `top-io.json`.\n\n"
        "### 1.6 Clocks and Frequencies\n\nClock definitions live in `clocks.json`.\n"
    )
    (tmp_path / "top-io.json").write_text(
        json.dumps(
            [
                {
                    "name": "clk",
                    "direction": "input",
                    "width": 1,
                    "clock_domain": "clk",
                    "interface_group": "clk",
                    "role": "clock",
                },
                {
                    "name": "clk_io",
                    "direction": "input",
                    "width": 1,
                    "clock_domain": "clk_io",
                    "interface_group": "clk",
                    "role": "clock",
                },
                {
                    "name": "din",
                    "direction": "input",
                    "width": 8,
                    "clock_domain": "clk",
                    "interface_group": "cfg",
                    "protocol": "APB3",
                    "role": "data",
                },
            ]
        )
    )
    (tmp_path / "clocks.json").write_text(
        json.dumps(
            [
                {
                    "name": "clk",
                    "io_delay_ns": 3.0,
                    "period_ns": 10.0,
                    "relationship": "primary",
                },
                {
                    "name": "clk_io",
                    "io_delay_ns": 6.0,
                    "period_ns": 20.0,
                    "relationship": "async",
                },
            ]
        )
    )
    return tmp_path


def test_step5_cold_regenerated_seed_byte_identical(tmp_path, monkeypatch):
    """Cold-start equivalence (unit-testable slice): delete the warm SGDC/SDC seed and
    re-derive — derive-constraints is deterministic, so the cold-regenerated seed is
    byte-identical to the warm one. (SpyGlass verdict-equality is an EDA-gated
    design-time obligation exercised via the fixture, NOT asserted here.)"""
    wd = spec_workdir(tmp_path)
    derive_constraints(wd)
    warm_sgdc = (wd / "constraints" / "m.sgdc").read_bytes()
    warm_sdc = (wd / "constraints" / "m.sdc").read_bytes()
    # sanity: the seed is a non-trivial multi-clock SGDC (real CDC content).
    assert b"clock -name clk" in warm_sgdc

    # delete the warm cache seed, then cold-regenerate from the identical input.
    (wd / "constraints" / "m.sgdc").unlink()
    (wd / "constraints" / "m.sdc").unlink()
    derive_constraints(wd)

    assert (wd / "constraints" / "m.sgdc").read_bytes() == warm_sgdc
    assert (wd / "constraints" / "m.sdc").read_bytes() == warm_sdc


def test_step5_lintcdc_dispatchable_and_waiver_never_cached(tmp_path, monkeypatch):
    """lint-cdc stays dispatchable after its warm SGDC seed is deleted (the seed is a
    derived warm-start, not a hard input). waiver.tcl is a promoted output whose
    producer_of==consumer self-reference still holds, but it is now carried
    (Rule.carry), not a declared input — no in∩out self-lock exemption applies to it
    anymore, with no separate cache declaration (the old Rule.cache field had no
    machine consumer and was removed)."""
    lint = rules.RULES["lint-cdc"]
    input_globs = [g for gs in lint.inputs.values() for g in gs]
    assert rules.producer_of("Design/lint-cdc/scripts/waiver.tcl") == "lint-cdc"
    # the warm SGDC seed is NOT among lint-cdc's declared inputs — absence cannot gate.
    assert "Design/lint-cdc/scripts/constraints.sgdc" not in input_globs

    monkeypatch.chdir(tmp_path)
    m = "cold"
    mk(m, "intent/brainstorm.md", "b1")
    valid(m, "specification", 1)  # writes the SGDC seed constraints/top.sgdc
    valid(m, "rtl-design", 1)
    evs = store.read_events(m)
    assert facts.rule_available(m, evs, "lint-cdc")  # dispatchable cold (no cache yet)

    # a prior lint run's warm cache seed exists, then is deleted -> still dispatchable.
    mk(m, "Design/lint-cdc/scripts/constraints.sgdc", "cached-sgdc-v1")
    assert facts.rule_available(m, evs, "lint-cdc")
    (Path(m) / "Design/lint-cdc/scripts/constraints.sgdc").unlink()
    assert facts.rule_available(m, store.read_events(m), "lint-cdc")


# ── The four dispatch shapes (dispatch.json) ─────────────────────────────────────


def dispatch_doc(module, workdir):
    return json.loads((Path(module) / workdir / "dispatch.json").read_text())


def test_forward_redispatch_scope_names_the_drifted_inputs(tmp_path, monkeypatch):
    """Shape 2 — a forward re-dispatch: spec re-ran, drifting rtl-design's recorded inputs,
    so `scope` names exactly those files. That drift is what invalidated the proof, and only
    the kernel can compute it (the fingerprint table lives in the log)."""
    monkeypatch.chdir(tmp_path)
    m = "fwd-scope"
    mk(m, "intent/brainstorm.md", "b1")
    valid(m, "specification", 1)
    valid(m, "rtl-design", 1)  # records design.md/child/manifest at r1 fingerprints
    assert facts.proof_valid(m, store.read_events(m), "rtl-design")

    valid(m, "specification", 2, tag="r2")  # spec re-runs, re-promoting those files
    assert not facts.proof_valid(
        m, store.read_events(m), "rtl-design"
    )  # inputs drifted

    d = kernel.cmd_dispatch(m, "rtl-design", None)
    assert d["ok"], d
    doc = dispatch_doc(m, d["workdir"])
    assert "Design/specification/design.md" in doc["scope"]
    assert "Design/specification/design.md" in doc["scope"]
    assert "caused_by" not in doc and "reasons" not in doc


def test_first_dispatch_carries_no_narrowing_key(tmp_path, monkeypatch):
    """Shape 1 — a first delivery (no prior rtl-design outcome): `inputs` alone. The absent
    narrowing keys are what send the skill to full scope; it then tells that apart from a
    re-verify by whether the workdir already holds its own prior products."""
    monkeypatch.chdir(tmp_path)
    m = "fwd-first"
    mk(m, "intent/brainstorm.md", "b1")
    valid(m, "specification", 1)  # spec present so rtl-design's inputs are available
    d = kernel.cmd_dispatch(m, "rtl-design", None)
    assert d["ok"], d
    assert list(dispatch_doc(m, d["workdir"])) == ["inputs"]


def test_reverify_dispatch_carries_no_narrowing_key(tmp_path, monkeypatch):
    """An explicit recheck with unchanged inputs carries prior products without narrowing."""
    monkeypatch.chdir(tmp_path)
    m = "reverify"
    mk(m, "intent/brainstorm.md", "b1")
    valid(m, "specification", 1)
    assert facts.proof_valid(m, store.read_events(m), "specification")
    assert facts.stale_inputs(m, store.read_events(m), "specification") == []

    d = kernel.cmd_dispatch(m, "specification", None)
    assert d["ok"], d
    assert list(dispatch_doc(m, d["workdir"])) == ["inputs"]
    # carry_self brought the prior round's products in: that is the disk fact the skill
    # branches on, and it is what makes this shape distinguishable from a first delivery.
    assert (Path(m) / d["workdir"] / "design.md").is_file()


def test_repair_dispatch_names_what_named_the_owner_and_the_human_reasoning(
    tmp_path, monkeypatch
):
    """Shape 3 — a repair: `caused_by` names the failing run the diagnosis is about,
    derived from its `subject` rather than stored on it, and `reasons` carries the
    reasoning verbatim. `scope` is absent: nothing drifted under this rule, and where the
    human thinks the fix goes is in their reasoning, not in a second list. The envelope
    path is per-run, so a later run of the same stage cannot move it."""
    monkeypatch.chdir(tmp_path)
    m = "repair-shape"
    mk(m, "intent/brainstorm.md", "b1")
    valid(m, "specification", 1)
    valid(m, "rtl-design", 1)
    fail(m, "synthesis", 1)
    # reap promotes a failing run's envelope, so in production this path always exists.
    mk(m, "Design/synthesis/runs/1/result.json", json.dumps({"status": "fail"}))
    r = kernel.cmd_diagnose(
        m,
        "diag-unit",
        "synthesis",
        1,
        "specification",
        "specification",
        "operator",
        "the area target's unit is wrong, not the RTL",
        None,
    )
    assert r["ok"], r

    d = kernel.cmd_dispatch(m, "specification", ["diag-unit"], None, [("synthesis", 1)])
    assert d["ok"], d
    doc = dispatch_doc(m, d["workdir"])
    assert doc["caused_by"] == ["Design/synthesis/runs/1/result.json"]
    assert "scope" not in doc
    assert doc["reasons"] == ["the area target's unit is wrong, not the RTL"]
    ev = next(
        e
        for e in reversed(store.read_events(m))
        if e["type"] == "dispatch" and e["rule"] == "specification"
    )
    assert ev["caused_by"] == [["synthesis", 1]]


def test_repair_dispatch_rejects_an_unresolvable_channel(tmp_path, monkeypatch):
    """Both rework channels fail closed. A dangling --caused-by would hand the worker a path
    it cannot open; an unknown --diagnosis-refs would drop that diagnosis's own record and
    reasoning silently."""
    monkeypatch.chdir(tmp_path)
    m = "repair-guard"
    mk(m, "intent/brainstorm.md", "b1")
    valid(m, "specification", 1)
    r = kernel.cmd_dispatch(m, "rtl-design", None, None, [("synthesis", 9)])
    assert not r["ok"] and "no result.json" in r["error"]
    r = kernel.cmd_dispatch(m, "rtl-design", ["diag-nope"], None)
    assert not r["ok"] and "unknown diagnosis ref" in r["error"]
    # neither attempt allocated a run
    assert (
        sum(
            1
            for event in store.read_events(m)
            if event["type"] == "dispatch" and event["rule"] == "rtl-design"
        )
        == 0
    )
