# tests/unit/test_lintcdc_bootstrap.py
"""lintcdc bootstrap verb — deploy-into-workdir behavior.

Two layers: in-process unit tests of the inference helpers (byte-for-byte the
synthesis helpers), and subprocess "mirror" tests of full deploy behavior
that run the real shipped skill with cwd set to a tmp design-tree root and build the
upstream asic/<module>/... references under it. The bootstrap anchors the design tree
on the CWD (matching kernel.py and the stage-subagent contract), independent of where
the skill code lives. Neither verb shells out to any Tier-2 script — bootstrap is a
pure deploy.

`make_tree` pre-populates workdir/dispatch.json (rtl/annotations/sgdc_seed keys) the way
kernel.py dispatch injects it at dispatch time, and (when given `carried_local` /
`carried_waiver`) pre-places files directly into workdir/scripts/ the way kernel.py's
carry_self does before this verb runs — bootstrap reads upstream locations from
dispatch.json and carried files from the workdir itself, instead of self-navigating
tree_root/asic/<module>/Design/lint-cdc/scripts/... ."""

import json
import shutil
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
MAIN = REPO_ROOT / "skills" / "lint-cdc" / "scripts" / "lintcdc" / "__main__.py"
sys.path.insert(0, str(REPO_ROOT / "skills" / "lint-cdc" / "scripts"))


# ── inference helpers (in-process, precise — copied from synthesis) ────────────
def rtl_dir(workdir: Path) -> Path:
    """The rtl-design dir for a workdir built by make_tree (.../Design/lint-cdc/runs/N)."""
    return workdir.parents[3] / "Design" / "rtl-design"


def make_tree(
    tmp_path,
    *,
    top="dut",
    rtl_files={"files": ["rtl/dut.v"]},
    carried_local=None,
    carried_waiver=None,
    cold="# seed\ncurrent_design dut\nclock -name clk -period 10.0\n",
    sdc=None,
    annotations={
        "c": {
            "sgdc": {
                "sync_cell": [],
                "reset_synchronizer": [],
                "set_case_analysis": [],
                "quasi_static": [],
            },
            "sdc": {
                "create_generated_clock": [],
                "set_multicycle_path": [],
                "set_false_path": [],
            },
        }
    },
):
    """Build the upstream asic/<module>/... refs under a tmp design-tree root, and
    pre-populate workdir/dispatch.json (rtl/annotations/sgdc_seed keys) the way kernel.py
    dispatch injects it. `carried_local` / `carried_waiver`, when given, pre-place
    scripts/local.sgdc / scripts/waiver.tcl directly INTO the workdir — the way
    kernel.py's carry_self does before this verb runs.
    Returns (module, workdir, main). Deploy tests run `main` (the real shipped skill)
    with cwd=tmp_path, so the bootstrap anchors the design tree on the CWD."""
    m = "M"
    base = tmp_path / "asic" / m
    rtl = base / "Design" / "rtl-design"
    rtl.mkdir(parents=True)
    if rtl_files is not None:
        (rtl / "rtl-files.json").write_text(json.dumps(rtl_files))
    if annotations is not None:
        (rtl / "constraint-annotations.json").write_text(json.dumps(annotations))
    spec_root = base / "Design" / "specification"
    if cold is not None or sdc is not None:
        spec_con = spec_root / "constraints"
        spec_con.mkdir(parents=True)
        if cold is not None:
            (spec_con / f"{top}.sgdc").write_text(cold)
        if sdc is not None:
            (spec_con / f"{top}.sdc").write_text(sdc)
    workdir = base / "Design" / "lint-cdc" / "runs" / "1"
    workdir.mkdir(parents=True)
    if carried_local is not None or carried_waiver is not None:
        ws = workdir / "scripts"
        ws.mkdir(parents=True)
        if carried_local is not None:
            (ws / "local.sgdc").write_text(carried_local)
        if carried_waiver is not None:
            (ws / "waiver.tcl").write_text(carried_waiver)
    spec_root.mkdir(parents=True, exist_ok=True)
    (spec_root / "manifest.json").write_text(json.dumps({"module": "dut"}))
    (workdir / "dispatch.json").write_text(
        json.dumps(
            {
                "inputs": {
                    "rtl": str(rtl),
                    "annotations": str(rtl),
                    "sgdc_seed": str(spec_root),
                    "manifest": str(spec_root),
                }
            }
        )
    )
    return m, workdir, MAIN


def run(workdir, main, extra=None, cwd=None):
    if cwd is None:
        # The bootstrap anchors the design tree on the CWD; the tree root is the
        # prefix of the (absolute) workdir up to the 'asic/' component.
        parts = Path(workdir).parts
        cwd = Path(*parts[: parts.index("asic")])
    cmd = [
        "python3",
        str(main),
        "bootstrap",
        "--workdir",
        str(workdir),
    ]
    if extra:
        cmd += extra
    return subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True)


def test_deploys_and_substitutes_template_branch(tmp_path):
    # No warm/cold seed -> template branch: env.sh MY_TOP -> top, and the copytree'd
    # template constraints.sgdc IS MY_TOP-substituted.
    m, workdir, main = make_tree(tmp_path)
    r = run(workdir, main, extra=["--top", "dut"])
    assert r.returncode == 0, r.stderr
    assert (workdir / "Makefile").is_file()
    env_sh = (workdir / "env.sh").read_text()
    assert "MY_TOP" not in env_sh
    assert 'export TOP="${TOP:-dut}"' in env_sh
    con = (workdir / "scripts" / "constraints.sgdc").read_text()
    assert (
        "MY_TOP" not in con and "current_design dut" in con
    )  # template branch subs it


def test_carried_waiver_survives_template_deploy(tmp_path):
    # Pre-place a carried scripts/waiver.tcl (as kernel.py's carry_self would, BEFORE
    # this verb runs), then deploy: the no-clobber template deploy must NOT clobber it.
    m, workdir, main = make_tree(tmp_path, carried_waiver="HUMAN AUDITED")
    r = run(workdir, main, extra=["--top", "dut"])
    assert r.returncode == 0, r.stderr
    assert (workdir / "scripts" / "waiver.tcl").read_text() == "HUMAN AUDITED"


def test_no_carried_waiver_keeps_substituted_template(tmp_path):
    # No carried waiver -> the no-clobber-deployed template waiver.tcl stays, MY_TOP-substituted.
    m, workdir, main = make_tree(tmp_path)
    r = run(workdir, main, extra=["--top", "dut"])
    assert r.returncode == 0, r.stderr
    tpl = (workdir / "scripts" / "waiver.tcl").read_text()
    assert "MY_TOP" not in tpl


def test_filelist_synced_and_rebased(tmp_path):
    # rtl-design/filelist.txt -> scripts/filelist.txt with the +incdir + re-anchored
    # ABSOLUTE paths. Skip set is {#, blank} ONLY: a comment is dropped, real .v lines
    # are re-anchored.
    m, workdir, main = make_tree(
        tmp_path, rtl_files={"files": ["rtl/dut.v", "rtl/sub/u.sv"]}
    )
    rtl_root = rtl_dir(workdir)
    r = run(workdir, main, extra=["--top", "dut"])
    assert r.returncode == 0, r.stderr
    gen = (workdir / "scripts" / "filelist.txt").read_text()
    # the search path is exactly what the child declared — nothing outside the tree
    assert f"+incdir+{rtl_root}\n" not in gen
    assert f"{rtl_root}/rtl/dut.v" in gen
    assert f"{rtl_root}/rtl/sub/u.sv" in gen
    assert "../../../rtl-design" not in gen  # no relpath climb
    assert "a comment" not in gen  # comment skipped
    assert "bootstrap_lint_cdc" not in gen  # generated header names no retired .sh


def test_filelist_reanchors_to_absolute_rtl(tmp_path):
    # Bootstrap reads the upstream rtl-design location from the injected
    # dispatch.json "rtl" key — not by self-navigating tree_root/asic/<module>/....
    # scripts/filelist.txt must bake the ABSOLUTE rtl root, never a relative climb.
    m, workdir, main = make_tree(tmp_path, rtl_files={"files": ["rtl/dut.v"]})
    rtl_root = rtl_dir(workdir)
    r = run(workdir, main, extra=["--top", "dut"])
    assert r.returncode == 0, r.stderr
    src = (workdir / "scripts" / "filelist.txt").read_text()
    assert str(rtl_root) in src
    assert "../../../rtl-design" not in src


def test_empty_filelist_fail_closed(tmp_path):
    # rtl-files.json listing no files -> exit 1.
    m, workdir, main = make_tree(tmp_path, rtl_files={"files": []})
    # --top given so we reach the filelist generation.
    r = run(workdir, main, extra=["--top", "dut"])
    assert r.returncode == 1
    assert "lists no RTL files" in r.stderr


def test_no_rtl_filelist_fail_closed(tmp_path):
    # rtl-design/rtl-files.json absent -> exit 1, same as one that lists no files.
    # Succeeding here would deploy an empty sourcelist, and SpyGlass reports a clean
    # run on one of those: a pass that analyzed no RTL.
    m, workdir, main = make_tree(tmp_path, rtl_files=None)
    r = run(workdir, main, extra=["--top", "dut"])
    assert r.returncode == 1
    assert "rtl-files.json not found" in r.stderr


def test_cant_read_top_fail_closed(tmp_path):
    # No --top and no manifest -> exit 1; nothing else is consulted.
    m, workdir, main = make_tree(tmp_path)
    spec = tmp_path / "asic" / m / "Design" / "specification"
    (spec / "manifest.json").unlink()
    r = run(workdir, main)  # no --top
    assert r.returncode == 1
    assert "cannot read top" in r.stderr


def test_reprepare_preserves_authored_setup_and_refreshes_upstream_inputs(tmp_path):
    unused, workdir, main = make_tree(tmp_path)
    assert run(workdir, main).returncode == 0
    authored = (
        "env.sh",
        "Makefile",
        "scripts/spyglass_lint.prj",
        "scripts/local.sgdc",
        "scripts/helper.tcl",
    )
    for name in authored:
        (workdir / name).write_text("# MY_TOP is authored literal\n")
    rtl = rtl_dir(workdir)
    (rtl / "rtl-files.json").write_text('{"files":["src/new.sv"]}')
    seed = workdir.parents[2] / "specification/constraints/dut.sgdc"
    seed.write_text("current_design dut\nclock -name clk -period 20\n")
    r2 = run(workdir, main)
    assert r2.returncode == 0, r2.stderr
    for name in authored:
        assert (workdir / name).read_text() == "# MY_TOP is authored literal\n"
    assert "src/new.sv" in (workdir / "scripts/filelist.txt").read_text()
    assert "-period 20" in (workdir / "scripts/constraints.sgdc").read_text()


def test_missing_template_dir_fail_closed(tmp_path):
    # Run a skill COPY whose templates/ has been removed -> fail-closed before any
    # mutation. The design tree itself is valid under the CWD.
    m, workdir, unused = make_tree(tmp_path)
    skill_copy = tmp_path / "skills" / "lint-cdc"
    shutil.copytree(REPO_ROOT / "skills" / "lint-cdc", skill_copy)
    shutil.rmtree(skill_copy / "templates")
    main = skill_copy / "scripts" / "lintcdc" / "__main__.py"
    r = run(workdir, main, extra=["--top", "dut"])
    assert r.returncode == 1
    assert "missing template directory" in r.stderr
    assert not (workdir / "Makefile").exists()  # fail-closed before any mutation


def test_relative_workdir_with_trailing_slash(tmp_path):
    # A relative --workdir resolves against the CWD (the design-tree root), and
    # the trailing slash is dropped before deploy.
    m, workdir, main = make_tree(tmp_path)
    proc = subprocess.run(
        [
            "python3",
            str(main),
            "bootstrap",
            "--workdir",
            "asic/M/Design/lint-cdc/runs/1/",  # relative + trailing slash
            "--top",
            "dut",
        ],
        cwd=str(tmp_path),
        capture_output=True,
        text=True,
    )
    assert proc.returncode == 0, proc.stderr
    assert (workdir / "Makefile").is_file()  # resolved to the absolute location
    assert (workdir / "env.sh").is_file()


# ── the assembled SGDC ────────────────────────────────────────────────────────────────
ANN = {
    "b_child": {
        "sgdc": {
            "sync_cell": ["sync2ff"],
            "reset_synchronizer": ["rst_meta_n"],
            "set_case_analysis": [{"port": "scan_en", "value": "0"}],
            "quasi_static": ["cfg_mode"],
        },
        "sdc": {
            "create_generated_clock": [],
            "set_multicycle_path": [],
            "set_false_path": [],
        },
    },
    "a_child": {
        "sgdc": {
            "sync_cell": [],
            "reset_synchronizer": [],
            "set_case_analysis": [],
            "quasi_static": [],
        },
        "sdc": {
            "create_generated_clock": [],
            "set_multicycle_path": [],
            "set_false_path": [],
        },
    },
}


def test_seed_and_annotations_are_separate_from_carried_local(tmp_path):
    m, workdir, main = make_tree(
        tmp_path,
        cold="# SEED\ncurrent_design dut\nreset -name rst -value 0\n",
        carried_local="# LOCAL\nabstract_port -ports rst -clock clk -reset rst\n",
        annotations=ANN,
    )
    r = run(workdir, main, extra=["--top", "dut"])
    assert r.returncode == 0, r.stderr
    out = (workdir / "scripts" / "constraints.sgdc").read_text()
    assert out.index("# SEED") < out.index("sync_cell")
    assert "reset -name rst -value 0" in out
    assert "# LOCAL" not in out
    assert (workdir / "scripts/local.sgdc").read_text() == (
        "# LOCAL\nabstract_port -ports rst -clock clk -reset rst\n"
    )


def test_annotations_are_generated_from_the_sidecar_not_transcribed(tmp_path):
    """All four categories, every child, in the sidecar's own spelling. A transcriber who
    silently corrected a wrong name would hide a defect that belongs to its author."""
    m, workdir, main = make_tree(tmp_path, annotations=ANN)
    r = run(workdir, main, extra=["--top", "dut"])
    assert r.returncode == 0, r.stderr
    out = (workdir / "scripts" / "constraints.sgdc").read_text()
    for line in (
        "sync_cell -name sync2ff",
        "reset_synchronizer -name rst_meta_n",
        "quasi_static -name cfg_mode",
        "set_case_analysis -name scan_en -value 0",
    ):
        assert line in out, line


def test_a_corrected_seed_reaches_the_tool_without_the_stage_acting(tmp_path):
    """The defect this replaces: the seed was read once, on round 1, so a specification-side
    correction landed in a file the stage never opened again."""
    m, workdir, main = make_tree(
        tmp_path,
        cold="# seed v2\ncurrent_design dut\nreset -name rst -value 0\n",
        carried_local="# carried local, untouched\n",
    )
    r = run(workdir, main, extra=["--top", "dut"])
    assert r.returncode == 0, r.stderr
    out = (workdir / "scripts" / "constraints.sgdc").read_text()
    assert "reset -name rst -value 0" in out
    assert (
        workdir / "scripts/local.sgdc"
    ).read_text() == "# carried local, untouched\n"


def test_project_reads_local_edits_on_each_invocation(tmp_path):
    """Evaluate the deployed project with instrumented SGDC input commands.

    Real SpyGlass runs separately verify its SGDC semantics.
    """
    unused, workdir, main = make_tree(
        tmp_path, cold="current_design dut\n", annotations={}
    )
    r = run(workdir, main, extra=["--top", "dut"])
    assert r.returncode == 0, r.stderr
    local = workdir / "scripts/local.sgdc"
    stub = local.read_text()
    (workdir / "probe.tcl").write_text(
        """set observed none
proc read_file {args} {
    if {[lindex $args 1] eq "sgdc"} {uplevel #0 [list source [lindex $args 2]]}
}
proc set_option args {}
proc current_design {name} {set ::design $name}
proc set_case_analysis {args} {set ::observed [lindex $args end]}
source scripts/spyglass_lint.prj
puts "observed=$observed design=$design"
"""
    )
    for value in (0, 1, None):
        local.write_text(
            stub
            + (
                f"\nset_case_analysis -name mode -value {value}\n"
                if value is not None
                else ""
            )
        )
        seen = subprocess.run(
            ["tclsh", "probe.tcl"], cwd=workdir, capture_output=True, text=True
        )
        assert seen.returncode == 0, seen.stderr
        expected = "none" if value is None else value
        assert f"observed={expected} design=dut" in seen.stdout


def test_missing_seed_fail_closed(tmp_path):
    """SpyGlass reading a design with no clock declared reports a clean run, so there is no
    tolerable default here."""
    m, workdir, main = make_tree(tmp_path, cold=None)
    r = run(workdir, main, extra=["--top", "dut"])
    assert r.returncode == 1
    assert "SGDC source of truth not found" in r.stderr


def test_missing_annotations_fail_closed(tmp_path):
    m, workdir, main = make_tree(tmp_path, annotations=None)
    r = run(workdir, main, extra=["--top", "dut"])
    assert r.returncode == 1
    assert "constraint-annotations.json" in r.stderr
