import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "framework" / "scripts"))
import rules  # noqa: E402
import store  # noqa: E402


def read_dispatch(wd):
    return json.loads((wd / "dispatch.json").read_text())


def test_inject_upstream_keys_are_producer_stage_roots(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    wd = tmp_path / "m" / "Design" / "synthesis" / "runs" / "1"
    wd.mkdir(parents=True)
    store.write_dispatch(Path("m"), "synthesis", wd)
    table = read_dispatch(wd)["inputs"]
    base = str((tmp_path / "m").resolve())
    assert table["rtl"] == base + "/Design/rtl-design"
    assert table["sdc"] == base + "/Design/specification"
    assert table["requirements"] == base + "/Design/specification"


def test_every_rule_reaches_the_intent_tree(tmp_path, monkeypatch):
    # The intent document and whatever the engineer delivered with it are read by whoever a
    # requirement row points at; every rule binds the container by the same key so none of
    # them has to navigate to it undeclared.
    monkeypatch.chdir(tmp_path)
    intent = str((tmp_path / "m" / "intent").resolve())
    for rule, r in rules.RULES.items():
        wd = tmp_path / "m" / Path(*r.workdir_root) / "runs" / "1"
        wd.mkdir(parents=True, exist_ok=True)
        store.write_dispatch(Path("m"), rule, wd)
        assert read_dispatch(wd)["inputs"]["intent"] == intent, rule


def test_inject_pipeline_input_resolves_to_the_container_not_the_module_root(
    tmp_path, monkeypatch
):
    # What the stage is handed is exactly what its proof records: the container, not the
    # module root around it (which holds Design/, Verification/, the log, and anything an
    # agent wrote there — none of it versioned, none of it intent).
    monkeypatch.chdir(tmp_path)
    wd = tmp_path / "m" / "Design" / "specification" / "runs" / "1"
    wd.mkdir(parents=True)
    store.write_dispatch(Path("m"), "specification", wd)
    table = read_dispatch(wd)["inputs"]
    assert table["intent"] == str((tmp_path / "m" / "intent").resolve())
    assert table["intent"] != str((tmp_path / "m").resolve())


def test_inject_sim_run_key_and_guard(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    wd = tmp_path / "m" / "Verification" / "simulation-triage" / "runs" / "1"
    wd.mkdir(parents=True)
    store.write_dispatch(Path("m"), "simulation-triage", wd, params={"sim_run": "3"})
    sim_root = str((tmp_path / "m" / "Verification" / "simulation").resolve())
    assert read_dispatch(wd)["inputs"]["sim_run"] == sim_root + "/runs/3"


def test_narrowing_keys_absent_when_empty(tmp_path, monkeypatch):
    """`inputs` is always there; a narrowing key is written only when it carries something.
    Their ABSENCE is what a worker reads to tell a narrowed round from a full one, so an
    empty list must not serialize as a present-but-empty key."""
    monkeypatch.chdir(tmp_path)
    wd = tmp_path / "m" / "Design" / "synthesis" / "runs" / "1"
    wd.mkdir(parents=True)
    store.write_dispatch(Path("m"), "synthesis", wd, None, [], [], [])
    assert list(read_dispatch(wd)) == ["inputs"]


def test_narrowing_keys_written_when_present(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    wd = tmp_path / "m" / "Design" / "rtl-design" / "runs" / "2"
    wd.mkdir(parents=True)
    store.write_dispatch(
        Path("m"),
        "rtl-design",
        wd,
        None,
        ["Design/specification/child_a.md", "mac.v:42"],
        ["Design/synthesis/runs/1/result.json"],
        ["the area target's unit was wrong, not the RTL"],
    )
    doc = read_dispatch(wd)
    assert doc["scope"] == ["Design/specification/child_a.md", "mac.v:42"]
    assert doc["caused_by"] == ["Design/synthesis/runs/1/result.json"]
    assert doc["reasons"] == ["the area target's unit was wrong, not the RTL"]


@pytest.mark.parametrize("bad", ["0", "-1", "abc", "1/../2", "../9"])
def test_resolve_sim_run_rejects(tmp_path, bad):
    with pytest.raises(ValueError):
        store.resolve_sim_run(Path(tmp_path) / "asic" / "m", bad)
