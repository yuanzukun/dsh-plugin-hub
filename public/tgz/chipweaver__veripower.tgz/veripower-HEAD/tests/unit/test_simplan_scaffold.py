"""Tests for the simplan check-scaffold verb — gate: structural (jsonschema) + semantic cross-ref + coverage."""

import copy
import json
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
MAIN = ROOT / "skills/simulation-plan/scripts/simplan/__main__.py"

# Complete plan fixture: boundary signals are read from specification, not copied here.
GOOD = {
    "module": "m",
    "top": "m_top",
    "agents": [
        {
            "name": "drv",
            "mode": "active",
            "interface_groups": ["cfg"],
        },
        {
            "name": "obs",
            "mode": "passive",
            "interface_groups": ["stat"],
        },
    ],
    "sequences": [{"name": "smoke", "agent": "drv", "desc": "smoke"}],
    "tests": [
        {
            "name": "t_smoke",
            "test_id": "T1",
            "suites": ["smoke", "regress"],
            "seqs": ["smoke"],
        }
    ],
    "rm": {"name": "m_rm", "inports": ["drv"]},
    "scoreboard": {"name": "m_sb", "observer": "obs"},
    "testpoints": [
        {
            "id": "TP-1",
            "intent": "drive TP-1 and observe it",
            "seqs": ["smoke"],
            "covers": ["CHK-0"],
        }
    ],
    "power_scenarios": [
        {
            "id": "S1",
        }
    ],
}


TOP_IO = [
    {
        "name": "clk",
        "direction": "input",
        "width": 1,
        "clock_domain": "clk",
        "interface_group": "cfg",
        "role": "clock",
    },
    {
        "name": "rst_n",
        "direction": "input",
        "width": 1,
        "clock_domain": "clk",
        "interface_group": "cfg",
        "role": "reset",
        "reset_polarity": 0,
        "reset_kind": "async",
    },
    {
        "name": "wdata",
        "direction": "input",
        "width": 32,
        "clock_domain": "clk",
        "interface_group": "cfg",
        "role": "data",
    },
    {
        "name": "rdata",
        "direction": "output",
        "width": 32,
        "clock_domain": "clk",
        "interface_group": "stat",
        "role": "data",
    },
]


ROWS = [
    {
        "id": "R-0",
        "verbatim": "the register reads back what was written",
        "judge": "simulation",
    }
]


def spec(tmp_path, hints=None, top_io=None, rows=None):
    """tmp_path doubles as the spec workdir: manifest + check-hints.json + top-io.json + ledger."""
    (tmp_path / "top-io.json").write_text(
        json.dumps(TOP_IO if top_io is None else top_io)
    )
    (tmp_path / "requirements.json").write_text(
        json.dumps(ROWS if rows is None else rows)
    )
    (tmp_path / "manifest.json").write_text(json.dumps({"module": "m"}))
    (tmp_path / "check-hints.json").write_text(
        json.dumps([{"check_id": "CHK-0"}] if hints is None else hints)
    )
    return tmp_path


def split(tmp_path, scaffold):
    """Project one in-memory plan dict onto the three on-disk sidecars the gate reads.
    The tests keep authoring one dict because that is the shape the cross-array checks are
    about; the split is a property of the files, not of the checks."""
    doc = dict(scaffold)
    for name, key in (
        ("sequences.json", "sequences"),
        ("power-scenarios.json", "power_scenarios"),
    ):
        (tmp_path / name).write_text(json.dumps(doc.pop(key, [])))
    (tmp_path / "tb-scaffold.json").write_text(json.dumps(doc))


def run(tmp_path, scaffold, check=True, hints=None, top_io=None, rows=None):
    split(tmp_path, scaffold)
    spec(tmp_path, hints, top_io, rows)
    return subprocess.run(
        [
            "python3",
            str(MAIN),
            "check-scaffold",
            "--plan",
            str(tmp_path),
            "--spec",
            str(tmp_path),
        ],
        capture_output=True,
        text=True,
        check=check,
    )


def test_good_scaffold_passes(tmp_path):
    proc = run(tmp_path, GOOD)
    assert proc.returncode == 0 and "OK" in proc.stdout


def test_malformed_scaffold_json_fails_loud(tmp_path):
    # A JSON syntax error in a sidecar must fail loud with a fix-oriented message,
    # not a raw traceback.
    split(tmp_path, GOOD)
    (tmp_path / "tb-scaffold.json").write_text("{ oops ]")
    spec(tmp_path, [])
    proc = subprocess.run(
        [
            "python3",
            str(MAIN),
            "check-scaffold",
            "--plan",
            str(tmp_path),
            "--spec",
            str(tmp_path),
        ],
        capture_output=True,
        text=True,
    )
    assert proc.returncode != 0
    assert "not valid JSON" in proc.stderr and "Traceback" not in proc.stderr


def test_injected_interface_transaction_tolerated(tmp_path):
    # The current authored plan must satisfy its closed per-agent schema.
    assert run(tmp_path, GOOD).returncode == 0


# ---- structural ----
def test_observer_list_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    s["scoreboard"]["observer"] = ["a", "b"]
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "observer" in proc.stderr


def test_inports_string_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    s["rm"]["inports"] = "drv"
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "inports" in proc.stderr


def test_seqs_string_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    s["tests"][0]["seqs"] = "smoke"
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "seqs" in proc.stderr


def test_mode_non_enum_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    s["agents"][0]["mode"] = "master"
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "mode" in proc.stderr


def test_mode_missing_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    del s["agents"][0]["mode"]
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "mode" in proc.stderr


def test_missing_interface_groups_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    del s["agents"][0]["interface_groups"]
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "interface_groups" in proc.stderr


def test_agent_extra_key_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    s["agents"][0]["drive_signals"] = ["wdata"]
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0  # additionalProperties:false on agents[]


# ---- boundary: the agents must partition top-io.json's data ports ----
def test_unclaimed_data_port_group_fails(tmp_path):
    """simulation binds the DUT by walking the ports, so a group no agent claims has nothing
    to bind to. The complete plan check includes this assignment."""
    s = copy.deepcopy(GOOD)
    s["agents"] = [a for a in s["agents"] if a["name"] != "obs"]
    s["scoreboard"]["observer"] = "drv"
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0
    assert "stat" in proc.stderr and "no agent claims" in proc.stderr


def test_group_claimed_twice_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    s["agents"][1]["interface_groups"] = ["cfg", "stat"]
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "claimed by both" in proc.stderr


def test_clock_and_reset_groups_need_no_agent(tmp_path):
    """clk/rst carry an interface_group like every other row, but the bench drives them, so
    a group holding only clock/reset is not one an agent has to claim."""
    top_io = [dict(p) for p in TOP_IO]
    for p_ in top_io:
        if p_["role"] in ("clock", "reset"):
            p_["interface_group"] = "clkrst"
    assert run(tmp_path, GOOD, top_io=top_io).returncode == 0


# ---- semantic ----
def test_observer_unknown_agent_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    s["scoreboard"]["observer"] = "nope"
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "observer" in proc.stderr


def test_observer_omitted_single_agent_passes(tmp_path):
    s = copy.deepcopy(GOOD)
    s["agents"] = [s["agents"][0]]  # single agent: drv
    s["sequences"] = [{"name": "smoke", "agent": "drv"}]
    s["rm"]["inports"] = ["drv"]
    del s["scoreboard"]["observer"]
    s["agents"][0]["interface_groups"] = ["cfg", "stat"]  # one agent, so it owns both
    assert run(tmp_path, s).returncode == 0


def test_observer_omitted_multi_agent_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    del s["scoreboard"]["observer"]
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "observer" in proc.stderr  # option-c


def test_inports_unknown_agent_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    s["rm"]["inports"] = ["ghost"]
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "inports" in proc.stderr


def test_seqs_unknown_sequence_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    s["tests"][0]["seqs"] = ["ghost"]
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "seqs" in proc.stderr


def test_sequence_agent_unknown_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    s["sequences"][0]["agent"] = "ghost"
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "agent" in proc.stderr


def test_sequence_without_agent_fails(tmp_path):
    # Functional sequences need the agent they drive.
    s = copy.deepcopy(GOOD)
    del s["sequences"][0]["agent"]
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "agent" in proc.stderr


def test_sequence_ref_unknown_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    s["power_scenarios"][0]["sequence_ref"] = "ghost"
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "sequence_ref" in proc.stderr


def test_sequence_ref_non_string_fails(tmp_path):
    # A non-string sequence_ref must fail structurally (clean message), not crash with a
    # TypeError in the semantic membership check (power_scenarios items are addP:true).
    s = copy.deepcopy(GOOD)
    s["power_scenarios"][0]["sequence_ref"] = ["smoke"]
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "sequence_ref" in proc.stderr


def test_duplicate_agent_name_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    s["agents"][1]["name"] = "drv"  # both agents now named "drv"
    s["scoreboard"]["observer"] = "drv"  # keep refs resolving so only the dup fires
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "duplicated" in proc.stderr


def test_skipped_checks_shape_validated(tmp_path):
    """skipped_checks[] entries require check_id + reason; a malformed entry fails structurally."""
    s = copy.deepcopy(GOOD)
    s["skipped_checks"] = [{"check_id": "CHK-9"}]  # missing 'reason'
    proc = run(tmp_path, s, check=False)
    assert proc.returncode != 0 and "reason" in proc.stderr


# ---- power scenarios the requirements name ----
def test_power_bound_naming_an_undefined_scenario_fails(tmp_path):
    rows = [
        *ROWS,
        {
            "id": "R-9",
            "verbatim": "idle power below 2 mW",
            "judge": "power-analysis",
            "target": {"dim": "power_mw", "op": "<", "value": 2, "scenario": "idle"},
        },
    ]
    proc = run(tmp_path, GOOD, check=False, rows=rows)
    assert proc.returncode != 0 and "R-9" in proc.stderr and "'idle'" in proc.stderr


def test_power_bound_naming_a_defined_scenario_passes(tmp_path):
    rows = [
        *ROWS,
        {
            "id": "R-9",
            "verbatim": "S1 power below 2 mW",
            "judge": "power-analysis",
            "target": {"dim": "power_mw", "op": "<", "value": 2, "scenario": "S1"},
        },
    ]
    assert run(tmp_path, GOOD, rows=rows).returncode == 0


# ---- coverage matrix ----
def test_coverage_uncovered_check_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    s["testpoints"] = [
        {
            "id": "TP-0",
            "intent": "drive TP-0 and observe it",
            "seqs": ["smoke"],
            "covers": ["CHK-00"],
        }
    ]
    proc = run(
        tmp_path,
        s,
        check=False,
        hints=[{"check_id": "CHK-00"}, {"check_id": "CHK-01"}],
    )
    assert (
        proc.returncode != 0 and "uncovered" in proc.stderr and "CHK-01" in proc.stderr
    )


def test_coverage_skip_passes(tmp_path):
    s = copy.deepcopy(GOOD)
    s["testpoints"] = [
        {
            "id": "TP-0",
            "intent": "drive TP-0 and observe it",
            "seqs": ["smoke"],
            "covers": ["CHK-00"],
        }
    ]
    s["skipped_checks"] = [{"check_id": "CHK-01", "reason": "lint-only gate"}]
    proc = run(
        tmp_path,
        s,
        hints=[{"check_id": "CHK-00"}, {"check_id": "CHK-01"}],
    )
    assert proc.returncode == 0


def test_coverage_dangling_covers_fails(tmp_path):
    s = copy.deepcopy(GOOD)
    s["testpoints"] = [
        {
            "id": "TP-0",
            "intent": "drive TP-0 and observe it",
            "seqs": ["smoke"],
            "covers": ["CHK-00", "CHK-99"],
        }
    ]
    proc = run(tmp_path, s, check=False, hints=[{"check_id": "CHK-00"}])
    assert (
        proc.returncode != 0
        and "unknown check_id" in proc.stderr
        and "CHK-99" in proc.stderr
    )


def test_coverage_fully_covered_passes(tmp_path):
    s = copy.deepcopy(GOOD)
    s["testpoints"] = [
        {
            "id": "TP-0",
            "intent": "drive TP-0 and observe it",
            "seqs": ["smoke"],
            "covers": ["CHK-00", "CHK-01"],
        }
    ]
    proc = run(
        tmp_path,
        s,
        hints=[{"check_id": "CHK-00"}, {"check_id": "CHK-01"}],
    )
    assert proc.returncode == 0


# ── in-process: identity is the agent name itself + schema path ───────────────
import sys  # noqa: E402

sys.path.insert(0, str(ROOT / "skills" / "simulation-plan" / "scripts"))
from simplan import scaffold as sc_mod  # noqa: E402


def test_agent_name_needs_no_unwrapping():
    # The producer gate and the consumer both resolve `observer` / `inports` by looking the
    # value up in agents[] verbatim — no transform to keep byte-identical across two skills.
    errs = sc_mod.semantic_errors(
        {
            "module": "m",
            "agents": [{"name": "m_wb_txn_agent"}],
            "sequences": [],
            "tests": [],
            "rm": {"inports": ["m_wb_txn_agent"]},
            "scoreboard": {"observer": "m_wb_txn_agent"},
            "testpoints": [],
            "power_scenarios": [],
        }
    )
    assert errs == []


def test_every_sidecar_schema_resolves():
    # the package is scripts/simplan/, so REFERENCES needs one extra parent (SC6)
    from simplan import plan

    for unused, schema_name, unused in plan.FILES:
        assert (plan.REFERENCES / schema_name).is_file(), schema_name


@pytest.mark.parametrize(
    "fault, fragment",
    [
        ("unknown", "unknown interface_group"),
        ("clock-only", "no data ports"),
        ("duplicate-group", "claimed by both"),
        ("duplicate-signal", "duplicate signal name"),
        ("missing-groups", "interface_groups"),
        ("missing-boundary", "top-io.json"),
        ("malformed-boundary", "top-io.json"),
    ],
)
def test_boundary_defects_are_rejected_by_check_and_finalize(tmp_path, fault, fragment):
    plan = copy.deepcopy(GOOD)
    ports = copy.deepcopy(TOP_IO)
    if fault == "unknown":
        plan["agents"][0]["interface_groups"].append("not-declared")
    elif fault == "clock-only":
        for port in ports:
            if port["role"] in ("clock", "reset"):
                port["interface_group"] = "bench"
        plan["agents"].append(
            {"name": "clock_ctrl", "mode": "passive", "interface_groups": ["bench"]}
        )
    elif fault == "duplicate-group":
        plan["agents"][0]["interface_groups"].append("cfg")
    elif fault == "duplicate-signal":
        ports.append(dict(ports[2]))
    elif fault == "missing-groups":
        del plan["agents"][0]["interface_groups"]
    split(tmp_path, plan)
    spec(tmp_path, top_io=ports)
    if fault == "missing-boundary":
        (tmp_path / "top-io.json").unlink()
    elif fault == "malformed-boundary":
        (tmp_path / "top-io.json").write_text("{invalid")
    for verb, path_flag in (("check-scaffold", "--plan"), ("finalize", "--workdir")):
        p = subprocess.run(
            [
                "python3",
                str(MAIN),
                verb,
                path_flag,
                str(tmp_path),
                "--spec",
                str(tmp_path),
            ],
            capture_output=True,
            text=True,
        )
        assert p.returncode != 0 and fragment in p.stderr, (verb, p.stdout, p.stderr)
        assert not (tmp_path / "result.json").exists()


def test_plan_check_keeps_authored_inputs_unchanged(tmp_path):
    split(tmp_path, GOOD)
    spec(tmp_path)
    before = {p.name: p.read_bytes() for p in tmp_path.iterdir()}
    p = subprocess.run(
        [
            "python3",
            str(MAIN),
            "check-scaffold",
            "--plan",
            str(tmp_path),
            "--spec",
            str(tmp_path),
        ],
        capture_output=True,
        text=True,
    )
    assert p.returncode == 0, p.stderr
    assert {p.name: p.read_bytes() for p in tmp_path.iterdir()} == before
