# tests/unit/test_sim_result.py
import json
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
MAIN = ROOT / "skills/simulation/scripts/sim/__main__.py"
COVERAGE_ROWS = [
    {
        "id": f"R-{i}",
        "verbatim": f"{d} coverage > 90%",
        "judge": "simulation",
        "target": {"dim": f"coverage_{d}", "op": ">", "value": 90},
    }
    for i, d in enumerate(("line", "cond", "fsm", "toggle"))
]

SCAFFOLD = {
    "module": "m",
    "top": "m_top",
    "agents": [{"name": "drv", "mode": "active"}, {"name": "obs", "mode": "passive"}],
    "sequences": [{"name": "smoke", "agent": "drv"}],
    "tests": [{"name": "t_smoke", "seqs": ["smoke"]}],
}
COV_PASS = {
    "per_instance": [
        dict(
            name="m_top_tb_top.u_dut",
            **{"line": 92.0, "cond": 91.0, "fsm": 95.0, "toggle": 93.0},
        )
    ]
}


def final_workdir(tmp_path):
    wd = tmp_path
    (wd / "tb/uvm/seq").mkdir(parents=True)
    (wd / "tb/uvm/agent").mkdir(parents=True)
    (wd / "tb/uvm/seq/m_smoke_seq.sv").write_text("class m_smoke_seq; endclass\n")
    for f in (
        "m_drv_driver.sv",
        "m_drv_monitor.sv",
        "m_drv_agent.sv",
        "m_obs_monitor.sv",
        "m_obs_agent.sv",
    ):
        (wd / "tb/uvm/agent" / f).write_text("class x; endclass\n")
    (wd / "tb/uvm/env").mkdir(parents=True)
    (wd / "tb/uvm/env/m_env.sv").write_text(
        "class m_env; m_drv_agent drv; m_obs_agent obs; endclass\n"
    )
    doc = dict(SCAFFOLD)
    (wd / "sequences.json").write_text(json.dumps(doc.pop("sequences", [])))
    (wd / "tb-scaffold.json").write_text(json.dumps(doc))
    (wd / "structural-coverage.json").write_text(json.dumps(COV_PASS))
    (wd / "requirements.json").write_text(json.dumps(COVERAGE_ROWS))
    (wd / "case-results.json").write_text(
        json.dumps(
            {"total_tests": 3, "passed_tests": 3, "failed_tests": 0, "not_run_tests": 0}
        )
    )
    review(wd)
    return wd


def review(wd, *findings):
    """The reviewer's own record, as it stands on disk when finalize runs: one heading per
    finding, and a blocking one says so."""
    body = "# check-adequacy review — m\n\n" + "\n\n".join(findings)
    (wd / "check-review.md").write_text(body + "\n")


def finalize(wd, *extra):
    return subprocess.run(
        [
            "python3",
            str(MAIN),
            "finalize",
            "--workdir",
            str(wd),
            *extra,
        ],
        capture_output=True,
        text=True,
    )


def finalize_final(wd, *extra):
    return finalize(
        wd,
        "--phase",
        "final",
        "--plan",
        str(wd),
        "--requirements",
        str(wd / "requirements.json"),
        "--check-review",
        str(wd / "check-review.md"),
        *extra,
    )


def test_final_pass_writes_result(tmp_path):
    wd = final_workdir(tmp_path)
    proc = finalize_final(wd)
    assert proc.returncode == 0, proc.stderr
    env = json.loads((wd / "result.json").read_text())
    assert env["stage"] == "simulation" and env["status"] == "pass"
    assert env["stage_specific"]["total_cases"] == 3
    assert "result.json" not in [a["path"] for a in env["artifacts"]]


def test_check_review_promoted(tmp_path):
    # The review is promoted into artifacts[] — it is the record the round routes on, and the
    # only stage product a later reader opens by name.
    wd = final_workdir(tmp_path)
    proc = finalize_final(wd)
    assert proc.returncode == 0, proc.stderr
    paths = [
        a["path"] for a in json.loads((wd / "result.json").read_text())["artifacts"]
    ]
    assert "check-review.md" in paths


def test_final_pass_missing_case_results_is_blocked(tmp_path):
    # A missing case-results.json on the pass path is a broken pipeline step;
    # finalize must fail loud (exit 2 BLOCKED), not write null counts. Deleting only the
    # the rendering beside it would NOT block: nothing reads it.
    wd = final_workdir(tmp_path)
    (wd / "case-results.json").unlink()
    proc = finalize_final(wd)
    assert proc.returncode == 2, proc.stdout
    assert not (wd / "result.json").exists()


def test_check_review_phase_writes_the_routing_envelope(tmp_path):
    # The fail-out carries the reason; the findings themselves stay in the promoted review
    # beside it, which is what triage opens. Copying them into the envelope would duplicate a
    # structured sibling in the same directory.
    proc = finalize(
        tmp_path,
        "--phase",
        "fail",
        "--fail-reason",
        "TP-01: check cannot detect the fault its intent names",
    )
    assert proc.returncode == 0, proc.stderr
    ss = json.loads((tmp_path / "result.json").read_text())["stage_specific"]
    assert "TP-01" in ss["fail_reason"]
    assert "check_review_findings" not in ss


def test_final_thin_fail_is_compile(tmp_path):
    wd = final_workdir(tmp_path)
    (wd / "tb/uvm/agent/m_drv_driver.sv").write_text("// TODO(driver)\n")  # residue
    proc = finalize_final(wd)
    assert proc.returncode == 0
    env = json.loads((wd / "result.json").read_text())
    ss = env["stage_specific"]
    # a compile fail ran no test and measured no coverage, so neither companion rides
    assert env["status"] == "fail"
    assert "failing_cases" not in ss and "requirements" not in ss


def test_final_coverage_fail(tmp_path):
    wd = final_workdir(tmp_path)
    (wd / "structural-coverage.json").write_text(
        json.dumps(
            {
                "per_instance": [
                    dict(
                        name="m_top_tb_top.u_dut",
                        **{"line": 10.0, "cond": 91.0, "fsm": 95.0, "toggle": 93.0},
                    )
                ]
            }
        )
    )
    proc = finalize_final(wd)
    assert (
        proc.returncode == 0
    )  # a coverage fail still writes result.json (exit 0, not BLOCKED)
    env = json.loads((wd / "result.json").read_text())
    assert env["status"] == "fail"

    judged = {e["id"]: e for e in env["stage_specific"]["requirements"]}
    assert judged["R-0"]["met"] is False  # the line row
    assert judged["R-0"]["actual"] == 10.0
    # The verdict names the scope it scored, so a reader never has to guess it.
    assert "line coverage of the DUT" in judged["R-0"]["measured"]
    assert judged["R-1"]["met"] is True


def test_coverage_uses_rtl_top_even_when_module_named_instance_passes(tmp_path):
    wd = final_workdir(tmp_path)
    coverage = json.loads((wd / "structural-coverage.json").read_text())
    actual = coverage["per_instance"][0]
    coverage["per_instance"].append({**actual, "name": "m_tb_top.u_dut"})
    actual["line"] = 10.0
    (wd / "structural-coverage.json").write_text(json.dumps(coverage))
    proc = finalize_final(wd)
    assert proc.returncode == 0, proc.stderr
    env = json.loads((wd / "result.json").read_text())
    assert env["status"] == "fail"
    assert env["stage_specific"]["requirements"][0]["actual"] == 10.0


def test_final_check_review_trip_is_fail_not_pass(tmp_path):
    # The one gate whose verdict finalize is handed rather than deriving alone. SKILL.md tells
    # the main thread it may not override a trip; until finalize itself refuses, that sentence
    # is the whole enforcement, and the main thread is the party it constrains.
    wd = final_workdir(tmp_path)
    review(
        wd,
        "## TP-01  tb/uvm/checker/m_sb.sv:10  BLOCKING\n"
        "mismatch logged as uvm_info; the counter never moves",
    )
    proc = finalize_final(wd)
    assert proc.returncode == 0, proc.stderr
    ss = json.loads((wd / "result.json").read_text())["stage_specific"]
    assert "TP-01" in ss["fail_reason"]


def test_final_non_blocking_finding_does_not_trip(tmp_path):
    # A reported-but-not-blocking finding is the reviewer's own call; the backstop reads the
    # same call and must not turn the whole review into a second, stricter gate.
    wd = final_workdir(tmp_path)
    review(
        wd,
        "## TP-02  tb/uvm/checker/m_sb.sv:44\n"
        "handshake verified only end-to-end; no internal probe",
    )
    proc = finalize_final(wd)
    assert proc.returncode == 0, proc.stderr
    assert json.loads((wd / "result.json").read_text())["status"] == "pass"


def test_a_suite_that_did_not_finish_is_not_a_pass(tmp_path):
    # The counts finalize reports are over the RESULT lines that exist, so a run cut short
    # reads as a smaller clean one: three of ten tests, all green. Every declared test is in a
    # suite `make regress` selects, so a test with no result is the runner having stopped.
    wd = final_workdir(tmp_path)
    (wd / "case-results.json").write_text(
        json.dumps(
            {
                "total_tests": 3,
                "passed_tests": 3,
                "failed_tests": 0,
                "not_run_tests": 7,
            }
        )
    )
    proc = finalize_final(wd)
    assert proc.returncode == 0, proc.stderr
    env = json.loads((wd / "result.json").read_text())
    assert env["status"] == "fail"
    assert "7 declared tests" in env["stage_specific"]["fail_reason"]


def test_final_compile_fail_carries_no_coverage_companions(tmp_path):
    # Companions follow the resolved phase: a compile fail says nothing about coverage,
    # and the phase table in SKILL.md lists none for it.
    wd = final_workdir(tmp_path)
    (wd / "tb/uvm/agent/m_drv_driver.sv").write_text("// TODO(driver)\n")
    proc = finalize_final(wd)
    ss = json.loads((wd / "result.json").read_text())["stage_specific"]
    assert proc.returncode == 0
    assert "requirements" not in ss and "coverage_extractable" not in ss


def test_early_exit_smoke(tmp_path):
    wd = tmp_path
    proc = finalize(wd, "--phase", "fail", "--fail-reason", "case X failed")
    assert proc.returncode == 0
    env = json.loads((wd / "result.json").read_text())
    assert env["status"] == "fail"
    assert env["stage_specific"]["fail_reason"] == "case X failed"


def test_final_requires_its_three_inputs_exit_2(tmp_path):
    # --check-review is one of them: defaulted to absent, the backstop above would read
    # an empty finding set and clear every review it was never given.
    wd = final_workdir(tmp_path)
    for missing in ("--plan", "--requirements", "--check-review"):
        flags = {
            "--plan": str(wd),
            "--requirements": str(wd / "requirements.json"),
            "--check-review": str(wd / "check-review.md"),
        }
        del flags[missing]
        args = [x for kv in flags.items() for x in kv]
        proc = finalize(wd, "--phase", "final", *args)
        assert proc.returncode == 2, missing
        assert not (wd / "result.json").exists(), missing


def test_finalize_blocked_exit_2(tmp_path):
    # --phase final with a non-existent plan dir -> finalize raises -> exit 2 (BLOCKED)
    wd = final_workdir(tmp_path)
    proc = finalize(
        wd,
        "--phase",
        "final",
        "--plan",
        str(wd / "nope"),
        "--requirements",
        str(wd / "requirements.json"),
        "--check-review",
        str(wd / "check-review.md"),
    )
    assert proc.returncode == 2


# ── the one object array triage reads ──────────────────────────────────────────
def test_failure_delivers_original_case_evidence(tmp_path):
    wd = final_workdir(tmp_path)
    logs = wd / "logs"
    logs.mkdir()
    (logs / "T-1.log").write_text("UVM_ERROR checker: expected 7, observed 8\n")
    (wd / "regression-log.txt").write_text("RESULT T-1 FAIL log=logs/T-1.log\n")
    reason = "T-1 mismatch: logs/T-1.log, expected 7, observed 8"
    proc = finalize(
        wd, "--phase", "fail", "--fail-reason", reason, "--fix-owner", "simulation"
    )
    assert proc.returncode == 0, proc.stderr
    env = json.loads((wd / "result.json").read_text())
    assert env["status"] == "fail"
    assert env["stage_specific"] == {"fail_reason": reason, "fix_owner": "simulation"}
    assert {"logs", "regression-log.txt", "case-results.json"} <= {
        a["path"] for a in env["artifacts"]
    }
    assert (
        logs / "T-1.log"
    ).read_text() == "UVM_ERROR checker: expected 7, observed 8\n"


def test_fail_phase_refuses_an_empty_reason(tmp_path):
    """The documented route-out commands used to omit --fail-reason, which wrote
    `fail_reason: ""` — rejected by the envelope schema at reap, so the round cost a blocked
    outcome instead of a routable fail. Measured 6 times across 5 production runs on 2 designs.
    finalize now refuses to write it."""
    proc = finalize(tmp_path, "--phase", "fail")
    assert proc.returncode == 2
    assert "--fail-reason is required" in proc.stderr
    assert not (tmp_path / "result.json").exists()

    proc = finalize(tmp_path, "--phase", "fail", "--fail-reason", "   ")
    assert proc.returncode == 2
    assert not (tmp_path / "result.json").exists()


def test_failed_case_prevents_final_success(tmp_path):
    wd = final_workdir(tmp_path)
    (wd / "case-results.json").write_text(
        json.dumps(
            {
                "total_tests": 3,
                "passed_tests": 2,
                "failed_tests": 1,
                "not_run_tests": 0,
            }
        )
    )
    proc = finalize_final(wd)
    assert proc.returncode == 0, proc.stderr
    result = json.loads((wd / "result.json").read_text())
    assert (
        result["status"] == "fail"
        and "1 tests failed" in result["stage_specific"]["fail_reason"]
    )


def test_unmarked_violation_can_prevent_final_success(tmp_path):
    wd = final_workdir(tmp_path)
    proc = finalize_final(
        wd,
        "--fail-reason",
        "observed violation despite review label",
        "--fix-owner",
        "simulation",
    )
    assert proc.returncode == 0, proc.stderr
    result = json.loads((wd / "result.json").read_text())
    assert (
        result["status"] == "fail"
        and result["stage_specific"]["fix_owner"] == "simulation"
    )


@pytest.mark.parametrize(
    "counts",
    [
        {"total_tests": 3, "passed_tests": 3, "failed_tests": 0},
        {"total_tests": 3, "passed_tests": 3, "failed_tests": 1, "not_run_tests": 0},
        {"total_tests": 0, "passed_tests": 0, "failed_tests": 0, "not_run_tests": 0},
        {"total_tests": 3, "passed_tests": True, "failed_tests": 0, "not_run_tests": 0},
    ],
)
def test_invalid_case_evidence_clears_prior_result(tmp_path, counts):
    wd = final_workdir(tmp_path)
    assert finalize_final(wd).returncode == 0
    (wd / "case-results.json").write_text(json.dumps(counts))
    assert finalize_final(wd).returncode == 2
    assert not (wd / "result.json").exists()


def test_empty_review_is_not_clean(tmp_path):
    wd = final_workdir(tmp_path)
    (wd / "check-review.md").write_text(" ")
    assert finalize_final(wd).returncode == 2
    assert not (wd / "result.json").exists()
