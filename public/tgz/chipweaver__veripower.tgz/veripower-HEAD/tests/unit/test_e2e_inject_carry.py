"""End-to-end validation: the kernel CLI drives real
dispatch -> execute -> reap -> promote rounds under inject+carry for (1) the
richest AUTHOR (rtl-design, which self-carries its own prior round into a
fresh workdir) and (2) a TRANSFORMER spanning four upstream stages
(power-analysis), plus (3) the "relocation invariance" behavioral proof (the REAL
criterion, not just token-absence): move the whole canonical
tree wholesale and the consumer still re-anchors, because it re-reads
`dispatch.json` every round instead of trusting a baked cross-stage path.

Model: test_kernel_cli.py's `run_json`/`dispatch_write_reap` subprocess idiom
(same per-stage minimal schema-valid `stage_specific`/output-file sets), scoped
here to only the stages these three tests need (specification, simulation-plan,
rtl-design, synthesis, simulation, power-analysis).
"""

import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPT = str(ROOT / "framework" / "scripts" / "kernel.py")
SYNTH_MAIN = ROOT / "skills" / "synthesis" / "scripts" / "synthesis" / "__main__.py"
POWER_MAIN = ROOT / "skills" / "power-analysis" / "scripts" / "power" / "__main__.py"


def utc_timestamp() -> str:
    """Second-resolution UTC stamp, mirroring the skill finalizers' utc_timestamp()
    (test_kernel_cli.py's helper) — so a result.json written mid-test passes the
    reap temporal-integrity check the same way a real freshly-finalized envelope
    does."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def run(tree_root, *args):
    return subprocess.run(
        [sys.executable, SCRIPT, *args],
        capture_output=True,
        text=True,
        cwd=str(tree_root),
    )


def run_json(tree_root, *args):
    r = run(tree_root, *args)
    assert r.returncode == 0, r.stderr
    return json.loads(r.stdout)


def write_file(tree_root, module, rel, content):
    p = tree_root / module / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content)
    return p


# Minimal pass-valid stage_specific per stage used here — exactly the per-stage
# schema's status=pass conditional requirements (skills/<stage>/references/
# result.schema.json), so reap-time schema validation genuinely passes.
STAGE_SPECIFIC = {
    "specification": {"top_module": "top"},
    "simulation-plan": {},
    "rtl-design": {},
    "synthesis": {"requirements": []},
    "simulation": {},
    "power-analysis": {
        "saif_artifacts": [],
        "compile_info": {"vcs_version": "test"},
        "failures": [],
        "requirements": [],
        "power_by_scenario": [],
    },
}

# Minimal declared-output set per stage: exactly the files downstream rules'
# own `inputs` selectors reference (per rules.RULES).
STAGE_FILES = {
    "specification": {
        "design.md": "design v1",
        "manifest.json": "{}",
        "requirements.json": "[]",
        "clocks.json": "[]",
        "check-hints.json": "[]",
        "top-io.json": "[]",
        "constraints/top.sdc": "# sdc",
        "constraints/top.sgdc": "# sgdc",
    },
    "simulation-plan": {
        "verification-plan.md": "plan v1",
        "tb-scaffold.json": "{}",
        "sequences.json": "[]",
        "power-scenarios.json": "[]",
    },
    "rtl-design": {
        "src/top.v": "module top; endmodule",
        "rtl-files.json": '{"files": ["src/top.v"]}',
        "constraint-annotations.json": "{}",
    },
    "synthesis": {
        "out/top_syn.v": "module top; endmodule",
        "out/top_syn.sdc": "# sdc",
        "out/top_syn.sdf": "# sdf",
        "reports/qor.rpt": "qor",
    },
    "simulation": {
        "case-results-summary.md": "all pass",
        "tests/testlist.json": "[]",
        "env.sh": "#!/bin/sh",
        "filelist.f": "-f rtl_filelist.f",
        "rtl_filelist.f": "top.v",
        "scripts/run_vcs_regression.sh": "#!/bin/sh\n",
        # the TB's package declaration: what the rendered power tests read their prefix from
        "tb/uvm/pkg/tb_pkg.sv": "package top_tb_pkg;\nendpackage\n",
    },
    "power-analysis": {
        "reports_ptpx/run1/power_hier.rpt": "power ok",
    },
}


def dispatch_write_reap(tree_root, module, rule, files):
    """dispatch `rule`, write `files` (workdir-relative path -> content) + a
    passing schema-valid result.json declaring them as artifacts, then reap.
    Returns the reap JSON."""
    d = run_json(
        tree_root,
        "dispatch",
        "--module",
        module,
        "--rule",
        rule,
    )
    assert d["ok"] is True, d
    workdir = d["workdir"]
    for rel, content in files.items():
        write_file(tree_root, module, f"{workdir}/{rel}", content)
    result = {
        "stage": rule,
        "module": module,
        "produced_at": utc_timestamp(),
        "status": "pass",
        "artifacts": [{"path": p} for p in files],
        "stage_specific": STAGE_SPECIFIC[rule],
    }
    write_file(tree_root, module, f"{workdir}/result.json", json.dumps(result))
    return run_json(
        tree_root, "reap", "--module", module, "--rule", rule, "--run", str(d["run"])
    )


def test_rtl_author_dispatch_reap_promote_green(tmp_path):
    module = "m"
    # 1. seed upstream canonical (specification products) + the intent tree
    write_file(tmp_path, module, "intent/brainstorm.md", "b1")
    spec = dispatch_write_reap(
        tmp_path, module, "specification", STAGE_FILES["specification"]
    )
    assert spec["ok"] is True and spec["verdict"] == "pass", spec

    # 2. dispatch rtl-design -> dispatch.json's design and manifest both
    # resolve to the SAME producer (specification) stage root, absolute.
    d1 = run_json(
        tmp_path,
        "dispatch",
        "--module",
        module,
        "--rule",
        "rtl-design",
    )
    assert d1["ok"] is True, d1
    wd1 = tmp_path / module / d1["workdir"]
    table = json.loads((wd1 / "dispatch.json").read_text())["inputs"]
    spec_root = str((tmp_path / module / "Design" / "specification").resolve())
    assert table["design"] == spec_root
    assert table["manifest"] == spec_root

    # 3. write a schema-valid rtl result.json in the workdir, reap -> verdict
    # pass, promote
    for rel, content in STAGE_FILES["rtl-design"].items():
        write_file(tmp_path, module, f"{d1['workdir']}/{rel}", content)
    result1 = {
        "stage": "rtl-design",
        "module": module,
        "produced_at": utc_timestamp(),
        "status": "pass",
        "artifacts": [{"path": p} for p in STAGE_FILES["rtl-design"]],
        "stage_specific": STAGE_SPECIFIC["rtl-design"],
    }
    write_file(tmp_path, module, f"{d1['workdir']}/result.json", json.dumps(result1))
    r1 = run_json(
        tmp_path,
        "reap",
        "--module",
        module,
        "--rule",
        "rtl-design",
        "--run",
        str(d1["run"]),
    )
    assert r1 == {"ok": True, "rule": "rtl-design", "run": d1["run"], "verdict": "pass"}
    canonical = tmp_path / module / "Design" / "rtl-design"
    assert (canonical / "src/top.v").read_text() == STAGE_FILES["rtl-design"][
        "src/top.v"
    ]

    # 4. re-dispatch rtl-design -> the previous *.v and both sidecars were
    # CARRIED into the new workdir (carry_self), not re-authored from scratch.
    d2 = run_json(
        tmp_path,
        "dispatch",
        "--module",
        module,
        "--rule",
        "rtl-design",
    )
    assert d2["ok"] is True and d2["run"] == d1["run"] + 1
    wd2 = tmp_path / module / d2["workdir"]
    assert (wd2 / "src/top.v").read_text() == STAGE_FILES["rtl-design"]["src/top.v"]
    assert (wd2 / "rtl-files.json").read_text() == STAGE_FILES["rtl-design"][
        "rtl-files.json"
    ]
    assert (wd2 / "constraint-annotations.json").read_text() == STAGE_FILES[
        "rtl-design"
    ]["constraint-annotations.json"]


def test_power_transformer_filelist_across_sim_and_synth(tmp_path):
    module = "m"
    write_file(tmp_path, module, "intent/brainstorm.md", "b1")
    # Power consumes the plan meaning and identifiers, independently of functional sequences.
    simplan_files = {
        "verification-plan.md": "plan v1",
        "tb-scaffold.json": "{}",
        "sequences.json": json.dumps([{"name": "idle_seq", "agent": "cpu"}]),
        "power-scenarios.json": json.dumps(
            [
                {
                    "id": "S1",
                }
            ]
        ),
    }
    # seed synthesis (netlist) + simulation (tb_env) + simulation-plan
    # (scaffold) + spec (ppa) canonical, each through a real dispatch+reap
    for rule, files in (
        ("specification", STAGE_FILES["specification"]),
        ("simulation-plan", simplan_files),
        ("rtl-design", STAGE_FILES["rtl-design"]),
        ("synthesis", STAGE_FILES["synthesis"]),
        ("simulation", STAGE_FILES["simulation"]),
    ):
        outcome = dispatch_write_reap(tmp_path, module, rule, files)
        assert outcome["ok"] is True and outcome["verdict"] == "pass", outcome

    # dispatch power-analysis -> dispatch.json spans all four keys as absolute
    # stage roots
    d = run_json(
        tmp_path,
        "dispatch",
        "--module",
        module,
        "--rule",
        "power-analysis",
    )
    assert d["ok"] is True, d
    wd = tmp_path / module / d["workdir"]
    table = json.loads((wd / "dispatch.json").read_text())["inputs"]
    base = str((tmp_path / module).resolve())
    assert table["netlist"] == base + "/Design/synthesis"
    assert table["tb_env"] == base + "/Verification/simulation"
    assert table["plan"] == base + "/Verification/simulation-plan"
    assert table["requirements"] == base + "/Design/specification"
    for key in ("netlist", "tb_env", "plan", "requirements"):
        assert Path(table[key]).is_absolute()

    # EXECUTE: the real power bootstrap script, reading the kernel-injected
    # dispatch.json exactly as a real task dispatch would -> env.sh's *_DIR
    # substitutions are absolute stage roots, no relpath climb.
    br = subprocess.run(
        [
            sys.executable,
            str(POWER_MAIN),
            "bootstrap",
            "--workdir",
            str(wd),
            "--top",
            "top",
        ],
        cwd=str(tmp_path),
        capture_output=True,
        text=True,
    )
    assert br.returncode == 0, br.stderr
    env_sh = (wd / "env.sh").read_text()
    assert f"export NETLIST={table['netlist']}/out/top_syn.v" in env_sh
    assert "TB_DIR" not in env_sh
    assert "/../" not in env_sh  # no relpath climb regardless of workdir depth

    # reap -> promote green
    for rel, content in STAGE_FILES["power-analysis"].items():
        write_file(tmp_path, module, f"{d['workdir']}/{rel}", content)
    authored = {
        "experiment/run.sh": "echo authored\n",
        "scripts/ptpx.tcl": "# local setup\n",
        "saif/idle.saif": "activity evidence\n",
    }
    for rel, content in authored.items():
        write_file(tmp_path, module, f"{d['workdir']}/{rel}", content)
    (wd / "experiment/run.sh").chmod(0o755)
    result = {
        "stage": "power-analysis",
        "module": module,
        "produced_at": utc_timestamp(),
        "status": "pass",
        "artifacts": [{"path": p} for p in [*STAGE_FILES["power-analysis"], *authored]],
        "stage_specific": STAGE_SPECIFIC["power-analysis"],
    }
    write_file(tmp_path, module, f"{d['workdir']}/result.json", json.dumps(result))
    r = run_json(
        tmp_path,
        "reap",
        "--module",
        module,
        "--rule",
        "power-analysis",
        "--run",
        str(d["run"]),
    )
    assert r == {
        "ok": True,
        "rule": "power-analysis",
        "run": d["run"],
        "verdict": "pass",
    }
    canonical = tmp_path / module / "Verification" / "power-analysis"
    assert (canonical / "reports_ptpx" / "run1" / "power_hier.rpt").is_file()

    again = run_json(
        tmp_path, "dispatch", "--module", module, "--rule", "power-analysis"
    )
    carried = tmp_path / module / again["workdir"]
    for rel, content in authored.items():
        assert (carried / rel).read_text() == content
    assert (carried / "experiment/run.sh").stat().st_mode & 0o100
    assert (carried / "reports_ptpx").exists()
    assert (carried / "saif").exists()


def test_relocation_invariance_consumer_reanchors(tmp_path):
    # The REAL criterion — not "no relpath token": move canonical
    # wholesale and the consumer still resolves, because it re-reads
    # dispatch.json each round instead of trusting a baked cross-stage path.
    module = "m"
    tree_a = tmp_path / "a"
    tree_a.mkdir()
    write_file(tree_a, module, "intent/brainstorm.md", "b1")
    for rule in ("specification", "rtl-design"):
        outcome = dispatch_write_reap(tree_a, module, rule, STAGE_FILES[rule])
        assert outcome["ok"] is True and outcome["verdict"] == "pass", outcome

    # Dispatch synthesis under tree A -> rtl_load.tcl points into A.
    d_a = run_json(
        tree_a,
        "dispatch",
        "--module",
        module,
        "--rule",
        "synthesis",
    )
    assert d_a["ok"] is True, d_a
    wd_a = tree_a / module / d_a["workdir"]
    br_a = subprocess.run(
        [
            sys.executable,
            str(SYNTH_MAIN),
            "bootstrap",
            "--workdir",
            str(wd_a),
            "--top",
            "top",
        ],
        cwd=str(tree_a),
        capture_output=True,
        text=True,
    )
    assert br_a.returncode == 0, br_a.stderr
    tcl_a = (wd_a / "scripts" / "rtl_load.tcl").read_text()
    rtl_root_a = str((tree_a / module / "Design" / "rtl-design").resolve())
    assert rtl_root_a in tcl_a

    # reap synthesis run 1 in A (so it is no longer in-flight) -> promote
    for rel, content in STAGE_FILES["synthesis"].items():
        write_file(tree_a, module, f"{d_a['workdir']}/{rel}", content)
    result = {
        "stage": "synthesis",
        "module": module,
        "produced_at": utc_timestamp(),
        "status": "pass",
        "artifacts": [{"path": p} for p in STAGE_FILES["synthesis"]],
        "stage_specific": STAGE_SPECIFIC["synthesis"],
    }
    write_file(tree_a, module, f"{d_a['workdir']}/result.json", json.dumps(result))
    reap_a = run_json(
        tree_a,
        "reap",
        "--module",
        module,
        "--rule",
        "synthesis",
        "--run",
        str(d_a["run"]),
    )
    assert reap_a["ok"] is True and reap_a["verdict"] == "pass", reap_a

    # Copy the WHOLE asic tree (events.jsonl + canonical products) to a second
    # location B.
    tree_b = tmp_path / "b"
    shutil.copytree(tree_a, tree_b)

    # Re-dispatch synthesis THERE -> a fresh run 2 whose write_dispatch
    # recomputes the rtl stage root against tree B's own cwd.
    d_b = run_json(
        tree_b,
        "dispatch",
        "--module",
        module,
        "--rule",
        "synthesis",
    )
    assert d_b["ok"] is True, d_b
    assert d_b["run"] == d_a["run"] + 1
    wd_b = tree_b / module / d_b["workdir"]
    br_b = subprocess.run(
        [
            sys.executable,
            str(SYNTH_MAIN),
            "bootstrap",
            "--workdir",
            str(wd_b),
            "--top",
            "top",
        ],
        cwd=str(tree_b),
        capture_output=True,
        text=True,
    )
    assert br_b.returncode == 0, br_b.stderr

    # rtl_load.tcl now points into B (the new absolute rtl root), NEVER the
    # stale A path.
    tcl_b = (wd_b / "scripts" / "rtl_load.tcl").read_text()
    assert str(tree_b) in tcl_b and str(tree_a) not in tcl_b
