"""Unit tests for lintcdc.result — thin combiner for lint-cdc result.json.

TDD order: AND gate + shape, header derivations,
artifact delivery and schema validation.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT / "skills" / "lint-cdc" / "scripts"))
from lintcdc import result as rb  # noqa: E402, I001

MAIN = REPO_ROOT / "skills/lint-cdc/scripts/lintcdc/__main__.py"


def spec(tmp_path, rows=()):
    """A specification root with a ledger, and the dispatch.json that points finalize at it."""
    sd = tmp_path / "spec"
    sd.mkdir(exist_ok=True)
    (sd / "requirements.json").write_text(json.dumps(list(rows)))
    (tmp_path / "dispatch.json").write_text(
        json.dumps({"inputs": {"requirements": str(sd)}})
    )
    return sd


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def clean_workdir(tmp_path, lint_err=0, cdc_err=0):
    wd = tmp_path
    (wd / "lint-violations.json").write_text(
        json.dumps(
            {
                "kind": "lint",
                "counts": {"error": lint_err, "warning": 0, "info": 5},
                "violations": [],
            }
        )
    )
    (wd / "cdc-violations.json").write_text(
        json.dumps(
            {
                "kind": "cdc",
                "counts": {"error": cdc_err, "warning": 0, "info": 14},
                "violations": [],
            }
        )
    )
    (wd / "lint-report.txt").write_text(
        "=== IPD lint-report (SpyGlass) ===\n"
        "top:  dut_top\n"
        "#     SpyGlass Version : SpyGlass_vL-2016.06\n"
    )
    (wd / "cdc-report.txt").write_text("=== IPD cdc-report (SpyGlass) ===\n")
    (wd / "scripts").mkdir()
    (wd / "scripts" / "constraints.sgdc").write_text("current_design dut_top\n")
    return wd


# ---------------------------------------------------------------------------
# AND gate + lean shape
# ---------------------------------------------------------------------------


def test_envelope_pass_lean_shape(tmp_path):
    wd = clean_workdir(tmp_path)
    assert rb.finalize(wd, [], []) == 0
    env = json.loads((wd / "result.json").read_text())
    assert env["stage"] == "lint-cdc"
    assert env["status"] == "pass" and env["produced_at"].endswith("Z")
    ss = env["stage_specific"]
    assert ss["tool"] == "SpyGlass vL-2016.06"
    assert ss["violations"] == []
    # lean: dropped fields absent
    for k in (
        "note",
        "waivers",
        "sgdc_seed",
        "top_module",
        "lint_counts",
        "cdc_counts",
    ):
        assert k not in ss


def test_envelope_fail_on_lint_error(tmp_path):
    wd = clean_workdir(tmp_path, lint_err=1)
    # one error-severity lint violation present, carrying the tool message the reason derives from
    (wd / "lint-violations.json").write_text(
        json.dumps(
            {
                "kind": "lint",
                "counts": {"error": 1, "warning": 0, "info": 0},
                "violations": [
                    {
                        "id": "W123:foo.v:9",
                        "rule": "W123",
                        "severity": "error",
                        "file": "foo.v",
                        "line": 9,
                        "message": "inferred latch on signal q",
                    }
                ],
            }
        )
    )
    assert rb.finalize(wd, [], []) == 0
    env = json.loads((wd / "result.json").read_text())
    assert env["status"] == "fail"
    ss = env["stage_specific"]
    assert ss["fail_reason"]
    v = ss["violations"][0]
    # reason is derived from the tool message: "<rule>: <message>"
    assert (v["id"], v["severity"], v["reason"]) == (
        "W123:foo.v:9",
        "error",
        "W123: inferred latch on signal q",
    )


def test_envelope_fail_on_warning_with_no_error(tmp_path):
    """A warning-severity message gates exactly as an error does: a run that left one standing
    is not sign-off, and a waive carrying its reason is the only route from there to pass."""
    wd = clean_workdir(tmp_path)
    (wd / "lint-violations.json").write_text(
        json.dumps(
            {
                "kind": "lint",
                "counts": {"error": 0, "warning": 1, "info": 5},
                "violations": [
                    {
                        "id": "SYNTH_5118:datapath.v:23",
                        "rule": "SYNTH_5118",
                        "severity": "warning",
                        "file": "datapath.v",
                        "line": 723,
                        "message": (
                            "Function (f32_add) may not return a correct value as 'n_t01' is "
                            "either unassigned or assigned some uninitialized variable in some "
                            "path(s)"
                        ),
                    }
                ],
            }
        )
    )
    assert rb.finalize(wd, [], []) == 0
    env = json.loads((wd / "result.json").read_text())
    assert env["status"] == "fail"
    ss = env["stage_specific"]
    assert "1 lint warning(s)" in ss["fail_reason"]
    v = ss["violations"][0]
    assert (v["id"], v["severity"]) == ("SYNTH_5118:datapath.v:23", "warning")
    assert v["reason"].startswith("SYNTH_5118: Function (f32_add) may not return")


def test_info_severity_does_not_gate(tmp_path):
    # The pass fixture carries info rows in its counts; only error and warning are counted.
    wd = clean_workdir(tmp_path)
    assert rb.finalize(wd, [], []) == 0
    assert json.loads((wd / "result.json").read_text())["status"] == "pass"


# ---------------------------------------------------------------------------
# Reproducibility-header derivations
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# artifacts[] enumeration
# ---------------------------------------------------------------------------


def test_enumerate_artifacts_present_only_no_self(tmp_path):
    (tmp_path / "scripts").mkdir()
    for rel in [
        "scripts/constraints.sgdc",
        "lint-report.txt",
        "cdc-report.txt",
        "lint-violations.json",
        "cdc-violations.json",
    ]:
        (tmp_path / rel).write_text("x")
    (tmp_path / "result.json").write_text("{}")  # must NOT self-list
    paths = [a["path"] for a in rb.enumerate_artifacts(tmp_path)]
    assert "scripts" in paths  # Iron Rule: warm-start anchor
    assert "lint-violations.json" in paths and "cdc-report.txt" in paths
    assert "result.json" not in paths
    assert all((tmp_path / p).exists() for p in paths)  # files or complete trees


# ---------------------------------------------------------------------------
# Result-schema validation
# ---------------------------------------------------------------------------


def test_pass_envelope_is_schema_valid(tmp_path):
    # Reuse framework.scripts.store.validate_result (Draft202012Validator + Registry)
    # on the produced result.json dict.
    from framework.scripts import store

    wd = clean_workdir(tmp_path)
    rb.finalize(wd, [], [])
    result = json.loads((wd / "result.json").read_text())
    err = store.validate_result("lint-cdc", result)
    assert err is None, f"lint-cdc result.json is not schema-valid: {err}"
    assert result["status"] == "pass"


def test_fail_envelope_is_schema_valid(tmp_path):
    # The FAIL path must also be schema-valid (the result schema requires fail_reason
    # on fail). Guard the fail shape explicitly.
    from framework.scripts import store

    wd = clean_workdir(tmp_path)
    # inject one error-severity lint violation -> status=fail with fail_reason + violations
    (wd / "lint-violations.json").write_text(
        json.dumps(
            {
                "kind": "lint",
                "counts": {"error": 1, "warning": 0, "info": 0},
                "violations": [
                    {
                        "id": "W123:foo.v:9",
                        "rule": "W123",
                        "severity": "error",
                        "file": "foo.v",
                        "line": 9,
                        "message": "inferred latch on signal q",
                    }
                ],
            }
        )
    )
    assert rb.finalize(wd, [], []) == 0
    result = json.loads((wd / "result.json").read_text())
    err = store.validate_result("lint-cdc", result)
    assert err is None, f"fail-path lint-cdc result.json is not schema-valid: {err}"
    assert result["status"] == "fail"


# ---------------------------------------------------------------------------
# Attribution: fix_owner is the one field this verb cannot derive. Everything the
# report says is already in violations[]; whose artifact must change is not.
# ---------------------------------------------------------------------------


def test_fail_envelope_carries_the_agent_named_fix_owner(tmp_path):
    """fix_owner is the one field this verb cannot derive: a constraint-family violation is
    reported at an RTL line while the fix belongs in the SGDC, and no rule prefix adjudicates
    that. The agent names it; finalize only records it."""
    wd = clean_workdir(tmp_path, cdc_err=1)
    (wd / "cdc-violations.json").write_text(
        json.dumps(
            {
                "kind": "cdc",
                "counts": {"error": 1, "warning": 0, "info": 0},
                "violations": [
                    {
                        "id": "Clock_info05:cdc_smoke.clk2",
                        "rule": "Clock_info05",
                        "severity": "error",
                        "message": "Clock-Net is unconstrained",
                    }
                ],
            }
        )
    )
    assert rb.finalize(wd, [], [], fix_owner="specification") == 0
    ss = json.loads((wd / "result.json").read_text())["stage_specific"]
    assert ss["fix_owner"] == "specification"


def test_fail_envelope_omits_fix_owner_when_unnamed(tmp_path):
    """Absence is the signal decide reads as "this stage cannot tell", so an unnamed owner
    must not serialize as a present-but-empty key."""
    wd = clean_workdir(tmp_path, cdc_err=1)
    assert rb.finalize(wd, [], []) == 0
    ss = json.loads((wd / "result.json").read_text())["stage_specific"]
    assert "fix_owner" not in ss


def test_fail_envelope_no_violations_omits_failures(tmp_path):
    # Report-missing early-fail path: no error-severity violation rows at all ->
    # nothing to classify -> failures[] stays unset (not invented).
    wd = clean_workdir(tmp_path)
    (wd / "lint-violations.json").unlink()
    assert rb.finalize(wd, [], []) == 0
    env = json.loads((wd / "result.json").read_text())
    ss = env["stage_specific"]
    assert env["status"] == "fail"
    assert "failures" not in ss


# ---------------------------------------------------------------------------
# New: finalize() wrapper (BLOCKED policy) + CLI dispatch
# ---------------------------------------------------------------------------


def test_early_fail_reason_wins_and_is_the_failure_declaration(tmp_path):
    """The Step 4/5 early-fail closes through this verb too. `make` died before the parser
    wrote its sidecar, so the cause exists only on stderr where the agent read it; passing it
    is what declares the failure, and it must not be overwritten by the derived gate wording."""
    wd = clean_workdir(tmp_path)
    (wd / "cdc-violations.json").unlink()  # write-fresh-or-nothing removed it
    reason = "SpyGlass exited 1 before cdc_setup: no license for cdc/cdc_verify_struct"
    assert rb.finalize(wd, [], [], fail_reason=reason, fix_owner="rtl-design") == 0
    env = json.loads((wd / "result.json").read_text())
    ss = env["stage_specific"]
    assert env["status"] == "fail"
    assert ss["fail_reason"] == reason  # not "CDC report missing/unparseable, ..."
    assert ss["fix_owner"] == "rtl-design"


def test_fail_reason_forces_fail_on_an_otherwise_clean_pair(tmp_path):
    # A tool failure can leave both sidecars clean (e.g. make died after reporting).
    # Supplying the reason is the failure declaration, so the gate must not out-vote it.
    wd = clean_workdir(tmp_path)
    assert rb.finalize(wd, [], [], fail_reason="spyglass crashed post-report") == 0
    env = json.loads((wd / "result.json").read_text())
    assert env["status"] == "fail"
    assert env["stage_specific"]["fail_reason"] == "spyglass crashed post-report"


def test_empty_fail_reason_is_blocked_not_a_fail(tmp_path):
    # An unreasoned early-fail is a program error, never a routable verdict.
    wd = clean_workdir(tmp_path)
    assert rb.finalize(wd, [], [], None, "   ") == 2
    assert not (wd / "result.json").exists()


@pytest.mark.parametrize(
    "body",
    [
        "waive -rules {W257} -comment {documented reason}",
        "set reason {documented reason}\nwaive -rules {W257} -comment $reason",
        "if {0} {\nwaive -rules {W257}\n}",
    ],
)
def test_waiver_source_format_does_not_gate_closure(tmp_path, body):
    # The native reports are clean and report no waived messages. Source declarations
    # do not establish what ran or matched; they must not create an extra gate.
    wd = clean_workdir(tmp_path)
    (wd / "scripts").mkdir(exist_ok=True)
    (wd / "scripts/waiver.tcl").write_text(body + "\n")
    assert rb.finalize(wd, [], []) == 0
    assert json.loads((wd / "result.json").read_text())["status"] == "pass"


@pytest.mark.parametrize(
    "body",
    [
        "waive -rules {W257} -comment {documented reason}",
        'waive -rules {W257} -comment ""',
        'if {1} {waive -rules {W257} -comment ""}',
    ],
)
def test_waiver_problem_can_be_returned_without_editing_the_script(tmp_path, body):
    wd = clean_workdir(tmp_path)
    (wd / "scripts").mkdir(exist_ok=True)
    (wd / "scripts/waiver.tcl").write_text(body + "\n")
    reason = "The applied waiver lacks a task-grounded justification."
    assert rb.finalize(wd, [], [], "lint-cdc", reason) == 0
    result = json.loads((wd / "result.json").read_text())
    assert result["status"] == "fail"
    assert result["stage_specific"]["fail_reason"] == reason
    assert result["stage_specific"]["fix_owner"] == "lint-cdc"
    assert (wd / "scripts/waiver.tcl").read_text() == body + "\n"


def test_finalize_missing_required_flag_is_blocked(tmp_path):
    MAIN = REPO_ROOT / "skills/lint-cdc/scripts/lintcdc/__main__.py"
    # --workdir is the one flag finalize cannot infer; omitting it is argparse exit 2,
    # never a written envelope.
    r = subprocess.run(
        ["python3", str(MAIN), "finalize"],
        capture_output=True,
        text=True,
    )
    assert r.returncode == 2
    assert not (tmp_path / "result.json").exists()


def test_finalize_cli_happy_path(tmp_path):
    # End-to-end through the finalize CLI (lazy handler import + arg mapping), not just
    # in-process run(). A handler typo would pass every other test (which call run()
    # directly) but fail here. --top omitted -> defaults to the report header.
    wd = clean_workdir(tmp_path)
    spec(tmp_path)
    r = subprocess.run(
        ["python3", str(MAIN), "finalize", "--workdir", str(wd)],
        capture_output=True,
        text=True,
    )
    assert r.returncode == 0, r.stderr
    env = json.loads((wd / "result.json").read_text())
    assert (env["stage"], env["status"]) == ("lint-cdc", "pass")
    assert env["stage_specific"]["requirements"] == []


# ---------------------------------------------------------------------------
# The rows requirements.json assigns to lint-cdc: judged by the agent, accounted for here
# ---------------------------------------------------------------------------

ROWS = [
    {
        "id": "R-7",
        "verbatim": "lint / CDC clean（0 Error、0 Warning）",
        "judge": "lint-cdc",
    },
    {"id": "R-8", "verbatim": "single clock domain", "judge": "lint-cdc"},
    {"id": "R-9", "verbatim": "no `initial` blocks", "judge": "rtl-design"},
]


def cli(wd, *extra):
    return subprocess.run(
        ["python3", str(MAIN), "finalize", "--workdir", str(wd), *extra],
        capture_output=True,
        text=True,
    )


def test_declared_verdicts_land_in_the_envelope(tmp_path):
    wd = clean_workdir(tmp_path)
    spec(tmp_path, ROWS)
    declared = [
        {
            "id": "R-7",
            "met": True,
            "actual": "0 errors, 0 warnings, 0 waivers",
            "measured": "read from the run's own report",
        },
        {
            "id": "R-8",
            "met": True,
            "actual": "1 clock domain",
            "measured": "read from the run's own report",
        },
    ]
    r = cli(wd, "--requirements", json.dumps(declared))
    assert r.returncode == 0, r.stderr
    env = json.loads((wd / "result.json").read_text())
    assert env["status"] == "pass"
    assert (
        env["stage_specific"]["requirements"] == declared
    )  # in ledger order, only its rows


def test_an_unmet_row_fails_the_run(tmp_path):
    wd = clean_workdir(tmp_path)
    spec(tmp_path, ROWS)
    declared = [
        {
            "id": "R-7",
            "met": False,
            "actual": "2 warnings waived",
            "measured": "read from the run's own report",
        },
        {"id": "R-8", "met": True, "measured": "read from the run's own report"},
    ]
    r = cli(wd, "--requirements", json.dumps(declared), "--fix-owner", "rtl-design")
    assert r.returncode == 0, r.stderr
    ss = json.loads((wd / "result.json").read_text())["stage_specific"]
    assert ss["fail_reason"] == "requirement(s) not met: R-7"
    assert ss["fix_owner"] == "rtl-design"


def test_a_row_nobody_judged_is_blocked(tmp_path):
    # A row the agent never read cannot pass as silence.
    wd = clean_workdir(tmp_path)
    spec(tmp_path, ROWS)
    r = cli(
        wd,
        "--requirements",
        json.dumps(
            [{"id": "R-7", "met": True, "measured": "read from the run's own report"}]
        ),
    )
    assert r.returncode == 2
    assert "R-8" in r.stderr and not (wd / "result.json").exists()


def test_a_verdict_on_another_stages_row_is_blocked(tmp_path):
    wd = clean_workdir(tmp_path)
    spec(tmp_path, ROWS)
    declared = [
        {"id": "R-7", "met": True, "measured": "read from the run's own report"},
        {"id": "R-8", "met": True, "measured": "read from the run's own report"},
        {"id": "R-9", "met": True, "measured": "read from the run's own report"},
    ]
    r = cli(wd, "--requirements", json.dumps(declared))
    assert r.returncode == 2 and "R-9" in r.stderr


def test_a_tool_fail_needs_no_verdicts(tmp_path):
    # The rows are judged once the tool gate is clean; a failed run is already a fail.
    wd = clean_workdir(tmp_path, lint_err=1)
    spec(tmp_path, ROWS)
    r = cli(wd)
    assert r.returncode == 0, r.stderr
    env = json.loads((wd / "result.json").read_text())
    assert env["status"] == "fail" and "requirements" not in env["stage_specific"]
