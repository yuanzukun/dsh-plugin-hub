"""Every command line a skill documents must be one its CLI actually accepts.

Outdated flags in simulation's documented finalize commands previously blocked real runs.
Keep the examples consistent with the commands agents can execute.

So the check is mechanical: pull every `bash` block out of the agent-facing prose, resolve the
CLI it names, and ask that CLI whether the verb and every long flag exist. Re-introducing the
`--failure-phase` line makes this fail, as does renaming a verb.

One block is deliberately unreachable: design-flow's kernel dispatch passes `dispatch_args`
verbatim from `decide`, so the prose has a placeholder where a verb would be.
"""

import re
import subprocess
import sys
from functools import lru_cache
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
BLOCK = re.compile(r"```bash\n(.*?)```", re.S)
LONG_FLAG = re.compile(r"(?<![\w-])(--[a-z][a-z0-9-]*)")
VERB = re.compile(r"[a-z][a-z-]*\Z")


def cli_for(cmd: str, skill: str) -> Path | None:
    if "kernel.py" in cmd:
        return ROOT / "framework/scripts/kernel.py"
    m = re.search(r"<skill>/scripts/([a-z_]+)(?:/__main__\.py)?", cmd)
    if not m:
        return None
    base = ROOT / "skills" / skill / "scripts" / m.group(1)
    return base / "__main__.py" if (base / "__main__.py").is_file() else base


def documented_commands():
    for md in sorted((ROOT / "skills").glob("*/SKILL.md")) + sorted(
        (ROOT / "skills").glob("*/references/*.md")
    ):
        skill = md.relative_to(ROOT / "skills").parts[0]
        for block in BLOCK.findall(md.read_text(encoding="utf-8")):
            for line in block.replace("\\\n", " ").splitlines():
                cmd = " ".join(line.split())
                cli = cli_for(cmd, skill)
                if cli is not None:
                    yield str(md.relative_to(ROOT)), cli, cmd


def documented():
    for md, cli, cmd in documented_commands():
        tail = cmd.split(cli.name)[-1] if cli.name in cmd else cmd
        words = [
            w for w in tail.split() if not w.startswith(("-", "<", "{", "[", "'", '"'))
        ]
        if words and VERB.fullmatch(words[0]):
            yield md, cli, words[0], tuple(sorted(set(LONG_FLAG.findall(tail))))


CASES = list(documented())


@lru_cache(maxsize=None)
def help(cli: Path, verb: str):
    r = subprocess.run(
        [sys.executable, str(cli), verb, "--help"], capture_output=True, text=True
    )
    return r.returncode, r.stdout


def test_every_skill_command_block_is_checked():
    commands = list(documented_commands())
    assert commands
    for md, cli, cmd in commands:
        assert cli.is_file(), f"{md} documents missing CLI {cli}: {cmd}"
    assert {c[1] for c in CASES} == {c[1] for c in commands}


@pytest.mark.parametrize(
    "md,cli,verb,flags", CASES, ids=[f"{c[0]}:{c[2]}" for c in CASES]
)
def test_documented_command_is_accepted(md, cli, verb, flags):
    rc, out = help(cli, verb)
    assert rc == 0, f"{md} documents `{verb}`, which {cli.name} does not accept"
    for flag in flags:
        assert flag in out, (
            f"{md} documents `{verb} {flag}`, which {cli.name} does not accept"
        )
