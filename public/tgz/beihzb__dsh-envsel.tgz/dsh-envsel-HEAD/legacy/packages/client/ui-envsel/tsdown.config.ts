import { clientBundle } from '../tsdown.client.ts'

export default clientBundle('@deepseek-ai/dsh-client-ui-envsel', ['lib/types/index.js', 'lib/types/invariant.js'])
