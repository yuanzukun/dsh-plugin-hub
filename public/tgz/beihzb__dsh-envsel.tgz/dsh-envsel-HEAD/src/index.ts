/**
 * envsel — session environment selector for DeepSeek Harness. Per-language
 * slots (`python`, `r`, `cli`) each hold one first-priority environment drawn
 * from conda, standalone R installs, WSL distributions, or user-pinned custom
 * paths. Selections persist in a machine-local JSON store keyed by session id
 * (never the session event log — see state.ts), reach the model as a
 * per-turn runtime-context block and as `DSH_ENV_*` facts on every shell call,
 * and are changed from the browser via the `/env` command, the `session_env`
 * model tool, or the `envsel` Typert Remote that backs the header dropdown.
 * A session with no selection of its own inherits the nearest selecting
 * session it descends from, so delegated work keeps the environment its
 * parent chose.
 *
 * @module @beihaizb/dsh-envsel
 */

import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { CommandInvocation, CommandResult } from '@deepseek-ai/dsh-commands'
import type { BashEnvContributor } from '@deepseek-ai/dsh-shell-env'
import type { DshEnvironmentKey } from '@deepseek-ai/dsh-shell'
import { discoverAll, isWindowsHost, probeCustomPath } from './discover.ts'
import type { DiscoverConfig } from './discover.ts'
import { appendPinnedPath, PINNED_FILE_NAME, removePinnedPath, resolvePinnedEntries } from './pin-cache.ts'
import { EnvselRemoteService } from './remote.ts'
import type { EnvselGatewayHandlers } from './remote.ts'
import { readAllSelections, writeSessionSelection } from './state.ts'
import { hostCopy, resolveHostLocale, slotLabel } from './copy.ts'
import {
  ENV_SLOTS,
  isEmptySelection,
} from './types.ts'
import type { EnvEntry, EnvSelection, EnvSlot, SessionId } from './types.ts'
import type {
  EnvselCatalogValue,
  EnvselGetResult,
  EnvselGetValue,
  EnvselPinResult,
  EnvselRejected,
  EnvselSetResult,
  EnvselSuccess,
  EnvselUnpinResult,
} from './types.ts'
export {
  defaultStandaloneRRoots,
  isWindowsHost,
  joinPath,
  prefixFromRscript,
  probeCustomPath,
} from './discover.ts'
export { parsePinnedDocument, PINNED_FILE_NAME, serializePinnedDocument } from './pin-cache.ts'
export { parseStateDocument, serializeStateDocument, STATE_FILE_NAME } from './state.ts'
export type * from './types.ts'
export { EnvselRemoteService } from './remote.ts'
export type { EnvselGatewayHandlers } from './remote.ts'
export type { DiscoverConfig, DiscoverResult } from './discover.ts'

export const name = 'envsel'

/** Hard dependencies: every service ships in the official DSH host plane. */
export const inject = ['subprocess', 'fs', 'shellEnv', 'commands', 'tools', 'timer', 'sessions']

/** Default catalog cache TTL in milliseconds. */
export const LIST_TTL_MS_DEFAULT = 300000

/** Default conda executable name. */
export const CONDA_COMMAND_DEFAULT = 'conda'

/** Default per-probe watchdog timeout in milliseconds. */
export const PROBE_TIMEOUT_MS_DEFAULT = 20000

/**
 * Order of envsel's runtime-context block. The official blocks occupy 110
 * (sandbox policy), 115 (approval policy) and 120 (subagent delegation), so a
 * selection is rendered after every policy block and before any later
 * contribution — a stable position keeps the durable snapshot from churning.
 */
export const PROMPT_CONTEXT_ORDER = 130

/**
 * Maximum delegating-session hops walked when a session has no selection of
 * its own. A DSH subagent runs in its own session (`origin: "subagent"`,
 * `delegationDepth: n`) whose header still names the session that delegated to
 * it, so the walk lets delegated work inherit the environment its parent
 * chose instead of silently falling back to the host default.
 */
export const MAX_INHERIT_HOPS = 8

/** Name of envsel's runtime-context contribution. */
export const PROMPT_CONTEXT_NAME = 'envsel:session-environment'

/** envsel deployment configuration (every field optional; schema defaults apply). */
export interface Config {
  /** Catalog cache TTL in milliseconds. */
  readonly listTtlMs?: number
  /** Conda executable name or absolute path. */
  readonly condaCommand?: string
  /** Extra standalone-R roots scanned after the Program Files defaults. */
  readonly standaloneRRoots?: string[]
  /** Whether WSL discovery is enabled. */
  readonly wslEnabled?: boolean
  /** Whether the `session_env` model tool is registered. */
  readonly registerTool?: boolean
  /**
   * Whether the selection is contributed to the per-turn runtime context.
   * Requires a host that binds the assembling agent to its context providers
   * (DSH 0.2.0-rc.1 and newer); on an older host the contribution renders
   * nothing and this switch has no effect.
   */
  readonly registerContext?: boolean
  /** Per-probe hard timeout in milliseconds (watchdog terminate). */
  readonly probeTimeoutMs?: number
}

/** Validated runtime configuration. */
interface ResolvedConfig {
  readonly listTtlMs: number
  readonly condaCommand: string
  readonly standaloneRRoots: readonly string[]
  readonly wslEnabled: boolean
  readonly registerTool: boolean
  readonly registerContext: boolean
  readonly probeTimeoutMs: number
}

/** Apply defaults and validate deployment values at the configuration boundary. */
function resolveConfig(input: Config = {}): ResolvedConfig {
  const listTtlMs = input.listTtlMs ?? LIST_TTL_MS_DEFAULT
  const probeTimeoutMs = input.probeTimeoutMs ?? PROBE_TIMEOUT_MS_DEFAULT
  const condaCommand = input.condaCommand ?? CONDA_COMMAND_DEFAULT
  if (!Number.isFinite(listTtlMs) || listTtlMs <= 0) {
    throw new TypeError(`envsel: listTtlMs must be a positive finite number, got ${String(listTtlMs)}`)
  }
  if (!Number.isFinite(probeTimeoutMs) || probeTimeoutMs <= 0) {
    throw new TypeError(`envsel: probeTimeoutMs must be a positive finite number, got ${String(probeTimeoutMs)}`)
  }
  if (condaCommand.trim().length === 0) {
    throw new TypeError('envsel: condaCommand must be non-empty')
  }
  return {
    listTtlMs,
    condaCommand: condaCommand.trim(),
    standaloneRRoots: [...(input.standaloneRRoots ?? [])],
    wslEnabled: input.wslEnabled ?? true,
    registerTool: input.registerTool ?? true,
    registerContext: input.registerContext ?? true,
    probeTimeoutMs,
  }
}

/**
 * Structural view of one runtime-context block, matching
 * `PromptContext` in `@deepseek-ai/dsh-system-prompt`. Declared here rather
 * than imported so this plugin needs no additional dependency for a single
 * optional contribution.
 */
interface PromptContextContribution {
  readonly name: string
  readonly order: number
  readonly text: string | ((context: { readonly agent?: Agent }) => string)
}

/**
 * Structural view of the host's system-prompt service. Only `context` is
 * used; the contribution is skipped entirely on a host that does not expose it.
 */
interface SystemPromptHost {
  context(contribution: PromptContextContribution): () => void
}

/** Parse one `/env` command line. */
type EnvLineAction =
  | { kind: 'show' }
  | { kind: 'help' }
  | { kind: 'clear' }
  | { kind: 'wsl' }
  | { kind: 'add'; path: string }
  | { kind: 'unpin'; address: string }
  | { kind: 'list'; filter: string }
  | { kind: 'assign'; assignments: ReadonlyArray<{ slot: EnvSlot; value: string }> }
  | { kind: 'error'; text: string }

const ASSIGNMENT = /^([a-z]+)=(.*)$/u

/** Parse the raw input of a `/env` invocation into an action. */
export function parseEnvLine(rawInput: string, locale: 'en' | 'zh' = 'en'): EnvLineAction {
  const copy = hostCopy(locale)
  const tokens = rawInput.trim().split(/\s+/u).filter(token => token.length > 0)
  if (tokens.length === 0) return { kind: 'show' }
  const first = tokens[0]!
  if (first === 'help') return { kind: 'help' }
  if (first === 'clear') return { kind: 'clear' }
  if (first === 'wsl') return { kind: 'wsl' }
  if (first === 'add') {
    const path = tokens.slice(1).join(' ').trim()
    if (path.length === 0) return { kind: 'error', text: copy.usageAdd }
    return { kind: 'add', path }
  }
  if (first === 'unpin') {
    const address = tokens.slice(1).join(' ').trim()
    if (address.length === 0) return { kind: 'error', text: copy.usageUnpin }
    return { kind: 'unpin', address }
  }
  if (first === 'list') {
    return { kind: 'list', filter: tokens.slice(1).join(' ').trim() }
  }
  const assignments: { slot: EnvSlot; value: string }[] = []
  for (const token of tokens) {
    const match = ASSIGNMENT.exec(token)
    if (match === null) {
      return { kind: 'error', text: copy.unknownArg(token) }
    }
    const slot = match[1] as EnvSlot
    const value = match[2] ?? ''
    if (!ENV_SLOTS.includes(slot)) {
      return { kind: 'error', text: copy.unknownSlot(slot) }
    }
    assignments.push({ slot, value })
  }
  return { kind: 'assign', assignments }
}

/** Resolve a value into an entry reference against one catalog. */
function resolveEntry(catalog: readonly EnvEntry[], value: string): EnvEntry | null {
  if (value.length === 0) return null
  if (value.includes(':')) {
    const parts = value.split(':')
    if (parts.length === 2) {
      const [kind, name] = parts
      return catalog.find(entry => entry.kind === kind && entry.name === name) ?? null
    }
    if (parts.length === 3 && parts[0] === 'wsl') {
      const [, distro, name] = parts
      return catalog.find(entry => entry.kind === 'wsl' && entry.distro === distro && entry.name === name) ?? null
    }
    return null
  }
  const matches = catalog.filter(entry => entry.name === value)
  if (matches.length === 1) return matches[0]!
  return null
}

/** Whether an entry can serve a slot (its language must be present). */
export function slotCompatible(slot: EnvSlot, entry: EnvEntry): boolean {
  if (slot === 'python') return entry.python !== null
  if (slot === 'r') return entry.rscript !== null
  return true
}

/** Human-readable one-line summary of an entry. */
export function describeEntry(entry: EnvEntry): string {
  const badges = [
    entry.python !== null ? 'python' : null,
    entry.rscript !== null ? 'R' : null,
  ].filter((badge): badge is string => badge !== null)
  const address = entry.kind === 'wsl'
    ? `wsl:${entry.distro}:${entry.name}`
    : `${entry.kind}:${entry.name}`
  return `${address} — ${entry.prefix}${badges.length > 0 ? ` (${badges.join(', ')})` : ''}`
}

/** Render the runtime-context block for one selection. */
export function selectionContext(selection: EnvSelection): string {
  const blocks: string[] = []
  const python = selection.python
  if (python !== undefined) {
    const run = python.pythonCommand ?? python.python ?? `python from ${python.prefix}`
    const lines = [
      `Session Python env (user-selected): ${python.name} (${python.kind}).`,
      `- python: ${run}`,
      `Use it for all Python work in this session: ${run} script.py (absolute path, no activation needed).`,
    ]
    if (python.kind === 'wsl') lines.push('- WSL: pass Windows paths as /mnt/c/<drive>/<path>.')
    blocks.push(lines.join('\n'))
  }
  const r = selection.r
  if (r !== undefined) {
    const run = r.rscriptCommand ?? r.rscript ?? `Rscript from ${r.prefix}`
    const lines = [
      `Session R env (user-selected): ${r.name} (${r.kind}).`,
      `- Rscript: ${run}`,
      `Use it for all R work in this session: ${run} -e / -f file.R.`,
    ]
    if (r.kind === 'wsl') lines.push('- WSL: pass Windows paths as /mnt/c/<drive>/<path>.')
    blocks.push(lines.join('\n'))
  }
  const cli = selection.cli
  if (cli !== undefined) {
    const lines = [
      `Session CLI env (user-selected): ${cli.name} (${cli.kind}) — prepend its dirs to PATH for shell tools:`,
      cliPathGuidance(cli),
    ]
    blocks.push(lines.join('\n'))
  }
  return blocks.join('\n\n')
}

/**
 * Resolve a session's effective selection. A session's own entry always wins;
 * otherwise the nearest selection owned by a session it descends from is used,
 * walking `parentOf` at most `maxHops` times.
 *
 * Delegated work runs in its own session — a DSH subagent child records the
 * session that delegated to it in `header.parentSession` — so without the walk
 * a subagent would silently fall back to the host default instead of the
 * environment the delegating session selected.
 *
 * Free of host services on purpose: the resolution order is the part worth
 * testing, and it stays testable only while it needs nothing but the map.
 *
 * @param sessionId - the session to resolve.
 * @param selections - folded selections keyed by session id.
 * @param parentOf - the delegating session of a session, when one is known.
 * @param maxHops - hard bound on the ancestor walk.
 * @returns the effective selection, or an empty object when none applies.
 */
export function resolveSelection(
  sessionId: SessionId,
  selections: ReadonlyMap<string, EnvSelection>,
  parentOf: (sessionId: SessionId) => SessionId | undefined,
  maxHops: number = MAX_INHERIT_HOPS,
): EnvSelection {
  const own = selections.get(String(sessionId))
  if (own !== undefined) return own
  let cursor = parentOf(sessionId)
  for (let hops = 0; cursor !== undefined && hops < maxHops; hops += 1) {
    const inherited = selections.get(String(cursor))
    if (inherited !== undefined) return inherited
    cursor = parentOf(cursor)
  }
  return {}
}

/** Usage text for the /env command. */
export function envHelpText(locale: 'en' | 'zh' = 'en'): string {
  return hostCopy(locale).help
}

/** Display path of the machine-local pin cache. */
function pinnedCacheHint(): string {
  return `~/.dsh/${PINNED_FILE_NAME}`
}

/**
 * PATH-prefix guidance for the CLI slot, matching the host shell family.
 * @param entry - selected CLI environment.
 * @param platform - Node platform string; defaults to `process.platform`.
 * @returns one copy-pasteable PATH line for the model snapshot.
 */
export function cliPathGuidance(entry: EnvEntry, platform: NodeJS.Platform = process.platform): string {
  if (entry.kind === 'wsl') {
    return `- wsl.exe -d ${entry.distro} -- bash -lc 'export PATH="${entry.prefix}/bin:$PATH"'`
  }
  if (isWindowsHost(platform)) {
    return `- pwsh: $env:PATH = "${entry.prefix};${entry.prefix}\\Scripts;${entry.prefix}\\Library\\bin;" + $env:PATH`
  }
  return `- bash: export PATH="${entry.prefix}/bin:${entry.prefix}:$PATH"`
}

/** The registered `session_env` tool name. */
export const SESSION_ENV_TOOL = 'session_env'

/** Build one successful Remote reply branch. */
function success<T>(value: T): EnvselSuccess<T> {
  return Object.freeze({ ok: true, value })
}

/** Build one rejected Remote reply branch. */
function rejected<E>(error: E): EnvselRejected<E> {
  return Object.freeze({ ok: false, error: Object.freeze(error) })
}

/**
 * Install the envsel command, prompt context, shell facts, and model tool.
 * @param ctx - registrant context carrying every injected service.
 * @param config - deployment's explicit envsel policy.
 */
export async function apply(ctx: Context, config: Config): Promise<void> {
  const resolved = resolveConfig(config)
  const locale = resolveHostLocale(ctx)
  const copy = hostCopy(locale)
  const discoverConfig: DiscoverConfig = {
    condaCommand: resolved.condaCommand,
    standaloneRRoots: resolved.standaloneRRoots,
    wslEnabled: resolved.wslEnabled,
    probeTimeoutMs: resolved.probeTimeoutMs,
  }

  // ── catalog cache ──────────────────────────────────────────────────────────
  let catalog: { at: number; entries: EnvEntry[]; warnings: string[] } | null = null
  let catalogPending: Promise<{ entries: EnvEntry[]; warnings: string[] }> | null = null

  async function loadCatalog(): Promise<{ entries: EnvEntry[]; warnings: string[] }> {
    const discovered = await discoverAll(ctx, discoverConfig)
    const pinned = await resolvePinnedEntries(ctx)
    const seen = new Set(discovered.entries.map(entry => `${entry.kind}|${entry.distro ?? ''}|${entry.name}|${entry.prefix}`))
    const entries = [...discovered.entries]
    for (const entry of pinned.entries) {
      const key = `${entry.kind}|${entry.distro ?? ''}|${entry.name}|${entry.prefix}`
      if (seen.has(key)) continue
      seen.add(key)
      entries.push(entry)
    }
    return { entries, warnings: [...discovered.warnings, ...pinned.warnings] }
  }

  function getCatalog(force: boolean): Promise<{ entries: EnvEntry[]; warnings: string[] }> {
    if (catalogPending !== null) return catalogPending
    if (!force && catalog !== null && Date.now() - catalog.at < resolved.listTtlMs) {
      return Promise.resolve({ entries: catalog.entries, warnings: catalog.warnings })
    }
    catalogPending = loadCatalog()
      .then(result => {
        catalog = { at: Date.now(), entries: result.entries, warnings: result.warnings }
        return { entries: result.entries, warnings: result.warnings }
      })
      .finally(() => {
        catalogPending = null
      })
    return catalogPending
  }

  async function pinPath(path: string): Promise<EnvselPinResult> {
    const probed = await probeCustomPath(ctx, path)
    if (!probed.ok) return rejected({ code: probed.code, path: path.trim() })
    await appendPinnedPath(ctx, path)
    const result = await getCatalog(true)
    return success<EnvselCatalogValue>({ entries: result.entries, warnings: result.warnings })
  }

  async function unpinPath(address: string): Promise<EnvselUnpinResult> {
    const current = await getCatalog(false)
    const removed = await removePinnedPath(ctx, address, current.entries)
    if (!removed) return rejected({ code: 'entry-not-found', address })
    const result = await getCatalog(true)
    return success<EnvselCatalogValue>({ entries: result.entries, warnings: result.warnings })
  }

  // ── per-session selection: in-memory map preloaded from the durable store ──
  const selections = new Map<string, EnvSelection>()

  function liveSession(sessionId: SessionId): ReturnType<typeof ctx.sessions.get> {
    return ctx.sessions.get(sessionId)
  }

  function selectionOfSession(sessionId: SessionId): EnvSelection {
    return resolveSelection(sessionId, selections, parentOfSession)
  }

  /** The header-named delegating session of a live session, when it has one. */
  function parentOfSession(sessionId: SessionId): SessionId | undefined {
    return liveSession(sessionId)?.header.parentSession
  }

  function selectionOf(agent: Agent): EnvSelection {
    return selectionOfSession(agent.session.header.id)
  }

  async function setSelectionForSession(sessionId: SessionId, next: EnvSelection): Promise<void> {
    if (isEmptySelection(next)) {
      selections.delete(String(sessionId))
    } else {
      selections.set(String(sessionId), next)
    }
    await writeSessionSelection(ctx, sessionId, next)
  }

  async function setSelection(agent: Agent, next: EnvSelection): Promise<void> {
    await setSelectionForSession(agent.session.header.id, next)
  }

  function copySelection(agent: Agent): EnvSelection {
    return { ...selectionOf(agent) }
  }

  // Preload durable selections into memory so every synchronous read path
  // (the DSH_ENV_* resolve, command/tool/remote handlers) sees the same state.
  {
    const stored = await readAllSelections(ctx)
    for (const [key, value] of Object.entries(stored)) selections.set(key, value)
  }

  // ── browser gateway: shares the catalog cache and selection state ───────────
  const gatewayHandlers: EnvselGatewayHandlers = {
    list: async () => {
      const result = await getCatalog(false)
      return { entries: result.entries, warnings: result.warnings }
    },
    get: (sessionId: SessionId): EnvselGetResult => {
      if (liveSession(sessionId) === undefined) {
        return rejected({ code: 'session-not-found', sessionId })
      }
      return success<EnvselGetValue>({ selection: selectionOfSession(sessionId) })
    },
    pin: (path: string) => pinPath(path),
    unpin: (address: string) => unpinPath(address),
    set: async (sessionId: SessionId, slot: EnvSlot, address: string): Promise<EnvselSetResult> => {
      if (liveSession(sessionId) === undefined) {
        return rejected({ code: 'session-not-found', sessionId })
      }
      if (!(ENV_SLOTS as readonly string[]).includes(slot)) {
        return rejected({ code: 'unknown-slot', sessionId, slot })
      }
      const next: EnvSelection = { ...selectionOfSession(sessionId) }
      if (address.length === 0) {
        delete next[slot]
      } else {
        const result = await getCatalog(false)
        const entry = resolveEntry(result.entries, address)
        if (entry === null) {
          return rejected({ code: 'entry-not-found', sessionId, slot, address })
        }
        if (!slotCompatible(slot, entry)) {
          return rejected({ code: 'incompatible', sessionId, slot, address })
        }
        next[slot] = entry
      }
      await setSelectionForSession(sessionId, next)
      return success<EnvselGetValue>({ selection: next })
    },
  }
  // The TypertRemoteService constructor provides the `envsel` service itself;
  // the api gateway resolves it from the live Context on every invocation.
  new EnvselRemoteService(ctx, gatewayHandlers)

  // ── /env command ────────────────────────────────────────────────────────────
  ctx.effect(() => ctx.commands.register({
    name: 'env',
    description: copy.commandDescription,
    input: { hint: copy.commandHint },
    handler: (invocation: CommandInvocation): Promise<CommandResult> => handleEnvLine(invocation),
  }), 'envsel: /env command')

  async function handleEnvLine(invocation: CommandInvocation): Promise<CommandResult> {
    const action = parseEnvLine(invocation.rawInput, locale)
    try {
      switch (action.kind) {
        case 'error':
          return { kind: 'error', text: action.text }
        case 'help':
          return { kind: 'success', text: envHelpText(locale) }
        case 'show': {
          return { kind: 'success', text: renderSelection(selectionOf(invocation.agent)) }
        }
        case 'clear': {
          await setSelection(invocation.agent, {})
          return { kind: 'success', text: copy.cleared }
        }
        case 'wsl': {
          if (!isWindowsHost()) {
            return { kind: 'success', text: copy.wslSkipped }
          }
          const result = await getCatalog(true)
          const wslEntries = result.entries.filter(entry => entry.kind === 'wsl')
          const lines = [
            copy.wslDone(wslEntries.length),
            ...wslEntries.map(entry => `  ${describeEntry(entry)}`),
            ...(wslEntries.length === 0 ? [copy.wslNone] : []),
            ...result.warnings.map(warning => `  ⚠ ${warning}`),
          ]
          return { kind: 'success', text: lines.join('\n') }
        }
        case 'add': {
          const pinned = await pinPath(action.path)
          if (!pinned.ok) {
            const reason = pinned.error.code === 'invalid-path'
              ? copy.pinReasonInvalid
              : pinned.error.code === 'not-found'
                ? copy.pinReasonNotFound
                : copy.pinReasonNoInterpreter
            return { kind: 'error', text: copy.addFailed(action.path, reason) }
          }
          const added = pinned.value.entries.filter(entry => entry.kind === 'custom')
          return {
            kind: 'success',
            text: [
              copy.pinned(pinnedCacheHint()),
              ...added.map(entry => `  ${describeEntry(entry)}`),
            ].join('\n'),
          }
        }
        case 'unpin': {
          const removed = await unpinPath(action.address)
          if (!removed.ok) {
            return { kind: 'error', text: copy.unpinMissing(action.address) }
          }
          return { kind: 'success', text: copy.unpinned(action.address) }
        }
        case 'list': {
          const result = await getCatalog(false)
          const filter = action.filter.toLowerCase()
          const entries = filter.length === 0
            ? result.entries
            : result.entries.filter(entry =>
              entry.name.toLowerCase().includes(filter) || entry.prefix.toLowerCase().includes(filter))
          const lines = [
            copy.listHeader(entries.length, action.filter),
            ...entries.map(entry => `  ${describeEntry(entry)}`),
            ...result.warnings.map(warning => `  ⚠ ${warning}`),
          ]
          return { kind: 'success', text: lines.join('\n') }
        }
        case 'assign': {
          const result = await getCatalog(false)
          const next = copySelection(invocation.agent)
          const applied: string[] = []
          for (const assignment of action.assignments) {
            if (assignment.value.length === 0) {
              delete next[assignment.slot]
              applied.push(`${slotLabel(assignment.slot, locale)} → ${copy.slotUnset}`)
              continue
            }
            const entry = resolveEntry(result.entries, assignment.value)
            if (entry === null) {
              const candidates = result.entries.filter(candidate => candidate.name === assignment.value)
              const hint = candidates.length > 0
                ? copy.slotAmbiguous(candidates.map(describeEntry).join(' | '))
                : copy.slotMissing(assignment.value)
              return { kind: 'error', text: copy.slotSetFailed(slotLabel(assignment.slot, locale), hint) }
            }
            if (!slotCompatible(assignment.slot, entry)) {
              return {
                kind: 'error',
                text: copy.slotIncompatible(slotLabel(assignment.slot, locale), describeEntry(entry)),
              }
            }
            next[assignment.slot] = entry
            applied.push(`${slotLabel(assignment.slot, locale)} → ${entry.name} (${entry.kind})`)
          }
          await setSelection(invocation.agent, next)
          return { kind: 'success', text: `${copy.updated}\n${applied.map(line => `  ${line}`).join('\n')}` }
        }
      }
    } catch (error) {
      return { kind: 'error', text: `envsel: ${error instanceof Error ? error.message : String(error)}` }
    }
  }

  /** Render the current selection as command text. */
  /** Render the current selection as command text. */
  function renderSelection(selection: EnvSelection): string {
    if (isEmptySelection(selection)) {
      return [copy.noneSelected, copy.noneSelectedHint].join('\n')
    }
    const lines = [copy.currentEnv]
    for (const slot of ENV_SLOTS) {
      const entry = selection[slot]
      const label = slotLabel(slot, locale)
      lines.push(entry === undefined
        ? `  ${label} -> ${copy.unsetParen}`
        : `  ${label} -> ${describeEntry(entry)}`)
    }
    lines.push(copy.usageHelp)
    return lines.join('\n')
  }

  // ── DSH_ENV_* shell facts ───────────────────────────────────────────────────
  const DSH_ENV_PYTHON = 'DSH_ENV_PYTHON' as DshEnvironmentKey
  const DSH_ENV_RSCRIPT = 'DSH_ENV_RSCRIPT' as DshEnvironmentKey
  const DSH_ENV_CLI_PREFIX = 'DSH_ENV_CLI_PREFIX' as DshEnvironmentKey

  const contributor: BashEnvContributor = {
    name: 'envsel',
    variables: {
      [DSH_ENV_PYTHON]: { description: 'Absolute python invocation of the session\'s selected Python environment.' },
      [DSH_ENV_RSCRIPT]: { description: 'Absolute Rscript invocation of the session\'s selected R environment.' },
      [DSH_ENV_CLI_PREFIX]: { description: 'Install prefix of the session\'s selected CLI environment (wsl:distro:prefix for WSL).' },
    },
    resolve(execution) {
      const agent = execution?.agent
      if (agent === undefined) return {}
      const selection = selectionOf(agent)
      const out: Partial<Record<DshEnvironmentKey, string>> = {}
      const python = selection.python
      if (python?.pythonCommand !== undefined && python.pythonCommand !== null) {
        out[DSH_ENV_PYTHON] = python.pythonCommand
      }
      const r = selection.r
      if (r?.rscriptCommand !== undefined && r.rscriptCommand !== null) {
        out[DSH_ENV_RSCRIPT] = r.rscriptCommand
      }
      const cli = selection.cli
      if (cli !== undefined) {
        out[DSH_ENV_CLI_PREFIX] = cli.kind === 'wsl'
          ? `wsl:${cli.distro}:${cli.prefix}`
          : cli.prefix
      }
      return out
    },
  }
  ctx.effect(() => ctx.shellEnv.register(contributor), 'envsel: shell facts')

  // ── runtime-context contribution ───────────────────────────────────────────
  // DSH assembles a "Current runtime context" snapshot before every model step.
  // The assembling agent reaches each context provider only from 0.2.0-rc.1 on,
  // which is what makes a per-session selection renderable as text at all. Until
  // then the selection reached the model only as `DSH_ENV_*` shell facts, and a
  // fact stays invisible until a shell call asks for it by name — so a model
  // that simply runs `python script.py` never learns an environment was chosen.
  // This block is the difference between an advisory variable and an
  // instruction the model reads on every turn.
  if (resolved.registerContext) {
    ctx.inject(['systemPrompt'], (promptCtx) => {
      const service = (promptCtx as unknown as { systemPrompt?: SystemPromptHost }).systemPrompt
      if (service === undefined || typeof service.context !== 'function') return
      promptCtx.effect(() => service.context({
        name: PROMPT_CONTEXT_NAME,
        order: PROMPT_CONTEXT_ORDER,
        // An empty selection renders nothing, so a session (or subagent) with
        // no selection adds no block and never churns the durable snapshot.
        text: (context) => {
          const agent = context?.agent
          if (agent === undefined) return ''
          return selectionContext(selectionOfSession(agent.session.header.id))
        },
      }), 'envsel: runtime context')
    })
  }

  // ── session_env model tool ──────────────────────────────────────────────────
  if (resolved.registerTool) {
    ctx.tools.register(defineTool({
      name: SESSION_ENV_TOOL,
      description: 'Manage the environments selected for the current session (Jupyter-kernel-style): per-language slots python/r/cli, each holding one conda, standalone R, WSL, or user-pinned custom entry. action=list enumerates all entries; action=get returns the current selection; action=set assigns one slot (slot required, name="" clears that slot; kind is an optional disambiguation hint); action=pin remembers a host interpreter/install path in the machine-local cache (name = path); action=unpin forgets a cached path (name = custom:<name> or the original path). The current selection is restated in the runtime context of every turn, so no separate query is needed to see it; a session with no selection of its own — a delegated subagent, for example — inherits the nearest selecting session it descends from.',
      parameters: {
        action: { type: 'string', required: true, enum: ['list', 'get', 'set', 'pin', 'unpin'], description: 'Operation to perform.' },
        slot: { type: 'string', enum: ['python', 'r', 'cli'], description: 'Slot to assign for action=set.' },
        kind: { type: 'string', enum: ['conda', 'r', 'wsl', 'custom'], description: 'Entry-kind disambiguation hint for action=set.' },
        name: { type: 'string', description: 'Entry name for action=set (empty clears); host path for action=pin; custom:<name> or path for action=unpin.' },
      },
      output: {
        schema: { type: 'json' },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
      },
      async execute(args, exec) {
        const action = args.action
        if (action === 'list') {
          const result = await getCatalog(false)
          return { entries: [...result.entries], warnings: [...result.warnings] }
        }
        if (action === 'pin') {
          const path = typeof args.name === 'string' ? args.name.trim() : ''
          const pinned = await pinPath(path)
          if (!pinned.ok) {
            throw new Error(`session_env: cannot add path ${JSON.stringify(path)} (${pinned.error.code})`)
          }
          return { entries: [...pinned.value.entries], warnings: [...pinned.value.warnings] }
        }
        if (action === 'unpin') {
          const address = typeof args.name === 'string' ? args.name.trim() : ''
          const removed = await unpinPath(address)
          if (!removed.ok) {
            throw new Error(`session_env: pinned path not found ${JSON.stringify(address)}`)
          }
          return { entries: [...removed.value.entries], warnings: [...removed.value.warnings] }
        }
        if (exec.agent === undefined) throw new Error('session_env requires an owning agent session')
        const agent = exec.agent
        if (action === 'get') return { selection: selectionOf(agent) }
        if (action === 'set') {
          const slot = args.slot as EnvSlot | undefined
          if (slot === undefined || !ENV_SLOTS.includes(slot)) {
            throw new Error(`session_env: unknown slot ${JSON.stringify(slot)} (use python | r | cli)`)
          }
          const name = typeof args.name === 'string' ? args.name.trim() : ''
          const next = copySelection(agent)
          if (name.length === 0) {
            delete next[slot]
          } else {
            const result = await getCatalog(false)
            const kindHint = args.kind
            const entry = typeof kindHint === 'string' && kindHint.length > 0
              ? result.entries.find(candidate => candidate.kind === kindHint && candidate.name === name) ?? null
              : resolveEntry(result.entries, name)
            if (entry === null) {
              throw new Error(`session_env: environment not found ${JSON.stringify(name)} (use /env list or session_env list)`)
            }
            if (!slotCompatible(slot, entry)) {
              throw new Error(`session_env: ${slot} slot cannot use ${describeEntry(entry)} (missing that language's interpreter)`)
            }
            next[slot] = entry
          }
          await setSelection(agent, next)
          return { selection: next }
        }
        throw new Error(`session_env: unknown action ${JSON.stringify(action)}`)
      },
      presentCall: args => ({
        card: 'generic',
        title: 'Session environment',
        kind: 'other',
        rawInput: args.action === 'set' || args.action === 'pin' || args.action === 'unpin'
          ? `${String(args.action)} ${String(args.slot ?? '')} ${String(args.name ?? '')}`.trim()
          : String(args.action),
      }),
    }))
  }
}
