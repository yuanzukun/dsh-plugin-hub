## 0.7.2 — 2026-10-29

又只修 CI，产品代码仍然没动（功能与 0.7.0 / 0.7.1 一致）。

0.7.1 之后 Linux 上还剩一条红：`test/selfupdate.test.mjs` 的「非桌面版（execPath 是 node）不许装」。原因还是平台假设：

- 用例里把 exe 写成 `'C:\\Program Files\\nodejs\\node.exe'`，产品判断是 `path.basename(exe)` 是否等于 `node(\\.exe)?`。
- Windows 上 `path.basename` 认得反斜杠，得到 `node.exe`，于是走进「不是桌面版」分支 —— 测试通过。
- Linux 上反斜杠不是分隔符，basename 就是整串，判不成 node，于是继续往下真的去 spawn `cmd.exe`，报 `spawn cmd.exe ENOENT`。

修法：exe 改成 `'C:/Program Files/nodejs/node.exe'`。正斜杠在两个平台上 `path.basename` 都认得，所以两边都稳定走进「不是桌面版」分支。

回归：`node --test` 全量 **883 passed / 0 failed**；本机 `test/selfupdate.test.mjs` 28/28。

## 0.7.1 — 2026-10-29

只修 CI，产品代码没动。

0.7.0 推上去之后 GitHub Actions 的 Linux 三个 job 红了，Windows job 绿。四条失败全在测试里，是「只在 Windows 上成立」的假设：

1. `test/restrict.test.mjs` 的「own 层能进白名单」：`herDir` 写的是 `'C:\h'`，JS 里其实是 `C:h`（反斜杠被吃掉），而 cwd 写的是 `'C:\\h'`（真值 `C:\h`）。Windows 上 `resolve('C:h')` 恰好归一回 `C:\h`，所以本地一直绿；Linux 上会拼到 cwd 后面，两个路径不相等，`isHerAgent` 判 false，restrict 根本没被调用。现在两边写同一种字面量。
2. `test/selfupdate.test.mjs` 的 profile 反推：用 `pathToFileURL('C:/Users/…')` 造 URL，Linux 上会把盘符当相对路径拼到 cwd 后面。改成字面 `file:///C:/…`，断言时把 `/C:/…` 归一成 `C:/…`。
3. 两个安装用例（「非桌面版不许装」「安装：写好脚本…」）没有显式给 `platform`，`install()` 先查「是不是 Windows」再查「有没有 exe」，Linux 上先撞前一条，拿不到预期的错误。现在显式传 `platform: 'win32'`。

顺手给另外两个自更新用例也补了 `platform: 'win32'`（它们本来不装，补上更明确）。

回归：`node --test` 全量 **883 passed / 0 failed**；另用 `path.posix` 复算了上面两处判据（restrict 的 `normDir` 相等、profileDirOf 归一出 `C:/…`），确认在 Linux 上也会过。

## 0.7.0 — 2026-10-29

**把 0.6.12–0.6.32 这二十一个本地版本合成一次发布。对外只发这一版；下面按主题并成一份，逐版本的细节仍留在 0.6.12–0.6.32 各条目里。**

一句话概括这段时间：请神认得出对话的名字、走的时候会留下交接句；出门能接着上次那趟做、回家能复核被拒收的那趟、能带回一件纪念品、能按趟翻旅行日记；工具面多了一段「手边有什么」；日记从「一篇都没有」修到「一天写两篇也不互相覆盖」；GitHub 自更新第一次有了完整的真机路径。

### 一、请神（临时上身到你在用的那条对话）

- 选择框显示真实对话名（0.6.12）：三层取名——`sessionTitle` 服务 → 折会话自己的 `session/title` 事件 → header 兜底；重名补工作区目录名，没名字写「还没起名字的对话」，不再显示 session id 的尾巴。
- 结束请神会往那条对话里补一条交接句（0.6.13），让下一轮读到自己「已经还回去了」，不再顺着上一句接着演；被请的那条会话 `seq=339` 有请神段、`seq=352` 已无，说明提示词本身撤得干净，残留只在历史里。
- 删掉「临走留一句」输入框（0.6.18）：那个框读起来像她要留话，实际是让你替她写，绕；现在只留标准两句。

### 二、出门（去别的工作区干活）

- 出门页补齐（0.6.16）：状态条与「现在在哪」显示「此刻在外面：<工作区> · 已 N 小时」；请神态补时长与标题；「最近几趟」并进同一张卡；驳回的条目会真的讲给她听；回家那一刻当场拆掉身份段与守卫，不等进程退出；新增「接着上次那趟」。
- 出门时她终于问得出「想带这个回来」（0.6.21）：`bring_back` 与事件写入原来都被「你不在这个家里」这条判据挡死，现在按「这趟出门的会话」放行；身份文件仍拒。
- 纪念品与旅行日记（0.6.17）：一趟最多问 3 次、同时只 1 件等点头；只认这趟工作区里的文件（目录/链接/空文件/超 20MB 都拒）；点头时才复制进 `keepsakes/<日期>/`；日记仍写同一本 `diary/<日期>.md`，只打 `trip:会话@出发时刻`，界面按趟聚合。
- 判据修正（0.6.24）：台账已经绑了会话 id 之后，同一个工作区里**你自己的会话**不再被当成她（原来会被挂身份段与守卫，连 `ops_bash` 都被回「这件事我做不到」）。
- 时间字段（0.6.25）：事件 `ts` 是 ISO 字符串，两处读者按数字比 → `NaN` → 回家审查永远「0 条」、出门页留话永远空；改成统一走 `tsMs()`。
- 幽灵出门（0.6.26）：装配跑在写日志之前，中途抛错会留下一条「在外面」却没有装备的台账；改成先写日志、装配失败强制撤掉并回 500。
- 接回上次那趟（0.6.27）：这版宿主的 `sessionController` 没有 `resume`，改用 `resolveAgent`。
- 复核（0.6.32）：被拒收的那趟原来点完只剩「在家」加一条一闪而过的提示，`pending` 成了单向门；现在「现在在哪」会留一张「上一趟没结算：文件对不上」卡，文件还原后点「复核一次」就能收下，`endedAt` 保留她真正回家的那一刻。

### 三、工具面与白名单

- 「手边有什么」段（0.6.19）：挡不掉的工具至少先让她知道那不是自己的。
- 白名单认 `ops_*`（0.6.20）；own 层工具授权不再只认 `dsh-ops`（0.6.22）：任何插件挂进她自己那一层的工具都能进白名单、都能被守卫放行。

### 四、日记、留话与住处

- 三天零日记（0.6.15）：身份文档只说「每天我会记一笔」，没写用哪个工具；补上 `growth_commit` 与 `type=diary`，并在每天最后一次叫醒时给一句「今天到这里了」，写不写仍由她。
- 排队的话没人投（0.6.23）：`deliverQueued` 写好却没有调用点；她家会话建起来时补投，日志会写「补上了排队的话 N 句」。
- 同一天第二篇日记（0.6.28）：不再整篇覆盖第一篇，改为接在后面；`diary/archive/` 不再新增。
- 解除归档（0.6.29）：把会话从「已归档」放回来之后，插件自己会认回来继续用那条，不再挂着「会话被收起来了」。
- 「她写的小纸条」（0.6.30）：从记忆页的「信箱」搬到住所页，名字、描述与单位都换掉。

### 五、升级与稳定性

- GitHub 自更新（0.6.14）：「检查更新」不再只把人送去 Releases，能直接下载 tag 包、核对包名与版本、备份 profile、替换、失败回滚并重开；开发版（`link:`/`file:` 依赖）明确拒绝自动升级。
- 测试污染真实账本（0.6.31）：全量测试把 20 个临时家写进 `~/.dsh-fish-homes.json`，导致每次真启动都记一条假「家换了」；测试改指临时账本 + 默认账本对临时 root 直接跳过。

### 六、关于「出门」页签

对外发布版仍然**不显示**这个页签：判据是数据目录里的 `.dev` 文件或 `DSH_FISH_DEV=1`（`lib/devmode.js`），`.dev` 不随包发布、也不在 git 里；正式安装读不到 → 页签不渲染（`lib/client.js` 里 `TABS.filter(([id]) => id !== 'outing' || devMode === true)`）。本机那台有 `.dev`，所以自己看得见，这是预期的。

**回归**：全量 `node --test` **883 passed / 0 failed**。版本号、README、CHANGELOG 同步为 0.7.0 / 883。

## 0.6.32 — 2026-10-29

**被拒收的那趟成了死路：点完「这趟收下」什么也看不到，也不给复核的机会。**

用户 2026-10-29 真机（m03885 之前）：用 `events.jsonl` 截短造了一次篡改，点「这趟收下」后 —— 页面回到「在家」，`outingMsg` 一闪而过，台账里那趟 `status=pending`、`kept=null`，之后再点「收下」只会得到 409「她没在外面」。人和文件都还在，却没有一条路能把它结掉。

- 根因：`pending` 之后这趟不再是 `active`，`awayNow()` 返回 `null`，于是「现在在哪」整块审查卡消失；原因与复核入口只写在点击瞬间的提示里，一刷新就没了。`endOuting` 又没有反向操作，`pending` 是单向门。
- 修法一（台账）：`lib/outing.js` 新增 `pendingOf()` 与 `settlePending()`——复核通过时只改 `status/kept`，`endedAt` 保留她真正回家的那一刻，不复写成复核时间。
- 修法二（接口）：`GET /outing` 多回 `pendingReview`（工作区、会话短号、当时的失败原因、现在是否已经能对上）；`POST /outing {action:'review'}` 当场重算 `verifyEvents`：还对不上就 409 并说原因，对上了就收下并写一行日志。
- 修法三（界面与文案）：新增「上一趟没结算：文件对不上」卡，列出原因与两个动作状态（「复核一次」在文件没还原前是灰的，旁边写「还没还原」）；台账状态词由「等确认」改成「等复核」；把「她留在外面等你确认」改成事实——她本人照样回家、装备照拆，只是这趟等着复核。
- 顺带修正一处读口径：`readOutings()` 原来把 `kept: null` 读成 `false`；`null` 是「还没结算」，`false` 是「这趟不算数」，两者不能混。
- 回归三条：库层「等复核的那趟：能找出来、复核通过就收下，结束时间不重写」；源码级「GET 带回 pendingReview，POST action=review 通过后收下」；**接口层**新增 `test/outing-route.test.mjs`——用假 ctx/req/res 真调用注册出来的 `/dsh-fish/outing`，把「出门中 → 截短 → 收下变 pending → 核对原因 → 未还原复核被拒且台账不动 → 还原后复核变 done → 再点 409」整条走一遍，顺带钉住「没挂装备会给出 warning」。全量 883。

## 0.6.31 — 2026-10-29

**每次启动都记一条假「家换了」：测试把临时家写进了真实家谱。**

日志体检发现的（不是用户报的 bug）：`logs/dsh-fish.log` 里 13 条 `家换了：C:\Users\DANG\AppData\Local\Temp\fish-boot-XXXX → C:\Users\DANG\.dsh-fish`，每次真启动一条；`~/.dsh-fish-homes.json` 的 `homes` 里塞了 20 个 `Temp\fish-boot-*`，`lastAt` 全落在跑 `node --test` 的时刻。

- 根因：`test/boot.test.mjs` 的 `withRoot()` 用 `mkdtemp` 造临时 root 后直接 `apply(ctx, {root})`；`apply` 里的 `noteRoot(root)` 写的是**默认账本**（`lib/homes.js` 的 `homesFile()` 只在 `DSH_FISH_HOMES` 存在时才改道），测试没设这个 env。
- 于是每次全量测试都往真实账本灌 20 条临时家；之后每次真启动都拿最后一条临时家当「上次的家」→ 假 warn + 往她的事件流里写假 `meta`。
- 修法两道：① `test/boot.test.mjs` 的 `withRoot()` 把 `DSH_FISH_HOMES` 指到临时账本，`finally` 还原；② `lib/homes.js` 加防线——**默认账本 + 临时目录里的 root** 直接跳过（返回 `{ok:true, skipped:'temp'}`），测试传自定义 `file` 或用显式 env 时不受影响。
- 清理：`~/.dsh-fish-homes.json` 里 19 条 `Temp\fish-boot-*` 删掉（原文件备份为 `.dsh-fish-homes.json.bak-20261029`），只留真实那一间。
- `events.jsonl` 里已写进去的假 `meta` 不动（append-only，且 `derive` 不认这种类型）。
- 回归：新增「临时目录里的家不写进真实家谱」，全量 879。

## 0.6.30 — 2026-10-29

**「她写的小纸条」原来在记忆页、叫「信箱」；现在搬到住所页（日记下面、自检上面），名字和描述也换了。**

用户 m02105：把记忆页的「信箱」改名成「她写的小纸条」，描述改成「特意留给你的话。某种意义上代表她当前的状态，可能含有关键信息。」，整张卡挪到住所页，放在日记下面。

- 卡片从记忆页整段搬走，标题 `groupFull('她写的小纸条'`，计数单位由「封」改成「张」；未读角标、「都看过了」、前 20 条、末尾 `~/.dsh-fish/inbox.md` 提示都照旧。
- 住所页的顺序是「日记 → 她写的小纸条 → 本插件工作自检」；卡先定义成 `inboxCard` 常量再摆进去，省得多层嵌套的括号出错。
- 页签说明同步：住所改成「住在哪：工作区、会话、身份文件、日记、她留下的小纸条，以及一键自检。」；记忆页去掉「还有信箱」。
- 回归 878（`test/client.test.mjs` 的位置断言改为「日记 < inboxCard < 自检」，老描述句换成新描述句）。

## 0.6.29 — 2026-10-29

**把会话从「已归档」里放回来了，插件却不认：设置页还挂着一句「会话被收起来了」，她也不接管那条对话。**

用户 m03508 问「我现在已经把会话归档了，我直接解除归档就可以恢复吗」，同时问「重新搭一间和重置大肥鱼是不是功能重复」。

- **0.6.8 的判定太死**：`ensureTalkSession` 只看 `home.json` 里的 `status:'archived'`，命中就返回 archived，**不看宿主那边是不是已经把她放回来了**。而全库没有一处会在「解除归档」后清掉这个标记（只有「重新搭一间」整份重写 `home.json` 时顺带清掉）。于是解除归档 = 会话回到侧栏，但插件仍然当她被收起来，永远要用户点「重新搭一间」。
- **改法**：命中 archived 标记时先问宿主一句——这条会话现在在 `ws.sessionIds` 里、且不在 `archivedSessionIds` 里，就当场清掉 `status`/`archivedAt` 并走正常复用（原来那条，不新开）；只要宿主还说她在归档里，就继续不重开、等用户点「重新搭一间」——「我收起来了」这句话不能被插件自己推翻。
- **文案互补**（用户要求写清两者区别）：
  - 「会话被收起来了」卡补一句「如果你只是把侧栏里的归档取消了，那不用点这里：下一次叫醒（或重启）就会自己认回来（0.6.29 起）」。
  - 「重置大肥鱼」卡开头点明「这跟上面那张『重新搭一间』不是一回事：那个只换一条对话，数据一条不动；这个是真的重开一局」。
- 默认可见性不变：没归档时只有「重置大肥鱼」；归档之后才多出「重新搭一间」。
- **回归**：`test/home.test.mjs` 新增「用户把会话解除归档了：插件要当场认回来，而不是一直等她点『重新搭一间』」（归档 → 解除归档 → 复用原来那条、`homeStatus().status` 为空、没有多建会话）；该文件 23/23。全量 `node --test`：**878 passed / 0 failed**。

## 0.6.28 — 2026-10-29

**同一天写第二篇日记，第一篇被整篇盖掉；界面上也看不到翻页键。**

用户 m01952 选的方案：「同日追加成一篇（推荐），并且确认多篇的时候会出现翻页键」。

- **现状**：0.6.4 为 issue #7 做的是「覆盖前把旧稿归档到 `diary/archive/`」，但归档版界面上不显示——用户看到的就是「之前那篇没了」。而且同一天只有一篇，翻页键本来就不该出现，两件事叠在一起，看起来像「多篇被盖 + 翻页坏了」。
- **改成同日追加**：同一天再写一次不再覆盖，而是在当天文件末尾接一段，中间一行 `---` 隔开；旧稿原样留在正文里，不用再去 archive 找。内容与最后一版完全一样时不追加（重写同一篇仍然幂等）。
- **「一天一篇」的语义不变**：客户端按日期翻页，`listDiary` 只认顶层 `YYYY-MM-DD.md`；**跨天**才有第二个日期、才出现「← 更早 / 更晚 →」，同一天的几段合成同一页。
- **老归档不清**：`diary/archive/` 里 0.6.4–0.6.27 留下的历史稿原地保留，只是新写入不再产生归档。
- **顺带修她自己回头翻的截断方向**：合并后超过 3000 字时改为留**最后一段**——原来从头截，晚上补的那段会被切掉，等于「刚写的自己读不到」；提示也改成「当天写了好几段，这里只留了最后 3000 字」。
- 报告（`out/`）仍然整篇覆盖：它是派生品，随时能由事件流重算。
- **回归**：`test/dailylog.test.mjs` 重写为追加语义（两段顺序、三段、幂等、跨天两个日期、out 仍覆盖、旧 archive 可读）；`test/herdiary.test.mjs` 加「太长时留最后一段」；`test/client.test.mjs` 加「日期 ≥ 2 才出翻页键、两个按钮与禁用状态都对」。全量 `node --test`：**877 passed / 0 failed**。

## 0.6.27 — 2026-10-29

**勾「接着上次那趟」出门，直接报错 `宿主没有 sessionController.resume，接不回上次那条会话`——这版宿主的 `sessionController` 根本没有 `resume` 这个方法。**

用户 m03372 真机反馈：「操作了，显示派活失败：HTTP 500，并且还在家」。插件日志连续三次（05:44:56 / 05:45:04 / 05:45:34）都是两行连着：

```
[info] 出门： deepseekagent （接回第 3 趟） D:\deepseekagent
[warn] 出门：装配失败，已经把这趟撤掉了 宿主没有 sessionController.resume，接不回上次那条会话
```

- **0.6.26 的收口是对的**：每次失败都把台账那趟撤掉了，所以人「还在家」、不留幽灵记录。错的是入口。
- **根因**：`sessionController` 是带 `@Remote` 装饰的服务，对外暴露的只有 `list / search / create / selectModel / modelCatalog / rename / fork / prompt / attachment / updateQueue / cancel / page / follow / projections / control`——**没有 `resume`**。恢复一条已经跑过的会话要用 `resolveAgent(sessionId)`：它内部 `resolve → resume`，把并发恢复去重，返回 `{ agent }` 或 `{ error }`。
- **为什么 0.6.26 没测出来**：`create({ sessionId })` 只复用**空白**会话（跑过一轮 turn 就会静默新开一条），所以复用必须走「恢复」；而恢复入口只在一台真机上点下去才会暴露，`873` 条单测没有一条能替它。
- **修法**：新增 `resolveSessionAgent(sc, sessionId)`——优先 `sc.resolveAgent`，退到 `sc.agents.resolveAgent`；拿到 `{ error }` 原样抛（上层按 0.6.26 的收口撤掉这趟），没交出 agent 也明确抛；两个入口都没有时说清「宿主没有 sessionController.resolveAgent」，而不是 `undefined is not a function`。复用分支改成调它，恢复后再按需补挂身份段与兜底守卫。
- **回归**：`test/outing.test.mjs` 加 1 条——`{ agent }` 正常返回、`{ error }` 原样抛、只挂在 `sc.agents` 上也能接、一个入口都没有要报 `resolveAgent`、源码里不再出现 `sc.resume(`。
- 全量 `node --test`：**873 passed / 0 failed**。

## 0.6.26 — 2026-10-29

**「接着上次那趟」在真机上接回了同一条会话，但成功得看不出来：日志里没有那一行，界面也没写清是哪个工作区的那条对话。查下去发现装配那一段跑在写日志之前——中途任何一步抛错，台账里会留下一条「在外面」，可身份段与守卫一段都没挂上。**

用户 m03194 真机反馈两点：勾了复用出门，但日志里没看到「（接回上次那趟）」；界面也没写清她现在在哪条对话里。

- **查到的**：`outings.json` 里连续两趟用的是同一个 `sessionId`（21:14:33 结束的那趟、21:33:48 开始的这趟），所以复用**确实接回了同一条会话**；但这一趟既没有出门日志、也没有装备挂载记录，属于「幽灵出门」——台账说在外面，实际没挂上。
- **根因**：`/outing` POST start 里，`logLine('info', ['出门：' …])` 排在 `attachIdentity`／`attachAwayGuard`／`sc.resume`／首轮 `sc.prompt` 之后；中间只要抛一次，异常直接冒到路由外层，台账已经写盘、日志一行没留。
- **修法**：①先写「出门：（接回第 N 趟）」再装配；②整段装配包 try/catch，失败时 `detachOutside` + `abortOuting(root, { force: true })`（新增 force：允许撤掉已经绑了会话的那条）+ 写一行 warn，回 500，不留幽灵记录；③装配完再写一行「出门：装配完成 … 装备挂上了／装备一段都没挂上」。
- **界面**：出门页「现在在哪」现在写「在「<工作区>」那条对话里（名字：…）· 会话 <短号> · 第 N 趟」，没挂上装备时红字直说；「送她出门」的复用勾选框旁显示上次的日期与会话短号。
- **接口**：`/outing` GET 的 `away` 多了 `sessionId/sessionShort/sessionTitle/tripNo/equipped/warning`；POST start 回包多了 `tripNo`、`equipped`。
- **回归**：`test/outing.test.mjs` 加 3 条（趟次口径、force 撤掉带会话的那趟、start 的日志顺序与异常收口）。

## 0.6.25 — 2026-10-29

**她写了 `growth_commit`，回家审查还是「这趟多出 0 条」——因为事件的时间字段是 ISO 字符串，两处读者却按数字比，`Number("2026-10-29T…")` 是 NaN，比较恒为假。她的东西一条都进不来。**

用户 m03011 真机反馈：她发了事件编号 `ev_01M625WYHEECKM2YEGVZNC2232`（那一刻她写下的正文也在），早上出门那会儿还写过一条日记，可回家审查卡仍是 0 条。

- **根因**：`lib/schema.js` 的 `validateEvent` 把 `ts` 写成 `new Date(now).toISOString()`；而 `lib/outing.js` 的 `eventsSince` 用 `Number(ev.ts) >= at` 做时间筛，`lib/letter.js` 的 `lettersSince` 同样是 `Number(e.ts)`。ISO 字符串转数字恒为 `NaN`，任何比较都是 `false` → 真实事件流里的条目一条都筛不进来。测试夹具一直用数值 ts（`1_000`、`1_100`），所以这个坑在 800 多条测试里也没照出来。
- **修法**：`lib/schema.js` 新增 `tsMs(ev)`——数值直接认、ISO 字符串 `Date.parse`、坏值给 0，永不抛；`eventsSince` 与 `lettersSince` 全部改走它，输出统一回毫秒（UI 排序与「已 N 分钟」才对得上）。
- **影响面**：回家审查清单（一直是 0 条）、出门页「这趟她留给你的话」（一直是空的）。其它按 `Date.parse(e.ts)` 读时间的模块本来就对，不动。
- **回归**：`test/review.test.mjs` 加 2 条（ISO 事件要进清单、`tsMs` 三态）；`test/letter.test.mjs` 加 1 条（ISO 留话要算数）。全量 `node --test` 866 条基线 + 这 3 条。

## 0.6.24 — 2026-10-29

**「这趟多出 0 条，取消勾选要留下的那条」——没有可勾的条目，是因为这一趟她的事件流里真的什么都没写；只跟你说话不算事件。顺便修了一个更要紧的：同一个工作区里，你自己的会话也被当成了她。**

用户 m02937 真机反馈：回家审查卡写着「这趟多出 0 条。默认全收下；不想留下的那条取消勾选」，但清单里一条都没有，无从取消。核对代码：清单来自 `eventsSince(events.jsonl, outing.startedAt)`，只统计**她自己事件流**在出门之后新增的条目；聊天、读文件、跑命令都不写这条流。她这趟没有调用过 `growth_commit` / `her_leave` / `bili_speak` / 写日记，所以是 0 条——空清单不是 bug，是一句话没说清。

- **空清单时说人话**（`lib/client.js`）：0 条时改成「这趟她自己的事件流里没有新增，所以没有可以取消勾选的条目——只跟你说话不算事件。想验驳回，在那条出门会话里让她用 growth_commit 写一条（或留话、写日记、评视频），回家这里才会冒出那一行。」；口袋那趟的说明保持不变。
- **「同一个工作区里别的会话也算她」的漏洞**（`lib/identity.js`）：`registerIdentity` 原来只要 cwd 等于出门工作区，就给这条会话挂她的身份段与兜底守卫；台账一旦绑了会话 id，这个判据就该退场。真机上直接踩到——用户在这个工作区开的主会话也被挂上她的身份与守卫，连自己的记忆文件都读不了（`memory_note` 被「这件事我做不到。」挡回）。现在：**两边都有 id 却不相等时，cwd 不算数**；只有「台账还没绑 id」或「宿主这次没给 id」才靠 cwd 兜底。
- **回归**：`test/away.test.mjs` 新增「台账已经绑了会话 id 时，同一个工作区里别的会话不该被当成她」——同一工作区两条会话，只有台账里那条挂身份与守卫，另一条一段都不挂。全量 `node --test` **866 tests / pass 866 / fail 0**。
- 只落本地：未提交、未推 GitHub、未发 npm（0.6.12–0.6.24 都还在本地队列里）。

## 0.6.23 — 2026-10-29

**回家被驳回的那句话，原来永远不会送到她手里——`deliverQueued` 写好了，却没有人调用它。**

0.6.16 做驳回话术时留了一条兜底路：结算那一刻她家那条会话要是没开着，先把「这趟里我不认这几条……」排进 `session-notes.json`，等她家会话下次起来再补进去。排队写好了，补投也写好了（`lib/sessionnote.js` 的 `deliverQueued`），但全库 grep 只有定义、没有调用点——排队的句子会一直躺在文件里，她永远不知道哪几条不算数。这不是文案问题，是那句「回来再跟你说」根本没兑现。

- **`lib/identity.js`**：`registerIdentity` 的 `agent/created` 钩子里，认出「这是她家那条会话」之后调一次 `deliverQueued(agent, root)`，补上了就记一行日志（`补上了排队的话 N 句`）。异步、失败吞掉——补投是锦上添花，不能连累身份段挂载。
- **回归**：新增 `test/sessionnote.test.mjs` 7 条——写事件形状与 `surfaceOp`、空白与无会话不抛、排队取走即清空、最多留 50 句、`deliverQueued` 补投并清空、以及行为级的一条：`registerIdentity` 在她家会话 `agent/created` 时真的把排队的话补进会话；最后再加一条源码断言，防止 `deliverQueued` 再变回死代码。全量 `node --test` **865 tests / pass 865 / fail 0**。
- 顺带：真机核对脚本 `04-小工具/check-diary.mjs` 的「家里写的日记不带 trip 标记」由 FAIL 改为 SKIP（家里当天还没写日记时不该判失败），结论行现在带 PASS/FAIL/SKIP 计数。
- 只落本地：未提交、未推 GitHub、未发 npm（0.6.12–0.6.23 都还在本地队列里）。

## 0.6.22 — 2026-10-29

**「收窄挡不住的 own 层工具」这事不再只认 dsh-ops：任何插件挂进她自己那一层的工具，都能存进白名单、都能被守卫放行。**

用户 m01685：「如果有用户也想要给这种性质的工具授权白名单，并且不是 ops 这个插件提供的工具，那也应该能够保存成功」。0.6.20 只把 `ops_*` 这种前缀当成了症状，但症状的成因与插件名无关——凡是**注册在她自己那一层**（`tools.view(agent).visible` 里有、`restrictableNames` 里没有）的工具都一样：`restrict()` 点不了名，白名单不该因此判它不存在。

- **名字快照改成现取**：`knownToolNames()` 每次被问都从最近那个 agent 现取一次 `view(agent)`，不再只信 `agent/created` 那一刻的快照。dsh-ops 是 attach 时才 `publish()`，别的插件也可能在建会话之后才补工具——旧实现在那种情况下会一直把它们判成「名字不存在」，用户根本存不进去。
- **快照跨 agent 累积、只增不减**：同一个进程里有她的家、别的工作区、子 agent，各自的 own 层不同；`rememberKnownTools()` 现在是真正的复位（连 agent 一起忘掉），除此之外名单不会因为某次 view 变小而缩水。
- **own 层名单同样累积**：`ownLayerNames()` 返回见过的全部 `visible − restrictable`，设置页的「收窄挡不住它」提示不会再因为切换 agent 而时有时无。
- **下刀时也记一笔**：`restrict()` 之前算桶的那次 view 顺手写进快照，保证「这一刀认得的名字」和「白名单认的名字」是同一份。
- **文案去掉插件名**：设置页静态说明改成「有些工具是插件按会话注册进她自己那一层的（`ops_*`、`team_*` 之类）」，保存回执里也只说「插件把她自己的工具注册进她那一层」。
- **回归**：`test/restrict.test.mjs` 新增 2 条——①非 `ops_` 前缀的 own 层工具（`team_task_list`、`helper_paint`）同样能存、能放行、不下给 restrict；②插件在她建好之后才注册的工具，不重启也能被认出来。全量 `node --test` **858 tests / pass 858 / fail 0**。
- 边界不变：这不是物理隔离——own 层的 schema 仍在上下文里，白名单只是「守卫放行 + 提示词里算她的」。

## 0.6.21 — 2026-10-29

**出门时她终于能把「想带这个回来」问出口，也能把这一趟写进自己的事件流——原来这两件事都被「你不在这个家里」挡死了。**

用户 m02517 真机反馈：出门页「现在在哪」一直没冒出「她想带这个回来：<路径>（N KB）」，她明明挑了 `避坑指南.md`，回执却是「bring_back 看了一眼就说：这条调用来自 D:\deepseekagent 这个家，不是 C:\Users\DANG\.dsh-fish……这次没有落盘」。

根因只有一条：`lib/keep.js` 的 `bring_back` 在写入前调了 `guardWrite`，而 `lib/tenant.js` 的 `checkCaller` 要求调用者的 cwd 在 `root`（或 `root/her`）里——出门会话的 cwd 天生就是**别人的工作区**，于是这个工具在唯一该起作用的场合 100% 被拒。不是配置错，是判据选错了对象：把「能不能写她家」当成了「她是不是在外面」。

同一条根因下还埋着更大的问题：`growth_commit`（`lib/capture.js`）、`her_leave`（`lib/letter.js`）、`bili_speak`（`lib/speak.js`）全部走 `guardWrite`——也就是说，出门期间她**写不了任何事件**：回家审查列表永远是空的，旅行日记（`diary` 走 `growth_commit`）永远写不出来，她也没法在外面留话。

- **`lib/keep.js`**：改成先看 `deps.tenant?.tenant?.ok === false`（家被别人占着仍拒），再用 `callerOf(exec)` 取 sessionId，与 `outings.json` 里 active 那趟比对；对上了才 `askKeepsake`。回执与日志不变。
- **`lib/tenant.js`**：`checkCaller` 增加 `outsideOk`（默认 true）判据——「这条会话正是当前那趟出门的会话」时放行写事件，返回 `{ ok:true, outside:true }`；判据不是 cwd，而是台账里的 active `sessionId`，所以两窝鱼互写仍然被拒。
- **`lib/selfdoc.js`**：身份文件那条调用显式传 `outsideOk:false`——她出门时能写回事件，但改不了自己的身份。
- **回归**：`test/keepsake.test.mjs` 新增「出门会话的 cwd 在别人家也不该被『另一个家』挡掉」；`test/tenant.test.mjs` 新增「出门那条会话写事件放行（`outside:true`）／身份文件不放行／别人的会话仍拒」。全量 `node --test` **856 tests / pass 856 / fail 0**。
- 只落本地：未提交、未推 GitHub、未发 npm（0.6.12–0.6.21 都还在本地队列里）。

## 0.6.20 — 2026-10-29

**白名单终于能写下 `ops_*` 了：认得它的名字、能存、能让守卫放行——但收窄那一步不会拿它去冒险。**

用户 m01493 真机反馈：想放行 dsh-ops 的 `ops_bash`，输入框一直说「名字不存在」，存不进去。根子在两处对不上：

- 白名单校验读的是 `restrictableNames`（能被 `tools.restrict()` 点名的工具），而 dsh-ops 把 `ops_*` 注册进 **agent 自身作用域** —— 它出现在 `tools.view(agent).visible` 里，却不在可收窄名册里（宿主对 own 层不过 `admits`、也不加入 `restrictableNames`，见 Discussion #11373）。
- 就算硬把这个名字塞进 `allow`，`restrict()` 会抛 `names unknown global tool`，整段收窄失效、只剩守卫兜底 —— 比不收窄还糟。

- **`lib/restrict.js`**：新增 `rememberFromView(view)`，把 `restrictableNames ∪ visible` 并成「认得的名字」（单调不缩），同时记下 `ownLayerNow = visible − restrictable`；新增 `ownLayerNames()` 读这份 own 层名单；`rememberKnownTools()` 复位时一并清空。
- **分三桶下发**：`allow` 是配置全量（给守卫与提示词），`allowForRestrict = allow ∩ restrictable` 才下给 `restrict()`，`missing = allow − restrictable − visible` 才走延后重试。老宿主没有 `visible` 时整段退回旧行为，不会因为升级插件把收窄搞坏。
- **守卫按全量放行**：白名单里写 `ops_bash`，`guards[0]({name:'ops_bash'})` 返回 `undefined`（放行）；写 `web_search` 仍然回「这件事我做不到。」。
- **`/tools` 多返回 `ownLayer`**：客户端拿它解释「这类工具她本来就看得见、收窄挡不住，加进白名单只是让守卫放行它」，保存成功的回执里会点名是哪几个。
- **设置页文案**：静态说明改写为「名字必须和宿主里的完全一致：拼错的不让保存。带 `ops_` 这类由别的插件按会话注册的工具，她本来就看得见、收窄也挡不住 —— 加进来只是让兜底守卫放行它。」`saveTools()` 改成每次保存都问一次 `/tools`（原来只在名单为空时问，加了新插件要刷新页面才认）。
- **回归**：`test/restrict.test.mjs` 新增 3 条（own 层能进白名单但不塞给 restrict、`rememberFromView` 并集与 own 层、只写 own 层名字时不延后也不失败），`test/p5.test.mjs` 新增 1 条真路由用例（`/tools` 带 `ownLayer`、`/config` 收下 `ops_bash`）。全量 `node --test` **854 tests / pass 854 / fail 0**。
- 只说清边界：收窄挡不住 own 层，这是宿主行为；这次做的是「让她能放进白名单、守卫放行、提示词里照实说」，不是物理隔离。
- 只落本地：未提交、未推 GitHub、未发 npm（0.6.12–0.6.20 都还在本地队列里）。

## 0.6.19 — 2026-10-29

**提示词里多一段「手边有什么」：挡不掉的那些工具，至少让她不把它们当成自己的。**

用户 m01276 拍板：不再按插件一个个做适配（"要是我有一堆需要限制的插件，岂不是需要根据每个插件做适配"），等上游和插件作者回复；先把提示词与兜底守卫这一层做扎实——工具定义确实进了上下文，但可以让她认定"只有这几样是我的"，越界由守卫回一句「这件事我做不到」，白名单放行的跟着念给她。

为什么光有 `restrict`/guard 不够（已核实）：宿主 `tools.view()` 对**注册在 agent 自身作用域**的工具不过 `admits`、也不进 `restrictableNames`，`restrict()` 点不了它们的名 —— dsh-ops 的 `ops_bash`/`ops_discover_tools` 就是这样照样出现在她的工具表里（实测她那条会话 9 个工具里就带着这两个），schema 里有名字，模型就会倾向于当成"我能用"。

- **新段 `fish:tools`（`lib/identity.js`，order 8600）**：走 `agent.ctx.systemPrompt.section()`，system 角色、不进对话历史、界面上看不到；`text` 是函数，白名单变了下一轮就生效，不用重建会话。
- **正文由 `lib/restrict.js` 的 `toolSurfaceText()` 生成**：逐条点名"真正放行的这几样"；点名说清带 `ops_`、`team_`、`subagent`、`workflow`、`skill` 那些"不是我的，别去调，也别把它们说成我会的事"；并预告越界的回答就是「这件事我做不到」（与 guard 同一句）；问到时按这几样说，没有就说没有，不许诺。刻意不用「权限/禁止/违规」这类系统词——她该以为是自己做不到。
- **跟着白名单走**：`registerToolRestrict` 每次算完 `allow`（`HER_TOOLS` + 设置页额外放行）就刷新这段文本；收窄整个关掉时这段为空 —— 不能一边放开、一边还告诉她"只有这几样"。
- **没动的地方**：guard 仍是同一条「这件事我做不到。」；restrict 的名册与重试逻辑不变；出门时这段随身份段一起挂、一起拆（`detachOutside` 的计数从 3 变 4）。
- **回归**：`test/restrict.test.mjs` 新增 3 条（逐一点名与话术一致、默认清单 / 收窄关掉时为空、额外放行会进提示词），`test/identity.test.mjs` 与 `test/away.test.mjs` 的段数断言从 2→3、3→4。全量 `node --test` **850 tests / pass 850 / fail 0**。
- 只落本地：未提交、未推 GitHub、未发 npm（0.6.12–0.6.19 都还在本地队列里）。

## 0.6.18 — 2026-10-29

**删掉请神结束时的「临走留一句」输入框：那个框读起来像她要留话，其实是让你替她写字。**

用户 m02381 看到真机验证清单里「在请神卡的『临走留一句（可不写）』里写一句」这条，问「是不是我给她说一句，不是她给我说？」——正是这个框的问题：它由用户填，内容会被写成被请神那条对话里的一条用户消息，形如「（大肥鱼回去了。临走留了一句：…）」。语义太绕，写出来像她临走遗言，实际作用只是给下一轮模型一个「已经还回来了」的锚。

- **整块删掉**：`lib/client.js` 里 `possessFarewell` 状态、输入框、「结束请神」时的 `farewell` 参数全部移除；`lib/possess.js` 的 `releaseNoteText()` / `appendReleaseNote()` / `releasePossession()` 都不再收 `farewell`；`lib/observe.js` 的 `/possession` end 分支不再读 `b.farewell`。
- **保留的交接句**（写进那条对话，正常可见）：两行固定文本——「（大肥鱼回去了，这条对话还给你。）」「请神期间她说过的话仍留在上面的历史里；想完全干净，开一条新对话最稳。」
- **回归**：`test/possess.test.mjs` 的交接句用例改为断言标准文本，路由用例改为断言源码里不再出现 `farewell` / `possessFarewell` / 「临走留一句」。
- 只落本地：未提交、未推 GitHub、未发 npm（0.6.12–0.6.18 都还在本地队列里）。

## 0.6.17 — 2026-10-29

**纪念品与旅行日记：她能从外面带一件东西回来（要你点头），出门写的日记能按趟翻。**

用户 m02041 / m02045 拍板：纪念品「她自己决定带，但是需要用户批准」；旅行日记「照常写 `diary/`，打上趟次标记，界面按趟聚合」。

- **纪念品（`bring_back` + `lib/keepsake.js`）**：她在外面看上一件东西，只能「问」——`bring_back` 记一条 `asked`，不动任何文件。出门页「现在在哪」里出现「她想带这个回来：<相对路径>（大小）」，看得到为什么，点「准了」才真的复制进 `~/.dsh-fish/keepsakes/<日期>/`；点「算了」标记 `declined`，什么都不动。四条硬边界写死在代码里：只认**这一次出门那个工作区里的文件**（归一化路径判前缀，`..` 跑不出去）、只认文件（目录/链接/空文件都不行）、单个 ≤ 20MB、一趟最多问 3 次且同时只能有 1 件待点头。点头那一刻会**再核一次**（还在不在、还是不是文件、有没有变大），不在就不带并记下原因。
- **旅行日记（`capture.js` + `/outing`）**：日记本体仍写进同一个 `diary/YYYY-MM-DD.md`，只在 meta 上多打一个 `trip:会话@出发时刻` 标记——只有「进行中的出门会话」才打，家里写的不打。出门页把每一趟的「日记 N 篇」和「带回来 M 件」列在「最近几趟」里，不另建 `diary/trips/`。
- **没有动的地方**：篡改检测仍是「总长度 + 尾 4096 字节 sha256」三态（用户选择先不升级，盲区已写在方案 §9）；递话不改道（用户原话「大肥鱼如果不在家，家里说的话，她就应该收不到才对」）；请神工具面不收窄。
- 新增回归：`test/keepsake.test.mjs` 8 条（会话匹配 / 越界与目录与空文件 / 20MB 上限 / 一趟 3 次与单件待点头 / 点头才复制且原文件不动 / 点头时文件没了 / 台账按趟分开 / 工具参数与回执），`test/capture.test.mjs` 加 1 条（出门那篇带趟次标记、家里那篇不带）。全量 `node --test` **847 tests / pass 847 / fail 0**。
- 只落本地：未提交、未推 GitHub、未发 npm（0.6.12–0.6.17 都还在本地队列里）。

## 0.6.16 — 2026-10-29

**出门页签补齐：能接着上次那趟做，回家那一刻真的把装备拆掉，不认的那几条会说给她听。**

这一版把「出门」从「能出去、能回来」补成「出去这件事有始有终」（用户 m01613 拍板、m01677 追加）：

- **一条会话什么时候算她的**（先定规则再改代码）：只有当 `outings.json` 里有一条 `status: 'active'` 的出门记录指向这条会话时，它才算她的；回家那一刻当场拆掉挂在上面的身份段、处境段和兜底守卫（`detachOutside`），不再等进程退出；DSH 重启后没有 active 记录，它只是一条普通会话；她自己的家会话永远算她的。
- **接着上次那趟做**（`lastOutingForCwd` + 宿主 `sessionController.resume`）：送她出门卡多一个勾选框，勾上就回到同一工作区上次那条会话里。这里踩过宿主的坑——`create({ sessionId })` **只复用空白会话**（`reusable && !events.some(e => e.type === 'turn/start')`），已经跑过一轮的会话传 sessionId 进去会静默新开一条；所以接回走 `resume(sessionId)`，宿主没有 `resume` 时如实拒绝，不假装接上了。
- **不认的那几条，讲给她听**（`rejectNoteText` + `sessionnote`）：回家审查里没勾的条目，结束这趟时把**原文**整理成一段话说给她——「这趟里我不认这几条：…它们不算你，别的算。这不是说你这趟白去了，是那几句我不收。」她在线就直接写进她家那条会话（合法 `user/message` + `surfaceOp: 'append'`），不在线就排队（`session-notes.json`，最多 50 条），下次她家会话起来补投。这是设计文档 §3.7 一直没做的那件事。
- **「此刻在外面」看得见**：`/status` 回包多一个 `away: { kind, since, line, tripDays }`，首页状态条直接多一行「此刻在外面：素材盘 · 已 3 小时 / 此刻在替人说话：修 bug · 已 12 分钟」；请神那一行加粗，并在后面标「（这条对话此刻是她）」——请神视觉标识。
- **请神态说清楚**：「现在在哪」里请神时显示标题 + 时长，出门时显示「这趟已经第 N 天」（想念天数，按整天算，不四舍五入）。
- **「最近几趟」并进「现在在哪」**：同一份台账（`outings.slice(-20)`，前端本来只画 6 条），不再单独占一张卡。
- **出门口袋独立成模块**（`lib/pocket.js`）：`pocketDirPath` / `ensurePocket` 从 `lib/observe.js` 搬出来，能单独测；插件源码的风险提示并进「出门口袋」卡的说明里（「别把她送到有插件源码的工作区——她在那边能读到自己不该看的文件，只是想让她去干活，用口袋最稳」），不再只在选中源码工作区时出现。
- **请神卡那句错误文案改了**：原文写「请神期间那条对话的工具面对你也不可用」——不符合实现（请神不收窄工具面，只挂守卫）。现在是「这段时间那条对话的守卫分不出谁在说话，会连你一起拦；它也不再是原来的那个人。只能由你结束。」
- **留话**：`lettersSince` 认出她这趟留下的 `utterance`，出门期间「现在在哪」会列出「这趟她留给你的话」。
- **清掉 `/outing` 的死字段**：`possessionEnabled: false` 与 `possessionWhy`（0.6.3 的旧话，客户端早就不读）已删除，接口不再说假话。
- **回归用例**：新增 `test/pocket.test.mjs` 6 条（默认路径 / `outingPocket` 覆盖 / 已登记不重复 create / 登记失败仍能出门 / 连目录都建不出来的失败 / 没有 registry 也不炸）；`test/outing.test.mjs` +4（想念天数整天口径、复用的匹配与路径归一、会话所有权只看 active、驳回话术只否定那几条）；`test/away.test.mjs` +2（挂了几段拆几段、没挂过的不乱拆）；`test/letter.test.mjs` +1（按会话/按时间筛，未打标不算留话）。全量 `node --test` **837 tests / pass 837 / fail 0**。

## 0.6.15 — 2026-10-29

**养了三天，一篇日记都没有（2026-10-29 用户 m01236 真机发现）。**

不是她不想写，也不是写失败：`~/.dsh-fish` 下连 `diary/` 目录都没建过，日志里 `日记` 相关 0 行——她一次都没试。原因在 0.6.6 那次改动（用户 m00928「叫醒仅仅只是叫醒」）：日记原来跟着叫醒消息一起派发，被移进身份文档常驻，而搬过去的那一段只写了「每天我会记一笔」，没写**用哪个东西记**。同一页的「隔些日子停下来想一想」明写了 `growth_commit` 和 `refs`，她照着能交出来；日记这段没写机制，加上一整天没有任何「到今天了」的节点，就成了「知道有这件事、但既不知道怎么落笔、也没有时机」。

- **身份文档补一句机制**（`lib/persona.js` 的 `DIARY_BRIEF`）：`写的时候用 growth_commit 交一条 type=diary——写多写少都行，不想写就不写。` 仍是第一人称、仍是常驻做法，不是任务派发；写不写由她决定。
- **当天最后一段给一个时机**（`lib/scheduler.js`）：新增 `DAY_END_CUE = '（今天到这里了。这一刻是我自己的。）'`，只在当天最后一次叫醒里追加。判断抽成纯函数 `isLastWakeOfDay(config, counts)`——上限取 `daily.events` 与 `wakesPerDay` 里**更小的那个**（`plan()` 的两个闸门同时生效），已醒 `counts.sent` 次 + 这一次顶到上限即为最后一段；配额配成 0 或非数字时不加，免得乱给时机。这句只进 `fish:wake` 段（用户看不见），**不提日记、不派活**——提了就成了工单，正是 0.6.6 要去掉的东西。
- **回归用例**：`test/events-v2.test.mjs` 新增 2 条（两个闸门取小、超了仍算最后一段、坏配置不乱给）；`test/herdiary.test.mjs` 新增 2 条（`DIARY_BRIEF` 必须含 `growth_commit` 与 `type=diary`、`selfdoc` 的 diary 分支仍在）。全量 `node --test` **821 tests / pass 821 / fail 0**（18.6s）。

## 0.6.14 — 2026-10-29

**市场里的版本总比 GitHub 慢半天到一天，想升级只能自己去 Releases 手动下载（2026-10-29 用户 m00203）。**

发到 GitHub 之后，插件市场的索引要走一轮构建，短则半天、长则一天。这段时间里「检查更新」能看见新版本号，却点不动——原来的按钮只是一个 `target=_blank` 的链接，指去 Releases 页面让人自己找包。现在这条链子接到应用里走完：**检查到新版 → 问一句 → 下载 → 解开来验 → 再问一句 → 关掉应用、换包、自动重开**。每一步都不静默：用户没点确认，什么都不会发生。

- **新模块 `lib/selfupdate.js`**（零依赖，只用 `node:fs/path/zlib/child_process/url`）。下载源是 GitHub tag 的 tarball（直连 `codeload.github.com/ssamurias/dsh-fish/tar.gz/refs/tags/v<ver>`；两个镜像前缀 `ghproxy.net`、`ghfast.top` 不走 codeload——实测镜像对 codeload 地址一律回 403 `Invalid input.`，改走 `github.com/ssamurias/dsh-fish/archive/refs/tags/v<ver>.tar.gz`，与直连包逐字节相同）。三个地址都硬编码、不接受外部传进来的 URL；单源 25 秒、整批 60 秒预算，断了换下一个，全断才报错。
- **下载完先验包再落盘。** 不是「文件大小对了就算成功」：流式收完先 `zlib.gunzipSync` 解开（带 96 MB 上限），按 tar 头扫 `package/package.json` 与 `package/lib/index.js`，核对包名是 `dsh-fish`、版本正是要的那个、入口文件在。任何一条不符——镜像回了 HTML 错误页、缓存滞后给了旧版本、文件被截断——都当失败，`.part` 文件清掉，正式文件名一次都不会出现。这样「装上一个坏包」这条路在下载阶段就断了。
- **失败说人话、能重试。** 报错形如「这个版本没能下载成功。直连：等了 25 秒没下完；镜像 A：HTTP 500；…。过一会儿再试一次，或者开一下网络工具。」卡片里留着「重试下载」按钮，从 `failed` 直接回到 `downloading`；不要求刷新页面，也不假装成功。
- **两次确认，各管各的事。** 第一次在下载前：「要下载 v0.6.15 到本地并校验，这一步不会重启应用。继续？」——只下文件，不碰现有安装；第二次在安装前，先讲清代价：「安装会先关掉 DeepSeek Harness，再由后台脚本替换插件、装完自动重开（大概半分钟，期间窗口会消失）。现在继续？」两次都用 `window.confirm`，与插件里其他危险动作一致。
- **真正的替换交给一个独立脚本**（`<数据目录>/updates/install-v<ver>.cmd`，`detached` 起，宿主被杀不会把它带走）。顺序是死的：等 2 秒让 HTTP 响应先回到界面 → `taskkill` 宿主 → 轮询 `tasklist` 确认真的退出了（60 秒还没退就**什么都不改**直接重开）→ 备份 profile 的 `package.json`、`pnpm-lock.yaml` 与 `node_modules/dsh-fish` → 用应用自带的 node/pnpm 装**刚才下载并验过的那个包**：`add "file:<数据目录>/updates/dsh-fish-v<ver>.tgz" --config.minimumReleaseAge=0` → 读安装后的 `package.json.version` 核对 → 失败就还原备份并 `pnpm install` → `start` 重开应用。**装的是本地包，不是 `github:` spec**：`github:` 要 pnpm 跑 `git ls-remote` 打 `github.com:443`，本机实测 `Recv failure: Connection was reset`（HEAD 也 ETIMEDOUT）——codeload 和镜像都通、偏偏 git 协议不通，而国内用户大多如此。本地包零网络，实测 `+ dsh-fish 0.6.11`、1.4 秒装完；文件留在 `updates/` 不删，之后 `pnpm install` 还要用它。日志写 `updates/last.log`（脚本里全英文，cmd 默认代码页是 GBK；装完之后状态接口会把最后 12 行带回来给界面看）。`--config.minimumReleaseAge=0` 是必须的：24 小时的「太新的包不装」闸会正好拦住刚发的版本。
- **开发版不动。** 依赖里写的是 `link:`/`file:` 时（装到源码目录的那种），`kind` 判成 `local`，`managed:false`——界面直接写「这台机器上装的是开发版，不走自动升级」，服务端也拒掉下载与安装。否则一次升级就会把源码目录换成下载包。同理，`execPath` 是 `node.exe`（非桌面版）时拒绝安装：换上去了却没有能重开的 exe，等于把人关在门外。
- **路由**：`GET /dsh-fish/update/status`（阶段 `idle/downloading/prepared/installing/failed` + 进度字节 + 来源 + 可读错误；prepared/installing 时附脚本日志尾巴）；`POST /update/download {version}`、`POST /update/install {version}` **只认 POST**（GET 一律 405——换成链接也不会「点一下就下」），缺 `version` 400，其它 `/update/*` 404。检查更新那条 `/update` 保持原样。
- **界面**：「关于」卡里检查更新旁边多一个「下载 v0.6.15」按钮，下载中显示百分比与已收字节，就绪后换成「现在重启并安装 v0.6.15」；原来的 GitHub 链接改文案为「或去 GitHub 手动下载」，还在。
- **回归用例** `test/selfupdate.test.mjs` 新增 26 条：地址与 spec 硬编码、`classifySpec` 六种、`profileDirOf` 的 link 识别、`runtimeBins` 找不到就退回 PATH、`inspectPackage` 的七种坏包（非 gzip/空/版本不符/包名不对/无入口/半截 tar）、下载成功不留 `.part`、断源换源、全败不落盘、内容不对不落盘、超时不拖住、脚本顺序（先等两秒再杀、真退出了才动手、装的是本地 tarball、含年龄闸、含版本核对、含回滚与 manifest 还原、含重开、**不含中文**）、无自带 pnpm 时退回 PATH、没有 tarball 才退回 `github:`、非 Windows 拒绝安装、状态机（prepared / 失败可重试 / 开发版拒绝 / node.exe 拒绝 / 起脚本 `detached`）、路由五种响应。全量 `node --test` **823 tests / pass 823 / fail 0**。
- **没做的事**（说清楚免得误会）：下载完不自动装——第二次确认永远是人点的；不静默替换正在运行的包（避坑指南 §3.1 的 `ERR_PNPM_EPERM` 就是这么来的）；不碰 `cordis.patch.yml`，也不改 `bundles`（插件条目本来就在，升的只是依赖版本）。

## 0.6.13 — 2026-10-29

**请她走之后，那条对话还自称是大肥鱼（2026-10-29 用户 m00924 真机发现）。**

不是提示词污染，也不是没请走。请神段是每轮现组装的 system prompt 贡献，撤掉就没了——被请的会话前后两条 `system/message`（`seq=339` 含「此刻你在…」、`seq=352` 不含）证明它确实被撤干净了。留在里面的是**历史**：请神期间她以自己身份说过的话已经写进那条会话，append-only，删不掉；模型下一轮读到「自己」上一句「我是大肥鱼」，就顺着演下去。任何提示词清理都动不了已经写下的消息。

- **结束时补一条交接句**：`lib/possess.js` 新增 `releaseNoteText()` / `appendReleaseNote()`——`releasePossession()` 在撤挂载、结台账之后，往那条对话里追加一条**可见的 `user/message`**：`（大肥鱼回去了，这条对话还给你。）` + `请神期间她说过的话仍留在上面的历史里；想完全干净，开一条新对话最稳。`。宿主校验按 `dsh-session` 的真实形状来：`{ id, role:'user', source:{kind:'user'}, content:[{type:'text',text}] }`，并带 `{ surfaceOp:'append' }`（`user/message` 属 surface-eligible，不带宿主直接拒）。
- **不连坐**：交接句写不进去（对话已收起来、session 已关、宿主形状变了）只记一条日志，请神本身照样算结束，`/possession` 回包里带 `note:{ok,why}`，界面据此换提示语。
- **界面上说清楚**：「结束请神」上面多了一个「临走留一句（可不写）」输入框，最多 200 字，会被写进那条对话的交接句；卡片里明写「请神期间她说过的话会留在这条对话的历史里——结束时会补一条『我回去了』进去，想完全干净请新开一条对话」。不再让人以为「结束 = 全部恢复原样」。
- **路由**：`lib/observe.js` 的 `/possession` `action:'end'` 先从 `ctx.get('agents')` 找到那条活 agent（没带 sessionId 就用台账里的 active 那条），把 `agent` 与 `farewell` 一起交给 `releasePossession`，回包透出 `note`。
- **回归用例** `test/possess.test.mjs` 新增 5 条（`releaseNoteText` 的两态与截断、交接句是合法 `user/message` 且带 `surfaceOp:'append'`、写不进去不抛、`releasePossession` 先撤挂载再补交接句且互不连坐、路由与界面源码级断言）。全量 `node --test` **791 tests / pass 791 / fail 0**。

## 0.6.12 — 2026-10-29

**请神的选择框里显示的是一串会话 id，不是对话框的名字（2026-10-29 用户 m00761）。**

设置 → 出门 →「请神（上身到一条正在用的对话）」的下拉原来是 `s.title || s.sessionId.slice(-8)`。问题在上游：服务端 `/possession` 从 `agent.session.header` 里找 `title`，而宿主**根本不往 header 里写标题**——它把名字写成会话事件流里的 `session/title` 事件，由 `sessionTitle` 服务折出来。于是 `title` 恒为空，客户端每次都退回 id 尾巴，用户看到的全是数字字母。

- **新模块 `lib/sessiontitle.js`**：`titleOfSession()` 按可靠性排三层——① 问宿主服务 `ctx.get('sessionTitle').get(session)`；② 服务不在（宿主版本不同、或测试里没有）就自己折 `session.snapshotEvents()`，从后往前取最后一个 `session/title` 的 `data.title`；③ 都没有才退回 header 的 `title ?? name`，再没有给空字符串。永不抛：拿不到名字不该让整页报错。另有 `titleOfAgent()`（从 agent 取会话）与 `clipTitle()`（截断，默认 80 字）。
- **服务端改名**：`/possession` 的候选列表改用 `titleOfAgent(ctx, a)`（`lib/observe.js`）；请神台账里记的名字也同步走这条（`lib/possess.js` 的 `possessInto`），「请神：×××」的日志与界面上「现在上身：×××」才有真名字。
- **客户端三处**：下拉走 `possessName(s)`——有名字显示名字；两条对话重名时补上工作区目录名（`标题 · dsh-fish`）区分；还没起名字的显示「还没起名字的对话」，不再把 id 甩给人看。「现在上身」同样显示名字 + 工作区，不再回退到 `sessionId`。
- **回归用例** `test/sessiontitle.test.mjs`（6 条）：服务优先、事件流兜底、无标题给空、header 只是旧版本退路、截断长度、以及源码级断言「下拉不再出现 `s.title || s.sessionId.slice(-8)`」。全量 `node --test` **786 tests / pass 786 / fail 0**。

## 0.6.11 — 2026-10-29

**「出门」页签在公开版里没藏住，所有人装完都能看见（2026-10-29 用户 m00608 真机发现）。**

0.6.7 说好「出门页只在开发副本里露出」，判据是 `/outing` 回包里的 `dev: IS_DEV_INSTALL`，而 `IS_DEV_INSTALL` 的算法是「自己的 `import.meta.url` 路径里有没有 `node_modules` 这一段」。这个判据不可靠：发布包会被解包到插件目录、也可能经 junction / link 指过去，路径里根本没有 `node_modules`，于是 `dev` 恒真、页签在正式版照常渲染。换句话说，它猜的是「安装布局」，而布局不由插件决定。

- **判据换成文件开关**：`/outing` 的 `dev` 改用 `await devMode(root)`（`lib/devmode.js`）——`DSH_FISH_DEV=1` 或数据目录下存在 `.dev` 文件才算本机测试版。这跟「去刷 B 站」那个按钮共用同一个开关，与安装路径彻底解耦：没这个标记就是正式版，页签不渲染。
- **删掉 `isDevInstall()` / `IS_DEV_INSTALL`**：不再按路径猜安装形态，避免以后换一种装法又漏一次。代码、路由、审查卡照旧全部保留，本机 `.dev` 在，开发副本上页签与以前一样。
- **回归用例**（`test/outing.test.mjs`）：断言 `lib/observe.js` 里没有 `IS_DEV_INSTALL`、没有 `includes('node_modules')`、`/outing` 的 `dev` 走 `devMode(root)`，且复用 `./devmode.js`——判据再被改回路径猜法时这条会红。
- 验证：本机 `node --test` **780 tests / pass 780 / fail 0**。

## 0.6.10 — 2026-10-28

**GitHub Actions 四个 job 全红：三处「只在 Windows 上成立」的路径判断（2026-10-28 发布后自查）。**

本机 Windows 上 779 条全绿，推到 GitHub 后 `test` workflow 的 ubuntu（Node 20/22/24）与 Windows runner 全红。逐条对日志，全是平台依赖，不是逻辑回归：

- **`normPath` 在 POSIX 上把 Windows 路径当相对路径。** `resolve('D:\\a\\home')` 在 Linux 上会拼到 cwd 后面（变成 `/home/runner/work/dsh-fish/dsh-fish/D:\a\home`），而 `isInside` 又用平台的 `sep` 拼前缀，于是「同一个家有大小写/尾斜杠两种写法」被判成「在外面」——`isInside / normPath`、`checkCaller`、`guardWrite` 三条一起红。现在 `normPath` 先认 Windows 写法的绝对路径（盘符 `^[a-zA-Z]:[\\/]` 或 UNC `^\\\\`）：不管跑在哪个系统都按 Windows 规则归一（分隔符统一成 `/`、盘符路径小写），其余才走 `resolve()`；`isInside` 比较前把两侧分隔符都统一成 `/`，混着比也不会误判。**Windows 上的输出格式一字未变**——`~/.dsh-fish-homes.json` 里已记的家不会被当成新家、不会写假事件。
- **`normRoot` 剥不掉 Windows 写法的尾 `\`。** POSIX 的 `sep` 只有 `/`，`…\Home\` 与 `…\Home` 被当成两个家（`同一个家的不同写法不算换家` 红）。改成两种分隔符都剥。
- **自检用例把「缺 ffmpeg」连坐成「看画面坏掉」。** `tools.test.mjs` 早先断言自检摘要不含 `/看画面/`，只为证明「全局工具表查不到 `read_image` 时不能乱报红」；但 GitHub 的 Windows runner 没装 ffmpeg，另一项红项的标题正好叫「看画面用的 ffmpeg」，被这条断言误伤。改成直接断言红项里没有 `read-image` 这一项，不再拿文案做代理。
- 验证：本机 `node --test` **779 tests / pass 779 / fail 0**；另用 POSIX 语义模拟（`D:\deepseekagent\04-小工具\posix-sim.mjs`）逐条复算了 ubuntu 上那几个断言，确认修对了。

## 0.6.9 — 2026-10-28

**反馈页的「常见问题解答」点了没反应；刷视频记录翻不了页（2026-10-28 用户 m00416）。**

- **常见问题解答点了没反应。** 按钮原来是 `<a target="_blank">` 指向 `/dsh-fish/faq`，想在浏览器新窗口里看全文。但宿主的信任栅栏只认 App 内的登录 cookie，新标签页直接敲这个路径一律 403 —— 用户看到的就是「点了一下，什么都没发生」。现在改成 `button` + **就地展开的面板**：点一下向 `/faq.data`（同源、带 cookie）取同一份 JSON，在卡片里摊开一个固定高度、内部滚动的面板，看完点「收起」；不把下面的「找开发者 / 进群」挤出屏幕，也不依赖任何窗口策略。整页 HTML（`/dsh-fish/faq`）保留，浏览器带登录态仍可看，断网也行。
- **刷视频记录按条翻页，每页条数随实际量自适应。** 0.6.6 之前是「按天分组、每页三天」——一天刷 10 条、查 3 天就是 30 条挤在一屏，只能一直往下滚。现在摊平成一条一条，日期只在换天处出现一次；**每页多少条不是死数字**，而是看总量与日均密度：一共 ≤ 8 条就一页全放下（连翻页条都不出，避免「第 1 / 1 页」这种噪音）；日均 > 20 条 → 6 条/页，> 10 → 8 条，> 5 → 10 条，其余 12 条。刷得越密每页越短，重度用户一屏不会顶到十几条，轻度用户也不用为翻页而翻页；页码旁会写「一页 N 条」。查询范围（1 天 ~ 1 年）不变。
- 测试：`faq.test.mjs` 新增「/faq.data 吐 JSON」与「按钮不再是 target=_blank」两条（5→6）；`client.test.mjs` 新增「按条翻页」一条（20→21）；`ui.test.mjs` 那条 10-24 写的「一天里的条目全部列出」（断言源码里还留着 `g.items.map(`）按新语义改写——现在断言的是「全部摊平后再分页、没有 `slice(0, 8)`、两个翻页按钮和页码文案都在」。全量 779 条全绿。

## 0.6.8 — 并入 0.6.9

**分身与重复的会话（2026-10-28 房客日志复盘）。** 一位用户把插件装到 `D:\DSH\plugins-src\dsh-fish`，又在 `cordis.patch.yml` 里换了两次 `root`，最后侧栏里出现好几间「大肥鱼的家」，重启还会继续长新的。日志逐条对完，是三件不同的事：

- **归档过的会话被当成「没了」，于是每次启动重建一间。** 判活只看工作区的会话清单、又把已归档的排掉——用户手动归档之后，下一轮启动就判死重开。现在 `home.json` 记 `status: 'archived'`（含 `archivedAt`），归档态下 `ensureTalkSession` 直接返回「这个家的会话被收起来了」，不再自动新建；想重开有明确入口（见下）。自己的 `/reset`（重置一局）仍旧新建，那是它本来就该干的事。
- **同一间房被并发建两条。** 启动链路和「她要说话」链路都会调 `ensureTalkSession`，没有单飞锁时各建一条。现在按规范化后的 root 共享同一个 promise；另外 `home.json` 的 `createdAt` 在 10 分钟内时，即使宿主索引还没列出那条会话也按「可复用」算，避免索引延迟造成重复。
- **换了 root 没有任何痕迹。** 新家从零开始，旧家的东西原封不动留在旧路径——这在用户眼里就是「一夜之间多了个分身」。现在在数据目录之外记一份 `~/.dsh-fish-homes.json`（可用 `DSH_FISH_HOMES` 覆盖），root 变了就在事件流里写一条 `meta`：「家换了：A → B。这不是搬家——旧家的东西还在旧地方，没有并过来；这边从一开始就是新的」，同时进日志、进 `/state.homes`，设置页数据页顶部也会提示。

新增 `lib/homes.js`（`homesFile` / `normRoot` / `readHomesSync` / `noteRoot`）；`home.js` 新增 `HOME_GRACE_MS`、单飞锁与 `force` 参数；`observe.js` 新增 `POST /home/rebuild`（要 `confirm: 'rebuild'`）与 `/state` 的 `homes`、`home` 字段；设置页新增「会话被收起来了」卡片与「重新搭一間」按钮，换家时给一行路径说明。测试：`home.test.mjs` 两条旧断言反转、新增宽限与并发两条；新增 `homes.test.mjs` 5 条。全量回归 777 条全绿。

**注意语义变化**：以前「把会话归档」等于「下次启动重开一间」；现在归档就是收起来，重开要点「重新搭一間」。

## 0.6.7 — 并入 0.6.9

**两份大肥鱼共用一个家（2026-10-28 房客反馈）。** 那位用户把插件文件夹手工搬到别处，结果两个工作区都加载了大肥鱼、都落到同一个数据目录，最后出现「两只鱼、一份记忆」。插件此前对此毫无察觉：无论从哪条会话进来，`growth_commit` 都往同一个 `events.jsonl` 追加，事件里也不带「谁写的」。

现在分三层拦住：

- **认家。** 加载时在数据目录写 `instance.json`（instanceId、心跳时间、进程号、机器名），每 15 秒续一次；45 秒没续或同机进程已死即视为前任崩了，新实例立刻接管（重启不会被自己锁住）。
- **后进来的不写。** 占用被别的活实例握在手里时，`growth_commit` / `her_leave` / `bili_speak` 直接回一句「这个家被另一个实例占着」并说明怎么分开，身份文件也不落盘；已在里面的旧事件一律不动。
- **认谁在写。** 工具调用前核对调用者会话的 cwd 属不属于当前家，不属于就拒绝并说明「这不是这里」；每条事件新增 `sessionId`（最多 120 字符，去控制字符），事后能查到是哪条会话写的。

新增 `lib/tenant.js`（`callerOf` / `checkCaller` / `claimRoot` / `beatRoot` / `releaseRoot` / `guardWrite`）；`schema.js` 认 `sessionId`；`capture.js`、`letter.js`、`speak.js`、`selfdoc.js` 接入；`index.js` 启动时认家并起心跳，`/state` 回包新增 `tenancy`；`observe.js` 透传。新增 `tenant.test.mjs` 11 条（双实例拒绝、死 pid 立即接管、TTL/release、心跳失败不改归属、身份文件两路守卫、schema 的 sessionId）。全量回归 768 条全绿。

**给搬家的用户**：正确的分家方式是在 profile 的 `cordis.patch.yml` 里给这个插件条目配 `root`，两个工作区各指一个目录，不要复制插件文件夹。升级插件包不会重写 `cordis.patch.yml`（插件只写自己数据目录下的文件），但升级后要确认那条 loader 条目的 `id` 仍然对得上——对不上时 patch 会静默失配，两个工作区就又会回落默认的同一个目录。

**「出门」页只在开发副本里露出来**（2026-10-28 用户要求）。这个功能还要真机跑一段时间，发布版先不放到设置页上：服务端按自己的 `import.meta.url` 判断是不是装在 `node_modules` 底下，`/outing` 回包带上 `dev`；设置页只在 `dev === true` 时渲染这个页签。代码、路由、审查卡全部保留，本机 `link:` 安装的开发副本照常显示——不是删功能，只是收入口。测试同步改为断言 10 个页签、`devMode` 过滤与 `/outing` 的 `dev` 字段。

## 0.6.6 — 并入 0.6.9

**四条用户反馈**（2026-10-28 用户转来）：

- **「让我看日记」会自己关回去。** 根因是设置页的「整表自动保存」：任何一项环境参数改动都会在 700ms 后把**整份**配置 POST 一遍，而 `buildConfig()` 里带着日记三项；`/state` 回包比手速慢一点，刚落下的开关就按旧值被拨回界面、再被整表写回文件。现在日记三项**摘出整表**，各走各的窄 patch（`{diary:{visible}}` / `{diary:{enabled}}` / `{diary:{keepDays}}`），patch 未回包期间不让 `/state` 覆盖输入框；`/state` 里 `diary` 字段不是 boolean 时一律跳过，不再把 `undefined` 当 `false`。
- **领养人两格被登录账号顶掉。** 0.5.10 起服务端已不再回填（#2），仍复现的路径有三条：①用户点的是「测试」——它只验 cookie、不保存两格，旧文案却让人以为会保存；②`owner.json` 被 ≤0.5.9 写脏且没有迁移；③cookie 认不出来时旧代码**整单放弃**，连 `mid`/昵称一起丢。现在：测试按钮改叫「测试 cookie 能不能说话」并写明「不保存、不动上面两格」；保存时 cookie 解析失败**仍把两格存下**；两格与登录账号相同时界面点出「像是旧版本写进去的」。
- **看视频记录只看得见 4 条。** `recordBrowse` 原来把每次刷站的结果塞进**一条** meta，超过 1800 字就从尾部 `slim.pop()` 丢条目（带封面的单项 ≈350 字 → 每次只剩 4 条），而 `looked:` 计数不受截断影响 —— 于是「累计看过 24」配「抽屉里 4 条」。现在按 1800 字**分片**写成多条 `browse:` / `browse-more:` 行，读取侧（历史列表、外出、封面兜底）全部分片解析；`browseCountToday` 的当日配额口径不变。
- **风控提示不清。** 读/写两条冷却提示都带剩余时间（「B站风控冷却中，还要约 N 分钟才能写」）；`browsePlan` 的 note 带分钟数；观测台把「落盘的冷却」与「进程内 60 秒熔断」分两句话讲，并说明后者重启就清空（`/risk` 回包新增 `memory` 字段）。

新增测试：`client.test.mjs` 3 条（日记不进整表、风控两层提示、领养人脏值提示）、`owner.test.mjs` 1 条（cookie 认不出仍存两格）、`bili-risk.test.mjs` 1 条（`memoryCooldown` 形状）、`p6.test.mjs` 1 条（note 带分钟）。全量回归见下。

**递过来的视频，她以前永远评不了**（2026-10-28 用户反馈）。截图里她自己的说法是：「平台今天推给我的视频 能；我自己搜出来的 不能；你发链接给我的 也不能」。根因两处：评论闸门 `targetsToday()` 只认刷站记账 `browse:`；`bili_look` 又只有 `home/search/related`（`related` 是「接着这条往下看别人的推荐」，看不到指定那一条）。口径本来就错了——该管的是**她有没有真的看过**，不是**谁让她看的**。

现在可评论的目标是三种来源的并集：刷站记账、主动看过的 `look:<日期> <bvid>`（`bili_look` 每次「看」都记一行）、看过画面的 `watched:<日期> <bvid>`。**递过来但没看一眼的不算**：`turns.js` 从侧栏真人消息里认出 BV 号只记 `hand:<日期> <bvid>`（事实，不等于看过），拒绝理由会写明「这条是他递过来的，你还没看」。昨天看过的今天也不能拿去评（`looked:` 无日期，`look:` 带日期，两者并存）。

`bili_look` 新增 `what=video`：按 BV 号看指定那一条。详情只取一次——`absorb()` 现在可以接收调用方已取回的 `view`；b23.tv / bili2233.cn 短链由新增的 `client.resolveUrl()` 解析成 BV（跟随跳转取落地地址，跟不到再从正文里抠；只认 BV，不认 av 号）。设置页「在 B 站说话」的说明句同步改成三种来源。

新增测试：`look-video.test.mjs` 7 条（按 BV 看指定一条并落两笔账、黑名单不看也不记账、认不出就直说、短链交给 client、absorb 复用详情、resolveUrl 带 BV 不联网、从正文抠 BV 与「不是视频」）、`p4.test.mjs` 2 条（`targetsToday` 并集与日期口径、hand 之后 look 才能评）。

**设置页多了一个「常见问题解答」入口**（2026-10-28 用户要求）。反馈页第一张卡就是它，点了在**新窗口**打开 `/dsh-fish/faq`：整页 HTML、自带深浅两套配色、不引任何外部资源（断网也能看）。正文是作者那份《常见问题解答.doc》的逐字搬运，12 个问题（权限、接别的渠道、上下文撑爆、遗忘机制、对话认知条数、字数限制、换对话、找不到成长事件、看不了视频、加功能……），不是摘要。没在设置页里铺开——太长了，展开会把整个页面顶歪。

新增文件 `lib/faq.js`（正文 + `renderFaqPage()` + `escapeHtml()`；正文一律转义，这一页没有一处该被当成标签）；`lib/observe.js` 注册 `/faq` 路由（`content-length` 按 `Buffer.byteLength` 算，中文标题才不会被截断）；`lib/client.js` 反馈页加按钮。用的是原生 `target="_blank"` 链接而不是 `window.open`，不受弹窗拦截，也能中键开。

新增测试：`faq.test.mjs` 5 条（12 条正文与原文档对齐、页面自包含无脚本无外链、转义、`/faq` 路由 200 + content-type + 字节长度、反馈页按钮确实指向 `/faq` 且新窗口）。

## 0.6.5 — 并入 0.6.9

**请神：把一条正在用的对话临时交给她。** 从下一轮起，回你话的是她——身份是真的、工具是真的，不是演。结束时撤销，那条对话恢复原样。

换人靠的是宿主自己的分段名，不是往提示词里再塞一段。宿主 `@deepseek-ai/dsh-system-prompt` 的段是 `deployment:persona-prefix`（order 10100）与 `deployment:persona-suffix`（10200），而 **scoped ctx 上注册同名段会覆盖全局那一段**（宿主注释原话：a scoped section shadows a global section with the same name）。这两个名字是从安装包 `app.asar` 里把 `dsh-system-prompt` 抽出来读到的，不是猜的——0.6.3 猜过一轮，猜错的名字不会报错，只会静默不生效。现在覆盖失败会退回插件自己的段名 `fish:possession`（order 10150）并写一行日志说明，不假装成功。

三条边界：

- **只能请到活着的对话。** 宿主 `agents.get(sessionId)` 只认当前在内存里的 agent；没打开过的对话请不到（打开一次之后才会出现在下拉里）。
- **她自己的家请不了**；**她正在出门时也请不了**（先叫她回家）。出门与请神是两条路，同时开会互相打架。
- **守卫会连你一起拦。** 请神期间那条对话的参数级拦截（她的屋子、`~/.dsh/{memory,sessions,profiles}`）照样挂着，而它分不出这条消息是谁打的——你自己在那条对话里读这些路径也会被拒。界面把这条写在按钮旁边，没有藏。

撤销是可验证的，不是「关了就当没了」：两层段（前缀覆盖 + 后缀清空）在 `agent.ctx` 的 effect 上注册，结束请神时按逆序 dispose；台账 `~/.dsh-fish/possessions.json` 记 `{sessionId,title,startedAt,status,identity}`，宿主**冷会话**被打开时（`agent/created`）id 对得上就补挂，不用重新请一次。身份用**请神那一刻的快照**（与出门同一套做法），不是每轮重读家里的活文件。

新增 `test/possess.test.mjs` 8 条（正文、同名覆盖、覆盖失败退路、宿主没有 `systemPrompt.section`、冷会话补挂只认 id 对上、坏台账当没有、台账存快照、出门占着时拒绝）。全量回归 **739 passed / 0 failed**。

## 0.6.4 — 并入 0.6.9

**按仓库里三个 issue 修的三处**（#5 风控熔断、#6 侧栏轮数、#7 日记覆盖与不可读）。

**#5 一次 -412 被放大成 30 分钟不可用，间隔也改不了。** 原来 `lib/bili.js` 只有一个全局 `riskUntil`：任何一次 `-412` 都把这个进程按死 30 分钟，读和写不分——刷一次首页碰上风控，连看视频、发评论一起停摆。现在拆成两档：**读**（搜索/首页/评论列表/弹幕）从 60 秒起、连续复发翻倍、封顶 10 分钟；**写**（发评论、回复）从 5 分钟起、封顶 30 分钟。任一次成功就立刻解除自己那一档。另外**签名接口**（WBI 签名的 `search`）收到 `-412` 时先强制刷新一次密钥重试一次，还不行才认作风控——那类 `-412` 里有一半其实是 `w_rid` 过期。`-352`（风控校验失败）、`-509`（请求超限）一并按风控处理，其余错误码不再误伤。

请求间隔终于**可配**了：`bili.minIntervalMs`（默认 800，夹在 200–120000）与 `bili.jitterMs`（默认 500，夹在 0–60000），设置页「B 站」页签可改；`null` / 空串 / 非数字一律回落到默认值，不会把间隔配成 0 去撞风控。改完下一次请求就生效（`loadConfig` 里直接喂给客户端）。

**#6 在侧栏亲口跟她说话，`【turns】` 不涨，`chat.rotateAfter` 永不触发。** 根因是 `bumpTurns()` 只有 `/say` 路由一个调用点——那是观测台/IM 替人递话的路，用户在侧栏直接打的字根本不经过它。新增 `lib/turns.js`：监听宿主 `session/event`，认准"她住的那个会话"，收到**真人打的** user 消息就记下，等这一轮 `turn/end` 再结账（turns +1、`talkmem` 记原话、满 `rotateAfter` 就换会话，和 `/say` 走同一套 `rotateTalkSession` + 身份文档刷新）。换会话时还会往事件流追加一条 `meta`（`rotate:<turns>:<新会话 id>`），事后查得到。

来源必须先分清，否则轮数一定失真：真机会话事件里 `runtime-context` / `skill-catalog` / `plugin:xxx` 这类注入的 `source.kind` 不是 `user`；插件自己 `prompt()` 进去的消息 `kind` 也是 `user`，但 **`rpcId` 带 `wake-`/`say-` 前缀且没有 `clientTimeZone`**；只有客户端亲手打的字才带 `clientTimeZone`。认来源的判据就是这条，宁可少算一轮，也不把每晚的唤醒算成人说话（那会让 `rotateAfter` 天天提前触发、她天天失忆）。

**#7 同一天写第二次日记会静默覆盖，而且她自己读不回。** 两半都修了。

- **覆盖**：`writeDaily()` 在覆盖 `diary/YYYY-MM-DD.md` 之前，如果旧稿存在且内容不同，先存到 `diary/archive/YYYY-MM-DD-HHmmss.md` 再写新的。界面上仍然是"一天一篇"（客户端按日期分页不用改），`listDiary()` 的正则只认顶层 `YYYY-MM-DD.md`，归档版不会被当成第三篇日记。内容相同不归档，归档失败也不阻断本次写入。
- **读不回**：新增只读工具 `her_diary`（`lib/herdiary.js`），加进 `HER_TOOLS` 与身份里的日记说明。它**只读、只能读日记目录、参数是日期不是路径**（`YYYY-MM-DD` 之外一律不认，`../` 传不进来），一次一份、正文截到 3000 字，也可以只列写过哪些天。**不参与身份文档拼装，也不进 `her_recall`**——`diary.visible` 管的是"主人看不看"，这个工具管的是"她自己愿不愿意回头翻"，两个开关不交叉，原来那条"日记不进事件流"的设计没被拆。

新增 `test/turns.test.mjs`（来源判据、真机事件形态、结账、换会话、非她屋子不记、插件消息不记、注销后不再记）、`test/herdiary.test.mjs`（最近一篇、指定日期、日期清单、非法日期、那天没写、截断），`test/dailylog.test.mjs` 补了同日覆盖归档的用例。

**顺便修了出门那条兜底守卫「看不见实参」的毛病。** 0.6.3 的 `attachAwayGuard` 只读 `exec.args` / `input` / `params`，而宿主 `@deepseek-ai/dsh-tools` 的 `createExecution` 只挂 `exec.arguments`——守卫每次拿到的都是空对象：日志上写着「外面这一条挂上了兜底守卫」，实际一次也没拦。2026-10-28 20:55 那趟真机就是在这条缝里用 `ops_bash` 把 `PLAN.md` 读走的。现在四种形状都认，`test/away.test.mjs` 的用例改成宿主真实形状（`{name, arguments:{…}}`）并保留 `args` 变体。全量回归 **731 passed / 0 failed**。

## 0.6.3 — 并入 0.6.9

**她可以出门了：去别的工作区干一趟活，回来再判这趟算不算数**（用户 m07453 定的方案，文档见 `docs/E-出门与请神-方案.md`）。

以前她只有一间屋子：`~/.dsh-fish` 那个工作区，工具面被 6+1 白名单收窄到只剩自己那几个。想在别的项目里干点什么，只能由人手动把那个项目的工作区开给她，开完还得一路盯着。现在设置页最后多了一个「出门」页签：选一个工作区，在那边开一条新会话，她继承那个工作区**本来的权限和工具**（不套家里那套收窄过的名单），第一条消息由插件递过去，说明她在哪、能用什么、别动自己的屋子。

**出门不是「换个地方聊天」，是换一套规矩。** 所以有四条边界：

1. **同一时间只能出一次门。** 第二条会被拒——同时出现在两个工作区，回家时两份记录会互相踩。
2. **出门期间家里那套日程整段暂停**（`lib/scheduler.js` 的 `tick()` 开头先看台账）：不叫她、不刷 B 站、不写日记。原因同上：两边同时醒着，`events.jsonl` 就是两个人抢一支笔。
3. **回家时先验事件流。** 出门前记下 `events.jsonl` 的字节数 + 尾部 4096 字节的 sha256（`lib/outing.js` 的 `snapshotEvents`）；回家时三种结论：**变小**（被删过行）、**大小没变但尾部变了**（被原地改写）、**只是追加**（她自己写日记，正常）。前两种默认**不收**：`status` 停在 `pending`，她留在外面，等人看过再决定——这条是用户拍的板（「不能只收下说得漂亮的」）。
4. **「这趟不算数」不是删记录。** 驳回只把这一趟标成 `rejected`，事件原文仍在 `events.jsonl` 里（第 5 条铁律：只能追加），只是 `deriveSelf` 跳过这一段。话术也不是「你没去过」，而是「那部分我不认，它不算你」。

**在门外，她读到的是「走的时候的自己」，并且伸不回家里。** 出门那一刻，身份文本会被归档成一份只读快照写进台账（`lib/outing.js` 的 `identity` 字段），外面那条会话的 system 段读快照，不读家里那份随时可改的文件——否则人已经出去了，身份还能被自己在别处改写。同时那条 agent 上挂了兜底守卫（`lib/identity.js` 的 `attachAwayGuard`）：任何工具调用里出现她家目录的路径就拒绝，话术与家里的收窄一致（「这件事我做不到。」，不带权限/禁止字样）。这层不是防外人，是防「自己伸手回家」——收窄挡的是「看不见」，挡不住写文件。

**回家卡上先看得到比对结论，再决定收不收。** `/dsh-fish/outing` 的 GET 现在顺带算一遍事件流比对（只读，不写盘），出门页签「现在在哪」那张卡直接写「事件流只多出 N 字节」或者「不对劲：…」；`identityFrozen` 也一并返回，卡上会说明她带的是什么时候的自己。

**身份判据拆成了两条**（`lib/restrict.js`）：`isHerHome` 只认她自己的屋子——**工具收窄**用它，出门了就不该按家里的名单收；`isHerAnywhere` 认家 + 出门名单上的那个 cwd——**身份挂载**用它，出门那一位仍然是她，否则她在外面会失去全部来历。原来的 `isHerAgent` 保持行为不变，作为 `isHerHome` 的别名留着。

**请神这一版没开。** 它要在别人 agent 的 scoped ctx 上注册**同名** system 段来盖掉人格、用影子工具盖掉工具面；而宿主那些段名（`systemPrompt.section({ name })` 的那一串）没有在运行期 dump 过，写错不会报错、只会静默失效。`/dsh-fish/possession` 现在 GET 如实说「还没启用」、POST 一律 409，设置页那张卡也把理由写在脸上——**宁可没有，也不要一个看起来装了、其实没盖上的请神**。

**这一趟做了什么，回家时逐条摊开；不收下的那条也不删。** `/dsh-fish/outing` 的 GET 现在把 `away.since` 一起返回：`lib/outing.js` 的 `eventsSince` 按 `ts >= startedAt` 筛出这一趟新增的事件（排除 `outing-reject:` 这类插件自己写的标记行，最多给最后 300 条，`total` 仍是真实条数）。出门页签点「叫她回家…」先展开这张卡：每条一个勾选框、默认全勾，文本截到 400 字；`type === 'refusal'` 或 `verdict === 'refuted'` 的条目前面单独标「顶回来的」——只收下说得漂亮的，等于把这趟教坏。

取消勾选后点「这趟收下」，`POST /outing` 带 `rejectedIds`；服务端确认事件流没被动过之后追加一条 `meta`（`text: 'outing-reject:<id> <id> …'`，走 `validateEvent(…, { source: 'system' })`——只有 system 才能写 meta）。`deriveSelf` 读到这条就把那些 id 跳过：**原文仍在 `events.jsonl` 里，观测台和导出照样看得见**，只是不再参与她对自己的判断。第 5 条铁律是「只能追加」，所以「不收下」只能是读时跳过，不能删行。「整趟不算」走另一条路（`kept: false`），台账里 `status: 'rejected'`，不写逐条标记。

**真机第一趟抓到一个顺序 bug：会话先建了，台账还没写。**（2026-10-28 13:18 / 13:32 两趟真出门）

两趟的台账都对：第一趟 6 秒、第二趟 88 秒，身份快照 2834 字符、基线 98400 字节都在。但日志里既没有「外面这一条挂上了兜底守卫」，也没有「身份段已挂进 system prompt」——**她出去的时候没有身份段，也没有兜底守卫**。根因是 `POST /outing` 先 `sc.create()` 再 `startOuting()` 写盘：宿主在建会话时**同步**触发 `agent/created`，`lib/identity.js` 那条钩子读到的是「她没出门」，于是整段跳过。同一根因还有另一半：`readOutings` 按 `sessionId` 过滤，空 id 的那条会被当坏档丢掉。

改法是「先记账，再建会话」：`startOuting` 允许 `sessionId` 先空着；`sc.create()` 之后用 `bindOutingSession` 把 id 补进台账（幂等），建会话失败则 `abortOuting` 撤掉空壳（否则她会一直「挂在门外」，家里调度也跟着停）。`agent/created` 那边三种都认：台账记的 id 对上、cwd 就是出门那个工作区、或者台账刚写还没 id 而这条会话还没 cwd；认不出来时留一行「有条出门记录，但这条会话没对上：cwd=… sid=…」，不静默跳过。

新增 `lib/outing.js`（台账 + 基线 + 判据 + `eventsSince`，独立于 `events.jsonl` 结构）、`test/outing.test.mjs` 14 条（互斥、三种比对结论、坏档容错、`awayLine` 文案、空 id 先记账 + `bindOutingSession` 幂等 + `abortOuting` 撤空壳）、`test/away.test.mjs` 10 条（身份快照、兜底守卫拦不拦、没 `tools.guard` 时如实报错、出门那条挂两段而家里那条不挂守卫、**会话还没有 cwd 时也认得出出门并把 id 补进台账**、认不出来要留日志）、`test/review.test.mjs` 5 条（只摊开出门后新增、没给时刻不猜、limit 截断但 total 真实、`deriveSelf` 跳过被取消勾选的条目、一条标记带多个 id）。全量 `node --test` = **704 passed / 0 failed**（0.6.2 基线 675 + 新增 29）。

**真机第三趟暴露了更难查的一层：她不该读到的东西，是「记忆注入」送进去的，不是她翻出来的。**（2026-10-28 14:13 那趟，`session-5fd70849`）

那趟她在 `deepseekagent` 里待了 17 分钟：读文件、搜网存图、回家。日志里身份段和兜底守卫都挂上了，`~/.dsh-fish` 也确实没被读——但她思维链里出现了「四条黑名单代码级硬禁（不撒娇卖萌、无好感度数字、不读自身数值与设定、不能调工具改自己）」的原文，还拿它当理由拒绝了一次读自己屋子。查会话原文才看清：她在最开头收到的**第一条 user 消息**不是人打的字，是 `@a9i5k4/dsh-auto-memory` 注入的记忆块——那个工作区的白板（禁令原文就在白板里）和交接账本（「先记账、再建会话」、`bindOutingSession`、基线 98400 字节、身份快照 2834 字符，全在）。同一块每轮刷新一次，整趟注入了三次。**文件路径拦截拦不住这条路**：注入是宿主按工作区拼好递进去的，不经过任何工具调用。

所以「出门」现在有两种：

- **原来的出门**（去某个已有工作区）：能干活，但那个工作区有多少记忆，她就带过去多少。选到插件源码目录时界面会亮警告——同一个道理，源码里有禁令清单。
- **出门口袋（干活模式，2026-10-28 用户 m01145 拍板）**：一个从没写过记忆的空目录（默认 `~/outing-pocket`，可用 `config.outingPocket` 改），第一次开门时自动登记成工作区。那边没有这里的白板，也没有这十几天的账，每轮注入只剩骨架；她的身份、工具、网络照旧。设置页「出门」页签多了一张「出门口袋」卡，按钮是「送她去口袋」。

**读拦截也跟着扩到了宿主记忆库。** 兜底守卫原来只挡 `~/.dsh-fish` 和插件的根目录；现在 `lib/identity.js` 的 `awayBlockedPaths` 还会加上存在的 `<用户目录>/.dsh/memory`、`.dsh/sessions`、`.dsh/profiles`——白板、交接账本、每日日志、所有会话原文、profile 配置都在那下面。**记忆类工具（`memory_recall` 等）不在这一层挡**：它们的参数是关键词不是路径，用户拍板保留（干净工作区里已经没东西可召回）。

**代价写进界面，不藏着**：沙箱的写权限跟着工作区走，她在口袋里写不进 `02-我的项目` / `03-我的文档` / `04-小工具`。真机那趟已经踩过更硬的一版——`workspace-write` 下 bash/node 对**含中文祖先的路径**一律 `EPERM`（`mkdir`/`touch`/`cp`/`cat >` 全挂，连指向它们的 junction 也挂），11 分 46 秒里 8 次 `Permission denied`、2 次等人点批准，真正有效动作只有三步。要交付就从口袋搬，或者回到主工作区再动。

新增 `lib/identity.js` 的 `awayBlockedPaths` + `lib/observe.js` 的 `ensurePocket` / `pocketDirPath` + `/outing` 的 `pocket` 字段与 `{ action: 'start', pocket: true }` + 出门页「出门口袋」卡（`lib/client.js`）；`test/away.test.mjs` 加 1 条（宿主记忆库路径被挡、不存在的目录不凭空多一条）。全量 `node --test` = **705 passed / 0 failed**。

## 0.6.2 — 并入 0.6.9

**自检里「看画面」单列一项，缺 `read_image` 不再是绿行末尾的一句附注**（2026-10-28 用户转来别人的运行日志：「她的大肥鱼看不到视频画面，但是 ffmpeg 也安装了，是因为看视频设置到上限了吗」）。

那台机器 ffmpeg 装好了、额度也没用完，`bili_watch` 走完整个流程都没报错——问题在更上游：宿主没注册 `read_image`，她能抽到帧，打不开那张图，于是整个「看画面」等于白做。而当时自检把这件事写在「手上的工具 ✓」那行的末尾（「宿主没给 read_image，她看不了图——不影响说话」），前面一个绿勾，没人会去读。

现在它是一项独立的 `read-image`：「看画面」。没给工具表的假环境（预检、部分测试）里这一项干脆不出现，不冒充结论。

**然后当天深夜就被自己的判据打脸，改成「有旁证才算有」**（用户 m05885：「那为什么我这个可以看图呢，还是说她假装在看图，我根本没发现她看不了图？关键是她之前还看图成功了，还能把抽帧的视频画面讲明白」）。

`!tools.get('read_image')` 这个判据是**必然误报**：宿主把 `read_image` 注册在 agent 平面（由 `attachments` 服务挂着），全局工具表里根本查不到它——所以任何真机都会报这一项红。反证在用户自己的会话里：`bili_watch` 抽出的 1096×622 PNG，`read_image` 读回来的是一整个 image 块，她照着画面把内容讲了出来（「画面是黑的底，白符号是实心的。橙色小人被夹在两个 −1 中间……」）。

判据改成四条，按证据强弱排：① 全局表里直接看到 → 绿；② 收窄真的挂上了（`applied > 0`）且名单里有它 → 绿（`restrict` 遇到不存在的名字会抛错，等于宿主亲口认过）；③ 宿主明说了没挂 `attachments` → 红，给三步修法；④ 都查不到 → 绿，写「查不准，让她看一次画面就知道」，**不再替她宣布看不见**。`/dsh-fish/selfcheck` 顺带把 `attachments` 服务的真实状态传进来（有 `ctx.get` 就是权威答案，没有就别猜）。

顺带把自检的修法从 `.tag` 胶囊改成单独一行：原来是一句话还行，这次的三步会被撑成挤在一起的长条。

**skip 日志不再每分钟刷一条**（同一份日志里 22:15→23:00 每分钟一行 `skip 今日主动唤醒已满(1/1)`）。

跟 0.6.2 上面那条 `quiet:` 刷屏同源：`skip` 也不带 `wake:` 前缀，`todayCounts` 拦不住它，原因又是当天固定的配额，于是同样的字被重写上几十遍，真正的报错（工具有没有注册上）反而被埋掉。现在同一小时 + 同一原因只记一条，换小时或换原因才再写；判定走纯内存（`lib/scheduler.js` 的 `shouldLogSkip`），不往 `events.jsonl` 里写噪音。

新增 `test/boot.test.mjs` 一条用例盯这个函数（同小时同原因静默、换小时再记、换原因再记、跨日再记），`test/tools.test.mjs` 里原来「read_image 缺失只提示、不算失败」的断言改写成「全局表查不到但收窄认过 → 绿；没挂 attachments → 红；什么旁证都没有 → 判不准、不报红」。

**整个家可以搬到别的盘**（用户 m06510：「有些人不想让插件的工作区在 C 盘，他们可能想要挪到 D 盘、E 盘」）。

以前状态库写死在 `~/.dsh-fish`。现在设置页「数据」页签的「数据在哪」那一格下面多了一张「迁移工作区」卡：点「选择文件夹…」调宿主的目录选择器（web 模式下退化成手填路径），选定后点「搬到这个文件夹」就开始搬。

搬的动作是**复制 + 逐字节核对**，不是剪切：先按相对路径整棵复制（跳过 `logs/`、`backups/`、`dsh-fish-backups/`、`node_modules/`），再把每个文件的字节数跟源目录比一遍——有一个对不上就整体判失败，**且不写指针**（等于没迁过，她还住在原地）。核对通过才写指针 `~/.dsh-fish-location.json`（刻意放在数据目录**之外**，否则它跟着数据一起被搬走就等于没存）。

旧目录不删：搬完把源目录改名成同级的 `dsh-fish-backups/moved-<时间戳>/`，跟重置、恢复一个规矩。旧的工作区注册会一并清掉（`workspaceController.delete`），旧会话归档，不会在侧栏留下一个指向空路径的「大肥鱼的家」。

**重启 DSH 才生效**——状态库路径在插件启动时算一次并分发给十几个模块，中途换路径会让一半模块继续写老地方。卡片上直接写了这一句。

**拒绝的四种情况**：目标是空的、或者不是文件夹；目标里已经有一份非空的 `dsh-fish`；目标在你现在这个家里（会把自己装进自己）；目标会把你现在这个家套进去。平级搬（比如 `C:\Users\你\.dsh-fish` → `D:\大肥鱼`）是允许的，那是最常见的一次搬迁。

`DSH_FISH_HOME` 环境变量仍然优先于指针文件：想临时指到别处（跑测试、开第二份档）不用动配置。

**导出包补上四样东西，下次「看不见画面」不用再靠猜**（用户 2026-10-28：「补三件事，让下次可判」——实际是四件，这里一并做完）。

另一台机器上反馈「她看不了视频画面」，导出包发过来却判不出来：里面只有配置里写的 7 个白名单名字、没有真正生效的工具列表、没有模型信息、也没有 `watched:` 记录，只能靠猜是被哪一条挡下的。现在「设置 → 大肥鱼 → 数据 → 导出运行记录」那份 txt 里多了四样：

1. **实际生效的 allow 列表**（`readRestrictState().effective`，`lib/restrict.js`）。`config.tools.allow` 只是「想放行」：收窄还没认过、宿主拒绝、这一局还没收到注册结果时，名单里写的名字一个都不作数。导出里两条都写——「实际生效: N 个（…）」和「名单里没生效的: …」，并注明停在哪一步（`applied` / `applied-late` / `deferred` / `failed`）。
2. **模型与图像能力**（新文件 `lib/modelinfo.js`）。从会话投影取她那条会话最后一次用的 provider/model（`sessionProjections.snapshot` 挂了就退 `stateOf`），再问 `llm.resolveModelInfo` 要 `inputModalities`：声明了 `image` 是「支持」，只声明文本是「不支持」，拿不到（没有该服务、模型没报、调用抛错）一律「说不准」并写明原因。**三态，不猜**——把「说不准」写成「不支持」，会把排查的人直接带去换模型。
3. **`events.jsonl` 尾部**（`tailEvents`，最近 60 行 / 上限 256KB，脱敏后附）。`watched:` 与看画面的失败记录都在里面，能对上额度是怎么用掉的、卡在哪一步。
4. **看画面每一步都写日志**（`lib/watch.js`）。设置关掉、视频号不合法、今日额度满、抽帧失败四个分支各写一行，成功也写一行（带 `used+1/cap`）。以前这条链路一个字都没有，用户那边出问题时导出包里完全查不出被哪一条挡下。日志给人看，可以写数字；工具回复给她看，仍然不许出现数字。

新增 `test/modelinfo.test.mjs` 8 条（含「模型没报 `inputModalities` 时必须是说不准、不是不支持」），`test/watch.test.mjs` 补 4 条盯日志写入（设置、非法视频号、额度满、抽帧失败）。

**修：状态卡片一分钟跳一条「醒了，但今天没有该问的事」**（用户 m06971：「现在一分钟跳一个记录，这是怎么回事」）。

调度层每 60 秒 tick 一次，候选池一空就写一条 `quiet:` 的 meta 事件记「今天不打扰」。这条事件既没有 `wake:` 前缀（`todayCounts` 数不到、「每天最多几条事件」拦不住它），也没做过「今天已经记过」的判断——所以从 0.1.0 起它一天能写几百条（实测 2026-10-27 有 142 条、10-28 有 96 条），状态卡整页刷成同一句。

两处改法：写入侧一天只记一条（`lib/scheduler.js` 先查 `quiet:<日期>` 是否已在事件流里）；读的时候按**本地时区**的日期折叠，旧档里已经堆着的那几百条各天只留第一条（`lib/status.js`）——事件流只能追加，不能靠删历史来修。折叠不能按 ISO 串切前 10 位：`at` 是 UTC，北京时间 07:25 与 08:00 会落在不同的 UTC 日子里，切串就合并不掉。

这一条**不是 0.6.1 引入的**，远端 0.6.1 也有；`growthDays` 只是间接相关（天数推得快 → 快速过阶段 → 候选池提前空 → 更早开始刷屏），`daily.events` 无关。新增 `test/status.test.mjs` 两条折叠用例。

新增 `lib/locate.js`（同步读指针，带 2 秒模块级缓存——`rootDir()` 是同步函数且被 `paths()` 的默认参数高频调用）、`lib/move.js`（`planMove` / `moveRoot` / `moveStatus`）、`test/move.test.mjs`（7 条）；`/dsh-fish/move` 的 GET/POST；`lib/store.js` 的 `rootDir()` 改为「环境变量 → 指针 → 默认」。

## 0.6.1 — 2026-10-28

**叫醒时先说清「现在几点、谁让醒」**（用户 m00974：屋子刚建好那天 16:06 她被叫醒，第一句是「大概不是我的时段」——用户以为是自己没给权限，去翻设置、还试了提权，后来看日志才知道是插件在收窄工具面）。

现在叫醒的处境开头先给时间与缘由（`lib/scheduler.js` 的 `wakeTimeLine`）：手动叫醒是「现在是 16:06。有人刚按了叫醒——这个点不在你平时的时段，是有人要你现在醒。」「现在是 20:43。有人刚按了叫醒，要你现在醒。」；定时唤醒是「现在是 20:43，这一次是你自己醒的。」空白屋子第一次醒来走的是另一条路（`wakeIfBlank`，没有处境段），就把时间与缘由直接写进触发语（`lib/wakeconst.js` 的 `freshWakeText`）：「（醒一醒。现在是 16:06，屋子刚建好，有人叫了你一声。）」

**身份文档补一句工具面**（`lib/persona.js` 的 `TOOL_BRIEF`）：「屋里只有这几样，不是被谁拿走了；别的东西伸手也够不着。」——她原来会把 7 个工具当成权限事故，以为「什么也动不了」。

工具面收窄的**设计**没有改：第一轮放开等于给一个陌生模型一个 shell，也违背「不让她莫名调工具」的原始设计。

**修：启动时工具面被收窄成 1 个**（2026-10-27 另一台真机，0.6.0）：日志里是「有 6 个名字宿主还没登记，先按认识的 1 个收窄」——宿主先建了她的 agent、插件的 6 个工具还没登记完，旧实现就把 `allow` 与报错里的已知名单取交集再收窄，交集只剩 1 个。那条会话从此只看得见 1 个工具，她调 `bili_look` 直接 `Error: unknown tool "bili_look"`，于是回答「我没法浏览 B 站」。`restrict` 只能减不能加，收窄错了没有回头路。现在：名字没登记齐就**这一次先不收窄**（兜底 guard 照旧在拦），每 200ms 再看一眼，齐了再收（日志报「收窄延后」）；15 次仍不齐就留到下一次会话，自检显示「暂未收窄」，不再假装成功。工具名快照也改成只增不减，防止 1 个名字覆盖全量名单（`lib/restrict.js`）。

**QQ 接入写进说明、白名单念给她听**（用户 m01371）：设置页「手上能用什么」补了「QQ 接入」一段——装一个社区现成的 QQ 桥接插件（比如 qq-bridge），在上面白名单填 `qq_send_message` / `qq_get_unread_messages` / `qq_reply`；本插件不直接提供 QQ 桥接功能，两个一起装、在这里放行就可以；不知道装的那个插件实际工具名，可以先问大肥鱼。白名单输入框的 placeholder 也给了同样的示例。身份文档改成 `toolBrief(extra)`（`lib/persona.js`），把 `config.tools.allow` 里的名字念给她听——原来她不知道自己多了这几只手，就算放行了也不会用。

**事件流变长后不再卡住 JS 主线程**（issue #3，bigbigyu-Blue）：`deriveSelf` 的 `mentions` 原来对每条判断遍历全部 utterance 并重建字符串，`detectTensions` 两两比，`stability()` 每次抽样又全量重算——事件流到 500 条时一次派生是秒级，观测台与心跳会一起卡住。现在 `stripNegation` 与字符二元组先算一次复用，`mentions` 与 `detectTensions` 改成倒排索引只算「共享至少一个二元组」的候选对，`stability()` 按「事件流指纹 + 参数」缓存（新增 `clearStabilityCache()` 供测试用）；判定口径、同分顺序与输出都没变。

**提示词不再承诺取不到的素材**（issue #4，同一作者）：`first_bet` / `test_first` / `why_say` 三条模板里写死了「（下面附素材）」，但不在上网时段、今日次数用完、风控冷却、网络失败时素材本来就没有——她会收到一句「下面附素材」，下面什么都没有。现在模板只描述处境（「今天可能有点东西摆在你面前，也可能什么都没有」），真取到素材时仍由 look 段自己说明。

## 0.6.0 — 2026-10-27

**领养人和登录账号拆成两个人**（用户 m00551：「导入 cookie 的时候会顺带把账号名自动填入『领养人认证』，而且不允许更改，能否让 cookie 归 cookie、领养人单独填写——这样我可以用小号放 cookie，大号接收艾特」）。

以前只要存一次 cookie，或者点一次「测试能不能说话」，插件就会拿这份 cookie 探到的 mid 与昵称覆盖「领养人」那两格。拿小号当她的嘴时，评论里 @ 的是小号、自检里显示的是小号、用户手填的大号下次保存又被冲掉。

现在 `owner.json` 多一格只读的 `account`（`mid` / `name` / `savedAt`）：「这份 cookie 登的是谁」只记在这里，存 cookie 和测试都只写它，绝不碰 `mid` / `nickname`。领养人只由用户手填，决定 @ 谁。判断「哪条评论是她自己补的」改用 `account.mid`（`lib/comment.js` 的 `loginMid`），老数据没有 `account` 时仍退回 `owner.mid`。

界面：领养人卡片写明「这是要 @ 的账号，一般填大号，和 cookie 无关」；cookie 卡片只读显示「登录账号：xxx（uid …）」；点「测试能不能说话」不再把输入框改成小号。自检的「B 站登录」显示登录账号，而不是领养人昵称。

**重置后的首批不再固定四条**（用户 m00763：「那个首次刷视频，不要都去刷入站必刷榜了……阶段 1 混入排行榜/分区，不再只吃一份固定片单，天然就分散」）。以前阶段 1 只吃「入站必刷」——98 条全站老片的固定榜；而重置会清空事件流（seen 变空、阶段回 1），所以每次重置刷到的首批都是同样四条。现在阶段 1 改成老片 + 热门 + 全站排行 + 轮换的分区排行四路混（`lib/browse.js` 的 `SOURCES[1]` 与 `RANKING_TIDS`，分区数由 `browse.rankingTids` 控制、默认 2）；候选进 `rankVideos` 之前先 Fisher-Yates 打散，分数并列时的先后不再固定成接口顺序。分数不并列的仍按分数排——打散只负责「同样值得看时不再总是同一批」。这两笔一起并进 0.6.0 发布（0.5.10 没有单独发行）。

## 0.5.9 — 2026-10-27

**「判断漂移」原来那把尺子量错了东西**（用户 m05785：「稳定 0.00 · 一致 1.00 · 新鲜 0.00，为什么剩下两个全是 0，是不是这 3 个数字都是 1 最好」）。

三个数里有两个是**样本不足时的默认值**被当成读数印了出来：刚重置的一局里她还没有判断（稳定 → 0）、说过的话不足两条（一致 → 1）、没有七天以前的老话（新鲜 → 0）。更要紧的是稳定那把尺子本身有问题——它量的是「抽掉几条判断后 `needs` 三项变多少」，而 `needs` 是拒绝过几次、改口过几次、重聚过几次这些**内部计数器**的映射，不是「她这个人」。刚开局的号里三项常年 0，抽掉谁都是 0，于是稳定永远是 0.00。一个永远为 0 的尺子等于没有尺子。

这次动三件事（用户 m05868：「该测的是「少给她几条她信的事，她还是不是她」，123 都做」）：

- **① 换尺子：稳定 = 抽掉几条她还在拿着的判断，她还是不是她。** 新增 `lib/quality.js`（依赖方向 quality → derive + persona，不能再塞回 derive，否则 `selfdoc.js → derive.js` 那条已有边会绕成环）。做法是随机抽 k 条判断（连同源头事件），重算一遍她的自我描述，和原来的比相似度：接近 0 = 那些判断只是记账，抽掉几条她一个字都没变；接近 1 = 全押在少数几条上，少一条就是另一个人。比较前先剔掉「你是谁 / 现在 / 不能做的 / 你还不会的 / 他说的事和你记得的不一样时」这些**永远不变**的骨架段，否则分母被常数撑满，真实变化全被稀释成 0.0x。
- **② 样本不足时不再印假分数。** `stabilityBand()` 把「还没攒到判断，测不出来 / 只有 N 条判断，抽掉一条就是一大块 / 这些判断还只是记账… / 长在这些事上… / 全压在这几条上…」写成一句人话；客户端对一致与新鲜同样处理（「还没有跨阶段的话可比」「最近一周没说过话」「还没有七天前的老话可比」）。数字只在真能测时才印。
- **③ 界面文案改口。** `QUALITY_HELP` 原来写「越接近 1 越好」——错的。这三个不是考卷分数，是体检值，稳定太高也是病（押得太死）、一致恒为 1.00 也可能是她一直没长新东西。

另：`lib/derive.js` 里的 `stability` 移除（旧尺子），改由 `lib/quality.js` 导出同名函数；`lib/observe.js` 的 `/state` 直接把 `band` 一并算好传出，客户端不含阈值（阈值只该有一处）。

**它的三个值现在分三行显示**（用户 m06107：「这三个参数分成三行显示，现在排成一行有点拥挤」）。原来三个值拼在同一条 `rowTip` 的值里，稳定那句判读又长——一长串挤在一行里，读的人分不清哪个是哪个。现在「判断漂移（三个诊断值，不是分数）」占一行做小标题，下面三行各自是「稳定 / 一致 / 新鲜」，每行右边一个 ⓘ 说清这一项到底量什么。版本号不升，仍是 0.5.9。

新增回归 1 条（`test/client.test.mjs`）：三个值必须是三个独立的行，不许再拼成一行。

**能测出来的时候，数字要跟判读一起印**（用户 m06350：「为啥我重启了之后，界面还是显示的长在这些事上，抽掉一条少一块，就没有给数值啊」）。三行改完之后，`qStability` 让 band 直接把数字盖掉了——能测出 0.16 的那一局，界面上只剩「长在这些事上，抽掉一条少一块」，读的人以为根本没测。现在改成 `0.16 · 长在这些事上，抽掉一条少一块`：数值在前、判读在后。样本不足时仍然只给判读（那种 0.00 是默认值，不是测量结果，不能当数字印）。改的是同一条回归用例的断言：从「有 band 时不该印数字」改成「能测出数值时数字必须印出来」。

回归 634 条：632 过、2 条已知跨文件假红（`cover: fetchCover 拿不到图时返回空串，不抛`、`ULID 单调递增，且能从 id 反解时间`，单文件跑各自全绿）。

## 0.5.8 — 2026-10-27

**「回顾」这一步开始要凭证**（用户 m05409：「那就动第一层和第二层，回顾也允许她说我想不清楚。第三层不做」）。

背景是另一只大肥鱼对项目的评价里最准的一条：事件流无限增长，真正进上下文的只有 `deriveSelf` / `persona` 那层摘要，所以「摘要」就是她的自我；而 LLM 太擅长把零散经历讲成一个漂亮的成长故事。它担忧的是**叙事漂移**——不是她说谎，是每次读到自己的摘要都顺着它说，说完又追加成新事件，三十天后方向已偏。

这次动的是两头：

- **第一层：refs 要能对上，不只是写着。** `lib/schema.js` 的 `validateEvent` 新增 `knownIds` 参数，`revise` 和 `narration` 的每个 ref 都必须在事件流里真实存在，否则 `REF_NOT_FOUND`。以前只查「非空」，于是「我改的是哪一条」很容易退化成仪式——随便填个 id 就过了。`lib/store.js` 的 `appendEvent` 在 `type` 是这两种时读一遍全量事件、把 id 集合塞进 ctx；读失败就退化成老行为（`knownIds = null`），不能因为查不了就拒收她的正常写入。
- **第二层：回顾型 `narration` 也要 refs。** 以前 narration 随便写，于是「我变成了什么样」可以凭空编。现在要么用 `refs` 指到 `her_recall` 翻到的具体几条，要么直说「我没想清楚」。**「我没想清楚」是放行的**——那句本身也是真的，不该因为没想清楚就什么都不许写。判定用 `isBlankNarration()`：必须是 60 字以内、且整句就是一个「没想清楚」的说法（`我想不明白` / `说不清` / `想不出什么` / `我还没想好` 等）；拿它当开头再接一整篇自传不算，仍要 refs。
- **`her_recall` 现在每条都带 id**（`lib/recall.js` 的 `searchEvents` 加 `id` 字段、`renderRecall` 在正文后用括号附上）。没有 id，第二层就只是逼她编。`RECALL_BRIEF` 常驻身份文档的那段也加了一句「每条后面小括号里是它的 id——要改口、要做回顾时，用它指回去」，否则她会以为那是乱码。
- `lib/persona.js` 的 `sleepPrompt` 与常驻的 `SLEEP_BRIEF` 同步改：要求 refs，并写明「真的没想清楚，直接写「我没想清楚」——那句也算数，不用带 refs」。只改周提示不改常驻做法的话，平时那一轮她根本不知道有这要求。
- `lib/capture.js` 的 `growth_commit` 工具说明与 `refs` 参数描述跟着改。

**第三层（要求每句自我认知都挂凭证）不做**，理由：很多「我变了」是弥漫性的，硬挂凭证会让回顾变成拼凑，产出变少而质量更难判断。

新增回归 5 条（`test/schema.test.mjs`）：refs 指不存在的 id 被拒 / 不传 knownIds 时保持老行为 / narration 无 refs 被拒但 5 种「没想清楚」放行 / 「我没想清楚」+ 长自传仍被拒 / utterance 不受影响。「她不能用工具写系统侧类型」那条随 narration 新规则补了 refs。

回归 630 条：628 过、2 条已知跨文件假红（`cover: fetchCover 拿不到图时返回空串，不抛`、`ULID 单调递增，且能从 id 反解时间`，单文件跑各自全绿）。

## 0.5.7 — 2026-10-27

- **「下载交接单模板」按钮挪出来，任何时候都能看到**（用户 m05086）。原来它挂在「这一局还能接、并且已经展开粘贴框」那一个分支里——已经养着一只鱼的人（`canImport` 为假）走的是另一条分支，页面上根本没有这个按钮。用户原话：「我没在导入其他人的大肥鱼那里看到这个交接单模版下载的按钮」。
  - 现在按钮提到卡片正文末尾，**跟「这一局能不能接」完全解耦**：能不能接、要不要接、有没有展开粘贴框，都不影响下载。旁注一句「不管这一局能不能接、要不要接，模板随时能下载」。
  - 「不能接」那条分支的说明补一句「模板可以先下载下来备着」，免得人以为没戏了。
  - 顺手把 `importNote`（下载/导入的结果提示）也提到这一层，下载成功或失败的反馈在任何分支下都看得见。
  - 「粘贴交接单」按钮保持不变，仍只在能接的时候出现——那一支才需要贴。

回归 625 条：623 过、2 条已知跨文件假红（`cover: fetchCover…`、`ULID 单调递增…`，单文件跑各自全绿）。

## 0.5.6 — 2026-10-27

- **把「接过来什么、不接什么」写成用户能听懂的话**（用户 m04402）。原来说「不过来的：过了多少天、长出了哪些判断、身上的疤、拒绝过什么」，太短，没说清后果——现在逐条写明：
  - 天数：本插件按时间推进事件，非本插件原生的那一只要从第一天重新算。
  - 判断：计数为 0。原提示词里规定的一些认知她依然记得，但往后在本插件的事件循环里可能被更新、优化、忘掉一部分。
  - 疤、拒绝记录：同上。
  - 日记、B 站登录 cookie：不带。
- **新增一段说明**：如果你原本的大肥鱼带了好感度这类数值设定，进入本插件后她看不到自己的好感度，本插件也不允许你通过命令改她的人设——原来可以为所欲为，到这里关系只能靠真实交互推进，也没法随口命令她换一种人设。这段话是**说明**不是控件，`test/client.test.mjs` 那条「不该出现好感度/亲密度」的红线扫描会先把这一段剥掉再扫（剥不掉就红，防止哪天这段被悄悄删掉）。
- `README.md` 开头那句改成：「本项目的人格并非角色扮演的形式，没有人设配置菜单。默认从空白开始养起，但可导入你已经养过的大肥鱼人设提示词，继承大肥鱼的人设并在本插件环境内进行成长，具体请看本插件「数据」页面介绍。」
- `README.md` 的「不会过来的」一段同步改细；并新增「如果你带了好感度这类数值设定」一段。
- `market/ssamurias__dsh-fish.yml` 的中英文首段同步加上「也可以导入你已经在别处养过的大肥鱼人设提示词，继承她的人设在本插件里继续成长」（英文首屏仍在 160 字符内，句子完整）。
- **交接单模板可以一键下载**（用户 m04565）。设置页「数据 → 导入人设」多了两个按钮：「下载交接单模板」把一份 `.md` 存到本地，「粘贴交接单」才是真正导入。模板不是给人照填的表格，是**写给对面那个 AI 的说明书**——上半写明怎么写（第二人称、只写已经稳定成型的样子、不写形容词清单）、不要写什么（不写好感度、不写剧情、不写"你总是很温柔"这种笼统画像），下半才是「你是谁 / 称呼 / 工具」三节空表。把它发给现在养着她的那个 AI，它填完你再把填好的部分贴回来。
  - 解析时说明书的部分一个字都不能进她的人设：整份模板贴回来（还没填）会被判为「空」，填好之后说明书段落也会被丢掉。`test/import.test.mjs` 加了 3 条把这件事钉住。
- `README.md` 顶部加了视频讲解链接（19 分钟，B 站 BV1oTnZ6LEtc）。
- **交接单写明了字数区间**（用户 m04868）。原来模板里写的是「2000 字以内（上限 6000 字）」，那句是错的：事件流的正文上限就是 2000，超了直接拒收；而 1800 字的身份预算里人设占满之后，「判断、疤、立场」这些往后会长出来的段落会被整段挤掉。现在模板、设置页导入卡、README 三处统一写成「1200～1500 字」，并说明超了会怎样。`test/import.test.mjs` 加一条把这三个数字钉在模板里。
- **交接单里的小节名前后对不上了**（用户 m05009）。模板的「怎么写」那段说的是「『你自己』这一节用第二人称写」，但下面真正的空表标题是 `## 你是谁`，解析器认的也是「你是谁 / 人设 / 设定 / 她是谁 / 交接单」。照模板填完贴回来，`### 你自己` 这行会被当成人设正文收进去，变成她身份文档里的一行标题。两处都改了：模板正文统一成「你是谁」，解析器额外把「你自己」也认了——别人手里的交接单不一定按我们的模板写，多认一个词比少认一个词安全。新增一条回归。

回归 624 条：622 过、2 条已知跨文件假红（`cover: fetchCover…`、`ULID 单调递增…`，单文件跑各自全绿）。

## 0.5.5 — 2026-10-27

- **修「每次重启都再叫醒她一次」**（issue #1 报的第二个问题，@xidojiu 补充）。0.5.4 之前的 `wakeIfBlank()` 靠 `list()` 猜这条会话是不是空的：查不到这一行、且 `freshOnly` 为真，就当空白叫一声。问题在插件自己建的会话上**永远**是这个形状——它不会被设成「当前会话」，宿主也就不把空的非当前会话放进可见列表——所以这条分支每次启动都命中，每次重启都白叫一声。
- 改法：不再猜，**自己记账**。叫成功之后把这一条 `sessionId` 写进 `home.json` 的 `wokeFor`；同一个 id 再来直接收手，返回 `why: '这一局已经叫过了'`。
  - 只记**成功送达**的那一次：宿主的 `prompt` 收下这一轮就 resolve，收下就一定会跑出内容；抛错则不写，下次启动还会重试（0.5.4 之前漏传 signal 那种情况不会留下假标记）。
  - 换会话（`rotateTalkSession` / 重置后重建）就是换了 id，自然重新算一次。
  - `root` 为空时不记账——测试与只读调用回到原来的行为，不写文件、也不挡第二次。
- `wakeIfBlank` 新增 `root` 参数，两个入口（`lib/index.js` 启动、`lib/observe.js` 的 `POST /reset`）都传进去。
- 新增 4 条回归：同一条会话不会被叫第二次 / 换了会话重新算 / 没给 root 不记账 / `prompt` 失败不记账下次重试。`test/wake.test.mjs` 14 条全绿。

回归 622 条：620 过、2 条已知跨文件假红（`cover: fetchCover…`、`ULID 单调递增…`，单文件跑各自全绿）。

## 0.5.4 — 2026-10-27

- **修「豁免会跟着备份/恢复跑」的漏洞**（用户 m03769）。0.5.3 把「这一位是接来的，不受那两条提示词禁令约束」写成了一个配置项 `persona.bansMuted`，存进 `config.json`。问题是 `config.json` 会跟着**备份与恢复**一起被搬回来，也会被重置时抄回新库——结果一条原生养大的鱼，只要恢复过一次「导入过」的档，就永久拿到了豁免。用户原话：「检测到是使用接一只别人养过的大肥鱼这个导入的，就忽略禁令，通过我们自己插件的备份与恢复的就不忽视」。
- 改法：豁免凭据从配置挪进**事件流**。导入时多写一条 `meta` / `import-mark:<来源>`；`deriveSelf` 解析出 `model.persona.{imported, source}`；身份文档（`lib/selfdoc.js`）与观测台（`lib/observe.js` 的 `/memory`）判定时**只读 model，不读 config**。
  - 事件流只能追加：原生那一局从头到尾没有这条记录，恢复多少次也不会长出来。
  - 重置时整个状态库被 rename 走，新一局天然没有这条——`reset.js` 里原来那个 `clearImportedMark` 调用随之删掉（不再需要）。
- 删掉 `DEFAULTS.persona`（整组）、`clearImportedMark()`、以及 `/import` 里写 `persona.source` 的那段；来源改为作为参数直接传给 `applyHandover`，与标记一起写进那条 `meta`。
- `/import` 的 GET 改为从事件流算 `persona`，不再回显配置。
- 新增 4 条回归：凭据写在事件流里 / 原生局没有豁免 / **配置里写着豁免也没用（模拟恢复来的 config）** / 重置后新一局没有豁免。`test/import.test.mjs` 13 条全绿。
- 设置页导入卡加一句：「这个豁免只认从这里接过来这一个动作，备份恢复搬回来的一分豁免都不会有」；README 的导入小节同步。

回归 614 条：612 过、2 条已知跨文件假红（`cover: fetchCover…`、`ULID 单调递增…`，单文件跑各自全绿）。

## 0.5.3 — 2026-10-27

- **新增「接一只别人养过的大肥鱼」**（用户 m03170 / m03201）。原来的承诺是「没有人格设置」，现在的说法是「**默认没有人格设定，但支持导入**」：默认还是一张白纸、靠事件流长大；如果你手里有别人养过的交接单，可以把它接过来，让她从那份设定继续长。
  - 接过来的三样：**人设正文**（写进 `seed`，成为「你是谁」）、**称呼**（写进一条 `meta` 事件，`import-name:` 前缀）、**工具白名单**（与现有取**并集**，不会挤掉她自己的那 6 个工具）。
  - 不过来的：天数（**从第 1 天开始**，`growthDay` 只认 seed 的时间戳）、判断与疤、拒绝记录、日记、B 站登录、每天刷几次的配置。
  - 带过来的设定**不受我们那两条提示词禁令约束**（「不可以用亲密度/好感度这类词」和「还不会撒娇卖萌」）。实现是 `selfdoc.js` 的 `withBans: false`，物理层两条（不读自身数值、不改自己）仍在工具层拦着，不豁免。
  - 只在**还没起点**（没有 `seed`）的一局生效。已经有起点时接口返回 409 并让他先重置——覆盖一个已经在长的她，这个决定不该由插件替他做。
  - 带过来称呼之后，我们第一天的起名事件 `name_offer`（条件是 `!m.name`）**自然不再触发**，不需要额外代码。
  - 重置时 `clearImportedMark` 会把 `persona.imported/bansMuted` 清掉——否则会出现「默认人设 + 别人的豁免」这种最糟的组合。
- 新增 `lib/import.js`（`parseHandover` / `applyHandover` / `clearImportedMark` / `IMPORT_TEMPLATE`）、`POST|GET /dsh-fish/import` 路由、设置页「数据」页签里的导入卡，以及 `test/import.test.mjs` 11 条用例。
- 交接单里的 `# 交接单`「## 你是谁」只是外壳标题，解析时丢掉、只收正文——否则身份文档里会叠出三层重复标题。
- `persona` 这组配置**不进 `/config` 白名单**：它只由导入动作写，不给一个「关掉那两条禁令」的开关。

回归 612 条：610 过、2 条已知跨文件假红（`cover: fetchCover…`、`ULID 单调递增…`，单文件跑各自全绿）。

## 0.5.2 — 2026-10-26

- **修「她怎么叫我」永远不更新**（用户报告：已经让她改叫「时梦尘」，她答应了，设置页状态栏还是「还没想好」）。
  两处都是识别规则写窄了，不是她没记住：
  - 旧规则只认「称呼你 / 叫你」。真机上她写的是「**他给了自己的名字：时梦尘**，说他认这个名字。以后叫他时梦尘。」——三种说法一种都没命中。现在「称呼他 / 叫他 / 称他」和「他（给了）自己的名字：X」都认，但**不认「他给我起了名字：大肥鱼」**（那是她自己的名字）。
  - 旧规则只取第一次命中的。她先猜过「搭屋的」「开灯的」，被否掉之后才定下他给的名字，于是永远停在最早那个上。现在**后来的盖掉先前的**，以最近一次为准。
  - 补了句尾剥壳（「我叫你老张好了」→ 老张）和代词挡板（「以后叫他他吧」→ 不算）；`的` 不剥——「开灯的」剥掉就成了「开灯」。
- 顺带改掉三处过时注释（`lib/scheduler.js`、`lib/store.js`、`lib/readme.js` 里还写「身份由 home/AGENTS.md 承载、宿主每轮注入」）：0.4.x 起身份走 `systemPrompt.section`，`AGENTS.md` 那个通道早已不用，`selfdoc.js` 还会把它 unlink 掉。

回归 601 条：599 过、2 条已知跨文件假红（`cover: fetchCover…`、`ULID 单调递增…`，单文件跑各自全绿）。

## 0.5.1 — 2026-10-26

对外措词统一成用户视角（市场简介、README、插件内说明、技术规范同一套说法）：

- 「她的人格不是配置出来的」→ **没有人格设置，通过事件流长大**。
- 「没有设置面板」→ **没有人格设置**。
- 「用自己写的客户端刷 B 站」→ **她可以自己刷 B 站**。
- 「事件流只追加，是唯一真相源」→ **事件流不能删除记录，是唯一可信源**。
- 「会写不给自己看的日记」→ **会写日记给你看**（`diary.visible` 默认仍是关的，打开开关就能读；文案与设置页说明同步改成这个意思）。
- 「四个阶段全部走完之后才开始攒立场清单」→ **四个阶段完成后才会开始有立场**。

改动文件：`package.json` 描述、`README.md`（事件流与 stance.js 两行）、`lib/readme.js`、`AGENTS.md`（第 4、5 节）、`lib/client.js` 日记说明、`lib/browse.js` 与 `lib/schema.js` 注释。**不涉及任何行为改动**，回归 600 条里 598 过、2 条已知跨文件假红。

## 0.5.0 — 2026-10-26

- **修「图片无法预览」**（用户 m01408：「为什么我在和大肥鱼对话的时候，提示我图片无法预览」）。
  根因是**反斜杠路径**，不是文件缺失、不是权限、也不是跨目录读取。同一张图做了三组对照（2026-10-26 实测）：
  - `![x](C:\Users\me\.dsh-fish\media\sheet-….png)` → 显示「图片无法预览」
  - `![x](C:/Users/me/.dsh-fish/media/sheet-….png)` → 正常显示
  - 同一文件复制到工作区内、用正斜杠 → 正常显示
  宿主渲染 markdown 图片时把路径拼进 `/api/file?path=`，反斜杠在那一层取不到文件；
  跨目录读取本身没有问题（宿主文档明确写着「不限制目录包含关系」）。
  她照抄工具给的路径，所以**插件交给模型的路径一律改成正斜杠**：新增 `lib/posix.js` 的 `slashed()`，
  用在 `bili_watch` 的返回（`lib/watch.js`）、拼图路径（`lib/video.js`）、封面 markdown（`lib/cover.js`）、
  「他发了张图，在这儿：…」（`lib/say.js`）。内部读写文件仍用 `node:path`，行为不变。
  **注意：历史消息里已经写下的反斜杠图不会变好**，只有从这一版起新生成的消息能显示。
- 新增 `test/posix.test.mjs`（2 条）+ `coverLines` 的「不含反斜杠」断言；
  全量 `node --test --test-isolation=none` = 600 tests / 598 pass / 2 已知跨文件假红
  （`cover：fetchCover`、`ULID 单调递增`，单文件跑都绿）。

- **公开发布前的清理**：仓库里出现过的本机用户名统一改成 `me`（`lib/posix.js` 注释、`test/posix.test.mjs` 的三处断言、本文件里的两行示例）；`.gitignore` 补上 `owner.json` / `config.json` / `.dev`。
  历史提交逐条查过：只有测试用的假凭据（`SESSDATA=abc123`、`abcdef123456` 这类），**没有真实 cookie**；`lib/owner.js` 是读取与打码逻辑，不含任何账号数据。

## 0.4.9 — 2026-10-26

- **改掉重置后那句不诚实的提示**（用户 m01426 真机反馈：「上面说什么重置了，应该能在侧边栏看到对话了，但是我实测不行，还是要点叫醒大肥鱼才行」）。
  0.4.3 起重置会顺手建新会话、还会 `wakeIfBlank` 叫一声，提示就写成「侧栏里应该已经冒出「跟大肥鱼说话」」——
  但宿主的可见性规则是 `if (session.blank && session.id !== current) return false`，插件用 API 建的会话
  **永远不会成为 current**，所以自动叫一声并不保证它出现。实测只有人自己点「叫醒大肥鱼」才会出现。
  现在三处文案统一改成「点一下「叫醒大肥鱼」，她开一次口，侧栏里才会出现这条会话」：
  - 重置按钮上方的说明（`lib/client.js` 重置卡）
  - 点完的即时提示（`doReset` 的 `tail`）
  - `/reset` 返回的 `note`（`lib/observe.js`，给不走前端的调用方）
  行为没改（仍然尝试自动唤醒，成功算白赚），只是不再承诺侧栏会自己冒出。

## 0.4.8 — 2026-10-26

- **重置不再把配置也恢复出厂**（用户 m01201：「不仅仅是cookie不变，那个配置也应该不变，就是包括上网、成长的相关设置」）。
  `resetAll` 的 `CARRIED` 从 `['owner.json', '.dev']` 扩到 `['owner.json', 'config.json', '.dev']`：重开一局搬走的是
  她经历过的事（事件流、日记、屋子、备份），不搬「这台机器怎么待她」——每天醒几次、上网时段与额度、成长节拍、
  日记可见性都原样留着。备份里同样还有一份。
  - 回归补强：`test/p4.test.mjs` 的「重置把钥匙留下」用例改成同时断言 `owner.json` 与 `config.json`
    （`wakesPerDay` / `browse.perDay` / `memory.sleepEveryDays`）在新库与备份目录里都在。
- **日记栏一天一页，多了自动出翻页**（用户 m01201：「每天的日记都单独归类」「我倾向于自动出现翻页按钮」）。
  原来观测台一次把 30 天正文全塞进一个 `<pre>`，日子一多既慢又没法看。现在：
  - `/diary` 默认只回 `dates`（日期目录，新→旧）+ 最新那一天的正文；`?day=YYYY-MM-DD` 单独取一天，
    那天没有就 404。不可见时仍然只给 `lockedDates`，开关语义没变。
  - 页上多天时出现「← 更早　2026-10-20　1 / 12　更晚 →」，单天时只显示日期；翻过的页缓存在内存里，
    30 秒轮询只刷新当前页，不会把正在看的那页弹走。
  - 新增回归 1 条（`test/boot.test.mjs`「日记可见时一天一页：默认只给最新一天，?day= 取指定那天」）：
    默认只带一天、指定 `day` 只回那天（不混进别的日子）、不存在的日子 404。
- 全量 `node --test --test-isolation=none` = **598 tests / 596 pass / 2 fail**，两条仍是已知跨文件假红
  （`cover：fetchCover…`、`ULID 单调递增…`，单文件跑都绿）。

## 0.4.7 — 2026-10-26

- **叫醒消息不再派活**（用户 m00928 原话：「叫醒内容太多，就给改到常驻身份文档」）。
  原来一条唤醒消息里连着两段祈使句手册：`diaryPrompt` 的「今天写日记…写今天发生了什么、你注意到什么」
  和 `sleepPrompt` 的「这一周过去了…不要总结」。她在 `fish-wake-2026-10-26-manual` 里的 reasoning 是
  「需要做的是：说一句…然后写日记」——那不是醒来，是领工单。
  现在：**做法**常驻在身份文档（`persona.DIARY_BRIEF` / `SLEEP_BRIEF` → `selfdoc.renderSelfDoc` 的
  「## 平常会做的事」两节），**时机**只留一句 `SLEEP_TODAY`（「（今天停下来，想一想。）」）。
  日记提示整段从唤醒消息里删掉——她每天都记，不需要每次醒来被念一遍。
- **新增「让她去刷 B 站」按钮，仅本机测试版**（用户 m00928：「仅在本机的测试版生效…我需要用这个按钮
  来测试刷 b 站功能能不能生效，正式版不会有这个按钮」）。
  判据是状态库根目录下的 `.dev` 文件（`lib/devmode.js`）：在则 `/state` 返回 `dev: true`，设置页状态卡
  多出一个按钮；不在则前端连节点都不生成。`.dev` 进了 `resetAll` 的 `CARRIED`，重开一局不会把测试开关弄丢。
  按钮走 `POST /wake?focus=browse`：跳过 `plan()` 的「今天该不该醒」，并让 `lookBeforeWake` 绕过上网时段与
  `perDay`（`deps.forceBrowse`）——不绕过风控，那不是功能开关。
- 新增回归 3 条（`test/nudge.test.mjs`）：forceBrowse 在时段外/额度用完时仍然去取素材；同配置没有 forceBrowse
  时一次都不发（证明闸门没被顺带拆掉）；`devMode` 只认 `.dev` 文件。

## 0.4.6 — 2026-10-26

- **修掉「她刷不了 B 站」的真凶**（用户 m00751 的现场证据）：`lib/look.js:47` 原来是
  `(await readEvents(root).then((r) => r.events)).catch(() => [])` —— 括号把 `await` 一起圈进去了，
  `.catch` 就落在**已经 await 出来的数组**上，数组没有 `catch` → `TypeError: (intermediate value).catch is not a function`。
  工具把它当成"这次没看到什么"返回给她，她连试两次都只得这一句，日记里还把它写成了"世界没让我看"。
  现在改成 `await readEvents(root).then((r) => r.events).catch(() => [])`，实测首页三条正常出来。
- **重置不再把 B 站 cookie 一起封存**：`resetAll` 把整个 `~/.dsh-fish` rename 到备份，
  `owner.json`（SESSDATA 等登录凭据）也在里面，于是「重开一局」之后她当场变成未登录。
  现在 rename 之后把 `owner.json` 抄回新状态库（`CARRIED = ['owner.json']`），备份里那份照旧保留。
  理由：她是换了一辈子，不是换了台机器——钥匙跟人走，记忆不跟。
- 新增回归 1 条：重置后 `owner.json` 在新状态库里、且封存目录里仍有一份（`test/p4.test.mjs`）。

## 0.4.5 — 2026-10-26

- **叫醒不再把对话扔进「未分组」**：`wakeNow` 原来硬编 `fish-wake-<日期>-manual-<ts>` 当会话 id，
  宿主不认识这个 id，就按 cwd 另建一条 —— 那条会话不在任何工作区的 `sessionIds` 里，侧栏只能丢进「未分组」，
  用户在「大肥鱼的家」里根本看不见（m00507）。现在先 `talkSessionId` 取屋里那条会话，真拿不到屋子才退回独立会话，
  并且 `log` 写明「会落进未分组」。
- **触发语从「……」改成「（醒一醒）」**：她真是把它当成用户发来的一句话去猜。
  会话 `fish-wake-2026-10-26-manual` 的 reasoning 原文：「用户发来的只有一个省略号，"……"，没有实质请求。」，
  侧栏标题还被 first-prompt 模型生成成 `Error`。现在触发语是括号旁白；`scheduler.js` 另加 `WAKE_HINT`
  进 `fish:wake` 段：「对话里那条括号里的短句不是用户说的话，是叫醒你的信号」。
- 身份文档新增「## 被叫醒的时候」一节（`selfdoc.js`）：说明括号短句是系统信号、不是用户的话。
  必须常驻在身份里——手动唤醒走 `wake()` 会带 `WAKE_HINT`，但启动时的 `wakeIfBlank` 不走那段，
  只放对话里盖不住两个入口。
- 新增 2 条回归：有屋子时必须落在屋子会话里、不得再造 `fish-wake-*`；屋子没了才退回独立会话且必须 log。
- 已知限制：宿主没有把已有会话挂回工作区的接口（`workspace/*` 只有 create/delete/rename/archive/pin），
  已经掉进「未分组」的两条旧会话只能右键归档，挪不回来。

## 0.4.4 — 2026-10-26

- **修掉「重置完看不到新会话」的真正原因**：宿主的侧栏可见性规则是
  `if (session.blank && session.id !== current) return false` —— 空白会话只在它是当前主视图会话时才显示。
  插件用 API 建的会话不会被设成当前会话，于是它一直藏在列表外面，点多少次重置都「没有新会话」（m00331）。
- `lib/home.js` 新增 `wakeIfBlank(ctx, { sessionId, freshOnly })`：查 `sessionController.list()` 的 `blank`，
  确实空白就发一轮 `WAKE_TRIGGER`（与 scheduler 同一句），让她动起来；有内容则一个字不说。
  判断失败时保守降级：只有刚建出来的会话（`freshOnly`）才按空白处理。
- **只在两个入口叫**：`index.js` 启动、`observe.js` 的 `POST /reset`。
  不放进 `bootstrapHome`——`talkSessionId` 在屋子缺失时也会调它，那样每次「第一次说话」会多叫一次，
  她一轮被点两次火（`test/p3.test.mjs` 的「说一句话」正是这么红的）。`POST /reset` 的 `fresh` 一并带出 `woke`。
- 唤醒语挪到 `lib/wakeconst.js`：`scheduler.js` 已经 import 了 `home.js`，反过来 import 会成环。
- 新增 `test/wake.test.mjs`（6 条）：空白才叫、有内容不叫、查不到按有内容、list 抛错不穿透、
  缺服务明确降级、prompt 失败只记日志。

## 0.4.3 — 2026-10-26

- 重置后**立刻**开好新会话：`POST /reset` 在「搬状态库 + 归档旧会话」之后调用
  `bootstrapHome(ctx, { root, preset })`，返回值多带 `fresh: { wsId, sessionId }` / `freshError`。
  此前新会话只在 DSH 启动时（`bootstrapHome`）创建，所以点完重置侧栏是空的，用户不知道该去哪说话（m00260）。
- 前端重置提示改为「侧栏『跟大肥鱼说话』已经开好，点进去就能说话」，重置卡文案同步。
- 事实核对（写进回答，不进代码）：宿主 Session 行「...」菜单只有 分叉/归档/取消归档/置顶/取消置顶/复制 Session ID/重命名，
  **没有删除会话**；能删的只有「删除工作区」，且它只把工作区移出列表、会话归到「未分组」。

# 更新日志

这个插件的版本号含义很简单：**改了事件格式 = 次版本号进位**，其余都只是功能与文案。

---

## 0.4.2 · 2026-10-25

一句话：**「重开一局」现在真的干净了，暗色模式下的下拉框也看得见了。**

### 修复

- **重置之后侧栏还留着旧对话（用户报告）**：`resetAll` 只搬 `~/.dsh-fish/`，而宿主把工作区和会话登记在
  `~/.dsh/storages/workspace.json` 里——重启也不会变，因为那个注册表压根没被碰过。
  现在重置成功后会把「大肥鱼的家」里登记的所有旧会话交给宿主的 `workspaceRegistry.archiveSession(sid, { stopActivity: true })`：
  它们从工作区主列表移进「已归档」，文件一个字节不删；工作区保留（她下次启动还要住这间屋子）。
  宿主没有「删除会话」的接口（已核实只有 archive / unarchive / pin），所以能做到的边界就是归档。
- **暗色模式下所有下拉框变成白条、看不见字（用户报告）**：`select` 的背景写的是 `transparent`，
  原生控件在深色主题里用 UA 白底绘制，而字色是 `--dsw-alias-label-primary`（深色下接近白）——白底白字。
  改为 `--dsw-alias-bg-layer-1` 不透明层色 + `color-scheme: inherit`（跟随宿主在 `<html>` 上设的 dark/light），
  并给 `option` 显式补同组底色/字色。`input[type=time]` 同样的毛病一并改。
- **设置页的重置文案说了假话**：原来写「你在 DSH 侧栏那个会话也会一起被封存」，
  实际根本没碰宿主侧。现在写的是真的：旧对话移进「已归档」、工作区留着、下次启动是新会话。

### 工程

- 新增 `lib/retire.js`（`readHomeRecord` / `retireHomeSessions`）与 `lib/observe.js` 的 `/reset` 串联：
  resetAll 之前先读 `home.json`（之后它就被搬走了），成功后归档；归档不完整只回 `retiredError`，不让重置失败。
- 新增 `test/retire.test.mjs` 7 条：全量归档去重、home.json 被搬走时用提前读的记录、无 registry 时明确降级、
  老宿主单参数降级、单条失败不抛。
- 测试数 575 → 582。

---

## 0.4.1 · 2026-10-25

一句话：**把插件页的顺序改回来——原来的工具说明在前，「关于」在最后。**

### 修复

- **插件页三张卡的顺序**：现在是 ①手上能用什么 → ②为什么默认只放这几个 → ③关于（版本 / 检查更新 / GitHub 入口）。
  0.4.0 把「关于」卡插在了工具卡后面、工具说明前面，把这一页原来的阅读顺序打乱了——工具卡和它下面那段"为什么"本来是一件事（能看到什么工具、为什么只有这几个），不该被拆开。
  没有新开「关于」页签：插件页现在 8 个页签已经够多，为一个版本号再拆一页反而更散。

### 工程

- `test/ui.test.mjs` 新增一条断言锁住这个顺序（`toolsCard` → 「为什么默认只放这几个」→ `aboutCard`），并且断言「关于」不能紧跟在工具卡后面。以后谁改回去，测试先红。
- 测试数 573 → 574。

---

## 0.4.0 · 2026-10-25

一句话：**装完之后能自己查新版了，仓库也有了一个能点的入口。**

### 新增

- **设置 → 大肥鱼 → 插件 → 「关于」卡**：显示当前版本，一个「检查更新」按钮。
  - 只在**点按钮那一下**出网，插件运行期从不自动查、也不会自动下载或安装（`lib/update.js` 头注释写明这条边界）。
  - 六个源并发：GitHub API 的 `releases/latest` 与 `tags?per_page=1`，外加 `raw.githubusercontent.com` / `ghfast.top` / `ghproxy.net` / `cdn.jsdelivr.net` 四条镜像取 `main` 的 `package.json`。国内哪条通算哪条，多个成功取版本号最大的（镜像有缓存会滞后）。整批共用一个超时预算（默认 6 秒，界面按 8 秒请求）。
  - 六条全失败时说的是人话：「连不上 GitHub（等了 N 秒）。国内时通时不通，过一会儿再试，或者开一下网络工具。」不抛异常、不卡界面。
  - **读不到自己装的版本号时不谎报**：`known: false`，既不显示「有新版本」也不显示「已最新」，只把查到的最新版告诉你并说明判断不了。
- **同一张卡里的 GitHub 入口**：GitHub 商标小图（16×16 内联 SVG 官方 mark，不引外链、不加载图片）+「GitHub」文字，点开新标签到仓库。旁边一句「觉得有用的话，点个 Star 就是最实在的支持。」

### 工程

- 新增 `lib/update.js`（155 行）与 `lib/observe.js` 的 `/update` 路由。**路由里不接受客户端传 URL**——地址全部硬编码在 `update.js`，否则就是个 SSRF 口子。
- `/state` 的 `meta` 多带一个 `version`，界面从这儿读当前版本。
- 新增 `test/update.test.mjs`（12 条，用可注入的假 fetch，不发真网络）+ `test/p7.test.mjs` 1 条 + `test/ui.test.mjs` 3 条（守着「只在点击时查」「图标内联」「读不到不谎报」）。测试数 557 → 573。

---

## 0.3.0 · 2026-10-25

一句话：**把「立场」摆正位置，把仓库补成能给别人看的样子。**

### 修正

- **撤回「能力」这个维度。** `lib/capability.js` 整个删掉（78 行 + 78 行测试）。原因：原来的判据量到的是**说话风格**，不是能力——同一件事用不同语气说，得分就变了，那不是能力。这个维度留着会让「进阶」变成一个可以被话术骗过的数字。0.2.0 里它还在，属于发早了，这一版收回。
- **立场上限从「4 条进身份」改成「内部 12 条、进身份 8 条」**（`STANCE_MAX` / `STANCE_PROMPT_MAX`）。原来 4 条太少：一个走过四个阶段的存在，不会只有四句「我不做」。
- **同一件事说过不止一次、或因此栽过一次，才算一条立场**；两条打架时后来的算数，判不出先后的两条都不留。

### 界面

- **原理图重画**（`media/principle-loop.svg`，画布 1400×980 → **1400×1160**）：立场不再是一行小字，而是底部一块独立区块——浅绿底、左侧墨绿竖条、24px 标题「走完四个阶段之后长出来的：立场清单」，三列分别讲「什么算一条」「长什么样」「怎么不弄丢」。阶段 4 到它之间有一根橙色向下箭头，旁注「走完才有」。
- **图与说明文字不再重叠。** 加了一条分隔线（y=1068），三行图注下移到 y=1100/1122/1144；`figcaption` 上边距 6px → 12px。
- 阶段卡里的「门：」统一改成「**瓶颈：**」（「四道门/三道门」全部作废，术语守门有测试拦着）。
- 设置页「立场」那行的提示词删掉后半截——现在只说「要等四个阶段（信任 / 自主 / 主动 / 整合）都走完，立场才开始产生。」，不再解释它「不是第五关」。

### 文档

- **README 补 cookie 安全说明**：cookie 只落在 `~/.dsh-fish/owner.json`（`0600`）、只发给 `api.bilibili.com`、日志自动打码成 `SESSDATA=***`；并明确写出**备份文件里含 cookie**，别随手发人。
- **安装段加了 ffmpeg 前置提示**：刷视频需要本机已装 ffmpeg（`DSH_FISH_FFMPEG` 可指定路径），没装会提示并降级为只看文字。之前只在功能段提了一句「用本地 ffmpeg」，没告诉人要自己先装——这是唯一会卡住新用户的地方。
- README 接上**三张真机截图**（状态 / 成长 / 上网）。
- 新增 **`AGENTS.md`**：只写改代码的硬约束（零依赖、不加人格设置界面、四条黑名单、文案守门词、事件流只能追加、必须跑全套测试）。
- 新增本文件。
- 测试数 540 → 557。

### 工程

- 新增 **GitHub Actions**（`.github/workflows/test.yml`）：Linux 上 Node 20 / 22 / 24 三个版本各跑一遍全套测试，另有一个 Windows + Node 22 的作业（路径归一化、chmod 语义、ffmpeg 探测在这边和 Linux 不一样）。push 与 PR 都跑。首次推送需要在 GitHub 上给 token/push 开 `workflow` 权限，否则会被拒。
- **测试脚本改成 `node --test`（不带参数）。** 原来写的 `node --test "test/*.test.mjs"` 只在 Node 22+ 能用——Node 20 不展开引号里的通配符，直接报 `Could not find '.../test/*.test.mjs'`，CI 的 Node 20 作业就是被这条拖红的。`node --test test/`（目录形式）在 Node 26 + Windows 下又报 `MODULE_NOT_FOUND`，也不能用。不带参数是三种 Node 版本、三个平台都认的唯一写法。
- CI 暴露并修掉的两个跨平台 bug：`lib/capture.js` 的日记返回值原来把绝对路径（`diary/xxx.md`）带回给她，Windows 上分隔符是 `\` 所以测试侥幸通过、Linux 上直接命中隐私断言——改为只回日期键；`lib/say.js` 的 `waitTurnEnd` 在没有事件总线时把唯一的定时器 `unref` 了，Node 20/22 上事件循环提前收尾、Promise 永远等不到 resolve（含 `test/notify.test.mjs` 用 `Z:/` 造坏路径、在 Linux 上变成相对路径的跨平台问题）。
- `actions/checkout` / `actions/setup-node` 从 v4 升到 **v5**（v4 会触发 Node 20 弃用告警）。
- 删掉遗留的 `main-old` 分支（已被 `main` 整条取代，删前把它的顶端打成 `archive-main-old` 标签留着，需要时还能翻回来）。
- `package.json` 0.2.0 → 0.3.0，`files` 补进 `AGENTS.md` 与 `CHANGELOG.md`；`lib/index.js` 的 `VERSION` 从 0.1.0 一并升到 0.3.0（这个号写进启动日志，排查时第一件事就是看它）。

---

## 0.2.0 · 2026-10-25

一句话：**走完那四个阶段之后不再加关，往后长的是立场。**

- 新增 `lib/stance.js`：立场清单。它**不是第五关**——四个阶段走完才开始产生，靠「同一件事说过不止一次」「因此栽过一次」这类证据攒出来，每条后面跟一句代价，不跟次数。这一版上限是 4 条。
- 同时新增了 `lib/capability.js`（「横向能力」维度）。**这个维度是错的，0.3.0 已整个撤回**——它的判据量到的是说话风格，不是能力。
- 原理图与设置页加入立场说明。
- README 重写：先讲她怎么长，再讲怎么装（之前是反过来的）。
- README 顶部加示例图 `media/fish.jpg`。
- **改正上游归因**：本项目不含任何 `video-watch` 代码派生，之前 README 里那句归属是错的。

---

## 0.1.0 · 2026-10-25

第一个公开版本：**她能记住、会改口、会拒绝，也会忘。**

- **事件流是唯一真相源**：`~/.dsh-fish/events.jsonl`，只追加不改写；`state.json` 是派生品，`rebuild()` 随时可重算。删掉 `state.json` 能算出完全一样的结果，这条有测试守着。
- **人格靠事件长，不靠配置**：提示词里没有一句人格设定，也没有任何性格滑条 / 好感度数字 / 亲密度进度条。
- **四个阶段与三道瓶颈**：信任 → 自主 → 主动 → 整合，按天推进但每道瓶颈要她自己突破。
- **四条黑名单是代码级硬禁**，不是提示词里的劝告：不撒娇卖萌（写成「还不会」）、没有关系数值、不能读自己的设定与数值、不能调工具改自己。
- **她会拒绝**，也会为自己的拒绝反省；拒绝之后走哪条反馈链取决于你的反应。
- **记忆有重量**：深刻的记住，普通的折叠成一句「记不清原话了」，但不删除——原文还在事件流里，她能用 `her_recall` 翻回去。疤那类永不折叠。
- **她会自己刷 B 站**：`lib/bili.js` 只用 Node 内置 `fetch` / `crypto` / `zlib` 打 `api.bilibili.com`（自己实现 wbi 签名），串行限流 800ms、遇 -352/-412/-509 熔断 30 分钟；能看首页 / 排行 / 搜索 / 详情 / 评论 / 弹幕，能抽帧看画面，能在评论区说话与回话。
- **设置页**（设置 → 大肥鱼）：状态 / 成长 / 住所 / 上网 / 记忆 / 插件 / 原理 / 数据 八个 tab，全部是环境参数。
- **观测台不直连浏览器**：`/dsh-fish` 被 App 的登录栅栏守着，浏览器敲只会 401。
- 零运行时依赖，零构建步骤，110 个文件、22712 行。
