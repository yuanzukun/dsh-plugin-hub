/**
 * log.test.mjs —— 运行日志（2026-10-24 加）
 *
 * 这里测的不是"能写"。能写是显然的。要钉住的是三条容易悄悄坏掉的性质：
 *   1. **永不抛**：盘满、目录没了、root 是怪值，都不能连带让插件挂掉。
 *   2. **脱敏**：cookie 一类的值进不了日志文件。这条一旦失效，用户把日志导出发给
 *      别的 AI 排查的同时就把账号送出去了。
 *   3. **导出包不含不该外带的东西**：配置里的 cookie 字段、owner 里的凭据。
 *
 * 另外一个反直觉的规矩也要钉：**日志没有开关**。没有 `log.enabled` 这种配置键——
 * 出事那一刻才发现日志关着，是最常见的一种后悔。测试直接断言 DEFAULTS 里没这组。
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import {
  LOG_MAX_BYTES,
  LINE_MAX,
  buildBundle,
  clearLog,
  logBoot,
  logLine,
  logFile,
  makeLogger,
  redactConfig,
  scrub,
  tailEvents,
  tailLog,
} from '../lib/log.js'
import { DEFAULTS } from '../lib/settings.js'

async function tempRoot() {
  return await mkdtemp(join(tmpdir(), 'fish-log-'))
}

test('写一行就能读回来，带级别与时间戳', async () => {
  const root = await tempRoot()
  assert.equal(logLine('info', ['你好'], root), true)
  const tail = tailLog(root)
  assert.equal(tail.exists, true)
  assert.equal(tail.lines.length, 1)
  assert.match(tail.lines[0], /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} \[info\] 你好$/)
})

test('tailLog 只给最后 N 行，并且丢掉被截断的半截首行', async () => {
  const root = await tempRoot()
  for (let i = 0; i < 12; i += 1) logLine('info', [`第 ${i} 行`], root)
  const tail = tailLog(root, { lines: 3 })
  assert.equal(tail.lines.length, 3)
  assert.match(tail.lines[2], /第 11 行/)
  // maxBytes 小到切在行中间时，第一行必须是完整的行（不能以半句开头）
  const cut = tailLog(root, { lines: 5, maxBytes: 40 })
  for (const line of cut.lines) assert.match(line, /^\d{4}-\d{2}-\d{2} /)
})

test('没有日志文件时不抛，如实说没有', async () => {
  const root = await tempRoot()
  const tail = tailLog(root)
  assert.equal(tail.exists, false)
  assert.deepEqual(tail.lines, [])
  assert.equal(tail.bytes, 0)
})

test('root 是怪值也永不抛（日志坏了不能连带插件挂掉）', () => {
  // 用一段既不像路径、Windows 上又确实建不出来的串
  const bad = 'D:\\u0000nul\\\u0000bad'
  assert.doesNotThrow(() => logLine('error', ['写不进去也没关系'], bad))
  assert.equal(logLine('info', ['x'], bad), false)
  assert.doesNotThrow(() => tailLog(bad))
  assert.doesNotThrow(() => clearLog(bad))
})

test('Error 对象只留 message 与栈的前两帧，不整段倒进来', async () => {
  const root = await tempRoot()
  const err = new Error('屋子没接上')
  logLine('warn', [err], root)
  const line = tailLog(root).lines[0]
  assert.match(line, /屋子没接上/)
  assert.ok(line.length < LINE_MAX, '一行不能超长')
})

test('超长参数被截断到 LINE_MAX 以内', async () => {
  const root = await tempRoot()
  logLine('info', ['x'.repeat(50_000)], root)
  const line = tailLog(root).lines[0]
  assert.ok(line.length <= LINE_MAX + 40, `实际 ${line.length}`)
})

test('cookie 值在写盘前被抹掉', async () => {
  const root = await tempRoot()
  logLine('info', ['Cookie: SESSDATA=abcdef123456; bili_jct=deadbeef99'], root)
  const line = tailLog(root).lines[0]
  assert.doesNotMatch(line, /abcdef123456/)
  assert.doesNotMatch(line, /deadbeef99/)
  assert.match(line, /SESSDATA=\*\*\*/)
})

test('裸长串也抹：40 位以上且字母数字混杂的当凭据处理', () => {
  assert.equal(scrub('t=AbCdEf0123456789AbCdEf0123456789AbCdEf01'), 't=***')
  // 纯字母的长串更可能是路径或标识符，不清洗（清洗过头会毁掉排查信息）
  assert.match(scrub('a'.repeat(45)), /^a+$/)
})

test('自家的会话 id 与事件 id 不能被当成凭据抹掉（2026-10-29 用户 m02241）', () => {
  // 病根：规则②「40 位以上字母数字混杂」把 `session-<uuid>` 整条抹成 ***，
  // 于是日志里到处是「会话 ***」「woke ***」，要查「是哪条会话出的问题」时
  // 日志一个字都给不出，只能翻 outings.json 反推。
  const sid = 'session-058a9c4d-0999-4772-8264-c289f799fd09'
  assert.equal(scrub(`出门：装配完成 会话 ${sid}`), `出门：装配完成 会话 ${sid}`)
  assert.equal(scrub('woke session-abc123 test_first'), 'woke session-abc123 test_first')
  const evId = 'ev_01M62M5R78EJRR5P3393B80R22'
  assert.equal(scrub(`标记 ${evId}`), `标记 ${evId}`)
  // 但真凭据还是要抹：会话 id 放行不等于放行 cookie
  // 注意用 `session=` 而不是 `sid=`——`sid=` 是 cookie 参数名，规则①会连值一起抹掉
  // （那是 0.1.x 起的凭据规则，行为正确，不改）。
  const mixed = scrub(`SESSDATA=abcdef123456&bili_jct=deadbeef99&session=${sid}`)
  assert.doesNotMatch(mixed, /abcdef123456/)
  assert.doesNotMatch(mixed, /deadbeef99/)
  assert.match(mixed, /SESSDATA=\*\*\*/)
  assert.match(mixed, /session-058a9c4d/, '同一行里的会话 id 仍要留着')
})

test('export 里不留配置与 owner 的凭据', () => {
  const cfg = { comment: { enabled: true }, cookie: 'SESSDATA=xxx', owner: { mid: '1', cookie: 'SESSDATA=yyy' } }
  const out = redactConfig(cfg)
  assert.equal(out.cookie, '***')
  assert.equal(out.owner.cookie, '***')
  assert.equal(out.owner.mid, '1', 'mid 不是凭据，要留着')
  assert.equal(cfg.cookie, 'SESSDATA=xxx', '不能改原对象')
})

test('buildBundle 的段落顺序按"排查时最先想看什么"排', async () => {
  const root = await tempRoot()
  logBoot(root, '0.1.0 · test')
  const text = buildBundle(root, {
    version: '0.1.0',
    checks: { summary: '10 项里 9 项正常', items: [{ id: 'cookie', ok: false, label: '登录', detail: '还没存', fix: '贴上 cookie' }] },
    restrict: { applied: 1, allow: ['growth_commit'], guard: true, why: '' },
    lines: 20,
  })
  const iSelf = text.indexOf('--- 自检 ---')
  const iLog = text.indexOf('--- 日志')
  assert.ok(iSelf > 0 && iLog > iSelf, '自检要在日志前面')
  assert.match(text, /BAD 登录: 还没存 \| 修法: 贴上 cookie/)
  assert.match(text, /工具面: 已收窄/)
  assert.match(text, /插件版本: 0\.1\.0/)
})

test('清空是真的清空，之后再写还能写', async () => {
  const root = await tempRoot()
  logLine('info', ['一'], root)
  assert.deepEqual(clearLog(root), { ok: true, cleared: true })
  assert.equal(tailLog(root).lines.length, 0)
  logLine('info', ['二'], root)
  assert.equal(tailLog(root).lines.length, 1)
  // 文件不存在时清空也算成功（幂等）
  assert.deepEqual(clearLog(root).ok, true)
})

test('超过上限会轮转，旧内容进 .1 而不是被丢掉', async () => {
  const root = await tempRoot()
  const file = logFile(root)
  // 目录由第一条日志创建，所以这里要自己先建（顺手钉住"目录不存在时 logLine 自己会建"）
  await mkdir(dirname(file), { recursive: true })
  await writeFile(file, 'x'.repeat(LOG_MAX_BYTES + 10), 'utf8')
  logLine('info', ['轮转之后'], root)
  const rotated = await readFile(`${file}.1`, 'utf8')
  assert.ok(rotated.length >= LOG_MAX_BYTES, '.1 里应是那份超限的旧日志')
  assert.match(tailLog(root).lines.join('\n'), /轮转之后/)
})

test('makeLogger 同时写文件与转发宿主；宿主 logger 抛错也不影响写盘', async () => {
  const root = await tempRoot()
  const seen = []
  const ctx = { logger: { info: (...a) => seen.push(a.join(' ')), warn: () => { throw new Error('宿主坏了') } } }
  const log = makeLogger(ctx, root)
  log.info('第一次')
  assert.doesNotThrow(() => log.warn('第二次'))
  const lines = tailLog(root).lines
  assert.equal(lines.length, 2, '两次都要落盘')
  assert.deepEqual(seen, ['第一次'])
})

test('ctx 里没有 logger 也能用（测试环境与极老宿主）', async () => {
  const root = await tempRoot()
  const log = makeLogger(undefined, root)
  assert.doesNotThrow(() => log.info('照写'))
  assert.equal(tailLog(root).lines.length, 1)
})

test('日志没有开关：DEFAULTS 里不存在 log 这组配置', () => {
  assert.equal('log' in DEFAULTS, false, '有开关就等于允许"出事那一刻才发现日志关着"')
})

test('tailEvents：给事件流尾部，且丢掉被截断的半截首行', async () => {
  const root = await tempRoot()
  const file = join(root, 'events.jsonl')
  const rows = []
  for (let i = 0; i < 8; i += 1) rows.push(JSON.stringify({ type: 'meta', text: `watched:2026-10-28 BV1xx411c7m${i}` }))
  writeFileSync(file, rows.join('\n') + '\n', 'utf8')
  const ev = tailEvents(root, { lines: 3 })
  assert.equal(ev.exists, true)
  assert.equal(ev.lines.length, 3)
  assert.match(ev.lines[2], /BV1xx411c7m7/)
  // 没有这个文件也要如实说没有，不抛
  const none = tailEvents(join(root, 'nope'))
  assert.equal(none.exists, false)
  assert.deepEqual(none.lines, [])
})

test('导出里把「配置允许」与「实际生效」分开写（另一台机器的排查就栽在只有前者）', async () => {
  const root = await tempRoot()
  const text = buildBundle(root, {
    version: '0.6.2',
    restrict: { applied: 1, allow: ['growth_commit', 'her_recall', 'read_image'], effective: ['growth_commit'], guard: true, why: 'applied' },
  })
  assert.match(text, /配置允许 3 个/)
  assert.match(text, /实际生效: 1 个（growth_commit）/)
  assert.match(text, /名单里没生效的: her_recall \/ read_image/)
})

test('没收窄时导出明说「她看得见全部工具」，不是「允许 0 个」', async () => {
  const root = await tempRoot()
  const text = buildBundle(root, {
    version: '0.6.2',
    restrict: { applied: 0, allow: ['growth_commit', 'read_image'], effective: [], guard: true, why: 'deferred' },
  })
  assert.match(text, /未收窄/)
  assert.match(text, /实际生效: 没收窄 —— 这一局她看得见全部工具/)
})

test('导出里带模型与图像输入（看不见画面有一半原因是模型不吃图）', async () => {
  const root = await tempRoot()
  const yes = buildBundle(root, { model: { provider: 'deepseek', model: 'v4-flash', imageInput: true } })
  assert.match(yes, /模型: deepseek \/ v4-flash · 图像输入: 支持/)
  const no = buildBundle(root, { model: { provider: 'x', model: 'y', imageInput: false } })
  assert.match(no, /图像输入: 不支持/)
  // 说不准就写说不准，不能替人家宣布「不支持」
  const maybe = buildBundle(root, { model: { provider: '', model: '', imageInput: null, why: '读不到' } })
  assert.match(maybe, /图像输入: 说不准/)
})

test('导出里带事件流尾部：watched: 这种计数只在事件流里，日志文件里一个字都没有', async () => {
  const root = await tempRoot()
  logBoot(root, '0.6.2 · test')
  writeFileSync(join(root, 'events.jsonl'), JSON.stringify({ type: 'meta', text: 'watched:2026-10-28 BV1xx411c7mD' }) + '\n', 'utf8')
  const text = buildBundle(root, { version: '0.6.2', lines: 5, eventLines: 5 })
  const iEv = text.indexOf('--- 事件流')
  const iLog = text.indexOf('--- 日志')
  assert.ok(iEv > 0, '要有事件流段')
  assert.ok(iLog > iEv, '事件流在日志前面')
  assert.match(text, /watched:2026-10-28 BV1xx411c7mD/)
})
