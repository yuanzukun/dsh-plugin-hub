import type { Agent, AgentHandle } from '@deepseek-ai/dsh-agent'
import type { SessionId } from '@deepseek-ai/dsh-session'

/** fork = talk to A' (A unchanged). align = talk to A in place (A's log is written). */
export type ConsultMode = 'fork' | 'align'

/** How the answering session was chosen. */
export type ConsultFork = 'new' | 'continued' | 'fresh' | 'source'

export type ConsultTaskOwner = 'initiator' | 'peer'
export type ConsultTaskStatus = 'open' | 'doing' | 'done'
export type ConsultQuestionStatus = 'open' | 'answered'

/** One item on the shared division-of-labor board. */
export interface ConsultTask {
  readonly id: string
  title: string
  owner: ConsultTaskOwner
  status: ConsultTaskStatus
}

/** A clarifying question from the working side back to B. */
export interface ConsultQuestion {
  readonly id: string
  text: string
  status: ConsultQuestionStatus
  answer?: string
}

/** Shared board for one consult channel. Logged on B (and A when aligning). */
export interface ConsultBoard {
  goal: string
  known: string[]
  tasks: ConsultTask[]
  questions: ConsultQuestion[]
  welcomeQuestions: boolean
}

/** One consult channel: B talks to a fork of A, or to A itself when aligning. */
export interface ConsultChannel {
  readonly id: string
  readonly mode: ConsultMode
  /** Session that opened the consult (B). Consult transcript lives here as tool results. */
  readonly initiatorId: SessionId
  /** Original peer. Unchanged in fork mode; written in align mode. */
  readonly sourceId: SessionId
  /** Who answers: A' in fork mode, A itself in align mode. */
  readonly workingId: SessionId
  /** Present only for forks this plugin created or resumed in this process. Never dispose an aligned source. */
  handle?: AgentHandle
  /** First seq that belongs to this consult (fork seed boundary, or A's seq at align open). */
  readonly visibleFromSeq: number
  /** True when this fork was created with fresh=true (clean seed from A). */
  readonly fresh: boolean
  board: ConsultBoard
  rounds: number
  queue: string[]
  inFlight?: { firstNewSeq: number }
  /** Set when B stops the in-flight round; collectInFlight treats it as a stop. */
  stopRequested: boolean
  deliveries: ConsultDelivery[]
  /** Independent copy created by promote, if any. */
  promotedId?: SessionId
}

/** A completed consult round or ask-back waiting to be attached to B's next tool call. */
export interface ConsultDelivery {
  readonly consultId: string
  readonly workingSessionId: SessionId
  readonly sourceSessionId: SessionId
  readonly round: number
  readonly kind?: 'reply' | 'ask-back'
  readonly reply?: string
  readonly error?: string
  readonly stopped?: boolean
}

export interface PeerListEntry {
  readonly sessionId: SessionId
  readonly title: string
  readonly kind: 'source' | 'working-copy' | 'promoted'
  readonly lastActiveAt: number
  readonly consultId?: string
  readonly mode?: ConsultMode
}

export interface AskPeerResult {
  readonly status: 'ready' | 'pending' | 'queued' | 'stopped'
  readonly consultId: string
  readonly workingSessionId: SessionId
  readonly sourceSessionId: SessionId
  readonly mode: ConsultMode
  readonly fork: ConsultFork
  readonly waitMs: number
  readonly round?: number
  readonly reply?: string
  readonly queueDepth?: number
  readonly note?: string
  readonly board: ConsultBoard
}

export interface PromoteResult {
  readonly consultId: string
  readonly independentSessionId: SessionId
  readonly sourceSessionId: SessionId
}

export interface ConsultStatus {
  readonly consultId: string
  readonly sourceSessionId: SessionId
  readonly workingSessionId: SessionId
  readonly mode: ConsultMode
  readonly fork: ConsultFork
  readonly rounds: number
  readonly state: 'idle' | 'running' | 'queued'
  readonly queueDepth: number
  readonly undelivered: number
  readonly promotedSessionId?: SessionId
}

export interface ConsultProgress {
  readonly consultId: string
  readonly workingSessionId: SessionId
  readonly sourceSessionId: SessionId
  readonly mode: ConsultMode
  readonly state: ConsultStatus['state']
  readonly currentTool?: string
  /** Last two visible texts, truncated so they do not replace the final delivery. */
  readonly parts: string[]
}

export interface ConsultStopResult {
  readonly consultId: string
  readonly stopped: boolean
  readonly clearedQueue: number
  readonly parts: string[]
  readonly note: string
}

export interface ConsultAskResult {
  readonly consultId: string
  readonly questionId: string
  readonly delivered: 'followup' | 'queued'
  readonly board: ConsultBoard
}

export interface ConsultBoardResult {
  readonly consultId: string
  readonly board: ConsultBoard
}

/** Result of archiving and disposing idle working forks. */
export interface ConsultCleanupResult {
  readonly archived: SessionId[]
  readonly disposed: SessionId[]
}

export type { Agent, AgentHandle, SessionId }
