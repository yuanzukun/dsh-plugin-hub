import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import type { SessionEvent } from '@deepseek-ai/dsh-session'

/** Flatten text blocks; ignore images, reasoning, and tool payloads. */
export function contentText(blocks: readonly ContentBlock[]): string {
  return blocks
    .filter((block): block is ContentBlock & { type: 'text'; text: string } => block.type === 'text')
    .map(block => block.text)
    .join('\n')
}

/** Last non-empty assistant message in a log suffix, else streamed text. */
export function lastAssistantText(events: readonly SessionEvent[]): string {
  let message: ContentBlock[] | undefined
  const partial: string[] = []
  for (const event of events) {
    if (event.type === 'assistant/message' && event.data.message.content.length > 0) {
      message = event.data.message.content
    } else if (event.type === 'assistant/chunk' && event.data.chunk.type === 'text-delta') {
      if (event.data.chunk.text.length > 0) partial.push(event.data.chunk.text)
    }
  }
  if (message !== undefined) return contentText(message)
  return partial.join('')
}

/**
 * Last `limit` visible (non-think) assistant texts.
 * Each completed assistant/message with text is one part; leftover text-delta
 * after the last message is the in-progress part. Reasoning blocks and
 * reasoning-delta chunks are ignored.
 */
export function recentVisibleParts(events: readonly SessionEvent[], limit: number): string[] {
  const parts: string[] = []
  let streaming = ''
  for (const event of events) {
    if (event.type === 'assistant/chunk' && event.data.chunk.type === 'text-delta') {
      if (event.data.chunk.text.length > 0) streaming += event.data.chunk.text
      continue
    }
    if (event.type !== 'assistant/message') continue
    const text = contentText(event.data.message.content).trim()
    if (text.length > 0) parts.push(text)
    streaming = ''
  }
  const live = streaming.trim()
  if (live.length > 0) parts.push(live)
  return parts.slice(-limit)
}

const PROGRESS_PART_CHARS = 400

/** Truncate progress parts so they cannot stand in for the final delivery. */
export function truncateProgressParts(parts: readonly string[]): string[] {
  return parts.map(part => {
    if (part.length <= PROGRESS_PART_CHARS) return part
    return `${part.slice(0, PROGRESS_PART_CHARS)}…`
  })
}
