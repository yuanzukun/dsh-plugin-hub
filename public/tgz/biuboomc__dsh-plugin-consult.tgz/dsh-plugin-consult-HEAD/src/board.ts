import type { ConsultBoard, ConsultQuestion, ConsultTask, ConsultTaskOwner } from './types.ts'

export const BOARD_PREFIX = '[consult-board '

export function emptyBoard(goal: string, welcomeQuestions: boolean): ConsultBoard {
  return {
    goal,
    known: [],
    tasks: [],
    questions: [],
    welcomeQuestions,
  }
}

export function cloneBoard(board: ConsultBoard): ConsultBoard {
  return {
    goal: board.goal,
    known: [...board.known],
    tasks: board.tasks.map(task => ({ ...task })),
    questions: board.questions.map(question => ({ ...question })),
    welcomeQuestions: board.welcomeQuestions,
  }
}

export function formatBoardMessage(consultId: string, board: ConsultBoard): string {
  return `${BOARD_PREFIX}${consultId}]\n${JSON.stringify(board)}`
}

export function parseBoardMessage(text: string): { consultId: string; board: ConsultBoard } | undefined {
  const start = text.indexOf(BOARD_PREFIX)
  if (start < 0) return undefined
  const rest = text.slice(start + BOARD_PREFIX.length)
  const close = rest.indexOf(']\n')
  if (close < 0) return undefined
  const consultId = rest.slice(0, close)
  const objectText = rest.slice(close + 2).split('\n')[0] ?? ''
  const raw = parseJsonObject(objectText)
  if (consultId.length === 0 || raw === undefined) return undefined
  const board = asBoard(raw)
  if (board === undefined) return undefined
  return { consultId, board }
}

export function splitKnown(known: string | undefined): string[] {
  if (known === undefined) return []
  return known.split(/\n+/).map(line => line.trim()).filter(line => line.length > 0)
}

export function tasksFromLines(text: string | undefined, owner: ConsultTaskOwner): ConsultTask[] {
  if (text === undefined) return []
  return text.split(/\n+/).map(line => line.trim()).filter(line => line.length > 0).map(title => ({
    id: crypto.randomUUID(),
    title,
    owner,
    status: 'open' as const,
  }))
}

export function mergeOpening(board: ConsultBoard, known: string[], tasks: ConsultTask[], goal: string): void {
  if (board.goal.length === 0 && goal.length > 0) board.goal = goal
  for (const item of known) {
    if (!board.known.includes(item)) board.known.push(item)
  }
  for (const task of tasks) board.tasks.push(task)
}

export function addQuestion(board: ConsultBoard, text: string): ConsultQuestion {
  const question: ConsultQuestion = { id: crypto.randomUUID(), text, status: 'open' }
  board.questions.push(question)
  return question
}

export function formatBoardForPrompt(board: ConsultBoard): string {
  const known = board.known.length === 0 ? '(none)' : board.known.map(item => `- ${item}`).join('\n')
  const tasks = board.tasks.length === 0
    ? '(none)'
    : board.tasks.map(task => `- [${task.status}] ${task.id} owner=${task.owner}: ${task.title}`).join('\n')
  const questions = board.questions.length === 0
    ? '(none)'
    : board.questions.map(question => {
      const answer = question.answer !== undefined ? ` → ${question.answer}` : ''
      return `- [${question.status}] ${question.id}: ${question.text}${answer}`
    }).join('\n')
  return [
    `Goal: ${board.goal.length > 0 ? board.goal : '(not set)'}`,
    `Already known (do not re-research):`,
    known,
    `Tasks:`,
    tasks,
    `Open questions from you to the initiator:`,
    questions,
    board.welcomeQuestions
      ? 'You may call consult_ask on this channel if you need the initiator to clarify before doing overlapping work.'
      : 'Do not call consult_ask; answer from what you have.',
  ].join('\n')
}

function parseJsonObject(text: string): Record<string, unknown> | undefined {
  try {
    const value: unknown = JSON.parse(text)
    if (typeof value !== 'object' || value === null || Array.isArray(value)) return undefined
    return value as Record<string, unknown>
  } catch {
    return undefined
  }
}

function asBoard(raw: Record<string, unknown>): ConsultBoard | undefined {
  if (typeof raw.goal !== 'string' || !Array.isArray(raw.known) || !Array.isArray(raw.tasks) || !Array.isArray(raw.questions)) {
    return undefined
  }
  return {
    goal: raw.goal,
    known: raw.known.filter((item): item is string => typeof item === 'string'),
    tasks: raw.tasks.filter(isTask),
    questions: raw.questions.filter(isQuestion),
    welcomeQuestions: raw.welcomeQuestions !== false,
  }
}

function isTask(value: unknown): value is ConsultTask {
  if (typeof value !== 'object' || value === null) return false
  const task = value as ConsultTask
  return typeof task.id === 'string' && typeof task.title === 'string'
    && (task.owner === 'initiator' || task.owner === 'peer')
    && (task.status === 'open' || task.status === 'doing' || task.status === 'done')
}

function isQuestion(value: unknown): value is ConsultQuestion {
  if (typeof value !== 'object' || value === null) return false
  const question = value as ConsultQuestion
  return typeof question.id === 'string' && typeof question.text === 'string'
    && (question.status === 'open' || question.status === 'answered')
}
