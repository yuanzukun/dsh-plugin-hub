/**
 * Peer consult: B talks to a fork of A (default) or to A itself (align).
 * Channels carry a shared board; A may ask back. The consultId index is
 * rebuilt from B's logged ask_peer results after a reload. Working forks are
 * archived out of the workspace picker and disposed after forkIdleMs.
 */
import { randomUUID } from 'node:crypto'
import { Service, type Context } from '@deepseek-ai/cordis'
import Schema from '@deepseek-ai/schemastery'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { SessionId } from '@deepseek-ai/dsh-session'
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { PostToolDecision } from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-agent-presets'
import type {} from '@deepseek-ai/dsh-commands'
import type { AssembleContext } from '@deepseek-ai/dsh-system-prompt'
import type {} from '@deepseek-ai/dsh-session-title'
import type {} from '@deepseek-ai/dsh-user-approval'
import type {} from '@deepseek-ai/dsh-workspace'
import {
  addQuestion,
  cloneBoard,
  emptyBoard,
  formatBoardForPrompt,
  formatBoardMessage,
  mergeOpening,
  parseBoardMessage,
  splitKnown,
  tasksFromLines,
} from './board.ts'
import { completedTurnPrefix } from './seed.ts'
import { lastAssistantText, recentVisibleParts, truncateProgressParts } from './text.ts'
import type {
  AskPeerResult,
  ConsultAskResult,
  ConsultBoard,
  ConsultBoardResult,
  ConsultCleanupResult,
  ConsultChannel,
  ConsultDelivery,
  ConsultFork,
  ConsultMode,
  ConsultProgress,
  ConsultStatus,
  ConsultStopResult,
  ConsultTaskOwner,
  PeerListEntry,
  PromoteResult,
} from './types.ts'

declare module '@deepseek-ai/cordis' {
  interface Context {
    consult: ConsultService
  }
}

const INITIATOR_ONLY_TOOLS = [
  'list_peers',
  'ask_peer',
  'promote_consult',
  'consult_status',
  'consult_progress',
  'consult_stop',
] as const

const RESULT_PREFIX = '[consult-result] '

const CONSULT_RULES = `You work alongside other live sessions. They are colleagues, not archives.
If the user's task overlaps another session's work — aligning, comparing, 对齐, 问一下那边, 同事, training vs eval, or anything that session already researched — you MUST ask_peer that session before you search, clone, or re-read the same material.
Do not read a colleague's workspace folder with the read tool. That path is a directory. Talk to them with ask_peer.
Do not become the expert for a topic a colleague already owns. Talking to them is the default; doing their work again is the failure.
One question → one peer. Pass known= (what you already have) and tasks= (what they should cover). wait_ms=30000.
User wants both sides to remember the exchange → align=true. One-way lookup → align=false.
If ask_peer returns pending/queued, keep working. The peer may still be on their own turn; the question waits until they are idle. The reply arrives on your next tool result or as a follow-up when you go idle. Do not busy-poll.
The peer may consult_ask you back; answer on the same consult_id.`

const WORKING_COPY_CONTEXT
  = 'You are a working copy answering a colleague consult. Your original session is not receiving these messages. '
    + 'Answer from this session\'s existing context and the consult board first. Do not re-research facts listed as already known. '
    + 'If you need the initiator to clarify, call consult_ask on this channel (not ask_peer). Use consult_board to claim or complete tasks. '
    + 'Operations that require approval are rejected automatically. Do not open consults to other sessions.'

export interface Config {
  /** Max ask_peer rounds per consult channel. */
  maxRounds: number
  /** Upper bound for the wait_ms argument B supplies. */
  maxWaitMs: number
  /** Max clarifying questions the working side may send back on one channel. */
  maxAskBack: number
  /**
   * Hide working forks from workspace grouping via archiveSession.
   * Does not write the original session A. Ignored when workspaceRegistry is absent.
   */
  archiveWorkingForks: boolean
  /**
   * After a fork is idle (no in-flight round, queue, or undelivered reply),
   * dispose its live agent. 0 keeps the agent live. The consultId and log stay;
   * the next ask_peer resumes the same A'.
   */
  forkIdleMs: number
}

export default class ConsultService extends Service {
  static inject = ['agents', 'sessions', 'tools']

  static Config: Schema<Config> = Schema.object({
    maxRounds: Schema.number().default(8),
    maxWaitMs: Schema.number().default(180_000),
    maxAskBack: Schema.number().default(4),
    archiveWorkingForks: Schema.boolean().default(true),
    forkIdleMs: Schema.number().default(1_800_000),
  })

  private readonly config: Config
  private readonly channels = new Map<string, ConsultChannel>()
  /** (initiatorId, sourceId) → primary fork consult id (the first non-fresh fork). */
  private readonly primaryByPair = new Map<string, string>()
  /** (initiatorId, sourceId) → align consult that writes the original session. */
  private readonly alignByPair = new Map<string, string>()
  private readonly workingIds = new Set<string>()
  private readonly retireTimers = new Map<string, () => void>()
  private indexReady = false
  private disposed = false

  constructor(ctx: Context, config: Config) {
    super(ctx, 'consult')
    this.config = config
    this.registerTools()
    this.registerCommands()
    this.registerPrompt()
    this.registerDeliveryHook()
    this.registerIdleHook()
    ctx.on('session/created', () => { this.ensureIndex() }, { global: true })
    ctx.effect(() => {
      const timer = setTimeout(() => { if (!this.disposed) this.ensureIndex() }, 0)
      return () => {
        clearTimeout(timer)
        this.disposeAll()
      }
    })
  }

  listPeers(caller: Agent): PeerListEntry[] {
    try {
      this.rebuildIndex()
    } catch (error) {
      this.ctx.logger.warn(
        `[consult] list_peers index rebuild failed: ${error instanceof Error ? error.message : String(error)}`,
      )
    }
    const entries: PeerListEntry[] = []
    for (const session of this.ctx.sessions.list()) {
      if (session.id === caller.id) continue
      try {
        const working = this.channelByWorking(session.id)
        const align = this.alignChannelForSource(session.id, caller.id)
        const fromCaller = [...this.channels.values()].find(channel =>
          channel.initiatorId === caller.id && (channel.sourceId === session.id || channel.workingId === session.id),
        )
        const promoted = this.channelByPromoted(session.id)
        const title = this.ctx.get('sessionTitle')?.get(session)?.title ?? session.id
        const fork = working?.mode === 'fork' ? working : undefined
        if (fork !== undefined && this.isArchived(session.id)) continue
        const tagged = fork ?? align ?? fromCaller ?? promoted
        entries.push({
          sessionId: session.id,
          title,
          kind: fork ? 'working-copy' : promoted ? 'promoted' : 'source',
          lastActiveAt: lastActiveAt(session),
          ...tagged !== undefined ? { consultId: tagged.id, mode: tagged.mode } : {},
        })
      } catch (error) {
        this.ctx.logger.warn(
          `[consult] list_peers skipped ${session.id}: ${error instanceof Error ? error.message : String(error)}`,
        )
      }
    }
    entries.sort((left, right) => right.lastActiveAt - left.lastActiveAt)
    return entries
  }

  statusFor(caller: Agent): ConsultStatus[] {
    this.ensureIndex()
    return [...this.channels.values()]
      .filter(channel => channel.initiatorId === caller.id)
      .map(channel => this.toStatus(channel))
  }

  progress(caller: Agent, consultIdOrSource: string): ConsultProgress {
    this.ensureIndex()
    const channel = this.resolveChannel(caller, consultIdOrSource)
    return this.toProgress(channel)
  }

  stop(caller: Agent, consultIdOrSource: string): ConsultStopResult {
    this.ensureIndex()
    const channel = this.resolveChannel(caller, consultIdOrSource)
    const clearedQueue = channel.queue.length
    channel.queue = []
    if (channel.inFlight === undefined) {
      this.noteForkIdle(channel)
      return {
        consultId: channel.id,
        stopped: false,
        clearedQueue,
        parts: truncateProgressParts(this.visibleParts(channel)),
        note: channel.mode === 'align' ? 'Aligned session is already idle.' : 'Working copy is already idle.',
      }
    }
    channel.stopRequested = true
    const live = this.liveTarget(channel)
    if (live === undefined) {
      channel.inFlight = undefined
      this.noteForkIdle(channel)
      return {
        consultId: channel.id,
        stopped: true,
        clearedQueue,
        parts: [],
        note: 'Working copy was already retired. Partial text is not available.',
      }
    }
    live.cancel({ kind: 'parent' })
    const collected = this.collectInFlight(channel)
    this.noteForkIdle(channel)
    return {
      consultId: channel.id,
      stopped: true,
      clearedQueue,
      parts: truncateProgressParts(
        collected.reply !== undefined && collected.reply.length > 0
          ? [collected.reply]
          : this.visibleParts(channel),
      ),
      note: channel.mode === 'align'
        ? 'Cancelled the original session\'s in-flight turn. Partial text is in parts and will not be delivered again.'
        : 'Cancelled the in-flight turn. Partial text is in parts and will not be delivered again.',
    }
  }

  async askPeer(
    caller: Agent,
    args: {
      sessionId: string
      question: string
      waitMs: number
      consultId?: string
      fresh?: boolean
      align?: boolean
      known?: string
      tasks?: string
      welcomeQuestions?: boolean
    },
    signal: AbortSignal,
  ): Promise<AskPeerResult> {
    this.ensureIndex()
    if (signal.aborted) throw abortError(signal)
    const requestedWait = this.requireWaitMs(args.waitMs)
    const waitMs = stepAlreadyHasAskPeerResult(caller) ? 0 : requestedWait
    if (args.fresh === true && args.consultId !== undefined) {
      throw new Error('fresh=true creates a new working copy; omit consult_id')
    }
    if (args.align === true && args.fresh === true) {
      throw new Error('align=true writes the original session; omit fresh')
    }
    if (args.align === true) {
      const named = this.channelByWorking(SessionId(args.sessionId))
      if (named?.mode === 'fork' && named.workingId === SessionId(args.sessionId)) {
        throw new Error('align=true writes the original session; pass that session_id, not a working copy')
      }
    }

    const source = this.resolveSource(caller, args.sessionId)
    const { channel, created } = await this.ctx.agents.withoutInitiator(() =>
      this.ensureChannel(caller, source, {
        signal,
        fresh: args.fresh === true,
        ...args.align !== undefined ? { requestedMode: args.align ? 'align' : 'fork' } : {},
        consultId: args.consultId,
        goal: args.question,
        welcomeQuestions: args.welcomeQuestions !== false,
      }),
    )
    mergeOpening(
      channel.board,
      splitKnown(args.known),
      tasksFromLines(args.tasks, 'peer'),
      args.question,
    )
    if (args.welcomeQuestions !== undefined) channel.board.welcomeQuestions = args.welcomeQuestions
    this.persistBoard(channel)

    if (channel.rounds + channel.queue.length + (channel.inFlight !== undefined ? 1 : 0) >= this.config.maxRounds) {
      throw new Error(`consult ${channel.id} reached maxRounds=${this.config.maxRounds}; start a fresh fork or a new align channel`)
    }

    const fork = forkLabel(channel, created)
    if (channel.inFlight !== undefined) {
      channel.queue.push(args.question)
      return this.askResult(channel, {
        status: 'queued',
        fork,
        waitMs: 0,
        queueDepth: channel.queue.length,
        note: 'The target is still answering a previous consult question. This follow-up is queued. Keep working; the reply attaches to a later tool result.',
      })
    }

    const target = await this.ctx.agents.withoutInitiator(() => this.ensureTarget(channel, signal))
    if (target.status !== 'idle') {
      channel.queue.push(args.question)
      this.schedulePump(channel, caller)
      return this.askResult(channel, {
        status: 'queued',
        fork,
        waitMs: 0,
        queueDepth: channel.queue.length,
        note: 'The peer is still working on their own turn. The question is queued and will start when they are idle. Keep working; the reply attaches to a later tool result or a new turn if they go idle first.',
      })
    }

    const started = this.ctx.agents.withoutInitiator(() =>
      this.startRound(channel, caller, args.question),
    )
    if (!started) {
      channel.queue.push(args.question)
      this.schedulePump(channel, caller)
      return this.askResult(channel, {
        status: 'queued',
        fork,
        waitMs: 0,
        queueDepth: channel.queue.length,
        note: 'The peer started working before the consult turn could open. The question is queued. Keep working; the reply attaches later.',
      })
    }
    const stop = await waitUntilIdle(this.targetAgent(channel), waitMs, signal)
    if (stop === 'idle') {
      const ready = this.collectInFlight(channel)
      void this.ctx.agents.withoutInitiator(() => this.pumpQueue(channel, caller))
      if (ready.stopped === true) {
        return this.askResult(channel, {
          status: 'stopped',
          fork,
          waitMs,
          round: ready.round,
          reply: ready.reply ?? '',
          note: channel.mode === 'align'
            ? 'Aligned session was stopped during wait_ms.'
            : 'Working copy was stopped during wait_ms.',
        })
      }
      if (ready.error !== undefined) throw new Error(ready.error)
      return this.askResult(channel, {
        status: 'ready',
        fork,
        waitMs,
        round: ready.round,
        reply: ready.reply ?? '',
      })
    }

    void this.ctx.agents.withoutInitiator(() => this.settleInFlight(channel, caller))
    return this.askResult(channel, {
      status: 'pending',
      fork,
      waitMs,
      note: waitMs === 0 && requestedWait > 0
        ? 'Another ask_peer in this step already waited. This call returned pending immediately. The reply will attach to your next tool result.'
        : `No reply within ${waitMs}ms. Keep working. The reply will attach to your next tool result.`,
    })
  }

  consultAsk(caller: Agent, text: string, consultId?: string): ConsultAskResult {
    this.ensureIndex()
    const channel = this.resolveWorkingChannel(caller, consultId)
    if (!channel.board.welcomeQuestions) {
      throw new Error(`consult ${channel.id} is not accepting clarifying questions`)
    }
    if (channel.board.questions.length >= this.config.maxAskBack) {
      throw new Error(`consult ${channel.id} reached maxAskBack=${this.config.maxAskBack}`)
    }
    const question = addQuestion(channel.board, text)
    this.persistBoard(channel)
    const delivered = this.deliverAskBack(channel, question.text)
    return {
      consultId: channel.id,
      questionId: question.id,
      delivered,
      board: cloneBoard(channel.board),
    }
  }

  consultBoard(
    caller: Agent,
    args: {
      consultId?: string
      addKnown?: string
      addTask?: string
      owner?: ConsultTaskOwner
      claimTask?: string
      completeTask?: string
      answerId?: string
      answer?: string
    },
  ): ConsultBoardResult {
    this.ensureIndex()
    const channel = this.resolveEitherSide(caller, args.consultId)
    const isInitiator = channel.initiatorId === caller.id
    if (args.addKnown !== undefined) {
      for (const item of splitKnown(args.addKnown)) {
        if (!channel.board.known.includes(item)) channel.board.known.push(item)
      }
    }
    if (args.addTask !== undefined) {
      if (!isInitiator) throw new Error('only the initiating session may add tasks')
      channel.board.tasks.push({
        id: randomUUID(),
        title: args.addTask,
        owner: args.owner ?? 'peer',
        status: 'open',
      })
    }
    if (args.claimTask !== undefined) {
      const task = channel.board.tasks.find(item => item.id === args.claimTask)
      if (task === undefined) throw new Error(`task ${args.claimTask} not found`)
      const want: ConsultTaskOwner = isInitiator ? 'initiator' : 'peer'
      task.owner = want
      if (task.status === 'open') task.status = 'doing'
    }
    if (args.completeTask !== undefined) {
      const task = channel.board.tasks.find(item => item.id === args.completeTask)
      if (task === undefined) throw new Error(`task ${args.completeTask} not found`)
      task.status = 'done'
    }
    if (args.answerId !== undefined) {
      if (!isInitiator) throw new Error('only the initiating session may answer clarifying questions')
      const question = channel.board.questions.find(item => item.id === args.answerId)
      if (question === undefined) throw new Error(`question ${args.answerId} not found`)
      if (args.answer === undefined) throw new Error('answer is required when answering a question')
      question.status = 'answered'
      question.answer = args.answer
    }
    this.persistBoard(channel)
    return { consultId: channel.id, board: cloneBoard(channel.board) }
  }

  async cleanupIdleForks(caller: Agent): Promise<ConsultCleanupResult> {
    this.ensureIndex()
    const archived: SessionId[] = []
    const disposed: SessionId[] = []
    for (const channel of this.channels.values()) {
      if (channel.initiatorId !== caller.id) continue
      const result = await this.retireFork(channel, true)
      if (result === undefined) continue
      if (result.archived) archived.push(channel.workingId)
      if (result.disposed) disposed.push(channel.workingId)
    }
    return { archived, disposed }
  }

  async promote(caller: Agent, consultIdOrSource: string, signal: AbortSignal): Promise<PromoteResult> {
    this.ensureIndex()
    if (signal.aborted) throw abortError(signal)
    const channel = this.resolveChannel(caller, consultIdOrSource)
    if (channel.mode === 'align') {
      throw new Error('promote is only for fork-mode working copies; align already writes the original session')
    }
    this.cancelRetire(channel.id)
    const working = await this.ensureTarget(channel, signal)
    const seed = completedTurnPrefix(working)
    if (seed.length === 0) {
      throw new Error('working fork has no completed turn to copy yet')
    }

    const independentId = SessionId(randomUUID())
    const source = working
    const handle = await this.ctx.agents.withoutInitiator(() => this.ctx.agents.create({
      sessionId: independentId,
      seed,
      meta: {
        ...source.session.header.cwd !== undefined ? { cwd: source.session.header.cwd } : {},
        parentSession: channel.workingId,
        seedLength: seed.length,
        ...source.session.header.agentPreset !== undefined
          ? { agentPreset: source.session.header.agentPreset }
          : {},
      },
      agentOptions: { ...source.options },
      signal,
      setup: (agentCtx) => {
        agentCtx.get('agentPresets')?.composeFrom(agentCtx, source.ctx)
      },
    }))
    channel.promotedId = handle.agent.id
    this.ctx.logger.info(
      `[consult] promoted working fork ${channel.workingId} → independent ${handle.agent.id} (source ${channel.sourceId} unchanged)`,
    )
    return {
      consultId: channel.id,
      independentSessionId: handle.agent.id,
      sourceSessionId: channel.sourceId,
    }
  }

  private askResult(
    channel: ConsultChannel,
    rest: Omit<AskPeerResult, 'consultId' | 'workingSessionId' | 'sourceSessionId' | 'mode' | 'board'>,
  ): AskPeerResult {
    return {
      consultId: channel.id,
      workingSessionId: channel.workingId,
      sourceSessionId: channel.sourceId,
      mode: channel.mode,
      board: cloneBoard(channel.board),
      ...rest,
    }
  }

  private requireWaitMs(waitMs: number): number {
    if (!Number.isInteger(waitMs) || waitMs < 0) {
      throw new Error('wait_ms must be a non-negative integer (milliseconds)')
    }
    if (waitMs > this.config.maxWaitMs) {
      throw new Error(`wait_ms ${waitMs} exceeds maxWaitMs=${this.config.maxWaitMs}`)
    }
    return waitMs
  }

  private ensureIndex(): void {
    const first = !this.indexReady
    this.rebuildIndex()
    void this.sweepWorkingForks().then(() => {
      if (first) this.armIdleForks()
    })
  }

  private rebuildIndex(): void {
    if (this.disposed) return
    this.rebuildFromLogs(this.indexReady)
    this.indexReady = true
  }

  private armIdleForks(): void {
    for (const channel of this.channels.values()) this.noteForkIdle(channel)
  }

  private rebuildFromLogs(merge: boolean): void {
    for (const initiator of this.ctx.agents.list()) {
      this.ingestAskPeerResults(initiator)
      this.ingestBoardMessages(initiator, merge)
    }
  }

  private ingestAskPeerResults(initiator: Agent): void {
    const events = initiator.session.events
    for (const event of events) {
      if (event.type !== 'tool/result') continue
      const parsed = parseConsultResult(toolResultText(event))
      if (parsed === undefined) continue
      const existing = this.channels.get(parsed.consultId)
      if (existing !== undefined) {
        if (parsed.round !== undefined && parsed.round > existing.rounds) existing.rounds = parsed.round
        const board = parseBoardMessage(toolResultText(event))
        if (board !== undefined) existing.board = board.board
        continue
      }
      const working = this.ctx.agents.get(parsed.workingSessionId)
      const source = this.ctx.agents.get(parsed.sourceSessionId)
      if (source === undefined && working === undefined) continue
      const mode = parsed.mode
      const workingId = parsed.workingSessionId
      const sourceId = parsed.sourceSessionId
      const channel: ConsultChannel = {
        id: parsed.consultId,
        mode,
        initiatorId: initiator.id,
        sourceId,
        workingId,
        visibleFromSeq: working?.session.header.seedLength ?? 0,
        fresh: parsed.fork === 'fresh',
        board: emptyBoard('', true),
        rounds: parsed.round ?? (parsed.status === 'ready' || parsed.status === 'stopped' ? 1 : 0),
        queue: [],
        stopRequested: false,
        deliveries: [],
      }
      this.channels.set(channel.id, channel)
      if (mode === 'fork') this.workingIds.add(workingId)
      const pairKey = `${initiator.id}\0${sourceId}`
      if (mode === 'align') {
        if (!this.alignByPair.has(pairKey)) this.alignByPair.set(pairKey, channel.id)
      } else if (!channel.fresh && !this.primaryByPair.has(pairKey)) {
        this.primaryByPair.set(pairKey, channel.id)
      }
      this.ctx.logger.info(`[consult] rebuilt ${channel.id} (${mode}) from ${initiator.id} → ${workingId}`)
    }
  }

  private ingestBoardMessages(initiator: Agent, merge: boolean): void {
    for (const event of initiator.session.events) {
      const text = event.type === 'user/message'
        ? userMessageText(event)
        : event.type === 'tool/result'
          ? toolResultText(event)
          : ''
      if (text.length === 0) continue
      const parsed = parseBoardMessage(text)
      if (parsed === undefined) continue
      const channel = this.channels.get(parsed.consultId)
      if (channel === undefined) continue
      if (merge && channel.board.tasks.length + channel.board.known.length + channel.board.questions.length > 0) {
        continue
      }
      channel.board = parsed.board
    }
  }

  private async ensureChannel(
    caller: Agent,
    source: Agent,
    options: {
      signal: AbortSignal
      fresh: boolean
      requestedMode?: ConsultMode
      consultId?: string
      goal: string
      welcomeQuestions: boolean
    },
  ): Promise<{ channel: ConsultChannel; created: boolean }> {
    const mode: ConsultMode = options.requestedMode ?? 'fork'
    if (options.consultId !== undefined) {
      const existing = this.resolveChannel(caller, options.consultId)
      if (existing.sourceId !== source.id) {
        throw new Error(`consult ${options.consultId} is not a consult of ${source.id}`)
      }
      if (options.requestedMode !== undefined && existing.mode !== options.requestedMode) {
        throw new Error(`consult ${options.consultId} is ${existing.mode} mode; omit align or pass align=${existing.mode === 'align'}`)
      }
      return { channel: existing, created: false }
    }

    const pairKey = `${caller.id}\0${source.id}`
    if (mode === 'align') {
      const alignId = this.alignByPair.get(pairKey)
      if (alignId !== undefined) {
        const existing = this.channels.get(alignId)
        if (existing !== undefined) return { channel: existing, created: false }
      }
      return { channel: this.openAlignChannel(caller, source, pairKey, options), created: true }
    }

    if (!options.fresh) {
      const primaryId = this.primaryByPair.get(pairKey)
      if (primaryId !== undefined) {
        const primary = this.channels.get(primaryId)
        if (primary !== undefined) return { channel: primary, created: false }
      }
    }

    return { channel: await this.openForkChannel(caller, source, pairKey, options), created: true }
  }

  private openAlignChannel(
    caller: Agent,
    source: Agent,
    pairKey: string,
    options: { goal: string; welcomeQuestions: boolean },
  ): ConsultChannel {
    const channel: ConsultChannel = {
      id: randomUUID(),
      mode: 'align',
      initiatorId: caller.id,
      sourceId: source.id,
      workingId: source.id,
      visibleFromSeq: source.session.seq,
      fresh: false,
      board: emptyBoard(options.goal, options.welcomeQuestions),
      rounds: 0,
      queue: [],
      stopRequested: false,
      deliveries: [],
    }
    this.channels.set(channel.id, channel)
    this.alignByPair.set(pairKey, channel.id)
    this.ctx.logger.info(
      `[consult] opened ${channel.id} (align): ${caller.id} → source ${source.id}`,
    )
    return channel
  }

  private async openForkChannel(
    caller: Agent,
    source: Agent,
    pairKey: string,
    options: { signal: AbortSignal; fresh: boolean; goal: string; welcomeQuestions: boolean },
  ): Promise<ConsultChannel> {
    const seed = completedTurnPrefix(source)
    if (seed.length === 0) {
      throw new Error(`session ${source.id} has no completed turn to fork; refusing to consult an empty copy`)
    }
    const workingId = SessionId(randomUUID())
    const handle = await this.ctx.agents.create({
      sessionId: workingId,
      seed,
      meta: {
        ...source.session.header.cwd !== undefined ? { cwd: source.session.header.cwd } : {},
        parentSession: source.id,
        seedLength: seed.length,
        ...source.session.header.agentPreset !== undefined
          ? { agentPreset: source.session.header.agentPreset }
          : {},
      },
      agentOptions: { ...source.options },
      signal: options.signal,
      setup: (agentCtx) => applyWorkingCopySetup(agentCtx, source),
    })

    const channel: ConsultChannel = {
      id: randomUUID(),
      mode: 'fork',
      initiatorId: caller.id,
      sourceId: source.id,
      workingId: handle.agent.id,
      handle,
      visibleFromSeq: handle.agent.session.header.seedLength ?? seed.length,
      fresh: options.fresh,
      board: emptyBoard(options.goal, options.welcomeQuestions),
      rounds: 0,
      queue: [],
      stopRequested: false,
      deliveries: [],
    }
    this.channels.set(channel.id, channel)
    this.workingIds.add(handle.agent.id)
    if (!options.fresh && !this.primaryByPair.has(pairKey)) {
      this.primaryByPair.set(pairKey, channel.id)
    }
    this.ctx.logger.info(
      `[consult] opened ${channel.id} (${options.fresh ? 'fresh' : 'primary'}): ${caller.id} → fork ${handle.agent.id} of ${source.id}`,
    )
    await this.archiveWorking(handle.agent.id)
    return channel
  }

  private liveTarget(channel: ConsultChannel): Agent | undefined {
    if (channel.handle !== undefined) return channel.handle.agent
    return this.ctx.agents.get(channel.workingId)
  }

  private targetAgent(channel: ConsultChannel): Agent {
    const agent = this.liveTarget(channel)
    if (agent === undefined) {
      throw new Error(`${channel.mode === 'align' ? 'aligned' : 'working'} session ${channel.workingId} is not live`)
    }
    return agent
  }

  private async ensureTarget(channel: ConsultChannel, signal: AbortSignal): Promise<Agent> {
    const live = this.liveTarget(channel)
    if (live !== undefined) {
      this.cancelRetire(channel.id)
      return live
    }
    if (channel.mode === 'align') {
      throw new Error(`aligned session ${channel.workingId} is not live`)
    }
    this.cancelRetire(channel.id)
    const source = this.ctx.agents.get(channel.sourceId)
    const handle = await this.ctx.agents.resume({
      resumeSessionId: channel.workingId,
      ...source !== undefined ? { agentOptions: { ...source.options } } : {},
      signal,
      setup: (agentCtx) => applyWorkingCopySetup(agentCtx, source),
    })
    channel.handle = handle
    this.workingIds.add(handle.agent.id)
    await this.archiveWorking(handle.agent.id)
    this.ctx.logger.info(`[consult] resumed working fork ${handle.agent.id} for ${channel.id}`)
    return handle.agent
  }

  private isArchived(sessionId: SessionId): boolean {
    try {
      return this.ctx.get('workspaceRegistry')?.archivedSessionIds.includes(sessionId) === true
    } catch {
      return false
    }
  }

  private async archiveWorking(workingId: SessionId): Promise<void> {
    if (!this.config.archiveWorkingForks) return
    const registry = this.ctx.get('workspaceRegistry')
    if (registry === undefined) return
    try {
      await registry.archiveSession(workingId)
    } catch (error) {
      this.ctx.logger.warn(
        `[consult] archive working fork ${workingId} failed: ${error instanceof Error ? error.message : String(error)}`,
      )
    }
  }

  private async sweepWorkingForks(): Promise<void> {
    for (const channel of this.channels.values()) {
      if (channel.mode !== 'fork') continue
      await this.archiveWorking(channel.workingId)
    }
  }

  private canRetire(channel: ConsultChannel): boolean {
    if (channel.mode !== 'fork') return false
    if (channel.inFlight !== undefined || channel.queue.length > 0 || channel.deliveries.length > 0) {
      return false
    }
    const live = this.liveTarget(channel)
    return live === undefined || live.status === 'idle'
  }

  private cancelRetire(consultId: string): void {
    this.retireTimers.get(consultId)?.()
    this.retireTimers.delete(consultId)
  }

  private noteForkIdle(channel: ConsultChannel): void {
    this.cancelRetire(channel.id)
    if (!this.canRetire(channel) || this.config.forkIdleMs <= 0) return
    const timer = setTimeout(() => {
      this.retireTimers.delete(channel.id)
      void this.retireFork(channel, false)
    }, this.config.forkIdleMs)
    this.retireTimers.set(channel.id, () => clearTimeout(timer))
  }

  private async retireFork(
    channel: ConsultChannel,
    immediate: boolean,
  ): Promise<{ archived: boolean; disposed: boolean } | undefined> {
    if (this.disposed || channel.mode !== 'fork') return undefined
    if (!immediate && !this.canRetire(channel)) return undefined
    if (immediate && (channel.inFlight !== undefined || channel.queue.length > 0 || channel.deliveries.length > 0)) {
      return undefined
    }
    this.cancelRetire(channel.id)
    await this.archiveWorking(channel.workingId)
    const archived = this.config.archiveWorkingForks && this.isArchived(channel.workingId)
    let disposed = false
    if (channel.handle !== undefined) {
      const handle = channel.handle
      channel.handle = undefined
      try {
        await handle.dispose()
        disposed = true
      } catch (error) {
        this.ctx.logger.warn(
          `[consult] dispose working fork ${channel.workingId} failed: ${error instanceof Error ? error.message : String(error)}`,
        )
      }
    }
    if (archived || disposed) {
      this.ctx.logger.info(
        `[consult] retired working fork ${channel.workingId} (${channel.id}) archived=${String(archived)} disposed=${String(disposed)}`,
      )
    }
    return { archived, disposed }
  }

  private initiatorAgent(channel: ConsultChannel): Agent {
    const agent = this.ctx.agents.get(channel.initiatorId)
    if (agent === undefined) throw new Error(`initiating session ${channel.initiatorId} is not live`)
    return agent
  }

  private startRound(channel: ConsultChannel, caller: Agent, question: string): boolean {
    this.cancelRetire(channel.id)
    const working = this.targetAgent(channel)
    if (working.status !== 'idle') return false
    const firstNewSeq = working.session.seq
    working.followup(createUserMessage({
      content: [{ type: 'text', text: peerPrompt(caller, question, channel) }],
      source: { kind: 'plugin', plugin: 'consult', form: 'relay' },
    }))
    channel.inFlight = { firstNewSeq }
    return true
  }

  private persistBoard(channel: ConsultChannel): void {
    const text = formatBoardMessage(channel.id, channel.board)
    const message = createUserMessage({
      content: [{ type: 'text', text }],
      source: { kind: 'plugin', plugin: 'consult', form: 'notice', summary: `consult board ${channel.id.slice(0, 8)}` },
    })
    const initiator = this.ctx.agents.get(channel.initiatorId)
    if (initiator !== undefined) {
      if (initiator.status === 'idle') {
        this.ctx.agents.withoutInitiator(() => {
          initiator.followup(message)
        })
      } else {
        initiator.send(message, 'next-step', false)
      }
    }
    if (channel.mode === 'align') {
      const working = this.ctx.agents.get(channel.workingId)
      if (working !== undefined && working.id !== channel.initiatorId) {
        const copy = createUserMessage({
          content: [{ type: 'text', text }],
          source: { kind: 'plugin', plugin: 'consult', form: 'notice', summary: `consult board ${channel.id.slice(0, 8)}` },
        })
        if (working.status === 'idle') {
          this.ctx.agents.withoutInitiator(() => {
            working.followup(copy)
          })
        } else {
          working.send(copy, 'next-step', false)
        }
      }
    }
  }

  private deliverAskBack(channel: ConsultChannel, text: string): 'followup' | 'queued' {
    const initiator = this.initiatorAgent(channel)
    const message = createUserMessage({
      content: [{
        type: 'text',
        text: `[consult-ask ${channel.id} from working=${channel.workingId}]\n${text}`,
      }],
      source: { kind: 'plugin', plugin: 'consult', form: 'relay' },
    })
    if (initiator.status === 'idle') {
      this.ctx.agents.withoutInitiator(() => {
        initiator.followup(message)
      })
      return 'followup'
    }
    channel.deliveries.push({
      consultId: channel.id,
      workingSessionId: channel.workingId,
      sourceSessionId: channel.sourceId,
      round: channel.rounds,
      kind: 'ask-back',
      reply: text,
    })
    return 'queued'
  }

  private collectInFlight(channel: ConsultChannel): ConsultDelivery {
    const inFlight = channel.inFlight
    if (inFlight === undefined) {
      throw new Error(`consult ${channel.id} has no in-flight round`)
    }
    channel.inFlight = undefined
    channel.rounds += 1
    const stopped = channel.stopRequested
    channel.stopRequested = false
    const suffix = this.targetAgent(channel).session.events.filter(event => event.seq >= inFlight.firstNewSeq)
    const reply = lastAssistantText(suffix).trim()
    if (stopped) {
      return {
        consultId: channel.id,
        workingSessionId: channel.workingId,
        sourceSessionId: channel.sourceId,
        round: channel.rounds,
        ...reply.length > 0 ? { reply } : {},
        stopped: true,
        ...reply.length === 0 ? { error: 'stopped by initiator before any visible text' } : {},
      }
    }
    if (!turnCompleted(suffix) || reply.length === 0) {
      return {
        consultId: channel.id,
        workingSessionId: channel.workingId,
        sourceSessionId: channel.sourceId,
        round: channel.rounds,
        error: channel.mode === 'align'
          ? `aligned session ${channel.workingId} did not finish with assistant text`
          : `working fork ${channel.workingId} did not finish with assistant text`,
      }
    }
    return {
      consultId: channel.id,
      workingSessionId: channel.workingId,
      sourceSessionId: channel.sourceId,
      round: channel.rounds,
      reply,
    }
  }

  private async settleInFlight(channel: ConsultChannel, caller: Agent): Promise<void> {
    if (this.disposed || channel.inFlight === undefined) return
    try {
      await this.targetAgent(channel).whenIdle()
      if (this.disposed || channel.inFlight === undefined) return
      const delivery = this.collectInFlight(channel)
      channel.deliveries.push(delivery)
    } catch (error) {
      if (channel.inFlight !== undefined) {
        channel.inFlight = undefined
        channel.rounds += 1
        channel.deliveries.push({
          consultId: channel.id,
          workingSessionId: channel.workingId,
          sourceSessionId: channel.sourceId,
          round: channel.rounds,
          error: error instanceof Error ? error.message : String(error),
        })
      }
    }
    await this.pumpQueue(channel, caller)
  }

  private schedulePump(channel: ConsultChannel, caller: Agent): void {
    if (this.disposed || channel.inFlight !== undefined || channel.queue.length === 0) return
    const working = this.liveTarget(channel)
    if (working === undefined || working.status !== 'idle') return
    void this.ctx.agents.withoutInitiator(() => this.pumpQueue(channel, caller))
  }

  private async pumpQueue(channel: ConsultChannel, caller: Agent): Promise<void> {
    if (this.disposed || channel.inFlight !== undefined) return
    const working = this.liveTarget(channel)
    if (working !== undefined && working.status !== 'idle') return
    const question = channel.queue.shift()
    if (question === undefined) {
      this.noteForkIdle(channel)
      return
    }
    if (!this.startRound(channel, caller, question)) {
      channel.queue.unshift(question)
      return
    }
    await this.settleInFlight(channel, caller)
  }

  private flushDeliveriesIfIdle(agent: Agent): void {
    if (agent.status !== 'idle') return
    const messages = this.takeDeliveryMessages(agent)
    if (messages.length === 0) return
    const text = messages.flatMap(message =>
      message.content.flatMap(block => block.type === 'text' ? [block.text] : []),
    ).join('\n\n')
    if (text.length === 0) return
    this.ctx.agents.withoutInitiator(() => {
      agent.followup(createUserMessage({
        content: [{ type: 'text', text }],
        source: { kind: 'plugin', plugin: 'consult' },
      }))
    })
  }

  private takeDeliveryMessages(caller: Agent) {
    const deliveries: ConsultDelivery[] = []
    for (const channel of this.channels.values()) {
      if (channel.initiatorId !== caller.id) continue
      if (channel.deliveries.length === 0) continue
      deliveries.push(...channel.deliveries.splice(0))
      this.noteForkIdle(channel)
    }
    return deliveries.map(delivery => createUserMessage({
      content: [{ type: 'text', text: formatDelivery(delivery) }],
      source: { kind: 'plugin', plugin: 'consult' },
    }))
  }

  private consultEvents(channel: ConsultChannel): SessionEvent[] {
    const agent = this.liveTarget(channel)
    if (agent === undefined) return []
    return agent.session.events.filter(event => event.seq >= channel.visibleFromSeq)
  }

  private visibleParts(channel: ConsultChannel): string[] {
    return recentVisibleParts(this.consultEvents(channel), 2)
  }

  private toProgress(channel: ConsultChannel): ConsultProgress {
    const currentTool = lastOpenTool(this.consultEvents(channel))
    return {
      consultId: channel.id,
      workingSessionId: channel.workingId,
      sourceSessionId: channel.sourceId,
      mode: channel.mode,
      state: this.toStatus(channel).state,
      ...currentTool !== undefined ? { currentTool } : {},
      parts: truncateProgressParts(this.visibleParts(channel)),
    }
  }

  private toStatus(channel: ConsultChannel): ConsultStatus {
    return {
      consultId: channel.id,
      sourceSessionId: channel.sourceId,
      workingSessionId: channel.workingId,
      mode: channel.mode,
      fork: forkLabel(channel, false),
      rounds: channel.rounds,
      state: channel.inFlight !== undefined
        ? 'running'
        : channel.queue.length > 0 ? 'queued' : 'idle',
      queueDepth: channel.queue.length,
      undelivered: channel.deliveries.length,
      ...channel.promotedId !== undefined ? { promotedSessionId: channel.promotedId } : {},
    }
  }

  private resolveSource(caller: Agent, targetId: string): Agent {
    const id = SessionId(targetId)
    if (id === caller.id) throw new Error('cannot consult your own session')
    const working = this.channelByWorking(id)
    if (working !== undefined) {
      if (working.initiatorId !== caller.id) {
        throw new Error(`working copy ${targetId} belongs to another consult`)
      }
      const source = this.ctx.agents.get(working.sourceId)
      if (source === undefined) throw new Error(`original session ${working.sourceId} is not live`)
      return source
    }
    const agent = this.ctx.agents.get(id)
    if (agent === undefined) throw new Error(`session ${targetId} is not a live agent`)
    return agent
  }

  private resolveChannel(caller: Agent, consultIdOrSource: string): ConsultChannel {
    const byId = this.channels.get(consultIdOrSource)
    if (byId !== undefined) {
      if (byId.initiatorId !== caller.id) throw new Error('consult belongs to another session')
      return byId
    }
    const pairKey = `${caller.id}\0${consultIdOrSource}`
    const forkId = this.primaryByPair.get(pairKey)
    const alignId = this.alignByPair.get(pairKey)
    if (forkId !== undefined && alignId !== undefined) {
      throw new Error(`both a fork and an align consult exist for ${consultIdOrSource}; pass consult_id`)
    }
    const mapped = forkId ?? alignId
    if (mapped !== undefined) {
      const channel = this.channels.get(mapped)
      if (channel !== undefined) return channel
    }
    throw new Error(`no consult matching "${consultIdOrSource}" for this session`)
  }

  private resolveWorkingChannel(caller: Agent, consultId?: string): ConsultChannel {
    if (consultId !== undefined) {
      const channel = this.channels.get(consultId)
      if (channel === undefined) throw new Error(`no consult matching "${consultId}"`)
      if (channel.workingId !== caller.id) throw new Error('consult_ask is only for the answering session')
      return channel
    }
    const matches = [...this.channels.values()].filter(channel => channel.workingId === caller.id)
    if (matches.length === 0) throw new Error('this session is not the answering side of a consult')
    if (matches.length > 1) throw new Error('multiple consults target this session; pass consult_id')
    return matches[0]!
  }

  private resolveEitherSide(caller: Agent, consultId?: string): ConsultChannel {
    if (consultId !== undefined) {
      const channel = this.channels.get(consultId)
      if (channel === undefined) throw new Error(`no consult matching "${consultId}"`)
      if (channel.initiatorId !== caller.id && channel.workingId !== caller.id) {
        throw new Error('consult_board is only for a session on this channel')
      }
      return channel
    }
    const matches = [...this.channels.values()].filter(channel =>
      channel.initiatorId === caller.id || channel.workingId === caller.id,
    )
    if (matches.length === 0) throw new Error('this session has no consult channel')
    if (matches.length > 1) throw new Error('multiple consults involve this session; pass consult_id')
    return matches[0]!
  }

  private alignChannelForSource(sourceId: SessionId, initiatorId: SessionId): ConsultChannel | undefined {
    for (const channel of this.channels.values()) {
      if (channel.mode === 'align' && channel.sourceId === sourceId && channel.initiatorId === initiatorId) {
        return channel
      }
    }
    return undefined
  }

  private channelByWorking(id: SessionId): ConsultChannel | undefined {
    for (const channel of this.channels.values()) {
      if (channel.mode === 'fork' && channel.workingId === id) return channel
    }
    return undefined
  }

  private channelByPromoted(id: SessionId): ConsultChannel | undefined {
    for (const channel of this.channels.values()) {
      if (channel.promotedId === id) return channel
    }
    return undefined
  }

  private registerPrompt(): void {
    const prompt = this.ctx.get('systemPrompt')
    if (prompt === undefined) return
    prompt.section({
      name: 'plugin:consult',
      order: 114,
      text: (assemble: AssembleContext) => this.consultSectionText(assemble.agent),
    })
  }

  private consultSectionText(caller: Agent | undefined): string {
    if (caller !== undefined && this.workingIds.has(caller.id)) {
      return WORKING_COPY_CONTEXT
    }
    const roster = caller === undefined ? '' : this.formatColleagueRoster(caller)
    return roster.length > 0 ? `${CONSULT_RULES}\n\n${roster}` : CONSULT_RULES
  }

  private formatColleagueRoster(caller: Agent): string {
    const peers = this.listPeers(caller).filter(entry => entry.kind === 'source')
    if (peers.length === 0) {
      return 'No other live colleague sessions right now. If the user asked you to consult one, say so; do not invent a peer.'
    }
    const lines = peers.slice(0, 8).map(entry => {
      const open = entry.consultId !== undefined
        ? ` — already on consult ${entry.consultId} (${entry.mode ?? 'fork'})`
        : ''
      return `- ${entry.title} (${entry.sessionId})${open}`
    })
    return ['Live colleagues this turn (call ask_peer with that session_id):', ...lines].join('\n')
  }

  private registerDeliveryHook(): void {
    this.ctx.on('tools/post-execute', async (exec, _result, next): Promise<PostToolDecision> => {
      const decision = await next()
      const caller = exec.agent
      if (caller === undefined || this.workingIds.has(caller.id)) return decision
      const extra = this.takeDeliveryMessages(caller)
      if (extra.length === 0) return decision
      return {
        ...decision,
        additionalContexts: [...decision.additionalContexts ?? [], ...extra],
      }
    })
  }

  private registerIdleHook(): void {
    this.ctx.on('agent/status', ({ agent, status }) => {
      if (status !== 'idle' || this.disposed) return
      this.flushDeliveriesIfIdle(agent)
      for (const channel of this.channels.values()) {
        if (channel.workingId !== agent.id) continue
        const initiator = this.ctx.agents.get(channel.initiatorId)
        if (initiator === undefined) continue
        this.schedulePump(channel, initiator)
      }
    }, { global: true })
  }

  private registerCommands(): void {
    const commands = this.ctx.get('commands')
    if (commands === undefined) return
    commands.register({
      name: 'consult-status',
      description: 'List this session\'s peer consults (forks and align channels).',
      handler: (invocation) => {
        const rows = this.statusFor(invocation.agent)
        if (rows.length === 0) return { kind: 'success', text: 'No consults from this session.' }
        return {
          kind: 'success',
          text: rows.map(row => formatStatus(row)).join('\n'),
        }
      },
    })
    commands.register({
      name: 'consult-progress',
      description: 'Show truncated visible assistant texts from a consult target.',
      input: { hint: 'consult id or source session id' },
      handler: (invocation) => {
        const target = invocation.rawInput.trim()
        if (target.length === 0) {
          return { kind: 'error', text: 'Usage: /consult-progress <consult-id-or-source-session-id>' }
        }
        try {
          const row = this.progress(invocation.agent, target)
          const body = row.parts.length === 0 ? '(no visible text yet)' : row.parts.map((part, index) => `--- part ${index + 1} ---\n${part}`).join('\n')
          const tool = row.currentTool !== undefined ? ` currentTool=${row.currentTool}` : ''
          return { kind: 'success', text: `${row.consultId} state=${row.state}${tool}\n${body}` }
        } catch (error) {
          return { kind: 'error', text: error instanceof Error ? error.message : String(error) }
        }
      },
    })
    commands.register({
      name: 'consult-stop',
      description: 'Cancel the consult target\'s in-flight turn and drop queued follow-ups. Align mode cancels the original session.',
      input: { hint: 'consult id or source session id' },
      handler: (invocation) => {
        const target = invocation.rawInput.trim()
        if (target.length === 0) {
          return { kind: 'error', text: 'Usage: /consult-stop <consult-id-or-source-session-id>' }
        }
        try {
          const row = this.stop(invocation.agent, target)
          return { kind: 'success', text: JSON.stringify(row, null, 2) }
        } catch (error) {
          return { kind: 'error', text: error instanceof Error ? error.message : String(error) }
        }
      },
    })
    commands.register({
      name: 'consult-promote',
      description: 'Copy a fork-mode working copy into an independent session. Not valid for align consults.',
      input: { hint: 'consult id or source session id' },
      handler: async (invocation) => {
        const target = invocation.rawInput.trim()
        if (target.length === 0) {
          return { kind: 'error', text: 'Usage: /consult-promote <consult-id-or-source-session-id>' }
        }
        try {
          const result = await this.promote(invocation.agent, target, invocation.signal)
          return {
            kind: 'success',
            text: `Independent session ${result.independentSessionId} copied from working fork. Original ${result.sourceSessionId} was not modified.`,
          }
        } catch (error) {
          return { kind: 'error', text: error instanceof Error ? error.message : String(error) }
        }
      },
    })
    commands.register({
      name: 'consult-cleanup',
      description: 'Archive and dispose idle working forks opened by this session. Does not touch the original peer or align targets.',
      handler: async (invocation) => {
        try {
          const result = await this.cleanupIdleForks(invocation.agent)
          if (result.archived.length === 0 && result.disposed.length === 0) {
            return { kind: 'success', text: 'No idle working forks to clean up.' }
          }
          return {
            kind: 'success',
            text: [
              result.archived.length > 0 ? `Archived: ${result.archived.join(', ')}` : undefined,
              result.disposed.length > 0 ? `Disposed: ${result.disposed.join(', ')}` : undefined,
            ].filter((line): line is string => line !== undefined).join('\n'),
          }
        } catch (error) {
          return { kind: 'error', text: error instanceof Error ? error.message : String(error) }
        }
      },
    })
  }

  private registerTools(): void {
    const service = this
    this.ctx.tools.register(defineTool({
      name: 'list_peers',
      description:
        'List live colleague sessions (id + title). Do not read their workspace directory — that path is a folder, not a file. Call ask_peer with session_id. One question → one peer.',
      parameters: {},
      output: {
        schema: {
          type: 'array',
          items: {
            type: 'object',
            additionalProperties: false,
            properties: {
              sessionId: { type: 'string', required: true },
              title: { type: 'string', required: true },
              kind: { type: 'string', required: true },
              lastActiveAt: { type: 'number', required: true },
              consultId: { type: 'string' },
              mode: { type: 'string' },
            },
          },
        },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
      },
      async execute(_args, exec) {
        return service.listPeers(requireAgent(exec.agent))
      },
    }))

    this.ctx.tools.register(defineTool({
      name: 'ask_peer',
      description:
        'Talk to a live colleague session. Use this instead of re-researching what they already know. Required when the user wants alignment (对齐) or when another session owns the context. Pass known and tasks. wait_ms typically 30000 — only waits if the peer is already idle. If they are busy, this returns queued immediately and does not interrupt them. align=true writes their original session.',
      parameters: {
        session_id: {
          type: 'string',
          required: true,
          description: 'Source session id from list_peers (the original, not a working copy).',
        },
        question: {
          type: 'string',
          required: true,
          description: 'Requirements and doubts for the peer. State what you need and what you are unsure about.',
        },
        wait_ms: {
          type: 'integer',
          required: true,
          description:
            'Milliseconds to wait synchronously for this reply before continuing. 0 returns immediately. Typical: 30000. Only the first ask_peer in a step waits.',
        },
        consult_id: {
          type: 'string',
          description: 'Continue this consult channel. Omit to reuse the primary fork or align channel for session_id.',
        },
        fresh: {
          type: 'boolean',
          description: 'If true, fork a clean working copy from the original session. Omit consult_id. Not valid with align=true.',
        },
        align: {
          type: 'boolean',
          description: 'If true, write this consult into the original session A. Default false uses a working fork A\'.',
        },
        known: {
          type: 'string',
          description: 'What you already know (newline-separated). The peer must not re-research these facts.',
        },
        tasks: {
          type: 'string',
          description: 'Newline-separated tasks for the peer. Keep other work on your side.',
        },
        welcome_questions: {
          type: 'boolean',
          description: 'If true (default), the peer may consult_ask to clarify before overlapping research.',
        },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            status: { type: 'string', required: true },
            consultId: { type: 'string', required: true },
            workingSessionId: { type: 'string', required: true },
            sourceSessionId: { type: 'string', required: true },
            mode: { type: 'string', required: true },
            fork: { type: 'string', required: true },
            waitMs: { type: 'number', required: true },
            round: { type: 'number' },
            reply: { type: 'string' },
            queueDepth: { type: 'number' },
            note: { type: 'string' },
            board: { type: 'object', additionalProperties: true, required: true },
          },
        },
        render: (_args, value) => [{ type: 'text', text: renderAsk(value) }],
      },
      async execute(args, exec) {
        return service.askPeer(requireAgent(exec.agent), {
          sessionId: args.session_id,
          question: args.question,
          waitMs: args.wait_ms,
          ...args.consult_id !== undefined ? { consultId: args.consult_id } : {},
          ...args.fresh !== undefined ? { fresh: args.fresh } : {},
          ...args.align !== undefined ? { align: args.align } : {},
          ...args.known !== undefined ? { known: args.known } : {},
          ...args.tasks !== undefined ? { tasks: args.tasks } : {},
          ...args.welcome_questions !== undefined ? { welcomeQuestions: args.welcome_questions } : {},
        }, exec.signal)
      },
    }))

    this.ctx.tools.register(defineTool({
      name: 'consult_status',
      description: 'List consult channels this session opened, including mode (fork/align), running/queued state, and undelivered replies.',
      parameters: {},
      output: {
        schema: {
          type: 'array',
          items: {
            type: 'object',
            additionalProperties: false,
            properties: {
              consultId: { type: 'string', required: true },
              sourceSessionId: { type: 'string', required: true },
              workingSessionId: { type: 'string', required: true },
              mode: { type: 'string', required: true },
              fork: { type: 'string', required: true },
              rounds: { type: 'number', required: true },
              state: { type: 'string', required: true },
              queueDepth: { type: 'number', required: true },
              undelivered: { type: 'number', required: true },
              promotedSessionId: { type: 'string' },
            },
          },
        },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
      },
      async execute(_args, exec) {
        return service.statusFor(requireAgent(exec.agent))
      },
    }))

    this.ctx.tools.register(defineTool({
      name: 'consult_progress',
      description:
        'Read short truncated snippets of the target\'s latest visible text, plus any in-flight tool. Does not wait. The full reply is delivered once separately.',
      parameters: {
        consult_id: {
          type: 'string',
          required: true,
          description: 'Consult id from ask_peer / consult_status, or the original source session id.',
        },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            consultId: { type: 'string', required: true },
            workingSessionId: { type: 'string', required: true },
            sourceSessionId: { type: 'string', required: true },
            mode: { type: 'string', required: true },
            state: { type: 'string', required: true },
            currentTool: { type: 'string' },
            parts: {
              type: 'array',
              required: true,
              items: { type: 'string' },
            },
          },
        },
        render: (_args, value) => [{ type: 'text', text: renderProgress(value) }],
      },
      async execute(args, exec) {
        return service.progress(requireAgent(exec.agent), args.consult_id)
      },
    }))

    this.ctx.tools.register(defineTool({
      name: 'consult_stop',
      description:
        'Stop a consult target\'s current turn and drop queued follow-ups. Partial text is returned here and is not delivered again. Align mode cancels A itself.',
      parameters: {
        consult_id: {
          type: 'string',
          required: true,
          description: 'Consult id from ask_peer / consult_status, or the original source session id.',
        },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            consultId: { type: 'string', required: true },
            stopped: { type: 'boolean', required: true },
            clearedQueue: { type: 'number', required: true },
            parts: {
              type: 'array',
              required: true,
              items: { type: 'string' },
            },
            note: { type: 'string', required: true },
          },
        },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
      },
      async execute(args, exec) {
        return service.stop(requireAgent(exec.agent), args.consult_id)
      },
    }))

    this.ctx.tools.register(defineTool({
      name: 'consult_board',
      description:
        'Read or update the shared consult board. Either side may claim/complete tasks and add known facts. Only the initiator may add tasks or answer clarifying questions.',
      parameters: {
        consult_id: {
          type: 'string',
          description: 'Consult id. Required if this session has more than one channel.',
        },
        add_known: {
          type: 'string',
          description: 'Newline-separated facts to add to the already-known list.',
        },
        add_task: {
          type: 'string',
          description: 'Title of a new task (initiator only).',
        },
        owner: {
          type: 'string',
          description: 'Owner for add_task: initiator or peer. Default peer.',
        },
        claim_task: {
          type: 'string',
          description: 'Task id to claim (sets owner to you and status doing).',
        },
        complete_task: {
          type: 'string',
          description: 'Task id to mark done.',
        },
        answer_id: {
          type: 'string',
          description: 'Clarifying question id to answer (initiator only).',
        },
        answer: {
          type: 'string',
          description: 'Answer text for answer_id.',
        },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            consultId: { type: 'string', required: true },
            board: { type: 'object', additionalProperties: true, required: true },
          },
        },
        render: (_args, value) => [{ type: 'text', text: renderBoard(value) }],
      },
      async execute(args, exec) {
        const owner = args.owner === 'initiator' || args.owner === 'peer' ? args.owner : undefined
        return service.consultBoard(requireAgent(exec.agent), {
          ...args.consult_id !== undefined ? { consultId: args.consult_id } : {},
          ...args.add_known !== undefined ? { addKnown: args.add_known } : {},
          ...args.add_task !== undefined ? { addTask: args.add_task } : {},
          ...owner !== undefined ? { owner } : {},
          ...args.claim_task !== undefined ? { claimTask: args.claim_task } : {},
          ...args.complete_task !== undefined ? { completeTask: args.complete_task } : {},
          ...args.answer_id !== undefined ? { answerId: args.answer_id } : {},
          ...args.answer !== undefined ? { answer: args.answer } : {},
        })
      },
    }))

    this.ctx.tools.register(defineTool({
      name: 'consult_ask',
      description:
        'Ask the initiating session a clarifying question on this consult channel. Only the answering session (A or A\') may call this. Do not use ask_peer.',
      parameters: {
        question: {
          type: 'string',
          required: true,
          description: 'What you need the initiator to clarify before you continue.',
        },
        consult_id: {
          type: 'string',
          description: 'Consult id. Required if this session answers more than one consult.',
        },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            consultId: { type: 'string', required: true },
            questionId: { type: 'string', required: true },
            delivered: { type: 'string', required: true },
            board: { type: 'object', additionalProperties: true, required: true },
          },
        },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
      },
      async execute(args, exec) {
        return service.consultAsk(
          requireAgent(exec.agent),
          args.question,
          args.consult_id,
        )
      },
    }))

    this.ctx.tools.register(defineTool({
      name: 'promote_consult',
      description:
        'Copy a fork-mode working copy into a new independent session. Not valid for align consults.',
      parameters: {
        consult_id: {
          type: 'string',
          required: true,
          description: 'Consult id from ask_peer / consult_status, or the original source session id.',
        },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            consultId: { type: 'string', required: true },
            independentSessionId: { type: 'string', required: true },
            sourceSessionId: { type: 'string', required: true },
          },
        },
        render: (_args, value) => [{
          type: 'text',
          text: typeof value === 'object' && value !== null && 'independentSessionId' in value
            ? `Independent session ${(value as PromoteResult).independentSessionId}`
            : JSON.stringify(value),
        }],
      },
      async execute(args, exec) {
        return service.promote(requireAgent(exec.agent), args.consult_id, exec.signal)
      },
    }))
  }

  private disposeAll(): void {
    this.disposed = true
    for (const cancel of this.retireTimers.values()) cancel()
    this.retireTimers.clear()
    for (const channel of this.channels.values()) {
      if (channel.mode !== 'fork') continue
      void this.archiveWorking(channel.workingId)
      const handle = channel.handle
      channel.handle = undefined
      if (handle !== undefined) {
        void handle.dispose().catch((error: unknown) => {
          this.ctx.logger.warn(
            `[consult] dispose working fork ${channel.workingId} on unload failed: ${error instanceof Error ? error.message : String(error)}`,
          )
        })
      }
    }
    this.channels.clear()
    this.primaryByPair.clear()
    this.alignByPair.clear()
    this.workingIds.clear()
  }
}


function requireAgent(agent: Agent | undefined): Agent {
  if (agent === undefined) throw new Error('consult tools require a calling agent')
  return agent
}

function forkLabel(channel: ConsultChannel, created: boolean): ConsultFork {
  if (channel.mode === 'align') return 'source'
  if (channel.fresh) return 'fresh'
  if (created || channel.rounds === 0) return 'new'
  return 'continued'
}

function peerPrompt(caller: Agent, question: string, channel: ConsultChannel): string {
  const modeLine = channel.mode === 'align'
    ? `A colleague session (${caller.id}) is consulting you in place. This message is written into this session log.`
    : `A colleague session (${caller.id}) is consulting a working copy of you. The original session is not receiving this message.`
  return [
    modeLine,
    'Answer from this session\'s existing context and the board first. Do not re-research facts listed as already known.',
    'If you need clarification, call consult_ask (not ask_peer). Use consult_board to claim or complete tasks.',
    '',
    formatBoardForPrompt(channel.board),
    '',
    question,
  ].join('\n')
}

function renderBoard(value: unknown): string {
  if (typeof value !== 'object' || value === null || !('consultId' in value) || !('board' in value)) {
    return JSON.stringify(value)
  }
  const row = value as ConsultBoardResult
  return formatBoardMessage(row.consultId, row.board)
}

function formatStatus(row: ConsultStatus): string {
  const promoted = row.promotedSessionId !== undefined ? ` promoted=${row.promotedSessionId}` : ''
  return `${row.consultId}: mode=${row.mode} source=${row.sourceSessionId} working=${row.workingSessionId} fork=${row.fork} state=${row.state} rounds=${row.rounds} queued=${row.queueDepth} undelivered=${row.undelivered}${promoted}`
}

function formatDelivery(delivery: ConsultDelivery): string {
  if (delivery.kind === 'ask-back') {
    return `[consult-ask ${delivery.consultId} from working=${delivery.workingSessionId}]\n${delivery.reply ?? ''}`
  }
  const head = `[consult ${delivery.consultId} round ${delivery.round} working=${delivery.workingSessionId}]`
  if (delivery.stopped === true) {
    return `${head} stopped\n${delivery.reply ?? delivery.error ?? ''}`
  }
  if (delivery.error !== undefined) return `${head} failed: ${delivery.error}`
  return `${head}\n${delivery.reply ?? ''}`
}

function renderProgress(value: unknown): string {
  if (typeof value !== 'object' || value === null) return JSON.stringify(value)
  const row = value as ConsultProgress
  const tool = row.currentTool !== undefined ? ` currentTool=${row.currentTool}` : ''
  const body = row.parts.length === 0
    ? '(no visible text yet)'
    : row.parts.map((part, index) => `--- part ${index + 1} ---\n${part}`).join('\n')
  return `${row.consultId} state=${row.state}${tool}\n${body}`
}

function lastOpenTool(events: readonly SessionEvent[]): string | undefined {
  const open = new Set<string>()
  const names = new Map<string, string>()
  for (const event of events) {
    if (event.type === 'tool/call') {
      open.add(event.data.callId)
      names.set(event.data.callId, event.data.name)
    } else if (event.type === 'tool/result') {
      open.delete(event.data.message.content[0].toolCallId)
    }
  }
  const last = [...open].at(-1)
  return last !== undefined ? names.get(last) : undefined
}

function renderAsk(value: unknown): string {
  if (typeof value !== 'object' || value === null) return JSON.stringify(value)
  const result = value as AskPeerResult
  const head = JSON.stringify({
    consultId: result.consultId,
    workingSessionId: result.workingSessionId,
    sourceSessionId: result.sourceSessionId,
    mode: result.mode,
    fork: result.fork,
    status: result.status,
    ...result.round !== undefined ? { round: result.round } : {},
  })
  const board = formatBoardMessage(result.consultId, result.board)
  if (result.status === 'ready' || result.status === 'stopped') {
    return `${RESULT_PREFIX}${head}\n${board}\n${result.reply ?? ''}`
  }
  return `${RESULT_PREFIX}${head}\n${board}\n${JSON.stringify(result, null, 2)}`
}

function parseConsultResult(text: string): {
  consultId: string
  workingSessionId: SessionId
  sourceSessionId: SessionId
  mode: ConsultMode
  fork: ConsultFork
  status: string
  round?: number
} | undefined {
  const trimmed = text.trim()
  const jsonText = trimmed.startsWith(RESULT_PREFIX)
    ? (trimmed.slice(RESULT_PREFIX.length).split('\n')[0] ?? '')
    : trimmed.startsWith('{')
      ? trimmed
      : ''
  if (jsonText.length === 0) return undefined
  try {
    const value: unknown = JSON.parse(jsonText)
    if (typeof value !== 'object' || value === null) return undefined
    const row = value as Record<string, unknown>
    if (typeof row.consultId !== 'string' || typeof row.workingSessionId !== 'string' || typeof row.sourceSessionId !== 'string') {
      return undefined
    }
    if (row.mode !== 'fork' && row.mode !== 'align') return undefined
    const fork = row.fork === 'new' || row.fork === 'continued' || row.fork === 'fresh' || row.fork === 'source'
      ? row.fork
      : 'continued'
    return {
      consultId: row.consultId,
      workingSessionId: SessionId(row.workingSessionId),
      sourceSessionId: SessionId(row.sourceSessionId),
      mode: row.mode,
      fork,
      status: typeof row.status === 'string' ? row.status : 'pending',
      ...typeof row.round === 'number' ? { round: row.round } : {},
    }
  } catch {
    return undefined
  }
}

function toolResultText(event: SessionEvent): string {
  if (event.type !== 'tool/result') return ''
  const block = event.data.message.content[0]
  const inner = block.content
  return inner
    .filter((item): item is { type: 'text'; text: string } => item.type === 'text')
    .map(item => item.text)
    .join('\n')
}

function userMessageText(event: SessionEvent): string {
  if (event.type !== 'user/message') return ''
  return event.data.content
    .filter((item): item is { type: 'text'; text: string } => item.type === 'text')
    .map(item => item.text)
    .join('\n')
}

function lastActiveAt(session: Session): number {
  const last = session.events.at(-1)
  return last?.time ?? session.header.createdAt
}

function stepAlreadyHasAskPeerResult(agent: Agent): boolean {
  const events = agent.session.events
  const start = events.findLast(event => event.type === 'step/start')
  if (start === undefined) return false
  const { turn, step } = start.data
  const callIds = new Set<string>()
  for (const event of events) {
    if (event.type === 'tool/call' && event.data.turn === turn && event.data.step === step && event.data.name === 'ask_peer') {
      callIds.add(event.data.callId)
    } else if (event.type === 'tool/result' && event.data.turn === turn && event.data.step === step) {
      const callId = event.data.message.content[0]?.toolCallId
      if (callId !== undefined && callIds.has(callId)) return true
    }
  }
  return false
}

function abortError(signal: AbortSignal): Error {
  return signal.reason instanceof Error ? signal.reason : new Error('consult aborted')
}

function waitAbort(signal: AbortSignal): Promise<never> {
  return new Promise((_, reject) => {
    if (signal.aborted) {
      reject(abortError(signal))
      return
    }
    signal.addEventListener('abort', () => reject(abortError(signal)), { once: true })
  })
}

async function waitUntilIdle(working: Agent, waitMs: number, signal: AbortSignal): Promise<'idle' | 'timeout'> {
  if (signal.aborted) throw abortError(signal)
  if (waitMs === 0) return 'timeout'
  const timeout = AbortSignal.timeout(waitMs)
  const combined = AbortSignal.any([signal, timeout])
  try {
    await Promise.race([working.whenIdle(), waitAbort(combined)])
    return 'idle'
  } catch (error) {
    if (signal.aborted) throw abortError(signal)
    if (timeout.aborted) return 'timeout'
    throw error
  }
}

function turnCompleted(events: readonly SessionEvent[]): boolean {
  return events.some(event =>
    event.type === 'turn/end' && event.data.reason.kind === 'completed',
  )
}

function applyWorkingCopySetup(agentCtx: Context, source: Agent | undefined): void {
  if (source !== undefined) {
    agentCtx.get('agentPresets')?.composeFrom(agentCtx, source.ctx)
  }
  pinWorkingApproval(agentCtx)
  denyInitiatorConsultTools(agentCtx)
  agentCtx.get('systemPrompt')?.context({
    name: 'consult:working-copy',
    order: 120,
    text: WORKING_COPY_CONTEXT,
  })
}

function pinWorkingApproval(agentCtx: Context): void {
  const session = agentCtx.agent?.session
  if (session === undefined) return
  if (agentCtx.get('approval') === undefined) return
  session.append('approval/policy', { policy: 'never', source: 'delegation' })
}

function denyInitiatorConsultTools(agentCtx: Context): void {
  const deny = INITIATOR_ONLY_TOOLS.filter(name =>
    agentCtx.tools.get(name, agentCtx.agent) !== undefined
    || agentCtx.tools.get(name) !== undefined,
  )
  if (deny.length > 0) agentCtx.tools.restrict({ deny })
}
