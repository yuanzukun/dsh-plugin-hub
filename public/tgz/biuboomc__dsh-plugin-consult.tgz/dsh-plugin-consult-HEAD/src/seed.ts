import type { SessionEvent } from '@deepseek-ai/dsh-session'
import type { Agent } from '@deepseek-ai/dsh-agent'

/**
 * Balanced completed-turn prefix of an agent's log.
 * The in-flight turn is excluded; before any completed turn the seed is empty.
 */
export function completedTurnPrefix(agent: Agent): SessionEvent[] {
  const events = agent.session.events
  const lastEnd = events.findLast(event => event.type === 'turn/end')
  if (lastEnd === undefined) return []
  return events.slice(0, lastEnd.seq + 1)
}
