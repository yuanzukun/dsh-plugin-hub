#!/usr/bin/env node
// dsh-plugin-doctor：dsh 插件「完整性 + 运行流畅」一体检测器
// 分组：静态·包结构(R) / 静态·cordis 契约扫描(K) / 动态·沙箱冒烟(D) / 生态·集合站清单(CC)
//
// 不可变契约（R-fix 0B）：name 前缀 / results 扁平数组 / stdout 含 "R0 " 与 "K1 " /
// 退出码 0(通过) 1(插件缺陷) 2(用法错误) 语义不变。新增码 3/4/5/6 只在原本会误判的场景出现。
import path from 'node:path'
import { readFileSync, existsSync, mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { Doctor, verdict, render, summarizeGroups, degradedGroups } from './lib/framework.mjs'
import { addChecks as addPackageChecks } from './lib/checks-package.mjs'
import { addChecks as addCordisChecks } from './lib/checks-cordis.mjs'
import { addChecks as addRuntimeChecks } from './lib/checks-runtime.mjs'
import { addSmokeChecks } from './lib/checks-smoke.mjs'
import { addChecks as addCollectionChecks } from './lib/checks-collections.mjs'
import { quarantineSandbox, redact } from './lib/util.mjs'
import { toContract, contractExitCode } from './lib/compat.mjs'
import { locateDshInstall, hostSurfaceSummary } from './lib/host-surface.mjs'
import { deriveStandards } from './lib/standards.mjs'

const VERSION = JSON.parse(readFileSync(path.join(import.meta.dirname, 'package.json'), 'utf8')).version
const SCHEMA_VERSION = '2'
// K10–K13 = 交叉干扰组（waterfall 委托 / 工具名遮蔽 / 服务键双提供 / 覆写内置行）。
// 它们是 warn 级启发式，与 K1–K9 同属 K 组，因此不新增分组、不改 --only 语义；
// 下游仓的 plugin-doctor.yml 吃分组名而不是 checkset 串，兼容。
const CHECKSET = 'R0-R8+K1-K14+D0-D3,D9+CC1-CC5/3+X1-X5'
const QUARANTINE_PREFIX = 'doctor-quarantine-'

const USAGE = `dsh-plugin-doctor ${VERSION} —— dsh 插件完整性 + 运行流畅一体检测器

用法: node doctor.mjs --repo <插件仓路径> [选项]

选项:
  --repo, -r <路径>      被检插件仓（含 package.json）
  --workspace, -w <路径> 兄弟仓所在工作区根（用于 CC 组核对本地清单；缺省=工具自身父目录）
  --no-smoke        跳过动态沙箱冒烟（默认执行；需网络 + pnpm）
  --no-host         跳过 X 组（动态面·宿主契约：peer 走廊 / inject 服务面 / patch 可定位性）
  --host <版本>     把该宿主版本并入 X1 的求值集合（可重复；用于"我还想支持这条线"的场景）
  --dsh-install <路径> 指定一份 dsh 安装目录（默认自动探测：本工具自身、DSH_INSTALL_DIR、全局 npm 前缀）
  --dsh <版本>      D 组冒烟要安装的宿主版本。
                    默认 = **实测到的本机安装版本**；探不到就交给 D1 报 unsupported-host。
                    刻意不再回落硬编码常量：旧默认 0.1.2-rc.1 早于 peer 执法起点
                    （dsh-v0.1.7-rc.1），对走廊毫无鉴别力，且会造成 7/46 个仓的假红。
                    想刻意测最老的线，显式 --dsh 0.1.2-rc.1。
  --only <分组>     只跑指定分组（逗号分隔）。推荐用 ASCII 别名（编码安全）：
                      R  = 静态·包结构
                      K  = 静态·cordis 契约扫描
                      X  = 动态面·宿主契约（对宿主真实面求值，不手抄常量表）
                      D  = 动态·沙箱冒烟
                      CC = 生态·集合站清单
                    中文全名同样可用；大小写不敏感。
  --allow-degraded  允许「被请求的组整组未真跑」时仍返回 0（默认返回 6）
  --json <路径|->   另存 JSON 报告；传 "-" 写 stdout（此时抑制人类可读报告）
  --format <名称>   JSON 报告的形态（默认 doctor）:
                      doctor = 本工具的完整信封（5 种状态、退出码 3/4/5/6、逐项 id/分组/覆盖率）
                      check  = 生态正在收敛的三值契约（PASS/WARN/FAIL + 0/1/2），
                               见 RFC #1846。供其它 check 工具与 Action 直接消费；
                               本工具的语义差异（尤其 skip != pass）在 doctor 字段里保留，
                               并在无法无损表达时置 approximated=true
  --purge <隔离目录> 删除本工具自己产生的隔离目录（仅接受 ${QUARANTINE_PREFIX}* 前缀）
  -h, --help        显示帮助
  -v, --version     显示版本

X 组的数据来源（全部离线可读，不需要 harness checkout、不需要联网）:
  · <dsh>/node_modules/@deepseek-ai/dsh-tool-cordis/lib/types/api-catalog.js —— 官方生成物，
    导出 91 个 harness 服务 / 81 个事件 / 992 个类型声明
  · <dsh>/node_modules/@deepseek-ai/dsh-base/cordis.patch.yml —— 宿主自带行 id（当前 94 个）
  · <dsh>/node_modules/@deepseek-ai/dsh-app-boot —— **X1 直接调用宿主自己的
    evaluatePluginCompatibility**，结论与宿主逐字节同源，不存在"自研 semver 算错"的可能
  读不到安装时回落到随包发布的快照（lib/host-surface.data.mjs，带基线版本戳）并如实标注来源。
  刷新快照: npm run test:host-surface -- --write   （只比较: npm run test:host-surface）

退出码:
  0 = 无 fail/error（可含 warn/skip）
  1 = 存在 fail/error（插件缺陷）
  2 = 用法错误、未知分组或未知选项
  3 = 基础设施错误（如缺 npm/pnpm 等环境不可用）
  4 = 不支持的宿主版本（宿主安装失败，不判插件）
  5 = 结果不稳定（步骤超时）
  6 = 降级：被请求的组整组未真跑（如无源文件可扫描）—— 不得当作通过

安全: 冒烟全程使用 %TEMP% 自建沙箱（前缀 doctor-，与宿主 %TEMP%\\dsh-* 保护模板不重叠），绝不触碰真实 ~/.dsh。
      运行结束只做「隔离不删除」（rename 到 ${QUARANTINE_PREFIX}*），需人工确认后用 --purge 清理。
      注意: 任何带 --profile 的 dsh 探测都会初始化该 profile，因此必须显式传 DSH_HOME。

防静默通过: --only 里的分组名只要有一个不匹配，本工具立即以退出码 2 失败。
            被请求的分组若整组未真跑（全 skip），以退出码 6 失败——除非显式 --allow-degraded。`

const GROUP_ALIASES = {
  R: '静态·包结构',
  K: '静态·cordis 契约扫描',
  D: '动态·沙箱冒烟',
  CC: '生态·集合站清单',
  X: '动态面·宿主契约',
}

const FLAGS_WITH_VALUE = new Set(['--repo', '-r', '--workspace', '-w', '--dsh', '--json', '--only', '--purge', '--format', '--host', '--dsh-install'])

function parseArgs(argv) {
  const opts = {
    repo: null, workspace: null, smoke: true, hostGroup: true, dshVersion: null, json: null,
    groups: null, help: false, version: false, allowDegraded: false, purge: null,
    format: 'doctor', hosts: [], dshInstall: null,
  }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a === '--repo' || a === '-r') opts.repo = argv[++i]
    else if (a === '--workspace' || a === '-w') opts.workspace = argv[++i]
    else if (a === '--no-smoke') opts.smoke = false
    else if (a === '--no-host') opts.hostGroup = false
    else if (a === '--dsh') opts.dshVersion = argv[++i]
    else if (a === '--host') opts.hosts.push(String(argv[++i] ?? ''))
    else if (a === '--dsh-install') opts.dshInstall = argv[++i]
    else if (a === '--json') opts.json = argv[++i]
    else if (a === '--only') opts.groups = String(argv[++i] ?? '').split(',').map((s) => s.trim())
    else if (a === '--purge') opts.purge = argv[++i]
    else if (a === '--format') opts.format = String(argv[++i] ?? '')
    else if (a === '--allow-degraded') opts.allowDegraded = true
    else if (a === '--help' || a === '-h') opts.help = true
    else if (a === '--version' || a === '-v') opts.version = true
    else if (a.startsWith('-')) {
      // 未知选项必须报错：旧实现会把未识别长选项的值当作位置参数、静默改写 --repo（静默错靶）
      return { ...opts, error: `未知选项: ${a}` }
    } else if (opts.repo === null) {
      opts.repo = a
    } else {
      return { ...opts, error: `多余的位置参数: ${a}（--repo 已由前一个位置参数占用）` }
    }
    if (FLAGS_WITH_VALUE.has(a) && argv[i] === undefined) return { ...opts, error: `选项 ${a} 缺少取值` }
  }
  if (!['doctor', 'check'].includes(opts.format)) {
    return { ...opts, error: `未知 --format: ${opts.format}（可选: doctor, check）` }
  }
  return opts
}

function main() {
  const opts = parseArgs(process.argv.slice(2))
  if (opts.help) { console.log(USAGE); return 0 }
  if (opts.version) { console.log(VERSION); return 0 }
  if (opts.error) { console.error(`${opts.error}\n\n${USAGE}`); return 2 }

  // --purge：三段式的第三段（人工确认后清理）。只接受本工具自己的隔离目录。
  if (opts.purge) {
    const abs = path.resolve(opts.purge)
    if (!path.basename(abs).startsWith(QUARANTINE_PREFIX)) {
      console.error(`拒绝清理：只接受 ${QUARANTINE_PREFIX}* 前缀的隔离目录（收到 ${path.basename(abs)}）`)
      return 2
    }
    try { rmSync(abs, { recursive: true, force: true }) } catch (e) { console.error(`清理失败: ${e.message}`); return 3 }
    console.log(`已清理隔离目录: ${abs}`)
    return 0
  }

  if (!opts.repo) { console.error('缺少 --repo <路径>\n\n' + USAGE); return 2 }
  const repoPath = path.resolve(opts.repo)
  const pkgPath = path.join(repoPath, 'package.json')
  if (!existsSync(pkgPath)) { console.error(`未找到 ${pkgPath}`); return 2 }
  let pkg
  try { pkg = JSON.parse(readFileSync(pkgPath, 'utf8')) } catch (e) { console.error(`package.json 解析失败: ${e.message}`); return 2 }

  const runRoot = mkdtempSync(path.join(tmpdir(), 'doctor-run-'))
  const logDir = path.join(runRoot, 'logs')
  mkdirSync(logDir, { recursive: true })
  const workspaceRoot = opts.workspace ? path.resolve(opts.workspace) : path.resolve(import.meta.dirname, '..')
  // 宿主版本必须**实测**，绝不回落硬编码常量（旧实现的 0.1.2-rc.1 已过期两代，
  // 且 0.1.2-rc.1 早于 peer 执法起点 dsh-v0.1.7-rc.1，对走廊毫无鉴别力）。
  const dshInstall = locateDshInstall(opts.dshInstall ?? null)
  let dshInstallVersion = null
  if (dshInstall) {
    try {
      dshInstallVersion = JSON.parse(readFileSync(path.join(dshInstall, 'package.json'), 'utf8')).version ?? null
    } catch { dshInstallVersion = null }
  }
  const ctx = {
    repoPath,
    pkg,
    pkgName: pkg.name,
    logDir,
    workspaceRoot,
    sandboxRoots: [runRoot],
    dshInstall,
    dshInstallVersion,
    hostVersions: opts.hosts.filter(Boolean),
  }

  const doctor = new Doctor()
  addPackageChecks(doctor, ctx)
  addCordisChecks(doctor, ctx)
  if (opts.hostGroup) addRuntimeChecks(doctor, ctx)
  addCollectionChecks(doctor, ctx)
  if (opts.smoke) addSmokeChecks(doctor, ctx, { dshVersion: opts.dshVersion ?? dshInstallVersion })

  const knownGroups = [...new Set(doctor.checks.map((c) => c.group))]
  if (opts.groups) {
    const resolved = opts.groups.map((t) => GROUP_ALIASES[t.toUpperCase()] ?? t)
    const unknown = resolved.filter((g) => !knownGroups.includes(g))
    if (unknown.length > 0) {
      const smokeHint = !opts.smoke && unknown.some((g) => GROUP_ALIASES.D === g)
        ? '\n注：D 组需要动态冒烟，不能与 --no-smoke 同时请求（要么去掉 --no-smoke，要么从 --only 里去掉 D）'
        : ''
      console.error(
        `未知分组: ${unknown.join(', ')}\n` +
          `可用分组: ${knownGroups.map((g) => `${g}（${Object.keys(GROUP_ALIASES).find((a) => GROUP_ALIASES[a] === g) ?? '-'}）`).join(', ')}${smokeHint}`,
      )
      return 2
    }
    opts.groups = resolved
  }

  const started = Date.now()
  const raw = doctor.run(ctx, { groups: opts.groups })
  return Promise.resolve(raw).then((results) => finish(results, { opts, ctx, repoPath, pkg, runRoot, logDir, started }))
}

function finish(results, { opts, ctx, repoPath, pkg, runRoot, logDir, started }) {
  if (results.length === 0) {
    console.error('没有任何检查被执行（--only 未匹配到任何分组）——拒绝静默通过，退出码 2')
    return 2
  }

  // 脱敏：把本次运行注入的绝对路径替换为占位符（R-fix 0C）
  const redactPaths = [repoPath, logDir, runRoot, ...(ctx.sandboxRoots ?? [])]
  for (const r of results) {
    if (typeof r.message === 'string') r.message = redact(r.message, redactPaths)
    if (typeof r.evidence === 'string') r.evidence = redact(r.evidence, redactPaths)
  }

  const groups = summarizeGroups(results)
  const degraded = degradedGroups(groups)
  const v = verdict(results, { degraded })
  const durationMs = Date.now() - started

  const envelope = {
    schemaVersion: SCHEMA_VERSION,
    doctorVersion: VERSION,
    checksetVersion: CHECKSET,
    target: {
      repo: repoPath,
      pkgName: pkg.name,
      pkgVersion: pkg.version ?? null,
      integrity: null,          // 取自 registry（npm view <pkg>@<ver> dist.integrity）；R/K 离线档不解析
      integritySource: 'unresolved',
    },
    env: {
      node: process.version,
      platform: process.platform,
      arch: process.arch,
      // 必须区分三件事，旧实现把它们混成一个字段：
      //   hostDshVersion        = 实际探测到的宿主版本（本机安装，判决器读的就是它）
      //   smokeHostDshVersion   = D 组冒烟实际安装的宿主版本
      //   hostDetection         = 探测来源；null 表示探不到（报告须显式说明，不得回落硬编码）
      hostDshVersion: ctx.dshInstallVersion ?? null,
      hostDetection: ctx.dshInstall ? 'installed-package' : null,
      smokeHostDshVersion: opts.smoke ? (opts.dshVersion ?? ctx.dshInstallVersion ?? null) : null,
      smoke: opts.smoke,
      hostGroup: opts.hostGroup,
    },
    startedAt: new Date(started).toISOString(),
    durationMs,
    quarantine: null,
    coverage: ctx.coverage ?? {},
    groups,
    degraded,
    verdict: { worst: v.worst, ok: v.ok, criticalFail: v.criticalFail },
    // 采用轨道投影（dsh-levels/1）：只加字段，不改 stdout / 退出码 / verdict /
    // --format check。FLOW 恒 manual、BOOST 恒 not-measured —— 本工具不跑旅程、
    // 不做基准，绝不冒充。
    standards: deriveStandards(results, groups),
    results,
  }

  const qPath = quarantineSandbox({ root: runRoot })
  envelope.quarantine = qPath

  // --format check restates the same run in the ecosystem's three-value contract
  // (RFC #1846). It never changes whether a project passes; it only changes the
  // vocabulary, and it keeps the doctor semantics in a side field so nothing is
  // silently lost.
  const contract = opts.format === 'check'
    ? toContract({ results, degraded, repoPath, doctorVersion: VERSION })
    : null

  const code = contract
    ? contractExitCode(results, { degraded })
    : exitCodeFor(results, { degraded, allowDegraded: opts.allowDegraded })

  if (opts.json === '-') {
    process.stdout.write(JSON.stringify(contract ?? envelope, null, 2) + '\n')
  } else if (contract) {
    console.log(JSON.stringify(contract, null, 2))
    if (opts.json) {
      writeFileSync(opts.json, JSON.stringify(contract, null, 2) + '\n', 'utf8')
      console.log(`JSON 报告: ${opts.json}`)
    }
  } else {
    console.log(`# dsh-plugin-doctor 报告\n目标: ${repoPath}\n包名: ${pkg.name}`)
    console.log(render(results, { degraded }))
    console.log(`沙箱隔离目录: ${qPath ?? '(未创建)'}（人工确认后用 --purge 清理）`)
    if (opts.json) {
      writeFileSync(opts.json, JSON.stringify(envelope, null, 2) + '\n', 'utf8')
      console.log(`JSON 报告: ${opts.json}`)
    }
  }
  return code
}

// 退出码映射：fail/error 优先（按 category 细分 3/4/5），其次「整组未真跑」→ 6。
function exitCodeFor(results, { degraded, allowDegraded }) {
  const bad = results.filter((r) => r.status === 'fail' || r.status === 'error')
  if (bad.length) {
    const cats = [...new Set(bad.map((r) => r.category))]
    if (cats.length === 1) {
      if (cats[0] === 'unsupported-host') return 4
      if (cats[0] === 'infrastructure') return 3
      if (cats[0] === 'unstable') return 5
    }
    return 1
  }
  if (degraded.length && !allowDegraded) return 6
  return 0
}

const out = main()
Promise.resolve(out).then((code) => { process.exitCode = typeof code === 'number' ? code : 0 }).catch((err) => {
  console.error(err)
  process.exitCode = 3
})
