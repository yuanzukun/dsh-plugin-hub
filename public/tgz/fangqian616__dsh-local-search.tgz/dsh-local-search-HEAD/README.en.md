# @fangqian616/dsh-bing-search

[中文](README.md) · [English](README.en.md)

A DeepSeek Harness plugin that registers a **`bing_search`** model tool for zero-dependency local web search — **no API key, no firecrawl, no signup**. It hits Bing's HTML directly from the host and parses title/url/snippet results.

Use it when `web_search` fails with 403 (firecrawl keyless rejected) or no search API key is configured.

## Install

```bash
dsh plugin --profile web add @fangqian616/dsh-bing-search
# restart dsh
```

The tool then surfaces as `bing_search` (callable by the model).

## Usage (as a model tool)

```
bing_search(query: "your query terms", limit?: 10)
```

Returns `[{ title, url, snippet }]`.

## How it works

- Fetches `https://www.bing.com/search?q=...` through DSH's `web` service (`ctx.web.fetch`).
- Regex-parses `<li class="b_algo">` result blocks (title / url / snippet), decodes HTML entities, filters Bing/Microsoft self-links.
- No runtime npm dependencies beyond the DSH core services.

## Caveats

- Parsing is regex-based and can break if Bing changes markup or serves a consent/captcha page (the tool returns an `error` field in that case).
- DuckDuckGo is blocked in some regions; Bing is used because it is reachable without a key.

## License

MIT
