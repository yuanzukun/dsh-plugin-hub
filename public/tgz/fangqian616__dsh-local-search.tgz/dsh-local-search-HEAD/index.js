export const name = 'bing-search'
export const inject = ['tools']

function decodeEntities(s) {
  return String(s)
    .replace(/&#(\d+);/g, (m, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (m, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;|&#39;/g, "'")
    .replace(/&nbsp;|&ensp;|&emsp;/g, ' ')
    .replace(/&middot;/g, '·')
    .replace(/&hellip;/g, '…')
}

function stripTags(s) {
  return decodeEntities(String(s).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim())
}

function parseResults(html, max) {
  const out = []
  const blocks = html.split(/<li class="b_algo"/i).slice(1)
  for (const block of blocks) {
    const link = /<h2[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i.exec(block)
    if (!link) continue
    const url = decodeEntities(link[1])
    const title = stripTags(link[2])
    if (!url || !title) continue
    if (/bing\.com|microsoft\.com|msn\.com|go\.microsoft/i.test(url)) continue
    const p = /<p[^>]*>([\s\S]*?)<\/p>/i.exec(block)
    const snippet = p ? stripTags(p[1]) : ''
    out.push({ title, url, snippet })
    if (out.length >= max) break
  }
  return out
}

export function apply(ctx) {
  const web = ctx.get('web')

  ctx.tools.register({
    name: 'bing_search',
    description:
      'Zero-dependency local web search via Bing HTML. Use when web_search fails (firecrawl 403) or no search API key is configured. Returns title/url/snippet results.',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Search query terms' },
        limit: { type: 'number', description: 'Maximum results (default 10, max 20)' },
      },
      required: ['query'],
    },
    output: {
      schema: {
        type: 'object',
        properties: {
          query: { type: 'string' },
          error: { type: 'string' },
          results: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                url: { type: 'string' },
                snippet: { type: 'string' },
              },
              additionalProperties: false,
            },
          },
        },
        additionalProperties: false,
      },
      render(args, value) {
        if (!value || value.error) {
          return [{ type: 'text', text: 'bing_search error: ' + (value && value.error ? value.error : 'unknown') }]
        }
        const results = value.results || []
        if (results.length === 0) {
          return [{ type: 'text', text: 'No results.' }]
        }
        const text = results
          .map((r, i) => '[' + (i + 1) + '] ' + r.title + '\n    ' + r.url + (r.snippet ? '\n    ' + r.snippet : ''))
          .join('\n\n')
        return [{ type: 'text', text }]
      },
    },
    async execute(args) {
      const query = String(args.query || '').trim()
      if (!query) return { query, error: 'empty query', results: [] }
      if (web === undefined) return { query, error: 'web service unavailable', results: [] }
      const max = Math.max(1, Math.min(20, Number(args.limit) || 10))
      const url =
        'https://www.bing.com/search?q=' +
        encodeURIComponent(query) +
        '&setlang=zh-hans&count=' +
        Math.min(max + 5, 30)
      try {
        const result = await web.fetch({ url })
        if (result.statusCode >= 400) {
          return { query, error: 'Bing HTTP ' + result.statusCode, results: [] }
        }
        const html = result.body ? result.body.content : ''
        const results = parseResults(html, max)
        if (results.length === 0) {
          return { query, error: 'No results parsed (Bing consent/captcha page?)', results: [] }
        }
        return { query, results }
      } catch (e) {
        return { query, error: String((e && e.message) || e), results: [] }
      }
    },
  })
}
