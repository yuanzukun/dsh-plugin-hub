# @fangqian616/dsh-bing-search

[中文](README.md) · [English](README.en.md)

一个 DeepSeek Harness 插件，注册 **`bing_search`** 模型工具，用于零依赖的本地网页搜索 —— **无需 API key、无需 firecrawl、无需注册**。它直接从宿主机抓取 Bing 的 HTML，并解析出标题 / 链接 / 摘要。

当 `web_search` 报 403（firecrawl keyless 被拒）或未配置搜索 API key 时使用。

## 安装

```bash
dsh plugin --profile web add @fangqian616/dsh-bing-search
# 重启 dsh
```

工具随后以 `bing_search` 暴露（模型可调用）。

## 用法（作为模型工具）

```
bing_search(query: "你的查询词", limit?: 10)
```

返回 `[{ title, url, snippet }]`。

## 工作原理

- 通过 DSH 的 `web` 服务（`ctx.web.fetch`）抓取 `https://www.bing.com/search?q=...`；
- 用正则解析 `<li class="b_algo">` 结果块（标题 / 链接 / 摘要），解码 HTML 实体，过滤 Bing / Microsoft 自身链接；
- 除 DSH 核心服务外无运行时 npm 依赖。

## 注意事项

- 解析基于正则，若 Bing 改版或返回验证码 / 同意页（此时工具返回 `error` 字段）可能失效；
- 某些地区 DuckDuckGo 被墙，故选用无需 key 即可访问的 Bing。

## License

MIT
