/**
 * Host half for the static conversation-outline package. It serves compact
 * outline snapshots and generated turn titles through same-origin JSON routes,
 * so the browser bundle does not need dynamic package RPC.
 */

import { readFile, writeFile } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'

const PREVIEW_MAX = 120
const TITLE_CONTEXT_MAX = 8000
const TITLE_MAX = 48
// Transient llm errors (rate limits, provider hiccups) are cached for this
// long so a failed title auto-retries instead of sticking as "标题未生成" forever.
const ERROR_CACHE_TTL_MS = 60_000
const titleCache = new Map()
const titlePromises = new Map()
const outlineCache = new Map()

const OUTLINE_SETTINGS_NS = 'conversation-outline'

const settingsFilePath = () => {
  const home = process.env.DSH_HOME !== undefined && process.env.DSH_HOME.length > 0
    ? process.env.DSH_HOME
    : path.join(os.homedir(), '.dsh')
  return path.join(home, 'settings.yaml')
}

const yamlScalar = (value) => {
  if (value === true || value === false || typeof value === 'number') return String(value)
  const text = String(value)
  return /^[A-Za-z0-9_./:-]+$/.test(text) ? text : JSON.stringify(text)
}

const renderYamlSection = (section) => [
  `${OUTLINE_SETTINGS_NS}:`,
  ...Object.entries(section).map(([key, value]) => `  ${key}: ${yamlScalar(value)}`),
].join('\n')

const parseOutlineSettingsText = (text) => {
  const lines = String(text ?? '').split(/\r?\n/)
  const section = { model: '', reasoningEffort: '', maxConcurrency: 3, disabled: false }
  let inSection = false
  for (const line of lines) {
    if (/^conversation-outline:\s*$/.test(line)) {
      inSection = true
      continue
    }
    if (inSection && /^[^ \t]/.test(line)) inSection = false
    if (!inSection) continue
    const match = line.match(/^  ([a-zA-Z][a-zA-Z0-9]*):\s*(.*)\s*$/)
    if (match === null) continue
    const key = match[1]
    let value = match[2]
    if (value === 'true') value = true
    else if (value === 'false') value = false
    else if (/^-?\d+$/.test(value)) value = Number(value)
    else if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1)
    }
    section[key] = value
  }
  const max = Number(section.maxConcurrency)
  section.maxConcurrency = Number.isFinite(max) && max > 0 ? Math.min(8, Math.round(max)) : 3
  section.disabled = section.disabled === true
  return section
}

const readOutlineSettings = async () => {
  try {
    const text = await readFile(settingsFilePath(), 'utf8')
    return parseOutlineSettingsText(text)
  } catch {
    return { model: '', reasoningEffort: '', maxConcurrency: 3, disabled: false }
  }
}

const writeOutlineSettings = async (patch) => {
  const file = settingsFilePath()
  let text = ''
  try {
    text = await readFile(file, 'utf8')
  } catch {
    text = ''
  }
  const current = parseOutlineSettingsText(text)
  const next = { ...current, ...patch }
  const section = renderYamlSection(next)
  const pattern = /(^|\n)conversation-outline:\n(?:  [^\n]*\n?)*/
  const updated = pattern.test(text)
    ? text.replace(pattern, (match, lead) => `${lead}${section}\n`)
    : `${text.replace(/\s*$/, '')}\n${section}\n`
  await writeFile(file, updated, 'utf8')
  return next
}

const compact = (value, max = PREVIEW_MAX) => {
  const text = typeof value === 'string' ? value : ''
  const oneLine = text.replace(/\s+/g, ' ').trim()
  if (oneLine.length <= max) return oneLine
  return `${oneLine.slice(0, max - 1).trimEnd()}...`
}

const contentPreview = (blocks) => {
  if (!Array.isArray(blocks)) return ''
  for (const block of blocks) {
    if (block !== null && typeof block === 'object' && block.type === 'text'
      && typeof block.text === 'string' && block.text.trim().length > 0) {
      return compact(block.text)
    }
  }
  return ''
}

const textBlocks = (blocks) => {
  if (!Array.isArray(blocks)) return []
  const out = []
  for (const block of blocks) {
    if (block !== null && typeof block === 'object' && block.type === 'text'
      && typeof block.text === 'string' && block.text.trim().length > 0) {
      out.push(block.text.trim())
    }
  }
  return out
}

const titleKeyFor = (text) => {
  let hash = 2166136261
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index)
    hash = Math.imul(hash, 16777619) >>> 0
  }
  return `outline:${hash.toString(36)}`
}

const reasonPreview = (reason) => {
  if (reason === null || typeof reason !== 'object') return '完成'
  switch (reason.kind) {
    case 'completed': return '完成'
    case 'aborted': return '已中断'
    case 'error':
      if (reason.error !== null && typeof reason.error === 'object'
        && typeof reason.error.message === 'string') {
        return compact(reason.error.message)
      }
      return '错误'
    case 'max-tokens': return '达到最大输出'
    case 'blocked': return '被阻止'
    case 'interrupted': return '中断'
    default: return '完成'
  }
}

const sourceOf = (event, data) => {
  const message = data.message !== null && typeof data.message === 'object' ? data.message : {}
  const source = message.source !== null && typeof message.source === 'object' ? message.source : {}
  if (source.kind !== undefined) return source
  return data.source !== null && typeof data.source === 'object' ? data.source : {}
}

const toolCallIdOf = (data) => {
  if (typeof data.callId === 'string' && data.callId.length > 0) return data.callId
  const message = data.message !== null && typeof data.message === 'object' ? data.message : {}
  const source = message.source !== null && typeof message.source === 'object' ? message.source : {}
  if (typeof source.callId === 'string' && source.callId.length > 0) return source.callId
  return null
}

const userLabelOf = (source) => {
  if (source.kind === 'user') return '用户'
  if (source.kind === 'plugin' || source.kind === 'agent-instructions' || source.kind === 'skill-catalog') return '上下文'
  return '消息'
}

const ensureTurn = (timeline, turnIndex, turn) => {
  let entry = turnIndex.get(turn)
  if (entry === undefined) {
    entry = {
      kind: 'turn',
      id: `turn:${turn}`,
      turn,
      startSeq: null,
      endSeq: null,
      endReason: null,
      title: null,
      titleStatus: 'queued',
      items: [],
      hasContent: false,
    }
    turnIndex.set(turn, entry)
    timeline.push(entry)
  }
  return entry
}

const canMergeTools = (entry, last) => {
  if (entry.breakAt === null || entry.breakAt === undefined) return true
  const lastSeq = last.kind === 'tool-group'
    ? last.items[last.items.length - 1].seq
    : last.seq
  return lastSeq > entry.breakAt
}

const pushTurnItem = (entry, item) => {
  if (entry.turn !== null && item.turn === undefined) item.turn = entry.turn
  const isContextItem = item.kind === 'user' && (item.label === '上下文' || item.label === '消息')
  if (!isContextItem) entry.hasContent = true
  const last = entry.items.length > 0 ? entry.items[entry.items.length - 1] : null
  if (item.kind === 'tool') {
    if (last !== null && last.kind === 'tool-group' && canMergeTools(entry, last)) {
      last.items.push(item)
      last.count += 1
      last.endSeq = item.seq
      return
    }
    if (last !== null && last.kind === 'tool' && canMergeTools(entry, last)) {
      entry.items[entry.items.length - 1] = {
        kind: 'tool-group',
        id: `tool-group:${entry.id}:${last.seq}`,
        seq: last.seq,
        count: 2,
        items: [last, item],
        endSeq: item.seq,
      }
      return
    }
    entry.items.push(item)
    return
  }
  entry.items.push(item)
}

const makeItem = (kind, seq, time, label, preview, extra = {}) => ({
  id: `${kind}:${seq}`,
  kind,
  seq,
  time,
  label,
  preview,
  ...extra,
})

const timelineFromEvents = (events) => {
  const timeline = []
  const turnIndex = new Map()
  const pendingUserItems = []
  let currentTurn = null

  for (const event of events) {
    if (event === null || typeof event !== 'object' || typeof event.type !== 'string') continue
    const data = event.data !== null && typeof event.data === 'object' ? event.data : {}
    const seq = typeof event.seq === 'number' ? event.seq : 0
    const time = typeof event.time === 'number' ? event.time : 0

    switch (event.type) {
      case 'turn/start': {
        if (typeof data.turn === 'number') {
          currentTurn = ensureTurn(timeline, turnIndex, data.turn)
          if (currentTurn.startSeq === null) currentTurn.startSeq = seq
          while (pendingUserItems.length > 0) {
            pushTurnItem(currentTurn, pendingUserItems.shift())
          }
        }
        break
      }
      case 'turn/end': {
        const turn = typeof data.turn === 'number' ? data.turn : currentTurn
        if (turn !== null) {
          const entry = ensureTurn(timeline, turnIndex, turn)
          entry.endSeq = seq
        }
        currentTurn = null
        break
      }
      case 'user/message': {
        const source = sourceOf(event, data)
        const preview = contentPreview(data.content)
        if (preview.length > 0) {
          const item = makeItem('user', seq, time, userLabelOf(source), preview)
          if (source.kind === 'user') {
            if (currentTurn !== null) {
              currentTurn.breakAt = seq
              pushTurnItem(currentTurn, item)
            } else {
              pendingUserItems.push(item)
            }
          } else if (currentTurn === null) {
            timeline.push({ kind: 'item', item })
          } else {
            pushTurnItem(currentTurn, item)
          }
        }
        break
      }
      case 'assistant/message': {
        const message = data.message !== null && typeof data.message === 'object' ? data.message : {}
        const preview = contentPreview(message.content)
        if (preview.length > 0) {
          const item = makeItem('assistant', seq, time, '助手', preview, {
            turn: typeof data.turn === 'number' ? data.turn : null,
            step: typeof data.step === 'number' ? data.step : null,
          })
          if (currentTurn === null) timeline.push({ kind: 'item', item })
          else pushTurnItem(currentTurn, item)
        }
        break
      }
      case 'tool/call': {
        const name = typeof data.name === 'string' && data.name.length > 0 ? data.name : 'tool'
        const args = typeof data.arguments === 'string' && data.arguments.length > 0
          ? ` · ${compact(data.arguments)}`
          : ''
        const callId = toolCallIdOf(data)
        const item = makeItem('tool', seq, time, '工具', `${name}${args}`, {
          name,
          ...(callId === null ? {} : { callId }),
        })
        if (currentTurn === null) timeline.push({ kind: 'item', item })
        else pushTurnItem(currentTurn, item)
        break
      }
      case 'tool/result': {
        const error = data.error !== null && typeof data.error === 'object' ? data.error : null
        if (error !== null) {
          const preview = typeof error.name === 'string' && error.name.length > 0
            ? `${error.name}${typeof error.code === 'string' ? ' · ' + error.code : ''}`
            : '工具调用失败'
          const callId = toolCallIdOf(data)
          const item = makeItem('error', seq, time, '错误', preview, {
            ...(callId === null ? {} : { callId }),
          })
          if (currentTurn === null) timeline.push({ kind: 'item', item })
          else pushTurnItem(currentTurn, item)
        }
        break
      }
      case 'compaction/summary': {
        const preview = contentPreview(data.summary)
        if (preview.length > 0) {
          const item = makeItem('compaction', seq, time, '压缩检查点', preview)
          if (currentTurn === null) timeline.push({ kind: 'item', item })
          else pushTurnItem(currentTurn, item)
        }
        break
      }
      case 'command/run': {
        break
      }
      default:
        break
    }
  }

  for (const item of pendingUserItems) {
    timeline.push({ kind: 'item', item })
  }

  for (const entry of turnIndex.values()) {
    if (entry.startSeq === null && entry.items.length > 0) entry.startSeq = entry.items[0].seq
  }

  return { timeline }
}

const buildTurnContext = (events, turn, startSeq, endSeq, previousEndSeq) => {
  const lines = []
  const ceiling = endSeq === null || endSeq === undefined ? Number.POSITIVE_INFINITY : endSeq

  for (const event of events) {
    if (event === null || typeof event !== 'object' || typeof event.type !== 'string') continue
    const seq = typeof event.seq === 'number' ? event.seq : 0
    const data = event.data !== null && typeof event.data === 'object' ? event.data : {}

    if (event.type === 'user/message' && seq >= startSeq && seq <= ceiling) {
      const source = sourceOf(event, data)
      if (source.kind === 'user') {
        for (const text of textBlocks(data.content)) lines.push(`用户：${text}`)
      }
      continue
    }

    if (event.type === 'assistant/message' && seq >= startSeq && seq <= ceiling) {
      const message = data.message !== null && typeof data.message === 'object' ? data.message : {}
      for (const text of textBlocks(message.content)) lines.push(`助手：${text}`)
    }
  }

  const joined = lines.join('\n').trim()
  return joined.length > TITLE_CONTEXT_MAX ? `${joined.slice(0, TITLE_CONTEXT_MAX).trimEnd()}...` : joined
}

const parentSelection = (parent, agentDefaultModel) => {
  const options = parent !== undefined && parent.options !== null && typeof parent.options === 'object'
    ? parent.options
    : {}
  let fallback = {}
  if (agentDefaultModel !== undefined && typeof agentDefaultModel.currentSelection === 'function') {
    const selection = agentDefaultModel.currentSelection()
    if (selection !== null && typeof selection === 'object') fallback = selection
  }
  return {
    provider: options.provider ?? fallback.provider,
    model: options.model ?? fallback.model,
    maxTokens: options.maxTokens ?? fallback.maxTokens,
  }
}

const titlePrompt = (contextText) => [
  '请根据下面这一轮对话生成一个简短的中文标题。',
  '规则：只输出一句话，不超过 40 个中文字符；不要输出引号、解释或 Markdown。',
  '下面是从用户命令到模型输出提取的对话内容，已删除工具调用和思考过程：',
  '',
  contextText,
].join('\n')

const makeNoopSignal = () => {
  // The static Host runs in Node, so a REAL AbortSignal is always available.
  // The llm adapters validate the signal (AbortSignal.any([...])), and a plain
  // object shim fails that check as "signals[0] is not of type AbortSignal".
  if (typeof AbortController !== 'undefined') {
    return new AbortController().signal
  }
  return {
    aborted: false,
    reason: undefined,
    addEventListener() {},
    removeEventListener() {},
    dispatchEvent() {
      return false
    },
    throwIfAborted() {},
  }
}

const failureTextOf = (failure) => {
  if (failure === null || typeof failure !== 'object') return ''
  const code = typeof failure.code === 'string' && failure.code.length > 0 ? `code=${failure.code}` : ''
  const status = typeof failure.status === 'number' ? `HTTP ${failure.status}` : ''
  const message = typeof failure.message === 'string' && failure.message.length > 0 ? failure.message : ''
  return [code, status, message].filter(Boolean).join(' · ')
}

const sleep = (ms) => new Promise((resolve) => { setTimeout(resolve, ms) })

const performTitleRun = async (ctx, selection, contextText, signal, overrides = {}) => {
  const llm = ctx.get('llm')
  if (llm === undefined || typeof llm.stream !== 'function') {
    return { ok: false, error: '没有可用的 llm 服务' }
  }
  const parts = {}
  let finish = null
  // Only pass a REAL AbortSignal. The pi-ai adapter merges the caller signal
  // with the consumer's via AbortSignal.any([...]); a plain object shim (or a
  // mismatched value) throws "signals[0] is not of type AbortSignal". When we
  // have no real signal, omit it entirely so the adapter falls back to the
  // agent's own consumer.signal. The per-attempt timeout lives in
  // generateTitle, where it covers the WHOLE attempt (session read, model
  // resolution, credential lookup, and the llm.stream iteration itself), so
  // the handler always answers within timeoutMs.
  const signalIsReal = typeof AbortSignal !== 'undefined' && signal instanceof AbortSignal
  for await (const chunk of llm.stream({
    provider: selection.provider,
    model: overrides.model !== '' && overrides.model !== undefined ? overrides.model : selection.model,
    ...(overrides.reasoningEffort !== '' && overrides.reasoningEffort !== undefined
      ? { reasoningEffort: overrides.reasoningEffort }
      : {}),
    messages: [{
      id: 'outline-turn-title',
      role: 'user',
      content: [{ type: 'text', text: titlePrompt(contextText) }],
      source: { kind: 'user' },
    }],
    ...(selection.maxTokens === undefined ? {} : { maxTokens: selection.maxTokens }),
    purpose: 'session-title',
    ...(signalIsReal ? { signal } : {}),
  })) {
    if (chunk.type === 'text-delta') {
      parts[chunk.index] = (parts[chunk.index] ?? '') + chunk.text
    } else if (chunk.type === 'block-end' && chunk.block.type === 'text') {
      parts[chunk.index] = chunk.block.text
    } else if (chunk.type === 'finish') {
      finish = chunk.reason
    }
  }
  const ordered = Object.keys(parts).sort((left, right) => Number(left) - Number(right))
  const text = ordered.map((index) => parts[index]).join('\n').trim()
  const title = text.replace(/^["“'‘]+|["”'’]+$/g, '').trim()
  if (finish === null || finish.kind !== 'stop' || title.length === 0) {
    const failure = finish !== null
      && (finish.kind === 'error' || finish.kind === 'aborted')
      && finish.failure !== null && typeof finish.failure === 'object'
      ? failureTextOf(finish.failure)
      : ''
    const detail = failure.length > 0 ? ` · ${failure}` : ''
    return { ok: false, error: `标题生成失败：${finish === null ? 'unknown' : finish.kind}${detail}` }
  }
  return { ok: true, title: compact(title, TITLE_MAX) }
}

const generateTitle = async (ctx, sessionId, turn, events, startSeq, endSeq, previousEndSeq, overrides = {}) => {
  const contextText = buildTurnContext(events, turn, startSeq, endSeq, previousEndSeq)
  const key = titleKeyFor(contextText)
  const cached = titleCache.get(key)
  if (cached !== undefined && cached.status === 'ready') return { ok: true, title: cached.title, titleKey: key }
  if (cached !== undefined && cached.status === 'error') {
    // Only a TIME-BOUND error is retryable; a permanent error (no retryAt,
    // e.g. "this turn has no text") is returned as-is.
    if (cached.retryAt === undefined || Date.now() < cached.retryAt) {
      return { ok: false, error: cached.error }
    }
    titleCache.delete(key)
  }
  if (titlePromises.has(key)) return titlePromises.get(key)

  const promise = (async () => {
    if (contextText.length === 0) {
      const failed = { status: 'error', error: '这一轮没有可摘要的可见文本' }
      titleCache.set(key, failed)
      return { ok: false, error: failed.error }
    }
    const agents = ctx.agents
    const parent = agents?.get(sessionId) ?? agents?.currentInitiator()
    if (parent === undefined) {
      const failed = { status: 'error', error: '找不到主 Agent' }
      titleCache.set(key, failed)
      return { ok: false, error: failed.error }
    }
    const selection = parentSelection(parent, ctx.agentDefaultModel)
    if (typeof selection.provider !== 'string' || typeof selection.model !== 'string') {
      const failed = { status: 'error', error: '无法确定主 Agent 的模型参数' }
      titleCache.set(key, failed)
      return { ok: false, error: failed.error }
    }

    const maxRetries = Number.isFinite(Number(overrides.maxRetries)) && Number(overrides.maxRetries) >= 0
      ? Math.min(5, Math.round(Number(overrides.maxRetries)))
      : 2
    const timeoutSeconds = Number(overrides.timeoutSeconds)
    const timeoutMs = Number.isFinite(timeoutSeconds) && timeoutSeconds >= 5
      ? Math.round(timeoutSeconds * 1000)
      : 0
    // Title generation is FULLY PARALLEL with the session: it is a plain
    // llm.stream call with its own AbortController, exactly like DSH's own
    // built-in title service (dsh-session-title-llm calls ctx.llm.stream
    // directly with a deadline signal, no runMaintenance, no agent coupling).
    // `agent.runMaintenance()` is deliberately NOT used here: it THROWS
    // ("already has active work") while the agent is busy and never queues or
    // waits, so it could only add failure paths, not parallelism. The static
    // host runs in Node, so a real AbortController signal is always available.
    const runOnce = (signal) => performTitleRun(ctx, selection, contextText, signal, overrides)
    const runAttempt = async () => {
      const controller = typeof AbortController !== 'undefined' ? new AbortController() : null
      const signal = controller !== null ? controller.signal : makeNoopSignal()
      let timer = undefined
      let rejectTimeout = () => {}
      const timeoutGuard = new Promise((_, reject) => { rejectTimeout = reject })
      try {
        if (timeoutMs > 0 && controller !== null) {
          timer = setTimeout(() => {
            try { controller.abort(new Error(`title timeout after ${timeoutMs}ms`)) } catch { /* noop */ }
            rejectTimeout(new Error(`title timeout after ${timeoutMs}ms`))
          }, timeoutMs)
        }
        return await Promise.race([runOnce(signal), timeoutGuard])
      } catch (reason) {
        return { ok: false, error: reason instanceof Error ? reason.message : String(reason) }
      } finally {
        if (timer !== undefined) clearTimeout(timer)
      }
    }

    let outcome = null
    for (let attempt = 0; attempt <= maxRetries; attempt += 1) {
      outcome = await runAttempt()
      if (outcome.ok === true) break
      if (attempt < maxRetries) {
        const delay = Math.min(5000, 800 * (attempt + 1))
        console.warn(
          `[conversation-outline] title attempt ${attempt + 1}/${maxRetries + 1} failed session=${sessionId} turn=${turn} `
          + `provider=${selection.provider} model=${selection.model} error=${outcome.error} retry in ${delay}ms`,
        )
        await sleep(delay)
      }
    }

    if (outcome.ok === true) {
      titleCache.set(key, { status: 'ready', title: outcome.title })
      return { ok: true, title: outcome.title, titleKey: key }
    }
    console.error(
      `[conversation-outline] title failed after ${maxRetries + 1} attempts session=${sessionId} turn=${turn} `
      + `provider=${selection.provider} model=${selection.model}`
      + (typeof overrides.model === 'string' && overrides.model !== '' ? ` overrideModel=${overrides.model}` : '')
      + (typeof overrides.reasoningEffort === 'string' && overrides.reasoningEffort !== ''
        ? ` reasoningEffort=${overrides.reasoningEffort}`
        : '')
      + ` error=${outcome.error}`,
    )
    titleCache.set(key, { status: 'error', error: outcome.error, retryAt: Date.now() + ERROR_CACHE_TTL_MS })
    return outcome
  })()

  titlePromises.set(key, promise)
  try {
    return await promise
  } finally {
    titlePromises.delete(key)
  }
}

const turnMetadata = (events) => {
  const starts = new Map()
  const ends = new Map()
  const previousEnds = new Map()
  let previousEndSeq = null
  for (const event of events) {
    if (event === null || typeof event !== 'object' || typeof event.type !== 'string') continue
    const data = event.data !== null && typeof event.data === 'object' ? event.data : {}
    if (event.type === 'turn/start' && typeof data.turn === 'number') {
      starts.set(data.turn, event.seq)
      if (previousEndSeq !== null) previousEnds.set(data.turn, previousEndSeq)
    }
    if (event.type === 'turn/end' && typeof data.turn === 'number') {
      ends.set(data.turn, event.seq)
      previousEndSeq = event.seq
    }
  }
  return { starts, ends, previousEnds }
}

const turnsWithMetadata = (events, timeline) => {
  const { starts, ends, previousEnds } = turnMetadata(events)
  return timeline.map((entry) => {
    if (entry.kind !== 'turn') return entry
    return {
      ...entry,
      startSeq: starts.get(entry.turn) ?? entry.startSeq,
      endSeq: ends.get(entry.turn) ?? entry.endSeq,
      previousEndSeq: previousEnds.get(entry.turn) ?? null,
    }
  })
}

const applyCachedTitles = (timeline, sessionId) => timeline.map((entry) => {
  if (entry.kind !== 'turn') return entry
  const cacheKey = typeof entry.titleKey === 'string' && entry.titleKey.length > 0
    ? entry.titleKey
    : `${sessionId}:${entry.turn}`
  const cached = titleCache.get(cacheKey)
  if (cached !== undefined && cached.status === 'ready') {
    return { ...entry, title: cached.title, titleStatus: 'ready' }
  }
  if (cached !== undefined && cached.status === 'error') {
    return { ...entry, titleStatus: 'error' }
  }
  return entry
})

const sendJson = (res, status, data) => {
  const body = JSON.stringify(data)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
  })
  res.end(body)
}

const readJsonBody = async (req) => {
  const chunks = []
  for await (const chunk of req) chunks.push(chunk)
  const text = Buffer.concat(chunks).toString('utf8')
  try {
    return JSON.parse(text.length > 0 ? text : '{}')
  } catch {
    return {}
  }
}

const sessionIdFrom = (req) => {
  try {
    const url = new URL(req.url ?? '/', 'http://localhost')
    return url.searchParams.get('sessionId')
  } catch {
    return null
  }
}

export const inject = ['webServer', 'sessionQuery', 'agents', 'agentDefaultModel', 'llm']

export function apply(ctx) {
  const webServer = ctx.webServer
  const sessionQuery = ctx.sessionQuery
  const llmService = ctx.get('llm') !== undefined ? ctx.get('llm') : undefined

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: '/dsh-outline/config',
    handler: async (_req, res) => {
      const settings = await readOutlineSettings()
      if (llmService === undefined || typeof llmService.listProviders !== 'function') {
        sendJson(res, 200, { ok: true, settings, models: [], reasoning: [] })
        return
      }
      const models = []
      for (const provider of llmService.listProviders()) {
        if (provider === null || typeof provider !== 'object' || typeof provider.id !== 'string') continue
        try {
          const list = await llmService.listModels(provider.id)
          for (const model of list) {
            if (model === null || typeof model !== 'object' || typeof model.id !== 'string') continue
            models.push({
              provider: provider.id,
              id: model.id,
              name: typeof model.name === 'string' && model.name.length > 0 ? model.name : model.id,
            })
          }
        } catch {
          // A provider may reject model discovery; keep the rest of the list usable.
        }
      }
      sendJson(res, 200, {
        ok: true,
        settings,
        models,
        reasoning: [
          { id: 'off', name: 'Off' },
          { id: 'low', name: 'Low' },
          { id: 'medium', name: 'Medium' },
          { id: 'high', name: 'High' },
          { id: 'max', name: 'Max' },
        ],
      })
    },
  }))

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: '/dsh-outline/save-settings',
    handler: async (req, res) => {
      const body = await readJsonBody(req)
      const max = Number(body.maxConcurrency)
      const settings = await writeOutlineSettings({
        model: typeof body.model === 'string' ? body.model : '',
        reasoningEffort: typeof body.reasoningEffort === 'string' ? body.reasoningEffort : '',
        maxConcurrency: Number.isFinite(max) && max > 0 ? Math.min(8, Math.round(max)) : 3,
        disabled: body.disabled === true,
      })
      sendJson(res, 200, { ok: true, settings })
    },
  }))

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: '/dsh-outline/snapshot',
    handler: async (req, res) => {
      const sessionId = sessionIdFrom(req)
      if (sessionId === null || sessionId.length === 0) {
        sendJson(res, 400, { ok: false, error: 'sessionId is required' })
        return
      }
      try {
        let lastSeq = null
        let records = null
        try {
          records = await sessionQuery.listEvents(sessionId)
        } catch {
          records = null
        }
        if (Array.isArray(records)) {
          lastSeq = records.length > 0 && typeof records[records.length - 1].seq === 'number'
            ? records[records.length - 1].seq
            : -1
        }
        const cached = outlineCache.get(sessionId)
        if (cached !== undefined && cached.lastSeq === lastSeq) {
          sendJson(res, 200, { ok: true, outline: { timeline: applyCachedTitles(cached.timeline, sessionId) } })
          return
        }
        const snapshot = await sessionQuery.readSession(sessionId)
        const outline = timelineFromEvents(snapshot.events)
        const withMeta = turnsWithMetadata(snapshot.events, outline.timeline)
        const withTitleKeys = withMeta.map((entry) => {
          if (entry.kind !== 'turn') return entry
          const contextText = buildTurnContext(
            snapshot.events,
            entry.turn,
            entry.startSeq ?? 0,
            entry.endSeq ?? null,
            entry.previousEndSeq ?? null,
          )
          return { ...entry, titleKey: titleKeyFor(contextText) }
        })
        outlineCache.set(sessionId, { lastSeq, timeline: withTitleKeys })
        sendJson(res, 200, { ok: true, outline: { timeline: applyCachedTitles(withTitleKeys, sessionId) } })
      } catch (error) {
        sendJson(res, 500, { ok: false, error: error instanceof Error ? error.message : String(error) })
      }
    },
  }))

  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: '/dsh-outline/title',
    handler: async (req, res) => {
      const sessionId = sessionIdFrom(req)
      let turn = null
      let overrides = {}
      try {
        const url = new URL(req.url ?? '/', 'http://localhost')
        const raw = url.searchParams.get('turn')
        turn = raw === null ? null : Number(raw)
        const persisted = await readOutlineSettings()
        const rawTimeout = url.searchParams.get('timeoutSeconds')
        const rawRetries = url.searchParams.get('maxRetries')
        overrides = {
          model: url.searchParams.get('model') ?? persisted.model ?? '',
          reasoningEffort: url.searchParams.get('reasoningEffort') ?? persisted.reasoningEffort ?? '',
          // Never let the host run without a deadline: absent query values fall
          // back to the persisted/configured setting, then to 60s.
          timeoutSeconds: rawTimeout !== null && Number.isFinite(Number(rawTimeout)) && Number(rawTimeout) >= 5
            ? Math.min(300, Number(rawTimeout))
            : (Number.isFinite(Number(persisted.timeoutSeconds)) && Number(persisted.timeoutSeconds) >= 5
              ? Math.min(300, Number(persisted.timeoutSeconds))
              : 60),
          maxRetries: rawRetries !== null && Number.isFinite(Number(rawRetries)) && Number(rawRetries) >= 0
            ? Math.min(5, Math.round(Number(rawRetries)))
            : (Number.isFinite(Number(persisted.maxRetries)) && Number(persisted.maxRetries) >= 0
              ? Math.min(5, Math.round(Number(persisted.maxRetries)))
              : 2),
        }
      } catch {
        turn = null
      }
      if (sessionId === null || sessionId.length === 0 || turn === null || !Number.isInteger(turn)) {
        sendJson(res, 400, { ok: false, error: 'sessionId and turn are required' })
        return
      }
      try {
        const snapshot = await sessionQuery.readSession(sessionId)
        const { starts, ends, previousEnds } = turnMetadata(snapshot.events)
        const result = await generateTitle(
          ctx,
          sessionId,
          turn,
          snapshot.events,
          starts.get(turn) ?? 0,
          ends.get(turn) ?? null,
          previousEnds.get(turn) ?? null,
          overrides,
        )
        sendJson(res, 200, result)
      } catch (error) {
        sendJson(res, 500, { ok: false, error: error instanceof Error ? error.message : String(error) })
      }
    },
  }))
}
