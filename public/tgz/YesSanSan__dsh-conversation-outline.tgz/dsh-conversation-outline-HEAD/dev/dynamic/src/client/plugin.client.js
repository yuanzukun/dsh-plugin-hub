/**
 * Client half: a session-header toggle plus a native details-column panel that
 * shows a compact conversation timeline. The panel fetches the outline through
 * this Package's Host half, collapses tool runs and turns, and jumps through
 * the existing chat anchors.
 */
return {
  inject: ['slots', 'sessions'],
  apply(ctx) {
    const css = `
.outline-details-root {
  box-sizing: border-box;
  height: 100%;
  min-width: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: var(--dsw-specific-sidebar-fill, var(--dsw-alias-bg-base, #242424));
  color: var(--dsw-alias-label-primary, #e8e8e8);
}
.outline-overlay-header {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  gap: 8px;
  flex: none;
  padding: 14px 12px 12px;
  border-bottom: 1px solid var(--dsw-alias-border-l2, #555);
}
.outline-overlay-title {
  min-width: 0;
  flex: 1;
  margin: 0;
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.outline-overlay-icon-btn {
  box-sizing: border-box;
  width: 28px;
  height: 28px;
  flex: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: none;
  border-radius: 50%;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #b8b8b8);
  cursor: pointer;
  padding: 0;
}
.outline-overlay-icon-btn:hover {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
  color: var(--dsw-alias-label-primary, #e8e8e8);
}
.outline-overlay-icon-btn:disabled {
  opacity: 0.45;
  cursor: default;
}
.outline-refresh-spin {
  display: inline-flex;
  animation: outline-spin 1s linear infinite;
}
@keyframes outline-spin {
  to { transform: rotate(360deg); }
}
.outline-overlay-body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  padding: 6px 12px 12px;
  --dsh-scrollbar-thumb: var(--dsw-alias-scrollbar-bg-l2, #555);
  --dsh-scrollbar-thumb-hover: var(--dsw-alias-scrollbar-hover-l2, #777);
}
.outline-overlay-status {
  margin: 12px;
  color: var(--dsw-alias-label-tertiary, #999);
  font-size: 13px;
  line-height: 20px;
}
.outline-overlay-error {
  margin: 12px 12px 10px;
  color: var(--dsw-alias-state-error-primary, #e5484d);
  font-size: 13px;
  line-height: 20px;
}
.outline-overlay-tools {
  display: flex;
  gap: 8px;
  align-items: center;
  margin: 0 12px;
}
.outline-overlay-secondary {
  box-sizing: border-box;
  height: 30px;
  padding: 0 10px;
  border: 1px solid var(--dsw-alias-border-l2, #555);
  border-radius: 8px;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #b8b8b8);
  font: inherit;
  font-size: 12px;
  line-height: 18px;
  cursor: pointer;
}
.outline-overlay-secondary:hover:not(:disabled) {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
  color: var(--dsw-alias-label-primary, #e8e8e8);
}
.outline-standalone-item {
  padding: 6px 12px 0;
}
.outline-turn-card {
  position: relative;
  margin-top: 10px;
  border: 1px solid var(--dsw-alias-border-l2, #555);
  border-radius: 8px;
  background: var(--dsw-alias-bg-layer-2, #242424);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
}
.outline-turn-card .outline-turn-head {
  box-sizing: border-box;
  position: sticky;
  top: 0;
  z-index: 3;
  width: 100%;
  min-height: 40px;
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0;
  padding: 8px 12px;
  border: none;
  border-bottom: 1px solid var(--dsw-alias-border-l2, #555);
  border-radius: 8px 8px 0 0;
  background: var(--dsw-alias-bg-layer-2, #242424);
  color: var(--dsw-alias-label-primary, #e8e8e8);
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.outline-turn-card .outline-turn-head:hover {
  background: var(--dsw-alias-bg-layer-3, #303030);
}
.outline-turn-card.outline-turn-collapsed .outline-turn-head {
  border-bottom: none;
  border-radius: 8px;
}
.outline-turn-chevron {
  flex: none;
  color: var(--dsw-alias-label-tertiary, #999);
  transition: transform 120ms ease;
}
.outline-turn-chevron-open {
  transform: rotate(90deg);
}
.outline-turn-title {
  min-width: 0;
  flex: 1;
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.outline-turn-meta {
  flex: none;
  color: var(--dsw-alias-label-tertiary, #999);
  font-size: 11px;
  line-height: 16px;
  white-space: nowrap;
}
.outline-turn-items {
  padding: 4px 8px 8px;
  border-radius: 0 0 8px 8px;
}
.outline-row {
  box-sizing: border-box;
  width: 100%;
  min-height: 34px;
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 6px 8px;
  border: 1px solid transparent;
  border-radius: 8px;
  background: transparent;
  color: var(--dsw-alias-label-primary, #e8e8e8);
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.outline-row:hover:not(:disabled) {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
}
.outline-row:focus-visible {
  outline: 2px solid var(--dsw-alias-brand-primary, #4f8cff);
  outline-offset: -2px;
}
.outline-row:disabled {
  opacity: 0.55;
  cursor: default;
}
.outline-row-active {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
  border-color: var(--dsw-alias-brand-primary, #4f8cff);
}
.outline-row-kind {
  box-sizing: border-box;
  flex: none;
  width: 42px;
  padding: 2px 4px;
  border-radius: 4px;
  background: var(--dsw-alias-bg-module-platform, #333);
  color: var(--dsw-alias-label-secondary, #b8b8b8);
  font-size: 10px;
  font-weight: 600;
  line-height: 14px;
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.outline-row-kind-user {
  color: var(--dsw-alias-state-business-primary, #4f8cff);
  background: var(--dsw-alias-state-business-tertiary, #1e3a5f);
}
.outline-row-kind-context {
  color: color-mix(in srgb, var(--dsw-alias-state-success-primary, #30a46c) 68%, var(--dsw-alias-label-secondary, #b8b8b8));
  background: var(--dsw-alias-state-success-tertiary, #173f31);
}
.outline-row-kind-assistant {
  color: color-mix(in srgb, var(--dsw-alias-brand-primary, #6e56cf) 60%, var(--dsw-alias-state-error-secondary, #ff8b8b));
  background: color-mix(in srgb, color-mix(in srgb, var(--dsw-alias-brand-primary, #6e56cf) 55%, var(--dsw-alias-state-error-secondary, #ff8b8b)) 15%, var(--dsw-alias-bg-layer-1, #1f1f1f));
}
.outline-row-kind-tool {
  color: var(--dsw-alias-state-warn-label, #e5a50a);
  background: var(--dsw-alias-state-warn-tertiary, #3d2f12);
}
.outline-row-kind-error {
  color: var(--dsw-alias-state-error-primary, #e5484d);
  background: var(--dsw-alias-state-error-tertiary, #3f1d22);
}
.outline-row-kind-compaction {
  color: var(--dsw-alias-label-secondary, #b8b8b8);
  background: var(--dsw-alias-bg-module-platform, #333);
}
.outline-row-preview {
  flex: 1;
  min-width: 0;
  font-size: 12px;
  line-height: 20px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-break: break-word;
}
.outline-tool-group {
  margin: 2px 0;
}
.outline-tool-group-head {
  box-sizing: border-box;
  width: 100%;
  min-height: 34px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 8px;
  border: 1px solid transparent;
  border-radius: 8px;
  background: transparent;
  color: var(--dsw-alias-label-primary, #e8e8e8);
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.outline-tool-group-head:hover {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
}
.outline-tool-group-chevron {
  flex: none;
  color: var(--dsw-alias-label-tertiary, #999);
  transition: transform 120ms ease;
}
.outline-tool-group-chevron-open {
  transform: rotate(90deg);
}
.outline-tool-group-count {
  color: var(--dsw-alias-state-business-primary, #4f8cff);
  font-size: 11px;
  font-weight: 600;
  line-height: 16px;
}
.outline-tool-group-items {
  margin-left: 18px;
  padding-left: 4px;
  border-left: 1px solid var(--dsw-alias-border-l2, #555);
}
.outline-tabs {
  display: flex;
  gap: 4px;
  flex: none;
  padding: 0 12px 10px;
  border-bottom: 1px solid var(--dsw-alias-border-l2, #555);
}
.outline-tab {
  box-sizing: border-box;
  height: 28px;
  padding: 0 10px;
  border: none;
  border-radius: 8px;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #b8b8b8);
  font: inherit;
  font-size: 12px;
  line-height: 18px;
  cursor: pointer;
}
.outline-tab:hover {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
  color: var(--dsw-alias-label-primary, #e8e8e8);
}
.outline-tab-active {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
  color: var(--dsw-alias-brand-primary, #4f8cff);
}
.outline-toggle {
  box-sizing: border-box;
  height: 28px;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 0 8px;
  border: none;
  border-radius: 8px;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #b8b8b8);
  font: inherit;
  font-size: 12px;
  line-height: 18px;
  cursor: pointer;
}
.outline-toggle:hover {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
  color: var(--dsw-alias-label-primary, #e8e8e8);
}
.outline-toggle[aria-pressed="true"] {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
  color: var(--dsw-alias-brand-primary, #4f8cff);
}
`

    const TITLE_CACHE_KEY = 'dsh-conversation-outline-titles:v1'
    const listeners = new Set()
    let panelState = { open: false, revision: 0 }
    let outlineRequestId = 0
    let sessionsService = null
    let layoutService = null

    const readTitleLocalCache = () => {
      try {
        if (typeof localStorage === 'undefined') return {}
        const raw = localStorage.getItem(TITLE_CACHE_KEY)
        if (raw === null) return {}
        const parsed = JSON.parse(raw)
        return parsed !== null && typeof parsed === 'object' ? parsed : {}
      } catch {
        return {}
      }
    }

    const titleLocalCache = readTitleLocalCache()

    const persistTitleLocalCache = () => {
      try {
        if (typeof localStorage !== 'undefined') {
          localStorage.setItem(TITLE_CACHE_KEY, JSON.stringify(titleLocalCache))
        }
      } catch {
        // localStorage can be unavailable in restricted browser contexts.
      }
    }

    const titleCacheKeyFor = (entry, sessionIdRef) => (
      typeof entry.titleKey === 'string' && entry.titleKey.length > 0
        ? entry.titleKey
        : `${sessionIdRef}:${entry.turn}`
    )

    const applyLocalTitles = (timeline, sessionIdRef) => timeline.map((entry) => {
      if (entry.kind !== 'turn') return entry
      const cached = titleLocalCache[titleCacheKeyFor(entry, sessionIdRef)]
      if (cached !== undefined && typeof cached.title === 'string' && cached.title.length > 0) {
        return { ...entry, title: cached.title, titleStatus: 'ready' }
      }
      return entry
    })

    const subscribePanel = (listener) => {
      listeners.add(listener)
      return () => { listeners.delete(listener) }
    }

    const getPanelSnapshot = () => panelState

    const notifyPanel = () => {
      panelState = { ...panelState, revision: panelState.revision + 1 }
      for (const listener of Array.from(listeners)) listener()
    }

    const togglePanel = () => {
      const nextOpen = !panelState.open
      if (layoutService !== null) {
        if (nextOpen) layoutService.openDetails()
        else layoutService.closeDetails()
      }
      panelState = { ...panelState, open: nextOpen, revision: panelState.revision + 1 }
      notifyPanel()
    }

    const closePanel = () => {
      if (panelState.open) {
        if (layoutService !== null) layoutService.closeDetails()
        panelState = { ...panelState, open: false, revision: panelState.revision + 1 }
        notifyPanel()
      }
    }

    const usePanelState = () => {
      const [snapshot, setSnapshot] = React.useState(getPanelSnapshot)
      React.useEffect(() => subscribePanel(() => setSnapshot(getPanelSnapshot())), [])
      return snapshot
    }

    const emptyOutline = () => ({ timeline: [] })

    const findNodeForSeq = (snapshot, seq) => {
      const store = snapshot.chat !== null && typeof snapshot.chat === 'object'
        ? snapshot.chat.nodes
        : undefined
      if (store === undefined || typeof store.values !== 'function') return null
      const nodes = store.values()
      let exact = null
      let next = null
      let prev = null
      for (const node of nodes) {
        if (node === null || typeof node !== 'object' || node.visibility === 'hidden') continue
        const anchor = node.anchorSeq
        if (typeof anchor !== 'number') continue
        if (Math.abs(anchor - seq) < 0.5) {
          if (exact === null) exact = node
          continue
        }
        if (anchor >= seq && (next === null || anchor < next.anchorSeq)) next = node
        if (anchor <= seq && (prev === null || anchor > prev.anchorSeq)) prev = node
      }
      return exact !== null ? exact : next !== null ? next : prev
    }

    const hasSeqInWindow = (snapshot, seq) => {
      const store = snapshot.chat !== null && typeof snapshot.chat === 'object'
        ? snapshot.chat.nodes
        : undefined
      if (store === undefined || typeof store.values !== 'function') return false
      let min = Number.POSITIVE_INFINITY
      let max = Number.NEGATIVE_INFINITY
      for (const node of store.values()) {
        if (node === null || typeof node !== 'object' || typeof node.anchorSeq !== 'number') continue
        if (node.anchorSeq < min) min = node.anchorSeq
        if (node.anchorSeq > max) max = node.anchorSeq
      }
      return min <= seq && seq <= max
    }

    const findAnchorRow = (key) => {
      const rows = document.querySelectorAll('[data-chat-anchor-key]')
      for (const row of rows) {
        if (row.dataset.chatAnchorKey === key) return row
      }
      return null
    }

    const isTrajectoryViewActive = () => (
      document.querySelector('[data-trajectory-scroll]') !== null
    )

    const trajectoryRecordIdFor = (item, snapshot) => {
      const views = snapshot !== null && typeof snapshot === 'object' && snapshot.views !== null
        && typeof snapshot.views === 'object'
        ? snapshot.views
        : undefined
      const trajectory = views !== undefined && typeof views.get === 'function'
        ? views.get('trajectory')
        : undefined
      if (trajectory === undefined || trajectory === null || typeof trajectory !== 'object') return null
      const nodes = Array.isArray(trajectory.eventNodes) ? trajectory.eventNodes : []
      const requests = Array.isArray(trajectory.requests) ? trajectory.requests : []
      const nodeWithKind = (kinds, seq) => {
        const matches = nodes.filter((node) => node !== null && typeof node === 'object'
          && kinds.includes(node.kind) && typeof node.seq === 'number')
        return matches.find((node) => node.seq === seq)
          ?? matches.filter((node) => node.seq >= seq).sort((left, right) => left.seq - right.seq)[0]
      }

      if (item.kind === 'user') {
        const target = nodeWithKind(['user', 'steering', 'context'], item.seq)
        if (target === undefined || typeof target.seq !== 'number') return null
        const rowKind = target.kind === 'steering' ? 'user' : target.kind
        return `${rowKind}\u0000seq\u0000${target.seq}`
      }
      if (item.kind === 'assistant') {
        const target = nodeWithKind(['assistant'], item.seq)
        if (target === undefined || typeof target.turn !== 'number' || typeof target.step !== 'number') return null
        return `assistant\u0000${target.turn}\u0000${target.step}`
      }
      if (item.kind === 'tool' || item.kind === 'error') {
        if (typeof item.callId === 'string' && item.callId.length > 0) return `tool\u0000call\u0000${item.callId}`
        const target = nodeWithKind(['tool-result'], item.seq)
        if (target === undefined || typeof target.callId !== 'string') return null
        return `tool\u0000call\u0000${target.callId}`
      }
      if (item.kind === 'compaction') {
        const compactions = requests.filter((request) => request !== null && typeof request === 'object'
          && request.purpose === 'compaction' && typeof request.startSeq === 'number')
        const target = compactions.find((request) => request.resultSeq === item.seq)
          ?? compactions.filter((request) => (request.resultSeq ?? -1) >= item.seq)
            .sort((left, right) => left.resultSeq - right.resultSeq)[0]
        if (target === undefined) return null
        return `compacted\u0000seq\u0000${target.startSeq}`
      }
      return null
    }

    const trajectoryOrderIndexFor = (item, snapshot) => {
      const recordId = trajectoryRecordIdFor(item, snapshot)
      if (recordId === null) return null
      const views = snapshot !== null && typeof snapshot === 'object' && snapshot.views !== null
        && typeof snapshot.views === 'object'
        ? snapshot.views
        : undefined
      const trajectory = views !== undefined && typeof views.get === 'function'
        ? views.get('trajectory')
        : undefined
      if (trajectory === undefined || trajectory === null || typeof trajectory !== 'object') return null
      const nodes = Array.isArray(trajectory.eventNodes) ? trajectory.eventNodes : []
      const requests = Array.isArray(trajectory.requests) ? trajectory.requests : []
      const entries = []
      for (const node of nodes) {
        if (node === null || typeof node !== 'object' || typeof node.seq !== 'number') continue
        if (node.kind === 'user' || node.kind === 'steering' || node.kind === 'context') {
          const rowKind = node.kind === 'steering' ? 'user' : node.kind
          entries.push({ seq: node.seq, id: `${rowKind}\u0000seq\u0000${node.seq}` })
        } else if (node.kind === 'assistant' && typeof node.turn === 'number' && typeof node.step === 'number') {
          entries.push({ seq: node.seq, id: `assistant\u0000${node.turn}\u0000${node.step}` })
        } else if (node.kind === 'tool-result' && typeof node.callId === 'string') {
          entries.push({ seq: node.seq, id: `tool\u0000call\u0000${node.callId}` })
        }
      }
      for (const request of requests) {
        if (request === null || typeof request !== 'object' || request.purpose !== 'compaction') continue
        if (typeof request.startSeq !== 'number') continue
        entries.push({ seq: request.startSeq, id: `compacted\u0000seq\u0000${request.startSeq}` })
      }
      entries.sort((left, right) => left.seq - right.seq)
      const index = entries.findIndex((entry) => entry.id === recordId)
      return index === -1 || entries.length === 0 ? null : { index, count: entries.length }
    }

    const findTrajectoryRowByKey = (key) => {
      const rows = document.querySelectorAll('tr[data-trajectory-row-key]')
      for (const row of rows) {
        if (row.dataset.trajectoryRowKey === key) return row
      }
      return null
    }

    const findTrajectoryRowFor = (item, key) => {
      const exact = findTrajectoryRowByKey(key)
      if (exact !== null) return exact
      const rows = document.querySelectorAll('tr[data-trajectory-row-key]')
      for (const row of rows) {
        let id = ''
        try {
          id = decodeURIComponent(row.dataset.trajectoryRowKey || '')
        } catch {
          continue
        }
        if (item.kind === 'user' && id.includes(`\u0000seq\u0000${item.seq}`)) return row
        if (item.kind === 'assistant'
          && (id.includes(`\u0000seq\u0000${item.seq}`)
            || (typeof item.turn === 'number' && typeof item.step === 'number'
              && id === `assistant\u0000${item.turn}\u0000${item.step}`))) return row
        if ((item.kind === 'tool' || item.kind === 'error')
          && typeof item.callId === 'string' && id.includes(`\u0000call\u0000${item.callId}`)) return row
      }
      return null
    }

    const expandTrajectorySummaries = () => {
      const rows = document.querySelectorAll('tr[data-collapsed-summary]')
      for (const row of rows) {
        if (typeof row.click === 'function') row.click()
      }
    }

    const waitForNextFrame = () => new Promise((resolve) => {
      if (typeof requestAnimationFrame === 'function') requestAnimationFrame(() => resolve())
      else resolve()
    })

    const iconPath = (d) => React.createElement('svg', {
      viewBox: '0 0 16 16',
      width: '14',
      height: '14',
      'aria-hidden': true,
    }, React.createElement('path', {
      d,
      fill: 'none',
      stroke: 'currentColor',
      strokeWidth: '1.5',
      strokeLinecap: 'round',
      strokeLinejoin: 'round',
    }))

    const chevronPath = 'M6 4l4 4-4 4'

    function OutlineToggle() {
      const snapshot = usePanelState()
      return React.createElement('button', {
        type: 'button',
        className: 'outline-toggle',
        'aria-label': '对话大纲',
        'aria-pressed': snapshot.open,
        title: '对话大纲',
        onClick: togglePanel,
      }, iconPath('M3 3.5h10M3 8h10M3 12.5h6'), React.createElement('span', null, '大纲'))
    }

    function OutlineRow({ item, active, jumping, onClick }) {
      const kindClass = item.kind === 'user'
        ? item.label === '上下文' || item.label === '消息' ? ' outline-row-kind-context' : ' outline-row-kind-user'
        : item.kind === 'assistant' ? ' outline-row-kind-assistant'
          : item.kind === 'tool' ? ' outline-row-kind-tool'
            : item.kind === 'error' ? ' outline-row-kind-error'
              : item.kind === 'compaction' ? ' outline-row-kind-compaction' : ''
      return React.createElement('button', {
        type: 'button',
        className: `outline-row${active ? ' outline-row-active' : ''}`,
        disabled: jumping === item.seq || item.kind === 'notice',
        onClick: () => { onClick(item) },
      },
      React.createElement('span', { className: `outline-row-kind${kindClass}` }, item.label),
      React.createElement('span', { className: 'outline-row-preview' }, item.preview))
    }

    function ToolGroup({ group, expanded, activeSeq, jumping, onToggle, onJump }) {
      return React.createElement('div', { className: 'outline-tool-group' },
        React.createElement('button', {
          type: 'button',
          className: 'outline-tool-group-head',
          'aria-expanded': expanded,
          onClick: onToggle,
        },
        React.createElement('span', { className: `outline-tool-group-chevron${expanded ? ' outline-tool-group-chevron-open' : ''}` },
          iconPath(chevronPath)),
        React.createElement('span', { className: 'outline-row-kind outline-row-kind-tool' }, '工具'),
        React.createElement('span', { className: 'outline-row-preview' }, `${group.count} 次调用`)),
        expanded
          ? React.createElement('div', { className: 'outline-tool-group-items' },
              group.items.map((item, index) => React.createElement(OutlineRow, {
                key: `${item.id}:${index}`,
                item,
                active: activeSeq === item.seq,
                jumping,
                onClick: (target) => { onJump(target) },
              })))
          : null)
    }

    function OutlinePanel({ useSessions }) {
      const panel = usePanelState()
      const sessionId = useSessions((state) => state.current)
      const [status, setStatus] = React.useState('idle')
      const [outline, setOutline] = React.useState(emptyOutline)
      const outlineRef = React.useRef(emptyOutline())
      const [refreshing, setRefreshing] = React.useState(false)
      const [error, setError] = React.useState(null)
      const [jumping, setJumping] = React.useState(null)
      const [jumpError, setJumpError] = React.useState(null)
      const [activeSeq, setActiveSeq] = React.useState(null)
      const [collapsedTurns, setCollapsedTurns] = React.useState(null)
      const [expandedToolGroups, setExpandedToolGroups] = React.useState(new Set())
      const requestedTurns = React.useRef(new Set())

      React.useEffect(() => { outlineRef.current = outline }, [outline])

      React.useEffect(() => {
        setOutline(emptyOutline())
        outlineRef.current = emptyOutline()
        setStatus('idle')
        setError(null)
        setRefreshing(false)
      }, [sessionId])

      const updateTurnTitle = (turn, patch) => {
        setOutline((current) => ({
          ...current,
          timeline: current.timeline.map((entry) => {
            if (entry.kind !== 'turn' || entry.turn !== turn) return entry
            return { ...entry, ...patch }
          }),
        }))
      }

      const queueTitleGeneration = React.useCallback((timeline, sessionIdRef) => {
        const turns = timeline.filter((entry) => entry.kind === 'turn' && entry.titleStatus === 'queued')
        if (turns.length === 0) return
        let index = 0
        const worker = async () => {
          while (index < turns.length) {
            const entry = turns[index]
            index += 1
            const requestKey = `${sessionIdRef}:${entry.turn}`
            const localKey = titleCacheKeyFor(entry, sessionIdRef)
            if (requestedTurns.current.has(requestKey)) continue
            const local = titleLocalCache[localKey]
            if (local !== undefined && typeof local.title === 'string' && local.title.length > 0) {
              updateTurnTitle(entry.turn, { title: local.title, titleStatus: 'ready' })
              continue
            }
            requestedTurns.current.add(requestKey)
            try {
              const result = await host.call('outline/title', { sessionId: sessionIdRef, turn: entry.turn })
              if (result !== null && typeof result === 'object' && result.ok === true) {
                const cacheKey = typeof result.titleKey === 'string' && result.titleKey.length > 0
                  ? result.titleKey
                  : localKey
                titleLocalCache[cacheKey] = { title: result.title, savedAt: Date.now() }
                persistTitleLocalCache()
                updateTurnTitle(entry.turn, { title: result.title, titleStatus: 'ready', titleKey: cacheKey })
              } else {
                const message = result !== null && typeof result === 'object' && typeof result.error === 'string'
                  ? result.error
                  : '标题生成失败'
                requestedTurns.current.delete(requestKey)
                updateTurnTitle(entry.turn, { titleStatus: 'error', titleError: message })
              }
            } catch (reason) {
              requestedTurns.current.delete(requestKey)
              updateTurnTitle(entry.turn, { titleStatus: 'error', titleError: reason instanceof Error ? reason.message : String(reason) })
            }
          }
        }
        const workers = Array.from({ length: Math.min(3, turns.length) }, () => worker())
        void Promise.all(workers)
      }, [])

      const loadOutline = React.useCallback(() => {
        if (typeof sessionId !== 'string' || sessionId.length === 0) {
          setStatus('idle')
          setOutline(emptyOutline())
          return
        }
        const requestId = ++outlineRequestId
        const hasExisting = outlineRef.current.timeline.length > 0
        setError(null)
        if (hasExisting) {
          setStatus('ready')
          setRefreshing(true)
        } else {
          setStatus('loading')
          setRefreshing(false)
        }
        host.call('outline/snapshot', { sessionId })
          .then((result) => {
            if (requestId !== outlineRequestId) return
            setRefreshing(false)
            if (result === null || typeof result !== 'object' || result.ok !== true) {
              const message = result !== null && typeof result === 'object' && typeof result.error === 'string'
                ? result.error
                : '无法读取会话大纲'
              setError(message)
              if (!hasExisting) setStatus('error')
              return
            }
            const next = result.outline
            const nextTimeline = next !== null && typeof next === 'object' && Array.isArray(next.timeline)
              ? applyLocalTitles(next.timeline, sessionId)
              : []
            outlineRef.current = { timeline: nextTimeline }
            setOutline({ timeline: nextTimeline })
            setStatus('ready')
            queueTitleGeneration(nextTimeline, sessionId)
          })
          .catch((reason) => {
            if (requestId !== outlineRequestId) return
            setRefreshing(false)
            setError(reason instanceof Error ? reason.message : String(reason))
            if (!hasExisting) setStatus('error')
          })
      }, [sessionId, queueTitleGeneration])

      React.useEffect(() => {
        if (!panel.open) return undefined
        if (typeof sessionId !== 'string' || sessionId.length === 0) {
          setStatus('idle')
          return undefined
        }
        loadOutline()
        const service = sessionsService
        const binding = service !== null && typeof service.binding === 'function'
          ? service.binding(sessionId)
          : undefined
        const session = binding !== undefined && binding.session !== undefined ? binding.session : undefined
        if (session === undefined || typeof session.subscribe !== 'function' || typeof session.getSnapshot !== 'function') {
          return undefined
        }
        return session.subscribe(() => {
          let snapshot
          try {
            snapshot = session.getSnapshot()
          } catch {
            return
          }
          if (snapshot !== null && typeof snapshot === 'object' && snapshot.running === false) {
            loadOutline()
          }
        })
      }, [panel.open, sessionId, loadOutline])

      const jumpTo = React.useCallback(async (item) => {
        if (item === null || typeof item !== 'object' || typeof item.seq !== 'number') return
        setJumping(item.seq)
        setJumpError(null)
        try {
          const service = sessionsService
          const binding = service !== null && typeof service.binding === 'function'
            ? service.binding(sessionId)
            : undefined
          const session = binding !== undefined && binding.session !== undefined ? binding.session : undefined
          if (session === undefined || typeof session.loadOlder !== 'function' || typeof session.getSnapshot !== 'function') {
            setJumpError('当前会话不可用')
            return
          }
          let snapshot = session.getSnapshot()
          if (isTrajectoryViewActive()) {
            let recordId = trajectoryRecordIdFor(item, snapshot)
            let key = recordId === null ? null : encodeURIComponent(recordId)
            let row = key === null ? null : findTrajectoryRowFor(item, key)
            if (row === null && snapshot.hasMore === true) {
              let guard = 0
              while (snapshot.hasMore === true && guard < 200) {
                await session.loadOlder()
                snapshot = session.getSnapshot()
                guard += 1
              }
              recordId = trajectoryRecordIdFor(item, snapshot)
              key = recordId === null ? null : encodeURIComponent(recordId)
              row = key === null ? null : findTrajectoryRowFor(item, key)
            }
            if (key === null) {
              setJumpError('轨迹中找不到该事件')
              return
            }
            if (row === null) {
              expandTrajectorySummaries()
              await waitForNextFrame()
              row = findTrajectoryRowFor(item, key)
            }
            if (row === null) {
              const order = trajectoryOrderIndexFor(item, snapshot)
              const pane = document.querySelector('[data-trajectory-scroll]')
              if (order !== null && pane !== null) {
                const max = Math.max(0, pane.scrollHeight - pane.clientHeight)
                const ratio = order.index / Math.max(1, order.count)
                pane.scrollTop = Math.round(max * ratio)
                pane.dispatchEvent(new Event('scroll'))
                await waitForNextFrame()
                row = findTrajectoryRowFor(item, key)
              }
            }
            if (row === null) {
              setJumpError('目标行未在轨迹中渲染')
              return
            }
            row.scrollIntoView({ behavior: 'smooth', block: 'center' })
            setActiveSeq(item.seq)
            return
          }
          let guard = 0
          while (snapshot.hasMore === true && !hasSeqInWindow(snapshot, item.seq) && guard < 200) {
            await session.loadOlder()
            snapshot = session.getSnapshot()
            guard += 1
          }
          const node = findNodeForSeq(snapshot, item.seq)
          if (node === null) {
            setJumpError('无法定位该消息')
            return
          }
          const row = findAnchorRow(node.key)
          if (row === null) {
            setJumpError('目标不在当前聊天视图')
            return
          }
          row.scrollIntoView({ behavior: 'smooth', block: 'start' })
          setActiveSeq(item.seq)
        } catch (reason) {
          setJumpError(reason instanceof Error ? reason.message : String(reason))
        } finally {
          setJumping(null)
        }
      }, [sessionId])

      const toggleTurn = (turnId, allTurnIds) => {
        setCollapsedTurns((current) => {
          if (current === null) {
            const next = new Set(allTurnIds)
            next.delete(turnId)
            return next
          }
          const next = new Set(current)
          if (next.has(turnId)) next.delete(turnId)
          else next.add(turnId)
          return next
        })
      }

      const toggleToolGroup = (groupId) => {
        setExpandedToolGroups((current) => {
          const next = new Set(current)
          if (next.has(groupId)) next.delete(groupId)
          else next.add(groupId)
          return next
        })
      }

      if (!panel.open) return null

      const renderItems = (items) => items.map((item, index) => {
        if (item.kind === 'tool-group') {
          return React.createElement(ToolGroup, {
            key: item.id,
            group: item,
            expanded: expandedToolGroups.has(item.id),
            activeSeq,
            jumping,
            onToggle: () => { toggleToolGroup(item.id) },
            onJump: (target) => { void jumpTo(target) },
          })
        }
        return React.createElement(OutlineRow, {
          key: `${item.id}:${index}`,
          item,
          active: activeSeq === item.seq,
          jumping,
          onClick: (target) => { void jumpTo(target) },
        })
      })

      const fallbackTitleFor = (entry) => {
        const first = Array.isArray(entry.items) ? entry.items[0] : undefined
        if (first !== undefined && typeof first === 'object') {
          if (first.kind === 'tool-group' && typeof first.count === 'number') {
            return `${first.count} 次调用`
          }
          if (typeof first.preview === 'string' && first.preview.length > 0) {
            return first.preview
          }
        }
        return `第 ${entry.turn} 轮`
      }

      const renderTurn = (entry, allTurnIds) => {
        const collapsed = collapsedTurns === null || collapsedTurns.has(entry.id)
        const title = entry.titleStatus === 'ready' && typeof entry.title === 'string' && entry.title.length > 0
          ? entry.title
          : fallbackTitleFor(entry)
        const metaParts = []
        if (entry.titleStatus === 'queued') metaParts.push('生成标题中...')
        if (entry.titleStatus === 'error') metaParts.push('标题未生成')
        metaParts.push(`${entry.items.length} 项`)
        return React.createElement('section', { key: entry.id, className: `outline-turn-card${collapsed ? ' outline-turn-collapsed' : ''}` },
          React.createElement('button', {
            type: 'button',
            className: 'outline-turn-head',
            'aria-expanded': !collapsed,
            onClick: () => { toggleTurn(entry.id, allTurnIds) },
          },
          React.createElement('span', { className: `outline-turn-chevron${collapsed ? '' : ' outline-turn-chevron-open'}` },
            iconPath(chevronPath)),
          React.createElement('span', { className: 'outline-turn-title' }, title),
          React.createElement('span', { className: 'outline-turn-meta' }, metaParts.join(' · '))),
          collapsed ? null : React.createElement('div', { className: 'outline-turn-items' }, renderItems(entry.items)))
      }

      const timeline = Array.isArray(outline.timeline) ? outline.timeline : []
      const turnIds = timeline.filter((entry) => entry.kind === 'turn').map((entry) => entry.id)

      const hasTimeline = timeline.length > 0
      const outlineBody = status === 'loading'
        ? React.createElement('p', { className: 'outline-overlay-status' }, '正在生成大纲...')
        : status === 'error' && !hasTimeline
          ? React.createElement('div', null,
              React.createElement('p', { className: 'outline-overlay-error' }, error),
              React.createElement('div', { className: 'outline-overlay-tools' },
                React.createElement('button', { type: 'button', className: 'outline-overlay-secondary', onClick: loadOutline }, '刷新')))
          : !hasTimeline
            ? React.createElement('p', { className: 'outline-overlay-status' }, '会话暂无内容')
            : React.createElement('div', null,
                error === null ? null : React.createElement('p', { className: 'outline-overlay-error' }, error),
                ...timeline.map((entry) => entry.kind === 'turn'
                  ? renderTurn(entry, turnIds)
                  : React.createElement('div', { key: entry.item.id, className: 'outline-standalone-item' },
                      React.createElement(OutlineRow, {
                        item: entry.item,
                        active: activeSeq === entry.item.seq,
                        jumping,
                        onClick: (target) => { void jumpTo(target) },
                      }))),
                jumpError === null ? null : React.createElement('p', { className: 'outline-overlay-error' }, jumpError))

      return React.createElement('div', { className: 'outline-details-root', role: 'complementary', 'aria-label': '对话大纲' },
        React.createElement('div', { className: 'outline-overlay-header' },
          React.createElement('h2', { className: 'outline-overlay-title' }, '对话大纲'),
          React.createElement('button', {
            type: 'button',
            className: 'outline-overlay-icon-btn',
            'aria-label': '刷新大纲',
            title: '刷新大纲',
            disabled: status === 'loading' || refreshing,
            onClick: loadOutline,
          }, refreshing || status === 'loading'
            ? React.createElement('span', { className: 'outline-refresh-spin' },
                iconPath('M13.5 8a5.5 5.5 0 1 1-1.6-3.9M13.5 2.5v3h-3'))
            : iconPath('M13.5 8a5.5 5.5 0 1 1-1.6-3.9M13.5 2.5v3h-3')),
          React.createElement('button', {
            type: 'button',
            className: 'outline-overlay-icon-btn',
            'aria-label': '关闭大纲',
            title: '关闭大纲',
            onClick: closePanel,
          }, iconPath('M4 4l8 8M12 4l-8 8'))),
        React.createElement('div', { className: 'outline-overlay-body' }, outlineBody))
    }

    ctx.effect(() => styles.insert(css))

    const slots = ctx.get('slots')
    if (slots !== undefined) {
      sessionsService = ctx.get('sessions') !== undefined ? ctx.get('sessions') : null
      layoutService = ctx.get('layout') !== undefined ? ctx.get('layout') : null
      slots.inject('conversation.session.header.actions', () => slots.register({
        name: 'conversation.session.header.actions',
        id: 'conversation-outline-toggle',
        order: 30,
        priority: -1,
        label: () => '大纲',
      }, OutlineToggle))
      slots.inject('details', () => slots.register({
        name: 'details',
        priority: -1,
      }, OutlinePanel))
    }
  },
}
