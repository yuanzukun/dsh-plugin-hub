/**
 * Host half: reads one complete session log through sessionQuery and returns
 * a compact timeline outline. It also generates one concise title per turn
 * through a spawned subagent, using the parent's model route.
 */
return {
  inject: ['sessionQuery', 'agents', 'agentDefaultModel'],
  apply(ctx) {
    const PREVIEW_MAX = 120
    const TITLE_CONTEXT_MAX = 8000
    const TITLE_MAX = 48
    const titleCache = new Map()
    const titlePromises = new Map()
    const outlineCache = new Map()
    const llmService = ctx.get('llm') !== undefined ? ctx.get('llm') : undefined

    const compact = (value, max = PREVIEW_MAX) => {
      const text = typeof value === 'string' ? value : ''
      const oneLine = text.replace(/\s+/g, ' ').trim()
      if (oneLine.length <= max) return oneLine
      return `${oneLine.slice(0, max - 1).trimEnd()}...`
    }

    const contentPreview = (blocks) => {
      if (!Array.isArray(blocks)) return ''
      for (const block of blocks) {
        if (block !== null && typeof block === 'object' && block.type === 'text'
          && typeof block.text === 'string' && block.text.trim().length > 0) {
          return compact(block.text)
        }
      }
      return ''
    }

    const textBlocks = (blocks) => {
      if (!Array.isArray(blocks)) return []
      const out = []
      for (const block of blocks) {
        if (block !== null && typeof block === 'object' && block.type === 'text'
          && typeof block.text === 'string' && block.text.trim().length > 0) {
          out.push(block.text.trim())
        }
      }
      return out
    }

    const titleKeyFor = (text) => {
      let hash = 2166136261
      for (let index = 0; index < text.length; index += 1) {
        hash ^= text.charCodeAt(index)
        hash = Math.imul(hash, 16777619) >>> 0
      }
      return `outline:${hash.toString(36)}`
    }

    const reasonPreview = (reason) => {
      if (reason === null || typeof reason !== 'object') return '完成'
      switch (reason.kind) {
        case 'completed': return '完成'
        case 'aborted': return '已中断'
        case 'error':
          if (reason.error !== null && typeof reason.error === 'object'
            && typeof reason.error.message === 'string') {
            return compact(reason.error.message)
          }
          return '错误'
        case 'max-tokens': return '达到最大输出'
        case 'blocked': return '被阻止'
        case 'interrupted': return '中断'
        default: return '完成'
      }
    }

    const sourceOf = (event, data) => {
      const message = data.message !== null && typeof data.message === 'object' ? data.message : {}
      const source = message.source !== null && typeof message.source === 'object' ? message.source : {}
      if (source.kind !== undefined) return source
      return data.source !== null && typeof data.source === 'object' ? data.source : {}
    }

    const toolCallIdOf = (data) => {
      if (typeof data.callId === 'string' && data.callId.length > 0) return data.callId
      const message = data.message !== null && typeof data.message === 'object' ? data.message : {}
      const source = message.source !== null && typeof message.source === 'object' ? message.source : {}
      if (typeof source.callId === 'string' && source.callId.length > 0) return source.callId
      return null
    }

    const userLabelOf = (source) => {
      if (source.kind === 'user') return '用户'
      if (source.kind === 'plugin' || source.kind === 'agent-instructions' || source.kind === 'skill-catalog') return '上下文'
      return '消息'
    }

    const ensureTurn = (timeline, turnIndex, turn) => {
      let entry = turnIndex.get(turn)
      if (entry === undefined) {
        entry = {
          kind: 'turn',
          id: `turn:${turn}`,
          turn,
          startSeq: null,
          endSeq: null,
          endReason: null,
          title: null,
          titleStatus: 'queued',
          items: [],
          hasContent: false,
        }
        turnIndex.set(turn, entry)
        timeline.push(entry)
      }
      return entry
    }

    const canMergeTools = (entry, last) => {
      if (entry.breakAt === null || entry.breakAt === undefined) return true
      const lastSeq = last.kind === 'tool-group'
        ? last.items[last.items.length - 1].seq
        : last.seq
      return lastSeq > entry.breakAt
    }

    const pushTurnItem = (entry, item) => {
      if (entry.turn !== null && item.turn === undefined) item.turn = entry.turn
      const isContextItem = item.kind === 'user' && (item.label === '上下文' || item.label === '消息')
      if (!isContextItem) entry.hasContent = true
      const last = entry.items.length > 0 ? entry.items[entry.items.length - 1] : null
      if (item.kind === 'tool') {
        if (last !== null && last.kind === 'tool-group' && canMergeTools(entry, last)) {
          last.items.push(item)
          last.count += 1
          last.endSeq = item.seq
          return
        }
        if (last !== null && last.kind === 'tool' && canMergeTools(entry, last)) {
          entry.items[entry.items.length - 1] = {
            kind: 'tool-group',
            id: `tool-group:${entry.id}:${last.seq}`,
            seq: last.seq,
            count: 2,
            items: [last, item],
            endSeq: item.seq,
          }
          return
        }
        entry.items.push(item)
        return
      }
      entry.items.push(item)
    }

    const makeItem = (kind, seq, time, label, preview, extra = {}) => ({
      id: `${kind}:${seq}`,
      kind,
      seq,
      time,
      label,
      preview,
      ...extra,
    })

    const timelineFromEvents = (events) => {
      const timeline = []
      const turnIndex = new Map()
      const pendingUserItems = []
      let currentTurn = null

      for (const event of events) {
        if (event === null || typeof event !== 'object' || typeof event.type !== 'string') continue
        const data = event.data !== null && typeof event.data === 'object' ? event.data : {}
        const seq = typeof event.seq === 'number' ? event.seq : 0
        const time = typeof event.time === 'number' ? event.time : 0

        switch (event.type) {
          case 'turn/start': {
            if (typeof data.turn === 'number') {
              currentTurn = ensureTurn(timeline, turnIndex, data.turn)
              if (currentTurn.startSeq === null) currentTurn.startSeq = seq
              while (pendingUserItems.length > 0) {
                pushTurnItem(currentTurn, pendingUserItems.shift())
              }
            }
            break
          }
          case 'turn/end': {
            const turn = typeof data.turn === 'number' ? data.turn : currentTurn
            if (turn !== null) {
              const entry = ensureTurn(timeline, turnIndex, turn)
              entry.endSeq = seq
            }
            currentTurn = null
            break
          }
          case 'user/message': {
            const source = sourceOf(event, data)
            const preview = contentPreview(data.content)
            if (preview.length > 0) {
              const item = makeItem('user', seq, time, userLabelOf(source), preview)
              if (source.kind === 'user') {
                if (currentTurn !== null) {
                  currentTurn.breakAt = seq
                  pushTurnItem(currentTurn, item)
                } else {
                  pendingUserItems.push(item)
                }
              } else if (currentTurn === null) {
                timeline.push({ kind: 'item', item })
              } else {
                pushTurnItem(currentTurn, item)
              }
            }
            break
          }
          case 'assistant/message': {
            const message = data.message !== null && typeof data.message === 'object' ? data.message : {}
            const preview = contentPreview(message.content)
            if (preview.length > 0) {
              const item = makeItem('assistant', seq, time, '助手', preview, {
                turn: typeof data.turn === 'number' ? data.turn : null,
                step: typeof data.step === 'number' ? data.step : null,
              })
              if (currentTurn === null) timeline.push({ kind: 'item', item })
              else pushTurnItem(currentTurn, item)
            }
            break
          }
          case 'tool/call': {
            const name = typeof data.name === 'string' && data.name.length > 0 ? data.name : 'tool'
            const args = typeof data.arguments === 'string' && data.arguments.length > 0
              ? ` · ${compact(data.arguments)}`
              : ''
            const callId = toolCallIdOf(data)
            const item = makeItem('tool', seq, time, '工具', `${name}${args}`, {
              name,
              ...(callId === null ? {} : { callId }),
            })
            if (currentTurn === null) timeline.push({ kind: 'item', item })
            else pushTurnItem(currentTurn, item)
            break
          }
          case 'tool/result': {
            const error = data.error !== null && typeof data.error === 'object' ? data.error : null
            if (error !== null) {
              const preview = typeof error.name === 'string' && error.name.length > 0
                ? `${error.name}${typeof error.code === 'string' ? ' · ' + error.code : ''}`
                : '工具调用失败'
              const callId = toolCallIdOf(data)
              const item = makeItem('error', seq, time, '错误', preview, {
                ...(callId === null ? {} : { callId }),
              })
              if (currentTurn === null) timeline.push({ kind: 'item', item })
              else pushTurnItem(currentTurn, item)
            }
            break
          }
          case 'compaction/summary': {
            const preview = contentPreview(data.summary)
            if (preview.length > 0) {
              const item = makeItem('compaction', seq, time, '压缩检查点', preview)
              if (currentTurn === null) timeline.push({ kind: 'item', item })
              else pushTurnItem(currentTurn, item)
            }
            break
          }
          case 'command/run': {
            break
          }
          default:
            break
        }
      }

      for (const item of pendingUserItems) {
        timeline.push({ kind: 'item', item })
      }

      for (const entry of turnIndex.values()) {
        if (entry.startSeq === null && entry.items.length > 0) entry.startSeq = entry.items[0].seq
      }

      return { timeline }
    }

    const buildTurnContext = (events, turn, startSeq, endSeq, previousEndSeq) => {
      const lines = []
      const ceiling = endSeq === null || endSeq === undefined ? Number.POSITIVE_INFINITY : endSeq

      for (const event of events) {
        if (event === null || typeof event !== 'object' || typeof event.type !== 'string') continue
        const seq = typeof event.seq === 'number' ? event.seq : 0
        const data = event.data !== null && typeof event.data === 'object' ? event.data : {}

        if (event.type === 'user/message' && seq >= startSeq && seq <= ceiling) {
          const source = sourceOf(event, data)
          if (source.kind === 'user') {
            for (const text of textBlocks(data.content)) lines.push(`用户：${text}`)
          }
          continue
        }

        if (event.type === 'assistant/message' && seq >= startSeq && seq <= ceiling) {
          const message = data.message !== null && typeof data.message === 'object' ? data.message : {}
          for (const text of textBlocks(message.content)) lines.push(`助手：${text}`)
        }
      }

      const joined = lines.join('\n').trim()
      return joined.length > TITLE_CONTEXT_MAX ? `${joined.slice(0, TITLE_CONTEXT_MAX).trimEnd()}...` : joined
    }

    const makeNoopSignal = () => ({
      aborted: false,
      reason: undefined,
      addEventListener() {},
      removeEventListener() {},
      dispatchEvent() {
        return false
      },
      throwIfAborted() {},
    })

    const parentSelection = (parent) => {
      const options = parent !== undefined && parent.options !== null && typeof parent.options === 'object'
        ? parent.options
        : {}
      let fallback = {}
      if (ctx.agentDefaultModel !== undefined && typeof ctx.agentDefaultModel.currentSelection === 'function') {
        const selection = ctx.agentDefaultModel.currentSelection()
        if (selection !== null && typeof selection === 'object') fallback = selection
      }
      return {
        provider: options.provider ?? fallback.provider,
        model: options.model ?? fallback.model,
        maxTokens: options.maxTokens ?? fallback.maxTokens,
      }
    }

    const titlePrompt = (contextText) => [
      '请根据下面这一轮对话生成一个简短的中文标题。',
      '规则：只输出一句话，不超过 40 个中文字符；不要输出引号、解释或 Markdown。',
      '下面是从用户命令到模型输出提取的对话内容，已删除工具调用和思考过程：',
      '',
      contextText,
    ].join('\n')

    const performTitleRun = async (parent, selection, contextText, signal) => {
      if (llmService === undefined || typeof llmService.stream !== 'function') {
        return { ok: false, error: '没有可用的 llm 服务' }
      }
      const parts = {}
      let finish = null
      for await (const chunk of llmService.stream({
        provider: selection.provider,
        model: selection.model,
        messages: [{
          id: 'outline-turn-title',
          role: 'user',
          content: [{ type: 'text', text: titlePrompt(contextText) }],
          source: { kind: 'user' },
        }],
        ...(selection.maxTokens === undefined ? {} : { maxTokens: selection.maxTokens }),
        purpose: 'session-title',
        signal,
      })) {
        if (chunk.type === 'text-delta') {
          parts[chunk.index] = (parts[chunk.index] ?? '') + chunk.text
        } else if (chunk.type === 'block-end' && chunk.block.type === 'text') {
          parts[chunk.index] = chunk.block.text
        } else if (chunk.type === 'finish') {
          finish = chunk.reason
        }
      }
      const ordered = Object.keys(parts).sort((left, right) => Number(left) - Number(right))
      const text = ordered.map((index) => parts[index]).join('\n').trim()
      const title = text.replace(/^["“'‘]+|["”'’]+$/g, '').trim()
      if (finish === null || finish.kind !== 'stop' || title.length === 0) {
        return { ok: false, error: `标题生成失败：${finish === null ? 'unknown' : finish.kind}` }
      }
      return { ok: true, title: compact(title, TITLE_MAX) }
    }

    const generateTitle = async (sessionId, turn, events, startSeq, endSeq, previousEndSeq) => {
      const contextText = buildTurnContext(events, turn, startSeq, endSeq, previousEndSeq)
      const key = titleKeyFor(contextText)
      const cached = titleCache.get(key)
      if (cached !== undefined && cached.status === 'ready') {
        return { ok: true, title: cached.title, titleKey: key }
      }
      if (cached !== undefined && cached.status === 'error') return { ok: false, error: cached.error }
      if (titlePromises.has(key)) return titlePromises.get(key)

      const promise = (async () => {
        if (contextText.length === 0) {
          const failed = { status: 'error', error: '这一轮没有可摘要的可见文本' }
          titleCache.set(key, failed)
          return { ok: false, error: failed.error }
        }
        const parent = ctx.agents.get(sessionId) ?? ctx.agents.currentInitiator()
        if (parent === undefined) {
          const failed = { status: 'error', error: '找不到主 Agent' }
          titleCache.set(key, failed)
          return { ok: false, error: failed.error }
        }
        const selection = parentSelection(parent)
        if (typeof selection.provider !== 'string' || typeof selection.model !== 'string') {
          const failed = { status: 'error', error: '无法确定主 Agent 的模型参数' }
          titleCache.set(key, failed)
          return { ok: false, error: failed.error }
        }

        let outcome
        if (typeof parent.runMaintenance === 'function') {
          try {
            outcome = await parent.runMaintenance((signal) => performTitleRun(parent, selection, contextText, signal))
          } catch {
            outcome = await performTitleRun(parent, selection, contextText, makeNoopSignal())
          }
        } else {
          outcome = await performTitleRun(parent, selection, contextText, makeNoopSignal())
        }

        if (outcome.ok === true) {
          titleCache.set(key, { status: 'ready', title: outcome.title })
          return { ok: true, title: outcome.title, titleKey: key }
        }
        titleCache.set(key, { status: 'error', error: outcome.error })
        return outcome
      })()

      titlePromises.set(key, promise)
      try {
        return await promise
      } finally {
        titlePromises.delete(key)
      }
    }

    const turnMetadata = (events) => {
      const starts = new Map()
      const ends = new Map()
      const previousEnds = new Map()
      let previousEndSeq = null
      for (const event of events) {
        if (event === null || typeof event !== 'object' || typeof event.type !== 'string') continue
        const data = event.data !== null && typeof event.data === 'object' ? event.data : {}
        if (event.type === 'turn/start' && typeof data.turn === 'number') {
          starts.set(data.turn, event.seq)
          if (previousEndSeq !== null) previousEnds.set(data.turn, previousEndSeq)
        }
        if (event.type === 'turn/end' && typeof data.turn === 'number') {
          ends.set(data.turn, event.seq)
          previousEndSeq = event.seq
        }
      }
      return { starts, ends, previousEnds }
    }

    const turnsWithMetadata = (events, timeline) => {
      const { starts, ends, previousEnds } = turnMetadata(events)
      return timeline.map((entry) => {
        if (entry.kind !== 'turn') return entry
        return {
          ...entry,
          startSeq: starts.get(entry.turn) ?? entry.startSeq,
          endSeq: ends.get(entry.turn) ?? entry.endSeq,
          previousEndSeq: previousEnds.get(entry.turn) ?? null,
        }
      })
    }

    const applyCachedTitles = (timeline, sessionId) => timeline.map((entry) => {
      if (entry.kind !== 'turn') return entry
      const cacheKey = typeof entry.titleKey === 'string' && entry.titleKey.length > 0
        ? entry.titleKey
        : `${sessionId}:${entry.turn}`
      const cached = titleCache.get(cacheKey)
      if (cached !== undefined && cached.status === 'ready') {
        return { ...entry, title: cached.title, titleStatus: 'ready' }
      }
      if (cached !== undefined && cached.status === 'error') {
        return { ...entry, titleStatus: 'error' }
      }
      return entry
    })

    ctx.effect(() => harness.handle('outline/snapshot', async (args) => {
      const input = args !== null && typeof args === 'object' ? args : {}
      const sessionId = typeof input.sessionId === 'string' && input.sessionId.length > 0
        ? input.sessionId
        : null
      if (sessionId === null) return { ok: false, error: 'sessionId is required' }
      try {
        let lastSeq = null
        let records = null
        try {
          records = await ctx.sessionQuery.listEvents(sessionId)
        } catch {
          records = null
        }
        if (Array.isArray(records)) {
          lastSeq = records.length > 0 && typeof records[records.length - 1].seq === 'number'
            ? records[records.length - 1].seq
            : -1
        }
        const cached = outlineCache.get(sessionId)
        if (cached !== undefined && cached.lastSeq === lastSeq) {
          return { ok: true, outline: { timeline: applyCachedTitles(cached.timeline, sessionId) } }
        }
        const snapshot = await ctx.sessionQuery.readSession(sessionId)
        const outline = timelineFromEvents(snapshot.events)
        const withMeta = turnsWithMetadata(snapshot.events, outline.timeline)
        const withTitleKeys = withMeta.map((entry) => {
          if (entry.kind !== 'turn') return entry
          const contextText = buildTurnContext(
            snapshot.events,
            entry.turn,
            entry.startSeq ?? 0,
            entry.endSeq ?? null,
            entry.previousEndSeq ?? null,
          )
          return { ...entry, titleKey: titleKeyFor(contextText) }
        })
        outlineCache.set(sessionId, { lastSeq, timeline: withTitleKeys })
        return { ok: true, outline: { timeline: applyCachedTitles(withTitleKeys, sessionId) } }
      } catch (error) {
        return { ok: false, error: error instanceof Error ? error.message : String(error) }
      }
    }))

    ctx.effect(() => harness.handle('outline/title', async (args) => {
      const input = args !== null && typeof args === 'object' ? args : {}
      const sessionId = typeof input.sessionId === 'string' && input.sessionId.length > 0
        ? input.sessionId
        : null
      const turn = typeof input.turn === 'number' ? input.turn : null
      if (sessionId === null || turn === null) {
        return { ok: false, error: 'sessionId and turn are required' }
      }
      try {
        const snapshot = await ctx.sessionQuery.readSession(sessionId)
        const { starts, ends, previousEnds } = turnMetadata(snapshot.events)
        return await generateTitle(
          sessionId,
          turn,
          snapshot.events,
          starts.get(turn) ?? 0,
          ends.get(turn) ?? null,
          previousEnds.get(turn) ?? null,
        )
      } catch (error) {
        return { ok: false, error: error instanceof Error ? error.message : String(error) }
      }
    }))
  },
}
