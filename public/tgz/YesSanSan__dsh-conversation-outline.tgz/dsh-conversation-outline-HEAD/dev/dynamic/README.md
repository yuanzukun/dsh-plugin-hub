# conversation-outline-sidebar dynamic plugin

当前进程中直接运行的 DSH Web 插件：在会话头部增加“大纲”开关，右侧浮层显示当前会话的完整结构化大纲，并支持点击跳转到对应聊天消息。

## 文件

- `src/host/plugin.host.js`：Host 半区。通过 `sessionQuery.readSession` 读取完整日志，在 Host 端压缩成紧凑大纲 JSON。
- `src/client/plugin.client.js`：Client 半区。注册头部按钮和 `shell.overlay` 面板，处理大纲渲染、历史加载和 DOM 跳转。

## 在当前 Harness 中加载

这份源码就是 `cordis_define` 的 Host/Client 代码：

1. Host 代码使用 `src/host/plugin.host.js`。
2. Client 代码使用 `src/client/plugin.client.js`。
3. 定义后运行，在 WebUI 会话头部点击“大纲”。

## 限制

- 动态插件只在当前进程生效，重启即丢。
- 快速跳转依赖聊天行现有 `data-chat-anchor-key`；若 DSH 未来移除该属性，会降级为“无法定位目标”。
- 面板优先服务于当前普通会话；子代理/冷会话可用性取决于当前会话 binding 是否存在。
