# Changelog

All notable changes to this project are documented in this file.

## [0.3.0] - 2025

### Added

- Kind tags now collapse into icons when the panel is narrow (≤360px
  container width), mirroring the trajectory view's `kindTag` behavior: each
  tag renders an `aria-hidden` icon (in a tooltip with the full label) plus
  the text label; a named container query (`outline-tab`) swaps them with a
  smooth `prefers-reduced-motion`-aware transition.
- Icons are byte-identical to the trajectory page: user/assistant reuse the
  same primitives (`IconUserOutline16` / `IconSparkle16`); context/tool/
  compaction use verbatim copies of the trajectory's Information/Wrench/
  Compacted glyphs; error rows use the same tool wrench (trajectory renders
  failed tool calls as kind `tool`).

## [0.2.0] - 2025

### Fixed

- Title generation no longer uses `agent.runMaintenance()`: it **throws**
  ("already has active work") while the agent is busy and never queues, so it
  could never provide parallelism. Title generation is now a plain `llm.stream`
  call with its own `AbortController` — fully parallel with the session,
  matching DSH's built-in `dsh-session-title-llm` design.
- Root cause of "stuck in 生成标题中 / timeout never fired": the old per-chunk
  timeout inside the `llm.stream` loop never ran when the provider stream
  produced no chunks, while the adapter idle watchdog defaults to 300s. The
  timeout is now enforced over the WHOLE attempt via `Promise.race` armed at
  attempt start, so every attempt returns within `timeoutSeconds`.
- Client no longer gates ALL title requests on `running`; only the still-open
  current turn (`endSeq === null` while running) is deferred
  ("等待本轮结束..."), and it auto-generates when the turn ends.
- Host timeout/retry never fall back to 0 when query params are absent
  (persisted settings → 60s / 2 retries defaults).

### Added

- Settings: `model`, `reasoningEffort`, `maxConcurrency`, `timeoutSeconds`,
  `maxRetries`, `disabled` — persisted via better-sidebar `pluginSettings`
  (v0.12.0+) with `localStorage` fallback.

## [0.1.0] - 2025

- Initial external-plugin release: `conversation-outline` tab for
  dsh-better-sidebar, per-turn outline with quick jump (chat + trajectory),
  LLM titles with content-fingerprint caching.
