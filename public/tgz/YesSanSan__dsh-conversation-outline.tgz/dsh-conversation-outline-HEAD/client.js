window.__ModuleLoader__.load({
  id: 'dsh-client-ui-conversation-outline',
  factory: (require) => {
    var module = { exports: {} }
    var exports = module.exports
    var React = require('react')
    var uiPrimitives = require('@deepseek-ai/dsh-client-ui-primitives')
    var NativeChevronDown = uiPrimitives && uiPrimitives.IconChevronDownOutline14
      ? uiPrimitives.IconChevronDownOutline14
      : null
    var NativeTooltip = uiPrimitives && uiPrimitives.Tooltip
      ? uiPrimitives.Tooltip
      : null
    var NativeIconUser = uiPrimitives && uiPrimitives.IconUserOutline16
      ? uiPrimitives.IconUserOutline16
      : null
    var NativeIconSparkle = uiPrimitives && uiPrimitives.IconSparkle16
      ? uiPrimitives.IconSparkle16
      : null

    const css = `
.outline-details-root {
  box-sizing: border-box;
  height: 100%;
  min-width: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: var(--dsw-specific-sidebar-fill, var(--dsw-alias-bg-base, #242424));
  color: var(--dsw-alias-label-primary, #e8e8e8);
  /* Named inline-size container: at narrow panel widths the kind text tags
     collapse into icons, mirroring the trajectory view's kindTag behavior. */
  container: outline-tab / inline-size;
}
.outline-overlay-header {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  gap: 8px;
  flex: none;
  padding: 14px 12px 12px;
  border-bottom: 1px solid var(--dsw-alias-border-l2, #555);
}
.outline-overlay-title {
  min-width: 0;
  flex: 1;
  margin: 0;
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.outline-overlay-icon-btn {
  box-sizing: border-box;
  width: 28px;
  height: 28px;
  flex: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: none;
  border-radius: 50%;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #b8b8b8);
  cursor: pointer;
  padding: 0;
}
.outline-overlay-icon-btn:hover {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
  color: var(--dsw-alias-label-primary, #e8e8e8);
}
.outline-overlay-icon-btn:disabled {
  opacity: 0.45;
  cursor: default;
}
.outline-refresh-spin {
  display: inline-flex;
  animation: outline-spin 1s linear infinite;
}
@keyframes outline-spin {
  to { transform: rotate(360deg); }
}
.outline-overlay-body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  padding: 6px 12px 12px;
  --dsh-scrollbar-thumb: var(--dsw-alias-scrollbar-bg-l2, #555);
  --dsh-scrollbar-thumb-hover: var(--dsw-alias-scrollbar-hover-l2, #777);
}
.outline-overlay-status {
  margin: 12px;
  color: var(--dsw-alias-label-tertiary, #999);
  font-size: 13px;
  line-height: 20px;
}
.outline-overlay-error {
  margin: 12px 12px 10px;
  color: var(--dsw-alias-state-error-primary, #e5484d);
  font-size: 13px;
  line-height: 20px;
}
.outline-overlay-tools {
  display: flex;
  gap: 8px;
  align-items: center;
  margin: 0 12px;
}
.outline-overlay-secondary {
  box-sizing: border-box;
  height: 30px;
  padding: 0 10px;
  border: 1px solid var(--dsw-alias-border-l2, #555);
  border-radius: 8px;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #b8b8b8);
  font: inherit;
  font-size: 12px;
  line-height: 18px;
  cursor: pointer;
}
.outline-overlay-secondary:hover:not(:disabled) {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
  color: var(--dsw-alias-label-primary, #e8e8e8);
}
.outline-standalone-item {
  padding: 6px 12px 0;
}
.outline-turn-card {
  position: relative;
  margin-top: 10px;
  border: 1px solid var(--dsw-alias-border-l2, #555);
  border-radius: 8px;
  background: var(--dsw-alias-bg-layer-2, #242424);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
}
.outline-turn-card .outline-turn-head {
  box-sizing: border-box;
  position: sticky;
  top: 0;
  z-index: 3;
  width: 100%;
  min-height: 40px;
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0;
  padding: 8px 12px;
  border: none;
  border-bottom: 1px solid var(--dsw-alias-border-l2, #555);
  border-radius: 8px 8px 0 0;
  background: var(--dsw-alias-bg-layer-2, #242424);
  color: var(--dsw-alias-label-primary, #e8e8e8);
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.outline-turn-card .outline-turn-head:hover {
  background: var(--dsw-alias-bg-layer-3, #303030);
}
.outline-turn-card.outline-turn-collapsed .outline-turn-head {
  border-bottom: none;
  border-radius: 8px;
}
.outline-turn-chevron {
  flex: none;
  color: var(--dsw-alias-label-tertiary, #999);
  transition: transform 120ms ease;
}
.outline-turn-chevron-open {
  transform: rotate(90deg);
}
.outline-turn-title {
  min-width: 0;
  flex: 1;
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.outline-turn-meta {
  flex: none;
  color: var(--dsw-alias-label-tertiary, #999);
  font-size: 11px;
  line-height: 16px;
  white-space: nowrap;
}
.outline-turn-items {
  padding: 4px 8px 8px;
  border-radius: 0 0 8px 8px;
}
.outline-row {
  box-sizing: border-box;
  width: 100%;
  min-height: 34px;
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 6px 8px;
  border: 1px solid transparent;
  border-radius: 8px;
  background: transparent;
  color: var(--dsw-alias-label-primary, #e8e8e8);
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.outline-row:hover:not(:disabled) {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
}
.outline-row:focus-visible {
  outline: 2px solid var(--dsw-alias-brand-primary, #4f8cff);
  outline-offset: -2px;
}
.outline-row:disabled {
  opacity: 0.55;
  cursor: default;
}
.outline-row-active {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
  border-color: var(--dsw-alias-brand-primary, #4f8cff);
}
.outline-row-kind {
  box-sizing: border-box;
  flex: none;
  width: 42px;
  height: 19px;
  padding: 0 5px;
  border-radius: 4px;
  background: var(--dsw-alias-bg-module-platform, #333);
  color: var(--dsw-alias-label-secondary, #b8b8b8);
  font-size: 10px;
  font-weight: 600;
  line-height: 16px;
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 2px;
}
.outline-row-kind-icon {
  flex: none;
  width: 0;
  height: 13px;
  opacity: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  transform: scale(0.8);
}
.outline-row-kind-label {
  min-width: 0;
  max-width: 72px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  opacity: 1;
  display: inline-block;
}
@container outline-tab (max-width: 360px) {
  .outline-row-kind {
    width: 19px;
    padding: 0;
    gap: 0;
  }
  .outline-row-kind-icon {
    width: 13px;
    opacity: 1;
    transform: scale(1);
  }
  .outline-row-kind-label {
    max-width: 0;
    opacity: 0;
  }
}
@media (prefers-reduced-motion: no-preference) {
  .outline-row-kind,
  .outline-row-kind-icon,
  .outline-row-kind-label {
    transition-property: width, max-width, opacity, transform, padding;
    transition-duration: 0.18s;
    transition-timing-function: var(--ds-ease-in-out, ease);
  }
}
.outline-row-kind-user {
  color: var(--dsw-alias-state-business-primary, #4f8cff);
  background: var(--dsw-alias-state-business-tertiary, #1e3a5f);
}
.outline-row-kind-context {
  color: color-mix(in srgb, var(--dsw-alias-state-success-primary, #30a46c) 68%, var(--dsw-alias-label-secondary, #b8b8b8));
  background: var(--dsw-alias-state-success-tertiary, #173f31);
}
.outline-row-kind-assistant {
  color: color-mix(in srgb, var(--dsw-alias-brand-primary, #6e56cf) 60%, var(--dsw-alias-state-error-secondary, #ff8b8b));
  background: color-mix(in srgb, color-mix(in srgb, var(--dsw-alias-brand-primary, #6e56cf) 55%, var(--dsw-alias-state-error-secondary, #ff8b8b)) 15%, var(--dsw-alias-bg-layer-1, #1f1f1f));
}
.outline-row-kind-tool {
  color: var(--dsw-alias-state-warn-label, #e5a50a);
  background: var(--dsw-alias-state-warn-tertiary, #3d2f12);
}
.outline-row-kind-error {
  color: var(--dsw-alias-state-error-primary, #e5484d);
  background: var(--dsw-alias-state-error-tertiary, #3f1d22);
}
.outline-row-kind-compaction {
  color: var(--dsw-alias-label-secondary, #b8b8b8);
  background: var(--dsw-alias-bg-module-platform, #333);
}
.outline-row-preview {
  flex: 1;
  min-width: 0;
  font-size: 12px;
  line-height: 20px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-break: break-word;
}
.outline-tool-group {
  margin: 2px 0;
}
.outline-tool-group-head {
  box-sizing: border-box;
  width: 100%;
  min-height: 34px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 8px;
  border: 1px solid transparent;
  border-radius: 8px;
  background: transparent;
  color: var(--dsw-alias-label-primary, #e8e8e8);
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.outline-tool-group-head:hover {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
}
.outline-tool-group-chevron {
  flex: none;
  color: var(--dsw-alias-label-tertiary, #999);
  transition: transform 120ms ease;
}
.outline-tool-group-chevron-open {
  transform: rotate(90deg);
}
.outline-tool-group-count {
  color: var(--dsw-alias-state-business-primary, #4f8cff);
  font-size: 11px;
  font-weight: 600;
  line-height: 16px;
}
.outline-tool-group-items {
  margin-left: 18px;
  padding-left: 4px;
  border-left: 1px solid var(--dsw-alias-border-l2, #555);
}
.outline-toggle {
  box-sizing: border-box;
  height: 28px;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 0 8px;
  border: none;
  border-radius: 8px;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #b8b8b8);
  font: inherit;
  font-size: 12px;
  line-height: 18px;
  cursor: pointer;
}
.outline-toggle:hover {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
  color: var(--dsw-alias-label-primary, #e8e8e8);
}
.outline-toggle[aria-pressed="true"] {
  background: var(--dsw-alias-interactive-bg-hover, #303030);
  color: var(--dsw-alias-brand-primary, #4f8cff);
}
.outline-settings-card {
  box-sizing: border-box;
  border: 1px solid var(--dsw-alias-border-l2, #555);
  border-radius: 8px;
  background: var(--dsw-alias-bg-layer-2, #242424);
  padding: 14px;
}
.outline-settings-card h3 {
  margin: 0 0 4px;
  font-size: 14px;
  line-height: 20px;
  color: var(--dsw-alias-label-primary, #e8e8e8);
}
.outline-settings-card p {
  margin: 0 0 12px;
  font-size: 12px;
  line-height: 18px;
  color: var(--dsw-alias-label-tertiary, #999);
}
.outline-settings-field {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: 10px;
  margin-bottom: 12px;
}
.outline-settings-field label {
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
  line-height: 18px;
  color: var(--dsw-alias-label-secondary, #b8b8b8);
}
.outline-settings-input,
.outline-settings-number {
  box-sizing: border-box;
  width: 100%;
  height: 32px;
  padding: 0 8px;
  border: 1px solid var(--dsw-alias-border-l2, #555);
  border-radius: 8px;
  background: var(--dsw-alias-bg-layer-1, #1f1f1f);
  color: var(--dsw-alias-label-primary, #e8e8e8);
  font: inherit;
  font-size: 13px;
  line-height: 18px;
}
.outline-settings-toggle {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
  font-size: 13px;
  line-height: 18px;
  color: var(--dsw-alias-label-primary, #e8e8e8);
}
.outline-settings-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}
.outline-settings-save,
.outline-settings-reset {
  height: 30px;
  padding: 0 10px;
  border-radius: 8px;
  font: inherit;
  font-size: 12px;
  line-height: 18px;
  cursor: pointer;
}
.outline-settings-save {
  border: 1px solid var(--dsw-alias-brand-primary, #4f8cff);
  background: var(--dsw-alias-brand-primary, #4f8cff);
  color: #fff;
}
.outline-settings-save:disabled {
  opacity: 0.5;
  cursor: default;
}
.outline-settings-reset {
  border: 1px solid var(--dsw-alias-border-l2, #555);
  background: transparent;
  color: var(--dsw-alias-label-secondary, #b8b8b8);
}
.outline-settings-status {
  margin-left: auto;
  font-size: 12px;
  line-height: 18px;
  color: var(--dsw-alias-state-success-primary, #30a46c);
}
.outline-settings-header {
  box-sizing: border-box;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 0;
  border: none;
  background: transparent;
  color: var(--dsw-alias-label-primary, #e8e8e8);
  cursor: pointer;
  text-align: left;
}
.outline-settings-head-text {
  min-width: 0;
}
.outline-settings-chevron {
  flex: none;
  color: var(--dsw-alias-label-tertiary, #999);
  transition: transform 120ms ease;
}
.outline-settings-chevron-open {
  transform: rotate(180deg);
}
.outline-settings-body {
  margin-top: 12px;
}
.outline-pcard-card {
  list-style: none;
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 12px;
  background: var(--dsw-alias-bg-layer-3);
  transition: border-color 0.16s, background 0.16s;
}
.outline-pcard-card:hover {
  border-color: var(--dsw-alias-label-dimmed);
}
.outline-pcard-cardOpen {
  background: var(--dsw-alias-bg-layer-2);
  border-color: var(--dsw-alias-label-dimmed);
}
.outline-pcard-header {
  width: 100%;
  appearance: none;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: left;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 16px;
  border-radius: 12px;
}
.outline-pcard-header:focus-visible {
  outline: 2px solid var(--dsw-alias-brand-primary);
  outline-offset: -2px;
}
.outline-pcard-headText {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.outline-pcard-name {
  font-size: 15px;
  font-weight: 600;
  line-height: 1.4;
  color: var(--dsw-alias-label-primary);
}
.outline-pcard-description {
  font-size: 13px;
  line-height: 1.5;
  color: var(--dsw-alias-label-tertiary);
}
.outline-pcard-chevron {
  flex: none;
  color: var(--dsw-alias-label-tertiary);
  transition: transform 0.16s;
}
.outline-pcard-chevronOpen {
  transform: rotate(180deg);
}
.outline-pcard-body {
  border-top: 1px solid var(--dsw-alias-border-l2);
  margin: 0 16px;
  padding-bottom: 8px;
}
.outline-pcard-footer {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 8px;
  padding: 12px 0 4px;
  border-top: 1px solid var(--dsw-alias-border-l2);
}
.outline-pcard-discard,
.outline-pcard-save {
  appearance: none;
  border: 1px solid transparent;
  border-radius: 8px;
  padding: 5px 14px;
  font: inherit;
  font-size: 13px;
  line-height: 1.5;
  cursor: pointer;
}
.outline-pcard-discard {
  border-color: var(--dsw-alias-border-l2);
  background: none;
  color: var(--dsw-alias-label-secondary);
}
.outline-pcard-discard:hover:not(:disabled) {
  color: var(--dsw-alias-label-primary);
  border-color: var(--dsw-alias-label-dimmed);
}
.outline-pcard-save {
  background: var(--dsw-alias-label-primary);
  color: var(--dsw-alias-bg-layer-3);
}
.outline-pcard-discard:disabled,
.outline-pcard-save:disabled {
  opacity: 0.4;
  cursor: default;
}
.outline-pfield-field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 12px 0;
}
.outline-pfield-field + .outline-pfield-field {
  border-top: 1px solid var(--dsw-alias-border-l2);
}
.outline-pfield-head {
  display: flex;
  align-items: center;
  gap: 8px;
}
.outline-pfield-label {
  flex: 1;
  min-width: 0;
  font-size: 13px;
  font-weight: 500;
  line-height: 1.5;
  color: var(--dsw-alias-label-primary);
}
.outline-pfield-input,
.outline-pfield-select {
  height: 34px;
  padding: 0 12px;
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 8px;
  background: var(--dsw-alias-bg-layer-3);
  font: inherit;
  font-size: 13px;
  line-height: 1.5;
  color: var(--dsw-alias-label-primary);
}
.outline-pfield-input:focus-visible,
.outline-pfield-select:focus-visible {
  outline: none;
  border-color: var(--dsw-alias-brand-primary);
}
.outline-pfield-select {
  appearance: none;
}
.outline-pfield-toggle {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 0;
  font-size: 13px;
  line-height: 1.5;
  color: var(--dsw-alias-label-primary);
}
.outline-pcard-status {
  margin-right: auto;
  font-size: 12px;
  line-height: 1.5;
  color: var(--dsw-alias-state-success-primary);
}
`

    const TITLE_CACHE_KEY = 'dsh-conversation-outline-titles:v1'
    const OUTLINE_SETTINGS_KEY = 'dsh-conversation-outline-settings:v1'
    const OUTLINE_TAB_ID = 'conversation-outline'
    const DEFAULT_OUTLINE_SETTINGS = {
      model: '',
      reasoningEffort: '',
      maxConcurrency: 3,
      timeoutSeconds: 60,
      maxRetries: 2,
      disabled: false,
    }

    const normalizeOutlineSettings = (raw, base = DEFAULT_OUTLINE_SETTINGS) => {
      const value = {
        model: typeof base.model === 'string' ? base.model : '',
        reasoningEffort: typeof base.reasoningEffort === 'string' ? base.reasoningEffort : '',
        maxConcurrency: Number.isFinite(Number(base.maxConcurrency)) && Number(base.maxConcurrency) > 0
          ? Math.min(8, Math.round(Number(base.maxConcurrency)))
          : 3,
        timeoutSeconds: Number.isFinite(Number(base.timeoutSeconds)) && Number(base.timeoutSeconds) >= 5
          ? Math.min(300, Math.round(Number(base.timeoutSeconds)))
          : 60,
        maxRetries: Number.isFinite(Number(base.maxRetries)) && Number(base.maxRetries) >= 0
          ? Math.min(5, Math.round(Number(base.maxRetries)))
          : 2,
        disabled: base.disabled === true,
      }
      if (raw === null || typeof raw !== 'object') return value
      if (typeof raw.model === 'string') value.model = raw.model
      if (typeof raw.reasoningEffort === 'string') value.reasoningEffort = raw.reasoningEffort
      const max = Number(raw.maxConcurrency)
      if (Number.isFinite(max) && max > 0) value.maxConcurrency = Math.min(8, Math.round(max))
      const timeout = Number(raw.timeoutSeconds)
      if (Number.isFinite(timeout) && timeout >= 5) value.timeoutSeconds = Math.min(300, Math.round(timeout))
      const retries = Number(raw.maxRetries)
      if (Number.isFinite(retries) && retries >= 0) value.maxRetries = Math.min(5, Math.round(retries))
      if (raw.disabled === true) value.disabled = true
      return value
    }

    const readOutlineSettings = (store) => {
      let value = { ...DEFAULT_OUTLINE_SETTINGS }
      try {
        if (typeof localStorage !== 'undefined') {
          const raw = localStorage.getItem(OUTLINE_SETTINGS_KEY)
          if (raw !== null) {
            const parsed = JSON.parse(raw)
            if (parsed !== null && typeof parsed === 'object') value = normalizeOutlineSettings(parsed, value)
          }
        }
      } catch {
        // localStorage can be unavailable in restricted browser contexts.
      }
      if (store !== undefined && store !== null && typeof store.getPrefs === 'function') {
        const prefs = store.getPrefs()
        const blob = prefs !== null && typeof prefs === 'object'
          && prefs.pluginSettings !== null && typeof prefs.pluginSettings === 'object'
          ? prefs.pluginSettings[OUTLINE_TAB_ID]
          : undefined
        if (blob !== null && blob !== undefined) value = normalizeOutlineSettings(blob, value)
      }
      return value
    }

    const persistOutlineSettings = (settings) => {
      try {
        if (typeof localStorage !== 'undefined') {
          localStorage.setItem(OUTLINE_SETTINGS_KEY, JSON.stringify(settings))
        }
      } catch {
        // localStorage can be unavailable in restricted browser contexts.
      }
    }

    const listeners = new Set()
    let panelState = { open: false, revision: 0 }
    let outlineRequestId = 0
    let sessionsService = null
    let layoutService = null

    const fetchJson = async (path, params, timeoutMs) => {
      const url = new URL(path, window.location.origin)
      for (const [key, value] of Object.entries(params !== null && typeof params === 'object' ? params : {})) {
        url.searchParams.set(key, String(value))
      }
      const controller = typeof AbortController !== 'undefined' ? new AbortController() : null
      let timer = undefined
      if (controller !== null && Number.isFinite(Number(timeoutMs)) && Number(timeoutMs) > 0) {
        timer = setTimeout(() => controller.abort(), Number(timeoutMs))
      }
      try {
        const response = await fetch(url.toString(), {
          headers: { accept: 'application/json' },
          ...(controller !== null ? { signal: controller.signal } : {}),
        })
        const data = await response.json()
        if (!response.ok || data === null || typeof data !== 'object' || data.ok !== true) {
          const message = data !== null && typeof data === 'object' && typeof data.error === 'string'
            ? data.error
            : `HTTP ${response.status}`
          throw new Error(message)
        }
        return data
      } finally {
        if (timer !== undefined) clearTimeout(timer)
      }
    }

    const fetchOutline = (sessionId) => fetchJson('/dsh-outline/snapshot', { sessionId })
    const fetchTitle = (sessionId, turn, settings) => {
      const params = { sessionId, turn }
      let timeoutSeconds = 60
      let maxRetries = 2
      if (settings !== null && typeof settings === 'object') {
        if (settings.model !== '') params.model = settings.model
        if (settings.reasoningEffort !== '') params.reasoningEffort = settings.reasoningEffort
        if (Number.isFinite(Number(settings.timeoutSeconds)) && Number(settings.timeoutSeconds) >= 5) {
          timeoutSeconds = Number(settings.timeoutSeconds)
          params.timeoutSeconds = timeoutSeconds
        }
        if (Number.isFinite(Number(settings.maxRetries)) && Number(settings.maxRetries) >= 0) {
          maxRetries = Number(settings.maxRetries)
          params.maxRetries = maxRetries
        }
      }
      // Client-side upper bound: cover every host attempt (per-attempt timeout)
      // plus the retry backoff, plus a margin. A hung HTTP request can never
      // leave the turn stuck in "生成标题中..." forever.
      const budgetMs = Math.round((timeoutSeconds * (maxRetries + 1) + 15 + maxRetries * 3) * 1000)
      return fetchJson('/dsh-outline/title', params, budgetMs)
    }

    const saveOutlineSettings = async (settings) => {
      const response = await fetch('/dsh-outline/save-settings', {
        method: 'POST',
        headers: { 'content-type': 'application/json', accept: 'application/json' },
        body: JSON.stringify(settings),
      })
      const data = await response.json()
      if (!response.ok || data === null || typeof data !== 'object' || data.ok !== true) {
        throw new Error(data !== null && typeof data === 'object' && typeof data.error === 'string'
          ? data.error
          : `HTTP ${response.status}`)
      }
      return data
    }

    const readTitleLocalCache = () => {
      try {
        if (typeof localStorage === 'undefined') return {}
        const raw = localStorage.getItem(TITLE_CACHE_KEY)
        if (raw === null) return {}
        const parsed = JSON.parse(raw)
        return parsed !== null && typeof parsed === 'object' ? parsed : {}
      } catch {
        return {}
      }
    }

    const titleLocalCache = readTitleLocalCache()

    const persistTitleLocalCache = () => {
      try {
        if (typeof localStorage !== 'undefined') {
          localStorage.setItem(TITLE_CACHE_KEY, JSON.stringify(titleLocalCache))
        }
      } catch {
        // localStorage can be unavailable in restricted browser contexts.
      }
    }

    const titleCacheKeyFor = (entry, sessionIdRef) => (
      typeof entry.titleKey === 'string' && entry.titleKey.length > 0
        ? entry.titleKey
        : `${sessionIdRef}:${entry.turn}`
    )

    const applyLocalTitles = (timeline, sessionIdRef) => timeline.map((entry) => {
      if (entry.kind !== 'turn') return entry
      const cached = titleLocalCache[titleCacheKeyFor(entry, sessionIdRef)]
      if (cached !== undefined && typeof cached.title === 'string' && cached.title.length > 0) {
        return { ...entry, title: cached.title, titleStatus: 'ready' }
      }
      return entry
    })

    const subscribePanel = (listener) => {
      listeners.add(listener)
      return () => { listeners.delete(listener) }
    }

    const getPanelSnapshot = () => panelState

    const notifyPanel = () => {
      panelState = { ...panelState, revision: panelState.revision + 1 }
      for (const listener of Array.from(listeners)) listener()
    }

    const togglePanel = () => {
      const nextOpen = !panelState.open
      if (layoutService !== null) {
        if (nextOpen) layoutService.openDetails()
        else layoutService.closeDetails()
      }
      panelState = { ...panelState, open: nextOpen, revision: panelState.revision + 1 }
      notifyPanel()
    }

    const closePanel = () => {
      if (panelState.open) {
        if (layoutService !== null) layoutService.closeDetails()
        panelState = { ...panelState, open: false, revision: panelState.revision + 1 }
        notifyPanel()
      }
    }

    const usePanelState = () => {
      const [snapshot, setSnapshot] = React.useState(getPanelSnapshot)
      React.useEffect(() => subscribePanel(() => setSnapshot(getPanelSnapshot())), [])
      return snapshot
    }

    const emptyOutline = () => ({ timeline: [] })

    const findNodeForSeq = (snapshot, seq) => {
      const store = snapshot.chat !== null && typeof snapshot.chat === 'object'
        ? snapshot.chat.nodes
        : undefined
      if (store === undefined || typeof store.values !== 'function') return null
      const nodes = store.values()
      let exact = null
      let next = null
      let prev = null
      for (const node of nodes) {
        if (node === null || typeof node !== 'object' || node.visibility === 'hidden') continue
        const anchor = node.anchorSeq
        if (typeof anchor !== 'number') continue
        if (Math.abs(anchor - seq) < 0.5) {
          if (exact === null) exact = node
          continue
        }
        if (anchor >= seq && (next === null || anchor < next.anchorSeq)) next = node
        if (anchor <= seq && (prev === null || anchor > prev.anchorSeq)) prev = node
      }
      return exact !== null ? exact : next !== null ? next : prev
    }

    const hasSeqInWindow = (snapshot, seq) => {
      const store = snapshot.chat !== null && typeof snapshot.chat === 'object'
        ? snapshot.chat.nodes
        : undefined
      if (store === undefined || typeof store.values !== 'function') return false
      let min = Number.POSITIVE_INFINITY
      let max = Number.NEGATIVE_INFINITY
      for (const node of store.values()) {
        if (node === null || typeof node !== 'object' || typeof node.anchorSeq !== 'number') continue
        if (node.anchorSeq < min) min = node.anchorSeq
        if (node.anchorSeq > max) max = node.anchorSeq
      }
      return min <= seq && seq <= max
    }

    const findAnchorRow = (key) => {
      const rows = document.querySelectorAll('[data-chat-anchor-key]')
      for (const row of rows) {
        if (row.dataset.chatAnchorKey === key) return row
      }
      return null
    }

    const isTrajectoryViewActive = () => (
      document.querySelector('[data-trajectory-scroll]') !== null
    )

    const trajectoryRecordIdFor = (item, snapshot) => {
      const views = snapshot !== null && typeof snapshot === 'object' && snapshot.views !== null
        && typeof snapshot.views === 'object'
        ? snapshot.views
        : undefined
      const trajectory = views !== undefined && typeof views.get === 'function'
        ? views.get('trajectory')
        : undefined
      if (trajectory === undefined || trajectory === null || typeof trajectory !== 'object') return null
      const nodes = Array.isArray(trajectory.eventNodes) ? trajectory.eventNodes : []
      const requests = Array.isArray(trajectory.requests) ? trajectory.requests : []
      const nodeWithKind = (kinds, seq) => {
        const matches = nodes.filter((node) => node !== null && typeof node === 'object'
          && kinds.includes(node.kind) && typeof node.seq === 'number')
        return matches.find((node) => node.seq === seq)
          ?? matches.filter((node) => node.seq >= seq).sort((left, right) => left.seq - right.seq)[0]
      }

      if (item.kind === 'user') {
        const target = nodeWithKind(['user', 'steering', 'context'], item.seq)
        if (target === undefined || typeof target.seq !== 'number') return null
        const rowKind = target.kind === 'steering' ? 'user' : target.kind
        return `${rowKind}\u0000seq\u0000${target.seq}`
      }
      if (item.kind === 'assistant') {
        const target = nodeWithKind(['assistant'], item.seq)
        if (target === undefined || typeof target.turn !== 'number' || typeof target.step !== 'number') return null
        return `assistant\u0000${target.turn}\u0000${target.step}`
      }
      if (item.kind === 'tool' || item.kind === 'error') {
        if (typeof item.callId === 'string' && item.callId.length > 0) return `tool\u0000call\u0000${item.callId}`
        const target = nodeWithKind(['tool-result'], item.seq)
        if (target === undefined || typeof target.callId !== 'string') return null
        return `tool\u0000call\u0000${target.callId}`
      }
      if (item.kind === 'compaction') {
        const compactions = requests.filter((request) => request !== null && typeof request === 'object'
          && request.purpose === 'compaction' && typeof request.startSeq === 'number')
        const target = compactions.find((request) => request.resultSeq === item.seq)
          ?? compactions.filter((request) => (request.resultSeq ?? -1) >= item.seq)
            .sort((left, right) => left.resultSeq - right.resultSeq)[0]
        if (target === undefined) return null
        return `compacted\u0000seq\u0000${target.startSeq}`
      }
      return null
    }

    const trajectoryOrderIndexFor = (item, snapshot) => {
      const recordId = trajectoryRecordIdFor(item, snapshot)
      if (recordId === null) return null
      const views = snapshot !== null && typeof snapshot === 'object' && snapshot.views !== null
        && typeof snapshot.views === 'object'
        ? snapshot.views
        : undefined
      const trajectory = views !== undefined && typeof views.get === 'function'
        ? views.get('trajectory')
        : undefined
      if (trajectory === undefined || trajectory === null || typeof trajectory !== 'object') return null
      const nodes = Array.isArray(trajectory.eventNodes) ? trajectory.eventNodes : []
      const requests = Array.isArray(trajectory.requests) ? trajectory.requests : []
      const entries = []
      for (const node of nodes) {
        if (node === null || typeof node !== 'object' || typeof node.seq !== 'number') continue
        if (node.kind === 'user' || node.kind === 'steering' || node.kind === 'context') {
          const rowKind = node.kind === 'steering' ? 'user' : node.kind
          entries.push({ seq: node.seq, id: `${rowKind}\u0000seq\u0000${node.seq}` })
        } else if (node.kind === 'assistant' && typeof node.turn === 'number' && typeof node.step === 'number') {
          entries.push({ seq: node.seq, id: `assistant\u0000${node.turn}\u0000${node.step}` })
        } else if (node.kind === 'tool-result' && typeof node.callId === 'string') {
          entries.push({ seq: node.seq, id: `tool\u0000call\u0000${node.callId}` })
        }
      }
      for (const request of requests) {
        if (request === null || typeof request !== 'object' || request.purpose !== 'compaction') continue
        if (typeof request.startSeq !== 'number') continue
        entries.push({ seq: request.startSeq, id: `compacted\u0000seq\u0000${request.startSeq}` })
      }
      entries.sort((left, right) => left.seq - right.seq)
      const index = entries.findIndex((entry) => entry.id === recordId)
      return index === -1 || entries.length === 0 ? null : { index, count: entries.length }
    }

    const findTrajectoryRowByKey = (key) => {
      const rows = document.querySelectorAll('tr[data-trajectory-row-key]')
      for (const row of rows) {
        if (row.dataset.trajectoryRowKey === key) return row
      }
      return null
    }

    const findTrajectoryRowFor = (item, key) => {
      const exact = findTrajectoryRowByKey(key)
      if (exact !== null) return exact
      const rows = document.querySelectorAll('tr[data-trajectory-row-key]')
      for (const row of rows) {
        let id = ''
        try {
          id = decodeURIComponent(row.dataset.trajectoryRowKey || '')
        } catch {
          continue
        }
        if (item.kind === 'user' && id.includes(`\u0000seq\u0000${item.seq}`)) return row
        if (item.kind === 'assistant'
          && (id.includes(`\u0000seq\u0000${item.seq}`)
            || (typeof item.turn === 'number' && typeof item.step === 'number'
              && id === `assistant\u0000${item.turn}\u0000${item.step}`))) return row
        if ((item.kind === 'tool' || item.kind === 'error')
          && typeof item.callId === 'string' && id.includes(`\u0000call\u0000${item.callId}`)) return row
      }
      return null
    }

    const expandTrajectorySummaries = () => {
      const rows = document.querySelectorAll('tr[data-collapsed-summary]')
      for (const row of rows) {
        if (typeof row.click === 'function') row.click()
      }
    }

    const waitForNextFrame = () => new Promise((resolve) => {
      if (typeof requestAnimationFrame === 'function') requestAnimationFrame(() => resolve())
      else resolve()
    })

    const iconPath = (d, size = 14) => React.createElement('svg', {
      viewBox: '0 0 16 16',
      width: String(size),
      height: String(size),
      'aria-hidden': true,
    }, React.createElement('path', {
      d,
      fill: 'none',
      stroke: 'currentColor',
      strokeWidth: '1.5',
      strokeLinecap: 'round',
      strokeLinejoin: 'round',
    }))

    const chevronPath = 'M6 4l4 4-4 4'

    // Exact glyph copies of the DSH trajectory's kindTag icons so the outline
    // and trajectory stay pixel-consistent: Information / Wrench / Compacted are
    // textually identical to dsh-client-ui-trajectory; user/assistant reuse the
    // same primitives (IconUserOutline16 / IconSparkle16) with a filled fallback
    // when the primitive is unavailable.
    const iconUserFallback = () => React.createElement('svg', {
      viewBox: '0 0 16 16',
      width: '13',
      height: '13',
      fill: 'currentColor',
      'aria-hidden': true,
    }, React.createElement('path', { d: 'M11.0307 5.46369C11.0305 3.78995 9.6734 2.43357 7.99961 2.43357C6.32601 2.43379 4.96972 3.79009 4.96949 5.46369C4.96949 7.13748 6.32587 8.49455 7.99961 8.49477C9.67354 8.49477 11.0307 7.13762 11.0307 5.46369ZM12.3163 5.46369C12.3163 7.84777 10.3837 9.78042 7.99961 9.78042C5.61572 9.7802 3.68288 7.84763 3.68288 5.46369C3.6831 3.07993 5.61586 1.14718 7.99961 1.14695C10.3836 1.14695 12.3161 3.0798 12.3163 5.46369Z' }))
    const iconSparkleFallback = () => React.createElement('svg', {
      viewBox: '0 0 16 16',
      width: '13',
      height: '13',
      fill: 'currentColor',
      'aria-hidden': true,
    }, React.createElement('path', { d: 'M6.1 3.1Q6.6 7.8 11.3 8.3Q6.6 8.8 6.1 13.5Q5.6 8.8 0.9 8.3Q5.6 7.8 6.1 3.1Z' }),
    React.createElement('path', { d: 'M11.9 1Q12.2 3.7 14.9 4Q12.2 4.3 11.9 7Q11.6 4.3 8.9 4Q11.6 3.7 11.9 1Z' }),
    React.createElement('path', { d: 'M12.5 9.4Q12.7 11.4 14.7 11.6Q12.7 11.8 12.5 13.8Q12.3 11.8 10.3 11.6Q12.3 11.4 12.5 9.4Z' }))
    const IconInformationExact = () => React.createElement('svg', {
      width: '14',
      height: '14',
      viewBox: '0 0 16 16',
      fill: 'none',
      stroke: 'currentColor',
      strokeWidth: '1.4',
      strokeLinecap: 'round',
      'data-role-icon': 'information',
      'aria-hidden': true,
    }, React.createElement('circle', { cx: '8', cy: '8', r: '6.7' }),
    React.createElement('circle', { cx: '8', cy: '5.5', r: '.85', fill: 'currentColor', stroke: 'none' }),
    React.createElement('path', { d: 'M8 7.75v3.4', strokeWidth: '1.8' }))
    const IconWrenchExact = () => React.createElement('svg', {
      width: '13',
      height: '13',
      viewBox: '0 0 16 16',
      fill: 'none',
      stroke: 'currentColor',
      strokeWidth: '1.5',
      strokeLinecap: 'round',
      strokeLinejoin: 'round',
      'data-role-icon': 'wrench',
      'aria-hidden': true,
    }, React.createElement('path', { d: 'M14 3.3a3.8 3.8 0 0 1-4.8 4.8l-5.1 5.1a1.6 1.6 0 1 1-2.3-2.3l5.1-5.1A3.8 3.8 0 0 1 11.7 1l-2.3 2.3 2.3 2.3L14 3.3Z' }))
    const IconCompactedExact = () => React.createElement('svg', {
      width: '13',
      height: '13',
      viewBox: '0 0 16 16',
      fill: 'none',
      stroke: 'currentColor',
      strokeWidth: '1.5',
      strokeLinecap: 'round',
      strokeLinejoin: 'round',
      'data-role-icon': 'compacted',
      'aria-hidden': true,
    }, React.createElement('path', { d: 'm2.5 2.5 3.75 3.75M3 6.25h3.25V3' }),
    React.createElement('path', { d: 'm13.5 2.5-3.75 3.75M13 6.25H9.75V3' }),
    React.createElement('path', { d: 'm2.5 13.5 3.75-3.75M3 9.75h3.25V13' }),
    React.createElement('path', { d: 'm13.5 13.5-3.75-3.75M13 9.75H9.75V13' }))
    const KIND_ICON = {
      // user & assistant reuse the exact trajectory primitives (filled), with
      // the same fallback glyphs when the primitive is unavailable.
      user: () => NativeIconUser !== null
        ? React.createElement(NativeIconUser, { size: 13 })
        : iconUserFallback(),
      context: () => React.createElement(IconInformationExact, null),
      assistant: () => NativeIconSparkle !== null
        ? React.createElement(NativeIconSparkle, { size: 13 })
        : iconSparkleFallback(),
      // Trajectory renders failed tool calls as kind "tool" (wrench); the
      // outline's error rows mirror that same wrench glyph.
      tool: () => React.createElement(IconWrenchExact, null),
      error: () => React.createElement(IconWrenchExact, null),
      compaction: () => React.createElement(IconCompactedExact, null),
    }

    const kindIconFor = (item) => {
      if (item === null || typeof item !== 'object') return null
      const kind = item.kind
      if (kind === 'user' && (item.label === '上下文' || item.label === '消息')) {
        if (typeof KIND_ICON.context === 'function') return KIND_ICON.context()
        return null
      }
      if (typeof KIND_ICON[kind] === 'function') return KIND_ICON[kind]()
      return null
    }

    function OutlineToggle() {
      const snapshot = usePanelState()
      return React.createElement('button', {
        type: 'button',
        className: 'outline-toggle',
        'aria-label': '对话大纲',
        'aria-pressed': snapshot.open,
        title: '对话大纲',
        onClick: togglePanel,
      }, iconPath('M3 3.5h10M3 8h10M3 12.5h6'), React.createElement('span', null, '大纲'))
    }

    function KindTag({ item, kindClass }) {
      const icon = typeof kindIconFor === 'function' ? kindIconFor(item) : null
      const label = item !== null && typeof item === 'object' ? item.label : ''
      const iconEl = icon === null ? null : React.createElement('span', {
        className: 'outline-row-kind-icon',
        'aria-hidden': true,
      }, icon)
      const iconWithTooltip = icon !== null && NativeTooltip !== null
        ? React.createElement(NativeTooltip, { label, side: 'right' }, iconEl)
        : iconEl
      return React.createElement('span', { className: `outline-row-kind${kindClass}` },
        iconWithTooltip,
        React.createElement('span', { className: 'outline-row-kind-label' }, label))
    }

    function OutlineRow({ item, active, jumping, onClick }) {
      const kindClass = item.kind === 'user'
        ? item.label === '上下文' || item.label === '消息' ? ' outline-row-kind-context' : ' outline-row-kind-user'
        : item.kind === 'assistant' ? ' outline-row-kind-assistant'
          : item.kind === 'tool' ? ' outline-row-kind-tool'
            : item.kind === 'error' ? ' outline-row-kind-error'
              : item.kind === 'compaction' ? ' outline-row-kind-compaction' : ''
      return React.createElement('button', {
        type: 'button',
        className: `outline-row${active ? ' outline-row-active' : ''}`,
        disabled: jumping === item.seq || item.kind === 'notice',
        onClick: () => { onClick(item) },
      },
      React.createElement(KindTag, { item, kindClass }),
      React.createElement('span', { className: 'outline-row-preview' }, item.preview))
    }

    function ToolGroup({ group, expanded, activeSeq, jumping, onToggle, onJump }) {
      return React.createElement('div', { className: 'outline-tool-group' },
        React.createElement('button', {
          type: 'button',
          className: 'outline-tool-group-head',
          'aria-expanded': expanded,
          onClick: onToggle,
        },
        React.createElement('span', { className: `outline-tool-group-chevron${expanded ? ' outline-tool-group-chevron-open' : ''}` },
          iconPath(chevronPath)),
        React.createElement(KindTag, { item: { kind: 'tool', label: '工具' }, kindClass: ' outline-row-kind-tool' }),
        React.createElement('span', { className: 'outline-row-preview' }, `${group.count} 次调用`)),
        expanded
          ? React.createElement('div', { className: 'outline-tool-group-items' },
              group.items.map((item, index) => React.createElement(OutlineRow, {
                key: `${item.id}:${index}`,
                item,
                active: activeSeq === item.seq,
                jumping,
                onClick: (target) => { onJump(target) },
              })))
          : null)
    }

    function OutlinePanel(props) {
      const ctx = props !== null && typeof props === 'object' ? props.ctx : undefined
      const store = props !== null && typeof props === 'object' ? props.store : undefined
      const scope = props !== null && typeof props === 'object' && props.scope !== null && typeof props.scope === 'object'
        ? props.scope
        : {}
      const tab = props !== null && typeof props === 'object' ? props.tab : undefined
      const active = props !== null && typeof props === 'object' && props.visible === true
      const sessionId = typeof scope.sessionId === 'string' && scope.sessionId.length > 0 ? scope.sessionId : null
      const storeSnapshot = React.useSyncExternalStore(
        React.useCallback((listener) => (
          store !== undefined && store !== null && typeof store.subscribe === 'function'
            ? store.subscribe(listener)
            : () => {}
        ), [store]),
        React.useCallback(() => (
          store !== undefined && store !== null && typeof store.getSnapshot === 'function'
            ? store.getSnapshot()
            : null
        ), [store]),
      )
      void storeSnapshot
      const outlineSettings = readOutlineSettings(store)
      const outlineSettingsRef = React.useRef(outlineSettings)
      const [status, setStatus] = React.useState('idle')
      const [outline, setOutline] = React.useState(emptyOutline)
      const outlineRef = React.useRef(emptyOutline())
      const [refreshing, setRefreshing] = React.useState(false)
      const [error, setError] = React.useState(null)
      const [jumping, setJumping] = React.useState(null)
      const [jumpError, setJumpError] = React.useState(null)
      const [activeSeq, setActiveSeq] = React.useState(null)
      const [collapsedTurns, setCollapsedTurns] = React.useState(null)
      const [expandedToolGroups, setExpandedToolGroups] = React.useState(new Set())
      const requestedTurns = React.useRef(new Set())
      const runningRef = React.useRef(false)

      React.useEffect(() => { outlineRef.current = outline }, [outline])
      React.useEffect(() => { outlineSettingsRef.current = outlineSettings }, [outlineSettings])

      React.useEffect(() => {
        setOutline(emptyOutline())
        outlineRef.current = emptyOutline()
        setStatus('idle')
        setError(null)
        setRefreshing(false)
        runningRef.current = false
      }, [sessionId])

      const updateTurnTitle = (turn, patch) => {
        setOutline((current) => ({
          ...current,
          timeline: current.timeline.map((entry) => {
            if (entry.kind !== 'turn' || entry.turn !== turn) return entry
            return { ...entry, ...patch }
          }),
        }))
      }

      const queueTitleGeneration = React.useCallback((timeline, sessionIdRef) => {
        // Title generation is fully parallel with the session: an ended turn
        // (its turn/end event exists) generates immediately even while the
        // agent is still working on a later turn. Only the still-OPEN current
        // turn has no final assistant content yet, so its title is deferred
        // until the running-false subscription reloads the outline.
        const turns = timeline.filter((entry) => entry.kind === 'turn' && entry.titleStatus === 'queued'
          && (entry.endSeq !== null && entry.endSeq !== undefined || !runningRef.current))
        if (turns.length === 0) return
        const settings = readOutlineSettings(store)
        if (settings.disabled) {
          for (const entry of turns) updateTurnTitle(entry.turn, { titleStatus: 'disabled' })
          return
        }
        let index = 0
        const worker = async () => {
          while (index < turns.length) {
            const entry = turns[index]
            index += 1
            const requestKey = `${sessionIdRef}:${entry.turn}`
            const localKey = titleCacheKeyFor(entry, sessionIdRef)
            if (requestedTurns.current.has(requestKey)) continue
            const local = titleLocalCache[localKey]
            if (local !== undefined && typeof local.title === 'string' && local.title.length > 0) {
              updateTurnTitle(entry.turn, { title: local.title, titleStatus: 'ready' })
              continue
            }
            requestedTurns.current.add(requestKey)
            try {
              const result = await fetchTitle(sessionIdRef, entry.turn, outlineSettingsRef.current)
              if (result !== null && typeof result === 'object' && result.ok === true) {
                const cacheKey = typeof result.titleKey === 'string' && result.titleKey.length > 0
                  ? result.titleKey
                  : localKey
                titleLocalCache[cacheKey] = { title: result.title, savedAt: Date.now() }
                persistTitleLocalCache()
                updateTurnTitle(entry.turn, { title: result.title, titleStatus: 'ready', titleKey: cacheKey })
              } else {
                const message = result !== null && typeof result === 'object' && typeof result.error === 'string'
                  ? result.error
                  : '标题生成失败'
                requestedTurns.current.delete(requestKey)
                updateTurnTitle(entry.turn, { titleStatus: 'error', titleError: message })
              }
            } catch (reason) {
              requestedTurns.current.delete(requestKey)
              updateTurnTitle(entry.turn, { titleStatus: 'error', titleError: reason instanceof Error ? reason.message : String(reason) })
            }
          }
        }
        const workers = Array.from({ length: Math.min(Math.max(1, settings.maxConcurrency), turns.length) }, () => worker())
        void Promise.all(workers)
      }, [store])

      const loadOutline = React.useCallback(() => {
        if (typeof sessionId !== 'string' || sessionId.length === 0) {
          setStatus('idle')
          setOutline(emptyOutline())
          return
        }
        const requestId = ++outlineRequestId
        const hasExisting = outlineRef.current.timeline.length > 0
        setError(null)
        if (hasExisting) {
          setStatus('ready')
          setRefreshing(true)
        } else {
          setStatus('loading')
          setRefreshing(false)
        }
        fetchOutline(sessionId)
          .then((result) => {
            if (requestId !== outlineRequestId) return
            setRefreshing(false)
            if (result === null || typeof result !== 'object' || result.ok !== true) {
              const message = result !== null && typeof result === 'object' && typeof result.error === 'string'
                ? result.error
                : '无法读取会话大纲'
              setError(message)
              if (!hasExisting) setStatus('error')
              return
            }
            const next = result.outline
            const nextTimeline = next !== null && typeof next === 'object' && Array.isArray(next.timeline)
              ? applyLocalTitles(next.timeline, sessionId)
              : []
            outlineRef.current = { timeline: nextTimeline }
            setOutline({ timeline: nextTimeline })
            setStatus('ready')
            // Titles run fully in parallel with the session; queueTitleGeneration
            // itself defers only the still-open current turn.
            queueTitleGeneration(nextTimeline, sessionId)
          })
          .catch((reason) => {
            if (requestId !== outlineRequestId) return
            setRefreshing(false)
            setError(reason instanceof Error ? reason.message : String(reason))
            if (!hasExisting) setStatus('error')
          })
      }, [sessionId, queueTitleGeneration])

      React.useEffect(() => {
        if (!active) return undefined
        if (typeof sessionId !== 'string' || sessionId.length === 0) {
          setStatus('idle')
          return undefined
        }
        loadOutline()
        const service = sessionsService
        const binding = service !== null && typeof service.binding === 'function'
          ? service.binding(sessionId)
          : undefined
        const session = binding !== undefined && binding.session !== undefined ? binding.session : undefined
        if (session === undefined || typeof session.subscribe !== 'function' || typeof session.getSnapshot !== 'function') {
          return undefined
        }
        try {
          const initial = session.getSnapshot()
          runningRef.current = initial !== null && typeof initial === 'object' && initial.running === true
        } catch {
          // Ignore a snapshot read failure; the subscription below catches up.
        }
        return session.subscribe(() => {
          let snapshot
          try {
            snapshot = session.getSnapshot()
          } catch {
            return
          }
          if (snapshot !== null && typeof snapshot === 'object') {
            runningRef.current = snapshot.running === true
            if (snapshot.running === false) {
              loadOutline()
            }
          }
        })
      }, [active, sessionId, loadOutline])

      const jumpTo = React.useCallback(async (item) => {
        if (item === null || typeof item !== 'object' || typeof item.seq !== 'number') return
        setJumping(item.seq)
        setJumpError(null)
        try {
          const service = sessionsService
          const binding = service !== null && typeof service.binding === 'function'
            ? service.binding(sessionId)
            : undefined
          const session = binding !== undefined && binding.session !== undefined ? binding.session : undefined
          if (session === undefined || typeof session.loadOlder !== 'function' || typeof session.getSnapshot !== 'function') {
            setJumpError('当前会话不可用')
            return
          }
          let snapshot = session.getSnapshot()
          if (isTrajectoryViewActive()) {
            let recordId = trajectoryRecordIdFor(item, snapshot)
            let key = recordId === null ? null : encodeURIComponent(recordId)
            let row = key === null ? null : findTrajectoryRowFor(item, key)
            if (row === null && snapshot.hasMore === true) {
              let guard = 0
              while (snapshot.hasMore === true && guard < 200) {
                await session.loadOlder()
                snapshot = session.getSnapshot()
                guard += 1
              }
              recordId = trajectoryRecordIdFor(item, snapshot)
              key = recordId === null ? null : encodeURIComponent(recordId)
              row = key === null ? null : findTrajectoryRowFor(item, key)
            }
            if (key === null) {
              setJumpError('轨迹中找不到该事件')
              return
            }
            if (row === null) {
              expandTrajectorySummaries()
              await waitForNextFrame()
              row = findTrajectoryRowFor(item, key)
            }
            if (row === null) {
              const order = trajectoryOrderIndexFor(item, snapshot)
              const pane = document.querySelector('[data-trajectory-scroll]')
              if (order !== null && pane !== null) {
                const max = Math.max(0, pane.scrollHeight - pane.clientHeight)
                const ratio = order.index / Math.max(1, order.count)
                pane.scrollTop = Math.round(max * ratio)
                pane.dispatchEvent(new Event('scroll'))
                await waitForNextFrame()
                row = findTrajectoryRowFor(item, key)
              }
            }
            if (row === null) {
              setJumpError('目标行未在轨迹中渲染')
              return
            }
            row.scrollIntoView({ behavior: 'smooth', block: 'center' })
            setActiveSeq(item.seq)
            return
          }
          let guard = 0
          while (snapshot.hasMore === true && !hasSeqInWindow(snapshot, item.seq) && guard < 200) {
            await session.loadOlder()
            snapshot = session.getSnapshot()
            guard += 1
          }
          const node = findNodeForSeq(snapshot, item.seq)
          if (node === null) {
            setJumpError('无法定位该消息')
            return
          }
          const row = findAnchorRow(node.key)
          if (row === null) {
            setJumpError('目标不在当前聊天视图')
            return
          }
          row.scrollIntoView({ behavior: 'smooth', block: 'start' })
          setActiveSeq(item.seq)
        } catch (reason) {
          setJumpError(reason instanceof Error ? reason.message : String(reason))
        } finally {
          setJumping(null)
        }
      }, [sessionId])

      const toggleTurn = (turnId, allTurnIds) => {
        setCollapsedTurns((current) => {
          if (current === null) {
            const next = new Set(allTurnIds)
            next.delete(turnId)
            return next
          }
          const next = new Set(current)
          if (next.has(turnId)) next.delete(turnId)
          else next.add(turnId)
          return next
        })
      }

      const toggleToolGroup = (groupId) => {
        setExpandedToolGroups((current) => {
          const next = new Set(current)
          if (next.has(groupId)) next.delete(groupId)
          else next.add(groupId)
          return next
        })
      }

      if (!active) return null

      const renderItems = (items) => items.map((item, index) => {
        if (item.kind === 'tool-group') {
          return React.createElement(ToolGroup, {
            key: item.id,
            group: item,
            expanded: expandedToolGroups.has(item.id),
            activeSeq,
            jumping,
            onToggle: () => { toggleToolGroup(item.id) },
            onJump: (target) => { void jumpTo(target) },
          })
        }
        return React.createElement(OutlineRow, {
          key: `${item.id}:${index}`,
          item,
          active: activeSeq === item.seq,
          jumping,
          onClick: (target) => { void jumpTo(target) },
        })
      })

      const fallbackTitleFor = (entry) => {
        const first = Array.isArray(entry.items) ? entry.items[0] : undefined
        if (first !== undefined && typeof first === 'object') {
          if (first.kind === 'tool-group' && typeof first.count === 'number') {
            return `${first.count} 次调用`
          }
          if (typeof first.preview === 'string' && first.preview.length > 0) {
            return first.preview
          }
        }
        return `第 ${entry.turn} 轮`
      }

      const shortErrorOf = (text, max = 60) => {
        if (typeof text !== 'string' || text.length === 0) return '标题未生成'
        const oneLine = text.replace(/\s+/g, ' ').trim()
        return oneLine.length > max ? `${oneLine.slice(0, max - 1).trimEnd()}…` : oneLine
      }
      const renderTurn = (entry, allTurnIds) => {
        const collapsed = collapsedTurns === null || collapsedTurns.has(entry.id)
        const title = entry.titleStatus === 'ready' && typeof entry.title === 'string' && entry.title.length > 0
          ? entry.title
          : fallbackTitleFor(entry)
        const metaParts = []
        if (entry.titleStatus === 'queued') {
          const open = entry.endSeq === null || entry.endSeq === undefined
          metaParts.push(open && runningRef.current ? '等待本轮结束...' : '生成标题中...')
        }
        if (entry.titleStatus === 'error') metaParts.push(`未生成 · ${shortErrorOf(entry.titleError)}`)
        metaParts.push(`${entry.items.length} 项`)
        return React.createElement('section', { key: entry.id, className: `outline-turn-card${collapsed ? ' outline-turn-collapsed' : ''}` },
          React.createElement('button', {
            type: 'button',
            className: 'outline-turn-head',
            'aria-expanded': !collapsed,
            onClick: () => { toggleTurn(entry.id, allTurnIds) },
          },
          React.createElement('span', { className: `outline-turn-chevron${collapsed ? '' : ' outline-turn-chevron-open'}` },
            iconPath(chevronPath)),
          React.createElement('span', { className: 'outline-turn-title' }, title),
          React.createElement('span', { className: 'outline-turn-meta' }, metaParts.join(' · '))),
          collapsed ? null : React.createElement('div', { className: 'outline-turn-items' }, renderItems(entry.items)))
      }

      const timeline = Array.isArray(outline.timeline) ? outline.timeline : []
      const turnIds = timeline.filter((entry) => entry.kind === 'turn').map((entry) => entry.id)

      const hasTimeline = timeline.length > 0
      const outlineBody = status === 'loading'
        ? React.createElement('p', { className: 'outline-overlay-status' }, '正在生成大纲...')
        : status === 'error' && !hasTimeline
          ? React.createElement('div', null,
              React.createElement('p', { className: 'outline-overlay-error' }, error),
              React.createElement('div', { className: 'outline-overlay-tools' },
                React.createElement('button', { type: 'button', className: 'outline-overlay-secondary', onClick: loadOutline }, '刷新')))
          : !hasTimeline
            ? React.createElement('p', { className: 'outline-overlay-status' }, '会话暂无内容')
            : React.createElement('div', null,
                error === null ? null : React.createElement('p', { className: 'outline-overlay-error' }, error),
                ...timeline.map((entry) => entry.kind === 'turn'
                  ? renderTurn(entry, turnIds)
                  : React.createElement('div', { key: entry.item.id, className: 'outline-standalone-item' },
                      React.createElement(OutlineRow, {
                        item: entry.item,
                        active: activeSeq === entry.item.seq,
                        jumping,
                        onClick: (target) => { void jumpTo(target) },
                      }))),
                jumpError === null ? null : React.createElement('p', { className: 'outline-overlay-error' }, jumpError))

      return React.createElement('div', { className: 'outline-details-root', role: 'complementary', 'aria-label': '对话大纲' },
        React.createElement('div', { className: 'outline-overlay-header' },
          React.createElement('h2', { className: 'outline-overlay-title' }, '对话大纲'),
          React.createElement('button', {
            type: 'button',
            className: 'outline-overlay-icon-btn',
            'aria-label': '刷新大纲',
            title: '刷新大纲',
            disabled: status === 'loading' || refreshing,
            onClick: loadOutline,
          }, refreshing || status === 'loading'
            ? React.createElement('span', { className: 'outline-refresh-spin' },
                iconPath('M13.5 8a5.5 5.5 0 1 1-1.6-3.9M13.5 2.5v3h-3'))
            : iconPath('M13.5 8a5.5 5.5 0 1 1-1.6-3.9M13.5 2.5v3h-3')),
          React.createElement('button', {
            type: 'button',
            className: 'outline-overlay-icon-btn',
            'aria-label': '关闭大纲',
            title: '关闭大纲',
            onClick: () => {
              const service = ctx !== undefined && typeof ctx.get === 'function' ? ctx.get('betterSidebar') : undefined
              if (service !== undefined && tab !== null && typeof tab === 'object'
                && typeof tab.id === 'string' && scope !== null && typeof scope === 'object'
                && typeof scope.sessionId === 'string') {
                service.closeTab(tab.id, scope)
              }
            },
          }, iconPath('M4 4l8 8M12 4l-8 8'))),
        React.createElement('div', { className: 'outline-overlay-body' }, outlineBody))
    }

    function OutlineSettingsPanel(props) {
      const rawSettings = props !== null && typeof props === 'object' ? props.pluginSettings : undefined
      const updatePluginSetting = props !== null && typeof props === 'object'
        ? props.updatePluginSetting
        : undefined
      const close = props !== null && typeof props === 'object' ? props.close : undefined
      const [settings, setSettings] = React.useState(() => normalizeOutlineSettings(rawSettings))
      const [saved, setSaved] = React.useState(false)
      const [options, setOptions] = React.useState({ models: [], reasoning: [] })
      const [modelCustomMode, setModelCustomMode] = React.useState(false)
      const [reasoningCustomMode, setReasoningCustomMode] = React.useState(false)
      React.useEffect(() => {
        setSettings(normalizeOutlineSettings(rawSettings))
        const savedModel = normalizeOutlineSettings(rawSettings).model
        const savedReasoning = normalizeOutlineSettings(rawSettings).reasoningEffort
        fetchJson('/dsh-outline/config', {})
          .then((data) => {
            if (data === null || typeof data !== 'object' || data.ok !== true) return
            const models = Array.isArray(data.models) ? data.models : []
            const reasoning = Array.isArray(data.reasoning) ? data.reasoning : []
            setOptions({ models, reasoning })
            setModelCustomMode(savedModel !== '' && !models.some((model) => model.id === savedModel))
            setReasoningCustomMode(
              savedReasoning !== '' && !reasoning.some((item) => item.id === savedReasoning),
            )
          })
          .catch(() => {
            // Keep the panel usable with the generic custom inputs.
          })
      }, [rawSettings])
      const update = (patch) => {
        setSaved(false)
        setSettings((current) => ({ ...current, ...patch }))
      }
      const persist = (next) => {
        if (typeof updatePluginSetting === 'function') {
          updatePluginSetting('model', next.model)
          updatePluginSetting('reasoningEffort', next.reasoningEffort)
          updatePluginSetting('maxConcurrency', next.maxConcurrency)
          updatePluginSetting('timeoutSeconds', next.timeoutSeconds)
          updatePluginSetting('maxRetries', next.maxRetries)
          updatePluginSetting('disabled', next.disabled)
        }
        persistOutlineSettings(next)
        setSaved(true)
      }
      const save = () => {
        persist(settings)
        if (typeof close === 'function') close()
      }
      const reset = () => {
        const next = { ...DEFAULT_OUTLINE_SETTINGS }
        setSettings(next)
        setModelCustomMode(false)
        setReasoningCustomMode(false)
        persist(next)
        if (typeof close === 'function') close()
      }
      const modelCustom = modelCustomMode || (settings.model !== '' && !options.models.some((model) => model.id === settings.model))
      const reasoningCustom = reasoningCustomMode || (settings.reasoningEffort !== '' && !options.reasoning.some((item) => item.id === settings.reasoningEffort))
      const modelSelectValue = modelCustom ? '__custom__' : settings.model
      const reasoningSelectValue = reasoningCustom ? '__custom__' : settings.reasoningEffort
      return React.createElement('div', { className: 'outline-settings-render' },
        React.createElement('div', { className: 'outline-pfield-field' },
          React.createElement('div', { className: 'outline-pfield-head' },
            React.createElement('label', { className: 'outline-pfield-label', htmlFor: 'outline-config-model' }, '标题生成模型')),
          React.createElement('select', {
            id: 'outline-config-model',
            className: 'outline-pfield-select',
            value: modelSelectValue,
            onChange: (event) => {
              if (event.target.value === '__custom__') {
                setModelCustomMode(true)
                return
              }
              setModelCustomMode(false)
              update({ model: event.target.value })
            },
          },
          React.createElement('option', { value: '' }, '与会话模型相同'),
          options.models.map((model) => React.createElement('option', {
            key: `${model.provider}:${model.id}`,
            value: model.id,
          }, `${model.provider}/${model.name}`)),
          React.createElement('option', { value: '__custom__' }, '自定义...'))),
        modelCustom
          ? React.createElement('div', { className: 'outline-pfield-field' },
              React.createElement('div', { className: 'outline-pfield-head' },
                React.createElement('label', { className: 'outline-pfield-label', htmlFor: 'outline-config-model-custom' }, '自定义模型')),
              React.createElement('input', {
                id: 'outline-config-model-custom',
                className: 'outline-pfield-input',
                value: settings.model,
                onChange: (event) => { update({ model: event.target.value }) },
              }))
          : null,
        React.createElement('div', { className: 'outline-pfield-field' },
          React.createElement('div', { className: 'outline-pfield-head' },
            React.createElement('label', { className: 'outline-pfield-label', htmlFor: 'outline-config-reasoning' }, '模型推理等级')),
          React.createElement('select', {
            id: 'outline-config-reasoning',
            className: 'outline-pfield-select',
            value: reasoningSelectValue,
            onChange: (event) => {
              if (event.target.value === '__custom__') {
                setReasoningCustomMode(true)
                return
              }
              setReasoningCustomMode(false)
              update({ reasoningEffort: event.target.value })
            },
          },
          React.createElement('option', { value: '' }, '与会话模型相同'),
          options.reasoning.map((item) => React.createElement('option', {
            key: item.id,
            value: item.id,
          }, item.name)),
          React.createElement('option', { value: '__custom__' }, '自定义...'))),
        reasoningCustom
          ? React.createElement('div', { className: 'outline-pfield-field' },
              React.createElement('div', { className: 'outline-pfield-head' },
                React.createElement('label', { className: 'outline-pfield-label', htmlFor: 'outline-config-reasoning-custom' }, '自定义推理等级')),
              React.createElement('input', {
                id: 'outline-config-reasoning-custom',
                className: 'outline-pfield-input',
                value: settings.reasoningEffort,
                onChange: (event) => { update({ reasoningEffort: event.target.value }) },
              }))
          : null,
        React.createElement('label', { className: 'outline-pfield-toggle' },
          React.createElement('input', {
            type: 'checkbox',
            checked: settings.disabled,
            onChange: (event) => { update({ disabled: event.target.checked }) },
          }),
          '不生成标题'),
        React.createElement('div', { className: 'outline-pfield-field' },
          React.createElement('div', { className: 'outline-pfield-head' },
            React.createElement('label', { className: 'outline-pfield-label', htmlFor: 'outline-config-concurrency' }, '标题生成并发数')),
          React.createElement('input', {
            id: 'outline-config-concurrency',
            type: 'number',
            className: 'outline-pfield-input',
            min: '1',
            max: '8',
            value: settings.maxConcurrency,
            onChange: (event) => {
              const value = Number(event.target.value)
              update({ maxConcurrency: Number.isFinite(value) && value > 0 ? Math.min(8, Math.round(value)) : 3 })
            },
          })),
        React.createElement('div', { className: 'outline-pfield-field' },
          React.createElement('div', { className: 'outline-pfield-head' },
            React.createElement('label', { className: 'outline-pfield-label', htmlFor: 'outline-config-timeout' }, '标题超时（秒）')),
          React.createElement('input', {
            id: 'outline-config-timeout',
            type: 'number',
            className: 'outline-pfield-input',
            min: '5',
            max: '300',
            value: settings.timeoutSeconds,
            onChange: (event) => {
              const value = Number(event.target.value)
              update({ timeoutSeconds: Number.isFinite(value) && value >= 5 ? Math.min(300, Math.round(value)) : 60 })
            },
          })),
        React.createElement('div', { className: 'outline-pfield-field' },
          React.createElement('div', { className: 'outline-pfield-head' },
            React.createElement('label', { className: 'outline-pfield-label', htmlFor: 'outline-config-retries' }, '失败重试次数')),
          React.createElement('input', {
            id: 'outline-config-retries',
            type: 'number',
            className: 'outline-pfield-input',
            min: '0',
            max: '5',
            value: settings.maxRetries,
            onChange: (event) => {
              const value = Number(event.target.value)
              update({ maxRetries: Number.isFinite(value) && value >= 0 ? Math.min(5, Math.round(value)) : 2 })
            },
          })),
        React.createElement('div', { className: 'outline-pcard-footer' },
          saved ? React.createElement('span', { className: 'outline-pcard-status' }, '已保存') : null,
          React.createElement('button', { type: 'button', className: 'outline-pcard-discard', onClick: reset }, '重置'),
          React.createElement('button', { type: 'button', className: 'outline-pcard-save', onClick: save }, '保存')))
    }

    exports.inject = ['sessions', 'betterSidebar']
    exports.apply = function apply(ctx) {
      const style = document.createElement('style')
      style.dataset.plugin = 'dsh-client-ui-conversation-outline'
      style.textContent = css
      document.head.appendChild(style)
      ctx.effect(() => () => style.remove())

      sessionsService = ctx.get('sessions') !== undefined ? ctx.get('sessions') : null
      layoutService = null

      const betterSidebar = ctx.get('betterSidebar')
      if (betterSidebar !== undefined && betterSidebar !== null && typeof betterSidebar.registerTab === 'function') {
        ctx.effect(() => betterSidebar.registerTab({
          id: OUTLINE_TAB_ID,
          title: () => '对话大纲',
          icon: (size) => iconPath('M3 3.5h10M3 8h10M3 12.5h6', size || 16),
          order: 45,
          single: true,
          settings: {
            render: OutlineSettingsPanel,
          },
          component: (props) => React.createElement(OutlinePanel, {
            ctx: props.ctx,
            store: props.store,
            scope: props.scope,
            tab: props.tab,
            visible: props.visible,
          }),
        }))
      }
    }

    return module.exports
  },
})
