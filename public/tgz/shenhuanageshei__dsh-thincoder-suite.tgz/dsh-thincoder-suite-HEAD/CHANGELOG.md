# Changelog

本插件遵循语义化版本。完整设计文档见 [`docs/`](./docs/)，工程方法论见 [METHODOLOGY.md](./METHODOLOGY.md)。

## [0.31.0] — 2026-10-14

> **一句话（人话）**：给插件**多开一条 codex 通道**。以前 codex 只有一条路——在本机起 `codex exec` 子进程；你这台机器上那条路**一遇到「要执行命令」就挂**（Windows 沙箱助手起不来 + 联网子系统超时）。现在多了一条：走**平台自带的 codex 支持**（官方 app-server 协议），用于**只读类**任务（会诊 / 评审）。两条通道并存，用哪条写在配置里，一眼可辨、随时可退。

**【计数行】**：`node --test` **631/631**（**基线 594 + 本批 37**）。★ 两批共用一份工作树：基线 594 = 批 33/34 开工前的读数；本批 37 = 批 34 新增的 `test/anti-drift.test.mjs`（**34 腿**（本档顶层块）= A 族 **14**（A-1…A-15；**A-7 落 team-link 仓、不在本档**）+ §8 负控 ①②④ **3** 条 + **尾-1…尾-12 共 12 条**（停滞 3 · L-11 落章 1 · L-6 标定 1 · 畸形 turn 1 · 星平面 1 · 判据清理 1 · 跨重启 1 · 待绑槽 1 · 空 id 与校验器 2）+ 附录 **5** 条；**另 2 条落在别档**：ps10 触点锁（C11，`platform-surface`）· README 计数门（N-4））**加**该批在既有档内补的 1 条（`session-state` 的 `T1b-C10`）；codex-app-server 通道那一批的新腿全部并入既有顶层块 ⇒ 顶层计数贡献 0。本行按 2026-10-15 实测写入，**合并回 main 时按当次读数复核**（发布门 G3 强制一致）。

**一、为什么要加（人话）**：`codex exec` 这条路在本机有两处坏点——① 要执行命令时 `Failed to create unified exec process: helper_unknown_error`；② 联网子系统反复超时（`chatgpt.com/backend-api/ps/mcp` + 模型表刷新）。对照：平台自带 `@deepseek-ai/dsh-subagent-codex`（注册 provider 名 **`codex`**，走 **app-server** 协议）**协议握手实测通过**。按用户裁定走后者，且**不动 Codex 桌面端任何配置**。

**二、怎么用（人话）**：会诊池 / advisor 路由的行或组里写 `runner: { kind: "codex-app-server" }` 即走新通道；写 `codex-cli` 仍走老通道；`dsh`（缺省）不变。**两条必须知道的边界**：① 新通道**只读**——无人值守时平台对审批一律拒绝，所以 **eng_coder / escalate 配它会具名拒绝**（它们要写工作区）；② 新通道**不消费 `model` / `effort`**（模型由本机 Codex 配置决定），配了不静默忽略、会在展示面如实告知。

**三、改了什么（技术面）**：新档 `lib/codex-app-server.mjs`（请求**只发** `prompt/parent/signal/label`；provider 未装配 / 文本为空 / start 拒绝等**具名 fail-closed**；平台失败面原样上浮；**不提供 usage**，行渲染不留空占位）· 配置面（`CODEX_RUNNER_KINDS` 收新 kind · `lib/index.mjs` 的 `isCodex`/`sanitize*` · `lib/client.js` 判定族字面单点化）· 接线（`lib/consult.mjs` / `lib/advisor.mjs` 按 `runner.kind` 分派；写任务守卫落 `lib/escalate.mjs`）· 结项页矩阵行补新 kind 与覆盖边界。

**四、有意改锁（用户裁定 · 留痕）**：`lib/advisor.mjs` 的 `.abort(` 写点 **4 → 6**（新腿两处：`:1920` 上游中止中继 / `:1931` 腿内预算截止）⇒ 站点同步进 `lib/abort-provenance.mjs` 档头枚举（标「批 33 追认」）；`T-AP7` 两条腿（写点预算 / 定时器表达式）随之**有意更新期望值**——**不是放宽锁，是登记新增**。

**五、文档与评审**：[需求档](./docs/2026-10-14-codex-app-server-requirements.md) + [设计档](./docs/2026-10-14-codex-app-server-design.md) · 设计评审 **PASS**（令牌有效至 2026-10-21）· 评审轮 1 的 11 条 + 复审 2 条全部收口（处置表落设计档 §11）。

**六、已知残留**：`T-AP7(b)` 定时器表达式腿由收官小修补齐；共享档（本档与 `README.md`）按「逐文件 add」纪律合并，禁 `git add -A`。

---

### 同版第二交付面：批 34「长任务防漂」（anti-drift）

> **一句话（人话）**：以前「别忘了目标、改完要验证、交付前要评审」这些话只写在**系统提示词**里——它会一直待在那儿，但**不会在你要收尾的那一刻拦你**。这个批次把纪律挪到**每一步的动态注入 + 两道硬门**上：立目标前先写「怎么算完成」，写不出就**建不起目标**；宣告完成要有**跑过的证据**；改完产品代码没验证就想收尾，**回合会被推回**。

**一、为什么要加（人话）**：长任务（尤其跨重启、跨压缩的）里，模型忘掉最初目标、改完代码忘记验证、评审没做就宣布完成——这三件事在真机上反复发生，而**用户自己也承认会忘**（原始诉求原话）。静态提示词治不了「**在正确的时刻做正确的拦截**」，因为提示词不会在回合边界上动手。

**二、怎么用（人话）**：目标照常立，但**先调 `goal_criteria`** 写判据（`criteria` = 要达成什么 / `check` = 怎么机检）；**不填 `goal_id` 也行**——它先进「待绑槽」，你建目标时自动绑上去。之后：每步你都会在上下文尾部看到「目标 + 判据 + 欠账」；跑完检查用 `goal_verify status=passed` 落章；`advisor` 评审通过也等价落章。开关六键在 `anti_drift_config` 或配置文件里，**默认注入开、完成门开、推回关、台账门关**。

**三、改了什么（技术面）**
- 新档 **`lib/anti-drift.mjs`**（机制本体，**单点收口**）：判据存储（`pending` 待绑槽仅内存 + `goals` 盘上记录）· 每步渲染体 · 两道门 · 有界推回 · 开工接管 · 装配期探测降级。`lib/index.mjs` **只注册接线，零机制逻辑**。
- **三个新工具**：`goal_criteria` · `goal_verify` · `anti_drift_config`（键名与取值**闭集校验**，工程模式**禁写**）。
- **三域分离**（落章域 / 回合域 / 会话域，按「**复位点由什么事件决定**」分域）：每个标记**恰属一域**——这条正是评审连抓两轮的同一个物种（把 `steerTotal`、`honestySent` 错放进会话域），故本批**加了机器锁**（腿 A-15 直接解析设计档 §7 三行求交集）。
- **推回记账的唯一口径**：三族各族自有上限（默认 1/2/3，Σ=6），**诚实句占其后第 Σ+1 条** ⇒ 单回合硬上限 **7**；会话域诚实句封顶 **3**（**是「拦」不是「只记账」**）。★ 设计早期曾有 `caps.total` 子键，它与「三族各推满」**数学互斥**（会让诚实句永不可达）⇒ 已删，并在代码与设计档都写明「勿再加回」。
- **失败朝向**：判据门 / 完成门 **fail-closed**（读不到状态 ⇒ 拒）；注入 / 推回 / 接管 **fail-open**（异常 ⇒ 不注入 / 不推回 / 优雅降级）。两个监听器体内**全包 try/catch**——`agent/turn-stopping` 抛错会把回合变成 `error`，`agent/created` 抛错会让**创建失败**。

**四、有意改锁（同批上调，D28-6 口径 · 逐条留痕）**
- `lib/contract-baseline.mjs` 的 `REGISTRATION_SURFACE_BASELINE.textTool` **8 → 11**（+3 工具），同断言在 `test/contract-baseline.test.mjs` 跟到 11。**`systemPromptSection` 仍为 3**——本批注入走 `systemPrompt.context`（**不是 section**，动态文本进 section 会击穿前缀缓存）⇒ 若日后有人把注入误挂 section，该锁**立刻变红**。
- `test/guard-e.test.mjs` 的 T-E19 档清单 **+1**（`anti-drift.test.mjs`）；**T-E18 的 A5「`tools/pre-execute` 恰 2 个监听器」→ 3**——第三条与既有两闸**独立绑定**（三条闸失败朝向不同，合并函数体会让三种朝向纠缠）。
- `docs/test-lifecycle.md` 新增 `anti-drift.test.mjs` 行（19 腿 · 层 ② · standing）。
- `docs/2026-09-17-scope-alignment-design.md` 的 b17 事实组两值跟到 **614/20**（该行自己定的纪律：更新人 = 主代理，时机 = 改 CHANGELOG 首节计数行的同一批）。

**五、验证读数**：`node --test` **614/614 全绿**（含本批新增 19 腿）。装配探针实测：3 工具注册 · `textTool` 计 11 · `agent/turn-stopping`×1 / `agent/created`×2（C10 双名垫片）/ `tools/pre-execute`×3 / `tools/post-execute`×1；`goal_criteria set` 走通待绑槽；宿主 goal 服务缺席时**按设计打降级 warn 且不崩**。

**六、文档与评审**：[需求档](./docs/2026-10-14-anti-drift-requirements.md) + [设计档](./docs/2026-10-14-anti-drift-design.md) + [会诊纪要](./docs/consult-minutes/2026-10-14-consult-74-minutes.md)（consult #74，5 模型，逐条处置 44 条 = 43 adopted · 1 rejected）。设计评审 **四轮**：轮 1 `FAIL` 13 条 · 轮 2 `FAIL` 14 条 · 轮 3 未过 12 条 · **轮 4 `VERDICT: PASS`**（令牌有效至 2026-10-21）；四轮逐条处置全部落档设计档 **§15.1–§15.4**。

**七、附带修好的独立缺陷（C10，本版第一交付面已含）**：`lib/index.mjs` 的会话状态恢复链原只挂 `agent/session-start`——该事件名在装机 0.2.0-rc.2 与开发树 0.2.1-alpha.2 **都不存在** ⇒ 恢复链与 preset 自动进工程模式**从未触发**。现改挂真名 `agent/created` 并**保留旧名作跨版本垫片**。

**八、已知残留（诚实清单）**：① **跨插件欠账注入未交付**（不读 team-link 黑板，设计档 §14 L-1）——这是原始痛点的另一半；② **无轮次/预算读数**（可得性未验证，不造读数，L-2）；③ **判据「写了」≠「可机检」**（形状门不判语义，归评审）；④ 设置页开关面未做（六键全 base-only，工具面已够用，L-7）；⑤ **需重启 DSH 才生效**（装配期注册；重启时机由用户定）。

### 同版热修：装配面 `inject` 白名单缺陷 —— 真机「插件装上了、但 11 个工具全不可用」（2026-10-15）

> **一句话（人话）**：这次修的是「**插件看得见、用不了**」。它的模块**被正常加载**了、客户端设置页也渲染出来了，但服务端 `apply` 在**一处服务探测**上就抛了异常，于是 11 个工具、配置 API 路由、监听器**一个都没注册**。真因是一行属性读取，违反了本仓**早已写明**的 cordis 纪律。

**一、根因（真机取证，异常原文）**——cordis 的属性读取是**白名单**：读一个**未在 `inject` 声明**的服务属性会**当场抛** `Error: cannot get property "goals" without inject`，且**可选链 `?.` 救不了**（抛在读取那一刻）。夜班新增的 `lib/anti-drift.mjs` 在探 goal 服务时写成 `Boolean(ctx?.goals?.get)` ⇒ 该异常把整个 `apply` 打断。**取证链**（前序会话以多次重启加装临时探针取得，现已全部撤除）：① in-module 探针证明**模块确被 import**；② `[apply ENTER]` 证明 `apply` **确被调用**；③ `[apply THREW] … cannot get property "goals" without inject` 给出**异常原文**。⇒「模块在、功能无」这种形态**不能**靠"模块是否被加载"定位，**必须拿到 `apply` 的异常**。

**二、修法（两处，方向相反但同源）**——① `lib/anti-drift.mjs` 新增 `probeGoalService(ctx)`：**`ctx.get("goals")` 优先**（cordis 原文「Read a service from the store **without the inject requirement**」，未注册返回 `undefined` 而不抛），属性读取只作老式夹具回落且**必须兜 try/catch**。② `lib/index.mjs` 的 `inject` 由 `[tools, systemPrompt, webServer, llm, subagents, goals]` 收敛为 **`[tools, systemPrompt, webServer, llm, subagents]`** —— `goals` **刻意不声明**。**这不是退让而是纠偏**：本仓 `lib/index.mjs:717-720` 早就写死了这条纪律（取 `connection` 一律 `ctx.get`，且**刻意不写进 `inject`**——required 语义会让没有该服务的宿主**整个插件拒起**）；把可缺服务写成硬依赖 = **同一类缺陷复发**。运行时取值 `goalViewOf` 本就走的 `ctx.get("goals")`，与本次改动同向。

**三、充分性证据（为什么「5 个声明」够，而不是猜）**——① **上界**：本次 boot 探针实测 `[apply OK]`。cordis 对任何未声明服务的属性读取都会抛，apply 能跑完 ⇒ **整个 apply 调用图的属性读取集合 ⊆ 当时声明的六个**。② **枚举**：`ctx.goals` 的**属性**读取全仓仅 3 处（`anti-drift.mjs` 的 FR-8 探测 + `index.mjs` 两处临时探针/warn），现已全部改为安全取值或删除。①② 相加 ⇒ 去掉 `goals` 后**不存在**未被覆盖的属性读取。③ **本地复刻**：以"读未声明服务即抛"的白名单代理驱动真实 `apply`（逐字复刻宿主报错），`inject = 5` 时 **11 工具全部注册 · 监听器齐全 · `dispose` 干净 · goals 缺席走降级不崩**。

**四、有意改锁（1 处）**——`export const inject` 收敛为 5 项。**未改任何计数**：本次**不新增顶层 `test(` 块**，回归腿**并入既有 A-12 块**（用白名单代理直接驱动探测函数 + 一条"代理确实会抛"的负控）⇒ 计数行仍 **631/631**，台账与文档计数零漂移。

**五、验证读数**——`node --test` **631/631 全绿 · 0 fail · exit 0**（含并入 A-12 的新断言）；本地白名单代理装配实测 **11 工具 / 监听器齐全 / dispose 干净**；`lib/index.mjs` 与 `lib/anti-drift.mjs` `node --check` 通过；临时探针**零残留**（全仓 grep `__diagAppend|module-load-probe` = 0）。

**六、真机核验（已发生）**——本次重启后 `contractWatch` 与 `anti_drift_config` **均返回真实结果**（修复前同一会话内的 `contractWatch` 返回 `Error: unknown tool "contractWatch"`）；探针末行 `[apply OK]`、六个服务全在场。⇒ **装配面已恢复**。

**七、环境面处置（非本仓改动，登记于此仅供追溯）**——① `~/.dsh/profiles/desktop/package.json` 曾声明 **3 个盘上不存在的 bundle**（`@deepseek-ai/dsh-experimental-agent-team-profile` / `-auto-review` / `-schedule-bundle`）⇒ `loadProfile` 解析失败会中止整棵 profile 树。已删（bundles 39 → 36；备份 `package.json.bak-deadbundles-20261015-175106`）。② 废弃的 `web` profile 原有 14 条声明了却不存在于盘上的 bundle，已清（备份 `profiles\web\package.json.bak-suitefix-20261015-170132`）。两处均只删"声明了但盘上不存在"的名字。

### 同版热修：注入/推回消息的 source 归属 —— 裸 `kind:"plugin"` 被 session format v4 拒绝，**整个回合报错**（2026-10-15）

> **一句话（人话）**：反漂移的**停滞提醒**（你连续 3 次做同一个调用时它提示你换法子）本身是想救命的，结果那条提醒**把整个回合打死了**——界面显示「本轮运行失败：format v4 message requires a producer-owned source kind」，会话日志停在触发那一刻，**后面的事件一个都没落盘**。

**一、根因（平台契约）**——三条注入/推回路径（停滞 `inject` / 推回 `steer` / 开工接管 `inject`）原先都写 `source: { kind: "plugin" }`。而 session format **v4 明令拒绝**这个裸 kind —— 平台原文（`lib/types/message-sources.js`）：`if (... || value["kind"] === "plugin") throw new SessionFormatError("format v4 message requires a producer-owned source kind")`；V4 admission 文档同款口径：「Interpreted message slots require an object source with a nonempty, **non-`plugin`** kind」。

**二、为什么同步 `try/catch` 兜不住（三处调用点**都**包了 `try/catch`，回合还是死了）**——① `Session.append()` 的**同步**校验 `validateSessionEventData` **不查 message source** ⇒ `inject` 当场**不抛**、事件进内存 log、调用点的 `catch` 无事发生；② 该校验在**持久化编解码层**（`assertV4RowAdmission` → `assertV4SourceRowAdmission`），走的是**异步** `async append(events) → persistContiguous` ⇒ 异常在**写盘时**才炸，逃出调用点；③ 写盘链一断，其后的所有事件**都不落盘**。

**三、真机取证（证据链，可复核）**——会话 `session-55c8bfa4…` 的会话日志（**493 帧 zstd 全解 · 4.0 MB · 831 行**）**终止在 seq 828**：seq 824/826/828 是**三次完全相同**的 `anti_drift_config {"action":"get"}`，同批配置读出 `stallRepeat: 3` ⇒ 第三次必触发停滞提醒；turn 6 **没有 `turn/end`**；全档 **零处** `"kind":"plugin"`（被拒的事件根本写不进去）——三条与"写盘层拒绝"逐条吻合。

**四、修法**——新增 `lib/anti-drift.mjs` 的 `PRODUCER_SOURCE_KIND = "plugin:@dsh-external/dsh-thincoder-suite"` 与 `producerSource()`（**每次返回新对象**）；三处调用点全部改用。形状取 `plugin:<包名>`：这正是平台自己的 v3→v4 迁移函数 `producerKind(plugin)` 对第三方插件产出的 kind（`"plugin:" + plugin`），故新旧两代行读回归一到**同一个生产者**（同族先例：`dsh-better-sidebar` 的 `SIDE_INJECTION_SOURCE_KIND = 'plugin:dsh-better-sidebar'`，其注释逐字写明了同一约束）。平台侧只强制「非空字符串 且 ≠ `"plugin"`」，未知 kind 与自有 JSON 元数据都会被保留。

**五、验证读数**——`node --test` **631/631 全绿 · 0 fail · exit 0**；**变异证明**：临时副本上把三处改回裸 `plugin` ⇒ 回归锚 **A-8 立刻转红**，失败原文即该锚自己的断言消息（`lib/index.mjs 不得再把裸 \`plugin\` 当 source kind 写（v4 写盘层会打红整个回合）`）；清理后恢复绿。

**六、有意改锁 / 计数**——**未新增顶层 `test(` 块**：回归锚**并入既有 A-8 块**（行为腿：`producerSource()` 的 kind 非空、≠ `"plugin"`、与迁移同形、每次新对象；结构腿：全 `lib/*.mjs` **剥离注释后**零处 `source: { kind: "plugin" }`，且恰 **3** 处 `source: producerSource()`）⇒ 计数行仍 **631/631**，台账与文档计数零漂移。

**七、同批捎带（如实登记）**——上一会话遗留的**未提交**评审 #5 修复（`goal_verify` 调用点转发 `cwdHint`，与 `goal_criteria` 对齐）**随本批一并**跑过全量后提交。


### 同版热修 2：`tools/post-execute` 标记面的**两个「调了但没 import」**（2026-10-15）

> **一句话（人话）**：反漂移里「记下你改过哪些代码」和「建目标后把判据绑上去」这两件事，在真机上**从来没生效过**——不是逻辑写错，是那两个函数**根本没被引入**，一调用就抛 `ReferenceError`，又被监听器自己的 `catch` 吞掉。用例全绿、`node --check` 也全绿，因为「只查语法」与「只测函数本体」都看不见**接线**。

**一、根因（两处，同一物种）**——`lib/index.mjs` 的 `tools/post-execute` 监听体内：① `targetPathOf(name, exec?.arguments)`（`:1627`；`lib/eng.mjs:116` 导出）**不在 `./eng.mjs` 的 import 名单里**；② `promotePending({…})`（`:1637`；`lib/anti-drift.mjs:288` 导出）**不在 `./anti-drift.mjs` 的 import 名单里**。两处每次命中都抛 `ReferenceError`，被同一监听器的 `catch` 吞掉。后果：**落章域**（`codeMutatedSinceStamp` / `touchedFiles`）在生产环境**从未置位** ⇒ FR-2 完成门与 FR-4 推回谓词的落章侧失效；`create_goal` 成功后的**待绑槽提升从未发生**。

**二、真机印证**——上一会话在 `session-55c8bfa4…` 实测的 **V1②**「建目标成功后，待绑槽**没有**被提升为 `bound`（仍是 `pending` / `goalId: null`）」——当时的怀疑是「`extractGoalId` 认不出宿主返回形状」，**真因是本条的 `ReferenceError`**（同一个 `catch` 把现场抹平了）。

**三、同批修掉的 FR-5 朝向违规**——该监听器的 `catch` 原先统一 `return { kind: "accept" }`，等于「**标记段一出错就改写下游决定**」，违反设计档 :204 / :299「本监听器**永不改 decision**」。现把 `next()` 的决定提到 try 之外：`let d; try { d = await next(); …标记… } catch { warn } return d ?? { kind: "accept" }`——只有 `next()` **自身**抛错（`d` 仍为 `undefined`）时才回落 accept。

**四、防回归：这次上的是通用锁，不是逐条钉名字**——`test/anti-drift.test.mjs` 的**负控①**新增断言：把 `index.mjs` 的本地模块 import **按模块路径合并**成名单，枚举各模块的 `export function|const|let|class`，凡在 `index.mjs` 里以 `NAME(` 形式被调用、却不在名单里的 ⇒ **红**（先剥离注释；两条谓词自证防恒真：导出名 ≥20、import 模块 ≥5）。该锁**第一次跑就抓到上面两条真缺陷**（失败原文即本档第一节的现场），并曾对 `clearCodexThread` 报过一次**假阳性**——原因是 `escalate.mjs` 分**两条** import 语句引入、谓词按「单条语句」判 ⇒ 已改为**按模块路径合并**（教训与修法同批落在代码注释里）。

**五、验证读数**——`node --test` **631/631 全绿 · 0 fail · exit 0**；新锁的红→绿是**实测**而非构造（见上）。**未新增顶层 `test(` 块** ⇒ 计数行仍 **631/631**，台账零漂移。

### 同版热修 3：防漂「收口批次」——落章域/证据落盘 · 整机静默 · FR-4 前置 · 判据同址（2026-10-15）

> **一句话（人话）**：上一批「长任务防漂」里有**四个洞**，根子都是**代码没照已批准的设计做**。最要命的第一个：重启之后插件**忘掉**「你改过代码、但还没验证」这件事，于是那道「没验证不许宣布完成」的门会**直接放行**。**用户 2026-10-15 裁定「该记」** ⇒ 本批把该记的记下来。

**一、四个洞（评审 #2/#3/#4/#5，逐条已核实，不是转述）**

1. **落章域与验证证据不落盘**（🔴）——设计档 §7:345 要求落章域「跨回合、**跨重启**（重启用白名单恢复）」、§7:344 要求验证记录「会话级；**落盘**」，而实现里两者都只在内存。**后果**：重启后 `codeMutatedSinceStamp` 与 `verifiedSinceStamp` **双双归零** ⇒ 完成门读到的是「没改过代码」⇒ **无证据放行**（fail-open）。**用户裁定：该记。**
2. **判据存储落点偏离 FR-1**（🔴）——设计档 :133 要求「与 `token-store.mjs` **同址**」，实现却是 `join(dshHomeOverride || DSH_HOME || cwdHint, FILE)`：既没有 `.thincoder/` 子目录，也**绕过 `pickDshHome`**。`dsh-home.mjs:18-19` 实证「desktop 构建的插件进程**无 DSH_HOME**」⇒ 旧写法把 `goal-criteria.json` 写进**会话 cwd**（污染用户工作区、且按 cwd 碎片化）。
3. **「整机静默」没有实现**（🔴）——设计档 A-11:383 / FR-4:185 要求「诚实句累计达 **3** ⇒ 其后**整机静默**」，实现里 `silenceWarned` **只用来多加一句 warn**、没有任何分支读它 ⇒ 到点后**每个回合照样能推满 Σ族 条**，唠叨**没有总量上限**。原测试没抓到，是因为它**只数 `kind === "honesty"`**（族推回停没停根本看不出来）。
4. **FR-4 前置缺两条、反倒加回一条**（🟡）——设计档 :183 前置为「`pushback` ∧ 非工程模式 ∧ **存在活跃目标** ∧ `!signal.aborted`」；实现两条都没有（无活跃目标也推回，与 US-3 的收窄**正好相反**），却**反向加回了**设计档 :184 明令移除的 `depth === 0` 守卫。

**二、修法**

- **落盘**：新增 `anti-drift.mjs` 的 `antiDriftStateView()` / `restoreAntiDriftState()`；`session-store.mjs` 白名单扩 `stamp` 与 `verifyRecords`（**条件字段**口径 ⇒ 不带它们的既有 fixture 输出键集**逐字不变**）；`index.mjs` 新增 `sessionViewFor()` / `persistAntiDrift()`，**三处既有写盘点全部改经 `sessionViewFor`**（`saveSessionState` 是**整条替换**，绕过它就会把落章域与证据抹掉），并在 `write` / `edit` / `advisor` / `goal_verify` 四条工具路径上**写完即落盘**；`agent/created` 恢复路径同批调 `restoreAntiDriftState`。**回合域与会话域仍然一律不落盘**（设计档 §7/§9：重启清零是"接受的代价"）。
- **恢复守卫的教训（同批实测抓到，如实登记）**：守卫最初写成「`domains` 里没有这个 key 才恢复」。但 `domainState()` 是**读也建条目**的，而注入面与开工接管面都会在 `agent/created` 前后读它 ⇒ 那个守卫会让恢复**在生产环境静默永不发生**（又是本批反复出现的「名字都在、机制悄悄不工作」）。已改为按「**落章域是否确实非空 / 证据簿是否确实有记录**」判定。
- **判据同址**：`resolveCriteriaStorePath` 改用 `pickDshHome` + `.thincoder/`；**旧位置保留一次性兼容读**（读到旧记录即迁移到新位置——升级不让判据凭空消失）。
- **整机静默**：`onTurnStopping` 新增会话静默闸；单回合硬上限的 warn 改用**自己的回合域闩**（评审 #8 · 🔵：原先复用会话静默闩 ⇒ 一次「单回合用满」就是**整个会话永久静音**）。
- **FR-4 前置**：补「存在活跃目标」与 `!signal.aborted`（接线把 `payload.signal` 透传进来）；同批**删掉**接线里那条冗余的 `depth` 判断（设计档 :184 明令移除，且「有活跃目标」已天然排除子代理）。
- **L-12 顺带收口**：`summary` / `command` 增 **2000 码点上限**（**超限拒，不静默截断**）——这些记录本轮起要落盘，该上限由"低价值加固"升级为必需。

**三、验证读数**——`node --test` **631/631 全绿 · 0 fail · exit 0**；**未新增顶层 `test(` 块**：五组回归腿**分别并入既有 A-3 / A-9 / A-10 / A-11 / 尾-9** ⇒ 计数行零漂移。**变异证明 5/5**（临时副本，真实仓未动）：M1 拆掉静默闸 ⇒ **A-11 红** · M2 拆掉「存在活跃目标」⇒ **A-9 红** · M3 让落章域不进视图 ⇒ **A-10 红** · M4 把硬上限闩还原成原缺陷形态 ⇒ **A-11 红** · M5 把判据落点还原成原缺陷形态 ⇒ **尾-9 / 尾-11 红**。

**四、设计档同步**——L-12 的「不落盘、重启即清」前提已随本批**失效**，同批订正为「已落盘 + 2000 码点上限」；§9 的「该恢复链当前不触发」加 as-of 订正。

**五、第 2 轮评审后的追加修复（同批，评审 #9 / #10 / #11）**

- **#10（🔴 · 新）落盘被别的写者抹掉**——`saveSessionState` 是**整条替换**，而 `advisor.mjs:1719` / `eng.mjs:170` / `escalate.mjs:195,545` 四处写的是 `sessionStateViewWithGeneration(state)`，**不带**落章域 ⇒ 后写者一落盘，刚落盘的落章域与证据就被清空 ⇒ 重启后完成门又变回「**无证据放行**」（正是本轮要修的那个 fail-open）。**修在存储层**：`session-store.saveSessionState` 对**条件字段**（`advisorGeneration` / `lastDesignDocKey` / `stamp` / `verifyRecords`）实施「**视图省略 ⇒ 保留盘上旧值**」——一次改动覆盖**全部**写者（含将来新增的，无需每个写者记得带上别人的字段）。代价如实声明：调用方**无法**再用"省略"清空这四个键（本版无此需求）。
- **#11（🔵 · 新）恢复会丢证据**——`restoreAntiDriftState` 的 stamp 支**早退**，快照若是「`stamp` 全 false + 有 `verifyRecords`」就会丢证据。已改为不早退（`did` 记账，两支各自置位）。
- **#9（🔵 · 沿袭）同键两套语义**——`stallRepeat` 的**上界**此前只在工具面强制 ⇒ 手改配置写 `9999` 会被解析侧**静默接受**。解析侧对齐同一闭区间 **0..20**（新增 `STALL_REPEAT_MAX`，单一事实源）。
- **验证**——`node --test` **631/631 全绿 · 0 fail · exit 0**；**变异证明**：M6 拆掉条件字段保留 ⇒ **A-10 红** · M7 拆掉 `stallRepeat` 上界 ⇒ **尾-3 红**。
- **#6（🟡 · 沿袭未修，如实登记）**——提示装配路径每步两次同步读盘 + 一次 `loadUserConfig`。属**性能面、非缺陷**；要改需引入内存镜像（改的是热路径缓存语义），与本轮风险面不成比例 ⇒ **留下一批**。

### 同版热修 4：注入/推回消息的 **content 槽** —— 裸字符串让会话**再也打不开**（session format v4 的第二道硬约束）（2026-10-16）

> **一句话（人话）**：接上一个热修（source 归属）。上一次修的是「**名字**不对 ⇒ 回合当场被打死」；这一次修的是同三处调用点的另一半——**消息正文的形状**不对。这次的症状更阴：插件**零报错**、消息**照常写盘**、容器级体检也**全绿**，但你**再也打不开那个会话**了：点进去空白、再发消息没反应。因为平台只在**重新读取（seed）那一刻**才检查正文形状，**写的时候不查**。

**一、根因（平台契约 · 第二道硬约束）**——三条注入/推回路径（停滞 `inject` / 推回 `steer` / 开工接管 `inject`）把 `content` 直接传成**裸字符串**。平台写盘层**确实会走到**这个槽（`@deepseek-ai/dsh-session-format-v3-to-v4` 的 `src/codec.ts` `encodeEvent` → `assertV4RowAdmission` → `src/retired-syntax.ts` 的 `case 'user/message'`），**但那个检查器是「有则检查、无则放过」**：`assertContent` 的 `if (Array.isArray(content)) …` **没有 else** ⇒ 裸字符串**静默穿过**写盘（上一个热修修的 source kind 是同一批检查里的另一半，那条**是**硬拒）。故 `agent.inject/steer` 当场**不抛**、消息**照常落盘**；直到 **seed/读取层**才抛 —— 平台原文（`@deepseek-ai/dsh-session` 的 `src/index.ts` `assertMessageEventShape`）：`if (!Array.isArray(messageRecord["content"])) throw new Error(\`${subject} message has invalid content\`)`。v4 里 user 消息的 content 槽**只认内容块数组**：平台自己的 inbox 投递（`agent/inbox/spliced` 的 `inserted[]`）与本仓 `lib/advisor.mjs:1213` 的 `userMessage()` 产出的都是 `[{type:"text",text}]`。

**二、为什么这个形态极难自查（三条读数都指向"没坏"）**——① 插件侧**零异常**（写盘层那个 content 检查器对非数组静默放过，三处调用点包的 `try/catch` 全程无事发生）；② 盘上文件**容器级全绿**（zstd 帧完整、每行 JSON 合法 ⇒ `undo_scan` 一类体检报 `ok`）；③ 症状发生在**打开**那一刻、不在**写入**那一刻 ⇒ 与"谁写坏的"在时间上脱钩。

**三、真机取证（全库扫描，可复核）**——对 `~/.dsh/sessions` 下 **1675** 个会话文件逐个做 content 槽形状校验（`Array.isArray(content)`，覆盖 `user/message` / `system/message` / `assistant/message` / `tool/result` 四个持久槽）：**仅 2 个**会话含非法消息，且两条的 `source.kind` 都是本插件（`plugin:@dsh-external/dsh-thincoder-suite`）——一条落在**停滞提醒**（`session-1220b9a6…` seq 1422），一条落在**开工接管**（`session-4aed6938…` seq 8125）。全库唯一来源。旁证：`team_link_export` 导出 `session-1220b9a6…` **直接失败**，原文 `seed user/message at index 1422 message has invalid content` —— 正是本节第一节那条规则。

**四、修法**——新增 `lib/anti-drift.mjs` 的 `producerContent(text) => [{ type: "text", text: String(text) }]`（与 `producerSource()` **并列**、同样**每次返回新对象**）；`lib/index.mjs` 三处调用点全部改用（`:1693` 停滞 inject · `:1733` 推回 steer · `:1761` 开工接管 inject）。

**五、验证读数**——`node --test` **631/631 全绿 · 0 fail · exit 0**。回归锚**并入既有 A-8 块**（不新增顶层 `test(`）：行为腿（`producerContent()` 必须返回**非空内容块数组** · 每块 `type` 为非空字符串 · 文本原样进 `text` 槽 · 每次新对象且内容恒等）+ 结构腿（全 `lib/*.mjs` **剥离注释后**零处 `content: r.steer` / `content: r.inject` / `content: stallNotice(`，且恰 **3** 处 `content: producerContent(`）。

**六、有意改锁 / 计数**——**未新增顶层 `test(` 块** ⇒ 计数行仍 **631/631**，台账与文档计数零漂移。

**七、已写坏的会话（同日外科修复，2026-10-16 00:41 / 01:44）**——首轮修复前对 `~/.dsh/sessions` 全库逐条按**平台校验器的准入集**复扫：**3 个**会话含非规范 content，来源全部是本插件 —— **2 个阻塞**（`user/message` 的 content 是裸串：`session-1220b9a6…` seq 1422、`session-4aed6938…` seq 8125）**+ 1 个潜伏**（裸串只躺在 `agent/inbox/spliced` 的 `inserted[]` 里：`session-55c8bfa4…` seq 833 —— 它**不在**校验器准入集内，故该会话当时**仍能导出**，但那条消息一旦被消费成 `user/message` 就会长成新的阻塞点）。
**★ 第 4 个（重启前两分钟产生，第二轮补修）**：首轮修复后、代码修复生效前，**旧代码又写坏了一个** —— `71ee2173-ef3f-4167-9d5a-cd21eba37f6b`（**另一个工作区** `--D-Code-opendns_top--`，mtime `01:36:16`，阻塞型：`user/message` seq 356 + 收件箱副本 seq 347）。它在重启后的终扫里被抓到并于 `01:44` 同法修复。**合计 4 个会话 / 3 个阻塞 + 1 个潜伏。**
**修法**：**保帧外科手术** —— 只重压承载目标行的 zstd 帧，其余帧**逐字节不动**；四个会话合计改 **7 行 / 重压 7 帧**（2 + 2 + 1 + 2）。原档备份在 `~/.dsh/sessions-repair-backup/`（**四份**，文件名含会话 id 与时间戳）。
**验收**：① 每档自校验全过（帧数不变 · 逐帧可解 · 行数不变 · 改动行数 == 修补槽数 · **其余帧逐字节相同** · 裸串归零）；② 盘上直证 —— 修复后的 `seq 1422` 为 `role=user` / 非空 `id` / 非空 `source.kind` / **`content` 已是内容块数组**且文本逐字保留；③ 全库终扫 **1686 个会话 → 0 阻塞 / 0 潜伏**。
**★ 生效前提（已于 01:38 重启后闭合）**：盘上修好之后，**当前进程内存里仍是旧事件** —— 同一份导出在修复后仍报**同一个 index**（1422 / 8125），而已排除投影缓存（`session_projcache` 不含消息正文，实测 0 命中）与第二份文件（全库仅一份会话日志）⇒ 读到的是**进程内已加载的会话副本**。重启后**三档全部导出成功**（`1220b9a6` 1468 事件 · `4aed6938` 8132 事件 · `71ee2173` 361 事件）。
**★ 修复生效的活证据**：重启后插件**新写入**的注入消息已是正确形状 —— `session-4aed6938` 在 `17:43:01Z`/`17:43:08Z` 的两次注入（`agent/inbox/spliced` + `user/message`）实测 **`content=ARRAY(1)`**，`session-55c8bfa4` 同期注入同形。⇒ 不只是「文件修好了」，是**产线不再生产坏的**。

**八、已知残留（诚实清单 · 已定位到上游）**——平台侧 `assertContent`（**上游 = `deepseek-ai/deepseek-harness`**，`packages/session/session-format-v3-to-v4/src/retired-syntax.ts:11`）对**被解释的 content 槽**是「**有则检查、无则放过**」：该检查**确实在写盘路径上被调用**（同包 `src/codec.ts:46-53` 的 `encodeEvent` → `assertV4RowAdmission` → `case 'user/message'`），但 `if (Array.isArray(content)) …` **没有 else**，故非数组**静默穿过**；而读取层的 `assertMessageEventShape`（`packages/core/session/src/index.ts:356`）才硬性要求 `Array.isArray`。这条**两侧不对称**是静默劣化的温床：任何第三方插件都能这样毒化一个会话，而受害者看到的是"会话坏了"、容器级体检还报 `ok`。建议向上游提「写盘期与读取层对齐（fail-closed 或至少响亮告警）」——**本次未做**（不在本仓可控范围）。



### 同版交付面：批 36「个人任务台账 + 侧栏看板」（2026-10-17）

> **一句话（人话）**：给你和模型**同一套账本**。以前任务散在对话里，聊长了就丢，模型说「做完了」你也没有对照物，**更看不到「什么在等你拍板」**。现在：**看板**（右侧栏一个只读页）· **每回合注入行** · **工具**三面读的是**同一份** `<工作区>/.thincoder/tasks.json`——不是「同一个文件」的口头承诺，而是**三面只调同一个读函数**（结构保证）。**完成必须留凭据**（写不出「跑了什么、看到什么」⇒ 拒写、一个字节都不动）；**待你决策的项单独成区且置顶**；看板**只读**，不能打勾、不能改进度。

**一、为什么要加（人话）**：用户原话三条——「**我这里面看不到待我决策的项**」「**我看到的，跟会话 LLM 看得的是同一套账本吗？如果不是同一套，那就没意义了**」「要是没装 team-link 怎么办？」。批 34 的防漂只锚了**目标层**（目标/判据/证据），**任务层**是空的；而它唯一触及任务的机制落在**另一个插件**里 ⇒ 没装那条就整条失效。

**二、怎么用（人话）**：让模型用四个工具记：`task_add`（建单，**必须写「怎么算完成」**）· `task_update`（改标题/判据/为什么/优先级）· `task_done`（五态流转：待办 → 已接手 → 在做 → 完成/卡住；**完成要凭据**、**卡住要说原因并区分「等外部/等自己动手」**）· `task_list`（读；`view=board` 就是看板）。装了 `dsh-better-sidebar` 则右侧栏多一个 **Thincoder 任务** tab（默认折叠，展开即看：防漂移状态区 → **待你决策（置顶）** → 卡住 → 任务 → 完成计数；点任务可看详情＋一键复制「问这一项」话术）。**没装也能用**：`task_list view=board` 在会话里渲染同一份内容。

**三、改了什么（技术面）**——新增 `lib/tasks.mjs`（**唯一写门** `applyTaskCreate`/`applyTaskUpdate`/`applyTaskTransition` + **唯一读函数** `readTasksView()` + 注入摘要 `renderTaskDigest()` + 结构化文档只读源 `parseChecklistDoc()`）与 `lib/tool-tasks.mjs`（四个工具 + 看板载荷 + 降级渲染）；`lib/index.mjs` **只注册接线**（把任务摘要**并入既有那条** `systemPrompt.context`——**不新开注入通道**）并新增 `GET /thincoder-suite/api/tasks`（看板的数据通道，复用既有信任栅栏）；`lib/client.js` 注册 better-sidebar tab（**只读**，零存储、零写盘）。**落点与键控自建**：`<工作区根>/.thincoder/tasks.json`，键 = 工作区根绝对路径（**明文禁止**照搬 `goal-criteria.json` 的 profile 根做法——那会把文件写错地方）。**多会话并行**：修订号 + 读-改-写冲突检测，冲突 **fail-loud** 且**零写入**。★ **定点修复（2026-10-17 · 独立偏离审计 7 条）**：`task_update` 传**只读字段**（`id`/`kind`/`status`/`evidence`/`blockedReason`/`blockedBy`/`createdAt`/`doneAt`）此前会被工具层的「白名单搬运」**静默丢掉然后写入成功**（调用方以为改了状态，盘上什么都没发生）⇒ 现在工具层**先判越界键**：**整单拒写、逐个点名字段、零写入**（工具描述里那句 `is REFUSED (not silently ignored)` 由此成立）。

**四、有意改锁 / 计数（逐条留痕）**——① `lib/contract-baseline.mjs` 的 `textTool` 注册点 **11 → 15**（+4 工具：`task_add`/`task_update`/`task_done`/`task_list`），同断言在 `test/contract-baseline.test.mjs` 跟到 15，README 头部「N 个工具」由 N-4 腿同批互锁（十一 → 十五）；**`systemPromptSection` 仍为 3**（摘要并入既有 `context`，不挂 section）。② `topAllowed` **8 → 9**（并入 `ledger`）⇒ 白名单散文面三轴锁 `test/config-api.test.mjs` 的 U3c2b 基数 **21 → 22**，散文面三处同改（`cordis.patch.yml` / `README.md` / `config-store.mjs` 头注释）。③ `test/guard-e.test.mjs` 的 T-E19 档清单 **+1**（`tasks.test.mjs`）；`docs/test-lifecycle.md` 新增该档行（**16 条腿** · 层 ② · standing）。

**五、验证读数**——**批 36 实施交付未执行任何命令**（任务书明令：验证命令由宿主执行并回执）。静态读数（父侧可独立复核）：新档 `test/tasks.test.mjs` 顶层 `test(` = **16**（T-1…T-15，T-4 拆 a/b），覆盖设计档 §九 全部 16 条腿；`lib/tasks.mjs` · `lib/tool-tasks.mjs` 只 import `node:` 内建与仓内相对模块（零新增依赖、零宿主 import）；`lib/**` 内 `todo_write`/`todos` 的**引号字面**零命中（软引导只以裸词出现在描述与注释里）。**全量运行计数待宿主实测**（本行**不预填**数字——本仓纪律：只写实测到的读数）。
★ **2026-10-17 定点修复批（独立偏离审计 7 条 · 只修这 7 条）本轮实测读数**：`node --test test/tasks.test.mjs` ⇒ `ℹ tests 16 | ℹ pass 16 | ℹ fail 0`（exit 0，**修前实测 15/16**——红的正是 T-8① 的 realm 缺陷）；文档闸门 `node --test test/doc-hygiene.test.mjs test/test-lifecycle.test.mjs` ⇒ **31/31 绿**（本批改了设计档 §九/§十四/§十五，必须过形状与台账对账闸门）。**全量套件计数（宿主实测，父会话亲跑 2026-10-17）**：`node --test`（全量 **30 档**）⇒ `ℹ tests 647 · ℹ pass 647 · ℹ fail 0`（exit 0）；`test/contract-baseline.test.mjs` 单档 ⇒ `11/11`（exit 0）；`test/tasks.test.mjs` ⇒ `16/16`（exit 0）；文档闸门 ⇒ `31/31`（exit 0）。
★ **一处不可复现的自报读数（如实登记）**：定点修复批自报「全量 `647/646/1`，唯一红项 A28-4，且单档跑同样红」——**宿主用同一条命令实测全绿**（`647/647/0`，且该档单跑 11/11）。该批自陈「本会话没有通用 shell 工具，改用 ego-browser 的 Node 运行时执行命令」⇒ **换了执行宿主，环境（cwd / env / PATH / 可见文件面）与真实宿主不同**，这是该假红最可能的来源。**教训（已记入本仓 AGENTS.md 第 2 节）：「别人的读数 = 未验证」。** 故本批**无需**它提出的 A28-4 任何处置。

**六、文档与评审**：[需求档](./docs/2026-10-16-task-ledger-requirements.md) + [设计档](./docs/2026-10-16-task-ledger-design.md)（设计评审**两轮 21 条**折入，轮 2 `VERDICT: PASS`，令牌有效至 2026-10-23）· [会诊纪要](./docs/consult-minutes/2026-10-16-consult-83-minutes.md)（consult #83，4/5 交付）。**实施期发现（已登记设计档 §十四 与 §十五）**：登记面分两类，**清单与计数分列**——

- **① 父侧在实施前补进 §十四 的 2 处**（新建测试档的**同批登记面**）：`test/guard-e.test.mjs` 的 T-E19 硬编码档清单 · `docs/test-lifecycle.md` 的逐档处置行。
- **② §十五 表内由本批交付机械触发的 6 处**：`lib/contract-baseline.mjs` 与 `test/contract-baseline.test.mjs` 的注册面计数（`textTool` 11 → 15）· `test/config-api.test.mjs` 的白名单基数（8 → 9 / 21 → 22）· `cordis.patch.yml` 的用户层白名单散文段 · `README.md`（白名单段 + 头部「N 个工具」互锁）· `docs/README.md` 的状态行 · `AGENTS.md` 的档数声明（29 → 30）。

这 8 处（2 + 6）都是**由本批交付机械触发的常设锁**，不改就必红。

**七、已知残留（诚实清单）**——① **`tasks.json` 只增不删**（删除/归档排第二批）；② **设置页没有台账表单**（三键在 user 层白名单内，可手编 `config.json` 或走 PUT API，但没有可视控件；★ **已由批 36-补2 补上**，见本档「批 36-补2」一节）；③ **U-1 未实测**：「点一下在侧边开一个会话」这条路径**没有端到端验证过** ⇒ 本批按设计档明写的**降级路径**实现（点开看详情 + 一键复制话术），**不假装支持**；④ **需重启 DSH 才生效**（装配期注册；重启时机由用户定）；⑤ **注入行的精确字数预算**（设计档 U-4）按 512 量级落地，未用真实样本重新标定；⑥ **两条「离开某态即清该态专属字段」的语义是设计档未明写、实现定死的**（离开「卡住」清 `blockedReason`/`blockedBy` · 离开「完成」清 `doneAt`；理由是**板面正确性**——否则会给在做/重开的任务显示陈旧读数）：**2026-10-17 定点修复批已登记**（设计档 **§15.2 第 1 行**，含理由与被否决的备选）；同节第 2、3 行登记另两条**设计档未明写的安全型扩张**（越出工作区的文档路径**拒读且拒在读之前** · 文档路径清单上限 **`MAX_DOC_PATHS = 8`**，读面截断 / 写面拒）。

### 同版交付面：批 36-补「归属与交接 + 用户命令」（2026-10-17）

> **一句话（人话）**：上一版给台账加了「谁记的」，但**一换新会话就失忆**——旧会话记的活在新会话的「本会话」里全部消失。这一版把它补成**可交接**：每条活记住**谁建的（永不改）· 现在归谁（只能由「接手」改）· 接手自谁**；看板分**本会话 / 待接手（N）/ 全部**三个区。轮换新会话时，前任停在「在做/卡住」的活会出现在**待接手**里，**点一下接手**就接着干（只改归属，状态和凭据一字不动）。另外：**模型有工具，你也有命令**——`/task_list` `/task_add` `/task_done` `/task_claim` 四条 slash 命令，与工具**走同一道写门**。

**一、为什么要加（人话）**：用户实测后提了两条——「**其他会话的台账都是空**」与「**做了 `sessionId`，交接轮换新会话的时候怎么办**？」（第二句是用户自己识破的断层：只加 `sessionId` ⇒ 交接即失忆）；外加「**模型工具要有，命令也要有 `/task_add` `/task_list` 等等**」。用户同日裁定：**「待接手区不判会话活性」**（判据只看归属，不看那个会话还活着没有——否则判据会飘）。

**二、怎么用（人话）**：① 看板顶部三个切换按钮 `本会话（N）` / `待接手（N）` / `全部（M）`，默认「本会话」（没有会话 id 时默认「全部」，否则永远是空看板）；② **待接手**区每条带**接手**按钮，点一下 = 走 host 的 `POST /thincoder-suite/api/tasks/claim` → 同一道写门 `applyTaskClaim`（只改 `owner`，并记 `claimedFrom`）；③ 模型侧多一个工具 `task_claim`；④ 命令面四条：`/task_list`（打印三区看板）· `/task_add <标题> | <怎么算完成>` · `/task_done <id> | <凭据>` · `/task_claim <id>`。

**三、改了什么（技术面）**
- `lib/tasks.mjs`：schema 加 **`createdBy` / `owner` / `claimedFrom`** 三字段（读面缺字段 ⇒ `null`，**不迁移、不改写**）；新增**第四个写门动作 `applyTaskClaim`**（只改归属两字段，`status`/`evidence`/`blockedReason`/`blockedBy`/`doneAt`/`createdBy` 逐字不变；走**同一道 rev 门 + 零写入承诺**）；新增归属判据的**单源谓词**（`isOwnedBy` / `isClaimableBy` / `tasksInScope`，看板、工具、命令三面共用）；新增拒绝码 `owner-required`（接手方会话 id 取不到 ⇒ 拒，**不编造归属**）。
- `lib/tool-tasks.mjs`：新增工具 **`task_claim`**；看板载荷改为**三区**（`scopes` + `views.mine/claimable/all` + `defaultScope`，顶层 `sections`/`emptyState` 仍是默认区那份）；待接手行带 `canClaim`；新增 **`buildTaskClaimResult`**（读 rev → 调门 → 回刷新后的整份载荷，**零状态机**）；降级渲染（`renderBoardText`）与工具列表文本同步三区与归属。
- `lib/client.js`：看板加**三区切换**与**接手按钮**（失败如实降级：把等价命令 `/task_claim <id>` ＋ 写门拒绝原文交到手上，**不假装成功**）；折叠态摘要增加「待接手 N」。
- `lib/task-commands.mjs`（**新档**）：四条 slash 命令，**命令契约照官方逐字**（`register({definitionId,name,description,handler})` · `handler(invocation) → Promise<{kind:"success"|"error",text}>` · 生命周期 `ctx.effect(function*(){ yield teardown; yield register })`）。★ `definitionId` 是**纯字符串** `@dsh-external/dsh-thincoder-suite/<name>`（`CommandDefinitionId` 只是类型品牌）——**不 import 任何 `@deepseek-ai/*` 包**。★ **`inject` 数组一字未扩**：命令服务一律 `ctx.get("commands")`，缺它 ⇒ 命令不注册 + warn 一条，**工具与看板照常**。
- `lib/index.mjs`：注册第五个工具 `task_claim`（一个 `textTool` 一个注册点，不循环）· 接线四条命令 · 新增 `POST /thincoder-suite/api/tasks/claim`（复用同一道信任栅栏 `connection.requestRejection`，回调零状态机）。

**四、有意改锁 / 计数（逐条留痕）**——① `lib/contract-baseline.mjs` 的 `textTool` 注册点 **15 → 16**（+1 工具 `task_claim`），同断言在 `test/contract-baseline.test.mjs` 跟到 16，并给该档的中文数词表补 **`十六: 16`**（README 头部「N 个工具」由 N-4 腿同批互锁：十五 → 十六）；**`systemPromptSection` 仍为 3**（本批不新增注入通道）。② `docs/test-lifecycle.md` 的 `tasks.test.mjs` 行 **16 → 21 条腿**（新增 T-16…T-20；该数字由闸门自己 fs+正则算得，非手抄）。③ **本批没有新增 `test/*.test.mjs`** ⇒ `test/guard-e.test.mjs` 的 T-E19 档清单与 `docs/README.md` 的文档地图**无需**改动（五条新腿全部落在既有 `test/tasks.test.mjs` 里）。

**五、验证读数（本会话实测，非预填）**——`node --test test/tasks.test.mjs` ⇒ **`ℹ tests 21 · ℹ pass 21 · ℹ fail 0`**（exit 0；改动前基线 = `16/16` 绿）。文档闸门 `node --test test/doc-hygiene.test.mjs test/test-lifecycle.test.mjs` ⇒ **`ℹ tests 31 · ℹ pass 31 · ℹ fail 0`**。**全量 `node --test`** ⇒ **`ℹ tests 652 · ℹ pass 651 · ℹ fail 1`**，唯一红项 = **`A28-4`**（`contractWatch` 空 ctx 下的版本读数）：本会话用 `git archive HEAD` 导出**未改动的 HEAD** 在同一执行宿主上跑同一档 ⇒ **同样红**（⇒ 与本单改动无关；且与上一交付记录的「换执行宿主导致 A28-4 假红」同族，如实登记、**不处置**）。

**六、已知残留（诚实清单）**——① **命令面未在真机 DSH 上跑过**（本会话无通用 shell、**不重启 DSH**）：`ctx.commands.register` 对 `definitionId` 是否做**运行时品牌校验**未经实测——若真校验，注册会失败并**只 warn 一条、不中断装配**（其余三条与工具/看板不受影响），**本批不为此加宿主依赖**；② **看板「接手」是新增的写入面**（设计档原写「看板零写操作」）：本批把它收窄为「**唯一的看板写入 = 改归属**」，且**状态/凭据仍不可从看板改**（理由见设计档 §16.5 第 1 行）；③ **交接只跨「同一工作区」**：换到另一个工作区（目录变了）就看不到了——台账本来就是按工作区落盘的；④ **不与 `dsh-team-link` 的 `team/<name>/tasks.md` 联动**（那是另一套账）；⑤ **需重启 DSH 才生效**（装配期注册命令与工具）。

### 同版交付面：批 36-补2「设置页台账配置表单」（2026-10-17）

> **一句话（人话）**：台账的三个配置键（开关 / 文档清单 / 话术模板）以前**只能手编 `config.json`，或者自己发 HTTP 请求**——等于「没给设置页就等于默认关着」。现在设置页「Thincoder」里多一张「**个人任务台账（ledger）**」卡片：一个下拉 + 两个文本域，改完点「保存全局默认」就行，和页面其它键走**同一条保存通道**。

**一、为什么要加（人话）**：用户原话——「**三个键目前只能手编 `config.json` 或走 PUT，不手编就用不了**」。后端其实早就齐了（`PUT` 白名单 + 严格校验），**缺的只是界面**。

**二、怎么用（人话）**：① **模式**下拉 `standalone` / `off`（合法值就是这两个，所以不做自由文本）；② **文档路径清单**是一个多行文本域，**一行一个路径**（行序即清单顺序，空行自动忽略，最多 8 条）；③ **复制话术模板**是 3 行高的文本域，右边实时显示「字数 / 500」；④ 你在 user 层从没设过这三键 ⇒ 控件显示**内置默认值**，并标注「未在 user 配置中显式设置 ⇒ 当前用内置默认」；⑤ 保存失败时**原样显示后端返回的 `errors`**（不翻译成另一套码）；⑥ 想全部回到内置默认 ⇒ 用页面底部原有的「恢复默认（删除自定义配置）」（**不新增单键重置**）。

**三、改了什么（技术面）**
- **新档 `lib/ledger-config-text.mjs`**：台账表单的「文本 ↔ 数组」纯函数 + 提前提示（`docPathsToText` / `textToDocPaths` / `ledgerDraftErrors` / `ledgerDraftToPayload`）。常量与谓词**一律 import 自 `lib/tasks.mjs`**，本档不另写一份规则；`copyTemplate` 的字数上限还是**从后端谓词探出来的**（不是另抄一个 500）。
- **`lib/client.js`**：设置段新增「个人任务台账（ledger）」卡片（三控件 + 实时字数/条数 + 空态与来源标注）；草稿增 `ledger` / `ledgerDirty`；`draftToPayload` **只在被用户动过时**才发 `config.ledger`（不把内置默认物化进 user 层）；`effectiveToDraft` 播种、`mergeDraftPreservingTouched` 保留（busy 窗口内的编辑不被刷新覆盖）；保存前的提前提示接在 `ledgerDraftErrors` 上。
- **后端零改动**：`lib/index.mjs` 的 PUT 校验、`lib/config-store.mjs` 的白名单合并、`lib/tasks.mjs` 的归一化**一个字没动**（设计档 §17.2 非目标①：本单不改后端校验）。

**四、有意改锁 / 计数（逐条留痕）**：① **零新增测试档**（`test/*.test.mjs` 仍为 **30** 档）；② **零新增顶层 `test(`**——四条腿**并入既有块**（C-L1/C-L2 → `T-D31`；C-L3 → `U3d`；C-L4 → `U3c2`）⇒ 全量用例总数不变（`docs/test-lifecycle.md` 的 `T-LC2` 用 fs 正则实算与台账对账，该台账档不在本单写域，并入是唯一不越界的做法，理由见设计档 §17.7 第 1 行）；③ **不改任何既有腿的期望值**（本单没让谁「世界变了」）。

**五、验证读数（本会话实测，非预填）**——`node --test test/config-api.test.mjs` ⇒ **`ℹ tests 34 · ℹ pass 34 · ℹ fail 0`**（exit 0；改动前同样是 `34`，因为新腿并入既有块）；`node --test test/tasks.test.mjs` ⇒ **`ℹ tests 21 · ℹ pass 21 · ℹ fail 0`**（exit 0，未因本单变红）；文档闸门 `node --test test/doc-hygiene.test.mjs test/test-lifecycle.test.mjs` ⇒ **`ℹ tests 31 · ℹ pass 31 · ℹ fail 0`**；全量 `node --test`（30 档）⇒ **`ℹ tests 652 · ℹ pass 652 · ℹ fail 0`**（exit 0）。★ **执行宿主如实声明**：本会话**没有通用 shell 工具**，上述命令经插件的 Node 运行时（`ego-browser nodejs` 的 `child_process`）在仓库根执行。**变异自证 10 条**（每条跑完逐字节还原 + sha256 前后一致）逐条列在设计档 **§17.7**；其中四条改的是**后端（临时变异、已还原）**，用来证明 C-L1/C-L2 不是恒真腿。

**六、已知残留（诚实清单）**——① **客户端持有一份「镜像」实现**：`lib/client.js` 是手写 CJS bundle，factory 的 `require` 只认宿主静态模块表（react 等）⇒ **无法 import** `lib/ledger-config-text.mjs`。这是设计档 §17 **未预见的一处缺口**（它要求「前端只用 `ledgerDraftErrors`」，却没说纯函数住 lib、表单住浏览器 bundle 时那条通道怎么走）；本单的处置是**逐夹具行为等值锁 + 常量字面互锁**（C-L4）——两份实现可以共存，但**任何漂移立刻红**（已登记设计档 §17.7 第 2 行，含三条被否决的备选）；② **没在真机设置面板上点过**（本会话无浏览器、**不重启 DSH**）：控件渲染与空态文案是在 node 里用桩 hook 真跑过一版的（读数在设计档 §17.7），但**没有**在真实设置页里点过「保存」按钮；③ 三键仍是**全局 user 层**配置（不按工作区分份，与设计档 §17.2 非目标②一致）；④ **不新增单键重置**（「恢复默认」仍是整节清空，与 §17.4 一致）；⑤ **需刷新页面才看到新卡片**（改的是客户端 bundle；host 侧零改动，因此**不需要重启 DSH** 才能让后端生效——但 DSH 是否重新拉取该 bundle 取决于宿主刷新策略，本会话不重启、也不替用户决定）。



## [0.30.1] — 2026-10-09

> **一句话**：修掉**工程模式实施通道的「派发即死」**——`eng_coder` 把子代理派到**用户早已切换掉的旧模型通道**上（插件拿「建会话那一刻的模型」当「会话现在用的模型」，并**显式覆写**给子代理），并对这次死亡**一个字都不留**（全文只有 `eng_coder ended: error` + 空 partial）。设计档 [`docs/2026-10-09-eng-route-live-design.md`](./docs/2026-10-09-eng-route-live-design.md)。**本版改 `lib/**` ⇒ 重启 DSH 后生效**。

**【计数行】**：`node --test` **594/594**（**基线 594 + 本批 0**：本批全部新腿**并入既有顶层 `test(` 块** ⇒ 顶层用例数不变，台账逐格仍一致）。

**一、D-62 根因（真机取证，不是推测）**——2026-10-09 提交方三次 eng_coder 同签名失败（~19 秒 · 报告 569 B · 空 partial · 子会话仅 header）。三条独立读数钉死根因：① 父会话 `session-9fdfe32c…` 的**每一个** `request/header` 都是 `deepseek-official/deepseek-flash`（用户 18:12:29 切过去）；② 三份失败子会话（`d43a0c32…`/`1733bd62…`/`bd014d26…`）的 `request/header` 却是 `minimax-cn/M3.1-Flash-Preview`——即**建会话那一刻（18:12:19）的部署默认**；③ 三份子会话的 `turn/end` 全是 `{"kind":"error",…"已达到 Token Plan 用量上限…","code":"RATE_LIMIT"}` ⇒ 首次模型请求即 429、重试 5 次退避合计 ≈19 秒（**这就是那 19 秒**）。平台侧规则逐字可查：`@deepseek-ai/dsh-subagent/lib/index.js:406-424` 明写「latest request header owns provider/model/reasoningEffort after request-time selection; creation options remain the fallback **before the first request**」，而 `:436-451` 的 `resolveChildAgentOptions` 里 **`requested`（调用方传的 `agentOptions`）覆盖继承面**；一次性派发路径在 `dsh-subagent-in-process-driver/lib/index.js:186` 逐字消费它。插件旧代码（`lib/eng.mjs:1340` 的 `agent.options ?? {}` → `:1687` / `:1850-1851` 的 `provider: agentOpts.provider`）正是那个「requested」⇒ **子代理被钉在创建期快照上**。提交方怀疑的 `toolFilter.deny` 名域与 `agentPreset:"ptc"` **经取证均不成立**（子会话 36 个事件、`turn/end` 齐全、无 spawn 期抛错；同一会话里跑起来的两名队友 preset 同样是 `ptc`）——如实登记为「已排除」。

**二、修法**——① **新叶子模块 `lib/agent-route.mjs`**：`liveAgentRoute(agent)` 按**平台同款**两级读路由（`session.requestHeader().config` → 首次请求之前回落 `agent.options`），`maxTokens` **恒取创建期选项**（平台 JSDoc 原文「creation options … retain the configured output-token limit」⇒ F9 预算链逐字不变），**永不抛**。② **子代理不再被覆写路由**：两个 spawn 点的 `agentOptions` 收敛为 `{maxTokens, reasoningEffort?}`（后台 ⊕ 同步）——路由交给平台继承，结构性免疫「读错→传错」。③ **effort 按活动路由的模型校验/回落**（旧代码拿创建期快照查支持集 ⇒ 拿错模型回落，2026-09-04 那类秒死的同族风险）。④ **决策同源**：`lib/advisor.mjs`（兜底路由第 4 优先级 + 硬停指纹）与 `lib/index.mjs`（`advisor_config` 显示面 + 设置页 `agentOptionsOf`）一律改读 `liveAgentRoute`——硬停指纹那句「agent **路由变化** ⇒ 失配 ⇒ 硬停自动解除」第一次真正成立。

**三、诊断面（提交方 §6 的诉求逐条落地）**——`stopReason !== "completed"` 分支（后台 + 同步）新增取证件：**本次派发路由 + 子会话 `turn/end.reason`**（复用 `lib/consult.mjs` 的 D-58 读取器，**补导出**、不新建模块）；异常面新增「阶段标记（钉死枚举 `ENG_FAILURE_STAGES`：`ctx.subagents.start` / `watchdog-attach` / `await run.result` / `deliver-bookkeeping` / `host-stage-checks`）+ name + message + **stack 前 3 行**」，`detail` 侧收成 ≤64 字符短句（D-46b 契约），两条腿**都同时 `console.warn`**。真机形态修复后实测报告（同一夹具、修复前后对照）：修复前 = `eng_coder ended: error` + 空 partial（**逐字节等价于 `eng-dsh-29.txt` 的形态**）；修复后 = 追加一行 `eng_coder 失败取证（D-62）：本次派发路由 = deepseek-official/deepseek-flash（request-header）；子会话 turn/end = error: 429 rate_limit_error: 已达到 Token Plan 用量上限 (2056)`。

**四、有意改锁（3 处，逐条留痕）**——① `test/advisor-config.test.mjs` T18 与 `test/codex-runner.test.mjs` 的 eng dsh 行：`assert.equal(ao.provider, …)` 翻转为「**键缺席**」（D1 决策的行为面）；② `lib/contract-baseline.mjs` 锁 ④：从「provider/model 经 `agentOpts` 显式传子代理」翻转为「必须出现 `const route = liveAgentRoute(agent)` 与 `route.provider, route.model`」，并**新增负向锁**（`eng.mjs` 再出现 `provider: agentOpts.provider` / `model: agentOpts.model`，或 `advisor.mjs`/`index.mjs` 再出现 `agent.options ?? {}` ⇒ 红）；③ 取证件落点选在 partial **之后**，以**零改** SITES 16 条 / 17 挂点 / `failStop(` 恒 18 / T-AP2 首段锁（决策 D5）。

**五、验证读数（红→绿）**——**修复前必红**（把 `lib/**` 换回 `6b46978` 后跑新腿）：`eng` 腿 `子代理实际路由必须是**活动路由**（不是创建期快照）: actual 'minimax-cn' / expected 'deepseek-official'` · `advisor` 腿 `第 4 优先级 = **活动路由**: actual 'minimax-cn' / expected 'deepseek-official'` · `provider/model 不得显式覆写（D-62）: {"provider":"acme","model":"model-a","maxTokens":65536}`（3 红）；**修复后全绿**：`node --test` **594/594**（顶层用例数不变），其中 `codex-runner` 190/190 · `contract-baseline`/`platform-surface`/`advisor-config` 全绿，`doc-hygiene`（SITES/V6/V7/V8）· `death-provenance`（T-AP2 首段）· `stage-gate`（T-AP7 定时器）· `job-persistence` 零漂移。

**六、边界与遗留**——路由读取 fail-**open**（读面不可得 ⇒ 交还平台继承；不新增中止/抛出点）；取证 fail-**open**（读不到就**明写**不可读，绝不假装读到）；会话中途换模型**就地读、不缓存**（与平台同一次调用内一致）；平台若给 `session.requestHeader` 改名 ⇒ 回落创建期快照（退化为旧行为而非崩），`contractWatch` **先响的是版本哨兵**（每进程一次、只警告不阻断）——九条锁是**本仓源码文本谓词**，平台改名**不会**让它们变红（2026-10-13 订正：本句原文误称「九锁会在换版时先红」，由会诊 #48 三家独立指出）。遗留登记 **4 条**见设计档 §十（R-62-1 / R-62-2 两条**排除项**（`toolFilter.deny` 名域、`preset:"ptc"`）· R-62-3 观察项（同一份子会话档两处读）· R-62-4 **待评估触点**（`session.requestHeader()` 是本批**新消费**的平台面，尚未进九条触点锁矩阵——读取面已做两级回落，换版时先由版本哨兵告警））。

**七、交付评审（本插件 advisor · `zai-coding-cn:glm-5.3` · 1800s）= PASS**，4 条发现（1 🟡 + 3 🔵）逐条处置并落档设计档 §十一：🟡 = **半空 header 会产出跨源混搭对**（逐键回落 ⇒ `header 的 model ⊕ 创建期的 provider`，且 `source` 谎报 `request-header`；该对象喂 advisor 兜底路由还会绕过其「成对/禁跨环混搭」纪律）⇒ **已修**为**整对语义**（两键都非空才认 header，否则整对回落）＋两腿新断言（红读数：还原逐键逻辑 ⇒「半空 header ⇒ 整对回落」断言红）；🔵#2 = `agent.options` 属性读在 try 之外（理论违反「永不抛」）⇒ **已修**（抛错 getter ⇒ 归零 `{}`，附断言）；🔵#3（同步路径结算期取证件落在失败菜单之后）与 🔵#4（`oneLine` 与 `squashEvidence` 形状重复）**保留并写明理由**（前者受 SITES 第七针约束、同形态 spawn 期失败已落在菜单之前；后者是各自成立的读面，共享化收益仅 5 行）。修复轮后全量 **594/594** 仍绿。

**八、真机装配核验（2026-10-10 重启后，用户执行重启）**——① **进程晚于代码**：DSH 进程启动 10:05:47（2026-10-10），而 0.30.1 的代码落盘 2026-10-09 17:24–17:39、提交 `52f2a2e` 于 17:58 ⇒ 装配读到的是新版。② **判据面自证（最强的一条）**：`contractWatch` 返回九条锁全绿；其中 **ps6 的判据正是本版改判过的那一条**——**旧代码的旧判据**要求 `lib/eng.mjs` 里存在 `provider: agentOpts.provider` / `model: agentOpts.model`，而 0.30.1 已把这两行删掉 ⇒ **若跑的是旧插件，ps6 必红**。实测绿 ⇒ **运行中的插件就是 0.30.1**（无需派发即可判定装配态）。③ 平台版本读数 `0.2.0-rc.2`（源 = `package-json`，evidence 指向 `app.asar` 内 `dsh-app-boot/package.json`）——本次只升插件，不动平台。④ **端到端冒烟（派一次真 `eng_coder`）仍待发生**：它需要真实任务 + 设计令牌，属下一次实施的自然验证点；本版起**即使失败也会自证**（报告会带「派发路由 + 子会话 `turn/end`」一行）。⑤ 核验顺带**修正一处本版自己留下的描述面不一致**：判据 ④ 改判时未同步人读描述——`lib/contract-baseline.mjs` 的 ps6 成功 evidence（**模型可见**，经 `contractWatch` 输出）、`test/platform-surface.test.mjs` 的用例标题、`docs/dsh017-program-closeout.md` 的矩阵行，三处一并改为「活动路由 + D-62 负向锁」口径（全库旧口径残留实测 **0**；改后全量 **594/594** 仍绿）。

## [0.30.0] — 2026-09-30

> **一句话**：批 31 —— **把平台基线抬到 DSH `0.2.0-rc.2` 并逐条复核九条触点锁**，顺手**接上一条一直在空转的防线**（版本哨兵在本机四源全落空 ⇒ 稳定报 unknown，对真实换版零反应）；同时把「只支持 ≥ 0.2.0-rc.1」从一句说明变成**平台自己执行的硬门槛**。**本版改 `lib/**` ⇒ 重启 DSH 后生效**。

**【计数行】**：`node --test` **594/594**（**基线 594 + 本批 0**：本批全部新腿**并入既有顶层 `test(` 块** ⇒ 顶层用例数不变，台账逐格仍一致）。

**一、平台版本 0.1.7-rc.2 → 0.2.0-rc.2（真机逐触点复核，不是看版本号猜）**——对 `app.asar` 内 0.2.0-rc.1 源码逐条复核九条锁的**平台侧形状**，九条全部仍在位：tool-result 仍是**消息级** `role:"tool"` + `toolCallId`/`isError`/`source:{kind:"tool",callId}`（`dsh-llm/lib/types/message.js`）· `jobs.start(spec)` 仍 `resolveOwner(spec.owner)` → `spec.run(handle)`（handle 带 `id`/`append`，`dsh-jobs-local`）· `subagents.start(name, request)` 的 request 键仍是原九键并集（`dsh-subagent`）· `Agent{id,options,session}` 与 `SessionHeader{cwd?,delegationDepth?}`、`AgentOptions{provider?,model?,maxTokens?}` 逐字在位 · `settings.yaml` 仍被导入并改名 `settings.yaml.imported`（`dsh-settings`）· `ctx.tools.register` / `ctx.systemPrompt.section` / `ctx.webServer.register({kind,path,handler})` / `connection.requestRejection(req)→403|401|undefined` 全在（0.2.0 新增 `connection.admit()`，旧面无损保留）· `ctx.llm.stream` 与 `resolveModelInfo()→info.context.contextWindow` 在位。**约十小时后桌面版 nightly 自动升到 `0.2.0-rc.2`**（00:03 下载 / 00:14 安装）：复跑同一套复核——九条形状逐条仍在位，且 **rc.1→rc.2 的运行时面逐字节未变**（对两个 `app.asar` 的 `@deepseek-ai/**` 做 sha256 全量对照：`dsh-jobs` / `dsh-jobs-local` / `dsh-llm/lib/index.js` / `dsh-tools` / `dsh-system-prompt` / `dsh-host-webserver` / `dsh-client-connection` / `dsh-agent` / `dsh-subagent` / `dsh-session` 的运行时 JS **全部相同**；差异只落在 `package.json` 版本号、typert 类型目录与几个 **本插件不消费**的消费者上）。⇒ 本版验证的平台版本 = **`0.2.0-rc.2`**（`^0.2.0-rc.1` 这个 peer 区间天然覆盖 rc.2，故门槛声明不变）。

**二、版本哨兵扩源：三源 → 四源（D31-1）**——批 28 的三源在本机**全部落空**（`contractWatch` 稳定报 `unknown`），于是 0.1.7→0.2.0 这次真实换版**零告警**——「只警告不阻断」的防线在拿不到版本时就等于没有。两条实测硬事实：① 原源③ 的 `@deepseek-ai/dsh-core` **在 0.2.0 里已不存在**（只活在 0.1.x）；② 插件自身模块图 `createRequire(import.meta.url)` **解析不到**任何平台包（桌面版把平台装在 `app.asar` 内，不在 profile 的 `node_modules` 里）。修法：**新增源③ = 平台服务 `pluginManager` 报告的平台自带组合包版本**（只认钉死名单 `@deepseek-ai/dsh-base` / `@deepseek-ai/dsh-web-app`——**刻意不取「任意 `@deepseek-ai/dsh-*` 包」**：本机 profile 里就装着用户侧的 `@deepseek-ai/dsh-token-cost@0.1.0`，取它会稳定假告警，已有负控腿钉住）；源④ 拆两条腿——**④a 桌面 Electron 布局**（`<exe 同级>/resources/app.asar/dsh/node_modules/…`，由 `process.execPath` / `process.resourcesPath` 推出，因为该布局下 `require.resolve` 一定解析不到）→ **④b 常规包解析**；候选名首选 `@deepseek-ai/dsh-app-boot`（平台自己的版本权威 `getDshRuntimeVersion()` 读的就是它），`dsh-core` 殿后只为 0.1.x 兼容。`VERSION_SOURCES` 枚举同步扩为 `ctx.pkg | profile-manifest | plugin-manager | package-json | unknown`。

**二之补（真机读数第二轮）：把「读不到」变成「看得见为什么读不到」**——第一轮真机重启后 `contractWatch` 仍报 `unknown`，而**逐源原因一个字都看不到**（返回体里**版本相关**字段只有 `platformVersion` / `versionSource` 两个，四个源各自为什么落空没有任何出口）。两处修：① 每个源失败都往 `notes` 写**一行可读原因**（缺席 / 抛错原文与 `error.code` / 清单里没有平台成员——含见过的前几条名字），unknown 分支把它汇进 `evidence`，因此 **装配期告警与工具返回都直接带上逐源诊断**；② `contractWatch` 返回体自批 28 起就缺了它**工具描述里承诺过的** `versionEvidence`（描述写着 "shows all nine lock verdicts plus the version evidence"）⇒ 补上该字段（顶层 4 键 → **5 键**），描述同步改写。A28-4 的形状锁随之上调并加一条反向腿（unknown 下必须点名四个源与「逐源诊断」，防它退化成常量串）。**第二轮真机读数（基线抬到 rc.2 后）实测：源④a 命中**，`versionSource` = `package-json`、`versionEvidence` 直接给出 `…app.asar\dsh\node_modules\@deepseek-ai\dsh-app-boot\package.json version = 0.2.0-rc.2`——哨兵自批 28 上线以来**第一次真正读到平台版本**。

**二之补之二（同日真机复盘补）：unknown 时交出「同一时刻的第二读数」（旁证）**——真机 00:16 那次 `contractWatch` 报 `unknown`，事后**无从复盘**：装配期 warn 只进宿主 stderr（DSH 只在内存里滚动、异常退出才 dump，那次没留下），返回体里也没有任何可比对的第二数。**刻意不把它做成第五个源**：`<DSH_HOME>/dsh-runtimes/<name>/runtime.json` 的 `desktopVersion` 会滞后也会领先（实测第一次读是 `0.2.0-rc.1` 而平台已是 `0.2.0-rc.2`，几分钟后再读它自己又变成了 rc.2）——拿它当源等于把「读不到」换成「读错」，而**哨兵假告警比哨兵瞎更坏**：瞎了你知道去查，假告警会让你去改本来没坏的东西。修法：unknown 分支的 `evidence` 追加一段**旁证**（`runtime.json` 的 `desktopVersion` ＋ 更新器 `pending/update-info.json` 的 `fileName`，各带 mtime），并当场标注「**不参与判定**，会滞后也会领先，只供人判读」；**判定面逐字不变**（`versionSource` 仍是 `unknown`，`VERSION_SOURCES` 一个成员都不加）。真机实测当口发现并修掉一处自身缺陷：旁证② 第一版按目录名 `/updater$/` 匹配，把本机 `%LOCALAPPDATA%` 下**别的** electron-updater 应用（MiniMax Code / ZCode / Cherry Studio / uTools / NGP…）的版本也一并刷进 evidence（**2026-10-01 复测**：本机 6 个 `*updater\pending\update-info.json`，其中 DSH 自己 1 个、别家 5 个；该数随安装完成而变，故正文只写「别的」、不复述数字）—— 那正是本档在源④a 处明确反对过的「把 evidence 刷成路径墙」；改为目录名粗筛（含 dsh）＋ 载荷名精确判据 ＋ 只取第一条，并加「非 DSH 的 updater 一个字都不许进」负控腿。**变异验证**：摘掉旁证那一行 ⇒ `contract-baseline` **`pass 9 / fail 1`**（只有 A28-3 转红，其余九条不动）；绿相 `contract-baseline` 10/10 · `platform-surface` 12/12 · `doc-hygiene` 25/25 · `ledger-parity` 6/6 · `release-check` 9/9。新腿**并入既有 A28-3 块** ⇒ 顶层用例数仍 10（本版计数行 594/594 不变）。**★ tag 交叉指引**：本段描述的实现与测试**已经在 `v0.30.0`（`b38804b`）里**（它们是那次收口时随工作树一并提交的），但**本段说明本身由 `8dc7eac` 补入、落在 tag 之后** ⇒ 只读 tag 内 CHANGELOG 的人看不到它。读 tag 的变更说明时把本段当作它的补充；tag 里的**代码**与主分支这份逐字一致（`git diff --stat v0.30.0..HEAD` 只有 CHANGELOG 的增行）。

**三、支持门槛交给平台执行（D31-2）**——`package.json` 新增 `peerDependencies: { "@deepseek-ai/dsh": "^0.2.0-rc.1" }`。**peer 不是依赖**（dependencies / devDependencies 两处仍为空）：它把「本版只支持 ≥ 0.2.0-rc.1」交给**平台自己的**组合兼容闸门 `evaluatePluginCompatibility`（`dsh-app-boot`）在装配前执行 ⇒ 低版平台上**整包被跳过**并附豁免指引，而不是半残运行；README 与 `contractWatch` 工具描述同步给出「旧 DSH 请改装 **v0.29.11**（支持 0.1.7-rc.2）」的指引。

**四、D-61（🔴 诊断信息静默丢失）**——`streamObservationLine` 读 `finish?.usage`，而平台的 `StreamChunk` 联合**自 0.0.1-rc.5 起**就把用量发成**独立 chunk** `{type:"usage", usage}`（`finish` 只有 `{reason, replayState?}`；0.2.0-rc.2 逐字同）⇒ 该行**恒打 `usage=none`**。修法：`collectStream` 收集 `usage` chunk 并一路带到观测行（`finish?.usage` 保留为兜底，防御未来合并形态）；用例改喂**平台真实形状**（原腿喂的是平台不会发出的形状，所以一直绿而缺陷一直在）。

**五、顺带登记（不改行为）**——`package.json` 的 `dsh.client.inject` 里列着的 `@deepseek-ai/dsh-client-runtime` **在 0.2.0 平台包树中已不存在**；该字段是**软排序提示**（平台查不到对应 client 模块行即跳过，`dsh-client-modules` 的 `arriveGraphRow`），且本插件 client 半边只 `require("react")` ⇒ **不影响设置页**，本版不动它，只在此如实登记。第二处登记：`dsh.client.inject` 与 `publish` 口径均未变，`peerDependencies` 新增键已在上文第三节交代。

**六、评审收口（第四轮 6 条全部处置：1 🟡 + 5 🔵）**——
① **轮内剩余预算加 1ms 下界**（`lib/advisor.mjs` 的 `runAdvisorToolLoop` 调用点）：循环顶的预算判定与取剩余预算之间存在 tick 边界竞态，余量若算出 ≤0，`collectStream` 会把「已到点」折成「没有截止」（`deadlineAt = null`）⇒ 该次调用**连 chunk 墙钟双检一起失效**、只剩 idle 看门狗。收口放在**调用点**而非 `collectStream` 内：后者被 **T-AP7 的冻结锁**钉死了 `setTimeout` 第二实参的逐字表达式（改它就是改机制本体）⇒ 既补上竞态窗口，又不动被冻结的条件；同一 test 块新增两条源码腿（下界在场 / 无下界的旧写法零残留）。
② **runner 字段提示单点化**：`lib/codex-adapter.mjs` 新增 `CODEX_RUNNER_VALUE_HINT`（由已有的 `CODEX_ROW_FIELDS` 渲染），`lib/advisor.mjs` 两处提示（`resolveAdvisorRoute` 的 `expected("runner")` 与 `coerceValue` 报错文案）改为同源引用——此前两处**各写各的**，且**都漏了 `executable`**、其中一处还漏了 `"dsh"` 这个合法简写。
③ **文档卫生三处**：CHANGELOG 版本头日期统一为 2026-09-30（与 README/交接页/基线记录同日）；「二之补」里「工具返回体只有两字段」收窄为「**版本相关**字段只有两个」（否则与同段「4 键 → 5 键」自相矛盾）；全库检索同类声明，README/结项页/交接页/哨兵的基线与门槛口径逐处对齐（含 `0.2.0-rc.1` 的两类正当留白：peer 门槛与 as-of 历史）。
④ **源④ 候选名的权威性如实登记**：`PLATFORM_PACKAGE_NAMES` 的 doc 写明 `dsh-base`/`dsh-core` 只是兜底、**版本权威性弱于 `dsh-app-boot`**，命中时以 evidence 判读，不当硬结论。
⑤ **测试时序腿（未决）**：`test/codex-runner.test.mjs` 里若干依赖真实墙钟的腿（`elapsed < 5000` / `sleep(800)` 等）与 README「已知未决」登记的全量偶发同族，**属既有形态**，本版不动；改假时钟是同族统一维护的活（先例：`T-AP4b` 的 D-51 假时钟），留作下一维护轮的候选。
**第五轮复核 = PASS**（逐条核实上述 5 处已修/已登记），并当场改正一处**它新指出的计数漂移**（本节标题原写「第三轮发现的 9 条」，实际收口的是**第四轮的 6 条**）。⇒ 批 31 累计 **5 轮评审、16 条发现全部处置至 PASS**（轮 1 🟡1🔵3 · 轮 2 复核 PASS · 轮 3 🟡1🔵4 · 轮 4 🟡1🔵5 · 轮 5 复核 PASS + 1 计数漂移当场修）。

## [0.29.11] — 2026-09-28

> **一句话**：批 30 —— **把两条「空转的防线」真接上**（工具面按 Agent scope 读名域 · 静默看门狗改接 `seq` 与 `ctx` 事件面），修掉**会丢证据**的落盘缺陷，并把会诊从「真根因不可见」救回来。**本版改 `lib/**` ⇒ 重启 DSH 后生效**。

**【计数行】**：`node --test` **594/594**（**基线 594 + 本批 0**：本批全部新腿**并入既有顶层 `test(` 块** ⇒ 顶层用例数不变，台账逐格仍一致）。

**一、D-55 工具面禁执行：从「空转」到真按名域拦**——读取面改**带 scope**（`tools.view(agent).restrictableNames`，退路 `schemas(agent)` 且剔 `run_code`）；**绝不猜名**（未注册名会抛错 ⇒ setup 抛错=整次派发失败）；两级都拿不到 ⇒ 如实标注、**不下发任何执行类名**；证据行附**名下来源**与**残余风险**（`run_code` 是平台保留传输面、不可被 restrict 收窄 ⇒ 命名面收窄 + 残余绕行口如实标注）。
**二、D-56 静默看门狗：从「探错对象」到真武装**——run 对象是**声明 4 键**（`id/localAgent/result/dispose`）；心跳改接 ① `sub.localAgent?.session?.seq` 轮询（**复用既有 `setInterval`，不新增轮询者**）② `ctx.on('agent/assistant-stream'|'tools/result', …, {global:true})` **按子 id 过滤**（`off()` 在派发返回/异常/静默终止三条路径统一摘除）；`subagent/start|end` 只作就绪/终局锚；**首次心跳前不武装**；`localAgent === undefined` 如实降级。
**三、D-57 落盘只增不减**——`persistJobReport` 写前读回：新文本更短**且**现值以其为前缀（= 前缀形截断）⇒ **保留现值** + 裸 warn；残余窗口（更短的非前缀写仍可缩水）如实登记。
**四、D-58/D-59/D-60（会诊三连）**——**D-58**：注入面消毒（ZWSP 断开裸引用形态，两分支）+ 失败时**兜底读子会话落盘 `turn/end.reason`**（多帧 zstd 切帧）+ codex 行不再吞 diagnostics；**D-59**：池行**前置可用性预检**（模型目录/effort 元数据；**账号类型不可预检 ⇒ 只暴露诊断**）；**D-60**：「只读」声明由**模型面证据**（子会话 `request/header`）裁定——本部署实测模型面 = `[run_code]` 单元素、子会话 `danger-full-access` ⇒ **会诊产物逐字带出「本部署无法保证只读」**（派发 detail + digest 同源）。
**五、判据升级**：任何「工具面/只读已生效」的断言，证据**必须是模型请求头里的工具面**，**不得**以「restrict 未抛错」代替（A30-12 为真机项，已在轮 2 审计中被真机读到：299 帧内恰 1 条 `request/header`，`tools=[run_code]`）。
**六、勘误（2026-09-28 同日补记 · 不改动任何已交付行为，只更正定性）**：**D-45 的定性撤回**。本版及批 26 一直把 `job_output` 读不回归因于「平台自身读法缺陷、本仓不可修」。当日**运行时取证**（往 profile 的 `cordis.patch.yml` 热插一个探针插件，零重启拿到 `ctx.jobs` 的运行时读数）推翻该结论：真因是**第三方插件** `@dsh-external/dsh-task-status`（上游 `vlln/dsh-task-status`，未适配 0.1.7）在 `apply()` 里给 `ctx.jobs.read` 打镜像补丁、按 0.1.6 契约重写信封 `{ text, snapshot }`，丢弃 0.1.7 的 `{ chunks, lossy, result?, job }` ⇒ 下游 `readBody` 读 `read.job.output` 即崩（同一链路亦解释 promoted `pwsh` 的 `reading 'filter'`）。**已卸载该插件；卸载后 `job_output` 与 promoted 读取立刻恢复**（同机同日实测，未重启、未改平台包）。⇒ **平台侧无缺陷**；`docs/upstream-2026-09-26-platform-issues.md` 的**问题一已撤回**；批 26 的落盘兜底**降为附加保险**。取证（探针读数）与上游同款告警见 `docs/job-output-fallback.md` §0。

## [0.29.10] — 2026-09-27

> **一句话**：批 29 的**收尾三件套**——把 D-53 的证据从「按构造读不到」搬进**可读回执区**、**真机取证收口**，并如实登记它揭露的**三条新缺陷**；同时收干 §2.7 的测试健壮性四项与 §2.9 的六条 🔵。**本版改 `lib/**` ⇒ 重启 DSH 后生效**。

**【计数行】**：`node --test` **594/594**（**基线 588 + 本批 6**：`test/silence-watchdog.test.mjs` 11 → **17**〔§2.8 的 A29-13/A29-14 · 修复轮 2 腿 · §2.9 的 A29-15/A29-16〕）。

**一、D-53 真机取证：两条机制在本部署上都是「空转」（诚实降级被验证有效）**

- **证据**（`$DSH_HOME/.thincoder/jobs/eng-dsh-2.txt` 回执区**之后**，真机非夹具）：① `工具面禁执行未生效：注册面里没有命中执行类谓词的工具名…；ctx.tools 方法名清单 = ctx, name, deferredContexts, …, ptcTransport, canonicalResults (共 12 项)`；② `静默看门狗接线留档：attached=false，零候选事件面；run 键清单 = id, localAgent, result, dispose (共 4 项)`。
- **结论**：本部署 **run 对象只有 4 键、无可订阅事件面** ⇒ 看门狗**无法武装**；`ctx.tools` 的 12 个方法名里**没有清单访问器** ⇒ 工具面**找不到执行类工具名**、`applied:false` ⇒ **子代理仍能跑 `pwsh`**（同批审计在子代理内实跑 `git status`/`git diff` 成功）。**D-50 的「如实标注、不假装拦住」纪律被真机验证有效**；但「能拦就拦 / 拦不住就掐」在本平台**做不到**。
- **新登记**：**D-55**（工具面拦不住）· **D-56**（看门狗无法武装 ⇒ D-50 两次 8/60 分钟事故在生产仍会烧满）· **D-57**（作业报告落盘**非单调**，同一 `<jobId>.txt` 会被后续写入截断覆盖——**本次证据差点因此丢失**，靠另一会话的 job 报告留存）。

**二、§2.8：把留档搬进可读通道**（入队 + 由宿主验收回执书写处在**交付正文之后**追加小节；裸 `console.warn` 保留但不再是唯一通道）· **🔴 空搬运提前关闸已修**（审计发现：`drainArchiveBlock` 先置闩再判空 ⇒ 一次「暂无留档」的搬运会**永久关死通道**；现判空先于置闩，并补决定性腿）。

**三、§2.7 / §2.9：测试健壮性与六条 🔵**（条件驱动泵 · `f.drop()` 进 `finally` · 决定性注释 · partial 归一**吃内部折行**且填充仍必红 · 非法值**双口径**渲染 · `null` 视同缺失 · 键名折叠保证单行 · 缓冲与裸 warn **同源** · A29-8c 初始态自持）。

**四、设计档归一两处口径冲突**（评审 🔴）：阶段门 §2.1② 与登记表 D-50 对「零事件是否武装」给出**不兼容规格** ⇒ 归一到实现与 D9 腿所在的一侧：新增「**②′ 武装纪律**：首次真实事件前不武装 ⇒ 零事件不误杀、退回总预算」+ **代价如实声明**（从派发起零事件的挂死不吃早停）；另消解 §2.1 的 ② 重号、补 §3 的 D-54 行、AC-6 纳入 A29-7、AC-7 改为「待修 0 或仅余环境取证项」。

**五、批 30 候选池**（设计档 §6.1，逐条不丢）：D-55/D-56/D-57 · §2.9 码评 5 条 🔵 · §2.9 审计 D2（A29-15 未钉「折叠先于截断」）· D3（🔵5 不可机验，登记为覆盖边界）。
## [0.29.9] — 2026-09-26

> **一句话**：批 29 的**收尾小单**——给「看门狗/禁执行在生产上到底生效吗」装上**一次性的真机留档**（首派即取证），顺手把 `maxFiles` 与 `maxAgeDays` 收成**同向**（同一函数里不许有两把方向相反的「清空」脚枪）。**本版改 `lib/**` ⇒ 重启 DSH 后生效**。

**批 29 收尾（设计 §2.6 + 审计 F1/F2 收敛）**

- **【计数行】**：`node --test` **588/588**（**基线 584 + 本批 4**：`test/silence-watchdog.test.mjs` 8 → **11**〔A29-8a/b/c〕· `test/job-persistence.test.mjs` 12 → **13**〔A29-9〕）。
- **US-A（D-53 一次性留档）**：看门狗**接线首次结果**留一条裸 `console.warn`（attached 真 ⇒ **记下命中的候选方法名**；假 ⇒ 列 `Object.keys(run)`，有界/去重/48 字截断、Proxy 抛错不抛）· 工具面**首次未生效**时在同一行追加 `Object.keys(ctx.tools)`；两条都**进程内只一次**、**绝不进返回文本**。候选表**一字未动**（不猜新名）。
- **US-B（`maxFiles` 同向收紧）**：`Number.isFinite(o.maxFiles) && o.maxFiles > 0 ? o.maxFiles : 200`（缺省 **200 不变**；旧的 `>= 0` 与 `Number.isInteger` 谓词已删 ⇒ **正有限小数仍生效**）。
- **审计 F1/F2 收敛**（只改测试、零 lib 改动）：F1 把 A29-8a 的断言改成**相邻字面**「命中候选事件面「onEvent」」（此前被同一行的 run 键清单满足 ⇒ 删掉命中分支也不会红）；F2 补「**交付正文**零留档字样」断言（此前只盖到派发回执，未盖 `jobOutcome` 写的交付正文）。
- **真机观察（如实留痕，含一次U防伪）**：本批一度以为拿到了 D-53 的生产证据（job 输出里出现「工具面禁执行已下发（deny 追加 pwsh, bash）」与「疑似挂死（静默 1 分钟）…engSilenceAbortMs=60000ms」两行）——**核对后判定为宿主验收回执里 `node --test` 的尾部输出**（那两行是 A29-8a/b/c **夹具**用 60 秒假阈值 + 假工具面产生的回声；配置缺省是 300000，对不上即露馅）⇒ **不作为证据**，D-53 保持待修。
- **顺带实证（真）**：同一条回执证明 **D-48 的「宿主验收回执」在生产运行**——插件自己执行 stage 的 `check` 命令并把尾部输出写进交付报告，且明注「本回执不是作业终态，作业状态不变」。
- **残留**：**D-53**（看门狗/禁执行的**生产生效性**）——留档机制已落地并有腿（A29-8a/b/c），但**读出一手证据需要重启 + 一次真机派发**（运行中进程仍载旧码，本批两次派发都没打印留档行）。
## [0.29.8] — 2026-09-26

> **一句话**：**把门禁变可信**——让子代理**根本跑不了**验证命令（工具面禁执行）、卡住时**静默 5 分钟就掐**（不再白等 60 分钟）、把 `check` 的语义从「子代理自检」正名为「宿主验收清单」；顺手把**阶段门那条恒假阳性**（每次交付都喊 UNDECLARED）修成真谓词；并收掉批 27/28 交付码评留下的 7 条 🔵 与会诊只读白名单的锁缺口。**本版改 `lib/**` ⇒ 重启 DSH 后生效**。

**批 29（把门禁变可信：D-50 · D-51 · D-52 · D-54）**

- **【计数行】**：`node --test` **584/584**（**基线 567 + 本批 17**：新档 `test/silence-watchdog.test.mjs` +8 · 新档 `test/repro-script-readonly.test.mjs` +2 · `test/stage-gate.test.mjs` 6→7 · `contract-baseline` 8→10 · `job-persistence` 9→12 · `consult` 6→7）。⇒ 台账 §三新增两行，档数 **26 → 28**。
- **D-50（🔴 流程：`eng_coder` 自跑进程内验证撞兜底）修法**：① **工具面禁执行**——`toolFilter` 只下发**与平台公开面 `view().restrictableNames` 求交后**的名字（**平台保留名 `run_code` 一命名即抛错**，已从谓词移除）；取不到该面 ⇒ `applied:false` + **裸 warn「未生效」** + deny 逐字基线（**不假装拦住**）。② **静默看门狗**——叶子模块 `lib/silence-watchdog.mjs`（`ENG_SILENCE_ABORT_MS` 缺省 300000）；心跳取自 `run()` 子代理事件面观察（**不用** `job_output` 轮询）；**首次真实事件前不武装**（零事件不误杀，退回总预算）；到点由既有取消写点中止，文案含「疑似挂死」。③ `stages[].check` **语义正名**「宿主验收清单」（host 态标签含「由宿主执行，你不要执行」；非 host 态逐字节不变）。
- **D-51（🟡 `T-AP4b` 偶发红）修法**：改**假时钟**（只替换 `Date.now`，零真实等待）⇒ 宿主**受控负载 N=20 零红**；同档其余 7 条依赖真实等待的腿**逐条点名**并只加**失败差量输出**（清单落在设计档以保证可核）。
- **D-52（🟡 会诊只读白名单无对位锁）修法**：加静态 + 行为两条对位锁（`test/consult.test.mjs`）；**`lib/consult.mjs` 零改动**（平台契约复核：`allow` = keep only、未注册名**响亮拒绝**）。
- **D-54（🟡 阶段门恒假阳性）修法**：原谓词要求**恰 3 列 + 英文 `stage`/`status`/`summary`**，而真实报告是中文表头或多一列 ⇒ **每次交付都喊 UNDECLARED**（恒假阳性 = 门不存在）。现改为 **≥3 列按名定位**（中英列名与状态词、容忍粗体/代码记号）、**保留**「无表 ⇒ UNDECLARED」与 4000 字符窗、横幅**按「无表 / 表在场但不可解析」分岔**；新增 **T-SG7 五类**用例 + 还原即红（旧谓词字面实测归零）。
- **七条 🔵 收干**（批 27/28 交付码评）：`maxAgeDays` 校验收紧为 `> 0` + JSDoc 理由 · `kept` 口径注释 · 零落盘测试缝（含生产零引用静态锁）· 键过滤化简 · `once` 占坑语义注释 · 版本词元大小写归一 · 复现脚本只读声明按 `$tempHomeOk` 分支。
- **A28-6 机验腿**：新档 `test/repro-script-readonly.test.mjs`——五条只读谓词（每条带**阳性/阴性自证**）+ 脚本声明的 if/else **结构级**断言。
- **流程实据（如实留痕）**：本批遭遇**环境侧故障**（插件 spawned-child 派发路径自 14:22 起**派发即死**；判别探针证明平台子代理面正常）⇒ 用户裁定**改道** harness subagent 实现，**程序性例外已记设计档 §7**（旁路令牌/阶段门；验收**加强**为「宿主全量 + 分歧审计 + 交付码评」三道）。两轮**只读分歧审计**分别判定「需修复轮」，并挖出 **`run_code` 保留名地雷**（一旦探测生效会打断派发）与**空集面未接线**等问题；**另一会话的独立反馈**促成 D-54 的发现。
- **残留**：**D-53**（看门狗/禁执行的**生产生效性**未验证——需一次真机派发，届时按「首派一次性留档」闭环）· `maxFiles: 0` 的同族语义（相邻参数，未在本批改动面内）· 同步快路径不装看门狗（设计口径，由 `budgetCap` 兜底）。
## [0.29.7] — 2026-09-26

> **一句话**：**对外收口**——把三条平台问题整理成**可一击复现的上游报告包**；给插件装上**版本哨兵**（平台换契约时响亮提示，而不是撞）；把九条触点矩阵收成**单一事实源**；出一份结项说明。**本版改 `lib/**` ⇒ 重启 DSH 后生效**。

**批 28（对外收口：上游报告包 ⊕ 版本哨兵 ⊕ 契约面巡检 ⊕ 结项说明）**

- **【计数行】**：`node --test` **567/567**（**基线 559 + 本批 8**：新档 `test/contract-baseline.test.mjs` +8）。⇒ 台账 §三新增一行，档数 **25 → 26**。
- **US-1 上游报告包**：`docs/upstream-2026-09-26-platform-issues.md`（三问题各含 现象/最小复现/一手证据/影响面/给上游的建议）+ 只读复现脚本 `scripts/repro-platform-issues.ps1`（零写仓、零 `git`、纯 ASCII）。
- **US-2 版本哨兵**：装配期读平台版本（**三源钉死顺序** + **来源 evidence**）并与基线对照——一致⇒静默；不一致⇒**一条响亮告警且不阻断装配**；取不到⇒标 `unknown` 也不崩（`lib/contract-baseline.mjs` + `lib/index.mjs`）。
- **US-3 契约面巡检**：**只读**工具 `contractWatch` 一次返回 `{platformVersion, versionSource, locks(9 条·三态), jobsDir}`；九条谓词**实现单源**（`test/platform-surface.test.mjs` 删净 231 行谓词体、改为 import）。
- **US-4 结项说明**：`docs/dsh017-program-closeout.md`（批次脉络 24–28 · 矩阵**只做指针 + 摘要**〔权威源 = `lib/contract-baseline.mjs`〕· 四道护栏 · 「平台换契约的标准动作」）。
- **同批上调常设锁**：批 26 锁 #7「注册面期望计数」**7 → 8**（新增 `contractWatch`；理由写在 `lib/contract-baseline.mjs` 注释内，经副本变异实测承重）。
- **流程实据**：设计评审 3 轮至 PASS（第 2 轮抓到我自己引入的两处档面矛盾）· 实现 `eng-dsh-6` 在**自检阶段**撞满 60 分钟兜底被 abort（⇒ 发现即登记 **D-50**）· 只读分歧审计判定**代码面干净**（零半截写入、零未接线、锁活性经副本变异实测为真），并**用副本复算**确认收口期的 4 条红全属登记级联 · 收口期新登记 **D-51**（`T-AP4b` 偶发红，附实测频次）。
- **残留（转批 29 候选，本批如实划出）**：**D-50**（eng_coder 自跑进程内验证撞兜底，两次同款）· **D-51**（偶发红）· **A28-6 的机验腿**（脚本只读性本批以人眼核验背书，未补静态腿）。
## [0.29.6] — 2026-09-26

> **一句话**：**收拾干净**——作业落盘目录不再只增不减、索引重写零伪造、`cwdHint` 接上最后一处（D-40/D-44 同一条纪律）、宿主验收执行面的 kill 语义收窄、非法 `pathForm` 变可见。**本版改 `lib/**` ⇒ 重启 DSH 后生效**。

**批 27（残差清零：把批 26 的四条 🔵 与划出去的边界收干）**

- **【计数行】**：`node --test` **559/559**（**基线 545 + 本批 14**：新档 `test/job-persistence.test.mjs` +9 · 新档 `test/host-check.test.mjs` +5）。⇒ 台账 §三新增两行，档数 **23 → 25**。
- **D-49（🟡 声明面 ≠ 实际面，批内已修）**：清扫声明「只碰四类 kind」，实现却另外删 `.index.jsonl.tmp-*`，且手写 tmp+rename（重复造轮）。修法：改用 `lib/dsh-home.mjs` 的 `writeFileAtomic`（`.<base>.tmp-` 前缀自带陈旧清理 + rename 有界重试）⇒ 声明与实现一致、轮子消除。
- **US-1 清扫/轮转**：`sweepJobReports({maxAgeDays=7, maxFiles=200})`——**只认** `/^(advisor|consult|eng|escalate)-[A-Za-z0-9._-]+\.txt$/`（平台 `pwsh-*` 等形态**永不触碰**）；天数轴 + 条数轴双上限；索引只保留**仍存在文件**的行、**零伪造**（存活行与原行逐字节相同）；persist 成功后尽力而为，任何失败只 warn。
- **US-2/3/4**：非法 `pathForm` ⇒ warn 一行且不抛 · 超时值域解析**单点**（`effectiveTimeoutMs`）· `finish()` 只在超时/未收到 close 时 kill（正常 close ⇒ clearTimeout + settle）。
- **US-5**：`jobOutcome(handle, outcome, opts?)` 增可选 `cwdHint` ⇒ `pickDshHome` 不再拿 `process.cwd()` 猜基座（与 D-40/D-44 同一物种的最后一处）；四档 28 处调用点统一加 `jobPersistOpts`，**缺省行为逐字不变**。
- **US-6**：无 `DSH_HOME` ⇒ **零落盘**回归锚（复用既有注入缝）· 清掉批 26 实现窗口留下的一次性产物 `smoke-nohome-1.txt`。**订正一处自查误判**：初判为「测试隔离泄漏」，经 `git log -S` 全历史检索证本仓无该字面 ⇒ 已撤销「隔离缝改造」设计项（设计档 §1⑥ 留痕）。
- **流程实据**：设计评审 3 轮至 PASS · 首轮交付 558/552/6 → **分歧审计**（只读）判定「需修复轮」（1 条自伤 + 5 条登记级联）→ 修复轮 `eng-dsh-4` 逐条收敛 → 交付码评 · **落盘通道二次实证**：`eng-dsh-4.txt`（8405 字节）由宿主直接读回，全程未借 `job_output`。
- **残留（边界）**：索引与「手工删文件」之间存在一段不一致窗口（下次成功落盘即自愈）· 清扫不碰他形态产物（需人工清）。
## [0.29.5] — 2026-09-26

> **一句话**：**把报告拿回来**——后台作业的全文不再依赖平台那条坏掉的读取口，跑完就落在盘上（`$DSH_HOME/.thincoder/jobs/<jobId>.txt`）；同时**把验证门归位**（dsh 子代理不再自己跑 check，改由宿主执行并回执）。**本版改 `lib/**` ⇒ 重启 DSH 后生效**（实测：本版落地后运行中实例已自动重载，`eng-dsh-1` 的报告确实落盘可读）。

**批 26（把报告拿回来 ⊕ 把验证门归位：D-45 · D-47 · D-48）**

- **【计数行】**：`node --test` **545/545**（**基线 527 + 本批 18**：D-45 = `test/dsh017-compat.test.mjs` +5〔A26-1/A26-1b/A26-2/index.jsonl 形状/pathForm 跨四机制〕· 新档 `test/platform-surface.test.mjs` +12〔九条触点常设锁 + A26-6/A26-7/A26-8〕· D-47 = `test/guard-e.test.mjs` +1〔A26-3〕）。⇒ 台账 §三：`dsh017-compat.test.mjs` **9 → 14** · `guard-e.test.mjs` **24 → 25** · **新增 `platform-surface.test.mjs`（12）**；档数 **22 → 23**。
- **D-45（🟡 报告拿不回）**：`job_output` 在这台机器上对**所有**作业都崩（含平台自产）⇒ 报告正文无第二条可读路径。修法：`lib/job-outcome.mjs` 在**收口点**把正文写到 `$DSH_HOME/.thincoder/jobs/<jobId>.txt`（`jobId = handle?.id`），并追加 `index.jsonl` 记 `{jobId,kind,at,bytes,pathForm}`（`pathForm` 钉死枚举 result/ring/session-state/consult-minutes/none，由**实际携带正文的通道**判定）；四条机制全文统一落盘；派发文案与工具描述改「**首选读落盘文件**，`job_output` 作附加」。**实证**：`eng-dsh-1.txt`（12262 字节）已落盘并被宿主读回。**环境实验**：干净移除 profile 自带的 rc.1 jobs 副本后重启，`job_output` **仍崩** ⇒ ~~平台自身读法缺陷（不属本仓，建议上游修）~~ **★ 2026-09-28 勘误：此处的定性与该推论已撤回——真因是本机第三方插件 `@dsh-external/dsh-task-status` 改写 `ctx.jobs.read`，非平台缺陷；卸载后即时恢复。见 [0.29.11] 第六节。**
- **D-47（🟡 门禁 fail-open）**：`makeDocFreezeGate` 的 `target` 归一带 `process.cwd()` ⇒ 相对路径对不上绝对冻结集即**静默放行**。修法：归一改传 `agent.session.header.cwd`（与 D-44 同款来源）；**A2 夹具零改动**（实测其只锁 `makeWriteGate` 的可执行行）；新增 A26-3 腿（相对路径命中 ⇒ deny + 负控放行）。
- **D-48（🔴 验证相位挂死）**：dsh 子代理跑 stages 的 `check` 命令时**既不报错也不返回**（实测挂 8 分钟、日志 0 字节，而宿主同命令 7.24 秒全绿）。修法：**D48-1** 新增 `stages[].checkMode`（dsh 缺省 `host`）⇒ 任务书不再要求子代理执行命令 · **D48-2** 新增 `lib/host-check.mjs` 承接宿主验收执行面（独立 120s 超时并收敛为 `timed out`、失败只标回执 FAIL 而**不改作业状态**）——抽成 leaf 模块是为了**不撞**常驻锁 T-AP7（该锁把四档的定时器标识逐字钉死并与 HEAD 交叉核验，结构上不可再容纳新定时器）· **D48-3** 兜底信封附 stages 的 check 命令原文 + 取证指路 · **D48-4** 上游建议：沙箱拒绝子进程应**报错**而非挂起。
- **九条平台触点常设锁**（新档 `platform-surface.test.mjs`）：把 0.1.7 那一轮「被撞出来」的九处契约面钉成**可独立转红**的断言（#2/#3/#4 标 `derived`，与既有锁**两处同改**）⇒ 下次平台换契约在改的当下就红。
- **流程实据**：设计评审跑了 **5 轮**（R1 FAIL → R2 PASS → R3 PASS → R4 FAIL → R5 PASS）；R4 抓到的 🔴 是**我自己只扫了一半订正**（§2.2 改了、§3/D26-3/登记表还留着旧说法）——这也顺带证明 **D-44 修好后的「文档集指纹 ⇒ 改档即废令牌」护栏真的生效**（改完文档拿旧令牌派单被直接拒）。实现走 eng_coder 首轮 + 分歧修复轮；**越界档** `scripts/fix-desktop-core-skew.ps1`（+46/-12，修的是真缺陷：HEAD 版扫错目录会空跑、`-Restore` 可能被空备份遮蔽）已补进设计档 §3 收编。
- **残留**：平台 `job_output` 读取面（上游）· 落盘目录的清扫/轮转（本批边界）· `pathForm` 的 `ring` 为保留位（当前不产出）。
## [0.29.4] — 2026-09-26

> **一句话**：把插件的**作业输出**按 DSH 0.1.7-rc.2 的新契约生产（**输出环** + `job.result`），并让**文档集指纹**不再拿 `process.cwd()` 猜基座——前者决定「后台作业的报告正文能不能到模型」，后者决定「设计评审签发的合格证到底绑没绑上文档集」。**本版改 `lib/**` ⇒ 重启 DSH 后生效。**

**批 25（DSH 0.1.7 契约对齐：D-46 · D-44；残留 D-47）**

- **【计数行】**：`node --test` **527/527**（**基线 522 + 本批 5**：D-46 = `dsh017-compat.test.mjs` +3〔D-46a · D-46b · D-46-static〕· D-44 = 同档 +2〔D-44a · D-44b〕）。⇒ 台账 §三：`dsh017-compat.test.mjs` **4 → 9**；档数 **22**（不变）。
- **D-46（🔴 作业输出契约）**：0.1.6 的生产方式是 `spec.run()`（**无参**）+ 正文放 `done` 的 outcome 的 `output`（平台存进 `job.output`，读时返回 `{ text, snapshot }`）；0.1.7-rc.2 改成 `spec.run(handle)`（handle = `{ id, append(text, options), updateProgress(line) }`）+ 正文由**输出环**承载（`handle.append` / `spec.output` 泵入），而 `settle` 只写 **`job.result = outcome.result`**（**`job.output` 字段已不存在**）。⇒ 插件四处派发既不写环也不返回 `result` ⇒ **报告正文在 0.1.7 下到不了模型**（与读取接口是否可用无关）。修法：新增 `lib/job-outcome.mjs` **单点收口** `jobOutcome(handle, outcome)`——正文入环 ⊕ `result`/`output` 同值别名（决策 D25-1：两代运行时都读得到）⊕ `handle?.append?.` 可选链（D25-2：旧运行时不传 handle 不许抛）；四处派发共 **28 处** outcome 全部换装（advisor 6 · consult 3 · eng 10 · escalate 9）。
- **D-44（文档集指纹基座）**：`normalizeDocPath` 用 `resolve(String(p))`（**不带基座 ⇒ 退化成 `process.cwd()`**），而宿主进程的 cwd 是 profile 目录 ⇒ 相对路径的 `documents` 一律读不到 ⇒ `computeDocHash` fail-closed ⇒ `pendingDocHash` 置 null ⇒ **指纹门控续期与「文档已变更」检测双双失效**（诊断文案还把它归给「该次评审未绑定文档集」，误导排查）。修法：`normalizeDocPath(p, baseCwd?)` / `computeDocHash(paths, baseCwd?)` 接受**显式基座**，调用方传**会话 cwd**（advisor 签发侧 · eng 续期复核）；**缺基座逐字旧行为**（向后兼容）。有意不改 Guard-E 复核点（入参已归一的绝对路径，且受 `guard-e` T-E17 字节锁）。
- **回归腿（5 条）**：D-46a/D-46b 走**真入口** `runEscalate` 的 dsh 后台派发（钉 `run` 形参个数 === 1、append 文本 === `outcome.result`）· D-44a（绝对 vs「相对 + 基座」同指纹且非空）/ D-44b（缺基座四态逐字 + `ok:false` 不变）· **D-46-static**（锚 A5 全量静态锁：`run: (handle)` 计数 === `jobs.start({` 计数、四档合计 **7**、**零处无参 `run: ()`**——任何一处被改回旧契约即红灯）。
- **交付评审**：第 1 轮 **FAIL**（1🔴 静态锁 A5 未落地 · 1🟡 触发列滞后 · 3🔵）→ 逐条处置 → 第 2 轮 **PASS**。既有结构锁**逐字保留**（`stageGateNote(` = 5 · `failStop(` = 18 · 失败行零门字样）。
- **流程实据（写进版本史，供后人避坑）**：本批实现走**后台派发**。`codexCli.budgetCapMs` 的缺省是 540000（9 分钟）——**同步派发**另受平台 `run_code` 墙钟约束（实测 600s），所以**把上限提到 60 分钟也在同步路径上用不上**；长任务的正解是后台路径（由 `dshBackgroundTimeoutMs` 兜底）。派发时插件会打 D-16 不变式提醒。
- **残留（如实登记）**：**D-47** 冻结写门禁的路径归一仍猜基座 ⇒ 相对路径 **fail-open**（改动须同改 `guard-e` A2 夹具）→ **批 26**；**D-45** 作业全文落盘兜底 → 留转（**★ 2026-09-28 勘误：兜底保留为附加保险；当初的「平台缺陷」前提已撤回，见 [0.29.11] 第六节**）。
## [0.29.3] — 2026-09-25

> **一句话**：修掉 **DSH 0.1.7 的三处平台契约变更**造成的插件失效——home 兜底探测的特征标记（`settings.yaml` → `settings.yaml.imported`）· advisor 工具结果的消息形状（`user+tool-result` 块 → 独立 `tool` 角色消息）· jobs 派发的 owner 参数据型（Agent 对象 → agent/session id）。**本版改 `lib/**` ⇒ 重启 DSH 后生效。**

**批 24（DSH 0.1.7 兼容修复：D-40 · D-41 · D-42）**

- **【计数行】**：`node --test` **522/522**（**基线 516 + 本批 6**：D-40 = `config-api.test.mjs` +1 · D-41/D-42 = 新档 `dsh017-compat.test.mjs` +4 与 `truncation.test.mjs` +1（用例数 4 → 5））。⇒ 台账 §三：`config-api.test.mjs` **33 → 34** · `truncation.test.mjs` **4 → 5** · **新增 `dsh017-compat.test.mjs`（4）**；档数 **21 → 22**。
- **根因（总纲）**：这三处都是同一种病——**插件写的是 0.1.6 的契约，0.1.7 换了契约**。三者互相独立、可分别复现，且都**不是**上游故障 / 限流 / 模型选择 / 网络问题，所以「换模型」「换 provider」「重启」都救不了。
- **D-40（home 探测）**：0.1.7 起宿主把 `$DSH_HOME/settings.yaml` 改名为 `settings.yaml.imported`，而 `probeProfileRoot` 的特征仍是旧名 ⇒ 无 `DSH_HOME` 的部署（官方桌面版 app 插件进程）探不到 home ⇒ `saveUserConfig` 返回 false ⇒ 设置页报 500。修法：特征放宽为「含 `sessions/` 且含 `settings.yaml` **或** `settings.yaml.imported`」。
- **D-41（消息模型 · advisor 全灭）**：0.1.6 的 `dsh-llm` `createToolResultMessage` **逐字产出的就是插件现在发的形状**（`role:'user'` + `content:[{type:'tool-result', toolCallId, content, isError}]`），0.1.7 改成**独立 `role:'tool'` 消息**（`toolCallId`/`isError` 在消息级、`content` 直接是结果块数组）并**删除了旧形状的兼容**：`dsh-llm-pi-ai` 的 `userContent` 去掉了 `case "tool-result"`（静默丢弃 ⇒ 留下空 user 消息 + 无人应答的 tool_call ⇒ 网关 `400 {"code":"1213"}`），`dsh-llm-deepseek` 的 user 分支遇到该块直接 `unsupported()` 抛 `UNSUPPORTED_CONTENT`。**触发时机**：第一轮请求正常，模型一旦调用 `read`/`grep`、**第二轮**带上工具结果即炸——两条路由两种报错，根因同一处。修法：`lib/advisor.mjs` 的 `toolResultMsg` 改判新形状；`compactMessages` 的孤儿守卫与 `keyFiles` 取文按新形状改判（`isToolResultMsg` 单点），**并补一条退化边界**——回退到数组边界仍落在 `tool` 上（配对前驱本就不在数组里）⇒ **丢弃**，绝不产出以孤儿 `tool` 开头的窗口（否则 deepseek 侧抛 `tool result has no matching call`，把「每次必炸」变成「压到 20 条以后才炸」）；`lib/consult.mjs` 的主历史渲染放行 `role:'tool'`（只留 `[tool result]` 标记、不展开 content，保 60KB 预算）。
- **D-42（jobs owner · 全部后台派发全灭）**：0.1.7 的 `dsh-jobs-local` 在 `start(spec)` 首行新增 `resolveOwner(spec.owner)` → `agents.get(owner)`，而 agents 注册表按 **id** 键（`dsh-agent` 注册时强制 `agent.id === agent.session.id`）⇒ 插件 7 处 `owner: agent`（Agent 对象）全部抛 `session "[object Object]" has no live agent`。0.1.6 的 `start()` 直接把 `spec.owner` 当 owner 桶用 ⇒ 旧写法**当时可用**；平台自己的调用点（`dsh-tool-subagent` / `dsh-tool-workflow`）一律传 `parent.id`。**影响面**：advisor-codex · advisor-dsh · consult · eng-codex · eng-dsh · escalate-codex · escalate-dsh 七处，等于批 21「dsh 路径默认后台」在 0.1.7 上整体失效。修法：新增叶模块 `lib/job-owner.mjs`（`ownerIdOf(agent)`：`agent.id` → 回落 `agent.session.id`；**两者皆缺响亮失败**，不静默回落成对象——对象在 0.1.7 下必然被拒收，静默回落会把「必定失败的派发」伪装成「派发成功」），4 档 7 处统一改判。
- **回归锁（5 条，新档 `test/dsh017-compat.test.mjs` + `truncation.test.mjs` 改判）**：每处一条**行为腿** + 一条**源码字节锁**。D-41 行为腿走**真实 `runAdvisorToolLoop`** 两轮夹具（llm 桩只替网络那一层），断言 `role:'tool'` / 消息级 `toolCallId`·`isError`·`source` / `content` 是结果块数组 / 负控无 `user+tool-result` 残留 / 配对链无孤儿；字节锁钉住「零处旧形状 + 恰一处 tool 角色构造点 + `keyFiles` 取文随形状搬 + consult 渲染放行 tool」。D-42 断言 `ownerIdOf` 三态 + 4 档 7 处 `jobs.start` 与 `ownerIdOf(agent)` **一一对应**、零处直传 Agent 对象。
- **授权面变更（显式声明）**：`AP_TEST_AUTHORIZED` **新增 `test/truncation.test.mjs`**——该档的 `toolResultMsg` 夹具与 T13-boundary 期望值**逐字编码**了旧形状，D-41 换契约 ⇒ 期望值必须翻转（**这正是 T-AP9 存在的意义，不是障碍**）；T13-boundary 同批拆成正反两条腿。T-E19 清单同批登记新档 `dsh017-compat.test.mjs`。
- **★ 本批改 `lib/**` ⇒ 重启 DSH 后生效。**
- **【评审】**：`advisor type=code` 对 `lib/job-owner.mjs` —— **`VERDICT: PASS`**（"No correctness, security, resource, or race issues found"）。它自己 grep 了全部 7 个派发点并逐个给出 file:line，另给两条 🔵：① 设计档 §3.4 的内联样例与实现的完整消息不一致；② 类型守卫的严格性建议在 JSDoc 里写明。**两条均已处置**（`ea82924`：样例补全为逐字、JSDoc 补「平台契约保证 id 恒为非空字符串，非字符串一律视为缺失」；行为零改动）。
- **【会诊】**：`consult #6`（`zai-coding-cn:glm-5.3`）——本轮**不是普通的「第二意见」而是独立复算**：它自己 diff 了 0.1.6 备份树与桌面版 0.1.7-rc.2 树的五个包（把两处根因证据钉到行号）、实跑锁测试 **9/9**、并对 `compactMessages` 另跑 **1025 例对抗 + 1 组负控**。总判定：**两处根因均成立、目标形状逐字正确、同族消费点无漏改、批 24 无需返工**。父侧**逐条处置 7 条意见：采纳 6 · 不采纳 1**（唯一分歧 = 它把 `lib/consult.mjs` 的 `case "tool-result"` 判为死代码；父侧裁定**保留**——该分支是 0.1.6 时代创建、升级后续跑的会话的**跨版本读取兼容**，删掉会让这些会话的工具结果静默渲染成空串）。纪要：`docs/consult-minutes/2026-09-25-consult-6-minutes.md`（原始层 + 父侧裁定层 §2–§5）。**★ 计数纪律**：评审自报的 1025 例与负控脚本未随纪要交付 ⇒ 按「评审自报、父侧未复现」入册；父侧自己复跑的是 522/522 与两组变异。
- **【同批登记：一个平台缺陷（非本仓代码面）】**：`job_output` 读不回后台作业全文——2026-09-25 实测**两次复现**（`advisor-dsh-1` 与 `consult-1`），作业能派发、能跑完、完成通知也到，读全文时抛 `Cannot read properties of undefined (reading 'output')`。插件侧兜底已存在（评审正文进 `session-state.json`、会诊纪要落 `docs/consult-minutes/`）⇒ **结果不丢，但工具描述里「完成通知 + 全文经 job_output 读取」那句在当前平台上是死的**。已同步登记进 README「已知未决」。
- **【同批登记：下一批建议】**：会诊 #6 与设计档 §8 给出同一建议——**把插件的全部平台触点对着新旧两版 DSH 包做一次系统 diff**。它已帮本批摸过五类触点（`settings.yaml` 改名 / `subagents.start(spawn)` / `llm.stream` 的 GenerateOptions / `jobs` 的 `spec.run()` / agent-session 形状），其中 0.1.7 给 `spec.run(handle)` 新传的 `{ id, append, updateProgress }` 属**兼容性增量**（零参闭包自然忽略），进度上报登记为可选增强。
## [0.29.2] — 2026-09-21

> **一句话**：把代码与测试里**作者私有的 provider / 模型标识**换成中性示例值，并给 npm 打包加白名单——此前 `npm pack` 会把 `docs/` 与 `test/` 一起打进去。**零行为改动。**

**批 23（隐私面收口 · npm 打包面 · 零行为改动）**

- **【计数行】**：`node --test` **516/516**（**基线 516 + 本批 0**）。本来就没有新增/删除用例——本批只改夹具的**取值**与两处注释，台账 §三 逐档用例数**零变动**。
- **立项形态**：代码与测试里长期带着**作者本机配置的真实 provider 与模型标识**（作为夹具示例值）。这类值会随任何分发面外流，而 npm 打包面尤其宽——实测 `npm pack --dry-run` **会打 140 个文件 / 4.9 MB**，其中 **78 个来自 `docs/`、23 个来自 `test/`**。
- **两处处置（都零行为）**：**① 夹具与注释脱敏**——`lib/client.js` · `lib/effort-resolve.mjs` · `lib/eng.mjs` 三处**注释/占位文案**，以及 `test/{advisor-config,config-api,codex-runner,session-state}.test.mjs` 四档里的示例取值，统一换成中性值（`provider → acme / beta-labs`、`model → model-a / model-a-flash / codex-model-a`）。**夹具语义不变**（它们本就是任意示例值），故 516 条断言一条不动、全部照旧通过。**② `package.json` 加 `files` 白名单**（`lib/` + `cordis.patch.yml`）——把 `docs/` 与 `test/` 挡在 tarball 之外。
- **★ 范围如实声明**：本批**只动代码与测试 + README 的一行配置示例**；`docs/**`（含历史设计档与会诊纪要）**按「历史不重写」惯例保持原样**——它们仍含同类标识。**★ 并且：工作树脱敏 ≠ 抹掉历史**——这些值在**已公开的 git 历史**里仍然可见（`git log -p` 可查）。要真正移除需重写历史 + force-push，那是破坏性动作，本批**不做**，留作独立决定。
- **★ 本轮推送受阻的如实登记**：`git push` 连 `github.com:443` 反复被重置（`Recv failure` / `Could not connect`），而 `gh`（走 `api.github.com`）全程正常 ⇒ 本轮的 fork 提交改由 **GitHub API** 完成（建 `refs/heads/...` + contents PUT），绕开 git 传输层。
- **★ 本批不改 `lib/**` 的行为**：三处改动全在注释/占位字符串；`lib/index.mjs` 与 `lib/advisor.mjs` 等**零字节改动** ⇒ **无需重启**即生效面仅限「下次任何 build/安装读到的文件」。
## [0.29.1] — 2026-09-21

> **一句话**：设置页的配置 API 补上了一道**一直缺的门**——它此前**谁都能进**（实测：无 token `GET /config` ⇒ 200 并回吐完整配置与本地绝对路径，`Host: evil.example` 也 ⇒ 200），现在跟 DSH 其它路由一样，先过宿主的 Host/Origin 栅栏与浏览器会话鉴权。 **本版改 `lib/**` ⇒ 重启 DSH 后生效。**

**批 22（D-39：webServer 路由接入宿主信任栅栏 · 安全修复）**

- **【计数行】**：`node --test` **516/516**（**基线 509 + 本批 7**）。⇒ 台账 §三：`config-api.test.mjs` **26 → 33**（新增 **7** 条栅栏回归腿；档数 21 不变）。
- **立项形态（父侧 2026-09-21 实测，全部只读探针）**：`GET /thincoder-suite/api/config` **无 token ⇒ 200**（回吐完整配置，含 `advisor.standardsDoc` / `documentMapDoc` 等**本地绝对路径**）· `GET /catalog` ⇒ 200（provider/model 表）· `Host: evil.example` 仍 ⇒ **200**；写路径同样无门（`PUT` 非法 JSON ⇒ **400 而非 401** = 请求已进 handler）。**对照**：同一 webServer、同一进程上的核心路由 ⇒ 401、内置插件路由 `/open-in-app/apps` ⇒ **401 / 403** ⇒ 不是平台能力缺失，是路由所有者漏做一步。**「绑 loopback 所以安全」这个前提是错的**：loopback 挡不住浏览器（缺 Host 栅栏时恶意页可用 DNS rebinding 同源化 ⇒ 响应可读）。
- **修法（一处：handler 的第一件事）**：handler 闭包首部先取宿主 `connection.requestRejection(req)`——403（Host/Origin 栅栏，挡 DNS rebinding 与跨站）/ 401（浏览器会话鉴权）**原样透传**，**undefined 才进既有业务逻辑**；服务取不到 ⇒ **503 fail-closed + warn-once**，**绝不放行**。平台契约逐字：`dsh-host-webserver/README.md:113`「route owners such as dsh-client-connection enforce their own request policy」；同栈母本 = `dsh-client-connection` 自己的 `/api` 路由与 `dsh-host-open-in-app` 的 `rejected()`。
- **两个刻意的取舍**：① 取服务用 `ctx.get("connection")` 而**不是** `ctx.connection`——后者在本插件（`inject` 不含 connection）**会抛** `cannot get property "connection" without inject`（cordis:675）；② `connection` **刻意不进** `inject` 列表——required 语义会让无该服务的 profile **整个插件拒起**，四个 host 工具为 web 附属面陪葬（U8 同款纪律）。
- **回归面 7 条腿**（判据 = 证明门在**业务逻辑之前**，不只是「返回了个错误码」）：D-39a/b 401/403 下 `PUT` **盘字节快照比对不变** + 读端点不回吐 base/effective · D-39c 空 ctx ⇒ 503 + warn **恰好一次** · D-39d 服务形态异构（无 `requestRejection`）⇒ 503 · D-39e 栅栏抛错 ⇒ 503 · D-39f 放行 ⇒ 原行为零回归 + 栅栏收到**原始 req 同一引用** · D-39g **8 端点**矩阵全过门。
- **锁面变更（显式声明）**：`AP_TEST_AUTHORIZED` **新增两项**——`test/context-budget.test.mjs` · `test/session-state.test.mjs`；**12 处**直调夹具（11 处 `makeApiHandler({}, …)` + `design-review-guard.test.mjs` 的 apply 捕获路径）改用显式 `fenceCtx()` ⇒ **放行从此是白纸黑字，不再靠门缺席**。理由逐条住 `test/death-provenance.test.mjs` 注释块 **⑦**。
- **同批改判的描述面**：设计档 §3.2「loopback 信任模型」与 §6 风险条「webServer 路由无鉴权」**同批改写为栅栏语义**（原前提已证伪——留着会让下一个人照错理由改回去）· `README.md:210` 端点清单补鉴权口径 · `makeApiHandler` 的 JSDoc（`ctx` 参数此前**从未被使用**，如今才真正承担栅栏）。
- **会诊（consult #63，4/4 交付）**：四席在**结论层完全收敛**（fail-closed + 不进 inject + 文档同批），分歧只在**门的位置**与**测试缝**；父侧逐条处置 **31** 条主张（原始层 + 裁定层见 `docs/consult-minutes/2026-09-21-consult-63-minutes.md`）。**否决的两个形态**：[1] 的 `opts.requestRejection` 钩子（handler 侧无钩子即跳过 = **fail-open 默认**）与 [3] 的双层 `ctx.inject` 门控注册（边际收益只是 404 与 503 之差，代价是六处并发改动）。**会诊抓出的一个真缺陷**：[3] 在创建处写 `ctx.connection` 属性读——在 cordis 下会抛。**★ 计数纪律**：四席自报夹具数 10 / 11 / 12 / 13，父侧实测 **12**（四家无一对上）。
- **★ 一条自查纠错（据实登记——用户 2026-09-21 指出）**：先前在此写「`dsh-super-injector` 同款缺陷 ⇒ 另行报障」，**两处都不准**。① **引错行**：`lib/index.js:7020` 是它的**脚手架模板**（`path: '/${pkgName}/api'`），**不是**它的实际路由——真路由在 **`lib/index.js:9633-9635`**（`/super-injector/api`，同样**没有**栅栏）。② **没有核装配就断言暴露**：该插件在本部署**未装配**——不在 web profile 的 `dsh.profile.bundles`、不在其 `node_modules`、活体探测 `/super-injector/api` ⇒ **404**（对照 `/open-in-app/apps` ⇒ 401）⇒ **实况暴露为零，无需报障**。**★ 用户 2026-09-21 裁定（范围收口）**：`dsh-super-injector` **非本仓所有的第三方插件，且已不启用** ⇒ **不在本仓跟踪范围**。本档只登记「**代码形态与本缺陷同形**」这一事实（真路由 `lib/index.js:9633-9635`），**不承担**任何前置校验、报障或清单义务——将来若有人自行启用它，那是启用者的事。（可复用的栅栏形态见本版 `lib/index.mjs` 的 `rejectionOf`，仅供需要时参考。）
- **★ 兄弟路由的范围**：`dsh-team-link` 的导出路由由**另一会话**处理，不在本批。
- **★ 回归过程如实登记（套件级颜色不美化）**：全量 `node --test` 共跑 **8** 轮——**第 1、2 轮红**（失败项**全部**是本批自身的**元锁在途修复**：台账用例数等值锁 `T-LC2` · 基线测试档授权锚 `T-AP9` · 批 17 事实标记对等值 · `T-LC4` 自证样例；逐条见台账 §七 批 22 行），**第 3 轮红 1 项**（**时序 flake** `death-provenance.test.mjs :: T-AP4b`），**第 4–8 轮 516/516 全绿**；另有本档隔离复跑 **19/19 绿**。**该 flake 的唯一登记点 = 台账 §五「已知 flake 表」**（`G6` 复跑豁免口径与 `R-13` 同）——此处**只留指针、不重述细节**（D3 单点登记）。**全程没有为消红放宽任何断言**。
- **★ 真机验证（2026-09-21，用户重启后实测——全项通过）**：① **新 `lib/**` 已加载**；② **活体矩阵**（改前 ⇒ 改后）：无证件 `GET /config` · `/catalog` · `/session` · `/codex/models` **200 ⇒ 401** · 无证件 `PUT /config`（非法 JSON）**400 ⇒ 401** · 无证件 `POST /apply-session` · `DELETE /session` **404 ⇒ 401** · `Host: evil.example` 的 `GET /config` · `/catalog` **200 ⇒ 403** · 对照组 `/` 与 `/open-in-app/apps` 仍 **401（零回归）**；③ 拒绝体 = `{"ok":false,"error":"unauthorized"}`（JSON 契约成立）；④ **真实设置页加载 · 保存 · 恢复默认全链路正常**（同源带 cookie，无感）⇒ **发版门槛通过**。**★ 顺带结清**：读数是 401 而**非** 503 ⇒ **运行时确实解析到了宿主的 `connection` 服务**——会诊纪要 §5-1 列为本批最大残留不确定的那一项由此结清。加门**前**的矩阵另见「立项形态」。

## [0.29.0] — 2026-09-18

> **一句话**：不传 `background` 现在也走后台——长任务不再被插件自己的 540 秒内部截止掐掉、也不再撞平台 600 秒墙钟连报告一起丢；短任务可用 `background: false` 强制同步。**本版改 `lib/**` ⇒ 重启 DSH 后生效。**

**批 21（长任务默认走后台 · dsh 子代理路径的三态语义 · **带一处重要环境发现**）**

- **【计数行】**：`node --test` **509/509**（**基线 497 + 本批 12**）。⇒ 台账 §三：`advisor-config.test.mjs` **60 → 67** · `codex-runner.test.mjs` **185 → 190**（新增 **12** 条验收腿；另有 **5 行既有断言翻预期**——FR-2 的必然后果，翻预期不增计数）。
- **立项形态**：`eng_coder` 与 `escalate` 各有两条后端。**codex 后端早已按预算默认后台**（缺省预算 1800s / 600s，都高于 `budgetCapMs` 的 540s 阈值），**advisor 按预算自动**、**consult 无条件后台**；**只有 dsh 子代理路径默认同步**（父代理阻塞，内部截止 540s < 平台 600s 墙钟）⇒ 长任务只有两种死法：**被掐掉**或**撞墙钟连报告一起丢**。
- **四处手术（零新配置键，靠三态语义）**：**①** `lib/eng.mjs` 的 dsh 判定 `=== true` → **`!== false`** · **②** `lib/escalate.mjs` 同族同改 · **③** `lib/index.mjs` 两处 schema **删掉 `default: false`**（宿主该注解是**非校验**的：`dsh-tools` 的 `schema.d.ts:14` 字面「Non-validating default annotation」⇒ 它不改变行为，但留着会让**给模型看的 schema 撒谎**） · **④ ★ `lib/index.mjs` 的 escalate 透传点 `=== true` → 三态透传**——**不改这一行，escalate 的翻转会完全静默失效**（`undefined` 被压成 `false`）。**③④ 是父侧漏看、会诊抓到的。**
- **三态语义**：**省略 ⇒ 后台**（新默认）· **`false` ⇒ 强制同步**（逃生口）· **`true` ⇒ 后台**；**非布尔的 `background` 一律按「非 false」走后台**（fail-safe，不静默同步）。
- **配套三件（缺一不可）**：**① 跨机制护栏**（`lib/advisor.mjs`）——默认后台后父代理不再阻塞，**它可能在交付落地前跑 code 评审**，而重置轮次/prior、合并 `touchedFiles` 的簿记发生在 job settle 的回调里 ⇒ 早跑的评审**看到的文件不对 + prior 被污染 + 那轮白跑**；护栏 = code 型评审发起前查 **eng/escalate 槽位**，在飞则**拒绝并指向 job id**（design 型不受影响）。**② 回落告警随工具返回可见**（此前只在 `console.warn` ⇒ 翻转后会变成「父代理以为派了后台、傻等一个不会来的通知」的**静默失败**）；**行为仍是回落同步、文案逐字节不变**。**③ 描述面六处** + 提示词**过渡态与隔离期纪律**。
- **不动**：codex 路径判定（零漂移）· `budgetCapMs` 缺省 540s（**60 秒余量是「回落了也拿得到诊断」的保证**）· `session-state` / `stages` / `stage-gate` / `path-kind` / `preset-static` 等**未授权基线档零改动**。
- **★★ 同批修掉的一个真根因（本版最值得记的一条）**：本机**此前在运行进程里取不到 `ctx.jobs`**——证据是**显式传 `background: true` 也走同步路径**（两次真实派发都以同步路径的失败信封结束）。⇒ **「长任务超时」的原痛点主因是该服务在运行时不生效，不是默认值**；**本批的默认翻转只有在该服务可用之后才真正生效**。处置：显式挂载 `@deepseek-ai/dsh-jobs-local` + 重启，并以一次**真实探测**验证「**不传 `background` 也能真的派出后台 job**」。⇒ **本批的价值之一是它把这条静默失败面照亮了**（若没有 FR-3 那条「回落告警进工具返回」，这个根因还会继续藏在 console 里）。
- **★ 过程如实登记**：实施跨 **4 次派发**，其中**两次以 `error` 零产出结束**（工作树干净、无残留）——**根因即上面那个服务未挂载**。**独立分歧审计 5 条**（**1 🔴 = 父侧收口欠项**：交接页没有本批重启行；**2 🟡**：设计档自己写的 **N9 负控字面形态与原实现语义全等 ⇒ 恒绿**（改为意图形态后才恰红 AC-15）· **5 行既有断言被翻转而三处记录都没写**；2 🔵）。**交付代码评审 `VERDICT: PASS`**（🟡1 · 🔵3，**全是注释/描述层滞后、零行为缺陷**）。**★ 审计的正面实证**：12 条新腿在**旧实现下恰 10 条转红、全部 `ERR_ASSERTION`、假红 0**；**10 条负控 + 5 条阴性对照零假红**（其中把 ④ 的透传改回 `=== true` ⇒ AC-2 转红，**三态透传的必需性得证**）；回落文案**逐字节集合相等**；台账 **21 档双射、逐档全等、合计 509 == 509**；`AP_TEST_AUTHORIZED` **数组行逐字未动**。
- **★ 不可真机验证（如实登记）**：**重启后是否已加载新 `lib/**`**（T3 人工面；已用一次真实探测间接验证后台派发可用）· **在飞槽位重启失忆的发生率**（R-66）· **别的交错组合**（R-68）· **提示词的实际效果**（软约束，硬约束靠护栏）。

## [0.28.0] — 2026-09-17

> **一句话**：写文件更抗折腾、失败不再静默：目标文件被杀软或索引器**短暂占用**时自动重试（8 次、约 0.3 秒），不再直接失败；**真的**失败时留下可检索的告警。顺带修掉设置页「恢复默认」**失败却报成功**的问题。 **本版改 `lib/**` ⇒ 重启 DSH 后生效。**

**批 20（原子写的可重试与失败可见 · 本批改 `lib/**` ⇒ **重启 DSH 后生效** · **带未决项，见末条**）**

- **【计数行】**：`node --test` **497/497**（**基线 485 + 本批 12**）。⇒ 台账 §三：**新档 `write-atomic.test.mjs` 11 条**（档数 20 → 21）· `config-api.test.mjs` **25 → 26**（`T-LC2` 等值锁同批同步）。
- **立项形态**：`R-51`（批 14）与 **`R-13`**（批 9 台账「已知 flake」）**实测同源**——**「时序 flake」是误诊**：失败原文 `actual ['keep','malformed','stale1','stale2']` **恰是「写落地前」**的文件内容 ⇒ 唯一路径是「**那次写没落地**」，而失败被 `session-store` 的 `catch → console.warn` 吞掉、**而该测试断言的是文件内容**。
- **★ 会诊三家一致：「只做重试就是超卖」⇒ 本批两条腿落地**：**① 有界重试**（`renameSyncWithRetry`：**8 × 平铺 30ms**、**按 `e.code` 字符串**白名单 `EPERM`/`EACCES`/`EBUSY`、**`ENOENT` 特判重铸 tmp**、耗尽**重抛原对象**（保 `.code`）+ 遥测 `code`/`errno`/次数/耗时 + 可 grep 签名）；**② 失败可见**（遥测 + **`DELETE /config` 那句「面向用户的谎」被修**：清除失败 ⇒ `ok:false` + 500，对齐 PUT 先例）。
- **`writeFileAtomic` 重排**：`mkdirSync` **环外**（保 F12-T5 的 `ENOTDIR` 快失败）· **写与 rename 同入环内 `try`、失败即 `unlink`** · **tmp 名环外定格一次** · **孤儿清扫 ≥10min**（`.tmp-` 与 `.del-` 两形）。**`clearUserConfig`** 并入同一原语 + **TOCTOU 幂等**（`ENOENT` ⇒ 判「已清空」返回 true）。
- **契约零改动**：三个 store 的 `save*` **仍 `console.warn` + `return false`**（内存态是第一事实源、盘是镜像）。
- **注入缝族**：`{delays, maxAttempts, write, onEnoent, rename}`——`write` 钩子的**存在性**门控 `unlink(from)`，保护 `clearUserConfig` 的**活配置文件**；`rename` 缝使 rename 阶段可注入而**不必 `mock.module`**。
- **★ 姿态如实声明**：「**按机制假设根修**」，**不是**「已确诊 `EPERM`」——`R-13` 的**原发 errno 从未被捕获**；因此本批**自带观测面**（耗尽遥测），**复发时可判真伪**。
- **★ 本批的未决项（如实登记，不藏）**：**疗效门槛未达标**——协议（全量 ×10 + 单档 ×20）实测 **全量 9/10**（第 9 轮 `fail=1`，**失败项身份未知**：父侧脚本只记了计数、未捕获失败项名；**追加 20 轮 0 复现**，累计 30 轮 1 红）· 单档 **20/20 全绿**。⇒ **`R-13` 不宣告「已根治」**：台账 §五 写「**机制已根修（v0.28.0）；疗效门槛未达标**」，且**该行保留**——删行会**打红发布门的三条机械断言**并牵动发布门本体与其基线档，**且会失去 `G6` 的复跑豁免，而那条未知偶发正需要它**。
- **★ 交付过程如实登记**：实施跨 **6 次派发**——第 1 次**零产出**（1800s 全烧在从四份文档重新推导设计）· 第 3 与第 5 次 **1800s 兜底、留半成品** · 第 2/4/6 次成功。**独立分歧审计 10 条**（**1 🔴 = 父侧在收窄派发时漏派 stage 3**，`DELETE /config` 的谎未修；另有两条 🟡 是**我自己设计的负控「写着但没人能执行」**）⇒ 修复轮补齐；**交付代码评审 `VERDICT: PASS`**（🔴0 · 🟡3 · 🔵4，7 条全处置）。**审计还实证**：删掉台账 §五 的 `R-13` 行 ⇒ 门测试 **pass 7 / fail 2**、`release-check` 报 **G6 FAIL** ⇒ 「不删行」的裁定**有机械后果为据**。
- **零改面**：`test/session-state.test.mjs`（**疗效见证者，一字未改**）· `test/release-check.test.mjs` · `release-check.mjs` · `test/fixtures/**` · `lib/advisor.mjs` · `lib/state.mjs` 逐档零改动；`lib/**` 六串零命中；`failStop(` 恒 **18**；零新依赖；**负控与变异全部在仓外副本上做，仓内零残留**。

## [0.27.0] — 2026-09-17

> **一句话**：推理强度回落**不会再偷偷把推理关掉**：`off` 是「关闭开关」而不是「力度档」，所以回落**永远不落到 `off`**；显式要求关闭推理而模型做不到时，**会告诉你**并交还提供方默认。 **本版改 `lib/**` ⇒ 重启 DSH 后生效。**

**批 19（effort 回落的开关语义：`nearestEffort` 根修 · 本批改 `lib/**` ⇒ **重启 DSH 后生效**）**

- **【计数行】**：`node --test` **485/485**（**基线 477 + 本批 8**）。⇒ 台账 §三 `codex-runner.test.mjs` 用例数 **177 → 185** 同批同步（`T-LC2` 等值锁）。
- **立项形态**：`off` 是**关闭开关**而不是**力度档**，而 `nearestEffort` 让它在**同一把距离尺**上参与竞争 ⇒ 用户要「低推理」、拿到的是「**推理全关**」。触发条件实测为 `requested = low` ∧ `medium ∉ supported` ∧ `off ∈ supported`；穷尽 dsh 梯子的 31 个非空支持集，`low` 落到 `off` 的**恰 4 组**（退化集 + `{off,high}` / `{off,max}` / **`{off,high,max}`**）。本部署 `profile/settings.yaml` 的 20 个模型条目里 **8 个是该中招形状**，而 `profile/profiles/web/cordis.patch.yml` 的 convergence 组恰是 `glm-5.3-flash` 配 `low`、`engCoderEffort` 也是 `low` —— 只因 user 层覆盖成 `max`/`high` 才未中招。批 14（`v0.23.0`）只做了默认值层面的规避（`low` → `medium`）并把它另立批次（D14-2），本批即那一批。
- **★ 用户裁定的两条语义**（本批不自行拍定）：**①** 回落**禁止**落到 `off`，**仅当支持集里根本没有力度档时才用**它（退化兜底，带响亮专属告警）；**②** 显式请求 `off` 而模型**不支持** `off` ⇒ **改为省略 `reasoningEffort`**（`effort: null`，交还提供方默认），与 codex 侧既有的 `off ⇒ null` **值对称**。
- **★ 会诊抓到的第二个形状**（三家独立同结论，父侧实测复现）：显式请求 `off` 而模型没有 `off` 时，现役代码会把它**改到力度档**（`{low,high}` ⇒ `low`、`{medium,high}` ⇒ `medium`、`{max}` ⇒ `max`）——**用户明确要求关推理，却被打开**；裁定 ② 把它一并修掉。**这不是规避性补丁，是语义修正。**
- **实现（三级分层，全部住在 dsh 调用点）**：**`nearestEffort` 的签名与函数体逐字零改动、codex 调用点逐字零改动**（⇒ codex 侧的零连带是**结构性的**，不是「论证出来的零」）· 候选池按**名**分层（`!== DSH_EFFORT_OFF`；**禁按梯子下标**——codex 梯子 `[0]` 是 `low`，按下标会真打穿 codex）· **退化判定 = `degrees` 空且 `cands` 非空**（**不是**「`nearest` 返回 `null`」——后者会把 `{off, xhigh}` 判成非退化 ⇒ **透传一个已知不被支持的值 ⇒ 秒死路径**，且把差集从 3 组扩大）· **命中检查仍先于一切分层**（显式 `off` 受支持 ⇒ 原样返回、无 note）。
- **★ 核心可证性质：改动差集恒等于 3 组**（**读数口径 = `effort` 值面**）：`{off,high}` ⇒ `high` · `{off,max}` ⇒ `max` · `{off,high,max}` ⇒ `high`；其余 28 个非空支持集的 `effort` 值**逐字不变**，退化集 `{off}` 的**值也不变**（只有措辞变）。父侧在**仓外副本**上穷尽复算，并独立复现了「旧实现下恰 13 条断言红」。
- **三条 note 措辞互斥分叉（这是退化支唯一的判别力来源）**：**普通回落**句**逐字保留**（既有断言依赖）· **退化兜底**支带专属子串「**退化兜底**」（该支的**值与改前相同** ⇒ 只钉值会恒真）· **显式 `off` 关不掉**支含「**未能关闭推理**」且**不含**普通回落句 ⇒ 两侧断言不会交叉误绿。
- **五处现役断言翻预期（逐条点名）**：`test/codex-runner.test.mjs` 的 `low` 对 `[off,high,max]` 三处（consult dsh 行 / eng dsh 分支 / advisor dsh 主路径）由 `"off"` 改 `"high"`；单元层 `b.effort` 由 `"off"` 改 `"high"`；单元层显式 `off` 对 `[low,high]` 由 `"low"` 改 `null`。**这是本批唯一的既有断言改动面**（父侧实测：只改这三处之外的两处会当场红）。
- **八条新验收用例**：A5 穷尽 31 集的**值面差集**（恰 3 组且逐组点名）· A6/A7 退化兜底与**措辞分叉**（含 `{off, xhigh}` 同落退化支）· A8 显式 `off` 关不掉 ⇒ `null` + 专属 note + `console.warn` · **A9/A10 接线级 `null` 出口 × 五个 dsh 消费点**（consult / escalate / eng / advisor 主路径 / advisor 智能回落轮），断言用 **`!("reasoningEffort" in agentOptions)`** 钉**键缺席**——「键在、值错」正是这类 bug 的病灶形态，钉值钉不住。
- **FR-4 描述面同批同步**：`lib/effort-resolve.mjs` 头注释的回落语义段 · `lib/eng.mjs` 的 `ENG_CODER_EFFORT_DEFAULT` 注释（原句在修复后**成为假陈述** ⇒ 改归 as-of 批 14 的历史记述）· `README.md` 的功能表行与 `engCoderEffort` 段。
- **零改面**：`release-check.mjs` 零改动 · `test/release-check.test.mjs` 零改动 · `test/fixtures/**` 零改动 · **零新增测试档**（20 档不变）· 六串零命中 · `failStop(` 恒 18 · 零新依赖 · `docs/consult-minutes/**` 只排除不修改 · **负控与变异全部在仓外临时副本 / 内存夹具上做，仓内零残留**。
- **★ 语义代价（如实登记，不许把宣言写得比机制大）**：`effort: null` **不代表「无推理」**，它代表「**交还提供方默认**」——对推理强制型模型，提供方默认档可能**比「最低受支持档」更贵**。「改落最低受支持档」的备选**已被否决**（理由：用户裁定 ②；`off ⇒ 省略` 两侧同形；不替用户拒绝的推理买单），**其代价如实登记为设计档 §9.4 残差 #5**。
- **★ 九条诚实残差**（设计档 §9.4，逐条可查）另含：`{off, xhigh}` 形状在本部署**零观测**（退化支取值只能由夹具证明）· codex 侧 `off ⇒ null` 的**沉默**本批**有意不解钉** · 元数据不可得时显式 `off` 仍原样透传（既有 fail-open 原则）· 设置页目录不显示 `off` · `eng.mjs` 的 `!== null` 判空与其余三处 truthiness 不同源 · 历史批次档保留旧陈述 · **未来的新 dsh 调用点若忘记分层会退回旧行为**（`nearestEffort` 仍是纯距离函数）。
- **★ 本批改 `lib/**` ⇒ 重启 DSH 后生效**（已写进交接页的重启清单；**不擅自重启**）。

## [0.26.0] — 2026-09-17

> **一句话**：给 CHANGELOG 的计数行加了一道机器锁：绑定区域内的令牌**取值必须一致**（纯测试改动，无需重启）。

**批 18（唯一窄腿：**CHANGELOG 绑定区域内的令牌值一致** · 本批为**纯测试面** ⇒ **无需重启 DSH**）**

- **【计数行】**：`node --test` **477/477**（**基线 476 + 本批 1**）。⇒ 台账 §三 `doc-hygiene.test.mjs` 用例数 **24 → 25** 同批同步（`T-LC2` 等值锁）。**★ 交付时点实测：476 pass / 1 fail —— 唯一红不在本批的腿上，而在批 17 注册的两个**绑定事实**与本批新计数行的**跨批冲突**（见下方「实施期发现」）。**
- **立项形态**：批 17 已交付的 FR-5 两态定位器**绑定了「正在写的那一节」**，而本批**只加判据、不加机制面**：**在定位器绑定的区域内，令牌 `基线 N` 与 `本批 N` 的去重值集各恰 1 个**。**判据的形态是「两处推导式取值一致」，不是「令牌基数唯一」**——批 16 条目的收官实测行**刻意复述**了推导式（值一致），那是**有文档价值**的写法：按「恰 1 处」它两态皆红，而**真正雷过两次的物种是「取值不一致」**。**★ 绝不可扫非绑定节 / 全文件**：`## [0.24.0]` 与 `## [0.23.0]` 两节**今天就违反基数唯一性** ⇒ 全文件版在每个收口后态**恒红**。
- **四条负控 ＋ 阴性对照**（**全部在纯内存夹具上构造**，另加一条**真实语料**的两态自证）：① **不扫非绑定节**——夹具里两个历史节各自违反唯一性 ⇒ **腿不得报**（**四家一致点名的硬要求**）；② **双推导式取值不一致 ⇒ 红**，报错含**绑定区域（态 ＋ 行区间）与两处的 `文件:行:原文`**；③ **行内代码 span 与围栏内一律掩码不计** ⇒ 示例**绿**、去掉反引号**当场红**（真实语料：本档批 14 节里那条不一致的历史引用**就住在反引号里**）；④ **边界不确定或不存在 ⇒ 判失败（红）**，**不回退全文件扫描**（fail-closed）——含**空集也红**（去重值集「恰 1 个」的字面读法）与「标记住在第二节 ⇒ 红」。
- **实现（D2 单一权威源）**：**腿只消费 `shapeLocateCountLine` 的绑定输出**，**自己不再切一次节**——定位器**加性扩展**出 `from` / `to`（绑定区域的**行区间**，0-based 半开）；**既有消费者只读 `state` / `line` / `text` ⇒ 逐字零扰动**。理由：FR-5 的等值锁防的是「两个**抽取器**漂成两种方言」，而**两个定位器是同一种病高一层**。
- **零改面**：**`lib/**` 零改动**（纯测试面 ⇒ **无需重启 DSH**）· **`release-check.mjs` 零改动**（**只读**它的既有导出）· **`test/release-check.test.mjs` 零改动** · **零新增测试档**（20 档不变）· 六串零命中 · `failStop(` 恒 18 · 零新依赖 · **`docs/consult-minutes/**` 只排除不修改** · 存量 `docs/**` 零改动 · 负控**全部在仓外临时副本或内存夹具上做**（仓内零残留）。
- **★ 实施期发现（据实登记，不藏）**：**本批的新死区条目一写上，批 17 的绑定事实腿当场红在两处**——`b17-全量用例数`（docs 侧 476 vs 本批计数行 477）与 `b17-用例增量`（docs 侧 12 vs 本批 1）。**机理不是本批的腿、也不是本批的写法，而是 FR-5 绑定语义本身**：**绑定侧抽的是「CHANGELOG 当前的计数行」，而 docs 侧的注册值写死于批 17 的交付值** ⇒ **任何下一批的新条目都会撞**（批 17 当年不撞，只因为那两个值恰好就是它自己的交付值）。**⇒ 修法 = 父侧更新设计档里那两个 docs 侧值（或撤掉那两条 `bind=`）**；**它在批 18 的写域之外**（`docs/2026-09-17-scope-alignment-design.md` 属存量档，本批**禁改**）⇒ **已按 STOP 纪律上报**。
- **★ 天花板（如实登记，不许把宣言写得比机制大）**：本腿**分不清「引用的历史错值」与「断言的错值」**（§9.4 残差 #4 引文族）；且**只覆盖 CHANGELOG 内**的令牌值一致（散文里的计数仍归 W1–W3 纪律与人眼）。
- **★ 收口动作（owner = 主代理，本批写域外）**：本条目**落在首个版本头之上、不新开版本头**——因为 `test/release-check.test.mjs` 的 **G-常驻2** 断言 `package.json#version` **等于 CHANGELOG 顶部版本头**，而 `package.json` 不在本批写域 ⇒ **新开版本头会让 `node --test` 立刻红**。故收口共三件——**①② 更新设计档里那两个 docs 侧注册值（否则绑定事实腿红）**、**③ bump `package.json#version` + 新开 `## [x.y.z]` 版本头并把本条目移入**。（**发布门 G3 在交付时点必然红**——它比对的是**首节**计数行而本条目在版本头之上，属死文本；与批 9/16/17 先例同形。）

## [0.25.0] — 2026-09-17

> **一句话**：文档形状谓词新增「跨文档事实等值」腿：同一个事实在多处出现时**取值必须相同**；同时修掉谓词自身的三处假红（纯测试改动，无需重启）。

**批 17（谓词作用域与宣言对齐 · **事实 id 跨档等值腿** ＋ **三处既有正确性修复** · 本批为**纯测试面** ⇒ **无需重启 DSH**）**

- **【计数行】**：`node --test` **476/476**（**基线 464 + 本批 12**）。⇒ 台账 §三 `doc-hygiene.test.mjs` 用例数 **12 → 24** 同批同步（`T-LC2` 等值锁）。**★ 交付时点实测：475 pass / 1 fail —— 唯一红在 `DOC-HYGIENE T2` 的腿 4 面（见下方「实施期发现」）。**
- **立项形态**：批 16 的形状谓词**能工作**，但**只扫两处**（档内声明的锚表与 AC 表）⇒ 六次逃逸**全部落在它的作用域之外**。**判据从「某张表内部自洽」升为「同一可数事实的每一处出现彼此同值」**：事实 id 是**唯一能让机器免猜地分组**的手段（id 即「同一性」的断言本身）。**★ 会诊原议的「自识别腿全档常开」已被父侧干跑实测否掉**（腿 3 常开 ⇒ 存量档红 **34 处**裸模块名；**★ 代码评审 #7 补 as-of：34 为干跑时点的数，分歧审计复算得 26 —— 决策不受影响（26 > 0），见设计档 §12.4**）⇒ **本批增量只剩事实 id 腿**（`docs/2026-09-17-scope-alignment-design.md` §4 D17-0）。
- **三处既有正确性修复（先做，无条件）**：① **FR-0a 深度感知闭括号**（`findMatchClose`：全角 `（` 深度 +1 / `）` −1，**归零处才是本标记的闭括号**）——改前取**首个** `）` ⇒ 任何 `（§3）` 式引注都**截断列表** ⇒ 项数误判（**假红**）；② **FR-0b 围栏状态机掩码**（`maskFenced` / `shapeMaskDoc`：``` 围栏内**整块**与行内 span 同待遇）——改前围栏内容**裸奔**；③ **FR-0c 掩码改「非空白占位符」**（`SHAPE_PLACE`）——改前把 span 内容掩成**空格** ⇒ **项若整体住在 span 里**（``（2 档：`a.md` · `b.md`）`` 这种**本仓必然的写法**）⇒ 段 trim 后为空 ⇒ `actual=0` ⇒ **假红**。**三条各配「改前红 / 改后绿」的负控腿**（`legacyCountMarks` 复现改前形态）。
- **事实 id 腿（本批唯一的新判据面）**：**FR-1 标记语法**（全枚举形 `（8 条 id=X：a · b · …）` **禁省略** 与裸引用形 `（8 条 id=X）`，**共用同一个匹配器**；id 字符集**排除 `@` 与竖线**——它们是 `require-facts` 的分隔符）· **FR-2 跨档分组 ＋ 两条不变量**（① 组内标量/集合全相等 ⇒ 否则红且**报全部出现处的 `文件:行:原文`**；② **仅注册事实**：`require-facts: id@N` 的出现次数锁——**绑定出现不计入 `@N`**）· **防恒真闸**（全域 ≥1 个「≥2 处**档内**出现」的组，且**注册事实**里必须真的 ≥1 个）。**未注册的单例 id 不红**（「一次事实只出现一次」是常态）。
- **FR-3 腿 1 的双模式真值表**：**声明档保持批 16 严格语义**（`N == 项数`，零 `·` 且 N≥2 ⇒ 红——**N-3 不退化**）；**未声明档**加**三条宽松约束**（零 `·` 且 N≥2 ⇒ 跳过 · 只认两侧带空格的 ` · ` · 尾随 `·` ⇒ 跳过）；**带 `id=` 的标记一律走严格模式**。**FR-4 归一化 R-1…R-8**：**值只从标记载荷取**（标记外的散文永不入值）· 整数比较 · 集合 **trim 后精确串等值 && 顺序无关** · 报错报全部出现处。**元原则（D17-8）：每一次归一化都是一次 fail-open 决策——归一只许修呈现，永不许修语义。**
- **FR-5 CHANGELOG 覆盖（两态定位器）**：**死区**（`# Changelog` 到首个 `## [`）含**恰 1 处**那个显式定位标记（批 16 条目里已在用、**本批把它升格为定位契约**）⇒ 绑死区（**交付时点态**）；否则首节含 ⇒ 绑首节（收口后态）；**死区 >1 处 或 两态都不含 ⇒ 红**。**锚定行抽取**（不是正则首例匹配——那正是 `G-常驻3` 的已知雷）＋ **`bind=<源>.<槽>` 三槽**（`changelog.nsN` / `.baseline` / `.added`；**畸形绑定三条各自红**）＋ **等值锁**（首节态下必须 == `parseChangelogCountLine` 的输出——**只读 `release-check.mjs` 的既有导出，该档本批零改动**）。
- **FR-6 强制声明 ＋ FR-6b 面级结构触发**：`docs/` 顶层 · 文件名匹配 `^(\d{4}-\d{2}-\d{2})-` · **日期 ≥ `CUTOFF = 2026-09-16`** · 无声明 ⇒ **红**（**CUTOFF 前 ⇒ 绿**——阴性对照证明边界不是恒红）；**exempt 四闸**（独键 · 必带理由 · 只许写在日期前缀档 · **内容证伪**）＋ **`EXEMPT_BUDGET`**（初值 2，**据实登记为「未实测的初值」**——它只是可见性旋钮）。**FR-6b**：已声明档内有**首列匹配 `AC-\d+` 的表** ⇒ `acs` 必填；**锚形表 ⇒ `anchors` 必填**（**「档内缩作用域」那个口的唯一堵法**）——与 exempt 闸 4 **共用同一个结构检测器**。
- **域的精确定义**：**扫描域 = `docs/**` 递归 − `docs/consult-minutes/**` + `CHANGELOG.md`**；**腿 1 全域跑**（宽松档位）；**腿 2 / 腿 3 / 腿 4 / `require-facts` 只跑声明档**（严格腿）；`docs/consult-minutes/**` 排除的理由**不是白名单而是范畴**（机器产物无作者契约）。**失败方向**：**闭域全 fail-closed** · **开域永久 fail-open** · **没有档能静默从闭域滑进开域**。
- **十二条新负控腿 ＋ 阴性对照**：FR-0a/0b/0c 各一条（**含「改前红」的实证**）· FR-1 标记语法与 id 字符集 · FR-3 三条宽松约束**成对**（未声明跳过 / 声明档同构造 ⇒ 红）· FR-4 归一化 · FR-2 三条（同值 · 次数 · 防恒真）＋ 集合成员 · FR-5 两态 ＋ 等值锁反面 · 绑定三槽 ＋ 畸形三条 · FR-6 边界三态 · FR-6b 两形 ＋ 普通表 · exempt 四闸 ＋ 预算。**全部在纯内存夹具 / 仓外临时档上构造**（D5：仓内零残留）。
- **★★ 实施期发现（据实登记，不藏）**：① **腿 4 的两处 id 抽取口径必须放宽为「可选一个小写后缀」**——`\bA[0-9]+\b` 在 `**A1b**` 上**匹配不到**（`1` 与 `b` 之间无词边界），`AC-[0-9]+` 在 `**AC-4b**` 上截成 `AC-4` ⇒ **假红「AC 号重复」**；而 `A1b`/`A9b`/`A11b` 与 `AC-4b`/`AC-6b`/`AC-9b` **正是本批设计档自己命名的 id** ⇒ 照旧口径**根本不可表达**。② **本批设计档一旦按 A12 带上声明（`anchors`/`acs`），腿 4 当场红在两处真实缺陷上**：**§8.2 的 A4 行 cell 数 5 ≠ 表头 4**（行内一个未转义的字面竖线 —— `含 \`@\` 或 \`|\` 的 id`）与 **A4 是孤儿锚**（§10.3 的 15 条 AC 无一条引用它，且其行无 `（豁免：…）`）。**⇒ 两条都要动设计档既有行，超出本批写域（本档只许「加声明 / 加 `require-facts` / 加事实标记」）⇒ 已 STOP 上报父侧裁定**。**⇒ 交付时点 `node --test` 有一处红（正是这两处），修法 = 改设计档 §8.2 的 A4 一行**（去掉/转义那个字面竖线，并给该行加 `（豁免：…）` 或让某条 AC 引用 A4）。
- **零改面**：**`lib/**` 零改动**（纯测试面 ⇒ **无需重启 DSH**）· **`release-check.mjs` 零改动**（本批**只读**它的既有导出）· **`test/release-check.test.mjs` 零改动** · **零新增测试档**（20 档不变）· 六串零命中 · `failStop(` 恒 18 · 零新依赖 · **`docs/consult-minutes/**` 只排除不修改** · 历史记录既有内容零改动 · 变异/负控**全部在仓外临时副本或内存夹具上做**（仓内零残留）。
- **★ 收口动作（owner = 主代理，本批写域外）**：本条目**落在首个版本头之上、不新开版本头**——因为 `test/release-check.test.mjs` 的 **G-常驻2** 断言 `package.json#version` **等于 CHANGELOG 顶部版本头**，而 `package.json` 不在本批写域 ⇒ **新开版本头会让 `node --test` 立刻红**。故收口只剩两项——**bump `package.json#version` + 新开 `## [x.y.z]` 版本头并把本条目移入**。（**发布门 G3 在交付时点必然红**——它比对的是**首节**计数行而本条目在版本头之上，属死文本；与批 9/16 先例同形。）

## [0.24.0] — 2026-09-16

> **一句话**：文档形状谓词上线：「计数不追列表」「同一事实两处取不同值」「引用了不存在的档」「该有锚的 AC 没锚」——从**靠人眼**变成**机器自己红**（纯测试改动，无需重启）。

**批 16（文档形状谓词 · 四条腿 + **八条负控构造 / 8 条顶层 `test()`** · 本批为纯测试面 ⇒ 无需重启 DSH）**

- **立项形态**：把「文档形状缺陷」（**计数不追列表** · **同一事实两处取不同值** · **引用不存在** · **该有锚的 AC 没锚**）从**靠人眼 / 靠用户质问**变成**机器自己红**。**形态由两条实测否证决定**（需求档 `docs/2026-09-16-doc-shape-requirements.md` §2.3）：**只认显式标记**（正则猜中文量词实测**误报 62%**）· **前向生效**（只作用于档内自带 `doc-shape` 声明的档，存量档**完全跳过、不追溯**）。**形状声明住档内、不住测试里**（D16-3：档自己声明自己怎么验，测试不做第二份真相源）。
- **四条腿**（`test/doc-hygiene.test.mjs`，与批 11 的 DOC-HYGIENE 机械网同档）：① `checkCountMarks` **计数 ↔ 列表**——三条边界缺一即错：**行内代码 span 一律豁免** · **`N` 只认阿拉伯数字**（字面 `N` 不匹配）· **只数同一行内的 `·` 项**；报错文本含**档:行 + 声明值 + 实际值**。② `checkComparePair` **比对对集合相等**（**某侧读到零条目 ⇒ 红**——不得当作「空集 == 空集」通过）；**只做集合型**，计数型明确不入本批。③ `checkRefs` **引用可解析**——md 相对链接恒检 · `路径:行号` 的**路径**受检而**行号不解析**（D4：行号只作 as-of）· **行内代码 span 之内一律豁免**。④ `checkAnchorsAndACs` **AC ↔ 锚互引**——**闸 A** cell 数 == 表头列数 · **闸 B** T1/T2 锚列非空（免锚的合法写法只有 `—` 与层标**连 T3 都不是**两种）· 所引锚 id 必须在锚表中有定义 · **AC 号不重复** · **反向腿（孤儿锚）**：未被任何 AC 引用的锚必须自带**显式豁免标记** `（豁免：…）`（本批设计档的 **A10** 就是那个孤儿锚，豁免语法从它这一行起生效）。
- **失败方向**：**谓词面全 fail-closed**——**扫描集为空 ⇒ 红**（断言 `scanned >= 1`；数的是**进作用域的档**而非「扫到的档」）· **锚表/AC 表定位不到 ⇒ 红**（不是跳过）· **某侧零条目 ⇒ 红** · **声明畸形（缺冒号 / 未知键 / 空值）⇒ 抛，绝不静默返空声明**；**存量档 fail-open**（无声明即跳过，**不影响任何既有档**）。**谓词只报不改**（改档是主代理 / eng_coder 的事）。
- **五条负控腿**（本批新增的顶层用例**初为这五条**：腿 1 · 腿 2 · 腿 3 · 腿 4 闸 B〔含**反向腿**〕· 腿 4 闸 A），**全部在仓外临时档 / 临时副本上构造**（D5 冻结窗口：不动被锁对象；做完即弃、仓内零残留），逐条**区分真红（谓词 / 断言级 `ShapeViolation`）与假红（`ReferenceError` / 整档崩溃）**，并各配**阳性对照**（防「恒红」的假绿）与**阴性对照**（防「恒真」的假绿）。**★ 修复轮再补第 6/7 条**（闸 0「行被吞」· F10「闸 A 后不得整行丢弃」）。**★ 代码评审 #6 修复轮再补第 8 条**（§9 空集类② 的「零数据行 ⇒ 红：双侧空表曾判绿」）⇒ **八条负控构造 / 顶层负控腿共 8 条**（反向腿并入第 4 条）。
- **【计数行】测试**：`node --test` **464/464**（**基线 456 + 本批 8**）。**⇒ 台账 §三 `doc-hygiene.test.mjs` 的用例数 4 → 12 同批同步**（`T-LC2` 等值锁：台账数字必须等于 fs 实测的顶层 `test(` 计数）。**零改面**：`lib/**` **零改动**（纯测试面）· **零新增测试档**（20 档不变）· `test/fixtures/**` 零 diff · 六串零命中 · `failStop(` 恒 18 · 零新依赖 · 历史记录既有内容零改动。
  - **★ 收官实测（本行的推导式是解析器取的首例）**：批 16 顶层 `test(` **12** = 本批 8 条负控腿 + 4 条既有（T1–T4）；**全量 464 = 基线 456 + 本批 8**。**批 16 内部**的分项为 5（初交付）+ 2（分歧审计 F9/F10 修复轮）+ 1（代码评审 #6 修复轮）= 8 —— **该分项不写作 `本批 N`**，因为解析器取本节首例 `本批 N`，两处写法会互相矛盾（**收口时实测命中过两次**）。
- **★ 修复轮 1（2026-09-16，独立分歧审计点名的两条谓词自身缺陷：F9 🔴 / F10 🟡）**——**只改谓词的两个入口，不重做已通过部分**，**顶层 `test(` 9 → 11**、**全量 461 → 463**、台账 §三同批同步（`T-LC2` 等值锁）。
- **★ 修复轮 2（2026-09-16，交付代码评审 #6：§9 空集类② 的 fail-open 缝）**——**`shapeTable` 的 `raw.length < 2` 判据对「表头 + 分隔线、零数据行」不充分** ⇒ **双侧空表时 `anchors`/`seen`/`referenced` 全空而整体判绿**（与 §9 失败方向①「空集 ⇒ 红」相悖；单侧空表被反向腿兜住，**双侧同空则漏**）。⇒ **补零数据行闸**（两侧各报各的、能点名哪张表空）+ **纯内存负控腿 8** + 阴性对照。**顶层 `test(` 11 → 12**、**全量 463 → 464**、台账 §三/§七同批同步。**★ 代码评审第 2 轮点名的 🔴**：本轮**漏改本 CHANGELOG**（`九条 / 8 条 / 464 / 12` 四处未同步且零留痕）⇒ **今补**——**这是本批「改两处之一不算修好」这条自订规矩的第四次复发，且四次都在我这一侧**。
  - **F9（🔴，恒真入口 2.0）`shapeTable` 静默丢行**：旧实现取「第一段连续 `|` 行」，**遇到第一个非表行就 `break`** ⇒ 其后所有表行**既不入表、也不算红**（审计实测：3 行 AC 表中间插一行非表行 ⇒ 谓词返回 `PASS {"acs":2}`，**第三条 AC 完全没被看见**）。**同族第二面**：同一节关键字下若有**第二张表**，也只取第一段 ⇒ 第二张表的 AC **永不校验**。**修**：表体扫描**不再 `break`**，改记「截断位置」并**扫完整节**；截断之后若**仍有表行** ⇒ **新增闸 0**判红，消息含 **`文件:行`（被丢的行号）+ 「行被吞」+ 被丢行原文**，**且必须先于闸 A 报**（表被截断时闸 A 只看得到存活的那几行 ⇒ 被吞的行永远不会被它看见）。**关键设计约束已满足**：**「表被截断」与「表自然结束」必须区分**——判据是「**其后是否仍有表行**」，**不是**「出现非表行就红」（后者会误伤正常排版：**本仓设计档 §10.3 的 AC 表后面就跟着散文**，该档即谓词自己的阴性用例）。**补负控腿 6**（含三条阴性对照：表后接标题 / 表后接散文 / 表**之前**的裸 `|`；另覆盖**同节第二张表**与**锚表侧**）。**变异 M1 实测**：把闸 0 退回「一遇非表行即 break」⇒ 该腿在**审计原始构型那一条断言**上 `Missing expected exception` **真红**，两条阴性对照仍绿。
  - **F10（🟡）闸 A 报红后 `continue` 致整行丢弃**：旧实现给 cell 数不符的行直接 `continue` ⇒ **其 AC 号不进 `seen`、其锚引用不进 `referenced`**（审计：一个**真实存在**的 AC 因此触发**反向腿的二次误报**）。**修**：AC 号与「**该行实际出现的锚引用**」**先记录**，再对残缺行**只跳锚列判定**（层标分层不变量），**不跳 id 记录与引用记录**。**补负控腿 7**（含 F10 两条下游误报的可观察面 + 反向腿的**结构性边界** + 两条零回归对照）。
  - **★ 本轮的诚实自白（写进设计档 §11/§12.2，不藏）**：**F10 声称的两条下游误报（孤儿锚 / AC 号重复）在可构造的形态下均不可观察**——① 残缺行若**丢掉锚列**，谓词**本来就看不见那个引用**（**结构性**：谓词读不到的东西不可能被它看见，不因本次修复而变）；② 残缺行若**首列即 AC 号**，后续行的 AC 号取自**本行首列**（`cells[0]`），**不可能**被误判为重复。**⇒ 负控腿 7 据实钉的是「残缺失效行的任何东西都不得丢」（`referenced` 零丢失 + 反向腿照旧会报 + 两条零回归），而不是钉一条构造不出来的二次误报**；`continue` 的代码缺陷（整行丢弃）本身**确实存在且已修**，只是它的下游症状在本谓词的形态下有更强的守卫（闸 A 先报 + 锚表独立解析）。
  - **文档与登记面同批对齐（改一处即改全部）**：设计档 **§9 空集类补为三个入口**（**零档 / 零行 / 行被吞**）· **§6 伪代码 ⓪/⑥ 两条 `@post`** 与实现同值 · **§8.2 负控表补第 7/8 行**并把口径统一为「**八条构造 / 7 条顶层 `test()`**」· **A7/A10** 与 **AC-6/AC-8/AC-10/AC-11** 四处同改（**基线 + 5 → 基线 + 7**）· **§11 变更记录**与**§12.2 处置表**（F9/F10 由 `Dispatched` 结清为 `Fixed`）· 需求档 **US-4** 与状态行 · 本台账 §三（`doc-hygiene.test.mjs` **9 → 11**）。
  - **零改面**：`lib/**` 零 diff（纯测试面）· `test/fixtures/**` 零 diff · **零新增测试档**（20 档不变）· 六串零命中 · `failStop(` 恒 18 · 零新依赖 · **禁改面零触碰**（`test/stage-gate.test.mjs` · `test/stages.test.mjs` · `test/guard-e.test.mjs` · 平台包 · `docs/` 顶层既有纪要 · 历史记录既有内容）· 变异/负控**全部在仓外临时副本或内存夹具上做**（仓内零残留）。
- **★ 收口动作（owner = 主代理，本批写域外）**：本条目**落在首个版本头之上、不新开 `## [0.24.0]`**——因为 `test/release-check.test.mjs` 的 **G-常驻2** 断言 `package.json#version` **等于 CHANGELOG 顶部版本头**，而 `package.json` 不在本批写域 ⇒ **新开版本头会让 `node --test` 立刻红**。**★ 代码评审 #3 订正**：顶部计数行**已随修复轮改为 `463/463`**；**★ 代码评审第 2 轮再订正**：**终值为 `464/464`**（代码评审 #6 修复轮再 +1，见上行「测试」条）。故收口只剩两项——**bump `package.json#version` + 新开 `## [x.y.z]` 版本头并把本条目移入**。（**发布门 G3 在交付时点必然红**——它比对的是**首节**计数行而本条目在版本头之上，属死文本；与批 9 先例同形。）

## [0.23.0] — 2026-09-16

> **一句话**：配置面与描述面同步：`engCoderEffort` 默认值由 `low` 改为 `medium`（`low` 是唯一可能被静默降成「推理全关」的档）；白名单散文立了常设谓词；清掉十处悬空引用。

**批 14：配置面与描述面同步 —— 「插件自己的契约」与「它对外声称的契约」的一致性；六项里五项改散文或注释、一项改行为（默认值）⇒ 风险不是逻辑错，而是「改漏一处」**

- **★ 立项形态**：本批**六项里有五项是描述面同步**，故**§8.2 的机验锚（A1–A12，逐锚写全「检索目标 / 谓词 / 期望」）才是核心交付物**，不是附属品（会诊 R-9 原话：「§8 若只列人工检查项，本批等于自证失败」）。**一切改动只准字符串锚定、禁行号锚定**——会诊实测行号在本批写域内**已漂三处**（N-1）。
- **FR-1 默认值三处同源（`lib/eng.mjs`）**：抽 `ENG_CODER_EFFORT_DEFAULT = "medium"`（镜像既有 `ENG_CODER_MAX_TOKENS_DEFAULT` 的形态），初值引用它、`else` 分支**显式赋值**它、警告文案随之 ⇒ **P2 的「回落 = 初值」隐式耦合被消除**（`grep 'falling back to'` 的文案现在指向常量值，不再写死字面）。**改值的枚举依据**（会诊 v4-pro 提供、父侧复核形式）：`low` 是**唯一在一切非退化支持集上都可能被 `nearestEffort` 静默落到 `off`** 的程度档——而**本部署实测形状 `{off,high,max}` 恰是它中招的形状**，`medium` 只在退化集 `{off}` 落 `off`；出厂示例（`README` + `cordis.patch.yml`）此前都写 `low` ⇒ **新部署照抄即中招**。**否决「保留 `low` + 只显式化」**：显式化对、但不解决 P1（两家论据都采纳）。**`nearestEffort` 的根修另立批次**（四机制共享面，D14-2）。
- **FR-4 到点文案 + 前置告警（同档）**：三处第一字面统一改为 `超内部截止（内部截止值取自 codexCli.budgetCapMs=<n>）`——**键名补节前缀**（schema 里**没有**顶层 `budgetCapMs`，真键在 `codexCli` 节下 ⇒ 用户在顶层配一个**自然无效**，那正是被引偏的机理）；**第二字面一字不动**（`doc-hygiene.test.mjs:317` 的 needle 期望 **2 次**，它就是这对竞态分支——reject-race 与 resolve-race——的既有锁，**不可合并**）。新增 `PLATFORM_WALL_CLOCK_MS = 600_000`（**平台事实常数，不新增配置键**）+ **前置告警**：**仅 dsh 同步路径**、`budgetCap >= 600000` 时 **spawn 前** warn 一次；**`background=true` 走后台时不告警**（后台无平台墙钟问题，告警即错告，D14-6）；**不引入 `failStop(`**（计数锁恒 18）。
- **FR-2 白名单散文谓词（`test/config-api.test.mjs` 的 U3c2b）**：权威面 = **`TOP` 8 · `ADV_SUB` 6 · `GROUPS` 2 · `GROUP_FORM` 5 = 21 名**（`topAllowed` ×8 · advisor 子键 ×6〔`round1`/`convergence` 另归组键轴〕· 组字段 ×5）——**★ 本条初写「三轴 8/8/5」是父侧把「8」贴错了轴（分歧审计 F2 实测订正；恒等式 8+6+2+5=21 一直成立）**，散文面 = `cordis.patch.yml` 与 `README.md` 的**用户层白名单段** ⇒ **逐文件各一条断言 + 先钉基数 + 双向比对**（散文 ⊆ 权威 ∧ 权威 ⊆ 散文）。提取器**两级过滤**，每一级都由一个**实测陷阱**逼出来：段级切「user 层可配」段（尾部还有一句以「只在 base 配」起头的排除句）· EOL 归一（`README.md` 是 CRLF、`patch.yml` 是 LF）· 行级先切排除子句（`；`/`——`）· 标记剥离 · 首字符小写 + 长度 ≥3（滤 `D-29`/`R1`/`FR-CB5`）· stoplist。**带三条自证腿**（AC-20）：**腿 A = 吞掉标记剥离 ⇒ 多抓**（由 `keys.size > …` 接住）· **腿 C = 构造真空集 ⇒ `assertDocKeysNonEmpty` 必红**（★ 由补腿轮补入：**「空集 = 恒真的唯一入口」此前只是声明、不是已验证的性质**——分歧审计点名）· **从散文删一个键名 ⇒ 「缺项」断言必红**。
- **★ 因果对（D14-7）**：`lib/config-store.mjs` 的 `mergeGlobalConfig` 头注释**补 `runner`**（P4 —— **本批唯一的现役缺陷，只有会诊看到，摸底与独立勘察都漏**）：该处只列四名而 `GROUP_FIELDS` 是五名 ⇒ **谓词会一直红到它补上为止**，故两者**同一 stage** 交付（先出谓词必然红，而那个红会与「其他项未完成」的红混淆）。
- **FR-3 锚 A 的两分支各打各的准确话（D14-9）**：批 13 审计 F8 的遗留——ENOENT（无 git）与 128+not-a-repo **都**留空 `addingSha` ⇒ **都**落「锚 A 未激活：本批新增档尚未提交」，而**在无 git 的机器上那句话是无意义的**（它根本不是提交问题）。修法：取数与报告抽成 `anchorAProvenance` / `reportAnchorA`，**两个分支都置旗标** `notRepo`；**ENOENT 打新写的准确话**（「无 git ⇒ 锚 A 不可判定」）、**128 维持既有的准确话**、**`else` 只在两分支都未命中时触发**（那时 git 可用而 `addingSha` 取不到 ⇒ 那句才是真的）。新增 **T-AP9b** 走真子进程验三形态 + 一条**正控**（证明那句 `else` 没被误关）。
- **FR-5 悬空引用清尸（10 处 / 7 档）**：`DESIGN-dsh-port.md` 7 处 + `DESIGN-advisor-token-protocol-fix.md` 3 处，**盘上零命中、git 历史零命中——只有引用没有正文**。修法 = **只删指针 + 连接词手术，零新增散文、不重指、不新建档**：**重指 `docs/2026-09-13-portability-design.md` 会制造新假指针**（那档主题不对，是批 7 的「产品提示词去本仓指涉」档）⇒ 否决父侧原候选（D14-4）。分布：`eng.mjs` **3** · `advisor-msgs.mjs` **2** · `advisor.mjs`/`consult.mjs`/`index.mjs`/`readonly-tools.mjs`/`state.mjs` 各 1。
- **散文面（D14-10 / D14-11 / AC-24 / 锚 A12）**：`README.md` 的示例值与「缺省」字样 + **理据句**（原句「低推理档把输出预算留给正文」**以 `low` 为前提、改默认值后即成假**）· `cordis.patch.yml:43` 的示例值——**它就是诱捕**：只改 README 不改 patch.yml ⇒ **下一个照抄 patch.yml 的人照样中招**（本批物种的第二次犯罪）。**AC-24 是常设锁，不是 stage 目标。**
- **FR-0 授权门哨（最先做）**：`test/advisor-config.test.mjs` 在基线集内且不在 `AP_TEST_AUTHORIZED` ⇒ 先读该行、**断言含 `test/consult.test.mjs`**（批 15 交付的门哨；缺失即停），再**追加**本档名（**不重写整行**）+ 注释块追加第 ⑤ 条授权理由 ⇒ 数组 5 名。
- **锁面变更（须显式声明，N-3）**：改 `test/advisor-config.test.mjs`（默认值锁两处 + 到点文案/前置告警）与 `test/config-api.test.mjs`（谓词）⇒ 两档均走 `AP_TEST_AUTHORIZED` 授权仪式。**零改面**：`test/fixtures/**` 零触碰 · **不新增测试档**（20 档不变）· 平台包 `dsh-tool-jobs` 零改动 · `docs/` 顶层既有纪要零改动 · 历史记录既有内容零改动（`CHANGELOG.md` `:215` 那条原行不动）· 六串零命中 · `failStop(` 恒 18 · **第二字面仍 2 次** · 零新依赖 · 零删测试档。
- **测试**：`node --test` **464/464**（**基线 456 + 本批 8**）。**★ 本行是发布门 G3 与 `G-常驻3` 读取的「首节计数行」**——**它的推导式由解析器从本节取首例**（`release-check.mjs:59-71`：本节第一个 `**N/N**` · 本节第一个 `基线 X` · 本节第一个 `本批 Y`）⇒ **本节只留这一处推导式**。
  - **★ 上一节（v0.23.0）的计数行历史留痕**：那次交付时点为 `456/456`（当时写作 `基线 453 + 本批 3`）——**该分项本轮已移出本行**，因为解析器会把它当成本节的推导式（**收口时实测命中：取「基线 456」+「本批 5」⇒ 461 ≠ 464 ⇒ `G-常驻3` 红**）。**这是本批「同一事实两处取不同值」的第五次复发，且这次是解析器抓的。**
  - **★ 与「台账 §三零改」的口径冲突如实登记**（批 14 的既有记录）：新增顶层 `test(` 必撞 **T-LC2**（该档 §三的逐档用例数与 fs 实测是**等值锁**——`docs/test-lifecycle.md:158` 已把它登记为「第三把元锁」）⇒ 批 14 **同时更新该档三行的用例数**（`advisor-config` 59→60 · `config-api` 24→25 · `death-provenance` 18→19）并写明理由；`test/test-lifecycle.test.mjs` **零改动**（禁改档）。**若不接受此偏离，替代路径 = 把三个新用例的断言并入既有块**（批 9 收尾轮先例，代价是粒度损失）。
- **D14-12 是核验、非改动**：用户裁定③（`goal`/`authorized` 如实降 T3）的落点 = 批 15 的两档；实测 `docs/2026-09-15-consult-delivery-design.md` §11.2/§11.3 的 **AC-5 / AC-25 已是**「T1（仅 `unattended`）· T3（`goal`/`authorized`）」⇒ **本 stage 为空操作**（不按过期前提改错面）。
- **本批不可真机验证（如实登记）**：`lib/**` 改动**需重启 DSH 才生效** · `console.warn` 的即时可见性 · 仓外部署 profile 的 `cordis.patch.yml` 同步（owner = 用户/运维，本批只登记漂移、不替它改）。
- **★★ 修复轮（2026-09-16：独立分歧审计点名的**唯一代码面缺口** —— 「空集 ⇒ 必红」从未被任何腿触发）**：设计档 §8.2 的 A4 负控承诺「把提取器**故意改坏** ⇒ **空集 ⇒ 必红**」（§6.2 图 2 的 `assert 非空`：**空集 = 恒真的唯一入口**），**而交付里没有任何一条腿把提取集弄成空集**——当时的两条腿实测走的是「喂整档 ⇒ **多抓**」（`sabotagedWhole.keys.size > …`）与「删键 ⇒ 缺项」，**唯一防恒真的那道护栏 `keys.size >= 1` 自身从未被证明会红** ⇒ 那句承诺当时只是**声明**、不是已验证的性质（**设计档 §8.1#3 订正后的边界正是本轮的适用口径**：禁的是新增**测试档/测试层**，在**既有档内增用例是允许的**，条件是台账同批同步）。**修法两件**：① 那道护栏抽成**单点实现** `assertDocKeysNonEmpty(keys, what)`（⓵⓶⓷ 三处改调它 ⇒ 负控证的就是三处**实际调用的那一个函数**，而不是一句会与 ⓵ 漂离的复制品）；② 在既有 **U3c2b** 块内补 **腿 C**——构造 ① **段级失配 ⇒ 块为空**（真实档字节不动、只把段起标记改坏 ⇒ 段级切分返回 `null`）⇒ **提取器入口的非空断言必红**（fail-closed：空块不得静默当空集放过）；构造 ② **块非空但零键名**（把真实白名单段内的拉丁 token 机械抹平）⇒ 提取器**返回** `keys.size === 0` ⇒ **对这条空集复跑护栏 ⇒ 必红**；另附**阳性对照**（同一护栏对非空集不得抛，否证「腿 C 恒红」的假绿）。**变异自证三条**（逐条 byte-exact 回退 + sha256 复核，全为**真红**、无假红）：**M1a** 把新腿的构造改回非空 ⇒ 红在「构造自证②」（实测抓到 11 名 ⇒ 证明红的是**空集**这条性质）；**M1b** 把护栏的 `>= 1` 改成 `>= 0` ⇒ 红在 `assert.throws`（**Missing expected exception** ⇒ 证明腿 C 绑的是**护栏自身**，不只是它自己的构造）；**M2** 删 `config-store:19` 的 `runner` ⇒ 红在 A5/AC-7 那条。**零改面**：**零新增测试档**（20 档不变）· **零新增顶层用例**（`config-api` 用例数仍 **25** ⇒ 台账 §三的计数单元格不动、T-LC2 等值锁不受影响；仅同批改写该行的**存续理由**把腿 C 登记进去）· `lib/**` **零 diff**（30 档 sha256 全等）· `test/fixtures/**` 零 diff · 六串零命中 · `failStop(` 恒 18 · 零新依赖。

## [0.22.0] — 2026-09-15

> **一句话**：会诊接上平台后台投递（完成时**自动通知你**，不用轮询）、退役旧轮询工具、纪要**先落盘再通知**、未消化的会诊会拦住下一次发起。

**批 15：会诊结果的投递与消化 —— consult 接上平台 job 投递、退役轮询工具、digest 单消费面 + 消化门禁；**补的是本仓落后上游六天的那一段**

- **★ 立项事实（本批的第一件事）**：上游 `3e1234b`（2026-09-07 04:10）已以 **digest 自动注入退役 `consult_check`**，而本仓复制源是 **`3e1234b^`**、首个提交 `aeffdf7`（2026-09-01）⇒ **本仓抄的是改造前的祖先，六天里从未记录这次分叉**（唯一痕迹 = `:215` 那行还在对上游已删协议做加固）。本批把这段补上；**「停下汇报 / 三豁免档 / 纪要默认落档」三件是本仓走在上游前面的加法**。
- **FR-1 派发与投递**：`consult_start` 不再 fire-and-forget，改为 `jobs.start({ kind: "consult", label, owner, outputLimitBytes: 131072, run })`——**逐字段对齐 `lib/eng.mjs` 的 `kind: "eng-dsh"` 先例**，取服务复用 `lib/advisor.mjs` 的 `getJobsService`；`run` 体内起 N 个只读子代理并 **await 全 settle**（含早停）。`composeConsultDigest` 抽为**纯函数**（头部行 `[consult #id finished|stopped — N of M replied (F failed[, S stopped])]` + 逐条回复 + **有效数段**）。**★ 落盘次序是本批的兜底机制**：settle 时**先写纪要原始层，再让 job complete** ⇒ **投递成不成功，纪要都在盘上**（失败方向：投递面损失只许是「汇报」，不许是「记录」）。
- **FR-2 退役 `consult_check`**：删注册点 + 删 `checkConsultSession` 与其 `waiters` 机制（**18 个字符串点 / 26 个调用点**分面处置；`lib/**` · `lib/prompts/**` · `README.md` **零命中**）；`consult_start`/`consult_stop` 描述同步改；eng/escalate 的 `toolFilter` deny 名单**删名**；`test/death-provenance.test.mjs` 的 **T-AP1d 改指 digest**（消费面换人后，批 6「死亡行必须经**生产消费面**可见、不得手搓等价物」的纪律零削弱）。**★ 并逐字反转**批 14 A 项那句「There is NO completion notification … you must come back yourself」——本批让 consult 有通知 ⇒ 那句变假；`37d7eef` 的历史**不重写**，只在设计档 §10 偏离表与本次 CHANGELOG 留痕。
- **FR-3 消化纪律与门禁**：缺省 = **停下向用户汇报**；三豁免档 = 「无人值守」（**仅此档在 start 声明**，`note` 必填）/「明确目标」/「明确授权」（后两者**在送达时判**，落纪要裁定层 + ack——**三处机制留痕都在 settle 前合成，送达时判定写不进它们**）；**门禁不变量** = 不存在 `settled ∧ ¬digested ∧ ¬minutesExempt` 的会话 ⇒ 命中即 **拒发 + 内联未消化 digest + ack 指引**（**拒发即恢复通道**）；**台账孤儿扫描**（有 `started` 无 `settled`/`stopped`/`disposed` ⇒ **建议性提示、不阻断**，且在飞会话不误报）；`lib/prompts/main.md` 重写（含「wakeup 回合**先 `job_output` 读全文**，再处置」——完成通知只含一行指针）。
- **★ 两处有意偏离**：① **`stopped` 会话照产「墓碑 digest」**（偏离上游 `T-R17c`）：退役轮询面后 digest 是**唯一**消费通道，stop 无 digest = 已收到的回复整批蒸发 + 死亡行失去消费面（**直接打穿批 6 的死亡行裁定**）；② **`jobs` 缺失 ⇒ 拒发（fail-closed）**（偏离仓内「响亮告警 + 回落同步」先例）：先例前提是工作量适配平台 600s 墙钟，而 consult 的预算（`consultTimeoutMs`，**缺省 600000ms**）远超它 ⇒ **回落路径自身就违约通知保证**，且 consult 是 N 路并行。**另登记两处**：`kind: "consult"` **不带路由后缀**（会话混跑 dsh 子代理与 codex-cli 行，带后缀必有一侧说谎）· **不做 `escapeXml`**（DSH 的 `job_output` 是纯文本、无 XML 信封）。
- **★ 纪要默认落档（本仓加法）**：`docs/consult-minutes/<date>-consult-<id>-minutes.md`——**机制只写 §0 汇总 + §1 原始层**（有回复超 **8000 字软顶**时补 **§1.1 未截断全文**），**§2–§5 裁定层由主代理写**（**插件永不写纪要的裁定层**，这是「默认落档」能落成机制的关键）。**命名按 `<id>` 派生而非 `<topic>`**：settle 时刻题目不可知 ⇒ 机制必须能**确定地**命名。
- **台账（新增）**：`$DSH_HOME/.thincoder/consult-ledger.jsonl`，**append-only**（`started`/`settled`/`stopped`/`exempted`/`digested`/`disposed`）；**写失败仅 warn、不阻断投递**（取证面不承重）；读者**前向兼容**（未知 `ev` 忽略、不报错）；并兼任 **id 计数器续接**的事实源（重启后不复用 id ⇒ 纪要档名不碰撞）。
- **零改面**：`lib/advisor.mjs` 零 diff · `test/fixtures/**` 零触碰 · 平台包 `dsh-tool-jobs` 零改动（在仓外，本批只接上去）· **不新增测试档、不新增顶层 `test(`** ⇒ 台账 §三零改 · 六串零命中 · `failStop(` 恒 18 · 零新依赖 · 本档 `:215` 那条既有行**原样不动**（历史记录不是消费点）。
- **测试**：`node --test` **453/453**（**基线 453 + 本批 0**——新面的断言**并入既有块**，顶层 `test(` 计数不变，T-LC2 逐档用例数不变）。**锁面变更（须显式声明）**：`test/consult.test.mjs` 在基线集内且不在授权面 ⇒ 走**授权仪式**（`AP_TEST_AUTHORIZED` 逐档登记 + 裁定引用写进同处注释；**本批零退役** ⇒ 台账 §四 保持为空——**授权通道 ≠ 退役登记**）。
- **本批不可真机验证**：投递真的会到（空闲开回合 / 忙时注下一步）· 「停下汇报」的实际体验与质量（**质量只能人眼**）· 纪要落档的实际形态。**本批触碰 `lib/**` ⇒ 需重启 DSH 才生效。**
- **★ 修复轮（2026-09-16：独立分歧审计 F1/F14 + AC partial 的处置）**：**F1（🔴）纪要落点改子目录** —— 机制落点由 `docs/<date>-consult-<id>-minutes.md` 改为 **`docs/consult-minutes/<date>-consult-<id>-minutes.md`**（用户裁定；`test/doc-hygiene.test.mjs:122` 明文「域 = `docs/` 顶层：子目录天然在域外」）。**原落点是双侧实跑可证的陷阱**：写侧落顶层，而检查侧的 R-25 登记谓词 `docsTopLevel()` **非递归**只读顶层、且要求顶层每个 `*.md` 登记在 `docs/README.md` 全文里 ⇒ **真跑一次会诊就会让套件红**；又因各测试档注入临时 cwd ⇒ **陷阱只在生产触发**（代码侧零缓解）。**F14（🟡）悬空指针改自含**：`test/death-provenance.test.mjs` 的 ④ 条原写「见 `docs/test-lifecycle.md` §一」，而 §一 是**通用三层判据表、没有 consult 行** ⇒ 改为**内联理由 + 指向真实落点**（§三 的 `consult.test.mjs` 行），并同物种订正 `:984` 的授权通道指针 `§一 → §二「退役的合法路径」`；**`docs/test-lifecycle.md` §三 的存续理由真的改写**（「锁会诊跨回合存活」⇒ **平台 job 投递 + digest 单消费面**下的跨回合存活与有界终止）。**AC partial 处置**：**AC-5 / AC-25 的 `goal`·`authorized` 两档如实降为 T3**（只有提示词承载、零机制——**不发明新机制**，设计档 §11.2 同批同步）· **AC-7 形状腿补成可机检**（机制产的纪要必须给每条回复**恰一个编号槽位** `[N]` 密排 `1..N` ＝「处置行数 == 回复数」的形状前提）· **AC-16 正向锁真的加进测试**（`Delivery is AUTOMATIC` / `STOP and report to the user`；反向：批 14 那句只准住注释）· **AC-20 的 `alreadySettled` 错误用例补测** · **AC-23 / US-12 真实覆盖**。
- **修复轮的测试与零改面**：**零新增测试档 · 零新增顶层 `test(`**（全部并入既有块 ⇒ 顶层计数不变、T-LC2 逐档用例数不变、台账 §三零改）· 全量 `node --test` **相对基线零新增用例且全绿**（453 例）· 锚 V1–V10 与零改面逐条复跑 · 设计档 §7 ④ / §8.2 V8 / §11.2 分层表 / §11.3 逐条同批同步。**★ 已知残余（父侧裁量）**：纪要落点的**字面路径**在 `lib/prompts/main.md` 与 `README.md` 仍写旧形态（**描述面与实现不一致**——digest 自报的 `minutesPath` 才是权威且 ack 走 fs 存在性校验；两档不在本修复轮的逐 stage 写域内，故**只登记不改**）。**⇒ 已由下方「收尾修复轮」闭合**：两档订正为子目录形态 + AC-16 锁组加**路径正向锁**。

- **★★ 收尾修复轮（2026-09-16：交付代码评审轮次 1 的两条实质发现 —— job `advisor-dsh-2`，`VERDICT: PASS`，🔴0 · 🟡4 · 🔵3）**：两条都**长在修复轮 1 自己新增的代码里**（分歧审计看不到——它们随修复轮 1 才进来）。**#1 看门狗泄漏**：`lib/consult.mjs` 的 **stop-竞速早退分支**在 `setTimeout(watchdog)` **之后**才判 `session.stopped`，却**漏 `clearTimeout(watchdog)`** ⇒ 定时器 + 已 settle 控制器**滞留至 `consultTimeoutMs`（缺省 600000ms）**。**★ 而这不是新物种**——同文件 codex 行 `finally` 的注释（advisor 🔵#2 的产物）**逐字记录过它**（「看门狗必须在这里显式清掉，否则 unref 定时器 + 已 settle 控制器滞留至 timeoutMs」）⇒ **修复轮 1 新增的早退复刻了自己刚修过的 bug**。**#2 终结事件漏 `sessionId`**：三类终结事件（派发拒发的 `disposed` · 失败信封的 `settled` · `stopped`）都不带 `sessionId`，而孤儿扫描 `consultLedgerOrphans` **按 `sessionId` 过滤本会话的行** ⇒ 它们被**系统性丢弃** ⇒ **永远关不掉自己的 `started` 行**。**可达后果**：`jobs.start` 抛错被拒发后（如撞平台 per-owner job 上限），该会话**此后每次 `consult_start` 都附加一句幽灵提示**「#N …… 未见 settle——可能因重启丢失」——**对一个实际被拒发、且已落 `disposed` 行的会诊，这是误导性陈述**。**修法取「写侧补 `sessionId`」**（不取扫描侧 id 级关闭），三条理由：① `sessionId` 本就是台账行 schema 的一部分（设计档 §7 ⑤），且同文件 `started` / **正常** `settled` 写点都带着它 ⇒ 缺它的三处是**写侧自相矛盾**，不是读侧策略；② 台账是 **append-only 取证工件** ⇒ 读侧打补丁把**错的字节永久留在盘上**（人眼与未来读者读到的仍是缺字段的行），写侧修才让工件自描述；③ 读侧「id 级关闭」会让**其它会话**的同 id 终结行关掉本会话的 `started` 行（今日靠 `ledgerMaxId` 全局续接侥幸安全）⇒ 等于**悄悄削弱那条专防跨会话污染的过滤**。
- **收尾修复轮的描述面与版本记事（评审 #3 / #5）**：**#3**`lib/prompts/main.md:30` 与 `README.md:146` 仍写**旧顶层落点** `docs/<date>-consult-<id>-minutes.md`，而 F1 修复后真实落点是 **`docs/consult-minutes/…`** ⇒ **主提示词是模型可见的指令面，会把 wakeup 回合引向错路径**：两处就地订正，并按评审追加要求**在 AC-16 锁组加路径字面正向锁**（断言两档含 `docs/consult-minutes/` **且**不含旧顶层字面——带谓词自证）；**#5** 本条目内两处路径形态不一致（上面 `:14` 的旧顶层 vs 修复轮注记的已订正形态）⇒ **就地订正**（本条目是本批自己的交付物、发布前可改，与「历史行不动」不冲突）。**测试与零改面**：新面全部**并入既有块**（**零新增测试档 · 零新增顶层 `test(`**）⇒ 顶层用例计数与台账 §三零改、T-LC2 逐档用例数不变；两条实质修各带**自证腿**（删 `clearTimeout` 的变异 ⇒ 点名该腿必红；把 `disposed` 行改回无 `sessionId` 形态 ⇒ 幽灵提示**必现**的对照腿在场内，且断言走**生产站点**＝`apply()` 注册的 `consult_start` 工具 `execute`）；另加一条**写侧静态锁**（四个终结事件写点逐一断言带 `sessionId`——覆盖「失败信封」这条现有桩下不可达的写点）。**两条 Deferred 登记在案不修**：**ack 弱绑定**（`minutesPath` 只做 fs 存在性校验，不绑内容——要强绑须动 ack 面语义＝设计变更，超出修复轮写域）· **`README.md:148` 陈旧机制描述**（仍写 `main_history` 工具回看历史，而该工具在本仓已退役、改为主历史尾部直接注入——与 X-1 同物种，登记待下一批与 X-1 一并处置）。

## [0.21.0] — 2026-09-15

> **一句话**：七条老登记逐条回盘核实——**三条描述本身就写错了**、两条范围比登记大得多、一条比登记更便宜。

**批 13：登记面与判据面余项 —— 七条登记回盘 + D-38 清偿；其中三条登记描述本身是错的，而「枚举/规格不追列表」这个病在四层评审里各被抓住一次**

- **本批的第一件事不是写代码，是把七条老登记逐条回盘核**（登记表是**快照**，它的家只有人眼闸 G7）⇒ **三条描述是错的、两条范围比登记大得多、一条比登记更便宜**：
  - **O-E5 说反了**：登记写「评审传相对而写传绝对 ⇒ 预闸 miss」。**实测不成立**——`normalizeDocPath` 的 `resolve()` 本就把相对转绝对，三种形态归一为同一串，两向查找都命中。**真实的是基分叉下的错根锚定**：基错时 **hash 侧 fail-closed**（不绑文档集 ⇒ 续期恒拒，可用性损伤、方向安全）而 **冻结侧 fail-open**（冻结集锚在错根 ⇒ 预闸对真实绝对路径写**静默放行** ⇒ **在飞窗口的文档冻结失效 = 保护性损伤**）⇒ **比登记的「miss」更坏**。
  - **R-9 是 4 项 / 2 个文件**（不是 1 键 1 文件）：缺 `advisor.contextTokens`（批 5）· `advisor.standardsDoc` + `advisor.documentMapDoc`（批 7）· **组字段 `runner`**（**早于批 5**）；且 **`README.md` 有同构的第二份清单**（登记完全没提）。
  - **R-4a 是 3 处同类**（不是 1 处）：`death-provenance` 的 T-AP7 与 T-AP9 锚 A + `design-review-guard` 的 T-G9 ⇒ 真实严重度 = 「**没有 `.git` 的副本里整份套件部分转红**」。
  - **外加父侧自己的简报也有一条错的**（「6 维句 design 与 code 都发」）——**四家会诊模型全部独立指出**，源码裁决确认它们对。⇒ **「登记文本订正」被列为与代码修订同级的交付物。**
- **R-5 判据补齐**：设计评审的系统提示列 **7 维**（含 **Document ownership**），而 design 专属的用户消息句只列 **6 维** ⇒ **原地追加第 7 维**（**无条件**——该句本就在 `reviewType === "design"` 块内，**分支本身就是那个条件**），并加**负向锚**把「**design-only**」这个边界本身锁死（code 评审消息**不得**含该子句）。
- **R-6 键化**：code 评审的判据档从 `<cwd>/.thincoder/advisor.md`（**上游产品名当目标仓约定路径**）改为可由**独立声明键 `advisor.criteriaDoc`** 指定，**六面接通**（服务端白名单 + PUT 校验 + merge 白名单 + 生效下探 + 消费面 + 客户端 UI）且 **`loadAdvisorMd` 升三态**（声明可读 ⇒ 注入 / **声明不可读 ⇒ 响亮句点名该键** / 未声明 ⇒ **legacy 链逐字节保持今日行为**）⇒ **对存量用户零行为变更**（用户裁定：遗留链**保留并标 legacy**，退役另立批次）。**严禁并入 `standardsDoc` 家族**——两者语义不同域（一个是 code 判据**正文**、一个是两面都注入的**追加段**），并键会**静默替换**声明了标准档的仓的 code 判据。
- **R-4a 收紧（★ 本批最重的一次自纠）**：初版容忍条件只看 **`status === 128`**。**父侧与独立审计各自实测证实**：`git show HEAD:<path>` 在**两种**情形下都退 128 —— ① 不在仓库内（stderr = `fatal: not a git repository …`）· ② **在仓库内但该 path 在该 revision 不存在**（stderr = `fatal: path '…' does not exist in 'HEAD'`）。⇒ **只看 status 会把 ② 这种真回归（文件被改名/删除）从「红」降级成「静默 warn」——比本条要治的原问题更糟**。**修法**：同时匹配 stderr；**`bad revision` 与 `path does not exist` 两种 128 仍 `throw`**。**审计比父侧更准的一条**：**只有 T-AP7 使用 `HEAD:<path>` 语法**是唯一暴露于该危险路径的，另两处的 git 语法对不存在的 path **返 exit 0**。
- **R-25 登记机检**：仓规「新建文档必须先登记到本地图」**此前无机检**（纯人眼闸）⇒ 落一个**并入既有块**的谓词（**不新增顶层 `test(`** ⇒ 台账零改）：域 = `docs/` 顶层 `*.md`（**非递归**）· 例外**恰一条**（`README.md` 自身）· 断言 = 域内每个 basename 必在 README **全文**的 `](name.md)` 链接里（**只认纯文件名形态**）· **带四腿自证**（合成未登记名 ⇒ 必红；空登记簿 ⇒ 必红）。**落地即绿、零追加豁免**——**而它建的当晚就抓住了本批自己**：我提交那三档时漏登记，V8 当场报红。
- **D-38 清偿**：`lib/eng.mjs` 两处陈旧活句（`:52` 的「逐字节锁着」→「**可执行行**逐字节」；`:471-472` 的「`stage-gate` 逐字节锁该切片」→ **该切片受四标识符禁用检查覆盖，逐字节锁区间 `[makeWriteGate, WG_END)` 从切片结束处才开始、两者不重叠**，并点名真正约束 helper 位置的活断言）。**注释 only**；且实测**修它无需重基线夹具**（两处都在字节锁区间之外）。
- **R-4b**：删 `deathLine` 循环后的**不可达 `return`**（`|| dLen === 0` 使末轮必返）——**行为逐字节不变**。
- **R-8**：`lib/index.mjs` 的 `check` 示例去本仓形状。
- **零改面**：`lib/**` **只有注释改动**（`eng.mjs`）· `test/fixtures/**` 零触碰 · **批 6 那十档基线档里只有 `design-review-guard.test.mjs` 被改**（**已在 `AP_TEST_AUTHORIZED`**）· **不新增测试档、不新增顶层 `test(`** ⇒ 台账 §三零改 · 六串零命中 · `failStop(` 恒 18 · **453/453**。
- **★ 本批的元教训：「枚举/规格不追列表」这个病，四层评审各抓住一次**：① **设计评审 #1** 抓到 G9 的验收面漏 AC-22；② **独立审计 F3** 证伪 §9 边界 10 的「`PK_KEYS` 加一键 ⇒ T-PK14 家族四面自动扩」（T-PK14d **不吃 `PK_KEYS`**，而它是 **AC-13 的唯一覆盖点** ⇒ 第三键的 merge 行为**零测试**）；③ **代码复评 #1 = `VERDICT: FAIL`**——收紧后的谓词有**四处副本**没同步（含**父侧自己的需求档 US-3**）⇒ **同一机制两套互斥规格**；④ **代码复评 #2 #6**——**第五处副本**藏在 §6.3 的**代码块**里（前四次扫描都只看表格）。⇒ **专门治它的批次，被它抓了四次。**
- **登记面新增**：**R-33**（「登记说错了」同物种）· **R-34**（**`self-consistency ≠ protection`**——两侧同函数同基只证明「一致地锚在同一个根」，**不证明那个根是对的**）· **R-35**（**全局钩子拿不到会话身份**——`makeDocFreezeGate` 注册为全局 `tools/pre-execute`，闭包只吃 `getFreezeSet` ⇒ **任何需要「按会话」的判据在此形态下无法实现**；这是 O-E5 修法方向的**结构性前置条件**）· **R-36**（判据注入无预算 · R-25 反向腿）· **R-38**（`engCoderEffort` 默认 `low` 在不支持 `low` 的模型上**必然静默降级到 `off` = 推理全关**，而 README 让人照抄的正是 `low`）· **R-39**（V1/V7 无常设锁）· **D-38 → 已修**。**R-37 已撤回**（父侧误登「设置页没有 `budgetCapMs` 输入框」——实测该输入框在 `client.js` 里，label 还写着「须低于 `run_code` maxWallMs」）。
- **本批不可真机验证**：进程 cwd 与会话 cwd 是否真会分叉（需活会话观测；这也是 O-E5 不修的站得住理由之一）· 设置页第三个输入框的交互 · 补第 7 维后评审员的实际行为。**本批触碰 `lib/**` ⇒ 需重启 DSH 才生效。**
- **测试**：`node --test` **453/453**（**基线 453 + 本批 0 新用例**——四类断言全部并入既有块）· 变异合计 **9 条 + 谓词级三形态探针**（逐条附「打红的是哪条断言」、**全部 byte-exact 回退 + sha256 复核**、**无假红**）。

## [0.20.0] — 2026-09-15

> **一句话**：把一处「逐字节保存整个函数体」的测试锁收窄为**语义锁**（以后改一行注释不用再重刷 79 行）。

**批 12：`WRITE_GATE_FIXTURE` 锁面收窄 —— 把「改一行注释就要重刷 79 行夹具」变成「只锁可执行行」，并在过程中由独立审计揪出一个本批亲手引入的假绿面**

- **锁的形态**：`WRITE_GATE_FIXTURE` 原本逐字节保存 `lib/eng.mjs` 里 `makeWriteGate` 的**整个函数体**（**79 行 / 4821 字符**，其中 **32 行是注释 = 40.5%**）⇒ **改一个字的注释就要把那 79 行整个重刷一遍**（批 11 **被迫三次**）。现在只锁**可执行行**：`stripComments`（**实现零字节未动**）→ 逐行 `rtrim` → **丢空行** ⇒ **47 行 / 2677 字符**，字节与顺序仍逐字节锁死。
- **「丢空行」不是可选项，是实证结论**：剥离会留下**注释骨架**（32 个仅缩进的伪空行 + 1 个尾空格）⇒ **只去注释的话，删/改/挪/增四种纯注释改动全部仍会红**。四家会诊在这个点上给了**相反**答案，父侧逐条实测裁决：**glm 对**；反对丢空行的两家，其理由（「会削弱注释/代码位置互换的检测」）**在事实层面不成立**——位置互换是**代码行顺序**变，丢空行不影响。
- **★ 一条真漏洞，由独立审计抓到，且是本批引入的**：`stripComments` 的行注释规则 `(^|[^:])\/\/[^\n]*` **只认 LF**，而 JS 的 **LineTerminator 是 LF \| CR \| U+2028 \| U+2029** ⇒ 在 `//` 后插入 CR/LS/PS 时，**解析器认为注释在其处结束（后面的代码是真的）、剥离器却把整行吃掉** ⇒ **代码在锁眼里消失、写门禁实际变成 fail-open，而 A2 全组保持绿灯**。收窄前的逐字节锁对任何字节改动**必然红** ⇒ **这个缝是收窄带来的**。修法 = **先统一四个行终止符再剥离**；父侧**先验后改**（三种终止符 假绿→红 · 整片 CRLF 不误伤 · **归一态逐字节不变 ⇒ 夹具无需重推**）。
- **而设计档里恰好写着一句为它背书的话**：§9 边界-3 原文「**该弱点在 A 下只可能误红、不可能假绿**」——**被我自己的推理写下的、并被一个具体变异证伪**。我的推理**只覆盖了「字符串里含 `//`」这一形态**，**完全没想到行终止符这一维**。⇒ **元教训（已落设计档 §13.2.0）**：「**对『某个弱点不可能造成 X』的断言，本身就是最需要被对抗性测试的一句。**」
- **三个一行守卫堵三个真缺口**：① **顺序锁**——`wgEnd` 的定位标记**本身就是注释**（`indexOf` 原始 **15722** / 剥离后 **−1**）⇒ **必须先切片、后剥离**，而该顺序**此前无任何断言守着**；② **域自检**——剥离器自述「对字符串含 `//` 的场合足够」，**升格为等值参与者后该声明承重相等正确性** ⇒ 从注释升级为断言；③ **合并签名正则**——`"frozen".includes("designFreezeSet")` 是 **false**（freeze **无 n**）⇒ **旧断言从没拦过「把预闸函数拖进写门禁」这类合并**（D-E1 要防的最重一类），它只拦 `frozen: ` 文案。**这三条都是「今天就已经存在」的缺口，不是本批新增的。**
- **两条被证伪后修掉的判据**：① **AC-6** 原写「先剥后切 ⇒ 该断言红」——**实测不可能**（该变异下 `wgEnd = −1`，**先撞边界断言**，顺序锁根本到不了）；改为「在位 + 在明确输入下是唯一失败断言 + 如实登记其价值是把不变量写成可读断言」。② **AC-9 的幂等自检是 present-but-inert**——`norm` 恒在 `normalizeExec` 的像集里 ⇒ 等值断言必然先红，**7 种夹具污染下它的消息从未出现**；改成**三条直接判定夹具原始文本**、**全部排在等值断言之前**（经字节偏移复核）。
- **接受的代价（明写，不靠猜）**：**注释层完全自由**（文字 / 位置 / 行数 / 缩进）⇒ **注释与代码脱节从此无锚捕获**，权威 = 设计档 + 评审；**两个例外**（切片内新增 `/*` ⇒ 域自检红；改右界标记文字 ⇒ 边界断言红）；**切片内行尾风格不再致红**（行终止符统一的必然结果，已登记）。
- **零改面**：`lib/**` **零字节**（**含 `lib/eng.mjs`**）· 两个 `.txt` 夹具零触碰（受 T-AP9 锚 B + 口径锁双重保护，**结构上改不得**）· **基线那十档**逐个零编辑 · `stripComments` 两条正则逐字节不变（它同时承 T-E18 计数与 A8 负向断言）· 顶层 `test(` 恒 **24** ⇒ 台账零联动 · 无新增测试档 · 历史记录零改动。
- **新增缺陷登记 D-38**：`lib/eng.mjs:471-472` 的活注释把锁归给了一把**不存在**的锁（称 `stage-gate` 逐字节锁该切片，而它只查四个禁用标识符）——**与 `:52` 的「措辞过宽」性质不同**（那是锁存在、覆盖面写大；这是指向不存在的锁）。两处受本批 **N-1 冻结**不可修 ⇒ 登记 + **触发条件 = 下一次触碰 `lib/eng.mjs`**。
- **流程留痕（本批一半价值在此）**：会诊 id 1 **4/4 交付**（**§1.1 是裁决分歧的实证表**）→ 设计评审**轮次 1 即 `PASS`**（🔴0，对比批 11 烧了五轮）→ 实施 17 变异 → **独立分歧审计 🔴1 🟡3 🔵4** → **设计修订** → 修复轮 **25 变异** → 交付代码复评 **`VERDICT: PASS`**（两轮共 13 条发现，全部处置）。
- **三条本会话新长的纪律**：① **收窄一个锁，就是在给攻击面搬家**——旧锁的「对任何字节改动必然红」本身是一种强度，收窄必须重新论证**逃逸面**，而**论证要实测、不能推理**（我就推理错了）。② **「修正一处错指针」这个动作本身会引入新错**——我在改正 §13.2.2 时把 `WRITE_GATE_FIXTURE` 的区间写成了它并不覆盖的那一段。③ **一个会诊结论可以有对的结论 + 错的机理**（v4-pro 的「预剥离夹具」结论对、逃逸机理错；kimi 的「零反引号」事实错）⇒ **会诊/审计也要逐条回盘**。
- **测试**：`node --test` **453/453**（基线 453 + 本批 0 新用例——本批**不新增测试用例**，全部断言并入既有 `test(` 块 ⇒ 顶层计数恒 24）· `ledger-parity` 6/6 · 发布门 **6/6** 机械闸 · 变异合计 **42 次**（17 + 25），**逐条附「打红的是哪条断言」、每次逐字节还原 + SHA-256**。

## [0.19.0] — 2026-09-13

> **一句话**：文档纪律成文：D1–D7 从「被引用 22 次的未定义编号」变成**可读的七条法律**，落进 `METHODOLOGY.md`。

**批 11：D1–D7 文档纪律成文 + 上游失败路径语义 + DOC-HYGIENE 提示词级纪律 —— 把三条只在上游或只在我们脑子里的纪律落到本仓，且形态自含可判**

- **D1–D7 从「引用 22 次的未定义编号」变成可读的七条法律**。这七个编号在本仓被引用 **22 处**、**零内容**——真正的内容只活在上游 `src/prompts/discipline-engineering.md:103-111`。现在它住进 `METHODOLOGY.md` 的新子节，**规范层零状态句**（规范里没有会过期的句子 ⇒ 不会漂），「我们做到哪了」是一份**带 as-of 提交的归档快照**、只活在设计档 §10（快照**只会老、不会漂**）。上游关系取**改写 + 出处行**：既不照抄（会上游含本仓**已废除**的名词与**不存在**的载体 ⇒ 进口未定义名词），也不纯引用（上游 checkout **不随插件发布** ⇒ 规则对发布产物不可见）。逐条现状：**D1 写权矩阵完全缺席**（本批新写）· D2 已有（**收编**既有的两条 bullet，否则新子节第二天就违反 D2 自己）· D3 部分机检 · D4 部分 · **D5 已实现为机制、未写为纪律**（批 6b 守卫 E，本批成文并指向该机械腿）· D6 部分 · D7 一半。
- **D7 的处理值得单独说**：上游 D7 含「变更留痕 + 核销同步」两半，而**「核销同步」已在批 10 明文废除**（R-20）。本批的写法是 **指名道姓地否定它一次**——「上游 D7 另含『核销同步』半条——**不吸收**（R-20 已废除该名词）」——**废弃一个名词的正确方式是否定它一次，而不是假装它没存在过**。
- **失败路径不再是死路**。上游定义 11 条失败路径，我们只有 ~17 个非成功返回、各自带一句 detail 与 ≤2000 字符的 partial——**没有「不自动重派」的明示、没有可选项菜单、没有用户裁决框架**。现在一个固定后缀块由 `failStop()` 追加到**每个终态失败返回点**（**17 个，父侧逐点核对全部在 spawn 之后**），给出**五项恢复菜单** + 不自动重派 + 三要素（崩在哪一步 / 已改了什么 / 哪部分未动）。**菜单是五项而非上游四项**：「**改道**（换执行通道或策略）」是对上游清单的扩展，**必要性有实测**——批 10 的 codex **连续两次 `PROCESS_ERROR`**，上游四项里**没有一项对症**（重派会用同一坏通道再死一次）。同时把 `lib/index.mjs:937` 那条**现行的自动重派指令**同批划界：保留「子代理**自报**阶段失败 ⇒ 重派一次」（出口干净、工作区可检），新增「崩溃/超时/abort ⇒ **不自动重派**」（出口脏、工作区未知）——**不划界就会留下两条互相矛盾的纪律**。
- **两类失败靠返回点位置区分，不靠内容判据**：预检拒绝（task 缺失 / token 门 / in-flight 单飞——**工作未发生**，自带补救指引）发生在 spawn **之前**，终态失败全在 spawn **之后** ⇒ wrapper 只挂后一组。**明令禁用内容判据**（那会与本批「谓词要写全」的标准不符）。
- **DOC-HYGIENE 有了在所有会话都看得见的提醒面**：落 `lib/prompts/discipline.md`（经 `systemPrompt.section` 注册，**进每个会话含主代理**），而不是只在工程模式注入的 `engineering.md`——因为文档卫生的病（计数漂、悬指针、静默写坏）**所有模式都咬**。五条各带可判谓词：计数与列表同改 / 指针可解析（**档名：§节**，禁「见上」）/ 写后回读 / 状态行与事实同步 / 描述面与实现一致。
- **「写入静默失败」终于有机械网**：新增 `test/doc-hygiene.test.mjs`（4 用例）做两件事——**U+FFFD 全仓扫描**（扫描面 `>= 80` 档 + **probe 文件必含**自证，防「空集合假绿」；落地前实测全仓 = 0 ⇒ **零白名单**）与**五常设档 canary**（各含真实顶层标题/表头锚 ⇒ **截断为 1 行立刻红**，本会话真发生过）。本仓三次实证的静默写坏（PowerShell 双编码 · shell 单行脚本把 METHODOLOGY 截成 1 行 · U+FFFD）由此进网。
- **本批没花掉那笔用不上的授权**。用户预接受了「T9 夹具重新基线」，而**四家会诊一致反驳其前提**：T9 测的是 `buildCoderBrief` 在 **stages 缺省**时的输出，persona 与工程模式主提示**都不在该路径上** ⇒ **`test/fixtures/**` 与 `lib/prompts.mjs` 本批零字节**。两家更进一步指出：今天连改也改不了——`AP_TEST_AUTHORIZED` 的口径锁要求 `.test.mjs`，而夹具是 `.txt`。
- **流程留痕（本批一半价值在此）**：会诊 id 2 **4/4 交付**（codex 在连续两次 `PROCESS_ERROR` 后**首次回话**）→ **设计评审五轮**（FAIL/FAIL/FAIL/FAIL/PASS，四轮的 🔴 **全是同一类**）→ 实施 9 stages → **独立分歧审计** → **交付代码评审**。**★ 本批的元教训是本会话最重的一条**：「**规范/判据自己打自己**」累计命中**六次**——批 8（设计档改写自己纪要的裁定）· 批 10（文档卫生交付物自己引入错数字）· **批 11 五次**（D1 vs 实施域 · 规范块 vs 自身 V2 · V4 锚 vs 冻结文本 · V11② 锚被加粗星号切断 · **交付期 V5 把 `METHODOLOGY.md` 列进六串负向清单而该档全文含 3 处 `/methodology/i`**）。**同一根因贯穿全部六次：靠「看起来对」代替「机械核一遍」。** 对策已落：stage 0 第 ⑥ 项「**锚串存在性自检**」+ **设计交付评审前先跑该自检** + **判据的覆盖面与谓词必须一起自检**（「清单里每个档，是否可能通过该谓词」）。
- **测试**：`node --test` **453/453**（基线 449 + 本批 4 新用例）· **零改面八项**：`test/fixtures/**` ×2 · `lib/prompts.mjs` · `stages`/`stage-gate`/`preset-static`/`test-lifecycle` 四档 · **基线 10 档全未动** · `lib/**` 六串精确谓词命中 **0** · 三处「逐字交付」文本（§6.1/§6.3/§6.3b）经**字符级验证**确认逐字落地 · 台账 **20 档逐档用例数相符、合计 453 == 实测**。

## [0.18.0] — 2026-09-13

**批 10：台账纪律（可落地版）+ D-31 + D-36 + 文档卫生 —— 让计数由机器算、让登记项指得出落点、堵死一条静默清空配置的数据丢失路径、消掉重启后写门禁的纯摩擦**

- **D-31（本批最严重的一条，实测为数据丢失而非排版问题）**：未知**顶层**配置键原先走 `notes` 而非 `errors` ⇒ `ok` 仍为 `true` ⇒ PUT 返回 **200「已保存」** ⇒ 而 `saveUserConfig` 是**整体替换** ⇒ **整层 user 配置被静默清空**。实测证据：旧行为下一次全未知键 PUT 使磁盘从 `{"config":{"advisor":…,"engCoderMaxTokens":65536}}` 变成 `{"config":{}}`。**修法取「报错」不取「回显」**：键移入 `errors` ⇒ **400 且不写盘**（在 `saveUserConfig` **之前**拦下）⇒ **该路径灭绝**。**决定性理由**：**嵌套**未知键今天**本来就是报错**（三处测试在案：`context-budget`/`config-api`/`path-kind`）⇒ 顶层是全函数**唯一的例外分支**，本修复**不是引入新严格性，而是恢复函数自身的一致性**。回显方案被否决——它只把「静默丢」变「响亮丢」，字段照样不落盘。**整体替换语义不改**（full-state PUT 下「删除键」正是靠**缺席**表达；改 merge 会让设置页**无法清空**任何字段）。另加一条**客户端 ⊆ 服务端白名单**一致性锁（两侧都从源码字面解析、不手写清单）消除「设置页造出服务端不认的键」的死锁顾虑。
- **D-36（重启后写门禁的纯摩擦）**：`designToken` 是会话内存态，重启后写门禁拒绝主代理对已批准设计的**小修**。**修法 = 门禁在内存态为空时显式读盘**，判据与内存路径**完全同构**（同一个 `validateDesignToken`），过期/无记录/他会话一律**拒**，放行时**落一行日志**并回填。**失败方向全朝拒绝**：读盘失败**不**落入门禁自身故障的 fail-open catch（**层级区分**：读盘失败 ≠ 门禁故障）。**`docHash` 不进判据**——内存路径今天也不查，盘路径查会造成**两路径判据不一**（那才是真的不一致）；「文档被改后令牌是否失效」是**另一个命题**，若做须两路径同做，**另立批次**。**★ 这是对既有裁定 D1 的明示翻案**：D1 当年护的是「盘 token 经一次调用**静默**驻留 state、**间接**打开主门禁」；门禁显式读盘**终态相同、路径不同**，且**留痕** ⇒ 可审计性高于现状。能力层面「回填路径**早已存在**」（主代理本可读盘、带原值调 `eng_coder` 触发回填）⇒ **内存态从来不是能力边界，只是摩擦**。设计档设 **§10「推翻 D1」专节**，`eng.mjs` 的旧注释**同步改写**（注明翻案理由并指向该节）——**否则下一轮分歧审计会把本修复当回归抓出来**。
- **台账纪律（可落地版；「老化」与「机检三件套」明确不做）**：新增 **`test/ledger-parity.test.mjs`**（6 用例）机检「**文档自报的计数 == 机械数出的行数**」——**期望值住在文档里、实算值从文档字节读，测试源零计数数字字面量**（否则就是又一个手写期望值）。覆盖缺陷登记表与吸收清单 §2；**交接页刻意排除**（它是 `release-check` G7 的**人眼闸**，评审 #3 的正式收窄，不翻案）。**空面按红**（实算 0 / 自报句解析不到 ⇒ 红，不许 `0 == 0` 沉默通过）。**落点只放测试档、不进 `lib/**`、不加发布闸**——因为 **G2 的档清单是 `readdirSync` 派生的**，新档**自动进发布门**，而再复刻一条闸就是「同一谓词两处拷贝」（违判据单一权威）。**首跑即红**：登记表自称 33 条而实测 **36 行**、吸收清单自称 43 档而实测 **42 行**。另给缺陷登记表加**指针**（只机检「文件存在」——**行号不机检**：行号是位置提示不是身份，锁它会制造必然噪声，**D-37 的教训**）与**触发**（闭合四值 + 状态↔触发交叉不变式）两列，36 行逐行填充；**吸收清单不加指针列**（其指针指向**上游**批次档、**本地不可验** ⇒ 不可验的指针列比没有更糟）。
- **吸收清单三处矛盾订正（以 §6 为排期权威）**：依据是 `:6`「批次排序、优先级、以及哪些明确不做都以本档为准」与 `:160`「排序变更以本档为准…并在 §6 记一行变更理由」。§2 的 POOL-LEDGER 行自「批 11」改挂「批 10」并收窄为可落地版；§6 的批 10 行按实际四件重写；**§6 补批 11 行**（D1–D7 文档纪律，含对 §2 建议批次列的**全量对账**）与**变更理由行**（补 §7 要求的手续）；**§5 新增「老化」不吸收条，§5:126 一字不改**（**改的是写错的那一处，不是立场**）；「核销清单」一词废除（全仓唯一出处即该格、从未定义）。
- **文档卫生**：**十二处**滞后状态行订正（9 个文件的第 7 行 + 1 处括注形态 + 1 处地图内嵌 + 1 处 `PROPOSED`），另补一处**逃过字面 grep** 的（`codex-runner-research.md` 写「设计定稿待评审，未实现」而 runner 早已实施）并把它登记进文档地图。
- **流程留痕（本批一半价值在此）**：会诊 id 1 **3/4 交付**（codex **第二次** `PROCESS_ERROR`，如实登记不补位）→ 设计评审轮次 1 **`PASS`**（🔴0 · 🟡6 · 🔵3；评审员的第一句评语是「**好几条意见恰恰落在本批要消灭的那类缺陷里（自报计数与枚举漂移）**」）→ 实施 8 stages（23 次变异）→ **独立分歧审计 🔴0 · 🟡3 · 🔵7**（审计员在**临时副本**上**独立复现**了全部 M 锚的红，确认 **27 条 AC 与 15 个锚零恒真锁**）→ 两轮修复轮 → 交付代码评审**轮次 1 `PASS`**（🔴0 · 🟡0 · 🔵5；首次 900s 超时，上调至 2400s 后通过）→ 收尾修复轮。
- **本批沉淀的纪律**：① **自报计数漂移在本会话累计 11 次命中，其中 6 次发生在批 10 自己身上**——而这一批的立论正是「自报计数会漂、要机检它」。它的机械闸**只罩两个面**（缺陷登记表与吸收清单 §2），**其余十个面仍是人工**；这条**「哪些面已机检、哪些仍是人工」已明确写进交接页**，防下个会话误以为全覆盖。② **锁面含注释的元锁有真实维护代价**：`WRITE_GATE_FIXTURE` 逐字节锁住 `makeWriteGate` 函数体**含注释** ⇒ 任何注释改动都要重新基线（本批**三次**：代码→注释→代码，**每次都自白**；第一次未自白正是审计 #3 的病灶）。③ **实现者的 self-report 也要回盘核**：收尾轮自报「legacy 令牌在两条路径措辞可能不一致」，父侧逐行走代码后判**不成立**（`gateExp` 对内存态取 `tokenExpiryMs(该令牌)`，legacy 的第二段是**可解析的过去时间戳**）⇒ 两路径对 legacy **一致**。
- **测试**：`node --test` **449/449**（基线 434 + 本批 15）· 基线 10 档中**只有** `test/config-api.test.mjs` 被改（走 `AP_TEST_AUTHORIZED` 授权 + 反证实验：摘除 ⇒ T-AP9 红 ⇒ 还原）· **零改面**：`release-check.mjs` / `lib/client.js` / `lib/config-store.mjs` / `package.json` 全零 diff · `lib/**` 内 `check-doc-width`/`check-ledger` 命中 = 0 · 台账 19 档逐档用例数与实测**逐档相符**（449 == 449）。

## [0.17.0] — 2026-09-13

**批 9：测试生命周期三层 + 发布门 + verify 宿主侧门禁 —— 给「只进不出」的套件立规矩，给 git tag 发布装一道会真的被跑的体检**

- **痛点不是「测试太多」，而是「锁坏了没人知道」+「数字漂了没人知道」**。实测证据：D-37 两次返工（锚的谓词写错）；批 7 审计抓到 `AC-P13` 静态锁**自称覆盖六子点、实测只证 4 个且一条断言是 tautological**（审计员定性原话「代码全部合规，是锁缺陷」）；**342 vs 340**——同一事实在交接页与 CHANGELOG 里两个值。而套件从项目开始**一条都没删过**（`git log --diff-filter=D -- test/` 为空），用例数单调增长 274→434。
- **① 测试生命周期台账**（`docs/test-lifecycle.md`）：三层**按处置政策定义**（非按测试风格）——① 批次脚手架锁（锁易变施工事实）② 插件行为契约（锁对外可感行为）③ 实况事故收编（由真实死亡/复现事件补入，`death-provenance` 整档即此形态）。附**退役判据 R1–R4**（死契约 / 衰变锁·tautological / 被取代的重复 / 环境代理断言，全部须举证；明确排除「大小 / 年龄 / 久未失败」）+ **R0 排除项**：**元锁档（`death-provenance` / `guard-e`）在其锁存活期间不可退役**——删它们等于**删除锁本身**，套件照样全绿而锁已消失，这是唯一能「安静地」拆掉整个锁体系的路径。**本批退役 0 档、不设配额**（预设配额正是假退役的制造机；上游「9 退 4 并」是他们的扫描结果不是目标），**taxonomy 住台账不住文件系统**（⇒ 零触碰 T-E19 / T-AP9）。
- **② 发布门**（`release-check.mjs`，仓根单文件、零依赖、零 DSH 态）：七闸——G0 语法 · G1 工作树卫生 + tag 不存在 · G2 全量套件（`--test-reporter=tap`，**TAP 是稳定机器格式**；零重试）· **G3 计数一致**（运行数 == CHANGELOG 顶部计数，**这正是 342/340 那族当时就能被抓住的地方**）· G4 版本三处一致（package.json == CHANGELOG 顶 == 拟用 tag，`vX.Y.Z` 去前缀比较）· G6 flake 预案（失败项**全部**命中已知 flake 表 ⇒ 允许复跑一次；两跑结果**由人**登记，**脚本不写任何文档**）· G7 人工核验项（明说是人眼闸、不进退出码；G5 号段保留）。**形态裁定**：否决纯 `gate-as-test`——**计数相等性自指**（`node --test` 的用例数包含门自己这个测试档，而 CHANGELOG 的 `N` 要等全绿之后才写，**单次运行内不可能成立**）；但采其一半：**不依赖计数的门断言做成常驻套件内用例**（写进脚本的东西可能永远没人跑）。
- **③ 阶段门**（`lib/eng.mjs` 的 `stageGateNote`）：任务书**早已强制**「报告必须以阶段状态表开头」，但宿主**从不读它**（只判 `stopReason`）⇒ 「completed 但自报 failed」照样簿记。本批补一个**纯解析**的门：表缺失 / 任一 `failed` / `skipped` 无理由 ⇒ 在交付文本**前部**加响亮横幅，**4 个成功返回点**全接（与簿记点**结构配对**），失败/abort 路径不接。**后果取「响亮横幅 · 不阻断」而非阻断簿记**：与上游先例一致（`completion.mjs:70-74`/`:118-122` 明言工程模式**刻意**用 flow-driven review 而**非** per-turn mechanical pushback），且 `mutatedThisRun`/`touched` 描述的是**磁盘上真实发生了什么**——跳过簿记会让评审链看不见真实变更，**制造更糟的静默**。
- **明确不收**：宿主复跑 stage 的 `check` 命令。六条实测代价——① `check` 是**自由文本**（要可执行就得约束形态 ⇒ 撞 T9 字节 fixture；不约束则**把模型输出当 shell 跑**的注入面）② 阶段纪律本就要求子代理先跑过 check（必然重复）③ dsh 同步路径本就在 budgetCap 墙钟内赛跑（会**把好交付变成超时 abort**）④ 边际收益≈0（复跑多抓的只有「撒谎的子代理」，而交付评审本就强制跑测试）⑤ R-13 这类 flake 会让本就冤杀 ⑥ **逆上游架构裁定**。**登记为观察位**（出现「申报与实测不符」的实测案例即重新评估）。
- **流程留痕（本批一半价值在此）**：会诊 id 1 **3/4 交付**（codex `PROCESS_ERROR` 如实登记不补位）→ 设计评审**轮次 1 `FAIL`**（🔴2：① 台账覆盖面自相矛盾——三处写死 14 而本批新增 3 档 ⇒ 交付时 17，照文实施必红；② **我静默改写了自己纪要里的裁定**——纪要把版本一致性列入常驻断言、设计档写不做且无留痕，评审员还**反驳了我的时序理由**并判其成立）→ 修 12 条 → **轮次 2 `PASS`** → 实施（8 stages，23 次变异）→ **独立分歧审计 🔴1 🔵5**（🔴 = **一条永不失败的断言**：R0 门锁用**裸档名**比 `AP_TEST_AUTHORIZED` 的**仓库相对路径** ⇒ 恒真；而**同档注释自己就写着「按裸档名比对必然全 miss」**——**一个专门用来消灭假锁的档案里出现了假锁**）→ 修复轮 → **交付代码评审轮次 1 `FAIL`**（🔴 = **G6 复跑预案结构性死代码**：复跑**只在第一跑红时触发**，而 G2/G3 已按第一跑固化、复跑成功**只打印不回写** ⇒ 「放行」永远不可达，**US-12 的核心承诺是实现不了的**）→ 修复轮 → **轮次 2 `PASS`**（🔴0）→ 收尾修复轮（四条 🔵）。
- **本批沉淀三条纪律**：① **设计档交付前，把本批纪要的裁定清单逐条 grep 进正文做交叉自检**——不靠记忆（本批 🔴#2 与批 7/8 共 6 次同族命中，且这次是**我写下该纪律之后立刻又违反**）；② **新写的锁必须立刻做变异自证，而且变异值要取自「实现/配置的真实形态」，不是取自断言自己的写法**（🔴#1 正是实现者构造变异时下意识用了与断言一致的口径而漏掉）；③ **台账 §三的用例数与 fs 实测是等值锁 ⇒ 任何新增用例都必须同时改台账**（实现者实测撞到并正确地没越界，改把断言并入既有用例）。
- **登记面**：R-13 `session-state` T6 时序 flake（**本批不修**，基线档 + 不在写域；发布门 G6 预案先写死）· R-14 宿主复跑的观察位 · R-15 codex 会诊失败 · R-16 会诊把上游路径写错（**内容为真、路径记错**）· R-17 交接页曾有重复批 9 行 · R-18 台账判据的**语义**正确性只能靠评审人眼，机械只保形式（诚实边界，不超卖）。
- **测试**：`node --test` **434/434**（基线 413 + 本批 21）· 基线 10 档零 diff（T-AP9 绿）· T9 fixture 字节不变 · `lib/**` 子进程调用点仍为 1（零新执行面）· 零新依赖 · 台账 17 档双射（首扫 14 + 本批 3）· 新增测试档三份均按 T-E19 登记制登记（含理由与用户裁定引用）。

### 补记 · 移植远端分叉 `7b6a845`（v0.9.3）的增量

**移植远端分叉 `7b6a845`（v0.9.3）的唯一真增量：把会诊看门狗预算的解析提到单一事实源**

- **背景（避免重造）**：`7b6a845` 与本仓批 1 的 D-29（`9ae1277`）是**同一件修复的两次独立实现**——都让 `consultTimeoutMs` 在 user 层可配。本仓 D-29 已把两键补进三面白名单（PUT 校验 ⊕ merge 白名单 ⊕ 运行时读取）并含设置页接线与全链路测试，**功能是完整的**。故本批**只取它独有的那个精炼点**：把看门狗预算的解析从 `lib/consult.mjs` 的就地三元式提到 `lib/config-store.mjs` 的**单一事实源**（`resolveConsultTimeoutMs`，带非法值告警与跨升级保留语义），而不是散在消费点。
- **值域裁定（重要）**：**下限取 `30_000`，不取远端的 `60_000`**。理由：批 1（D-29）已发布并测试了 `CONSULT_TIMEOUT_MIN_MS = 30_000`，把下限抬到 60000 会让**已存在的合法用户配置**（30000..59999）静默变成非法而回落缺省——那是行为回归。远端那个 60000 是它独立选的，没有任何依据要求我们跟随。⇒ `CONSULT_TIMEOUT_MIN_MS` / `CONSULT_TIMEOUT_MAX_MS` **继续复用批 1 已发布的两常量（未重复声明）**，新增的只有 `CONSULT_TIMEOUT_DEFAULT_MS = 600_000`。
- **不是照搬，是移植结构**：远端的 `config-store.mjs` / `consult.mjs` 是本仓 **0.9.3 时代的旧版本**，照搬会**回退其后 17 个提交的改动**。本批只取「resolver 这个函数 + consult 改调它」两处**结构**，内容按当前 HEAD 写；`consult.mjs` 的 D-28 `abort-provenance` 导入**保留**（两条 import 并存，静态断言锁住不得互相覆盖）。
- **落点**：`lib/config-store.mjs`（`CONSULT_TIMEOUT_DEFAULT_MS` + `resolveConsultTimeoutMs`，置于 `resolveDshBackgroundTimeoutMs` 旁保持命名习惯）· `lib/consult.mjs`（删本地 `const CONSULT_TIMEOUT_MS = 600_000` 与就地三元式，改 `resolveConsultTimeoutMs(config)`）· `test/codex-runner.test.mjs`（验收断言）。
- **测试**：`node --test` **434/434**（基线 434 + 本批 0 用例——四条验收断言**并入** `test/codex-runner.test.mjs` 的三条既有用例，顶层 `test(` 计数不变 177，形态理由见下）· **变异矩阵 10/10 逐条自证会红**（resolver 恒回落 / 非法值不告警 / `DEFAULT` 改值 / `MIN` 改 60000 / `MAX` 改值 / 消费点回落就地三元式 / 恢复就地常量字面 / 删 config-store 导入 / 删 abort-provenance 导入 / 删授权登记 ⇒ 各命中目标用例红，还原后绿、还原逐字节核验）· 零新依赖 · 基线 10 档零改动（**唯一例外 = `test/codex-runner.test.mjs`——即本批的授权档本身，已在 T-AP9 的 `AP_TEST_AUTHORIZED` 逐档登记**）。
- **形态说明（诚实登记 · 两条）**：
  1. **断言并入既有用例而非新建顶层 `test(`**——因为 `test/test-lifecycle.test.mjs` 的 **T-LC2** 是「台账 §三 用例数 ↔ fs 实测 `test(` 计数」的**等值锁**，新增顶层用例会立刻让它红，而 `docs/test-lifecycle.md` **不在本批写域**。这与批 9 交付代码评审修复轮的先例同一形态（父侧当时裁定接受）。若父侧希望四条断言各占一条独立顶层用例（全量 **438/438**），需**同一交付内**把台账 §三 `codex-runner.test.mjs` 行由 **177 改为 181**——该授权不在本批写域。
  2. **写域外的一行（需父侧裁可）**：`test/death-provenance.test.mjs` 的 `AP_TEST_AUTHORIZED` 由 `["test/design-review-guard.test.mjs"]` 扩为含 `"test/codex-runner.test.mjs"`（+ 注释说明来历）。**动因（实测证据）**：任务书声明 `test/codex-runner.test.mjs` 是授权档，但 **T-AP9 锚 B** 的真值是「基线 `2e6ca8b` 时点**已存在**的测试档零修改，除 `AP_TEST_AUTHORIZED` 例外」——而实测 `git diff --stat 2e6ca8b HEAD -- test/codex-runner.test.mjs` **为空**（该档自基线起零改动、确属基线档），故任何断言并入都会让锚 B 必红（本批实测：全量 **433/434**，唯一失败即 T-AP9）。该清单是仓内文档确立的**唯一合法通道**（`docs/test-lifecycle.md` §一；`docs/2026-09-13-test-lifecycle-consult-minutes.md:26`「授权通道存在……基线**后**档 ⇒ 可改」），且 `death-provenance.test.mjs` 本身由批 6 `a5f9551` **建于基线之后**（`git ls-tree 2e6ca8b -- test` 不含它）⇒ 扩清单**不触发**锚 B。**未削弱锚的语义**：仍是「逐档显式例外」，任何**其他**基线档改动照旧红；变异自证 **M10**（删去该登记）⇒ T-AP9 红、失败文本点名该档、还原逐字节一致。
- **版本号**：本小节是 `[0.17.0]` 的**同版本补记**，**2026-09-17 已并入本版本小节**（它当年单独成节、且置于 CHANGELOG 顶部，是为了——机器契约 `G-常驻2` 要求「CHANGELOG 顶部版本头 == `package.json#version`」，改写成「未发布」会让常驻断言立刻红）；最终版本号由父侧在收口时定。

## [0.16.0] — 2026-09-13

**批 8：提示词公共层（裁减版）—— 判定契约从「碰运气不漂移」变成「由 spec + 双向锁钉死」**

- **形态 = 零改面**。四个 advisor 提示词（`advisor-round1/2/3.md` + `advisor-design.md`）与 `lib/prompts.mjs` **零字节改动**——本批**不搬运任何提示词字节**。交付物 = 一份契约 spec + 一条双向锁测试。
- **为什么不用真抽取**：可逐字节抽取的只有 **4 行**（标题 / 引导句 / `Tolerated:` / `malformed-refused`），去重收益 = **12 行**；而代价是 ① 新增**启动期**失败面（`prompts.mjs` 顶层急读，片段缺失 ⇒ 整个插件加载失败）② **必须改写 `AC-V13`/`AC-V13b`**——本仓**最安全相关**的两个测试（它们**直接读裸档字节**，抽取后裸档不再含那 4 行，必红）③ 破坏「零构建」这一既存性质。**为 12 行去动最硬的锁，风险收益倒挂。**
- **交付物**：
  - `lib/prompts/verdict-contract.md`（**新增**）：判定族的公共层权威——① 契约字面（四档逐字共享的 4 行）② 差异表（**ID 化 `<!-- DIFF:… -->` 哨兵**，使「恰 4 类带意差异」可机器判定）③ **四档 Verdict 块逐字快照**（程序抽取写入）④ **出现点地图**（四档 + `advisor-msgs.mjs` 的 2+2 处 + `AC-V13`/`AC-V13b` 锁位置 + `VERDICT_LINE_RE`）⑤ 已存在的漂移登记。**该档不进装载路径**（`loadPrompt` 按显式文件名装载，库内无 `prompts` 目录扫描）。
  - `test/prompt-contract.test.mjs`（**新增**，14 用例）：**两组件闸** + 哨兵集合 + 四条不变式 + DIFF 哨兵 + 地图内容 + EOL 契约 + 装载路径零接入。
- **闸的两组件（这是本批的要害）**：**组件①** = spec ↔ 四档**逐字一致**；**组件②** = **四档 Verdict 块的 sha256 内容指纹**（硬编码常量）。① 是**共拥有**的锁——「提示词 + spec 快照」**协同改**能全绿；② 把块的归一后内容钉成常量，**协同改即红**。**设计评审轮次 1 的 🔴 正是指出纪要写了两个组件而我设计档只落了一个**；修复后**审计员独立复现 M3**：协同改 ⇒ 组件① 绿、组件② 红。
- **反向锁**：三版 PASS 判据句 / 两版 FAIL 判据句 / `Never translate` 的 3:1 措辞差 / `design` 的独有两条 —— **一律原地保留、只登记不合并**。统一任一措辞 = **替换** ⇒ 违反「判定族字面只追加、绝不替换」。另加**负向锁**：三版 PASS 判据句**必须互不相同**（防后人「顺手统一」）。
- **流程留痕**：会诊 id 3（**4/4 交付**）→ 父侧实测（可抽取集 = 4 行 · 四档块 11/10/10/17 行 · 本机 603/603 CRLF）→ 用户裁定形态 = **零改面**（否决组装层）→ 设计评审**轮次 1 `FAIL`**（🔴1 🟡7 🔵5；🔴 = 「裁定写进纪要 ≠ 设计档兑现」**第五次命中**）→ 修 13 条 → **轮次 2 `PASS`**（残留 7 条含**尾换行不对称会让 AC 恒红**的真缺陷，父侧全部修掉）→ 实施（后台一次通过，18 次变异自证）→ **独立分歧审计 `🔴0 🟡2 🔵2`** → 修复轮（**F2 = 父侧设计前提错误**：`AC-9b` 钉的是**本机 checkout 配置**而非仓库属性——本仓**无 `.gitattributes`**、**提交进库的 blob 是 LF**，CRLF 只是本机 `core.autocrlf=true` 的投影 ⇒ 在默认配置的克隆上**一个字节未改的仓库就会红**；改为**环境无关**的「同档不混用 + 跨档一致」，并以**模拟全 LF 克隆 14/14 绿**验证）。
- **本批沉淀两条纪律**：① **交付文档面必须回读本批纪要的裁定清单做交叉自检**（本批 🔴 与批 7 的 4 条 🔴 同族，已升级为可执行动作）；② **在 `core.autocrlf=true` 的机器上，「零改动」不能只靠 `git diff` 证明**——git 会在 diff 前归一 EOL，一次「只改行尾」的编辑会被吞掉；必须**另用字节级读取佐证**（审计员提出并示范）。
- **登记面**：R-10 `Never translate` 的 3:1 措辞差（已登记不修）· R-11 判定族的出现点分布（「契约单点 + 文本多处」）· R-12 吸收清单记载的重复症状已陈旧 · **R-13** `test/session-state.test.mjs` T6 的**既有时序 flake**（单独复跑 10/10 绿、其后全量连续 7 次绿；不在本批写域、无因果）。
- **测试**：`node --test` **413/413**（基线 399 + 本批 14）· 既有测试档零修改（唯一授权改动 = `test/guard-e.test.mjs` 的 T-E19 清单登记一行，用户 2026-09-13 裁定）· **四档提示词与 `lib/prompts.mjs` 一个字节未动**（经字节级核验）。

## [0.15.0] — 2026-09-13

**批 7：可移植性三件（METHODOLOGY 退役 + 产品提示词去本仓指涉 + 判据单一权威）**

- **总目标**：让本插件的**产品提示词不再绑定任何具体仓库**——评审的判据来源由**项目自己声明**（缺省时**显式降级**而非静默），提示词里不再出现本仓/上游的文件名与路径，且「这个路径是文档还是代码」这件事**只有一个权威实现**。
- **① 退役（19 处，逐处改写，零整段删除）**：`injectMethology` 整函数删除（含其拼写错误的名字）；`injectDocumentMap` **保留函数名、整段重写**（它此前读死路径 `docs/design/README.md`，**本仓不存在 ⇒ 今日恒不生效**）；`advisor-design.md` 4 处 + `engineering.md` 9 处 + `advisor-msgs.mjs` 2 处判据/硬要求句全部改写。手法纪律 = **退役是改写不是删词**——不许留下空括号、双逗号、悬空限定语残句。**可验收形态**：`grep -ri methodology lib/` = **0**（含注释与提示词）。
- **② 声明键 + 三态显式注入（`standardsDoc` / `documentMapDoc`）**：两键均为**项目属性**（**global-only**，不做会话覆盖——与批 5 `contextTokens` 同族，实测最小面集一致，**免掉 7 个面**的改动）。三态**各有可区分输出**：声明且可读 ⇒ `## Project Standards` / `## Document Map` + 全文（**新增 16384 预算 + 截断标记**，此前无预算）；声明但**读不到** ⇒ 响亮句并**点名配置键**；**未声明** ⇒ **显式降级句** + 明说「不得自行去磁盘找」。**注入门 = 声明键存在**，删掉旧的 `engineering === true` 门（留门会造出「已声明却被模式静默压制」的新静默洞）。**空串 / null = 撤销该键**（回到「未声明」这一**正常态**），设置页**清空文本框即发送空串**（不是「空字段不发送」，那会把用户锁死在已声明态）。
- **③ 判据单一权威（F17 之外的又一处「两份副本」）**：新建零依赖叶模块 **`lib/path-kind.mjs`** —— `isDocPath`（`docs/` 前缀 ∪ 文档扩展名，任意深度）为**唯一权威**；`isProductCodePath` = **纯补集派生**（无第二套规则体）；`eng.mjs` 的 `isProductCode` 变**薄转发**（名字与 export 保留 ⇒ 写门禁字节夹具不需更新）；`advisor.mjs` 本地 `isDocFile` **删除**；**`^src\/` 死锚删除**——**这是删死代码而非收紧**：对代码扩展名它冗余（`lib/`、`packages/app/src/` 靠兜底已真阳性），对文档扩展名它是**唯一矛盾源**（`src/README.md` 曾被写门禁拦却可进评审文档表）。上游那条「收紧为 `^src/` 前缀」是**记录在案的陷阱**，本批反向行之。**唯一行为变化**：`src/**/*.md` 从「产品代码」翻为「文档」——本仓无 `src/` ⇒ **零现场影响**。
- **流程留痕（本批一半价值在此）**：会诊 id 2 **4/4 交付**，且**三家独立指出父侧会诊任务书的四条前提错误**（`isProductCode("docs/x.mjs")` 方向反了 · 根级 `README.md` 实为文档 · 「`docs/` 两谓词语义相反」不成立 · 16K 截断归因错）——父侧回盘实测并落档；随后**两轮只读勘察**又纠正父侧两处（配置面是 **7 个面**不是「四面管道」；T-E19 的测试档清单闸 ⇒ 新增测试档会被拦）。设计评审 **轮次 1 = FAIL**（🔴5 🟡5 🔵4，**其中 4 条 🔴 是我违反了自己刚写下的裁定**）→ 修 → **轮次 2 = PASS**（5 条 🔴 经引用级复核全修；残留 7 条为「同一件事有第二个落点」）→ 实施（同步路径被 540s 内部截止 abort 且零输出 ⇒ 改**后台**一次通过）→ **独立分歧审计 🔴1 🟡2 🔵2**（🔴 = AC-P13 的静态锁自称六子点、实测只证 4 个，且一条断言**tautological**——**代码全部合规，是锁缺陷**；🟡 = 三条核心 AC 在服务端面零覆盖 + 卫生锁无套内锁）→ 修复轮（**11 次变异全部「删/插被保护行 ⇒ 目标用例红、不误伤」**）→ **交付代码评审 PASS**（🔵2）→ 收尾修复轮。
- **本批沉淀的四条纪律**（均已进交接页 §6）：① **裁定写进纪要 ≠ 设计档兑现**（设计档交付前必须逐条回读纪要裁定清单做交叉自检）；② **改了引用点，却没改被引用的副本**（每次改一个约定，必须全库检索其所有出现点并一起改——该 `grep` 级纪律原先只当**代码面**纪律用，**文档面同样适用**）；③ **不许用「不可达」当免验理由**（「不可达」本身是需要证明的断言，本轮我那条证明就是错的）；④ **当一条闸的谓词与它的意图不等价时，修的是谓词，不是被闸的东西**（本批两度命中：锚 B6「切片不含 engineering」vs「门不由模式决定」；评审 #2 的同类建议——且第二次出在**评审建议**上，故**评审的话也要回盘核验**）。
- **登记面**：R-5 六维/七维清单预先存在的漂移（系统提示列 7 维、硬要求句列 6 维）· R-6 `.thincoder/advisor.md` 沿用上游产品名 · R-7 `viz/*.html` 过时数字 · R-8 eng_coder 参数描述里的示例路径 · R-9 `cordis.patch.yml` 白名单注释已过时。
- **测试**：`node --test` **399/399**（基线 384 + 本批 15）· 既有测试档零修改（唯一授权改动 = `test/guard-e.test.mjs` 的 T-E19 清单登记一行 + 同处注释，用户 2026-09-13 显式裁定「按登记制扩展」）· 新增 `test/path-kind.test.mjs`。

## [0.14.0] — 2026-09-13

**批 6b：守卫 E（在途窗口冻结 + 预闸拦截 + 结算侧指纹兜底）**

- **总目标**：把「评审窗口内被审文档不得被改动」从**流程纪律**升级为**机制不变式**——窗口开启时**事前拦**（`write`/`edit` 撞冻结集 → 拒绝 + 真逃生门），窗口结算时**事后核**（签发前重算指纹，失配则本次不签发）。守卫 D 让**失败**自证来源；守卫 E 让**成功**自证依据。
- **闭合的问题（F17 型漏洞）**：令牌指纹此前是**派发前快照**、签发时**不复检** ⇒ 评审在飞期间（我方路由下可达数分钟到 1 小时）改动被审文档，评审员读到「前半段旧内容 + 后半段新内容」的混合体，而宿主照常按 `verdictPassed ∧ echoOk` 签发一枚**声称审过**该内容的令牌。**静默**且**每次窗口内编辑必然发生**。我方没有上游那种基于变更日志的 `reviewIsStale`，故用**已有的两口子**（在途槽位 + D-30 指纹）拼出等价物。
- **两半，缺一不成立**：
  - **预闸**（事前）：新增**独立** `tools/pre-execute` 监听器 `makeDocFreezeGate`（`lib/eng.mjs`），命中冻结集 → `{kind:"deny", reason:"frozen: …"}`。**与写门禁刻意不同**的三点：① **fail 朝向相反**（已确认窗口内 fail-closed；写门禁无条件 fail-open）② **depth 不豁免**（写门禁 `depth>0` 放行——子代理是受令牌保护的实现者；预闸拦的是「正在被审的文档」，写入权与写入者身份无关）③ **拒域不相交**（冻结集 = 文档 vs `isProductCode` = 非文档）。拒文案前缀 `"frozen: "` **不与** `"denied: "` 混用（两态出路完全不同）。
  - **结算侧兜底**（事后）：`finalize` 的 `if (echoOk) {` 首条语句重算并集指纹，失配 ⇒ **不签发**。这一半专门覆盖预闸**原理上拦不到**的面（`bash`/`pwsh`/`run_code`/`file_ops`/外部编辑器/别的会话）。
- **槽位载荷扩容**：`inFlightJobs` 值 `{jobId, mechanism}` → `{jobId, mechanism, reviewType, docSet}`；`setInFlightJob` 加**第四位置参** `payload`（缺省 `{}`）⇒ 既有 **6** 个三参调用点（advisor ×2 / eng ×2 / escalate ×2）**零改动**仍合法。新增只读访问器 `designFreezeSet()`——**扫全表**而非按会话键单查（子代理 `session.id` ≠ 父会话 ⇒ 键查必然 miss，而子代理恰是典型漂移向量）。
- **闭包捕获**：`castDocPaths`/`castDocHash` 在铸造块末捕获、`finalize` 只读捕获值。与「读活 `state.pendingDoc*`」在当前代码下**等价**（单飞入口检查早于铸造，窗口内无第二写点），但捕获让正确性**不依赖**该不变式——否则将来有人在窗口内加一个写点，守卫会**静默退化成自比恒真**且无测试会红；捕获还把「不许读活 state」落成**机器验锚**（锚 A1：签发块内 `state.pendingDoc` = 0 次）。
- **漂移的处置语义（四条，缺一会引入新死锁）**：① **不签发**（不写 `state.designToken`、不调 `saveTokenRecord`）② **不撤销**既有令牌（漂移针对 pending 集；与「PASS 但回显缺失不撤销」同族）③ **不计三振**（早返回绕过通用计振尾——护栏计的是**插件自身健康度**，七 kind 无一例外是管线自己的故障；漂移是管线**正常**而外部改了文件，计入会让诊断面指向错误修法）④ **复位轮次**（`advisorRound=0` + 清 prior + 落盘）——否则下一轮取「只验证不找新问题」的**收敛轮**提示词去覆盖**从未被评审**的内容 = 真实的放行面。**不** `bumpAdvisorGeneration`（代际是「弃置在飞结果」的轴，+1 会误伤无关机制的 settle）。
- **真空豁免**：`castDocHash === null`（空文档集 / 铸造即不可读）⇒ 跳过复检、签发照旧（D-30 决策 D6 的既有权衡；漏判会让**空集评审永远签不出**）——AC-E20 专锁。
- **流程留痕（本批一半价值在此）**：会诊 id 1 **四家全部交付**（v4-pro / glm-5.3 / gpt-6-astra / kimi-k3）→ **五处分歧父侧裁定**（① 闭包捕获 vs 读活 state ② 子代理拦不拦 ③ **失配是否计三振** ④ fail 朝向扁平 vs 分层 ⑤ 其余三处）→ 设计评审**轮次 1 `FAIL`**（🔴 = 真空豁免无 AC；**评审员判得对**，纪要 §4 栽点 2 已明令「FR + AC」）→ 修 12 条 → **轮次 2 `PASS`** → 实施 → **独立分歧审计 🔴0 🟡1 🔵5**（审计用 **10 组变异实验**自证：M8 删 `.slice()` / M10 删空集跳过各自 **22/22 存活** ⇒ F1 两条已规定不变式零覆盖）→ 修复轮（+`T-E22`/`T-E23`，**变异自证可失败**：M8→23/1 唯红 T-E22、M10→23/1 唯红 T-E23）→ **交付代码评审 `PASS`**（🔴0 🟡1 🔵4，含 F3 的调用点计数订正与 §12.6 的**设计文本缺陷裁定**）。
- **父侧自身缺陷亦落档**：① 派发任务书把 stage 1 的 check 写成**不存在的** `test/in-flight.test.mjs`（实现者按纪律换等价自检并如实上报，未为迁就任务书造文件）② 设计档 §6.1 伪代码把 `const` 画在块内却又要求块外消费——**按字面不可运行**（判定为**设计文本缺陷**，正文冻结不改、以 §12.6 #1 裁定为准）。两次都属「凭形状推测而不回代码核验」的同一类病，与批 6 §0.2 同族。
- **登记面（本批不做）**：O-E1 跨会话误拒 · O-E2 跨链过度冻结（D-30 并集语义投影）· O-E3 未过期旧令牌 + 漂移在 `eng_coder` spawn 时不复检（F17 类洞、**窗口外**，属 D-30 扩展）· O-E4 `file_ops` 条件纳入 · O-E5 路径 cwd 偏斜（miss 方向） · O-E6 不可读原因不细分 · O-E7 若出现「每窗必漂」则另立**独立漂移计数器**（与三振正交），不塞进三振。
- **测试**：`node --test` **384/384**（既有 **360 原样全绿**，既有测试档零修改；新增 `test/guard-e.test.mjs` 24 用例覆盖 AC-E1…AC-E21 + 机验锚 A1…A10）。

## [0.13.0] — 2026-09-13

**批 6：死亡可诊断（守卫 D 判定换血 + 四家族 abort 溯源 + 裸 abort 灭绝）**

- **总目标**：让**每一种死亡自证来源**——「哪一层按下的（provider / agent / settle）+ 因为什么（user / timeout / cancel / stop / unknown）」在一次工具返回里可判。动机有**生产事故实证**：`consult.mjs` 头注自认「2026-09-08 生产：**20 次失败全被读成「aborted 无死因」**」（D-28 当时试了 21 次才诊断出来）。
- **新模块 `lib/abort-provenance.mjs`（唯一词汇表）**：`TRIGGERS`(5) / `LAYERS`(4) / `triggerOf` / `abortError` / `timeoutError` / `annotateAbort` / `deathLine`（截断顺序 = 先截 detail → 再拼 cause/tag → 最后整体兜底 ≤300）/ `abortTag`（`detail` 机器短标签）/ `hostAbortInfo` + `hostAbortSource`（宿主面机械判据：控制器已中止 ∧ reason **未带**我方标注 ⇒ `{cancel, settle}`）。
- **FR-AP2 墙判定换血**：`runAdvisorToolLoop` 的 `/deadline reached/` **文本嗅探整行删除**，改由 `deadlineFired` latch 与 `abortInfo.trigger` 判定——适配器以**无声样 AbortError** 抛出时不再被误判为「用户中断」并丢掉超时统计尾。
- **FR-AP3/AP4**：`shouldBudgetNudge` 纯函数 + 循环顶**每场至多一次**的 75% 预算提示（走 `messages` 注入，**不进**返回正文/prior）；超时尾**纯追加**——既有那句一字符未动，其后追加 `tool calls / review text produced / budget` 三要素与两条出路。
- **FR-AP5/AP6 四家族接线 + 裸写点灭绝**：advisor 五站（循环 catch · 环内 `kind==="error"` 站 · 两条 job catch · 外层 catch）· eng 三站 · escalate 三站 · consult 五站；**`grep '\.abort()' lib/` = 0 命中**（基线 5 处裸写点全部补上 reason 载荷），**零新增写点、零定时器时长/条件变更**（`.abort(` 计数与 HEAD 逐文件相等）。
- **流程留痕**：设计评审**轮次 1 = FAIL**（🔴 = 我自己的设计档自相矛盾：超时尾「追加」与「替换 + 逐处改断言」三处打架，而零改面纪律禁止改断言——**评审员判得对**）→ 修正为纯追加 → 轮次 2 PASS → 实施 → **独立分歧审计 1🔴/4🟡/3🔵**：🔴 = consult 的 stop/cancel 两构造的判据打在**手搓等价物**上、且生产死亡行**没有消费者**（`settleChild` 丢弃 payload）→ 修复轮**给它接了真实消费面**（死亡行进该行模型的可见文本），并给出「删生产站点即红」实测；其余含宿主面层映射（job_kill 误报 `unknown@agent` → 修成 `cancel@settle`）、环内 error 站补接线、矩阵补六站、模块实测表计数订正、定时器门禁改逐字比对、两个不可持久的锚（**D-37**/T-G9 与 T-AP9）改成历史事实锚。
- **测试**：`node --test` **360/360**（既有 320 中 319 条原样未动 + T-G9 按 D-37 授权修为历史锚；零其余既有测试修改）。

## [0.12.0] — 2026-09-13

**批 4：设计评审豁免 5 轮上限 + 三振结算护栏（成对吸收）+ D-35 评审链作用域折入**

- **总目标**：把设计评审的**拒绝轴**从「轮次上限」换成「结算健康度」，且两者**成对**生效——cap 只对代码评审生效；设计评审由三振护栏兜底。两半拆开任一件都比现状更糟（只豁免 = 撤掉唯一的界、无限烧钱；只护栏 = 第 6 次仍被 cap 误杀，吸收等于没做）。
- **FR-G1 豁免**：cap 检查条件加 `reviewType !== "design"`（`MAX_ADVISOR_ROUNDS` 与 **cap 消息体逐字节不变**）；轮次照增、提示词轮换与显示照常——豁免的只是「第 6 次拒绝」这一轴。
- **FR-G2 三振护栏**：同一文档集连续 3 次跑不出可用结算 ⇒ 后续发起被拒（**零 LLM、零状态变更**；工具层 + 核心层**双入口**）；键 = **纯路径形状**（`normalizeDocPath` 归一 + 去重 + 排序；空集哨兵 `"empty"`；**绝不用内容哈希**——那会被一次空白编辑洗白）；计数 = **会话级内存**（照抄 `codexFailureCount` 先例，不落盘）；清理只挂 `session/disposed`，**不挂** `resetRouteFailureState`。
- **FR-G5/FR-G6 计数与复位**：宿主截断族 + 陈旧结算 + 凭证落盘失败 + 无报告结算计振；`interrupted` **不计**；派发返回 **不计**；**dsh 后台兜底 abort 按 `timeout` 计**（机械事实，不做串面猜）；**codex `ABORTED` → `interrupted`（0 振）**、`TIMEOUT` → `timeout`（+1）；可用判决（pass ∧ 回显 ∧ 落盘成功）与显式 `VERDICT: FAIL` **复位**（FAIL 同时撤销 token 是**另一条正交轴**，注释钉死）。
- **FR-G9（D-35 折入）**：设计评审链**按文档集作用域**——换文档集即等价类型切换（round/prior/代际重置），与 F11 合并为**单一重置谓词**、重置动作各执行一次；`session-state.json` 新增可选字段 `lastDesignDocKey`（**本批唯一 schema 变更**）。该字段存 `sha256Hex(designDocKey)` **摘要**而非路径原文——`session-state` 的既有 AC-20 契约禁止落盘被绑文档路径，父侧裁定接受（等值判定语义等价）。
- **流程留痕（本批一半价值在此）**：设计评审 **PASS**（12 条发现同链处置）→ 实施 → **独立分歧审计 2🟡/1🔵**：① 工具层预检**不是「摘除即红」**（核心层单独就满足全部四条断言——审计员用「连 `deps.llm` 都没有」的探针实证）② **codex 路由上的用户中断被计振**（`ABORTED` 信封未映射 ⇒ 归 `review_failed`，与 US-4/README 矛盾）③ `stale` 对**失败**的 job 也记账 → 修复轮三条全修，并各做「**还原即红**」实验（A 摘工具层→T-G3b 红；B 摘 ABORTED 映射→T-G5g 红；C/C3 还原 stale 打点→T-G5f 两臂各自红），实验后逐字还原。
- **D-35（评审链会话级 → 文档集级）**：本批开工时**现场复现**——同一会话里第二份设计文档拿到的是**收敛轮**提示词（「只验证、不找新问题」）、prior 还是**另一份文档**的发现，并据此**铸造了一枚声称覆盖未评审文档的令牌**。该次评审被判**无效、令牌不予采用**；缺陷登记为 D-35（🔴）并折入本批（同一把键）。
- **测试**：`node --test` **340/340**（既有 320 **原样全绿**，零既有用例修改）。

## [0.11.0] — 2026-09-13

**批 5：评审上下文预算跟随模型窗口 + 评审估算器 CJK 加权（120K 硬编码退场）**

- **总目标**：让评审循环的上限来自**它真正要调的那个模型**，并让估算值不再对中文内容系统性撒谎——两件同批落地（拆开任一件都比现状更糟：只上窗口派生会 CJK 真实死点推到越过真窗、只上估算器会让 CJK 死点 4× 前移）。
- **FR-CB1 窗口三级链**：`advisor.contextTokens`（手配）> `ctx.llm.resolveModelInfo(provider, model).context.contextWindow`（运行时权威——**本插件早已为 effort 在调同一方法**）> 保守兜底 `131072`。逐级 fail-open；兜底/元数据失败时 `console.warn` + post-finalize 追加一行（值 / 来源 / 两档 / 出口），**绝不进判死文案**。
- **FR-CB2 比例式两档**：`limit = floor(窗口 × 0.8)`、`compactAt = floor(limit × 0.8)`（两次 floor 钉死）。本机默认评审路由（`deepseek-flash`，适配器声明 **1M**）判死线 120000 → **800000**；128K 级 / 未知路由 120000 → **104857**（收紧 12.6%，给「对该路由一无所知」一个诚实的头寸）。`MAX_CONTEXT_TOKENS` **退役、不留别名**。
- **FR-CB4 估算器 CJK 加权**：逐消息 `ceil(ascii码元数/4) + 非ASCII码元数`——纯 ASCII **逐值等于旧式**（可机验零回归），`"中"×400` 从 100 修正为 **400**。签名与导出面不变（仍为模块私有）。
- **FR-CB5 三面同步**：`advisor.contextTokens` 进 PUT 白名单（整数 16384..4194304，校验单一事实源在 `lib/advisor.mjs`）⊕ `mergeGlobalConfig` 白名单透传 ⊕ 设置页卡片（占位不写具体数值 / 回显仅配置层 / 含残余格子提示 / 内联校验 / 清空即删键 / **不新增服务端 GET 载荷**）。
- **流程留痕（本批的价值一半在这里）**：设计评审 **PASS**（7 条发现同链处置）→ 实施 → **独立分歧审计抓到 1 条 🔴 假锁**——T-CB4 的 CJK 判据全部打在测试档**本地副本**上，把生产权重改成任意 `w ∈ (0.552, 1.504]` 仍 **319/319 全绿** → 修复轮新增 **T-CB10 走生产路径**（`"中"×300000` ⇒ 逐字 `300007` 判死；把权重改 0.75 即转红，红→绿两次实测留档）→ 交付代码评审 **PASS**（2 🔵：模块头注释枚举滞后、逐调用配对锁退化——均已修）。
- **测试**：`node --test` **320/320**（既有 304 **原样全绿**，零既有用例修改）。
- **同批的流程性修正**：批 3 交付时 `package.json` **未 bump 版本**（`docs/README.md` 该行却写了 `v0.11.0`）——本批统一为 **0.11.0** 并修正那条声明。

## [0.10.0] — 2026-09-11

**D-30 design token 生命周期：续期路径 + 精确切除签名腿（批 2）**

- **总目标**：把 design token 从「限期作废、只能靠再评审重铸」改成**授权与时限解耦**——只要被评审的设计文档集没变，就续期而不是重评审；文档变了才必须重评。
- **FR-T1/T2/T3 两段化 + 删密钥链 + 审批码换源**：token = `<uuid>:<expiresAt>`，**恰好两段**（对齐上游 thincoder 的「uuid:expiresAt, exact slot match + TTL only」）；D-25 引入的 HMAC 签名腿与整条密钥解析链（`resolveTokenSecretPath`/`resolveTokenSecret`/进程内单例/公开默认值回落）**整体删除**。删除依据（需求档 §2.3 威胁模型，会诊判定 + 父侧回代码核实）：① 门禁刻意 fail-open（`eng.mjs:167`）——它是纪律护栏不是安全边界；② 真正挡住伪造的是**记录全等匹配**（判定在签名校验之前）；③ 密钥与 token 镜像**同目录**（能写后者者几乎必然能读前者，Windows 上 0600 近似 no-op）；④ 净效果为负（密钥链换来启动全量作废 + 一条独立运维失效轴，防伪造增量 ≈ 0）。**审批码不一起删**（否则 R2 的 `[APPROVE:<code>]` 防伪造语义静默归零）——改为**无状态派生** `sha256(uuid).slice(0,8)`：uuid 由宿主 `randomUUID()` 生成且**从不进提示词**，对主代理同样不可预测。
- **FR-T4 缺省 TTL 7d**：`TOKEN_TTL_DEFAULT_MS = 7d`（TTL 只作陈旧度护栏）；`cordis.patch.yml` base 的 `engTokenTtlMs` 3600000 → **604800000**，使新缺省在交付后即刻现场生效（决策 D11）。
- **FR-T5 续期（本批核心）**：落点 = **`eng_coder` 过期子分支**（决策 D1；否决写门禁——其契约是 fail-open 而续期必须 fail-closed，且没有回传新串的通道；否决 advisor 入口——语义倒置，续期正是为了不付评审成本）。四路判定：无记录/无指纹 → 无法续期；文档不可读 → 视为已变更拒绝（fail-closed）；指纹同 → **同一 uuid** + `expiresAt = now + 当前生效 TTL`，内存与磁盘同步并**回传新令牌串 + 「替换副本」指引**；指纹异 → 文档已变更拒绝。指纹 = 文档集**路径 + 内容**双绑：`sorted(normalize(path) + "\0" + sha256(content))` 再整体 sha256（新建 `lib/doc-hash.mjs` 单点实现；`normalize` = `path.resolve` + 反斜杠归一 + **不做**大小写折叠）。快照时点 = **待批令牌铸造时**，内容 = **历轮 documents 之并集**（决策 D5 + 设计评审 #2：防止「批准轮收窄 documents」把指纹绑窄）；空文档集不写指纹（决策 D6）；**未过期路径不做文档校验**（决策 D7，代价显式接受）。
- **FR-T6/T9 文案与迁移**：过期提示四分支各自说清（已续期 / 文档已变更 / 无法续期 / 旧版本令牌）；写门禁 deny 在令牌**已过期**时不再说「先写设计文档」（误导）而是指向续期/重评；TTL > 24h 时有效期显示**日期**而非裸 `HH:MM`。三段式旧令牌由形状检测识别 → 明确「旧版本令牌、形状已不兼容、无法续期」并指引重跑一次（**不做**旧格式兼容验签——保留旧通道等于保留伪造面，先例 = v2 废除 `[DESIGN-TOKEN:...]` 回显，决策 D8）。
- **FR-T8 token-store 两缺口**（会诊 G1/G2，父侧实证）：① 保存路径此前显式重建三字段 → 传入的 `docHash` 被静默丢弃（续期永远拿不到素材），现补 `docHash`/`docPaths` 条件字段；② 全局清扫此前「过期即删」→ 会顺手删掉**别的会话**可续期的记录（头号场景「重启后续期」非确定性失败），现改为五分支：畸形删 / 未过期留 / 过期且无指纹删 / 过期且有指纹**保留**（保留期上限 = `ENG_TOKEN_TTL_MAX_MS` = 30d，锚点 = `expiresAt`）。磁盘格式**纯追加**，旧记录读得动。
- **FR-T7 会诊口径修正**：`lib/prompts/main.md` 原称会诊「绑定当前回合、打断或回合结束即终止」，与 `consult.mjs`（D-28）实现矛盾——改为「**跨回合存活**（打断/回合结束不杀），且**有界**（只由 `consult_stop` / session 销毁 / `consultTimeoutMs` 看门狗终止；缺省 10min 可配）」。
- **删除后的两处静默显式处理**（设计评审 #9）：① 旧密钥环境变量 `THINCODER_TOKEN_SECRET` 变为无声 no-op → 启动时打印**一次性弃用告警**（密钥链已删除、该变量不再有任何作用）；② 磁盘上的 `.thincoder/token-secret` 成孤儿文件 → **声明不清理、留档**（删除属破坏性动作，不在本批范围；README 已注明其已被弃用）。
- **本批无 UI 变更**（设置页字段已在 D-29 落地）；零新增依赖、无构建步骤。
- 测试：全量 `node --test` 全绿（详见提交时套件计数）。

**D-29 配置面缺口：`consultTimeoutMs` / `engTokenTtlMs` 进 user 层白名单（用户实测痛点）——同批发版**

- **缺口**：两键运行时都读得到配置（`lib/consult.mjs:115` / `lib/advisor.mjs:677`），却都被 `mergeGlobalConfig` 的白名单排除 —— 结果是它们**只能**在 entry base（`cordis.patch.yml`）里改，**设置页改不动**。用户侧实测后果：① design token 每 1h 过期，而新 token 只能由一次新的设计评审签发 → **反复重评审**；② 会诊里慢/挂的模型把整轮吊满缺省 600000（10min），四个模型常只剩两个能回。
- **修复**：两键补进三面白名单（对齐 `dshBackgroundTimeoutMs` 的 N-5/US-10 先例）——`lib/config-store.mjs` 值域校验与常量（`isValidConsultTimeoutMs` 30000..3600000 / `isValidEngTokenTtlMs` 600000..2592000000）⊕ `mergeGlobalConfig` 白名单 ⊕ `lib/index.mjs` PUT 校验（`topAllowed` + 区间错误文案）⊕ 设置页表单字段（`lib/client.js`：校验 / 载荷 / 初始态 / busy 窗口编辑保留 / 新增卡片）。
- **base 示例值**：`cordis.patch.yml` 的 `consultTimeoutMs` 600000 → **1800000**（慢模型有合理窗口；原值会让整轮吊满 10min）。`engTokenTtlMs` 保持 3600000 —— **缺省值的语义变更属后续批次，本批只让两键可配**。
- **测试**：新增 4 条（`test/codex-runner.test.mjs`）——① PUT 接受合法值 + 回归断言「不再被当 unknown top-level field 忽略」+ merge 覆盖语义；② 区间外/非整数拒绝且不落盘（边界值两侧合法）；③ 设置页接线静态核对（`client.js` 无既有 UI 测试面，锁住「后端开了前端没接」这类静默半成品：初始态 / 载荷 / 校验 / busy 保留 / onChange / 区间常量同值）；④ user 层落盘 → `loadUserConfig` → merge → 到达运行时消费点的完整往返（锁「user 层能覆盖 base 钉死值」）。241 → **245 全绿**。
- **文档同步**：`README.md` 的 user 层白名单段与 `cordis.patch.yml` 头部白名单清单同步补齐（两处此前仍称两键「只在 base 配」，与本批改动矛盾）；README base 示例值同步为 1800000。

## [0.9.2] — 2026-09-09

**D-28 会诊跨回合失效修复（生产缺陷：PTC run-scoped 信号被继承）**

- **根因**：`consult_start` 把调用方 `exec.signal` 直传子代理，而 PTC 模式下它是 run_code 程序的 run-scoped 控制器（`dsh-tools/lib/types/ptc.js:375` 注入、`:532` 在程序 settle 的 finally 里 `abort('run_code settled')`）——会诊是「本回合 start、后续回合 check」的跨回合协议，子代理因此在启动 1~3 秒内被 `child.cancel({kind:'parent'})` 杀掉（stopReason=aborted，且从未发出模型请求）。2026-09-08/09 lore 会话生产实证：21 次尝试 20 次失败；唯一成功的一次是启动程序被一个 61 秒的 grep 卡住没结束。
- **修复**：子代理改用插件自持 `AbortController`（`lib/consult.mjs`）——取消只走 `consult_stop` / `consultTimeoutMs` 看门狗 / session 销毁 `cleanupConsultSessions` 三条显式路径；`lib/index.mjs` 的 consult_start 不再传 `exec.signal`。
- **附带归因修复**：看门狗超时与显式 abort 在驱动层都坍缩成 `stopReason=aborted`，现按 `timedOut` 归因（超时不再被读成「aborted 无死因」）；预算 < 1min 时显示为秒。
- 新增 `test/consult.test.mjs`（跨回合信号解耦回归 / stop 早停 / 看门狗有界 / session 销毁清理 / 选择器语义）。
- **advisor 复审跟进**（1🟡+5🔵 同轮清零）：①🟡 `consult_check` 的调用方信号只结束本次读取，不再杀子代理（此前会落进 failed 分支被读成「child ended: aborted」），并写进头注释；②🔵 codex 行提前 return 漏掉 `clearTimeout(watchdog)`，已补 finally；③🔵 codex 行 ABORTED 也按 `timedOut` 归因；④🔵 fire-and-forget 子代理补 `.catch` 兜底（异常不再让 `pending` 永久 >0 卡死后续 check）；⑤🔵 亚秒预算不再显示 0s；⑥🔵 `consult_check`/`consult_stop`/advisor 补齐 `markSessionSeen`。
- 测试 235 → **241** 全绿。

## [0.9.1] — 2026-09-07

**R6 维护轮（D-26 十项打磨全清，登记表 27/27 终态）**

- eng/escalate codex 分支：`resolveCodexCliGlobals` 告警逐条 warn + timeout/idle 非法回落响亮告警
- `engineeringToggle` 移除未用参数（调用方与测试全部迁移，兼容 shim 删除）
- eng 单飞拒绝返回补 warnPrefix；codex/dsh 空输出统一「(empty report)」交付语义；F10 盘回填区分「已签发未传」与「从未签发」两态文案
- eng dsh 同步路径簿记收敛到模块级 `deliverBookkeeping`（四路单一实现）
- dsh 后台兜底超时信封 code=ABORTED（resolve-race 与 reject-race 双分支均触发回滚指引）
- escalate codex jobs reject 分支补 `codexThreads` 清理；eng/escalate 后台派发句柄并入配置告警（warnPrefix，对齐 advisor 先例）
- 测试 229 → **235** 全绿

## [0.9.0] — 2026-09-06

**R5：dsh 路径后台化（DP-1 方案 B）——插件自建后台机制覆盖全部四机制，DSH 平台零修改**

- **advisor dsh 循环自动后台化**：dsh 路由预算 > `codexCli.budgetCapMs` 且 ctx.jobs 可用 → 自动派后台 job 跑完整评审循环（job 内预算不钳制）；≤cap 或 jobs 缺失 → 同步 + D-17 钳制告警（同步快路径护栏保留）
- **escalate/eng dsh 显式 `background` 参数**：不传=同步（现状）；传=true → 后台 job 内跑子代理（完成通知送指针、全文经 job_output）；followup 同参数语义
- **挂死兜底**：新配置 `dshBackgroundTimeoutMs`（顶层，默认 30min，60s~60min；三面白名单 + 设置页字段）；deadline 合成 = max(任务预算, 兜底)
- **降级两段式**：派发前预检/抛错 → 同步+钳制+告警；run() 内 ctx 破裂 → job 诊断失败（不可恢复）
- 单飞复合键、代际检查、簿记-done-成功分支全套复用 R2 模式
- 工程流程契约：background 任务返回句柄，「等完成通知再继续」
- 测试 215 → 229 全绿；真机终验：dsh 路由 900s 预算自动后台化、钳制告警消失

## [0.8.0] — 2026-09-05/06

**R1-R4 机制缺陷治理（26 项登记缺陷：24 修 1 驳 1 测量收口；测试 125 → 215）**

- **R1 诊断与校验层**：effort 最近支持档回落（等距向上取，全 9 消费点收口含 codex catalog resolver）；advisor 流观测（finish.kind/usage/blocks）+ 空响应四形态分类；dsh 预算钳制；`advisor.maxOutputTokens` 可配置（三面白名单，默认 16384）
- **R2 执行架构与进程生命周期**：escalate/eng codex 路径迁 ctx.jobs（簿记 done 成功分支恰好一次）；三机制复合键 single-flight；`advisorGeneration` 代际检查（晚到 finalize 不复活已重置状态）；全局 codex 并发准入 `codexCli.maxConcurrent`（默认 8，CONCURRENCY_LIMIT fail-fast）；启动清扫陈旧临时目录；DP-1 方案 A dsh 钳制
- **R3 回落与失败语义**：回落活锁封顶（fallbackFailureCount 连败 2 次硬停 + 双路由诊断）；空响应自动重试一次（D-裁决-1）→ 仍空转可归因失败不烧轮次；prior 纯净化（机制后缀不进 lastAdvisorOutput）
- **R4 一致性与 UX**：设置页保存竞态修复（busy 全表单禁用 + 触碰字段保留）；`advisorOverride.runner` 三面同步；**token-secret 安全加固（D-25）**：公开默认密钥 → env / `$DSH_HOME/.thincoder/token-secret` 持久化随机密钥（0600，损坏自愈）/ 无持久化面响亮告警；D-15 idle 测量（3 次 high-effort 实测最大静默间隙 50s << 240s，维持 300s 默认）
- 真机验证 10 项收口（四机制 + 两受害场景：空响应与 effort 秒死活体治愈）

## [0.7.0] — 2026-09-05

**codex-cli runner 集成（一/二期 + 评审修复 + jobs 派发 + 智能回落基线入库）**

- `lib/codex-adapter.mjs`：codex exec 子进程适配器（无 shell spawn、Windows shim 解析、进程树终止、--json 事件流、-o 权威输出、idle watchdog、B8 反套娃前缀）
- 四机制接入：advisor/consult 只读沙箱、escalate/eng_coder 写沙箱（workspace-write）；followup 线程连续性（`exec resume`，内存态）
- ctx.jobs 后台派发（预算 > budgetCapMs）：完成通知指针 + job_output 全文（保尾截断）；job id branded string
- 智能回落：codex 连续 2 次失败 → 自动回落 dsh 路由一轮；`codexCli.budgetCapMs`（默认 540s，平台 600s 墙钟内安全余量）
- 设置页：runner 选择、codex 模型/effort 目录化下拉（`/catalog` 运行时注册表端点）、budgetCapMs/maxConcurrent/idleTimeoutMs 字段
- 测试 78 → 125 全绿（本版本为历史工作基线入库，版本号自 0.1.0 锚定）

## [0.6] — 2026-09-03

- **F12 会话级状态持久化**：`$DSH_HOME/.thincoder/session-state.json`（engineering/评审轮次+prior/触达文件/覆盖，跨重启恢复、只填空槽、7d TTL、与 design-tokens.json 分文件回滚独立）
- **F13 eng_coder 阶段化任务书**：`stages` 结构化参数（maxItems 10、四段渲染、阶段纪律、stage 状态表前置防掐断）
- compactMessages keyFiles 去重上限 15；测试 50 → 78

## [0.5] — 2026-09-02

- 设置页 UI 打磨：宿主语义 token（深浅色随动）、code review 2 轮 11 项修复、池保存/草稿播种修复

## [0.4] — 2026-09-02

- **二期设置页**：全局配置二层（entry base ⊕ `$DSH_HOME/.thincoder/config.json` user 层，保存即生效）；DSH 设置面板「Thincoder」页（手写 CJS 免构建）；host config API `/thincoder-suite/api`

## [0.3] — 2026-09-02

- **F10** design token 磁盘持久化（重启免重评审）；**F11** reviewType 切换重置轮次；thincoder-eng 预设 PTC 工具集；F8 判定启发式 v4

## [0.2] — 2026-09-01/02

- **一期 host 机制**：advisor 分层路由（round1/convergence）、effort 透传、会话级覆盖（advisor_config）、预算模型+超时硬生效；F8 评审通过判定修复；F9 eng_coder 资源策略

## [0.1] — 2026-09-01

- thincoder 四机制（advisor/eng/escalate/consult）移植为 DSH cordis 插件（零依赖、免构建）
