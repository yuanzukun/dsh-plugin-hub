# dsh-thincoder-suite

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](./LICENSE)
[![topic: dsh-plugin](https://img.shields.io/badge/topic-dsh--plugin-8957e5)](https://github.com/topics/dsh-plugin)

**把「AI 写代码时的五条自我纪律」装进 [DSH（DeepSeek Harness）](https://deepseek.com)**——一个插件，十六个工具，**不改 DSH 本体一行代码**；外加一套**你和模型共看同一份账本**的个人任务台账（批 36，含 `/task_*` 四条命令与**交接**）。它是给 **DSH 本身**写的（本机那种「桌面壳」只是 DSH 的一种包装方式，插件不依赖壳）。

> 移植自开源项目 [thincoder](https://gitee.com/shanghai-xinbo/thincoder)（上游 MIT 协议），向上游贡献者致谢。

---

## 它替你挡掉哪六种翻车

| 你遇到过 | 这个插件怎么治 | 工具 |
|---|---|---|
| **AI 说「没问题了」，其实没审完**——评审循环停不下来，或者停下来时你也不知道它到底看没看你的改动 | **会终止、可对账**的评审：轮次有上限、每轮必须回一张「逐条对账表」，连引用行号都去磁盘上验真 | `advisor` |
| **代码写完了才发现方向错了** | **先设计、后写码**：没拿到「评审通过令牌」之前，写产品代码会被当场拦下 | `eng` / `eng_coder` |
| **模型能力不够，越改越烂** | **把活交给更强的模型亲自写**，写完给你一份术后报告，你验收 | `escalate` |
| **卡在同一个问题上反复失败** | **多个模型并行独立会诊**，各出各的结论，你逐条裁决 | `consult_start` |
| **长任务跑着跑着就跑偏**——忘了最初的目标、改完没验证、没评审就宣告完成 | **每一步把目标/判据/欠账重新摆到眼前**：立项先写可验证判据（写不出就建不起目标）、完成要有跑过的证据、改完没验证就别想收尾 | `goal_criteria` / `goal_verify` / `anti_drift_config` |
| **不知道「什么在等我拍板」**，也确认不了「我看到的就是模型看到的」 | **一套账本三面同源**：看板、每回合注入行、工具读的是**同一个读函数**；**完成必须留凭据**（没有凭据完不成）；**待你决策的项置顶**；**换会话不漏活**（看板三区 + 「接手」只改归属） | `task_add` / `task_update` / `task_done` / `task_list` / `task_claim` |

**为什么这六个不是「又一套流程」**：它们的共同点是**每一条结论都要能被机械核对**——对账表、令牌、纪要、跑过的测试、判据的检查、台账凭据，都在磁盘上留痕。**不是靠信任模型，是靠留下可核对的痕迹。**

```mermaid
flowchart LR
  U["你提需求"] --> A{"任务有多大？"}
  A -- "要改产品代码" --> E["eng 工程模式<br/>先设计 → 评审 → 拿令牌"]
  E --> C["eng_coder 写码"]
  A -- "超出模型能力" --> X["escalate 飞刀<br/>强模型亲自写"]
  A -- "卡住没头绪" --> Q["consult 会诊<br/>多模型并行给意见"]
  A -- "改完了" --> R["advisor 评审<br/>多轮收敛 + 引用验真"]
  C --> R
  X --> R
  style E fill:#e8f0ff,stroke:#48f
  style R fill:#e8ffe8,stroke:#0a0
```

---

## 六个机制各自怎么跑

### ① advisor：把「无限找茬」变成「有界对账」

普通的 AI 复查看似在进步，实际有四个陷阱：**没有终止条件**（每轮都能报新问题）· **锚定效应**（复审会顺着上轮结论重复深化）· **证据不可验证**（报的行号可能是错的、旧的、编的）· **运动员兼裁判**（同一个模型审自己刚写的东西）。

本插件的做法：

```mermaid
flowchart TD
  R1["Round 1<br/>全量审查，建立问题清单"] --> R2["Round 2<br/>核销上轮清单<br/>只接致命新问题（崩溃/丢数据级）"]
  R2 --> R3["Round 3–5<br/>严格只核销上轮响应表<br/>不再找新问题"]
  R3 --> CAP{"第 6 次调用<br/>（仅代码评审）"}
  CAP -->|"机械拒绝，不过 LLM"| STOP["结束"]
  R3 -->|"全部销账"| PASS["✅ 通过"]
  style PASS fill:#dfd,stroke:#090
  style CAP fill:#fdd,stroke:#c00
```

四条配套的机械约束：

- **响应表协议**：被评审的一方每轮必须回 `| # | Action | Detail |`，Action 只有四个值（`Fixed` / `Dispatched` / `Not an issue` / `Deferred`），逐条对账。**`Dispatched` 只是「认领」不是「解决」**——派出去还没回来的 🔴，和没修的 🔴 同样算没过。
- **引用验真**：报告里每个 `文件:行号` 都去磁盘上比对，伪造引用直接标出来。
- **每轮全新上下文**：上一轮的输出以原文注入新会话——防止「顺着自己上轮的话往下说」。
- **轮次上限只对 code 评审生效**（Cap 只对 code 评审生效）：代码评审有 5 轮硬上限；**设计评审豁免上限**（设计文档天生要反复改，改文档→重评审正是本机制的本意），改由「**连续三次跑不出可用结论 ⇒ 拒绝再发起**」兜底，且**不可自解除**（改配置、改文件、重跑都不复位，唯一出口是新会话）。**两半必须成对**：只豁免 = 撤掉唯一的界；只护栏 = 设计评审仍被上限误杀。

### ② eng：没拿到令牌，写不了产品代码

```mermaid
sequenceDiagram
  participant U as 你
  participant A as 主代理（架构师）
  participant V as advisor 设计评审
  participant C as eng_coder（实现）
  U->>A: 提需求
  A->>A: 澄清需求 → 写需求档 → 写设计档
  U->>V: 发起设计评审（必须由你发起）
  V-->>A: VERDICT: PASS + 批准码
  A->>C: 带着 design token 派实现
  C-->>A: 交付报告（改了哪些文件、跑了什么）
  A->>V: 交付代码评审（自动）
```

- `eng` 工具开关工程模式；**进模式后，模型只能写文档**——`write` / `edit` 想动产品代码会被 `tools/pre-execute` 当场拦下（`docs/**` 与根级 `.md` 豁免，那是架构师的产出物）。
- **设计评审必须由你发起**，模型不能自己审自己、自己给自己发令牌。
- 令牌（design token）**跨重启有效**（存 `$DSH_HOME/.thincoder/design-tokens.json`），默认 7 天；**设计文档没变就自动续期**，文档改了才要重评。
- `eng_coder` 支持**结构化阶段任务书**（`stages`）：大任务拆成几段，每段有目标、可动文件、验收标准、自检命令；**报告必须以阶段状态表开头**——这样报告被截断也不会丢分类账。

### ③ escalate：把活交给更强的模型亲自写

判断任务超出当前模型能力时（复杂多文件重构、疑难 bug、精妙算法），把任务连**写权限**一起交给 `consultModels` 池里的更强模型。它自己改代码，返回术后报告（改了什么 / 为什么 / 怎么验证），**你负责验收**（读变更文件、跑测试）。

护栏：子代理里不能再飞刀（防递归甩锅）；工程模式下直接拒绝（工程模式的实现只能走 `eng_coder`）。

### ④ consult：卡住了就并行会诊

```mermaid
flowchart LR
  S["consult_start"] --> P["多个模型<br/>并行独立分析<br/>（只读）"]
  P --> J["平台 job 后台跑<br/>settle 时自动通知你"]
  J --> D["先落盘纪要<br/>再发完成通知"]
  D --> M["读全 digest（首选落盘文件）<br/>逐条处置"]
  M --> G{"下一次 consult_start<br/>：消化了吗？"}
  G -- "没消化" --> BLOCK["拒绝发起<br/>（内联未消化的 digest）"]
  G -- "已消化 / 已豁免" --> S
  style BLOCK fill:#fdd,stroke:#c00
```

- **不需要轮询**：会诊在后台跑，完成时你会在会话里被通知（忙就插到下一步，空闲就自动开一个回合）。
- **纪要默认落盘**：`docs/consult-minutes/` 下的纪要**先写盘、再发通知**——通知丢了纪要也在。
- **消化门禁**：没消化的会诊会**拦住你发起下次会诊**（拒绝并把未消化的内容摊出来）。
- **早停不丢东西**：中途 `consult_stop` 也会产一份「墓碑纪要」，已收到的回复照常送达。

### ⑤ anti-drift：长任务不跑偏（批 34）

```mermaid
flowchart TD
  A["我要立目标"] --> B{"先写过判据了吗？<br/>（goal_criteria set）"}
  B -- "没有" --> DENY["拒绝建目标<br/>「没有可验证判据的目标是愿望不是目标」"]
  B -- "有" --> OK["建目标成功<br/>判据自动绑定"]
  OK --> L["每一步都注入：<br/>目标 + 判据 + 欠账"]
  L --> W{"改了产品代码<br/>但没验证就想收尾？"}
  W -- "是" --> PUSH["推回该回合<br/>（三族各有上限）"]
  W -- "否" --> DONE["宣告完成"]
  PUSH --> H["上限用尽 ⇒ 只说一句诚实句<br/>（会话累计 ≤3 句后整机静默）"]
  DONE --> G{"有跑过的证据吗？"}
  G -- "没有" --> DENY2["拒绝完成<br/>指路 goal_verify / advisor"]
  G -- "有" --> PASS["放行"]
  style DENY fill:#fdd,stroke:#c00
  style DENY2 fill:#fdd,stroke:#c00
```

- **它治什么**：长任务里「忘了最初的目标、忘了跑验证、忘了评审」——把纪律从**静态提示词**里挪到**每一步的动态注入 + 两道硬门**上。
- **三个工具**：`goal_criteria`（写判据，可先存**待绑槽**再建目标）· `goal_verify`（记录「检查真的跑过」）· `anti_drift_config`（开关**七键**）。
- **默认分档**：注入与完成门**默认开**（低打扰 / 挡假完成）；推回与台账门**默认关**（会改变回合命运）。
- **三域分离**：落章域（跨回合跨重启）· 回合域（每回合归零）· 会话域（跨回合累计）——**每个标记恰属一域**。
- **它不做什么**：不读别的插件的黑板（跨插件欠账注入是遗留项）；不做轮次/预算读数（读数可得性未验证，不造读数）。

### ⑥ 任务台账：你和模型看的是**同一套账本**（批 36）

```mermaid
flowchart TD
  W["唯一写门<br/>task_add / task_update / task_done / task_claim"] --> J[("tasks.json<br/>唯一真源 · 修订号 rev · 归属 createdBy/owner/claimedFrom")]
  J --> R["唯一读函数 readTasksView()"]
  R --> B["侧栏看板（三个区：本会话 / 待接手 / 全部）"]
  R --> I["每回合注入行"]
  R --> T["工具 task_list"]
  R --> C["命令 /task_list /task_add /task_done /task_claim"]
  W --> G{"门：凭据 / 五态迁移 / 卡住原因 / rev 冲突 / 疑似凭据 / 接手方会话"}
  G -->|拒| Z["零写入 + 文案指路"]
  style J fill:#e7f5ff,stroke:#1c7ed6,stroke-width:2px
  style B fill:#e6fcf5,stroke:#0ca678
```

- **它治什么**：任务散在对话里、聊长了就丢；模型说「做完了」你没有对照物；**什么在等你拍板**看不到；**换了新会话，旧会话记的活就"消失"了**。
- **一句话判据**：**你在看板上看到的，与模型同一回合读到的是同一份** —— 不是「同一个文件」的口头承诺，而是**三面只调同一个读函数**（结构保证）。
- **四条硬规矩**：① **完成必须留凭据**（写不出「跑了什么、看到什么」⇒ 拒写且**零写入**）；② **五态流转**（待办 → 已接手 → 在做 → 完成 / 卡住），卡住必须说清**等外部**还是**等自己动手**；③ **待你决策的项单独成区且置顶**；④ 看板**不能打勾/改进度**——完成必须带凭据；看板上**唯一的写动作是「接手」**，而它只改归属（`owner`）、不动状态。
- **归属与交接（批 36-补）**：每条任务有三个归属字段——`createdBy`（谁建的，**永不改**）· `owner`（现在归谁，**只能经 `task_claim`/「接手」改**）· `claimedFrom`（接手时记下的上一任）。看板分**三个区**：**本会话**（默认）· **待接手（N）**（别人/前任留下的**未完成**项）· **全部**。**交接轮换新会话时**：旧会话把活停在「在做/卡住」⇒ 新会话打开看板 ⇒「待接手 N 条」⇒ 点**接手** ⇒ 继续。**绝不自动改归属**（悄悄吞掉别人的活比断层更糟）；**待接手区不判会话活性**（只看归属，不看那个会话还在不在）。
- **也可以直接敲命令（批 36-补）**：`/task_list`（打印看板）· `/task_add <标题> | <怎么算完成>` · `/task_done <id> | <凭据>` · `/task_claim <id>`。**四条命令与工具走同一道写门**——命令层不自己判状态机、也不自己写盘（`/task_done` 不写凭据照样被写门拒、一个字节都不动）。**没装命令服务时命令不出现、工具与看板照常**（只 warn 一条）。
- **多会话并行**：台账带修订号，两个会话同时写时**后写的会被拒并明确告知**（不会静默丢更新）。
- **落点**：`<你的工作区>/.thincoder/tasks.json`（绑工作区 ⇒ 跨会话、跨重启都在）；**旧台账照样能读**（没有归属字段 ⇒ 视为「无归属」，不报错、不迁移、不改写）；**只增不删**（完成可重开，凭据不清空）。
- **没有 better-sidebar 也能用**：装了 `dsh-better-sidebar` 就是右侧栏一个 tab（只读渲染 + 三区切换 + 接手）；没装则用 `task_list view=board`（或 `/task_list`）在会话里渲染**同一份内容**（降级不是缺失）。
- **它不做什么**：不碰宿主自带的 `todo_write`（那是「本回合的工作便签」，每回合开始就被平台清空——**两个物种**）；不做截止日期；不做删除/归档；不做第二份存储；**不与 `dsh-team-link` 的团队台账联动**（那是另一套账，本批不假装打通）。

---

## 底座：让长任务跑得完、失败看得见

六个机制共用一层基础设施（**全部插件自建，DSH 平台零修改**）：

| 能力 | 人话 |
|---|---|
| **长任务后台化** | 超过预算自动转后台 job，**不再撞平台的 10 分钟墙钟**；完成时通知你 |
| **失败可归因** | 空响应分成四类、流的收尾状态和用量都记下来；**从不静默截断**——该告警的地方一定出声 |
| **自愈与封顶** | codex 连败两次自动回落一轮；回落再连败两次硬停并给出双路由诊断；任何循环都有界 |
| **并发与状态安全** | 每个会话同一机制单飞；后台结果晚到不会复活已重置的状态；全局 codex 并发有闸 |
| **推理强度智能回落** | 按目标模型**真实支持的档位**回落到最近档，绝不因为配了个不支持的档就秒死；**`off` 是「关闭开关」不是「力度档」**，所以回落**永远不落到 `off`**（只有模型除 `off` 外没有任何力度档时才退化使用，并单独告警）；显式要求 `off` 而模型关不掉时，**省略该参数、交还提供方默认**，并告诉你 |
| **安全模型** | 授权靠**记录全等匹配 + 设计文档集指纹 + 流程纪律**（令牌 `uuid:过期时间` 两段式，不引入签名密钥链） |

### ★ 最容易被配错的一件事：长任务默认走后台——前提是装了 jobs 插件

`eng_coder` 和 `escalate` 的 **dsh 子代理路径默认后台**执行（批 21 起省略 `background` 即后台：返回 job 句柄，完成时通知，**报告全文首选读落盘文件 `$DSH_HOME/.thincoder/jobs/<jobId>.txt`、`job_output` 作为附加读取手段**——该取向自批 26 起适用于四条机制的**全部**后台派发）；传 `background: false` 才强制同步。codex 后端则一直按预算自动后台（缺省预算本就超过阈值）。

| 调用方式 | 谁在等 | 生效的截止 | 结果 |
|---|---|---|---|
| 不传 `background`（默认）/ 显式 `true` | 父代理立刻拿到 job 句柄 | `dshBackgroundTimeoutMs`（默认 30 分钟） | **不占父代理墙钟**，完成时通知；**报告全文首选读落盘文件**（`$DSH_HOME/.thincoder/jobs/<jobId>.txt`，`job_output` 为附加）（stage 门横幅也在 job 输出里） |
| 传 `background: false` | 父代理阻塞 | `codexCli.budgetCapMs`（默认 540s，**刻意低于平台 600s**） | 当场拿结果；插件在平台之前温柔超时、能拿到诊断；**但任务活不过 10 分钟** |
| 后台**回落**（jobs 插件未装 / 派发失败） | 父代理阻塞（回落同步） | 同上 `budgetCapMs` | **告警随工具返回可见** + 回落同步（仍受 540s/600s 约束） |

> **⚠ 前提**：后台依赖 `dsh-jobs-local` + `dsh-tool-jobs` 两个插件。**没装时不会报错，而是告警（随工具返回可见）并回落同步**（那时仍会撞 600s）——批 21 起默认就是后台，这两个插件从「跑长任务才需要」变成「建议常装」。
> **⇒ 想跑过 10 分钟，正解是装齐 jobs 插件（省略 `background` 即后台），不是去调大 `budgetCapMs`**（后台路径根本不读这个键）。

---

## 安装

要求：**DSH（DeepSeek Harness）本体**——**不需要桌面壳**（本机那种包装壳只是 DSH 的一种运行方式）。具体：**DSH ≥ `0.2.1-rc.2`**（`peerDependencies` 声明的门槛，由**平台自己**的组合兼容闸门在装配前执行；本版**十条**平台触点锁逐条对齐，并**已在 `0.2.2-rc.1` 上验证过**（批 45：触点锁逐条绿 + 四源版本读取链复核 + 全量 `node --test` 678/678；三条主链真机派发与 `contractWatch` 真机读数见 `CHANGELOG.md` 0.40.0 的「诚实清单」））+ cordis `^4.0.0-rc.7` + web profile 标准服务（tools / llm / subagents / systemPrompt / webServer——webServer 缺失时仅设置页 API 降级，host 工具不受影响）。

> **⚠ 平台版本门槛（v0.30.0 起 · v0.33.0 上调）**：**本版只支持 DSH ≥ `0.2.1-rc.2`**（低版本由平台自身的 peer 兼容闸门**拒绝安装**，不会出现「装上了起不来」）。
> **如果你的 DSH 低于 `0.2.1-rc.2`（例如 `0.2.0-rc.x` / `0.1.7-rc.2`），请改用旧版 release**：[**v0.29.11**](https://github.com/shenhuanageshei/dsh-thincoder-suite/releases/tag/v0.29.11)（及更早）支持 `0.1.7-rc.2`。
> 硬装到低版平台上的表现是**整包被平台拦下**（不是半残运行）：插件管理页该包显示「异常」，启动日志出现 `dsh: skipping profile bundle "@dsh-external/dsh-thincoder-suite"`，并给出该包的 peer 范围与豁免指引——**这属于预期行为，不是安装损坏**。
> 装配期还会有一条版本哨兵告警（`[thincoder-suite] 平台版本哨兵…`，只警告不阻断），两种形态都指向此处；也可随时调用只读工具 `contractWatch` 看当前平台版本、版本来源与十条触点锁现状。
> **预期内的告警**：哨兵比对的是**本版验证过的那个平台版本**，所以同一 peer 区间里**别的**版本（例如将来的 `0.2.0-rc.3`，或区间内更早的 `0.2.0-rc.1`）也会各打**一次**告警——那不是在断言「不支持」，而是提示「本版尚未对该版本复核过」，照 `contractWatch` 走一遍十条触点锁即可（这正是它存在的意义）。

> **⚠ 想让长任务能跑过 10 分钟，请先确认这两个插件在**：**`dsh-jobs-local` + `dsh-tool-jobs`**（后台任务靠它们）。**没装也能跑**，但长任务会**告警并回落同步执行**（批 21 起默认后台，回落时仍会撞平台的 600 秒墙钟）——**详见下方「最容易被配错的一件事」**。

```bash
git clone https://github.com/shenhuanageshei/dsh-thincoder-suite.git
```

在你的 web profile 目录（`~/.dsh/profiles/web`）：

```bash
pnpm add link:<克隆路径>/dsh-thincoder-suite
```

然后编辑 profile 的 `package.json`，把包名加进 `dsh.profile.bundles`：

```json
{
  "dsh": {
    "profile": {
      "bundles": [
        "@dsh-external/dsh-thincoder-suite"
      ]
    }
  }
}
```

重启 DSH。启动日志出现

```
[thincoder-suite] active: advisor/eng/eng_coder ...
```

即装配成功。

### 本机开发：让 DSH 直接读你的 git 工作副本

**如果这个插件是你自己在改的**，请务必用 `link:`（上面那条命令就是），**不要用 `file:`**：

| 写法 | pnpm 干了什么 | 改源码后 |
|---|---|---|
| `link:<绝对路径>` | 在 `node_modules` 里建一个**指向源码目录的链接** | **立刻可见**（重启后生效） |
| `file:<绝对路径>` | 把文件**硬链接复制**进 `node_modules/.pnpm/…` | **不会生效**——你改的是另一份 inode |

`file:` 那个坑很隐蔽：文件在磁盘上是同一份内容、哈希都一样，只有 `nlink` 与 `inode` 能看出是**两份**。
另外，**新增文件不会被复制过去**——`import` 一个新模块会直接失败。判断当前是哪种：

```bash
node -e "const fs=require('fs');const p='<profile>/node_modules/@dsh-external/dsh-thincoder-suite';console.log(fs.realpathSync(p))"
```

解析到**你的克隆目录** = `link:`（活）；解析到 `…/.pnpm/@dsh-external+dsh-thincoder_…` = `file:`（快照）。
已经是快照、又想切活：把 `package.json` 里那一行改成 `link:<克隆路径>`，再
`pnpm add @dsh-external/dsh-thincoder-suite@link:<克隆路径> --lockfile-only`，
然后把 `node_modules/@dsh-external/dsh-thincoder-suite` 换成指向克隆目录的链接（Windows 上 junction 即可），重启。
切换前先备份 `package.json` 与 `pnpm-lock.yaml`。

> **在本仓里不要 `pnpm install` / `npm install`**：本仓**零依赖**，`node --test` 直接就能跑（这也是它能免构建直发的原因）。`package.json` 的 `peerDependencies`（`@deepseek-ai/dsh` + `cordis`）声明的是**宿主**提供的运行时，不是要装进来的包——若你的安装器开了 `auto-install-peers`，它会去 registry 拉这两个宿主包（两个名字都已发布、可解析，例如 `@deepseek-ai/dsh@0.2.0-rc.1` 存在），纯属白装且**可能把一个副本塞进 profile 的 `node_modules` 里遮蔽宿主版本**（本机 2026-09-11 曾因 profile 里多出一份旧 `dsh-session` 起不来）。**DSH profile 那边的 `pnpm` 由 `pnpm-workspace.yaml` 的 `autoInstallPeers: false` 兜住**，本仓这边靠这条提示兜住。

---

## 配置（两层）

全局配置分两层：

| 层 | 位置 | 怎么改 | 什么时候生效 |
|---|---|---|---|
| **base** | `cordis.patch.yml` 的 `config`（启动快照） | 手编该文件 / profile 部署副本 | **重启 DSH** |
| **user 层** | `$DSH_HOME/.thincoder/config.json` | **DSH 设置面板 →「Thincoder」页**（也可手编 JSON） | **保存即生效** |

生效值 = user 层（字段级覆盖 base）⊕ base；user 层缺失或损坏则回落 base。user 层可配字段白名单：
`advisor.round1/convergence` 组（provider/model/effort/timeoutMs/runner）、`advisor.includeProjectGuide`、`advisor.maxOutputTokens`、
`advisor.contextTokens`、`advisor.standardsDoc`、`advisor.documentMapDoc`、`advisor.criteriaDoc`、`consultModels`（整体替换）、
`engCoderMaxTokens`、`engCoderEffort`、`codexCli`、`dshBackgroundTimeoutMs`、`consultTimeoutMs`、`engTokenTtlMs`、
`ledger`（批 36 个人任务台账：开关 / 文档清单 / 话术模板）——其余字段（`engineering` 等）
只在 base 配。文件示例：

```json
{ "version": 1, "config": { "advisor": { "round1": { "provider": "…", "model": "…" } } } }
```

> 部署侧 bundle 安装时 `cordis.patch.yml` 会作为默认 patch 应用——本仓库文件是 base 示例（**单一事实源**）；`link:` 安装直接编辑克隆目录即可。

### 设置面板「Thincoder」页

设置 →「Thincoder」：

- **四个 tab**（v0.32.0 起）：**常用**（当前会话视图 + 首轮/收敛轮：runner、provider、model、effort、超时）· **会诊**（会诊模型池 + 会诊看门狗）· **任务台账**（`ledger` 三键）· **高级**（评审记忆开关、输出/上下文预算、项目文档声明、eng_coder 资源、Codex runner、后台兜底、设计令牌有效期）。每项都是「**人话主标签** + 灰字技术键 + 一句『它影响什么』」；**保存**写 user 层；**恢复默认**清 user 层回落到 base。
- **个人任务台账**（批 36-补2，v0.32.0 起在「任务台账」tab）：三个控件——「开不开」下拉（开着 / 关掉）· `ledger.docPaths` 多行文本域（**一行一个路径**，行序即清单顺序，最多 8 条）· `ledger.copyTemplate` 文本域（3 行高，**边打边显示字数 / 上限**）。这三键此前**只能在设置页之外手编 `config.json`**；现在与页面其它键走**同一条保存通道**（既有 `PUT /config`，不新增写端点）与同一条恢复通道（既有「恢复默认」= 整节恢复）。user 层没有 `ledger` 时，控件显示**内置默认值**并标注「未在 user 配置中显式设置 ⇒ 当前用内置默认」；**没动过就不写盘**（不会把内置默认物化成「显式设置」）。
- **当前会话视图**：显示生效摘要与覆盖来源，可「应用到当前会话」（优先级高于全局）或「恢复会话默认」。

host API 前缀 `/thincoder-suite/api`（GET/PUT/DELETE `/config`、GET/DELETE `/session`、POST `/apply-session`）。**全部端点先过宿主信任栅栏**（`connection.requestRejection`：跨站 / 非受信 Host ⇒ 403，无浏览器会话 cookie ⇒ 401；栅栏不可核验 ⇒ 503 fail-closed，绝不静默放行）。

### base 配置示例（`cordis.patch.yml`）

```yaml
- insert:
    - id: thincoder-suite
      name: '@dsh-external/dsh-thincoder-suite'
      config:
        # 会诊 / 飞刀模型池（最多 5 个）。
        # 不配置则 escalate / consult 工具不注册；advisor / eng / eng_coder 始终可用。
        consultModels:
          - provider: provider-a        # 你 settings.yaml 里已配置的 provider
            model: strong-model-x
          - provider: provider-b
            model: strong-model-y
            effort: high                # 可选，映射 reasoningEffort
          # 也可整行改走 codex（runner 字面量；与 provider/model 行并列，可混用）：
          #   - runner: { kind: codex-cli }                  # 本地 Codex CLI 子进程（可写；advisor/consult/escalate/eng_coder）
          #   - runner: { kind: codex-app-server }           # 平台 codex provider 的 app-server 传输面（**只读定位**：advisor/consult 用；
          #                                                  # 不消费 model/effort——模型由本机 Codex 配置决定；写任务会被具名拒绝，
          #                                                  # 详见 docs/2026-10-14-codex-app-server-design.md）
        # advisor 评审路由（不配置则跟随当前会话模型）——按轮次分层：
        advisor:
          round1:                      # 首次全量评审（建议旗舰组）
            provider: provider-a
            model: reviewer-model
            effort: medium             # 可选 off|low|medium|high|max；缺省不传（适配器默认）
            timeoutMs: 900000          # round1 缺省 600000
          convergence:                 # 收敛轮（round 2+ 共用；建议快档）
            provider: provider-a
            model: fast-reviewer-model
            effort: low
            timeoutMs: 300000          # convergence 缺省 300000
          includeProjectGuide: false   # 评审是否注入 AGENTS.md（默认 false；评审只认显式 documents）
        # eng_coder 子代理资源（缺省即安全值，一般无需配置）
        engCoderMaxTokens: 65536       # 输出预算（缺省 65536）
        engCoderEffort: medium         # 推理档（缺省 medium；非法值忽略并警告）
        # dsh 后台任务挂死兜底（可选；缺省 1800000 = 30min，合法 60000..3600000）
        dshBackgroundTimeoutMs: 1800000
        # codex-cli runner 全局节（可选；配了任何 codex 行/后端才需要）
        codexCli:
          executable: codex            # 可执行名或完整路径（缺省 PATH 上的 codex）
          model: codex-model-a           # codex 默认模型（可选）
          engCoderRunner: codex-cli    # eng_coder 走 codex 后端（可选；缺省 dsh 子代理）
          defaultTimeoutMs: 600000     # codex 任务默认预算（缺省 600s）
          budgetCapMs: 540000          # 同步执行预算上限——超过则派后台 job（缺省 540s，须低于平台 maxWallMs）
          maxConcurrent: 8             # 全局 codex 并发上限（fail-fast 不排队；缺省 8）
          idleTimeoutMs: 300000        # 写任务假死判定（事件流静默窗口；缺省 300s）
        # 可选：其余开关
        engineering: false             # 所有会话默认进工程模式（默认 false）
        engTokenTtlMs: 604800000       # design token 有效期（合法 600000..2592000000 = 10min..30d；缺省 7d）
        consultTimeoutMs: 1800000      # 会诊单个模型超时（合法 30000..3600000 = 30s..1h）
        # 个人任务台账（批 36；键语义见 docs/2026-10-16-task-ledger-design.md §十四）
        ledger:
          mode: standalone             # off | standalone（缺省 standalone；off 只关个人台账分区，防漂移状态区仍在）
          docPaths: []                 # 结构化验收档路径清单（相对工作区根；最多 8 条；只读渲染勾选态）
          # copyTemplate: 说人话大白话，说清楚前因后果，给建议。   # 复制话术模板（缺省即此句）
        antiDrift:                     # 批 34 长任务防漂（见 docs/2026-10-14-anti-drift-design.md）
          inject: true                 # 每步注入「目标 + 判据 + 欠账」行（默认 true）
          completeGate: true           # 目标完成门：无证据不许宣告完成（默认 true）
          pushback: false              # 回合推回：改完代码没验证就不让收尾（默认 false）
          verifyHeuristic: true        # shell 命令形启发（只喂推回谓词；默认 true）
          stallRepeat: 3               # 连续同名同参调用几次就提醒一次停滞（0..20；0 ⇒ 关；默认 3）
          ledgerTransitionGate: false  # 台账写门（**由 dsh-team-link 读它自己的配置**；在此翻它不开那道门）
          caps:                        # 三族推回上限（各 0..6，三者都必填）
            pending: 1                 #   目标缺判据
            verify: 2                  #   有未验证改动
            advisor: 3                 #   未评审
          # 无 total 子键：诚实句占「三族之和 + 1」那一条（缺省 Σ=6 ⇒ 单回合硬上限 7 条）
```

> **`antiDrift` 的默认值按「打扰度」分档**（不是按机制）：只多说一句的默认**开**，会改变回合命运的默认**关**。
> **七个键都能由工具面 `anti_drift_config` 即时翻转**（写 base 配置面，**本会话下一次读取就生效，不需重启**），
> 但**工程模式下禁写**（避免在纪律最重的模式下被临时关掉机制）。★ **两处例外要知道**：① `caps` 的键名与取值走闭集校验，
> 非法 ⇒ 整体拒绝 + 零写入；② **`ledgerTransitionGate` 是"跨插件键"**——它由 `dsh-team-link` 读**它自己**的配置面，
> 在这里翻它对那道门**无效**（要开门得在 team-link 侧设）。

字段说明要点：

- **provider / model 成对解析**：会话覆盖 ⊕ 全局组 → 旧字段 `advisor.provider/model`（仅首轮，兼容迁移）→ 主代理路由；**禁止跨层混搭**。两组都没配则评审跟随当前会话模型。
- **runner（可选，逐行/逐组）**：**人话**——`dsh`（缺省，走当前会话模型）· `codex-cli`（在本机起 codex 子进程，**能写**）· **`codex-app-server`**（走平台自带 codex 的 app-server 传输面，**只读**，用于会诊/评审；**不消费 model/effort**）。`kind` 闭集 = 上述三者（批 33）。后两者是 codex 的两条通道；`codex-app-server` 走平台自带 `codex` provider 的 app-server 传输面，**只读定位**（无人值守对审批一律拒绝）⇒ 只用于 advisor / consult，eng_coder / escalate 配到它会被**具名拒绝**；该通道**不消费 `model`/`effort`**（模型由本机 Codex 配置决定，配了只会出现在展示标签并如实告知）。设计与边界见 [docs/2026-10-14-codex-app-server-design.md](docs/2026-10-14-codex-app-server-design.md)。
- **effort**：`off|low|medium|high|max`，映射 `reasoningEffort`；非法值忽略并警告；不传就用适配器默认。
- **timeoutMs**：单轮评审硬预算（绝对截止，到点即中止，不依赖数据块到达）；合法 1000~3600000。
- **includeProjectGuide**：评审是否注入 `AGENTS.md`（默认 false——评审独立于项目记忆，需求与验收标准请显式传 `documents=[...]`）。
- **engCoderEffort 默认 `medium`**：实现任务由任务书机械执行，普通推理档足以「按文档改文件」，再高只是白吞输出预算。
- **`engTokenTtlMs` / `consultTimeoutMs`** 也可从设置页改（两键都在 user 层白名单，优先级 user > base）。`consultTimeoutMs` 是**单个模型**的看门狗：超时只把该模型记成超时，不终止整轮会诊。
- **`ledger` 的三个键也可从设置页改**（批 36-补2）：`mode`（`standalone` / `off`）· `docPaths`（一行一个路径的多行文本域，最多 8 条）· `copyTemplate`（文本域 + 实时字数上限 500）。前端只做**提前提示**，**最终裁决永远是后端**——保存失败时页面原样显示后端返回的 `errors`（例如 `ledger.docPaths must be an array of at most 8 non-empty strings`），不翻译成另一套码。

### 会话级覆盖（`advisor_config` 工具）

```
advisor_config request={"action":"get"}
advisor_config request={"action":"set","path":"round1.effort","value":"low"}
advisor_config request={"action":"reset","path":"convergence"}
```

会话覆盖优先于全局组配置（字段级合并），会话销毁即失效；非法输入直接返回错误且不改动现有覆盖。

**从旧版升级**：旧字段 `advisor.provider / model / timeoutMs` **只映射首轮组**；收敛轮不会沿用它——没配 `advisor.convergence` 时收敛轮回落主代理路由（属正常回落，不是错误）。建议显式配两组：首轮旗舰保质量，收敛轮快档提速。

---

## 预设：新会话一键进工程模式（可选）

[`preset/thincoder-eng/`](./preset/thincoder-eng/) 让新会话**从第一句起就是工程模式**（架构师角色 + 门禁全开）。

```bash
mkdir -p ~/.dsh/.agent-presets/thincoder-eng
cp preset/thincoder-eng/* ~/.dsh/.agent-presets/thincoder-eng/
```

> **preset 源文件改过之后要重新同步**（本仓库是单一事实源，部署副本不会自动跟随），且**新会话**才生效。插件靠 `agent/session-start` 识别预设 id 自动进工程模式——预设本身不重复装配插件。

---

## 架构与设计取舍

```mermaid
flowchart TD
  subgraph HOST["host 侧（lib/*.mjs）"]
    AD["advisor 评审"]
    EN["eng 门禁 + eng_coder"]
    ES["escalate"]
    CO["consult"]
    API["设置页 config API"]
    WR["tools/pre-execute 写门禁"]
  end
  subgraph CLIENT["client 侧（手写 CJS，免构建）"]
    UI["设置面板「Thincoder」页"]
  end
  HOST --- CLIENT
  AD --> LLM["ctx.llm.stream"]
  EN --> SUB["ctx.subagents.start"]
  ES --> SUB
  CO --> SUB
  JOB["ctx.jobs（长任务后台化）"] -.-> EN
  JOB -.-> ES
  JOB -.-> CO
  style HOST fill:#f5f8ff,stroke:#48f
  style CLIENT fill:#f5fff5,stroke:#0a0
```

- **host + client 双层，零 TypeScript、零打包**（继承上游的零依赖哲学）。
- **零 bare import**：插件经 junction 安装后 Node 会 realpath 化，向上解析不到宿主的包——所以工具定义是手工构造的，插件契约只依赖 `export name / inject / apply`。
- **advisor 自己管工具循环**：每轮替换 system prompt、只给只读工具（read / glob / grep）；LLM 调用带**绝对截止定时器 + 数据块级看门狗**双保险（DSH 的调用参数没有 per-request 超时字段，这是移植侧的替代机制）。
- **写门禁**用 `tools/pre-execute` 的 waterfall 拦截；**不拦间接写**（shell 等）——那与上游同款取舍，靠流程纪律。

## 与上游 thincoder 的差异

> **两类差异要分清**：「本仓有意偏离」（移植时的设计决定）与「上游改了而本仓没跟」（滞后 = 欠账）。**混在一起看会掩盖后者。**
>
> **★ 本节是摘要，不是全量**：下面列 **5 条有意偏离 + 1 条已知滞后**；**权威全量**在两份设计档的「上游偏离表」里（**六列格式**，共约 **19 行**，含只属本仓自纠的条目）——[`docs/2026-09-15-consult-delivery-design.md`](./docs/2026-09-15-consult-delivery-design.md) §10 与 [`docs/2026-09-15-config-surface-design.md`](./docs/2026-09-15-config-surface-design.md) §10。**判据**：偏离表是**唯一**记录「本仓行为 / 上游行为 + 坐标 / 方向 / 理由 / 复检条件 / 锚」的地方。

**有意偏离（移植决定）**：

1. **LLM 调用超时**：上游有 per-request 超时；DSH 无此字段 ⇒ 移植版用数据块级看门狗（90s）+ 3 次重试替代，挂死的调用最终转为有界可诊断错误。
2. **子代理宿主**：上游 spawn 独立 CLI 进程；移植版用 DSH 进程内的 subagents。
3. **eng 会话状态**：内存态为主 + `session-state.json` 镜像（跨重启恢复，7 天 TTL，只填空槽）；删文件即回纯内存行为。
4. **design token 格式**：上游是裸 `uuid:expiresAt`；本插件曾多一条签名腿与密钥链，后来按威胁模型复核**整体删除**并与之对齐，另加**文档集指纹门控续期**（上游无此机制）。
5. **预设入口**：DSH 特有——工程模式的新会话一键入口用 agent preset 实现（运行时状态机装不进静态预设）。

**已知滞后（已补偿）**：本仓在 consult 协议上曾落后上游六天（上游以 digest 自动注入退役了 `consult_check`，而本仓抄的是改造前的版本且从未记录这次分叉）。⇒ 教训：**移植是抄一个时间点，而源会继续走**——移植物必须记下被抄的坐标。

---

## 已知未决（诚实清单）

**这一节存在，是因为这个项目相信「把没做完的事写出来」比「装作做完了」更值钱。**

| 项 | 现状 |
|---|---|
| **一个极少见的测试偶发** | 全量测试连跑 80 轮里有 1 轮红、**具体是哪一条还没抓到**（当时的脚本只记了数量没记名字）。已保留它为「未关闭」，并保留发布门对它的复跑兜底；复现手段已就位 |
| **codex-cli 会诊席经常缺席** | 该模型的子进程偶发非零退出，会诊通常按 3/4 交付（不影响结论，digest 会如实标出失败数） |
| **长任务的两个截止键容易配错** | 见上文「最容易被配错的一件事」——文档已写明，但**配置本身没有护栏**（配错只是慢，不会坏） |
| ~~**平台触点还没有系统扫**~~ **（2026-09-29 闭环）** | DSH 0.1.7 已知的三处断裂（工具结果的消息形状 · 后台派发的 owner 参数 · `settings.yaml` 改名打断 home 兜底探测）当年**都是人工撞出来的**，本行原建议「单列一批，把全部平台触点对着新旧两版做一次 diff」。**这笔欠账已经还了**：**九条平台触点常设锁**（单一事实源 [`lib/contract-baseline.mjs`](./lib/contract-baseline.mjs)；批 26 建档 → 批 28 收口 → 批 31 用它对 **0.2.0-rc.1 / 0.2.0-rc.2** 做了完整对照复核）把「全部门面」变成**一次调用可查**（只读工具 `contractWatch`，九条逐条给 `true|false|unknown` + evidence）；矩阵与批次脉络见 [`docs/dsh017-program-closeout.md`](./docs/dsh017-program-closeout.md) §二。**残余**：锁只覆盖**已知**九条触点，全新的平台面仍可能漏网——所以契约换版的标准动作是「先跑 `contractWatch`，任一条转红再开新批」 |
| **平台写盘层对消息 `content` 槽「有则检查、无则放过」** | 上游（`deepseek-ai/deepseek-harness`）**写盘路径**上的 `assertContent`（`packages/session/session-format-v3-to-v4/src/retired-syntax.ts:11`）只写 `if (Array.isArray(content)) …`、**没有 else** ⇒ 非数组**静默穿过**；而**读取/播种层**的 `assertMessageEventShape`（`packages/core/session/src/index.ts:356`）却硬性要求 `Array.isArray(content)`。这条**两侧不对称**的后果：插件把 `content` 写成字符串时，插件侧**零报错**、消息**照常落盘**、容器级体检（zstd 帧 / JSON 行）**全绿**——直到用户**打开那个会话**才炸，且**无法回放**。**2026-10-16 实测**：全库 1686 个会话中 4 个中招（全部源自本插件旧版的注入）。**本仓已自行规避**：注入一律走 `producerContent()`（`lib/anti-drift.mjs`），回归锁在 `test/anti-drift.test.mjs` 的 A-8 块。**上游反馈通道**：该仓 **Issues 与 PR 均已关闭**，唯一官方渠道是 **GitHub Discussions**（`CONTRIBUTING.zh.md` 点名此渠道；发帖需 GitHub 账号），社区实际约定为 **General 板块 + `[Bug]` 标题前缀**。报告草稿已备（含两处 `file:line` 与复现步骤），**尚未提交** |

**2026-09-28 收口一条（原先登记在本节）**：**`job_output` 读不回后台作业全文**——2026-09-25 实测四次报 `Cannot read properties of undefined (reading 'output')`（含平台自己产的作业），当时的定性「平台侧缺陷、本仓不可修」**已被推翻**。真因是**第三方插件**：本机 profile 装的 `@dsh-external/dsh-task-status`（上游 `vlln/dsh-task-status`，未适配 0.1.7）在 `apply()` 里给 `ctx.jobs.read` 打镜像补丁，按 0.1.6 契约重写信封 `{ text, snapshot }`，丢弃 0.1.7 的 `{ chunks, lossy, result?, job }` ⇒ 下游读 `read.job.output` 即崩（同一链路也解释 promoted `pwsh` 的 `reading 'filter'`）。**已卸载该插件；卸载后 `job_output` 与 promoted 读取立刻恢复**（同机同日实测，未重启、未改平台包）。**⇒ 平台侧无缺陷**；批 26 的落盘兜底保留为**附加保险**。真因取证（零重启热探针读数）、逐机制绕行与上游同款告警见 [`docs/job-output-fallback.md`](./docs/job-output-fallback.md) §0。

更细的技术台账（内部批号、逐条残差、发布门判据）见 [`CHANGELOG.md`](./CHANGELOG.md) 与 [`docs/`](./docs/)、[`METHODOLOGY.md`](./METHODOLOGY.md)。

---

## 变更记录

完整变更历史见 [CHANGELOG.md](./CHANGELOG.md)。近期版本：

| 版本 | 日期 | 变更（人话） |
|---|---|---|
| **v0.32.0** | 2026-10-18 | **看板看得懂了 + 设置页说人话了**。① 任务带 **`P10`/`P5`/`P2` 优先级徽标**（红/琥珀/灰，**0 不显示**）· ② 顶部**五态环形图**（待办·已接手·在做·卡住·完成，纯手绘 SVG 零依赖）· ③ 看板**默认展开** · ④ 卡片改**毛玻璃**（底色 `color-mix` 派生，深浅色主题自动适配）· ⑤ 设置页重构成 **常用 / 会诊 / 任务台账 / 高级 四个 tab**，21 个字段全部改成「**人话主标签** + 灰字技术键 + 一句它影响什么」· ⑥ 时间字段改成 `[数字][分钟▾]` 两段式，**上限写在下方**。★ 另修一个 P0：DSH 0.2.1 移除了 `ctx.subagents.start` ⇒ `advisor`/`eng_coder`/`consult`/`escalate` 四条线待迁移（已记账）。 |
| **v0.31.0** | 2026-10-14 | **两个新交付面 + 四次真机热修**。① **给 codex 多开一条通道**：以前 codex 只有「在本机起 `codex exec` 子进程」一条路——那条路在有些机器上一遇到「要执行命令」就挂（Windows 沙箱助手起不来 + 联网子系统超时）。现在可以改走**平台自带的 codex 支持**（官方 app-server 协议），用于**只读类**任务（会诊 / 评审）；两条通道并存，用哪条写在配置里，一眼可辨、随时可退。② **长任务防漂（anti-drift）**：「别忘了目标、改完要验证、交付前要评审」这些话以前只躺在系统提示词里——它一直在那儿，但**不会在你要收尾的那一刻拦你**。现在立目标前先写「怎么算完成」（写不出就**建不起目标**）、宣告完成要拿得出**跑过的证据**、改完产品代码没验证就想收尾**回合会被推回**。③ **四次热修（全部源自真机事故）**：装配面 `inject` 白名单缺陷（**插件装上了、但 11 个工具全不可用**）· 注入消息的 source 归属被 session format v4 拒绝（**整个回合报错**，且其后事件全不落盘）· 标记面两个「调了但没 import」（落章域**从未生效**）· **注入消息的 content 槽被写成裸字符串**（插件**零报错**、消息照常落盘，但该会话**再也打不开**：界面空白、发消息无反应；全库 1686 个会话里 4 个中招，已逐个外科修复）。**改 `lib/**` ⇒ 重启 DSH 后生效** |
| **v0.30.1** | 2026-10-09 | **修「工程模式实施通道派发即死」（`D-62`）**：`eng_coder` 把子代理派到**用户早已切换掉的旧模型通道**上（插件拿「建会话那一刻的模型」当「会话现在用的模型」，并**显式覆写**给子代理；平台自己的规则是「会话当前路由 = 最近一次请求头，创建期选项只在首次请求之前兜底」）⇒ 该通道额度已尽时首次请求即 429、约 19 秒死，且报告面只有 `eng_coder ended: error` + 空 partial。**修法**：新增**活动路由**单一事实源（`session.requestHeader().config`，**整对语义**，回落创建期；`maxTokens` 仍取创建期，平台同款）· 两个 spawn 点**不再覆写** `provider/model` · effort / advisor 兜底路由 / 硬停指纹 / 设置页**四处同源** · **失败取证**（子会话 `turn/end.reason` + 本次派发路由 + 崩在哪一步 + 异常栈前 3 行 + `console.warn`）。**改 `lib/**` ⇒ 重启 DSH 后生效** |
| **v0.30.0** | 2026-09-30 | **抬平台基线到 DSH `0.2.0-rc.2`**（先按 `0.2.0-rc.1` 逐触点复核；nightly 自动升到 rc.2 后复跑同一套复核，并对两个 `app.asar` 做 sha256 全量对照证明**运行时面逐字节未变**）+ **真机派发冒烟**（`escalate-dsh-1` 全链路走通、报告落盘并与 `job_output` 读回一致） · **版本哨兵扩到四源**（原来三源在本机全落空 ⇒ 对真实换版零反应；新增「问平台服务 `pluginManager` 要平台组合包版本」，并**钉死名单**防用户侧同前缀包假告警）· **支持门槛交给平台执行**（组合包声明 `peerDependencies @deepseek-ai/dsh`，低版平台由平台自己的组合兼容闸门在装配前拦下；旧 DSH 请改 [v0.29.11](https://github.com/shenhuanageshei/dsh-thincoder-suite/releases/tag/v0.29.11)）· 修 D-61（观测行读 `finish.usage`，而平台把用量发成**独立 chunk** ⇒ 恒打 `usage=none`）· `contractWatch` 补上工具描述里一直承诺的 **`versionEvidence`**（返回体 4 键 → 5 键），且**每个源失败都带一行可读原因**（读不到版本时不再是「看不见为什么」）。**改 `lib/**` ⇒ 重启 DSH 后生效** |
| **v0.29.11** | 2026-09-28 | **批 30：把两条空转的防线真接上** —— D-55 工具面按 **Agent scope** 读名域（绝不猜名；`run_code` 残余风险如实标注）· D-56 看门狗改接 `localAgent.session.seq` + `ctx` 事件面（复用既有轮询、按子 id 过滤、`off()` 三路径）· D-57 落盘**前缀截断被拒** · D-58/D-59/D-60 会诊三连（注入面消毒 + 失败带真因 + 池预检 + **只读声明由模型面裁定**）
| **v0.29.10** | 2026-09-27 | **批 29 收尾**：D-53 **真机取证收口**（实测：本部署 run 无事件面、工具面无清单访问器 ⇒ 两条机制走**诚实降级**；新登记 **D-55/D-56/D-57**）· 留档搬进**可读回执区**（🔴 空搬运提前关闸已修）· §2.7 测试健壮性四项 · §2.9 六条 🔵
| **v0.29.9** | 2026-09-26 | **批 29 收尾**：D-53 的**一次性真机留档**（首派即取证：看门狗接线首次结果 + 工具面首次未生效，各一条裸 warn、只一次、不进返回文本）· `maxFiles` 与 `maxAgeDays` **同向**收紧（0 被拒、小数仍生效）· 审计 F1/F2 收敛（断言决定性 + 交付正文零污染）
| **v0.29.8** | 2026-09-26 | **把门禁变可信**：子代理**工具面禁执行**（只下发与平台 `view().restrictableNames` 求交后的名字；保留名 `run_code` 一命名即抛错）· **静默看门狗**（5 分钟无事件即掐，不再白等 60 分钟；首次真实事件前不武装 ⇒ 零事件不误杀）· `stages[].check` 语义正名「**宿主验收清单**」· **阶段门恒假阳性**修成真谓词（≥3 列按名定位、中英列名状态词，保留「无表 ⇒ UNDECLARED」）· `T-AP4b` 偶发红改假时钟消除时序依赖（N=20 零红）· 会诊只读白名单加对位锁 · 七条 🔵 收干
| **v0.29.7** | 2026-09-26 | **对外收口**：**上游报告包**（三条平台问题附只读复现脚本：`job_output` 读法缺陷 · 沙箱拒子进程应报错而非挂起 · advisor 三形态；**2026-09-28 更正：其中「`job_output` 读法缺陷」一条已撤回——真因是第三方插件，见 [`docs/job-output-fallback.md`](./docs/job-output-fallback.md) §0**）· **版本哨兵**（装配期读平台版本〔三源链 + 来源 evidence〕，不一致**响亮告警但不阻断**）· **只读巡检工具** `contractWatch`（九条触点一次看全，三态含 `unknown`）· **九条谓词单源**（触点档删净 231 行谓词体改 import）· **结项说明**。附批 26 锁 #7 注册面基线 7→8 的同批上调
| **v0.29.6** | 2026-09-26 | **收拾干净**：作业落盘目录加**清扫/轮转**（只认本插件四类 kind，平台 `pwsh-*` 永不触碰；天数轴 + 条数轴双上限；索引重写**零伪造**）· `cwdHint` 接上最后一处（不再拿 `process.cwd()` 猜基座）· 宿主验收执行面 kill 语义收窄 · 非法 `pathForm` 变可见。附 **D-49**（清扫面「声明 ≠ 实际」批内已修：改用 `writeFileAtomic`）
| **v0.29.5** | 2026-09-26 | **把报告拿回来**：后台作业全文落在 `$DSH_HOME/.thincoder/jobs/<jobId>.txt`（含 `index.jsonl` 记来源通道），不再依赖平台那条坏掉的 `job_output` 读取口（环境实验已排除本机包错配；**2026-09-28 更正：当时判作「平台自身缺陷」有误，真因是第三方插件的 `jobs.read` 镜像补丁，见 [`docs/job-output-fallback.md`](./docs/job-output-fallback.md) §0**）；同批**把验证门归位**——dsh 子代理不再自己跑 check（沙箱下子进程会挂死），改由宿主执行并回执，`checkMode` 可显式覆盖。附九条平台触点常设锁 + 冻结门禁相对路径 fail-open 修复 |
| **v0.29.4** | 2026-09-26 | 把**后台作业的输出**按 DSH 0.1.7 的新契约生产：0.1.7 的模型可见正文改由**输出环**承载（`spec.run(handle)` + `handle.append`），`settle` 只读 `job.result`（`job.output` 字段已不存在），而插件仍按 0.1.6 的「无参 `run` + `outcome.output`」写 ⇒ **报告正文到不了模型**。同批修掉**文档集指纹拿 `process.cwd()` 猜基座**——相对路径的文档一律读不到 ⇒ 评审合格证的「到期续期」与「文档已变更」两道闸双双失效。新增 `lib/job-outcome.mjs` **单点收口** + 5 条回归腿（含全量静态锁）；交付评审 2 轮，第 2 轮 PASS |
| **v0.29.3** | 2026-09-25 | **修掉让插件在 DSH 0.1.7 上整个用不了的两处平台契约变更**：0.1.7 把「工具结果」从 user 消息里的一个块换成了独立的 tool 角色消息，插件仍按旧形状发 ⇒ 评审跑到第二轮（第一次带上工具结果那一轮）就被平台拒收；后台派发的 `owner` 也从「传对象」变成「传 id」。同版还带上 `home` 兜底探测（`settings.yaml` 改名）的修复。**改 `lib/**` ⇒ 重启 DSH 生效** |
| **v0.29.2** | 2026-09-21 | 隐私面收口：代码与测试里的真实 provider / 模型标识换成中性示例值；npm 打包加白名单（此前 `npm pack` 会把 `docs/` 与 `test/` 一起打进去）。**零行为改动** |
| **v0.29.1** | 2026-09-21 | 设置页的配置 API 补上宿主的信任栅栏——此前**无 token 也能读到完整配置**（含本地绝对路径），现在跟 DSH 其它路由一样先鉴权 |
| **v0.29.0** | 2026-09-21 | 长任务（`eng_coder` / `escalate` 的 dsh 子代理路径）**默认走后台**，不再撞平台的 600 秒墙钟；同批暴露并修掉了它牵出的根因链 |
| **v0.28.0** | 2026-09-17 | **写文件更抗折腾，失败不再静默**：遇到杀软/索引器短暂占用文件时，写入会**自动重试**而不是直接失败；真的失败时会留下可检索的告警。顺带修掉设置页「恢复默认」**失败时仍报成功**的问题 |
| **v0.27.0** | 2026-09-17 | **推理档回落的根修**：`off` 是「关闭开关」不是「力度档」——以前要「低推理」可能被静默换成「推理全关」，现在**永远不会**；显式要求关推理而模型做不到时，会**告诉你**并交还提供方默认 |
| **v0.26.0** | 2026-09-17 | 测试面加固：CHANGELOG 计数行的绑定区域内，令牌取值必须一致（纯测试改动，无需重启） |
| **v0.25.0** | 2026-09-17 | 文档形状谓词扩展：同一事实在不同文档里必须**取值相同**；并修了三处谓词自身的假红（纯测试改动） |
| **v0.24.0** | 2026-09-16 | 文档形状谓词上线：**计数不追列表 / 同一事实两处不同值 / 引用不存在 / 该有锚的 AC 没锚**——从「靠人眼」变成「机器自己红」（纯测试改动） |
| **v0.23.0** | 2026-09-16 | 配置面与描述面同步：`engCoderEffort` 默认值 `low` → `medium`；白名单散文立常设谓词；清掉十处悬空引用 |
| **v0.22.0** | 2026-09-15 | 会诊接上平台 job 投递（完成时自动通知），退役轮询工具；纪要默认落盘；未消化的会诊会拦住下次发起 |
| **v0.21.0** | 2026-09-15 | 七条老登记逐条回盘核实——**三条描述是错的、两条范围比登记大得多、一条比登记更便宜** |
| **v0.20.0** | 2026-09-15 | 把一处「逐字节保存整个函数体」的测试锁收窄成语义锁（改个注释不再要重刷 79 行） |
| **v0.19.0** | 2026-09-13 | 文档纪律成文：D1–D7 从「被引用 22 次的未定义编号」变成可读的七条法律 |

> 更早的版本（v0.1–v0.18）与其内部批号、逐条残差、机械判据，见 [CHANGELOG.md](./CHANGELOG.md)。

## License

MIT —— 见 [LICENSE](./LICENSE)。基于 [thincoder](https://gitee.com/shanghai-xinbo/thincoder)（[thincoder.com](https://thincoder.com/)）移植，向上游贡献者致谢。
