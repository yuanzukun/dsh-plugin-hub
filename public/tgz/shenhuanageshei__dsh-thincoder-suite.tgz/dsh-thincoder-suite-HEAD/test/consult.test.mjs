// consult.test.mjs — 会诊机制单元测试（登记表 D-28 回归钉死，2026-09-09）。
// 覆盖：
// ① D-28 回归：调用方 exec.signal abort 不得杀死子代理——PTC 模式下 exec.signal 是
//    run_code 程序的 run-scoped 控制器（dsh-tools/lib/types/ptc.js:375 注入、:532 在程序
//    settle 的 finally 里 abort），而会诊是「本回合 start、后续回合 check」的跨回合协议；
//    生产实证（2026-09-08/09，lore 会话）：21 次尝试里 20 次子代理在 1~3 秒内被
//    child.cancel({kind:'parent'}) 杀掉且从未发出模型请求。
// ② consult_stop 早停仍中止在跑子代理（不因 ① 的控制器自持而失效）。
// ③ consultTimeoutMs 看门狗仍有界（泄漏兜底不因 ① 而失效）。
// ④ cleanupConsultSessions（session 销毁）中止全部在跑子代理。
// ⑤ selectConsultModels 选择器语义（provider:model / 裸 provider / 裸 model / 未知）。
// ⑥ **批 30 / US-5（D-58 · A30-8 / A30-9）**：注入面消毒（裸会话引用形态被断开、带路径形态原样）+ 失败
//    可诊断（无 diagnostic 时兜底读子会话落盘 `turn/end.reason`；读不到 ⇒ 如实声明「子代理面不可诊断」）
//    + codex 行带出 `env.diagnostics`（exit code / stderr）；**US-7（D-59 · A30-11）**：池行前置可用性预检——
//    模型不在目录 / effort 不被接受 ⇒ 该行**不派发**并点名「因配置未派发」+ 原因（判据 = 零 codex exec 调用）；
//    目录不可得 ⇒ fail-open 不拦 + 响亮标注（诚实降级）；**US-6（D30-6 · A30-10 / A30-12）**：权限面判据
//    读**模型请求头**（`request/header`，不得以「restrict 未抛错」代替）+ **会诊产物**（派发回复的 detail 段 ·
//    settle 后的 digest）带「本部署无法保证只读」如实声明与**弱证 / 模型面**证据口径（含一条跨档防漂移锁）。
//    ★ 全部**并入既有块**（台账 §三零改：零新增顶层 `test(`）。
// 假 subagents 忠实复刻 dsh-subagent-in-process-driver 的取消语义：request.signal abort →
// 子代理被取消（stopReason "aborted"）；否则 delayMs 后以 reply 完成。零真实 LLM 调用。
process.env.DSH_HOME = ""
import { test } from "node:test"
import assert from "node:assert/strict"
import { appendFileSync, existsSync, mkdirSync, mkdtempSync, readFileSync, writeFileSync } from "node:fs"
import { tmpdir } from "node:os"
import { dirname, join, resolve } from "node:path"
import { fileURLToPath } from "node:url"
import { EventEmitter } from "node:events"
// 批 30 / US-5（D-58 · 锚 A30-9）：多帧 zstd 会话档的自造夹具（逐帧压缩 + 顺序拼接，真机同形）。
import * as nodeZlib from "node:zlib"
import {
  startConsultSession, stopConsultSession, cleanupConsultSessions, selectConsultModels,
  composeConsultDigest, readConsultLedger, consultDigestionGate, consultLedgerOrphans,
  undigestedConsultSessions, CONSULT_DIGEST_REPLY_CAP,
  // 批 30 / US-5：注入面消毒（A30-8）与落盘日志定位 slug（A30-9 的证据通道）
  sanitizeInjectedText, projectKeySlug,
  // 批 41（台账 t-6）：只读预设**内容**闸门的受测入口（T-39…T-41 直接驱动它，不手搓等价物）
  resolveConsultReadonlyRoute,
} from "../lib/consult.mjs"
// 批 41（台账 t-6 / 设计档 §五 FR-1）：发货模块名常量的单一事实源（T-42 的静态同步锁对位它）
// + 纯函数层组合判据（T-41⑦ 直接驱动它：rows==null 降级分支 —— 审计 #4b —— 与非数组「形态不符」降级分支 —— 修复轮 #5）
import { CONSULT_READONLY_MODULES, evaluatePresetDrift } from "../lib/preset-readonly-guard.mjs"
// 批 30 / US-6（D30-6 · 锚 A30-10/A30-12）：**模型面**证据的捕获与成文（eng.mjs 侧实现，
// 读取器复用 consult.mjs 的补导出——设计 §2.6「不得新建模块」）
import { readChildModelToolSurface, renderModelSurfaceEvidence } from "../lib/eng.mjs"
import { sessionState, dropSession } from "../lib/state.mjs"
// 批 37 / 设计档 §二十（S1）：子代理派发单一入口——T-27…T-30 四条腿的受测对象
import { dispatchSubagent, subagentDispatchAvailable } from "../lib/subagent-dispatch.mjs"

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function waitFor(fn, timeoutMs = 2000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (fn()) return
    await sleep(5)
  }
  throw new Error("waitFor timeout")
}

/** 假 subagents：signal abort → 取消（对齐 in-process driver），否则 delayMs 后完成。 */
function makeSubagents({ delayMs = 20, reply = "reply-ok" } = {}) {
  const started = []
  const aborts = []
  return {
    started,
    aborts,
    async start(kind, req) {
      started.push({ kind, req })
      let cancelled = false
      let onAbort = null
      const result = new Promise((resolve) => {
        onAbort = () => { cancelled = true; aborts.push(Date.now()); resolve({ output: [], stopReason: "aborted" }) }
        if (req.signal) {
          if (req.signal.aborted) onAbort()
          else req.signal.addEventListener("abort", onAbort, { once: true })
        }
        const t = setTimeout(() => {
          if (!cancelled) resolve({ output: [{ type: "text", text: reply }], stopReason: "completed" })
        }, delayMs)
        t.unref?.()
      })
      return {
        result,
        dispose: async () => { try { req.signal?.removeEventListener("abort", onAbort) } catch { /* noop */ } },
      }
    },
  }
}

let seq = 0
/**
 * 假 jobs 服务（批 15 / D15-1：派发**必须**走平台 job）。平台契约（`dsh-jobs` 的 `JobStart`）：
 * `start(spec)` 调 `spec.run()` 取 `{cancel, done}`，返回 branded string `<kind>-N`。
 */
function makeJobs() {
  const specs = []
  return {
    specs,
    jobs: {
      start(spec) {
        const hooks = spec.run()
        specs.push({ spec, hooks })
        return "consult-" + specs.length
      },
    },
  }
}

/** deps stub：ctx.subagents 假服务 + 假 jobs 服务 + 会话级 state（真实 sessionState 形状）。
 *  `services`：额外宿主服务（批 39 的 `agentPresets` 假注册表就由此注入；缺省 ⇒ 一律 null，
 *  与「服务缺席」同义——这正是 T-29/T-38 的负向夹具）。 */
function makeDeps({ subagents, signal, config = {}, noJobs = false, services = null } = {}) {
  const sessionId = "consult-test-" + (++seq)
  const state = sessionState(sessionId)
  const j = makeJobs()
  // 批 15：纪要档与台账都写盘 ⇒ 落点必须在临时目录（不得污染仓库 docs/ 与真实 DSH_HOME）
  const cwd = mkdtempSync(join(tmpdir(), "consult-cwd-"))
  const dshHome = mkdtempSync(join(tmpdir(), "consult-home-"))
  return {
    sessionId,
    state,
    jobs: j,
    cwd,
    dshHome,
    deps: {
      ctx: {
        subagents,
        get: (svc) => {
          if (svc === "jobs" && !noJobs) return j.jobs
          return services && Object.hasOwn(services, svc) ? services[svc] : null
        },
      },
      agent: {
        session: { id: sessionId, header: { cwd }, deriveMessages: () => [] },
        options: { provider: "p", model: "m" },
      },
      config: { consultModels: [{ provider: "p", model: "m" }], ...config },
      state,
      signal,
      persona: undefined,
      dshHome,
    },
  }
}

const cleanup = (sessionId, state) => { cleanupConsultSessions(state); dropSession(sessionId, (s) => cleanupConsultSessions(s)) }

/**
 * 批 15（FR-2）：`checkConsultSession` 与其 `waiters` 机制已随投递改造退役 ⇒
 * **生产消费面 = digest**（`composeConsultDigest` 的产物，由 run 体在 job complete 前合成）。
 * 测试读的仍是生产站点真正合成的载荷（不手搓等价物——批 6 修复轮审计 🔴 #1 的纪律）。
 */
const sessOf = (state, id) => state.consultSessions.get(String(id))
async function waitDigest(session, timeoutMs = 3000) {
  await waitFor(() => session.digest !== null, timeoutMs)
  return session.digest
}

test("D-28 回归：调用方 exec.signal abort 不得杀死 consult 子代理", async () => {
  const sub = makeSubagents({ delayMs: 30, reply: "keep-it" })
  const outer = new AbortController()
  const { deps, state, sessionId } = makeDeps({ subagents: sub, signal: outer.signal })

  const s = await startConsultSession(deps, "问题", undefined)
  assert.deepEqual(s.models, ["p:m"])
  assert.equal(s.jobId, "consult-1", "批 15（D15-1）：派发走平台 job")
  await waitFor(() => sub.started.length === 1)

  const childSignal = sub.started[0].req.signal
  assert.ok(childSignal, "子代理必须拿到插件自持的 signal")
  outer.abort()                                   // 模拟 PTC run_code 程序 settle（ptc.js:532）
  await sleep(10)

  assert.equal(childSignal.aborted, false, "子代理信号必须与调用方程序解耦")
  assert.equal(sub.aborts.length, 0, "调用方 abort 不得取消子代理")

  const digest = await waitDigest(sessOf(state, s.id))
  assert.match(digest.split("\n")[0], /^\[consult #\d+ finished — 1 of 1 replied \(0 failed\)\]$/)
  assert.ok(digest.includes("keep-it"), "真实回复经生产消费面（digest）可见")
  cleanup(sessionId, state)
})

test("D-28：consult_stop 早停仍中止在跑子代理", async () => {
  const sub = makeSubagents({ delayMs: 5000 })
  const { deps, state, sessionId } = makeDeps({ subagents: sub })

  const s = await startConsultSession(deps, "问题", undefined)
  await waitFor(() => sub.started.length === 1)

  const stopped = stopConsultSession(state, s.id, 1, deps)
  assert.equal(stopped.abandoned, 1)
  await waitFor(() => sub.aborts.length === 1)

  // ★ 批 15（D15-3 / AC-20，**有意偏离上游 T-R17c**）：stop 会话照产**墓碑 digest**——
  // 退役轮询面后 digest 是唯一消费通道，stop 无 digest = 已收到的回复整批蒸发。
  const sess = sessOf(state, s.id)
  const digest = await waitDigest(sess)
  assert.match(digest.split("\n")[0], /^\[consult #\d+ stopped — 0 of 1 replied \(0 failed, 1 stopped\) before stop\]$/)
  assert.ok(digest.includes("abort(stop@agent: stop requested)"),
    "stop 死亡行经生产消费面（digest）可见：" + digest.split("\n").slice(-3).join(" / "))
  assert.equal(sess.received, 0)
  assert.equal(sess.requiresReport, false, "墓碑 ⇒ requiresReport=false（§7 取值规则 ③）")
  cleanup(sessionId, state)
})

test("D-28：consultTimeoutMs 看门狗仍有界中止（失败回复带 timed out）", async () => {
  const sub = makeSubagents({ delayMs: 5000 })
  const { deps, state, sessionId } = makeDeps({ subagents: sub, config: { consultTimeoutMs: 25 } })

  const s = await startConsultSession(deps, "问题", undefined)
  const digest = await waitDigest(sessOf(state, s.id))

  assert.ok(digest.includes("timed out after 1s"), "亚秒预算不得渲染成 0s（advisor 🔵#5）")
  assert.match(digest.split("\n")[1], /^effective: 0 of 1 \(1 failed · 0 without content\)$/, "全失败仍照投 + 有效数=0")
  assert.equal(sub.aborts.length, 1)
  cleanup(sessionId, state)
})

test("D-28 跟进：调用方（已 abort 的）信号不得杀子代理，digest 仍读到真实回复", async () => {
  const sub = makeSubagents({ delayMs: 40, reply: "late-ok" })
  const outer = new AbortController()
  outer.abort() // 调用方程序已 settle（PTC run-scoped 信号）
  const { deps, state, sessionId } = makeDeps({ subagents: sub, signal: outer.signal })

  const s = await startConsultSession(deps, "问题", undefined)
  await waitFor(() => sub.started.length === 1)

  const digest = await waitDigest(sessOf(state, s.id))
  assert.equal(sub.aborts.length, 0, "调用方信号不得杀子代理（advisor 🟡#1）")
  assert.match(digest, /^late-ok/m, "子代理仍在跑 → digest 里仍是真实回复")
  cleanup(sessionId, state)
})

test("D-28：cleanupConsultSessions（session 销毁）中止全部在跑子代理", async () => {
  const sub = makeSubagents({ delayMs: 5000 })
  const { deps, state, sessionId } = makeDeps({
    subagents: sub,
    config: { consultModels: [{ provider: "p", model: "m" }, { provider: "p", model: "n" }] },
  })

  const s = await startConsultSession(deps, "问题", undefined)
  await waitFor(() => sub.started.length === 2)
  const sess = sessOf(state, s.id)

  cleanupConsultSessions(state)
  await waitFor(() => sub.aborts.length === 2)
  assert.equal(state.consultSessions.size, 0)
  // R-9 / §9：dispose 面**不强行造墓碑投递**（digest 无从合成是既有登记例外）
  assert.equal(sess.digest, null, "销毁路径不合成 digest（R-9）")
  assert.equal(sess.disposed, true)
  dropSession(sessionId, (s) => cleanupConsultSessions(s))
})

// ═══════════════ 批 15 交付/消化面（AC-1…AC-26 的 T1 腿） ═══════════════
//
// ★ 为什么挤在既有用例里：批 15 的硬约束是**零新增测试档 + 零新增顶层 `test(`**
//（台账 §三零改 → T-LC2 逐档用例数必须与 fs 实测一致）⇒ 新增断言只能**并入既有块**。
// 下面是一组模块级 helper，由本档最后一个用例一次性跑完（每项都带它对应的 AC 号）。

/** 按 req.label 分派回复形态的假子代理（`ok` / `empty` / `fail` / `long` / `ctrl`）。 */
function makeSpecSubagents(pick) {
  return {
    async start(_kind, req) {
      const spec = pick(String(req.label ?? "")) ?? { kind: "ok", text: "reply" }
      if (spec.kind === "fail") return { result: Promise.reject(new Error(spec.text ?? "boom")), dispose: async () => { } }
      if (spec.kind === "empty") return { result: Promise.resolve({ output: [], stopReason: "completed" }), dispose: async () => { } }
      return {
        result: (async () => {
          await sleep(10)
          return { output: [{ type: "text", text: spec.text ?? "reply" }], stopReason: "completed" }
        })(),
        dispose: async () => { },
      }
    },
  }
}

const POOL4 = [
  { provider: "p", model: "a" }, { provider: "p", model: "b" },
  { provider: "p", model: "c" }, { provider: "p", model: "d" },
]

// ═══════════════ 批 15 修复轮：形状腿 · 描述面正向锁 · alreadySettled ═══════════════
//
// 独立分歧审计（子代理 80feea19）判定 AC-5 / AC-7(形状) / AC-16 / AC-25 为 partial、AC-20 的 `alreadySettled`
// 错误用例未测、US-12 无真实覆盖 ⇒ 本组把**可机检的那部分**补齐；**不可机检的那部分**（`goal`/`authorized`
// 两档的送达时判定 = 只有提示词承载、零机制）**如实降为 T3**，并同步设计档 §11.2 / §11.3。
// ★ 硬约束：**零新增测试档 · 零新增顶层 `test(`**（台账 §三零改）⇒ 全部并入既有块。

/** 仓库根（本档在 `test/` 下）——静态锁（描述面 / 纪律面）读源码字节用。 */
const PLUGIN_DIR = resolve(dirname(fileURLToPath(import.meta.url)), "..")

/**
 * 纪要形状谓词（**纯函数**，AC-7 的**形状腿** / 修复轮补腿）：
 * 「每条意见**恰一条处置**」的**形状前提** = 机制产出的纪要必须给**每一条回复恰一个编号槽位**
 * （`[N]`，且密排 `1..N`）——主代理的 §2 处置行逐一绑定这些槽位。
 * ★ 语义（每条处置是否正确、不采纳的理由是否成立）**仍只能人眼**（T3；R-41 不许超卖）。
 * @param {string} text 纪要全文
 * @param {number} expectedReplies 该会话的回复条数（`session.replies.length`）
 * @returns {string[]} 违规描述列表（空 = 合规）
 */
function minutesShapeViolations(text, expectedReplies) {
  const bad = []
  const t = String(text ?? "")
  for (const need of ["## §0 汇总", "## §1 原始层", "## §2 逐问裁定"]) {
    if (!t.includes(need)) bad.push("缺小节 " + need)
  }
  if (!t.includes("每条意见**恰一条处置**")) bad.push("§2 缺「每条意见恰一条处置」指令")
  if (!t.includes("不采纳（**必附理由**）")) bad.push("§2 缺「不采纳必附理由」")
  const nums = [...t.matchAll(/^\[(\d+)\] /gm)].map((m) => Number(m[1]))
  const sorted = [...nums].sort((a, b) => a - b)
  if (sorted.length !== expectedReplies || !sorted.every((n, i) => n === i + 1)) {
    bad.push("回复槽位不密不齐：实测 [" + nums.join(",") + "]，应恰为 1.." + expectedReplies)
  }
  return bad
}

/** AC-7(形状) · AC-16 · AC-20(alreadySettled) · AC-23 / US-12：修复轮补齐的可机检腿。 */
async function b15ShapeAndSurfaceChecks() {
  // —— ① AC-7 形状腿（T1）：**真实生产站点**产出的纪要 ⇒ 每条回复恰一个编号槽位 ——
  const sub = makeSpecSubagents((label) => {
    if (label.endsWith("p:a")) return { kind: "ok", text: "reply-from-a" }
    if (label.endsWith("p:b")) return { kind: "empty" }
    if (label.endsWith("p:c")) return { kind: "fail", text: "boom" }
    return { kind: "ok", text: "reply-from-d" }
  })
  const h = makeDeps({ subagents: sub, config: { consultModels: POOL4 } })
  const r = await startConsultSession(h.deps, "问题", undefined)
  await h.jobs.specs[0].hooks.done
  const s = sessOf(h.state, r.id)
  const minutesText = readFileSync(join(h.cwd, s.minutesPath), "utf8")
  assert.equal(s.replies.length, 4, "4 条回复（ok / 空 / 失败 / ok）全部进 replies（digest 的单一输入）")
  assert.deepEqual(minutesShapeViolations(minutesText, s.replies.length), [],
    "AC-7 形状腿：机制产的纪要给每条回复**恰一个**编号槽位（密排 1..N）——「处置行数 == 回复数」的形状前提")
  // 谓词自证（律 3：破坏被保护物 ⇒ 必红，不是恒真锁）
  const dropped = minutesText.replace(/^\[1\] [^\n]*\n/m, "")
  assert.notEqual(dropped, minutesText, "谓词自证前置：编号槽位行（`[N] …`）可定位")
  assert.ok(minutesShapeViolations(dropped, s.replies.length).length > 0, "谓词自证：抽掉一个槽位 ⇒ 必判违规")
  assert.ok(minutesShapeViolations(minutesText.replace(/^\[2\] /m, "[1] "), s.replies.length).length > 0,
    "谓词自证：槽位编号重复（不密）⇒ 必判违规")
  assert.ok(minutesShapeViolations(minutesText, s.replies.length + 1).length > 0,
    "谓词自证：回复数与槽位数不符 ⇒ 必判违规")
  cleanup(h.sessionId, h.state)

  // —— ② AC-16 正向锁（T2）+ 反向：新描述面含「自动投递 / 收到须汇报」 ——
  const idx = readFileSync(join(PLUGIN_DIR, "lib/index.mjs"), "utf8")
  const mainPrompt = readFileSync(join(PLUGIN_DIR, "lib/prompts/main.md"), "utf8")
  assert.ok(idx.includes("Delivery is AUTOMATIC"), "AC-16 正向：consult_start 描述面须声明**自动投递**")
  assert.ok(idx.includes("you ARE notified in-session"), "AC-16 正向：「你会被通知」的字面在场")
  assert.ok(idx.includes("STOP and report to the user"), "AC-16 正向：缺省「停下向用户汇报」在场")
  assert.ok(mainPrompt.includes("you are notified in-session when it settles"), "AC-16 正向：主提示词同款声明在场")
  assert.ok(mainPrompt.includes("STOP and report to the user"), "AC-16 正向：主提示词的缺省停在场")
  // AC-16 反向（逐行）：批 14 那句「没有通知」只准作为**注释留痕**存在，不得回到描述面（字符串字面）
  const retired = idx.split("\n").filter((l) => l.includes("There is NO completion notification"))
  assert.ok(retired.length >= 1, "反向锁自证：该句仍须作为历史留痕留在注释里（否则反向断言是恒真）")
  for (const l of retired) {
    assert.ok(/^\s*\/\//.test(l), "AC-16 反向：那句只准住注释，不得出现在描述面：" + l.trim().slice(0, 60))
  }

  // —— ②b ★ 路径字面正向锁（交付代码评审 #3 的追加要求）：机制的真实落点是 `docs/consult-minutes/`
  //   子目录（F1 修复），**两处描述面必须与之一致**，且**不得回到旧顶层形态**（防再漂移）。
  //   在此之前两档都写着 `docs/<date>-consult-<id>-minutes.md`——**模型可见的指令面指向一个错的落点**。
  const readme = readFileSync(join(PLUGIN_DIR, "README.md"), "utf8")
  /** 路径锁的两条腿（**判据本体**——正向/反向都在这里，自证腿必须打在它身上才不是恒真）。 */
  const minutesPathLegs = (text) => ({
    positive: text.includes("docs/consult-minutes/"),
    noOldTopLevel: !text.includes("docs/<date>-consult-<id>-minutes.md"),
  })
  for (const [label, text] of [["lib/prompts/main.md", mainPrompt], ["README.md", readme]]) {
    const legs = minutesPathLegs(text)
    assert.ok(legs.positive,
      "路径正向锁（AC-16 组）：" + label + " 必须写出机制的真实落点前缀 `docs/consult-minutes/`")
    assert.ok(legs.noOldTopLevel,
      "路径反向锁（AC-16 组）：" + label + " 不得再写旧顶层字面（F1 修复后真实落点是子目录）")
  }
  // 谓词自证（律 3）：合成文本各走一遍 —— 新形态两条腿都过；**旧顶层形态两条腿都判否**
  //（后者逐字就是 F1 修复前 main.md:30 / README.md:146 的原文 ⇒ 这两条断言当时会红）
  assert.deepEqual(minutesPathLegs("minutes land at docs/consult-minutes/<date>-consult-<id>-minutes.md"),
    { positive: true, noOldTopLevel: true }, "谓词自证前置：新形态文本必判过")
  assert.deepEqual(minutesPathLegs("minutes land at docs/<date>-consult-<id>-minutes.md"),
    { positive: false, noOldTopLevel: false }, "谓词自证：旧顶层字面两条腿都判否")

  // —— ③ AC-23 / US-12（T2）：wakeup 回合「先读全文再处置」的纪律在场（英文谓词——该档正文是英文） ——
  assert.ok(mainPrompt.includes("job_output"), "AC-23：主提示词须点名 `job_output`（P4 的那一跳）")
  assert.ok(mainPrompt.includes("read the full digest first"), "AC-23：须有「先读全文」的等价句")

  // —— ④ AC-20 错误用例（补测）：已 settle 的会话再 stop ⇒ 无效（不造第二套结算面） ——
  const h2 = makeDeps({ subagents: makeSpecSubagents(() => ({ kind: "ok", text: "reply" })) })
  const r2 = await startConsultSession(h2.deps, "问题", undefined)
  const s2 = sessOf(h2.state, r2.id)
  await h2.jobs.specs[0].hooks.done
  const settledDigest = s2.digest
  assert.equal(typeof settledDigest, "string", "前置：会话已 settle（有 digest）")
  const rejected = stopConsultSession(h2.state, r2.id, 1, h2.deps)
  assert.deepEqual(rejected, { stopped: 0, alreadySettled: true }, "AC-20 错误用例：已 settle ⇒ stop 无效")
  assert.equal(s2.digest, settledDigest, "已 settle 的 digest 不得被二次合成覆盖（digest 单一写点）")
  assert.equal(s2.stopped, false, "已 settle 的会话不得被标为 stopped（否则墓碑语义被污染）")
  cleanup(h2.sessionId, h2.state)
}

/** AC-1 / AC-2 / AC-9 / AC-21 / AC-22 / §7 ③：一次投递 = job 输出；先落盘再 complete；两个数。 */
async function b15DeliveryChecks() {
  const sub = makeSpecSubagents((label) => {
    if (label.endsWith("p:a")) return { kind: "ok", text: "reply-from-a" }
    if (label.endsWith("p:b")) return { kind: "empty" }        // 空回复（既有兜底 `(empty reply)`）
    if (label.endsWith("p:c")) return { kind: "fail", text: "boom" }
    return { kind: "ok", text: "reply-from-d" }
  })
  const h = makeDeps({ subagents: sub, config: { consultModels: POOL4 } })
  const r = await startConsultSession(h.deps, "问题", undefined)
  assert.equal(r.jobId, "consult-1")
  assert.equal(h.jobs.specs.length, 1, "AC-1/AC-2：全 settle 只产生**一次**投递（一个平台 job）")
  // §7 ③ job spec 逐字段（对齐 eng.mjs 的 kind:\"eng-dsh\" 先例）
  const spec = h.jobs.specs[0].spec
  assert.equal(spec.kind, "consult", "D15-5：kind 无路由后缀（会话混跑 dsh 与 codex-cli 行）")
  assert.equal(spec.outputLimitBytes, 131072)
  assert.equal(spec.owner, h.deps.agent.id ?? h.deps.agent.session.id, "D-42：owner = 共享 agent/session id（0.1.7 平台按 id 查活代理）")
  assert.match(spec.label, /^consult #\d+ \(4 models: p:a, p:b, p:c, p:d\)$/)
  assert.deepEqual(Object.keys(h.jobs.specs[0].hooks).sort(), ["cancel", "done"], "hooks 形 = {cancel, done}")

  const outcome = await h.jobs.specs[0].hooks.done
  const s = sessOf(h.state, r.id)
  assert.equal(outcome.status, "completed")
  assert.equal(outcome.output, s.digest, "job 输出 === session.digest（digest 无第二个写点）")
  // ★★ AC-21 落盘次序：done 解决时纪要**已经在盘上**（写盘先于 job complete）
  assert.ok(s.minutesPath && existsSync(join(h.cwd, s.minutesPath)),
    "AC-21：settle 时纪要原始层先于 job complete 落盘（order = 本批的兜底机制）")
  // AC-9：命名 glob + 结构（§0 汇总 + §1 原始层由机制写；§2–§5 留给主代理）
  assert.match(s.minutesPath, /^docs\/consult-minutes\/\d{4}-\d{2}-\d{2}-consult-\d+-minutes\.md$/, "AC-9（修复轮 F1）：命名 = docs/consult-minutes/<date>-consult-<id>-minutes.md")
  // ★ 批 15 修复轮（审计 F1 = 🔴）：落点**不得**回到 `docs/` 顶层——`test/doc-hygiene.test.mjs:123-132` 的 R-25
  //   登记谓词 `docsTopLevel()` 非递归只读顶层、且要求每个 `*.md` 登记在 `docs/README.md` 全文里 ⇒ 顶层纪要必令套件红。
  assert.ok(!/^docs\/[^/]+\.md$/.test(s.minutesPath), "F1：纪要落点必须留在 docs/ 的子目录里（顶层会撞 R-25 登记谓词）")
  const minutes = readFileSync(join(h.cwd, s.minutesPath), "utf8")
  assert.ok(minutes.includes("## §0 汇总") && minutes.includes("## §1 原始层"), "机制写 §0/§1")
  assert.ok(minutes.includes("## §2 逐问裁定") && minutes.includes("主代理写"), "裁定层留给主代理（插件永不写纪要的裁定层）")
  assert.ok(minutes.includes("不采纳（**必附理由**）"), "AC-8：纪要模板含理由列")
  // AC-22 / T-3：**交付数与有效数是两个数**
  const [head, eff] = String(s.digest).split("\n")
  assert.equal(head, "[consult #1 finished — 3 of 4 replied (1 failed)]", "交付数 3 of 4（失败 1）")
  assert.equal(eff, "effective: 2 of 4 (1 failed · 1 without content)", "有效数 2 of 4（空回复不计入有效）")
  assert.ok(String(s.digest).includes("reply-from-a") && String(s.digest).includes("reply-from-d"), "逐条回复在场")
  assert.equal(s.requiresReport, true, "§7 取值规则 ①：正常 settle ⇒ true")
  assert.equal(s.digested, false)
  const ledgerEvs = readConsultLedger(h.deps)
  assert.deepEqual(ledgerEvs.rows.map((x) => x.ev), ["started", "settled"], "台账 append-only：started → settled")
  cleanup(h.sessionId, h.state)
}

/** AC-18 / D15-4：jobs 缺失或 jobs.start 抛错 ⇒ **拒发**（零部分工作，绝不回落同步）。 */
async function b15RefusalChecks() {
  const sub = makeSpecSubagents(() => ({ kind: "ok", text: "x" }))
  const h = makeDeps({ subagents: sub, noJobs: true })
  const r = await startConsultSession(h.deps, "问题", undefined)
  assert.match(String(r.error), /jobs/, "AC-18：jobs 缺失 ⇒ 响亮拒发")
  assert.match(String(r.error), /未派发任何子代理/)
  assert.equal(sub.started?.length ?? 0, 0, "拒发路径未派发任何子代理")
  assert.equal(h.state.consultSessions.size, 0, "拒发路径不留下会话（零部分工作）")
  cleanup(h.sessionId, h.state)

  const h2 = makeDeps({ subagents: sub })
  h2.deps.ctx.get = () => ({ start() { throw new Error("no job controller serves this agent") } })
  const r2 = await startConsultSession(h2.deps, "问题", undefined)
  assert.match(String(r2.error), /派发失败/, "jobs.start 抛错同样拒发（不回落）")
  assert.equal(h2.state.consultSessions.size, 0)
  cleanup(h2.sessionId, h2.state)
}

/** AC-5 / AC-6 / AC-25 / R-7：豁免档（仅 unattended 在 start 声明 · note 必填 · 三处留痕 · 字段仍 true）。 */
async function b15ExemptionChecks() {
  const sub = makeSpecSubagents(() => ({ kind: "ok", text: "reply" }))
  // 缺省 = 无豁免 = 停
  const h0 = makeDeps({ subagents: sub })
  const r0 = await startConsultSession(h0.deps, "问题", undefined)
  await waitDigest(sessOf(h0.state, r0.id))
  assert.equal(sessOf(h0.state, r0.id).exemption, null, "AC-6：豁免缺省全部关闭")
  assert.equal(sessOf(h0.state, r0.id).requiresReport, true, "缺省 ⇒ 必须汇报（停下汇报断点）")
  cleanup(h0.sessionId, h0.state)

  // 声明 unattended ⇒ session.exemption + digest 头部行 + 台账 exempted；requiresReport **仍 true**
  const h1 = makeDeps({ subagents: sub })
  const r1 = await startConsultSession(h1.deps, "问题", undefined, { kind: "unattended", note: "user is away for 2h" })
  const d1 = await waitDigest(sessOf(h1.state, r1.id))
  assert.deepEqual(sessOf(h1.state, r1.id).exemption, { kind: "unattended", note: "user is away for 2h" }, "AC-25：session.exemption 留痕")
  assert.ok(d1.includes("exemption: unattended — user is away for 2h"), "R-7：digest 头部行留痕（wakeup 回合据此知道不必停）")
  assert.equal(sessOf(h1.state, r1.id).requiresReport, true, "§7 取值规则 ④：豁免时字段**仍为 true**（字段表达事实，不表达动作）")
  assert.deepEqual(readConsultLedger(h1.deps).rows.map((x) => x.ev), ["started", "exempted", "settled"], "R-7 第三处：台账 exempted 事件")
  cleanup(h1.sessionId, h1.state)

  // 非法 kind / note 空 ⇒ 拒
  const h2 = makeDeps({ subagents: sub })
  assert.match(String((await startConsultSession(h2.deps, "问题", undefined, { kind: "goal", note: "x" })).error), /unattended/,
    "AC-5：非法 kind ⇒ 拒（goal/authorized 只能在送达时判）")
  assert.match(String((await startConsultSession(h2.deps, "问题", undefined, { kind: "unattended", note: "   " })).error), /note/,
    "AC-5/AC-25：note 必填（豁免必须留痕）")
  assert.equal(h2.state.consultSessions.size, 0, "非法豁免 ⇒ 零部分工作")
  cleanup(h2.sessionId, h2.state)
}

/** AC-19 / AC-10 / §5.7：门禁不变量 + ack 形状（正常 / 边界 / 错误三用例）。 */
async function b15GateChecks() {
  const sub = makeSpecSubagents(() => ({ kind: "ok", text: "reply" }))
  const h = makeDeps({ subagents: sub })
  const r = await startConsultSession(h.deps, "问题", undefined)
  const d = await waitDigest(sessOf(h.state, r.id))
  const s = sessOf(h.state, r.id)

  // 边界：裸 settle（无 ack）⇒ 拒发 + 内联未消化 digest + ack 指引
  let gate = consultDigestionGate(h.state, undefined, h.deps)
  assert.equal(gate.blocked, true, "AC-19：settled ∧ ¬digested ∧ ¬minutesExempt ⇒ 命中")
  assert.ok(gate.text.includes("未派发任何子代理"), "拒发文案含「未派发任何子代理」")
  assert.ok(gate.text.includes(d.split("\n")[0]), "内联未消化 digest（拒发即恢复通道）")
  assert.ok(gate.text.includes("digested:"), "ack 指引在场")
  assert.deepEqual(undigestedConsultSessions(h.state).map((x) => x.id), [r.id], "谓词 = settled ∧ ¬digested ∧ ¬minutesExempt")

  // 错误：ack 的 minutesPath 不存在 / 裸 id ⇒ 拒（仍拦）
  gate = consultDigestionGate(h.state, [{ id: r.id, minutesPath: "docs/nope.md" }], h.deps)
  assert.equal(gate.blocked, true, "AC-19 错误用例：ack 路径不存在 ⇒ 拒")
  assert.match(gate.acked.rejected.join(" "), /不存在/)
  gate = consultDigestionGate(h.state, [String(r.id)], h.deps)
  assert.equal(gate.blocked, true, "裸 id 串不够（留痕是这一档全部的意义）")
  assert.match(gate.acked.rejected.join(" "), /id/)
  gate = consultDigestionGate(h.state, [{ id: r.id, minutesExempt: { reason: "  " } }], h.deps)
  assert.equal(gate.blocked, true, "AC-10：minutesExempt.reason 必填")

  // 正常：分钟豁免（显式 + 理由）⇒ 放行；且留痕
  gate = consultDigestionGate(h.state, [{ id: r.id, minutesExempt: { reason: "minutes already in the ticket" } }], h.deps)
  assert.equal(gate.blocked, false, "AC-19：显式豁免 ⇒ 放行")
  assert.deepEqual(s.minutesExempt, { reason: "minutes already in the ticket" })
  assert.ok(readConsultLedger(h.deps).rows.some((x) => x.ev === "digested" && x.minutesExempt), "AC-10：豁免留痕（台账）")
  assert.deepEqual(undigestedConsultSessions(h.state), [], "不变量恢复")

  // 正常：minutesPath 存在 ⇒ digested（AC-9 的落点就是 ack 的凭据）
  const h2 = makeDeps({ subagents: sub })
  const r2 = await startConsultSession(h2.deps, "问题", undefined)
  await waitDigest(sessOf(h2.state, r2.id))
  const s2 = sessOf(h2.state, r2.id)
  assert.ok(existsSync(join(h2.cwd, s2.minutesPath)))
  const gate2 = consultDigestionGate(h2.state, [{ id: r2.id, minutesPath: s2.minutesPath }], h2.deps)
  assert.equal(gate2.blocked, false, "AC-19 正常用例：ack 路径在盘上 ⇒ 放行")
  assert.equal(s2.digested, true)
  cleanup(h2.sessionId, h2.state)
  cleanup(h.sessionId, h.state)
}

/** AC-26：台账孤儿扫描（正常无提示 / 边界孤儿 / 错误：在飞会话不误报）。 */
async function b15OrphanChecks() {
  const sub = makeSpecSubagents(() => ({ kind: "ok", text: "reply" }))
  const h = makeDeps({ subagents: sub })
  const r = await startConsultSession(h.deps, "问题", undefined)
  assert.deepEqual(consultLedgerOrphans(h.deps, h.state), [], "AC-26 错误用例：在飞会话（有 started 无 settled，但内存里在）⇒ 不误报")
  await waitDigest(sessOf(h.state, r.id))
  assert.deepEqual(consultLedgerOrphans(h.deps, h.state), [], "AC-26 正常用例：完整会话 ⇒ 无提示")
  // 边界：模拟重启后的孤儿行（台账有 started、无 settle、内存里也没有该 id）
  appendFileSync(join(h.dshHome, ".thincoder", "consult-ledger.jsonl"),
    JSON.stringify({ ev: "started", id: "77", sessionId: h.sessionId, at: Date.now() }) + "\n", "utf8")
  const orphans = consultLedgerOrphans(h.deps, h.state)
  assert.deepEqual(orphans.map((o) => o.id), ["77"], "AC-26 边界用例：孤儿 ⇒ 提示（建议性，不阻断）")
  cleanup(h.sessionId, h.state)
}

// ═══════════════ 批 15 收尾修复轮：交付代码评审轮次 1 的两条实质发现 ═══════════════
//
// 交付代码评审（`advisor-dsh-2`，`VERDICT: PASS`，🔴0 🟡4 🔵3）在本批**修复轮 1 新增的代码**里
// 抓出两条实质缺陷（分歧审计没看到——它们随修复轮 1 才进来）：
//   #1 **`lib/consult.mjs` 的 stop-竞速早退路径漏 `clearTimeout(watchdog)`**——与同文件 codex 行
//      finally 注释逐字记录过的**同一缺陷物种**；#2 **三类终结事件漏 `sessionId`** ⇒ 孤儿扫描
//      按会话过滤把它们整批丢掉 ⇒ `started` 行永远关不上 ⇒ 下一次 `consult_start` 附加误导提示。
// ★ 硬约束不变：**零新增测试档 · 零新增顶层 `test(`**（台账 §三零改）⇒ 并入既有块。

/**
 * 交付代码评审 #1：**stop-竞速早退路径必须清掉自己的看门狗**。
 * 该路径在 `setTimeout(watchdog)` **之后**才判 `session.stopped` ⇒ 不清就是滞留（缺省 600000ms）。
 * ★ 观测手段 = 包裹 `globalThis.setTimeout` / `clearTimeout` 记账（consult.mjs 走全局定时器），
 * 只认 `delay === consultTimeoutMs` 的那一个 ⇒ 与测试自身的 sleep/超时定时器不混淆。
 */
async function b15WatchdogLeakChecks() {
  const TIMEOUT = 987654 // 运行时宽容正整数值域（config-store 的 resolveConsultTimeoutMs）且可辨识
  const sub = makeSpecSubagents(() => ({ kind: "ok", text: "reply" }))
  const h = makeDeps({ subagents: sub, config: { consultTimeoutMs: TIMEOUT } })
  // 假 jobs：**不立即执行 run 体**（把 spec 交回测试）⇒ 造出「会话已注册、子代理尚未起跑」的竞速窗口
  const deferred = []
  h.deps.ctx.get = () => ({ start(spec) { deferred.push(spec); return "consult-deferred" } })
  const created = new Map()
  const cleared = new Set()
  const origSetTimeout = globalThis.setTimeout
  const origClearTimeout = globalThis.clearTimeout
  globalThis.setTimeout = function (fn, ms, ...rest) { const hd = origSetTimeout(fn, ms, ...rest); created.set(hd, ms); return hd }
  globalThis.clearTimeout = function (hd) { cleared.add(hd); return origClearTimeout(hd) }
  try {
    const r = await startConsultSession(h.deps, "问题", undefined)
    assert.equal(r.jobId, "consult-deferred", "前置：派发已返回，而 run 体尚未起跑（早停可在此窗口到达）")
    assert.equal(stopConsultSession(h.state, r.id, 1, h.deps).stopped, 1, "前置：早停到达时子代理一个都还没起跑")
    const hooks = deferred[0].run()              // ← 现在才起跑 ⇒ 命中 `if (session.stopped)` 早退分支
    const outcome = await hooks.done
    assert.equal(outcome.status, "completed")
    assert.match(String(outcome.output).split("\n")[0],
      /^\[consult #\d+ stopped — 0 of 1 replied \(0 failed, 1 stopped\) before stop\]$/,
      "墓碑语义不受本修影响（D15-3：0 回复的墓碑同样自证 stop 面）")
    const watchdogs = [...created.entries()].filter(([, ms]) => ms === TIMEOUT)
    assert.equal(watchdogs.length, 1,
      "前置：该早退路径恰好造了 1 个看门狗（delay == consultTimeoutMs）——否则本腿是恒真")
    assert.ok(watchdogs.every(([hd]) => cleared.has(hd)),
      "★ 交付评审 #1：stop-竞速早退路径必须 clearTimeout(watchdog)（否则 unref 定时器 + 已 settle 控制器滞留至 consultTimeoutMs）")
  } finally {
    globalThis.setTimeout = origSetTimeout
    globalThis.clearTimeout = origClearTimeout
    cleanup(h.sessionId, h.state)
  }
}

/**
 * 交付代码评审 #2：**被拒发的会诊必须自己关上台账的 `started` 行**——否则下一次 `consult_start`
 * 会附加一句误导性幽灵提示（「#N 未见 settle——可能因重启丢失」，而那个会诊**从未派发**）。
 * ★ 本腿走**生产站点**：`apply()` 注册的 `consult_start` 工具 `execute`（含 `lib/index.mjs` 的孤儿
 * 提示组装），**不手搓等价物**（批 6 修复轮审计 🔴#1 的纪律）；台账落点由 `DSH_HOME` 注入临时目录
 * （本档顶部把 `DSH_HOME` 置空 = 测试隔离契约，此处临时改回一个临时目录并在 finally 还原）。
 */
async function b15GhostOrphanChecks() {
  const { apply } = await import("../lib/index.mjs")
  const registeredTools = []
  let jobsService = null
  // 注册面用 fake ctx（只需 `effect` + `systemPrompt.section` + `tools.register` + `get("jobs")`；
  // 不需要事件面 —— 本腿只驱动 consult_start 的 execute）
  const fakeCtx = {
    on: () => () => { },
    effect: (fn) => { const d = fn?.(); return () => d?.() },
    systemPrompt: { section: () => () => { } },
    tools: { register: (t) => { registeredTools.push(t); return () => { } } },
    get: (n) => (n === "jobs" ? jobsService : null),
  }
  const dshHome = mkdtempSync(join(tmpdir(), "consult-home-"))
  const cwd = mkdtempSync(join(tmpdir(), "consult-cwd-"))
  const prevHome = process.env.DSH_HOME
  process.env.DSH_HOME = dshHome // 生产路径的台账落点由 env 解析（index.mjs 的 deps 无 dshHome 注入缝）
  const sessionId = "consult-ghost-" + (++seq)
  const state = sessionState(sessionId)
  const agent = { session: { id: sessionId, header: { cwd }, deriveMessages: () => [] }, options: {} }
  // 滞后的假子代理：会话整段保持在飞（既不被消化门禁拦住，也不会变成孤儿行）
  fakeCtx.subagents = {
    async start(_kind, req) {
      const result = new Promise((resolve) => {
        const onAbort = () => resolve({ output: [], stopReason: "aborted" })
        if (req.signal.aborted) onAbort()
        else req.signal.addEventListener("abort", onAbort, { once: true })
      })
      return { result, dispose: async () => { } }
    },
  }
  try {
    apply(fakeCtx, { consultModels: [{ provider: "p", model: "m" }] })
    const tool = registeredTools.find((t) => t.name === "consult_start")
    assert.ok(tool, "前置：apply() 注册了 consult_start（池非空）")

    // ① 拒发（jobs.start 抛错）：零部分工作，且台账必须留下**可关闭的** disposed 行
    jobsService = { start() { throw new Error("no job controller serves this agent") } }
    const r1 = await tool.execute({ problem: "probe-1" }, { agent })
    assert.match(String(r1), /派发失败/, "前置：拒发路径")
    assert.ok(!String(r1).includes("台账孤儿"), "拒发本次不得报孤儿")
    const ledgerFile = join(dshHome, ".thincoder", "consult-ledger.jsonl")
    const rows1 = readFileSync(ledgerFile, "utf8").trim().split("\n").map((l) => JSON.parse(l))
    assert.deepEqual(rows1.map((x) => x.ev), ["started", "disposed"], "台账 append-only：started → disposed")
    assert.equal(rows1[1].sessionId, sessionId,
      "★★ 交付评审 #2：终结事件 disposed 必须带 sessionId（孤儿扫描按会话过滤——缺则被系统性丢弃）")

    // ② 再次发起（正常派发）：**不得**再对这个只被拒发的 #1 附加幽灵提示
    const specs = []
    jobsService = { start(spec) { const hooks = spec.run(); specs.push({ spec, hooks }); return "consult-" + specs.length } }
    const r2 = await tool.execute({ problem: "probe-2" }, { agent })
    assert.ok(!String(r2).includes("台账孤儿"),
      "★ 交付评审 #2：被拒发的 #1 不得被报成孤儿（它从未派发 ⇒「未见 settle、可能因重启丢失」是误导性陈述）：" + String(r2))

    // ③ 对照腿（**自证该断言非恒真**）：把 disposed 行改回**旧的**（无 sessionId）形态 ⇒ 下一次调用必报幽灵
    //    —— 逐字复现评审描述的修复前行为（本批修复轮 1 的真实代码就是那样写的）。
    const ghostRows = readFileSync(ledgerFile, "utf8").trim().split("\n").map((l) => JSON.parse(l))
    writeFileSync(ledgerFile,
      ghostRows.map((x) => JSON.stringify(x.ev === "disposed" ? { ...x, sessionId: undefined } : x)).join("\n") + "\n", "utf8")
    const r3 = await tool.execute({ problem: "probe-3" }, { agent })
    assert.ok(String(r3).includes("台账孤儿") && String(r3).includes("#1（"),
      "对照腿自证：旧形态（disposed 无 sessionId）下**确实**出现该幽灵提示 ⇒ ② 那条「不得出现」不是恒真：" + String(r3))

    // ④ 写侧静态锁（T2）：**每个终结事件写点都必须带 `sessionId`**——评审 #2 点名的三个里，
    //    「失败信封的 settled」在现有桩下不可达（settle 路径自身不抛）⇒ 用静态锁补它的可机检腿。
    const consultSrc = readFileSync(join(PLUGIN_DIR, "lib", "consult.mjs"), "utf8")
    const callBlocks = []
    const needle = "ledgerAppend(deps, {"
    for (let i = consultSrc.indexOf(needle); i !== -1; i = consultSrc.indexOf(needle, i + 1)) {
      let depth = 0
      let j = i + needle.length - 1 // 指向那个 `{`
      for (; j < consultSrc.length; j++) {
        if (consultSrc[j] === "{") depth++
        else if (consultSrc[j] === "}") { depth--; if (depth === 0) break }
      }
      callBlocks.push(consultSrc.slice(i, j + 1))
    }
    assert.ok(callBlocks.length >= 6, "前置：写点切块器真的切开了台账写点（实测 " + callBlocks.length + " 块，应 ≥ 6）")
    const terminalBlocks = callBlocks.filter((b) => /ev: "(settled|stopped|disposed)"/.test(b))
    assert.deepEqual([...new Set(terminalBlocks.map((b) => b.match(/ev: "([a-z]+)"/)[1]))].sort(),
      ["disposed", "settled", "stopped"], "前置：三类终结事件写点全在场（settled / stopped / disposed）")
    for (const b of terminalBlocks) {
      assert.match(b, /sessionId:/,
        "交付评审 #2 写侧锁：每个终结事件写点都必须带 sessionId（缺则孤儿扫描按会话过滤丢弃它、该 started 行永远关不上）："
          + b.replace(/\s+/g, " ").slice(0, 100))
    }
  } finally {
    process.env.DSH_HOME = prevHome
    cleanupConsultSessions(state)
    dropSession(sessionId, (s) => cleanupConsultSessions(s))
  }
}

/** AC-21 的负向腿 + §9 畸形 + 台账前向兼容 + id 计数器续接。 */
async function b15RobustnessChecks() {
  // ① 写盘失败 ⇒ digest 仍投递（fail-open）+ warn + minutesPath 归 null（盘上没有就不得声称有）
  const sub = makeSpecSubagents(() => ({ kind: "ok", text: "reply" }))
  const h = makeDeps({ subagents: sub })
  writeFileSync(join(h.cwd, "docs"), "occupied") // 让 docs/ 成为一个**文件** ⇒ mkdirSync 必 EEXIST
  const warns = []
  const origWarn = console.warn
  console.warn = (...a) => { warns.push(a.join(" ")) }
  let r
  try {
    r = await startConsultSession(h.deps, "问题", undefined)
    const outcome = await h.jobs.specs[0].hooks.done
    assert.equal(outcome.status, "completed", "AC-21：纪要写不出去也照样投递（记录面 fail-open）")
    assert.ok(warns.some((w) => w.includes("纪要原始层写出失败")), "响亮 warn（不静默）")
    assert.equal(sessOf(h.state, r.id).minutesPath, null, "盘上没有档 ⇒ minutesPath 归 null（artifact 不得撒谎）")
    assert.ok(!String(outcome.output).includes("-minutes.md"), "digest 不得声称一个不存在的落点")
  } finally { console.warn = origWarn; cleanup(h.sessionId, h.state) }

  // ② §9 畸形输入：单条回复软顶 + 截断标记 + 控制字符清洗（**纯函数**直接断言）
  const long = "L".repeat(CONSULT_DIGEST_REPLY_CAP + 500)
  const synthetic = {
    id: "9", total: 1, received: 1, failed: 0, terminated: 0, stopped: false, replies: [{ model: "p:x", reply: "\u0000" + long }],
    models: ["p:x"], jobId: "consult-9", minutesPath: null, requiresReport: true, exemption: null,
  }
  const dLong = composeConsultDigest(synthetic)
  assert.ok(dLong.includes("reply capped at " + CONSULT_DIGEST_REPLY_CAP + " chars"), "§9：软顶 + 截断标记")
  assert.ok(!dLong.includes("L".repeat(CONSULT_DIGEST_REPLY_CAP + 1)), "超帽部分不进 digest（全文在纪要 §1.1）")
  assert.ok(!dLong.includes("\u0000"), "§9：控制字符清洗")
  assert.equal(dLong, composeConsultDigest(synthetic), "纯函数幂等（同输入同输出）")

  // ③ 台账前向兼容（§9 升级类）：未知 ev 忽略、不报错；畸形行忽略
  const h3 = makeDeps({ subagents: sub })
  const file = join(h3.dshHome, ".thincoder", "consult-ledger.jsonl")
  mkdirSync(dirname(file), { recursive: true })
  appendFileSync(file, JSON.stringify({ ev: "future-event", id: "5", at: 1 }) + "\n", "utf8")
  appendFileSync(file, "{not json\n", "utf8")
  const read = readConsultLedger(h3.deps)
  assert.deepEqual(read.rows, [], "未知 ev 不进语义视图（忽略该行、不报错）")
  assert.equal(read.unknownEvents.length, 1)
  assert.equal(read.maxId, 5, "★ id 计数器仍看全部合法行（防新版本事件让老读者 id 回退 ⇒ 纪要档名碰撞）")
  // ④ id 计数器续接：台账最大 id=5 ⇒ 下一个会话 id = 6（**重启后不复用 id**）
  const r3 = await startConsultSession(h3.deps, "问题", undefined)
  assert.equal(r3.id, "6", "§7 ⑤：id 计数器由台账续接（重启后不复用 id）")
  await h3.jobs.specs[0].hooks.done
  cleanup(h3.sessionId, h3.state)
}

// ═══════════════ 批 30 / US-5（D-58 · 锚 A30-8 / A30-9）：注入面消毒 + 失败可诊断 ═══════════════
//
// 来源：会诊 #13 **全灭**的已确证真因（子会话落盘 `turn/end` seq 7 铁证 + 平台源码链 + 本地解码
// 复现）：注入文本里的**裸会话引用形态**被平台当 canonical URI 解析 ⇒ base64url + JSON.parse 抛 ⇒
// 整回合 `reason.kind="error"` ⇒ 子代理 `stopReason="error"`（**不带 diagnostic**）⇒ 插件只渲染
// 一行「child ended: error」。本组的消费面与 D-28 腿同源 = **digest**。
// ★ 判据正则**以字面钉进本档**（**不 import 平台模块**——避免测试与平台内部耦合）；
//   来源坐标 = `dsh-session-reference/lib/types/uri.js:59` 的 bare 分支：
//     /@\[((?:\\.|[^\\\]])*)\]\((dsh-session:[^\s)]*)\)|(dsh-session:[A-Za-z0-9_-]+)/gu
//   本档只钉**裸分支那一半**（它才是 #13 命中的那一路）。
const PLATFORM_BARE_SESSION_REF = /(dsh-session:[A-Za-z0-9_-]+)/gu
/**
 * 病态样本**以拼接形态**写（不写整串字面）：设计 §2.0 C 的写作纪律——裸简写不得作为整串出现在
 * 可能被注入的文本里；本档照此形态，免得测试自己成为下一个罪证源（判据正则仍是字面，见上）。
 */
const BARE_REF_SAMPLE = "dsh-session" + ":" + "483-499"
/** 带路径的引用形态（合规写法）：平台两个分支都**不命中**（`dsh-session` 之后是 `/` 而非 `:`）。 */
const PATH_REF_SAMPLE = "dsh-session/lib/types/index.js:483-499"
/** 平台 bare 分支的命中数。**每次新建正则**：带 `g` 的正则有 `lastIndex` 状态，复用会让断言互相污染。 */
const bareRefHits = (text) => [...String(text).matchAll(new RegExp(PLATFORM_BARE_SESSION_REF.source, "gu"))].length
/** 假 codex 子进程调用记录里**真的发起了任务**的那些（`args[0] === "exec"`；探测调用不算）。 */
const execCalls = (log) => (Array.isArray(log) ? log : []).filter((args) => args[0] === "exec")

/**
 * 假 codex 子进程（注入缝 `deps.spawn`；形状对齐 test/codex-runner.test.mjs 的同族夹具）：
 * `--version` ⇒ 探测成功；`debug models` ⇒ 非零退出（目录走 models_cache.json 兜底）；
 * 其余（exec）⇒ 非零退出 + stderr（本组要证的正是 stderr / exit code 上浮进 digest）。
 */
function a30CodexSpawn(stderrText, log) {
  return (_file, args) => {
    // 派发面取证：`args[0] === "exec"` 才是**真的发起了 codex 任务**（`--version` / `debug models` 只是探测）
    if (Array.isArray(log)) log.push(args.slice())
    const child = new EventEmitter()
    child.pid = 424242
    child.stdout = new EventEmitter()
    child.stderr = new EventEmitter()
    child.stdin = { write() { }, end() { } }
    child.kill = () => { }
    ;(async () => {
      // ★ 先让出一拍再发事件：调用方是在 spawn 返回**之后**才挂 `stdout/stderr.on("data")` 的，
      //   同步 emit 会整批丢失（现场形态 = 「codex --version 退出码 0（输出: ）」⇒ RUNNER_UNAVAILABLE）。
      await sleep(0)
      if (args.includes("--version")) {
        child.stdout.emit("data", Buffer.from("codex-cli 0.150.1\n"))
        await sleep(5)
        child.emit("exit", 0)
        return
      }
      if (args.includes("models")) { await sleep(5); child.emit("exit", 1); return }
      child.stderr.emit("data", Buffer.from(stderrText))
      await sleep(5)
      child.emit("exit", 1)
    })()
    return child
  }
}

/** 批 30 / US-5（A30-8 / A30-9）的可机检腿——并入既有块（台账 §三零改：本档零新增顶层 `test(`）。 */
async function b30InjectionAndDiagnosticsChecks() {
  // ——— ① A30-8 谓词自证（先证可判，再对真档断言） ———
  assert.equal(bareRefHits(BARE_REF_SAMPLE), 1, "谓词自证：裸形态必须命中平台 bare 分支（不是恒假断言）")
  assert.equal(bareRefHits(PATH_REF_SAMPLE), 0, "谓词自证：带路径形态**本就不命中**（`dsh-session` 之后是 `/`）")
  assert.equal(bareRefHits(sanitizeInjectedText(BARE_REF_SAMPLE)), 0, "★ 消毒后不再命中（删掉消毒 ⇒ 本行必红）")
  assert.ok(sanitizeInjectedText(BARE_REF_SAMPLE).includes("\u200B"), "断开方式 = 插入零宽空格")
  assert.equal(sanitizeInjectedText(BARE_REF_SAMPLE).replace(/\u200B/g, ""), BARE_REF_SAMPLE,
    "除插入的零宽空格外**逐字不变**（纯替换，不做任何其它改写）")
  assert.equal(sanitizeInjectedText(PATH_REF_SAMPLE), PATH_REF_SAMPLE, "带路径的引用形态**一字不改**（原样保留）")
  assert.equal(sanitizeInjectedText("普通正文\n第二行"), "普通正文\n第二行", "无关文本逐字不变（含换行）")

  // ——— ①b 批 30 修复轮 / 码评 🟡#1：**markdown 提及分支**的形态腿（轮 1 的消毒面扩了它，却没有腿）———
  // 病（码评实证）：消毒的 F3 订正把「`](` 紧跟 `dsh-session:`」这一**上下文形态**一并纳入断开面，
  //   但**没有任何断言**覆盖它 ⇒ 删掉那一半、只留 bare 分支时**全套仍绿**（净损失一条防线）。
  // 判据正则**以字面钉住平台提及分支**：`@\[…\]\((dsh-session:[^\s)]*)\)`（来源坐标同上：
  //   `dsh-session-reference/lib/types/uri.js:59`；载荷是 `[^\s)]*` ⇒ **任意、可为空**）。
  //   两个判据：① **载荷侧** `(dsh-session:[^\s)]*)`（与设计/工单逐字同形）；② **完整提及形态**
  //   `\]\((dsh-session:[^\s)]*)\)`——后者才是平台正则真正要求的那一形（带 `](` 上下文与收尾 `)`）。
  //   它与 bare 分支的载荷形状**不同** ⇒ 两半可各自转红（删任一半，对位的断言必红）。
  const MENTION_PAYLOAD_RE = /(dsh-session:[^\s)]*)/gu
  const MENTION_FULL_RE = /\]\((dsh-session:[^\s)]*)\)/gu
  const hitsOf = (re, text) => [...String(text).matchAll(new RegExp(re.source, "gu"))].length
  const mentionPayloadHits = (text) => hitsOf(MENTION_PAYLOAD_RE, text)
  const mentionFullHits = (text) => hitsOf(MENTION_FULL_RE, text)
  const MD_REF_SAMPLE = "](" + "dsh-session" + ":" + "!!!"   // 载荷**非词字符开头**：bare 分支本就不命中
  const MD_REF_EMPTY = "](" + "dsh-session" + ":" + ")"      // 载荷**为空**：bare 分支同样不命中
  assert.equal(mentionPayloadHits(MD_REF_SAMPLE), 1, "谓词自证：提及形态的**载荷侧**必须命中（不是恒假断言）")
  assert.equal(bareRefHits(MD_REF_SAMPLE), 0, "谓词自证：该样本**本就不命中** bare 分支（故本段只裁 markdown 那一半）")
  assert.equal(mentionPayloadHits(MD_REF_EMPTY), 1, "谓词自证：空载荷形态同样命中提及载荷侧")
  assert.equal(mentionFullHits(MD_REF_EMPTY + "x)"), 1, "谓词自证：**完整提及形态**（带收尾 `)`）命中")
  assert.equal(mentionPayloadHits(sanitizeInjectedText(MD_REF_SAMPLE)), 0,
    "★ 🟡#1 决定性（markdown 半）：消毒后不再命中提及载荷侧（删掉实现里 `](dsh-session:` 那一半 ⇒ 本行必红）")
  assert.equal(mentionPayloadHits(sanitizeInjectedText(MD_REF_EMPTY)), 0, "空载荷形态同样被断开（载荷任意 ⇒ 不能只断词字符形态）")
  assert.equal(mentionFullHits(sanitizeInjectedText(MD_REF_EMPTY + "x)")), 0,
    "★ 完整提及形态（`](dsh-session:<载荷>)`）消毒后不再命中（平台正则真正要求的那一形）")
  assert.equal(sanitizeInjectedText(MD_REF_SAMPLE).replace(/\u200B/g, ""), MD_REF_SAMPLE,
    "仍是**纯替换**（只插入零宽空格，`](` 与其余文本一字不改）")
  assert.ok(sanitizeInjectedText(MD_REF_SAMPLE).includes("](") && sanitizeInjectedText(MD_REF_SAMPLE).includes("!!!"),
    "★ 断言「`](` 上下文被保留」——实现若把整段 `](dsh-session:` 删掉，本行与上一行同时红")
  // 另一半（bare）的独立可转红：**只**断 markdown 上下文时，带词字符载荷的形态仍会命中
  assert.equal(bareRefHits(sanitizeInjectedText(BARE_REF_SAMPLE)), 0,
    "★ 🟡#1 决定性（bare 半）：`dsh-session:` + 词字符载荷仍被断开（删掉那一半 ⇒ 本行必红）")

  // ——— ② A30-8 行为腿：经**真实派发路径**（prompt 装配点）验证两个来源都过消毒 ———
  {
    const sub = makeSubagents({ delayMs: 10, reply: "ok" })
    const h = makeDeps({ subagents: sub })
    // 注入源：① 问题正文含裸形态；② 主历史派生消息里**同时**含裸形态与带路径形态
    h.deps.agent.session.deriveMessages = () => [
      { role: "user", content: [{ type: "text", text: "证据：裸 " + BARE_REF_SAMPLE + " 与带路径 " + PATH_REF_SAMPLE }] },
    ]
    try {
      await startConsultSession(h.deps, "问题里的裸形态 " + BARE_REF_SAMPLE, undefined)
      await waitFor(() => sub.started.length === 1)
      const promptText = (sub.started[0].req.prompt ?? []).map((part) => part?.text ?? "").join("\n")
      assert.ok(promptText.length > 0, "前置：prompt 文本可读（假子代理收到真实装配结果）")
      assert.equal(bareRefHits(promptText), 0,
        "★ 派发出去的 prompt 里**零命中**平台 bare 分支（问题正文与主历史两个来源都过消毒；漏一处本行必红）")
      assert.ok(promptText.includes(PATH_REF_SAMPLE), "带路径的引用形态原样保留在注入文本里")
      assert.ok(promptText.includes("问题里的裸形态"), "问题正文照常注入（消毒不改其余内容）")
    } finally { cleanup(h.sessionId, h.state) }
  }

  // ——— ③ A30-9 证据通路的 slug 移植必须与**真机观测值**一致（否则定位永远走不到主路径） ———
  assert.equal(projectKeySlug("D:\\DSH-Portable\\plugins\\dsh-thincoder-suite"),
    "--D-DSH-Portable-plugins-dsh-thincoder-suite--",
    "slug 移植 == 本机 $DSH_HOME/sessions/ 下的真实目录名（逐字比对；漂移 ⇒ 本行红）")
  const zstdOk = typeof nodeZlib.zstdCompressSync === "function" && typeof nodeZlib.zstdDecompressSync === "function"

  // ——— ④ A30-9 形态一「有 reason」：stopReason=error 且**无 diagnostic** ⇒ digest 带出真因 ———
  {
    const childId = "a30-9-child-" + (++seq)
    const sub = {
      started: [],
      async start(_kind, req) {
        sub.started.push(req)
        return { id: childId, result: Promise.resolve({ output: [], stopReason: "error" }), dispose: async () => { } }
      },
    }
    const h = makeDeps({ subagents: sub })
    try {
      const frames = [
        JSON.stringify({ type: "session", version: 4, id: childId }),
        JSON.stringify({ type: "turn/end", seq: 7, time: 1, data: { turn: 1, reason: { kind: "error", error: { message: "A30-9 真因：Unexpected token", code: "UNKNOWN" } } } }),
      ]
      const dir = join(h.dshHome, "sessions", projectKeySlug(h.cwd), childId)
      mkdirSync(dir, { recursive: true })
      const frameBytes = frames.map((f) => nodeZlib.zstdCompressSync(Buffer.from(f + "\n", "utf8")))
      writeFileSync(join(dir, "session.v4.jsonl.zstd"), Buffer.concat(frameBytes))
      const r = await startConsultSession(h.deps, "问题", undefined)
      const digest = await waitDigest(sessOf(h.state, r.id))
      if (zstdOk) {
        assert.ok(digest.includes("child session turn/end"),
          "★ digest 带出兜底读到的真因（删掉兜底读 ⇒ 本行必红）：" + JSON.stringify(digest.slice(0, 260)))
        assert.ok(digest.includes("Unexpected token"), "真因原文（reason.error.message）在场（不是只给 stopReason）")
        assert.ok(digest.includes("error: A30-9 真因"), "reason.kind 一并带出（单行证据行）")
      } else {
        assert.ok(digest.includes("子代理面不可诊断"),
          "本运行时不带 zstd ⇒ 如实降级声明「不可诊断」（诚实降级，不假装读到）")
      }
      assert.ok(digest.includes("child ended: error"), "既有 stopReason 语义不变（兜底只**追加**证据）")
    } finally { cleanup(h.sessionId, h.state) }
  }

  // ——— ⑤ A30-9 形态二「无 reason（退路）」：会话档不存在 / 子会话 id 缺失 ⇒ **如实声明不可诊断** ———
  {
    const sub = {
      started: [],
      async start(_kind, req) {
        sub.started.push(req)
        // 子会话 id 缺失（无 id / 无 localAgent）= 定位不到会话档的**最保守形态**
        return { result: Promise.resolve({ output: [], stopReason: "error" }), dispose: async () => { } }
      },
    }
    const h = makeDeps({ subagents: sub })
    try {
      const r = await startConsultSession(h.deps, "问题", undefined)
      const digest = await waitDigest(sessOf(h.state, r.id))
      assert.ok(digest.includes("子代理面不可诊断"),
        "★ 退路：定位 / 解压 / id 任一不可得 ⇒ digest **明写**「子代理面不可诊断」（不假装、不吞掉）："
          + JSON.stringify(digest.slice(0, 260)))
      assert.ok(!digest.includes("child session turn/end"), "退路里**不得**出现「读到了真因」的措辞")
    } finally { cleanup(h.sessionId, h.state) }
  }

  // ——— ⑥ A30-9 ③ codex 行：`env.diagnostics`（exit code / stderr）**一并显示**，不再只显示 userMessage ———
  {
    const codexCwd = mkdtempSync(join(tmpdir(), "consult-codex-home-"))
    writeFileSync(join(codexCwd, "models_cache.json"), JSON.stringify({
      models: [{ slug: "gpt-a30-9", display_name: "gpt-a30-9", supported_reasoning_levels: [{ effort: "low" }, { effort: "medium" }], default_reasoning_level: "low", visibility: "list", context_window: 128000 }],
    }), "utf8")
    const sub = makeSubagents({ delayMs: 10, reply: "unused" })
    const h = makeDeps({ subagents: sub, config: { consultModels: [{ runner: { kind: "codex-cli", model: "gpt-a30-9", executable: "codex-b30-9" } }] } })
    const codexLog = []
    Object.assign(h.deps, {
      spawn: a30CodexSpawn("A30-9 codex stderr: model not supported with a ChatGPT account\n", codexLog),
      platform: "linux",
      env: { CODEX_HOME: codexCwd, PATH: "" },
    })
    try {
      const r = await startConsultSession(h.deps, "问题", undefined)
      const digest = await waitDigest(sessOf(h.state, r.id))
      assert.equal(sub.started.length, 0, "前置：codex 行不走 dsh 子代理面（独立配置面）")
      assert.ok(digest.includes("codex-cli PROCESS_ERROR"), "codex 行失败照常进 digest：" + JSON.stringify(digest.slice(0, 200)))
      assert.ok(digest.includes("A30-9 codex stderr"),
        "★ stderr 原文上浮（旧实现 `userMessage || diagnostics` 二选一 ⇒ userMessage 在场就把真因吞掉，本行必红）")
      assert.ok(digest.includes("exit=1"), "exit code 同样上浮（diagnostics 的两半都在）")
      assert.ok(execCalls(codexLog).length >= 1, "正向对照：该行**确实发起过** codex exec（下面的「零 exec」断言不是恒真）")
    } finally { cleanup(h.sessionId, h.state) }
  }

  // ═══ 批次 30 / US-7（D-59 · 锚 A30-11）：池行**前置可用性预检** ═══
  // 形态：池里含**配置性必败行** ⇒ 该行**不被派发**且点名。判据 = ①digest/文案点名「因配置未派发」
  // + 原因；②**零 codex exec 调用**（假子进程的调用记录是「确实没派发」的直接证据，不是推断）。

  // ——— ⑦ 模型**不在目录内** ⇒ 该行不派发、digest 点名；同池的 dsh 行照常结算（不连坐） ———
  {
    const codexHome = mkdtempSync(join(tmpdir(), "consult-pf-a-"))
    writeFileSync(join(codexHome, "models_cache.json"), JSON.stringify({
      models: [{ slug: "gpt-in-catalog", supported_reasoning_levels: [{ effort: "low" }] }],
    }), "utf8")
    const log = []
    const sub = makeSubagents({ delayMs: 10, reply: "dsh 行照常回复" })
    const h = makeDeps({
      subagents: sub,
      config: { consultModels: [
        { provider: "p", model: "m" },
        { runner: { kind: "codex-cli", model: "gpt-a30-11-absent", executable: "codex-b30-11a" } },
      ] },
    })
    Object.assign(h.deps, { spawn: a30CodexSpawn("unused\n", log), platform: "linux", env: { CODEX_HOME: codexHome, PATH: "" } })
    try {
      const r = await startConsultSession(h.deps, "问题", undefined)
      assert.ok(r && r.id, "前置：仅一行必败 ⇒ 池不整体拒发：" + JSON.stringify(r).slice(0, 200))
      const digest = await waitDigest(sessOf(h.state, r.id)) // 等整批 settle 后再取证（此时该派发的都已派发）
      assert.equal(execCalls(log).length, 0,
        "★ 必败的 codex 行**未被派发**（settle 后仍零 exec 调用——假子进程调用记录直接取证，不是推断）")
      assert.equal(sub.started.length, 1, "其余 dsh 行照常派发（一次）")
      assert.ok(digest.includes("因配置未派发"),
        "★ digest 点名「因配置未派发」：" + JSON.stringify(digest.slice(0, 320)))
      assert.ok(digest.includes("codex-cli:gpt-a30-11-absent"), "点名**是那一行**（模型标签逐字在场）")
      assert.ok(digest.includes("不在 codex 模型目录内"), "带出**原因**（目录未命中）")
      assert.ok(digest.includes("dsh 行照常回复"), "其余行照常结算（预检不连坐）")
      assert.equal(sessOf(h.state, r.id).models.join(","), "p:m", "session.models 只含**实际派发**的行")
      assert.equal(sessOf(h.state, r.id).total, 1, "total = 实际派发行数（计数口径与派发面一致）")
    } finally { cleanup(h.sessionId, h.state) }
  }

  // ——— ⑧ `reasoningEffort` 不被接受**且无法回落**（只能原样透传）⇒ 同样不派发；池内唯一行必败 ⇒ 整池拒发 ———
  // ★ 判据收窄（见 lib/codex-adapter.mjs 的 preflightCodexRow ②）：可回落的「不被接受」**不拦**
  //   （那是既有回落链的职责，由 codex-runner 测试档的两条回落腿钉住）；只有「连回落都做不到 ⇒
  //   只能把一个已知不被支持的值原样送给 codex」才是配置性必败。
  {
    const codexHome = mkdtempSync(join(tmpdir(), "consult-pf-b-"))
    writeFileSync(join(codexHome, "models_cache.json"), JSON.stringify({
      // 该模型只声明一个**插件梯子不认识的**档 ⇒ 解析器无法映射 ⇒ 只能原样透传（必败形态）
      models: [{ slug: "gpt-eff-offladder", supported_reasoning_levels: [{ effort: "minimal" }] }],
    }), "utf8")
    const log = []
    const h = makeDeps({
      subagents: makeSubagents({ delayMs: 10, reply: "unused" }),
      config: { consultModels: [
        { runner: { kind: "codex-cli", model: "gpt-eff-offladder", effort: "max", executable: "codex-b30-11b" } },
      ] },
    })
    Object.assign(h.deps, { spawn: a30CodexSpawn("unused\n", log), platform: "linux", env: { CODEX_HOME: codexHome, PATH: "" } })
    try {
      const r = await startConsultSession(h.deps, "问题", undefined)
      assert.ok(r && r.error, "池内**唯一**行必败 ⇒ 整体拒发（响亮、零派发）：" + JSON.stringify(r).slice(0, 260))
      assert.ok(r.error.includes("因配置未派发"), "拒发文案点名「因配置未派发」")
      assert.ok(r.error.includes("不被 codex model gpt-eff-offladder 接受"), "拒发文案带出原因（effort 不被接受）")
      assert.ok(r.error.includes("无法映射到任何受支持档"), "原因里点明**为何不可回落**（只能原样透传）")
      assert.ok(r.error.includes("supported: minimal"), "原因里含该模型**实际支持**的档位（可行动）")
      assert.equal(execCalls(log).length, 0, "★ 零 exec：该行确实没被派发（省下的正是那一行预算）")
    } finally { cleanup(h.sessionId, h.state) }
  }

  // ——— ⑨ 诚实降级：**目录不可得** ⇒ 不拦（fail-open，退回既有行为）+ 响亮 note（绝不假装拦住） ———
  {
    const codexHome = mkdtempSync(join(tmpdir(), "consult-pf-c-")) // 空目录：无 models_cache.json ⇒ 目录不可得
    const log = []
    const h = makeDeps({
      subagents: makeSubagents({ delayMs: 10, reply: "unused" }),
      config: { consultModels: [{ runner: { kind: "codex-cli", model: "gpt-unknown-a30-11", executable: "codex-b30-11c" } }] },
    })
    Object.assign(h.deps, { spawn: a30CodexSpawn("A30-11 目录不可得时的 stderr\n", log), platform: "linux", env: { CODEX_HOME: codexHome, PATH: "" } })
    const warns = []
    const origWarn = console.warn
    try {
      console.warn = (...a) => { warns.push(a.map(String).join(" ")) }
      const r = await startConsultSession(h.deps, "问题", undefined)
      assert.ok(r && r.id, "★ 目录不可得 ⇒ **不拦**（fail-open：绝不因读不到而砖化）：" + JSON.stringify(r).slice(0, 240))
      const digest = await waitDigest(sessOf(h.state, r.id)) // 派发在 job 体内异步发生 ⇒ 等 settle 再取证
      assert.ok(execCalls(log).length >= 1, "该行照常派发（settle 后有 exec 调用）")
      assert.ok(!digest.includes("因配置未派发"), "零「因配置未派发」——降级路径不假装拦住")
      assert.ok(warns.some((w) => w.includes("前置预检")),
        "如实标注该降级（裸 console.warn）：" + JSON.stringify(warns.slice(0, 3)))
    } finally {
      console.warn = origWarn
      cleanup(h.sessionId, h.state)
    }
  }

  // ——— ⑩ 反向对照（**不得误拦**）：可回落的「不被接受」照常派发（既有回落链消化） ———
  // 这条腿防的是「收窄过头」：model [low,high] + 请求 medium ⇒ 解析器回落 high ⇒ 预检**放行** ⇒
  // 该行照常 exec（与 codex-runner 测试档的两条回落腿同一语义——本批不得把既有回落地判死）。
  {
    const codexHome = mkdtempSync(join(tmpdir(), "consult-pf-d-"))
    writeFileSync(join(codexHome, "models_cache.json"), JSON.stringify({
      models: [{ slug: "gpt-mappable", supported_reasoning_levels: [{ effort: "low" }, { effort: "high" }] }],
    }), "utf8")
    const log = []
    const h = makeDeps({
      subagents: makeSubagents({ delayMs: 10, reply: "unused" }),
      config: { consultModels: [
        { runner: { kind: "codex-cli", model: "gpt-mappable", effort: "medium", executable: "codex-b30-11d" } },
      ] },
    })
    Object.assign(h.deps, { spawn: a30CodexSpawn("mappable row（照常派发后失败）\n", log), platform: "linux", env: { CODEX_HOME: codexHome, PATH: "" } })
    try {
      const r = await startConsultSession(h.deps, "问题", undefined)
      assert.ok(r && r.id, "★ 可回落行**不得**被预检拦下（拦下 = 打断既有回落语义）：" + JSON.stringify(r).slice(0, 240))
      const digest = await waitDigest(sessOf(h.state, r.id))
      assert.ok(execCalls(log).length >= 1, "该行照常派发（settle 后有 exec 调用）")
      assert.ok(!digest.includes("因配置未派发"), "digest 里零「因配置未派发」（没被误拦）")
      assert.ok(digest.includes("falling back to nearest supported effort"),
        "既有回落 note 照常进回复尾部（medium ⇒ high，回落语义未被本批改动）：" + JSON.stringify(digest.slice(0, 300)))
    } finally { cleanup(h.sessionId, h.state) }
  }
}
/**
 * 批 30 / US-6（D30-6 · 锚 A30-10）：**权限面判据读模型请求头**。
 * 判据（设计 §2.6 硬要求）：「工具面已生效 / 只读已生效」这类断言，证据只能是**模型可见工具面**
 *（子会话落盘 `request/header` 事件），**不得**以「`restrict` 未抛错」代替；读不到 ⇒ 如实标注
 * **「模型面未验」**（并带「本部署无法保证只读」）。
 * ★ 本函数的样本**不经平台**：自造多帧 zstd 会话档（与 A30-9 同形的夹具）。
 * ★ ⓪ 段补的是设计 §2.6 末句的另一半（分歧修复轮 F1 / 审计实证：该声明**只在 eng_coder 的模型面
 *   证据行**、会诊侧零命中）：**「若平台面无法收窄 ⇒ 如实标注『本部署无法保证只读』，并在会诊产物里
 *   带该声明」** ⇒ 会诊的**两条产物**（派发回复的 detail 段 · settle 后的 digest）各一条腿；
 *   外加一条**跨档防漂移锁**（与 `lib/eng.mjs` 的 `renderModelSurfaceEvidence` 同一句）。
 * ★ 并入既有块（台账 §三零改：本档零新增顶层 `test(`）。
 */
async function b30PermissionSurfaceChecks() {
  // ——— ⓪ **会诊产物**必须带如实声明（设计 §2.6 末句逐字：「若平台面无法收窄 ⇒ 如实标注『本部署
  // 无法保证只读』，**并在会诊产物里带该声明**」）———
  // ★ 分歧修复轮 F1 的实证：该声明此前**只在 eng_coder 的模型面证据行**（lib/eng.mjs 的
  //   renderModelSurfaceEvidence），会诊侧零命中 ⇒ 本段把「会诊产物」这一半钉死。
  // ★ 两条产物各一条独立腿（派发回复的 detail 段 / settle 后的 digest）：**任一**缺声明或被改写成
  //   「只读生效」即红（分离断言 ⇒ 删哪一处都能定位，不是一条恒绿的大断言）。
  const READONLY_CORE = "本部署无法保证只读（平台面无法收窄）"
  {
    const sub = makeSubagents({ delayMs: 10, reply: "artifact-ok" })
    const h = makeDeps({ subagents: sub })
    try {
      const r = await startConsultSession(h.deps, "问题", undefined)
      const dispatch = String(r.text ?? "")
      assert.ok(dispatch.includes(READONLY_CORE),
        "★ A30-10：**派发产物**必须带如实声明「" + READONLY_CORE + "」：" + dispatch)
      assert.ok(dispatch.includes("弱证") && dispatch.includes("模型面"),
        "★ 声明必须附**证据口径**（弱证 = allow 白名单下发 / 模型面 = 子会话 request/header）：" + dispatch)
      assert.ok(!dispatch.includes("只读会诊"),
        "★ 派发产物**不得**再自称「只读会诊」（平台面不可收窄：allow 白名单 ≠ 只读保证）：" + dispatch)
      const digest = await waitDigest(sessOf(h.state, r.id))
      const headLines = digest.split("\n").slice(0, 4).join(" / ")
      assert.ok(digest.includes(READONLY_CORE), "★ A30-10：**digest** 必须带如实声明：" + headLines)
      assert.ok(digest.includes("弱证") && digest.includes("模型面") && digest.includes("request/header"),
        "★ digest 的声明必须附证据口径（弱证 + 模型面通道）：" + headLines)
      assert.ok(digest.includes("[run_code]"),
        "★ 声明须带本部署实测模型面（[run_code] 单元素 ⇒ 残余绕行口在场）：" + headLines)
      assert.ok(!digest.includes("只读生效"),
        "★ 声明**不得**被改写成「只读生效」（现场证据相反：会诊子会话实际改写过设计档）：" + headLines)
    } finally { cleanup(h.sessionId, h.state) }
  }
  // ★ 跨档防漂移锁：consult 侧与 `lib/eng.mjs`（renderModelSurfaceEvidence 的未验分支）必须**同一句**
  //   ——平台口径更新时两处同改；只改一处 ⇒ 本锁红（「同源」是可机检的性质，不是注释里的承诺）。
  {
    const engSrc = readFileSync(new URL("../lib/eng.mjs", import.meta.url), "utf8")
    const consultSrc = readFileSync(new URL("../lib/consult.mjs", import.meta.url), "utf8")
    assert.ok(engSrc.includes(READONLY_CORE), "前置：eng.mjs 的模型面证据仍以本句为口径（同源基座）")
    assert.ok(consultSrc.includes(READONLY_CORE), "★ 同源：consult.mjs 必须逐字含本句（防两处漂移）")
  }

  const zstdOk = typeof nodeZlib.zstdCompressSync === "function" && typeof nodeZlib.zstdDecompressSync === "function"
  const childId = "a30-10-child-" + (++seq)
  const cwd = mkdtempSync(join(tmpdir(), "consult-a30-10-cwd-"))
  const home = mkdtempSync(join(tmpdir(), "consult-a30-10-home-"))
  const agent = { session: { id: "a30-10-parent", header: { cwd } } }
  const run = { id: childId, localAgent: { session: { id: childId, header: { cwd } } } }
  const dir = join(home, "sessions", projectKeySlug(cwd), childId)
  const writeFrames = (frames) => {
    mkdirSync(dir, { recursive: true })
    writeFileSync(join(dir, "session.v4.jsonl.zstd"), Buffer.concat(
      frames.map((f) => nodeZlib.zstdCompressSync(Buffer.from(f + "\n", "utf8")))))
  }

  if (!zstdOk) {
    // 本运行时不带 zstd ⇒ 判据**必须**如实降级（不得因为「restrict 没抛错」就说已生效）
    const noZstd = readChildModelToolSurface({ dshHome: home }, run, agent)
    assert.equal(noZstd.verified, false, "无 zstd ⇒ 模型面未验（诚实降级）")
    assert.ok(renderModelSurfaceEvidence(noZstd, ["pwsh"]).includes("模型面未验"), "如实标注「模型面未验」")
    return
  }

  // ——— ① 主形态：请求头里**只有** run_code ⇒ 命名面生效 + 残余绕行口如实标注 ———
  // ★ 多帧：`request/header` 落在**第二个**帧 ⇒ 同时验证「按 magic 切帧循环」（只读第一帧会漏）
  writeFrames([
    JSON.stringify({ type: "session", version: 4, id: childId }),
    JSON.stringify({ type: "request/header", seq: 3, time: 1, data: { header: { reason: "initial", tools: [{ name: "run_code", description: "PTC transport" }] } } }),
  ])
  const surface = readChildModelToolSurface({ dshHome: home }, run, agent)
  assert.equal(surface.verified, true,
    "★ A30-10：判据读的是**模型请求头**（request/header；多帧切帧解压后仍能读到）：" + JSON.stringify(surface))
  assert.deepEqual(surface.tools, ["run_code"], "工具面逐字来自请求头（不是派发载荷、也不是平台回显）")
  const line = renderModelSurfaceEvidence(surface, ["pwsh", "bash"])
  assert.ok(line.includes("request/header"), "证据行点名**证据来源**：" + line)
  assert.ok(line.includes("模型可见工具面 = [run_code]"), "逐字带出模型可见面：" + line)
  assert.ok(line.includes("执行类命名工具在场 0 个") && line.includes("命名面收窄生效"),
    "命名面生效由**模型面**判定：" + line)
  assert.ok(line.includes("残余绕行口") && line.includes("run_code"),
    "★ run_code 在场 ⇒ 如实标注**残余绕行口**（平台保留传输面不可收窄）：" + line)

  // ——— ② 反向（防「判据恒绿」）：请求头里**确有**执行类命名工具 ⇒ 必须判「收窄未生效」 ———
  writeFrames([
    JSON.stringify({ type: "request/header", seq: 1, time: 1, data: { header: { tools: [{ name: "pwsh" }, { name: "run_code" }] } } }),
  ])
  const leaked = readChildModelToolSurface({ dshHome: home }, run, agent)
  const leakedLine = renderModelSurfaceEvidence(leaked, ["pwsh", "bash"])
  assert.deepEqual(leaked.tools, ["pwsh", "run_code"], "反向样本的工具面逐字来自请求头")
  assert.ok(leakedLine.includes("收窄未生效") && leakedLine.includes("pwsh"),
    "★ 谓词不是恒绿：请求头里确有执行类 ⇒ 判**未生效**并点名：" + leakedLine)
  assert.ok(!leakedLine.includes("命名面收窄生效"), "不得同时说生效与未生效：" + leakedLine)

  // ——— ③ 三处如实降级：定位不到 / 事件不含工具面 / 子会话 id 不可得 ⇒ **模型面未验** ———
  const missing = readChildModelToolSurface({ dshHome: home }, { id: "no-such-child-" + (++seq) }, agent)
  assert.equal(missing.verified, false, "定位不到会话档 ⇒ 未验（不假装读到）")
  const missingLine = renderModelSurfaceEvidence(missing, ["pwsh"])
  assert.ok(missingLine.includes("模型面未验"), "★ 明写「模型面未验」：" + missingLine)
  assert.ok(missingLine.includes("不得以「restrict 未抛错」代替"), "★ 明写不得用「未抛错」顶替模型面证据：" + missingLine)
  assert.ok(missingLine.includes("本部署无法保证只读"), "★ 平台面无法收窄 ⇒ 如实声明「本部署无法保证只读」：" + missingLine)
  assert.ok(!missingLine.includes("收窄生效") && !missingLine.includes("已生效"),
    "★ 未验时**绝不**出现「已生效」类措辞（判据伪装的正是这一格）：" + missingLine)
  // 事件在场但不含工具面（形状漂移）⇒ 同样未验，与「读不到档」分开归因
  writeFrames([JSON.stringify({ type: "request/header", seq: 2, time: 1, data: { reason: "series" } })])
  const noTools = readChildModelToolSurface({ dshHome: home }, run, agent)
  assert.equal(noTools.verified, false, "request/header 在场但无工具面 ⇒ 未验")
  assert.ok(noTools.reason.includes("没有可读的工具面"), "归因可读（形状漂移 vs 档不可得，分开写）：" + noTools.reason)
  // 子会话 id 不可得 ⇒ 未验（不抛）
  assert.equal(readChildModelToolSurface({ dshHome: home }, { localAgent: { session: {} } }, agent).verified, false,
    "子会话 id 不可得 ⇒ 未验（不抛）")
  // 连运行对象都没有 ⇒ 未验（不抛；取证面永不成为新的失败源）
  assert.equal(readChildModelToolSurface({ dshHome: home }, null, null).verified, false, "无 run/agent ⇒ 未验（不抛）")
}
test("selectConsultModels（provider:model / 裸 provider / 裸 model / 未知）+ 批 15 交付与消化面（AC-1…AC-26 的腿）+ 修复轮补腿（AC-7 形状 · AC-16 正向锁 · AC-20 alreadySettled · AC-23/US-12）+ 收尾修复轮补腿（交付代码评审 #1 看门狗清除 · #2 终结事件 sessionId 与幽灵孤儿 · #3 落点路径字面锁）+ 批 30 / US-5 补腿（A30-8 注入面消毒 · A30-9 失败可诊断两形态 + codex 行 diagnostics）", async () => {
  const pool = [
    { provider: "a", model: "x" },
    { provider: "a", model: "y" },
    { provider: "b", model: "z" },
    { runner: { kind: "codex-cli", model: "gpt" } },
  ]
  assert.deepEqual(selectConsultModels(pool, undefined).models, pool)
  assert.deepEqual(selectConsultModels(pool, []).models, pool)
  assert.deepEqual(selectConsultModels(pool, ["a:x"]).models.map((m) => m.model), ["x"])
  assert.deepEqual(selectConsultModels(pool, ["a"]).models.map((m) => m.model), ["x", "y"])
  assert.deepEqual(selectConsultModels(pool, ["z"]).models.map((m) => m.provider), ["b"])
  assert.deepEqual(selectConsultModels(pool, ["codex-cli:gpt"]).models.map((m) => m.runner.model), ["gpt"])
  assert.match(selectConsultModels(pool, ["nope"]).error, /unknown consult model selector/)

  await b15DeliveryChecks()
  await b15RefusalChecks()
  await b15ExemptionChecks()
  await b15GateChecks()
  await b15OrphanChecks()
  await b15WatchdogLeakChecks()
  await b15GhostOrphanChecks()
  await b15RobustnessChecks()
  await b15ShapeAndSurfaceChecks()
  // 批 30 / US-5（D-58 · A30-8 / A30-9）：注入面消毒 + 失败可诊断（并入既有块——台账 §三零改）
  await b30InjectionAndDiagnosticsChecks()
  // 批 30 / US-6（D30-6 · A30-10）：权限面判据读模型请求头（无法收窄即如实标注）
  await b30PermissionSurfaceChecks()
})

// ═════════ D-52 / A29-7（批 29 单②）：会诊只读白名单的**对位锁** ═════════
//
// 病（2026-09-26 取证）：会诊子代理的只读白名单（`READONLY_TOOLS` / `READONLY_TOOLS_CORE`）
// 是 consult.mjs 的模块私有常量，**没有任何对位锁**——白名单被改动（混进写类工具 / 换成 deny
// 黑名单语义 / 干脆不再下发 toolFilter）时，全套测试**一片绿**。本档补两条：
//   ① **静态**：白名单成员集恰为只读集合（零写类工具）+ 两处派发点都以 `allow` 键下发；
//   ② **行为**：`ctx.subagents.start("spawn", …)` 收到的 spec 里 `toolFilter.allow` 逐项在场、
//      且**不得**出现 `deny`（平台契约：`allow` = keep only / `deny` = remove；两种语义不可混用）。
// 平台契约（2026-09-26 取证）：`restrict(filter)` 的 `allow` = keep only，`deny` = remove；
// 未注册名会被**响亮拒绝**——这正是 consult.mjs 那条 `unknown → 降级核心三件` 重试腿的由来。
test("A29-7 (D-52): 会诊只读白名单对位锁——静态成员集 = 只读集合且 allow 键在场；行为：派发 spec 零 deny、allow 逐项在场", async () => {
  // —— 谓词（先自证可判违规，再对真档断言）——
  const READONLY_UNIVERSE = ["read", "glob", "grep", "web_search", "web_fetch"]
  const WRITE_CLASS = ["write", "edit", "run_code", "pwsh", "bash", "powershell", "sh", "zsh", "cmd",
    "shell", "exec", "spawn", "terminal", "process", "run_terminal", "task", "write_file",
    "str_replace_editor", "notebook_edit"]
  const writeIn = (list) => list.filter((t) => WRITE_CLASS.includes(t))
  assert.deepEqual(writeIn(["read", "write"]), ["write"], "谓词自证：写类成员必须被判出（不是恒真断言）")
  assert.deepEqual(writeIn(["read", "glob"]), [], "谓词自证：只读成员不得被误判")

  const src = readFileSync(new URL("../lib/consult.mjs", import.meta.url), "utf8")
  const arrayOf = (name) => {
    const m = new RegExp("const " + name + " = \\[([^\\]]*)\\]").exec(src)
    return m ? [...m[1].matchAll(/"([^"]+)"/g)].map((x) => x[1]) : null
  }
  const full = arrayOf("READONLY_TOOLS")
  const core = arrayOf("READONLY_TOOLS_CORE")
  assert.ok(Array.isArray(full) && Array.isArray(core), "两个白名单常量必须可从源码文本解析出来")
  // ① 静态：成员集**恰为**只读集合（逐项 ⊆ 只读全集 ⇒ 零写类工具），且降级集 ⊆ 全集
  assert.deepEqual(full, [...READONLY_UNIVERSE],
    "白名单成员集恰为只读集合（成员漂移即红，须显式更新本锁）：" + JSON.stringify(full))
  assert.deepEqual(core, ["read", "glob", "grep"], "降级集 = 读 + 检索三件：" + JSON.stringify(core))
  assert.deepEqual(writeIn(full), [], "白名单不得混入任何写类工具：" + JSON.stringify(writeIn(full)))
  assert.ok(core.every((t) => full.includes(t)), "降级集必须是全量的子集")
  // ① 静态：两处派发点都用 `allow` 键（keep-only 语义），且**零** `deny`（黑名单语义）
  const allowSites = [...src.matchAll(/toolFilter:\s*\{\s*allow:\s*(READONLY_TOOLS|READONLY_TOOLS_CORE)\s*\}/g)]
    .map((m) => m[1]).sort()
  assert.deepEqual(allowSites, ["READONLY_TOOLS", "READONLY_TOOLS_CORE"].sort(),
    "两处派发点都显式以 allow 键下发白名单：" + JSON.stringify(allowSites))
  assert.equal((src.match(/toolFilter:\s*\{\s*deny/g) ?? []).length, 0,
    "consult.mjs 不得把只读白名单换成 deny 黑名单语义")

  // —— ② 行为：主路径（全量白名单）收到 spec 的 toolFilter ——
  const subA = makeSubagents({ delayMs: 20, reply: "ok" })
  const hA = makeDeps({ subagents: subA })
  try {
    await startConsultSession(hA.deps, "problem", undefined)
    await waitFor(() => subA.started.length === 1)
    assert.equal(subA.started[0].kind, "spawn", "子代理类型 = spawn")
    const tfA = subA.started[0].req.toolFilter
    assert.ok(tfA && typeof tfA === "object", "spec 必须带 toolFilter：" + JSON.stringify(tfA))
    assert.deepEqual(Object.keys(tfA), ["allow"], "toolFilter 恰有 allow 一个键（零 deny）：" + JSON.stringify(Object.keys(tfA)))
    assert.equal(tfA.deny, undefined, "★ 不得出现 deny（一旦出现，语义就从 keep-only 变成黑名单）")
    for (const t of READONLY_UNIVERSE) {
      assert.ok(tfA.allow.includes(t), "白名单逐项在场：" + t + " → " + JSON.stringify(tfA.allow))
    }
  } finally { cleanup(hA.sessionId, hA.state) }

  // —— ② 行为：降级腿（可选工具未注册 ⇒ 平台响亮拒绝 ⇒ 核心三件重试）同样只有 allow ——
  const subB = {
    started: [],
    async start(kind, req) {
      subB.started.push({ kind, req })
      if (subB.started.length === 1) throw new Error("unknown tool: web_search")
      return { result: Promise.resolve({ output: [{ type: "text", text: "ok" }], stopReason: "completed" }), dispose: async () => {} }
    },
  }
  const hB = makeDeps({ subagents: subB })
  try {
    await startConsultSession(hB.deps, "problem", undefined)
    await waitFor(() => subB.started.length === 2)
    assert.deepEqual(subB.started[1].req.toolFilter, { allow: ["read", "glob", "grep"] },
      "降级腿 = 核心三件白名单，且仍零 deny：" + JSON.stringify(subB.started[1].req.toolFilter))
  } finally { cleanup(hB.sessionId, hB.state) }

  // ═════ 批 37 / S1（设计档 §二十 20.5）：子代理契约迁移的四条腿（并入本块——零新增顶层 test(）═════

  // —— T-27（源码级）：四个派发档不再直呼已移除的 ctx.subagents.start(，全部经单一入口 ——
  const dispatchModules = ["consult.mjs", "eng.mjs", "escalate.mjs", "codex-app-server.mjs"]
  for (const f of dispatchModules) {
    const srcT27 = readFileSync(new URL("../lib/" + f, import.meta.url), "utf8")
    assert.equal((srcT27.match(/(?:ctx\.)?subagents\.start\s*\(/g) ?? []).length, 0,
      "T-27：" + f + " 不得直呼已移除的 subagents.start(...)（回退分支只许住在 lib/subagent-dispatch.mjs）")
    assert.ok(srcT27.includes("subagent-dispatch.mjs"),
      "T-27：" + f + " 必须 import 共享派发助手")
    assert.ok(/dispatchSubagent\s*\(/.test(srcT27),
      "T-27：" + f + " 必须调用 dispatchSubagent(...)（不是只 import）")
  }
  const helperSrc = readFileSync(new URL("../lib/subagent-dispatch.mjs", import.meta.url), "utf8")
  for (const needle of ["getProvider", "startActivation", "subagents.start", "宿主子代理契约断层"]) {
    assert.ok(helperSrc.includes(needle),
      "T-27 反证：老宿主回退/新宿主派发/可读断层必须都在单一入口内：" + needle)
  }

  // —— T-28：契约断层 ⇒ 抛**可读错误**（含 getProvider 与 subagents.start），不是裸 TypeError ——
  await assert.rejects(
    () => dispatchSubagent({ subagents: {} }, "spawn", { prompt: [{ type: "text", text: "x" }], parent: {} }),
    (e) => {
      assert.ok(e instanceof Error, "T-28：必须抛 Error")
      assert.ok(!(e instanceof TypeError), "T-28：不得是裸 TypeError（那是被禁止的错误文案）")
      assert.match(String(e.message), /getProvider/, "T-28：文案必须点名 getProvider")
      assert.match(String(e.message), /subagents\.start/, "T-28：文案必须点名 subagents.start")
      assert.match(String(e.message), /宿主子代理契约断层/, "T-28：文案必须点明契约断层")
      return true
    },
  )
  await assert.rejects(
    () => dispatchSubagent({ subagents: { getProvider: () => ({ name: "spawn", start: "not-a-function" }) } }, "spawn", {}),
    (e) => /getProvider/.test(String(e.message)) && !(e instanceof TypeError),
    "T-28：provider.start 非函数（且无其它派发面）⇒ 同一可读断层",
  )
  assert.equal(subagentDispatchAvailable({ subagents: {} }, "spawn"), false,
    "T-28 谓词自证：空 ctx.subagents 不可派")

  // —— T-29 ★：consult 在新宿主拿不到只读保证 ⇒ fail-closed（零派发） ——
  const t29Dispatches = []
  const t29Provider = {
    name: "spawn",
    capabilities: { agentOptions: true, agentPreset: true, outputSchema: true, depthLimit: true },
    async prepareContinuable() { return {} },
  }
  const t29Host = {
    getProvider: (name) => (name === "spawn" ? t29Provider : undefined),
    async startActivation(spec) {
      t29Dispatches.push(spec)
      return {
        childId: "t29-child",
        result: Promise.resolve({ output: [{ type: "text", text: "should-not-run" }], stopReason: "completed" }),
        dispose: async () => {},
      }
    },
  }
  const hT29 = makeDeps({ subagents: t29Host })
  try {
    const r29 = await startConsultSession(hT29.deps, "problem", undefined)
    assert.ok(r29 && typeof r29.error === "string",
      "T-29：新宿主下 consult 必须拒绝运行（返回 error，而不是起一个可写会诊）：" + JSON.stringify(r29))
    assert.match(r29.error, /无法保证只读/, "T-29：拒绝文案必须点明「无法保证只读」")
    assert.match(r29.error, /拒绝运行/, "T-29：拒绝文案必须点明「拒绝运行」")
    assert.equal(t29Dispatches.length, 0,
      "T-29：拒绝时不得派发任何子代理（startActivation 零调用）；实调 " + t29Dispatches.length + " 次")
  } finally { cleanup(hT29.sessionId, hT29.state) }

  // —— T-30：老宿主回退（只有 subagents.start）仍能派发，且既有字段原样透传 ——
  const t30Calls = []
  const t30Legacy = {
    async start(kind, request) {
      t30Calls.push({ kind, request })
      return {
        id: "t30-run",
        result: Promise.resolve({ output: [{ type: "text", text: "legacy-ok" }], stopReason: "completed" }),
        dispose: async () => {},
      }
    },
  }
  const t30Run = await dispatchSubagent({ subagents: t30Legacy }, "spawn", {
    prompt: [{ type: "text", text: "x" }], parent: {}, signal: undefined, label: "legacy",
    persona: "p", toolFilter: { allow: ["read"] }, agentOptions: { maxTokens: 1 },
  })
  assert.equal(t30Calls.length, 1, "T-30：老宿主回退必须真的调用 subagents.start")
  assert.equal(t30Calls[0].kind, "spawn", "T-30：provider 名原样透传")
  assert.equal(t30Calls[0].request.persona, "p", "T-30：persona 原样透传（老宿主契约遵守它）")
  assert.deepEqual(t30Calls[0].request.toolFilter, { allow: ["read"] }, "T-30：toolFilter 原样透传")
  assert.deepEqual(t30Calls[0].request.agentOptions, { maxTokens: 1 }, "T-30：agentOptions 原样透传")
  assert.equal((await t30Run.result).stopReason, "completed", "T-30：回退句柄的 result 可读")
  assert.equal(typeof t30Run.dispose, "function", "T-30：回退句柄带 dispose")

  // —— T-30 附加（新宿主主路线）：只有 getProvider+startActivation 时也派得出去 ——
  const t30bCalls = []
  const t30bProvider = {
    name: "spawn",
    capabilities: { agentOptions: true, agentPreset: true, outputSchema: true, depthLimit: true },
    async prepareContinuable() { return {} },
  }
  const t30bHost = {
    getProvider: () => t30bProvider,
    agents: { get: (id) => ({ id, session: { seq: 1 } }) },
    async startActivation(spec) {
      t30bCalls.push(spec)
      return {
        childId: "t30b-child",
        result: Promise.resolve({ output: [{ type: "text", text: "new-ok" }], stopReason: "completed" }),
        dispose: async () => {},
      }
    },
  }
  const t30bRun = await dispatchSubagent(
    { subagents: t30bHost, agents: t30bHost.agents }, "spawn",
    {
      prompt: [{ type: "text", text: "x" }], parent: {}, signal: new AbortController().signal,
      label: "eng-coder", persona: "p", toolFilter: { deny: ["x"] },
    },
    { allowUnsupportedComposition: true },
  )
  assert.equal(t30bCalls.length, 1, "T-30b：新宿主主路线必须调用 startActivation")
  assert.equal(t30bCalls[0].delivery, "caller", "T-30b：delivery=caller（结果只回调用方）")
  assert.equal(t30bCalls[0].label, "eng-coder", "T-30b：label 走 spec 顶层")
  assert.equal("label" in t30bCalls[0].request, false, "T-30b：request 不得再带 label")
  assert.equal("signal" in t30bCalls[0].request, false, "T-30b：request 不得再带 signal")
  assert.equal("persona" in t30bCalls[0].request, false, "T-30b：0.2.1 request 不含 persona（显式降级）")
  assert.equal("toolFilter" in t30bCalls[0].request, false, "T-30b：0.2.1 request 不含 toolFilter（显式降级）")
  assert.equal(t30bRun.id, "t30b-child", "T-30b：receipt.childId 映射为旧 run.id")
  assert.equal(t30bRun.localAgent.id, "t30b-child", "T-30b：ctx.agents 可读时补 localAgent（可读不到不伪造）")
  assert.equal((await t30bRun.result).stopReason, "completed", "T-30b：新路线 result 可读")

  // —— 组合字段默认 fail-closed：未显式授权时，新宿主路线不得静默丢 persona/toolFilter ——
  await assert.rejects(
    () => dispatchSubagent({ subagents: t30bHost }, "spawn", { prompt: [{ type: "text", text: "x" }], parent: {}, persona: "p" }),
    /拒绝派发/,
    "新宿主不遵守组合字段 ⇒ 默认拒绝派发（只有显式 allowUnsupportedComposition 才降级）",
  )

  // ═════ 批 39 / 设计档 §二十二 22.5：Agent Preset 随包分发的四条腿（T-35…T-38）═════
  //
  // 受测对象 = 本**仓**的三处交付面：cordis.patch.yml 的两条 preset 行（T-35 / T-36）·
  // package.json 的 peer 下限（T-37）· consult 的派发与 fail-closed（T-38）。全部并入本块
  // （台账 §三零改：零新增顶层 test(）。

  // —— T-35：两条 preset 行都在，config.id 精确，plugins 非空 ——
  const patchSrc = readFileSync(new URL("../cordis.patch.yml", import.meta.url), "utf8")
  /** 从 patch 源码切出一行 Loader 条目：以同缩进的 `- id:` 兄弟行收尾（缩进感知，避免吞掉相邻行）。 */
  const loaderRow = (src, rowId) => {
    const esc = rowId.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
    const head = new RegExp("^( *)- id: " + esc + "[ \\t]*$", "m")
    const m = head.exec(src)
    if (!m) return null
    const sib = new RegExp("^" + m[1] + "- id: ", "gm")
    sib.lastIndex = m.index + m[0].length
    const n = sib.exec(src)
    return src.slice(m.index, n ? n.index : src.length)
  }
  assert.equal(loaderRow(patchSrc, "preset-does-not-exist"), null,
    "T-35 谓词自证：不存在的行名必须切不到（切片器不是恒真）")
  const engPresetSrc = loaderRow(patchSrc, "preset-thincoder-eng")
  const roPresetSrc = loaderRow(patchSrc, "preset-thincoder-consult-ro")
  assert.ok(engPresetSrc !== null && roPresetSrc !== null,
    "T-35：cordis.patch.yml 必须含两条 preset 行（preset-thincoder-eng / preset-thincoder-consult-ro）")
  for (const [label, block, wantId] of [
    ["thincoder-eng", engPresetSrc, "thincoder-eng"],
    ["thincoder-consult-ro", roPresetSrc, "thincoder-consult-ro"],
  ]) {
    assert.match(block, /name:[ \t]*'@deepseek-ai\/dsh-agent-preset'/,
      "T-35：" + label + " 必须是 @deepseek-ai/dsh-agent-preset 的 Loader 条目")
    assert.match(block, new RegExp("^ +id: " + wantId.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(?:[ \\t]+#.*)?[ \\t]*$", "m"),
      "T-35：" + label + " 的 config.id 必须逐字为 " + wantId + "（插件侧按它认会话）")
    assert.match(block, /^ +plugins:[ \t]*\n(?: +.*\n)*? +- id: /m,
      "T-35：" + label + " 的 plugins 必须是非空的行清单（schema 要求 id + plugins）")
    // 行清单至少有一项：块内 `- id:` 出现次数 > 1（第 1 次是行自身）
    assert.ok([...block.matchAll(/^ +- id: \S+[ \t]*$/gm)].length > 1,
      "T-35：" + label + " 的 plugins 不得为空")
  }

  // —— T-36：只读预设**不含**写/执行类；fs 写能力由 config 关掉；读面仍在 ——
  /** 块内所有 `name:` 值（**只认带引号的 name 行**——注释里点名的裸词不算，防假阳性）。 */
  const namesIn = (block) => [...block.matchAll(/^[ \t]+name:[ \t]*'([^']+)'[ \t]*$/gm)].map((m) => m[1])
  const roNames = namesIn(roPresetSrc)
  const RO_FORBIDDEN = [
    "@deepseek-ai/dsh-tool-pwsh", "@deepseek-ai/dsh-tool-bash",
    "@deepseek-ai/dsh-tool-bash-persistent", "@deepseek-ai/dsh-tool-pwsh-persistent",
    "@deepseek-ai/dsh-tool-terminal", "@deepseek-ai/dsh-tool-str-replace-editor",
    "@deepseek-ai/dsh-tool-jobs", "@deepseek-ai/dsh-tool-ralph",
    "@deepseek-ai/dsh-tool-workflow", "@deepseek-ai/dsh-workflow-ptc",
    "@deepseek-ai/dsh-tool-subagent", "@deepseek-ai/dsh-tool-cordis",
  ]
  // 谓词自证：塞一个写类工具进去必须被判出（本断言不恒真）
  assert.deepEqual(
    ["@deepseek-ai/dsh-tool-fs", "@deepseek-ai/dsh-tool-pwsh"].filter((n) => RO_FORBIDDEN.includes(n)),
    ["@deepseek-ai/dsh-tool-pwsh"], "T-36 谓词自证：写/执行类名单必须能判出违规成员")
  assert.deepEqual(roNames.filter((n) => RO_FORBIDDEN.includes(n)), [],
    "T-36：只读预设不得含写/执行/后台作业/再委派类工具：" + JSON.stringify(roNames))
  // tool-fs 的写能力：0.2.1 的 tool-fs Config 有 write / edit 两个开关 ⇒ 必须逐字关掉
  const roFsRow = loaderRow(roPresetSrc, "tool-fs")
  assert.ok(roFsRow !== null, "T-36：只读预设的 tool-fs 行必须可定位")
  assert.match(roFsRow, /^ +write: false[ \t]*$/m, "T-36：tool-fs 的 write 必须显式关掉（不能靠缺省）")
  assert.match(roFsRow, /^ +edit: false[ \t]*$/m, "T-36：tool-fs 的 edit 必须显式关掉（不能靠缺省）")
  // 只读面必须**还在**（不然「砍干净」也能让上一条恒绿）
  for (const need of ["@deepseek-ai/dsh-tool-fs", "@deepseek-ai/dsh-tool-fs-search",
    "@deepseek-ai/dsh-tool-web", "@deepseek-ai/dsh-tool-skill"]) {
    assert.ok(roNames.includes(need), "T-36：只读预设必须保留读/检索类行：" + need + "（实得 " + JSON.stringify(roNames) + "）")
  }

  // —— T-37：package.json 的 @deepseek-ai/dsh peer 下限 ≥ 0.2.1-rc.2 ——
  /** 极简 semver 比较（只服务本腿：major.minor.patch + 可选 prerelease，语义按 semver §11）。 */
  const parseVer = (s) => {
    const m = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/.exec(String(s))
    return m ? { nums: [Number(m[1]), Number(m[2]), Number(m[3])], pre: m[4] ?? null } : null
  }
  const cmpVer = (a, b) => {
    for (let i = 0; i < 3; i++) if (a.nums[i] !== b.nums[i]) return a.nums[i] < b.nums[i] ? -1 : 1
    if (a.pre === null && b.pre === null) return 0
    if (a.pre === null) return 1          // 正式版 > 同号预发布
    if (b.pre === null) return -1
    const pa = a.pre.split("."), pb = b.pre.split(".")
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      if (pa[i] === undefined) return -1
      if (pb[i] === undefined) return 1
      const na = /^\d+$/.test(pa[i]), nb = /^\d+$/.test(pb[i])
      if (na && nb) { const x = Number(pa[i]), y = Number(pb[i]); if (x !== y) return x < y ? -1 : 1 }
      else if (na !== nb) return na ? -1 : 1   // 数字标识符 < 字母标识符
      else if (pa[i] !== pb[i]) return pa[i] < pb[i] ? -1 : 1
    }
    return 0
  }
  const floorAtLeast = (range, floor) => {
    const m = /^\^\s*([0-9A-Za-z.+-]+)$/.exec(String(range).trim())
    if (!m) return false
    const a = parseVer(m[1]), b = parseVer(floor)
    return a !== null && b !== null && cmpVer(a, b) >= 0
  }
  // 比较器自证（四个方向都要对；否则「≥」恒真/恒假都能混过）
  assert.equal(floorAtLeast("^0.2.1-rc.2", "0.2.1-rc.2"), true, "T-37 谓词自证：等于下限 ⇒ 通过")
  assert.equal(floorAtLeast("^0.2.0-rc.1", "0.2.1-rc.2"), false, "T-37 谓词自证：低于下限 ⇒ 不通过")
  assert.equal(floorAtLeast("^0.2.2", "0.2.1-rc.2"), true, "T-37 谓词自证：更高正式版 ⇒ 通过")
  assert.equal(floorAtLeast("^0.1.7-rc.2", "0.2.1-rc.2"), false, "T-37 谓词自证：老宿主下限 ⇒ 不通过")
  assert.equal(floorAtLeast("^0.2.1-rc.1", "0.2.1-rc.2"), false, "T-37 谓词自证：低一个 rc ⇒ 不通过")
  const pkg = JSON.parse(readFileSync(new URL("../package.json", import.meta.url), "utf8"))
  const dshPeer = String(pkg?.peerDependencies?.["@deepseek-ai/dsh"] ?? "")
  assert.ok(floorAtLeast(dshPeer, "0.2.1-rc.2"),
    "T-37：@deepseek-ai/dsh 的 peer 下限必须 ≥ 0.2.1-rc.2（低版本由平台 peer 闸门拒绝安装）：实际 "
      + JSON.stringify(dshPeer))

  // —— T-38 ★：派发带 agentPreset；预设缺失/不可用 ⇒ fail-closed（零派发） ——
  // 正向：注册表里有只读预设 ⇒ consult 恢复可用，且 spec.request 里 agentPreset 逐字在场、
  //       **不带** toolFilter / persona（0.2.1 契约里没有它们，夹带只会被剥掉或拒绝）。
  const t38Calls = []
  const t38Provider = {
    name: "spawn",
    capabilities: { agentOptions: true, agentPreset: true, outputSchema: true, depthLimit: true },
    async prepareContinuable() { return {} },
  }
  const t38Host = {
    getProvider: (name) => (name === "spawn" ? t38Provider : undefined),
    async startActivation(spec) {
      t38Calls.push(spec)
      return {
        childId: "t38-child",
        result: Promise.resolve({ output: [{ type: "text", text: "ro-ok" }], stopReason: "completed" }),
        dispose: async () => {},
      }
    },
  }
  const t38Presets = {
    async list() { return [{ id: "standard" }, { id: "thincoder-consult-ro" }] },
  }
  const hT38 = makeDeps({ subagents: t38Host, services: { agentPresets: t38Presets } })
  try {
    const r38 = await startConsultSession(hT38.deps, "problem", undefined)
    assert.ok(r38 && r38.error === undefined,
      "T-38：只读预设已注册 ⇒ consult 必须恢复可用（不再 fail-closed）：" + JSON.stringify(r38))
    await waitFor(() => t38Calls.length >= 1)
    assert.equal(t38Calls[0].request.agentPreset, "thincoder-consult-ro",
      "T-38：派发必须带 agentPreset = 随包分发的只读预设（实得 "
        + JSON.stringify(t38Calls[0].request.agentPreset) + "）")
    assert.equal("toolFilter" in t38Calls[0].request, false,
      "T-38：预设路线不得再夹带 toolFilter（0.2.1 契约不含它）")
    assert.equal("persona" in t38Calls[0].request, false,
      "T-38：预设路线不得再夹带 persona（0.2.1 契约不含它）")
  } finally { cleanup(hT38.sessionId, hT38.state) }

  // 负向①：注册表里**没有**该 id ⇒ 拒绝运行 + 零派发（绝不退化成无约束会诊）
  const t38bCalls = []
  const t38bHost = {
    getProvider: () => t38Provider,
    async startActivation(spec) {
      t38bCalls.push(spec)
      return { childId: "t38b-child", result: Promise.resolve({ output: [], stopReason: "completed" }), dispose: async () => {} }
    },
  }
  const hT38b = makeDeps({
    subagents: t38bHost,
    services: { agentPresets: { async list() { return [{ id: "standard" }] } } },
  })
  try {
    const r38b = await startConsultSession(hT38b.deps, "problem", undefined)
    assert.ok(r38b && typeof r38b.error === "string",
      "T-38：只读预设缺失 ⇒ 必须拒绝运行：" + JSON.stringify(r38b))
    assert.match(r38b.error, /只读预设缺失/, "T-38：拒绝文案必须点名「只读预设缺失」")
    assert.match(r38b.error, /无法保证只读/, "T-38：拒绝文案必须点明「无法保证只读」")
    assert.match(r38b.error, /拒绝运行/, "T-38：拒绝文案必须点明「拒绝运行」")
    assert.equal(t38bCalls.length, 0,
      "T-38：预设缺失时不得派发任何子代理（实调 " + t38bCalls.length + " 次）")
  } finally { cleanup(hT38b.sessionId, hT38b.state) }

  // 负向②：注册了但**挂载失败**（broken）⇒ 同样 fail-closed（工具面不是我们要的那一份）
  const t38cCalls = []
  const t38cHost = {
    getProvider: () => t38Provider,
    async startActivation(spec) {
      t38cCalls.push(spec)
      return { childId: "t38c-child", result: Promise.resolve({ output: [], stopReason: "completed" }), dispose: async () => {} }
    },
  }
  const hT38c = makeDeps({
    subagents: t38cHost,
    services: { agentPresets: { async list() { return [{ id: "thincoder-consult-ro", broken: "row tool-fs: never started" }] } } },
  })
  try {
    const r38c = await startConsultSession(hT38c.deps, "problem", undefined)
    assert.ok(r38c && typeof r38c.error === "string", "T-38：broken 预设 ⇒ 拒绝运行：" + JSON.stringify(r38c))
    assert.match(r38c.error, /只读预设不可用/, "T-38：broken 预设的拒绝文案必须点明「只读预设不可用」")
    assert.equal(t38cCalls.length, 0, "T-38：broken 预设时不得派发任何子代理")
  } finally { cleanup(hT38c.sessionId, hT38c.state) }

  // ★ 批39 交付评审 #1 追加夹具：`broken: false`（平台「字段恒在、健康时为 false」形状）⇒ **必须放行**。
  //   原谓词用 `String(x) !== ""`，而 `String(false) === "false"` 非空 ⇒ 被误判 broken
  //   ⇒ 健康预设被拒、整条会诊被误锁死。本条钉住收紧后的**真值判定**（改回 String 谓词 ⇒ 本夹具红）。
  const t38dCalls = []
  const t38dHost = {
    getProvider: () => t38Provider,
    async startActivation(spec) {
      t38dCalls.push(spec)
      return { childId: "t38d-child", result: Promise.resolve({ output: [], stopReason: "completed" }), dispose: async () => {} }
    },
  }
  const hT38d = makeDeps({
    subagents: t38dHost,
    services: { agentPresets: { async list() { return [{ id: "thincoder-consult-ro", broken: false }] } } },
  })
  try {
    const r38d = await startConsultSession(hT38d.deps, "problem", undefined)
    assert.ok(!(r38d && typeof r38d.error === "string"),
      "T-38：broken:false（健康）⇒ 必须放行，不得误判为 broken：" + JSON.stringify(r38d))
  } finally { cleanup(hT38d.sessionId, hT38d.state) }
})

// ═════════ 批 41（台账 t-6 / 设计档 docs/2026-10-18-consult-preset-drift-design.md §八）═════════
// 只读会诊预设的「内容漂移」检测——四条顶层腿（T-39 … T-42）。
//
// 受测对象：
//   T-39 / T-40 / T-41 = lib/consult.mjs 的 resolveConsultReadonlyRoute（内容层）+ lib/preset-readonly-guard.mjs；
//   T-42 = 发货定义 cordis.patch.yml 与 CONSULT_READONLY_MODULES 的**静态同步锁**。
// ★ 三条纪律（设计档 §八）：① 每条腿都必须**能红**（变异自证读数见交付报告）；
//   ② T-42 的解析规则**写死在腿里**（不引 YAML 解析器——本仓零依赖）；
//   ③ 停用行与顺序都按 D-1 / 评审 #9 判（先滤行再取名、顺序无关）。
// ★ 夹具全部是**注入的 agentPresets 桩对象**，零真实服务、零 LLM 调用。

/**
 * 发货模块名的**字面量**副本（修复轮 #6：T-39 正向腿的 actual 侧**不得**取自被测常量
 * `CONSULT_READONLY_MODULES` —— 否则常量拼错时 actual 与 expected 一起错，T-39 仍全绿 = 假腿）。
 * 三者的一致性由两条腿夹住：T-39（本字面量 = actual vs 常量 = expected）与 T-42（常量 vs YAML 实测集）
 * —— 字面量、常量、发货 YAML 任一漂移都会红。
 */
const SHIPPED_MODULE_LITERALS = [
  "@deepseek-ai/dsh-agent-instructions",
  "@deepseek-ai/dsh-tool-fs",
  "@deepseek-ai/dsh-tool-fs-search",
  "@deepseek-ai/dsh-skill-filesystem",
  "@deepseek-ai/dsh-tool-skill",
  "@deepseek-ai/dsh-tool-web",
  "@deepseek-ai/dsh-compaction-basic",
  "@deepseek-ai/dsh-command-compact",
  "@deepseek-ai/dsh-compaction-tool-result-pruner",
]

/**
 * 发货模块名 → compositionInventory 的扁平化声明行。
 * ★ `enabled: true` 显式给出（修复轮 #4）：normalizeModules 只把**字面量 true** 当在用，
 *   平台 flattenRows 恒带布尔 enabled —— 缺键 / "conditional" 一律不算在用。
 */
const shippedRows = (names = SHIPPED_MODULE_LITERALS) =>
  names.map((moduleName, i) => ({ entryId: "e" + i, moduleName, enabled: true }))

/** 0.2.1 预设路线的假宿主（与 T-38 的 t38Host 同形；本组只看闸门判定，不校验派发载荷）。 */
function roPresetHost() {
  return {
    getProvider: () => ({
      name: "spawn",
      capabilities: { agentOptions: true, agentPreset: true, outputSchema: true, depthLimit: true },
      async prepareContinuable() { return {} },
    }),
    async startActivation() {
      return {
        childId: "ro-child",
        result: Promise.resolve({ output: [{ type: "text", text: "ro-ok" }], stopReason: "completed" }),
        dispose: async () => {},
      }
    },
  }
}

/** ctx：预设路线 + 注入的 agentPresets 桩（**不碰真实服务**）。 */
const roPresetCtx = (presets) => ({ subagents: roPresetHost(), get: (n) => (n === "agentPresets" ? presets : null) })

/**
 * 注入的 agentPresets 桩：list() 恒说「已注册」；观测面的各种失效形态各由一个开关造出来
 * （T-41 的受测面：无 inventory / inventory 抛错 / readDocument 抛错 / **readDocument 方法缺失** / 缺该预设行）。
 */
function presetsStub({ rows = null, content = null, inventory, noInventory = false, inventoryThrows = false, docThrows = false, noReadDocument = false } = {}) {
  const p = {
    async list() { return [{ id: "standard" }, { id: "thincoder-consult-ro" }] },
    async readDocument() {
      if (docThrows) throw new Error("readDocument boom")
      return { agentPreset: "thincoder-consult-ro", content }
    },
  }
  if (noReadDocument) delete p.readDocument
  if (!noInventory) {
    p.compositionInventory = async () => {
      if (inventoryThrows) throw new Error("compositionInventory boom")
      return inventory !== undefined
        ? inventory
        : [{ id: "standard", rows: [] }, { id: "thincoder-consult-ro", rows }]
    }
  }
  return p
}

/** 正常内容的 YAML 形态（与发货定义同形：写 / 改显式 false）。 */
const RO_GOOD_DOC = "plugins:\n  - id: tool-fs\n    name: '@deepseek-ai/dsh-tool-fs'\n    config:\n      write: false\n      edit: false\n"

test("T-39（批 41 · 设计档 §八）：模块集合漂移——精确等值（顺序无关），多出 / 缺失 / 停用 / 条件化各自判红", async () => {
  // ① 集合完全一致（**顺序打乱**）⇒ 放行
  //    ★ 修复轮 #6：actual 侧用**字面量**（SHIPPED_MODULE_LITERALS），不取被测常量 —— 常量拼错时本条必须红。
  assert.equal(SHIPPED_MODULE_LITERALS.length, 9,
    "T-39① 前置：字面量夹具必须是发货的 9 个模块（修复轮 #6：独立于被测常量）")
  const shuffled = [...SHIPPED_MODULE_LITERALS].reverse()
  assert.notDeepEqual(shuffled, [...SHIPPED_MODULE_LITERALS], "T-39① 前置：顺序确实被打乱（否则「顺序无关」没被测到）")
  const r1 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({ rows: shippedRows(shuffled), content: RO_GOOD_DOC })))
  assert.equal(r1.ok, true, "T-39①：集合等值（顺序不同）⇒ 必须放行：" + JSON.stringify(r1))
  assert.equal(r1.degraded, null, "T-39①：两层都核验通过 ⇒ degraded 必须恰为 null（不得用空串/含糊值冒充「验过」）")

  // ② 多一个 tool-pwsh ⇒ 拒绝；reason 点名它**且**带「（写/执行类）」文案
  const r2 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({
    rows: shippedRows([...SHIPPED_MODULE_LITERALS, "@deepseek-ai/dsh-tool-pwsh"]), content: RO_GOOD_DOC,
  })))
  assert.equal(r2.ok, false, "T-39②：多出的模块必须判红：" + JSON.stringify(r2))
  assert.match(String(r2.reason), /无法保证只读/, "T-39②：拒绝文案必含「无法保证只读」（T-29 判据）")
  assert.ok(String(r2.reason).includes("多出"), "T-39②：必须点明是「多出」：" + r2.reason)
  assert.ok(String(r2.reason).includes("@deepseek-ai/dsh-tool-pwsh"), "T-39②：必须点名多出的模块：" + r2.reason)
  assert.ok(String(r2.reason).includes("（写/执行类）"),
    "T-39②：词表只做**文案解释器**（拒因来自集合层，评审 #1）——多出的执行类模块必须被解释：" + r2.reason)

  // ③ 少一个 tool-web ⇒ 拒绝且点名
  const r3 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({
    rows: shippedRows(SHIPPED_MODULE_LITERALS.filter((n) => n !== "@deepseek-ai/dsh-tool-web")), content: RO_GOOD_DOC,
  })))
  assert.equal(r3.ok, false, "T-39③：缺失模块必须判红：" + JSON.stringify(r3))
  assert.ok(String(r3.reason).includes("缺失"), "T-39③：必须点明是「缺失」：" + r3.reason)
  assert.ok(String(r3.reason).includes("@deepseek-ai/dsh-tool-web"), "T-39③：必须点名缺失的模块：" + r3.reason)

  // ④ 发货集合**之外**的写能力行若 enabled:false ⇒ 不算在用（放行；评审 #9 的「先滤行」）
  const r4 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({
    rows: [...shippedRows(), { entryId: "x", moduleName: "@deepseek-ai/dsh-tool-pwsh", enabled: false }],
    content: RO_GOOD_DOC,
  })))
  assert.equal(r4.ok, true, "T-39④：停用的**额外**写能力行不算在用 ⇒ 必须放行：" + JSON.stringify(r4))

  // ⑤ 发货集合**之内**的行被 enabled:false 停用 ⇒ 拒绝（= 缺失；§九 钉的方向，无二选一）
  const r5 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({
    rows: shippedRows().map((r) => (r.moduleName === "@deepseek-ai/dsh-tool-fs-search" ? { ...r, enabled: false } : r)),
    content: RO_GOOD_DOC,
  })))
  assert.equal(r5.ok, false, "T-39⑤：发货集合内的行被停用 = 缺失 ⇒ 必须拒绝：" + JSON.stringify(r5))
  assert.ok(String(r5.reason).includes("@deepseek-ai/dsh-tool-fs-search"),
    "T-39⑤：必须点名被停用（= 缺失）的模块：" + r5.reason)

  // ⑥ 发货集合内的行 **enabled: "conditional"**（平台 `!!js` 条件行）⇒ 非布尔取值 = 未证实在用
  //    ⇒ 表现为「缺失」⇒ 拒绝（修复轮 #4 的口径：只有字面量 true 才算在用）
  const r6 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({
    rows: shippedRows().map((r) => (r.moduleName === "@deepseek-ai/dsh-tool-fs" ? { ...r, enabled: "conditional" } : r)),
    content: RO_GOOD_DOC,
  })))
  assert.equal(r6.ok, false, "T-39⑥：enabled conditional 的发货行不算在用 ⇒ 必须拒绝：" + JSON.stringify(r6))
  assert.ok(String(r6.reason).includes("@deepseek-ai/dsh-tool-fs"),
    "T-39⑥：必须点名被条件化（= 缺失）的模块：" + r6.reason)
})

test("T-40（批 41 · 设计档 §八）：配置层**正反双向**——write:true / edit:true 判红；发货形态放行；tool-fs 缺键 / 缺行即漂移", async () => {
  const withLine = (line) => "plugins:\n  - id: tool-fs\n    config:\n      " + line + "\n"

  // ① write: true ⇒ 拒绝
  const r1 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({ rows: shippedRows(), content: withLine("write: true") })))
  assert.equal(r1.ok, false, "T-40①：write 被翻成 true ⇒ 必须判红：" + JSON.stringify(r1))
  assert.match(String(r1.reason), /无法保证只读/, "T-40①：拒绝文案必含「无法保证只读」")
  assert.ok(String(r1.reason).includes("关键配置被翻转"), "T-40①：必须点明失败层 = 关键配置：" + r1.reason)
  assert.ok(String(r1.reason).includes("write: true"), "T-40①：必须点名 write: true：" + r1.reason)

  // ② edit: true ⇒ 拒绝
  const r2 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({ rows: shippedRows(), content: withLine("edit: true") })))
  assert.equal(r2.ok, false, "T-40②：edit 被翻成 true ⇒ 必须判红：" + JSON.stringify(r2))
  assert.ok(String(r2.reason).includes("edit: true"), "T-40②：必须点名 edit: true：" + r2.reason)

  // ③ 正常内容（write: false / edit: false）⇒ 放行
  const r3 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({ rows: shippedRows(), content: RO_GOOD_DOC })))
  assert.equal(r3.ok, true, "T-40③：正常内容 ⇒ 必须放行：" + JSON.stringify(r3))
  assert.equal(r3.degraded, null, "T-40③：两层都核验 ⇒ degraded 恰为 null")

  // ④ ★ 修复轮 #1（交付评审 #1 翻向）：tool-fs 行**缺 write / edit 键** ⇒ **拒绝**。
  //    平台 tool-fs 的 write / edit 缺省 **true** ⇒ 旧口径「缺键 ⇒ 放行」等于静默打开写 / 改工具。
  const missingKeys = "plugins:\n  - id: tool-fs\n    name: '@deepseek-ai/dsh-tool-fs'\n    config:\n      read: true\n"
  const r4 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({ rows: shippedRows(), content: missingKeys })))
  assert.equal(r4.ok, false, "T-40④：tool-fs 缺 write:false / edit:false 键 ⇒ 必须拒绝（平台缺省 true）：" + JSON.stringify(r4))
  assert.ok(String(r4.reason).includes("关键配置被翻转"), "T-40④：必须点明失败层 = 关键配置：" + r4.reason)
  assert.ok(String(r4.reason).includes("write: false"), "T-40④：必须点名缺的 write: false：" + r4.reason)
  assert.ok(String(r4.reason).includes("edit: false"), "T-40④：必须点名缺的 edit: false：" + r4.reason)

  // ⑤ 只删「write: false」一行（edit: false 仍在）⇒ 拒绝，且只点名 write（精确性：不是整篇一律拒）
  const onlyWriteDropped = RO_GOOD_DOC.replace("      write: false\n", "")
  assert.notEqual(onlyWriteDropped, RO_GOOD_DOC, "T-40⑤ 前置：write: false 行必须真的被删掉")
  const r5 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({ rows: shippedRows(), content: onlyWriteDropped })))
  assert.equal(r5.ok, false, "T-40⑤：只删 write: false 一行 ⇒ 必须拒绝：" + JSON.stringify(r5))
  assert.ok(String(r5.reason).includes("write: false"), "T-40⑤：必须点名缺的 write: false：" + r5.reason)
  assert.ok(!String(r5.reason).includes("edit: false"), "T-40⑤：edit: false 仍在 ⇒ 不得点名 edit（精确性）：" + r5.reason)

  // ⑤-b 连 tool-fs 行都不在文档里 ⇒ 无法核验 ⇒ 拒绝（不得当「没这些开关」放行）
  const noFsRow = "plugins:\n  - id: agent-instructions\n    name: '@deepseek-ai/dsh-agent-instructions'\n"
  const r6 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({ rows: shippedRows(), content: noFsRow })))
  assert.equal(r6.ok, false, "T-40 补：文档里没有 tool-fs 行 ⇒ 无法核验 write/edit ⇒ 必须拒绝：" + JSON.stringify(r6))
})

test("T-41（批 41 · 设计档 §八）：观测面缺失与服务面异常——缺失 / 方法缺失降级放行且告警可见；缺行拒绝；模块层优先", async () => {
  // ① 服务只有 list()（无 inventory）⇒ 放行 + degraded 非空 + **派发文本**带告警（FR-3 / FR-4）
  const listOnly = { async list() { return [{ id: "thincoder-consult-ro" }] } }
  const r1 = await resolveConsultReadonlyRoute(roPresetCtx(listOnly))
  assert.equal(r1.ok, true, "T-41①：inventory 不可得 ⇒ 降级**放行**（D-2，不把安全强化变成可用性事故）：" + JSON.stringify(r1))
  assert.equal(typeof r1.degraded, "string", "T-41①：degraded 必须是字符串（不是 undefined/假值）")
  assert.ok(String(r1.degraded).length > 0, "T-41①：degraded 必须非空（评审 #2：不许静默）")
  assert.ok(String(r1.degraded).includes("compositionInventory"), "T-41①：degraded 必须点名缺的观测面：" + r1.degraded)

  const h1 = makeDeps({ subagents: roPresetHost(), services: { agentPresets: listOnly } })
  try {
    const started = await startConsultSession(h1.deps, "问题", undefined)
    assert.equal(started.error, undefined, "T-41①：降级放行 ⇒ start 必须成功：" + JSON.stringify(started))
    const dispatchText = String(started.text ?? "")
    assert.ok(dispatchText.includes("只读预设内容未能核验"),
      "T-41①（FR-3）：degraded 必须并入**派发文本**（warnPrefix 通道，不许只进 console）：" + dispatchText)
    assert.ok(dispatchText.includes("compositionInventory 不可用"),
      "T-41①：派发文本必须带出**具体原因**：" + dispatchText)
    assert.ok(dispatchText.includes("本部署的「只读」仍是弱证"),
      "T-41①：派发文本必须如实声明「只读」仍是弱证（不假装验过）：" + dispatchText)
  } finally { cleanup(h1.sessionId, h1.state) }

  // ② compositionInventory 抛错 ⇒ 放行 + degraded
  const r2 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({ inventoryThrows: true, rows: shippedRows(), content: RO_GOOD_DOC })))
  assert.equal(r2.ok, true, "T-41②：inventory 抛错 ⇒ 降级放行：" + JSON.stringify(r2))
  assert.ok(String(r2.degraded ?? "").includes("compositionInventory"), "T-41②：degraded 非空且点名观测面：" + r2.degraded)
  assert.ok(String(r2.degraded ?? "").includes("compositionInventory boom"),
    "T-41②（修复轮 #2）：degraded 必须带出**被抛出的平台原文**（catch 不许丢弃异常对象）：" + r2.degraded)

  // ③ readDocument 抛错但 inventory 正常 ⇒ **放行 + degraded 非空**（评审 #2：不许静默）
  const r3 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({ rows: shippedRows(), docThrows: true })))
  assert.equal(r3.ok, true, "T-41③：配置层不可用 ⇒ 模块层仍生效、整体放行：" + JSON.stringify(r3))
  assert.equal(typeof r3.degraded, "string", "T-41③：degraded 必须是字符串")
  assert.ok(String(r3.degraded).length > 0, "T-41③：★ 配置层未核验必须**明说**（评审 #2：degraded 为空即红）")
  assert.ok(String(r3.degraded).includes("配置层"), "T-41③：degraded 必须点名失败层 = 配置层：" + r3.degraded)
  assert.ok(String(r3.degraded).includes("readDocument boom"),
    "T-41③（修复轮 #2）：degraded 必须带出**被抛出的平台原文**（catch 不许丢弃异常对象）：" + r3.degraded)

  // ④ inventory 可用但**缺该预设行** ⇒ 拒绝（评审 #11：观测面自相矛盾）
  const r4 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({ inventory: [{ id: "standard", rows: [] }] })))
  assert.equal(r4.ok, false, "T-41④：list() 说有、inventory 说没有 ⇒ 必须拒绝：" + JSON.stringify(r4))
  assert.match(String(r4.reason), /无法保证只读/, "T-41④：拒绝文案必含「无法保证只读」")
  assert.ok(String(r4.reason).includes("观测面自相矛盾"), "T-41④：必须点明自相矛盾：" + r4.reason)

  // ⑤ 集合不符 + readDocument 抛错 ⇒ **仍拒绝**（模块层优先，配置层缺失不掩盖模块层实物）
  const r5 = await resolveConsultReadonlyRoute(roPresetCtx(presetsStub({
    rows: shippedRows([...CONSULT_READONLY_MODULES, "@deepseek-ai/dsh-tool-terminal"]), docThrows: true,
  })))
  assert.equal(r5.ok, false, "T-41⑤：模块层已判红 ⇒ 配置层不可用不得把它降级成放行：" + JSON.stringify(r5))
  assert.ok(String(r5.reason).includes("@deepseek-ai/dsh-tool-terminal"), "T-41⑤：必须点名多出的执行类模块：" + r5.reason)

  // ⑥ readDocument **方法缺失**（不是抛错）⇒ 配置层同样降级放行且告警点名「配置层」（修复轮 · 审计 #4a）
  //   夹具 = presetsStub 的 noReadDocument（**删掉该键**；与 ③ 的「调了抛错」是两条不同分支）
  const noDocSvc = presetsStub({ rows: shippedRows(), noReadDocument: true })
  assert.equal(typeof noDocSvc.readDocument, "undefined",
    "T-41⑥ 前置：夹具必须**没有** readDocument 键（否则测的就不是「方法缺失」）")
  const r6 = await resolveConsultReadonlyRoute(roPresetCtx(noDocSvc))
  assert.equal(r6.ok, true, "T-41⑥：readDocument 方法缺失（非抛错）⇒ 配置层降级放行：" + JSON.stringify(r6))
  assert.equal(typeof r6.degraded, "string", "T-41⑥：degraded 必须是字符串（方法缺失同样不许静默）")
  assert.ok(String(r6.degraded).length > 0, "T-41⑥：★ 方法缺失也必须明说「未核验」（degraded 为空即红）")
  assert.ok(String(r6.degraded).includes("配置层"), "T-41⑥：degraded 必须点名失败层 = 配置层：" + r6.degraded)

  // ⑦ 纯函数层：rows == null ⇒ ok + degraded 恰为「内容观测面不可用」（设计档 §六 该分支；修复轮 · 审计 #4b）
  //   直接 import evaluatePresetDrift 断言（不经服务对象）—— 证明这条告警文案真由 rows==null 分支产生。
  const nullRowsDrift = evaluatePresetDrift({ rows: null })
  assert.equal(nullRowsDrift.ok, true, "T-41⑦：rows == null ⇒ 降级放行：" + JSON.stringify(nullRowsDrift))
  assert.equal(nullRowsDrift.degraded, "内容观测面不可用",
    "T-41⑦：★ rows == null 必须给出该分支的固定告警文案（设计档 §六）：" + JSON.stringify(nullRowsDrift.degraded))
  //    ★ 修复轮 #5：**非数组** rows 与缺失同支（degraded）——不得折成空集后谎报「缺失 9 项」
  const shapeDrift = evaluatePresetDrift({ rows: { rows: [] } })
  assert.equal(shapeDrift.ok, true, "T-41⑦：非数组 rows（形态不符）⇒ 与缺失同支，降级放行：" + JSON.stringify(shapeDrift))
  assert.equal(shapeDrift.reason, null, "T-41⑦：形态不符不得产出拒绝理由（那是谎报内容漂移）：" + JSON.stringify(shapeDrift))
  assert.ok(String(shapeDrift.degraded ?? "").includes("形态"),
    "T-41⑦：非数组 rows 的 degraded 必须点明「形态」不符：" + JSON.stringify(shapeDrift.degraded))
})

test("T-42（批 41 · 设计档 §八）：发货定义同步锁——cordis.patch.yml 的 preset 段（group 递归展开）逐项等于 CONSULT_READONLY_MODULES", () => {
  /**
   * 静态解析器（**规则写死在本腿里**——本仓零依赖，不引 YAML 解析器）：
   *   ① 锚定 Loader 行 id: preset-thincoder-consult-ro（不按行号；不存在的锚 ⇒ null）；
   *   ② 找到该行块里的 plugins:；
   *   ③ 只取 plugins: 之下、缩进更深的**清单行**的 name:（缩进建树；group: true 的行递归展开其子树）；
   *   ④ 排除 preset 自身包装行 name 与 config.name（它们不是清单行的 +2 属性，见下）；
   *   ⑤ 容忍等价格式（修复轮 #3）：name 接受 ' / " 两种引号，锚点行与 plugins: 行允许行尾注释。
   */
  const moduleNamesOfPreset = (src) => {
    // ★ 修复轮 #3（交付评审 #3）：等价格式容忍 —— 行尾注释先剥（引号内的 # 不是注释；
    //   # 需在行首或前面是空白），name: 接受 ' / " 两种引号，锚点行与 plugins: 行都允许行尾注释。
    const stripComment = (raw) => {
      const s = String(raw ?? "")
      let quote = ""
      for (let i = 0; i < s.length; i++) {
        const ch = s[i]
        if (quote !== "") { if (ch === quote) quote = ""; continue }
        if (ch === "'" || ch === '"') { quote = ch; continue }
        if (ch === "#" && (i === 0 || s[i - 1] === " " || s[i - 1] === "\t")) return s.slice(0, i)
      }
      return s
    }
    const all = String(src ?? "").split(/\r?\n/)
    const clean = all.map(stripComment)
    const headIdx = clean.findIndex((l) => /^( *)- id: preset-thincoder-consult-ro[ \t]*$/.test(l))
    if (headIdx < 0) return null                       // 锚点不在 ⇒ 切不到（自证用）
    const headIndent = /^ */.exec(all[headIdx])[0].length
    const block = []
    for (let i = headIdx; i < all.length; i++) {
      if (i > headIdx && /^ *- id: /.test(clean[i]) && /^ */.exec(clean[i])[0].length === headIndent) break
      block.push(all[i])
    }
    let pluginsIdx = -1
    let pluginsIndent = -1
    for (let i = 0; i < block.length; i++) {
      const m = /^( *)plugins:[ \t]*$/.exec(stripComment(block[i]))
      if (m) { pluginsIdx = i; pluginsIndent = m[1].length; break }
    }
    if (pluginsIdx < 0) return null
    const items = []
    for (let i = pluginsIdx + 1; i < block.length; i++) {
      const raw = stripComment(block[i])
      if (raw.trim() === "") continue                  // 空行 / 整行注释（注释已剥 ⇒ 只剩空白）
      const ind = /^ */.exec(raw)[0].length
      if (ind <= pluginsIndent) break                  // 离开 plugins 段
      const m = /^( *)- id: *(\S+?)[ \t]*$/.exec(raw)
      if (!m) continue
      items.push({ index: i, indent: m[1].length, id: m[2], name: null, group: false, children: [] })
    }
    // 归属：清单行**自己**的属性行缩进恰为 item.indent + 2（更深的是子行 / config 体）
    for (let k = 0; k < items.length; k++) {
      const it = items[k]
      let end = block.length
      for (let j = k + 1; j < items.length; j++) {
        if (items[j].indent <= it.indent) { end = items[j].index; break }
      }
      for (let i = it.index + 1; i < end; i++) {
        const raw = stripComment(block[i])
        if (raw.trim() === "") continue
        if (/^ */.exec(raw)[0].length !== it.indent + 2) continue
        const nm = /^ *name:[ \t]*(?:'([^']*)'|"([^"]*)"|([^ \t'"][^ \t]*))[ \t]*$/.exec(raw)
        if (nm) it.name = nm[1] !== undefined ? nm[1] : (nm[2] !== undefined ? nm[2] : nm[3])
        if (/^ *group:[ \t]*true[ \t]*$/.test(raw)) it.group = true
      }
    }
    // 缩进建树（文档顺序 = 先父后子）
    const roots = []
    const stack = []
    for (const it of items) {
      while (stack.length > 0 && stack[stack.length - 1].indent >= it.indent) stack.pop()
      if (stack.length === 0) roots.push(it)
      else stack[stack.length - 1].children.push(it)
      stack.push(it)
    }
    // 展开：group ⇒ 递归子树（其 name: cordis:group **不是**模块名）；叶子 ⇒ 取 name
    const out = []
    const walk = (nodes) => {
      for (const n of nodes) {
        if (n.group) walk(n.children)
        else if (typeof n.name === "string" && n.name !== "") out.push(n.name)
      }
    }
    walk(roots)
    return out
  }

  const patchSrc = readFileSync(new URL("../cordis.patch.yml", import.meta.url), "utf8")
  const parsed = moduleNamesOfPreset(patchSrc)
  assert.ok(parsed !== null, "T-42：cordis.patch.yml 必须能锚定 id: preset-thincoder-consult-ro 并定位到 plugins:")
  assert.deepEqual([...parsed].sort(), [...CONSULT_READONLY_MODULES].sort(),
    "T-42：发货定义的模块名（group 展开后）必须**逐项等于** CONSULT_READONLY_MODULES（多/少/改名都红）——实测 "
      + JSON.stringify([...parsed].sort()))

  // —— 谓词自证（律 3；评审 #5「解析规则写死在腿里」⇒ 解析器本身必须先被证明不是恒真）——
  assert.equal(moduleNamesOfPreset(String(patchSrc).replace("id: preset-thincoder-consult-ro", "id: preset-does-not-exist")), null,
    "T-42 自证：锚点不存在 ⇒ 必须切不到（切片器不是恒真）")
  const synthetic = [
    "    - id: preset-thincoder-consult-ro",
    "      name: '@deepseek-ai/dsh-agent-preset'",
    "      config:",
    "        id: thincoder-consult-ro",
    "        name: '显示名（config.name 不是模块名）'",
    "        plugins:",
    "          - id: a",
    "            name: '@x/tool-a'",
    "            config:",
    "              write: false",
    "          - id: grp",
    "            name: 'cordis:group'",
    "            group: true",
    "            config:",
    "              - id: b",
    "                name: '@x/tool-b'",
  ].join("\n")
  // ★ 修复轮（独立偏离审计 #3）：自证的期望值必须是**同一份合成集**。旧写法拿合成的 @x/* 清单去比
  //   **真实 9 个常量**做 notDeepEqual —— 两侧本就无交集 ⇒ 恒真、证明不了解析器（空转）。
  //   这里先钉死「合成完整集」，再分两条：正向（解析 == 合成完整集）与负向（删一项 ⇒ 解析 != **同一**合成完整集）。
  const SYNTHETIC_FULL = ["@x/tool-a", "@x/tool-b"]
  assert.deepEqual(moduleNamesOfPreset(synthetic).sort(), [...SYNTHETIC_FULL].sort(),
    "T-42 自证②：合成完整集 ⇒ 解析结果必须**等于同一份合成集**（group 被**递归展开**、group 自身名与 config.name 被排除；评审 N1）")
  const dropped = synthetic.replace("              - id: b\n", "")
  const droppedParsed = moduleNamesOfPreset(dropped)
  assert.notDeepEqual([...droppedParsed].sort(), [...SYNTHETIC_FULL].sort(),
    "T-42 自证③：从合成 YAML 删掉一项 ⇒ 必须与**同一份合成完整集**不等（对**真实常量**做 notDeepEqual 是恒真空转 ⇒ 审计 #3）：实测 "
      + JSON.stringify([...droppedParsed].sort()))
  const renamed = synthetic.replace("name: '@x/tool-b'", "name: '@x/tool-b2'")
  assert.deepEqual(moduleNamesOfPreset(renamed).sort(), ["@x/tool-a", "@x/tool-b2"],
    "T-42 自证：改名会被原样读出（比对面不是名字不敏感）")

  // ★ 修复轮 #3（交付评审 #3）**反向腿**：等价格式不算漂移 —— name 换**双引号**、锚点行与
  //   plugins: 行加**行尾注释** ⇒ 解析结果仍须等于同一份合成完整集（格式容忍不是恒真：
  //   前置断言证明这些替换真的落到了文本上）。
  const tolerated = synthetic
    .replace("    - id: preset-thincoder-consult-ro", "    - id: preset-thincoder-consult-ro  # 锚点行尾注释")
    .replace("        plugins:", "        plugins:  # 段起点行尾注释")
    .replace("name: '@x/tool-a'", 'name: "@x/tool-a"')
    .replace("name: '@x/tool-b'", 'name: "@x/tool-b"')
  assert.notEqual(tolerated, synthetic, "T-42 自证④ 前置：等价格式替换必须真的落到文本上（否则这条腿恒真）")
  const toleratedParsed = moduleNamesOfPreset(tolerated)
  assert.deepEqual([...(toleratedParsed ?? [])].sort(), [...SYNTHETIC_FULL].sort(),
    "T-42 自证④（反向）：双引号 name + 锚点/plugins 行尾注释 ⇒ 仍须等于同一合成集（等价格式不算漂移）：实测 "
      + JSON.stringify(toleratedParsed))
})

// ═══════════════ 批 42（看门狗硬结算 · 设计档 2026-10-22-forced-settle-design.md）会诊腿 ═══════════════
//
// 覆盖 §八 的 AC-1（永不 settle ⇒ timeout+grace 内 settled）· AC-3（pending 恰一次）·
// AC-4（强制结算后迟到 reject 不成未处理拒绝、不改账）· AC-6（文案含「未响应 abort」且不含
// 「已终止」/「被终止」）· AC-8（`forced` 只在强制路径写进账本）· AC-12（abort 后 reject ⇒ disarm 无残留）。
//
// ★ **四条独立用例**（批 42 修复轮 · 锚 A-4）：AC-1 · AC-3（多模型）· AC-12 · AC-5 各是一个 `test()`——
//   合在一个 test() 里时「②一红 ⇒ ③④ 不执行」，「删实现即红」对这些腿事实上不可达。
//
// ★ 零真实等待（与设计档 §五 FR-6「注入假定时器/假时钟」对位）：
//   ① 会诊看门狗（`lib/consult.mjs` 的真实 `setTimeout(consultTimeoutMs)`）由本档**捕获后手动点火**
//      ⇒ 不等 consultTimeoutMs（且**先 clearTimeout**：旧值 7ms 与 5ms 轮询只差 2ms，看门狗会自己到点）；
//   ② 宽限计时器（批 42 新增）走 `deps.forcedSettleOpts` 注入的假定时器 ⇒ 不等 60s，点火即到期；
//   ③ 唯一真实等待 = 快行子代理的既有 10ms 夹具延迟（与同档其它腿同量级）。

/** 假宽限计时器（`deps.forcedSettleOpts` 注入缝）：不注册真实定时器，到点由测试显式点火。 */
function makeGraceTimer() {
  const pending = new Map()
  const created = []
  const cleared = []
  const msSeen = []
  let nextId = 0
  return {
    opts: {
      setTimeout: (fn, ms) => {
        nextId += 1
        msSeen.push(ms)
        const hd = { id: nextId, unrefCalls: 0, unref() { this.unrefCalls += 1 } }
        pending.set(hd, fn)
        created.push(hd)
        return hd
      },
      clearTimeout: (hd) => { cleared.push(hd); pending.delete(hd) },
    },
    created,
    cleared,
    msSeen,
    pendingCount: () => pending.size,
    /** 点火：执行当前挂着的宽限回调（模拟「宽限到期」）。 */
    fire() {
      const fns = [...pending.values()]
      pending.clear()
      for (const fn of fns) fn()
    },
  }
}

/**
 * 捕获此后注册的真实 `setTimeout`（同时保留**回调**与句柄）——用来手动点火会诊看门狗。
 * 只按「延迟 == consultTimeoutMs」取用；其余定时器（本档的 sleep / 夹具延迟）照常透传。
 */
function captureRealTimers() {
  const captured = []
  const orig = globalThis.setTimeout
  globalThis.setTimeout = function (fn, delay, ...rest) {
    const hd = orig(fn, delay, ...rest)
    captured.push({ fn, delay, hd })
    return hd
  }
  return {
    ofDelay: (delay) => captured.filter((c) => c.delay === delay),
    restore: () => { globalThis.setTimeout = orig },
  }
}

// ═══ 用例 1/4（锚 A-4：AC-1 · AC-3 · AC-4 · AC-6 · AC-8 独立自证）═══
// ★ 为什么拆成四条独立 test()（批 42 修复轮 · 审计 B）：此前四条挤在**同一个** test() 的 ①②③④ 段里，
//   ②一红 ③④ 根本不执行 ⇒「删掉对应实现即红」对 ③④ 事实上不可达（本轮实测即是）。
// ★ 时序纪律（审计 A）：TIMEOUT 取 300（快行夹具 10ms / 轮询间隔 5ms 的两个数量级以上），且一律
//   **先 clearTimeout、再手动点火** ⇒ 真实看门狗不会自己先到点。旧值 7ms 与 5ms 轮询只差 2ms，
//   轮询稍慢看门狗就会自己到点并把宽限提前武装，断言的起火点因此不可控。
test("批 42 AC-1 / AC-3 / AC-4 / AC-6 / AC-8：假子代理永不 settle ⇒ 预算+宽限内落账；pending 恰一次；文案如实；迟到 reject 不改账", async () => {
  // ★ 时序（审计 A）：300 远大于快行夹具 10ms 与轮询间隔 5ms，且先 clearTimeout 再手动点火。
  const TIMEOUT = 300
  const aborts = []
  let requests = 0
  let rejectLate = null
  const sub = {
    async start(_kind, req) {
      requests += 1
      req.signal?.addEventListener("abort", () => { aborts.push(Date.now()) }, { once: true })
      return {
        // ★ 「永不 settle」的忠实夹具：连 abort 也不响应（这正是 #108 跑 88.8 分钟的那种形态）
        result: new Promise((_resolve, reject) => { rejectLate = reject }),
        dispose: async () => { },
      }
    },
  }
  const h = makeDeps({ subagents: sub, config: { consultTimeoutMs: TIMEOUT } })
  const grace = makeGraceTimer()
  h.deps.forcedSettleOpts = grace.opts
  const cap = captureRealTimers()
  try {
    const s = await startConsultSession(h.deps, "问题", undefined)
    await waitFor(() => cap.ofDelay(TIMEOUT).length >= 1, 1000)
    // 先等子代理真的派发（abort 监听已挂）再点火——否则「abort ⇒ 子代理收到」这条前置不成立
    await waitFor(() => requests === 1, 1000)
    const wd = cap.ofDelay(TIMEOUT)[0]
    clearTimeout(wd.hd) // 真实看门狗不再自己跑（手动点火 ⇒ 零真实等待）
    assert.equal(grace.created.length, 0, "前置：预算未到点 ⇒ **宽限计时器尚未武装**（正常路径零资源成本）")
    wd.fn()             // 看门狗到点：先武装、再发中止
    assert.equal(aborts.length, 1, "前置：看门狗确实经**既有中止写点** abort 了子代理（D5 零新增写点）")
    assert.equal(grace.created.length, 1, "★ AC-1 前置：宽限计时器在**既有中止回调**里武装（删掉 armAfterAbort ⇒ 本行必红）")
    assert.deepEqual(grace.msSeen, [60000], "生产路径宽限缺省 = 60000（D1：用户不可配；本腿不注入 graceMs）")
    grace.fire()        // 宽限到期 ⇒ 强制结算（不等 60s）

    const sess = sessOf(h.state, s.id)
    const digest = await waitDigest(sess)
    assert.equal(sess.pending, 0, "★ AC-3：pending 恰好递减一次（重复递减会到 −1）")
    assert.equal(sess.failed, 1, "强制结算计入 failed（不伪造成功）")
    assert.equal(sess.received, 0, "没有任何真实回复 ⇒ received 必须为 0（绝不伪造成交付）")
    assert.ok(digest.includes("未响应 abort"),
      "★ AC-6：强制结算文案必须含「未响应 abort」：" + digest.slice(0, 400))
    assert.ok(digest.includes("consultation timed out after"),
      "沿用既有超时前缀（不是新造一种超时文案）")
    assert.equal(digest.includes("已终止"), false, "★ AC-6 反向：不得声称「已终止」（我们无法终止它）")
    assert.equal(digest.includes("被终止"), false,
      "★ AC-6 反向（审计 F1 的绕过形态）：也不得写「被终止」——它和「已终止」是同一句话的两个说法")

    // AC-8：账本 settled 事件带**加性**字段 forced:true（且恰一条 —— 单一写点）
    const settled = readConsultLedger(h.deps).rows.filter((r) => r.ev === "settled" && String(r.id) === String(s.id))
    assert.equal(settled.length, 1, "恰一条 settled 事件（settleAndDeliver 单一写点）")
    assert.equal(settled[0].forced, true, "★ AC-8：强制路径写入加性字段 forced:true")
    assert.equal(sess.forced, true, "会话面同样可辨（供 digest/排障）")

    // AC-4：强制结算之后 run.result 迟到 reject ⇒ **不得**成为未处理拒绝、不得再改账
    const unhandled = []
    const onUnhandled = (e) => { unhandled.push(e) }
    process.on("unhandledRejection", onUnhandled)
    try {
      rejectLate(new Error("late reject after forced settle"))
      await sleep(10)
    } finally {
      process.off("unhandledRejection", onUnhandled)
    }
    assert.deepEqual(unhandled.map((e) => String(e?.message ?? e)), [],
      "★ AC-4：迟到 reject 不得变成未处理拒绝（race 已挂 handler；改回裸 await 本行必红）")
    assert.equal(sess.pending, 0, "★ AC-4：迟到 reject 不得再动账（pending 仍为 0）")
    assert.equal(sess.failed, 1, "★ AC-4：failed 不得二次递增")
  } finally {
    cap.restore()
    cleanup(h.sessionId, h.state)
  }
})

// ═══ 用例 2/4（AC-3 的多模型面 + AC-8）═══
// 一个模型在宽限内**正常回复**，另一个永不 settle ⇒ 先到者赢、pending 只归零一次。
// ★ 本腿是「finally 里的 forced.disarm()」在多模型面上的判据：快行 settle 后若未 disarm，
//   它的宽限对象会在下方手动点火时被武装 ⇒ grace.created 变 2 ⇒ 本腿红。
test("批 42 AC-3（多模型）/ AC-8：快行正常回复 + 慢行永不 settle ⇒ 先到者赢、pending 恰一次归零、账本 forced:true", async () => {
  // ★ 时序（审计 A）：300 远大于快行夹具 10ms 与轮询间隔 5ms，且先 clearTimeout 再手动点火。
  const TIMEOUT = 300
  let starts = 0
  const sub = {
    async start(_kind, req) {
      starts += 1
      const mine = starts
      if (mine === 1) {
        // 快行：既有夹具形态（10ms 后 completed）——它自己的宽限计时器在 finally 里被 disarm
        return {
          result: (async () => {
            await sleep(10)
            return { output: [{ type: "text", text: "fast-reply" }], stopReason: "completed" }
          })(),
          dispose: async () => { },
        }
      }
      req.signal?.addEventListener("abort", () => { }, { once: true })
      return { result: new Promise(() => { }), dispose: async () => { } } // 永不 settle
    },
  }
  const h = makeDeps({
    subagents: sub,
    config: { consultTimeoutMs: TIMEOUT, consultModels: [{ provider: "p", model: "a" }, { provider: "p", model: "b" }] },
  })
  const grace = makeGraceTimer()
  h.deps.forcedSettleOpts = grace.opts
  const cap = captureRealTimers()
  try {
    const s = await startConsultSession(h.deps, "问题", undefined)
    const sess = sessOf(h.state, s.id)
    // 先让快行**正常**落地（此时它自己的宽限对象已 disarm）⇒ 再点火看门狗只会武装慢行
    await waitFor(() => sess.received === 1, 2000)
    await sleep(5) // 等快行走完 finally（disarm）——否则本腿会把它的宽限也武装起来（假红）
    await waitFor(() => cap.ofDelay(TIMEOUT).length === 2, 1000)
    for (const wd of cap.ofDelay(TIMEOUT)) { clearTimeout(wd.hd); wd.fn() }
    assert.equal(grace.created.length, 1,
      "宽限只被**慢行**武装（快行已 settle ⇒ 其 disarm 生效；否则本行会 ≥2）")
    grace.fire()
    const digest = await waitDigest(sess)
    assert.equal(sess.pending, 0, "★ AC-3：多模型场景由**最后一个** child 归零（恰一次，绝不 −1）")
    assert.equal(sess.received, 1, "快行的真实回复保留（先到者赢，不被强制结算挤掉）")
    assert.equal(sess.failed, 1, "慢行按失败结算")
    assert.match(digest.split("\n")[0], /1 of 2 replied \(1 failed\)/, "头部行如实报 1/2：" + digest.split("\n")[0])
    assert.ok(digest.includes("fast-reply"), "快行的真实回复经 digest 可见（D4 先到者赢）")
    assert.ok(digest.includes("未响应 abort"), "慢行的强制结算说明在位")
    const settled = readConsultLedger(h.deps).rows.filter((r) => r.ev === "settled" && String(r.id) === String(s.id))
    assert.equal(settled[0].forced, true, "AC-8：该会话确有一路强制结算 ⇒ 账本带 forced:true")
  } finally {
    cap.restore()
    cleanup(h.sessionId, h.state)
  }
})

// ═══ 用例 3/4（AC-12 的既有失败路径 + AC-8 的非强制面）═══
// abort 之后子代理在**宽限内 reject** ⇒ 走既有超时失败路径、**必须 disarm**（无残留计时器），
// 且账本**不得**出现 forced 字段（加性字段只在强制路径写）。
test("批 42 AC-12 / AC-8：abort 后子代理在宽限内 reject ⇒ 既有失败路径同样 disarm（无残留计时器）、账本无 forced 字段", async () => {
  // ★ 时序（审计 A）：300 远大于快行夹具 10ms 与轮询间隔 5ms，且先 clearTimeout 再手动点火。
  const TIMEOUT = 300
  let aborted = 0
  let requests = 0
  const sub = {
    async start(_kind, req) {
      requests += 1
      const result = new Promise((_resolve, reject) => {
        req.signal?.addEventListener("abort", () => {
          aborted += 1
          const e = new Error("subagent aborted by consult watchdog")
          e.name = "AbortError"
          reject(e)
        }, { once: true })
      })
      return { result, dispose: async () => { } }
    },
  }
  const h = makeDeps({ subagents: sub, config: { consultTimeoutMs: TIMEOUT } })
  const grace = makeGraceTimer()
  h.deps.forcedSettleOpts = grace.opts
  const cap = captureRealTimers()
  try {
    const s = await startConsultSession(h.deps, "问题", undefined)
    await waitFor(() => cap.ofDelay(TIMEOUT).length >= 1, 1000)
    await waitFor(() => requests === 1, 1000) // 同用例 1：先等 abort 监听挂上
    const wd = cap.ofDelay(TIMEOUT)[0]
    clearTimeout(wd.hd)
    wd.fn() // 武装 + abort ⇒ 子代理在宽限内 reject（既有失败路径）
    const sess = sessOf(h.state, s.id)
    const digest = await waitDigest(sess)
    assert.equal(aborted, 1, "前置：abort 确实到达子代理（它在宽限内 reject，**不是**强制结算）")
    assert.equal(grace.created.length, 1, "前置：宽限计时器曾被武装（否则下方 disarm 断言恒真）")
    assert.equal(grace.cleared.length, 1, "★ AC-12：既有失败路径同样执行 disarm()——clearTimeout 恰一次")
    assert.equal(grace.pendingCount(), 0, "★ AC-12：settle 之后**无残留宽限计时器**")
    assert.equal(digest.includes("未响应 abort"), false, "既有失败路径的文案逐字不变（不追加强制说明）")
    assert.ok(digest.includes("consultation timed out after"), "仍走既有超时归因（timedOutNow 派生）")
    const settled = readConsultLedger(h.deps).rows.filter((r) => r.ev === "settled" && String(r.id) === String(s.id))
    assert.equal("forced" in settled[0], false,
      "★ AC-8：非强制路径**不得**写入 forced 键（加性字段只在强制路径出现，正常事件逐字不变）")
    assert.equal(sess.forced, undefined, "会话面同样不得被置位")
  } finally {
    cap.restore()
    cleanup(h.sessionId, h.state)
  }
})

// ═══ 用例 4/4（AC-5：dispose 挂死不得把强制结算拖回无界等待）═══
// 判据 = digest 在 waitDigest 的短超时内出现。实现若改回 `await run.dispose()`（强制路径也 await），
// 子代理函数永不返回 ⇒ pending 不归零 ⇒ digest 永不合成 ⇒ **本腿超时必红**。
test("批 42 AC-5：run.dispose() 永不返回 ⇒ 强制结算仍完成（digest 在短超时内合成）", async () => {
  // ★ 时序（审计 A）：300 远大于快行夹具 10ms 与轮询间隔 5ms，且先 clearTimeout 再手动点火。
  const TIMEOUT = 300
  let disposed = 0
  const sub = {
    async start() {
      return {
        result: new Promise(() => { }),            // 永不 settle
        dispose: () => { disposed++; return new Promise(() => { }) }, // 永不返回
      }
    },
  }
  const h = makeDeps({ subagents: sub, config: { consultTimeoutMs: TIMEOUT } })
  const grace = makeGraceTimer()
  h.deps.forcedSettleOpts = grace.opts
  const cap = captureRealTimers()
  try {
    const s = await startConsultSession(h.deps, "问题", undefined)
    await waitFor(() => cap.ofDelay(TIMEOUT).length >= 1, 1000)
    const wd = cap.ofDelay(TIMEOUT)[0]
    clearTimeout(wd.hd)
    wd.fn()
    assert.equal(grace.created.length, 1, "前置：宽限已武装")
    grace.fire()
    const sess = sessOf(h.state, s.id)
    const digest = await waitDigest(sess, 1500) // ← 若强制路径 await dispose，这里**超时**（本腿即红）
    assert.equal(disposed, 1, "★ AC-5：dispose 仍被**调用**（只是不 await）")
    assert.equal(sess.pending, 0, "★ AC-5：dispose 挂死不影响结算（pending 已归零）")
    assert.ok(digest.includes("未响应 abort"), "★ AC-5：digest 照常合成且带强制说明")
  } finally {
    cap.restore()
    cleanup(h.sessionId, h.state)
  }
})



