# 设计文档：机制缺陷分轮修复设计（R1-R5）

- 日期：2026-09-05（R5 立项 2026-09-06）
- 状态：R6-READY（2026-09-07 七次评审 2🔴+2🟡+5🔵 全部折入；**R1-R5 已全部交付**〔155/185/205/215+微修/229 测试，v0.9.0，R5 终验活体通过——见登记表「真机验证记录」〕；**未决实施范围 = R6**〔D-26 维护轮十条，§12〕）
- 上游：[需求文档](2026-09-05-defect-remediation-requirements.md)（含三项用户裁决 D-裁决-1/2/3）· [缺陷登记表](2026-09-05-defect-registry.md)（D-01…D-27，全部条目带证据行号）· 审计报告（thorough 子代理，2026-09-05）
- 平台契约依据：登记表「平台契约要点」五条（jobs 返回 branded string / 通知只含指针 / cancel→abort / run() 无墙钟 / job_output wait 上限 600s）

## 1. 问题陈述

四机制 + codex runner 已功能可用（125 测试绿），但机制层存在 9 项 🔴 阻塞级缺陷（**D-01 空响应坍缩**〔2026-09-05 生产复现 ×2 后由 🟡 升级〕、effort 矩阵级漏校验、eng codex 无钳制静默死亡、followup 绕过预算、后台无单飞、回落活锁、晚到 finalize 复活状态、写任务半途残留、dsh 子代理路径无界等待）与 10+ 项 🟡/🔵 缺陷。根因横切四个层面：执行架构（回合内 await × 平台墙钟）、失败语义（观测缺失 + 分类坍缩）、自愈边界（回落无封顶）、配置一致性（白名单/数据源漂移）。本设计按「诊断先行 → 架构收口 → 语义完备 → 一致性收尾」分四轮修复，每轮独立提交、独立可回滚、可独立验收。

## 2. 总体方案

### 2.1 轮次结构

| 轮 | 主题 | 覆盖缺陷 | 一句话目标 |
|---|---|---|---|
| **R1** | 诊断与校验层 | D-01(观测)、D-02、D-17、D-18、D-23(版本/注释部分) | 先让失败可读、effort 真正能用——后续轮依赖 R1 的观测与收口点 |
| **R2** | 执行架构与进程生命周期 | D-03、D-04、D-05、D-06、D-09、D-10、D-11、D-14、D-16、D-20、D-21、D-22 | 长任务不再静默死亡：jobs 迁移 + 单飞 + 代际检查 + 进程卫生 |
| **R3** | 回落与失败语义完备化 | D-07、D-01(重试/分类)、D-19、**D-06(同步路径单飞扩展)** | 自愈可预测：回落封顶 + 空响应重试分类 + prior 纯净 + 单飞语义补全 |
| **R4** | 一致性与 UX 收口 | D-12、D-13、D-15、D-24 + 文档/测试收尾 | 配置三面同步 + 设置页竞态 + 测量定档 + 评审欠账 |
| **R5** | dsh 路径后台化（DP-1 方案 B） | D-27 | dsh 路径同样免墙钟：advisor 自动判定 + escalate/eng 显式 background 参数 |

轮次依赖：R2 的迁移设计消费 R1 的 codex effort 收口（迁移后的 escalate/eng 复用同一 resolver）；R3 的空响应分类消费 R1 的观测字段；R4 的 D-15 测量消费 R2 的 idle 间隙日志；R5 复用 R2 的整套 jobs 模式（单飞/代际/簿记-done/通知接续）。每轮一个 eng_coder 任务（stages 化）+ 偏离审计 + 交付 code review + 独立提交。

### 2.2 跨切原则（全部轮次共同遵守）

1. **回合内 await 判据**（N-1）：回合内的等待要么预算 ≤ budgetCap（钳制 + 响亮告警），要么派 ctx.jobs；无一处静默截断。
2. **失败可归因**（N-2）：失败文本携带结构化观测（finish.reason.kind、usage、block 计数、exit、stderr 尾部）；不单独依赖 exit code。
3. **single-flight + 代际检查**（N-3）：每会话每机制最多一个在飞任务；后台完成对共享状态的合并带代际校验。
4. **兼容性**（N-6）：config user 层只增不改；advisor 协议对外语义不变；DSH 平台零修改。

## 3. R1 — 诊断与校验层

> 〔时态说明：本节为**已实施记录**（2026-09-05 交付，155/155 绿）——验收条款即已验证事实；未决实施范围为 §6（R4）〕

### 3.1 D-02 effort 三层校验收口（核心）

**现状**：9 个消费点 × 三层矩阵中 6 个 GAP（登记表 D-02 + 审计 §4 矩阵）；`effort-resolve.mjs` 现行为回落到模型 `defaultEffort`（违背 D-裁决-2）。

**方案**：

- **`resolveSupportedEffort` 重规约（dsh 侧）**：回落语义改为**最近支持档**（D-裁决-2）。算法：按档位序 `off < low < medium < high < max` 在目标模型 `reasoningEfforts` 列表中查找；命中→保持；未命中→序距离最近的档；**等距 tie-break 向上取**（DP-2，保推理质量）。元数据不可得（resolveModelInfo 缺失/抛错）→ **fail-open 透传 + 响亮告警**（「保证真正能用」原则：绝不因校验砖化）。回落/透传都带 note。
- **新增 codex 侧 resolver**：`resolveCodexRowEffort(deps, runner, effort)` —— 数据源为 `discoverCodexModels` catalog（**不是** `llm.resolveModelInfo`，审计判定点 ③）。dsh 档位 → codex 档位：先按同名校验是否在模型 `supported_reasoning_levels` 内；不在→最近档（同 tie-break）；`off` → `null`（不传，codex 无 off）。catalog 未命中该模型 → fail-open 透传 + 告警。**档位规范域（有意取舍）**：dsh 五档（off/low/medium/high/max）为唯一配置域，codex 专属档（xhigh/ultra）不可直达——单一规范档位域防配置面分裂；xhigh 级别需求按运行数据另立决策。
- **收口点接线（消灭逐点漂移）**：
  - dsh 行：`consult.mjs:165`、`escalate.mjs:207` 按**行自身**的 provider/model 调 `resolveSupportedEffort`（不是父代理路由）；
  - codex 行：`consult` codex 行、`escalate` codex runner、`eng.mjs:399`、advisor 的 `runner.effort`（`resolveAdvisorRoute` 输出 → `buildCodexArgs` 之前）统一走 `resolveCodexRowEffort`（〔归属注记〕consult codex 行的 **row.effort 接通**完成于 R2——R1 完成 runner.effort 链，row.effort 死配置遗留至 R2 收口，见登记表 D-02）；
  - `eng.mjs:385` 的 dsh 解析只在 dsh 分支执行（codex 分支跳过，消除误导告警）。
- **L2 设置页预检**（UI 决策 UI-1）：池行 effort 下拉按行动态取档位——dsh 行用 `/catalog` 的 provider+model `reasoningEfforts`；codex 行用 codex models catalog；`engCard` 的 EffortInput 补 provider/model 上下文（client.js:1057 现无）。静态枚举下拉全部替换。
- 修正 `effort-resolve.mjs:6` 虚假注释。

### 3.2 D-18 结构化观测三件套

- advisor dsh 循环：流结束记录 `finish?.reason`（kind + failure.message）、block 计数（text/tool-call）、finish 携带的 usage（如有）——追加到失败/空响应文本内 + `console.warn` 留档。
- codex 信封：TIMEOUT/PROCESS_ERROR 诊断加入 usage（input/output tokens，adapter 已捕获未上浮）；stderr 保留改为**尾部 4K**（可用错误在尾，N7）。

### 3.3 D-01 观测部分（重试留 R3）

`advisor.mjs:779` 空响应返回前生成分类行（finish null / stop 零块 / error 无 message 三形态区分 + 观测字段）；R1 不改返回语义（不重试、不烧轮次改动留 R3），只让文本可归因。

### 3.4 D-17 dsh 路径预算钳制

advisor dsh 主路径 + 回落轮：`effective = min(route.timeoutMs, budgetCapMs)`，超限钳制 + 尾部告警（镜像 codex 同步路径既有行为）。

### 3.5 D-23 chore（R1 部分）

package.json 版本锚定 0.7.0；`effort-resolve.mjs:6` 注释修正（其余漂移标记随各自轮次修）。

### 3.6 D-01 热修正式化（R1 新增，2026-09-05 热修的配置化收口）

advisor 单次 LLM 输出预算 `LLM_MAX_TOKENS` 由硬编码改为可配置：全局配置 `advisor.maxOutputTokens`（缺省 16384——2026-09-05 用户授权热修值；合法区间 4096..65536）。**三面白名单同步落地（N-5/US-10，防 D-13 同类漂移）**：PUT 校验（`index.mjs` topAllowed 增该字段 + 数值区间校验）、配置合并（`config-store.mjs` merge 白名单）、运行时读取（`advisor.mjs` 常量改为 effectiveGlobalConfig 读取 + 越界回落缺省并告警）、设置页字段（`client.js`）。热修仅改常量值，本节补齐全部配置面（含回归用例：非法值回落缺省 + 告警；三面白名单同步断言）。

### 3.7 R1 受影响文件

`lib/effort-resolve.mjs`（重规约 + codex resolver）、`lib/codex-adapter.mjs`（导出 catalog 解析）、`lib/advisor.mjs`（含 maxOutputTokens 配置化）、`lib/consult.mjs`、`lib/escalate.mjs`、`lib/eng.mjs`、`lib/index.mjs` + `lib/config-store.mjs`（maxOutputTokens 白名单两面）、`lib/client.js`（UI-1 + 新字段）、`package.json`、`test/codex-runner.test.mjs`

### 3.8 R1 验收标准

1. 矩阵 9 消费点全部转绿：每点 ≥1 回归用例（非法档 → 最近档回落 + note 断言；元数据缺失 → 透传 + 告警断言）；
2. tie-break 用例：medium 缺失且 low/high 皆支持 → 取 high（DP-2 已终裁：向上取，2026-09-05 用户裁决，已实施）；
3. codex 行用例：catalog 命中/未命中/off→null 三形态；
4. 空响应文本含分类行与观测字段；
5. dsh 超限预算钳制告警用例；版本 0.7.0 入库；
6. 全量测试绿（≥125 基线 + 新增）；
7. maxOutputTokens 配置化验收：非法值回落缺省 + 告警用例；三面白名单同步断言（PUT 接受 ⊕ merge 保留 ⊕ 运行时生效）。

## 4. R2 — 执行架构与进程生命周期

> 〔时态说明：本节为**已实施记录**（2026-09-05 交付，185/185 绿）——验收条款即已验证事实；未决实施范围为 §6（R4）〕

### 4.1 codex 写路径 jobs 迁移（D-03 / D-04 / T2.1b 收口）

escalate codex（首次 + **followup**，D-04 一并修）与 eng_coder codex 迁移到 ctx.jobs，**整体复制 advisor 已验证模式**：

- 预算 > budgetCap 且 jobs 可用 → 派发（owner 绑定 agent、cancel 走 ctrl.abort、run() 内自有 watchdog）；预算 ≤ cap → 同步执行（现状）。
- **工具契约**（UI 决策 UI-2）：立即返回 job 句柄 + 显式指令「**等待完成通知后再继续**（发散审计/交付评审）；长任务勿用 job_output wait 阻塞等待（平台等待上限 600s）」——修正 D-09 的虚假承诺文本。
- **簿记进 done() 且仅成功分支**（D-20 一并修）：escalate 的 touchedFiles 合并 + codexThreads 记录、eng 的轮次重置/mutatedThisRun/touched 合并，全部移入任务完成回调的成功分支；失败分支只输出诊断 + partial 的 advisory touched 提示。
- **followup 预算**：followup 路径预算解析与首次一致（runner.timeoutMs → budgetCap 钳制/jobs 判定），消除 D-04 的零余量撞墙；**补 followup effort 复用回归用例**（R1 审计 🔵5：首次交付保存已解析 runner，followup 复用——锁死该语义）。
- jobs 缺失降级：同步 + 钳制 + 响亮告警（镜像 advisor）。

### 4.2 D-21 dsh 子代理路径（DP-1，评审裁定）

**推荐方案 A：本轮钳制告警，jobs 迁移另立项**——escalate dsh（:220）与 eng dsh（:460）的 `await run.result` 加内部截止（budgetCap，AbortController + 定时器），到点 abort + 响亮告警（「dsh 子代理路径受平台墙钟约束，超限任务被终止；如需长任务请走 codex runner 或拆分 stages」）。理由：eng_coder dsh 同步交付驱动整个工程流程（交付→审计→评审），迁 jobs 是协议级重构，超出缺陷治理范畴；且历史 14 轮 eng_coder 交付未见 >600s 死亡记录，钳制即可消除静默风险。备选方案 B（一并迁移）如用户裁定则扩展本轮范围。escalate.mjs:4 头注释同步修正。

### 4.3 D-06 single-flight

模块级在飞表（**复合键 `sessionId + mechanism`**，每机制独立单飞槽位——同会话 advisor 在飞不阻塞 escalate/eng 派发，反之亦然，对齐 US-4/N-3 的 per-session-**per-mechanism** 语义）；advisor + 迁移后的 escalate/eng codex 派发前检查，命中 → 拒绝并告知在飞 job id 与接续方式；settle 时清除。

### 4.4 D-10 代际检查

`sessionState.advisorGeneration`（整数，随 F12 视图持久化）；eng 交付重置、F11 类型切换、config apply-session 变更时 **+1**；job 派发时捕获代际，finalize 应用前校验——不匹配 → 丢弃变更 + 完成通知注明「状态代际已变更，本轮结果不并入（原文可读）」。

### 4.5 D-05 / D-11 / D-14 / D-16 / D-22

- **D-05**：`started` 即 branded string，直接使用；测试 fake 改返回 string（消除掩蔽，审计 N26）。
- **D-11**：同步截断杀路径的返回文本加回滚指引（「半途写入可能残留：对照 partial 输出与 Touched 提示检查工作区，必要时 git 回滚」）+ partial 内 Touched 行作 advisory 解析；启动清扫：插件启动时扫描 `tmpdir()/thincoder-codex-*` 陈旧目录（>24h）删除 + warn；进程级清扫因无可靠属主标记列为文档化边界（宿主硬死孤儿 = B9 边界保持）。
- **D-14**：adapter 维护全局活跃 codex 子进程计数，上限 `codexCli.maxConcurrent`（默认 8，设置页可配）；超限 fail-fast 并明确报错（不排队——简单诚实）。
- **D-16**：mitigation 收口——钳制告警（已有）+ 设置页提示（已有）+ 派发时若 `budgetCapMs ≥ 600000` 输出一次不变式提醒（「确认已同步提高平台 maxWallMs 且 cap < wall」）；登记表标注不可完全强制。
- **D-22**：`codexFailureCount` 会话销毁清理（挂到既有 session/disposed 清理组）；consult 子代理 run 补 dispose；`cleanCwdRoot` 死旋钮删除（消费点与注释一并清）。
- **R2 附带观测**（供 D-15 与 maxWallMs 留证）：adapter 退出时记录本次运行最大静默间隙（lastActivityAt 差分最大值）到诊断/warn。
- **R1 code review 🔵 折入**：① escalate effort-note 前缀统一为 `\n\n[thincoder-suite]`（与其余消费点对齐）；② advisor codex 行的 `resolveCodexCliGlobals` warnings 并入 `route.warnings`（手编 config 非法 codexCi 值运行时同样响亮告警）。

### 4.6 R2 受影响文件

`lib/advisor.mjs`、`lib/escalate.mjs`、`lib/eng.mjs`、`lib/consult.mjs`（dispose）、`lib/index.mjs`（清理组接线）、`lib/codex-adapter.mjs`（计数/观测/死旋钮）、`lib/config-store.mjs` + `lib/client.js`（maxConcurrent 字段）、`lib/session-store.mjs`（generation 白名单）、`test/codex-runner.test.mjs`

### 4.7 R2 验收标准

1. 迁移路径单测（假 jobs）：escalate/eng codex 预算 >cap → 派发、簿记在 done 内成功分支恰好一次、句柄文本含接续指令；followup 预算用例；
2. single-flight 用例：在飞时二次调用被拒并含 job id；
3. 代际用例：派发后 generation 变更 → finalize 丢弃 + 通知注明；
4. D-20 用例：失败交付不重置轮次/不置 mutated；
5. job id 真实渲染（fake 返回 string）；D-09 文本修正断言；
6. 全局并发上限 fail-fast 用例；启动清扫用例；D-22 三项卫生用例；
7. dsh 路径（DP-1 方案 A）截止告警用例；
8. **US-3 token 截断存活性回归**：模拟 job_output 保尾截断（头部丢弃 + [output truncated] 标记）→ 尾部 design token 完整可提取——钉死平台 retainTail 契约（用户故事-测试映射补全）。

## 5. R3 — 回落与失败语义完备化

> 〔时态说明：本节为**已实施记录**（2026-09-05 交付含补丁轮，205/205 绿，`4d33cf8`+`7222811`）——验收条款即已验证事实；未决实施范围为 §6（R4）〕

### 5.1 D-07 回落封顶（D-裁决-3）

- `codexFailureCount.delete` 移到**回落轮结果之后**（修正 :1015 顺序错误）；
- 新增 `fallbackFailureCount`（会话内存态）：回落轮失败 +1、成功清零；
- **连续 2 次回落失败 → 硬停**：返回「双路由皆不可用」+ 配置诊断（codex 路由与 dsh 路由各自状态、最近失败码、修正指引：网络/代理/runner 切换/provider 检查）；
- **计数器语义（精确）**：`codexFailureCount`（既有 Map）——codex 路由失败 +1、**任一路由成功清零**、回落轮结果产出后才执行 delete（顺序修正）；`fallbackFailureCount`（新增）——回落轮失败 +1、任一路由成功清零。两计数器独立于 advisorRound（失败不烧轮次），任何组合的零进度循环在「连续 2 次回落失败」硬停处终止。〔实现语义（R3 交付采纳，2026-09-05 架构确认）：delete 仅在回落轮**成功**时执行——回落失败不清零 codex 计数，下一调用直接再进回落轮（不交替），连败 2 次硬停 = 4 次调用封顶；依据 D-裁决-3「不再交替重试」〕

### 5.2 D-01 重试与分类（D-裁决-1）

- 空响应（R1 分类为非基础设施形态）→ **自动重试一次**（复用 messages，同 stall 重试通道语义但独立计数）；再空 → 返回 **"Advisor:" 前缀**的可归因失败（分类 + 观测字段 + 「重试一次仍空」），不烧轮次、不写 prior。〔勘误（R3 交付 probe 证实）：基线空响应占位文本本就带 Advisor: 前缀、不烧轮次——本节交付的是终态语义，属措辞收敛而非行为修正〕；
- 分类为基础设施形态（error 无 message / stall）→ 走既有失败路径，不空重试。

### 5.3 D-19 prior 纯净化

finalize 区分 `body`（评审正文）与 `body + 机制性后缀`（回落告警/effort note/截断提示）：`lastAdvisorOutput` 只存 body；返回文本照常带后缀（可见性不变）。收敛轮 prior 注入因此不再携带插件杂讯。

### 5.4 D-06 同步路径单飞扩展（2026-09-05 R2 审计裁决折入，三次评审 🔴 补全）

R2 交付的在飞表检查仅覆盖 jobs 派发入口；同机制 >cap job 在飞期间，≤cap 同步调用仍会并行执行（轮次/prior 双写窗口）。本节将 `checkInFlightJob` 扩展到三机制**全部入口**（含同步路径）：同机制在飞时任何新调用被拒（含在飞 job id 与接续指引），settle 双分支清除不变。

### 5.5 R3 受影响文件与验收

文件：`lib/advisor.mjs`、`lib/escalate.mjs`、`lib/eng.mjs`、`test/codex-runner.test.mjs`。〔2026-09-05 R3 交付勘误：原清单漏 eng.mjs 且误限 escalate 仅注释，与 §5.4 三机制全入口要求冲突——以 §5.4 契约为准修正；escalate/eng 入口检查随补丁轮交付〕
验收：① 活锁封顶用例（codex 败×2 → 回落败×2 → 硬停文本含双路由诊断）；② delete-after-result 顺序用例；③ 空响应重试一次→仍空→前缀失败不烧轮次用例；④ 重试后成功不重复计轮用例；⑤ prior 纯净用例（后缀不进 lastAdvisorOutput）；⑥ **正向清零用例**——回落轮成功后 codexFailureCount/fallbackFailureCount 归零（单次未来失败不触发硬停）；⑦ **同步路径单飞用例**——同机制 >cap job 在飞时 ≤cap 调用被拒（D-06 扩展）。

## 6. R4 — 一致性与 UX 收口

> 〔时态说明：本节为**已实施记录**（2026-09-05 交付）——验收条款即已验证事实；D-15 测量与
> D-24 eng.mjs 评审补跑为收尾阶段任务（见登记表终态），非本节代码交付范围〕

### 6.1 D-12 保存竞态（UI 决策 UI-3）

busy 期间禁用全部表单输入（非仅按钮）；保存成功后的 refreshView **不整体替换草稿**——只重放未被用户触碰（自保存发起时起）的字段，触碰字段保留用户值并出提示条「保存期间有编辑，已保留你的修改」。

### 6.2 D-13 override runner 三面同步

方向：**全面接受**（apply-session 已接受）——`ADVISOR_OVERRIDE_GROUP_PATHS` + `advisor_config` coercion 增加 runner（校验走 `normalizeRunnerValue`）；session-store 持久化白名单加 runner；client.js:726 注释修正。往返用例：set runner → 模拟重启恢复 → 仍在。

### 6.3 D-15 idle 档位测量（测量任务，非代码修复）

消费 R2 的最大静默间隙日志：真机跑 ≥3 次高 effort codex 任务，若健康流出现 >240s 静默间隙 → 建议 idleTimeoutMs 默认上调或 effort 感知（数据登记入研究文档附录，默认值是否改动由数据说话）。**判定规则（显式）**：任一健康高 effort 运行出现 >240s 静默间隙 → 附数据提议默认值上调；全部 ≤240s → 维持 300s 默认并记录测量结论。

### 6.4 D-24 + 收尾

eng.mjs 独立 code review 补跑（advisor type=code，两轮环境阻塞的欠账）〔**已完成 2026-09-05**：评审通过零 🔴，1🟡+5🔵 转 D-26 后续维护轮——登记表 D-24 已修；设计头部如有「待补跑」措辞以登记表终态为准〕；全部登记条目状态核对；METHODOLOGY 文档历史记入 R0-R4；版本号推进至 0.8.0。**R1 审计 🔵 遗留收口**：① per-point fail-open（元数据缺失）补 1-2 个接线级用例（或接受 resolver 级覆盖并记录）；② 登记表 D-18「TIMEOUT 信封补 usage」措辞收窄（仅 idle-watchdog 信封带结构化 usage，墙钟信封在诊断串内——设计 §3.2 本就只要求诊断）；③ `discoverCodexModels` 缓存无 refresh 通道（R1 评审 #3）——加 refresh 参数或注释缓存语义；④ 验证 docs/README.md 三份新文档登记在案（收尾核对）。〔D-02 用例数 17→19 已随二次评审落盘，原 ② 项关闭〕**〔收尾注记 2026-09-05〕**D-25（token-secret 加固，已修）与 D-26（eng.mjs 评审跟进批，待后续维护轮）详见登记表对应条目——未尽事项以**登记表为单一事实源**。

### 6.5 R4 受影响文件与验收

文件：`lib/client.js`、`lib/advisor.mjs`、`lib/escalate.mjs`、`lib/session-store.mjs`、`lib/index.mjs`（如 coercion 共享——交付确认无需：coercion 全在 advisor.mjs，index.mjs 零改动）、`test/codex-runner.test.mjs`、`METHODOLOGY.md`、`package.json`、`docs/2026-09-05-defect-registry.md`（终态核对）。〔escalate.mjs 为 R3 code review 收尾折入项 ② 所需——2026-09-05 补入清单；codex-adapter.mjs 为 §6.4 ② 缓存语义注释所需——2026-09-05 R4 交付补入（注释零行为变化，与 escalate.mjs 先例同型的清单勘误）；登记表为 §6.4 ⑥ 终态核对与 D-15/D-18 标注所需〕

**R3 code review 收尾折入（4 项小修）**：① 回落失败路径后缀补「回落失败 X/2」计数（与不可达路径对齐）；② escalate dsh 超时竞态分支补 codexFailureAdvisory（与 eng 对齐）；③ clearCodexFailureCount 更名 clearAdvisorRouteFailureState + 别名导出；④ advisor JSDoc 补 single-flight "Error:" 前缀例外注记。各 ≥1 断言。

验收：① 竞态用例（保存期间编辑被保留 + 提示）〔**交付形态勘误（2026-09-05 R4）**：本仓库无 client 测试面（client.js 为浏览器 CJS bundle，node --test 无法驱动 DOM/React）——① 按 §6.1 验收为代码级实现 + node --check 通过（登记表 D-12 终态如实标注）；后端可测面（runner 往返）照常带用例〕；② runner 往返用例；③ 测量数据登记〔登记表 D-15 标注判定规则与执行阶段——测量本身属真机验证阶段〕；④ eng.mjs 评审报告落档〔架构会话收尾阶段补跑——非 eng_coder 任务面，登记表 D-24 已裁决处置〕；⑤ 登记表全条目终态核对。〔R1 审计 🔵 ①② 交付记录：① per-point fail-open 接线级用例 ×2（escalate dsh 行 + advisor dsh 主路径——元数据不可得 → 原样透传 + note 入尾部 + 响亮告警）；② 缓存语义注释落地 codex-adapter.mjs（refresh 通道一期已有——注释补「快照随首次发现、UI 刷新才更新」语义）；③ D-18 措辞收窄经代码核对**前提不成立**（墙钟 TIMEOUT 信封同样带结构化 usage 字段，codex-adapter.mjs 两处 envelope 构造均传 usage、R1 用例即墙钟路径断言 env.usage 深等）——按 §9 验收第 1 条「终态与代码一致」维持原措辞并登记核对结论（见登记表 D-18）；④ docs/README.md 三文档登记核验 ✓〕

## 7. R5 — dsh 路径后台化（DP-1 方案 B，2026-09-06 立项）

> 〔时态说明：本节为**已实施记录**（2026-09-06 交付，微轮 1+codex 轮，229/229 绿，`4c84d43`；R5 终验 2026-09-07 活体通过——见登记表「真机验证记录」）——验收条款即已验证事实；未决实施范围为 §12（R6）〕

> 〔背景与终裁修订〕R4 交付后的真机使用中，用户裁定**复活 DP-1 方案 B 并全量三路径**：不改 DSH 平台默认（maxWallMs 600s 保持），由插件自建后台机制让 dsh 路径同样免墙钟。DP-1 终裁更新见 §8。登记表 D-27。

### 7.1 advisor dsh 循环（自动判定，与 codex 完全对称）

dsh 路由的评审预算 `route.timeoutMs > budgetCapMs` 且 ctx.jobs 可用 → 派后台 job：run() 内执行完整 `runAdvisorToolLoop`（纯进程内 llm.stream 调用，无子进程），finalize 在 done 内恰好一次（R2 codex 模式全套复用：单飞槽位 advisor、代际捕获校验、prior/token 语义不变）；≤cap 或 jobs 缺失 → 同步执行（D-17 钳制与告警保留——它保护的就是同步路径）。**job 内预算不钳制**（run() 无墙钟，D-17 钳制只适用于同步路径——route.timeoutMs 在 job 内全额生效）。**派发降级**：jobs.start 抛错或派发失败 → 同步 + 钳制 + 响亮告警（advisor codex 先例同款 try/catch 降级）；ctx.llm 在 run() 内不可用属同类失败形态，经同一降级路径回收（验收⑦真机全链为该假设的硬门禁）。**兜底覆盖与 deadline 合成**：本路径同样受 `dshBackgroundTimeoutMs` 兜底（挂起的 llm.stream 不会永悬 job）；**合成规则 = max(route.timeoutMs, dshBackgroundTimeoutMs)**——任务预算为主（预算更大的评审不被兜底误杀），兜底只捕获无进展挂死。**派发判定时点 = 入口路由解析时**：同步调用（≤cap）中途回落到 >cap dsh 轮的，回落轮仍按 D-17 钳制（N-1 合规的已接受残余——同步调用的回落轮不升级为后台）。**降级两段式**：(a) 派发前 ctx 可用性预检（jobs 服务缺失/派发抛错）→ 同步 + 钳制 + 响亮告警；(b) run() 内假设破裂（ctx.llm 不可用等）→ **不可恢复**，job 以诊断失败收场（句柄已返回，无法回退同步）——验收⑦真机全链为该假设的硬门禁（含 advisor dsh >cap 真机用例）。

### 7.2 escalate/eng dsh 子代理（显式 `background` 参数）

- 工具契约新增可选参数 `background`（默认 false）：**不传** = 现状（同步执行 + budgetCap 内部截止——短任务的快路径体验不变，今日全部任务 <540s）；**传 true** = 派后台 job：run() 闭包内 `ctx.subagents.start` + `await run.result`（ctx 引用在 job 生命周期内有效——与 advisor jobs 先例同假设；session 优雅销毁 → job cancel → abort 传递），完成通知**只含指针**、交付文本/失败诊断经 job_output 读取（平台契约 #2，D-09 同语义）；簿记（escalate touchedFiles、eng 交付簿记）在 done 成功分支恰好一次（D-20 模式复用）。**单飞契约**：background 派发与同步入口共用同一复合键槽位（setInFlightJob 于派发同步块、settle 双分支清除——R3 全入口检查之上，派发点二次检查保留）。**followup 续轮**：escalate followup 同样接受 background 参数（续轮任务往往更长，语义一致）。**降级两段式（与 §7.1 同）**：(a) 派发前预检/派发抛错 → 同步 + 钳制 + 响亮告警；(b) run() 内 ctx.subagents 不可用 → job 以诊断失败收场（不可恢复——句柄已返回）。
- 返回文本 = job 句柄 + UI-2 接续指令（复用共享 dispatch reply helper，机制名泛化）。
- **挂死兜底（覆盖全部三条后台路径，含 §7.1）**：后台 dsh 任务有兜底 deadline（防子代理挂起/llm.stream 挂起导致 job 永悬）——新全局配置 `dshBackgroundTimeoutMs`（缺省 1_800_000=30min，合法 60_000..3_600_000；三面白名单 + 设置页字段 + 非法回落缺省告警）；到点 abort（子代理 abort / 流 abort）+ 超时信封（partial 保留）。
- eng_coder 流程契约变更（架构师侧）：background 任务返回句柄 → **等完成通知后再发起发散审计/交付评审**（与 codex 长任务同纪律）。

### 7.3 R5 受影响文件与验收

文件：`lib/advisor.mjs`（dsh 循环派发 + reply 泛化）、`lib/escalate.mjs`、`lib/eng.mjs`（background 参数）、`lib/index.mjs` + `lib/config-store.mjs` + `lib/client.js`（dshBackgroundTimeoutMs 三面 + 设置页）、`test/codex-runner.test.mjs`、登记表、`METHODOLOGY.md`（R5 交付记录）、`package.json`（版本 0.9.0）——R4 清单先例。

验收：① advisor dsh >cap 自动派发用例（假 jobs：run() 内跑循环、finalize 恰好一次、句柄含接续指令；≤cap 同步不变断言；**job 内预算不钳制断言**；**deadline 合成 = max(预算, 兜底) 断言**）；② escalate background=true 派发 + 子代理在 run() 内执行 + 簿记 done 内成功分支 + 兜底 deadline abort 用例（**含 cancel 传播用例：job kill → 子代理 abort**）；③ eng background 同款 + 失败不簿记（D-20 断言复用）；④ 三路径单飞槽位互不阻塞断言（含 background 派发占位/清除）；⑤ dshBackgroundTimeoutMs 三面同步 + 非法回落用例；⑥ 全量 ≥215 绿 + **派发降级错误路径用例 ×2**（jobs.start 抛错 / jobs 缺失 → 同步 + 钳制 + 响亮告警断言，advisor 与 escalate/eng 各一）；⑦ 真机：一次 background eng_coder 全链（句柄→通知→交付→审计接续）+ **一次 advisor dsh >cap 真机评审**——ctx 服务在 run() 内可用的假设硬门禁。

## 8. UI/交互决策汇总（METHODOLOGY 要求集中呈现）

| # | 决策 | 轮次 |
|---|---|---|
| UI-1 | effort 下拉全部目录化：dsh 行按行 provider+model 取 /catalog 档位；codex 行取 codex catalog；engCard 补模型上下文。**〔2026-09-05 实施裁决〕engCard 上下文来源**：codex 后端 → CodexEffortInput 随 codexCli.model 联动（真实目标模型）；dsh 后端 → dsh 目录档位并集（目标=父代理路由，设置页不可知；运行时 L1 兜底） | R1 |
| UI-2 | 后台派发返回文本 = job 句柄 + 「等完成通知再继续；勿用 job_output wait 阻塞等长任务」显式指令 | R2 |
| UI-3 | 保存期间全表单禁用；保存后草稿不被未触碰字段的刷新覆盖，触碰字段保留 + 提示条 | R4 |
| UI-4 | 设置页新增 `codexCli.maxConcurrent` 字段（默认 8，提示全局 codex 进程上限） | R2 |
| UI-5 | 设置页新增 `dshBackgroundTimeoutMs` 字段（默认 30min，提示 dsh 后台任务挂死兜底）；escalate/eng 工具的 background 参数说明进工具描述 | R5 |

## 9. 设计决策点（评审时请用户裁定）

| # | 问题 | 终裁 |
|---|---|---|
| DP-1 | D-21 dsh 子代理路径处置 | **初裁（2026-09-05）：方案 A 钳制告警**；**修订终裁（2026-09-06，用户裁定）：方案 B 全量三路径**——advisor dsh 自动按 timeoutMs 判定、escalate/eng 显式 background 参数、同步快路径与钳制保留（R5 实施，见 §7） |
| DP-2 | 最近支持档等距 tie-break | **已终裁（2026-09-05）：向上取**（R1 已实施） |
| DP-3 | 全局 codex 并发上限默认值 | **已终裁（2026-09-05）：8**（可配，UI-4） |

## 10. 验收标准（项目级，映射需求 §5）

1. 缺陷登记表**全部在册条目**（动态上界——2026-09-07 立项 R6 时为 D-01…D-27）终态 ∈ {已修, 已裁决处置, 已驳回(附证据), 待测量(附数据), 延期至后续轮(附理由)}——〔D-26 原适用末类，R6 立项后由 R6 修复收口〕；
2. 单测全绿且每修复 ≥1 回归用例（R1-R5 各节验收条款即用例清单）；
3. 真机验证：advisor（jobs 派发 + 回落链 + token 签发）、eng_coder（一次交付 + 一次 background 全链）、escalate（含 followup）、consult（含 codex 行）各一次成功；复测「空响应」「effort 秒死」两受害场景（前者给出可归因诊断或重试后成功；后者不再秒死）。**回退规则**：受害场景自然复现失败时，以故障注入验证对应诊断/重试/回落路径作为等效验收——生产复现实录已在登记表 D-01/D-02 留证；
4. git：R1-R5 每轮独立提交 + 版本 0.7.0→0.9.0 推进 + 文档登记与 METHODOLOGY 历史记入。

### 10.1 用户故事-测试映射（METHODOLOGY 纪律，每故事 ≥1 用例）

| 用户故事 | 测试映射 |
|---|---|
| US-1 可预测回落 | R3 验收①②（活锁封顶双路由诊断 / delete-after-result 顺序） |
| US-2 空响应可诊断 | R1 已交付（空响应四形态分类+观测用例组）；R3 验收③④（重试语义） |
| US-3 token 可恢复 | R2 验收⑧（job_output 保尾截断下 token 完整可提取） |
| US-4 后台单飞 | R2 验收②（复合键：同机制拒绝含 job id / 异机制不受阻）+ R3 验收⑦（同步路径扩展——全部入口单飞） |
| US-5 长任务完整执行 | R2 验收①（escalate/eng codex 迁移 + 簿记 done 内成功分支）+ R5 验收①②③（dsh 路径后台化：advisor 自动判定 / escalate·eng background 参数 + 兜底 deadline） |
| US-6 写任务安全 | R2 验收④⑥（D-20 失败不簿记 / 回滚指引·清扫·卫生） |
| US-7 池行能力校验 | R1 已交付（9 消费点逐点用例）；R2 D-02 遗留接通用例 |
| US-8 保存时拦截 | R1 已交付（L2 目录化下拉）；R4 验收①（竞态） |
| US-9 进程卫生 | R2 验收⑥（fail-fast/清扫/三项卫生）；**边界**：宿主硬死孤儿=文档化边界（B9），启动清扫缓解——2026-09-05 二次评审确认该差距被正式接受 |
| US-10 配置单一事实源 | R1 已交付（maxOutputTokens 三面同步用例）；R4 验收②（runner 三面往返） |
| US-11 工程过程 | 各轮独立提交 + 版本推进（本节第 4 条）+ 登记表状态核对（R4 验收⑤） |
| US-12 失败可读 | R1 已交付（stream observation + codex usage/stderr 保尾用例） |
| （R6 追溯映射） | ⑧ 兜底超时回滚指引 → US-6/US-12；⑨ 线程清理对称 → US-9；④⑤ 空输出一致性与签收文案 → US-12；⑥⑦ 单一实现 → US-11 |

## 11. 风险与边界

- **宿主硬死孤儿**（B9）：jobs 只护优雅销毁；R2 的启动清扫缓解陈旧目录，进程级清扫无可靠属主标记——保持文档化边界。
- **maxWallMs 绑定路径未在平台源码钉死**：设计依据 = 本插件 D.1 实测 + 两会话 15+ 次同形截断；R2 钳制告警本身不依赖该绑定成立（绑定不成立时钳制只是多余但无害）。
- **dsh 路径残余风险（R5 后）**：仅剩默认同步快路径（background=false / 预算 ≤cap / jobs 缺失降级）——该路径钳制+告警**按设计保留**（它保护的就是墙钟内的同步执行）；长任务经自动判定或显式 background 进入后台后无墙钟。〔原「方案 A 数据不足」措辞已被 2026-09-06 方案 B 终裁取代〕

## 12. R6 — D-26 维护轮（2026-09-07 立项，打磨级小修批）

> 〔定位〕D-26 登记的 10 项非阻塞打磨（3🟡+7🔵，全部来自已通过评审的跟进建议，file:line 与处方在登记表 D-26 行）——单轮清完，验收以既有测试面回归为主。

| # | 修复（处方 = 评审建议） |
|---|---|
| ①🟡 | eng codex 分支捕获 resolveCodexCliGlobals 的 warnings 逐条 warn()；defaultTimeoutMs/idleTimeoutMs 本地校验回落补 warn（escalate 同款点一并核查） |
| ②🔵 | engineeringToggle 移除未用参数 configDefaultEngineering（同步调用方） |
| ③🔵 | eng 单飞拒绝返回补 warnPrefix() 前缀 |
| ④🔵 | 空输出归类统一：codex ok+空文本按 dsh 同语义处理——交付 + 显式「(empty report)」标记（不静默翻转类别；两路径一致） |
| ⑤🔵 | F10 盘回填文案区分两态：盘有记录但未传 token →「本会话已签发但本次未传」；无盘记录 →「从未签发」 |
| ⑥⑦🟡 | eng dsh 同步路径（:710-723）内联簿记替换为 deliverBookkeeping 调用（四路单一实现落地为真，注释相符） |
| ⑧🟡 | dsh 后台兜底超时信封 code 改 "ABORTED"（触发 codexFailureAdvisory 回滚指引，与 codex TIMEOUT 对称） |
| ⑨🔵 | escalate codex jobs reject 分支补 codexThreads.delete（与失败分支对称） |
| ⑩🔵 | eng 兜底文案空格/句读统一 |

**受影响文件**：`lib/eng.mjs`、`lib/escalate.mjs`、`lib/index.mjs`（如 toggle 调用方）、`test/codex-runner.test.mjs`、登记表（D-26 → 已修）、`METHODOLOGY.md`（一行历史）、`package.json`（0.9.1）。

**验收**：①③⑧⑨⑩ 各 ≥1 断言；② 编译级核验（参数移除后 node --check 通过 + 既有测试全绿——纯无行为重构；调用方同步更新）；④ 两路径空输出断言一致（eng.mjs codex ok+空文本分支与 dsh :633 一致）；⑤ 两态文案断言（eng.mjs F10 盘回填分支）；⑥⑦ 行为等价替换（既有 dsh 成功路径断言核销）+ 四路径单一实现断言；全量 **≥229+新增断言数** 绿（R6 交付报告列明新总数）；版本 0.9.1；登记表 D-26 → 已修。〔文件归属：②=eng.mjs 函数签名 + index.mjs 调用方；④⑤=eng.mjs；⑨=escalate.mjs；①⑥⑦⑧⑩=eng.mjs/escalate.mjs 各自评审报告所列点〕
- **平台契约依赖**：jobs 契约五条由审计钉死于当前部署版本；DSH 升级若变更契约，登记表「平台契约要点」需复核。
