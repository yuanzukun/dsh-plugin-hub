# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-08-20

Initial release.

### Added

- Deterministic, rule-based redaction (API keys, JWTs, high-entropy tokens,
  `.env` values, bearer tokens, URL credentials, absolute paths, opt-in emails,
  custom regexes) with correlated salted fingerprints.
- Session export to Markdown, JSONL, HTML and PDF (headless-Chromium optional).
- On-disk archive management with chunking, search/filter and path-traversal
  guarding.
- Compliance metadata headers (session, models, sanitization level, optional
  SHA-256 content hash) and a trend/audit view.
- Model-facing tools + slash commands, plus a harness-independent `./core`
  library subpath.
