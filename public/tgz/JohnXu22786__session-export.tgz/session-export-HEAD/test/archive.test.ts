/**
 * Archive manager tests: write/list/filter/delete, index rebuild, path
 * traversal guards, and UTF-8 chunk splitting.
 */

import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import * as fs from 'node:fs/promises'
import * as os from 'node:os'
import * as path from 'node:path'
import { ArchiveManager, isInside, resolveInside, splitUtf8, exportId, recordExport, type ArchiveEntry } from '../src/core/archive.ts'
import { safeFileName } from '../src/core/filenames.ts'

async function tmpArchive(): Promise<{ tmp: string; archive: ArchiveManager }> {
  const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'session-export-arc-'))
  return { tmp, archive: new ArchiveManager(tmp) }
}

function makeEntry(archive: ArchiveManager, format: 'markdown' | 'jsonl' = 'markdown', sessionId: string | null = 's1', date = '2026-01-02'): ArchiveEntry {
  return {
    id: exportId(`${date}-10_form.${format === 'jsonl' ? 'jsonl' : 'md'}`, sessionId),
    format,
    sessionId,
    project: 'prj',
    exportedAt: new Date(`${date}T10:00:00.000Z`).toISOString(),
    date,
    fileName: `${date}-10_form.${format === 'jsonl' ? 'jsonl' : 'md'}`,
    relPath: `sessions/${safeFileName(sessionId ?? '_unsaved')}/${date}/${date}-10_form.${format === 'jsonl' ? 'jsonl' : 'md'}`,
    size: 100,
    contentHash: 'abc',
    sanitizationLevel: 'standard',
    redacted: true,
    warnings: [],
    partCount: 1,
  }
}

describe('archive: write + list + filter', () => {
  it('writes a primary artifact into session/date directories', async () => {
    const { tmp, archive } = await tmpArchive()
    const d = '2026-01-02'
    const { absolute, bytes } = await archive.writePrimary('s1', d, '2026-01-02_x_markdown.md', 'hello')
    assert.equal(bytes, 5)
    assert.ok(absolute.startsWith(path.join(tmp, 'sessions', 's1', d)))
    assert.equal(await fs.readFile(absolute, 'utf8'), 'hello')
    await fs.rm(tmp, { recursive: true, force: true })
  })

  it('lists exports and filters by session/format/date/query', async () => {
    const { tmp, archive } = await tmpArchive()
    const e1 = makeEntry(archive, 'markdown', 's1', '2026-01-02')
    const e2 = makeEntry(archive, 'jsonl', 's1', '2026-01-03')
    const e3 = makeEntry(archive, 'markdown', 's2', '2026-01-03')
    const dir = archive.sessionDir('s1', '2026-01-02')
    await fs.mkdir(dir, { recursive: true })
    await archive.saveIndex([e1, e2, e3])

    const all = await archive.list()
    assert.equal(all.total, 3)
    const onlyS1 = await archive.list({ sessionId: 's1' })
    assert.equal(onlyS1.total, 2)
    const onlyMarkdown = await archive.list({ format: 'markdown' })
    assert.equal(onlyMarkdown.total, 2)
    const after = await archive.list({ after: '2026-01-03T00:00:00Z' })
    assert.equal(after.total, 2)
    const q = await archive.list({ query: 'jsonl' })
    assert.equal(q.total, 1)
    const limited = await archive.list({ limit: 1 })
    assert.equal(limited.entries.length, 1)
    await fs.rm(tmp, { recursive: true, force: true })
  })

  it('rebuilds the index from sidecars when the index is corrupt', async () => {
    const { tmp, archive } = await tmpArchive()
    const date = '2026-01-02'
    const dir = archive.sessionDir('s1', date)
    const { absolute } = await archive.writePrimary('s1', date, `${date}_10_form.md`, 'x')
    await archive.writeSidecar(absolute, makeEntry(archive, 'markdown', 's1', date))
    await fs.writeFile(archive.indexFile, '{ nope', 'utf8')

    const entries = await archive.entries()
    assert.equal(entries.length, 1)
    assert.equal(entries[0]?.fileName, `2026-01-02-10_form.md`)
    await fs.rm(tmp, { recursive: true, force: true })
  })
})

describe('archive: delete', () => {
  it('removes the primary file, meta sidecar and prunes empty dirs', async () => {
    const { tmp, archive } = await tmpArchive()
    const date = '2026-01-02'
    const dir = archive.sessionDir('s1', date)
    const { absolute } = await archive.writePrimary('s1', date, `${date}-10_form.md`, 'content')
    await archive.writeSidecar(absolute, makeEntry(archive, 'markdown', 's1', date))
    const entry = makeEntry(archive, 'markdown', 's1', date)
    await archive.saveIndex([entry])

    assert.equal((await archive.list()).total, 1)
    const removed = await archive.remove(entry.id)
    assert.ok(removed.entry)
    assert.ok(removed.removedFiles.length >= 1, 'removedFiles must list what was deleted')
    assert.equal(await fs.access(absolute).then(() => true).catch(() => false), false)
    // session date dir and session dir should be gone (empty), sessionsRoot remains
    assert.equal(await fs.access(dir).then(() => true).catch(() => false), false)
    assert.equal((await archive.list()).total, 0)
    await fs.rm(tmp, { recursive: true, force: true })
  })

  it('refuses deletion targets outside the archive root (traversal guard)', async () => {
    const { tmp, archive } = await tmpArchive()
    assert.throws(() => resolveInside(tmp, '../outside.txt'))
    assert.equal(isInside(tmp, path.join(tmp, 'ok.md')), true)
    assert.equal(isInside(tmp, path.join(tmp, '..', 'elsewhere', 'x.txt')), false)
    // remove() with a traversal path must not resolve outside
    const r = await archive.findByIdOrPath('../outside.txt')
    assert.equal(r, null)
    await fs.rm(tmp, { recursive: true, force: true })
  })

  it('blocked by remove() when id/path not found', async () => {
    const { tmp, archive } = await tmpArchive()
    const r = await archive.remove('exp-nonexistent')
    assert.equal(r.entry, null)
    assert.deepEqual(r.removedFiles, [])
    await fs.rm(tmp, { recursive: true, force: true })
  })
})

describe('archive: concurrent writers', () => {
  it('serializes parallel upserts so no recorded entry is lost', async () => {
    const { tmp, archive } = await tmpArchive()
    const date = '2026-01-02'
    try {
      const results = await Promise.all(
        ['a', 'b', 'c', 'd'].map(async (tag) => {
          const name = `${date}-${tag}_form.md`
          const { absolute } = await archive.writePrimary(`s${tag}`, date, name, `content-${tag}`)
          return recordExport(archive, {
            format: 'markdown',
            sessionId: `s${tag}`,
            project: null,
            exportedAt: new Date('2026-01-02T10:00:00.000Z'),
            fileName: name,
            size: 8,
            contentHash: null,
            sanitizationLevel: 'standard',
            redacted: true,
            warnings: [],
            partCount: 1,
          }, absolute)
        }),
      )
      assert.equal(results.length, 4)
      const { entries } = await archive.list()
      assert.equal(entries.length, 4)
      assert.equal(new Set(entries.map((e) => e.sessionId)).size, 4)
    } finally {
      await fs.rm(tmp, { recursive: true, force: true })
    }
  })
})

describe('archive: recordExport sidecars', () => {
  it('records an entry and writes the meta sidecar + index', async () => {
    const { tmp, archive } = await tmpArchive()
    const date = '2026-01-02'
    const { absolute } = await archive.writePrimary('s1', date, `${date}_10_form.md`, 'data')
    const recorded = await recordExport(archive, {
      format: 'markdown',
      sessionId: 's1',
      project: 'prj',
      exportedAt: new Date('2026-01-02T10:00:00.000Z'),
      fileName: `${date}_10_form.md`,
      size: 4,
      contentHash: 'x',
      sanitizationLevel: 'standard',
      redacted: true,
      warnings: [],
      partCount: 1,
    }, absolute)
    assert.equal(recorded.relPath, `sessions/s1/${date}/${date}_10_form.md`)
    const side = JSON.parse(await fs.readFile(`${absolute}.meta.json`, 'utf8')) as ArchiveEntry
    assert.equal(side.id, recorded.id)
    assert.equal((await archive.list()).total, 1)
    await fs.rm(tmp, { recursive: true, force: true })
  })
})

describe('archive: splitUtf8', () => {
  it('keeps multibyte characters intact across part boundaries', () => {
    const text = 'a'.repeat(100) + '中'.repeat(100) + 'b'.repeat(100)
    const parts = splitUtf8(text, 100)
    assert.ok(parts.length > 1)
    const joined = parts.join('')
    assert.equal(joined, text)
    assert.ok(parts.every((p) => Buffer.byteLength(p, 'utf8') <= 100))
  })

  it('returns a single part when under the limit', () => {
    assert.deepEqual(splitUtf8('small', 1000), ['small'])
  })

  it('handles a single code point larger than the limit', () => {
    const emoji = '😀'.repeat(1)
    const parts = splitUtf8(`${'x'.repeat(10)}${emoji}`, 5)
    assert.equal(parts.join(''), 'x'.repeat(10) + emoji)
  })
})
