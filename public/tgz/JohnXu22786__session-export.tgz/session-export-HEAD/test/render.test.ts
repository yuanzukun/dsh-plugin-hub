/**
 * Renderer tests: Markdown narrative, JSONL machine record, HTML/PDF path.
 */

import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import { foldSession } from '../src/core/fold.ts'
import { buildHeader } from '../src/core/meta.ts'
import { renderMarkdown } from '../src/core/render/markdown.ts'
import { renderJsonl, canonicalBody } from '../src/core/render/jsonl.ts'
import { renderHtml } from '../src/core/render/html.ts'
import { SAMPLE_EVENTS } from './helpers.ts'

function header() {
  return buildHeader({
    plugin: { name: 'x', version: '0.1.0' },
    session: { id: 'sess-abc123', project: 'acme', cwd: '/home/alice/project', createdAt: 1_700_000_000_000 },
    models: ['deepseek-v4-flash'],
    sanitization: { enabled: true, level: 'standard', rules: ['api-key'], saltFingerprint: null },
    warnings: [],
  })
}

describe('markdown renderer', () => {
  it('renders a readable narrative with ordering and headings', () => {
    const doc = foldSession(SAMPLE_EVENTS)
    const md = renderMarkdown(doc, header())
    assert.ok(md.startsWith('<!--'), 'metadata header block first')
    assert.ok(md.includes('## User'))
    assert.ok(md.includes('## Assistant'))
    assert.ok(md.includes('`read_file`'))
    assert.ok(md.includes('## Document tree'))
  })

  it('embeds the compliance header JSON as an HTML comment', () => {
    const doc = foldSession(SAMPLE_EVENTS)
    const md = renderMarkdown(doc, header())
    assert.ok(md.includes('"formatVersion": 1'))
    assert.ok(md.includes('"exportedAt"'))
  })

  it('draws an extended fence around tool output containing backticks', () => {
    const doc = foldSession([
      { type: 'tool/result', seq: 1, time: 1, data: { message: { content: 'before\n```json\n{"a":1}\n```\nafter' } } },
    ])
    const md = renderMarkdown(doc, header())
    // The tool result is multi-line so it is fenced with a bar longer than any
    // backtick run inside (3 → 4). The outer fence must not be closable by the
    // content's own triple backticks.
    assert.ok(md.includes('````\nbefore\n```json\n{"a":1}\n```\nafter\n````'), md)
  })

  it('truncates long assistant content with an explicit marker', () => {
    const doc = foldSession([{ type: 'assistant/message', seq: 1, time: 1, data: { turn: 0, step: 0, message: { content: 'x'.repeat(500) } } }])
    const md = renderMarkdown(doc, header(), { maxMessageChars: 50 })
    assert.ok(md.includes('truncated by exporter'))
  })
})

describe('jsonl renderer', () => {
  it('first line is the compliance header, then one object per entry', () => {
    const doc = foldSession(SAMPLE_EVENTS)
    const out = renderJsonl(doc, header())
    const lines = out.trimEnd().split('\n')
    const h = JSON.parse(lines[0] ?? '{}') as { formatVersion?: number }
    assert.equal(h.formatVersion, 1)
    assert.equal(lines.length, 1 + doc.entries.length)
    for (const line of lines.slice(1)) {
      const obj = JSON.parse(line) as { kind: string; seq: number }
      assert.ok(typeof obj.kind === 'string')
      assert.ok(typeof obj.seq === 'number')
    }
  })

  it('tool calls keep their raw arguments for machine consumers', () => {
    const doc = foldSession(SAMPLE_EVENTS)
    const out = renderJsonl(doc, header())
    assert.ok(out.includes('"toolName":"read_file"'))
  })

  it('canonicalBody is stable and format-independent', () => {
    const doc = foldSession(SAMPLE_EVENTS)
    const a = canonicalBody(doc)
    const b = canonicalBody(foldSession(SAMPLE_EVENTS))
    assert.equal(a, b)
    assert.ok(a.includes('hf_'))
  })
})

describe('html/print path', () => {
  it('renders a self-contained offline HTML with CSP and print CSS', () => {
    const doc = foldSession(SAMPLE_EVENTS)
    const html = renderHtml(doc, header(), { includeDocuments: true })
    assert.ok(html.includes('<!DOCTYPE html>'))
    assert.ok(html.includes('default-src'))
    assert.ok(html.includes('@media print'))
    assert.ok(html.includes('deepseek-v4-flash'))
    assert.ok(!html.includes('<script'), 'no scripts anywhere')
  })
})
