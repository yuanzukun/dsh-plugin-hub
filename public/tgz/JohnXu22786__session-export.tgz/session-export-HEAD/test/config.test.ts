import { test } from 'node:test'
import assert from 'node:assert/strict'
import * as path from 'node:path'
import { defaultOutDir } from '../src/config.ts'

test('config: defaultOutDir honors DSH_HOME', () => {
  process.env.DSH_HOME = '/opt/dsh'
  delete process.env.HOME
  delete process.env.USERPROFILE
  assert.equal(defaultOutDir(), path.join('/opt/dsh', 'exports'))
})

test('config: defaultOutDir falls back to HOME when DSH_HOME is unset', () => {
  delete process.env.DSH_HOME
  process.env.HOME = '/home/alice'
  delete process.env.USERPROFILE
  assert.equal(defaultOutDir(), path.join('/home/alice', 'exports'))
})

test('config: defaultOutDir falls back to USERPROFILE (Windows-style env)', () => {
  delete process.env.DSH_HOME
  delete process.env.HOME
  process.env.USERPROFILE = 'C:\\Users\\alice'
  assert.equal(defaultOutDir(), path.join('C:\\Users\\alice', 'exports'))
})

test('config: defaultOutDir returns relative "exports" when no home is set', () => {
  delete process.env.DSH_HOME
  delete process.env.HOME
  delete process.env.USERPROFILE
  assert.equal(defaultOutDir(), path.join('.', 'exports'))
})
