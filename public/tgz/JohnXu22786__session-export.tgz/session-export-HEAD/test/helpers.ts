/**
 * Shared fixtures + engine deps factory for tests.
 */

import * as fs from 'node:fs/promises'
import * as os from 'node:os'
import * as path from 'node:path'
import { normalizeConfig, type SessionExportConfig } from '../src/config.ts'
import { ArchiveManager } from '../src/core/archive.ts'
import type { RawSessionEvent } from '../src/core/fold.ts'
import type { EngineDeps } from '../src/engine.ts'

/** A small but representative session log (chunked streaming + tools + .env). */
export const SAMPLE_EVENTS: RawSessionEvent[] = [
  { type: 'session/created', seq: 0, time: 1_700_000_000_000, data: { id: 'sess-abc123', cwd: '/home/alice/project', project: 'acme' } },
  { type: 'turn/start', seq: 1, time: 1_700_000_000_001, data: { turn: 0 } },
  { type: 'user/message', seq: 2, time: 1_700_000_000_010, data: { content: 'Fix the login bug in src/auth.ts, check .env', source: 'user' } },
  { type: 'step/start', seq: 3, time: 1_700_000_000_020, data: { turn: 1, step: 0 } },
  { type: 'assistant/chunk', seq: 4, time: 1_700_000_000_021, data: { turn: 1, step: 0, chunk: { text: 'I inspected the code. The API key ' } } },
  { type: 'assistant/chunk', seq: 5, time: 1_700_000_000_022, data: { turn: 1, step: 0, chunk: { text: 'sk-abcdefghijklmnopqrstuvwxyz0123456 is hardcoded.' } } },
  {
    type: 'assistant/message',
    seq: 6,
    time: 1_700_000_000_023,
    data: {
      turn: 1,
      step: 0,
      message: { content: 'I inspected the code. The API key sk-abcdefghijklmnopqrstuvwxyz0123456 is hardcoded.' },
      usage: { input_tokens: 12, output_tokens: 9 },
    },
  },
  { type: 'tool/call', seq: 7, time: 1_700_000_000_030, data: { turn: 2, step: 0, callId: 'call_1', name: 'read_file', arguments: '{"path":"C:\\\\Users\\\\alice\\\\project\\\\src\\\\auth.ts"}' } },
  { type: 'tool/result', seq: 8, time: 1_700_000_000_040, data: { turn: 2, step: 0, callId: 'call_1', message: { content: 'export const DEEPSEEK_KEY = "hf_abcdefghijklmnopqrstuvwxyz1234567890"' } } },
  { type: 'assistant/chunk', seq: 9, time: 1_700_000_000_050, data: { turn: 3, step: 0, chunk: { text: 'Fixing by moving the key into a env variable: DATABASE_URL=' } } },
  { type: 'assistant/message', seq: 10, time: 1_700_000_000_060, data: { turn: 3, step: 0, message: { content: 'Fixing by moving the key into a env variable: DATABASE_URL=postgres://admin:secret@db.local:5432/acme' } } },
  { type: 'todo/write', seq: 11, time: 1_700_000_000_070, data: { todo: { text: 'write integration tests' } } },
]

/** A raw event with an unknown type (robustness check). */
export function eventOf(type: string, data: unknown, seq: number): RawSessionEvent {
  return { type, seq, time: 1_700_000_001_000 + seq, data }
}

/** Create a throwaway temp archive directory + deps. */
export async function makeEnv(
  events: readonly RawSessionEvent[],
  configOverrides: Record<string, unknown> = {},
): Promise<{ tmp: string; deps: EngineDeps; config: SessionExportConfig }> {
  const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'session-export-test-'))
  const config = normalizeConfig({ outDir: tmp, ...configOverrides })
  const archive = new ArchiveManager(config.outDir)
  const deps: EngineDeps = {
    plugin: { name: 'dsh-session-export-test', version: '0.0.0-test' },
    getConfig: () => config,
    getArchive: () => archive,
    loadSession: async (id) => ({
      session: { id: id ?? 'sess-abc123', project: 'acme', cwd: '/home/alice/project', createdAt: 1_700_000_000_000 },
      events: [...events],
    }),
    now: () => new Date('2026-01-02T03:04:05.000Z'),
  }
  return { tmp, deps, config }
}

export async function cleanup(tmp: string): Promise<void> {
  await fs.rm(tmp, { recursive: true, force: true }).catch(() => undefined)
}
