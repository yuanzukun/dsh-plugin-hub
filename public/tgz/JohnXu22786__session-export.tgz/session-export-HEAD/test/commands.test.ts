/**
 * Command-layer tests: slash-command parsing, audit/delete/config surfaces.
 */

import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import type { EngineDeps } from '../src/engine.ts'
import { exportCommands } from '../src/commands.ts'
import { exportDeleteTool, sanitizeConfigTool, sessionExportListTool } from '../src/tools.ts'
import { defineTool } from '../src/adapter/defineTool.ts'
import type { ArchiveEntry } from '../src/core/archive.ts'

function sampleEntry(over: Partial<ArchiveEntry>): ArchiveEntry {
  return {
    id: 'exp-1',
    format: 'markdown',
    sessionId: 's1',
    project: null,
    exportedAt: '2026-01-02T10:00:00.000Z',
    date: '2026-01-02',
    fileName: 'a.md',
    relPath: 'sessions/s1/2026-01-02/a.md',
    size: 10,
    contentHash: null,
    sanitizationLevel: 'standard',
    redacted: true,
    warnings: [],
    partCount: 1,
    ...over,
  }
}

function fakeDeps(entries: ArchiveEntry[]): EngineDeps {
  const config: import('../src/config.ts').SessionExportConfig = {
    enabled: true,
    outDir: '/tmp/x',
    defaultFormat: 'markdown',
    includeNotes: false,
    includeDocuments: true,
    maxChunkBytes: 0,
    maxMessageChars: 0,
    prettyToolArgs: false,
    includeHash: true,
    redaction: {
      enabled: true,
      level: 'standard',
      maskApiKeys: true,
      maskEnvValues: true,
      maskBearerTokens: true,
      maskUrlCredentials: true,
      maskAbsolutePaths: true,
      pathMode: 'mask',
      projectRoots: [],
      maskEmails: false,
      customPatterns: [],
      aiMaskEnabled: false,
      salt: 'test',
    },
    pdf: { engine: 'html' },
  }
  return {
    plugin: { name: 'p', version: '1' },
    getConfig: () => config,
    getArchive: () =>
      ({
        async list() {
          return { entries, total: entries.length }
        },
        async remove(target: string) {
          const hit = entries.find((e) => e.id === target || e.fileName === target)
          if (!hit) return { entry: null, removedFiles: [] }
          return { entry: hit, removedFiles: [hit.fileName] }
        },
      }) as unknown as import('../src/core/archive.ts').ArchiveManager,
    loadSession: async () => {
      throw new Error('unused in these tests')
    },
  }
}

describe('command parsing', () => {
  it('sanitize-config --test runs real redaction on the sample', async () => {
    const commands = exportCommands(fakeDeps([]))
    const sanitize = commands.find((c) => c.name === 'sanitize-config')
    assert.ok(sanitize)
    const res = await sanitize!.handler({ rawInput: '--test my key is sk-abcdefghijklmnopqrstuvwxyz0123456' })
    assert.ok(!res.text.includes('sk-abcdefghijklmnopqrstuvwxyz0123456'))
  })

  it('rejects path-traversal delete targets with a clear message', async () => {
    const commands = exportCommands(fakeDeps([]))
    const del = commands.find((c) => c.name === 'export-delete')
    assert.ok(del)
    const res = await del!.handler({ rawInput: '../outside' })
    assert.match(res.text, /traversal/)
  })

  it('renders the audit summary over archived exports', async () => {
    const commands = exportCommands(fakeDeps([sampleEntry({}), sampleEntry({ id: 'exp-2', format: 'jsonl', date: '2026-01-03', exportedAt: '2026-01-03T00:00:00Z', sessionId: 's2' })]))
    const audit = commands.find((c) => c.name === 'export-audit')
    assert.ok(audit)
    const res = await audit!.handler({ rawInput: '' })
    assert.ok(res.text.includes('Total exports: 2'))
    assert.ok(res.text.includes('By format:'))
  })

  it('list command fails cleanly on an unknown flag value', async () => {
    const commands = exportCommands(fakeDeps([sampleEntry({})]))
    const list = commands.find((c) => c.name === 'session-export-list')
    assert.ok(list)
    const res = await list!.handler({ rawInput: '--format=bogus' })
    // bogus format coerces to 'all' filter which returns everything; no crash
    assert.ok(res.text.length > 0)
  })
})

describe('tool wrappers', () => {
  it('export_delete rejects simulated traversal attempts', async () => {
    const deps = fakeDeps([sampleEntry({})])
    const def = exportDeleteTool(deps)
    await assert.rejects(() => Promise.resolve(def.execute({ target: '../escape.txt' })), /traversal/)
    await assert.rejects(() => Promise.resolve(def.execute({ target: 'a\u0000b' })), /invalid delete target/)
  })

  it('export_delete resolves by file name and reports removal', async () => {
    const deps = fakeDeps([sampleEntry({})])
    const def = exportDeleteTool(deps)
    const out = await def.execute({ target: 'a.md' })
    const parsed = out as { removed: boolean; entry: string }
    assert.equal(parsed.removed, true)
    assert.equal(parsed.entry, 'sessions/s1/2026-01-02/a.md')
  })

  it('sanitize_config test runs the active rules deterministically', async () => {
    const deps = fakeDeps([])
    const def = sanitizeConfigTool(deps)
    const once = await def.execute({ action: 'test', sample: 'token sk-abcdefghijklmnopqrstuvwxyz0123456' })
    const twice = await def.execute({ action: 'test', sample: 'token sk-abcdefghijklmnopqrstuvwxyz0123456' })
    assert.equal(JSON.stringify(once), JSON.stringify(twice))
    const parsed = once as { rules: string[]; output: string }
    assert.ok(parsed.rules.length > 0)
    assert.ok(!parsed.output.includes('sk-abcdefghijklmnopqrstuvwxyz0123456'))
  })

  it('session_export_list formats entries without crashing', async () => {
    const deps = fakeDeps([sampleEntry({}), sampleEntry({ id: 'exp-2', format: 'jsonl' })])
    const def = sessionExportListTool(deps)
    const out = await def.execute({ limit: 10 })
    const parsed = out as { total: number; entries: unknown[] }
    assert.equal(parsed.total, 2)
  })

  it('defineTool returns its input unchanged (contract identity)', () => {
    const def = defineTool({
      name: 'x',
      description: 'd',
      parameters: { a: { type: 'string', description: 'p' } },
      output: { schema: {}, render: () => [{ type: 'text' as const, text: 'x' }] },
      execute: () => 'ok',
    })
    assert.equal(def.name, 'x')
  })
})
