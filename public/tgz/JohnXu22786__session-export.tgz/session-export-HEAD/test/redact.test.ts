/**
 * Redaction engine tests — the compliance-critical core.
 */

import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import { Redactor, DEFAULT_REDACTION_CONFIG } from '../src/core/redact.ts'
import { shortFingerprint } from '../src/core/hash.ts'

function build(salt = 'test-salt'): Redactor {
  return new Redactor({ ...DEFAULT_REDACTION_CONFIG, salt })
}

describe('redaction: API key / token masking', () => {
  it('masks a DeepSeek/OpenAI style sk- key deterministically', async () => {
    const r = build()
    const secret = 'sk-abcdefghijklmnopqrstuvwxyz0123456'
    const { text, rules } = await r.redact(`key=${secret} here`)
    assert.ok(!text.includes(secret), 'secret must not appear in output')
    assert.ok(text.includes(`<redacted:api-key sha256:${shortFingerprint(secret, 'test-salt')}>`))
    assert.ok(rules.includes('api-key'))
  })

  it('masks a .env-style assignment and never leaks the value', async () => {
    const r = build()
    const value = 'postgres://admin:super-secret-pw@db.local/acme'
    const { text } = await r.redact(`DATABASE_URL=${value}\nNEXT_PUBLIC_X=1`)
    assert.ok(!text.includes(value))
    assert.ok(text.includes('DATABASE_URL=<redacted:env'))
    // Every `KEY=value` line is treated as an env assignment, even benign names.
    assert.ok(text.includes('NEXT_PUBLIC_X=<redacted:env'))
  })

  it('masks quoted and token .env values, keeping multi-line blocks intact line by line', async () => {
    const r = build()
    const { text } = await r.redact('SECRET_KEY="line one"\nNEXT=plainvalue\nVISIBLE=keep')
    assert.ok(!text.includes('line one'))
    assert.ok(!text.includes('plainvalue'))
    assert.ok(text.includes('NEXT=<redacted:env'))
    assert.ok(text.includes('VISIBLE=<redacted:env'))
  })

  it('masks the value token without consuming a following shell command', async () => {
    const r = build()
    const input = '$ DATABASE_URL=postgres://admin:secret@db:5432/acme node run.js\nserver listening on 3000\nall good'
    const { text } = await r.redact(input)
    assert.ok(text.includes('DATABASE_URL=<redacted:env'), text)
    assert.ok(!text.includes('admin:secret'))
    assert.ok(text.includes('node run.js'), 'the command after the value must survive')
    assert.ok(text.includes('server listening on 3000'), 'the following lines must survive')
  })

  it('preserves prose that merely mentions a KEY= assignment', async () => {
    const r = build()
    const { text } = await r.redact('User set FLAG=ON.\nContinue from there.')
    assert.ok(text.includes('FLAG=<redacted:env'))
    assert.ok(text.includes('Continue from there.'), 'following prose must survive')
  })

  it('an empty KEY= does not absorb the next line', async () => {
    const r = build()
    const { text } = await r.redact('EMPTY=\nNEXT=1')
    assert.ok(text.includes('EMPTY='))
    assert.ok(text.includes('NEXT=<redacted:env'))
  })

  it('masks single-character env keys too', async () => {
    const r = build()
    const { text } = await r.redact('X=supersecretpass along')
    assert.ok(text.includes('X=<redacted:env'))
    assert.ok(text.includes('along'), 'trailing prose survives')
  })

  it('correlates the same secret when written bare or as an env value', async () => {
    const r = build()
    const secret = 'sk-abcdefghijklmnopqrstuvwxyz0123456'
    const bare = await r.redact(`found ${secret} here`)
    const asEnv = await r.redact(`DEPLOY_KEY=${secret}`)
    // env-value runs first, masking the value wholesale; the fingerprint is
    // derived from the secret alone so the hex must match the bare api-key one.
    assert.ok(bare.text.includes(`<redacted:api-key sha256:${shortFingerprint(secret, 'test-salt')}>`))
    assert.ok(asEnv.text.includes(`<redacted:env sha256:${shortFingerprint(secret, 'test-salt')}>`))
  })

  it('masks a JWT and shortens its fingerprint', async () => {
    const r = build()
    const jwt = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIn0.dozjgNryR4KQ6iL8WZA9vIyW9kXP8Xz9FfLQ'
    const { text, rules } = await r.redact(`Authorization: Bearer ${jwt}`)
    assert.ok(!text.includes(jwt))
    assert.ok(rules.includes('jwt'))
  })

  it('masks a long high-entropy token (hf_ / generic)', async () => {
    const r = build()
    const hf = 'hf_abcdefghijklmnopqrstuvwxyz1234567890'
    const { text } = await r.redact(`key = "${hf}"`)
    assert.ok(!text.includes(hf))
  })

  it('redaction is deterministic across repeated calls', async () => {
    const r = build()
    const input = 'sk-abcdefghijklmnopqrstuvwxyz0123456 and DATABASE_URL=sekretvalue'
    const first = await r.redact(input)
    const second = await r.redact(input)
    assert.equal(first.text, second.text)
    assert.deepEqual(first.rules, second.rules)
  })

  it('same secret in different texts yields the same fingerprint (correlatable)', async () => {
    const r = build()
    const secret = 'sk-abcdefghijklmnopqrstuvwxyz0123456'
    const fp = `<redacted:api-key sha256:${shortFingerprint(secret, 'test-salt')}>`
    const a = await r.redact(secret)
    const b = await r.redact(`prefix ${secret} suffix`)
    assert.ok(a.text.includes(fp))
    assert.ok(b.text.includes(fp))
  })

  it('does not corrupt plain text', async () => {
    const r = build()
    const plain = 'Hello world, this is a totally normal sentence with no secrets.'
    const { text } = await r.redact(plain)
    assert.equal(text, plain)
  })

  it('empty input stays empty', async () => {
    const r = build()
    const { text, rules } = await r.redact('')
    assert.equal(text, '')
    assert.deepEqual(rules, [])
  })

  it('handles disabled redaction as passthrough', async () => {
    const r = new Redactor({ ...DEFAULT_REDACTION_CONFIG, enabled: false, salt: 'x' })
    const secret = 'sk-abcdefghijklmnopqrstuvwxyz0123456'
    const { text, rules } = await r.redact(secret)
    assert.equal(text, secret)
    assert.deepEqual(rules, [])
  })
})

describe('redaction: paths', () => {
  it('masks a Windows absolute path by default', async () => {
    const r = build()
    const p = 'C:\\Users\\alice\\project\\src\\auth.ts'
    const { text } = await r.redact(`file at ${p} matters`)
    assert.ok(!text.includes(p))
    assert.ok(text.includes('<redacted:path'))
  })

  it('relativizes a path under a configured project root', async () => {
    const r = new Redactor({
      ...DEFAULT_REDACTION_CONFIG,
      salt: 'x',
      pathMode: 'relative',
      projectRoots: ['C:\\Users\\alice\\project'],
    })
    const p = 'C:\\Users\\alice\\project\\src\\auth.ts'
    const { text } = await r.redact(`file at ${p}`)
    assert.ok(text.includes('./src/auth.ts'), text)
    assert.ok(!text.includes('alice'), 'root must not leak')
  })

  it('does not touch relative paths', async () => {
    const r = build()
    const rel = 'src/auth.ts'
    const { text } = await r.redact(`./${rel}`)
    assert.ok(text.includes(rel))
  })

  it('pathMode off leaves paths intact', async () => {
    const r = new Redactor({ ...DEFAULT_REDACTION_CONFIG, salt: 'x', pathMode: 'off' })
    const p = 'C:\\Users\\alice\\x\\y.txt'
    const { text } = await r.redact(p)
    assert.ok(text.includes(p))
  })
})

describe('redaction: custom rules + AI hook', () => {
  it('applies a custom regex pattern with a literal replacement', async () => {
    const r = new Redactor({
      ...DEFAULT_REDACTION_CONFIG,
      salt: 'x',
      customPatterns: [{ pattern: '(\\d{4})-\\d{4}-\\d{4}-\\d{4}', replacement: 'CREDIT-CARD' }],
    })
    const { text, rules } = await r.redact('card 4111-1111-1111-1111 ok')
    assert.ok(text.includes('card CREDIT-CARD ok'))
    assert.ok(rules.some((x) => x.startsWith('custom:')))
  })

  it('ignores an invalid custom pattern rather than failing', async () => {
    const r = new Redactor({
      ...DEFAULT_REDACTION_CONFIG,
      salt: 'x',
      customPatterns: [{ pattern: '([unclosed', replacement: 'x' }],
    })
    const { text } = await r.redact('anything')
    assert.equal(text, 'anything')
  })

  it('never hangs on a custom pattern without the global flag', async () => {
    const r = new Redactor({
      ...DEFAULT_REDACTION_CONFIG,
      salt: 'x',
      customPatterns: [{ pattern: 'SECRET', flags: 'i' }],
    })
    const { text, rules } = await r.redact('the secret is SECRET here')
    assert.ok(text.includes('<redacted:custom'))
    assert.ok(rules.some((x) => x.startsWith('custom:')))
  })

  it('optional AI mask hook is applied only when enabled', async () => {
    const calls: string[] = []
    const r = new Redactor({
      ...DEFAULT_REDACTION_CONFIG,
      salt: 'x',
      aiMaskEnabled: true,
      aiMaskFn: (t) => {
        calls.push(t)
        return t.replace(/GrumpyCat/g, '[AI-MASKED]')
      },
    })
    const { document, rules } = await r.redactDocument({
      session: { id: null, project: null, cwd: null, createdAt: null },
      entries: [{ kind: 'assistant', seq: 1, sourceSeq: 1, time: 1, sourceType: 'assistant/message', masked: false, content: 'GrumpyCat is here', truncated: false }],
      documents: [],
      models: [],
      counts: { events: 1, entries: 1, byKind: { assistant: 1 } },
      warnings: [],
    })
    const entry = document.entries[0]
    assert.ok(entry && entry.kind === 'assistant')
    assert.ok(entry.content.includes('[AI-MASKED]'))
    assert.equal(entry.masked, true)
    assert.ok(rules.includes('ai-mask'))
    assert.ok(calls.length > 0)
  })
})

describe('redaction: fingerprint helpers', () => {
  it('shortFingerprint is stable for identical input & salt', () => {
    assert.equal(shortFingerprint('sk-12345', 's'), shortFingerprint('sk-12345', 's'))
  })
  it('changes when salt changes', () => {
    assert.notEqual(shortFingerprint('sk-12345', 'a'), shortFingerprint('sk-12345', 'b'))
  })
})
