/**
 * End-to-end engine tests: fold → redact → header → render → chunk → archive.
 */

import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import * as fs from 'node:fs/promises'
import * as path from 'node:path'
import { normalizeConfig } from '../src/config.ts'
import { runExport } from '../src/engine.ts'
import { cleanup, makeEnv, SAMPLE_EVENTS } from './helpers.ts'

describe('engine: export pipeline', () => {
  it('exports markdown + jsonl, redacts secrets, records compliance metadata', async () => {
    const { tmp, deps } = await makeEnv(SAMPLE_EVENTS)
    try {
      const outcome = await runExport(deps, { format: 'all' })
      const formats = outcome.artifacts.map((a) => a.format).sort()
      // 'all' = markdown + jsonl + pdf; pdf degrades to an HTML artifact when
      // no browser binary is available (see generatePdf).
      assert.deepEqual(formats, ['html', 'jsonl', 'markdown'])
      assert.equal(outcome.sanitized, true)
      assert.equal(outcome.redactionLevel, 'standard')
      assert.equal(outcome.sessionId, 'sess-abc123')
      assert.ok(outcome.contentHash)

      const mdPath = path.join(tmp, outcome.artifacts.find((a) => a.format === 'markdown')!.relPath)
      const md = await fs.readFile(mdPath, 'utf8')
      assert.ok(!md.includes('sk-abcdefghijklmnopqrstuvwxyz0123456'), 'API key must not leak into markdown')
      assert.ok(!md.includes('hf_abcdefghijklmnopqrstuvwxyz1234567890'), 'HF key must not leak')
      assert.ok(!md.includes('postgres://admin:secret'))
      assert.ok(!md.includes('C:\\Users\\alice'), 'absolute path must be masked')
      assert.ok(!md.includes('/home/alice'), 'session cwd must not leak')
      assert.ok(md.includes('<redacted:'))

      const jsonlPath = path.join(tmp, outcome.artifacts.find((a) => a.format === 'jsonl')!.relPath)
      const lines = (await fs.readFile(jsonlPath, 'utf8')).trimEnd().split('\n')
      const header = JSON.parse(lines[0] ?? '{}') as { formatVersion?: number; sanitization?: { level?: string }; session?: { cwd?: string | null } }
      assert.equal(header.formatVersion, 1)
      assert.equal(header.sanitization?.level, 'standard')
      assert.ok(!String(header.session?.cwd).includes('/home/alice'), 'header cwd must be redacted')
      const body = lines.slice(1).join('\n')
      assert.ok(!body.includes('sk-abcdefghijklmnopqrstuvwxyz0123456'))
      assert.ok(!body.includes('/home/alice'))

      // meta sidecar + index exist
      assert.ok(await fs.access(`${mdPath}.meta.json`).then(() => true).catch(() => false))
      assert.ok(await fs.access(path.join(tmp, 'archives.json')).then(() => true).catch(() => false))
    } finally {
      await cleanup(tmp)
    }
  })

  it('respects redact=false override (secrets visible, level none)', async () => {
    const { tmp, deps } = await makeEnv(SAMPLE_EVENTS)
    try {
      const outcome = await runExport(deps, { format: 'markdown', redact: false })
      assert.equal(outcome.sanitized, false)
      assert.equal(outcome.redactionLevel, 'none')
      const mdPath = path.join(tmp, outcome.primary.relPath)
      const md = await fs.readFile(mdPath, 'utf8')
      assert.ok(md.includes('sk-abcdefghijklmnopqrstuvwxyz0123456'), 'unredacted export keeps content')
    } finally {
      await cleanup(tmp)
    }
  })

  it('chunks large exports into numbered parts when maxChunkBytes is small', async () => {
    const big = [
      { type: 'user/message', seq: 1, time: 1, data: { content: 'A'.repeat(5000) } },
      { type: 'assistant/message', seq: 2, time: 1, data: { turn: 0, step: 0, message: { content: 'B'.repeat(5000) } } },
    ]
    const { tmp, deps } = await makeEnv(big, { maxChunkBytes: 2048 })
    try {
      // redact:false keeps the 10KB raw body so splitting is actually triggered
      // (default redaction would shrink the 5000-char runs to fingerprints).
      const outcome = await runExport(deps, { format: 'markdown', redact: false })
      assert.ok(outcome.primary.partCount > 1, `expected chunking, got parts=${outcome.primary.partCount}`)
      const dir = path.dirname(path.join(tmp, outcome.primary.relPath))
      const files = (await fs.readdir(dir)).filter((f) => f.endsWith('.md'))
      assert.ok(files.length === outcome.primary.partCount)
      assert.ok(outcome.warnings.some((w) => w.includes('split into')))
    } finally {
      await cleanup(tmp)
    }
  })

  it('pdf falls back to archived HTML when no browser binary is present', async () => {
    const { tmp, deps } = await makeEnv(SAMPLE_EVENTS)
    try {
      const outcome = await runExport(deps, { format: 'pdf' })
      // The default engine 'auto' without a discoverable browser yields `html`.
      assert.equal(outcome.artifacts[0]?.format, 'html')
      assert.ok(outcome.warnings.some((w) => w.toLowerCase().includes('print to pdf')))
    } finally {
      await cleanup(tmp)
    }
  })

  it('throws a clear error when the plugin is disabled', async () => {
    const { tmp, deps } = await makeEnv(SAMPLE_EVENTS, { enabled: false })
    try {
      await assert.rejects(runExport(deps, { format: 'markdown' }), /disabled/)
    } finally {
      await cleanup(tmp)
    }
  })

  it('throws clearly when the session log cannot be read', async () => {
    const { tmp, deps } = await makeEnv(SAMPLE_EVENTS)
    try {
      deps.loadSession = async () => {
        throw new Error('boom: no persistence backend')
      }
      await assert.rejects(runExport(deps, { format: 'markdown' }), /no persistence/)
    } finally {
      await cleanup(tmp)
    }
  })

  it('files historical/named exports under the requested session id even without id events', async () => {
    const eventsWithoutIdentity = [
      { type: 'user/message', seq: 1, time: 1, data: { content: 'hello' } },
      { type: 'assistant/message', seq: 2, time: 1, data: { turn: 0, step: 0, message: { content: 'hi' } } },
    ]
    const { tmp, deps } = await makeEnv(eventsWithoutIdentity)
    try {
      const outcome = await runExport(deps, { format: 'markdown', sessionId: 'historical-42' })
      assert.equal(outcome.sessionId, 'historical-42')
      assert.ok(outcome.primary.relPath.startsWith('sessions/historical-42/'), outcome.primary.relPath)
      // Index record carries the requested id, not `_unsaved` or null.
      assert.equal((await deps.getArchive().list()).entries[0]?.sessionId, 'historical-42')
    } finally {
      await cleanup(tmp)
    }
  })

  it('two same-second exports never overwrite each other', async () => {
    const { tmp, deps } = await makeEnv(SAMPLE_EVENTS)
    try {
      // deps.now() pins the clock, so without a unique tag these two would
      // collide on the same file name and id.
      for (let i = 0; i < 2; i += 1) {
        await runExport(deps, { format: 'markdown' })
      }
      const { entries } = await deps.getArchive().list()
      assert.equal(entries.length, 2)
      assert.equal(new Set(entries.map((e) => e.relPath)).size, 2)
      assert.equal(new Set(entries.map((e) => e.id)).size, 2)
    } finally {
      await cleanup(tmp)
    }
  })
})

describe('config normalization', () => {
  it('fills defaults and coerces raw dsh config', () => {
    const cfg = normalizeConfig({
      maxChunkBytes: '2097152',
      includeNotes: true,
      redaction: { pathMode: 'relative', projectRoots: ['/work'], customPatterns: [{ pattern: '\\d{4}' }], salt: 'abc' },
    })
    assert.equal(cfg.maxChunkBytes, 2097152)
    assert.equal(cfg.includeNotes, true)
    assert.equal(cfg.redaction.pathMode, 'relative')
    assert.equal(cfg.redaction.customPatterns.length, 1)
    assert.equal(cfg.redaction.salt, 'abc')
    assert.equal(cfg.defaultFormat, 'markdown')
    assert.equal(cfg.outDir.length > 0, true)
  })

  it('keeps garbage config from crashing', () => {
    const cfg = normalizeConfig({ redaction: 'nonsense', maxChunkBytes: 'xx' })
    assert.equal(cfg.redaction.enabled, true)
    assert.equal(cfg.maxChunkBytes, 4 * 1024 * 1024)
  })

  it('bumps level to custom when custom rules are configured', async () => {
    const { tmp, deps } = await makeEnv(SAMPLE_EVENTS, { redaction: { customPatterns: [{ pattern: 'SECRET-X' }] } })
    try {
      const outcome = await runExport(deps, { format: 'markdown' })
      assert.equal(outcome.redactionLevel, 'custom')
    } finally {
      await cleanup(tmp)
    }
  })
})
