/**
 * Event-log folding tests — order preservation, chunk accumulation, tools,
 * defensive handling of unknown event shapes.
 */

import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import { foldSession } from '../src/core/fold.ts'
import { eventOf, SAMPLE_EVENTS } from './helpers.ts'

describe('foldSession: narrative structure', () => {
  it('preserves strict source order: user, assistant, tool%call, tool%result', () => {
    const doc = foldSession(SAMPLE_EVENTS)
    const kinds = doc.entries.map((e) => e.kind)
    assert.deepEqual(kinds, ['user', 'assistant', 'tool_call', 'tool_result', 'assistant'])
    assert.equal(doc.counts.events, SAMPLE_EVENTS.length)
    assert.equal(doc.counts.entries, 5)
  })

  it('accumulates assistant/chunk deltas into a single message', () => {
    const doc = foldSession(SAMPLE_EVENTS)
    const assistant = doc.entries.filter((e) => e.kind === 'assistant')
    assert.equal(assistant.length, 2)
    const first = assistant[0]
    assert.ok(first && first.kind === 'assistant')
    assert.equal(
      first.content,
      'I inspected the code. The API key sk-abcdefghijklmnopqrstuvwxyz0123456 is hardcoded.',
    )
  })

  it('attaches usage tokens meta to the assistant message', () => {
    const doc = foldSession(SAMPLE_EVENTS)
    const assistant = doc.entries.find((e) => e.kind === 'assistant' && e.content.includes('hardcoded'))
    assert.ok(assistant && 'meta' in assistant && assistant.meta)
    assert.equal((assistant.meta as Record<string, unknown>).input_tokens, 12)
  })

  it('extracts tool call name + raw arguments and tool result content', () => {
    const doc = foldSession(SAMPLE_EVENTS)
    const call = doc.entries.find((e) => e.kind === 'tool_call')
    const result = doc.entries.find((e) => e.kind === 'tool_result')
    assert.ok(call && call.kind === 'tool_call')
    assert.equal(call.toolName, 'read_file')
    assert.ok(call.argumentsText.includes('auth.ts'))
    assert.ok(result && result.kind === 'tool_result')
    assert.ok(result.content.includes('hf_'))
  })
})

describe('foldSession: bookkeeping & tolerance', () => {
  it('student examples of bookkeeping events are excluded by default', () => {
    const events = [eventOf('todo/write', { todo: { text: 'x' } }, 1), ...SAMPLE_EVENTS]
    const doc = foldSession(events)
    assert.ok(!doc.entries.some((e) => e.kind === 'todo' || e.kind === 'system'))
  })

  it('includes notes when requested', () => {
    const events = [...SAMPLE_EVENTS, eventOf('todo/write', { todo: { text: 'add tests' } }, 99)]
    const doc = foldSession(events, { includeNotes: true })
    assert.ok(doc.entries.some((e) => e.kind === 'system' && e.sourceType === 'todo/write'))
  })

  it('handles unknown event types and malformed payloads without crashing', () => {
    const events = [
      eventOf('brand/new/v1', { value: 42 }, 1),
      eventOf('user/message', null, 2),
      eventOf('tool/call', { name: 'x' }, 3),
      eventOf('assistant/chunk', { turn: 1, step: 0, chunk: { text: 'hi' } }, 4),
      eventOf('assistant/chunk', { turn: 1, step: 0, chunk: { text: ' there' } }, 5),
    ]
    const doc = foldSession(events)
    assert.equal(doc.counts.events, 5)
    const last = doc.entries.at(-1)
    assert.ok(last && last.kind === 'assistant')
    assert.equal(last.content, 'hi there')
  })

  it('flushes unclosed chunks even without a closing assistant/message', () => {
    const events = [eventOf('assistant/chunk', { turn: 7, step: 2, chunk: { text: 'dangling' } }, 1)]
    const doc = foldSession(events)
    assert.equal(doc.entries.length, 1)
    const entry = doc.entries[0]
    assert.ok(entry && entry.kind === 'assistant')
    assert.equal(entry.content, 'dangling')
  })

  it('collects a document tree from path-like keys', () => {
    const events = [
      eventOf('tool/call', { path: 'src/a.ts', name: 'read' }, 1),
      eventOf('tool/result', { cwd: '/work/root', path: 'src/b.ts' }, 2),
    ]
    const doc = foldSession(events)
    assert.ok(doc.documents.includes('src/a.ts'))
    assert.ok(doc.documents.includes('src/b.ts'))
    assert.ok(doc.documents.includes('/work/root'))
  })

  it('collects models from provider/model fields', () => {
    const events = [eventOf('request/header', { model: 'deepseek-v4-flash' }, 1)]
    const doc = foldSession(events)
    assert.ok(doc.models.includes('deepseek-v4-flash'))
  })

  it('fills session identity from session/created', () => {
    const doc = foldSession(SAMPLE_EVENTS)
    assert.equal(doc.session.id, 'sess-abc123')
    assert.equal(doc.session.cwd, '/home/alice/project')
  })
})
