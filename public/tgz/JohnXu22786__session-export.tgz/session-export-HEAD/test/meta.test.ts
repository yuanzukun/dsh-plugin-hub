/**
 * Compliance metadata + filename + audit unit tests.
 */

import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import { buildHeader, renderHeaderText, FORMAT_VERSION } from '../src/core/meta.ts'
import { buildExportFileName, dateTag, formatExt, nextExportTag, safeFileName, sessionDirName } from '../src/core/filenames.ts'
import { summarizeAudit, renderAuditText } from '../src/core/audit.ts'
import type { ArchiveEntry } from '../src/core/archive.ts'

describe('compliance header', () => {
  it('contains all auditable fields', () => {
    const h = buildHeader({
      plugin: { name: 'p', version: '0.1.0' },
      session: { id: 's1', project: 'prj', cwd: '/x', createdAt: 1_700_000_000_000 },
      models: ['m1'],
      counts: { events: 4, entries: 3, byKind: { user: 1 } },
      sanitization: { enabled: true, level: 'standard', rules: ['api-key'], saltFingerprint: 'abc' },
      contentHash: { algorithm: 'sha256', value: 'deadbeef'.padEnd(64, '0') },
      warnings: ['warn'],
      now: new Date('2026-01-02T03:04:05.000Z'),
    })
    assert.equal(h.formatVersion, FORMAT_VERSION)
    assert.equal(h.session.id, 's1')
    assert.equal(h.exportedAt, '2026-01-02T03:04:05.000Z')
    assert.deepEqual(h.model, ['m1'])
    assert.equal(h.sanitization.level, 'standard')
    assert.equal(h.contentHash?.algorithm, 'sha256')
    assert.deepEqual(h.warnings, ['warn'])
    assert.equal(h.counts.entries, 3)
  })

  it('header text embeds the JSON record for Markdown', () => {
    const text = renderHeaderText(buildHeader({ plugin: { name: 'p', version: '1' } }))
    assert.ok(text.includes('"formatVersion"'))
    assert.ok(text.startsWith('<!--'))
  })
})

describe('filenames', () => {
  it('sanitizes windows-illegal and control characters', () => {
    assert.equal(safeFileName('a<b>c:d|e?f*g"h'), 'a_b_c_d_e_f_g_h')
    assert.equal(safeFileName('line\nbreak.txt'), 'line_break.txt')
  })

  it('handles reserved device names', () => {
    assert.ok(!/^con$/i.test(safeFileName('CON')))
    assert.equal(safeFileName('aux.txt').toLowerCase().startsWith('_aux'), true)
  })

  it('strips directory components and traversal', () => {
    assert.equal(safeFileName('../secret'), 'secret')
    assert.equal(safeFileName('C:\\Windows\\system.ini'), 'system.ini')
    assert.equal(safeFileName('a/b/c.md'), 'c.md')
  })

  it('sessionDirName is safe and unique-ish', () => {
    assert.equal(sessionDirName('sess/one:two'), safeFileName('sess/one:two'))
    assert.equal(sessionDirName(null), '_unsaved')
  })

  it('builds sortable UTC stamp names', () => {
    const d = new Date('2026-01-02T03:04:05.000Z')
    assert.equal(dateTag(d), '2026-01-02')
    assert.equal(formatExt('markdown'), 'md')
    assert.match(buildExportFileName(d, 'markdown'), /^2026-01-02_030405_markdown\.md$/)
    assert.match(buildExportFileName(d, 'markdown', 'abc12'), /^2026-01-02_030405-abc12_markdown\.md$/)
  })

  it('nextExportTag yields distinct values on consecutive calls', () => {
    const a = nextExportTag()
    const b = nextExportTag()
    assert.notEqual(a, b)
    assert.match(a, /^[a-z0-9]+$/)
  })

  it('truncates long names but never exceeds the limit, even with a giant extension', () => {
    assert.equal(safeFileName('x'.repeat(200) + '.md', 180).length, 180)
    assert.equal(safeFileName('x'.repeat(100) + '.' + 'y'.repeat(200), 180).length, 180)
    assert.ok(safeFileName('x'.repeat(100) + '.' + 'y'.repeat(200), 180).endsWith('y'))
  })
})

describe('audit summary', () => {
  const entry = (partial: Partial<ArchiveEntry> & Pick<ArchiveEntry, 'id' | 'format' | 'exportedAt' | 'date' | 'fileName' | 'relPath' | 'size' | 'sanitizationLevel' | 'redacted'>): ArchiveEntry => ({
    sessionId: null,
    project: null,
    contentHash: null,
    warnings: [],
    partCount: 1,
    ...partial,
  })

  it('aggregates by format, date, session and level', () => {
    const entries = [
      entry({ id: '1', format: 'markdown', exportedAt: '2026-01-02T00:00:00Z', date: '2026-01-02', fileName: 'a.md', relPath: 'a.md', size: 100, sessionId: 's1', sanitizationLevel: 'standard', redacted: true }),
      entry({ id: '2', format: 'jsonl', exportedAt: '2026-01-02T01:00:00Z', date: '2026-01-02', fileName: 'b.jsonl', relPath: 'b.jsonl', size: 50, sessionId: 's1', sanitizationLevel: 'custom', redacted: true }),
      entry({ id: '3', format: 'markdown', exportedAt: '2026-01-03T00:00:00Z', date: '2026-01-03', fileName: 'c.md', relPath: 'c.md', size: 25, sessionId: 's2', sanitizationLevel: 'none', redacted: false }),
    ]
    const report = summarizeAudit(entries)
    assert.equal(report.total, 3)
    assert.equal(report.totalBytes, 175)
    assert.equal(report.redacted, 2)
    assert.deepEqual(report.sanitized, { none: 1, standard: 1, custom: 1 })
    assert.equal(report.byFormat.length, 2)
    assert.equal(report.byDate.length, 2)
    assert.equal(report.bySession.length, 2)
    assert.equal(report.timeframe.first, '2026-01-02T00:00:00Z')
    const text = renderAuditText(report)
    assert.ok(text.includes('Total exports: 3'))
  })
})
