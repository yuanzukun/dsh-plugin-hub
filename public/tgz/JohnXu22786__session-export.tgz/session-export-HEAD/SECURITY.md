# Security Policy

`dsh-session-export` is a sanitization/compliance plugin: its whole purpose is to
make sure secrets do not reach exported artifacts. Take bugs here seriously.

## Supported versions

| Version | Supported          |
| ------- | ------------------ |
| 0.1.x   | :white_check_mark: |

## Reporting a vulnerability

Please report suspected vulnerabilities to
[security advisories](https://github.com/JohnXu22786/session-export/security/advisories/new)
rather than opening a public issue, especially anything in the redaction engine
(`src/core/redact.ts`) or archive path handling (`src/core/archive.ts`).

## Handling of sensitive data

- Redaction is **deterministic** (same secret → same masked value) so exports stay
  correlatable for compliance without exposing the secret.
- Set the `redaction.salt` configuration value to a private secret before
  distributing exports that should not be cross-matched.
- Exports are ruled out of safe harbor only if `redact: false` is explicitly
  requested at export time.

## Disclosure policy

We patch privately and, once a fix is released, publish an advisory describing the
affected versions and the timeline.
