/**
 * dsh bundle entry.
 *
 * Follows the DeepSeek Harness bundle convention: export `name`, `inject` and
 * `apply(ctx, config)`. The bundle ships as `package.json` + `cordis.patch.yml`
 * and is mounted by the loader; check `README.md` for installation.
 */

import { createLoadSession } from './adapter/backend.ts'
import type { PluginContext } from './adapter/types.ts'
import { registerCommands } from './commands.ts'
import { normalizeConfig } from './config.ts'
import { ArchiveManager } from './core/archive.ts'
import type { EngineDeps } from './engine.ts'
import { registerTools } from './tools.ts'

export const name = 'dsh-session-export'

export const inject = ['sessions', 'sessionPersistence', 'tools', 'commands'] as const

/** Keep in sync with `package.json` `version`. */
export const PLUGIN_VERSION = '0.1.0'

export function apply(ctx: PluginContext, rawConfig?: unknown): void {
  const config = normalizeConfig(rawConfig)

  // Even when disabled we keep the archives index readable; tools simply
  // refuse to export with a clear message.
  const archive = new ArchiveManager(config.outDir)
  const loadSession = createLoadSession(ctx)

  const deps: EngineDeps = {
    plugin: { name, version: PLUGIN_VERSION },
    getConfig: () => config,
    getArchive: () => archive,
    loadSession,
  }

  registerTools(ctx, deps)
  registerCommands(ctx, deps)
}
