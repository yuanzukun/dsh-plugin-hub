/**
 * Human-facing slash commands (`ctx.commands`).
 *
 * These wrap the same engine/archive operations as the model-facing tools so a
 * user can export from the chat without spending model tokens. Commands are
 * registered defensively: if the harness composition lacks `ctx.commands`,
 * tool-only operation still works (see `src/index.ts`).
 *
 * Surface:
 *   /session-export [format] [--id=<sid>] [--redact|--no-redact]
 *   /session-export-list [query] [--format=<f>] [--limit=<n>]
 *   /export-delete <id|path|file>
 *   /sanitize-config [--test <sample text>]
 *   /export-audit
 */

import type { EngineDeps } from './engine.ts'
import { renderAudit } from './tools.ts'
import { runExport } from './engine.ts'
import { Redactor } from './core/redact.ts'
import type { CommandsService } from './adapter/types.ts'

export interface CommandResult {
  text: string
}

export interface CommandInvocation {
  agent?: unknown
  rawInput?: string
  signal?: AbortSignal
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any
}

export interface CommandDefinition {
  name: string
  description: string
  input?: { hint?: string }
  handler: (invocation: CommandInvocation) => Promise<CommandResult> | CommandResult
}

/** Structural owner for a command definition (mirrors the harness shape). */
export function defineCommand(def: CommandDefinition): CommandDefinition {
  return def
}

function parseArgs(raw: string): { flags: Map<string, string | boolean>; positionals: string[] } {
  const flags = new Map<string, string | boolean>()
  const positionals: string[] = []
  for (const token of String(raw ?? '').trim().split(/\s+/)) {
    if (!token) continue
    if (token.startsWith('--')) {
      const body = token.slice(2)
      const eq = body.indexOf('=')
      if (eq >= 0) flags.set(body.slice(0, eq), body.slice(eq + 1))
      else flags.set(body, true)
    } else {
      positionals.push(token)
    }
  }
  return { flags, positionals }
}

export function exportCommands(deps: EngineDeps): CommandDefinition[] {
  const archive = deps.getArchive()
  const getConfig = deps.getConfig

  return [
    defineCommand({
      name: 'session-export',
      description: 'Export the current or a named session to the compliance archive (Markdown/JSONL/PDF, sanitized by default).',
      input: { hint: '[format] [--id=<session>] [--no-redact]' },
      async handler({ rawInput, signal }) {
        const { flags, positionals } = parseArgs(rawInput ?? '')
        const format = positionals[0] ?? flags.get('format')
        if (format && !['markdown', 'jsonl', 'pdf', 'all'].includes(String(format))) {
          return { text: `unsupported format "${String(format)}" (expected markdown|jsonl|pdf|all)` }
        }
        const redactFlag = flags.get('redact')
        const noRedact = flags.get('no-redact')
        const redact =
          noRedact === true || noRedact === 'true'
            ? false
            : redactFlag === true || redactFlag === 'true'
              ? true
              : undefined
        const params: import('./engine.ts').ExportParams = {}
        if (format && ['markdown', 'jsonl', 'pdf', 'all'].includes(String(format))) {
          params.format = format as import('./engine.ts').RequestedFormat
        }
        const id = flags.get('id')
        if (typeof id === 'string' && id.length > 0) params.sessionId = id
        if (redact !== undefined) params.redact = redact
        if (signal) params.signal = signal
        const outcome = await runExport(deps, params)
        const lines = [
          `Exported session ${outcome.sessionId ?? '(unknown)'}`,
          ...outcome.artifacts.map((a) => `  ${a.relPath} (${a.format}, ${a.size} bytes)`),
          `Sanitized: ${outcome.sanitized} (level ${outcome.redactionLevel})`,
          outcome.contentHash ? `Content hash: ${outcome.contentHash}` : '',
          ...outcome.warnings.map((w) => `Warning: ${w}`),
        ].filter((l) => l.length > 0)
        return { text: lines.join('\n') }
      },
    }),

    defineCommand({
      name: 'session-export-list',
      description: 'List or search archived session exports.',
      input: { hint: '[query] [--format=<f>] [--limit=<n>] [--id=<session>]' },
      async handler({ rawInput }) {
        const { flags, positionals } = parseArgs(rawInput ?? '')
        const query = positionals.join(' ')
        const limit = typeof flags.get('limit') === 'string' ? Number(flags.get('limit')) : NaN
        const filter: import('./core/archive.ts').ListFilter = {}
        if (query) filter.query = query
        const format = flags.get('format')
        if (typeof format === 'string') filter.format = format as import('./core/archive.ts').ExportFormat | 'all'
        const id = flags.get('id')
        if (typeof id === 'string' && id.length > 0) filter.sessionId = id
        if (Number.isFinite(limit) && limit > 0) filter.limit = Math.floor(limit)
        const { entries, total } = await archive.list(filter)
        if (entries.length === 0) return { text: `No archived exports${query ? ` matching "${query}"` : ''}.` }
        const lines = [`Archived exports (${total} total, showing ${entries.length}):`]
        for (const e of entries) {
          lines.push(`  ${e.id}  ${e.format.padEnd(8)} ${e.date}  ${e.fileName}  ${e.size}b${e.redacted ? '  [redacted]' : ''}`)
        }
        return { text: lines.join('\n') }
      },
    }),

    defineCommand({
      name: 'export-delete',
      description: 'Delete an archived export by archive id, file name or relative path.',
      input: { hint: '<id|path|filename>' },
      async handler({ rawInput }) {
        const target = String(rawInput ?? '').trim()
        if (!target) return { text: 'usage: /export-delete <id|path|filename>' }
        if (/\.{2}[\\/]/.test(target)) return { text: 'invalid target: no path traversal allowed' }
        const { entry, removedFiles } = await archive.remove(target)
        if (!entry) return { text: `no archived export matches "${target}"` }
        return { text: `Deleted ${entry.relPath}\n  removed files: ${removedFiles.join(', ') || '(none)'}` }
      },
    }),

    defineCommand({
      name: 'sanitize-config',
      description: 'Describe the active redaction settings or test a sample against them.',
      input: { hint: '[--test <text>]' },
      async handler({ rawInput }) {
        const { flags, positionals } = parseArgs(rawInput ?? '')
        if (flags.get('test') === true) {
          const sample = positionals.join(' ') || String((flags.get('test') as string) ?? '')
          if (!sample) return { text: 'usage: /sanitize-config --test <text>' }
          const r = await new Redactor(getConfig().redaction).redact(sample)
          return { text: `Matched rules: ${r.rules.join(', ') || '(none)'}\n${r.text}` }
        }
        const cfg = getConfig()
        const red = cfg.redaction
        return {
          text: [
            `Redaction enabled: ${red.enabled}`,
            `Level: ${red.level}`,
            `Path mode: ${red.pathMode} (roots: ${red.projectRoots.join(', ') || 'none'})`,
            `API keys: ${red.maskApiKeys}, env values: ${red.maskEnvValues}, bearer tokens: ${red.maskBearerTokens}`,
            `URL credentials: ${red.maskUrlCredentials}, absolute paths: ${red.maskAbsolutePaths}, emails: ${red.maskEmails}`,
            `Custom patterns: ${red.customPatterns.length}`,
            `AI masking: ${red.aiMaskEnabled}`,
            `Archive root: ${cfg.outDir}`,
          ].join('\n'),
        }
      },
    }),

    defineCommand({
      name: 'export-audit',
      description: 'Compliance/trend summary over all archived exports.',
      async handler() {
        return { text: await renderAudit(deps) }
      },
    }),
  ]
}

/** Register all commands onto a live ctx.commands (if present). */
export function registerCommands(ctx: Pick<{ commands: CommandsService }, 'commands'>, deps: EngineDeps): void {
  const register = ctx.commands?.register
  if (typeof register !== 'function') return
  for (const command of exportCommands(deps)) {
    try {
      register(command)
    } catch (err) {
      // Duplicate name in the same layer throws; skip rather than kill the
      // whole plugin fiber — but keep the failure visible.
      console.warn(`[dsh-session-export] failed to register command "/${command.name}": ${err instanceof Error ? err.message : String(err)}`)
    }
  }
}
