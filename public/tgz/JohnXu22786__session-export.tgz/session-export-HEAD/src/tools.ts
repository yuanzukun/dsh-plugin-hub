/**
 * Model-facing tools (`ctx.tools`).
 *
 * Tools registered by this plugin:
 *   - `session_export`        export a session to the compliance archive
 *   - `session_export_list`   list / search archived exports
 *   - `export_delete`         delete an archived export
 *   - `sanitize_config`       inspect or try out the active redaction rules
 *
 * Each `execute` returns the structured value declared by its `output.schema`;
 * the harness's registry validates that value, and the `output.render` step
 * turns it into a readable text block. Handlers stay thin and delegate to the
 * shared engine / archive manager so unit tests exercise the same code paths.
 */

import type { ExportFormat, ListFilter } from './core/archive.ts'
import { renderAuditText, summarizeAudit } from './core/audit.ts'
import type { EngineDeps, ExportOutcome } from './engine.ts'
import { runExport } from './engine.ts'
import { Redactor } from './core/redact.ts'
import { defineTool, jsonTextOutput, type ToolDefinition } from './adapter/defineTool.ts'
import type { ToolsService } from './adapter/types.ts'

const SCHEMA_OUTCOME = {
  type: 'object',
  properties: {
    ok: { type: 'boolean' },
    artifacts: { type: 'array', items: { type: 'string' } },
    sessionId: { type: ['string', 'null'] },
    sanitized: { type: 'boolean' },
    redactionLevel: { type: 'string' },
    contentHash: { type: ['string', 'null'] },
    warnings: { type: 'array', items: { type: 'string' } },
  },
  required: ['ok'],
} as const

type ExportArgs = { format?: string; sessionId?: string; redact?: boolean }

export function sessionExportTool(deps: EngineDeps): ToolDefinition<ExportArgs> {
  return defineTool<ExportArgs>({
    name: 'session_export',
    description:
      'Export a session (current or historical) to the compliance archive as a redacted Markdown, JSONL or PDF file. Redaction is deterministic (API keys, tokens, .env values, absolute paths) and on by default. Returns the archived file paths and a compliance summary.',
    parameters: {
      format: {
        type: 'string',
        description: 'Format: "markdown", "jsonl", "pdf" or "all". Default: the plugin default (markdown).',
        enum: ['markdown', 'jsonl', 'pdf', 'all'],
      },
      sessionId: {
        type: 'string',
        description: 'Session id to export. Omit to auto-detect the current session.',
      },
      redact: {
        type: 'boolean',
        description: 'Enable/disable sanitization for this export. Default: on.',
      },
    },
    output: jsonTextOutput(SCHEMA_OUTCOME),
    async execute(args, exec) {
      const format = normalizeFormat(args.format)
      if (format === null) {
        throw new Error(`unsupported format "${args.format ?? ''}" (expected markdown|jsonl|pdf|all)`)
      }
      const params: import('./engine.ts').ExportParams = { format, sessionId: args.sessionId ?? null }
      if (args.redact !== undefined) params.redact = args.redact
      if (exec?.signal) params.signal = exec.signal
      const outcome = await runExport(deps, params)
      return renderOutcome(outcome)
    },
  })
}

type ListArgs = {
  query?: string
  sessionId?: string
  format?: string
  before?: string
  after?: string
  limit?: number
}

export function sessionExportListTool(deps: EngineDeps): ToolDefinition<ListArgs> {
  const archive = deps.getArchive()
  return defineTool<ListArgs>({
    name: 'session_export_list',
    description:
      'List or search archived session exports. Supports filtering by session id, format, ISO date range, a free-text query and a result limit.',
    parameters: {
      query: { type: 'string', description: 'Substring match against file/session/path.' },
      sessionId: { type: 'string', description: 'Only exports of this session id.' },
      format: {
        type: 'string',
        description: 'Only exports of this format.',
        enum: ['markdown', 'jsonl', 'pdf', 'html', 'all'],
      },
      before: { type: 'string', description: 'Exports exported strictly before this ISO datetime.' },
      after: { type: 'string', description: 'Exports exported at or after this ISO datetime.' },
      limit: { type: 'integer', description: 'Maximum number of entries to return (default 50).' },
    },
    output: jsonTextOutput({ type: 'object', properties: { entries: { type: 'array' }, total: { type: 'number' } } }),
    async execute(args) {
      const filter: ListFilter = {}
      if (args.query) filter.query = args.query
      if (args.sessionId) filter.sessionId = args.sessionId
      const fmt = normalizeFormatEnum(args.format)
      if (fmt) filter.format = fmt
      if (args.before) filter.before = args.before
      if (args.after) filter.after = args.after
      if (typeof args.limit === 'number' && args.limit > 0) filter.limit = Math.floor(args.limit)
      const { entries, total } = await archive.list(filter)
      return {
        ok: true,
        total,
        entries: entries.map((e) => ({
          id: e.id,
          format: e.format,
          sessionId: e.sessionId,
          exportedAt: e.exportedAt,
          date: e.date,
          fileName: e.fileName,
          size: e.size,
          contentHash: e.contentHash,
          sanitizationLevel: e.sanitizationLevel,
          redacted: e.redacted,
        })),
      }
    },
  })
}

type DeleteArgs = { target: string }

export function exportDeleteTool(deps: EngineDeps): ToolDefinition<DeleteArgs> {
  const archive = deps.getArchive()
  return defineTool<DeleteArgs>({
    name: 'export_delete',
    description:
      'Delete an archived export, identified by its archive id or its relative path / file name. Only files inside the archive root and matching archive records can be deleted. Returns what was removed.',
    parameters: {
      target: {
        type: 'string',
        description: 'Archive id (e.g. exp-abc123) or the archived file name/path.',
        required: true,
      },
    },
    output: jsonTextOutput({
      type: 'object',
      properties: { removed: { type: 'boolean' }, entry: { type: ['string', 'null'] }, removedFiles: { type: 'array', items: { type: 'string' } } },
    }),
    async execute(args) {
      // Reject obvious path escapes before delegating (defense in depth).
      if (/\.{2}[\\/]/.test(args.target) || args.target.includes('\0')) {
        throw new Error('invalid delete target: no path traversal allowed')
      }
      const { entry, removedFiles } = await archive.remove(args.target)
      if (!entry) {
        throw new Error(`no archived export matches "${args.target}"`)
      }
      return { removed: true, entry: entry.relPath, removedFiles }
    },
  })
}

type SanitizeArgs = { action?: 'show' | 'test'; sample?: string }

export function sanitizeConfigTool(deps: EngineDeps): ToolDefinition<SanitizeArgs> {
  const getConfig = deps.getConfig
  return defineTool<SanitizeArgs>({
    name: 'sanitize_config',
    description:
      'Inspect the active sanitization configuration ("show") or run a text sample through the deterministic redaction rules ("test") so users/agents can verify masking before exporting.',
    parameters: {
      action: { type: 'string', description: '"show" (default) or "test".', enum: ['show', 'test'] },
      sample: { type: 'string', description: 'Text to run through the redaction rules (only for action=test).' },
    },
    output: jsonTextOutput({ type: 'object' }),
    async execute(args) {
      const cfg = getConfig()
      const red = cfg.redaction
      if (args.action === 'test') {
        if (typeof args.sample !== 'string') {
          throw new Error('action=test requires a "sample" text input')
        }
        const result = await new Redactor(cfg.redaction).redact(args.sample)
        return {
          ok: true,
          enabled: red.enabled,
          rules: result.rules,
          matchesReported: result.rules.length,
          output: result.text,
        }
      }
      return {
        ok: true,
        outDir: cfg.outDir,
        includeHash: cfg.includeHash,
        maxChunkBytes: cfg.maxChunkBytes,
        redaction: {
          enabled: red.enabled,
          level: red.level,
          pathMode: red.pathMode,
          projectRoots: red.projectRoots,
          maskApiKeys: red.maskApiKeys,
          maskEnvValues: red.maskEnvValues,
          maskBearerTokens: red.maskBearerTokens,
          maskUrlCredentials: red.maskUrlCredentials,
          maskAbsolutePaths: red.maskAbsolutePaths,
          maskEmails: red.maskEmails,
          customPatterns: red.customPatterns,
          aiMaskEnabled: red.aiMaskEnabled,
          saltFingerprint: red.salt ? '<set>' : null,
        },
        pdf: cfg.pdf,
      }
    },
  })
}

/** Audit view over the archive, returned as readable text. */
export async function renderAudit(deps: EngineDeps): Promise<string> {
  const { entries } = await deps.getArchive().list()
  return renderAuditText(summarizeAudit(entries))
}

/** Register all model-facing tools onto a live ctx.tools (if present). */
export function registerTools(
  ctx: Pick<{ tools: ToolsService }, 'tools'>,
  deps: EngineDeps,
): void {
  const register = ctx.tools?.register
  if (typeof register !== 'function') return
  const tools = [sessionExportTool(deps), sessionExportListTool(deps), exportDeleteTool(deps), sanitizeConfigTool(deps)]
  for (const tool of tools) {
    try {
      register(tool)
    } catch (err) {
      // A duplicate/shadowed tool name must not take the whole plugin down,
      // but the failure should not be invisible.
      console.warn(`[dsh-session-export] failed to register tool "${tool.name}": ${errMessage(err)}`)
    }
  }
}

function errMessage(err: unknown): string {
  return err instanceof Error ? err.message : String(err)
}

function normalizeFormat(raw: string | undefined): 'markdown' | 'jsonl' | 'pdf' | 'all' | null {
  if (raw === undefined || raw === '') return 'markdown'
  if (raw === 'markdown' || raw === 'jsonl' || raw === 'pdf' || raw === 'all') return raw
  return null
}

function normalizeFormatEnum(raw: string | undefined): ExportFormat | 'all' | undefined {
  if (!raw) return undefined
  if (raw === 'markdown' || raw === 'jsonl' || raw === 'pdf' || raw === 'html' || raw === 'all') return raw
  return undefined
}

function renderOutcome(outcome: ExportOutcome): Record<string, unknown> {
  return {
    ok: true,
    artifacts: outcome.artifacts.map((a) => a.relPath),
    sessionId: outcome.sessionId,
    sanitized: outcome.sanitized,
    redactionLevel: outcome.redactionLevel,
    contentHash: outcome.contentHash,
    warnings: outcome.warnings,
  }
}
