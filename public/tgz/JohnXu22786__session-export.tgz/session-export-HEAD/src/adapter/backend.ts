/**
 * Harness backend adapter.
 *
 * Bridges the DeepSeek Harness services (`ctx.sessions` and
 * `ctx.sessionPersistence`) to the engine's `loadSession` contract. The exact
 * persistence API can vary across harness versions, so reads are attempted
 * through several known signatures and degrade with a helpful error instead of
 * crashing.
 */

import type { RawSessionEvent } from '../core/fold.ts'
import type { SessionIdentity } from '../core/model.ts'
import type { LoadedSession } from '../engine.ts'
import type { PersistenceService, PluginContext, SessionsService, SessionEventLike } from './types.ts'

/** Defensively read a property that lives behind possibly-proxied objects. */
function probe(obj: object | null | undefined, key: string): unknown {
  if (!obj || typeof obj !== 'object') return undefined
  try {
    return (obj as Record<string, unknown>)[key]
  } catch {
    return undefined
  }
}

/** Resolve a session id without an explicit one (current/latest heuristics). */
export function resolveSessionId(ctx: Pick<PluginContext, 'sessions'>, explicit: string | null | undefined): string | null {
  if (explicit) return explicit
  const envId = process.env.DSH_SESSION_ID
  if (envId) return envId
  const s = ctx.sessions as SessionsService
  for (const key of ['current', 'active', 'default', 'latest']) {
    const value = probe(s, key)
    if (typeof value === 'string' && value.length > 0) return value
    if (value && typeof value === 'object') {
      const nested = probe(value, 'id')
      if (typeof nested === 'string' && nested.length > 0) return nested
    }
  }
  if (typeof s.id === 'string' && s.id.length > 0) return s.id
  return null
}

/**
 * Normalize the various ways a persistence call can return a session log into
 * an array of raw events.
 */
function toEvents(value: unknown): RawSessionEvent[] | null {
  if (Array.isArray(value)) return value.filter((e): e is SessionEventLike => e !== null && typeof e === 'object')
  if (value && typeof value === 'object') {
    const events = probe(value, 'events')
    if (Array.isArray(events)) return events.filter((e): e is SessionEventLike => e !== null && typeof e === 'object')
  }
  return null
}

async function collectAsMaybeAsync(value: Promise<unknown> | unknown): Promise<unknown> {
  let resolved = await value
  if (resolved && typeof resolved === 'object') {
    const v = resolved as { [Symbol.asyncIterator]?: () => AsyncIterator<unknown> }
    if (typeof v[Symbol.asyncIterator] === 'function') {
      const out: unknown[] = []
      for await (const item of v as AsyncIterable<unknown>) out.push(item)
      resolved = out
    }
  }
  return resolved
}

interface ReadOutcome {
  events: RawSessionEvent[]
  identity: SessionIdentity
}

/** Read a session's full log via the persistence seam. */
export async function readSessionLog(
  ctx: Pick<PluginContext, 'sessionPersistence' | 'sessions'>,
  sessionId: string,
): Promise<ReadOutcome> {
  const sp = ctx.sessionPersistence as PersistenceService
  const errors: string[] = []

  // Preferred: readFrom(id, fromSeq=0)
  if (typeof sp.readFrom === 'function') {
    try {
      const value = await collectAsMaybeAsync(sp.readFrom(sessionId, 0))
      const events = toEvents(value)
      if (events) return { events, identity: identityFor(sessionId) }
      errors.push('readFrom did not return a readable log')
    } catch (err) {
      errors.push(`readFrom: ${errMessage(err)}`)
    }
  }

  // inspect(id) may return a snapshot — preferred over `load`, which is a
  // cold-ownership operation and must not run for ids owned by live sessions.
  if (typeof sp.inspect === 'function') {
    try {
      const value = await collectAsMaybeAsync(sp.inspect(sessionId))
      const events = toEvents(value)
      if (events) return { events, identity: identityFor(sessionId) }
      errors.push('inspect did not return a readable log')
    } catch (err) {
      errors.push(`inspect: ${errMessage(err)}`)
    }
  }

  // load(id) → Session with .events (last resort for read access)
  if (typeof sp.load === 'function') {
    try {
      const value = await collectAsMaybeAsync(sp.load(sessionId))
      const events = toEvents(value)
      if (events) return { events, identity: identityFor(sessionId) }
      errors.push('load did not return a readable log')
    } catch (err) {
      errors.push(`load: ${errMessage(err)}`)
    }
  }

  // in-memory store fallback
  const sessions = ctx.sessions as SessionsService
  try {
    const value = await findInStore(sessions, sessionId)
    const found = await collectAsMaybeAsync(value)
    const events = toEvents(found)
    if (events) return { events, identity: identityFor(sessionId) }
  } catch (err) {
    errors.push(`sessions store: ${errMessage(err)}`)
  }

  throw new Error(
    `could not read session log for "${sessionId}" via ctx.sessionPersistence ` +
      `(attempted ${errors.join('; ') || 'no readable method found'}). ` +
      `Ensure a session-persistence backend (e.g. the JSONL backend) is active.`,
  )
}

function identityFor(id: string): SessionIdentity {
  return { id, project: null, cwd: null, createdAt: null }
}

async function findInStore(sessions: SessionsService, id: string): Promise<unknown> {
  if (typeof sessions.find === 'function') {
    try {
      const value = sessions.find((session: unknown) => probe(session as object | null, 'id') === id)
      return value !== undefined ? value : null
    } catch {
      /* fall through */
    }
  }
  // Direct map/get access, if the store exposes one.
  for (const key of ['get', 'byId']) {
    if (typeof sessions[key] === 'function') {
      try {
        const value = await (sessions[key] as (k: string) => unknown)(id)
        if (value !== undefined && value !== null) return value
      } catch {
        /* try next */
      }
    }
  }
  return null
}

/** Build the engine's `loadSession` from a live ctx. */
export function createLoadSession(ctx: PluginContext): (sessionId: string | null) => Promise<LoadedSession> {
  return async (sessionId) => {
    const id = resolveSessionId(ctx, sessionId)
    if (!id) {
      throw new Error(
        'no session id resolved: pass sessionId explicitly, or set DSH_SESSION_ID, ' +
          'or expose a `.current`/`.active` session on ctx.sessions',
      )
    }
    const { events } = await readSessionLog(ctx, id)
    return { session: identityFor(id), events }
  }
}

function errMessage(err: unknown): string {
  return err instanceof Error ? err.message : String(err)
}
