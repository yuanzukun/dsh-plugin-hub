/**
 * Local stand-in for `@deepseek-ai/dsh-tools`' `defineTool`.
 *
 * The harness's `defineTool` validates parameters, compiles the parameter DSL
 * into a JSON Schema and returns the definition; registering a well-formed
 * plain object through `ctx.tools.register` carries the same contract. This
 * shim keeps the plugin dependency-free and structurally typed while producing
 * exactly the shape the harness reads (name/description/parameters/output/
 * execute).
 */

export type ToolParameter = {
  type: 'string' | 'number' | 'boolean' | 'integer'
  required?: boolean
  description: string
  /** Freeform additional JSON-schema constraints (e.g. enum). */
  enum?: readonly (string | number)[]
}

export interface ToolOutput {
  schema: unknown
  render: (args: unknown, value: unknown) => Array<{ type: 'text'; text: string }>
}

/** Execution context handed to `execute` by the harness tool registry. */
export interface ToolExecContext {
  signal?: AbortSignal
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any
}

export interface ToolDefinition<P extends Record<string, unknown>> {
  name: string
  description: string
  parameters: { [K in keyof P]: ToolParameter }
  output: ToolOutput
  execute: (args: P, exec?: ToolExecContext) => Promise<unknown> | unknown
}

/** Type-safe identity: matches `defineTool`'s return contract. */
export function defineTool<P extends Record<string, unknown>>(definition: ToolDefinition<P>): ToolDefinition<P> {
  return definition
}

/**
 * `output` whose render step pretty-prints the JSON value the tool returned.
 * `execute` returns the structured value (matching `output.schema`); rendering
 * is the registry's job, so harness-side `INVALID_TOOL_OUTPUT` never fires.
 */
export function jsonTextOutput(schema: unknown): ToolOutput {
  return {
    schema,
    render: (_args, value) => [{ type: 'text', text: JSON.stringify(value ?? null, null, 2) }],
  }
}
