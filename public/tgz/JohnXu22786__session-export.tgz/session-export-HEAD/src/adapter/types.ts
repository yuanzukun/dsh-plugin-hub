/**
 * Minimal structural views of the DeepSeek Harness `ctx` surface used by this
 * plugin. These are deliberately loose so the plugin compiles and runs without
 * a dependency on `@deepseek-ai/*` types, while still validating the exact
 * fields the harness guarantees (per the bundle/tool/command references).
 */

export interface SessionEventLike {
  type: string
  seq?: unknown
  time?: unknown
  data?: unknown
}

/** Subset of `ctx.sessions` (in-memory `SessionStore`). */
export interface SessionsService {
  id?: unknown
  current?: unknown
  active?: unknown
  default?: unknown
  latest?: unknown
  find?: (pred: unknown) => unknown
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any
}

/** Subset of `ctx.sessionPersistence` (durability seam). */
export interface PersistenceService {
  readFrom?: (id: string, fromSeq?: number) => unknown
  load?: (id: string) => unknown
  inspect?: (id: string) => unknown
  locate?: (id: string) => unknown
  list?: () => unknown
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any
}

/** Subset of `ctx.tools` (tool registry). */
export interface ToolsService {
  register?: (definition: unknown) => unknown
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any
}

/** Subset of `ctx.commands` (human slash-command registry). */
export interface CommandsService {
  register?: (definition: unknown) => unknown
  [key: string]: unknown
}

/** Structural `ctx` accepted by `apply()` — only services we declare are touched. */
export interface PluginContext {
  sessions: SessionsService
  sessionPersistence: PersistenceService
  tools: ToolsService
  commands: CommandsService
}
