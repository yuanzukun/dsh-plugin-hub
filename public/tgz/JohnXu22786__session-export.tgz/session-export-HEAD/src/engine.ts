/**
 * Export engine — orchestrates one export job end to end.
 *
 * Pipeline: load session log → fold → sanitize → build compliance header →
 * render → chunk & write into the archive → record in the archive index.
 *
 * All harness-specific concerns are funneled through `EngineDeps` so the whole
 * pipeline runs under plain unit tests.
 */

import * as fs from 'node:fs/promises'
import * as path from 'node:path'
import {
  ArchiveManager,
  PARTS_SUFFIX,
  partFileName,
  recordExport,
  splitUtf8,
  type ArchiveEntry,
  type CreateEntryInput,
  type ExportFormat,
} from './core/archive.ts'
import { effectiveLevel, type SessionExportConfig } from './config.ts'
import { buildExportFileName, dateTag, nextExportTag } from './core/filenames.ts'
import { foldSession, type RawSessionEvent } from './core/fold.ts'
import { shortFingerprint, sha256Hex } from './core/hash.ts'
import { buildHeader, type PluginIdentity } from './core/meta.ts'
import type { ExportDocument, SessionIdentity } from './core/model.ts'
import { renderHtml } from './core/render/html.ts'
import { canonicalBody, renderJsonl } from './core/render/jsonl.ts'
import { renderMarkdown } from './core/render/markdown.ts'
import { generatePdf, writeUtf8, type PdfResult } from './core/render/pdf.ts'
import { Redactor, type RedactionConfig } from './core/redact.ts'

export type RequestedFormat = 'markdown' | 'jsonl' | 'pdf' | 'html' | 'all'

export interface ExportParams {
  format?: RequestedFormat
  sessionId?: string | null
  /** Explicit redaction override; undefined → follow config. */
  redact?: boolean
  /** Optional cancellation signal from the calling tool/command. */
  signal?: AbortSignal
}

export interface LoadedSession {
  session: SessionIdentity
  events: RawSessionEvent[]
}

export interface EngineDeps {
  plugin: PluginIdentity
  getConfig: () => SessionExportConfig
  getArchive: () => ArchiveManager
  /** Resolve + read the session log; `sessionId` null means "current/default". */
  loadSession: (sessionId: string | null) => Promise<LoadedSession>
  now?: () => Date
}

export interface ExportOutcome {
  /** Written & indexed archive entries (one per artifact). */
  artifacts: ArchiveEntry[]
  /** Main (human-facing) artifact. */
  primary: ArchiveEntry
  warnings: string[]
  sanitized: boolean
  redactionLevel: 'none' | 'standard' | 'custom'
  models: string[]
  contentHash: string | null
  /** The session id the artifacts were filed under. */
  sessionId: string | null
}

function saltFingerprint(salt: string): string | null {
  return salt.length > 0 ? shortFingerprint('', salt) : null
}

function abortError(): Error {
  const err = new Error('session-export aborted')
  err.name = 'AbortError'
  return err
}

/** Render, chunk and write one primary artifact; returns its archive record. */
async function writeArtifact(
  deps: EngineDeps,
  config: SessionExportConfig,
  sessionId: string | null,
  format: 'markdown' | 'jsonl' | 'html',
  content: string,
  now: Date,
  tag: string,
  makeInput: (bytes: number) => CreateEntryInput,
): Promise<ArchiveEntry> {
  const archive = deps.getArchive()
  const date = dateTag(now)
  const primaryName = buildExportFileName(now, format, tag)
  const ext = format === 'markdown' ? '.md' : format === 'jsonl' ? '.jsonl' : '.html'

  const limit = config.maxChunkBytes
  const parts = limit > 0 ? splitUtf8(content, limit) : [content]
  const partCount = parts.length

  const partFiles: string[] = []
  const sizes: number[] = []
  let totalBytes = 0
  const writtenAbs: string[] = []
  for (let i = 0; i < parts.length; i += 1) {
    const name = i === 0 ? primaryName : partFileName(primaryName, ext, i + 1)
    const { absolute, bytes } = await archive.writePrimary(sessionId, date, name, parts[i] ?? '')
    partFiles.push(name)
    sizes.push(bytes)
    writtenAbs.push(absolute)
    totalBytes += bytes
  }

  const entry = { ...makeInput(totalBytes), partCount }
  if (partCount > 1) {
    entry.warnings = [...entry.warnings, `large export split into ${partCount} parts`]
    const manifestPath = path.join(path.dirname(writtenAbs[0] ?? primaryName), `${primaryName}${PARTS_SUFFIX}`)
    const manifest = { primary: primaryName, partFiles, partCount, sizes }
    await fs.writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8')
  }

  const first = writtenAbs[0]
  if (!first) throw new Error('artifact produced no file on disk')
  return recordExport(archive, entry, first)
}

/**
 * Run a complete export job.
 *
 * `format: 'all'` produces markdown + jsonl + pdf. The pdf format degrades
 * gracefully (see `generatePdf`): when no browser binary exists it archives an
 * HTML artifact and adds a warning.
 */
export async function runExport(deps: EngineDeps, params: ExportParams = {}): Promise<ExportOutcome> {
  const config = deps.getConfig()
  const archive = deps.getArchive()
  const now = deps.now ? deps.now() : new Date()
  const warnings: string[] = []
  const artifacts: ArchiveEntry[] = []

  if (params.signal?.aborted) throw abortError()
  if (!config.enabled) {
    throw new Error('session-export is disabled in the active configuration')
  }

  const requested: RequestedFormat =
    params.format ?? (config.defaultFormat === 'auto' ? 'markdown' : config.defaultFormat)
  const tag = nextExportTag()

  const loaded = await deps.loadSession(params.sessionId ?? null)
  if (params.signal?.aborted) throw abortError()

  const rawDoc = foldSession(loaded.events, {
    includeNotes: config.includeNotes,
    includeDocuments: config.includeDocuments,
  })
  for (const w of rawDoc.warnings) warnings.push(w)

  // Archive ONLY under the resolved id so historical/named exports never land
  // under `_unsaved` when their log lacks an id-bearing event.
  const sessionKey = params.sessionId ?? loaded.session.id ?? rawDoc.session.id ?? null

  // Redaction is on by default; `redact:false` opts out for one-off exports.
  const redaction: RedactionConfig =
    params.redact === false
      ? { ...config.redaction, enabled: false }
      : params.redact === true
        ? { ...config.redaction, enabled: true }
        : config.redaction
  const effective = effectiveLevel({ ...config, redaction })
  const redactor = new Redactor(redaction)
  let doc: ExportDocument = rawDoc
  let firedRules: string[] = []
  if (redaction.enabled) {
    const out = await redactor.redactDocument(rawDoc)
    doc = out.document
    firedRules = out.rules
  }
  if (firedRules.length > 0) warnings.push(`active redaction rules: ${[...new Set(firedRules)].sort().join(', ')}`)

  const contentHash = config.includeHash
    ? ({ algorithm: 'sha256', value: sha256Hex(canonicalBody(doc)) } as const)
    : null

  const header = buildHeader({
    plugin: deps.plugin,
    session: doc.session,
    models: doc.models,
    counts: doc.counts,
    sanitization: {
      enabled: redaction.enabled,
      level: effective,
      rules: [...new Set(firedRules)].sort(),
      saltFingerprint: saltFingerprint(redaction.salt),
    },
    contentHash,
    warnings,
    now,
  })

  // NOTE: `header.warnings` is frozen at build time. Artifact-level warnings
  // that only become known while writing (chunking, PDF fallback) are recorded
  // on the archive index entry + sidecar and re-surfaced on the outcome.

  const baseInput = (format: ExportFormat, size: number): CreateEntryInput => ({
    format,
    sessionId: sessionKey,
    project: doc.session.project ?? null,
    exportedAt: now,
    fileName: buildExportFileName(now, format, tag),
    size,
    contentHash: contentHash?.value ?? null,
    sanitizationLevel: effective,
    redacted: redaction.enabled,
    warnings: [],
    partCount: 1,
  })

  if (requested === 'markdown' || requested === 'all') {
    const body = renderMarkdown(doc, header, {
      includeDocuments: config.includeDocuments,
      prettyToolArgs: config.prettyToolArgs,
      maxMessageChars: config.maxMessageChars,
    })
    artifacts.push(
      await writeArtifact(deps, config, sessionKey, 'markdown', body, now, tag, (bytes) =>
        baseInput('markdown', bytes),
      ),
    )
  }

  if (requested === 'jsonl' || requested === 'all') {
    const body = renderJsonl(doc, header)
    artifacts.push(
      await writeArtifact(deps, config, sessionKey, 'jsonl', body, now, tag, (bytes) =>
        baseInput('jsonl', bytes),
      ),
    )
  }

  if (requested === 'html') {
    const body = renderHtml(doc, header, { includeDocuments: config.includeDocuments })
    artifacts.push(
      await writeArtifact(deps, config, sessionKey, 'html', body, now, tag, (bytes) =>
        baseInput('html', bytes),
      ),
    )
  }

  if (requested === 'pdf' || requested === 'all') {
    const htmlBody = renderHtml(doc, header, { includeDocuments: config.includeDocuments })
    const date = dateTag(now)
    const pdfName = buildExportFileName(now, 'pdf', tag)
    const htmlName = buildExportFileName(now, 'html', tag)
    const dir = archive.sessionDir(sessionKey, date)
    const htmlAbs = path.join(dir, htmlName)
    const pdfAbs = path.join(dir, pdfName)
    await writeUtf8(htmlAbs, htmlBody)

    const pdf: PdfResult = await generatePdf(htmlAbs, pdfAbs, config.pdf)
    if (pdf.generated === 'pdf' && pdf.pdfPath) {
      // Success: keep the PDF, discard the intermediate HTML copy.
      const size = await fs.stat(pdf.pdfPath).then((s) => s.size).catch(() => 0)
      await fs.rm(htmlAbs, { force: true })
      if (size > 0) {
        artifacts.push(await recordExport(archive, { ...baseInput('pdf', size), fileName: pdfName }, pdf.pdfPath))
      } else {
        // Zero-byte/absent output: treat as a fallback (orphan cleaned below).
        const size2 = Buffer.byteLength(htmlBody, 'utf8')
        warnings.push('PDF generation wrote no output; archived the print-ready HTML instead')
        await writeUtf8(htmlAbs, htmlBody)
        artifacts.push(await recordExport(archive, { ...baseInput('html', size2), fileName: htmlName }, htmlAbs))
      }
    } else {
      const size = Buffer.byteLength(htmlBody, 'utf8')
      warnings.push(pdf.note)
      artifacts.push(await recordExport(archive, { ...baseInput('html', size), fileName: htmlName }, htmlAbs))
    }
  }

  const primary = artifacts[0]
  if (!primary) throw new Error(`unknown export format: ${requested}`)

  // Surface artifact-level warnings (chunking, PDF fallback) on the outcome too.
  for (const artifact of artifacts) {
    for (const w of artifact.warnings) {
      if (!warnings.includes(w)) warnings.push(w)
    }
  }

  return {
    artifacts,
    primary,
    warnings,
    sanitized: redaction.enabled,
    redactionLevel: effective,
    models: doc.models,
    contentHash: contentHash?.value ?? null,
    sessionId: sessionKey,
  }
}
