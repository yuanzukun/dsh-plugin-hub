/**
 * Plugin configuration.
 *
 * The dsh harness feeds config from the bundle's `cordis.patch.yml`; this
 * module defines the accepted shape and a strict `normalize()` so the plugin
 * never depends on a particular harness config schema version.
 */

import type { PdfEngineOptions } from './core/render/pdf.ts'
import type { PathRedactMode, RedactionConfig, RedactionLevel } from './core/redact.ts'
import * as path from 'node:path'

export type ImportFormat = 'markdown' | 'jsonl' | 'pdf'
export type ExportFormats = ImportFormat | 'all'
/** Resolve the default export format from dsh when set to 'auto'. */
export type DefaultFormat = ImportFormat | 'auto'

export interface SessionExportConfig {
  /** Master switch. When false, tools no-op with a friendly message. */
  enabled: boolean
  /** Archive root. Defaults to `$DSH_HOME/exports`. */
  outDir: string
  /** Format used when a caller does not request one explicitly. */
  defaultFormat: DefaultFormat
  /** Include low-value bookkeeping events (todos, commands, feedback…). */
  includeNotes: boolean
  /** Include the "document tree" appendix. */
  includeDocuments: boolean
  /** Split large exports above this byte size into numbered parts (0 = never). */
  maxChunkBytes: number
  /** Truncate stored message content in Markdown to this many chars (0 = never). */
  maxMessageChars: number
  /** Pretty-print JSON tool arguments in Markdown. */
  prettyToolArgs: boolean
  /** Emit a SHA-256 content hash in every compliance header. */
  includeHash: boolean
  redaction: RedactionConfig
  pdf: PdfEngineOptions
}

/** Default archive root: `$DSH_HOME/exports` (falling back to `~/.dsh/exports`). */
export function defaultOutDir(): string {
  const home = process.env.DSH_HOME ?? (process.env.HOME ?? process.env.USERPROFILE ?? '')
  if (home) return path.join(home, 'exports')
  return path.join('.', 'exports')
}

export const DEFAULT_CONFIG: SessionExportConfig = {
  enabled: true,
  outDir: defaultOutDir(),
  defaultFormat: 'markdown',
  includeNotes: false,
  includeDocuments: true,
  maxChunkBytes: 4 * 1024 * 1024,
  maxMessageChars: 0,
  prettyToolArgs: false,
  includeHash: true,
  redaction: {
    enabled: true,
    level: 'standard',
    maskApiKeys: true,
    maskEnvValues: true,
    maskBearerTokens: true,
    maskUrlCredentials: true,
    maskAbsolutePaths: true,
    pathMode: 'mask',
    projectRoots: [],
    maskEmails: false,
    customPatterns: [],
    aiMaskEnabled: false,
    salt: '',
  },
  pdf: { engine: 'auto' },
}

function asBool(value: unknown, fallback: boolean): boolean {
  if (typeof value === 'boolean') return value
  return fallback
}

function asNumber(value: unknown, fallback: number): number {
  let n = fallback
  if (typeof value === 'number' && Number.isFinite(value)) n = value
  else if (typeof value === 'string') {
    const parsed = Number(value)
    if (Number.isFinite(parsed)) n = parsed
  }
  return Math.max(0, n) // byte/char limits are never negative
}

function asString(value: unknown, fallback: string): string {
  return typeof value === 'string' && value.length > 0 ? value : fallback
}

function asPathMode(value: unknown): PathRedactMode {
  if (value === 'relative' || value === 'mask' || value === 'off') return value
  return 'mask'
}

function asLevel(value: unknown): RedactionLevel {
  if (value === 'none' || value === 'standard' || value === 'custom') return value
  return 'standard'
}

/**
 * Merge an arbitrary (possibly partial, harness-provided) config object over
 * the defaults without mutating the input.
 */
export function normalizeConfig(raw: unknown): SessionExportConfig {
  const input = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>
  const redaction = (input.redaction && typeof input.redaction === 'object'
    ? (input.redaction as Record<string, unknown>)
    : {}) as Record<string, unknown>

  const customPatterns = Array.isArray(redaction.customPatterns)
    ? redaction.customPatterns
        .filter((p): p is Record<string, unknown> => p !== null && typeof p === 'object')
        .map((p) => {
          const out: { pattern: string; flags?: string; replacement?: string } = {
            pattern: asString(p.pattern, ''),
          }
          const flags = p.flags === undefined ? undefined : asString(p.flags, 'g')
          if (flags !== undefined) out.flags = flags
          const replacement = p.replacement === undefined ? undefined : asString(p.replacement, '')
          if (replacement !== undefined) out.replacement = replacement
          return out
        })
    : []

  const projectRoots = Array.isArray(redaction.projectRoots)
    ? redaction.projectRoots.filter((r): r is string => typeof r === 'string' && r.length > 0)
    : []

  const defaultFormatRaw = input.defaultFormat
  const defaultFormat: DefaultFormat =
    defaultFormatRaw === 'jsonl' || defaultFormatRaw === 'pdf' || defaultFormatRaw === 'auto'
      ? defaultFormatRaw
      : 'markdown'

  return {
    enabled: asBool(input.enabled, DEFAULT_CONFIG.enabled),
    outDir: asString(input.outDir, DEFAULT_CONFIG.outDir),
    defaultFormat,
    includeNotes: asBool(input.includeNotes, DEFAULT_CONFIG.includeNotes),
    includeDocuments: asBool(input.includeDocuments, DEFAULT_CONFIG.includeDocuments),
    maxChunkBytes: asNumber(input.maxChunkBytes, DEFAULT_CONFIG.maxChunkBytes),
    maxMessageChars: asNumber(input.maxMessageChars, DEFAULT_CONFIG.maxMessageChars),
    prettyToolArgs: asBool(input.prettyToolArgs, DEFAULT_CONFIG.prettyToolArgs),
    includeHash: asBool(input.includeHash, DEFAULT_CONFIG.includeHash),
    redaction: {
      enabled: asBool(redaction.enabled, DEFAULT_CONFIG.redaction.enabled),
      level: asLevel(redaction.level),
      maskApiKeys: asBool(redaction.maskApiKeys, DEFAULT_CONFIG.redaction.maskApiKeys),
      maskEnvValues: asBool(redaction.maskEnvValues, DEFAULT_CONFIG.redaction.maskEnvValues),
      maskBearerTokens: asBool(redaction.maskBearerTokens, DEFAULT_CONFIG.redaction.maskBearerTokens),
      maskUrlCredentials: asBool(redaction.maskUrlCredentials, DEFAULT_CONFIG.redaction.maskUrlCredentials),
      maskAbsolutePaths: asBool(redaction.maskAbsolutePaths, DEFAULT_CONFIG.redaction.maskAbsolutePaths),
      pathMode: asPathMode(redaction.pathMode),
      projectRoots,
      maskEmails: asBool(redaction.maskEmails, DEFAULT_CONFIG.redaction.maskEmails),
      customPatterns,
      aiMaskEnabled: asBool(redaction.aiMaskEnabled, DEFAULT_CONFIG.redaction.aiMaskEnabled),
      salt: asString(redaction.salt, DEFAULT_CONFIG.redaction.salt),
    },
    pdf: {
      engine:
        input.pdf && typeof input.pdf === 'object' &&
        ((input.pdf as Record<string, unknown>).engine === 'chrome' ||
          (input.pdf as Record<string, unknown>).engine === 'html')
          ? ((input.pdf as Record<string, unknown>).engine as 'chrome' | 'html')
          : 'auto',
      ...(() => {
        const chromePath = asString(
          (input.pdf && typeof input.pdf === 'object' ? (input.pdf as Record<string, unknown>).chromePath : undefined) as
            | string
            | undefined,
          '',
        )
        return chromePath ? { chromePath } : {}
      })(),
    },
  }
}

/** Bump the header redaction level when custom rules/AI masking are engaged. */
export function effectiveLevel(config: SessionExportConfig): RedactionLevel {
  const r = config.redaction
  if (!r.enabled) return 'none'
  if (r.level === 'custom' || r.customPatterns.length > 0 || r.aiMaskEnabled) return 'custom'
  return 'standard'
}
