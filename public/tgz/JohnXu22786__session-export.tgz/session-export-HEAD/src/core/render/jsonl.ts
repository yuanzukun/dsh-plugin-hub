/**
 * JSONL renderer.
 *
 * Machine-readable complete record: line 1 is the compliance header, one JSON
 * object per transcript entry after it. Nothing is truncated here — for very
 * large sessions the archiver's chunking splits the file while keeping every
 * event intact.
 */

import type { ComplianceHeader } from '../meta.ts'
import type { ExportDocument, TranscriptEntry } from '../model.ts'

/** Deterministic JSON representation of one transcript entry. */
export function entryToJson(entry: TranscriptEntry): Record<string, unknown> {
  const base: Record<string, unknown> = {
    seq: entry.seq,
    sourceSeq: entry.sourceSeq,
    sourceType: entry.sourceType,
    kind: entry.kind,
    masked: entry.masked,
    time: entry.time != null ? new Date(entry.time).toISOString() : null,
  }
  if (entry.kind === 'tool_call') {
    base.toolName = entry.toolName
    base.argumentsText = entry.argumentsText
    base.truncated = entry.truncated
  } else if (entry.kind === 'tool_result') {
    base.toolName = entry.toolName ?? null
    base.content = entry.content
    base.errorName = entry.errorName
    base.errorCode = entry.errorCode
    base.truncated = entry.truncated
  } else {
    base.content = entry.content
    base.truncated = entry.truncated
  }
  if ('meta' in entry && entry.meta && Object.keys(entry.meta).length > 0) base.meta = entry.meta
  return base
}

/**
 * Canonical, stateless serialization of the transcript used for the content
 * hash. Format-independent so the same sanitized record always hashes the same
 * way regardless of which renderer produced the archive file.
 */
export function canonicalBody(doc: ExportDocument): string {
  return doc.entries.map((entry) => JSON.stringify(entryToJson(entry))).join('\n') + '\n'
}

export function renderJsonl(doc: ExportDocument, header: ComplianceHeader): string {
  const lines: string[] = []
  lines.push(JSON.stringify(header))
  for (const entry of doc.entries) lines.push(JSON.stringify(entryToJson(entry)))
  return lines.join('\n') + '\n'
}
