/**
 * Markdown renderer.
 *
 * Produces a readable narrative transcript: a metadata header, an optional
 * document-tree appendix, then a chronological thread of user/assistant turns
 * and tool activity. Tool arguments/results are wrapped in fences whose opening
 * bar is longer than any backtick run inside the content, so embedded fences
 * can never break the outer one.
 */

import type { ComplianceHeader } from '../meta.ts'
import { renderHeaderText } from '../meta.ts'
import type { ExportDocument, TranscriptEntry } from '../model.ts'

export interface MarkdownOptions {
  /** Include the document-tree appendix. Default: true. */
  includeDocuments?: boolean
  /** Pretty-print tool arguments JSON. Default: false. */
  prettyToolArgs?: boolean
  /** Truncate stored content to this many chars per message (0 = unlimited). */
  maxMessageChars?: number
}

export const TRUNCATION_MARKER =
  '\n\n<content truncated by exporter -- see archived JSONL for the full record>\n\n'

/** A fence one backtick longer than the longest run inside the content. */
function fenceBlock(content: string, lang = ''): string {
  const runs = content.match(/`+/g) ?? []
  const longest = runs.reduce((max, run) => Math.max(max, run.length), 0)
  const bar = '`'.repeat(longest + 1)
  const open = lang ? `${bar}${lang}` : bar
  return `${open}\n${content}\n${bar}`
}

function truncate(content: string, limit: number): string {
  if (limit <= 0 || content.length <= limit) return content
  return content.slice(0, limit) + TRUNCATION_MARKER
}

function renderEntry(entry: TranscriptEntry, opts: MarkdownOptions): string {
  const limit = opts.maxMessageChars ?? 0
  switch (entry.kind) {
    case 'user':
      return `## User${entry.masked ? ' *(sanitized)*' : ''}\n\n${truncate(entry.content, limit)}\n`
    case 'assistant':
      return `## Assistant${entry.masked ? ' *(sanitized)*' : ''}\n\n${truncate(entry.content, limit)}\n`
    case 'tool_call': {
      const head = `### Tool call: \`${entry.toolName}\`${entry.masked ? ' *(sanitized)*' : ''}`
      const raw = opts.prettyToolArgs ? prettyJson(entry.argumentsText) : entry.argumentsText
      if (raw.trim().length === 0) return `${head}\n`
      return `${head}\n\n${fenceBlock(truncate(raw, limit), 'json')}\n`
    }
    case 'tool_result': {
      const head = `#### Tool result: \`${entry.toolName ?? 'unknown'}\``
      const err = entry.errorName
        ? ` (error: ${entry.errorName}${entry.errorCode ? ` ${entry.errorCode}` : ''})`
        : ''
      if (entry.content.trim().length === 0 && !err) return `${head}\n\n*(empty result)*\n`
      const body = truncate(entry.content, limit)
      const rendered = body.includes('\n') ? fenceBlock(body) : body.trim()
      return `${head}${err}${entry.masked ? ' *(sanitized)*' : ''}\n\n${rendered}\n`
    }
    case 'system':
      return `## Note -- ${entry.sourceType}${entry.masked ? ' *(sanitized)*' : ''}\n\n${truncate(entry.content, limit)}\n`
    case 'todo':
      return `## Todo\n\n${truncate(entry.content, limit)}\n`
    case 'unknown':
    default:
      return `## ${entry.sourceType}\n\n${truncate(entry.content, limit)}\n`
  }
}

function prettyJson(raw: string): string {
  if (raw.trim().length === 0) return raw
  try {
    return JSON.stringify(JSON.parse(raw), null, 2)
  } catch {
    return raw
  }
}

/** Render a full Markdown export (header + title + body + appendix). */
export function renderMarkdown(
  doc: ExportDocument,
  header: ComplianceHeader,
  opts: MarkdownOptions = {},
): string {
  const title = '# Session export\n'
  const meta = renderHeaderText(header)

  const body: string[] = []
  for (const entry of doc.entries) body.push(renderEntry(entry, opts))

  const appendix: string[] = []
  if ((opts.includeDocuments ?? true) && doc.documents.length > 0) {
    appendix.push('## Document tree\n\n')
    for (const p of doc.documents) appendix.push(`- \`${p}\`\n`)
    appendix.push('\n')
  }

  const warnings =
    header.warnings.length > 0
      ? `## Export warnings\n\n${header.warnings.map((w) => `- ${w}`).join('\n')}\n\n`
      : ''
  return `${meta}${title}\n${body.join('\n\n')}\n${warnings}${appendix.join('')}`.trimEnd() + '\n'
}
