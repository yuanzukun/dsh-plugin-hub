/**
 * Self-contained HTML renderer (print-ready).
 *
 * This is the intermediate format for the PDF path: a single standalone HTML
 * file with embedded CSS, no external resources, a `meta` CSP, and print
 * styles. Opening it and choosing "Print to PDF" yields a clean PDF; the
 * `pdf.ts` module can also drive a headless Chromium automatically when one is
 * available.
 */

import type { ComplianceHeader } from '../meta.ts'
import type { ExportDocument, TranscriptEntry } from '../model.ts'

const CSP = "default-src 'none'; style-src 'unsafe-inline'"

const CSS = `
:root { color-scheme: light dark; }
body { font-family: -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
       max-width: 860px; margin: 0 auto; padding: 24px; line-height: 1.55; color: #1a1a1a; }
h1 { border-bottom: 2px solid #6b7280; padding-bottom: 8px; }
h2 { margin-top: 1.6em; border-bottom: 1px solid #e5e7eb; padding-bottom: 4px; }
h3 { margin-top: 1.2em; }
h4 { margin-top: 0.9em; font-style: italic; color: #444; }
pre { background: #f4f4f5; border: 1px solid #e4e4e7; border-radius: 6px; padding: 12px;
      overflow-x: auto; font-size: 13px; white-space: pre-wrap; word-break: break-word; }
code { font-family: ui-monospace, SFMono-Regular, Consolas, monospace; }
.meta { font-size: 12px; color: #555; border: 1px solid #ddd; border-radius: 6px; padding: 10px; margin-bottom: 24px; }
.meta pre { margin: 4px 0 0 0; }
.sanitized { color: #b45309; font-weight: 600; }
.user, .assistant { margin: 12px 0; }
.tool { background: #f8fafc; border-left: 3px solid #93c5fd; padding: 8px 12px; border-radius: 4px; }
.error { color: #b91c1c; }
@media print {
  body { padding: 0; max-width: 100%; }
  pre { white-space: pre-wrap; overflow: visible; }
  .tool { page-break-inside: avoid; }
}
@media (prefers-color-scheme: dark) {
  body { color: #eee; }
  pre, .tool { background: #111827; border-color: #374151; }
  .meta { color: #bbb; border-color: #374151; }
  .sanitized { color: #fbbf24; }
}
`.trim()

function esc(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

function renderEntryHtml(entry: TranscriptEntry): string {
  const badge = (label: string): string =>
    entry.masked ? ` <span class="sanitized">(${label})</span>` : ''
  switch (entry.kind) {
    case 'user':
      return `<div class="user"><h2>User${badge('sanitized')}</h2><div><pre>${esc(entry.content)}</pre></div></div>`
    case 'assistant':
      return `<div class="assistant"><h2>Assistant${badge('sanitized')}</h2><div><pre>${esc(entry.content)}</pre></div></div>`
    case 'tool_call':
      return `<div class="tool"><h3>Tool call: <code>${esc(entry.toolName)}</code>${badge('sanitized')}</h3><pre>${esc(entry.argumentsText)}</pre></div>`
    case 'tool_result': {
      const err = entry.errorName
        ? ` <span class="error">(error: ${esc(entry.errorName)}${entry.errorCode ? ' ' + esc(entry.errorCode) : ''})</span>`
        : ''
      return `<div class="tool"><h4>Tool result: <code>${esc(entry.toolName ?? 'unknown')}</code>${err}${badge('sanitized')}</h4><pre>${esc(entry.content)}</pre></div>`
    }
    case 'system':
    case 'todo':
    case 'unknown':
    default:
      return `<div class="user"><h2>${esc(entry.sourceType)}${badge('sanitized')}</h2><div><pre>${esc(entry.content)}</pre></div></div>`
  }
}

/** Render a single-file, offline-capable HTML document. */
export function renderHtml(
  doc: ExportDocument,
  header: ComplianceHeader,
  opts: { includeDocuments?: boolean } = {},
): string {
  const body = doc.entries.map((entry) => renderEntryHtml(entry)).join('\n')

  const documents =
    (opts.includeDocuments ?? true) && doc.documents.length > 0
      ? `<h2>Document tree</h2>\n${doc.documents.map((p) => `<pre>· ${esc(p)}</pre>`).join('\n')}`
      : ''

  const warnings =
    header.warnings.length > 0
      ? `<h2>Export warnings</h2>\n${header.warnings.map((w) => `<pre>· ${esc(w)}</pre>`).join('\n')}`
      : ''

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="${CSP}">
<title>Session export</title>
<style>${CSS}</style>
</head>
<body>
<div class="meta">
<strong>Session export -- compliance record</strong>
<pre>${esc(JSON.stringify(header, null, 2))}</pre>
</div>
${body}
${warnings}
${documents}
</body>
</html>
`
}
