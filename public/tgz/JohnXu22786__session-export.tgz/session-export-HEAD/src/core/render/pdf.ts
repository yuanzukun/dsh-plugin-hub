/**
 * PDF generation (lightweight, dependency-free by default).
 *
 * Approach: render the session as a print-ready standalone HTML file, then
 * either
 *   1. write just the HTML and instruct the user to "Print to PDF" (default
 *      behavior when no browser binary is available), or
 *   2. drive a headless Chromium/Edge (`--headless --print-to-pdf`) when one
 *      is discoverable — configured via `chromePath`/`CHROME_PATH`, falling
 *      back to common install locations.
 *
 * The output of every path is a real file on disk plus a structured result so
 * tool callers can learn exactly what was produced.
 */

import { spawn } from 'node:child_process'
import * as fs from 'node:fs/promises'
import * as path from 'node:path'
import { pathToFileURL } from 'node:url'

export interface PdfEngineOptions {
  /** `auto` tries Chromium, then falls back to HTML. Default: `auto`. */
  engine: 'auto' | 'chrome' | 'html'
  /** Explicit browser binary; overrides auto-discovery. */
  chromePath?: string
}

export const DEFAULT_PDF_OPTIONS: PdfEngineOptions = { engine: 'auto' }

export interface PdfResult {
  generated: 'pdf' | 'html'
  /** Absolute path of the generated PDF (null when the HTML fallback was used). */
  pdfPath: string | null
  /** Absolute path of the always-produced HTML file. */
  htmlPath: string
  /** Human-readable note for the caller (e.g. how to produce the PDF). */
  note: string
}

const KNOWN_LOCATIONS: readonly string[] = [
  process.env.PROGRAMFILES ? `${process.env.PROGRAMFILES}\\Google\\Chrome\\Application\\chrome.exe` : '',
  process.env['PROGRAMFILES(X86)'] ? `${process.env['PROGRAMFILES(X86)']}\\Google\\Chrome\\Application\\chrome.exe` : '',
  process.env.LOCALAPPDATA ? `${process.env.LOCALAPPDATA}\\Google\\Chrome\\Application\\chrome.exe` : '',
  process.env.PROGRAMFILES ? `${process.env.PROGRAMFILES}\\Microsoft\\Edge\\Application\\msedge.exe` : '',
  process.env['PROGRAMFILES(X86)'] ? `${process.env['PROGRAMFILES(X86)']}\\Microsoft\\Edge\\Application\\msedge.exe` : '',
  process.env.LOCALAPPDATA ? `${process.env.LOCALAPPDATA}\\Microsoft\\Edge\\Application\\msedge.exe` : '',
]

/**
 * Discover a usable Chromium-family binary. Returns and explicit path, the
 * `CHROME_PATH` env var, or the first non-empty candidate. Pure enough to
 * unit-test: candidates are injectable.
 */
export function resolveBrowserBinary(
  explicit?: string,
  candidatePaths: readonly string[] = KNOWN_LOCATIONS,
): string | null {
  const candidates = [explicit, process.env.CHROME_PATH, ...candidatePaths].filter(
    (c): c is string => typeof c === 'string' && c.length > 0,
  )
  return candidates[0] ?? null
}

/**
 * Generate a PDF from an HTML file via headless Chromium. Never throws for
 * environment reasons: on any failure (no binary, non-zero exit, timeout, or a
 * zero-byte/missing output) it removes the partial PDF and returns the HTML
 * fallback result so the caller can decide (and record) what happened.
 */
export async function generatePdf(
  htmlPath: string,
  pdfPath: string,
  opts: PdfEngineOptions = DEFAULT_PDF_OPTIONS,
): Promise<PdfResult> {
  const htmlFile = await fs.realpath(htmlPath).catch(() => htmlPath)
  const htmlUrl = pathToFileURL(htmlFile).href

  const htmlFallback = (note: string): PdfResult => ({
    generated: 'html',
    pdfPath: null,
    htmlPath,
    note,
  })

  if (opts.engine === 'html') {
    return htmlFallback(
      'PDF engine set to "html"; produced a print-ready HTML file instead. Open it and use "Print to PDF" to create the PDF.',
    )
  }

  const binary = resolveBrowserBinary(opts.chromePath)
  if (!binary) {
    return htmlFallback(
      'Chromium not available; produced a print-ready HTML file instead. Open it and use "Print to PDF" to create the PDF.',
    )
  }

  const args = [
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    '--disable-dev-shm-usage',
    `--print-to-pdf=${pdfPath}`,
    htmlUrl,
  ]

  const outcome = await new Promise<{ code: number; error: string | null }>((resolve) => {
    let child
    try {
      child = spawn(binary, args, { stdio: 'ignore', windowsHide: true })
    } catch (err) {
      resolve({ code: -1, error: err instanceof Error ? err.message : String(err) })
      return
    }
    const timer = setTimeout(() => {
      child.kill()
      resolve({ code: -1, error: 'timed out generating the PDF' })
    }, 60_000)
    child.on('error', (err) => {
      clearTimeout(timer)
      resolve({ code: -1, error: err.message })
    })
    child.on('close', (code) => {
      clearTimeout(timer)
      resolve({ code: code ?? -1, error: null })
    })
  })

  if (outcome.code !== 0) {
    await fs.rm(pdfPath, { force: true }).catch(() => undefined)
    return htmlFallback(
      outcome.error
        ? `headless browser failed (${outcome.error}); produced a print-ready HTML file instead. Use "Print to PDF" for the PDF.`
        : `headless browser exited with code ${outcome.code}; produced a print-ready HTML file instead. Use "Print to PDF" for the PDF.`,
    )
  }

  // Chromium can exit 0 while writing nothing; verify a non-empty file exists.
  const stat = await fs.stat(pdfPath).catch(() => null)
  if (!stat || stat.size === 0) {
    await fs.rm(pdfPath, { force: true }).catch(() => undefined)
    return htmlFallback(
      'headless browser reported success but wrote no PDF; produced a print-ready HTML file instead. Use "Print to PDF" for the PDF.',
    )
  }

  return {
    generated: 'pdf',
    pdfPath: await fs.realpath(pdfPath).catch(() => pdfPath),
    htmlPath,
    note: 'Generated via headless Chromium print-to-pdf.',
  }
}

/** Write a UTF-8 string to disk (creates parent directories). */
export async function writeUtf8(filePath: string, content: string): Promise<void> {
  await fs.mkdir(path.dirname(filePath), { recursive: true })
  await fs.writeFile(filePath, content, 'utf8')
}
