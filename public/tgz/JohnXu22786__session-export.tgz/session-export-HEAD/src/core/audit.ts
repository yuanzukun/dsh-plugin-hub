/**
 * Audit / trend view over the archive index.
 *
 * Aggregates exports by date, format, session and sanitization level so an
 * operator can answer "what did we export, when, and how sensitive was it?".
 */

import type { ArchiveEntry, ExportFormat } from './archive.ts'

export interface AuditGroup {
  key: string
  count: number
  bytes: number
}

export interface AuditReport {
  generatedAt: string
  total: number
  totalBytes: number
  redacted: number
  sanitized: { none: number; standard: number; custom: number }
  byFormat: AuditGroup[] & { key: ExportFormat | 'unknown' }
  byDate: AuditGroup[]
  bySession: AuditGroup[]
  timeframe: { first: string | null; last: string | null }
  levels: Record<string, number>
}

export function summarizeAudit(entries: readonly ArchiveEntry[]): AuditReport {
  const byFormat = new Map<string, AuditGroup>()
  const byDate = new Map<string, AuditGroup>()
  const bySession = new Map<string, AuditGroup>()
  const levels = new Map<string, number>()
  let totalBytes = 0
  let redacted = 0
  let first: string | null = null
  let last: string | null = null

  const bump = (map: Map<string, AuditGroup>, key: string, entry: ArchiveEntry): void => {
    const group = map.get(key) ?? { key, count: 0, bytes: 0 }
    group.count += 1
    group.bytes += entry.size
    map.set(key, group)
  }

  for (const entry of entries) {
    totalBytes += entry.size
    if (entry.redacted) redacted += 1
    levels.set(entry.sanitizationLevel, (levels.get(entry.sanitizationLevel) ?? 0) + 1)
    bump(byFormat, entry.format, entry)
    bump(byDate, entry.date, entry)
    bump(bySession, entry.sessionId ?? '_unsaved', entry)
    if (first === null || entry.exportedAt < first) first = entry.exportedAt
    if (last === null || entry.exportedAt > last) last = entry.exportedAt
  }

  const sort = (a: AuditGroup, b: AuditGroup): number => b.count - a.count

  const sanitized = { none: 0, standard: 0, custom: 0 }
  for (const [k, v] of levels) {
    if (k === 'none') sanitized.none = v
    else if (k === 'custom') sanitized.custom = v
    else sanitized.standard = v
  }

  return {
    generatedAt: new Date().toISOString(),
    total: entries.length,
    totalBytes,
    redacted,
    sanitized,
    byFormat: [...byFormat.values()].sort(sort) as AuditReport['byFormat'],
    byDate: [...byDate.values()].sort((a, b) => b.key.localeCompare(a.key)),
    bySession: [...bySession.values()].sort(sort),
    timeframe: { first, last },
    levels: Object.fromEntries(levels),
  }
}

/** Readable text rendering of an audit report (used by the CLI/command). */
export function renderAuditText(report: AuditReport): string {
  const lines: string[] = []
  lines.push('Session export audit')
  lines.push(`Generated: ${report.generatedAt}`)
  lines.push(`Total exports: ${report.total}`)
  lines.push(`Total bytes: ${report.totalBytes}`)
  lines.push(`Redacted exports: ${report.redacted}`)
  lines.push(
    `Sanitization levels: none=${report.sanitized.none} standard=${report.sanitized.standard} custom=${report.sanitized.custom}`,
  )
  lines.push(`Timeframe: ${report.timeframe.first ?? '—'} → ${report.timeframe.last ?? '—'}`)
  lines.push('')
  lines.push('By format:')
  for (const g of report.byFormat) lines.push(`  ${g.key}: ${g.count} (${g.bytes} bytes)`)
  lines.push('')
  lines.push('By date:')
  for (const g of report.byDate) lines.push(`  ${g.key}: ${g.count} (${g.bytes} bytes)`)
  lines.push('')
  lines.push('By session:')
  for (const g of report.bySession) lines.push(`  ${g.key}: ${g.count} (${g.bytes} bytes)`)
  return lines.join('\n') + '\n'
}
