/**
 * Public library surface of the session-export core.
 *
 * Everything here is harness-independent and can be imported directly by other
 * tooling (`dsh-session-export/core` package subpath) for rendering, redaction,
 * archiving or audit without a running harness context.
 */

export * from './archive.ts'
export * from './audit.ts'
export * from './filenames.ts'
export * from './fold.ts'
export * from './hash.ts'
export * from './meta.ts'
export * from './model.ts'
export * from './redact.ts'

export { canonicalBody, entryToJson, renderJsonl } from './render/jsonl.ts'
export { renderMarkdown, TRUNCATION_MARKER } from './render/markdown.ts'
export { renderHtml } from './render/html.ts'
export { generatePdf, resolveBrowserBinary, writeUtf8 } from './render/pdf.ts'
