/**
 * Archive management.
 *
 * Exports are stored on disk under `<outDir>/sessions/<session>/<YYYY-MM-DD>/`
 * with a sidecar `<file>.meta.json` per export and a `archives.json` index for
 * fast list/search. The index is best-effort: if it is missing or corrupt it
 * is transparently rebuilt by scanning the directory tree.
 *
 * Every path handled by this module is confined to the archive root — a path
 * traversal guard rejects anything outside it.
 */

import * as fs from 'node:fs/promises'
import * as path from 'node:path'
import { shortFingerprint, sha256Hex } from './hash.ts'
import { dateTag, formatExt, safeFileName, sessionDirName } from './filenames.ts'
import type { RedactionLevel } from './redact.ts'

export type ExportFormat = 'markdown' | 'jsonl' | 'html' | 'pdf'

export const INDEX_FILE = 'archives.json'
export const META_SUFFIX = '.meta.json'
export const PARTS_SUFFIX = '.parts.json'

/** One record of an archived export, persisted in the index and sidecars. */
export interface ArchiveEntry {
  id: string
  format: ExportFormat
  sessionId: string | null
  project: string | null
  exportedAt: string
  /** `YYYY-MM-DD` (UTC) of the export. */
  date: string
  /** File name (or first part's name) of the primary artifact. */
  fileName: string
  /** Forward-slash path relative to the archive root. */
  relPath: string
  size: number
  contentHash: string | null
  sanitizationLevel: RedactionLevel
  redacted: boolean
  warnings: string[]
  /** Number of parts when a large export was split (>1). */
  partCount: number
}

export interface ListFilter {
  sessionId?: string | null
  format?: ExportFormat | 'all'
  query?: string
  before?: string
  after?: string
  limit?: number
}

export interface ListResult {
  entries: ArchiveEntry[]
  total: number
}

/** Deterministic per-export identifier. */
export function exportId(fileName: string, sessionId: string | null): string {
  return `exp-${sha256Hex(`${sessionId ?? ''}:${fileName}`).slice(0, 12)}`
}

/** Part file name for the i-th (1-based) chunk of a primary export file. */
export function partFileName(base: string, ext: string, index: number): string {
  return `${base.slice(0, -ext.length)}.p${String(index).padStart(3, '0')}${ext}`
}

function relPathOf(outDir: string, absolute: string): string {
  return path.relative(outDir, absolute).split(path.sep).join('/')
}

export interface CreateEntryInput {
  format: ExportFormat
  sessionId: string | null
  project: string | null
  exportedAt: Date
  fileName: string
  size: number
  contentHash: string | null
  sanitizationLevel: RedactionLevel
  redacted: boolean
  warnings: string[]
  partCount: number
}

/** Whether a path resolves inside a root (both are expected absolute). */
export function isInside(root: string, candidate: string): boolean {
  const rel = path.relative(path.resolve(root), path.resolve(candidate))
  return rel !== '' && !rel.startsWith('..') && !path.isAbsolute(rel)
}

/** Resolve `relPath` (already confined) to an absolute path inside root. */
export function resolveInside(root: string, relPathFileName: string): string {
  const candidate = path.resolve(root, relPathFileName)
  if (!isInside(root, candidate)) throw new Error(`refusing to access path outside archive root: ${relPathFileName}`)
  return candidate
}

/**
 * Splits a UTF-8 string into parts without breaking multi-byte characters.
 * Each part is ≤ `maxBytes` bytes.
 */
export function splitUtf8(text: string, maxBytes: number): string[] {
  if (maxBytes <= 0 || Buffer.byteLength(text, 'utf8') <= maxBytes) return [text]
  const parts: string[] = []
  let current = ''
  let currentBytes = 0
  for (const ch of text) {
    const bytes = Buffer.byteLength(ch, 'utf8')
    if (currentBytes + bytes > maxBytes) {
      if (currentBytes > 0) {
        parts.push(current)
        current = ''
        currentBytes = 0
      }
      // A single code point larger than the limit gets its own part.
      if (bytes > maxBytes) {
        parts.push(ch)
        continue
      }
    }
    current += ch
    currentBytes += bytes
  }
  if (currentBytes > 0 || current.length > 0) parts.push(current)
  return parts
}

export class ArchiveManager {
  readonly outDir: string
  /** Serializes index read-modify-write cycles within one process. */
  private lockTail: Promise<unknown> = Promise.resolve()

  constructor(outDir: string) {
    this.outDir = path.resolve(outDir)
  }

  /** Chain a task behind the previous one so writers never interleave. */
  private withLock<T>(fn: () => Promise<T> | T): Promise<T> {
    const run = this.lockTail.then(fn, fn)
    this.lockTail = run.then(
      () => undefined,
      () => undefined,
    )
    return run
  }

  get indexFile(): string {
    return path.join(this.outDir, INDEX_FILE)
  }

  get sessionsRoot(): string {
    return path.join(this.outDir, 'sessions')
  }

  /** Absolute path of the directory a new export for `sessionId` goes to. */
  sessionDir(sessionId: string | null, date: string): string {
    return path.join(this.sessionsRoot, sessionDirName(sessionId), date)
  }

  async writePrimary(
    sessionId: string | null,
    date: string,
    fileName: string,
    content: string,
  ): Promise<{ absolute: string; bytes: number }> {
    const dir = this.sessionDir(sessionId, date)
    await fs.mkdir(dir, { recursive: true })
    const absolute = path.join(dir, safeFileName(fileName))
    const data = Buffer.from(content, 'utf8')
    await fs.writeFile(absolute, data)
    return { absolute, bytes: data.byteLength }
  }

  /** Write a sidecar JSON next to a primary file. */
  async writeSidecar(primaryAbs: string, payload: unknown): Promise<void> {
    await fs.writeFile(`${primaryAbs}${META_SUFFIX}`, `${JSON.stringify(payload, null, 2)}\n`, 'utf8')
  }

  async saveIndex(entries: readonly ArchiveEntry[]): Promise<void> {
    await fs.mkdir(this.outDir, { recursive: true })
    // Unique temp name prevents two concurrent writers from corrupting each
    // other's rename target.
    const tmp = `${this.indexFile}.tmp-${process.pid}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
    try {
      await fs.writeFile(tmp, `${JSON.stringify(entries, null, 2)}\n`, 'utf8')
      await fs.rename(tmp, this.indexFile)
    } finally {
      await fs.rm(tmp, { force: true }).catch(() => undefined)
    }
  }

  async loadIndex(): Promise<ArchiveEntry[]> {
    let raw: string
    try {
      raw = await fs.readFile(this.indexFile, 'utf8')
    } catch {
      return []
    }
    try {
      const parsed = JSON.parse(raw)
      if (!Array.isArray(parsed)) return []
      return parsed.filter((e): e is ArchiveEntry => e && typeof e === 'object' && typeof e.relPath === 'string')
    } catch {
      return [] // corrupt index; caller falls back to a disk rebuild
    }
  }

  async upsert(entry: ArchiveEntry): Promise<void> {
    await this.withLock(async () => {
      const entries = await this.loadIndex()
      const idx = entries.findIndex((e) => e.id === entry.id)
      if (idx >= 0) entries[idx] = entry
      else entries.push(entry)
      entries.sort((a, b) => b.exportedAt.localeCompare(a.exportedAt))
      await this.saveIndex(entries)
    })
  }

  /** Rebuild the index from disk state (used when the index is missing/corrupt). */
  async rebuildIndex(): Promise<ArchiveEntry[]> {
    const entries: ArchiveEntry[] = []
    const walk = async (dir: string): Promise<void> => {
      let children
      try {
        children = await fs.readdir(dir, { withFileTypes: true })
      } catch {
        return
      }
      for (const child of children) {
        const full = path.join(dir, child.name)
        if (child.isDirectory()) await walk(full)
        else if (child.isFile() && !child.name.endsWith(META_SUFFIX) && !child.name.endsWith(PARTS_SUFFIX) && child.name !== INDEX_FILE) {
          const meta = await this.readSidecar(full)
          const stat = await fs.stat(full).catch(() => null)
          if (meta) {
            // The sidecar's recorded size is authoritative (it is the summed
            // size across parts when the export was chunked).
            entries.push({ ...meta, size: meta.size ?? stat?.size ?? 0 })
          }
        }
      }
    }
    await walk(this.sessionsRoot)
    entries.sort((a, b) => b.exportedAt.localeCompare(a.exportedAt))
    await this.saveIndex(entries)
    return entries
  }

  /** Load entries, rebuilding from disk if the index file is unusable. */
  async entries(): Promise<ArchiveEntry[]> {
    const fromIndex = await this.loadIndex()
    if (fromIndex.length === 0) {
      // Could be an empty archive or a missing/corrupt index — scan the tree.
      return this.rebuildIndex()
    }
    return fromIndex
  }

  async list(filter: ListFilter = {}): Promise<ListResult> {
    const all = await this.entries()
    let out = all.filter((e) => {
      if (filter.sessionId !== undefined && filter.sessionId !== null && e.sessionId !== filter.sessionId) return false
      if (filter.format && filter.format !== 'all' && e.format !== filter.format) return false
      if (filter.before && e.exportedAt >= filter.before) return false
      if (filter.after && e.exportedAt < filter.after) return false
      if (filter.query) {
        const q = filter.query.toLowerCase()
        const hay = `${e.fileName} ${e.sessionId ?? ''} ${e.relPath} ${e.project ?? ''}`.toLowerCase()
        if (!hay.includes(q)) return false
      }
      return true
    })
    out.sort((a, b) => b.exportedAt.localeCompare(a.exportedAt))
    const total = out.length
    if (filter.limit && filter.limit > 0) out = out.slice(0, filter.limit)
    return { entries: out, total }
  }

  async findByIdOrPath(ref: string): Promise<ArchiveEntry | null> {
    const all = await this.entries()
    const byId = all.find((e) => e.id === ref)
    if (byId) return byId
    const norm = ref.split(/[\\/]/).join('/')
    return all.find((e) => e.relPath === norm || e.fileName === norm) ?? null
  }

/**
 * Delete an export identified by archive id or its relative path/file name.
 * Removes the primary artifact, part files and sidecars, prunes empty
 * directories up to the archive root, and updates the index.
 *
 * Only the index read-modify-write is serialized (via `withLock`); file
 * deletion and directory pruning happen outside the lock so no nested lock
 * call (e.g. through `entries()` → `rebuildIndex()`) can deadlock.
 */
async remove(ref: string): Promise<{ entry: ArchiveEntry | null; removedFiles: string[] }> {
  const entry = await this.findByIdOrPath(ref)
  if (!entry) return { entry: null, removedFiles: [] }

  const base = resolveInside(this.outDir, entry.relPath)
  const removedFiles = await this.deleteWithSidecars(base, entry.partCount)

  // Prune empty directories from the session dir up to (not including) root.
  let dir = path.dirname(base)
  while (dir !== this.outDir && path.dirname(dir) !== dir) {
    const remaining = await fs.readdir(dir).catch(() => null)
    if (remaining === null || remaining.length === 0) {
      await fs.rmdir(dir).catch(() => undefined)
      dir = path.dirname(dir)
    } else {
      break
    }
  }

  await this.withLock(async () => {
    const remaining = await this.entries()
    await this.saveIndex(remaining.filter((e) => e.id !== entry.id))
  })
  return { entry, removedFiles }
}

/**
 * Delete the artifacts for one export and return the paths that were actually
 * removed (primary, sidecars, parts manifest, part files).
 */
private async deleteWithSidecars(base: string, partCount: number): Promise<string[]> {
  const ext = path.extname(base)
  // All candidates are derived from an already-confined `base`, hence safe.
  const candidates = [
    base,
    `${base}${META_SUFFIX}`,
    `${base}${PARTS_SUFFIX}`,
    ...Array.from({ length: partCount }, (_, i) => partFileName(base, ext, i + 1)),
  ]
  const removedFiles: string[] = []
  for (const file of candidates) {
    const existed = await fs.access(file).then(() => true).catch(() => false)
    if (existed) {
      removedFiles.push(file)
      await fs.rm(file, { force: true }).catch(() => undefined)
    }
  }
  return removedFiles
}

private async readSidecar(primaryAbs: string): Promise<ArchiveEntry | null> {
  try {
    const raw = await fs.readFile(`${primaryAbs}${META_SUFFIX}`, 'utf8')
    const parsed = JSON.parse(raw) as ArchiveEntry
    if (!parsed || typeof parsed.relPath !== 'string') return null
    return parsed
  } catch {
    return null
  }
}
}

/**
 * Compose an ArchiveEntry and persist it (file already written by the caller).
 * `primaryAbs` must be a real path inside `archive.outDir`.
 */
export async function recordExport(
  archive: ArchiveManager,
  input: CreateEntryInput,
  primaryAbs: string,
): Promise<ArchiveEntry> {
  const relPath = relPathOf(archive.outDir, primaryAbs)
  const entry: ArchiveEntry = {
    id: exportId(input.fileName, input.sessionId),
    format: input.format,
    sessionId: input.sessionId,
    project: input.project,
    exportedAt: input.exportedAt.toISOString(),
    date: dateTag(input.exportedAt),
    fileName: input.fileName,
    relPath,
    size: input.size,
    contentHash: input.contentHash,
    sanitizationLevel: input.sanitizationLevel,
    redacted: input.redacted,
    warnings: input.warnings,
    partCount: input.partCount,
  }
  await archive.writeSidecar(primaryAbs, entry)
  await archive.upsert(entry)
  return entry
}
