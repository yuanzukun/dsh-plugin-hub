/**
 * Small hash helpers used for compliance hashing and deterministic
 * correlation fingerprints. Uses only the Node built-in `node:crypto`.
 */

import { createHash } from 'node:crypto'

/** Hex SHA-256 of a UTF-8 string. */
export function sha256Hex(input: string): string {
  return createHash('sha256').update(input, 'utf8').digest('hex')
}

/**
 * Short deterministic fingerprint of a secret, keyed with a salt when one is
 * configured. Sanitized values are replaced by `<redacted:... sha256:fp>` so
 * that (a) the true secret never leaves disk in the export and (b) the same
 * secret is consistently replaced — which keeps exports correlatable for
 * compliance without leaking the secret itself.
 */
export function shortFingerprint(secret: string, salt: string): string {
  return sha256Hex(`${salt}:${secret}`).slice(0, 12)
}
