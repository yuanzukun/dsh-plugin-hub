/**
 * Core data model for session export.
 *
 * The model is deliberately decoupled from any specific DeepSeek Harness
 * version: an adapter layer normalizes the harness "session log" into this
 * shape, and everything downstream (redaction, rendering, archiving,
 * compliance metadata) operates on it.
 */

export type TranscriptKind =
  | 'user'
  | 'assistant'
  | 'tool_call'
  | 'tool_result'
  | 'system'
  | 'todo'
  | 'unknown'

/** Base fields shared by every transcript entry. */
export interface TranscriptBase {
  /** Monotonic index derived from the source event order (starts at 0). */
  seq: number
  /** Original harness event `seq` when available, otherwise `null`. */
  sourceSeq: number | null
  /** Unix epoch *milliseconds* when the source event was recorded. */
  time: number | null
  /** Original harness event type (e.g. `user/message`), for diagnostics. */
  sourceType: string
  /** True when sanitization altered this entry at least once. */
  masked: boolean
}

export interface TextEntry extends TranscriptBase {
  kind: Exclude<TranscriptKind, 'tool_call' | 'tool_result'>
  content: string
  truncated: boolean
  /** Optional structured extras (e.g. usage tokens for assistant messages). */
  meta?: Record<string, unknown>
}

export interface ToolCallEntry extends TranscriptBase {
  kind: 'tool_call'
  toolName: string
  /** Raw arguments as the harness recorded them (usually a JSON string). */
  argumentsText: string
  truncated: boolean
}

export interface ToolResultEntry extends TranscriptBase {
  kind: 'tool_result'
  toolName: string | null
  content: string
  errorName: string | null
  errorCode: string | null
  truncated: boolean
}

export type TranscriptEntry = TextEntry | ToolCallEntry | ToolResultEntry

export type NamedTranscriptKind = Exclude<TranscriptKind, 'tool_call' | 'tool_result'>

/** Normalized identity of the exported session. */
export interface SessionIdentity {
  id: string | null
  project: string | null
  cwd: string | null
  createdAt: number | null
}

export interface DocumentCounts {
  events: number
  entries: number
  byKind: Partial<Record<TranscriptKind, number>>
}

/**
 * A fully folded, pre-sanitization view of a session. `redact()` operates on
 * this shape so determinism and per-entry masking flags are well-defined.
 */
export interface ExportDocument {
  session: SessionIdentity
  /** All transcript entries in strict source-event order. */
  entries: TranscriptEntry[]
  /**
   * Deduplicated file-like paths mentioned by the session (keys such as
   * `file`, `path`, `cwd`, `root`, `dir` found in event data). Presented as a
   * "document tree" appendix so archive consumers see which files were touched.
   */
  documents: string[]
  /** Unique model identifiers observed in the log (e.g. `deepseek-v4-flash`). */
  models: string[]
  counts: DocumentCounts
  warnings: string[]
}

/** Options controlling the event-log fold. */
export interface FoldOptions {
  /** Include low-value bookkeeping events as `system` entries. Default: false. */
  includeNotes?: boolean
  /** Collect file-like paths into `documents`. Default: true. */
  includeDocuments?: boolean
  /** When set, note events matching these types are included. */
  noteEventTypes?: readonly string[]
}
