/**
 * Deterministic sanitization engine.
 *
 * Redaction is rule-based and fully deterministic by default: the same input
 * always produces the same output, and matches are replaced with a stable
 * `<redacted:… sha256:fp>` fingerprint (see `hash.ts`) so archive consumers
 * can correlate a secret across exports without ever seeing it.
 *
 * The engine has no dependency on a model. An optional user-supplied
 * `aiMaskFn` hook can be enabled explicitly for heuristic masking on top of
 * the deterministic rules.
 */

import { shortFingerprint } from './hash.ts'
import type { ExportDocument, TranscriptEntry } from './model.ts'

export type RedactionLevel = 'none' | 'standard' | 'custom'
export type PathRedactMode = 'relative' | 'mask' | 'off'

export interface CustomPattern {
  pattern: string
  flags?: string
  /** Literal replacement. When omitted a fingerprint replacement is used. */
  replacement?: string
}

export interface RedactionConfig {
  enabled: boolean
  level: RedactionLevel
  maskApiKeys: boolean
  maskEnvValues: boolean
  maskBearerTokens: boolean
  maskUrlCredentials: boolean
  maskAbsolutePaths: boolean
  pathMode: PathRedactMode
  /** Absolute roots against which paths are relativized. */
  projectRoots: readonly string[]
  maskEmails: boolean
  customPatterns: readonly CustomPattern[]
  aiMaskEnabled: boolean
  /** Optional heuristic masker layered on top of the deterministic rules. */
  aiMaskFn?: (text: string) => string | Promise<string>
  /** Salt keying the correlation fingerprint. Empty string when unset. */
  salt: string
}

export const DEFAULT_REDACTION_CONFIG: RedactionConfig = {
  enabled: true,
  level: 'standard',
  maskApiKeys: true,
  maskEnvValues: true,
  maskBearerTokens: true,
  maskUrlCredentials: true,
  maskAbsolutePaths: true,
  pathMode: 'mask',
  projectRoots: [],
  maskEmails: false,
  customPatterns: [],
  aiMaskEnabled: false,
  salt: '',
}

export interface RedactResult {
  text: string
  /** Citations of rules that actually matched (seed-ordered, deduplicated). */
  rules: string[]
}

/** A single atomic rule: the regex geometry plus its replacement callback. */
interface Rule {
  label: string
  re: RegExp
  to: (match: string, groups: RegExpMatchArray) => string
}

/**
 * Text-level sanitizer. Create one instance per export and reuse it across all
 * entries so routing stays consistent within a single export job.
 */
export class Redactor {
  readonly config: RedactionConfig

  constructor(config: Partial<RedactionConfig> = {}) {
    this.config = { ...DEFAULT_REDACTION_CONFIG, ...config }
  }

  private fingerprint(secret: string, label: string): string {
    return `<redacted:${label} sha256:${shortFingerprint(secret, this.config.salt)}>`
  }

  /** Apply a single rule over `text`, recording the label when a match fired. */
  private matchReplace(text: string, rule: Rule, seen: Set<string>): string {
    const out: string[] = []
    let last = 0
    let m: RegExpExecArray | null
    const re = rule.re
    re.lastIndex = 0 // rules are reused across entries; always reset
    while ((m = re.exec(text)) !== null) {
      out.push(text.slice(last, m.index))
      out.push(rule.to(m[0], m))
      seen.add(rule.label)
      last = m.index + m[0].length
      if (m.index === re.lastIndex) re.lastIndex += 1 // guard zero-width matches
    }
    out.push(text.slice(last))
    return out.join('')
  }

  /** Relativize or fingerprint a single absolute path. */
  applyPath(path: string): string {
    if (this.config.pathMode === 'mask' || this.config.projectRoots.length === 0) {
      return this.fingerprint(path, 'path')
    }
    if (this.config.pathMode === 'relative') {
      const norm = path.replace(/[\\/]+/g, '/')
      const lower = norm.toLowerCase()
      for (const root of this.config.projectRoots) {
        const normRoot = String(root).replace(/[\\/]+/g, '/').replace(/\/+$/, '')
        if (!normRoot) continue
        const lowerRoot = normRoot.toLowerCase()
        if (lower === lowerRoot) return '<project-root>'
        if (lower.startsWith(`${lowerRoot}/`)) return `./${norm.slice(normRoot.length + 1)}`
      }
    }
    return this.fingerprint(path, 'path')
  }

  /** Replace absolute filesystem paths; returns the new text and whether changed. */
  private redactPaths(text: string, seen: Set<string>): string {
    if (!this.config.maskAbsolutePaths || this.config.pathMode === 'off') return text
    // Deliberately conservative: only replace paths we can identify confidently.
    //  - Windows drive paths: `C:\a\b` (and forward-slash variants)
    //  - UNC paths: `\\server\share\...`
    //  - POSIX home/workdir roots: `/home/…`, `/Users/…`, `/root/…`
    const rules: Rule[] = [
      {
        label: 'path-win',
        re: /[A-Za-z]:[\\/](?:[^\s\\/:*?"<>|]+[\\/])*[^\s\\/:*?"<>|]*/g,
        to: (m) => this.applyPath(m),
      },
      {
        label: 'path-unc',
        re: /\\\\[^\s\\]+\\[^\s\\]+(?:\\[^\s\\]+)*/g,
        to: (m) => this.applyPath(m),
      },
      {
        label: 'path-posix',
        re: /\/(?:home|Users|root)\/[^\s\\/:*?"<>|]+(?:[\\/][^\s\\/:*?"<>|]+)*/g,
        to: (m) => this.applyPath(m),
      },
    ]
    let out = text
    for (const rule of rules) {
      out = this.matchReplace(out, rule, seen)
    }
    return out
  }

  /**
   * Rules selected from the active config, in deterministic order.
   *
   * Ordering matters for correlation: `env-value` runs first so a
   * `KEY=sk-…` line is reduced to `KEY=<redacted:env sha256:hex>` in one step
   * and the token rules never see (and re-fingerprint) its value. Because the
   * fingerprint is derived from the *secret value* alone (not the rule label),
   * the same secret yields the same hex for `api-key` and `env` alike.
   */
  private selectRules(): Rule[] {
    const rules: Rule[] = []

    if (this.config.maskEnvValues) {
      rules.push({
        label: 'env-value',
        // `KEY=value` where KEY is an env-style identifier (1-64 chars). The
        // value is a single whitespace-free token or a quoted string, so a
        // pasted `.env` has its secrets masked WITHOUT swallowing the prose,
        // command, or tool output that follows on the same line or the next
        // line. Bounded and linear — no catastrophic-backtracking/DoS risk.
        re: /(^\s*|[,;\s])([A-Z][A-Z0-9_]{0,63})[ \t]*=[ \t]*((?:"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*')|[^\s,;]+)/gm,
        to: (m, g) => `${g[1]}${g[2]}=${this.fingerprint(g[3] ?? '', 'env')}`,
      })
    }

    if (this.config.maskApiKeys) {
      rules.push({
        label: 'api-key',
        re: /\b(?:sk-[A-Za-z0-9_-]{8,}|pk-[A-Za-z0-9_-]{8,}|ghp_[A-Za-z0-9]{20,}|gho_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|AIza[0-9A-Za-z_-]{30,})\b/g,
        to: (m) => this.fingerprint(m, 'api-key'),
      })
      rules.push({
        label: 'jwt',
        re: /\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b/g,
        to: (m) => this.fingerprint(m, 'jwt'),
      })
      rules.push({
        label: 'high-entropy-token',
        re: /\b[A-Za-z0-9_-]{32,}\b/g,
        to: (m) => this.fingerprint(m, 'token'),
      })
    }

    if (this.config.maskBearerTokens) {
      rules.push({
        label: 'bearer',
        re: /\b(?:Bearer|bearer|token|Token)\s+([A-Za-z0-9._~+/-]{12,})/g,
        to: (m, g) => m.slice(0, m.length - (g[1]?.length ?? 0)) + this.fingerprint(g[1] ?? '', 'token'),
      })
    }

    if (this.config.maskUrlCredentials) {
      rules.push({
        label: 'url-credential',
        re: /(https?:\/\/)([^/@\s]+)@/gi,
        to: (m, g) => `${g[1]}${this.fingerprint(g[2] ?? '', 'credential')}@`,
      })
    }

    if (this.config.maskEmails) {
      rules.push({
        label: 'email',
        re: /\b[\w.+-]+@[\w-]+\.[\w.-]+\b/g,
        to: (m) => this.fingerprint(m, 'email'),
      })
    }

    for (const cp of this.config.customPatterns) {
      if (!cp.pattern) continue
      let re: RegExp
      try {
        // Force the global flag: non-global exec() never advances lastIndex and
        // the substitution loop would spin forever.
        const flags = new Set(cp.flags ?? 'g')
        flags.add('g')
        re = new RegExp(cp.pattern, [...flags].join(''))
      } catch {
        continue // invalid user-supplied pattern: skip it, never fail the export
      }
      rules.push({
        label: `custom:${cp.pattern}`,
        re,
        to: (m) =>
          cp.replacement !== undefined && cp.replacement !== '' ? cp.replacement : this.fingerprint(m, 'custom'),
      })
    }

    return rules
  }

  /**
   * Sanitize a single text block. Returns the new text plus the ordered list
   * of rules that fired (deduplicated).
   */
  async redact(text: string): Promise<RedactResult> {
    if (!this.config.enabled) return { text, rules: [] }
    const seen = new Set<string>()
    let out = text
    for (const rule of this.selectRules()) {
      out = this.matchReplace(out, rule, seen)
    }
    out = this.redactPaths(out, seen)
    return { text: out, rules: [...seen] }
  }

  /**
   * Sanitize a transcript document: entries, the document-tree, and the session
   * cwd/project identity — so no absolute path escapes into headers/appendix.
   */
  async redactDocument(doc: ExportDocument): Promise<{ document: ExportDocument; rules: string[] }> {
    const rules = new Set<string>()
    const entries: TranscriptEntry[] = []
    for (const entry of doc.entries) {
      const candidate = { ...entry } as TranscriptEntry
      let changed = false

      const applyToText = async (value: string): Promise<string> => {
        const r = await this.redact(value)
        for (const rule of r.rules) rules.add(rule)
        if (r.rules.length > 0) changed = true
        return r.text
      }

      if ('content' in candidate) candidate.content = await applyToText(candidate.content)
      if ('argumentsText' in candidate) candidate.argumentsText = await applyToText(candidate.argumentsText)

      if (this.config.aiMaskEnabled && this.config.aiMaskFn) {
        if ('content' in candidate) {
          const masked = await this.config.aiMaskFn(candidate.content)
          if (masked !== candidate.content) {
            candidate.content = masked
            rules.add('ai-mask')
            changed = true
          }
        }
        if ('argumentsText' in candidate) {
          const masked = await this.config.aiMaskFn(candidate.argumentsText)
          if (masked !== candidate.argumentsText) {
            candidate.argumentsText = masked
            rules.add('ai-mask')
            changed = true
          }
        }
      }

      if (changed) {
        candidate.masked = true
        if ('meta' in candidate) candidate.meta = { ...(candidate.meta ?? {}), sanitized: true }
      }
      entries.push(candidate)
    }

    // Document tree + session identity must pass through the same rules so the
    // "redacted before anything touches disk" guarantee holds for headers and
    // the appendix, not just message bodies.
    const documents: string[] = []
    for (const p of doc.documents) {
      const r = await this.redact(p)
      for (const rule of r.rules) rules.add(rule)
      documents.push(r.text)
    }
    let session = { ...doc.session }
    if (typeof session.cwd === 'string' && session.cwd.length > 0) {
      const r = await this.redact(session.cwd)
      for (const rule of r.rules) rules.add(rule)
      session = { ...session, cwd: r.text }
    }
    if (typeof session.project === 'string' && session.project.length > 0) {
      const r = await this.redact(session.project)
      for (const rule of r.rules) rules.add(rule)
      session = { ...session, project: r.text }
    }

    return { document: { ...doc, entries, documents, session }, rules: [...rules] }
  }
}
