/**
 * Event-log folding.
 *
 * Converts a raw append-only session log (an ordered array of harness
 * `SessionEvent`s) into the normalized `ExportDocument` used by every
 * downstream stage. It is intentionally permissive about `data` shapes so the
 * plugin keeps working across harness versions: unknown payloads degrade to a
 * text representation instead of failing the whole export.
 */

import type {
  DocumentCounts,
  ExportDocument,
  FoldOptions,
  SessionIdentity,
  TextEntry,
  ToolCallEntry,
  ToolResultEntry,
  TranscriptEntry,
} from './model.ts'

/** Most permissive accepted shape of a raw harness event envelope. */
export type RawSessionEvent = Readonly<{
  type: string
  seq?: unknown
  time?: unknown
  data?: unknown
  ignorable?: unknown
}>

const DEFAULT_NOTE_EVENTS: readonly string[] = [
  'todo/write',
  'goal/change',
  'command/run',
  'command/done',
  'permission/',
  'feedback/',
  'session/end-seed',
  'compaction/',
]

/** Pull a printable string out of an arbitrary `data` payload. */
export function stringifyData(data: unknown, pretty = false): string {
  if (data === null || data === undefined) return ''
  if (typeof data === 'string') return data
  if (typeof data === 'number' || typeof data === 'boolean') return String(data)
  if (data instanceof Date) return data.toISOString()
  if (pretty) {
    try {
      return JSON.stringify(data, null, 2)
    } catch {
      /* fall through to non-pretty */
    }
  }
  try {
    return JSON.stringify(data)
  } catch {
    return String(data)
  }
}

/** Best-effort text extraction from a message-like payload. */
export function messageText(data: unknown): string {
  if (typeof data === 'string') return data
  if (data && typeof data === 'object') {
    const o = data as Record<string, unknown>
    for (const key of ['content', 'text', 'message', 'value']) {
      const v = o[key]
      if (typeof v === 'string' && v.length > 0) return v
    }
    if (Array.isArray(o.content)) {
      const parts: string[] = []
      for (const item of o.content) {
        if (item && typeof item === 'object') {
          const it = item as Record<string, unknown>
          if (typeof it.text === 'string') parts.push(it.text)
          else if (typeof it.text0 === 'string') parts.push(it.text0)
          else parts.push(stringifyData(item))
        } else {
          parts.push(stringifyData(item))
        }
      }
      return parts.join('\n')
    }
  }
  return ''
}

/** Recursively search an object for string values under "path-like" keys. */
function collectPathLikes(value: unknown, out: Set<string>): void {
  if (value === null || typeof value !== 'object') return
  if (Array.isArray(value)) {
    for (const item of value) collectPathLikes(item, out)
    return
  }
  const o = value as Record<string, unknown>
  for (const [k, v] of Object.entries(o)) {
    if (/^(file|path|cwd|root|dir)(s|name)?$/i.test(k) && typeof v === 'string' && v.length > 0) {
      out.add(v)
    } else {
      collectPathLikes(v, out)
    }
  }
}

function isNoteType(type: string, noteEvents: readonly string[] | undefined): boolean {
  const list = noteEvents ?? DEFAULT_NOTE_EVENTS
  for (const prefix of list) {
    if (prefix.endsWith('/')) {
      if (type.startsWith(prefix.slice(0, -1))) return true
    } else if (type === prefix) {
      return true
    }
  }
  return false
}

function emptyCounts(): DocumentCounts {
  return { events: 0, entries: 0, byKind: {} }
}

function bumpCounts(counts: DocumentCounts, kind: TranscriptEntry['kind']): void {
  counts.entries += 1
  counts.byKind[kind] = (counts.byKind[kind] ?? 0) + 1
}

/**
 * Fold a raw event log into a normalized document.
 *
 * Assistant streaming: `assistant/chunk` events carry raw deltas identified by
 * `(turn, step)`; the fold accumulates them and attaches the text to the
 * closing `assistant/message` for the same `(turn, step)`. Chunks without a
 * closing message are emitted as a standalone assistant entry.
 */
export function foldSession(events: readonly RawSessionEvent[], options: FoldOptions = {}): ExportDocument {
  const session: SessionIdentity = { id: null, project: null, cwd: null, createdAt: null }
  const entries: TranscriptEntry[] = []
  const documents = new Set<string>()
  const models = new Set<string>()
  const counts = emptyCounts()
  const warnings: string[] = []
  const chunkBuffer = new Map<string, string>()

  const includeNotes = options.includeNotes ?? false
  const includeDocuments = options.includeDocuments ?? true

  let ordering = 0

  const push = (entry: TranscriptEntry): void => {
    ordering += 1
    entries.push(entry)
    bumpCounts(counts, entry.kind)
  }

  const finishAssistant = (turn: number, step: number, override: string | null): TextEntry | null => {
    const key = `${turn}/${step}`
    const chunks = chunkBuffer.get(key)
    chunkBuffer.delete(key)
    if (override === null && (chunks === undefined || chunks.length === 0)) return null
    const entry: TextEntry = {
      kind: 'assistant',
      seq: ordering,
      sourceSeq: null,
      time: null,
      sourceType: 'assistant/stream',
      masked: false,
      content: override ?? chunks ?? '',
      truncated: false,
    }
    push(entry)
    return entry
  }

  for (const ev of events) {
    counts.events += 1
    const type = typeof ev.type === 'string' ? ev.type : 'unknown/event'
    const sourceSeq = typeof ev.seq === 'number' ? ev.seq : null
    const time = typeof ev.time === 'number' ? ev.time : null
    const data = (ev as { data?: unknown }).data ?? {}

    switch (type) {
      case 'user/message': {
        push({
          kind: 'user',
          seq: ordering,
          sourceSeq,
          time,
          sourceType: type,
          masked: false,
          content: messageText(data),
          truncated: false,
        })
        break
      }

      case 'assistant/chunk': {
        const o = (data ?? {}) as Record<string, unknown>
        const turn = typeof o.turn === 'number' ? o.turn : 0
        const step = typeof o.step === 'number' ? o.step : 0
        const raw = o.chunk
        const text =
          typeof raw === 'string'
            ? raw
            : raw !== null && typeof raw === 'object' && typeof (raw as { text?: unknown }).text === 'string'
              ? ((raw as { text: string }).text as string)
              : stringifyData(data)
        const key = `${turn}/${step}`
        const buffer = chunkBuffer.get(key) ?? ''
        chunkBuffer.set(key, buffer + text)
        break
      }

      case 'assistant/message': {
        const o = (data ?? {}) as Record<string, unknown>
        const turn = typeof o.turn === 'number' ? o.turn : 0
        const step = typeof o.step === 'number' ? o.step : 0
        const content = messageText(o.message ?? data)
        const entry = finishAssistant(turn, step, content === '' ? null : content)
        const usage = o.usage as Record<string, unknown> | undefined
        if (entry && usage && typeof usage === 'object') {
          const meta: Record<string, unknown> = {}
          for (const [k, v] of Object.entries(usage)) {
            if (typeof v === 'number') meta[k] = v
          }
          if (Object.keys(meta).length > 0) entry.meta = meta
        }
        break
      }

      case 'tool/call': {
        const o = (data ?? {}) as Record<string, unknown>
        const name = typeof o.name === 'string' ? o.name : typeof o.tool === 'string' ? o.tool : 'unknown'
        const args =
          typeof o.arguments === 'string'
            ? o.arguments
            : o.arguments !== undefined && o.arguments !== null
              ? stringifyData(o.arguments as object)
              : ''
        if (includeDocuments) collectPathLikes(data, documents)
        push({
          kind: 'tool_call',
          seq: ordering,
          sourceSeq,
          time,
          sourceType: type,
          masked: false,
          toolName: name,
          argumentsText: args,
          truncated: false,
        })
        break
      }

      case 'tool/result': {
        const o = (data ?? {}) as Record<string, unknown>
        const message = (o.message ?? data) as Record<string, unknown>
        const error = o.error as Record<string, unknown> | undefined
        if (includeDocuments) collectPathLikes(data, documents)
        push({
          kind: 'tool_result',
          seq: ordering,
          sourceSeq,
          time,
          sourceType: type,
          masked: false,
          toolName: typeof o.tool === 'string' ? o.tool : typeof o.name === 'string' ? o.name : null,
          content: messageText(message),
          errorName: error && typeof error.name === 'string' ? error.name : null,
          errorCode: error && typeof error.code === 'string' ? error.code : null,
          truncated: false,
        })
        break
      }

      default: {
        // Identity / model metadata is gathered eagerly from the event stream.
        if (includeDocuments) collectPathLikes(data, documents)
        if (typeof data === 'object' && data !== null) {
          const o = data as Record<string, unknown>
          if (typeof o.model === 'string') models.add(o.model)
          if (typeof o.provider === 'string') models.add(o.provider)
          if (Array.isArray(o.usage)) {
            for (const u of o.usage) collectModels(u, models)
          }
          if (o.session && typeof o.session === 'object') {
            const s = o.session as Record<string, unknown>
            if (session.id === null && typeof s.id === 'string') session.id = s.id
            if (typeof o.cwd === 'string' && session.cwd === null) session.cwd = o.cwd
          }
          if (typeof o.cwd === 'string' && session.cwd === null) session.cwd = o.cwd
          if (typeof o.project === 'string' && session.project === null) session.project = o.project
          if (
            typeof o.createdAt !== 'undefined' &&
            session.createdAt === null &&
            (typeof o.createdAt === 'number' || typeof o.createdAt === 'string')
          ) {
            const parsed = Date.parse(String(o.createdAt))
            if (!Number.isNaN(parsed)) session.createdAt = typeof o.createdAt === 'number' ? o.createdAt : parsed
          }
        }
        if (type === 'session/start' || type === 'session/created') {
          const o = (data ?? {}) as Record<string, unknown>
          if (typeof o.id === 'string' && session.id === null) session.id = o.id
        }
        if (includeNotes && isNoteType(type, options.noteEventTypes)) {
          const content = messageText(data) || stringifyData(data)
          if (content.length > 0) {
            push({
              kind: 'system',
              seq: ordering,
              sourceSeq,
              time,
              sourceType: type,
              masked: false,
              content,
              truncated: false,
            })
          }
        }
        break
      }
    }
  }

  // Flush any unclosed streaming buffers.
  for (const [key, text] of chunkBuffer) {
    const [turnRaw, stepRaw] = key.split('/').map((n) => Number(n))
    const turn = Number.isFinite(turnRaw) ? (turnRaw as number) : 0
    const step = Number.isFinite(stepRaw) ? (stepRaw as number) : 0
    if (text.length > 0) finishAssistant(turn, step, text)
  }
  chunkBuffer.clear()

  return {
    session,
    entries,
    documents: [...documents].sort(),
    models: [...models].sort(),
    counts,
    warnings,
  }
}

function collectModels(value: unknown, out: Set<string>): void {
  if (value === null || typeof value !== 'object') return
  const o = value as Record<string, unknown>
  if (typeof o.model === 'string') out.add(o.model)
  if (typeof o.name === 'string') out.add(o.name)
}

export const NOTE_EVENT_DEFAULTS: readonly string[] = DEFAULT_NOTE_EVENTS
