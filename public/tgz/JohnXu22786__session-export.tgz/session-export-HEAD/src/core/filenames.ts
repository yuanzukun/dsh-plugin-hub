/**
 * Filesystem- and platform-safe filename helpers.
 *
 * Every helper here must be safe on Windows *and* POSIX:
 *  - illegal characters `< > : " / \ | ? *` and control characters
 *  - reserved device names (CON, PRN, AUX, NUL, COM1..9, LPT1..9)
 *  - trailing dots/spaces
 *  - path traversal (`..`, leading `/`, drive letters)
 */

const ILLEGAL_RE = /[<>:"/\\|?*\u0000-\u001f]/g
const RESERVED = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i
const CONTROL_RE = /[\u0000-\u001f\u007f]/g

/** Strip path components; returns only a single safe file-name component. */
export function safeFileName(raw: string, maxLength = 180): string {
  let name = String(raw ?? '')
  // Remove any directory structure or drive/UNC prefix.
  name = name.replace(/^[A-Za-z]:[\\/]/, '').replace(/^[\\/]+/, '')
  name = name.split(/[\\/]/).at(-1) ?? name
  name = name.replace(ILLEGAL_RE, '_').replace(CONTROL_RE, '')
  name = name.replace(/^\.+/, '').replace(/[.\s]+$/, '')
  if (RESERVED.test(name)) name = `_${name}`
  if (name.length === 0) name = 'untitled'
  if (name.length > maxLength) {
    const ext = name.includes('.') ? name.slice(name.lastIndexOf('.')) : ''
    if (ext.length > maxLength) {
      name = name.slice(0, maxLength)
    } else {
      name = `${name.slice(0, maxLength - ext.length)}${ext}`
    }
  }
  return name
}

/** UTC date tag `YYYY-MM-DD`. */
export function dateTag(date: Date): string {
  return date.toISOString().slice(0, 10)
}

/** UTC clock tag `HHMMSS`. */
export function clockTag(date: Date): string {
  return date.toISOString().slice(11, 19).replace(/:/g, '')
}

/** A directory name that is unique per session yet filesystem-safe. */
export function sessionDirName(sessionId: string | null): string {
  if (!sessionId) return '_unsaved'
  return safeFileName(sessionId, 64) || '_unsaved'
}

/** File extension per export format. */
export function formatExt(format: string): string {
  switch (format) {
    case 'markdown':
      return 'md'
    case 'jsonl':
      return 'jsonl'
    case 'html':
      return 'html'
    case 'pdf':
      return 'pdf'
    default:
      return 'txt'
  }
}

/**
 * Build `<YYYY-MM-DD>_<HHMMSS>[-<tag>]_<formatAlias>.<ext>` inside the
 * session/date directory. The clock tag keeps exports of the same session
 * distinct; the optional `tag` disambiguates exports made within the same
 * second (see `nextExportTag`).
 */
export function buildExportFileName(d: Date, format: string, tag = ''): string {
  const stamp = `${dateTag(d)}_${clockTag(d)}`
  const suffix = tag ? `-${tag}` : ''
  return `${stamp}${suffix}_${format}.${formatExt(format)}`
}

let tagCounter = 0

/**
 * A short, process-unique tag for export file names. Combines the pid, the
 * wall clock and a monotonic counter so two exports in the same second (even
 * in different processes) never collide on disk.
 */
export function nextExportTag(): string {
  tagCounter += 1
  return `${process.pid.toString(36)}${Date.now().toString(36)}${tagCounter.toString(36)}`
}
