/**
 * Compliance metadata ("header") attached to every export.
 *
 * All export formats carry the same metadata so archives remain auditable:
 * session identity, model identifiers, sanitization level, event/message
 * counts, an optional content hash, and warnings.
 */

import type { DocumentCounts, ExportDocument } from './model.ts'
import type { RedactionLevel } from './redact.ts'

export const FORMAT_VERSION = 1

export interface PluginIdentity {
  name: string
  version: string
}

export interface SanitizationHeader {
  enabled: boolean
  level: RedactionLevel
  rules: string[]
  saltFingerprint: string | null
}

export interface ContentHash {
  algorithm: string
  value: string
}

export interface ComplianceHeader {
  formatVersion: number
  plugin: PluginIdentity
  session: {
    id: string | null
    project: string | null
    cwd: string | null
    createdAt: string | null
  }
  exportedAt: string
  model: string[]
  sanitization: SanitizationHeader
  counts: DocumentCounts
  contentHash: ContentHash | null
  warnings: string[]
}

export interface BuildHeaderOptions {
  plugin: PluginIdentity
  session?: ExportDocument['session']
  models?: readonly string[]
  counts?: DocumentCounts
  sanitization?: SanitizationHeader
  contentHash?: ContentHash | null
  warnings?: readonly string[]
  now?: Date
}

/** Compose the compliance header shared by every renderer. */
export function buildHeader(opts: BuildHeaderOptions): ComplianceHeader {
  const now = opts.now ?? new Date()
  return {
    formatVersion: FORMAT_VERSION,
    plugin: opts.plugin,
    session: {
      id: opts.session?.id ?? null,
      project: opts.session?.project ?? null,
      cwd: opts.session?.cwd ?? null,
      createdAt:
        opts.session?.createdAt != null ? new Date(opts.session.createdAt).toISOString() : null,
    },
    exportedAt: now.toISOString(),
    model: [...(opts.models ?? [])],
    sanitization: opts.sanitization ?? {
      enabled: false,
      level: 'none',
      rules: [],
      saltFingerprint: null,
    },
    counts: opts.counts ?? { events: 0, entries: 0, byKind: {} },
    contentHash: opts.contentHash ?? null,
    warnings: [...(opts.warnings ?? [])],
  }
}

/** Rendered as the Markdown front block. ASCII-safe for maximum portability. */
export function renderHeaderText(header: ComplianceHeader): string {
  const lines = JSON.stringify(header, null, 2)
  return `<!--\n  === Session export metadata (compliance record) ===\n${lines}\n-->\n`
}
