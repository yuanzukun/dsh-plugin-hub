window.__ModuleLoader__.load({
  id: 'dsh-kiro',
  factory(require) {
    const React = require('react')
    const { useCallback, useEffect, useMemo, useState, useSyncExternalStore } = React
    // React 18 exposes the store hook; a host without it renders the snapshot once.
    const useStoreSnapshot = typeof useSyncExternalStore === 'function'
      ? useSyncExternalStore
      : (_subscribe, getSnapshot) => getSnapshot()
    const API = '/kiro/api'
    const NS = 'dsh-kiro'
    const STYLE_ID = 'dsh-kiro-settings-style'
    const KIRO_BODY_PATH = 'M398.554 818.914C316.315 1001.03 491.477 1046.74 620.672 940.156C658.687 1059.66 801.052 970.473 852.234 877.795C964.787 673.567 919.318 465.357 907.64 422.374C827.637 129.443 427.623 128.946 358.8 423.865C342.651 475.544 342.402 534.18 333.458 595.051C328.986 625.86 325.507 645.488 313.83 677.785C306.873 696.424 297.68 712.819 282.773 740.645C259.915 783.881 269.604 867.113 387.87 823.883L399.051 818.914H398.554Z'
    const KIRO_LEFT_EYE_PATH = 'M636.123 549.353C603.328 549.353 598.359 510.097 598.359 486.742C598.359 465.623 602.086 448.977 609.293 438.293C615.504 428.852 624.697 424.131 636.123 424.131C647.555 424.131 657.492 428.852 664.447 438.541C672.398 449.474 676.623 466.12 676.623 486.742C676.623 525.998 661.471 549.353 636.375 549.353H636.123Z'
    const KIRO_RIGHT_EYE_PATH = 'M771.24 549.353C738.445 549.353 733.477 510.097 733.477 486.742C733.477 465.623 737.203 448.977 744.41 438.293C750.621 428.852 759.814 424.131 771.24 424.131C782.672 424.131 792.609 428.852 799.564 438.541C807.516 449.474 811.74 466.12 811.74 486.742C811.74 525.998 796.588 549.353 771.492 549.353H771.24Z'

    const en = {
      title: 'Kiro',
      description: 'Connect a Kiro account, keep its token refreshed, and discover the models available to it.',
      account: 'Account',
      accounts: 'Accounts',
      addAccount: 'Add account',
      useAccount: 'Use',
      reconnect: 'Sign in again',
      removeAccount: 'Remove',
      removeAccountConfirm: 'Remove this account from dsh-kiro?',
      activeAccount: 'Active',
      accountReady: 'Ready',
      accountNeedsRefresh: 'Refreshes on next use',
      accountNeedsLogin: 'Needs sign-in',
      accountsHint: 'Requests use the active account. The choice applies to every session.',
      signOutAll: 'Sign out all',
      signedOut: 'Not signed in',
      managed: 'Managed by dsh-kiro',
      external: 'Using Kiro IDE / CLI sign-in',
      connectKiro: 'Sign in',
      connectManaged: 'Sign in with dsh-kiro',
      externalHint: 'Kiro IDE / CLI owns this credential, so dsh-kiro never modifies or deletes it — which is also why Sign out cannot remove it. Sign in above to store a credential this plugin manages and refreshes itself; it takes precedence over the Kiro one.',
      connectTitle: 'Connect Kiro',
      chooseMethod: 'Choose how you want to connect your Kiro account.',
      recommended: 'Recommended',
      builderDesc: 'Best for most users. Sign in with a free AWS Builder ID.',
      idcDesc: 'Use your organization’s AWS IAM Identity Center.',
      googleDesc: 'Get a one-time code and sign in on app.kiro.dev with Google.',
      githubDesc: 'Get a one-time code and sign in on app.kiro.dev with GitHub.',
      refreshDesc: 'Paste an existing refresh token from Kiro IDE.',
      apiDesc: 'Use a long-lived Kiro or CodeWhisperer API key.',
      externalDesc: 'Import CLIProxyAPI Microsoft external-IdP JSON.',
      back: 'Back',
      close: 'Close',
      openBrowser: 'Open browser',
      authorizationUrl: 'Authorization URL',
      copy: 'Copy',
      copied: 'Copied',
      method: 'Login method',
      builderId: 'AWS Builder ID',
      idc: 'IAM Identity Center',
      google: 'Google',
      github: 'GitHub',
      refreshToken: 'Refresh token',
      credentialSource: 'Credential source',
      credentialSourceAuto: 'Detect automatically',
      credentialSourceKiro: 'Kiro refresh token',
      apiKey: 'Kiro API key',
      externalIdp: 'Microsoft external IdP JSON',
      startUrl: 'Identity Center start URL',
      region: 'AWS region (optional)',
      profileArn: 'Profile ARN (optional)',
      clientId: 'OIDC client ID (optional)',
      clientSecret: 'OIDC client secret (optional)',
      credentialJson: 'CLIProxyAPI-compatible credential JSON',
      login: 'Continue',
      import: 'Import credentials',
      signingIn: 'Working…',
      logout: 'Sign out',
      usage: 'Usage',
      refreshUsage: 'Refresh usage',
      refreshingUsage: 'Refreshing…',
      quotaUnlimited: 'no limit',
      quotaLeft: '{percent}% left',
      quotaTitle: 'Kiro usage',
      verified: 'Credential verified',
      verifiedModels: 'models available',
      savedCredential: 'Credentials saved',
      used: 'used',
      remaining: 'remaining',
      unlimited: 'unlimited',
      resets: 'Resets',
      updated: 'Updated',
      models: 'Model selector',
      refresh: 'Discover models',
      refreshing: 'Discovering…',
      selectAll: 'Select all',
      deselectAll: 'Deselect all',
      selected: 'selected',
      saving: 'Saving…',
      apply: 'Apply',
      maxContext: 'Max context',
      maxContextAuto: 'follow each model',
      maxContextHint: 'Tokens of context Kiro may fill before the Harness condenses the conversation. Empty follows each model (1,000,000); lower spends fewer tokens per turn.',
      maxContextInvalid: 'Enter a whole number of tokens, or leave it empty.',
      configured: 'Configured fallback catalog',
      live: 'Live account catalog',
      noModels: 'No models are available yet.',
      code: 'Device code',
      pending: 'Complete authorization in the browser. This page will update automatically.',
      authMethod: 'Method',
      profile: 'Profile',
      reasoning: 'Reasoning',
      default: 'default',
      context: 'Context',
      output: 'Max output',
    }
    const zh = {
      title: 'Kiro',
      description: '连接 Kiro 账号、自动刷新令牌，并发现此账号可用的模型。',
      account: '账号',
      accounts: '账号列表',
      addAccount: '添加账号',
      useAccount: '使用',
      reconnect: '重新登录',
      removeAccount: '移除',
      removeAccountConfirm: '确定要从 dsh-kiro 移除此账号吗？',
      activeAccount: '当前',
      accountReady: '可用',
      accountNeedsRefresh: '下次使用时刷新',
      accountNeedsLogin: '需要登录',
      accountsHint: '请求使用当前账号，该选择对所有会话生效。',
      signOutAll: '退出所有账号',
      signedOut: '未登录',
      managed: '由 dsh-kiro 管理',
      external: '正在使用 Kiro IDE / CLI 登录',
      connectKiro: '登录',
      connectManaged: '使用 dsh-kiro 登录',
      externalHint: '该凭据由 Kiro IDE / CLI 拥有，dsh-kiro 不会修改或删除它——这也是「退出」无法移除它的原因。可点击上方登录，改用由本插件管理并自动刷新的凭据，它的优先级高于 Kiro 的凭据。',
      connectTitle: '连接 Kiro',
      chooseMethod: '请选择连接 Kiro 账号的方式。',
      recommended: '推荐',
      builderDesc: '适合大多数用户，使用免费的 AWS Builder ID 登录。',
      idcDesc: '使用组织提供的 AWS IAM Identity Center。',
      googleDesc: '获取一次性验证码，然后在 app.kiro.dev 使用 Google 登录。',
      githubDesc: '获取一次性验证码，然后在 app.kiro.dev 使用 GitHub 登录。',
      refreshDesc: '粘贴 Kiro IDE 中已有的 refresh token。',
      apiDesc: '使用长期有效的 Kiro 或 CodeWhisperer API key。',
      externalDesc: '导入 CLIProxyAPI Microsoft external-IdP JSON。',
      back: '返回',
      close: '关闭',
      openBrowser: '打开浏览器',
      authorizationUrl: '授权 URL',
      copy: '复制',
      copied: '已复制',
      method: '登录方式',
      builderId: 'AWS Builder ID',
      idc: 'IAM Identity Center',
      google: 'Google',
      github: 'GitHub',
      refreshToken: '刷新令牌',
      credentialSource: '凭据来源',
      credentialSourceAuto: '自动判断',
      credentialSourceKiro: 'Kiro 刷新令牌',
      apiKey: 'Kiro API 密钥',
      externalIdp: 'Microsoft 外部 IdP JSON',
      startUrl: 'Identity Center 起始 URL',
      region: 'AWS 区域（可选）',
      profileArn: 'Profile ARN（可选）',
      clientId: 'OIDC 客户端 ID（可选）',
      clientSecret: 'OIDC 客户端密钥（可选）',
      credentialJson: '兼容 CLIProxyAPI 的凭据 JSON',
      login: '继续',
      import: '导入凭据',
      signingIn: '处理中…',
      logout: '退出',
      usage: '使用量',
      refreshUsage: '刷新使用量',
      refreshingUsage: '刷新中…',
      quotaUnlimited: '无限制',
      quotaLeft: '剩余 {percent}%',
      quotaTitle: 'Kiro 用量',
      verified: '凭据已验证',
      verifiedModels: '个模型可用',
      savedCredential: '凭据已保存',
      used: '已使用',
      remaining: '剩余',
      unlimited: '无上限',
      resets: '重置时间',
      updated: '更新时间',
      models: '模型选择器',
      refresh: '发现模型',
      refreshing: '发现中…',
      selectAll: '全选',
      deselectAll: '取消全选',
      selected: '已选择',
      saving: '保存中…',
      apply: '应用',
      maxContext: '最大上下文',
      maxContextAuto: '跟随各模型',
      maxContextHint: 'Kiro 在 Harness 压缩对话前可填充的上下文 token 数。留空则跟随各模型（1,000,000）；数值越低，每轮消耗的 token 越少。',
      maxContextInvalid: '请输入整数 token 数，或留空。',
      configured: '配置的后备模型目录',
      live: '账号实时模型目录',
      noModels: '尚无可用模型。',
      code: '设备验证码',
      pending: '请在浏览器中完成授权，本页面会自动更新。',
      authMethod: '方式',
      profile: 'Profile',
      reasoning: '推理',
      default: '默认',
      context: '上下文',
      output: '最大输出',
    }

    function translator(ctx) {
      const bound = ctx.locale && typeof ctx.locale.bind === 'function' ? ctx.locale.bind(NS) : undefined
      return (key) => {
        if (bound) {
          const value = bound(key)
          if (value && value !== key && value !== `${NS}.${key}`) return value
        }
        const active = ctx.locale && typeof ctx.locale.getLocale === 'function'
          ? ctx.locale.getLocale()?.active
          : navigator.language
        const dictionary = active && active.startsWith('zh') ? zh : en
        return dictionary[key] || en[key] || key
      }
    }

    /**
     * Replace the settings-nav glyph for this plugin's section with the official
     * Kiro mark.
     *
     * The settings shell picks nav icons from a fixed table keyed by section id
     * and exposes no icon seat to registrants, so the glyph can only be adjusted
     * in the DOM. Returns whether the icon is now in place, which is what lets
     * the observer below stop working instead of scanning forever.
     */
    function patchNavIcon() {
      let installed = false
      for (const span of document.querySelectorAll('span')) {
        if (!span.textContent || span.textContent.trim() !== 'Kiro') continue
        const button = span.closest('button')
        const svg = button && button.querySelector('svg')
        if (!svg) continue
        const body = svg.querySelector('path')
        if (svg.getAttribute('viewBox') === '0 0 1200 1200'
          && body && body.getAttribute('d') === KIRO_BODY_PATH) {
          installed = true
          continue
        }
        svg.setAttribute('viewBox', '0 0 1200 1200')
        svg.setAttribute('width', '16')
        svg.setAttribute('height', '16')
        svg.setAttribute('fill', 'none')
        svg.innerHTML = `<rect width="1200" height="1200" rx="260" fill="#9046FF"/><path d="${KIRO_BODY_PATH}" fill="white"/><path d="${KIRO_LEFT_EYE_PATH}" fill="black"/><path d="${KIRO_RIGHT_EYE_PATH}" fill="black"/>`
        installed = true
      }
      return installed
    }

    /** The nav element holding this plugin's settings row, when it is mounted. */
    function navContainer() {
      for (const span of document.querySelectorAll('span')) {
        if (!span.textContent || span.textContent.trim() !== 'Kiro') continue
        const button = span.closest('button')
        const nav = button && button.closest('nav')
        if (nav) return nav
      }
      return undefined
    }

    /**
     * Keep the nav icon patched for as long as this plugin is loaded, without
     * polling and without watching the whole document forever.
     *
     * Two observation scopes: the app root while the settings panel is closed
     * (the panel mounts and unmounts, so its arrival has to be noticed
     * somewhere), then the panel's own `nav` once the row exists. Re-arming the
     * wide scope happens only when that nav leaves the document.
     * @returns a disposer that stops all observation.
     */
    function installNavIcon() {
      const root = document.getElementById('root') || document.body || document.documentElement
      let observer
      let scope
      let scheduled = false
      let disposed = false

      const observe = (target) => {
        if (disposed || !target || target === scope) return
        if (observer) observer.disconnect()
        scope = target
        observer = new MutationObserver(schedule)
        observer.observe(target, { childList: true, subtree: true })
      }

      const apply = () => {
        scheduled = false
        if (disposed) return
        const installed = patchNavIcon()
        const nav = navContainer()
        // Narrow to the nav once it exists; widen again if it goes away, so a
        // reopened panel is still picked up.
        observe(installed && nav ? nav : root)
      }

      function schedule() {
        if (disposed || scheduled) return
        scheduled = true
        const defer = typeof window.requestAnimationFrame === 'function'
          ? window.requestAnimationFrame
          : (callback) => window.setTimeout(callback, 0)
        defer(apply)
      }

      apply()
      return () => {
        disposed = true
        if (observer) observer.disconnect()
        observer = undefined
        scope = undefined
      }
    }

    async function api(path, options) {
      const response = await fetch(`${API}${path}`, {
        headers: { 'content-type': 'application/json' },
        ...options,
      })
      const body = await response.json()
      if (!response.ok || !body.ok) throw new Error(body.error || `HTTP ${response.status}`)
      return body.value
    }

    function installStyle() {
      if (document.getElementById(STYLE_ID)) return
      const style = document.createElement('style')
      style.id = STYLE_ID
      style.textContent = `
.dshk-wrap{box-sizing:border-box;width:100%;max-width:820px;padding:0 0 28px;color:#111827}
.dshk-title{display:flex;align-items:center;gap:10px;margin:0;font-size:21px;font-weight:750}
.dshk-logo{display:block;width:28px;height:28px;flex:none}
.dshk-desc{margin:8px 0 18px;color:#6b7280;font-size:13px;line-height:20px}
.dshk-card{margin:0 0 14px;padding:16px;border:1px solid #e5e7eb;border-radius:13px;background:#fff}
.dshk-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px}
.dshk-heading{font-size:15px;font-weight:700}
.dshk-actions{display:flex;gap:8px;flex-wrap:wrap}
.dshk-btn{padding:7px 12px;border:1px solid #d1d5db;border-radius:9px;background:white;color:#111827;font-size:13px;text-decoration:none;cursor:pointer}
.dshk-btn:hover{background:#f9fafb}.dshk-btn:disabled{cursor:not-allowed;opacity:.55}
.dshk-primary{border-color:#4f46e5;background:#4f46e5;color:white}.dshk-primary:hover{background:#4338ca}
.dshk-status{display:flex;align-items:center;gap:9px;padding:11px 12px;border-radius:10px;background:#f9fafb;color:#4b5563;font-size:13px}
.dshk-dot{width:9px;height:9px;border-radius:50%;background:#9ca3af}.dshk-dot-on{background:#10b981}
.dshk-code{margin-top:10px;padding:11px 12px;border:1px solid #c7d2fe;border-radius:10px;background:#eef2ff;color:#3730a3;font-size:13px}
.dshk-code strong{display:inline-block;margin-left:8px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:15px;letter-spacing:.08em}
.dshk-meta{margin-top:8px;color:#6b7280;font-size:12px}
.dshk-form{display:grid;gap:10px;margin-top:12px;padding-top:12px;border-top:1px solid #eef0f3}.dshk-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
.dshk-field{display:grid;gap:5px;color:#4b5563;font-size:12px}.dshk-field-wide{grid-column:1/-1}
.dshk-input{box-sizing:border-box;width:100%;min-width:0;padding:8px 10px;border:1px solid #d1d5db;border-radius:8px;background:#fff;color:#111827;font:inherit;font-size:13px}
textarea.dshk-input{min-height:78px;resize:vertical;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px}
.dshk-details{overflow-wrap:anywhere}
.dshk-overlay{position:fixed;inset:0;z-index:10000;display:flex;align-items:center;justify-content:center;box-sizing:border-box;padding:20px;background:rgba(15,23,42,.58);backdrop-filter:blur(3px)}
.dshk-modal{box-sizing:border-box;width:min(640px,100%);max-height:min(760px,calc(100vh - 40px));overflow:auto;border:1px solid #e5e7eb;border-radius:16px;background:#fff;box-shadow:0 24px 70px rgba(15,23,42,.3)}
.dshk-modal-head{position:sticky;top:0;z-index:1;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:16px 18px;border-bottom:1px solid #eef0f3;background:inherit}
.dshk-modal-title{display:flex;align-items:center;gap:9px;font-size:17px;font-weight:750}.dshk-modal-title .dshk-logo{width:25px;height:25px}
.dshk-close{display:grid;place-items:center;width:30px;height:30px;padding:0;border:0;border-radius:8px;background:transparent;color:#64748b;font-size:22px;line-height:1;cursor:pointer}.dshk-close:hover{background:#f1f5f9}
.dshk-modal-body{padding:18px}.dshk-chooser-copy{margin:0 0 14px;color:#6b7280;font-size:13px}
.dshk-methods{display:grid;gap:9px}.dshk-method{display:flex;align-items:flex-start;gap:12px;width:100%;padding:13px;border:1px solid #e2e8f0;border-radius:11px;background:#fff;color:inherit;text-align:left;cursor:pointer;transition:border-color .15s,background .15s,transform .15s}
.dshk-method:hover{transform:translateY(-1px);border-color:#a78bfa;background:#faf8ff}.dshk-method:disabled{cursor:not-allowed;opacity:.55;transform:none}
.dshk-method-icon{display:grid;place-items:center;flex:none;width:38px;height:38px;border-radius:10px;background:#f3e8ff;color:#6d28d9;font-size:11px;font-weight:800;letter-spacing:.02em}
.dshk-method-main{min-width:0;flex:1}.dshk-method-title{display:flex;align-items:center;gap:7px;font-size:14px;font-weight:700}.dshk-method-desc{margin-top:3px;color:#6b7280;font-size:12px;line-height:17px}.dshk-chevron{align-self:center;color:#94a3b8;font-size:20px}
.dshk-badge{padding:2px 6px;border-radius:999px;background:#ede9fe;color:#6d28d9;font-size:9px;font-weight:750;text-transform:uppercase;letter-spacing:.04em}
.dshk-step-head{display:flex;align-items:center;gap:9px;margin-bottom:14px}.dshk-back{padding:5px 8px}.dshk-step-title{font-size:15px;font-weight:700}.dshk-working{padding:38px 12px;text-align:center;color:#6b7280;font-size:13px}
.dshk-auth-url{display:grid;gap:6px;margin-top:12px}.dshk-auth-url-label{color:#6b7280;font-size:11px;font-weight:650}.dshk-auth-url-row{display:flex;align-items:stretch;gap:7px}.dshk-auth-url-row .dshk-input{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11px}.dshk-auth-url-row .dshk-btn{flex:none}
.dshk-plan{display:inline-flex;margin-left:auto;padding:3px 8px;border-radius:999px;background:#ede9fe;color:#6d28d9;font-size:10px;font-weight:750}
.dshk-quota{display:inline-flex;align-items:center;gap:5px;padding:3px 8px;border:1px solid #e5e7eb;border-radius:999px;background:#f9fafb;color:#4b5563;font-size:11px;font-weight:600;line-height:1.5;cursor:pointer;white-space:nowrap}
.dshk-quota:hover{background:#f3f4f6}.dshk-quota:disabled{cursor:progress;opacity:.6}
.dshk-quota-dot{width:6px;height:6px;flex:none;border-radius:50%;background:#10b981}
.dshk-quota-low .dshk-quota-dot{background:#f59e0b}.dshk-quota-critical .dshk-quota-dot{background:#ef4444}
.dshk-usage{display:grid;gap:11px;margin-top:13px;padding-top:13px;border-top:1px solid #eef0f3}.dshk-usage-row{display:grid;gap:6px}.dshk-usage-top{display:flex;align-items:baseline;justify-content:space-between;gap:12px;font-size:12px}.dshk-usage-name{font-weight:650}.dshk-usage-metric{color:#64748b;text-align:right}.dshk-bar{height:6px;overflow:hidden;border-radius:999px;background:#eef0f3}.dshk-fill{height:100%;border-radius:inherit;background:linear-gradient(90deg,#8b5cf6,#6366f1)}.dshk-usage-foot{display:flex;justify-content:space-between;gap:12px;color:#94a3b8;font-size:10px}
.dshk-context{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:10px;padding-top:10px;border-top:1px solid #eef0f3}
.dshk-context-label{font-size:12px;font-weight:650;color:#4b5563}
.dshk-context-input{width:112px}
.dshk-context-hint{flex:1;min-width:190px;color:#94a3b8;font-size:11px;line-height:1.5}
.dshk-model-tools{display:flex;align-items:center;gap:9px;flex-wrap:wrap}.dshk-link-btn{padding:0;border:0;background:transparent;color:#6d28d9;font:inherit;font-size:11px;cursor:pointer}.dshk-link-btn:hover{text-decoration:underline}.dshk-link-btn:disabled{cursor:not-allowed;opacity:.5}.dshk-selected-count{color:#94a3b8;font-size:11px}
.dshk-list{display:grid;gap:5px}.dshk-model{display:flex;align-items:flex-start;gap:10px;padding:8px 10px;border:1px solid #eef0f3;border-radius:9px;background:#fcfcfd;cursor:pointer}.dshk-model:hover{border-color:#c4b5fd;background:#faf8ff}.dshk-model-off{opacity:.68}.dshk-check{width:15px;height:15px;margin:2px 0 0;accent-color:#7c3aed;flex:none}.dshk-model-text{display:grid;min-width:0;gap:2px}.dshk-model-name{font-size:13px;font-weight:650}.dshk-model-sub{overflow:hidden;color:#6b7280;font-size:10.5px;line-height:15px;text-overflow:ellipsis;white-space:nowrap}
.dshk-error{margin-top:10px;padding:9px 11px;border-radius:9px;background:#fef2f2;color:#b91c1c;font-size:12px;white-space:pre-wrap}
.dshk-notice{margin-top:10px;padding:9px 11px;border-radius:9px;background:#f0fdf4;color:#15803d;font-size:12px}
.dshk-empty{padding:18px;text-align:center;color:#9ca3af;font-size:13px}
.dshk-accounts{display:grid;gap:7px;margin-top:11px}
.dshk-account{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 11px;border:1px solid #eef0f3;border-radius:10px;background:#fcfcfd}
.dshk-account-active{border-color:#c4b5fd;background:#faf8ff}
.dshk-account-text{display:grid;gap:2px;min-width:0}
.dshk-account-name{display:flex;align-items:center;gap:6px;font-size:13px;font-weight:650}
.dshk-account-sub{overflow:hidden;color:#6b7280;font-size:10.5px;text-overflow:ellipsis;white-space:nowrap}
.dshk-account-actions{display:flex;flex:none;gap:6px}
.dshk-danger{color:#b91c1c}
@media(max-width:620px){.dshk-grid{grid-template-columns:1fr}.dshk-field-wide{grid-column:auto}.dshk-auth-url-row{align-items:stretch;flex-direction:column}.dshk-head{align-items:flex-start;flex-direction:column}.dshk-usage-top{align-items:flex-start;flex-direction:column;gap:2px}.dshk-usage-metric{text-align:left}.dshk-model-sub{white-space:normal}.dshk-account{align-items:flex-start;flex-direction:column}.dshk-account-actions{flex-wrap:wrap}}
@media(prefers-color-scheme:dark){.dshk-notice{background:#0f2a1a;color:#86efac}.dshk-wrap{color:#f3f4f6}.dshk-card,.dshk-modal{border-color:#303642;background:#171a21}.dshk-modal-head{border-color:#303642}.dshk-status,.dshk-model{background:#1d2129;border-color:#303642;color:#d1d5db}.dshk-model:hover{border-color:#8b5cf6;background:#282333}.dshk-btn,.dshk-input,.dshk-method{border-color:#434b59;background:#20242d;color:#f3f4f6}.dshk-method:hover{border-color:#8b5cf6;background:#282333}.dshk-method-icon{background:#332a52;color:#c4b5fd}.dshk-close:hover{background:#272c35}.dshk-form,.dshk-usage{border-color:#303642}.dshk-context{border-color:#303642}.dshk-context-label{color:#d1d5db}.dshk-field{color:#d1d5db}.dshk-code{border-color:#4338ca;background:#272447;color:#c7d2fe}.dshk-bar{background:#303642}.dshk-plan{background:#332a52;color:#c4b5fd}.dshk-link-btn{color:#c4b5fd}.dshk-quota{border-color:#434b59;background:#20242d;color:#d1d5db}.dshk-quota:hover{background:#282333}.dshk-account{background:#1d2129;border-color:#303642}.dshk-account-active{border-color:#8b5cf6;background:#282333}.dshk-account-sub{color:#9ca3af}.dshk-danger{color:#fca5a5}}
`
      document.head.appendChild(style)
    }

    function formatTokens(value) {
      if (!Number.isFinite(value)) return undefined
      if (value >= 1000000) return `${(value / 1000000).toFixed(value % 1000000 === 0 ? 0 : 1)}M`
      if (value >= 1000) return `${Math.round(value / 1000)}K`
      return String(value)
    }

    function formatAmount(value) {
      if (!Number.isFinite(value)) return '0'
      return new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(value)
    }

    function formatDate(value) {
      const date = new Date(value)
      if (!Number.isFinite(date.getTime())) return ''
      return date.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })
    }

    function KiroLogo() {
      return React.createElement('svg', {
        className: 'dshk-logo',
        viewBox: '0 0 1200 1200',
        fill: 'none',
        focusable: 'false',
        'aria-hidden': 'true',
      },
      React.createElement('rect', { width: 1200, height: 1200, rx: 260, fill: '#9046FF' }),
      React.createElement('path', {
        d: 'M398.554 818.914C316.315 1001.03 491.477 1046.74 620.672 940.156C658.687 1059.66 801.052 970.473 852.234 877.795C964.787 673.567 919.318 465.357 907.64 422.374C827.637 129.443 427.623 128.946 358.8 423.865C342.651 475.544 342.402 534.18 333.458 595.051C328.986 625.86 325.507 645.488 313.83 677.785C306.873 696.424 297.68 712.819 282.773 740.645C259.915 783.881 269.604 867.113 387.87 823.883L399.051 818.914H398.554Z',
        fill: 'white',
      }),
      React.createElement('path', {
        d: 'M636.123 549.353C603.328 549.353 598.359 510.097 598.359 486.742C598.359 465.623 602.086 448.977 609.293 438.293C615.504 428.852 624.697 424.131 636.123 424.131C647.555 424.131 657.492 428.852 664.447 438.541C672.398 449.474 676.623 466.12 676.623 486.742C676.623 525.998 661.471 549.353 636.375 549.353H636.123Z',
        fill: 'black',
      }),
      React.createElement('path', {
        d: 'M771.24 549.353C738.445 549.353 733.477 510.097 733.477 486.742C733.477 465.623 737.203 448.977 744.41 438.293C750.621 428.852 759.814 424.131 771.24 424.131C782.672 424.131 792.609 428.852 799.564 438.541C807.516 449.474 811.74 466.12 811.74 486.742C811.74 525.998 796.588 549.353 771.492 549.353H771.24Z',
        fill: 'black',
      }))
    }

    /** Percentage at the precision a quota figure is worth. */
    function formatPercent(value) {
      if (!Number.isFinite(value)) return '0'
      return new Intl.NumberFormat(undefined, { maximumFractionDigits: 1 }).format(value)
    }

    /** The row with the least room left, which is the one that decides the next turn. */
    function tightestRow(usage) {
      const rows = Array.isArray(usage.rows) ? usage.rows : []
      const bounded = rows.filter(row => row.unlimited !== true && Number.isFinite(row.remainingPercent))
      if (bounded.length === 0) return rows[0]
      return bounded.reduce((worst, row) => row.remainingPercent < worst.remainingPercent ? row : worst)
    }

    /**
     * The plan quota beside the composer.
     *
     * The settings card is where usage is studied; this is where it is noticed,
     * because the number that decides whether the next turn is refused should
     * not require opening a panel. Clicking forces a refresh.
     */
    /** Whether this session's next request is routed to Kiro. */
    function isKiroModel(state) {
      const current = state?.current
      return Boolean(current && current.provider === 'kiro' && typeof current.model === 'string')
    }

    function KiroQuota({ ctx, directory }) {
      const t = useMemo(() => translator(ctx), [ctx])
      const [usage, setUsage] = useState(undefined)
      const [busy, setBusy] = useState(false)
      const [failed, setFailed] = useState(false)

      // The session's own selection decides eligibility. Its transient `status`
      // does not: reading usage re-reads usage, and a catalog reload must not
      // blink the chip away — the same reason the Antigravity chip ignores it.
      const subscribe = useCallback((onChange) => (
        typeof directory?.subscribe === 'function' ? directory.subscribe(onChange) : () => {}
      ), [directory])
      const getSnapshot = useCallback(() => (
        typeof directory?.getSnapshot === 'function' ? directory.getSnapshot() : undefined
      ), [directory])
      const selected = useStoreSnapshot(subscribe, getSnapshot, getSnapshot)
      const eligible = isKiroModel(selected)

      const load = useCallback(async (force) => {
        try {
          setUsage(await api('/usage', force ? { method: 'POST' } : undefined))
          setFailed(false)
        } catch {
          // A figure that only decorates the composer must not grow an error box.
          setFailed(true)
        }
      }, [])

      useEffect(() => {
        // A session routed elsewhere has nothing to spend here, and polling for
        // it would read a quota the user is not using.
        if (!eligible) return undefined
        let active = true
        void load(false)
        // The Host caches usage for five minutes, so this reads the cache and
        // reaches the provider only when that entry has expired.
        const timer = window.setInterval(() => { if (active) void load(false) }, 300000)
        return () => { active = false; window.clearInterval(timer) }
      }, [eligible, load])

      if (!eligible || failed || usage === undefined) return null
      const row = tightestRow(usage)
      if (row === undefined) return null

      const unlimited = row.unlimited === true || !Number.isFinite(row.remainingPercent)
      const percent = unlimited ? undefined : row.remainingPercent
      const label = unlimited ? t('quotaUnlimited') : t('quotaLeft').replace('{percent}', formatPercent(percent))
      const tone = percent === undefined ? '' : percent < 5 ? ' dshk-quota-critical' : percent < 20 ? ' dshk-quota-low' : ''
      const detail = [
        usage.plan,
        ...(Array.isArray(usage.rows) ? usage.rows : []).map((entry) => {
          const amount = entry.unlimited === true
            ? t('quotaUnlimited')
            : `${formatAmount(entry.used)} / ${formatAmount(entry.limit)}`
          const left = entry.unlimited === true || !Number.isFinite(entry.remainingPercent)
            ? ''
            : ` · ${formatPercent(entry.remainingPercent)}% ${t('remaining')}`
          const reset = entry.resetAt ? ` · ${t('resets')} ${formatDate(entry.resetAt)}` : ''
          return `${entry.label}: ${amount}${left}${reset}`
        }),
        usage.fetchedAt ? `${t('updated')} ${formatDate(usage.fetchedAt)}` : '',
      ].filter(Boolean).join('\n')

      return React.createElement('button', {
        className: `dshk-quota${tone}`,
        type: 'button',
        title: detail,
        'aria-label': `${t('quotaTitle')}: ${label}`,
        disabled: busy,
        onClick: () => {
          setBusy(true)
          void load(true).finally(() => setBusy(false))
        },
      },
      React.createElement('span', { className: 'dshk-quota-dot' }),
      label)
    }

    function KiroSettings({ ctx }) {
      const t = useMemo(() => translator(ctx), [ctx])
      const [status, setStatus] = useState(undefined)
      const [busy, setBusy] = useState('')
      const [error, setError] = useState('')
      const [method, setMethod] = useState('builder-id')
      const [fields, setFields] = useState({})
      const [authOpen, setAuthOpen] = useState(false)
      const [selectedMethod, setSelectedMethod] = useState(null)
      const [copiedAuthUrl, setCopiedAuthUrl] = useState(false)
      const [usage, setUsage] = useState(undefined)
      const [usageError, setUsageError] = useState('')
      const [notice, setNotice] = useState('')
      // Set while the dialog is re-authenticating an existing account rather
      // than adding one; empty means the next login lands on a new account.
      const [targetAccountId, setTargetAccountId] = useState('')

      const updateField = useCallback((name, value) => {
        setFields((current) => ({ ...current, [name]: value }))
      }, [])

      const load = useCallback(async () => {
        const next = await api('/status')
        setStatus(next)
        return next
      }, [])

      useEffect(() => {
        let active = true
        void load().catch((cause) => active && setError(cause.message))
        const timer = window.setInterval(() => {
          if (active && status?.login?.status === 'pending') {
            void load().catch((cause) => setError(cause.message))
          }
        }, 2000)
        return () => { active = false; window.clearInterval(timer) }
      }, [load, status?.login?.status])

      // Which credential is in force, not merely whether one is. Signing in from
      // a signed-out page changes `authenticated`, but importing a key while a
      // Kiro IDE credential is already present does not — and that is exactly
      // when the dialog must close and the usage card must be re-read.
      const credentialKey = status?.authenticated
        ? [status.credentialSource, status.authMethod, status.expiresAt].join('|')
        : ''

      useEffect(() => {
        if (credentialKey === '') return
        setAuthOpen(false)
        setSelectedMethod(null)
      }, [credentialKey])

      useEffect(() => {
        if (credentialKey === '') {
          setUsage(undefined)
          setUsageError('')
          return undefined
        }
        let active = true
        if (status?.usage) setUsage(status.usage)
        void api('/usage').then((value) => {
          if (active) { setUsage(value); setUsageError('') }
        }).catch((cause) => { if (active) setUsageError(cause.message) })
        return () => { active = false }
      }, [credentialKey])

      useEffect(() => {
        if (notice === '') return undefined
        // A confirmation is news, not state: it clears itself rather than
        // lingering over a page the user has moved on from.
        const timer = window.setTimeout(() => setNotice(''), 8000)
        return () => window.clearTimeout(timer)
      }, [notice])

      const noticeFor = useCallback((next) => {
        const models = next?.verified?.models
        if (typeof models === 'number') return `${t('verified')} · ${models} ${t('verifiedModels')}`
        if (next?.verified?.refreshed) return t('verified')
        // Nothing was checked on the wire for this method, so the message says
        // only what happened: it was saved.
        return t('savedCredential')
      }, [t])

      const refreshUsage = useCallback(async () => {
        setBusy('usage'); setUsageError('')
        try { setUsage(await api('/usage', { method: 'POST' })) }
        catch (cause) { setUsageError(cause.message) } finally { setBusy('') }
      }, [])

      const accountList = Array.isArray(status?.accounts?.accounts) ? status.accounts.accounts : []

      const login = useCallback(async (requestedMethod) => {
        const activeMethod = typeof requestedMethod === 'string' ? requestedMethod : method
        setBusy('login'); setError('')
        const imported = activeMethod === 'refresh-token' || activeMethod === 'api-key' || activeMethod === 'external-idp'
        try {
          if (imported) {
            const payload = activeMethod === 'refresh-token'
              ? {
                  method: activeMethod,
                  refreshToken: fields.refreshToken,
                  region: fields.region,
                  profileArn: fields.profileArn,
                  clientId: fields.clientId,
                  clientSecret: fields.clientSecret,
                  startUrl: fields.startUrl,
                  // Empty means "derive": Builder ID and Identity Center
                  // credentials look alike, so the origin is stated, not guessed.
                  credentialSource: fields.credentialSource,
                  accountId: targetAccountId,
                }
              : activeMethod === 'api-key'
                ? { method: activeMethod, apiKey: fields.apiKey, region: fields.region, accountId: targetAccountId }
                : { method: activeMethod, credentials: fields.credentials, accountId: targetAccountId }
            const next = await api('/credentials/import', { method: 'POST', body: JSON.stringify(payload) })
            setStatus(next)
            // Close and confirm here rather than waiting on a derived state
            // change: re-importing the same kind of credential can leave every
            // observed field identical, and the dialog must still close.
            setAuthOpen(false)
            setSelectedMethod(null)
            // The secret has been stored server-side; keeping a copy in the page
            // only widens where it can leak.
            setFields((current) => ({
              ...current,
              apiKey: '',
              refreshToken: '',
              clientSecret: '',
              credentials: '',
            }))
            setNotice(noticeFor(next))
            await refreshUsage()
            return
          }
          const flow = await api('/login', {
            method: 'POST',
            body: JSON.stringify({
              method: activeMethod,
              region: fields.region,
              startUrl: fields.startUrl,
              // Empty means "add an account"; a value re-authenticates that one.
              accountId: targetAccountId,
            }),
          })
          setStatus((current) => ({ ...current, login: flow }))
          await load()
        } catch (cause) { setError(cause.message) } finally { setBusy('') }
      }, [fields, load, method, noticeFor, refreshUsage, targetAccountId])

      const chooseMethod = useCallback((nextMethod) => {
        setMethod(nextMethod)
        setSelectedMethod(nextMethod)
        setError('')
        if (nextMethod === 'builder-id' || nextMethod === 'google' || nextMethod === 'github') {
          void login(nextMethod)
        }
      }, [login])

      // An account id means "sign this account in again"; no id adds one.
      const openAuth = useCallback((accountId) => {
        setTargetAccountId(typeof accountId === 'string' ? accountId : '')
        setError('')
        const pendingMethod = status?.login?.status === 'pending' ? status.login.method : null
        setSelectedMethod(pendingMethod)
        if (pendingMethod) setMethod(pendingMethod)
        setAuthOpen(true)
      }, [status?.login])

      const closeAuth = useCallback(() => {
        setTargetAccountId('')
        setAuthOpen(false)
      }, [])

      const activateAccount = useCallback(async (accountId) => {
        setBusy('accounts'); setError('')
        try {
          const next = await api('/accounts/activate', { method: 'POST', body: JSON.stringify({ accountId }) })
          setStatus(next)
          if (next?.authenticated) await refreshUsage()
          else setUsage(undefined)
        } catch (cause) { setError(cause.message) } finally { setBusy('') }
      }, [refreshUsage])

      const removeAccount = useCallback(async (account) => {
        // The service requires a replacement when the active account goes while
        // others remain, so the first remaining account takes over.
        const remaining = accountList.filter((candidate) => candidate.id !== account.id)
        if (typeof window.confirm === 'function' && !window.confirm(t('removeAccountConfirm'))) return
        setBusy('accounts'); setError('')
        try {
          const next = await api('/accounts/remove', {
            method: 'POST',
            body: JSON.stringify({
              accountId: account.id,
              ...account.active && remaining.length > 0 ? { replacementId: remaining[0].id } : {},
            }),
          })
          setStatus(next)
          if (next?.authenticated) await refreshUsage()
          else { setUsage(undefined); setUsageError('') }
        } catch (cause) { setError(cause.message) } finally { setBusy('') }
      }, [accountList, refreshUsage, t])

      useEffect(() => {
        if (!authOpen) return undefined
        const closeOnEscape = (event) => { if (event.key === 'Escape') closeAuth() }
        window.addEventListener('keydown', closeOnEscape)
        return () => window.removeEventListener('keydown', closeOnEscape)
      }, [authOpen, closeAuth])

      const backToMethods = useCallback(() => {
        setSelectedMethod(null)
        setError('')
      }, [])

      const cancelLogin = useCallback(async () => {
        setBusy('cancel'); setError('')
        try {
          setStatus(await api('/login/cancel', { method: 'POST' }))
          setSelectedMethod(null)
        } catch (cause) { setError(cause.message) } finally { setBusy('') }
      }, [])

      const copyAuthorizationUrl = useCallback(async () => {
        const url = status?.login?.authUrl
        if (typeof url !== 'string') return
        try {
          await navigator.clipboard.writeText(url)
        } catch {
          const input = document.createElement('textarea')
          input.value = url
          input.style.position = 'fixed'
          input.style.opacity = '0'
          document.body.appendChild(input)
          input.select()
          document.execCommand('copy')
          input.remove()
        }
        setCopiedAuthUrl(true)
      }, [status?.login?.authUrl])

      useEffect(() => {
        setCopiedAuthUrl(false)
      }, [status?.login?.authUrl])

      const logout = useCallback(async () => {
        setBusy('logout'); setError('')
        try { setStatus(await api('/logout', { method: 'POST' })) }
        catch (cause) { setError(cause.message) } finally { setBusy('') }
      }, [])

      // The context ceiling is a profile row, so it round-trips through the Host
      // rather than a settings page of its own.
      const [cap, setCap] = useState('')
      const [capBusy, setCapBusy] = useState(false)
      const capValue = status?.contextWindowCap
      useEffect(() => {
        setCap(capValue === undefined || capValue === null ? '' : String(capValue))
      }, [capValue])

      const applyCap = useCallback(async () => {
        setCapBusy(true); setError('')
        try {
          const trimmed = cap.trim()
          const value = trimmed.length === 0 ? null : Number(trimmed)
          if (value !== null && (!Number.isInteger(value) || value <= 0)) throw new Error(t('maxContextInvalid'))
          setStatus(await api('/context', { method: 'POST', body: JSON.stringify({ maxContextWindow: value }) }))
        } catch (cause) { setError(cause.message) } finally { setCapBusy(false) }
      }, [cap, t])

      const refresh = useCallback(async () => {
        setBusy('models'); setError('')
        try {
          const models = await api('/models/refresh', { method: 'POST' })
          setStatus((current) => ({ ...current, models }))
        } catch (cause) { setError(cause.message) } finally { setBusy('') }
      }, [])

      const saveModels = useCallback(async (enabledModelIds) => {
        setBusy('models-save'); setError('')
        try {
          const models = await api('/models', {
            method: 'POST', body: JSON.stringify({ enabledModelIds }),
          })
          setStatus((current) => ({ ...current, models }))
        } catch (cause) { setError(cause.message) } finally { setBusy('') }
      }, [])

      const flow = status?.login
      const catalog = status?.models
      const models = Array.isArray(catalog?.models) ? catalog.models : []
      const enabledModelIds = models.filter((model) => model.enabled).map((model) => model.id)
      const toggleModel = (id, enabled) => saveModels(enabled
        ? [...new Set([...enabledModelIds, id])]
        : enabledModelIds.filter((modelId) => modelId !== id))
      const accountLabel = status?.credentialSource === 'dsh'
        ? t('managed')
        : status?.credentialSource === 'kiro' ? t('external') : t('signedOut')
      const importMethod = method === 'refresh-token' || method === 'api-key' || method === 'external-idp'
      const loginLabel = importMethod ? t('import') : t('login')
      const field = (name, label, options = {}) => React.createElement('label', {
        className: `dshk-field${options.wide ? ' dshk-field-wide' : ''}`,
      },
      React.createElement('span', null, label),
      options.choices
        ? React.createElement('select', {
            className: 'dshk-input',
            value: fields[name] || options.choices[0].value,
            onChange: (event) => updateField(name, event.target.value),
          }, options.choices.map((choice) => React.createElement('option', {
            key: choice.value, value: choice.value,
          }, choice.label)))
        : options.textarea
        ? React.createElement('textarea', {
            className: 'dshk-input',
            value: fields[name] || '',
            placeholder: options.placeholder,
            onChange: (event) => updateField(name, event.target.value),
          })
        : React.createElement('input', {
            className: 'dshk-input',
            type: options.secret ? 'password' : 'text',
            value: fields[name] || '',
            placeholder: options.placeholder,
            autoComplete: options.secret ? 'off' : undefined,
            onChange: (event) => updateField(name, event.target.value),
          }))

      const loginFields = method === 'idc'
        ? [
            field('startUrl', t('startUrl'), { wide: true, placeholder: 'https://example.awsapps.com/start' }),
            field('region', t('region'), { placeholder: 'us-east-1' }),
          ]
        : method === 'builder-id'
          ? [field('region', t('region'), { placeholder: 'us-east-1' })]
          : method === 'refresh-token'
            ? [
                field('refreshToken', t('refreshToken'), { wide: true, textarea: true, secret: true }),
                field('credentialSource', t('credentialSource'), {
                  wide: true,
                  choices: [
                    { value: '', label: t('credentialSourceAuto') },
                    { value: 'imported', label: t('credentialSourceKiro') },
                    { value: 'builder-id', label: t('builderId') },
                    { value: 'idc', label: t('idc') },
                  ],
                }),
                field('profileArn', t('profileArn'), { wide: true, placeholder: 'arn:aws:codewhisperer:…:profile/…' }),
                field('region', t('region'), { placeholder: 'us-east-1' }),
                field('startUrl', t('startUrl'), { placeholder: 'https://example.awsapps.com/start' }),
                field('clientId', t('clientId'), { secret: true }),
                field('clientSecret', t('clientSecret'), { secret: true }),
              ]
            : method === 'api-key'
              ? [
                  field('apiKey', t('apiKey'), { wide: true, secret: true }),
                  field('region', t('region'), { placeholder: 'us-east-1' }),
                ]
              : method === 'external-idp'
                ? [field('credentials', t('credentialJson'), { wide: true, textarea: true, secret: true })]
                : []

      const methodChoices = [
        { id: 'builder-id', icon: 'AWS', title: t('builderId'), description: t('builderDesc'), recommended: true },
        { id: 'idc', icon: 'SSO', title: t('idc'), description: t('idcDesc') },
        { id: 'google', icon: 'G', title: t('google'), description: t('googleDesc') },
        { id: 'github', icon: 'GH', title: t('github'), description: t('githubDesc') },
        { id: 'refresh-token', icon: '↻', title: t('refreshToken'), description: t('refreshDesc') },
        { id: 'api-key', icon: 'KEY', title: t('apiKey'), description: t('apiDesc') },
        { id: 'external-idp', icon: '{}', title: t('externalIdp'), description: t('externalDesc') },
      ]
      const selectedChoice = methodChoices.find((choice) => choice.id === method)
      const chooser = React.createElement(React.Fragment, null,
        React.createElement('p', { className: 'dshk-chooser-copy' }, t('chooseMethod')),
        React.createElement('div', { className: 'dshk-methods' }, methodChoices.map((choice) =>
          React.createElement('button', {
            className: 'dshk-method',
            type: 'button',
            key: choice.id,
            disabled: !!busy,
            onClick: () => chooseMethod(choice.id),
          },
          React.createElement('span', { className: 'dshk-method-icon', 'aria-hidden': 'true' }, choice.icon),
          React.createElement('span', { className: 'dshk-method-main' },
            React.createElement('span', { className: 'dshk-method-title' },
              choice.title,
              choice.recommended && React.createElement('span', { className: 'dshk-badge' }, t('recommended'))),
            React.createElement('span', { className: 'dshk-method-desc' }, choice.description)),
          React.createElement('span', { className: 'dshk-chevron', 'aria-hidden': 'true' }, '›')))))

      const authorizationControls = typeof flow?.authUrl === 'string'
        ? React.createElement('div', { className: 'dshk-auth-url' },
            React.createElement('div', { className: 'dshk-auth-url-label' }, t('authorizationUrl')),
            React.createElement('div', { className: 'dshk-auth-url-row' },
              React.createElement('input', {
                className: 'dshk-input', value: flow.authUrl, readOnly: true,
                onFocus: (event) => event.target.select(),
              }),
              React.createElement('button', {
                className: 'dshk-btn', type: 'button', onClick: copyAuthorizationUrl,
              }, copiedAuthUrl ? t('copied') : t('copy')),
              React.createElement('a', {
                className: 'dshk-btn dshk-primary', href: flow.authUrl, target: '_blank', rel: 'noopener noreferrer',
              }, t('openBrowser'))))
        : null

      const pendingFlow = flow?.status === 'pending'
        ? React.createElement(React.Fragment, null,
            React.createElement('div', { className: 'dshk-step-head' },
              React.createElement('button', {
                className: 'dshk-btn dshk-back', type: 'button', disabled: !!busy, onClick: cancelLogin,
              }, `‹ ${t('back')}`),
              React.createElement('div', { className: 'dshk-step-title' },
                methodChoices.find((choice) => choice.id === flow.method)?.title || flow.method)),
            React.createElement('div', { className: 'dshk-code' },
              t('code'), React.createElement('strong', null, flow.userCode),
              React.createElement('div', { className: 'dshk-meta' }, t('pending')),
              authorizationControls),
            error && React.createElement('div', { className: 'dshk-error' }, error))
        : null

      const methodForm = React.createElement(React.Fragment, null,
        React.createElement('div', { className: 'dshk-step-head' },
          React.createElement('button', {
            className: 'dshk-btn dshk-back', type: 'button', disabled: !!busy, onClick: backToMethods,
          }, `‹ ${t('back')}`),
          React.createElement('div', { className: 'dshk-step-title' }, selectedChoice?.title || t('connectTitle'))),
        loginFields.length > 0 && React.createElement('div', { className: 'dshk-grid' }, loginFields),
        React.createElement('div', { className: 'dshk-actions', style: { marginTop: '14px' } },
          React.createElement('button', {
            className: 'dshk-btn dshk-primary', disabled: !!busy, onClick: () => login(method),
          }, busy === 'login' ? t('signingIn') : loginLabel)),
        flow?.status === 'error' && React.createElement('div', { className: 'dshk-error' }, flow.error),
        error && React.createElement('div', { className: 'dshk-error' }, error))

      const authContent = pendingFlow
        ?? (busy === 'login' && (method === 'builder-id' || method === 'google' || method === 'github')
          ? React.createElement('div', { className: 'dshk-working' }, t('signingIn'))
          : selectedMethod === null ? chooser : methodForm)

      return React.createElement('div', { className: 'dshk-wrap' },
        React.createElement('h2', { className: 'dshk-title' },
          React.createElement(KiroLogo),
          t('title')),
        React.createElement('p', { className: 'dshk-desc' }, t('description')),
        React.createElement('section', { className: 'dshk-card' },
          React.createElement('div', { className: 'dshk-head' },
            React.createElement('div', { className: 'dshk-heading' }, t('account')),
            React.createElement('div', { className: 'dshk-actions' },
              // Reachable while signed in too: a second account is added
              // rather than replacing the one in use.
              React.createElement('button', {
                className: 'dshk-btn dshk-primary', disabled: !!busy, onClick: () => openAuth(''),
              }, accountList.length > 0
                ? t('addAccount')
                : status?.authenticated ? t('connectManaged') : t('connectKiro')),
              status?.authenticated && React.createElement('button', {
                className: 'dshk-btn', disabled: !!busy, onClick: refreshUsage,
              }, busy === 'usage' ? t('refreshingUsage') : t('refreshUsage')),
              status?.credentialSource === 'dsh' && React.createElement('button', {
                className: 'dshk-btn', disabled: !!busy, onClick: logout,
              }, accountList.length > 1 ? t('signOutAll') : t('logout')))),
          React.createElement('div', { className: 'dshk-status' },
            React.createElement('span', { className: `dshk-dot${status?.authenticated ? ' dshk-dot-on' : ''}` }),
            React.createElement('span', null, accountLabel),
            status?.region && React.createElement('span', null, `· ${status.region}`)),
          accountList.length > 0 && React.createElement(React.Fragment, null,
            React.createElement('div', { className: 'dshk-accounts' }, accountList.map((account) =>
              React.createElement('div', {
                className: `dshk-account${account.active ? ' dshk-account-active' : ''}`, key: account.id,
              },
              React.createElement('div', { className: 'dshk-account-text' },
                React.createElement('span', { className: 'dshk-account-name' },
                  account.label,
                  account.active && React.createElement('span', { className: 'dshk-badge' }, t('activeAccount'))),
                React.createElement('span', { className: 'dshk-account-sub' },
                  [
                    account.authMethod,
                    account.region,
                    account.state === 'ready'
                      ? t('accountReady')
                      : account.state === 'refresh-required' ? t('accountNeedsRefresh') : t('accountNeedsLogin'),
                  ].filter(Boolean).join(' · '))),
              React.createElement('div', { className: 'dshk-account-actions' },
                !account.active && React.createElement('button', {
                  className: 'dshk-btn', type: 'button', disabled: !!busy,
                  onClick: () => activateAccount(account.id),
                }, t('useAccount')),
                React.createElement('button', {
                  className: 'dshk-btn', type: 'button', disabled: !!busy,
                  onClick: () => openAuth(account.id),
                }, t('reconnect')),
                React.createElement('button', {
                  className: 'dshk-btn dshk-danger', type: 'button', disabled: !!busy,
                  onClick: () => removeAccount(account),
                }, t('removeAccount')))))),
            React.createElement('div', { className: 'dshk-meta' }, t('accountsHint'))),
          status?.authenticated && React.createElement('div', { className: 'dshk-meta dshk-details' },
            status.authMethod && `${t('authMethod')}: ${status.authMethod}`,
            status.authMethod && status.profileArn && ' · ',
            status.profileArn && `${t('profile')}: ${status.profileArn}`),
          status?.credentialSource === 'kiro' && React.createElement('div', {
            className: 'dshk-meta dshk-details',
          }, t('externalHint')),
          status?.authenticated && usage && React.createElement('div', { className: 'dshk-usage' },
            React.createElement('div', { className: 'dshk-usage-top' },
              React.createElement('span', { className: 'dshk-heading' }, t('usage')),
              React.createElement('span', { className: 'dshk-plan' }, usage.plan)),
            (usage.rows || []).map((row) => React.createElement('div', { className: 'dshk-usage-row', key: row.id },
              React.createElement('div', { className: 'dshk-usage-top' },
                React.createElement('span', { className: 'dshk-usage-name' }, row.label),
                React.createElement('span', { className: 'dshk-usage-metric' },
                  row.unlimited
                    // The plan reports no usable bound, so there is no percentage
                    // to show: inventing one would misstate the account.
                    ? `${formatAmount(row.used)} ${t('used')} · ${t('unlimited')}`
                    : `${formatAmount(row.used)} / ${formatAmount(row.limit)} ${t('used')} · ${formatAmount(row.remainingPercent)}% ${t('remaining')}`)),
              React.createElement('div', { className: 'dshk-bar' },
                React.createElement('div', {
                  className: 'dshk-fill',
                  style: { width: `${row.unlimited ? 100 : Math.max(0, Math.min(100, row.remainingPercent || 0))}%` },
                })),
              React.createElement('div', { className: 'dshk-usage-foot' },
                React.createElement('span', null, row.resetAt ? `${t('resets')} ${formatDate(row.resetAt)}` : ''),
                React.createElement('span', null, `${t('updated')} ${formatDate(usage.fetchedAt)}`))))),
          notice && React.createElement('div', { className: 'dshk-notice', role: 'status' }, notice),
          usageError && React.createElement('div', { className: 'dshk-error' }, usageError),
          error && React.createElement('div', { className: 'dshk-error' }, error)),
        React.createElement('section', { className: 'dshk-card' },
          React.createElement('div', { className: 'dshk-head' },
            React.createElement('div', null,
              React.createElement('div', { className: 'dshk-heading' }, t('models')),
              React.createElement('div', { className: 'dshk-meta' }, catalog?.source === 'live' ? t('live') : t('configured'))),
            React.createElement('button', { className: 'dshk-btn dshk-primary', disabled: !!busy || !status?.authenticated, onClick: refresh }, busy === 'models' ? t('refreshing') : t('refresh'))),
          React.createElement('div', { className: 'dshk-context' },
            React.createElement('span', { className: 'dshk-context-label' }, t('maxContext')),
            React.createElement('input', {
              className: 'dshk-input dshk-context-input', inputMode: 'numeric', value: cap,
              placeholder: t('maxContextAuto'), 'aria-label': t('maxContext'),
              onChange: (event) => setCap(event.target.value),
              onKeyDown: (event) => { if (event.key === 'Enter') void applyCap() },
            }),
            React.createElement('button', {
              className: 'dshk-btn', type: 'button', disabled: !!busy, onClick: () => { void applyCap() },
            }, capBusy ? t('saving') : t('apply')),
            React.createElement('span', { className: 'dshk-context-hint' }, t('maxContextHint'))),
          React.createElement('div', { className: 'dshk-model-tools' },
            React.createElement('button', {
              className: 'dshk-link-btn', type: 'button', disabled: !!busy || models.length === enabledModelIds.length,
              onClick: () => saveModels(models.map((model) => model.id)),
            }, t('selectAll')),
            React.createElement('button', {
              className: 'dshk-link-btn', type: 'button', disabled: !!busy || enabledModelIds.length === 0,
              onClick: () => saveModels([]),
            }, t('deselectAll')),
            React.createElement('span', { className: 'dshk-selected-count' },
              busy === 'models-save' ? t('saving') : `${enabledModelIds.length}/${models.length} ${t('selected')}`)),
          models.length === 0
            ? React.createElement('div', { className: 'dshk-empty' }, t('noModels'))
            : React.createElement('div', { className: 'dshk-list' }, models.map((model) => {
                const context = formatTokens(model.contextWindow)
                const output = formatTokens(model.maxTokens)
                const metadata = [
                  model.id,
                  context && `${t('context')} ${context}`,
                  output && `${t('output')} ${output}`,
                  `${t('reasoning')}: ${(model.reasoningEfforts || ['off']).join('/')}${model.defaultReasoningEffort ? ` (${t('default')} ${model.defaultReasoningEffort})` : ''}`,
                ].filter(Boolean).join(' · ')
                return React.createElement('label', {
                  className: `dshk-model${model.enabled ? '' : ' dshk-model-off'}`, key: model.id,
                },
                React.createElement('input', {
                  className: 'dshk-check', type: 'checkbox', checked: !!model.enabled, disabled: !!busy,
                  onChange: (event) => toggleModel(model.id, event.target.checked),
                }),
                React.createElement('span', { className: 'dshk-model-text' },
                  React.createElement('span', { className: 'dshk-model-name' }, model.name),
                  React.createElement('span', { className: 'dshk-model-sub', title: metadata }, metadata)))
              }))),
        authOpen && React.createElement('div', {
          className: 'dshk-overlay',
          role: 'presentation',
          onMouseDown: (event) => { if (event.target === event.currentTarget) closeAuth() },
        },
        React.createElement('div', {
          className: 'dshk-modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': t('connectTitle'),
        },
        React.createElement('div', { className: 'dshk-modal-head' },
          React.createElement('div', { className: 'dshk-modal-title' }, React.createElement(KiroLogo), t('connectTitle')),
          React.createElement('button', {
            className: 'dshk-close', type: 'button', onClick: closeAuth, 'aria-label': t('close'), title: t('close'),
          }, '×')),
        React.createElement('div', { className: 'dshk-modal-body' }, authContent))))
    }

    return {
      inject: ['slots', 'locale'],
      apply(ctx) {
        installStyle()
        // The observer and its scope belong to this plugin's lifetime: an
        // undisposed one keeps watching the DOM after an unload or reload.
        if (typeof ctx.effect === 'function') {
          ctx.effect(() => installNavIcon())
        } else {
          if (window.__kiroNavIconDispose) window.__kiroNavIconDispose()
          window.__kiroNavIconDispose = installNavIcon()
        }
        if (ctx.locale && typeof ctx.locale.register === 'function') ctx.locale.register(NS, { en, zh })
        ctx.slots.inject('settings.section', () => ctx.slots.register({
          name: 'settings.section',
          id: 'kiro',
          order: 12,
          label: () => 'Kiro',
        }, () => React.createElement(KiroSettings, { ctx })))
        // The quota the account is actually spending belongs beside the control
        // that spends it, the way the Antigravity and Codex plugins show theirs.
        // The chip answers "what is left of the plan this session is spending",
        // so it needs the session's own selection to know whether that is Kiro.
        // A host without that service (or without `inject` at all) registers the
        // seat without a directory, and the chip then stays invisible rather
        // than guessing which route the session is on.
        const registerQuota = (host) => {
          const directoryFor = host.modelDirectories?.directoryFor
          host.slots.inject('conversation.input.right', () => host.slots.register({
            name: 'conversation.input.right',
            id: 'kiro-quota',
            order: 20,
            locale: NS,
            ...typeof directoryFor !== 'function' ? {} : {
              inject: (sessionId) => ({ directory: host.modelDirectories.directoryFor(sessionId).store }),
            },
          }, (props) => React.createElement(KiroQuota, { ...props, ctx })))
        }
        if (typeof ctx.inject === 'function') ctx.inject(['slots', 'modelDirectories'], registerQuota)
        else registerQuota(ctx)
      },
    }
  },
})
