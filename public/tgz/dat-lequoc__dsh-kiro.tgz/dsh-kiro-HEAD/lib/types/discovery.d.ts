/** Live Kiro model discovery through ListAvailableModels. */
import type { ModelModality } from '@deepseek-ai/dsh-llm';
import type { KiroCatalogModel, KiroConnectionOptions } from './adapter.ts';
import type { KiroToken } from './auth.ts';
import { getJson, postJsonWithHeaders } from './transport.ts';
/**
 * Read the input modalities a catalog entry declares.
 *
 * The service states this per model as `supportedInputTypes: ["TEXT","IMAGE"]`,
 * so the capability is read rather than inferred from the model id: on this
 * account 17 of 19 models accept images while `glm-5` and `minimax-m2.5` accept
 * only text, and an id-based guess would send images to a model that refuses
 * them. An unreadable value yields absence, which leaves the configured default
 * in force instead of silently narrowing the model to text.
 * @param value - the raw `supportedInputTypes` member.
 * @returns declared modalities in display order, or undefined when unreadable.
 */
export declare function parseInputModalities(value: unknown): ModelModality[] | undefined;
/** Request hook used to test discovery without network access. */
export type ModelDiscoveryRequest = typeof getJson;
/** POST hook used for ListAvailableProfiles. */
export type ProfileDiscoveryRequest = typeof postJsonWithHeaders;
/** Constructor dependencies for {@link KiroModelDiscovery}. */
export interface KiroModelDiscoveryOptions {
    resolveToken: (connection: KiroConnectionOptions, signal: AbortSignal) => Promise<KiroToken>;
    requestJson?: ModelDiscoveryRequest;
    profileRequestJson?: ProfileDiscoveryRequest;
    cacheTtlMs?: number;
}
/** Resolve the best CodeWhisperer profile ARN for one OAuth credential. */
export declare function discoverKiroProfileArn(connection: Pick<KiroConnectionOptions, 'region' | 'proxyUrl'>, token: KiroToken, signal: AbortSignal, request?: ProfileDiscoveryRequest): Promise<string | undefined>;
/** Infer whether a discovered route should expose Kiro's thinking controls. */
export declare function modelSupportsThinking(modelId: string): boolean;
interface ParsedEffortSchema {
    levels: string[];
    schemaPath: 'output_config' | 'reasoning';
    defaultLevel?: string;
}
/** Parse the same two effort-schema branches used by the installed Kiro client. */
export declare function parseEffortSchema(schema: unknown): ParsedEffortSchema | undefined;
/**
 * Read the bounds of the model's advertised `max_tokens` request field.
 *
 * The field is the only output cap `generateAssistantResponse` honors, and the
 * advertised schema is `additionalProperties: false`, so a value outside the
 * declared range — or the field itself on a model that does not declare it —
 * fails validation. Sending it therefore requires reading these bounds first.
 * @param schema - the model's `additionalModelRequestFieldsSchema`.
 * @returns the inclusive bounds, or `undefined` when the model declares none.
 */
export declare function parseMaxTokensBounds(schema: unknown): {
    minimum: number;
    maximum: number;
} | undefined;
/**
 * Parse Kiro's ListAvailableModels response into harness catalog entries.
 * @param body - decoded JSON response.
 * @returns unique models in provider order.
 */
export declare function parseAvailableModels(body: unknown): KiroCatalogModel[];
/**
 * Read the continuation token of one ListAvailableModels page.
 * @param body - decoded JSON response.
 * @returns the token, or `undefined` when this page is the last.
 */
export declare function modelPageToken(body: unknown): string | undefined;
/** Cached account-specific model discovery used by the adapter and web UI. */
export declare class KiroModelDiscovery {
    private readonly options;
    private readonly requestJson;
    private readonly profileRequestJson;
    private readonly cacheTtlMs;
    private readonly cache;
    constructor(options: KiroModelDiscoveryOptions);
    private key;
    /** Drop all cached discovery results after login or logout. */
    clear(): void;
    private endpoint;
    private headers;
    private discoverProfile;
    /**
     * Return the last discovered catalog for this connection without I/O.
     * @param connection - current connection facts.
     * @returns cached models, if a matching discovery has completed.
     */
    current(connection: KiroConnectionOptions): readonly KiroCatalogModel[] | undefined;
    /**
     * Discover models offered to the signed-in account.
     * @param connection - frozen request facts.
     * @param signal - caller cancellation.
     * @param force - bypass a still-valid cache entry.
     * @returns live Kiro model metadata.
     */
    list(connection: KiroConnectionOptions, signal: AbortSignal, force?: boolean): Promise<readonly KiroCatalogModel[]>;
}
export {};
