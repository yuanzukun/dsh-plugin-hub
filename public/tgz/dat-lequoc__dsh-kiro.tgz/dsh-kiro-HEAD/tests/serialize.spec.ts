import { describe, expect, it } from 'vitest'
import { ToolCallId, createAssistantMessage, createMessage, createToolResultMessage, createUserMessage } from '@deepseek-ai/dsh-llm'
import type { GenerateOptions, Message } from '@deepseek-ai/dsh-llm'
import { serializeRequest } from '../src/serialize.ts'
import type { WireImageBlock, WireUserInputMessage } from '../src/types.ts'

const SOURCE = { kind: 'plugin' as const, plugin: 'test' }

/** One user message carrying plain text. */
function user(text: string): Message {
  return createUserMessage({ content: [{ type: 'text', text }], source: SOURCE })
}

/** One assistant message carrying text and optional tool calls. */
function assistant(text: string, calls: { id: string; name: string; args: string }[] = []): Message {
  return createAssistantMessage({
    content: [
      ...text.length > 0 ? [{ type: 'text' as const, text }] : [],
      ...calls.map(call => ({
        type: 'tool-call' as const,
        id: ToolCallId(call.id),
        name: call.name,
        arguments: call.args,
      })),
    ],
    source: { provider: 'kiro', model: 'claude-sonnet-4.5' },
  })
}

/** One tool-result message for the named call. */
function toolResult(id: string, text: string, isError = false): Message {
  return createToolResultMessage({
    callId: ToolCallId(id),
    content: [{ type: 'text', text }],
    isError,
  })
}

/** Serialize with the fields every case shares. */
function serialize(
  messages: Message[],
  extra: Partial<GenerateOptions> = {},
  defaults = {},
  images?: ReadonlyMap<string, WireImageBlock>,
) {
  return serializeRequest(
    { provider: 'kiro', model: 'claude-sonnet-4.5', messages, ...extra },
    defaults,
    'conv-1',
    'arn:aws:codewhisperer:us-east-1:1:profile/X',
    undefined,
    undefined,
    images,
  )
}

/** A durable image reference shaped like the attachment service's own. */
function imageRef(id: string) {
  return { attachmentId: id, mediaType: 'image/png', bytes: 4, width: 2, height: 2 }
}

/** One user message carrying a single image block. */
function userImage(id: string, text?: string) {
  return createUserMessage({
    content: [
      ...text === undefined ? [] : [{ type: 'text' as const, text }],
      { type: 'image' as const, attachment: imageRef(id) },
    ],
    source: SOURCE,
  } as never)
}

const PREPARED_PNG: WireImageBlock = { format: 'png', source: { bytes: 'aGVsbG8=' } }

/** The history entries, narrowed for assertions. */
function history(request: ReturnType<typeof serialize>) {
  return request.conversationState.history ?? []
}

/** The current user message. */
function currentOf(request: ReturnType<typeof serialize>): WireUserInputMessage {
  return request.conversationState.currentMessage.userInputMessage
}

describe('serializeRequest', () => {
  it('sends a lone user turn as currentMessage with no history', () => {
    const request = serialize([user('hello')])
    expect(currentOf(request).content).toBe('hello')
    expect(currentOf(request).modelId).toBe('claude-sonnet-4.5')
    expect(currentOf(request).origin).toBe('AI_EDITOR')
    expect(request.conversationState.history).toBeUndefined()
    expect(request.profileArn).toBe('arn:aws:codewhisperer:us-east-1:1:profile/X')
  })

  it('omits profileArn when the account default applies', () => {
    const request = serializeRequest(
      { provider: 'kiro', model: 'auto', messages: [user('hi')] },
      {},
      'conv-1',
    )
    expect('profileArn' in request).toBe(false)
  })

  it('prepends the system prompt to the earliest user turn', () => {
    const request = serialize([user('first'), assistant('answer'), user('second')], { system: 'PERSONA' })
    const first = history(request)[0]
    expect(first).toMatchObject({ userInputMessage: { content: 'PERSONA\n\nfirst' } })
    // The later turn stays clean: the prompt belongs at one place in the prefix.
    expect(currentOf(request).content).toBe('second')
  })

  it('prepends the system prompt to currentMessage when there is no history', () => {
    const request = serialize([user('only')], { system: 'PERSONA' })
    expect(currentOf(request).content).toBe('PERSONA\n\nonly')
  })

  it('carries thinking markers with the resolved effort budget', () => {
    const request = serialize([user('hi')], { system: 'PERSONA' }, { reasoningEffort: 'high' })
    expect(currentOf(request).content).toBe(
      '<thinking_mode>enabled</thinking_mode><max_thinking_length>24000</max_thinking_length>\nPERSONA\n\nhi',
    )
  })

  it('omits thinking markers at effort off', () => {
    const request = serialize([user('hi')], {}, { reasoningEffort: 'off' })
    expect(currentOf(request).content).toBe('hi')
  })

  it('sends discovered Claude efforts through output_config without prompt markers', () => {
    const request = serializeRequest(
      {
        provider: 'kiro',
        model: 'claude-opus-5',
        messages: [user('hi')],
        reasoningEffort: 'max' as never,
        system: 'PERSONA',
      },
      {},
      'conv-1',
      undefined,
      {
        schemaPath: 'output_config',
        levels: ['low', 'medium', 'high', 'xhigh', 'max'],
        defaultLevel: 'high',
      },
    )
    expect(request.additionalModelRequestFields).toEqual({ output_config: { effort: 'max' } })
    expect(currentOf(request).content).toBe('PERSONA\n\nhi')
  })

  it('uses the live GPT default and reasoning schema path', () => {
    const request = serializeRequest(
      { provider: 'kiro', model: 'gpt-5.6-sol', messages: [user('hi')] },
      {},
      'conv-1',
      undefined,
      {
        schemaPath: 'reasoning',
        levels: ['none', 'low', 'medium', 'high', 'xhigh', 'max'],
        defaultLevel: 'high',
      },
    )
    expect(request.additionalModelRequestFields).toEqual({ reasoning: { effort: 'high' } })
  })

  it('rejects an effort absent from the selected model’s live schema', () => {
    expect(() => serializeRequest(
      {
        provider: 'kiro',
        model: 'claude-opus-4.6',
        messages: [user('hi')],
        reasoningEffort: 'xhigh' as never,
      },
      {},
      'conv-1',
      undefined,
      { schemaPath: 'output_config', levels: ['low', 'medium', 'high', 'max'] },
    )).toThrowError(expect.objectContaining({ code: 'UNSUPPORTED_REASONING_EFFORT' }))
  })

  it.each([['low', 4000], ['medium', 12000], ['high', 24000]] as const)(
    'publishes the %s effort budget as %i tokens',
    (effort, budget) => {
      const request = serialize([user('hi')], {}, { reasoningEffort: effort })
      expect(currentOf(request).content).toContain(`<max_thinking_length>${budget}</max_thinking_length>`)
    },
  )

  it('forces a session title to spend its budget on visible text', () => {
    const request = serialize([user('hi')], { purpose: 'session-title' }, { reasoningEffort: 'high' })
    expect(currentOf(request).content).toBe('hi')
  })

  it('refuses an effort the adapter does not publish', () => {
    expect(() => serialize([user('hi')], { reasoningEffort: 'ultra' as never }))
      .toThrowError(expect.objectContaining({ code: 'UNSUPPORTED_REASONING_EFFORT' }))
  })

  it('refuses to enable thinking against a deployment that disabled it', () => {
    expect(() => serialize([user('hi')], { reasoningEffort: 'high' as never }, { thinking: 'disabled' }))
      .toThrowError(expect.objectContaining({ code: 'UNSUPPORTED_REASONING_EFFORT' }))
  })

  it('sends tool schemas on the current turn', () => {
    const request = serialize([user('weather?')], {
      tools: [{ name: 'get_weather', description: 'Get weather', parameters: { type: 'object', properties: {} } }],
    })
    expect(currentOf(request).userInputMessageContext?.tools).toEqual([{
      toolSpecification: {
        name: 'get_weather',
        description: 'Get weather',
        inputSchema: { json: { type: 'object', properties: {} } },
      },
    }])
  })

  it('refuses a tool name the service rejects', () => {
    expect(() => serialize([user('hi')], {
      tools: [{ name: 'get-weather', description: 'd', parameters: {} }],
    })).toThrowError(expect.objectContaining({ code: 'UNSUPPORTED_TOOL_NAME' }))
  })

  it('pairs a tool result with the call its history issued', () => {
    const request = serialize([
      user('weather?'),
      assistant('checking', [{ id: 'call-1', name: 'get_weather', args: '{"city":"Beijing"}' }]),
      toolResult('call-1', 'sunny'),
    ])
    expect(history(request).at(-1)).toMatchObject({
      assistantResponseMessage: {
        toolUses: [{ toolUseId: 'call-1', name: 'get_weather', input: { city: 'Beijing' } }],
      },
    })
    expect(currentOf(request).userInputMessageContext?.toolResults).toEqual([
      { toolUseId: 'call-1', content: [{ text: 'sunny' }], status: 'success' },
    ])
    expect(currentOf(request).content).toBe('Tool results provided.')
  })

  it('rewrites a foreign tool-call id Kiro rejects, keeping call and result paired', () => {
    // Codex ids replayed after switching the session's model to Kiro.
    const codexId = 'call_0lx9PIkFKkM32YzX11jiARuO|fc_06f12345a6aaa55d016ab6efee5e8887d1ae4f4f739af1b6b8'
    const request = serialize([
      user('weather?'),
      assistant('', [{ id: codexId, name: 'get_weather', args: '{}' }]),
      toolResult(codexId, 'sunny'),
    ])
    const last = history(request).at(-1)
    const useId = last !== undefined && 'assistantResponseMessage' in last
      ? last.assistantResponseMessage.toolUses?.[0]?.toolUseId
      : undefined
    expect(useId).toMatch(/^[A-Za-z0-9_-]{1,64}$/)
    expect(currentOf(request).userInputMessageContext?.toolResults?.[0]?.toolUseId).toBe(useId)
  })

  it('folds the oldest turns into text once history passes the service cap', () => {
    // Kiro refuses more than 198 history entries with "Input is too long."
    // whatever the token count; 150 tool steps produce 300 entries.
    const messages: Message[] = [user('q0')]
    for (let i = 0; i < 150; i++) {
      messages.push(assistant(`a${i}`, [{ id: `c${i}`, name: 'run', args: `{"i":${i}}` }]))
      messages.push(toolResult(`c${i}`, `out${i}`))
    }
    const request = serialize(messages)
    const entries = history(request)
    expect(entries.length).toBeLessThanOrEqual(198)
    expect(entries.length % 2).toBe(0)
    const folded = entries[0]
    const foldedText = folded !== undefined && 'userInputMessage' in folded ? folded.userInputMessage.content : ''
    for (const fragment of ['q0', 'a0', 'out0', '{"i":0}']) expect(foldedText).toContain(fragment)
    expect(JSON.stringify(request)).toContain('out148')
    // Every replayed result still names a call the wire issued.
    const issued = new Set<string>()
    entries.forEach((entry, index) => {
      expect('userInputMessage' in entry).toBe(index % 2 === 0)
      if ('assistantResponseMessage' in entry) {
        for (const use of entry.assistantResponseMessage.toolUses ?? []) issued.add(use.toolUseId)
        return
      }
      for (const result of entry.userInputMessage.userInputMessageContext?.toolResults ?? []) {
        expect(issued.has(result.toolUseId)).toBe(true)
      }
    })
    expect(currentOf(request).userInputMessageContext?.toolResults?.[0]?.toolUseId).toBe('c149')
  })

  it('only appends between folds, so the cached prefix survives each step', () => {
    const messages: Message[] = [user('q0')]
    for (let i = 0; i < 250; i++) {
      messages.push(assistant(`a${i}`, [{ id: `c${i}`, name: 'run', args: '{}' }]))
      messages.push(toolResult(`c${i}`, `out${i}`))
    }
    const rewrites: number[] = []
    let previous: string[] = []
    for (let steps = 90; steps <= 250; steps++) {
      const entries = history(serialize(messages.slice(0, 1 + steps * 2), { system: 'SYS' }))
        .map(entry => JSON.stringify(entry))
      if (!previous.every((entry, index) => entries[index] === entry)) rewrites.push(steps)
      previous = entries
    }
    // One fold roughly every 74 steps; every step in between extends the last request.
    expect(rewrites).toEqual([100, 174, 249])
  })

  it('marks a failed tool result as an error', () => {
    const request = serialize([
      user('weather?'),
      assistant('checking', [{ id: 'call-1', name: 'get_weather', args: '{}' }]),
      toolResult('call-1', 'boom', true),
    ])
    expect(currentOf(request).userInputMessageContext?.toolResults?.[0]?.status).toBe('error')
  })

  it('degrades a tool result with no issuing call to text', () => {
    // Compaction can drop the assistant turn that issued a call while keeping
    // its result. Kiro rejects the orphan, so the output reaches the model as text.
    const request = serialize([user('do it'), toolResult('call-gone', 'output text')])
    expect(currentOf(request).userInputMessageContext?.toolResults).toBeUndefined()
    expect(currentOf(request).content).toContain('[Output for tool call call-gone]:\noutput text')
  })

  it('replaces unparsable tool arguments with an empty object', () => {
    const request = serialize([
      user('go'),
      assistant('calling', [{ id: 'call-1', name: 'run', args: '{"truncated' }]),
      toolResult('call-1', 'ok'),
    ])
    expect(history(request).at(-1)).toMatchObject({
      assistantResponseMessage: { toolUses: [{ input: {} }] },
    })
  })

  it('sends empty tool output as a placeholder the wire accepts', () => {
    const request = serialize([
      user('go'),
      assistant('calling', [{ id: 'call-1', name: 'run', args: '{}' }]),
      toolResult('call-1', ''),
    ])
    expect(currentOf(request).userInputMessageContext?.toolResults?.[0]?.content)
      .toEqual([{ text: '(no output)' }])
  })

  it('merges consecutive same-role turns to keep history alternating', () => {
    const request = serialize([
      user('one'),
      user('two'),
      assistant('a'),
      assistant('b'),
      user('three'),
    ])
    expect(history(request)).toEqual([
      { userInputMessage: { content: 'one\n\ntwo', modelId: 'claude-sonnet-4.5', origin: 'AI_EDITOR' } },
      { assistantResponseMessage: { content: 'a\n\nb' } },
    ])
    expect(currentOf(request).content).toBe('three')
  })

  it('appends neutral continuation text when the conversation ends on the assistant', () => {
    // A resumed session replays history whose last entry is the assistant's;
    // Kiro still needs a user turn to answer. The padding must be ordinary
    // conversational text: a distinctive system-looking marker gets imitated by
    // the model and then persisted as visible assistant output.
    const request = serialize([user('hi'), assistant('done')])
    expect(currentOf(request).content).toBe('Continue')
    expect(history(request)).toEqual([
      { userInputMessage: { content: 'hi', modelId: 'claude-sonnet-4.5', origin: 'AI_EDITOR' } },
      { assistantResponseMessage: { content: 'done' } },
    ])
  })

  it('keeps history ending on the assistant', () => {
    const request = serialize([user('one'), assistant('a'), user('two'), user('three')])
    expect(history(request)).toHaveLength(2)
    expect(history(request).at(-1)).toHaveProperty('assistantResponseMessage')
    expect(currentOf(request).content).toBe('two\n\nthree')
  })

  it('treats a mid-conversation system message as user content', () => {
    const system = createMessage({ role: 'system', content: [{ type: 'text', text: 'RULE' }], source: SOURCE })
    const request = serialize([system, user('hi')])
    expect(currentOf(request).content).toBe('RULE\n\nhi')
  })

  it('gives a text-less assistant turn the neutral acknowledgement', () => {
    const request = serialize([
      user('go'),
      assistant('', [{ id: 'call-1', name: 'run', args: '{}' }]),
      toolResult('call-1', 'ok'),
    ])
    expect(history(request).at(-1)).toMatchObject({
      assistantResponseMessage: { content: 'understood' },
    })
  })

  it('puts a prepared user image on its own turn', () => {
    const request = serialize(
      [userImage('att-1', 'what is this?')],
      {},
      {},
      new Map([['att-1', PREPARED_PNG]]),
    )
    expect(request.conversationState.currentMessage.userInputMessage).toMatchObject({
      content: 'what is this?',
      images: [{ format: 'png', source: { bytes: 'aGVsbG8=' } }],
    })
  })

  it('refuses an image nobody prepared rather than dropping it', () => {
    // A missing preparation is a bug in the adapter, not user content to discard:
    // sending the turn without the image would answer about nothing.
    expect(() => serialize([userImage('att-missing')]))
      .toThrowError(expect.objectContaining({ code: 'INVALID_REQUEST' }))
  })

  it('refuses an image on an assistant turn, which has no wire seat for one', () => {
    const message = createAssistantMessage({
      content: [{ type: 'image', attachment: imageRef('att-2') }],
      source: SOURCE,
    } as never)
    expect(() => serialize([user('hi'), message, user('again')], {}, {}, new Map([['att-2', PREPARED_PNG]])))
      .toThrowError(expect.objectContaining({ code: 'UNSUPPORTED_CONTENT' }))
  })

  it('hoists an image out of a tool result onto the same user turn', () => {
    // `ToolResultContentBlock` is a union of text and json only, so the
    // enclosing turn is the nearest seat that keeps the screenshot.
    const result = createToolResultMessage({
      callId: ToolCallId('call-1'),
      content: [
        { type: 'text', text: 'screenshot taken' },
        { type: 'image', attachment: imageRef('att-3') },
      ],
    } as never)
    const request = serialize(
      [user('shoot'), assistant('', [{ id: 'call-1', name: 'shoot', args: '{}' }]), result],
      {},
      {},
      new Map([['att-3', PREPARED_PNG]]),
    )
    const current = request.conversationState.currentMessage.userInputMessage
    expect(current.images).toEqual([PREPARED_PNG])
    expect(current.userInputMessageContext?.toolResults?.[0]?.toolUseId).toBe('call-1')
  })

  it('sends no images member when the request has none', () => {
    const request = serialize([user('text only')])
    expect(request.conversationState.currentMessage.userInputMessage.images).toBeUndefined()
  })

  it('refuses a request with no messages', () => {
    expect(() => serialize([])).toThrowError(expect.objectContaining({ code: 'INVALID_REQUEST' }))
  })
})
