/**
 * dsh-https-fix 客户端卡片(settings 插件页)回归测试。
 *
 * 用法(依赖不写进插件 package.json,按需临时安装):
 *   npm i --no-save react@18 react-dom@18 jsdom
 *   node test/ui-harness.mjs [客户端 bundle 路径,默认 ../lib/client.js]
 *
 * 覆盖:折叠/展开、状态徽标、字段回显与改动、一键填入当前地址、证书来源切换、
 * 校验结果汇总、热补丁消息、保存/放弃/恢复默认、三次确认、只读与不可用态。
 * 退出码非 0 表示有断言失败。
 */
import { createRequire } from "node:module"
import { pathToFileURL, fileURLToPath } from "node:url"

// 依赖从「运行命令时的当前目录」解析:在仓库根目录 npm i --no-save react@18 react-dom@18 jsdom 再跑
const require = createRequire(process.cwd() + "/")
const { JSDOM } = await import(pathToFileURL(require.resolve("jsdom")).href)
const React = require("react")
const ReactDOM = require("react-dom/client")
const { Simulate } = require("react-dom/test-utils")
const jsxRuntime = require("react/jsx-runtime")
const { act } = React

const dom = new JSDOM("<!doctype html><html><head></head><body><ul id='root'></ul></body></html>", { url: "https://203.0.113.7:3081/settings" })
global.window = dom.window
global.document = dom.window.document
Object.defineProperty(global, "navigator", { value: dom.window.navigator, configurable: true })
global.IS_REACT_ACT_ENVIRONMENT = true
let confirmCount = 0
dom.window.confirm = () => { confirmCount++; return true }

// —— 0.1.7 数据层 mock:remote.settings.describe / mutate ————————————————
let configValue = { enableHttps: true, domain: "old.example.com", httpsPort: 3081, address: "", certPath: "", keyPath: "", autoToken: true, versionCheck: true, blockHttpExternalAccess: false, loginEnabled: true, loginUser: "admin", loginPasswordHash: "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918" }
let userLayer = { domain: "old.example.com" }
const baseLayer = { httpPort: 3080 }
let revision = 3
let writable = true
let describeFails = false
const calls = []
const remoteSettings = {
  async describe() {
    if (describeFails) return { ok: false, error: { code: "unavailable", message: "settings unavailable" } }
    return { ok: true, value: {
      writable,
      hasDocument: true,
      namespaces: [{
        ns: "https-fix", autoGenerate: false, schema: {}, value: configValue, base: baseLayer, user: userLayer,
        applies: "live", secrets: [], revision
      }]
    } }
  },
  async mutate(ns, ops, expectedRevision) {
    if (!writable) return { ok: false, error: { code: "readonly", message: "read-only" } }
    for (const op of ops) {
      const key = op.path[0]
      if (op.op === "set") {
        calls.push(["set", key, op.value])
        configValue = { ...configValue, [key]: op.value }
        userLayer = { ...userLayer, [key]: op.value }
      } else {
        calls.push(["unset", key])
        const next = { ...userLayer }
        delete next[key]
        userLayer = next
      }
    }
    revision += 1
    return { ok: true }
  }
}


const clientReports = []
let statusValue = { running: true, httpsPort: 3081, domain: "old.example.com", certSource: "auto-self-signed", certPath: "/root/.dsh/https-fix/self-signed.crt", enableHttps: true, serverIps: ["10.0.0.5", "172.17.0.1"] }
global.fetch = async (url, init) => {
  JSON.parse(init.body)
  let result
  if (url.endsWith("/status")) result = { ok: true, value: statusValue }
  else if (url.endsWith("/patch-status")) result = { ok: true, patched: false, msg: "未打热补丁" }
  else if (url.endsWith("/validate")) result = { ok: false, log: [{ ok: true, msg: "版本核对:dsh 0.1.5-rc.2 一致" }, { ok: false, msg: "热补丁:未应用" }] }
  else if (url.endsWith("/patch-loopback")) result = { ok: true, log: ["已写入热补丁"] }
  else if (url.endsWith("/revert-loopback")) result = { ok: true, log: ["已还原"] }
  else if (url.endsWith("/clientlog")) { clientReports.push(JSON.parse(init.body).payload); result = { ok: true, value: { logged: true } } }
  else result = { ok: true }
  return { json: async () => ({ type: "server-response", rpcId: "t", result }) }
}

const clientFile = process.argv[2] ?? fileURLToPath(new URL("../lib/client.js", import.meta.url))
let def = null
dom.window.__ModuleLoader__ = { load: (d) => { def = d } }
await import(pathToFileURL(clientFile).href)
const mod = def.factory((n) => (n === "react" ? React : n === "react/jsx-runtime" ? jsxRuntime : require(n)))

let Card = null
let injected = null
// cordis 只允许访问已声明的服务:没 inject "remote" 就抛(2026-09-24 远程卡片"设置不可用"的真因)
const declaredInject = Array.isArray(mod.inject) ? mod.inject : []
let remoteAccessCount = 0
const ctx = {
  get remote() {
    if (!declaredInject.includes("remote")) throw new Error('cannot get property "remote" without inject(插件的 inject 里必须声明 "remote")')
    remoteAccessCount++
    return { settings: remoteSettings, $on: () => () => {} }
  },
  slots: {
    inject: (name, fn) => fn(),
    register: (spec, component) => { Card = component; injected = spec.inject() }
  },
  effect: (fn) => { const disposer = fn(); return () => { if (typeof disposer === "function") disposer() } }
}
mod.apply(ctx)
const controller = injected.controller

const results = []
const check = (name, cond, extra) => { results.push([cond ? "PASS" : "FAIL", name, extra ?? ""]) }
const $ = (sel) => document.querySelector(sel)
const $$ = (sel) => Array.from(document.querySelectorAll(sel))
const text = (sel) => ($(sel) ? $(sel).textContent : "<missing>")
const byText = (tag, t) => $$(tag).find((e) => e.textContent === t)
const labelFor = (t) => $$("label.hf_label").find((l) => l.textContent === t).htmlFor
const flush = () => act(async () => { await new Promise((r) => setTimeout(r, 0)) })

const root = ReactDOM.createRoot($("#root"))
await act(async () => { root.render(React.createElement(Card, injected)) })
await flush()

check("inject 里声明了 remote(cordis 访问约束)", declaredInject.includes("remote"), JSON.stringify(declaredInject))
check("卡片标题渲染", text(".hf_name") === "Https Fix")
check("头部状态徽标=运行中", text(".hf_badge").includes("运行中 old.example.com:3081") && text(".hf_badge").includes("自签"), text(".hf_badge"))
check("默认展开(设置页 tab)", $(".hf_body") !== null)
await act(async () => { $(".hf_header").click() })
check("可折叠", $(".hf_body") === null)
await act(async () => { $(".hf_header").click() })
check("展开后出现四个分组", ["HTTPS 服务", "TLS 证书", "访问与安全", "诊断"].every((t) => $$(".hf_sectionTitle").some((e) => e.textContent === t)), $$(".hf_sectionTitle").map((e) => e.textContent).join(" | "))
// 布局不变量:一行一个设置,禁止任何自动并排容器
const fieldsStacked = () => $$(".hf_field").every((f) => f.parentElement && f.parentElement.classList.contains("hf_section"))
check("设置项一行一个(无并排容器)", $$(".hf_grid").length === 0)
check("设置项都是分组的直接子元素", fieldsStacked(), $$(".hf_field").map((f) => f.parentElement.className).join(" | ").slice(0, 90))
check("访问入口预览", text(".hf_url").includes("https://old.example.com:3081/"), text(".hf_url"))
check("域名输入框回显", $("#" + labelFor("域名 / IP")).value === "old.example.com")
check("用户改过的项有恢复默认", $$(".hf_inlineBtn").some((b) => b.textContent === "恢复默认"))
check("自动自签说明块存在", $$(".hf_note").length === 1 && text(".hf_note").includes("self-signed.crt"))

// 改域名 -> 未保存
const domainInput = $("#" + labelFor("域名 / IP"))
await act(async () => { Simulate.change(domainInput, { target: { value: "new.example.com" } }) })
check("改动后出现未保存徽标", text(".hf_pending") === "未保存", text(".hf_pending"))
check("页脚提示改动数量", text(".hf_footerNote").includes("1 项改动未保存"), text(".hf_footerNote"))
check("访问入口跟随改动", text(".hf_url").includes("https://new.example.com:3081/"), text(".hf_url"))

// 一键填入当前地址
await act(async () => { byText("button", "填入当前地址").click() })
check("一键填入当前地址栏 host", domainInput.value === "203.0.113.7", domainInput.value)

// 校验
await act(async () => { byText("button", "校验 HTTPS 可用性").click() })
await flush()
check("校验结果摘要", text(".hf_summary").includes("1/2 项需要处理"), text(".hf_summary"))
check("校验条目渲染两条", $$(".hf_log span").length === 2, String($$(".hf_log span").length))

// 热补丁
await act(async () => { byText("button", "一键打热补丁").click() })
await flush()
check("热补丁结果渲染", $$(".hf_log span").some((s) => s.textContent.includes("已写入热补丁")))

// 保存
await act(async () => { byText("button", "保存配置").click() })
await flush()
check("保存写入 staged 字段", calls.some((c) => c[0] === "set" && c[1] === "domain" && c[2] === "203.0.113.7"), JSON.stringify(calls.filter((c) => c[0] === "set")))
check("保存后未保存徽标消失", $(".hf_pending") === null)

// 恢复默认
const resetBtn = byText("button", "恢复默认")
check("恢复默认按钮存在", !!resetBtn)
await act(async () => { resetBtn.click() })
await flush()
check("恢复默认调用 controller.unset", calls.some((c) => c[0] === "unset" && c[1] === "domain"), JSON.stringify(calls))

// 证书模式:切到自定义路径应出现两个输入框
const radios = $$(".hf_choiceRow input[type=radio]")
await act(async () => { radios[1].click() })
check("切到自定义证书显示路径输入", $("#" + labelFor("cert 路径")) !== null && $("#" + labelFor("key 路径")) !== null)
check("自定义路径也一行一个", fieldsStacked() && $$(".hf_grid").length === 0)
await act(async () => { Simulate.change($("#" + labelFor("cert 路径")), { target: { value: "/etc/ssl/a.pem" } }) })
check("只填 cert 时提示成对填写", $$(".hf_warn").length === 1, text(".hf_warn"))
await act(async () => { Simulate.change($("#" + labelFor("key 路径")), { target: { value: "/etc/ssl/a.key" } }) })
check("成对填写后提示消失", $$(".hf_warn").length === 0)
await act(async () => { radios[0].click() })
check("切回自动自签显示说明块", $$(".hf_note").length === 1)

// 关闭版本核对:三次确认 + 待保存 + 保存
confirmCount = 0
await act(async () => { $("#" + labelFor("核对版本号")).click() })
check("关闭核对版本号触发三次确认", confirmCount === 3, "confirm=" + confirmCount)
check("关闭后进入待保存状态", text(".hf_pending") === "未保存", text(".hf_pending"))
await act(async () => { byText("button", "保存配置").click() })
await flush()
check("保存后写入 versionCheck=false", calls.some((c) => c[0] === "set" && c[1] === "versionCheck" && c[2] === false), JSON.stringify(calls.filter((c) => c[0] === "set")))

// 放弃修改
await act(async () => { Simulate.change($("#" + labelFor("域名 / IP")), { target: { value: "discard.me" } }) })
check("改动后可放弃", byText("button", "放弃修改").disabled === false)
await act(async () => { byText("button", "放弃修改").click() })
check("放弃后未保存徽标消失", $(".hf_pending") === null)

// 服务器 IP 来源(host 侧网卡枚举,经 status RPC 下发)
const domainBox = () => $("#" + labelFor("域名 / IP"))
const refreshStatusViaValidate = async () => {
  await act(async () => { byText("button", "校验 HTTPS 可用性").click() })
  await flush()
}
statusValue = { ...statusValue, serverIps: [{ iface: "ens18", address: "10.0.0.5", private: false }] }
await refreshStatusViaValidate()
await act(async () => { byText("button", "填入服务器 IP").click() })
check("单个服务器 IP 直接填入", domainBox().value === "10.0.0.5", domainBox().value)

statusValue = { ...statusValue, serverIps: [{ iface: "ens18", address: "10.0.0.5", private: false }, { iface: "docker0", address: "172.17.0.1", private: true }] }
await refreshStatusViaValidate()
await act(async () => { byText("button", "填入服务器 IP").click() })
check("多个服务器 IP 展开候选行(带网卡名)", $$("span").some((s) => s.textContent === "服务器网卡地址(公网优先):") && $$("button").some((b) => b.textContent === "docker0 · 172.17.0.1"), $$(".hf_row button").map((b) => b.textContent).join(" | "))
await act(async () => { $$("button").find((b) => b.textContent.includes("172.17.0.1")).click() })
check("选候选后填入并收起候选行", domainBox().value === "172.17.0.1" && !$$("span").some((s) => s.textContent === "服务器网卡地址(公网优先):"), domainBox().value)

statusValue = { ...statusValue, serverIps: [] }
await refreshStatusViaValidate()
check("无服务器 IP 时按钮禁用", byText("button", "填入服务器 IP").disabled === true)

// 登录设置(密码只暂存 SHA-256)
const sha256 = (t) => require("crypto").createHash("sha256").update(t, "utf8").digest("hex")
const DEFAULT_HASH = sha256("admin")
check("登录三项设置都在", ["启用登录", "登录账号", "登录密码"].every((l) => $$("label.hf_label").some((x) => x.textContent === l)), $$("label.hf_label").map((x) => x.textContent).join(","))
check("初始显示默认密码状态", $$("span").some((s) => s.textContent === "当前:默认密码(admin)"))
const pwBox = $("#" + labelFor("登录密码"))
check("密码框是 password 类型", pwBox.type === "password")
await act(async () => { Simulate.change(pwBox, { target: { value: "newpass123" } }) })
await act(async () => { await new Promise((r) => setTimeout(r, 0)) })
check("输入新密码提示待保存", $$("span").some((s) => s.textContent === "新密码已记录,保存后生效"))
check("输入后显示自定义密码状态", $$("span").some((s) => s.textContent === "当前:自定义密码"))
await act(async () => { byText("button", "保存配置").click() })
await flush()
check("保存写入的是 SHA-256 而不是明文", calls.some((c) => c[0] === "set" && c[1] === "loginPasswordHash" && c[2] === sha256("newpass123")), JSON.stringify(calls.filter((c) => c[0] === "set" && c[1] === "loginPasswordHash")))
check("保存后密码框清空", pwBox.value === "")
check("卡片里没有「重置为默认密码」按钮", !$$("button").some((b) => b.textContent === "重置为默认密码"), $$("button").map((b) => b.textContent).join(" | "))
check("退出登录按钮存在", !!byText("button", "退出登录"))

// 只读
writable = false
await act(async () => { await controller.refresh() })
check("只读时显示提示", $$(".hf_readOnly").length === 1, text(".hf_readOnly"))
check("只读时保存按钮禁用", byText("button", "保存配置").disabled === true)

// 已读到过数据之后同步失败:保留上次的值,只标注原因
describeFails = true
writable = true
await act(async () => { await controller.refresh() })
check("同步失败仍保留上次读到的值", text(".hf_badge").includes("运行中"), text(".hf_badge"))
check("同步失败标出真实原因", $$(".hf_warn").some((e) => e.textContent.includes("settings unavailable")), $$(".hf_warn").map((e) => e.textContent).join(" | "))
check("失败原因已回传宿主日志", clientReports.some((p) => p.where === "settings.describe" && String(p.message).includes("settings unavailable")), JSON.stringify(clientReports))

// 从没读到过就失败 + 退避重试自愈(这条以前是永久"设置不可用")
describeFails = true
let Card2 = null
let injected2 = null
const ctx2 = Object.assign({}, ctx, { slots: { inject: (name, fn) => fn(), register: (spec, component) => { Card2 = component; injected2 = spec.inject() } } })
mod.apply(ctx2)
const controller2 = injected2.controller
await act(async () => { root.unmount() })
const host2 = document.createElement("div")
document.body.appendChild(host2)
const root2 = ReactDOM.createRoot(host2)
await act(async () => { root2.render(React.createElement(Card2, injected2)) })
await flush()
check("首读失败徽标=设置不可用", text(".hf_badge") === "设置不可用", text(".hf_badge"))
check("首读失败提示带原文", text(".hf_readOnly").includes("settings unavailable"), text(".hf_readOnly"))
describeFails = false
await act(async () => { await new Promise((r) => setTimeout(r, 1300)) })
check("退避重试后自愈", text(".hf_badge").includes("运行中"), text(".hf_badge"))
check("自愈后不可用提示消失", text(".hf_readOnly") === "<missing>" || !text(".hf_readOnly").includes("设置不可用"), text(".hf_readOnly"))
controller2.dispose()
controller.dispose()

console.log(results.map((r) => r[0].padEnd(5) + r[1] + (r[2] ? "   [" + r[2] + "]" : "")).join("\n"))
const failed = results.filter((r) => r[0] === "FAIL").length
console.log("\n" + (results.length - failed) + "/" + results.length + " 通过")
process.exit(failed === 0 ? 0 : 1)
