# Voice Enhancer Skill

> dsh-smart-input 插件的 Agent 技能指令

## 触发条件

当用户请求以下操作时，使用此技能：
- "帮我语音输入" / "语音说" / "用语音"
- "优化我的提示词" / "帮我改写" / "提示词优化"
- "enhance my prompt" / "voice input" / "语音输入"

## 工具使用

### 1. transcribe — 语音转写

将音频转写为文字。

**参数**：
- `audioSource` (string, 可选): `microphone` 或 `file`，默认 `microphone`
- `filePath` (string, 可选): 当 audioSource=file 时的音频文件路径
- `language` (string, 可选): 语言代码（zh/en/ja）
- `duration` (number, 可选): 最大录音时长（秒），默认 300

**示例**：
```
transcribe({ audioSource: "microphone", language: "zh", duration: 60 })
```

### 2. enhance_prompt — 提示词优化

优化用户输入的提示词。

**参数**：
- `prompt` (string, 必填): 原始提示词内容
- `strategy` (string, 可选): 优化策略
  - `auto` — 自动选择（默认）
  - `concise` — 简洁化
  - `detailed` — 详细化
  - `technical` — 技术化
  - `structured` — 结构化
  - `roleplay` — 角色扮演
- `contextFiles` (array, 可选): 相关工作区文件路径

**示例**：
```
enhance_prompt({
  prompt: "帮我写一个排序算法",
  strategy: "structured",
  contextFiles: ["src/main.py"]
})
```

## 使用指南

### 语音输入工作流

1. 确认用户麦克风可用
2. 调用 `transcribe` 工具开始录音
3. 将转写结果填入用户输入框
4. 询问用户是否确认发送或继续编辑

### 提示词优化工作流

1. 获取用户当前输入框中的文字
2. 自动检测优化策略（或按用户指定）
3. 调用 `enhance_prompt` 工具
4. 展示优化前后对比，让用户选择采纳或撤回

## 注意事项

- 语音输入依赖浏览器权限，首次使用需用户授权麦克风
- 本地 Whisper 模型需提前下载到指定目录
- Whisper API 模式需要有效的 OpenAI API Key
- 智能标点功能默认开启，可在设置中关闭
