/**
 * patch.tsx — DSH 插件补丁入口
 * 此文件由 DSH Cordis 内核加载，负责将插件 UI 注入到 Web 应用
 * 
 * 导出格式：default export 为一个 Patch 函数，接收 DSH 上下文，返回清理函数
 */
import React from 'react';
import { createRoot } from 'react-dom/client';
import { ComposerToolbar } from '../src/frontend/components/ComposerToolbar';
import { SettingsPanel } from '../src/frontend/components/SettingsPanel';

/**
 * 插件 Patch 函数 — DSH 调用此函数注入 UI
 * @param ctx DSH 提供的上下文（包含 settings、events 等）
 * @returns 清理函数（插件卸载时调用）
 */
export default function patch(ctx: {
  settings: Record<string, any>;
  events: {
    on(event: string, handler: (payload?: any) => void): void;
    emit(event: string, payload?: any): void;
  };
  updateSetting?: (key: string, value: any) => Promise<void>;
  dom: {
    composerToolbar: HTMLElement | null;
    settingsContainer: HTMLElement | null;
  };
}): () => void {
  const { settings, events, dom } = ctx;

  const cleanups: (() => void)[] = [];

  // —— 1. 注入 Composer 工具栏按钮 ——
  if (dom.composerToolbar) {
    const container = document.createElement('div');
    container.className = 'dsh-smart-input-composer-patch';
    dom.composerToolbar.appendChild(container);

    const root = createRoot(container);
    root.render(
      React.createElement(ComposerToolbar, {
        settings,
        onInsertText: (text: string) => {
          events.emit('smart-input:insert', { text });
        },
        onEnhanceResult: (result: any) => {
          events.emit('smart-input:enhance-complete', result);
        },
      })
    );

    cleanups.push(() => {
      root.unmount();
      container.remove();
    });
  }

  // —— 2. 注入设置面板 ——
  if (dom.settingsContainer) {
    const settingsPanel = document.createElement('div');
    settingsPanel.className = 'dsh-smart-input-settings-patch';
    dom.settingsContainer.appendChild(settingsPanel);

    const settingsRoot = createRoot(settingsPanel);
    settingsRoot.render(
      React.createElement(SettingsPanel, {
        settings,
        onSettingChange: (key: string, value: any) => {
          ctx.updateSetting?.(key, value);
        },
      })
    );

    cleanups.push(() => {
      settingsRoot.unmount();
      settingsPanel.remove();
    });
  }

  // —— 3. 注册快捷键 ——
  const handleKeyDown = (e: KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'V') {
      e.preventDefault();
      events.emit('smart-input:toggle-voice', {});
    }
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'E') {
      e.preventDefault();
      events.emit('smart-input:open-enhance', {});
    }
  };
  window.addEventListener('keydown', handleKeyDown);
  cleanups.push(() => window.removeEventListener('keydown', handleKeyDown));

  // —— 4. 监听事件 ——
  const handleVoiceToggle = () => {
    events.emit('smart-input:internal-toggle', {});
  };
  events.on('smart-input:toggle-voice', handleVoiceToggle);
  cleanups.push(() => events.off('smart-input:toggle-voice', handleVoiceToggle));

  // —— 返回清理函数 ——
  return () => {
    for (const cleanup of cleanups) {
      try { cleanup(); } catch {}
    }
  };
}
