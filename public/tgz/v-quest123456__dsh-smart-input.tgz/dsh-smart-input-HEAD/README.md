# dsm-smart-input

> 智能输入插件 for DeepSeek Harness — 语音输入 + 提示词优化

[![DSH Plugin](https://img.shields.io/badge/DSH-Plugin-blue)](https://github.com/deepseek-ai/deepseek-harness)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

## ✨ 功能

### 🎤 语音输入

在 DSH 输入框一键语音输入，支持三种识别引擎：

| 引擎 | 特点 | 适用场景 |
|------|------|----------|
| **浏览器 Web Speech API** | 零依赖、即时可用 | 日常使用，中文识别 |
| **本地 Whisper ONNX** | 完全离线、隐私安全 | 无网络环境、高准确率需求 |
| **Whisper API（在线）** | 最高准确率、多语言 | 专业场景、多语言混合 |

- 实时流式转写，边说边出字
- 智能标点自动添加
- 支持中文、英文、日文
- 连续对话模式（发送后自动续听）
- 快捷键 `Ctrl/Cmd + Shift + V`

### ✨ 提示词优化

一键优化输入框中的提示词，支持 6 种策略：

| 策略 | 说明 |
|------|------|
| 🔄 自动 | 根据内容自动选择最佳策略 |
| ✂️ 简洁化 | 去除冗余，精炼表达 |
| 📝 详细化 | 补充上下文和约束条件 |
| ⚙️ 技术化 | 使用精确的技术术语 |
| 📋 结构化 | 目标-约束-输出格式 |
| 🎭 角色扮演 | 添加角色设定增强代入感 |

- 上下文感知：可注入工作区文件信息
- 优化前后对比预览
- 一键采纳或撤回
- 快捷键 `Ctrl/Cmd + Shift + E`

## 📦 安装

```sh
# 通过 dsh CLI 安装（推荐）
dsh plugin --profile web add dsh-smart-input

# 或手动安装
git clone https://github.com/your-repo/dsh-smart-input.git ~/.dsh/plugins/dsh-smart-input
dsh plugin --profile web link ~/.dsh/plugins/dsh-smart-input
```

## ⚙️ 配置

安装后在 **设置 → 智能输入** 中配置：

### 语音输入设置

| 配置项 | 默认值 | 说明 |
|--------|--------|------|
| 识别模式 | `auto` | 自动选择 / 浏览器 / 本地 Whisper / Whisper API |
| 本地模型 | `whisper-small` | 模型大小（影响速度 vs 准确率） |
| 模型路径 | `D:\subbatch-local-v2.0.0\models` | 本地模型文件目录 |
| 识别语言 | `zh` | 默认语音识别语言 |
| 智能标点 | `true` | 自动添加标点符号 |
| 自动发送 | `false` | 识别完成后自动发送 |
| 连续对话 | `false` | 发送后自动进入录音模式 |

### 提示词优化设置

| 配置项 | 默认值 | 说明 |
|--------|--------|------|
| 优化模型 | 留空 | 留空复用当前会话模型 |
| 默认策略 | `auto` | 自动选择优化策略 |
| 上下文感知 | `true` | 注入工作区上下文 |

## 🚀 使用

### 语音输入

1. 点击输入框工具栏的 🎤 按钮
2. 开始说话，文字实时出现在输入框
3. 再次点击停止录音
4. 确认文字后发送

### 提示词优化

1. 在输入框中输入你的提示词草稿
2. 点击工具栏的 ✨ 按钮
3. 选择优化策略（或保持自动）
4. 点击"开始优化"
5. 对比预览后选择采纳或重新生成

## 🛠️ 本地模型准备

### 方案一：使用现有模型（推荐）

如果你已有 `subbatch-local-v2.0.0` 中的模型：

1. 在设置中设置 **模型路径** 为 `D:\subbatch-local-v2.0.0\models`
2. 选择模型：`whisper-small` 或 `whisper-large-v3-turbo`

### 方案二：下载新模型

```sh
# 下载 Whisper Small（~466MB）
npx @xenova/convert --model openai/whisper-small --output ./models/whisper-small

# 下载 Whisper Large V3 Turbo（~1.5GB）
npx @xenova/convert --model openai/whisper-large-v3-turbo --output ./models/whisper-large-v3-turbo
```

## 📋 快捷键

| 快捷键 | 功能 |
|--------|------|
| `Ctrl/Cmd + Shift + V` | 开始/停止语音输入 |
| `Ctrl/Cmd + Shift + E` | 打开提示词优化面板 |

快捷键可在设置中自定义。

## 🔧 开发

```sh
# 克隆项目
git clone https://github.com/your-repo/dsh-smart-input.git
cd dsh-smart-input

# 安装依赖
npm install

# 开发模式（热重载）
npm run dev

# 构建
npm run build
```

## 📄 项目结构

```
dsh-smart-input/
├── dsh.bundle              # 插件 manifest（DSH 识别文件）
├── package.json            # npm 包定义
├── tsconfig.json           # TypeScript 配置
├── src/
│   ├── backend/
│   │   ├── index.ts        # 后端入口（工具注册）
│   │   └── types.ts        # 类型定义
│   ├── frontend/
│   │   ├── index.tsx       # 前端入口（UI 注册）
│   │   └── components/
│   │       ├── VoiceInputButton.tsx    # 语音输入按钮
│   │       ├── PromptEnhanceButton.tsx # 提示词优化按钮
│   │       └── SettingsPanel.tsx       # 设置面板
│   └── services/
│       ├── asr-service.ts      # 语音识别服务
│       └── enhance-service.ts  # 提示词优化服务
├── skills/
│   └── voice-enhancer/
│       └── SKILL.md        # Agent 技能指令
├── public/
│   └── models/             # 本地模型文件目录
└── README.md
```

## 🤝 贡献

欢迎提交 Issue 和 PR！

## 📜 协议

[MIT](LICENSE)

## 🙏 致谢

- [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) — 插件框架
- [@xenova/transformers](https://github.com/xenova/transformers.js) — 浏览器端 ONNX 推理
- [ONNX Runtime Web](https://github.com/microsoft/onnxruntime) — ONNX 运行时
