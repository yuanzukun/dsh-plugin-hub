/**
 * dsh-smart-input — Client Bundle (v2)
 * Loaded by DSH Web UI via window.__ModuleLoader__.load()
 *
 * UI model (Qoder-style, per user request):
 * - Voice input and prompt enhancement are small flat line-style icons
 *   registered into the official `conversation.input.model` slot, so they sit
 *   next to the model selector in the composer toolbar.
 * - No floating popups: the live speech transcript is written straight into
 *   the composer textarea, and the enhanced prompt replaces the textarea
 *   content in place.
 */
window.__ModuleLoader__.load({ id: "dsh-smart-input", factory: (require) => {
  // Client-module convention: the factory must deliver an exports object
  // carrying `apply` — the cordis client runner applies it as a plugin.
  var module = { exports: {} };
  var exports = module.exports;
  Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
  var React = require("react");

  var useState = React.useState;
  var useEffect = React.useEffect;
  var useCallback = React.useCallback;
  var useRef = React.useRef;

  function pluginSettings() {
    return (window.__DSH_SETTINGS__ && window.__DSH_SETTINGS__["dsh-smart-input"]) || {};
  }

  // ═══════════════════════════════════════════════════════════════
  // Flat line-style icons (stroke = currentColor, matches shell UI)
  // ═══════════════════════════════════════════════════════════════
  var svgProps = {
    width: 15, height: 15, viewBox: "0 0 24 24", fill: "none",
    stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round", strokeLinejoin: "round"
  };
  function MicIcon() {
    return React.createElement("svg", svgProps,
      React.createElement("rect", { x: 9, y: 2.5, width: 6, height: 11.5, rx: 3 }),
      React.createElement("path", { d: "M19 11a7 7 0 0 1-14 0" }),
      React.createElement("line", { x1: 12, y1: 18, x2: 12, y2: 21.5 })
    );
  }
  function StopIcon() {
    return React.createElement("svg", svgProps,
      React.createElement("rect", { x: 6.5, y: 6.5, width: 11, height: 11, rx: 2, fill: "currentColor", stroke: "none" })
    );
  }
  function SparkIcon() {
    return React.createElement("svg", svgProps,
      React.createElement("path", { d: "M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z" }),
      React.createElement("path", { d: "M18.5 15.5l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8z" })
    );
  }
  function SpinnerIcon() {
    return React.createElement("svg", Object.assign({}, svgProps, { className: "dsh-si-spin" }),
      React.createElement("path", { d: "M12 3a9 9 0 1 0 9 9" })
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // Composer textarea helpers — all text lands directly in the input box
  // ═══════════════════════════════════════════════════════════════
  function getComposerTextarea() {
    return document.querySelector("textarea");
  }
  function setTextarea(ta, value) {
    if (!ta) return;
    var proto = ta.tagName === "TEXTAREA" ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    var desc = Object.getOwnPropertyDescriptor(proto, "value");
    if (desc && desc.set) desc.set.call(ta, value);
    else ta.value = value;
    ta.dispatchEvent(new Event("input", { bubbles: true }));
  }
  /** 在光标处插入文本，并返回插入后的光标位置 */
  function insertAtCursor(ta, text) {
    if (!ta) return 0;
    var start = ta.selectionStart || 0;
    var end = ta.selectionEnd || 0;
    var before = ta.value.substring(0, start);
    var after = ta.value.substring(end);
    // 确保插入前有一个空格分隔（如果前面不是空白或空字符串）
    var sep = (before.length > 0 && !/\s$/.test(before)) ? " " : "";
    var newVal = before + sep + text + after;
    setTextarea(ta, newVal);
    var newCursor = start + sep.length + text.length;
    ta.setSelectionRange(newCursor, newCursor);
    return newCursor;
  }

  // ═══════════════════════════════════════════════════════════════
  // ASR helpers (browser recognition + optional Whisper backends)
  // ═══════════════════════════════════════════════════════════════
  function mapLang(lang) {
    var m = { "zh": "zh-CN", "en": "en-US", "ja": "ja-JP" };
    return m[lang] || lang || "zh-CN";
  }
  function getSupportedMimeType() {
    var types = ["audio/webm;codecs=opus", "audio/webm", "audio/ogg;codecs=opus"];
    for (var i = 0; i < types.length; i++) {
      if (MediaRecorder.isTypeSupported(types[i])) return types[i];
    }
    return "audio/webm";
  }
  // Send the recording to the host endpoint, which runs the intended ASR
  // ladder server-side: LOCAL Whisper first, Whisper API as the fallback.
  // (A browser page cannot touch the local model files, so the node half
  // owns transcription; API keys stay on the host, never in the page.)
  function transcribeViaHost(blob, settings) {
    var mode = settings.asrMode || "auto";
    var hostMode = mode === "local-whisper" ? "local" : mode === "whisper-api" ? "api" : "auto";
    var params = new URLSearchParams({ mode: hostMode });
    if (settings.language) params.set("language", settings.language);
    if (settings.localModel) params.set("model", settings.localModel);
    return fetch("/api/smart-input/transcribe?" + params.toString(), {
      method: "POST",
      body: blob
    }).then(function (resp) { return resp.json(); }).then(function (data) {
      if (!data || !data.ok) throw new Error((data && data.error) || "transcribe failed");
      return data;
    });
  }

  // ═══════════════════════════════════════════════════════════════
  // VoiceIconButton — mic icon; transcript streams into the textarea
  // 修复点：
  //   1. 提前启动 SpeechRecognition → 解决开头丢字
  //   2. 使用 selectionStart/selectionEnd → 在光标位置插入
  //   3. 只替换本次录音的文本段 → 不覆盖其他内容
  // ═══════════════════════════════════════════════════════════════
  function VoiceIconButton() {
    var _s = useState("idle"); // idle | recording | processing | error
    var status = _s[0];
    var setStatus = _s[1];

    var recognitionRef = useRef(null);
    var recorderRef = useRef(null);
    var chunksRef = useRef([]);
    var timerRef = useRef(null);
    var statusRef = useRef("idle");
    statusRef.current = status;
    // 录音文本在 textarea 中的位置范围（用于精确定位替换）
    var recordRangeRef = useRef({ start: 0, end: 0 });
    var finalizedRef = useRef("");   // accumulated final transcripts

    /**
     * 将转写文本写入 textarea 的光标位置。
     * 只在 recordRangeRef 标记的范围内替换，不影响其他区域。
     */
    function writeLiveText(interim) {
      var ta = getComposerTextarea();
      if (!ta) return;
      var range = recordRangeRef.current;
      var full = ta.value;
      var before = full.substring(0, range.start);
      var after = full.substring(range.end);
      var sep = (before.length > 0 && !/\s$/.test(before)) ? " " : "";
      var newText = finalizedRef.current + interim;
      var newVal = before + sep + newText + after;
      // 用 native setter 触发 React onChange
      var proto = window.HTMLTextAreaElement.prototype;
      var desc = Object.getOwnPropertyDescriptor(proto, "value");
      if (desc && desc.set) desc.set.call(ta, newVal);
      else ta.value = newVal;
      ta.dispatchEvent(new Event("input", { bubbles: true }));
      // 更新 range.end 以反映当前文本长度
      range.end = range.start + sep.length + newText.length;
      // 光标移到插入文本末尾
      ta.setSelectionRange(range.end, range.end);
    }

    function stopRecognition() {
      var rec = recognitionRef.current;
      if (rec) {
        try { rec.stop(); } catch (e) {}
        recognitionRef.current = null;
      }
    }

    function startRecognition(settings) {
      var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SpeechRecognition) return;
      var rec = new SpeechRecognition();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = mapLang(settings.language);
      rec.onresult = function (event) {
        var finalized = "";
        var interim = "";
        for (var i = 0; i < event.results.length; i++) {
          var t = event.results[i][0].transcript;
          if (event.results[i].isFinal) finalized += t;
          else interim += t;
        }
        finalizedRef.current = finalized;
        writeLiveText(interim);
      };
      rec.onerror = function () {};
      rec.onend = function () {
        if (statusRef.current === "recording") {
          try { rec.start(); } catch (e) {}
        }
      };
      recognitionRef.current = rec;
      try { rec.start(); } catch (e) {}
    }

    function processAudio(blob, settings) {
      var mode = settings.asrMode || "auto";
      // Pure browser mode: the live recognition text is already final.
      if (mode === "browser") { setStatus("idle"); return; }
      setStatus("processing");
      transcribeViaHost(blob, settings).then(function (result) {
        var text = result.text || "";
        var ta = getComposerTextarea();
        if (ta && text) {
          // Whisper 结果只替换 recordRangeRef 标记的范围
          var range = recordRangeRef.current;
          var full = ta.value;
          var before = full.substring(0, range.start);
          var after = full.substring(range.end);
          var sep = (before.length > 0 && !/\s$/.test(before)) ? " " : "";
          var newVal = before + sep + text + after;
          setTextarea(ta, newVal);
          range.end = range.start + sep.length + text.length;
        }
      }).catch(function (err) {
        console.warn("[dsh-smart-input] ASR ladder failed, keeping browser preview:", err && err.message);
      }).then(function () { setStatus("idle"); });
    }

    function start() {
      if (statusRef.current === "recording") return;
      var settings = pluginSettings();
      var ta = getComposerTextarea();
      if (!ta) return;

      // 记录当前光标位置 → 录音文本从这里开始插入
      var cursorPos = ta.selectionStart || 0;
      recordRangeRef.current = { start: cursorPos, end: cursorPos };
      finalizedRef.current = "";
      chunksRef.current = [];
      setStatus("recording");

      // ★ 修复1：提前启动浏览器语音识别（不等待 getUserMedia）
      // SpeechRecognition 不依赖 getUserMedia 权限，可以立即启动
      var mode = settings.asrMode || "auto";
      if (mode !== "local-whisper" && mode !== "whisper-api") {
        startRecognition(settings);
      }

      // 同时获取麦克风权限（用于 Whisper 模式的录音文件）
      navigator.mediaDevices.getUserMedia({
        audio: { channelCount: 1, sampleRate: 16000, echoCancellation: true, noiseSuppression: true }
      }).then(function (stream) {
        var recorder = new MediaRecorder(stream, { mimeType: getSupportedMimeType() });
        recorderRef.current = recorder;
        recorder.ondataavailable = function (e) { if (e.data.size > 0) chunksRef.current.push(e.data); };
        recorder.onstop = function () {
          stream.getTracks().forEach(function (t) { t.stop(); });
          processAudio(new Blob(chunksRef.current, { type: recorder.mimeType }), settings);
        };
        recorder.start(200);
        var t0 = Date.now();
        timerRef.current = setInterval(function () {
          if (Date.now() - t0 > 300000) stop();
        }, 1000);
      }).catch(function () {
        // getUserMedia 失败时，如果浏览器识别已在运行，不报错
        if (!recognitionRef.current) {
          setStatus("error");
          setTimeout(function () { setStatus("idle"); }, 2500);
        }
      });
    }

    function stop() {
      if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
      stopRecognition();
      var recorder = recorderRef.current;
      if (recorder && recorder.state !== "inactive") recorder.stop();
      else setStatus("idle");
      // 最终整理：确保 recordRangeRef 内的文本整洁
      var ta = getComposerTextarea();
      if (ta && finalizedRef.current) {
        var range = recordRangeRef.current;
        var full = ta.value;
        var before = full.substring(0, range.start);
        var after = full.substring(range.end);
        var sep = (before.length > 0 && !/\s$/.test(before)) ? " " : "";
        var cleanText = finalizedRef.current.replace(/\s+$/, "");
        setTextarea(ta, before + sep + cleanText + after);
        range.end = range.start + sep.length + cleanText.length;
      }
    }

    function handleClick() {
      if (statusRef.current === "recording") stop();
      else start();
    }

    useEffect(function () { return function () {
      if (timerRef.current) clearInterval(timerRef.current);
      stopRecognition();
    }; }, []);

    var state = status === "recording" ? "recording" : status === "processing" ? "processing" : "idle";
    var title = status === "recording" ? "停止录音 (Ctrl+Shift+V)"
      : status === "processing" ? "语音转写中…"
      : status === "error" ? "录音启动失败，请检查麦克风权限"
      : "语音输入 (Ctrl+Shift+V)";
    var icon = status === "recording" ? React.createElement(StopIcon)
      : status === "processing" ? React.createElement(SpinnerIcon)
      : React.createElement(MicIcon);

    return React.createElement("button", {
      className: "dsh-si-iconbtn dsh-si-voice",
      "data-state": state,
      onClick: handleClick,
      title: title,
      type: "button"
    }, icon);
  }

  // ═══════════════════════════════════════════════════════════════
  // EnhanceIconButton — spark icon; result replaces textarea content
  // ═══════════════════════════════════════════════════════════════
  function getSystemPrompt(strategy) {
    var prompts = {
      concise: "精简提示词专家。去除冗余，保留核心意图，用词精准。只输出优化后的提示词，不要解释。",
      detailed: "提示词扩展专家。补充上下文、明确目标与约束，消除歧义。只输出优化后的提示词，不要解释。",
      technical: "技术写作专家。使用精确术语，明确技术栈与约束（性能、安全、兼容性）。只输出优化后的提示词，不要解释。",
      structured: "任务分解专家。按格式重构：目标、背景、约束、输出、示例（可选）。只输出优化后的提示词，不要解释。",
      roleplay: "角色设计专家。添加明确角色身份与专业背景，保持原意，自然融入。只输出优化后的提示词，不要解释。"
    };
    return prompts[strategy] || prompts.detailed;
  }
  function autoSelectStrategy(text) {
    var lower = text.toLowerCase();
    if (text.length > 200) return "concise";
    if (text.length < 20) return "detailed";
    if (/代码|函数|class|function|api|数据库/.test(lower)) return "structured";
    return "detailed";
  }
  function fallbackEnhance(text, strategy) {
    switch (strategy) {
      case "concise": return text.replace(/\s+/g, " ").trim();
      case "detailed": return text + "\n\n请提供详细的实现方案，包含必要的代码示例和说明。";
      case "structured": return "目标：" + text + "\n\n要求：\n- 提供清晰的实现步骤\n- 包含代码示例\n- 说明关键决策点";
      case "technical": return text + "\n\n请使用最佳实践，确保代码质量和可维护性。";
      case "roleplay": return "作为一位资深开发专家，" + text;
      default: return text;
    }
  }

  function EnhanceIconButton() {
    var _p = useState(false);
    var isProcessing = _p[0];
    var setIsProcessing = _p[1];

    var handleEnhance = useCallback(function () {
      if (isProcessing) return;
      var ta = getComposerTextarea();
      if (!ta) return;
      var text = ta.value.trim();
      if (!text) {
        ta.focus();
        ta.setAttribute("placeholder", "先输入要优化的提示词…");
        return;
      }
      var settings = pluginSettings();
      var strategy = (settings.enhanceStrategy && settings.enhanceStrategy !== "auto")
        ? settings.enhanceStrategy : autoSelectStrategy(text);
      setIsProcessing(true);
      fetch("/api/smart-input/enhance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: text, strategy: strategy, contextAware: settings.enhanceContextAware !== false })
      }).then(function (resp) { return resp.json(); }).then(function (data) {
        var enhanced = data && (data.enhanced || (data.data && data.data.enhanced));
        if (enhanced) setTextarea(ta, enhanced);
        else setTextarea(ta, fallbackEnhance(text, strategy));
      }).catch(function () {
        setTextarea(ta, fallbackEnhance(text, strategy));
      }).then(function () {
        setIsProcessing(false);
      });
    }, [isProcessing]);

    return React.createElement("button", {
      className: "dsh-si-iconbtn dsh-si-enhance",
      "data-state": isProcessing ? "processing" : "idle",
      onClick: handleEnhance,
      title: isProcessing ? "正在优化提示词…" : "优化提示词 (Ctrl+Shift+E)",
      type: "button"
    }, isProcessing ? React.createElement(SpinnerIcon) : React.createElement(SparkIcon));
  }

  // ═══════════════════════════════════════════════════════════════
  // Slot component — both icons, plus keyboard shortcuts
  // ═══════════════════════════════════════════════════════════════
  function ComposerIcons() {
    useEffect(function () {
      function handleKeyDown(e) {
        if (!(e.ctrlKey || e.metaKey) || !e.shiftKey) return;
        var key = (e.key || "").toUpperCase();
        if (key === "V") {
          var v = document.querySelector(".dsh-si-voice");
          if (v) { e.preventDefault(); v.click(); }
        } else if (key === "E") {
          var h = document.querySelector(".dsh-si-enhance");
          if (h) { e.preventDefault(); h.click(); }
        }
      }
      window.addEventListener("keydown", handleKeyDown);
      return function () { window.removeEventListener("keydown", handleKeyDown); };
    }, []);

    return React.createElement("div", { className: "dsh-si-icons" },
      React.createElement(VoiceIconButton),
      React.createElement(EnhanceIconButton)
    );
  }

  // Inject CSS (flat icon buttons consistent with the shell toolbar)
  var style = document.createElement("style");
  style.textContent = [
    "@keyframes dsh-pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.55; } }",
    "@keyframes dsh-spin { to { transform: rotate(360deg); } }",
    ".dsh-si-icons { display: inline-flex; align-items: center; gap: 2px; }",
    ".dsh-si-iconbtn { width: 26px; height: 26px; display: inline-flex; align-items: center; justify-content: center;",
    "  border: none; background: transparent; border-radius: 6px; padding: 0;",
    "  color: var(--dsw-alias-label-secondary, #666); cursor: pointer;",
    "  transition: background .15s ease, color .15s ease; }",
    ".dsh-si-iconbtn:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(127,127,127,.14));",
    "  color: var(--dsw-alias-label-primary, #111); }",
    ".dsh-si-iconbtn[data-state=\"recording\"] { color: #FF4444; animation: dsh-pulse 1.5s infinite; }",
    ".dsh-si-iconbtn[data-state=\"processing\"] { color: var(--dsw-alias-state-business-primary, #4D6BFE); }",
    ".dsh-si-spin { animation: dsh-spin 1s linear infinite; }"
  ].join("\n");
  document.head.appendChild(style);

  // Plugin shape for the cordis client runner.
  var name = "dsh-smart-input";
  var inject = ["slots"];
  function apply(ctx) {
    // Park the registration until the composer renders. `conversation.input.right`
    // is a list slot rendered as the composer bar's rightItems — the icons
    // land next to the model selector. (`conversation.input.model` is a
    // single slot owned by the model picker and rejects second registrations.)
    ctx.slots.inject("conversation.input.right", function () {
      return ctx.slots.register({
        name: "conversation.input.right",
        id: "smart-input-icons",
        order: 1
      }, ComposerIcons);
    });
  }
  exports.name = name;
  exports.inject = inject;
  exports.apply = apply;
  return module.exports;
}});
