/**
 * PromptEnhanceButton — 提示词优化按钮组件
 * 点击展开优化面板，展示策略选择和优化结果对比
 */
import React, { useState, useCallback } from 'react';

interface PromptEnhanceButtonProps {
  settings: Record<string, any>;
  onEnhance: (result: EnhanceResult) => void;
  onError: (error: Error) => void;
}

interface EnhanceResult {
  original: string;
  enhanced: string;
  strategy: string;
  changes: string[];
}

interface Strategy {
  id: string;
  name: string;
  nameEn: string;
  description: string;
  icon: string;
}

const STRATEGIES: Strategy[] = [
  { id: 'auto', name: '自动', nameEn: 'Auto', description: '智能选择最佳策略', icon: '🔄' },
  { id: 'concise', name: '简洁化', nameEn: 'Concise', description: '去除冗余，精炼表达', icon: '✂️' },
  { id: 'detailed', name: '详细化', nameEn: 'Detailed', description: '补充上下文和约束', icon: '📝' },
  { id: 'technical', name: '技术化', nameEn: 'Technical', description: '使用精确技术术语', icon: '⚙️' },
  { id: 'structured', name: '结构化', nameEn: 'Structured', description: '目标-约束-输出格式', icon: '📋' },
  { id: 'roleplay', name: '角色扮演', nameEn: 'Role Play', description: '添加角色设定', icon: '🎭' },
];

export const PromptEnhanceButton: React.FC<PromptEnhanceButtonProps> = ({
  settings,
  onEnhance,
  onError,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedStrategy, setSelectedStrategy] = useState(settings.enhanceStrategy || 'auto');
  const [currentInput, setCurrentInput] = useState('');
  const [result, setResult] = useState<EnhanceResult | null>(null);

  // —— 执行优化 ——
  const handleEnhance = useCallback(async () => {
    if (!currentInput.trim()) {
      onError(new Error('请先输入需要优化的提示词'));
      return;
    }

    setIsProcessing(true);
    setResult(null);

    try {
      // 调用后端 LLM 服务
      const response = await fetch('/api/smart-input/enhance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: currentInput,
          strategy: selectedStrategy,
          contextAware: settings.enhanceContextAware ?? true,
        }),
      });

      if (!response.ok) {
        throw new Error(`优化失败: ${response.status}`);
      }

      const data: EnhanceResult = await response.json();
      setResult(data);
    } catch (err) {
      // 降级：使用纯前端优化（简单的文本处理）
      const fallback = performFallbackEnhance(currentInput, selectedStrategy);
      setResult(fallback);
    } finally {
      setIsProcessing(false);
    }
  }, [currentInput, selectedStrategy, settings, onError]);

  // —— 采纳优化结果 ——
  const handleAccept = useCallback(() => {
    if (result) {
      onEnhance(result);
      setIsOpen(false);
      setResult(null);
      setCurrentInput('');
    }
  }, [result, onEnhance]);

  // —— 关闭面板 ——
  const handleClose = useCallback(() => {
    setIsOpen(false);
    setResult(null);
  }, []);

  return (
    <>
      <button
        className="dsh-enhance-btn"
        onClick={() => setIsOpen(!isOpen)}
        title={`优化提示词 (${settings.hotkeyEnhance || 'Ctrl+Shift+E'})`}
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '4px',
          padding: '4px 10px',
          border: '1px solid #10B981',
          borderRadius: '6px',
          backgroundColor: isOpen ? '#10B98120' : 'transparent',
          color: '#10B981',
          cursor: 'pointer',
          fontSize: '13px',
          transition: 'all 0.2s',
        }}
      >
        <span style={{ fontSize: '14px' }}>✨</span>
        <span>优化</span>
      </button>

      {/* —— 优化面板弹窗 —— */}
      {isOpen && (
        <div style={{
          position: 'absolute',
          bottom: '100%',
          right: 0,
          marginBottom: '8px',
          width: '480px',
          backgroundColor: 'var(--bg-elevated, #fff)',
          border: '1px solid var(--border-color, #e5e7eb)',
          borderRadius: '12px',
          boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
          zIndex: 1001,
          overflow: 'hidden',
        }}>
          {/* 标题栏 */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '12px 16px',
            borderBottom: '1px solid var(--border-color, #e5e7eb)',
            backgroundColor: 'var(--bg-secondary, #f9fafb)',
          }}>
            <span style={{ fontWeight: 600, fontSize: '14px', color: 'var(--text-primary, #111)' }}>
              ✨ 提示词优化
            </span>
            <button
              onClick={handleClose}
              style={{
                border: 'none', background: 'none', cursor: 'pointer',
                fontSize: '18px', color: 'var(--text-secondary, #999)', padding: '0 4px',
              }}
            >×</button>
          </div>

          {/* 策略选择 */}
          <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-color, #e5e7eb)' }}>
            <div style={{ fontSize: '12px', color: 'var(--text-secondary, #666)', marginBottom: '8px' }}>优化策略</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
              {STRATEGIES.map(s => (
                <button
                  key={s.id}
                  onClick={() => setSelectedStrategy(s.id)}
                  title={s.description}
                  style={{
                    padding: '4px 10px',
                    border: `1px solid ${selectedStrategy === s.id ? '#10B981' : 'var(--border-color, #ddd)'}`,
                    borderRadius: '16px',
                    backgroundColor: selectedStrategy === s.id ? '#10B98115' : 'transparent',
                    color: selectedStrategy === s.id ? '#10B981' : 'var(--text-secondary, #666)',
                    cursor: 'pointer',
                    fontSize: '12px',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '4px',
                    transition: 'all 0.15s',
                  }}
                >
                  <span>{s.icon}</span>
                  <span>{s.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 输入区 */}
          <div style={{ padding: '12px 16px' }}>
            <div style={{ fontSize: '12px', color: 'var(--text-secondary, #666)', marginBottom: '6px' }}>输入提示词</div>
            <textarea
              value={currentInput}
              onChange={(e) => setCurrentInput(e.target.value)}
              placeholder="在这里输入你想要优化的提示词..."
              style={{
                width: '100%',
                minHeight: '60px',
                padding: '8px 10px',
                border: '1px solid var(--border-color, #ddd)',
                borderRadius: '6px',
                fontSize: '13px',
                resize: 'vertical',
                fontFamily: 'inherit',
                lineHeight: '1.5',
                boxSizing: 'border-box',
              }}
            />
          </div>

          {/* 优化按钮 */}
          <div style={{ padding: '0 16px 12px', display: 'flex', gap: '8px' }}>
            <button
              onClick={handleEnhance}
              disabled={isProcessing || !currentInput.trim()}
              style={{
                flex: 1,
                padding: '8px 16px',
                border: 'none',
                borderRadius: '6px',
                backgroundColor: isProcessing ? '#9CA3AF' : '#10B981',
                color: '#fff',
                cursor: isProcessing ? 'not-allowed' : 'pointer',
                fontSize: '13px',
                fontWeight: 500,
                transition: 'background-color 0.15s',
              }}
            >
              {isProcessing ? '⏳ 优化中...' : '🚀 开始优化'}
            </button>
          </div>

          {/* 优化结果 */}
          {result && (
            <div style={{
              borderTop: '1px solid var(--border-color, #e5e7eb)',
              backgroundColor: 'var(--bg-secondary, #f9fafb)',
            }}>
              {/* 对比展示 */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0' }}>
                {/* 原文 */}
                <div style={{ padding: '12px 16px', borderRight: '1px solid var(--border-color, #e5e7eb)' }}>
                  <div style={{ fontSize: '11px', color: '#EF4444', marginBottom: '6px', fontWeight: 600 }}>原文</div>
                  <div style={{ fontSize: '13px', color: 'var(--text-primary, #333)', whiteSpace: 'pre-wrap', lineHeight: '1.6' }}>
                    {result.original}
                  </div>
                </div>
                {/* 优化后 */}
                <div style={{ padding: '12px 16px' }}>
                  <div style={{ fontSize: '11px', color: '#10B981', marginBottom: '6px', fontWeight: 600 }}>
                    优化后
                    {result.changes.length > 0 && (
                      <span style={{ fontWeight: 400, marginLeft: 8, color: 'var(--text-secondary, #999)' }}>
                        ({result.changes.join(', ')})
                      </span>
                    )}
                  </div>
                  <div style={{ fontSize: '13px', color: 'var(--text-primary, #333)', whiteSpace: 'pre-wrap', lineHeight: '1.6' }}>
                    {result.enhanced}
                  </div>
                </div>
              </div>

              {/* 操作按钮 */}
              <div style={{
                display: 'flex',
                gap: '8px',
                padding: '10px 16px',
                borderTop: '1px solid var(--border-color, #e5e7eb)',
                backgroundColor: 'var(--bg-elevated, #fff)',
              }}>
                <button
                  onClick={handleAccept}
                  style={{
                    flex: 1,
                    padding: '7px 14px',
                    border: 'none',
                    borderRadius: '6px',
                    backgroundColor: '#10B981',
                    color: '#fff',
                    cursor: 'pointer',
                    fontSize: '13px',
                    fontWeight: 500,
                  }}
                >
                  ✅ 采纳优化结果
                </button>
                <button
                  onClick={() => { setResult(null); }}
                  style={{
                    padding: '7px 14px',
                    border: '1px solid var(--border-color, #ddd)',
                    borderRadius: '6px',
                    backgroundColor: 'transparent',
                    color: 'var(--text-secondary, #666)',
                    cursor: 'pointer',
                    fontSize: '13px',
                  }}
                >
                  重新生成
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </>
  );
};

// ============ 降级优化（纯前端） ——

function performFallbackEnhance(text: string, strategy: string): EnhanceResult {
  let enhanced = text;
  const changes: string[] = [];

  switch (strategy) {
    case 'concise':
      enhanced = text.replace(/\s+/g, ' ').trim();
      if (enhanced.length < text.length) changes.push('精简了表达');
      break;
    case 'detailed':
      enhanced = `${text}\n\n请提供详细的实现方案，包含必要的代码示例和说明。`;
      changes.push('补充了详细要求');
      break;
    case 'structured':
      enhanced = `目标：${text}\n\n要求：\n- 提供清晰的实现步骤\n- 包含代码示例\n- 说明关键决策点`;
      changes.push('重构为结构化格式');
      break;
    case 'technical':
      enhanced = text + '\n\n请使用最佳实践，确保代码质量和可维护性。';
      changes.push('添加了技术规范');
      break;
    case 'roleplay':
      enhanced = `作为一位资深开发专家，${text}`;
      changes.push('添加了角色设定');
      break;
    default:
      enhanced = text;
      changes.push('已优化');
  }

  return {
    original: text,
    enhanced,
    strategy,
    changes,
  };
}
