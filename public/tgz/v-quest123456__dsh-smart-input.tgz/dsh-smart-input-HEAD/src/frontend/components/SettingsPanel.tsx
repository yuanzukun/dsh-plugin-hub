/**
 * SettingsPanel — 插件设置面板
 * 在 DSH 设置页面中渲染
 */
import React, { useState } from 'react';

interface SettingsPanelProps {
  settings: Record<string, any>;
  onSettingChange: (key: string, value: any) => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({ settings, onSettingChange }) => {
  const [modelPath, setModelPath] = useState(settings.modelPath || '');

  return (
    <div style={{ padding: '20px', maxWidth: '600px' }}>
      <h2 style={{ fontSize: '18px', fontWeight: 600, marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
        <span>🎤</span> 智能输入设置
      </h2>

      {/* —— 语音识别设置 —— */}
      <section style={{ marginBottom: '24px' }}>
        <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-secondary, #666)', marginBottom: '12px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
          语音识别 (ASR)
        </h3>

        {/* ASR 模式 */}
        <SettingRow label="识别模式" description="选择语音识别引擎">
          <select
            value={settings.asrMode || 'auto'}
            onChange={(e) => onSettingChange('asrMode', e.target.value)}
            style={selectStyle}
          >
            <option value="auto">🔄 自动选择（推荐）</option>
            <option value="browser">🌐 浏览器 Web Speech API</option>
            <option value="local-whisper">💻 本地 Whisper ONNX</option>
            <option value="whisper-api">☁️ Whisper API（在线）</option>
          </select>
        </SettingRow>

        {/* 本地模型选择 */}
        {(settings.asrMode === 'local-whisper' || settings.asrMode === 'auto') && (
          <>
            <SettingRow label="本地模型" description="模型越大准确率越高，但速度越慢">
              <select
                value={settings.localModel || 'whisper-small'}
                onChange={(e) => onSettingChange('localModel', e.target.value)}
                style={selectStyle}
              >
                <option value="whisper-small">Whisper Small（快速，~466MB）</option>
                <option value="whisper-large-v3-turbo">Whisper Large V3 Turbo（准确，~1.5GB）</option>
              </select>
            </SettingRow>

            <SettingRow label="模型路径" description="本地 Whisper 模型文件所在目录">
              <div style={{ display: 'flex', gap: '8px' }}>
                <input
                  type="text"
                  value={modelPath}
                  onChange={(e) => setModelPath(e.target.value)}
                  onBlur={() => onSettingChange('modelPath', modelPath)}
                  placeholder="~/.dsh/models/whisper"
                  style={inputStyle}
                />
                <button
                  onClick={() => {
                    const defaultPath = '~/.dsh/models/whisper';
                    setModelPath(defaultPath);
                    onSettingChange('modelPath', defaultPath);
                  }}
                  style={{
                    ...buttonStyle,
                    backgroundColor: 'var(--bg-secondary, #f3f4f6)',
                    color: 'var(--text-primary, #333)',
                  }}
                >
                  重置默认
                </button>
              </div>
            </SettingRow>
          </>
        )}

        {/* Whisper API Key */}
        {(settings.asrMode === 'whisper-api') && (
          <>
            <SettingRow label="API Key" description="OpenAI Whisper API Key">
              <input
                type="password"
                value={settings.whisperApiKey || ''}
                onChange={(e) => onSettingChange('whisperApiKey', e.target.value)}
                placeholder="sk-..."
                style={inputStyle}
              />
            </SettingRow>
            <SettingRow label="API 端点" description="自定义 Whisper API 端点（可选）">
              <input
                type="text"
                value={settings.whisperApiEndpoint || 'https://api.openai.com/v1/audio/transcriptions'}
                onChange={(e) => onSettingChange('whisperApiEndpoint', e.target.value)}
                style={inputStyle}
              />
            </SettingRow>
          </>
        )}

        {/* 语言 */}
        <SettingRow label="识别语言" description="语音转写的默认语言">
          <select
            value={settings.language || 'zh'}
            onChange={(e) => onSettingChange('language', e.target.value)}
            style={selectStyle}
          >
            <option value="auto">🌐 自动检测</option>
            <option value="zh">🇨🇳 中文</option>
            <option value="en">🇺🇸 English</option>
            <option value="ja">🇯🇵 日本語</option>
          </select>
        </SettingRow>

        {/* 智能标点 */}
        <SettingRow label="智能标点" description="自动添加句号、逗号等标点符号">
          <Toggle
            checked={settings.smartPunctuation ?? true}
            onChange={(v) => onSettingChange('smartPunctuation', v)}
          />
        </SettingRow>

        {/* 自动发送 */}
        <SettingRow label="自动发送" description="语音识别完成后自动发送消息">
          <Toggle
            checked={settings.autoSend ?? false}
            onChange={(v) => onSettingChange('autoSend', v)}
          />
        </SettingRow>

        {/* 连续模式 */}
        <SettingRow label="连续对话" description="发送后自动进入录音模式，适合连续语音交互">
          <Toggle
            checked={settings.continuousMode ?? false}
            onChange={(v) => onSettingChange('continuousMode', v)}
          />
        </SettingRow>
      </section>

      {/* —— 提示词优化设置 —— */}
      <section style={{ marginBottom: '24px' }}>
        <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-secondary, #666)', marginBottom: '12px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
          提示词优化
        </h3>

        {/* 优化模型 */}
        <SettingRow label="优化模型" description="留空则复用当前会话模型">
          <input
            type="text"
            value={settings.enhanceModel || ''}
            onChange={(e) => onSettingChange('enhanceModel', e.target.value)}
            placeholder="例如：deepseek-chat（留空复用当前模型）"
            style={inputStyle}
          />
        </SettingRow>

        {/* 默认策略 */}
        <SettingRow label="默认策略" description="提示词优化的默认改写策略">
          <select
            value={settings.enhanceStrategy || 'auto'}
            onChange={(e) => onSettingChange('enhanceStrategy', e.target.value)}
            style={selectStyle}
          >
            <option value="auto">🔄 自动选择</option>
            <option value="concise">✂️ 简洁化</option>
            <option value="detailed">📝 详细化</option>
            <option value="technical">⚙️ 技术化</option>
            <option value="structured">📋 结构化</option>
            <option value="roleplay">🎭 角色扮演</option>
          </select>
        </SettingRow>

        {/* 上下文感知 */}
        <SettingRow label="上下文感知" description="优化时注入工作区文件列表等上下文信息">
          <Toggle
            checked={settings.enhanceContextAware ?? true}
            onChange={(v) => onSettingChange('enhanceContextAware', v)}
          />
        </SettingRow>
      </section>

      {/* —— 快捷键设置 —— */}
      <section style={{ marginBottom: '24px' }}>
        <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-secondary, #666)', marginBottom: '12px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
          快捷键
        </h3>

        <SettingRow label="语音输入" description="开始/停止语音录音">
          <input
            type="text"
            value={settings.hotkeyVoice || 'Ctrl+Shift+V'}
            onChange={(e) => onSettingChange('hotkeyVoice', e.target.value)}
            style={{ ...inputStyle, width: '150px' }}
          />
        </SettingRow>

        <SettingRow label="提示词优化" description="打开优化面板">
          <input
            type="text"
            value={settings.hotkeyEnhance || 'Ctrl+Shift+E'}
            onChange={(e) => onSettingChange('hotkeyEnhance', e.target.value)}
            style={{ ...inputStyle, width: '150px' }}
          />
        </SettingRow>
      </section>

      {/* —— 关于 —— */}
      <section style={{
        padding: '16px',
        backgroundColor: 'var(--bg-secondary, #f9fafb)',
        borderRadius: '8px',
        fontSize: '13px',
        color: 'var(--text-secondary, #666)',
      }}>
        <div style={{ fontWeight: 600, marginBottom: '4px', color: 'var(--text-primary, #333)' }}>
          dsh-smart-input v0.1.0
        </div>
        <div>语音输入 + 提示词优化插件 — 支持浏览器 Web Speech API、本地 Whisper ONNX、Whisper API 三种识别模式。</div>
      </section>
    </div>
  );
};

// ============ 子组件 ============

const SettingRow: React.FC<{ label: string; description: string; children: React.ReactNode }> = ({
  label, description, children
}) => (
  <div style={{
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '10px 0',
    borderBottom: '1px solid var(--border-color, #f3f4f6)',
    gap: '16px',
  }}>
    <div style={{ flex: '0 0 180px' }}>
      <div style={{ fontSize: '13px', fontWeight: 500, color: 'var(--text-primary, #333)' }}>{label}</div>
      <div style={{ fontSize: '11px', color: 'var(--text-secondary, #999)', marginTop: '2px' }}>{description}</div>
    </div>
    <div style={{ flex: 1, display: 'flex', justifyContent: 'flex-end' }}>{children}</div>
  </div>
);

const Toggle: React.FC<{ checked: boolean; onChange: (v: boolean) => void }> = ({ checked, onChange }) => (
  <button
    onClick={() => onChange(!checked)}
    style={{
      width: '40px',
      height: '22px',
      borderRadius: '11px',
      border: 'none',
      backgroundColor: checked ? '#10B981' : '#D1D5DB',
      cursor: 'pointer',
      position: 'relative',
      transition: 'background-color 0.2s',
    }}
  >
    <div style={{
      width: '18px',
      height: '18px',
      borderRadius: '9px',
      backgroundColor: '#fff',
      position: 'absolute',
      top: '2px',
      left: checked ? '20px' : '2px',
      transition: 'left 0.2s',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    }} />
  </button>
);

// ============ 样式常量 ============

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '6px 10px',
  border: '1px solid var(--border-color, #ddd)',
  borderRadius: '6px',
  fontSize: '13px',
  fontFamily: 'inherit',
  backgroundColor: 'var(--bg-primary, #fff)',
  color: 'var(--text-primary, #333)',
};

const selectStyle: React.CSSProperties = {
  padding: '6px 10px',
  border: '1px solid var(--border-color, #ddd)',
  borderRadius: '6px',
  fontSize: '13px',
  backgroundColor: 'var(--bg-primary, #fff)',
  color: 'var(--text-primary, #333)',
  minWidth: '200px',
};

const buttonStyle: React.CSSProperties = {
  padding: '6px 12px',
  border: '1px solid var(--border-color, #ddd)',
  borderRadius: '6px',
  fontSize: '13px',
  cursor: 'pointer',
  whiteSpace: 'nowrap',
};
