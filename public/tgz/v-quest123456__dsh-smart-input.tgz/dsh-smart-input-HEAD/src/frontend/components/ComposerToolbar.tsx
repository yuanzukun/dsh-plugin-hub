/**
 * ComposerToolbar — 输入框工具栏集成组件
 * 在 DSH 输入框工具栏中渲染语音输入和提示词优化按钮
 */
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { VoiceInputButton } from './VoiceInputButton';
import { PromptEnhanceButton } from './PromptEnhanceButton';

interface ComposerToolbarProps {
  settings: Record<string, any>;
  onInsertText: (text: string) => void;
  onEnhanceResult?: (result: any) => void;
}

export const ComposerToolbar: React.FC<ComposerToolbarProps> = ({
  settings,
  onInsertText,
  onEnhanceResult,
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingError, setRecordingError] = useState<string | null>(null);

  // —— 语音转写回调 ——
  const handleTranscript = useCallback((text: string) => {
    if (settings.autoSend) {
      onInsertText(text);
      // 自动发送逻辑由父组件处理
    } else {
      onInsertText(text);
    }

    if (settings.continuousMode) {
      // 连续模式：发送后自动重新开始录音
      setTimeout(() => {
        // 触发重新录音
      }, 500);
    }
  }, [settings, onInsertText]);

  // —— 错误处理 ——
  const handleError = useCallback((error: Error) => {
    setRecordingError(error.message);
    setTimeout(() => setRecordingError(null), 5000);
  }, []);

  // —— 快捷键绑定 ——
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl/Cmd + Shift + V → 语音输入
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'V') {
        e.preventDefault();
        // 触发语音输入按钮点击
        const voiceBtn = document.querySelector('.dsh-voice-input-btn') as HTMLButtonElement;
        voiceBtn?.click();
      }
      // Ctrl/Cmd + Shift + E → 提示词优化
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'E') {
        e.preventDefault();
        const enhanceBtn = document.querySelector('.dsh-enhance-btn') as HTMLButtonElement;
        enhanceBtn?.click();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div
      className="dsh-smart-input-toolbar"
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '4px',
        padding: '2px 0',
      }}
    >
      <VoiceInputButton
        settings={settings}
        onTranscript={handleTranscript}
        onError={handleError}
      />
      <PromptEnhanceButton
        settings={settings}
        onEnhance={(result) => {
          onInsertText(result.enhanced);
          onEnhanceResult?.(result);
        }}
        onError={handleError}
      />

      {/* 错误提示 */}
      {recordingError && (
        <span style={{
          fontSize: '12px',
          color: '#EF4444',
          padding: '2px 8px',
          backgroundColor: '#FEF2F2',
          borderRadius: '4px',
        }}>
          {recordingError}
        </span>
      )}
    </div>
  );
};

/**
 * InputEnhancer — 输入增强器
 * 监听输入框内容变化，在适当时机提供优化建议
 */
export const InputEnhancer: React.FC<{
  settings: Record<string, any>;
  inputValue: string;
  onEnhance: () => void;
}> = ({ settings, inputValue, onEnhance }) => {
  const [showSuggestion, setShowSuggestion] = useState(false);

  useEffect(() => {
    // 当输入长度适中（10-100字）时显示优化建议
    const len = inputValue.trim().length;
    setShowSuggestion(len >= 10 && len <= 100);
  }, [inputValue]);

  if (!showSuggestion) return null;

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: '6px',
      padding: '4px 8px',
      fontSize: '12px',
      color: 'var(--text-secondary, #999)',
    }}>
      <span>💡 需要优化提示词吗？</span>
      <button
        onClick={onEnhance}
        style={{
          border: '1px solid #10B981',
          borderRadius: '4px',
          padding: '2px 8px',
          backgroundColor: 'transparent',
          color: '#10B981',
          cursor: 'pointer',
          fontSize: '12px',
        }}
      >
        ✨ 一键优化
      </button>
      <span style={{ fontSize: '11px', opacity: 0.6 }}>
        ({settings.hotkeyEnhance || 'Ctrl+Shift+E'})
      </span>
    </div>
  );
};
