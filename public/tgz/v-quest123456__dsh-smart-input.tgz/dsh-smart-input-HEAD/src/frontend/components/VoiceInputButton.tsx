/**
 * VoiceInputButton — 语音输入按钮组件
 * 点击开始/停止录音，实时显示转写结果
 */
import React, { useState, useRef, useCallback } from 'react';

interface VoiceInputButtonProps {
  settings: Record<string, any>;
  onTranscript: (text: string) => void;
  onError: (error: Error) => void;
}

export const VoiceInputButton: React.FC<VoiceInputButtonProps> = ({
  settings,
  onTranscript,
  onError,
}) => {
  const [status, setStatus] = useState<'idle' | 'recording' | 'processing' | 'error'>('idle');
  const [interimText, setInterimText] = useState('');
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  // —— 开始录音 ——
  const startRecording = useCallback(async () => {
    try {
      chunksRef.current = [];
      setInterimText('');
      setStatus('recording');

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true,
        }
      });

      const mimeType = getSupportedMimeType();
      const mediaRecorder = new MediaRecorder(stream, { mimeType });
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        const blob = new Blob(chunksRef.current, { type: mimeType });
        await processAudio(blob);
      };

      mediaRecorder.start(200);

      // 计时器
      setRecordingTime(0);
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => {
          const next = prev + 1;
          const maxDuration = 300;
          if (next >= maxDuration) {
            stopRecording();
          }
          return next;
        });
      }, 1000);

      // 尝试同时启动浏览器实时转写（如果支持）
      if (settings.asrMode !== 'local-whisper' && settings.asrMode !== 'whisper-api') {
        startBrowserRecognition();
      }

    } catch (err) {
      setStatus('error');
      onError(err as Error);
    }
  }, [settings]);

  // —— 停止录音 ——
  const stopRecording = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    stopBrowserRecognition();

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }

    setStatus('processing');
  }, []);

  // —— 处理音频（转写） ——
  const processAudio = useCallback(async (blob: Blob) => {
    try {
      setStatus('processing');
      const mode = settings.asrMode || 'auto';

      if (mode === 'browser') {
        // 浏览器模式结果已在回调中
        setStatus('idle');
        return;
      }

      // 本地 Whisper 或 Whisper API
      if (mode === 'local-whisper' || (mode === 'auto' && isLocalModelAvailable())) {
        const result = await transcribeWithLocalWhisper(blob);
        onTranscript(result);
      } else if (mode === 'whisper-api' || settings.whisperApiKey) {
        const result = await transcribeWithWhisperAPI(blob);
        onTranscript(result);
      } else {
        // 回退到浏览器
        setStatus('idle');
      }

      setStatus('idle');
    } catch (err) {
      setStatus('error');
      onError(err as Error);
      setTimeout(() => setStatus('idle'), 3000);
    }
  }, [settings, onTranscript, onError]);

  // —— 浏览器实时转写（叠加模式） ——
  const browserRecognitionRef = useRef<any>(null);

  const startBrowserRecognition = useCallback(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    const recognizer = new SpeechRecognition();
    recognizer.continuous = true;
    recognizer.interimResults = true;
    recognizer.lang = mapLang(settings.language || 'zh');

    recognizer.onresult = (event: any) => {
      let interim = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        interim += event.results[i][0].transcript;
      }
      setInterimText(interim);
    };

    recognizer.onerror = () => {/* 静默处理 */};
    recognizer.onend = () => {
      if (status === 'recording') recognizer.start();
    };

    browserRecognitionRef.current = recognizer;
    try { recognizer.start(); } catch {}
  }, [settings, status]);

  const stopBrowserRecognition = useCallback(() => {
    if (browserRecognitionRef.current) {
      try { browserRecognitionRef.current.stop(); } catch {}
      browserRecognitionRef.current = null;
    }
    // 如果有中间结果，直接使用
    if (interimText.trim()) {
      onTranscript(interimText.trim());
      setInterimText('');
    }
  }, [interimText, onTranscript]);

  // —— 按钮点击处理 ——
  const handleClick = useCallback(() => {
    if (status === 'recording') {
      stopRecording();
    } else if (status === 'idle' || status === 'error') {
      startRecording();
    }
  }, [status, startRecording, stopRecording]);

  // —— 渲染 ——
  const buttonConfig = {
    idle: { icon: '🎤', label: '语音输入', color: '#4D6BFE' },
    recording: { icon: '⏹️', label: '停止录音', color: '#FF4444' },
    processing: { icon: '⏳', label: '转写中...', color: '#FFA500' },
    error: { icon: '❌', label: '出错了', color: '#FF4444' },
  }[status];

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  return (
    <div className="dsh-voice-input-wrapper" style={{ position: 'relative', display: 'inline-flex', alignItems: 'center' }}>
      <button
        className="dsh-voice-input-btn"
        onClick={handleClick}
        title={`${buttonConfig.label} (${settings.hotkeyVoice || 'Ctrl+Shift+V'})`}
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '4px',
          padding: '4px 10px',
          border: `1px solid ${buttonConfig.color}`,
          borderRadius: '6px',
          backgroundColor: status === 'recording' ? `${buttonConfig.color}20` : 'transparent',
          color: buttonConfig.color,
          cursor: 'pointer',
          fontSize: '13px',
          transition: 'all 0.2s',
          animation: status === 'recording' ? 'pulse 1.5s infinite' : 'none',
        }}
      >
        <span style={{ fontSize: '14px' }}>{buttonConfig.icon}</span>
        <span>{buttonConfig.label}</span>
        {status === 'recording' && (
          <span style={{ fontSize: '11px', opacity: 0.7 }}>{formatTime(recordingTime)}</span>
        )}
      </button>

      {/* 实时转写预览浮层 */}
      {(status === 'recording' || status === 'processing') && interimText && (
        <div style={{
          position: 'absolute',
          bottom: '100%',
          left: '50%',
          transform: 'translateX(-50%)',
          marginBottom: '8px',
          padding: '8px 12px',
          backgroundColor: 'var(--bg-elevated, #fff)',
          border: '1px solid var(--border-color, #ddd)',
          borderRadius: '8px',
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          maxWidth: '320px',
          minWidth: '160px',
          fontSize: '13px',
          color: 'var(--text-secondary, #666)',
          whiteSpace: 'normal',
          wordBreak: 'break-word',
          zIndex: 1000,
        }}>
          {interimText}
          <span style={{ display: 'inline-block', width: '2px', height: '14px', backgroundColor: buttonConfig.color, marginLeft: '2px', animation: 'blink 1s infinite', verticalAlign: 'middle' }} />
        </div>
      )}

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.7; }
        }
        @keyframes blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0; }
        }
      `}</style>
    </div>
  );
};

// ============ 工具函数 ============

function getSupportedMimeType(): string {
  const types = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus'];
  for (const t of types) {
    if (MediaRecorder.isTypeSupported(t)) return t;
  }
  return 'audio/webm';
}

function mapLang(lang: string): string {
  const m: Record<string, string> = { 'zh': 'zh-CN', 'en': 'en-US', 'ja': 'ja-JP' };
  return m[lang] || lang;
}

function isLocalModelAvailable(): boolean {
  // 检查本地模型目录是否可访问
  // 实际实现中通过 fetch 检查
  return true;
}

async function transcribeWithLocalWhisper(blob: Blob): Promise<string> {
  // 使用 transformers.js 加载本地 Whisper 模型
  const { pipeline, env } = await import('@xenova/transformers');
  env.localModelPath = '/models/whisper/';
  env.allowRemoteModels = false;

  const transcriber = await pipeline('automatic-speech-recognition', 'whisper-small', {
    local_files_only: true,
  });

  const audioCtx = new AudioContext();
  const arrayBuf = await blob.arrayBuffer();
  const audioBuf = await audioCtx.decodeAudioData(arrayBuf);
  const channelData = audioBuf.getChannelData(0);

  const result = await transcriber(channelData, {
    chunk_length_s: 30,
    return_timestamps: false,
  });

  return result.text?.trim() || '';
}

async function transcribeWithWhisperAPI(blob: Blob): Promise<string> {
  const apiKey = (window as any).__DSH_SETTINGS__?.whisperApiKey;
  if (!apiKey) throw new Error('未配置 Whisper API Key');

  const formData = new FormData();
  formData.append('file', blob, 'audio.webm');
  formData.append('model', 'whisper-1');
  formData.append('response_format', 'text');

  const resp = await fetch('https://api.openai.com/v1/audio/transcriptions', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${apiKey}` },
    body: formData,
  });

  if (!resp.ok) throw new Error(`Whisper API 错误: ${resp.status}`);
  return (await resp.text()).trim();
}
