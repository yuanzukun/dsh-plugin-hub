/**
 * useVoiceRecording — 语音录音 Hook
 * 封装 MediaRecorder 录音逻辑
 */
import { useState, useRef, useCallback } from 'react';

interface UseVoiceRecordingOptions {
  onDataAvailable?: (blob: Blob) => void;
  onResult?: (text: string) => void;
  onError?: (error: Error) => void;
  mimeType?: string;
  language?: string;
  maxDuration?: number;
}

interface UseVoiceRecordingReturn {
  isRecording: boolean;
  isProcessing: boolean;
  interimText: string;
  duration: number;
  error: string | null;
  start: () => Promise<void>;
  stop: () => void;
  reset: () => void;
}

export function useVoiceRecording(options: UseVoiceRecordingOptions = {}): UseVoiceRecordingReturn {
  const {
    onDataAvailable,
    onError,
    mimeType = 'audio/webm;codecs=opus',
    maxDuration = 300,
  } = options;

  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [duration, setDuration] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const start = useCallback(async () => {
    try {
      chunksRef.current = [];
      setError(null);
      setIsRecording(true);
      setDuration(0);

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true,
        }
      });
      streamRef.current = stream;

      const recorder = new MediaRecorder(stream, { mimeType: getSupportedMimeType(mimeType) });
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        stream.getTracks().forEach(t => t.stop());
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType });
        onDataAvailable?.(blob);
      };

      recorder.start(200);

      // 计时
      timerRef.current = setInterval(() => {
        setDuration(prev => {
          const next = prev + 1;
          if (next >= maxDuration) stop();
          return next;
        });
      }, 1000);

    } catch (err) {
      const error = err as Error;
      setError(error.message);
      onError?.(error);
      setIsRecording(false);
    }
  }, [mimeType, maxDuration, onDataAvailable, onError]);

  const stop = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }

    setIsRecording(false);
    setIsProcessing(true);
  }, []);

  const reset = useCallback(() => {
    chunksRef.current = [];
    setIsRecording(false);
    setIsProcessing(false);
    setDuration(0);
    setError(null);
  }, []);

  return {
    isRecording,
    isProcessing,
    interimText: '',
    duration,
    error,
    start,
    stop,
    reset,
  };
}

/**
 * useWhisperTranscribe — Whisper 转写 Hook
 */
export function useWhisperTranscribe() {
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [result, setResult] = useState('');
  const [error, setError] = useState<string | null>(null);

  const transcribe = useCallback(async (blob: Blob, modelPath: string, language?: string) => {
    setIsTranscribing(true);
    setError(null);

    try {
      const { pipeline, env } = await import('@xenova/transformers');
      env.localModelPath = modelPath + '/';
      env.allowRemoteModels = false;

      const transcriber = await pipeline('automatic-speech-recognition', 'whisper-small', {
        local_files_only: true,
      });

      const audioCtx = new AudioContext();
      const arrayBuf = await blob.arrayBuffer();
      const audioBuf = await audioCtx.decodeAudioData(arrayBuf);
      const channelData = audioBuf.getChannelData(0);

      const output = await transcriber(channelData, {
        chunk_length_s: 30,
        return_timestamps: false,
        ...(language && language !== 'auto' ? { language } : {}),
      });

      const text = output.text?.trim() || '';
      setResult(text);
      return text;
    } catch (err) {
      const error = err as Error;
      setError(error.message);
      throw error;
    } finally {
      setIsTranscribing(false);
    }
  }, []);

  return { transcribe, isTranscribing, result, error };
}

/**
 * usePromptEnhance — 提示词优化 Hook
 */
export function usePromptEnhance() {
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const enhance = useCallback(async (prompt: string, strategy: string, contextFiles?: string[]) => {
    setIsEnhancing(true);
    setError(null);

    try {
      // 尝试调用后端 API
      const response = await fetch('/api/smart-input/enhance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, strategy, contextFiles }),
      });

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      setResult(data);
      return data;
    } catch (err) {
      const error = err as Error;
      setError(error.message);
      throw error;
    } finally {
      setIsEnhancing(false);
    }
  }, []);

  return { enhance, isEnhancing, result, error };
}

// ============ 工具函数 ============

function getSupportedMimeType(preferred: string): string {
  if (MediaRecorder.isTypeSupported(preferred)) return preferred;
  const fallbacks = ['audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];
  for (const f of fallbacks) {
    if (MediaRecorder.isTypeSupported(f)) return f;
  }
  return 'audio/webm';
}
