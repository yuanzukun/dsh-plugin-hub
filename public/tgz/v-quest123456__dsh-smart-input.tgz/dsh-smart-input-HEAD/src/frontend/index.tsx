/**
 * dsh-smart-input — 前端入口
 * 注册 UI 扩展：语音输入按钮、提示词优化按钮、设置面板
 */
import React from 'react';
import { ComposerToolbar, InputEnhancer } from './components/ComposerToolbar';
import { VoiceInputButton } from './components/VoiceInputButton';
import { PromptEnhanceButton } from './components/PromptEnhanceButton';
import { SettingsPanel } from './components/SettingsPanel';

export interface SmartInputFrontend {
  /** 渲染 Composer 工具栏按钮 */
  renderComposerToolbar(inputValue?: string): React.ReactNode;
  /** 渲染输入增强器 */
  renderInputEnhancer?(inputValue: string): React.ReactNode;
  /** 渲染设置面板 */
  renderSettingsPanel?(): React.ReactNode;
}

/**
 * 前端初始化入口 — DSH Cordis 内核在加载 bundle 时调用
 */
export function activate(ctx: any): SmartInputFrontend {
  const { settings, events } = ctx;

  return {
    renderComposerToolbar(inputValue: string = '') {
      return React.createElement(ComposerToolbar, {
        settings,
        onInsertText: (text: string) => {
          events.emit('smart-input:insert', { text });
        },
        onEnhanceResult: (result: any) => {
          events.emit('smart-input:enhance-complete', result);
        },
      });
    },

    renderInputEnhancer(inputValue: string) {
      return React.createElement(InputEnhancer, {
        settings,
        inputValue,
        onEnhance: () => {
          events.emit('smart-input:enhance-request', { text: inputValue });
        },
      });
    },

    renderSettingsPanel() {
      return React.createElement(SettingsPanel, {
        settings,
        onSettingChange: (key: string, value: any) => {
          ctx.updateSetting?.(key, value);
        },
      });
    }
  };
}

// 重新导出组件（供 dsh.bundle hooks 引用）
export { ComposerToolbar, InputEnhancer } from './components/ComposerToolbar';
export { VoiceInputButton } from './components/VoiceInputButton';
export { PromptEnhanceButton } from './components/PromptEnhanceButton';
export { SettingsPanel } from './components/SettingsPanel';
