/**
 * dsh-smart-input — 后端入口
 * 注册 Tool 服务：语音识别 (transcribe) + 提示词优化 (enhance_prompt)
 */
import { ASRService, createASRService } from './services/asr-service';
import { EnhanceService, createEnhanceService } from './services/enhance-service';
import { PluginContext, ToolDefinition } from './types';

export interface SmartInputBackend {
  asr: ASRService;
  enhance: EnhanceService;
  ctx: PluginContext;
}

/**
 * 插件后端初始化入口 — DSH Cordis 内核在加载 bundle 时调用
 */
export function activate(ctx: PluginContext): SmartInputBackend {
  const settings = ctx.settings;

  // 初始化 ASR 服务
  const asr = createASRService({
    mode: settings.asrMode ?? 'auto',
    localModel: settings.localModel ?? 'whisper-small',
    modelPath: settings.modelPath || undefined,
    language: settings.language ?? 'zh',
    whisperApiKey: settings.whisperApiKey || undefined,
    whisperApiEndpoint: settings.whisperApiEndpoint ?? 'https://api.openai.com/v1/audio/transcriptions',
    smartPunctuation: settings.smartPunctuation ?? true,
  }, ctx);

  // 解析自定义策略提示词
  var customPrompts: Record<string, string> | undefined;
  if (settings.enhanceCustomPrompts) {
    try {
      customPrompts = JSON.parse(settings.enhanceCustomPrompts);
    } catch (e) {
      console.warn('[dsh-smart-input] enhanceCustomPrompts JSON 解析失败，使用内置策略');
    }
  }

  // 初始化提示词优化服务
  const enhance = createEnhanceService({
    model: settings.enhanceModel || undefined,
    strategy: settings.enhanceStrategy ?? 'auto',
    contextAware: settings.enhanceContextAware ?? true,
    customPrompts: customPrompts,
  }, ctx);

  // 注册 Tool 定义
  const tools: ToolDefinition[] = [
    {
      name: 'transcribe',
      description: '将音频转写为文字。支持从麦克风录音或传入音频文件路径。',
      parameters: {
        type: 'object',
        properties: {
          audioSource: {
            type: 'string',
            enum: ['microphone', 'file'],
            default: 'microphone',
            description: '音频来源：microphone(麦克风录音) / file(文件路径)'
          },
          filePath: {
            type: 'string',
            description: '音频文件路径（当 audioSource=file 时必填）'
          },
          language: {
            type: 'string',
            description: '语言代码（如 zh, en, ja），不指定则使用设置中的默认值'
          },
          duration: {
            type: 'number',
            description: '最大录音时长（秒），默认 300'
          }
        }
      },
      execute: (params) => asr.transcribeTool(params)
    },
    {
      name: 'enhance_prompt',
      description: '优化用户输入的提示词，使其更清晰、具体、有效。支持多种优化策略。',
      parameters: {
        type: 'object',
        properties: {
          prompt: {
            type: 'string',
            description: '原始提示词内容'
          },
          strategy: {
            type: 'string',
            enum: ['auto', 'concise', 'detailed', 'technical', 'structured', 'roleplay'],
            description: '优化策略'
          },
          contextFiles: {
            type: 'array',
            items: { type: 'string' },
            description: '相关工作区文件路径（用于上下文感知优化）'
          }
        },
        required: ['prompt']
      },
      execute: (params) => enhance.enhancePrompt(params)
    }
  ];

  // 注册到 DSH
  for (const tool of tools) {
    ctx.registerTool(tool);
  }

  // 记录日志
  ctx.logger.info('[dsh-smart-input] 后端已加载，可用工具：transcribe, enhance_prompt');

  return { asr, enhance, ctx };
}

/**
 * 插件停用入口
 */
export function deactivate(backend: SmartInputBackend): void {
  backend.asr.dispose();
  backend.enhance.dispose();
  backend.ctx.logger.info('[dsh-smart-input] 后端已卸载');
}
