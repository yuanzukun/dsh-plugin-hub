/**
 * 类型定义 — DSH 插件上下文与工具接口
 */

/** DSH 插件上下文 — 由 Cordis 内核注入 */
export interface PluginContext {
  /** 当前插件设置 */
  settings: Record<string, any>;
  /** 设置变更时更新 */
  updateSetting(key: string, value: any): Promise<void>;
  /** 日志记录器 */
  logger: {
    info(...args: any[]): void;
    warn(...args: any[]): void;
    error(...args: any[]): void;
    debug(...args: any[]): void;
  };
  /** 注册工具 */
  registerTool(tool: ToolDefinition): void;
  /** 调用 LLM（复用 DSH 会话模型） */
  callLLM(params: LLMCallParams): Promise<LLMCallResult>;
  /** 获取当前工作区路径 */
  getWorkspacePath(): string | null;
  /** 获取会话历史摘要 */
  getSessionSummary?(): Promise<string>;
  /** 文件系统访问 */
  fs: {
    readFile(path: string): Promise<string>;
    exists(path: string): Promise<boolean>;
    listDir(path: string): Promise<string[]>;
  };
  /** 事件总线 */
  events: {
    emit(event: string, payload?: any): void;
    on(event: string, handler: (payload?: any) => void): void;
    off(event: string, handler: (payload?: any) => void): void;
  };
}

/** 工具定义 */
export interface ToolDefinition {
  name: string;
  description: string;
  parameters: JSONSchema;
  execute(params: any): Promise<ToolResult>;
}

/** 工具调用结果 */
export interface ToolResult {
  content: string;
  data?: any;
  error?: string;
}

/** LLM 调用参数 */
export interface LLMCallParams {
  messages: Array<{
    role: 'system' | 'user' | 'assistant';
    content: string;
  }>;
  model?: string;
  temperature?: number;
  maxTokens?: number;
  stream?: boolean;
}

/** LLM 调用结果 */
export interface LLMCallResult {
  content: string;
  model: string;
  usage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
}

/** JSON Schema 简化类型 */
export interface JSONSchema {
  type: string;
  properties?: Record<string, JSONSchema>;
  required?: string[];
  default?: any;
  description?: string;
  enum?: string[];
  items?: JSONSchema;
  [key: string]: any;
}
