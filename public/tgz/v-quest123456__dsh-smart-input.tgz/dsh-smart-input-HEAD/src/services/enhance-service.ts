/**
 * Enhance Service — 提示词优化服务
 * 支持多种优化策略，可注入工作区上下文
 */
import { PluginContext } from '../backend/types';

// ============ 配置与类型 ============

export interface EnhanceConfig {
  model?: string;
  strategy: 'auto' | 'concise' | 'detailed' | 'technical' | 'structured' | 'roleplay';
  contextAware: boolean;
  /** 用户自定义策略提示词（可选，覆盖内置版本） */
  customPrompts?: Record<string, string>;
}

export interface EnhanceResult {
  original: string;
  enhanced: string;
  strategy: string;
  changes: string[];
  tokensUsed?: number;
}

export interface EnhanceService {
  enhancePrompt(params: {
    prompt: string;
    strategy?: string;
    contextFiles?: string[];
  }): Promise<EnhanceResult>;
  getStrategies(): StrategyInfo[];
  dispose(): void;
}

interface StrategyInfo {
  id: string;
  name: string;
  nameEn: string;
  description: string;
  icon: string;
}

// ============ 优化策略定义 ============

interface Strategy {
  id: string;
  systemPrompt: string;
  temperature: number;
}

function getStrategies(customPrompts?: Record<string, string>): Record<string, Strategy> {
  // 通用约束（所有策略共享，避免重复）
  const SUFFIX = '只输出优化后的提示词，不要解释。';

  const builtins: Record<string, Strategy> = {
    concise: {
      id: 'concise',
      systemPrompt: `精简提示词专家。去除冗余，保留核心意图，用词精准。${SUFFIX}`,
      temperature: 0.3,
    },
    detailed: {
      id: 'detailed',
      systemPrompt: `提示词扩展专家。补充上下文、明确目标与约束，消除歧义。${SUFFIX}`,
      temperature: 0.5,
    },
    technical: {
      id: 'technical',
      systemPrompt: `技术写作专家。使用精确术语，明确技术栈与约束（性能、安全、兼容性）。${SUFFIX}`,
      temperature: 0.4,
    },
    structured: {
      id: 'structured',
      systemPrompt: `任务分解专家。按格式重构：目标、背景、约束、输出、示例（可选）。${SUFFIX}`,
      temperature: 0.4,
    },
    roleplay: {
      id: 'roleplay',
      systemPrompt: `角色设计专家。添加明确角色身份与专业背景，保持原意，自然融入。${SUFFIX}`,
      temperature: 0.6,
    },
  };

  // 合并用户自定义提示词（覆盖内置版本）
  if (customPrompts) {
    for (var key in customPrompts) {
      if (builtins[key]) {
        builtins[key] = Object.assign({}, builtins[key], { systemPrompt: customPrompts[key] });
      }
    }
  }

  return builtins;
}

// ============ 实现 ============

class EnhanceServiceImpl implements EnhanceService {
  private config: EnhanceConfig;
  private ctx: PluginContext;

  constructor(config: EnhanceConfig, ctx: PluginContext) {
    this.config = config;
    this.ctx = ctx;
  }

  async enhancePrompt(params: {
    prompt: string;
    strategy?: string;
    contextFiles?: string[];
  }): Promise<EnhanceResult> {
    const { prompt, strategy, contextFiles } = params;

    if (!prompt || !prompt.trim()) {
      throw new Error('提示词不能为空');
    }

    const effectiveStrategy = strategy || this.config.strategy;
    const resolvedStrategy = effectiveStrategy === 'auto'
      ? this.autoSelectStrategy(prompt)
      : effectiveStrategy;

    const strategyDef = getStrategies(this.config.customPrompts)[resolvedStrategy] || getStrategies(this.config.customPrompts).detailed;

    // 构建上下文
    let contextPrefix = '';
    if (this.config.contextAware && contextFiles && contextFiles.length > 0) {
      const ctx = await this.buildContext(contextFiles);
      if (ctx) {
        contextPrefix = `## 相关上下文\n${ctx}\n\n`;
      }
    }

    // 构建消息
    const messages = [
      {
        role: 'system' as const,
        content: strategyDef.systemPrompt,
      },
      {
        role: 'user' as const,
        content: `${contextPrefix}请优化以下提示词：\n\n${prompt}`,
      },
    ];

    // 调用 LLM
    const result = await this.ctx.callLLM({
      messages,
      model: this.config.model,
      temperature: strategyDef.temperature,
      maxTokens: 2048,
    });

    const enhanced = result.content.trim();

    return {
      original: prompt,
      enhanced,
      strategy: resolvedStrategy,
      changes: this.diffChanges(prompt, enhanced),
      tokensUsed: result.usage?.totalTokens,
    };
  }

  getStrategies(): StrategyInfo[] {
    return [
      { id: 'auto', name: '自动', nameEn: 'Auto', description: '根据内容自动选择最佳策略', icon: '🔄' },
      { id: 'concise', name: '简洁化', nameEn: 'Concise', description: '去除冗余，精炼表达', icon: '✂️' },
      { id: 'detailed', name: '详细化', nameEn: 'Detailed', description: '补充上下文和约束条件', icon: '📝' },
      { id: 'technical', name: '技术化', nameEn: 'Technical', description: '使用精确的技术术语', icon: '⚙️' },
      { id: 'structured', name: '结构化', nameEn: 'Structured', description: '重构为目标-约束-输出格式', icon: '📋' },
      { id: 'roleplay', name: '角色扮演', nameEn: 'Role Play', description: '添加角色设定增强代入感', icon: '🎭' },
    ];
  }

  // —— 自动选择策略 ——

  private autoSelectStrategy(prompt: string): string {
    const lower = prompt.toLowerCase();

    // 如果已经很长且详细 → 简洁化
    if (prompt.length > 200 && !prompt.includes('请') && !prompt.includes('帮我')) {
      return 'concise';
    }

    // 如果很短 → 详细化
    if (prompt.length < 20) {
      return 'detailed';
    }

    // 如果包含技术关键词 → 结构化
    const techKeywords = ['代码', '函数', '类', '接口', 'API', '数据库', '算法', '架构', 'code', 'function', 'class'];
    if (techKeywords.some(kw => lower.includes(kw))) {
      return 'structured';
    }

    // 如果是问句 → 详细化
    if (prompt.endsWith('?') || prompt.endsWith('？') || lower.startsWith('怎么') || lower.startsWith('如何')) {
      return 'detailed';
    }

    // 默认详细化
    return 'detailed';
  }

  // —— 构建上下文 ——

  private async buildContext(filePaths: string[]): Promise<string> {
    const ctxParts: string[] = [];

    for (const filePath of filePaths.slice(0, 5)) { // 最多 5 个文件
      try {
        const content = await this.ctx.fs.readFile(filePath);
        // 截取前 500 字符作为上下文
        const truncated = content.length > 500
          ? content.slice(0, 500) + '...'
          : content;
        ctxParts.push(`### ${filePath}\n${truncated}`);
      } catch {
        // 跳过无法读取的文件
      }
    }

    return ctxParts.join('\n\n');
  }

  // —— 差异对比 ——

  private diffChanges(original: string, enhanced: string): string[] {
    const changes: string[] = [];

    if (enhanced.length > original.length * 1.2) {
      changes.push('扩展了内容细节');
    } else if (enhanced.length < original.length * 0.8) {
      changes.push('精简了表达');
    }

    if (enhanced.includes('##') || enhanced.includes('- ')) {
      changes.push('增加了结构化格式');
    }

    if (!changes.length) {
      changes.push('优化了表达方式');
    }

    return changes;
  }

  dispose(): void {
    // 无需要释放的资源
  }
}

// ============ 工厂函数 ============

export function createEnhanceService(config: EnhanceConfig, ctx: PluginContext): EnhanceService {
  return new EnhanceServiceImpl(config, ctx);
}
