/**
 * ASR Service — 语音识别服务
 * 支持四种模式：auto / browser / local-whisper / whisper-api
 */
import { PluginContext } from '../backend/types';

// ============ 配置接口 ============

export interface ASRConfig {
  mode: 'auto' | 'browser' | 'local-whisper' | 'whisper-api';
  localModel: 'whisper-small' | 'whisper-large-v3-turbo';
  modelPath?: string;
  language: string;
  whisperApiKey?: string;
  whisperApiEndpoint: string;
  smartPunctuation: boolean;
}

export interface TranscriptResult {
  text: string;
  language?: string;
  confidence?: number;
  segments?: TranscriptChunk[];
  duration?: number;
}

export interface TranscriptChunk {
  text: string;
  start: number;
  end: number;
  isFinal: boolean;
}

// ============ ASR 服务主类 ============

export interface ASRService {
  /** 检查当前可用的 ASR 模式 */
  getAvailableModes(): ASRModeInfo[];
  /** 开始录音并转写（流式回调） */
  startRecording(options?: RecordingOptions): Promise<void>;
  /** 停止录音 */
  stopRecording(): Promise<TranscriptResult>;
  /** 转写已有音频文件 */
  transcribeFile(filePath: string, language?: string): Promise<TranscriptResult>;
  /** Tool 调用入口 */
  transcribeTool(params: any): Promise<any>;
  /** 释放资源 */
  dispose(): void;
}

export interface RecordingOptions {
  language?: string;
  onChunk?: (chunk: TranscriptChunk) => void;
  onResult?: (result: TranscriptResult) => void;
  onError?: (error: Error) => void;
  maxDuration?: number; // 秒
}

interface ASRModeInfo {
  mode: string;
  label: string;
  available: boolean;
  description: string;
}

// ============ 工厂函数 ============

export function createASRService(config: ASRConfig, ctx: PluginContext): ASRService {
  return new ASRServiceImpl(config, ctx);
}

// ============ 实现 ============

class ASRServiceImpl implements ASRService {
  private config: ASRConfig;
  private ctx: PluginContext;
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];
  private isRecording = false;
  private browserRecognizer: any = null;
  private localWhisperSession: any = null;

  constructor(config: ASRConfig, ctx: PluginContext) {
    this.config = config;
    this.ctx = ctx;
  }

  // —— 可用模式检测 ——

  getAvailableModes(): ASRModeInfo[] {
    const modes: ASRModeInfo[] = [];

    // 浏览器 Web Speech API
    const browserAvailable = typeof window !== 'undefined' &&
      ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window);
    modes.push({
      mode: 'browser',
      label: '浏览器语音识别',
      available: browserAvailable,
      description: browserAvailable
        ? '使用浏览器内置 Web Speech API，零依赖'
        : '当前浏览器不支持 Web Speech API（需 Chrome/Edge）'
    });

    // 本地 Whisper（需要模型文件）
    const modelPath = this.getModelPath();
    modes.push({
      mode: 'local-whisper',
      label: '本地 Whisper',
      available: true, // 运行时检查
      description: `使用本地 Whisper ONNX 模型 (${this.config.localModel})，完全离线`
    });

    // Whisper API
    const hasKey = !!this.config.whisperApiKey;
    modes.push({
      mode: 'whisper-api',
      label: 'Whisper API（在线）',
      available: hasKey,
      description: hasKey
        ? '使用 OpenAI Whisper API，准确率最高'
        : '需配置 OpenAI API Key'
    });

    return modes;
  }

  private getModelPath(): string {
    if (this.config.modelPath) return this.config.modelPath;
    // 默认模型路径：优先使用环境变量，回退到 DSH 模型目录
    const base = process.env.DSH_SMART_INPUT_MODEL_ROOT
      || (process.env.DSH_HOME ? `${process.env.DSH_HOME}/models/whisper` : '~/.dsh/models/whisper');
    const modelName = this.config.localModel;
    return `${base.replace(/\\/g, '/')}/${modelName}`;
  }

  // —— 录音控制 ——

  async startRecording(options: RecordingOptions = {}): Promise<void> {
    if (this.isRecording) {
      throw new Error('已有录音正在进行中');
    }

    const mode = this.resolveMode();

    if (mode === 'browser') {
      await this.startBrowserRecording(options);
    } else {
      // local-whisper 和 whisper-api 都先录音，后转写
      await this.startMediaRecorderRecording(options);
    }
  }

  async stopRecording(): Promise<TranscriptResult> {
    if (!this.isRecording) {
      throw new Error('没有正在进行的录音');
    }

    const mode = this.resolveMode();

    if (mode === 'browser' && this.browserRecognizer) {
      return this.stopBrowserRecording();
    } else {
      return this.stopMediaRecorderRecording();
    }
  }

  // —— 模式解析 ——

  private resolveMode(): string {
    if (this.config.mode !== 'auto') return this.config.mode;

    // 自动选择优先级：浏览器 → 本地 Whisper → Whisper API
    if (typeof window !== 'undefined' &&
        ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
      return 'browser';
    }
    // 检查本地模型是否存在
    if (this.checkLocalModel()) {
      return 'local-whisper';
    }
    if (this.config.whisperApiKey) {
      return 'whisper-api';
    }
    // 默认回退到浏览器
    return 'browser';
  }

  private checkLocalModel(): boolean {
    // 运行时检查模型文件是否存在
    try {
      const modelPath = this.getModelPath();
      // 在浏览器端通过 fetch 检查
      return true; // 简化实现
    } catch {
      return false;
    }
  }

  // —— 浏览器 Web Speech API ——

  private async startBrowserRecording(options: RecordingOptions): Promise<void> {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      throw new Error('浏览器不支持 Web Speech API');
    }

    const recognizer = new SpeechRecognition();
    recognizer.continuous = true;
    recognizer.interimResults = true;
    recognizer.lang = this.mapLanguageCode(options.language || this.config.language);

    let finalTranscript = '';

    recognizer.onresult = (event: any) => {
      let interimTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript + ' ';
          options.onChunk?.({
            text: transcript,
            start: 0,
            end: 0,
            isFinal: true
          });
        } else {
          interimTranscript += transcript;
          options.onChunk?.({
            text: interimTranscript,
            start: 0,
            end: 0,
            isFinal: false
          });
        }
      }
    };

    recognizer.onerror = (event: any) => {
      const error = new Error(`语音识别错误: ${event.error}`);
      options.onError?.(error);
    };

    recognizer.onend = () => {
      if (this.isRecording) {
        // 连续模式：自动重启
        recognizer.start();
      }
    };

    this.browserRecognizer = recognizer;
    this.isRecording = true;
    recognizer.start();

    // 最大时长限制
    const maxDuration = options.maxDuration || 300;
    setTimeout(() => {
      if (this.isRecording) {
        this.stopRecording().catch(() => {});
      }
    }, maxDuration * 1000);
  }

  private async stopBrowserRecording(): Promise<TranscriptResult> {
    this.isRecording = false;
    if (this.browserRecognizer) {
      this.browserRecognizer.stop();
      this.browserRecognizer = null;
    }
    return {
      text: '', // 已在回调中流式返回
      language: this.config.language,
    };
  }

  // —— MediaRecorder 录音（用于 local-whisper / whisper-api） ——

  private async startMediaRecorderRecording(options: RecordingOptions): Promise<void> {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mediaRecorder = new MediaRecorder(stream, {
      mimeType: this.getSupportedMimeType()
    });

    this.audioChunks = [];

    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        this.audioChunks.push(event.data);
      }
    };

    mediaRecorder.onstop = async () => {
      const audioBlob = new Blob(this.audioChunks, { type: mediaRecorder.mimeType });
      stream.getTracks().forEach(track => track.stop());

      try {
        const result = await this.transcribeBlob(audioBlob, options.language);
        options.onResult?.(result);
      } catch (error) {
        options.onError?.(error as Error);
      }
    };

    this.mediaRecorder = mediaRecorder;
    this.isRecording = true;
    mediaRecorder.start(100); // 每 100ms 收集一次数据

    // 最大时长限制
    const maxDuration = options.maxDuration || 300;
    setTimeout(() => {
      if (this.isRecording) {
        this.stopRecording().catch(() => {});
      }
    }, maxDuration * 1000);
  }

  private async stopMediaRecorderRecording(): Promise<TranscriptResult> {
    this.isRecording = false;
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      this.mediaRecorder.stop();
    }
    // 结果在 onstop 回调中异步返回
    return { text: '', language: this.config.language };
  }

  // —— 音频转写（Blob） ——

  private async transcribeBlob(audioBlob: Blob, language?: string): Promise<TranscriptResult> {
    const mode = this.resolveMode();

    if (mode === 'local-whisper') {
      return this.transcribeWithLocalWhisper(audioBlob, language);
    } else {
      return this.transcribeWithWhisperAPI(audioBlob, language);
    }
  }

  // —— 本地 Whisper ONNX 推理 ——

  private async transcribeWithLocalWhisper(audioBlob: Blob, language?: string): Promise<TranscriptResult> {
    try {
      // 使用 transformers.js 加载本地 Whisper 模型进行推理
      const { pipeline, env } = await import('@xenova/transformers');

      // 设置本地模型路径
      const modelPath = this.getModelPath();
      env.localModelPath = modelPath + '/';
      env.allowRemoteModels = false;

      const transcriber = await pipeline('automatic-speech-recognition', this.config.localModel, {
        local_files_only: true,
      });

      // 转换 Blob 为音频数据
      const audioData = await this.blobToAudioData(audioBlob);

      const result = await transcriber(audioData, {
        language: language || this.config.language,
        task: 'transcribe',
        chunk_length_s: 30,
        return_timestamps: true,
      });

      let text = result.text || '';
      if (this.config.smartPunctuation) {
        text = this.addSmartPunctuation(text);
      }

      return {
        text,
        language: language || this.config.language,
        segments: result.chunks?.map((chunk: any) => ({
          text: chunk.text,
          start: chunk.timestamp?.[0] || 0,
          end: chunk.timestamp?.[1] || 0,
          isFinal: true,
        })),
      };
    } catch (error) {
      throw new Error(`本地 Whisper 转写失败: ${(error as Error).message}`);
    }
  }

  // —— Whisper API 在线转写 ——

  private async transcribeWithWhisperAPI(audioBlob: Blob, language?: string): Promise<TranscriptResult> {
    if (!this.config.whisperApiKey) {
      throw new Error('未配置 Whisper API Key');
    }

    const formData = new FormData();
    formData.append('file', audioBlob, 'audio.webm');
    formData.append('model', 'whisper-1');
    if (language && language !== 'auto') {
      formData.append('language', language);
    }
    formData.append('response_format', 'verbose_json');

    const response = await fetch(this.config.whisperApiEndpoint, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.config.whisperApiKey}`,
      },
      body: formData,
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Whisper API 错误 (${response.status}): ${errText}`);
    }

    const data = await response.json();
    let text = data.text || '';
    if (this.config.smartPunctuation) {
      text = this.addSmartPunctuation(text);
    }

    return {
      text,
      language: data.language || language,
      segments: data.segments?.map((seg: any) => ({
        text: seg.text,
        start: seg.start,
        end: seg.end,
        isFinal: true,
      })),
    };
  }

  // —— 文件转写 ——

  async transcribeFile(filePath: string, language?: string): Promise<TranscriptResult> {
    // 读取文件内容
    const exists = await this.ctx.fs.exists(filePath);
    if (!exists) {
      throw new Error(`音频文件不存在: ${filePath}`);
    }

    // 在浏览器端需要通过 fetch 或 File API 读取
    const response = await fetch(`file://${filePath}`);
    const audioBlob = await response.blob();

    return this.transcribeBlob(audioBlob, language);
  }

  // —— Tool 调用入口 ——

  async transcribeTool(params: any): Promise<any> {
    const { audioSource, filePath, language, duration } = params;

    if (audioSource === 'file' && filePath) {
      return this.transcribeFile(filePath, language);
    }

    // 麦克风录音
    return new Promise((resolve, reject) => {
      this.startRecording({
        language,
        maxDuration: duration || 300,
        onResult: resolve,
        onError: reject,
      });
    }).finally(() => {
      this.dispose();
    });
  }

  // —— 工具方法 ——

  private mapLanguageCode(lang: string): string {
    const map: Record<string, string> = {
      'zh': 'zh-CN',
      'en': 'en-US',
      'ja': 'ja-JP',
      'ko': 'ko-KR',
      'fr': 'fr-FR',
      'de': 'de-DE',
      'es': 'es-ES',
    };
    return map[lang] || lang;
  }

  private getSupportedMimeType(): string {
    const types = [
      'audio/webm;codecs=opus',
      'audio/webm',
      'audio/ogg;codecs=opus',
      'audio/mp4',
    ];
    for (const type of types) {
      if (MediaRecorder.isTypeSupported(type)) {
        return type;
      }
    }
    return 'audio/webm';
  }

  private async blobToAudioData(blob: Blob): Promise<Float32Array> {
    const arrayBuffer = await blob.arrayBuffer();
    const audioContext = new AudioContext();
    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
    return audioBuffer.getChannelData(0);
  }

  private addSmartPunctuation(text: string): string {
    // 智能标点：基于停顿词和语法规则添加标点
    let result = text.trim();

    // 去除多余的空格
    result = result.replace(/\s+/g, ' ');

    // 中文语境下的简单标点规则
    if (this.config.language === 'zh' || this.config.language === 'auto') {
      // 句末标点（简单的启发式规则）
      const sentenceEnders = ['吗', '呢', '吧', '啊', '呀', '哦', '嗯', '请', '请问', '可以', '能不能', '是不是', '什么', '怎么', '哪个', '哪里', '多少', '为什么'];

      // 问句
      for (const ender of sentenceEnders) {
        if (result.endsWith(ender)) {
          result += '？';
          break;
        }
      }

      // 句中大停顿 → 逗号
      result = result.replace(/([，,])\s*/g, '，');
    }

    // 确保末尾有标点
    if (result && !/[。！？.?!，,；;：:]/.test(result.slice(-1))) {
      result += '。';
    }

    return result;
  }

  // —— 资源释放 ——

  dispose(): void {
    this.isRecording = false;

    if (this.browserRecognizer) {
      try { this.browserRecognizer.stop(); } catch {}
      this.browserRecognizer = null;
    }

    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      try { this.mediaRecorder.stop(); } catch {}
    }

    this.mediaRecorder = null;
    this.audioChunks = [];
  }
}
