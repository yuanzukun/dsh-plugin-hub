// validate.mjs — 桩 ctx 驱动 dsh-web-restart host 插件，验证重启端点逻辑。
import { apply } from './index.mjs'
import { setTimeout as sleep } from 'node:timers/promises'

let registeredRoute = null
let registeredCommands = []
let exitResults = []   // recorded exits: {code}
const originalExit = process.exit
process.exit = (code) => { exitResults.push({ code }); }   // stub: 记录但不退出

function fakeReq({ auth } = {}) { return { method: 'POST', headers: { authorization: auth } } }
function fakeRes() {
  const calls = { status: 0, body: '', end: false }
  const s = { writeHead(c) { calls.status = c; return s }, end(b) { if (typeof b === 'string') calls.body = b; calls.end = true; return s } }
  return { s, calls }
}
function makeCtx() {
  return {
    logger: { info: () => {}, warn: () => {} },
    effect: () => () => {},
    inject(keys, cb) {
      if (keys.includes('webServer')) cb({ webServer: { register(route) { registeredRoute = route; return () => {} } } })
    },
    commands: { register(d) { registeredCommands.push(d) } }
  }
}

const results = []
const t = (name, cond) => results.push({ name, cond })

// 1) 路由注册 + 返回 202
registeredRoute = null
apply(makeCtx(), {})
t('route /api/_dsh/restart registered (exact)', registeredRoute?.kind === 'exact' && registeredRoute?.path === '/api/_dsh/restart')
const r1 = fakeRes()
registeredRoute.handler(fakeReq(), r1.s)
t('responds 202 on POST', r1.calls.status === 202)

// 2) 未配 token：POST 触发退出
exitResults = []
await apply(makeCtx(), { flushMs: 0 })
const r2 = fakeRes()
registeredRoute.handler(fakeReq(), r2.s)
await sleep(30)
t('exit triggered (default mode=exit)', exitResults.length > 0)

// 3) token 校验
exitResults = []
await apply(makeCtx(), { flushMs: 0, token: 's3cret' })
const r3 = fakeRes()
registeredRoute.handler(fakeReq(), r3.s)            // 无 token
await sleep(30)
t('unauthorized → 401 & no exit', r3.calls.status === 401 && exitResults.length === 0)
const r4 = fakeRes()
registeredRoute.handler(fakeReq({ auth: 's3cret' }), r4.s)  // 对 token
await sleep(30)
t('authorized → 202 & exit', r4.calls.status === 202 && exitResults.length > 0)

// 4) slash 命令注册
registeredCommands = []
apply(makeCtx(), {})
t('slash /restart registered', registeredCommands.some((d) => d.name === 'restart'))
registeredCommands = [];
apply(makeCtx(), { enableCommand: false })
t('slash /restart disabled when enableCommand=false', !registeredCommands.some((d) => d.name === 'restart'))

process.exit = originalExit
const fails = results.filter((r) => !r.cond)
for (const r of results) console.log((r.cond ? '  ok  - ' : 'FAIL  - ') + r.name)
console.log(`\n${results.length - fails.length}/${results.length} passed`)
process.exit(fails.length ? 1 : 0)
