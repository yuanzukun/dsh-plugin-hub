// dsh-web-restart — 在 WebUI 里一键重启 DSH（host 端）
//
// 机制：
//   - 通过 webServer 服务注册一个同源 HTTP 端点 POST /api/_dsh/restart，
//     WebUI 里的"重启 DSH"按钮直接 fetch 它，不需要活跃会话/agent，最稳。
//   - 同时注册一个 slash 命令 /restart，可在对话里输入执行（内部走同一逻辑）。
//   - 端点被命中时：返回 200/202 并施放一点延迟让响应落盘，然后 process.exit(0)。
//     注意：dsh web 是单 Node 进程，host 一退出整个 UI 就断线。要想"重启后
//     还能回来"，必须由一个外部守护进程（macOS launchd KeepAlive / 一个 wrapper
//     脚本）在进程退出后把 `dsh web` 重新拉起。插件本身无法在死后自举。
//
// 为兼容"没有外部守护"的场景，提供两种退出策略：
//   - mode = "exit"（默认）：干净退出，靠 launchd/守护自动拉起。
//   - mode = "exec" ：在同进程内用 exec 替换自身（node 同路径重新跑 dsh web），
//                     适合手动从终端跑、没有守护的场景，退出后立即换新进程。
//   mode 在 cordis.patch.yml 里可配。

import z from '@deepseek-ai/schemastery'
import { spawn } from 'node:child_process'

const name = 'web-restart'
const inject = ['commands']
const Config = z.object({
  // exit | exec —— 见顶部注释
  mode: z.string().default('exit'),
  // 路径中的 secret token，防止局域网/其他来源误触发
  token: z.string().default(''),
  // 返回响应后等多久再退出/exec，让响应体尽量落盘
  flushMs: z.number().default(200),
  // 是否注册 slash 命令 /restart
  enableCommand: z.boolean().default(true)
})

/** 干净退出，把控制权交给外部守护（launchd KeepAlive 等）。 */
function doExit(log, flushMs) {
  log('dsh-web-restart: exiting cleanly; external supervisor should relaunch dsh web')
  setTimeout(() => process.exit(0), flushMs)
}

/**
* 用同进程 exec 自替换：node 重新运行本进程同样的 argv（dsh --profile web ...）。
* 适合没有外部守护、从终端手动启动的场景。
*/
function doExec(log, flushMs) {
  const args = process.argv.slice(1) // [script/entrypath, ...dsh args]
  const nodeCmd = process.execPath
  log('dsh-web-restart: exec-self node=%s argv=%j', nodeCmd, args)
  setTimeout(() => {
    try {
      process.execPath = nodeCmd
      process.once('disconnect', () => process.abort())
      const cp = spawnReload(nodeCmd, args)
      log('dsh-web-restart: spawned replacement pid=%s', cp.pid)
      // 让新进程接管，当前进程退出
      setTimeout(() => process.exit(0), 50)
    } catch (error) {
      log('dsh-web-restart: exec failed, exiting raw: %s', String(error?.message ?? error))
      process.exit(0)
    }
  }, flushMs)
}

function apply(ctx, config) {
  const cfg = {
    mode: config?.mode === 'exec' ? 'exec' : 'exit',
    token: config?.token ?? '',
    flushMs: config?.flushMs ?? 200,
    enableCommand: config?.enableCommand === undefined || config?.enableCommand === null ? true : Boolean(config.enableCommand)
  }

  const log = (...a) => ctx.logger.info(...a)

  /** 校验 token（若配置了）。返回 401 时不给 hint。 */
  function authorized(req) {
    if (!cfg.token) return true
    const header = req.headers?.['authorization'] ?? req.headers?.['x-dsh-restart-token']
    return header === cfg.token
  }

  const restart = () => {
    log('dsh-web-restart: restart requested (mode=%s)', cfg.mode)
    if (cfg.mode === 'exec') doExec(log, cfg.flushMs)
    else doExit(log, cfg.flushMs)
  }

  // ── HTTP 端点 ──────────────────────────────────────────────
  // 注意：cordis 的 ctx.effect(execute) 会立即执行 execute，返回值才是
  // 卸载时的清理函数。因此这里必须传 () => dispose（返回清理函数），
  // 而不能直接传 dispose —— 否则路由刚注册就被删掉（端点 404）。
  ctx.inject(['webServer'], (scope) => {
    const ws = scope.webServer
    const dispose = ws.register({
      kind: 'exact',
      path: '/api/_dsh/restart',
      handler: (req, res) => {
        try {
          const cors = {
            'access-control-allow-origin': req.headers?.origin ?? '*',
            'access-control-allow-methods': 'POST, OPTIONS',
            'access-control-allow-headers': 'content-type, accept, authorization, x-dsh-restart-token'
          }
          // CORS preflight：浏览器带自定义头/跨源时会先发 OPTIONS，必须放行
          if (req.method === 'OPTIONS') {
            res.writeHead(204, { ...cors, 'content-length': '0' })
            res.end()
            return
          }
          if (req.method !== 'POST') {
            res.writeHead(405, { 'content-type': 'application/json', ...cors })
            res.end(JSON.stringify({ ok: false, error: 'method-not-allowed' }))
            return
          }
          if (!authorized(req)) {
            res.writeHead(401, { 'content-type': 'application/json', ...cors })
            res.end(JSON.stringify({ ok: false, error: 'unauthorized' }))
            return
          }
          res.writeHead(202, { 'content-type': 'application/json', ...cors })
          res.end(JSON.stringify({ ok: true, mode: cfg.mode, note: 'restarting' }))
          // 响应已发给客户端，随后干净退出/自替换
          setImmediate(restart)
        } catch (error) {
          ctx.logger.warn('dsh-web-restart: handler error %s', String(error?.message ?? error))
          try {
            res.writeHead(500, { 'content-type': 'application/json' })
            res.end(JSON.stringify({ ok: false, error: 'internal' }))
          } catch {
            /* res may be gone */
          }
        }
      }
    })
    // 正确姿势：effect 主体返回清理函数，卸载时才调用 dispose
    ctx.effect(() => dispose, 'web-restart: http route')
  })

  // ── slash 命令（可选）──────────────────────────────────────
  if (cfg.enableCommand) {
    ctx.commands.register({
      name: 'restart',
      description: 'Restart the dsh web process (requires an external supervisor to bring the UI back)',
      input: { hint: 'confirm' },
      handler: ({ rawInput }) => {
        const arg = rawInput.trim().toLowerCase()
        if (arg === 'y' || arg === 'yes' || arg === 'confirm' || arg === '') {
          restart()
          return { kind: 'success', text: 'Restarting dsh web… (UI will drop briefly; external supervisor should relaunch it.)' }
        }
        return { kind: 'error', text: 'Restart dsh web? This kills the process. Confirm with: /restart confirm' }
      }
    })
  }
}

export { apply, inject, name, Config }
