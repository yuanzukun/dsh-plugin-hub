#!/bin/zsh
# takeover.sh — 把当前手动运行的 DSH web 平稳地交给 launchd（com.dsh.web）托管。
#
# 顺序：
#   1) 找到监听 3080 的进程并优雅终止（清掉手动起的实例）。
#   2) launchctl bootout 旧的 com.dsh.web（即便没加载也容错）。
#   3) bootstrap 新 agent → 由 launchd 用 dsh-web-start.sh 启动全新 dsh web。
#   4) 轮询端口/端点，确认服务与重启端点就绪。
#
# 会在脚本进程内一次做完，避免服务重启后跨进程断点。

set -u
LOG="$HOME/.dsh/dsh-web-takeover.log"
exec > >(tee "$LOG") 2>&1
echo "=== takeover start $(date) ==="

LA="$HOME/Library/LaunchAgents"
PLIST="$LA/com.dsh.web.plist"
LABEL="com.dsh.web"
UID="$(id -u)"
DOMAIN="gui/$UID"
PORT="${PORT:-3080}"

# 1) 终止当前占用端口的实例（无论是否手动起的）
PIDS=$(lsof -nP -tiTCP:"$PORT" -sTCP:LISTEN 2>/dev/null)
if [ -n "$PIDS" ]; then
  echo "stopping manual instance(s) on port $PORT: $PIDS"
  for p in $PIDS; do
    # 优雅终止；若残留再强杀
    kill "$p" 2>/dev/null
  done
  sleep 2
  for p in $PIDS; do
    if kill -0 "$p" 2>/dev/null; then kill -9 "$p" 2>/dev/null; fi
  done
  # 等端口释放
  for i in {1..30}; do
    if ! lsof -nP -tiTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1; then break; fi
    sleep 1
  done
else
  echo "port $PORT free; nothing manual to stop"
fi

# 2) 清理旧的 agent 状态
launchctl bootout "$DOMAIN/$LABEL" 2>/dev/null || true
launchctl remove "$LABEL" 2>/dev/null || true

# 3) 确保 plist 就位
if [ ! -f "$PLIST" ]; then
  echo "ERROR: plist missing: $PLIST"
  exit 1
fi
cp -f "$PLIST" "$PLIST"  # no-op; ensure present

launchctl bootstrap "$DOMAIN" "$PLIST" 2>/dev/null || true
launchctl enable "$DOMAIN/$LABEL" 2>/dev/null || true
launchctl kickstart -k "$DOMAIN/$LABEL" 2>/dev/null || true

# 4) 轮询就绪（用根路径探测，绝不误触重启端点）
echo "waiting for dsh web on port $PORT …"
ok=0
for i in {1..60}; do
  if curl -sf -o /dev/null "http://127.0.0.1:$PORT/" --max-time 2; then ok=1; break; fi
  sleep 2
done

echo "=== takeover done, ok=$ok ==="
echo "launchd state:"; launchctl print "$DOMAIN/$LABEL" 2>/dev/null | head -20
echo "server log tail:"; tail -n 20 "$HOME/.dsh/dsh-web.launchd.err.log" 2>/dev/null
