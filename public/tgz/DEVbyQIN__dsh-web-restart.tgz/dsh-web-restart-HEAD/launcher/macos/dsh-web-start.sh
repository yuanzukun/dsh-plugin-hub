#!/bin/zsh
# dsh web — launch under launchd that auto-restarts on crash/exit.
#
# Why a wrapper: launchd LaunchAgents run with a minimal environment, so we
# (re)establish the Node/npm path explicitly. We invoke `node` directly on the
# built dsh entry so we never depend on an interactive shell or nvm auto-load.
#
# Resolution order (override any by exporting the env var):
#   NODE_BIN   — node executable. Auto-detected from PATH or common nvm paths.
#   DSH_ENTRY  — dsh CLI entry (lib/bin.js). Auto-detected via `which dsh`.
#   DSH_WEB_PORT — port dsh web listens on (default 3080).
#   DSH_HOME   — DSH data dir (default ~/.dsh).

# ---- auto-detect node ----
if [ -z "${NODE_BIN:-}" ]; then
  NODE_BIN="$(command -v node 2>/dev/null)"
fi
if [ -z "${NODE_BIN:-}" ]; then
  # common nvm layout: newest installed version wins
  for v in "$HOME"/.nvm/versions/node/*/bin/node; do
    [ -x "$v" ] && NODE_BIN="$v"
  done
fi
if [ -z "${NODE_BIN:-}" ] || [ ! -x "$NODE_BIN" ]; then
  echo "dsh-web-start: cannot find node (set NODE_BIN)" >&2
  exit 1
fi

# ---- auto-detect dsh entry ----
if [ -z "${DSH_ENTRY:-}" ]; then
  DSH_BIN="$(command -v dsh 2>/dev/null)"
  if [ -n "$DSH_BIN" ] && [ -f "$DSH_BIN" ]; then
    # resolve symlink chain to the real bin.js
    REAL="$(readlink "$DSH_BIN" 2>/dev/null || echo "$DSH_BIN")"
    case "$REAL" in
      /*) DSH_ENTRY="$REAL" ;;
      *) DSH_ENTRY="$(cd "$(dirname "$DSH_BIN")" && readlink "$REAL" 2>/dev/null || echo "$REAL")" ;;
    esac
    # readlink may be relative; normalize against the bin dir
    case "$DSH_ENTRY" in
      /*) ;;
      *) DSH_ENTRY="$(cd "$(dirname "$DSH_BIN")" && cd "$(dirname "$DSH_ENTRY")" && pwd)/$(basename "$DSH_ENTRY")" ;;
    esac
  fi
fi
if [ -z "${DSH_ENTRY:-}" ] || [ ! -f "$DSH_ENTRY" ]; then
  echo "dsh-web-start: cannot find dsh entry (set DSH_ENTRY)" >&2
  exit 1
fi

PORT="${DSH_WEB_PORT:-3080}"

# Make `dsh`/`pnpm` available to anything DSH spawns (tools, plugins).
export PATH="$(dirname "$NODE_BIN"):/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"

# Where DSH keeps its data (default: ~/.dsh). Overridable.
export DSH_HOME="${DSH_HOME:-$HOME/.dsh}"

# If the port is still held by a previous instance (e.g. during takeover),
# wait up to 60s for it to free before starting; otherwise dsh web would
# fail to bind and launchd's KeepAlive would thrash.
i=0
while [ $i -lt 60 ] && /usr/sbin/lsof -nP -iTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1; do
  sleep 1
  i=$((i + 1))
done

exec "${NODE_BIN}" "${DSH_ENTRY}" --profile web "$@"
