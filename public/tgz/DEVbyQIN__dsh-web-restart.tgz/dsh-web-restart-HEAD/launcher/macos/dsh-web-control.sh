#!/bin/zsh
# dsh-web launcher helper — install / uninstall / start / stop / restart / status
#
# Usage:
#   ./dsh-web-control.sh install     # install launchd agent (auto-start at login)
#   ./dsh-web-control.sh uninstall   # stop + bootout + remove plist
#   ./dsh-web-control.sh start       # launchctl kickstart
#   ./dsh-web-control.sh stop        # launchctl bootout (stop does NOT disable auto-start)
#   ./dsh-web-control.sh restart     # stop then start
#   ./dsh-web-control.sh status      # current launchd state
#
# Once installed, the launchd agent keeps `dsh web` alive. The WebUI Restart
# button (from dsh-web-restart) calls process.exit() and the agent relaunches.
#
# Notes for contributors:
#   - The start script is copied to ~/Library/Application Support/dsh-web/
#     because macOS TCC protects ~/Documents etc. — launchd cannot read
#     scripts there.
#   - The plist uses __DSH_*__ placeholders; install rewrites them with the
#     actual absolute paths before bootstrapping.

set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
PLIST_SRC="$HERE/com.dsh.web.plist"
SCRIPT_SRC="$HERE/dsh-web-start.sh"
PLIST_DIR="$HOME/Library/LaunchAgents"
PLIST="$PLIST_DIR/com.dsh.web.plist"
APP_SUPPORT="$HOME/Library/Application Support/dsh-web"
INSTALLED_SCRIPT="$APP_SUPPORT/dsh-web-start.sh"
LABEL="com.dsh.web"
MY_UID="$(id -u)"
DOMAIN="gui/$MY_UID"
DSH_HOME="${DSH_HOME:-$HOME/.dsh}"

mkdir -p "$PLIST_DIR" "$APP_SUPPORT"
chmod +x "$SCRIPT_SRC"

cmd="${1:-help}"

bootstrap() {
  launchctl bootout "$DOMAIN/$LABEL" 2>/dev/null || true
  launchctl bootstrap "$DOMAIN" "$PLIST"
  launchctl enable "$DOMAIN/$LABEL"
  launchctl kickstart "$DOMAIN/$LABEL"
}

case "$cmd" in
  install)
    # 1) copy the start script to a launchd-readable location (TCC-safe)
    cp "$SCRIPT_SRC" "$INSTALLED_SCRIPT"
    chmod 755 "$INSTALLED_SCRIPT"
    # 2) render the plist with real paths
    sed -e "s|__DSH_START_SCRIPT__|$INSTALLED_SCRIPT|g" \
        -e "s|__DSH_HOME__|$DSH_HOME|g" \
        -e "s|__DSH_LOG_DIR__|$DSH_HOME|g" \
        "$PLIST_SRC" > "$PLIST"
    plutil -lint "$PLIST"
    # 3) bootstrap
    bootstrap
    echo "dsh web agent installed and running."
    echo "  plist:  $PLIST"
    echo "  script: $INSTALLED_SCRIPT"
    echo "  logs:   $DSH_HOME/dsh-web.launchd.{log,err.log}"
    ;;
  uninstall)
    launchctl bootout "$DOMAIN/$LABEL" 2>/dev/null || true
    rm -f "$PLIST"
    echo "uninstalled (running process, if any, is left untouched by launchd)."
    ;;
  start)
    launchctl bootstrap "$DOMAIN" "$PLIST" 2>/dev/null || true
    launchctl enable "$DOMAIN/$LABEL"
    launchctl kickstart "$DOMAIN/$LABEL"
    echo "started."
    ;;
  stop)
    launchctl bootout "$DOMAIN/$LABEL" 2>/dev/null || true
    echo "stopped (auto-start remains installed)."
    ;;
  restart)
    launchctl bootout "$DOMAIN/$LABEL" 2>/dev/null || true
    launchctl bootstrap "$DOMAIN" "$PLIST" 2>/dev/null || true
    launchctl kickstart "$DOMAIN/$LABEL"
    echo "restarted."
    ;;
  status)
    launchctl print "$DOMAIN/$LABEL" 2>/dev/null || echo "not loaded"
    ;;
  *)
    echo "usage: $0 {install|uninstall|start|stop|restart|status}"
    ;;
esac
