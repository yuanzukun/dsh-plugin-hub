-- DSH Web launcher.app — 点击图标启动/确保 DeepSeek Harness WebUI 运行
-- 通过 launchd (com.dsh.web) 保证进程常驻；未安装守护时回退为直接后台启动。
--
-- 依赖：dsh-web-control.sh install 已执行（把启动脚本装到
--       ~/Library/Application Support/dsh-web/）。若未安装，直接运行
--       dsh-web-start.sh 的绝对路径也可（见下方 dshApp）。

on run
	-- 由 shell 展开 $HOME，避免硬编码用户名
	set homeDir to do shell script "echo $HOME"
	set dshApp to homeDir & "/Library/Application Support/dsh-web/dsh-web-start.sh"
	set myUid to do shell script "id -u"
	set portOpen to portOpenOn(3080)

	if portOpen then
		-- 已在运行：直接打开浏览器
		openBrowser()
	else
		-- 尝试通过 launchd 拉起（守护已装好时最稳；无需管理员权限）
		try
			do shell script "launchctl kickstart gui/" & myUid & "/com.dsh.web"
		on error
			-- 无守护：回退为直接后台启动脚本
			try
				do shell script "nohup '" & dshApp & "' >/dev/null 2>&1 &"
			end try
		end try
		-- 等待端口就绪后打开浏览器
		repeat 30 times
			delay 1
			if portOpenOn(3080) then exit repeat
		end repeat
		openBrowser()
	end if
end run

on openBrowser()
	try
		do shell script "open http://127.0.0.1:3080"
	end try
end openBrowser

on portOpenOn(p)
	try
		set out to do shell script "lsof -nP -iTCP:" & p & " -sTCP:LISTEN | grep -q . && echo yes || echo no"
		return (out is "yes")
	on error
		return false
	end try
end portOpenOn
