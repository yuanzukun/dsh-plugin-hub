/** file-op extraction: tool classification, arg parsing, grouping. */
import { describe, expect, it } from 'vitest'
import { extractFileOps, groupByFile, knownContentBefore } from '../src/client/file-ops.ts'
import type { ToolResultNode } from '@deepseek-ai/dsh-client-ui-conversation/client'

/** Minimal settled tool-result node fixture; content defaults empty. */
function result(callId: string, name: string, args: Record<string, unknown>, time: number, isError = false, content: unknown[] = []): ToolResultNode {
  return {
    kind: 'tool-result',
    seq: time,
    time,
    callId,
    call: { name, argsRaw: JSON.stringify(args) },
    callTime: time,
    content,
    isError,
    subCalls: [],
  } as unknown as ToolResultNode
}

describe('extractFileOps', () => {
  it('keeps op element identities stable across calls with unchanged nodes (streaming re-render guard)', () => {
    // The component subscribes with an element-identity equality so a
    // streaming delta that settles no new file op skips its re-render; the
    // per-node cache behind this must return the SAME op objects (and skip
    // re-parsing payloads) while the node objects are unchanged.
    const nodes = [
      result('r1', 'read', { file_path: 'a.ts' }, 1, false, [{ text: 'body' }]),
      result('w1', 'write', { file_path: 'b.ts', content: 'new body' }, 2),
    ]
    const first = extractFileOps(nodes, [])
    const second = extractFileOps(nodes, [])
    expect(second).not.toBe(first) // fresh arrays…
    expect(second[0]).toBe(first[0]) // …but stable elements
    expect(second[1]).toBe(first[1])
    // A rebuilt node (settled result replaces the running call) misses the
    // cache and yields a fresh op object — no stale payload reuse.
    const settled = [nodes[1]!, result('r1', 'read', { file_path: 'a.ts' }, 1, false, [{ text: 'changed' }])]
    const third = extractFileOps(settled, [])
    expect(third.find(op => op.callId === 'r1')?.read).toBe('changed')
  })

  it('extracts read/write/edit with paths and payloads', () => {
    const ops = extractFileOps([
      result('r1', 'read', { file_path: 'a.ts' }, 1),
      result('w1', 'write', { file_path: 'b.ts', content: 'new body' }, 2),
      result('e1', 'edit', { file_path: 'c.ts', old_string: 'x', new_string: 'y' }, 3),
    ], [])
    expect(ops.map(op => op.kind)).toEqual(['edit', 'write', 'read'])
    expect(ops[2]!.path).toBe('a.ts')
    expect(ops[1]!.content).toBe('new body')
    expect(ops[0]!.edit).toEqual({ oldString: 'x', newString: 'y' })
  })

  it('ignores non-file tools and malformed args', () => {
    const bad = { kind: 'tool-result', seq: 9, time: 9, callId: 'x', call: { name: 'pwsh', argsRaw: '{oops' }, content: [], isError: false, subCalls: [] } as unknown as ToolResultNode
    const ops = extractFileOps([bad, result('g', 'glob', { pattern: '*' }, 8)], [])
    expect(ops).toHaveLength(0)
  })

  it('recurses into parent-call subCalls (run_code-style dispatch)', () => {
    const innerEdit = result('inner1', 'edit', { file_path: 'a.ts', old_string: 'x', new_string: 'y' }, 1)
    const parent = {
      kind: 'tool-result' as const,
      seq: 2, time: 2, callId: 'p1',
      call: { name: 'run_code', argsRaw: '{}' },
      callTime: 2, content: [], isError: false,
      subCalls: [innerEdit],
    }
    const ops = extractFileOps([parent as unknown as ToolResultNode], [])
    expect(ops).toHaveLength(1)
    expect(ops[0]!.kind).toBe('edit')
    expect(ops[0]!.path).toBe('a.ts')
  })

  it('expands present-tool calls into one write op per file', () => {
    const ops = extractFileOps([
      result('p1', 'present', { files: [{ path: 'docs/report.md', description: 'd1' }, { path: 'out/chart.png', description: 'd2' }] }, 7),
      result('p2', 'present', { files: 'not-an-array' }, 8),
      result('p3', 'present', { files: [{ description: 'no-path' }] }, 9),
    ], [])
    expect(ops).toHaveLength(2)
    expect(ops.every(op => op.kind === 'write')).toBe(true)
    expect(new Set(ops.map(op => op.path))).toEqual(new Set(['docs/report.md', 'out/chart.png']))
    expect(ops.every(op => op.callId === 'p1')).toBe(true)
  })

  it('carries error and running flags', () => {
    const ops = extractFileOps([result('e', 'write', { file_path: 'a', content: 'z' }, 5, true)], [])
    expect(ops[0]!.isError).toBe(true)
    const running = extractFileOps([], [{ callId: 'r', name: 'edit', argsRaw: JSON.stringify({ file_path: 'q' }), turn: 1, step: 1, time: 6, subCalls: [] }])
    expect(running[0]!.running).toBe(true)
  })

  it('captures the result text as errorText for errored ops of every kind', () => {
    const errText = [{ type: 'text', text: 'cannot write "a": not found' }]
    const ops = extractFileOps([
      result('w', 'write', { file_path: 'a', content: 'z' }, 1, true, errText),
      result('e', 'edit', { file_path: 'b', old_string: 'x', new_string: 'y' }, 2, true, errText),
      result('r', 'read', { file_path: 'c' }, 3, true, errText),
    ], [])
    for (const op of ops) expect(op.errorText).toBe('cannot write "a": not found')
  })

  it('omits errorText on successful ops', () => {
    const ops = extractFileOps([result('w', 'write', { file_path: 'a', content: 'z' }, 1, false, [{ type: 'text', text: 'ok' }])], [])
    expect(ops[0]!.errorText).toBeUndefined()
  })
})

describe('groupByFile / knownContentBefore', () => {
  it('groups by path with newest file first', () => {
    const ops = extractFileOps([
      result('1', 'read', { file_path: 'old.ts' }, 1),
      result('2', 'write', { file_path: 'new.ts', content: 'n' }, 2),
    ], [])
    const groups = groupByFile(ops)
    expect([...groups.keys()]).toEqual(['new.ts', 'old.ts'])
  })

  it('recovers prior content from an earlier write', () => {
    const ops = extractFileOps([
      result('1', 'write', { file_path: 'a.ts', content: 'first' }, 1),
      result('2', 'write', { file_path: 'a.ts', content: 'second' }, 2),
    ], [])
    const before = knownContentBefore(ops, 'a.ts', ops[0]!)
    expect(before).toBe('first')
  })
})
