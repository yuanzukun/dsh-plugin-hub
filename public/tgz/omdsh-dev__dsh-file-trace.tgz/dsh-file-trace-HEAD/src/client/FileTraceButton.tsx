/**
 * FileTraceButton: the session-header utilities trigger. Derives the file
 * operation list live from the Chat view snapshot (pure derivation each
 * render — no store, no listener), shows a count badge, and on click opens
 * a self-contained fixed-position drawer listing every touched file with a
 * line-diff view (del red / add green / mod blue via --dsw state tokens).
 */
import { Component, useEffect, useMemo, useRef, useState, type CSSProperties, type PointerEvent as ReactPointerEvent, type ReactElement, type ReactNode } from 'react'
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots'
import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-ui-conversation/client'
import type {} from '@deepseek-ai/dsh-client-ui-chat/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import { extractFileOps, groupByFile, knownContentBefore, parseReadContent, parseReadLines, stitchSegmentReads, type FileOp } from './file-ops.ts'
import { renderCompatBanner } from './compat.ts'
import { PLUGIN_VERSION, fetchLatestTag, compareSemver, runUpdate, updatePrompt } from './update-check.ts'
import { diffLines, formatBytes, buildDiffSegments, diffInline, coalesceInline, MIN_FOLD, type DiffRow, type InlineDiff } from './diff.ts'
import { scanLine, isColored, langOfPath, hasBlockComment, type TokenType, type CodeToken } from './highlight.ts'
import { MarkdownView, isMarkdownPath, assetUrl } from './markdown.tsx'
import type { FileTraceKey } from './locales.ts'
import { redactText } from './redact.ts'
import css from './FileTrace.module.css'

/** Latest main-view session id (module-level: index.ts keeps it in sync via uiSession). */
const currentSessionIdStore: { value: string; listeners: Set<() => void> } = { value: '', listeners: new Set() }
/** Called by the plugin body when the main-view session changes. */
export function setCurrentSessionId(id: string): void {
  currentSessionIdStore.value = id
  for (const listener of [...currentSessionIdStore.listeners]) listener()
}

/** Renders the remediation banner once when the drawer subtree throws. */
class DrawerErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean; message: string }> {
  override state = { failed: false, message: '' }
  static getDerivedStateFromError(error: unknown): { failed: boolean; message: string } { return { failed: true, message: String((error as Error)?.message ?? error) } }
  override componentDidCatch(error: unknown): void {
    renderCompatBanner(
      'dsh-file-trace',
      '@dsh-external/dsh-file-trace',
      `渲染出错：${String((error as Error)?.message ?? error)}`,
      ['请将插件更新到适配当前 DSH 的版本；', '或在插件目录执行 pnpm run build 后刷新页面。'],
    )
  }
  override render(): ReactNode {
    if (this.state.failed) {
      return (
        <div className={css.drawerError} data-file-trace-error>
          渲染出错：{this.state.message}
        </div>
      )
    }
    return this.props.children
  }
}

/** Long diff lines fold to one ellipsized row; the threshold is the char count. */
const FOLD_THRESHOLD = 120

/** Token class -> CSS color class ('' inherits the row's diff color). */
const TOKEN_CLASS: Readonly<Record<TokenType, string>> = {
  plain: '',
  comment: css.tokComment ?? '',
  string: css.tokString ?? '',
  keyword: css.tokKeyword ?? '',
  number: css.tokNumber ?? '',
  type: css.tokType ?? '',
  function: css.tokFunction ?? '',
  macro: css.tokMacro ?? '',
}

/** One token span's class list: its color class, plus the change tint. */
function tokenSpanClass(type: TokenType, changed: boolean): string {
  const color = TOKEN_CLASS[type]
  return changed ? `${color} ${css.inlineChange}` : color
}

/** Render scanned tokens as colored nodes; uncolored runs stay text. */
function tokensToNodes(tokens: readonly CodeToken[], changed = false): ReactNode[] {
  const nodes: ReactNode[] = []
  for (const token of tokens) {
    if (!changed && !isColored(token)) nodes.push(token.text)
    else nodes.push(<span key={String(nodes.length)} className={tokenSpanClass(token.type, changed)}>{token.text}</span>)
  }
  return nodes
}

/** Per-row block-comment entry state for a diff: the old side threads along
 *  old-line order and the new side along new-line order (the LCS row order
 *  preserves both), so multi-line comments color correctly on each side. */
function diffBlockEntries(rows: readonly DiffRow[], lang: string | undefined): Map<DiffRow, boolean> {
  const entries = new Map<DiffRow, boolean>()
  if (!hasBlockComment(lang)) return entries
  let oldIn = false
  let newIn = false
  for (const row of rows) {
    const isOld = row.oldLine !== undefined
    const isNew = row.newLine !== undefined
    entries.set(row, isOld ? oldIn : newIn)
    if (isOld) oldIn = scanLine(row.text, lang, oldIn).inBlock
    if (isNew) newIn = scanLine(row.text, lang, newIn).inBlock
  }
  return entries
}

/** Trigger props: session standard kit + locale seat. */
/**
 * Consumed props only: the header slot hands the full session standard props
 * (useSession/useInput/…); the better-sidebar tab mount supplies the same
 * conversation selector hook from the session binding. A component accepting
 * a subset stays assignable where the full set is given.
 */
export type FileTraceButtonProps = PropsLocale<'fileTrace'> & {
  useConversation: <S>(sel: (snapshot: ConversationSnapshot) => S, eq?: (a: S, b: S) => boolean) => S
  sessionId?: string
  /** Embedded mount (better-sidebar tab): no trigger button, the drawer fills
   * its container statically — no drag, resize, docking, or Escape close. */
  embedded?: boolean
}

/** Whether a path is an HTML document eligible for the render preview. */
function isHtmlPath(path: string): boolean {
  return /\.(html?|xhtml)$/i.test(path)
}

/** Whether a path is a PDF document eligible for the render preview. */
function isPdfPath(path: string): boolean {
  return /\.pdf$/i.test(path)
}

/** Whether a path is an SVG document eligible for the render preview (the
 *  preview renders the op's own payload, so no absolute path is required). */
function isSvgPath(path: string): boolean {
  return /\.svg$/i.test(path)
}

/** Whether a path is absolute (drive / POSIX root / UNC). The asset route
 *  serves by absolute path only: a relative op path resolves against the
 *  host process cwd, not the session workspace, so it cannot render. */
function isAbsolutePath(path: string): boolean {
  const rooted = path.startsWith('/') || path.startsWith('\\')
  return /^[A-Za-z]:/.test(path) || rooted
}

/** The browser-native PDF preview of one traced PDF file: the bytes stream
 *  through the host asset route and re-wrap into an explicitly-typed Blob —
 *  a direct iframe src can fall back to a download when the MIME arrives
 *  wrong (old host process / proxy caches application/octet-stream). */
function PdfFrame(props: { path: string; t: (key: FileTraceKey) => string }) {
  const [state, setState] = useState<{ kind: 'loading' } | { kind: 'ready'; url: string } | { kind: 'error'; message: string }>({ kind: 'loading' })
  useEffect(() => {
    const controller = new AbortController()
    let objectUrl: string | undefined
    setState({ kind: 'loading' })
    void (async () => {
      try {
        const response = await fetch(assetUrl(props.path), { signal: controller.signal })
        if (!response.ok) throw new Error('HTTP ' + String(response.status))
        const bytes = await response.arrayBuffer()
        if (controller.signal.aborted) return
        objectUrl = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }))
        setState({ kind: 'ready', url: objectUrl })
      } catch (error) {
        if (!controller.signal.aborted) setState({ kind: 'error', message: error instanceof Error ? error.message : String(error) })
      }
    })()
    return () => {
      controller.abort()
      if (objectUrl !== undefined) URL.revokeObjectURL(objectUrl)
    }
  }, [props.path])
  if (state.kind === 'loading') return <div className={css.mdPane} data-file-trace-pdf-loading>{props.t('pdf.loading')}</div>
  if (state.kind === 'error') return <div className={css.mdPane} data-file-trace-pdf-error role="alert">{state.message}</div>
  return (
    <div className={css.mdPane} data-file-trace-pdf-pane>
      <iframe className={css.htmlFrame} title={props.path} src={state.url} />
    </div>
  )
}

/** The rendered preview of one traced SVG file: the op's own payload wraps
 *  into an image/svg+xml Blob URL for an <img> — SVG scripts never execute in
 *  image context, so no sandbox staging is needed (unlike the HTML viewer),
 *  and no host route is involved. */
function SvgFrame(props: { path: string; src: string; t: (key: FileTraceKey) => string }) {
  const [state, setState] = useState<{ kind: 'loading' } | { kind: 'url'; url: string; via: 'asset' | 'payload' } | { kind: 'error' }>({ kind: 'loading' })
  const [imgFailed, setImgFailed] = useState(false)
  useEffect(() => {
    const controller = new AbortController()
    let objectUrl: string | undefined
    setState({ kind: 'loading' })
    void (async () => {
      // Source order: (1) the host asset route — the file's real bytes, immune
      // to any session-payload corruption, but 404 on a host half older than
      // the SVG whitelist; (2) the op payload as an image/svg+xml blob, only
      // after DOMParser proves it well-formed XML so a corrupted read can
      // never show a silent broken image.
      try {
        const response = await fetch(assetUrl(props.path), { signal: controller.signal })
        if (!response.ok) throw new Error('HTTP ' + String(response.status))
        const blob = await response.blob()
        if (controller.signal.aborted) return
        objectUrl = URL.createObjectURL(blob)
        setState({ kind: 'url', url: objectUrl, via: 'asset' })
        return
      } catch { /* asset route unavailable: payload below */ }
      try {
        if (controller.signal.aborted) return
        const parsed = new DOMParser().parseFromString(props.src, 'image/svg+xml')
        if (parsed.getElementsByTagName('parsererror').length > 0) throw new Error('payload XML invalid')
        objectUrl = URL.createObjectURL(new Blob([props.src], { type: 'image/svg+xml' }))
        setState({ kind: 'url', url: objectUrl, via: 'payload' })
      } catch {
        if (!controller.signal.aborted) setState({ kind: 'error' })
      }
    })()
    return () => {
      controller.abort()
      if (objectUrl !== undefined) URL.revokeObjectURL(objectUrl)
    }
  }, [props.path, props.src])
  if (state.kind === 'loading') return <div className={css.mdPane} data-file-trace-svg-pane data-svg-state="loading">{props.t('pdf.loading')}</div>
  if (state.kind === 'error') return <div className={css.mdPane} data-file-trace-svg-missing role="alert">{props.t('svg.missing')}</div>
  // A broken <img> falls back to a sandboxed iframe (scripts blocked, SMIL
  // animations still run): the sandbox keeps SVG's same-origin script risk
  // inert in both shapes.
  if (imgFailed) {
    return (
      <div className={css.mdPane} data-file-trace-svg-pane data-svg-state="iframe">
        <iframe className={css.htmlFrame} title={props.path} src={state.url} sandbox="" />
      </div>
    )
  }
  return (
    <div className={css.mdPane} data-file-trace-svg-pane data-svg-state={state.via === 'asset' ? 'img-asset' : 'img-payload'}>
      <img className={css.mdImg} src={state.url} alt={props.path} onError={() => { setImgFailed(true) }} />
    </div>
  )
}

/** Diff material for one operation, computed at open time.
 * For an edit the model's payload is only the changed snippet, so a hunched
 * diff needs the file's prior full content: when known (from an earlier
 * write/read in the window) apply the replacement to reconstruct the new full
 * content and diff whole files; otherwise fall back to the snippet itself. */
function diffOf(op: FileOp, prior: string | undefined): readonly DiffRow[] {
  if (op.kind === 'read') return []
  if (op.kind === 'edit' && op.edit !== undefined) {
    const { oldString, newString } = op.edit
    if (prior !== undefined && prior.includes(oldString)) {
      const newFile = prior.replace(oldString, newString)
      return diffLines(prior, newFile)
    }
    return diffLines(oldString, newString)
  }
  if (op.kind === 'write') {
    const content = op.content ?? ''
    // A write is an authoritative full-content op: when the prior state is
    // unknown or identical to the written content, render it as all-added
    // (every line a green +) rather than a no-op context list.
    const old = prior !== undefined && prior !== content ? prior : undefined
    return diffLines(old ?? '', content)
  }
  return []
}

/** Present-tool delivery pane: the op records no inline content (the file was written by code), so read the current on-disk bytes through the host asset route and render them. The owning session id arrives as the session-scope slot prop (authoritative for resolving the workspace-relative path); the module store synced from uiSession stays only as a fallback for hosts without the prop. */
function PresentedPane({ path, sessionId: sessionProp, rendered, t }: { readonly path: string; readonly sessionId?: string | undefined; readonly rendered: boolean; readonly t: (key: FileTraceKey) => string }): ReactElement {
  const [state, setState] = useState<{ kind: 'loading' } | { kind: 'error' } | { kind: 'ok'; text: string }>({ kind: 'loading' })
  useEffect(() => {
    const controller = new AbortController()
    setState({ kind: 'loading' })
    const sessionId = sessionProp !== undefined && sessionProp !== '' ? sessionProp : currentSessionIdStore.value
    const url = /^[a-zA-Z]:[\\/]/.test(path) || path.startsWith('/') || path.startsWith('\\\\')
      ? assetUrl(path)
      : sessionId === '' ? assetUrl(path) : `${assetUrl(path)}&session=${encodeURIComponent(sessionId)}`
    fetch(url, { signal: controller.signal })
      .then(async (response): Promise<void> => {
        if (!response.ok) throw new Error(String(response.status))
        setState({ kind: 'ok', text: await response.text() })
      })
      .catch(() => { if (!controller.signal.aborted) setState({ kind: 'error' }) })
    return () => { controller.abort() }
  }, [path, sessionProp])
  if (state.kind === 'loading') return <div className={css.mdPane} data-file-trace-present-loading>{t('present.loading')}</div>
  if (state.kind === 'error') return <div className={css.mdPane} data-file-trace-present-error role="alert">{t('present.missing')}</div>
  if (rendered && isMarkdownPath(path)) {
    return <div className={css.readContent} data-file-trace-present><MarkdownView src={state.text} baseDir={path} /></div>
  }
  return (
    <div className={css.readContent} data-file-trace-present>
      {state.text.split('\n').map((line, index) => (
        <div key={String(index)} className={css.readRow}>
          <span className={css.lineNo}>{String(index + 1)}</span>
          <span className={css.text}>{line}</span>
        </div>
      ))}
    </div>
  )
}

/** The header trigger button plus its drawer. */
export function FileTraceButton({ useConversation, t, sessionId, embedded = false }: FileTraceButtonProps) {
  // Element-identity equality: with per-node cached extraction (file-ops.ts),
  // ops elements are stable objects, so a streaming delta that settles no new
  // file op reuses the previous array contents and skips this re-render
  // entirely instead of rebuilding the drawer per text chunk.
  const opsEqual = (a: readonly FileOp[], b: readonly FileOp[]): boolean =>
    a === b || (a.length === b.length && a.every((op, i) => op === b[i]))
  const rawOps = useConversation((conversation: ConversationSnapshot) => {
    const chat = conversation.views.get('chat')
    return extractFileOps(chat?.legacy.nodes ?? [], chat?.legacy.runningCalls ?? [])
  }, opsEqual)
  // Stitch is user-triggered (拼合分段读取 button in the drawer head): the
  // merged read replaces that file's segment rows in the list.
  const [stitchOn, setStitchOn] = useState(false)
  const ops = useMemo(() => (stitchOn ? stitchSegmentReads(rawOps) : rawOps), [rawOps, stitchOn])
  const stitchable = useMemo(() => {
    const readsByPath = new Map<string, number>()
    for (const op of rawOps) {
      if (op.kind !== 'read' || op.read === undefined) continue
      readsByPath.set(op.path, (readsByPath.get(op.path) ?? 0) + 1)
    }
    for (const n of readsByPath.values()) if (n >= 2) return true
    return false
  }, [rawOps])
  const groups = useMemo(() => groupByFile(ops), [ops])
  const [open, setOpen] = useState(embedded)
  // Update check: newest tag from the public mirror, once per open.
  const [latestTag, setLatestTag] = useState<string | undefined>(undefined)
  // True when the version check could not reach the network (shown in the drawer head).
  const [checkFailed, setCheckFailed] = useState(false)
  const [updating, setUpdating] = useState(false)
  const [updateMsg, setUpdateMsg] = useState<string | null>(null)
  const [selected, setSelected] = useState<{ path: string; op: FileOp } | null>(null)
  // Markdown reading mode for .md files: replaces the raw/diff pane with a
  // rendered document (read = file content; write/edit = resulting content).
  const [mdReading, setMdReading] = useState(false)
  // Delivered (present-only) files default to the rendered reading mode; the
  // header toggle flips this one independently of read-op markdown viewing.
  const [presentReading, setPresentReading] = useState(true)
  // HTML render mode for .html/.htm/.xhtml files: preview the (redacted)
  // document in a sandboxed iframe instead of the raw/diff view.
  const [htmlReading, setHtmlReading] = useState(false)
  // Sandbox strictness for the render iframe: 'strict' (no scripts),
  // 'script' (allow-scripts, opaque origin), 'relaxed' (allow-scripts + a
  // permissions policy for autoplay/fullscreen). Default 'script'.
  const [htmlSandbox, setHtmlSandbox] = useState<'strict' | 'script' | 'relaxed'>('script')
  // PDF render mode for .pdf files: the browser-native viewer over the host
  // asset route (see PdfFrame). Reset per selected op like the other modes.
  const [pdfReading, setPdfReading] = useState(false)
  // SVG render mode for .svg files: an <img> over the host asset route.
  // Reset per selected op like the other modes.
  const [svgReading, setSvgReading] = useState(false)
  const SANDBOX_ATTR: Record<'strict' | 'script' | 'relaxed', string> = {
    strict: '',
    script: 'allow-scripts',
    relaxed: 'allow-scripts',
  }
  const PERMISSIONS_ATTR: Record<'strict' | 'script' | 'relaxed', string> = {
    strict: '',
    script: '',
    relaxed: 'autoplay; fullscreen',
  }
  // Long diff lines fold to one ellipsized row; the set holds expanded row keys.
  const [expandedLines, setExpandedLines] = useState<ReadonlySet<string>>(new Set())
  // Hunk-fold segments expanded by index; default collapsed.
  const [expandedFolds, setExpandedFolds] = useState<ReadonlySet<number>>(new Set())
  // Bottom diff pane height in px; drag the handle to resize (min/max clamp).
  const [diffHeight, setDiffHeight] = useState(340)
  const diffPaneRef = useRef<HTMLDivElement>(null)
  // Per-selected-op scroll memory for the diff/read pane: switching ops restores
  // that op's own position instead of jumping to the top each time.
  const scrollPaneRef = useRef<HTMLDivElement>(null)
  const scrollMemoryRef = useRef(new Map<string, number>())
  const listScrollRef = useRef<HTMLDivElement>(null)
  const listScrollMemoryRef = useRef<number | undefined>(undefined)
  // Ctrl+wheel font sizing: one size for the op-list area, one for the
  // diff/read pane; both persist in localStorage and clamp to
  // [MIN_FONT, MAX_FONT] with a toast when the wheel keeps pushing past a bound.
  const MIN_FONT = 9
  const MAX_FONT = 28
  const LS_LIST_FONT = 'dsh-file-trace:listFont'
  const LS_PANE_FONT = 'dsh-file-trace:paneFont'
  const readFont = (key: string): number | undefined => {
    try {
      const saved = window.localStorage.getItem(key)
      if (saved !== null) {
        const n = Number(saved)
        if (Number.isFinite(n)) return Math.min(Math.max(n, MIN_FONT), MAX_FONT)
      }
    } catch { /* storage unavailable */ }
    return undefined
  }
  const [listFont, setListFont] = useState(() => readFont(LS_LIST_FONT) ?? 12)
  const [paneFont, setPaneFont] = useState(() => readFont(LS_PANE_FONT) ?? 12)
  const drawerRef = useRef<HTMLDivElement>(null)
  const paneFontRef = useRef(paneFont)
  paneFontRef.current = paneFont
  const listFontRef = useRef(listFont)
  listFontRef.current = listFont
  const fontToast = (message: string): void => {
    const existing = document.getElementById('dsh-file-trace-font-toast')
    if (existing !== null) existing.remove()
    const el = document.createElement('div')
    el.id = 'dsh-file-trace-font-toast'
    el.className = css.fontToast ?? ''
    el.textContent = message
    document.body.appendChild(el)
    window.setTimeout(() => { el.remove() }, 1600)
  }
  useEffect(() => {
    if (!open) return
    const onFontWheel = (e: WheelEvent): void => {
      if (!e.ctrlKey) return
      // The mermaid zoom modal owns ALL wheel events while open (its own
      // capture-stage handler zooms); font sizing must not fight it.
      if (document.getElementById('dsh-file-trace-mermaid-modal') !== null) return
      const target = e.target instanceof Node ? e.target : null
      const drawer = drawerRef.current
      if (drawer === null || target === null || !drawer.contains(target)) return
      e.preventDefault()
      // The markdown reading pane is part of the pane font group too (its
      // own md-pane attribute): Ctrl+wheel there scales the rendered document.
      const inPane = target instanceof Element && target.closest('[data-file-trace-diff], [data-file-trace-md-pane]') !== null
      const step = e.deltaY < 0 ? 1 : -1
      const current = inPane ? paneFontRef.current : listFontRef.current
      const next = Math.min(Math.max(current + step, MIN_FONT), MAX_FONT)
      if (next === current) {
        fontToast(t(step < 0 ? 'font.min' : 'font.max', { px: String(step < 0 ? MIN_FONT : MAX_FONT) }) as never)
        return
      }
      if (inPane) setPaneFont(next)
      else setListFont(next)
      try { window.localStorage.setItem(inPane ? LS_PANE_FONT : LS_LIST_FONT, String(next)) } catch { /* storage unavailable */ }
    }
    document.addEventListener('wheel', onFontWheel, { passive: false, capture: true })
    return () => { document.removeEventListener('wheel', onFontWheel, { capture: true } as EventListenerOptions) }
  }, [open, t])

  // Floating-window geometry (like dsh-minigames): position by header drag,
  // size by edge drags; persisted in localStorage.
  const LS_POS = 'dsh-file-trace:pos'
  const LS_SIZE = 'dsh-file-trace:size'
  const [winPos, setWinPos] = useState<{ x: number; y: number }>(() => {
    try {
      const saved = window.localStorage.getItem(LS_POS)
      if (saved !== null) {
        const p = JSON.parse(saved) as { x?: unknown; y?: unknown }
        if (typeof p.x === 'number' && Number.isFinite(p.x) && typeof p.y === 'number' && Number.isFinite(p.y)) {
          return { x: Math.min(Math.max(p.x, 8), Math.max(8, window.innerWidth - 300)), y: Math.min(Math.max(p.y, 8), Math.max(8, window.innerHeight - 120)) }
        }
      }
    } catch { /* fall through to the default */ }
    return { x: Math.max(16, window.innerWidth - 576), y: Math.max(16, Math.round(window.innerHeight * 0.12)) }
  })
  const [winSize, setWinSize] = useState<{ w: number; h: number }>(() => {
    try {
      const saved = window.localStorage.getItem(LS_SIZE)
      if (saved !== null) {
        const s = JSON.parse(saved) as { w?: unknown; h?: unknown }
        if (typeof s.w === 'number' && Number.isFinite(s.w) && typeof s.h === 'number' && Number.isFinite(s.h)) {
          return { w: Math.min(Math.max(s.w, 360), window.innerWidth - 16), h: Math.min(Math.max(s.h, 200), window.innerHeight - 16) }
        }
      }
    } catch { /* fall through to the default */ }
    return { w: Math.min(560, window.innerWidth - 32), h: Math.min(720, window.innerHeight - 64) }
  })
  const posRef = useRef(winPos)
  posRef.current = winPos
  const sizeRef = useRef(winSize)
  sizeRef.current = winSize
  const saveWin = (key: string, value: unknown): void => {
    try { window.localStorage.setItem(key, JSON.stringify(value)) } catch { /* storage unavailable */ }
  }

  /** Right-edge docking: released near the right edge, the window snaps into
 * a full-height right sidebar; dragging the header undocks it again. */
  const LS_DOCK = 'dsh-file-trace:dock'
  const SNAP_PX = 24
  const [docked, setDocked] = useState<boolean>(() => {
    if (embedded) return false
    try { return window.localStorage.getItem(LS_DOCK) === 'right' } catch { return false }
  })
  const dockedRef = useRef(docked)
  dockedRef.current = docked

  // Live gesture geometry: while a drag/resize pointer gesture is active, the
  // drawer's inline styles are written straight to the DOM on each
  // pointermove (and this ref mirrors them so an interleaved React
  // re-render — a streaming delta — re-applies the live values instead of
  // jumping back to the pre-gesture state). pointerup commits the geometry
  // into React state once; the direct writes keep the drag following the
  // pointer even when renders are slow.
  const liveGeomRef = useRef<{ x: number; y: number; w: number; h: number } | null>(null)
  const applyLiveGeom = (): void => {
    const g = liveGeomRef.current
    const el = drawerRef.current
    if (g === null || el === null) return
    el.style.left = `${String(g.x)}px`
    el.style.top = `${String(g.y)}px`
    el.style.width = `${String(g.w)}px`
    el.style.height = `${String(g.h)}px`
  }
  /** Begin (or continue) a gesture from the current geometry. */
  const gestureStart = (): { x: number; y: number; w: number; h: number } => {
    const live = liveGeomRef.current
    if (live !== null) return live
    const fresh = { x: posRef.current.x, y: posRef.current.y, w: sizeRef.current.w, h: sizeRef.current.h }
    liveGeomRef.current = fresh
    return fresh
  }
  /** Commit the live geometry to state and storage, ending the gesture. */
  const gestureCommit = (): void => {
    const g = liveGeomRef.current
    liveGeomRef.current = null
    if (g === null) return
    setWinPos({ x: g.x, y: g.y })
    setWinSize({ w: g.w, h: g.h })
    saveWin(LS_POS, { x: g.x, y: g.y })
    saveWin(LS_SIZE, { w: g.w, h: g.h })
  }

  /** Apply the docked-right geometry: flush to the right edge, full height. */
  const applyDock = (): void => {
    const w = sizeRef.current.w
    setWinPos({ x: window.innerWidth - w, y: 0 })
    setWinSize(prev => ({ ...prev, h: window.innerHeight }))
  }

  /** Drag the floating window by its header; clamped to the viewport.
 * Dragging undocks a docked window; releasing near the right edge docks it
 * into a full-height right sidebar. */
  const startWinDrag = (e: ReactPointerEvent<HTMLDivElement>): void => {
    const target = e.target as HTMLElement
    if (target.closest('button') !== null) return
    e.preventDefault()
    if (dockedRef.current) {
      setDocked(false)
      saveWin(LS_DOCK, 'free')
    }
    const startX = e.clientX
    const startY = e.clientY
    const start = { ...gestureStart() }
    const onMove = (ev: PointerEvent): void => {
      const g = {
        ...start,
        x: Math.min(Math.max(start.x + ev.clientX - startX, 8), Math.max(8, window.innerWidth - start.w - 8)),
        y: Math.min(Math.max(start.y + ev.clientY - startY, 8), Math.max(8, window.innerHeight - 64)),
      }
      liveGeomRef.current = g
      applyLiveGeom()
    }
    const onUp = (up: PointerEvent): void => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
      gestureCommit()
      if (up.clientX >= window.innerWidth - SNAP_PX) {
        setDocked(true)
        saveWin(LS_DOCK, 'right')
        applyDock()
      }
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
  }

  /** Resize the floating window from the left edge (right edge anchored). */
  const startWinResizeW = (e: ReactPointerEvent<HTMLDivElement>): void => {
    e.preventDefault()
    const anchorRight = (() => { const s = gestureStart(); return s.x + s.w })()
    const onMove = (ev: PointerEvent): void => {
      const w = Math.min(Math.max(anchorRight - ev.clientX, 360), Math.min(window.innerWidth - 16, anchorRight - 8))
      const s = gestureStart()
      liveGeomRef.current = { ...s, w, x: anchorRight - w }
      applyLiveGeom()
    }
    const onUp = (): void => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
      gestureCommit()
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
  }

  /** Resize the floating window from the bottom edge (top edge anchored). */
  const startWinResizeH = (e: ReactPointerEvent<HTMLDivElement>): void => {
    e.preventDefault()
    const startY = e.clientY
    const start = { ...gestureStart() }
    const onMove = (ev: PointerEvent): void => {
      const h = Math.min(Math.max(start.h + ev.clientY - startY, 200), window.innerHeight - start.y - 8)
      liveGeomRef.current = { ...start, h }
      applyLiveGeom()
    }
    const onUp = (): void => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
      gestureCommit()
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
  }

  /** Resize the floating window from the top edge (bottom edge anchored). */
  const startWinResizeHT = (e: ReactPointerEvent<HTMLDivElement>): void => {
    e.preventDefault()
    const startY = e.clientY
    const start = { ...gestureStart() }
    const bottom = start.y + start.h
    const onMove = (ev: PointerEvent): void => {
      const h = Math.min(Math.max(start.h + (startY - ev.clientY), 200), window.innerHeight - 8)
      liveGeomRef.current = { ...start, h, y: bottom - h }
      applyLiveGeom()
    }
    const onUp = (): void => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
      gestureCommit()
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
  }

  /** Resize the floating window from the right edge (left edge anchored). */
  const startWinResizeWR = (e: ReactPointerEvent<HTMLDivElement>): void => {
    e.preventDefault()
    const startX = e.clientX
    const start = { ...gestureStart() }
    const onMove = (ev: PointerEvent): void => {
      const w = Math.min(Math.max(start.w + (ev.clientX - startX), 360), window.innerWidth - start.x - 8)
      liveGeomRef.current = { ...start, w }
      applyLiveGeom()
    }
    const onUp = (): void => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
      gestureCommit()
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
  }

  const onHandleDown = (e: ReactPointerEvent<HTMLDivElement>): void => {
    e.preventDefault()
    const startY = e.clientY
    const startH = diffHeight
    const onMove = (ev: PointerEvent): void => {
      setDiffHeight(Math.min(Math.max(startH + (startY - ev.clientY), 140), Math.round(window.innerHeight * 0.85)))
    }
    const onUp = (): void => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
  }

  // While docked AND open, shrink the page (body) by the sidebar width so the
  // conversation column reflows left and never overlaps the docked panel;
  // fixed-position elements (the docked panel itself) ignore body margin.
  // The panel's left-edge resize handle is the splitter between the two.
  // Closing the panel removes the margin — reopening (still docked) re-applies.
  useEffect(() => {
    if (embedded) return
    const id = 'dsh-file-trace-dock-style'
    const existing = document.getElementById(id)
    if (docked && open) {
      const el = existing ?? document.createElement('style')
      el.id = id
      el.textContent = `body { margin-right: ${String(winSize.w)}px !important; }`
      if (existing === null) document.head.appendChild(el)
      return () => { el.remove() }
    }
    if (existing !== null) existing.remove()
    return undefined
  }, [docked, open, winSize.w])
  // Restore the docked geometry on mount; keep the dock pinned when the
  // viewport resizes (the sidebar stays flush-right and full-height).
  useEffect(() => { if (!embedded && dockedRef.current) applyDock() }, [])
  useEffect(() => {
    const onResize = (): void => { if (dockedRef.current) applyDock() }
    window.addEventListener('resize', onResize)
    return () => { window.removeEventListener('resize', onResize) }
  }, [])

  // Check for a newer tag once on mount (the trigger button shows a ⟳ dot
  // when one exists); the drawer head reuses the same state.
  useEffect(() => {
    void fetchLatestTag().then((tag) => {
      if (tag !== undefined) setLatestTag((prev) => (prev !== undefined ? prev : tag))
      else setCheckFailed(true)
    })
  }, [])
  const newerTag = latestTag !== undefined && compareSemver(latestTag, PLUGIN_VERSION) > 0 ? latestTag : undefined

  /** One-click update: host endpoint first; on failure, copy the prompt. */
  const onUpdateClick = (): void => {
    if (newerTag === undefined || updating) return
    setUpdating(true)
    setUpdateMsg(null)
    void runUpdate(newerTag).then((result) => {
      setUpdating(false)
      if (result.ok) {
        setUpdateMsg(result.hostChanged === true ? `已更新到 ${newerTag}（含宿主侧变更），请重启 dsh 生效` : `已更新到 ${newerTag}，客户端自动刷新生效（未见变化可硬刷新）`)
        return
      }
      if (result.link) {
        void navigator.clipboard?.writeText(updatePrompt(newerTag))
          .then(() => setUpdateMsg(`本地 link 安装：自动更新会断开本地开发链接，已跳过；已把更新提示词复制到剪贴板——若想切换为 git 依赖安装并自动更新，请先以 git 方式安装本插件`))
          .catch(() => setUpdateMsg(`本地 link 安装：自动更新已跳过。请手动执行：dsh plugin --profile web add '@dsh-external/dsh-file-trace@github:lhh010/dsh-file-trace#${newerTag}'`))
        return
      }
      void navigator.clipboard?.writeText(updatePrompt(newerTag))
        .then(() => { setUpdateMsg(`自动更新失败（${result.detail.slice(0, 80)}）；已复制更新提示词到剪贴板，粘贴发送即可${result.recovery !== undefined ? `；恢复命令：${result.recovery}` : ''}`) })
        .catch(() => { setUpdateMsg(`自动更新失败；请手动执行：dsh plugin --profile web add '@dsh-external/dsh-file-trace@github:lhh010/dsh-file-trace#${newerTag}'`) })
    })
  }

  // Escape closes the drawer, mirroring platform dialog behavior (an embedded
  // mount has nothing to close — its container owns the visibility).
  useEffect(() => {
    if (!open || embedded) return
    const onKey = (e: KeyboardEvent): void => { if (e.key === 'Escape') setOpen(false) }
    window.addEventListener('keydown', onKey)
    return () => { window.removeEventListener('keydown', onKey) }
  }, [open])

  const count = ops.length
  const selectedOp = selected?.op
  // Language hint for syntax coloring of the selected op's content.
  const selectedLang = useMemo(
    () => selected === null ? undefined : langOfPath(selected.path),
    [selected],
  )
  // Secret redaction: on by default, toggle persists per browser. Every
  // downstream consumer (diff rows, read view, markdown mode, error text)
  // renders from viewOp below, so masked payloads are the only shape that
  // can reach the DOM while the toggle is on.
  const [redactionOn, setRedactionOn] = useState((): boolean => {
    try { return localStorage.getItem('dsh-file-trace.redaction') !== '0' } catch { return true }
  })
  const toggleRedaction = (): void => {
    setRedactionOn((prev) => {
      const next = !prev
      try { localStorage.setItem('dsh-file-trace.redaction', next ? '1' : '0') } catch { /* storage unavailable */ }
      return next
    })
  }
  const viewOp = useMemo(() => {
    const priorRaw = selectedOp === undefined ? undefined : knownContentBefore(ops, selected?.path ?? '', selectedOp)
    if (selectedOp === undefined || !redactionOn) {
      return { op: selectedOp, prior: priorRaw, hit: false }
    }
    const path = selected?.path ?? ''
    const mask = (text: string): string => redactText(path, text).text
    const hit = [selectedOp.read, selectedOp.content, selectedOp.edit?.oldString, selectedOp.edit?.newString, selectedOp.errorText, priorRaw]
      .some((text) => text !== undefined && redactText(path, text).hit)
    const op: FileOp = {
      ...selectedOp,
      ...(selectedOp.read !== undefined ? { read: mask(selectedOp.read) } : {}),
      ...(selectedOp.content !== undefined ? { content: mask(selectedOp.content) } : {}),
      ...(selectedOp.edit !== undefined ? { edit: { oldString: mask(selectedOp.edit.oldString), newString: mask(selectedOp.edit.newString) } } : {}),
      ...(selectedOp.errorText !== undefined ? { errorText: mask(selectedOp.errorText) } : {}),
    }
    return { op, prior: priorRaw === undefined ? undefined : mask(priorRaw), hit }
  }, [selectedOp, selected?.path, ops, redactionOn])
  const diffRows = useMemo(
    () => viewOp.op === undefined ? [] : diffOf(viewOp.op, viewOp.prior),
    [viewOp],
  )
  const segments = useMemo(() => buildDiffSegments(diffRows), [diffRows])
  // Char-level highlight for mod-row pairs: keyed by (oldLine|newLine), so a
  // rewritten line shows exactly which substring changed (higher-contrast bg).
  const inlineMap = useMemo(() => {
    const map = new Map<string, InlineDiff>()
    let i = 0
    while (i < diffRows.length) {
      if (diffRows[i]!.kind !== 'mod') { i += 1; continue }
      let j = i
      while (j < diffRows.length && diffRows[j]!.kind === 'mod') j += 1
      const block = diffRows.slice(i, j)
      const k = Math.floor(block.length / 2)
      for (let p = 0; p < k; p += 1) {
        const delRow = block[p]!
        const addRow = block[p + k]!
        const r = diffInline(delRow.text, addRow.text)
        map.set(`${String(delRow.oldLine ?? '')}|${String(delRow.newLine ?? '')}`, r)
        map.set(`${String(addRow.oldLine ?? '')}|${String(addRow.newLine ?? '')}`, r)
      }
      i = j
    }
    return map
  }, [diffRows])
  // Block-comment entry state per row, threaded per side (multi-line comments).
  const blockEntries = useMemo(() => diffBlockEntries(diffRows, selectedLang), [diffRows, selectedLang])
  // Read view rows with block-comment state threaded down the file's lines.
  const readRows = useMemo(() => {
    if (viewOp.op?.kind !== 'read' || viewOp.op.read === undefined) return []
    let state = false
    // Stitched reads carry clean content (no envelope/prefixes): number rows
    // from the segment's own start line.
    if (viewOp.op.readClean) {
      const start = viewOp.op.readStart ?? 1
      return viewOp.op.read.split('\n').map((line, i) => {
        const scan = scanLine(line, selectedLang, state)
        state = scan.inBlock
        return { line: start + i, nodes: tokensToNodes(scan.tokens) }
      })
    }
    return parseReadLines(viewOp.op.read).map((line) => {
      const scan = scanLine(line.text, selectedLang, state)
      state = scan.inBlock
      return { line: line.line, nodes: tokensToNodes(scan.tokens) }
    })
  }, [viewOp, selectedLang])
  // Reading-mode source for a .md selection: read -> the file's full content;
  // write -> the written content; edit -> the reconstructed resulting
  // content when the prior state is known, else the edit's new snippet.
  // All payloads come from viewOp (redacted when the toggle is on).
  const readingSrc = useMemo(() => {
    if (selected === null || (!isMarkdownPath(selected.path) && !isHtmlPath(selected.path) && !isSvgPath(selected.path))) return ''
    const op = viewOp.op
    if (op === undefined) return ''
    if (op.kind === 'read') return op.readClean ? (op.read ?? '') : parseReadContent(op.read ?? '')
    if (op.kind === 'write') return op.content ?? ''
    if (op.kind === 'edit' && op.edit !== undefined) {
      const prior = viewOp.prior
      if (prior !== undefined && prior.includes(op.edit.oldString)) {
        return prior.replace(op.edit.oldString, op.edit.newString)
      }
      return op.edit.newString
    }
    return ''
  }, [selected, viewOp])
  // SVG render source: the selected op's payload when it forms a complete
  // document (contains the closing </svg>); otherwise the newest complete
  // read of the same path — a truncated/partial read is not well-formed XML
  // and its <img> would be silently broken. Undefined = not renderable.
  const svgSrc = useMemo(() => {
    if (selected === null || !isSvgPath(selected.path)) return undefined
    const path = selected.path
    if (readingSrc.includes('</svg>')) return readingSrc
    let newest: { at: number; text: string } | undefined
    for (const op of ops) {
      if (op.path !== path || op.kind !== 'read' || op.isError || op.read === undefined) continue
      const text = op.readClean ? op.read : parseReadContent(op.read)
      if (!text.includes('</svg>')) continue
      if (newest === undefined || op.time > newest.at) newest = { at: op.time, text }
    }
    if (newest === undefined) return undefined
    return redactionOn ? redactText(path, newest.text).text : newest.text
  }, [selected, readingSrc, ops, redactionOn])
  // Reset folding when selecting a different operation (the row indexes change).
  useEffect(() => { setExpandedLines(new Set()); setExpandedFolds(new Set()); setMdReading(false); setHtmlReading(false); setHtmlSandbox('script'); setPdfReading(false); setSvgReading(false) }, [selectedOp])

  // Restore this op's own diff/read scroll position (new ops start at top).
  useEffect(() => {
    const el = scrollPaneRef.current
    if (el === null) return
    const saved = scrollMemoryRef.current.get(selectedOp?.callId ?? '')
    el.scrollTop = saved ?? 0
  }, [selectedOp, open])

  // Keep the file-list scroll position when selecting an op (don't jump to top).
  useEffect(() => {
    const el = listScrollRef.current
    if (el === null) return
    const saved = listScrollMemoryRef.current
    if (saved !== undefined) el.scrollTop = saved
  }, [selectedOp])

  // One diff row: colored sign + text, with the long-line fold toggle.
  const renderDiffRow = (row: DiffRow, rowKey: string, lang: string | undefined): ReactElement => {
    const isLong = row.text.length > FOLD_THRESHOLD
    const blockEntry = blockEntries.get(row) ?? false
    const isFolded = isLong && !expandedLines.has(rowKey)
    return (
      <div
        key={rowKey}
        className={css.diffRow}
        data-kind={row.kind}
        data-folded={isFolded ? 'true' : undefined}
        onClick={isLong ? () => {
          setExpandedLines(prev => {
            const next = new Set(prev)
            if (next.has(rowKey)) next.delete(rowKey)
            else next.add(rowKey)
            return next
          })
        } : undefined}
        title={isFolded ? row.text : undefined}
      >
        <span className={css.lineNo}>{row.oldLine !== undefined ? String(row.oldLine) : ''}</span>
        <span className={css.lineNo}>{row.newLine !== undefined ? String(row.newLine) : ''}</span>
        <span className={css.sign} aria-label={t(`diff.${row.kind}` as never)}>
          {row.kind === 'del' ? '-' : row.kind === 'add' ? '+' : row.kind === 'mod' ? '~' : ' '}
        </span>
        <span className={css.text} data-folded={isFolded ? 'true' : undefined}>
          {row.kind === 'mod' && (() => {
            const inline = inlineMap.get(`${String(row.oldLine ?? '')}|${String(row.newLine ?? '')}`)
            if (inline === undefined) return tokensToNodes(scanLine(row.text, lang, blockEntry).tokens)
            // Coalesced change runs, each split into syntax tokens with
            // block-comment state threaded across the runs of this line.
            const side = coalesceInline(row.oldLine !== undefined ? inline.old : inline.next)
            const nodes: ReactNode[] = []
            let state = blockEntry
            for (const seg of side) {
              const scan = scanLine(seg.text, lang, state)
              state = scan.inBlock
              nodes.push(...tokensToNodes(scan.tokens, seg.changed))
            }
            return nodes
          })()}
          {row.kind !== 'mod' && tokensToNodes(scanLine(row.text, lang, blockEntry).tokens)}
        </span>
      </div>
    )
  }

  return (
    <>
      {embedded ? null : (
        <button
          type="button"
          className={css.trigger}
          data-file-trace-trigger
          title={t('open')}
          aria-label={`${t('title')} (${String(count)})`}
          onClick={() => { setOpen(prev => !prev); setSelected(null) }}
        >
          <span className={css.triggerLabel}>{t('title')}</span>
          {count > 0 && <span className={css.badge}>{String(count)}</span>}
          {newerTag !== undefined && <span className={css.updateDot} title={`新版本 ${newerTag} 可用`}>⟳</span>}
        </button>
      )}
      {open && (
        <DrawerErrorBoundary key={String(selected?.op.callId ?? 'open')}>
        <div
          className={css.drawer}
          data-file-trace-drawer
          data-embedded={embedded ? 'true' : undefined}
          ref={drawerRef}
          data-dock={docked ? 'right' : undefined}
          role={embedded ? undefined : 'dialog'}
          aria-label={embedded ? undefined : t('title')}
          style={(embedded
            ? { '--ft-list-font': `${String(listFont)}px`, '--ft-pane-font': `${String(paneFont)}px` } as CSSProperties
            : { '--ft-list-font': `${String(listFont)}px`, '--ft-pane-font': `${String(paneFont)}px`, ...(liveGeomRef.current !== null
              // Mid-gesture: pass the live geometry through so a streaming
              // re-render cannot snap the drawer back to the pre-gesture
              // state (the same values were already written to the DOM).
              ? { left: liveGeomRef.current.x, top: liveGeomRef.current.y, width: liveGeomRef.current.w, height: liveGeomRef.current.h }
              : docked
              ? { left: window.innerWidth - winSize.w, top: 0, width: winSize.w, height: window.innerHeight }
              : {
                left: Number.isFinite(winPos.x) ? Math.min(Math.max(winPos.x, 8), Math.max(8, window.innerWidth - 360)) : Math.max(16, window.innerWidth - 576),
                top: Number.isFinite(winPos.y) ? Math.min(Math.max(winPos.y, 8), Math.max(8, window.innerHeight - 120)) : 16,
                width: Number.isFinite(winSize.w) ? Math.min(Math.max(winSize.w, 360), window.innerWidth - 16) : Math.min(560, window.innerWidth - 16),
                height: Number.isFinite(winSize.h) ? Math.min(Math.max(winSize.h, 200), window.innerHeight - 16) : Math.min(720, window.innerHeight - 16),
              }) } as CSSProperties) }
        >
          {embedded ? null : (
            <div
              className={css.resizeW}
              data-ft-resize-w
              onPointerDown={startWinResizeW}
              role="separator"
              aria-orientation="vertical"
            />
          )}
          {docked ? null : (
            <div
              className={css.resizeH}
              data-ft-resize-h
              onPointerDown={startWinResizeH}
              role="separator"
              aria-orientation="horizontal"
            />
          )}
          {docked ? null : (
            <div
              className={css.resizeT}
              data-ft-resize-t
              onPointerDown={startWinResizeHT}
              role="separator"
              aria-orientation="horizontal"
            />
          )}
          {docked ? null : (
            <div
              className={css.resizeR}
              data-ft-resize-r
              onPointerDown={startWinResizeWR}
              role="separator"
              aria-orientation="vertical"
            />
          )}
          <div className={css.drawerHead} onPointerDown={embedded ? undefined : startWinDrag}>
            <span className={css.drawerTitle}>{t('title')}</span>
            <span className={css.drawerMeta}>
              {String(groups.size)} {t('files')} · {String(count)} ops
            </span>
            {stitchable && (
              <button type="button" className={css.readModeBtn} data-on={stitchOn ? 'true' : undefined} onClick={() => { setStitchOn(v => !v) }} title={t('stitch.do')}>
                {stitchOn ? t('stitch.on') : t('stitch.do')}
              </button>
            )}
            {newerTag !== undefined && (
              <button type="button" className={css.updateBadge} data-updating={updating ? 'true' : undefined} onClick={onUpdateClick} title={`一键更新到 ${newerTag}（点击触发；失败则复制提示词）`}>
                {updating ? '更新中…' : `⟳ 更新到 ${newerTag}`}
              </button>
            )}
            {updateMsg !== null && <span className={css.updateMsg} title={updateMsg}>{updateMsg}</span>}
          {checkFailed && newerTag === undefined && updateMsg === null && <span className={css.updateMsg} title="无法连接宿主端点 / GitHub，稍后重开抽屉重试">⚠ 版本检查失败</span>}
            {embedded ? null : <button type="button" className={css.close} onClick={() => { setOpen(false) }}>{t('close')}</button>}
          </div>
          <div className={css.drawerBody} ref={listScrollRef} onScroll={(e) => { listScrollMemoryRef.current = e.currentTarget.scrollTop }}>
            {count === 0 && <div className={css.empty}>{t('empty')}</div>}
            {[...groups.entries()].map(([path, fileOps]) => (
              <div key={path} className={css.fileGroup}>
                <div className={css.filePath} title={path}>{path}</div>
                {fileOps.map(op => (
                  <button
                    type="button"
                    key={op.callId}
                    className={css.opRow}
                    data-op-kind={op.kind}
                    data-op-error={op.isError ? 'true' : undefined}
                    onClick={() => { setSelected({ path, op }) }}
                  >
                    <span className={css.opKind} data-kind={op.kind}>{t(`ops.${op.kind}` as never)}</span>
                    <span className={css.opTime}>{new Date(op.time).toLocaleTimeString()}</span>
                    {op.running && <span className={css.opFlag}>{t('running')}</span>}
                    {op.isError && <span className={css.opFlagError}>{t('error')}</span>}
                    {op.kind !== 'read' && (
                      <span className={css.opSize}>
                        {formatBytes(new Blob([op.edit?.newString ?? op.content ?? '']).size)}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            ))}
          </div>
          {selected !== null && (
            <div className={css.diffPane} data-file-trace-diff style={{ height: diffHeight }}>
              <div className={css.dragHandle} onPointerDown={onHandleDown} role="separator" aria-orientation="horizontal" aria-label="drag to resize" />
              <div className={css.diffHead}>
                <span className={css.diffPath}>{selected.path}</span>
                <span className={css.diffKind} data-kind={selected.op.kind}>
                  {t(`ops.${selected.op.kind}` as never)}
                </span>
                {viewOp.hit && redactionOn && (
                  <span className={css.redactBanner} role="status">{t('redact.banner')}</span>
                )}
                {viewOp.op?.partial === true && (
                  <span className={css.redactBanner} role="status">{t('read.partial', { range: viewOp.op.partialRange ?? '' })}</span>
                )}
                {viewOp.op?.readStitched !== undefined && (
                  <span className={css.redactBanner} role="status">{t('read.stitched', { range: viewOp.op.readStitched, count: String(viewOp.op.partialSegments ?? 0) })}</span>
                )}
                <button
                  type="button"
                  className={css.readModeBtn}
                  data-on={redactionOn ? 'true' : undefined}
                  onClick={toggleRedaction}
                  title={redactionOn ? t('redact.off') : t('redact.on')}
                >
                  {redactionOn ? t('redact.onLabel') : t('redact.offLabel')}
                </button>
                {isMarkdownPath(selected.path) && !selected.op.isError && (
                  <button
                    type="button"
                    className={css.readModeBtn}
                    data-on={(selected.op.presentOnly === true ? presentReading : mdReading) ? 'true' : undefined}
                    onClick={() => { if (selected.op.presentOnly === true) setPresentReading(prev => !prev); else setMdReading(prev => !prev) }}
                    title={(selected.op.presentOnly === true ? presentReading : mdReading) ? t('md.raw') : t('md.read')}
                  >
                    {(selected.op.presentOnly === true ? presentReading : mdReading) ? t('md.raw') : t('md.read')}
                  </button>
                )}
                {isHtmlPath(selected.path) && !selected.op.isError && (
                  <button
                    type="button"
                    className={css.readModeBtn}
                    data-on={htmlReading ? 'true' : undefined}
                    onClick={() => { setHtmlReading(prev => !prev) }}
                    title={htmlReading ? t('html.raw') : t('html.render')}
                  >
                    {htmlReading ? t('html.raw') : t('html.render')}
                  </button>
                )}
                {htmlReading && isHtmlPath(selected.path) && (
                  <button
                    type="button"
                    className={css.readModeBtn}
                    data-on="true"
                    onClick={() => { setHtmlSandbox(prev => prev === 'strict' ? 'script' : prev === 'script' ? 'relaxed' : 'strict') }}
                    title={t(`html.sandbox.${htmlSandbox}`)}
                  >
                    {t(`html.sandbox.${htmlSandbox}`)}
                  </button>
                )}
                {isPdfPath(selected.path) && isAbsolutePath(selected.path) && (
                  <button
                    type="button"
                    className={css.readModeBtn}
                    data-on={pdfReading ? 'true' : undefined}
                    onClick={() => { setPdfReading(prev => !prev) }}
                    title={pdfReading ? t('pdf.raw') : t('pdf.render')}
                  >
                    {pdfReading ? t('pdf.raw') : t('pdf.render')}
                  </button>
                )}
                {isSvgPath(selected.path) && !selected.op.isError && (
                  <button
                    type="button"
                    className={css.readModeBtn}
                    data-on={svgReading ? 'true' : undefined}
                    onClick={() => { setSvgReading(prev => !prev) }}
                    title={svgReading ? t('svg.raw') : t('svg.render')}
                  >
                    {svgReading ? t('svg.raw') : t('svg.render')}
                  </button>
                )}
                <button type="button" className={css.close} onClick={() => { setSelected(null) }}>×</button>
              </div>
              {svgReading && isSvgPath(selected.path) && svgSrc === undefined
                ? (
                  <div className={css.mdPane} data-file-trace-svg-missing role="alert">
                    {t('svg.missing')}
                  </div>
                )
                : svgReading && isSvgPath(selected.path) && svgSrc !== undefined
                ? (
                  <SvgFrame path={selected.path} src={svgSrc} t={t} />
                )
                : pdfReading && isPdfPath(selected.path)
                ? (
                  <PdfFrame path={selected.path} t={t} />
                )
                : selected.op.isError
                ? (
                  <div className={css.readContent} data-file-trace-read data-error="true" ref={scrollPaneRef} onScroll={(e) => { scrollMemoryRef.current.set(selectedOp?.callId ?? '', e.currentTarget.scrollTop) }}>
                    <div className={css.readError} role="alert">
                      {viewOp.op?.errorText ?? t('error')}
                    </div>
                  </div>
                )
                : selected.op.presentOnly === true
                  ? (
                    <PresentedPane path={selected.path} sessionId={sessionId} rendered={presentReading} t={t} />
                  )
                  : mdReading && isMarkdownPath(selected.path)
                  ? (
                    <div className={css.mdPane} data-file-trace-md-pane ref={scrollPaneRef} onScroll={(e) => { scrollMemoryRef.current.set(selectedOp?.callId ?? '', e.currentTarget.scrollTop) }}>
                      <MarkdownView src={readingSrc} baseDir={selected.path.replace(/[\\/][^\\/]*$/, '')} />
                    </div>
                  )
                  : htmlReading && isHtmlPath(selected.path) && readingSrc !== ''
                  ? (
                    <div className={css.mdPane} data-file-trace-html-pane>
                      <iframe
                        className={css.htmlFrame}
                        title={selected.path}
                        sandbox={SANDBOX_ATTR[htmlSandbox]}
                        allow={PERMISSIONS_ATTR[htmlSandbox]}
                        srcDoc={readingSrc}
                      />
                    </div>
                  )
                  : selected.op.kind === 'read'
                  ? (
                    <div className={css.readContent} data-file-trace-read ref={scrollPaneRef} onScroll={(e) => { scrollMemoryRef.current.set(selectedOp?.callId ?? '', e.currentTarget.scrollTop) }}>
                      {readRows.map((row) => (
                        <div key={String(row.line)} className={css.readRow}>
                          <span className={css.lineNo}>{String(row.line)}</span>
                          <span className={css.text}>{row.nodes}</span>
                        </div>
                      ))}
                    </div>
                  )
                  : (
                  <div className={css.diffRows} ref={scrollPaneRef} onScroll={(e) => { scrollMemoryRef.current.set(selectedOp?.callId ?? '', e.currentTarget.scrollTop) }}>
                    {selected.op.kind === 'write'
                      && knownContentBefore(ops, selected.path, selected.op) === undefined
                      && <div className={css.priorUnknown}>{t('diff.priorUnknown')}</div>}
                    {segments.map((segment, segIndex) => {
                      if (segment.kind === 'fold') {
                        // Runs shorter than MIN_FOLD are shown directly (no
                        // collapse) — only >= MIN_FOLD context runs fold.
                        const shouldFold = segment.rows.length >= MIN_FOLD
                        const isExpanded = expandedFolds.has(segIndex)
                        if (!shouldFold) {
                          return segment.rows.map((row, index) => renderDiffRow(row, `${segIndex}-${String(index)}`, selectedLang))
                        }
                        return (
                          <div
                            key={`fold-${String(segIndex)}`}
                            className={css.foldRow}
                            data-expanded={isExpanded ? 'true' : undefined}
                            onClick={() => {
                              setExpandedFolds(prev => {
                                const next = new Set(prev)
                                if (next.has(segIndex)) next.delete(segIndex)
                                else next.add(segIndex)
                                return next
                              })
                            }}
                          >
                            {isExpanded
                              ? segment.rows.map((row, index) => renderDiffRow(row, `${segIndex}-${String(index)}`, selectedLang))
                              : (
                                <span className={css.foldMarker} title={`${t('diff.context')} ${segment.oldStart}–${segment.oldEnd} · ${segment.newStart}–${segment.newEnd}`}>
                                  {t('diff.fold', { count: String(segment.rows.length) })}
                                </span>
                              )}
                          </div>
                        )
                      }
                      return segment.rows.map((row, index) => renderDiffRow(row, `${segIndex}-${String(index)}`, selectedLang))
                    })}
                  </div>
                  )}
            </div>
          )}
        </div>
        </DrawerErrorBoundary>
      )}
    </>
  )
}
