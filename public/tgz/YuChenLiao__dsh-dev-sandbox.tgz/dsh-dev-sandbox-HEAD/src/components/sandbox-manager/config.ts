/** sandbox-manager 组件自己的常量；跨组件共享的常量在 shared/config.ts。 */

import type { McpEntry } from "../../shared/types.ts";

export const INSTANCE_ID_PREFIX = "sbx-";
export const INSTANCE_ID_LENGTH = 6;

export const HOME_DIR = "home";
export const WORKSPACE_DIR = "workspace";
export const PROFILE_DIR = "profiles";
export const PROFILE_AGENTS_DIR = "agents";
export const PROFILE_NODE_MODULES = "node_modules";
export const LOG_FILE = "boot.log";
export const ENV_FILE = ".env";

export const PROFILE_PACKAGE_NAME = "dsh-profile-sbx";
export const PROFILE_PATCH_HEADER = "# 沙箱 profile 层：本实例的约束与插件行";
export const API_KEY_ENV = "DEEPSEEK_API_KEY";

/**
 * MCP server 行：每个 server 一行 `dsh-mcp-client` 实例。
 * config 用 JSON 内联——YAML 的 flow mapping 语法接受 JSON 对象，省掉手写序列化。
 */
function mcpLines(mcp: readonly McpEntry[] | undefined): string[] {
  const lines: string[] = [];
  for (const entry of mcp ?? []) {
    lines.push(
      "- insert:",
      `    - id: mcp-${entry.serverName}`,
      '      name: "@deepseek-ai/dsh-mcp-client"',
      `      config: ${JSON.stringify(entry.config)}`,
    );
  }
  return lines;
}

/**
 * 物化后的 preset 行：`readDocument` 给的就是 entry-list YAML，原样缩进四格嵌进 `- insert:`。
 * 比 JSON 化好的地方是 `!!js` 表达式能原样保留，不会被丢掉。
 *
 * 只接受**顶层** entry-list（首行以 `-` 开头）。content 来自用户可写的 preset 文件，
 * 如果是顶层 mapping，缩进后拼出来的补丁会错位，所以这里先挡一下。
 */
function presetLines(yaml: string | undefined): string[] {
  const body = (yaml ?? "").trim();
  if (!body) return [];
  const firstLine = body.split("\n").find((line) => line.trim());
  if (!firstLine || !firstLine.trimStart().startsWith("-")) {
    throw new Error("preset 内容不是顶层 entry-list，无法物化");
  }
  return ["- insert:", ...body.split("\n").map((line) => (line.trim() ? `    ${line}` : line))];
}

/**
 * 沙箱 profile 的补丁：把 agent 的文件与 shell 钉在 workspace 里。
 * 不依赖 base 的默认值，避免哪天默认放宽后沙箱跟着放宽。
 *
 * 不接收 preset 行——web profile 里没有 preset 可绑，物化只对 headless 的 run profile 有意义。
 */
export function profilePatchBody(workspaceRoot: string, mcp?: readonly McpEntry[]): string {
  return [
    PROFILE_PATCH_HEADER,
    "- id: sandbox-policy",
    "  config:",
    "    mode: workspace-write",
    `    workspaceRoot: ${JSON.stringify(workspaceRoot)}`,
    // base 的 permission 行依赖 DSH_PERMISSION_MODE 推出组合默认；
    // 沙箱把这个变量清掉了，组合默认匹配不到任何 preset，必须显式给 defaultPreset。
    "- id: permission",
    "  config:",
    "    defaultPreset: workspace-write",
    "    presets:",
    "      read-only:",
    "        sandbox: read-only",
    "        approval: ask",
    "      workspace-write:",
    "        sandbox: workspace-write",
    "        approval: ask",
    "      danger-full-access:",
    "        sandbox: danger-full-access",
    "        approval: never",
    ...mcpLines(mcp),
    "",
  ].join("\n");
}

/** 凭据继承：复制工作环境的凭据文件，但剥掉这条 GUI 会话记录。 */
export const CREDENTIALS_FILE = ".credentials.yaml";
export const BROWSER_SESSION_RECORD = "client-connection/browser-session";
export const PLATFORM_ACCOUNT_PREFIX = "deepseek-account-platform/";

/** 跑对话用的 headless profile：不带 web-app，只装 base + headless + 待测插件。 */
export const RUN_PROFILE = "run";
export const HEADLESS_BUNDLE = "@deepseek-ai/dsh-headless";
export const WEB_APP_BUNDLE = "@deepseek-ai/dsh-web-app";

/**
 * headless profile 的补丁：恢复凭据三行（headless 默认关掉它们），
 * 再把 agent 的文件与 shell 钉在 workspace。
 */
export function runProfilePatchBody(
  workspaceRoot: string,
  mcp?: readonly McpEntry[],
  presetYaml?: string,
): string {
  return [
    "# 沙箱 headless 运行层",
    "- id: credentials",
    "  disabled: false",
    "- id: authorization",
    "  disabled: false",
    "- id: deepseek-account",
    "  disabled: false",
    "- id: sandbox-policy",
    "  config:",
    "    mode: workspace-write",
    `    workspaceRoot: ${JSON.stringify(workspaceRoot)}`,
    "- id: permission",
    "  config:",
    "    defaultPreset: workspace-write",
    "    presets:",
    "      read-only:",
    "        sandbox: read-only",
    "        approval: ask",
    "      workspace-write:",
    "        sandbox: workspace-write",
    "        approval: ask",
    "      danger-full-access:",
    "        sandbox: danger-full-access",
    "        approval: never",
    ...mcpLines(mcp),
    // headless 的组合器不认 agent preset（`assertAdoptable` 会直接拒绝带 preset 的会话），
    // 所以 preset 里注册的插件进不了 agent 的 scope 链。物化到 profile 层之后它们以
    // 全局身份加载，`collectFresh` 的 global 段就能看到它们。
    ...presetLines(presetYaml),
    "",
  ].join("\n");
}

/** 启动参数。端口固定交给系统分配，避免与工作环境的 6945 撞车。 */
export const BOOT_ARGS = ["--profile", "sbx", "--port", "0", "--no-open"] as const;
export const DUMP_CONFIG_ARGS = ["--profile", "sbx", "--dump-config"] as const;
