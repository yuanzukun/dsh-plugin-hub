// Care panel for Pet — the pet-raising UI migrated from PetClaw's care chapter.
// Right-click the pet to open near the character. Tabbed layout:
// status+interactions / inventory / shop / settings. Fixed light palette so
// it reads the same under any DSH theme.

import { useCallback, useEffect, useRef, useState, type FC } from 'react'
import type { MiniEngine } from './game/mini-engine.ts'
import type { ChatModel } from './PetChatBox.tsx'
import type { PetProfile, LineKey } from './custom-pets.ts'
import { LINE_KEYS, LINE_META } from './custom-pets.ts'
import {
  claimLogReward, claimWeekReward, getWitnessDay, getWitnessWeek, getWeekLog,
  recordCare, saveLogText, saveWeekLogText,
} from './game/witness-log.ts'
import { memoryTexts, type PetMemory } from './memory.ts'
import type { WorkspaceView } from './workspace.ts'
import { PixelIcon } from './pixel-icons.tsx'

interface Props {
  engine: MiniEngine
  anchor: { x: number; y: number } // pet screen position (panel opens beside it)
  petName: string // active companion name (header + switch button)
  chatModel: ChatModel | null // LLM used by the side chat box
  onChatModelChange: (model: ChatModel | null) => void // persist a new choice
  profile: PetProfile // active companion's persona + event lines
  onProfileChange: (patch: Partial<PetProfile>) => void // persist an edit
  onGeneratePet: (description: string) => Promise<{ ok: boolean; name?: string; error?: string }> // LLM sprite generation (spends coins)
  /** How many custom companions exist (0 → first generate is free). */
  customCount: number
  onImportPet: (text: string) => { ok: boolean; name?: string; error?: string } // share-file import (free)
  onPetSay: (text: string) => void // speak through the pet's bubble (wrapped)
  onSpeakPool: (key: LineKey) => void // fire a pool-keyed speech event through the pet's bubble
  onBurst: (opts?: { count?: number; color?: string }) => void // fire a particle burst at the pet's position
  /** Open the 45s runner mini-game (double-click on the pet does the same). */
  onPlayRunner: () => void
  onSwitchPet: () => void // reopen the companion picker
  memories: PetMemory[] // the pet's stored memories about the user
  onRemoveMemory: (id: string) => void // drop one memory
  autoMemory: boolean // automatic memory extraction enabled
  /** Vine-climb overlay for high platforms (default off: covers text). */
  vineClimb: boolean
  onVineClimbChange: (on: boolean) => void
  onAutoMemoryChange: (on: boolean) => void // persist the toggle
  workspace: WorkspaceView // host session list view (empty on old hosts)
  onClose: () => void
}

/** Provider+model list served by the plugin's node half. */
interface ModelListEntry {
  id: string
  name: string
  models: Array<{ id: string; name: string }>
  /** Set when listing this provider's models failed; the rest stay usable. */
  error?: string
}

const LEVEL_COLORS: Record<string, string> = {
  sad: '#ef4444', starving: '#ef4444', sick: '#ef4444',
  hungry: '#f59e0b', subhealthy: '#f59e0b', normal: '#3b82f6',
  healthy: '#22c55e', happy: '#22c55e', full: '#22c55e', joyful: '#a855f7',
}
const LEVEL_NAMES: Record<string, string> = {
  sad: '低落', starving: '耗尽', sick: '生病', hungry: '饥饿', subhealthy: '亚健康',
  normal: '正常', healthy: '健康', happy: '开心', full: '满格', joyful: '亢奋',
}
const CAT_NAMES: Record<string, string> = {
  food: '食物', toy: '玩具', medicine: '药品', special: '特殊', collection: '收藏',
}

function barColor(level: string): string {
  return LEVEL_COLORS[level] ?? '#3b82f6'
}

let panelStyleInjected = false
function injectPanelStyles(): void {
  if (panelStyleInjected) return
  panelStyleInjected = true
  const s = document.createElement('style')
  s.textContent = `
.dsh-pet-sprite-panel{position:fixed;z-index:950;width:260px;max-height:min(60vh,460px);display:flex;flex-direction:column;background:var(--dsw-alias-bg-layer-1,#ffffff);border:2px solid var(--dsw-alias-border-l3,#2a2f3e);border-radius:12px;box-shadow:0 5px 0 rgba(0,0,0,.16),0 14px 32px rgba(0,0,0,.18);overflow:hidden;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;color:var(--dsw-alias-label-primary,#1f2430);pointer-events:auto}
.dsh-pet-sprite-panel-hd{display:flex;align-items:center;gap:6px;padding:8px 10px;border-bottom:2px solid #2a2f3e;font-size:12px;font-weight:800;color:#1f2430}
.dsh-pet-sprite-panel-hd .sub{font-weight:600;font-size:10.5px;color:var(--dsw-alias-label-secondary,#6b7280)}
.dsh-pet-sprite-panel-hd .coins{margin-left:auto;font-weight:800;font-size:11px;color:#b8860b;white-space:nowrap}
.dsh-pet-sprite-panel-x{border:none;background:transparent;font-size:13px;cursor:pointer;color:var(--dsw-alias-label-secondary,#6b7280);padding:2px 5px;border-radius:6px;line-height:1}
.dsh-pet-sprite-panel-x:hover{background:#eef0f4;color:#1f2430}
.dsh-pet-sprite-tabs{display:flex;border-bottom:1px solid #e5e7eb}
.dsh-pet-sprite-tab{flex:1;border:none;background:transparent;padding:6px 0;font-size:11px;font-weight:700;color:var(--dsw-alias-label-secondary,#6b7280);cursor:pointer;font-family:inherit;border-bottom:2px solid transparent}
.dsh-pet-sprite-tab.on{color:#1f2430;border-bottom-color:#4f6ef7}
.dsh-pet-sprite-tab:hover{color:#1f2430}
.dsh-pet-sprite-panel-bd{overflow-y:auto;padding:8px 12px 12px;font-size:12px}
.dsh-pet-sprite-panel-bd::-webkit-scrollbar{width:5px}
.dsh-pet-sprite-panel-bd::-webkit-scrollbar-thumb{background:#d1d5db;border-radius:999px}
.dsh-pet-sprite-row{display:flex;align-items:center;gap:8px;margin:6px 0}
.dsh-pet-sprite-row label{width:30px;flex:none;color:var(--dsw-alias-label-secondary,#6b7280);font-size:11px}
.dsh-pet-sprite-bar{flex:1;height:8px;border-radius:999px;background:#e5e7eb;overflow:hidden}
.dsh-pet-sprite-bar i{display:block;height:100%;border-radius:999px;transition:width .5s cubic-bezier(.2,.8,.4,1)}
.dsh-pet-sprite-row b{width:78px;flex:none;text-align:right;font-weight:700;font-variant-numeric:tabular-nums;font-size:10.5px;color:#1f2430}
.dsh-pet-sprite-exp .cap{display:flex;justify-content:space-between;color:var(--dsw-alias-label-secondary,#6b7280);font-size:10.5px;margin:8px 0 3px}
.dsh-pet-sprite-sec h4{margin:10px 0 5px;font-size:10px;color:var(--dsw-alias-label-secondary,#6b7280);font-weight:800;letter-spacing:.5px}
.dsh-pet-sprite-acts{display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px}
.dsh-pet-sprite-btn{border:1.5px solid #2a2f3e;background:#f6f7fa;border-radius:8px;padding:6px 2px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit;color:#1f2430;transition:transform .12s,background .12s}
.dsh-pet-sprite-btn:hover{background:#eef0f4}
.dsh-pet-sprite-btn:active{transform:scale(.94)}
.dsh-pet-sprite-btn:disabled{opacity:.4;cursor:not-allowed}
.dsh-pet-sprite-item{display:flex;align-items:center;gap:6px;padding:5px 7px;border-radius:8px;border:1.5px solid var(--dsw-alias-border-l2,#e5e7eb);margin-bottom:5px;background:var(--dsw-alias-bg-layer-1,#fff)}
.dsh-pet-sprite-item .ic{font-size:14px;flex:none}
.dsh-pet-sprite-item .nm{font-weight:700;flex:none;font-size:11.5px;color:#1f2430;max-width:84px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dsh-pet-sprite-item .fx{color:var(--dsw-alias-label-secondary,#6b7280);flex:1;font-size:10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dsh-pet-sprite-item .qty{flex:none;font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-secondary,#6b7280);font-size:10.5px}
.dsh-pet-sprite-buy{flex:none;border:1.5px solid #2a2f3e;border-radius:6px;padding:2.5px 8px;font-size:10.5px;font-weight:800;cursor:pointer;background:#ffd33d;color:#1f2430;font-family:inherit}
.dsh-pet-sprite-buy:disabled{opacity:.35;cursor:not-allowed}
.dsh-pet-sprite-buy:not(:disabled):active{transform:scale(.94)}
.dsh-pet-sprite-switch{display:block;width:100%;margin-top:12px;color:var(--dsw-alias-label-secondary,#6b7280);background:var(--dsw-alias-bg-layer-1,#fff)}
.dsh-pet-sprite-set-note{color:var(--dsw-alias-label-secondary,#6b7280);font-size:10.5px;line-height:1.6;margin:4px 0 8px}
.dsh-pet-sprite-set select{width:100%;border:1.5px solid #2a2f3e;border-radius:8px;padding:6px 8px;font:700 11.5px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;color:#1f2430;background:var(--dsw-alias-bg-layer-1,#fff);margin-bottom:8px;outline:none}
.dsh-pet-sprite-set label{display:block;font-size:10.5px;font-weight:800;color:var(--dsw-alias-label-secondary,#6b7280);margin:8px 0 4px}
.dsh-pet-sprite-set textarea{display:block;width:100%;box-sizing:border-box;border:1.5px solid #2a2f3e;border-radius:8px;padding:6px 8px;font:600 11.5px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;color:#1f2430;background:var(--dsw-alias-bg-layer-1,#fff);outline:none;resize:vertical;min-height:54px;margin-bottom:4px}
.dsh-pet-sprite-set textarea:focus,.dsh-pet-sprite-set input:focus{background:var(--dsw-specific-bubble,#fffbe8)}
.dsh-pet-sprite-set input{display:block;width:100%;box-sizing:border-box;border:1.5px solid #2a2f3e;border-radius:8px;padding:6px 8px;font:600 11.5px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;color:#1f2430;background:var(--dsw-alias-bg-layer-1,#fff);outline:none;margin-bottom:6px}
.dsh-pet-sprite-gen-btn{display:block;width:100%;margin-top:2px}
.dsh-pet-sprite-lines-toggle{display:block;width:100%;margin-top:8px;color:#4f6ef7;background:#f0f3ff}
.dsh-pet-sprite-lines-toggle:hover{background:#e3e9ff}
.dsh-pet-sprite-lines{border:1.5px dashed #c9cede;border-radius:10px;padding:8px 8px 4px;margin-top:6px;background:#fafbff}
.dsh-pet-sprite-lines textarea{margin-bottom:8px}
.dsh-pet-sprite-import-file{display:none}
.dsh-pet-sprite-import-row{display:flex;gap:6px}
.dsh-pet-sprite-import-row .dsh-pet-sprite-btn{flex:1}
.dsh-pet-sprite-paste-box{margin-bottom:6px}
.dsh-pet-sprite-set-err{border:1.5px solid var(--dsw-alias-state-error-secondary,#e8434e);border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-state-error-primary,#e8434e) 10%,var(--dsw-alias-bg-layer-1,#fff));color:var(--dsw-alias-state-error-secondary,#b32832);font-size:10.5px;font-weight:700;padding:6px 9px;margin:6px 0;line-height:1.5;word-break:break-word}
.dsh-pet-sprite-log{border:1.5px solid #2a2f3e;border-radius:10px;background:var(--dsw-specific-bubble,#fffbe8);padding:7px 9px;margin-top:8px;font-size:11.5px;font-weight:600;line-height:1.7;color:#1f2430;white-space:pre-wrap;word-break:break-word}
.dsh-pet-sprite-log-tag{display:inline-block;font-size:9.5px;font-weight:800;color:var(--dsw-alias-label-secondary,#9a8c4a);background:var(--dsw-alias-state-warn-tertiary,#fff3b8);border:1.5px solid #d9c86a;border-radius:999px;padding:0 7px;margin-bottom:5px}
.dsh-pet-sprite-mem{position:relative;border:1.5px solid var(--dsw-alias-border-l2,#e5e7eb);border-radius:8px;background:#fafbff;padding:5px 24px 5px 8px;margin-bottom:5px}
.dsh-pet-sprite-mem .tx{font-size:11px;font-weight:700;color:#1f2430;line-height:1.5;word-break:break-word}
.dsh-pet-sprite-mem .mt{font-size:9.5px;color:#9ca3af;margin-top:2px}
.dsh-pet-sprite-mem-x{position:absolute;top:4px;right:4px;border:none;background:transparent;color:#9ca3af;font-size:12px;line-height:1;cursor:pointer;padding:2px 4px;border-radius:5px}
.dsh-pet-sprite-mem-x:hover{background:var(--dsw-alias-interactive-bg-hover-danger,#ffe9ec);color:var(--dsw-alias-state-error-secondary,#b32832)}
.dsh-pet-sprite-check{display:flex;align-items:flex-start;gap:6px;font-size:10.5px;font-weight:600;color:#374151;line-height:1.5;margin:4px 0 8px;cursor:pointer}
.dsh-pet-sprite-check input{margin-top:2px;accent-color:#4f6ef7}
.dsh-pet-sprite-toast{position:fixed;z-index:960;background:#1f2430;color:#fff;font-size:12px;padding:7px 13px;border-radius:9px;box-shadow:0 4px 0 rgba(0,0,0,.2);animation:dshPetSpriteToast 2.6s ease forwards;max-width:260px}
@keyframes dshPetSpriteToast{from{opacity:0;transform:translateY(8px)}10%,80%{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(-6px)}}
`
  document.head.appendChild(s)
}

export const CarePanel: FC<Props> = ({ engine, anchor, petName, chatModel, onChatModelChange, profile, onProfileChange, onGeneratePet, customCount, onImportPet, onPetSay, onSpeakPool, onBurst, onPlayRunner, onSwitchPet, memories, onRemoveMemory, autoMemory, onAutoMemoryChange, vineClimb, onVineClimbChange, workspace, onClose }) => {
  const [, bump] = useState(0)
  const [tab, setTab] = useState<'status' | 'bag' | 'shop' | 'set'>('status')
  const [toast, setToast] = useState<{ id: number; text: string } | null>(null)
  // provider/model options for the chat settings tab; fetched from the
  // plugin's node route on first open of the tab
  const [modelList, setModelList] = useState<ModelListEntry[] | null>(null)
  const [modelListError, setModelListError] = useState<string | null>(null)
  // custom sprite generation: description draft + in-flight/error states
  const [genDesc, setGenDesc] = useState('')
  const [generating, setGenerating] = useState(false)
  const [genError, setGenError] = useState<string | null>(null)
  // share-file import: hidden file input + paste-box toggle + error state
  const importInputRef = useRef<HTMLInputElement>(null)
  const [pasteOpen, setPasteOpen] = useState(false)
  const [pasteText, setPasteText] = useState('')
  const [importError, setImportError] = useState<string | null>(null)
  // event-lines editor: collapsed by default, one textarea per event pool
  const [linesOpen, setLinesOpen] = useState(false)
  // work log (day / week): cached entries show on open, regenerate on click
  const [logBusy, setLogBusy] = useState<'day' | 'week' | null>(null)
  const [logError, setLogError] = useState<string | null>(null)
  const [logText, setLogText] = useState<string | null>(() => getWitnessDay().lastLog ?? getWeekLog())
  const [logScope, setLogScope] = useState<'day' | 'week'>(() => getWitnessDay().lastLog !== undefined ? 'day' : 'week')
  useEffect(() => { injectPanelStyles() }, [])

  const loadModels = useCallback(async () => {
    if (modelList !== null || modelListError !== null) return
    try {
      const res = await fetch('/plugins/dsh-pet-sprite/models')
      const data = await res.json().catch(() => ({})) as { providers?: ModelListEntry[]; error?: string }
      if (!res.ok) throw new Error(data.error ?? `HTTP ${res.status}`)
      setModelList(data.providers ?? [])
    } catch (error) {
      setModelListError(error instanceof Error ? error.message : String(error))
    }
  }, [modelList, modelListError])
  useEffect(() => {
    if (tab === 'set') void loadModels()
  }, [tab, loadModels])

  const say = useCallback((text: string) => {
    setToast({ id: Date.now(), text })
  }, [])
  const refresh = useCallback(() => bump((v) => v + 1), [])

  // event-lines plumbing: text in the editor is one line per entry; empty
  // pools fall back to the built-in voice (speakLine in custom-pets.ts).
  const linesText = (key: LineKey): string => profile.lines[key]?.join('\n') ?? ''
  const setLines = (key: LineKey, text: string): void => {
    const rows = text.split('\n').map(s => s.trim()).filter(s => s.length > 0).slice(0, 8)
    const next = { ...profile.lines }
    if (rows.length > 0) next[key] = rows
    else delete next[key]
    onProfileChange({ lines: next })
  }

  // Position: open to the left of the pet, above its base; flip to the
  // right if it would overflow the viewport, clamp vertically.
  const PW = 260, PH = 380
  let px = anchor.x - PW - 16
  if (px < 8) px = anchor.x + 16 + 48 // pet width ~48
  if (px + PW > window.innerWidth - 8) px = Math.max(8, window.innerWidth - PW - 8)
  let py = anchor.y - PH + 28
  if (py < 8) py = Math.min(window.innerHeight - 160, anchor.y + 20)
  py = Math.max(8, py)

  const stats = engine.getStats()
  const info = engine.levels.getInfo()
  const expPct = info.expToNext > 0
    ? Math.min(100, Math.round(((info.exp - info.currentLevelExp) / info.expToNext) * 100))
    : 100

  const inv = engine.inventory.list().filter((it) => it.quantity !== 0)
  const shop = engine.shop.listShop({
    power: stats.power, health: stats.health, mood: stats.mood, adventureActive: false,
  }).slice(0, 8)

  // work-log summary numbers (read per render: cheap, stays fresh)
  const day = getWitnessDay()
  const week = getWitnessWeek()
  const fmtChars = (n: number): string => n >= 10000 ? `${(n / 10000).toFixed(1)} 万字` : `${n} 字`

  const doPlay = (id: string) => {
    const r = engine.care.play(id)
    if (r.ok) {
      recordCare('play')
      onSpeakPool('play')
      onBurst({ count: 5, color: '#ffd33d' })
    }
    else if (r.reason === 'too_low_power') say('电量不够玩了，先喂点东西吧')
    refresh()
  }
  const doRest = () => {
    const r = engine.care.rest({ duration: 30, wokeBy: 'manual' })
    if (r.ok) {
      recordCare('rest')
      onSpeakPool('rest')
    }
    refresh()
  }
  const doUse = (id: string) => {
    const r = engine.care.useItem(id)
    if (!r.ok) {
      say(r.reason === 'cooldown' ? '还在冷却中…' : '没有这个道具了')
      return
    }
    recordCare('feed')
    onSpeakPool('feed')
    onBurst({ count: 4, color: '#f2839b' })
    refresh()
  }
  const doBuy = (id: string) => {
    const r = engine.shop.buy(id)
    if (r.ok) say(`买好了 ${id}`)
    else if (r.reason === 'insufficient_coins') say('金币不够')
    else if (r.reason === 'level_too_low') say('等级不够，还解锁不了')
    else if (r.reason === 'daily_limit') say('今天卖完了，明天再来')
    else say(`买不了（${r.reason}）`)
    refresh()
  }

  // work log: journal numbers + persona go to the node route, which returns
  // one entry in the pet's voice — today's log or the last-7-days report.
  // Regeneration is free (the user's own model); witness fees land once
  // per day (20) and once per week (50).
  const doWitness = async (scope: 'day' | 'week'): Promise<void> => {
    if (logBusy !== null) return
    if (chatModel === null) {
      setLogError('还没有选择模型：先在「设置」里选一个。')
      return
    }
    setLogBusy(scope)
    setLogError(null)
    try {
      const day = scope === 'week'
        ? (() => {
            const w = getWitnessWeek()
            return {
              turns: w.turns, tasks: w.tasks, inChars: w.inChars, outChars: w.outChars,
              spanMinutes: w.spanMinutes, night: w.nights > 0,
              feed: w.feed, play: w.play, rest: w.rest, levelUps: w.levelUps,
              activeDays: w.activeDays, nights: w.nights,
            }
          })()
        : (() => {
            const d = getWitnessDay()
            return {
              turns: d.turns, tasks: d.tasks, inChars: d.inChars, outChars: d.outChars,
              spanMinutes: d.lastAt > d.firstAt ? Math.round((d.lastAt - d.firstAt) / 60000) : 0,
              night: d.night,
              feed: d.feed, play: d.play, rest: d.rest, levelUps: d.levelUps,
            }
          })()
      const res = await fetch('/plugins/dsh-pet-sprite/witness', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          petName,
          persona: profile.persona,
          lang: navigator.language,
          provider: chatModel.provider,
          model: chatModel.model,
          scope,
          day,
          memories: memoryTexts(10),
          petState: stats,
        }),
      })
      const data = await res.json().catch(() => ({})) as { log?: string; error?: string }
      if (!res.ok) throw new Error(data.error ?? `HTTP ${res.status}`)
      const log = (data.log ?? '').trim()
      if (log.length === 0) throw new Error('模型没有写出日志。')
      setLogText(log)
      setLogScope(scope)
      if (scope === 'day') saveLogText(log)
      else saveWeekLogText(log)
      onPetSay(log)
      const claimed = scope === 'day' ? claimLogReward() : claimWeekReward()
      if (claimed) {
        engine.shop.earnCoins(scope === 'day' ? 20 : 50, `witness_${scope}`)
        say(scope === 'day' ? '见证完成，星币 +20' : '本周见证完成，星币 +50')
      } else {
        say(scope === 'day' ? '已更新今日日志' : '已更新本周周报')
      }
      refresh()
    } catch (error) {
      setLogError(error instanceof Error ? error.message : String(error))
    } finally {
      setLogBusy(null)
    }
  }

  // LLM sprite generation runs in ChatPet (wallet + storage live there);
  // this side only owns the draft, the busy state, and error surfacing.
  const doGenerate = async (): Promise<void> => {
    const description = genDesc.trim()
    if (description.length === 0 || generating) return
    setGenerating(true)
    setGenError(null)
    const r = await onGeneratePet(description)
    setGenerating(false)
    if (r.ok) {
      setGenDesc('')
      say(`新伙伴「${r.name ?? ''}」加入！已切换为它。`)
    } else {
      setGenError(r.error ?? '生成失败，再试一次。')
    }
    refresh()
  }

  // share-file import: shared result object for the file picker and the
  // paste box; on success the picker overlay will re-render with the new pet
  const doImport = (text: string): void => {
    const r = onImportPet(text)
    if (r.ok) {
      setImportError(null)
      setPasteOpen(false)
      setPasteText('')
      say(`「${r.name ?? ''}」加入了！已切换为它。`)
    } else {
      setImportError(r.error ?? '导入失败。')
    }
    refresh()
  }
  const doImportFile = (file: File | undefined): void => {
    if (file === undefined) return
    void file.text().then(doImport, () => setImportError('读不出这个文件。'))
  }

  return (
    <>
      <div className="dsh-pet-sprite-panel" role="dialog" aria-label="Pet 照顾面板" style={{ left: px, top: py }}>
        <div className="dsh-pet-sprite-panel-hd">
          {petName} <span className="sub">Lv.{stats.level} {stats.title}</span>
          <span className="coins"><PixelIcon icon="coin" size={12} /> {stats.coins}</span>
          <button className="dsh-pet-sprite-panel-x" onClick={onClose} aria-label="关闭">✕</button>
        </div>
        <div className="dsh-pet-sprite-tabs">
          <button className={`dsh-pet-sprite-tab ${tab === 'status' ? 'on' : ''}`} onClick={() => setTab('status')}>状态</button>
          <button className={`dsh-pet-sprite-tab ${tab === 'bag' ? 'on' : ''}`} onClick={() => setTab('bag')}>背包</button>
          <button className={`dsh-pet-sprite-tab ${tab === 'shop' ? 'on' : ''}`} onClick={() => setTab('shop')}>商店</button>
          <button className={`dsh-pet-sprite-tab ${tab === 'set' ? 'on' : ''}`} onClick={() => setTab('set')}>设置</button>
        </div>
        <div className="dsh-pet-sprite-panel-bd">
          {tab === 'status' && (
            <>
              <div className="dsh-pet-sprite-row">
                <label>心情</label>
                <div className="dsh-pet-sprite-bar"><i style={{ width: `${stats.mood}%`, background: barColor(stats.moodLevel) }} /></div>
                <b>{stats.mood} {LEVEL_NAMES[stats.moodLevel] ?? stats.moodLevel}</b>
              </div>
              <div className="dsh-pet-sprite-row">
                <label>电量</label>
                <div className="dsh-pet-sprite-bar"><i style={{ width: `${Math.min(100, stats.power / 3)}%`, background: barColor(stats.powerLevel) }} /></div>
                <b>{stats.power} {LEVEL_NAMES[stats.powerLevel] ?? stats.powerLevel}</b>
              </div>
              <div className="dsh-pet-sprite-row">
                <label>健康</label>
                <div className="dsh-pet-sprite-bar"><i style={{ width: `${stats.health}%`, background: barColor(stats.healthLevel) }} /></div>
                <b>{stats.health} {LEVEL_NAMES[stats.healthLevel] ?? stats.healthLevel}</b>
              </div>
              <div className="dsh-pet-sprite-exp">
                <div className="cap"><span>经验 → Lv.{stats.level + 1}</span><span>{expPct}%</span></div>
                <div className="dsh-pet-sprite-bar"><i style={{ width: `${expPct}%`, background: '#4f6ef7' }} /></div>
              </div>
              <div className="dsh-pet-sprite-sec">
                <h4>互动</h4>
                <div className="dsh-pet-sprite-acts">
                  <button className="dsh-pet-sprite-btn" onClick={() => doPlay('hide_seek')}>捉迷藏</button>
                  <button className="dsh-pet-sprite-btn" onClick={() => doPlay('sunbathe')}>晒太阳</button>
                  <button className="dsh-pet-sprite-btn" onClick={onPlayRunner}>▶ 跑酷 45 秒</button>
                  <button className="dsh-pet-sprite-btn" onClick={doRest}>睡一会</button>
                </div>
              </div>
              <div className="dsh-pet-sprite-sec">
                <h4>工作日志</h4>
                <div className="dsh-pet-sprite-set-note">
                  今日：对话 {day.turns} 轮 · 完成 {day.tasks} 件 · 输出 {fmtChars(day.outChars)}
                  {day.night ? ' · 凌晨仍在干活' : ''}
                  <br />
                  本周：活跃 {week.activeDays} 天 · 对话 {week.turns} 轮 · 输出 {fmtChars(week.outChars)}
                  {week.nights > 0 ? ` · ${week.nights} 天熬到凌晨` : ''} —— {petName} 都看在眼里。
                </div>
                <div className="dsh-pet-sprite-import-row">
                  <button
                    className="dsh-pet-sprite-btn"
                    onClick={() => { void doWitness('day') }}
                    disabled={logBusy !== null}
                  >
                    {logBusy === 'day' ? '写日报中……' : '生成日报'}
                  </button>
                  <button
                    className="dsh-pet-sprite-btn"
                    onClick={() => { void doWitness('week') }}
                    disabled={logBusy !== null}
                  >
                    {logBusy === 'week' ? '写周报中……' : '生成周报'}
                  </button>
                </div>
                {logError !== null && <div className="dsh-pet-sprite-set-err">{logError}</div>}
                {logText !== null && (
                  <div className="dsh-pet-sprite-log">
                    <div className="dsh-pet-sprite-log-tag">{logScope === 'day' ? '今日日报' : '本周周报'}</div>
                    {logText}
                  </div>
                )}
              </div>
              <div className="dsh-pet-sprite-sec">
                <h4>宠物的记忆</h4>
                {workspace.total > 0 && (
                  <div className="dsh-pet-sprite-set-note">
                    主人的工地：{workspace.total} 个会话
                    {workspace.currentTitle.length > 0 ? `，当前在「${workspace.currentTitle}」` : ''}。
                  </div>
                )}
                {memories.length === 0
                  ? <div className="dsh-pet-sprite-set-note">还没有记忆——陪主人干几轮活，{petName} 会默默记下值得记的事。</div>
                  : memories.map(m => (
                    <div key={m.id} className="dsh-pet-sprite-mem">
                      <div className="tx">{m.text}</div>
                      <div className="mt">
                        {m.sessionTitle.length > 0 ? `来自「${m.sessionTitle}」` : ''}
                        {m.sessionTitle.length > 0 ? ' · ' : ''}{new Date(m.createdAt).toLocaleDateString()}
                      </div>
                      <button className="dsh-pet-sprite-mem-x" title="忘掉这条" onClick={() => onRemoveMemory(m.id)}>×</button>
                    </div>
                  ))}
                {memories.length > 0 && (
                  <div className="dsh-pet-sprite-set-note">
                    见证主人干活时顺手记下的（最多 30 条，满了挤掉最旧的）；只存在本地浏览器，聊天和写日志时会想起来。
                  </div>
                )}
              </div>
            </>
          )}
          {tab === 'bag' && (
            <div className="dsh-pet-sprite-sec">
              {inv.length === 0 && <div style={{ color: '#6b7280', fontSize: 11 }}>背包空空的，去「商店」补货</div>}
              {inv.map((it) => (
                <div key={it.itemId} className="dsh-pet-sprite-item">
                  <span className="ic"><PixelIcon icon={it.def.icon} /></span>
                  <span className="nm">{it.def.name}</span>
                  <span className="fx">{CAT_NAMES[it.def.category] ?? it.def.category}</span>
                  <span className="qty">×{it.quantity < 0 ? '∞' : it.quantity}</span>
                  <button className="dsh-pet-sprite-buy" disabled={!it.canUse} onClick={() => doUse(it.itemId)}>使用</button>
                </div>
              ))}
            </div>
          )}
          {tab === 'shop' && (
            <div className="dsh-pet-sprite-sec">
              {shop.map((it) => (
                <div key={it.id} className="dsh-pet-sprite-item">
                  <span className="ic"><PixelIcon icon={it.icon} /></span>
                  <span className="nm">{it.name}</span>
                  <span className="qty"><PixelIcon icon="coin" size={10} />{it.price}</span>
                  <button className="dsh-pet-sprite-buy" disabled={!it.canBuy} onClick={() => doBuy(it.id)}>购买</button>
                </div>
              ))}
            </div>
          )}
          {tab === 'set' && (
            <div className="dsh-pet-sprite-sec dsh-pet-sprite-set">
              <h4>聊天模型</h4>
              <div className="dsh-pet-sprite-set-note">
                左键点击 {petName} 可以聊天；这里选择由哪个模型来扮演它（复用本页已配置的服务商和密钥）。
              </div>
              {modelListError !== null && <div className="dsh-pet-sprite-set-err">模型列表加载失败：{modelListError}</div>}
              {modelList === null && modelListError === null && <div className="dsh-pet-sprite-set-note">加载模型列表……</div>}
              {modelList !== null && modelList.length === 0 && (
                <div className="dsh-pet-sprite-set-note">没有可用模型：先在 DSH 设置里配置一个模型服务商。</div>
              )}
              {modelList !== null && modelList.length > 0 && (
                <>
                  <label>服务商</label>
                  <select
                    value={chatModel?.provider ?? ''}
                    onChange={(e) => {
                      const p = modelList.find(m => m.id === e.target.value)
                      // auto-pick the provider's first model so the choice is always complete
                      onChatModelChange(p && p.models.length > 0 ? { provider: p.id, model: p.models[0].id } : null)
                    }}
                  >
                    <option value="" disabled={chatModel !== null}>选择服务商</option>
                    {modelList.map(p => (
                      <option key={p.id} value={p.id} disabled={p.models.length === 0}>
                        {p.name}（{p.id}）{p.models.length === 0 ? ' — 模型列表不可用' : ''}
                      </option>
                    ))}
                  </select>
                  {modelList.filter(p => p.error !== undefined).map(p => (
                    <div key={p.id} className="dsh-pet-sprite-set-err">{p.name}：{p.error}</div>
                  ))}
                  {chatModel !== null && (() => {
                    const p = modelList.find(m => m.id === chatModel.provider)
                    return p ? (
                      <>
                        <label>模型</label>
                        <select
                          value={chatModel.model}
                          onChange={(e) => onChatModelChange({ provider: chatModel.provider, model: e.target.value })}
                        >
                          {p.models.map(m => <option key={m.id} value={m.id}>{m.name === m.id ? m.id : `${m.name}（${m.id}）`}</option>)}
                        </select>
                        <div className="dsh-pet-sprite-set-note">当前：{chatModel.provider} / {chatModel.model}</div>
                      </>
                    ) : (
                      <div className="dsh-pet-sprite-set-note">已保存的服务商不在当前列表里，重新选一个吧。</div>
                    )
                  })()}
                </>
              )}
              <h4>角色设定</h4>
              <div className="dsh-pet-sprite-set-note">
                给 {petName} 写的性格设定，聊天时会优先按它来演；留空则用默认性格。导出分享时会一并带给朋友。
              </div>
              <textarea
                value={profile.persona}
                onChange={(e) => onProfileChange({ persona: e.target.value })}
                placeholder="例如：嘴硬心软的傲娇性格，喜欢被夸，偶尔阴阳怪气但很靠得住"
                maxLength={500}
                rows={3}
              />
              <button
                className="dsh-pet-sprite-btn dsh-pet-sprite-lines-toggle"
                onClick={() => setLinesOpen(v => !v)}
              >
                {linesOpen ? '收起事件台词' : '定制事件台词（待机 / 工作 / 互动…）'}
              </button>
              {linesOpen && (
                <div className="dsh-pet-sprite-lines">
                  <div className="dsh-pet-sprite-set-note">
                    每行一条，随机触发；留空用默认。最多 8 条，每条 24 字内。
                  </div>
                  {LINE_KEYS.map(key => (
                    <div key={key}>
                      <label>{LINE_META[key].label}</label>
                      <textarea
                        value={linesText(key)}
                        onChange={(e) => setLines(key, e.target.value)}
                        rows={2}
                        placeholder={LINE_META[key].ph}
                      />
                    </div>
                  ))}
                </div>
              )}
              <h4>自动记忆</h4>
              <label className="dsh-pet-sprite-check">
                <input
                  type="checkbox"
                  checked={autoMemory}
                  onChange={(e) => onAutoMemoryChange(e.target.checked)}
                />
                {petName} 每见证 5 轮完成悄悄记下关于主人的新事实（每天最多 8 次，用当前选的模型）
              </label>
              <h4>藤蔓攀爬</h4>
              <label className="dsh-pet-sprite-check">
                <input
                  type="checkbox"
                  checked={vineClimb}
                  onChange={(e) => onVineClimbChange(e.target.checked)}
                />
                高处平台长出藤蔓爬上去（藤蔓会盖住消息文字，默认关闭；关闭时只跳向够得着的气泡）
              </label>
              <h4>生成新形象</h4>
              <div className="dsh-pet-sprite-set-note">
                用一句话描述想要的伙伴，模型会画出它的像素形象并加入选择列表（当前 <PixelIcon icon="coin" size={10} />{stats.coins}）。
              </div>
              <input
                value={genDesc}
                onChange={(e) => setGenDesc(e.target.value)}
                placeholder="例如：戴圆眼镜的绿色小恐龙"
                maxLength={200}
                disabled={generating}
                onKeyDown={(e) => { if (e.key === 'Enter') void doGenerate() }}
              />
              <button
                className="dsh-pet-sprite-btn dsh-pet-sprite-gen-btn"
                onClick={() => { void doGenerate() }}
                disabled={generating || genDesc.trim().length === 0}
              >
                {generating ? '绘制中……' : customCount === 0 ? '生成新伙伴（首只免费）' : <>生成新伙伴（<PixelIcon icon="coin" size={11} />100）</>}
              </button>
              {genError !== null && <div className="dsh-pet-sprite-set-err">{genError}</div>}
              <h4>导入伙伴</h4>
              <div className="dsh-pet-sprite-set-note">
                朋友分享的 <b>.dsh-pet.json</b> 文件可以直接导入，免费加入形象列表。
              </div>
              <input
                ref={importInputRef}
                type="file"
                accept=".json,application/json"
                className="dsh-pet-sprite-import-file"
                onChange={(e) => {
                  doImportFile(e.target.files?.[0])
                  // allow re-picking the same file after fixing it elsewhere
                  e.target.value = ''
                }}
              />
              <div className="dsh-pet-sprite-import-row">
                <button className="dsh-pet-sprite-btn" onClick={() => importInputRef.current?.click()}>选择文件</button>
                <button
                  className="dsh-pet-sprite-btn"
                  onClick={() => { setPasteOpen(v => !v); setImportError(null) }}
                >
                  {pasteOpen ? '收起粘贴框' : '粘贴 JSON'}
                </button>
              </div>
              {pasteOpen && (
                <>
                  <textarea
                    value={pasteText}
                    onChange={(e) => setPasteText(e.target.value)}
                    placeholder='粘贴分享文件的内容（以 {"format":"dsh-pet-sprite" 开头）'
                    rows={3}
                    className="dsh-pet-sprite-paste-box"
                  />
                  <button
                    className="dsh-pet-sprite-btn dsh-pet-sprite-gen-btn"
                    onClick={() => doImport(pasteText)}
                    disabled={pasteText.trim().length === 0}
                  >
                    导入
                  </button>
                </>
              )}
              {importError !== null && <div className="dsh-pet-sprite-set-err">{importError}</div>}
              <h4>形象</h4>
              <button className="dsh-pet-sprite-btn dsh-pet-sprite-switch" onClick={onSwitchPet}>更换形象</button>
            </div>
          )}
        </div>
      </div>
      {toast && (
        <div
          key={toast.id}
          className="dsh-pet-sprite-toast"
          style={{ left: px, top: py - 34 }}
        >
          {toast.text}
        </div>
      )}
    </>
  )
}
