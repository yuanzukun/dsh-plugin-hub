#!/usr/bin/env node
// Build client/dsh-team-cost.client.js -> lib/client.js (minified) for the
// DSH client-module pipeline. The browser bundle is a single __ModuleLoader__
// factory closure (same pattern as dsh-cost-meter's lib/client.js).
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { resolve, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { transform } from 'esbuild'

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const src = readFileSync(resolve(projectRoot, 'client/dsh-team-cost.client.js'), 'utf8')
const result = await transform(src, {
  minify: true,
  keepNames: false,
  legalComments: 'none',
  target: 'es2022',
  format: 'esm',
  charset: 'utf8',
})
const header = '// Generated from client/dsh-team-cost.client.js via scripts/build-client.mjs (esbuild). Do not edit.\n'
mkdirSync(resolve(projectRoot, 'lib'), { recursive: true })
writeFileSync(resolve(projectRoot, 'lib/client.js'), header + result.code)
console.log(`client -> lib/client.js ${Buffer.byteLength(header + result.code)} bytes`)
