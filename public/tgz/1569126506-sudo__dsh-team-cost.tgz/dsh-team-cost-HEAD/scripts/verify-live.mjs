#!/usr/bin/env node
// 真实会话账本验证脚本(不依赖 DSH 运行):
//   node scripts/verify-live.mjs [--data-dir <路径>]
//
// 步骤:
//   1. 用你自己的 Key 启动 DSH 并跑几轮真实会话:
//        dsh --profile web
//      (插件已在 profile 里时无需任何额外参数;没装则先
//       `dsh plugin --profile web add dsh-team-cost` 或用 --patch 指到 dist/index.js)
//   2. 跑本脚本:校验 JSONL 账本完整性、按插件内置价目重算费用、
//      与 rollups.json 缓存对账。
//   3. 同时打开 设置 → 团队成本,看板数字应与脚本输出一致。

import { readdirSync, readFileSync, existsSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

const args = process.argv.slice(2)
const dirIdx = args.indexOf('--data-dir')
const dataDir = dirIdx >= 0 ? args[dirIdx + 1] : join(homedir(), '.dsh', '.dsh-team-cost')

let failures = 0
const check = (name, cond, detail = '') => {
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : '  ' + detail}`)
  if (!cond) failures++
}

if (!existsSync(dataDir)) {
  console.error(`未找到数据目录: ${dataDir}`)
  console.error('先启动 DSH 跑几轮真实会话(插件装好后账本会自动生成),再运行本脚本。')
  process.exit(1)
}

// 与 src/pricing.ts 同口径的内置价目(DeepSeek 2026-09 谷价, CNY/百万 token)。
const PRICE = { cr: 0.02, in: 1, out: 4 }
const reprice = (r) =>
  ((r.cr ?? 0) * PRICE.cr + ((r.in ?? 0) + (r.cw ?? 0)) * PRICE.in + (r.out ?? 0) * PRICE.out) / 1e6

const files = readdirSync(dataDir).filter((f) => /^usage-\d{4}-\d{2}\.jsonl$/.test(f))
check('找到账本文件', files.length > 0, files.join(', '))
if (files.length === 0) {
  console.log('\n数据目录还是空的:插件已装好但还没有真实模型调用。')
  console.log('启动 dsh --profile web 跑几轮会话(面板每 30 秒刷新),再运行本脚本。')
  process.exit(1)
}

const records = []
const badLines = []
for (const f of files) {
  const lines = readFileSync(join(dataDir, f), 'utf8').split('\n').filter(Boolean)
  for (const [i, line] of lines.entries()) {
    try {
      records.push(JSON.parse(line))
    } catch {
      badLines.push(`${f}:${i + 1}`)
    }
  }
}
check('账本行全部为合法 JSON', badLines.length === 0, badLines.join(', '))

const required = ['t', 'seq', 'sid', 'user', 'provider', 'model', 'in', 'out', 'cost']
const missing = records.filter((r) => required.some((k) => r[k] === undefined))
check('每条记录字段完整', missing.length === 0, `${missing.length} 条缺字段`)
const nonNeg = records.filter((r) => r.in < 0 || r.out < 0 || (r.cr ?? 0) < 0 || r.cost < 0)
check('token/费用无负数', nonNeg.length === 0)

const repriced = records.filter((r) => String(r.model).toLowerCase().includes('deepseek'))
const mismatches = repriced.filter((r) => Math.abs(reprice(r) - r.cost) > Math.max(1e-6, r.cost * 0.01))
check(
  `DeepSeek 记录费用与内置价目一致(抽查 ${repriced.length} 条)`,
  mismatches.length === 0,
  mismatches.length ? `示例: ${JSON.stringify(mismatches[0])}` : '',
)
const unpriced = records.length - repriced.length
if (unpriced > 0) console.log(`INFO  ${unpriced} 条非 DeepSeek 模型记录: token 已计量,费用需在 price-overrides.json 配置后才会计入`)

// 与 rollups 缓存对账
const rollupsPath = join(dataDir, 'rollups.json')
if (existsSync(rollupsPath)) {
  const cells = JSON.parse(readFileSync(rollupsPath, 'utf8')).cells ?? []
  const sum = (xs, k) => xs.reduce((s, x) => s + x, 0)
  const jsonlCost = sum(records.map((r) => r.cost))
  const cellCost = sum(cells.map((c) => c.cost))
  check('rollups.json 与账本总额一致', Math.abs(jsonlCost - cellCost) < 0.01, `jsonl=${jsonlCost.toFixed(4)} rollups=${cellCost.toFixed(4)}`)
} else {
  console.log('INFO  尚无 rollups.json(插件还没到首个落盘周期),跳过对账')
}

// 汇总输出
const byUser = new Map()
for (const r of records) {
  const u = byUser.get(r.user) ?? { cost: 0, calls: 0, tokens: 0 }
  u.cost += r.cost
  u.calls += 1
  u.tokens += (r.in ?? 0) + (r.out ?? 0) + (r.cr ?? 0) + (r.cw ?? 0)
  byUser.set(r.user, u)
}
console.log('\n── 账本汇总(按成员) ──')
for (const [user, u] of [...byUser.entries()].sort((a, b) => b[1].cost - a[1].cost)) {
  console.log(`  ${user.padEnd(16)} 调用 ${String(u.calls).padStart(5)}  tokens ${String(u.tokens).padStart(12)}  费用 ${u.cost.toFixed(4)} CNY`)
}
console.log(`  合计 ${records.length} 条记录\n`)

console.log(failures === 0 ? '账本校验全部通过 ✓  打开 设置 → 团队成本 核对看板数字。' : `${failures} 项校验失败,请把输出发给作者排查。`)
process.exit(failures === 0 ? 0 : 1)
