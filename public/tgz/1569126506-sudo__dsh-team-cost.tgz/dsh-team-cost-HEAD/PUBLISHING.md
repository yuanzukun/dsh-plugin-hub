# 发布与提交清单（PUBLISHING）

本文档是从 0 到「插件上架可见」的操作顺序。发布前确认 `npm run build` 与 `node test/smoke.mjs` 全绿。

## 1. 建 GitHub 仓库

```sh
cd dsh-team-cost
git init && git add -A && git commit -m "dsh-team-cost v0.2.1: per-member team cost metering, dashboard, quotas"
# 在 GitHub 建好空仓库后（仓库名建议就叫 dsh-team-cost，和 package.json 一致）：
git remote add origin git@github.com:<你的用户名>/dsh-team-cost.git
git push -u origin main
```

注意：把 `docs/dashboard-demo.png` 一并提交（README 里引用）。README 中的仓库链接目前是占位，提交前把两处 `<你的用户名>` 换成真实用户名。

## 2. 发布 npm

```sh
npm login
npm publish        # prepack 钩子会自动 build；包体 ~17 kB
```

发布后 `dsh plugin --profile web add dsh-team-cost` 即可直接装。

## 3. 提交 awesome-dsh-plugin 列表（核心分发渠道）

仓库：https://github.com/awesome-dsh-plugin/awesome-dsh-plugin

**投稿方式（以 contributing.md 为准，README 是生成的，不要手改 README）**：

1. fork 上游仓库；
2. 在 fork 上新增**一个文件**：`data/plugins/<owner>__<repo>.yml`（本插件的是 `1569126506-sudo__dsh-team-cost.yml`，已在本仓库历史之外的 fork main 分支上）；
3. PR 只包含这一个文件，标题格式 `add dsh-team-cost (usage): <一句话>`。

```yaml
url: https://github.com/1569126506-sudo/dsh-team-cost
name: 1569126506-sudo/dsh-team-cost
category: usage
description:
  en: 'Team cost captain: meters every model call (subagents included), attributes each call to a member by workspace rules, prices it with the built-in DeepSeek 2026-09 catalog (peak/off-peak, CNY/USD) or user overrides, and appends it to a local JSONL ledger. Adds hot-reloadable member budgets, 80%/100% webhook alerts, optional over-budget enforcement, a team_cost_report tool with CSV export, and a settings-page team dashboard served over a Typert RPC service.'
  zh: '团队成本管家：按成员/工作空间计量每次模型调用的 token 与费用（含子代理），内置 DeepSeek 2026-09 价目表与自定义价格覆盖，成员预算热更新、阈值 Webhook 告警、可选超支拦截，提供成本报表工具与 CSV 导出，并在设置页提供团队成本看板。'
```

**硬性规则（CI 自动检查）**：
- 仓库必须声明 `dsh.bundle`（package.json，已满足）并在根目录有 `cordis.patch.yml`（已满足）；
- **仓库创建满 1 天**才能提 PR——所以 PR 定在仓库创建 26 小时后自动提交；
- 仓库加 `dsh-plugin` topic（已加：dsh-plugin / deepseek / deepseek-harness / cost-tracking / team-management）；
- 描述必须与实际功能一一对应、不带营销词（YAML 里的每句都已核对过）。

**评审注意**（来自列表的收录规则）：描述里的每个功能宣称都会被人工核对（"如果描述写 46 个工具，他们会数到 46"）。上面的措辞与实际功能一一对应，不要扩写。

## 4. 提交 dshhub 市场收录

package.json 里的 `dshhub` 字段已填好（displayName / summary / categories / surfaces）。
按 dsh-market 的收录流程提交仓库地址即可；装好后插件会出现在设置→插件市场的「费用/Usage & Billing」分类。

## 5. 让最早的用户看到

- 在 DeepSeek Harness Discord 的插件频道发一条（带 docs/dashboard-demo.png 截图）；
- 官方 Discussions 的「Show Your Plugins!」分类发一篇，标题直接写要解决的问题：
  "dsh-team-cost — 团队场景按成员计量成本（含子代理），成员预算与告警"。
