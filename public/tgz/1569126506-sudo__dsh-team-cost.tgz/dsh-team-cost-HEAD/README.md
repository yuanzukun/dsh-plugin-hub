# dsh-team-cost · 团队成本管家

[English](#english) | 中文

> DeepSeek Harness 团队级 AI 用量与成本计量插件：**按成员、按项目**精确记录每一次模型调用的 token 与费用（子代理一并计入），内置成员预算、阈值告警、Webhook 通知、可选超支拦截，以及一个可以随时向 AI 查询的报表工具。

DeepSeek Harness (`dsh`) 正在被团队共用一台主机地使用，但生态里现存的 100+ 个用量插件几乎全是**单人自用仪表盘**：它们盯着自己会话的余额，回答不了团队最关心的问题——

- 这个月**每个人**花了多少钱？
- 子代理（subagent / Agent Teams 队友）的用量去哪了？（官方论坛已有团队反馈汇总口径少算 2.3×）
- 谁超预算了？超了要不要拦？

`dsh-team-cost` 只做这一件事，把它做完整。

## 功能

- **全量计量**：监听 `session/event`，从每条 `assistant/message` 读取官方 `TokenUsage`（未命中输入 / 输出 / 缓存命中 / 缓存写入 / 推理分列）。子代理会话照常上报，全部计入。
- **成员归因**：按工作空间路径前缀规则把会话归属到成员（`members=workspace` 规则，最长前缀优先）；配 `dsh-login` 每用户工作空间时每人只需一行规则。未匹配的会话归入可配置的默认成员。
- **计价**：内置 DeepSeek 2026-09 官方价目表（峰/谷价 × 人民币/美元），其他模型通过 `price-overrides.json` 配置；未配置的模型照常计 token，费用记 0。
- **成员预算**：每个成员独立的日/月费用与 token 预算，编辑 `<dataDir>/members.json` 一分钟内生效，无需重启。
- **告警**：越过 80%/100% 阈值时触发一次通知（去重），可推送 Webhook（企微/钉钉/飞书机器人直接可用）；同时派发 `dsh-team-cost/quota-exceeded` 事件给其他插件。
- **超支拦截（可选）**：`enforce: 'total'` 超过团队日预算后拦截新模型请求；`enforce: 'members'` 尝试按成员拦截（尽力而为，见配置注释）。默认只监控不拦截。
- **报表工具**：AI 工具 `team_cost_report`——问一句"出一下本月团队成本报表"即可按成员/模型/天分组统计，支持导出 CSV。

## 安装

```sh
# 从 GitHub 仓库安装
dsh plugin --profile web add https://github.com/1569126506-sudo/dsh-team-cost

# 或克隆到本地后从路径安装
git clone https://github.com/1569126506-sudo/dsh-team-cost.git
dsh plugin --profile web add ./dsh-team-cost
```

> npm 渠道（`dsh plugin --profile web add dsh-team-cost`）待账号注册开放后启用。

## 配置

插件配置（cordis 设置页 / patch）：

| 键 | 默认 | 说明 |
| --- | --- | --- |
| `dataDir` | `~/.dsh/.dsh-team-cost` | 数据目录（JSONL 账本、rollups、members.json、导出文件） |
| `enabled` | `true` | 总开关 |
| `currency` | `CNY` | 内置价目表币种：`CNY` / `USD` |
| `deepseekPeakPricing` | `false` | DeepSeek 使用峰价而非谷价 |
| `enforce` | `off` | `off` / `total` / `members`，见上文 |
| `totalDailyCost` | `0` | 团队日预算（`enforce: total` 时生效） |
| `alertThresholds` | `["80","100"]` | 告警阈值（百分比） |
| `alertWebhook` | 空 | 告警 Webhook POST 地址 |
| `attributionRules` | `[]` | 成员归因规则 `"成员=工作空间路径前缀"` |
| `defaultMember` | `unassigned` | 未匹配会话的归属成员 |
| `flushIntervalSec` | `15` | 聚合落盘间隔 |

成员预算示例（`~/.dsh/.dsh-team-cost/members.json`）：

```json
{
  "members": [
    { "name": "alice", "dailyCost": 20, "monthlyCost": 400 },
    { "name": "bob",   "dailyCost": 20, "dailyTokens": 50000000 }
  ]
}
```

价格覆盖示例（`price-overrides.json`，单位：每百万 token）：

```json
{ "kimi-k3": { "cr": 0.5, "in": 4, "out": 16 } }
```

## 报表

对 AI 说：

> 用 team_cost_report 出一下本月的团队成本报表，按成员分组，并导出 CSV

或直接调用工具参数：`range: today|month|all`，`groupBy: member|model|day`，`csv: "true"`。

## 验证真实账本

跑几轮真实会话后,校验账本完整性并把费用按内置价目重算对账:



## 数据与隐私

账本是纯本地 JSONL（`usage-YYYY-MM.jsonl`），聚合缓存在 `rollups.json`。不外发任何会话内容——计量只读取 token 计数、模型名与工作目录。

## 看板

设置 → 团队成本:

![团队成本看板](docs/dashboard-demo.png)

## 路线图

- [x] v0.2：Web 设置页成本看板（客户端面板,Typert RPC）
- [ ] dsh-login 原生身份桥接（免配置按登录名归因）
- [ ] 更多厂商内置价目与自动价格同步
- [ ] sqlite 存储后端与更长周期报表
- [ ] 团队配额与企业 SSO（商业版）

## License

MIT

---

<a id="english"></a>

## English

Team-scoped AI usage & cost metering for DeepSeek Harness. Every model call — subagents included — is metered from the official `session/event` firehose (`assistant/message` carries the step's `TokenUsage`), attributed to a team member via workspace-prefix rules, priced against the built-in DeepSeek 2026-09 catalog (peak/off-peak, CNY/USD) or user overrides, and appended to a local monthly JSONL ledger.

Per-member daily/monthly budgets live in `<dataDir>/members.json` (hot-reloaded); crossing 80%/100% thresholds fires de-duplicated alerts and an optional webhook. `enforce: 'total' | 'members'` can block new model requests over budget (off by default). The `team_cost_report` tool answers "how much did the team spend this month?" by member, model, or day, with CSV export.

No conversation content ever leaves the machine: metering reads token counts, model ids, and the session working directory only.
