// Smoke test for dsh-team-cost core logic (no DSH host required).
// Run: node test/smoke.mjs
import { mkdtempSync, writeFileSync, readFileSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { UsageStore } from '../dist/store.js'
import { Pricing } from '../dist/pricing.js'
import { Attribution } from '../dist/attribution.js'
import { Quota } from '../dist/quota.js'

const dataDir = mkdtempSync(join(tmpdir(), 'dsh-team-cost-'))
let failures = 0
const check = (name, cond, detail = '') => {
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : '  ' + detail}`)
  if (!cond) failures++
}

// --- pricing: DeepSeek 2026-09 off-peak CNY (cr 0.02 / in 1 / out 4 per Mtok)
const pricing = new Pricing('CNY', false)
const cost = pricing.cost('deepseek-v4.1-flash', { inputTokens: 1_000_000, outputTokens: 1_000_000, cacheReadTokens: 1_000_000 })
check('deepseek offpeak cost = 5.02 CNY per 1M+1M+1M', Math.abs(cost - 5.02) < 1e-9, String(cost))
const peak = new Pricing('CNY', true).cost('deepseek-v4.1-flash', { inputTokens: 1_000_000, outputTokens: 1_000_000, cacheReadTokens: 1_000_000 })
check('deepseek peak cost = 10.04', Math.abs(peak - 10.04) < 1e-9, String(peak))
const usd = new Pricing('USD', false).cost('deepseek-v4.1-flash', { inputTokens: 1_000_000, outputTokens: 0 })
check('deepseek usd input = 0.15', Math.abs(usd - 0.15) < 1e-9, String(usd))
pricing.setOverrides({ 'gpt-9': { cr: 0, in: 2, out: 8 } })
check('override wins', Math.abs(pricing.cost('gpt-9', { inputTokens: 500_000, outputTokens: 0 }) - 1) < 1e-9)
check('unknown model falls back to 0', pricing.cost('some-unknown-model', { inputTokens: 999, outputTokens: 999 }) === 0)

// --- attribution: longest prefix wins, unknown → default
const attr = new Attribution(
  ['alice=C:\\teams\\alice', 'bob=C:\\teams\\alice\\client-b', '=bad-rule', 'x'],
  'unassigned',
)
check('alice rule', attr.resolve('C:\\teams\\alice\\proj') === 'alice')
check('longest prefix wins', attr.resolve('C:\\teams\\alice\\client-b\\app') === 'bob')
check('default for unknown', attr.resolve('C:\\elsewhere') === 'unassigned')
check('default for empty', attr.resolve('') === 'unassigned')

// --- store: record, aggregate, totals, csv export
const store = new UsageStore(dataDir, 5)
await store.init()
const mk = (t, user, model, o) => ({
  t, seq: 1, sid: 's-' + user, ws: 'C:\\teams\\alice', user, provider: 'deepseek', model,
  in: o.in, out: o.out, cr: o.cr ?? 0, cw: 0, cost: o.cost,
})
const today = new Date()
const iso = (d) => d.toISOString()
await store.record(mk(iso(today), 'alice', 'deepseek-v4.1-flash', { in: 1_000_000, out: 100_000, cr: 500_000, cost: 1.5 }))
await store.record(mk(iso(today), 'alice', 'deepseek-v4.1-flash', { in: 2_000_000, out: 200_000, cr: 0, cost: 2.5 }))
const yesterday = new Date(today.getTime() - 86400_000)
await store.record(mk(iso(yesterday), 'bob', 'deepseek-v4.1-flash', { in: 3_000_000, out: 300_000, cr: 0, cost: 3.0 }))

const todayByMember = store.aggregate('today', 'member')
check('today aggregate: 1 member row', todayByMember.length === 1, JSON.stringify(todayByMember))
check('today alice cost 4.0', Math.abs(todayByMember[0].cost - 4.0) < 1e-9)
const allByModel = store.aggregate('all', 'model')
check('all aggregate: 1 model row, 3 calls, 7.0 cost', allByModel.length === 1 && allByModel[0].calls === 3 && Math.abs(allByModel[0].cost - 7.0) < 1e-9, JSON.stringify(allByModel))
const aliceTotals = store.totalsFor('alice')
check('alice today totals', aliceTotals.todayCost === 4.0 && aliceTotals.todayTokens === 3_800_000, JSON.stringify(aliceTotals))
const csvFile = await store.exportCsv('all')
check('csv exported', existsSync(csvFile))
const csv = readFileSync(csvFile, 'utf8')
check('csv has 2 day rows + header', csv.trim().split('\n').length === 3)

// --- quota: budgets from members.json, thresholds, blocking
writeFileSync(join(dataDir, 'members.json'), JSON.stringify({
  members: [{ name: 'alice', dailyCost: 5, dailyTokens: 10_000_000 }],
}))
const alerts = []
const quota = new Quota(dataDir, store, [80, 100], '', (e) => alerts.push(String(e)))
await quota.loadMembers()
const st = await quota.evaluate('alice')
check('alice over dailyCost (4/5 = 80%)', st.level === 0.8 && !st.over, JSON.stringify(st))
check('80% alert fired once', alerts.length === 1, JSON.stringify(alerts))
check('alice not blocked yet', quota.isBlocked('alice') === false)
await store.record(mk(iso(today), 'alice', 'deepseek-v4.1-flash', { in: 1_000_000, out: 0, cr: 0, cost: 1.1 }))
const st2 = await quota.evaluate('alice')
check('alice now over (5.1/5)', st2.over && st2.exceeded.includes('dailyCost'), JSON.stringify(st2))
check('alice blocked', quota.isBlocked('alice') === true)
const st3 = await quota.evaluate('nobody')
check('unknown member unlimited', !st3.over && st3.level === 0)
check('webhook empty: no crash', quota.dispose() === undefined)

// --- jsonl durability: restart rebuilds totals from rollups.json
await store.dispose()
const store2 = new UsageStore(dataDir, 5)
await store2.init()
const totals2 = store2.totalsFor('alice')
check('totals survive restart via rollups cache', Math.abs(totals2.todayCost - 5.1) < 1e-9, JSON.stringify(totals2))

console.log(failures === 0 ? '\nALL PASS' : `\n${failures} FAILURES`)
process.exit(failures === 0 ? 0 : 1)
