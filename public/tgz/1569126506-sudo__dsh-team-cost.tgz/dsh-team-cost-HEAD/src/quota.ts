import { readFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { join } from 'node:path'
import type { MembersFile, QuotaStatus } from './types.js'
import type { UsageStore } from './store.js'

const RELOAD_MS = 60_000

/**
 * Member budgets + threshold alerts + optional enforcement.
 *
 * Budgets live in <dataDir>/members.json ({ "members": [{ name, dailyCost,
 * monthlyCost, dailyTokens, monthlyTokens }] }) and hot-reload every minute,
 * so admins edit the file without restarting DSH.
 */
export class Quota {
  private members = new Map<string, { dailyCost?: number; monthlyCost?: number; dailyTokens?: number; monthlyTokens?: number }>()
  private lastLoad = 0
  private alerted = new Set<string>()
  private reloadTimer: ReturnType<typeof setInterval> | undefined

  constructor(
    private readonly dataDir: string,
    private readonly store: UsageStore,
    private readonly thresholds: readonly number[],
    private readonly webhook: string,
    private readonly onError?: (err: unknown) => void,
  ) {}

  start(): void {
    this.reloadTimer = setInterval(() => this.loadMembers().catch((e) => this.onError?.(e)), RELOAD_MS)
    this.reloadTimer.unref?.()
  }

  dispose(): void {
    if (this.reloadTimer) clearInterval(this.reloadTimer)
  }

  get membersPath(): string {
    return join(this.dataDir, 'members.json')
  }

  async loadMembers(): Promise<void> {
    this.lastLoad = Date.now()
    if (!existsSync(this.membersPath)) return
    try {
      const parsed: unknown = JSON.parse(await readFile(this.membersPath, 'utf8'))
      const file = parsed as MembersFile
      if (Array.isArray(file.members)) {
        this.members = new Map(file.members.map((m) => [m.name, m]))
      }
    } catch (err) {
      this.onError?.(err)
    }
  }

  private ensureFresh(): void {
    if (Date.now() - this.lastLoad > RELOAD_MS) void this.loadMembers()
  }

  /** All configured member names (budget file order). */
  memberNames(): string[] {
    this.ensureFresh()
    return [...this.members.keys()]
  }

  /** Budget lines for one member, or {} when unconfigured. */
  budgetsFor(user: string): { dailyCost?: number; monthlyCost?: number; dailyTokens?: number; monthlyTokens?: number } {
    this.ensureFresh()
    const b = this.members.get(user)
    if (!b) return {}
    return { dailyCost: b.dailyCost, monthlyCost: b.monthlyCost, dailyTokens: b.dailyTokens, monthlyTokens: b.monthlyTokens }
  }

  /**
   * Evaluate one metered call. Fires webhook alerts on newly crossed
   * thresholds (per member+threshold, once per day) and returns the status.
   */
  async evaluate(user: string): Promise<QuotaStatus> {
    this.ensureFresh()
    const budget = this.members.get(user)
    const totals = this.store.totalsFor(user)
    const status: QuotaStatus = { user, level: 0, exceeded: [], over: false }
    if (!budget) return status

    const lines: Array<[string, number, number]> = [
      ['dailyCost', budget.dailyCost ?? 0, totals.todayCost],
      ['monthlyCost', budget.monthlyCost ?? 0, totals.monthCost],
      ['dailyTokens', budget.dailyTokens ?? 0, totals.todayTokens],
      ['monthlyTokens', budget.monthlyTokens ?? 0, totals.monthTokens],
    ]
    for (const [name, limit, value] of lines) {
      if (!limit || limit <= 0) continue
      const fraction = value / limit
      if (fraction >= 1) {
        status.over = true
        status.exceeded.push(name)
        status.level = Math.max(status.level, 1)
        this.alertOnce(user, `${name}:100`, `成员 ${user} 已超出 ${name} 预算 (${Math.round(value)}/${limit})`)
      } else {
        for (const threshold of this.thresholds) {
          if (threshold > 0 && threshold < 100 && fraction >= threshold / 100) {
            status.level = Math.max(status.level, threshold / 100)
            this.alertOnce(user, `${name}:${threshold}`, `成员 ${user} 用量已达 ${name} 预算的 ${threshold}% (${Math.round(value)}/${limit})`)
          }
        }
      }
    }
    return status
  }

  /** True when new model requests for this member should be blocked. */
  isBlocked(user: string): boolean {
    this.ensureFresh()
    const budget = this.members.get(user)
    if (!budget) return false
    const totals = this.store.totalsFor(user)
    if ((budget.dailyCost ?? 0) > 0 && totals.todayCost >= (budget.dailyCost ?? 0)) return true
    if ((budget.monthlyCost ?? 0) > 0 && totals.monthCost >= (budget.monthlyCost ?? 0)) return true
    if ((budget.dailyTokens ?? 0) > 0 && totals.todayTokens >= (budget.dailyTokens ?? 0)) return true
    if ((budget.monthlyTokens ?? 0) > 0 && totals.monthTokens >= (budget.monthlyTokens ?? 0)) return true
    return false
  }

  private alertOnce(user: string, key: string, message: string): void {
    const dedupe = `${user}:${new Date().toISOString().slice(0, 10)}:${key}`
    if (this.alerted.has(dedupe)) return
    this.alerted.add(dedupe)
    const totals = this.store.totalsFor(user)
    this.onError?.(new Error(`[dsh-team-cost] ${message}`))
    if (this.webhook) {
      const body = JSON.stringify({
        plugin: 'dsh-team-cost',
        user,
        message,
        todayCost: Number(totals.todayCost.toFixed(4)),
        monthCost: Number(totals.monthCost.toFixed(4)),
        time: new Date().toISOString(),
      })
      void fetch(this.webhook, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body,
      }).catch((err) => this.onError?.(err))
    }
  }
}
