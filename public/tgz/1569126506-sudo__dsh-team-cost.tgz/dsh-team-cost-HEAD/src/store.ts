import { appendFile, mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { join } from 'node:path'
import type { RollupCell, UsageRecord } from './types.js'

function pad2(n: number): string {
  return String(n).padStart(2, '0')
}

/** Local-time day key (YYYY-MM-DD) — must match `todayKey()`. */
function dayKeyOf(iso: string): string {
  const d = new Date(iso)
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`
}

function monthKeyOf(iso: string): string {
  return dayKeyOf(iso).slice(0, 7)
}

/**
 * Append-only JSONL metering log plus an in-memory aggregate, flushed to a
 * small JSON file for fast startup. The JSONL file is the source of truth;
 * rollups.json is a cache and is rebuilt from it on demand.
 */
export class UsageStore {
  private cells = new Map<string, RollupCell>()
  private flushTimer: ReturnType<typeof setInterval> | undefined

  constructor(
    private readonly dataDir: string,
    private flushIntervalSec: number,
  ) {}

  async init(): Promise<void> {
    await mkdir(this.dataDir, { recursive: true })
    await mkdir(join(this.dataDir, 'exports'), { recursive: true })
    await this.loadRollups()
  }

  startFlushing(onError?: (err: unknown) => void): void {
    const sec = Math.max(5, this.flushIntervalSec)
    this.flushTimer = setInterval(() => {
      this.flush().catch((err) => onError?.(err))
    }, sec * 1000)
    this.flushTimer.unref?.()
  }

  async dispose(): Promise<void> {
    if (this.flushTimer) clearInterval(this.flushTimer)
    await this.flush()
  }

  private jsonlPath(iso: string): string {
    return join(this.dataDir, `usage-${monthKeyOf(iso)}.jsonl`)
  }

  private get rollupsPath(): string {
    return join(this.dataDir, 'rollups.json')
  }

  async record(rec: UsageRecord): Promise<void> {
    await appendFile(this.jsonlPath(rec.t), JSON.stringify(rec) + '\n', 'utf8')
    const key = `${dayKeyOf(rec.t)}\u0000${rec.user}\u0000${rec.model}`
    let cell = this.cells.get(key)
    if (!cell) {
      cell = { day: dayKeyOf(rec.t), user: rec.user, model: rec.model, calls: 0, in: 0, out: 0, cr: 0, cw: 0, cost: 0 }
      this.cells.set(key, cell)
    }
    cell.calls += 1
    cell.in += rec.in
    cell.out += rec.out
    cell.cr += rec.cr ?? 0
    cell.cw += rec.cw ?? 0
    cell.cost += rec.cost
  }

  private cellList(): RollupCell[] {
    return [...this.cells.values()]
  }

  todayKey(): string {
    const now = new Date()
    const y = now.getFullYear()
    const m = String(now.getMonth() + 1).padStart(2, '0')
    const d = String(now.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }

  monthKey(): string {
    return this.todayKey().slice(0, 7)
  }

  /** Aggregate rows over a range, grouped by 'member' | 'model' | 'day'. */
  aggregate(range: 'today' | 'month' | 'all', groupBy: 'member' | 'model' | 'day'): RollupCell[] {
    const today = this.todayKey()
    const month = this.monthKey()
    const acc = new Map<string, RollupCell>()
    for (const cell of this.cellList()) {
      if (range === 'today' && cell.day !== today) continue
      if (range === 'month' && !cell.day.startsWith(month)) continue
      const groupKey = groupBy === 'member' ? cell.user : groupBy === 'model' ? cell.model : cell.day
      let row = acc.get(groupKey)
      if (!row) {
        row = { day: cell.day, user: groupBy === 'member' ? groupKey : '*', model: groupBy === 'model' ? groupKey : '*', calls: 0, in: 0, out: 0, cr: 0, cw: 0, cost: 0 }
        acc.set(groupKey, row)
      }
      row.calls += cell.calls
      row.in += cell.in
      row.out += cell.out
      row.cr += cell.cr
      row.cw += cell.cw
      row.cost += cell.cost
    }
    return [...acc.values()].sort((a, b) => b.cost - a.cost)
  }

  /** Totals for one member (or '*') over today and this month. */
  totalsFor(user: string): { todayCost: number; todayTokens: number; monthCost: number; monthTokens: number } {
    const today = this.todayKey()
    const month = this.monthKey()
    const out = { todayCost: 0, todayTokens: 0, monthCost: 0, monthTokens: 0 }
    for (const cell of this.cellList()) {
      if (user !== '*' && cell.user !== user) continue
      const tokens = cell.in + cell.out + cell.cr + cell.cw
      if (cell.day === today) {
        out.todayCost += cell.cost
        out.todayTokens += tokens
      }
      if (cell.day.startsWith(month)) {
        out.monthCost += cell.cost
        out.monthTokens += tokens
      }
    }
    return out
  }

  async exportCsv(range: 'today' | 'month' | 'all'): Promise<string> {
    const rows = this.aggregate(range, 'day')
    const header = 'day,member,model,calls,input_tokens,output_tokens,cache_read,cache_write,cost\n'
    const lines = rows.map((r) => `${r.day},${r.user},${r.model},${r.calls},${r.in},${r.out},${r.cr},${r.cw},${r.cost.toFixed(6)}`)
    const csv = header + lines.join('\n') + '\n'
    const file = join(this.dataDir, 'exports', `report-${range}-${Date.now()}.csv`)
    await writeFile(file, csv, 'utf8')
    return file
  }

  private async flush(): Promise<void> {
    const payload = JSON.stringify({ version: 1, cells: this.cellList() })
    const tmp = this.rollupsPath + '.tmp'
    await writeFile(tmp, payload, 'utf8')
    await rename(tmp, this.rollupsPath)
  }

  private async loadRollups(): Promise<void> {
    if (!existsSync(this.rollupsPath)) return
    try {
      const parsed: unknown = JSON.parse(await readFile(this.rollupsPath, 'utf8'))
      const cells = (parsed as { cells?: RollupCell[] }).cells
      if (Array.isArray(cells)) {
        for (const cell of cells) {
          if (cell && typeof cell.day === 'string' && typeof cell.user === 'string' && typeof cell.model === 'string') {
            this.cells.set(`${cell.day}\u0000${cell.user}\u0000${cell.model}`, cell)
          }
        }
      }
    } catch {
      // Corrupt cache: rebuild lazily is not implemented in MVP; keep going
      // with in-memory only aggregates — the JSONL log still has everything.
    }
  }
}
