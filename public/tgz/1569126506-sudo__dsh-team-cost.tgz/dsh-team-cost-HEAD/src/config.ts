import z from '@deepseek-ai/schemastery'

/** Plugin configuration for the dsh-team-cost metering plugin. */
export interface Config {
  /** Directory for data files (usage JSONL, rollups, members.json, exports).
   * When empty, resolved to `<dshHome>/.dsh-team-cost` at apply time. */
  dataDir: string
  /** Whether metering is active (default true). When false, the plugin
   * registers nothing. */
  enabled: boolean
  /** Currency for built-in prices and report labels: 'CNY' or 'USD'. */
  currency: string
  /** Use DeepSeek peak pricing instead of off-peak for the builtin catalog. */
  deepseekPeakPricing: boolean
  /**
   * Enforcement mode:
   * - 'off' (default): meter and alert only, never block model requests.
   * - 'total': block new model requests once the TOTAL daily cost budget is
   *   exceeded (set `totalDailyCost` > 0 to arm).
   * - 'members': additionally block a member's new requests once that member
   *   is over any of their 100% budgets. Member resolution inside the request
   *   hook is best-effort (workspace-based); sessions that cannot be resolved
   *   are allowed. Requires a DSH version whose agent payload exposes the
   *   session; when it does not, 'members' behaves like 'off' for unresolved
   *   agents — which is why 'off' remains the default.
   */
  enforce: string
  /** Total daily cost budget across all members, in currency major units.
   * 0 disables the total budget (default). Used by enforce='total'. */
  totalDailyCost: number
  /** Fractions that trigger an alert, e.g. 80 and 100. */
  alertThresholds: string[]
  /** Optional HTTP(S) endpoint receiving a JSON POST on every threshold
   * crossing: { user, level, exceeded, todayCost, monthCost }. Empty
   * disables webhook alerts. */
  alertWebhook: string
  /**
   * Member attribution rules, tried longest-prefix first. Each rule is
   * `memberName=workspacePathPrefix` (the member, '=', then the cwd prefix).
   * Sessions whose cwd matches a prefix are attributed to that member.
   * Unmatched sessions fall back to `defaultMember`. Tip: if you run
   * dsh-login, add one rule per user workspace (its per-user sandbox root
   * makes this a one-line mapping per member).
   */
  attributionRules: string[]
  /** Member name for sessions that match no attribution rule. */
  defaultMember: string
  /** Flush rollups to disk every N seconds (default 15). */
  flushIntervalSec: number
}

export const Config: z<Config> = z.object({
  dataDir: z.string().default(''),
  enabled: z.boolean().default(true),
  currency: z.string().default('CNY'),
  deepseekPeakPricing: z.boolean().default(false),
  enforce: z.string().default('off'),
  totalDailyCost: z.natural().default(0),
  alertThresholds: z.array(String).default(['80', '100']),
  alertWebhook: z.string().default(''),
  attributionRules: z.array(String).default([]),
  defaultMember: z.string().default('unassigned'),
  flushIntervalSec: z.natural().default(15),
})
