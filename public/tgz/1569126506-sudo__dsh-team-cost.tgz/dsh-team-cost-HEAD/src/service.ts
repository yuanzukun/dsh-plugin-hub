import type { UsageStore } from './store.js'
import type { Quota } from './quota.js'
import type { GroupRow, MemberRow, TeamCostState } from './types.js'

/**
 * The `teamCost` remote service consumed by the web dashboard through the
 * Typert gateway (`remote.teamCost.getState()`). Bound with a `typertRemote`
 * property so the gateway's validateBinding accepts the hand-written
 * `./typert` manifest.
 */
export function createTeamCostService(deps: {
  store: UsageStore
  quota: Quota
  currency: string
  enforce: string
}): TeamCostService {
  const { store, quota, currency, enforce } = deps

  const service = {
    /** Full dashboard snapshot: member rows with budgets/totals, model rows. */
    async getState(): Promise<TeamCostState> {
      const memberRows: MemberRow[] = []
      const knownMembers = quota.memberNames()
      const seen = new Set<string>(knownMembers)
      for (const name of knownMembers) {
        const totals = store.totalsFor(name)
        const status = await quota.evaluate(name)
        const budgets = quota.budgetsFor(name)
        memberRows.push({
          name,
          todayCost: totals.todayCost,
          todayTokens: totals.todayTokens,
          monthCost: totals.monthCost,
          monthTokens: totals.monthTokens,
          dailyCost: budgets.dailyCost,
          monthlyCost: budgets.monthlyCost,
          dailyTokens: budgets.dailyTokens,
          monthlyTokens: budgets.monthlyTokens,
          level: status.level,
          over: status.over,
        })
      }
      const fold = (rows: ReturnType<UsageStore['aggregate']>): GroupRow[] =>
        rows.map((r) => ({
          key: r.model !== '*' ? r.model : r.user,
          calls: r.calls,
          inTok: r.in + r.cw,
          outTok: r.out,
          cacheRead: r.cr,
          cacheWrite: r.cw,
          cost: r.cost,
        }))
      // Members that metered activity but have no budgets file entry.
      for (const row of store.aggregate('month', 'member')) {
        if (seen.has(row.user)) continue
        seen.add(row.user)
        const totals = store.totalsFor(row.user)
        memberRows.push({
          name: row.user,
          todayCost: totals.todayCost,
          todayTokens: totals.todayTokens,
          monthCost: totals.monthCost,
          monthTokens: totals.monthTokens,
          level: 0,
          over: false,
        })
      }
      memberRows.sort((a, b) => b.monthCost - a.monthCost)
      const now = new Date()
      return {
        currency,
        enforce,
        generatedAt: now.getTime(),
        dayKey: store.todayKey(),
        monthKey: store.monthKey(),
        members: memberRows,
        todayByModel: fold(store.aggregate('today', 'model')),
        monthByModel: fold(store.aggregate('month', 'model')),
      }
    },
  }
  Object.defineProperty(service, 'typertRemote', {
    configurable: false,
    enumerable: false,
    writable: false,
    value: { service, serviceKey: 'teamCost', namespace: 'teamCost' },
  })
  return service
}

export interface TeamCostService {
  getState(): Promise<TeamCostState>
}
