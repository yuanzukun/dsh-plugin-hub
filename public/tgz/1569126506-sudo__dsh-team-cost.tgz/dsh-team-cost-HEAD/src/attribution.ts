/** Member attribution: map a session workspace (cwd) to a team member. */

export interface AttributionRule {
  member: string
  prefix: string
}

/**
 * Parse `memberName=workspacePathPrefix` rules. Longest prefixes win;
 * malformed entries (no '=') are ignored so a typo cannot take the
 * metering plugin down.
 */
export function parseRules(entries: readonly string[]): AttributionRule[] {
  const rules: AttributionRule[] = []
  for (const entry of entries) {
    const eq = entry.indexOf('=')
    if (eq <= 0 || eq === entry.length - 1) continue
    const member = entry.slice(0, eq).trim()
    const prefix = entry.slice(eq + 1).trim()
    if (member && prefix) rules.push({ member, prefix })
  }
  rules.sort((a, b) => b.prefix.length - a.prefix.length)
  return rules
}

/** Normalize a path for comparison: forward slashes, no trailing slash. */
function normalizePath(p: string): string {
  return p.replaceAll('\\', '/').replace(/\/+$/, '').toLowerCase()
}

export class Attribution {
  private readonly rules: AttributionRule[]

  constructor(
    entries: readonly string[],
    private readonly defaultMember: string,
  ) {
    this.rules = parseRules(entries)
  }

  /** Resolve the member for one session cwd (may be empty/unknown). */
  resolve(cwd: string | undefined): string {
    if (!cwd) return this.defaultMember
    const norm = normalizePath(cwd)
    for (const rule of this.rules) {
      if (norm.startsWith(normalizePath(rule.prefix))) return rule.member
    }
    return this.defaultMember
  }
}
