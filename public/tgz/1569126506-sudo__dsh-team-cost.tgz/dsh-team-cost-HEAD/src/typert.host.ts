/**
 * dsh-team-cost Host-face Typert manifest, hand-written to the exact shape
 * the typert-loader scans (`./typert` export `TYPERT`, zod v4 codecs).
 * Mirrors @deepseek-ai/dsh-typert-generator output; see dsh-cost-meter's
 * lib/typert.host.js for the reference implementation this follows.
 */

import { z } from 'zod'

const num = z.number()

const memberRowSchema = z.object({
  name: z.string(),
  todayCost: num,
  todayTokens: num,
  monthCost: num,
  monthTokens: num,
  dailyCost: num.optional(),
  monthlyCost: num.optional(),
  dailyTokens: num.optional(),
  monthlyTokens: num.optional(),
  level: num,
  over: z.boolean(),
})

const groupRowSchema = z.object({
  key: z.string(),
  calls: num,
  inTok: num,
  outTok: num,
  cacheRead: num,
  cacheWrite: num,
  cost: num,
})

export const stateSchema = z.object({
  currency: z.string(),
  enforce: z.string(),
  generatedAt: num,
  dayKey: z.string(),
  monthKey: z.string(),
  members: z.array(memberRowSchema),
  todayByModel: z.array(groupRowSchema),
  monthByModel: z.array(groupRowSchema),
})

const _state$codec = { mode: 'strict', typeSymbol: 'dsh-team-cost#TeamCostState', schema: stateSchema }

export const TYPERT = {
  package: 'dsh-team-cost',
  face: 'host',
  schemas: [],
  model: {
    services: [
      {
        description:
          'dsh-team-cost 团队成本服务(ctx.teamCost):按成员/模型聚合 token 用量与费用。Team cost service (ctx.teamCost) aggregating per-member, per-model token usage and cost.',
        summary: 'dsh-team-cost 团队成本服务 (team cost & quota dashboard service)。',
        tags: [],
        jsDoc:
          '/** dsh-team-cost 团队成本服务(ctx.teamCost)。Team cost service (ctx.teamCost). */',
        key: 'teamCost',
        exportName: 'TeamCostService',
        members: [
          {
            kind: 'method',
            name: 'getState',
            signature: 'getState(): Promise<TeamCostState>',
            summary: '读取团队成本看板快照。Read the team cost dashboard snapshot.',
            description:
              '返回全部成员的今日/本月费用、token 用量、预算与阈值状态,以及按模型聚合的用量。Returns every member\'s today/month cost, token usage, budgets and threshold status, plus per-model aggregates.',
            tags: [],
            jsDoc:
              '/** 读取团队成本看板快照。Read the team cost dashboard snapshot. */',
          },
        ],
        types: [],
      },
    ],
    events: [],
    objects: [],
  },
  invocations: [
    {
      id: 'dsh-team-cost#teamCost/getState',
      service: 'teamCost',
      namespace: 'teamCost',
      method: 'getState',
      invocation: { kind: 'direct' },
      parameters: [],
      result: _state$codec,
    },
  ],
}

export default TYPERT
