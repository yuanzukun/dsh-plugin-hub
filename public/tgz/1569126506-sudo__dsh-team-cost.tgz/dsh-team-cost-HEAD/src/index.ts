import { homedir } from 'node:os'
import { join } from 'node:path'
import { readFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import type { Context } from '@deepseek-ai/cordis'
import { Config, type Config as ConfigShape } from './config.js'
import { Attribution } from './attribution.js'
import { Pricing } from './pricing.js'
import { UsageStore } from './store.js'
import { Quota } from './quota.js'
import { createReportTool } from './report.js'
import { createTeamCostService } from './service.js'
import type { UsageRecord, QuotaStatus } from './types.js'

export const name = 'dsh-team-cost'

/** The tool registry is required for the report tool. */
export const inject = ['tools']

export { Config }

declare module '@deepseek-ai/cordis' {
  interface Events {
    /** Fired when a member crosses any configured budget (100%). */
    'dsh-team-cost/quota-exceeded': (payload: QuotaStatus) => void
  }
}

/** dsh-login's home resolution: DSH_HOME env, else ~/.dsh. */
function resolveDshHome(): string {
  const env = process.env.DSH_HOME
  return env !== undefined && env.length > 0 ? env : join(homedir(), '.dsh')
}

/**
 * Team cost captain for DeepSeek Harness.
 *
 * - Meters every model call from the `session/event` firehose
 *   (`assistant/message` events carry the step's TokenUsage), subagents
 *   included: any session that reports usage is metered.
 * - Attributes each call to a team member via workspace-prefix rules.
 * - Prices the call against the builtin DeepSeek 2026-09 catalog or user
 *   overrides, and appends the record to a monthly JSONL log.
 * - Evaluates member budgets, alerts thresholds via webhook, and can block
 *   new model requests in enforce mode.
 */
export function apply(ctx: Context, config: ConfigShape): void {
  if (!config.enabled) return

  const dataDir = config.dataDir === '' ? join(resolveDshHome(), '.dsh-team-cost') : config.dataDir
  const onError = (err: unknown): void => {
    ctx.logger.warn(err instanceof Error ? err.message : String(err))
  }

  const store = new UsageStore(dataDir, config.flushIntervalSec)
  const attribution = new Attribution(config.attributionRules, config.defaultMember)
  const pricing = new Pricing(config.currency, config.deepseekPeakPricing)
  const quota = new Quota(dataDir, store, config.alertThresholds.map(Number), config.alertWebhook, onError)

  const loadOverrides = async (): Promise<void> => {
    const file = join(dataDir, 'price-overrides.json')
    if (!existsSync(file)) return
    try {
      pricing.setOverrides(JSON.parse(await readFile(file, 'utf8')))
    } catch (err) {
      onError(err)
    }
  }

  void store
    .init()
    .then(loadOverrides)
    .then(() => {
      store.startFlushing(onError)
      quota.start()
    })
    .catch(onError)

  ctx.effect(() => () => {
    void store.dispose()
    quota.dispose()
  })

  // Meter one usage-bearing assistant message. The firehose delivers every
  // session — top-level or subagent — so team and teammate spend is counted
  // in full instead of being lost to single-session dashboards.
  ctx.on('session/event', (session, event) => {
    if (event.type !== 'assistant/message') return
    const usage = event.data.usage
    if (!usage) return
    const source = event.data.message.source
    const header = session.header
    const user = attribution.resolve(header.cwd)
    const record: UsageRecord = {
      t: new Date(event.time).toISOString(),
      seq: event.seq,
      sid: header.id,
      ws: header.cwd ?? '',
      user,
      provider: source.provider,
      model: source.model,
      in: usage.inputTokens ?? 0,
      out: usage.outputTokens ?? 0,
      cr: usage.cacheReadTokens,
      cw: usage.cacheWriteTokens,
      rz: usage.reasoningTokens,
      cost: Number(pricing.cost(source.model, usage).toFixed(6)),
    }
    void store
      .record(record)
      .then(() => quota.evaluate(user))
      .then((status) => {
        if (status.over) ctx.emit('dsh-team-cost/quota-exceeded', status)
      })
      .catch(onError)
  })

  if (config.enforce !== 'off') {
    ctx.on('agent/request', (payload, next) => {
      if (config.enforce === 'total') {
        if (config.totalDailyCost > 0) {
          const totals = store.totalsFor('*')
          if (totals.todayCost >= config.totalDailyCost) {
            throw new Error(
              `[dsh-team-cost] 团队今日费用已超预算 ${totals.todayCost.toFixed(2)}/${config.totalDailyCost} ${config.currency}，新请求已被拦截`,
            )
          }
        }
      } else if (config.enforce === 'members') {
        // Best-effort member resolution from the agent's session header.
        const agent = payload.agent as { session?: { header?: { cwd?: string } } } | undefined
        const user = attribution.resolve(agent?.session?.header?.cwd)
        if (quota.isBlocked(user)) {
          throw new Error(
            `[dsh-team-cost] 成员 ${user} 已超出预算，新请求已被拦截（调整 <dataDir>/members.json 后一分钟内生效）`,
          )
        }
      }
      return next()
    })
  }

  ctx.tools.register(createReportTool({ store, currency: config.currency }))

  // RPC 服务:Web 看板经 remote.teamCost.getState() 读取快照(./typert 清单由
  // typert-loader 自动扫描注册)。
  ctx.provide(
    'teamCost',
    createTeamCostService({ store, quota, currency: config.currency, enforce: config.enforce }),
  )
}
