import type { ModelPrice } from './types.js'

/**
 * Price lookup and cost computation.
 *
 * Prices are currency units per million tokens with three components:
 * cache-hit input (cr), uncached input (in), output (out). Cache-write is
 * billed as uncached input (DeepSeek bills cache-write at the input rate).
 *
 * The builtin catalog ships DeepSeek's published 2026-09 pricing in both
 * CNY and USD, off-peak and peak. Unknown models are not guessed: they
 * meter tokens and price at `fallbackPrice` (default 0) until an override
 * is added to <dataDir>/price-overrides.json.
 */

const DEEPEEK_V4_FLASH: Record<'CNY' | 'USD', Record<'offpeak' | 'peak', ModelPrice>> = {
  CNY: {
    offpeak: { cr: 0.02, in: 1, out: 4 },
    peak: { cr: 0.04, in: 2, out: 8 },
  },
  USD: {
    offpeak: { cr: 0.003, in: 0.15, out: 0.6 },
    peak: { cr: 0.006, in: 0.3, out: 1.2 },
  },
}

/** Legacy DeepSeek chat/reasoner pricing, kept for older logs. */
const DEEPSEEK_LEGACY: Record<'CNY' | 'USD', ModelPrice> = {
  CNY: { cr: 0.2, in: 2, out: 8 },
  USD: { cr: 0.027, in: 0.27, out: 1.1 },
}

export class Pricing {
  private readonly overrides = new Map<string, ModelPrice>()

  constructor(
    private readonly currency: string,
    private readonly peak: boolean,
    private readonly fallback: ModelPrice = { cr: 0, in: 0, out: 0 },
  ) {}

  /** Load user overrides (model name → price). Later calls win. */
  setOverrides(entries: Record<string, ModelPrice>): void {
    this.overrides.clear()
    for (const [model, price] of Object.entries(entries)) {
      if (price && typeof price.in === 'number' && typeof price.out === 'number') {
        this.overrides.set(model, price)
      }
    }
  }

  priceFor(model: string): { price: ModelPrice; source: 'override' | 'builtin' | 'fallback' } {
    const override = this.overrides.get(model)
    if (override) return { price: override, source: 'override' }
    const cur = this.currency.toUpperCase() === 'USD' ? 'USD' : 'CNY'
    const m = model.toLowerCase()
    // DeepSeek route ids commonly look like deepseek-chat / deepseek-reasoner
    // / deepseek-v4.x-flash; flash-family and legacy ids resolve separately.
    if (m.startsWith('deepseek')) {
      if (m.includes('flash') || m.includes('v4')) {
        const tier = DEEPEEK_V4_FLASH[cur]
        return { price: this.peak ? tier.peak : tier.offpeak, source: 'builtin' }
      }
      return { price: DEEPSEEK_LEGACY[cur], source: 'builtin' }
    }
    return { price: this.fallback, source: 'fallback' }
  }

  /** Cost in currency major units for one call. */
  cost(
    model: string,
    usage: { inputTokens: number; outputTokens: number; cacheReadTokens?: number; cacheWriteTokens?: number },
  ): number {
    const { price } = this.priceFor(model)
    const cr = usage.cacheReadTokens ?? 0
    const cw = usage.cacheWriteTokens ?? 0
    const m = 1e6
    return (
      (cr * price.cr) / m +
      ((usage.inputTokens + cw) * price.in) / m +
      (usage.outputTokens * price.out) / m
    )
  }
}
