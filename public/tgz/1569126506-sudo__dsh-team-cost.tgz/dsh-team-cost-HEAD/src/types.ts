/** Core data shapes shared by the metering, quota, and report modules. */

/** Per-model price, in currency units per million tokens. */
export interface ModelPrice {
  /** Cache-hit (cached read) input price per Mtok. */
  cr: number
  /** Uncached input price per Mtok. */
  in: number
  /** Output price per Mtok. */
  out: number
}

/** One metered model call. Appended as one JSONL line. */
export interface UsageRecord {
  /** ISO-8601 UTC time of the call. */
  t: string
  /** Session event sequence number of the assistant message. */
  seq: number
  /** Session id. */
  sid: string
  /** Session working directory (workspace), when resolvable. */
  ws: string
  /** Resolved member name (attribution result, never empty). */
  user: string
  /** Provider route that produced the message. */
  provider: string
  /** Model id within the provider route. */
  model: string
  /** Uncached input tokens. */
  in: number
  /** Output tokens. */
  out: number
  /** Cache-read tokens, when reported. */
  cr?: number
  /** Cache-write tokens, when reported. */
  cw?: number
  /** Reasoning tokens (informational, included in out). */
  rz?: number
  /** Computed cost in the configured currency's major units. */
  cost: number
  /** Whether the model call was interrupted mid-stream. */
  interrupted?: true
}

/** Aggregated counters for one (day, user, model) cell. */
export interface RollupCell {
  day: string
  user: string
  model: string
  calls: number
  in: number
  out: number
  cr: number
  cw: number
  cost: number
}

/** Member budget configuration, loaded from <dataDir>/members.json. */
export interface MemberBudget {
  /** Member display name; matches the `user` field of attribution. */
  name: string
  /** Daily cost budget in currency major units (0 = unlimited). */
  dailyCost?: number
  /** Monthly cost budget in currency major units (0 = unlimited). */
  monthlyCost?: number
  /** Daily total-token budget (0 = unlimited). */
  dailyTokens?: number
  /** Monthly total-token budget (0 = unlimited). */
  monthlyTokens?: number
}

/** Persisted members file shape. */
export interface MembersFile {
  members: MemberBudget[]
}

/** Quota evaluation result for one member. */
export interface QuotaStatus {
  user: string
  /** Highest crossed threshold fraction (of any budget), 0 when none. */
  level: number
  /** The budget lines currently over their 100% limit. */
  exceeded: string[]
  /** True when the member is over at least one 100% limit. */
  over: boolean
}

/** One member row of the dashboard snapshot. */
export interface MemberRow {
  name: string
  todayCost: number
  todayTokens: number
  monthCost: number
  monthTokens: number
  dailyCost?: number
  monthlyCost?: number
  dailyTokens?: number
  monthlyTokens?: number
  level: number
  over: boolean
}

/** One grouped usage row (by model) of the dashboard snapshot. */
export interface GroupRow {
  key: string
  calls: number
  inTok: number
  outTok: number
  cacheRead: number
  cacheWrite: number
  cost: number
}

/** `remote.teamCost.getState()` result served to the web dashboard. */
export interface TeamCostState {
  currency: string
  enforce: string
  generatedAt: number
  dayKey: string
  monthKey: string
  members: MemberRow[]
  todayByModel: GroupRow[]
  monthByModel: GroupRow[]
}
