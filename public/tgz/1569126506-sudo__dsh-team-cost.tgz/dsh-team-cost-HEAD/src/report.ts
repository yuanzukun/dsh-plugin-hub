import { defineTool } from '@deepseek-ai/dsh-tools'
import type { UsageStore } from './store.js'

export interface ReportDeps {
  store: UsageStore
  currency: string
}

const RANGES = new Set(['today', 'month', 'all'])
const GROUPS = new Set(['member', 'model', 'day'])

function fmt(n: number): string {
  return n % 1 === 0 ? String(n) : n.toFixed(0)
}

export function createReportTool(deps: ReportDeps) {
  return defineTool({
    name: 'team_cost_report',
    description:
      '查询团队 AI 用量与成本报表（按成员/模型/天分组，支持 today/month/all 范围，可导出 CSV）。' +
      'Query team AI usage and cost: group by member, model, or day; optionally export CSV.',
    parameters: {
      range: { type: 'string', description: '统计范围: today | month | all (默认 today)' },
      groupBy: { type: 'string', description: '分组维度: member | model | day (默认 member)' },
      csv: { type: 'string', description: '传 "true" 时同时导出 CSV 文件并返回路径' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args: { range?: string; groupBy?: string; csv?: string }) {
      const range = RANGES.has(args.range ?? '') ? (args.range as 'today' | 'month' | 'all') : 'today'
      const groupBy = GROUPS.has(args.groupBy ?? '') ? (args.groupBy as 'member' | 'model' | 'day') : 'member'
      const rows = deps.store.aggregate(range, groupBy)
      const label = groupBy === 'member' ? '成员' : groupBy === 'model' ? '模型' : '日期'
      const lines: string[] = [
        `团队用量报表 (${range === 'today' ? '今天' : range === 'month' ? '本月' : '全部'}, 单位: ${deps.currency})`,
        '',
        `${label} | 调用次数 | 输入 tokens | 输出 tokens | 缓存命中 | 费用`,
        '--- | --- | --- | --- | --- | ---',
      ]
      let totalCost = 0
      for (const row of rows) {
        totalCost += row.cost
        lines.push(
          `${groupBy === 'day' ? row.day : groupBy === 'member' ? row.user : row.model} | ${row.calls} | ${fmt(row.in + row.cw)} | ${fmt(row.out)} | ${fmt(row.cr)} | ${row.cost.toFixed(4)}`,
        )
      }
      lines.push('', `合计费用: ${totalCost.toFixed(4)} ${deps.currency}`)

      if (args.csv === 'true') {
        const file = await deps.store.exportCsv(range)
        lines.push('', `CSV 已导出: ${file}`)
      }
      return lines.join('\n')
    },
  })
}
