/**
 * dsh-team-cost 浏览器端 bundle(单文件 __ModuleLoader__ 工厂闭包)。
 *
 * 提供「团队成本」设置分节:
 *  - 概览卡片:今日费用、本月费用、超支成员数;
 *  - 成员表:每人今日/本月费用与预算进度条;
 *  - 模型表:本月按模型的调用次数与费用。
 *
 * 数据通道:remote.teamCost.getState()(Typert RPC)→ 30s 轮询快照。
 * 样式使用 --dsw-* / --dsh-* 主题变量,跟随全局亮/暗主题。
 * 结构参照 dsh-cost-meter 的 src/client 实现模式。
 */

window.__ModuleLoader__.load({
  id: 'dsh-team-cost',
  factory: (require) => {
    var module = { exports: {} }
    var exports = module.exports
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })

    const React = require('react')
    const { useState, useEffect } = React
    const e = React.createElement

    const css = [
      '/* dsh-team-cost: 团队成本看板 */',
      '.tc-wrap{display:flex;flex-direction:column;gap:14px;font-size:13px;color:var(--dsw-alias-label-primary)}',
      '.tc-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}',
      '.tc-card{padding:12px;border-radius:10px;background:var(--dsw-alias-bg-layer-2)}',
      '.tc-card-label{font-size:12px;color:var(--dsw-alias-label-tertiary)}',
      '.tc-card-value{margin-top:4px;font-size:20px;font-weight:700;font-variant-numeric:tabular-nums}',
      '.tc-over{color:#e5484d}',
      '.tc-warn{color:#f5a623}',
      'table.tc-table{width:100%;border-collapse:collapse;font-variant-numeric:tabular-nums}',
      '.tc-table th{font-size:12px;font-weight:500;text-align:left;color:var(--dsw-alias-label-tertiary);padding:6px 8px;border-bottom:1px solid var(--dsw-alias-separator)}',
      '.tc-table td{padding:7px 8px;border-bottom:1px solid var(--dsw-alias-separator)}',
      '.tc-table tr:last-child td{border-bottom:none}',
      '.tc-bar{position:relative;height:6px;min-width:90px;border-radius:3px;background:var(--dsw-alias-interactive-bg-hover);overflow:hidden}',
      '.tc-bar-fill{height:100%;border-radius:3px;background:var(--dsw-alias-brand-primary)}',
      '.tc-bar-fill.tc-hot{background:#e5484d}',
      '.tc-note{font-size:12px;color:var(--dsw-alias-label-tertiary)}',
      '.tc-section-title{font-size:13px;font-weight:600;margin:4px 0 0}',
    ].join('\n')

    function useTeamCostState(api) {
      const [state, setState] = useState(null)
      const [error, setError] = useState(null)
      useEffect(() => {
        let alive = true
        const reload = async () => {
          try {
            const result = await api.getState()
            if (!alive) return
            if (result === null || typeof result !== 'object' || result.ok !== true) {
              throw new Error(result?.error?.message ?? 'rpc failed')
            }
            setState(result.value)
            setError(null)
          } catch (err) {
            if (alive) setError(err?.message ?? String(err))
          }
        }
        void reload()
        const timer = setInterval(() => { if (!document.hidden) void reload() }, 30_000)
        const onVisible = () => { if (document.visibilityState === 'visible') void reload() }
        document.addEventListener('visibilitychange', onVisible)
        return () => { alive = false; clearInterval(timer); document.removeEventListener('visibilitychange', onVisible) }
      }, [api])
      return { state, error }
    }

    const fmtCost = (n, currency) => `${(n ?? 0).toFixed(4)} ${currency}`
    const fmtTok = (n) => {
      const v = n ?? 0
      if (v >= 1e9) return (v / 1e9).toFixed(2) + 'B'
      if (v >= 1e6) return (v / 1e6).toFixed(2) + 'M'
      if (v >= 1e3) return (v / 1e3).toFixed(1) + 'K'
      return String(v)
    }

    function BudgetBar(props) {
      const { used, limit } = props
      if (!limit || limit <= 0) return e('span', { className: 'tc-note' }, '—')
      const frac = Math.max(0, Math.min(1.5, used / limit))
      const pct = Math.min(100, Math.round(frac * 100))
      return e('div', { className: 'tc-bar', title: `${pct}%` },
        e('div', { className: 'tc-bar-fill' + (frac >= 1 ? ' tc-hot' : ''), style: { width: pct + '%' } }))
    }

    function MemberTable(props) {
      const { members, currency } = props
      return e('table', { className: 'tc-table' },
        e('thead', null, e('tr', null,
          e('th', null, '成员'), e('th', null, '今日费用'), e('th', null, '日预算'),
          e('th', null, '本月费用'), e('th', null, '月预算'), e('th', null, '本月 tokens'))),
        e('tbody', null, members.map((m) => e('tr', { key: m.name },
          e('td', null, m.name),
          e('td', { className: m.over ? 'tc-over' : undefined }, fmtCost(m.todayCost, currency)),
          e('td', null, e(BudgetBar, { used: m.todayCost, limit: m.dailyCost })),
          e('td', { className: m.over ? 'tc-over' : undefined }, fmtCost(m.monthCost, currency)),
          e('td', null, e(BudgetBar, { used: m.monthCost, limit: m.monthlyCost })),
          e('td', null, fmtTok(m.monthTokens))))))
    }

    function ModelTable(props) {
      const { rows, currency } = props
      if (!rows || rows.length === 0) return e('p', { className: 'tc-note' }, '本周期暂无调用记录')
      return e('table', { className: 'tc-table' },
        e('thead', null, e('tr', null,
          e('th', null, '模型'), e('th', null, '调用'), e('th', null, '输入 tok'),
          e('th', null, '输出 tok'), e('th', null, '缓存命中'), e('th', null, '费用'))),
        e('tbody', null, rows.map((r) => e('tr', { key: r.key },
          e('td', null, r.key), e('td', null, String(r.calls)),
          e('td', null, fmtTok(r.inTok)), e('td', null, fmtTok(r.outTok)),
          e('td', null, fmtTok(r.cacheRead)), e('td', null, fmtCost(r.cost, currency))))))
    }

    function TeamCostSection(props) {
      const { teamCost } = props
      const { state, error } = useTeamCostState(teamCost)
      if (error) return e('p', { className: 'tc-note' }, '读取团队成本失败: ' + error)
      if (!state) return e('p', { className: 'tc-note' }, '加载中…')
      const overCount = state.members.filter((m) => m.over).length
      const todayTotal = state.members.reduce((s, m) => s + m.todayCost, 0)
      const monthTotal = state.members.reduce((s, m) => s + m.monthCost, 0)
      return e('div', { className: 'tc-wrap' },
        e('style', null, css),
        e('div', { className: 'tc-cards' },
          e('div', { className: 'tc-card' },
            e('div', { className: 'tc-card-label' }, '今日团队费用 (' + state.dayKey + ')'),
            e('div', { className: 'tc-card-value' }, fmtCost(todayTotal, state.currency))),
          e('div', { className: 'tc-card' },
            e('div', { className: 'tc-card-label' }, '本月团队费用 (' + state.monthKey + ')'),
            e('div', { className: 'tc-card-value' }, fmtCost(monthTotal, state.currency))),
          e('div', { className: 'tc-card' },
            e('div', { className: 'tc-card-label' }, '超支成员'),
            e('div', { className: 'tc-card-value' + (overCount > 0 ? ' tc-over' : '') },
              overCount + ' / ' + state.members.length))),
        e('p', { className: 'tc-section-title' }, '成员'),
        state.members.length === 0
          ? e('p', { className: 'tc-note' }, '暂无计量数据;在数据目录的 members.json 配置成员预算,attributionRules 配置归因规则。')
          : e(MemberTable, { members: state.members, currency: state.currency }),
        e('p', { className: 'tc-section-title' }, '本月模型用量'),
        e(ModelTable, { rows: state.monthByModel, currency: state.currency }),
        e('p', { className: 'tc-note' },
          '每 30 秒自动刷新' + (state.enforce !== 'off' ? ';超支拦截已开启 (' + state.enforce + ')' : ';当前为只监控模式') + '。'))
    }

    // ── 插件主体 ────────────────────────────────────────────────────────────

    const inject = ['remote']

    // RPC 贡献:与服务端 ./typert 清单一一对应(getState 无参,快照结果)。
    const CONTRIBUTION = {
      package: 'dsh-team-cost',
      descriptors: [
        {
          id: 'dsh-team-cost#teamCost/getState',
          service: 'teamCost',
          namespace: 'teamCost',
          method: 'getState',
          invocation: { kind: 'direct' },
          parameters: [],
          result: { mode: 'src-json' },
        },
      ],
    }

    async function apply(ctx) {
      const remote = ctx.remote
      if (remote === undefined || typeof remote.$mount !== 'function') return
      const unmount = await remote.$mount(CONTRIBUTION)
      ctx.effect(() => () => { unmount() }, 'team-cost: remote contribution')
      const teamCost = ctx.get('remote.teamCost')
      if (teamCost === undefined) return

      const slots = ctx.get('slots')
      if (slots === undefined) return
      const disposeSection = slots.inject('settings.section', () => slots.register(
        { name: 'settings.section', id: 'team-cost', order: 32, label: '团队成本', inject: () => ({ teamCost }) },
        TeamCostSection,
      ))
      ctx.effect(() => () => { if (typeof disposeSection === 'function') disposeSection() }, 'team-cost: settings section')
    }

    exports.apply = apply
    exports.inject = inject
    return module.exports
  },
})
