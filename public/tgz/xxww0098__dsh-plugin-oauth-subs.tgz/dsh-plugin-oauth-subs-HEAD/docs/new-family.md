# 家族对齐 magpie/plugins

家族的登录、对话 wire 和额度读取对齐 [magpie-community/plugins](https://github.com/magpie-community/plugins)，不在本仓重写。上游 `packages/` 里有什么 provider 包，本插件就下载什么、更新什么。手写一家登录 / hop / 额度的旧接入顺序已经作废。

跨家族硬规则仍在 [`docs/rules.md`](rules.md)。引擎怎么下载、校验、加载、跟版，设计源是 [`src/upstream-engine/README.md`](../src/upstream-engine/README.md)。只加模型不加家族走 [`docs/new-model.md`](new-model.md)。

## 对齐什么

只对齐 **provider 包**：npm 名是 `@magpie-community/opencode-<id>-auth`，一家一个包（一个包可以导出两个产品，例如 workbuddy / workbuddy-ai、autoclaw / autoclaw-cn）。

| 上游包 | 本插件 | 状态 |
|---|---|---|
| `opencode-kimi-work-auth` | kimi-work | 引擎即实现 |
| `opencode-workbuddy-auth` | workbuddy / workbuddy-ai | 引擎即实现 |
| `opencode-opendesign-auth` | opendesign | 引擎即实现 |
| `opencode-autoclaw-auth` | autoclaw / autoclaw-cn | 引擎即实现 |
| `opencode-zed-auth` | zed | 引擎即实现 |
| `opencode-cline-auth` | cline | 引擎即实现 |
| `opencode-commandcode-auth` | command-code | 引擎即实现 |
| `opencode-cursor-auth` | cursor | 有包，未切引擎（h2 出口口径未定，见 [`ROLLOUT.md`](../src/upstream-engine/ROLLOUT.md) §7） |
| `opencode-zcode-auth` | glm | 有包，未切引擎（见 ROLLOUT §8） |
| `opencode-mimo-auth` | mimo | 有包；本仓仍是 TS（切过去会绕过代理卡） |
| `opencode-grok-auth` | grok | 有包；本仓仍是 TS（登录/刷新依赖 grok CLI 二进制） |
| `opencode-kiro-auth` | kiro | 有包；本仓仍是 TS（`node:sqlite` 与登录面） |
| `opencode-devin-auth` | devin | 有包；本仓仍是 TS（活测只回 stub config） |

这四家包在，但切过去会降级或坏掉。维持 TS 是对照结果，不是另写一套协议；包本身仍在对照表里，上游修了阻塞再切。

上游没有对应 provider 包的家族维持现有实现，不发明一个引擎：codex、chatgpt、antigravity、ollama、opencode-go、kimi（Kimi Code Plan；上游的 kimi-work 是另一个产品）。

## 不下载什么

上游仓里其余的包不是订阅 provider，不进 `src/upstream-engine/`，也不进家族目录：

- **明确放弃的 provider**：minimax、qoder、raccoon、trae、factory（含各自的 CN / Global 变体）。
- **zen-free**：唯一机制是伪装 OpenCode 指纹绕免费档，已拒绝。
- **agent / middleware / tools / page**：aider、kimi-desktop、type4me、block-patterns、calc、codex-history、model-map、param-override、reserve、system-prompt、think-tags、word-guard、usage。它们服务 magpie 宿主，不是本插件的一条订阅路由。

新出现的包先看它是不是 `@magpie-community/opencode-*-auth`。是，且不在放弃名单里，就按下一节接；不是，就不接。

## 下载与更新

引擎家族的包不进 `src/` 或 `lib/`，也不进构建。运行时由 [`src/upstream-engine/packages.ts`](../src/upstream-engine/packages.ts) 下载：

- 作用域钉死 `@magpie-community/`，tarball host 钉死 `registry.npmjs.org`，sha512 对点名该版本的 registry 元数据校验，流量走 `outboundFetch`。
- 种子版本写在 `ENGINE_SEEDS`（本仓审计过的版本）。首次引导取 integrity 落盘；之后换版必须匹配新版本元数据。
- [`watch.ts`](../src/upstream-engine/watch.ts) 每 15 分钟看 npm dist-tags，`latest` 变了就下载校验并原子换版。磁盘留最近 3 版，回退是把 manifest 的 version 改回去。
- 加载或契约失败：该家带着引擎错误失败，不回退到一套本仓重写的 wire。

豁免的只有引擎家族上游包换版的活测门禁。本仓自己的改动仍要测试。

## 留在本仓

引擎包只替换登录、chat wire 和额度读取。下面这些不交给包：

- 目录闭集。`models.json` 的行、`CATALOG_KEYS`、`scripts/models.ts` 的 `ADAPTERS` 仍按 [`docs/models.md`](models.md) 维护。引擎的 `provider.models` 是 magpie 行形状，不接管这张表。
- 缓存与会话亲和。DSH 字段仍由 `rewriteUpstreamBody` 剥除，家族 `cache.ts` 仍留在该家目录。
- vault 形状、`publicSession`、别名、`displayName`（`Subs · <家族名> · <协议>`）。
- 本插件的路由、设置页家族栏、额度卡片。包怎么登录、怎么说话，适配层只做管道。

## 接一家

同一个 PR 里做完：

1. 在 [`docs/oauth.md`](oauth.md) 总表加一行：包名、审计过的版本、该包实际发出的登录 / hop / 额度。行为反转按 [`ROLLOUT.md`](../src/upstream-engine/ROLLOUT.md) 的口径签核。
2. `ENGINE_SEEDS` 加该家族（一个包两个产品就两行，同一 npm 名和版本）。
3. `<id>/engine.ts` 声明包的入口，注册该家端点 host 闭集（没有 `fetchImpl` 的包走 bridge）。不在适配层重写登录、刷新或请求体。
4. 删掉被这个包替换的 TS 登录 / hop / 额度路径。不要留 flag，不要留第二条实现。
5. 目录、缓存、vault、路由、UI 按上一节留在本仓，接线进 `families.ts`。
6. `test/<id>.test.ts` 钉住该包版本的登录、session、缓存隔离、路由和额度。
7. 该家 README 写清包版本、随包的行为、刻意偏离的点。真实账号活测结论落 [`docs/error.md`](error.md)。

## 对抗审查（PR 自答）

- [ ] 这家对应一个 `@magpie-community/opencode-*-auth` 包，且不在放弃名单里。
- [ ] 登录、hop、额度读取来自该包，不是本仓新写的一套。
- [ ] 包没有进 `src/` 或 `lib/`；名字在 `ENGINE_SEEDS`，作用域与 tarball host 没放宽。
- [ ] 被替换的 TS wire 已删，没有 flag，没有第二条车道。
- [ ] 端点 host 是精确闭集，引擎流量走 `outboundFetch` 或 bridge。
- [ ] `provider.models` 没有写进 `models.json`；目录行仍有自己的出处。
- [ ] `cache.ts` 没有 import 别家的 cache；DSH 会话字段没有原样发上游。
- [ ] `publicSession` 不暴露 token、refresh、opaque account id。
- [ ] `displayName` 仍是 `Subs · <家族名> · <协议>`。
