/**
 * AWS Kiro subscription OAuth — same methods as ZyphrZero/kiro.rs:
 *   social / OAuth  portal PKCE at app.kiro.dev
 *   builder-id      AWS SSO OIDC device code (view.awsapps.com/start)
 *   idc             Enterprise IAM Identity Center (org Start URL)
 *   external_idp    Microsoft Entra / Azure AD refresh_token grant
 *   api_key         ksk_… bearer
 */

import { createHash, randomUUID } from 'node:crypto'
import { outboundFetch } from '../../utils/outbound.js'
import { oauthCodeOf } from '../errors.js'
import { catalogRows } from '../../catalog/index.js'

export const KIRO_PORTAL_URL = 'https://app.kiro.dev'
export const KIRO_AUTH_HOST = 'prod.us-east-1.auth.desktop.kiro.dev'
export const KIRO_AUTH_URL = `https://${KIRO_AUTH_HOST}`
export const BUILDER_ID_START_URL = 'https://view.awsapps.com/start'
export const BUILDER_ID_PROFILE_ARN = 'arn:aws:codewhisperer:us-east-1:638616132270:profile/AAAACCCCXXXX'
export const SOCIAL_PROFILE_ARN = 'arn:aws:codewhisperer:us-east-1:699475941385:profile/EHGA3GRVQMUK'
export const KIRO_CALLBACK_PORTS = Object.freeze([3128, 4649, 6588, 8008, 9091, 49153, 50153, 51153, 52153, 53153])
export const KIRO_CALLBACK_PATH = '/oauth/callback'
/** Origin-only Cognito redirect can land on `/`, the IDE path, or `/signin/callback`. */
export const KIRO_CALLBACK_PATHS = Object.freeze(['/', '/oauth/callback', '/signin/callback'])
export const KIRO_OIDC_SCOPES = Object.freeze([
  'codewhisperer:completions',
  'codewhisperer:analysis',
  'codewhisperer:conversations',
  'codewhisperer:transformations',
  'codewhisperer:taskassist',
])
export const KIRO_USAGE_VERSION = '1.0.0'
export const KIRO_NEVER_EXPIRES = 8.64e15
export const KIRO_DEFAULT_REGION = 'us-east-1'
export const KIRO_CONTEXT_WINDOW = 200_000
export const KIRO_LARGE_CONTEXT = 1_000_000
export const KIRO_GPT_CONTEXT = 1_000_000
export const KIRO_DEEPSEEK_CONTEXT = 164_000
export const KIRO_QWEN_CONTEXT = 256_000
export const KIRO_MAX_TOKENS = 64_000
export const KIRO_VISION_INPUT = Object.freeze(['text', 'image'])
export const KIRO_TEXT_INPUT = Object.freeze(['text'])
export const KIRO_METHODS = Object.freeze(['social', 'idc', 'external_idp', 'api_key'])
export const KIRO_USAGE_REGIONS = Object.freeze(['us-east-1', 'eu-central-1'])

/**
 * kiro.dev/docs/models/effort — Claude `output_config.effort`.
 * Opus 5 / 4.8 / 4.7 and Sonnet 5 add `xhigh`; 4.6 family stops at `max`.
 * Thinking can also be `adaptive`/`disabled`; DSH picker is the effort ladder.
 */
export const KIRO_REASONING_CLAUDE = Object.freeze({
  low: 'low',
  medium: 'medium',
  high: 'high',
  max: 'max',
})

export const KIRO_REASONING_CLAUDE_XHIGH = Object.freeze({
  ...KIRO_REASONING_CLAUDE,
  xhigh: 'xhigh',
})

/** GPT-5.6 `reasoning.effort`. Official wire is `none`; DSH picker key is `off`. */
export const KIRO_REASONING_GPT = Object.freeze({
  off: 'none',
  low: 'low',
  medium: 'medium',
  high: 'high',
  xhigh: 'xhigh',
  max: 'max',
})

const EXTERNAL_IDP_ALIASES = Object.freeze([
  'external_idp', 'azuread', 'azure', 'entra', 'entra-id',
  'microsoft', 'm365', 'office365', 'external',
])
const ALLOWED_IDP_SUFFIXES = Object.freeze([
  '.microsoftonline.com',
  '.microsoftonline.us',
  '.microsoftonline.cn',
])

/**
 * Offline fallback only — a non-empty live ListAvailableModels replaces it.
 * Snapshot of ListAvailableModels origin=KIRO_CONSOLE (2026-09-28, the full
 * governance catalog) minus Auto; `claude-fable-5` is retained for
 * pi-provider-kiro bootstrap compatibility. Rows live in
 * `src/catalog/models.json` under `"kiro"`.
 */
export const KIRO_MODELS = catalogRows('kiro')

export const KIRO_PLAN_NAMES = Object.freeze({
  kiro_free: 'Free',
  kirofree: 'Free',
  free: 'Free',
  kiro_pro: 'Pro',
  kiropro: 'Pro',
  pro: 'Pro',
  'kiro_pro+': 'Pro+',
  kiro_proplus: 'Pro+',
  kiro_pro_plus: 'Pro+',
  kiroproplus: 'Pro+',
  proplus: 'Pro+',
  pro_plus: 'Pro+',
  kiro_powered: 'Powered',
  kiropowered: 'Powered',
  powered: 'Powered',
})

export function canonicalizeKiroMethod(value, { tokenEndpoint }: any = {}) {
  const raw = typeof value === 'string' ? value.trim() : ''
  if (!raw && tokenEndpoint) return 'external_idp'
  const lower = raw.toLowerCase()
  if (lower === 'builder-id' || lower === 'builder_id' || lower === 'builderid' || lower === 'builder' || lower === 'iam') return 'idc'
  if (lower === 'api_key' || lower === 'apikey' || lower === 'ksk') return 'api_key'
  if (EXTERNAL_IDP_ALIASES.some((alias) => alias === lower)) return 'external_idp'
  if (lower === 'oauth' || lower === 'github' || lower === 'google' || lower === 'gmail' || lower === 'gh' || lower === 'social') return 'social'
  if (lower === 'enterprise' || lower === 'idc') return 'idc'
  if (KIRO_METHODS.includes(lower)) return lower
  if (tokenEndpoint) return 'external_idp'
  return raw ? lower : 'social'
}

const SOCIAL_PROVIDERS = Object.freeze(['github', 'google', 'gmail', 'gh', 'social', 'oauth'])
const IDC_PROVIDERS = Object.freeze([
  'builderid', 'builder-id', 'builder_id', 'builder', 'enterprise', 'idc', 'iam',
])

/**
 * Guess authMethod for dumps that omit it (kiro-manager-lite compact JSON /
 * 卡密). Social = GitHub/Google refresh only; IdC = Builder ID / Enterprise
 * with clientId+clientSecret.
 */
export function inferKiroAuthMethod(raw: any = {}) {
  const nested = raw?.credentials && typeof raw.credentials === 'object' && !Array.isArray(raw.credentials)
    ? raw.credentials
    : raw
  const kiroApiKey = trimmed(nested.kiroApiKey ?? nested.kiro_api_key)
  const access = trimmed(nested.accessToken ?? nested.access_token)
  if (kiroApiKey || (access && access.startsWith('ksk_'))) return 'api_key'
  const tokenEndpoint = nested.tokenEndpoint ?? nested.token_endpoint ?? raw.tokenEndpoint ?? raw.token_endpoint
  const declared = nested.authMethod ?? nested.auth_method ?? raw.authMethod ?? raw.auth_method
  if ((typeof declared === 'string' && declared.trim()) || tokenEndpoint) {
    return canonicalizeKiroMethod(declared, { tokenEndpoint })
  }
  const provider = String(nested.provider ?? nested.idp ?? raw.provider ?? raw.idp ?? raw.kiroProvider ?? '')
    .trim()
    .toLowerCase()
  if (SOCIAL_PROVIDERS.includes(provider)) return 'social'
  if (IDC_PROVIDERS.includes(provider)) return 'idc'
  if (EXTERNAL_IDP_ALIASES.includes(provider)) return 'external_idp'
  const clientId = trimmed(nested.clientId ?? nested.client_id)
  const clientSecret = trimmed(nested.clientSecret ?? nested.client_secret)
  if (clientId && clientSecret) return 'idc'
  return 'social'
}

export function kiroAccountKind(session: any = {}) {
  const method = canonicalizeKiroMethod(session.authMethod, { tokenEndpoint: session.tokenEndpoint })
  if (method === 'external_idp') return 'entra'
  if (method === 'api_key') return 'key'
  if (method === 'idc') {
    const start = trimmed(session.startUrl)
    const provider = trimmed(session.kiroProvider)
    if (provider === 'Enterprise' || (start && start !== BUILDER_ID_START_URL)) return 'idc'
    return 'builder'
  }
  return 'social'
}

export function kiroMethodLabel(methodOrSession) {
  if (methodOrSession && typeof methodOrSession === 'object') {
    const kind = kiroAccountKind(methodOrSession)
    if (kind === 'builder') return 'Builder'
    if (kind === 'idc') return 'IdC'
    if (kind === 'entra') return 'Entra'
    if (kind === 'key') return 'API key'
    return 'Social'
  }
  switch (canonicalizeKiroMethod(methodOrSession)) {
    case 'idc': return 'IdC'
    case 'external_idp': return 'Entra'
    case 'api_key': return 'API key'
    default: return 'Social'
  }
}

export function kiroAccountId(session: any = {}) {
  const kind = kiroAccountKind(session)
  const account = trimmed(session.account) || trimmed(session.email)
  if (account && account.includes('@')) return `${account}@${kind}`
  const seed = session.kiroApiKey || session.refreshToken || session.accessToken || session.clientId || ''
  const tail = String(seed).replace(/[^A-Za-z0-9]/g, '').slice(-10) || kind
  return `${tail}@${kind}`
}

export function oidcEndpoint(region = KIRO_DEFAULT_REGION) {
  return `https://oidc.${region || KIRO_DEFAULT_REGION}.amazonaws.com`
}

export function kiroUsageHost(region = KIRO_DEFAULT_REGION) {
  return `q.${region || KIRO_DEFAULT_REGION}.amazonaws.com`
}

/** Management plane for ListAvailableProfiles / ListAvailableModels. Chat stays on q.<region>.amazonaws.com. */
export function kiroManagementHost(region = KIRO_DEFAULT_REGION) {
  return `management.${region || KIRO_DEFAULT_REGION}.kiro.dev`
}

export const KIRO_LIST_PROFILES_PATH = 'List-Available-Profiles'
export const KIRO_LIST_MODELS_PATH = 'List-Available-Models'

export function kiroUsageRegions(session: any = {}) {
  const region = String(session.authRegion || session.apiRegion || session.region || KIRO_DEFAULT_REGION)
  if (region === 'eu-central-1' || region.startsWith('eu-')) return ['eu-central-1', 'us-east-1']
  return ['us-east-1', 'eu-central-1']
}

export function kiroUsageUrl(region, profileArn) {
  const host = kiroUsageHost(region)
  const base = `https://${host}/getUsageLimits?origin=AI_EDITOR&resourceType=AGENTIC_REQUEST&isEmailRequired=true`
  const arn = typeof profileArn === 'string' && profileArn.trim() ? profileArn.trim() : ''
  return arn ? `${base}&profileArn=${encodeURIComponent(arn)}` : base
}

export function validateKiroIdpEndpoint(raw) {
  let url
  try {
    url = new URL(String(raw ?? '').trim())
  } catch {
    throw new Error('kiro enterprise SSO token endpoint is not a URL')
  }
  if (url.protocol !== 'https:') throw new Error('kiro enterprise SSO token endpoint must be https')
  const host = url.hostname.toLowerCase()
  if (!host || /^\d/.test(host) || host.includes(':')) {
    throw new Error('kiro enterprise SSO token endpoint host is not allowed')
  }
  if (!ALLOWED_IDP_SUFFIXES.some((suffix) => host.endsWith(suffix) && host.length > suffix.length)) {
    throw new Error('kiro enterprise SSO token endpoint must be a microsoftonline host')
  }
  return url.toString()
}

export function validateKiroRefreshToken(value) {
  const token = trimmed(value)
  if (!token) throw new Error('kiro refresh token is empty')
  if (token.length < 100 || token.includes('...')) {
    throw new Error(`kiro refresh token looks truncated (${token.length} chars)`)
  }
  return token
}

export function validateKiroApiKey(value) {
  const key = trimmed(value)
  if (!key) throw new Error('kiro API key is empty')
  if (!key.startsWith('ksk_') || key.length < 12) throw new Error('kiro API key must start with ksk_')
  return key
}

export function kiroMachineId(session: any = {}) {
  const stored = trimmed(session.machineId)
  if (stored && /^[0-9a-f]{64}$/i.test(stored)) return stored.toLowerCase()
  const method = canonicalizeKiroMethod(session.authMethod, { tokenEndpoint: session.tokenEndpoint })
  const seed = method === 'api_key'
    ? (session.kiroApiKey || session.accessToken)
    : session.refreshToken
  const prefix = method === 'api_key' ? 'KiroAPIKey/' : 'KotlinNativeAPI/'
  return createHash('sha256').update(prefix + String(seed || randomUUID())).digest('hex')
}

/** Stable 64-hex for Social UA. Pass a prior id (or session) so login/token share one machine. */
export function allocateKiroMachineId(prior) {
  if (typeof prior === 'string') return kiroMachineId({ machineId: prior })
  if (prior && typeof prior === 'object') return kiroMachineId(prior)
  return kiroMachineId()
}

function usageUserAgent(session) {
  const machine = kiroMachineId(session)
  const os = process.platform === 'darwin' ? 'macos' : process.platform
  return `aws-sdk-js/1.0.0 ua/2.1 os/${os} lang/js md/nodejs#${process.version} api/codewhispererruntime#1.0.0 m/N,E KiroIDE-${KIRO_USAGE_VERSION}-${machine}`
}

export function kiroTokenTypeHeader(session) {
  const method = canonicalizeKiroMethod(session?.authMethod, { tokenEndpoint: session?.tokenEndpoint })
  if (method === 'api_key') return 'API_KEY'
  if (method === 'external_idp') return 'EXTERNAL_IDP'
  return undefined
}

export function kiroProfileArn(session) {
  const method = canonicalizeKiroMethod(session?.authMethod, { tokenEndpoint: session?.tokenEndpoint })
  if (method === 'api_key') return undefined
  if (typeof session?.profileArn === 'string' && session.profileArn.trim()) return session.profileArn.trim()
  return method === 'social' ? SOCIAL_PROFILE_ARN : BUILDER_ID_PROFILE_ARN
}

export function kiroUsageHeaders(session) {
  const machine = kiroMachineId(session)
  const tokenType = kiroTokenTypeHeader(session)
  return {
    authorization: `Bearer ${session.accessToken}`,
    accept: 'application/json',
    'user-agent': usageUserAgent(session),
    'x-amz-user-agent': `aws-sdk-js/1.0.0 KiroIDE-${KIRO_USAGE_VERSION}-${machine}`,
    'amz-sdk-invocation-id': randomUUID(),
    'amz-sdk-request': 'attempt=1; max=1',
    ...(tokenType ? { tokentype: tokenType } : {}),
  }
}

/** Portal authorize `redirect_uri` is origin only (`http://localhost:<port>`). */
export function kiroSocialRedirectUri(redirectUri) {
  const url = new URL(String(redirectUri ?? ''))
  const hostname = url.hostname === '127.0.0.1' || url.hostname === '[::1]' ? 'localhost' : url.hostname
  return `${url.protocol}//${hostname}${url.port ? `:${url.port}` : ''}`
}

export function kiroSocialLoginOption(value) {
  const raw = typeof value === 'string' ? value.trim().toLowerCase() : ''
  return raw || undefined
}

/**
 * The social portal answers "Your organization" with a redirect that carries
 * no authorization `code`: `login_option=awsidc` + `issuer_url` + `idc_region`
 * tell the client to redo the login as IAM Identity Center (device flow) —
 * picking it apart is what fixes the bare `missing authorization code` the
 * loopback used to answer (issue #167). Returns undefined for every other
 * callback shape (including a normal social `code`).
 */
export function kiroIdcRedirectOf(url) {
  if (!(url instanceof URL)) return undefined
  if (url.searchParams.get('code')) return undefined
  const option = (url.searchParams.get('login_option') ?? url.searchParams.get('loginOption') ?? '').trim().toLowerCase()
  if (option !== 'awsidc') return undefined
  const issuerUrl = (url.searchParams.get('issuer_url') ?? url.searchParams.get('issuerUrl') ?? '').trim()
  if (!/^https:\/\/[^\s/]+(\/\S*)?$/i.test(issuerUrl)) return undefined
  const region = (url.searchParams.get('idc_region') ?? url.searchParams.get('idcRegion') ?? '').trim().toLowerCase()
  return {
    issuerUrl,
    region: /^[a-z]{2}(-[a-z]+)+-\d$/.test(region) ? region : KIRO_DEFAULT_REGION,
  }
}

/**
 * Loopback answer for the IdC pivot: send the browser straight to the device
 * confirmation page (the URL pre-fills the user code), so the user keeps
 * confirming in the tab they came from.
 */
export function kiroIdcPendingPage(verificationUrl) {
  const safe = String(verificationUrl ?? '').replace(/["<>&]/g, (ch) => (
    ch === '"' ? '%22' : ch === '<' ? '%3C' : ch === '>' ? '%3E' : '&amp;'
  ))
  return '<!doctype html><html><head><meta charset="utf-8">'
    + '<meta http-equiv="refresh" content="0;url=' + safe + '">'
    + '<title>Organization login</title></head>'
    + '<body style="font-family:sans-serif;background:#0a0a0b;color:#f4f4f5;padding:48px">'
    + '<h1>Organization login</h1>'
    + '<p>Continuing with your organization\'s device confirmation…</p>'
    + `<p><a href="${safe}" style="color:#7dd3fc">Continue to the device confirmation page</a></p>`
    + '</body></html>'
}

/**
 * Token-exchange `redirect_uri` is the URL the browser actually hit:
 * origin + path (`/` / `/oauth/callback` / `/signin/callback`) and
 * `?login_option=google|github` when the callback carried that query.
 */
export function kiroSocialTokenRedirectUri(redirectUri, callback: any = {}) {
  const origin = kiroSocialRedirectUri(redirectUri)
  const rawPath = typeof callback.pathname === 'string' && callback.pathname
    ? callback.pathname
    : (() => {
      try {
        return new URL(String(redirectUri ?? '')).pathname || '/'
      } catch {
        return '/'
      }
    })()
  const path = rawPath.startsWith('/') ? rawPath : `/${rawPath}`
  const loginOption = kiroSocialLoginOption(callback.loginOption ?? callback.login_option)
  return loginOption ? `${origin}${path}?login_option=${loginOption}` : `${origin}${path}`
}

function kiroSocialClientAgent(session: any = {}) {
  return `KiroIDE-${KIRO_USAGE_VERSION}-${kiroMachineId(session)}`
}

/**
 * Social portal flow. `startIdc` pivots to the IdC device flow when the
 * callback turns out to be the portal's `login_option=awsidc` redirect: it
 * receives kiroIdcRedirectOf's `{ issuerUrl, region }` and returns the
 * KiroIdcFlowManager attempt, whose verification page the loopback then
 * forwards the browser to.
 */
export function kiroSocialFlow({ startIdc }: any = {}) {
  return {
    // KiroIDE registers `http://localhost:<port>` (hostname, no path).
    // listenHosts binds 127.0.0.1 + ::1 so the browser redirect is accepted.
    listen: { host: 'localhost', ports: [...KIRO_CALLBACK_PORTS] },
    callbackPath: KIRO_CALLBACK_PATH,
    callbackPaths: [...KIRO_CALLBACK_PATHS],
    buildAuthorizeUrl(input) {
      const params = new URLSearchParams({
        state: input.state,
        code_challenge: input.pkce.challenge,
        code_challenge_method: 'S256',
        redirect_uri: kiroSocialRedirectUri(input.redirectUri),
        redirect_from: 'KiroIDE',
      })
      return `${KIRO_PORTAL_URL}/signin?${params}`
    },
    async collect(url) {
      const code = url.searchParams.get('code')
      if (code) return code
      const idc = kiroIdcRedirectOf(url)
      if (!idc) return undefined
      if (typeof startIdc !== 'function') {
        throw new Error('organization login needs the Builder ID / Enterprise button here')
      }
      return { kiroIdcAttempt: await startIdc(idc) }
    },
    callbackPage(result) {
      const attempt = result && typeof result === 'object' ? result.kiroIdcAttempt : undefined
      if (!attempt) return undefined
      return kiroIdcPendingPage(attempt.verificationUrl ?? attempt.verificationUri)
    },
  }
}

function trimmed(value) {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined
}

function asPositiveNumber(value) {
  if (typeof value === 'number' && Number.isFinite(value) && value > 0) return value
  if (typeof value === 'string' && value.trim()) {
    const n = Number(value)
    if (Number.isFinite(n) && n > 0) return n
  }
  return undefined
}

function durationMsOf(value) {
  const n = asPositiveNumber(value)
  if (n === undefined) return undefined
  return n > 1e6 ? n : n * 1000
}

function expiresAtOf(value, fallbackSec = 3600) {
  if (typeof value === 'number' && Number.isFinite(value) && value > 1e12) return value
  if (typeof value === 'number' && Number.isFinite(value) && value > 0) {
    return Date.now() + (value > 1e6 ? value : value * 1000)
  }
  if (typeof value === 'string' && value.trim()) {
    const stamp = Date.parse(value)
    if (Number.isFinite(stamp)) return stamp
  }
  return Date.now() + fallbackSec * 1000
}

/** Fresh TTL from the refresh JSON only. Never reuse a stored session expiresAt. */
function refreshExpiresAt(body: any = {}) {
  const ttl = durationMsOf(body.expiresIn ?? body.expires_in)
  if (ttl !== undefined) return Date.now() + ttl
  const stamp = body.expiresAt ?? body.expires_at
  if (stamp !== undefined && stamp !== null && stamp !== '') return expiresAtOf(stamp)
  return Date.now() + 3600 * 1000
}

export class KiroHttpError extends Error {
  declare status: any
  declare retryAfter: string | undefined
  declare oauthCode: string | undefined

  constructor(message, status, { retryAfter, oauthCode }: any = {}) {
    super(message)
    this.name = 'KiroHttpError'
    this.status = status
    if (oauthCode) this.oauthCode = oauthCode
    if (retryAfter != null && String(retryAfter).trim()) this.retryAfter = String(retryAfter).trim()
  }
}

export function headerOf(response, name) {
  const headers = response?.headers
  if (!headers) return undefined
  if (typeof headers.get === 'function') return headers.get(name) ?? undefined
  return headers[name] ?? headers[name.toLowerCase()]
}

export function kiroSession(fields: any = {}) {
  const method = canonicalizeKiroMethod(fields.authMethod, { tokenEndpoint: fields.tokenEndpoint })
  const kiroApiKey = method === 'api_key' ? (trimmed(fields.kiroApiKey) || trimmed(fields.accessToken)) : undefined
  const accessToken = trimmed(fields.accessToken) || kiroApiKey
  const refreshToken = trimmed(fields.refreshToken) || accessToken
  if (method === 'api_key') {
    if (!accessToken) throw new Error('kiro session needs an API key')
  } else if (!refreshToken) {
    throw new Error('kiro session needs an access token or refresh token')
  }
  const region = trimmed(fields.region) || trimmed(fields.authRegion) || KIRO_DEFAULT_REGION
  const account = trimmed(fields.account) || trimmed(fields.email)
  const draft: any = {
    accessToken: accessToken || refreshToken,
    refreshToken,
    expiresAt: method === 'api_key' ? KIRO_NEVER_EXPIRES : expiresAtOf(fields.expiresAt, fields.expiresIn),
    account,
    authMethod: method,
    kiroProvider: trimmed(fields.kiroProvider) || trimmed(fields.provider),
    planType: trimmed(fields.planType) || trimmed(fields.subscriptionTitle),
    profileArn: trimmed(fields.profileArn),
    clientId: trimmed(fields.clientId),
    clientSecret: trimmed(fields.clientSecret),
    startUrl: trimmed(fields.startUrl),
    tokenEndpoint: trimmed(fields.tokenEndpoint),
    issuerUrl: trimmed(fields.issuerUrl),
    scopes: trimmed(fields.scopes),
    region,
    authRegion: trimmed(fields.authRegion) || region,
    apiRegion: trimmed(fields.apiRegion) || region,
    kiroApiKey: method === 'api_key' ? accessToken : undefined,
  }
  if (!draft.account) draft.account = method === 'api_key' ? 'api-key' : kiroMethodLabel(draft)
  draft.machineId = trimmed(fields.machineId) || kiroMachineId(draft)
  return draft
}

async function readJson(response, label) {
  const text = await response.text()
  if (!response.ok) {
    throw new KiroHttpError(
      `${label} failed (HTTP ${response.status})${text ? `: ${text.slice(0, 240)}` : ''}`,
      response.status,
      { retryAfter: headerOf(response, 'retry-after'), oauthCode: oauthCodeOf(text) },
    )
  }
  return text ? JSON.parse(text) : {}
}

export async function exchangeKiroSocialCode(code, verifier, redirectUri, { fetchFn = outboundFetch, callback, machineId: priorMachineId }: any = {}) {
  const machineId = allocateKiroMachineId(priorMachineId)
  const response = await fetchFn(`${KIRO_AUTH_URL}/oauth/token`, {
    method: 'POST',
    headers: {
      accept: 'application/json, text/plain, */*',
      'content-type': 'application/json',
      'user-agent': kiroSocialClientAgent({ machineId }),
    },
    body: JSON.stringify({
      code,
      code_verifier: verifier,
      redirect_uri: kiroSocialTokenRedirectUri(redirectUri, callback),
    }),
  })
  const body = await readJson(response, 'kiro social token')
  const accessToken = trimmed(body.accessToken ?? body.access_token)
  if (!accessToken) throw new Error('kiro social token exchange returned no access_token')
  return kiroSession({
    accessToken,
    refreshToken: body.refreshToken ?? body.refresh_token,
    expiresAt: body.expiresAt ?? body.expires_at,
    expiresIn: body.expiresIn ?? body.expires_in,
    profileArn: body.profileArn ?? body.profile_arn ?? SOCIAL_PROFILE_ARN,
    authMethod: 'social',
    kiroProvider: 'Social',
    machineId,
  })
}

export async function refreshKiroSocial(session, { fetchFn = outboundFetch } = {}) {
  const refreshToken = validateKiroRefreshToken(session.refreshToken)
  const region = session.authRegion || session.region || KIRO_DEFAULT_REGION
  const host = `prod.${region}.auth.desktop.kiro.dev`
  const response = await fetchFn(`https://${host}/refreshToken`, {
    method: 'POST',
    headers: {
      accept: 'application/json, text/plain, */*',
      'content-type': 'application/json',
      'user-agent': kiroSocialClientAgent(session),
    },
    body: JSON.stringify({ refreshToken }),
  })
  const body = await readJson(response, 'kiro social refresh')
  return kiroSession({
    ...session,
    accessToken: body.accessToken ?? body.access_token,
    refreshToken: body.refreshToken ?? body.refresh_token ?? refreshToken,
    expiresAt: refreshExpiresAt(body),
    profileArn: body.profileArn ?? body.profile_arn ?? session.profileArn,
    authMethod: 'social',
  })
}

export async function refreshKiroIdc(session, { fetchFn = outboundFetch } = {}) {
  const refreshToken = validateKiroRefreshToken(session.refreshToken)
  const region = session.authRegion || session.region || KIRO_DEFAULT_REGION
  const response = await fetchFn(`${oidcEndpoint(region)}/token`, {
    method: 'POST',
    headers: {
      accept: 'application/json',
      'content-type': 'application/json',
      'user-agent': 'aws-sdk-js/3.980.0 KiroIDE',
      'x-amz-user-agent': 'aws-sdk-js/3.980.0 KiroIDE',
    },
    body: JSON.stringify({
      clientId: session.clientId,
      clientSecret: session.clientSecret,
      refreshToken,
      grantType: 'refresh_token',
    }),
  })
  const body = await readJson(response, 'kiro idc refresh')
  return kiroSession({
    ...session,
    accessToken: body.accessToken ?? body.access_token,
    refreshToken: body.refreshToken ?? body.refresh_token ?? refreshToken,
    expiresAt: refreshExpiresAt(body),
    profileArn: body.profileArn ?? body.profile_arn ?? session.profileArn,
    authMethod: 'idc',
  })
}

export async function refreshKiroExternalIdp(session, { fetchFn = outboundFetch } = {}) {
  const tokenEndpoint = validateKiroIdpEndpoint(session.tokenEndpoint)
  const refreshToken = validateKiroRefreshToken(session.refreshToken)
  if (!trimmed(session.clientId)) throw new Error('kiro enterprise SSO needs a client id')
  const form = new URLSearchParams({
    client_id: session.clientId,
    grant_type: 'refresh_token',
    refresh_token: refreshToken,
  })
  if (session.scopes) form.set('scope', session.scopes)
  const response = await fetchFn(tokenEndpoint, {
    method: 'POST',
    headers: {
      accept: 'application/json',
      'content-type': 'application/x-www-form-urlencoded',
    },
    body: form.toString(),
  })
  const body = await readJson(response, 'kiro enterprise SSO refresh')
  const accessToken = trimmed(body.access_token ?? body.accessToken)
  if (!accessToken) throw new Error('kiro enterprise SSO refresh returned no access_token')
  return kiroSession({
    ...session,
    accessToken,
    refreshToken: body.refresh_token ?? body.refreshToken ?? refreshToken,
    expiresAt: refreshExpiresAt(body),
    authMethod: 'external_idp',
  })
}

export async function refreshKiro(session, { fetchFn = outboundFetch } = {}) {
  const method = canonicalizeKiroMethod(session?.authMethod, { tokenEndpoint: session?.tokenEndpoint })
  if (method === 'api_key') return session
  if (method === 'external_idp') return refreshKiroExternalIdp(session, { fetchFn })
  if (method === 'idc') return refreshKiroIdc(session, { fetchFn })
  return refreshKiroSocial(session, { fetchFn })
}

export function isKiroCredential(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return false
  const nested = raw.credentials && typeof raw.credentials === 'object' && !Array.isArray(raw.credentials)
    ? raw.credentials
    : raw
  if (trimmed(nested.kiroApiKey ?? nested.kiro_api_key ?? raw.kiroApiKey ?? raw.kiro_api_key)) return true
  const method = nested.authMethod ?? nested.auth_method ?? raw.authMethod ?? raw.auth_method
  if (typeof method === 'string' && method.trim()) return true
  const arn = nested.profileArn ?? nested.profile_arn ?? raw.profileArn ?? raw.profile_arn
  if (typeof arn === 'string' && arn.includes('codewhisperer')) return true
  const endpoint = nested.tokenEndpoint ?? nested.token_endpoint ?? raw.tokenEndpoint ?? raw.token_endpoint
  if (typeof endpoint === 'string' && endpoint.includes('microsoftonline')) return true
  const start = nested.startUrl ?? nested.start_url ?? raw.startUrl ?? raw.start_url
  if (typeof start === 'string' && /awsapps\.com\/start/i.test(start) && (nested.clientId || nested.client_id || raw.clientId || raw.client_id)) return true
  const provider = String(nested.provider ?? nested.idp ?? raw.provider ?? raw.idp ?? '').trim().toLowerCase()
  if (SOCIAL_PROVIDERS.includes(provider) || IDC_PROVIDERS.includes(provider) || EXTERNAL_IDP_ALIASES.includes(provider)) {
    return true
  }
  const refresh = trimmed(nested.refreshToken ?? nested.refresh_token ?? raw.refreshToken ?? raw.refresh_token)
  if (refresh && refresh.length >= 100 && (
    trimmed(raw.email) || trimmed(nested.email)
    || trimmed(nested.accessToken ?? nested.access_token)
    || trimmed(nested.clientId ?? nested.client_id)
  )) return true
  return false
}

function unwrapKiroCredential(raw) {
  if (!raw || typeof raw !== 'object') return raw
  const nested = raw.credentials
  if (!nested || typeof nested !== 'object' || Array.isArray(nested)) return raw
  const subscription = raw.subscription && typeof raw.subscription === 'object' ? raw.subscription : {}
  return {
    ...nested,
    email: raw.email ?? nested.email,
    account: raw.account ?? nested.account ?? raw.email ?? nested.email,
    provider: nested.provider ?? raw.idp ?? raw.provider,
    idp: raw.idp,
    authMethod: nested.authMethod ?? nested.auth_method ?? raw.authMethod ?? raw.auth_method,
    subscriptionTitle: subscription.title ?? raw.subscriptionTitle ?? raw.subscription_title,
    planType: subscription.type ?? raw.planType ?? nested.planType,
    profileArn: nested.profileArn ?? nested.profile_arn ?? raw.profileArn,
  }
}

export function kiroSessionFromImport(raw) {
  if (!raw || typeof raw !== 'object') throw new Error('kiro credential is not an object')
  const entry = unwrapKiroCredential(raw)
  const kiroApiKey = trimmed(entry.kiroApiKey ?? entry.kiro_api_key)
  const method = inferKiroAuthMethod(entry)
  if (method === 'api_key' || kiroApiKey) {
    return kiroSession({
      accessToken: validateKiroApiKey(kiroApiKey || entry.accessToken || entry.access_token),
      kiroApiKey,
      authMethod: 'api_key',
      account: trimmed(entry.email) || trimmed(entry.account) || 'api-key',
      planType: entry.subscriptionTitle ?? entry.subscription_title ?? entry.planType,
    })
  }
  if (method === 'external_idp') {
    validateKiroIdpEndpoint(entry.tokenEndpoint ?? entry.token_endpoint)
  }
  const refresh = entry.refreshToken ?? entry.refresh_token
  if (refresh) validateKiroRefreshToken(refresh)
  const startUrl = trimmed(entry.startUrl ?? entry.start_url)
    || (method === 'idc' ? BUILDER_ID_START_URL : undefined)
  return kiroSession({
    accessToken: entry.accessToken ?? entry.access_token,
    refreshToken: refresh,
    expiresAt: entry.expiresAt ?? entry.expires_at,
    account: entry.email ?? entry.account,
    authMethod: method,
    kiroProvider: entry.provider ?? entry.idp,
    planType: entry.subscriptionTitle ?? entry.subscription_title ?? entry.planType,
    profileArn: entry.profileArn ?? entry.profile_arn,
    clientId: entry.clientId ?? entry.client_id,
    clientSecret: entry.clientSecret ?? entry.client_secret,
    startUrl,
    tokenEndpoint: entry.tokenEndpoint ?? entry.token_endpoint,
    issuerUrl: entry.issuerUrl ?? entry.issuer_url,
    scopes: entry.scopes,
    region: entry.region,
    authRegion: entry.authRegion ?? entry.auth_region,
    apiRegion: entry.apiRegion ?? entry.api_region,
    machineId: entry.machineId ?? entry.machine_id,
  })
}
