/**
 * Kiro account lifecycle for AuthController: live catalog discovery, Social / Builder ID /
 * IdC login, pasted keys and batch imports, and profile write-back.
 * Functions take the controller as their first argument; the class keeps
 * the public entry points.
 */

import { listStoredSessions, publicSession, saveSession, updateAccountSession } from '../store.js'
import {
  allocateKiroMachineId,
  BUILDER_ID_START_URL,
  canonicalizeKiroMethod,
  exchangeKiroSocialCode,
  kiroSession,
  kiroSocialFlow,
  refreshKiro,
  refreshKiroExternalIdp,
  refreshKiroSocial,
  validateKiroApiKey,
  validateKiroIdpEndpoint,
  validateKiroRefreshToken,
} from './index.js'
import { isKiroBatchImport, parseKiroImportText } from './import.js'
import { kiroCatalogModels } from './catalog.js'
import { catalogRouteSignature, notifyCatalogDiscovery } from '../catalog-sync.js'
import type { AuthController } from '../controller.js'

export async function discoverKiro(ctl: AuthController, session) {
  if (!session || typeof ctl.kiroDiscover !== 'function') return kiroCatalogModels()
  try {
    return await ctl.kiroDiscover(session)
  } catch {
    return kiroCatalogModels()
  }
}

export async function rememberKiroProfile(ctl: AuthController, row, quota) {
  if (!quota || quota.status !== 'ready') return
  const email = typeof quota.account === 'string' && quota.account.trim() ? quota.account.trim() : undefined
  const planType = typeof quota.planType === 'string' && quota.planType.trim() ? quota.planType.trim() : undefined
  if (!email && !planType) return
  if ((!email || row.session.account === email) && (!planType || row.session.planType === planType)) return
  const next = { ...row.session }
  if (email) next.account = email
  if (planType) next.planType = planType
  await updateAccountSession('kiro', row, next, ctl.authPath)
}

export async function existingKiroMachineId(ctl: AuthController) {
  const rows = await listStoredSessions('kiro', ctl.authPath)
  for (const row of rows) {
    const id = row.session?.machineId
    if (typeof id === 'string' && /^[0-9a-f]{64}$/i.test(id)) return id
  }
  return undefined
}

export async function loginKiro(ctl: AuthController, payload: any = {}) {
  const mode = canonicalizeKiroMethod(payload.mode ?? payload.authMethod, {
    tokenEndpoint: payload.tokenEndpoint,
  })
  if (mode === 'api_key' || mode === 'external_idp') {
    throw new Error('kiro API key and enterprise SSO use the paste form, not browser login')
  }
  ctl.claim('kiro')
  ctl.flows.pending('kiro')?.cancel()
  ctl.kiroFlows.pending('kiro')?.cancel()
  if (mode === 'idc' || payload.mode === 'builder' || payload.mode === 'builder-id') {
    const startUrl = typeof payload.startUrl === 'string' && payload.startUrl.trim()
      ? payload.startUrl.trim()
      : BUILDER_ID_START_URL
    const kind = startUrl === BUILDER_ID_START_URL ? 'builder' : 'enterprise'
    const attempt = await ctl.kiroFlows.start('kiro', {
      startUrl,
      kind,
      fetchFn: ctl.fetchFn,
    })
    ctl.finalizing.add('kiro')
    void ctl.completeKiroIdc(attempt)
    return {
      authorizeUrl: attempt.verificationUrl,
      verificationUri: attempt.verificationUri,
      userCode: attempt.userCode,
      mode: 'device',
      kind,
      startUrl,
    }
  }
  const machineId = allocateKiroMachineId(await existingKiroMachineId(ctl))
  const attempt: any = await ctl.flows.start('kiro', kiroSocialFlow({
    // The portal's "Your organization" redirect (login_option=awsidc) carries
    // no code — pivot to the IdC device flow with the issuer it names.
    startIdc: (idc) => ctl.kiroFlows.start('kiro', {
      startUrl: idc.issuerUrl,
      kind: 'enterprise',
      region: idc.region,
      fetchFn: ctl.fetchFn,
    }),
  }))
  attempt.machineId = machineId
  const claim = ctl.claim('kiro')
  void ctl.completePkce('kiro', attempt, claim)
  return { authorizeUrl: attempt.authorizeUrl, redirectUri: attempt.redirectUri, mode: 'pkce', machineId }
}

export async function completeKiroIdc(ctl: AuthController, attempt) {
  try {
    const session = await attempt.waitToken()
    const wasSignedIn = (await listStoredSessions('kiro', ctl.authPath)).length > 0
    const before = catalogRouteSignature(kiroCatalogModels())
    await saveSession('kiro', session, ctl.authPath)
    ctl.lastError.delete('kiro')
    await discoverKiro(ctl, session)
    await notifyCatalogDiscovery(ctl, 'kiro', { wasSignedIn, before, models: kiroCatalogModels() })
    void ctl.quota.refresh('kiro')
  } catch (error) {
    if (!(error instanceof Error && error.message === 'login cancelled')) {
      ctl.lastError.set('kiro', error instanceof Error ? error.message : String(error))
    }
  } finally {
    ctl.finalizing.delete('kiro')
  }
}

/**
 * The Kiro portal redirected an organization login to the IdC device flow
 * (`login_option=awsidc`, issue #167): settle through the device attempt
 * the callback already started instead of exchanging a code. Returns true
 * when the paste completion is settled (or cancelled) this way.
 */
export function resumeKiroIdcPaste(ctl: AuthController, code, claim) {
  if (!code || typeof code !== 'object' || !code.kiroIdcAttempt) return false
  if (ctl.claims.get('kiro') !== claim) {
    code.kiroIdcAttempt.cancel()
    return true
  }
  ctl.finalizing.add('kiro')
  void ctl.completeKiroIdc(code.kiroIdcAttempt)
  return true
}

export async function completeKiroPaste(ctl: AuthController, code, attempt) {
  return exchangeKiroSocialCode(code, attempt.pkce.verifier, attempt.redirectUri, {
    fetchFn: ctl.fetchFn,
    callback: typeof attempt.callback === 'function' ? attempt.callback() : attempt.callback,
    machineId: attempt.machineId,
  })
}

export async function useKiroKey(ctl: AuthController, key, payload: any = {}) {
  const raw = typeof key === 'string' ? key.trim() : ''
  const parsed = parseKiroImportText(raw)
  if (isKiroBatchImport(parsed.kind) && parsed.sessions.length > 0) {
    return saveKiroImports(ctl, parsed.sessions, { refreshMissingAccess: true })
  }
  const mode = canonicalizeKiroMethod(payload.mode ?? payload.authMethod, {
    tokenEndpoint: payload.tokenEndpoint,
  })
  ctl.claim('kiro')
  ctl.flows.pending('kiro')?.cancel()
  ctl.kiroFlows.pending('kiro')?.cancel()
  let session
  if (raw.startsWith('ksk_') || mode === 'api_key') {
    const kiroApiKey = validateKiroApiKey(raw || payload.kiroApiKey)
    session = kiroSession({
      accessToken: kiroApiKey,
      kiroApiKey,
      authMethod: 'api_key',
      account: typeof payload.account === 'string' ? payload.account : 'api-key',
    })
  } else if (mode === 'external_idp' || payload.tokenEndpoint) {
    const tokenEndpoint = validateKiroIdpEndpoint(payload.tokenEndpoint)
    session = await refreshKiroExternalIdp(kiroSession({
      refreshToken: validateKiroRefreshToken(raw || payload.refreshToken),
      clientId: payload.clientId,
      tokenEndpoint,
      issuerUrl: payload.issuerUrl,
      scopes: payload.scopes,
      authMethod: 'external_idp',
      kiroProvider: 'Entra',
      account: payload.account,
    }), { fetchFn: ctl.fetchFn })
  } else {
    session = await refreshKiroSocial(kiroSession({
      refreshToken: validateKiroRefreshToken(raw),
      authMethod: 'social',
      kiroProvider: 'Social',
      account: payload.account,
    }), { fetchFn: ctl.fetchFn })
  }
  const wasSignedIn = (await listStoredSessions('kiro', ctl.authPath)).length > 0
  const before = catalogRouteSignature(kiroCatalogModels())
  await saveSession('kiro', session, ctl.authPath)
  ctl.lastError.delete('kiro')
  await discoverKiro(ctl, session)
  await notifyCatalogDiscovery(ctl, 'kiro', { wasSignedIn, before, models: kiroCatalogModels() })
  void ctl.quota.refresh('kiro')
  return { method: session.authMethod, account: publicSession('kiro', session), count: 1 }
}

export async function saveKiroImports(ctl: AuthController, sessions, { refreshMissingAccess = false } = {}) {
  ctl.claim('kiro')
  ctl.flows.pending('kiro')?.cancel()
  ctl.kiroFlows.pending('kiro')?.cancel()
  const saved: any[] = []
  const errors: any[] = []
  for (const draft of sessions) {
    let session = draft
    const method = canonicalizeKiroMethod(session.authMethod, { tokenEndpoint: session.tokenEndpoint })
    const needsRefresh = refreshMissingAccess
      && method !== 'api_key'
      && (!session.accessToken || session.accessToken === session.refreshToken)
    try {
      if (needsRefresh) session = await refreshKiro(session, { fetchFn: ctl.fetchFn })
      await saveSession('kiro', session, ctl.authPath, { activate: saved.length === 0 })
      saved.push(session)
    } catch (error) {
      errors.push(error instanceof Error ? error.message : String(error))
    }
  }
  if (saved.length === 0) {
    throw new Error(errors[0] || 'no Kiro credentials imported')
  }
  ctl.lastError.delete('kiro')
  const wasSignedIn = (await listStoredSessions('kiro', ctl.authPath)).length > saved.length
  const before = catalogRouteSignature(kiroCatalogModels())
  if (saved[0]) await discoverKiro(ctl, saved[0])
  await notifyCatalogDiscovery(ctl, 'kiro', { wasSignedIn, before, models: kiroCatalogModels() })
  void ctl.quota.refresh('kiro')
  return {
    method: saved[0]?.authMethod,
    account: publicSession('kiro', saved[0]),
    count: saved.length,
  }
}
