# Kiro OAuth

本文件是 `src/oauth/kiro/` 的设计源。改登录、额度、对话或缓存先改这里再改代码。
跨家族硬规则在 [`docs/rules.md`](../../../docs/rules.md)；故障记录在 [`docs/error.md`](../../../docs/error.md)；对照仓库在 [`docs/oauth.md`](../../../docs/oauth.md)。

AWS **Kiro / CodeWhisperer**。协议对齐 [ZyphrZero/kiro.rs](https://github.com/ZyphrZero/kiro.rs) 与 Kiro IDE。对话 **不是** OpenAI Responses，是 `GenerateAssistantResponse` eventstream。

## 文件

| 文件 | 职责 |
|---|---|
| [`index.ts`](index.ts) | 五种凭据、portal PKCE、刷新、profileArn、用量头、静态目录 |
| [`catalog.ts`](catalog.ts) | 登录后 `ListAvailableModels` 活目录；静态 `KIRO_MODELS` 只做离线 fallback |
| [`import.ts`](import.ts) | 卡密 / JSON / CSV / kiro.rs / IDE token 解析；SSO client 配对 |
| [`idc-flow.ts`](idc-flow.ts) | AWS SSO OIDC register + JSON device poll（Builder ID / 企业 IdC） |
| [`request.ts`](request.ts) | OpenAI chat ↔ `conversationState` + eventstream → `chat.completion` |
| [`transport.ts`](transport.ts) | AWS HTTP 生命周期、EventStream 错误传播、按 toolUseId 分配 OpenAI 流索引 |
| [`cache.ts`](cache.ts) | `conversationState.conversationId`。禁止 `Date.now()` |

调度：[`../proxy.ts`](../proxy.ts) `family === 'kiro'` 剥 Codex retention，取出 `kiroConversationId`；真正组 AWS body 在 `openaiToKiro`。
额度：[`quota.ts`](quota.ts) `fetchKiroQuota` / `parseKiroUsage`。
套餐：`KIRO_PLAN_NAMES`（Free / Pro / Pro+ / Powered）。

## 登录（五种凭据）

`KIRO_METHODS`：`social` | `idc` | `external_idp` | `api_key`。Builder ID 在存储里是 `idc` + 官方 Start URL。

| 方法 | 用户看见 | 怎么登录 | 换票注意 |
|---|---|---|---|
| Social / OAuth | Google / GitHub | portal PKCE `app.kiro.dev`，callback 端口 `KIRO_CALLBACK_PORTS` | **authorize 和 token 的 `redirect_uri` 必须字节一致**。Cognito 常是 origin-only（`http://127.0.0.1:PORT`），path 可能是 `/`、`/oauth/callback`、`/signin/callback`。portal 页选「Your organization」时回的不是 code 而是 `login_option=awsidc&issuer_url=…&idc_region=…`——`kiroSocialFlow` 的 `collect` 识别它并转走 IdC 设备流（issue #167），回调页（`kiroIdcPendingPage`）把浏览器重定向到设备确认页（`verificationUrl` 预填配对码）。`refreshKiroSocial` 成功后必须用 refresh JSON 的 `expiresIn` / `expiresAt` **重写** `expiresAt`，不能留旧毫秒戳，否则 TokenManager 每轮都刷新 → `/refreshToken` 429。429 带 `status` + `Retry-After` 回给 DSH，不要改成 500。 |
| Builder ID | 个人 AWS | `idc-flow.ts` + `https://view.awsapps.com/start`，profile `BUILDER_ID_PROFILE_ARN` | |
| Enterprise / IdC | 企业 IAM IC | 同一套 device poll，用户填 org Start URL | `kiroAccountKind` → `idc` |
| Entra / Azure AD | 企业 SSO | `external_idp`，token endpoint 必须是 `*.microsoftonline.com` / `.us` / `.cn` | `refresh_token` grant |
| API Key | `ksk_…` | 直接 bearer，`KIRO_NEVER_EXPIRES` | |

`canonicalizeKiroMethod` 把 `oauth`/`github`/`google`/`gmail`/`gh` → `social`，`builder-id`/`builderid` → `idc`，`azuread`/`entra` → `external_idp`。
没有 `authMethod` 时 `inferKiroAuthMethod` 看 provider / 是否带 clientId+secret：GitHub/Google 是 social，Builder ID / Enterprise 是 idc。

导入：`parseKiroImportText` / `sessionsFromKiroAuth` / `importKiroAuth`。格式对照 [kiro-manager-lite](https://github.com/lucks-cloud/kiro-manager-lite) 与 kiro.rs 的导出样例（**不**引用 AGPL 源码）：

| 来源 | 形状 |
|---|---|
| 卡密 | `邮箱----密码----RefreshToken----ClientId----ClientSecret----登录方式`（也认 Tab / 连续空格 / 逗号） |
| 精简 JSON | `[{ email, refreshToken, provider, clientId, clientSecret }]` |
| 完整备份 | `{ app: "kiro-account-lite", accounts: [{ email, idp, credentials }] }` |
| CSV / TXT | 表头 `邮箱` / `email` / `refreshToken` / `登录方式` |
| kiro.rs | `credentials.json` 数组或对象 |
| Kiro IDE | `~/.aws/sso/cache/kiro-auth-token.json`；IdC 用 `clientIdHash` 配对旁边的 OIDC 注册 json |
| API key | 一行一个 `ksk_…` |

**导入本机会话** 扫本地文件，**一次写入全部账号**。IDE token 缺 clientId/secret 时补上 SSO 缓存里的注册，否则 Builder ID 之后刷新会 401。Settings **粘贴凭证** 吃上面任何一种文本；只有 refresh、没有 access 时会按方法走 `refreshKiro`。

登录成功后 Settings 必须清掉「打开授权页」（`busy === false`），否则授权条还挂在已登录卡下面。

## 对话

DSH `api: openai-completions`。原生是 AWS EventStream `GenerateAssistantResponse`，三种闭集都对不上，Completions + 翻译层是唯一划算的。不要改 Responses / Anthropic（翻译层还在，还丢掉 DSH 原生 Completions）。

```text
DSH chat/completions  →  POST https://q.<region>.amazonaws.com/
  X-Amz-Target: AmazonCodeWhispererStreamingService.GenerateAssistantResponse
  Content-Type: application/x-amz-json-1.0
  Accept: application/vnd.amazon.eventstream
  x-amzn-kiro-agent-mode: vibe
```

`openaiToKiro`：

- `developer` 以及未知角色 → system。官方 wire **没有**独立 system 字段（[kiro.rs](https://github.com/ZyphrZero/kiro.rs) `build_history` / kiro-proxy PROTOCOL.md）。system 钉成 **history 第一条** `userInputMessage` + 固定 ack `I will follow these instructions.`，**不要**每轮拼进 `currentMessage.content`。
- 历史是 `userInputMessage` / `assistantResponseMessage` 成对。当前 user 文本只是这一轮。
- `conversationId` = DSH `session_id` / `prompt_cache_key` **加上 model**（`session:deepseek-3.2`），缺 pin 时 `dsh-kiro:<model>`，`isKiroFallback` 为真时不钉系统提示。**永远不要** `Date.now()`。静态目录各钉各的，切换 picker 不共用一条 AWS conversation。
- tools 仍在 **current** `userInputMessageContext.tools`（官方也是挂 current，不在 conversationState 顶层）。
- **effort 走 `additionalModelRequestFields`**（请求体顶层，与 `conversationState` 同级）。形状以模型自己的 schema（`List-Available-Models` 的 `additionalModelRequestFieldsSchema`）为准：Claude `{ output_config: { effort } }`，GPT-5.6 `{ reasoning: { effort } }`；schema 是封闭的（`additionalProperties: false`），字段或取值不在里面就 400（`Invalid additionalModelRequestFields: property 'output_config' is not defined in the schema…`），所以只在该模型的目录行有档位（`reasoningEfforts` 从同一份 schema 读出）且取值在档位内时才发。活测（2026-09-29）：Opus 5.5 default 花 0.186 credit、low 0.184、**max 0.804（4.3×，35s 对 10s）**；GPT-5.6 Luna none 0.064 / max 0.516（8×，28s 对 4s）。不发这个字段时模型跑 schema 默认档，DSH 里选的档位等于没选。`thinking: { type: 'adaptive', display: 'summarized' }` 也被接受，但没有任何思考事件流出来（`display: summarized` 无效果），所以不发。档位就是速度：本机 Opus 5.5 会话 high 每步推理字数是原来的 2.6×、p90 步时 63s → 96s（xhigh 145s）。
- **缓存是服务端自动的，按请求前缀的内容命中，与 `conversationId` 无关，只是不上报。** `List-Available-Models` 的 `promptCaching` 写着 `supportsPromptCaching: true`（Sonnet 4.6 最多 4 个 checkpoint、每个至少 1024 token；Haiku 4.5 / Opus 4.6 / 4.5 每个至少 4096；DeepSeek / MiniMax / GLM / Qwen 不支持）。活测（2026-09-29）：同一个约 15K token 的前缀连发三次，Haiku 0.0364 → 0.0193 → 0.0193 credit，Sonnet 0.118 → 0.063 → 0.063（重复请求约省一半），但事件里没有 `metadataEvent`，没有 `cacheReadInputTokens`。**增长与工具（2026-09-29 Haiku 4.5，约 12K token 前缀，`meteringEvent` credit）**：纯文本对话追加 2、4 轮，cost 都是冷启动的 0.53×，换一个 `conversationId` 发同样内容仍是 0.53×；带 tool_use / tool_result 的 agent 形态每步只多付新增部分（+1150 token 的一轮只多 0.0008 credit），第 3 步 0.64×，原样重发 0.53×；**只改一个工具的 description，整段缓存作废（1.00×）**——工具定义在缓存前缀里，所以一个会话里工具列表必须逐字节稳定（顺序、描述、schema）。`contextUsagePercentage` 是 3 位小数的浮点（25.567 → 25.574 对应 +14 token），`prompt_tokens` 的推算足够精确。所以 Kiro 的命中率是**测不到，不是没命中**：`npm run analyze` 目录模式显示 `n/a`，单会话显示 `UNMEASURED`。能给的只是**可缓存前缀的估算上限**（`cache.ts` `estimateKiroPrefix`）：每次请求按模型的缓存顺序分段（工具在最前，虽然线格把它挂在 current 上；再是各轮历史和当前轮，只取内容），和同一会话最近 4 次请求比，从头数相同的字节，写进数据目录 `prefix-estimate.jsonl`；分析器对 Kiro 显示 `≤x%`。它假设服务端缓存还热（`gap>5m` 单列），能抓到的是插件把前缀弄坏（工具列表变了、系统提示改了、历史被改写），不是真实命中。kiro.rs 也写「上游 prompt cache 按内容前缀匹配、与会话 id 无关」，稳定前缀（本家 `cache.ts` 钉系统提示）仍是对的。
- **文本块和推理块都是增量，原样拼接。** 不要把「以已有文本开头」的块当累计快照丢前缀（活流里重复字符会被吞），也不要逐块 trim（块边界的空格会丢，推理读成 `modelfetching approach byfinding`）。
- **没有 tools 的请求不带 tool_use / tool_result**：Bedrock 会 400（`The toolConfig field must be defined when using toolUse and toolResult content blocks`，活测 2026-09-29）。压缩 / 摘要请求就是这个形状，且不该拿到可调用的工具，所以 `toolHistoryAsText` 把调用与结果改成文本（连续结果并成一条 user）。有 tools 时线格不变。Kiro 会话 60 天内从未压缩过，此路径没被实战踩到，但 400 是活测事实。（历史里出现当前没提供的工具名，Haiku 4.5 活测是 200，不处理。）
- **无参工具的流式参数**：Kiro 对没有参数的工具不发参数文本，流里 `arguments` 恒为空串；非流式路径一直答 `{}`，现在流式收尾也补一个 `{}`，给宿主一个 JSON 对象。
- tool result 仍包成 `{ json: { result } }`：换成 magpie 的 `{ text }` 块活测只省 1.8% token（6.3K 字符的源码，约 124 token），不值得动线格。
- 输出撞上限：流内 `ContentLengthExceededException` 帧（kiro.rs 读作 stop_reason `max_tokens`）以 `finish_reason: length` 收尾并保留已出文本，不当 502 销毁（宿主会重试同一个还会撞上限的请求）。**活测（2026-09-29）没能复现这个帧**：用 schema 里的 `max_tokens: 1024` 逼出上限，流是静默结束的，没有异常帧也没有 stopReason，只能看到文本被截断，所以这种截断我们分辨不出来（`finish_reason` 仍是 `stop`）。
- 图片：user 消息里 `data:image/{png,jpeg,gif,webp};base64,…` 的 `image_url` 变成该条 `userInputMessage.images: [{format, source: {bytes}}]`（jpg → jpeg；远程 URL 和其他类型不发，一张被拒会让整轮 400）。**只有最近一条带图的 user 消息保留图片**，更早的不再重发（Kiro 自己的 agent 与 magpie 都这样；kiro.rs 是当前消息带图、历史里同图去重）。之前目录声明 `image` 而这里只留文本，图片被静默丢掉。线格来自 kiro.rs `KiroImage` 与 magpie `gateway/kiro.go`，2026-09-29 IdC 账号活测 haiku 4.5：红 / 蓝两张 64×64 图都读对。
- `toolResults` 必须紧跟带该 `toolUseId` 的 `assistantResponseMessage`（history user 或 current）。`relocateDisplacedToolResults` 先按 id 把错位的 result 挪回发出它的 assistant 后面（并发交错：A / user / B / result(A) → AWS 400）；再走原来的 `flushAssistant` 再 `flushUser`。不编造 “Tool results provided.”；有 `toolResults` 时 `content` 保持空串，只有既无文本也无 results 才写占位 `.`。
- `normalizeToolUseId`：已符合 `^[a-zA-Z0-9_.:-]{1,64}$` 的 id 只做 `call_` / `toolu_` / `tool_` → `tooluse_`；带 `|` 或超长的 OpenAI Responses 复合 id（`call_…|fc_…`）用稳定 sha256 映成 `tooluse_<32>`，use 和 result 共用同一张表。
- 上游 401/403 先经 `run` 的刷新钩子（`tokens.ts` `forcedRefresh` → `refreshNow`）刷一次再试；仍失败改写成 400（非 AUTH），避免 DSH 把订阅打成「API 密钥无效」。`MONTHLY_REQUEST_COUNT` → 429 `usage limit reached: <厂商原文>`（`upstream.ts` `quotaFailure`，不带 Retry-After）：DSH 的 `classifyPiAiError` 先判额度措辞、后判 429，所以归为 QUOTA_EXCEEDED、不重试。这个措辞是契约，去掉就会变回可锤的 429。`INSUFFICIENT_MODEL_CAPACITY` → 503；`USER_REQUEST_RATE_EXCEEDED` → 429（有则带 Retry-After，不带额度措辞）；超大 / `TOO_BIG` 保持 400/413，但消息前缀 `input is too long for the model's context window: `——DSH 只在 `CONTEXT_WINDOW_EXCEEDED` 时压缩后继续，pi-ai 适配器靠措辞判定（`isContextWindowExceededError` / `OVERFLOW_PATTERNS`），Kiro 原文 `Input is too long.` 两套都不匹配（回归 `test/kiro.test.ts` 内嵌宿主正则原文）。流内异常（流式和非流式）走同一套分类定状态码，默认 502（可重试）。**错误体的 `type` 决定宿主怎么归类**：宿主按 `<status> <error JSON>` 文本匹配，`invalid.?request` 排在 5xx 之前，所以 5xx 一律 `api_error`（`invalid_request_error` 只给 4xx，429 是 `rate_limit_error`）。5xx 标成 `invalid_request_error` 会让宿主判 INVALID_REQUEST 不重试，长 turn 被打断。不要抄 kiro-cli 的 403 级联。
- eventstream 里结构化 thinking / `text`（无 `content`）映成 Completions `reasoning_content`。不要把思考压成 `<thinking>` XML 写进 `content`。
- 网络块不是帧边界。`KiroEventStreamParser` 拒绝非法帧长 / header 长度，`finish()` 拒绝 EOF 残帧；不能在毒前缀后继续积累数据。见[故障记录](../../../docs/error.md)。
- 流式工具按 `toolUseId` 分配稳定且互异的 OpenAI `index`，参数片段始终是字符串；交错工具不能拼成同一个调用。
- 传输层跑在 `upstreamRequest().run` 里（首字节 120s / 预算 270s / 空闲 270s，每块上游数据 `touch()`）；第一块映射后的输出之前不写头。**首次尝试 90s 内没有映射后的输出就放弃、在写头前重试**（元数据帧不算；只管第一次，重试用剩下的预算）：活测两次首字 ~105s、随后静默 242s 被断，宿主重试 6s 就出字；健康的慢启动实测最多 61s（上游过载）、冷 288K 前缀 12–23s。不要再缩短输出**后**的空闲截止：工具参数生成时上游一个字都不发，实测正常静默 168s。输出前：厂商异常帧按 `classifyKiroHopError` 回 HTTP 状态、不重放；畸形帧 / EOF 残帧 / 断流是传输故障，由 `run` 重试。输出后任何失败都 `destroy`，不写 `error` SSE，不追加成功 `finish_reason` / `[DONE]`；停止消费并释放上游 reader。

命中：有 `metadataEvent.tokenUsage`（或嵌套 `metadataEvent` / snake_case）时用精确字段，`cacheReadInputTokens` → `prompt_tokens_details.cached_tokens`。

**现场 wire 往往没有 `metadataEvent`。** kiro-cli / kirogo / kiro.rs 实测 `:event-type` 是 `initial-response`、`assistantResponseEvent`、`toolUseEvent`、`contextUsageEvent`、`meteringEvent`。`meteringEvent.usage` 是 **credit**，不是 token。没有 tokenUsage 时，`prompt_tokens` = `contextUsagePercentage / 100 *` 该模型 `contextWindow`（**活目录行的窗口**，也就是宿主压缩用的那个数；静态表只在没有活行时兜底）；`completion_tokens` 按正文 + 思考 + 工具参数的字数估（只算正文会让思考 + 工具步骤恒为 0）。没有 cache 字段时命中率不可测，`npm run analyze` 报 `UNMEASURED`，有前缀估算时另列 `≤x%` 上限。AWS 连 context 也没下发时才保持 0/0/0。头解码仍要走过非 string 类型。

## 模型

行在 [`src/catalog/models.json`](../../catalog/models.json) 的 `"kiro"` 键；行格式、来源与 `npm run models` 更新流程见 [`docs/models.md`](../../../docs/models.md)。本节只记本家的取舍与出处。

最近核对：2026-10-08，治理列表（`npm run models`，`origin=KIRO_CONSOLE`）无新行、无字段变化；`? claude-fable-5` 仍是有意保留的兼容 id，不删。价目：`claude-sonnet-5.5` 的 cache read 随 models.dev `amazon-bedrock` `global.anthropic.claude-sonnet-5-5` 从 $0.20 改成 $0.10。chat 列表是否放行 sonnet-5.5 这次没重探。

上次核对：2026-10-04，management `List-Available-Models` 两个 origin 对账。治理列表有 `claude-sonnet-5.5`（`tokenLimits` 1M / 128K，`TEXT`+`IMAGE`，`output_config.effort` 为 low / medium / high / xhigh / max，`rateMultiplier` 1.3），已收入静态 fallback。同一天本机 chat 列表（`origin=AI_EDITOR`，9 个 id）仍没有它。登录后的选择器只采用 chat 列表，不把这一行补进去——chat 发治理列表独有的 id 会 400 `INVALID_MODEL_ID`。`skip` 已删。

上次核对：2026-10-03。chat 列表把 `deepseek-3.2` / `minimax-m2.1` / `qwen3-coder-next` 的 `supportedInputTypes` 收成 `TEXT`，目录三行 `input` 随 chat 列表从 text+image 改成 text。

**选择器以接口为准，不以文档为准。** 登录 / 导入 / 额度刷新 / 启动 warmup 后，`refreshKiroCatalog` 打 management `https://management.<region>.kiro.dev/` `List-Available-Models`，`origin` 用对话同一个 `KIRO_CHAT_ORIGIN`（`AI_EDITOR`）。遇到空列表或区域 403 会再探 `us-east-1` / `eu-central-1`，不在第一个 403 停。**活列表非空就是选择器本身**，同时写进 `oauth-kiro.models` yaml，不再补静态行。对话 hop **仍是** `q.<region>.amazonaws.com` GenerateAssistantResponse。

字段来源（每行从接口读）：`tokenLimits` → 窗口 / 输出上限；`supportedInputTypes` → `text` / `image`；`additionalModelRequestFieldsSchema` → effort（Claude 读 `output_config.effort`，GPT 读 `reasoning.effort`，`none` → DSH `off`，wire 仍发 `none`；schema 为 `null` 就是不支持思考）。静态行只提供排序和美化名，接口没给的字段才用它补。`rateMultiplier`（credit 倍率）只用于 Models 页的 `×倍率` 标签（`catalog.ts` 的 `rate` → `describeCatalog` 的 `rates` → `ModelRow`），不进 `settings.yaml` 路由行（`toHarnessModel` 是白名单）。

- **后端按 origin 放行模型。** 只有 chat origin 的列表才是能对话的模型，不在列表里的模型 400 `INVALID_MODEL_ID`；每个账号的列表就是它的实际权限（见 docs/error.md 2026-09-28 Kiro 官方模型目录与 GPT-5.6 1M 窗口更新；选择器 Claude 400 INVALID_MODEL_ID）。
- **列表按出口区域过滤**（与 Cursor 同理）：中国大陆出口拿不到 Claude。要用 Claude 就给插件配非中国大陆出口的出站代理（`outbound-proxy.json` / 插件 `proxyUrl` / `HTTPS_PROXY`），chat、目录、额度都会走它。目录缓存 key 是 token 加出口代理；手动「刷新」总是重拉，因为系统 VPN 切换出口时 key 感知不到。
- `origin=KIRO_CONSOLE` 是治理目录，**不是**权限列表：chat 发它是 `Improperly formed request`，不要拿它当选择器。它只作静态 fallback 的来源（`npm run models` 读它）。合法 origin 可以用非法值让接口报错列出。
- `KIRO_MODELS` 只是离线 fallback（活列表失败或为空时用）：`KIRO_CONSOLE` 快照去掉 Auto，外加兼容 ID `claude-fable-5`（[pi-provider-kiro](https://github.com/mikeyobrien/pi-provider-kiro) bootstrap）。窗口 / 输出取接口 `tokenLimits` 的精确值，不取官方文档表的取整值。id 用点号（`claude-sonnet-5`、`claude-fable-5.1`）。
- **新模型要等它上 chat 列表才进登录选择器**：不在 chat 列表里的 id 对话会 400 `INVALID_MODEL_ID`，不要并进活列表。静态 fallback 可以先收治理列表已给出 `tokenLimits` 的行。`claude-sonnet-5.5` 就是这样：2026-10-04 收进静态目录，chat 列表仍没有，登录后不会出现。`inferKiroReasoning` / `inferKiroWindow` 按前缀推断，上架后无需改代码。
- **Auto 不进选择器**，活列表列出来也跳过。
- 不要把 `none` 当 DSH 键——整段 `oauth-kiro` 写不进 settings.yaml。
- 离线 fallback 必须有 Opus 5、Opus 4.8；Sonnet 主推是 **Claude Sonnet 5**（4.5 与 4.0 仍保留）。

## 额度

`fetchKiroQuota` 打用量 host（`us-east-1` / `eu-central-1`）。`profileArn` 与对话、目录同源（`kiroProfileArn`）：Builder ID 不带 ARN 会 400 `Invalid profileArn.`。只有 403 才换下一个区。`parseKiroUsage` 一条 cycle：`currentUsage` / `usageLimit` + 进行中的 trial / bonus。卡片显示进度条。没有 Codex 重置卷。

## 缓存

AWS 按**请求前缀的内容**缓存（上面「缓存是服务端自动的」），`conversationId` 不是缓存键，只用来钉系统提示。没有 Codex 前缀、没有 Grok 分片、没有 Gemini `systemInstruction` 字段。system 的稳定位置是 **history 首对**，不是 current 正文。

| 步骤 | 函数 | 做什么 |
|---|---|---|
| 1 | `kiroCacheSessionId` | 清洗 DSH `session_id` / `prompt_cache_key` / model |
| 2 | `kiroConversationId` | pin + **model**；否则 **`dsh-kiro:<model>`** |
| 3 | `pinKiroSystemPrefix` | 每个 conversationId 钉第一次 system；DSH snapshot 增量挂 history **后缀**（再一对 user+ack）。后缀若会夹在 assistant `toolUses` 和 current `toolResults` 之间，改插到那条 assistant **前面** |
| 4 | `openaiToKiro` | 写入 `conversationId`；current 不重倒 system；`parkKiroSystemExtra` 保证 tool 对相邻 |
| 5 | `mapKiroUsage` / `resolveKiroUsage` | 精确 `tokenUsage` 优先；否则 `contextUsageEvent` % × 窗口 |

proxy 只删 `prompt_cache_retention` / `prompt_cache_options`，**不**把 `prompt_cache_key` 转给 AWS。
测试用 `resetKiroSystemPins()`。不要和 GLM / Antigravity 共用 Map。

## 不要

- 不要 `conversationId: \`-${Date.now()}\``。
- 不要把整段 system 每轮拼进 `currentMessage.content`（current 一变，AWS 前缀就 miss）。
- 不要把目录模型共用一个 `dsh-kiro` conversationId。
- 不要把带 `|` 的 OpenAI Responses tool id 原样发给 AWS（`REQUEST_BODY_INVALID`）。
- 不要在错位 tool_result 上编造合成 “Tool results provided.” 或丢掉已有 call 的 result。
- 不要把思考压成 `<thinking>` XML 写进 assistant `content`。
- 不要把 chat hop 改到 `runtime.<region>.kiro.dev`（未在本 hop 的 JSON + eventstream 上证明）。
- 不要只在第一个 ListAvailableModels 403 就放弃；再探另一个 canonical region。
- 不要给 Kiro 写 Codex `session-id` / `prompt_cache_key` 或 Grok `x-grok-conv-id`。
- 不要在新 assistant 上先 `flushUser` 再 `flushAssistant`（会把上一轮 tool_result 写到 tool_use 前面；0.0.58 第三跳 400）。
- 不要把 extra system user+ack 插在 `toolUses` 和匹配的 `toolResults` 中间。
- 不要把 tools 挪到 conversationState 顶层（官方挂 current `userInputMessageContext`）。
- 不要把 Social 的 `redirect_uri` 在 authorize 和 token 之间改掉（HTTP 500）。
- 不要把 `login_option=awsidc` 的回调当「缺 code」失败（那是 portal 让客户端转 IdC 设备流的指令，issue #167 的 `missing authorization code` 就是这么来的）；`kiroIdcRedirectOf` 只认「无 code + awsidc + https issuer_url」，普通 code 回调不受影响，`idc_region` 不是合法区域时落回默认区。
- 不要在 refresh 成功后保留旧 `expiresAt`（TokenManager 会每轮打 `/refreshToken` → 429）。
- 不要把 refresh 429 映射成代理 500；原样回 429（有则带 Retry-After）。
- 刷新永久失败只认 `KiroHttpError` 的 401 或 body `error` 码（`invalid_grant` 等），不扫消息文本。
- 不要只 stub `GenerateAssistantResponse`（会 501）。
- 不要在 eventstream 非 string 头上 `break`（会丢掉 `:event-type`）。
- 不要只认 `metadataEvent.tokenUsage`。现场流经常只有 `contextUsageEvent` + `meteringEvent`（credit）。
- 不要把 `meteringEvent.usage` 当 token。
- 不要把 `api` 改成 Responses / Anthropic。
- 不要把 `none` 写成 `reasoningEfforts` 的键（DSH 只认 `off|minimal|low|medium|high|xhigh|max`）。
- 不要把 5xx 错误体标成 `invalid_request_error`（宿主先匹配 `invalid.?request`，永不重试）。
- 不要用「以已有文本开头」猜累计快照：块是增量，重复开头的块是新文本；也不要 trim 推理块，边界空格是正文。
- 不要给没提供 tools 的请求发 `toolUses` / `toolResults`（Bedrock 400）。
- 不要在会话中途改工具列表的顺序 / 描述（工具在缓存前缀里，改一处整段缓存作废）。
- 不要把 kiro-manager-lite 的 AGPL 源码贴进来；格式只做对照，解析器写自己的。

## 归因

一线：Kiro IDE。协议对齐 MIT [ZyphrZero/kiro.rs](https://github.com/ZyphrZero/kiro.rs)。

| 抄 | 出处 | 本 hop |
|---|---|---|
| 没有独立 system 字段：system 钉成 history 第一条 + 固定 ack | kiro.rs `build_history` | `openaiToKiro` |
| 模型页价格徽标（USD / 1M） | models.dev `amazon-bedrock` 的 `global.*` 端点标价（Kiro 按积分计，`×N` 徽标另走 `rateMultiplier`） | `src/catalog/rates.json`，`npm run rates` 写入（见 [docs/models.md](../../../docs/models.md) 费率表） |
| `GenerateAssistantResponse` eventstream 帧与事件类型 | kiro.rs | `parseKiroEventStream` / `collectKiroEvents` |
| 图片线格 `images: [{format, source: {bytes}}]` | kiro.rs `KiroImage`、magpie `gateway/kiro.go` | `openaiToKiro` |
| 模型目录 | `List-Available-Models`（origin 与 chat 相同）；[kiro.dev/docs/models](https://kiro.dev/docs/models) 只作离线参考 | `refreshKiroCatalog`（取舍见「模型」） |
| 兼容 id `claude-fable-5` | [mikeyobrien/pi-provider-kiro](https://github.com/mikeyobrien/pi-provider-kiro) `0.10.2` bootstrap | 静态 fallback 行 |
| 卡密 / JSON / CSV 导入形状 | AGPL [lucks-cloud/kiro-manager-lite](https://github.com/lucks-cloud/kiro-manager-lite)：只记格式，不抄源码 | [`import.ts`](import.ts) 自己的解析器 |

**不要发明：** 与上游对照相关的禁令（`Date.now()` 会话 id、system 拼进 current、把 credit 当 token、贴 AGPL 源码）都在「不要」。

跨家族对照总表见 [`docs/oauth.md`](../../../docs/oauth.md)。
