# WorkBuddy / WorkBuddy AI（腾讯 CodeBuddy 桌面 agent 套餐）OAuth

本文件是 `src/oauth/workbuddy/` 的设计源。改登录、额度、对话或缓存先改这里再改代码。
跨家族硬规则在 [`docs/rules.md`](../../../docs/rules.md)；故障记录在 [`docs/error.md`](../../../docs/error.md)；对照仓库在 [`docs/oauth.md`](../../../docs/oauth.md)。

**一个家族目录、两个 provider**（与 magpie 包的两 build 一致，两套登录、两个 vault）：

| provider id | build | 端点 | 路由名 |
|---|---|---|---|
| `workbuddy` | WorkBuddy（国内版，CodeBuddy 套餐） | `https://copilot.tencent.com` | `Subs · WorkBuddy · Chat` |
| `workbuddy-ai` | WorkBuddy AI（国际版） | `https://www.workbuddy.ai` | `Subs · WorkBuddy AI · Chat` |

## 上游引擎（引擎即实现，2026-10-18 全过签核、不回退）

本家登录、wire、刷新、额度由运行时下载的 `@magpie-community/opencode-workbuddy-auth`
直接驱动（[`engine.ts`](engine.ts) + [`../../upstream-engine/`](../../upstream-engine/README.md) 基座）：
具名导出 `WorkBuddyAuthPlugin` / `WorkBuddyAIAuthPlugin` 一包双 build；裸 global fetch 经
URL 作用域桥路由进 `outboundFetch`；npm dist-tags 自动跟进。被替换的 TS wire 路径
（登录轮询、刷新 POST、chat 头工厂、meter 额度、四头派生、`import.ts`/`quota.ts`）已删除。

**随包接受的行为反转**（ROLLOUT.md 清单 2026-10-18 全过）：升级改走 npm tarball 自动跟进
（不再手工 git diff 对齐）；四会话头由引擎 attend() 派生（sha256 带进程 SALT——缓存前缀
跨进程会重置一次）；桌面登录变**引用式**（vault 只存 source+uid+占位 token，引擎每跳活读
桌面文件，永不拷贝）；引擎内部的 runsOutAt/spareFree/EDGE_READS 探测/FLAGGED 改写/
工具名消毒/response 包装随包进来（我方 applyCache 仍先做 DSH 剥除与方言改写，引擎在其上
再 fit）；响应上的 `X-Magpie-Sign-In` 协议头由 proxy 层 `WIRE_ONLY` 剥除。

**留在本仓**：vault 会话形状与生命周期、目录闭集与 `/v3/config` 活目录读（catalog.ts，
引擎的 provider.models 说 magpie 行形状、不接管目录）、DSH 方言改写（request.ts）、
缓存剥除与 system 停车（cache.ts）、拒答分类（request.ts）、流程槽与登录完成回调。

## 归因（抄什么 / 不要发明什么）——已删 TS 路径的协议账与引擎行为的上游出处

钉住 **`@magpie-community/opencode-workbuddy-auth@0.1.24`**
（[magpie-community/plugins](https://github.com/magpie-community/plugins) `packages/workbuddy`，MIT；种子 commit `0b58032fa37b57e7a003ea5570d3674dc52fedea`，2026-10-17）。
该包对照的又是 WorkBuddy 桌面端自身（`application-manifest.js` 的头组）与其插桩实测。**抄**：

- 登录流：`POST /v2/plugin/auth/state?platform=<workbuddy|workbuddy-ai>`（`X-No-Authorization/X-No-User-Id/X-No-Enterprise-Id/X-No-Department-Info: true`，body `{}`）→ `{state, authUrl}`；浏览器打开 `authUrl?version=2.0.0&loginSessionId=<hex32>`；每 1s 轮询 `GET /v2/plugin/auth/token?state=`（未就绪 = code 11217 / HTTP 408/429，上限 5 分钟）；再轮询 `GET /v2/plugin/login/account?state=`（Bearer + `X-Domain` + `X-No-User-Id/X-No-Enterprise-Id`，未就绪 = 12151）拿 `uid/nickname/enterpriseId`。
- 企业账号：`X-Enterprise-Id` + `X-Tenant-Id`（同一值）；`/login/account` 没给而非 personal 时查 `GET /v2/plugin/accounts`（同 uid 同 type 唯一 → 唯一 lastLogin → 唯一）。
- 刷新：`POST /v2/plugin/auth/token/refresh`，头 `X-Refresh-Token` + `X-Auth-Refresh-Source: plugin` + `X-Domain`（+ 企业头），body `{}`；到期前 60s（EARLY_MS）预刷；**refresh token 一次性轮换**（2026-10-02 活测坐实，共享 TokenManager 的 rotation hold 负责不花两次）。
- chat：OpenAI Completions，`POST {endpoint}/v2/chat/completions`，**只收流式**（非流式 400 code 11101 `Non-stream chat request is currently not supported`，原样透出不重试）。
- chat 头组（引擎 loader 注入；被删的 `workbuddyUpstreamHeaders` 同源）：`Authorization`、`X-User-Id: <uid>`、`X-Domain`（账号自身 domain，国内版实测 `www.workbuddy.cn`，非站点 host）、`X-Product: SaaS`、`X-IDE-Type/Name: WorkBuddy`、`X-IDE-Version`、`X-Agent-Purpose: conversation`、`X-Agent-Intent: craft`、`X-Requested-With: XMLHttpRequest`、`User-Agent: WorkBuddy/5.5.6`（**没有它 = error 10085**）；AI 版另加 `X-Agent-Type: main`。缺客户端组（使用端归因）的请求在用量明细里算「无客户端」。
- 会话四头：`X-Conversation-ID`（会话稳定）、`X-Conversation-Request-ID`（一次用户发送稳定——后端按它计一次请求，工具回传/重试共用同一个）、`X-Conversation-Message-ID` = `X-Request-ID`（每次请求新鲜，厂商契约即如此）。派生规则见下「缓存」。
- 目录：`GET /v3/config`（**UA 换 `CLI/2.0.0 WorkBuddy/5.5.6`**，裸 UA 拿到的是 IDE 的配置、没有 cli agent）→ `data.agents[].name === 'cli'` 的模型 id 列表 + `data.models[]` 明细（`maxInputTokens`/`maxOutputTokens`/`supportsImages`/`reasoning.supportedEfforts`/`reasoning.canDisableThinking`/`onlyReasoning`）。
- 额度：`POST {endpoint}/billing/meter/get-user-resource-summary`（**无 /v2 前缀**），`{IsPaidUser, Packages[].{CycleTotalCapacity, CycleUsedCapacity}}`（字符串容量）；企业账号 summary 无 packages → `POST /billing/meter/get-enterprise-user-usage`（`limitNum/credit/cycleResetTime/cycleStartTime`，UTC+8 字符串）。
- 请求体改写：`max_completion_tokens`→`max_tokens`；`developer`→`system`；首条非 system 时补默认 system（`You are a helpful assistant.`，app 自身行为）；对象 `tool_choice`→字符串形；FLAGGED 词改写（下）；工具 schema 修形（下）；工具名出站消毒。
- 拒答分类：`unapproved channel`（Claude Code/Codex 官方系统提示词触发，改写已知触发词后仍可能命中）、11140「账号异常受限」、14018「额度用尽（免额度模型也需有效套餐）」。
- 另两类 2026-10-17 登录态实测的 400：**11128**「request illegal」= 渠道校验（AI 版聊天缺会话四头时）或「first message is not system prompt」；**11158**「model [x] is not allowed for user type [personal_free_user]」= 免费账号点到了 picker 列出但不属于它的模型；**11150**「the reasoning effort value is not supported by the current model」= 没有阶梯的模型收到了它不认的 `reasoning_effort`（行上固定档就是为此）。
- 品牌图标：**WorkBuddy 自己的绿色 logo**，不是 CodeBuddy 的青紫色标。两 build 的站点 `assets/logo.svg` 字节相同（assets.workbuddy.cn 与 download.codebuddy.ai，2026-10-17 取），桌面端 `icon.icns` 的像素直方图也是绿（#00C0A0/#00C080 占 67%，无紫）；LobeHub 没有 workbuddy 图标（404）。落地在 ui 层 `TAB_ICONS.workbuddy`（`raw` + `viewBox 0 0 40 40`，id 全改名 `osubs-wb-*` 防文档内冲突），两个 build 共用一个标（`FAMILY_ICON` 同指）。

**不要发明**：installation-id / parent-thread 等 magpie 没发的字段；别家的缓存头（Codex `session-id` / Grok `x-grok-conv-id` / Cline `X-Task-ID`）；把 DSH `session_id` 原样发上游。magpie 的多账号调度 / 每日签到 / runsOutAt 包件到期测算 / spareFree 免费模型豁免 / EDGE_READS 2MiB ECONNRESET→401 探测 / gemini replyAfterTools 重试 / 工具名回写**不引入**（本插件每家族只用 active 账号；这些是 magpie 的路由器/多客户端诉求，README「不采纳」节有账）。

## 对照仓与升级对齐

npm 包与仓库一一对应：

- 仓库：[magpie-community/plugins]（https://github.com/magpie-community/plugins）
- 包目录：`packages/workbuddy`
- npm 包：`@magpie-community/opencode-workbuddy-auth`（其 `repository` 字段同指该目录，MIT）

每次发布都是该目录一条 `workbuddy <version>: …` 的 version-bump commit。版本 → commit 查：

```
https://api.github.com/repos/magpie-community/plugins/commits?path=packages/workbuddy/package.json
```

0.1.24 = `9a4ec8600c04`（2026-10-15）。本 README 钉的 `0b58032` 是其后 55 个 commit 的主线 HEAD（gh compare `9a4ec86..0b58032` 坐实：全区间 `packages/workbuddy` 只动 README 一处——`0b58032` 的 #201 +33 行「免额度模型能用而积分模型被拒」诊断节，docs only；`index.mjs`/`package.json` 零改动）——代码仍与 npm 0.1.24 等价。#201 节里本插件已有等价物的：5.6+ 桌面加密文件导入明确报错且**永不覆盖同 id 账号**（已删的 `import.ts`；引擎桌面方法同语义）、11140 受限分类（`request.ts`）、额度读失败原样上抛（余额未知就是未知）；magpie 路由器专属的（routing details 多账号排查、`usage.test.mjs` 封闭 HOME 复现、浏览器登录续期另一账号）不采纳。

**升级（2026-10-18 起反转）**：引擎车道由 npm dist-tags 自动跟进（sha512 对 registry 元数据校验），不再手工跟版。`git diff` 该目录降级为**审计工具**——检查自动跟进拉进来的行为面、维护本 README 的协议账时用。步骤：

1. 取新版本对应的 bump commit（上面那条 API，取该版本 commit 的 `sha`；本机有 clone 时 `git log --oneline -- packages/workbuddy/package.json` 更快）
2. `git diff <旧bump>..<新bump> -- packages/workbuddy` ——这就是全部 wire 变化
3. 逐项过「归因」节：端点 / 头组 / UA 版本 / 重试码 / 错误分类 / 请求改写 / 目录端点
4. **先改本 README，再改代码**（README 是设计源）
5. 钉住版本号三处同步：本节、[docs/oauth.md] 总表、`index.ts` 文件头
6. `npm run models workbuddy workbuddy-ai` 干跑对账目录（两 build 分开跑）
7. 全量 `npm test`，活测按 [docs/development.md] 的门禁

该包发布节奏很快（两周 24 版），升级前先看 bump commit 的 message——多数版本只有一两个行为修复。**只在 `packages/workbuddy` 有改动时才跟**：同仓库其它目录（其它家族）的变化与本站无关。
## 文件

| 文件 | 职责 |
|---|---|
| [`engine.ts`](engine.ts) | 上游引擎适配层：双 build 插件构建（写回 client.auth.set）、登录/桌面引用/刷新/额度/hop 的引擎驱动面、host 闭集注册 |
| [`index.ts`](index.ts) | 站点表、端点、目录读的头种子常量、桌面文件读取（引擎同款，供目录读与诊断） |
| [`accounts.ts`](accounts.ts) | 流程槽 + 登录完成回调（保存/发现/通知）、身份回写、auto-import |
| [`cache.ts`](cache.ts) | 剥 DSH 缓存字段；首段 system 停车；`dsh-workbuddy[-ai]` 常量兜底（会话四头已归引擎 attend() 派生） |
| [`request.ts`](request.ts) | Completions 方言：`max_completion_tokens` 改名、默认 system、effort 映射（未映射的档取最近一档、单档模型缺省也补发）、include_usage、拒答分类、`prompt_cache_hit_tokens`→`cached_tokens`（FLAGGED/工具修形随引擎包） |
| [`catalog.ts`](catalog.ts) | `/v3/config` 活目录（cli agent）；固定档、`credits`/`modelPromotions` 折算（`creditsOf` / `workbuddyCreditsOf`）；静态表在 `src/catalog/models.json` 的 `workbuddy` / `workbuddy-ai` 键 |

调度：[`../proxy.ts`](../proxy.ts) `/workbuddy[-ai]/v1/chat/completions` → `forward()`（headersOf 只传引擎 session 头；fetchFn 是引擎 loader 的包装）；额度经 [`../families.ts`](../families.ts) 注册 `fetchWorkbuddyQuotaEngine`。

## 协议

DSH `api: openai-completions`。`baseURL` 是 `${origin}/workbuddy`（AI 版 `/workbuddy-ai`），SDK 打到 `/workbuddy[-ai]/v1/chat/completions`。`/v1/responses` 明确 501。

SSE 实测（2026-10-02 活测收口）：以 `: heartbeat` 注释行开头、`data: [DONE]` 收尾；usage 自带 `prompt_cache_hit_tokens` / `prompt_cache_miss_tokens` / `credit`（前两者映射进 `prompt_tokens_details.cached_tokens`，credit 无 DSH 对应槽、忽略）。

`reasoningEfforts` 键只有 `off|minimal|low|medium|high|xhigh|max`，值是 WorkBuddy 原文拼法（`none|low|high|xhigh|max`；厂商 `none` 是 `off` 的值，永不做键）。

## 缓存（会话四头怎么派生）

wire 上没有 Codex 式 `prompt_cache_key` 字段；后端有隐式前缀缓存（usage 带 hit/miss 统计）。策略＝剥 DSH 缓存字段 + 会话四头：

- `cacheSessionId`：DSH `session_id` / `prompt_cache_key` 清洗（≤64，`[^A-Za-z0-9._:-]`→`-`），兜底常量 `dsh-workbuddy[-ai]`（仅分析器可见，不是会话）。
- `X-Conversation-ID` = sha256(`<site>|conversation|` + 会话键).slice(0,32)，会话键 = `session:<cacheSessionId>`；无 DSH 会话时退回首条用户消息签名 `first:<sig>`；两者皆无则**不发**该头（编一个只会把用量明细打散成无数会话）。
- `X-Conversation-Request-ID` = sha256(`<site>|turn|` + 会话键 + `|` + 轮键).slice(0,32)。轮键 = 最后一条「用户自己的话」的位置+签名（工具结果/assistant 工具调用之后的那条不算，同 magpie turnKey）；同一发送的工具回传、重试共用同一个，用户下一条换新。无可用轮键 → 新鲜 hex（厂商对每次请求本来就发新 uuid）。
- `X-Conversation-Message-ID` = `X-Request-ID` = 每次发送新鲜 hex32（厂商契约的每请求 uuid；**不是**会话/缓存 id，对抗清单 grep 时看注释）。

首段 system 停车照 Kimi：同会话增长的 system 快照停在消息尾部，保持前缀可命中；无关提示（换模型）重新钉。

## 登录

浏览器开腾讯登录页（微信快捷 / Google broker 实测可走通），无 PKCE、无回环。authUrl 的 host 是 state 接口返回的（`www.workbuddy.cn` / `www.workbuddy.ai`），不硬编码。

| 项 | 值 |
|---|---|
| state | `POST /v2/plugin/auth/state?platform=<build>`，`X-No-*` 四头，body `{}` |
| token | `GET /v2/plugin/auth/token?state=`，1s 轮询，11217/408/429 继续，5 分钟超时 |
| who | `GET /v2/plugin/login/account?state=`，12151 继续；`uid/nickname/phoneNumber/enterpriseId/type` |
| 刷新 | `POST /v2/plugin/auth/token/refresh`，头见上，60s 预刷，refresh 轮换一次性 |

桌面导入：`~/Library/Application Support/CodeBuddyExtension/Data/Public/auth/workbuddy-desktop[-ai].info`（win `%LOCALAPPDATA%\CodeBuddyExtension`、linux `~/.local/share`）。**只读不回写**；WorkBuddy 5.6+ 把 token 加密（`$wbEncrypted`）只有 app 自己能开——导入时明确报错指引用浏览器登录。desktop 来源的会话刷新＝重读文件，绝不花 refresh token（花掉即把桌面端挤下线）。

## 活测

`npm run live -- workbuddy,workbuddy-ai`（2026-10-17 登录两 build 后通过，六个检查全 PASS）：每个 build 三项——

| 检查 | 打到哪里 | 断言 |
|---|---|---|
| `ping` | 真实代理 → `/v2/chat/completions`（流式） | 回 `PONG`；CN 用 `deepseek-v4.1-flash`、AI 用 `fast-model` |
| `usage` | 同上，读 SSE 尾帧 | OpenAI 形状 `prompt_tokens` / `prompt_tokens_details.cached_tokens`（AI 版实测 cached 128，映射成立） |
| `quota` | 直连家族 `fetchWorkbuddy*Quota`（meter 是不带 `/v2` 的独立 POST，不走 chat 路由，故挂在 `setup(session)` 上） | 有 rows、`total` / `usedPercent` 是数字；实测 CN `Pro 10% of 9900`、AI `Free 0% of 350` |

活测脚本只读 store（`listStoredSessions`，绝不写回）、且不刷新令牌。refresh 轮换另行手工验证（会花掉一次性 refresh token）：两个 build 各刷一次，access 与 refresh 双变、身份字段保留；CN 侧再坐实一次性轮换。真实轮换的写回由共享 `TokenManager` 的 rotation hold 负责。

## 模型

**目录源是 `GET /v3/config`（cli agent 列表 + 明细：`maxInputTokens`/`maxOutputTokens`/`supportsImages`/`credits`/`reasoning.supportedEfforts`/`reasoning.effort`/`canDisableThinking`/`onlyReasoning`）**，优先匿名读（2026-10-17 两次实测：上午两个 build 都回完整 picker，傍晚两个都回 `data.agents: null` / `models: null`——匿名视图**会随服务端会话状态开关**，不再是稳定源）。公开读为空时用 `npm run models -- --profile <profile> --write` 走**登录态**：`scripts/models.ts` 的两个适配器把家族自己的 `workbuddyUpstreamHeaders`（bearer + `X-Domain` + `X-User-Id`，UA 换 CLI）当活目录读，落盘后才对账。静态表（`models.json` 的 `workbuddy` 18 行 / `workbuddy-ai` 27 行）2026-10-17 傍晚已按**登录态**端点重落：两 build 的 cli 列表行 id 未变（仍 18 / 27），变的是字段——见下。magpie 0.1.24 的离线表只作接入时的初始种子。

**AI 版 GLM 模型虽然 config 标 `supportsImages` 但实测丢图**（2026-10-13，glm-5.3/5.3-flash/5.2 回「不支持图片」）——静态行 `input: [text]`，活目录同样按 text-only 收。同名去重：config 里 `deepseek-v4.1-flash` 与 `-sg` 同名时后者加 `(SG)` 后缀。

efforts 映射（值 = WorkBuddy 原文）：`off→none`，`low/medium/high/xhigh/max→原样`；`off` 由 gate 产生（`!onlyReasoning` 且 `canDisableThinking` 非 false 才前置 `none`，照 magpie prepend——厂商字段矛盾时信 `onlyReasoning`）。

**没有阶梯的模型带一个固定档**（2026-10-17 登录态活测）：config 里 `reasoning` 只有 `effort`（`auto`=high、`glm-5.1`/`glm-5v-turbo`/`minimax-m3`/`kimi-k2.6`/`kimi-k2.7`=medium、AI 版 `fast-model`/`balanced-model`=medium、`primary-model`=high）时，行上写 `{ <effort>: <effort> }`。不发 `reasoning_effort` 的后果实测是「不思考」：`kimi-k2.6` 与 `fast-model` 不传时 `reasoning_tokens` 0，传 `medium` 时 203 / 出现思考帧；`glm-5.1` 不传直接 **400 code 11150**「the reasoning effort value is not supported by the current model」。所以 `applyWorkbuddyThinking` 对只有一个非 off 档的行，在 DSH 没选档时也把那一档发出去。

**免费档标在行的 `credits` 上**：`/v3/config` 的 `models[].credits`（`"x0.00"` / `"x0.34 credits"` / `""`）+ 顶层 `modelPromotions`，按 magpie `priceOf` 口径折算成数字落进目录行——整日促销取折后价，**按小时促销不计**（Hy4 夜间免费；缓存列表会把夜里看到的「免费」显示一整天，magpie #121），`x0.00` 即 0 = 免费。模型页对 `credits === 0` 的行出「免费 / Free」徽标（复制见 `src/ui/parts/copy.ts` 的 `freeTag`）。注意这不是 USD 价目，`rates.json` 仍然不收。2026-10-17 登录态实测的免费行：CN `hy3` / `step-5-preview`；AI `hy3` / `step-5-preview` / `deepseek-v4.1-flash`（`-sg` 是 x0.03）。CN 的 `deepseek-v4.1-flash` 是 **x0.11**，不是免费——国际版账号的免费额度不适用于国内版。

**AI 版免费账号的行是按账号过滤的**：同一个 AI 账号（`planType: Free`）拿到的 picker 照样列 GPT-6 / GPT-5.6 全家，但聊天时它们回 **400 code 11158**「model [gpt-6.1-sol] is not allowed for user type [personal_free_user]」——目录是产品配置视角，不是账号真实可用集（`docs/models.md`「厂商列出的，不等于订阅能用的」）。另外 AI 版聊天**必须**带会话四头（缺了回 400 code 11128「request illegal」）且首条消息是 system（否则 11128「first message is not system prompt」）；本插件两条都满足（`cache.ts` + `request.ts`）。

2026-10-17 对账记录：CN 新增 `hy4-preview`（原 `hy4-preview-f` 改 id、窗 1000000→960000）、`kimi-k2.8-preview` / `space-bunny` / `step-5-preview`，`auto` 窗 168000→256000，`deepseek-v4.1-flash` 出现 efforts `[low,high,max]`；AI 新增 GPT-6 全家（astra/sol/luna/6.1-sol）、`gpt-5.6-{sol,terra,luna}`、`grok-4.7`、`gemini-3.8-flash`（即「不采纳」节 replyAfterTools 怪癖模型，已进目录）、`deepseek-v4.1-flash[-sg]`、`glm-5.3-flash`、`hy4-preview` / `step-5-preview` / `kimi-k2.8-preview`，`glm-5.2` 增 `off`；撤 `deep-model` / `gpt-5.3-codex` / `gemini-3.1-pro` / `minimax-m3`。

价格：WorkBuddy 的 `credits`（`x0.29`）是套餐积分倍率、`modelPromotions` 是限时/夜间促销，**不是** USD 价目——`rates.json` 不收（无 USD 来源，不发明数字）。

## 额度

- 个人：`get-user-resource-summary` → 一行 Credits（`Σ CycleUsedCapacity / Σ CycleTotalCapacity`，字符串解析，空 = 0）；plan 名 `IsPaidUser ? Pro : Free`。
- 企业（summary 无 packages）：`get-enterprise-user-usage` → Credits（`credit/limitNum`）+ 周期重置（UTC+8 解析）。

不采纳（magpie 有、本插件不做）：runsOutAt 包件到期测算（付费/免费包分页 + 固定包码表）、spareFree 免费模型豁免、每日签到、多账号调度。

## 不采纳（记录在案）

- **EDGE_READS（>2MiB 拒签请求连接被重置，读起来像 ECONNRESET）**：预刷新（60s）下到期令牌极少见；诊断会显示上游传输错。遇到时重新登录即可。
- **replyAfterTools（gemini-3.8-flash 对工具结果后跟用户消息回 400 11153，插空 assistant 消息重试）**：单模型怪癖且不在静态表；命中时错误原样透出，此处记录。
- **工具名回写（消毒后的名字在响应里改回原名）**：DSH 自带工具名全部是 `[A-Za-z0-9_-]`，出站消毒不触发；MCP 带点/冒号的名字消毒后模型按消毒名调用，DSH 找不到工具的失败比整单 400 好。后续有真实需求再加响应侧回写。
