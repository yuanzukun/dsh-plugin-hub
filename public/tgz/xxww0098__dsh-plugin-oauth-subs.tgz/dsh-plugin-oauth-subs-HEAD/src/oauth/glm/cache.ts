/**
 * Z.AI Coding Plan implicit prefix cache.
 * https://docs.z.ai/guides/capabilities/cache
 *
 * The cache key is a hash of the leading system blob plus history. There is
 * no Codex `prompt_cache_key` and no Grok `x-grok-conv-id`. Sticky routing
 * is the OpenAI `user` field / Anthropic `metadata.user_id` plus the
 * `x-session-id` header. Anthropic also stamps `cache_control` on the first
 * system text block plus a rolling breakpoint on the latest non-system message
 * (ZCode default protocol, `finalizeLatestNonSystemMessageCacheControl`).
 *
 * DSH prepends a runtime-context snapshot as another leading system every
 * step. That rewrite is parked at the messages suffix so the first system
 * blob can still hit. Thinking models also need `clear_thinking: false`
 * (owned by request.ts).
 */

import { splitLeadingSystem, systemText, unrelatedPrompt } from '../../utils/system-pin.js'

const SYSTEM_PIN_CAP = 64
const SYSTEM_PINS = new Map()

/** `x-session-id` when DSH sends no session: one constant, same across restarts and hot reloads. */
export const GLM_STABLE_SESSION = 'dsh-glm'

export function glmCacheSessionId(key) {
  if (typeof key !== 'string') return undefined
  const cleaned = key.trim().replace(/[^A-Za-z0-9._:-]/g, '-')
  if (!cleaned) return undefined
  return cleaned.slice(0, 64)
}

export function resetGlmSystemPins() {
  SYSTEM_PINS.clear()
}

/**
 * Read a pin and mark it most recently used. Map order is recency, so the
 * cap drops the idlest conversation, never one that is still sending steps.
 */
function usePin(key) {
  const pin = SYSTEM_PINS.get(key)
  if (pin === undefined) return undefined
  SYSTEM_PINS.delete(key)
  SYSTEM_PINS.set(key, pin)
  return pin
}

/**
 * Pin the first leading system run per DSH session. Extra / changed
 * snapshots go after the conversation so the implicit-cache prefix
 * stays byte-stable.
 */
export function stabilizeGlmSystemPrefix(messages, sessionId) {
  if (!Array.isArray(messages) || !sessionId) return messages
  const { head, rest } = splitLeadingSystem(messages)
  if (head.length === 0) return messages
  const text = head.map(systemText).join('\n\n')
  const existing = usePin(sessionId)
  if (existing === undefined) {
    if (SYSTEM_PINS.size >= SYSTEM_PIN_CAP) {
      const first = SYSTEM_PINS.keys().next().value
      SYSTEM_PINS.delete(first)
    }
    SYSTEM_PINS.set(sessionId, { head, text })
    return messages
  }
  // A different prompt on the same id is its own request: re-pin, send as-is.
  if (unrelatedPrompt(existing.text, text)) {
    SYSTEM_PINS.set(sessionId, { head, text })
    return messages
  }
  let extra = ''
  if (text !== existing.text) {
    extra = text.startsWith(existing.text)
      ? text.slice(existing.text.length).replace(/^\n+/, '').trim()
      : text
  }
  const parked = extra ? [{ role: 'system', content: extra }] : []
  return [...existing.head, ...rest, ...parked]
}

/**
 * Pin the first Anthropic `system` run per DSH session. Extra snapshots
 * become additional text blocks *without* cache_control so the first
 * block stays a stable prefix. Z.AI Anthropic accepts `cache_control`.
 */
export function stabilizeGlmAnthropicSystem(system, sessionId) {
  if (!sessionId) return system
  const pinId = `${sessionId}\0anthropic`
  const blocks = systemBlocks(system)
  if (blocks.length === 0) return system
  const text = blocks.map((block) => block.text).filter(Boolean).join('\n\n')
  if (!text) return system
  const existing = usePin(pinId)
  if (existing === undefined) {
    if (SYSTEM_PINS.size >= SYSTEM_PIN_CAP) {
      const first = SYSTEM_PINS.keys().next().value
      SYSTEM_PINS.delete(first)
    }
    SYSTEM_PINS.set(pinId, { head: blocks, text })
    return withCacheControl(blocks)
  }
  if (unrelatedPrompt(existing.text, text)) {
    SYSTEM_PINS.set(pinId, { head: blocks, text })
    return withCacheControl(blocks)
  }
  let extra = ''
  if (text !== existing.text) {
    extra = text.startsWith(existing.text)
      ? text.slice(existing.text.length).replace(/^\n+/, '').trim()
      : text
  }
  const extras = extra ? [{ type: 'text', text: extra }] : []
  return withCacheControl([...existing.head, ...extras])
}

function systemBlocks(system) {
  if (typeof system === 'string') {
    const text = system.trim()
    return text ? [{ type: 'text', text }] : []
  }
  if (!Array.isArray(system)) return []
  return system.flatMap((part) => {
    if (typeof part === 'string') {
      const text = part.trim()
      return text ? [{ type: 'text', text }] : []
    }
    if (part && typeof part.text === 'string' && part.text.trim()) {
      return [{ type: 'text', text: part.text }]
    }
    return []
  })
}

function withCacheControl(blocks) {
  if (blocks.length === 0) return blocks
  return blocks.map((block, index) => (
    index === 0
      ? { ...block, cache_control: { type: 'ephemeral' } }
      : { type: 'text', text: block.text }
  ))
}

const CACHEABLE_BLOCK_TYPES = new Set(['text', 'image', 'tool_result'])

function withoutCacheControl(block) {
  if (!isPlainObject(block) || block.cache_control === undefined) return block
  const { cache_control: _dropped, ...rest } = block
  return rest
}

function withMessageCacheControl(message) {
  const content = message.content
  if (typeof content === 'string') {
    if (!content) return undefined
    return [{ type: 'text', text: content, cache_control: { type: 'ephemeral' } }]
  }
  if (!Array.isArray(content) || content.length === 0) return undefined
  const blocks = [...content]
  for (let index = blocks.length - 1; index >= 0; index--) {
    const block = blocks[index]
    if (!isPlainObject(block) || !CACHEABLE_BLOCK_TYPES.has(block.type)) continue
    blocks[index] = { ...block, cache_control: { type: 'ephemeral' } }
    return blocks
  }
  return undefined
}

/**
 * ZCode `finalizeLatestNonSystemMessageCacheControl`
 * (apps/zcode-cli/packages/core/src/runtime/helpers/provider-request-messages.ts):
 * exactly one rolling `cache_control` breakpoint, on the latest non-system
 * message. pi-ai already stamps the last user turn, so the common case is
 * idempotent; this owns the guarantee for assistant-last bodies and clears
 * stale non-system breakpoints a replay client may carry. Message breakpoints
 * only — tool-level breakpoints stay where the client put them, same as ZCode.
 */
export function stabilizeGlmAnthropicMessageCache(messages) {
  if (!Array.isArray(messages) || messages.length === 0) return messages
  const next = messages.map((message) => {
    if (!isPlainObject(message) || message.role === 'system') return message
    if (!Array.isArray(message.content)) return message
    const content = message.content.map(withoutCacheControl)
    const changed = content.some((block, index) => block !== message.content[index])
    return changed ? { ...message, content } : message
  })
  let index = -1
  for (let cursor = next.length - 1; cursor >= 0; cursor--) {
    if (next[cursor]?.role !== 'system') {
      index = cursor
      break
    }
  }
  if (index < 0) return next
  const content = withMessageCacheControl(next[index])
  if (content === undefined) return next
  next[index] = { ...next[index], content }
  return next
}

/** Drop Codex/Grok cache fields; pin `user`; freeze the leading system. */
export function applyGlmCache(payload) {
  const next = { ...payload }
  const sessionId = glmCacheSessionId(next.user)
    || glmCacheSessionId(next.session_id)
    || glmCacheSessionId(next.prompt_cache_key)
  delete next.prompt_cache_key
  delete next.prompt_cache_retention
  delete next.prompt_cache_options
  if (Array.isArray(next.messages) && sessionId) {
    next.messages = stabilizeGlmSystemPrefix(next.messages, sessionId)
  }
  if (sessionId && (next.user == null || next.user === '')) next.user = sessionId
  return { payload: next, cacheSessionId: sessionId }
}

/**
 * Anthropic Messages: pin top-level `system`, `metadata.user_id`, and
 * `cache_control` on the first system block. Same pin map as Completions.
 */
export function applyGlmAnthropicCache(payload) {
  const next = { ...payload }
  const sessionId = glmCacheSessionId(next.metadata?.user_id)
    || glmCacheSessionId(next.session_id)
    || glmCacheSessionId(next.prompt_cache_key)
    || glmCacheSessionId(next.user)
  delete next.prompt_cache_key
  delete next.prompt_cache_retention
  delete next.prompt_cache_options
  if (sessionId && next.system != null) {
    next.system = stabilizeGlmAnthropicSystem(next.system, sessionId)
  }
  if (Array.isArray(next.messages)) {
    next.messages = stabilizeGlmAnthropicMessageCache(next.messages)
  }
  if (sessionId) {
    const metadata = isPlainObject(next.metadata) ? { ...next.metadata } : {}
    if (metadata.user_id == null || metadata.user_id === '') metadata.user_id = sessionId
    next.metadata = metadata
  }
  return { payload: next, cacheSessionId: sessionId }
}

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}
