# Kimi Work（Kimi 桌面版 Work 订阅）

本文件是 `src/oauth/kimi-work/` 的设计源。改登录、额度、对话或缓存先改这里再改代码。
跨家族硬规则在 [`docs/rules.md`](../../../docs/rules.md)；故障记录在 [`docs/error.md`](../../../docs/error.md)；对照仓库在 [`docs/oauth.md`](../../../docs/oauth.md)。

**不是** Kimi Code（`src/oauth/kimi/`，api.kimi.com 设备码）也不是 Kimi API key。
上游是 Kimi 桌面版的普通 **Work 订阅**，走 `https://agent-gw.kimi.com/coding/v1`（OpenAI Completions 方言）。
登录只读本机桌面版自己的登录文件；**没有浏览器登录、没有设备码、没有 API-key 兜底**，无头机器上没有桌面会话文件就登不了。

## 归因（抄什么 / 不要发明什么）

钉住 **`@magpie-community/opencode-kimi-work-auth@0.1.4`**
（[magpie-community/plugins](https://github.com/magpie-community/plugins) `packages/kimi-work`，MIT；
本仓 clone 在 `.local/upstream-magpie/packages/kimi-work/`，README 钉 0.1.4 / 测试与 fixture 同批）。
其再对照 [`kupakupar/kimi-work-provider`](https://github.com/kupakupar/kimi-work-provider) 0.1.2 的本地桌面实现（上游 README「Origin」节）。
**抄**（全部钉到该 clone 的 file:line）：

- **登录 = 只读桌面文件**：`kimi-desktop/daimon-share/daimon/config.json`，win `%APPDATA%` / mac `~/Library/Application Support` / linux `~/.config` 下（`index.mjs:15-19`；README「Sign-in and local files」）。文件 >8MiB、非普通文件、带 BOM 都处理（`index.mjs:26-28`）。
- **凭据字段**：`credentials.kimiCode.{apiKey, baseUrl}` 是 Work 凭据——**origin 必须精确等于 `https://agent-gw.kimi.com/coding/v1`**（尾斜杠剥离后比较，`index.mjs:31`），指向 api.kimi.com 一律拒绝、绝不顶替（`tests/provider.test.mjs:22`）；`credentials.kimiWeb.{accessToken, userId}` 是会员凭据（`index.mjs:29-30`；COMPATIBILITY.md 字段名实录）。
- **账号引用**：vault 只存 `uid = sha256('kimi-work-account\0' + webUserId)`（`index.mjs:33`），**token 永不落盘、每次操作重读桌面文件**（含桌面端自己轮换之后，`index.mjs:21-23` 注释）。桌面换号 = 要求重连（`index.mjs:63-67` `current()`：auth.uid !== 文件 uid → expired；README「Sign-in」）。
- **登录探测**：authorize callback 里 `GET /coding/v1/models`（workToken）验证可用性，失败即报「没有可用的本机登录」（`index.mjs:93-98`）。
- **chat 端点**：`POST https://agent-gw.kimi.com/coding/v1/chat/completions`，OpenAI Completions，流式 / 工具 / 取消原样保留（`index.mjs:120`；README「Models and requests」）。端点守卫：只接受该 origin+path+POST、无 query / 内嵌凭据（`index.mjs:106-108`）。
- **UA**：上游用插件自己的 UA（`Magpie Kimi Work provider/<version>`，`index.mjs:10`），**不假装桌面客户端**（README 明说）。本插件对应 `dsh-plugin-oauth-subs`；除此之外没有任何指纹头（chat 头只有 Authorization + UA + Content-Type，`index.mjs:113-115`；JSON 读再加 Accept / Connect-Protocol-Version，`index.mjs:70-71`）。进站头的 `authorization/x-api-key/cookie/host/content-length/origin` 先删再放自己的（`index.mjs:112`）。
- **错误语义**：推理 401 = 登录过期（重连，`index.mjs:122`）；429 / 5xx **原样透出**（保留 Retry-After 与上游文案，不猜不重试不降级，README 第 18 行）。
- **模型目录**：`GET /coding/v1/models`（workToken，`index.mjs:93,139`）。`{data[], has_more}`；守卫：`has_more` / >100 行报「暂不可用」（`index.mjs:38`）、空目录报「目录为空」（`index.mjs:58`）、档位格式非法报「思考档位格式无效」（`index.mjs:43,46`）；**非法 id（非串 / 空 / >256 / 含控制符或斜杠）静默跳过不报错**（`index.mjs:41` `continue`）。字段：`id / display_name / context_length / supports_image_in / supports_reasoning / reasoningEffortOptions[].effort`。**窗口 = min(context_length, 262144)**（服务端报的是套餐 XL 窗，默认走标准窗，`index.mjs:52-53`）；输出上限 32768；图输入随 `supports_image_in`；工具永远可用。实测目录（fixture + COMPATIBILITY.md macOS 实录）：`k3-agent`（K3）、`k2d8-preview`（K2.8 Preview），档位 LOW / HIGH / MAX。
- **思考档**：`REASONING_EFFORT_*` 前缀剥掉、小写，就是 wire 上的 `reasoning_effort` 值（`index.mjs:45-47` 变体 `{reasoningEffort: effort}` → openai-compatible 的顶层 `reasoning_effort`）。**不是** Kimi Code hop 的 `thinking` 对象。上游保留一切返回值（含 STANDARD，README 第 24 行：LOW 在 Kimi 界面显示为 Standard）。
- **额度**：`POST https://www.kimi.com/apiv2/kimi.gateway.membership.v2.MembershipService/GetSubscriptionStats`，**webToken**（不是 workToken，`tests/provider.test.mjs:71` 断言 Bearer webToken）、body `{}`、头 `Connect-Protocol-Version: 1`（`index.mjs:8,68-72,130`）。只读 `subscriptionBalance.amountUsedRatio`（0..1 → 百分比，`index.mjs:13,131-134`），一行「会员共享额度」（shared membership allowance，不是独立的 Work 免费额度）。**不报 reset**：`expireTime` / `upcomingExpiration.timestamp` 是过期字段、未验证是额度重置（README 第 22 行）；`ratelimitCode5h / ratelimitCode7d` 是 Code 的窗，不读。额度读失败（含 403）**不**作废登录（`tests/provider.test.mjs:75-79`）。

**不要发明**：任何浏览器 / 设备码 / PKCE / 粘贴 key 入口；`api.kimi.com` 或 Kimi Code 凭据的回退；Codex `session-id` / Grok `x-grok-conv-id` / Cline `X-Task-ID` 等别家缓存头；把 DSH `session_id` 原样发上游；额度 reset 时刻；plan 档位名（上游不读 plan，见「额度」）。上游包的 `maxConcurrency: 1`、Magpie Library 指派、kimi-work-opencode 的迁移 / 冲突处理是宿主侧概念，本插件不引入。

## 文件

| 文件 | 职责 |
|---|---|
| [`index.ts`](index.ts) | 端点常量、桌面文件读取与校验、账号引用、session builder、hop 头、刷新（= 重读文件） |
| [`accounts.ts`](accounts.ts) | 登录（读 → 探测 → 存引用）、只读导入、auto-import、活目录发现 |
| [`cache.ts`](cache.ts) | 剥 DSH 缓存字段；首段 system 停车。无任何上游缓存头 |
| [`request.ts`](request.ts) | DSH `reasoning_effort` → 行上广告的档位值；usage 别名映射 |
| [`engine.ts`](engine.ts) | 上游引擎适配层：登录探测、hop fetch、membership 一行会员共享额度（`fetchKimiWorkQuota`） |
| [`catalog.ts`](catalog.ts) | `/coding/v1/models` 活目录 + 守卫；静态表在 `src/catalog/models.json` 的 `kimi-work` 键 |

调度：[`../proxy.ts`](../proxy.ts) `/kimi-work/v1/chat/completions` → `forward()`（[`engine.ts`](engine.ts) 的 loader 每次请求重读桌面文件取活 token）；额度经 [`../families.ts`](../families.ts) 注册 `fetchKimiWorkQuota`（同出 engine.ts）。

## 协议

DSH `api: openai-completions`。`baseURL` 是 `${origin}/kimi-work`，SDK 打到 `/kimi-work/v1/chat/completions`；`/v1/responses` 明确 501。

```text
DSH POST /kimi-work/v1/chat/completions
  → applyKimiWorkCache（剥 prompt_cache_key / session_id / retention；快照停到 messages suffix）
  → applyKimiWorkThinking（目录行声明思考时映射 reasoning_effort）
  → POST https://agent-gw.kimi.com/coding/v1/chat/completions
     Authorization: Bearer <workToken（当次重读桌面文件）>
     User-Agent: dsh-plugin-oauth-subs
```

`reasoningEfforts` 键只有 `off|minimal|low|medium|high|xhigh|max`，值是网关广告的拼法（实测 low / high / max）。行上没映射的档取最近一档（先上后下）；行不提供 `off` 时（该模型关不掉思考），`off` 落到**最低可用档**（如只有 low/high/max 时发 `low`）——不发编造的 `off` 值。未选档不发字段（上游从不代选）。

## 登录

无任何远程登录流。点「登录」= 读桌面文件 → `GET /coding/v1/models` 探测 → 存一条**引用 session**：

| 项 | 值 |
|---|---|
| `accessToken` / `refreshToken` | 占位符 `local-desktop-session`（vault 地板要求非空；上游 loader 的 apiKey 占位同名，`index.mjs:102`） |
| `expiresAt` | `8.64e15`（引用永不过期，桌面端自己管 token 寿命；401 才触发重读） |
| `uid` | 桌面账号引用哈希（换号即拒绝，要求重连） |
| `account` | `Kimi Work (local)`（上游 accountId，`index.mjs:97`）——vault 键，重连原地重绑 |

刷新 = 重读桌面文件（绝不调任何 refresh 端点、不消费桌面 refresh token）；文件没了 / 换号 = 永久失败，行被收割成「请重连」。每次 hop / 目录 / 额度读取都现场重读文件，桌面端轮换 token 即刻生效。

## 模型

行在 [`src/catalog/models.json`](../../catalog/models.json) 的 `"kimi-work"` 键；行格式与来源见 [`docs/models.md`](../../../docs/models.md)。本节记本家取舍与出处。

- `k3-agent`：id / 名（`K3 · Work`）/ 窗 262144 / 输出 32768 —— 上游默认配置（`index.mjs:84`）；档位 low / high / max —— fixture + COMPATIBILITY.md 实录。
- `k2d8-preview`：id / 名（`K2.8 Preview`）—— fixture 第 26-27 行；窗 min(1000000, 262144) = 262144、输出 32768 —— `index.mjs:53`；档位同上。
- 图输入：两行 `supports_image_in: true`（fixture）。
- 活目录：登录 / 导入 / 额度刷新后 `refreshKimiWorkCatalog` 打 `GET /coding/v1/models`（workToken），非空即替换静态行，失败或空回落静态行。`has_more` / >100 行 / 空目录报错不落盘。
- 未知档位拼法（如 `ultra`）没有 DSH 键可落，丢弃不猜；`standard` 落 `low` 键（值仍是 `standard`，README 第 24 行：LOW 显示为 Standard）。
- 价格：Work 订阅没有公开 USD 价目，`rates.json` 不收 `kimi-work` 键（不发明数字）。

最近核对：2026-10-17，上游 0.1.4 包内 fixture 与 COMPATIBILITY.md（macOS 26.6.2 arm64 / Kimi 3.2.17 build 3.2.17.4 实录）。

## 额度

一行 `会员共享额度`（key `membership` / kind `cycle`）：`usedPercent = amountUsedRatio × 100`。无 resetAt、无 planType——membership 端点不返回 plan 档位，上游也不读，账号卡的 plan 徽标留空是如实。读失败算额度错误，不作废登录。

## 缓存

Work 网关与 Kimi Code 同为 `/coding/v1` Completions：wire 上没有缓存字段（上游包对 body 零改写），后端是隐式前缀缓存。策略＝剥 DSH 缓存字段 + 首段 system 停车（照 Kimi 家族移植到同厂商同 wire 的网关；上游包不需要停车是因为它的调用方自己保持 instructions 稳定）。`dsh-kimi-work` 常量只给分析器标签，不钉系统提示、不进上游 body。**不发任何别家缓存头。**

流式 usage：上游不请求 `include_usage`，本 hop 也不加（不发明上游没发的字段）；usage 里若带回 `cached_tokens` / `cache_read_*` 别名则映射进 `prompt_tokens_details.cached_tokens`，缺字段不发明 0。是否补 `include_usage` 待活测（见 openQuestions）。

## 不要

- 不要加浏览器 / 设备码 / PKCE / 粘贴 key 登录。
- 不要把 `api` 写成 `kimi-openai-completions` 或 Responses / Anthropic。
- 不要发 Codex `session-id` / `prompt_cache_key`、Grok `x-grok-conv-id`、Cline `X-Task-ID`。
- 不要把桌面 token 写进本仓 vault / 日志 / 快照。
- 不要消费桌面的 refresh token 或回写 `config.json`（导入只读）。
- 不要假装成 Kimi 桌面客户端（UA 用本插件自己的；例外见下节试点——引擎模式用上游自己的 `Magpie Kimi Work provider/<v>`）。
- 不要把 `kimiWeb` 会员凭据发去 agent-gw，也不要把 `kimiCode` Work 凭据发去 www.kimi.com（上游分开用，测试锁死）。

## 上游引擎（引擎即实现，维护者 2026-10-18 裁定：全过、不回退、不旧兼容）

本家的登录探测、chat wire 与额度读取由运行时下载的上游包
`@magpie-community/opencode-kimi-work-auth` 直接驱动（`src/upstream-engine/` 基座 +
本目录 `engine.ts` 适配层）。被替换的 TS wire 路径已删除——引擎加载 / 契约 / 下载
失败时该家操作带着引擎的错误失败，没有第二条车道：

- **归属不变**：vault 会话形状、目录行与闭集、缓存 / 会话亲和（cache.ts）始终留在本仓；
  引擎只经 `_internal.createPlugin({ readSession, fetchImpl })` 接管「读桌面文件 + 鉴权头 +
  单端点 wire + membership 解析」，fetchImpl 注入 `outboundFetch`（尊重代理卡）。
- **行为差异（有意接受）**：UA 从本插件自己的变为上游的 `Magpie Kimi Work provider/<v>`；
  其余端点 / 校验 / uid 公式与被删的 TS 路径逐字一致。
- **自动跟进**：npm dist-tags 每 15 分钟轮询，新版经 sha512 对 registry 元数据校验后自动
  换版（此豁免仅限引擎家族的上游包；磁盘留最近 3 版，回退＝改 manifest 版本号）。
- 后续家族的推进顺序与各家行为反转清单见
  [`src/upstream-engine/ROLLOUT.md`](../../upstream-engine/ROLLOUT.md)；无 `fetchImpl`
  的包（如 workbuddy）走 [`bridge.ts`](../../upstream-engine/README.md) 的
  URL 作用域 global-fetch 桥。

## 活测

待维护者真实账号验证（本机无 Kimi 桌面版 Work 登录）。上游侧证据：COMPATIBILITY.md 记录 0.1.4 在 Windows 11 与 macOS 26.6.2 arm64（Kimi 3.2.17.4）真实 Work 推理流式 200 + `[DONE]`、目录 `k3-agent` / `k2d8-preview`、一行会员共享额度。本插件落地后需按 [`docs/development.md`](../../../docs/development.md) 跑：登录（读桌面文件）、活目录、额度行、`npm run analyze` 缓存命中率，结论写进 [`docs/error.md`](../../../docs/error.md) 才算收口。
