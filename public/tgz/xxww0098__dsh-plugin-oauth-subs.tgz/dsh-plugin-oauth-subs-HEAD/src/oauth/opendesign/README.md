# Open Design (Design Plan) OAuth

本文件是 `src/oauth/opendesign/` 的设计源。改登录、额度、对话或缓存先改这里再改代码。
跨家族硬规则在 [`docs/rules.md`](../../../docs/rules.md)；故障记录在 [`docs/error.md`](../../../docs/error.md)；对照仓库在 [`docs/oauth.md`](../../../docs/oauth.md)。

上游是 **open-design.ai Cloud 的 Design Plan 订阅**。对照源是社区包
[`@magpie-community/opencode-opendesign-auth`](https://github.com/magpie-community/plugins/tree/main/packages/opendesign)
**钉 0.1.6**（本仓 `.local/upstream-magpie/packages/opendesign/`，下称「上游」；本文行号均指该目录内文件）。
云端两个面（上游 README:26-32）：

| 面 | Host | Key | 用途 |
|---|---|---|---|
| 控制面 | `amr-api.open-design.ai` | `vela_ctrl_…` | 套餐、钱包、5h + 7d 窗、workspace |
| 模型面 | `amr-link.open-design.ai/v1` | `sk-amr-…` | OpenAI 兼容 `/models`、`/chat/completions`、`/responses`、Anthropic messages |

## 上游引擎（引擎即实现，2026-10-18 全过签核、不回退）

设备登录、控制面 usage 与 hop 的 wire facts（baseURL、runtime key、装载 UA）由运行时下载的
`@magpie-community/opencode-opendesign-auth` 驱动（[`engine.ts`](engine.ts)；裸 factory
`OpenDesignAuthPlugin` 零宿主耦合，两个 host 进 [`bridge.ts`](../../upstream-engine/README.md)
桥闭集）。被删的 TS 路径：设备 start/poll、批准解析（`opendesignSessionOfApproval`）、
`quota.ts` 的控制面三读与 parse。

**留在本仓**：vault 会话形状与粘贴 key 登录（vault 域输入——包的 method[1] 是 magpie 的
key 提示，不是我们的）、双钥不过期的恒等刷新、目录闭集（catalog.ts 的 `/models` 读——
引擎 provider.models 说 magpie 行形状）、cache 剥除。

**行为差异（已接受）**：UA 版本随装载的包走（`opendesignEngineUserAgent`，种子 0.1.6 兜底；
hop 与 catalog.ts 的 `/models` 活读同用一个 UA，两个面不自报分裂）；
无档位时套餐名用上游兜底「Open Design」（本仓原为 undefined）；窗口行只带百分比与
resetAt（上游 usage 只给这两样 + display，不再透传 used/total 原始数）。

## 文件

| 文件 | 职责 |
|---|---|
| [`index.ts`](index.ts) | 双面端点、双钥 session、UA 种子常量、请求头、`refresh`（恒等） |
| [`engine.ts`](engine.ts) | 引擎适配层：设备 authorize、usage 映射、hop wire facts、host 闭集注册 |
| [`accounts.ts`](accounts.ts) | 登录流程槽 + 后台完成、粘贴 key、活目录发现、身份回写 |
| [`catalog.ts`](catalog.ts) | 登录后 `GET /v1/models`；静态 `OPENDESIGN_MODELS` 只做 fallback |
| [`cache.ts`](cache.ts) | 剥 Codex / DSH 缓存字段；**不发明**任何亲和（上游 wire 无缓存字段） |

没有 `request.ts`：模型面原生 OpenAI Completions、`reasoning_effort` 原生直通（#137 实测），无方言要译（Ollama 同款先例）。
没有 `import.ts`：上游绝不读写 OpenDesign 桌面应用自己的 `~/.amr/config.json`（index.mjs:10-12，README:42-44），本家同样不碰。

## 落地状态（读前必看）

本目录之外的家外接线（`src/catalog/models.json` 的 `"opendesign"` 键与 `src/catalog/index.ts` 的 `CATALOG_KEYS`、`families.ts` 注册行、`store.ts`、`controller.ts` 的流程槽、`proxy.ts` 路由分支、`models.ts`、`token-managers.ts`、`scripts/models.ts`、`src/index.ts` re-export、`docs/oauth.md` 总表行、UI 各 part）已随注册台落地——与其它家族同构，改这些文件不再有 opendesign 特例。

调度：[`../proxy.ts`](../proxy.ts) `family === 'opendesign'` → `applyOpendesignCache`（经 `families.ts` 注册行分派），`forward()` 到 `OPENDESIGN_CHAT_URL`。
额度：[`engine.ts`](engine.ts) `fetchOpendesignQuotaEngine`（`families.ts` 注册行引用；控制面三读在引擎 usage 里）。套餐名直接取引擎 `usage.plan` 的原文（`Design Plan <Tier>` 拼法随包），不走 [`../plan.ts`](../plan.ts) 的档位表（那个表是 slug 美化，这里是厂商卡片原文）。

## 协议

DSH `api: openai-completions`，单一 Chat 路由：

```text
DSH POST /opendesign/v1/chat/completions
  → applyOpendesignCache（剥 prompt_cache_key / session_id / retention / options）
  → POST https://amr-link.open-design.ai/v1/chat/completions
     Authorization: Bearer <runtime key sk-amr-…>
     User-Agent: opencode-opendesign-auth/0.1.6
```

`baseURL` 是 `${origin}/opendesign`（DSH 打 `{baseURL}/v1/chat/completions`）。

**单路由 vs 上游的按模型分线**：amr-link 对同一 base 同时答三种协议，上游按模型选线（plugins#141 实测，index.mjs:27-45）——chat completions 承载 11 个里 10 个的思考，`claude-haiku-5.5` / `deepseek-v4-pro` 在 Responses 上思考更长，`glm-5.3-flash` 只在 Anthropic messages 上思考。DSH 一条路由只有一种 `api`（闭集，rules.md），本家取**上游自己的缺省线** chat completions（index.mjs:43-45「a model this plugin doesn't name is asked on chat completions」）。代价记在这里：

- `glm-5.3-flash` 在本 hop 上**不会思考**（上游实测它在 chat 线不思考）；它的档位照目录声明（amr-link 接受 `reasoning_effort`），只是不出思考。
- `claude-haiku-5.5` / `deepseek-v4-pro` 会思考，但上游更推荐 Responses 线。

要按线拆路由（像 OpenCode Go / Zen 那样一协议一路），是维护者的决定，见 openQuestions。

`reasoningEfforts` 值 = amr-link 实测接受的 `reasoning_effort` 拼写：`low` / `high` / `max`（#137、#141，models.mjs:11-12）。键只有 `low|high|max`（WorkBuddy 同款子集写法），不发明 medium / off 的映射——DSH 默认档写路由时会自己向最近档折叠。

## 登录

默认**设备授权**（`vela login` 同款），**不是 RFC 8628**：JSON body、自定义状态字，共享 `DeviceFlowManager` 不适用，轮询住在 accounts.ts（WorkBuddy `createFlowAttempts` 形状）。

| 项 | 值 | 出处 |
|---|---|---|
| 发起 | `POST https://amr-api.open-design.ai/api/v1/cli/device-authorizations`，body `{cliVersion: "0.1.4", host: <hostname>, profile: "prod"}` | index.mjs:124-129,47 |
| 回答 | `{deviceId, deviceSecret, userCode, activationUrl, pollIntervalSeconds, expiresAt}` | index.mjs:130-141 |
| 轮询 | `POST …/device-authorizations/{deviceId}/token`，body `{deviceSecret}` | index.mjs:153-156 |
| 批准 | `{status:"approved", controlKey, runtimeKey, user:{id, email}}` → 双钥 + email 账号 | index.mjs:163 |
| 失败 | 404 / `expired|canceled|cancelled|denied|rejected` → 重新开始；401 `invalid_device_secret` → code 失效；pending 继续等 | index.mjs:166-172 |
| 有效期 | `Date.parse(expiresAt)`，缺省 +10min；间隔 `pollIntervalSeconds` 缺省 2s | index.mjs:139-140 |

session：`accessToken` = 运行时 key，`controlKey` = 控制面 key，`account` = email，`uid` = 厂商用户 id（只存不显）。**两把 key 都不过期、没有刷新端点**（index.mjs:71-86，README:92-97）：`refreshToken` 填运行时 key 只为满足 store 形状，`refreshOpendesign` 恒等返回，永远不发。401/403（key 被吊销）只能重登，quota 读会把厂商的话带出来。

粘贴 key：只收 `sk-amr-…` 运行时 key（`vela_ctrl_…` 是控制面 key，模型面不收——上游 runtimeKeyOf，index.mjs:62-65）。粘贴 key 读不到额度（控制面不接受 API key，README:51），卡片只显示账号。

## 模型

行在 [`src/catalog/models.json`](../../catalog/models.json) 的 `"opendesign"` 键；行格式与更新流程见 [`docs/models.md`](../../../docs/models.md)。本节记本家取舍与出处。

静态底表 = 上游种子 models.mjs（11 行，钉 0.1.6）逐行搬：

- `contextWindow` ← 种子 `context`（上游来自 `metadata.context_limit`）；`maxTokens` ← 种子 `output`（`metadata.context_budget`）。
- `input`：种子 `input` 收窄到 text|image（`audio` / `video` / `file` 剥掉，rules 行格式）；种子没有 `input` 的行（deepseek-v4-flash / -pro）= 纯文本 → `["text"]`。
- `rate` ← 花费词倍率：low=x0.5、medium=x1、high=x2、very_high=x4（上游 COST，index.mjs:54）。这是**套餐积分倍率**不是 USD 价目——与 WorkBuddy 同款处理：`rates.json` 刻意不收，没有可对账的价目源（docs/models.md 费率表 WorkBuddy 行同款理由）。
- `reasoningEfforts`：10 行 `{"low":"low","high":"high","max":"max"}`（实测档，models.mjs:15-25）；`gpt-6-luna` 收了档但从不思考（#137）→ `false`。

活目录：登录 / 额度刷新后 `refreshOpendesignCatalog` 打 `GET /v1/models`（Bearer 运行时 key），非空即替换静态行。**目录端点不携带 effort 与名称**（refresh-models.mjs:60-64），活行沿用种子实测档与名称（上游 modelsOf 只从种子借 name / efforts，index.mjs:361）；一个种子不认识的新 id 先不写档位（上游「A model the seed doesn't know has none until it is measured」，index.mjs:260-263）——等实测再收，`npm run models` 报 `unresolved` / 新行无档时人工补。活行上限只看目录 `metadata`，缺省 200K / 32K（上游 modelOf，index.mjs:289-292）——种子不借上限，不发明别的数。活行 `input`：`architecture.input_modalities` 收窄到 text|image，**字段缺失 = 纯文本**（上游 facts() 缺失时取空数组，index.mjs:335-337），不给厂商没声明 image 的行发明输入模态。

最近核对：2026-10-17，钉上游 0.1.6 的 models.mjs / index.mjs / index.test.mjs。

## 额度

`fetchOpendesignQuotaEngine`（引擎 usage 执行的控制面三读，Bearer `vela_ctrl_…`）：

1. `GET /api/v1/workspaces/current` → `activeWorkspaceId`；
2. `GET /api/v1/workspaces/{id}/billing/preflight` → `codingPlan.windows`（`durationSeconds` / `usedCredits` / `limitCredits` / `resetsAt`）+ `balanceUsd`（上游 index.mjs:380-421，样例 test.mjs:63-76）；
3. `GET /api/v1/billing/summary` → `membershipTier`（尽力读，上游同款 summary.ok 才用，index.mjs:400-413）。

卡片：5 小时窗 → `primary`（windowMinutes 300），7 天窗 → `weekly`，最短在前（上游 allowances 排序，index.mjs:247）；钱包 → `prepaid`（USD，上游 money，index.mjs:222-225）；`planType` = `Design Plan <Tier>`（thePlan，index.mjs:251-255），无档位时不发明。`eligible === false` 时钱包行带 note（上游话术，index.mjs:414-416）。重置时刻只用 `resetsAt`，窗口没有就不写。

## 缓存

上游 wire **没有任何缓存亲和字段**：模型请求 `headers: {}`（index.mjs:313），插件也从不在 body 写缓存键。amr-link 是否隐式前缀缓存未声明——**不发明**：

| 步骤 | 函数 | 做什么 |
|---|---|---|
| 1 | `opendesignCacheSessionId` | 清洗 DSH id（1–64，`[A-Za-z0-9._:-]`） |
| 2 | `applyOpendesignCache` | 剥 `prompt_cache_key` / `prompt_cache_retention` / `prompt_cache_options` / `session_id` |
| 3 | `opendesignCacheHeaders` | 空。不写 `session-id` / `x-grok-conv-id` / `X-Task-ID` |

`dsh-opendesign` 只给分析器标签，不进上游 body，不钉系统提示。上游若带回 `cached_tokens` 一族字段，hop 不改写（没有证据它回，缺字段不发明 0）。不要 `Date.now()`。

## 不要

- 不要把登录做成 RFC 8628（`client_id` / form body / `authorization_pending` 那套是别家的）。
- 不要读写 `~/.amr/config.json`（桌面应用自己的登录，上游明说不碰）。
- 不要给 amr-link 写 Codex `session-id` / `prompt_cache_key`、Grok `x-grok-conv-id`、Cline `X-Task-ID`。
- 不要给 `reasoningEfforts` 发明 `off` / `medium` 档值（实测只有 low / high / max）。
- 不要把 `vela_ctrl_…` 控制面 key 发到模型面，或把 `sk-amr-…` 发到控制面额度读之外的任何地方。
- 不要把 `api` 写成 Responses / Anthropic（本家单 Chat 路由）；改线先读「协议」节的代价记录。
- 不要给 rates.json 编 USD 价目（`cost` 词是积分倍率）。
- 不要假装 vela CLI：UA 用上游插件自己的 `opencode-opendesign-auth/0.1.6`（上游 index.mjs:46,107-108），设备 body 的 cliVersion 钉 `0.1.4`（index.mjs:47）。

## 活测

**待维护者真实账号验证。** 本机没有 Open Design 账号，设备授权、双钥会话、额度三读、chat hop、活目录都只有单测夹具覆盖（`test/opendesign.test.ts`），没有真实端到端。活测后把缓存命中率与结论记进 [`docs/error.md`](../../../docs/error.md)。

## 归因

一线：Open Design CLI（`vela login`）的设备授权。社区对照：magpie-community/plugins `packages/opendesign` 钉 0.1.6（MIT），其再对照 #137 / #141 的实测。

| 抄 | 出处 | 本 hop |
|---|---|---|
| 设备授权两跳（端点、body、状态字、失败口径） | 上游 index.mjs:124-175 | `startOpendesignDevice` / `waitForOpendesignDevice` |
| 双钥会话（不过期、refresh 空、email 账号） | 上游 index.mjs:71-86, README:92-97 | `opendesignSession` / `refreshOpendesign` |
| chat 端点与鉴权 | 上游 index.mjs:23,107-110,461-465 | `OPENDESIGN_CHAT_URL` / `opendesignUpstreamHeaders` |
| UA `opencode-opendesign-auth/0.1.6`、cliVersion `0.1.4` | 上游 index.mjs:46-47,107-127 | `OPENDESIGN_USER_AGENT` / `OPENDESIGN_CLI_VERSION` |
| 模型目录端点与字段（context_limit / context_budget / input_modalities / cost） | 上游 index.mjs:333-345,449 + refresh-models.mjs:48,67-87 | `toOpendesignPickerModels` + 静态行 |
| 实测档 low / high / max（gpt-6-luna 不思考） | 上游 models.mjs:15-25（#137 / #141） | 目录 `reasoningEfforts` |
| 花费词倍率 x0.5 / x1 / x2 / x4 | 上游 index.mjs:54 | 目录 `rate` |
| 额度三读与窗口/钱包/档位解析 | 上游 index.mjs:180-186,222-255,380-421 + test.mjs:63-76 | `fetchOpendesignQuotaEngine`（引擎 usage 三读与解析） |
| 「上游无缓存字段」→ 不发明亲和 | 上游 index.mjs:313 | `cache.ts` |
| 粘贴 `sk-amr-…`（控制面 key 不当运行时 key） | 上游 index.mjs:62-65,488-494 | `parseOpendesignApiKey` / `useOpendesignKey` |

**不要发明：** 与上游对照相关的每一条都已在上面「不要」节，这里不重复。

跨家族对照总表见 [`docs/oauth.md`](../../../docs/oauth.md)。
