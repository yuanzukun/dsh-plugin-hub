/**
 * Generic OAuth authorization-code flow engine: one temporary loopback HTTP
 * server per login attempt receives the provider's redirect, validates
 * `state`, and yields the authorization `code`. A pasted callback URL carrying
 * the matching state can substitute for the browser redirect (`manual`).
 * Families whose callback carries something other than a `code` (Command Code
 * credentials, Kiro's IdC pivot) provide `spec.collect`, which may be async;
 * `spec.callbackPage(result)` overrides the rendered success page.
 *
 * The poll-style login managers (Grok device flow, Kiro IdC, GLM CLI) share
 * `createFlowAttempts()` below for their generic attempt bookkeeping.
 */

import { createServer } from 'node:http'
import { createPkce, randomHex, randomToken } from '../utils/pkce.js'

export const DEFAULT_FLOW_TIMEOUT_MS = 180_000

/**
 * Abortable delay shared by the poll-style login flows (Grok device, Kiro IdC,
 * GLM CLI poll). Rejects with the abort reason — or a plain `aborted` error —
 * and removes its abort listener on both exit paths.
 */
export function sleep(ms, signal) {
  return new Promise<void>((resolve, reject) => {
    if (signal.aborted) {
      reject(signal.reason instanceof Error ? signal.reason : new Error('aborted'))
      return
    }
    const timer = setTimeout(() => {
      signal.removeEventListener('abort', onAbort)
      resolve()
    }, ms)
    const onAbort = () => {
      clearTimeout(timer)
      reject(signal.reason instanceof Error ? signal.reason : new Error('aborted'))
    }
    signal.addEventListener('abort', onAbort, { once: true })
  })
}

/**
 * Attempt bookkeeping shared by the poll-style login managers (Grok device
 * flow, Kiro IdC, GLM CLI). Each manager owns one registry: no sessions,
 * caches, or provider ids live here — only the one-attempt-per-provider slot
 * handling and the deferred token promise the family poll loop settles.
 *
 * `begin(provider)` reserves the slot synchronously (across start()'s
 * registration awaits) and returns a handle: `abandon()` when registration
 * failed, `publish(fields)` to register the attempt — adding the shared
 * `waitToken`/`cancel` surface — and `settle(error?, value?)` when it
 * resolves. `settle` and `owns` ignore calls from an attempt that no
 * longer owns the slot (a newer login may already have taken it).
 */
export function createFlowAttempts() {
  const attempts = new Map<string, any>()
  // Slots reserved by start() before its first await. The busy guard alone is
  // not atomic across awaits, so two concurrent start() calls would both pass
  // it and each bind a listener / register a device flow.
  const starting = new Set<string>()

  function begin(provider) {
    if (attempts.has(provider) || starting.has(provider)) {
      throw new Error(`a ${provider} login attempt is already in progress`)
    }
    starting.add(provider)
    const controller = new AbortController()
    let resolveToken
    let rejectToken
    const tokenPromise = new Promise((resolve, reject) => {
      resolveToken = resolve
      rejectToken = reject
    })
    tokenPromise.catch(() => undefined)
    let published
    const settle = (error, value?) => {
      if (attempts.get(provider) !== published) return
      attempts.delete(provider)
      if (error !== undefined) rejectToken(error)
      else if (value !== undefined) resolveToken(value)
    }
    // Name the global AbortSignal interface so the emitted declaration can
    // reference it; the inferred controller.signal type cannot be named.
    const signal: AbortSignal = controller.signal
    return {
      signal,
      settle,
      /** Registration failed before publish: release the reserved slot. */
      abandon() {
        starting.delete(provider)
      },
      /** Is `attempt` still the one registered under this provider? */
      owns(attempt) {
        return attempts.get(provider) === attempt
      },
      /** Register the attempt under the provider and arm settle() for it. */
      publish(fields) {
        const attempt = {
          ...fields,
          waitToken: () => tokenPromise,
          cancel() {
            controller.abort(new Error('login cancelled'))
            settle(new Error('login cancelled'))
          },
        }
        published = attempt
        attempts.set(provider, attempt)
        starting.delete(provider)
        return attempt
      },
    }
  }

  return {
    isBusy(provider) {
      return attempts.has(provider) || starting.has(provider)
    },
    pending(provider) {
      return attempts.get(provider)
    },
    begin,
  }
}

const SUCCESS_PAGE = '<!doctype html><html><head><meta charset="utf-8"><title>Login successful</title></head>'
  + '<body style="font-family:sans-serif;background:#0a0a0b;color:#f4f4f5;padding:48px">'
  + '<h1>Login successful</h1><p>You can close this tab and return to DeepSeek Harness.</p></body></html>'

function failurePage(detail) {
  const safe = String(detail).replace(/[<>&]/g, '')
  return '<!doctype html><html><head><meta charset="utf-8"><title>Login failed</title></head>'
    + `<body style="font-family:sans-serif;background:#0a0a0b;color:#f4f4f5;padding:48px"><h1>Login failed</h1><p>${safe}</p></body></html>`
}

function listenHosts(host) {
  // Hostname `localhost` is what KiroIDE / Google register. Bind the
  // loopback addresses the browser actually connects to after DNS.
  return host === 'localhost' ? ['127.0.0.1', '::1'] : [host]
}

function callbackPathsOf(spec) {
  if (Array.isArray(spec.callbackPaths) && spec.callbackPaths.length > 0) {
    return spec.callbackPaths
  }
  return spec.callbackPath ? [spec.callbackPath] : []
}

function isCallbackPath(pathname, spec) {
  return callbackPathsOf(spec).includes(pathname)
}

/** Path + query the browser actually landed on (Kiro token exchange needs this). */
export function oauthCallbackFromUrl(url, fallbackPath) {
  const loginOption = (url.searchParams.get('login_option') ?? url.searchParams.get('loginOption') ?? '').trim().toLowerCase()
  const issuerUrl = url.searchParams.get('issuer_url') ?? url.searchParams.get('issuerUrl') ?? undefined
  return {
    pathname: url.pathname || fallbackPath || '/',
    loginOption: loginOption || undefined,
    issuerUrl: issuerUrl || undefined,
  }
}

function oauthCallbackFromPasted(raw, fallbackPath) {
  const trimmed = String(raw ?? '').trim()
  if (/^https?:\/\//i.test(trimmed)) return oauthCallbackFromUrl(new URL(trimmed), fallbackPath)
  if (trimmed.includes('code=')) {
    return oauthCallbackFromUrl(new URL(`http://localhost${fallbackPath || '/'}?${trimmed.replace(/^\?/, '')}`), fallbackPath)
  }
  return { pathname: fallbackPath || '/' }
}

function familyUnavailable(error) {
  return error?.code === 'EADDRNOTAVAIL' || error?.code === 'EPROTONOSUPPORT'
}

async function listen(handler, spec) {
  const hosts = listenHosts(spec.host)
  const candidates = spec.ports.flatMap((port) => (port === 0 ? [0, 0, 0] : [port]))
  let lastError
  for (const candidate of candidates) {
    const servers: any[] = []
    let port = candidate
    let unusable = false
    for (const host of hosts) {
      const server = createServer(handler)
      try {
        await new Promise<void>((resolve, reject) => {
          const onError = (error) => reject(error)
          server.once('error', onError)
          server.listen(port, host, () => {
            server.removeListener('error', onError)
            resolve()
          })
        })
        const address = server.address()
        if (address === null) throw new Error(`callback server on ${host}:${port} has no address`)
        if (port === 0 && typeof address === 'object') port = address.port
        servers.push(server)
      } catch (error) {
        server.close()
        if (familyUnavailable(error)) continue
        lastError = error
        unusable = true
        break
      }
    }
    if (unusable || servers.length === 0) {
      for (const server of servers) server.close()
      continue
    }
    return { servers, port }
  }
  throw lastError instanceof Error
    ? lastError
    : new Error(`callback server could not listen on ${spec.host} (ports ${spec.ports.join(', ')})`)
}

export class OAuthFlowManager {
  declare attempts: Map<string, any>
  declare starting: Set<string>

  constructor() {
    this.attempts = new Map()
    // Slots reserved by start() before its first await. The busy guard alone is
    // not atomic across awaits, so two concurrent start() calls would both pass
    // it and each bind a listener / register a device flow.
    this.starting = new Set()
  }

  isBusy(provider) {
    return this.attempts.has(provider) || this.starting.has(provider)
  }

  pending(provider) {
    return this.attempts.get(provider)
  }

  async start(provider, spec) {
    if (this.isBusy(provider)) {
      throw new Error(`a ${provider} login attempt is already in progress`)
    }
    this.starting.add(provider)
    const input = {
      redirectUri: '',
      state: randomToken(32),
      pkce: createPkce(),
      nonce: randomHex(8),
    }
    const timeoutMs = spec.timeoutMs ?? DEFAULT_FLOW_TIMEOUT_MS

    let resolveCode
    let rejectCode
    const codePromise = new Promise((resolve, reject) => {
      resolveCode = resolve
      rejectCode = reject
    })
    codePromise.catch(() => undefined)

    let settled = false
    let timer
    let servers: any[] = []
    let callback

    const settle = (error, code?) => {
      if (settled) return
      settled = true
      if (timer !== undefined) clearTimeout(timer)
      for (const server of servers) {
        server.close()
        server.closeAllConnections?.()
      }
      this.attempts.delete(provider)
      if (error !== undefined) rejectCode(error)
      else if (code !== undefined) resolveCode(code)
    }

    const handler = async (request, response) => {
      const url = new URL(request.url ?? '/', 'http://localhost')
      if (!isCallbackPath(url.pathname, spec)) {
        response.writeHead(404, { 'content-type': 'text/plain' })
        response.end('not found')
        return
      }
      if (url.searchParams.get('state') !== input.state) {
        response.writeHead(400, { 'content-type': 'text/plain' })
        response.end('state mismatch')
        return
      }
      const errorDescription = url.searchParams.get('error_description') ?? url.searchParams.get('error')
      if (errorDescription !== null) {
        response.writeHead(200, { 'content-type': 'text/html' })
        response.end(failurePage(errorDescription))
        settle(new Error(`authorization failed: ${errorDescription}`))
        return
      }
      // Families whose callback carries something other than an OAuth `code`
      // provide spec.collect: it validates the required fields and returns the
      // attempt result (Command Code's apiKey bundle, Kiro's IdC pivot). It may
      // be async — the result then lands once its own network work settles.
      // The state check above already ran, so collect only sees matching
      // attempts. spec.callbackPage(result) overrides the success page (Kiro
      // redirects the browser to the device confirmation URL).
      if (typeof spec.collect === 'function') {
        let result
        try {
          result = await spec.collect(url)
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error)
          response.writeHead(200, { 'content-type': 'text/html' })
          response.end(failurePage(message))
          settle(error instanceof Error ? error : new Error(message))
          return
        }
        if (result === undefined || result === null) {
          response.writeHead(400, { 'content-type': 'text/plain' })
          response.end('missing callback parameters')
          return
        }
        const page = typeof spec.callbackPage === 'function' ? spec.callbackPage(result) : undefined
        response.writeHead(200, { 'content-type': 'text/html' })
        response.end(page ?? SUCCESS_PAGE)
        callback = oauthCallbackFromUrl(url, spec.callbackPath)
        settle(undefined, result)
        return
      }
      const code = url.searchParams.get('code')
      if (code === null || code.length === 0) {
        response.writeHead(400, { 'content-type': 'text/plain' })
        response.end('missing authorization code')
        return
      }
      response.writeHead(200, { 'content-type': 'text/html' })
      response.end(SUCCESS_PAGE)
      callback = oauthCallbackFromUrl(url, spec.callbackPath)
      settle(undefined, code)
    }

    let bound
    try {
      bound = await listen(handler, spec.listen)
    } catch (error) {
      this.starting.delete(provider)
      throw error
    }
    servers = bound.servers
    input.redirectUri = `http://${spec.listen.host}:${bound.port}${spec.callbackPath}`

    timer = setTimeout(() => {
      settle(new Error(`login timed out after ${Math.round(timeoutMs / 1000)}s`))
    }, timeoutMs)
    timer.unref()

    let authorizeUrl
    try {
      authorizeUrl = spec.buildAuthorizeUrl(input)
    } catch (error) {
      // Registration failed after listen(): release the bound callback port and
      // the timer, or the listener outlives the attempt.
      for (const server of servers) {
        server.close()
        server.closeAllConnections?.()
      }
      if (timer !== undefined) clearTimeout(timer)
      this.starting.delete(provider)
      throw error
    }

    const attempt = {
      authorizeUrl,
      redirectUri: input.redirectUri,
      pkce: input.pkce,
      state: input.state,
      waitCode: () => codePromise,
      callback() {
        return callback
      },
      manual(rawInput) {
        if (settled) throw new Error(`the ${provider} login attempt already finished`)
        const trimmed = rawInput.trim()
        if (typeof spec.collect === 'function') {
          if (!/^https?:\/\//i.test(trimmed)) {
            throw new Error('paste the complete callback URL')
          }
          const url = new URL(trimmed)
          if (url.searchParams.get('state') !== input.state) {
            throw new Error('state mismatch: paste the complete callback URL from this login attempt')
          }
          // A sync collect keeps its throw-on-invalid contract (the RPC answers
          // it); an async one (Kiro's IdC pivot) settles the attempt instead —
          // there is no response page to render for a pasted URL.
          const collected = spec.collect(url)
          if (collected && typeof collected.then === 'function') {
            collected.then(
              (result) => {
                if (result === undefined || result === null) {
                  settle(new Error('no credentials found in the pasted callback URL'))
                  return
                }
                callback = oauthCallbackFromPasted(trimmed, spec.callbackPath)
                settle(undefined, result)
              },
              (error) => settle(error instanceof Error ? error : new Error(String(error))),
            )
            return
          }
          if (collected === undefined || collected === null) {
            throw new Error('no credentials found in the pasted callback URL')
          }
          callback = oauthCallbackFromPasted(trimmed, spec.callbackPath)
          settle(undefined, collected)
          return
        }
        let code
        let pastedState
        if (/^https?:\/\//i.test(trimmed)) {
          const url = new URL(trimmed)
          code = url.searchParams.get('code') ?? undefined
          pastedState = url.searchParams.get('state') ?? undefined
        } else if (trimmed.includes('code=')) {
          const params = new URLSearchParams(trimmed)
          code = params.get('code') ?? undefined
          pastedState = params.get('state') ?? undefined
        }
        if (code === undefined || code.length === 0) {
          throw new Error('no authorization code found in the pasted input')
        }
        if (pastedState !== input.state) {
          throw new Error('state mismatch: paste the complete callback URL from this login attempt')
        }
        callback = oauthCallbackFromPasted(trimmed, spec.callbackPath)
        settle(undefined, code)
      },
      cancel() {
        settle(new Error('login cancelled'))
      },
    }
    this.attempts.set(provider, attempt)
    this.starting.delete(provider)
    return attempt
  }
}
