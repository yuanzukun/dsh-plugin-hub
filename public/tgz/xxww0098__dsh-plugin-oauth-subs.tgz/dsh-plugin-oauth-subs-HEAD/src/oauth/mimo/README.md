# Xiaomi MiMo（小米 MiMo 桌面端订阅）OAuth

本文件是 `src/oauth/mimo/` 的设计源。改登录、额度、对话或缓存先改这里再改代码。
跨家族硬规则在 [`docs/rules.md`](../../../docs/rules.md)；故障记录在 [`docs/error.md`](../../../docs/error.md)；对照仓库在 [`docs/oauth.md`](../../../docs/oauth.md)。

**不是**任何 OpenAI 官方后端。上游是小米 MiMo 桌面 App 的订阅服务
`https://mimo-server-<region>.xiaomimimo.com/api/route/chat/completions`（OpenAI Completions 方言），
登录是**小米账号**（account.xiaomi.com 的 long-poll ticket，扫码或密码），会话是服务器
`/sts` 下发的 cookie（`serviceToken` / `userId` / `cUserId`），**没有 Bearer、没有 PKCE、没有设备码、没有回环回调**。
账号按地区路由：俄罗斯 / 印度账号落 `mimo-server-ru` / `mimo-server-in`，其余 `mimo-server-sgp`。

计费是**每周额度**（`/user/usage` 给的是剩余百分比 + 重置日），不是 5h 窗口；无订阅账号是 Free，
被 App 403 `membership_required` 拒绝后由开放平台的 Token Plan（`tp-` key）兜底。

## 文件

| 文件 | 职责 |
|---|---|
| [`index.ts`](index.ts) | 常量（HOSTS / UA / APP_VERSION / SOURCE / 24h 续期）、重定向 cookie jar、小米账号 sign-on 舞步（`/user/xiaomi/me` → serviceLogin → `/sts`）、登录票据（longPolling loginUrl + lp 轮询）、地区搬迁、session 形状与刷新、`mimoServerTime`（+08:00） |
| [`cache.ts`](cache.ts) | 剥 DSH 缓存字段；首段 system 停车；回退 id `dsh-mimo`；**无**粘性头 |
| [`request.ts`](request.ts) | 剥 `reasoning_effort`/`thinking`（无模型声明推理）；流式补 `stream_options.include_usage`；`membership_required` 分类；Token Plan 模型名映射 |
| [`platform.ts`](platform.ts) | 开放平台（platform.xiaomimimo.com，sid `api-platform`）的 passToken 登舞与 Token Plan 三页（detail / usage / apiKey+raw）、`tp-` key 1h 缓存、onPlan 一小时直连标记 |
| [`transport.ts`](transport.ts) | `forwardMimo`：App `/route` 直通；403 `membership_required` → Token Plan 兜底（Bearer `tp-`、模型改名）；401 交给共享 refresh 钩子重新 sign-on |
| [`quota.ts`](quota.ts) | `/user/xiaomi/subscription/self`（套餐）+ `/user/usage`（周额度，**percent 是剩余**）+ Token Plan（best-effort） |
| [`accounts.ts`](accounts.ts) | 浏览器登录（票据 → passToken → sign-on → 地区搬迁）、`completeMimoBrowser` 收尾、`rememberMimoIdentity` 回写 |

调度：[`../families.ts`](../families.ts) `mimo` 行 `applyCache`（→ `applyMimoStreamUsage(applyMimoThinking(cached))`）→ [`../proxy.ts`](../proxy.ts) `family === 'mimo'` → `forwardMimo`。
额度：families.ts 注册 `fetchMimoQuota` 与 `afterEnsure`/`remember`（`rememberMimoIdentity`）。
无本地 CLI 凭据文件可导入（上游只认自己的 auth.json），无 `useKey`、无 `importLocal`。
无活目录端点（上游目录是钉住的静态表），不注册 `catalogModels`——picker 行即 `MIMO_MODELS` 静态楼。

## 协议

DSH `api: openai-completions`。不要写第四个 api 字符串。

```text
DSH POST /mimo/v1/chat/completions
  → applyMimoCache（剥 prompt_cache_key / session_id / retention；首段 system 停车）
  → applyMimoThinking（剥 reasoning_effort / thinking——无模型声明推理）
  → applyMimoStreamUsage（stream 时补 stream_options.include_usage）
  → forwardMimo → POST https://mimo-server-<region>.xiaomimimo.com/api/route/chat/completions
     Cookie: serviceToken=…; userId=…; cUserId=…   ← 无 Authorization
     X-Mimo-Source: mimocode-cli-free
     X-Client-Version: 26.929.292248
     User-Agent: miNative PC/Normal Windows_NT/10.0.26100 SDKV/1.0.0 DEVT/PC DEVS/Windows APP/miaccount_desktop APPV/0.1.0
```

`baseURL` 是 `${origin}/mimo`（DSH Completions SDK 打到 `/mimo/v1/chat/completions`）。
`/mimo/v1/responses` 明确 501。

**Token Plan 兜底**（App 拒绝无会员账号时）：App 403 body 的 `error.code === "membership_required"`
（报文原文「未开通会员或会员已到期，请订阅后使用」）→ 同一 passToken 在开放平台（sid `api-platform`）
登舞读 `/tokenPlan/apiKey` 的 `openaiBaseUrl`（如 `https://token-plan-cn.xiaomimimo.com/v1`）与
`/tokenPlan/apiKey/raw` 的 `tp-` key，请求改发该端点：`Authorization: Bearer tp-…`、无 cookie，
模型名 `mimo-pro → mimo-v2.6-pro`、`mimo-flash → mimo-v2.6-flash`（其余原样）。此后 **1 小时**内该账号
直连 Token Plan（`noteMimoOnPlan`），再回 App 先问（防止中途买了会员）；平台侧重置过 key（plan 端点 401）
→ 作废缓存 key，下次重读。无 Token Plan 或无 key 的账号：403 改写成 **400** 说明（403 会被宿主归 AUTH，
把「没订会员」错当登录死了），报文带上厂商原文。

## 登录

一条路，**小米账号**，浏览器不回 127.0.0.1：

1. `mimoServiceOf`：GET `<base>/user/xiaomi/me`（无会话）读 302 Location 的 `sid`（默认 `mimosgp`）与 `callback`（默认 `<base>/sts`）。
2. `mimoSignInPage`：GET `account.xiaomi.com/longPolling/loginUrl?<q>`，query 逐字照上游
   （`_group=DEFAULT`、`_qrsize=240`、`qs=%3Fsid%3D…%26_json%3Dtrue`、`callback`、`_hasLogo=false`、`sid`、`serviceParam=`、`_locale=en_US`），
   Cookie `deviceId=pc_<32hex>; pass_ua=pc; uLocale=zh_CN`，UA 同上。`&&&START&&&` 守卫后的 JSON 给 `loginUrl` + `lp` 票据，寿命 `min(timeout, 10min)`。
3. UI 打开 `loginUrl`（小米页面，扫码或密码）；`waitMimoPoll` 每 1s 问 `lp`，200 且 JSON 带 `passToken`+`userId` 即完成。
4. `mimoSignInWith`：creds（`userId`、`cUserId`、`passToken`、`deviceId`、`region: 'SGP'`、`base`）种子到
   account.xiaomi.com 的 cookie 上，`mimoSignOn` 手动跟随重定向（≤10 跳；同主机 `http://` 回跳升 `https://`），
   `/sts` 落会话 cookie；`me.region` 是 RU/IN 时换该地区服务器再签一次，creds 跟着搬。

存储形状（对齐上游 `toAuth`/`fromAuth`）：`refreshToken` = 小米账号 JSON（再签到的凭据），
`accessToken` = 会话 cookie JSON，`expiresAt` = 签发 + **24h**（App 一天后重签），
`account` = 小米 userId（数字，非 opaque）。**刷新** = 同一 passToken 再走一遍 sign-on
（`refreshMimo`；TokenManager `preemptMs` = 10min 提前量，对齐上游 `LEAD_MS`）。
passToken 失效（回的是小米登录页 HTML / `code != 0`）→ `MimoLapsedError`（401 + `invalid_grant`，
永久失败，登录被回收重新登录），其余网络错误是临时失败。

## 模型

行在 [`src/catalog/models.json`](../../catalog/models.json) 的 `"mimo"` 键（键与 `CATALOG_KEYS` 闭集由注册台落地）；来源是**上游钉住的静态表**，
没有目录端点（上游 `MODELS` 即常量）：

| 模型 | 名称 | contextWindow | maxTokens | input | 出处 |
|---|---|---|---|---|---|
| `mimo-pro` | MiMo Pro | 1,000,000 | 128,000 | text, image | 上游 index.mjs:28-32（`limit.context` / `limit.output` / `modalities.input`）、README「Models」表 |
| `mimo-flash` | MiMo Flash | 1,000,000 | 128,000 | text, image | 同上 |

- 两行都 `reasoningEfforts: false`：上游表**没有**任何推理字段，不发明阶梯（`applyMimoThinking` 剥掉 DSH effort）。
- 上游 `release_date: 2026-07-01`、`tool_call: true`、`attachment: true` 是宿主侧元数据，目录行不收。
- `mimo-auto` 是 App 的默认模型别名，上游把它改写成 `mimo-pro` 发出（index.mjs:697-703）；本 hop 的 picker 永远不会发 `mimo-auto`，故不设映射。
- 无价目源（Token Plan 定价不在上游包里），`rates.json` 不加 `mimo` 键；`scripts/models.ts` ADAPTERS 写 `manual`。

## 额度

上游 `usage`（index.mjs:534-584）抄的就是 magpie 内建 MiMo 账号卡（`internal/provider/mimo_usage.go`）的取数：

| 端点 | 用途 |
|---|---|
| `GET <base>/user/xiaomi/subscription/self` | 套餐：`current.title`（中文，如「MiMo 高阶」）→ `planTier`（1 Starter / 2 Plus / 3 Pro / 4 Ultra）→ `planCode`；`endTime`、`renewalMode`（MONTHLY/YEARLY→auto，ONE_TIME→off） |
| `GET <base>/user/usage` | 周额度：`percent` 是**剩余**百分比（上游 used = 100 − percent），`resetDate` 是重置日（北京时间）；无 `resetDate` = 无套餐（Free 不画条） |
| 平台 `/api/v1/tokenPlan/detail` + `/tokenPlan/usage` | Token Plan：`planName`、`currentPeriodEnd`（**UTC**，与 App 端点时区不同）、`month_total_token`（退 `plan_total_token`）的 used/limit；有 App 套餐时行名带「· API key」 |

卡片规则（上游同款）：有 App 套餐 → 套餐名 + 周条（+ Token Plan 侧条）；无 App 套餐但有 Token Plan →
`Token Plan <名>` 当套餐、credits 当 allowance；两者皆无 → `Free`。会话中途被 401 / 登录页弹回 → 内存里
重新 sign-on 一次再读，仍失败按「sign-in expired」报错（与上游 `page()` 的 force 重试一致）。
平台读失败不致命（上游吞掉，卡片照出）。

DSH 行：周条 `kind: 'primary'`、`windowMinutes: 10080`、`product: '7 days'`；Token Plan 条
`kind: 'product'`、`unit: 'credits'`、used/total 原数（UI 自己渲染；上游的 `6.81M / 4.1B` 缩写与
`aside: true` 标记是 magpie 卡片的概念，本仓行形状没有该字段——README 记录，不发明）。

## 缓存

App 服务器是**隐式前缀缓存**：上游客户端不发任何缓存/会话亲和字段（chat 请求只有 cookie + 三个标记头，
index.mjs:745-750），也没有粘性 HTTP 头。所以 `cache.ts` 只做两件事：

1. 剥 DSH 的 `prompt_cache_key` / `prompt_cache_retention` / `prompt_cache_options` / `session_id`；
2. 首段 system 钉住、后续纯扩展快照停到 messages suffix（kimi/cline 的停车纪律，本家自己的实现与 id）。

回退 id `dsh-mimo` 不是会话，从不钉。**不要**给 MiMo 写 Codex `session-id`、Grok `x-grok-conv-id`、
Cline `X-Task-ID` 或任何 `Date.now()`。命中情况待活测（见下）。

## 不要

- 不要发 `Authorization`——App 端点只认 cookie；Token Plan 端点才用 `Bearer tp-…`（两套凭据不混用）。
- 不要改 UA / `X-Client-Version` / `X-Mimo-Source` 的值，也不要按本机平台改写 UA——上游三个地区、登录与对话用的都是这一个 Windows 串。
- 不要发明推理阶梯（`reasoningEfforts: false` 是有意的）；不要发 `mimo-auto`。
- 不要把 `percent` 当「已用」——它是**剩余**（上游 used = 100 − percent，usage.test.mjs:51 钉 70→used 30）。
- 不要把 Token Plan 的时间当北京时间——平台 `currentPeriodEnd` 是 **UTC**（上游注释「(UTC)」）。
- 不要在平台替用户创建 API key（`/tokenPlan/apiKey/raw` 读不到 key 就把 App 的 403 原样分类，不 POST 生成）。
- 不要给额度/登录之外的请求加 `X-Mimo-Source`（服务器页面只带 UA + `X-Client-Version`）。
- 不要给 mimo 加本地导入或粘贴 key：上游只有浏览器登录一种，本地无凭据文件。
- 不要把 `api` 写成第四个字符串。
- 上游「平台 key 401 → 重读」与「1 小时直连」的语义是按**账号**（userId）记的，不要按会话或进程记。

## 归因

一线：**小米 MiMo 桌面 App 的客户端行为**，全部经社区对照仓
[`@magpie-community/opencode-mimo-auth 0.1.9`](https://github.com/magpie-community/plugins/tree/main/packages/mimo)
（MIT；本仓 `.local/upstream-magpie/packages/mimo/`，下表 `index.mjs` 行号都指它）钉住；它本身再对照 magpie
内建的 MiMo 账号（`internal/provider/mimo_usage.go` / `mimo_test.go`）。

| 抄 | 上游出处 | 本 hop |
|---|---|---|
| 三地区 API base | `index.mjs:14-19`（HOSTS / REGION） | `MIMO_HOSTS` / `MIMO_DEFAULT_REGION` |
| UA / `X-Client-Version` / `X-Mimo-Source` | `index.mjs:21-23`（APP_VERSION / SOURCE / UA）、`:107`（appHeaders）、`:748`（chat 才加 Source） | `MIMO_APP_VERSION` / `MIMO_SOURCE` / `MIMO_USER_AGENT` / `mimoUpstreamHeaders` / `mimoPageHeaders` |
| cookie jar 与 sign-on 舞步 | `index.mjs:53-101`（Jar）、`:114-161`（session：`/user/xiaomi/me` → serviceLogin → `/sts`，http→https 修正，Lapsed/403/46109 判定） | `MimoJar` / `mimoSignOn` |
| 地区搬迁 | `index.mjs:345-354`（`me.region` → RU/IN 服务器再签） | `mimoSignInWith` |
| 登录票据 + 轮询 | `index.mjs:278-292`（serviceOf）、`:299-320`（longPolling loginUrl，query 逐字）、`:323-334`（waitPoll，1s 间隔 / 70s 上限）、`:26`（SIGN_IN_LIFE 10min） | `mimoServiceOf` / `mimoSignInPage` / `waitMimoPoll` |
| 存储形状（refresh=账号 JSON、access=cookie JSON、24h、accountId=userId） | `index.mjs:24`（RENEW_AFTER）、`:239-263`（toAuth/fromAuth） | `mimoSession` / `parseMimoStored` |
| 刷新（同 passToken 重签，提前 10min，失效=expired） | `index.mjs:25`（LEAD_MS）、`:438-455`（renew）、`:478-493`（refresh，Lapsed→signIn "expired"） | `refreshMimo` + TokenManager `preemptMs: MIMO_PREEMPT_MS` |
| chat 端点与 wire | `README.md:22`、`index.mjs:671`（config api = HOSTS[REGION]+/route）、`:688`（loader baseURL）、`:745-750`（chat 头） | `mimoChatUrl` / `forwardMimo` |
| membership_required 兜底（403 判定、tp- key、端点校验、模型改名、1h 直连、key 401 重读、其余 403 原样） | `index.mjs:35`（TP_MODELS）、`:36`（TP_LIFE 1h）、`:629-660`（planKey）、`:662/739-744`（onPlan）、`:716-773`（loader fetch 的 toPlan 与 403 分支） | `platform.ts` / `request.ts` / `transport.ts` |
| 平台登舞（401+loginUrl、sid `api-platform`、`/sts`、http→https） | `index.mjs:169-226`（PLATFORM / platformPage）、usage.test.mjs:117-147（登录报文形状） | `mimoPlatformPage` |
| 额度三读与卡片规则 | `index.mjs:357-364`（注释：usage & billing 两页）、`:375`（TIERS）、`:409-417`（serverTime +08:00）、`:499-532`（page 重试）、`:534-584`（usage）、`:591-627`（tokenPlan） | `quota.ts` |
| 模型两行（1M/128k/text+image、无推理） | `index.mjs:28-32`、`README.md:84-88` | `src/catalog/models.json` `"mimo"` 键 |

**不发明：** 推理阶梯、`mimo-auto` 映射、目录端点、价目、平台代建 key、按平台改写 UA、粘性缓存头、
`stream_options.include_usage` 之外的一切 body 字段。`include_usage` 是本仓 Completions 家族的统一习惯
（kimi/cline/workbuddy request.ts），上游插件自身未显式发——活测时验证流式不受影响，若服务器拒绝则删掉
（见「活测」）。

跨家族对照总表见 [`docs/oauth.md`](../../../docs/oauth.md)（总表行由注册台落地）。

## 活测

**待维护者真实账号验证。** 单测覆盖登录解析、session 往返、缓存隔离、代理路由（含 Token Plan 兜底）与
额度 snapshot，但以下只有真账号能回答：

1. 流式 + `stream_options.include_usage` 是否 200、usage 帧是否带 `prompt_tokens_details.cached_tokens`（缓存命中率进 `docs/error.md`）。
2. 周条 `percent` 语义（剩余）在真实账号上与卡片一致。
3. RU/IN 账号的地区搬迁路径（本机难以覆盖）。
4. Token Plan 兜底：403 → 平台 key → `token-plan-*.xiaomimimo.com` 改名请求全链路。
