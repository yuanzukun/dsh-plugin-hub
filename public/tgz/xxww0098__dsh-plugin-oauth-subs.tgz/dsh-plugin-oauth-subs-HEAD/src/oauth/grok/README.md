# Grok OAuth

本文件是 `src/oauth/grok/` 的设计源。改登录、额度、对话或缓存先改这里再改代码。
跨家族硬规则在 [`docs/rules.md`](../../../docs/rules.md)；故障记录在 [`docs/error.md`](../../../docs/error.md)；对照仓库在 [`docs/oauth.md`](../../../docs/oauth.md)。

**不是** OpenAI Responses。上游是 xAI `api.x.ai/v1/responses`，登录对齐 Grok CLI。

## 文件

| 文件 | 职责 |
|---|---|
| [`index.ts`](index.ts) | OIDC 发现、device/PKCE、换票、刷新、Responses 头、套餐档位 |
| [`device-flow.ts`](device-flow.ts) | RFC 8628 设备码（默认登录，无 loopback） |
| [`credits-frame.ts`](credits-frame.ts) | grok.com `GetGrokCreditsConfig` 的 gRPC-web 帧解码 |
| [`reset-frame.ts`](reset-frame.ts) | grok.com 重置卡 `GetRemainingResets` / `RedeemReset` 的 gRPC-web 编解码 + 公开卡 id 哈希 |
| [`request.ts`](request.ts) | DSH Responses body：钉 leading system，多余 snapshot 挂 **input 后缀**；真 Fast id（`grok-4.7-build-fast`）原样透传、残留 `-fast` 别名剥掉、`service_tier` 永不发。不抬顶层 `instructions` |
| [`cache.ts`](cache.ts) | `prompt_cache_key` + grok-build 头；家族内、按兼容版本保存的进程级 leading-prefix LRU，兼容热重载保留，进程重启或显式 reset 清空。禁止带 Codex `session-id` |
| [`diagnostics.ts`](diagnostics.ts) | 私有、轮转的缓存诊断：进程内加盐指纹、钉住原因／模块代次、输入公共前缀字节数、上游真实缓存读数；不改变请求、响应或重试 |

调度：[`../proxy.ts`](../proxy.ts) `family === 'grok'` → `normalizeGrokResponsesBody` + `applyGrokCache` + `grokAffinityHeaders`。
额度：[`quota.ts`](quota.ts) `fetchGrokQuota` / `parseGrokBilling` / `applyGrokCreditsSnapshot`；重置卡 `fetchGrokResetTokens` / `consumeGrokResetToken`；registry reset 钩子 `spendGrokResetCard`；429 限流窗口 `noteGrokRateLimit` / `grokRateLimitRows`。
套餐：[`../plan.ts`](../plan.ts) + `GROK_TIER_NAMES`（JWT 数字档 0–7）。

## 登录

默认 **设备码**，浏览器不回 127.0.0.1。PKCE loopback `127.0.0.1:56121` `/callback` 是后备。

| 项 | 值 |
|---|---|
| `client_id` | `b1a00492-073a-47ea-816f-4c329264a828` |
| discovery | `https://auth.x.ai/.well-known/openid-configuration`（主机必须是 `x.ai` / `*.x.ai`） |
| UA | `grok-cli/0.2.93` |
| scope | `openid profile email offline_access grok-cli:access api:access` |

入口：`grokDiscovery` → `grokDeviceSpec` / `grokFlow` → `completeGrokDevice` / `exchangeGrokCode` → `grokSession`。
导入：[`../import-auth.ts`](../import-auth.ts) `importGrokAuth` 扫 Grok CLI 凭证路径。

## 对话

DSH `api: openai-responses`。上游就是 xAI `api.x.ai/v1/responses`。不要改 Completions / Anthropic。

```text
DSH  →  本机 Responses 代理  →  POST https://api.x.ai/v1/responses
```

头：`grokUpstreamHeaders` + grok-build `GrokRequestHeaders`（`x-grok-conv-id`、`x-grok-session-id`、`x-grok-req-id`、`x-grok-model-override`；重试再加 `x-grok-transient-retry`）。**不要**抄 Codex 的 `session-id` / `x-client-request-id`：xAI 忽略它们，缓存会打到错误分片。

行在 [`src/catalog/models.json`](../../catalog/models.json) 的 `"grok"` 键；行格式、来源与 `npm run models` 更新流程见 [`docs/models.md`](../../../docs/models.md)。本节只记本家的取舍与出处。

最近核对：2026-09-30，`GET cli-chat-proxy.grok.com/v1/models`（grok CLI 自己的列表，`~/.grok/models_cache.json` 同源）；本次 4.5 / 4.6 的 `context_window` 也降到 256K，与 4.7 同口径（2026-09-29 只改了 4.7，4.5 / 4.6 当时源里还报 500K）。

来源字段：`context_window` → `contextWindow`，`reasoning_efforts[].value` → `reasoningEfforts`（思考关不掉，没有 `off`）。`GET api.x.ai/v1/models` 是 API 目录，不是订阅 picker，只作对照。输入窗取**非 Max Mode 基础窗**，不取缓存里的 Max Mode 变体窗口（与 Cursor 家族同一归因，见 `src/oauth/cursor/README.md`；经过见 [`docs/error.md`](../../../docs/error.md) 2026-09-29 Grok 4.7 输入窗口）。列表不带输出上限，`maxTokens` 沿用行值。`grok-4.7-build-fast` 是真后端变体（2× 价），不是 `-fast` 后缀；`grok-4.7-fast` 上游 404。Grok 4 已下架。

## 额度

两条源，缺一不可：

1. `GET https://cli-chat-proxy.grok.com/v1/billing?format=credits` + `/v1/user?include=subscription` → `parseGrokBilling`（周期用量、预付、产品行、档位）。
2. `POST https://grok.com/grok_api_v2.GrokBuildBilling/GetGrokCreditsConfig`（gRPC-web）→ `decodeGrokCreditsFrame`。统一计费的 SuperGrok / X Premium+ 在 JSON billing 里经常没有 `creditUsagePercent`，这个帧才有周池。周期在 nested field 8 `{type, start, end}`（field 1 不带 usage）；proto3 省略零值 = 0% 已用（与 grok.com 网页一致）。

第三条只作旁注、不参与「缺一不可」：chat 429 限流窗口（`passthrough.ts` 每次响应记 `noteGrokRateLimit`，2xx 清除；`grokRateLimitResetAt` 解析 Retry-After 秒/HTTP 日期与任意 `*ratelimit*reset*` 头的 epoch ms/epoch s/相对秒，无名持 5 分钟；`fetchGrokQuota` 末尾以一行 `rate-limit` 渲染）。billing 读数对限流一无所知——0% 已用也可能每个请求都 429（magpie `index.mjs:690-697`）。

重置卡（「重置卡」，类 Codex reset credits / GLM 重置卡）：grok CLI 里没有（1.0.44 二进制搜不到这组 RPC），挂在 grok.com 网页计费服务，同一把 CLI bearer + gRPC-web 头（`grokResetHeaders`）即可。

- 列表：`POST grok.com/prod_mc_billing.ConsumerUiSvc/GetRemainingResets`，空请求帧。回 repeated field 10 = token；token 内 10 = id（`restok_…`）、20 = 发放、30 = 过期（Timestamp）——出处 stablyai/orca #18116 的真实抓包 hex；OmniRoute dd263fe 注释写 1/2/3 裸秒，两种形都解。空 DATA 帧 + `grpc-status 0` = 真 0 张；非 0 状态 / HTTP 失败 = 读失败，`resetCredits` 不写，保留上次卡数。
- 兑换：`POST …/RedeemReset`，`ConsumerRedeemResetReq.token_id` = field 10。`0` 成功；`9` 且含 "already" = 这张已兑（丢响应后的重试，按成功算）；其余 `9` 或 `3` "token_id" = 没这张卡（`GrokResetRejected`）。
- 一张卡清周池（和 Codex 一样只有「每周窗口」一行）。
- token id 持有即可兑换，**不出宿主**：公开卡 id 是 `grokResetCardId`（sha256 前 16 位），兑换时重读列表按哈希找回 token，列表里没有就拒绝，不会换一张别的卡花掉。
- 活测 2026-09-29（desktop 两个 SuperGrok 账号）：列表 200 + `grpc-status 0` + 空帧 = 0 张；过期 token 回 header `grpc-status 7`（凭据无效）。兑换未活测（无卡）。

金额字段全部是 `{ val: <cents> }`（CodexBar `x.ai/billing` 文档口径）：`monthlyLimit` + `usage.includedUsed/totalUsed` = 月度包含池，`onDemandCap`/`onDemandUsed` = 按需消费封顶，`prepaidBalance` = 预付余额 —— 统一计费账号（SuperGrok / X Premium+）这些字段全是 `{val:0}` 或不发，**只有裸百分比**；非统一计费账号才有美元数。`{val}` 形才按美分转 USD（`unit:'usd'`），裸数字照旧当无单位 credits。周期 type 映射：MONTHLY→cycle、DAILY→primary(24h)、其余→weekly。`hasGrokCodeAccess` 渲染成卡片上的 `Grok Code` 标。`x.ai/billing` JSON-RPC 只接在 TUI 里（agent stdio 1.0.41 仍 -32601），别当数据源加。gRPC 帧 nested field 7 = `{type, f32}` 语义未考（疑产品/周期子项），fields 11/13 是 flag —— 不解不画。

档位：JWT / user `subscription_tier` 数字 → `GROK_TIER_NAMES`（Free / SuperGrok / X Basic / X Premium / X Premium+ / SuperGrok Heavy / Lite / Plus）。`SuperGrokPro` 显示 **SuperGrok Heavy**。

## 缓存

对照 grok-build（`xai-org/grok-build` Responses）：分片粘滞 **和** 字节前缀都要。

| 步骤 | 函数 | 做什么 |
|---|---|---|
| 1 | `grokConversationId` | 清洗 DSH `prompt_cache_key` / `session_id`；都空则 `dsh-grok` |
| 2 | `pinGrokSystemPrefix` | 每个 conv id 钉住第一次的 leading system/developer；后续改写只取**变化区域**（最长公共前后缀夹出、外扩到整行）当 extra，禁止整块重挂。共享不到较短文本一半 = 另一个 prompt（DSH 标题请求与主对话同 key），重钉原样发，不挂后缀 |
| 3 | `normalizeGrokResponsesBody` | 钉住的前缀放 `input` 最前（`role: system`）；DSH 多出来的快照挂 **input 后缀** developer。不抬成顶层 `instructions`（grok-build 发 `instructions: null`） |
| 4 | `applyGrokCache` | body `prompt_cache_key` = conv id；删 `session_id` / `prompt_cache_retention` |
| 5 | `grokAffinityHeaders` | `x-grok-conv-id` = `x-grok-session-id` = conv id；每请求一个 `x-grok-req-id`；`x-grok-model-override`；重试 `x-grok-transient-retry` |

前缀 LRU 仍只保留 64 个最近使用的 conv id；状态的兼容版本键只属 Grok，不落盘，也不与其他家族共享。兼容的模块图热重载复用它，标题请求的不同 prompt 仍会重钉，显式 reset 对旧／新模块引用都生效。

`grok-cache.jsonl` 放在插件私有 dataDir，0600、约 1 MB 轮转，只保留一份 `.1`；写入用不跟随链接的文件描述符，校验私有父目录／属主并通过描述符收紧权限。会话键、账号、请求 id、模型／工具／输入内容仅作进程随机密钥 HMAC 指纹；明文模型只允许目录中的 id。

诊断基线最多 64 个 profile／账号／会话／模型组合、每个最多 512 个输入条目指纹，待写日志最多 128 行。重试对每个账号只建立一次逻辑请求基线，无 id 的共享 fallback 不建立跨请求基线。复用已序列化的 normalized wire bytes，不为日志重复 stringify 整个请求；请求诊断工作预算 2 MiB，超预算只对开头字节与总长度作明确标记的样本指纹（`requestFingerprintTruncated`／`diagnosticWorkTruncated`），前缀／共享字节数据为 null，不冒充完整证据。

观察整个上游字节流，包含提交输出后的终止 usage；支持 CR／LF／CRLF 分片边界和 JSON 非流，每帧／JSON 保留至多 2 MiB。缺少或无效的 `cached_tokens` 记 `null`，显式零才记 `0`；超限帧或写盘失败不影响对话。公共前缀**字节数**仅是完整输入条目序列化字节数的和，不含数组分隔符，也不是缓存 token 数或命中率。

分析器的 < 10% 复用 `affinity_miss` 是低缓存启发式标签，不是上游分片证据；还需对照钉住原因、前缀指纹、压缩标记和停顿。不要把 GLM 的 576 token 残骸当成同一信号。

健康长会话：加权命中 ≥ 80%，**零** affinity miss。压缩 / 计划重建造成的 0 命中不是分片 miss。

## 不要

- 不要给 Grok 写 Codex `session-id` / `x-client-request-id`。
- 不要把 DSH 每步 snapshot 留在 `input` 最前（grok-build：下一次必须 byte-for-byte 重放前缀）。
- 不要把 Grok 4 加回目录。
- 不要把 `grok-4.7-build-fast` 当 Codex `-fast` 后缀剥掉（会变成不存在的 `grok-4.7-build`）；不要发明 `grok-4.7-fast`（上游 404）。
- 不要只用 billing JSON 填额度条（Heavy / Premium+ 会空）。
- 不要把 `api` 改成 Completions / Anthropic。

## 归因

一线：[xai-org/grok-build](https://github.com/xai-org/grok-build) 的 Responses 路径；UA 钉 `grok-cli/0.2.93`。导入旁路：[NousResearch/hermes-agent](https://github.com/NousResearch/hermes-agent) 的 `~/.hermes/auth.json`。

| 抄 | 出处 | 本 hop |
|---|---|---|
| `x-grok-conv-id` / `x-grok-session-id` / `x-grok-req-id` / `x-grok-model-override`，重试加 `x-grok-transient-retry` | grok-build `GrokRequestHeaders` | `grokAffinityHeaders` |
| 模型页价格徽标（USD / 1M） | models.dev `xai`（xAI API 标价）；`grok-4.7-build-fast` 源里没有，按基础行 × 2 派生（乘数出处：上游 picker 对 Fast 的自述 "Fast variant. 2x the price."，见 [`docs/error.md`](../../../docs/error.md) 2026-09-22） | `src/catalog/rates.json`，`npm run rates` 写入（见 [docs/models.md](../../../docs/models.md) 费率表） |
| `instructions: null`，前缀 byte-for-byte 重放 | grok-build | `normalizeGrokResponsesBody` 不抬顶层 `instructions` |
| 设备码默认 | grok-build | [`device-flow.ts`](device-flow.ts) |
| 目录（窗口、efforts、真 Fast id） | `GET cli-chat-proxy.grok.com/v1/models` | `GROK_MODELS`；真 Fast id 由 `normalizeGrokResponsesBody` 原样透传 |
| 重置卡 `ConsumerUiSvc/GetRemainingResets` / `RedeemReset`（grok.com 网页，CLI 没有） | [stablyai/orca#18116](https://github.com/stablyai/orca/pull/18116) 抓包 + [OmniRoute dd263fe](https://github.com/diegosouzapw/OmniRoute/commit/dd263fed66da50e50e706195f1734e665d61e268) 状态映射 | [`reset-frame.ts`](reset-frame.ts) + `quota.ts` `fetchGrokResetTokens` / `consumeGrokResetToken` |

**不要发明：** 自造的 grok-shell UA——保持 `grok-cli/0.2.93`。Codex 头与 Fast id 的禁令见「不要」。

## magpie 上游对照（2026-10-17）

对照快照：`.local/upstream-magpie` @ `0b58032`，`packages/grok`（`@magpie-community/opencode-grok-auth` 0.1.15）。逐项核对结论与取舍：

| 上游事实 | 出处 | 本仓取舍 |
|---|---|---|
| 登录/刷新全部代办给 grok CLI 二进制：`grok login --device-auth` 起设备码，刷新在该 home 跑 `grok models` 读回 `auth.json` | 上游 `index.mjs:441-482`（login）、`index.mjs:144-167`（renew/token）、README「Sign in」 | 不跟。自研 OIDC 设备码与上游同 client_id、同 `https://auth.x.ai/oauth2/device/code`（上游 `login.test.mjs:52` 报错文本印证该端点仍是 CLI 的设备码端点）；不引入「必须装 CLI」的依赖。`auth.json` 的 scope 键 `https://auth.x.ai::<client_id>`（上游 `index.mjs:21`、`import.test.mjs:11`）本仓 `import.ts` 已按 `xai::` / client_id 命中 |
| chat 走 `https://cli-chat-proxy.grok.com/v1/responses` | 上游 `index.mjs:18`（`BASE`）、`usage.test.mjs:123` / `signin.test.mjs:28`（POST 路径） | 不跟。本仓钉 `api.x.ai/v1/responses`（grok-build 一线归因 + 2026-09-28 真实流修复记录）；两 endpoint 都活过，换道需活测 A/B，见 openQuestions |
| 签名指纹：UA `grok-shell/<v> (<os>; <arch>)` + `x-grok-client-version` / `x-grok-client-identifier: grok-shell` / `x-grok-client-mode: headless`，钉版 **1.0.41**（装了更新的 CLI 则用更新的） | 上游 `index.mjs:19`（`CLIENT_VERSION`）、`index.mjs:169-203`（clientVersion/sign）、README「Requests」 | 不跟（本 README「不要」明令保持 `grok-cli/0.2.93`；2026-09-29 活测确认版本头无门槛，见 `docs/error.md:502-506`）。上游已从 0.2.x 走到 1.0.41+（`login.test.mjs:49` 注释提到 1.0.46），升级钉版属 `docs/oauth.md` 总表决定 |
| 亲和头只发 `x-grok-conv-id`（= body `prompt_cache_key`）+ `x-grok-model-override`，无 `x-grok-session-id` / `x-grok-req-id` / `x-grok-transient-retry` | 上游 `index.mjs:822-831` | 不跟。全套 sticky 头归因 grok-build `GrokRequestHeaders`（2026-09-04 缓存命中率修复的发端）；上游少发不是「发错」的证据 |
| 模型目录动态拉 `GET /v1/models`，只收 `api_backend === "responses"`；`context_windows` 的非默认窗做成 `grok-4.7@500k` 挑选行，请求时发 `x-grok-context-window: 500000`、body 用裸 id | 上游 `index.mjs:391-397`（过滤）、`index.mjs:400-435`（windowsOf/modelOf）、`index.mjs:822-830`（请求拆分）、`models.test.mjs:20-61` | `api_backend` 过滤已补进 `scripts/models.ts` 探针（2026-10-17，照上游同判跳过）；`context_windows` 在探查报告带出供人工核对。窗口变体行不收（2026-09-29 裁定：`contextWindow` 取非 Max Mode 基础窗，不暴露 Max Mode 变体，与 Cursor 同归因） |
| 兜底 efforts `low/medium/high/xhigh` | 上游 `index.mjs:364`（`DEFAULT_EFFORTS`） | 与本仓 `GROK_REASONING_47` 一致，无需动 |
| 额度只读 billing JSON：`creditUsagePercent`、`currentPeriod{type,end}`（type 带 `USAGE_PERIOD_TYPE_` 前缀）、`onDemandCap/onDemandUsed`（`{val}` 美分）、`billingPeriodEnd` | 上游 `index.mjs:654-686`、`usage.test.mjs:32-68` | 字段 `parseGrokBilling` 全覆盖且是超集（本仓另读 gRPC 周池与重置卡）；无缺口 |
| 新增 429「Rate limit」窗口：Retry-After（秒或 HTTP 日期）或任意 `*ratelimit*reset*` 头（epoch ms / epoch s / 相对秒）定恢复点，都没命名则持 5 分钟或直到请求成功 | 上游 `index.mjs:697-737`、`usage.test.mjs:116-166` | 已落（2026-10-17）：`passthrough.ts` 观测 chat 响应（`noteGrokRateLimit`，按账号），`grok/quota.ts` `grokRateLimitResetAt` / `grokRateLimitRows` 照上游解析并在 `fetchGrokQuota` 尾行渲染（行形状无 `aside` 字段，不发明，与 mimo 同例）；仅进程内，重启即忘 |
| wire 侧丢后端不收的 tool 类型（闭集 `function/web_search/x_search/image_generation/collections_search/file_search/code_execution/code_interpreter/mcp/shell/tool_search`）、`external_web_access`、指名已删类型的 `tool_choice`、reasoning `content: null`；Codex `agent_message` 转 user 消息 | 上游 `index.mjs:32-34`（TOOLS）、`index.mjs:297-357`（rewrite）、README「Requests」 | 不跟。该拒绝行为是 **cli-chat-proxy** 后端的（本仓 chat 走 api.x.ai，无本地 400 证据）；DSH 也不产 `agent_message`。若日后换道 cli-chat-proxy 一并抄 |
| 新增 CPA 账号 JSON 导入：`~/.cli-proxy-api/xai-<email>.json`，校验 `iss === https://auth.x.ai` 且 `aud` 含本 client_id，写进私有 home；CPA 与 Grok Build 轮换同一 refresh token | 上游 `index.mjs:524-594`、`import.test.mjs` | 暂不接（需共享导入 UI 管线；「停用 CPA 再导入」的语义要维护者拍板），见 openQuestions |

跨家族对照总表见 [`docs/oauth.md`](../../../docs/oauth.md)。
