/**
 * xAI Grok prompt cache — grok-build Responses path.
 *
 * Sticky routing is the grok-build header set (`x-grok-conv-id` +
 * `x-grok-session-id` + `x-grok-req-id` + `x-grok-model-override`).
 * `prompt_cache_key` on the body defaults to the same conversation id
 * and overrides conv-id for routing. Codex `session-id` /
 * `x-client-request-id` are ignored on this backend and must not be copied.
 *
 * Prefix cache is also real: grok-build replays conversation items byte
 * for byte. DSH snapshots that would rewrite the leading system/developer
 * are pinned per conv id; extras park at the input suffix.
 *
 * Low reuse is a diagnostic signal, not proof of the shard or prefix
 * responsible; correlate request fingerprints and observed usage.
 */

import { randomUUID } from 'node:crypto'

/** When DSH sends neither session_id nor prompt_cache_key, still pin a constant. */
export const GROK_STABLE_SESSION = 'dsh-grok'

// Compatible module graphs share this Grok-only, process-local state. A new
// schema must use a new version key; nothing is serialized or shared with a
// different family. Explicit reset still clears every live module reference.
const PIN_STATE_KEY = Symbol.for('dsh-plugin-oauth-subs.grok.system-pins.v1')
type GrokPinState = { pins: Map<string, string>, generation: number }
const pinRoot: typeof globalThis & { [PIN_STATE_KEY]?: GrokPinState } = globalThis
const pinState = pinRoot[PIN_STATE_KEY] ??= {
  pins: new Map(), generation: 0,
}
const GENERATION = ++pinState.generation
const SYSTEM_PINS = pinState.pins
const SYSTEM_PIN_CAP = 64

export interface GrokPinDecision {
  action: 'empty' | 'unkeyed' | 'new' | 'reuse' | 'append' | 'changed' | 'repin'
  generation: number
  evicted: boolean
}

export function grokCacheSessionId(key) {
  if (typeof key !== 'string') return undefined
  const cleaned = key.trim().replace(/[^A-Za-z0-9._:-]/g, '-')
  if (!cleaned) return undefined
  return cleaned.slice(0, 64)
}

export function resetGrokSystemPins() {
  SYSTEM_PINS.clear()
}

/**
 * Read a pin and mark it most recently used. Map order is recency, so the
 * cap drops the idlest conversation, never one that is still sending steps.
 */
function usePin(key) {
  const pin = SYSTEM_PINS.get(key)
  if (pin === undefined) return undefined
  SYSTEM_PINS.delete(key)
  SYSTEM_PINS.set(key, pin)
  return pin
}

/**
 * Pin the first leading system/developer blob per conversation. Later text
 * that DSH rewrites is `extra` so request.ts can park it after the
 * conversation, not at the front. Only the changed region is parked: a
 * prepended snapshot or an in-place edit must not re-park the whole blob,
 * which would leave its untouched front permanently uncached.
 */
export function pinGrokSystemPrefix(conversationId, systemText, observe?: (decision: GrokPinDecision) => void) {
  const finish = (pinned: string, extra: string, action: GrokPinDecision['action'], evicted = false) => {
    observe?.({ action, generation: GENERATION, evicted })
    return { pinned, extra }
  }
  const text = typeof systemText === 'string' ? systemText : ''
  if (!text) return finish('', '', 'empty')
  if (!conversationId || conversationId === GROK_STABLE_SESSION) return finish(text, '', 'unkeyed')
  const existing = usePin(conversationId)
  if (existing === undefined) {
    const evicted = SYSTEM_PINS.size >= SYSTEM_PIN_CAP
    if (evicted) SYSTEM_PINS.delete(SYSTEM_PINS.keys().next().value!)
    SYSTEM_PINS.set(conversationId, text)
    return finish(text, '', 'new', evicted)
  }
  if (existing === text || existing.startsWith(text)) return finish(existing, '', 'reuse')
  if (text.startsWith(existing)) {
    return finish(existing, text.slice(existing.length).replace(/^\n+/, '').trim(), 'append')
  }
  const extra = changedRegion(existing, text)
  if (extra !== null) return finish(existing, extra, 'changed')
  // A different prompt on the same conv id (DSH's session-title request
  // shares the chat's prompt_cache_key) is its own request, not a rewrite.
  SYSTEM_PINS.set(conversationId, text)
  return finish(text, '', 'repin')
}

/** The smallest whole-line slice of `text` that differs from `existing`:
 * strip the longest common prefix and suffix (which never overlap), then
 * widen the change outward to the enclosing line boundaries so the parked
 * text reads as complete lines. Appending keeps the old tail-only park; a
 * prepended snapshot or an in-place edit parks just the changed region
 * instead of the whole blob, keeping its untouched front cacheable.
 * `null` when under half of the shorter text is shared — a different
 * prompt, not an edit. */
function changedRegion(existing, text) {
  const max = Math.min(existing.length, text.length)
  let prefix = 0
  while (prefix < max && existing.charCodeAt(prefix) === text.charCodeAt(prefix)) prefix += 1
  let suffix = 0
  while (suffix < max - prefix
    && existing.charCodeAt(existing.length - 1 - suffix) === text.charCodeAt(text.length - 1 - suffix)) suffix += 1
  if ((prefix + suffix) * 2 < max) return null
  const lineStart = text.lastIndexOf('\n', prefix - 1)
  const start = lineStart < 0 ? 0 : lineStart + 1
  const lineEnd = text.indexOf('\n', text.length - suffix)
  const end = lineEnd < 0 ? text.length : lineEnd
  return text.slice(start, end).replace(/^\n+/, '').replace(/\n+$/, '').trim()
}

export function grokConversationId(payload: any = {}) {
  return grokCacheSessionId(payload.prompt_cache_key)
    || grokCacheSessionId(payload.session_id)
    || GROK_STABLE_SESSION
}

/**
 * grok-build `GrokRequestHeaders`. `reqId` is one UUID per DSH request so
 * retries keep the same id; `retryAttempt` becomes `x-grok-transient-retry`.
 */
export function grokAffinityHeaders(cacheSessionId, extra: any = {}) {
  if (typeof cacheSessionId !== 'string' || cacheSessionId.length === 0) return {}
  const headers = {
    'x-grok-conv-id': cacheSessionId,
    'x-grok-session-id': cacheSessionId,
    'x-grok-req-id': typeof extra.reqId === 'string' && extra.reqId ? extra.reqId : randomUUID(),
  }
  if (typeof extra.model === 'string' && extra.model.trim()) {
    headers['x-grok-model-override'] = extra.model.trim()
  }
  if (Number(extra.retryAttempt) > 0) {
    headers['x-grok-transient-retry'] = String(extra.retryAttempt)
  }
  return headers
}

export function applyGrokCache(payload) {
  const next = { ...payload }
  const cacheSessionId = grokConversationId(next)
  next.prompt_cache_key = cacheSessionId
  delete next.session_id
  delete next.prompt_cache_retention
  delete next.prompt_cache_options
  return { payload: next, cacheSessionId }
}
