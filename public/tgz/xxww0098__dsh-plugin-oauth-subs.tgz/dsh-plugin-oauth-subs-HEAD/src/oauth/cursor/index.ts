/**
 * Cursor subscription family. Auth is PKCE loginDeepControl + poll, or
 * local CLI Keychain / IDE state.vscdb reuse. Chat is Connect/protobuf
 * AgentService/Run — not OpenAI REST. Fingerprint is the official CLI
 * (`cli-2026.09.23-86fc751`, magpie packages/cursor VERSION_FALLBACK —
 * the version the CLI names when no install does; pi-cursor main still
 * pins 07.23), not
 * the desktop IDE and not `@cursor/sdk` `client-type: sdk` (that path is
 * API-key Agent.create, not this OAuth hop).
 */

import { createHash, randomBytes, randomUUID } from 'node:crypto'
import { decodeJwtPayload } from '../../utils/jwt.js'
import { OAuthEndpointError, oauthError } from '../errors.js'
import { outboundFetch } from '../../utils/outbound.js'
import { catalogRows } from '../../catalog/index.js'

export const CURSOR_LOGIN_URL = 'https://cursor.com/loginDeepControl'
export const CURSOR_POLL_URL = 'https://api2.cursor.sh/auth/poll'
export const CURSOR_REFRESH_URL = 'https://api2.cursor.sh/auth/exchange_user_api_key'
export const CURSOR_AGENT_URL = 'https://agentn.us.api5.cursor.sh'
export const CURSOR_API2_URL = 'https://api2.cursor.sh'
export const CURSOR_USAGE_PATH = '/aiserver.v1.DashboardService/GetCurrentPeriodUsage'
export const CURSOR_USAGE_URL = `${CURSOR_API2_URL}${CURSOR_USAGE_PATH}`
export const CURSOR_HARD_LIMIT_PATH = '/aiserver.v1.DashboardService/GetHardLimit'
export const CURSOR_HARD_LIMIT_URL = `${CURSOR_API2_URL}${CURSOR_HARD_LIMIT_PATH}`
export const CURSOR_STRIPE_PROFILE_URL = `${CURSOR_API2_URL}/auth/full_stripe_profile`
export const CURSOR_GET_EMAIL_PATH = '/aiserver.v1.AuthService/GetEmail'
export const CURSOR_GET_EMAIL_URL = `${CURSOR_API2_URL}${CURSOR_GET_EMAIL_PATH}`
export const CURSOR_GET_ME_PATH = '/aiserver.v1.DashboardService/GetMe'
export const CURSOR_GET_ME_URL = `${CURSOR_API2_URL}${CURSOR_GET_ME_PATH}`
export const CURSOR_RUN_PATH = '/agent.v1.AgentService/Run'
export const CURSOR_MODELS_PATH = '/agent.v1.AgentService/GetUsableModels'
export const CURSOR_AVAILABLE_MODELS_PATH = '/aiserver.v1.AiService/AvailableModels'
export const CURSOR_CLIENT_VERSION = 'cli-2026.09.23-86fc751'
export const CURSOR_CLIENT_TYPE = 'cli'
export const CURSOR_PREEMPT_MS = 5 * 60_000
export const CURSOR_POLL_MAX_ATTEMPTS = 150
export const CURSOR_POLL_BASE_DELAY_MS = 1000
export const CURSOR_POLL_MAX_DELAY_MS = 10_000
export const CURSOR_POLL_BACKOFF = 1.2

export const CURSOR_PLAN_NAMES = Object.freeze({
  free: 'Free',
  hobby: 'Hobby',
  pro: 'Pro',
  proplus: 'Pro+',
  'pro+': 'Pro+',
  pro_plus: 'Pro+',
  business: 'Business',
  team: 'Team',
  ultra: 'Ultra',
  enterprise: 'Enterprise',
})

export const CURSOR_REASONING = Object.freeze({
  off: 'none',
  low: 'low',
  medium: 'medium',
  high: 'high',
  xhigh: 'extra-high',
})

/**
 * Vendor effort value → DSH reasoningEfforts key. Cursor's registry spells
 * the same level differently per family ('none'/'extra-high' on GPT-5.5,
 * 'xhigh' on Grok 4.7, 'max' on Kimi/GLM), so picker rows are built from the
 * family's own advertised values, not one shared map.
 */
export function cursorEffortKey(value) {
  const key = String(value ?? '').trim()
  if (key === 'none') return 'off'
  if (key === 'extra-high') return 'xhigh'
  return ['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'].includes(key) ? key : undefined
}

export function cursorContextValueTokens(value) {
  const text = String(value ?? '').trim().toLowerCase()
  const match = text.match(/^(\d+)([km])$/)
  return match ? Number(match[1]) * (match[2] === 'm' ? 1_000_000 : 1_000) : undefined
}

/**
 * RequestedModel parameter style per picker family, from live
 * AvailableModels variants (2026-09-26 probe, Pro account): the registry
 * validates Run parameters verbatim — a wrong id OR value fails the whole
 * Run with 'Invalid parameters for registry model'. effortParam is the
 * parameter id that family takes ('reasoning' / 'effort' / 'reasoning_effort'),
 * efforts maps DSH key → vendor wire value, contexts lists the family's
 * advertised context values, fast whether a fast variant exists. Families
 * absent here keep the picker effort list but send no effort parameter —
 * guessing an id 400s, omitting falls back to the registry default.
 */
const CURSOR_CLAUDE_EFFORTS = { low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh', max: 'max' }
const CURSOR_GPT56_EFFORTS = { off: 'none', ...CURSOR_CLAUDE_EFFORTS }
const CURSOR_MUSE_EFFORTS = { minimal: 'minimal', ...CURSOR_CLAUDE_EFFORTS }

export const CURSOR_PARAM_STYLES = Object.freeze({
  'grok-4.7': {
    effortParam: 'reasoning_effort',
    efforts: { low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh' },
    contexts: ['256k'],
    fast: true,
  },
  'grok-4.6': {
    effortParam: 'effort',
    efforts: { low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh' },
    contexts: [],
    fast: true,
  },
  'grok-4.5': {
    effortParam: 'effort',
    efforts: { low: 'low', medium: 'medium', high: 'high' },
    contexts: [],
    fast: true,
  },
  'gpt-5.5': {
    effortParam: 'reasoning',
    efforts: { off: 'none', low: 'low', medium: 'medium', high: 'high', xhigh: 'extra-high' },
    contexts: ['272k', '1m'],
    fast: true,
  },
  'claude-fable-5-1': { effortParam: 'effort', efforts: CURSOR_CLAUDE_EFFORTS, contexts: ['300k'], fast: false },
  'claude-opus-5-5': { effortParam: 'effort', efforts: CURSOR_CLAUDE_EFFORTS, contexts: ['300k'], fast: true },
  'claude-opus-5': { effortParam: 'effort', efforts: CURSOR_CLAUDE_EFFORTS, contexts: ['300k'], fast: true },
  'claude-sonnet-5': { effortParam: 'effort', efforts: CURSOR_CLAUDE_EFFORTS, contexts: ['300k'], fast: false },
  // docs 2026-09-28 /docs/models/claude-sonnet-5-5: effort low–max, 200k window
  // (1M Max Mode). No live param probe yet — contexts stays empty so no
  // unadvertised context value is ever sent.
  'claude-sonnet-5-5': { effortParam: 'effort', efforts: CURSOR_CLAUDE_EFFORTS, contexts: [], fast: false },
  'gemini-3.8-flash': { effortParam: 'reasoning_effort', efforts: { low: 'low', medium: 'medium', high: 'high' }, contexts: [], fast: false },
  'muse-spark-1.3': { effortParam: 'effort', efforts: CURSOR_MUSE_EFFORTS, contexts: ['300k'], fast: false },
  'gpt-5.6-sol': { effortParam: 'reasoning', efforts: CURSOR_GPT56_EFFORTS, contexts: ['272k'], fast: true },
  'gpt-5.6-terra': { effortParam: 'reasoning', efforts: CURSOR_GPT56_EFFORTS, contexts: ['272k'], fast: true },
  'gpt-5.6-luna': { effortParam: 'reasoning', efforts: CURSOR_GPT56_EFFORTS, contexts: ['272k'], fast: true },
  'kimi-k3': {
    effortParam: 'reasoning',
    efforts: { low: 'low', high: 'high', max: 'max' },
    contexts: [],
    fast: false,
  },
  'glm-5.2': {
    effortParam: 'reasoning',
    efforts: { high: 'high', max: 'max' },
    contexts: [],
    fast: false,
  },
  'composer-2.5': { effortParam: undefined, efforts: {}, contexts: [], fast: true },
  default: { effortParam: undefined, efforts: {}, contexts: [], fast: false },
})

/** Picker reasoningEfforts for one family style: vendor values keyed back to DSH levels. */
export function cursorStyleReasoningEfforts(style) {
  if (!style || !style.effortParam) return false
  const efforts = {}
  for (const [key, wire] of Object.entries(style.efforts ?? {})) efforts[key] = wire
  return Object.keys(efforts).length ? efforts : false
}

/** Static fallback aligned to cursor.com/docs/models-and-pricing and 2026-09-26 AvailableModels. Live GetUsableModels may add Fast / extra families (Auto is kept out). reasoningEfforts come from the family's CURSOR_PARAM_STYLES entry — the wire values the registry actually takes. Rows live in `src/catalog/models.json` under `"cursor"` (values snapshotted from those styles). */
export const CURSOR_MODELS = catalogRows('cursor')

export const CURSOR_SOURCES = Object.freeze(['pkce', 'cli_keychain', 'ide_vscdb', 'env'])

export function cursorSourceLabel(source, locale = 'en') {
  const key = String(source ?? '').trim()
  if (key === 'cli_keychain') return 'CLI'
  if (key === 'ide_vscdb') return 'IDE'
  if (key === 'env') return 'env'
  if (key === 'pkce') return 'PKCE'
  return locale === 'zh' ? undefined : undefined
}

function trimmed(value) {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined
}

export function cursorClientVersion() {
  return trimmed(process.env.PI_CURSOR_CLIENT_VERSION) || CURSOR_CLIENT_VERSION
}

export function cursorAgentUrl() {
  return trimmed(process.env.PI_CURSOR_AGENT_URL)
    || trimmed(process.env.CURSOR_AGENT_URL)
    || CURSOR_AGENT_URL
}

let cursorProxyOverride

/** Plugin config `cursorProxy` wins over env; empty re-enables env fallback. */
export function configureCursorUpstreamProxy(value) {
  cursorProxyOverride = trimmed(value)
}

/**
 * Upstream egress for the Cursor h2 hop (Run + discovery RPCs). Anthropic /
 * OpenAI / Gemini refuse requests that leave from unsupported regions, so a
 * supported-region proxy is the only way to run those families — same role
 * as the IDE's `http.proxy`. Auth poll, refresh, and quota stay direct.
 */
export function cursorUpstreamProxy() {
  return cursorProxyOverride
    ?? trimmed(process.env.PI_CURSOR_PROXY)
    ?? trimmed(process.env.CURSOR_PROXY)
    ?? undefined
}

export function cursorTokenExpiry(token, now = Date.now()) {
  const payload = decodeJwtPayload(token)
  if (payload && typeof payload.exp === 'number' && Number.isFinite(payload.exp)) {
    return payload.exp * 1000 - CURSOR_PREEMPT_MS
  }
  return now + 60 * 60_000
}

/** JWT `sub` / WorkOS / Auth0 / the literal `cursor` — vault keys only, never a card title. */
export function isCursorOpaqueAccount(value) {
  if (typeof value !== 'string' || !value.trim()) return true
  const raw = value.trim()
  if (raw.toLowerCase() === 'cursor') return true
  if (/^cursor-[A-Za-z0-9_-]{4,}$/i.test(raw)) return true
  if (/^[A-Za-z0-9._-]+\|[A-Za-z0-9._-]+$/.test(raw) && !raw.includes('@')) return true
  if (/^user_[A-Za-z0-9]{16,}$/i.test(raw)) return true
  return false
}

export function pickCursorHumanAccount(...candidates) {
  for (const value of candidates) {
    const next = trimmed(value)
    if (!next || isCursorOpaqueAccount(next)) continue
    return next
  }
  return undefined
}

export function cursorAccountFromToken(token) {
  const payload = decodeJwtPayload(token)
  if (!payload) return undefined
  return pickCursorHumanAccount(payload.email, payload.preferred_username)
}

function cursorVaultAccountFromToken(token) {
  const payload = decodeJwtPayload(token)
  return payload ? trimmed(payload.sub) : undefined
}

export function displayCursorAccount(session) {
  return pickCursorHumanAccount(
    session?.account,
    session?.cachedEmail,
    cursorAccountFromToken(session?.accessToken),
  )
}

/** GetEmail `{ email }` or GetMe `{ email, firstName, lastName }`. Email wins. */
export function cursorNameFromProfile(value) {
  if (!value || typeof value !== 'object') return undefined
  const email = pickCursorHumanAccount(value.email)
  if (email) return email
  const first = trimmed(value.firstName)
  const last = trimmed(value.lastName)
  const combined = [first, last].filter(Boolean).join(' ')
  return pickCursorHumanAccount(combined)
}

export function cursorMembershipFromStripe(value) {
  if (!value || typeof value !== 'object') return undefined
  const individual = trimmed(value.individualMembershipType)
  const membership = trimmed(value.membershipType)
  return individual || membership
}

export function cursorAccessStillValid(token, now = Date.now()) {
  if (typeof token !== 'string' || !token.trim()) return false
  return now < cursorTokenExpiry(token, now)
}

export function createCursorPkce() {
  const verifier = randomBytes(96).toString('base64url')
  const challenge = createHash('sha256').update(verifier).digest('base64url')
  return { verifier, challenge }
}

export function cursorLoginParams({ verifier, challenge, uuid }: any = {}) {
  const pkce = verifier && challenge ? { verifier, challenge } : createCursorPkce()
  const id = trimmed(uuid) || randomUUID()
  const params = new URLSearchParams({
    challenge: pkce.challenge,
    uuid: id,
    mode: 'login',
    redirectTarget: 'cli',
  })
  return {
    verifier: pkce.verifier,
    challenge: pkce.challenge,
    uuid: id,
    loginUrl: `${CURSOR_LOGIN_URL}?${params.toString()}`,
  }
}

export function parseCursorTokenResponse(value, endpoint = 'Cursor token') {
  if (!value || typeof value !== 'object') throw new Error(`${endpoint} returned an invalid token response`)
  const accessToken = trimmed(value.accessToken) ?? trimmed(value.access)
  if (!accessToken) throw new Error(`${endpoint} returned no access token`)
  const refreshToken = trimmed(value.refreshToken) ?? trimmed(value.refresh)
  return { accessToken, refreshToken }
}

export function cursorSession({
  accessToken,
  refreshToken,
  expiresAt,
  account,
  planType,
  cachedEmail,
  source = 'pkce',
}: any = {}) {
  if (!trimmed(accessToken)) throw new Error('cursor session needs an access token')
  const refresh = trimmed(refreshToken) ?? accessToken
  const resolvedExpiry = typeof expiresAt === 'number' && Number.isFinite(expiresAt)
    ? expiresAt
    : cursorTokenExpiry(accessToken)
  const cached = pickCursorHumanAccount(cachedEmail)
  const human = pickCursorHumanAccount(account, cursorAccountFromToken(accessToken))
  const accountName = trimmed(account)
  const vault = human
    ?? (accountName && accountName.toLowerCase() !== 'cursor' ? accountName : undefined)
    ?? cursorVaultAccountFromToken(accessToken)
  return {
    accessToken,
    refreshToken: refresh,
    expiresAt: resolvedExpiry,
    ...(vault ? { account: vault } : {}),
    source: CURSOR_SOURCES.includes(source) ? source : 'pkce',
    ...(trimmed(planType) ? { planType: planType.trim() } : {}),
    ...(cached ? { cachedEmail: cached } : {}),
  }
}

export function cursorChatHeaders(session, { unary = false, requestId, originalRequestId }: any = {}) {
  const id = typeof requestId === 'string' && requestId.trim() ? requestId.trim() : randomUUID()
  const original = typeof originalRequestId === 'string' && originalRequestId.trim()
    ? originalRequestId.trim()
    : id
  return {
    authorization: `Bearer ${session.accessToken}`,
    'connect-protocol-version': '1',
    'content-type': unary ? 'application/proto' : 'application/connect+proto',
    te: 'trailers',
    'x-ghost-mode': 'true',
    'x-cursor-client-version': cursorClientVersion(),
    'x-cursor-client-type': CURSOR_CLIENT_TYPE,
    'x-request-id': id,
    'x-original-request-id': original,
  }
}

export function cursorUsageHeaders(session) {
  return {
    authorization: `Bearer ${session.accessToken}`,
    'content-type': 'application/json',
    // api2 JSON unaries are Connect calls; magpie sends the protocol version
    // on GetHardLimit / GetCurrentPeriodUsage too (packages/cursor index.mjs
    // headersFor / hardLimit).
    'connect-protocol-version': '1',
    'x-cursor-client-version': cursorClientVersion(),
    'x-cursor-client-type': CURSOR_CLIENT_TYPE,
  }
}

export async function pollCursorAuth(uuid, verifier, { fetchFn = outboundFetch, sleep, signal, maxAttempts = CURSOR_POLL_MAX_ATTEMPTS }: any = {}) {
  const wait = sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)))
  let delay = CURSOR_POLL_BASE_DELAY_MS
  let consecutiveErrors = 0
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    if (signal?.aborted) throw new Error('login cancelled')
    await wait(delay, signal)
    if (signal?.aborted) throw new Error('login cancelled')
    try {
      // The CLI fingerprints the poll too (Content-Type + client version /
      // type): magpie's browserSignIn sends exactly these on /auth/poll
      // (packages/cursor index.mjs).
      const response = await fetchFn(`${CURSOR_POLL_URL}?uuid=${encodeURIComponent(uuid)}&verifier=${encodeURIComponent(verifier)}`, {
        headers: {
          'content-type': 'application/json',
          'x-cursor-client-version': cursorClientVersion(),
          'x-cursor-client-type': CURSOR_CLIENT_TYPE,
        },
        signal,
      })
      if (response.status === 404) {
        consecutiveErrors = 0
        delay = Math.min(delay * CURSOR_POLL_BACKOFF, CURSOR_POLL_MAX_DELAY_MS)
        continue
      }
      if (response.ok) {
        const data = parseCursorTokenResponse(await response.json(), 'Cursor authentication polling')
        if (!data.refreshToken) throw new Error('Cursor authentication polling returned no refresh token')
        return data
      }
      throw new Error(`Poll failed: ${response.status}`)
    } catch (error) {
      if (signal?.aborted || (error instanceof Error && error.message === 'login cancelled')) {
        throw new Error('login cancelled')
      }
      consecutiveErrors += 1
      if (consecutiveErrors >= 3) {
        throw error instanceof Error ? error : new Error(String(error))
      }
    }
  }
  throw new Error('Cursor authentication polling timeout')
}

export async function refreshCursorTokens(refreshToken, { fetchFn = outboundFetch, signal }: any = {}) {
  const token = trimmed(refreshToken)
  if (!token) throw new Error('cursor refresh needs a refresh token')
  const response = await fetchFn(CURSOR_REFRESH_URL, {
    method: 'POST',
    headers: {
      authorization: `Bearer ${token}`,
      'content-type': 'application/json',
    },
    body: '{}',
    signal,
  })
  if (!response.ok) throw await oauthError(response, 'Cursor token refresh')
  const data = parseCursorTokenResponse(await response.json(), 'Cursor token refresh')
  return {
    accessToken: data.accessToken,
    refreshToken: data.refreshToken || token,
    expiresAt: cursorTokenExpiry(data.accessToken),
  }
}

export async function refreshCursor(session, fetchFn = outboundFetch) {
  if (session?.source === 'env' || session?.refreshToken === session?.accessToken) {
    if (cursorAccessStillValid(session.accessToken)) return session
    throw new OAuthEndpointError('Cursor env token expired; sign in again', 401)
  }
  const tokens = await refreshCursorTokens(session.refreshToken, { fetchFn })
  return cursorSession({
    ...tokens,
    account: session.account,
    planType: session.planType,
    cachedEmail: session.cachedEmail,
    source: session.source,
  })
}

export async function completeCursorLogin(tokens, { source = 'pkce' } = {}) {
  return cursorSession({
    accessToken: tokens.accessToken,
    refreshToken: tokens.refreshToken,
    expiresAt: tokens.expiresAt ?? cursorTokenExpiry(tokens.accessToken),
    account: tokens.account,
    source,
  })
}
