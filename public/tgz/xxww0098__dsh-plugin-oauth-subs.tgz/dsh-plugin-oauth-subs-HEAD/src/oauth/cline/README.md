# Cline (cline.bot) OAuth

本文件是 `src/oauth/cline/` 的设计源。改登录、额度、对话或缓存先改这里再改代码。
跨家族硬规则在 [`docs/rules.md`](../../../docs/rules.md)；故障记录在 [`docs/error.md`](../../../docs/error.md)；对照仓库在 [`docs/oauth.md`](../../../docs/oauth.md)。

**上游引擎（维护者裁定 2026-10-18「全过、不回退、不旧兼容」）**：登录、刷新、chat hop
（头组 + `X-Task-ID` 派生 + `{success,data}` 剥壳）、额度三读由运行时下载的
`@magpie-community/opencode-cline-auth`（种子 0.1.8，dist-tags 自动跟进）直接驱动——
[`engine.ts`](engine.ts) 是适配层，api.cline.bot 与 api.workos.com 走 URL 作用域 global-fetch
桥（[`../../upstream-engine/bridge.ts`](../../upstream-engine/bridge.ts)）。留在本仓的：
vault 会话形状与生命周期、只读 CLI 导入、身份写回、目录闭集（catalog.ts）、缓存剥离与
system 钉（cache.ts）、拒绝分类（request.ts `clineQuotaFailure`，代理语义）。
加载/契约/下载失败＝本家带着引擎错误失败（60s 负缓存），无第二条车道。

**不是** ChatGPT Codex / xAI Grok / OpenCode Zen。上游是 Cline 订阅后端
`https://api.cline.bot/api/v1/chat/completions`（OpenAI Completions 方言，OpenRouter 在后）。
登录是 **WorkOS 设备码 + Cline register 兑换**，**没有 PKCE、没有回环回调服务器**。

计费单位是**额度（credits）**，不是 5h/周窗口：`cline` 产品按用量扣余额，ClinePass 才有订阅限额
（限额只以 429/402 报文出现，没有查询端点）。所以额度卡是 `prepaid` 余额行 + 套餐名。

## 文件

| 文件 | 职责 |
|---|---|
| [`engine.ts`](engine.ts) | 引擎适配：插件装配（`ClinePlugin({client})`）、登录 `clineEngineAuthorize`、刷新 `refreshClineEngine`、hop 头/装载 `clineEngineHeaders`/`clineEngineFetch`、额度 `fetchClineQuotaEngine`、写回 client（按 uid 合并 vault 行） |
| [`index.ts`](index.ts) | 常量（URL/头组/成本位）、`workos:` 前缀、会话形状 `clineSessionFromAuthData`、`/users/me` 身份、静态目录 |
| [`import.ts`](import.ts) | `~/.cline/data/settings/providers.json` 读取（`cline` / `cline-pass` 都认），只读不回写 |
| [`catalog.ts`](catalog.ts) | `GET /ai/cline/recommended-models`（成员）+ `GET /ai/cline/models`（窗口/输出/模态事实）；静态 `CLINE_MODELS` 做离线下限 |
| [`request.ts`](request.ts) | `max_tokens`→`max_completion_tokens`（OpenAI 推理世代）；`include_usage`；`reasoning_effort` 透传；`cache_read_*`→`cached_tokens`；拒绝分类 `clineQuotaFailure`（对引擎已归一化的 `usage limit reached: ` 前缀不二次加前缀） |
| [`cache.ts`](cache.ts) | 会话 id 清洗与 `x-magpie-cline-session` 取舍；剥 Codex / Grok 字段；首段 system 停车 |

调度：[`../proxy.ts`](../proxy.ts) `family === 'cline'` → `applyClineCache` → `applyClineMaxCompletionTokens` → `applyClineThinking` → `applyClineStreamUsage`，`clineEngineFetch` 装载引擎 loader 后 `forward()` 到 `CLINE_CHAT_URL`。
额度：[`../quota.ts`](../quota.ts) 分派 `fetchClineQuotaEngine`（[`engine.ts`](engine.ts)）。
套餐：[`../plan.ts`](../plan.ts) `CLINE_PLAN_NAMES`（`usage-billing` / `clinepass`），无订阅时落 `usage-billing`。

## 协议

DSH `api: openai-completions`。不要写第四个 api 字符串：DSH 闭集只有
`openai-responses` | `openai-completions` | `anthropic-messages`，第四个值会整段丢掉。

```text
DSH POST /cline/v1/chat/completions
  → applyClineCache（剥 prompt_cache_key / session_id / retention；首段 system 停车）
  → applyClineMaxCompletionTokens（gpt-5 / o1/o3/o4 才把 max_tokens 改名）
  → applyClineThinking（目录里有该模型才留 reasoning_effort，max→xhigh）
  → applyClineStreamUsage（stream 时补 stream_options.include_usage）
  → clineEngineHeaders（具名会话 → x-magpie-cline-session 头；兜底 id 不发）
  → 引擎 loader.fetch：剥会话头、注 Bearer workos:<jwt>、Cline 头组（UA Cline/3.0.68、
     X-CLIENT-TYPE cline-cli、…）、X-Task-ID = sha256("cline task\0"+会话) 的 v4 形状、
     非 2xx 按 failure() 归一（429 族 → "usage limit reached: …"）、2xx 剥 {success,data} 壳、
     响应盖 X-Magpie-Sign-In（WIRE_ONLY 闭集在转发前剥掉）
  → POST https://api.cline.bot/api/v1/chat/completions
```

`baseURL` 是 `${origin}/cline`。Completions SDK 打到 `/cline/v1/chat/completions`。
`/cline/v1/responses` 明确 501：Cline 只有 Completions。

每日免费额度耗尽是 HTTP 429 `{"code":"INFERENCE_CAP_ERROR","message":"Error 429: Daily free limit reached on model …"}`
（2026-09-28 宿主会话实录）。引擎 loader 的 `failure()` 先把它归一成 429 `usage limit reached: <厂商原文>`，
代理侧 `clineQuotaFailure` 经 `forward()` 的 `classifyFailure` 钩子再分类（已带前缀的不二次加前缀），
宿主归为 QUOTA_EXCEEDED、不重试。同一改写覆盖 CLI 认得的
ClinePass 限额文案（`you have reached your` … `clinepass limit` … `please try again later.`）、402 / `insufficient_credits` / spend limit。
其余 429 仍原样转发。未订阅 / 组织账号不能用个人推理订阅是 400 说明，不是 403：宿主分类器见报文里的 403 就归 AUTH，会把「没订 ClinePass」看成登录死了。

`reasoningEfforts` 键只有 `off|minimal|low|medium|high|xhigh|max`，值是 OpenAI `reasoning_effort`
（`minimal|low|medium|high|xhigh`，`max`→`xhigh`；**没有 `off`**，见下）。

## 登录

引擎驱动，浏览器不回 127.0.0.1。**没有 PKCE**。`clineEngineAuthorize` 调包的设备方法
（`methods[0].authorize()`），settle 即完成会话——WorkOS 轮询与 register 兑换都在引擎 callback 里。

| 项 | 值（随包，钉 0.1.8 的行为） |
|---|---|
| `client_id` | `client_01K3A541FN8TA3EPPHTD2325AR`（WorkOS，production） |
| device | `POST https://api.workos.com/user_management/authorize/device`，form body 只有 `client_id` |
| poll | `POST https://api.workos.com/user_management/authenticate` `grant_type=urn:ietf:params:oauth:grant-type:device_code` + `device_code` + `client_id`；先睡 interval（≥1s）再首问；`authorization_pending` = 继续等；`slow_down` = interval +1s；轮询上限 600s |
| 兑换 | `POST https://api.cline.bot/api/v1/auth/register` JSON `{accessToken, refreshToken}`（WorkOS 那对）→ `{success, data:{accessToken, refreshToken, tokenType, expiresAt, userInfo}}` |
| 刷新 | `POST https://api.cline.bot/api/v1/auth/refresh` JSON `{refreshToken, grantType:"refresh_token"}`；`{success,data}` 信封，401/403 或 [400,401,403]+文案含 `invalid\|expired\|revoked\|unauthorized` = Lapsed（sign-in gone） |

WorkOS 那一对 token 不是 Cline 会话——`register` 兑换才拿到 `usr-…` 账号 id 与 Cline refresh token。

访问令牌在 vault 里存 **`workos:<jwt>`**（CLI `formatAccessToken` 的前缀；引擎 `bearerOf` 幂等补前缀，
适配层 `sessionFromEngineResult` 的 `formatClineAccessToken` 保持约定）。裸 JWT 打上游是 401
`Unauthorized: Please make sure you're using the latest version of Cline…`（2026-09-19 实测）。

刷新失败分类**只认引擎的 verdict**（不回退裁定）：Lapsed（`signIn: 'expired'` / `.expired`）
→ 适配层转 401 + `invalid_grant` 永久失败（`isPermanentRefreshFailure`），登录被删；其余——
403 rate limit、5xx、200+`success:false`——都是临时失败，手里的 access token 继续服务、稍后重试
（引擎 `fresh` 的 RETRYABLE_GRACE 30s + `RENEW_LEAD` 10min 语义）。2026-10-11 活测的
400 句中 `invalid_grant`（`failed to refresh token: invalid_grant`）由引擎的 lapsed 文案测试命中，无需共享精确 code 匹配。

**刷新单次消费随包**：`auth.refresh(authObject)`（注意参数是 auth 对象**不是** getter——usage/loader 才是 getter），
`held` 按「已花 refresh token → 链上最新对」记多把（进程内），串行锁防双花；写回经
`client.auth.set` → 适配层按 uid 找 vault 行合并 token 字段。落盘失败时共享 `tokens.ts`
`#holdRotation` 按来源版本再兜一层（写失败不重打端点）。**不要**在本家另记一份副本（历史事故见
2026-10-11：额度卡数字数小时不动；`test/cline.test.ts` 钉「每次调用都真换」，`test/token-lifecycle.test.ts` 钉共享层的两条）。

入口：`loginCline` → `clineEngineAuthorize({fetchFn})` → `{authorizeUrl, userCode, mode:'device', settle}` →
`completeClineDevice`（`waitToken()` = settle → `finishClineSession` → save + discover + quota）。
导入：[`import.ts`](import.ts) `importClineAuth`。空花名册自动导入一次；已存 session **绝不**静默覆盖。

**导入只读**（决定 4）：`source: 'cli'` 的登录临期时，`clineImported` 钩子只重读 `providers.json`，过期 > 现在 + 15s 才采用；文件也过期 → `ImportedLoginStale`（403）「… run cline or use browser login」，不删登录；`userId`（`usr-…`）与存储行不同同样抛 `ImportedLoginStale`，不采用。`oauth` 登录照常刷新。引擎车道同样设门：`clineEngineFetch` / `fetchClineQuotaEngine` 对临期（≤ 引擎 `REFRESH_LEAD`，钉版等于 `CLINE_PREEMPT_MS` 5min）的 `cli` 会话直接抛 `ImportedLoginStale`，绝不进入 loader/usage 的 `fresh()`（那里会自行 POST `/auth/refresh` 花掉 CLI 的 refresh token）；`refreshClineEngine` 对 `cli` 会话一律拒绝；引擎写回（`client.auth.set`）合并时保留行上原有 `source`，`cli` 行不会被改写成 `oauth`。

轮换证据：来源一 npm `@cline/core` 0.0.92 `dist/index.js`——刷新路径仍是 POST `/api/v1/auth/refresh`，响应带新的 `refreshToken`（缺省沿用旧值）⇒ 会轮换。来源二（被动观察：插件自有登录在宿主自然刷新前后各记一次 refresh token sha256 前 8 位）：待合入后记录。
刷新一旦成功，旧 refresh token 就作废。落盘失败时**不能让下一次再拿旧 token 去换**（那就是 `invalid_grant`、登录会被删掉），保管这份轮换结果的活由共享层干：`tokens.ts` 写失败时按来源版本 `#holdRotation`，下次直接交还并重试落盘、不再打端点，写成功或版本已变即清除（magpie `held` 的做法，别家同样受益）。
**不要**在本家再记一份这个副本：曾经在这里按 refresh token 记过（并且把「轮换后的 refresh token」也当键），而落盘成功后存储里正是那个键，于是之后每次刷新都命中自己的上一次答案、从不打端点，会话冻结在那一对直到访问令牌过期（2026-10-11 实测：额度卡数字数小时不动、上游数字早已前进；`test/cline.test.ts` 钉「每次调用都真换」，`test/token-lifecycle.test.ts` 钉共享层的两条）。
账号 id 用 `userInfo.email`，其次 `clineUserId`；两者都没有时取 JWT `external_id`/`sub`，再退回常量 `cline-account`——**不用** token 片段。

## 模型

行在 [`src/catalog/models.json`](../../catalog/models.json) 的 `"cline"` 键；行格式、来源与 `npm run models` 更新流程见 [`docs/models.md`](../../../docs/models.md)。本节只记本家的取舍与出处。

登录 / 导入 / 额度刷新后 `refreshClineCatalog` 并行打两个公开端点（都带 `clineIdentityHeaders`，不带 `X-Task-ID`）：

1. `GET https://api.cline.bot/api/v1/ai/cline/recommended-models` — 成员。失败则活目录退回静态楼。
2. `GET https://api.cline.bot/api/v1/ai/cline/models` — 事实（`{data:[…]}`，约 450 行）。失败不影响成员，窗口退回静态楼或 CLI 默认。

- 收 `recommended` + `free` + `clinePass`。`free` 名后补 ` (free)`，`clinePass` 补 ` (ClinePass)`。同一 id 后出现的 free 标记盖过前面的标签。`clineCloud` 不收：CLI `includeClineCloudModels` 默认关，是组织云交接，不是用量计费选择器；magpie 也不收。
- 云目录本身不进 picker。CLI 的 `cline` provider 是整棵 OpenRouter 再叠 recommended 角标；本 hop 只借它的窗口数字。全量会把几百行默认开启写进 settings.yaml。要放开需同时改这里与 [`catalog.ts`](catalog.ts)。
- 窗口取云目录，不取 models.dev 末段。精确 id 优先；只有 `cline-free/`、`cline-pass/` 才按末段回退，且末段必须在云目录里唯一，否则不借（避免 `spacexai/grok-4.7` 这种非网关 id 吃到 `x-ai/` 的行）。`context_length` 是窗（活载荷的 `context` 是 0，不用）。`maxTokens` 取 `top_provider.max_completion_tokens`（路由层另夹到 32768，目录行留厂商上限）。`input` 只留 text/image。`supported_parameters` 含 `reasoning_effort` 才挂 `CLINE_REASONING`，否则 `reasoningEfforts: false`（本 hop 只发这个字段，不发明别的推理字段）。
- 云目录和静态楼都没有数字的新 id 用 CLI 的 `CLINE_PASS_MODEL_DEFAULTS`（128k / 8k / text+image），不编数字。2026-10-10 的 `cline-pass/qwen3.8-max` 不在云目录里，窗口就是这个默认。
- 显示名：静态楼的策展名优先；否则云目录 `Vendor: Model` 去掉厂商前缀；feed 的 name 经常等于 id 或末段，那种不算名字，改成末段的可读形式。
- 免费档可用、不扣余额，个别模型按出口 IP 403 区域门（非本 hop 问题）；见 docs/error.md 2026-09-19 Cline 免费档活测。推理模型别把 `max_tokens` 设太小，reasoning token 吃满预算会得到空 `content`。credit 账号选 ClinePass 行会 402/403，失败分类改写成 400 说明，不当成登录失效。
- 上限槽：`maxContextWindow`（自定义输入窗上限）对 cline 行生效（`familyMaxContextWindow` 查静态楼）；`pickerRow` 会把 fact 上的同名字段带进活目录。云目录只给一档 `context_length`，没有第二档可挂，行上目前不写。

最近核对：2026-10-17，公开 feed（recommended 6 / free 4 / clinePass 14，仍无 grok）+ 云目录 470 行（2026-10-15 记 462）。feed 与云目录在匿名与带本机 Bearer 两种取法下 id 完全相同，排除账号/出口过滤；feed 12 次 no-store 采样逐桶一致。free 桶换行：撤下 `cline-free/step-5-preview`（活测 `POST /v1/chat/completions` 404 `model not found` 两次；同账号同日 `x-ai/grok-4.7` 200、`cline-free/mimo-v2.6-flash` 500，故排除账号/套餐/出口过滤，随源删行与 $0 价目），收 `cline-free/nemotron-3.5-super-vl`。新行参数：云目录 `nvidia/nemotron-3.5-super-vl` 的 `top_provider` 给 262144 窗 / 235929 输出，`context_length` 给 1048576 总窗，modalities text+image+video（video 剥掉），`supported_parameters` 只有 `reasoning` 没有 `reasoning_effort` → `reasoningEfforts: false`。窗口按「默认输入窗 ≠ 总窗」钉 262144，1048576 挂该行 `maxContextWindow`（同机 command-code 的同一 id 行也是 262144；全表 470 行里 `top_provider.context_length` 比 `context_length` 小的有 28 行、大的 0 行，说明前者是实际服务档）。免费兄弟行 `nvidia/nemotron-3.5-super-vl:free` 与 models.dev `:free` 都是 1000000/131072，1M 档确实存在另一档，所以基线钉小、上限挂大。两行 `maxTokens` 变化都不是「厂商改版」而是**源在摆**：`cline-pass/deepseek-v4.1-flash` 30 次独立采样 30/30 = 393216（10-14 记改小、10-15 记改回 943718、今天又回 393216），`cline-pass/glm-5.3-flash` 30 次采样 **18 次 131072 / 12 次 943718**、同一分钟内来回切且价目同步两套口径 —— 两者都按今天与第二源（models.dev `openrouter` 393216、`cline-pass`/`zai` 131072）相符的一档写入并加 `keep` 钉死，避免逐轮抖动（路由侧仍被 32768 夹住，用户不受影响）。`x-ai/grok-4.7` 与 `spacexai/grok-4.7` 仍不在 feed，两个 id 同日活测都是 200，继续不 `--prune`。价目：新免费行随 feed `free` 组 $0；删 `cline-free/step-5-preview` 的 $0 行。

上次核对：2026-10-15，公开 feed（recommended 6 / free 4 / clinePass 14，仍无 grok）+ 云目录 462 行。`cline-pass/deepseek-v4.1-flash` 的 `top_provider.max_completion_tokens` 从 393216 回到 943718，目录 `maxTokens` 随云目录改回。`cline-free/step-5-preview` 末段唯一命中 `stepfun/step-5-preview`，`context_length` 1000000→1048576，目录窗口跟着改；输出仍是 64000。`x-ai/grok-4.7` 与 `spacexai/grok-4.7` 仍不在 feed，云目录仍有 `x-ai/grok-4.7`，不 `--prune`。价目随 openrouter：`moonshotai/kimi-k3` 0.73/10/0.55 → 0.45/15/0.28；`cline-pass/deepseek-v4.1-flash` 借 `deepseek/deepseek-v4.1-flash` 0.15/0.6/0.003 → 0.01368/0.891/0.0054。

上次核对：2026-10-14，公开 feed + `GET /ai/cline/models`（462 行，末段唯一）。feed 的 `recommended` 新增 `google/gemini-4-argon`：末段唯一命中云目录 `google/gemini-4-argon`（1048576 窗 / 65536 输出 / text+image / `supported_parameters` 含 `reasoning_effort` → `CLINE_REASONING`），已收入目录；价目取 models.dev `openrouter`（$2/$10/cacheRead $0.1/cacheWrite $0.1875）。两行 `maxTokens` 随云目录更新：`cline-pass/deepseek-v4.1-flash` 943718 → 393216（厂商把该行输出上限改小）、`cline-pass/glm-5.3-flash` 943717 → 943718。`? x-ai/grok-4.7` / `spacexai/grok-4.7` 仍不在 feed（旧 id 2026-10-10 活测 200），不 `--prune`。同一轮 rates 随源改：`cline-pass/deepseek-v4.1-flash` $0.3/$1.2/$0.006 → $0.15/$0.6/$0.003、`moonshotai/kimi-k3` $0.5/$13.5/$0.28 → $0.73/$10/$0.55。

上次核对：2026-10-10，公开 feed + `GET /ai/cline/models`（458 行，`{data:[…]}`，末段全部唯一）。窗口改从云目录取，不再用 models.dev 末段。`clinePass` 14 个 id 入列（名后 `(ClinePass)`），窗/输出取唯一末段命中的厂商行：`deepseek-v4.1-flash` 1048576/943718 text+image；`mimo-v2.6-flash` 与 `mimo-v2.6-pro` 1050000/131072 text+image，`reasoningEfforts: false`；`glm-5.3` 1048576/943718 text；`deepseek-v4-pro` 1048576/384000 text；`muse-spark-1.3-contributor` 与 `kimi-k3` 都是 1048576/943718 text+image（同数字，不是末段撞车）；`glm-5.3-flash` 1048576/943717 text+image；`qwen3.7-plus` 1000000/131072 text+image、`qwen3.7-max` 1000000/131072 text，两者 `reasoningEfforts: false`；`minimax-m3` 1048576/512000 text+image，`reasoningEfforts: false`；`mimo-v2.5-pro` 1050000/131072 text、`mimo-v2.5` 1050000/131072 text+image，两者 `reasoningEfforts: false`。`cline-pass/qwen3.8-max` 不在云目录，窗口与推理阶梯都是 CLI 默认 128000/8192 / `CLINE_REASONING`，不是测到的参数表。`cline-free/mimo-v2.6-flash` 同步改成 `reasoningEfforts: false`。价目不编，新行没有 rates。不 `--prune`（`spacexai/grok-4.7` 仍不在 feed）。

上次核对：2026-10-10，公开 feed + models.dev `openrouter`：recommended 把 `spacexai/grok-4.7` 换成 `x-ai/grok-4.7`（精确命中 openrouter `x-ai/grok-4.7`：500000 窗 / 450000 输出 / text+image，pdf 剥掉；价 2/6/0.5，超过 200K 为 4/12/1）。旧 id 四个桶都没有，但 `POST /chat/completions` 仍 200，列表换前缀不是下架，静态行与价目保留、不 `--prune`（登录后活目录按 feed 替换，picker 不再列旧 id）。free 桶新增 `cline-free/step-5-preview`：桶里没有 `cline-free/` 前缀，末段匹配 openrouter `stepfun/step-5-preview`（1000000 / 64000 / text+image，video 剥掉；free 组 → $0）。`max_tokens: 16` 活测 500 `empty response content`（推理吃满预算）；2048 与 64+`minimal` 都 200。`moonshotai/kimi-k3` 价随 openrouter 桶 0.62/12.3/0.43 → 0.8/13.5/0.55。行数 9→11。

上次核对：2026-10-08，公开 feed 无新行、无下架（仍 9 行）。`moonshotai/kimi-k3` 价随 models.dev `openrouter` 桶 0.65/15/0.43 → 0.62/12.3/0.43。

上次核对：2026-10-07，公开 feed + models.dev `openrouter`：feed 的 `free` 桶新增 `cline-free/solar-mini4`（Solar Mini 4，524288 窗 / 131072 输出 / text / minimal–max；free 组 → 价目 $0）；撤下 `stealth/space-bunny-alpha`（Stealth 免费预览结束——command-code 1.74.2 同日退役 "Space Bunny Alpha" 与 "Pixel Canary"，互相印证），目录与价目随源删行；`moonshotai/kimi-k3` 价随 models.dev `openrouter` 桶 0.67/14/0.22 → 0.69/15/0.45。行数 9→9。

上次核对：2026-10-05，公开 feed + models.dev `openrouter`：feed 的 `free` 桶撤下 `cline-free/deepseek-v4.1-flash`（4→3 行；同名 id 仍在 `clinePass` / `clineCloud` 两个付费桶里 → 免费档促销结束，不是模型下架），目录与价目随源删行（10→9）；`moonshotai/kimi-k3` 价随 models.dev `openrouter` 桶 2.7/13.5/0.27 → 0.67/14/0.22。

更早核对：2026-10-01，公开 feed + models.dev `openrouter`：feed 撤下 `stealth/pixel-canary`（Stealth 预览 9/30 结束；command-code 1.73.1 同日加退役日期门 `2026-10-01T06:00:00Z`，互相印证），目录与价目删行（11→10）；`cline-free/mimo-v2.6-flash` 的 `contextWindow` 随 models.dev 桶 1048576 → 1050000。


## 额度

`fetchClineQuotaEngine` 调引擎 `usage(getAuth)`，三读的顺序与形状都随包（index.mjs `usage`/`usageOf`）：
`/users/me/plan/usage-limits` 与 `/users/me` 并行发起 → 按 me 给的候选 id（`clineUserId`/`subject`/`id`/凭据 uid）
依次试 `GET /users/{id}/balance`。

| 读 | 引擎语义 |
|---|---|
| `/users/me` | 身份（`email`、`usr-…` id）；`plan`/`planType`/`membership`/`tier` 任一即套餐名 |
| `/users/{id}/balance` | `{balance}` **微美元**（÷1e6 = USD）→ `'$x.xx'` 字符串 |
| `/users/me/plan/usage-limits` | ClinePass 滚动窗口 `{limits:[{type, percentUsed, resetsAt}]}`；404 = 无订阅（`{v:null}`，不算错） |

适配映射：窗口 `five_hour`/`weekly`/`monthly`（名字 '5 hours'/'Weekly'/'Month'）→ `kind: 'primary'`
行（`usedPercent` 原值、`remainingPercent = 100 - used`、`resetAt`）；余额字符串 → `prepaid`
钱包行；`user` → 卡片账号。usage-limits 非 404 失败而 me/balance 成功时（包 #79 的 partial
设计：带着软错误一起返回），适配层保留已读到的窗口/余额行与 `planType` 降级返回、`error`
字段带原因；一行都读不到才整体报错。`signIn: 'expired'` 仍是 401 `invalid_grant` 永久失败。

**引擎只说百分比，不说分母**——旧 quota.ts 从 entitlements（1e-8 USD `inferenceCapThreshold`）
合成 `used`/`total` 美元槽的路径已随不回退裁定删除，cap 缺失就不给总数，不发明分母。
无订阅时 `planType` 不写（卡片侧落 `usage-billing` 徽章）。

> ⚠️ 窗口行数值仍未用订阅账号活测（本机是 credit 账号）；引擎 `usageOf` 的形状由
> `test/upstream-engine-fixture.ts` 的 CLINE_FIXTURE_MODULE 按 0.1.8 复刻钉住。拿到订阅账号后
> 应重跑一次额度读取并把结论补进 `docs/error.md`。

## 缓存

Cline 背后是 OpenRouter，缓存是**隐式前缀哈希**；客户端不发 `prompt_cache_key` / `cache_control`。
唯一的会话亲和字段是 **`X-Task-ID`** 请求头——**派生随包**（`taskIdOf`：sha256(`"cline task\0"` + 会话)
截 16 字节强转 v4 形状 UUID），我们的会话名经 `x-magpie-cline-session` 头进引擎再派生。

| 步骤 | 函数 | 做什么 |
|---|---|---|
| 1 | `clineCacheSessionId` | 清洗 DSH id（1–64，`[A-Za-z0-9._:-]`） |
| 2 | `applyClineCache` | 剥 Codex/Grok 字段；首段 system 钉住，后续**纯扩展**快照停到 **messages suffix**；不兼容的头（换模型）直接重钉；回退 id `dsh-cline`（`isClineFallback`）不是会话，从不钉 |
| 3 | `clineEngineHeaders` | 具名会话 → `{accept, x-magpie-cline-session: <钉>}`；兜底 id **不发**（引擎按自身输入派生或不发）——rules.md 回退常量条款的豁免已随裁定落地，`CLINE_STABLE_SESSION` 只作 system-pin 的「永不钉」哨兵 |

活测（2026-09-19，本机账号）：`openai/gpt-6-astra` 同一 1.4k 前缀第二次 **1461/1464 cached**；
`anthropic/claude-opus-5` 两次都是 0——Anthropic 走 OpenRouter 需要显式 `cache_control` 断点，
**CLI 也不发**，所以本 hop 同样不发（见「不要」）。不要 `Date.now()`。
（注：该命中活测是在旧「钉 DSH 会话 id 本身」的派生下做的；换包派生后前缀键不同，
命中率重置一次——已接受的反转。）

## 不要

- 不要加 PKCE / 回环回调：CLI 默认 `useWorkOSDeviceAuth: true`，浏览器分支是给旧 VS Code 扩展的。
- 不要把裸 JWT 当 bearer（必须 `workos:` 前缀），也不要加第二次前缀。
- 不要给 Cline 写 Codex `session-id` / `prompt_cache_key` 或 Grok `x-grok-conv-id`。
- 不要发明 `cache_control` 断点：CLI 的 `splitToolImagesMiddleware` 只搬图片，不加缓存断点。
- 不要把 `clineCloud` 或 `/ai/cline/models` 的整棵 OpenRouter 列进 picker。`clinePass` 要列，名后标 `(ClinePass)`；credit 账号打到它是 400 说明，不要原样转发 403（宿主见 403 归 AUTH）。
- 不要照抄 magpie 的随机 `X-Task-ID`——0.1.8 已是「`"cline task\0" + 会话 id`」sha256 确定性派生（随包采用），
  但**不要**自己再算一份或把会话头透传到上游之外（`x-magpie-cline-session` 是宿主私有头，loader 发线前必删）。
  也不要把目录 `maxTokens` 留 0（它的宿主自己留预算；本 hop 目录行是厂商上限，路由层再夹到 32768）。
  DeepSeek `pinUpstream`（providerOptions.gateway.only）默认关，本 hop 不开这个开关。
- 不要 npm `@cline/sdk`、不要 vendor `@cline/*` 整棵树；Settings 图标是 LobeHub static SVG path。
- 不要把 `api` 写成第四个字符串。
- 不要自己累加 `/usages` 去凑窗口用量：窗口百分比由引擎的 `plan/usage-limits` 读给；没有分母就不画总数，不补默认值、不从 entitlements 合成。
- 不要给 credit 账号画进度条（它没有窗口分母）。

## 归因

**实现归因 = 引擎包**：[`@magpie-community/opencode-cline-auth`](https://github.com/magpie-community/plugins/tree/main/packages/cline)
`0.1.8`（MIT，运行时下载、sha512 钉版、dist-tags 自动跟进；本仓快照 `.local/upstream-magpie/packages/cline/`）。
登录/刷新/hop/额度全部随包，见文件表。

一线 CLI 对照（**只对照 wire，不再是实现**）：**Cline CLI 3.0.70**（npm `cline`，本机
`~/.local/lib/node_modules/cline`），跑在 `@cline/core` / `@cline/llms` 0.0.92 上；源码 tag
[`cli-v3.0.70`](https://github.com/cline/cline)（Apache-2.0）。闭源的只有 WorkOS 身份：登录是
`api.workos.com` 的 RFC 8628 设备码，换票走 Cline 自己的 `/api/v1/auth/register`。引擎自身钉的是
CLI 3.0.68 / core 0.0.90（上游内部三处版本引用不一致，随包不修）；本仓静态目录头的
`CLINE_CLIENT_VERSION` 3.0.70 / `CLINE_CORE_VERSION` 0.0.92 仅供目录刷新读数与测试对照。
ClinePass 窗口形状的原始对照：MIT [`pi-clinepass`](https://www.npmjs.com/package/pi-clinepass)。

| 抄 | 出处 | 本仓落点 |
|---|---|---|
| 登录/刷新/hop/额度 wire | `@magpie-community/opencode-cline-auth` 0.1.8 `index.mjs` | [`engine.ts`](engine.ts) 适配层（fixture 复刻见 `test/upstream-engine-fixture.ts`） |
| 模型页价格徽标（USD / 1M） | recommended-models feed `free` 组 → $0；其余 models.dev `openrouter`（`spacexai/` → `x-ai/`） | `src/catalog/rates.json`，`npm run rates` 写入（见 [docs/models.md](../../../docs/models.md) 费率表） |
| `workos:` 前缀 + 会话形状 | CLI `sdk/packages/core/src/auth/provider-auth-registry.ts` `formatAccessToken`；引擎 `bearerOf` | `formatClineAccessToken`（幂等，vault 约定） |
| OpenAI 兼容 hop | CLI `sdk/packages/llms/src/providers/vendors/cline.ts`；引擎 loader | `CLINE_CHAT_URL` + `api: openai-completions` |
| `max_tokens`→`max_completion_tokens` | CLI `sdk/packages/llms/src/providers/vendors/openai-compatible.ts` | `applyClineMaxCompletionTokens`（本仓保留的请求方言层） |
| `reasoning_effort` 语义（`max`→`xhigh`，禁用不发字段） | CLI `sdk/packages/llms/src/providers/routing/portable-reasoning.ts` | `CLINE_REASONING`（无 `off` 键） |
| 推荐模型 feed + 云目录事实 | CLI `sdk/packages/core` `fetchClineRecommendedModels` / `loadCloudModels` | `refreshClineCatalog`：成员是 recommended+free+clinePass，窗口来自 `GET /ai/cline/models`（目录闭集留本仓） |
| 余额微美元 | CLI `apps/cli/src/utils/output.ts` `normalizeCreditBalance`；引擎 `balanceUSD` | `CLINE_CREDIT_SCALE`（引擎金额字符串由适配层解析） |
| 本机凭据文件 | `ProviderSettingsManager`（`~/.cline/data/settings/providers.json`） | [`import.ts`](import.ts) |

**不要发明：** 这份对照得出的禁令（credit 账号进度条、cap 缺失补默认、自累加 `/usages`、裸 JWT、PKCE / 回环、`cache_control` 断点、别家缓存头、`clineCloud` / 整棵 OpenRouter 进目录、随机 `X-Task-ID`、第四个 `api`）都在「不要」节，这里不重复。

跨家族对照总表见 [`docs/oauth.md`](../../../docs/oauth.md)。
