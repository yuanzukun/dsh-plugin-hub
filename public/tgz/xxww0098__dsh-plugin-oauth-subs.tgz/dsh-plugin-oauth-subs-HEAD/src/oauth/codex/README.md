# Codex OAuth

本文件是 `src/oauth/codex/` 的设计源。改登录、额度、对话或缓存先改这里再改代码。
跨家族硬规则在 [`docs/rules.md`](../../../docs/rules.md)；故障记录在 [`docs/error.md`](../../../docs/error.md)；对照仓库在 [`docs/oauth.md`](../../../docs/oauth.md)。

**不是** `api.openai.com` 付费 key。走的是 ChatGPT 订阅后端 `chatgpt.com/backend-api/codex`。

## 文件

| 文件 | 职责 |
|---|---|
| [`index.ts`](index.ts) | 客户端 id、端点、授权 URL、回调 client_id 校验、换票、刷新、上游头 |
| [`request.ts`](request.ts) | Responses 体：把 `input` 里的 system/developer 抬到 `instructions`，后缀停放，剥 gpt-5.6 拒收字段；`encodeCodexBody` zstd 压缩 |
| [`cache.ts`](cache.ts) | `prompt_cache_key` + `session-id` / `thread-id` / `x-client-request-id`。禁止给别的家族用 |
| [`websocket.ts`](websocket.ts) | WS 传输 + 连接级续传（`previous_response_id` 增量），池 / 冷却 / SSE 回退；`DSH_CODEX_WEBSOCKET=on` 显式开启 |

调度：[`../proxy.ts`](../proxy.ts) `family === 'codex'` → `normalizeCodexResponsesBody` + `applyCodexCache` + `codexCacheHeaders`。
额度：[`quota.ts`](quota.ts) `fetchCodexQuota` / `parseCodexUsage` / `consumeCodexReset`。
套餐显示：[`../plan.ts`](../plan.ts) `CODEX_PLAN_NAMES`（`pro` → **Pro 20x**，`prolite` → **Pro 5x**）。

## 登录

指纹对齐 Codex CLI（`openai/codex`）：

| 项 | 值 |
|---|---|
| `client_id` | `app_EMoamEEZ73f0CkXaXp7hrann` |
| authorize | `https://auth.openai.com/oauth/authorize` |
| token | `https://auth.openai.com/oauth/token` |
| originator / UA | `codex_cli_rs` / `codex_cli_rs/0.162.1` |
| loopback | `localhost:1455`，失败再 `1457`；path `/auth/callback` |
| 换票 | `application/x-www-form-urlencoded` + PKCE |
| 刷新 | JSON `{ client_id, grant_type, refresh_token }` |

入口：`codexFlow.buildAuthorizeUrl` → `exchangeCodexCode` → `codexSession`。
`chatgpt_account_id` 必须从 id_token `https://api.openai.com/auth` 解出，没有就不能用订阅。
永久刷新失败：401，共享码 `invalid_grant` / `invalid_client` / `unauthorized_client`，加本家额外码 `refresh_token_expired` / `reused` / `invalidated`（`CODEX_PERMANENT_REFRESH_CODES`，读 `error` 或 `error.code`）。

导入：[`../import-auth.ts`](../import-auth.ts) `importCodexAuth` 读本机 Codex CLI `auth.json`（其次 `~/.hermes/auth.json`）。

**导入只读**（决定 4）：导入的 session 带 `source: <auth.json 路径>`，PKCE 登录没有。`TokenManager` 的 `codexImported` 钩子临期只重读该文件（过期 > 现在 + 15s 才采用，经版本守卫写回 vault），**从不**拿与 CLI 共享的 refresh token 换票；文件也过期 → `ImportedLoginStale`（403）「… run codex or use browser login」，不删登录；重读到的 `accountId` 与存储行不同（CLI 换了号）同样抛 `ImportedLoginStale`，不采用。过期取 access JWT `exp`：旧的 `last_refresh + 1h` 会把 CLI 约 8 天才轮换一次的活 token 判为临期、每个请求都重读。硬切：本改动前导入的登录没有 `source`，仍按插件自有登录换票，需手动重新导入一次。

轮换证据：来源一 openai/codex `rust-v0.155.1` `codex-rs/login/src/auth/manager.rs`——`RefreshResponse.refresh_token: Option<String>`，`persist_tokens` 有新值即覆盖并 `storage.save`；`refresh_token_reused` 归为 Exhausted ⇒ refresh token 一次性、会轮换。CLI 在 JWT `exp` 前 5 分钟主动刷新（取不到 `exp` 时 `last_refresh` 超 8 天）。来源二（被动观察：插件自有登录在宿主自然刷新前后各记一次 refresh token sha256 前 8 位）：待合入后记录。

## 对话

DSH `api: openai-responses`。ChatGPT 订阅后端就是 Responses，三种闭集里这是原生。不要改 Completions / Anthropic（会凭空加翻译层）。

```text
DSH  →  本机 Responses 代理  →  POST chatgpt.com/backend-api/codex/responses
```

头：`codexUpstreamHeaders`（`Authorization`、`chatgpt-account-id`、`originator`、`openai-beta: responses=experimental`）+ `session-id` / `thread-id` / `x-client-request-id`。同一 DSH 请求重试时回放 `x-codex-turn-state`。
请求体：`encodeCodexBody` 用 zstd 压缩（`content-encoding: zstd`，默认级别，不设大小门槛），每个请求只压一次，重试复用同一份字节；后端解码失败（400 / 415）时不回退明文。
Fast：body `service_tier` 从 `fast` 改成 `priority`，并带 `x-codex-routing-hint`（`codexRoutingHint`，见 openai/codex#37345）。
`store` 必须 `false`。`include` 默认 `reasoning.encrypted_content`。剥掉 `prompt_cache_retention` / `prompt_cache_options` / `safety_identifier` / `max_output_tokens`（gpt-5.6 400，Codex #39397）。

## WebSocket 续传（[`websocket.ts`](websocket.ts)，默认关）

同一端点也说 Responses over WebSocket，且 `store:false` 下**连接本身保留服务端会话**，下一轮可以 `previous_response_id` + 只发增量 `input`（协议对照 earendil-works/pi `packages/ai/src/api/openai-codex-responses.ts`）：

- 升级：POST 同路径转 ws/wss，头 = 授权头 + `originator` / UA + `openai-version` + `openai-beta: responses_websockets=2026-02-06` + `session-id` + `x-client-request-id`（**不发 `thread-id`**，pi 升级也不发；HTTP hop 三头不变）。走 `outboundWebsocketDispatcher`（`src/utils/outbound.ts` 唯一 undici 属主），代理 / 直连与 HTTP hop 同一套裁定。
- 请求：一个文本帧 `{type:"response.create", ...body}`，明文 JSON（zstd 只是 HTTP 的事）。
- 回包：每个 WS 消息一个事件 JSON（与 SSE `data:` 同物）；`response.done` 在 WS 侧是终止名，转发给宿主前改名 `response.completed`，宿主看到的与 SSE 事件集一致。
- 池：按（`prompt_cache_key` × `chatgpt-account-id`）一条连接；空闲 5 分钟关、最长 55 分钟换；并行同会话请求各开一次性连接，不共享续传态。
- 增量守卫：body 除 `input` 外逐字段稳定（排序键比较，含 model / instructions / tools / reasoning），且新 `input` 前缀逐项覆盖 [上次全量 input, 上次响应 output]（宿主重放多带的 `phase` / `namespace` 允许）→ 才发增量；任何不符整段重发，不会错删。宿主（llm-pi-ai）重放与服务端 items 的字段序不同，所以比较必须无视键序。
- 失败语义：`error` / `response.failed` 事件按 code 映射 429/401/400（无 HTTP 状态可抄）；`previous_response_not_found` 清续传态后同连接重发整段一次；`websocket_connection_limit_reached` 与一切 pre-commit 传输故障：标记会话冷却 5 分钟（期间全走 SSE），并在**同一 attempt 内**立即落 SSE，不付重试退避；提交后（已出输出）按流中断契约销毁响应，绝不静默重试成重复输出。
- 门口（全部满足才试 WS）：`DSH_CODEX_WEBSOCKET=on`（**默认关**，活测确认后放开默认）、首个 attempt、`stream:true`、有会话 id、非 Fast（`;tier=` 路由提示不带 WS）、会话不在冷却中。401 刷新重试保持 attempt 0，会换新 token 重连 WS。

健康会话在 WS 下的收益不是「前缀缓存命中」，而是**旧前缀根本不上网**：长会话每轮只发新增 items（DSH `instructions` ~128KB + 全史 `input` 从第二轮起不再传）。命中观察：`response.completed` 的 `usage` 里 `input_tokens` 应显著小于全史（服务端按存储上下文计）。


## 模型

行在 [`src/catalog/models.json`](../../catalog/models.json) 的 `"codex"` 键；行格式、来源与 `npm run models` 更新流程见 [`docs/models.md`](../../../docs/models.md)。本节只记本家的取舍与出处。

`CODEX_MODELS` 是唯一目录源，对照 Codex CLI `models.json` 与活目录 `GET .../codex/models?client_version=<CODEX_CLIENT_VERSION>`；运行时不替换静态行。**后端按 `client_version` 门控下发**：`gpt-6-sol`/`gpt-6-luna` 要 ≥ 0.155.0，`gpt-6.1-sol` 要 ≥ 0.159.0——钉的版本落后会让新模型从活目录消失（2026-09-30 实测，0.155.1 下 9 行无 6.1，0.159.0 下出现），所以 `CODEX_CLIENT_VERSION` 跟 npm `@openai/codex` latest 走。

- 只收 `visibility: list` 的行；`gpt-reserve` / auto-review 这类 `hide` 行是 CLI 内部用的。
- 活目录按 `client_version` 过滤：新模型只对足够新的版本下发，identity 版本落后就看不到新模型（见 docs/error.md 2026-09-23 Codex 目录轮换）。
- 不收订阅后端 400（"not supported when using Codex with a ChatGPT account"）的模型，`gpt-5.3-codex` 是先例。
- `contextWindow` 默认取 CLI 的可用输入 258K（`CODEX_CONTEXT_WINDOW`），不是端点的原始 `context_window`。**唯一例外是 `gpt-6.1-sol`**：2026-10-12 核对时源已把它的 `context_window` 抬到 500K（`max_context_window` 仍 872K），这一行的基线跟源取 500K——适配器的 `newRow` 只填新行、源也不返回 `contextWindow`，所以这个值只能手改，`npm run models --write` 不会把它退回去（见 [`docs/error.md`](../../../docs/error.md) 2026-10-12）。端点的 `max_context_window` 写进行的 `maxContextWindow`，作为自定义窗口上限，不派生变体行。
- `fastTier` = `service_tiers` 里有 `priority`。
- `reasoningEfforts` 取 `supported_reasoning_levels`，但 `minimal` 与 `ultra` 会 400（`ultra` 是 CLI 的多 agent 模式，不是 API effort）；`off` 的 wire 值是 `null`。

最近核对：2026-10-14，跟 npm latest 升钉 `CODEX_CLIENT_VERSION` 0.161.0 → 0.162.1（changelog 无模型条目），活目录 @ 0.162.1 探查 7 行、`+0 ~0`、无字段变化。`? gpt-5.5` 源里仍没有——2026-10-08 定向活测 `POST .../codex/responses` 仍 200 `response.completed`，列表过滤不是下架，不删。

上次核对：2026-10-12，只改 `gpt-6.1-sol` 的窗口基线（258K → 500K）。出处是源的 `context_window`：本机 Codex CLI 缓存 `~/.codex/models_cache.json` 镜像 `GET chatgpt.com/backend-api/codex/models` 的同一份清单，2026-10-12 拉取 @ `client_version` 0.162.0 给 `gpt-6.1-sol` `context_window` 500000 / `max_context_window` 872000（同日 `gpt-6-astra` / `gpt-6-luna` 仍是 272000 / 872000）。插件钉的 `CODEX_CLIENT_VERSION` 仍 0.161.0——窗口不随版本门控，本次未升钉；其余行、其余字段不动。

上次核对：2026-10-08，活目录 @ `client_version` 0.161.0（npm latest 0.161.0 当日发布，changelog 无新模型——只是把 GPT-6.1 Sol 设为 CLI 默认档；探查 7 行、无新行、无字段变化，纯跟版。`? gpt-5.5` 源里没有——同日定向活测 `POST .../codex/responses` 仍 200 `response.completed`，chatgpt 家族同样：列表不回 ≠ 下架，不删）。

更早核对：2026-10-07，活目录 @ `client_version` 0.160.1（钉跟 npm latest 升 0.160.1；探查 7 行、无新行、无字段变化，纯跟版。`? gpt-5.5` 源里没有——登录态端点按账号过滤，未确认下架不删）。

更早核对：2026-10-03，活目录 @ `client_version` 0.160.0（钉跟 npm latest 升 0.160.0；探查 8 行、无新行、无字段变化，纯跟版）。

更早核对：2026-09-30，活目录 @ `client_version` 0.159.0（+ `gpt-6.1-sol`）；同日钉跟 npm latest 升 0.159.2（探查无新行，纯跟版）。

## 额度

`GET chatgpt.com/backend-api/wham/usage` → `parseCodexUsage`：

- `primary_window` → 条 `primary`（5 小时）
- `secondary_window` → 条 `weekly`

重置卷（仅 Codex）：`GET .../wham/rate-limit-reset-credits`，消费 `POST .../consume`。Grok 没有对等接口。卡片上的「重置」只对 Codex 亮。

额度余额：`rate_limit.credits`（`{ has_credits, unlimited, balance }`——codex CLI `RateLimitSnapshot` 的 `Credits` 结构，`balance` 是字符串数字）渲染成 `prepaid` 行「额度」，就是 ChatGPT 用量页的「剩余额度」。`has_credits: false` 表示该套餐没有额度计费，不出行；`unlimited` 显示「不限量」。`codex.rate_limits` 帧的 `rate_limits.credits` 走同一条映射；帧没带 `credits` 时 `QuotaStore.learn` 保留上一条余额行。

被动学习（2026-10-02）：Responses 流开头的 `codex.rate_limits` SSE 帧带着同一账号的窗口读数（`primary`/`secondary`，`used_percent` + `window_minutes` + `reset_after_seconds`；codex CLI `RateLimitSnapshot` 拼法，帧的存在性另见 `responses-sse.ts` 引 CLIProxyAPI）。`parseCodexRateLimitsFrame` 把它解析成与 `parseCodexUsage` 同构的行，`QuotaStore.learn` 合进活跃账号的缓存——端点读数仍为权威，`usedAt` 由 `touch` 照常标记。只在 gate 未提交前捕获（帧实践上先于输出）；ChatGPT 家族走 `api.openai.com`，无此帧，不接。

## 缓存

后端按 **`instructions` 然后 `input` 的最长稳定前缀** 命中。DSH 每步把运行时快照插到 `input` 最前（developer/system），不处理就会整段 miss。

| 步骤 | 函数 | 做什么 |
|---|---|---|
| 1 | `liftInstructions` | 前缀 system/developer 抬成顶层 `instructions` |
| 2 | `stabilizeInputPrefix` | 已有 `instructions` 不变；多出来的快照改成 **input 末尾** 的 developer |
| 3 | `applyCodexCache` | `prompt_cache_key` ← DSH `prompt_cache_key` 或 `session_id`（`codexCacheSessionId` 清洗，最长 64）。抄完后从上游 JSON **删掉** `session_id`（chatgpt.com `Unsupported parameter`） |
| 4 | `codexCacheHeaders` | `session-id` = body `prompt_cache_key`；`thread-id` = `x-client-request-id`。DSH 一轮对话就是一条 thread，三值相同。官方 CLI 子代理共享 session、各有 thread |
| 5 | `websocket.ts`（可选） | WS 连接级续传：增量守卫通过时整段旧史不上网；不通过或任何失败 → 整段 + SSE，行为退回第 1–4 步 |

健康长会话：加权命中 ≥ 80%，**零** affinity miss。压缩 / 计划重建造成的 0 命中不是分片 miss。同一 DSH 请求的重试回放 `x-codex-turn-state`（CLI 同 turn 粘滞）。

**禁止**把这套头抄给 Grok / GLM / Kiro / Antigravity。Grok 忽略 Codex `session-id`。

## 不要

- 不要用 `Date.now()` 当 `session-id`。
- 不要发明 `x-codex-installation-id` / `x-codex-turn-metadata` / `parent-thread-id`（官方 CLI 有，本 hop 不发）。
- 不要把 DSH `session_id` 送上 chatgpt.com（抄到 `prompt_cache_key` 和亲和头之后删掉）。
- 不要把 `prompt_cache_retention` 送上去。
- 不要把 Fast 只写 body 不写 `x-codex-routing-hint`（回显会一直是 default）。
- 不要把 `api` 改成 Completions / Anthropic。
- 不要把 `websocket.ts` 的连接 / 续传态给别的家族，也不要在 WS 升级头里发明 `thread-id` 或 `x-codex-routing-hint`（pi 的 WS 不发）。
- 活测确认前不要把 `DSH_CODEX_WEBSOCKET` 的默认改成开。

## 归因

一线：[openai/codex](https://github.com/openai/codex) tag `rust-v0.162.1`（升钉核对时 npm latest 0.162.1；缓存头按 0.153.4 的源码形状核对）。

| 抄 | 出处 | 本 hop |
|---|---|---|
| `session-id` + `thread-id` + `x-client-request-id`（三者同值） | `codex-rs/codex-api/src/requests/headers.rs` `build_session_headers` | `codexCacheHeaders`：三值都等于 DSH pin（一轮对话一条 thread） |
| WS Responses 协议（`response.create` 帧 / 事件消息 / `response.done` / `previous_response_not_found` / 连接池 5min-55min / SSE 即时回退） | earendil-works/pi `packages/ai/src/api/openai-codex-responses.ts`（仓库即 badlogic/pi-mono 后继） | `websocket.ts`（增量守卫为键序无关比较 + 允许宿主重放多带字段，与 pi 的整串比较不同：本 hop 宿主是 llm-pi-ai，重放键序与服务端 items 不一致） |
| 模型页价格徽标（USD / 1M） | models.dev `openai`；`-fast` 孪生行取 models.dev `vercel` `openai/<id>-fast`（priority 档） | `src/catalog/rates.json`，`npm run rates` 写入（见 [docs/models.md](../../../docs/models.md) 费率表） |
| 同 turn 重试回放 `x-codex-turn-state` | `codex-rs/core/src/client.rs` | `proxy.ts` 重试路径（仅 `family === 'codex'`） |
| Fast → Priority | [#37345](https://github.com/openai/codex/issues/37345) | body `service_tier: priority` + `x-codex-routing-hint` |
| 请求体 zstd（`content-encoding: zstd`） | 官方客户端同款；宿主自带 openai-codex provider 同样压缩 | `request.ts` `encodeCodexBody` |
| 剥 `max_output_tokens` | [#39397](https://github.com/openai/codex/issues/39397) | `request.ts` |
| `pro` / `prolite` 徽章 | [#29243](https://github.com/openai/codex/issues/29243) | `plan.ts` Pro 20x / Pro 5x |
| 目录 | CLI `models.json` + `GET .../codex/models` | `CODEX_MODELS`（取舍见「模型」） |

**不要发明：** 官方 CLI 发、本 hop 不发的头，以及 DSH `session_id` 的去向，见「不要」。

跨家族对照总表见 [`docs/oauth.md`](../../../docs/oauth.md)。
