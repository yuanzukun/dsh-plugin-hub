# Zed（Zed Pro / 试用 / 学生 / 商业套餐）OAuth

本文件是 `src/oauth/zed/` 的设计源。改登录、额度、对话或缓存先改这里再改代码。
跨家族硬规则在 [`docs/rules.md`](../../../docs/rules.md)；故障记录在 [`docs/error.md`](../../../docs/error.md)；对照仓库在 [`docs/oauth.md`](../../../docs/oauth.md)。

Zed 托管 Anthropic / OpenAI / xAI（以及 Google）的模型，全部经 `cloud.zed.dev` 一个入口收发，
按 Zed 编辑器自己的方式调用。本地家族 id：`zed`（订阅登录型 → `src/oauth/zed/`）。

> **接线状态**：注册台接线已落地（models.json 键、families.ts、proxy.ts 三 wire 路由、CHECKS、UI），后又随 2026-10-18 裁定引擎化（见页首引擎节）。


## 上游引擎（引擎即实现，2026-10-18 全过签核、不回退）

登录（RSA loopback + native_app_signin + /me）、模型 token 铸造与重铸、三 wire 的
provider 信封/事件流翻译、plan usage 读全部由运行时下载的 `@magpie-community/opencode-zed-auth`
驱动（[`engine.ts`](engine.ts)；`ZedAuthPlugin` 具名导出，cloud.zed.dev 进桥闭集）。
被删 TS：`transport.ts`、`request.ts` 事件机、`quota.ts`、accounts 的 RSA 登录半段。

**留在本仓**：vault 会话形状（access + refresh JSON 载体，引擎 stateOf 同形）、流程槽与
登录完成回调、目录闭集与活目录读（catalog.ts）、缓存剥除（cache.ts）、恒等 refresh。
usage 的 plan 写回经 client.auth.set 落 vault 并 capture slug 供卡片；`forwardZedEngine`
只做响应管道（协议头照旧 WIRE_ONLY 剥除），并把引擎调用与流泵关进 `upstreamRequest`
的家族超时（first-byte / pre-output budget / idle——包自己的 /completions fetch 只带
调用方 signal，超时强制只能落在这层）。
## 归因（抄什么 / 不要发明什么）

钉住 **`@magpie-community/opencode-zed-auth@0.1.8`**
（本仓 `.local/upstream-magpie/packages/zed/`，MIT；其 `package.json` `repository` 指
magpie-community/plugins 的 `packages/zed`）。该包又是 magpie 内建 Zed 账号的插件化，
其内建对照 **zed-industries/zed `1.23.0`** 的源码（上游 index.mjs:4-6）。以下 `index.mjs:N`
均指该包根的 `index.mjs`。**抄**：

- **登录**（index.mjs:396-445）：每次登录生成 RSA-2048 密钥对；公钥以 URL-safe base64
  **带 padding**（Rust `URL_SAFE` 的写法，index.mjs:349-352）挂 URL；浏览器开
  `zed.dev/native_app_signin?native_app_port=<port>&native_app_public_key=<pub>&system_id=<uuid>`；
  回调落在本机回环端口的**任意路径**（只认 query，index.mjs:404-413），带
  `user_id` + `access_token`（RSA 加密）；本地回 302 到
  `zed.dev/native_app_signin_succeeded`（index.mjs:36, 413）；10 分钟超时（index.mjs:41）。
- **token 解密**（index.mjs:356-369）：先 RSA-OAEP SHA-256；失败再以 `RSA_NO_PADDING`
  手工剥 PKCS#1 v1.5 的 `00 02 <非零> 00 <msg>` 填充（Node/Bun 拒绝直接解 v1.5）。
- **凭据对**：`Authorization: "<user_id> <access_token>"` 服务一切 `/client/*`（index.mjs:157-169），
  另带 `x-zed-system-id`（登录时生成的 machine id）与 UA。**Zed 没有 refresh token**：
  对一直用到被拒（401）为止（index.mjs:24-26）。落地：vault 的 `refreshToken` 槽存
  `{userId, systemId, org, plan, planName, login, name}` JSON（上游同样把余下上下文塞
  OpenCode oauth entry 的 refresh 槽，index.mjs:23-27, 386-392）；`expiresAt =
  MAX_SAFE_INTEGER`（command-code 同款「永久凭据」口径，`src/apikey/command-code/index.ts:146`）。
- **模型 token**（index.mjs:216-246）：每个请求用短时效 model token——
  `POST /client/llm_tokens`，body `{organization_id}`，凭据对签名的 /client 头；内存保存；
  上游 401 或响应头 `x-zed-expired-token` / `x-zed-outdated-token` = 过期，**重铸一次**
  （index.mjs:152, 916-943）。
- **chat**（index.mjs:905-949）：`POST cloud.zed.dev/completions`，body
  `{provider, model, provider_request}`——`provider_request` 就是该厂商自家 API 的请求体；
  请求头：Bearer model token、`x-zed-version: 1.23.0`、
  `x-zed-client-supports-status-messages: true`、
  `x-zed-client-supports-stream-ended-request-completion-status: true`、UA。
- **按模型选协议**（index.mjs:45-52, 256-264）：anthropic → Messages、open_ai → Responses、
  x_ai → chat completions、google → generateContent；`vendorOf` 的 id 前缀猜（claude→
  anthropic、gemini→google、grok→x_ai、其余 open_ai）在包内是死代码，`complete()` 不
  经过（index.mjs:912）。
- **请求体改写**（index.mjs:472-509）：Anthropic 删 `stream`（云端永远流式）并给每个
  `tool_result` 补 `is_error`（缺了 Zed 拒收）；Responses 置 `stream: true`；Chat 置
  `stream: true` 且 `max_tokens` → `max_completion_tokens`。Gemini 删 SDK 自家
  `session_id` 并把模型名写成 `models/<id>`（本 hop 不服务 Gemini，见下）。
- **回复**（index.mjs:513-538, 541-545, 697-903）：上行是换行分隔 JSON，每行
  `{event: <厂商自家流事件>}`、`{status: "stream_ended"}` 或 `{status: {failed: {code, message}}}`
  （wrapped 与否看响应头 `x-zed-server-supports-status-messages`，本 hop 请求头已声明、按响应头判定）；
  下行还原成该厂商自家 SSE（anthropic/responses 带 `event:` 行，chat 只 `data:`，收尾
  `[DONE]`）。**首个「说了话」的事件之前的帧先扣住**：那之前的失败（failed 状态行、
  厂商自家 error 事件、无 stream_ended 的截断）按其状态码整体拒绝（429/402/529……），
  不是 200 里夹错误。失败码→状态码：`upstream_http_<n>`/`http_<n>` 前缀、`rate_limit`→429、
  `overloaded`→529、`billing|payment`→402、`context_length`→400，其余 502（index.mjs:113-126）。
  402 的文案固定为「套餐不含 Zed 托管模型或额度用尽」（index.mjs:131）；401 紧跟重铸之后
  = 登录本身被拒（index.mjs:135）。
- **截断收尾**（index.mjs:650-689，#91）：chat 流在 stream_ended 之前断掉、但已说过话且没有
  半截工具调用 → 以说明文字 + `stop` + `[DONE]` 收尾（`ZED_CUT_SHORT_NOTE`）；说了半截工具
  调用、或一个字没说 → 仍是失败。Anthropic / Responses 截断**不做**此收尾（网关可续），
  chat 流中途失败留在流里（error 帧）。一处刻意偏差：上游合成收尾 chunk 的 `created`
  兜底是 `Math.floor(Date.now()/1000)`（index.mjs:681），本地不落 `Date.now()`，缺省时
  省略该字段（首个 chunk 实际总会带 `created`）。
- **目录**（index.mjs:266-289）：`GET /models`，Bearer model token +
  `x-zed-client-supports-x-ai: true` + UA；过滤 `is_disabled`；TTL 10 分钟（index.mjs:43）。
- **额度**（index.mjs:953-998）：`GET /client/users/me`（15s 超时）——套餐
  （`plans_by_organization[org] ?? plan.plan_v3`）、账期结束（`plan.subscription_period.ended_at`，
  RFC3339）、逾期发票（`plan.has_overdue_invoices` = 模型被暂停）。**Zed 不报已用多少，
  没有用量窗口**。组织选择：默认组织在列表内用默认，否则第一个（index.mjs:183-189）；
  `configuration_by_organization[org].is_zed_model_provider_enabled === false` 的组织拒收
  （index.mjs:193-196）。
- **UA / 指纹**：`Zed/1.23.0 (<os>; <arch>)`，Rust 命名（darwin→macos、arm64→aarch64，
  index.mjs:66-70）。
- **套餐名**（index.mjs:199-202）：`zed_pro`→Pro、`zed_pro_trial`→Pro Trial、
  `zed_business`→Business、`zed_student`→Student、`zed_vip`→VIP、`zed_free`/空→Free。

**不要发明**：别的厂商缓存头（Codex `session-id` / Grok `x-grok-conv-id` / Cline
`X-Task-ID` / WorkBuddy 会话四头）——Zed wire 上没有任何缓存亲和新字段，别造一个；
把 DSH `session_id` 原样发上游；`installation-id` 等上游没发的字段；给 google 模型做
openai↔gemini 翻译（本插件不是第二套 LLM 适配器）。上游的 magpie 专属物**不引入**：
`X-Magpie-Sign-In` 标记、`KEPT` 头、多账号 failover、web-search stand-in、jsonError 的
Go 错误文案复刻（`zed.Me` unmarshal 报文）。

## 文件

| 文件 | 职责 |
|---|---|
| [`index.ts`](index.ts) | 常量（站点/云端/版本/UA/超时）、端点、凭据对 reader（`zedCloud`）、模型令牌铸造、恒等 refresh、静态表 `ZED_MODELS` |
| [`engine.ts`](engine.ts) | 上游引擎适配层：loopback 登录装载、三 wire 转发（`forwardZedEngine`：loader.fetch + Response 管道 + 协议头剥除 + `upstreamRequest` 超时强制）、plan slug 写回捕获、额度映射、cloud.zed.dev 进桥闭集 |
| [`accounts.ts`](accounts.ts) | 登录流程槽（引擎 authorize 的 url 透传 + 回调等待）、后台收尾、身份回写、活目录发现 |
| [`cache.ts`](cache.ts) | 剥 DSH 缓存字段；`dsh-zed` 兜底常量（RSA 登录半段、NDJSON 翻译层、token 铸造与 `/me` 读已随包删除，本目录不再有 request/transport/quota） |
| [`catalog.ts`](catalog.ts) | `/models` 活目录（disabled 过滤、google 过滤、efforts 映射）；静态底表 = `index.ts` 的 `ZED_MODELS`（models.json `zed` 键落地后以文件为准，见页首「接线状态」） |

## 协议（三条路由，一个家族）

Zed 一个入口、四种厂商 wire；DSH `api` 是闭集（`openai-completions | openai-responses |
anthropic-messages`），所以本家族开**三条路由**（OpenCode Go/Zen「一个账号多条协议路由」的
先例反过来用），`baseURL` 都是 `${origin}/zed`，SDK 按各自 api 落
`/zed/v1/{messages,responses,chat/completions}`：

| 路由 id | DSH api | Zed vendor | displayName | 代理路径 |
|---|---|---|---|---|
| `<prefix>-zed` | `anthropic-messages` | anthropic | `Subs · Zed · Anthropic` | `POST /zed/v1/messages` |
| `<prefix>-zed-responses` | `openai-responses` | open_ai | `Subs · Zed · Responses` | `POST /zed/v1/responses` |
| `<prefix>-zed-chat` | `openai-completions` | x_ai | `Subs · Zed · Chat` | `POST /zed/v1/chat/completions` |

`familyOfProvider`：`-zed` / `-zed-responses` / `-zed-chat` 后缀都归 `zed`（互不包含，
顺序无关，同 workbuddy 双 build 的口径）。chat 路由有 efforts 行时带
`compat: { supportsReasoningEffort, thinkingFormat: 'openai' }`（cline 同款条件式）；
Anthropic / Responses 路由**不带** compat（DSH 拒绝，见 docs/rules.md）。请求落到
`forwardZedEngine`，wire 由代理分支显式传入。vendor 两层各管各的：**路由分线**按本仓
目录行的 `vendor` 字段（`zedWireRows`）；**引擎侧** vendor 它自己定——登录时
`fetchModels` 快照的 vendors Map 命中就用它，未命中按 wire 默认（index.mjs:912
`vendors.get(id) ?? WIRE_VENDOR[w.wire]`），本仓目录行引擎看不到，hop 路径也没有
id 前缀猜测（`vendorOf` 在包内是死代码）。

**google 模型不进目录**：其 wire 是 generateContent，DSH 闭集没有对应 api，给它做翻译
就成第二套适配器——过滤掉（`ZED_PICKABLE_VENDORS`），不发明。

## 缓存

Zed 的 wire 上没有缓存亲和新字段（envelope 只有 provider/model/provider_request；上游
只在 gemini 分支删 SDK 自家的 session_id，index.mjs:502-507）。云端有隐式前缀缓存。
策略＝**剥 DSH 缓存字段**（`session_id` / `prompt_cache_key` / `prompt_cache_retention` /
`prompt_cache_options`）＋ `cacheSessionId` 兜底常量 `dsh-zed`（仅分析器可见）。Anthropic
wire 的 `metadata.user_id` 是 Anthropic 自家遥测字段、原样过（GLM 同款字段且 GLM 拿它做
亲和；这里不发明改写）。无 system 停车、无会话头派生——上游没发，就不造。

## 登录

浏览器开 `zed.dev/native_app_signin`（Zed 自家登录，GitHub 等），无 PKCE、无 state、
无设备码——回调直接带凭据。`accountId` = 账号的 GitHub login（fallback：username →
name → legacy id，index.mjs:172-178）。无本机 CLI store 可导入（上游没有 importLocal，
Zed 编辑器自己的凭据在它自家 keychain/db，不在本插件读得着的地方）——**不写 import.ts**。

| 项 | 值 |
|---|---|
| URL | `zed.dev/native_app_signin?native_app_port=&native_app_public_key=&system_id=` |
| 回调 | 回环端口任意路径，query `user_id` + `access_token`；本地 302 → `native_app_signin_succeeded` |
| 解密 | RSA-OAEP SHA-256；失败手工剥 PKCS#1 v1.5 |
| 收尾 | `GET /client/users/me` 定 org/plan/账号名；models-off 的组织拒收；顺带拉一次 `/models` |
| 超时 | 10 分钟（index.mjs:41）；取消走登录槽的 abort |

会话形状（vault 行）：`accessToken` = 访问令牌；`refreshToken` = 上下文 JSON；
`expiresAt` = `MAX_SAFE_INTEGER`；`account` / `planType` / `source: 'oauth'`。

## 模型

**目录源是 `GET /models`**（登录后 10 分钟 TTL，与 cline 同款 `createLiveCatalog`）。
行字段映射：`id`、`display_name`、`max_token_count`→contextWindow、
`max_output_tokens`→maxTokens、`supports_images`→input、`supported_effort_levels[].value`→
reasoningEfforts（值 = Zed 原文拼法；`none` 是 `off` 的值、永不做键；闭集外的拼法丢弃）、
`provider`→`vendor`（目录行新增透传字段，`src/catalog/models.json` 行格式同步加
`vendor`，scripts/models.ts 的 `ROW_FIELDS` 同步）。`is_disabled` 过滤；
**没有 `max_token_count` 的行不进目录**（本地目录必须有真实窗口，不造数——上游
entry() 显示 0，是它家 UI 的事）。静态底表 = 上游登录前的六行声明
（index.mjs:56-63）去掉 gemini 行，每行参数照抄：

| id | vendor | name | contextWindow | maxTokens | input |
|---|---|---|---|---|---|
| `claude-sonnet-5` | anthropic | Claude Sonnet 5 | 1000000 | 64000 | text+image |
| `claude-opus-5-5` | anthropic | Claude Opus 5.5 | 1000000 | 128000 | text+image |
| `claude-haiku-4-5` | anthropic | Claude Haiku 4.5 | 200000 | 64000 | text+image |
| `gpt-5.5` | open_ai | GPT-5.5 | 400000 | 128000 | text+image |
| `grok-4.7` | x_ai | Grok 4.7 | 500000 | 64000 | text+image |

底表**不带 reasoningEfforts**（上游离线表没给 levels，不发明梯子）；登录后活目录带。
价格：Zed 套餐内模型无 USD 价目源——`rates.json` 不收 `zed` 键，不发明数字。

## 额度

`fetchZedQuotaEngine`（引擎 usage；plan slug 由写回捕获补 `/client/users/me` 之外的信息）：

- `planType` = 原始 slug（`zed_pro` 等；plan.ts 的 `ZED_PLAN_NAMES` 分支负责映射卡片名）。
- `account` = whoami 的名字（身份回写 `rememberZedIdentity`）。
- **rows 恒空**：Zed 不报已用量（上游同样没有窗口，index.mjs:79-87）。卡片 = 套餐名。
- 逾期发票 → 抛错（卡片走 error 态）：「this account has an overdue invoice, so its
  models are paused (see zed.dev/account)」。
- 401 → 「<账号>: the Zed sign-in has expired — sign in again」。
- **账期结束时间没有卡片槽**（QuotaStore entry 无此字段，UI 也无渲染位）：丢弃，记在案
  （openQuestions）；要展示得先给卡片加通用槽，不为本家私改。

## 活测

**待维护者真实账号验证**（本接入无真实 Zed 账号；引擎化后 hop 随包，`npm run live -- zed`
的三 wire 检查已在 CHECKS 表里）。
待验清单：

1. `npm run live -- zed` 三条 wire 各一发（anthropic / responses / chat），看
   NDJSON→SSE 还原、usage、截断收尾是否如上游行为。
2. 缓存命中率：`npm run analyze`——Zed 无 wire 亲和字段，命中率即云端隐式前缀缓存的效果，
   预期不因本 hop 请求内容而异（若极低，属云端行为，不是本家可调）。
3. 额度卡片：Pro 账号显示 Pro、逾期账号显示 error。
4. 过期登录：401 后卡片提示重登、重登后恢复。

结论落 [`docs/error.md`](../../../docs/error.md) 才算完成。

## 不采纳（记录在案）

- **`X-Magpie-Sign-In` / `KEPT` 标记体系**：magpie 的多账号网关语义；本插件每家族只用
  active 账号，401 直接透传（消息已说明是登录过期）。
- **多 Zed 账号并发调度**：同上，vault 支持多账号切换，但不做请求间 failover。
- **web-search stand-in**：magpie 自带能力，与本 hop 无关。
- **上游 `usage()` 的 save 回写 plan 变化**：本地由 `rememberZedIdentity` 在额度链上做
  同等事（每次刷新回写 planType），不重复实现。
- **`jsonError` 的 Go 文案复刻**（`json: cannot unmarshal … into Go value of type
  zed.Me`）：上游为对齐 magpie 内建的错误字符串；本地说「an unreadable account」即可。
- **gemini 翻译**：见「协议」——google vendor 过滤，不做 openai↔generateContent 适配。
