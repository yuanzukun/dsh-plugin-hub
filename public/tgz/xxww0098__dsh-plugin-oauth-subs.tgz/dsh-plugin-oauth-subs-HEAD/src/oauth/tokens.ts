/** One refresh owner per stored login and credential version. */

import { deleteSession, getStoredSession, updateAccountSession } from './store.js'
import { RequestError } from '../utils/http.js'
import { isPermanentRefreshFailure } from './errors.js'

/** OAuth token-endpoint error vocabulary, re-exported from the shared leaf. */
export { OAuthEndpointError, oauthCodeOf, oauthError, isPermanentRefreshFailure } from './errors.js'

/**
 * The login is missing or gone and only the user can fix it. 403, so the host
 * classifies it AUTH and does not retry; the proxy answers by `status` alone.
 */
export class LoginRequiredError extends RequestError {
  constructor(message: string) {
    super(403, message)
    this.name = 'LoginRequiredError'
  }
}

/**
 * A login imported from a vendor CLI whose own store has also expired. The
 * plugin never redeems the CLI's refresh token (where it rotates, that logs
 * the CLI out), so only the user can fix it — by running that CLI. Not permanent: the
 * login stays and the next reread picks up whatever the CLI wrote.
 */
export class ImportedLoginStale extends LoginRequiredError {
  constructor(displayName: string, cli: string, why = 'is stale') {
    super(`${displayName} imported login ${why}; run ${cli} or use browser login`)
    this.name = 'ImportedLoginStale'
  }
}

/** A reread is adopted only when it outlives this margin. */
const IMPORTED_MIN_TTL_MS = 15_000

/** Rotations the store refused that this process still holds for a retry. */
const HELD_ROTATION_CAP = 8

/** Fields a reread may replace on a stored login; account labels stay put. */
const IMPORTED_TOKEN_FIELDS = ['accessToken', 'refreshToken', 'idToken', 'expiresAt']

/**
 * How long a transient refresh failure suppresses another attempt for the same
 * credential version. Mirrors CLIProxyAPI's refreshFailureBackoff: without it,
 * every request during a token-endpoint outage re-hammers the endpoint.
 */
export const REFRESH_FAILURE_BACKOFF_MS = 5 * 60_000

/**
 * An expired token cannot fall back to serving, so its backoff is short: the
 * last failure is replayed for this long instead of re-hitting the endpoint on
 * every request, then the next request tries again.
 */
export const REFRESH_EXPIRED_RETRY_MS = 10_000

/**
 * How long an unsettled exchange stays the single owner of its credential
 * version. A second redemption of a rotating refresh token races the first
 * (invalid_grant) — only an exchange hung past this cap is given up on.
 */
export const REFRESH_LATE_CAP_MS = 120_000

/**
 * Longest a request waits on a refresh. The refresh itself keeps running as
 * the single owner of that credential version — a second redemption of a
 * rotating refresh token would be answered with invalid_grant.
 */
export const REFRESH_WAIT_MS = 30_000

/**
 * How long one attempt waits on a refresh exchange (pi-ai bounds the same
 * exchange at 15s). Family refresh calls carry no AbortSignal: a token endpoint
 * that accepts the connection and stalls would otherwise make every request
 * for that account pay the full waiter timeout instead of failing over to a
 * still-valid token. The exchange itself keeps running (REFRESH_LATE_CAP_MS).
 */
export const REFRESH_EXCHANGE_TIMEOUT_MS = 20_000

class RefreshTimeout extends Error {
  constructor(displayName, timeoutMs) {
    super(`${displayName} token refresh timed out after ${timeoutMs}ms`)
    this.name = 'RefreshTimeout'
  }
}

class RefreshExchangeTimeout extends Error {
  constructor(displayName, timeoutMs) {
    super(`${displayName} token exchange timed out after ${timeoutMs}ms`)
    this.name = 'RefreshExchangeTimeout'
  }
}

function waitFor(promise, timeoutMs, onTimeout) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(onTimeout()), timeoutMs)
    timer.unref?.()
    promise.then(
      (value) => { clearTimeout(timer); resolve(value) },
      (error) => { clearTimeout(timer); reject(error) },
    )
  })
}

export class TokenManager {
  declare provider: string
  declare authPath: string
  declare displayName: string
  declare preemptMs: number
  /** Injected refresh callback; distinct from the private #refresh method. */
  declare refresh: any
  /** Family grant codes that are permanent beyond the shared ones. */
  declare permanentCodes: readonly string[]
  declare onRemoved: any
  /**
   * `{ is(session), reread(session), cli, identity?(session) }` — logins owned
   * by a vendor CLI's store; `identity` names the account where the store has one.
   */
  declare imported: any
  /** version → when its imported store was last reread (throttles rereads that find nothing newer). */
  declare rereadAt: Map<any, number>
  declare refreshWaitMs: number
  declare exchangeTimeoutMs: number
  /** version → the exchange that owns it: { at, late, promise }. */
  declare inflight: Map<any, any>
  declare failures: Map<any, any>
  /** version → the rotation the store refused; see `#holdRotation`. */
  declare heldRotations: Map<any, any>
  /** Store writer seam; tests inject a refusing writer to pin the held-rotation recovery. */
  declare updateSession: any
  declare sources: WeakMap<object, any>

  constructor({ provider, authPath, displayName, preemptMs, refresh, permanentCodes = [], onRemoved, imported, refreshWaitMs = REFRESH_WAIT_MS, exchangeTimeoutMs = REFRESH_EXCHANGE_TIMEOUT_MS, updateSession = updateAccountSession }: any) {
    this.provider = provider
    this.authPath = authPath
    this.displayName = displayName
    this.preemptMs = preemptMs
    this.refreshWaitMs = refreshWaitMs
    this.exchangeTimeoutMs = exchangeTimeoutMs
    this.refresh = refresh
    this.permanentCodes = permanentCodes
    this.onRemoved = onRemoved
    this.imported = imported
    this.rereadAt = new Map()
    this.inflight = new Map()
    this.failures = new Map()
    this.heldRotations = new Map()
    this.updateSession = updateSession
    this.sources = new WeakMap()
  }

  async session(id) {
    return (await this.account(id)).session
  }

  /** The stored-account row that produced this session, when known. */
  sourceOf(session) {
    return this.sources.get(session)
  }

  async account(id) {
    const source = await getStoredSession(this.provider, id, this.authPath)
    if (!source) throw new LoginRequiredError(`${this.displayName} is not logged in`)
    return this.#resolve(source, { force: false })
  }

  /**
   * Refresh the stored login regardless of its expiry window — the proxy calls
   * this after an upstream 401 (CLIProxyAPI's tryRefreshAfterUnauthorized). A
   * concurrent refresh that already rotated the failed access token is reused
   * instead of forcing a second redemption of the same refresh token.
   */
  async refreshNow(id, failedAccessToken) {
    const source = await getStoredSession(this.provider, id, this.authPath)
    if (!source) return undefined
    const rotated = typeof failedAccessToken === 'string' && failedAccessToken.length > 0
      && source.session.accessToken !== failedAccessToken
    if (rotated && source.session.expiresAt - Date.now() > this.preemptMs) {
      this.sources.set(source.session, source)
      return source
    }
    return this.#resolve(source, { force: true })
  }

  async #resolve(source, { force }) {
    const left = source.session.expiresAt - Date.now()
    if (!force && left > this.preemptMs) return this.#serve(source)
    if (!force) {
      // A failure is keyed by credential version, so a new login or rotated
      // token starts clean. A still-valid token keeps serving through the
      // long backoff; an expired one replays the failure only briefly, or one
      // blip would fail every request for the whole window.
      const failed = this.failures.get(source.version)
      const age = failed ? Date.now() - failed.at : Infinity
      if (left > 0 && age < REFRESH_FAILURE_BACKOFF_MS) return this.#serve(source)
      if (left <= 0 && age < REFRESH_EXPIRED_RETRY_MS) throw failed.error
      // A reread that found nothing newer keeps this version: while it is still
      // valid, reread at most once per window instead of on every request
      // (a Keychain reread spawns a process).
      const reread = this.rereadAt.get(source.version)
      if (left > 0 && reread !== undefined && Date.now() - reread < REFRESH_EXPIRED_RETRY_MS) return this.#serve(source)
      if (left > this.refreshWaitMs) {
        this.#start(source)
        return this.#serve(source)
      }
    }
    let current
    try {
      current = await waitFor(this.#start(source), this.refreshWaitMs, () => new RefreshTimeout(this.displayName, this.refreshWaitMs))
    } catch (error) {
      // A transient endpoint failure must not kill a request whose access
      // token is still valid. Forced refreshes (post-401) rethrow instead:
      // the proxy needs a rotated token or nothing.
      const transient = error instanceof RefreshTimeout
        || error instanceof RefreshExchangeTimeout
        || this.failures.get(source.version)?.error === error
      if (!force && transient && source.session.expiresAt > Date.now()) return this.#serve(source)
      throw error
    }
    return this.#serve(current)
  }

  #serve(source) {
    this.sources.set(source.session, source)
    return source
  }

  /**
   * Join or start the exchange that owns `source.version` and wait for it at
   * most exchangeTimeoutMs. A timed-out exchange keeps running as the owner —
   * its result is still persisted — until it settles or REFRESH_LATE_CAP_MS
   * passes; only then may a second exchange redeem the same refresh token.
   */
  #start(source) {
    let entry = this.inflight.get(source.version)
    if (!entry || Date.now() - entry.at >= REFRESH_LATE_CAP_MS) {
      const owner: any = { at: Date.now(), late: false }
      owner.promise = this.#refresh(source, owner)
      const clear = () => { if (this.inflight.get(source.version) === owner) this.inflight.delete(source.version) }
      owner.promise.then(clear, clear)
      this.inflight.set(source.version, owner)
      entry = owner
    }
    const attempt = waitFor(entry.promise, this.exchangeTimeoutMs, () => {
      entry.late = true
      const error = new RefreshExchangeTimeout(this.displayName, this.exchangeTimeoutMs)
      this.failures.set(source.version, { at: Date.now(), error })
      return error
    })
    attempt.catch(() => {})
    return attempt
  }

  /** The stored login that superseded `source` (another writer rotated it), if still usable. */
  async #successor(source) {
    const current = await getStoredSession(this.provider, source.id, this.authPath)
    if (!current || current.version === source.version || current.session.expiresAt <= Date.now()) return undefined
    return current
  }

  async remember(session, fields) {
    const source = this.sources.get(session)
    if (!source) return
    await updateAccountSession(this.provider, source, { ...session, ...fields }, this.authPath)
  }

  /**
   * An imported login shares its refresh token with the vendor CLI: reread the
   * CLI's store instead of exchanging, and never write that store.
   */
  async #reread(session) {
    const fresh = await this.imported.reread(session)
    if (!(fresh?.expiresAt > Date.now() + IMPORTED_MIN_TTL_MS)) throw new ImportedLoginStale(this.displayName, this.imported.cli)
    // The CLI now holds another account: its tokens must not land on this row.
    const was = this.imported.identity?.(session)
    const now = this.imported.identity?.(fresh)
    if (was && now && was !== now) throw new ImportedLoginStale(this.displayName, this.imported.cli, 'belongs to another account now')
    const next = { ...session }
    for (const key of IMPORTED_TOKEN_FIELDS) if (fresh[key] !== undefined) next[key] = fresh[key]
    return next
  }

  /**
   * Keep a rotation the store refused, under the version it was exchanged for.
   * The endpoint spends the refresh token the moment it answers, so redeeming
   * the stored one again is `invalid_grant` — the login's death, not a retry.
   * In-memory only: a restart loses it, exactly as magpie's `held` does, and
   * the next process has a fresh chance to save whatever the vendor still
   * honours. Capped so a long-lived host does not keep every pair forever.
   */
  #holdRotation(version, next) {
    this.heldRotations.delete(version)
    this.heldRotations.set(version, next)
    while (this.heldRotations.size > HELD_ROTATION_CAP) {
      const oldest = this.heldRotations.keys().next().value
      if (oldest === undefined) break
      this.heldRotations.delete(oldest)
    }
  }

  async #refresh(source, owner) {
    // A rotation this same stored session already paid for is the only way
    // forward: persist it again instead of buying a second one.
    const held = this.heldRotations.get(source.version)
    let next
    let exchanged = false
    try {
      if (held) {
        next = held
      } else if (this.imported?.is(source.session)) {
        this.rereadAt.set(source.version, Date.now())
        next = await this.#reread(source.session)
      } else {
        next = await this.refresh(source.session)
        exchanged = true
      }
    } catch (error) {
      // A late verdict arrives after its waiters gave up: keep the login and
      // let the next timely exchange decide.
      if (!isPermanentRefreshFailure(error, this.permanentCodes) || owner.late) {
        this.failures.set(source.version, { at: Date.now(), error })
        throw error
      }
      const removed = await deleteSession(this.provider, this.authPath, source.id, source)
      if (removed) this.onRemoved?.()
      // invalid_grant for a token another writer already rotated.
      const successor = removed ? undefined : await this.#successor(source)
      if (successor) return successor
      throw new LoginRequiredError(`${this.displayName} login expired; sign in again`)
    }
    this.failures.delete(source.version)
    // Version-guarded: a late result cannot revive a logged-out or replaced login.
    let saved
    try {
      saved = await this.updateSession(this.provider, source, next, this.authPath)
    } catch (error) {
      // The exchange succeeded and the store did not take it. Keep the pair so
      // the next attempt can persist it; re-redeeming the spent token would
      // trade a retryable write failure for a forced re-login.
      if (exchanged) this.#holdRotation(source.version, next)
      throw error
    }
    // A version miss means another writer owns the login now: its result wins,
    // and a held pair from this source is dead weight.
    this.heldRotations.delete(source.version)
    if (saved) return saved
    const successor = await this.#successor(source)
    if (successor) return successor
    throw new Error(`${this.displayName} session changed; retry the request`)
  }
}

/**
 * `run`'s `refresh` hook: after an upstream 401, force-refresh the stored login
 * behind `get()` once and hand the rotated session to `set`. False when there
 * is none or the refresh fails — `run` then forwards the upstream's own 401.
 */
export function forcedRefresh(tokens, get: () => any, set: (session: any) => void) {
  return async () => {
    const session = get()
    const source = typeof tokens?.sourceOf === 'function' ? tokens.sourceOf(session) : undefined
    if (!source || typeof tokens.refreshNow !== 'function') return false
    const next = await tokens.refreshNow(source.id, session.accessToken).catch(() => undefined)
    if (!next?.session) return false
    set(next.session)
    return true
  }
}
