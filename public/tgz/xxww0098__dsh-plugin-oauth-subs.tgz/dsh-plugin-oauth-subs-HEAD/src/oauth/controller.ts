/**
 * Auth controller behind the Settings page RPC: owns the per-family token
 * managers, quota store and flow managers, builds the Settings snapshot, and
 * syncs routes to the host. The work behind each entry point lives in plain
 * functions that take the controller: login.ts (flows, keys, imports),
 * account-quota.ts, self-update.ts, account-marks.ts, and each family's
 * accounts.ts (auto-import, identity, catalog discovery, login completion).
 */

import { dirname, join } from 'node:path'
import { OAuthFlowManager } from './flow.js'
import { DeviceFlowManager } from './grok/device-flow.js'
import { GlmCliFlowManager } from './glm/cli-flow.js'
import { KiroIdcFlowManager } from './kiro/idc-flow.js'
import {
  accountIdOf,
  asVault,
  deleteSession,
  getSession,
  listStoredSessions,
  loadStore,
  PROVIDER_IDS,
  publicSession,
  purgeRetiredSessions,
  switchAccount,
} from './store.js'
import { GLM_MODELS } from './glm/index.js'
import { CursorPollFlowManager } from './cursor/pkce-flow.js'
import { refreshCursorCatalog } from './cursor/catalog.js'
import { refreshOllamaCatalog } from '../apikey/ollama/catalog.js'
import { refreshCommandCode } from '../apikey/command-code/index.js'
import { catalogPricing, catalogRateTimeOfDay } from '../catalog/index.js'
import { kiroCatalogModels, refreshKiroCatalog } from './kiro/catalog.js'
import { configureKimiIdentity } from './kimi/index.js'
import { refreshKimiCatalog } from './kimi/catalog.js'
import { refreshDevinCatalog } from './devin/catalog.js'
import { refreshClineCatalog } from './cline/catalog.js'
import { refreshCommandCodeCatalog } from '../apikey/command-code/catalog.js'
import { opencodeGoFilePath, OpencodeGoStore } from '../apikey/opencode-go/store.js'
import {
  APIKEY_FAMILY_IDS,
  buildProviders,
  catalogProviders,
  describeCatalog,
  describeProviders,
  MODEL_FAMILY_IDS,
} from './models.js'
import { ensureOpencodeGoRoute, ensureOpencodeZenRoute, filterProviders, syncHarnessModels } from './harness-sync.js'
import { familyCatalogInputs, OAUTH_FAMILIES } from './families.js'
import { catalogRouteSignature } from './catalog-sync.js'
import { ModelSwitch } from './model-switch.js'
import { buildTokenManagers } from './token-managers.js'
import { TokenManager } from './tokens.js'
import { QuotaStore } from './quota.js'
import { DEFAULT_PROFILE, installRelease, localUpdateInfo } from '../utils/update.js'
import { readUpdatePrefs, readUpdateState, updatePrefsPath, updateStatePath } from '../utils/update-prefs.js'
import { outboundFetch } from '../utils/outbound.js'
import { completeCommandCode, maybeAutoImportCommandCode } from '../apikey/command-code/accounts.js'
import { maybeAutoImportOllama } from '../apikey/ollama/accounts.js'
import {
  clearOpencodeGo,
  hasOpencodeGoKey,
  logoutOpencodeGo,
  opencodeGoSnapshot,
  refreshOpencodeGoQuota,
  saveOpencodeGo,
  switchOpencodeGo,
} from '../apikey/opencode-go/accounts.js'
import { markSignedOut } from './account-marks.js'
import { accountsWithQuota, consumeReset, ensureAccountQuota, refreshQuota } from './account-quota.js'
import { completeClineDevice, maybeAutoImportCline } from './cline/accounts.js'
import { revokeChatgptAccounts } from './chatgpt/accounts.js'
import { refreshChatgptCatalog } from './chatgpt/catalog.js'
import {
  completeCursor,
  maybeAutoImportCursor,
  resolveCursorIdentities,
} from './cursor/accounts.js'
import { maybeAutoImportDevin } from './devin/accounts.js'
import { completeGlm, resolveGlmIdentities, upgradeGlmLegacyBearers } from './glm/accounts.js'
import { completeKimiDevice, maybeAutoImportKimi } from './kimi/accounts.js'
import { completeKiroIdc } from './kiro/accounts.js'
import { completeDevice, completePkce, importFrom, login, useKey } from './login.js'
import {
  checkUpdate,
  fetchChangelog,
  runAutoUpdate,
  setAutoUpdate,
  startAutoUpdateWatch,
  stopAutoUpdateWatch,
} from './self-update.js'

/** How often the background sweep re-checks stored credential expiry. */
export const TOKEN_SWEEP_INTERVAL_MS = 60_000

export class AuthController {
  // JS-style fields: each is assigned in the constructor below, or — for the
  // outbound-proxy pair — wired on by src/index.ts. `declare` keeps these
  // type-only, so the emitted JavaScript is byte-identical to before.
  declare authPath: string
  declare prefix: string
  declare origin: () => string
  declare settings: any
  declare credentials: any
  declare grokLogin: string
  declare profile: string
  declare patchPath: string | undefined
  declare readFileFn: any
  declare updateEnv: any
  declare onAuthChanged: ((provider?: string) => void) | undefined
  declare models: ModelSwitch
  declare flows: OAuthFlowManager
  declare devices: DeviceFlowManager
  declare glmFlows: GlmCliFlowManager
  declare kiroFlows: KiroIdcFlowManager
  declare cursorFlows: CursorPollFlowManager
  declare cursorAutoImport: boolean
  declare cursorImport: any
  declare cursorAutoImportTried: boolean
  declare cursorDiscover: any
  declare ollamaAutoImport: boolean
  declare ollamaAutoImportTried: boolean
  declare ollamaDiscover: any
  declare kiroDiscover: any
  declare kimiAutoImport: boolean
  declare kimiAutoImportTried: boolean
  declare kimiDiscover: any
  declare devinAutoImport: boolean
  declare devinImport: any
  declare devinAutoImportTried: boolean
  declare devinDiscover: any
  declare clineDiscover: any
  declare chatgptDiscover: any
  declare clineAutoImport: boolean
  declare clineAutoImportTried: boolean
  declare commandCodeAutoImport: boolean
  declare commandCodeAutoImportTried: boolean
  declare commandCodeImport: any
  declare commandCodeDiscover: any
  declare lastError: Map<string, any>
  declare finalizing: Set<string>
  declare claims: Map<string, number>
  declare tokens: Record<string, TokenManager>
  declare quota: QuotaStore
  identityTried = new Map<string, number>()
  #snapshotRun: Promise<Record<string, any>> | undefined
  #revalidateQuotaNext = false
  #syncQueue: Promise<void> = Promise.resolve()
  declare fetchFn: any
  declare opencodeGo: any
  declare opencodeGoAdopted: boolean
  declare tokenSweepTimer: any
  declare outboundProxy: any
  declare setOutboundProxy: any
  declare usage: any
  declare arena: any
  declare installReleaseFn: any
  declare autoUpdate: boolean
  declare updateState: any
  declare prefsReady: Promise<void>
  /** Resolves once the families signed in at construction time are seeded. */
  declare loginsReady: Promise<void>
  declare autoUpdateTimer: any
  declare prefsFile: string
  declare stateFile: string
  constructor({ authPath, prefix, origin, settings, patchPath, credentials, grokLogin = 'device', onAuthChanged, models, fetchFn = outboundFetch, quotaTtlMs, profile, readFileFn, updateEnv, installReleaseFn = installRelease, cursorAutoImport, cursorImport, cursorDiscover, ollamaAutoImport, ollamaDiscover, kiroDiscover, kimiAutoImport, kimiDiscover, devinAutoImport, devinImport, devinDiscover, clineDiscover, clineAutoImport, commandCodeAutoImport, commandCodeImport, commandCodeDiscover, chatgptDiscover }: any) {
    this.authPath = authPath
    this.prefix = prefix
    this.origin = origin
    this.settings = settings
    this.patchPath = patchPath
    this.credentials = credentials
    this.grokLogin = grokLogin
    this.profile = profile || DEFAULT_PROFILE
    this.readFileFn = readFileFn
    this.updateEnv = updateEnv
    this.installReleaseFn = installReleaseFn
    this.prefsFile = updatePrefsPath(authPath)
    this.stateFile = updateStatePath(authPath)
    this.prefsReady = Promise.all([
      readUpdatePrefs(this.prefsFile),
      readUpdateState(this.stateFile),
    ]).then(([prefs, state]) => {
      this.autoUpdate = prefs.autoUpdate
      this.updateState = state
    })
    // Any login-state change re-arms the throttled identity discovery.
    this.onAuthChanged = (provider) => {
      this.identityTried.clear()
      return onAuthChanged?.(provider)
    }
    this.models = models ?? new ModelSwitch()
    this.loginsReady = (async () => {
      await this.models.ready
      // Retired families have no logout button: delete their tokens from
      // auth.json instead of leaving them there for good. Only a configured
      // path — an instance without one must never reach for the default dir.
      if (typeof authPath === 'string' && authPath) await purgeRetiredSessions(authPath).catch(() => [])
      await this.#seedSeenLogins()
    })()
    this.flows = new OAuthFlowManager()
    this.devices = new DeviceFlowManager()
    this.glmFlows = new GlmCliFlowManager()
    this.kiroFlows = new KiroIdcFlowManager()
    this.cursorFlows = new CursorPollFlowManager()
    // node:test sets NODE_TEST_CONTEXT; do not harvest the agent/IDE login into unit snapshots.
    this.cursorAutoImport = cursorAutoImport ?? !process.env.NODE_TEST_CONTEXT
    this.cursorImport = cursorImport && typeof cursorImport === 'object' ? cursorImport : {}
    this.cursorAutoImportTried = false
    this.cursorDiscover = typeof cursorDiscover === 'function'
      ? cursorDiscover
      : (process.env.NODE_TEST_CONTEXT ? undefined : refreshCursorCatalog)
    this.ollamaAutoImport = ollamaAutoImport ?? !process.env.NODE_TEST_CONTEXT
    this.ollamaAutoImportTried = false
    this.ollamaDiscover = typeof ollamaDiscover === 'function'
      ? ollamaDiscover
      : (process.env.NODE_TEST_CONTEXT ? undefined : refreshOllamaCatalog)
    this.kiroDiscover = typeof kiroDiscover === 'function'
      ? kiroDiscover
      : (process.env.NODE_TEST_CONTEXT ? undefined : ((session) => refreshKiroCatalog(session, { fetchFn })))
    this.kimiAutoImport = kimiAutoImport ?? !process.env.NODE_TEST_CONTEXT
    this.kimiAutoImportTried = false
    this.kimiDiscover = typeof kimiDiscover === 'function'
      ? kimiDiscover
      : (process.env.NODE_TEST_CONTEXT ? undefined : ((session) => refreshKimiCatalog(session, { fetchFn })))
    this.devinAutoImport = devinAutoImport ?? !process.env.NODE_TEST_CONTEXT
    this.devinImport = devinImport && typeof devinImport === 'object' ? devinImport : {}
    this.devinAutoImportTried = false
    this.devinDiscover = typeof devinDiscover === 'function'
      ? devinDiscover
      : (process.env.NODE_TEST_CONTEXT ? undefined : ((session) => refreshDevinCatalog(session, { fetchFn })))
    this.chatgptDiscover = typeof chatgptDiscover === 'function'
      ? chatgptDiscover
      : (process.env.NODE_TEST_CONTEXT ? undefined : ((session) => refreshChatgptCatalog(session, { fetchFn })))
    this.clineDiscover = typeof clineDiscover === 'function'
      ? clineDiscover
      : (process.env.NODE_TEST_CONTEXT ? undefined : ((session) => refreshClineCatalog(session, { fetchFn })))
    this.clineAutoImport = clineAutoImport ?? !process.env.NODE_TEST_CONTEXT
    this.clineAutoImportTried = false
    // The Command Code CLI's auth.json is its only credential store — harvest
    // it once like cursor's IDE import, so an installed CLI means instant login.
    this.commandCodeDiscover = typeof commandCodeDiscover === 'function'
      ? commandCodeDiscover
      : (process.env.NODE_TEST_CONTEXT ? undefined : ((session) => refreshCommandCodeCatalog(session, { fetchFn })))
    this.commandCodeAutoImport = commandCodeAutoImport ?? !process.env.NODE_TEST_CONTEXT
    this.commandCodeImport = commandCodeImport && typeof commandCodeImport === 'object' ? commandCodeImport : {}
    this.commandCodeAutoImportTried = false
    configureKimiIdentity(typeof authPath === 'string' ? dirname(authPath) : undefined)
    this.lastError = new Map()
    this.finalizing = new Set()
    this.claims = new Map()
    this.tokens = buildTokenManagers({
      authPath: this.authPath,
      fetchFn,
      cursorImport: this.cursorImport,
      // Resolves this.onAuthChanged at fire time, like the inline closures did.
      onAuthChanged: (provider) => this.onAuthChanged?.(provider),
    })
    this.quota = new QuotaStore({
      tokens: this.tokens,
      fetchFn,
      ttlMs: quotaTtlMs,
      snapshotPath: typeof authPath === 'string' && authPath ? join(dirname(authPath), 'quota-snapshot.json') : undefined,
    })
    this.fetchFn = fetchFn
    this.opencodeGo = (typeof authPath === 'string' && authPath)
      ? new OpencodeGoStore({ path: opencodeGoFilePath(authPath), fetchFn })
      : undefined
    this.opencodeGoAdopted = false
  }

  claim(provider) {
    const next = (this.claims.get(provider) ?? 0) + 1
    this.claims.set(provider, next)
    return next
  }

  /**
   * Grandfather every family already signed in when this plugin instance
   * started. The login default (a family that signs in starts with every row
   * off) must only hit logins that happen while this code runs, so an upgrade
   * never turns an existing install's models off.
   */
  async #seedSeenLogins() {
    let families: string[]
    try {
      const store = await loadStore(this.authPath)
      families = PROVIDER_IDS.filter((family) => asVault(family, store[family]).activeId !== undefined)
    } catch {
      // An unreadable store cannot say what was signed in; seed nothing rather
      // than guess (a broken store fails loggedIn() on this same sync anyway).
      return
    }
    await this.models.seedSeenLogins(families)
  }

  async loggedIn() {
    // Driven by PROVIDER_IDS (same order the hand-written literal kept) so a
    // new family cannot be missed; sequential awaits like the literal had.
    const out: Record<string, boolean> = {}
    for (const family of PROVIDER_IDS) {
      out[family] = (await getSession(family, this.authPath)) !== undefined
    }
    return out
  }

  async status(provider) {
    const session = await getSession(provider, this.authPath)
    const detail = this.lastError.get(provider)
    const pub = publicSession(provider, session)
    const activeId = session ? accountIdOf(provider, session) : undefined
    return {
      loggedIn: session !== undefined,
      busy: this.flows.isBusy(provider) || this.devices.isBusy(provider) || this.glmFlows.isBusy(provider) || this.kiroFlows.isBusy(provider) || this.cursorFlows.isBusy(provider) || this.finalizing.has(provider),
      ...pub,
      quota: this.quota.peek(provider, activeId),
      ...(detail === undefined ? {} : { detail }),
    }
  }

  async #glmModels() {
    void (await getSession('glm', this.authPath))
    return GLM_MODELS
  }

  /**
   * The one model-list bag every llm-pi-ai projection consumes — catalog(),
   * #buildSnapshot's catalogProviders and buildProviders — straight off the
   * family registry (familyCatalogInputs), so no family can be missed at one
   * site. GLM's rows stay the explicit async seat: resolved behind the glm
   * session read above, never read synchronously from the registry.
   */
  async #catalogInputs() {
    return familyCatalogInputs({ glmModels: await this.#glmModels() })
  }

  async catalog() {
    // Un-overridden build: describeCatalog applies `contexts` itself so rows
    // keep their catalog default and ceiling next to the effective window,
    // and setContext can cap edits at the row's own maximum.
    return catalogProviders({
      prefix: this.prefix,
      origin: this.origin(),
      ...await this.#catalogInputs(),
    })
  }

  /**
   * Startup discovery for every signed-in family with a live catalog. The
   * picker otherwise keeps the static floor until someone logs in or hits
   * quota refresh, which is how region-gated / retired rows stay offered.
   * Re-syncs once if any family's picker rows changed.
   */
  async warmCatalogs() {
    const families = [...OAUTH_FAMILIES.values()].filter((family) => family.quota?.discover && family.catalogModels)
    const before = new Map(families.map((family) => [family.id, catalogRouteSignature(family.catalogModels!())]))
    await Promise.all(families.map(async (family) => {
      const tokens = this.tokens[family.id]
      if (!tokens) return
      let session
      try {
        session = await tokens.session(undefined)
      } catch {
        return // not signed in
      }
      await family.quota!.discover!.run(this, session)
    }))
    const changed = families.some((family) => catalogRouteSignature(family.catalogModels!()) !== before.get(family.id))
    if (changed && this.settings) await this.sync().catch(() => undefined)
  }

  /**
   * RPC payload for the Settings page. The Settings half is a classic script
   * that reads this as plain JSON. Leaving the return type to inference made
   * the emitted `snapshot` / `switchAccount` / `setModels` declarations ~25k
   * lines each (they all return this method), roughly doubling the published
   * `lib/`. The callers are untyped on purpose — do not "restore" the inferred
   * type without re-checking `lib/` size.
   */
  snapshot(fresh = false, opts: { revalidateQuota?: boolean } = {}): Promise<Record<string, any>> {
    // Concurrent polls share one build; cleared on settle so a failure never
    // pins. A post-mutation caller passes `fresh` so it never joins a build
    // that started before its write — later polls join the fresh one.
    // `revalidateQuota` is sticky on purpose: the page sends it when the user
    // (re)enters the quota view, and if a build is already running the flag
    // survives until the next build picks it up — at most one poll later.
    if (opts.revalidateQuota) this.#revalidateQuotaNext = true
    if (fresh || !this.#snapshotRun) {
      const run = this.#buildSnapshot().finally(() => {
        if (this.#snapshotRun === run) this.#snapshotRun = undefined
      })
      this.#snapshotRun = run
    }
    return this.#snapshotRun
  }

  async #buildSnapshot(): Promise<Record<string, any>> {
    const revalidateQuota = this.#revalidateQuotaNext
    this.#revalidateQuotaNext = false
    await this.models.ready
    await this.prefsReady
    await resolveGlmIdentities(this)
    await upgradeGlmLegacyBearers(this)
    await maybeAutoImportCursor(this)
    await resolveCursorIdentities(this)
    await maybeAutoImportOllama(this)
    await maybeAutoImportKimi(this)
    await maybeAutoImportDevin(this)
    await maybeAutoImportCline(this)
    await maybeAutoImportCommandCode(this)
    const loggedIn = await this.loggedIn()
    const origin = this.origin()
    const opencodeGoApiKeySet = await hasOpencodeGoKey(this)
    const catalogInputs = await this.#catalogInputs()
    const catalog = catalogProviders({
      prefix: this.prefix,
      origin,
      ...catalogInputs,
    })
    const selected = this.models.selectedForSync(catalog)
    const providers = filterProviders(buildProviders({
      prefix: this.prefix,
      origin,
      loggedIn,
      contexts: this.models.contexts,
      ...catalogInputs,
    }), selected)
    // Every family at once: the cold read is the slowest upstream, not the sum.
    await Promise.all(PROVIDER_IDS.map((family) => (loggedIn[family] ? ensureAccountQuota(this, family, revalidateQuota) : this.quota.clear(family))))
    const enabledKeys = this.models.enabledKeys(catalog)
    const opencodeGo = await this.opencodeGoSnapshot()
    // Account rows per OAuth family, in PROVIDER_IDS order.
    const familyAccounts = await Promise.all(PROVIDER_IDS.map((family) => accountsWithQuota(this, family)))
    // Same shape the hand-written literal produced: one status read per family
    // (sequential, in PROVIDER_IDS order) so a new family cannot be missed;
    // opencode-go is an apikey family outside PROVIDER_IDS and stays explicit.
    const accounts: Record<string, any> = {}
    for (let index = 0; index < PROVIDER_IDS.length; index++) {
      const family = PROVIDER_IDS[index]
      const rows = familyAccounts[index]
      accounts[family] = { ...(await this.status(family)), activeId: rows.find((row) => row.active)?.id, accounts: rows }
    }
    accounts['opencode-go'] = opencodeGo
    return {
      origin,
      profile: this.profile,
      grokLogin: this.grokLogin,
      catalog: describeCatalog(catalog, {
        enabledKeys,
        awaitingPick: this.models.awaitingPick,
        contexts: this.models.contexts,
        rates: Object.fromEntries([
          ...kiroCatalogModels().filter((model: any) => model.rate).map((model: any) => [`kiro/${model.id}`, model.rate]),
        ]),
        pricing: catalogPricing(),
        pricingTimeOfDay: catalogRateTimeOfDay(),
        loggedIn: {
          ...loggedIn,
          ...Object.fromEntries(APIKEY_FAMILY_IDS.map((family) => [family, opencodeGoApiKeySet])),
        },
      }),
      providers: describeProviders(providers),
      selected: enabledKeys,
      efforts: { ...this.models.efforts },
      accounts,
      opencodeGo,
      update: localUpdateInfo(process.platform, {
        profile: this.profile,
        env: this.updateEnv ?? process.env,
        readFileFn: this.readFileFn,
      }),
      autoUpdate: this.autoUpdate === true,
      autoUpdateState: this.updateState,
    }
  }

  opencodeGoSnapshot(options?) {
    return opencodeGoSnapshot(this, options)
  }

  saveOpencodeGo(payload?: any) {
    return saveOpencodeGo(this, payload)
  }

  switchOpencodeGo(id) {
    return switchOpencodeGo(this, id)
  }

  logoutOpencodeGo(id) {
    return logoutOpencodeGo(this, id)
  }

  clearOpencodeGo(field, id) {
    return clearOpencodeGo(this, field, id)
  }

  refreshOpencodeGoQuota(id) {
    return refreshOpencodeGoQuota(this, id)
  }

  refreshQuota(provider, accountId?) {
    return refreshQuota(this, provider, accountId)
  }

  consumeReset(provider, accountId, creditId?) {
    return consumeReset(this, provider, accountId, creditId)
  }

  checkUpdate(payload?: any) {
    return checkUpdate(this, payload)
  }

  changelog() {
    return fetchChangelog(this)
  }

  setAutoUpdate(payload?: any) {
    return setAutoUpdate(this, payload)
  }

  runAutoUpdate() {
    return runAutoUpdate(this)
  }

  startAutoUpdateWatch(options?) {
    return startAutoUpdateWatch(this, options)
  }

  stopAutoUpdateWatch() {
    return stopAutoUpdateWatch(this)
  }

  /**
   * Background credential sweep — CLIProxyAPI's authAutoRefreshLoop shape.
   * TokenManager refreshes lazily on request; without a sweep the first call
   * after an idle stretch pays the refresh RTT, and a refresh token that died
   * while idle only surfaces mid-request. Each family's own preemptMs decides
   * whether a stored login is due, so the sweep stays provider-agnostic.
   */
  startTokenSweep({ intervalMs = TOKEN_SWEEP_INTERVAL_MS } = {}) {
    if (this.tokenSweepTimer) return
    void this.sweepTokensOnce()
    this.tokenSweepTimer = setInterval(() => void this.sweepTokensOnce(), intervalMs)
    this.tokenSweepTimer.unref?.()
  }

  stopTokenSweep() {
    if (!this.tokenSweepTimer) return
    clearInterval(this.tokenSweepTimer)
    this.tokenSweepTimer = undefined
  }

  async sweepTokensOnce() {
    for (const provider of PROVIDER_IDS) {
      const manager = this.tokens[provider]
      if (!manager) continue
      let rows
      try {
        rows = await listStoredSessions(provider, this.authPath)
      } catch {
        continue
      }
      for (const row of rows) {
        if (!row) continue
        // account() refreshes only inside the family's preempt window; a
        // transient failure serves the still-valid token instead of throwing.
        await manager.account(row.id).catch(() => undefined)
      }
    }
  }

  login(provider, options) {
    return login(this, provider, options)
  }

  completePkce(provider, attempt, claim) {
    return completePkce(this, provider, attempt, claim)
  }

  completeKimiDevice(attempt) {
    return completeKimiDevice(this, attempt)
  }

  completeClineDevice(attempt) {
    return completeClineDevice(this, attempt)
  }

  completeDevice(provider, attempt) {
    return completeDevice(this, provider, attempt)
  }

  completeGlm(attempt) {
    return completeGlm(this, attempt)
  }

  completeCursor(attempt) {
    return completeCursor(this, attempt)
  }

  completeKiroIdc(attempt) {
    return completeKiroIdc(this, attempt)
  }

  completeCommandCode(attempt, claim) {
    return completeCommandCode(this, attempt, claim)
  }

  useKey(provider, key, extra) {
    return useKey(this, provider, key, extra)
  }

  async manual(provider, input) {
    const attempt = this.flows.pending(provider)
    if (attempt === undefined) throw new Error(`no ${provider} login attempt is in progress`)
    attempt.manual(input)
  }

  async cancel(provider) {
    this.claim(provider)
    this.flows.pending(provider)?.cancel()
    this.devices.pending(provider)?.cancel()
    this.glmFlows.pending(provider)?.cancel()
    this.kiroFlows.pending(provider)?.cancel()
    this.cursorFlows.pending(provider)?.cancel()
  }

  async logout(provider, id) {
    if (provider === 'opencode-go') return this.logoutOpencodeGo(id)
    this.claim(provider)
    this.flows.pending(provider)?.cancel()
    this.devices.pending(provider)?.cancel()
    this.glmFlows.pending(provider)?.cancel()
    this.kiroFlows.pending(provider)?.cancel()
    this.cursorFlows.pending(provider)?.cancel()
    // Sign in with ChatGPT: end the renewable session remotely first (siwc
    // profiles-and-sessions); an unconfirmed revocation still signs out.
    const revoked = provider === 'chatgpt' ? await revokeChatgptAccounts(this, id) : true
    await deleteSession(provider, this.authPath, id)
    // "Signed out" gates auto-import from local CLI/IDE logins, so it means the
    // family is EMPTY — leaving one of two accounts must not mark the family.
    // (store.saveSession clears the mark again when any login lands.)
    if ((await listStoredSessions(provider, this.authPath)).length === 0) await markSignedOut(this, provider)
    this.lastError.delete(provider)
    if (!revoked) {
      this.lastError.set(provider, 'Signed out locally. Remote revocation could not be confirmed; disconnect the app in ChatGPT Settings → Apps.')
    }
    this.quota.clear(provider, id)
    // The cached reading is mirrored to quota-snapshot.json behind a 2s
    // debounce; a reload right after logout would otherwise restore this
    // account's plan and numbers from disk.
    await this.quota.flush()
    this.onAuthChanged?.(provider)
    if (await getSession(provider, this.authPath)) void ensureAccountQuota(this, provider)
  }

  async switchAccount(provider, id) {
    if (provider === 'opencode-go') {
      await this.switchOpencodeGo(id)
      return this.snapshot(true)
    }
    await switchAccount(provider, id, this.authPath)
    this.lastError.delete(provider)
    this.onAuthChanged?.(provider)
    return this.snapshot(true)
  }

  importFrom(provider) {
    return importFrom(this, provider)
  }

  async setModels(payload: any = {}) {
    await this.models.ready
    const catalog = await this.catalog()
    if (Array.isArray(payload.selected)) {
      await this.models.setEnabled(payload.selected, catalog)
    } else if (payload.resetContexts === true) {
      // 恢复默认窗口: drop every custom input-context override at once.
      await this.models.resetContexts()
    } else if (typeof payload.contextKey === 'string') {
      // Custom input-context window (null resets to the catalog default);
      // not an enable choice, so selectionExplicit stays as it was.
      await this.models.setContext(payload.contextKey, payload.context ?? null, catalog)
    } else if (typeof payload.key === 'string') {
      await this.models.toggle(payload.key, payload.on !== false, catalog)
    } else if (MODEL_FAMILY_IDS.includes(payload.family)) {
      await this.models.setFamily(payload.family, payload.on !== false, catalog)
    } else if (typeof payload.all === 'boolean') {
      await this.models.setAll(payload.all, catalog)
    } else if ('effort' in payload) {
      // Default effort for `families` (null clears); no families = every family (全部).
      await this.models.setEffort(payload.effort, payload.families ?? undefined)
    } else {
      throw new Error('models payload needs selected, key, family, all, or effort')
    }
    // A context override on a disabled row only persists to models.json —
    // filterProviders drops it from the route write, so syncing would
    // produce a byte-identical settings file while paying a seconds-long
    // host reconcile. The override lands the next time the row is enabled.
    const dormantContextEdit = typeof payload.contextKey === 'string'
      && !this.models.isEnabled(payload.contextKey)
    if (!dormantContextEdit && this.settings && typeof this.settings.mutate === 'function') {
      // Picker already wrote the switch; do not re-enable a deliberate 全关.
      // Mutate failures must reach the RPC so the picker can show them.
      await this.sync(undefined, { recover: false })
    }
    return this.snapshot(true)
  }

  // Startup, onAuthChanged, and the RPC can all call sync() concurrently;
  // queue the whole body (same shape as installQueue in utils/update.ts) so
  // their settings mutates and compaction read-modify-writes never interleave.
  // Each queued call still runs its own full sync; the swallowed catch keeps
  // one rejection from poisoning the queue.
  async sync(selected?, options: any = {}) {
    const pending = this.#syncQueue.then(() => this.#performSync(selected, options))
    this.#syncQueue = pending.then(() => undefined, () => undefined)
    return pending
  }

  async #performSync(selected?, options: any = {}) {
    if (this.settings === undefined || typeof this.settings.mutate !== 'function') {
      throw new Error('settings service is not mounted; cannot sync llm-pi-ai routes')
    }
    await this.models.ready
    await this.loginsReady
    const catalog = await this.catalog()
    if (selected !== undefined) {
      await this.models.setEnabled(selected, catalog)
    }
    const loggedIn = await this.loggedIn()
    if (selected === undefined) {
      // 登录默认: a family that signs in while this runs keeps every row off
      // until the user picks for it (families signed in at startup are seeded,
      // so an upgrade never turns an existing install's models off).
      await this.models.applyLoginDefaults(catalog, loggedIn)
      if (options.recover !== false) {
        await this.models.recoverEmptyLoggedInFamilies(catalog, loggedIn)
      }
    }
    const opencodeGoKeySet = await hasOpencodeGoKey(this)
    // Planned only: its writes ride the family-route mutate below, so one sync
    // costs the host one llm-pi-ai reconcile (a few seconds), not two.
    const { mutations: opencodeGoMutations = [], ...opencodeGoRoute } = await ensureOpencodeGoRoute(this.settings, {
      selected: this.models.selectedForSync(catalog),
      apiKeySet: opencodeGoKeySet,
      contexts: this.models.contexts,
      efforts: this.models.efforts,
      apply: false,
    })
    if (opencodeGoKeySet && opencodeGoRoute.status !== 'pending' && opencodeGoRoute.status !== 'present') {
      throw new Error(`OpenCode Go model sync failed: ${opencodeGoRoute.status}`)
    }
    // OpenCode Zen rides the same credential/vault/account as Go; its three
    // routes are planned here and land in the one mutate below.
    const { mutations: opencodeZenMutations = [], ...opencodeZenRoute } = await ensureOpencodeZenRoute(this.settings, {
      selected: this.models.selectedForSync(catalog),
      apiKeySet: opencodeGoKeySet,
      contexts: this.models.contexts,
      efforts: this.models.efforts,
      apply: false,
    })
    if (opencodeGoKeySet && opencodeZenRoute.status !== 'pending' && opencodeZenRoute.status !== 'present') {
      throw new Error(`OpenCode Zen model sync failed: ${opencodeZenRoute.status}`)
    }
    const synced = await syncHarnessModels({
      settings: this.settings,
      patchPath: this.patchPath,
      prefix: this.prefix,
      origin: this.origin(),
      loggedIn,
      selected: this.models.selectedForSync(catalog),
      // Every other family's rows are read from the registry inside
      // syncHarnessModels; glmModels is its one caller-resolved (async) seat.
      glmModels: await this.#glmModels(),
      contexts: this.models.contexts,
      efforts: this.models.efforts,
      extraMutations: [...opencodeGoMutations, ...opencodeZenMutations],
    })
    return {
      ...synced,
      opencodeGoRoute: opencodeGoMutations.length ? { ...opencodeGoRoute, status: 'written' } : opencodeGoRoute,
      opencodeZenRoute: opencodeZenMutations.length ? { ...opencodeZenRoute, status: 'written' } : opencodeZenRoute,
    }
  }
}
