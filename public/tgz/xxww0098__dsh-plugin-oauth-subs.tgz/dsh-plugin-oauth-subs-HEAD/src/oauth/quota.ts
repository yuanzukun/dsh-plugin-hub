/**
 * Quota store: the per-account cache (mirrored to quota-snapshot.json), the
 * stale-while-revalidate read, reset-card spending, and the family dispatch
 * (a registry lookup into `families.ts`).
 * Each family's endpoints and parsing live in its own `quota.ts`
 * (`src/oauth/<id>/quota.ts`, `src/apikey/<id>/quota.ts`); shared coercion
 * and fetch helpers are in `quota-shared.ts`.
 */

import { readFileSync } from 'node:fs'
import { formatPlanLabel } from './plan.js'
import { accountIdOf } from './store.js'
import { writePrivateText } from '../utils/private-text.js'
import { outboundFetch } from '../utils/outbound.js'
import { parseCodexRateLimitsFrame } from './codex/quota.js'
import { chatgptUsageRows, parseChatgptUsageEvent, recordChatgptUsage } from './chatgpt/usage.js'
import { NO_RESET_CARDS, oauthFamily } from './families.js'
import { isAvailableResetCredit } from './quota-shared.js'


export const QUOTA_TTL_MS = 60_000

/**
 * Freshness window once a proxied chat request has spent this account's quota
 * (`QuotaStore.touch`). A floor, not a trigger: an agent loop firing dozens of
 * requests a minute still costs at most one quota read per account per 15s,
 * and only while the panel polls `snapshot()`.
 */
export const QUOTA_USED_TTL_MS = 15_000

function publicResetCredits(value) {
  if (!value) return { availableCount: 0, credits: [] }
  const available = (value.credits ?? []).filter(isAvailableResetCredit).map((credit) => ({
    id: credit.id,
    expiresAt: credit.expiresAt,
    ...(credit.resetType ? { resetType: credit.resetType } : {}),
  }))
  const nextExpiresAt = value.nextExpiresAt
  let credits = available
  if (credits.length === 0 && (value.availableCount ?? 0) > 0) {
    const count = Math.max(0, Math.round(value.availableCount))
    credits = Array.from({ length: count }, (_, index) => ({
      id: `available-${index + 1}`,
      expiresAt: nextExpiresAt,
    }))
  }
  return {
    availableCount: value.availableCount ?? credits.length,
    credits,
    ...(nextExpiresAt === undefined ? {} : { nextExpiresAt }),
  }
}

function quotaCacheKey(provider, accountId) {
  return accountId ? `${provider}\0${accountId}` : provider
}

function publicQuota(entry?, provider?) {
  if (!entry) return { status: 'idle' }
  return {
    status: entry.status,
    planType: entry.planType,
    planLabel: formatPlanLabel(entry.planType, provider),
    account: entry.account,
    subscriptionStatus: entry.subscriptionStatus,
    hasGrokCodeAccess: entry.hasGrokCodeAccess,
    updatedAt: entry.updatedAt,
    error: entry.error,
    rows: entry.rows ?? [],
    resetCredits: publicResetCredits(entry.resetCredits),
  }
}

const SNAPSHOT_VERSION = 1

/** Past this a saved reading is history, not a stand-in: quota windows have reset. */
const SNAPSHOT_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000

const SNAPSHOT_DEBOUNCE_MS = 2_000

/**
 * The quota cache, mirrored to a private file so a restart or hot reload shows
 * the last known numbers at once. A restored entry is old, so `ensure` serves it
 * and re-reads behind it — nothing else in the store knows the file exists.
 * Every write path goes through set / delete / clear, which is where it hooks.
 */
class PersistedCache extends Map<string, any> {
  #path: string
  #timer: NodeJS.Timeout | undefined
  #chain: Promise<void> = Promise.resolve()
  #written = ''

  constructor(path: string) {
    super()
    this.#path = path
    try {
      const saved = JSON.parse(readFileSync(path, 'utf8'))
      if (saved?.version === SNAPSHOT_VERSION && saved.entries && typeof saved.entries === 'object') {
        for (const [key, entry] of Object.entries<any>(saved.entries)) {
          if (Array.isArray(entry?.rows) && entry.rows.length && Date.now() - entry.updatedAt < SNAPSHOT_MAX_AGE_MS) super.set(key, entry)
        }
        this.#written = this.#serialize()
      }
    } catch { /* first run, or a file we cannot read: start empty */ }
  }

  set(key: string, value: any) {
    super.set(key, value)
    this.#schedule()
    return this
  }

  delete(key: string) {
    const had = super.delete(key)
    if (had) this.#schedule()
    return had
  }

  clear() {
    if (!this.size) return
    super.clear()
    this.#schedule()
  }

  /** Write now (a reload is about to drop the timer) and wait for it. */
  flush() {
    clearTimeout(this.#timer)
    this.#timer = undefined
    // Serialized at write time, so a later write can never put older data back.
    this.#chain = this.#chain.then(async () => {
      const text = this.#serialize()
      if (text === this.#written) return
      await writePrivateText(this.#path, text)
      this.#written = text
    }).catch(() => undefined)
    return this.#chain
  }

  #schedule() {
    if (this.#timer) return
    this.#timer = setTimeout(() => { void this.flush() }, SNAPSHOT_DEBOUNCE_MS)
    this.#timer.unref?.()
  }

  /** Only readings that carry numbers; an error entry keeps the rows it had, and comes back as `ready`. */
  #serialize() {
    const entries: Record<string, any> = {}
    for (const [key, entry] of this) {
      if (!Array.isArray(entry?.rows) || !entry.rows.length) continue
      const { usedAt, error, ...kept } = entry
      entries[key] = { ...kept, status: 'ready' }
    }
    return JSON.stringify({ version: SNAPSHOT_VERSION, entries })
  }
}

export class QuotaStore {
  declare tokens: any
  declare fetchFn: any
  declare ttlMs: number
  declare cache: Map<string, any>
  declare inflight: Map<string, any>

  constructor({ tokens, fetchFn = outboundFetch, ttlMs = QUOTA_TTL_MS, snapshotPath = undefined }: any = {}) {
    this.tokens = tokens
    this.fetchFn = fetchFn
    this.ttlMs = ttlMs
    this.cache = snapshotPath ? new PersistedCache(snapshotPath) : new Map()
    this.inflight = new Map()
  }

  /** Persist the cache now, when it is persisted at all. */
  async flush() {
    await (this.cache as any).flush?.()
  }

  peek(provider, accountId?) {
    if (accountId) return publicQuota(this.cache.get(quotaCacheKey(provider, accountId)), provider)
    const exact = this.cache.get(provider)
    if (exact) return publicQuota(exact, provider)
    for (const [key, entry] of this.cache) {
      if (key.startsWith(`${provider}\0`)) return publicQuota(entry, provider)
    }
    return publicQuota()
  }

  clear(provider, accountId?) {
    if (!provider) {
      this.cache.clear()
      return
    }
    if (accountId) {
      this.cache.delete(quotaCacheKey(provider, accountId))
      this.cache.delete(provider)
      return
    }
    this.cache.delete(provider)
    for (const key of [...this.cache.keys()]) {
      if (key.startsWith(`${provider}\0`)) this.cache.delete(key)
    }
  }

  /** Record a known failure without calling upstream (e.g. a stale imported login). */
  fail(provider, accountId, message) {
    const key = quotaCacheKey(provider, accountId)
    const previous = this.cache.get(key)
    const entry = {
      status: 'error',
      planType: previous?.planType,
      subscriptionStatus: previous?.subscriptionStatus,
      hasGrokCodeAccess: previous?.hasGrokCodeAccess,
      updatedAt: Date.now(),
      error: message,
      rows: previous?.rows ?? [],
      resetCredits: previous?.resetCredits ?? { availableCount: 0 },
    }
    this.cache.set(key, entry)
    return publicQuota(entry, provider)
  }

  /**
   * `maxAgeMs` tightens the freshness window for one call — the panel sends it
   * when the user (re)enters the quota page, so a reading older than the 15s
   * floor is re-read behind the cached answer instead of waiting out the TTL.
   */
  async ensure(provider, accountId?, session?, maxAgeMs = this.ttlMs) {
    const live = session ?? await this.#activeSession(provider)
    const id = accountId ?? (live ? accountIdOf(provider, live) : undefined)
    const key = quotaCacheKey(provider, id)
    const cached = this.cache.get(key)
    const ttl = cached?.usedAt !== undefined ? Math.min(maxAgeMs, QUOTA_USED_TTL_MS) : maxAgeMs
    if (cached && Date.now() - cached.updatedAt < ttl) {
      return publicQuota(cached, provider)
    }
    // Stale-while-revalidate for errors too: the snapshot awaits families in
    // series, so a blocking re-read of a down upstream stalls the whole panel.
    if (cached && (cached.status === 'ready' || cached.status === 'error')) {
      void this.refresh(provider, id, live)
      return publicQuota(cached, provider)
    }
    return this.refresh(provider, id, live)
  }

  /**
   * A proxied chat request for this account finished: its quota moved. Only
   * shortens the cached entry's freshness window — no upstream call here.
   */
  async touch(provider, session?) {
    const live = session ?? await this.#activeSession(provider)
    const id = live ? accountIdOf(provider, live) : undefined
    const entry = this.cache.get(quotaCacheKey(provider, id))
    if (entry) entry.usedAt = Date.now()
  }

  /**
   * Passive quota learning: the response itself carried this account's quota
   * (the Codex Responses stream's `codex.rate_limits` frame, or a ChatGPT
   * `response.completed` usage block), so the rows are updated without a
   * side-read. The endpoint read stays authoritative — a refresh that was in
   * flight overwrites what this wrote, and `usedAt` is left alone (`touch`
   * marks the spend the moment the response closes).
   */
  async learn(provider, data, session?) {
    if (provider === 'chatgpt') return this.#learnChatgptUsage(data, session)
    if (provider !== 'codex') return undefined
    const parsed = parseCodexRateLimitsFrame(data)
    if (!parsed.rows.length) return undefined
    const live = session ?? await this.#activeSession(provider)
    const id = live ? accountIdOf(provider, live) : undefined
    const key = quotaCacheKey(provider, id)
    const previous = this.cache.get(key)
    const entry = {
      status: 'ready',
      planType: parsed.planType ?? previous?.planType,
      account: previous?.account,
      subscriptionStatus: previous?.subscriptionStatus,
      hasGrokCodeAccess: previous?.hasGrokCodeAccess,
      updatedAt: Date.now(),
      // touch may already have marked this response's close. The frame says
      // nothing about that spend, so a later learn must not clear it.
      usedAt: previous?.usedAt,
      // A frame without a credits block must not drop the last known balance
      // (older servers / account shapes that don't send it on the wire).
      rows: parsed.rows.some((row) => row.kind === 'prepaid')
        ? parsed.rows
        : [...parsed.rows, ...(previous?.rows ?? []).filter((row) => row.kind === 'prepaid')],
      // The frame says nothing about the reset-credit bank: keep the last one.
      resetCredits: previous?.resetCredits ?? { availableCount: 0 },
    }
    this.cache.set(key, entry)
    return publicQuota(entry, provider)
  }

  /**
   * ChatGPT (siwc) has no quota endpoint; the terminal event's usage block is
   * the only in-contract signal. The spend is appended to the family's own
   * log and the card's rows become measured rolling windows — token sums, not
   * the plan's quota unit (chatgpt/usage.ts owns both shapes).
   */
  async #learnChatgptUsage(data, session?) {
    const spend = parseChatgptUsageEvent(data)
    if (!spend) return undefined
    const live = session ?? await this.#activeSession('chatgpt')
    if (!live) return undefined
    const id = accountIdOf('chatgpt', live)
    await recordChatgptUsage(id, spend)
    const rows = await chatgptUsageRows(id)
    if (!rows.length) return undefined
    const key = quotaCacheKey('chatgpt', id)
    const previous = this.cache.get(key)
    const entry = {
      status: 'ready',
      planType: previous?.planType,
      account: previous?.account,
      subscriptionStatus: previous?.subscriptionStatus,
      hasGrokCodeAccess: previous?.hasGrokCodeAccess,
      updatedAt: Date.now(),
      usedAt: previous?.usedAt,
      rows,
      resetCredits: previous?.resetCredits ?? { availableCount: 0 },
    }
    this.cache.set(key, entry)
    return publicQuota(entry, 'chatgpt')
  }

  async refresh(provider, accountId?, session?) {
    const live = session ?? await this.#activeSession(provider)
    const id = accountId ?? (live ? accountIdOf(provider, live) : undefined)
    const key = quotaCacheKey(provider, id)
    const pending = this.inflight.get(key)
    if (pending) return pending
    const run = this.#load(provider, id, live).finally(() => this.inflight.delete(key))
    this.inflight.set(key, run)
    return run
  }

  /**
   * Spend one of an account's reset cards through the family's own hook
   * (families.ts): the store owns the cache key, waits out a read in flight
   * for that account, hands over the cached bank, then drops the entry and
   * re-reads, so the card that was spent is gone from the panel. A family
   * without reset cards is refused here, before any vendor is asked.
   */
  async consume(provider, accountId?, session?, creditId?) {
    const spend = oauthFamily(provider)?.reset?.spend
    if (!spend) throw new Error(NO_RESET_CARDS)
    const manager = this.tokens?.[provider]
    const live = session ?? await this.#activeSession(provider)
    if (!live) throw new Error(`${manager?.displayName ?? provider} is not signed in`)
    const id = accountId ?? accountIdOf(provider, live)
    const key = quotaCacheKey(provider, id)
    const pending = this.inflight.get(key)
    if (pending) await pending.catch(() => undefined)
    await spend(live, creditId, { fetchFn: this.fetchFn, bank: this.cache.get(key)?.resetCredits, key })
    this.cache.delete(key)
    return this.refresh(provider, id, live)
  }

  async #activeSession(provider) {
    const manager = this.tokens?.[provider]
    if (!manager || typeof manager.session !== 'function') return undefined
    try {
      return await manager.session()
    } catch {
      return undefined
    }
  }

  async #load(provider, accountId, session) {
    const key = quotaCacheKey(provider, accountId)
    if (!session) {
      this.cache.delete(key)
      return publicQuota()
    }
    const previous = this.cache.get(key)
    const startedAt = Date.now()
    // A touch() that lands while this read is in flight is not reflected in it.
    const usedSince = () => {
      const usedAt = this.cache.get(key)?.usedAt
      return usedAt !== undefined && usedAt >= startedAt ? usedAt : undefined
    }
    this.cache.set(key, {
      ...(previous ?? {}),
      status: previous?.status === 'ready' ? 'ready' : 'loading',
      updatedAt: previous?.updatedAt ?? Date.now(),
      rows: previous?.rows ?? [],
      resetCredits: previous?.resetCredits ?? { availableCount: 0 },
    })
    try {
      // Registry dispatch: a family's own quota.ts owns the endpoints and the
      // parsing, and a provider that is not a family has no endpoint to read.
      const fetchQuota = oauthFamily(provider)?.fetchQuota
      if (!fetchQuota) throw new Error(`${provider} has no quota endpoint`)
      const parsed = await fetchQuota(session, this.fetchFn)
      const entry = {
        status: 'ready',
        planType: parsed.planType,
        account: parsed.account,
        subscriptionStatus: parsed.subscriptionStatus,
        hasGrokCodeAccess: parsed.hasGrokCodeAccess,
        updatedAt: Date.now(),
        usedAt: usedSince(),
        rows: parsed.rows ?? [],
        // A family whose side-read failed leaves resetCredits off: keep the last bank.
        resetCredits: parsed.resetCredits ?? previous?.resetCredits ?? { availableCount: 0 },
      }
      this.cache.set(key, entry)
      return publicQuota(entry, provider)
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      const entry = {
        status: 'error',
        planType: previous?.planType,
        subscriptionStatus: previous?.subscriptionStatus,
        hasGrokCodeAccess: previous?.hasGrokCodeAccess,
        updatedAt: Date.now(),
        usedAt: usedSince(),
        error: message,
        rows: previous?.rows ?? [],
        resetCredits: previous?.resetCredits ?? { availableCount: 0 },
      }
      this.cache.set(key, entry)
      return publicQuota(entry, provider)
    }
  }
}
