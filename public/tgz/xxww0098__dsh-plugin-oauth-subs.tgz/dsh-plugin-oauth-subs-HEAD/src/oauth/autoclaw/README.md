# AutoClaw / AutoClaw CN（智谱澳龙 OpenClaw 云端账号）OAuth

本文件是 `src/oauth/autoclaw/` 的设计源。改登录、额度、对话或缓存先改这里再改代码。
跨家族硬规则在 [`docs/rules.md`](../../../docs/rules.md)；故障记录在 [`docs/error.md`](../../../docs/error.md)；对照仓库在 [`docs/oauth.md`](../../../docs/oauth.md)。

**一个家族目录、两个 provider**（与 magpie 包一致，两套登录、两个 vault）：

| provider id | build | chat 上游 | 登录 | 路由名 |
|---|---|---|---|---|
| `autoclaw` | 国际版（海外直连网关） | `https://autoglm-api.autoglm.ai` + `/autoclaw-proxy/proxy/autoclaw/v1/chat/completions` | 本地网页 OAuth（Google / z.ai，阿里滑块 + state 校验回调） | `Subs · AutoClaw · Chat` |
| `autoclaw-cn` | 国内版（managed gateway） | `https://autoglm-acceleration-api.zhipuai.cn` + `/autoclaw-proxy/proxy/autoclaw/chat/completions` | 手机验证码（+86，两步 RPC） | `Subs · AutoClaw CN · Chat` |

按账号所在地分开登录、分开记额度：手机号账号只认国内 host（401/403 即失效）；z.ai/Google 账号只认国际 host（401/403 换国内侧重试，均拒才失效）。两组 provider 都在 OAuth 组（订阅登录型）。

> **接线状态**：注册台接线已落地（families/store/proxy/models/目录键/UI），后又随 2026-10-18 裁定引擎化——见下节。

## 归因（抄什么 / 不要发明什么）

钉住 **`@magpie-community/opencode-autoclaw-auth@0.2.1`**
（[magpie-community/plugins](https://github.com/magpie-community/plugins) `packages/autoclaw`，MIT）。该包对照的又是 AutoClaw 官方客户端（桌面端 / TokenServer）的逆向与实测。本仓 `.local/upstream-magpie/packages/autoclaw/` 有全量快照；下述 file:line 均指该快照的 `index.mjs`（README.md 指 its README）。**抄**：

- **客户端指纹**：`APP_ID=100003`、`APP_KEY=38d2391985e2369a5fb8227d8e6cd5e5`（签名用）、`PRODUCT=autoclaw`；国际版 `CHANNEL=AutoClaw4`、`CLIENT_VERSION=1.18.1`、UA `AutoClaw/1.18.1 (mac-arm64)`（index.mjs:25-33）；国内 managed `CHANNEL=AutoClaw26`、`CLIENT_VERSION=2.1.0`（index.mjs:30-31,495-497）。
- **业务签名头组**（登录/refresh/钱包/任务端点）：`X-Auth-Appid/X-Auth-TimeStamp/X-Auth-Sign=md5(APP_ID&ts&APP_KEY)`、`X-Trace-Id`（每请求随机 hex16 nonce）、`X-Tm/X-Product/X-Version/X-Lang/X-Channel`、`Origin/Referer: http://localhost:18432`（官方 TokenServer 本地源；端口池顺延时也固定 18432，照抄）（index.mjs:191-212）。
- **国际版登录**（完整本地实现，index.mjs:815-1049）：官方回调白名单端口池 `[18432,19654,19723,53699]`，被占顺延（index.mjs:847-861）；127.0.0.1 本地服务器内嵌引导页 → `/captcha-config`（POST `/userapi/overseasv1/oauth-captcha-config`）→ 阿里滑块（AliyunCaptcha SDK，`ali_captcha_verify_param` 回执，warmup ≥2.1s 再程序化 click，index.mjs:1107-1126）→ `POST /open-auth` 调 `/userapi/overseasv1/{vendor}-oauth-url`（body `{source_id, device_id, navigate_uri: http://localhost:<port>/auth/callback-<vendor>}`；redirect_uri 形态不符会被 `Redirect URI not registered for this client` 拒）→ 授权页 state 必须原样带回（防伪造回调劫持登录；不匹配拒收但不动会话，index.mjs:939-971）→ `/auth/callback-<vendor>?code&state` 收 code → `POST /userapi/overseasv1/{vendor}-oauth-login`（body `{source_id, device_id, code, state, navigate_uri}`）换 token；写接口只收 127.0.0.1/localhost 来源；10 分钟会话上限、5 分钟 code 等待；结束关服务器释放端口。
- **国内版登录**（手机验证码，index.mjs:744-793）：`POST /userapi/v1/agent-send-code`（body `{source_id, device_id, phone}`，11 位手机号 `^1\d{10}$`）→ `POST /userapi/v1/agent-login/`（**结尾斜杠是上游原样**；`code` 数字串按数字发，字符串会 400001）。身份：`POST /userapi/v1/user-profile` 取 `user_name/user_phone/user_id`，显示名 = 昵称 > 手机号 > uid（index.mjs:427-453）。
- **token 语义**：`expires_in` 常缺省，**JWT exp 才是事实来源**（约 24h），提前 10 分钟（skew）记到期；缺 JWT 时按 5h 兜底（index.mjs:142-143,277-290）。**refresh token 一次一换**（共享 TokenManager 的 rotation hold 防双花）；refresh 的 host 顺序由 refresh token 的 `source_id` claim 决定（`agent*` = 短信先国内），`/userapi/v1/refresh` 回 code 400002 换 `/userapi/v1/agent-refresh` 同 host 重试，信封 code 400000 换下一个 host；401/403 或 invalid_grant/revoked/expired/登录已失效 类消息 = 永久失败（index.mjs:459-484）。
- **chat 端点**：国际版 `POST {GLOBAL}/autoclaw-proxy/proxy/autoclaw/v1/chat/completions`（带 `/v1`，401/403 换 `{CN}/…/v1/…` 重试，均拒才 401）；国内 `POST {MANAGED}/autoclaw-proxy/proxy/autoclaw/chat/completions`（无 `/v1`，401/403 即失效）（index.mjs:38-40,603-634）。
- **chat 头组**：鉴权一律 **`X-Authorization: Bearer <token>`**，绝不发 `Authorization`；国际版轻头组（UA/X-Client-Type: pc/X-Product/X-Tm/X-Version/X-Lang/X-Channel/`x_trace_id: autoclaw-desktop` + `X-Request-Model`=routeModelId + `X-Request-Id` 每请求新 hex；index.mjs:575-601）；国内 managed 用签名头组打底再叠 2.1.0 指纹、`X-Agent-Id: main`、rid 同值喂 `X-Trace-Id/X-Request-Id`（index.mjs:490-507）。**上游收到 `X-Harness-Type` 即 406**——本 hop 只传自己的头组，天然不带。
- **请求整形**（两网关一致，缺任一条 406 且 body 空，index.mjs:41,44-139,509-530）：官方 system 前缀 `You are AutoClaw. Answer the user directly and concisely.` 并入首条 system（无则补最小 system；幂等）；删 `max_tokens`/`max_completion_tokens`；system/developer 里的外部 agent 身份句按 FLAGGED 表改写（`You are Claude Code`→`You are the Claude Code CLI` 等 8 对，每对经真实网关验证左 406 右可答；user/assistant 不改）。406 拒答时把出口提示拼进错误消息（REFUSED_HINT，index.mjs:84-104）。
- **模型目录**：无目录端点，固定 4 行（`zai_`/`zaicoding_` 前缀 routeModelId）：国际版 `zai_auto`/`zai_auto-fast`（ctx 200000 / out 32000）、`zaicoding_glm-5.3`（1000000/131072）、`zai_glm-5.3-flash`（1000000/32000）（index.mjs:150-158）；国内 managed 全部 ctx 1048576，out 分别 393216/131072/307200/131072，`attachment` 标图（zaicoding 不收图），推理档 low/high/max（index.mjs:147,161-167）。`zai_glm-5-turbo` 与 `tdpsk_deepseek-*` 已被上游下线（README.md:18）。
- **额度**：`GET {host}/agent-assetmgr/api/v2/wallets?biz_app_id=autoclaw`（签名头组 + Bearer；host home 优先、另一个兜底），`{code:0, data:{total_balance, wallets[]}}`；命名钱包（`display!==false`、余额>0、≠总额）至多 3 行（index.mjs:42,296-313,659-689）。纯积分制、无总量上限、无订阅档位名。

**不要发明**：会话/缓存亲和字段——上游 wire 没有任何（无 Codex `prompt_cache_key`、无 Grok `x-grok-conv-id`、无会话头），本 hop 不造；别家的缓存头；把 DSH `session_id` 原样发上游；`installation-id`/`parent-thread` 之类 upstream 没发的字段；models.dev 价目（无 USD 来源，`rates.json` 不收）。magpie 的**每日签到**（原生 checkin 钩子 + 旧链路自动补签 + 配置文件）、**多账号调度/故障切换**、usage 窗口的 aside 布局语义不引入（本插件每家族只用 active 账号）。

## 对照仓与升级对齐

- 仓库：[magpie-community/plugins](https://github.com/magpie-community/plugins)，包目录 `packages/autoclaw`，npm 包 `@magpie-community/opencode-autoclaw-auth`（MIT）。
- 本仓快照：`.local/upstream-magpie/packages/autoclaw/`（index.mjs + index.test.mjs + guide-lifecycle.test.mjs + README.md）。
- 升级：`git diff <旧>..<新> -- packages/autoclaw`，逐项过「归因」节（CLIENT_VERSION / 端点 / FLAGGED / 模型清单 / 头组），先改本 README 再改代码；钉住版本三处同步（本节、`docs/oauth.md` 总表、`index.ts` 文件头）。上游 README 自己说：上游偶发改协议时 `CLIENT_VERSION`/端点路径可能要随官方客户端更新（README.md:91）。

## 上游引擎（引擎即实现，2026-10-18 全过签核、不回退）

登录（国际本地 OAuth 服务器 + CN 短信两步）、refresh 一次一换与无名账号正名、hop（biz 头组、
官方 system 前缀、max_tokens 剥除、FLAGGED 改写、双 host 倒换、CN managed 网关）、额度 wallets
读全部由运行时下载的 `@magpie-community/opencode-autoclaw-auth` 驱动（[`engine.ts`](engine.ts)；
`AutoclawAuthPlugin` / `AutoclawCnAuthPlugin` 具名导出，三 host 进
[`bridge.ts`](../../upstream-engine/README.md) 桥闭集）。被删 TS：`local-oauth.ts` 全文、
send-code/agent-login 调用、biz 头工厂、`refreshAutoclaw`、`quota.ts`、request.ts 的方言改写。

**留在本仓**：vault 会话形状与流程槽（`autoclawFlows`）+ 登录完成回调；目录闭集（catalog.ts
静态行）；缓存剥除（cache.ts）；406 拒答分类（request.ts，proxy 语义）；国际行 reasoningEfforts
不声明（目录侧裁定维持）。CN 短信两步的挂起态改存包的 started 登录（10 分钟内有效，同旧语义）。

## 文件

| 文件 | 职责 |
|---|---|
| [`index.ts`](index.ts) | 站点表、常量（APP_ID/KEY/UA/端口池/超时）、`{code,msg,data}` 信封与 JWT/token 语义、账号显示名取法（引擎化后供 vault/测试钉语义用） |
| [`engine.ts`](engine.ts) | 上游引擎适配层：双 build 插件构建、登录（国际浏览器 + CN 短信两步挂起态）、刷新、hop 装载（biz 头组/双 host 倒换/CN managed 网关随包）、wallets 额度映射、host 闭集注册 |
| [`catalog.ts`](catalog.ts) | 静态目录（种子行；`src/catalog/models.json` 的 `autoclaw`/`autoclaw-cn` 键） |
| [`cache.ts`](cache.ts) | 剥 DSH 缓存字段；`dsh-autoclaw[-cn]` 常量兜底（无 wire 缓存字段，无 system 停车） |
| [`request.ts`](request.ts) | 406 拒答分类（`classifyAutoclawFailure`，proxy 语义；官方前缀/FLAGGED/删 max_tokens 已随包） |
| [`accounts.ts`](accounts.ts) | 登录编排（浏览器流后台收尾、SMS 两步）、家族 attempt registry（`autoclawFlows`） |

调度：[`../proxy.ts`](../proxy.ts) `/autoclaw[-cn]/v1/chat/completions` → `forward()`（`headersOf` = `autoclawEngineHeaders` 只传 accept；biz 头组、body 改写、双 host 倒换与 CN managed 网关都在引擎 loader 里）；额度经 [`../families.ts`](../families.ts) 注册 `fetchAutoclawQuotaEngine` / `fetchAutoclawCnQuotaEngine`。

## 协议

DSH `api: openai-completions`。`baseURL` 是 `${origin}/autoclaw`（国内 `${origin}/autoclaw-cn`），SDK 打到 `/autoclaw[-cn]/v1/chat/completions`。`/v1/responses` 明确 501。`model` 字段原样是 routeModelId（`zai_auto` 等）；**`zai_auto-fast` 是上游真实模型 id**，不是本插件 `-fast` 孪生——不做 fast-mode 剥离，`withPickerVariants` 也不加孪生（fast-mode 只认 Codex `fastTier`）。

`reasoning_effort`：国内行声明 `{low, high, max}`（wire 值同档名，upstream VARIANTS index.mjs:147）；国际行**不声明**（upstream 代码只给国内 managed 表挂 variants，index.mjs:150-158；其 README.md:14-16 却声称国际版也支持 low/high/max——活测确认前不发明，见 openQuestions）。声明了档位的路由才挂 `compat: { supportsReasoningEffort: true, thinkingFormat: 'openai' }`。

## 缓存

上游 wire 无任何缓存亲和字段，上游插件也不做 system 停车（官方前缀本身就是稳定头）。本 hop：剥 `session_id`/`prompt_cache_key`/retention/options（绝不发上游）；`cacheSessionId` 仅分析器可见，兜底常量 `dsh-autoclaw[-cn]`，不是会话、不 pin。`X-Request-Id`/`X-Trace-Id` 是每请求 nonce（厂商契约如此），不是会话/缓存 id——对抗清单 grep 时看本节。

## 登录

> 引擎现状：本地服务器（含滑块/授权页/换 token）与短信发码/兑换都在引擎 authorize 里；
> accounts.ts 只透传 url、保管流程槽与 SMS 挂起态（包的 started 登录，10 分钟内有效）。
> 下方细节为引擎行为的归因（与包 index.mjs 一致）。

- **国际版**（`login('autoclaw', { vendor: 'google'|'zai' })`，默认 google）：本地服务器（端口池探测）就绪后返回 `{ authorizeUrl: 本地引导页, mode: 'browser' }`，宿主打开 URL；滑块/授权/回调全在本地页完成，code 经 state 校验后由插件换 token、拉 profile、落 vault；完成或 10 分钟超时即关服务器。取消（controller.cancel → 家族 registry）停下流程槽——引擎 settle 先落 slot，保存等 `waitToken`，取消后登录页即便完成也不落 vault（workbuddy 同形）；引擎自己的本地服务器仍由它的完成/超时关停。
- **国内版**两步：`login('autoclaw-cn', { phone })` 发验证码（返回 `{mode:'code-sent', message}`；挂起态含 device_id，10 分钟内有效）；`login('autoclaw-cn', { phone, code })` 兑换并落 vault。无本地导入源（upstream 也没有）。
- **刷新**：JWT exp − 10min 为到期点，TokenManager 预刷窗口 = 10min；refresh 一次一换；与 AutoClaw 桌面端共用账号会互踢（upstream README.md:90，使用须知）。

## 额度

`fetchAutoclawQuota`/`fetchAutoclawCnQuota`：wallets 双 host 顺序读，第一个 `code:0` 带 data 的为准；产出「积分余额」一行 + 命名钱包行（≤3，排除与总额相同的重复），都是 **prepaid 余额行**（`remaining`=余额，无 used/百分比——balance 制不发明 used，cline/opendesign 钱包行同形；共享 QuotaMeter 才能上数字）。无 planType（wire 无档位名，`plan.ts` 不加分支）。额度缓存 key = `provider\0accountId`（共享 QuotaStore），snapshot 覆盖每个已存账号。

## 模型

全部数字的出处见「归因·模型目录」（index.mjs:150-167）。种子行与 `src/catalog/models.json` 逐字段相同（models.json 的 `autoclaw`/`autoclaw-cn` 键已落地接管，`catalogRows` 正常回答）；`zai_auto-fast` 保持原 id。国内表 `input` 按 `attachment` 标（zaicoding text-only）；国际表 attachment 未标 → 全部 text-only（不发明图片能力）。**无价目源**（上游无 USD 价目；积分制不等于 USD）——`rates.json` 不收 `autoclaw` 键，`scripts/rates.ts` 无 resolver；`scripts/models.ts` 的 `ADAPTERS` 记 `manual`（无目录端点，行手工维护在 models.json）。

## 不采纳（记录在案）

- **每日签到**（`auth.checkin` 钩子、旧链路 usage/refresh 自动补签、`~/.config/magpie/autoclaw.json` 配置、`signinOnUsage` 等开关）：magpie 宿主的调度诉求，upstream index.mjs:315-420；额度窗口的「每日签到」状态行也随之不采纳。
- **多账号池 / 故障切换 / 401 自动换账号**：本插件每家族只用 active 账号（与 workbuddy 同口径）。
- **usage 窗口的 `aside`/`balance` 布局语义**：本地 quota 行形状由共享 QuotaStore 决定，只映射数值。
- **`X-Magpie-Sign-In` 响应头**：magpie 宿主的登录态标记协议；本地由共享 TokenManager/UpstreamFailure 分类承担。

## 活测

**待维护者真实账号验证**（本接入无真实账号，无法执行 `npm run live`）。需要验证的点（按「归因」节）：两个 provider 各一次登录（滑块流程 + 短信流程）、chat 前缀/FLAGGED/406 行为、国际版 401 换侧、wallets 额度读数、refresh 轮换与互踢提醒；命中率和结论落 `docs/error.md` 后才算完成。
