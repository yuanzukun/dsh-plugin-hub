/**
 * Ollama Cloud subscription on ollama.com — not the local 127.0.0.1:11434
 * daemon that already hosts DSH (`ollama launch dsh`).
 *
 * Programmatic auth is an API key from https://ollama.com/settings/keys
 * sent as `Authorization: Bearer`. `ollama signin` is local-daemon SSH
 * signing (`~/.ollama/id_ed25519`); that public key is not a Bearer.
 *
 * Chat hop is OpenAI Completions at https://ollama.com/v1/chat/completions
 * (official Factory docs + 401-not-404 probe). Native `/api/chat` stays
 * unused unless that /v1 route disappears.
 */

import { createHash } from 'node:crypto'
import { outboundFetch } from '../../utils/outbound.js'
import { catalogRows } from '../../catalog/index.js'

export const OLLAMA_CLOUD_ORIGIN = 'https://ollama.com'
export const OLLAMA_CHAT_URL = `${OLLAMA_CLOUD_ORIGIN}/v1/chat/completions`
export const OLLAMA_TAGS_URL = `${OLLAMA_CLOUD_ORIGIN}/api/tags`
export const OLLAMA_SHOW_URL = `${OLLAMA_CLOUD_ORIGIN}/api/show`
export const OLLAMA_ME_URL = `${OLLAMA_CLOUD_ORIGIN}/api/me`
export const OLLAMA_BALANCE_URL = `${OLLAMA_CLOUD_ORIGIN}/api/balance`

/** ollama.com /api/me Plan slugs. Not Codex `pro` → Pro 20x. */
export const OLLAMA_PLAN_NAMES = Object.freeze({
  free: 'Free',
  hobby: 'Hobby',
  plus: 'Plus',
  pro: 'Pro',
  max: 'Max',
  team: 'Team',
  enterprise: 'Enterprise',
})
/** Official docs: API keys do not expire. */
export const OLLAMA_NEVER_EXPIRES = 8.64e15
export const OLLAMA_DEFAULT_CONTEXT = 128_000
export const OLLAMA_DEFAULT_MAX_TOKENS = 16_384
export const OLLAMA_TEXT_INPUT = Object.freeze(['text'])
export const OLLAMA_VISION_INPUT = Object.freeze(['text', 'image'])

/**
 * DSH picker keys → Ollama OpenAI-compat wire
 * (`reasoning_effort` / `effort`: high|medium|low|max|none).
 * Never use a vendor spelling as a key.
 */
export const OLLAMA_REASONING = Object.freeze({
  off: 'none',
  low: 'low',
  medium: 'medium',
  high: 'high',
  max: 'max',
})

export const OLLAMA_SOURCES = Object.freeze(['paste', 'env'])

/**
 * Official Cloud retirement table (docs.ollama.com/cloud). Upcoming
 * 2026-07-31 rows are already past as of this family. Do not list them.
 * Ids live in `src/catalog/models.json` under `"ollamaRetired"`.
 */
export const OLLAMA_RETIRED_MODELS = Object.freeze(new Set(catalogRows('ollamaRetired')))

/** Last-resort name regex when POST /api/show has no `capabilities`. */
export function inferOllamaInput(id) {
  const text = String(id ?? '').toLowerCase()
  if (/gemma|vision|\bvl\b|-vl/.test(text)) return [...OLLAMA_VISION_INPUT]
  return [...OLLAMA_TEXT_INPUT]
}

/**
 * DSH picker `input` from POST /api/show `capabilities`.
 * `vision` (any case) → text+image. Missing `capabilities` → undefined
 * so the catalog can fall back to `inferOllamaInput`. Never invent audio.
 */
export function ollamaShowInput(show) {
  if (show == null || typeof show !== 'object' || !Array.isArray(show.capabilities)) return undefined
  const vision = show.capabilities.some((item) => String(item ?? '').toLowerCase() === 'vision')
  return vision ? [...OLLAMA_VISION_INPUT] : [...OLLAMA_TEXT_INPUT]
}

export function ollamaInput(id, show) {
  return ollamaShowInput(show) ?? inferOllamaInput(id)
}

function asPositiveInt(value) {
  const n = typeof value === 'number' ? value : typeof value === 'string' && value.trim() ? Number(value) : NaN
  if (!Number.isFinite(n) || n <= 0) return undefined
  return Math.trunc(n)
}

/** `model_info.<family>.context_length` from POST /api/show, or a later tags field. */
export function ollamaShowContextLength(value) {
  if (value == null || typeof value !== 'object') return undefined
  const bags = [value, value.model_info, value.details, value.model_info?.details]
  for (const bag of bags) {
    if (!bag || typeof bag !== 'object') continue
    const direct = asPositiveInt(bag.context_length ?? bag.contextLength)
    if (direct) return direct
    for (const [key, raw] of Object.entries(bag)) {
      if (/(?:^|\.)context_length$/i.test(key)) {
        const n = asPositiveInt(raw)
        if (n) return n
      }
    }
  }
  return undefined
}

export function ollamaSnapshotContextWindow(id) {
  const name = String(id ?? '').trim()
  if (!name) return undefined
  const exact = OLLAMA_MODELS.find((model) => model.id === name)
  if (exact) return exact.contextWindow
  const bare = name.split(':')[0]
  return OLLAMA_MODELS.find((model) => model.id === bare || model.id.split(':')[0] === bare)?.contextWindow
}

/**
 * DSH picker window: live show/tags `context_length`, else the pinned Cloud
 * snapshot. Last resort for an unknown new tag is OLLAMA_DEFAULT_CONTEXT —
 * not a family-size regex (128k/200k/256k).
 */
export function ollamaContextWindow(id, show) {
  return ollamaShowContextLength(show) ?? ollamaSnapshotContextWindow(id) ?? OLLAMA_DEFAULT_CONTEXT
}

/**
 * 17-row Cloud `/api/tags` snapshot (2026-09-26). Windows are POST /api/show
 * `model_info.*.context_length`. `input` is that show's `capabilities` (`vision` →
 * text+image). Live tags+show replace this after login. Rows live in
 * `src/catalog/models.json` under `"ollama"` (every row carries the family
 * `OLLAMA_REASONING` ladder and `OLLAMA_DEFAULT_MAX_TOKENS`).
 */
export const OLLAMA_MODELS = catalogRows('ollama')

/** Catalog lookup for the custom-context ceiling (`familyMaxContextWindow`). */
export function ollamaModel(modelId) {
  return OLLAMA_MODELS.find((model) => model.id === modelId)
}

export function ollamaSourceLabel(source) {
  if (source === 'env') return 'env'
  if (source === 'paste') return 'key'
  return undefined
}

function trimmed(value) {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined
}

export function parseOllamaApiKey(value) {
  const key = trimmed(value)
  if (!key || key.length < 8) throw new Error('ollama API key is empty')
  if (key.includes('BEGIN') && key.includes('PUBLIC KEY')) {
    throw new Error('ollama id_ed25519.pub is the registry public key, not a cloud API key')
  }
  return key
}

/** Stable vault id that is not the raw key. */
export function ollamaAccountFingerprint(key) {
  return createHash('sha256').update(String(key ?? '')).digest('hex').slice(0, 8)
}

export function ollamaDefaultAccount(key) {
  return `ollama-${ollamaAccountFingerprint(key)}`
}

/** Vault / card title before /api/me Email lands. */
export function isOllamaOpaqueAccount(value) {
  return /^ollama-[0-9a-f]{8}$/i.test(String(value ?? '').trim())
}

export function isOllamaRetiredModel(id) {
  const name = String(id ?? '').trim().toLowerCase()
  if (!name) return true
  if (OLLAMA_RETIRED_MODELS.has(name)) return true
  const bare = name.split(':')[0]
  return OLLAMA_RETIRED_MODELS.has(bare)
}

export function ollamaPrettyName(id) {
  return String(id ?? '')
    .replace(/[:_-]+/g, ' ')
    .replace(/\b\w/g, (char) => char.toUpperCase())
    .trim() || 'Ollama'
}

export function ollamaSession({
  accessToken,
  account,
  source = 'paste',
}: any = {}) {
  const key = parseOllamaApiKey(accessToken)
  return {
    accessToken: key,
    refreshToken: key,
    expiresAt: OLLAMA_NEVER_EXPIRES,
    account: trimmed(account) ?? ollamaDefaultAccount(key),
    source: OLLAMA_SOURCES.includes(source) ? source : 'paste',
  }
}

export async function refreshOllama(session) {
  if (!session || typeof session.accessToken !== 'string' || !session.accessToken.trim()) {
    throw new Error('ollama session needs an API key')
  }
  return session
}

export function ollamaUpstreamHeaders(session) {
  return {
    authorization: `Bearer ${session.accessToken}`,
  }
}

function firstTrimmed(...values) {
  for (const value of values) {
    const next = trimmed(value)
    if (next) return next
  }
  return undefined
}

/** Live /api/me is PascalCase (`Email`, `Name`, `Plan`). GET is 405. */
export function parseOllamaMe(value) {
  if (!value || typeof value !== 'object') return {}
  const user = value.user && typeof value.user === 'object' ? value.user : value
  const account = firstTrimmed(
    user.Email,
    user.email,
    user.Name,
    user.name,
    user.preferred_username,
    user.username,
    value.Email,
    value.email,
    value.Name,
    value.name,
  )
  const planType = firstTrimmed(user.Plan, user.plan, value.Plan, value.plan)
  return {
    ...(account ? { account } : {}),
    ...(planType ? { planType } : {}),
  }
}

export async function resolveOllamaIdentity(session, { fetchFn = outboundFetch, signal }: any = {}) {
  const key = trimmed(session?.accessToken)
  if (!key) return undefined
  try {
    const response = await fetchFn(OLLAMA_ME_URL, {
      method: 'POST',
      headers: {
        authorization: `Bearer ${key}`,
        'content-type': 'application/json',
      },
      body: '{}',
      signal,
    })
    if (!response.ok) return undefined
    const identity = parseOllamaMe(await response.json())
    return identity.account || identity.planType ? identity : undefined
  } catch {
    return undefined
  }
}
