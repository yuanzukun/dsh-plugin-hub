/**
 * OpenCode Go API-key family (quota only).
 *
 * Chat is DSH's builtin opencode-go + OPENCODE_API_KEY (Responses, no
 * loopback hop). This module stores a web session cookie + workspace id
 * so Settings can show remaining quota.
 *
 * Many accounts share the one OPENCODE_API_KEY env: the vault keeps each
 * account's key, and the controller mirrors the active account's key into
 * the host credential so DSH keeps reading a single ref.
 */

import { createHash } from 'node:crypto'

export const OPENCODE_GO_ID = 'opencode-go'
export const OPENCODE_GO_ORIGIN = 'https://opencode.ai'
export const OPENCODE_GO_COOKIE_MASK = '••••••••'

// Migrated workspaces live in the Console SPA, whose session is a separate
// cookie; unmigrated accounts still authenticate with the legacy auth cookie.
const AUTH_COOKIE_NAMES = new Set(['auth', '__host-auth', '__host-console_session', 'console_session'])
const WORKSPACE_ID_RE = /^(?:wrk_|org_)[A-Za-z0-9_-]+$/
const WORKSPACE_RE = /(?:wrk_|org_)[A-Za-z0-9_-]+/

export function parseOpencodeGoCookie(raw) {
  const text = String(raw ?? '').trim()
  if (!text) return undefined
  // Settings redisplays the mask; saving it back must not be persisted as a
  // real `auth=••••••••` credential (it has no '=', so it would slip through
  // to the bare-token fallback below).
  if (isOpencodeGoCookieMask(text)) return undefined
  const parts = text.split(';').map((part) => part.trim()).filter(Boolean)
  const picked: string[] = []
  for (const part of parts) {
    const eq = part.indexOf('=')
    if (eq <= 0) continue
    const name = part.slice(0, eq).trim()
    const value = part.slice(eq + 1).trim()
    if (!value) continue
    if (AUTH_COOKIE_NAMES.has(name.toLowerCase())) picked.push(`${name}=${value}`)
  }
  if (picked.length > 0) return picked.join('; ')
  if (text.includes('=') || /\s/.test(text)) return undefined
  return `auth=${text}`
}

export function normalizeOpencodeGoWorkspaceId(raw) {
  const text = String(raw ?? '').trim()
  if (!text) return undefined
  if (WORKSPACE_ID_RE.test(text)) return text
  try {
    const url = new URL(text)
    const parts = url.pathname.split('/').filter(Boolean)
    for (const marker of ['workspace', 'console']) {
      const index = parts.indexOf(marker)
      if (index < 0) continue
      const candidate = parts[index + 1]
      if (typeof candidate === 'string' && WORKSPACE_ID_RE.test(candidate)) return candidate
    }
  } catch {
    // not a URL
  }
  const match = text.match(WORKSPACE_RE)
  return match ? match[0] : undefined
}

/** Stable account id: workspace when known, else a hash of the secret. */
export function opencodeGoAccountId({ workspaceId, apiKey, cookieHeader }: any = {}) {
  const workspace = normalizeOpencodeGoWorkspaceId(workspaceId)
  if (workspace) return workspace
  const secret = String(apiKey ?? '').trim() || String(cookieHeader ?? '').trim()
  if (!secret) return undefined
  return `go_${createHash('sha256').update(secret).digest('hex').slice(0, 12)}`
}

/** Masked identity for a keyed account that has no workspace id yet. */
export function opencodeGoKeyHint(apiKey) {
  const key = String(apiKey ?? '').trim()
  if (!key) return ''
  const tail = key.slice(-4)
  return key.startsWith('sk-') ? `sk-…${tail}` : `…${tail}`
}

export function publicOpencodeGoAccount(id, entry, quota, active) {
  const workspaceId = String(entry?.workspaceId ?? '').trim()
  const email = String(entry?.email ?? '').trim()
  const displayName = String(entry?.displayName ?? '').trim()
  return {
    id,
    active: Boolean(active),
    account: displayName || email || workspaceId,
    displayName,
    email,
    workspaceId,
    workspaceName: String(entry?.workspaceName ?? '').trim(),
    cookieSet: Boolean(entry?.cookieHeader),
    apiKeySet: Boolean(entry?.apiKey),
    quota: quota ?? { status: 'idle' },
  }
}

export function publicOpencodeGo(vault, quotas) {
  const accounts = Object.entries(vault?.accounts ?? {})
    .map(([id, entry]) => publicOpencodeGoAccount(id, entry, quotas?.get?.(id), id === vault?.activeId))
    .sort((left, right) => Number(right.active) - Number(left.active) || left.id.localeCompare(right.id))
  return {
    id: OPENCODE_GO_ID,
    activeId: vault?.activeId,
    accounts,
  }
}

export function isOpencodeGoCookieMask(value) {
  return String(value ?? '').trim() === OPENCODE_GO_COOKIE_MASK
}
