# 上游引擎推进清单（维护者 2026-10-18 裁定：清单化逐家推进）

裁决与边界（裁定链：2026-10-17 试点先行 → **2026-10-18 全过 + 不回退、不旧兼容**）：

- **不可切换（共 10 家，维持 TS 维护）**：codex / chatgpt / antigravity / ollama / opencode-go / kimi
  ——上游无对应 provider 包；mimo（fetch 不可注入，绕过代理卡）、kiro（node:sqlite 需
  flag + 登录面变 kiro-cli）、grok（登录/刷新依赖 grok CLI 二进制）、devin（`ide_name:
  'devin-cli'` 活测只回 1 条 stub config，index.mjs:1309/1735）——切换即降级或坏掉。
- **可切换 8 家**：按下表顺序逐家推进。每家流程＝本清单签核 → 适配器落地 → 测试绿 →
  维护者活测。**引擎即实现**：被替换的 TS wire 路径删除，无 flag、无双轨、无回退梯；
  坏发版的兜底是「契约断言 + 60s 负缓存 + 三版缓存改 manifest 回退」。
- 通用基建（2026-10-18 落地）：**URL 作用域 global-fetch 桥**（`bridge.ts`——无
  `fetchImpl` 的包把端点 host 注册进闭集，引擎流量路由进 `outboundFetch`，其余原样过）
  + **适配器声明包入口**（`loadUpstreamEngine` 的 `entry` 参数——kimi-work 走
  `_internal.createPlugin`，workbuddy 走具名导出）+ 响应协议头 `X-Magpie-Sign-In` 进
  proxy 层 `WIRE_ONLY` 闭集剥离。cursor 的 h2 `Run`（node:http2.connect）另案已闭环
  （2026-10-18：本仓 TS 本就同形裸 h2 + 自有 `cursorUpstreamProxy` 出口，引擎另带
  H1-over-fetch 兜底可进桥——见 §7 的决议记录）。
- 已完成：kimi-work（试点 2026-10-17 → 引擎即实现 2026-10-18）、workbuddy 双 build、
  opendesign、autoclaw 双 build、zed、cline、command-code（均 2026-10-18，待活测）。

签核口径：勾掉一条＝接受该行为反转随上游自动跟进；不勾＝适配器需在该项上偏离上游
（写明做法）或该家暂缓。

## 1. workbuddy（分歧最小，先行）——已落地（2026-10-18，待活测）

- [x] 升级政策反转：引擎车道 npm tarball + dist-tags 自动跟进；git diff 降级为审计工具。
- [x] 双 build（workbuddy CN `copilot.tencent.com` / workbuddy-ai `www.workbuddy.ai`）由
      上游单包具名导出驱动；站点选择、头组随上游。**活目录刷新留本仓**（catalog.ts 的
      `/v3/config` 读——目录行格式是 curator 闭集域，引擎的 provider.models 说 magpie
      行形状，不接管；适配器偏离项，依「目录侧维持本地」原则）。
- [x] wire 细节随上游：四会话头（attend() 派生，进程 SALT——缓存前缀跨进程重置一次）、
      一次性 refresh 轮换（引擎 renew() 去重 + 我方 client.auth.set 写回 vault）、
      流式必开、额度 meter 无 `/v2` 前缀、UA 钉版自动跟。
- [x] 随包新增：桌面登录变引用式（vault 只存 source+uid，引擎每跳活读文件——不拷贝
      token）；引擎内部 FLAGGED 改写/工具修形/EDGE_READS 探测/runsOutAt/spareFree 随包。
      被删 TS 路径：登录轮询、刷新 POST、头工厂、meter 额度、四头派生、import.ts、quota.ts。

## 2. opendesign——已落地（2026-10-18，待活测）

- [x] wire/额度三读端点随上游（设备登录 + 控制面 usage 走引擎；裸 factory 零宿主耦合，
      两个 host 进桥闭集）；UA `opencode-opendesign-auth/<v>` 随装载版本自动跟
      （engine.ts opendesignEngineUserAgent，种子版本兜底）。
- [x] 目录行参数仍由本仓 curator 钉（catalog.ts /models 读留本仓——引擎的
      provider.models 说 magpie 行形状，不接管目录；适配器偏离项）。
- [x] hop 的 wire facts（baseURL + runtime key + UA）取自引擎 loader；被删 TS：设备
      start/poll、批准解析、quota.ts 三读与 parse。**留本仓**：粘贴 key 登录（vault 域）、
      无过期刷新 no-op、cache 剥除。行为差异（已接受）：无档位时 plan 名用上游兜底
      「Open Design」（本仓原为 undefined）；窗口行不再带 used/total 原始数（上游只给
      百分比与 display）。
- [ ] 若上游日后新增 Responses/Anthropic 线，引擎侧随包（本仓路由仍是单 Chat 线，
      目录 wire 元数据留本仓时一并议）。

## 3. autoclaw——已落地（2026-10-18，待活测）

- [x] 国际版登录整段交上游包（本地 loopback 服务器、滑块、官方端口池、state 校验回
      调、code 兑换都在包内；我们只透传 url + 等 callback）。被删 TS：`local-oauth.ts`
      全文、send-code/agent-login 调用、biz 头工厂、`refreshAutoclaw`。
- [x] 国内 +86 手机验证码两步随上游（engine.ts 挂起态保存包的 started 登录，第二 RPC
      提交验证码给 callback；数字验证码按数字发）；refresh 一次一换 + 无名账号就地正名
      随上游；三 host（global/cn/managed）进桥闭集；hop 的 biz 头组、官方 system 前缀、
      max_tokens 剥除、FLAGGED 改写、双 host 失效倒换、CN managed 网关全部随包
      （families 的 applyCache 只剩缓存剥除）。额度 usage 的 display 行映射（积分总额 +
      命名钱包），签到状态行维持不采纳。
- [x] 国际行 reasoningEfforts 暂不声明是本仓目录侧裁定，不受引擎影响，维持。

## 4. zed——已落地（2026-10-18，待活测）

- [x] 登录由上游包自起 loopback server（RSA keypair + native_app_signin 页 + state
      回调 + /me 读），我们只透传 url + 等 callback；被删 TS：accounts 的 RSA 登录
      半段（padded/decrypt/buildZedSession/finishZedSignIn）。
- [x] 三 wire（chat/responses/anthropic → x_ai/open_ai/anthropic vendor）、模型 token
      铸造与 staleness 重铸、402 透传、事件流翻译全部随包（被删 TS：transport.ts、
      request.ts 事件机、quota.ts /me 读）；engine.ts forwardZedEngine 只做管道。
      cloud.zed.dev 进桥闭集；usage 的 plan 写回经 client.auth.set 落 vault
      （capture plan slug 供卡片）。
- [x] 账期 `subscription_period.ended_at` 无卡面槽（现状丢弃），维持；refresh 维持
      恒等（存证对永不过期，模型 token 由引擎按铸造管理）。

## 5. cline——已落地（2026-10-18，待活测）

- [x] 钉版回退：3.0.70/0.0.92 → 上游 3.0.68/0.0.90（上游内部三处版本引用不一致，
      随包不修）。
- [x] `X-Task-ID` 派生公式换上游（sha256("cline task\0"+会话)→v4 形状）：已活测钉住的缓存
      前缀作废，命中率重置一次；适配层经 `x-magpie-cline-session` 会话头转交派生。
- [x] 无具名会话不发 `X-Task-ID`（本仓恒发 `dsh-cline` 兜底——rules.md 回退常量条款的
      豁免已随「全过」裁定：兜底 id 不进会话头，引擎按自身输入派生；缓存侧
      CLINE_STABLE_SESSION 仍是 system-pin 的「永不钉」哨兵）。
- [x] DeepSeek `pinUpstream`（providerOptions.gateway.only）功能随包（默认关，我们不开）。
- [x] 刷新失败分类放宽：200+success:false 归临时错误重试（适配层只认引擎的 Lapsed
      verdict——signIn:'expired'/.expired——转 401 invalid_grant；正文关键词一律不重判）。
- [x] 模型目录整棵云表入列 + `output: 0`：目录侧维持本地 curator 闭集（CLINE_MODELS +
      catalog.ts 合并），引擎 config 的模型面与目录不再同步保证（豁免同上裁定）。
- [x] 额度随包三读（usage-limits ∥ me → 按 me 候选 id 拉 balance，{balance} 百万美元位）；
      旧 quota.ts 的 entitlements 1e-8 美元 caps 合成与独立 /plan 读被删（引擎只说
      percentUsed 窗口 + 余额字符串，不发明 used/total 美元槽）。plan 从 me.plan 直接读，
      usage envelope 的 unwrap 也随包（loader 返回已剥壳 body，families 的
      unwrapCompletionsBody 变成幂等 no-op，留着兜非引擎答案）。
- [x] 刷新单次消费随包：auth.refresh(authObject)（注意非 getter）、held 按 refresh token
      键控链、写回 client.auth.set 按 uid 合并 vault 行；vault 的 `workos:` 前缀约定由
      适配层 sessionFromEngineResult 的 formatClineAccessToken 保持。
- [x] 代理侧 clineQuotaFailure 对引擎已归一化的 `usage limit reached: ` 前缀不二次加前缀
      （引擎 failure() 先归一、我们后分类的双层组合）。
- [x] 被删 TS：quota.ts（+lib 残件）、index 的 clineDeviceSpec/registerClineTokens/
      refreshCline/clineUpstreamHeaders；accounts 的登录/完成改吃 clineEngineAuthorize
      的 {authorizeUrl, settle} 面（DeviceFlowManager 不再进 cline 家族）。

## 6. command-code——已落地（2026-10-18，待活测）

- [x] 钉版回退：1.84.0 → 上游 1.72.2（上游 README 另引 1.79.2，三处不一致，随包不修）。
      本仓 `COMMAND_CODE_CLI_VERSION` 1.84.0 只留在目录/身份头（本地路径），Go 线随包。
- [x] Go 线指纹：`User-Agent: 'cli'` + `x-project-slug: 'magpie'` + 进程级 `x-session-id`
      randomUUID（rules.md 禁 random 当会话键的豁免：进程级非请求级）；丢 threadId 亲和，
      缓存前缀作废——cache.ts 收缩为 strip-only，`cacheSessionId` 只作日志亲和。
- [x] 登录流换上游 POST+CORS 随机口 loopback（本仓 GET 固定端口段与 flow spec 删除；
      accounts.ts 吃 engine 的 {authorizeUrl, settle} 面，claims 语义保留）。
- [x] 模型列表按套餐裁剪：**豁免**——目录侧维持本地闭集 + 公开 /provider/v1/models 刷新
      （引擎 provider.models 不接管），PREMIUM/GO_BLOCKED 裁剪不进本仓目录。
- [x] 流截断处理换上游（cut-short 补 CUT_SHORT_NOTE 优雅收尾；本仓 502 retryable 删除）。
- [x] effort 档位就近拟合（fitEffort）随包；本仓「无条目不发明」只对目录行生效。
- [x] （清单外补记）hop 路由随包：付费 key 走 Provider API 透传（/provider/v1/chat/
      completions，Authorization + x-api-key 双签），Go key 走 /alpha/generate JSONL 翻译，
      未存 plan 的 Go key 靠 GO_NO_API 拒绝自检（首跳被拒一次后写回 Go 再重发）——本仓
      旧「一切走 /alpha/generate」的翻译层（transport.ts/request.ts）删除。
- [x] 额度随包两读（subscriptions + credits → allowanceOf 窗口/余额，plan/until/renew）；
      旧 quota.ts 四读（whoami/credits/subscriptions/usage-summary）删除，credits 池数学
      与本仓旧实现同口径（plan 月度与池取大 + purchased/free）。plan 经 client.auth.set
      写回（引擎给展示名，适配层映射回 planId 存 vault；'No plan' 不落）。
      身份（whoami→人类账号名）只在登录/导入时由本仓做——引擎 usage 不读 whoami，
      已存 opaque id 不再经额度链晋升（重登录即可）。
- [x] 导入 copy-only 裁定保住：本仓从不设 metadata.cli，引擎 liveKey 永不重读
      ~/.commandcode/auth.json；paste/env/cli-file 导入路径全留本仓。
- [x] 拒绝分类保留本仓（failure.ts）：引擎 failure() 归一后的 'Model not in plan: '
      拼写进正则；401/upgrade/credits/window 的改写语义不变。

## 7. cursor——阻塞已消解，待维护者确认口径后落地

**h2 另案决议材料（2026-10-18 复核，旧结论作废）**：旧记录「h2 Run 连 fetch 层都不可注入」
只看了引擎一侧。实际两边同形——本仓 TS 的 cursor hop 本来就是裸 `http2.connect`
（`h2-session.ts`：Run + AvailableModels/GetUsableModels 发现 RPC），且 cursor 家族自有
`cursorUpstreamProxy` 出口（`PI_CURSOR_PROXY`/`CURSOR_PROXY`/插件配置，区域代理语义，
文档明确「Auth poll, refresh, and quota stay direct」）——代理卡对 cursor 的 h2 主通道
**从来就不是约束**，这是既有的家族例外。引擎侧 0.1.x 的 `open()`：h2 优先（裸连），
h2Blocked 后 10 分钟粘性切 `openH1`——H1 走 `BidiAppend`/`RunSSE` 两个**纯 fetch** 端点，
可注册进桥（api2.cursor.sh / agentn.global.api5.cursor.sh）。即引擎 = 现状同形 + 多一条
fetch 兜底。待确认一句：cursor 落地后 `cursorUpstreamProxy` 语义对 h2 通道如何延续
（引擎不读这个配置；选项 A 接受引擎直连+H1 兜底、cursor 例外照旧；B 给引擎的 h2
补一个 node:http2 agent 走 cursorProxy——需自写，上游无此口子）。确认后按标准配方落地。

- [ ] 默认 host us→global + `GetServerConfig` 按账号发现（团队账号风险随上游）。
- [ ] 版本钉 cli-2026.07.23 → 2026.09.23 + 本机 cursor-agent 探测。
- [ ] Run 握手簇整簇换（allowed-tools 头、request_context 回 env、exec case36、closeExec、
      5s 心跳、ModelDetails/field19、KV miss 文案）：2026-09-29 活测口径作废，需重新活测。
- [ ] OAuth 刷新语义换上游（浏览器登录无物可续、约两月重登 vs 本仓
      exchange_user_api_key 续期）——切换后现有刷新链停用。
- [ ] CLI 导入临期自续（跑 cursor-agent status）vs 本仓只读抛 ImportedLoginStale。
- [ ] 目录架构：@size 行 / Max Mode 自动升级 / pick 变体 vs 本仓家族行 + fast 孪生
      （目录侧可维持本地，但引擎模型面不再一一对应）。
- [ ] h2 失败的 HTTP/1.1 兜底路径随上游新增。

## 8. glm（zcode）

落地勘察（2026-10-18，执行时先读这段）：包 `@magpie-community/opencode-zcode-auth` 0.1.19
（1758 行，快照 .local/upstream-magpie/packages/zcode/）；入口具名导出
`ZCodeAuthPlugin({client})`（非裸 factory）；methods 双站点（zai → api.z.ai /
bigmodel → open.bigmodel.cn），`authorize_url` 深链改写在 flow 里（index.mjs:909）；
loader + usage 齐备；`_internal` 暴露 entry/limitWindows/plansOf/giftOf/dualUsage 等。
本仓 TS 侧 8 文件（src/oauth/glm/{index,accounts,cli-flow,import,quota,request,cache}.ts），
双 wire（chat + anthropic，proxy.ts 两处 headersOf）。桥闭集候选 host：
api.z.ai、open.bigmodel.cn、ZCODE 登录域（cli-flow 现地址）。清单七项签核照旧适用。

- [ ] hop 端点换上游直连 `api.z.ai` / `open.bigmodel.cn`，放弃 `zcode.z.ai` ultra 网关
      （官方网关归因作废——这是最强源，慎重）。
- [ ] `authorize_url` redirect 改写（ZCODE/app/oauth/login 深链）——事故档案记录双重
      核销/兑换失败（zai-org/feedback #705/#718）。
- [ ] 铸 key 名与 ZCode 共用 `zcode-api-key`（轮换联动）vs 本仓隔离名。
- [ ] start-plan / gift 路由随包进来（captcha 伪装墙）——适配器需钉死不启用，除非翻案。
- [ ] 账号展示回退 `user_id`（opaque id 上卡面——违反隐私规则，适配层拦截或豁免）。
- [ ] 无时区戳一律 +08:00（Z.ai 区域的 UTC 读法作废）。
- [ ] 运行时 `client/configs` 目录拉取 vs 本仓 curated 目录（目录侧维持本地）。
