# upstream-engine（上游引擎基座）

维护者裁定链：2026-10-17 **试点先行**（kimi-work + 自动跟进）→ 2026-10-18
**全过 + 不回退、不旧兼容**——引擎即实现，被替换的 TS wire 路径删除，无
flag、无双轨、无回退梯。每家推进仍按 [`ROLLOUT.md`](ROLLOUT.md) 的行为反转
清单签核；上游 npm 发版自动跟进（豁免的只是引擎家族上游包换版的活测门禁）。

## 供给面（packages.ts）

- 清单 `<dataDir>/upstream-engines/manifest.json`（auth.json 同目录模式）：
  `{ engines: { '<family>': { npm, version, integrity } } }`。种子钉本仓
  `.local` 克隆审计过的版本（kimi-work 0.1.4、workbuddy 0.1.24），integrity
  首次引导时从 registry 元数据取并落盘（TOFU，此后换版必须匹配新版本元数据）。
- 下载只走 `outboundFetch`；tarball host 钉死 registry.npmjs.org；sha512 必须匹配
  「点名该版本的 registry 元数据」；60s 超时、5 MiB 上限；解包后必须含 index.mjs 且
  package.json version 与请求一致（引擎自己在 import 时读它）。
- 缓存 `cache/<name-escaped>/<version>/`，0700；换版先落新目录再原子改写 manifest，
  磁盘保留最近 3 版（KEEP_VERSIONS），回退 = 把 manifest.version 改回去。
- 作用域钉死 `@magpie-community/`：任何其它名字在 validNpmName 处被拒。

## 加载面（engine.ts）

- `loadUpstreamEngine(family, { authPath, fetchFn, entry })`：按缓存目录动态
  import，模块实例按「family@目录」缓存——auto-follow 换版后是新 key，在途
  hop 用旧模块跑完。
- `entry` 由家族适配层声明（包的入口各不相同：kimi-work 是
  `_internal.createPlugin`，workbuddy 是具名 `WorkBuddyAuthPlugin` 导出；默认
  按 OpenCode 惯例取 default 导出）。基座断言 entry 可调；适配层建好插件后
  再用 `assertEnginePlugin` 断言 `auth.methods[].authorize / auth.loader /
  auth.usage`。契约不符 → 抛错并记 60s 负缓存，期间该家的操作带着引擎的
  错误失败——**没有第二条车道**（2026-10-18 裁定）。

## URL 作用域 global-fetch 桥（bridge.ts）

除 kimi-work 外，其余引擎包都不收 `fetchImpl`——登录轮询、刷新、配置读、
wire 调用全说裸 global fetch。bridge 把 `globalThis.fetch` 换成路由器：

- 命中「适配器注册的该家端点 host 闭集」→ 走 `outboundFetch`（代理卡合规，
  outbound.ts「全仓唯一出口」不破）；
- 其余流量原样交给捕获的原 global fetch——DSH、别的插件、本仓 loopback
  测试都感知不到桥存在。

host 是精确闭集（rules.md），不按前缀/通配路由；`configureEngineBridge`
是测试缝。outbound 防火墙测试把 bridge.ts 与 outbound.ts 并列为唯二允许
碰 global fetch 的文件。引擎包响应上的宿主协议头（`X-Magpie-Sign-In`）由
proxy 层 `WIRE_ONLY` 闭集剥除，永远不落 DSH 客户端。

## 自动跟进（watch.ts）

- 照抄 self-update 节奏：15 分钟一轮、unref、启动先跑一遍
  （self-update.ts:90-101 / update-prefs.ts:13）。
- 上游无 GitHub releases，发布走 Actions OIDC → npm，版本感知只能靠 registry
  dist-tags（可行性研究实测：轻量端点 36 字节；packument 提供 dist.integrity）。
- manifest 未初始化 → 空转跳过，零成本零落盘。
- 结果写 `upstream-engines/state.json`，进 controller.snapshot 的
  `upstreamEngines`，About 卡状态行展示。坏发版的兜底是「契约断言 + 操作
  带错误失败 + 三版缓存手工回退 manifest」，不是回滚网络、不是静默降级。

## 不要做的事

- 不在引擎车道造第二条实现：被引擎替换的 TS wire 路径删了就不复活，
  翻案走 ROLLOUT.md 的清单重新评审。
- 不要在引擎路径上放松 rules.md：DSH 会话字段照旧由 `rewriteUpstreamBody`
  剥除，家族缓存亲和照旧本仓实现；目录闭集（models.md）始终由本仓 curator
  钉——引擎的 provider.models 说 magpie 行形状，不接管目录。
- 不要为引擎流量绕开 outboundFetch 或 bridge 注册面（host 闭集之外不许加
  路由）；不要允许 `@magpie-community/` 之外的作用域或 registry 之外的
  tarball host。
- 不要手改 `upstream-engines/` 下的缓存内容做调试——删掉对应版本目录让它重下。

## 活测（维护者收口）

每家真实账号登录 + 一次引擎 chat hop + `npm run analyze`，结论按惯例落
docs/error.md；已落地：kimi-work（2026-10-18）、workbuddy 双 build（待活测）。
