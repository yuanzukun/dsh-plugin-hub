import assert from 'node:assert/strict'
import { chmod, mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { test } from 'node:test'
import { AuthController } from '../lib/oauth/controller.js'
import { accountIdOf, listStoredSessions, saveSession } from '../lib/oauth/store.js'
import { installedVersion } from '../lib/utils/update.js'
import { CODEX_USAGE_URL } from '../lib/oauth/codex/index.js'
import {
  HARNESS_ANTHROPIC_API,
  HARNESS_COMPLETIONS_API,
  assertDshServiceableProvider,
  catalogKeys,
  catalogProviders,
} from '../lib/oauth/models.js'
import { ModelSwitch } from '../lib/oauth/model-switch.js'
import { glmSession } from '../lib/oauth/glm/index.js'
import { OPENCODE_GO_BUILTIN_ROUTE_ID, OPENCODE_GO_EXTRA_MODELS, OPENCODE_GO_EXTRA_ROUTE, OPENCODE_GO_ROUTES, OPENCODE_ZEN_ROUTES } from '../lib/apikey/opencode-go/models.js'
import { kiroSession, KIRO_MODELS } from '../lib/oauth/kiro/index.js'
import { kiroCatalogModels, refreshKiroCatalog, resetKiroCatalogCache } from '../lib/oauth/kiro/catalog.js'
import { antigravitySession } from '../lib/oauth/antigravity/index.js'
import { kimiSession } from '../lib/oauth/kimi/index.js'
import { kimiCatalogModels, refreshKimiCatalog, resetKimiCatalogCache } from '../lib/oauth/kimi/catalog.js'
import { devinSession } from '../lib/oauth/devin/index.js'
import { devinCatalogModels, resetDevinCatalog, setDevinCatalogModels } from '../lib/oauth/devin/catalog.js'
import { commandCodeSession } from '../lib/apikey/command-code/index.js'
import { commandCodeCatalogModels, refreshCommandCodeCatalog, resetCommandCodeCatalogCache } from '../lib/apikey/command-code/catalog.js'

const KIRO_RT = `rt_${'x'.repeat(120)}`

function createPiAiSettings(initialProviders = {}) {
  const section = { providers: structuredClone(initialProviders) }
  const ops = []
  return {
    ops,
    section,
    describe() {
      return [{ ns: 'llm-pi-ai', value: structuredClone(section) }]
    },
    async mutate(target, mutations) {
      if (target !== 'llm-pi-ai') throw new Error(`unknown settings namespace ${target}`)
      const next = { providers: { ...section.providers } }
      for (const row of mutations) {
        const key = row.path?.[1]
        if (row.path?.[0] !== 'providers' || typeof key !== 'string') throw new Error('bad path')
        if (row.op === 'unset') {
          delete next.providers[key]
        } else if (row.op === 'set') {
          assertDshServiceableProvider(key, row.value)
          next.providers[key] = structuredClone(row.value)
        }
      }
      section.providers = next.providers
      ops.push({ target, mutations })
    },
  }
}

const GLM_CURRENT = ['oauth-glm/glm-5.3-flashx', 'oauth-glm/glm-5.3', 'oauth-glm/glm-5.3-flash', 'oauth-glm/glm-5-turbo']
const GLM_STALE = ['oauth-glm/glm-4.7', 'oauth-glm/glm-5', 'oauth-glm/glm-5.1', 'oauth-glm/glm-5.2']

function glmQuotaFetch() {
  return async () => new Response(JSON.stringify({
    data: { level: 'pro', list: [] },
  }), { status: 200, headers: { 'content-type': 'application/json' } })
}

async function glmController({ dir, models, ops = [], settings }) {
  const authPath = join(dir, 'auth.json')
  await saveSession('glm', glmSession({
    accessToken: 'glm-token',
    account: 'dev@x',
    region: 'bigmodel',
  }), authPath)
  const store = settings ?? {
    mutate: async (target, mutations) => { ops.push({ target, mutations }) },
  }
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: store,
    models,
    fetchFn: glmQuotaFetch(),
  })
  return { controller, ops: store.ops ?? ops, authPath, settings: store }
}

test('snapshot reports logged-out accounts and empty providers', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
  })
  const snap = await controller.snapshot()
  assert.equal(snap.accounts.codex.loggedIn, false)
  assert.equal(snap.accounts.grok.loggedIn, false)
  assert.equal(snap.accounts.kimi.loggedIn, false)
  // Copilot was removed as a family: no account row, no catalog group.
  assert.equal(snap.accounts.copilot, undefined)
  assert.equal(snap.accounts.opencode, undefined)
  assert.equal(snap.accounts['opencode-go'].loggedIn, false)
  assert.deepEqual(snap.accounts['opencode-go'].accounts, [])
  assert.equal(snap.opencodeGo.cookieSet, false)
  assert.equal(snap.opencodeGo.apiKeySet, false)
  assert.equal(snap.opencodeGo.quota.status, 'idle')
  assert.deepEqual(snap.providers, [])
  // 19 single-route OAuth families + Zed's 3 wire routes + OpenCode Go's 3 + Zen's 3.
  assert.equal(snap.catalog.length, 28)
  assert.equal(snap.accounts.anthropic, undefined)
  assert.equal(snap.catalog.some((row) => row.family === 'anthropic'), false)
  assert.equal(snap.catalog.some((row) => row.family === 'kimi'), true)
  assert.equal(snap.catalog.some((row) => row.family === 'devin'), true)
  assert.equal(snap.accounts.devin.loggedIn, false)
  assert.equal(snap.catalog.some((row) => row.family === 'opencode'), false)
  const go = snap.catalog.find((row) => row.family === OPENCODE_GO_EXTRA_ROUTE.id)
  assert.equal(go.loggedIn, false)
  assert.deepEqual(go.models.map((model) => model.id), OPENCODE_GO_EXTRA_MODELS.map((model) => model.id))
  for (const route of OPENCODE_ZEN_ROUTES) {
    const zen = snap.catalog.find((row) => row.family === route.id)
    assert.equal(zen.loggedIn, false, `${route.id} stays locked without a key`)
    assert.deepEqual(zen.models.map((model) => model.id), route.models.map((model) => model.id))
  }
  assert.equal(go.models.every((model) => model.enabled), true)
  assert.equal(snap.catalog.filter((row) => row.family.startsWith('opencode-go')).length, OPENCODE_GO_ROUTES.length)
  assert.equal(snap.catalog.some((row) => row.family === 'copilot'), false)
  // No opt-in rows exist any more: every listed model defaults on, and the
  // removed `-900k` key never appears in the selection.
  assert.equal(snap.catalog.every((row) => row.models.every((model) => model.enabled)), true)
  assert.equal(snap.selected.includes('oauth-codex/gpt-5.5'), true)
  assert.equal(snap.selected.includes('oauth-codex/gpt-5.6-sol-900k'), false)
  assert.equal(typeof snap.update.version, 'string')
  assert.equal(snap.update.repoSlug, 'xxww0098/dsh-plugin-oauth-subs')
  assert.equal(['win', 'mac', 'linux'].includes(snap.update.platform), true)
})

test('saveOpencodeGo stores the key in the vault, mirrors OPENCODE_API_KEY, and hides secrets', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const keys = new Map()
  const credentials = {
    async describe(ref) { return { configured: keys.has(ref), writable: true } },
    async resolve(ref) { return keys.has(ref) ? { value: keys.get(ref), source: 'file' } : undefined },
    async set(ref, value) { keys.set(ref, value) },
    async unset(ref) { keys.delete(ref) },
  }
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    credentials,
  })
  const saved = await controller.saveOpencodeGo({ apiKey: 'sk-test' })
  assert.equal(saved.accounts.length, 1)
  assert.equal(saved.accounts[0].apiKeySet, true)
  assert.equal(saved.loggedIn, true)
  assert.equal(saved.activeId, saved.accounts[0].id)
  assert.equal(keys.get('OPENCODE_API_KEY'), 'sk-test')
  assert.equal('cookieHeader' in saved.accounts[0], false)
  const vault = JSON.parse(await readFile(join(dir, 'opencode-go.json'), 'utf8'))
  assert.equal(vault.accounts[vault.activeId].apiKey, 'sk-test')

  const cleared = await controller.clearOpencodeGo('key', saved.activeId)
  assert.equal(cleared.accounts[0].apiKeySet, false)
  assert.equal(keys.has('OPENCODE_API_KEY'), false)
})

test('OpenCode Go switch mirrors the active account key and logout drops the last one', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const keys = new Map()
  const credentials = {
    async describe(ref) { return { configured: keys.has(ref), writable: true } },
    async resolve(ref) { return keys.has(ref) ? { value: keys.get(ref), source: 'file' } : undefined },
    async set(ref, value) { keys.set(ref, value) },
    async unset(ref) { keys.delete(ref) },
  }
  const fetchFn = async () => new Response(
    JSON.stringify({ usage: { rolling: { usagePercent: 10, resetInSec: 30 } } }),
    { status: 200, headers: { 'content-type': 'text/javascript' } },
  )
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    credentials,
    fetchFn,
  })
  await controller.saveOpencodeGo({ apiKey: 'sk-one', cookie: 'Fe26.2one', workspace: 'wrk_one' })
  assert.equal(keys.get('OPENCODE_API_KEY'), 'sk-one')
  const second = await controller.saveOpencodeGo({ apiKey: 'sk-two', cookie: 'Fe26.2two', workspace: 'wrk_two' })
  assert.equal(second.accounts.length, 2)
  assert.equal(second.activeId, 'wrk_two')
  assert.equal(keys.get('OPENCODE_API_KEY'), 'sk-two')
  const renamed = await controller.saveOpencodeGo({ id: 'wrk_one', displayName: 'user@example.com' })
  assert.equal(renamed.activeId, 'wrk_two')
  assert.equal(renamed.accounts.find((row) => row.id === 'wrk_one').account, 'user@example.com')
  assert.equal(keys.get('OPENCODE_API_KEY'), 'sk-two')

  const switched = await controller.switchAccount('opencode-go', 'wrk_one')
  assert.equal(switched.accounts['opencode-go'].activeId, 'wrk_one')
  assert.equal(keys.get('OPENCODE_API_KEY'), 'sk-one')

  const afterLogout = await controller.logout('opencode-go', 'wrk_one')
  assert.equal(afterLogout.activeId, 'wrk_two')
  assert.equal(afterLogout.accounts.length, 1)
  assert.equal(keys.get('OPENCODE_API_KEY'), 'sk-two')

  const empty = await controller.logout('opencode-go', 'wrk_two')
  assert.equal(empty.accounts.length, 0)
  assert.equal(keys.has('OPENCODE_API_KEY'), false)
})

test('OpenCode Go keeps OPENCODE_API_KEY only while some stored account holds a key', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const keys = new Map()
  const credentials = {
    async describe(ref) { return { configured: keys.has(ref), writable: true } },
    async resolve(ref) { return keys.has(ref) ? { value: keys.get(ref), source: 'file' } : undefined },
    async set(ref, value) { keys.set(ref, value) },
    async unset(ref) { keys.delete(ref) },
  }
  const fetchFn = async () => new Response(
    JSON.stringify({ usage: { rolling: { usagePercent: 10, resetInSec: 30 } } }),
    { status: 200, headers: { 'content-type': 'text/javascript' } },
  )
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    credentials,
    fetchFn,
  })
  await controller.saveOpencodeGo({ apiKey: 'sk-one', cookie: 'Fe26.2one', workspace: 'wrk_one' })
  await controller.saveOpencodeGo({ cookie: 'Fe26.2two', workspace: 'wrk_two' })
  const roster = await controller.switchAccount('opencode-go', 'wrk_two')
  assert.equal(roster.accounts['opencode-go'].activeId, 'wrk_two')
  // A keyless quota-only account keeps the other stored account's key alive.
  assert.equal(keys.get('OPENCODE_API_KEY'), 'sk-one')

  // Removing the last keyed account drops the credential, so sync() takes the
  // plugin route back out of DSH instead of leaving models with no key.
  await controller.logout('opencode-go', 'wrk_one')
  assert.equal(keys.has('OPENCODE_API_KEY'), false)

  // Clearing a whole account (field undefined) mirrors the credential too.
  await controller.saveOpencodeGo({ apiKey: 'sk-three', workspace: 'wrk_two' })
  assert.equal(keys.get('OPENCODE_API_KEY'), 'sk-three')
  const cleared = await controller.clearOpencodeGo(undefined, 'wrk_two')
  assert.equal(keys.has('OPENCODE_API_KEY'), false)
  assert.equal(cleared.accounts.length, 1)
})

test('OpenCode Go card title uses the dashboard email the cookie scrapes', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const page = 'rollingUsage:$R[35]={status:"ok",resetInSec:30,usagePercent:10},'
    + 'userEmail[\\"wrk_abc123\\"]=$R[0]=$R[2](($R[1]={p:0,s:0,f:0}));$R[28]($R[1],"dev@example.com");'
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async () => new Response(page, { status: 200, headers: { 'content-type': 'text/javascript' } }),
  })
  const snap = await controller.saveOpencodeGo({ apiKey: 'sk-test', cookie: 'Fe26.2token', workspace: 'wrk_abc123' })
  const row = snap.accounts.find((entry) => entry.active)
  assert.equal(row.email, 'dev@example.com')
  assert.equal(row.account, 'dev@example.com')
  assert.equal(row.workspaceId, 'wrk_abc123')
})

test('OpenCode Go unlock needs a key; picker selection filters the supplemental route', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const keys = new Map([['OPENCODE_API_KEY', 'sk-test']])
  const credentials = {
    async describe(ref) { return { configured: keys.has(ref), writable: true } },
    async set(ref, value) { keys.set(ref, value) },
    async unset(ref) { keys.delete(ref) },
  }
  const store = createPiAiSettings()
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: store,
    credentials,
    models: new ModelSwitch(),
    cursorAutoImport: false,
    ollamaAutoImport: false,
    kimiAutoImport: false,
  })
  const snap = await controller.snapshot()
  assert.equal(snap.catalog.find((row) => row.family === OPENCODE_GO_EXTRA_ROUTE.id).loggedIn, true)
  await controller.sync()
  // The plugin only writes its supplemental route; DSH's built-in opencode-go
  // catalog route is never registered by the plugin.
  assert.equal(store.section.providers[OPENCODE_GO_BUILTIN_ROUTE_ID], undefined)
  assert.deepEqual(store.section.providers[OPENCODE_GO_EXTRA_ROUTE.id].models.map((model) => model.id), OPENCODE_GO_EXTRA_MODELS.map((model) => model.id))
  // Go and family routes land in one llm-pi-ai mutate: one host reconcile per sync.
  assert.equal(store.ops.length, 1)

  await controller.setModels({ family: OPENCODE_GO_EXTRA_ROUTE.id, on: false })
  assert.equal(store.ops.length, 2)
  assert.equal(store.section.providers[OPENCODE_GO_EXTRA_ROUTE.id], undefined)
  assert.equal(store.section.providers[OPENCODE_GO_BUILTIN_ROUTE_ID], undefined)

  await controller.setModels({ family: OPENCODE_GO_EXTRA_ROUTE.id, on: true })
  assert.deepEqual(store.section.providers[OPENCODE_GO_EXTRA_ROUTE.id].models.map((model) => model.id), OPENCODE_GO_EXTRA_MODELS.map((model) => model.id))
})

test('OpenCode Go routes appear only while a key is stored', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const keys = new Map()
  const credentials = {
    async describe(ref) { return { configured: keys.has(ref), writable: true } },
    async resolve(ref) { return keys.has(ref) ? { value: keys.get(ref), source: 'file' } : undefined },
    async set(ref, value) { keys.set(ref, value) },
    async unset(ref) { keys.delete(ref) },
  }
  // Start from the auto-written built-in profile of older plugin versions:
  // it must be taken back, and a key must only ever add the supplemental route.
  const store = createPiAiSettings({
    'opencode-go': {
      apiKeyEnv: 'OPENCODE_API_KEY',
      headers: { 'x-opencode-session': 'dsh-opencode-go' },
    },
  })
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: store,
    credentials,
    models: new ModelSwitch(),
    cursorAutoImport: false,
    ollamaAutoImport: false,
    kimiAutoImport: false,
  })
  await controller.sync()
  assert.equal(store.section.providers[OPENCODE_GO_BUILTIN_ROUTE_ID], undefined)
  assert.equal(store.section.providers[OPENCODE_GO_EXTRA_ROUTE.id], undefined)

  const saved = await controller.saveOpencodeGo({ apiKey: 'sk-test' })
  assert.equal(keys.get('OPENCODE_API_KEY'), 'sk-test')
  await controller.sync()
  assert.equal(store.section.providers[OPENCODE_GO_BUILTIN_ROUTE_ID], undefined)
  assert.deepEqual(store.section.providers[OPENCODE_GO_EXTRA_ROUTE.id].models.map((model) => model.id), OPENCODE_GO_EXTRA_MODELS.map((model) => model.id))

  await controller.clearOpencodeGo('key', saved.activeId)
  assert.equal(keys.has('OPENCODE_API_KEY'), false)
  await controller.sync()
  assert.equal(store.section.providers[OPENCODE_GO_BUILTIN_ROUTE_ID], undefined)
  assert.equal(store.section.providers[OPENCODE_GO_EXTRA_ROUTE.id], undefined)
})

test('sync after a stored session writes llm-pi-ai providers', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  await saveSession('grok', {
    accessToken: 'a',
    refreshToken: 'r',
    expiresAt: Date.now() + 60 * 60_000,
    tokenEndpoint: 'https://auth.x.ai/oauth2/token',
    account: 'grok-user',
  }, authPath)
  const ops = []
  const fetchFn = async () => new Response('{"config":{"subscription_tier":"SuperGrok","creditUsagePercent":10}}', {
    status: 200,
    headers: { 'content-type': 'application/json' },
  })
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async (target, mutations) => { ops.push({ target, mutations }) } },
    fetchFn,
  })
  const result = await controller.sync()
  assert.equal(result.routes[0].provider, 'oauth-grok')
  assert.equal(ops[0].target, 'llm-pi-ai')
  const status = await controller.snapshot()
  assert.equal(status.accounts.grok.account, 'grok-user')
  assert.equal(status.accounts.grok.quota.status, 'ready')
  assert.equal(status.accounts.grok.quota.planType, 'SuperGrok')
  assert.equal(status.accounts.grok.quota.planLabel, 'SuperGrok')
  assert.equal(status.accounts.grok.quota.rows[0].remainingPercent, 90)
})

test('overlapping sync() calls queue: one mutate at a time, both full syncs resolve', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const ops = []
  let inMutate = false
  const settings = {
    // Re-entrancy detector: a second mutate must not begin before the first
    // settles. The setImmediate yield opens the window interleaving would use.
    mutate: async (target, mutations) => {
      assert.equal(inMutate, false, 'settings.mutate re-entered before the previous call completed')
      inMutate = true
      try {
        ops.push({ target, mutations })
        await new Promise((resolve) => setImmediate(resolve))
      } finally {
        inMutate = false
      }
    },
  }
  const { controller } = await glmController({ dir, settings, models: new ModelSwitch({ path: join(dir, 'models.json') }) })
  const [first, second] = await Promise.all([controller.sync(), controller.sync()])
  assert.equal(first.routes[0].provider, 'oauth-glm')
  assert.equal(second.routes[0].provider, 'oauth-glm')
  // Each queued call performed its own full sync — one llm-pi-ai mutate each.
  assert.equal(ops.length, 2)
  assert.equal(ops.every((op) => op.target === 'llm-pi-ai'), true)
})

test('setModels contextKey customizes a route window and resets to catalog', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const settings = createPiAiSettings()
  const { controller } = await glmController({ dir, settings, models: new ModelSwitch({ path: join(dir, 'models.json') }) })
  await controller.sync()
  const glmRows = () => settings.section.providers['oauth-glm'].models
  assert.equal(glmRows().find((m) => m.id === 'glm-5.3').contextWindow, 400_000)

  const snap = await controller.setModels({ contextKey: 'oauth-glm/glm-5.3', context: 300_000 })
  assert.equal(glmRows().find((m) => m.id === 'glm-5.3').contextWindow, 300_000)
  // `-1m` rows no longer exist; a base override is the only large window.
  assert.equal(glmRows().find((m) => m.id === 'glm-5.3-1m'), undefined)
  const described = snap.catalog.find((row) => row.family === 'glm').models
  assert.equal(described.find((m) => m.id === 'glm-5.3').window, '300K')
  assert.equal(described.find((m) => m.id === 'glm-5.3').custom, true)
  assert.equal(described.find((m) => m.id === 'glm-5.3').windowMax, '1M')
  assert.equal(described.find((m) => m.id === 'glm-5.3-flash').custom, false)

  // Reset restores the catalog window everywhere.
  const reset = await controller.setModels({ contextKey: 'oauth-glm/glm-5.3', context: null })
  assert.equal(glmRows().find((m) => m.id === 'glm-5.3').contextWindow, 400_000)
  const resetDescribed = reset.catalog.find((row) => row.family === 'glm').models
  assert.equal(resetDescribed.find((m) => m.id === 'glm-5.3').window, '400K')
  assert.equal(resetDescribed.find((m) => m.id === 'glm-5.3').custom, false)

  // The vendor ceiling caps edits: GLM-5.3 tops out at the official 1M.
  await assert.rejects(controller.setModels({ contextKey: 'oauth-glm/glm-5.3', context: 1_000_001 }), /between 4096 and 1000000/)
  await controller.setModels({ contextKey: 'oauth-glm/glm-5.3', context: 1_000_000 })
  assert.equal(glmRows().find((m) => m.id === 'glm-5.3').contextWindow, 1_000_000)
  await assert.rejects(controller.setModels({ contextKey: 'oauth-glm/unknown-id', context: 300_000 }), /unknown model/)

  // 恢复默认窗口 clears every override at once and rewrites the routes.
  const all = await controller.setModels({ resetContexts: true })
  assert.equal(glmRows().find((m) => m.id === 'glm-5.3').contextWindow, 400_000)
  assert.equal(all.catalog.find((row) => row.family === 'glm').models.every((m) => m.custom === false), true)
})

test('setModels effort: 全部 sets every family, a family pick sets only it, 全部 again unifies', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const settings = createPiAiSettings()
  const { controller } = await glmController({ dir, settings, models: new ModelSwitch({ path: join(dir, 'models.json') }) })
  await controller.sync()
  const glm = () => settings.section.providers['oauth-glm']
  const effortOf = (id, level) => glm().models.find((m) => m.id === id).reasoningEfforts[level]
  let snap = await controller.setModels({ effort: 'medium' })
  assert.equal(snap.efforts.glm, 'medium')
  assert.equal(snap.efforts.kiro, 'medium')
  // glm-5-turbo is non-reasoning: the route takes no default while it is synced.
  assert.equal(glm().models.find((m) => m.id === 'glm-5-turbo').reasoningEfforts, false)
  assert.equal(glm().reasoning, undefined)
  await controller.setModels({ key: 'oauth-glm/glm-5-turbo', on: false })
  assert.equal(glm().reasoning, 'medium')
  assert.equal(effortOf('glm-5.3', 'medium'), effortOf('glm-5.3', 'low'), 'GLM has no medium: it falls back to low')

  snap = await controller.setModels({ effort: 'max', families: ['glm'] })
  assert.equal(glm().reasoning, 'max')
  assert.equal(snap.efforts.kiro, 'medium', 'a family pick leaves the others alone')
  snap = await controller.setModels({ effort: 'high' })
  assert.equal(glm().reasoning, 'high', '全部 overrides the family pick')
  assert.deepEqual(new Set(Object.values(snap.efforts)), new Set(['high']))
  snap = await controller.setModels({ effort: null })
  assert.deepEqual(snap.efforts, {})
  assert.equal(glm().reasoning, undefined)
  await assert.rejects(controller.setModels({ effort: 'turbo' }), /effort must be one of/)
})

test('setModels contextKey on a disabled row only persists; enabling writes it', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const settings = createPiAiSettings()
  const { controller } = await glmController({ dir, settings, models: new ModelSwitch({ path: join(dir, 'models.json') }) })
  await controller.sync()
  const glmRows = () => settings.section.providers['oauth-glm']?.models ?? []

  // Turn glm-5-turbo off: its row leaves the synced route.
  await controller.setModels({ key: 'oauth-glm/glm-5-turbo', on: false })
  assert.equal(glmRows().some((m) => m.id === 'glm-5-turbo'), false)

  // A dormant context edit persists to models.json but skips the route write
  // (and with it the host reconcile).
  const mutates = settings.ops.length
  const snap = await controller.setModels({ contextKey: 'oauth-glm/glm-5-turbo', context: 100_000 })
  assert.equal(settings.ops.length, mutates)
  assert.equal(snap.catalog.find((row) => row.family === 'glm').models.find((m) => m.id === 'glm-5-turbo').custom, true)
  assert.equal(glmRows().some((m) => m.id === 'glm-5-turbo'), false)

  // Enabling the row syncs the stored override into the route.
  await controller.setModels({ key: 'oauth-glm/glm-5-turbo', on: true })
  assert.equal(glmRows().find((m) => m.id === 'glm-5-turbo').contextWindow, 100_000)
})

test('controller refreshes quota', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  await saveSession('codex', {
    accessToken: 'a',
    refreshToken: 'r',
    expiresAt: Date.now() + 60 * 60_000,
    accountId: 'acct',
  }, authPath)
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    fetchFn: async (url) => {
      if (String(url).includes('rate-limit-reset-credits')) {
        return new Response(JSON.stringify({ available_count: 0 }), { status: 200 })
      }
      return new Response(JSON.stringify({
        plan_type: 'plus',
        rate_limit: {
          primary_window: { used_percent: 40, limit_window_seconds: 18_000, reset_after_seconds: 60 },
        },
      }), { status: 200 })
    },
  })
  const result = await controller.refreshQuota('codex')
  assert.equal(result.status, 'ready')
  assert.equal(result.planType, 'plus')
  assert.equal(result.planLabel, 'Plus')
  assert.equal(result.rows[0].remainingPercent, 60)
  assert.equal(result.resetCredits.availableCount, 0)
})

test('controller consumes Codex reset', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  await saveSession('codex', {
    accessToken: 'a',
    refreshToken: 'r',
    expiresAt: Date.now() + 60 * 60_000,
    accountId: 'acct',
  }, authPath)
  const posts = []
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    fetchFn: async (url, init) => {
      const href = String(url)
      if (href.endsWith('/rate-limit-reset-credits/consume')) {
        posts.push(JSON.parse(init.body))
        return new Response('{}', { status: 200 })
      }
      if (href.endsWith('/rate-limit-reset-credits')) {
        return new Response(JSON.stringify({ available_count: 1 }), { status: 200 })
      }
      return new Response(JSON.stringify({
        plan_type: 'plus',
        rate_limit: {
          primary_window: { used_percent: 8, limit_window_seconds: 18_000, reset_after_seconds: 60 },
        },
      }), { status: 200 })
    },
  })
  const result = await controller.consumeReset('codex')
  assert.equal(result.status, 'ready')
  assert.equal(result.resetCredits.availableCount, 1)
  assert.equal(result.rows[0].remainingPercent, 92)
  assert.equal(typeof posts[0].redeem_request_id, 'string')
})

test('controller rejects quota reset for a family without reset cards', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
  })
  await assert.rejects(controller.consumeReset('kiro'), /Codex, Grok and GLM/)
})

test('entering the quota page revalidates stale readings without blocking the snapshot', async (t) => {
  t.mock.timers.enable({ apis: ['Date'], now: 1_000_000 })
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  await saveSession('codex', {
    accessToken: 'a',
    refreshToken: 'r',
    expiresAt: Date.now() + 60 * 60_000,
    accountId: 'acct',
  }, authPath)
  let reads = 0
  let release
  const usageBody = (usedPercent) => JSON.stringify({
    plan_type: 'plus',
    rate_limit: {
      primary_window: { used_percent: usedPercent, limit_window_seconds: 18_000, reset_after_seconds: 60 },
    },
  })
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    fetchFn: async (url) => {
      if (String(url) === CODEX_USAGE_URL) {
        reads += 1
        // The second read is the entry revalidation: hang it so the test can
        // prove the snapshot does not wait for it.
        if (reads === 2) await new Promise((resolve) => { release = resolve })
        return new Response(usageBody(reads === 1 ? 40 : 90), { status: 200 })
      }
      if (String(url).includes('rate-limit-reset-credits')) {
        return new Response(JSON.stringify({ available_count: 0 }), { status: 200 })
      }
      throw new Error(`unexpected ${url}`)
    },
  })
  await controller.snapshot()
  assert.equal(reads, 1, 'cold build reads upstream once')
  await controller.snapshot()
  assert.equal(reads, 1, 'inside the 60s poll TTL the cache serves')
  // Age the reading past the 15s floor, then enter the page: the re-read
  // fires behind the build and the cached answer still comes back at once.
  t.mock.timers.tick(30_000)
  const entered = await controller.snapshot(false, { revalidateQuota: true })
  assert.equal(reads, 2, 'the entry re-read fired')
  assert.equal(entered.accounts.codex.accounts[0].quota.rows[0].remainingPercent, 60, 'the cached answer still serves')
  release()
  await controller.quota.inflight.get('codex\0acct')
  const poll = await controller.snapshot()
  assert.equal(poll.accounts.codex.accounts[0].quota.rows[0].remainingPercent, 10, 'the next poll picks the re-read up')
  // A reading just re-read is younger than the 15s floor: the next entry is free.
  await controller.snapshot(false, { revalidateQuota: true })
  assert.equal(reads, 2)
})

test('snapshot marks GLM catalog loggedIn for a vault account', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const { controller } = await glmController({ dir, models: new ModelSwitch() })
  const snap = await controller.snapshot()
  const glm = snap.catalog.find((row) => row.family === 'glm')
  assert.equal(snap.accounts.glm.loggedIn, true)
  assert.equal(snap.accounts.glm.activeId, 'dev@x@bigmodel')
  assert.equal(snap.accounts.glm.account, 'dev@x')
  assert.equal(glm.loggedIn, true)
  assert.equal(glm.models.length, 4)
  assert.deepEqual(glm.models.map((model) => model.id), ['glm-5.3-flashx', 'glm-5.3', 'glm-5.3-flash', 'glm-5-turbo'])
  assert.equal(glm.models.find((model) => model.id === 'glm-5.3-flash').name, 'GLM-5.3-Flash')
  // The 1M window is the row's custom-context ceiling, not an opt-in row.
  assert.equal(glm.models.find((model) => model.id === 'glm-5.3').windowMax, '1M')
  assert.equal(glm.models.find((model) => model.id === 'glm-5.3').enabled, true)
})

test('toggle glm-5.3 on writes oauth-glm when all current GLM keys were disabled', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const catalog = catalogProviders({ prefix: 'oauth', origin: 'http://127.0.0.1:8318' })
  const models = new ModelSwitch()
  await models.ready
  models.disabled = new Set([...GLM_CURRENT, ...GLM_STALE])
  const ops = []
  const { controller } = await glmController({ dir, models, ops })
  const before = await controller.snapshot()
  assert.equal(before.catalog.find((row) => row.family === 'glm').loggedIn, true)
  assert.equal(before.catalog.find((row) => row.family === 'glm').models.every((model) => model.enabled === false), true)
  const snap = await controller.setModels({ key: 'oauth-glm/glm-5.3', on: true })
  assert.equal(snap.catalog.find((row) => row.family === 'glm').models.find((model) => model.id === 'glm-5.3').enabled, true)
  const last = ops.at(-1)
  assert.equal(last.target, 'llm-pi-ai')
  const set = last.mutations.filter((row) => row.op === 'set')
  const glm = set.find((row) => row.path[1] === 'oauth-glm')
  assert.equal(glm.value.api, HARNESS_ANTHROPIC_API)
  assert.equal(glm.value.baseURL, 'http://127.0.0.1:8318/glm')
  assert.deepEqual(glm.value.compat, { forceAdaptiveThinking: true, allowEmptySignature: true })
  assert.deepEqual(glm.value.models.map((model) => model.id), ['glm-5.3'])
})

test('login/sync recovers leftover GLM 全关 and writes the current catalog route', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const models = new ModelSwitch()
  await models.ready
  models.disabled = new Set([...GLM_CURRENT, ...GLM_STALE])
  const ops = []
  const { controller } = await glmController({ dir, models, ops })
  const result = await controller.sync()
  const glm = result.routes.find((row) => row.provider === 'oauth-glm')
  assert.deepEqual(glm.models, ['glm-5.3-flashx', 'glm-5.3', 'glm-5.3-flash', 'glm-5-turbo'])
  for (const key of GLM_CURRENT) assert.equal(models.isEnabled(key), true)
  for (const key of GLM_STALE) assert.equal(models.disabled.has(key), true)
  const set = ops.at(-1).mutations.filter((row) => row.op === 'set')
  const route = set.find((row) => row.path[1] === 'oauth-glm')
  assert.equal(route.value.api, HARNESS_ANTHROPIC_API)
  assert.equal(route.value.compat.forceAdaptiveThinking, true)
  assert.deepEqual(route.value.models.map((model) => model.id), ['glm-5.3-flashx', 'glm-5.3', 'glm-5.3-flash', 'glm-5-turbo'])
})

test('setModels 全关 still unsets oauth-glm and does not recover', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const ops = []
  const { controller } = await glmController({ dir, models: new ModelSwitch(), ops })
  await controller.setModels({ family: 'glm', on: true })
  const off = await controller.setModels({ family: 'glm', on: false })
  assert.equal(off.catalog.find((row) => row.family === 'glm').models.every((model) => model.enabled === false), true)
  const empty = ops.at(-1).mutations.filter((row) => row.op === 'set')
  assert.equal(empty.some((row) => row.path[1] === 'oauth-glm'), false)
})

test('setModels 全选 persists logged-in GLM 4/4 into the settings store', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const store = createPiAiSettings()
  const { controller } = await glmController({ dir, models: new ModelSwitch(), settings: store })
  await controller.setModels({ family: 'glm', on: true })
  const set = store.ops.at(-1).mutations.filter((row) => row.op === 'set')
  const glm = set.find((row) => row.path[1] === 'oauth-glm')
  assert.equal(glm.value.api, HARNESS_ANTHROPIC_API)
  assert.deepEqual(glm.value.models.map((model) => model.id), ['glm-5.3-flashx', 'glm-5.3', 'glm-5.3-flash', 'glm-5-turbo'])
  assert.equal(store.section.providers['oauth-glm'].api, 'anthropic-messages')
  assert.deepEqual(store.section.providers['oauth-glm'].models.map((model) => model.id), ['glm-5.3-flashx', 'glm-5.3', 'glm-5.3-flash', 'glm-5-turbo'])
})

test('Antigravity 全选 clears leftover disabled keys and writes oauth-antigravity', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  await saveSession('antigravity', antigravitySession({
    accessToken: 'a', refreshToken: 'r', expiresAt: Date.now() + 60 * 60_000, account: 'dev@x', projectId: 'proj',
  }), authPath)
  const catalog = catalogProviders({ prefix: 'oauth', origin: 'http://127.0.0.1:8318' })
  const agKeys = catalogKeys(catalog).filter((key) => key.startsWith('oauth-antigravity/'))
  const models = new ModelSwitch()
  await models.ready
  models.disabled = new Set(agKeys.filter((key) => key !== 'oauth-antigravity/gemini-3.7-flash-high'))
  const store = createPiAiSettings()
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: store,
    models,
    fetchFn: async () => { throw new Error('antigravity must not hit a quota API') },
  })
  const before = await controller.snapshot()
  assert.equal(before.catalog.find((row) => row.family === 'antigravity').loggedIn, true)
  assert.equal(before.catalog.find((row) => row.family === 'antigravity').models.filter((model) => model.enabled).length, 1)
  assert.equal(store.section.providers['oauth-antigravity'], undefined)
  await controller.setModels({ family: 'antigravity', on: true })
  for (const key of agKeys) assert.equal(models.disabled.has(key), false)
  assert.equal(store.section.providers['oauth-antigravity'].api, HARNESS_COMPLETIONS_API)
  assert.equal(store.section.providers['oauth-antigravity'].models.length, agKeys.length)
})

test('Kiro login sync writes oauth-kiro; picker stays locked while logged out', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  const store = createPiAiSettings()
  const loggedOut = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: store,
  })
  const empty = await loggedOut.snapshot()
  assert.equal(empty.catalog.find((row) => row.family === 'kiro').loggedIn, false)
  await saveSession('kiro', kiroSession({
    accessToken: 'tok', refreshToken: KIRO_RT, authMethod: 'social', account: 'dev@x',
  }), authPath)
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: store,
    fetchFn: async () => new Response(JSON.stringify({
      subscriptionInfo: { subscriptionTitle: 'KIRO PRO' },
      userInfo: { email: 'dev@x' },
      usageBreakdownList: [{ currentUsageWithPrecision: 10, usageLimitWithPrecision: 100 }],
    }), { status: 200, headers: { 'content-type': 'application/json' } }),
  })
  await controller.sync()
  assert.equal(store.section.providers['oauth-kiro'].api, HARNESS_COMPLETIONS_API)
  assert.deepEqual(store.section.providers['oauth-kiro'].models.map((model) => model.id), KIRO_MODELS.map((model) => model.id))
})

test('setModels surfaces a mutate failure instead of swallowing it', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const { controller } = await glmController({
    dir,
    models: new ModelSwitch(),
    settings: {
      async mutate() {
        throw new Error('llm-pi-ai: provider "oauth-glm" api must be openai-completions | openai-responses | anthropic-messages')
      },
    },
  })
  await assert.rejects(controller.setModels({ family: 'glm', on: true }), /llm-pi-ai mutate failed/)
})

test('controller toggles models and sync uses the persisted set', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  await saveSession('codex', {
    accessToken: 'a',
    refreshToken: 'r',
    expiresAt: Date.now() + 60 * 60_000,
    accountId: 'acct',
  }, authPath)
  const ops = []
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async (target, mutations) => { ops.push({ target, mutations }) } },
    fetchFn: async (url) => {
      if (String(url).includes('rate-limit-reset-credits')) {
        return new Response(JSON.stringify({ available_count: 0 }), { status: 200 })
      }
      return new Response(JSON.stringify({ plan_type: 'plus', rate_limit: { primary_window: { used_percent: 1 } } }), { status: 200 })
    },
  })
  const off = await controller.setModels({ key: 'oauth-codex/gpt-5.5-fast', on: false })
  assert.equal(off.catalog.find((row) => row.family === 'codex').models.find((m) => m.id === 'gpt-5.5-fast').enabled, false)
  assert.equal(off.catalog.find((row) => row.family === 'codex').models.find((m) => m.id === 'gpt-5.5').enabled, true)
  const last = ops.at(-1)
  const set = last.mutations.filter((row) => row.op === 'set')
  assert.equal(set.length, 1)
  assert.equal(set[0].value.models.some((model) => model.id === 'gpt-5.5-fast'), false)
  assert.equal(set[0].value.models.some((model) => model.id === 'gpt-5.5'), true)
  const familyOff = await controller.setModels({ family: 'codex', on: false })
  assert.equal(familyOff.selected.some((key) => key.startsWith('oauth-codex/')), false)
  const empty = ops.at(-1).mutations.filter((row) => row.op === 'set')
  assert.equal(empty.length, 0)
})

test('controller lists Codex accounts and switchAccount changes the active session', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  await saveSession('codex', {
    accessToken: 'a1', refreshToken: 'r1', expiresAt: Date.now() + 60 * 60_000, emailAddress: 'one@x',
  }, authPath)
  await saveSession('codex', {
    accessToken: 'a2', refreshToken: 'r2', expiresAt: Date.now() + 60 * 60_000, emailAddress: 'two@x',
  }, authPath)
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async (url) => {
      if (String(url).includes('rate-limit-reset-credits')) {
        return new Response(JSON.stringify({ available_count: 0 }), { status: 200 })
      }
      return new Response(JSON.stringify({ plan_type: 'plus', rate_limit: { primary_window: { used_percent: 1 } } }), { status: 200 })
    },
  })
  const first = await controller.snapshot()
  assert.equal(first.accounts.codex.activeId, 'two@x')
  assert.equal(first.accounts.codex.accounts.length, 2)
  const switched = await controller.switchAccount('codex', 'one@x')
  assert.equal(switched.accounts.codex.activeId, 'one@x')
  assert.equal(switched.accounts.codex.account, 'one@x')
  await controller.logout('codex', 'one@x')
  const after = await controller.snapshot()
  assert.equal(after.accounts.codex.activeId, 'two@x')
  assert.equal(after.accounts.codex.accounts.length, 1)
})

test('snapshot shows quota on every Grok account, not only the active one', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  const later = Date.now() + 60 * 60_000
  await saveSession('grok', {
    accessToken: 'tok-a', refreshToken: 'r-a', expiresAt: later, account: 'a@x',
  }, authPath)
  await saveSession('grok', {
    accessToken: 'tok-b', refreshToken: 'r-b', expiresAt: later, account: 'b@x',
  }, authPath)
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async (_url, init) => {
      const auth = String(init?.headers?.authorization ?? '')
      const used = auth.includes('tok-b') ? 10 : 40
      return new Response(JSON.stringify({
        config: { subscription_tier: 'SuperGrok', creditUsagePercent: used },
      }), { status: 200, headers: { 'content-type': 'application/json' } })
    },
  })
  const snap = await controller.snapshot()
  const roster = snap.accounts.grok.accounts
  assert.equal(roster.length, 2)
  const first = roster.find((row) => row.id === 'a@x')
  const second = roster.find((row) => row.id === 'b@x')
  assert.equal(first.quota.status, 'ready')
  assert.equal(second.quota.status, 'ready')
  assert.equal(first.quota.rows[0].remainingPercent, 60)
  assert.equal(second.quota.rows[0].remainingPercent, 90)
  assert.equal(second.active, true)
})

async function grokPair(t, { fail = () => false, gate = async () => undefined } = {}) {
  t.mock.timers.enable({ apis: ['Date'], now: Date.now() })
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  const later = Date.now() + 60 * 60_000
  await saveSession('grok', { accessToken: 'tok-a', refreshToken: 'r-a', expiresAt: later, account: 'a@x' }, authPath)
  await saveSession('grok', { accessToken: 'tok-b', refreshToken: 'r-b', expiresAt: later, account: 'b@x' }, authPath)
  const calls = { 'tok-a': 0, 'tok-b': 0 }
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async (_url, init) => {
      const tok = String(init?.headers?.authorization ?? '').includes('tok-b') ? 'tok-b' : 'tok-a'
      calls[tok] += 1
      await gate()
      if (fail(tok)) return new Response('down', { status: 503 })
      return new Response(JSON.stringify({
        config: { subscription_tier: 'SuperGrok', creditUsagePercent: 10 },
      }), { status: 200, headers: { 'content-type': 'application/json' } })
    },
  })
  return { controller, calls }
}

test('concurrent snapshots share one build: one quota round per account, none within the TTL', async (t) => {
  const { controller, calls } = await grokPair(t)
  const [one, two] = await Promise.all([controller.snapshot(), controller.snapshot()])
  assert.equal(one, two)
  const round = calls['tok-a']
  assert.ok(round > 0)
  assert.deepEqual(calls, { 'tok-a': round, 'tok-b': round })
  for (const row of one.accounts.grok.accounts) assert.equal(row.quota.status, 'ready')

  t.mock.timers.tick(59_000)
  const again = await controller.snapshot()
  assert.notEqual(again, one) // settled build is cleared, not pinned
  assert.deepEqual(calls, { 'tok-a': round, 'tok-b': round })
})

test('a post-mutation snapshot never joins a build that started before the write', async (t) => {
  let release
  let held = Promise.resolve()
  const { controller, calls } = await grokPair(t, { gate: () => held })
  held = new Promise((resolve) => { release = resolve })
  const poll = controller.snapshot()
  // The poll's build has read the store (b@x active) and is parked on quota.
  while (calls['tok-a'] + calls['tok-b'] === 0) await new Promise((resolve) => setImmediate(resolve))
  const switched = controller.switchAccount('grok', 'a@x')
  await new Promise((resolve) => setTimeout(resolve, 20))
  release()
  held = Promise.resolve()
  const [stale, fresh] = await Promise.all([poll, switched])
  assert.notEqual(fresh, stale)
  const active = fresh.accounts.grok.accounts.find((row) => row.active)
  assert.equal(active.id, 'a@x')
})

test('refreshQuota bypasses the TTL once and joins an in-flight refresh', async (t) => {
  let release
  let held = Promise.resolve()
  const { controller, calls } = await grokPair(t, { gate: () => held })
  await controller.snapshot()
  // Grok quota is several GETs per account; count rounds, not requests.
  const round = calls['tok-a']
  held = new Promise((resolve) => { release = resolve })
  const first = controller.refreshQuota('grok', 'a@x')
  while (calls['tok-a'] === round) await new Promise((resolve) => setImmediate(resolve))
  const joined = [controller.refreshQuota('grok', 'a@x'), controller.snapshot()]
  await new Promise((resolve) => setTimeout(resolve, 50))
  release()
  held = Promise.resolve()
  await Promise.all([first, ...joined])
  assert.deepEqual(calls, { 'tok-a': 2 * round, 'tok-b': round })
})

test('a cold snapshot asks every signed-in family for its quota at once, not one family after another', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  const later = Date.now() + 60 * 60_000
  await saveSession('codex', { accessToken: 'tok-c', refreshToken: 'r-c', expiresAt: later, emailAddress: 'c@x' }, authPath)
  await saveSession('grok', { accessToken: 'tok-g', refreshToken: 'r-g', expiresAt: later, account: 'g@x' }, authPath)
  // Each family's first request parks for up to 300ms; with one family at a
  // time the first has always left before the second arrives.
  const started = new Set()
  const parked = new Set()
  let overlapped = false
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async (url) => {
      const family = String(url).includes('chatgpt.com') ? 'codex' : 'grok'
      if (!started.has(family)) {
        started.add(family)
        parked.add(family)
        overlapped = overlapped || parked.size === 2
        await new Promise((resolve) => setTimeout(resolve, 300))
        parked.delete(family)
      }
      if (String(url).includes('rate-limit-reset-credits')) return new Response(JSON.stringify({ available_count: 0 }), { status: 200 })
      return new Response(JSON.stringify({
        plan_type: 'plus',
        rate_limit: { primary_window: { used_percent: 1 } },
        config: { subscription_tier: 'SuperGrok', creditUsagePercent: 10 },
      }), { status: 200, headers: { 'content-type': 'application/json' } })
    },
  })
  const snap = await controller.snapshot()
  assert.equal(snap.accounts.codex.accounts[0].quota.status, 'ready')
  assert.equal(snap.accounts.grok.accounts[0].quota.status, 'ready')
  assert.ok(overlapped, 'the second family only started after the first had answered')
})

test('a failed quota round recovers on the next pass after the TTL', async (t) => {
  let down = true
  const { controller, calls } = await grokPair(t, { fail: () => down })
  const first = await controller.snapshot()
  for (const row of first.accounts.grok.accounts) assert.equal(row.quota.status, 'error')
  const round = calls['tok-a']
  await controller.snapshot()
  assert.equal(calls['tok-a'], round) // errors are not re-hit every poll
  down = false
  t.mock.timers.tick(60_000)
  const next = await controller.snapshot()
  for (const row of next.accounts.grok.accounts) assert.equal(row.quota.status, 'ready')
})

test('GLM identity discovery runs once per account per TTL; login changes re-arm it', async (t) => {
  t.mock.timers.enable({ apis: ['Date'], now: Date.now() })
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  await saveSession('glm', glmSession({ accessToken: 'glm-token', region: 'bigmodel' }), authPath)
  let userinfo = 0
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async (url) => {
      if (String(url).includes('getCustomerInfo')) userinfo += 1
      return new Response(JSON.stringify({ data: { level: 'pro', list: [] } }), { status: 200 })
    },
  })
  await controller.snapshot()
  await controller.snapshot()
  assert.equal(userinfo, 1)
  controller.onAuthChanged('glm')
  await controller.snapshot()
  assert.equal(userinfo, 2)
  t.mock.timers.tick(60_000)
  await controller.snapshot()
  assert.equal(userinfo, 3)
})

function githubLatest(tag) {
  return async () => new Response(JSON.stringify({
    tag_name: tag,
    name: tag,
    html_url: `https://github.com/xxww0098/dsh-plugin-oauth-subs/releases/tag/${tag}`,
    published_at: '2026-08-30T15:07:49Z',
    assets: [],
  }), { status: 200, headers: { 'content-type': 'application/json' } })
}

test('checkUpdate compare-only never installs; apply forwards the tag to installRelease', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const installs = []
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: githubLatest('v9.9.9'),
    profile: 'web',
    updateEnv: { DSH_HOME: dir },
    readFileFn: () => JSON.stringify({ version: '0.0.1' }),
    installReleaseFn: async (opts) => {
      installs.push(opts)
      return { status: 'installed', version: '9.9.9', restart: 'host' }
    },
  })
  const check = await controller.checkUpdate({ apply: false })
  assert.equal(check.status, 'update')
  assert.equal(check.version, '0.0.1')
  assert.equal(check.apply.status, 'none')
  assert.equal(installs.length, 0)
  const apply = await controller.checkUpdate({ apply: true })
  assert.equal(apply.status, 'update')
  assert.equal(apply.apply.status, 'installed')
  assert.equal(apply.apply.restart, 'host')
  assert.equal(installs[0].tag, 'v9.9.9')
  assert.equal(installs[0].profile, 'web')
})

test('checkUpdate apply reports manual instructions when no installed copy exists', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: githubLatest('v9.9.9'),
    profile: 'web',
    updateEnv: { DSH_HOME: dir },
    readFileFn: () => JSON.stringify({ version: '0.0.1' }),
    installReleaseFn: async () => ({
      status: 'manual',
      command: 'dsh plugin --profile web update dsh-plugin-oauth-subs',
    }),
  })
  const result = await controller.checkUpdate({ apply: true })
  assert.equal(result.status, 'update')
  assert.equal(result.apply.status, 'manual')
  assert.match(result.apply.command, /dsh plugin --profile web update/)
})

test('checkUpdate apply on desktop self-installs and asks for an app restart', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: githubLatest('v9.9.9'),
    profile: 'desktop',
    updateEnv: { DSH_HOME: dir },
    readFileFn: () => JSON.stringify({ version: '0.0.1' }),
    installReleaseFn: async ({ profile }) => {
      assert.equal(profile, 'desktop')
      return { status: 'installed', version: '9.9.9', restart: 'app' }
    },
  })
  const result = await controller.checkUpdate({ apply: true })
  assert.equal(result.status, 'update')
  assert.equal(result.apply.status, 'installed')
  assert.equal(result.apply.restart, 'app')
})

test('checkUpdate apply when already current reports no-op', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: githubLatest(`v${installedVersion()}`),
    profile: 'web',
    updateEnv: { DSH_HOME: dir },
  })
  const result = await controller.checkUpdate({ apply: true })
  assert.equal(result.status, 'current')
  assert.equal(result.apply.status, 'none')
})

test('checkUpdate stays update when disk is latest but this process is older', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const home = join(dir, 'dsh-home')
  const manifest = join(home, 'profiles', 'web', 'node_modules', 'dsh-plugin-oauth-subs', 'package.json')
  await mkdir(dirname(manifest), { recursive: true })
  await writeFile(manifest, `${JSON.stringify({ name: 'dsh-plugin-oauth-subs', version: '9.9.9' })}\n`)
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: githubLatest('v9.9.9'),
    profile: 'web',
    updateEnv: { DSH_HOME: home },
  })
  const snap = await controller.snapshot()
  assert.equal(snap.update.disk, '9.9.9')
  assert.equal(snap.update.version, installedVersion())
  assert.equal(snap.update.staleProcess, snap.update.running !== '9.9.9')
  const result = await controller.checkUpdate({ apply: false })
  assert.equal(result.status, 'update')
  assert.equal(result.disk, '9.9.9')
  assert.equal(result.version, installedVersion())
})

test('controller.snapshot exposes plugin update info only — no host-cli state', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
  })
  const snap = await controller.snapshot()
  assert.equal(typeof snap.update, 'object')
  assert.equal(snap.update.repoSlug, 'xxww0098/dsh-plugin-oauth-subs')
  assert.equal(snap.dshUpdate, undefined)
  assert.equal(snap.autoUpdate, false)
  assert.equal(snap.autoUpdateState, undefined)
})

test('setAutoUpdate persists the switch and snapshot exposes it', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: githubLatest(`v${installedVersion()}`),
    updateEnv: { DSH_HOME: dir },
  })
  const on = await controller.setAutoUpdate({ autoUpdate: true })
  assert.equal(on.autoUpdate, true)
  const prefs = JSON.parse(await readFile(join(dir, 'update-prefs.json'), 'utf8'))
  assert.equal(prefs.autoUpdate, true)
  const snap = await controller.snapshot()
  assert.equal(snap.autoUpdate, true)
  await controller.setAutoUpdate({ autoUpdate: false })
  const off = await controller.snapshot()
  assert.equal(off.autoUpdate, false)
})

test('runAutoUpdate installs a newer tag and records the outcome', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const installs = []
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: githubLatest('v9.9.9'),
    profile: 'desktop',
    updateEnv: { DSH_HOME: dir },
    readFileFn: () => JSON.stringify({ version: '0.0.1' }),
    installReleaseFn: async ({ tag }) => {
      installs.push(tag)
      return { status: 'installed', version: '9.9.9', restart: 'app' }
    },
  })
  const skipped = await controller.runAutoUpdate()
  assert.equal(skipped.skipped, true)
  assert.equal(installs.length, 0)
  await controller.setAutoUpdate({ autoUpdate: true })
  await controller.runAutoUpdate()
  const result = await controller.runAutoUpdate()
  assert.equal(result.apply.status, 'installed')
  assert.equal(installs.length >= 1, true)
  assert.equal(installs[0], 'v9.9.9')
  const state = JSON.parse(await readFile(join(dir, 'update-state.json'), 'utf8'))
  assert.equal(state.status, 'installed')
  assert.equal(typeof state.at, 'string')
  const snap = await controller.snapshot()
  assert.equal(snap.autoUpdateState.status, 'installed')
})

function kimiWindow(settings) {
  return settings.section.providers['oauth-kimi']?.models?.find((model) => model.id === 'kimi-for-coding')?.contextWindow
}

test('warmup, login, and quota refresh sync a same-id Kimi window change once', async () => {
  resetKimiCatalogCache()
  const dir = await mkdtemp(join(tmpdir(), 'oauth-kimi-sync-'))
  const authPath = join(dir, 'auth.json')
  await saveSession('kimi', kimiSession({ accessToken: 'sk-kimi-route-sync', source: 'paste' }), authPath)
  const state = { rows: [{ id: 'kimi-for-coding', context_length: 100_000 }] }
  let discovers = 0
  const settings = createPiAiSettings()
  let controller
  controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings,
    fetchFn: async () => new Response('{}', { status: 200, headers: { 'content-type': 'application/json' } }),
    onAuthChanged: () => controller.sync(),
    kimiDiscover: (session) => {
      discovers += 1
      return refreshKimiCatalog(session, {
        now: 1_700_000_000_000,
        ttlMs: 0,
        fetchFn: async () => ({ ok: true, json: async () => ({ data: state.rows }) }),
      })
    },
  })
  await controller.loginsReady
  await controller.warmCatalogs()
  assert.equal(settings.ops.length, 1)
  assert.equal(kimiWindow(settings), 100_000)
  const unchanged = settings.ops.length
  await controller.warmCatalogs()
  assert.equal(settings.ops.length, unchanged, 'an identical catalog does not write')

  state.rows = [{ id: 'kimi-for-coding', context_length: 200_000 }]
  await controller.warmCatalogs()
  assert.equal(settings.ops.length, unchanged + 1)
  assert.equal(kimiWindow(settings), 200_000)

  state.rows = [{ id: 'kimi-for-coding', context_length: 200_000, supports_image_in: false }]
  await controller.warmCatalogs()
  assert.equal(settings.ops.length, unchanged + 2)
  assert.deepEqual(
    settings.section.providers['oauth-kimi'].models.find((model) => model.id === 'kimi-for-coding').input,
    ['text'],
  )

  state.rows = [{
    id: 'kimi-for-coding',
    context_length: 200_000,
    supports_image_in: false,
    think_efforts: { support: true, valid_efforts: ['low'], default_effort: 'low' },
  }]
  await controller.warmCatalogs()
  assert.equal(settings.ops.length, unchanged + 3)
  assert.deepEqual(
    settings.section.providers['oauth-kimi'].models.find((model) => model.id === 'kimi-for-coding').reasoningEfforts,
    { off: 'off', minimal: 'low', low: 'low' },
  )

  const beforeLogin = settings.ops.length
  const beforeDiscover = discovers
  state.rows = [{ id: 'kimi-for-coding', context_length: 100_000 }]
  await controller.useKey('kimi', 'sk-kimi-route-sync-next')
  assert.equal(discovers, beforeDiscover + 1)
  assert.equal(settings.ops.length, beforeLogin + 1, 'login discovery writes the new window once')
  assert.equal(kimiWindow(settings), 100_000)
  const quiet = settings.ops.length
  const quietDiscover = discovers
  await controller.useKey('kimi', 'sk-kimi-route-sync-same')
  assert.equal(discovers, quietDiscover + 1)
  assert.equal(settings.ops.length, quiet, 'login with the same routing fields does not write')

  state.rows = [{ id: 'kimi-for-coding', context_length: 200_000 }]
  const beforeQuota = settings.ops.length
  await controller.refreshQuota('kimi')
  assert.equal(settings.ops.length, beforeQuota + 1)
  assert.equal(kimiWindow(settings), 200_000)
  const quotaQuiet = settings.ops.length
  await controller.refreshQuota('kimi')
  assert.equal(settings.ops.length, quotaQuiet, 'quota refresh with the same catalog does not write')
  resetKimiCatalogCache()
})

test('a Kimi window change keeps the user selection, alias, and window override', async () => {
  resetKimiCatalogCache()
  const dir = await mkdtemp(join(tmpdir(), 'oauth-kimi-keep-'))
  const authPath = join(dir, 'auth.json')
  await saveSession('kimi', kimiSession({ accessToken: 'sk-kimi-keep-selection', source: 'paste' }), authPath)
  const state = {
    rows: [
      { id: 'kimi-for-coding', context_length: 100_000 },
      { id: 'k3', context_length: 262_144 },
    ],
  }
  const settings = createPiAiSettings()
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings,
    fetchFn: async () => new Response('{}', { status: 200, headers: { 'content-type': 'application/json' } }),
    kimiDiscover: (session) => refreshKimiCatalog(session, {
      now: 1_700_000_000_000,
      ttlMs: 0,
      fetchFn: async () => ({ ok: true, json: async () => ({ data: state.rows }) }),
    }),
  })
  await controller.loginsReady
  await controller.warmCatalogs()
  const catalog = await controller.catalog()
  await controller.models.setEnabled(['oauth-kimi/kimi-for-coding'], catalog)
  await controller.models.setContext('oauth-kimi/kimi-for-coding', 32_768, catalog)
  state.rows = [
    { id: 'kimi-for-coding', context_length: 200_000 },
    { id: 'k3', context_length: 262_144 },
  ]
  const before = settings.ops.length
  await controller.warmCatalogs()
  assert.equal(settings.ops.length, before + 1)
  const models = settings.section.providers['oauth-kimi'].models
  assert.deepEqual(models.map((model) => model.id), ['kimi-for-coding'])
  assert.equal(models[0].name, 'Kimi/kimi-for-coding')
  assert.equal(models[0].contextWindow, 32_768)
  resetKimiCatalogCache()
})

test('a settings write failure does not fail Kimi discovery', async () => {
  resetKimiCatalogCache()
  const dir = await mkdtemp(join(tmpdir(), 'oauth-kimi-sync-fail-'))
  const authPath = join(dir, 'auth.json')
  await saveSession('kimi', kimiSession({ accessToken: 'sk-kimi-sync-fails', source: 'paste' }), authPath)
  const settings = createPiAiSettings()
  settings.mutate = async () => { throw new Error('disk full') }
  let controller
  controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings,
    fetchFn: async () => new Response('{}', { status: 200, headers: { 'content-type': 'application/json' } }),
    onAuthChanged: () => controller.sync(),
    kimiDiscover: (session) => refreshKimiCatalog(session, {
      now: 1_700_000_000_000,
      ttlMs: 0,
      fetchFn: async () => ({
        ok: true,
        json: async () => ({ data: [{ id: 'kimi-for-coding', context_length: 200_000 }] }),
      }),
    }),
  })
  await assert.doesNotReject(() => controller.warmCatalogs())
  await assert.doesNotReject(() => controller.useKey('kimi', 'sk-kimi-sync-fails'))
  assert.equal(kimiCatalogModels().find((model) => model.id === 'kimi-for-coding').contextWindow, 200_000)
  resetKimiCatalogCache()
})

test('the first Kimi login syncs even when the live catalog matches the floor', async () => {
  resetKimiCatalogCache()
  const dir = await mkdtemp(join(tmpdir(), 'oauth-kimi-first-'))
  const settings = createPiAiSettings()
  let changes = 0
  let controller
  controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings,
    fetchFn: async () => new Response('{}', { status: 200, headers: { 'content-type': 'application/json' } }),
    onAuthChanged: () => {
      changes += 1
      return controller.sync()
    },
    kimiDiscover: async () => kimiCatalogModels(),
  })
  await controller.useKey('kimi', 'sk-kimi-first-login')
  assert.equal(changes, 1)
  assert.equal(settings.ops.length, 1)
  await controller.useKey('kimi', 'sk-kimi-first-login-again')
  assert.equal(changes, 1, 'an already-signed-in login with the same routing fields does not sync')
  assert.equal(settings.ops.length, 1)
  resetKimiCatalogCache()
})

test('a failed Kimi account does not replace another account catalog or rewrite settings', async () => {
  resetKimiCatalogCache()
  const dir = await mkdtemp(join(tmpdir(), 'oauth-kimi-other-account-'))
  const authPath = join(dir, 'auth.json')
  const sessionA = kimiSession({ accessToken: 'sk-kimi-account-a-token', source: 'paste' })
  const sessionB = kimiSession({ accessToken: 'sk-kimi-account-b-token', source: 'paste' })
  await saveSession('kimi', sessionA, authPath)
  const settings = createPiAiSettings()
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings,
    fetchFn: async () => new Response('{}', { status: 200, headers: { 'content-type': 'application/json' } }),
    onAuthChanged: () => controller.sync(),
    kimiDiscover: (session) => refreshKimiCatalog(session, {
      now: 1_700_000_000_000,
      ttlMs: 60_000,
      fetchFn: async () => {
        if (session.accessToken === sessionB.accessToken) return { ok: false, json: async () => ({}) }
        return { ok: true, json: async () => ({ data: [{ id: 'live-only-a', context_length: 200_000 }] }) }
      },
    }),
  })
  await controller.loginsReady
  await controller.refreshQuota('kimi', accountIdOf('kimi', sessionA))
  const published = kimiCatalogModels().find((model) => model.id === 'live-only-a')
  assert.equal(published.contextWindow, 200_000)
  assert.equal(
    settings.section.providers['oauth-kimi'].models.find((model) => model.id === 'live-only-a').contextWindow,
    200_000,
  )
  const written = settings.ops.length
  await saveSession('kimi', sessionB, authPath)
  await controller.refreshQuota('kimi', accountIdOf('kimi', sessionB))
  assert.equal(settings.ops.length, written, 'B failing does not rewrite settings to the static floor')
  assert.equal(kimiCatalogModels().find((model) => model.id === 'live-only-a').contextWindow, 200_000)
  resetKimiCatalogCache()
})

test('a Kimi account with a previous success does not replace another account catalog when it later fails', async () => {
  resetKimiCatalogCache()
  const dir = await mkdtemp(join(tmpdir(), 'oauth-kimi-prior-fail-'))
  const authPath = join(dir, 'auth.json')
  const sessionA = kimiSession({ accessToken: 'sk-kimi-prior-a-token', source: 'paste' })
  const sessionB = kimiSession({ accessToken: 'sk-kimi-prior-b-token', source: 'paste' })
  await saveSession('kimi', sessionB, authPath)
  const settings = createPiAiSettings()
  let now = 1_700_000_000_000
  let failB = false
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings,
    fetchFn: async () => new Response('{}', { status: 200, headers: { 'content-type': 'application/json' } }),
    onAuthChanged: () => controller.sync(),
    kimiDiscover: (session) => refreshKimiCatalog(session, {
      now,
      ttlMs: 60_000,
      fetchFn: async () => {
        if (session.accessToken === sessionB.accessToken) {
          if (failB) return { ok: false, json: async () => ({}) }
          return { ok: true, json: async () => ({ data: [{ id: 'live-only-b', context_length: 100_000 }] }) }
        }
        return { ok: true, json: async () => ({ data: [{ id: 'live-only-a', context_length: 200_000 }] }) }
      },
    }),
  })
  await controller.loginsReady
  await controller.refreshQuota('kimi', accountIdOf('kimi', sessionB))
  assert.equal(kimiCatalogModels().find((model) => model.id === 'live-only-b').contextWindow, 100_000)
  await saveSession('kimi', sessionA, authPath)
  await controller.refreshQuota('kimi', accountIdOf('kimi', sessionA))
  assert.equal(kimiCatalogModels().find((model) => model.id === 'live-only-a').contextWindow, 200_000)
  assert.equal(kimiCatalogModels().some((model) => model.id === 'live-only-b'), false)
  const written = settings.ops.length
  assert.ok(written >= 1)
  now += 60_000
  failB = true
  await controller.refreshQuota('kimi', accountIdOf('kimi', sessionB))
  assert.equal(settings.ops.length, written, 'B failing with its own previous success does not rewrite settings')
  assert.equal(kimiCatalogModels().find((model) => model.id === 'live-only-a').contextWindow, 200_000)
  assert.equal(kimiCatalogModels().some((model) => model.id === 'live-only-b'), false)
  assert.equal(
    settings.section.providers['oauth-kimi'].models.find((model) => model.id === 'live-only-a').contextWindow,
    200_000,
  )
  resetKimiCatalogCache()
})

test('a failed Kiro re-ask keeps the published catalog and does not rewrite settings', async () => {
  resetKiroCatalogCache()
  const dir = await mkdtemp(join(tmpdir(), 'oauth-kiro-reask-'))
  const authPath = join(dir, 'auth.json')
  const sessionA = kiroSession({
    accessToken: 'kiro-live-a',
    refreshToken: `a${'r'.repeat(120)}`,
    authMethod: 'social',
    account: 'a@kiro.test',
  })
  const sessionB = kiroSession({
    accessToken: 'kiro-live-b',
    refreshToken: `b${'r'.repeat(120)}`,
    authMethod: 'social',
    account: 'b@kiro.test',
  })
  await saveSession('kiro', sessionA, authPath)
  const settings = createPiAiSettings()
  let failB = true
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings,
    fetchFn: async () => new Response('{}', { status: 200, headers: { 'content-type': 'application/json' } }),
    onAuthChanged: () => controller.sync(),
    kiroDiscover: (session) => refreshKiroCatalog(session, {
      now: 1_700_000_000_000,
      ttlMs: 60_000,
      fetchLive: async () => {
        if (session.accessToken === sessionB.accessToken) {
          if (failB) return []
          return [{ modelId: 'live-only-b', modelName: 'Live Only B' }]
        }
        return [{ modelId: 'live-only-a', modelName: 'Live Only A' }]
      },
    }),
  })
  await controller.loginsReady
  await controller.refreshQuota('kiro', accountIdOf('kiro', sessionA))
  assert.equal(kiroCatalogModels().some((model) => model.id === 'live-only-a'), true)
  assert.equal(kiroCatalogModels().some((model) => model.id === KIRO_MODELS[0].id), false)
  assert.equal(
    settings.section.providers['oauth-kiro'].models.some((model) => model.id === 'live-only-a'),
    true,
  )
  const written = settings.ops.length
  await saveSession('kiro', sessionB, authPath)
  await controller.refreshQuota('kiro', accountIdOf('kiro', sessionB))
  assert.equal(settings.ops.length, written, 'a failed Kiro re-ask does not write the static floor')
  assert.equal(kiroCatalogModels().some((model) => model.id === 'live-only-a'), true)
  assert.equal(kiroCatalogModels().some((model) => model.id === KIRO_MODELS[0].id), false)
  failB = false
  await controller.refreshQuota('kiro', accountIdOf('kiro', sessionB))
  assert.equal(settings.ops.length, written + 1)
  assert.equal(kiroCatalogModels().some((model) => model.id === 'live-only-b'), true)
  assert.equal(kiroCatalogModels().some((model) => model.id === 'live-only-a'), false)
  resetKiroCatalogCache()
})

test('Devin login and import sync only when the routing signature changes', async () => {
  resetDevinCatalog()
  const dir = await mkdtemp(join(tmpdir(), 'oauth-devin-signature-'))
  const authPath = join(dir, 'auth.json')
  await saveSession('devin', devinSession({ accessToken: 'devin-session-token$already', source: 'paste' }), authPath)
  const floor = devinCatalogModels()[0]
  let window = 100_000
  const settings = createPiAiSettings()
  let controller
  controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings,
    fetchFn: async (url) => {
      if (String(url).includes('/auth/cli/token')) {
        return new Response(JSON.stringify({ token: 'devin-session-token$pkce-sync' }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        })
      }
      return new Response('{}', { status: 200, headers: { 'content-type': 'application/json' } })
    },
    onAuthChanged: () => controller.sync(),
    devinAutoImport: false,
    devinDiscover: async () => {
      setDevinCatalogModels([{ ...floor, contextWindow: window }])
      return devinCatalogModels()
    },
  })
  await controller.loginsReady
  const login = async () => {
    const claim = controller.claim('devin')
    await controller.completePkce('devin', {
      waitCode: async () => 'devin-code',
      pkce: { verifier: 'devin-verifier' },
    }, claim)
  }
  await login()
  assert.equal(settings.ops.length, 1)
  assert.equal(settings.section.providers['oauth-devin'].models.find((model) => model.id === floor.id).contextWindow, 100_000)
  const same = settings.ops.length
  await login()
  assert.equal(settings.ops.length, same, 'a second Devin login with the same routing fields does not write')
  window = 200_000
  await login()
  assert.equal(settings.ops.length, same + 1)
  assert.equal(settings.section.providers['oauth-devin'].models.find((model) => model.id === floor.id).contextWindow, 200_000)

  const file = join(dir, 'credentials.toml')
  await writeFile(file, 'windsurf_api_key = "devin-session-token$import-sync"\n')
  await chmod(file, 0o600)
  controller.devinImport = { paths: [file] }
  const beforeImport = settings.ops.length
  await controller.importFrom('devin')
  assert.equal(settings.ops.length, beforeImport, 'an import with the same routing fields does not write')
  window = 300_000
  await controller.importFrom('devin')
  assert.equal(settings.ops.length, beforeImport + 1)
  assert.equal(settings.section.providers['oauth-devin'].models.find((model) => model.id === floor.id).contextWindow, 300_000)
  assert.equal((await listStoredSessions('devin', authPath)).length > 0, true)
  resetDevinCatalog()
})

test('Command Code login syncs a window change once and skips an unchanged catalog', async () => {
  resetCommandCodeCatalogCache()
  const dir = await mkdtemp(join(tmpdir(), 'oauth-command-code-signature-'))
  const authPath = join(dir, 'auth.json')
  await saveSession('command-code', commandCodeSession({ accessToken: 'cc-key-already-signed-in', source: 'paste' }), authPath)
  const id = commandCodeCatalogModels()[0].id
  let window = commandCodeCatalogModels()[0].contextWindow + 1_000
  const settings = createPiAiSettings()
  let controller
  controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings,
    fetchFn: async () => new Response('{}', { status: 200, headers: { 'content-type': 'application/json' } }),
    onAuthChanged: () => controller.sync(),
    commandCodeAutoImport: false,
    commandCodeDiscover: (session) => refreshCommandCodeCatalog(session, {
      now: 1_700_000_000_000,
      ttlMs: 0,
      fetchFn: async () => ({
        ok: true,
        json: async () => ({ data: [{ id, name: 'Live', context_length: window }] }),
      }),
    }),
  })
  await controller.loginsReady
  await controller.useKey('command-code', 'cc-key-login-window')
  assert.equal(settings.ops.length, 1)
  assert.equal(settings.section.providers['oauth-command-code'].models.find((model) => model.id === id).contextWindow, window)
  const same = settings.ops.length
  await controller.useKey('command-code', 'cc-key-login-same')
  assert.equal(settings.ops.length, same, 'a second Command Code login with the same routing fields does not write')
  window += 1_000
  await controller.useKey('command-code', 'cc-key-login-next')
  assert.equal(settings.ops.length, same + 1)
  assert.equal(settings.section.providers['oauth-command-code'].models.find((model) => model.id === id).contextWindow, window)
  resetCommandCodeCatalogCache()
})

