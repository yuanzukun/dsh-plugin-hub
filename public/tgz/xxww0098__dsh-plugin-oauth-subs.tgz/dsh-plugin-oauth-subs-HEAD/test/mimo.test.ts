// Xiaomi MiMo family tests: login parsing, session round-trip, catalog,
// cache isolation, proxy routing (incl. the Token-Plan reroute), quota snapshot.
//
import assert from 'node:assert/strict'
import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { isPermanentRefreshFailure } from '../lib/oauth/tokens.js'
import { AuthController } from '../lib/oauth/controller.js'
import { accountIdOf, listStoredSessions, publicSession, saveSession } from '../lib/oauth/store.js'
import { createFlowAttempts } from '../lib/oauth/flow.js'
import {
  HARNESS_COMPLETIONS_API,
  assertDshServiceableProvider,
  buildProviders,
  familyOfProvider,
} from '../lib/oauth/models.js'
import {
  MIMO_ACCOUNT_ORIGIN,
  MIMO_APP_VERSION,
  MIMO_DEFAULT_REGION,
  MIMO_HOSTS,
  MIMO_MODELS,
  MIMO_PREEMPT_MS,
  MIMO_RENEW_AFTER_MS,
  MIMO_SOURCE,
  MIMO_USER_AGENT,
  mimoChatUrl,
  mimoServerTime,
  mimoSession,
  mimoSignInPage,
  mimoSignInWith,
  mimoSignOn,
  parseMimoStored,
  refreshMimo,
  waitMimoPoll,
} from '../lib/oauth/mimo/index.js'
import { applyMimoCache, isMimoFallback, mimoCacheHeaders, mimoCacheSessionId, MIMO_STABLE_SESSION, resetMimoPins } from '../lib/oauth/mimo/cache.js'
import { applyMimoStreamUsage, applyMimoThinking, mimoMembershipRequired, mimoTpModelOf } from '../lib/oauth/mimo/request.js'
import { clearMimoOnPlan, mimoPrefersPlan, resetMimoPlatformState } from '../lib/oauth/mimo/platform.js'
import { fetchMimoQuota, parseMimoSubscription, parseMimoUsage } from '../lib/oauth/mimo/quota.js'
import { forwardMimo, mimoTpRestOf } from '../lib/oauth/mimo/transport.js'
import { loginMimo } from '../lib/oauth/mimo/accounts.js'
import { UpstreamFailure } from '../lib/oauth/upstream.js'
import { createProxy } from '../lib/oauth/proxy.js'

const SGP = MIMO_HOSTS.SGP
const RU = MIMO_HOSTS.RU

function json(body, status = 200, headers = {}) {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json', ...headers } })
}

// ---- the sign-in, as the upstream tests serve it ---------------------------

const guarded = (body) => new Response(`&&&START&&&${JSON.stringify(body)}`, { headers: { 'content-type': 'text/plain' } })

function redirect(location, headers = {}) {
  return new Response('', { status: 302, headers: { location, ...headers } })
}

/**
 * The whole Xiaomi → MiMo sign-in: the account server's ticket pages, plus the
 * MiMo server's `/user/xiaomi/me` redirect dance (ending signed on). The two
 * `/user/xiaomi/me` calls are told apart by the serviceToken cookie only the
 * `/sts` hop leaves.
 */
function serveSignIn({ me = { code: 0, data: { userId: '42', region: '' } }, setCookie = 'serviceToken=st-1; Path=/' } = {}, base = SGP) {
  return async (url, init = {}) => {
    const text = String(url)
    const cookie = new Headers(init.headers).get('Cookie') ?? ''
    if (text.startsWith(`${MIMO_ACCOUNT_ORIGIN}/longPolling/loginUrl`)) {
      return guarded({ code: 0, loginUrl: `${MIMO_ACCOUNT_ORIGIN}/longPolling/authorize`, lp: `${MIMO_ACCOUNT_ORIGIN}/longPolling/poll`, timeout: 600 })
    }
    if (text.startsWith(`${MIMO_ACCOUNT_ORIGIN}/longPolling/poll`)) {
      return guarded({ code: 0, userId: 42, cUserId: 'cu-1', passToken: 'pt-1' })
    }
    if (text.startsWith(`${MIMO_ACCOUNT_ORIGIN}/pass/serviceLogin`)) {
      // back to whichever server asked (the callback query names its /sts)
      return redirect(new URL(text).searchParams.get('callback') || `${base}/sts`)
    }
    if (text === `${base}/user/xiaomi/me`) {
      if (cookie.includes('serviceToken=')) return json(me)
      return redirect(`${MIMO_ACCOUNT_ORIGIN}/pass/serviceLogin?sid=mimosgp&callback=${encodeURIComponent(`${base}/sts`)}`)
    }
    if (text === `${base}/sts`) {
      return redirect(`${base}/user/xiaomi/me`, { 'set-cookie': setCookie })
    }
    return json({}, 404)
  }
}

test('login parses the Xiaomi ticket and signs the account on at the MiMo server', async () => {
  const seen: any[] = []
  const fetchFn = async (url, init = {}) => {
    seen.push({ url: String(url), cookie: new Headers(init.headers).get('Cookie') ?? '' })
    return serveSignIn()(String(url), init)
  }
  const page = await mimoSignInPage({ device: 'pc_dev', fetchFn })
  assert.equal(page.url, 'https://account.xiaomi.com/longPolling/authorize')
  assert.equal(page.lp, `${MIMO_ACCOUNT_ORIGIN}/longPolling/poll`)
  // the ticket read carries the device cookie and the account SDK's UA
  const ticket = seen.find((row) => row.url.startsWith(`${MIMO_ACCOUNT_ORIGIN}/longPolling/loginUrl`))
  assert.match(ticket.url, /sid=mimosgp/)
  assert.match(ticket.url, /_locale=en_US/)
  assert.equal(ticket.cookie, 'deviceId=pc_dev; pass_ua=pc; uLocale=zh_CN')
  const poll = await waitMimoPoll(page, fetchFn)
  assert.equal(poll.passToken, 'pt-1')

  const { creds, cookies } = await mimoSignInWith(poll, 'pc_dev', fetchFn)
  assert.equal(cookies.serviceToken, 'st-1')
  assert.equal(creds.userId, '42')
  assert.equal(creds.passToken, 'pt-1')
  assert.equal(creds.region, MIMO_DEFAULT_REGION)
  assert.equal(creds.base, SGP)
  // the passToken rode the account server's cookies into the sign-on
  const hop = seen.find((row) => row.url.startsWith(`${MIMO_ACCOUNT_ORIGIN}/pass/serviceLogin`))
  assert.match(hop.cookie, /passToken=pt-1/)
  assert.match(hop.cookie, /userId=42/)
})

test('an account of another region is served by that region\'s server', async () => {
  const fetchFn = async (url, init = {}) => {
    const text = String(url)
    if (text.startsWith(RU)) {
      return serveSignIn({ me: { code: 0, data: { userId: '42', region: 'RU' } }, setCookie: 'serviceToken=st-ru; Path=/' }, RU)(text, init)
    }
    return serveSignIn({ me: { code: 0, data: { userId: '42', region: 'RU' } }, setCookie: 'serviceToken=st-sgp; Path=/' })(text, init)
  }
  const { creds, cookies } = await mimoSignInWith({ userId: 42, passToken: 'pt-1', cUserId: '' }, 'pc_dev', fetchFn)
  assert.equal(creds.region, 'RU')
  assert.equal(creds.base, RU)
  assert.equal(cookies.serviceToken, 'st-ru')
})

test('a poll that never lands expires at the ticket deadline', async () => {
  const fetchFn = async () => new Response(`&&&START&&&${JSON.stringify({ code: 0 })}`, { headers: { 'content-type': 'text/plain' } })
  await assert.rejects(
    waitMimoPoll({ lp: `${MIMO_ACCOUNT_ORIGIN}/longPolling/poll`, device: 'pc_dev', until: Date.now() - 1 }, fetchFn),
    /expired before the sign-in finished/,
  )
})

test('the sign-on dance carries one shared signal on every hop; a caller\'s rides along (index.mjs:121)', async () => {
  const creds = { userId: '42', passToken: 'pt-1', cUserId: 'cu-1', deviceId: 'pc_dev', region: 'SGP', base: SGP }
  const signals: any[] = []
  const fetchFn = async (url, init = {}) => {
    signals.push(init.signal)
    return serveSignIn()(String(url), init)
  }
  const signed = await mimoSignOn(creds, SGP, fetchFn)
  assert.equal(signed.cookies.serviceToken, 'st-1')
  // one deadline for the whole dance (30 s, index.mjs:121), not one per hop
  assert.ok(signals.length >= 2)
  for (const signal of signals) {
    assert.ok(signal instanceof AbortSignal)
    assert.equal(signal, signals[0])
  }
  // a caller's own signal is merged in: aborted in, aborted on the wire
  const controller = new AbortController()
  controller.abort()
  const merged: any[] = []
  const abortable = async (url, init = {}) => {
    merged.push(init.signal)
    return serveSignIn()(String(url), init)
  }
  await mimoSignOn(creds, SGP, abortable, { signal: controller.signal })
  assert.ok(merged.length >= 1 && merged[0].aborted)
})

// ---- the session -----------------------------------------------------------

test('session round-trip: cookies as access, the Xiaomi account as refresh, nothing leaks', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'mimo-store-'))
  const authPath = join(dir, 'auth.json')
  const session = mimoSession({
    creds: { userId: '42', cUserId: 'cu-1', passToken: 'pt-1', deviceId: 'pc_dev', region: 'SGP', base: SGP },
    cookies: { serviceToken: 'st-1', userId: '42', cUserId: 'cu-1' },
    issuedAt: Date.now(),
  })
  assert.equal(session.account, '42')
  assert.ok(session.expiresAt > Date.now() + MIMO_RENEW_AFTER_MS - 5_000)
  await saveSession('mimo', session, authPath)
  const rows = await listStoredSessions('mimo', authPath)
  assert.equal(rows.length, 1)
  assert.equal(rows[0].id, '42')
  assert.equal(accountIdOf('mimo', session), '42')

  const pub = publicSession('mimo', session)
  assert.equal(pub.account, '42')
  for (const secret of ['serviceToken', 'passToken', 'pt-1', 'st-1', 'refreshToken', 'accessToken']) {
    assert.equal(JSON.stringify(pub).includes(secret), false, `public session must not carry ${secret}`)
  }

  const parsed = parseMimoStored(session)
  assert.equal(parsed.creds.passToken, 'pt-1')
  assert.equal(parsed.cookies.serviceToken, 'st-1')
  // a row that is not a Xiaomi-account sign-in reads as null
  assert.equal(parseMimoStored({ accessToken: 'x', refreshToken: 'not json', expiresAt: 1 }), null)
  assert.equal(parseMimoStored({ accessToken: 'x', refreshToken: JSON.stringify({ userId: '42' }), expiresAt: 1 }), null)
})

test('refresh signs on again with the same passToken; a dead passToken is permanent', async () => {
  const session = mimoSession({
    creds: { userId: '42', passToken: 'pt-1', deviceId: 'pc_dev', region: 'SGP', base: SGP },
    cookies: { serviceToken: 'st-old' },
    issuedAt: Date.now() - 3_600_000,
  })
  const next = await refreshMimo(session, async (url, init) => serveSignIn({ setCookie: 'serviceToken=st-new; Path=/' })(String(url), init))
  assert.equal(JSON.parse(next.accessToken).serviceToken, 'st-new')
  // the Xiaomi account is exactly what it was
  assert.deepEqual(JSON.parse(next.refreshToken), JSON.parse(session.refreshToken))
  assert.ok(next.expiresAt > session.expiresAt)

  const lapsed = await refreshMimo(session, async () => new Response('<html>sign in</html>')).catch((error) => error)
  assert.equal(isPermanentRefreshFailure(lapsed), true)
  assert.match(lapsed.message, /sign in again/)
})

// ---- the catalog -----------------------------------------------------------

test('catalog rows are the upstream pinned table: two models, no invented efforts', () => {
  assert.deepEqual(MIMO_MODELS.map((row) => row.id), ['mimo-pro', 'mimo-flash'])
  for (const row of MIMO_MODELS) {
    assert.equal(row.contextWindow, 1_000_000)
    assert.equal(row.maxTokens, 128_000)
    assert.deepEqual(row.input, ['text', 'image'])
    assert.equal(row.reasoningEfforts, false)
  }
})

test('the harness route is Completions, family-scoped, named Subs · Xiaomi MiMo · Chat', () => {
  const providers = buildProviders({
    prefix: 'oauth',
    origin: 'http://127.0.0.1:8318',
    loggedIn: { mimo: true },
  })
  const route = providers['oauth-mimo']
  assert.ok(route, 'the mimo route is built when logged in')
  assert.equal(route.api, HARNESS_COMPLETIONS_API)
  assert.equal(route.displayName, 'Subs · Xiaomi MiMo · Chat')
  assert.equal(route.baseURL, 'http://127.0.0.1:8318/mimo')
  assert.equal(familyOfProvider('oauth-mimo'), 'mimo')
  // the request budget clamps the vendor cap; the catalog row keeps it
  assert.equal(route.models.length, 2)
  for (const model of route.models) {
    assert.equal(model.maxTokens, 32_768)
    assert.equal(model.reasoningEfforts, false)
  }
  assert.doesNotThrow(() => assertDshServiceableProvider('oauth-mimo', route))
})

// ---- the cache -------------------------------------------------------------

test('cache isolation: foreign ids stripped, system parked, no sticky headers', () => {
  assert.equal(mimoCacheSessionId('session 772f7f3a/foo'), 'session-772f7f3a-foo')
  const dirty = { model: 'mimo-pro', session_id: 'dsh-42', prompt_cache_key: 'codex-style', prompt_cache_retention: '24h', prompt_cache_options: {}, messages: [{ role: 'system', content: 'you are dsh' }, { role: 'user', content: 'hi' }] }
  const { payload, cacheSessionId } = applyMimoCache(dirty)
  assert.equal(cacheSessionId, 'dsh-42')
  assert.equal(payload.session_id, undefined)
  assert.equal(payload.prompt_cache_key, undefined)
  assert.equal(payload.prompt_cache_retention, undefined)
  assert.equal(payload.prompt_cache_options, undefined)
  // no fallback id ever pins a system prompt
  assert.equal(isMimoFallback(MIMO_STABLE_SESSION), true)
  assert.equal(isMimoFallback(undefined), true)
  resetMimoPins()
  // a grown system prefix is parked at the suffix, keyed on the same id
  const first = applyMimoCache({ ...dirty, messages: [{ role: 'system', content: 'base' }, { role: 'user', content: 'one' }] })
  const grown = applyMimoCache({ ...dirty, messages: [{ role: 'system', content: 'base' }, { role: 'system', content: 'extra' }, { role: 'user', content: 'two' }] })
  assert.deepEqual(grown.payload.messages, [
    { role: 'system', content: 'base' },
    { role: 'user', content: 'two' },
    { role: 'system', content: 'extra' },
  ])
  assert.equal(first.payload.messages.length, 2)
  resetMimoPins()
  // MiMo sticky-routes on nothing: no header, and none of the other families'
  assert.deepEqual(mimoCacheHeaders(), {})
  assert.notEqual(mimoCacheSessionId('x'), undefined)
})

// ---- the hop ---------------------------------------------------------------

const accountSession = mimoSession({
  creds: { userId: '42', passToken: 'pt-1', deviceId: 'pc_dev', region: 'SGP', base: SGP },
  cookies: { serviceToken: 'st-1', userId: '42', cUserId: 'cu-1' },
  issuedAt: Date.now(),
})

/** A minimal tokens map: no refreshNow, so a 401 refresh hook declines and the answer forwards. */
const tokens = { mimo: { session: async () => accountSession, sourceOf: () => undefined, refreshNow: undefined } }

async function hop(fetchFn, body: any = { model: 'mimo-pro', messages: [{ role: 'user', content: 'hi' }] }) {
  // The registry's applyCache row, composed exactly as families.ts wires it —
  // the proxy's rewriteUpstreamBody is that lookup.
  const { payload: cached } = applyMimoCache(body)
  const rewritten = applyMimoStreamUsage(applyMimoThinking(cached))
  const response = {
    headersSent: false,
    written: [],
    status: undefined,
    headers: undefined,
    write(chunk) { this.written.push(chunk); return true },
    end() { this.ended = true },
    writableEnded: false,
    destroyed: false,
    writeHead(status, headers) { this.headersSent = true; this.status = status; this.headers = headers },
  }
  await forwardMimo(response, {
    payload: rewritten,
    stream: rewritten.stream === true,
    session: accountSession,
    tokens,
    fetchFn,
    startedAt: Date.now(),
  })
  return { response, text: response.written.map((chunk) => Buffer.from(chunk).toString('utf8')).join('') }
}

test('the hop posts to the app /route with cookies only, foreign fields stripped', async () => {
  const asked: any[] = []
  const fetchFn = async (url, init = {}) => {
    asked.push({ url: String(url), headers: new Headers(init.headers), body: JSON.parse(String(init.body)) })
    return json({ id: 'chat', choices: [{ message: { role: 'assistant', content: 'ok' } }], usage: { prompt_tokens: 5, completion_tokens: 3 } })
  }
  const { response, text } = await hop(fetchFn, {
    model: 'mimo-pro',
    messages: [{ role: 'user', content: 'hi' }],
    prompt_cache_key: 'codex-style',
    reasoning_effort: 'high',
  })
  assert.equal(response.status, 200)
  assert.match(text, /"ok"/)
  assert.equal(asked.length, 1)
  assert.equal(asked[0].url, `${SGP}/route/chat/completions`)
  assert.equal(asked[0].headers.get('Cookie'), 'serviceToken=st-1; userId=42; cUserId=cu-1')
  assert.equal(asked[0].headers.get('X-Mimo-Source'), MIMO_SOURCE)
  assert.equal(asked[0].headers.get('X-Client-Version'), MIMO_APP_VERSION)
  assert.equal(asked[0].headers.get('User-Agent'), MIMO_USER_AGENT)
  assert.equal(asked[0].headers.get('Authorization'), null)
  assert.equal(asked[0].body.prompt_cache_key, undefined)
  assert.equal(asked[0].body.reasoning_effort, undefined)
  // a stream asks for its usage frame; a non-stream body adds nothing
  assert.equal(asked[0].body.stream_options, undefined)
})

test('stream bodies ask for include_usage, thinking fields are dropped', () => {
  const body = applyMimoStreamUsage(applyMimoThinking({ model: 'mimo-pro', stream: true, reasoning_effort: 'high', thinking: { type: 'enabled' }, messages: [] }))
  assert.deepEqual(body.stream_options, { include_usage: true })
  assert.equal(body.reasoning_effort, undefined)
  assert.equal(body.thinking, undefined)
  const plain = applyMimoStreamUsage(applyMimoThinking({ model: 'mimo-pro', messages: [] }))
  assert.equal(plain.stream_options, undefined)
})

// the open platform, as the upstream tests serve it (usage.test.mjs:117-144)
const LOGIN_URL = `${MIMO_ACCOUNT_ORIGIN}/pass/serviceLogin?callback=${encodeURIComponent('https://platform.xiaomimimo.com/sts?sign=x&followup=' + encodeURIComponent('http://platform.xiaomimimo.com/api/v1/tokenPlan/detail'))}&sid=api-platform&_group=DEFAULT`
const TP_DETAIL = { code: 0, message: '', data: { planCode: 'lite', planName: 'Lite', currentPeriodEnd: '2026-11-06 23:59:59', expired: false, enableAutoRenew: true, hasAutoRenewSubscribed: true } }
const TP_USAGE = { code: 0, message: '', data: { monthUsage: { items: [{ name: 'month_total_token', used: 6809408, limit: 4100000000 }] }, usage: { items: [{ name: 'plan_total_token', used: 6809408, limit: 4100000000 }] } } }

function servePlatform(keyRef = { value: 'tp-one' }) {
  const state = { signOns: 0 }
  const serve = async (url, headers) => {
    const text = String(url)
    if (text.startsWith(`${MIMO_ACCOUNT_ORIGIN}/`)) {
      state.signOns += 1
      assert.equal(new URL(text).searchParams.get('sid'), 'api-platform')
      return new Response('', { status: 302, headers: { location: `https://platform.xiaomimimo.com/sts?sign=x&followup=${encodeURIComponent('http://platform.xiaomimimo.com/api/v1/tokenPlan/detail')}` } })
    }
    if (new URL(text).pathname === '/sts') {
      const response = new Response('', { status: 307, headers: { location: 'http://platform.xiaomimimo.com/api/v1/tokenPlan/detail' } })
      response.headers.append('set-cookie', 'api-platform_serviceToken=pst; Path=/; HttpOnly')
      response.headers.append('set-cookie', 'userId=42; Domain=xiaomimimo.com; Path=/')
      return response
    }
    if (text.endsWith('/tokenPlan/detail')) {
      if (!(headers.get('Cookie') ?? '').includes('api-platform_serviceToken=pst')) return json({ code: 401, loginUrl: LOGIN_URL }, 401)
      return json(TP_DETAIL)
    }
    if (text.endsWith('/tokenPlan/usage')) return json(TP_USAGE)
    if (text.endsWith('/tokenPlan/apiKey')) return json({ code: 0, data: { openaiBaseUrl: 'https://token-plan-cn.xiaomimimo.com/v1' } })
    if (text.endsWith('/tokenPlan/apiKey/raw')) return json({ code: 0, data: keyRef.value })
    return json({ code: 404 }, 404)
  }
  return { state, serve }
}

const REFUSED = { error: { message: '未开通会员或会员已到期，请订阅后使用', type: 'permission_error', code: 'membership_required', biz_code: 30012 } }

test('membership_required reroutes to the Token Plan with its key and model names, then goes straight there', async () => {
  resetMimoPlatformState()
  const platform = servePlatform()
  const asked: any[] = []
  const fetchFn = async (url, init = {}) => {
    const text = String(url)
    const headers = new Headers(init.headers)
    if (text.includes('xiaomimimo.com') && (text.includes('platform.xiaomimimo.com') || text.startsWith(MIMO_ACCOUNT_ORIGIN))) {
      return platform.serve(text, headers)
    }
    asked.push({ url: text, auth: headers.get('Authorization'), cookie: headers.get('Cookie'), model: JSON.parse(String(init.body)).model })
    if (text.startsWith('https://token-plan-cn.xiaomimimo.com/')) return json({ choices: [] })
    return json(REFUSED, 403)
  }
  const first = await hop(fetchFn)
  assert.equal(first.response.status, 200)
  assert.deepEqual(asked.map((row) => `${row.url} ${row.auth ?? '-'} ${row.model}`), [
    `${SGP}/route/chat/completions - mimo-pro`,
    'https://token-plan-cn.xiaomimimo.com/v1/chat/completions Bearer tp-one mimo-v2.6-pro',
  ])
  // the plan request carries no cookies and no app marks
  assert.equal(asked[1].cookie, null)
  assert.equal(mimoPrefersPlan('42'), true)
  // from then on straight to the plan; the key is not read again
  asked.length = 0
  const second = await hop(fetchFn, { model: 'mimo-flash', messages: [] })
  assert.equal(second.response.status, 200)
  assert.deepEqual(asked.map((row) => `${row.url} ${row.model}`), ['https://token-plan-cn.xiaomimimo.com/v1/chat/completions mimo-v2.6-flash'])
  assert.equal(platform.state.signOns, 1)
  assert.equal(mimoTpRestOf(`${SGP}/route/chat/completions`), '/chat/completions')
  resetMimoPlatformState()
})

test('a key reset at the platform is read again after the plan turns the old one away', async () => {
  resetMimoPlatformState()
  const keyRef = { value: 'tp-one' }
  const platform = servePlatform(keyRef)
  const asked: any[] = []
  const fetchFn = async (url, init = {}) => {
    const text = String(url)
    const headers = new Headers(init.headers)
    if (text.startsWith('https://platform.xiaomimimo.com/') || text.startsWith(MIMO_ACCOUNT_ORIGIN)) {
      return platform.serve(text, headers)
    }
    if (text.startsWith('https://token-plan-cn.xiaomimimo.com/')) {
      asked.push(headers.get('Authorization'))
      return headers.get('Authorization') === `Bearer ${keyRef.value}` ? json({ choices: [] }) : json({ error: { message: 'Invalid API Key' } }, 401)
    }
    return json(REFUSED, 403)
  }
  assert.equal((await hop(fetchFn)).response.status, 200)
  keyRef.value = 'tp-two'
  // onPlan is armed by the first hop: the plan is asked directly, its 401 answered as it is
  assert.equal((await hop(fetchFn)).response.status, 401)
  assert.equal((await hop(fetchFn)).response.status, 200)
  assert.deepEqual(asked, ['Bearer tp-one', 'Bearer tp-one', 'Bearer tp-two'])
  resetMimoPlatformState()
})

test('membership_required with no Token Plan behind it answers as a 400 explanation, not a 403', async () => {
  resetMimoPlatformState()
  clearMimoOnPlan('42')
  // a live plan whose key was never made (the platform's page creates one;
  // this plugin never does)
  const platform = servePlatform({ value: null })
  const fetchFn = async (url, init = {}) => {
    const text = String(url)
    if (text.startsWith('https://platform.xiaomimimo.com/') || text.startsWith(MIMO_ACCOUNT_ORIGIN)) {
      return platform.serve(text, new Headers(init.headers))
    }
    return json(REFUSED, 403)
  }
  const failure = await hop(fetchFn).catch((error) => error)
  assert.ok(failure instanceof UpstreamFailure)
  assert.equal(failure.status, 400)
  assert.equal(failure.payload.error.code, 'membership_required')
  assert.match(failure.payload.error.message, /未开通会员/)
  assert.equal(mimoMembershipRequired(403, REFUSED), '未开通会员或会员已到期，请订阅后使用')
  assert.equal(mimoMembershipRequired(403, { error: { code: 'other' } }), undefined)
  resetMimoPlatformState()
})

test('the app\'s own 401 reaches the refresh hook; other failures keep their status', async () => {
  const fetchFn = async () => json({ error: { message: 'stale' } }, 401)
  const failure = await hop(fetchFn).catch((error) => error)
  assert.ok(failure instanceof UpstreamFailure)
  assert.equal(failure.status, 401)
  assert.equal(failure.code, 'http')

  const refused = async () => json({ error: { message: 'nope' } }, 429, { 'retry-after': '30' })
  const rate = await hop(refused).catch((error) => error)
  assert.ok(rate instanceof UpstreamFailure)
  assert.equal(rate.status, 429)
  assert.equal(rate.retryAfter, '30')
})

// ---- quota -----------------------------------------------------------------

const SELF = { code: 0, data: { current: { planCode: 'mimo_pro_m', title: 'MiMo 高阶', planTier: 3, status: 'ACTIVE', renewalMode: 'MONTHLY', endTime: '2026-11-01T00:00:00' } } }
const USAGE = { code: 0, data: { percent: 70, resetDate: '2026-10-05' } }

test('the plan, the week\'s allowance (percent is what is LEFT), and the times', () => {
  assert.equal(mimoServerTime('2026-10-05'), '2026-10-04T16:00:00.000Z')
  assert.equal(mimoServerTime('2026-10-05T12:00:00'), '2026-10-05T04:00:00.000Z')
  assert.equal(mimoServerTime('2026-10-05T12:00:00Z'), '2026-10-05T12:00:00.000Z')
  assert.equal(mimoServerTime('soon'), undefined)

  assert.deepEqual(parseMimoSubscription(SELF.data), { planType: 'MiMo 高阶', until: '2026-10-31T16:00:00.000Z', renew: 'auto' })
  assert.deepEqual(parseMimoSubscription({ current: null }), { planType: 'Free' })
  assert.deepEqual(parseMimoSubscription({ current: { planTier: 4, renewalMode: 'ONE_TIME', endTime: '2026-11-01 08:30:00' } }), { planType: 'Ultra', until: '2026-11-01T00:30:00.000Z', renew: 'off' })
  assert.deepEqual(parseMimoSubscription({ current: { planTier: 9, planCode: 'mimo_x' } }), { planType: 'mimo_x' })

  const week = parseMimoUsage(USAGE.data)
  assert.equal(week.remainingPercent, 70)
  assert.equal(week.usedPercent, 30)
  assert.equal(week.windowMinutes, 10_080)
  assert.equal(week.resetAt, Date.parse('2026-10-04T16:00:00.000Z'))
  assert.equal(parseMimoUsage({ percent: 100, resetDate: null }), undefined)
})

test('quota reads the two app pages; the platform is best-effort', async () => {
  resetMimoPlatformState()
  const seen: string[] = []
  const fetchFn = async (url) => {
    const text = String(url)
    if (text === `${SGP}/user/xiaomi/subscription/self`) {
      seen.push(text)
      return json(SELF)
    }
    if (text === `${SGP}/user/usage`) {
      seen.push(text)
      return json(USAGE)
    }
    return json({ code: 401, loginUrl: LOGIN_URL }, 401)
  }
  const quota = await fetchMimoQuota(accountSession, fetchFn)
  assert.equal(quota.account, '42')
  assert.equal(quota.planType, 'MiMo 高阶')
  assert.equal(quota.rows.length, 1)
  assert.equal(quota.rows[0].kind, 'primary')
  assert.equal(quota.rows[0].remainingPercent, 70)
  assert.deepEqual(seen, [`${SGP}/user/xiaomi/subscription/self`, `${SGP}/user/usage`])
  resetMimoPlatformState()
})

test('no app plan makes the Token Plan the card\'s plan and its credits the allowance', async () => {
  resetMimoPlatformState()
  const platform = servePlatform()
  const fetchFn = async (url, init = {}) => {
    const text = String(url)
    if (text.startsWith('https://platform.xiaomimimo.com/') || text.startsWith(MIMO_ACCOUNT_ORIGIN)) {
      return platform.serve(text, new Headers(init.headers))
    }
    if (text.endsWith('/user/usage')) return json({ code: 0, data: { percent: 0, resetDate: null } })
    return json({ code: 0, data: { current: null } })
  }
  const quota = await fetchMimoQuota(accountSession, fetchFn)
  assert.equal(quota.planType, 'Token Plan Lite')
  assert.equal(quota.rows.length, 1)
  const row = quota.rows[0]
  assert.equal(row.kind, 'product')
  assert.equal(row.product, 'Token Plan')
  assert.equal(row.used, 6_809_408)
  assert.equal(row.total, 4_100_000_000)
  assert.equal(row.unit, 'credits')
  assert.equal(row.resetAt, Date.parse('2026-11-06T23:59:59Z'))
  resetMimoPlatformState()
})

test('an app plan keeps the week; the Token Plan rides beside it', async () => {
  resetMimoPlatformState()
  const platform = servePlatform()
  const fetchFn = async (url, init = {}) => {
    const text = String(url)
    if (text.startsWith('https://platform.xiaomimimo.com/') || text.startsWith(MIMO_ACCOUNT_ORIGIN)) {
      return platform.serve(text, new Headers(init.headers))
    }
    if (text.endsWith('/user/usage')) return json(USAGE)
    return json(SELF)
  }
  const quota = await fetchMimoQuota(accountSession, fetchFn)
  assert.equal(quota.planType, 'MiMo 高阶')
  assert.deepEqual(quota.rows.map((row) => row.product), ['7 days', 'Token Plan · API key'])
  resetMimoPlatformState()
})

// ---- login through the controller seam, and the snapshot -------------------

async function waitFor(read, { deadlineMs = 5_000, everyMs = 20 } = {}) {
  const until = Date.now() + deadlineMs
  for (;;) {
    const value = await read()
    if (value) return value
    if (Date.now() > until) throw new Error('waitFor: condition never became true')
    await new Promise((resolve) => setTimeout(resolve, everyMs))
  }
}

test('loginMimo publishes the Xiaomi page and saves the finished session', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'mimo-login-'))
  const authPath = join(dir, 'auth.json')
  const fetchFn = async (url, init = {}) => serveSignIn()(String(url), init)
  const ctl: any = {
    fetchFn,
    authPath,
    finalizing: new Set(),
    lastError: new Map(),
    quota: { refresh() { /* the saved row is the assertion */ } },
    mimoFlows: createFlowAttempts(),
  }
  const started = await loginMimo(ctl)
  assert.equal(started.mode, 'browser')
  assert.equal(started.authorizeUrl, 'https://account.xiaomi.com/longPolling/authorize')
  const rows = await waitFor(async () => {
    const found = await listStoredSessions('mimo', authPath)
    return found.length === 1 ? found : undefined
  })
  assert.equal(rows[0].id, '42')
  assert.equal(JSON.parse(rows[0].session.accessToken).serviceToken, 'st-1')
  assert.equal(ctl.finalizing.size, 0)
  assert.equal(ctl.lastError.size, 0)
})

test('controller snapshot shows quota on every mimo account; hop is Completions', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'mimo-ctrl-'))
  const authPath = join(dir, 'auth.json')
  const first = mimoSession({
    creds: { userId: '42', passToken: 'pt-a', deviceId: 'd', region: 'SGP', base: SGP },
    cookies: { serviceToken: 'st-a' },
  })
  const second = mimoSession({
    creds: { userId: '43', passToken: 'pt-b', deviceId: 'd', region: 'SGP', base: SGP },
    cookies: { serviceToken: 'st-b' },
  })
  await saveSession('mimo', first, authPath)
  await saveSession('mimo', second, authPath, { activate: false })

  const fetchFn = async (url) => {
    const text = String(url)
    if (text.endsWith('/user/xiaomi/subscription/self')) return json({ code: 0, data: { current: { title: 'MiMo 高阶', renewalMode: 'MONTHLY', endTime: '2026-11-01T00:00:00' } } })
    if (text.endsWith('/user/usage')) return json(USAGE)
    return json({ code: 401, loginUrl: LOGIN_URL }, 401)
  }
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    fetchFn,
  })
  const snap = await controller.snapshot()
  assert.equal(snap.accounts.mimo.accounts.length, 2)
  for (const row of snap.accounts.mimo.accounts) {
    assert.ok(row.quota)
    assert.equal(row.quota.status, 'ready')
    assert.equal(row.quota.planLabel, 'MiMo 高阶')
    assert.equal(row.quota.rows.length, 1)
    assert.equal(row.quota.rows[0].remainingPercent, 70)
    assert.equal(JSON.stringify(row).includes('passToken'), false)
    assert.equal(JSON.stringify(row).includes('serviceToken'), false)
  }

  const proxyFetch = async (url, init = {}) => {
    assert.equal(String(url), mimoChatUrl(first))
    assert.equal(new Headers(init.headers).get('Cookie'), 'serviceToken=st-a')
    return json({ id: 'chat', choices: [{ message: { role: 'assistant', content: 'ok' } }] })
  }
  const proxy = createProxy({
    port: 0,
    apiKey: 'proxy-key-mimo-test-xx',
    tokens: controller.tokens,
    fetchFn: proxyFetch,
  })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const response = await fetch(`http://127.0.0.1:${port}/mimo/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer proxy-key-mimo-test-xx', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'mimo-pro', messages: [{ role: 'user', content: 'hi' }], prompt_cache_key: 'codex-style', reasoning_effort: 'high' }),
    })
    assert.equal(response.status, 200)
    const models = await fetch(`http://127.0.0.1:${port}/mimo/v1/models`, { headers: { authorization: 'Bearer proxy-key-mimo-test-xx' } })
    assert.deepEqual((await models.json()).data.map((row) => row.id), ['mimo-pro', 'mimo-flash'])
    const refused = await fetch(`http://127.0.0.1:${port}/mimo/v1/responses`, {
      method: 'POST',
      headers: { authorization: 'Bearer proxy-key-mimo-test-xx', 'content-type': 'application/json' },
      body: '{}',
    })
    assert.equal(refused.status, 501)
  } finally {
    await proxy.close()
  }
})

test('mimoModel lookup and the plan names the wire spells', async () => {
  const { mimoModel, MIMO_PLAN_NAMES } = await import('../lib/oauth/mimo/index.js')
  assert.equal(mimoModel('mimo-pro').contextWindow, 1_000_000)
  assert.equal(mimoModel('nope'), undefined)
  assert.equal(MIMO_PLAN_NAMES.pro, 'Pro')
  assert.equal(MIMO_PLAN_NAMES.free, 'Free')
})
