import assert from 'node:assert/strict'
import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { AuthController } from '../lib/oauth/controller.js'
import { parseCursorPeriodUsage } from '../lib/oauth/cursor/quota.js'
import { formatPlanLabel } from '../lib/oauth/plan.js'
import { accountIdOf, listAccounts, listStoredSessions, publicSession, saveSession } from '../lib/oauth/store.js'
import {
  HARNESS_COMPLETIONS_API,
  buildProviders,
  catalogProviders,
  describeCatalog,
  ownedProviderIds,
} from '../lib/oauth/models.js'
import { syncHarnessModels } from '../lib/oauth/harness-sync.js'
import {
  cursorCatalogModels,
  cursorPickerFamilyId,
  cursorSourceIsFast,
  inferCursorContextWindow,
  inferCursorMaxOutputTokens,
  isCursorInternalModel,
  mergeCursorStaticFloor,
  CURSOR_CATALOG_TTL_MS,
  refreshCursorCatalog,
  resetCursorCatalogCache,
  toCursorPickerModels,
} from '../lib/oauth/cursor/catalog.js'
import { exerciseLiveCatalog } from './catalog-lifecycle.ts'
import {
  decodeAgentClientMessage,
  decodeAgentServerMessage,
  decodeAvailableModelsResponse,
  decodeGetUsableModelsResponse,
  encodeAvailableModelsRequest,
  encodeAvailableModelsResponse,
  encodeGetUsableModelsResponse,
  encodeMessage,
  encodeTurnEndedUpdate,
  frameConnect,
} from '../lib/oauth/cursor/proto.js'
import {
  CURSOR_CLIENT_VERSION,
  CURSOR_GET_EMAIL_URL,
  CURSOR_GET_ME_URL,
  CURSOR_LOGIN_URL,
  CURSOR_MODELS,
  CURSOR_POLL_URL,
  CURSOR_REASONING,
  CURSOR_REFRESH_URL,
  CURSOR_STRIPE_PROFILE_URL,
  CURSOR_USAGE_URL,
  completeCursorLogin,
  createCursorPkce,
  cursorAccessStillValid,
  cursorAccountFromToken,
  cursorChatHeaders,
  cursorLoginParams,
  cursorSession,
  cursorSourceLabel,
  displayCursorAccount,
  parseCursorTokenResponse,
  pollCursorAuth,
  refreshCursorTokens,
} from '../lib/oauth/cursor/index.js'
import {
  CURSOR_IMPORT_EMPTY,
  cursorVscdbPaths,
  importCursorAuth,
  readCursorKeychainTokens,
  readCursorVscdbTokens,
  resolveCursorLocalCredentials,
  rereadCursorImport,
  windowsUsernameFromEnv,
} from '../lib/oauth/cursor/import.js'
import { ImportedLoginStale } from '../lib/oauth/tokens.js'
import { configureOutbound } from '../lib/utils/outbound.js'
import {
  CURSOR_STABLE_SESSION,
  applyCursorCache,
  cursorCacheHeaders,
  cursorCacheSessionId,
  cursorConversationId,
  cursorStableId,
  peelCursorFastSuffix,
  pinCursorSystemPrefix,
  resetCursorSystemPins,
} from '../lib/oauth/cursor/cache.js'
import { consumeCursorFrames, cursorModelParameters, mapCursorUsage, openaiToCursor } from '../lib/oauth/cursor/request.js'

function jwt(payload) {
  const header = Buffer.from(JSON.stringify({ alg: 'none' })).toString('base64url')
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url')
  return `${header}.${body}.x`
}

function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })
}

function validAccess(email = 'cli@cursor.local', extra = {}) {
  return jwt({ email, exp: Math.floor(Date.now() / 1000) + 3600, ...extra })
}

function expiredAccess(email = 'stale@cursor.local') {
  return jwt({ email, exp: Math.floor(Date.now() / 1000) - 120 })
}

async function writeVscdb(dir, { accessToken, refreshToken, cachedEmail } = {}) {
  const { DatabaseSync } = await import('node:sqlite')
  const dbPath = join(dir, 'state.vscdb')
  const db = new DatabaseSync(dbPath)
  db.exec('CREATE TABLE ItemTable (key TEXT PRIMARY KEY, value TEXT)')
  const insert = db.prepare('INSERT INTO ItemTable (key, value) VALUES (?, ?)')
  if (accessToken) insert.run('cursorAuth/accessToken', accessToken)
  if (refreshToken) insert.run('cursorAuth/refreshToken', refreshToken)
  if (cachedEmail) insert.run('cursorAuth/cachedEmail', cachedEmail)
  db.close()
  return dbPath
}

function emptyImport(overrides = {}) {
  return {
    env: {},
    platform: 'linux',
    home: tmpdir(),
    execFileFn: async () => ({ stdout: '' }),
    readVscdbFn: async () => ({}),
    ...overrides,
  }
}

test('cursor PKCE login URL is loginDeepControl with challenge and uuid', () => {
  const pkce = createCursorPkce()
  const started = cursorLoginParams({ ...pkce, uuid: 'login-uuid-1' })
  assert.equal(started.loginUrl.startsWith(`${CURSOR_LOGIN_URL}?`), true)
  const url = new URL(started.loginUrl)
  assert.equal(url.searchParams.get('challenge'), pkce.challenge)
  assert.equal(url.searchParams.get('uuid'), 'login-uuid-1')
  assert.equal(url.searchParams.get('mode'), 'login')
  assert.equal(url.searchParams.get('redirectTarget'), 'cli')
})

test('cursor poll waits on 404 then stores tokens', async () => {
  let calls = 0
  const tokens = await pollCursorAuth('u1', 'verifier', {
    sleep: async () => undefined,
    fetchFn: async (url) => {
      calls += 1
      assert.equal(String(url).startsWith(CURSOR_POLL_URL), true)
      if (calls === 1) return new Response('', { status: 404 })
      return json({ accessToken: validAccess('poll@x'), refreshToken: 'rt-poll' })
    },
  })
  assert.equal(calls, 2)
  assert.equal(tokens.refreshToken, 'rt-poll')
  assert.equal(cursorAccessStillValid(tokens.accessToken), true)
})

test('cursor refresh parses exchange_user_api_key', async () => {
  const next = validAccess('refresh@x')
  const tokens = await refreshCursorTokens('rt-old', {
    fetchFn: async (url, init) => {
      assert.equal(url, CURSOR_REFRESH_URL)
      assert.equal(init.method, 'POST')
      assert.equal(init.headers.authorization, 'Bearer rt-old')
      assert.equal(init.body, '{}')
      return json({ accessToken: next, refreshToken: 'rt-new' })
    },
  })
  assert.equal(tokens.accessToken, next)
  assert.equal(tokens.refreshToken, 'rt-new')
})

test('cursor session round-trip keeps source for doctor/status', () => {
  const session = cursorSession({
    accessToken: validAccess('round@x'),
    refreshToken: 'rt-round',
    source: 'cli_keychain',
    planType: 'pro',
  })
  assert.equal(session.source, 'cli_keychain')
  assert.equal(session.account, 'round@x')
  const pub = publicSession('cursor', session)
  assert.equal(pub.account, 'round@x')
  assert.equal(pub.method, 'cli_keychain')
  assert.equal(pub.methodLabel, 'CLI')
  assert.equal(pub.planLabel, 'Pro')
  assert.equal(cursorSourceLabel('ide_vscdb'), 'IDE')
  assert.equal(cursorSourceLabel('env'), 'env')
  assert.equal(cursorSourceLabel('pkce'), 'PKCE')
})

test('JWT with only WorkOS sub is not a display account', () => {
  const opaque = 'grok|user_01TESTOPAQUEID0001'
  const token = jwt({ sub: opaque, exp: Math.floor(Date.now() / 1000) + 3600 })
  assert.equal(cursorAccountFromToken(token), undefined)
  assert.equal(displayCursorAccount({ accessToken: token, account: opaque }), undefined)
  assert.equal(displayCursorAccount({ accessToken: token, account: 'cursor' }), undefined)
  const session = cursorSession({ accessToken: token, refreshToken: 'rt-opaque' })
  const pub = publicSession('cursor', session)
  assert.equal(pub.account, undefined)
  assert.equal(accountIdOf('cursor', session), session.account)
})

test('JWT email or preferred_username wins over sub', () => {
  assert.equal(cursorAccountFromToken(jwt({
    email: 'named@x',
    sub: 'grok|user_01TESTOPAQUEID0002',
  })), 'named@x')
  assert.equal(cursorAccountFromToken(jwt({
    preferred_username: 'alice',
    sub: 'auth0|abc',
  })), 'alice')
  const session = cursorSession({
    accessToken: jwt({ email: 'named@x', sub: 'auth0|abc', exp: Math.floor(Date.now() / 1000) + 3600 }),
    refreshToken: 'rt-named',
  })
  assert.equal(publicSession('cursor', session).account, 'named@x')
})

test('cursor catalog is Completions at /cursor, not /cursor/v1', () => {
  const ids = ownedProviderIds('oauth')
  assert.equal(ids.includes('oauth-cursor'), true)
  const providers = buildProviders({
    prefix: 'oauth',
    origin: 'http://127.0.0.1:8318',
    loggedIn: { cursor: true },
  })
  const route = providers['oauth-cursor']
  assert.equal(route.api, HARNESS_COMPLETIONS_API)
  assert.equal(route.baseURL, 'http://127.0.0.1:8318/cursor')
  assert.equal(route.baseURL.endsWith('/cursor/v1'), false)
  for (const model of route.models) {
    const keys = Object.keys(model.reasoningEfforts ?? {})
    for (const key of keys) {
      assert.match(key, /^(off|minimal|low|medium|high|xhigh|max)$/)
    }
  }
  // Per-family wire values: composer-2.5 takes no effort param, grok-4.7
  // spells xhigh (not extra-high), gpt-5.5 keeps the legacy reasoning map.
  assert.equal(route.models.find((model) => model.id === 'composer-2.5').reasoningEfforts, false)
  assert.deepEqual(route.models.find((model) => model.id === 'grok-4.7').reasoningEfforts, {
    low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh',
  })
  assert.deepEqual(route.models.find((model) => model.id === 'gpt-5.5').reasoningEfforts, CURSOR_REASONING)
  assert.deepEqual(route.models.find((model) => model.id === 'composer-2.5').input, ['text'])
  assert.equal(route.models.find((model) => model.id === 'gemini-3.1-pro').reasoningEfforts, false)
  assert.equal(route.models.find((model) => model.id === 'claude-opus-5-5').reasoningEfforts.max, 'max')
  assert.equal(route.models.find((model) => model.id === 'gpt-5.6-sol').reasoningEfforts.off, 'none')
  resetCursorCatalogCache()
  assert.deepEqual(cursorModelParameters({ model: 'claude-opus-5-5', reasoning_effort: 'max' }), [
    { id: 'context', value: '300k' }, { id: 'effort', value: 'max' }, { id: 'fast', value: 'false' },
  ])
  assert.deepEqual(cursorModelParameters({ model: 'grok-4.7', reasoning_effort: 'xhigh' }), [
    { id: 'context', value: '256k' }, { id: 'reasoning_effort', value: 'xhigh' }, { id: 'fast', value: 'false' },
  ])
  const catalog = catalogProviders({ prefix: 'oauth', origin: 'http://x' })
  assert.equal(catalog['oauth-cursor'].models.length, CURSOR_MODELS.length)
})

test('snapshot shows quota on every cursor account', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-cursor-'))
  const authPath = join(dir, 'auth.json')
  const sessionA = cursorSession({
    accessToken: validAccess('a@x'), refreshToken: 'rt-a', source: 'pkce', account: 'a@x',
  })
  const sessionB = cursorSession({
    accessToken: validAccess('b@x'), refreshToken: 'rt-b', source: 'ide_vscdb', account: 'b@x',
  })
  await saveSession('cursor', sessionA, authPath)
  await saveSession('cursor', sessionB, authPath)
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    cursorAutoImport: false,
    fetchFn: async (_url, init) => {
      const auth = String(init?.headers?.authorization ?? '')
      const which = auth.includes(sessionB.accessToken) ? 'b@x' : 'a@x'
      return json({
        planUsage: { totalPercentUsed: which === 'b@x' ? 10 : 40, includedSpend: 1, limit: 10 },
        membershipType: 'pro',
        email: which,
      })
    },
  })
  const snap = await controller.snapshot()
  assert.equal(snap.catalog.some((row) => row.family === 'cursor'), true)
  const roster = snap.accounts.cursor.accounts
  assert.equal(roster.length, 2)
  const first = roster.find((row) => row.account === 'a@x')
  const second = roster.find((row) => row.account === 'b@x')
  assert.equal(first.quota.status, 'ready')
  assert.equal(second.quota.status, 'ready')
  // included + auto + api + total; the hard-limit read here answers with the
  // usage payload's shape (no hardLimit), which is "off" — no on-demand row.
  assert.equal(first.quota.rows.length, 4)
  assert.equal(first.quota.rows[0].kind, 'cycle')
  assert.equal(first.quota.rows[0].unit, 'usd')
  assert.equal(first.quota.rows.find((row) => row.product === 'auto').usedPercent, 0)
  assert.equal(second.quota.rows.find((row) => row.product === 'auto').usedPercent, 0)
  assert.equal(second.methodLabel, 'IDE')
})

test('parseCursorPeriodUsage emits included-spend usd row plus two used-percent bars', () => {
  const parsed = parseCursorPeriodUsage({
    planUsage: {
      totalPercentUsed: 44,
      autoPercentUsed: 51,
      apiPercentUsed: 0,
      includedSpend: 40000,
      limit: 40000,
    },
    membershipType: 'pro',
    billingCycleEnd: '2026-10-01T00:00:00.000Z',
    email: 'q@x',
  })
  assert.equal(parsed.planType, 'pro')
  assert.equal(formatPlanLabel(parsed.planType, 'cursor'), 'Pro')
  assert.equal(parsed.account, 'q@x')
  // included + auto + api + total (on-demand absent: nothing usage-based said).
  assert.equal(parsed.rows.length, 4)
  const included = parsed.rows[0]
  assert.equal(included.kind, 'cycle')
  assert.equal(included.unit, 'usd')
  assert.equal(included.used, 400)
  assert.equal(included.total, 400)
  assert.equal(included.remainingPercent, 0)
  const composer = parsed.rows.find((row) => row.product === 'auto')
  const api = parsed.rows.find((row) => row.product === 'api')
  assert.equal(composer.usedPercent, 51)
  assert.equal(composer.remainingPercent, 49)
  assert.equal(api.usedPercent, 0)
  assert.equal(api.remainingPercent, 100)
  assert.equal(composer.used, undefined)
  assert.equal(composer.total, undefined)
  assert.equal(api.used, undefined)
  assert.equal(api.total, undefined)
  assert.equal(JSON.stringify(parsed).includes('40000'), false)
  assert.equal(included.resetAt, Date.parse('2026-10-01T00:00:00.000Z'))
  assert.equal(api.resetAt, included.resetAt)
  // The Total row rides last (upstream usage() window order).
  const total = parsed.rows.find((row) => row.product === 'total')
  assert.equal(total.usedPercent, 44)
  assert.equal(total.remainingPercent, 56)
  assert.equal(total.resetAt, included.resetAt)
  assert.equal(parsed.rows[parsed.rows.length - 1].product, 'total')
})

test('parseCursorPeriodUsage renders the on-demand spend from spendLimitUsage + GetHardLimit (magpie onDemandOf)', () => {
  const base = { planUsage: { autoPercentUsed: 10, apiPercentUsed: 0 }, membershipType: 'pro' }
  // A member's own limit, in cents, wins over everything else.
  const own = parseCursorPeriodUsage({
    ...base,
    spendLimitUsage: { individualLimit: 5000, individualUsed: 1234 },
  })
  const ownRow = own.rows.find((row) => row.product === 'on-demand')
  assert.equal(ownRow.unit, 'usd')
  assert.equal(ownRow.used, 12.34)
  assert.equal(ownRow.total, 50)
  assert.equal(ownRow.usedPercent, 25)
  assert.equal(ownRow.remainingPercent, 75)
  // A team member with no limit of their own spends the pool: pooledLimit is
  // an int64 string, pooledUsed the whole pool's spend in cents.
  const pool = parseCursorPeriodUsage({
    ...base,
    spendLimitUsage: { limitType: 'team', pooledLimit: '4500000', pooledUsed: 90000, individualUsed: 1234 },
  })
  const poolRow = pool.rows.find((row) => row.product === 'on-demand')
  assert.equal(poolRow.used, 900)
  assert.equal(poolRow.total, 45000)
  assert.equal(poolRow.usedPercent, 2)
  // Without the pool, the hard limit caps the spend — already whole dollars.
  const hard = parseCursorPeriodUsage(
    { ...base, spendLimitUsage: { individualUsed: 200 } },
    { hardLimit: { hardLimit: 20 } },
  )
  const hardRow = hard.rows.find((row) => row.product === 'on-demand')
  assert.equal(hardRow.used, 2)
  assert.equal(hardRow.total, 20)
  assert.equal(hardRow.usedPercent, 10)
  // An int32-max hard limit is Cursor's "unlimited": dollars, no meter.
  const unlimited = parseCursorPeriodUsage(
    { ...base, spendLimitUsage: { individualUsed: 200 } },
    { hardLimit: { hardLimit: 2_147_483_647 } },
  )
  const unlimitedRow = unlimited.rows.find((row) => row.product === 'on-demand')
  assert.equal(unlimitedRow.used, 2)
  assert.equal(unlimitedRow.total, undefined)
  assert.equal(unlimitedRow.usedPercent, undefined)
  // Nothing usage-based stated and no hard reply: no on-demand row at all.
  const none = parseCursorPeriodUsage(base, {})
  assert.equal(none.rows.some((row) => row.product === 'on-demand'), false)
})

test('parseCursorPeriodUsage keeps a sub-1 API percent visible and prefers stripe Ultra', () => {
  const parsed = parseCursorPeriodUsage({
    planUsage: {
      autoPercentUsed: 55.123,
      apiPercentUsed: 0.454,
      totalPercentUsed: 47.313,
    },
    spendLimitUsage: { limitType: 'user' },
  }, {
    stripe: { membershipType: 'ultra', individualMembershipType: 'ultra' },
  })
  assert.equal(parsed.planType, 'ultra')
  assert.equal(formatPlanLabel(parsed.planType, 'cursor'), 'Ultra')
  assert.equal(parsed.account, undefined)
  const composer = parsed.rows.find((row) => row.product === 'auto')
  const api = parsed.rows.find((row) => row.product === 'api')
  assert.equal(composer.usedPercent, 55)
  assert.equal(composer.remainingPercent, 45)
  assert.equal(api.usedPercent, 1)
  assert.equal(api.remainingPercent, 99)
  const zero = parseCursorPeriodUsage({
    planUsage: { autoPercentUsed: 0, apiPercentUsed: 0 },
  })
  assert.equal(zero.planType, 'Pro')
  assert.equal(zero.rows[0].usedPercent, 0)
  assert.equal(zero.rows[0].remainingPercent, 100)
  assert.equal(zero.rows[1].usedPercent, 0)
  assert.equal(zero.rows[1].remainingPercent, 100)
})

test('parseCursorPeriodUsage always emits both bars at 0% when percents are missing', () => {
  const parsed = parseCursorPeriodUsage({
    planUsage: { totalPercentUsed: 0, includedSpend: 0, limit: 40000 },
    membershipType: 'proplus',
  })
  assert.equal(formatPlanLabel(parsed.planType, 'cursor'), 'Pro+')
  const included = parsed.rows[0]
  assert.equal(included.kind, 'cycle')
  assert.equal(included.unit, 'usd')
  assert.equal(included.used, 0)
  assert.equal(included.total, 400)
  assert.equal(included.remainingPercent, 100)
  // included + auto + api + total.
  assert.equal(parsed.rows.length, 4)
  assert.equal(parsed.rows[1].usedPercent, 0)
  assert.equal(parsed.rows[2].usedPercent, 0)
  assert.equal(parsed.rows[1].total, undefined)
})

test('cursor cache sanitizer and sticky conversation id across two turns', () => {
  resetCursorSystemPins()
  assert.equal(cursorCacheSessionId('session 772f7f3a/foo'), 'session-772f7f3a-foo')
  assert.equal(cursorCacheSessionId(''), undefined)
  const first = applyCursorCache({
    session_id: 'sess-cursor',
    prompt_cache_key: 'codex-style',
    prompt_cache_retention: '24h',
    model: 'composer-2',
  })
  assert.equal(first.payload.prompt_cache_key, undefined)
  assert.equal(first.payload.prompt_cache_retention, undefined)
  assert.equal(first.payload.service_tier, undefined)
  assert.equal(first.cacheSessionId, 'sess-cursor:composer-2')
  assert.deepEqual(cursorCacheHeaders(), {})
  const second = cursorConversationId({ session_id: 'sess-cursor', model: 'composer-2' })
  assert.equal(second, first.cacheSessionId)
  assert.equal(
    cursorConversationId({ session_id: 'sess-cursor', model: 'gpt-5.5-fast' }),
    cursorConversationId({ session_id: 'sess-cursor', model: 'gpt-5.5' }),
  )
  assert.equal(peelCursorFastSuffix('gpt-5.5-fast').modelId, 'gpt-5.5')
  assert.equal(peelCursorFastSuffix('gpt-5.5-fast').requestedFast, true)
  assert.notEqual(
    cursorConversationId({ model: 'composer-2' }),
    cursorConversationId({ model: 'gpt-5.5' }),
  )
  assert.equal(cursorConversationId({}), CURSOR_STABLE_SESSION)
  assert.equal(/^-\d+$/.test(cursorConversationId({})), false)
  const pin = pinCursorSystemPrefix('sess-cursor:composer-2', 'You are DSH.')
  const extra = pinCursorSystemPrefix('sess-cursor:composer-2', 'You are DSH.\nSnapshot')
  assert.equal(pin.pinned, 'You are DSH.')
  assert.equal(extra.pinned, 'You are DSH.')
  assert.equal(extra.extra, 'Snapshot')
  resetCursorSystemPins()
})

test('cursor hop Completions → AgentClientMessage keeps model, user, tools, conversation id', () => {
  resetCursorSystemPins()
  const built = openaiToCursor({
    model: 'composer-2',
    session_id: 'sess-hop',
    messages: [
      { role: 'system', content: 'You are DSH.' },
      { role: 'user', content: 'list files' },
    ],
    tools: [{
      type: 'function',
      function: { name: 'glob', description: 'find files', parameters: { type: 'object' } },
    }],
    reasoning_effort: 'high',
  })
  const decoded = decodeAgentClientMessage(built.requestBytes)
  assert.equal(built.conversationId, 'sess-hop:composer-2')
  assert.equal(decoded.conversationId, 'sess-hop:composer-2')
  assert.equal(decoded.modelId, 'composer-2')
  assert.equal(decoded.userText, 'list files')
  assert.equal(decoded.tools.some((tool) => tool.name === 'glob'), true)
  assert.equal(decoded.hasConversationState, true)
  resetCursorSystemPins()
})

test('cursor hop peels -fast to family modelId and sets RequestedModel fast param', () => {
  resetCursorSystemPins()
  const built = openaiToCursor({
    model: 'gpt-5.5-fast',
    session_id: 'sess-fast',
    reasoning_effort: 'high',
    service_tier: 'priority',
    messages: [{ role: 'user', content: 'hi' }],
  })
  const decoded = decodeAgentClientMessage(built.requestBytes)
  assert.equal(built.modelId, 'gpt-5.5')
  assert.equal(built.pickerModel, 'gpt-5.5-fast')
  assert.equal(decoded.modelId, 'gpt-5.5')
  assert.equal(decoded.modelId.endsWith('-fast'), false)
  assert.equal(decoded.maxMode, false)
  assert.deepEqual(decoded.parameters, [
    { id: 'context', value: '272k' },
    { id: 'reasoning', value: 'high' },
    { id: 'fast', value: 'true' },
  ])
  assert.equal(built.conversationId, 'sess-fast:gpt-5.5')
  assert.equal(decoded.conversationId, 'sess-fast:gpt-5.5')
  assert.equal(JSON.stringify(decoded).includes('service_tier'), false)
  const cached = applyCursorCache({
    model: 'gpt-5.5-fast',
    session_id: 'sess-fast',
    service_tier: 'priority',
  })
  assert.equal(cached.payload.model, 'gpt-5.5-fast')
  assert.equal(cached.payload.service_tier, undefined)
  assert.equal(cached.cacheSessionId, 'sess-fast:gpt-5.5')
  const plain = openaiToCursor({
    model: 'gpt-5.5',
    reasoning_effort: 'high',
    messages: [{ role: 'user', content: 'hi' }],
  })
  const plainDecoded = decodeAgentClientMessage(plain.requestBytes)
  assert.equal(plainDecoded.modelId, 'gpt-5.5')
  assert.deepEqual(plainDecoded.parameters, [
    { id: 'context', value: '272k' },
    { id: 'reasoning', value: 'high' },
    { id: 'fast', value: 'false' },
  ])
  resetCursorSystemPins()
})

test('cursor registry parameters use the family wire spelling (grok-4.7 reasoning_effort)', () => {
  resetCursorSystemPins()
  // Live AvailableModels: grok-4.7 takes reasoning_effort=xhigh, not
  // reasoning=extra-high — the wrong id/value 400s the whole Run.
  const built = openaiToCursor({
    model: 'grok-4.7',
    session_id: 'sess-g47',
    reasoning_effort: 'xhigh',
    messages: [{ role: 'user', content: 'hi' }],
  })
  const decoded = decodeAgentClientMessage(built.requestBytes)
  assert.equal(decoded.modelId, 'grok-4.7')
  assert.deepEqual(decoded.parameters, [
    { id: 'context', value: '256k' },
    { id: 'reasoning_effort', value: 'xhigh' },
    { id: 'fast', value: 'false' },
  ])

  const fast = openaiToCursor({
    model: 'grok-4.7-fast',
    session_id: 'sess-g47f',
    reasoning_effort: 'xhigh',
    messages: [{ role: 'user', content: 'hi' }],
  })
  const fastDecoded = decodeAgentClientMessage(fast.requestBytes)
  assert.equal(fastDecoded.modelId, 'grok-4.7')
  assert.deepEqual(fastDecoded.parameters, [
    { id: 'context', value: '256k' },
    { id: 'reasoning_effort', value: 'xhigh' },
    { id: 'fast', value: 'true' },
  ])

  // grok-4.7 advertises no 'none' effort — an unadvertised value is omitted,
  // not sent to the registry to 400.
  const off = openaiToCursor({
    model: 'grok-4.7',
    reasoning_effort: 'off',
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.deepEqual(decodeAgentClientMessage(off.requestBytes).parameters, [
    { id: 'context', value: '256k' },
    { id: 'fast', value: 'false' },
  ])
  resetCursorSystemPins()
})

test('cursor registry parameters omit effort for families without a style', () => {
  resetCursorSystemPins()
  // composer-2 is not in the static style table and has no live style: no
  // effort parameter is sent (guessing an id fails the Run).
  const built = openaiToCursor({
    model: 'composer-2',
    reasoning_effort: 'high',
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.deepEqual(decodeAgentClientMessage(built.requestBytes).parameters, [])
  // composer-2.5 advertises only fast — effort is omitted, fast is explicit.
  const composer = openaiToCursor({
    model: 'composer-2.5-fast',
    reasoning_effort: 'high',
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.deepEqual(decodeAgentClientMessage(composer.requestBytes).parameters, [
    { id: 'fast', value: 'true' },
  ])
  resetCursorSystemPins()
})

test('cursor CLI fingerprint stays cli and matches SDK original-request-id', () => {
  assert.equal(CURSOR_CLIENT_VERSION, 'cli-2026.09.23-86fc751')
  const headers = cursorChatHeaders({ accessToken: 'tok' }, { requestId: 'req-cursor-1' })
  assert.equal(headers['x-cursor-client-version'], 'cli-2026.09.23-86fc751')
  assert.equal(headers['x-cursor-client-type'], 'cli')
  assert.equal(headers['x-request-id'], 'req-cursor-1')
  assert.equal(headers['x-original-request-id'], 'req-cursor-1')
  assert.equal(Object.hasOwn(headers, 'x-parent-request-id'), false)
  assert.equal(Object.hasOwn(headers, 'x-root-parent-request-id'), false)
  assert.equal(Object.hasOwn(headers, 'session-id'), false)
  assert.equal(Object.hasOwn(headers, 'x-grok-conv-id'), false)
})

test('cursor hop keeps conversation prefix bytes stable across identical turns', () => {
  resetCursorSystemPins()
  const payload = {
    model: 'composer-2',
    session_id: 'sess-stable-cursor',
    messages: [
      { role: 'system', content: 'You are DSH.' },
      { role: 'user', content: 'hello' },
      { role: 'assistant', content: 'hi' },
      { role: 'user', content: 'again' },
    ],
  }
  const first = openaiToCursor(payload)
  const second = openaiToCursor(payload)
  assert.equal(first.requestBytes.equals(second.requestBytes), true)
  assert.equal(cursorStableId('a', 'b'), cursorStableId('a', 'b'))
  assert.notEqual(cursorStableId('a', 'b'), cursorStableId('a', 'c'))
  resetCursorSystemPins()
})

test('TurnEndedUpdate cache_read_tokens maps to OpenAI cached_tokens', () => {
  const payload = encodeMessage(1, encodeMessage(14, encodeTurnEndedUpdate({
    inputTokens: 1000,
    outputTokens: 40,
    cacheReadTokens: 800,
    cacheWriteTokens: 50,
    reasoningTokens: 12,
  })))
  const msg = decodeAgentServerMessage(payload)
  assert.equal(msg.turnEnded, true)
  assert.equal(msg.usage.promptTokens, 1000)
  assert.equal(msg.usage.completionTokens, 40)
  assert.equal(msg.usage.cachedTokens, 800)
  assert.equal(msg.usage.cacheWriteTokens, 50)
  const usage = mapCursorUsage(msg.usage)
  assert.equal(usage.prompt_tokens, 1000)
  assert.equal(usage.completion_tokens, 40)
  assert.equal(usage.prompt_tokens_details.cached_tokens, 800)
  assert.equal(mapCursorUsage({ promptTokens: 10, completionTokens: 2 }).prompt_tokens_details, undefined)
})

test('keychain hit prefers a still-valid access token with zero network', async () => {
  const access = validAccess('key@x')
  const session = await resolveCursorLocalCredentials(emptyImport({
    platform: 'darwin',
    execFileFn: async (_cmd, args) => {
      const service = args[args.indexOf('-s') + 1]
      if (service === 'cursor-access-token') return { stdout: `${access}\n` }
      if (service === 'cursor-refresh-token') return { stdout: 'rt-keychain\n' }
      throw new Error(`unexpected service ${service}`)
    },
  }))
  assert.equal(session.source, 'cli_keychain')
  assert.equal(session.accessToken, access)
  assert.equal(session.account, 'key@x')
})

test('vscdb hit uses ItemTable tokens when Keychain is empty', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-vscdb-'))
  const access = validAccess('ide@x')
  const dbPath = await writeVscdb(dir, { accessToken: access, refreshToken: 'rt-ide' })
  const fromFile = await readCursorVscdbTokens({ paths: [dbPath], platform: 'linux', env: {}, home: dir })
  assert.equal(fromFile.accessToken, access)
  assert.equal(fromFile.refreshToken, 'rt-ide')
  const imported = await importCursorAuth(emptyImport({
    platform: 'linux',
    readVscdbFn: async () => ({ accessToken: access, refreshToken: 'rt-ide' }),
  }))
  assert.equal(imported.source, 'ide_vscdb')
  assert.equal(imported.session.accessToken, access)
  assert.equal(imported.session.account, 'ide@x')
})

test('vscdb import with cachedEmail sets that email', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-vscdb-email-'))
  const access = jwt({
    sub: 'auth0|opaqueimport',
    exp: Math.floor(Date.now() / 1000) + 3600,
  })
  const dbPath = await writeVscdb(dir, {
    accessToken: access,
    refreshToken: 'rt-ide-email',
    cachedEmail: 'cached@x',
  })
  const fromFile = await readCursorVscdbTokens({ paths: [dbPath], platform: 'linux', env: {}, home: dir })
  assert.equal(fromFile.cachedEmail, 'cached@x')
  const imported = await importCursorAuth(emptyImport({
    platform: 'linux',
    readVscdbFn: async () => fromFile,
  }))
  assert.equal(imported.source, 'ide_vscdb')
  assert.equal(imported.session.account, 'cached@x')
  assert.equal(publicSession('cursor', imported.session).account, 'cached@x')
})

test('expired Keychain and vscdb are stale: import redeems neither refresh token', async () => {
  const stale = expiredAccess('stale@x')
  const calls: any[] = []
  configureOutbound({ fetchFn: async (url) => { calls.push(String(url)); throw new Error('import must not exchange') } })
  try {
    await assert.rejects(
      () => importCursorAuth(emptyImport({
        platform: 'darwin',
        execFileFn: async (_cmd, args) => {
          const service = args[args.indexOf('-s') + 1]
          if (service === 'cursor-access-token') return { stdout: stale }
          if (service === 'cursor-refresh-token') return { stdout: 'rt-stale' }
          throw new Error(service)
        },
        readVscdbFn: async () => ({ accessToken: stale, refreshToken: 'rt-ide-other' }),
      })),
      (error: any) => error instanceof ImportedLoginStale && error.status === 403 && /run cursor-agent/.test(error.message),
    )
  } finally {
    configureOutbound()
  }
  assert.deepEqual(calls, [])
})

test('cli reread follows the import order: a stale Keychain leftover must not shadow a live auth.json', async () => {
  const stale = expiredAccess('stale-keychain@x')
  const live = validAccess('file@x')
  const options = emptyImport({
    platform: 'darwin',
    execFileFn: async (_cmd, args) => {
      const service = args[args.indexOf('-s') + 1]
      if (service === 'cursor-access-token') return { stdout: stale }
      if (service === 'cursor-refresh-token') return { stdout: 'rt-stale' }
      throw new Error(service)
    },
    readAuthFileFn: async () => ({ accessToken: live, refreshToken: 'rt-file' }),
  })
  const imported = await importCursorAuth(options)
  assert.equal(imported.source, 'cli_keychain')
  assert.equal(imported.session.accessToken, live)
  const reread = await rereadCursorImport(imported.session, options)
  assert.equal(reread?.source, 'cli_keychain')
  assert.equal(reread?.accessToken, live)
  assert.equal(reread?.refreshToken, 'rt-file')
  assert.equal(cursorAccessStillValid(reread.accessToken), true)
})

test('cli reread prefers a still-valid Keychain entry over auth.json, like the import', async () => {
  const fromKeychain = validAccess('keychain@x')
  const fromAuthFile = validAccess('file@x')
  const options = emptyImport({
    platform: 'darwin',
    execFileFn: async (_cmd, args) => {
      const service = args[args.indexOf('-s') + 1]
      if (service === 'cursor-access-token') return { stdout: fromKeychain }
      if (service === 'cursor-refresh-token') return { stdout: 'rt-keychain' }
      throw new Error(service)
    },
    readAuthFileFn: async () => ({ accessToken: fromAuthFile, refreshToken: 'rt-file' }),
  })
  const session = (await importCursorAuth(options)).session
  assert.equal(session.accessToken, fromKeychain)
  const reread = await rereadCursorImport(session, options)
  assert.equal(reread?.accessToken, fromKeychain)
  assert.equal(reread?.refreshToken, 'rt-keychain')
})

test('cli reread with every store stale still returns the stale entry, not undefined', async () => {
  const staleKeychain = expiredAccess('stale-keychain@x')
  const staleFile = expiredAccess('stale-file@x')
  const options = emptyImport({
    platform: 'darwin',
    execFileFn: async (_cmd, args) => {
      const service = args[args.indexOf('-s') + 1]
      if (service === 'cursor-access-token') return { stdout: staleKeychain }
      if (service === 'cursor-refresh-token') return { stdout: 'rt-stale' }
      throw new Error(service)
    },
    readAuthFileFn: async () => ({ accessToken: staleFile, refreshToken: 'rt-stale-file' }),
  })
  const reread = await rereadCursorImport({ source: 'cli_keychain' }, options)
  assert.equal(reread?.accessToken, staleKeychain)
  assert.equal(cursorAccessStillValid(reread.accessToken), false)
})

test('empty machine throws cursor-import-empty, not a stack', async () => {
  await assert.rejects(
    () => importCursorAuth(emptyImport()),
    (error) => error.code === CURSOR_IMPORT_EMPTY && error.message === CURSOR_IMPORT_EMPTY,
  )
})

test('CURSOR_ACCESS_TOKEN env wins and does not refresh', async () => {
  const access = validAccess('env@x')
  const session = await resolveCursorLocalCredentials(emptyImport({
    env: { CURSOR_ACCESS_TOKEN: access },
  }))
  assert.equal(session.source, 'env')
  assert.equal(session.accessToken, access)
})

test('WSL username parsing does not walk other Users', () => {
  assert.equal(windowsUsernameFromEnv({ USERPROFILE: 'C:\\Users\\alice', USERNAME: 'alice' }), 'alice')
  assert.equal(windowsUsernameFromEnv({ USERPROFILE: 'C:\\Users\\Public', USERNAME: 'alice' }), 'alice')
  assert.equal(windowsUsernameFromEnv({ USERNAME: 'Public' }), undefined)
  assert.equal(windowsUsernameFromEnv({ USERNAME: 'Default' }), undefined)
  const paths = cursorVscdbPaths({
    platform: 'linux',
    home: '/home/alice',
    env: {
      WSL_DISTRO_NAME: 'Ubuntu',
      USERPROFILE: 'C:\\Users\\alice',
      USERNAME: 'alice',
    },
  })
  assert.equal(paths.some((path) => path.includes('/mnt/c/Users/alice/AppData/Roaming/Cursor/')), true)
  assert.equal(paths.some((path) => /\/mnt\/c\/Users\/(Public|Default|bob)\//.test(path)), false)
  assert.equal(paths.filter((path) => path.includes('/mnt/c/Users/')).length, 1)
})

test('readCursorKeychainTokens is darwin-only and concurrent', async () => {
  const seen = []
  const tokens = await readCursorKeychainTokens({
    platform: 'darwin',
    execFileFn: async (_cmd, args) => {
      seen.push(args[args.indexOf('-s') + 1])
      return { stdout: seen[seen.length - 1] === 'cursor-access-token' ? 'acc' : 'ref' }
    },
  })
  assert.deepEqual(seen.sort(), ['cursor-access-token', 'cursor-refresh-token'])
  assert.equal(tokens.accessToken, 'acc')
  assert.equal(tokens.refreshToken, 'ref')
  assert.deepEqual(await readCursorKeychainTokens({ platform: 'linux' }), {})
})

test('empty-roster auto-import saves CLI source; PKCE is not overwritten', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-cursor-auto-'))
  const authPath = join(dir, 'auth.json')
  const access = validAccess('auto@x')
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    cursorAutoImport: true,
    cursorImport: emptyImport({
      platform: 'darwin',
      execFileFn: async (_cmd, args) => {
        const service = args[args.indexOf('-s') + 1]
        return { stdout: service === 'cursor-access-token' ? access : 'rt-auto' }
      },
    }),
    fetchFn: async () => json({
      planUsage: { totalPercentUsed: 5, includedSpend: 0, limit: 10 },
      membershipType: 'pro',
      email: 'auto@x',
    }),
  })
  const snap = await controller.snapshot()
  assert.equal(snap.accounts.cursor.loggedIn, true)
  assert.equal(snap.accounts.cursor.accounts[0].methodLabel, 'CLI')

  const pkce = cursorSession({
    accessToken: validAccess('auto@x'),
    refreshToken: 'rt-pkce',
    source: 'pkce',
    account: 'auto@x',
  })
  await saveSession('cursor', pkce, authPath)
  const imported = await controller.importFrom('cursor')
  assert.equal(imported.source, 'pkce')
  const rows = await listStoredSessions('cursor', authPath)
  assert.equal(rows[0].session.source, 'pkce')
  assert.equal(accountIdOf('cursor', rows[0].session), 'auto@x')
})

test('signing out survives a restart: auto-import does not restore the family', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-cursor-signout-'))
  const authPath = join(dir, 'auth.json')
  const access = validAccess('auto@x')
  const make = () => new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    cursorAutoImport: true,
    cursorImport: emptyImport({
      platform: 'darwin',
      execFileFn: async (_cmd, args) => {
        const service = args[args.indexOf('-s') + 1]
        return { stdout: service === 'cursor-access-token' ? access : 'rt-auto' }
      },
    }),
    fetchFn: async () => json({ planUsage: { totalPercentUsed: 5, includedSpend: 0, limit: 10 }, membershipType: 'pro', email: 'auto@x' }),
  })
  const first = make()
  assert.equal((await first.snapshot()).accounts.cursor.loggedIn, true)
  await first.logout('cursor', 'auto@x')
  assert.deepEqual(await listStoredSessions('cursor', authPath), [])

  const restarted = make()
  assert.equal((await restarted.snapshot(true)).accounts.cursor.loggedIn, false)
  assert.deepEqual(await listStoredSessions('cursor', authPath), [])
  // An explicit import still works after signing out.
  await restarted.importFrom('cursor')
  assert.equal((await listStoredSessions('cursor', authPath)).length, 1)
})

test('sign out, sign back in, sign out again: each restart honours the latest choice', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-cursor-signout-cycle-'))
  const authPath = join(dir, 'auth.json')
  const access = validAccess('auto@x')
  const make = () => new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    cursorAutoImport: true,
    cursorImport: emptyImport({
      platform: 'darwin',
      execFileFn: async (_cmd, args) => {
        const service = args[args.indexOf('-s') + 1]
        return { stdout: service === 'cursor-access-token' ? access : 'rt-auto' }
      },
    }),
    fetchFn: async () => json({ planUsage: { totalPercentUsed: 5, includedSpend: 0, limit: 10 }, membershipType: 'pro', email: 'auto@x' }),
  })
  const first = make()
  assert.equal((await first.snapshot()).accounts.cursor.loggedIn, true, 'auto-import on the first run')
  await first.logout('cursor', 'auto@x')

  // The user explicitly signs back in (an import click), then leaves again.
  const second = make()
  assert.equal((await second.snapshot(true)).accounts.cursor.loggedIn, false, 'signed out stays signed out across a restart')
  await second.importFrom('cursor')
  assert.equal((await listStoredSessions('cursor', authPath)).length, 1)
  await second.logout('cursor', 'auto@x')

  // The latest choice is "signed out": the next restart must not bring it back.
  const third = make()
  assert.equal((await third.snapshot(true)).accounts.cursor.loggedIn, false)
  assert.deepEqual(await listStoredSessions('cursor', authPath), [])
})

test('snapshot backfills opaque cursor vault when usage has email', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-cursor-usage-'))
  const authPath = join(dir, 'auth.json')
  const opaque = 'grok|user_01TESTUSAGEBACKFILL'
  const access = jwt({ sub: opaque, exp: Math.floor(Date.now() / 1000) + 3600 })
  const session = cursorSession({
    accessToken: access,
    refreshToken: 'rt-usage',
    source: 'pkce',
    account: opaque,
  })
  await saveSession('cursor', session, authPath)
  assert.equal(accountIdOf('cursor', session), opaque)
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    cursorAutoImport: false,
    fetchFn: async (url) => {
      if (String(url).includes('GetCurrentPeriodUsage')) {
        return json({
          planUsage: { autoPercentUsed: 12, apiPercentUsed: 0 },
          membershipType: 'pro',
          email: 'from-usage@x',
        })
      }
      return new Response('', { status: 404 })
    },
  })
  const snap = await controller.snapshot()
  assert.equal(snap.accounts.cursor.account, 'from-usage@x')
  assert.equal(snap.accounts.cursor.accounts[0].account, 'from-usage@x')
  assert.equal(snap.accounts.cursor.accounts[0].id, 'from-usage@x')
  const roster = await listAccounts('cursor', authPath)
  assert.equal(roster[0].id, 'from-usage@x')
  assert.equal(roster.some((row) => row.id === opaque || row.account === opaque), false)
})

test('snapshot backfills opaque cursor vault from vscdb cachedEmail', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-cursor-cached-'))
  const authPath = join(dir, 'auth.json')
  const opaque = 'auth0|opaquevault'
  const access = jwt({ sub: opaque, exp: Math.floor(Date.now() / 1000) + 3600 })
  const session = cursorSession({
    accessToken: access,
    refreshToken: 'rt-cached',
    source: 'ide_vscdb',
    account: opaque,
  })
  await saveSession('cursor', session, authPath)
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    cursorAutoImport: false,
    cursorImport: emptyImport({
      readVscdbFn: async () => ({
        accessToken: access,
        refreshToken: 'rt-cached',
        cachedEmail: 'from-ide@x',
      }),
    }),
    fetchFn: async () => json({
      planUsage: { autoPercentUsed: 8, apiPercentUsed: 0 },
      membershipType: 'pro',
    }),
  })
  const snap = await controller.snapshot()
  assert.equal(snap.accounts.cursor.account, 'from-ide@x')
  assert.equal(snap.accounts.cursor.accounts[0].account, 'from-ide@x')
  assert.equal(snap.accounts.cursor.accounts[0].id, 'from-ide@x')
  const roster = await listAccounts('cursor', authPath)
  assert.equal(roster[0].id, 'from-ide@x')
  assert.equal(roster.some((row) => row.id === opaque || row.account === opaque), false)
})

test('snapshot opens state.vscdb only for a Cursor row lacking identity, once per TTL', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-cursor-vscdb-'))
  const authPath = join(dir, 'auth.json')
  const exp = Math.floor(Date.now() / 1000) + 3600
  await saveSession('cursor', cursorSession({
    accessToken: jwt({ sub: 'auth0|named', exp }),
    refreshToken: 'rt-named',
    source: 'pkce',
    account: 'named@x',
  }), authPath)
  let opens = 0
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    cursorAutoImport: false,
    cursorImport: emptyImport({ readVscdbFn: async () => { opens += 1; return {} } }),
    fetchFn: async () => json({ planUsage: { autoPercentUsed: 8, apiPercentUsed: 0 }, membershipType: 'pro' }),
  })
  await controller.snapshot()
  assert.equal(opens, 0)
  await saveSession('cursor', cursorSession({
    accessToken: jwt({ sub: 'auth0|opaque2', exp }),
    refreshToken: 'rt-opaque',
    source: 'pkce',
    account: 'auth0|opaque2',
  }), authPath)
  await controller.snapshot()
  await controller.snapshot()
  assert.equal(opens, 1)
})

test('refreshQuota GetEmail backfills opaque PKCE and stripe Ultra percents', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-cursor-refresh-'))
  const authPath = join(dir, 'auth.json')
  const opaque = 'auth0|user_01TESTGETEMAIL0001'
  const pkceAccess = jwt({
    sub: opaque,
    exp: Math.floor(Date.now() / 1000) + 3600,
    iss: 'https://authentication.cursor.sh',
  })
  const ideAccess = jwt({
    sub: 'auth0|user_01TESTIDE0002',
    exp: Math.floor(Date.now() / 1000) + 3600,
  })
  await saveSession('cursor', cursorSession({
    accessToken: pkceAccess,
    refreshToken: 'rt-pkce',
    source: 'pkce',
    account: opaque,
  }), authPath)
  await saveSession('cursor', cursorSession({
    accessToken: ideAccess,
    refreshToken: 'rt-ide',
    source: 'ide_vscdb',
    account: 'ide-user@example.test',
  }), authPath)
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    cursorAutoImport: false,
    cursorDiscover: async () => undefined,
    fetchFn: async (url, init) => {
      const href = String(url)
      const auth = String(init?.headers?.authorization ?? '')
      const pkce = auth.includes(pkceAccess)
      if (href === CURSOR_USAGE_URL) {
        return json(pkce
          ? {
            planUsage: {
              remaining: 2000,
              limit: 2000,
              autoPercentUsed: 0,
              apiPercentUsed: 0,
              totalPercentUsed: 0,
            },
            spendLimitUsage: { limitType: 'user' },
            displayMessage: "You've used 0% of your included usage",
          }
          : {
            planUsage: {
              autoPercentUsed: 55.123,
              apiPercentUsed: 0.454,
              totalPercentUsed: 47.313,
            },
            spendLimitUsage: { limitType: 'user' },
            displayMessage: "You've hit your usage limit",
          })
      }
      if (href === CURSOR_STRIPE_PROFILE_URL) {
        return json(pkce
          ? { membershipType: 'pro', individualMembershipType: 'pro' }
          : { membershipType: 'ultra', individualMembershipType: 'ultra' })
      }
      if (href === CURSOR_GET_EMAIL_URL) {
        return json({
          email: pkce ? 'pkce-user@example.test' : 'ide-user@example.test',
          signUpType: 'email',
          isRecentlyCreatedUser: false,
        })
      }
      if (href === CURSOR_GET_ME_URL) {
        throw new Error('GetMe is only for missing GetEmail')
      }
      return new Response('', { status: 404 })
    },
  })
  await controller.refreshQuota('cursor')
  const snap = await controller.snapshot()
  const roster = snap.accounts.cursor.accounts
  const pkceCard = roster.find((row) => row.account === 'pkce-user@example.test')
  const ideCard = roster.find((row) => row.account === 'ide-user@example.test')
  assert.ok(pkceCard)
  assert.ok(ideCard)
  assert.equal(pkceCard.planLabel, 'Pro')
  assert.equal(ideCard.planLabel, 'Ultra')
  assert.equal(pkceCard.quota.rows.find((row) => row.product === 'auto').remainingPercent, 100)
  assert.equal(pkceCard.quota.rows.find((row) => row.product === 'api').remainingPercent, 100)
  assert.equal(ideCard.quota.rows.find((row) => row.product === 'auto').remainingPercent, 45)
  assert.equal(ideCard.quota.rows.find((row) => row.product === 'api').remainingPercent, 99)
  assert.equal(ideCard.quota.rows.find((row) => row.product === 'api').usedPercent, 1)
  const stored = await listAccounts('cursor', authPath)
  assert.equal(stored.some((row) => row.id === opaque || row.account === opaque), false)
  assert.equal(stored.some((row) => /auth0\||grok\|user_/.test(String(row.id))), false)
  const pkceStored = (await listStoredSessions('cursor', authPath))
    .find((row) => row.session.cachedEmail === 'pkce-user@example.test')
  assert.ok(pkceStored)
  assert.equal(pkceStored.session.account, 'pkce-user@example.test')
})

test('parseCursorTokenResponse and completeCursorLogin tag pkce', async () => {
  const parsed = parseCursorTokenResponse({ accessToken: 'a', refreshToken: 'r' })
  const session = await completeCursorLogin(parsed)
  assert.equal(session.source, 'pkce')
  assert.equal(session.refreshToken, 'r')
})

test('cursor static catalog matches the live Cursor model set and has no Fast rows', () => {
  const ids = CURSOR_MODELS.map((model) => model.id)
  assert.deepEqual(ids, [
    'composer-2.5',
    'grok-4.7',
    'grok-4.6',
    'grok-4.5',
    'claude-fable-5-1',
    'claude-opus-5-5',
    'claude-opus-5',
    'claude-sonnet-5-5',
    'claude-sonnet-5',
    'claude-haiku-5-5',
    'gemini-3.1-pro',
    'gemini-3.8-flash',
    'gemini-4-argon',
    'muse-spark-1.3',
    'muse-wonder-1.0',
    'gpt-5.6-sol',
    'gpt-5.6-terra',
    'gpt-5.6-luna',
    'gpt-5.5',
  ])
  assert.equal(ids.some((id) => id.endsWith('-fast')), false)
  assert.equal(ids.includes('default'), false)
  assert.equal(CURSOR_MODELS.find((model) => model.id === 'grok-4.5').contextWindow, 256_000)
  assert.equal(CURSOR_MODELS.find((model) => model.id === 'grok-4.7').contextWindow, 256_000)
  assert.deepEqual(CURSOR_MODELS.find((model) => model.id === 'grok-4.7').input, ['text'])
  // Live list flips this one back and forth (supportsImages false on 09-30, true on 10-05).
  assert.deepEqual(CURSOR_MODELS.find((model) => model.id === 'claude-sonnet-5-5').input, ['text', 'image'])
  assert.equal(CURSOR_MODELS.find((model) => model.id === 'claude-opus-5').contextWindow, 300_000)
  assert.equal(CURSOR_MODELS.find((model) => model.id === 'claude-opus-5-5').contextWindow, 300_000)
  assert.equal(CURSOR_MODELS.find((model) => model.id === 'claude-haiku-5-5').contextWindow, 300_000)
  assert.equal(CURSOR_MODELS.find((model) => model.id === 'claude-haiku-5-5').maxTokens, 64_000)
  assert.equal(CURSOR_MODELS.find((model) => model.id === 'muse-spark-1.3').contextWindow, 300_000)
  assert.equal(CURSOR_MODELS.find((model) => model.id === 'muse-spark-1.3').maxTokens, 64_000)
  // Muse Wonder is 300K as a plain Run; the 1M only exists in Max Mode, which
  // this hop never sends — cataloguing 1M would push compaction past the gate.
  assert.equal(CURSOR_MODELS.find((model) => model.id === 'muse-wonder-1.0').contextWindow, 300_000)
  assert.equal(CURSOR_MODELS.find((model) => model.id === 'muse-wonder-1.0').maxTokens, 64_000)
  assert.equal(CURSOR_MODELS.find((model) => model.id === 'gemini-4-argon').contextWindow, 1_000_000)
  assert.equal(CURSOR_MODELS.find((model) => model.id === 'gemini-4-argon').maxTokens, 64_000)
  assert.equal(CURSOR_MODELS.find((model) => model.id === 'gpt-5.6-sol').contextWindow, 272_000)
  assert.equal(CURSOR_MODELS.find((model) => model.id === 'claude-fable-5-1').maxTokens, 128_000)
  const catalog = catalogProviders({ prefix: 'oauth', origin: 'http://x' })
  assert.equal(catalog['oauth-cursor'].models.length, CURSOR_MODELS.length)
  assert.equal(catalog['oauth-cursor'].models[0].id, 'composer-2.5')
})

test('cursor picker collapses effort/fast/thinking/max-mode and hides tab internals', () => {
  const rows = toCursorPickerModels([
    { id: 'default', name: 'Auto' },
    { id: 'default-fast', name: 'Auto Fast' },
    { id: 'gpt-5.5-none', name: 'GPT-5.5 272K None' },
    { id: 'gpt-5.5-high-fast', name: 'GPT-5.5 272K High Fast' },
    { id: 'gpt-5.5-1m-extra-high', name: 'GPT-5.5 1M Extra High' },
    { id: 'claude-4.6-opus-max-thinking', name: 'Opus 4.6 1M Max Thinking' },
    { id: 'claude-4.6-opus-high', name: 'Opus 4.6 1M' },
    { id: 'gpt-5.1-codex-max-high-fast', name: 'GPT-5.1 Codex Max High Fast' },
    { id: 'composer-2-fast', name: 'Composer 2 Fast' },
    { id: 'cursor-small', name: 'Tab' },
    { id: 'tab-completion', name: 'Tab completion' },
    { id: 'cursor-chat', name: 'Chat' },
  ])
  const ids = rows.map((row) => row.id)
  assert.equal(ids.includes('default'), false)
  assert.equal(ids.includes('default-fast'), false)
  assert.equal(ids.includes('gpt-5.5'), true)
  assert.equal(ids.includes('gpt-5.5-high-fast'), false)
  assert.equal(ids.includes('gpt-5.5-none'), false)
  assert.equal(ids.includes('gpt-5.5-1m-extra-high'), false)
  assert.equal(ids.includes('claude-4.6-opus-max-thinking'), false)
  assert.equal(ids.includes('gpt-5.1-codex-max-high-fast'), false)
  assert.equal(ids.includes('claude-4.6-opus'), true)
  assert.equal(ids.includes('gpt-5.1-codex-max'), true)
  assert.equal(ids.includes('composer-2'), true)
  assert.equal(ids.includes('gpt-5.5-fast'), true)
  assert.equal(ids.includes('composer-2-fast'), true)
  assert.equal(ids.includes('gpt-5.1-codex-max-fast'), true)
  assert.equal(ids.includes('claude-4.6-opus-fast'), false)
  assert.equal(ids.includes('default-fast'), false)
  assert.equal(rows.find((row) => row.id === 'gpt-5.5-fast').name, 'GPT-5.5 Fast')
  assert.equal(rows.find((row) => row.id === 'composer-2-fast').name, 'Composer 2 Fast')
  assert.equal(ids.filter((id) => id === 'gpt-5.5' || id === 'gpt-5.5-fast').length, 2)
  assert.equal(ids.some((id) => /tab|chat|cursor-small/.test(id)), false)
  assert.equal(isCursorInternalModel('cursor-small', 'Tab'), true)
  assert.equal(cursorPickerFamilyId('gpt-5.5-max-extra-high-fast'), 'gpt-5.5')
  assert.equal(cursorSourceIsFast('gpt-5.5-high-fast'), true)
  assert.equal(cursorSourceIsFast('composer-2-fast'), true)
  assert.equal(cursorSourceIsFast('gpt-5.5-high'), false)
  assert.equal(cursorSourceIsFast('default'), false)
  assert.equal(inferCursorContextWindow('grok-4.5', 'Grok 4.5'), 256_000)
  assert.equal(inferCursorContextWindow('grok-4.6', 'Grok 4.6'), 256_000)
  assert.equal(inferCursorContextWindow('grok-4.7', 'Grok 4.7'), 256_000)
  assert.equal(inferCursorContextWindow('claude-opus-5', 'Claude Opus 5'), 300_000)
  assert.equal(inferCursorContextWindow('claude-fable-5-1', 'Claude Fable 5.1'), 300_000)
  assert.equal(inferCursorMaxOutputTokens('gpt-5.5', 'GPT-5.5'), 128_000)
  assert.equal(inferCursorMaxOutputTokens('claude-sonnet-5', 'Claude Sonnet 5'), 128_000)
  assert.equal(inferCursorMaxOutputTokens('claude-fable-5-1', 'Claude Fable 5.1'), 128_000)

  assert.deepEqual(rows.find((row) => row.id === 'gpt-5.5').reasoningEfforts, CURSOR_REASONING)
  assert.equal(Object.hasOwn(rows.find((row) => row.id === 'gpt-5.5').reasoningEfforts, 'none'), false)
  const described = describeCatalog(catalogProviders({
    prefix: 'oauth',
    origin: 'http://x',
    cursorModels: rows,
  }))
  const cursor = described.find((row) => row.family === 'cursor')
  assert.equal(cursor.models.find((model) => model.id === 'gpt-5.5-fast').fast, true)
  assert.equal(cursor.models.find((model) => model.id === 'gpt-5.5').fast, false)
  assert.equal(cursor.models.find((model) => model.id === 'gpt-5.5-fast').enabled, true)
  const fromAvailable = toCursorPickerModels([], [
    { name: 'composer-2-fast', clientDisplayName: 'Composer 2 Fast' },
    { name: 'kimi-k2.5', clientDisplayName: 'Kimi K2.5' },
  ])
  assert.equal(fromAvailable.some((row) => row.id === 'composer-2-fast'), true)
  assert.equal(fromAvailable.some((row) => row.id === 'kimi-k2.5-fast'), false)
  const nonMax = toCursorPickerModels(
    [{ id: 'grok-4.7', name: 'Grok 4.7', contextWindow: 500_000 }],
    [{ name: 'grok-4.7', contextTokenLimit: 500_000, variants: [
      { isMaxMode: false, parameters: [{ id: 'context', value: '256k' }] },
      { isMaxMode: true, parameters: [{ id: 'context', value: '500k' }] },
    ] }],
  )
  assert.equal(nonMax.find((row) => row.id === 'grok-4.7').contextWindow, 256_000)
})

test('mocked GetUsableModels expands cursor catalog and yaml beyond the static 5', async () => {
  resetCursorCatalogCache()
  const usableSource = [
    { id: 'composer-2', name: 'Composer 2' },
    { id: 'composer-1.5', name: 'Composer 1.5' },
    { id: 'claude-sonnet-5', name: 'Claude Sonnet 5' },
    { id: 'gpt-5.5', name: 'GPT-5.5' },
    { id: 'gpt-5.5-high-fast', name: 'GPT-5.5 272K High Fast' },
    { id: 'grok-4.5', name: 'Grok 4.5' },
    { id: 'default', name: 'Auto' },
    { id: 'claude-4.6-sonnet-medium', name: 'Sonnet 4.6 1M' },
    { id: 'claude-4.6-sonnet-medium-thinking', name: 'Sonnet 4.6 1M Thinking' },
    { id: 'gemini-3.1-pro', name: 'Gemini 3.1 Pro' },
    { id: 'cursor-small', name: 'Tab' },
  ]
  const payload = frameConnect(encodeGetUsableModelsResponse(usableSource))
  const decoded = decodeGetUsableModelsResponse(payload)
  assert.equal(decoded.length, usableSource.length)
  const available = decodeAvailableModelsResponse(encodeAvailableModelsResponse([
    { name: 'kimi-k2.5', clientDisplayName: 'Kimi K2.5', contextTokenLimit: 262_000 },
  ]))
  assert.equal(available[0].name, 'kimi-k2.5')
  assert.equal(encodeAvailableModelsRequest().length > 0, true)
  const session = cursorSession({
    accessToken: validAccess('live@x'),
    refreshToken: 'rt-live',
    source: 'pkce',
  })
  const models = await refreshCursorCatalog(session, {
    fetchUsable: async () => decoded,
    fetchAvailable: async () => available,
  })
  assert.equal(models.some((model) => model.id === 'default'), false)
  assert.equal(models.some((model) => model.id === 'claude-4.6-sonnet'), true)
  assert.equal(models.some((model) => model.id === 'gemini-3.1-pro'), true)
  assert.equal(models.some((model) => model.id === 'kimi-k2.5'), true)
  assert.equal(models.some((model) => model.id === 'cursor-small'), false)
  // Non-empty live is trusted: retired static models are not force-added.
  assert.equal(models.some((model) => model.id === 'composer-2.5'), false)
  assert.equal(models.some((model) => model.id === 'grok-4.6'), false)
  assert.deepEqual(cursorCatalogModels().map((model) => model.id), models.map((model) => model.id))
  const catalog = catalogProviders({
    prefix: 'oauth',
    origin: 'http://127.0.0.1:8318',
    cursorModels: models,
  })
  assert.equal(catalog['oauth-cursor'].models.length, models.length)
  assert.equal(models.some((model) => model.id === 'gpt-5.5-fast'), true)
  assert.equal(models.some((model) => model.id === 'gpt-5.5-high-fast'), false)
  assert.equal(models.find((model) => model.id === 'gpt-5.5-fast').name, 'GPT-5.5 Fast')
  const yaml = { providers: {} }
  const result = await syncHarnessModels({
    settings: {
      mutate: async (_target, mutations) => {
        for (const op of mutations) {
          if (op.op === 'unset') delete yaml.providers[op.path[1]]
          if (op.op === 'set') yaml.providers[op.path[1]] = op.value
        }
      },
      get: async () => ({ providers: yaml.providers }),
    },
    prefix: 'oauth',
    origin: 'http://127.0.0.1:8318',
    loggedIn: { cursor: true },
    cursorModels: models,
  })
  const ids = yaml.providers['oauth-cursor'].models.map((model) => model.id)
  assert.deepEqual(ids, catalog['oauth-cursor'].models.map((model) => model.id))
  assert.deepEqual(result.routes.find((row) => row.provider === 'oauth-cursor').models, ids)
  assert.equal(ids.includes('gpt-5.5-fast'), true)
  assert.equal(ids.includes('gpt-5.5-high-fast'), false)
  resetCursorCatalogCache()
})

test('refreshQuota discovery persists live cursor models into settings.yaml', async () => {
  resetCursorCatalogCache()
  const dir = await mkdtemp(join(tmpdir(), 'oauth-cursor-live-'))
  const authPath = join(dir, 'auth.json')
  const session = cursorSession({
    accessToken: validAccess('yaml@x'),
    refreshToken: 'rt-yaml',
    source: 'pkce',
    account: 'yaml@x',
  })
  await saveSession('cursor', session, authPath)
  const yaml = { providers: {} }
  const decoded = decodeGetUsableModelsResponse(encodeGetUsableModelsResponse([
    { id: 'composer-2', name: 'Composer 2' },
    { id: 'composer-1.5', name: 'Composer 1.5' },
    { id: 'claude-sonnet-5', name: 'Claude Sonnet 5' },
    { id: 'gpt-5.5', name: 'GPT-5.5' },
    { id: 'grok-4.5', name: 'Grok 4.5' },
    { id: 'default', name: 'Auto' },
    { id: 'gemini-3.1-pro', name: 'Gemini 3.1 Pro' },
  ]))
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    cursorAutoImport: false,
    cursorDiscover: (live) => refreshCursorCatalog(live, {
      fetchUsable: async () => decoded,
      fetchAvailable: async () => [],
    }),
    settings: {
      mutate: async (_target, mutations) => {
        for (const op of mutations) {
          if (op.op === 'unset') delete yaml.providers[op.path[1]]
          if (op.op === 'set') yaml.providers[op.path[1]] = op.value
        }
      },
      get: async () => ({ providers: yaml.providers }),
    },
    fetchFn: async () => json({
      planUsage: { totalPercentUsed: 44, autoPercentUsed: 51, apiPercentUsed: 0, includedSpend: 40000, limit: 40000 },
      membershipType: 'pro',
      email: 'yaml@x',
    }),
  })
  await controller.refreshQuota('cursor')
  const snap = await controller.snapshot()
  const cursorGroup = snap.catalog.find((row) => row.family === 'cursor')
  assert.equal(cursorGroup.models.some((model) => model.id === 'gemini-3.1-pro'), true)
  assert.equal(cursorGroup.models.some((model) => model.id === 'composer-2.5'), false)
  const ids = yaml.providers['oauth-cursor'].models.map((model) => model.id)
  assert.deepEqual(ids, cursorGroup.models.map((model) => model.id))
  const enabled = await controller.setModels({ key: 'oauth-cursor/gemini-3.1-pro', on: true })
  assert.equal(enabled.catalog.find((row) => row.family === 'cursor').models.find((model) => model.id === 'gemini-3.1-pro').enabled, true)
  assert.equal(yaml.providers['oauth-cursor'].models.some((model) => model.id === 'gemini-3.1-pro'), true)
  resetCursorCatalogCache()
})

test('empty GetUsableModels keeps the static floor and does not invent Fast', async () => {
  resetCursorCatalogCache()
  const session = cursorSession({
    accessToken: validAccess('empty@x'),
    refreshToken: 'rt-empty',
    source: 'pkce',
  })
  const models = await refreshCursorCatalog(session, {
    fetchUsable: async () => [],
    fetchAvailable: async () => [],
  })
  assert.equal(models.length, CURSOR_MODELS.length)
  assert.deepEqual(models.map((model) => model.id), CURSOR_MODELS.map((model) => model.id))
  assert.equal(models.some((model) => String(model.id).endsWith('-fast')), false)
  const catalog = catalogProviders({ prefix: 'oauth', origin: 'http://x' })
  assert.equal(catalog['oauth-cursor'].models.length, CURSOR_MODELS.length)
  assert.equal(catalog['oauth-cursor'].models.some((model) => String(model.id).endsWith('-fast')), false)
  resetCursorCatalogCache()
})

test('non-empty GetUsableModels is trusted: retired static models are not re-added', async () => {
  resetCursorCatalogCache()
  const session = cursorSession({
    accessToken: validAccess('stale@x'),
    refreshToken: 'rt-stale',
    source: 'pkce',
  })
  const live = toCursorPickerModels([
    { id: 'composer-2', name: 'Composer 2' },
    { id: 'composer-1.5', name: 'Composer 1.5' },
    { id: 'claude-sonnet-5', name: 'Claude Sonnet 5' },
    { id: 'gpt-5.5', name: 'GPT-5.5' },
    { id: 'grok-4.5', name: 'Grok 4.5' },
  ])
  assert.equal(live.length, 5)
  const merged = mergeCursorStaticFloor(live)
  assert.deepEqual(merged.map((model) => model.id), live.map((model) => model.id))
  assert.equal(merged.some((model) => model.id === 'composer-2.5'), false)
  assert.equal(merged.some((model) => model.id === 'grok-4.6'), false)
  const models = await refreshCursorCatalog(session, {
    fetchUsable: async () => live,
    fetchAvailable: async () => [],
  })
  assert.deepEqual(models.map((model) => model.id), live.map((model) => model.id))
  resetCursorCatalogCache()
})

test('consumeCursorFrames surfaces the Connect error detail, not the bare "Error"', () => {
  const endFrame = frameConnect(Buffer.from(JSON.stringify({
    error: {
      code: 'invalid_argument',
      message: 'Error',
      details: [{
        type: 'aiserver.v1.ErrorDetails',
        debug: {
          error: 'ERROR_MODEL_NO_LONGER_SUPPORTED',
          details: {
            title: 'Composer 2 is retired',
            detail: "We're upgrading you to Composer 2.5, our most powerful model yet.",
          },
        },
      }],
    },
  })), true)
  const messages = []
  consumeCursorFrames(endFrame, Buffer.alloc(0), (msg) => messages.push(msg))
  assert.equal(messages.length, 1)
  assert.equal(messages[0].kind, 'error')
  assert.equal(messages[0].message, "Composer 2 is retired: We're upgrading you to Composer 2.5, our most powerful model yet.")
})

test('cursor hop replays a completed tool turn and continues with the tool output', () => {
  resetCursorSystemPins()
  const built = openaiToCursor({
    model: 'composer-2',
    session_id: 'sess-tool-resume',
    messages: [
      { role: 'system', content: 'You are DSH.' },
      { role: 'user', content: 'add 2+3' },
      {
        role: 'assistant',
        content: '',
        tool_calls: [{ id: 'call-1', type: 'function', function: { name: 'run_code', arguments: '{"code":"2+3"}' } }],
      },
      { role: 'tool', tool_call_id: 'call-1', content: '5' },
    ],
    tools: [{ type: 'function', function: { name: 'run_code', description: 'run', parameters: { type: 'object' } } }],
  })
  const decoded = decodeAgentClientMessage(built.requestBytes)
  // Every call has its result in the history; the turn goes on with a nudge, not the raw result.
  assert.equal(decoded.userText, 'Continue.')
  assert.deepEqual(rootMessages(built, decoded).slice(1), [
    { role: 'user', content: [{ type: 'text', text: 'add 2+3' }] },
    { role: 'assistant', content: [{ type: 'tool-call', toolCallId: 'call-1', toolName: 'CallDynamicTool', args: { namespace: 'dsh', toolName: 'run_code', arguments: { code: '2+3' } } }] },
    { role: 'tool', content: [{ type: 'tool-result', toolCallId: 'call-1', toolName: 'CallDynamicTool', result: 5, experimental_content: [{ type: 'text', text: '5' }] }] },
  ])
  resetCursorSystemPins()
})

/** The state's root messages in order, read back through the blob store: what Cursor is shown as the conversation. */
function rootMessages(built, decoded) {
  return decoded.rootBlobIds.map((id) => JSON.parse(built.blobStore.get(id).toString('utf8')))
}

test('cursor hop sends earlier turns as JSON messages in the state, so a later turn knows them', () => {
  // Live 2026-09-29: the protobuf turn history was ignored — turn 2 did not know turn 1's code word.
  resetCursorSystemPins()
  const built = openaiToCursor({
    model: 'composer-2',
    session_id: 'sess-history',
    messages: [
      { role: 'system', content: 'You are DSH.' },
      { role: 'user', content: 'code word: PELICAN' },
      { role: 'assistant', content: 'noted' },
      { role: 'user', content: 'what was the code word?' },
    ],
  })
  const decoded = decodeAgentClientMessage(built.requestBytes)
  assert.equal(decoded.userText, 'what was the code word?')
  assert.deepEqual(rootMessages(built, decoded), [
    { role: 'system', content: 'You are DSH.' },
    { role: 'user', content: [{ type: 'text', text: 'code word: PELICAN' }] },
    { role: 'assistant', content: [{ type: 'text', text: 'noted' }] },
  ])
  resetCursorSystemPins()
})

test('cursor hop sends data: images as JSON image parts, the latest image-bearing turn only (live: red / blue read back)', () => {
  resetCursorSystemPins()
  const image = (url) => ({ type: 'image_url', image_url: { url } })
  const older = 'data:image/png;base64,AAEC' // bytes 00 01 02
  const latest = 'data:image/jpeg;base64,/9j/' // bytes ff d8 ff
  const built = openaiToCursor({
    model: 'composer-2',
    session_id: 'sess-image',
    messages: [
      { role: 'user', content: [{ type: 'text', text: 'first picture' }, image(older)] },
      { role: 'assistant', content: 'a bar' },
      { role: 'user', content: [{ type: 'text', text: 'and this one?' }, image(latest), image('https://example.com/x.png')] },
    ],
  })
  const decoded = decodeAgentClientMessage(built.requestBytes)
  assert.equal(decoded.userText, 'and this one?')
  assert.deepEqual(rootMessages(built, decoded), [
    { role: 'user', content: [{ type: 'text', text: 'first picture' }] },
    { role: 'assistant', content: [{ type: 'text', text: 'a bar' }] },
    { role: 'user', content: [
      { type: 'text', text: 'and this one?' },
      { type: 'image', mimeType: 'image/jpeg', image: { __type: 'Uint8Array', hex: 'ffd8ff' } },
    ] },
  ])
  resetCursorSystemPins()
})

test('cursor hop answers a tool call the caller never resolved, and batches parallel results into one tool message', () => {
  resetCursorSystemPins()
  const call = (id, name) => ({ id, type: 'function', function: { name, arguments: '{}' } })
  const built = openaiToCursor({
    model: 'composer-2',
    session_id: 'sess-parallel',
    messages: [
      { role: 'user', content: 'go' },
      { role: 'assistant', content: '', tool_calls: [call('a', 'one'), call('b', 'two'), call('c', 'three')] },
      { role: 'tool', tool_call_id: 'a', content: 'first' },
      { role: 'tool', tool_call_id: 'b', content: '{"n":2}' },
      { role: 'user', content: 'never mind, next question' },
    ],
  })
  const decoded = decodeAgentClientMessage(built.requestBytes)
  assert.equal(decoded.userText, 'never mind, next question')
  const messages = rootMessages(built, decoded)
  assert.deepEqual(messages.map((message) => message.role), ['user', 'assistant', 'tool'])
  const results = messages[2].content
  assert.deepEqual(results.map((row) => [row.toolCallId, row.result, row.isError ?? false]), [
    ['a', 'first', false],
    ['b', { n: 2 }, false],
    ['c', 'Tool use was interrupted and did not produce a result.', true],
  ])
  resetCursorSystemPins()
})



test('warmCatalogs discovers the live cursor catalog at startup and re-syncs', async () => {
  resetCursorCatalogCache()
  const dir = await mkdtemp(join(tmpdir(), 'oauth-cursor-warm-'))
  const authPath = join(dir, 'auth.json')
  const session = cursorSession({
    accessToken: validAccess('warm@x'),
    refreshToken: 'rt-warm',
    source: 'pkce',
    account: 'warm@x',
  })
  await saveSession('cursor', session, authPath)
  const yaml = { providers: {} }
  const decoded = decodeGetUsableModelsResponse(encodeGetUsableModelsResponse([
    { id: 'default', name: 'Auto' },
    { id: 'kimi-k3', name: 'Kimi K3' },
    { id: 'glm-5.2-max', name: 'GLM 5.2 Max' },
  ]))
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    cursorAutoImport: false,
    cursorDiscover: (live) => refreshCursorCatalog(live, {
      fetchUsable: async () => decoded,
      fetchAvailable: async () => [],
    }),
    settings: {
      mutate: async (_target, mutations) => {
        for (const op of mutations) {
          if (op.op === 'unset') delete yaml.providers[op.path[1]]
          if (op.op === 'set') yaml.providers[op.path[1]] = op.value
        }
      },
      get: async () => ({ providers: yaml.providers }),
    },
  })
  await controller.warmCatalogs()
  const ids = (yaml.providers['oauth-cursor']?.models ?? []).map((model) => model.id)
  assert.deepEqual(ids, ['glm-5.2', 'kimi-k3'])
  resetCursorCatalogCache()
})

test('cursor catalog cache is keyed on the upstream proxy egress', async () => {
  const { configureCursorUpstreamProxy } = await import('../lib/oauth/cursor/index.js')
  resetCursorCatalogCache()
  configureCursorUpstreamProxy(undefined)
  const session = cursorSession({
    accessToken: validAccess('egress@x'),
    refreshToken: 'rt-egress',
    source: 'pkce',
  })
  let fetches = 0
  const fetchUsable = async () => {
    fetches += 1
    return decodeGetUsableModelsResponse(encodeGetUsableModelsResponse([{ id: 'kimi-k3', name: 'Kimi K3' }]))
  }
  const options = { fetchUsable, fetchAvailable: async () => [], ttlMs: 60_000 }
  await refreshCursorCatalog(session, options)
  await refreshCursorCatalog(session, options)
  assert.equal(fetches, 1)
  configureCursorUpstreamProxy('http://127.0.0.1:8080')
  await refreshCursorCatalog(session, options)
  assert.equal(fetches, 2)
  configureCursorUpstreamProxy(undefined)
  resetCursorCatalogCache()
})

test('a cursor cache hit restores that account parameter styles', async () => {
  resetCursorCatalogCache()
  const now = 1_700_000_000_000
  let fetches = 0
  const refresh = (token, family, paramId, value) => {
    let pending
    const read = () => {
      pending ??= Promise.resolve().then(() => {
        fetches += 1
      })
      return pending
    }
    return refreshCursorCatalog({ accessToken: token }, {
      now,
      ttlMs: CURSOR_CATALOG_TTL_MS,
      fetchUsable: async () => {
        await read()
        return [{ id: family, name: family }]
      },
      fetchAvailable: async () => {
        await read()
        return [{ name: family, variants: [{ parameters: [{ id: paramId, value }] }] }]
      },
    })
  }
  await refresh('cursor-style-account-a', 'composer-2', 'reasoning', 'high')
  assert.equal(cursorCatalogModels().some((model) => model.id === 'composer-2'), true)
  assert.ok(cursorModelParameters({ model: 'composer-2', reasoning_effort: 'high' }).some((row) => row.id === 'reasoning' && row.value === 'high'))
  const afterA = fetches
  await refresh('cursor-style-account-b', 'gpt-5.6-sol', 'effort', 'low')
  assert.equal(fetches, afterA + 1)
  assert.equal(cursorCatalogModels().some((model) => model.id === 'gpt-5.6-sol'), true)
  assert.deepEqual(cursorModelParameters({ model: 'composer-2', reasoning_effort: 'high' }), [])
  assert.deepEqual(cursorModelParameters({ model: 'gpt-5.6-sol', reasoning_effort: 'low' }), [{ id: 'effort', value: 'low' }])
  const beforeReturn = fetches
  await refresh('cursor-style-account-a', 'composer-2', 'reasoning', 'high')
  assert.equal(fetches, beforeReturn, 'refreshing A inside the TTL does not fetch models again')
  assert.equal(cursorCatalogModels().some((model) => model.id === 'composer-2'), true)
  assert.equal(cursorCatalogModels().some((model) => model.id === 'gpt-5.6-sol'), false)
  assert.ok(cursorModelParameters({ model: 'composer-2', reasoning_effort: 'high' }).some((row) => row.id === 'reasoning' && row.value === 'high'))
  const sol = cursorModelParameters({ model: 'gpt-5.6-sol', reasoning_effort: 'low' })
  assert.equal(sol.some((row) => row.id === 'effort'), false)
  assert.equal(sol.some((row) => row.id === 'reasoning' && row.value === 'low'), true)
  resetCursorCatalogCache()
})

test('cursor catalog refresh keeps publish order, egress identity, and the real TTL', async () => {
  await exerciseLiveCatalog({
    label: 'cursor',
    ttlMs: CURSOR_CATALOG_TTL_MS,
    dropStaticId: CURSOR_MODELS[0].id,
    reset: resetCursorCatalogCache,
    models: cursorCatalogModels,
    refresh: ({ token, now, ttlMs, fetch }) => {
      let pending
      const read = () => {
        pending ??= fetch()
        return pending
      }
      return refreshCursorCatalog({ accessToken: token }, {
        now,
        ttlMs,
        fetchUsable: async () => {
          const kind = await read()
          if (kind === 'fail' || kind === 'empty') return []
          return [{ id: kind === 'a' ? 'live-only-a' : 'live-only-b', name: kind === 'a' ? 'A' : 'B' }]
        },
        fetchAvailable: async () => {
          await read()
          return []
        },
      })
    },
  })
})
