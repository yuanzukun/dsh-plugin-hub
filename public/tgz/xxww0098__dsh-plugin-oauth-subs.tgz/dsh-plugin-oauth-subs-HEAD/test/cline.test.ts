import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { isPermanentRefreshFailure } from '../lib/oauth/tokens.js'
import { AuthController } from '../lib/oauth/controller.js'
import { accountIdOf, publicSession, saveSession, listStoredSessions } from '../lib/oauth/store.js'
import {
  HARNESS_COMPLETIONS_API,
  assertDshServiceableProvider,
  buildProviders,
  catalogProviders,
  familyOfProvider,
  ownedProviderIds,
} from '../lib/oauth/models.js'
import {
  CLINE_ACCESS_TOKEN_PREFIX,
  CLINE_API_BASE,
  CLINE_CHAT_URL,
  CLINE_CLIENT_TYPE,
  CLINE_CORE_VERSION,
  CLINE_MODELS,
  CLINE_MODELS_URL,
  CLINE_REASONING,
  CLINE_REFRESH_URL,
  CLINE_REGISTER_URL,
  CLINE_USER_AGENT,
  CLINE_WORKOS_AUTHENTICATE_URL,
  CLINE_WORKOS_CLIENT_ID,
  CLINE_WORKOS_DEVICE_URL,
  clineDefaultAccount,
  clineSessionFromAuthData,
  formatClineAccessToken,
  normalizeClineAccessToken,
} from '../lib/oauth/cline/index.js'
import {
  CLINE_SESSION_HEADER,
  clineEngineAuthorize,
  clineEngineFetch,
  clineEngineHeaders,
  fetchClineQuotaEngine,
  refreshClineEngine,
  resetClineEnginePlugin,
  sessionFromEngineResult,
} from '../lib/oauth/cline/engine.js'
import { ImportedLoginStale } from '../lib/oauth/tokens.js'
import { CLINE_IMPORT_EMPTY, clineSessionFromProvidersFile, importClineAuth } from '../lib/oauth/cline/import.js'
import { applyClineCache, clineCacheSessionId, resetClinePins } from '../lib/oauth/cline/cache.js'
import { applyClineMaxCompletionTokens, applyClineStreamUsage, applyClineThinking, clineQuotaFailure, mapClineUsage, unwrapClineEnvelope } from '../lib/oauth/cline/request.js'
import { UpstreamFailure } from '../lib/oauth/upstream.js'
import { CLINE_CATALOG_TTL_MS, clineCatalogModels, refreshClineCatalog, resetClineCatalogCache, toClinePickerModels } from '../lib/oauth/cline/catalog.js'
import { exerciseLiveCatalog } from './catalog-lifecycle.ts'
import { configureUpstreamEngine, resetUpstreamEngineCache } from '../lib/upstream-engine/engine.js'
import { configureEngineBridge, resetEngineBridge } from '../lib/upstream-engine/bridge.js'
import { CLINE_FIXTURE_MODULE, CLINE_FIXTURE_NPM, CLINE_FIXTURE_VERSION, writeEngineCache } from './upstream-engine-fixture.ts'
import { createProxy } from '../lib/oauth/proxy.js'

function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })
}

/** The engine lane under a tmp data dir, its global fetch bridge-routed. */
async function withEngine(t, fetchFn) {
  const dataDir = await mkdtemp(join(tmpdir(), 'cline-engine-'))
  t.after(() => rm(dataDir, { recursive: true, force: true }))
  await writeEngineCache(dataDir, {
    npm: CLINE_FIXTURE_NPM,
    version: CLINE_FIXTURE_VERSION,
    module: CLINE_FIXTURE_MODULE,
    engines: { cline: { npm: CLINE_FIXTURE_NPM, version: CLINE_FIXTURE_VERSION, integrity: 'sha512-fixture' } },
  })
  resetUpstreamEngineCache()
  resetClineEnginePlugin()
  configureUpstreamEngine(join(dataDir, 'auth.json'))
  configureEngineBridge({ fetchFn })
  t.after(() => {
    resetUpstreamEngineCache()
    resetClineEnginePlugin()
    resetEngineBridge()
    configureUpstreamEngine(undefined)
  })
  return dataDir
}

/**
 * The engine's X-Task-ID: sha256('cline task\0' + session) forced into a v4
 * UUID shape (fixture mirrors index.mjs taskIdOf — asserted against the wire).
 */
function taskIdOf(session: string) {
  const bytes = createHash('sha256').update('cline task\0').update(session).digest().subarray(0, 16)
  const b = Buffer.from(bytes)
  b[6] = (b[6] & 0x0f) | 0x40
  b[8] = (b[8] & 0x3f) | 0x80
  const h = b.toString('hex')
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`
}

function adaSession(overrides: Record<string, unknown> = {}) {
  return clineSessionFromAuthData({
    accessToken: 'jwt-a',
    refreshToken: 'ref-a',
    tokenType: 'Bearer',
    expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    userInfo: { subject: 'user_1', email: 'ada@example.com', name: 'Ada', clineUserId: 'usr-01ABC', accounts: null },
  }, {}, overrides)
}

// ---- 登录 ---------------------------------------------------------------------

test('device login drives the engine: WorkOS device start, poll, register exchange', { timeout: 20_000 }, async (t) => {
  const calls = []
  const fetchFn = async (url, init = {}) => {
    const href = String(url)
    calls.push({ url: href, body: String(init.body ?? '') })
    if (href === CLINE_WORKOS_DEVICE_URL) {
      return json({
        device_code: 'dev-code',
        user_code: 'WDJB-MJHT',
        verification_uri: 'https://api.workos.com/device',
        verification_uri_complete: 'https://api.workos.com/device?user_code=WDJB-MJHT',
        interval: 0.01,
        expires_in: 30,
      })
    }
    if (href === CLINE_WORKOS_AUTHENTICATE_URL) {
      return json({ access_token: 'workos-access-raw', refresh_token: 'workos-refresh', token_type: 'Bearer', expires_in: 3600 })
    }
    if (href === CLINE_REGISTER_URL) {
      return json({
        success: true,
        data: {
          accessToken: 'workos-access-raw',
          refreshToken: 'workos-refresh',
          tokenType: 'Bearer',
          expiresAt: new Date(Date.now() + 3600_000).toISOString(),
          userInfo: { subject: 'user_1', email: 'ada@example.com', name: 'Ada', clineUserId: 'usr-01ABC', accounts: null },
        },
      })
    }
    return json({}, 404)
  }
  await withEngine(t, fetchFn)
  const engine = await clineEngineAuthorize({ fetchFn })
  assert.equal(engine.authorizeUrl, 'https://api.workos.com/device?user_code=WDJB-MJHT')
  assert.equal(engine.mode, 'device')
  // The register exchange runs inside the engine's callback: settle IS the
  // finished session (no second hop for accounts.ts to drive).
  const session = await engine.settle()
  assert.equal(session.accessToken, 'workos:workos-access-raw')
  assert.equal(session.refreshToken, 'workos-refresh')
  assert.equal(session.account, 'ada@example.com')
  assert.equal(session.uid, 'usr-01ABC')
  assert.equal(session.source, 'oauth')
  // WorkOS speaks form encoding with the official client id (index.mjs:236-246).
  const deviceCall = calls.find((row) => row.url === CLINE_WORKOS_DEVICE_URL)
  assert.equal(deviceCall.body, `client_id=${CLINE_WORKOS_CLIENT_ID}`)
  const pollCall = calls.find((row) => row.url === CLINE_WORKOS_AUTHENTICATE_URL)
  assert.match(pollCall.body, /grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Adevice_code/)
  assert.match(pollCall.body, /device_code=dev-code/)
  const registerCall = calls.find((row) => row.url === CLINE_REGISTER_URL)
  assert.deepEqual(JSON.parse(registerCall.body), { accessToken: 'workos-access-raw', refreshToken: 'workos-refresh' })
})

test('access token carries the workos: prefix exactly once', () => {
  assert.equal(formatClineAccessToken('jwt'), 'workos:jwt')
  assert.equal(formatClineAccessToken('workos:jwt'), 'workos:jwt')
  assert.equal(normalizeClineAccessToken('workos:jwt'), 'jwt')
  assert.equal(normalizeClineAccessToken('jwt'), 'jwt')
  assert.equal(CLINE_ACCESS_TOKEN_PREFIX, 'workos:')
})

test('session round-trip keeps the prefix and never leaks the token', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'cline-store-'))
  const authPath = join(dir, 'auth.json')
  const session = adaSession()
  await saveSession('cline', session, authPath)
  const rows = await listStoredSessions('cline', authPath)
  assert.equal(rows.length, 1)
  assert.equal(rows[0].id, 'ada@example.com')
  const pub = publicSession('cline', session)
  assert.equal(pub.account, 'ada@example.com')
  assert.equal(pub.methodLabel, 'OAuth')
  assert.equal(JSON.stringify(pub).includes('jwt-a'), false)
  assert.equal(accountIdOf('cline', session), 'ada@example.com')
})

// ---- 刷新 ---------------------------------------------------------------------

test('the engine refresh posts the grant and lands the rotated pair', async (t) => {
  const refreshCalls = []
  const fetchFn = async (url, init = {}) => {
    refreshCalls.push({ url: String(url), body: JSON.parse(String(init.body)) })
    return json({
      success: true,
      data: {
        accessToken: 'jwt-b',
        refreshToken: 'ref-b',
        tokenType: 'Bearer',
        expiresAt: new Date(Date.now() + 7200_000).toISOString(),
        userInfo: { subject: 'user_1', email: 'ada@example.com', name: 'Ada', clineUserId: 'usr-01ABC', accounts: null },
      },
    })
  }
  await withEngine(t, fetchFn)
  const refreshed = await refreshClineEngine(adaSession(), fetchFn)
  assert.equal(refreshCalls[0].url, CLINE_REFRESH_URL)
  assert.deepEqual(refreshCalls[0].body, { refreshToken: 'ref-a', grantType: 'refresh_token' })
  assert.equal(refreshed.accessToken, 'workos:jwt-b')
  assert.equal(refreshed.refreshToken, 'ref-b')
  assert.ok(refreshed.expiresAt > Date.now())
  assert.equal(refreshed.account, 'ada@example.com')
})

test('every call redeems: the engine holds per-token chains, not one pair', async (t) => {
  // A stored session that already carries the rotated pair must exchange for
  // real: the engine keys its holds by the refresh token spent, so a second
  // call offering the NEW pair (the manager persisted the first answer)
  // spends that one — one wire request per call.
  let calls = 0
  const fetchFn = async () => {
    calls += 1
    return json({
      success: true,
      data: {
        accessToken: `jwt-rot-${calls + 1}`,
        refreshToken: `ref-rot-${calls + 1}`,
        expiresAt: new Date(Date.now() + 3600_000).toISOString(),
      },
    })
  }
  await withEngine(t, fetchFn)
  const session = clineSessionFromAuthData({
    accessToken: 'jwt-rot',
    refreshToken: 'ref-rot-1',
    expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    userInfo: { email: 'ada@example.com', clineUserId: 'usr-01ABC' },
  }, {})
  const first = await refreshClineEngine(session, fetchFn)
  // The manager persisted it; by now its access token has aged out.
  const aged = { ...first, expiresAt: Date.now() - 60_000 }
  const second = await refreshClineEngine(aged, fetchFn)
  assert.equal(calls, 2)
  assert.equal(second.accessToken, 'workos:jwt-rot-3')
  assert.equal(second.refreshToken, 'ref-rot-3')
  assert.ok(second.expiresAt > Date.now())
})

test('refresh rejection follows the engine verdict: lapsed is permanent, vendor words stay transient', async (t) => {
  const answers = [
    json({ error: 'Unauthorized' }, 401),
    json({ success: false, error: 'invalid refresh token' }),
    json({ error: 'boom' }, 500),
  ]
  let n = 0
  const fetchFn = async () => answers[n++]
  await withEngine(t, fetchFn)
  const unauthorized = await refreshClineEngine(adaSession(), fetchFn).catch((error) => error)
  assert.equal(isPermanentRefreshFailure(unauthorized), true)
  // A success:false refusal is not the engine's Lapsed verdict — the token in
  // hand rides on and the exchange is retried later (index.mjs fresh's grace).
  const rejected = await refreshClineEngine(adaSession(), fetchFn).catch((error) => error)
  assert.equal(isPermanentRefreshFailure(rejected), false)
  const transient = await refreshClineEngine(adaSession(), fetchFn).catch((error) => error)
  assert.equal(isPermanentRefreshFailure(transient), false)
})

test('a 400 "failed to refresh token: invalid_grant" is a permanent rejection', async (t) => {
  // api.cline.bot answers exactly this for a dead grant (live-probed
  // 2026-10-11). The engine's lapsed test ([400,401,403] + the refusal
  // words) catches it; the adapter normalizes the death to a 401
  // invalid_grant so the row is reaped. Any other 400 stays transient.
  const answers = [
    json({ data: '', error: 'failed to refresh token: invalid_grant', success: false }, 400),
    json({ error: 'malformed request' }, 400),
  ]
  let n = 0
  const fetchFn = async () => answers[n++]
  await withEngine(t, fetchFn)
  const session = clineSessionFromAuthData({
    accessToken: 'jwt-a',
    refreshToken: 'ref-dead',
    expiresAt: new Date(Date.now() - 1000).toISOString(),
    userInfo: { email: 'ada@example.com', clineUserId: 'usr-01ABC' },
  }, {})
  const dead = await refreshClineEngine(session, fetchFn).catch((error) => error)
  assert.equal(isPermanentRefreshFailure(dead), true)
  assert.equal(dead.status, 401)
  assert.match(dead.message, /invalid_grant/)
  // Any other 400 without a dead-grant verdict stays transient.
  const unrelated = await refreshClineEngine(session, fetchFn).catch((error) => error)
  assert.equal(isPermanentRefreshFailure(unrelated), false)
})

// ---- 目录 ---------------------------------------------------------------------

test('catalog is Completions at /cline with declared effort keys only', () => {
  const providers = buildProviders({
    prefix: 'oauth',
    origin: 'http://127.0.0.1:8318',
    loggedIn: { cline: true },
    clineModels: CLINE_MODELS,
  })
  const route = providers['oauth-cline']
  assert.equal(route.api, HARNESS_COMPLETIONS_API)
  assert.equal(route.baseURL, 'http://127.0.0.1:8318/cline')
  assert.equal(route.compat.supportsReasoningEffort, true)
  assert.equal(route.compat.thinkingFormat, 'openai')
  assert.equal(route.models.length, CLINE_MODELS.length)
  for (const model of route.models) {
    assert.ok(model.contextWindow > 0)
    assert.ok(model.maxTokens > 0)
    assert.ok(model.name)
    const efforts = model.reasoningEfforts
    if (efforts && typeof efforts === 'object') {
      for (const key of Object.keys(efforts)) {
        assert.ok(['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'].includes(key))
      }
    }
    assert.equal(model.input.every((part) => part === 'text' || part === 'image'), true)
  }
  assert.equal(familyOfProvider('oauth-cline'), 'cline')
  assert.ok(ownedProviderIds('oauth').includes('oauth-cline'))
  assert.equal(catalogProviders({ prefix: 'oauth', origin: 'http://x', clineModels: CLINE_MODELS })['oauth-cline'].models.length, CLINE_MODELS.length)
  assert.equal(CLINE_REASONING.off, undefined)
  assert.equal(CLINE_REASONING.max, 'xhigh')
})

test('live catalog merges recommended + free + clinePass and takes cloud-catalog facts', async () => {
  resetClineCatalogCache()
  const grok = CLINE_MODELS.find((model) => model.id === 'x-ai/grok-4.7')
  assert.equal(grok.contextWindow, 500_000)
  assert.equal(grok.maxTokens, 450_000)
  assert.deepEqual(grok.input, ['text', 'image'])
  // 2026-10-17: the free Step 5 row was retired (live 404) and the free bucket
  // swapped in Nemotron 3.5 Super VL. Its total window is 1M, but the servable
  // tier the source reports is top_provider.context_length 262144, so the row
  // pins that and hangs the total on maxContextWindow.
  assert.equal(CLINE_MODELS.find((model) => model.id === 'cline-free/step-5-preview'), undefined)
  const nemotron = CLINE_MODELS.find((model) => model.id === 'cline-free/nemotron-3.5-super-vl')
  assert.equal(nemotron.name, 'Nemotron 3.5 Super VL (free)')
  assert.equal(nemotron.contextWindow, 262_144)
  assert.equal(nemotron.maxContextWindow, 1_048_576)
  assert.equal(nemotron.maxTokens, 235_929)
  assert.deepEqual(nemotron.input, ['text', 'image'])
  assert.equal(nemotron.reasoningEfforts, false)
  const feed = {
    recommended: [{ id: 'anthropic/claude-opus-5.5', name: 'claude-opus-5.5' }, { id: 'new/lab-model', name: 'lab-model' }],
    free: [{ id: 'cline-free/mimo-v2.6-flash', name: 'Mimo V2.6 Flash' }, { id: 'cline-free/twin', name: 'cline-free/twin' }],
    clinePass: [{ id: 'cline-pass/glm-5.3', name: 'cline-pass/glm-5.3' }, { id: 'cline-free/mimo-v2.6-flash', name: 'ignored' }],
    clineCloud: [{ id: 'cline-cloud/deepseek-v4.1-flash', name: 'DeepSeek V4.1 Flash' }],
  }
  const cloud = {
    data: [
      { id: 'anthropic/claude-opus-5.5', name: 'Anthropic: Claude Opus 5.5', context_length: 1_000_000, context: 0, top_provider: { max_completion_tokens: 128_000 }, architecture: { input_modalities: ['text', 'image', 'file'] }, supported_parameters: ['reasoning_effort'] },
      { id: 'xiaomi/mimo-v2.6-flash', name: 'Xiaomi: MiMo-V2.6-Flash', context_length: 1_050_000, top_provider: { max_completion_tokens: 131_072 }, architecture: { input_modalities: ['text', 'image', 'audio'] }, supported_parameters: ['reasoning'] },
      { id: 'z-ai/glm-5.3', name: 'Z.ai: GLM 5.3', context_length: 1_048_576, top_provider: { max_completion_tokens: 943_718 }, architecture: { input_modalities: ['text'] }, supported_parameters: ['reasoning_effort'] },
      { id: 'vendor-a/twin', name: 'Vendor A Twin', context_length: 11, top_provider: { max_completion_tokens: 11 }, architecture: { input_modalities: ['text'] }, supported_parameters: [] },
      { id: 'vendor-b/twin', name: 'Vendor B Twin', context_length: 22, top_provider: { max_completion_tokens: 22 }, architecture: { input_modalities: ['text'] }, supported_parameters: [] },
      { id: 'x-ai/grok-4.7', name: 'SpaceXAI: Grok 4.7', context_length: 500_000, top_provider: { max_completion_tokens: 450_000 }, architecture: { input_modalities: ['text', 'image'] }, supported_parameters: ['reasoning_effort'] },
    ],
  }
  const merged = toClinePickerModels(feed, { models: [], cloud })
  assert.deepEqual(merged.map((model) => model.id), [
    'anthropic/claude-opus-5.5', 'new/lab-model', 'cline-free/mimo-v2.6-flash', 'cline-free/twin', 'cline-pass/glm-5.3',
  ])
  assert.equal(merged[0].name, 'Claude Opus 5.5')
  assert.equal(merged[0].contextWindow, 1_000_000)
  assert.equal(merged[0].maxTokens, 128_000)
  assert.deepEqual(merged[0].input, ['text', 'image'])
  assert.equal(merged[0].reasoningEfforts.max, 'xhigh')
  assert.equal(merged[1].name, 'Lab Model')
  assert.equal(merged[1].contextWindow, 128_000)
  assert.equal(merged[1].maxTokens, 8_192)
  assert.equal(merged[2].name, 'MiMo-V2.6-Flash (free)')
  assert.equal(merged[2].contextWindow, 1_050_000)
  assert.equal(merged[2].reasoningEfforts, false)
  assert.equal(merged[3].contextWindow, 128_000, 'an ambiguous slug must not borrow either vendor window')
  assert.equal(merged[4].name, 'GLM 5.3 (ClinePass)')
  assert.equal(merged[4].contextWindow, 1_048_576)
  assert.deepEqual(merged[4].input, ['text'])
  const notStolen = toClinePickerModels(
    { recommended: [{ id: 'spacexai/grok-4.7', name: 'spacexai/grok-4.7' }] },
    { models: [], cloud },
  )
  assert.equal(notStolen[0].contextWindow, 128_000, 'a non-gateway id does not slug-match another vendor')
  const calls = []
  const live = await refreshClineCatalog(null, {
    models: [],
    fetchFn: async (url, init) => {
      calls.push({ url: String(url), headers: init.headers })
      if (String(url) === CLINE_MODELS_URL) return json(cloud)
      return json(feed)
    },
  })
  assert.deepEqual(calls.map((call) => call.url).sort(), [CLINE_MODELS_URL, 'https://api.cline.bot/api/v1/ai/cline/recommended-models'].sort())
  assert.equal(calls[0].headers['user-agent'], CLINE_USER_AGENT)
  assert.equal(calls[0].headers['X-CLIENT-VERSION'], '3.0.70')
  assert.equal(calls[0].headers['X-CORE-VERSION'], CLINE_CORE_VERSION)
  assert.equal(Object.hasOwn(calls[0].headers, 'X-Task-ID'), false)
  assert.equal(live.length, 5)
  assert.equal(clineCatalogModels().length, 5)
  resetClineCatalogCache()
  const failed = await refreshClineCatalog(null, { fetchFn: async () => json({ error: 'nope' }, 500) })
  assert.equal(failed.length, CLINE_MODELS.length)
  assert.equal(CLINE_CATALOG_TTL_MS > 0, true)
})

test('cline caps stop retries and entitlement is not a 403 auth failure', () => {
  const cap = clineQuotaFailure(429, { code: 'INFERENCE_CAP_ERROR', message: 'Error 429: Daily free limit reached on model x' })
  assert.equal(cap.status, 429)
  assert.match(cap.message, /^usage limit reached: /)
  const pass = clineQuotaFailure(429, { error: { message: 'You have reached your ClinePass limit. Please try again later.' } })
  assert.equal(pass.status, 429)
  assert.match(pass.message, /ClinePass limit/)
  const credits = clineQuotaFailure(402, { code: 'insufficient_credits', message: 'insufficient credits' })
  assert.equal(credits.status, 429)
  // The engine hop's failure() (index.mjs 610-613) rewrites 402 /
  // insufficient_credits into this 429 before the classifier runs — the raw
  // 402 shape never arrives on the engine lane, so the rewrite is what must
  // still classify as quota (QUOTA_EXCEEDED, no retry), not a bare 429.
  const spent = clineQuotaFailure(429, {
    error: { message: 'out of credits ($0.50) — top up at https://app.cline.bot/credits', type: 'cline_error', code: 429 },
  })
  assert.ok(spent instanceof UpstreamFailure)
  assert.equal(spent.status, 429)
  assert.equal(spent.code, 'quota')
  assert.match(spent.message, /^usage limit reached: out of credits/)
  const denied = clineQuotaFailure(403, { message: 'the user is not subscribed to required model plan' })
  assert.ok(denied instanceof UpstreamFailure)
  assert.equal(denied.status, 400)
  assert.equal(/\b(?:401|403)\b/.test(denied.message), false)
  assert.equal(clineQuotaFailure(429, { error: { message: 'rate limited' } }), undefined)
  assert.equal(clineQuotaFailure(401, { message: 'the user is not subscribed to required model plan' }), undefined)
})

test('a fact ceiling survives the Cline projection', () => {
  const rows = toClinePickerModels(
    { recommended: [{ id: 'anthropic/claude-opus-5.5', name: 'claude-opus-5.5' }] },
    { models: [{ id: 'anthropic/claude-opus-5.5', contextWindow: 200_000, maxContextWindow: 1_000_000 }] },
  )
  assert.equal(rows[0].contextWindow, 200_000)
  assert.equal(rows[0].maxContextWindow, 1_000_000)
})

// ---- 缓存 ---------------------------------------------------------------------

test('cache strips Codex/Grok fields and pins X-Task-ID, never Date.now', () => {
  resetClinePins()
  const { payload, cacheSessionId } = applyClineCache({
    model: 'anthropic/claude-opus-5.5',
    messages: [{ role: 'system', content: 'sys v1' }, { role: 'user', content: 'hi' }],
    session_id: 'dsh/session 1',
    prompt_cache_key: 'codex-style',
    prompt_cache_retention: '24h',
    prompt_cache_options: { mode: 'explicit' },
  })
  assert.equal(cacheSessionId, 'dsh-session-1')
  assert.equal(payload.session_id, undefined)
  assert.equal(payload.prompt_cache_key, undefined)
  assert.equal(payload.prompt_cache_retention, undefined)
  assert.equal(payload.prompt_cache_options, undefined)
  assert.equal(clineCacheSessionId(undefined), undefined)
  // The engine hop speaks its own session header: a named conversation
  // rides it (the loader derives X-Task-ID from it); the `dsh-cline`
  // fallback is omitted so the engine derives from its own inputs.
  assert.deepEqual(clineEngineHeaders('dsh-session-1'), { accept: 'application/json', [CLINE_SESSION_HEADER]: 'dsh-session-1' })
  assert.deepEqual(clineEngineHeaders('dsh-cline'), { accept: 'application/json' })
  assert.deepEqual(clineEngineHeaders(undefined), { accept: 'application/json' })
})

test('system snapshots park at the suffix so the first system blob keeps hitting', () => {
  resetClinePins()
  const first = applyClineCache({ session_id: 's1', messages: [{ role: 'system', content: 'base' }, { role: 'user', content: 'a' }] })
  const second = applyClineCache({ session_id: 's1', messages: [{ role: 'system', content: 'base\nmore' }, { role: 'user', content: 'a' }] })
  assert.deepEqual(first.payload.messages.map((m) => m.role), ['system', 'user'])
  assert.deepEqual(second.payload.messages, [
    { role: 'system', content: 'base' },
    { role: 'user', content: 'a' },
    { role: 'system', content: 'more' },
  ])
})

test('an incompatible system head re-pins instead of serving the stale prompt', () => {
  resetClinePins()
  // A model switch inside one conversation must not inherit the previous system head.
  const session_id = 'session-cline-repin'
  applyClineCache({ session_id, messages: [{ role: 'system', content: 'model A prompt' }, { role: 'user', content: 'a' }] })
  const second = applyClineCache({ session_id, messages: [{ role: 'system', content: 'model B prompt' }, { role: 'user', content: 'a' }] })
  assert.deepEqual(second.payload.messages, [
    { role: 'system', content: 'model B prompt' },
    { role: 'user', content: 'a' },
  ])
  const third = applyClineCache({ session_id, messages: [{ role: 'system', content: 'model B prompt\nmore' }, { role: 'user', content: 'a' }] })
  assert.deepEqual(third.payload.messages, [
    { role: 'system', content: 'model B prompt' },
    { role: 'user', content: 'a' },
    { role: 'system', content: 'more' },
  ])
})

// ---- 请求整形 -----------------------------------------------------------------

test('completions hop renames max_tokens for reasoning-era ids, asks for usage, maps cache reads', () => {
  assert.deepEqual(
    applyClineMaxCompletionTokens({ model: 'openai/gpt-5.4', max_tokens: 100 }),
    { model: 'openai/gpt-5.4', max_completion_tokens: 100 },
  )
  assert.deepEqual(applyClineMaxCompletionTokens({ model: 'spacexai/grok-4.7', max_tokens: 100 }), { model: 'spacexai/grok-4.7', max_tokens: 100 })
  assert.deepEqual(applyClineStreamUsage({ stream: true }), { stream: true, stream_options: { include_usage: true } })
  assert.deepEqual(applyClineStreamUsage({ stream: false }), { stream: false })
  assert.deepEqual(
    applyClineThinking({ model: 'anthropic/claude-opus-5.5', reasoning_effort: 'high' }),
    { model: 'anthropic/claude-opus-5.5', reasoning_effort: 'high' },
  )
  assert.deepEqual(applyClineThinking({ model: 'anthropic/claude-opus-5.5', reasoning_effort: 'max' }), { model: 'anthropic/claude-opus-5.5', reasoning_effort: 'xhigh' })
  assert.deepEqual(applyClineThinking({ model: 'unknown/model', reasoning_effort: 'high' }), { model: 'unknown/model' })
  const mapped = mapClineUsage({ prompt_tokens: 10, cache_read_input_tokens: 4 })
  assert.equal(mapped.prompt_tokens_details.cached_tokens, 4)
})

test('usage mapping picks the first valid cache alias, not the first present one', () => {
  const skipped = mapClineUsage({ prompt_tokens: 10, prompt_tokens_details: { cached_tokens: '123' }, cached_tokens: 50 })
  assert.equal(skipped.prompt_tokens_details.cached_tokens, 50)
  const unmapped = mapClineUsage({ prompt_tokens: 10, prompt_tokens_details: { cached_tokens: 'x' } })
  assert.equal(unmapped.prompt_tokens_details.cached_tokens, 'x')
})

// ---- 引擎 hop -----------------------------------------------------------------

test('the engine hop unwraps the success envelope and strips the host mark', async (t) => {
  const chatBody = {
    success: true,
    data: {
      id: 'gen-1',
      model: 'openai/gpt-6-astra',
      choices: [{ index: 0, message: { role: 'assistant', content: 'ok' } }],
      usage: { prompt_tokens: 3, cache_read_tokens: 2 },
    },
  }
  const seen = []
  const fetchFn = async (url, init = {}) => {
    seen.push({ url: String(url), body: String(init.body ?? '') })
    return json(chatBody)
  }
  const dataDir = await withEngine(t, fetchFn)
  const session = adaSession()
  await saveSession('cline', session, join(dataDir, 'auth.json'))
  const proxy = createProxy({ port: 0, apiKey: 'proxy-key-envelope-test', tokens: { cline: { session: async () => session } }, fetchFn })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const response = await fetch(`http://127.0.0.1:${port}/cline/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer proxy-key-envelope-test', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'openai/gpt-6-astra', messages: [{ role: 'user', content: 'hi' }], stream: false }),
    })
    assert.equal(response.status, 200)
    const body = await response.json()
    assert.equal(body.success, undefined)
    assert.equal(body.choices[0].message.content, 'ok')
    assert.equal(body.usage.prompt_tokens_details.cached_tokens, 2)
    assert.equal(response.headers.get('x-magpie-sign-in'), null, "the engine's host-protocol mark never reaches a DSH client")
    assert.equal(seen.filter((row) => row.url === CLINE_CHAT_URL).length, 1)
  } finally {
    await proxy.close()
  }
})

// ---- 额度 ---------------------------------------------------------------------

test('quota maps the engine usage: percent windows, wallet dollars, plan and account', async (t) => {
  const calls = []
  const fetchFn = async (url, init = {}) => {
    const href = String(url)
    calls.push({ href, authorization: new Headers(init.headers).get('authorization') })
    if (href === 'https://api.cline.bot/api/v1/users/me/plan/usage-limits') {
      return json({
        success: true,
        data: {
          limits: [
            { type: 'five_hour', percentUsed: 4.25, resetsAt: '2026-09-19T15:00:00Z' },
            { type: 'weekly', percentUsed: 40, resetsAt: '2026-09-26T00:00:00Z' },
            { type: 'daily', percentUsed: 5 },
          ],
        },
      })
    }
    if (href.endsWith('/users/me')) {
      return json({ success: true, data: { clineUserId: 'usr-01ABC', email: 'ada@example.com', plan: 'Cline Pass' } })
    }
    if (href.endsWith('/balance')) {
      return json({ success: true, data: { balance: 1_500_000 } })
    }
    return json({}, 404)
  }
  await withEngine(t, fetchFn)
  const quota = await fetchClineQuotaEngine(adaSession(), fetchFn)
  assert.deepEqual(quota.rows, [
    { key: 'window', kind: 'primary', product: '5 hours', usedPercent: 4.25, remainingPercent: 95.8, resetAt: Date.parse('2026-09-19T15:00:00Z') },
    { key: 'window', kind: 'primary', product: 'Weekly', usedPercent: 40, remainingPercent: 60, resetAt: Date.parse('2026-09-26T00:00:00Z') },
    { key: 'wallet', kind: 'prepaid', remaining: 1.5, unit: 'usd' },
  ])
  assert.equal(quota.planType, 'Cline Pass')
  assert.equal(quota.account, 'ada@example.com')
  // The reads carry Cline's client header group (index.mjs clientHeaders).
  assert.equal(calls.some((row) => row.href.endsWith('/usr-01ABC/balance')), true, 'balance rides the user id me reported')
})

test('credit account quota: no limits and no plan leave the wallet row alone', async (t) => {
  const fetchFn = async (url) => {
    const href = String(url)
    if (href.endsWith('/plan/usage-limits')) return json({ data: null, error: 'no plan history found for user', success: false }, 404)
    if (href.endsWith('/users/me')) return json({ success: true, data: { clineUserId: 'usr-01ABC', email: 'credit@example.com' } })
    if (href.endsWith('/balance')) return json({ success: true, data: { balance: 340_000 } })
    return json({}, 404)
  }
  await withEngine(t, fetchFn)
  const quota = await fetchClineQuotaEngine(adaSession(), fetchFn)
  assert.deepEqual(quota.rows, [{ key: 'wallet', kind: 'prepaid', remaining: 0.34, unit: 'usd' }])
  assert.equal(quota.planType, undefined)
})

test('an expired engine sign-in surfaces as the permanent refresh error', async (t) => {
  const fetchFn = async () => json({ error: 'Unauthorized' }, 401)
  await withEngine(t, fetchFn)
  const quota = await fetchClineQuotaEngine(adaSession(), fetchFn).catch((error) => error)
  assert.equal(isPermanentRefreshFailure(quota), true)
})

test('a near-expiry cli login never reaches the engine refresh (decision 4)', async (t) => {
  // Inside the engine's REFRESH_LEAD (pinned equal to CLINE_PREEMPT_MS) the
  // engine's fresh() would POST /auth/refresh itself and spend the CLI's
  // rotating refresh token — logging the CLI out. The adapter stops all
  // three engine entry points with the same stale verdict the manager's
  // providers.json reread gives, and nothing goes on the wire.
  const calls: string[] = []
  const fetchFn = async (url, init = {}) => {
    const href = String(url)
    calls.push(href)
    if (href === CLINE_REFRESH_URL) {
      return json({
        success: true,
        data: { accessToken: 'jwt-spent', refreshToken: 'ref-spent', expiresAt: new Date(Date.now() + 3600_000).toISOString() },
      })
    }
    if (href.endsWith('/plan/usage-limits')) return json({ data: null, error: 'no plan history found for user', success: false }, 404)
    if (href.endsWith('/users/me')) return json({ success: true, data: { clineUserId: 'usr-01CLI', email: 'cli@example.com' } })
    if (href.endsWith('/balance')) return json({ success: true, data: { balance: 900_000 } })
    return json({ success: true, data: { choices: [{ message: { role: 'assistant', content: 'ok' } }] } })
  }
  await withEngine(t, fetchFn)
  const stale = clineSessionFromAuthData({
    accessToken: 'jwt-cli',
    refreshToken: 'ref-cli',
    expiresAt: new Date(Date.now() + 60_000).toISOString(),
    userInfo: { email: 'cli@example.com', clineUserId: 'usr-01CLI' },
  }, { source: 'cli' })
  const hop = await clineEngineFetch({ session: stale, fetchFn }).then(() => undefined, (error) => error)
  assert.ok(hop instanceof ImportedLoginStale)
  const quota = await fetchClineQuotaEngine(stale, fetchFn).then(() => undefined, (error) => error)
  assert.ok(quota instanceof ImportedLoginStale)
  assert.match(quota.message, /run cline or use browser login/)
  const refused = await refreshClineEngine(stale, fetchFn).then(() => undefined, (error) => error)
  assert.ok(refused instanceof ImportedLoginStale)
  assert.deepEqual(calls, [], 'the CLI pair is never spent')
  // Control: the same login with headroom reads on through the engine and
  // no /auth/refresh fires.
  const roomy = { ...stale, expiresAt: Date.now() + 30 * 60_000 }
  const read = await fetchClineQuotaEngine(roomy, fetchFn)
  assert.deepEqual(read.rows, [{ key: 'wallet', kind: 'prepaid', remaining: 0.9, unit: 'usd' }])
  assert.equal(calls.includes(CLINE_REFRESH_URL), false)
})

test('an engine write-back merges onto the row and keeps its source', async (t) => {
  // A rotation the engine reports lands on the vault row (client.auth.set →
  // updateAccountSession by uid/active), and the row's own source survives
  // the merge — an engine answer must not rebrand a cli row oauth, or the
  // manager would start exchanging the CLI's refresh token.
  const calls: string[] = []
  const fetchFn = async (url) => {
    const href = String(url)
    calls.push(href)
    if (href === CLINE_REFRESH_URL) {
      return json({
        success: true,
        data: {
          accessToken: 'jwt-b',
          refreshToken: 'ref-b',
          expiresAt: new Date(Date.now() + 7200_000).toISOString(),
          userInfo: { email: 'ada@example.com', clineUserId: 'usr-01ABC' },
        },
      })
    }
    if (href.endsWith('/plan/usage-limits')) return json({ data: null, error: 'no plan history found for user', success: false }, 404)
    if (href.endsWith('/users/me')) return json({ success: true, data: { clineUserId: 'usr-01ABC', email: 'ada@example.com' } })
    if (href.endsWith('/balance')) return json({ success: true, data: { balance: 1_200_000 } })
    return json({}, 404)
  }
  const dataDir = await withEngine(t, fetchFn)
  const authPath = join(dataDir, 'auth.json')
  const nearExpiry = { ...adaSession(), expiresAt: Date.now() + 60_000 }
  await saveSession('cline', nearExpiry, authPath)
  const quota = await fetchClineQuotaEngine(nearExpiry, fetchFn)
  assert.deepEqual(quota.rows, [{ key: 'wallet', kind: 'prepaid', remaining: 1.2, unit: 'usd' }])
  assert.equal(calls.includes(CLINE_REFRESH_URL), true, 'an oauth login inside the lead rotates through the engine')
  const rows = await listStoredSessions('cline', authPath)
  assert.equal(rows.length, 1)
  assert.equal(rows[0].session.accessToken, 'workos:jwt-b')
  assert.equal(rows[0].session.refreshToken, 'ref-b')
  assert.equal(rows[0].session.source, 'oauth')
  const merged = sessionFromEngineResult(
    { access: 'jwt-x', refresh: 'ref-x', expires: Date.now() + 3600_000 },
    { source: 'cli', account: 'cli@example.com' },
  )
  assert.equal(merged.source, 'cli', 'the merge seam keeps a cli base cli')
})

test('a failed limits read keeps the balance the usage still returned', async (t) => {
  // index.mjs #79: usage-limits failing non-404 while me/balance succeed is
  // reported as a soft error alongside what was read — the card keeps its
  // wallet row and plan instead of turning into an error card.
  const fetchFn = async (url) => {
    const href = String(url)
    if (href.endsWith('/plan/usage-limits')) return json({ error: 'limits backend down' }, 500)
    if (href.endsWith('/users/me')) return json({ success: true, data: { clineUserId: 'usr-01ABC', email: 'ada@example.com', plan: 'Cline Pass' } })
    if (href.endsWith('/balance')) return json({ success: true, data: { balance: 1_500_000 } })
    return json({}, 404)
  }
  await withEngine(t, fetchFn)
  const quota = await fetchClineQuotaEngine(adaSession(), fetchFn)
  assert.deepEqual(quota.rows, [{ key: 'wallet', kind: 'prepaid', remaining: 1.5, unit: 'usd' }])
  assert.equal(quota.planType, 'Cline Pass')
  assert.match(quota.error ?? '', /ClinePass limits couldn't be read/)
})

test('a usage read with nothing to show still fails whole', async (t) => {
  // Every read down: the card says error rather than an empty success (the
  // pre-engine behaviour for a total failure).
  await withEngine(t, async () => json({ error: 'down' }, 500))
  const dead = await fetchClineQuotaEngine(adaSession(), async () => json({ error: 'down' }, 500)).catch((error) => error)
  assert.ok(dead instanceof Error)
  assert.equal(isPermanentRefreshFailure(dead), false)
})

// ---- 导入与同步 -----------------------------------------------------------------

test('import reads ~/.cline providers.json without a token fragment as the id', async () => {
  const home = await mkdtemp(join(tmpdir(), 'cline-import-'))
  const settingsDir = join(home, '.cline', 'data', 'settings')
  await mkdir(settingsDir, { recursive: true })
  await writeFile(join(settingsDir, 'providers.json'), JSON.stringify({
    version: 1,
    lastUsedProvider: 'cline',
    providers: {
      cline: {
        settings: {
          provider: 'cline',
          auth: {
            accessToken: 'workos:cli-jwt',
            refreshToken: 'cli-refresh',
            expiresAt: Date.now() + 3600_000,
            accountId: 'usr-01CLI',
            metadata: { tokenType: 'Bearer', provider: 'cline', userInfo: { email: 'cli@example.com', clineUserId: 'usr-01CLI' } },
          },
        },
        tokenSource: 'oauth',
      },
    },
  }))
  const session = await importClineAuth({ home, env: {} })
  assert.equal(session.source, 'cli')
  assert.equal(session.session.accessToken, 'workos:cli-jwt')
  assert.equal(session.session.account, 'cli@example.com')
  assert.equal(accountIdOf('cline', session.session), 'cli@example.com')
  assert.equal(clineSessionFromProvidersFile({ providers: { cline: { settings: { auth: {} } } } }), undefined)
  const missing = await importClineAuth({ home: join(home, 'nope'), env: {} }).catch((error) => error)
  assert.equal(missing.message, CLINE_IMPORT_EMPTY)
  assert.equal(clineDefaultAccount('workos:not-a-jwt'), 'cline-account')
})

test('sync writes the live cline catalog, not the offline seed', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'cline-sync-'))
  const authPath = join(dir, 'auth.json')
  await saveSession('cline', clineSessionFromAuthData({
    accessToken: 'jwt-a',
    refreshToken: 'ref-a',
    expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    userInfo: { email: 'one@example.com', clineUserId: 'usr-01ONE' },
  }, {}), authPath)
  const providers = {}
  const operations = []
  const settings = {
    get: (name) => (name === 'llm-pi-ai' ? { providers: structuredClone(providers) } : undefined),
    mutate: async (target, mutations) => {
      assert.equal(target, 'llm-pi-ai')
      operations.push(...mutations)
      for (const row of mutations) {
        const key = row.path?.[1]
        if (row.op === 'unset') delete providers[key]
        else if (row.op === 'set') {
          // The same gate the host runs before its atomic mutate.
          assertDshServiceableProvider(key, row.value)
          providers[key] = structuredClone(row.value)
        }
      }
    },
  }
  const liveFeed = {
    recommended: [{ id: 'openai/gpt-6-astra', name: 'gpt-6-astra' }, { id: 'new/lab-model', name: 'lab-model' }],
    free: [{ id: 'cline-free/mimo-v2.6-flash', name: 'Mimo V2.6 Flash' }],
  }
  resetClineCatalogCache()
  await refreshClineCatalog(null, { fetchFn: async () => json(liveFeed) })
  const live = clineCatalogModels()
  assert.equal(live.length, 3)
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings,
    clineAutoImport: false,
    fetchFn: async () => json({}, 404),
  })
  await controller.sync()
  resetClineCatalogCache()
  const route = providers['oauth-cline']
  assert.ok(route, 'oauth-cline route must be written')
  assert.equal(route.api, HARNESS_COMPLETIONS_API)
  assert.equal(route.baseURL, 'http://127.0.0.1:8318/cline')
  assert.deepEqual(route.models.map((model) => model.id), live.map((model) => model.id))
  assert.equal(operations.some((row) => row.op === 'set' && row.path?.[1] === 'oauth-cline'), true)
})

test('an expired cli-imported cline login shows the rerun hint, never the upstream 401', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'cline-stale-'))
  const authPath = join(dir, 'auth.json')
  const home = join(dir, 'cline-home')
  await mkdir(join(home, 'data', 'settings'), { recursive: true })
  const expired = Date.now() - 3600_000
  await writeFile(join(home, 'data', 'settings', 'providers.json'), JSON.stringify({
    providers: { cline: { settings: { auth: { accessToken: 'workos:jwt-old', refreshToken: 'ref-old', expiresAt: expired, accountId: 'usr-01OLD' } } } },
  }))
  const session = clineSessionFromAuthData({
    accessToken: 'jwt-old',
    refreshToken: 'ref-old',
    expiresAt: new Date(expired).toISOString(),
    userInfo: { email: 'old@example.com', clineUserId: 'usr-01OLD' },
  }, { source: 'cli' })
  await saveSession('cline', session, authPath)
  const previous = process.env.CLINE_HOME
  process.env.CLINE_HOME = home
  const calls = []
  try {
    const controller = new AuthController({
      authPath,
      prefix: 'oauth',
      origin: () => 'http://127.0.0.1:8318',
      clineAutoImport: false,
      clineDiscover: async () => CLINE_MODELS,
      fetchFn: async (url) => {
        calls.push(String(url))
        return json({ error: "Unauthorized: Please make sure you're using the latest version of Cline" }, 401)
      },
    })
    await controller.refreshQuota('cline')
    const snap = await controller.snapshot()
    const [row] = snap.accounts.cline.accounts
    assert.ok(row, 'the stale login stays listed')
    assert.equal(row.quota.status, 'error')
    assert.match(row.quota.error, /imported login is stale; run cline/)
    assert.equal(calls.some((href) => href.includes('/users/')), false)
  } finally {
    if (previous === undefined) delete process.env.CLINE_HOME
    else process.env.CLINE_HOME = previous
  }
})

// ---- 控制器 -------------------------------------------------------------------

test('controller snapshot shows quota on every cline account; hop is Completions', async (t) => {
  const seen = []
  const fetchFn = async (url, init = {}) => {
    const href = String(url)
    const headers = new Headers(init.headers)
    const authorization = headers.get('authorization') ?? ''
    seen.push({ href, body: String(init.body ?? ''), headers, authorization })
    if (href.endsWith('/plan/usage-limits')) {
      return json({ data: null, error: 'no plan history found for user', success: false }, 404)
    }
    if (href.endsWith('/users/me')) {
      if (authorization.includes('jwt-b')) return json({ success: true, data: { clineUserId: 'usr-01TWO', email: 'two@example.com' } })
      return json({ success: true, data: { clineUserId: 'usr-01ONE', email: 'one@example.com', plan: 'Cline Pass' } })
    }
    if (href.endsWith('/balance')) {
      return json({ success: true, data: { balance: authorization.includes('jwt-b') ? 340_000 : 2_000_000 } })
    }
    if (href.endsWith('/chat/completions')) {
      return json({ success: true, data: { id: 'chat', choices: [{ message: { role: 'assistant', content: 'ok' } }] } })
    }
    return json({}, 404)
  }
  const dataDir = await withEngine(t, fetchFn)
  const authPath = join(dataDir, 'auth.json')
  const first = clineSessionFromAuthData({
    accessToken: 'jwt-a',
    refreshToken: 'ref-a',
    expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    userInfo: { email: 'one@example.com', name: 'One', clineUserId: 'usr-01ONE', subject: 'user_1' },
  }, {})
  const second = clineSessionFromAuthData({
    accessToken: 'jwt-b',
    refreshToken: 'ref-b',
    expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    userInfo: { email: 'two@example.com', name: 'Two', clineUserId: 'usr-01TWO', subject: 'user_2' },
  }, { source: 'cli' })
  await saveSession('cline', first, authPath)
  await saveSession('cline', second, authPath, { activate: false })
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    clineAutoImport: false,
    clineDiscover: async () => CLINE_MODELS,
    fetchFn,
  })
  const snap = await controller.snapshot()
  assert.equal(snap.accounts.cline.accounts.length, 2)
  assert.equal(snap.accounts.cline.loggedIn, true)
  for (const row of snap.accounts.cline.accounts) {
    assert.ok(row.quota)
    assert.equal(JSON.stringify(row).includes("jwt-"), false)
    assert.equal(JSON.stringify(row).includes("ref-"), false)
  }
  assert.equal(snap.catalog.some((row) => row.family === 'cline'), true)

  const proxy = createProxy({
    port: 0,
    apiKey: 'proxy-key-cline-test-xx',
    tokens: controller.tokens,
    fetchFn,
  })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const listed = await fetch(`http://127.0.0.1:${port}/cline/v1/models`, { headers: { authorization: 'Bearer proxy-key-cline-test-xx' } })
    assert.equal(listed.status, 200)
    const list = await listed.json()
    assert.equal(list.data.length, CLINE_MODELS.length)
    const response = await fetch(`http://127.0.0.1:${port}/cline/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer proxy-key-cline-test-xx', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'anthropic/claude-opus-5.5',
        messages: [{ role: 'user', content: 'hi' }],
        session_id: 'dsh-session-9',
        prompt_cache_key: 'codex-style',
        reasoning_effort: 'high',
      }),
    })
    assert.equal(response.status, 200)
    const chat = seen.find((row) => row.href === CLINE_CHAT_URL)
    assert.ok(chat, 'the hop reached the engine loader')
    // Cline's own header group with the engine's task id; nothing DSH leaks.
    assert.equal(chat.authorization, 'Bearer workos:jwt-a')
    assert.equal(chat.headers.get(CLINE_SESSION_HEADER), null, "the engine's private session header never leaves the plugin")
    assert.equal(chat.headers.get('X-Task-ID'), taskIdOf('dsh-session-9'))
    assert.match(chat.headers.get('X-Task-ID') ?? '', /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/)
    assert.equal(chat.headers.get('X-CLIENT-TYPE'), CLINE_CLIENT_TYPE)
    assert.equal(chat.headers.get('user-agent'), 'Cline/3.0.68')
    assert.equal(chat.headers.get('session-id'), null)
    assert.equal(chat.headers.get('x-grok-conv-id'), null)
    assert.equal(chat.headers.get('x-initiator'), null)
    const sent = JSON.parse(chat.body)
    assert.equal(sent.prompt_cache_key, undefined)
    assert.equal(sent.session_id, undefined)
    assert.equal(sent.reasoning_effort, 'high')
    assert.equal(CLINE_CHAT_URL, `${CLINE_API_BASE}/chat/completions`)
    const responses = await fetch(`http://127.0.0.1:${port}/cline/v1/responses`, {
      method: 'POST',
      headers: { authorization: 'Bearer proxy-key-cline-test-xx', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'anthropic/claude-opus-5.5', input: [] }),
    })
    assert.equal(responses.status, 501)
  } finally {
    await proxy.close()
  }
})

test('unwrapClineEnvelope stays a no-op over the engine-unwrapped body', () => {
  assert.deepEqual(
    unwrapClineEnvelope({ success: true, data: { choices: [{ index: 0 }] } }),
    { choices: [{ index: 0 }] },
  )
  assert.deepEqual(unwrapClineEnvelope({ success: false, error: 'nope' }), { success: false, error: 'nope' })
  assert.deepEqual(unwrapClineEnvelope({ choices: [] }), { choices: [] })
})

test('cline catalog refresh keeps one public lifecycle and does not double the two GETs', async () => {
  const http = { n: 0 }
  const feed = (kind) => ({
    recommended: [{ id: kind === 'a' ? 'live/only-a' : 'live/only-b', name: kind === 'a' ? 'A' : 'B' }],
  })
  await exerciseLiveCatalog({
    label: 'cline',
    ttlMs: CLINE_CATALOG_TTL_MS,
    shared: true,
    dropStaticId: CLINE_MODELS[0].id,
    httpPerRefresh: 2,
    httpCount: () => http.n,
    reset: resetClineCatalogCache,
    models: clineCatalogModels,
    idFor: (kind) => `live/only-${kind}`,
    refresh: ({ now, ttlMs, fetch }) => {
      let pending
      return refreshClineCatalog(null, {
        now,
        ttlMs,
        fetchFn: async () => {
          http.n += 1
          pending ??= fetch()
          const kind = await pending
          if (kind === 'fail') return { ok: false, json: async () => ({}) }
          if (kind === 'empty') return { ok: true, json: async () => ({}) }
          return { ok: true, json: async () => feed(kind) }
        },
      })
    },
  })
})
