import assert from 'node:assert/strict'
import { test } from 'node:test'
import { existsSync, readFileSync } from 'node:fs'
import { parseVersion } from '../lib/utils/update.js'

const manifest = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))
const exists = (relative) => existsSync(new URL('../' + relative, import.meta.url))

// The plugin panel installs from a registry name, a git repository, or a local
// directory; all three read this manifest before pnpm runs. A missing bundle
// patch, entry point, or published file turns into "该路径不存在或不是有效的插件包".

test('the manifest declares the DSH bundle patch and client the panel installs', () => {
  assert.equal(manifest.name, 'dsh-plugin-oauth-subs')
  assert.equal(manifest.dsh?.bundle?.patch, './cordis.patch.yml')
  assert.ok(exists('cordis.patch.yml'))
  assert.equal(manifest.dsh?.client?.platform, 'web')
  assert.ok(Array.isArray(manifest.dsh?.client?.inject) && manifest.dsh.client.inject.length > 0)
  assert.ok(Array.isArray(manifest.dsh?.client?.external))
})

test('every published file exists and the install entry points resolve', () => {
  assert.ok(Array.isArray(manifest.files) && manifest.files.length > 0)
  for (const entry of manifest.files) {
    assert.ok(exists(entry), 'files entry missing from the repo: ' + entry)
  }
  assert.equal(manifest.main, 'lib/index.js')
  assert.equal(manifest.exports?.['.'], './lib/index.js')
  assert.equal(manifest.exports?.['./client'], './lib/ui/client.js')
  assert.ok(exists('lib/index.js'), 'run npm run build before packing: lib/index.js')
  assert.ok(exists('lib/ui/client.js'), 'run npm run build before packing: lib/ui/client.js')
})

test('a git or npm install needs no build step: lib/ is committed', () => {
  // pnpm fetches the repository/tarball as-is; only a local directory link
  // points at a tree the maintainer builds in place.
  assert.ok(exists('src/index.ts'))
  assert.ok(exists('lib/index.js'))
  assert.ok(manifest.scripts?.build, 'build script must exist for the maintainer')
})

test('the committed version is a release version, never a local test number', () => {
  const parsed = parseVersion(manifest.version)
  assert.ok(parsed, 'package.json version must be semver-ish: ' + manifest.version)
  assert.equal(parsed.prerelease, '',
    'the repo manifest keeps the release version; test numbers live in the packed tgz only')
})

test('the DSH peer the panel checks before installing is declared', () => {
  assert.equal(manifest.peerDependencies?.['@deepseek-ai/cordis'], '^4.0.1')
})

// DSH 0.2.x reads a plugin's title, description, and icon without activating it:
// locale JSON is discovered by scanning the exported `/locale` directory, and the
// icon comes from a package-root `icon` or the exported `./icon` resource. Both
// are read through the Node ESM resolver, so a missing export silently degrades to
// the package `name` and the generic artwork.
test('display metadata exports locale JSON and an icon the host can resolve', () => {
  assert.equal(manifest.exports?.['./locale/*.json'], './locale/*.json')
  assert.equal(manifest.exports?.['./icon'], './assets/icon.svg')
  for (const entry of ['locale/en.json', 'locale/zh.json', 'assets/icon.svg']) {
    assert.ok(exists(entry), 'display resource missing from the repo: ' + entry)
  }
  // `files` does not filter a linked checkout, but a packed tarball ships only these.
  for (const entry of ['locale', 'assets']) {
    assert.ok(manifest.files.includes(entry), 'files must ship the display resources: ' + entry)
  }
})

test('every locale supplies meta.title and meta.description in both languages', () => {
  const titles = []
  for (const language of ['en', 'zh']) {
    const dictionary = JSON.parse(readFileSync(new URL(`../locale/${language}.json`, import.meta.url), 'utf8'))
    const meta = dictionary.meta
    assert.ok(meta, `locale/${language}.json must carry a meta object`)
    assert.equal(typeof meta.title, 'string')
    assert.ok(meta.title.trim().length > 0, `locale/${language}.json meta.title must not be blank`)
    assert.equal(typeof meta.description, 'string')
    assert.ok(meta.description.trim().length > 0, `locale/${language}.json meta.description must not be blank`)
    titles.push(meta.title)
  }
  // A shared English title would let a translation regression pass unnoticed.
  assert.notEqual(titles[0], titles[1], 'zh meta.title must be translated, not copied from English')
})

test('the plugin icon is a valid image under the host 256 KiB limit', () => {
  const bytes = readFileSync(new URL('../assets/icon.svg', import.meta.url))
  assert.ok(bytes.length <= 256 * 1024, `icon exceeds 256 KiB: ${bytes.length} bytes`)
  const svg = bytes.toString('utf8')
  // The host validates only the extension and size; a broken payload would still install.
  assert.match(svg, /^<svg[^>]+xmlns="http:\/\/www\.w3\.org\/2000\/svg"/,
    'icon must be an SVG document with a namespace, or a browser will not render it')
  assert.match(svg, /viewBox="\d+ \d+ \d+ \d+"/, 'icon needs a viewBox to scale into the plugin row')
})

// A `dsh.client.inject` name that no longer exists in the client module graph is
// skipped silently (only rows already in the graph are awaited), so a stale name
// is dead metadata rather than a boot error — but it still misleads the next reader.
test('client inject names graph rows the 0.2.x client system actually ships', () => {
  for (const name of manifest.dsh.client.inject) {
    assert.doesNotMatch(name, /^@deepseek-ai\/dsh-client-runtime$/,
      'dsh-client-runtime was folded into dsh-client-modules and no longer has a graph row')
  }
})

