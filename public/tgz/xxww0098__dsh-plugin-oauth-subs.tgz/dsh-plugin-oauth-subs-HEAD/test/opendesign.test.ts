import assert from 'node:assert/strict'
import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { AuthController } from '../lib/oauth/controller.js'
import { accountIdOf, listStoredSessions, publicSession, saveSession } from '../lib/oauth/store.js'
import {
  HARNESS_COMPLETIONS_API,
  buildProviders,
  catalogProviders,
  ownedProviderIds,
} from '../lib/oauth/models.js'
import {
  OPENDESIGN_CHAT_URL,
  OPENDESIGN_MODELS,
  OPENDESIGN_STABLE_SESSION,
  OPENDESIGN_USER_AGENT,
  OPENDESIGN_WORKSPACES_URL,
  opendesignControlKeyOf,
  opendesignDefaultAccount,
  opendesignRuntimeKeyOf,
  opendesignSession,
  opendesignSourceLabel,
  parseOpendesignApiKey,
} from '../lib/oauth/opendesign/index.js'
import { applyOpendesignCache, opendesignCacheHeaders, opendesignCacheSessionId } from '../lib/oauth/opendesign/cache.js'
import {
  fetchOpendesignQuotaEngine,
  opendesignEngineAuthorize,
  opendesignEngineUserAgent,
  resetOpendesignEnginePlugin,
} from '../lib/oauth/opendesign/engine.js'
import { toOpendesignPickerModels } from '../lib/oauth/opendesign/catalog.js'
import { createProxy } from '../lib/oauth/proxy.js'
import { rm } from 'node:fs/promises'
import { configureUpstreamEngine, resetUpstreamEngineCache } from '../lib/upstream-engine/engine.js'
import { configureEngineBridge, resetEngineBridge } from '../lib/upstream-engine/bridge.js'
import {
  OPENDESIGN_FIXTURE_MODULE,
  OPENDESIGN_FIXTURE_NPM,
  OPENDESIGN_FIXTURE_VERSION,
  writeEngineCache,
} from './upstream-engine-fixture.ts'

/** The engine lane under a tmp data dir, its global fetch bridge-routed. */
async function withEngine(t, fetchFn) {
  const dataDir = await mkdtemp(join(tmpdir(), 'opendesign-engine-'))
  t.after(() => rm(dataDir, { recursive: true, force: true }))
  await writeEngineCache(dataDir, {
    npm: OPENDESIGN_FIXTURE_NPM,
    version: OPENDESIGN_FIXTURE_VERSION,
    module: OPENDESIGN_FIXTURE_MODULE,
    engines: { opendesign: { npm: OPENDESIGN_FIXTURE_NPM, version: OPENDESIGN_FIXTURE_VERSION, integrity: 'sha512-fixture' } },
  })
  resetUpstreamEngineCache()
  resetOpendesignEnginePlugin()
  configureUpstreamEngine(join(dataDir, 'auth.json'))
  configureEngineBridge({ fetchFn })
  t.after(() => {
    resetUpstreamEngineCache()
    resetOpendesignEnginePlugin()
    resetEngineBridge()
    configureUpstreamEngine(undefined)
  })
  return dataDir
}

function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })
}

// ---- the sign-in ----------------------------------------------------------------

test('the engine device sign-in posts the CLI-shaped body with the package UA', async (t) => {
  const calls = []
  const fetchFn = async (url, init) => {
    calls.push({ url: String(url), body: String(init.body ?? ''), headers: init.headers })
    return json({
      deviceId: 'dev-1',
      deviceSecret: 'sec-1',
      userCode: '4HYFNA',
      activationUrl: 'https://open-design.ai/cloud/cli/activate?device_code=dev-1',
      pollIntervalSeconds: 3,
      expiresAt: '2026-10-17T12:00:00.000Z',
    })
  }
  await withEngine(t, fetchFn)
  const started = await opendesignEngineAuthorize({ fetchFn })
  assert.equal(started.mode, 'device')
  assert.equal(started.userCode, '4HYFNA')
  assert.match(started.authorizeUrl, /activate\?device_code=dev-1/)
  assert.equal(calls.length, 1)
  assert.equal(calls[0].url, 'https://amr-api.open-design.ai/api/v1/cli/device-authorizations')
  assert.deepEqual(JSON.parse(calls[0].body), { cliVersion: '0.1.4', host: 'fixture', profile: 'prod' })
  assert.equal(calls[0].headers['user-agent'], 'opencode-opendesign-auth/0.1.6')
  assert.equal(opendesignEngineUserAgent(), 'opencode-opendesign-auth/0.1.6', 'the UA follows the loaded engine version')
})

test('the engine poll takes the approval keys, and says so when the code dies', async (t) => {
  const calls = []
  const fetchFn = async (url) => {
    calls.push(String(url))
    if (String(url).endsWith('/device-authorizations')) {
      return json({ deviceId: 'd1', deviceSecret: 's1', userCode: '4H', activationUrl: 'https://open-design.ai/activate', pollIntervalSeconds: 0.001 })
    }
    const body = calls.length < 3
      ? { status: 'pending', controlKey: null, runtimeKey: null, user: null }
      : { status: 'approved', controlKey: 'vela_ctrl_a', runtimeKey: 'sk-amr-b', user: { id: 'u1', email: 'ada@example.com' } }
    return json(body)
  }
  const engineDir = await withEngine(t, fetchFn)
  const started = await opendesignEngineAuthorize({ fetchFn })
  const session = await started.settle()
  assert.equal(session.accessToken, 'sk-amr-b')
  assert.equal(session.controlKey, 'vela_ctrl_a')
  assert.equal(session.account, 'ada@example.com')
  assert.equal(session.uid, 'u1')
  assert.equal(session.source, 'oauth')
  assert.equal(calls[1], 'https://amr-api.open-design.ai/api/v1/cli/device-authorizations/d1/token')

  const died = async (answer, pattern) => {
    const fake = async (url) => {
      if (String(url).endsWith('/device-authorizations')) {
        return json({ deviceId: 'd2', deviceSecret: 's2', activationUrl: 'https://open-design.ai/activate', pollIntervalSeconds: 0.001 })
      }
      return answer()
    }
    resetUpstreamEngineCache()
    resetOpendesignEnginePlugin()
    configureUpstreamEngine(join(engineDir, 'auth.json'))
    configureEngineBridge({ fetchFn: fake })
    let again
    try {
      const started2 = await opendesignEngineAuthorize({ fetchFn: fake })
      again = await started2.settle()
      again = { message: 'the sign-in unexpectedly succeeded' }
    } catch (error) {
      again = error
    }
    assert.match(String(again.message ?? again), pattern)
  }
  await died(() => json({ status: 'expired' }), /expired — start again/)
  await died(() => json({ error: 'invalid_device_secret' }, 401), /no longer valid/)
})

test('both keys are required, and a control key is never a runtime key', () => {
  assert.equal(opendesignRuntimeKeyOf({ accessToken: 'sk-amr-b' }), 'sk-amr-b')
  assert.equal(opendesignRuntimeKeyOf({ accessToken: 'vela_ctrl_a' }), '')
  assert.equal(opendesignControlKeyOf({ controlKey: 'vela_ctrl_a' }), 'vela_ctrl_a')
  assert.equal(opendesignControlKeyOf({ accessToken: 'sk-amr-b' }), '')
  assert.throws(() => parseOpendesignApiKey('vela_ctrl_a'), /control key/)
  assert.equal(parseOpendesignApiKey('sk-amr-pasted'), 'sk-amr-pasted')
})

// ---- the session it keeps -------------------------------------------------------

test('session roundtrip: email ids, never-expiring keys, no secrets on the card', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'opendesign-store-'))
  const authPath = join(dir, 'auth.json')
  const first = opendesignSession({
    runtimeKey: 'sk-amr-a',
    controlKey: 'vela_ctrl-a',
    account: 'ada@example.com',
    uid: 'u1',
  })
  const second = opendesignSession({ runtimeKey: 'sk-amr-paste', source: 'paste' })
  await saveSession('opendesign', first, authPath)
  await saveSession('opendesign', second, authPath, { activate: false })
  const stored = await listStoredSessions('opendesign', authPath)
  assert.equal(stored.length, 2)
  assert.notEqual(accountIdOf('opendesign', first), accountIdOf('opendesign', second))
  assert.equal(accountIdOf('opendesign', first), 'ada@example.com')
  assert.equal(accountIdOf('opendesign', second), opendesignDefaultAccount('sk-amr-paste'))
  const pub = publicSession('opendesign', first)
  assert.equal(pub.account, 'ada@example.com')
  assert.equal(pub.methodLabel, 'OAuth')
  assert.equal(publicSession('opendesign', second).methodLabel, 'key')
  assert.equal(opendesignSourceLabel('env'), undefined)
  const text = JSON.stringify(pub)
  assert.equal(text.includes('sk-amr'), false)
  assert.equal(text.includes('vela_ctrl'), false)
  assert.equal(text.includes('u1'), false)
  assert.equal(Object.hasOwn(pub, 'accessToken'), false)
  assert.equal(Object.hasOwn(pub, 'controlKey'), false)
  // neither key expires, so nothing ever refreshes
  assert.ok(first.expiresAt > Date.now() + 100 * 365 * 24 * 60 * 60_000)
})

// ---- the account's models ------------------------------------------------------

test('catalog is Completions at /opendesign with closed-set effort keys', () => {
  const ids = ownedProviderIds('oauth')
  assert.equal(ids.includes('oauth-opendesign'), true)
  const providers = buildProviders({
    prefix: 'oauth',
    origin: 'http://127.0.0.1:8318',
    loggedIn: { opendesign: true },
  })
  const route = providers['oauth-opendesign']
  assert.equal(route.api, HARNESS_COMPLETIONS_API)
  assert.equal(route.api, 'openai-completions')
  assert.equal(route.baseURL, 'http://127.0.0.1:8318/opendesign')
  assert.equal(route.displayName, 'Subs · Open Design · Chat')
  assert.equal(route.models.length, OPENDESIGN_MODELS.length)
  for (const model of route.models) {
    for (const key of Object.keys(model.reasoningEfforts ?? {})) {
      assert.match(key, /^(off|minimal|low|medium|high|xhigh|max)$/)
    }
  }
  assert.deepEqual(
    route.models.find((model) => model.id === 'deepseek-v4-pro').reasoningEfforts,
    { low: 'low', high: 'high', max: 'max' },
  )
  assert.equal(route.models.find((model) => model.id === 'gpt-6-luna').reasoningEfforts, false)
  assert.equal(catalogProviders({ prefix: 'oauth', origin: 'http://x' })['oauth-opendesign'].models.length, OPENDESIGN_MODELS.length)
})

test('live rows come from the vendor catalog fields, efforts only where measured', () => {
  const rows = toOpendesignPickerModels({
    data: [
      {
        id: 'deepseek-v4-pro',
        architecture: { input_modalities: ['text'] },
        metadata: { cost: 'high', capability: 'advanced', context_limit: 1048000, context_budget: 232000 },
      },
      {
        id: 'glm-5.3-flash',
        architecture: { input_modalities: ['text', 'image', 'video'] },
        metadata: { cost: 'low', capability: 'advanced', context_limit: 1048000, context_budget: 232000 },
      },
      { id: 'brand-new-9', architecture: { input_modalities: ['text', 'image'] }, metadata: { cost: 'medium', capability: 'advanced' } },
      // no architecture at all: the vendor declared no modality — text only
      // (upstream facts() takes an empty array when the field is missing,
      // index.mjs:335-337); never an invented image input
      { id: 'no-modality', metadata: {} },
    ],
  })
  const byId = Object.fromEntries(rows.map((row) => [row.id, row]))
  assert.deepEqual(byId['deepseek-v4-pro'], {
    id: 'deepseek-v4-pro',
    name: 'DeepSeek V4 Pro',
    contextWindow: 1048000,
    maxTokens: 232000,
    input: ['text'],
    rate: 2,
    reasoningEfforts: { low: 'low', high: 'high', max: 'max' },
  })
  // video is stripped to the repo's text|image row shape
  assert.deepEqual(byId['glm-5.3-flash'].input, ['text', 'image'])
  // an id the seed has not measured carries no efforts; unknown limits get the
  // upstream provider defaults (index.mjs:289-292), never an invented number
  assert.equal(byId['brand-new-9'].reasoningEfforts, undefined)
  assert.equal(byId['brand-new-9'].contextWindow, 200_000)
  assert.equal(byId['brand-new-9'].maxTokens, 32_000)
  assert.equal(byId['brand-new-9'].name, 'brand-new-9')
  // missing modality declaration is text-only, and limits fall to the defaults
  // (the seed lends names and efforts only — modelsOf, index.mjs:361)
  assert.deepEqual(byId['no-modality'].input, ['text'])
  assert.equal(byId['no-modality'].contextWindow, 200_000)
})

// ---- the cache -----------------------------------------------------------------

test('cache strips foreign fields and pins nothing', () => {
  const { payload, cacheSessionId } = applyOpendesignCache({
    model: 'deepseek-v4-pro',
    session_id: 'sess-opendesign',
    prompt_cache_key: 'codex-style',
    prompt_cache_retention: '24h',
    prompt_cache_options: { retention: '24h' },
    reasoning_effort: 'high',
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.equal(cacheSessionId, 'sess-opendesign')
  assert.equal(payload.prompt_cache_key, undefined)
  assert.equal(payload.prompt_cache_retention, undefined)
  assert.equal(payload.prompt_cache_options, undefined)
  assert.equal(payload.session_id, undefined)
  // reasoning_effort is native on this wire: it passes through untouched
  assert.equal(payload.reasoning_effort, 'high')
  assert.deepEqual(payload.messages, [{ role: 'user', content: 'hi' }])
  const bare = applyOpendesignCache({ model: 'deepseek-v4-pro' })
  assert.equal(bare.cacheSessionId, OPENDESIGN_STABLE_SESSION)
  assert.deepEqual(opendesignCacheHeaders(), {})
  assert.equal(opendesignCacheSessionId('session 1'), 'session-1')
  assert.equal(opendesignCacheSessionId(''), undefined)
})

// ---- the allowance -------------------------------------------------------------

// one reading of /workspaces/{id}/billing/preflight, as the control plane
// answers it (upstream index.test.mjs PREFLIGHT)
const PREFLIGHT = {
  balanceUsd: '1.5000',
  funding: 'wallet',
  codingPlan: {
    eligible: true,
    tier: 'go',
    // out of order on purpose: the vendor's own shortest-first sort is applied
    windows: [
      { durationSeconds: 604800, usedCredits: '16251', limitCredits: '150000', resetsAt: '2026-10-18T06:36:14.000Z' },
      { durationSeconds: 18000, usedCredits: '16251', limitCredits: '50000', resetsAt: '2026-10-11T11:36:14.000Z' },
    ],
  },
}

test('the engine usage read maps 5h/7d windows, the wallet and the plan', async (t) => {
  const seen = []
  const fetchFn = async (url, init = {}) => {
    const target = String(url)
    seen.push([target, init.headers?.authorization ?? ''])
    if (target === OPENDESIGN_WORKSPACES_URL) {
      return json({ activeWorkspaceId: 'ws1', personalMembershipTier: 'go' })
    }
    if (target.includes('/billing/preflight')) return json(PREFLIGHT)
    if (target.endsWith('/billing/summary')) {
      return json({
        membershipTier: 'go',
        subscriptionStatus: 'active',
        subscriptionCancelAtPeriodEnd: false,
        subscriptionCurrentPeriodEnd: '2026-11-11T06:36:14.000Z',
        balanceUsd: '1.5000',
      })
    }
    return json({}, 404)
  }
  await withEngine(t, fetchFn)
  const session = opendesignSession({ runtimeKey: 'sk-amr-b', controlKey: 'vela_ctrl_a', account: 'ada@example.com' })
  const parsed = await fetchOpendesignQuotaEngine(session, fetchFn)
  assert.equal(parsed.planType, 'Design Plan Go')
  assert.equal(parsed.rows.length, 3, 'two windows, shortest first, plus the wallet')
  assert.deepEqual(parsed.rows.map((row) => row.key), ['window', '7d', 'wallet'])
  const fiveHour = parsed.rows[0]
  assert.equal(fiveHour.kind, 'primary')
  assert.equal(fiveHour.windowMinutes, 300)
  assert.equal(fiveHour.usedPercent, 32.5)
  assert.equal(fiveHour.remainingPercent, 67.5)
  assert.equal(fiveHour.resetAt, Date.parse('2026-10-11T11:36:14.000Z'))
  const weekly = parsed.rows[1]
  assert.equal(weekly.kind, 'weekly')
  assert.equal(weekly.usedPercent, 10.8)
  const wallet = parsed.rows[2]
  assert.equal(wallet.kind, 'prepaid')
  assert.equal(wallet.remaining, 1.5)
  assert.equal(wallet.unit, 'usd')
  assert.equal(seen.length, 3)
  assert.ok(seen.every(([, auth]) => auth === 'Bearer vela_ctrl_a'), 'the control-plane reads ride the control key')

  // a window with nothing to divide is left out (the engine's usedPercent);
  // a summary without a tier keeps the dashboard's own fallback name.
  const bareFake = async (url) => {
    const target = String(url)
    if (target === OPENDESIGN_WORKSPACES_URL) return json({ activeWorkspaceId: 'ws2' })
    if (target.includes('/billing/preflight')) {
      return json({ codingPlan: { eligible: true, windows: [{ durationSeconds: 18000, usedCredits: '3', limitCredits: '0' }] } })
    }
    if (target.endsWith('/billing/summary')) return json({})
    return json({}, 404)
  }
  resetOpendesignEnginePlugin()
  configureEngineBridge({ fetchFn: bareFake })
  const bare = await fetchOpendesignQuotaEngine(session, bareFake)
  assert.deepEqual(bare.rows, [], 'a window with nothing to divide is left out; without a balance there is no wallet row either')
  assert.equal(bare.planType, 'Open Design', "the engine names the dashboard's own fallback, it invents no tier table")

  // an API key sign-in has no allowance to read (the control plane takes none)
  const pasted = opendesignSession({ runtimeKey: 'sk-amr-only', source: 'paste' })
  const withoutControl = await fetchOpendesignQuotaEngine(pasted, fetchFn)
  assert.deepEqual(withoutControl.rows, [])
  assert.equal(seen.length, 3, 'the paste session made no control-plane call')

  // a refused sign-in says so: the workspace read passes, the billing read 401s
  const refusedFake = async (url) => {
    if (String(url) === OPENDESIGN_WORKSPACES_URL) return json({ activeWorkspaceId: 'ws1' })
    return json({ error: { message: 'unauthenticated' } }, 401)
  }
  resetOpendesignEnginePlugin()
  configureEngineBridge({ fetchFn: refusedFake })
  await assert.rejects(
    fetchOpendesignQuotaEngine(session, refusedFake),
    /refused the account's sign-in/,
  )
})

// The pinned package's money() (index.mjs:222-225) answers "" — never "$NaN" —
// when neither billing read gave a balanceUsd (index.mjs:405). The shared
// fixture still mints '$NaN' there, so this test loads a money()-shaped module
// and pins the real contract: an empty balance is no wallet row, not $0.00.
test('no wallet row when the engine answers an empty balance', async (t) => {
  const dataDir = await mkdtemp(join(tmpdir(), 'opendesign-engine-'))
  t.after(() => rm(dataDir, { recursive: true, force: true }))
  await writeEngineCache(dataDir, {
    npm: OPENDESIGN_FIXTURE_NPM,
    version: OPENDESIGN_FIXTURE_VERSION,
    module: `export async function OpenDesignAuthPlugin() {
  return {
    auth: {
      methods: [{ type: 'oauth', authorize: async () => ({}) }],
      loader: async () => ({}),
      usage: async () => ({ plan: 'Open Design', balance: '', windows: [], signIn: 'kept' }),
    },
  }
}
`,
    engines: { opendesign: { npm: OPENDESIGN_FIXTURE_NPM, version: OPENDESIGN_FIXTURE_VERSION, integrity: 'sha512-fixture' } },
  })
  resetUpstreamEngineCache()
  resetOpendesignEnginePlugin()
  configureUpstreamEngine(join(dataDir, 'auth.json'))
  t.after(() => {
    resetUpstreamEngineCache()
    resetOpendesignEnginePlugin()
    resetEngineBridge()
    configureUpstreamEngine(undefined)
  })
  const session = opendesignSession({ runtimeKey: 'sk-amr-b', controlKey: 'vela_ctrl_a', account: 'ada@example.com' })
  const parsed = await fetchOpendesignQuotaEngine(session, async () => {
    throw new Error('the usage read made no wire call')
  })
  assert.deepEqual(parsed.rows, [], "the engine's empty-string balance is no wallet, not a made-up $0.00")
  assert.equal(parsed.planType, 'Open Design')
})

// ---- the hop and the panel -----------------------------------------------------

test('the engine hop forwards Completions to amr-link at the runtime key', async (t) => {
  const hops = []
  const fetchFn = async (url, init = {}) => {
    const target = String(url)
    if (target.endsWith('/chat/completions')) {
      hops.push({ url: target, body: JSON.parse(String(init.body)), headers: init.headers })
      return json({ id: 'chat', choices: [{ message: { role: 'assistant', content: 'ok' } }] })
    }
    return json({})
  }
  await withEngine(t, fetchFn)
  const proxy = createProxy({
    port: 0,
    apiKey: 'proxy-key-opendesign-test-xx',
    tokens: {
      opendesign: { session: async () => opendesignSession({ runtimeKey: 'sk-amr-a', controlKey: 'vela_ctrl_a' }) },
    },
    fetchFn,
  })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const response = await fetch(`http://127.0.0.1:${port}/opendesign/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer proxy-key-opendesign-test-xx', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'deepseek-v4-pro',
        messages: [{ role: 'user', content: 'hi' }],
        prompt_cache_key: 'codex-style',
        reasoning_effort: 'high',
      }),
    })
    assert.equal(response.status, 200)
    assert.equal(hops.length, 1)
    assert.equal(hops[0].url, OPENDESIGN_CHAT_URL)
    assert.equal(hops[0].headers.authorization, 'Bearer sk-amr-a')
    assert.equal(hops[0].headers['user-agent'], 'opencode-opendesign-auth/0.1.6', 'the package own UA, at the loaded engine version')
    assert.equal(OPENDESIGN_USER_AGENT, 'opencode-opendesign-auth/0.1.6')
    assert.equal(Object.hasOwn(hops[0].headers, 'session-id'), false)
    assert.equal(Object.hasOwn(hops[0].headers, 'x-grok-conv-id'), false)
    assert.equal(Object.hasOwn(hops[0].headers, 'x-task-id'), false)
    assert.equal(hops[0].body.prompt_cache_key, undefined)
    assert.equal(hops[0].body.reasoning_effort, 'high')
  } finally {
    await proxy.close()
  }
})

test('controller snapshot shows quota on every opendesign account', async (t) => {
  const dir = await mkdtemp(join(tmpdir(), 'opendesign-ctrl-'))
  t.after(() => rm(dir, { recursive: true, force: true }))
  const authPath = join(dir, 'auth.json')
  const first = opendesignSession({
    runtimeKey: 'sk-amr-a',
    controlKey: 'vela_ctrl-a',
    account: 'ada@example.com',
    uid: 'u1',
  })
  const second = opendesignSession({ runtimeKey: 'sk-amr-b', controlKey: 'vela_ctrl-b', account: 'bob@example.com' })
  await saveSession('opendesign', first, authPath)
  await saveSession('opendesign', second, authPath, { activate: false })
  const fetchFn = async (url) => {
    if (String(url) === OPENDESIGN_WORKSPACES_URL) return json({ activeWorkspaceId: 'ws1', personalMembershipTier: 'go' })
    if (String(url).includes('/billing/preflight')) return json(PREFLIGHT)
    if (String(url).endsWith('/billing/summary')) {
      return json({ membershipTier: 'go', balanceUsd: '1.5000' })
    }
    if (String(url).endsWith('/models')) {
      return json({ data: [{ id: 'deepseek-v4-pro', architecture: { input_modalities: ['text'] }, metadata: { cost: 'high', context_limit: 1048000, context_budget: 232000 } }] })
    }
    return json({})
  }
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    fetchFn,
    opendesignDiscover: async () => OPENDESIGN_MODELS,
  })
  // The engine drives the quota read; the controller's data dir hosts it.
  await writeEngineCache(dir, {
    npm: OPENDESIGN_FIXTURE_NPM,
    version: OPENDESIGN_FIXTURE_VERSION,
    module: OPENDESIGN_FIXTURE_MODULE,
    engines: { opendesign: { npm: OPENDESIGN_FIXTURE_NPM, version: OPENDESIGN_FIXTURE_VERSION, integrity: 'sha512-fixture' } },
  })
  resetUpstreamEngineCache()
  resetOpendesignEnginePlugin()
  configureUpstreamEngine(authPath)
  configureEngineBridge({ fetchFn })
  t.after(() => {
    resetUpstreamEngineCache()
    resetOpendesignEnginePlugin()
    resetEngineBridge()
    configureUpstreamEngine(undefined)
  })
  const snap = await controller.snapshot()
  assert.equal(snap.accounts.opendesign.accounts.length, 2)
  for (const row of snap.accounts.opendesign.accounts) {
    assert.ok(row.quota)
    assert.equal(JSON.stringify(row).includes('sk-amr-'), false)
    assert.equal(JSON.stringify(row).includes('vela_ctrl'), false)
  }
  assert.equal(snap.accounts.opendesign.accounts.some((row) => row.quota.planType === 'Design Plan Go'), true)
})
