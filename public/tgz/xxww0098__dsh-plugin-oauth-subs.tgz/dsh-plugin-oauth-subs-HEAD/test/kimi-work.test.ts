import assert from 'node:assert/strict'
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { AuthController } from '../lib/oauth/controller.js'
import { createProxy } from '../lib/oauth/proxy.js'
import { isPermanentRefreshFailure } from '../lib/oauth/tokens.js'
import {
  getSession,
  listStoredSessions,
  publicSession,
  saveSession,
} from '../lib/oauth/store.js'
import { catalogRows } from '../lib/catalog/index.js'
import {
  KIMI_WORK_API_BASE,
  KIMI_WORK_CHAT_URL,
  KIMI_WORK_MODELS_URL,
  KIMI_WORK_PLACEHOLDER,
  kimiWorkAccountRef,
  kimiWorkSession,
  readKimiWorkDesktop,
  refreshKimiWork,
} from '../lib/oauth/kimi-work/index.js'
import { applyKimiWorkCache, KIMI_WORK_STABLE_SESSION, kimiWorkCacheHeaders, kimiWorkCacheSessionId, resetKimiWorkPins } from '../lib/oauth/kimi-work/cache.js'
import { applyKimiWorkThinking, mapKimiWorkUsage } from '../lib/oauth/kimi-work/request.js'
import { toKimiWorkPickerModels } from '../lib/oauth/kimi-work/catalog.js'
import { importKimiWork, loginKimiWork, maybeAutoImportKimiWork } from '../lib/oauth/kimi-work/accounts.js'
import { FAMILY_IDS, assertDshServiceableProvider, buildProviders, familyOfProvider, harnessModelAlias } from '../lib/oauth/models.js'

function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })
}

async function tmpDir(t, tag) {
  const dir = await mkdtemp(join(tmpdir(), `kimi-work-${tag}-`))
  t.after(() => rm(dir, { recursive: true, force: true }))
  return dir
}

/** Point homedir() at a fixture home so the desktop file read is hermetic. */
function withHome(t, home) {
  const previous = process.env.HOME
  process.env.HOME = home
  t.after(() => {
    if (previous === undefined) delete process.env.HOME
    else process.env.HOME = previous
  })
}

async function writeDesktop(home, { workToken = 'desk-work-token', webToken = 'desk-web-token', userId = 'user-1', baseUrl = KIMI_WORK_API_BASE, raw } = {}) {
  const dir = join(home, 'Library', 'Application Support', 'kimi-desktop', 'daimon-share', 'daimon')
  await mkdir(dir, { recursive: true })
  const doc = raw ?? {
    credentials: {
      kimiCode: { apiKey: workToken, baseUrl },
      kimiWeb: { accessToken: webToken, userId },
    },
  }
  await writeFile(join(dir, 'config.json'), JSON.stringify(doc))
}

/** The checked upstream catalog shape (packages/kimi-work tests/fixtures/work-models.redacted.json). */
const FIXTURE_MODELS = {
  data: [
    { id: 'k3-agent', display_name: 'K3', context_length: 1000000, supports_image_in: true, supports_reasoning: true,
      reasoningEffortOptions: [{ effort: 'REASONING_EFFORT_LOW', displayName: 'Standard' }, { effort: 'REASONING_EFFORT_HIGH', displayName: 'High' }, { effort: 'REASONING_EFFORT_MAX', displayName: 'Max' }] },
    { id: 'k2d8-preview', display_name: 'K2.8 Preview', context_length: 1000000, supports_image_in: true, supports_reasoning: true,
      reasoningEffortOptions: [{ effort: 'REASONING_EFFORT_LOW' }, { effort: 'REASONING_EFFORT_HIGH' }, { effort: 'REASONING_EFFORT_MAX' }] },
  ],
}

test('the desktop file read accepts only the Work origin and all four fields', async (t) => {
  const home = await tmpDir(t, 'desktop')
  withHome(t, home)
  await writeDesktop(home, {})
  const read = readKimiWorkDesktop()
  assert.equal(read.workToken, 'desk-work-token')
  assert.equal(read.webToken, 'desk-web-token')
  assert.equal(read.uid, kimiWorkAccountRef('user-1'))
  assert.match(read.uid, /^[0-9a-f]{64}$/, 'the account reference is a hash, never the raw user id')

  // A Code-origin credential is refused, never substituted.
  await writeDesktop(home, { baseUrl: 'https://api.kimi.com/coding/v1' })
  assert.equal(readKimiWorkDesktop(), undefined)
  await writeDesktop(home, { workToken: '' })
  assert.equal(readKimiWorkDesktop(), undefined)
  await writeDesktop(home, { webToken: '' })
  assert.equal(readKimiWorkDesktop(), undefined)
  await writeDesktop(home, { userId: '' })
  assert.equal(readKimiWorkDesktop(), undefined)

  // BOM-prefixed JSON still parses (upstream strips the BOM before JSON.parse).
  await writeDesktop(home, {})
  const file = join(home, 'Library', 'Application Support', 'kimi-desktop', 'daimon-share', 'daimon', 'config.json')
  const body = await readFile(file, 'utf8')
  await writeFile(file, `\uFEFF${body}`)
  assert.equal(readKimiWorkDesktop()?.workToken, 'desk-work-token')

  // An empty home: no file, no sign-in.
  const empty = await tmpDir(t, 'desktop-empty')
  withHome(t, empty)
  assert.equal(readKimiWorkDesktop(), undefined)
})

test('a reference session carries no credential and the vault keeps real tokens out', async (t) => {
  const home = await tmpDir(t, 'session')
  withHome(t, home)
  await writeDesktop(home, { workToken: 'desk-work-token', webToken: 'desk-web-token', userId: 'user-1' })
  const dir = await tmpDir(t, 'vault')
  const authPath = join(dir, 'auth.json')

  const session = kimiWorkSession({ uid: kimiWorkAccountRef('user-1') })
  assert.equal(session.accessToken, KIMI_WORK_PLACEHOLDER)
  assert.equal(session.refreshToken, KIMI_WORK_PLACEHOLDER)
  assert.equal(session.account, 'Kimi Work (local)')
  assert.equal(session.source, 'desktop')
  assert.ok(session.expiresAt > Date.now() + 1e12, 'a reference session never preempts a refresh')

  await saveSession('kimi-work', session, authPath)
  const stored = await getSession('kimi-work', authPath)
  assert.equal(stored.account, 'Kimi Work (local)')
  assert.equal(stored.uid, kimiWorkAccountRef('user-1'))
  const vault = await readFile(authPath, 'utf8')
  assert.ok(!vault.includes('desk-work-token'), 'the Work credential never lands in auth.json')
  assert.ok(!vault.includes('desk-web-token'), 'the membership credential never lands in auth.json')
  assert.ok(!vault.includes('user-1'), 'the raw desktop user id never lands in auth.json')

  const shown = publicSession('kimi-work', stored)
  assert.equal(shown.account, 'Kimi Work (local)')
  assert.equal(shown.method, 'desktop')
  assert.equal(shown.methodLabel, 'desktop')
  assert.equal(shown.uid, undefined)
  assert.equal(shown.accessToken, undefined)
  assert.equal(shown.refreshToken, undefined)

  // Reconnect rebinds the one row in place: a desktop account change is a
  // reconnect, not a silent second account.
  await writeDesktop(home, { userId: 'user-2' })
  await saveSession('kimi-work', kimiWorkSession({ uid: kimiWorkAccountRef('user-2') }), authPath)
  const rows = await listStoredSessions('kimi-work', authPath)
  assert.equal(rows.length, 1)
  assert.equal(rows[0].session.uid, kimiWorkAccountRef('user-2'))
})

test('login probes the models endpoint, then saves the account reference', async (t) => {
  const home = await tmpDir(t, 'login')
  withHome(t, home)
  await writeDesktop(home, {})
  const dir = await tmpDir(t, 'login-vault')
  const authPath = join(dir, 'auth.json')
  await writeEngineCache(dir)
  t.after(() => { resetUpstreamEngineCache(); resetKimiWorkEnginePlugin(); configureUpstreamEngine(undefined) })
  const calls: any[] = []
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    fetchFn: async (url, init) => {
      calls.push({ url: String(url), init })
      return json(FIXTURE_MODELS)
    },
    kimiWorkAutoImport: false,
    kimiWorkDiscover: async () => [],
  })
  const started = await loginKimiWork(controller)
  assert.equal(started.mode, 'desktop')
  assert.equal(calls[0].url, KIMI_WORK_MODELS_URL)
  assert.equal(calls[0].init.headers.authorization, 'Bearer desk-work-token')
  const stored = await getSession('kimi-work', authPath)
  assert.equal(stored.uid, kimiWorkAccountRef('user-1'))
  assert.equal(stored.source, 'desktop')

  // A refused probe saves nothing and says why.
  const dir2 = await tmpDir(t, 'login-fail')
  const authPath2 = join(dir2, 'auth.json')
  await writeEngineCache(dir2)
  const refused = new AuthController({
    authPath: authPath2,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    fetchFn: async () => json({}, 401),
    kimiWorkAutoImport: false,
  })
  await assert.rejects(loginKimiWork(refused), /no usable local Kimi Work sign-in/)
  assert.equal(await getSession('kimi-work', authPath2), undefined)

  // importFrom: the same read-only import, skipped when the account is unchanged.
  const imported = await importKimiWork(controller)
  assert.equal(imported.source, 'desktop')
  assert.equal(imported.skipped, true)
  const empty = await tmpDir(t, 'import-empty')
  withHome(t, empty)
  await assert.rejects(importKimiWork(controller), /no local Kimi Work sign-in found/)
})

test('startup auto-import harvests the desktop sign-in once', async (t) => {
  const home = await tmpDir(t, 'auto')
  withHome(t, home)
  await writeDesktop(home, { userId: 'user-auto' })
  const dir = await tmpDir(t, 'auto-vault')
  const authPath = join(dir, 'auth.json')
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    fetchFn: async () => json(FIXTURE_MODELS),
    kimiWorkAutoImport: true,
    kimiWorkDiscover: async () => [],
  })
  await maybeAutoImportKimiWork(controller)
  assert.equal((await listStoredSessions('kimi-work', authPath)).length, 1)
  await maybeAutoImportKimiWork(controller)
  const again = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    fetchFn: async () => json(FIXTURE_MODELS),
    kimiWorkAutoImport: true,
  })
  await maybeAutoImportKimiWork(again)
  assert.equal((await listStoredSessions('kimi-work', authPath)).length, 1, 'one row per desktop account, not per start')
})

test('a desktop refresh re-reads the file; a missing file or a changed account is permanent', async (t) => {
  const home = await tmpDir(t, 'refresh')
  withHome(t, home)
  await writeDesktop(home, { userId: 'user-1' })
  const session = kimiWorkSession({ uid: kimiWorkAccountRef('user-1') })
  const fetchFn = async () => {
    throw new Error('a kimi-work refresh must never hit an endpoint')
  }
  const next = await refreshKimiWork(session, fetchFn)
  assert.equal(next.uid, session.uid)
  assert.equal(next.accessToken, KIMI_WORK_PLACEHOLDER, 'rotation changes nothing in the vault; the hop re-reads live')

  await writeDesktop(home, { userId: 'user-2' })
  const changed = await refreshKimiWork(session, fetchFn).then(() => undefined, (error) => error)
  assert.match(changed.message, /another account/)
  assert.equal(isPermanentRefreshFailure(changed), true)

  const empty = await tmpDir(t, 'refresh-empty')
  withHome(t, empty)
  const missing = await refreshKimiWork(session, fetchFn).then(() => undefined, (error) => error)
  assert.match(missing.message, /isn't signed in/)
  assert.equal(isPermanentRefreshFailure(missing), true)
})

test('the picker catalog caps the window, keeps every mapped effort and guards the payload', () => {
  const rows = toKimiWorkPickerModels(FIXTURE_MODELS)
  assert.deepEqual(rows.map((row) => row.id), ['k2d8-preview', 'k3-agent'])
  const k3 = rows.find((row) => row.id === 'k3-agent')
  assert.equal(k3.name, 'K3')
  assert.equal(k3.contextWindow, 262144, 'the XL context the server lists is capped at the standard window')
  assert.equal(k3.maxTokens, 32768)
  assert.deepEqual(k3.input, ['text', 'image'])
  assert.deepEqual(k3.reasoningEfforts, { low: 'low', high: 'high', max: 'max' })

  assert.throws(() => toKimiWorkPickerModels({ data: FIXTURE_MODELS.data, has_more: true }), /暂不可用/)
  assert.throws(() => toKimiWorkPickerModels({ data: Array.from({ length: 101 }, () => FIXTURE_MODELS.data[0]) }), /暂不可用/)
  assert.throws(() => toKimiWorkPickerModels({ data: [] }), /目录为空/)
  assert.throws(() => toKimiWorkPickerModels({ data: [{ ...FIXTURE_MODELS.data[0], reasoningEffortOptions: [{ effort: '9BAD' }] }] }), /思考档位/)
  assert.throws(() => toKimiWorkPickerModels({ data: [{ ...FIXTURE_MODELS.data[0], reasoningEffortOptions: 'nope' }] }), /思考档位/)
  // A well-formed but unmapped spelling is dropped, not guessed onto a rung.
  const unmapped = toKimiWorkPickerModels({ data: [{ ...FIXTURE_MODELS.data[0], reasoningEffortOptions: [{ effort: 'REASONING_EFFORT_NOT_A_LEVEL' }] }] })
  assert.equal(Object.hasOwn(unmapped[0], 'reasoningEfforts'), false)

  // STANDARD maps onto the low rung (Kimi displays LOW as Standard); an
  // unmapped spelling is dropped rather than guessed.
  const standard = toKimiWorkPickerModels({ data: [{ ...FIXTURE_MODELS.data[0], reasoningEffortOptions: [{ effort: 'REASONING_EFFORT_STANDARD' }, { effort: 'REASONING_EFFORT_ULTRA' }] }] })
  assert.deepEqual(standard[0].reasoningEfforts, { low: 'standard' })
  const nonThinking = toKimiWorkPickerModels({ data: [{ ...FIXTURE_MODELS.data[0], supports_reasoning: false, reasoningEffortOptions: [{ effort: 'REASONING_EFFORT_HIGH' }] }] })
  assert.equal(Object.hasOwn(nonThinking[0], 'reasoningEfforts'), false)
  const textOnly = toKimiWorkPickerModels({ data: [{ ...FIXTURE_MODELS.data[0], supports_image_in: false }] })
  assert.deepEqual(textOnly[0].input, ['text'])

  // The static floor carries the same two rows.
  assert.deepEqual(catalogRows('kimi-work').map((row: any) => row.id), ['k2d8-preview', 'k3-agent'])
  for (const row of catalogRows('kimi-work') as any[]) {
    assert.equal(row.contextWindow, 262144)
  }
})

test('the cache strip keeps DSH fields off the wire and parks growing system snapshots', () => {
  resetKimiWorkPins()
  const dirty = 'session 772f7f3a/foo'
  assert.equal(kimiWorkCacheSessionId(dirty), 'session-772f7f3a-foo')
  assert.equal(kimiWorkCacheSessionId(''), undefined)

  const first = applyKimiWorkCache({
    model: 'k3-agent',
    session_id: 'dsh-sess-1',
    prompt_cache_key: 'dsh-sess-1',
    prompt_cache_retention: '24h',
    prompt_cache_options: { ttl: '1h' },
    messages: [{ role: 'system', content: 'You are DSH.' }, { role: 'user', content: 'hi' }],
  })
  assert.equal(first.cacheSessionId, 'dsh-sess-1')
  assert.equal(Object.hasOwn(first.payload, 'session_id'), false)
  assert.equal(Object.hasOwn(first.payload, 'prompt_cache_key'), false)
  assert.equal(Object.hasOwn(first.payload, 'prompt_cache_retention'), false)
  assert.equal(Object.hasOwn(first.payload, 'prompt_cache_options'), false)
  assert.deepEqual(kimiWorkCacheHeaders(), {})
  assert.notEqual(KIMI_WORK_STABLE_SESSION, 'dsh-kimi', 'the fallback constant is this family\'s own')

  const fallback = applyKimiWorkCache({ model: 'k3-agent', messages: [] })
  assert.equal(fallback.cacheSessionId, KIMI_WORK_STABLE_SESSION)

  const second = applyKimiWorkCache({
    model: 'k3-agent',
    session_id: 'dsh-sess-1',
    messages: [
      { role: 'system', content: 'You are DSH.' },
      { role: 'system', content: 'extra instruction' },
      { role: 'user', content: 'hi again' },
    ],
  })
  assert.deepEqual(second.payload.messages, [
    { role: 'system', content: 'You are DSH.' },
    { role: 'user', content: 'hi again' },
    { role: 'system', content: 'extra instruction' },
  ], 'the pinned prefix stays first; the extra snapshot parks at the suffix')
  resetKimiWorkPins()
})

test('reasoning_effort maps onto the advertised rung; usage aliases map when present', () => {
  const row = { id: 'k3-agent', reasoningEfforts: { low: 'low', high: 'high', max: 'max' } }
  assert.equal(applyKimiWorkThinking({ model: 'k3-agent', reasoning_effort: 'high' }, row).reasoning_effort, 'high')
  assert.equal(applyKimiWorkThinking({ model: 'k3-agent', reasoning_effort: 'medium' }, row).reasoning_effort, 'high', 'an unmapped level takes the nearest rung up')
  assert.equal(applyKimiWorkThinking({ model: 'k3-agent', reasoning_effort: 'xhigh' }, row).reasoning_effort, 'max')
  assert.equal(applyKimiWorkThinking({ model: 'k3-agent', reasoning_effort: 'off' }, row).reasoning_effort, 'low', 'off falls to the lowest advertised rung — the row offers no off, and no unadvertised value is invented')
  assert.equal(applyKimiWorkThinking({ model: 'k3-agent' }, row).reasoning_effort, undefined, 'no choice made: nothing is sent')
  const plain = applyKimiWorkThinking({ model: 'k3-agent', reasoning_effort: 'high' }, { id: 'k3-agent' })
  assert.equal(Object.hasOwn(plain, 'reasoning_effort'), false, 'a row that does not advertise thinking loses the field')

  assert.deepEqual(mapKimiWorkUsage({ prompt_tokens: 10, cache_read_tokens: 4 }), { prompt_tokens: 10, cache_read_tokens: 4, prompt_tokens_details: { cached_tokens: 4 } })
  assert.deepEqual(mapKimiWorkUsage({ prompt_tokens: 10 }), { prompt_tokens: 10 }, 'absent stays absent')
})

test('the proxy serves the catalog models route and refuses responses', async (t) => {
  const proxy = createProxy({
    port: 0,
    apiKey: 'secret-key',
    fetchFn: async () => json({}),
    tokens: { 'kimi-work': { session: async () => kimiWorkSession({ uid: kimiWorkAccountRef('user-1') }) } },
  })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const models = await fetch(`http://127.0.0.1:${port}/kimi-work/v1/models`, { headers: { authorization: 'Bearer secret-key' } })
    assert.equal(models.status, 200)
    const list = await models.json()
    assert.deepEqual(list.data.map((row: any) => row.id), catalogRows('kimi-work').map((row: any) => row.id))

    const refused = await fetch(`http://127.0.0.1:${port}/kimi-work/v1/responses`, {
      method: 'POST',
      headers: { authorization: 'Bearer secret-key' },
      body: '{}',
    })
    assert.equal(refused.status, 501)
  } finally {
    await proxy.close()
  }
})

test('the harness route is a completions provider named after the family', () => {
  assert.equal(FAMILY_IDS.includes('kimi-work'), true)
  assert.equal(familyOfProvider('oauth-kimi-work'), 'kimi-work')
  const providers = buildProviders({
    prefix: 'oauth',
    origin: 'http://127.0.0.1:8318',
    loggedIn: { 'kimi-work': true },
  })
  const route = providers['oauth-kimi-work']
  assert.equal(route.displayName, 'Subs · Kimi Work · Chat')
  assert.equal(route.api, 'openai-completions')
  assert.equal(route.baseURL, 'http://127.0.0.1:8318/kimi-work')
  assert.ok(route.models.length >= 2)
  assert.ok(route.models.some((model: any) => model.reasoningEfforts?.low === 'low'))
  assertDshServiceableProvider('oauth-kimi-work', route)
  assert.equal(harnessModelAlias('oauth-kimi-work', 'k3-agent'), 'Kimi Work/k3-agent')
  assert.equal(buildProviders({ prefix: 'oauth', origin: 'http://127.0.0.1:8318', loggedIn: {} })['oauth-kimi-work'], undefined)
})

// —— 上游引擎试点（DSH_UPSTREAM_ENGINES 含 kimi-work；回退梯见 kimi-work/engine.ts） ——

import { configureUpstreamEngine, resetUpstreamEngineCache } from '../lib/upstream-engine/engine.js'
import {
  fetchKimiWorkQuota,
  resetKimiWorkEnginePlugin,
} from '../lib/oauth/kimi-work/engine.js'
import { writeEngineCache } from './upstream-engine-fixture.ts'

function configuredEngineDir(t) {
  return tmpDir(t, 'engine')
}

test('the engine drives the kimi-work hop', async (t) => {
  const home = await tmpDir(t, 'engine-home')
  withHome(t, home)
  await writeDesktop(home, {})
  const dataDir = await configuredEngineDir(t)
  await writeEngineCache(dataDir, { version: '0.1.4' })
  resetUpstreamEngineCache()
  resetKimiWorkEnginePlugin()
  configureUpstreamEngine(join(dataDir, 'auth.json'))
  t.after(() => { resetUpstreamEngineCache(); resetKimiWorkEnginePlugin(); configureUpstreamEngine(undefined) })

  const session = kimiWorkSession({ uid: kimiWorkAccountRef('user-1') })
  const seen: any[] = []
  const fetchFn = async (url, init) => {
    const headers = new Headers(init.headers)
    seen.push({
      url: String(url),
      headers: Object.fromEntries(headers),
      body: init.body === undefined ? undefined : JSON.parse(init.body.toString()),
    })
    return new Response('data: [DONE]\n\n', { status: 200, headers: { 'content-type': 'text/event-stream' } })
  }
  const proxy = createProxy({
    port: 0,
    apiKey: 'secret-key',
    fetchFn,
    tokens: { 'kimi-work': { session: async () => session } },
  })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const ok = await fetch(`http://127.0.0.1:${port}/kimi-work/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer secret-key', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'k3-agent',
        session_id: 'dsh-sess-9',
        reasoning_effort: 'medium',
        stream: true,
        messages: [{ role: 'user', content: 'ping' }],
      }),
    })
    assert.equal(ok.status, 200)
    assert.match(await ok.text(), /\[DONE\]/)
    assert.equal(seen.length, 1)
    // The engine retargets to the same Work gateway and injects its own auth surface.
    assert.equal(seen[0].url, KIMI_WORK_CHAT_URL)
    assert.equal(seen[0].headers.authorization, 'Bearer desk-work-token')
    assert.equal(seen[0].headers['user-agent'], 'Magpie Kimi Work provider/test')
    // What stays ours: no DSH session fields, no other family's cache headers.
    assert.equal(seen[0].headers.cookie, undefined)
    assert.equal(seen[0].headers['session-id'], undefined)
    assert.equal(seen[0].headers['x-grok-conv-id'], undefined)
    assert.equal(seen[0].body.session_id, undefined)
    assert.equal(seen[0].body.prompt_cache_key, undefined)
    assert.equal(seen[0].body.reasoning_effort, 'high')

    // A desktop account change is refused by the engine's own uid check —
    // translated to the hop's 401 (the refresh gate's auth semantics), never
    // a transport retry ladder ending in a 502.
    await writeDesktop(home, { userId: 'user-2' })
    const switched = await fetch(`http://127.0.0.1:${port}/kimi-work/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer secret-key', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'k3-agent', messages: [{ role: 'user', content: 'ping' }] }),
    })
    assert.equal(switched.status, 401)
    assert.deepEqual(await switched.json(), { error: { message: 'Kimi Work desktop sign-in expired' } })
    assert.equal(seen.length, 1, 'the switched account never reached the gateway')
  } finally {
    await proxy.close()
  }
})

test('an unavailable engine fails the hop — no fallback lane (ruling 2026-10-18)', async (t) => {
  const home = await tmpDir(t, 'engine-fail-home')
  withHome(t, home)
  await writeDesktop(home, {})
  const dataDir = await configuredEngineDir(t)
  resetUpstreamEngineCache()
  resetKimiWorkEnginePlugin()
  configureUpstreamEngine(join(dataDir, 'auth.json'))
  t.after(() => { resetUpstreamEngineCache(); resetKimiWorkEnginePlugin(); configureUpstreamEngine(undefined) })

  const session = kimiWorkSession({ uid: kimiWorkAccountRef('user-1') })
  let hops = 0
  const fetchFn = async (url) => {
    // The engine bootstrap's packument probe rides this fetchFn too (its
    // failure is exactly why the load fails); only the chat wire is counted.
    if (String(url).includes('/chat/completions')) hops += 1
    return new Response('{}', { status: 200 })
  }
  const proxy = createProxy({
    port: 0,
    apiKey: 'secret-key',
    fetchFn,
    tokens: { 'kimi-work': { session: async () => session } },
  })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const answer = await fetch(`http://127.0.0.1:${port}/kimi-work/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer secret-key', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'k3-agent', messages: [{ role: 'user', content: 'ping' }] }),
    })
    assert.notEqual(answer.status, 200, 'a family without its engine is down, not silently degraded')
    assert.equal(hops, 0, 'nothing reaches any wire when the engine is missing')
  } finally {
    await proxy.close()
  }
})

test('the engine reads usage and maps the shared-allowance row', async (t) => {
  const home = await tmpDir(t, 'engine-quota-home')
  withHome(t, home)
  await writeDesktop(home, {})
  const dataDir = await configuredEngineDir(t)
  await writeEngineCache(dataDir, { version: '0.1.4' })
  resetUpstreamEngineCache()
  resetKimiWorkEnginePlugin()
  configureUpstreamEngine(join(dataDir, 'auth.json'))
  t.after(() => { resetUpstreamEngineCache(); resetKimiWorkEnginePlugin(); configureUpstreamEngine(undefined) })

  const session = kimiWorkSession({ uid: kimiWorkAccountRef('user-1') })
  const viaEngine = await fetchKimiWorkQuota(session, async () => {
    throw new Error('the engine fixture answers usage without any HTTP call')
  })
  assert.equal(viaEngine.rows.length, 1)
  assert.equal(viaEngine.rows[0].key, 'membership')
  assert.equal(viaEngine.rows[0].usedPercent, 42)
  assert.equal(viaEngine.rows[0].remainingPercent, 58)
})

test('a dead desktop sign-in answers 401 once and fires the hop refresh gate', async (t) => {
  const home = await tmpDir(t, 'engine-401-home')
  withHome(t, home)
  await writeDesktop(home, {})
  const dataDir = await configuredEngineDir(t)
  await writeEngineCache(dataDir, { version: '0.1.4' })
  resetUpstreamEngineCache()
  resetKimiWorkEnginePlugin()
  configureUpstreamEngine(join(dataDir, 'auth.json'))
  t.after(() => { resetUpstreamEngineCache(); resetKimiWorkEnginePlugin(); configureUpstreamEngine(undefined) })

  const session = kimiWorkSession({ uid: kimiWorkAccountRef('user-1') })
  let chats = 0
  const fetchFn = async () => {
    chats += 1
    return new Response('data: [DONE]\n\n', { status: 200, headers: { 'content-type': 'text/event-stream' } })
  }
  // forcedRefresh's production shape (tokens.ts): sourceOf feeds refreshNow,
  // which re-reads the file; a switched account stays refused, so it resolves
  // without a session and the hop forwards its own 401.
  const refreshes: any[] = []
  const proxy = createProxy({
    port: 0,
    apiKey: 'secret-key',
    fetchFn,
    tokens: {
      'kimi-work': {
        session: async () => session,
        sourceOf: () => ({ id: session.account, session }),
        refreshNow: async (id, failedAccessToken) => {
          refreshes.push({ id, failedAccessToken })
          return undefined
        },
      },
    },
  })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    await writeDesktop(home, { userId: 'user-2' })
    const started = Date.now()
    const answer = await fetch(`http://127.0.0.1:${port}/kimi-work/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer secret-key', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'k3-agent', messages: [{ role: 'user', content: 'ping' }] }),
    })
    assert.equal(answer.status, 401)
    assert.deepEqual(await answer.json(), { error: { message: 'Kimi Work desktop sign-in expired' } })
    assert.deepEqual(refreshes, [{ id: 'Kimi Work (local)', failedAccessToken: 'local-desktop-session' }])
    assert.equal(chats, 0, 'a refused account never reaches the gateway')
    assert.ok(Date.now() - started < 2000, `no transport backoff on a permanent 401 (took ${Date.now() - started}ms)`)
  } finally {
    await proxy.close()
  }
})

test('controller snapshot shows quota on every kimi-work account', { timeout: 20_000 }, async (t) => {
  const home = await tmpDir(t, 'engine-snapshot-home')
  withHome(t, home)
  await writeDesktop(home, {})
  const dataDir = await configuredEngineDir(t)
  await writeEngineCache(dataDir, { version: '0.1.4' })
  const authPath = join(dataDir, 'auth.json')
  // One row: the vault rebinds in place on reconnect — a desktop signs in as
  // exactly one Work account (kimi-work/index.mjs current()).
  await saveSession('kimi-work', kimiWorkSession({ uid: kimiWorkAccountRef('user-1') }), authPath)
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    fetchFn: async () => {
      throw new Error('the engine fixture answers usage without any HTTP call')
    },
    kimiWorkAutoImport: false,
    kimiWorkDiscover: async () => [],
  })
  t.after(() => { resetUpstreamEngineCache(); resetKimiWorkEnginePlugin(); configureUpstreamEngine(undefined) })
  const snap = await controller.snapshot()
  const family = snap.accounts['kimi-work']
  assert.equal(family.accounts.length, 1)
  for (const row of family.accounts) {
    assert.ok(row.quota)
    assert.equal(row.quota.status, 'ready', JSON.stringify(row.quota))
    assert.equal(row.quota.rows[0].key, 'membership')
    assert.equal(row.quota.rows[0].usedPercent, 42)
    assert.equal(row.quota.rows[0].remainingPercent, 58)
  }
})

