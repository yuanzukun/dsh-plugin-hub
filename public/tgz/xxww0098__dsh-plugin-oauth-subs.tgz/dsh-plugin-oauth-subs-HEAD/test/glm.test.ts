import assert from 'node:assert/strict'
import { createCipheriv, createHash, randomBytes } from 'node:crypto'
import { mkdtemp } from 'node:fs/promises'
import { arch as osArch, homedir, platform, tmpdir, userInfo } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import {
  GLM_APP_VERSION,
  GLM_ANTHROPIC_DIRECT_URLS,
  GLM_ANTHROPIC_VERSION,
  GLM_CLIENT_ID,
  GLM_CLI_INIT_URL,
  GLM_CLI_USER_AGENT,
  GLM_GATEWAY_ORIGIN,
  GLM_MODELS,
  GLM_TITLE,
  GLM_USER_AGENT,
  accountFromJwt,
  completeGlmCli,
  displayGlmAccount,
  isGlmOpaqueAccount,
  pickGlmHumanAccount,
  glmCliInit,
  glmCliProvider,
  glmAnthropicDirectUrl,
  glmAnthropicGatewayUrl,
  glmAnthropicUrl,
  glmCodingUrl,
  glmDesktopHeaders,
  glmQuotaUrl,
  glmSession,
  glmAnthropicHeaders,
  glmUpstreamHeaders,
  isGlmAppAccount,
  normalizeGlmRegion,
  parseCliInit,
  parseCliPoll,
  parseGlmExpiresAt,
  unwrapEnvelope,
} from '../lib/oauth/glm/index.js'
import {
  applyGlmAnthropicThinking,
  glmMaxTokens,
  mapGlmChatUsage,
  normalizeGlmAnthropicBody,
  normalizeGlmChatBody,
  resetGlmSystemPins,
} from '../lib/oauth/glm/request.js'
import { stabilizeGlmAnthropicMessageCache } from '../lib/oauth/glm/cache.js'
import { GlmCliFlowManager, glmLoginFailureMessage } from '../lib/oauth/glm/cli-flow.js'
import { decodeZcodeCredentialValue, glmKeyCandidateFromZcodeConfig } from '../lib/oauth/glm/import.js'
import { QuotaStore } from '../lib/oauth/quota.js'
import {
  fetchGlmQuota,
  glmCardStamp,
  mergeGlmToolUsage,
  parseGlmQuota,
  parseGlmResetCards,
} from '../lib/oauth/glm/quota.js'
import { glmResetCardUrl } from '../lib/oauth/glm/index.js'
import { buildProviders } from '../lib/oauth/models.js'
import { AuthController } from '../lib/oauth/controller.js'
import { accountIdOf, listAccounts, publicSession, replaceAccountId, saveSession } from '../lib/oauth/store.js'

test('normalizeGlmChatBody remaps DSH developer roles to system', () => {
  const out = normalizeGlmChatBody({
    model: 'glm-5.3-flash',
    messages: [
      { role: 'developer', content: 'You are DSH.\n\n# AGENTS.md' },
      { role: 'user', content: 'hello' },
    ],
  })
  assert.deepEqual(out.messages, [
    { role: 'system', content: 'You are DSH.\n\n# AGENTS.md' },
    { role: 'user', content: 'hello' },
  ])
  assert.equal(out.model, 'glm-5.3-flash')
  assert.deepEqual(out.thinking, { type: 'enabled', clear_thinking: false })
})

test('normalizeGlmChatBody keeps system / user / assistant / tool and tool ids', () => {
  const messages = [
    { role: 'system', content: 'You are GLM.' },
    { role: 'user', content: 'run it' },
    { role: 'assistant', content: null, tool_calls: [{ id: 'call_1', type: 'function', function: { name: 'ls', arguments: '{}' } }] },
    { role: 'tool', tool_call_id: 'call_1', content: 'ok' },
  ]
  const out = normalizeGlmChatBody({ model: 'glm-5.3', messages })
  assert.deepEqual(out.messages, messages)
  assert.equal(out.thinking.type, 'enabled')
  assert.equal(out.thinking.clear_thinking, false)
})

test('normalizeGlmChatBody copies assistant reasoning to reasoning_content', () => {
  const out = normalizeGlmChatBody({
    model: 'glm-5.3',
    messages: [
      { role: 'assistant', content: 'done', reasoning: 'I counted first' },
      { role: 'assistant', content: 'kept', reasoning_content: 'official', reasoning: 'alias' },
    ],
  })
  assert.equal(out.messages[0].reasoning_content, 'I counted first')
  assert.equal(out.messages[0].reasoning, 'I counted first')
  assert.equal(out.messages[1].reasoning_content, 'official')
  assert.equal(out.messages[1].reasoning, 'alias')
  assert.equal(out.thinking.clear_thinking, false)
})

test('normalizeGlmChatBody does not force-disable Turbo thinking', () => {
  const idle = normalizeGlmChatBody({
    model: 'glm-5-turbo',
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.equal(idle.thinking, undefined)

  const on = normalizeGlmChatBody({
    model: 'glm-5-turbo',
    thinking: { type: 'enabled' },
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.deepEqual(on.thinking, { type: 'enabled', clear_thinking: false })

  const off = normalizeGlmChatBody({
    model: 'glm-5-turbo',
    thinking: { type: 'disabled' },
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.deepEqual(off.thinking, { type: 'disabled' })
})

test('normalizeGlmChatBody maps unknown instructional roles to system and leaves input-only bodies', () => {
  const out = normalizeGlmChatBody({
    messages: [
      { role: 'instruction', content: 'be brief' },
      { role: 'user', content: 'go' },
    ],
  })
  assert.equal(out.messages[0].role, 'system')
  assert.equal(out.messages[1].role, 'user')

  const inputOnly = {
    model: 'glm-5.3',
    input: [{ role: 'developer', content: 'sys' }, { role: 'user', content: 'go' }],
  }
  const rewritten = normalizeGlmChatBody(inputOnly)
  assert.equal(rewritten.input[0].role, 'developer')
  assert.equal(rewritten.thinking.clear_thinking, false)
})

test('normalizeGlmChatBody parks extra leading system snapshots after the conversation', () => {
  resetGlmSystemPins()
  const first = normalizeGlmChatBody({
    model: 'glm-5.3-flash',
    session_id: 'session-cache-glm',
    prompt_cache_key: 'should-not-leave',
    messages: [
      { role: 'developer', content: 'You are an AI agent.' },
      { role: 'user', content: 'analyze the repo' },
    ],
  })
  assert.deepEqual(first.messages.map((message) => message.role), ['system', 'user'])
  assert.equal(first.messages[0].content, 'You are an AI agent.')
  assert.equal(first.user, 'session-cache-glm')
  assert.equal(first.prompt_cache_key, undefined)

  const later = normalizeGlmChatBody({
    model: 'glm-5.3-flash',
    session_id: 'session-cache-glm',
    messages: [
      { role: 'system', content: 'You are an AI agent.' },
      { role: 'system', content: 'Current runtime context. This snapshot supersedes earlier runtime-context snapshots.' },
      { role: 'user', content: 'analyze the repo' },
      { role: 'assistant', content: 'ok' },
    ],
  })
  assert.equal(later.messages[0].content, 'You are an AI agent.')
  assert.equal(later.messages[1].role, 'user')
  assert.equal(later.messages[1].content, 'analyze the repo')
  assert.equal(later.messages.at(-1).role, 'system')
  assert.match(later.messages.at(-1).content, /Current runtime context/)
  assert.equal(later.user, 'session-cache-glm')
  resetGlmSystemPins()
})

test('normalizeGlmChatBody keeps a matching leading system pinned across identical follow-ups', () => {
  resetGlmSystemPins()
  const body = {
    model: 'glm-5.3',
    prompt_cache_key: 'session-glm-stable',
    messages: [
      { role: 'system', content: 'stable prefix' },
      { role: 'user', content: 'one' },
    ],
  }
  const first = normalizeGlmChatBody(body)
  const second = normalizeGlmChatBody({
    ...body,
    messages: [
      { role: 'system', content: 'stable prefix' },
      { role: 'user', content: 'two' },
    ],
  })
  assert.equal(first.messages[0], second.messages[0])
  assert.equal(second.messages[1].content, 'two')
  assert.equal(second.messages.length, 2)
  assert.equal(second.prompt_cache_key, undefined)
  assert.equal(second.user, 'session-glm-stable')
  resetGlmSystemPins()
})

test('normalizeGlmAnthropicBody pins system, cache_control, metadata.user_id', () => {
  resetGlmSystemPins()
  const first = normalizeGlmAnthropicBody({
    model: 'glm-5.3',
    session_id: 'session-glm-anthropic',
    prompt_cache_key: 'drop-me',
    system: 'You are an AI agent.',
    messages: [{ role: 'user', content: 'analyze the repo' }],
  })
  assert.equal(first.max_tokens, 128_000)
  assert.equal(first.prompt_cache_key, undefined)
  assert.equal(first.metadata.user_id, 'session-glm-anthropic')
  assert.deepEqual(first.system, [
    { type: 'text', text: 'You are an AI agent.', cache_control: { type: 'ephemeral' } },
  ])
  assert.equal(first.thinking.type, 'enabled')
  assert.equal(first.thinking.clear_thinking, false)

  const later = normalizeGlmAnthropicBody({
    model: 'glm-5.3',
    session_id: 'session-glm-anthropic',
    system: 'You are an AI agent.\n\nCurrent runtime context. This snapshot supersedes earlier runtime-context snapshots.',
    messages: [
      { role: 'user', content: 'analyze the repo' },
      { role: 'assistant', content: 'ok' },
    ],
  })
  assert.equal(later.system[0].text, 'You are an AI agent.')
  assert.deepEqual(later.system[0].cache_control, { type: 'ephemeral' })
  assert.equal(later.system[1].text.includes('Current runtime context'), true)
  assert.equal(later.system[1].cache_control, undefined)
  assert.equal(later.metadata.user_id, 'session-glm-anthropic')
  resetGlmSystemPins()
})

test('normalizeGlmAnthropicBody does not force Turbo thinking', () => {
  const idle = normalizeGlmAnthropicBody({
    model: 'glm-5-turbo',
    max_tokens: 1024,
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.equal(idle.thinking, undefined)
  assert.equal(idle.max_tokens, 1024)
})

test('normalizeGlmAnthropicBody sends the ZCode catalog thinking shape', () => {
  resetGlmSystemPins()
  const low = normalizeGlmAnthropicBody({
    model: 'glm-5.3',
    max_tokens: 16,
    thinking: { type: 'adaptive', display: 'summarized' },
    output_config: { effort: 'low' },
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.deepEqual(low.thinking, { type: 'enabled', clear_thinking: false })
  assert.deepEqual(low.output_config, { effort: 'low' })
  // Anthropic-only knobs ZCode never sends for GLM.
  assert.equal(low.thinking.budget_tokens, undefined)
  assert.equal(low.thinking.display, undefined)
  assert.equal(low.thinking.effort, undefined)

  const max = normalizeGlmAnthropicBody({
    model: 'glm-5.3-flash',
    max_tokens: 16,
    thinking: { type: 'enabled', budget_tokens: 16384, display: 'summarized' },
    output_config: { effort: 'max' },
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.deepEqual(max.thinking, { type: 'enabled', clear_thinking: false })
  assert.deepEqual(max.output_config, { effort: 'max' })

  const bare = normalizeGlmAnthropicBody({
    model: 'glm-5.3',
    max_tokens: 16,
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.deepEqual(bare.thinking, { type: 'enabled', clear_thinking: false })
  assert.equal(bare.output_config, undefined)
  assert.deepEqual(bare.messages[0].content, [
    { type: 'text', text: 'hi', cache_control: { type: 'ephemeral' } },
  ])
})

test('GLM-5.2 keeps the official disabled switch; Turbo and other ids stay conservative', () => {
  const off = applyGlmAnthropicThinking({
    model: 'glm-5.2',
    thinking: { type: 'disabled' },
    output_config: { effort: 'high' },
  })
  assert.deepEqual(off.thinking, { type: 'disabled' })
  assert.equal(off.output_config, undefined)

  const on = applyGlmAnthropicThinking({
    model: 'glm-5.2',
    thinking: { type: 'adaptive' },
    output_config: { effort: 'max' },
  })
  assert.deepEqual(on.thinking, { type: 'enabled', clear_thinking: false })
  assert.deepEqual(on.output_config, { effort: 'max' })

  const turbo = applyGlmAnthropicThinking({ model: 'glm-5-turbo', thinking: { type: 'enabled' } })
  assert.deepEqual(turbo.thinking, { type: 'enabled', clear_thinking: false })
  assert.equal(turbo.output_config, undefined)

  const turboOff = applyGlmAnthropicThinking({ model: 'glm-5-turbo', thinking: { type: 'disabled' } })
  assert.deepEqual(turboOff.thinking, { type: 'disabled' })

  const unknown = applyGlmAnthropicThinking({
    model: 'glm-4.7',
    thinking: { type: 'enabled', budget_tokens: 4096 },
  })
  assert.deepEqual(unknown.thinking, { type: 'enabled', budget_tokens: 4096, clear_thinking: false })
})

test('glmMaxTokens uses the ZCode catalog output caps per model', () => {
  assert.deepEqual(GLM_MODELS.map((model) => model.id), ['glm-5.3-flashx', 'glm-5.3', 'glm-5.3-flash', 'glm-5-turbo'])
  assert.equal(glmMaxTokens('glm-5.3'), 128_000)
  assert.equal(glmMaxTokens('glm-5.3-flash'), 128_000)
  assert.equal(glmMaxTokens('glm-5.3-flashx'), 128_000)
  assert.equal(glmMaxTokens('glm-5.2'), 128_000)
  assert.equal(glmMaxTokens('glm-5-turbo'), 64_000)
  const turbo = normalizeGlmAnthropicBody({ model: 'glm-5-turbo', messages: [{ role: 'user', content: 'hi' }] })
  assert.equal(turbo.max_tokens, 64_000)
})

test('stabilizeGlmAnthropicMessageCache rolls one breakpoint to the latest non-system message', () => {
  const rolled = stabilizeGlmAnthropicMessageCache([
    { role: 'user', content: [{ type: 'text', text: 'one', cache_control: { type: 'ephemeral' } }] },
    { role: 'assistant', content: 'ok' },
    { role: 'user', content: [{ type: 'tool_result', tool_use_id: 't1', content: 'rows' }] },
  ])
  assert.equal(rolled[0].content[0].cache_control, undefined)
  assert.deepEqual(rolled[2].content[0].cache_control, { type: 'ephemeral' })

  const stringContent = stabilizeGlmAnthropicMessageCache([{ role: 'user', content: 'plain string' }])
  assert.deepEqual(stringContent[0].content, [
    { type: 'text', text: 'plain string', cache_control: { type: 'ephemeral' } },
  ])

  const assistantLast = stabilizeGlmAnthropicMessageCache([
    { role: 'user', content: [{ type: 'text', text: 'one' }] },
    { role: 'assistant', content: [{ type: 'text', text: 'tail' }] },
  ])
  assert.deepEqual(assistantLast[1].content[0].cache_control, { type: 'ephemeral' })

  const noNonSystem = stabilizeGlmAnthropicMessageCache([{ role: 'system', content: 'sys' }])
  assert.deepEqual(noNonSystem, [{ role: 'system', content: 'sys' }])
})

test('GLM Completions leftover maps cache_read aliases and asks for stream usage', () => {
  const streamed = normalizeGlmChatBody({
    model: 'glm-5.3',
    stream: true,
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.equal(streamed.stream_options.include_usage, true)
  const anth = normalizeGlmAnthropicBody({
    model: 'glm-5.3',
    stream: true,
    max_tokens: 16,
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.equal(anth.stream_options, undefined)
  assert.equal(mapGlmChatUsage({ prompt_tokens: 12, cache_read_input_tokens: 9 }).prompt_tokens_details.cached_tokens, 9)
  assert.equal(mapGlmChatUsage({ prompt_tokens: 12 }).prompt_tokens_details, undefined)
})

test('GLM Completions and Anthropic system pins do not collide', () => {
  resetGlmSystemPins()
  const chat = normalizeGlmChatBody({
    model: 'glm-5.3',
    session_id: 'same-session',
    messages: [{ role: 'system', content: 'chat-sys' }, { role: 'user', content: 'hi' }],
  })
  const anth = normalizeGlmAnthropicBody({
    model: 'glm-5.3',
    session_id: 'same-session',
    system: 'anth-sys',
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.equal(chat.messages[0].content, 'chat-sys')
  assert.equal(anth.system[0].text, 'anth-sys')
  assert.deepEqual(anth.system[0].cache_control, { type: 'ephemeral' })
  resetGlmSystemPins()
})

test('unwrapEnvelope accepts ZCode code 0 and biz code 200', () => {
  assert.equal(unwrapEnvelope({ code: 0, data: { ok: true } }, 'x').ok, true)
  assert.equal(unwrapEnvelope({ code: 200, success: true, data: { ok: true } }, 'x').ok, true)
  assert.throws(() => unwrapEnvelope({ code: 401, msg: 'denied' }, 'login'), /denied/)
})

test('normalizeGlmRegion maps ZCode ids to zai / bigmodel', () => {
  assert.equal(normalizeGlmRegion('zai'), 'zai')
  assert.equal(normalizeGlmRegion('bigmodel'), 'bigmodel')
  assert.equal(normalizeGlmRegion('zcode'), 'bigmodel')
  assert.equal(normalizeGlmRegion('cn'), 'bigmodel')
  assert.equal(glmCliProvider('zai'), 'zai')
  assert.equal(glmCliProvider('bigmodel'), 'bigmodel')
  // Official hop is the ZCode Coding Plan gateway, not the model endpoint.
  assert.equal(glmAnthropicUrl('zai'), 'https://zcode.z.ai/api/v1/ultra-zai/anthropic/v1/messages')
  assert.equal(glmAnthropicUrl('bigmodel'), 'https://zcode.z.ai/api/v1/ultra/anthropic/v1/messages')
  assert.equal(glmAnthropicGatewayUrl('zai'), glmAnthropicUrl('zai'))
  assert.equal(glmAnthropicGatewayUrl('bigmodel'), glmAnthropicUrl('bigmodel'))
  assert.equal(GLM_GATEWAY_ORIGIN, 'https://zcode.z.ai')
  assert.equal(glmAnthropicDirectUrl('zai'), 'https://api.z.ai/api/anthropic/v1/messages')
  assert.equal(glmAnthropicDirectUrl('bigmodel'), 'https://open.bigmodel.cn/api/anthropic/v1/messages')
  assert.equal(GLM_ANTHROPIC_DIRECT_URLS.zai, glmAnthropicDirectUrl('zai'))
})

test('parseCliInit reads flow_id and authorize_url', () => {
  const started = parseCliInit({
    code: 0,
    data: {
      flow_id: 'flow-1',
      authorize_url: `https://chat.z.ai/api/oauth/authorize?client_id=${GLM_CLIENT_ID}`,
      poll_interval_sec: 2,
      expires_at: Date.now() + 60_000,
    },
  })
  assert.equal(started.flowId, 'flow-1')
  assert.equal(started.authorizeUrl.includes(GLM_CLIENT_ID), true)
  assert.equal(started.intervalMs, 2000)
})

test('parseCliPoll stays pending until ready with zai access_token', () => {
  assert.equal(parseCliPoll({ code: 0, data: { status: 'pending' } }).ready, false)
  const ready = parseCliPoll({
    code: 0,
    data: {
      status: 'ready',
      token: 'zcode-jwt',
      zai: { access_token: 'oauth-access' },
      user: { email: 'dev@z.ai', id: 'u1' },
    },
  })
  assert.equal(ready.ready, true)
  assert.equal(ready.oauthAccess, 'oauth-access')
  assert.equal(ready.email, 'dev@z.ai')
})

test('parseCliPoll reads the provider token for the region, never the zcode JWT', () => {
  // Official readers only take data[providerId].access_token
  // (cli-oauth.ts parseReadyData / webAuthService) — the zcode JWT is
  // Start-Plan only, and bigmodel.cn answers 401 for it.
  const ready = parseCliPoll({
    code: 0,
    data: {
      status: 'ready',
      token: 'bm-jwt',
      bigmodel: { access_token: 'bm-oauth' },
      user: { email: 'dev@bigmodel.cn' },
    },
  }, 'bigmodel')
  assert.equal(ready.oauthAccess, 'bm-oauth')
  assert.equal(ready.zcodeJwt, 'bm-jwt')

  const zai = parseCliPoll({
    code: 0,
    data: {
      status: 'ready',
      token: 'z-jwt',
      zai: { access_token: 'zai-oauth' },
      user: { email: 'dev@z.ai' },
    },
  }, 'zai')
  assert.equal(zai.oauthAccess, 'zai-oauth')

  // The legacy `zcode` spelling must not shadow the provider token.
  // A ready poll without data.bigmodel.access_token is unusable; the legacy
  // zcode spelling must not stand in for the provider token.
  assert.throws(
    () => parseCliPoll({
      code: 0,
      data: {
        status: 'ready',
        token: 'bm-jwt',
        zcode: { access_token: 'bm-jwt-copy' },
        user: { email: 'dev@bigmodel.cn' },
      },
    }, 'bigmodel'),
    /without access token/,
  )
})

test('parseCliInit treats expires_at as epoch seconds and floors the poll interval', () => {
  const seconds = Math.floor(Date.now() / 1000) + 900
  const started = parseCliInit({
    code: 0,
    data: {
      flow_id: 'flow-sec',
      authorize_url: 'https://chat.z.ai/api/oauth/authorize?state=s1',
      poll_interval_sec: 0.2,
      expires_at: seconds,
    },
  })
  assert.equal(started.expiresAt, seconds * 1000)
  assert.equal(started.intervalMs, 1000)
  assert.equal(parseGlmExpiresAt(seconds), seconds * 1000)
  assert.throws(
    () => parseCliInit({
      code: 0,
      data: { flow_id: 'f', authorize_url: 'http://chat.z.ai/authorize', poll_interval_sec: 2, expires_at: seconds },
    }),
    /non-https/,
  )
})

test('parseCliPoll surfaces failed / unknown as terminal states', () => {
  const failed = parseCliPoll({ code: 0, data: { status: 'failed', msg: 'user denied' } })
  assert.equal(failed.ready, false)
  assert.equal(failed.failed, true)
  assert.equal(failed.message, 'user denied')
  assert.equal(parseCliPoll({ code: 0, data: { status: 'expired' } }).unknown, true)
  assert.equal(parseCliPoll({ code: 0, data: { status: 'pending' } }).unknown, false)
})

test('GlmCliFlowManager fails immediately on a failed poll and survives a transient 5xx', async () => {
  const initFor = (flowId, state) => json({
    code: 0,
    data: {
      flow_id: flowId,
      authorize_url: `https://chat.z.ai/api/oauth/authorize?state=${state}`,
      poll_interval_sec: 1,
      expires_at: Math.floor(Date.now() / 1000) + 300,
    },
  })
  // BigModel mints its Coding Plan key with the poll OAuth token as the biz
  // bearer (no z/login), so the mock serves that chain besides init.
  const attempts = []
  const fetchFn = async (url, init = {}) => {
    const href = String(url)
    if (href.includes('/oauth/cli/init')) return initFor('flow-live', 's1')
    if (href.includes('/oauth/cli/poll')) {
      attempts.push(href)
      if (attempts.length === 1) return json({ code: 0, msg: 'gateway hiccup' }, { status: 503 })
      return json({
        code: 0,
        data: {
          status: 'ready',
          token: 'bm-jwt',
          bigmodel: { access_token: 'bm-oauth' },
          user: { email: 'dev@bigmodel.cn' },
        },
      })
    }
    if (href.includes('/getCustomerInfo')) {
      assert.equal(init.headers.authorization, 'Bearer bm-oauth')
      return json({
        code: 200,
        data: {
          organizations: [{
            organizationId: 'org-1',
            isDefault: true,
            projects: [{ projectId: 'proj-1', isDefault: true }],
          }],
        },
      })
    }
    if (href.endsWith('/api_keys') && (init.method ?? 'GET') === 'GET') {
      return json({ code: 200, data: [{ apiKey: 'aaaa1111', name: 'dsh-plugin-oauth-subs' }] })
    }
    if (href.includes('/copy/')) {
      return json({ code: 200, data: { secretKey: 'bbbb222233334444' } })
    }
    throw new Error(`unexpected ${href}`)
  }
  const flows = new GlmCliFlowManager()
  const started = await flows.start('glm', { region: 'bigmodel', fetchFn })
  assert.equal(started.authorizeUrl.includes('chat.z.ai'), true)
  const session = await started.waitToken()
  assert.equal(session.accessToken, 'aaaa1111.bbbb222233334444')
  assert.equal(session.oauthAccess, 'bm-oauth')
  assert.equal(session.region, 'bigmodel')
  assert.equal(attempts.length, 2)

  const failingFetch = async (url) => (String(url).includes('/oauth/cli/init')
    ? initFor('flow-fail', 's2')
    : json({ code: 0, data: { status: 'failed', msg: 'user denied' } }))
  const failing = new GlmCliFlowManager()
  const startedFail = await failing.start('glm', { region: 'bigmodel', fetchFn: failingFetch })
  await assert.rejects(startedFail.waitToken(), /glm authorization failed: user denied/)

  // Upstream incident: the server kills the flow while exchanging the browser
  // code (zai-org/feedback#718) — surface the incident and the key fallback.
  const invalidFlowFetch = async (url) => (String(url).includes('/oauth/cli/init')
    ? initFor('flow-3004', 's3')
    : json({ code: 3004, msg: 'invalid_flow' }))
  const invalidFlow = new GlmCliFlowManager()
  const startedInvalid = await invalidFlow.start('glm', { region: 'bigmodel', fetchFn: invalidFlowFetch })
  await assert.rejects(startedInvalid.waitToken(), /invalid_flow.*feedback#718.*Coding Plan API key/s)
})

test('glm CLI login rides one X-Device-Mid from init through every poll', async () => {
  const calls = []
  const fetchFn = async (url, init = {}) => {
    const href = String(url)
    calls.push({ href, deviceMid: init.headers['X-Device-Mid'] })
    if (href.includes('/oauth/cli/init')) {
      return json({
        code: 0,
        data: {
          flow_id: 'flow-mid',
          authorize_url: 'https://chat.z.ai/api/oauth/authorize?state=mid',
          poll_interval_sec: 1,
          expires_at: Math.floor(Date.now() / 1000) + 300,
        },
      })
    }
    if (href.includes('/oauth/cli/poll')) {
      return json({ code: 0, data: { status: 'failed', msg: 'probe complete' } })
    }
    throw new Error(`unexpected ${href}`)
  }
  const flows = new GlmCliFlowManager()
  const started = await flows.start('glm', { region: 'zai', fetchFn })
  // A terminal failed poll ends the loop before the mint chain runs.
  await assert.rejects(started.waitToken(), /glm authorization failed: probe complete/)
  const init = calls.find((call) => call.href.includes('/oauth/cli/init'))
  const polls = calls.filter((call) => call.href.includes('/oauth/cli/poll'))
  assert.equal(polls.length, 1)
  assert.match(init.deviceMid, /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/)
  // One device id end to end (magpie `call` sends the flow's deviceMid on every
  // zcode.z.ai request): a poll that fell back to the any-device uuid would
  // make init/poll disagree server-side with no test going red.
  for (const poll of polls) {
    assert.equal(poll.deviceMid, init.deviceMid)
  }
})

test('glmLoginFailureMessage maps upstream OAuth incidents to the key fallback', () => {
  assert.match(
    glmLoginFailureMessage(new Error('glm cli poll failed: invalid_flow')),
    /feedback#718/,
  )
  assert.match(
    glmLoginFailureMessage(new Error('glm cli poll failed (HTTP 200): {"code":2007,"msg":"http error"}')),
    /feedback#523/,
  )
  assert.equal(
    glmLoginFailureMessage(new Error('glm authorization failed: user denied')),
    'glm authorization failed: user denied',
  )
})

test('glmSession stores a durable never-expiring key', () => {
  const session = glmSession({ accessToken: 'id.secret', account: 'dev@z.ai' })
  assert.equal(session.accessToken, 'id.secret')
  assert.equal(session.refreshToken, 'id.secret')
  assert.equal(session.account, 'dev@z.ai')
  assert.equal(session.region, 'zai')
  assert.ok(session.expiresAt > Date.now() + 1e12)
})

function assertZcodeDesktopFingerprint(headers) {
  const blob = JSON.stringify(headers)
  assert.equal(headers['user-agent'], 'ZCode/3.14.3 ai-sdk/anthropic/3.0.81')
  assert.equal(headers['user-agent'], GLM_USER_AGENT)
  assert.equal(headers['X-ZCode-App-Version'], '3.14.3')
  assert.equal(headers['X-ZCode-App-Version'], GLM_APP_VERSION)
  assert.equal(headers['X-ZCode-Agent'], 'glm')
  assert.equal(headers['HTTP-Referer'], 'https://zcode.z.ai')
  assert.equal(headers.referer, 'https://zcode.z.ai')
  assert.equal(headers['X-Title'], 'Z Code@electron')
  assert.equal(headers['X-Title'], GLM_TITLE)
  // buildCliZCodeSourceHeaders + createRuntimePlatformHeaders.
  assert.equal(headers['X-Release-Channel'], 'production')
  assert.equal(typeof headers['X-Client-Language'], 'string')
  assert.equal(typeof headers['X-Client-Timezone'], 'string')
  assert.equal(headers['X-Platform'], `${process.platform}-${osArch()}`)
  assert.match(headers['X-Os-Category'], /^(macos|windows|linux)$/)
  assert.equal(typeof headers['X-Os-Version'], 'string')
  // runner-attribution.ts: main / subagent / other.
  assert.equal(headers['x-zcode-session-type'], 'main')
  assert.match(headers['x-zcode-trace-id'], /^[0-9a-f]+$/)
  assert.match(headers['x-request-id'], /^[0-9a-f]+$/)
  assert.match(headers['x-query-id'], /^[0-9a-f]+$/)
  assert.equal(headers['x-session-id'], 'dsh-glm')
  assert.equal(blob.includes('dsh-plugin-oauth-subs'), false)
}

test('glmUpstreamHeaders is ZCode Desktop 3.14.3, not this plugin', () => {
  const session = glmSession({ accessToken: 'id.secret', account: 'dev@z.ai' })
  const first = glmUpstreamHeaders(session)
  const second = glmUpstreamHeaders(session)
  assert.equal(first.authorization, 'Bearer id.secret')
  // The plan key rides both spellings, as magpie's loader sends it
  // (`x-api-key` is also the Anthropic SDK's own spelling).
  assert.equal(first['x-api-key'], 'id.secret')
  assert.equal(first.accept, 'application/json')
  assertZcodeDesktopFingerprint(first)
  assertZcodeDesktopFingerprint(second)
  assert.equal(first['x-session-id'], second['x-session-id'])
  assert.notEqual(first['x-zcode-trace-id'], second['x-zcode-trace-id'])
  assert.notEqual(first['x-request-id'], second['x-request-id'])
  assert.notEqual(first['x-query-id'], second['x-query-id'])
  assert.equal(glmDesktopHeaders()['x-session-id'], first['x-session-id'])
})

test('glmAnthropicHeaders is Desktop plus anthropic-version', () => {
  const session = glmSession({ accessToken: 'id.secret', account: 'dev@z.ai' })
  const headers = glmAnthropicHeaders(session, 'session-anth')
  assert.equal(headers.authorization, 'Bearer id.secret')
  assert.equal(headers['x-api-key'], 'id.secret')
  assert.equal(headers['anthropic-version'], GLM_ANTHROPIC_VERSION)
  assert.equal(headers['anthropic-version'], '2023-06-01')
  assert.equal(headers['x-session-id'], 'session-anth')
  assert.equal(headers['user-agent'], GLM_USER_AGENT)
  assert.equal(JSON.stringify(headers).includes('dsh-plugin-oauth-subs'), false)
})

test('glmDesktopHeaders x-session-id equals a pinned DSH session, else the stable constant', async () => {
  const session = glmSession({ accessToken: 'id.secret', account: 'dev@z.ai' })
  const pinned = glmUpstreamHeaders(session, 'session-772f7f3a-332c-4e0c-bff1-6074123474e3')
  assert.equal(pinned['x-session-id'], 'session-772f7f3a-332c-4e0c-bff1-6074123474e3')
  assert.equal(glmDesktopHeaders('session-cache-1')['x-session-id'], 'session-cache-1')
  assert.equal(glmDesktopHeaders()['x-session-id'], 'dsh-glm')
  // A fresh module instance (restart / hot reload) keeps the same header.
  const reloaded = await import(`../lib/oauth/glm/index.js?reload=${process.pid}`)
  assert.equal(reloaded.glmDesktopHeaders()['x-session-id'], 'dsh-glm')
  assert.notEqual(pinned['x-request-id'], glmUpstreamHeaders(session, 'session-cache-1')['x-request-id'])
})

test('glmCodingUrl and glmQuotaUrl split Z.ai vs BigModel', () => {
  assert.equal(glmCodingUrl('zai').startsWith('https://api.z.ai/'), true)
  assert.equal(glmCodingUrl('bigmodel').startsWith('https://open.bigmodel.cn/'), true)
  assert.equal(glmQuotaUrl('zcode').includes('open.bigmodel.cn'), true)
})

test('completeGlmCli mints id.secret through business login + copy', async () => {
  const calls = []
  const fetchFn = async (url, init = {}) => {
    const href = String(url)
    calls.push({ href, method: init.method ?? 'GET', body: init.body, headers: init.headers })
    if (href.includes('/api/auth/z/login')) {
      return json({ code: 200, success: true, data: { access_token: 'biz' } })
    }
    if (href.includes('/getCustomerInfo')) {
      return json({
        code: 200,
        data: {
          organizations: [{
            organizationId: 'org-1',
            isDefault: true,
            projects: [{ projectId: 'proj-1', isDefault: true }],
          }],
        },
      })
    }
    if (href.endsWith('/api_keys') && (init.method ?? 'GET') === 'GET') {
      return json({ code: 200, data: [] })
    }
    if (href.endsWith('/api_keys') && init.method === 'POST') {
      return json({ code: 200, data: { apiKey: 'aaaa1111', name: 'dsh-plugin-oauth-subs' } })
    }
    if (href.includes('/copy/')) {
      return json({ code: 200, data: { secretKey: 'bbbb222233334444' } })
    }
    throw new Error(`unexpected ${href}`)
  }
  const session = await completeGlmCli(
    { ready: true, oauthAccess: 'oauth-access', email: 'dev@z.ai' },
    { fetchFn },
  )
  assert.equal(session.accessToken, 'aaaa1111.bbbb222233334444')
  assert.equal(session.account, 'dev@z.ai')
  assert.equal(session.region, 'zai')
  assert.equal(calls[0].href.includes('/api/auth/z/login'), true)
  assert.equal(GLM_CLI_INIT_URL.includes('zcode.z.ai'), true)
  for (const call of calls) {
    assertZcodeDesktopFingerprint(call.headers)
    assert.equal(String(call.href).includes('dsh-plugin-oauth-subs'), false)
  }
})

test('completeGlmCli for BigModel mints with the OAuth token as biz bearer', async () => {
  const calls = []
  const fetchFn = async (url, init = {}) => {
    const href = String(url)
    calls.push({ href, method: init.method ?? 'GET', auth: init.headers.authorization })
    if (href.includes('/api/auth/z/login')) throw new Error('z/login must not be called for BigModel')
    if (href.includes('/getCustomerInfo')) {
      return json({
        code: 200,
        data: {
          organizations: [{
            organizationId: 'org-1',
            isDefault: true,
            projects: [{ projectId: 'proj-1', isDefault: true }],
          }],
        },
      })
    }
    if (href.endsWith('/api_keys') && (init.method ?? 'GET') === 'GET') {
      return json({ code: 200, data: [] })
    }
    if (href.endsWith('/api_keys') && init.method === 'POST') {
      return json({ code: 200, data: { apiKey: 'aaaa1111', name: 'dsh-plugin-oauth-subs' } })
    }
    if (href.includes('/copy/')) {
      return json({ code: 200, data: { secretKey: 'bbbb222233334444' } })
    }
    if (href.includes('/subscription/list')) {
      // The zcodePlan-equivalent probe carries the minted key, not the OAuth bearer.
      return json({ code: 200, data: [] })
    }
    throw new Error(`unexpected ${href}`)
  }
  const session = await completeGlmCli(
    { ready: true, oauthAccess: 'bm-oauth', zcodeJwt: 'jwt', email: 'cn@bigmodel.cn' },
    { fetchFn, region: 'bigmodel' },
  )
  assert.equal(session.accessToken, 'aaaa1111.bbbb222233334444')
  assert.equal(session.oauthAccess, 'bm-oauth')
  assert.equal(session.region, 'bigmodel')
  assert.equal(session.account, 'cn@bigmodel.cn')
  assert.equal(session.zcodeJwt, 'jwt')
  for (const call of calls) {
    if (call.href.includes('/subscription/list')) {
      assert.equal(call.auth, 'Bearer aaaa1111.bbbb222233334444')
      continue
    }
    assert.equal(call.auth, 'Bearer bm-oauth')
  }

  // Minting fails: BigModel degrades to the OAuth token (identity/quota stay
  // usable; chat keeps its pre-fix behavior) and still records oauthAccess.
  const deadFetch = async (url) => json({ code: 500, msg: 'z.ai用户信息异常' }, { status: 500 })
  const degraded = await completeGlmCli(
    { ready: true, oauthAccess: 'bm-oauth', zcodeJwt: 'jwt', email: 'cn@bigmodel.cn' },
    { fetchFn: deadFetch, region: 'bigmodel' },
  )
  assert.equal(degraded.accessToken, 'bm-oauth')
  assert.equal(degraded.oauthAccess, 'bm-oauth')

  // No provider token to mint with and nothing to degrade to: the login fails
  // with the mint error instead of silently storing a chatless bearer.
  await assert.rejects(
    completeGlmCli(
      { ready: true, oauthAccess: undefined, zcodeJwt: 'jwt', email: 'cn@bigmodel.cn' },
      { fetchFn: deadFetch, region: 'bigmodel' },
    ),
    /failed \(HTTP 500\)/,
  )
})

test('upgradeGlmLegacyBearers re-mints stored BigModel OAuth bearers once', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  const { getSession, saveSession } = await import('../lib/oauth/store.js')
  const { upgradeGlmLegacyBearers } = await import('../lib/oauth/glm/accounts.js')
  const legacyJwt = 'eyJhbGciOiJIUzI1NiJ9.eyJlbWFpbCI6ImNuQGJpZ21vZGVsLmNuIn0.c2lnbmF0dXJl'
  await saveSession('glm', glmSession({
    accessToken: legacyJwt,
    account: 'cn@bigmodel.cn',
    region: 'bigmodel',
  }), authPath)
  const mints = []
  const ctl = {
    authPath,
    fetchFn: async (url, init = {}) => {
      const href = String(url)
      mints.push(href)
      if (href.includes('/getCustomerInfo')) {
        return json({
          code: 200,
          data: {
            organizations: [{
              organizationId: 'org-1',
              isDefault: true,
              projects: [{ projectId: 'proj-1', isDefault: true }],
            }],
          },
        })
      }
      if (href.endsWith('/api_keys') && (init.method ?? 'GET') === 'GET') {
        return json({ code: 200, data: [{ apiKey: 'cccc3333', name: 'dsh-plugin-oauth-subs' }] })
      }
      if (href.includes('/copy/')) {
        return json({ code: 200, data: { secretKey: 'dddd444455556666' } })
      }
      throw new Error(`unexpected ${href}`)
    },
  }
  await upgradeGlmLegacyBearers(ctl)
  const upgraded = await getSession('glm', authPath)
  assert.equal(upgraded.accessToken, 'cccc3333.dddd444455556666')
  assert.equal(upgraded.oauthAccess, legacyJwt)
  // bearer probe + customer lookup + key list + copy
  assert.equal(mints.length, 4)

  // Once per process: a second sweep must not re-mint (and a dead fetch would
  // otherwise leave the legacy bearer in place).
  await upgradeGlmLegacyBearers({ authPath, fetchFn: async () => { throw new Error('must not be called') } })
  assert.equal((await getSession('glm', authPath)).accessToken, 'cccc3333.dddd444455556666')

  // A failed mint keeps the stored legacy bearer untouched.
  const dir2 = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath2 = join(dir2, 'auth.json')
  await saveSession('glm', glmSession({
    accessToken: legacyJwt,
    account: 'cn2@bigmodel.cn',
    region: 'bigmodel',
  }), authPath2)
  await upgradeGlmLegacyBearers({ authPath: authPath2, fetchFn: async () => json({ code: 500, msg: 'no' }, { status: 500 }) })
  const kept = await getSession('glm', authPath2)
  assert.equal(kept.accessToken, legacyJwt)

  // `id.secret` bearers and Z.ai sessions are never touched.
  const dir3 = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath3 = join(dir3, 'auth.json')
  await saveSession('glm', glmSession({ accessToken: 'aaaa1111.bbbb2222', account: 'cn@bigmodel.cn', region: 'bigmodel' }), authPath3)
  await saveSession('glm', glmSession({ accessToken: legacyJwt, account: 'dev@z.ai', region: 'zai' }), authPath3)
  await upgradeGlmLegacyBearers({ authPath: authPath3, fetchFn: async () => { throw new Error('must not be called') } })
  const rows = await (await import('../lib/oauth/store.js')).listStoredSessions('glm', authPath3)
  assert.equal(rows.length, 2)
})

test('glmCliInit posts provider id bigmodel for BigModel', async () => {
  let body
  let headers
  const fetchFn = async (url, init = {}) => {
    body = init.body
    headers = init.headers
    return json({
      code: 0,
      data: {
        flow_id: 'flow-cn',
        authorize_url: 'https://bigmodel.cn/login?app_id=zcode',
        poll_interval_sec: 2,
        expires_at: Date.now() + 60_000,
      },
    })
  }
  const started = await glmCliInit({ region: 'bigmodel', fetchFn, pollToken: 'poll' })
  assert.equal(JSON.parse(body).provider, 'bigmodel')
  assert.equal(started.region, 'bigmodel')
  assert.equal(started.authorizeUrl.includes('bigmodel.cn'), true)
  assert.equal(headers['user-agent'], GLM_CLI_USER_AGENT)
  assert.equal(headers['user-agent'], 'ZCode/3.14.3')
  assert.equal(JSON.stringify(headers).includes('dsh-plugin-oauth-subs'), false)
})

test('parseGlmQuota maps credit windows and plan level', () => {
  const parsed = parseGlmQuota({
    data: {
      level: 'pro',
      list: [
        { type: 'CREDIT_LIMIT', usage: 12000, currentValue: 3000, duration: '5h' },
        { type: 'CREDIT_LIMIT', usage: 60000, currentValue: 10000, duration: 'week' },
      ],
    },
  })
  assert.equal(parsed.planType, 'Pro')
  assert.equal(parsed.rows.length, 2)
  assert.equal(parsed.rows[0].kind, 'primary')
  assert.equal(parsed.rows[0].remaining, 9000)
  assert.equal(parsed.rows[1].kind, 'weekly')
})

test('parseGlmQuota kinds screenshot-like CREDIT_LIMIT plus weekly and MCP', () => {
  const parsed = parseGlmQuota({
    code: 200,
    success: true,
    data: {
      level: 'lite',
      limits: [
        { type: 'CREDIT_LIMIT', unit: 3, number: 5, usage: 2000, currentValue: 0, remaining: 2000, percentage: 0 },
        { type: 'CREDIT_LIMIT', unit: 3, number: 5, usage: 2000, currentValue: 880, remaining: 1120, percentage: 44 },
        { type: 'CREDIT_LIMIT', unit: 6, number: 1, usage: 10_000, currentValue: 4400, remaining: 5600, percentage: 44 },
        {
          type: 'TIME_LIMIT',
          unit: 5,
          number: 1,
          usage: 1000,
          currentValue: 0,
          remaining: 1000,
          percentage: 0,
          usageDetails: [
            { modelCode: 'search-prime', usage: 0 },
            { modelCode: 'web-reader', usage: 0 },
            { modelCode: 'zread', usage: 0 },
          ],
        },
      ],
    },
  })
  assert.equal(parsed.planType, 'Lite')
  assert.deepEqual(parsed.rows.map((row) => row.kind), ['primary', 'weekly', 'mcp'])
  assert.equal(parsed.rows[0].used, 880)
  assert.equal(parsed.rows[0].total, 2000)
  assert.equal(parsed.rows[0].remainingPercent, 56)
  assert.equal(parsed.rows[1].total, 10_000)
  assert.equal(parsed.rows[2].product, 'ZCode MCP')
  assert.equal(parsed.rows[2].used, 0)
  assert.equal(parsed.rows[2].total, 1000)
  assert.equal(parsed.rows.some((row) => row.kind === 'cycle'), false)
})

test('parseGlmQuota reads a no-cap window as 0 used, not the vendor 100%', () => {
  // magpie #366 (zhipuLimits.windows): a limit whose whole is told as 0 has
  // no cap (an older plan's) and the vendor may still stamp it 100% used.
  const parsed = parseGlmQuota({
    code: 200,
    success: true,
    data: {
      level: 'max',
      limits: [
        { type: 'CREDIT_LIMIT', unit: 3, number: 5, usage: 0, percentage: 100 },
        { type: 'CREDIT_LIMIT', unit: 6, number: 1, usage: 60_000, currentValue: 30_000, remaining: 30_000 },
      ],
    },
  })
  const primary = parsed.rows.find((row) => row.kind === 'primary')
  assert.equal(primary.usedPercent, 0)
  assert.equal(primary.remainingPercent, 100)
  assert.equal(primary.used, undefined)
  assert.equal(primary.total, undefined)
  const weekly = parsed.rows.find((row) => row.kind === 'weekly')
  assert.equal(weekly.usedPercent, 50)
})

test('parseGlmQuota trusts the amounts over a stale percentage and derives used from remaining', () => {
  const parsed = parseGlmQuota({
    data: {
      level: 'pro',
      limits: [
        // Both whole and remaining told: used is the difference (800) and the
        // arithmetic (40%) wins over the vendor's percentage (99).
        { type: 'CREDIT_LIMIT', unit: 3, number: 5, usage: 2000, remaining: 1200, percentage: 99 },
      ],
    },
  })
  assert.equal(parsed.rows[0].kind, 'primary')
  assert.equal(parsed.rows[0].used, 800)
  assert.equal(parsed.rows[0].usedPercent, 40)
  assert.equal(parsed.rows[0].remainingPercent, 60)
})

test('mergeGlmToolUsage fills MCP when quota/limit only has credit windows', () => {
  const credits = parseGlmQuota({
    data: {
      level: 'lite',
      limits: [
        { type: 'CREDIT_LIMIT', unit: 3, number: 5, usage: 2000, currentValue: 0 },
        { type: 'CREDIT_LIMIT', unit: 6, number: 1, usage: 10_000, currentValue: 1200 },
      ],
    },
  })
  assert.deepEqual(credits.rows.map((row) => row.kind), ['primary', 'weekly'])
  const merged = mergeGlmToolUsage(credits, {
    data: {
      list: [{
        type: 'TIME_LIMIT',
        name: 'ZCode MCP',
        usage: 1000,
        currentValue: 12,
        remaining: 988,
        usageDetails: [{ modelCode: 'web-reader', usage: 12 }],
      }],
    },
  })
  assert.deepEqual(merged.rows.map((row) => row.kind), ['primary', 'weekly', 'mcp'])
  assert.equal(merged.rows[2].used, 12)
})

test('completeGlmCli for BigModel without poll email reads JWT email', async () => {
  const token = jwt({ email: 'cn@bigmodel.cn', preferred_username: 'cn@bigmodel.cn' })
  const session = await completeGlmCli(
    { ready: true, oauthAccess: 'oauth', zcodeJwt: token, accountId: 'zcode' },
    { fetchFn: async (url) => { throw new Error(`unexpected ${url}`) }, region: 'bigmodel' },
  )
  // Minting is dead here, so BigModel degrades to the OAuth token as the
  // bearer; identity still comes from the JWT, no userinfo call needed.
  assert.equal(session.accessToken, 'oauth')
  assert.equal(session.zcodeJwt, token)
  assert.equal(session.account, 'cn@bigmodel.cn')
  assert.equal(isGlmAppAccount(session.account), false)
})

test('pickGlmHumanAccount and displayGlmAccount reject opaque ZCode ids', () => {
  assert.equal(pickGlmHumanAccount('dnarplz6'), undefined)
  assert.equal(pickGlmHumanAccount('zcode', 'dnarplz6', '12345'), undefined)
  assert.equal(isGlmOpaqueAccount('dnarplz6'), true)
  assert.equal(isGlmOpaqueAccount('zcode'), true)
  assert.equal(isGlmOpaqueAccount('12345'), true)
  assert.equal(isGlmAppAccount('dnarplz6'), false)
  assert.equal(pickGlmHumanAccount('dnarplz6', 'zcode', 'live@bigmodel.cn'), 'live@bigmodel.cn')
  assert.equal(pickGlmHumanAccount('张三'), '张三')
  assert.equal(displayGlmAccount({ account: 'dnarplz6', accessToken: 'plain-key' }), undefined)
  assert.equal(displayGlmAccount({ account: 'zcode', accessToken: 'plain-key' }), undefined)
  assert.equal(publicSession('glm', {
    accessToken: 'plain-key',
    refreshToken: 'plain-key',
    expiresAt: 1,
    account: 'dnarplz6',
    region: 'bigmodel',
  }).account, undefined)
  const token = jwt({ sub: 'dnarplz6', user_id: 'dnarplz6', id: 'dnarplz6' })
  assert.equal(accountFromJwt(token), undefined)
  assert.equal(glmSession({ accessToken: 'a.b', account: 'dnarplz6', accountId: 'dnarplz6', region: 'bigmodel' }).account, undefined)
})

test('completeGlmCli for BigModel poll user.id fetches userinfo', async () => {
  const token = jwt({ sub: 'dnarplz6', user_id: 'dnarplz6' })
  const calls = []
  const session = await completeGlmCli(
    { ready: true, oauthAccess: 'oauth', zcodeJwt: token, accountId: 'dnarplz6' },
    {
      fetchFn: async (url) => {
        calls.push(String(url))
        if (String(url).includes('getCustomerInfo')) {
          return json({
            code: 200,
            data: { email: 'from-userinfo@bigmodel.cn', customerName: 'dnarplz6', id: 'dnarplz6' },
          })
        }
        throw new Error(`unexpected ${url}`)
      },
      region: 'bigmodel',
    },
  )
  assert.equal(session.account, 'from-userinfo@bigmodel.cn')
  assert.equal(isGlmOpaqueAccount(session.account), false)
  assert.ok(calls.some((href) => href.includes('open.bigmodel.cn')))
})

test('completeGlmCli omits account when poll user.id has empty userinfo', async () => {
  const token = jwt({ sub: 'dnarplz6' })
  const session = await completeGlmCli(
    { ready: true, oauthAccess: 'oauth', zcodeJwt: token, accountId: 'dnarplz6' },
    {
      fetchFn: async (url) => {
        if (String(url).includes('getCustomerInfo')) {
          return json({ code: 200, data: { id: 'dnarplz6', customerName: 'dnarplz6' } })
        }
        throw new Error(`unexpected ${url}`)
      },
      region: 'bigmodel',
    },
  )
  assert.equal(session.account, undefined)
})

test('completeGlmCli for BigModel without poll email reads userinfo', async () => {
  const token = jwt({ sub: 'zcode', user_id: 'zcode' })
  const calls = []
  const session = await completeGlmCli(
    { ready: true, oauthAccess: 'oauth', zcodeJwt: token, accountId: 'zcode' },
    {
      fetchFn: async (url) => {
        calls.push(String(url))
        if (String(url).includes('getCustomerInfo')) {
          return json({ code: 200, data: { email: 'from-userinfo@bigmodel.cn', customerName: 'zcode' } })
        }
        throw new Error(`unexpected ${url}`)
      },
      region: 'bigmodel',
    },
  )
  assert.equal(session.account, 'from-userinfo@bigmodel.cn')
  assert.ok(calls.some((href) => href.includes('open.bigmodel.cn')))
})

test('publicSession never returns zcode for a GLM vault row', () => {
  const token = jwt({ email: 'live@bigmodel.cn' })
  const stale = {
    accessToken: token,
    refreshToken: token,
    expiresAt: 1,
    account: 'zcode',
    region: 'bigmodel',
    zcodeJwt: token,
  }
  const pub = publicSession('glm', stale)
  assert.equal(pub.account, 'live@bigmodel.cn')
  assert.notEqual(pub.account, 'zcode')
  assert.equal(displayGlmAccount({ account: 'zcode', accessToken: 'plain-key' }), undefined)
  assert.equal(publicSession('glm', {
    accessToken: 'plain-key',
    refreshToken: 'plain-key',
    expiresAt: 1,
    account: 'zcode',
    region: 'bigmodel',
  }).account, undefined)
  assert.equal(accountFromJwt(token), 'live@bigmodel.cn')
})

test('snapshot rewrites a zcode@bigmodel vault to the JWT email', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const path = join(dir, 'auth.json')
  const token = jwt({ email: 'rewrite@bigmodel.cn' })
  await saveSession('glm', {
    accessToken: token,
    refreshToken: token,
    expiresAt: Date.now() + 1e15,
    account: 'zcode',
    region: 'bigmodel',
    zcodeJwt: token,
  }, path)
  assert.equal(accountIdOf('glm', { account: 'zcode', region: 'bigmodel' }), 'zcode@bigmodel')
  const controller = new AuthController({
    authPath: path,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async (url) => {
      if (String(url).includes('/quota/limit') || String(url).includes('/tool-usage')) {
        return json({ code: 200, data: { level: 'lite', limits: [] } })
      }
      throw new Error(`unexpected ${url}`)
    },
  })
  const snap = await controller.snapshot()
  assert.equal(snap.accounts.glm.account, 'rewrite@bigmodel.cn')
  assert.equal(snap.accounts.glm.accounts[0].account, 'rewrite@bigmodel.cn')
  assert.equal(snap.accounts.glm.accounts[0].id, 'rewrite@bigmodel.cn@bigmodel')
  const roster = await listAccounts('glm', path)
  assert.equal(roster[0].id, 'rewrite@bigmodel.cn@bigmodel')
  assert.equal(roster.some((row) => row.id === 'zcode@bigmodel' || row.account === 'zcode'), false)
})

test('snapshot rewrites a vault account opaque user.id to the userinfo email', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const path = join(dir, 'auth.json')
  const token = jwt({ sub: 'dnarplz6', user_id: 'dnarplz6' })
  await saveSession('glm', {
    accessToken: token,
    refreshToken: token,
    expiresAt: Date.now() + 1e15,
    account: 'dnarplz6',
    region: 'bigmodel',
    zcodeJwt: token,
  }, path)
  assert.equal(accountIdOf('glm', { account: 'dnarplz6', region: 'bigmodel' }), 'dnarplz6@bigmodel')
  assert.equal(pickGlmHumanAccount('dnarplz6'), undefined)
  const controller = new AuthController({
    authPath: path,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async (url) => {
      if (String(url).includes('getCustomerInfo')) {
        return json({ code: 200, data: { email: 'rewrite@bigmodel.cn', customerName: 'dnarplz6' } })
      }
      if (String(url).includes('/quota/limit') || String(url).includes('/tool-usage')) {
        return json({ code: 200, data: { level: 'lite', limits: [] } })
      }
      throw new Error(`unexpected ${url}`)
    },
  })
  const snap = await controller.snapshot()
  assert.equal(snap.accounts.glm.account, 'rewrite@bigmodel.cn')
  assert.equal(snap.accounts.glm.accounts[0].account, 'rewrite@bigmodel.cn')
  assert.equal(snap.accounts.glm.accounts[0].id, 'rewrite@bigmodel.cn@bigmodel')
  const roster = await listAccounts('glm', path)
  assert.equal(roster[0].id, 'rewrite@bigmodel.cn@bigmodel')
  assert.equal(roster.some((row) => row.id === 'dnarplz6@bigmodel' || row.account === 'dnarplz6'), false)
})

test('replaceAccountId moves the vault key without dropping the session', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const path = join(dir, 'auth.json')
  const session = glmSession({ accessToken: 'a.b', account: 'zcode', region: 'bigmodel' })
  const source = await saveSession('glm', { ...session, account: 'zcode' }, path)
  const next = { ...session, account: 'moved@bigmodel.cn' }
  await replaceAccountId('glm', source, next, path)
  const roster = await listAccounts('glm', path)
  assert.equal(roster.length, 1)
  assert.equal(roster[0].id, 'moved@bigmodel.cn@bigmodel')
  assert.equal(roster[0].account, 'moved@bigmodel.cn')
})

test('fetchGlmQuota throws the vendor business error instead of an empty ready quota', async () => {
  await assert.rejects(
    fetchGlmQuota(
      { accessToken: 'key', region: 'bigmodel' },
      async () => json({ code: 500, msg: '当前用户不存在coding plan', success: false }),
    ),
    /glm quota failed: 当前用户不存在coding plan/,
  )
})

test('fetchGlmQuota asks tool-usage when MCP is missing from quota/limit', async () => {
  const calls = []
  const parsed = await fetchGlmQuota(
    { accessToken: 'key', region: 'bigmodel' },
    async (url) => {
      calls.push(String(url))
      if (String(url).includes('/quota/limit')) {
        return json({
          data: {
            level: 'lite',
            limits: [
              { type: 'CREDIT_LIMIT', unit: 3, number: 5, usage: 2000, currentValue: 0 },
              { type: 'CREDIT_LIMIT', unit: 6, number: 1, usage: 10_000, currentValue: 100 },
            ],
          },
        })
      }
      if (String(url).includes('/tool-usage')) {
        return json({
          data: {
            limits: [{ type: 'TIME_LIMIT', usage: 400, currentValue: 0, remaining: 400, name: 'mcp tools' }],
          },
        })
      }
      throw new Error(`unexpected ${url}`)
    },
  )
  assert.ok(calls.some((href) => href.includes('open.bigmodel.cn/api/monitor/usage/quota/limit')))
  assert.ok(calls.some((href) => href.includes('open.bigmodel.cn/api/monitor/usage/tool-usage')))
  assert.deepEqual(parsed.rows.map((row) => row.kind), ['primary', 'weekly', 'mcp'])
})

// Shape of a live BigModel Max list (2026-09-29), ids / stamps shifted.
function resetCardList({ five = [], week = [] } = {}) {
  return {
    code: 200,
    msg: '操作成功',
    success: true,
    data: {
      targetType: 'PERSONAL',
      lastFiveHourResetTime: '2026-09-25 23:12:00',
      lastWeekResetTime: '2026-09-26 13:45:55',
      fiveHourResets: five,
      weekResets: week,
    },
  }
}

const GLM_WINDOWS = {
  code: 200,
  success: true,
  data: {
    level: 'max',
    limits: [
      { type: 'CREDIT_LIMIT', unit: 3, number: 5, usage: 28000, currentValue: 2550, remaining: 25449, percentage: 9 },
      { type: 'CREDIT_LIMIT', unit: 6, number: 1, usage: 140000, currentValue: 40421, remaining: 99578, percentage: 28 },
    ],
  },
}

test('glmCardStamp reads BigModel zone-less stamps as +08:00', () => {
  // lastWeekResetTime 13:45:55 lines up with weekly nextResetTime − 7d at 05:45:55Z.
  assert.equal(glmCardStamp('2026-09-26 13:45:55', 480), Date.UTC(2026, 8, 26, 5, 45, 55))
  assert.equal(glmCardStamp('2026-09-26 13:45:55', 0), Date.UTC(2026, 8, 26, 13, 45, 55))
})

test('parseGlmResetCards keeps only live cards, typed by bucket, earliest first', () => {
  const soon = '2099-01-01 00:00:00'
  const later = '2099-06-01 00:00:00'
  const bank = parseGlmResetCards(resetCardList({
    five: [
      { recordId: 2, grantType: 'DIRECT', expireTime: later, available: true },
      { recordId: 3, grantType: 'DIRECT', expireTime: '2020-01-01 00:00:00', available: true },
      { recordId: 4, grantType: 'DIRECT', expireTime: later, available: false },
    ],
    week: [{ recordId: 1, grantType: 'DIRECT', expireTime: soon, available: true }],
  }), 'bigmodel')
  assert.equal(bank.availableCount, 2)
  assert.deepEqual(bank.credits.map((c) => [c.id, c.resetType]), [['1', 'WEEK'], ['2', 'FIVE_HOUR']])
  assert.equal(bank.nextExpiresAt, glmCardStamp(soon, 480))
})

test('parseGlmResetCards refuses an incomplete list instead of reading zero cards', () => {
  assert.equal(parseGlmResetCards({ code: 200, success: true, data: {} }), undefined)
  assert.equal(parseGlmResetCards({ code: 500, success: false, msg: 'busy' }), undefined)
  assert.deepEqual(parseGlmResetCards(resetCardList()).credits, [])
})

test('fetchGlmQuota reads the reset-card bank from the region biz host', async () => {
  const calls = []
  const parsed = await fetchGlmQuota({ accessToken: 'key', region: 'bigmodel' }, async (url, init) => {
    const href = String(url)
    calls.push({ href, auth: init.headers.authorization })
    if (href.includes('/quota/limit')) return json(GLM_WINDOWS)
    if (href.includes('/customer-package-reset/list')) {
      return json(resetCardList({ week: [{ recordId: 9, expireTime: '2099-01-01 00:00:00', available: true }] }))
    }
    return json({})
  })
  const list = calls.find((call) => call.href.includes('customer-package-reset'))
  assert.equal(list.href, 'https://open.bigmodel.cn/api/biz/customer-package-reset/list?targetType=PERSONAL')
  assert.equal(list.auth, 'Bearer key')
  assert.equal(parsed.resetCredits.availableCount, 1)
  assert.equal(parsed.resetCredits.credits[0].resetType, 'WEEK')
})

test('QuotaStore keeps the last GLM card bank when the list read fails', async () => {
  let listOk = true
  const store = new QuotaStore({
    tokens: { glm: { session: async () => ({ accessToken: 'key', region: 'bigmodel', account: 'a@x' }) } },
    fetchFn: async (url) => {
      const href = String(url)
      if (href.includes('/quota/limit')) return json(GLM_WINDOWS)
      if (href.includes('/customer-package-reset/list')) {
        return listOk
          ? json(resetCardList({ five: [{ recordId: 5, expireTime: '2099-01-01 00:00:00', available: true }] }))
          : new Response('upstream down', { status: 502 })
      }
      return json({})
    },
  })
  assert.equal((await store.refresh('glm')).resetCredits.availableCount, 1)
  listOk = false
  const after = await store.refresh('glm')
  assert.equal(after.status, 'ready')
  assert.equal(after.resetCredits.availableCount, 1)
  assert.equal(after.resetCredits.credits[0].resetType, 'FIVE_HOUR')
})

test('QuotaStore GLM reset posts the card and reuses requestId after a lost response', async () => {
  const posts = []
  let available = true
  let dropNext = true
  const store = new QuotaStore({
    tokens: { glm: { session: async () => ({ accessToken: 'key', region: 'bigmodel', account: 'a@x' }) } },
    fetchFn: async (url, init) => {
      const href = String(url)
      if (href === glmResetCardUrl('bigmodel', 'use')) {
        posts.push(JSON.parse(init.body))
        if (dropNext) {
          dropNext = false
          throw new TypeError('fetch failed')
        }
        available = false
        return json({ code: 200, success: true, msg: '操作成功' })
      }
      if (href.includes('/quota/limit')) return json(GLM_WINDOWS)
      if (href.includes('/customer-package-reset/list')) {
        return json(resetCardList({ week: [{ recordId: 7, expireTime: '2099-01-01 00:00:00', available }] }))
      }
      return json({})
    },
  })
  await store.refresh('glm')
  await assert.rejects(store.consume('glm', undefined, undefined, '7'), /fetch failed/)
  const after = await store.consume('glm', undefined, undefined, '7')
  assert.equal(posts.length, 2)
  assert.deepEqual({ ...posts[0], requestId: undefined }, { targetType: 'PERSONAL', resetType: 'WEEK', recordId: 7, requestId: undefined })
  assert.equal(posts[1].requestId, posts[0].requestId)
  assert.equal(after.resetCredits.availableCount, 0)
  await assert.rejects(store.consume('glm', undefined, undefined, '7'), /not available/)
})

test('QuotaStore GLM reset surfaces a business rejection and mints a fresh requestId next time', async () => {
  const posts = []
  const store = new QuotaStore({
    tokens: { glm: { session: async () => ({ accessToken: 'key', region: 'bigmodel', account: 'a@x' }) } },
    fetchFn: async (url, init) => {
      const href = String(url)
      if (href.endsWith('/customer-package-reset/use')) {
        posts.push(JSON.parse(init.body))
        return json({ code: 500, success: false, msg: '窗口未消耗，无需重置' })
      }
      if (href.includes('/quota/limit')) return json(GLM_WINDOWS)
      if (href.includes('/customer-package-reset/list')) {
        return json(resetCardList({ five: [{ recordId: 8, expireTime: '2099-01-01 00:00:00', available: true }] }))
      }
      return json({})
    },
  })
  await store.refresh('glm')
  await assert.rejects(store.consume('glm', undefined, undefined, '8'), /glm reset card failed: 窗口未消耗/)
  await assert.rejects(store.consume('glm', undefined, undefined, '8'), /glm reset card failed/)
  assert.notEqual(posts[0].requestId, posts[1].requestId)
})

test('catalog includes GLM as Anthropic Messages (ZCode default)', () => {
  const providers = buildProviders({
    prefix: 'oauth',
    origin: 'http://127.0.0.1:8318',
    loggedIn: { glm: true },
  })
  assert.equal(providers['oauth-glm'].api, 'anthropic-messages')
  assert.equal(providers['oauth-glm'].baseURL, 'http://127.0.0.1:8318/glm')
  const ids = providers['oauth-glm'].models.map((model) => model.id)
  assert.deepEqual(ids, ['glm-5.3-flashx', 'glm-5.3', 'glm-5.3-flash', 'glm-5-turbo'])
  // Base rows sit at the plan's 400K input cap; the official 1M window is the
  // row's custom-context ceiling, no longer an opt-in `-1m` sibling row.
  // FlashX is the exception the plan serves at its full 1M window
  // (glm/README.md 模型, 2026-10-10 live test).
  assert.equal(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.3').contextWindow, 400_000)
  assert.equal(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.3-flash').contextWindow, 400_000)
  assert.equal(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.3-flashx').contextWindow, 1_000_000)
  assert.equal(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.3-1m'), undefined)
  assert.equal(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.3-flash-1m'), undefined)
  assert.deepEqual(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.3').input, ['text'])
  assert.deepEqual(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.3-flash').input, ['text', 'image'])
  assert.deepEqual(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.3-flashx').input, ['text', 'image'])
  assert.deepEqual(providers['oauth-glm'].models.find((model) => model.id === 'glm-5-turbo').input, ['text'])
  assert.equal(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.3-flash').name, 'GLM-5.3-Flash')
  assert.equal(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.3-flashx').name, 'GLM-5.3-FlashX')
  assert.equal(providers['oauth-glm'].models.find((model) => model.id === 'glm-5-turbo').name, 'GLM-5-Turbo')
  assert.equal(providers['oauth-glm'].models.find((model) => model.id === 'glm-5-turbo').contextWindow, 200_000)
  assert.equal(providers['oauth-glm'].models.find((model) => model.id === 'glm-5-turbo').maxTokens, 32_768)
  // 5.2 is not a plan row: it auto-routes to 5.3.
  assert.equal(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.2'), undefined)
  assert.deepEqual(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.3').reasoningEfforts, {
    low: 'low',
    high: 'high',
    max: 'max',
  })
  assert.deepEqual(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.3-flash').reasoningEfforts, {
    low: 'low',
    high: 'high',
    max: 'max',
  })
  assert.equal(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.3').reasoningEfforts.off, undefined)
  assert.equal(providers['oauth-glm'].models.find((model) => model.id === 'glm-5.3').reasoningEfforts.medium, undefined)
  assert.equal(providers['oauth-glm'].models.find((model) => model.id === 'glm-5-turbo').reasoningEfforts, false)
  // Anthropic-only compat: adaptive effort dispatch + unsigned thinking replay.
  // Completions-only switches must never appear on this route.
  assert.deepEqual(providers['oauth-glm'].compat, {
    forceAdaptiveThinking: true,
    allowEmptySignature: true,
  })
  assert.equal(providers['oauth-glm'].compat?.supportsReasoningEffort, undefined)
  assert.equal(providers['oauth-glm'].compat?.thinkingFormat, undefined)
})

test('Z.ai and BigModel accounts can coexist in the glm vault', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const path = join(dir, 'auth.json')
  await saveSession('glm', glmSession({ accessToken: 'a.b', account: 'dev@z.ai', region: 'zai' }), path)
  await saveSession('glm', glmSession({ accessToken: 'c.d', account: 'dev@z.ai', region: 'bigmodel' }), path)
  const roster = await listAccounts('glm', path)
  assert.equal(roster.length, 2)
  assert.equal(accountIdOf('glm', glmSession({ accessToken: 'a.b', account: 'dev@z.ai', region: 'zai' })), 'dev@z.ai@zai')
  assert.ok(roster.some((row) => row.region === 'zai'))
  assert.ok(roster.some((row) => row.region === 'bigmodel' && row.active))
})

test('controller GLM login sends BigModel region to cli init', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const calls = []
  const fetchFn = async (url, init = {}) => {
    const href = String(url)
    calls.push({ href, body: init.body })
    if (href.includes('/oauth/cli/init')) {
      return json({
        code: 0,
        data: {
          flow_id: 'f',
          authorize_url: 'https://bigmodel.cn/login?app_id=zcode',
          poll_interval_sec: 2,
          expires_at: Date.now() + 60_000,
        },
      })
    }
    if (href.includes('/oauth/cli/poll')) {
      return json({ code: 0, data: { status: 'pending' } })
    }
    throw new Error(`unexpected ${href}`)
  }
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn,
  })
  const result = await controller.login('glm', 'bigmodel')
  assert.equal(result.region, 'bigmodel')
  assert.equal(result.mode, 'cli')
  assert.equal(JSON.parse(calls[0].body).provider, 'bigmodel')
  await controller.cancel('glm')
})

test('controller useKey stores a pasted GLM key on the chosen region', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async () => new Response('{}', { status: 200 }),
  })
  const result = await controller.useKey('glm', 'id.secretkey', 'bigmodel')
  assert.equal(result.region, 'bigmodel')
  const roster = await listAccounts('glm', authPath)
  assert.equal(roster[0].region, 'bigmodel')
  assert.equal(roster[0].account, 'api-key')
})

function jwt(payload) {
  const header = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url')
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url')
  return `${header}.${body}.sig`
}

function json(body, init = {}) {
  return new Response(JSON.stringify(body), {
    status: 200,
    headers: { 'content-type': 'application/json' },
    ...init,
  })
}

// ---- Team Coding Plan (README 团队套餐; magpie zcode_team.go) -------------------------------

test('glmTeamProjects collects projectType-2 seats across orgs', async () => {
  const { glmTeamProjects, glmTeamHeaders, glmTeamDetailUsable, glmTeamSeatState, glmTeamStamp } = await import('../lib/oauth/glm/index.js')
  const seats = glmTeamProjects({
    organizations: [
      { organizationId: 'org-1', projects: [
        { projectId: 'personal-1', projectType: 1 },
        { projectId: 'team-1', projectType: '2' },
      ] },
      { organizationId: '', projects: [{ projectId: 'team-x', projectType: 2 }] },
      { organizationId: 'org-2', projects: [{ projectId: 'team-2', type: 2 }, { projectType: 2 }] },
    ],
  })
  assert.deepEqual(seats, [
    { org: 'org-1', project: 'team-1' },
    { org: 'org-2', project: 'team-2' },
  ])
  assert.equal(glmTeamHeaders('bigmodel', 'o', 'p')['Set-Language'], 'zh')
  assert.equal(glmTeamHeaders('zai', 'o', 'p')['Set-Language'], 'en')
  assert.equal(glmTeamHeaders('zai', 'o', 'p')['Bigmodel-Organization'], 'o')
  assert.equal(glmTeamDetailUsable({ status: 'EFFECTIVE', memberGrantStatus: 'VALID' }), true)
  assert.equal(glmTeamDetailUsable({ hasSubscription: false, status: 'EFFECTIVE', memberGrantStatus: 'VALID' }), false)
  assert.equal(glmTeamDetailUsable({ status: 'effective', memberGrantStatus: 'valid' }), true)
  assert.equal(glmTeamSeatState({ status: 'EFFECTIVE', memberGrantStatus: 'UNASSIGNED' }), 'unassigned')
  assert.equal(glmTeamSeatState({ status: 'EXPIRED', memberGrantStatus: 'VALID' }), 'expired')
  assert.equal(glmTeamSeatState({ status: 'EFFECTIVE', memberGrantStatus: 'VALID' }), undefined)
  assert.equal(glmTeamStamp(1760000000, 'zai'), 1760000000 * 1000)
  assert.equal(glmTeamStamp(1760000000000, 'zai'), 1760000000 * 1000)
  assert.equal(glmTeamStamp('2026-10-18 12:00:00', 'bigmodel'), Date.UTC(2026, 9, 18, 4, 0, 0))
  assert.equal(glmTeamStamp('2026-10-18 12:00:00', 'zai'), Date.UTC(2026, 9, 18, 12, 0, 0))
})

test('mintGlmCodingKey prefers a personal VALID plan and skips team projects when minting it', async () => {
  const { mintGlmCodingKey } = await import('../lib/oauth/glm/index.js')
  const calls: any[] = []
  const minted = await mintGlmCodingKey('oauth-tok', { region: 'zai', fetchFn: async (url, init) => {
    const href = String(url)
    calls.push({ href, method: init?.method ?? 'GET' })
    if (href.includes('/auth/z/login')) return json({ code: 0, data: { access_token: 'biz-tok' } })
    if (href.includes('/getCustomerInfo')) {
      assert.equal((init as any).headers.authorization, 'Bearer biz-tok')
      return json({
        code: 200,
        data: {
          organizations: [{
            organizationId: 'org-1',
            isDefault: true,
            projects: [
              { projectId: 'team-1', isDefault: true, projectType: 2 },
              { projectId: 'personal-1', projectType: 1 },
            ],
          }],
        },
      })
    }
    if (href.endsWith('/api_keys') || href.includes('/api_keys/')) {
      assert.ok(!href.includes('team-1'), 'personal mint must not land on the team project')
      if (href.endsWith('/api_keys')) return json({ code: 200, data: [{ apiKey: 'k1', name: 'dsh-plugin-oauth-subs' }] })
      if (href.includes('/copy/')) return json({ code: 200, data: { secretKey: 's1' } })
    }
    if (href.includes('/subscription/list')) {
      assert.equal((init as any).headers.authorization, 'Bearer k1.s1')
      return json({ code: 200, data: [{ productName: 'GLM Coding Plan Max', status: 'VALID' }] })
    }
    throw new Error(`unexpected ${href}`)
  } })
  assert.equal(minted.apiKey, 'k1.s1')
  assert.equal(minted.plan, 'GLM Coding Plan Max')
  assert.equal(minted.team, undefined)
  assert.equal(calls.some((call) => call.href.includes('querySubscribeDetail')), false)
})

test('mintGlmCodingKey falls back to a team seat when there is no personal plan', async () => {
  const { mintGlmCodingKey } = await import('../lib/oauth/glm/index.js')
  const seen: any[] = []
  const minted = await mintGlmCodingKey('bm-oauth', { region: 'bigmodel', fetchFn: async (url, init) => {
    const href = String(url)
    if (href.includes('/getCustomerInfo')) {
      return json({
        code: 200,
        data: {
          organizations: [{
            organizationId: 'org-9',
            projects: [{ projectId: 'team-9', projectType: 2 }],
          }],
        },
      })
    }
    if (href.includes('/querySubscribeDetail')) {
      seen.push({ href, headers: (init as any).headers })
      return json({
        code: 200,
        data: {
          hasSubscription: true,
          status: 'EFFECTIVE',
          memberGrantStatus: 'VALID',
          productName: 'GLM Coding Team Plan',
          subscribeEndTime: 4102444800,
        },
      })
    }
    if (href.includes('/api_keys')) {
      if (init?.method === 'POST') {
        assert.deepEqual(JSON.parse((init as any).body), { name: 'zcode-team-api-key', keyType: 2 })
        return json({ code: 200, data: { apiKey: 'tk9' } })
      }
      if (href.includes('/copy/')) return json({ code: 200, data: { secretKey: 'ts9' } })
      return json({ code: 200, data: [] })
    }
    throw new Error(`unexpected ${href}`)
  } })
  assert.equal(minted.apiKey, 'tk9.ts9')
  assert.deepEqual(minted.team, { org: 'org-9', project: 'team-9' })
  assert.equal(minted.plan, 'GLM Coding Team Plan')
  assert.equal(seen[0].href.includes('open.bigmodel.cn/api/biz/team/subscribe/product/querySubscribeDetail'), true)
  assert.equal(seen[0].headers['Bigmodel-Organization'], 'org-9')
  assert.equal(seen[0].headers['Bigmodel-Project'], 'team-9')
})

test('mintGlmCodingKey explains an unassigned seat and never regresses a minted personal key', async () => {
  const { mintGlmCodingKey } = await import('../lib/oauth/glm/index.js')
  const customer = {
    organizations: [{
      organizationId: 'org-9',
      projects: [{ projectId: 'team-9', projectType: 2 }],
    }],
  }
  const refusalFetch = async (url: any, init: any) => {
    const href = String(url)
    if (href.includes('/auth/z/login')) return json({ code: 0, data: { access_token: 'biz-tok' } })
    if (href.includes('/getCustomerInfo')) return json({ code: 200, data: customer })
    if (href.includes('/querySubscribeDetail')) {
      return json({ code: 200, data: { status: 'EFFECTIVE', memberGrantStatus: 'UNASSIGNED' } })
    }
    throw new Error(`unexpected ${href}`)
  }
  await assert.rejects(mintGlmCodingKey('t', { region: 'zai', fetchFn: refusalFetch }), /no seat on it yet — ask the team admin/)

  // A personal key that minted fine is kept even without a plan: today's login must not regress.
  const mixedFetch = async (url: any, init: any) => {
    const href = String(url)
    if (href.includes('/auth/z/login')) return json({ code: 0, data: { access_token: 'biz-tok' } })
    if (href.includes('/getCustomerInfo')) {
      return json({
        code: 200,
        data: {
          organizations: [{
            organizationId: 'org-1',
            projects: [
              { projectId: 'personal-1', projectType: 1 },
              { projectId: 'team-9', projectType: 2 },
            ],
          }],
        },
      })
    }
    if (href.includes('/querySubscribeDetail')) {
      return json({ code: 200, data: { status: 'EXPIRED', memberGrantStatus: 'VALID' } })
    }
    if (href.endsWith('/api_keys')) return json({ code: 200, data: [{ apiKey: 'k1', name: 'dsh-plugin-oauth-subs' }] })
    if (href.includes('/copy/')) return json({ code: 200, data: { secretKey: 's1' } })
    if (href.includes('/subscription/list')) return json({ code: 200, data: [] })
    throw new Error(`unexpected ${href}`)
  }
  const kept = await mintGlmCodingKey('t', { region: 'zai', fetchFn: mixedFetch })
  assert.equal(kept.apiKey, 'k1.s1')
  assert.match(kept.note ?? '', /expired/)
})

test('mintGlmCodingKey skips team-only orgs and mints on the default org and 默认项目', async () => {
  const { mintGlmCodingKey } = await import('../lib/oauth/glm/index.js')
  const keysUrls: string[] = []
  const minted = await mintGlmCodingKey('oauth-tok', { region: 'zai', fetchFn: async (url, init) => {
    const href = String(url)
    if (href.includes('/auth/z/login')) return json({ code: 0, data: { access_token: 'biz-tok' } })
    if (href.includes('/getCustomerInfo')) {
      return json({
        code: 200,
        data: {
          organizations: [
            { organizationId: 'org-team-only', organizationName: 'Some Team', projects: [{ projectId: 'team-0', projectType: 2 }] },
            { organizationId: 'org-def', organizationName: '默认机构', projects: [
              { projectId: 'personal-other', projectType: 1 },
              { projectId: 'personal-def', projectName: '默认项目', projectType: 1 },
            ] },
          ],
        },
      })
    }
    if (href.includes('/api_keys')) {
      keysUrls.push(href)
      if (href.endsWith('/api_keys')) return json({ code: 200, data: [{ apiKey: 'k1', name: 'dsh-plugin-oauth-subs' }] })
      if (href.includes('/copy/')) return json({ code: 200, data: { secretKey: 's1' } })
    }
    if (href.includes('/subscription/list')) {
      return json({ code: 200, data: [{ productName: 'GLM Coding Plan Pro', status: 'VALID' }] })
    }
    throw new Error(`unexpected ${href}`)
  } })
  assert.equal(minted.apiKey, 'k1.s1')
  assert.equal(keysUrls.length, 2)
  assert.ok(keysUrls.every((u) => u.includes('/organization/org-def/projects/personal-def/api_keys')),
    `mint must use org-def/personal-def, saw ${keysUrls.join(' ')}`)
})

test('mintGlmTeamApiKey keeps a keyType-2 key that copy returns with no secret', async () => {
  const { mintGlmTeamApiKey } = await import('../lib/oauth/glm/index.js')
  const minted = await mintGlmTeamApiKey('biz-tok', {
    region: 'bigmodel',
    org: 'org-9',
    project: 'team-9',
    fetchFn: async (url, init) => {
      const href = String(url)
      if (href.endsWith('/api_keys')) {
        if (init?.method === 'POST') return json({ code: 200, data: { apiKey: 'tk9' } })
        return json({ code: 200, data: [] })
      }
      if (href.includes('/copy/')) return json({ code: 200, data: {} })
      throw new Error(`unexpected ${href}`)
    },
  })
  // magpie zcodeProjectKey: a team key with no secret goes as it is.
  assert.equal(minted, 'tk9')
})

test('glmSession stores the team seat privately and the plan label', async () => {
  const { accountIdOf } = await import('../lib/oauth/store.js')
  const plain = glmSession({ accessToken: 'k.s', account: 'dev@z.ai' })
  const seated = glmSession({ accessToken: 'k.s', account: 'dev@z.ai', team: { org: ' o ', project: 'p' }, planType: 'GLM Coding Team Plan' })
  assert.deepEqual(seated.team, { org: 'o', project: 'p' })
  assert.equal(seated.planType, 'GLM Coding Team Plan')
  // The seat is not identity: the account id does not move.
  assert.equal(accountIdOf('glm', plain), accountIdOf('glm', seated))
  assert.equal(plain.team, undefined)
})

test('fetchGlmQuota reads a team seat with type=2 windows and TEAM reset cards', async () => {
  const seen: any[] = []
  const session = {
    accessToken: 'teamkey',
    oauthAccess: 'biz-tok',
    region: 'bigmodel',
    team: { org: 'org-9', project: 'team-9' },
  }
  const parsed = await fetchGlmQuota(session, async (url, init) => {
    const href = String(url)
    seen.push({ href, headers: (init as any).headers })
    if (href.includes('/quota/limit?type=2')) {
      return json(GLM_WINDOWS)
    }
    if (href.includes('/querySubscribeDetail')) {
      return json({ code: 200, data: { status: 'EFFECTIVE', memberGrantStatus: 'VALID', productName: 'GLM Coding Team Plan' } })
    }
    if (href.includes('customer-package-reset/list')) {
      return json(resetCardList({ week: [{ recordId: 11, expireTime: '2099-01-01 00:00:00', available: true }] }))
    }
    throw new Error(`unexpected ${href}`)
  })
  const windows = seen.find((call) => call.href.includes('/quota/limit?type=2'))
  assert.equal(windows.href, 'https://open.bigmodel.cn/api/monitor/usage/quota/limit?type=2')
  assert.equal(windows.headers['Bigmodel-Organization'], 'org-9')
  assert.equal(windows.headers['Bigmodel-Project'], 'team-9')
  assert.equal(windows.headers.authorization, 'Bearer teamkey')
  assert.equal(parsed.planType, 'GLM Coding Team Plan')
  const detail = seen.find((call) => call.href.includes('/querySubscribeDetail'))
  assert.equal(detail.headers.authorization, 'Bearer biz-tok')
  const cards = seen.find((call) => call.href.includes('customer-package-reset/list'))
  assert.equal(cards.href, 'https://open.bigmodel.cn/api/biz/customer-package-reset/list?targetType=TEAM')
  assert.equal(cards.headers.authorization, 'Bearer biz-tok')
  assert.equal(cards.headers['Bigmodel-Organization'], 'org-9')
  assert.equal(parsed.resetCredits.availableCount, 1)
  // MCP is PERSONAL-scope: a team seat never asks the MCP endpoints.
  assert.equal(seen.some((call) => call.href.includes('/mcp/usage') || call.href.includes('/tool-usage')), false)
})

test('glmResetCardBody targets TEAM for a seat and a minted session redeems with the team headers', async () => {
  const { glmResetCardBody } = await import('../lib/oauth/glm/quota.js')
  assert.equal(glmResetCardBody({ id: '7', resetType: 'WEEK' }, 'r1', true).targetType, 'TEAM')
  assert.equal(glmResetCardBody({ id: '7', resetType: 'WEEK' }, 'r1').targetType, 'PERSONAL')
  const posts: any[] = []
  const store = new QuotaStore({
    tokens: { glm: { session: async () => ({ accessToken: 'teamkey', region: 'bigmodel', account: 'a@x', team: { org: 'o', project: 'p' } }) } },
    fetchFn: async (url: any, init: any) => {
      const href = String(url)
      if (href.endsWith('/use')) {
        posts.push({ body: JSON.parse(init.body), headers: init.headers })
        return json({ code: 200, success: true, msg: '操作成功' })
      }
      if (href.includes('/quota/limit')) return json(GLM_WINDOWS)
      if (href.includes('customer-package-reset/list')) {
        return json(resetCardList({ week: [{ recordId: 21, expireTime: '2099-01-01 00:00:00', available: true }] }))
      }
      return json({})
    },
  })
  await store.refresh('glm')
  await store.consume('glm', undefined, undefined, '21')
  assert.equal(posts[0].body.targetType, 'TEAM')
  assert.equal(posts[0].headers['Bigmodel-Organization'], 'o')
  assert.equal(posts[0].headers['Bigmodel-Project'], 'p')
})

// ---- ZCode enc:v1 credential cipher (glm/import.ts) ----------------------------------------

/** Encrypt like ZCode's credentialCipherProvider: AES-256-GCM over a SHA-256 key. */
function zcodeEncV1(plaintext, secret) {
  const key = createHash('sha256').update(secret).digest()
  const iv = randomBytes(12)
  const cipher = createCipheriv('aes-256-gcm', key, iv)
  const data = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()])
  return `enc:v1:${iv.toString('base64url')}.${cipher.getAuthTag().toString('base64url')}.${data.toString('base64url')}`
}

test('decodeZcodeCredentialValue round-trips enc:v1 with the env and machine-fallback secrets', () => {
  const env = { ZCODE_CREDENTIAL_SECRET: 'import-secret' }
  const blob = zcodeEncV1('aaaa1111.bbbb2222', 'import-secret')
  assert.equal(decodeZcodeCredentialValue(blob, { env }), 'aaaa1111.bbbb2222')
  // Plaintext entries pass through untouched.
  assert.equal(decodeZcodeCredentialValue('plain-key', { env }), 'plain-key')
  assert.equal(decodeZcodeCredentialValue(undefined, { env }), undefined)
  // Wrong secret or a corrupt entry: undefined, so import skips it silently.
  assert.equal(decodeZcodeCredentialValue(blob, { env: { ZCODE_CREDENTIAL_SECRET: 'other-secret' } }), undefined)
  assert.equal(decodeZcodeCredentialValue('enc:v1:broken', { env }), undefined)
  assert.equal(decodeZcodeCredentialValue('enc:v1:..', { env }), undefined)
  // Documented machine-derived fallback when no secret is configured.
  const fallback = `zcode-credential-fallback:${platform()}:${homedir()}:${userInfo().username}`
  assert.equal(decodeZcodeCredentialValue(zcodeEncV1('fallback-key', fallback), { env: {} }), 'fallback-key')
})

test('glmKeyCandidateFromZcodeConfig decrypts an enc:v1 options.apiKey and drops an undecryptable one', () => {
  const had = process.env.ZCODE_CREDENTIAL_SECRET
  process.env.ZCODE_CREDENTIAL_SECRET = 'import-secret'
  try {
    // Newer ZCode writes the provider options.apiKey with the same enc:v1
    // cipher as the credential store (magpie configKey decrypts it too).
    const candidate = glmKeyCandidateFromZcodeConfig({
      provider: {
        'builtin:bigmodel': { options: { apiKey: '' } },
        'builtin:bigmodel-coding-plan': { options: { apiKey: zcodeEncV1('enc-coding-plan-key', 'import-secret') } },
      },
    })
    assert.equal(candidate.apiKey, 'enc-coding-plan-key')
    assert.equal(candidate.region, 'bigmodel')
    // A blob this machine cannot decrypt (another machine's secret) is no
    // candidate: import must skip it, not guess at ciphertext.
    assert.equal(glmKeyCandidateFromZcodeConfig({
      provider: { 'builtin:zai-coding-plan': { options: { apiKey: zcodeEncV1('foreign-key', 'other-machine') } } },
    }), undefined)
  } finally {
    if (had === undefined) delete process.env.ZCODE_CREDENTIAL_SECRET
    else process.env.ZCODE_CREDENTIAL_SECRET = had
  }
})
