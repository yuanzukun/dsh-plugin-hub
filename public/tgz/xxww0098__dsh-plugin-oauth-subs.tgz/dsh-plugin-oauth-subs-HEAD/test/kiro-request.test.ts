import assert from 'node:assert/strict'
import { test } from 'node:test'
import { createProxy } from '../lib/oauth/proxy.js'
import { estimateKiroPrefix, resetKiroPrefixBaselines } from '../lib/oauth/kiro/cache.js'
import { KIRO_CONTEXT_WINDOW, KIRO_DEEPSEEK_CONTEXT, KIRO_MODELS, SOCIAL_PROFILE_ARN, kiroSession, kiroUsageHeaders } from '../lib/oauth/kiro/index.js'
import {
  KIRO_AMZ_TARGET,
  KIRO_CHAT_ORIGIN,
  KIRO_EVENTSTREAM_TYPE,
  KIRO_STABLE_SESSION,
  KIRO_SYSTEM_ACK,
  collectKiroEvents,
  kiroChatHeaders,
  kiroChatUrl,
  kiroClientErrorBody,
  kiroClientErrorStatus,
  kiroConversationId,
  kiroToOpenai,
  kiroToOpenaiChunk,
  openaiToKiro,
  parseKiroEventStream,
  resetKiroSystemPins,
  resolveKiroUsage,
} from '../lib/oauth/kiro/request.js'
import { encodeKiroEventFrame, encodeKiroEventStream } from './kiro-frames.ts'

const RT = `rt_${'x'.repeat(120)}`

/** Real tool turns always offer tools; without them the wire carries the calls as text (`toolHistoryAsText`). */
const STUB_TOOLS = [{ type: 'function', function: { name: 'stub', description: 'stub', parameters: { type: 'object', properties: {} } } }]

function session(fields = {}) {
  return kiroSession({
    accessToken: 'kiro-tok',
    refreshToken: RT,
    expiresAt: Date.now() + 60_000,
    account: 'dev@x',
    authMethod: 'social',
    profileArn: SOCIAL_PROFILE_ARN,
    region: 'us-east-1',
    ...fields,
  })
}

function helloStream(text = 'Hello from Kiro') {
  return encodeKiroEventStream([
    { type: 'initial-response', payload: { conversationId: 'c1' } },
    { type: 'assistantResponseEvent', payload: { content: text, modelId: 'deepseek-3.2' } },
    { type: 'contextUsageEvent', payload: { contextUsagePercentage: 1.2 } },
  ])
}

test('openai messages become conversationState with dotted modelId and pinned conversationId', () => {
  resetKiroSystemPins()
  const first = openaiToKiro({
    model: 'deepseek-3.2',
    session_id: 'session-dsh-1',
    messages: [
      { role: 'developer', content: 'You are DSH.' },
      { role: 'system', content: 'Be brief.' },
      { role: 'user', content: 'hello' },
    ],
  }, { profileArn: SOCIAL_PROFILE_ARN })

  const user = first.conversationState.currentMessage.userInputMessage
  assert.equal(user.modelId, 'deepseek-3.2')
  assert.equal(user.modelId.includes('.'), true)
  assert.equal(user.origin, KIRO_CHAT_ORIGIN)
  assert.equal(user.origin, 'AI_EDITOR')
  assert.equal(user.content, 'hello')
  assert.equal(user.content.includes('You are DSH.'), false)
  assert.equal(first.conversationState.conversationId, 'session-dsh-1:deepseek-3.2')
  assert.equal(/^-\d+$/.test(first.conversationState.conversationId), false)
  assert.equal(first.conversationState.chatTriggerType, 'MANUAL')
  assert.equal(first.conversationState.history.length, 2)
  assert.equal(first.conversationState.history[0].userInputMessage.content, 'You are DSH.\nBe brief.')
  assert.equal(first.conversationState.history[1].assistantResponseMessage.content, KIRO_SYSTEM_ACK)
  assert.equal(first.profileArn, SOCIAL_PROFILE_ARN)

  const second = openaiToKiro({
    model: 'deepseek-3.2',
    session_id: 'session-dsh-1',
    messages: [
      { role: 'developer', content: 'You are DSH.' },
      { role: 'user', content: 'hello' },
      { role: 'assistant', content: 'Hi!' },
      { role: 'user', content: 'again' },
    ],
  }, { conversationId: 'session-dsh-1', profileArn: SOCIAL_PROFILE_ARN })
  assert.equal(second.conversationState.conversationId, first.conversationState.conversationId)
  assert.equal(second.conversationState.history.length, 4)
  assert.equal(second.conversationState.history[0].userInputMessage.content, 'You are DSH.\nBe brief.')
  assert.equal(second.conversationState.history[1].assistantResponseMessage.content, KIRO_SYSTEM_ACK)
  assert.equal(second.conversationState.history[2].userInputMessage.content, 'hello')
  assert.equal(second.conversationState.history[3].assistantResponseMessage.content, 'Hi!')
  assert.equal(second.conversationState.currentMessage.userInputMessage.content, 'again')
  assert.equal(second.conversationState.currentMessage.userInputMessage.content.includes('You are DSH.'), false)
})

test('a picked effort rides additionalModelRequestFields in the shape the model schema names; anything off the ladder is left out', () => {
  // Live 2026-09-29: Opus 5.5 low → max cost 4.3x, GPT-5.6 Luna none → max 8x; a field the schema lacks is a 400.
  const claude = { low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh', max: 'max' }
  const gpt = { off: 'none', low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh', max: 'max' }
  const ask = (model, effort, efforts) => openaiToKiro({ model, reasoning_effort: effort, messages: [{ role: 'user', content: 'hi' }] }, { efforts }).additionalModelRequestFields
  assert.deepEqual(ask('claude-opus-5.5', 'max', claude), { output_config: { effort: 'max' } })
  assert.deepEqual(ask('gpt-5.6-luna', 'none', gpt), { reasoning: { effort: 'none' } })
  assert.equal(ask('claude-sonnet-4.6', 'xhigh', { low: 'low', medium: 'medium', high: 'high', max: 'max' }), undefined)
  assert.equal(ask('claude-haiku-4.5', 'high', false), undefined)
  assert.equal(ask('claude-opus-5.5', undefined, claude), undefined)
  assert.equal(ask('claude-opus-5.5', 'max', undefined), undefined)
})

const PNG = 'data:image/png;base64,AAAA'
const JPG = 'data:image/jpg;base64,BBBB'
const image = (url) => ({ type: 'image_url', image_url: { url } })

test('data: image parts reach Kiro as userInputMessage.images (base64 bytes, jpg → jpeg); remote and unsupported ones are left out', () => {
  resetKiroSystemPins()
  const body = openaiToKiro({
    model: 'claude-opus-5.5',
    messages: [{
      role: 'user',
      content: [
        { type: 'text', text: 'what is in these?' },
        image(PNG),
        image(JPG),
        image('https://example.com/cat.png'),
        image('data:image/svg+xml;base64,CCCC'),
      ],
    }],
  })
  const user = body.conversationState.currentMessage.userInputMessage
  assert.equal(user.content, 'what is in these?')
  assert.deepEqual(user.images, [
    { format: 'png', source: { bytes: 'AAAA' } },
    { format: 'jpeg', source: { bytes: 'BBBB' } },
  ])
})

test('only the latest image-bearing user turn keeps its images, whether it is in history or current; an image-only turn is not dropped', () => {
  resetKiroSystemPins()
  const older = openaiToKiro({
    model: 'claude-opus-5.5',
    messages: [
      { role: 'user', content: [image(PNG)] },
      { role: 'assistant', content: 'a cat' },
      { role: 'user', content: [{ type: 'text', text: 'and now?' }, image(JPG)] },
    ],
  })
  const history = older.conversationState.history.map((entry) => entry.userInputMessage).filter(Boolean)
  assert.equal(history.length, 1)
  assert.equal(history[0].images, undefined) // the earlier image is not sent again
  assert.deepEqual(older.conversationState.currentMessage.userInputMessage.images, [{ format: 'jpeg', source: { bytes: 'BBBB' } }])

  const later = openaiToKiro({
    model: 'claude-opus-5.5',
    messages: [
      { role: 'user', content: [image(PNG)] },
      { role: 'assistant', content: 'a cat' },
      { role: 'user', content: 'thanks' },
    ],
  })
  const kept = later.conversationState.history.map((entry) => entry.userInputMessage).find(Boolean)
  assert.equal(kept.content, '.') // image-only turn stays in history
  assert.deepEqual(kept.images, [{ format: 'png', source: { bytes: 'AAAA' } }])
  assert.equal(later.conversationState.currentMessage.userInputMessage.images, undefined)
})

test('developer role is rewritten like GLM and unknown roles do not reach Kiro', () => {
  resetKiroSystemPins()
  const body = openaiToKiro({
    model: 'claude-sonnet-4.6',
    messages: [
      { role: 'developer', content: 'AGENTS.md' },
      { role: 'user', content: 'hi' },
    ],
  })
  const json = JSON.stringify(body)
  assert.equal(json.includes('"developer"'), false)
  assert.equal(body.conversationState.history[0].userInputMessage.content, 'AGENTS.md')
  assert.equal(body.conversationState.currentMessage.userInputMessage.content, 'hi')
})

test('later DSH system snapshots park at the history suffix, not on currentMessage', () => {
  resetKiroSystemPins()
  openaiToKiro({
    model: 'claude-sonnet-5',
    session_id: 'session-dsh-snap',
    messages: [
      { role: 'system', content: 'You are DSH.' },
      { role: 'user', content: 'hello' },
    ],
  })
  const second = openaiToKiro({
    model: 'claude-sonnet-5',
    session_id: 'session-dsh-snap',
    messages: [
      { role: 'system', content: 'You are DSH.\nThis snapshot supersedes the previous context.' },
      { role: 'user', content: 'hello' },
      { role: 'assistant', content: 'Hi!' },
      { role: 'user', content: 'again' },
    ],
  })
  assert.equal(second.conversationState.history[0].userInputMessage.content, 'You are DSH.')
  assert.equal(second.conversationState.history[1].assistantResponseMessage.content, KIRO_SYSTEM_ACK)
  const last = second.conversationState.history.at(-1)
  const parked = second.conversationState.history.at(-2)
  assert.equal(parked.userInputMessage.content, 'This snapshot supersedes the previous context.')
  assert.equal(last.assistantResponseMessage.content, KIRO_SYSTEM_ACK)
  assert.equal(second.conversationState.currentMessage.userInputMessage.content, 'again')
  assert.equal(JSON.stringify(second).includes('prompt_cache_key'), false)
  assert.equal(JSON.stringify(second).includes('x-grok-conv-id'), false)
})

test('same DSH session switching models does not reuse conversationId', () => {
  resetKiroSystemPins()
  const a = openaiToKiro({
    model: 'claude-opus-5',
    session_id: 'session-shared',
    messages: [{ role: 'user', content: 'hello' }],
  })
  const b = openaiToKiro({
    model: 'glm-5',
    session_id: 'session-shared',
    messages: [{ role: 'user', content: 'hello' }],
  })
  assert.equal(a.conversationState.conversationId, 'session-shared:claude-opus-5')
  assert.equal(b.conversationState.conversationId, 'session-shared:glm-5')
  assert.notEqual(a.conversationState.conversationId, b.conversationState.conversationId)
})

const EZ5 = 'toolu_bdrk_01Ez5MSML7fNdsjMvkPUTeCd'
const KG = 'toolu_bdrk_01KGbfVG6ZntZbT6MBPiMyfg'
const EZ5_WIRE = 'tooluse_bdrk_01Ez5MSML7fNdsjMvkPUTeCd'
const KG_WIRE = 'tooluse_bdrk_01KGbfVG6ZntZbT6MBPiMyfg'

function toolCall(id, name = 'run_code', args = '{}') {
  return { id, type: 'function', function: { name, arguments: args } }
}

function toolUseIds(row) {
  return row?.assistantResponseMessage?.toolUses?.map((item) => item.toolUseId) ?? []
}

function toolResultIdsOf(row) {
  const results = row?.userInputMessage?.userInputMessageContext?.toolResults
    ?? row?.userInputMessageContext?.toolResults
  return (results ?? []).map((item) => item.toolUseId)
}

function isKiroSystemAck(row) {
  return row?.assistantResponseMessage?.content === KIRO_SYSTEM_ACK
}

function assertToolResultFollowsUse(history, current, toolUseId) {
  const idx = history.findIndex((row) => toolUseIds(row).includes(toolUseId))
  assert.notEqual(idx, -1, `missing tool_use ${toolUseId}`)
  const after = history[idx + 1]
  assert.equal(isKiroSystemAck(after), false, `KIRO_SYSTEM_ACK between tool_use ${toolUseId} and tool_result`)
  const resultIds = after ? toolResultIdsOf(after) : toolResultIdsOf(current)
  assert.equal(resultIds.includes(toolUseId), true, `missing tool_result ${toolUseId}`)
  if (!after) {
    assert.equal(toolUseIds(history.at(-1)).includes(toolUseId), true)
    assert.equal(isKiroSystemAck(history.at(-1)), false)
  }
}

test('tools map into userInputMessageContext and tool results stay in history', () => {
  const body = openaiToKiro({
    model: 'deepseek-3.2',
    tools: [{ type: 'function', function: { name: 'run_code', description: 'run', parameters: { type: 'object', properties: { code: { type: 'string' } } } } }],
    messages: [
      { role: 'user', content: 'run it' },
      { role: 'assistant', content: '', tool_calls: [toolCall('call_1')] },
      { role: 'tool', tool_call_id: 'call_1', content: '{"ok":true}' },
      { role: 'user', content: 'thanks' },
    ],
  })
  const current = body.conversationState.currentMessage.userInputMessage
  assert.equal(current.userInputMessageContext.tools[0].toolSpecification.name, 'run_code')
  const assistant = body.conversationState.history.find((row) => row.assistantResponseMessage?.toolUses)
  assert.equal(assistant.assistantResponseMessage.toolUses[0].name, 'run_code')
  assert.equal(assistant.assistantResponseMessage.toolUses[0].toolUseId.startsWith('tooluse_'), true)
  const asstIdx = body.conversationState.history.indexOf(assistant)
  assert.equal(toolResultIdsOf(body.conversationState.history[asstIdx + 1]).includes('tooluse_1'), true)
})

test('two tool rounds keep tool_use before matching tool_result (live 0.0.58 walk)', () => {
  resetKiroSystemPins()
  const session_id = 'session-34f2f661-be56-4464-8b29-f20217fd0711'
  const model = 'claude-opus-5'
  openaiToKiro({
    tools: STUB_TOOLS,
    model,
    session_id,
    messages: [
      { role: 'system', content: 'You are DSH.' },
      { role: 'user', content: 'run it' },
    ],
  })
  const extraSystem = 'You are DSH.\nThis snapshot supersedes the previous context.'
  const first = openaiToKiro({
    tools: STUB_TOOLS,
    model,
    session_id,
    messages: [
      { role: 'system', content: extraSystem },
      { role: 'user', content: 'run it' },
      { role: 'assistant', content: '', tool_calls: [toolCall(EZ5)] },
      { role: 'tool', tool_call_id: EZ5, content: '{"ok":1}' },
    ],
  })
  const firstHist = first.conversationState.history
  const firstCurrent = first.conversationState.currentMessage.userInputMessage
  assert.equal(firstHist[0].userInputMessage.content, 'You are DSH.')
  assert.equal(isKiroSystemAck(firstHist[1]), true)
  assertToolResultFollowsUse(firstHist, firstCurrent, EZ5_WIRE)
  assert.deepEqual(toolResultIdsOf(firstCurrent), [EZ5_WIRE])
  assert.deepEqual(toolUseIds(firstHist.at(-1)), [EZ5_WIRE])

  const second = openaiToKiro({
    tools: STUB_TOOLS,
    model,
    session_id,
    messages: [
      { role: 'system', content: extraSystem },
      { role: 'user', content: 'run it' },
      { role: 'assistant', content: '', tool_calls: [toolCall(EZ5)] },
      { role: 'tool', tool_call_id: EZ5, content: '{"ok":1}' },
      { role: 'assistant', content: '', tool_calls: [toolCall(KG)] },
      { role: 'tool', tool_call_id: KG, content: '{"ok":2}' },
    ],
  })
  const hist = second.conversationState.history
  const current = second.conversationState.currentMessage.userInputMessage
  assert.equal(hist[0].userInputMessage.content, 'You are DSH.')
  assert.equal(isKiroSystemAck(hist[1]), true)
  assertToolResultFollowsUse(hist, current, EZ5_WIRE)
  assertToolResultFollowsUse(hist, current, KG_WIRE)
  assert.deepEqual(toolUseIds(hist.at(-1)), [KG_WIRE])
  assert.deepEqual(toolResultIdsOf(current), [KG_WIRE])
  const ez5Idx = hist.findIndex((row) => toolUseIds(row).includes(EZ5_WIRE))
  const kgIdx = hist.findIndex((row) => toolUseIds(row).includes(KG_WIRE))
  assert.ok(ez5Idx < kgIdx)
  assert.deepEqual(toolResultIdsOf(hist[ez5Idx + 1]), [EZ5_WIRE])
  assert.equal(isKiroSystemAck(hist[kgIdx]), false)

  const follow = openaiToKiro({
    tools: STUB_TOOLS,
    model,
    session_id,
    messages: [
      { role: 'system', content: extraSystem },
      { role: 'user', content: 'run it' },
      { role: 'assistant', content: '', tool_calls: [toolCall(EZ5)] },
      { role: 'tool', tool_call_id: EZ5, content: '{"ok":1}' },
      { role: 'assistant', content: '', tool_calls: [toolCall(KG)] },
      { role: 'tool', tool_call_id: KG, content: '{"ok":2}' },
      { role: 'user', content: 'thanks' },
    ],
  })
  const followHist = follow.conversationState.history
  const followCurrent = follow.conversationState.currentMessage.userInputMessage
  assert.equal(followHist[0].userInputMessage.content, 'You are DSH.')
  assertToolResultFollowsUse(followHist, followCurrent, EZ5_WIRE)
  assertToolResultFollowsUse(followHist, followCurrent, KG_WIRE)
  assert.equal(followCurrent.content, 'thanks')
  assert.equal((followCurrent.userInputMessageContext.toolResults ?? []).length, 0)
})

test('extra system snapshot does not sit between last tool_use and current toolResults', () => {
  resetKiroSystemPins()
  openaiToKiro({
    tools: STUB_TOOLS,
    model: 'claude-sonnet-5',
    session_id: 'session-dsh-tool-extra',
    messages: [
      { role: 'system', content: 'You are DSH.' },
      { role: 'user', content: 'use the tool' },
    ],
  })
  const extra = 'This snapshot supersedes the previous context.'
  const body = openaiToKiro({
    tools: STUB_TOOLS,
    model: 'claude-sonnet-5',
    session_id: 'session-dsh-tool-extra',
    messages: [
      { role: 'system', content: `You are DSH.\n${extra}` },
      { role: 'user', content: 'use the tool' },
      { role: 'assistant', content: '', tool_calls: [toolCall(EZ5, 'Read')] },
      { role: 'tool', tool_call_id: EZ5, content: '{"ok":true}' },
    ],
  })
  const history = body.conversationState.history
  const current = body.conversationState.currentMessage.userInputMessage
  assert.equal(history[0].userInputMessage.content, 'You are DSH.')
  assert.equal(isKiroSystemAck(history[1]), true)
  assert.equal(history.some((row) => row.userInputMessage?.content === extra), true)
  assertToolResultFollowsUse(history, current, EZ5_WIRE)
  assert.deepEqual(toolUseIds(history.at(-1)), [EZ5_WIRE])
  assert.deepEqual(toolResultIdsOf(current), [EZ5_WIRE])
  assert.equal(isKiroSystemAck(history.at(-1)), false)

  const withEmptyUser = openaiToKiro({
    tools: STUB_TOOLS,
    model: 'claude-sonnet-5',
    session_id: 'session-dsh-tool-extra',
    messages: [
      { role: 'system', content: `You are DSH.\n${extra}` },
      { role: 'user', content: 'use the tool' },
      { role: 'assistant', content: '', tool_calls: [toolCall(EZ5, 'Read')] },
      { role: 'tool', tool_call_id: EZ5, content: '{"ok":true}' },
      { role: 'user', content: '' },
    ],
  })
  const emptyHist = withEmptyUser.conversationState.history
  assert.equal(emptyHist[0].userInputMessage.content, 'You are DSH.')
  assertToolResultFollowsUse(emptyHist, withEmptyUser.conversationState.currentMessage.userInputMessage, EZ5_WIRE)
})

test('multiple tool_calls on one assistant all pair with their toolResults', () => {
  resetKiroSystemPins()
  const body = openaiToKiro({
    tools: STUB_TOOLS,
    model: 'claude-opus-5',
    session_id: 'session-dsh-multi-tool',
    messages: [
      { role: 'system', content: 'You are DSH.' },
      { role: 'user', content: 'run both' },
      { role: 'assistant', content: '', tool_calls: [toolCall(EZ5), toolCall(KG, 'read_file')] },
      { role: 'tool', tool_call_id: EZ5, content: '{"ok":1}' },
      { role: 'tool', tool_call_id: KG, content: '{"ok":2}' },
    ],
  })
  const history = body.conversationState.history
  const current = body.conversationState.currentMessage.userInputMessage
  assert.equal(history[0].userInputMessage.content, 'You are DSH.')
  assert.equal(isKiroSystemAck(history[1]), true)
  assert.deepEqual(toolUseIds(history.at(-1)), [EZ5_WIRE, KG_WIRE])
  assert.deepEqual(toolResultIdsOf(current), [EZ5_WIRE, KG_WIRE])
  assertToolResultFollowsUse(history, current, EZ5_WIRE)
  assertToolResultFollowsUse(history, current, KG_WIRE)
})

test('eventstream fixture becomes chat.completion content', () => {
  const frames = helloStream('Hello from Kiro')
  const events = parseKiroEventStream(frames)
  assert.equal(events.some((event) => event.type === 'assistantResponseEvent'), true)
  const openai = kiroToOpenai(frames, { model: 'deepseek-3.2', id: 'chatcmpl-test' })
  assert.equal(openai.object, 'chat.completion')
  assert.equal(openai.choices[0].message.content, 'Hello from Kiro')
  assert.equal(openai.choices[0].finish_reason, 'stop')
  assert.equal(openai.model, 'deepseek-3.2')
  assert.equal(openai.usage.prompt_tokens, Math.round(KIRO_DEEPSEEK_CONTEXT * 1.2 / 100))
  assert.ok(openai.usage.prompt_tokens > 0)
})

test('live AWS stream without metadataEvent uses contextUsageEvent percentage', () => {
  const frames = encodeKiroEventStream([
    { type: 'initial-response', payload: { conversationId: 'c1' } },
    { type: 'assistantResponseEvent', payload: { content: 'ALPHA', modelId: 'claude-haiku-4.5' } },
    { type: 'contextUsageEvent', payload: { contextUsagePercentage: 1.2 } },
    { type: 'meteringEvent', payload: { unit: 'credit', unitPlural: 'credits', usage: 0.016954 } },
  ])
  const events = parseKiroEventStream(frames)
  assert.equal(events.some((event) => event.type === 'metadataEvent'), false)
  assert.equal(events.some((event) => event.type === 'contextUsageEvent'), true)
  assert.equal(events.some((event) => event.type === 'meteringEvent'), true)
  const collected = collectKiroEvents(events)
  assert.equal(collected.usage, undefined)
  assert.equal(collected.contextPercentage, 1.2)
  const openai = kiroToOpenai(frames, { model: 'claude-haiku-4.5', id: 'chatcmpl-live' })
  assert.equal(openai.choices[0].message.content, 'ALPHA')
  assert.equal(openai.usage.prompt_tokens, Math.round(KIRO_CONTEXT_WINDOW * 1.2 / 100))
  assert.ok(openai.usage.prompt_tokens > 0)
  assert.equal(openai.usage.completion_tokens, Math.ceil('ALPHA'.length / 4))
  assert.equal(openai.usage.prompt_tokens_details, undefined)
  assert.notEqual(openai.usage.prompt_tokens, 0.016954)
})

test('assistantResponseEvent-only stream stays 0/0/0 when AWS omits usage events', () => {
  const frames = encodeKiroEventStream([
    { type: 'assistantResponseEvent', payload: { content: 'ALPHA', modelId: 'deepseek-3.2' } },
  ])
  const openai = kiroToOpenai(frames, { model: 'deepseek-3.2', id: 'chatcmpl-empty' })
  assert.equal(openai.choices[0].message.content, 'ALPHA')
  assert.deepEqual(openai.usage, { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 })
  assert.equal(openai.usage.prompt_tokens_details, undefined)
})

test('nested metadataEvent wrapper still maps tokenUsage', () => {
  const frame = encodeKiroEventFrame('metadataEvent', {
    metadataEvent: {
      tokenUsage: {
        uncachedInputTokens: 10,
        cacheReadInputTokens: 90,
        cacheWriteInputTokens: 4,
        outputTokens: 3,
        totalTokens: 107,
      },
    },
  })
  const openai = kiroToOpenai(frame, { model: 'claude-haiku-4.5', id: 'chatcmpl-wrap' })
  assert.equal(openai.usage.prompt_tokens, 104)
  assert.equal(openai.usage.prompt_tokens_details.cached_tokens, 90)
})

test('context fallback counts thinking and tool arguments as output, not just text', () => {
  const frames = encodeKiroEventStream([
    { type: 'reasoningContentEvent', payload: { text: 'x'.repeat(400) } },
    { type: 'toolUseEvent', payload: { toolUseId: 't1', name: 'run_code', input: 'y'.repeat(396) } },
    { type: 'toolUseEvent', payload: { toolUseId: 't1', stop: true } },
    { type: 'contextUsageEvent', payload: { contextUsagePercentage: 10 } },
  ])
  const openai = kiroToOpenai(frames, { model: 'claude-haiku-4.5', id: 'chatcmpl-think' })
  assert.equal(openai.choices[0].message.content, null)
  assert.ok(openai.usage.completion_tokens >= 200, `completion_tokens=${openai.usage.completion_tokens}`)
  assert.equal(resolveKiroUsage({ contextPercentage: 10, text: '', thinking: 'z'.repeat(80) }, 'claude-haiku-4.5').completion_tokens, 20)
})

test('metadataEvent tokenUsage wins over contextUsageEvent estimate', () => {
  const frames = encodeKiroEventStream([
    { type: 'assistantResponseEvent', payload: { content: 'ok' } },
    { type: 'contextUsageEvent', payload: { contextUsagePercentage: 50 } },
    {
      type: 'metadataEvent',
      payload: {
        tokenUsage: {
          uncachedInputTokens: 40,
          cacheReadInputTokens: 960,
          outputTokens: 8,
          totalTokens: 1008,
        },
      },
    },
  ])
  const openai = kiroToOpenai(frames, { model: 'claude-haiku-4.5', id: 'chatcmpl-prefer' })
  assert.equal(openai.usage.prompt_tokens, 1000)
  assert.equal(openai.usage.prompt_tokens_details.cached_tokens, 960)
  assert.notEqual(openai.usage.prompt_tokens, Math.round(KIRO_CONTEXT_WINDOW * 50 / 100))
  assert.equal(resolveKiroUsage({ usage: openai.usage, contextPercentage: 50, text: 'ok' }, 'claude-haiku-4.5').prompt_tokens, 1000)
})

test('kiroToOpenaiChunk emits SSE-shaped deltas', () => {
  const chunk = kiroToOpenaiChunk({ content: 'Hel' }, { model: 'deepseek-3.2', id: 'chatcmpl-s' })
  assert.equal(chunk.object, 'chat.completion.chunk')
  assert.equal(chunk.choices[0].delta.content, 'Hel')
  assert.equal(chunk.choices[0].finish_reason, null)
  const done = kiroToOpenaiChunk({}, { model: 'deepseek-3.2', id: 'chatcmpl-s', done: true })
  assert.equal(done.choices[0].finish_reason, 'stop')
})

test('conversationId is the DSH pin across two turns, never a Date.now stamp', () => {
  const a = kiroConversationId({ session_id: 'session-dsh-9', prompt_cache_key: 'ignored-when-session' })
  const b = kiroConversationId({ session_id: 'session-dsh-9' })
  assert.equal(a, 'session-dsh-9')
  assert.equal(b, a)
  assert.equal(kiroConversationId({}), KIRO_STABLE_SESSION)
  assert.equal(/^-\d+$/.test(kiroConversationId({})), false)
  const cleaned = kiroConversationId({}, 'session 772f/foo')
  assert.equal(cleaned, 'session-772f-foo')
  assert.equal(
    kiroConversationId({ session_id: 'session-dsh-9', model: 'deepseek-3.2' }),
    'session-dsh-9:deepseek-3.2',
  )
  const pinned = kiroConversationId({ session_id: 'session-dsh-9', model: 'claude-sonnet-5' }, 'session-dsh-9')
  assert.equal(pinned, 'session-dsh-9:claude-sonnet-5')
  assert.equal(pinned.includes(String(Date.now()).slice(0, 8)), false)
})

test('conversationId isolates all catalog models when DSH omits session_id', () => {
  assert.ok(KIRO_MODELS.length >= 18)
  const ids = KIRO_MODELS.map((model) => kiroConversationId({ model: model.id }))
  assert.equal(ids.length, new Set(ids).size)
  for (const model of KIRO_MODELS) {
    const id = kiroConversationId({ model: model.id })
    assert.equal(id, `${KIRO_STABLE_SESSION}:${model.id}`)
    assert.equal(/^-\d+$/.test(id), false)
    assert.notEqual(id, KIRO_STABLE_SESSION)
  }
})

test('metadataEvent usage survives mixed eventstream header types', () => {
  const frame = encodeKiroEventFrame('metadataEvent', {
    tokenUsage: {
      uncachedInputTokens: 40,
      cacheReadInputTokens: 960,
      outputTokens: 8,
      totalTokens: 1008,
    },
  })
  const events = parseKiroEventStream(frame)
  assert.equal(events.length, 1)
  assert.equal(events[0].type, 'metadataEvent')
  const collected = collectKiroEvents(events)
  assert.equal(collected.usage.prompt_tokens, 1000)
  assert.equal(collected.usage.prompt_tokens_details.cached_tokens, 960)
  const openai = kiroToOpenai(frame, { model: 'claude-sonnet-5', id: 'chatcmpl-usage' })
  assert.ok(openai.usage.prompt_tokens > 0)
  assert.equal(openai.usage.prompt_tokens, 1000)
  assert.equal(openai.usage.completion_tokens, 8)
  assert.equal(openai.usage.total_tokens, 1008)
  assert.equal(openai.usage.prompt_tokens_details.cached_tokens, 960)
})

test('mapKiroUsage accepts snake_case tokenUsage aliases', () => {
  const frame = encodeKiroEventFrame('metadataEvent', {
    token_usage: {
      uncached_input_tokens: 10,
      cache_read_input_tokens: 90,
      output_tokens: 5,
      total_tokens: 105,
    },
  })
  const openai = kiroToOpenai(frame, { model: 'claude-opus-4.5', id: 'chatcmpl-snake' })
  assert.ok(openai.usage.prompt_tokens > 0)
  assert.equal(openai.usage.prompt_tokens, 100)
  assert.equal(openai.usage.prompt_tokens_details.cached_tokens, 90)
})

test('collectKiroEvents maps cacheReadInputTokens to prompt_tokens_details.cached_tokens', () => {
  const frames = encodeKiroEventStream([
    { type: 'assistantResponseEvent', payload: { content: 'ok', modelId: 'deepseek-3.2' } },
    {
      type: 'metadataEvent',
      payload: {
        tokenUsage: {
          uncachedInputTokens: 40,
          cacheReadInputTokens: 960,
          outputTokens: 8,
          totalTokens: 1008,
        },
      },
    },
  ])
  const openai = kiroToOpenai(frames, { model: 'deepseek-3.2', id: 'chatcmpl-cache' })
  assert.equal(openai.usage.prompt_tokens, 1000)
  assert.equal(openai.usage.completion_tokens, 8)
  assert.equal(openai.usage.total_tokens, 1008)
  assert.equal(openai.usage.prompt_tokens_details.cached_tokens, 960)
})

test('chat headers ask for eventstream; quota headers stay JSON', () => {
  const sess = session()
  const usage = kiroUsageHeaders(sess)
  const chat = kiroChatHeaders(sess)
  assert.equal(usage.accept, 'application/json')
  assert.equal(chat.accept, KIRO_EVENTSTREAM_TYPE)
  assert.equal(chat['content-type'], 'application/x-amz-json-1.0')
  assert.equal(chat['x-amz-target'], KIRO_AMZ_TARGET)
  assert.equal(chat.authorization, 'Bearer kiro-tok')
  assert.equal(chat['user-agent'], usage['user-agent'])
  assert.equal(kiroChatUrl(sess), 'https://q.us-east-1.amazonaws.com/')
  assert.equal([401, 403].includes(kiroClientErrorStatus(403)), false)
  assert.equal(kiroClientErrorStatus(403), 400)
  assert.equal(kiroClientErrorStatus(429), 429)
})

test('proxy translates hello on /kiro/v1/chat/completions and does not 501', async () => {
  const seen = []
  const fetchFn = async (url, init) => {
    seen.push({ url: String(url), headers: init.headers, body: String(init.body) })
    return new Response(helloStream('hello'), {
      status: 200,
      headers: { 'content-type': KIRO_EVENTSTREAM_TYPE },
    })
  }
  const proxy = createProxy({
    port: 0,
    apiKey: 'secret-key',
    fetchFn,
    tokens: {
      kiro: { session: async () => session() },
    },
  })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const ok = await fetch(`http://127.0.0.1:${port}/kiro/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer secret-key', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'deepseek-3.2',
        session_id: 'session-dsh-kiro',
        messages: [{ role: 'user', content: 'hello' }],
      }),
    })
    assert.notEqual(ok.status, 501)
    assert.equal(ok.status, 200)
    const payload = await ok.json()
    assert.equal(payload.choices[0].message.content, 'hello')
    assert.ok(payload.usage.prompt_tokens > 0)
    assert.equal(payload.usage.prompt_tokens, Math.round(KIRO_DEEPSEEK_CONTEXT * 1.2 / 100))
    assert.equal(seen[0].url, 'https://q.us-east-1.amazonaws.com/')
    assert.equal(seen[0].headers['x-amz-target'], KIRO_AMZ_TARGET)
    assert.equal(seen[0].headers.accept, KIRO_EVENTSTREAM_TYPE)
    assert.equal(seen[0].headers['content-type'], 'application/x-amz-json-1.0')
    assert.equal(seen[0].headers.authorization, 'Bearer kiro-tok')
    const body = JSON.parse(seen[0].body)
    assert.equal(body.conversationState.currentMessage.userInputMessage.modelId, 'deepseek-3.2')
    assert.equal(body.conversationState.conversationId, 'session-dsh-kiro:deepseek-3.2')
    assert.equal(body.profileArn, SOCIAL_PROFILE_ARN)

    const again = await fetch(`http://127.0.0.1:${port}/kiro/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer secret-key', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'deepseek-3.2',
        session_id: 'session-dsh-kiro',
        messages: [
          { role: 'user', content: 'hello' },
          { role: 'assistant', content: 'hello' },
          { role: 'user', content: 'again' },
        ],
      }),
    })
    assert.equal(again.status, 200)
    const second = JSON.parse(seen[1].body)
    assert.equal(second.conversationState.conversationId, body.conversationState.conversationId)
    assert.equal(second.conversationState.conversationId, 'session-dsh-kiro:deepseek-3.2')

    const streamed = await fetch(`http://127.0.0.1:${port}/kiro/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer secret-key', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'deepseek-3.2',
        stream: true,
        session_id: 'session-dsh-kiro',
        messages: [{ role: 'user', content: 'hello' }],
      }),
    })
    assert.notEqual(streamed.status, 501)
    assert.equal(streamed.status, 200)
    assert.equal(streamed.headers.get('content-type')?.includes('text/event-stream'), true)
    const sse = await streamed.text()
    assert.equal(sse.includes('"object":"chat.completion.chunk"'), true)
    assert.equal(sse.includes('hello'), true)
    assert.equal(sse.includes('data: [DONE]'), true)
  } finally {
    await proxy.close()
  }
})

test('proxy forwards kiro social refresh 429 with Retry-After', async () => {
  const error = new Error('kiro social refresh failed (HTTP 429): Too many requests')
  error.status = 429
  error.retryAfter = '2'
  const proxy = createProxy({
    port: 0,
    apiKey: 'secret-key',
    fetchFn: async () => {
      throw new Error('refresh 429 must not reach GenerateAssistantResponse')
    },
    tokens: {
      kiro: {
        session: async () => {
          throw error
        },
      },
    },
  })
  const server = await proxy.listen()
  try {
    const denied = await fetch(`http://127.0.0.1:${server.address().port}/kiro/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer secret-key', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'claude-sonnet-5', messages: [{ role: 'user', content: 'hello' }] }),
    })
    assert.equal(denied.status, 429)
    assert.notEqual(denied.status, 500)
    assert.equal(denied.headers.get('retry-after'), '2')
    const payload = await denied.json()
    assert.match(String(payload.error), /HTTP 429/)
  } finally {
    await proxy.close()
  }
})

test('proxy remaps Kiro 403 to a non-AUTH 400', async () => {
  const proxy = createProxy({
    port: 0,
    apiKey: 'secret-key',
    fetchFn: async () => new Response(JSON.stringify({ message: 'expired token' }), { status: 403 }),
    tokens: { kiro: { session: async () => session() } },
  })
  const server = await proxy.listen()
  try {
    const denied = await fetch(`http://127.0.0.1:${server.address().port}/kiro/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer secret-key', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'deepseek-3.2', messages: [{ role: 'user', content: 'hello' }] }),
    })
    assert.equal(denied.status, 400)
    assert.equal([401, 403, 501].includes(denied.status), false)
    const payload = await denied.json()
    assert.equal(payload.error.message, 'expired token')
    assert.equal(payload.error.code, 'kiro_upstream')
  } finally {
    await proxy.close()
  }
})

// ── live findings 2026-09-29 ──────────────────────────────────────────────

test('a vendor 5xx is not typed invalid_request_error: the host reads that text before any 5xx and never retries it', () => {
  // The host sees `<status> <error JSON>` and matches /invalid.?request/ ahead of /\b5\d\d\b/.
  const hostText = (status, parsed) => `${status} ${JSON.stringify(kiroClientErrorBody(status, parsed, '').error)}`
  const highLoad = { message: 'Encountered unexpectedly high load when processing the request, please try again.' }
  assert.doesNotMatch(hostText(500, highLoad), /invalid.?request/i)
  assert.equal(kiroClientErrorBody(500, highLoad, '').error.type, 'api_error')
  const capacity = { reason: 'INSUFFICIENT_MODEL_CAPACITY', message: 'busy' }
  assert.equal(kiroClientErrorBody(400, capacity, '').error.type, 'api_error', 'capacity answers 503, so it is a server error')
  assert.doesNotMatch(hostText(400, capacity), /invalid.?request/i)
  // Client errors and rate limits keep their own types.
  assert.equal(kiroClientErrorBody(400, { message: 'bad' }, '').error.type, 'invalid_request_error')
  assert.equal(kiroClientErrorBody(429, { reason: 'USER_REQUEST_RATE_EXCEEDED' }, '').error.type, 'rate_limit_error')
})

test('text chunks are deltas: a chunk that starts with everything so far is still new text', () => {
  // Live: a run of `-` arrives as `-`×12 then `-`×48; treating the second as a cumulative snapshot kept 48 of 60.
  const events = [
    { type: 'assistantResponseEvent', payload: { content: '-'.repeat(12) } },
    { type: 'assistantResponseEvent', payload: { content: '-'.repeat(48) } },
    { type: 'reasoningContentEvent', payload: { text: 'ab' } },
    { type: 'reasoningContentEvent', payload: { text: 'abab' } },
  ]
  const message = kiroToOpenai(events, { model: 'deepseek-3.2' }).choices[0].message
  assert.equal(message.content, '-'.repeat(60))
  assert.equal(message.reasoning_content, 'ababab')
})

test('prompt tokens use the live catalog window when the caller has one', () => {
  const events = [
    { type: 'assistantResponseEvent', payload: { content: 'ok' } },
    { type: 'contextUsageEvent', payload: { contextUsagePercentage: 10 } },
  ]
  assert.equal(kiroToOpenai(events, { model: 'claude-haiku-4.5', window: 100_000 }).usage.prompt_tokens, 10_000)
  assert.equal(kiroToOpenai(events, { model: 'claude-haiku-4.5' }).usage.prompt_tokens, 20_000, 'static table when there is no live row')
})

test('cacheable-prefix estimate: a growing loop shares all but the new turn; one changed tool shares nothing', () => {
  resetKiroSystemPins()
  resetKiroPrefixBaselines()
  const id = 'session-a:claude-opus-5.5'
  const read = { type: 'function', function: { name: 'read', description: 'read a file', parameters: { type: 'object', properties: {} } } }
  const body = (messages, tools = [read]) => openaiToKiro({ model: 'claude-opus-5.5', messages, tools }, { conversationId: id })
  const turn1 = [{ role: 'system', content: 'be brief' }, { role: 'user', content: 'read a.ts' }]
  const turn2 = [...turn1,
    { role: 'assistant', content: '', tool_calls: [{ id: 'call_1', type: 'function', function: { name: 'read', arguments: '{}' } }] },
    { role: 'tool', tool_call_id: 'call_1', content: 'const a = 1' }]
  assert.equal(estimateKiroPrefix(id, body(turn1), 0).matched, null, 'no baseline yet')
  const grown = estimateKiroPrefix(id, body(turn2), 1_000)
  assert.ok(grown.matched > 0 && grown.matched < grown.bytes, 'last turn\'s current message is this turn\'s history entry')
  assert.equal(grown.gapMs, 1_000)
  // DSH's title request shares the session id; the next chat request still finds its baseline.
  estimateKiroPrefix(id, body([{ role: 'system', content: 'write a title' }, { role: 'user', content: 'title?' }]), 2_000)
  const again = estimateKiroPrefix(id, body(turn2), 3_000)
  assert.equal(again.matched, again.bytes)
  // Live 2026-09-29: one changed tool description cost 1.00x of cold.
  const retooled = { ...read, function: { ...read.function, description: 'read a file from disk' } }
  assert.equal(estimateKiroPrefix(id, body(turn2, [retooled]), 4_000).matched, 0)
  assert.equal(estimateKiroPrefix('dsh-kiro:claude-opus-5.5', body(turn2), 5_000).matched, null, 'no DSH session, no baseline')
})

test('cacheable-prefix estimate: a conversation still sending requests keeps its baseline while 64 newer ones start', () => {
  resetKiroSystemPins()
  resetKiroPrefixBaselines()
  const body = (id, text) => openaiToKiro({ model: 'claude-opus-5.5', messages: [{ role: 'user', content: text }] }, { conversationId: id })
  const lead = 'session-lead:claude-opus-5.5'
  estimateKiroPrefix(lead, body(lead, 'step 0'), 0)
  for (let i = 1; i <= 64; i += 1) {
    const other = `session-${i}:claude-opus-5.5`
    estimateKiroPrefix(other, body(other, 'hi'), i)
    assert.notEqual(estimateKiroPrefix(lead, body(lead, `step ${i}`), i).matched, null, `lead request ${i}`)
  }
  // Still bounded: the baseline that went is session-1's, idle since its only request.
  assert.equal(estimateKiroPrefix('session-1:claude-opus-5.5', body('session-1:claude-opus-5.5', 'hi'), 65).matched, null)
  resetKiroSystemPins()
  resetKiroPrefixBaselines()
})

test('tool history with no tools offered rides as text: Kiro 400s toolUse blocks without a toolConfig', () => {
  resetKiroSystemPins()
  const messages = [
    { role: 'user', content: 'read both files, then summarise' },
    { role: 'assistant', content: 'reading', tool_calls: [
      { id: 'call_1', type: 'function', function: { name: 'read_file', arguments: '{"path":"a.ts"}' } },
      { id: 'call_2', type: 'function', function: { name: 'read_file', arguments: '{"path":"b.ts"}' } },
    ] },
    { role: 'tool', tool_call_id: 'call_1', content: 'const a = 1' },
    { role: 'tool', tool_call_id: 'call_2', content: 'const b = 2' },
    { role: 'user', content: 'Summarise the conversation.' },
  ]
  const body = openaiToKiro({ model: 'claude-haiku-4.5', messages }, { conversationId: 's1' })
  const wire = JSON.stringify(body)
  assert.doesNotMatch(wire, /toolUses|toolResults/)
  const history = body.conversationState.history
  const texts = history.map((row) => row.userInputMessage?.content ?? row.assistantResponseMessage.content)
  assert.match(texts.join('\n'), /\[tool call\] read_file\(\{"path":"a\.ts"\}\)/)
  assert.match(texts.join('\n'), /\[tool result call_2\]\nconst b = 2/)
  assert.equal(history.filter((row) => row.userInputMessage?.content.startsWith('[tool result')).length, 1, 'both results are one user turn')
  assert.equal(body.conversationState.currentMessage.userInputMessage.content, 'Summarise the conversation.')

  // With tools offered the wire is untouched.
  resetKiroSystemPins()
  const tools = [{ type: 'function', function: { name: 'read_file', description: 'r', parameters: { type: 'object', properties: {} } } }]
  const withTools = JSON.stringify(openaiToKiro({ model: 'claude-haiku-4.5', messages, tools }, { conversationId: 's1' }))
  assert.match(withTools, /toolUses/)
  assert.match(withTools, /toolResults/)
})
