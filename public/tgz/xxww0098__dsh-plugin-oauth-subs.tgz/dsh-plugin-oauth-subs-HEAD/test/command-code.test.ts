import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { AuthController } from '../lib/oauth/controller.js'
import { accountIdOf, getSession, listStoredSessions, publicSession, saveSession } from '../lib/oauth/store.js'
import { buildProviders, catalogProviders, familyOfProvider, HARNESS_COMPLETIONS_API, ownedProviderIds } from '../lib/oauth/models.js'
import { mergeCatalogRows } from '../lib/catalog/merge.js'
import { exerciseLiveCatalog } from './catalog-lifecycle.ts'
import {
  COMMAND_CODE_API_KEY_ENV,
  COMMAND_CODE_GENERATE_URL,
  COMMAND_CODE_MODELS,
  isCommandCodeOpaqueAccount,
  isCommandCodePermanentRefreshError,
  commandCodeAuthFilePath,
  commandCodeDefaultAccount,
  commandCodeSession,
  commandCodeSourceLabel,
  commandCodeUpstreamHeaders,
  parseCommandCodeApiKey,
  parseCommandCodeWhoami,
  pickCommandCodeHumanAccount,
  refreshCommandCode,
  commandCodePlanInfo,
  commandCodePlanLabel,
} from '../lib/apikey/command-code/index.js'
import {
  COMMAND_CODE_CATALOG_TTL_MS,
  commandCodeCatalogModels,
  commandCodeProviderRows,
  commandCodeSourceModels,
  mergeCommandCodeProviderModels,
  refreshCommandCodeCatalog,
  resetCommandCodeCatalogCache,
} from '../lib/apikey/command-code/catalog.js'
import { commandCodeFailure } from '../lib/apikey/command-code/failure.js'
import { COMMAND_CODE_IMPORT_EMPTY, importCommandCodeAuth, readCommandCodeAuthFile } from '../lib/apikey/command-code/import.js'
import { applyCommandCodeCache } from '../lib/apikey/command-code/cache.js'
import {
  commandCodeEngineAuthorize,
  commandCodeEngineFetch,
  fetchCommandCodeQuotaEngine,
  resetCommandCodeEnginePlugin,
} from '../lib/apikey/command-code/engine.js'
import { configureUpstreamEngine, resetUpstreamEngineCache } from '../lib/upstream-engine/engine.js'
import { configureEngineBridge, resetEngineBridge } from '../lib/upstream-engine/bridge.js'
import { COMMANDCODE_FIXTURE_MODULE, COMMANDCODE_FIXTURE_NPM, COMMANDCODE_FIXTURE_VERSION, writeEngineCache } from './upstream-engine-fixture.ts'
import { formatPlanLabel } from '../lib/oauth/plan.js'
import { createProxy } from '../lib/oauth/proxy.js'
import { assembleUi } from '../scripts/ui-bundle.ts'

const KEY = 'user_test_3snjwc45CAe2b56LYBoLnXVuoJcQCP6d3rVZHUHqkVw'
const USER_UUID = 'e97a02d4-b06f-4c0c-9b87-a5aeebb363d9'

function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })
}

const LIVE_WHOAMI = {
  success: true,
  user: { id: USER_UUID, name: 'Xx Ww', email: '970685525@qq.com', userName: 'xxww0098' },
  org: null,
}

const LIVE_CREDITS = {
  credits: { monthlyCredits: 22.5, purchasedCredits: 4, freeCredits: 0.5 },
  windowLimits: {
    fiveHour: { used: 40, cap: 100, resetAt: '2099-01-01T05:00:00Z' },
    weekly: { used: 200, cap: 500, resetAt: '2099-01-08T00:00:00Z' },
  },
}

const LIVE_SUBSCRIPTION = {
  data: {
    planId: 'individual-pro',
    status: 'active',
    currentPeriodStart: '2099-01-01T00:00:00Z',
    currentPeriodEnd: '2099-02-01T00:00:00Z',
  },
}

/** The engine lane under a tmp data dir, its global fetch bridge-routed. */
async function withEngine(t, fetchFn) {
  const dataDir = await mkdtemp(join(tmpdir(), 'commandcode-engine-'))
  t.after(() => rm(dataDir, { recursive: true, force: true }))
  await writeEngineCache(dataDir, {
    npm: COMMANDCODE_FIXTURE_NPM,
    version: COMMANDCODE_FIXTURE_VERSION,
    module: COMMANDCODE_FIXTURE_MODULE,
    engines: { 'command-code': { npm: COMMANDCODE_FIXTURE_NPM, version: COMMANDCODE_FIXTURE_VERSION, integrity: 'sha512-fixture' } },
  })
  resetUpstreamEngineCache()
  resetCommandCodeEnginePlugin()
  configureUpstreamEngine(join(dataDir, 'auth.json'))
  configureEngineBridge({ fetchFn })
  t.after(() => {
    resetUpstreamEngineCache()
    resetCommandCodeEnginePlugin()
    resetEngineBridge()
    configureUpstreamEngine(undefined)
  })
  return dataDir
}

/** billing reads the engine's usage speaks (subscriptions + credits only). */
function billingFake({ subscription = LIVE_SUBSCRIPTION, credits = LIVE_CREDITS, whoami = LIVE_WHOAMI } = {}, log: any[] = []) {
  return async (url, init = {}) => {
    const href = String(url)
    log.push({ href, init })
    if (href.endsWith('/alpha/whoami')) return json(whoami)
    if (href.endsWith('/alpha/billing/credits')) return json(credits)
    if (href.endsWith('/alpha/billing/subscriptions')) return json(subscription)
    return json({}, 404)
  }
}

// ---- key / session / identity (vault-side, engine-independent) ----------------

test('parseCommandCodeApiKey trims and rejects multiline / short secrets', () => {
  assert.equal(parseCommandCodeApiKey(`  ${KEY}  `), KEY)
  assert.throws(() => parseCommandCodeApiKey(''), /empty/)
  assert.throws(() => parseCommandCodeApiKey('  '), /empty/)
  assert.throws(() => parseCommandCodeApiKey('short'), /invalid/)
  assert.throws(() => parseCommandCodeApiKey(`${KEY}\n${KEY}`), /invalid/)
})

test('command-code session round-trip: fingerprint account, no token in public view', () => {
  const session = commandCodeSession({ accessToken: KEY, source: 'paste' })
  assert.equal(session.accessToken, KEY)
  assert.equal(session.refreshToken, KEY)
  assert.equal(session.expiresAt, Number.MAX_SAFE_INTEGER)
  assert.equal(session.source, 'paste')
  assert.equal(session.account, commandCodeDefaultAccount(KEY))
  assert.equal(isCommandCodeOpaqueAccount(session.account), true)
  const pub = publicSession('command-code', session)
  assert.equal(pub.account, session.account)
  assert.equal(pub.method, 'paste')
  assert.equal(pub.methodLabel, 'key')
  assert.equal(pub.accessToken, undefined)
  assert.equal(pub.refreshToken, undefined)
  assert.equal(accountIdOf('command-code', session), session.account)
  assert.notEqual(accountIdOf('command-code', session), accountIdOf('command-code', commandCodeSession({
    accessToken: 'user_other_0000000000000000000000000000000000000000000000',
  })))
})

test('identity: userName > email > name > uuid; fingerprint and uuid stay opaque', async () => {
  const identity = parseCommandCodeWhoami(LIVE_WHOAMI)
  assert.equal(identity.account, 'xxww0098')
  assert.equal(identity.id, USER_UUID)
  assert.equal(identity.userName, 'xxww0098')
  assert.equal(identity.email, '970685525@qq.com')
  assert.equal(identity.orgId, undefined)
  assert.equal(parseCommandCodeWhoami({ user: { id: 'u1', email: 'a@b.c' } }).account, 'a@b.c')
  assert.equal(parseCommandCodeWhoami({ user: { id: 'u1', name: 'Nice Name' } }).account, 'Nice Name')
  assert.equal(parseCommandCodeWhoami({ user: { id: 'u1' } }).account, 'u1')
  assert.equal(parseCommandCodeWhoami({}), undefined)
  assert.equal(pickCommandCodeHumanAccount(commandCodeDefaultAccount(KEY), 'xxww0098'), 'xxww0098')
  assert.equal(pickCommandCodeHumanAccount(commandCodeDefaultAccount(KEY), USER_UUID), undefined)
  assert.equal(isCommandCodeOpaqueAccount('command-code-account'), true)
  assert.equal(isCommandCodeOpaqueAccount('xxww0098'), false)
  assert.equal(commandCodeSourceLabel('env'), 'env')
  assert.equal(commandCodeSourceLabel('browser'), 'browser')
  assert.equal(commandCodeSourceLabel('cli'), 'CLI')
  assert.equal(commandCodeSourceLabel('paste'), 'key')
})

test('plan table: individual-* / teams-* ids resolve to display names', () => {
  assert.equal(commandCodePlanLabel('individual-go'), 'Go')
  assert.equal(commandCodePlanLabel('individual-provider'), 'Provider')
  assert.equal(commandCodePlanLabel('individual-pro'), 'Pro')
  assert.equal(commandCodePlanLabel('individual-pro-v1'), 'Pro')
  assert.equal(commandCodePlanLabel('teams-pro'), 'Teams Pro')
  assert.equal(commandCodePlanInfo('individual-pro').monthlyCredits, 30)
  assert.equal(commandCodePlanInfo('individual-ultra').monthlyCredits, 300)
  assert.equal(formatPlanLabel('individual-pro', 'command-code'), 'Pro')
  assert.equal(formatPlanLabel('individual-goat', 'command-code'), 'GOAT')
  assert.equal(formatPlanLabel('teams-pro', 'command-code'), 'Teams Pro')
  assert.equal(commandCodePlanLabel('individual-mystery-9'), 'Mystery-9')
})

test('permanent key: refresh is a no-op and never fails permanently', async () => {
  const session = commandCodeSession({ accessToken: KEY })
  assert.equal(await refreshCommandCode(session), session)
  assert.equal(isCommandCodePermanentRefreshError(new Error('whatever')), false)
  await assert.rejects(() => refreshCommandCode({ accessToken: '' }), /API key/)
  const headers = commandCodeUpstreamHeaders(session)
  assert.equal(headers.authorization, `Bearer ${KEY}`)
  assert.equal(headers['x-command-code-version'], '1.84.0')
  assert.equal(headers['x-cli-environment'], 'production')
})

// ---- catalog (closed set stays local) ------------------------------------------

test('catalog is Completions at /command-code; efforts stay in the closed set', () => {
  assert.equal(ownedProviderIds('oauth').includes('oauth-command-code'), true)
  assert.equal(familyOfProvider('oauth-command-code'), 'command-code')
  const providers = buildProviders({
    prefix: 'oauth',
    origin: 'http://127.0.0.1:8318',
    loggedIn: { 'command-code': true },
  })
  const route = providers['oauth-command-code']
  assert.equal(route.api, HARNESS_COMPLETIONS_API)
  assert.equal(route.baseURL, 'http://127.0.0.1:8318/command-code')
  assert.equal(route.models.length, COMMAND_CODE_MODELS.length)
  for (const model of route.models) {
    for (const key of Object.keys(model.reasoningEfforts ?? {})) {
      assert.match(key, /^(off|minimal|low|medium|high|xhigh|max)$/)
    }
    for (const input of model.input) assert.match(input, /^(text|image)$/)
    assert.equal(typeof model.contextWindow, 'number')
    assert.equal(model.contextWindow > 0, true)
  }
  const catalog = catalogProviders({ prefix: 'oauth', origin: 'http://x' })
  assert.equal(catalog['oauth-command-code'].models.length, COMMAND_CODE_MODELS.length)
  assert.equal(commandCodeCatalogModels().length, COMMAND_CODE_MODELS.length)
  assert.equal(catalog['oauth-command-code'].models.some((row) => row.id === 'claude-sonnet-5'), true)
})

test('live provider list merges onto the pinned registry and never invents facts', async () => {
  resetCommandCodeCatalogCache()
  assert.equal(commandCodeCatalogModels().length, COMMAND_CODE_MODELS.length)
  const anchored = COMMAND_CODE_MODELS.find((model) => model.id === 'claude-sonnet-5')
  const live = commandCodeProviderRows({
    object: 'list',
    data: [
      { id: 'claude-sonnet-5', name: 'Claude Sonnet 5', context_length: 2_000_000, supported_endpoints: ['/messages'] },
      { id: 'zai-org/GLM-5.3', name: 'GLM-5.3', context_length: 0 },
      { id: 'brand/new-model', name: 'Brand New', context_length: 123_456, supported_endpoints: ['/chat/completions'] },
    ],
  })
  assert.deepEqual(live.map((row) => row.id), ['claude-sonnet-5', 'brand/new-model'], 'a row with no window is not a catalog row')
  const merged = mergeCommandCodeProviderModels(live, { models: COMMAND_CODE_MODELS })
  assert.equal(merged.length, COMMAND_CODE_MODELS.length + 1)
  const kept = merged.find((row) => row.id === 'claude-sonnet-5')
  assert.equal(kept.contextWindow, 2_000_000, 'the live window wins over the pinned snapshot')
  assert.equal(kept.name, anchored.name, 'the curated name stays')
  assert.deepEqual(kept.reasoningEfforts, anchored.reasoningEfforts, 'the registry keeps what the list does not carry')
  assert.deepEqual(merged.at(-1), { id: 'brand/new-model', name: 'Brand New', contextWindow: 123_456 }, 'a new id carries only what the list says')

  let calls = 0
  const rows = await refreshCommandCodeCatalog(null, {
    fetchFn: async () => {
      calls += 1
      return json({ object: 'list', data: [{ id: 'claude-sonnet-5', name: 'Claude Sonnet 5', context_length: 2_000_000 }] })
    },
  })
  assert.equal(rows.length, COMMAND_CODE_MODELS.length)
  assert.equal(commandCodeCatalogModels().find((row) => row.id === 'claude-sonnet-5').contextWindow, 2_000_000)
  await refreshCommandCodeCatalog(null, { fetchFn: async () => { calls += 1; return json({}) } })
  assert.equal(calls, 1, 'the second read inside the TTL is served from the cache')
  resetCommandCodeCatalogCache()
  const failed = await refreshCommandCodeCatalog(null, { fetchFn: async () => json({ error: 'nope' }, 500) })
  assert.equal(failed.length, COMMAND_CODE_MODELS.length, 'a failed read leaves the pinned registry')
  assert.equal(COMMAND_CODE_CATALOG_TTL_MS > 0, true)
})

test('command code source membership reports a dropped row while the picker keeps it', () => {
  const staticRows = [
    { id: 'kept', name: 'Kept', contextWindow: 1_000, maxTokens: 8 },
    { id: 'gone', name: 'Gone', contextWindow: 2_000, maxTokens: 8 },
  ]
  const live = commandCodeProviderRows({
    data: [{ id: 'kept', name: 'Kept Live', context_length: 1_500 }],
  })
  const source = commandCodeSourceModels(live)
  assert.deepEqual(source.map((row) => row.id), ['kept'])
  const picker = mergeCommandCodeProviderModels(live, { models: staticRows })
  assert.equal(picker.some((row) => row.id === 'gone'), true)
  assert.equal(picker.find((row) => row.id === 'kept').contextWindow, 1_500)
  const report = mergeCatalogRows(staticRows, source)
  assert.deepEqual(report.missing, ['gone'])
  assert.equal(report.rows.some((row) => row.id === 'gone'), true)
  const pruned = mergeCatalogRows(staticRows, source, { prune: true })
  assert.deepEqual(pruned.removed, ['gone'])
  assert.equal(pruned.rows.some((row) => row.id === 'gone'), false)
  const docs = readFileSync(new URL('../docs/models.md', import.meta.url), 'utf8')
  assert.match(docs, /Command Code `GET api\.commandcode\.ai\/provider\/v1\/models`/)
})

test('command code catalog refresh is one public lifecycle', async () => {
  const listed = (kind) => ({
    ok: true,
    json: async () => ({
      data: [{
        id: kind === 'a' ? 'live-only-a' : 'live-only-b',
        name: kind === 'a' ? 'A' : 'B',
        context_length: kind === 'a' ? 100_000 : 200_000,
      }],
    }),
  })
  await exerciseLiveCatalog({
    label: 'command-code',
    ttlMs: COMMAND_CODE_CATALOG_TTL_MS,
    shared: true,
    keepStaticId: 'claude-sonnet-5',
    windows: { a: 100_000, b: 200_000 },
    reset: resetCommandCodeCatalogCache,
    models: commandCodeCatalogModels,
    refresh: ({ now, ttlMs, fetch }) => refreshCommandCodeCatalog(null, {
      now,
      ttlMs,
      fetchFn: async () => {
        const kind = await fetch()
        if (kind === 'fail') return { ok: false, json: async () => ({}) }
        if (kind === 'empty') return { ok: true, json: async () => ({ data: [] }) }
        return listed(kind)
      },
    }),
  })
})

// ---- import (copy-only, local) --------------------------------------------------

test('import: env wins over auth.json; empty raises the sentinel; file fields map', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'command-code-import-'))
  const authPath = join(dir, '.commandcode', 'auth.json')
  await import('node:fs/promises').then((fs) => fs.mkdir(join(dir, '.commandcode'), { recursive: true }))
  await import('node:fs/promises').then((fs) => fs.writeFile(authPath, JSON.stringify({
    apiKey: KEY,
    userId: USER_UUID,
    userName: 'xxww0098',
    keyName: 'CLI login',
    authenticatedAt: '2026-01-01T00:00:00Z',
  })))
  assert.equal(commandCodeAuthFilePath(dir), authPath)
  const file = await readCommandCodeAuthFile({ path: authPath })
  assert.equal(file.apiKey, KEY)
  assert.equal(file.userName, 'xxww0098')
  const fromFile = await importCommandCodeAuth({ env: {}, path: authPath })
  assert.equal(fromFile.source, 'cli')
  assert.equal(fromFile.session.account, 'xxww0098')
  assert.equal(fromFile.session.userId, USER_UUID)
  assert.equal(accountIdOf('command-code', fromFile.session), 'xxww0098')
  const fromEnv = await importCommandCodeAuth({ env: { [COMMAND_CODE_API_KEY_ENV]: 'user_env_0000000000000000000000000000000000000000000000' }, path: authPath })
  assert.equal(fromEnv.source, 'env')
  assert.equal(fromEnv.session.accessToken, 'user_env_0000000000000000000000000000000000000000000000')
  await assert.rejects(importCommandCodeAuth({ env: {}, path: join(dir, 'missing.json') }), (error) => error.code === COMMAND_CODE_IMPORT_EMPTY)
  await assert.rejects(importCommandCodeAuth({ env: {}, readFileFn: async () => '{broken' }), (error) => error.code === COMMAND_CODE_IMPORT_EMPTY)
})

// ---- cache strip -----------------------------------------------------------------

test('applyCommandCodeCache strips foreign fields; the wire carries no thread id', () => {
  const stripped = applyCommandCodeCache({
    model: 'claude-sonnet-5',
    messages: [{ role: 'user', content: 'hi' }],
    prompt_cache_key: 'dsh/sess 1',
    prompt_cache_retention: '24h',
    prompt_cache_options: { retention: '24h' },
    session_id: 'sess-dsh',
    cache_control: { type: 'ephemeral' },
    service_tier: 'priority',
    store: true,
    user: 'u',
    metadata: {},
    parallel_tool_calls: true,
    logprobs: true,
    top_logprobs: 5,
    logit_bias: {},
    n: 2,
    seed: 42,
    stream_options: { include_usage: true },
    response_format: { type: 'json_object' },
    frequency_penalty: 1,
    presence_penalty: 1,
    stop: ['x'],
  })
  assert.deepEqual(Object.keys(stripped.payload), ['model', 'messages'])
  assert.equal(stripped.cacheSessionId, 'dsh-sess-1', 'the cleaned host key is the logging affinity only')
  assert.equal(applyCommandCodeCache({ model: 'gpt-5.5' }).cacheSessionId, undefined)
})

// ---- failure classification (proxy semantics stay ours) ---------------------------

test('refusals are remapped so no 403 reads as a dead login, and caps read as quota', () => {
  const old = commandCodeFailure(403, { error: { code: 'upgrade_required', message: 'Your Command Code CLI is out of date.', minVersion: '0.18.10' } })
  assert.equal(old.status, 400)
  assert.match(old.message, /update the plugin/)
  assert.match(old.message, /minVersion 0\.18\.10/)
  assert.equal(/\b(?:401|403)\b/.test(old.message), false)

  const plan = commandCodeFailure(403, { error: { message: 'MODEL_NOT_IN_PLAN: gpt-6-sol' } })
  assert.equal(plan.status, 400)
  assert.match(plan.message, /^Model not in plan: gpt-6-sol$/)
  // The engine's failure() normalizes to the spaced spelling — still a 400.
  const engineShaped = commandCodeFailure(403, { error: { message: 'Model not in plan: gpt-6-sol available in Provider and above plans', type: 'commandcode_error', code: 403 } })
  assert.equal(engineShaped.status, 400)
  assert.match(engineShaped.message, /^Model not in plan: /)
  assert.equal(/\b(?:401|403)\b/.test(engineShaped.message), false)

  for (const status of [400, 402]) {
    const credits = commandCodeFailure(status, { error: { message: 'You have insufficient credits to make this request.' } })
    assert.equal(credits.status, 429)
    assert.match(credits.message, /^usage limit reached: /)
  }
  const window = commandCodeFailure(429, { error: { code: 'RATE_LIMITED', message: 'You have reached your 5-hour limit. It resets in 2h.' } })
  assert.equal(window.status, 429)
  assert.match(window.message, /^usage limit reached: /)

  assert.equal(commandCodeFailure(429, { error: { message: 'Too many requests' } }), undefined)
  assert.equal(commandCodeFailure(401, { error: { message: "Invalid 'Authorization' header or token." } }), undefined)
  assert.equal(commandCodeFailure(400, { success: false, error: { code: 'BAD_REQUEST', message: 'Validation error: expected string at "config.workingDir"' } }), undefined)
})

// ---- engine: quota ---------------------------------------------------------------

test('engine quota maps the allowance windows, the credits pool and the plan id', async (t) => {
  await withEngine(t, billingFake())
  const session = commandCodeSession({ accessToken: KEY, source: 'paste' })
  const quota = await fetchCommandCodeQuotaEngine(session, billingFake())
  assert.equal(quota.planType, 'individual-pro')
  assert.equal(quota.rows.length, 3)
  const fiveHour = quota.rows.find((row) => row.kind === 'primary')
  assert.equal(fiveHour.label, '5-hour')
  assert.equal(fiveHour.usedPercent, 40)
  assert.equal(fiveHour.remainingPercent, 60)
  assert.equal(fiveHour.resetAt, Date.parse('2099-01-01T05:00:00Z'))
  const weekly = quota.rows.find((row) => row.kind === 'weekly')
  assert.equal(weekly.usedPercent, 40)
  const credits = quota.rows.find((row) => row.kind === 'credits')
  assert.equal(credits.unit, 'usd')
  // plan monthly ($30) > pool monthly ($22.5): total = 30 + 4 + 0.5
  assert.equal(credits.total, 34.5)
  assert.equal(credits.used, 7.5)
  assert.equal(credits.resetAt, Date.parse('2099-02-01T00:00:00Z'))
})

test('engine quota tells Pro v1 from Pro: the write-back id beats the shared display name', async (t) => {
  const proV1 = { data: { planId: 'individual-pro-v1', status: 'active', currentPeriodStart: '2099-01-01T00:00:00Z', currentPeriodEnd: '2099-02-01T00:00:00Z' } }
  const fetchFn = billingFake({ subscription: proV1 })
  const dataDir = await withEngine(t, fetchFn)
  const authPath = join(dataDir, 'auth.json')
  await saveSession('command-code', commandCodeSession({ accessToken: KEY, source: 'paste' }), authPath)
  // Round 1 (no plan on the row yet): usage's write-back resolves the real id.
  const first = await fetchCommandCodeQuotaEngine(await getSession('command-code', authPath), fetchFn)
  assert.equal(first.planType, 'individual-pro-v1')
  // Round 2 on the stored row: the read confirms the id, nothing flips back.
  const second = await fetchCommandCodeQuotaEngine(await getSession('command-code', authPath), fetchFn)
  assert.equal(second.planType, 'individual-pro-v1')
  assert.equal(commandCodePlanLabel(second.planType), 'Pro')
  const stored = await listStoredSessions('command-code', authPath)
  assert.equal(stored[0].session.planType, 'individual-pro-v1', 'the vault value stops oscillating between the two Pro ids')
})

test('engine quota: a key with no plan and no windows reads as its balance alone', async (t) => {
  await withEngine(t, billingFake({
    subscription: { data: null },
    credits: { credits: { monthlyCredits: 0, purchasedCredits: 3.25, freeCredits: 0 } },
  }))
  const quota = await fetchCommandCodeQuotaEngine(commandCodeSession({ accessToken: KEY }), billingFake())
  assert.equal(quota.planType, undefined)
  assert.deepEqual(quota.rows, [{ key: 'credits', kind: 'credits', label: 'Credits', unit: 'usd', remaining: 3.25 }])
})

test('engine quota: an unread credits reply is its error, windows still map', async (t) => {
  const fetchFn = async (url) => {
    const href = String(url)
    if (href.endsWith('/alpha/billing/credits')) return json({ error: 'nope' }, 503)
    if (href.endsWith('/alpha/billing/subscriptions')) return json(LIVE_SUBSCRIPTION)
    return json({}, 404)
  }
  await withEngine(t, fetchFn)
  const quota = await fetchCommandCodeQuotaEngine(commandCodeSession({ accessToken: KEY }), fetchFn).catch((error) => error)
  assert.ok(quota instanceof Error)
  assert.match(quota.message, /credits read failed/)
})

// ---- engine: the loopback sign-in ------------------------------------------------

test('the engine loopback sign-in lands a vault session and rejects foreign states', { timeout: 15_000 }, async (t) => {
  const dataDir = await withEngine(t, billingFake())
  const controller = new AuthController({
    authPath: join(dataDir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    commandCodeAutoImport: false,
    fetchFn: billingFake(),
  })
  const started = await controller.login('command-code')
  assert.equal(started.mode, 'oauth')
  const authorize = new URL(started.authorizeUrl)
  assert.equal(authorize.origin + authorize.pathname, 'https://commandcode.ai/studio/auth/cli')
  assert.equal(authorize.searchParams.get('mode'), 'redirect')
  const callback = new URL(authorize.searchParams.get('callback'))
  const state = authorize.searchParams.get('state')
  assert.match(callback.toString(), /^http:\/\/127\.0\.0\.1:\d+\/callback$/)
  // A foreign state is refused; the engine's own state completes the POST.
  const wrong = await fetch(`${callback}?apiKey=${KEY}`, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ apiKey: KEY, userId: USER_UUID, userName: 'xxww0098', keyName: 'CLI login', state: 'not-mine' }),
  })
  assert.equal(wrong.status, 403)
  const landing = await fetch(`${callback}?state=${state}`, {
    method: 'POST',
    redirect: 'manual',
    headers: { 'content-type': 'application/x-www-form-urlencoded', origin: 'https://commandcode.ai' },
    body: new URLSearchParams({ apiKey: KEY, userId: USER_UUID, userName: 'xxww0098', keyName: 'CLI login', state }),
  })
  assert.equal(landing.status, 303)
  assert.match(landing.headers.get('location') ?? '', /^\/callback\/complete/,'the form branch redirects the browser to the landing page')
  const deadline = Date.now() + 5000
  let stored
  while (Date.now() < deadline) {
    stored = await getSession('command-code', join(dataDir, 'auth.json'))
    if (stored) break
    await new Promise((resolve) => setTimeout(resolve, 20))
  }
  assert.equal(stored.accessToken, KEY)
  assert.equal(stored.account, 'xxww0098')
  assert.equal(stored.source, 'browser')
  assert.equal(stored.planType, 'individual-pro', 'the plan the sign-in read is saved on the row')
})

// ---- engine: the hop --------------------------------------------------------------

function jsonlResponse(events) {
  return new Response(events.map((event) => JSON.stringify(event)).join('\n') + '\n', {
    status: 200,
    headers: { 'content-type': 'application/jsonl' },
  })
}

test('the engine hop passes a paid key straight through the Provider API', async (t) => {
  const seen: any[] = []
  const fetchFn = async (url, init = {}) => {
    const href = String(url)
    seen.push({ href, headers: new Headers(init.headers) })
    if (href.endsWith('/alpha/billing/subscriptions')) return json(LIVE_SUBSCRIPTION)
    if (href.endsWith('/chat/completions')) {
      const body = JSON.parse(String(init.body))
      assert.equal(body.session_id, undefined)
      assert.equal(body.prompt_cache_key, undefined)
      assert.equal(body.reasoning_effort, 'high')
      return json({ id: 'gen-1', choices: [{ index: 0, message: { role: 'assistant', content: 'ok' } }], usage: { prompt_tokens: 3 } })
    }
    return json({}, 404)
  }
  const dataDir = await withEngine(t, fetchFn)
  const session = commandCodeSession({ accessToken: KEY, source: 'paste', account: 'xxww0098', planType: 'individual-pro' })
  await saveSession('command-code', session, join(dataDir, 'auth.json'))
  const proxy = createProxy({ port: 0, apiKey: 'proxy-key-cc-test-xx', tokens: { 'command-code': { session: async () => session } }, fetchFn })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const response = await fetch(`http://127.0.0.1:${port}/command-code/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer proxy-key-cc-test-xx', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'zai-org/GLM-5.3', messages: [{ role: 'user', content: 'hi' }], reasoning_effort: 'high', session_id: 'dsh/sess 1', prompt_cache_key: 'codex-style' }),
    })
    assert.equal(response.status, 200)
    const body = await response.json()
    assert.equal(body.choices[0].message.content, 'ok')
    const chat = seen.find((row) => row.href.endsWith('/chat/completions'))
    assert.ok(chat, 'the hop reached the Provider API')
    assert.equal(chat.headers.get('authorization'), `Bearer ${KEY}`)
    assert.equal(chat.headers.get('x-api-key'), KEY)
    assert.equal(chat.headers.get('x-magpie-sign-in'), null, 'the engine host mark never reaches a DSH client')
    const generate = seen.find((row) => row.href === COMMAND_CODE_GENERATE_URL)
    assert.equal(generate, undefined, 'a paid key never touches /alpha/generate')
  } finally {
    await proxy.close()
  }
})

test('the engine hop reroutes a Go key to /alpha/generate with the CLI fingerprint', async (t) => {
  const seen: any[] = []
  const goSubscription = { data: { planId: 'individual-go', status: 'active' } }
  const fetchFn = async (url, init = {}) => {
    const href = String(url)
    seen.push({ href, headers: new Headers(init.headers), body: String(init.body ?? '') })
    if (href.endsWith('/alpha/billing/subscriptions')) return json(goSubscription)
    if (href.endsWith('/alpha/generate')) {
      const wire = JSON.parse(String(init.body))
      assert.equal(wire.params.model, 'zai-org/GLM-5.3')
      assert.equal(wire.params.stream, true)
      assert.equal(wire.params.max_tokens, 64000)
      assert.equal(wire.params.system, 'sys')
      return jsonlResponse([
        { type: 'text-delta', text: 'hel' },
        { type: 'text-delta', text: 'lo' },
        { type: 'finish', finishReason: 'stop', totalUsage: { inputTokens: 7, outputTokens: 2, inputTokenDetails: { cacheReadTokens: 3 } } },
      ])
    }
    return json({}, 404)
  }
  const dataDir = await withEngine(t, fetchFn)
  const session = commandCodeSession({ accessToken: KEY, source: 'paste', account: 'xxww0098', planType: 'individual-go' })
  await saveSession('command-code', session, join(dataDir, 'auth.json'))
  const proxy = createProxy({ port: 0, apiKey: 'proxy-key-cc-go-xx', tokens: { 'command-code': { session: async () => session } }, fetchFn })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const response = await fetch(`http://127.0.0.1:${port}/command-code/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer proxy-key-cc-go-xx', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'zai-org/GLM-5.3', messages: [{ role: 'system', content: 'sys' }, { role: 'user', content: 'hi' }], stream: false }),
    })
    assert.equal(response.status, 200)
    const body = await response.json()
    assert.equal(body.choices[0].message.content, 'hello')
    assert.equal(body.usage.prompt_tokens_details.cached_tokens, 3)
    const generate = seen.find((row) => row.href === COMMAND_CODE_GENERATE_URL)
    assert.ok(generate, 'a Go key rides /alpha/generate')
    assert.equal(generate.headers.get('user-agent'), 'cli')
    assert.equal(generate.headers.get('x-project-slug'), 'magpie')
    assert.equal(generate.headers.get('x-command-code-version'), '1.72.2')
    assert.match(generate.headers.get('x-session-id') ?? '', /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/, 'one process-level session uuid, not a conversation id')
  } finally {
    await proxy.close()
  }
})

test('the engine hop streams a Go key as SSE chunks and ends with DONE', async (t) => {
  const goSubscription = { data: { planId: 'individual-go', status: 'active' } }
  const fetchFn = async (url) => {
    const href = String(url)
    if (href.endsWith('/alpha/billing/subscriptions')) return json(goSubscription)
    if (href.endsWith('/alpha/generate')) {
      return jsonlResponse([
        { type: 'text-delta', text: 'hi' },
        { type: 'finish', finishReason: 'stop', totalUsage: { inputTokens: 1, outputTokens: 1 } },
      ])
    }
    return json({}, 404)
  }
  const dataDir = await withEngine(t, fetchFn)
  const session = commandCodeSession({ accessToken: KEY, source: 'paste', planType: 'individual-go' })
  await saveSession('command-code', session, join(dataDir, 'auth.json'))
  const proxy = createProxy({ port: 0, apiKey: 'proxy-key-cc-sse-xx', tokens: { 'command-code': { session: async () => session } }, fetchFn })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const response = await fetch(`http://127.0.0.1:${port}/command-code/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer proxy-key-cc-sse-xx', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'zai-org/GLM-5.3', messages: [{ role: 'user', content: 'hi' }], stream: true }),
    })
    assert.equal(response.status, 200)
    const text = await response.text()
    assert.match(text, /"delta":\{"content":"hi"\}/)
    assert.match(text, /data: \[DONE\]/)
  } finally {
    await proxy.close()
  }
})

test('a Go key the plan was not known for self-detects off the Provider refusal', async (t) => {
  const seen: any[] = []
  let planReads = 0
  const fetchFn = async (url, init = {}) => {
    const href = String(url)
    seen.push({ href, body: String(init.body ?? '') })
    if (href.endsWith('/alpha/billing/subscriptions')) {
      planReads += 1
      // The first read fails to say Go (empty data), later ones stay Go.
      return json(planReads === 1 ? { data: null } : { data: { planId: 'individual-go', status: 'active' } })
    }
    if (href.endsWith('/chat/completions')) {
      return json({ error: { message: 'Your Go plan doesn’t include API access. Upgrade to Provider or higher to use it.' } }, 403)
    }
    if (href.endsWith('/alpha/generate')) return jsonlResponse([{ type: 'text-delta', text: 'go' }, { type: 'finish', finishReason: 'stop' }])
    return json({}, 404)
  }
  const dataDir = await withEngine(t, fetchFn)
  const session = commandCodeSession({ accessToken: KEY, source: 'paste' })
  await saveSession('command-code', session, join(dataDir, 'auth.json'))
  const proxy = createProxy({ port: 0, apiKey: 'proxy-key-cc-noapi-xx', tokens: { 'command-code': { session: async () => session } }, fetchFn })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const response = await fetch(`http://127.0.0.1:${port}/command-code/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer proxy-key-cc-noapi-xx', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'zai-org/GLM-5.3', messages: [{ role: 'user', content: 'hi' }] }),
    })
    assert.equal(response.status, 200)
    const body = await response.json()
    assert.equal(body.choices[0].message.content, 'go')
    assert.ok(seen.some((row) => row.href.endsWith('/alpha/generate')), 'the refused Provider call rerouted to Go’s endpoint')
    // The write-back persisted the Go plan onto the vault row.
    const stored = await getSession('command-code', join(dataDir, 'auth.json'))
    assert.equal(stored.planType, 'individual-go')
  } finally {
    await proxy.close()
  }
})

// ---- snapshot with the engine quota ----------------------------------------------

test('snapshot shows engine quota on every account and the plan write-back', async (t) => {
  const dataDir = await withEngine(t, billingFake())
  const authPath = join(dataDir, 'auth.json')
  const session = commandCodeSession({ accessToken: KEY, source: 'paste' })
  await saveSession('command-code', session, authPath)
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    commandCodeAutoImport: false,
    fetchFn: billingFake(),
  })
  const snap = await controller.snapshot()
  assert.equal(snap.accounts['command-code'].loggedIn, true)
  const row = snap.accounts['command-code'].accounts[0]
  assert.equal(row.quota?.status, 'ready')
  assert.equal(row.quota.rows.length, 3)
  assert.equal(row.quota.rows.find((entry) => entry.kind === 'credits')?.total, 34.5)
  assert.equal(row.planLabel, 'Pro')
  const stored = await listStoredSessions('command-code', authPath)
  assert.equal(stored[0].session.planType, 'individual-pro', 'the usage read wrote the plan back')
  assert.equal(snap.catalog.some((entry) => entry.provider === 'oauth-command-code'), true)
})

test('proxy answers the models list and keeps /responses a documented 501', async (t) => {
  const dataDir = await withEngine(t, billingFake())
  const session = commandCodeSession({ accessToken: KEY, source: 'paste' })
  await saveSession('command-code', session, join(dataDir, 'auth.json'))
  const proxy = createProxy({ port: 0, apiKey: 'proxy-key-cc-misc-xx', tokens: { 'command-code': { session: async () => session } }, fetchFn: billingFake() })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const listed = await fetch(`http://127.0.0.1:${port}/command-code/v1/models`, { headers: { authorization: 'Bearer proxy-key-cc-misc-xx' } })
    assert.equal(listed.status, 200)
    const list = await listed.json()
    assert.equal(list.data.length, COMMAND_CODE_MODELS.length)
    const responses = await fetch(`http://127.0.0.1:${port}/command-code/v1/responses`, {
      method: 'POST',
      headers: { authorization: 'Bearer proxy-key-cc-misc-xx', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'claude-sonnet-5', input: [] }),
    })
    assert.equal(responses.status, 501)
  } finally {
    await proxy.close()
  }
})

// ---- UI ---------------------------------------------------------------------------

test('Command Code UI icon uses official command symbol (⌘), not prompt fallback', async () => {
  const src = assembleUi()
  assert.match(src, /commandCode: \{ d: 'M6,2A4,4 0 0,1 10,6V8H14V6/)
  assert.equal(src.includes('M5 4.5l7.5 7.5L5 19.5v-3.3l4.2-4.2L5 7.8V4.5z'), false)
  assert.equal(src.includes("'command-code': '#22c55e'"), false)
})
