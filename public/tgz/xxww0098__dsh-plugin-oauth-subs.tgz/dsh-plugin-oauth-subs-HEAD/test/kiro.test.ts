import assert from 'node:assert/strict'
import { mkdtemp, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import {
  BUILDER_ID_PROFILE_ARN,
  BUILDER_ID_START_URL,
  KIRO_MODELS,
  KIRO_PORTAL_URL,
  KIRO_USAGE_VERSION,
  allocateKiroMachineId,
  canonicalizeKiroMethod,
  exchangeKiroSocialCode,
  inferKiroAuthMethod,
  isKiroCredential,
  kiroAccountId,
  kiroAccountKind,
  kiroProfileArn,
  kiroMethodLabel,
  kiroSession,
  kiroSessionFromImport,
  KIRO_CALLBACK_PATHS,
  kiroIdcRedirectOf,
  kiroSocialFlow,
  kiroSocialRedirectUri,
  kiroSocialTokenRedirectUri,
  kiroUsageUrl,
  refreshKiro,
  refreshKiroSocial,
  validateKiroApiKey,
  validateKiroIdpEndpoint,
  validateKiroRefreshToken,
} from '../lib/oauth/kiro/index.js'
import { KiroIdcFlowManager, registerKiroOidcClient, kiroIdcSession } from '../lib/oauth/kiro/idc-flow.js'
import { fetchKiroQuota, parseKiroUsage } from '../lib/oauth/kiro/quota.js'
import { formatPlanLabel } from '../lib/oauth/plan.js'
import { OAuthFlowManager } from '../lib/oauth/flow.js'
import { AuthController } from '../lib/oauth/controller.js'
import { accountIdOf, getSession, listAccounts, saveSession } from '../lib/oauth/store.js'
import { buildProviders, catalogProviders, describeCatalog } from '../lib/oauth/models.js'
import { importKiroAuth, sessionFromKiroAuth } from '../lib/oauth/import-auth.js'
import {
  hydrateKiroSsoToken,
  kiroSsoClientIdHash,
  parseKiroImportText,
  sessionsFromKiroAuth,
} from '../lib/oauth/kiro/import.js'
import {
  classifyKiroHopError,
  collectKiroEvents,
  kiroClientErrorBody,
  kiroClientErrorStatus,
  kiroToOpenai,
  normalizeToolUseId,
  openaiToKiro,
} from '../lib/oauth/kiro/request.js'
import {
  KIRO_CATALOG_TTL_MS,
  kiroCatalogModels,
  refreshKiroCatalog,
  resetKiroCatalogCache,
  toKiroPickerModels,
} from '../lib/oauth/kiro/catalog.js'
import { exerciseLiveCatalog } from './catalog-lifecycle.ts'

const RT = `rt_${'x'.repeat(120)}`
const KEY = 'ksk_live_example1'

function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })
}

test('canonicalizeKiroMethod maps aliases including Entra and Builder ID', () => {
  assert.equal(canonicalizeKiroMethod('builder-id'), 'idc')
  assert.equal(canonicalizeKiroMethod('builderid'), 'idc')
  assert.equal(canonicalizeKiroMethod('enterprise'), 'idc')
  assert.equal(canonicalizeKiroMethod('entra-id'), 'external_idp')
  assert.equal(canonicalizeKiroMethod('azuread'), 'external_idp')
  assert.equal(canonicalizeKiroMethod('github'), 'social')
  assert.equal(canonicalizeKiroMethod('gmail'), 'social')
  assert.equal(canonicalizeKiroMethod('oauth'), 'social')
  assert.equal(canonicalizeKiroMethod('ksk'), 'api_key')
  assert.equal(canonicalizeKiroMethod(undefined, { tokenEndpoint: 'https://login.microsoftonline.com/t/oauth2/v2.0/token' }), 'external_idp')
})

test('kiro social authorize URL omits the callback path on redirect_uri', () => {
  const flow = kiroSocialFlow()
  assert.equal(flow.listen.host, 'localhost')
  assert.deepEqual(flow.callbackPaths, [...KIRO_CALLBACK_PATHS])
  const callback = 'http://localhost:3128/oauth/callback'
  const url = new URL(flow.buildAuthorizeUrl({
    state: 'st',
    pkce: { challenge: 'ch' },
    redirectUri: callback,
  }))
  assert.equal(`${url.origin}${url.pathname}`, `${KIRO_PORTAL_URL}/signin`)
  assert.equal(url.searchParams.get('redirect_uri'), 'http://localhost:3128')
  assert.equal(url.searchParams.get('redirect_uri'), kiroSocialRedirectUri(callback))
  assert.notEqual(url.searchParams.get('redirect_uri'), callback)
  assert.equal(url.searchParams.get('code_challenge_method'), 'S256')
  assert.equal(url.searchParams.get('redirect_from'), 'KiroIDE')
})

test('kiro API key and truncated refresh tokens are rejected', () => {
  assert.equal(validateKiroApiKey(KEY), KEY)
  assert.throws(() => validateKiroApiKey('sk-not-kiro'), /ksk_/)
  assert.equal(validateKiroRefreshToken(RT), RT)
  assert.throws(() => validateKiroRefreshToken(`${'short'.repeat(5)}...`), /truncated/)
  assert.throws(() => validateKiroRefreshToken('too-short'), /truncated/)
})

test('Entra token endpoint allow-list is microsoftonline https only', () => {
  const ok = validateKiroIdpEndpoint('https://login.microsoftonline.com/contoso/oauth2/v2.0/token')
  assert.equal(ok.startsWith('https://login.microsoftonline.com/'), true)
  assert.throws(() => validateKiroIdpEndpoint('http://login.microsoftonline.com/t/token'), /https/)
  assert.throws(() => validateKiroIdpEndpoint('https://evil.example/token'), /microsoftonline/)
})

test('kiro account ids keep Social / Builder / IdC / Entra / API key apart', () => {
  const social = kiroSession({ accessToken: 'a', refreshToken: RT, authMethod: 'social', account: 'dev@x' })
  const builder = kiroSession({
    accessToken: 'a', refreshToken: RT, authMethod: 'idc', startUrl: BUILDER_ID_START_URL, account: 'dev@x',
  })
  const enterprise = kiroSession({
    accessToken: 'a', refreshToken: RT, authMethod: 'idc', startUrl: 'https://d-123.awsapps.com/start', account: 'dev@x',
  })
  const entra = kiroSession({
    accessToken: 'a',
    refreshToken: RT,
    authMethod: 'external_idp',
    tokenEndpoint: 'https://login.microsoftonline.com/t/oauth2/v2.0/token',
    clientId: 'cid',
    account: 'dev@x',
  })
  const key = kiroSession({ accessToken: KEY, authMethod: 'api_key', account: 'dev@x' })
  assert.equal(kiroAccountKind(social), 'social')
  assert.equal(kiroAccountKind(builder), 'builder')
  assert.equal(kiroAccountKind(enterprise), 'idc')
  assert.equal(kiroAccountKind(entra), 'entra')
  assert.equal(kiroAccountKind(key), 'key')
  assert.equal(kiroMethodLabel(builder), 'Builder')
  assert.equal(kiroMethodLabel(enterprise), 'IdC')
  assert.equal(kiroAccountId(social), 'dev@x@social')
  assert.equal(accountIdOf('kiro', builder), 'dev@x@builder')
  assert.equal(accountIdOf('kiro', enterprise), 'dev@x@idc')
  assert.equal(accountIdOf('kiro', entra), 'dev@x@entra')
  assert.equal(accountIdOf('kiro', key), 'dev@x@key')
})

test('kiroSessionFromImport reads kiro.rs camelCase and rejects truncated RTs', () => {
  const session = kiroSessionFromImport({
    authMethod: 'social',
    accessToken: 'at',
    refreshToken: RT,
    email: 'a@x',
    subscriptionTitle: 'KIRO PRO+',
    profileArn: 'arn:aws:codewhisperer:us-east-1:1:profile/X',
  })
  assert.equal(session.authMethod, 'social')
  assert.equal(session.account, 'a@x')
  assert.equal(session.planType, 'KIRO PRO+')
  assert.equal(isKiroCredential({ authMethod: 'idc', refreshToken: RT }), true)
  assert.throws(() => kiroSessionFromImport({
    authMethod: 'social',
    refreshToken: 'abc...def',
    accessToken: 'at',
  }), /truncated/)
})

test('Builder ID quota sends the Builder ID ARN; only a 403 moves to the next region', async () => {
  const session = { authMethod: 'idc', kiroProvider: 'BuilderId' }
  const arn = `profileArn=${encodeURIComponent(BUILDER_ID_PROFILE_ARN)}`
  const urls: string[] = []
  const replies = [
    new Response('{}', { status: 403 }),
    new Response(JSON.stringify({ subscriptionInfo: { subscriptionTitle: 'KIRO POWER' } })),
  ]
  const quota = await fetchKiroQuota(session, async (url) => { urls.push(url); return replies.shift() })
  assert.equal(quota.planType, 'KIRO POWER')
  assert.deepEqual(urls.map((url) => [new URL(url).hostname.includes('us-east-1'), url.includes(arn)]), [[true, true], [false, true]])

  urls.length = 0
  await assert.rejects(
    fetchKiroQuota(session, async (url) => { urls.push(url); return new Response('{"message":"Invalid profileArn."}', { status: 400 }) }),
    /HTTP 400.*Invalid profileArn/,
  )
  assert.equal(urls.length, 1)
})

test('parseKiroUsage sums trial + bonus and reads email / plan', () => {
  const parsed = parseKiroUsage({
    subscriptionInfo: { subscriptionTitle: 'KIRO PRO+' },
    userInfo: { email: 'alice@example.com' },
    nextDateReset: 1_800_000_000,
    usageBreakdownList: [{
      currentUsageWithPrecision: 10,
      usageLimitWithPrecision: 100,
      freeTrialInfo: {
        freeTrialStatus: 'ACTIVE',
        currentUsageWithPrecision: 5,
        usageLimitWithPrecision: 20,
      },
      bonuses: [{ status: 'ACTIVE', currentUsage: 2, usageLimit: 10 }],
    }],
  })
  assert.equal(parsed.account, 'alice@example.com')
  assert.equal(parsed.planType, 'KIRO PRO+')
  assert.equal(parsed.rows[0].used, 17)
  assert.equal(parsed.rows[0].total, 130)
  assert.equal(parsed.rows[0].remaining, 113)
  assert.equal(parsed.rows[0].kind, 'cycle')
})

test('formatPlanLabel maps Kiro slugs without colliding with Codex Pro 20x', () => {
  assert.equal(formatPlanLabel('KIRO PRO+', 'kiro'), 'Pro+')
  assert.equal(formatPlanLabel('pro', 'kiro'), 'Pro')
  assert.equal(formatPlanLabel('pro', 'codex'), 'Pro 20x')
  assert.equal(formatPlanLabel('kiro_free', 'kiro'), 'Free')
  assert.equal(formatPlanLabel('KIRO POWERED', 'kiro'), 'Powered')
})

test('Kiro offline fallback is the KIRO_CONSOLE snapshot plus Fable 5 (no Auto), with native ids', () => {
  const catalog = catalogProviders({ prefix: 'oauth', origin: 'http://x' })
  const kiro = catalog['oauth-kiro']
  assert.deepEqual(kiro.models.map((model) => model.id), [
    'gpt-5.6-sol',
    'gpt-5.6-terra',
    'gpt-5.6-luna',
    'claude-opus-5.5',
    'claude-opus-5',
    'claude-opus-4.8',
    'claude-opus-4.7',
    'claude-opus-4.6',
    'claude-opus-4.5',
    'claude-sonnet-5.5',
    'claude-sonnet-5',
    'claude-fable-5.1',
    'claude-fable-5',
    'claude-sonnet-4.6',
    'claude-sonnet-4.5',
    'claude-sonnet-4',
    'claude-haiku-4.5',
    'deepseek-3.2',
    'minimax-m2.5',
    'glm-5',
    'minimax-m2.1',
    'qwen3-coder-next',
  ])
  assert.equal(kiro.models.find((model) => model.id === 'claude-sonnet-4-8'), undefined)
  assert.equal(kiro.models.find((model) => model.id === 'auto'), undefined)
  assert.equal(kiro.models.find((model) => model.id === 'claude-fable-5')?.name, 'Claude Fable 5')
  assert.equal(kiro.models.find((model) => model.id === 'claude-fable-5.1')?.name, 'Claude Fable 5.1')
  assert.equal(kiro.models.find((model) => model.id === 'claude-fable-5.1')?.contextWindow, 1_000_000)
  assert.equal(kiro.models.find((model) => model.id === 'gpt-5.6-sol').contextWindow, 1_000_000)
  assert.equal(kiro.models.find((model) => model.id === 'claude-opus-5').contextWindow, 1_000_000)
  assert.equal(kiro.models.find((model) => model.id === 'claude-sonnet-5').name, 'Claude Sonnet 5')
  const sonnet55 = KIRO_MODELS.find((model) => model.id === 'claude-sonnet-5.5')
  assert.equal(sonnet55.name, 'Claude Sonnet 5.5')
  assert.equal(sonnet55.contextWindow, 1_000_000)
  assert.equal(sonnet55.maxTokens, 128_000)
  assert.deepEqual(sonnet55.input, ['text', 'image'])
  assert.deepEqual(sonnet55.reasoningEfforts, {
    low: 'low',
    medium: 'medium',
    high: 'high',
    max: 'max',
    xhigh: 'xhigh',
  })
  assert.equal(kiro.models.find((model) => model.id === 'claude-sonnet-4').name, 'Claude Sonnet 4.0')
  assert.deepEqual(kiro.models.find((model) => model.id === 'claude-opus-4.8').input, ['text', 'image'])
  assert.deepEqual(kiro.models.find((model) => model.id === 'gpt-5.6-sol').input, ['text', 'image'])
  assert.deepEqual(kiro.models.find((model) => model.id === 'glm-5').input, ['text'])
  assert.deepEqual(kiro.models.find((model) => model.id === 'deepseek-3.2').input, ['text'])
  assert.deepEqual(kiro.models.find((model) => model.id === 'qwen3-coder-next').input, ['text'])
  assert.equal(kiro.models.find((model) => model.id === 'minimax-m2.1').contextWindow, 196_000)
  assert.deepEqual(kiro.models.find((model) => model.id === 'gpt-5.6-sol').reasoningEfforts, {
    off: 'none',
    low: 'low',
    medium: 'medium',
    high: 'high',
    xhigh: 'xhigh',
    max: 'max',
  })
  assert.deepEqual(kiro.models.find((model) => model.id === 'claude-opus-5').reasoningEfforts, {
    low: 'low',
    medium: 'medium',
    high: 'high',
    max: 'max',
    xhigh: 'xhigh',
  })
  assert.deepEqual(kiro.models.find((model) => model.id === 'claude-fable-5.1').reasoningEfforts, {
    low: 'low',
    medium: 'medium',
    high: 'high',
    max: 'max',
    xhigh: 'xhigh',
  })
  assert.deepEqual(kiro.models.find((model) => model.id === 'claude-sonnet-4.6').reasoningEfforts, {
    low: 'low',
    medium: 'medium',
    high: 'high',
    max: 'max',
  })
  assert.equal(kiro.models.find((model) => model.id === 'claude-sonnet-4.6').reasoningEfforts.xhigh, undefined)
  assert.equal(kiro.models.find((model) => model.id === 'claude-haiku-4.5').reasoningEfforts, false)
  assert.equal(kiro.models.find((model) => model.id === 'glm-5').reasoningEfforts, false)
  assert.equal(kiro.compat.supportsReasoningEffort, true)
  assert.equal(kiro.api, 'openai-completions')
  const described = describeCatalog(catalog).find((row) => row.family === 'kiro')
  assert.equal(described.displayName.includes('Kiro'), true)
  const loggedOut = buildProviders({ prefix: 'oauth', origin: 'http://x', loggedIn: { kiro: false } })
  assert.equal(loggedOut['oauth-kiro'], undefined)
})

test('exchangeKiroSocialCode posts landed callback path and login_option', async () => {
  const registered = 'http://localhost:3128/oauth/callback'
  let seen
  const session = await exchangeKiroSocialCode('code-1', 'verifier', registered, {
    callback: { pathname: '/signin/callback', loginOption: 'Google' },
    fetchFn: async (url, init) => {
      seen = { url: String(url), body: JSON.parse(init.body), headers: init.headers }
      return json({
        accessToken: 'at',
        refreshToken: RT,
        expiresIn: 3600,
        profileArn: 'arn:aws:codewhisperer:us-east-1:1:profile/X',
      })
    },
  })
  assert.equal(seen.body.redirect_uri, 'http://localhost:3128/signin/callback?login_option=google')
  assert.equal(seen.body.redirect_uri, kiroSocialTokenRedirectUri(registered, {
    pathname: '/signin/callback',
    loginOption: 'Google',
  }))
  assert.equal(Object.keys(seen.body).sort().join(','), 'code,code_verifier,redirect_uri')
  assert.equal(KIRO_USAGE_VERSION, '1.0.0')
  assert.match(seen.headers['user-agent'], /^KiroIDE-1\.0\.0-[0-9a-f]{64}$/i)
  assert.equal(seen.headers.accept, 'application/json, text/plain, */*')
  assert.equal(session.authMethod, 'social')
  assert.equal(session.accessToken, 'at')
  assert.equal(session.machineId, seen.headers['user-agent'].slice('KiroIDE-1.0.0-'.length))
})

test('exchangeKiroSocialCode reuses a machineId allocated before the browser opens', async () => {
  const machineId = allocateKiroMachineId()
  assert.match(machineId, /^[0-9a-f]{64}$/)
  assert.equal(allocateKiroMachineId(machineId), machineId)
  let seen
  const session = await exchangeKiroSocialCode('code-m', 'verifier', 'http://localhost:3128/oauth/callback', {
    machineId,
    callback: { pathname: '/oauth/callback', loginOption: 'google' },
    fetchFn: async (_url, init) => {
      seen = { body: JSON.parse(init.body), ua: init.headers['user-agent'] }
      return json({ accessToken: 'at', refreshToken: RT, expiresIn: 3600 })
    },
  })
  assert.equal(session.machineId, machineId)
  assert.equal(seen.ua, `KiroIDE-1.0.0-${machineId}`)
  assert.equal(seen.body.redirect_uri, 'http://localhost:3128/oauth/callback?login_option=google')
})

test('kiro social authorize stays origin-only; token uses landed callback', async () => {
  const registered = 'http://localhost:4649/oauth/callback'
  const authorizeRedirect = new URL(kiroSocialFlow().buildAuthorizeUrl({
    state: 'st',
    pkce: { challenge: 'ch' },
    redirectUri: registered,
  })).searchParams.get('redirect_uri')
  let tokenRedirect
  await exchangeKiroSocialCode('code-2', 'verifier', registered, {
    callback: { pathname: '/oauth/callback', loginOption: 'github' },
    fetchFn: async (_url, init) => {
      tokenRedirect = JSON.parse(init.body).redirect_uri
      return json({ accessToken: 'at', refreshToken: RT, expiresIn: 3600 })
    },
  })
  assert.equal(authorizeRedirect, 'http://localhost:4649')
  assert.equal(authorizeRedirect, kiroSocialRedirectUri(registered))
  assert.equal(tokenRedirect, 'http://localhost:4649/oauth/callback?login_option=github')
  assert.notEqual(tokenRedirect, authorizeRedirect)
  assert.equal(String(authorizeRedirect).includes('127.0.0.1'), false)
  assert.equal(String(tokenRedirect).includes('127.0.0.1'), false)
})

test('kiro social token redirect_uri keeps path when login_option is missing', () => {
  assert.equal(
    kiroSocialTokenRedirectUri('http://localhost:3128/oauth/callback', { pathname: '/oauth/callback' }),
    'http://localhost:3128/oauth/callback',
  )
  assert.equal(
    kiroSocialTokenRedirectUri('http://127.0.0.1:3128/oauth/callback', {
      pathname: '/signin/callback',
      loginOption: 'GitHub',
    }),
    'http://localhost:3128/signin/callback?login_option=github',
  )
  assert.equal(kiroSocialRedirectUri('http://127.0.0.1:3128/oauth/callback'), 'http://localhost:3128')
  assert.equal(kiroSocialRedirectUri('http://127.0.0.1:3128/oauth/callback').includes('127.0.0.1'), false)
})

test('Kiro Social loopback registers localhost and accepts / plus /oauth/callback', async () => {
  const flows = new OAuthFlowManager()

  const first = await flows.start('kiro', {
    ...kiroSocialFlow(),
    listen: { host: 'localhost', ports: [0] },
    timeoutMs: 8_000,
  })
  const redirect = new URL(first.authorizeUrl).searchParams.get('redirect_uri')
  assert.match(redirect, /^http:\/\/localhost:\d+$/)
  assert.equal(new URL(first.redirectUri).hostname, 'localhost')
  assert.equal(new URL(first.authorizeUrl).searchParams.get('redirect_from'), 'KiroIDE')
  const port = new URL(redirect).port
  const root = await fetch(`http://127.0.0.1:${port}/?code=from-root&state=${first.state}`)
  assert.equal(root.status, 200)
  assert.equal(await first.waitCode(), 'from-root')

  const second = await flows.start('kiro', {
    ...kiroSocialFlow(),
    listen: { host: 'localhost', ports: [0] },
    timeoutMs: 8_000,
  })
  const secondPort = new URL(second.redirectUri).port
  const callback = await fetch(`http://127.0.0.1:${secondPort}/oauth/callback?code=from-cb&state=${second.state}`)
  assert.equal(callback.status, 200)
  assert.equal(await second.waitCode(), 'from-cb')

  const third = await flows.start('kiro', {
    ...kiroSocialFlow(),
    listen: { host: 'localhost', ports: [0] },
    timeoutMs: 8_000,
  })
  const thirdPort = new URL(third.redirectUri).port
  const signin = await fetch(`http://127.0.0.1:${thirdPort}/signin/callback?code=from-signin&state=${third.state}&login_option=Google`)
  assert.equal(signin.status, 200)
  assert.equal(await third.waitCode(), 'from-signin')
  const landed = third.callback()
  assert.equal(landed.pathname, '/signin/callback')
  assert.equal(landed.loginOption, 'google')
  let tokenRedirect
  await exchangeKiroSocialCode('from-signin', third.pkce.verifier, third.redirectUri, {
    callback: landed,
    fetchFn: async (_url, init) => {
      tokenRedirect = JSON.parse(init.body).redirect_uri
      return json({ accessToken: 'at', refreshToken: RT, expiresIn: 3600 })
    },
  })
  assert.equal(tokenRedirect, `http://localhost:${thirdPort}/signin/callback?login_option=google`)
  assert.equal(String(tokenRedirect).includes('127.0.0.1'), false)
  assert.equal(new URL(third.authorizeUrl).searchParams.get('redirect_uri').includes('127.0.0.1'), false)
})

test('kiroIdcRedirectOf parses the portal awsidc redirect from the social callback', () => {
  // Issue #167's exact callback shape: organization chosen on the portal.
  const url = new URL(`http://localhost:3128/signin/callback?login_option=awsidc&issuer_url=${encodeURIComponent('https://d-abc.awsapps.com/start/')}&idc_region=us-east-1&state=st`)
  assert.deepEqual(kiroIdcRedirectOf(url), {
    issuerUrl: 'https://d-abc.awsapps.com/start/',
    region: 'us-east-1',
  })
  // A normal social code is never an IdC pivot, even with the option set.
  assert.equal(kiroIdcRedirectOf(new URL('http://localhost:3128/?code=x&state=st&login_option=awsidc')), undefined)
  // No issuer, or a non-https issuer: not actionable.
  assert.equal(kiroIdcRedirectOf(new URL('http://localhost:3128/?login_option=awsidc&state=st')), undefined)
  assert.equal(kiroIdcRedirectOf(new URL(`http://localhost:3128/?login_option=awsidc&issuer_url=${encodeURIComponent('http://insecure/start')}&state=st`)), undefined)
  // A missing / malformed region falls back to the default, not to a pivot failure.
  assert.deepEqual(
    kiroIdcRedirectOf(new URL(`http://localhost:3128/?login_option=awsidc&issuer_url=${encodeURIComponent('https://d-abc.awsapps.com/start')}&state=st`)),
    { issuerUrl: 'https://d-abc.awsapps.com/start', region: 'us-east-1' },
  )
  assert.equal(kiroIdcRedirectOf('https://not-a-url-object'), undefined)
})

test('Kiro social callback pivots an organization login to the IdC device flow', async () => {
  const flows = new OAuthFlowManager()
  const idcManager = new KiroIdcFlowManager()
  const registrations = []
  const fetchFn = async (url, init = {}) => {
    const href = String(url)
    if (href.endsWith('/client/register')) {
      registrations.push(JSON.parse(init.body).issuerUrl)
      return json({ clientId: 'cid', clientSecret: 'sec' })
    }
    if (href.endsWith('/device_authorization')) {
      return json({
        deviceCode: 'dc',
        userCode: 'ABCD-EFGH',
        verificationUri: 'https://view.awsapps.com/start/#/device',
        verificationUriComplete: 'https://view.awsapps.com/start/#/device?user_code=ABCD-EFGH',
        interval: 1,
        expiresIn: 600,
      })
    }
    return json({ error: 'authorization_pending' }, 400)
  }
  const attempt = await flows.start('kiro', {
    ...kiroSocialFlow({
      startIdc: (idc) => idcManager.start('kiro', {
        startUrl: idc.issuerUrl,
        kind: 'enterprise',
        region: idc.region,
        fetchFn,
      }),
    }),
    listen: { host: 'localhost', ports: [0] },
    timeoutMs: 8_000,
  })
  const port = new URL(attempt.redirectUri).port
  // The portal's "Your organization" redirect carries no code (issue #167):
  // the loopback forwards the browser to the device confirmation page and
  // waitCode resolves with the device-flow attempt.
  const callback = await fetch(`http://127.0.0.1:${port}/signin/callback?login_option=awsidc&issuer_url=${encodeURIComponent('https://d-abc.awsapps.com/start/')}&idc_region=us-east-1&state=${attempt.state}`)
  assert.equal(callback.status, 200)
  const page = await callback.text()
  assert.match(page, /https:\/\/view\.awsapps\.com\/start\/#\/device\?user_code=ABCD-EFGH/)
  assert.equal(page.includes('Login successful'), false)
  const settled = await attempt.waitCode()
  assert.equal(settled.kiroIdcAttempt.userCode, 'ABCD-EFGH')
  assert.deepEqual(registrations, ['https://d-abc.awsapps.com/start/'])
  assert.equal(flows.isBusy('kiro'), false)
  assert.equal(idcManager.isBusy('kiro'), true)
  settled.kiroIdcAttempt.cancel()
  assert.equal(idcManager.isBusy('kiro'), false)
})

test('controller kiro social login settles an organization callback as a stored IdC session', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  let polls = 0
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async (url, init = {}) => {
      const href = String(url)
      if (href.endsWith('/client/register')) return json({ clientId: 'cid', clientSecret: 'sec' })
      if (href.endsWith('/device_authorization')) {
        return json({
          deviceCode: 'dc',
          userCode: 'ABCD-EFGH',
          verificationUri: 'https://view.awsapps.com/start/#/device',
          verificationUriComplete: 'https://view.awsapps.com/start/#/device?user_code=ABCD-EFGH',
          interval: 1,
          expiresIn: 600,
        })
      }
      polls += 1
      if (polls === 1) return json({ error: 'authorization_pending' }, 400)
      return json({ accessToken: 'at', refreshToken: RT, expiresIn: 3600 })
    },
  })
  const result = await controller.login('kiro', { mode: 'social' })
  assert.equal(result.mode, 'pkce')
  const social = controller.flows.pending('kiro')
  const port = new URL(result.redirectUri).port
  const callback = await fetch(`http://127.0.0.1:${port}/signin/callback?login_option=awsidc&issuer_url=${encodeURIComponent('https://d-abc.awsapps.com/start/')}&idc_region=us-east-1&state=${social.state}`)
  assert.equal(callback.status, 200)
  const session = await new Promise((resolve, reject) => {
    const started = Date.now()
    const tick = async () => {
      const stored = await getSession('kiro', authPath).catch(() => undefined)
      if (stored?.authMethod === 'idc') return resolve(stored)
      if (Date.now() - started > 8_000) return reject(new Error('idc session never landed'))
      setTimeout(tick, 100)
    }
    void tick()
  })
  assert.equal(session.startUrl, 'https://d-abc.awsapps.com/start/')
  assert.equal(session.authRegion, 'us-east-1')
  assert.equal(session.kiroProvider, 'Enterprise')
  await controller.cancel('kiro')
})

test('refreshKiroSocial rewrites stale ms expiresAt from expiresIn', async () => {
  const stale = Date.parse('2026-08-31T10:04:33.000Z')
  const before = Date.now()
  const next = await refreshKiroSocial(kiroSession({
    accessToken: 'old',
    refreshToken: RT,
    authMethod: 'social',
    expiresAt: stale,
  }), {
    fetchFn: async () => json({ accessToken: 'next', refreshToken: RT, expiresIn: 3600 }),
  })
  assert.equal(next.accessToken, 'next')
  assert.notEqual(next.expiresAt, stale)
  assert.ok(next.expiresAt > before + 3_000_000)
  assert.ok(next.expiresAt <= before + 3_700_000)
  assert.ok(next.expiresAt - Date.now() > 2 * 60_000)
})

test('refreshKiroSocial 429 keeps HTTP status and Retry-After', async () => {
  await assert.rejects(
    () => refreshKiroSocial(kiroSession({
      accessToken: 'old',
      refreshToken: RT,
      authMethod: 'social',
      expiresAt: Date.now() - 1,
    }), {
      fetchFn: async () => new Response('Too many requests', {
        status: 429,
        headers: { 'retry-after': '2' },
      }),
    }),
    (error) => {
      assert.equal(error.status, 429)
      assert.equal(error.retryAfter, '2')
      assert.match(error.message, /HTTP 429/)
      assert.match(error.message, /Too many requests/)
      return true
    },
  )
})

test('refreshKiro social / idc / entra hit the matching endpoints', async () => {
  const seen = []
  const fetchFn = async (url, init) => {
    seen.push({ url: String(url), body: init.body, type: init.headers['content-type'] })
    return json({ accessToken: 'next', access_token: 'next', refreshToken: RT, expiresIn: 3600 })
  }
  const social = await refreshKiro(kiroSession({
    accessToken: 'old', refreshToken: RT, authMethod: 'social',
  }), { fetchFn })
  assert.equal(social.accessToken, 'next')
  assert.equal(seen[0].url.includes('auth.desktop.kiro.dev/refreshToken'), true)
  const idc = await refreshKiro(kiroSession({
    accessToken: 'old',
    refreshToken: RT,
    authMethod: 'idc',
    clientId: 'cid',
    clientSecret: 'sec',
    startUrl: BUILDER_ID_START_URL,
  }), { fetchFn })
  assert.equal(idc.authMethod, 'idc')
  assert.equal(seen[1].url, 'https://oidc.us-east-1.amazonaws.com/token')
  assert.equal(JSON.parse(seen[1].body).grantType, 'refresh_token')
  const entra = await refreshKiro(kiroSession({
    accessToken: 'old',
    refreshToken: RT,
    authMethod: 'external_idp',
    clientId: 'cid',
    tokenEndpoint: 'https://login.microsoftonline.com/t/oauth2/v2.0/token',
  }), { fetchFn })
  assert.equal(entra.authMethod, 'external_idp')
  assert.equal(seen[2].type, 'application/x-www-form-urlencoded')
})

test('registerKiroOidcClient posts JSON camelCase to /client/register', async () => {
  let seen
  const registered = await registerKiroOidcClient({
    startUrl: BUILDER_ID_START_URL,
    fetchFn: async (url, init) => {
      seen = { url: String(url), body: JSON.parse(init.body) }
      return json({ clientId: 'cid', clientSecret: 'sec' })
    },
  })
  assert.equal(seen.url, 'https://oidc.us-east-1.amazonaws.com/client/register')
  assert.equal(seen.body.clientType, 'public')
  assert.equal(seen.body.issuerUrl, BUILDER_ID_START_URL)
  const session = kiroIdcSession({
    accessToken: 'at', refreshToken: RT, expiresIn: 3600,
  }, registered, { kind: 'builder' })
  assert.equal(session.kiroProvider, 'BuilderId')
  assert.equal(session.authMethod, 'idc')
})

test('controller snapshot lists Kiro catalog and quota on every account', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  const later = Date.now() + 60 * 60_000
  await saveSession('kiro', kiroSession({
    accessToken: 'tok-a', refreshToken: `${RT}a`, authMethod: 'social', account: 'a@x',
  }), authPath)
  await saveSession('kiro', kiroSession({
    accessToken: 'tok-b', refreshToken: `${RT}b`, authMethod: 'social', account: 'b@x',
  }), authPath)
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async (_url, init) => {
      const auth = String(init?.headers?.authorization ?? '')
      const used = auth.includes('tok-b') ? 10 : 40
      return json({
        subscriptionInfo: { subscriptionTitle: 'KIRO PRO' },
        userInfo: { email: auth.includes('tok-b') ? 'b@x' : 'a@x' },
        usageBreakdownList: [{ currentUsageWithPrecision: used, usageLimitWithPrecision: 100 }],
      })
    },
  })
  const snap = await controller.snapshot()
  assert.equal(snap.catalog.length, 18)
  assert.equal(snap.catalog.some((row) => row.family === 'kiro'), true)
  const roster = snap.accounts.kiro.accounts
  assert.equal(roster.length, 2)
  const first = roster.find((row) => row.account === 'a@x')
  const second = roster.find((row) => row.account === 'b@x')
  assert.equal(first.quota.status, 'ready')
  assert.equal(second.quota.status, 'ready')
  assert.equal(first.quota.rows[0].remainingPercent, 60)
  assert.equal(second.quota.rows[0].remainingPercent, 90)
  assert.equal(second.active, true)
  assert.equal(second.methodLabel, 'Social')
  assert.equal(second.quota.planLabel, 'Pro')
})

test('controller useKey stores a Kiro API key', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async () => json({
      subscriptionInfo: { subscriptionTitle: 'KIRO FREE' },
      usageBreakdownList: [{ currentUsageWithPrecision: 0, usageLimitWithPrecision: 50 }],
    }),
  })
  const result = await controller.useKey('kiro', KEY, { mode: 'api_key' })
  assert.equal(result.method, 'api_key')
  const roster = await listAccounts('kiro', authPath)
  assert.equal(roster[0].methodLabel, 'API key')
})

test('controller kiro Social login allocates machineId before opening the browser', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const authPath = join(dir, 'auth.json')
  const prior = allocateKiroMachineId()
  await saveSession('kiro', kiroSession({
    accessToken: 'old', refreshToken: RT, authMethod: 'social', account: 'old@x', machineId: prior,
  }), authPath)
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async () => { throw new Error('social login must not hit AWS before the browser') },
  })
  const result = await controller.login('kiro', { mode: 'social' })
  assert.equal(result.mode, 'pkce')
  assert.equal(result.machineId, prior)
  assert.equal(controller.flows.pending('kiro').machineId, prior)
  assert.match(result.authorizeUrl, /^https:\/\/app\.kiro\.dev\/signin\?/)
  const authorizeRedirect = new URL(result.authorizeUrl).searchParams.get('redirect_uri')
  assert.match(authorizeRedirect, /^http:\/\/localhost:\d+$/)
  await controller.cancel('kiro')
})

test('controller kiro Builder ID login registers an OIDC client then can cancel', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const calls = []
  const controller = new AuthController({
    authPath: join(dir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async (url, init = {}) => {
      const href = String(url)
      calls.push(href)
      if (href.endsWith('/client/register')) return json({ clientId: 'cid', clientSecret: 'sec' })
      if (href.endsWith('/device_authorization')) {
        return json({
          deviceCode: 'dc',
          userCode: 'ABCD-EFGH',
          verificationUri: 'https://view.awsapps.com/start/#/device',
          interval: 1,
          expiresIn: 600,
        })
      }
      return json({ error: 'authorization_pending' }, 400)
    },
  })
  const result = await controller.login('kiro', { mode: 'builder' })
  assert.equal(result.mode, 'device')
  assert.equal(result.userCode, 'ABCD-EFGH')
  assert.equal(result.kind, 'builder')
  assert.equal(calls.some((href) => href.endsWith('/client/register')), true)
  await controller.cancel('kiro')
})

test('sessionFromKiroAuth and importKiroAuth read a kiro.rs credentials dump', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'kiro-imp-'))
  const path = join(dir, 'credentials.json')
  await writeFile(path, JSON.stringify({
    authMethod: 'social',
    accessToken: 'at',
    refreshToken: RT,
    email: 'imp@x',
    provider: 'Github',
  }))
  const imported = await importKiroAuth([path])
  assert.equal(imported.session.account, 'imp@x')
  assert.equal(imported.source, path)
  assert.equal(imported.sessions.length, 1)
  assert.equal(sessionFromKiroAuth({ foo: 1 }), undefined)
})

test('inferKiroAuthMethod reads kiro-manager-lite provider without authMethod', () => {
  assert.equal(inferKiroAuthMethod({ provider: 'BuilderId', refreshToken: RT, clientId: 'cid', clientSecret: 'sec' }), 'idc')
  assert.equal(inferKiroAuthMethod({ provider: 'Github', refreshToken: RT }), 'social')
  assert.equal(inferKiroAuthMethod({ clientId: 'cid', clientSecret: 'sec', refreshToken: RT }), 'idc')
  assert.equal(inferKiroAuthMethod({ kiroApiKey: KEY }), 'api_key')
  assert.equal(isKiroCredential({ email: 'a@x', refreshToken: RT, provider: 'BuilderId' }), true)
})

test('parseKiroImportText reads kami, compact JSON, full backup, and CSV', () => {
  const kami = parseKiroImportText(`a@x----no_password----${RT}----cid----sec----BuilderId`)
  assert.equal(kami.kind, 'kami')
  assert.equal(kami.sessions.length, 1)
  assert.equal(kami.sessions[0].authMethod, 'idc')
  assert.equal(kami.sessions[0].account, 'a@x')
  assert.equal(kami.sessions[0].clientId, 'cid')
  assert.equal(kami.sessions[0].clientSecret, 'sec')

  const compact = parseKiroImportText(JSON.stringify([
    { email: 'gh@x', refreshToken: RT, provider: 'Github' },
    { email: 'b@x', refreshToken: RT, provider: 'BuilderId', clientId: 'cid', clientSecret: 'sec' },
  ]))
  assert.equal(compact.kind, 'json')
  assert.equal(compact.sessions.length, 2)
  assert.equal(compact.sessions[0].authMethod, 'social')
  assert.equal(compact.sessions[1].authMethod, 'idc')

  const backup = parseKiroImportText(JSON.stringify({
    app: 'kiro-account-lite',
    version: '1.0.19',
    accounts: [{
      email: 'full@x',
      idp: 'Google',
      credentials: {
        accessToken: 'at',
        refreshToken: RT,
        authMethod: 'social',
        expiresAt: Date.now() + 3_600_000,
      },
      subscription: { title: 'KIRO PRO' },
    }],
  }))
  assert.equal(backup.kind, 'json')
  assert.equal(backup.sessions.length, 1)
  assert.equal(backup.sessions[0].account, 'full@x')
  assert.equal(backup.sessions[0].authMethod, 'social')
  assert.equal(backup.sessions[0].planType, 'KIRO PRO')

  const csv = parseKiroImportText(`邮箱,refreshToken,登录方式,clientId,clientSecret\nb@x,${RT},BuilderId,cid,sec`)
  assert.equal(csv.kind, 'csv')
  assert.equal(csv.sessions.length, 1)
  assert.equal(csv.sessions[0].authMethod, 'idc')
  assert.equal(csv.sessions[0].account, 'b@x')
})

test('importKiroAuth writes every account in a kiro.rs array', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'kiro-multi-'))
  const path = join(dir, 'credentials.json')
  await writeFile(path, JSON.stringify([
    { authMethod: 'social', accessToken: 'at1', refreshToken: RT, email: 'one@x', provider: 'Github' },
    { authMethod: 'idc', accessToken: 'at2', refreshToken: RT, email: 'two@x', provider: 'BuilderId', clientId: 'cid', clientSecret: 'sec' },
  ]))
  const imported = await importKiroAuth([path])
  assert.equal(imported.sessions.length, 2)
  assert.deepEqual(imported.sessions.map((row) => row.account).sort(), ['one@x', 'two@x'])
  assert.equal(sessionsFromKiroAuth({ accounts: [] }).length, 0)
})

test('hydrateKiroSsoToken pairs IDE token with hashed OIDC registration', async () => {
  const hash = kiroSsoClientIdHash()
  const dir = await mkdtemp(join(tmpdir(), 'kiro-sso-'))
  const tokenPath = join(dir, 'kiro-auth-token.json')
  await writeFile(tokenPath, JSON.stringify({
    accessToken: 'at',
    refreshToken: RT,
    expiresAt: new Date(Date.now() + 3_600_000).toISOString(),
    authMethod: 'IdC',
    provider: 'BuilderId',
    clientIdHash: hash,
  }))
  await writeFile(join(dir, `${hash}.json`), JSON.stringify({
    clientId: 'oidc-cid',
    clientSecret: 'oidc-sec',
  }))
  const imported = await importKiroAuth([tokenPath])
  assert.equal(imported.session.authMethod, 'idc')
  assert.equal(imported.session.clientId, 'oidc-cid')
  assert.equal(imported.session.clientSecret, 'oidc-sec')
  const merged = hydrateKiroSsoToken(
    { refreshToken: RT, authMethod: 'IdC' },
    { clientId: 'x', clientSecret: 'y' },
  )
  assert.equal(merged.clientId, 'x')
  assert.equal(merged.clientSecret, 'y')
})

test('controller paste imports kami and compact JSON as multiple Kiro cards', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const path = join(dir, 'auth.json')
  const controller = new AuthController({
    authPath: path,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async () => json({
      accessToken: 'new-at',
      refreshToken: RT,
      expiresIn: 3600,
      profileArn: 'arn:aws:codewhisperer:us-east-1:1:profile/X',
    }),
  })
  const kami = await controller.useKey('kiro', ['gh@x', 'no_password', RT, '', '', 'Google'].join('----'))
  assert.equal(kami.count, 1)
  assert.equal(kami.method, 'social')
  const compact = await controller.useKey('kiro', JSON.stringify({
    email: 'full@x',
    accessToken: 'kept-at',
    refreshToken: RT,
    provider: 'Github',
  }))
  assert.equal(compact.count, 1)
  const roster = await listAccounts('kiro', path)
  assert.equal(roster.length, 2)
})

test('Kiro vault can hold one card per credential method', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-subs-'))
  const path = join(dir, 'auth.json')
  const later = Date.now() + 60 * 60_000
  const shared = { accessToken: 'at', refreshToken: RT, account: 'dev@x', expiresAt: later }
  await saveSession('kiro', kiroSession({ ...shared, authMethod: 'social' }), path)
  await saveSession('kiro', kiroSession({
    ...shared, authMethod: 'idc', startUrl: BUILDER_ID_START_URL, clientId: 'cid', clientSecret: 'sec',
  }), path)
  await saveSession('kiro', kiroSession({
    ...shared, authMethod: 'idc', startUrl: 'https://d-123.awsapps.com/start', clientId: 'cid', clientSecret: 'sec',
  }), path)
  await saveSession('kiro', kiroSession({
    ...shared,
    authMethod: 'external_idp',
    tokenEndpoint: 'https://login.microsoftonline.com/t/oauth2/v2.0/token',
    clientId: 'cid',
  }), path)
  await saveSession('kiro', kiroSession({ accessToken: KEY, authMethod: 'api_key', account: 'dev@x' }), path)
  const roster = await listAccounts('kiro', path)
  assert.equal(roster.length, 5)
  assert.deepEqual(roster.map((row) => row.methodLabel).sort(), ['API key', 'Builder', 'Entra', 'IdC', 'Social'])
  const ids = new Set(roster.map((row) => row.id))
  assert.equal(ids.size, 5)

  const controller = new AuthController({
    authPath: path,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    settings: { mutate: async () => undefined },
    fetchFn: async () => json({
      subscriptionInfo: { subscriptionTitle: 'KIRO PRO' },
      userInfo: { email: 'dev@x' },
      usageBreakdownList: [{ currentUsageWithPrecision: 1, usageLimitWithPrecision: 100 }],
    }),
  })
  const snap = await controller.snapshot()
  const cards = snap.accounts.kiro.accounts
  assert.equal(cards.length, 5)
  for (const card of cards) {
    assert.equal(card.quota.status, 'ready')
    assert.equal(card.account, 'dev@x')
  }
})

/** Real tool turns always offer tools; without them the wire carries the calls as text (`toolHistoryAsText`). */
const STUB_TOOLS = [{ type: 'function', function: { name: 'stub', description: 'stub', parameters: { type: 'object', properties: {} } } }]

const PIPED_TOOL_ID = 'call_abc123|fc_this_is_an_openai_responses_compound_id_over_sixty_four_chars_xx'

function toolCall(id, name = 'run_code', args = '{}') {
  return { id, type: 'function', function: { name, arguments: args } }
}

function toolUseIds(row) {
  return row?.assistantResponseMessage?.toolUses?.map((item) => item.toolUseId) ?? []
}

function toolResultIdsOf(row) {
  const results = row?.userInputMessage?.userInputMessageContext?.toolResults
    ?? row?.userInputMessageContext?.toolResults
  return (results ?? []).map((item) => item.toolUseId)
}

test('piped OpenAI tool ids remap stably on use and result', () => {
  assert.ok(PIPED_TOOL_ID.includes('|'))
  assert.ok(PIPED_TOOL_ID.length > 64)
  const first = normalizeToolUseId(PIPED_TOOL_ID)
  const second = normalizeToolUseId(PIPED_TOOL_ID)
  assert.equal(first, second)
  assert.match(first, /^tooluse_[A-Za-z0-9_-]{1,56}$/)
  assert.equal(first.includes('|'), false)
  assert.ok(first.length <= 64)
  assert.equal(normalizeToolUseId('call_1'), 'tooluse_1')
  assert.equal(normalizeToolUseId('toolu_bdrk_01Ez5MSML7fNdsjMvkPUTeCd'), 'tooluse_bdrk_01Ez5MSML7fNdsjMvkPUTeCd')

  const body = openaiToKiro({
    tools: STUB_TOOLS,
    model: 'claude-opus-5',
    messages: [
      { role: 'user', content: 'run it' },
      { role: 'assistant', content: '', tool_calls: [toolCall(PIPED_TOOL_ID)] },
      { role: 'tool', tool_call_id: PIPED_TOOL_ID, content: '{"ok":true}' },
    ],
  })
  const history = body.conversationState.history
  const current = body.conversationState.currentMessage.userInputMessage
  const useId = history.find((row) => row.assistantResponseMessage?.toolUses)?.assistantResponseMessage.toolUses[0].toolUseId
  assert.equal(useId, first)
  assert.deepEqual(toolResultIdsOf(current), [first])
  const again = openaiToKiro({
    tools: STUB_TOOLS,
    model: 'claude-opus-5',
    messages: [
      { role: 'user', content: 'run it' },
      { role: 'assistant', content: '', tool_calls: [toolCall(PIPED_TOOL_ID)] },
      { role: 'tool', tool_call_id: PIPED_TOOL_ID, content: '{"ok":true}' },
    ],
  })
  assert.equal(
    again.conversationState.history.find((row) => row.assistantResponseMessage?.toolUses)
      ?.assistantResponseMessage.toolUses[0].toolUseId,
    useId,
  )
})

test('interleaved A/B tool results relocate before positional flush', () => {
  const body = openaiToKiro({
    tools: STUB_TOOLS,
    model: 'claude-sonnet-5',
    messages: [
      { role: 'user', content: 'start' },
      { role: 'assistant', content: '', tool_calls: [toolCall('call_A', 'alpha')] },
      { role: 'user', content: 'meanwhile' },
      { role: 'assistant', content: '', tool_calls: [toolCall('call_B', 'bravo')] },
      { role: 'tool', tool_call_id: 'call_A', content: '{"a":1}' },
      { role: 'tool', tool_call_id: 'call_B', content: '{"b":2}' },
    ],
  })
  const history = body.conversationState.history
  const aIdx = history.findIndex((row) => toolUseIds(row).includes('tooluse_A'))
  assert.notEqual(aIdx, -1)
  assert.deepEqual(toolResultIdsOf(history[aIdx + 1]), ['tooluse_A'])
  // Relocate is a pure reorder — do not merge the intervening user text onto the
  // tool-result turn. Empty content when toolResults is set (AWS pairing).
  assert.equal(history[aIdx + 1].userInputMessage.content, '')
  assert.equal(history.some((row) => row.userInputMessage?.content === 'meanwhile'), true)
  const bIdx = history.findIndex((row) => toolUseIds(row).includes('tooluse_B'))
  assert.ok(bIdx > aIdx)
  assert.deepEqual(toolResultIdsOf(body.conversationState.currentMessage), ['tooluse_B'])
  assert.equal(body.conversationState.currentMessage.userInputMessage.content, '')
  assert.equal(JSON.stringify(body).includes('Tool results provided.'), false)
})

test('live catalog replaces the fallback, asks with the chat origin, drops auto, reads live efforts', async () => {
  resetKiroCatalogCache()
  const session = kiroSession({ accessToken: 'live-tok', refreshToken: RT, authMethod: 'social' })
  const seen = []
  const effort = (key, values) => ({ properties: { [key]: { properties: { effort: { enum: values } } } } })
  const models = await refreshKiroCatalog(session, {
    fetchFn: async (url) => {
      const href = String(url)
      seen.push(href)
      if (href.includes('us-east-1') && href.includes('List-Available-Models')) {
        return new Response('no profile here', { status: 403 })
      }
      if (href.includes('List-Available-Profiles')) {
        return json({ profiles: [{ arn: 'arn:aws:codewhisperer:eu-central-1:1:profile/X' }] })
      }
      return json({
        models: [
          { modelId: 'auto', modelName: 'Auto' },
          { modelId: 'kiro-live-only', modelName: 'Kiro Live Only', additionalModelRequestFieldsSchema: effort('output_config', ['low', 'high', 'xhigh']) },
          { modelId: 'deepseek-3.2', modelName: 'Deepseek v3.2', supportedInputTypes: ['TEXT', 'IMAGE'], additionalModelRequestFieldsSchema: null },
          { modelId: 'gpt-5.6-sol', modelName: 'GPT 5.6 Sol', additionalModelRequestFieldsSchema: effort('reasoning', ['none', 'high']) },
        ],
      })
    },
  })
  assert.ok(seen.some((href) => href.includes('eu-central-1') || href.includes('List-Available-Profiles')))
  assert.ok(seen.filter((href) => href.includes('List-Available-Models')).every((href) => href.includes('origin=AI_EDITOR')))
  // Fallback order first, live-only after; fallback rows the live list omits are gone.
  assert.deepEqual(models.map((model) => model.id), ['gpt-5.6-sol', 'deepseek-3.2', 'kiro-live-only'])
  const row = (id) => models.find((model) => model.id === id)
  assert.equal(row('gpt-5.6-sol').name, 'GPT-5.6 Sol')
  assert.equal(row('kiro-live-only').name, 'Kiro Live Only')
  assert.deepEqual(row('gpt-5.6-sol').reasoningEfforts, { off: 'none', high: 'high' })
  assert.deepEqual(row('kiro-live-only').reasoningEfforts, { low: 'low', high: 'high', xhigh: 'xhigh' })
  assert.equal(row('deepseek-3.2').reasoningEfforts, false)
  assert.deepEqual(row('deepseek-3.2').input, ['text', 'image'])
  resetKiroCatalogCache()
})

test('an unlisted Claude 5.5 id still infers the adaptive ladder and 1M window', () => {
  const models = toKiroPickerModels([{ modelId: 'claude-sonnet-5.5', modelName: 'Claude Sonnet 5.5' }])
  assert.equal(models.length, 1)
  assert.equal(models[0].contextWindow, 1_000_000)
  assert.deepEqual(models[0].reasoningEfforts, { low: 'low', medium: 'medium', high: 'high', max: 'max', xhigh: 'xhigh' })
  assert.deepEqual(models[0].input, ['text', 'image'])
})

test('empty ListAvailableModels keeps the static fallback', async () => {
  resetKiroCatalogCache()
  const session = kiroSession({ accessToken: 'empty-tok', refreshToken: RT, authMethod: 'social' })
  const models = await refreshKiroCatalog(session, {
    fetchFn: async () => json({ models: [] }),
  })
  assert.deepEqual(models.map((model) => model.id), KIRO_MODELS.map((model) => model.id))
  resetKiroCatalogCache()
})

test('MONTHLY_REQUEST_COUNT is a 429 quota answer, distinct from the rate limit', () => {
  const body = { reason: 'MONTHLY_REQUEST_COUNT', message: 'monthly request count exceeded' }
  const classified = classifyKiroHopError(400, body, JSON.stringify(body))
  assert.equal(classified.status, 429)
  assert.equal(classified.code, 'kiro_quota')
  assert.equal(classified.retryAfter, undefined)
  assert.equal(kiroClientErrorStatus(400, body, JSON.stringify(body)), 429)
  assert.equal(classifyKiroHopError(429, { reason: 'USER_REQUEST_RATE_EXCEEDED' }, '', { retryAfter: '2' }).status, 429)
  assert.equal(classifyKiroHopError(503, { reason: 'INSUFFICIENT_MODEL_CAPACITY' }, '').status, 503)
  assert.equal(classifyKiroHopError(400, { reason: 'CONTENT_LENGTH_EXCEEDS_THRESHOLD' }, '').status, 400)
  assert.equal(kiroClientErrorStatus(403), 400)
})

// Verbatim from DSH (`isContextWindowExceededError`, dsh-llm): the pi-ai adapter
// maps an errored turn matching it to CONTEXT_WINDOW_EXCEEDED, the only code
// that makes the host condense the conversation and go on.
const STRUCTURED_CONTEXT_OVERFLOW = new RegExp(String.raw`(?:^|[^a-z0-9])context[\s_-](?:length|window)[\s_-]`
  + String.raw`(?:exceed(?:ed|s)?|overflow(?:ed)?|limit[\s_-]exceeded)(?:$|[^a-z0-9])`, 'i')
const TOO_LARGE_FOR_CONTEXT = new RegExp(String.raw`\b(?:request|prompt|input|messages?)\s+(?:is\s+|are\s+)?`
  + String.raw`too\s+(?:large|long)\s+for\s+(?:(?:this|the)\s+)?`
  + String.raw`(?:model(?:'s)?\s+)?context(?:\s+window)?\b`, 'i')
const EXCEEDS_MODEL_CONTEXT = new RegExp(String.raw`\b(?:input|prompt|request|messages?)\b.{0,40}`
  + String.raw`\b(?:exceed(?:s|ed)?|overflows?|is\s+larger\s+than)\b.{0,40}`
  + String.raw`\b(?:the\s+)?(?:model(?:'s)?\s+)?context(?:\s+(?:length|window))?\b`, 'i')
function hostSeesContextOverflow(detail) {
  return STRUCTURED_CONTEXT_OVERFLOW.test(detail)
    || /\b(?:maximum|max)(?:\s+(?:allowed|supported))?\s+context\s+(?:length|window)\b/i.test(detail)
    || TOO_LARGE_FOR_CONTEXT.test(detail)
    || /\b(?:input|prompt|request)\s+(?:is\s+)?too\s+(?:long|large)\s+for\s+(?:this|the)\s+model\b/i.test(detail)
    || EXCEEDS_MODEL_CONTEXT.test(detail)
}

test('Kiro "Input is too long" reaches the host worded as a context overflow, so it condenses instead of failing the turn', () => {
  for (const raw of [
    { reason: 'CONTENT_LENGTH_EXCEEDS_THRESHOLD', message: 'Input is too long.' },
    { reason: 'INPUT_TOO_LONG', message: 'Input is too long.' },
  ]) {
    assert.equal(hostSeesContextOverflow(raw.message), false, 'Kiro\'s own wording is not recognized by the host')
    const body = kiroClientErrorBody(400, raw, JSON.stringify(raw))
    assert.equal(body.error.code, 'kiro_too_big')
    assert.ok(body.error.message.endsWith('Input is too long.'), 'the vendor text is kept')
    assert.equal(hostSeesContextOverflow(JSON.stringify(body.error)), true, body.error.message)
  }
  // Only size answers are reworded.
  for (const raw of [
    { reason: 'INSUFFICIENT_MODEL_CAPACITY', message: 'high load' },
    { reason: 'MONTHLY_REQUEST_COUNT', message: 'monthly request count exceeded' },
  ]) {
    assert.equal(hostSeesContextOverflow(JSON.stringify(kiroClientErrorBody(400, raw, JSON.stringify(raw)).error)), false)
  }
})

test('thinking events do not leak XML into content', () => {
  const collected = collectKiroEvents([
    { type: 'thinkingEvent', payload: { text: 'I will plan the edit' } },
    { type: 'assistantResponseEvent', payload: { content: 'hello from kiro' } },
  ])
  assert.equal(collected.text, 'hello from kiro')
  assert.equal(collected.thinking, 'I will plan the edit')
  assert.equal(collected.text.includes('<thinking>'), false)
  assert.equal(collected.thinking.includes('<thinking>'), false)
  const openai = kiroToOpenai([
    { type: 'thinkingEvent', payload: { thinkingEvent: { text: 'step one' } } },
    { type: 'assistantResponseEvent', payload: { content: 'done' } },
  ], { model: 'claude-sonnet-5', id: 'chatcmpl-think' })
  assert.equal(openai.choices[0].message.content, 'done')
  assert.equal(openai.choices[0].message.reasoning_content, 'step one')
  assert.equal(String(openai.choices[0].message.content).includes('<thinking>'), false)
  assert.equal(JSON.stringify(openai.choices[0].message).includes('<thinking>'), false)
})

test('kiro catalog refresh drops a result that returns after reset', async () => {
  await exerciseLiveCatalog({
    label: 'kiro',
    ttlMs: KIRO_CATALOG_TTL_MS,
    dropStaticId: KIRO_MODELS[0].id,
    reset: resetKiroCatalogCache,
    models: kiroCatalogModels,
    refresh: ({ token, now, ttlMs, fetch }) => refreshKiroCatalog({ accessToken: token }, {
      now,
      ttlMs,
      fetchLive: async () => {
        const kind = await fetch()
        if (kind === 'fail' || kind === 'empty') return []
        return [{ modelId: kind === 'a' ? 'live-only-a' : 'live-only-b', modelName: kind === 'a' ? 'A' : 'B' }]
      },
    }),
  })
})
