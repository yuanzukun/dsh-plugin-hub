import assert from 'node:assert/strict'
import { test } from 'node:test'
import { OAuthFlowManager } from '../lib/oauth/flow.js'
import { createPkce } from '../lib/utils/pkce.js'
import {
  CODEX_CLIENT_ID,
  CODEX_ORIGINATOR,
  CODEX_USER_AGENT,
  CODEX_CLIENT_VERSION,
  codexFlow,
  codexCredentialHeaders,
  codexRoutingHint,
  codexUpstreamHeaders,
  exchangeCodexCode,
  refreshCodex,
} from '../lib/oauth/codex/index.js'
import { GROK_USER_AGENT, grokCredentialHeaders, grokUpstreamHeaders } from '../lib/oauth/grok/index.js'

function jwtId() {
  const header = Buffer.from(JSON.stringify({ alg: 'none' })).toString('base64url')
  const body = Buffer.from(JSON.stringify({
    'https://api.openai.com/auth': { chatgpt_account_id: 'acct-1' },
  })).toString('base64url')
  return `${header}.${body}.x`
}

test('codexFlow builds the Codex CLI authorize URL', () => {
  const pkce = createPkce()
  const url = new URL(codexFlow.buildAuthorizeUrl({
    redirectUri: 'http://localhost:1455/auth/callback',
    state: 'st',
    pkce,
  }))
  assert.equal(url.origin + url.pathname, 'https://auth.openai.com/oauth/authorize')
  assert.equal(url.searchParams.get('client_id'), CODEX_CLIENT_ID)
  assert.equal(url.searchParams.get('code_challenge_method'), 'S256')
  assert.equal(url.searchParams.get('originator'), CODEX_ORIGINATOR)
  assert.equal(url.searchParams.get('codex_cli_simplified_flow'), 'true')
})

test('Codex originator and User-Agent are the official CLI pair', () => {
  const cred = codexCredentialHeaders()
  assert.equal(cred.originator, 'codex_cli_rs')
  assert.equal(cred['user-agent'], `codex_cli_rs/${CODEX_CLIENT_VERSION}`)
  assert.equal(CODEX_USER_AGENT, cred['user-agent'])
  const upstream = codexUpstreamHeaders({ accessToken: 'tok', accountId: 'acct' })
  assert.equal(upstream.originator, cred.originator)
  assert.equal(upstream['user-agent'], cred['user-agent'])
  assert.equal(upstream['openai-version'], CODEX_CLIENT_VERSION)
})

test('codexRoutingHint matches Codex CLI x-codex-routing-hint', () => {
  assert.equal(codexRoutingHint('gpt-5.6-luna', 'priority'), 'model=gpt-5.6-luna;tier=priority')
  assert.equal(codexRoutingHint('gpt-5.5', undefined), 'model=gpt-5.5')
  assert.equal(codexRoutingHint('gpt-5.5', ''), 'model=gpt-5.5')
  assert.equal(codexRoutingHint('', 'priority'), undefined)
})

test('exchangeCodexCode and refreshCodex send the same identity pair', async () => {
  const seen = []
  const fetchFn = async (url, init) => {
    seen.push(init.headers)
    return new Response(JSON.stringify({
      access_token: 'a.b.c',
      refresh_token: 'r',
      expires_in: 3600,
      id_token: jwtId(),
    }), { status: 200 })
  }
  await exchangeCodexCode('code', 'ver', 'http://localhost/cb', fetchFn)
  await refreshCodex({ refreshToken: 'r', accountId: 'acct-1' }, fetchFn)
  assert.equal(seen[0].originator, 'codex_cli_rs')
  assert.equal(seen[0]['user-agent'], CODEX_USER_AGENT)
  assert.equal(seen[1].originator, seen[0].originator)
  assert.equal(seen[1]['user-agent'], seen[0]['user-agent'])
})

test('Grok conversation headers use grok-cli User-Agent', () => {
  const cred = grokCredentialHeaders()
  assert.equal(cred['user-agent'], GROK_USER_AGENT)
  const upstream = grokUpstreamHeaders({ accessToken: 'g' })
  assert.equal(upstream['x-xai-token-auth'], 'xai-grok-cli')
  assert.equal(upstream['user-agent'], GROK_USER_AGENT)
})

test('OAuthFlowManager accepts a pasted callback URL with matching state', async () => {
  const flows = new OAuthFlowManager()
  const attempt = await flows.start('codex', {
    callbackPath: '/auth/callback',
    listen: { host: '127.0.0.1', ports: [0] },
    timeoutMs: 5_000,
    buildAuthorizeUrl: ({ redirectUri, state, pkce }) =>
      `https://example.test/authorize?redirect_uri=${encodeURIComponent(redirectUri)}&state=${state}&cc=${pkce.challenge}`,
  })
  assert.match(attempt.redirectUri, /^http:\/\/127\.0\.0\.1:\d+\/auth\/callback$/)
  assert.equal(flows.isBusy('codex'), true)
  attempt.manual(`${attempt.redirectUri}?code=abc123&state=${attempt.state}`)
  assert.equal(await attempt.waitCode(), 'abc123')
  assert.equal(typeof await attempt.waitCode(), 'string')
  assert.equal(flows.isBusy('codex'), false)
})

test('OAuthFlowManager reserves the slot before awaiting listen', async () => {
  const flows = new OAuthFlowManager()
  const spec = {
    callbackPath: '/auth/callback',
    listen: { host: '127.0.0.1', ports: [0] },
    timeoutMs: 5_000,
    buildAuthorizeUrl: ({ redirectUri }) => `https://example.test/authorize?redirect_uri=${encodeURIComponent(redirectUri)}`,
  }
  const first = flows.start('codex', spec)
  // The reservation must be visible synchronously, before listen() resolves —
  // otherwise a second call passes the guard and binds a second listener.
  assert.equal(flows.isBusy('codex'), true)
  await assert.rejects(() => flows.start('codex', spec), /already in progress/)
  const attempt = await first
  assert.equal(flows.isBusy('codex'), true)
  attempt.cancel()
  assert.equal(flows.isBusy('codex'), false)
})

test('OAuthFlowManager keeps waitCode a string and stores Kiro callback metadata', async () => {
  const flows = new OAuthFlowManager()
  const attempt = await flows.start('kiro', {
    callbackPath: '/oauth/callback',
    callbackPaths: ['/', '/oauth/callback', '/signin/callback'],
    listen: { host: 'localhost', ports: [0] },
    timeoutMs: 5_000,
    buildAuthorizeUrl: ({ redirectUri }) => `https://example.test/authorize?redirect_uri=${encodeURIComponent(redirectUri)}`,
  })
  attempt.manual(`http://localhost:3128/signin/callback?code=kiro-code&state=${attempt.state}&loginOption=GitHub`)
  assert.equal(await attempt.waitCode(), 'kiro-code')
  assert.equal(typeof await attempt.waitCode(), 'string')
  assert.deepEqual(attempt.callback(), {
    pathname: '/signin/callback',
    loginOption: 'github',
    issuerUrl: undefined,
  })
})

test('OAuthFlowManager rejects a mismatched pasted state', async () => {
  const flows = new OAuthFlowManager()
  const attempt = await flows.start('codex', {
    callbackPath: '/auth/callback',
    listen: { host: '127.0.0.1', ports: [0] },
    timeoutMs: 5_000,
    buildAuthorizeUrl: () => 'https://example.test/authorize',
  })
  assert.throws(() => attempt.manual('http://localhost/cb?code=x&state=other'), /state mismatch/)
  attempt.cancel()
  await assert.rejects(attempt.waitCode(), /cancelled/)
})

test('Codex and Antigravity callback paths stay exact; Kiro-only extras 404', async () => {
  const flows = new OAuthFlowManager()
  const attempt = await flows.start('codex', {
    callbackPath: '/auth/callback',
    listen: { host: '127.0.0.1', ports: [0] },
    timeoutMs: 5_000,
    buildAuthorizeUrl: ({ redirectUri }) => `https://example.test/authorize?redirect_uri=${encodeURIComponent(redirectUri)}`,
  })
  const port = new URL(attempt.redirectUri).port
  const root = await fetch(`http://127.0.0.1:${port}/?code=x&state=${attempt.state}`)
  assert.equal(root.status, 404)
  const kiroPath = await fetch(`http://127.0.0.1:${port}/oauth/callback?code=x&state=${attempt.state}`)
  assert.equal(kiroPath.status, 404)
  const ok = await fetch(`http://127.0.0.1:${port}/auth/callback?code=abc&state=${attempt.state}`)
  assert.equal(ok.status, 200)
  assert.equal(await attempt.waitCode(), 'abc')
})

test('OAuth error callbacks require state proof and leave other login attempts intact', async t => {
  const flows = new OAuthFlowManager()
  const attempt = await flows.start('codex', {
    callbackPath: '/auth/callback',
    listen: { host: '127.0.0.1', ports: [0] },
    timeoutMs: 5_000,
    buildAuthorizeUrl: () => 'https://example.test/authorize',
  })
  const result = attempt.waitCode().then(code => ({ code }), error => ({ error }))
  t.after(async () => { attempt.cancel(); await result })
  for (const suffix of ['', '&state=another-login']) {
    const response = await fetch(attempt.redirectUri + '?error=access_denied' + suffix)
    assert.equal(response.status, 400)
    assert.equal(await response.text(), 'state mismatch')
    assert.equal(flows.isBusy('codex'), true)
  }
  const response = await fetch(attempt.redirectUri + '?code=valid-code&state=' + attempt.state)
  assert.equal(response.status, 200)
  assert.deepEqual(await result, { code: 'valid-code' })
})

test('OAuth error callbacks with matching state still report authorization failure', async () => {
  const flows = new OAuthFlowManager()
  const attempt = await flows.start('codex', {
    callbackPath: '/auth/callback',
    listen: { host: '127.0.0.1', ports: [0] },
    timeoutMs: 5_000,
    buildAuthorizeUrl: () => 'https://example.test/authorize',
  })
  const rejected = assert.rejects(attempt.waitCode(), /authorization failed: access_denied/)
  try {
    const response = await fetch(attempt.redirectUri + '?error=access_denied&state=' + attempt.state)
    assert.equal(response.status, 200)
    await rejected
    assert.equal(flows.isBusy('codex'), false)
  } finally {
    attempt.cancel()
  }
})

test('OAuthFlowManager rejects a bare code without state proof', async () => {
  const flows = new OAuthFlowManager()
  const attempt = await flows.start('codex', {
    callbackPath: '/auth/callback',
    listen: { host: '127.0.0.1', ports: [0] },
    timeoutMs: 5_000,
    buildAuthorizeUrl: () => 'https://example.test/authorize',
  })
  assert.throws(() => attempt.manual('abc123'), /no authorization code/)
  assert.throws(() => attempt.manual('code=abc123'), /state mismatch/)
  attempt.cancel()
  await assert.rejects(attempt.waitCode(), /cancelled/)
})
