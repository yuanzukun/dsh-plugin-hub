import assert from 'node:assert/strict'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { AuthController } from '../lib/oauth/controller.js'
import { createProxy } from '../lib/oauth/proxy.js'
import {
  getSession,
  listStoredSessions,
  saveSession,
} from '../lib/oauth/store.js'
import { isPermanentRefreshFailure } from '../lib/oauth/tokens.js'
import { modelSupportsFastMode } from '../lib/utils/fast-mode.js'
import {
  AUTOCLAW_SITES,
  autoclawBareToken,
  autoclawJwtClaim,
  autoclawSession,
  autoclawTokenFields,
} from '../lib/oauth/autoclaw/index.js'
import {
  autoclawEngineAuthorizeBrowser,
  autoclawEngineAuthorizeSms,
  fetchAutoclawCnQuotaEngine,
  fetchAutoclawQuotaEngine,
  refreshAutoclawEngine,
  resetAutoclawEnginePlugin,
  resetAutoclawSmsPending,
} from '../lib/oauth/autoclaw/engine.js'
import { loginAutoclaw, loginAutoclawCn } from '../lib/oauth/autoclaw/accounts.js'
import { AUTOCLAW_REFUSED_HINT, classifyAutoclawFailure } from '../lib/oauth/autoclaw/request.js'
import { AUTOCLAW_CN_MODELS, AUTOCLAW_MODELS, autoclawModelOf } from '../lib/oauth/autoclaw/catalog.js'
import {
  AUTOCLAW_CN_STABLE_SESSION,
  AUTOCLAW_STABLE_SESSION,
  applyAutoclawCache,
  autoclawCacheSessionId,
  isAutoclawFallback,
} from '../lib/oauth/autoclaw/cache.js'
import { configureUpstreamEngine, resetUpstreamEngineCache } from '../lib/upstream-engine/engine.js'
import { configureEngineBridge, resetEngineBridge } from '../lib/upstream-engine/bridge.js'
import {
  AUTOCLAW_FIXTURE_MODULE,
  AUTOCLAW_FIXTURE_NPM,
  AUTOCLAW_FIXTURE_SYSTEM_PROMPT,
  AUTOCLAW_FIXTURE_VERSION,
  writeEngineCache,
} from './upstream-engine-fixture.ts'

function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })
}

const b64url = (value) => Buffer.from(JSON.stringify(value)).toString('base64url')
const jwt = (claims) => `${b64url({ alg: 'none' })}.${b64url(claims)}.sig`

async function tmpDir(t, tag) {
  const dir = await mkdtemp(join(tmpdir(), `autoclaw-${tag}-`))
  t.after(() => rm(dir, { recursive: true, force: true }))
  return dir
}

async function waitFor(predicate, message, timeoutMs = 5000) {
  const deadline = Date.now() + timeoutMs
  for (;;) {
    if (await predicate()) return
    if (Date.now() > deadline) throw new Error(`timed out waiting for ${message}`)
    await new Promise((resolve) => setTimeout(resolve, 20))
  }
}

/** The engine lane under a tmp data dir, its global fetch bridge-routed. */
async function withEngine(t, fetchFn, module: string = AUTOCLAW_FIXTURE_MODULE) {
  const dataDir = await tmpDir(t, 'engine')
  const entry = { npm: AUTOCLAW_FIXTURE_NPM, version: AUTOCLAW_FIXTURE_VERSION, integrity: 'sha512-fixture' }
  await writeEngineCache(dataDir, {
    npm: AUTOCLAW_FIXTURE_NPM,
    version: AUTOCLAW_FIXTURE_VERSION,
    module,
    engines: { autoclaw: entry, 'autoclaw-cn': entry },
  })
  resetUpstreamEngineCache()
  resetAutoclawEnginePlugin()
  resetAutoclawSmsPending()
  configureUpstreamEngine(join(dataDir, 'auth.json'))
  configureEngineBridge({ fetchFn })
  t.after(() => {
    resetUpstreamEngineCache()
    resetAutoclawEnginePlugin()
    resetAutoclawSmsPending()
    resetEngineBridge()
    configureUpstreamEngine(undefined)
  })
  return dataDir
}

const engineSession = (family: 'autoclaw' | 'autoclaw-cn', overrides: any = {}) => autoclawSession({
  accessToken: 'a1',
  refreshToken: 'r1',
  expiresAt: Date.now() + 3_600_000,
  account: 'Tester',
  source: family === 'autoclaw-cn' ? 'sms' : 'oauth',
  ...overrides,
})

// ---- 会话形状 ------------------------------------------------------------------

test('tokenFields: the JWT exp is the truth, with the 10-minute skew', () => {
  const access = jwt({ exp: 2_000_000_000 })
  assert.equal(autoclawBareToken(`Bearer ${access}`), access)
  assert.deepEqual(
    autoclawTokenFields({ access_token: `Bearer ${access}`, refresh_token: 'Bearer r1' }),
    { accessToken: access, refreshToken: 'r1', expiresAt: 2_000_000_000_000 - 10 * 60_000 },
  )
  const before = Date.now()
  const fallback = autoclawTokenFields({ access_token: 'a1', refresh_token: 'r1', expires_in: 3600 })
  const after = Date.now()
  assert.ok(fallback.expiresAt >= before + 3600_000 - 600_000 && fallback.expiresAt <= after + 3600_000 - 600_000)
  assert.throws(() => autoclawTokenFields({ refresh_token: 'r1' }), /no access_token/)
  assert.throws(() => autoclawTokenFields({ access_token: 'a1' }), /no refresh_token/)
  assert.equal(autoclawJwtClaim(jwt({ device_id: 'dev-1' }), 'device_id'), 'dev-1')
})

// ---- 引擎登录 ------------------------------------------------------------------

test('the engine local-OAuth login exchanges the state-checked code into a stored session', { timeout: 20_000 }, async (t) => {
  const calls: any[] = []
  const fetchFn = async (url, init = {}) => {
    calls.push({ url: String(url), init })
    const target = String(url)
    if (target.includes('/userapi/overseasv1/google-oauth-login')) {
      const body = JSON.parse(String(init.body ?? '{}'))
      assert.equal(body.code, 'eng-code-1')
      assert.equal(body.state, 'st-9')
      return json({ code: 0, msg: 'ok', data: { access_token: 'a2', refresh_token: 'r2', user_id: 'u1' } })
    }
    if (target.includes('/userapi/v1/user-profile')) {
      return json({ code: 0, msg: 'ok', data: { user_name: '小龙虾' } })
    }
    return json({ code: 0, msg: 'ok', data: {} })
  }
  const dataDir = await withEngine(t, fetchFn)
  const controller = new AuthController({
    authPath: join(dataDir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    fetchFn,
  })
  const started = await loginAutoclaw(controller)
  assert.equal(started.mode, 'browser')
  assert.match(started.authorizeUrl, /^http:\/\/127\.0\.0\.1:\d+\//)

  // The browser lands on the engine's own local callback with the code.
  const callback = new URL('auth/callback-google', started.authorizeUrl)
  callback.searchParams.set('code', 'eng-code-1')
  callback.searchParams.set('state', 'st-9')
  const landed = await fetch(callback)
  assert.equal(landed.status, 200)

  await waitFor(async () => Boolean(await getSession('autoclaw', join(dataDir, 'auth.json'))), 'the engine sign-in to settle')
  const stored = await getSession('autoclaw', join(dataDir, 'auth.json'))
  assert.equal(stored.accessToken, 'a2')
  assert.equal(stored.refreshToken, 'r2')
  assert.equal(stored.account, '小龙虾', 'the display name comes from user-profile')
  assert.equal(stored.uid, 'u1')
  assert.equal(stored.source, 'oauth')
})

test('a cancelled browser login never reaches the vault, even if the page finishes after the cancel', { timeout: 20_000 }, async (t) => {
  const calls: string[] = []
  const fetchFn = async (url, init = {}) => {
    const target = String(url)
    calls.push(target)
    if (target.includes('/userapi/overseasv1/google-oauth-login')) {
      return json({ code: 0, msg: 'ok', data: { access_token: 'a8', refresh_token: 'r8', user_id: 'u8' } })
    }
    if (target.includes('/userapi/v1/user-profile')) {
      return json({ code: 0, msg: 'ok', data: { user_name: '取消后完成者' } })
    }
    return json({ code: 0, msg: 'ok', data: {} })
  }
  const dataDir = await withEngine(t, fetchFn)
  const controller = new AuthController({
    authPath: join(dataDir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    fetchFn,
  })
  const started = await loginAutoclaw(controller)
  await controller.cancel('autoclaw')
  // The browser page still lands afterwards: the engine settles its own
  // callback, but the cancelled slot must gate the save (workbuddy shape).
  const callback = new URL('auth/callback-google', started.authorizeUrl)
  callback.searchParams.set('code', 'eng-code-too-late')
  callback.searchParams.set('state', 'st-late')
  const landed = await fetch(callback)
  assert.equal(landed.status, 200)
  await waitFor(async () => calls.some((u) => u.includes('google-oauth-login')), 'the late code to be exchanged')
  await new Promise((resolve) => setTimeout(resolve, 100))
  assert.equal(await getSession('autoclaw', join(dataDir, 'auth.json')), undefined, 'a cancelled login saves nothing')
  assert.equal(controller.lastError.get('autoclaw'), undefined, 'a cancel is not an error')
})

test('the engine CN SMS login sends the code, then exchanges digits into a stored session', async (t) => {
  const calls: any[] = []
  const fetchFn = async (url, init = {}) => {
    calls.push({ url: String(url), init })
    const target = String(url)
    if (target.includes('/agent-send-code')) {
      assert.deepEqual(JSON.parse(String(init.body ?? '{}')), { phone: '13800138000', device_id: 'fixture' })
      return json({ code: 0, msg: 'ok', data: {} })
    }
    if (target.includes('/agent-login/')) {
      assert.equal(JSON.parse(String(init.body ?? '{}')).code, 123456, 'digits go as numbers')
      return json({ code: 0, msg: 'ok', data: { access_token: 'a3', refresh_token: 'r3', user_id: 'u2' } })
    }
    if (target.includes('/userapi/v1/user-profile')) {
      return json({ code: 0, msg: 'ok', data: { user_phone: '13800138000' } })
    }
    return json({ code: 0, msg: 'ok', data: {} })
  }
  const dataDir = await withEngine(t, fetchFn)
  const controller = new AuthController({
    authPath: join(dataDir, 'auth.json'),
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    fetchFn,
  })
  const sent = await loginAutoclawCn(controller, { phone: '13800138000' })
  assert.equal(sent.mode, 'code-sent')
  assert.match(sent.message, /138\*\*\*\*0000|验证码已发送/)
  const done = await loginAutoclawCn(controller, { phone: '13800138000', code: '123456' })
  assert.equal(done.account.account, '13800138000', 'no nickname: the phone names the row')
  const stored = await getSession('autoclaw-cn', join(dataDir, 'auth.json'))
  assert.equal(stored.accessToken, 'a3')
  assert.equal(stored.source, 'sms')

  await assert.rejects(
    loginAutoclawCn(controller, { phone: '13800138000', code: '000000' }),
    /登录失败|验证码会话已过期/,
    'a fresh code needs a fresh send',
  )
})

// ---- 引擎刷新 ------------------------------------------------------------------

test('the engine refresh rotates once and back-fills the account name', async (t) => {
  const refreshAsks: any[] = []
  const fetchFn = async (url, init = {}) => {
    if (String(url).includes('/userapi/v1/refresh')) {
      refreshAsks.push(JSON.parse(String(init.body ?? '{}')))
      return json({ code: 0, msg: 'ok', data: { access_token: 'a9', refresh_token: 'r9' } })
    }
    if (String(url).includes('/userapi/v1/user-profile')) {
      return json({ code: 0, msg: 'ok', data: { user_name: '补拉的名字' } })
    }
    return json({ code: 0, msg: 'ok', data: {} })
  }
  await withEngine(t, fetchFn)
  const session = engineSession('autoclaw', { account: '已登录' })
  const next = await refreshAutoclawEngine('autoclaw', session, fetchFn)
  assert.equal(next.accessToken, 'a9')
  assert.equal(next.refreshToken, 'r9')
  assert.equal(next.account, '补拉的名字', 'a nameless row is renamed from user-profile on refresh')
  assert.equal(refreshAsks.length, 1)
  assert.equal(refreshAsks[0].refresh_token, 'r1')

  let dead: any
  const refusedFake = async () => json({ code: 400002, msg: 'refresh_token 无效' })
  configureEngineBridge({ fetchFn: refusedFake })
  try {
    await refreshAutoclawEngine('autoclaw', session, refusedFake)
    assert.fail('a refused refresh must throw')
  } catch (error) {
    dead = error
  }
  assert.match(String(dead.message), /refresh refused|无效/)
  assert.equal(isPermanentRefreshFailure(dead), true, 'a dead grant reaps the row, it does not loop')
})

test('a refresh the engine marks signIn=expired reads as a dead grant (401/403/revoked forms)', async (t) => {
  // Upstream 0.2.1 verdict shapes the fixture cannot produce: the marked
  // envelope death (`signIn="expired"`, index.mjs:477-481) and a bare 403.
  const markedEngine = `export const AutoclawAuthPlugin = async () => ({
    auth: {
      provider: 'autoclaw',
      methods: [{ type: 'oauth', authorize: async () => ({ url: 'http://127.0.0.1:9/', method: 'auto', callback: async () => ({ type: 'failed', error: 'unused' }) }) }],
      async refresh(auth) {
        if (auth?.refresh === 'r-403') throw Object.assign(new Error('AutoClaw refresh non-envelope response (HTTP 403): forbidden'), { signIn: 'expired' })
        throw Object.assign(new Error('AutoClaw token refresh failed (HTTP 200): revoked'), { signIn: 'expired' })
      },
      loader: async () => ({}),
      usage: async () => ({ windows: [] }),
    },
  })
  export const AutoclawCnAuthPlugin = AutoclawAuthPlugin
  `
  const idle = async () => json({ code: 0, msg: 'ok', data: {} })
  await withEngine(t, idle, markedEngine)
  for (const refreshToken of ['r1', 'r-403']) {
    let dead: any
    try {
      await refreshAutoclawEngine('autoclaw', engineSession('autoclaw', { refreshToken }), idle)
      assert.fail('the marked refresh must throw')
    } catch (error) {
      dead = error
    }
    assert.equal(dead.status, 401)
    assert.equal(dead.oauthCode, 'invalid_grant')
    assert.equal(isPermanentRefreshFailure(dead), true, `the engine's signIn=expired verdict reaps the row (${refreshToken})`)
  }
})

// ---- 目录 / 缓存 / 分类（本仓侧不变） -------------------------------------------

test('catalog rows carry the upstream limits for both builds', () => {
  assert.deepEqual(AUTOCLAW_MODELS.map((row) => row.id), ['zai_auto', 'zai_auto-fast', 'zaicoding_glm-5.3', 'zai_glm-5.3-flash'])
  assert.deepEqual(AUTOCLAW_CN_MODELS.map((row) => row.id), ['zai_auto', 'zai_auto-fast', 'zaicoding_glm-5.3', 'zai_glm-5.3-flash'])
  assert.equal(autoclawModelOf('autoclaw', 'zai_auto').contextWindow, 200000)
  assert.equal(autoclawModelOf('autoclaw', 'zai_auto').maxTokens, 32000)
  assert.equal(autoclawModelOf('autoclaw-cn', 'zai_auto').maxTokens, 393216)
  assert.deepEqual(autoclawModelOf('autoclaw-cn', 'zai_auto').input, ['text', 'image'])
  assert.deepEqual(autoclawModelOf('autoclaw-cn', 'zai_auto').reasoningEfforts, { low: 'low', high: 'high', max: 'max' })
  assert.equal(modelSupportsFastMode('zai_auto'), false)
  assert.equal(modelSupportsFastMode('zai_glm-5.3-flash'), false)
})

test('autoclaw cache strips DSH fields and owns its fallback constant', () => {
  const dirty = 'session 772f7f3a/foo'
  assert.equal(autoclawCacheSessionId(dirty), 'session-772f7f3a-foo')
  assert.equal(autoclawCacheSessionId(''), undefined)

  const overseas = applyAutoclawCache(AUTOCLAW_SITES.autoclaw, { session_id: 'sess-1', prompt_cache_retention: '24h', model: 'zai_auto' })
  assert.equal(overseas.cacheSessionId, 'sess-1')
  assert.equal(Object.hasOwn(overseas.payload, 'session_id'), false)
  assert.equal(Object.hasOwn(overseas.payload, 'prompt_cache_key'), false)
  assert.equal(Object.hasOwn(overseas.payload, 'prompt_cache_retention'), false)

  const fallback = applyAutoclawCache(AUTOCLAW_SITES['autoclaw-cn'], { model: 'zai_auto' })
  assert.equal(fallback.cacheSessionId, AUTOCLAW_CN_STABLE_SESSION)
  assert.equal(applyAutoclawCache(AUTOCLAW_SITES.autoclaw, {}).cacheSessionId, AUTOCLAW_STABLE_SESSION)
  assert.equal(AUTOCLAW_STABLE_SESSION, 'dsh-autoclaw')
  assert.equal(AUTOCLAW_CN_STABLE_SESSION, 'dsh-autoclaw-cn')
  assert.equal(isAutoclawFallback(AUTOCLAW_SITES.autoclaw, 'dsh-autoclaw'), true)
  assert.equal(isAutoclawFallback(AUTOCLAW_SITES['autoclaw-cn'], 'dsh-autoclaw'), false)
  assert.equal(isAutoclawFallback(AUTOCLAW_SITES.autoclaw, 'sess-1'), false)
})

test('classifyAutoclawFailure augments a 406 with the way out; other statuses pass through', () => {
  assert.equal(classifyAutoclawFailure(500, {}), undefined)
  assert.equal(classifyAutoclawFailure(401, {}), undefined)
  const guided = classifyAutoclawFailure(406, {})
  assert.ok(guided)
  assert.equal(guided.status, 406)
  assert.equal(guided.message, 'autoclaw upstream 406')
  assert.match(String(guided.payload?.error?.message ?? ''), /refuses chats whose system prompt carries another agent's identity/, 'the way out rides the payload the client sees')
  // The international engine path already appends the (byte-identical) hint
  // in its explained() 406 body — classify must not say it twice.
  const presaid = classifyAutoclawFailure(406, { error: { message: `blocked — ${AUTOCLAW_REFUSED_HINT}` } })
  assert.equal(
    String(presaid.payload?.error?.message ?? '').split(AUTOCLAW_REFUSED_HINT).length - 1,
    1,
    'the engine-pre-appended hint is not doubled',
  )
})

// ---- 引擎 hop ------------------------------------------------------------------

test('the engine hop signs with X-Authorization, rewrites the body and fails over hosts', { timeout: 20_000 }, async (t) => {
  const hops: any[] = []
  const fetchFn = async (url, init = {}) => {
    const target = String(url)
    if (target.endsWith('/chat/completions')) {
      hops.push({ url: target, init })
      if (target.startsWith('https://autoglm-api.autoglm.ai')) {
        return json({ error: { message: 'session refused' } }, 401)
      }
      return json({ id: 'chat', object: 'chat.completion', model: 'zai_auto', choices: [{ index: 0, message: { role: 'assistant', content: 'ok' }, finish_reason: 'stop' }] })
    }
    return json({ code: 0, msg: 'ok', data: {} })
  }
  const dataDir = await withEngine(t, fetchFn)
  const session = engineSession('autoclaw')
  await saveSession('autoclaw', session, join(dataDir, 'auth.json'))
  const proxy = createProxy({
    port: 0,
    apiKey: 'proxy-key-autoclaw-test-xx',
    tokens: { autoclaw: { session: async () => session } },
    fetchFn,
  })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const response = await fetch(`http://127.0.0.1:${port}/autoclaw/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer proxy-key-autoclaw-test-xx', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'zai_auto',
        max_tokens: 32000,
        messages: [
          { role: 'system', content: 'You are Claude Code.' },
          { role: 'user', content: 'hi' },
        ],
        prompt_cache_key: 'dsh-session-1',
      }),
    })
    assert.equal(response.status, 200, 'the refused home host fails over to the CN one')
    assert.equal(response.headers.get('x-magpie-sign-in'), null, "the engine's host-protocol mark never reaches a DSH client")
    assert.equal(hops.length, 2)
    assert.equal(hops[0].url, 'https://autoglm-api.autoglm.ai/autoclaw-proxy/proxy/autoclaw/v1/chat/completions')
    assert.equal(hops[1].url, 'https://autoglm-api.zhipuai.cn/autoclaw-proxy/proxy/autoclaw/v1/chat/completions')
    const headers = new Headers(hops[1].init.headers)
    assert.equal(headers.get('X-Authorization'), 'Bearer a1')
    assert.equal(headers.get('X-Request-Model'), 'zai_auto')
    assert.equal(headers.has('Authorization'), false)
    const sent = JSON.parse(String(hops[1].init.body))
    assert.equal(sent.max_tokens, undefined, 'the engine drops max_tokens')
    assert.equal(sent.prompt_cache_key, undefined)
    assert.ok(sent.messages[0].content.startsWith(AUTOCLAW_FIXTURE_SYSTEM_PROMPT))
    assert.equal(/You are Claude Code\./.test(sent.messages[0].content), false, 'the engine unflags the identity line')

    const models = await fetch(`http://127.0.0.1:${port}/autoclaw/v1/models`, {
      headers: { authorization: 'Bearer proxy-key-autoclaw-test-xx' },
    })
    const list = await models.json()
    assert.ok(list.data.some((row) => row.id === 'zai_auto' && row.owned_by === 'autoclaw'))

    const refused = await fetch(`http://127.0.0.1:${port}/autoclaw/v1/responses`, {
      method: 'POST',
      headers: { authorization: 'Bearer proxy-key-autoclaw-test-xx' },
      body: '{}',
    })
    assert.equal(refused.status, 501)
  } finally {
    await proxy.close()
  }
})

test('the engine CN hop rides the managed gateway with the 2.1.0 fingerprint', { timeout: 20_000 }, async (t) => {
  const hops: any[] = []
  const fetchFn = async (url, init = {}) => {
    const target = String(url)
    if (target.endsWith('/chat/completions')) {
      hops.push({ url: target, init })
      return json({ id: 'chat', object: 'chat.completion', model: 'zai_auto', choices: [{ index: 0, message: { role: 'assistant', content: 'ok' }, finish_reason: 'stop' }] })
    }
    return json({ code: 0, msg: 'ok', data: {} })
  }
  const dataDir = await withEngine(t, fetchFn)
  const session = engineSession('autoclaw-cn', { account: '13800138000' })
  await saveSession('autoclaw-cn', session, join(dataDir, 'auth.json'))
  const proxy = createProxy({
    port: 0,
    apiKey: 'proxy-key-autoclaw-test-xx',
    tokens: { 'autoclaw-cn': { session: async () => session } },
    fetchFn,
  })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const response = await fetch(`http://127.0.0.1:${port}/autoclaw-cn/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer proxy-key-autoclaw-test-xx', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'zai_auto', stream: false, messages: [{ role: 'user', content: 'hi' }] }),
    })
    assert.equal(response.status, 200)
    assert.equal(hops.length, 1)
    assert.equal(hops[0].url, 'https://autoglm-acceleration-api.zhipuai.cn/autoclaw-proxy/proxy/autoclaw/chat/completions')
    const headers = new Headers(hops[0].init.headers)
    assert.equal(headers.get('X-Agent-Id'), 'main')
    assert.equal(headers.get('X-Channel'), 'AutoClaw26')
    assert.equal(headers.get('X-Authorization'), 'Bearer a1')
    const sent = JSON.parse(String(hops[0].init.body))
    assert.ok(sent.messages[0].content.startsWith(AUTOCLAW_FIXTURE_SYSTEM_PROMPT))
  } finally {
    await proxy.close()
  }
})

// ---- 引擎额度 ------------------------------------------------------------------

test('the engine usage read maps the credits total and the named wallets, skipping the sign-in row', async (t) => {
  const urls: string[] = []
  const fetchFn = async (url) => {
    const target = String(url)
    urls.push(target)
    if (target.startsWith('https://autoglm-api.autoglm.ai')) {
      return new Response('gateway boom', { status: 500 })
    }
    if (target.includes('/wallets')) {
      return json({ code: 0, msg: 'ok', data: { total_balance: 300, wallets: [{ display_name: '体验金', balance: 100 }] } })
    }
    return json({ code: 0, msg: 'ok', data: {} })
  }
  await withEngine(t, fetchFn)
  const session = engineSession('autoclaw')
  const overseas = await fetchAutoclawQuotaEngine(session, fetchFn)
  assert.deepEqual(overseas.rows.map((row) => row.key), ['credits', 'wallet:体验金'])
  assert.equal(overseas.rows[0].kind, 'prepaid', 'balance 制走 prepaid 余额行（cline/opendesign 钱包同形），数字才能上卡')
  assert.equal(overseas.rows[0].remaining, 300)
  assert.equal(overseas.rows[0].usedPercent, undefined, 'balance 制：remaining 即余额，不发明 used')
  assert.equal(overseas.rows[1].kind, 'prepaid')
  assert.equal(overseas.rows[1].remaining, 100)
  assert.ok(urls.some((u) => u.includes('autoglm-api.zhipuai.cn')), 'the engine fails over to the CN host for the wallets read')

  const brokenFake = async () => new Response('nope', { status: 502 })
  configureEngineBridge({ fetchFn: brokenFake })
  await assert.rejects(
    () => fetchAutoclawQuotaEngine(session, brokenFake),
    /积分/,
  )
})

// ---- snapshot ------------------------------------------------------------------

test('controller snapshot shows quota on every autoclaw account', { timeout: 20_000 }, async (t) => {
  const fetchFn = async (url) => {
    if (String(url).includes('/wallets')) {
      return json({ code: 0, msg: 'ok', data: { total_balance: 4321, wallets: [] } })
    }
    return json({ code: 0, msg: 'ok', data: {} })
  }
  const dataDir = await withEngine(t, fetchFn)
  const authPath = join(dataDir, 'auth.json')
  await saveSession('autoclaw', engineSession('autoclaw', { accessToken: 'tok-a', refreshToken: 'ref-a', account: 'one@z.ai' }), authPath)
  await saveSession('autoclaw', engineSession('autoclaw', { accessToken: 'tok-b', refreshToken: 'ref-b', account: 'two@z.ai' }), authPath, { activate: false })
  const controller = new AuthController({ authPath, prefix: 'oauth', origin: () => 'http://127.0.0.1:8318', fetchFn })
  const snap = await controller.snapshot()
  const family = snap.accounts.autoclaw
  assert.equal(family.accounts.length, 2)
  for (const row of family.accounts) {
    assert.ok(row.quota)
    assert.equal(row.quota.status, 'ready', JSON.stringify(row.quota))
    assert.equal(row.quota.rows[0].kind, 'prepaid')
    assert.equal(row.quota.rows[0].remaining, 4321)
    assert.equal(JSON.stringify(row).includes('tok-'), false)
  }
})
