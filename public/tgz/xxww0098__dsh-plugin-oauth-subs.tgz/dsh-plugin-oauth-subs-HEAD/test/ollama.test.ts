import assert from 'node:assert/strict'
import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { AuthController } from '../lib/oauth/controller.js'
import { accountIdOf, listStoredSessions, publicSession, saveSession } from '../lib/oauth/store.js'
import {
  HARNESS_COMPLETIONS_API,
  buildProviders,
  catalogProviders,
  ownedProviderIds,
} from '../lib/oauth/models.js'
import { syncHarnessModels } from '../lib/oauth/harness-sync.js'
import {
  OLLAMA_BALANCE_URL,
  OLLAMA_CHAT_URL,
  OLLAMA_ME_URL,
  OLLAMA_MODELS,
  OLLAMA_REASONING,
  OLLAMA_SHOW_URL,
  OLLAMA_TAGS_URL,
  inferOllamaInput,
  isOllamaOpaqueAccount,
  isOllamaRetiredModel,
  ollamaContextWindow,
  ollamaDefaultAccount,
  ollamaInput,
  ollamaShowContextLength,
  ollamaShowInput,
  ollamaSnapshotContextWindow,
  ollamaSession,
  ollamaSourceLabel,
  parseOllamaApiKey,
  parseOllamaMe,
} from '../lib/apikey/ollama/index.js'
import { formatPlanLabel } from '../lib/oauth/plan.js'
import { QuotaStore } from '../lib/oauth/quota.js'
import { ollamaSessionResetAt, ollamaWeeklyResetAt, parseOllamaBalance } from '../lib/apikey/ollama/quota.js'
import {
  OLLAMA_IMPORT_EMPTY,
  importOllamaAuth,
  resolveOllamaLocalCredentials,
} from '../lib/apikey/ollama/import.js'
import {
  OLLAMA_CATALOG_TTL_MS,
  ollamaCatalogModels,
  refreshOllamaCatalog,
  resetOllamaCatalogCache,
  toOllamaPickerModels,
} from '../lib/apikey/ollama/catalog.js'
import { exerciseLiveCatalog } from './catalog-lifecycle.ts'
import {
  OLLAMA_STABLE_SESSION,
  applyOllamaCache,
  ollamaCacheHeaders,
  ollamaCacheSessionId,
  resetOllamaPins,
} from '../lib/apikey/ollama/cache.js'
import { createProxy } from '../lib/oauth/proxy.js'

function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })
}

test('parseOllamaApiKey rejects empty and registry public keys', () => {
  assert.equal(parseOllamaApiKey('  sk-ollama-test-key  '), 'sk-ollama-test-key')
  assert.throws(() => parseOllamaApiKey('short'), /empty/)
  assert.throws(() => parseOllamaApiKey('-----BEGIN PUBLIC KEY-----\nabc\n-----END PUBLIC KEY-----'), /registry public key/)
})

test('ollama session round-trip keeps source and never stores a plan slug', () => {
  const session = ollamaSession({ accessToken: 'sk-ollama-round-trip', source: 'paste' })
  assert.equal(session.source, 'paste')
  assert.equal(session.accessToken, 'sk-ollama-round-trip')
  assert.equal(session.refreshToken, 'sk-ollama-round-trip')
  assert.equal(session.account, ollamaDefaultAccount('sk-ollama-round-trip'))
  assert.equal(session.planType, undefined)
  const pub = publicSession('ollama', session)
  assert.equal(pub.account, session.account)
  assert.equal(pub.method, 'paste')
  assert.equal(pub.methodLabel, 'key')
  assert.equal(pub.planLabel, undefined)
  assert.equal(ollamaSourceLabel('env'), 'env')
  assert.notEqual(accountIdOf('ollama', session), accountIdOf('ollama', ollamaSession({
    accessToken: 'sk-ollama-other-key',
    source: 'env',
  })))
})

test('catalog is Completions at /ollama, not /ollama/v1', () => {
  const ids = ownedProviderIds('oauth')
  assert.equal(ids.includes('oauth-ollama'), true)
  const providers = buildProviders({
    prefix: 'oauth',
    origin: 'http://127.0.0.1:8318',
    loggedIn: { ollama: true },
  })
  const route = providers['oauth-ollama']
  assert.equal(route.api, HARNESS_COMPLETIONS_API)
  assert.equal(route.baseURL, 'http://127.0.0.1:8318/ollama')
  assert.equal(route.baseURL.endsWith('/ollama'), true)
  assert.equal(route.baseURL.endsWith('/ollama/v1'), false)
  for (const model of route.models) {
    const keys = Object.keys(model.reasoningEfforts ?? {})
    for (const key of keys) {
      assert.match(key, /^(off|minimal|low|medium|high|xhigh|max)$/)
    }
    assert.equal(Object.hasOwn(model.reasoningEfforts, 'none'), false)
  }
  assert.deepEqual(route.models.find((model) => model.id === 'gpt-oss:120b').reasoningEfforts, OLLAMA_REASONING)
  assert.equal(route.models.find((model) => model.id === 'gpt-oss:120b').reasoningEfforts.off, 'none')
  resetOllamaCatalogCache()
  const catalog = catalogProviders({ prefix: 'oauth', origin: 'http://x' })
  assert.equal(catalog['oauth-ollama'].models.length, 20)
  assert.equal(catalog['oauth-ollama'].models.length, OLLAMA_MODELS.length)
})

test('static OLLAMA_MODELS windows and input match the Cloud /api/show snapshot', () => {
  const snapshot = {
    beam: { window: 1_048_576, vision: false },
    'muse-spark-open': { window: 1_048_576, vision: true },
    'mistral-large-4': { window: 1_048_576, vision: true },
    'deepseek-v4-pro:0813': { window: 1_048_576, vision: false },
    'deepseek-v4.1-flash': { window: 1_048_576, vision: true },
    'gemma4:31b': { window: 262_144, vision: true },
    'glm-5.2': { window: 1_048_576, vision: false },
    'glm-5.3': { window: 1_048_576, vision: false },
    'glm-5.3-flash': { window: 1_048_576, vision: true },
    'gpt-oss:120b': { window: 131_072, vision: false },
    'gpt-oss:20b': { window: 131_072, vision: false },
    'kimi-k2.6': { window: 262_144, vision: true },
    'kimi-k2.7-code': { window: 262_144, vision: true },
    'kimi-k3': { window: 1_048_576, vision: true },
    'minimax-m2.7': { window: 196_608, vision: false },
    'minimax-m3': { window: 512_000, vision: true },
    'mistral-large-3:675b': { window: 262_144, vision: true },
    'nemotron-3-nano:30b': { window: 262_144, vision: false },
    'nemotron-3-super': { window: 262_144, vision: false },
    'nemotron-3-ultra': { window: 262_144, vision: false },
  }
  assert.equal(OLLAMA_MODELS.length, 20)
  assert.deepEqual(OLLAMA_MODELS.map((model) => model.id), Object.keys(snapshot))
  for (const model of OLLAMA_MODELS) {
    const row = snapshot[model.id]
    assert.equal(model.contextWindow, row.window)
    assert.equal(ollamaSnapshotContextWindow(model.id), row.window)
    assert.equal(ollamaContextWindow(model.id), row.window)
    assert.deepEqual(model.input, row.vision ? ['text', 'image'] : ['text'])
    assert.equal(model.input.includes('audio'), false)
    assert.equal(isOllamaRetiredModel(model.id), false)
  }
  assert.deepEqual(OLLAMA_MODELS.find((model) => model.id === 'glm-5.3-flash').input, ['text', 'image'])
  assert.deepEqual(OLLAMA_MODELS.find((model) => model.id === 'glm-5.3').input, ['text'])
  assert.deepEqual(OLLAMA_MODELS.find((model) => model.id === 'kimi-k3').input, ['text', 'image'])
  assert.deepEqual(OLLAMA_MODELS.find((model) => model.id === 'mistral-large-3:675b').input, ['text', 'image'])
  assert.deepEqual(OLLAMA_MODELS.find((model) => model.id === 'deepseek-v4.1-flash').input, ['text', 'image'])
  assert.deepEqual(OLLAMA_MODELS.find((model) => model.id === 'gpt-oss:120b').input, ['text'])
  assert.deepEqual(inferOllamaInput('gemma4:31b'), ['text', 'image'])
  assert.deepEqual(inferOllamaInput('glm-5.3-flash'), ['text'])
  assert.equal(ollamaShowContextLength({ model_info: { 'glm.context_length': 1_048_576 } }), 1_048_576)
  assert.equal(ollamaContextWindow('new-cloud-model'), 128_000)
})

test('ollamaShowInput reads capabilities; missing array falls back to name regex', () => {
  assert.deepEqual(ollamaShowInput({ capabilities: ['completion', 'vision'] }), ['text', 'image'])
  assert.deepEqual(ollamaShowInput({ capabilities: ['VISION'] }), ['text', 'image'])
  assert.deepEqual(ollamaShowInput({ capabilities: ['completion'] }), ['text'])
  assert.deepEqual(ollamaShowInput({ capabilities: ['completion', 'audio'] }), ['text'])
  assert.equal(ollamaShowInput({ details: {} }), undefined)
  assert.equal(ollamaShowInput(null), undefined)
  assert.deepEqual(ollamaInput('glm-5.3-flash', { capabilities: ['vision'] }), ['text', 'image'])
  assert.deepEqual(ollamaInput('glm-5.3-flash', { details: {} }), ['text'])
  assert.deepEqual(ollamaInput('gemma4:31b', { details: {} }), ['text', 'image'])
})

// Real 2026-10-10 probe of GET /api/balance on a Pro account: the legacy
// oneOf shape (session/weekly remaining_percent + resets_at), $0 purchased.
const LIVE_OLLAMA_BALANCE = {
  included: {
    session: { remaining_percent: 88.27, resets_at: '2026-10-10T16:00:00Z' },
    weekly: { remaining_percent: 60.37, resets_at: '2026-10-12T00:00:00Z' },
  },
  purchased: { balance_usd: 0 },
}

// Official docs response example for the credit-plan oneOf shape
// (docs.ollama.com/api/balance).
const LIVE_OLLAMA_BALANCE_CREDITS = {
  included: {
    balance_usd: 72.5,
    allowance_usd: 100,
    period: { from: '2026-09-15T09:30:00Z', until: '2026-10-15T09:30:00Z' },
  },
  purchased: { balance_usd: 25 },
}

const LIVE_OLLAMA_ME = {
  ID: 'user-1',
  Email: 'cloud@ollama.local',
  Name: 'Cloud User',
  Plan: 'pro',
}

async function ollamaCloudFetch(url, init) {
  const href = String(url)
  assert.equal(href.includes('127.0.0.1:11434'), false)
  assert.equal(href.includes('localhost:11434'), false)
  if (href === OLLAMA_BALANCE_URL) {
    assert.equal(init?.method ?? 'GET', 'GET')
    return json(LIVE_OLLAMA_BALANCE)
  }
  if (href === OLLAMA_ME_URL) {
    assert.equal(init?.method, 'POST')
    const auth = String(init?.headers?.authorization ?? '')
    const email = auth.includes('account-b') ? 'b@ollama.local' : 'a@ollama.local'
    return json({ ...LIVE_OLLAMA_ME, Email: email })
  }
  if (href === OLLAMA_TAGS_URL || href === OLLAMA_SHOW_URL) return json({ models: [] })
  throw new Error(`unexpected ${href}`)
}

test('parseOllamaBalance maps legacy remaining_percent rows and credit plans', () => {
  const now = Date.parse('2026-10-10T14:46:58Z')
  const parsed = parseOllamaBalance(LIVE_OLLAMA_BALANCE, LIVE_OLLAMA_ME, now)
  assert.equal(parsed.planType, 'pro')
  assert.equal(formatPlanLabel(parsed.planType, 'ollama'), 'Pro')
  assert.equal(parsed.account, 'cloud@ollama.local')
  assert.equal(parsed.rows.length, 2)
  assert.equal(parsed.rows[0].kind, 'primary')
  assert.equal(parsed.rows[0].usedPercent, 11.7)
  assert.equal(parsed.rows[0].remainingPercent, 88.3)
  assert.equal(parsed.rows[0].windowMinutes, 300)
  assert.equal(parsed.rows[0].resetAt, Date.parse('2026-10-10T16:00:00Z'))
  assert.equal(parsed.rows[1].kind, 'weekly')
  assert.equal(parsed.rows[1].usedPercent, 39.6)
  assert.equal(parsed.rows[1].remainingPercent, 60.4)
  assert.equal(parsed.rows[1].resetAt, Date.parse('2026-10-12T00:00:00Z'))
  // remaining_percent is REMAINING (75 = 75% left), never re-inverted twice
  assert.equal(parseOllamaBalance({ included: { session: { remaining_percent: 75 } } }).rows[0].remainingPercent, 75)
  // Credit plan: one USD meter, purchased credits as a separate prepaid row
  const credits = parseOllamaBalance(LIVE_OLLAMA_BALANCE_CREDITS, LIVE_OLLAMA_ME, now)
  assert.equal(credits.rows.length, 2)
  assert.equal(credits.rows[0].kind, 'primary')
  assert.equal(credits.rows[0].remainingPercent, 72.5)
  assert.equal(credits.rows[0].used, 27.5)
  assert.equal(credits.rows[0].total, 100)
  assert.equal(credits.rows[0].unit, 'usd')
  assert.equal(credits.rows[0].resetAt, Date.parse('2026-10-15T09:30:00Z'))
  assert.equal(credits.rows[1].kind, 'prepaid')
  assert.equal(credits.rows[1].unit, 'usd')
  assert.equal(credits.rows[1].remaining, 25)
  // $0 purchased adds no prepaid row; malformed balances add no rows
  const noPrepaid = parseOllamaBalance({ ...LIVE_OLLAMA_BALANCE, purchased: { balance_usd: 0 } })
  assert.equal(noPrepaid.rows.length, 2)
  const empty = parseOllamaBalance(undefined, undefined)
  assert.deepEqual(empty.rows, [])
  assert.equal(empty.planType, undefined)
  const meOnly = parseOllamaBalance({ included: {} }, { Name: 'Only Name', Plan: 'max' })
  assert.equal(meOnly.account, 'Only Name')
  assert.equal(meOnly.planType, 'max')
  assert.deepEqual(meOnly.rows, [])
  assert.equal(parseOllamaMe({ Email: 'a@b.c', Plan: 'pro' }).account, 'a@b.c')
  assert.equal(isOllamaOpaqueAccount('ollama-3f67f6bb'), true)
  assert.equal(isOllamaOpaqueAccount('cloud@ollama.local'), false)
})

test('balance resetAt prefers official resets_at; missing stamp falls back to #12532 buckets', () => {
  const now = Date.parse('2026-10-10T14:46:58Z')
  const stamped = parseOllamaBalance(LIVE_OLLAMA_BALANCE, LIVE_OLLAMA_ME, now)
  assert.equal(stamped.rows[0].resetAt, Date.parse('2026-10-10T16:00:00Z'))
  assert.equal(stamped.rows[1].resetAt, Date.parse('2026-10-12T00:00:00Z'))
  // 2026-10-10 is a Saturday: the official weekly stamp lands on Monday
  // 00:00 UTC — the same target the #12532 bucket math computes (and the
  // live session stamp is exactly the next UTC 5h bucket). Prove the stamp
  // wins with stamps that point elsewhere.
  const elsewhere = parseOllamaBalance({
    included: {
      session: { remaining_percent: 88, resets_at: '2099-01-01T00:00:00Z' },
      weekly: { remaining_percent: 60, reset_at: '2099-01-08T00:00:00Z' },
    },
  }, LIVE_OLLAMA_ME, now)
  assert.equal(elsewhere.rows[0].resetAt, Date.parse('2099-01-01T00:00:00Z'))
  assert.notEqual(elsewhere.rows[0].resetAt, ollamaSessionResetAt(now))
  assert.equal(elsewhere.rows[1].resetAt, Date.parse('2099-01-08T00:00:00Z'))
  const unstamped = parseOllamaBalance({
    included: {
      session: { remaining_percent: 88 },
      weekly: { remaining_percent: 60 },
    },
  }, LIVE_OLLAMA_ME, now)
  assert.equal(unstamped.rows[0].resetAt, ollamaSessionResetAt(now))
  assert.equal(unstamped.rows[1].resetAt, ollamaWeeklyResetAt(now))
  const nextReset = parseOllamaBalance({
    included: { session: { remaining_percent: 80, next_reset: 1_800_000_000 } },
  }, undefined, now)
  assert.equal(nextReset.rows[0].resetAt, 1_800_000_000_000)
})

test('#12532 bucket math: session next UTC 5h unix bucket, weekly next UTC 7d shifted -4d', () => {
  // ollama/ollama#12532: session remainder = 18000 - (epoch % 18000)
  assert.equal(ollamaSessionResetAt(0), 18_000_000)
  assert.equal(ollamaSessionResetAt(1), 18_000_000)
  assert.equal(ollamaSessionResetAt(17_999_999), 18_000_000)
  assert.equal(ollamaSessionResetAt(18_000_000), 36_000_000)
  const now = Date.parse('2026-10-10T14:46:58Z')
  assert.notEqual(ollamaSessionResetAt(now), now + 5 * 3600 * 1000)
  // weekly remainder = 604800 - ((epoch - 4d) % 604800); unix epoch Thu
  // + 4d = Mon 1970-01-05 00:00 UTC
  const monday = 4 * 86_400 * 1000
  const nextMonday = monday + 604_800 * 1000
  assert.equal(ollamaWeeklyResetAt(monday), nextMonday)
  assert.equal(ollamaWeeklyResetAt(monday + 1), nextMonday)
  assert.equal(ollamaWeeklyResetAt(nextMonday - 1), nextMonday)
  assert.equal(ollamaWeeklyResetAt(nextMonday), nextMonday + 604_800 * 1000)
  assert.equal(ollamaWeeklyResetAt(now), Date.parse('2026-10-12T00:00:00Z'))
  assert.notEqual(ollamaWeeklyResetAt(now), now + 7 * 24 * 3600 * 1000)
})

test('snapshot shows quota on every ollama account', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-ollama-'))
  const authPath = join(dir, 'auth.json')
  const sessionA = ollamaSession({ accessToken: 'sk-ollama-account-a', source: 'paste' })
  const sessionB = ollamaSession({ accessToken: 'sk-ollama-account-b', source: 'env' })
  await saveSession('ollama', sessionA, authPath)
  await saveSession('ollama', sessionB, authPath)
  const yaml = { providers: {} }
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    ollamaAutoImport: false,
    settings: {
      get: async (name) => name === 'llm-pi-ai' ? yaml : undefined,
      mutate: async (target, mutations) => {
        if (target !== 'llm-pi-ai') return
        for (const row of mutations) {
          const key = row.path?.[1]
          if (row.op === 'unset') delete yaml.providers[key]
          else if (row.op === 'set') yaml.providers[key] = row.value
        }
      },
    },
    fetchFn: ollamaCloudFetch,
  })
  const snap = await controller.snapshot()
  assert.equal(snap.accounts.ollama.loggedIn, true)
  assert.equal(snap.accounts.ollama.accounts.length, 2)
  assert.equal(snap.accounts.ollama.accounts.every((row) => row.quota?.status === 'ready'), true)
  for (const row of snap.accounts.ollama.accounts) {
    assert.equal(row.quota.planLabel, 'Pro')
    assert.equal(row.quota.rows[0].remainingPercent, 88.3)
    assert.equal(row.quota.rows[1].remainingPercent, 60.4)
    assert.equal(isOllamaOpaqueAccount(row.account), false)
    assert.match(row.account, /@ollama\.local$/)
  }
  assert.deepEqual(snap.accounts.ollama.accounts.map((row) => row.account).sort(), [
    'a@ollama.local',
    'b@ollama.local',
  ])
  assert.equal(snap.catalog.some((row) => row.provider === 'oauth-ollama'), true)
  assert.equal(snap.providers.some((row) => row.provider === 'oauth-ollama'), true)
  const synced = await controller.sync()
  assert.equal(yaml.providers['oauth-ollama'].api, HARNESS_COMPLETIONS_API)
  assert.equal(yaml.providers['oauth-ollama'].baseURL, 'http://127.0.0.1:8318/ollama')
  assert.deepEqual(synced.routes.find((row) => row.provider === 'oauth-ollama').models, yaml.providers['oauth-ollama'].models.map((model) => model.id))
})

test('OLLAMA_API_KEY import and empty-roster auto-import do not overwrite stored paste', async () => {
  assert.equal(await resolveOllamaLocalCredentials({ env: {} }), undefined)
  await assert.rejects(importOllamaAuth({ env: {} }), (error) => error.code === OLLAMA_IMPORT_EMPTY)
  const imported = await importOllamaAuth({ env: { OLLAMA_API_KEY: 'sk-ollama-from-env' } })
  assert.equal(imported.source, 'env')
  assert.equal(imported.session.accessToken, 'sk-ollama-from-env')

  const dir = await mkdtemp(join(tmpdir(), 'oauth-ollama-auto-'))
  const authPath = join(dir, 'auth.json')
  const previous = process.env.OLLAMA_API_KEY
  process.env.OLLAMA_API_KEY = 'sk-ollama-auto-env'
  try {
    const controller = new AuthController({
      authPath,
      prefix: 'oauth',
      origin: () => 'http://127.0.0.1:8318',
      settings: { mutate: async () => undefined },
      ollamaAutoImport: true,
      fetchFn: async () => json({ models: [] }),
    })
    const snap = await controller.snapshot()
    assert.equal(snap.accounts.ollama.loggedIn, true)
    assert.equal(snap.accounts.ollama.accounts[0].methodLabel, 'env')

    const paste = ollamaSession({ accessToken: 'sk-ollama-auto-env', source: 'paste' })
    await saveSession('ollama', paste, authPath)
    const result = await controller.importFrom('ollama')
    assert.equal(result.source, 'paste')
    const rows = await listStoredSessions('ollama', authPath)
    assert.equal(rows[0].session.source, 'paste')
  } finally {
    if (previous === undefined) delete process.env.OLLAMA_API_KEY
    else process.env.OLLAMA_API_KEY = previous
  }
})

test('live tags expand catalog; empty tags keep static fallback; retired stay out', async () => {
  resetOllamaCatalogCache()
  assert.equal(isOllamaRetiredModel('glm-4.7'), true)
  assert.equal(isOllamaRetiredModel('minimax-m2.5'), true)
  assert.equal(isOllamaRetiredModel('gpt-oss:120b'), false)
  const filtered = toOllamaPickerModels({
    models: [
      { name: 'glm-4.7' },
      { name: 'gpt-oss:120b' },
      { name: 'kimi-k2.6' },
    ],
  })
  assert.deepEqual(filtered.map((model) => model.id), ['gpt-oss:120b', 'kimi-k2.6'])
  assert.equal(filtered.find((model) => model.id === 'gpt-oss:120b').contextWindow, 131_072)
  assert.equal(filtered.find((model) => model.id === 'kimi-k2.6').contextWindow, 262_144)

  const session = ollamaSession({ accessToken: 'sk-ollama-tags', source: 'paste' })
  const live = await refreshOllamaCatalog(session, {
    fetchFn: async (url) => {
      if (String(url) === OLLAMA_SHOW_URL) return json({ details: {} })
      assert.equal(url, OLLAMA_TAGS_URL)
      return json({
        models: [
          { name: 'gpt-oss:120b' },
          { name: 'glm-5.3' },
          { name: 'new-cloud-model' },
          { name: 'glm-4.7' },
        ],
      })
    },
  })
  assert.equal(live.some((model) => model.id === 'new-cloud-model'), true)
  assert.equal(live.some((model) => model.id === 'glm-4.7'), false)
  assert.equal(live.find((model) => model.id === 'glm-5.3').contextWindow, 1_048_576)
  assert.notEqual(live.find((model) => model.id === 'glm-5.3').contextWindow, 128_000)
  assert.equal(ollamaCatalogModels().length, live.length)

  resetOllamaCatalogCache()
  const fallback = await refreshOllamaCatalog(session, {
    fetchFn: async () => json({ models: [] }),
  })
  assert.deepEqual(fallback.map((model) => model.id), OLLAMA_MODELS.map((model) => model.id))
})

test('live show capabilities override a wrong static/regex input row', async () => {
  resetOllamaCatalogCache()
  const session = ollamaSession({ accessToken: 'sk-ollama-show-input', source: 'paste' })
  assert.deepEqual(inferOllamaInput('glm-5.3-flash'), ['text'])
  const shown = await refreshOllamaCatalog(session, {
    fetchFn: async (url, init) => {
      if (String(url) === OLLAMA_SHOW_URL) {
        const model = JSON.parse(String(init.body ?? '{}')).model
        if (model === 'glm-5.3-flash') return json({ capabilities: ['completion', 'vision'] })
        if (model === 'glm-5.3') return json({ capabilities: ['completion'] })
        if (model === 'qwen3.5:397b') return json({ capabilities: ['vision'] })
        if (model === 'gemma4:31b') return json({ capabilities: ['completion'] })
        return json({ details: {} })
      }
      assert.equal(url, OLLAMA_TAGS_URL)
      return json({
        models: [
          { name: 'glm-5.3-flash' },
          { name: 'glm-5.3' },
          { name: 'gemma4:31b' },
          { name: 'qwen3.5:397b' },
        ],
      })
    },
  })
  assert.deepEqual(shown.find((model) => model.id === 'glm-5.3-flash').input, ['text', 'image'])
  assert.deepEqual(shown.find((model) => model.id === 'glm-5.3').input, ['text'])
  assert.deepEqual(shown.find((model) => model.id === 'gemma4:31b').input, ['text'])
  assert.deepEqual(shown.find((model) => model.id === 'qwen3.5:397b').input, ['text', 'image'])
})

test('live show model_info overrides snapshot; show-less tags keep snapshot not 128000', async () => {
  resetOllamaCatalogCache()
  const session = ollamaSession({ accessToken: 'sk-ollama-show', source: 'paste' })
  const shown = await refreshOllamaCatalog(session, {
    fetchFn: async (url, init) => {
      if (String(url) === OLLAMA_SHOW_URL) {
        const model = JSON.parse(String(init.body ?? '{}')).model
        if (model === 'glm-5.3') return json({ model_info: { 'glm.context_length': 999_999 } })
        return json({ model_info: {} })
      }
      assert.equal(url, OLLAMA_TAGS_URL)
      return json({ models: [{ name: 'glm-5.3' }, { name: 'gpt-oss:120b' }] })
    },
  })
  assert.equal(shown.find((model) => model.id === 'glm-5.3').contextWindow, 999_999)
  assert.equal(shown.find((model) => model.id === 'gpt-oss:120b').contextWindow, 131_072)

  resetOllamaCatalogCache()
  const noShow = await refreshOllamaCatalog(session, {
    fetchFn: async (url) => {
      if (String(url) === OLLAMA_SHOW_URL) return json({ details: {} })
      return json({ models: [{ name: 'glm-5.3' }] })
    },
  })
  assert.equal(noShow.find((model) => model.id === 'glm-5.3').contextWindow, 1_048_576)
  assert.notEqual(noShow.find((model) => model.id === 'glm-5.3').contextWindow, 128_000)

  const fromTags = toOllamaPickerModels({
    models: [{ name: 'glm-5.3', details: { context_length: 777_777 } }],
  })
  assert.equal(fromTags[0].contextWindow, 777_777)
})

test('a static-floor ceiling survives the Ollama tags projection', () => {
  const rows = toOllamaPickerModels(
    { models: [{ name: 'glm-5.3' }] },
    { floor: [{ id: 'glm-5.3', maxContextWindow: 2_000_000 }, { id: 'other' }] },
  )
  assert.equal(rows.find((model) => model.id === 'glm-5.3')?.maxContextWindow, 2_000_000)
})

test('useKey paste writes oauth-ollama and discovers tags', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-ollama-key-'))
  const authPath = join(dir, 'auth.json')
  const yaml = { providers: {} }
  resetOllamaCatalogCache()
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    ollamaAutoImport: false,
    ollamaDiscover: refreshOllamaCatalog,
    settings: {
      get: async (name) => name === 'llm-pi-ai' ? yaml : undefined,
      mutate: async (target, mutations) => {
        if (target !== 'llm-pi-ai') return
        for (const row of mutations) {
          const key = row.path?.[1]
          if (row.op === 'unset') delete yaml.providers[key]
          else if (row.op === 'set') yaml.providers[key] = row.value
        }
      },
    },
    fetchFn: async (url) => {
      if (String(url).includes('/api/me')) return json({ email: 'cloud@ollama.local' })
      return json({ models: [{ name: 'gpt-oss:120b' }, { name: 'live-only' }] })
    },
  })
  await controller.useKey('ollama', 'sk-ollama-paste-live')
  const snap = await controller.snapshot()
  assert.equal(snap.accounts.ollama.loggedIn, true)
  assert.equal(snap.accounts.ollama.account, 'cloud@ollama.local')
  assert.equal(snap.catalog.find((row) => row.provider === 'oauth-ollama').models.some((model) => model.id === 'live-only'), true)
  await controller.sync()
  // 登录默认: the paste alone (a sign-in while the plugin runs) leaves every
  // row off until the user picks one.
  assert.equal(yaml.providers['oauth-ollama'], undefined)
  await controller.setModels({ key: 'oauth-ollama/live-only', on: true })
  assert.equal(yaml.providers['oauth-ollama'].models.some((model) => model.id === 'live-only'), true)
})

test('proxy Completions hop is cloud /v1 with Bearer; no Codex/Grok headers', async () => {
  const seen = []
  const proxy = createProxy({
    port: 0,
    apiKey: 'secret-key',
    fetchFn: async (url, init) => {
      seen.push({ url: String(url), headers: init.headers, body: init.body?.toString() })
      return new Response('{"id":"chat","choices":[]}', { status: 200, headers: { 'content-type': 'application/json' } })
    },
    tokens: {
      ollama: {
        session: async () => ollamaSession({ accessToken: 'sk-ollama-proxy', source: 'paste' }),
      },
    },
  })
  const server = await proxy.listen()
  const { port } = server.address()
  try {
    const ok = await fetch(`http://127.0.0.1:${port}/ollama/v1/chat/completions`, {
      method: 'POST',
      headers: { authorization: 'Bearer secret-key', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'gpt-oss:120b',
        messages: [{ role: 'user', content: 'hi' }],
        prompt_cache_key: 'codex-style',
        session_id: 'sess-dsh',
      }),
    })
    assert.equal(ok.status, 200)
    assert.equal(seen[0].url, OLLAMA_CHAT_URL)
    assert.equal(seen[0].headers.authorization, 'Bearer sk-ollama-proxy')
    assert.equal(seen[0].headers['session-id'], undefined)
    assert.equal(seen[0].headers['x-client-request-id'], undefined)
    assert.equal(seen[0].headers['x-grok-conv-id'], undefined)
    const body = JSON.parse(seen[0].body)
    assert.equal(body.prompt_cache_key, undefined)
    assert.equal(body.session_id, undefined)
    assert.equal(body.model, 'gpt-oss:120b')

    const refused = await fetch(`http://127.0.0.1:${port}/ollama/v1/responses`, {
      method: 'POST',
      headers: { authorization: 'Bearer secret-key', 'content-type': 'application/json' },
      body: '{}',
    })
    assert.equal(refused.status, 501)
  } finally {
    await proxy.close()
  }
})

test('applyOllamaCache strips Codex/Grok fields and does not invent a wire id', () => {
  resetOllamaPins()
  assert.equal(ollamaCacheSessionId('session 772f7f3a/foo'), 'session-772f7f3a-foo')
  const { payload, cacheSessionId } = applyOllamaCache({
    model: 'gpt-oss:120b',
    session_id: 'sess-ollama',
    prompt_cache_key: 'codex-style',
    prompt_cache_retention: '24h',
    messages: [{ role: 'user', content: 'hi' }],
  })
  assert.equal(cacheSessionId, 'sess-ollama')
  assert.equal(payload.prompt_cache_key, undefined)
  assert.equal(payload.prompt_cache_retention, undefined)
  assert.equal(payload.session_id, undefined)
  assert.deepEqual(ollamaCacheHeaders(), {})
  assert.equal(Object.hasOwn(ollamaCacheHeaders(), 'session-id'), false)
  assert.equal(Object.hasOwn(ollamaCacheHeaders(), 'x-grok-conv-id'), false)
  const again = applyOllamaCache({ model: 'gpt-oss:120b', session_id: 'sess-ollama' })
  assert.equal(again.cacheSessionId, cacheSessionId)
  assert.equal(applyOllamaCache({ model: 'gpt-oss:120b' }).cacheSessionId, OLLAMA_STABLE_SESSION)
  assert.equal(/^-\d+$/.test(applyOllamaCache({}).cacheSessionId), false)
})

test('refreshQuota persists Email and replaceAccountId on ollama-hex vault id', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'oauth-ollama-id-'))
  const authPath = join(dir, 'auth.json')
  const session = ollamaSession({ accessToken: 'sk-ollama-opaque-key', source: 'paste' })
  assert.equal(isOllamaOpaqueAccount(session.account), true)
  await saveSession('ollama', session, authPath)
  const before = await listStoredSessions('ollama', authPath)
  assert.equal(before[0].id, session.account)
  const controller = new AuthController({
    authPath,
    prefix: 'oauth',
    origin: () => 'http://127.0.0.1:8318',
    ollamaAutoImport: false,
    fetchFn: async (url, init) => {
      if (String(url) === OLLAMA_BALANCE_URL) return json(LIVE_OLLAMA_BALANCE)
      if (String(url) === OLLAMA_ME_URL) return json(LIVE_OLLAMA_ME)
      if (String(url).includes('11434')) throw new Error('localhost daemon is not this family')
      return json({ models: [] })
    },
  })
  const quota = await controller.refreshQuota('ollama')
  assert.equal(quota.status, 'ready')
  assert.equal(quota.planLabel, 'Pro')
  assert.equal(quota.rows[0].remainingPercent, 88.3)
  assert.equal(quota.rows[1].remainingPercent, 60.4)
  const rows = await listStoredSessions('ollama', authPath)
  assert.equal(rows.length, 1)
  assert.equal(rows[0].id, 'cloud@ollama.local')
  assert.equal(rows[0].session.account, 'cloud@ollama.local')
  assert.equal(rows[0].session.planType, 'pro')
  const snap = await controller.snapshot()
  assert.equal(snap.accounts.ollama.account, 'cloud@ollama.local')
  assert.equal(snap.accounts.ollama.accounts[0].planLabel, 'Pro')
})

test('QuotaStore ollama fetches balance+me; missing balance does not crash; no session stays idle', async () => {
  const session = ollamaSession({ accessToken: 'sk-ollama-quota-store', source: 'paste' })
  const seen = []
  const store = new QuotaStore({
    fetchFn: async (url, init) => {
      const href = String(url)
      seen.push({ href, method: init?.method ?? 'GET' })
      assert.equal(href.includes('11434'), false)
      if (href === OLLAMA_BALANCE_URL) return json(LIVE_OLLAMA_BALANCE)
      if (href === OLLAMA_ME_URL) {
        assert.equal(init?.method, 'POST')
        return json(LIVE_OLLAMA_ME)
      }
      throw new Error(`unexpected ${href}`)
    },
    tokens: { ollama: { session: async () => session } },
  })
  const quota = await store.refresh('ollama')
  assert.equal(quota.status, 'ready')
  assert.notEqual(quota.status, 'idle')
  assert.equal(quota.planLabel, 'Pro')
  assert.equal(quota.account, 'cloud@ollama.local')
  assert.equal(quota.rows[0].remainingPercent, 88.3)
  assert.equal(quota.rows[1].remainingPercent, 60.4)
  assert.equal(seen.some((row) => row.href === OLLAMA_BALANCE_URL && row.method === 'GET'), true)
  assert.equal(seen.some((row) => row.href === OLLAMA_ME_URL && row.method === 'POST'), true)

  const meOnly = new QuotaStore({
    fetchFn: async (url) => {
      if (String(url) === OLLAMA_BALANCE_URL) return new Response('nope', { status: 500 })
      if (String(url) === OLLAMA_ME_URL) return json({ Plan: 'pro', Email: 'cloud@ollama.local' })
      throw new Error(`unexpected ${url}`)
    },
    tokens: { ollama: { session: async () => session } },
  })
  const partial = await meOnly.refresh('ollama')
  assert.equal(partial.status, 'ready')
  assert.equal(partial.planLabel, 'Pro')
  assert.deepEqual(partial.rows, [])

  let hits = 0
  const idle = new QuotaStore({
    fetchFn: async () => {
      hits += 1
      throw new Error('network should stay quiet')
    },
  })
  const empty = await idle.refresh('ollama')
  assert.equal(empty.status, 'idle')
  assert.equal(hits, 0)
})

test('ollama catalog refresh coalesces one tags+show pass per credential', async () => {
  const http = { n: 0 }
  await exerciseLiveCatalog({
    label: 'ollama',
    ttlMs: OLLAMA_CATALOG_TTL_MS,
    dropStaticId: OLLAMA_MODELS[0].id,
    httpPerRefresh: 2,
    httpCount: () => http.n,
    reset: resetOllamaCatalogCache,
    models: ollamaCatalogModels,
    refresh: ({ token, now, ttlMs, fetch }) => {
      let pending
      return refreshOllamaCatalog({ accessToken: token }, {
        now,
        ttlMs,
        fetchFn: async (url) => {
          http.n += 1
          if (String(url) === OLLAMA_SHOW_URL) return { ok: true, json: async () => ({}) }
          pending ??= fetch()
          const kind = await pending
          if (kind === 'fail') return { ok: false, json: async () => ({}) }
          if (kind === 'empty') return { ok: true, json: async () => ({ models: [] }) }
          return { ok: true, json: async () => ({ models: [{ name: kind === 'a' ? 'live-only-a' : 'live-only-b' }] }) }
        },
      })
    },
  })
})
