﻿# Domain Docs

How the engineering skills should consume this repo's domain documentation when exploring the codebase.

## Before exploring, read these

- **`CONTEXT.md`** at the repo root, or
- **`CONTEXT-MAP.md`** at the repo root if it exists 鈥?it points at one `CONTEXT.md` per context. Read each one relevant to the topic.
- **`docs/adr/`** 鈥?read ADRs that touch the area you're about to work in. In multi-context repos, also check `src/<context>/docs/adr/` for context-scoped decisions.

If any of these files don't exist, **proceed silently**. Don't flag their absence; don't suggest creating them upfront. The `/domain-modeling` skill (reached via `/grill-with-docs` and `/improve-codebase-architecture`) creates them lazily when terms or decisions actually get resolved.

## File structure

Single-context repo (most repos):

```
/
鈹溾攢鈹€ CONTEXT.md
鈹溾攢鈹€ docs/adr/
鈹?  鈹溾攢鈹€ 0001-event-sourced-orders.md
鈹?  鈹斺攢鈹€ 0002-postgres-for-write-model.md
鈹斺攢鈹€ src/
```

Multi-context repo (presence of `CONTEXT-MAP.md` at the root):

```
/
鈹溾攢鈹€ CONTEXT-MAP.md
鈹溾攢鈹€ docs/adr/                          鈫?system-wide decisions
鈹斺攢鈹€ src/
    鈹溾攢鈹€ ordering/
    鈹?  鈹溾攢鈹€ CONTEXT.md
    鈹?  鈹斺攢鈹€ docs/adr/                  鈫?context-specific decisions
    鈹斺攢鈹€ billing/
        鈹溾攢鈹€ CONTEXT.md
        鈹斺攢鈹€ docs/adr/
```

## Use the glossary's vocabulary

When your output names a domain concept (in an issue title, a refactor proposal, a hypothesis, a test name), use the term as defined in `CONTEXT.md`. Don't drift to synonyms the glossary explicitly avoids.

If the concept you need isn't in the glossary yet, that's a signal 鈥?either you're inventing language the project doesn't use (reconsider) or there's a real gap (note it for `/domain-modeling`).

## Flag ADR conflicts

If your output contradicts an existing ADR, surface it explicitly rather than silently overriding:

> _Contradicts ADR-0007 (event-sourced orders) 鈥?but worth reopening because鈥

