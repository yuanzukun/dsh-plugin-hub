// Acquisition of the Roslyn language server, the Unity analyzers and the .NET
// runtime that hosts them.
//
// Mirrors `Locus/src-tauri/src/csharp_lsp/assets.rs` and `dotnet_runtime.rs`.
// The one deliberate difference is the Unix archives: upstream only wires up
// Windows ZIPs because its downloader assumed zip; this plugin targets
// Linux/macOS first (the broker port is Unix-only), so
// `dotnet-runtime-<v>-<rid>.tar.gz` is handled by `archive.js`.
//
// Like upstream (`assets::ensure_assets`, called from the language server's
// start path), the download happens on the first query that needs it, and is
// cached: the files are written once into the plugin home and every later
// server start reuses them.
//
// The server and analyzers are pinned to the versions upstream ships so a
// workspace behaves the same in both clients.

import { execFile } from 'node:child_process'
import { createHash } from 'node:crypto'
import { createReadStream, createWriteStream, existsSync, mkdirSync, readdirSync, renameSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'
import { promisify } from 'node:util'

import { extractArchiveFile } from './archive.js'

const execFileAsync = promisify(execFile)

/** Roslyn language server build, matching `assets.rs::SERVER_VERSION`. */
export const SERVER_VERSION = '5.4.0-2.26179.14'
/** Microsoft.Unity.Analyzers, matching `assets.rs::UNITY_ANALYZERS_VERSION`. */
export const UNITY_ANALYZERS_VERSION = '1.26.0'
/** Runtime line both managed sidecars target (`dotnet_runtime.rs`). */
export const DOTNET_RUNTIME_VERSION = '10.0.9'
const DOTNET_RUNTIME_MAJOR = '10.0.0'

const COMPLETE_MARKER = '.locus-complete'
/**
 * A transfer that delivers no bytes for this long is treated as dead.
 *
 * Upstream sets no timeout at all and relies on a GUI progress indicator to
 * make a hang visible; a tool call has no such channel, so a stalled socket has
 * to fail on its own.
 */
export const DOWNLOAD_IDLE_TIMEOUT_MS = 30 * 1000
/** Hard ceiling on one transfer, so a trickling server cannot hold the call open. */
export const DOWNLOAD_TIMEOUT_MS = 60 * 60 * 1000

/** An asset could not be downloaded or unpacked. */
export class AssetError extends Error {
  constructor(message, { code = null, hint = null } = {}) {
    super(message)
    this.name = 'AssetError'
    this.code = code
    this.hint = hint
  }
}

/** Runtime identifier for a host, or `null` when the platform is unsupported. */
export function platformRid(platform = process.platform, arch = process.arch) {
  if (platform === 'win32') return arch === 'arm64' ? 'win-arm64' : 'win-x64'
  if (platform === 'darwin') return arch === 'arm64' ? 'osx-arm64' : 'osx-x64'
  if (platform === 'linux') return arch === 'arm64' ? 'linux-arm64' : 'linux-x64'
  return null
}

export function isPlatformSupported(platform = process.platform, arch = process.arch) {
  return platformRid(platform, arch) !== null
}

/**
 * Root that holds every downloaded asset.
 *
 * `DSH_LOCUS_CSHARP_HOME` overrides it so tests and air-gapped deployments can
 * pre-seed the tree; otherwise it sits beside the other Locus caches under the
 * user's data directory, matching the desktop layout (`csharp-lsp/`).
 */
export function assetsRoot(env = process.env) {
  if (env.DSH_LOCUS_CSHARP_HOME) return env.DSH_LOCUS_CSHARP_HOME
  const base =
    process.platform === 'win32'
      ? env.APPDATA || join(homedir(), 'AppData', 'Roaming')
      : process.platform === 'darwin'
        ? join(homedir(), 'Library', 'Application Support')
        : env.XDG_DATA_HOME || join(homedir(), '.local', 'share')
  return join(base, 'locus', 'csharp-lsp')
}

function markerPath(dir) {
  return join(dir, COMPLETE_MARKER)
}

function isComplete(dir) {
  return existsSync(markerPath(dir))
}

function markComplete(dir) {
  mkdirSync(dir, { recursive: true })
  writeFileSync(markerPath(dir), `${new Date().toISOString()}\n`)
}

export function serverDir(env = process.env, rid = platformRid()) {
  return join(assetsRoot(env), 'server', SERVER_VERSION, rid)
}

export function serverDllPath(env = process.env, rid = platformRid()) {
  return join(serverDir(env, rid), 'Microsoft.CodeAnalysis.LanguageServer.dll')
}

export function unityAnalyzersDir(env = process.env) {
  return join(assetsRoot(env), 'unity-analyzers', UNITY_ANALYZERS_VERSION)
}

export function dotnetDir(env = process.env, rid = platformRid()) {
  return join(assetsRoot(env), 'dotnet', DOTNET_RUNTIME_VERSION, rid)
}

function serverDownloadUrl(rid) {
  const id = `microsoft.codeanalysis.languageserver.${rid}`
  const version = SERVER_VERSION.toLowerCase()
  return (
    'https://pkgs.dev.azure.com/azure-public/vside/_packaging/vs-impl/nuget/v3/flat2/' +
    `${id}/${version}/${id}.${version}.nupkg`
  )
}

function analyzersDownloadUrl() {
  return (
    'https://api.nuget.org/v3-flatcontainer/microsoft.unity.analyzers/' +
    `${UNITY_ANALYZERS_VERSION}/microsoft.unity.analyzers.${UNITY_ANALYZERS_VERSION}.nupkg`
  )
}

function runtimeDownloadUrl(rid) {
  const base = `https://builds.dotnet.microsoft.com/dotnet/Runtime/${DOTNET_RUNTIME_VERSION}`
  if (rid.startsWith('win-')) return `${base}/dotnet-runtime-${DOTNET_RUNTIME_VERSION}-${rid}.zip`
  return `${base}/dotnet-runtime-${DOTNET_RUNTIME_VERSION}-${rid}.tar.gz`
}

/**
 * Download one URL to `target`, atomically.
 *
 * A partial file is never left behind under the final name: the body lands in
 * `<target>.part` and is renamed only after the stream ends cleanly.
 *
 * Two clocks bound the transfer, because one never fits both failure modes:
 *
 *   * `idleTimeoutMs` — how long a stalled socket may go without delivering a
 *     chunk. This is what actually detects a hung connection; a flat deadline
 *     would instead punish a slow but steady link.
 *   * `totalTimeoutMs` — a hard ceiling on the whole transfer, so a server that
 *     trickles one byte every few seconds cannot hold the call forever.
 *
 * Each component overwrites `<target>.part` in place rather than buffering the
 * body, so a 60 MB package does not also become 60 MB of heap.
 */
export async function downloadToFile(
  url,
  target,
  {
    fetchImpl = fetch,
    onProgress = null,
    idleTimeoutMs = DOWNLOAD_IDLE_TIMEOUT_MS,
    totalTimeoutMs = DOWNLOAD_TIMEOUT_MS,
  } = {},
) {
  mkdirSync(dirname(target), { recursive: true })
  const partial = `${target}.part`
  const controller = new AbortController()
  let abortReason = null
  let idleTimer = null
  // An abort cancels a real fetch body, but the body cannot always be relied on
  // to notice: a stalled transport may sit inside a pending read for as long as
  // it takes to unwind. Racing each read against a promise the clock settles
  // makes the failure immediate and keeps the timer the authority on when a
  // transfer is dead, rather than whatever the transport does next.
  let failOnAbort = null
  const aborted = new Promise((_resolve, reject) => {
    failOnAbort = reject
  })
  aborted.catch(() => {})
  const abortWith = (message) => {
    abortReason = new AssetError(message, { code: 'download_failed' })
    controller.abort(abortReason)
    // Settles the read that is currently blocked on a dead transport.
    failOnAbort?.(abortReason)
  }
  const armIdle = () => {
    clearTimeout(idleTimer)
    if (idleTimeoutMs > 0) idleTimer = setTimeout(() => abortWith(`no data from ${url} for ${idleTimeoutMs} ms`), idleTimeoutMs)
  }
  const totalTimer = totalTimeoutMs > 0 ? setTimeout(() => abortWith(`download of ${url} exceeded ${totalTimeoutMs} ms`), totalTimeoutMs) : null
  const stopTimers = () => {
    clearTimeout(idleTimer)
    clearTimeout(totalTimer)
    idleTimer = null
    failOnAbort = null
  }

  // The abort reason travels on the stream error, which keeps the message
  // "download failed" rather than the AbortError Node raises by default.
  const describe = (error) => (abortReason !== null ? abortReason.message : error.message)

  armIdle()
  let response
  try {
    response = await fetchImpl(url, { signal: controller.signal, redirect: 'follow' })
  } catch (error) {
    stopTimers()
    throw new AssetError(`cannot reach ${url}: ${describe(error)}`, { code: 'download_failed' })
  }
  if (!response.ok) {
    stopTimers()
    throw new AssetError(`${url} answered HTTP ${response.status}`, { code: 'download_failed' })
  }
  const total = Number(response.headers.get('content-length') ?? 0) || null
  let received = 0
  const sink = createWriteStream(partial)
  try {
    const body = response.body[Symbol.asyncIterator]()
    for (;;) {
      const step = await Promise.race([body.next(), aborted])
      // Re-armed after the read settles: a slow arrival is progress, and only a
      // gap between two chunks may trip the idle clock.
      armIdle()
      if (step.done) break
      const chunk = step.value
      if (!sink.write(chunk)) await new Promise((resolve, reject) => {
        sink.once('drain', resolve)
        sink.once('error', reject)
      })
      received += chunk.length
      onProgress?.({ received, total })
    }
  } catch (error) {
    stopTimers()
    sink.destroy()
    await new Promise((resolve) => sink.once('close', resolve))
    rmSync(partial, { force: true })
    throw new AssetError(`download interrupted after ${received} bytes: ${describe(error)}`, { code: 'download_failed' })
  }
  stopTimers()
  await new Promise((resolve, reject) => {
    sink.once('error', reject)
    sink.end(resolve)
  })
  if (total !== null && received !== total) {
    rmSync(partial, { force: true })
    throw new AssetError(`download truncated: ${received} of ${total} bytes`, { code: 'download_failed' })
  }
  renameSync(partial, target)
  const sha256 = await new Promise((resolve, reject) => {
    const hash = createHash('sha256')
    createReadStream(target)
      .on('data', (chunk) => hash.update(chunk))
      .on('error', reject)
      .on('end', () => resolve(hash.digest('hex')))
  })
  return { bytes: received, sha256 }
}

async function ensureServer(env, rid, options) {
  const dir = serverDir(env, rid)
  const dll = serverDllPath(env, rid)
  if (isComplete(dir) && existsSync(dll)) return dll
  rmSync(dir, { recursive: true, force: true })
  mkdirSync(dir, { recursive: true })
  const archive = join(dir, 'server.nupkg')
  await downloadToFile(serverDownloadUrl(rid), archive, options)
  const prefix = `content/LanguageServer/${rid}/`
  await extractArchiveFile(archive, dir, { prefix })
  rmSync(archive, { force: true })
  if (!existsSync(dll)) {
    throw new AssetError(
      `the language server archive did not contain Microsoft.CodeAnalysis.LanguageServer.dll`,
      { code: 'asset_corrupt' },
    )
  }
  markComplete(dir)
  return dll
}

async function ensureAnalyzers(env, options) {
  const dir = unityAnalyzersDir(env)
  if (isComplete(dir)) return dir
  rmSync(dir, { recursive: true, force: true })
  mkdirSync(dir, { recursive: true })
  const archive = join(dir, 'analyzers.nupkg')
  await downloadToFile(analyzersDownloadUrl(), archive, options)
  const staging = join(dir, 'staging')
  await extractArchiveFile(archive, staging, {
    filter: (name) => name.startsWith('analyzers/dotnet/cs/') && name.endsWith('.dll'),
  })
  // Flatten to `dir/*.dll`: the server takes a directory of analyzer assemblies.
  const flat = join(staging, 'analyzers', 'dotnet', 'cs')
  if (existsSync(flat)) {
    for (const entry of readdirSync(flat)) {
      if (entry.endsWith('.dll')) renameSync(join(flat, entry), join(dir, entry))
    }
  }
  rmSync(staging, { recursive: true, force: true })
  rmSync(archive, { force: true })
  markComplete(dir)
  return dir
}

/**
 * The managed runtime that hosts the server.
 *
 * A system `dotnet` with a compatible major version is preferred — it avoids a
 * ~30 MB download and is what a developer machine already has. Otherwise the
 * official runtime archive is fetched into the asset root.
 */
export async function resolveDotnet(env = process.env, { rid = platformRid(), options = {} } = {}) {
  const executable = process.platform === 'win32' ? 'dotnet.exe' : 'dotnet'
  try {
    const { stdout } = await execFileAsync(executable, ['--list-runtimes'], { timeout: 15_000 })
    // The server's runtimeconfig asks for 10.0.0 with `rollForward: Major`, so
    // any 10.x runtime satisfies it — pinning the exact patch version here made
    // a machine with 10.0.14 download a redundant 30 MB runtime.
    const major = DOTNET_RUNTIME_MAJOR.split('.')[0]
    const hasRuntime = String(stdout)
      .split(/\r?\n/)
      .some((line) => new RegExp(`^Microsoft\\.NETCore\\.App ${major}\\.`).test(line.trim()))
    if (hasRuntime) {
      const { stdout: host } = await execFileAsync(executable, ['--info'], { timeout: 15_000 })
      return { program: executable, source: 'system', info: String(host).split(/\r?\n/)[0] ?? '' }
    }
  } catch {
    // Fall through to the managed runtime.
  }

  const dir = dotnetDir(env, rid)
  const suffix = process.platform === 'win32' ? 'dotnet.exe' : 'dotnet'
  const program = join(dir, suffix)
  if (isComplete(dir) && existsSync(program)) return { program, source: 'managed', info: '' }

  rmSync(dir, { recursive: true, force: true })
  mkdirSync(dir, { recursive: true })
  const archiveName = runtimeDownloadUrl(rid).split('/').pop()
  const archive = join(dir, archiveName)
  await downloadToFile(runtimeDownloadUrl(rid), archive, options)
  await extractArchiveFile(archive, dir, {})
  rmSync(archive, { force: true })
  if (!existsSync(program)) {
    throw new AssetError(`the .NET runtime archive did not contain ${suffix}`, { code: 'asset_corrupt' })
  }
  markComplete(dir)
  return { program, source: 'managed', info: '' }
}

/**
 * What is on disk right now, without downloading anything.
 *
 * `ready` means a query can run. `missing` lists the components the next query
 * would fetch.
 */
export function assetStatus(env = process.env, { rid = platformRid() } = {}) {
  const server = existsSync(serverDllPath(env, rid)) && isComplete(serverDir(env, rid))
  const analyzers = existsSync(unityAnalyzersDir(env)) && isComplete(unityAnalyzersDir(env))
  const runtime = existsSync(join(dotnetDir(env, rid), process.platform === 'win32' ? 'dotnet.exe' : 'dotnet'))
  const missing = []
  if (!server) missing.push('server')
  if (!analyzers) missing.push('analyzers')
  if (!runtime) missing.push('runtime')
  return {
    rid,
    supported: rid !== null,
    root: assetsRoot(env),
    server: { ready: server, version: SERVER_VERSION, path: server ? serverDllPath(env, rid) : null },
    analyzers: { ready: analyzers, version: UNITY_ANALYZERS_VERSION, path: analyzers ? unityAnalyzersDir(env) : null },
    runtime: { ready: runtime, version: DOTNET_RUNTIME_VERSION, path: runtime ? dotnetDir(env, rid) : null },
    missing,
    // A system dotnet satisfies the runtime requirement without a download.
    installBytes: estimateInstallBytes(missing),
  }
}

function estimateInstallBytes(missing) {
  const sizes = { server: 60 * 1024 * 1024, analyzers: 2 * 1024 * 1024, runtime: 30 * 1024 * 1024 }
  return missing.reduce((total, part) => total + (sizes[part] ?? 0), 0)
}

/**
 * Download every missing component. Resolves to the same report as
 * `assetStatus()` with `ready: true`. The language server's start path calls
 * this, so a query fetches what it needs instead of failing on a cold machine.
 */
export async function installAssets(env = process.env, { rid = platformRid(), fetchImpl = fetch, onProgress = null, options = {} } = {}) {
  if (!rid) {
    throw new AssetError(`unsupported platform ${process.platform}/${process.arch}`, { code: 'unsupported_platform' })
  }
  // One install at a time across every workspace. Each component deletes its
  // target directory before downloading, so two workspaces opening at once
  // would otherwise remove each other's half-written tree; upstream guards the
  // same sequence with a global `INSTALL_LOCK`.
  const key = installLockKey(env, rid)
  const previous = installs.get(key) ?? Promise.resolve()
  const current = previous.then(() => installComponents(env, rid, { fetchImpl, onProgress, options }))
  const settled = current.catch(() => {})
  installs.set(key, settled)
  try {
    return await current
  } finally {
    if (installs.get(key) === settled) installs.delete(key)
  }
}

/** In-flight installs, keyed by asset root + runtime identifier. */
const installs = new Map()

function installLockKey(env, rid) {
  return `${assetsRoot(env)}\u0000${rid}`
}

async function installComponents(env, rid, { fetchImpl, onProgress, options }) {
  const shared = { fetchImpl, onProgress, ...options }
  await ensureServer(env, rid, shared)
  await ensureAnalyzers(env, shared)
  // Only a machine without a usable system .NET 10 pays for the managed copy.
  await resolveDotnet(env, { rid, options: shared })
  const status = assetStatus(env, { rid })
  const missing = status.missing.filter((part) => part !== 'runtime')
  return { ...status, missing, ready: missing.length === 0 }
}

/** Resolve everything a query needs; throws when an asset is missing. */
export async function requireAssets(env = process.env, { rid = platformRid() } = {}) {
  const status = assetStatus(env, { rid })
  // `assetStatus()` counts the runtime as missing whenever the managed copy is
  // absent, but a system `dotnet` with a 10.x runtime satisfies it — that is the
  // common developer-machine case and the whole point of `resolveDotnet`. Only
  // the two downloaded artifacts gate here; the runtime is resolved below.
  const required = status.missing.filter((part) => part !== 'runtime')
  if (required.length > 0) {
    throw new AssetError(
      `C# analysis assets could not be installed (missing: ${required.join(', ')}). ` +
        'Check the network connection, or install them by hand under the plugin home.',
      { code: 'assets_missing' },
    )
  }
  const dotnet = await resolveDotnet(env, { rid })
  return {
    rid,
    program: dotnet.program,
    dotnetSource: dotnet.source,
    serverDll: serverDllPath(env, rid),
    analyzersDir: unityAnalyzersDir(env),
  }
}

/** Total size of a directory tree, for the status report. */
export function directorySize(dir) {
  if (!existsSync(dir)) return 0
  let total = 0
  const walk = (current) => {
    let entries
    try {
      entries = readdirSync(current, { withFileTypes: true })
    } catch {
      return
    }
    for (const entry of entries) {
      const path = join(current, entry.name)
      if (entry.isDirectory()) walk(path)
      else if (entry.isFile()) {
        try {
          total += statSync(path).size
        } catch {
          // A file removed mid-walk is not worth failing the report over.
        }
      }
    }
  }
  walk(dir)
  return total
}