// Host loader entry for the browser-only whale plugin.
// Provides no host-side behavior; the real logic lives in client.js.
export const name = 'dsh-whale-pet'
export function apply() {}
