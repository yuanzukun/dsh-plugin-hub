// dsh-whale-pet client bundle (browser half).
// Hand-built to the same shape the tsdown bundles produce:
//   window.__ModuleLoader__.load({ id, factory })
// The factory receives a `require` for module resolution inside the client.
window.__ModuleLoader__.load({
  id: 'dsh-whale-pet',
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
    let React = require('react');

    const name = 'dsh-whale-pet';
    const inject = ['timer'];

    const CSS = `
      .dsh-whale-anchor {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 60;
        pointer-events: none;
      }
      .dsh-whale-body {
        position: absolute;
        top: 0;
        left: 0;
        pointer-events: auto;
        cursor: grab;
        user-select: none;
        -webkit-user-select: none;
        -webkit-tap-highlight-color: transparent;
        touch-action: none;
      }
      .dsh-whale-body.dsh-grabbing { cursor: grabbing; }
      .dsh-whale-flip { display: block; position: relative; z-index: 5; transition: transform 0.25s ease; }
      .dsh-whale-svg {
        display: block;
        overflow: visible;
        filter: drop-shadow(0 10px 22px rgba(35, 100, 170, 0.3));
        animation: dsh-whale-bob 4s ease-in-out infinite;
      }
      @keyframes dsh-whale-bob {
        0%, 100% { transform: translateY(0) rotate(-2deg); }
        50% { transform: translateY(-7px) rotate(2deg); }
      }
      .dsh-whale-speech {
        position: absolute;
        bottom: calc(100% + 12px);
        left: 50%;
        transform: translateX(-50%);
        background: #ffffff;
        color: #123c6b;
        padding: 8px 14px;
        border-radius: 16px;
        font-size: 13px;
        font-weight: 600;
        line-height: 1.3;
        white-space: nowrap;
        box-shadow: 0 8px 20px rgba(18, 60, 107, 0.18);
        animation: dsh-speech-in 0.28s cubic-bezier(0.34, 1.56, 0.64, 1);
        pointer-events: none;
        z-index: 7;
      }
      .dsh-whale-speech::after {
        content: '';
        position: absolute;
        top: 100%;
        left: 50%;
        transform: translateX(-50%);
        border: 6px solid transparent;
        border-top-color: #ffffff;
      }
      @keyframes dsh-speech-in {
        from { transform: translateX(-50%) scale(0.6); opacity: 0; }
        to { transform: translateX(-50%) scale(1); opacity: 1; }
      }
      .dsh-whale-burst {
        position: absolute;
        left: 50%;
        top: 55%;
        border-radius: 50%;
        pointer-events: none;
        animation: dsh-burst 1.1s ease-out forwards;
      }
      @keyframes dsh-burst {
        0% { transform: translate(0, 0) scale(0.5); opacity: 1; }
        100% { transform: translate(var(--dx), var(--dy)) scale(1.5); opacity: 0; }
      }
      .dsh-whale-spout-burst {
        transform-box: view-box;
        transform-origin: 220px 60px;
        animation: dsh-spout-burst 1.3s ease-out forwards;
      }
      @keyframes dsh-spout-burst {
        0% { transform: scaleY(0.15) scaleX(0.8); opacity: 0; }
        25% { transform: scaleY(1) scaleX(1); opacity: 1; }
        100% { transform: scaleY(1.35) scaleX(1) translateY(-10px); opacity: 0; }
      }
      .dsh-whale-svg-dizzy { animation: none; }
      .dsh-whale-spiral-spin {
        transform-box: fill-box;
        transform-origin: center;
        animation: dsh-spiral-spin 0.8s linear infinite;
      }
      @keyframes dsh-spiral-spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
      .dsh-whale-drool {
        transform-box: view-box;
        transform-origin: 252px 87px;
        animation: dsh-drool-drip 2s ease-in-out infinite;
      }
      @keyframes dsh-drool-drip {
        0%, 100% { transform: scaleY(0.85); }
        50% { transform: scaleY(1.15); }
      }
      .dsh-whale-fin {
        transform-box: view-box;
        transform-origin: 108px 110px;
        animation: dsh-fin-swing 1.5s ease-in-out infinite;
      }
      @keyframes dsh-fin-swing {
        0%, 100% { transform: rotate(0deg); }
        25% { transform: rotate(-14deg); }
        75% { transform: rotate(14deg); }
      }
      .dsh-whale-ripples-back path,
      .dsh-whale-ripples-front path {
        animation: dsh-wave-flow 1.8s ease-in-out infinite;
      }
      @keyframes dsh-wave-flow {
        0%, 100% { transform: translateX(0); opacity: 0.4; }
        50% { transform: translateX(7px); opacity: 0.7; }
      }
      .dsh-dizzy-stars-back {
        position: absolute;
        top: 0;
        left: 0;
        width: 200px;
        height: 112px;
        pointer-events: none;
        z-index: 3;
      }
      .dsh-dizzy-stars-front {
        position: absolute;
        top: 0;
        left: 0;
        width: 200px;
        height: 112px;
        pointer-events: none;
        z-index: 6;
      }
      .dsh-dizzy-star {
        position: absolute;
        background: #ffd166;
        clip-path: polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%);
      }
      .dsh-dizzy-star-main {
        filter: drop-shadow(0 0 4px rgba(255, 200, 60, 0.9));
      }
    `;

    function apply(ctx) {
      const slots = ctx.get('slots');
      if (slots === undefined) return;

      ctx.effect(() => {
        const styleEl = document.createElement('style');
        styleEl.textContent = CSS;
        document.head.appendChild(styleEl);
        return () => styleEl.remove();
      });

      const W = 200;
      const H = 112;
      const MARGIN = 24;
      const REST_TICKS = 667;
      const DIZZY_VELOCITY = 1.4;
      const DIZZY_FLIPS = 3;
      const WAKE_CLICKS = 5;
      const VERT_DRIFT = 20;
      const EYE_X_OFF = 161;
      const EYE_Y_OFF = 57.5;
      const EYE_X_OFF_FLIPPED = 39;
      const ORBIT_RX = 52;
      const ORBIT_RY = 22;
      const ORBIT_CX_FRONT = 161;
      const ORBIT_CX_BACK = 39;
      const ORBIT_CY = 31;
      const ORBIT_SPEED = 0.08;
      const TRAIL_STEP = 0.22;
      const TRAIL_COUNT = 5;
      const DROOL = 'M 0 0 C 5 4 5 9 0 11 C -5 9 -5 4 0 0 Z';

      function makeSpiral(turns, maxR, segments) {
        let d = '';
        for (let i = 0; i <= segments; i++) {
          const t = i / segments;
          const a = t * turns * 2 * Math.PI;
          const r = maxR * t;
          d += (i === 0 ? 'M ' : ' L ') + (r * Math.cos(a)).toFixed(2) + ' ' + (r * Math.sin(a)).toFixed(2);
        }
        return d;
      }
      const SPIRAL_EYE = makeSpiral(1.8, 4.5, 80);

      let currentPos = null;
      let target = null;
      let dragging = null;
      let speechTimer = null;
      let restTicks = 0;
      let dizzyFlag = false;
      let wakeCount = 0;

      function viewport() {
        if (typeof window !== 'undefined') {
          return { w: window.innerWidth, h: window.innerHeight };
        }
        return { w: 1280, h: 800 };
      }

      function clamp(v, lo, hi) {
        return Math.max(lo, Math.min(hi, v));
      }

      function Whale() {
        const [pos, setPos] = React.useState(() => {
          const vp = viewport();
          const init = { x: vp.w - W - MARGIN, y: vp.h - H - MARGIN };
          currentPos = init;
          return init;
        });
        const [face, setFace] = React.useState(1);
        const [grabbing, setGrabbing] = React.useState(false);
        const [speech, setSpeech] = React.useState(null);
        const [bursts, setBursts] = React.useState([]);
        const [spout, setSpout] = React.useState(false);
        const [cursor, setCursor] = React.useState(null);
        const [dizzy, setDizzy] = React.useState(false);
        const [orbitAngle, setOrbitAngle] = React.useState(0);

        function randomTarget() {
          const vp = viewport();
          const yMin = MARGIN;
          const yMax = vp.h - H - MARGIN;
          const baseY = currentPos ? clamp(currentPos.y, yMin, yMax) : (yMin + yMax) / 2;
          const y = clamp(baseY + (Math.random() * 2 - 1) * VERT_DRIFT, yMin, yMax);
          const x = MARGIN + Math.random() * Math.max(1, vp.w - W - MARGIN * 2);
          return { x, y };
        }

        function say(text, ms) {
          setSpeech(text);
          if (speechTimer) { speechTimer(); speechTimer = null; }
          speechTimer = ctx.timeout(() => {
            setSpeech(null);
            setBursts([]);
            setSpout(false);
            speechTimer = null;
          }, ms);
        }

        function react() {
          const phrases = [
            '噗噜噗噜~',
            '你好呀！🐳',
            '咕噜咕噜～',
            '一起去游泳吗？',
            'Hi! 🐋',
            'Hello there!',
          ];
          say(phrases[Math.floor(Math.random() * phrases.length)], 2400);
          const b = [];
          const n = 6 + Math.floor(Math.random() * 3);
          for (let i = 0; i < n; i++) {
            b.push({
              dx: Math.round((Math.random() - 0.5) * 140),
              dy: Math.round(-30 - Math.random() * 90),
              size: Math.round(5 + Math.random() * 8),
              color: Math.random() < 0.5 ? '#a5d8ff' : '#ffb7cd',
              delay: Math.round(Math.random() * 200) / 1000,
            });
          }
          setBursts(b);
          setSpout(true);
        }

        function goDizzy() {
          dizzyFlag = true;
          setDizzy(true);
          wakeCount = WAKE_CLICKS;
          setBursts([]);
          setSpout(false);
          say('好晕……多点我几下！😵💫', 3000);
        }

        function wakeUp() {
          dizzyFlag = false;
          setDizzy(false);
          wakeCount = 0;
          target = randomTarget();
          say('清醒啦！✨', 1600);
        }

        function wakeClick() {
          wakeCount -= 1;
          if (wakeCount <= 0) {
            wakeUp();
          } else {
            say('再点我 ' + wakeCount + ' 下…', 1400);
          }
        }

        React.useEffect(() => {
          if (typeof window === 'undefined') return undefined;
          const onMove = (e) => setCursor({ x: e.clientX, y: e.clientY });
          window.addEventListener('mousemove', onMove);
          return () => window.removeEventListener('mousemove', onMove);
        }, []);

        React.useEffect(() => {
          return ctx.interval(() => {
            if (dragging) return;
            if (dizzyFlag) return;
            if (restTicks > 0) { restTicks--; return; }
            const p = currentPos;
            if (!target) { target = randomTarget(); return; }
            const dx = target.x - p.x;
            const dy = target.y - p.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 6) { target = randomTarget(); return; }
            const speed = 1;
            const step = Math.min(dist, speed);
            const nx = p.x + (dx / dist) * step;
            const ny = p.y + (dy / dist) * step;
            if (Math.abs(dx) > 0.5) setFace(dx > 0 ? 1 : -1);
            currentPos = { x: nx, y: ny };
            setPos({ x: nx, y: ny });
          }, 30);
        }, []);

        React.useEffect(() => {
          return ctx.interval(() => {
            if (dizzyFlag || dragging) return;
            if (Math.random() < 0.2) {
              setSpout(true);
              ctx.timeout(() => setSpout(false), 1500);
            }
          }, 3200);
        }, []);

        React.useEffect(() => {
          if (!dizzy) return undefined;
          return ctx.interval(() => {
            setOrbitAngle((a) => a + ORBIT_SPEED);
          }, 30);
        }, [dizzy]);

        function onPointerDown(e) {
          if (e.pointerType === 'mouse' && e.button !== 0) return;
          e.preventDefault();
          if (e.currentTarget.setPointerCapture) e.currentTarget.setPointerCapture(e.pointerId);
          dragging = { offsetX: e.clientX - currentPos.x, offsetY: e.clientY - currentPos.y, moved: 0, lastT: Date.now(), lastX: currentPos.x, lastY: currentPos.y, peakV: 0, flips: 0, lastSignX: 0, lastSignY: 0 };
          setGrabbing(true);
        }

        function onPointerMove(e) {
          const d = dragging;
          if (!d) return;
          const vp = viewport();
          const nx = clamp(e.clientX - d.offsetX, 60 - W, vp.w - 60);
          const ny = clamp(e.clientY - d.offsetY, 60 - H, vp.h - 60);
          d.moved = Math.max(d.moved, Math.sqrt((nx - currentPos.x) * (nx - currentPos.x) + (ny - currentPos.y) * (ny - currentPos.y)));
          const now = Date.now();
          const dt = now - d.lastT;
          const stepDx = nx - d.lastX;
          const stepDy = ny - d.lastY;
          const step = Math.sqrt(stepDx * stepDx + stepDy * stepDy);
          if (dt > 4 && step > 10) {
            const v = step / dt;
            if (v > d.peakV) d.peakV = v;
          }
          if (step > 6) {
            if (Math.abs(stepDx) > 6) {
              const sx = stepDx > 0 ? 1 : -1;
              if (d.lastSignX && d.lastSignX !== sx) d.flips += 1;
              d.lastSignX = sx;
            }
            if (Math.abs(stepDy) > 6) {
              const sy = stepDy > 0 ? 1 : -1;
              if (d.lastSignY && d.lastSignY !== sy) d.flips += 1;
              d.lastSignY = sy;
            }
          }
          d.lastT = now;
          d.lastX = nx;
          d.lastY = ny;
          if (nx > currentPos.x + 1) setFace(1);
          else if (nx < currentPos.x - 1) setFace(-1);
          currentPos = { x: nx, y: ny };
          setPos({ x: nx, y: ny });
        }

        function onPointerUp(e) {
          const d = dragging;
          dragging = null;
          setGrabbing(false);
          if (d) {
            if (d.moved < 6) {
              if (dizzyFlag) wakeClick();
              else react();
            } else if (!dizzyFlag) {
              if (d.peakV > DIZZY_VELOCITY && d.flips >= DIZZY_FLIPS) goDizzy();
              else restTicks = REST_TICKS;
            }
          }
          target = randomTarget();
        }

        function onPointerCancel() {
          dragging = null;
          setGrabbing(false);
        }

        function onKeyDown(e) {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            if (dizzyFlag) wakeClick();
            else react();
          }
        }

        let lx = 0;
        let ly = 0;
        if (cursor && !dizzy) {
          const ex = pos.x + (face === 1 ? EYE_X_OFF : EYE_X_OFF_FLIPPED);
          const ey = pos.y + EYE_Y_OFF;
          const dxc = cursor.x - ex;
          const dyc = cursor.y - ey;
          const d = Math.sqrt(dxc * dxc + dyc * dyc);
          if (d > 1) {
            lx = (dxc / d) * face * 3.4;
            ly = (dyc / d) * 3.4;
          }
        }
        const pupilCx = 215.4 + lx;
        const pupilCy = 77.1 + ly;
        const glintCx = 214.2 + lx;
        const glintCy = 75.8 + ly;

        const ocx = face === 1 ? ORBIT_CX_FRONT : ORBIT_CX_BACK;
        const backStars = [];
        const frontStars = [];
        function starEl(key, x, y, size, opacity, main) {
          return React.createElement('span', {
            key: key,
            className: main ? 'dsh-dizzy-star dsh-dizzy-star-main' : 'dsh-dizzy-star',
            style: {
              left: (x - size / 2) + 'px',
              top: (y - size / 2) + 'px',
              width: size + 'px',
              height: size + 'px',
              opacity: opacity,
            },
          });
        }
        if (dizzy) {
          for (let i = 0; i < 4; i++) {
            const angle = orbitAngle + i * (Math.PI / 2);
            for (let k = TRAIL_COUNT; k >= 1; k--) {
              const ga = angle - k * TRAIL_STEP;
              const gx = ocx + ORBIT_RX * Math.cos(ga);
              const gy = ORBIT_CY + ORBIT_RY * Math.sin(ga);
              const gsize = Math.max(3, Math.round(15 * (1 - k * 0.16)));
              const gopacity = Math.round((0.45 - k * 0.07) * 100) / 100;
              const gfront = (gx - ocx) * face > 0;
              (gfront ? frontStars : backStars).push(starEl('star' + i + 'g' + k, gx, gy, gsize, gopacity, false));
            }
            const px = ocx + ORBIT_RX * Math.cos(angle);
            const py = ORBIT_CY + ORBIT_RY * Math.sin(angle);
            const pfront = (px - ocx) * face > 0;
            (pfront ? frontStars : backStars).push(starEl('star' + i, px, py, 15, 1, true));
          }
        }

        const bodyClass = grabbing ? 'dsh-whale-body dsh-grabbing' : 'dsh-whale-body';
        const svgClass = dizzy ? 'dsh-whale-svg dsh-whale-svg-dizzy' : 'dsh-whale-svg';

        return React.createElement('div', { className: 'dsh-whale-anchor' },
          React.createElement('div', {
            className: bodyClass,
            style: { transform: 'translate(' + pos.x + 'px, ' + pos.y + 'px)' },
            role: 'button',
            tabIndex: 0,
            'aria-label': 'Whale',
            onPointerDown: onPointerDown,
            onPointerMove: onPointerMove,
            onPointerUp: onPointerUp,
            onPointerCancel: onPointerCancel,
            onKeyDown: onKeyDown,
          },
            speech ? React.createElement('div', { className: 'dsh-whale-speech' }, speech) : null,
            bursts.map((b, i) => React.createElement('span', {
              key: i,
              className: 'dsh-whale-burst',
              style: {
                '--dx': b.dx + 'px',
                '--dy': b.dy + 'px',
                width: b.size + 'px',
                height: b.size + 'px',
                background: b.color,
                animationDelay: b.delay + 's',
              },
            })),
            dizzy ? React.createElement('div', { className: 'dsh-dizzy-stars-back' }, backStars) : null,
            React.createElement('div', { className: 'dsh-whale-flip', style: { transform: 'scaleX(' + face + ')' } },
              React.createElement('svg', { className: svgClass, viewBox: '0 0 268 150', width: W, height: H, role: 'img' },
                spout ? React.createElement('g', { className: 'dsh-whale-spout-burst' },
                  React.createElement('path', { d: 'M 215 60 C 208 39 202 24 193 7', stroke: '#8fd0f8', strokeWidth: '6', fill: 'none', strokeLinecap: 'round' }),
                  React.createElement('path', { d: 'M 220 60 C 220 34 224 18 232 7', stroke: '#8fd0f8', strokeWidth: '6', fill: 'none', strokeLinecap: 'round' }),
                  React.createElement('path', { d: 'M 225 60 C 233 41 245 29 257 25', stroke: '#8fd0f8', strokeWidth: '6', fill: 'none', strokeLinecap: 'round' }),
                  React.createElement('circle', { cx: '193', cy: '5', r: '5', fill: '#b8e2fb' }),
                  React.createElement('circle', { cx: '232', cy: '5', r: '5', fill: '#b8e2fb' }),
                  React.createElement('circle', { cx: '259', cy: '23', r: '5', fill: '#b8e2fb' })
                ) : null,
                React.createElement('g', { className: 'dsh-whale-ripples-back' },
                  React.createElement('path', { d: 'M 50 132 C 60 128 72 136 84 132 C 94 130 106 135 118 131 C 128 129 140 134 152 132 C 164 130 176 135 188 132 C 200 129 212 135 224 132', stroke: '#5b9bd5', strokeWidth: '1.6', fill: 'none', strokeLinecap: 'round', style: { animationDelay: '0s' } })
                ),
                React.createElement('g', { transform: 'translate(268 0) scale(-1 1)' },
                  React.createElement('path', { d: 'M 15 87 C 21 72 42 63 70 60 C 101 57 132 60 159 67 C 178 72 192 76 202 78 C 210 80 217 78 222 73 C 226 68 228 62 229 56 C 223 52 216 49 210 50 C 215 45 222 43 229 46 C 232 47 234 49 236 51 C 241 46 249 43 257 45 C 255 51 251 57 246 61 C 242 64 237 65 233 63 C 232 71 230 79 226 87 C 220 98 211 107 200 115 C 186 124 169 129 149 132 C 127 135 104 135 82 133 C 62 131 46 126 33 118 C 22 111 15 100 15 87 Z', fill: '#3F84B8' }),
                  React.createElement('path', { d: 'M 18 91 C 28 101 42 109 59 115 C 78 122 99 124 120 123 C 136 123 149 120 160 116 C 150 123 138 127 124 129 C 106 132 88 131 71 129 C 54 126 41 121 31 114 C 23 108 18 100 18 91 Z', fill: '#B9E3EC' }),
                  React.createElement('g', { className: 'dsh-whale-fin' },
                    React.createElement('path', { d: 'M 103 109 C 100 117 102 125 108 131 C 114 135 121 135 126 132 C 121 125 117 118 113 112 C 110 109 106 107 103 109 Z', fill: '#276B9F' })
                  )
                ),
                React.createElement('g', { className: 'dsh-whale-ripples-front' },
                  React.createElement('path', { d: 'M 60 141 C 72 137 84 145 96 141 C 108 138 120 143 132 141 C 144 138 156 144 168 141 C 180 138 192 144 204 141', stroke: '#5b9bd5', strokeWidth: '1.6', fill: 'none', strokeLinecap: 'round', style: { animationDelay: '0.8s' } }),
                  React.createElement('path', { d: 'M 90 146 C 101 143 112 148 123 146 C 134 144 145 148 156 146 C 167 144 178 148 189 146', stroke: '#5b9bd5', strokeWidth: '1.4', fill: 'none', strokeLinecap: 'round', style: { animationDelay: '1.6s' } })
                ),
                React.createElement('circle', { cx: '216', cy: '77', r: '5.1', fill: '#ffffff' }),
                dizzy
                  ? React.createElement('g', { transform: 'translate(216 77)' },
                      React.createElement('g', { className: 'dsh-whale-spiral-spin' },
                        React.createElement('path', { d: SPIRAL_EYE, stroke: '#0F2E57', strokeWidth: '1', fill: 'none', strokeLinecap: 'round', strokeLinejoin: 'round' })
                      )
                    )
                  : null,
                dizzy ? null : React.createElement('circle', { cx: pupilCx, cy: pupilCy, r: '2.8', fill: '#0F2E57' }),
                dizzy ? null : React.createElement('circle', { cx: glintCx, cy: glintCy, r: '1.0', fill: '#ffffff' }),
                React.createElement('path', { d: 'M 252 87 C 243 89.5 233 89.5 223 88', stroke: '#0F2E57', strokeWidth: '2', fill: 'none', strokeLinecap: 'round' }),
                dizzy ? React.createElement('g', { className: 'dsh-whale-drool' },
                  React.createElement('path', { d: DROOL, transform: 'translate(252 87)', fill: '#bfe3ff', stroke: '#8fc7ef', strokeWidth: '1', strokeLinejoin: 'round' })
                ) : null
              )
            ),
            dizzy ? React.createElement('div', { className: 'dsh-dizzy-stars-front' }, frontStars) : null
          )
        );
      }

      slots.inject('shell.overlay', () => slots.register(
        { name: 'shell.overlay', id: 'whale' },
        () => React.createElement(Whale),
      ));
    }

    exports.name = name;
    exports.inject = inject;
    exports.apply = apply;
    return module.exports;
  },
});
