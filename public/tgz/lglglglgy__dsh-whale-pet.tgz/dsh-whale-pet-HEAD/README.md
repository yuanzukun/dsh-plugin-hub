# 🐳 DSH 鲸鱼桌宠 · dsh-whale-pet

一只会自己游来游去、会晕、会喷水、还会盯着你鼠标看的蓝色鲸鱼，住在你的
[DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) Web UI 右下角。

> 装在 `web` profile 里，重启后永久生效——跨 session、跨重启都在。
<img width="450" height="116" alt="file-b1580f974e659d5989789758a6030f87" src="https://github.com/user-attachments/assets/5886a71a-de7d-4a20-a4be-12dd59ca06d4" />

---

## ✨ 它会做什么

| 能力 | 说明 |
| --- | --- |
| 🏊 自由游动 | 自动在屏幕上以水平为主地游来游去，上下只做小幅漂移 |
| 👀 眼神跟踪 | 眼睛始终盯着你的鼠标光标，游到哪看到哪 |
| 🖱️ 拖拽 | 按住就能把它拖到任何位置 |
| 💦 点击喷水 | 单击（或键盘聚焦后按 Enter / 空格）会喷水柱 + 冒气泡对话 + 炸开泡泡 |
| 😵 晕眩 | 快速来回甩动它，会晕过去：螺旋眼、绕头的星星（带拖尾）、流口水、原地静止 |
| 🖱️ 连点叫醒 | 晕眩后连续点 5 下就清醒恢复 |
| 🌊 水波 | 肚皮下方有会流动的波浪线，一部分藏在身体后面 |
| 🐋 腹鳍摆动 | 游动时腹鳍会来回摆动 |

---

## 🎮 玩法详解

**基础交互**

- **看它游**：啥也不用做，它会自己在屏幕里水平游动，偶尔自动喷一口水。
- **拖它**：按住鲸鱼拖动即可；松手后它会休息 20 秒再继续游。
- **点它**：单击 → 喷水 + 随机气泡对话（如「噗噜噗噜~」「你好呀！🐳」）+ 一圈泡泡。
- **键盘**：Tab 聚焦到鲸鱼后，按 Enter 或空格等同于点击。

**怎么让它晕 😵**

1. 按住鲸鱼，**快速来回甩动**（左右快速甩几下）；
2. 它就会进入晕眩状态：眼睛变成旋转的蚊香螺旋、头顶出现一圈带拖尾的星星、嘴角流口水、身体完全静止；
3. 晕眩时**连点 5 次**就能叫醒，它会喊「清醒啦！✨」然后继续游。

> 普通拖动、单方向快甩都不会误触发晕眩，只有「快速 + 往返」才算。

---

## 📦 安装

```sh
# 从 GitHub 安装（推荐）
dsh plugin --profile web add github:lglglglgy/dsh-whale-pet

# 或从本地目录安装
dsh plugin --profile web add ./dsh-whale-pet

# 或从 tarball 安装
dsh plugin --profile web add ./dsh-whale-pet-0.1.0.tgz
```

然后**重启 Web UI**：

```sh
dsh web
```

重启后，鲸鱼就会出现在右下角。插件集合的变更要重启后才生效。

> 前提：这个 profile 必须带 Web 运行时（`web` profile 自带 `@deepseek-ai/dsh-web-app`）。
> 装在 headless / TUI 这类 profile 里不会显示。

### 验证安装

```sh
dsh --profile web --dump-config
# 应能看到：
#   # == dsh-whale-pet
#   - id: whale
#     name: dsh-whale-pet
```

---

## 🗂️ 目录结构

```
dsh-whale-pet/
├── package.json       # dsh.bundle（patch 层）+ dsh.client（platform: web）
├── cordis.patch.yml   # - insert: - id: whale, name: dsh-whale-pet
├── index.js           # host 空入口（纯浏览器插件所需的 host 半）
└── client.js          # window.__ModuleLoader__.load(...) 浏览器 bundle（已构建，无需 build）
```

`client.js` 已经是构建产物，因此从 GitHub 安装**不需要**额外 build 授权。

---

## ❓ 常见问题

- **装完没看到鲸鱼？** 确认装在 `web` profile，且重启过 Web UI。
- **能关掉吗？** 卸载即可：
  ```sh
  dsh plugin --profile web remove dsh-whale-pet
  ```
- **想改行为/外观？** 直接改 `client.js` 里的坐标、颜色、动画参数，重新 `add` 即可。

---

## License

MIT
