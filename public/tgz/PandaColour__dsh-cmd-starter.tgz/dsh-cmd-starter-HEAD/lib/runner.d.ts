/**
 * Claude-Code style one-shot runner over the dsh 0.2.x headless profile.
 *
 * Reads the `cmdStartup` service, resolves the session identity (fresh create,
 * exact `--resume` by id or `--name` alias, or latest via `--continue`), runs
 * one task to quiescence — waiting for background subagents the turn spawned —
 * flushes the durable Session, and prints either the final assistant text
 * (default) or the official newline-delimited run-event stream (`--json`).
 *
 * The drive loop mirrors the official `@deepseek-ai/dsh-headless` runner so the
 * two differ only in the scheduling layer this plugin adds; the official row is
 * replaced, not wrapped, because headless mode cannot host two runners.
 * @module dsh-cmd-starter
 */
import type { Context } from '@deepseek-ai/cordis';
import { CMD_STARTUP_SERVICE } from './startup.js';
/** Stable Cordis plugin name. */
export declare const name = "cmd-runner";
/** Core services required before the one-shot turn can start. */
export declare const inject: string[];
/** Process-facing effects of one run. */
interface HeadlessIo {
    stdout: {
        write(chunk: string): unknown;
    };
    stderr: {
        write(chunk: string): unknown;
    };
    exit(code: number): void;
}
/** The process streams the runner writes to; tests substitute captures. */
export declare const internals: {
    stdout: HeadlessIo['stdout'];
    stderr: HeadlessIo['stderr'];
};
/** Mount the one-shot direct driver. */
export declare function apply(ctx: Context): void;
export { CMD_STARTUP_SERVICE };
