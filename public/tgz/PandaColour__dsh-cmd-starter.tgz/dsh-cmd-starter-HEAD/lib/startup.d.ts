/**
 * Claude-Code style command-line intake for the headless profile, on dsh 0.2.x.
 *
 * The official `@deepseek-ai/dsh-headless` startup already parses the task
 * positional, `--session-id`, `--json`, and `--help`. This plugin replaces that
 * row (headless mode cannot host two argument parsers on one argv), so it keeps
 * the official surface it still needs — the task positional and `--json` with
 * exactly the official NDJSON semantics — and adds only the scheduling flags
 * official headless does not provide:
 *
 *   - `--append-prompt`  per-run extra system-prompt text
 *   - `-c, --continue`   resume the most recently created session
 *   - `--resume <id>`    resume an exact session, by id or `--name` alias
 *   - `--name <name>`    durable alias for this session
 *   - `--provider/--model/--max-tokens/--effort` per-run model overrides
 *
 * Intentionally NOT re-exposed: `--session-id` (official spelling; use
 * `--resume <id>`, which also resolves aliases) and the stdin task form (`-`).
 * @module dsh-cmd-starter/startup
 */
import type { Context } from '@deepseek-ai/cordis';
/** Stable Cordis plugin name. */
export declare const name = "cmd-startup";
/** Services required before the invocation can be parsed. */
export declare const inject: string[];
/** Service name the runner row injects. */
export declare const CMD_STARTUP_SERVICE = "cmdStartup";
/** What the runner reads from {@link CMD_STARTUP_SERVICE}. */
export interface CmdStartupValues {
    /** The task text this invocation asked for. */
    task: string;
    /** Extra system-prompt text appended for THIS run only (repeatable). */
    appendPrompts: string[];
    /** Resume this exact persisted session instead of creating a new one. */
    resumeSessionId?: string;
    /** Resume the most recently created session (ignored when `resumeSessionId` is set). */
    continueLatest: boolean;
    /** Name this session under a durable alias (later: `--resume <name>`). */
    name?: string;
    /** Emit the official newline-delimited run-event stream instead of the final text. */
    json: boolean;
    /** Override the provider route for this run. */
    provider?: string;
    /** Override the model id for this run. */
    model?: string;
    /** Per-request output-token cap for this run. */
    maxTokens?: number;
    /** Reasoning effort for this run (adapter-specific: off|high|max, …). */
    effort?: string;
}
/** Parse and publish the one-shot task plus scheduling flags as a Cordis service. */
export declare function apply(ctx: Context): void;
