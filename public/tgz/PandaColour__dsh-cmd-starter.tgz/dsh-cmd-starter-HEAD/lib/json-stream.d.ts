/**
 * `--json` run projection: a bounded, ordered event stream derived from one
 * Agent's durable Session events, matching the official
 * `@deepseek-ai/dsh-headless --json` shape so a consumer can parse either
 * stream with the same reader:
 *
 *   `session` → `status` (turn_start/step_start/step_end/turn_end) →
 *   `thinking` / `text` / `tool_call` / `tool_result` → `final`
 *
 * Every projected event is a commit point: text and reasoning come from
 * committed `assistant/message` content, never from a live attempt that may
 * still be retried or discarded, so the stream never carries content the
 * durable log does not contain. The terminal `final` carries the same lossless
 * answer the default mode prints and is exempt from the byte cap.
 *
 * Ported from the official headless projection (same project family, MIT) so
 * `--json` keeps official semantics after this plugin replaces that row.
 * @module dsh-cmd-starter/json-stream
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
/**
 * Serialize one projected payload under both limits: every string and key is
 * capped at `maxStringBytes`, and the serialized line at `maxEventBytes`. When
 * the line is still too long, scalar fields survive and structured fields are
 * dropped; when even those are too long, only `type` and `truncated` remain.
 */
export declare function boundJsonLine(event: Record<string, unknown>, maxStringBytes?: number, maxEventBytes?: number): string;
/** The handle one run owns: terminate the stream with the final answer, then detach. */
export interface JsonProjection {
    finish(text: string): void;
    dispose(): void;
}
/**
 * Project one Agent's run as newline-delimited JSON on `sink`. Invoke before
 * submitting the task: the opening `session` event is written immediately.
 * @param ctx - plugin context carrying the live Session feed.
 * @param agent - the exact Agent whose events belong to this invocation.
 * @param sink - stdout sink receiving one JSON object per line.
 * @param options - projection tunables.
 * @returns the projection handle that finishes or disposes the stream.
 */
export declare function projectJsonRun(ctx: Context, agent: Agent, sink: {
    write(chunk: string): unknown;
}, options?: {
    cwd?: string;
}): JsonProjection;
