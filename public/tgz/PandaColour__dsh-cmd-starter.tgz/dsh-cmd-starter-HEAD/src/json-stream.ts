/**
 * `--json` run projection: a bounded, ordered event stream derived from one
 * Agent's durable Session events, matching the official
 * `@deepseek-ai/dsh-headless --json` shape so a consumer can parse either
 * stream with the same reader:
 *
 *   `session` → `status` (turn_start/step_start/step_end/turn_end) →
 *   `thinking` / `text` / `tool_call` / `tool_result` → `final`
 *
 * Every projected event is a commit point: text and reasoning come from
 * committed `assistant/message` content, never from a live attempt that may
 * still be retried or discarded, so the stream never carries content the
 * durable log does not contain. The terminal `final` carries the same lossless
 * answer the default mode prints and is exempt from the byte cap.
 *
 * Ported from the official headless projection (same project family, MIT) so
 * `--json` keeps official semantics after this plugin replaces that row.
 * @module dsh-cmd-starter/json-stream
 */

import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
import { lastAssistantStreamChunk } from '@deepseek-ai/dsh-llm/assistant-stream'

/** Default per-string and per-key byte cap applied to every bounded payload. */
const MAX_STRING_BYTES = 8 * 1024
/** Default cap on one projected event's serialized bytes, newline included. */
const MAX_EVENT_BYTES = 32 * 1024
/** Bytes every newline-delimited writer appends after one serialized event. */
const LINE_TERMINATOR_BYTES = 1
/** Maximum container depth one projected payload keeps before the tail is cut. */
const MAX_DEPTH = 64

/** Token usage a provider reported for one attempt or step. */
type Usage = NonNullable<SessionEvent<'assistant/message'>['data']['usage']>
/** One attempt's compacted provider stream. */
type Stream = SessionEvent<'assistant/attempt'>['data']['stream']

/** Truncate one UTF-8 string to `maxBytes`, dropping a split trailing character. */
function truncateUtf8(text: string, maxBytes: number): string {
  const decoded = Buffer.from(text, 'utf8').subarray(0, maxBytes).toString('utf8')
  return decoded.endsWith('\uFFFD') ? decoded.slice(0, -1) : decoded
}

/** Recursively cap every string (keys included) in one JSON-serializable value. */
function boundValue(value: unknown, maxBytes: number, state: { truncated: boolean }, depth = 0): unknown {
  if (typeof value === 'string') {
    if (Buffer.byteLength(value, 'utf8') <= maxBytes) return value
    state.truncated = true
    return truncateUtf8(value, maxBytes)
  }
  if (Array.isArray(value)) {
    if (depth >= MAX_DEPTH) {
      state.truncated = true
      return '[truncated: depth]'
    }
    return value.map(item => boundValue(item, maxBytes, state, depth + 1))
  }
  if (value !== null && typeof value === 'object') {
    if (depth >= MAX_DEPTH) {
      state.truncated = true
      return '[truncated: depth]'
    }
    const bounded: Record<string, unknown> = {}
    for (const [key, item] of Object.entries(value)) {
      const keyTooLong = Buffer.byteLength(key, 'utf8') > maxBytes
      if (keyTooLong) state.truncated = true
      bounded[keyTooLong ? truncateUtf8(key, maxBytes) : key] = boundValue(item, maxBytes, state, depth + 1)
    }
    return bounded
  }
  return value
}

/**
 * Serialize one projected payload under both limits: every string and key is
 * capped at `maxStringBytes`, and the serialized line at `maxEventBytes`. When
 * the line is still too long, scalar fields survive and structured fields are
 * dropped; when even those are too long, only `type` and `truncated` remain.
 */
export function boundJsonLine(
  event: Record<string, unknown>,
  maxStringBytes = MAX_STRING_BYTES,
  maxEventBytes = MAX_EVENT_BYTES,
): string {
  const limit = maxEventBytes - LINE_TERMINATOR_BYTES
  const state = { truncated: false }
  const bounded = boundValue(event, maxStringBytes, state) as Record<string, unknown>
  if (state.truncated) bounded.truncated = true
  const line = JSON.stringify(bounded)
  if (Buffer.byteLength(line, 'utf8') <= limit) return line
  const scalars: Record<string, unknown> = {}
  for (const [key, value] of Object.entries(bounded)) {
    if (value === null || typeof value !== 'object') scalars[key] = value
  }
  scalars.truncated = true
  const short = JSON.stringify(scalars)
  if (Buffer.byteLength(short, 'utf8') <= limit) return short
  return JSON.stringify({ type: bounded.type, truncated: true })
}

/** Parse raw tool-call arguments as the executor does: `''` is `{}`, invalid JSON stays text. */
function parseArguments(raw: string): unknown {
  if (raw === '') return {}
  const seen = { nonFinite: false }
  try {
    const parsed: unknown = JSON.parse(raw, (_key, value: unknown) => {
      if (typeof value === 'number' && !Number.isFinite(value)) seen.nonFinite = true
      return value
    })
    return seen.nonFinite ? raw : parsed
  } catch {
    return raw
  }
}

/** Join the text blocks of one model-facing tool result. */
function resultText(content: readonly { type: string; text?: string }[]): string {
  return content
    .filter((block): block is { type: 'text'; text: string } => block.type === 'text' && typeof block.text === 'string')
    .map(block => block.text)
    .join('')
}

/** The usage a provider reported in one attempt's stream, if any. */
function streamUsage(stream: Stream): Usage | undefined {
  return lastAssistantStreamChunk(stream, 'usage')?.usage
}

/**
 * Accumulate one step's usage across its attempts. A retried attempt keeps its
 * usage only in its `assistant/attempt` stream, so the committed message alone
 * would under-report billed tokens; an attempt that reports no sample makes the
 * step total unknowable, so the step omits usage entirely.
 */
function addUsage(state: { usage: Usage | undefined; complete: boolean }, next: Usage | undefined): { usage: Usage | undefined; complete: boolean } {
  if (next === undefined) return { usage: state.usage, complete: false }
  if (state.usage === undefined) return { usage: next, complete: state.complete }
  const total = state.usage
  const sum = (a: number | undefined, b: number | undefined): number | undefined => (a === undefined || b === undefined ? undefined : a + b)
  const totalTokens = sum(total.totalTokens, next.totalTokens)
  const cacheReadTokens = sum(total.cacheReadTokens, next.cacheReadTokens)
  const cacheWriteTokens = sum(total.cacheWriteTokens, next.cacheWriteTokens)
  const reasoningTokens = sum(total.reasoningTokens, next.reasoningTokens)
  return {
    usage: {
      inputTokens: total.inputTokens + next.inputTokens,
      outputTokens: total.outputTokens + next.outputTokens,
      ...totalTokens === undefined ? {} : { totalTokens },
      ...cacheReadTokens === undefined ? {} : { cacheReadTokens },
      ...cacheWriteTokens === undefined ? {} : { cacheWriteTokens },
      ...reasoningTokens === undefined ? {} : { reasoningTokens },
    },
    complete: state.complete,
  }
}

/** The handle one run owns: terminate the stream with the final answer, then detach. */
export interface JsonProjection {
  finish(text: string): void
  dispose(): void
}

/**
 * Project one Agent's run as newline-delimited JSON on `sink`. Invoke before
 * submitting the task: the opening `session` event is written immediately.
 * @param ctx - plugin context carrying the live Session feed.
 * @param agent - the exact Agent whose events belong to this invocation.
 * @param sink - stdout sink receiving one JSON object per line.
 * @param options - projection tunables.
 * @returns the projection handle that finishes or disposes the stream.
 */
export function projectJsonRun(
  ctx: Context,
  agent: Agent,
  sink: { write(chunk: string): unknown },
  options: { cwd?: string } = {},
): JsonProjection {
  let disposed = false
  let stepUsage: { usage: Usage | undefined; complete: boolean } = { usage: undefined, complete: true }

  const write = (event: Record<string, unknown>): void => {
    sink.write(`${boundJsonLine(event)}\n`)
  }

  const onSessionEvent = (session: unknown, event: SessionEvent): void => {
    if (session !== agent.session) return
    switch (event.type) {
      case 'turn/start':
        write({ type: 'status', phase: 'turn_start', turn: event.data.turn })
        return
      case 'step/start':
        write({ type: 'status', phase: 'step_start', turn: event.data.turn, step: event.data.step })
        return
      case 'assistant/attempt':
        stepUsage = addUsage(stepUsage, streamUsage(event.data.stream))
        return
      case 'assistant/message':
        stepUsage = addUsage(stepUsage, event.data.usage ?? streamUsage(event.data.stream))
        for (const block of event.data.message.content) {
          if (block.type === 'reasoning') write({ type: 'thinking', text: block.text })
          else if (block.type === 'text') write({ type: 'text', text: block.text })
        }
        return
      case 'step/end': {
        const { usage, complete } = stepUsage
        stepUsage = { usage: undefined, complete: true }
        write({
          type: 'status',
          phase: 'step_end',
          turn: event.data.turn,
          step: event.data.step,
          ...complete && usage !== undefined ? { usage } : {},
        })
        return
      }
      case 'turn/end':
        write({ type: 'status', phase: 'turn_end', turn: event.data.turn, reason: event.data.reason })
        return
      case 'tool/call':
        write({ type: 'tool_call', callId: event.data.callId, tool: event.data.name, input: parseArguments(event.data.arguments) })
        return
      case 'tool/result': {
        if (event.surfaceOp !== 'append') return
        const message = event.data.message
        write({
          type: 'tool_result',
          callId: message.toolCallId,
          status: message.isError === true ? 'error' : 'completed',
          result: resultText(message.content),
        })
        return
      }
      default:
        return
    }
  }

  write({ type: 'session', sessionId: agent.id, cwd: options.cwd ?? process.cwd() })
  const stopSession = ctx.on('session/event', onSessionEvent)
  return {
    finish(text: string): void {
      if (disposed) return
      sink.write(`${JSON.stringify({ type: 'final', text })}\n`)
    },
    dispose(): void {
      disposed = true
      stopSession()
    },
  }
}
