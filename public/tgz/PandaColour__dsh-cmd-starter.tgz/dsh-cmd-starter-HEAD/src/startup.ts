/**
 * Claude-Code style command-line intake for the headless profile, on dsh 0.2.x.
 *
 * The official `@deepseek-ai/dsh-headless` startup already parses the task
 * positional, `--session-id`, `--json`, and `--help`. This plugin replaces that
 * row (headless mode cannot host two argument parsers on one argv), so it keeps
 * the official surface it still needs — the task positional and `--json` with
 * exactly the official NDJSON semantics — and adds only the scheduling flags
 * official headless does not provide:
 *
 *   - `--append-prompt`  per-run extra system-prompt text
 *   - `-c, --continue`   resume the most recently created session
 *   - `--resume <id>`    resume an exact session, by id or `--name` alias
 *   - `--name <name>`    durable alias for this session
 *   - `--provider/--model/--max-tokens/--effort` per-run model overrides
 *
 * Intentionally NOT re-exposed: `--session-id` (official spelling; use
 * `--resume <id>`, which also resolves aliases) and the stdin task form (`-`).
 * @module dsh-cmd-starter/startup
 */

import { Command } from 'commander'
import type { Context } from '@deepseek-ai/cordis'
import { parseCmdline } from '@deepseek-ai/dsh-cmdline'

/** Stable Cordis plugin name. */
export const name = 'cmd-startup'

/** Services required before the invocation can be parsed. */
export const inject = ['cmdlineArgs']

/** Service name the runner row injects. */
export const CMD_STARTUP_SERVICE = 'cmdStartup'

/** What the runner reads from {@link CMD_STARTUP_SERVICE}. */
export interface CmdStartupValues {
  /** The task text this invocation asked for. */
  task: string
  /** Extra system-prompt text appended for THIS run only (repeatable). */
  appendPrompts: string[]
  /** Resume this exact persisted session instead of creating a new one. */
  resumeSessionId?: string
  /** Resume the most recently created session (ignored when `resumeSessionId` is set). */
  continueLatest: boolean
  /** Name this session under a durable alias (later: `--resume <name>`). */
  name?: string
  /** Emit the official newline-delimited run-event stream instead of the final text. */
  json: boolean
  /** Override the provider route for this run. */
  provider?: string
  /** Override the model id for this run. */
  model?: string
  /** Per-request output-token cap for this run. */
  maxTokens?: number
  /** Reasoning effort for this run (adapter-specific: off|high|max, …). */
  effort?: string
}

/** Repeatable single-value collector for `--append-prompt`. */
const collect = (value: string, previous: string[] = []): string[] => [...previous, value]

function cmdCommand(): Command {
  return new Command()
    .name('dsh --profile <name>')
    .description(
      'Answer one task in headless mode, print the result, and exit. '
      + 'Claude-Code style scheduling flags follow.',
    )
    .helpOption('-h, --help', 'show this help')
    .argument('[task...]', 'the task text; multiple words are joined by spaces')
    .option('--json', 'write newline-delimited run events to stdout instead of the final message')
    .option('--append-prompt <text>', 'append extra system-prompt text for THIS run only (repeatable)', collect)
    .option('--resume <sessionId>', 'resume an existing session by id or by a --name alias')
    .option('-c, --continue', 'resume the most recently created session')
    .option('--name <name>', 'name this session under a durable alias (later: --resume <name>)')
    .option('--provider <name>', 'override the provider route for this run')
    .option('--model <name>', 'override the model id for this run')
    .option('--max-tokens <n>', 'per-request output-token cap', value => {
      const n = Number(value)
      if (!Number.isInteger(n) || n < 1) throw new Error('--max-tokens needs a positive integer')
      return n
    })
    .option('--effort <level>', 'reasoning effort for this run (adapter-specific)')
    .addHelpText('after', `
Examples:
  dsh --profile headless "run the tests"                      answer one task and exit
  dsh --profile headless --json "run the tests"               emit the official run-event stream
  dsh --profile headless --append-prompt "be terse" "task"    append a per-run system-prompt note
  dsh --profile headless --resume <id> "continue"             resume a persisted session (id or alias)
  dsh --profile headless --name review --json "review this"   name it, then --resume review
  dsh --profile headless -c "continue"                        resume the latest session
`)
}

/** Parse and publish the one-shot task plus scheduling flags as a Cordis service. */
export function apply(ctx: Context): void {
  const program = cmdCommand()
  program.action(() => {
    const task = program.args.join(' ')
    if (task.trim() === '') {
      program.error('error: a task is required, for example: dsh --profile headless "run the tests"')
    }
    const opts = program.opts<{
      appendPrompt?: string[]
      resume?: string
      continue?: boolean
      name?: string
      json?: boolean
      provider?: string
      model?: string
      maxTokens?: number
      effort?: string
    }>()
    if (opts.resume !== undefined && opts.continue === true) {
      program.error('error: --resume and --continue are mutually exclusive')
    }
    if (opts.name !== undefined && opts.name.trim() === '') {
      program.error('error: --name needs a non-empty alias')
    }
    ctx.provide(CMD_STARTUP_SERVICE, {
      task,
      appendPrompts: opts.appendPrompt ?? [],
      resumeSessionId: opts.resume,
      continueLatest: opts.continue === true,
      name: opts.name,
      json: opts.json === true,
      provider: opts.provider,
      model: opts.model,
      maxTokens: opts.maxTokens,
      effort: opts.effort,
    } satisfies CmdStartupValues)
  })
  parseCmdline(ctx, program)
}
