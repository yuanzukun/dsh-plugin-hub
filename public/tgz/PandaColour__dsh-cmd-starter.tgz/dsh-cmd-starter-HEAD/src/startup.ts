/**
 * Claude-Code style command-line intake for the headless profile.
 *
 * Parses the task positional plus scheduling flags, then publishes a single
 * `cmdStartup` service the runner row consumes. The launcher provides
 * `ctx.cmdlineArgs` (the invocation's inner arguments) and `ctx.appExit`
 * (bounded exit request); `parseCmdline` runs this command's action on a
 * successful parse.
 * @module dsh-cmd-starter/startup
 */

import { Command } from 'commander'
import type { Context } from '@deepseek-ai/cordis'
import { parseCmdline } from '@deepseek-ai/dsh-cmdline'

/** Stable Cordis plugin name. */
export const name = 'cmd-startup'

/** Services required before the invocation can be parsed. */
export const inject = ['cmdlineArgs']

/** Service name the runner row injects. */
export const CMD_STARTUP_SERVICE = 'cmdStartup'

/** What the runner reads from {@link CMD_STARTUP_SERVICE}. */
export interface CmdStartupValues {
  /** The task text this invocation asked for. */
  task: string
  /** Extra system-prompt text appended for THIS run only (repeatable). */
  appendPrompts: string[]
  /** Resume this exact persisted session instead of creating a new one. */
  resumeSessionId?: string
  /** Resume the most recently created session (ignored when `resumeSessionId` is set). */
  continueLatest: boolean
  /** Name this session under a durable alias (later: `--resume <name>`). */
  name?: string
  /** Output shape: plain text or a single JSON object on stdout. */
  outputFormat: 'text' | 'json'
  /** Override the provider route for this run. */
  provider?: string
  /** Override the model id for this run. */
  model?: string
  /** Per-request output-token cap for this run. */
  maxTokens?: number
  /** Reasoning effort for this run (adapter-specific: off|high|max, …). */
  effort?: string
}

/** Repeatable single-value collector for `--append-prompt`. */
const collect = (value: string, previous: string[] = []): string[] => [...previous, value]

function cmdCommand(): Command {
  return new Command()
    .name('dsh --profile <name>')
    .description('Answer one task in headless mode, print the result, and exit. Claude-Code style scheduling flags follow.')
    .helpOption('-h, --help', 'show this help')
    .argument('[task...]', 'the task text; multiple words are joined by spaces')
    .option('--append-prompt <text>', 'append extra system-prompt text for THIS run only (repeatable)', collect)
    .option('--resume <sessionId>', 'resume an existing session by id or by a --name alias')
    .option('-c, --continue', 'resume the most recently created session')
    .option('--name <name>', 'name this session under a durable alias (later: --resume <name>)')
    .option('--output-format <format>', 'stdout shape: text (default) or json', /^(text|json)$/, 'text')
    .option('--provider <name>', 'override the provider route for this run')
    .option('--model <name>', 'override the model id for this run')
    .option('--max-tokens <n>', 'per-request output-token cap', value => {
      const n = Number(value)
      if (!Number.isInteger(n) || n < 1) throw new Error('--max-tokens needs a positive integer')
      return n
    })
    .option('--effort <level>', 'reasoning effort for this run (adapter-specific)')
    .addHelpText('after', `
Examples:
  dsh --profile headless "run the tests"                      answer one task and exit
  dsh --profile headless --append-prompt "be terse" "task"    append a per-run system-prompt note
  dsh --profile headless --resume <id> "continue"             resume a persisted session
  dsh --profile headless --name review --output-format json "review this"   name it, then --resume review
  dsh --profile headless -c "continue"                        resume the latest session
  dsh --profile headless --output-format json "task"          emit JSON incl. sessionId
`)
}

/** Parse and publish the one-shot task plus scheduling flags as a Cordis service. */
export function apply(ctx: Context): void {
  const program = cmdCommand()
  program.action(() => {
    const task = program.args.join(' ')
    if (task.trim() === '') program.error('error: a task is required, for example: dsh --profile headless "run the tests"')
    const opts = program.opts<{
      appendPrompt?: string[]
      resume?: string
      continue?: boolean
      name?: string
      outputFormat: 'text' | 'json'
      provider?: string
      model?: string
      maxTokens?: number
      effort?: string
    }>()
    if (opts.resume !== undefined && opts.continue === true) {
      program.error('error: --resume and --continue are mutually exclusive')
    }
    ctx.provide(CMD_STARTUP_SERVICE, {
      task,
      appendPrompts: opts.appendPrompt ?? [],
      resumeSessionId: opts.resume,
      continueLatest: opts.continue === true,
      name: opts.name,
      outputFormat: opts.outputFormat,
      provider: opts.provider,
      model: opts.model,
      maxTokens: opts.maxTokens,
      effort: opts.effort,
    } satisfies CmdStartupValues)
  })
  parseCmdline(ctx, program)
}
