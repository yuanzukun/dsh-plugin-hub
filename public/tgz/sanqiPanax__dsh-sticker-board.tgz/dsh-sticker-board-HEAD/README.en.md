# dsh-sticker-board

Fridge-magnet sticker board for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) (DSH) Web.

Turn your recurring tasks into fridge magnets pinned above the input box: 📰 24-hour tech news, ⭐ GitHub project picks, 📝 draft checks… grouped **long-term / short-term**. Click a sticker and its preloaded prompt is sent into the **current session** — the AI starts working immediately, no more typing the same task description every time.

![Sticker dock](docs/screenshot-dock.png)

## Why

Some tasks run almost daily at unpredictable times: catching up on tech news, checking GitHub trends, reviewing publish drafts. Typing a long prompt into the composer every time gets old, so this sticker dock exists:

- **Zero-friction start**: the dock sits right above the composer — see it, click it, done. No sidebar, no task setup.
- **Organized by rhythm**: long-term (daily) / short-term (ad hoc), at a glance.
- **Edit in place**: hover a sticker for ✏️ edit / 🗑 delete; changes apply and persist immediately.
- **Ordinary message semantics**: a click sends a normal queued session message — stop it anytime, misclicks cost nothing.

## Install

```sh
# Option 1: GitHub
dsh plugin --profile web add github:sanqiPanax/dsh-sticker-board

# Option 2: local tarball
dsh plugin --profile web add ./dsh-sticker-board-0.1.1.tgz
```

**Restart `dsh web`** (hard-refresh the browser once, Ctrl+F5) and the sticker dock appears above the input box.

> First launch seeds 8 default stickers into `~/.dsh/sticker-board.json` — add, edit and delete as you like.

## Usage

### Click to run

Click any sticker → its prompt is sent to the current session in **queue mode** (a running turn is not interrupted) and the AI gets to work.

### Add a sticker

1. Click the **＋** button at the right end of the dock.
2. Fill in: **emoji**, **label**, **group** (long-term / short-term), and the **prompt** sent to the AI when clicked.
3. Hit **Save** — the sticker appears in its group immediately.

### Edit / delete

Hover any sticker to reveal **✏️ edit** and **🗑 delete**; deletion is confirm-guarded.

### Default stickers

| Group | Sticker | Purpose |
|---|---|---|
| long | 📰 24-hour tech news | Chinese briefing of the last 24h (AI/chips/internet/gaming/hardware) |
| long | ⭐ GitHub project picks | 5 notable GitHub projects with highlights |
| long | 📅 GitHub weekly material | Collect material for the weekly GitHub report (image-rule evaluation) |
| long | ✅ Daily review | Done / in-progress / next-step review |
| short | 📝 X-HEI-GUO draft check | Table-to-PNG / no links / md2docx / check_draft.py checklist |
| short | 📣 WeChat-article check | author / title / image placeholders / table rendering / publish window |
| short | 🐦 X platform statement collection | CDP screenshots of relevant statements |
| short | 🖼️ Image recognition | Describe images and extract text |

The default prompts are drafts for common workflows — tweak them to your own with ✏️.

## How it works

- **Host half** (`lib/index.js`, zero dependencies): sticker CRUD REST API + JSON persistence, seeding the default set on first run:
  - `GET /api/sticker-board/health` — install probe (plugin version + sticker count)
  - `GET /api/sticker-board/stickers` — all stickers
  - `POST /api/sticker-board/stickers` — create
  - `PUT /api/sticker-board/stickers/:id` — update
  - `DELETE /api/sticker-board/stickers/:id` — delete
  - Data lives in `~/.dsh/sticker-board.json`; writes are serialized through a single promise chain so concurrent edits cannot corrupt the file.
- **Client half** (`lib/client.js`): a React component registered into the official `conversation.input.dock` seat (the full-width strip above the composer card — the same seat the official goal plugin uses). Clicking a sticker goes through `ctx.conversation.sendSession(session, prompt, [], 'queue')` — the same host admission path as a manual composer submit.

## Notes

- Sticker prompts are sent as **ordinary queued messages**: they wait for a running turn to finish (use the composer's steer if you need to interrupt).
- Positioned differently from [dsh-task-board](https://github.com/zhu1090093659/dsh-web-ui) (task kanban): this plugin is a **lightweight quick-command dock** — no state machine, cron, or execution history. Use the kanban for scheduled tasks; both can coexist.
- The plugin only reads/writes local JSON; nothing is uploaded anywhere.

## Development

```sh
npm pack                      # build the tarball
dsh plugin --profile web add ./dsh-sticker-board-0.1.1.tgz
```

Bump the `package.json` version before repacking — pnpm caches tarballs by version.

## License

MIT
