# Changelog

All notable changes to dsh-sticker-board are documented here.

## [0.1.1] - 2026-08-16

### Fixed

- Host route registration: `prefix` kind no longer carries a trailing slash,
  which the webserver's `path.startsWith(prefix + "/")` matching never matched
  (caused `/api/sticker-board/*` to 404). Bumped to 0.1.1 to bypass pnpm's
  same-version tgz cache.

### Added

- `GET /api/sticker-board/health` install probe (plugin version + sticker count).
- Retry button on sticker load failure in the dock.

## [0.1.0] - 2026-08-16

### Added

- Fridge-magnet sticker dock in `conversation.input.dock` (full-width strip
  above the composer card), grouped **long-term / short-term**.
- Click a sticker → its preloaded prompt is sent into the current session via
  `ctx.conversation.sendSession(session, prompt, [], 'queue')` — the same host
  admission path as a manual composer submit; a running turn is not
  interrupted.
- Inline management: trailing **＋** opens an add form (emoji / label / group /
  prompt); hovering a sticker reveals ✏️ edit and 🗑 delete (confirm-guarded).
- Host half (`lib/index.js`, zero dependencies): sticker CRUD REST API
  (`GET/POST/PUT/DELETE /api/sticker-board/stickers`) with `~/.dsh/sticker-board.json`
  persistence, serialized writes, and 8 default stickers seeded on first run.
- Client half (`lib/client.js`): React dock component registered via the
  official slot system, locale dictionaries (zh/en), DSH design tokens.
