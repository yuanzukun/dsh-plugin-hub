/**
 * Manifest compatibility guard.
 *
 * Why this exists (docs/LESSONS.md §33): dsh-app-boot's
 * `evaluatePluginCompatibility` checks every `@deepseek-ai/dsh*`
 * peerDependency range against the RUNNING dsh version and **skips the whole
 * bundle** when one does not satisfy it. dsh 0.2.0-rc.2 silently dropped this
 * plugin because the manifest still said `^0.1.5-rc.2` — the plugin vanished
 * from the composition with no build error. This test pins the ranges to the
 * runtime generations the code actually supports, and pins the client
 * `inject` list against services the core has removed.
 *
 * The semver subset implemented here is deliberately small (^, >=, <) — it
 * mirrors only what the manifest and the dsh evaluator use.
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)))
const manifest = JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf8'))
const clientSource = readFileSync(path.join(root, 'lib', 'client.js'), 'utf8')

/** Runtime generations this plugin supports.
 *  Versioning convention (user decision, 2026-10-08): the plugin's MAJOR
 *  tracks the dsh generation — 1.x serves dsh 0.1.x, 2.x serves dsh 0.2.x —
 *  and the peer ranges claim exactly the generation the code was verified on. */
const SUPPORTED_RUNTIMES = ['0.2.0-rc.2']

function parse(version) {
  const [core, pre = ''] = String(version).trim().split('-')
  const [major, minor, patch] = core.split('.').map(Number)
  return { major, minor, patch, pre: pre === '' ? [] : pre.split('.') }
}

function compareIdentifier(a, b) {
  const aNum = /^\d+$/.test(a)
  const bNum = /^\d+$/.test(b)
  if (aNum && bNum) return Number(a) - Number(b)
  if (aNum) return -1
  if (bNum) return 1
  return a < b ? -1 : a > b ? 1 : 0
}

/** Semver precedence, prerelease included. */
function compare(left, right) {
  const a = parse(left)
  const b = parse(right)
  for (const key of ['major', 'minor', 'patch']) {
    if (a[key] !== b[key]) return a[key] - b[key]
  }
  if (a.pre.length === 0 && b.pre.length === 0) return 0
  if (a.pre.length === 0) return 1
  if (b.pre.length === 0) return -1
  for (let index = 0; index < Math.max(a.pre.length, b.pre.length); index += 1) {
    const x = a.pre[index]
    const y = b.pre[index]
    if (x === undefined) return -1
    if (y === undefined) return 1
    const diff = compareIdentifier(x, y)
    if (diff !== 0) return diff
  }
  return 0
}

/** `satisfies` for the comparator subset the manifest uses, prereleases included. */
function satisfies(version, range) {
  for (const raw of String(range).trim().split(/\s+/)) {
    if (raw.startsWith('^')) {
      const base = parse(raw.slice(1))
      const current = parse(version)
      if (compare(version, raw.slice(1)) < 0) return false
      // Caret on 0.x allows only the same minor (npm's rule for 0.x).
      if (base.major === 0 ? current.minor !== base.minor || current.major !== base.major : current.major !== base.major) return false
    } else if (raw.startsWith('>=')) {
      if (compare(version, raw.slice(2)) < 0) return false
    } else if (raw.startsWith('<')) {
      if (compare(version, raw.slice(1)) >= 0) return false
    } else if (raw !== '') {
      throw new Error(`unsupported range token in test helper: ${raw}`)
    }
  }
  return true
}

test('every @deepseek-ai/dsh* peer range covers the supported runtime generations', () => {
  const peers = manifest.peerDependencies ?? {}
  const dshPeers = Object.entries(peers).filter(([name]) => name === '@deepseek-ai/dsh' || name.startsWith('@deepseek-ai/dsh-'))
  assert.ok(dshPeers.length > 0, 'the manifest must declare its dsh peer requirements')
  for (const [name, range] of dshPeers) {
    for (const runtime of SUPPORTED_RUNTIMES) {
      assert.ok(
        satisfies(runtime, range),
        `${name} range "${range}" excludes runtime ${runtime} — dsh-app-boot would skip the whole bundle (LESSONS §33)`
      )
    }
  }
})

test('the old caret-on-0.1 range really does exclude 0.2 — the trap is detected', () => {
  // Documents the exact failure: ^0.1.5-rc.2 never matches 0.2.0-rc.2.
  assert.equal(satisfies('0.2.0-rc.2', '^0.1.5-rc.2'), false)
  assert.equal(satisfies('0.1.5-rc.2', '^0.1.5-rc.2'), true)
})

test('the browser half no longer requires the removed settingsScope service', () => {
  // dsh 0.2 removed ctx.settingsScope; a cordis inject on a missing service
  // keeps the client plugin permanently pending (LESSONS §6/§33).
  const inject = /exports\.inject\s*=\s*\[([^\]]*)\]/.exec(clientSource)
  assert.ok(inject !== null, 'client.js must declare its cordis inject list')
  assert.ok(!/settingsScope/.test(inject[1]), 'the client must not inject the removed settingsScope service')
  assert.ok(/slots/.test(inject[1]), 'the client still needs the slots service')
  assert.ok(!/ctx\.settingsScope\.bind/.test(clientSource), 'client.js must not bind a settings scope')
})

test('the client talks to the host config API instead of the settings transport', () => {
  assert.ok(/fetchJson\("\/config"/.test(clientSource), 'client.js must read the host /config endpoint')
  assert.ok(/createProxyStore/.test(clientSource), 'client.js must build the host-backed config store')
})

test('every settings-write field is declared volatile (dsh 0.2 refuses unmarked writes)', () => {  // dsh-settings' volatileForm()/isVolatilePath() only accept a write whose
  // paths sit under a field whose schema node carries meta.volatile; without
  // it the host answers `Plugin entry "…" has no volatile fields` and every
  // toggle bounces straight back (LESSONS §36).
  const hostSource = readFileSync(path.join(root, 'lib', 'index.js'), 'utf8')
  const written = ['enabled', 'mode', 'customUrl', 'noProxy']
  for (const field of written) {
    assert.ok(
      new RegExp(`${field}: volatile\\(`).test(hostSource),
      `Config field "${field}" is written by the API/tools but is not marked volatile()`
    )
  }
  // systemPollMs is read once at apply time, so it must NOT promise a live edit.
  assert.ok(!/systemPollMs: volatile\(/.test(hostSource), 'systemPollMs must stay a composition-only knob')
})

test('the client store never refreshes from inside subscribe (render-loop guard)', () => {
  // Review fix (LESSONS §40): subscribe was an inline closure recreated every
  // render, so React re-subscribed on every render, each resubscribe fetched
  // /config, each response emitted a fresh snapshot, and the two fed each
  // other — a GET /config per render. Keeping the fetch in an effect with
  // identity-stable callbacks is what breaks that cycle.
  const subscribeBody = /subscribe:\s*function\s*\(fn\)\s*\{([\s\S]{0,200}?)\n\s*\},/.exec(clientSource)
  assert.ok(subscribeBody !== null, 'client.js must expose store.subscribe')
  assert.ok(!/refresh\(\)/.test(subscribeBody[1]), 'store.subscribe must not trigger a refresh')
  assert.ok(
    /useEffect\(function \(\) \{ store\.refresh\(\); \}, \[store\]\)/.test(clientSource),
    'the initial load must live in a mount effect'
  )
  assert.ok(/useCallback\(function \(onChange\)/.test(clientSource), 'subscribe must be identity-stable (useCallback)')
  assert.ok(/unchanged\(snapshot, next\)/.test(clientSource), 'an unchanged payload must not notify subscribers')
})
