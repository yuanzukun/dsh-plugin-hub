/**
 * Unit tests for lib/proxy-core.js — the dependency-free pure logic layer.
 * Run with `npm test` (node --test) — no DSH/runtime required.
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  classifyProbeStatus,
  classifyTargetFailure,
  combineDualProbe,
  composeNoProxy,
  configPayload,
  DEFAULT_ENTRY_ID,
  headNeedsGetRetry,
  keepaliveHint,
  makeSystemProxyReader,
  normalizeProxyUrl,
  parseOverrideEntries,
  parseProxyServer,
  parseRegDword,
  parseRegString,
  readConfigField,
  readProxyConfig,
  resolveEntryId,
  resolveProxyState,
  summarize,
  systemFactsEqual,
} from '../lib/proxy-core.js'

// ---- dsh 0.2 settings model (LESSONS §33/§36) ----------------------------

/** Minimal stand-in for the cordis context identity used by entry-id resolution. */
const fakeFiber = { uid: 'self', entry: { options: { id: 'dsh-proxy-pro' } } }

function fakeConfigEditor(rows) {
  return { configuration: () => rows }
}

/** A resolved volatile field, as cordis hands it to the plugin. */
function volatileRef(value) {
  return { get: () => value }
}

test('resolveEntryId prefers the fiber entry id (documented core idiom)', () => {
  assert.equal(resolveEntryId({ fiber: fakeFiber }, undefined), 'dsh-proxy-pro')
})

test('resolveEntryId falls back to the config-editor row, then the bundle id', () => {
  const ctx = { fiber: { uid: 'self' } } // no entry on the fiber
  const rows = [{ entry: { fiber: ctx.fiber, options: { id: 'custom-row' } }, override: {} }]
  assert.equal(resolveEntryId(ctx, fakeConfigEditor(rows)), 'custom-row')
  assert.equal(resolveEntryId(ctx, fakeConfigEditor([])), DEFAULT_ENTRY_ID)
  assert.equal(resolveEntryId({}, undefined), DEFAULT_ENTRY_ID)
  assert.equal(resolveEntryId({}, { configuration: () => { throw new Error('boom') } }), DEFAULT_ENTRY_ID)
})

test('readConfigField reads Volatile references through .get()', () => {
  assert.equal(readConfigField({ enabled: volatileRef(true) }, 'enabled', false), true)
  assert.equal(readConfigField({ enabled: volatileRef(false) }, 'enabled', true), false)
  // A throwing reference never takes the plugin down.
  assert.equal(readConfigField({ enabled: { get() { throw new Error('gone') } } }, 'enabled', 'fallback'), 'fallback')
})

test('readConfigField also accepts plain values (older cores / unmarked schemas)', () => {
  assert.equal(readConfigField({ enabled: true }, 'enabled', false), true)
  assert.equal(readConfigField({ systemPollMs: 5000 }, 'systemPollMs', 30000), 5000)
  assert.equal(readConfigField({}, 'mode', 'none'), 'none')
})

test('readProxyConfig yields the plain config the tools/client/API consume', () => {
  const live = {
    enabled: volatileRef(true),
    mode: volatileRef('custom'),
    customUrl: volatileRef('http://127.0.0.1:7890'),
    noProxy: volatileRef('a,b'),
    systemPollMs: 30000,
  }
  assert.deepEqual(readProxyConfig(live), {
    enabled: true,
    mode: 'custom',
    customUrl: 'http://127.0.0.1:7890',
    noProxy: 'a,b',
    systemPollMs: 30000,
  })
  // Volatile refs are re-read on every call: a Loader commit is visible at once.
  let flag = false
  const changing = { enabled: { get: () => flag } }
  assert.equal(readProxyConfig(changing).enabled, false)
  flag = true
  assert.equal(readProxyConfig(changing).enabled, true)
})

test('configPayload shapes the client panel payload and never leaks extra fields', () => {
  const payload = configPayload({ enabled: true, mode: 'custom', customUrl: 'http://127.0.0.1:7890', noProxy: 'a,b', systemPollMs: 5000, secret: 'nope' })
  assert.deepEqual(payload, {
    config: { enabled: true, mode: 'custom', customUrl: 'http://127.0.0.1:7890', noProxy: 'a,b', systemPollMs: 5000 },
    writable: true,
  })
  // Schema-validated booleans only: a truthy non-boolean must not switch the UI on.
  assert.equal(configPayload({ enabled: 1 }).config.enabled, false)
  // A composition that cannot persist must not offer enabled controls.
  assert.equal(configPayload({ enabled: true }, false).writable, false)
  assert.deepEqual(configPayload(undefined), {
    config: { enabled: false, mode: 'none', customUrl: '', noProxy: '', systemPollMs: 0 },
    writable: true,
  })
})


test('normalizeProxyUrl accepts bare host:port and http(s) URLs', () => {
  assert.equal(normalizeProxyUrl('127.0.0.1:7890'), 'http://127.0.0.1:7890')
  assert.equal(normalizeProxyUrl('http://proxy.example:8080/'), 'http://proxy.example:8080')
  assert.equal(normalizeProxyUrl('https://proxy.example:8443'), 'https://proxy.example:8443')
})

test('normalizeProxyUrl rejects junk and non-http protocols', () => {
  assert.equal(normalizeProxyUrl(''), null)
  assert.equal(normalizeProxyUrl('   '), null)
  assert.equal(normalizeProxyUrl('socks5://127.0.0.1:1080'), null)
  assert.equal(normalizeProxyUrl('ftp://x'), null)
  assert.equal(normalizeProxyUrl('not a url with spaces'), null)
})

test('parseProxyServer parses single host:port and per-scheme forms', () => {
  assert.deepEqual(parseProxyServer('proxyhk.huawei.com:8080'), {
    http: 'http://proxyhk.huawei.com:8080',
    https: 'http://proxyhk.huawei.com:8080',
  })
  assert.deepEqual(parseProxyServer('http=127.0.0.1:8080;https=127.0.0.1:8443'), {
    http: 'http://127.0.0.1:8080',
    https: 'http://127.0.0.1:8443',
  })
})

test('parseProxyServer ignores socks and rejects unusable input', () => {
  const socksOnly = parseProxyServer('socks=127.0.0.1:1080')
  assert.equal(socksOnly, null)
  assert.equal(parseProxyServer(''), null)
  assert.equal(parseProxyServer('http=not a url'), null)
})

test('parseRegDword / parseRegString decode `reg query` output lines', () => {
  assert.equal(parseRegDword('    ProxyEnable    REG_DWORD    0x1'), 1)
  assert.equal(parseRegDword('    ProxyEnable    REG_DWORD    0x0'), 0)
  assert.equal(parseRegDword('garbage'), undefined)
  assert.equal(parseRegString('    ProxyServer    REG_SZ    127.0.0.1:10808'), '127.0.0.1:10808')
  assert.equal(parseRegString('    ProxyOverride  REG_SZ    <local>;github.com'), '<local>;github.com')
})

test('composeNoProxy merges configured + override, locals always first', () => {
  assert.equal(composeNoProxy('', ''), 'localhost,127.0.0.1,::1')
  assert.equal(composeNoProxy('github.com,localhost', ''), 'localhost,127.0.0.1,::1,github.com')
  assert.equal(composeNoProxy('github.com', '<local>;api.example.com'), 'localhost,127.0.0.1,::1,github.com,api.example.com')
})

test('parseOverrideEntries turns a Windows ProxyOverride string into entries', () => {
  assert.deepEqual(parseOverrideEntries('<local>;api.example.com;*.cn'), ['localhost', '127.0.0.1', '::1', 'api.example.com', '*.cn'])
  assert.deepEqual(parseOverrideEntries(''), [])
})

test('resolveProxyState: disabled / mode-none are inactive', () => {
  assert.equal(resolveProxyState({ enabled: false, mode: 'system', customUrl: 'x', noProxy: '' }, null).active, false)
  const none = resolveProxyState({ enabled: true, mode: 'none', customUrl: '', noProxy: '' }, null)
  assert.equal(none.active, false)
  assert.equal(none.reason, 'mode-none')
})

test('resolveProxyState: system mode follows live facts', () => {
  const facts = { enabled: true, http: 'http://127.0.0.1:7890', https: 'http://127.0.0.1:7890', url: 'http://127.0.0.1:7890', override: '', serverLine: '' }
  const state = resolveProxyState({ enabled: true, mode: 'system', customUrl: '', noProxy: '' }, facts)
  assert.equal(state.active, true)
  assert.equal(state.url, 'http://127.0.0.1:7890')
})

test('resolveProxyState: system mode with proxy off reports its reason', () => {
  const state = resolveProxyState({ enabled: true, mode: 'system', customUrl: '', noProxy: '' }, { enabled: false, http: null, https: null, url: null, override: '', serverLine: '' })
  assert.equal(state.active, false)
  assert.equal(state.reason, 'system-proxy-off')
})

test('resolveProxyState: custom mode uses the custom address', () => {
  const state = resolveProxyState({ enabled: true, mode: 'custom', customUrl: 'http://127.0.0.1:7890', noProxy: '' }, null)
  assert.equal(state.active, true)
  assert.equal(state.url, 'http://127.0.0.1:7890')
})

test('resolveProxyState: invalid custom address is inactive with a reason', () => {
  const state = resolveProxyState({ enabled: true, mode: 'custom', customUrl: 'not a url', noProxy: '' }, null)
  assert.equal(state.active, false)
  assert.equal(state.reason, 'invalid-custom-url')
})

test('resolveProxyState: custom mode keeps only its own NO_PROXY (never the system override)', () => {
  const facts = { enabled: true, url: 'http://system:8080', http: 'http://system:8080', https: 'http://system:8080', override: '<local>;internal.corp', serverLine: '' }
  const state = resolveProxyState({ enabled: true, mode: 'custom', customUrl: 'http://127.0.0.1:7890', noProxy: '' }, facts)
  assert.equal(state.active, true)
  assert.equal(state.url, 'http://127.0.0.1:7890')
  assert.equal(state.noProxy, 'localhost,127.0.0.1,::1')
  assert.ok(!state.noProxy.includes('internal.corp'))
})

test('resolveProxyState: system mode merges the Windows ProxyOverride into NO_PROXY', () => {
  const facts = { enabled: true, url: 'http://system:8080', http: 'http://system:8080', https: 'http://system:8080', override: '<local>;internal.corp;*.cn', serverLine: '' }
  const state = resolveProxyState({ enabled: true, mode: 'system', customUrl: '', noProxy: '' }, facts)
  assert.equal(state.active, true)
  assert.equal(state.noProxy, 'localhost,127.0.0.1,::1,internal.corp,*.cn')
})

test('summarize exposes the fields the tools and API promise', () => {
  const snapshot = {
    config: { enabled: true, mode: 'custom', customUrl: 'http://127.0.0.1:7890', noProxy: '' },
    effective: { active: true, url: 'http://127.0.0.1:7890', http: 'http://127.0.0.1:7890', https: 'http://127.0.0.1:7890', noProxy: 'localhost', reason: null },
    systemProxy: null,
    at: '2026-09-17T00:00:00.000Z',
  }
  const s = summarize(snapshot)
  assert.equal(s.active, true)
  assert.equal(s.enabled, true)
  assert.equal(s.mode, 'custom')
  assert.equal(s.url, 'http://127.0.0.1:7890')
  assert.equal(s.source, 'custom')
  assert.ok(typeof s.at === 'string')
})

test('systemFactsEqual treats identical facts as equal', () => {
  const a = { enabled: true, url: 'http://x', http: 'http://x', https: 'http://x', override: '', serverLine: '' }
  const b = { enabled: true, url: 'http://x', http: 'http://x', https: 'http://x', override: '', serverLine: '' }
  const c = { enabled: false, url: null, http: null, https: null, override: '', serverLine: '' }
  assert.equal(systemFactsEqual(a, b), true)
  assert.equal(systemFactsEqual(a, c), false)
})

test('systemFactsEqual: http/https-only differences are unequal (drive re-sync + effKey rebuild)', () => {
  const base = { enabled: true, url: 'http://x:8080', http: 'http://x:8080', https: 'http://x:8080', override: '', serverLine: '' }
  const httpsChanged = { enabled: true, url: 'http://x:8080', http: 'http://x:8080', https: 'http://x:8443', override: '', serverLine: '' }
  const httpChanged = { enabled: true, url: 'http://y:8080', http: 'http://y:8080', https: 'http://x:8080', override: '', serverLine: '' }
  assert.equal(systemFactsEqual(base, httpsChanged), false)
  assert.equal(systemFactsEqual(base, httpChanged), false)
})

test('keepaliveHint only fires on 407/NTLM signals and uses the given proxy URL', () => {
  assert.ok(keepaliveHint('407 Proxy Authentication Required', 'http://127.0.0.1:7890').length > 0)
  assert.ok(keepaliveHint('ECONNREFUSED').length === 0)
})

test('keepaliveHint prefers the caller-provided proxy over a neutral placeholder', () => {
  const hint = keepaliveHint('407 Proxy Authentication Required', 'http://127.0.0.1:7890')
  assert.ok(hint.includes('http://127.0.0.1:7890'))
  const fallback = keepaliveHint('407 Proxy Authentication Required')
  assert.ok(fallback.includes('localhost'))
  assert.ok(!fallback.includes('proxyhk'))
})

test('makeSystemProxyReader queries reg via execFile', async () => {
  const calls = []
  const execFile = async (file, args) => {
    calls.push(args.join(' '))
    if (String(args).includes('ProxyEnable')) return { stdout: '\r\n    ProxyEnable    REG_DWORD    0x1\r\n\r\n' }
    throw new Error('no such value')
  }
  const reader = makeSystemProxyReader(execFile)
  const facts = await reader()
  assert.equal(facts.enabled, true)
  assert.ok(calls.length >= 3)
})

test('classifyTargetFailure names the connection code and stays actionable', () => {
  const dns = classifyTargetFailure({ cause: { code: 'ENOTFOUND' } })
  assert.equal(dns.kind, 'unreachable')
  assert.equal(dns.verdict, 'unusable')
  assert.match(dns.short, /ENOTFOUND/)
  assert.ok(dns.why.length > 0)
  assert.ok(dns.fix.length > 0)
  const refused = classifyTargetFailure({ cause: { code: 'ECONNREFUSED' } })
  assert.equal(refused.kind, 'unreachable')
  assert.match(refused.short, /ECONNREFUSED/)
})

test('classifyTargetFailure flags a mixed-undici dispatcher rejection', () => {
  const verdict = classifyTargetFailure({
    message: 'fetch failed',
    cause: { code: 'UND_ERR_INVALID_ARG', message: 'invalid onRequestStart method' },
  })
  assert.equal(verdict.kind, 'dispatcher')
  assert.match(verdict.short, /UND_ERR_INVALID_ARG/)
  assert.match(verdict.short, /混用/)
  // the message is enough even when the code is missing
  assert.equal(classifyTargetFailure({ cause: { message: 'invalid onRequestStart method' } }).kind, 'dispatcher')
})

test('classifyTargetFailure keeps the cause detail instead of a bare "fetch failed"', () => {
  const reset = classifyTargetFailure({ message: 'fetch failed', cause: { code: 'ECONNRESET', message: 'socket hang up' } })
  assert.equal(reset.kind, 'unreachable')
  assert.match(reset.short, /ECONNRESET/)
  const unknown = classifyTargetFailure({ message: 'fetch failed', cause: { code: 'EUNKNOWNCODE', message: 'mystery' } })
  assert.equal(unknown.kind, 'other')
  assert.match(unknown.short, /fetch failed/)
  assert.match(unknown.short, /EUNKNOWNCODE/)
})

test('classifyTargetFailure detects an NTLM proxy demand and probe aborts', () => {
  assert.equal(classifyTargetFailure({ message: 'HTTP 407 proxy authentication required' }).kind, 'auth')
  assert.equal(classifyTargetFailure({ message: 'HTTP 407 — the proxy asks for authentication' }).kind, 'auth')
  const timeout = classifyTargetFailure({ name: 'AbortError', message: 'This operation was aborted' })
  assert.equal(timeout.kind, 'unreachable')
  assert.match(timeout.short, /超时/)
})

test('classifyProbeStatus: 2xx/3xx and 401 are usable', () => {
  for (const code of [200, 204, 301, 302]) {
    const v = classifyProbeStatus(code)
    assert.equal(v.ok, true)
    assert.equal(v.verdict, 'usable')
    assert.equal(v.status, code)
    assert.equal(v.why, '')
    assert.equal(v.fix, '')
  }
  const auth = classifyProbeStatus(401)
  assert.equal(auth.ok, true)
  assert.equal(auth.verdict, 'usable')
  assert.match(auth.short, /401/)
})

test('classifyProbeStatus: 4xx is degraded with a cause and a fix', () => {
  for (const code of [403, 404, 405, 429, 418]) {
    const v = classifyProbeStatus(code)
    assert.equal(v.ok, false)
    assert.equal(v.verdict, 'degraded')
    assert.ok(v.why.length > 0, `why missing for ${code}`)
    assert.ok(v.fix.length > 0, `fix missing for ${code}`)
  }
  assert.match(classifyProbeStatus(405).short, /HEAD/)
  assert.match(classifyProbeStatus(404).short, /404/)
})

test('headNeedsGetRetry: a HEAD 404 must be retried with GET (网关的 HEAD 陷阱)', () => {
  for (const code of [404, 405, 501]) {
    assert.equal(headNeedsGetRetry(code), true, `HEAD ${code} should retry with GET`)
  }
  for (const code of [200, 204, 301, 401, 403, 407, 429, 500, 502, 503, 504]) {
    assert.equal(headNeedsGetRetry(code), false, `HEAD ${code} should not retry`)
  }
})

test('classifyProbeStatus: a double 404 points at the real endpoint, not the network', () => {
  const v = classifyProbeStatus(404)
  assert.match(v.why, /GET/)
  assert.match(v.fix, /端点/)
})

test('classifyProbeStatus: gateway and server errors are unusable, not "reachable"', () => {
  for (const code of [500, 502, 503, 504]) {
    const v = classifyProbeStatus(code)
    assert.equal(v.ok, false)
    assert.equal(v.verdict, 'unusable')
    assert.match(v.short, new RegExp(String(code)))
    assert.ok(v.why.length > 0 && v.fix.length > 0)
  }
  // the regression this classification exists for: 504 used to print as reachable
  const timeout = classifyProbeStatus(504)
  assert.equal(timeout.verdict, 'unusable')
  assert.match(timeout.why, /上游|超时/)
})

test('classifyProbeStatus: 407 is unusable and names the proxy auth wall', () => {
  const v = classifyProbeStatus(407)
  assert.equal(v.ok, false)
  assert.equal(v.verdict, 'unusable')
  assert.equal(v.kind, 'auth')
  assert.match(v.short, /407/)
  assert.match(v.fix, /curl/)
})

test('combineDualProbe: both legs OK → both-ok, green badges, keep current policy', () => {
  const proxy = classifyProbeStatus(200)
  const direct = classifyProbeStatus(200)
  const c = combineDualProbe(proxy, direct)
  assert.equal(c.verdict, 'both-ok')
  assert.equal(c.proxyBadge.tone, 'ok')
  assert.equal(c.directBadge.tone, 'ok')
  assert.match(c.fix, /保持当前策略/)
})

test('combineDualProbe: only proxy works → proxy-only (domain needs the proxy)', () => {
  const proxy = classifyProbeStatus(200)
  const direct = { ok: false, verdict: 'unusable', kind: 'unreachable', short: '直连不可达（EACCES）' }
  const c = combineDualProbe(proxy, direct)
  assert.equal(c.verdict, 'proxy-only')
  assert.equal(c.proxyBadge.tone, 'ok')
  assert.equal(c.directBadge.tone, 'bad')
  assert.match(c.fix, /NO_PROXY/)
})

test('combineDualProbe: direct OK + proxy 403 → direct-only with WARN proxy badge (链路通·被拒绝, 不是被拦死)', () => {
  const proxy = classifyProbeStatus(403)
  const direct = classifyProbeStatus(200)
  const c = combineDualProbe(proxy, direct)
  assert.equal(c.verdict, 'direct-only')
  assert.equal(c.proxyBadge.tone, 'warn')
  assert.match(c.proxyBadge.text, /被拒绝|链路通/)
  assert.equal(c.directBadge.tone, 'ok')
  // 403 是"到达目标被拒绝"，绝不能说是代理链路不通
  assert.match(c.why, /到达目标|被拒绝/)
  assert.match(c.fix, /NO_PROXY/)
})

test('combineDualProbe: proxy 407 + direct OK → direct-only-auth (do not fight NTLM)', () => {
  const proxy = classifyProbeStatus(407)
  const direct = classifyProbeStatus(200)
  const c = combineDualProbe(proxy, direct)
  assert.equal(c.verdict, 'direct-only-auth')
  assert.match(c.proxyBadge.text, /认证/)
  assert.equal(c.proxyBadge.tone, 'bad')
  assert.match(c.fix, /NO_PROXY/)
})

test('combineDualProbe: 核心回归——proxy 404 + direct EACCES → proxy-only, proxy 徽章为黄(链路通·路径不存在)', () => {
  // 用户实测（2026-09-18）：api.copilot.tencent.com/api/v1 走代理 404、直连 EACCES，
  // 旧逻辑误判 "代理与直连均失败(both-bad)"；正确是"只有走代理能到目标，目标 404=路径问题"。
  const proxy = classifyProbeStatus(404)
  const direct = { ok: false, verdict: 'unusable', kind: 'unreachable', short: '直连不可达（EACCES）—需要走代理' }
  const c = combineDualProbe(proxy, direct)
  assert.equal(c.verdict, 'proxy-only')
  assert.equal(c.proxyBadge.tone, 'warn')
  assert.match(c.proxyBadge.text, /链路通/)
  assert.match(c.proxyBadge.text, /路径不存在|拒绝/)
  assert.equal(c.directBadge.tone, 'bad')
  assert.match(c.short, /代理/)
  assert.equal(c.why.includes('只有代理通道能到达'), true)
})

test('combineDualProbe: both degraded (404+404) → both-reached, 双黄徽章, 指路真实端点', () => {
  const proxy = classifyProbeStatus(404)
  const direct = classifyProbeStatus(404)
  const c = combineDualProbe(proxy, direct)
  assert.equal(c.verdict, 'both-reached')
  assert.equal(c.proxyBadge.tone, 'warn')
  assert.equal(c.directBadge.tone, 'warn')
  assert.match(c.fix, /models|chat\/completions|端点/)
})

test('combineDualProbe: both legs fail with connection errors → both-bad, both badges bad', () => {
  const proxy = { ok: false, verdict: 'unusable', kind: 'unreachable', short: '连接被拒绝（ECONNREFUSED）' }
  const direct = { ok: false, verdict: 'unusable', kind: 'unreachable', short: '超时前无应答（ETIMEDOUT）' }
  const c = combineDualProbe(proxy, direct)
  assert.equal(c.verdict, 'both-bad')
  assert.equal(c.proxyBadge.tone, 'bad')
  assert.equal(c.directBadge.tone, 'bad')
  assert.match(c.fix, /与代理开关无关/)
})

test('combineDualProbe: proxy 504 + direct timeout → both-bad 但代理徽章 warn(链路通·网关报错), 不是 red 链路不通', () => {
  const proxy = classifyProbeStatus(504)
  const direct = { ok: false, verdict: 'unusable', kind: 'unreachable', short: '超时前无应答（ETIMEDOUT）' }
  const c = combineDualProbe(proxy, direct)
  assert.equal(c.verdict, 'both-bad')
  assert.equal(c.proxyBadge.tone, 'warn')
  assert.match(c.proxyBadge.text, /链路通|网关/)
  assert.equal(c.directBadge.tone, 'bad')
})

test('combineDualProbe: proxy OK + direct 404 → proxy-only, 直连徽章 warn(链路通·路径不存在)', () => {
  const proxy = classifyProbeStatus(200)
  const direct = classifyProbeStatus(404)
  const c = combineDualProbe(proxy, direct)
  assert.equal(c.verdict, 'proxy-only')
  assert.equal(c.proxyBadge.tone, 'ok')
  assert.equal(c.directBadge.tone, 'warn')
  assert.match(c.directBadge.text, /链路通/)
})