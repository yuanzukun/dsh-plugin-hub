import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  defaultDesktopAuthCandidates,
  desktopAuthCandidatesFor,
  parseWorkBuddyAuth,
  WorkBuddyCredentialStore,
  WORKBUDDY_AUTH_FILE_ENV,
} from '../src/credential/store.ts'
import { AI_VARIANT, CN_VARIANT } from '../src/variants.ts'

// node:os's ESM namespace rejects vi.spyOn (non-configurable), so homedir is
// mocked at the module level; unset state falls through to the real one.
const fakeOs = vi.hoisted(() => ({
  home: undefined as string | undefined,
  release: undefined as string | undefined,
}))
vi.mock('node:os', async (importOriginal) => {
  const actual = await importOriginal<typeof import('node:os')>()
  return {
    ...actual,
    homedir: () => fakeOs.home ?? actual.homedir(),
    release: () => fakeOs.release ?? actual.release(),
  }
})

const CLEANUP: (() => Promise<void>)[] = []

afterEach(async () => {
  await Promise.all(CLEANUP.splice(0).map((clean) => clean()))
  vi.unstubAllEnvs()
})

function nestedDoc(expiresAt: number): string {
  return JSON.stringify({
    auth: { accessToken: 'at', refreshToken: 'rt', expiresAt, domain: 'www.codebuddy.cn' },
    account: { uid: 'uid-1', enterpriseId: 'ent-1', nickname: '昵称' },
  })
}

describe('parseWorkBuddyAuth', () => {
  it('reads the desktop nested form with millisecond expiry', () => {
    const credential = parseWorkBuddyAuth(nestedDoc(1_792_128_236_868))
    expect(credential?.accessToken).toBe('at')
    expect(credential?.refreshToken).toBe('rt')
    expect(credential?.expiresAtMs).toBe(1_792_128_236_868)
    expect(credential?.uid).toBe('uid-1')
    expect(credential?.enterpriseId).toBe('ent-1')
    expect(credential?.nickname).toBe('昵称')
  })

  it('normalizes second-precision expiry to milliseconds', () => {
    const credential = parseWorkBuddyAuth(nestedDoc(1_792_128_236))
    expect(credential?.expiresAtMs).toBe(1_792_128_236_000)
  })

  it('reads the flat panel form', () => {
    const credential = parseWorkBuddyAuth(
      JSON.stringify({
        accessToken: 'at',
        refreshToken: 'rt',
        expiresAt: 0,
        domain: '',
        uid: 'uid-2',
      }),
    )
    expect(credential?.accessToken).toBe('at')
    expect(credential?.uid).toBe('uid-2')
    expect(credential?.expiresAtMs).toBe(0)
  })

  it('rejects documents without an access token', () => {
    expect(parseWorkBuddyAuth('{}')).toBeUndefined()
    expect(parseWorkBuddyAuth('not json')).toBeUndefined()
    expect(parseWorkBuddyAuth(JSON.stringify({ auth: { refreshToken: 'rt' } }))).toBeUndefined()
  })
})

describe('WorkBuddyCredentialStore', () => {
  it('serves a fresh desktop credential without refreshing', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'wb-store-'))
    CLEANUP.push(() => rm(dir, { recursive: true, force: true }))
    const desktop = join(dir, 'workbuddy-desktop.info')
    await writeFile(desktop, nestedDoc(Date.now() + 3600_000))
    let refreshes = 0
    const store = new WorkBuddyCredentialStore({
      desktopPath: desktop,
      ownPath: join(dir, 'own.json'),
      refresh: async () => {
        refreshes += 1
        return { accessToken: 'new' }
      },
    })
    await expect(store.resolve()).resolves.toMatchObject({ accessToken: 'at', source: 'desktop' })
    expect(refreshes).toBe(0)
  })

  it('refreshes an expiring credential, persists the copy, and serves it next', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'wb-store-'))
    CLEANUP.push(() => rm(dir, { recursive: true, force: true }))
    const desktop = join(dir, 'workbuddy-desktop.info')
    const own = join(dir, 'own.json')
    await writeFile(desktop, nestedDoc(Date.now() - 1000))
    const store = new WorkBuddyCredentialStore({
      desktopPath: desktop,
      ownPath: own,
      refresh: async () => ({ accessToken: 'fresh', refreshToken: 'rt2', expiresInSec: 3600 }),
    })
    await expect(store.resolve()).resolves.toMatchObject({ accessToken: 'fresh', source: 'dsh' })
    const saved = JSON.parse(await readFile(own, 'utf8')) as {
      version: number
      credential: { accessToken: string }
    }
    expect(saved.version).toBe(1)
    expect(saved.credential.accessToken).toBe('fresh')
    await expect(store.resolve()).resolves.toMatchObject({ accessToken: 'fresh' })
  })

  it('still returns a not-yet-expired token when refresh fails', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'wb-store-'))
    CLEANUP.push(() => rm(dir, { recursive: true, force: true }))
    const desktop = join(dir, 'workbuddy-desktop.info')
    await writeFile(desktop, nestedDoc(Date.now() + 60_000))
    const store = new WorkBuddyCredentialStore({
      desktopPath: desktop,
      ownPath: join(dir, 'own.json'),
      refreshMarginMs: 5 * 60_000,
      refresh: async () => {
        throw new Error('refresh endpoint down')
      },
    })
    await expect(store.resolve()).resolves.toMatchObject({ accessToken: 'at' })
  })

  it('serves the persisted copy with its expiry and identity after the desktop file disappears', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'wb-store-'))
    CLEANUP.push(() => rm(dir, { recursive: true, force: true }))
    const desktop = join(dir, 'workbuddy-desktop.info')
    const own = join(dir, 'own.json')
    await writeFile(desktop, nestedDoc(Date.now() - 1000))
    let refreshes = 0
    const store = new WorkBuddyCredentialStore({
      desktopPath: desktop,
      ownPath: own,
      refresh: async () => {
        refreshes += 1
        return { accessToken: 'fresh', refreshToken: 'rt2', expiresInSec: 3600 }
      },
    })
    await expect(store.resolve()).resolves.toMatchObject({ accessToken: 'fresh', source: 'dsh' })
    await rm(desktop)
    const survived = await store.resolve()
    expect(refreshes).toBe(1)
    expect(survived).toMatchObject({
      accessToken: 'fresh',
      uid: 'uid-1',
      enterpriseId: 'ent-1',
      nickname: '昵称',
      source: 'dsh',
    })
    expect(survived.expiresAtMs).toBeGreaterThan(Date.now() + 3000_000)
  })

  it('rejects an owned copy from another format version', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'wb-store-'))
    CLEANUP.push(() => rm(dir, { recursive: true, force: true }))
    const own = join(dir, 'own.json')
    await writeFile(own, JSON.stringify({ version: 99, credential: { accessToken: 'at' } }))
    const store = new WorkBuddyCredentialStore({
      desktopPath: join(dir, 'missing.info'),
      ownPath: own,
      refresh: async (credential) => ({ accessToken: credential.accessToken }),
    })
    await expect(store.resolve()).rejects.toThrow(/no signed-in WorkBuddy account/)
  })

  it('fails loudly when nothing is signed in', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'wb-store-'))
    CLEANUP.push(() => rm(dir, { recursive: true, force: true }))
    const store = new WorkBuddyCredentialStore({
      desktopPath: join(dir, 'missing.info'),
      ownPath: join(dir, 'own.json'),
      refresh: async (credential) => ({ accessToken: credential.accessToken }),
    })
    await expect(store.resolve()).rejects.toThrow(/no signed-in WorkBuddy account/)
  })

  it('applies a desktop-path repoint on the next read', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'wb-store-'))
    CLEANUP.push(() => rm(dir, { recursive: true, force: true }))
    const first = join(dir, 'workbuddy-a.info')
    const second = join(dir, 'workbuddy-b.info')
    await writeFile(first, nestedDoc(Date.now() + 3600_000))
    await writeFile(
      second,
      JSON.stringify({
        auth: {
          accessToken: 'at-b',
          refreshToken: 'rt',
          expiresAt: Date.now() + 7200_000,
          domain: '',
        },
        account: { uid: 'uid-b', nickname: 'B' },
      }),
    )
    const store = new WorkBuddyCredentialStore({
      desktopPath: first,
      ownPath: join(dir, 'own.json'),
      refresh: async (credential) => ({ accessToken: credential.accessToken }),
    })
    await expect(store.resolve()).resolves.toMatchObject({ accessToken: 'at' })
    store.setDesktopPath(second)
    expect(store.desktopAuthPath()).toBe(second)
    await expect(store.resolve()).resolves.toMatchObject({ accessToken: 'at-b', nickname: 'B' })
  })
})

describe('Windows default desktop path probing', () => {
  function windowsDoc(token: string): string {
    return JSON.stringify({
      auth: {
        accessToken: token,
        refreshToken: 'rt',
        expiresAt: Date.now() + 3600_000,
        domain: 'www.codebuddy.cn',
      },
      account: { uid: 'uid-w', nickname: 'Win 用户' },
    })
  }

  /** Fake a win32 home; probes are mocked in, dirs under a temp root. */
  async function fakeWindowsHome(): Promise<{ home: string; local: string; roaming: string }> {
    const home = await mkdtemp(join(tmpdir(), 'wb-win-'))
    CLEANUP.push(() => rm(home, { recursive: true, force: true }))
    const local = join(
      home,
      'AppData',
      'Local',
      'CodeBuddyExtension',
      'Data',
      'Public',
      'auth',
      'workbuddy-desktop.info',
    )
    const roaming = join(
      home,
      'AppData',
      'Roaming',
      'CodeBuddyExtension',
      'Data',
      'Public',
      'auth',
      'workbuddy-desktop.info',
    )
    return { home, local, roaming }
  }

  /** Run the case body as win32 with the given home; restore on exit. */
  async function asWindows<T>(home: string, run: () => Promise<T>): Promise<T> {
    const savedPlatform = process.platform
    const savedEnv = process.env[WORKBUDDY_AUTH_FILE_ENV]
    delete process.env[WORKBUDDY_AUTH_FILE_ENV]
    fakeOs.home = home
    Object.defineProperty(process, 'platform', { value: 'win32', configurable: true })
    try {
      return await run()
    } finally {
      Object.defineProperty(process, 'platform', { value: savedPlatform, configurable: true })
      fakeOs.home = undefined
      if (savedEnv === undefined) delete process.env[WORKBUDDY_AUTH_FILE_ENV]
      else process.env[WORKBUDDY_AUTH_FILE_ENV] = savedEnv
    }
  }

  it('lists Local before Roaming on win32', async () => {
    const { home, local, roaming } = await fakeWindowsHome()
    await asWindows(home, async () => {
      const candidates = defaultDesktopAuthCandidates()
      expect(candidates).toEqual([local, roaming])
    })
  })

  it('reads the Local AppData file when only it exists', async () => {
    const { home, local } = await fakeWindowsHome()
    await mkdir(join(local, '..'), { recursive: true })
    await writeFile(local, windowsDoc('at-local'))
    await asWindows(home, async () => {
      const store = new WorkBuddyCredentialStore({
        ownPath: join(home, 'own.json'),
        refresh: async (credential) => ({ accessToken: credential.accessToken }),
      })
      await expect(store.resolve()).resolves.toMatchObject({
        accessToken: 'at-local',
        source: 'desktop',
      })
      await expect(store.desktopFilePresent()).resolves.toBe(true)
    })
  })

  it('falls back to Roaming when only it exists (older desktop builds)', async () => {
    const { home, roaming } = await fakeWindowsHome()
    await mkdir(join(roaming, '..'), { recursive: true })
    await writeFile(roaming, windowsDoc('at-roaming'))
    await asWindows(home, async () => {
      const store = new WorkBuddyCredentialStore({
        ownPath: join(home, 'own.json'),
        refresh: async (credential) => ({ accessToken: credential.accessToken }),
      })
      await expect(store.resolve()).resolves.toMatchObject({
        accessToken: 'at-roaming',
        source: 'desktop',
      })
      await expect(store.desktopFilePresent()).resolves.toBe(true)
    })
  })

  it('prefers Local when both exist', async () => {
    const { home, local, roaming } = await fakeWindowsHome()
    await mkdir(join(local, '..'), { recursive: true })
    await mkdir(join(roaming, '..'), { recursive: true })
    await writeFile(local, windowsDoc('at-local'))
    await writeFile(roaming, windowsDoc('at-roaming'))
    await asWindows(home, async () => {
      const store = new WorkBuddyCredentialStore({
        ownPath: join(home, 'own.json'),
        refresh: async (credential) => ({ accessToken: credential.accessToken }),
      })
      await expect(store.resolve()).resolves.toMatchObject({ accessToken: 'at-local' })
    })
  })

  it('reports signed-out and lists both candidates when neither exists', async () => {
    const { home, local } = await fakeWindowsHome()
    await asWindows(home, async () => {
      const store = new WorkBuddyCredentialStore({
        ownPath: join(home, 'own.json'),
        refresh: async (credential) => ({ accessToken: credential.accessToken }),
      })
      await expect(store.status()).resolves.toMatchObject({ state: 'signed-out' })
      await expect(store.desktopFilePresent()).resolves.toBe(false)
      await expect(store.resolve()).rejects.toThrow(
        new RegExp(local.replaceAll(/[.*+?^${}()|[\]\\]/g, String.raw`\$&`)),
      )
      await expect(store.resolve()).rejects.toThrow(/AppData.*Local[\s\S]*AppData.*Roaming/)
    })
  })

  it('uses an explicit desktopPath verbatim without probing on win32', async () => {
    const { home, local, roaming } = await fakeWindowsHome()
    const explicit = join(home, 'explicit.info')
    await mkdir(join(local, '..'), { recursive: true })
    await writeFile(local, windowsDoc('at-local'))
    await writeFile(explicit, windowsDoc('at-explicit'))
    await asWindows(home, async () => {
      const store = new WorkBuddyCredentialStore({
        desktopPath: explicit,
        ownPath: join(home, 'own.json'),
        refresh: async (credential) => ({ accessToken: credential.accessToken }),
      })
      await expect(store.resolve()).resolves.toMatchObject({ accessToken: 'at-explicit' })
      expect(store.desktopAuthPath()).toBe(explicit)
      void roaming
    })
  })
})

describe('WSL default desktop path probing', () => {
  const AUTH_TAIL = join('CodeBuddyExtension', 'Data', 'Public', 'auth', 'workbuddy-desktop.info')

  /**
   * The env this suite manages. XDG bases belong here even though a WSL host
   * does not normally set them: the *test runner* may (CI exports
   * `XDG_CONFIG_HOME=/home/runner/.config`), and leaving that in place makes
   * the Linux half of the candidate list depend on the machine running the
   * tests — which is exactly what happened on CI.
   */
  const WSL_MANAGED_ENV = [
    'APPDATA',
    'LOCALAPPDATA',
    'USERPROFILE',
    'WSL_DISTRO_NAME',
    'WSL_INTEROP',
    'XDG_CONFIG_HOME',
    'XDG_DATA_HOME',
  ] as const

  async function asWsl<T>(
    options: {
      home: string
      env?: Partial<Record<(typeof WSL_MANAGED_ENV)[number], string>>
    },
    run: () => Promise<T>,
  ): Promise<T> {
    const savedPlatform = process.platform
    const savedEnv = Object.fromEntries(WSL_MANAGED_ENV.map((name) => [name, process.env[name]]))
    Object.defineProperty(process, 'platform', { value: 'linux', configurable: true })
    fakeOs.home = options.home
    fakeOs.release = '6.6.87.2-microsoft-standard-WSL2'
    for (const name of WSL_MANAGED_ENV) delete process.env[name]
    Object.assign(process.env, options.env)
    try {
      return await run()
    } finally {
      Object.defineProperty(process, 'platform', { value: savedPlatform, configurable: true })
      fakeOs.home = undefined
      fakeOs.release = undefined
      for (const [name, value] of Object.entries(savedEnv)) {
        if (value === undefined) delete process.env[name]
        else process.env[name] = value
      }
    }
  }

  /** Run with the platform stubbed to a plain (non-WSL) Linux and a fixed home. */
  async function asLinux<T>(
    options: {
      home: string
      env?: Record<string, string>
    },
    run: () => Promise<T>,
  ): Promise<T> {
    const savedPlatform = process.platform
    const managed = ['XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'WSL_DISTRO_NAME', 'WSL_INTEROP']
    const savedEnv = Object.fromEntries(managed.map((name) => [name, process.env[name]]))
    Object.defineProperty(process, 'platform', { value: 'linux', configurable: true })
    fakeOs.home = options.home
    fakeOs.release = '6.12.0-generic'
    for (const name of managed) delete process.env[name]
    Object.assign(process.env, options.env)
    try {
      return await run()
    } finally {
      Object.defineProperty(process, 'platform', { value: savedPlatform, configurable: true })
      fakeOs.home = undefined
      fakeOs.release = undefined
      for (const [name, value] of Object.entries(savedEnv)) {
        if (value === undefined) delete process.env[name]
        else process.env[name] = value
      }
    }
  }

  it('probes the matching mounted Windows profile before the Linux paths', async () => {
    await asWsl({ home: '/home/alice' }, async () => {
      expect(defaultDesktopAuthCandidates()).toEqual([
        join('/mnt/c/Users/alice/AppData/Local', AUTH_TAIL),
        join('/mnt/c/Users/alice/AppData/Roaming', AUTH_TAIL),
        join('/home/alice/.config', AUTH_TAIL),
        join('/home/alice/.local/share', AUTH_TAIL),
      ])
    })
  })

  it('probes both XDG bases on native Linux, config home before data home', async () => {
    await asLinux({ home: '/home/alice' }, async () => {
      expect(defaultDesktopAuthCandidates()).toEqual([
        join('/home/alice/.config', AUTH_TAIL),
        join('/home/alice/.local/share', AUTH_TAIL),
      ])
    })
  })

  it('honors non-empty absolute XDG overrides and falls back on invalid values', async () => {
    await asLinux(
      {
        home: '/home/alice',
        env: { XDG_CONFIG_HOME: '/custom/config', XDG_DATA_HOME: '/custom/data' },
      },
      async () => {
        expect(defaultDesktopAuthCandidates()).toEqual([
          join('/custom/config', AUTH_TAIL),
          join('/custom/data', AUTH_TAIL),
        ])
      },
    )
    // A relative override is not a path the XDG spec allows, so it must not
    // be joined onto: both bases fall back to their defaults.
    await asLinux(
      {
        home: '/home/alice',
        env: { XDG_CONFIG_HOME: 'relative/config', XDG_DATA_HOME: '  ' },
      },
      async () => {
        expect(defaultDesktopAuthCandidates()).toEqual([
          join('/home/alice/.config', AUTH_TAIL),
          join('/home/alice/.local/share', AUTH_TAIL),
        ])
      },
    )
  })

  it('swaps only the basename for the AI variant and still honors the env override', async () => {
    await asLinux({ home: '/home/alice' }, async () => {
      const aiTail = join(
        'CodeBuddyExtension',
        'Data',
        'Public',
        'auth',
        'workbuddy-desktop-ai.info',
      )
      expect(desktopAuthCandidatesFor(AI_VARIANT)).toEqual([
        join('/home/alice/.config', aiTail),
        join('/home/alice/.local/share', aiTail),
      ])
      // The explicit env override outranks every default candidate.
      vi.stubEnv(AI_VARIANT.env, '/explicit/ai-credential.info')
      const store = new WorkBuddyCredentialStore({
        variant: AI_VARIANT,
        ownPath: '/tmp/own.json',
        refresh: async (credential) => ({ accessToken: credential.accessToken }),
      })
      expect(store.desktopAuthPath()).toBe('/explicit/ai-credential.info')
    })
  })

  it.skipIf(process.platform === 'win32')(
    'skips an empty config-home file and resolves to the data-home credential',
    async () => {
      // The probe treats an empty file as absent and moves on; the resolved-path
      // diagnostic must agree, or doctor would name the empty config-home file
      // while authentication actually uses the data-home candidate.
      const root = await mkdtemp(join(tmpdir(), 'wb-xdg-empty-'))
      CLEANUP.push(() => rm(root, { recursive: true, force: true }))
      const configHome = join(root, 'config')
      const dataHome = join(root, 'data')
      const configAuth = join(configHome, 'CodeBuddyExtension', 'Data', 'Public', 'auth')
      const dataAuth = join(dataHome, 'CodeBuddyExtension', 'Data', 'Public', 'auth')
      await mkdir(configAuth, { recursive: true })
      await mkdir(dataAuth, { recursive: true })
      await writeFile(join(configAuth, 'workbuddy-desktop.info'), '   \n')
      await writeFile(join(dataAuth, 'workbuddy-desktop.info'), nestedDoc(Date.now() + 3600_000))
      await asLinux(
        { home: '/home/alice', env: { XDG_CONFIG_HOME: configHome, XDG_DATA_HOME: dataHome } },
        async () => {
          const store = new WorkBuddyCredentialStore({
            variant: CN_VARIANT,
            ownPath: join(root, 'own.json'),
            refresh: async (credential) => ({ accessToken: credential.accessToken }),
          })
          await expect(store.resolvedDesktopAuthPath()).resolves.toBe(
            join(dataAuth, 'workbuddy-desktop.info'),
          )
          // And the probe really does authenticate from the data-home file.
          await expect(store.current()).resolves.toMatchObject({
            accessToken: 'at',
            source: 'desktop',
          })
        },
      )
    },
  )

  it.skipIf(process.platform === 'win32')(
    'resolves the actually-hit path when only the data home carries the file',
    async () => {
      // Issue #43 diagnostics: the first *candidate* is the config home, but
      // when only the data-home copy exists, resolvedDesktopAuthPath() must
      // name it — for both variants.
      const root = await mkdtemp(join(tmpdir(), 'wb-xdg-resolved-'))
      CLEANUP.push(() => rm(root, { recursive: true, force: true }))
      const configHome = join(root, 'config')
      const dataHome = join(root, 'data')
      const dataAuth = join(dataHome, 'CodeBuddyExtension', 'Data', 'Public', 'auth')
      await mkdir(dataAuth, { recursive: true })
      await writeFile(join(dataAuth, 'workbuddy-desktop.info'), nestedDoc(Date.now() + 3600_000))
      await writeFile(join(dataAuth, 'workbuddy-desktop-ai.info'), nestedDoc(Date.now() + 3600_000))
      await asLinux(
        { home: '/home/alice', env: { XDG_CONFIG_HOME: configHome, XDG_DATA_HOME: dataHome } },
        async () => {
          for (const variant of [CN_VARIANT, AI_VARIANT]) {
            const store = new WorkBuddyCredentialStore({
              variant,
              ownPath: join(root, `${variant.id}-own.json`),
              refresh: async (credential) => ({ accessToken: credential.accessToken }),
            })
            await expect(store.resolvedDesktopAuthPath()).resolves.toBe(
              join(dataAuth, variant.desktopFilename),
            )
          }
        },
      )
    },
  )

  it.skipIf(process.platform === 'win32')(
    'uses translated WSL environment paths when the Windows user differs',
    async () => {
      const root = await mkdtemp(join(tmpdir(), 'wb-wsl-'))
      CLEANUP.push(() => rm(root, { recursive: true, force: true }))
      const windowsProfile = join(root, 'Users', 'windows-alice')
      const local = join(windowsProfile, 'AppData', 'Local', AUTH_TAIL)
      await mkdir(join(local, '..'), { recursive: true })
      await writeFile(local, nestedDoc(Date.now() + 3600_000))

      await asWsl({ home: '/home/linux-alice', env: { USERPROFILE: windowsProfile } }, async () => {
        const store = new WorkBuddyCredentialStore({
          ownPath: join(root, 'own.json'),
          refresh: async (credential) => ({ accessToken: credential.accessToken }),
        })
        expect(store.desktopAuthPath()).toBe(local)
        await expect(store.resolve()).resolves.toMatchObject({
          accessToken: 'at',
          source: 'desktop',
        })
      })
    },
  )

  it('converts Windows-form AppData environment paths to WSL mount paths', async () => {
    await asWsl(
      {
        home: '/home/alice',
        env: {
          LOCALAPPDATA: String.raw`D:\Users\alice\AppData\Local`,
          APPDATA: String.raw`D:\Users\alice\AppData\Roaming`,
        },
      },
      async () => {
        expect(defaultDesktopAuthCandidates().slice(0, 2)).toEqual([
          join('/mnt/d/Users/alice/AppData/Local', AUTH_TAIL),
          join('/mnt/d/Users/alice/AppData/Roaming', AUTH_TAIL),
        ])
      },
    )
  })
})
