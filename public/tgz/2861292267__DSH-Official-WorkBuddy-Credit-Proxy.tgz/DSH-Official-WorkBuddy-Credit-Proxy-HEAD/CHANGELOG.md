# Changelog

本项目的所有重要变更都会记录在此文件。

版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## 2.3.36 (2026-10-18)

本版集中修复四类历史问题，并补上补偿活动与到期优先选号。

### 一、`this.seedExpiries is not a function` —— 每个请求都 500

**症状**：重启后所有请求返回 500，宿主把同一条错误重试 5 次，前端显示「已重试模型请求 (1/5)」。

**根因**：我在 `acquire()` 里加了 `await this.seedExpiries(pool)`，却没有定义这个方法。
`node --check` 通过（语法合法），当时 25 套回归也全绿——没有任何一套会实例化这个类、更不会走到这条路径。

**修复**：补上 `seedExpiries(pool)`，四条设计约束写在方法注释里：只查没有记录的账号、失败退避 60 秒、并发上限 4、错误全部吞掉。

**验证**：新增 `_verify_method_refs.mjs`，对每个 `var X = class {` 做成员对账，任何 `this.foo()` 找不到定义就报错。
反向验证：把 `seedExpiries` 改名，该套件立刻点名报出。

### 二、到期优先从未生效 —— 排序代码正确，但数据是空的

**症状**：13 天到期的账号先被消耗，4.8 天到期的排在后面。

**根因**：`pickByWeight` 的排序逻辑没问题，但 `creditExpiries` 是内存 Map，只在查 `/status` 和「流式成功后」才会填。而请求走的是 shim 的 `/v1/chat/completions`，两条路径都不经过。于是选号时这张表是空的，直接落到闲置加权兜底。

**修复**：`acquire()` 在选号前调用 `seedExpiries()` 预取到期数据；种子填充后重新过滤一遍，余额低于门槛的账号当场剔除。

**验证**：新增 `_verify_expiry_priority.mjs`。用真实的四档到期分布跑 40 次：
- 改动前（软加成）：最早到期账号命中 **7/40 = 17.5%**
- 改动后（严格排序）：**40/40 = 100%**

### 三、国际版 `no configured model` —— 兜底模型表落后于真实目录

**症状**：`pi-ai provider "workbuddy-xdpool" has no configured model "deepseek-v4.1-flash"`。

**根因**：`FALLBACK_WORKBUDDY_MODELS` 是首次拉目录前唯一的模型清单，里面写的还是旧 id `deepseek-v4-flash`。实测国际版目录只有 `deepseek-v4.1-flash` 与 `-sg`，根本没有 `deepseek-v4-flash`。

**修复**：兜底表从 11 个补到 18 个，覆盖配置里全部 17 个启用模型，参数取自 `/status?region=cn` 实测值。

**验证**：新增 `_verify_fallback_models.mjs`，要求「配置启用的每个模型都必须在兜底表里」。

同时给 `regionOf()` 补了 **JWT iss 判区**：`auth.domain` 为空时，从 token 的 `iss` 声明判断国内/国际，避免把国际版账号送进国内网关。

### 四、`/version` 与 `/rollback` 在 `import.meta.url` 缺失时 500

**根因**：热重载后模块在一个没有 `import.meta.url` 的上下文里求值，`fileURLToPath(undefined)` 抛错。`/version` 是卡片打开时必拉的接口，坏了就看不到设置面板。

**修复**：三处 `fileURLToPath` 全部加 try/catch；`checkVersion` 在 `pluginDir` 为 undefined 时诚实降级（`compared: 0`，不伪造结论）；`/rollback` 明确返回 503。

**验证**：新增 `_verify_version_route.mjs`，静态检查 try 保护 + 行为层真实调用三种输入。

### 五、新增：补偿活动领取

从网页前端 bundle 里挖出真实接口（注意**没有 `/v2` 前缀**）：

- `POST /billing/meter/compensation-status`
- `POST /billing/meter/claim-compensation`
- `POST /billing/meter/check-gift-claimed`
- `POST /billing/meter/claim-gift`

新增 4 条路由与卡片按钮。读写分离：轮询状态永远走只读路由，只有点击才走 claim。

**验证**：`_verify_campaign_locale.mjs`（语言包 1:1）、`_verify_campaign_render.mjs`（变量作用域）、`_verify_campaign_claim.mjs`（领取后必须回写状态）。

### 六、重试策略：5 次 / 15.7 秒 → 2 次 / 0.8 秒

这个 provider 的后端是 `127.0.0.1` 上的本地 shim。切国内/国际时宿主重新解析 provider，切换瞬间的请求会以 `TRANSPORT`/`TIMEOUT` 立刻失败（会话日志实测 `usage: 0`、耗时 0 ms）。

宿主默认策略把这种毫秒级抖动放大成十几秒等待。改为：

```js
retryPolicy: resolveRetryPolicy({
  mode: "normal",
  maxRetries: 2,
  backoff: { initialDelayMs: 400, maxDelayMs: 2e3, jitterRatio: 0.1 }
}, "dsh-rotakit retryPolicy")
```

可重试码集**未改动**（仍含 TIMEOUT/TRANSPORT），砍掉的只是次数。

**验证**：`_verify_retry_policy.mjs`。

### 回归

25 套 · 408 条断言 · 0 失败。

---
## 2.3.25 (2026-10-12)

### 账号表的「积分」与「最近使用」两列从来是空的

**症状**：账号列表里，「积分」和「最近使用」两列**每一行都显示 `–`**。

**两个独立的根因，都不是"没数据"。**

**一、积分列读错了字段名。**

数据的真实形状是：

    account.credits = { total: 2055, packages: [...], expiringSoon: 0, nearestExpiryMs: ... }

而代码读的是 `credits.remaining` —— **这个字段不存在**。
判断逻辑本身是对的，只是**永远不成立**，于是一路落到兜底的破折号。

现在读 `total`（仍兼容 `remaining`，因为恢复的账本里旧账号用的是它）。

**二、最近使用列的注释描述了一个从未写出来的实现。**

单元格里原本只有这么一行：

    const lastUsed = cool.active ? (冷却倒计时) : "";

**不冷却时就是空字符串** —— 而一个健康的池子里**所有账号都不冷却**，
所以这一列对每个用户、每一行都是空的。上面那段注释写着"读的是请求日志，
不需要新字段"，**但没有任何代码真的去读**。

现在按 `accountId` 从请求日志里取每个账号最近一次请求的时间。
日志上限 200 条，所以在渲染时**建一次索引**，而不是每行扫一遍。

**三、顺带修掉一个隐藏的后果。**

同一个错误的字段名还出现在**排序**里 —— 两边都取不到值，
每次比较都是 `-1 - (-1) = 0`，于是**同级内顺序完全没排**，
显示顺序就是数组碰巧的顺序。现在按真实积分降序，积分多的排在前面。

**验证**（真实 payload，25 个账号）：

    积分列        23/25 有值（原来 0/25）
    最近使用列    16/25 有值（原来 0/25；其余是近期确实没服务过请求的账号）
    排序          5050 / 4934 / 4784 / 4630 / ...  确实按积分降序

**四、两处函数签名不匹配，顺手改正。**

`formatAge(isoAt, t)` 要的是 ISO 字符串，`formatDateTime(value)` 内部用 `Date.parse`——
后者喂进一个毫秒数会得到 `NaN` 并**把那个数字原样返回**，
于是悬停提示会显示 `1791794088911` 而不是时间。两处都已改成传 ISO。

## 2.3.23 (2026-10-11)

这一版来自一次**全方位审查**：三人分工读代码、读更新链路、读全网同类项目源码，
第四人对抗性复核，剔除误报后剩下的问题逐条修掉。**每条都有触发路径与实测证据**，
清单与复核记录在 `_audit/FINAL-REVIEW.md`。

### 一、协议：工具调用与结果不相邻（上游 11148）

**症状**：Claude Code 按 Esc 中断一次工具调用，之后**整条会话一直报错**。

**根因有两层，都不在原以为的位置。**

第一层在 `protocol-compat.js`。分块内容的分支里，`user` 文本先于本轮 `tool` 结果入队：

    assistant[tool_use] -> user["算了"] -> tool[result]

上游要求每个结果**紧跟**它的调用、中间不能有别的消息，于是整条请求被判
`11148 tool calls and tool results do not match`。

**同一文件里还有第二个入口**：`content` 是**字符串**时（客户端最常用的形态）
在更早的一行就 `continue` 走了，根本没进到上面那段。所以只修分块分支**并不能修好**——
实测确认过。现在两条路都按同一规则处理：**只要有未答复的调用，文本就先押后**，
等结果发完再放出去。

第二层在 `index.js` 的 `repairToolPairs`。它的守卫是"结果必须在调用**之后**出现过"，
于是**"结果比调用先到"的答案被整条丢弃**——调用变成无答案，上游照样拒绝。
而且两个结果（真实的 + 合成的占位符）会一起消失。

现在改成**按配对输出**：调用得到答复时，紧接着输出它选中的那条答案，**与它原本的位置无关**。
选中的规则是「真实内容优先于合成占位符」——早先的顺序会让占位符先到先得，
模型于是被告知"工具没有输出"，而它其实产出了数据。

**验证**（`_verify_p14.mjs` / `_verify_p28.mjs`，都在仓库根目录，可重跑）：

    场景：中断 + 后接文本    -> 相邻性违规 0 条
    场景：结果早于调用      -> 真实结果存活，占位符被丢弃
    对照：正常往返          -> 3 条进、3 条出，未改动

### 二、更新链路

**超时常量定义了却从未被引用。** `VERSION_CHECK_TIMEOUT_MS = 12e3` 全文只出现一次，
而唯一的调用方传的是 `undefined`，函数又只在参数有值时才挂 `signal`——
于是对"连上但从不回包"的主机，版本检查**永不返回**，卡片永久停在"正在检查更新…"，
更新按钮永不渲染。同一文件的 `/update` 路径超时接线是正确的，这正是它长期没被发现的原因。

**更新后的校验是硬编码的。** `REQUIRED_AFTER_UPDATE` 写死一个文件名，
只保护历史上出过事故的那一个；下一个新增模块不会被检查到，
后果是重启后插件**完全无法加载**（连卡片也起不来）。
现在从**即将写入的 `index.js` 的静态导入**推导，清单跟着发布内容走。

**`applyUpdate` 的 `rename` 没有护栏。** 同一个操作在 `applyRollback` 里是有 `try/catch` 的，
升级路径反而更脆弱——而 Windows 上 `rename` 失败是常事（文件被运行中的宿主占用）。
失败会以未捕获异常逃逸出路由，留下一个**既不是旧版也不是新版**的目录树。

**改成"先全部备份、再逐个写入"，两阶段分开。** 这同时修掉另一个问题：
原先"备份一个写一个"，中途失败留下的备份集是残缺的；而回滚点只接受完整备份集，
于是**最需要回滚的那次更新恰恰没有回滚点**，卡片上的回滚区块整个不渲染。

**`TRACKED_FILES` 从 4 项扩到 6 项**，补上：

| 文件 | 原来不更新的后果 |
|---|---|
| `lib/bin.js` | 卡片在凭据解密失败时**让用户去跑 `doctor`**，而那个 `doctor` 是旧代码 |
| `cordis.patch.yml` | DSH 据此注册 provider，留下旧的 provider id，改名永远不生效 |

`lib/index.d.ts` **刻意不加**：纯类型、运行时不加载，加上只会让每次更新多传 94 KB。

> 注意：这个列表的长度**同时是回滚点的判据**。所以判据改成了"按实际覆盖到的文件"，
> 而不是"等于当前列表长度"——否则扩充列表会把**所有历史回滚点**一起作废。

**回滚不再是一扇单向门。** 覆盖前先把当前版本另存为 `.pre-rollback-<时间戳>`；
备份集只恢复它实际覆盖的文件（早于某文件加入的备份集仍然可用）。
失败的更新还会清掉自己的临时文件。

**备份自动保留最近 3 组。** 每次更新复制六个文件（约 1.1 MB），原先从不清理。

### 三、其余

- **文案**：区域指引原先写"也可以直接用网页版登录"——插件读的是桌面客户端留下的凭据，
  网页版根本读不到，这句话把用户引向一条**必然失败**的路。中英两份都改了。
- **过期注释**四处：`checkVersion` 的 "Deliberately local-only"（描述的是 `inSync` 字段，
  不是整个函数，远端版本是另一个入参）、`sanitizeQr` 的 "arrives as markup from the gateway"
  （实际由 `qrcode` 库对 `authUrl` 生成）。
- **语言包护栏基线**从 261 更新到 295（中英各自 295，仍然对称）。

### 四、发布链

新增 `.github/workflows/release.yml`：**打 `v*` tag 即发布到 npm**（OIDC，无需 token 或 2FA）。

两条硬校验：

    tag 与 package.json 版本不一致  -> 中止（宁可发布失败，也不发名不副实的版本）
    包名不是 dsh-rotakit            -> 中止（那个包名属于上游作者，见 AGENTS.md §零）

新增 `tools/check-package-files.mjs`：每个运行时加载的文件都在 `files` 白名单里，
否则用户装上后 `ERR_MODULE_NOT_FOUND`，且要重启才暴露。
`tools/check-publish.mjs` 依赖本机已安装副本（硬编码 profile 路径），**CI 上跑不了**，
所以这个检查只读仓库，两边都能跑。

以上检查都做过**负向验证**：四种破坏（移除白名单项、清单指向不存在的文件、
`bin` 指向不打包的文件、白名单清空）分别得到预期的 `exit=1` 与 `exit=100`。

### 五、一份说明

审查过程中三方各自都推翻过自己的结论：一人初稿只读一个文件就下了 high 结论；
一人用正则匹配到了注释散文而产生了假阳性；复核者两次推翻自己，并剔除了一条
**拿对方实现推定我方缺陷**的误报（我方的错误分类器早已修过那个问题，
`index.js:498-501` 的注释记着 "This ordering is the fix"）。

**这轮的方法能成立，靠的正是这些自我推翻被记录了下来。**

## 2.3.13 (2026-10-11)


这一版是**设置卡片的视觉重构**（色调 / 排版 / 宽屏布局），加上一次
**余额刷新的缺陷修复**。所有改动都带着实测证据，并在 `_ui/` 下留下了可复跑的护栏脚本。

### 一、色调：建立令牌层，跟随宿主主题

原先卡片直接读宿主的 `--dsw-alias-*`。现在多了一层 `--pool-*`
（**基础块 17 个 + 既有 5 个 = 22 个**），每个转发到宿主变量并带字面量 fallback：

    --pool-accent: var(--dsw-alias-state-business-primary, #0369a1);

**亮暗取值分置**：亮色 `#0369a1`（深青蓝）/ 暗色 `#38bdf8`。
定稿的青蓝在白底只有 **2.14:1**，正文远不达标，所以亮色必须加深。

**主题三态**：`body[data-ds-dark-theme]`（宿主算出）/ `body[data-theme="light"]` /
`body:where(:not(...):not(...))` 兜底。

> **任务书里曾要求「跟随系统那一路在 `@media (prefers-color-scheme: dark)` 里补映射」，
> 那条判据是错的，已作废。** 该媒体查询在本文件里**从未作为活规则存在过**
> （逐行跟踪注释区间确认：含它的 2 处全在注释内，剥离注释后活规则 0 条）。
> 宿主的 `bootThemeBodyScript` 已经把三态折成一个布尔属性：
>
>     const dark = preference === 'dark' || (preference === 'system' && matchMedia(...).matches)
>     document.body.toggleAttribute('data-ds-dark-theme', dark)
>
> 卡片若自行读 OS，会在「OS 暗 + 用户选亮色」时拿到暗色强调色配浅色宿主。

### 二、排版与布局：宽屏真正铺开

概览改**三栏**（主区 + 336px 右栏）、账号列表改**五列表格**、趋势图 **44px → 104px**、
自动化页三卡并排、设置页双栏。

**关键决策：不新增包裹层。** 那 9 条「默认隐藏各区块」的选择器（`.usage > .x`）
与揭开侧（`.page-x .x`）的**特异性被刻意做成同为 (0,2,0)**，靠**源码顺序**决胜；
插入包裹层会让隐藏侧链变长、特异性不再相等、**胜负改由特异性决定 → 可能反转
→ 卡片渲染为空白，即使一条选择器都没漏改。** 把 grid 直接加在既有的 `.usage` 上，
则**既有规则一行都不用改**。

> 那一段的注释自己记录过同类事故：「CSS 合法、类都在、每个选择器都能解析，
> **测试套件完全看不见**」。

响应式四档（>900 / 620–900 / <620 / <420）全部走 `@container poolcard`，
`@media (min-width)` 命中 **0 处** —— 用媒体查询会在 1400px 窗口下把约 600px 宽的卡片误判为宽屏。

### 三、余额刷新：失败被静默吞掉，还会冻结 10 分钟

**症状**：上游抖动一次，该账号的余额在界面上**静止 10 分钟**，且系统里**不留任何痕迹**。

**根因（两处，叠加）**：

    lastBalanceAt.set(account.id, now);   // ← 写在 try 之前
    try {
        const credits = await client.fetchCredits(...);
        ...
    } catch {}                            // ← 空 catch

时间戳在 `try` **之前**更新，所以**无论成功失败都推进** → 失败也要等满
`BALANCE_REFRESH_MS`（10 分钟）才重试。一次瞬时抖动被放大成 10 分钟静默。
而空 catch 让「刚才失败了」这件事无处可查。

**修法**：时间戳移入成功分支；新增**独立**的 `lastBalanceFailAt` +
`BALANCE_RETRY_MS = 30s` 做失败退避。

> **两个窗口语义必须分离**：`lastBalanceAt` = 「距上次**成功**」，
> `lastBalanceFailAt` = 「距上次**失败**」。一个时间戳无法同时表示这两件事
> —— 那正是原缺陷的形状。

### 四、语言包：补上一个此前为零的自动化保护

期间发现仓库 `AGENTS.md` 里有一句**错误陈述**：「`check-publish.mjs` 会检查
（136 个键逐个核对）」。实测：把中英两包的 `row.title` **都删掉**，
该脚本仍 `6 passed, 0 failed`、`exit=0` —— **它根本不检查语言包**，
而 `run-suite` 的 17 套件也不涉及 i18n。**语言包此前零自动化保护。**

新增 `_ui/verify-locales.mjs`：校验中英数量相等、双向差集为空、
绝对数 = 基线 + N（N 从 `git diff` 数出，**不靠算术外推**）、两包各自无重复键。
本次新增 28 键/包 → 289/289。

### 五、验收

| 检查 | 结果 |
|---|---|
| `node tools/run-suite.mjs` | 332 passed / 0 failed |
| `node tools/check-publish.mjs` | 6 passed / 0 failed |
| `_ui/verify-locales.mjs --added 28` | 9 passed / 0 failed |
| `_ui/theme-matrix.mjs` | 234 项 / 0 失败（18 格三态 + 对比度） |
| `_ui/check-root-fallback.mjs` | 通过（补 `theme-matrix` 的已证盲区） |
| `_ui/shots/layout-shots.mjs` | 72/72 渲染有内容（4 主题 × 6 宽 × 3 页） |

### 六、留档：本轮的可信度教训

写检查脚本时踩到的坑，全部来自真实翻车，已写进 `AGENTS.md` §六：

1. **凡枚举型/存在型断言，必配反向验证** —— 单向只能证明「我找到了这些」，
   不能证明「我没漏掉」。实例：正则漏 `-fg-2`、尾行号漏 7 键、行号切包。
2. **「全部通过」必须先报「参与比对的项数」，且不得为 0** —— 实例：定位亮色块时
   命中了**注释里的那一份**，比较集合为空，检查空转报绿。
3. **报绿前先证明破坏真的改变了可观测输出** —— 实例：破坏确实落盘，但换成了
   **特异性等价、渲染相同**的写法，全绿是**对的**；若据此判「检出力回归」就是误伤。

**五种「信号不可信」形态**：假绿 / 假红 / 漂移 / 未改变可观测结果 / 未接线。

**退出码分段**（仅新建护栏脚本）：`0` 通过 / `1..99` 检出 / `100+` 基础设施故障。
`run-suite.mjs` 保持原语义（退出码 = 失败套件数），**不要去改它**。

### 七、未完成（已知未做，非无人发现）

- **30 处 CSS 规则仍直读宿主 `--dsw-alias-state-success-primary`**
  （另有 10 处 `focus-visible` 轮廓**刻意保留** —— 焦点环应随宿主）。
  它们当前**不是缺陷**（宿主主题下渲染正确），只是科技色调尚未统一。
  **收编时注意**：还有 2 处在 JS 侧（`dotColor()` 返回值、React 内联 `style`），
  **不在 `POOL_CARD_CSS` 模板内 —— CSS-only 扫描会漏掉它们。**
- **状态点保持绿色**：它承载「健康 / 正在服务」语义
  （`data-state` 有 error/idle/loading 三个变体），改成品牌色会让
  **「健康」与「品牌色」再也分不开** —— 那是分辨率下降，不是视觉统一。

## 2.3.9 (2026-10-11)

### 签到 / 自动化完成状态在重启后丢失（`servedSlots` 从未被持久化）

**症状**：每次签到完成之后，重启 DeepSeek Harness 就看不见签到是否完成了。
重启后卡片上同时出现两件互相矛盾的事：收益栏显示今天签到拿到 100 credit，
任务栏却显示签到 job「今天没跑过」。

**根因**：`lib/index.js` 的 `persistEarnings()` 只写两个字段：

```js
this.saveEarningsFn({
    date: this.earningsDate,
    accounts                 // ← 只有各账号收益
});
```

`servedSlots` / `lastRunSlot` / `lastRunDate` **一个都没写**。
恢复端 `applyEarningsLedger()` 同样只读 `accounts`。两半事实丢了一整半。

实测确认：`cordis.patch.yml` 的 `automationEarnings` 段只有 `date` 与
`accounts`，字符串检索确认无 `servedSlots`、无 `lastRunDate`。

**后果（两层，第二层更严重）**：

1. 界面自相矛盾 —— 同一次持久化里的 `accounts[].checkinCredit = 100` 还在，
   但 `servedSlots` 为空，卡片据此判定「今天没跑过」。
2. **防重复执行的锁丢了** —— `runNow` 的守卫是
   `this.servedSlotsOf(kind).includes(stamp)`，集合为空即守卫失效，
   重启后定时器会把今天已经跑过的 job 再跑一遍，真实重复请求上游。

**修法（一）**：`persistEarnings()` 增加 `runs` 段（按 kind 分组的
`servedSlots` / `lastRunSlot` / `lastRunDate`），`date`、`accounts`
含义不变；`applyEarningsLedger()` 同步恢复，并复用 `runJob` 写入端
同一条「只收当天 slot」的过滤规则。

新增 `readJobRunRecord()` 只接受字符串：`servedSlotsOf()` 对每个条目调用
`.startsWith`，一个数字混进去就会抛错 —— 而这是插件启动路径，抛错会连整张
卡片一起带走。畸形输入（`ledger` 为 `null`/数字、`accounts` 为 `null`、
`runs` 为字符串、`servedSlots` 含非字符串）一律不抛错、不清空已有状态。

**修法（二）：即使补上了字段，锁仍然不会落盘 —— 这是本次的第二个真 bug。**

`runJob()` 末尾原本没有任何持久化调用。更早的每一次 `persistEarnings()`
都来自 `recordEarnings()`，而它**每账号触发一次**，发生在账号循环中途 ——
也就是在 `servedSlots` / `lastRunSlot` / `lastRunDate` 被赋值**之前**。

更要命的是：一个所有账号都回「已签到」的 job 一分钱都不进账，
**根本不会调用 `recordEarnings`**，于是一次写入都不会发生 ——
尽管它确实占用了那个 slot。只补字段而不补写入时机，锁依然永远不落盘。

因此 `runJob()` 在状态定稿**之后**补一次 `persistEarnings()`。
这一条不做，第一个修复是不完整的。

**修法（三）**：顺手修掉同类隐患 —— 宿主会恢复**两次**（构造函数一次、
设置文档可读后 `index.js:11747` 再一次），而收益是逐账号 merge，
重复 merge 会把卡片上的每个数字翻倍。加 `restoredLedgerToday` 标记，
让收益只 merge 一次；run 记录本身幂等，不需要该标记。

**验证（四项实测，均跑真实导出模块，非替身）**：

| 用例 | 结果 |
|---|---|
| `node tools/run-suite.mjs`（17 套） | **332 passed, 0 failed** |
| 含 `runs` 的 ledger → 重启后读 status | `servedSlots=["2026-10-11T09"]`、`lastRunDate` 正确恢复，`dueSlot("checkin")` 返回 `undefined`，**锁恢复生效**；10 passed, 0 failed |
| `date` 为昨天的 ledger | 全部忽略，当日 09:00 仍 due（不跨天误恢复）；7 passed, 0 failed |
| 不含新字段的老格式 | 不报错、旧 accounts 仍在、重复应用不清空，且下次保存自动补上 `runs`；9 passed, 0 failed |

`node tools/check-publish.mjs` 同时 6 passed, 0 failed。

**对照实验**：用修复前的 `HEAD:lib/index.js`（519,701 B）替换被导入模块，
跑同一套断言必须失败 —— 否则测试本身没在测这个 bug：

| 套件 | 修复前基线 | 修复后 |
|---|---|---|
| 单元断言 | **24 passed, 14 failed** | 39 passed, 0 failed |
| 重启断言 | **4 passed, 6 failed** | 10 passed, 0 failed |

基线失败项恰好复现原症状：`lastRunDate=undefined` 与
`checkinCredit=100` **同时出现**（同一个文档，自相矛盾），
且 09:00 slot 再次 due（锁丢了）。

**未做物理进程重启的原因**：提供 `/plugins/dsh-rotakit/status` 的进程就是
运行验证的宿主进程，杀掉它等于杀掉观察者本身。改为在同一边界复现
（丢弃 scheduler 实例 → 从设置文档重建 → `applyEarningsLedger`），
与被测路径完全一致，并由上述对照实验背书。

**改动范围**：仅 `lib/index.js`（+ `package.json` 版本号）。
## 2.3.6 (2026-10-10)

### 请求记录在流结束前就被写盘，取消结果被静默丢弃

**症状**：客户端断开后，请求确实被取消了（上游停止计费、秒级终结），
但日志里 `outcome` 仍是 `ok`，只有 `detail` 写着「已被取消」——自相矛盾。

**根因**：`requests.add(record)` 的位置太早。

```js
// logTiming（旧）
record.generateMs = ...;
requests.add(record);        // ← 环形缓冲 + 追加 requests.jsonl，按值快照
```

而 `logTiming` 在**成功路径**上是由 `onStreamEnd` 调用的，那个回调在
**流还在写的时候**就触发。于是快照发生在 `record.outcome` 仍是 `"ok"` 的时刻；
`report()` 稍后设置的 `client-cancelled` 与 `detail` 再也到不了日志。

`detail` 之所以看起来「写进去了」，是因为它**不在**那次快照已提交的字段集里，
而 `outcome` 在 —— 一个字段丢了、另一个字段留了，日志因此自相矛盾。

**修复**：把持久化从 `logTiming` 中移出，改为幂等的 `persistRequest()`，
在所有**真正的终态**调用：

- 流的 `report()`（`end` / `error` / 看门狗三条路径汇聚于此）
- 12 个失败分支（no-account、model-blocked、no-credits、request-fault、
  context-overflow …）

`persistRequest` 定义在 `runChatLoop` 作用域，而 `report` 在
`serveSuccessfulStream` 内 —— 跨函数不可见。第一次改完直接
`ReferenceError: persistRequest is not defined`（由 `_verify_shim_e2e.mjs` 抓到），
现改为经参数传入并做可选调用。

**验证**（端到端实测，运行实例）：

| 项目 | 结果 |
|---|---|
| 真实长流 95KB / 289 帧 / 3 秒后断开 | `outcome = client-cancelled` ✔ |
| `totalMs` | 3006ms，精确对应断开时刻 3008ms ✔ |
| 失败路径（model-blocked） | 记录 1 条，无重复 ✔ |
| 成功路径 | 恰好 1 条 ✔ |

### 教训

**「写日志」和「改对象」的顺序是一个真实的 bug 来源。**
凡是先 `add()` 快照、后赋值的代码，后面的字段一定丢。这类问题在静态断言和
单元测试里都看不出来 —— 只有把**运行实例的日志**读出来对比才对得上。

## 2.3.5 (2026-10-10)

### 这一版真正的重点：之前的所有修复，DSH 都没加载过

**症状**：修复做完、测试全绿、端到端却仍然复现原问题。

**根因**：profile 的 `file:` 依赖指向了一个 **10月5日的孤儿副本**，
不是开发仓。

```
C:\Users\ASUS\.dsh\profiles\desktop\package.json
  "dsh-rotakit": "file:D:/WorkBuddy文件/2026-09-25-10-38-26/repo-DSH-..."
```

**它是什么**：

| 事实 | 内容 |
|---|---|
| 该副本 HEAD | `da61191`（*make the version strip look like a control*） |
| 开发仓中的对应提交 | `95d9f31` —— **同一提交**（内容逐字相同、作者相同、仅差 11 秒、git 身份不同） |
| 之后的分叉 | 开发仓又前进 **17 个提交**（2.2.0 → 2.3.5） |
| 该副本版本 | **1.99.2**；`lib/` 只有 3 个 js（无 `protocol-compat.js`） |
| `merge-base` | 与开发仓**无共同祖先** —— 是一份被复制出来的孤儿 |

**为什么难发现**：两条线**指向同一个 GitHub 远端**，提交信息一一对应，
只是 hash 因 rebase/身份差异而不同。光看 `git log` 会以为是一致的。

**怎么暴露的**：只有端到端实测能发现。用真实长流（先确认输出帧数/字节数/
持续时间）测断开，请求 **30 秒仍无终结记录**、`client-cancelled` 记录数为 **0**
—— 而单元测试和 332 条断言全绿。**测试跑在开发仓上，运行的是另一份代码。**

**修复**（三步）：

1. profile 依赖改指向开发仓；
2. `pnpm install`，输出确认了变更；
3. 安装目录改为 **Junction** 指向开发仓 —— 今后改仓库**立即生效**，
   从根上杜绝再次失配（pnpm 对 `file:` 默认是复制，这正是问题能悄悄存在的原因）。

> 顺带验证：中文+空格路径下的 `file:` 依赖可用，npm 会创建 Junction。

**教训**：`file:` 依赖是**复制语义**。改了「看起来是同一个仓库」的目录，
运行中的插件可能读的是另一份。改完必须验证**运行实例**的行为，
而不是验证磁盘上的文件、也不是验证测试套件。

### 端到端实测（重启后，真实实例）

| 项目 | 结果 |
|---|---|
| PROTO-03 `POST /v1/responses` | 返回 `{object:"response", status:"failed", ...}` ✔ |
| CONC-008 真实长流 3 秒 / 71KB 后断开 | **断开后 1.0 秒落盘**，`totalMs` 精确等于断开时刻 ✔ |
| `/v1/chat/completions` + `/v1/messages` | 均无 5xx ✔ |

CONC-008 前后对照（同为真实长流）：修复前断开后 23s→121s 无记录、上游继续计费；
修复后 **1.0s** 终结。

### 附：客户端取消的记录标签

新增 `outcome: "client-cancelled"` 与 `detail` 说明，使日志能区分
「用户主动中断」与「上游故障」。此前取消会被记成 `ok`，掩盖了中断事实。
写入位置必须在 `onStreamEnd`（即 `logTiming("ok")`）**之后** ——
否则会被覆盖回 `ok`。

## 2.3.2 (2026-10-10)

这一版把第二轮独立审计（4 路并行审查 + 交叉复核，共 49 条结论）里
**经复核确认**的缺陷落到了代码上。每条都写清根因、为什么这么修、
以及怎么验证 —— 包括我自己在修复过程中造成的两次回归。

修复前基线：17 套件 332 断言全绿。修复后：332 + 42（新增专项）= 374 全绿。

### 一、客户端断开后，上游继续跑（**唯一直接花钱的一条**）

**症状**：关掉页面或中断一个长回答，上游仍在生成，token 继续计费。

**根因**：`req.on("close")` 触发的 `controller.abort()` **只作用于 fetch 的
headers 阶段**。`chatStream` 拿到响应头就返回了原始 `response`，而响应体交给
`Readable.fromWeb` 时**没有绑定任何取消信号** —— 没有 `AbortSignal.any`，
也没有 `body.cancel`。

**实测**（本机 8120 端口，真实上游）：客户端在 t+1206ms 收到首字节后断开，
**23 秒后 `requests.jsonl` 仍无该请求的终结记录**。它要挂到 `IDLE_TIMEOUT_MS`
（300 秒）才会被收走，而且会被记成 `ok` —— 因为从上游视角什么都没出错。

**修法**：把 `controller.signal` 组合到响应体上，断开时 `body.destroy()`
向下撕掉 web stream，从而取消在途 HTTP 请求。`serveSuccessfulStream` 新增
`signal` 参数，两个调用点（主循环与压缩恢复）都传入。

**验证**：断言 `abortUpstream` 存在、绑定了 signal、在 `close` 时移除监听
（避免闭包滞留）、两个调用点都传了 signal。

### 二、Codex 的自由格式工具载荷被静默丢弃

**症状**：Codex CLI 的 `apply_patch` 永远收到空补丁，模型回
"I received an empty patch request"；`local_shell_call` 同理。HTTP 仍是 200，
日志里看不出任何异常。

**根因**：载荷字段**随 item 类型而变**，而代码只读了其中两个：

| item 类型 | 载荷字段 |
|---|---|
| `function_call` | `arguments`（JSON 字符串） |
| `local_shell_call` | `action`（对象） |
| **`custom_tool_call`** | **`input`（自由格式字符串，不是 JSON）** |

`apply_patch` 这类工具声明为 free-form，模型的输出落在 `input` 里，
而代码只查 `arguments`/`action`，于是 `args` 恒为 `"{}"`。
（已对照 codex-rs `protocol/src/items.rs` 核实自由格式变体携带 `input`。）

**修法**：按 `arguments` → `action` → `input` 的顺序取值。`input` 已是字符串时
**原样透传**而非再 `JSON.stringify` —— 自由格式载荷就是工具要收到的原始文本，
套一层引号等于把补丁变成一个 JSON 字符串字面量。

**验证**：把真实补丁文本喂进 Responses 翻译器，断言取到的是原文，
且**不是**被引号包起来的字符串。这里我第一版断言写错了（用 `JSON.stringify`
后的字符串去查转义符，必然失败），改成解析后取 `tool_calls[0].function.arguments`
再判断。

### 三、Responses 路由的错误不是 Responses 协议形状

**症状**：Codex 拿到 400 无法归类。上下文超长时不会被识别为可重试，
压缩恢复路径因此从不触发，回合直接死掉。

**根因**：`responsesProtocol` 复用了 OpenAI 的 `writeOpenAIError`，
返回 `{"error":{...}}`。而 Codex 的解析器（codex-rs `sse/responses.rs`）
只认 `response.failed` 事件、或一个 `status: "failed"` 的 `response` 对象。

**实测**（运行中实例）：`POST /v1/responses` 返回的确实是
`{"error":{"message":...}}` —— 复现了。

**修法**：新增 `writeResponsesError`，输出
`{ id, object: "response", created_at, status: "failed", error: { code, message } }`。
HTTP 状态码照旧，普通 HTTP 客户端仍能看到真实 code。
**Chat 路由继续用 OpenAI 信封**（有断言守着，防止误改）。

### 四、usage-stats 的行号游标与日志裁剪冲突，统计永久漏计

**症状**：界面上的用量统计在某天之后**再也不增长**，无任何报错。

**根因**：`createRequestLog.trim()` 在 `requests.jsonl` 超过 4MB 时把它重写为
最后 200 行，而 `processedLines` 记的仍是裁剪前的行数（比如 3000）。
下次构建时 `lines.length (200) <= processedLines (3000)` 成立 → 直接 return，
**而且这个条件只会越来越成立**，不自愈。

**修法**：游标改成「**哪一行**被数过了」，而不是「数了多少行」：

- `cursorLine` —— 最后被计数那行的文本
- `cursorSeenCount` —— 该文本在此之前从文件头数起**已出现过多少次**

相同行在这里是**常态而非边缘情况**（同模型同 token 数的两条请求序列化后完全相同），
所以只按文本匹配必然有歧义。出现序号消除歧义：行是追加的，裁剪保留尾部，
只要序号不超过保留下来的出现次数，第 n 次出现就还是同一行。

锚点整行消失时（被裁掉或轮转）从存活部分的头部重新开始 —— 宁可多计也不漏计。

**验证**（行为级，非仅静态）：把真实函数从源码中提取出来单独执行，喂进
「3 行 → 裁剪为 2 行 → 增长回 3 行」序列。**这里抓到了我第一版的真 bug**：
我最初用「末尾偏移量」做锚点，`fromEnd=0` 在新文件里永远匹配最后一行，
导致游标原地不动（计数冻结在 3）。改用出现序号后通过。

### 五、流式请求的 inFlight 租约提前释放，IN_FLIGHT_LIMIT 形同虚设

**症状**：同账号可被并发叠加任意多路流式请求，硬上限不生效。

**根因**：`serveSuccessfulStream` 是 async，但函数体里 `await` 数为 0 —
它挂上监听器、调用 `pipe` 就 `return` 了（源码注释自己写着
"returns as soon as pipe is called"）。外层 `finally` 随即 `pool.release()`，
于是**每条被服务的请求在整个流传输期间 `inFlightCount` 恒为 0**。
账号读起来是空闲的，就可以在已有流之上再被选中，`stickyAccount`
还会把整个会话压到同一个账号上。

**修法**：租约的**所有权转移给流**：

- 主循环用幂等的 `lease` 令牌，`finally` 调 `lease.finish()`
- `serveSuccessfulStream` 开头 `lease.handOff()` 接管
- 流的终态回调 `report()` 里 `lease.finish()` 才真正归还
  —— `report` 由 `end`/`error`/看门狗三条路径共同触发，一处覆盖所有终态
- **补偿路径**：`Readable.fromWeb` 或协议写头抛异常时流根本没启动，
  用 `releaseOnFailure()` 兜底归还

`finish` **必须幂等**：漏放会让账号永久退出轮换，但重复放更糟 ——
会为一条已不再持有租约的请求再减一次，把另一个仍在途的请求的计数打到 0，
正是这套机制要防的超额准入。

压缩恢复路径（`recoverFromContextOverrun`）有同样问题：它 `return` 一个
**仍在使用中**的账号，却在自己的 `finally` 里释放了租约。改为把 `releaseLease`
随结果一并返回，由调用方交给流。

**验证**：11 条断言覆盖四个必要部分 —— 令牌存在、有 hand-off、
`finally` 用的是令牌而非 `pool.release`、幂等、终态归还、异常路径归还、
两个调用点都传租约、恢复路径返回自己的租约。

### 六、11 个编辑器备份随发布包发布，占包体 74%

**根因**：`package.json` 的 `files` 白名单里 `"lib"` 是**目录**项，
而**目录项会盖过 `.gitignore`**。13 个 `.bak-*`（约 4.1MB）虽然 git 从未跟踪、
`.gitignore` 也明明挡了，却照样进 tgz。

**修法**：备份移出 `lib/`（放到工作区外的归档目录），并新增 `.npmignore`
做第二道防线 —— 排除规则写在 npm 真正会读的地方。

**验证**：`npm pack --dry-run` 实测。
**包体 5712KB → 1354KB（降 76.3%）**，16 个文件，无 `.bak`/`.orig`。

### 本次修复过程中我自己造成的两次回归（留档）

**其一**：我先把修改做在**安装目录**，然后用 `cp <repo>/lib/*.js <inst>/lib/`
"同步"——结果把安装目录**打回了仓库的旧版本**，五条修复全部丢失。
根因是**仓库与安装目录本来就不一致**：仓库的 `protocol-compat.js` 是 32327 字节，
安装目录是 33288 字节（多一个 PROTO-01/11148 修复）。
教训：同步前先比对两侧，而不是假设一侧领先。现已改为**在仓库改、带备份地同步**。

**其二**：RT-02 第一版用「末尾偏移量」当锚点，`fromEnd = 0` 无意义
（"最后一行"在新文件里永远是最后一行），计数冻结。
是**行为级验证**抓出来的 —— 仅做静态断言不会发现。这条教训写进验证脚本注释。

### 验证方式汇总

| 项目 | 命令 | 结果 |
|---|---|---|
| 全量回归 | `node tools/run-suite.mjs` | 332 断言 / 17 套件，全绿 |
| 本轮专项 | `node _verify_captain_fixes.mjs` | 42 断言，全绿 |
| 发布前检查 | `node tools/check-publish.mjs` | 6 项，全绿 |
| 打包体积 | `npm pack --dry-run` | 1354KB，无备份文件 |
| 端到端 | 真实 8120 端口 | 复现了 CONC-008 与 PROTO-03 |

**注意**：以上是**磁盘**验证。运行中的 DSH 用的是内存旧代码，
必须重启才会加载 2.3.2 —— 端到端实测已确认旧行为仍在生效。

## 2.3.0 (2026-10-10)

这一版把**更新流程本身**做完整。对照了业界做法（Tauri 的更新器、
electron-updater、VS Code 扩展市场），补上三项真实缺口，并对
「为什么不照搬某些机制」给出理由。

### 一、下载没有超时（此前会永久挂起）

`applyUpdate` 的 fetch **没有超时**。一条"连上了但不传数据"的连接会让更新按钮
一直转，用户只能重启 DSH 才能脱身。

现在有 12 分钟上限（实测下载 591KB 需 1.4–9.6s，余量充足），并与调用方自己的
signal 通过 `AbortSignal.any` 合并 —— 页面关闭仍能中止下载。

### 二、不拒绝降级（可能装上更旧的版本）

此前不校验"新版本是否高于当前版本"。两种真实后果：

- 已发布分支**倒退**时（回滚发布、重建仓库、强推），"更新"会装上一个更旧的树
- 更旧的包可能**根本无法加载**：老代码会 import 已不存在的文件
  —— 这正是 `protocol-compat.js` 那次事故的形态

现在用已有的 `isNewerVersion` 判断，**不是更新就拒绝**，并把原因返回给卡片。
这是 Tauri 的默认行为（"checks if the update version is greater"）。

### 三、新增回滚入口（此前备份有，但没路回去）

`applyUpdate` 每次都会把被替换的文件备份成 `<name>.orig-<stamp>`，
**但没有任何方式回到备份** —— 用户要手动找到
`index.js.orig-1791636000000` 再改名。备份存在，恢复不存在。

新增 `/rollback` 路由：

| 方法 | 作用 |
|---|---|
| `GET` | 列出可用备份（按时间倒序）|
| `POST` | 恢复指定的那一组 |

设计细节：

- **只提供"完整"的备份组** —— 每组必须覆盖全部 `TRACKED_FILES`。
  不完整的组会恢复一部分、留下另一部分在新版本，**得到一个哪版都不是的树**，
  比两版之间任何一个都糟
- 恢复用**原子写**（临时文件 + rename），与更新同一套纪律：崩溃不留半成品
- `POST` 走 `writeAllowed`（与更新同级的守卫），`GET` 只走只读检查
- 卡片在**有备份时才显示**该面板，默认收起 —— 它是逃生口，不是更新的必经步骤

实测：造一个"已从 2.2.0 更新到 2.2.2"的目录 → 回滚 → 版本与文件内容
全部回到 2.2.0；不存在的 stamp 被拒绝并给出原因。

### 为什么不做的三项（附理由）

**签名校验** —— Tauri 的做法是强制签名（"This cannot be disabled"）。
我们不做，因为代价与收益不成比例：需要维护密钥对、在 CI 里签名、把公钥嵌进
插件，而本插件的更新源是固定的 GitHub 仓库、走 HTTPS、不涉及金钱与特权。
**若将来要支持第三方源或私有部署，这一条应该重新评估。**

**哈希校验** —— 边际价值低。GitHub 的 HTTPS 已确认服务端身份；而哈希清单本身
也存在同一个仓库里，**若仓库被入侵，攻击者可以同时改代码和哈希**。
哈希能防"传输损坏"（gzip 的 CRC 已经覆盖），防不住"内容被替换"——
后者需要签名，不是哈希。

**可配置更新源** —— 无实际需求，避免过度设计。

### 四、测试

- 更新流程 24 条断言（超时 / 拒绝降级 / 回滚路由 / 前端 / 语言包）
- **真实回滚测试 9 条**：用真实函数在隔离目录上完成一次完整回滚
- 全量回归 331/331

## 2.2.1 (2026-10-10)

### 更新后必须重启 —— 提醒从「一行小字」改成「醒目横幅」

**症状**：用户点了「更新」，文件写到了磁盘，**但功能没有任何变化**，
而且卡片上只显示一句和版本号同样轻重的 `restart to apply`，很容易看漏。

**根因分成两层**：

1. **技术上**：运行中的进程用的是**内存里的旧代码**，磁盘换了新文件不影响正在跑的那份。
   这是 ESM 的固有限制 —— 模块缓存不可撤销，宿主持有旧引用。
   所以"更新后要重启"是**必然的**，不是缺陷。

   查清了插件持有的运行时状态（18 个 Map、11 个 Set、1 个 setInterval、
   11 个 setTimeout、12 个路由注册、4 个宿主清理钩子），
   确认**插件内部无法自行热重载** —— 强行重载会状态全丢 + 定时器双实例 + 路由重复注册。

2. **体验上**（这是真正能改的）：提醒太弱。

   改前：`updated → 2.2.0 · restart to apply`（一个 span，和版本号同层级）
   改后：带边框与背景的块，**加粗**写明「需要重启 DSH 才会生效 ——
         新代码已经写到磁盘，但正在运行的那份还是旧的」，
         并带 `role="alert"`（屏幕阅读器会播报）。

   顺带把更新校验的 `warning`（`REQUIRED_AFTER_UPDATE` 缺文件时的报告）
   也显示在这个块里 —— 之前它返回了但前端不展示。

### 顺带修正：上次的改动漏了同步

这次的横幅改的是 `lib/client.js`，而上次只把 `lib/index.js` 同步到了仓库，
**`client.js` 一直只存在于安装目录** —— 没进版本控制，也没升版本号，
用户永远收不到。

这正是 `AGENTS.md` 第一条要防的事，所以这次一并补上，并把流程写进文档。

## 2.2.0 (2026-10-10)

这一版做的是**发布给别人用**时才暴露的问题，以及**让用户知道自己该更新**。

### 一、更新后插件无法加载（致命）

`TRACKED_FILES` 只更新三个文件，**漏了 `lib/protocol-compat.js`** ——
而它是 2.0.0 新增、被 `index.js` **静态导入**的。

后果：一个 2.0.0 之前的安装点了「更新」，会拿到一个 import 它却找不到它的
`index.js`，`ERR_MODULE_NOT_FOUND`，**插件彻底起不来**。而且要到下次重启
才暴露，那时根本联想不到是更新造成的。

**已在隔离目录完整复现**：老版本安装（无该文件）→ 执行更新 → 更新前能加载、
更新后不能。修复后同一场景加载正常。

同时加了**更新后校验**：`REQUIRED_AFTER_UPDATE` 里的文件缺失就返回 warning。
为什么是 warning 而不是回滚 —— 那时文件已写完，磁盘上是发布版，用本次
自动生成的 `.orig-<时间戳>` 备份恢复比半新半旧更可靠。

### 二、`qrcode` 从未被声明为依赖（致命）

`index.js` 里 `await import("qrcode")` 用于扫码登录，但 package.json 的
`dependencies` 是空的，任何地方都没声明它。

**作者本机恰好有**（profile 顶层的 `qrcode` 被别的东西带进来了），所以扫码
一直正常；**别人装了插件，扫码必然失败**。

修法：放进 `optionalDependencies` —— 因为代码注释本来就说它是可选的：

> a missing `qrcode` package must cost this one feature, not the whole plugin

放 `dependencies` 会让整个安装失败，与这个设计矛盾。

### 三、可选依赖缺失被显示成「池状态不可用」

上一条的后端处理是**正确的**（惰性导入 + try/catch，错误措辞清晰）。**但前端
把它写进了共享错误行**，而那行渲染成 `Pool status unavailable: ...` ——
一个只影响扫码的可选依赖缺失，看起来像整个池子坏了。

现在扫码失败进**扫码自己的面板**，并明说「池子本身不受影响，桌面端登录照常」。

### 四、新功能：让装了插件的用户看到「有新版本」

`checkVersion` 原本比较「部署文件 vs 本地仓库」，而那个仓库路径由作者的
部署步骤写入 —— 普通用户没有它，所以 `compared: 0`、`inSync` 永远 false，
**他们无从知道该不该更新**。

早已写好、**却从未被调用**的 `fetchRemoteVersion` 现在接进了 `/version`，
带 12 秒超时与静默失败（这个路由被卡片轮询，GitHub 不通不能让面板卡住）。
新增字段 `remoteVersion` / `updateAvailable`；卡片优先显示「有新版本」。

版本比较用**版本字符串**而非文件哈希（tarball 是发布源码，比哈希会把每次
重建都报成更新）。**解析失败一律答「没有更新」** —— 版本检查的失败模式必须
是沉默，而不是让用户去覆盖一个能用的安装。

### 五、接受 `x-api-key` 鉴权头

只认 `Authorization: Bearer`，而 Anthropic SDK **默认发 `x-api-key`**，
配得好好的客户端收到 `401 missing or invalid Authorization bearer` ——
这句话说的是「你没发我要的头」，而不是「你的凭据不对」。

两个头都接受。这不是安全削弱：头不是第二因子，能设一个就能设另一个；
凭据本身仍走 `timingSafeEqual` 常量时间比较。

### 六、语言包漏键

上面新增的文案写进了组件、**没写进语言包**，于是卡片显示原始键名
`row.versionUpToDate`。而 `t?.("row.versionUpToDate") ?? "up to date"` 的
兜底**永远不会生效** —— 键缺失时 `t?.()` 返回的是**键名**，不是 undefined。

补进中英两份。并用**通用检查**（组件引用的每个键都到每份语言包找）确认
136 个键齐全 —— 这个检查当场发现了 12 个被字母-only 正则漏掉的键
（`row.regionHowTo1-4`、`row.usageLast7`、`row.autoJob_*` 等）。

### 七、新增发布前检查 `tools/check-publish.mjs`

上面两个致命问题**在本机都看不见**：一个走的是「从旧版本更新」的路径，
另一个依赖「机器上恰好有 qrcode」。

所以加了这个检查，跑三项**不依赖宿主环境**的性质：

| 检查 | 内容 |
|---|---|
| A | 每个外部导入都在 package.json 里有交代；每个相对导入的文件都存在 |
| B | 缺少**可选**依赖时插件仍能加载（在盘根隔离加载，父级链无 node_modules） |
| C | `index.js` 加载时导入的文件都在 `TRACKED_FILES` 里 |

**验证它有牙齿**，而不只是「能跑通」：把每个缺陷重新注入副本，对应检查都会
变红，且报出具体的文件或包名。不会失败的检查等于没有检查。

检查 B 在自己的输出里写明了它的局限：`peerDependencies` 由 DSH 宿主在运行时
提供，不在 `profile/node_modules` 里，宿主的解析**无法在此复现**，
所以它只证明一件事 —— 缺可选依赖不会阻止启动。

### 八、测试

全量 331/331。另有针对本版各项的独立验证：版本比较规则 16 条、
远程版本端到端 10 条（真实拉取 tarball）、qrcode 修复 16 条、
干净环境模拟、检查器有效性 5 条。

## 2.1.0 (2026-10-08)

这一版补两个同类项目都有、我们缺的功能：**模型别名映射**与**用量统计维度聚合**，
外加一处性能修复（压缩循环 O(n²) → O(n)）。

### 一、模型别名映射（modelAliases）

**痛点**：客户端发来的模型名（`gpt-4.1`、`claude`）不在池子目录里时，直接 400
`model_blocked` —— 同类项目（workbuddy-openai-proxy、KiroStudio）都有别名映射，
我们没有。

**做法**：`selection.modelAliases` 加配置，格式与同类一致：

```json
"modelAliases": { "gpt-4.1": "deepseek-v4.1-flash", "claude": "global/claude-sonnet-4.6" }
```

**目录优先于别名**：名字在目录里就直接用，别名只在目录查不到时才查 ——
上游万一哪天出了个叫 `claude` 的真模型，不会被映射抢走。
`region/` 前缀支持跨区域映射；没配的、配错的，原样走（清晰报错，不静默路由错）。
在 `runChatLoop` 里 `pool.acquire` 之前解析，三条协议路由共享。

### 二、用量统计维度聚合（usageStats）

**现状**：`requests.jsonl` 每次请求都落盘，但**没有任何聚合视图** ——
要回答"哪个模型花了最多 token、哪个账号最累、三条协议各占多少"只能翻原始日志。

**做法**：新增 `usage-stats.json`，从同一个 JSONL 派生：

| 维度 | 聚合内容 |
|---|---|
| `byModel` | count / ok / failed / promptTokens / completionTokens / totalMs |
| `byAccount` | count / ok / failed / promptTokens / completionTokens / accountLabel |
| `byChannel` | count / ok / failed（`responses` / `chat` / `(direct)`） |

**增量重建**：游标（`processedLines`）存在 stats 文件里，重启后从断点继续，
不每次全量读日志 —— 与 cooldown 账本同一套纪律。
**纯加法**：`/status` 响应多一个 `usageStats` 字段，旧卡片忽略它。

### 三、压缩循环 O(n²) → O(n)（perf）

`compactMessages` 循环里每丢 1 条消息就把全部消息重估一遍。
实测 3000 条消息压一半：**79,662ms ≈ 80 秒**。
改成预计算每条 token、循环只做减法：**268ms，297× 加速**，结果逐位一致。

### 四、测试

新增 `_verify_new_features`：27 条断言（别名 9 条 + 聚合器 16 条 + 集成 2 条）。
全量回归 332/332 全绿。

## 2.0.1 (2026-10-08)

这一版修的是一条**压缩触发链**上的三个叠加问题 —— 用户在 1.1M token 的会话上
连吃了三种报错：先 11115（超长）、压缩后变 11148（工具对断裂）、最后宿主会话
文件本身损坏（seq gap 复发）。

### 一、压缩会拆散工具调用对（根因）

`compactMessages` 与 `hardTruncate` 按**条数/下标**丢消息，完全不知道
OpenAI 格式里「assistant 带 `tool_calls`」与「后续 `role:"tool"` 带
`tool_call_id`」是一对。丢到对中间时，发出去的历史就是断的：

```
有结果没调用（孤儿结果）      → 上游 11148 拒收
有调用没结果（未应答的块）     → 上游 11148 拒收
结果早于调用（位置颠倒）       → 上游 11148 拒收
```

而 protocol-compat.js 的翻译层**有**配对保护 —— 但 DSH 走的主 chat 路径
在 index.js 里 `tool_call_id` 出现 0 次。保护只建了一半。

**修法**：新增 `repairToolPairs(messages)`，四层全部接上：

- **入口**：`prepareChatBody` 规范化后立即修复 —— 覆盖所有客户端
  （DSH / Codex / Claude Code），无论断对来自宿主损坏还是压缩副作用；
  三条协议路由共用这个函数，一处修全覆盖
- **压缩出口**：`compactMessages` 返回前修复
- **截断出口**：`hardTruncate` 返回前修复
- **分类**：11148 进 `REQUEST_FAULT_CODES` —— 轮换循环立刻停（不再拿
  8 个账号撞同一堵墙后透传），直接 400 返回真实原因

配对规则：孤儿结果丢弃；调用未被**全部**应答的 assistant 块整块丢弃
（其幸存的结果在下一轮成为孤儿一并丢弃）；结果早于调用视为孤儿。

### 二、11148 之前完全不被识别

错误码表里没有 11148，`classifyUpstreamError` 落到默认的 `client` 分类，
`kindStatus` 给 400 透传 —— 用户看到的正是原文：

```
workbuddy upstream client (http 400) after 1 account(s): {"code":11148,
"msg":"tool calls and tool results do not match, please start a new
conversation and retry"}
```

### 三、宿主会话文件损坏（seq gap 复发）

`session.v4.jsonl.zstd` 报 `released v2 row 11834 has seq gap`。**这不是
插件的文件**，是 DSH 宿主的会话日志；宿主代码里有 `recoverable` 解码模式
但 resume 走 strict。同一会话此前已坏过一次（目录里留着 `.broken-seqgap`
与 `.bak-ctxfix` 备份）。插件侧能做的（入口配对修复）已做；宿主侧建议
向 DSH 官方反馈 seq gap 的产生条件。

### 四、测试

新增 `_verify_11148`：15 条断言。**集成测试当场抓到一个真回归** ——
第一版补丁把 `prepareChatBody` 里 `developer → system` 的重命名顺手删掉了，
单元测试全绿、集成测试红了。这正是集成层存在的意义。

## 2.0.0 (2026-10-07)

这一版做的是**协议能力**与**三轮审查修复**。主版本号提升是因为对外能力变了：
池子从「只会说 OpenAI Chat」变成「同时说三种协议」。

### 一、协议兼容：新增 Responses 与 Anthropic 两条路由（新文件 `lib/protocol-compat.js`）

| 协议 | 路径 | 谁在用 |
|---|---|---|
| OpenAI Chat | `/v1/chat/completions` | DSH 本体、普通客户端 |
| **OpenAI Responses** | `/v1/responses` | **Codex**、任何 Responses 客户端 |
| **Anthropic Messages** | `/v1/messages` | **Claude Code**、Anthropic SDK |

关键设计是**翻译层与调度层分开**：`chatCompletions` 拆成「协议入口 + 共享循环」，
新协议只做请求与响应两个方向的翻译，账号轮换、冷却、熔断、积分门槛、上下文压缩
**一行都不重复**。改调度策略时三条路由同时生效，协议出 bug 也不会串到调度。

实测踩出来的几个点，都已固化：

- **工具调用必须在 `response.output` 里出现两次** —— Codex 读最终响应判断「这轮要不要继续」，
  只在流事件里发而不在 `output` 数组里，Codex 会认为模型只是说了句话，**结束回合等人输入**
- **调用与结果先配对再发送** —— 上游拒绝「结果早于调用」与「调用没有结果」，
  而客户端传来的历史里两种都真实存在
- **对话不以工具轮开头** —— 补一条用户轮在最前，而不是删掉工具调用
- **Anthropic `stop_reason` 报 `tool_use`** —— 报成 `end_turn` 客户端会结束回合，
  刚拿到的 `tool_use` 块永不执行
- **非流式与流式的 Content-Type 分开写** —— Anthropic SDK 带 `stream: false` 时按 JSON 解析
- **`previous_response_id` 明确拒绝** —— 本池不存响应历史，假装支持会静默丢掉前面所有轮次

### 二、推理模型的 token 预算地板（本轮影响最大的一条）

**症状**：`/v1/messages` 间歇性返回空内容，而 `/v1/chat/completions` 一直正常。

**定位过程**：同一会话、同一账号、交错请求两条路由 —— `chat` 8/8 有内容，`messages` 6/8。
唯一变量是翻译层，排除了模型与账号。继续量化（同一提示词，只改 `max_tokens`，各 6 次）：

```
max_tokens=16    1/6 有内容    平均 12 个推理帧    finish: length
max_tokens=64    3/6 有内容    平均 35 个推理帧    finish: length,stop
max_tokens=256   6/6 有内容    平均 43 个推理帧    finish: stop
无 max_tokens    6/6 有内容    平均 19 个推理帧    finish: stop
```

**根因**：池里是**推理模型**，思考计入 `max_tokens`。预算被思考吃光时上游返回
`finish_reason: length` 且 **`content` 完全为空**。而 chat 路由不带 `max_tokens`，
Anthropic SDK 则**必填** —— 这就是「chat 一直正常、messages 偶发空」的全部原因。

原实现的注释写着「Too small is left alone — a client asking for 64 tokens means 64」，
**这对普通模型成立，对推理模型不成立**：过小的预算不是「少给一点答案」，而是「根本给不出答案」。

**修法**：加 `MIN_MAX_TOKENS = 512` 地板。修复过程中测试抓到实现缺陷 ——
`Math.max(capped, 512)` 在模型上限只有 256 时会返回 512，**超出模型能力导致上游必拒**。
已修正为**上限优先**：超上限是确定性失败，低于地板只是概率性空回复，不能把「也许」变成「绝不」。

修复后实测：`max_tokens=64` → **10/10 有内容，`stop_reason` 全部 `end_turn`**。

### 三、三轮审查修复（26 条）

**第一轮（5 条严重）**

| 项 | 问题 |
|---|---|
| 二维码注入 | 上游返回的 QR 标记直接进 `dangerouslySetInnerHTML`，改为按 SVG 解析并剥离可执行部分 |
| 上下文压缩漏 release | `recoverFromContextOverrun` 两处 `pool.acquire` 没有配对 `release`，`inFlight` 只增不减，最终让 idle 过滤恒空、池子退化成单账号 |
| 调度偏斜 | 默认 `priority` 模式直接取 `candidates[0]`（按凭证新鲜度排序的固定列表），加权抽签与临期积分优先**全是死代码** |
| 写接口无鉴权 | 控制台 9 个写端点只校验 `Origin`，而 curl 不带 `Origin` 时**直接放行**（已实测复现 200） |
| CSS token 层未挂载 | `.dsm-workbuddy-xdpool-root` 只定义在 CSS 里、从未挂到元素上，46 处 `var(--pool-*)` 全部失效 |

**第二轮（6 条中等 / 轻微）**

冷却跨重载持久化、5xx 记账的同步 IO 改为合并落盘、状态码表加运行时兜底、
按页短路渲染、危险操作加确认、错误边界可恢复、首屏加载态、轮询退避、主题按钮显示下一态。

**第三轮（独立复核，6 条）**

> 前两轮修复完成后做了一次独立复核：两个子代理在**不知道修复记录**的前提下从零审查。
> 结果**找到的问题全部来自前两轮修复的副作用** —— 说明「改完再自查」确实有盲区。

其中 3 条是**修复自己引入的**：

- **5xx 账本写入缓存没有 TTL** —— 同文件另两个缓存都是 60 秒过期，唯独写入路径只判 `=== void 0`，
  面板一关缓存永不刷新，会在旧对象上累加并覆盖磁盘
- **「清除冷却」会被自己撤销** —— reset 同步写盘却不取消待触发的 1 秒定时器，
  期间的 `scan()` 会读回尚未被覆盖的旧文件灌进内存，待触发的定时器再把「复活」结果写回
- **成功服务的账号被重新退役** —— `noteServed` 清了内存 `authDeadUntilMs` 却不写盘，
  下次 rescan 又把退役窗口灌回来，把刚证明健康的账号踢出轮换

另有 3 条 UI：签到永远显示满分（`done` 与 `total` 同源，且宿主**根本没有 `total` 字段**）、
两个区域标签圆点串味（用当前区域的 `state` 渲染）、错误提示无 `role="alert"`。

### 四、一次自己造成的回归，以及它暴露的更深问题

上线后卡片报 `origin-not-trusted` —— 我加的写守卫**把卡片自己的请求拒了**。

**根因**：DSH 客户端插件以 `file://` 加载，浏览器对它发出的请求送 **`Origin: null`**，
而 `new URL("null")` 抛异常，`loopbackOrigin` 因此返回 false。

**修的过程中发现了更严重的**：我原来的守卫**本来就挡不住真正的攻击**。实测：

- 跨站 JSON POST **发不出去** —— OPTIONS 预检返回 405 且无 CORS 头
- 但**表单 POST 能发出去**（简单请求免预检），它带环回 `Host`（浏览器按连接地址填），
  也带 `Origin: null`（sandboxed iframe）—— 与 `file://` 客户端**无法区分**

**结论**：`Origin` 和 `Host` 都挡不住表单；表单**唯一做不到的是声明 `application/json`**。
所以真正的防线是 **content-type**。已改：写路由要求 JSON body，
前端三个无 body 的写请求（rescan / cooldowns-reset / self-update）补上声明。

### 五、其他修复

- **`formatCapacity` 只处理整除** —— `131072` 显示成 `"131072"` 而非 `"131K"`
- **`writeUsageLedger` 与 `writeServerErrorLedger` 的临时文件名固定** ——
  插件重载时新旧实例并存会互相覆盖；现全部按 pid 区分
- **5xx 读路径会用磁盘旧值覆盖未落盘的内存变更** —— 改为先 flush 再重读
- **package 列表截断到 6 个不提示** —— 补「另有 N 个」

### 六、测试

**16 套、303 条断言全部通过**。其中协议、鉴权、冷却持久化几套是**实际跑真实 HTTP**：
起真实 shim、发真实请求、打到真实上游。

### 七、修复期间的一次事故

插件目录曾被**外部重置**回 v1.99.2，全部修改与当时位于插件目录内的备份一起丢失
（后经测试脚本留在临时目录中的副本恢复）。**触发原因未查明**，重启不必然复现。
此后备份改为**双保险、存放在插件目录之外**。

## 1.6.0 (2026-09-24)

这一版修的都是「已装、已登录，插件却说找不到 App / 存不进去」这一类误报。

### 一、WorkBuddy 装在非系统盘时找不到 App（社区反馈 + 本机复现）

报错：`holds encrypted credentials but the desktop app could not provide the key`，
但 App 明明装着并在运行。

根因：Windows 只探测四个固定在**系统盘**的路径，而实际安装位置是自定义盘符 ——
本机实测两个 App 都在非默认位置，且**国际版的文件名都不一样**：

```
D:\workbuddy\WorkBuddy.exe        国内版 5.5.3
D:\workbuddyai\WorkBuddyAI.exe    国际版 5.6.2   ← 文件名都不同
```

修法（三层，按可靠性排序）：

1. **读注册表**（最权威）——安装器自己记录的 `DisplayIcon` / `InstallLocation`，
   不管装在哪个盘、目录叫什么、可执行文件叫什么都能找到；
2. 环境变量 `WORKBUDDY_APP_EXECUTABLE`（用户显式指定，优先级最高）；
3. 兜底枚举：`ProgramFiles` / `ProgramW6432` / `ProgramFiles(x86)` / `LOCALAPPDATA`，
   **外加所有固定盘符**的 `Program Files`，再向下扫一层匹配 `workbuddy*` 目录。

同时补上国际版可执行文件名 `WorkBuddyAI.exe` —— 它此前从未进过候选，
所以哪怕路径对了也找不到。

**实测验证**：注册表方案在本机正确发现两个 App，且用国内版 App 派生的密钥
能解开国际版凭据（两个 App 共用同一个构建期密钥，`keyId` 完全匹配）。

### 二、报错文案不再误导

原文案暗示「去装 App」，而用户 App 就装着。现在区分两种情况，并给出真正可执行的指引：
设置 `WORKBUDDY_APP_EXECUTABLE` 指向实际路径，并明说**重新登录无效**
（凭据本身是好的，缺的是密钥）。

### 三、读账号很慢 / 重新检测账号也报错

每次读凭据都会 spawn App 并等待 10 秒超时；一旦失败，逐个凭据文件再来一遍。
新增**失败负缓存**（60 秒）：一次失败后短期内不再重试，
既让「扫描账号」瞬间返回，也保证装上/启动 App 后无需重启 DSH 就能恢复。

### 四、「保留积分」保存报 `settings service unavailable; creditReserves was not saved`

**这是我 1.5.0 引入的 bug**：校验写入了不存在的 API。
本版 `dsh-settings` 暴露的是**按命名空间**的写入方法，没有 `set(key, value)`：

```
update(ns, patch, expectedRevision)    // 把 patch 合并进该命名空间的用户层
replace(ns, section, expectedRevision)
mutate(ns, ops, expectedRevision)
```

现在改用 `update(ns, { [key]: value })`。**「await + 回读校验」的理念保持不变**
（它确实抓到了问题，只是抓错了原因）——写入后仍然回读文档比对，不一致就报错。

### 测试

188 → 195（新增 `app-location.test.ts` 7 例：注册表优先、override 优先、
多盘符与文件名变体、macOS 仍走 bundle 而不碰注册表）。

## 1.5.3 (2026-09-24)

### 内核依赖对齐 DSH 实际版本，消除「需要 0.1.7」的歧义

`devDependencies` 里十个 `@deepseek-ai/dsh-*` 包原先钉在最老的版本
（`0.1.1-rc.2` / `0.1.2-rc.1`），而插件实际运行在 DSH Desktop 2.0.13 捆绑的
**`0.1.5-rc.2`** 上——开发环境与运行环境不一致，正是姊妹项目踩过的那类坑
（用旧类型构建、或反过来用新类型构建跑在旧内核上）。

现在钉到 **`0.1.5-rc.2`**，与实际运行内核一致。`dsh-client-runtime` 例外：该包
已停止发布（最后版本 `0.1.1-rc.2`），保持不动。

**peerDependencies 未改**，仍是最宽的 `>=0.1.1-rc.1 <0.2.0`。实测（semver）该范围
同时接受 `0.1.5-rc.2` 与 `0.1.7-rc.1`，比 `^0.1.5-rc.1`、`^0.1.5-0` 都广，所以
插件本身从来没有版本不兼容——市场页面上那句「需要 DSH >=0.1.7-rc.1」是市场对
预发布范围的判定方式所致，不是插件声明有误。

内核 `0.1.7-rc.1` 目前只在 npm 的 `next` 通道（`latest` 仍是 `0.0.1-rc.1`），
属于预发布；内核版本由 DSH Desktop 应用捆绑，需等官方发新版桌面端才能跟进。

### 测试

仍为 188 通过（本次只改依赖声明，无代码改动）。

## 1.5.2 (2026-09-24)

### 修掉测试对运行时区的依赖（发布流程在 CI 上红了）

1.5.0 把签到的小时判定改成显式 `Asia/Shanghai` 之后，测试却仍在用
`new Date(2026, 8, 7, 10, 30)` 构造时刻——那是**本机时区**的 10:30。本机在 UTC+8 时
恰好等于北京时间 10:30，所以本地全绿；换到 UTC 的 CI 上，同一时刻变成北京时间 18:30，
于是 `isFireHour(..., [10])` 返回 false，四个用例集体变红。

**代码没问题，是测试的构造方式错了**：用一个「运行机器时区」的输入去断言一个
「固定北京时区」的实现，结论必然随机器而变。

修法：测试里所有时刻改用 `beijing(y, m, d, h, min)` 显式构造（`Date.UTC(h - 8)`），
并新增一条用例专门钉住「同一个瞬间在任何时区下判出同一个小时」。

验证：`UTC` / `America/New_York` / `Asia/Shanghai` / `Europe/London` **四个时区各跑一遍，
均 188 通过**。

（顺带修好一处漏掉的 `AUTOMATION_JOB_KINDS` import——它让「卡片与调度器任务列表一致」
那条用例在 UTC 下失败。）

## 1.5.1 (2026-09-24)

### 「保留积分」改成填完点保存，并且告诉你存没存上

上一版修好了写入不落盘却报成功的问题，但交互仍然不好：输入框**一失焦就自动提交**，
你既没有明确的「保存」动作，也不知道到底有没有生效——失败了只在卡片顶上飘一行提示，很容易错过。

现在：
- 输入框只是草稿，**不再失焦自动提交**（回车或点「保存」才会写入）。
- 「保存」按钮只在草稿与已存值不同时可用，避免误点与空提交。
- 结果**就地显示在按钮旁边**：保存中… / 已保留 N 积分 / 保存失败，请重试。
- 保存成功后本地立刻定格新值，不用等下一次轮询——这是「重开又不显示」观感的直接解法。
- 输入框加了聚焦态（绿色描边），宽度从 76px 调到 84px。

### 测试

187 通过（本次为客户端交互改动，未新增用例）。

## 1.5.0 (2026-09-24)

这一版修四处实报问题，其中第一处直接决定 Mac 用户能不能用。

### 一、Mac 上 WorkBuddy 5.6.2「获取不到账号」——桌面端加密了凭据

现象：Mac 上 App 装着、也登录着，插件却一个账号都列不出来。

根因不在路径，在**加密**。WorkBuddy 桌面端从 **5.6.0 起**把 auth 文件里的
`accessToken` / `refreshToken` / `nickname` 从纯字符串改成了加密信封
（`{"$wbEncrypted":1,"envelope":"…"}`，AES-256-GCM），而且 **macOS 与 Windows
同样如此**——此前「只有 Windows 加密」的判断是错的。原来的读取代码是
`typeof auth.accessToken === 'string'`，遇到信封对象直接判定「没有凭据」，于是
把「已登录」误报成「未登录」。

修法（`src/at-rest.ts` 新增 + `src/accounts.ts` 接入）：
- 向**本机已安装的 App 自己**索取字段密钥：用 `ELECTRON_RUN_AS_NODE` 跑它的原生绑定
  (`electron_browser_workbuddy_storage.loggerGet()`)，就地派生密钥。插件不内置任何密钥
  副本，密钥只在进程内存缓存、不落盘。
- 二进制定位改为**问 bundle 自己**：macOS 的 `CFBundleExecutable` 是 `Electron`
  而不是 `WorkBuddy`，按 App 名拼路径永远找不到 App。候选含国际版 `WorkBuddy AI.app`，
  并支持 App 被归入 `/Applications/子目录/`，扫到的候选先用 `CFBundleIdentifier`
  确认身份才执行（每个 Electron 应用的二进制都叫 `Electron`，只按名字匹配有风险）。
- **「未登录」与「登录信息读不出来」不再共用一句话**：加密但拿不到密钥时抛
  `WorkBuddyEncryptedCredentialError`，文案指向「装 App / 用 `WORKBUDDY_APP_EXECUTABLE`
  指定位置」，并明说**重新登录没用**——因为凭据本身是好的。

### 二、签到到点不跑

两个独立原因，都会让 09:00 的签到静默错过：
- **时区**：判定用 `date.getHours()`（本机时区）。活动窗口按北京时间定义，机器时区不是
  北京时就会错点。现改为显式 `Asia/Shanghai`（`AUTOMATION_TIME_ZONE`）。
- **错过不补**：原来要求「当前小时正好等于配置小时」。DSH 在 09:00 没运行（或笔记本睡过去了），
  10:00 再启动时 `10 ∉ [9]`，当天就再也不跑。现改为**补跑**：只要配置的小时已过、且该时段
  当天未跑过，下一次 tick 立即执行。

### 三、字体太淡 + 时间显示不全

- 自动化面板里时间戳（`上次运行` 那列）被左侧名称以固定 `72px` 挤掉，且没有 `nowrap`，
  长日期会被换行/截断。现给该列独立的宽度策略与 `white-space:nowrap`。
- 一批文字用了过淡的 `#8a97b5`（`auto-hint` / `auto-total-label` / `earned-label` /
  `auto-switch` 等）与 11px 字号，对比度不足。统一提到次级色 `#c6c9d0`、字号 12px。

### 四、「保留积分」填了数值、重开还是 0

根因是**写入没有校验**。`setSetting` 原来是 fire-and-forget：不 await、不问结果，
于是「settings 服务 resolve 了但值没落盘」这种失败会**被报告成保存成功**，卡片显示已保存，
下次读取又变回 0——用户无法判断到底有没有生效。

修法：`setSetting` 改为 async，**await 写入 + 回读文档校验**，不一致就抛错，
由路由返回失败、卡片显示出来。比较用忽略键序的深比较（`stableJsonEqual`），
否则两个内容相同、键序不同的对象会被误判为「没落盘」。四处写入（保留积分、账号启停、
模型选择、积分台账）全部走这条路径。

### 测试

新增 16 例，总数 171 → **187**：加密凭据 7 例（含「不可解密必须报 ENCRYPTED 而不是未登录」、
「密钥不对不能返回垃圾」）、落盘校验 6 例（含「setter resolve 但没存必须抛错」）、
签到补跑 2 例、以及既有的调度/凭据用例随语义更新。

### 溯源

`src/at-rest.ts` 移植自 [dingminhua/dsh-connect-workbuddy](https://github.com/dingminhua/dsh-connect-workbuddy)
（MIT, Copyright (c) 2026 LaoDing）——该模块最先定位并修复了「5.6.0 起 macOS 也加密凭据」
（其 issue #15 真机取证）。移植保留其全部判定逻辑，未作改动。

## 1.4.1 (2026-09-24)

### 修了：hy3 超长对话还是会弹 400

1.4.0 让溢出消息能被 Harness 认出、并给 shim 加了本地压缩，但 hy3 仍然会爆。根因是
**窗口值写错了**：catalog 里 hy3 的 `contextWindow` 填的是 `200_000`，而它真实上限远小于
此。shim 压缩时按「估算 token 数的一半」设预算（约 100K），DSH 压力触发也按 200K 算，
两侧都以为 200K 够用，所以压缩到 100K 仍远超真实窗口，重试再次溢出。

修法：
- catalog 里 hy3 的窗口改为真实值 `32_000`（同步把 `maxOutputTokens` 从 128K 调到 8K）；
- `recoverFromContextOverrun` 不再用「估算一半」，而是用模型**真实**窗口算预算
  （`realWindow * 0.8 - 2048`），并在调用处把 catalog 的窗口传进去。

这样无论 DSH 外层还是 shim 内层，都按真实窗口压缩，不会再把压过的 prompt 发到真实窗口之外。
- 新增 `context-budget-real-window.test.ts` 钉住这个回归（含「hy3 不再声明 200K」）。

## 1.4.0 (2026-09-24)

### 长对话不再撞死在上下文上限上

以前聊到一定长度，就会弹出一个 `400 context_length_exceeded` 然后被送回主页，只能重开会话。
现在会自动收缩上下文继续跑，不再打断你。

这里其实有两层保险，各自管不同的情况：

**第一层是 Harness 自带的。** DSH 本来就装了 `compaction-basic`，它会在发请求之前先算一遍 token
压力，超了就摘要、重试。问题是它认错误的方式是「看这段文字像不像上下文溢出」，而插件原来报的是
一句友好英文 —— `the conversation exceeds <模型名>'s context window` —— 恰好是它唯一认不出来的
那种写法。于是它以为这是个普通的坏请求，跳过了恢复，直接把 400 抛给你。

（顺带一个坑：上游 WorkBuddy 自己那句 `input length too long`／业务码 `11115`，同样不在它的
识别清单里。所以「把上游原话原样透传」这条路也走不通，必须主动改写成它认得的措辞。）

现在溢出时会输出它认得的写法，Harness 的自动摘要就接上了。

**第二层是插件自己的。** 就算 Harness 那层没兜住（比如窗口值报得不准，或者你一口气粘了个巨大
文件），插件会自己压缩一遍再重试一次：先丢最旧的回合，保留 system 和最近几轮；还放不下就把被丢
掉的回合交给模型做个摘要塞回去；再不行才硬截断。摘要这一步哪怕失败也只会降级成直接截断，绝不
会反过来让你的这一轮请求失败。

### 「API 密钥无效」不再把所有账号卡死在第一个上

账号池的本意是：某个号不行就换下一个。但错误分类里有个漏洞 —— HTTP 401 只有在响应体里恰好
出现两条特定标记之一时，才会被认成「登录态失效」（可刷新、可轮换）。上游换个说法，比如
「api密钥无效」、`invalid api key`、`unauthorized`，就掉进了兜底的 `client` 类。

而 `client` 在轮换循环里是**终态**：直接 `break`，不再试后面的号。结果就是一个坏掉的号把整个池
钉死在第一个账号上，2/3/4 号全都白装着。

现在 401 和 403 无条件算「登录态失效」—— 刷新 token 然后换下一个号。另外把常见的中英文失效措辞
也补进了标记清单，这样即便状态码不是 401（比如被包在 200 信封里）也还能认出来。

### 其它

- 顺手修了个压缩逻辑里的真 bug：它用同一个变量同时表示「留下来的」和「被丢掉的」，结果明明已经
  砍到只剩几条，却报告「没有变化」，导致摘要功能整个跳过、根本没执行。
- 新增两组测试：`context-overflow-contract.test.ts` 逐字复刻了 Harness 的错误匹配规则（它将来改
  措辞时这个测试会变红，提醒你同步改）；`upstream-error-classification.test.ts` 钉住了上面那个
  401 分类回归。

## 1.3.0 (2026-09-23)

上一版把八类任务链接了进去，这一版修的是**「接进去了但你看不见」**的问题——功能在跑，界面上却没显示，等于白做。

### 猫猫旅行一天只跑一趟，等于坏了一半

旅行的流程是「派出去 → 回来领奖」，需要**两趟**。原来默认时段只配了 12:00 一个点，意味着猫早上出去之后，**要等到第二天**才有人管它。

改成 **09:00 + 21:00 两趟**（早上派出去，晚上回来领）。同时把每个任务的「今天跑过了」判断从**按日期**改成**按时间点**——按日期判断会把晚上那趟直接吞掉，这个守卫跟多时点本身是冲突的。单时点任务（签到、上报、任务奖励、连登）行为不变，同一小时内重复检查仍然不会重复跑。

> 参考项目的默认值就是 `[9, 21]`，注释里写的理由是「一趟派出 + 一趟领奖闭环」。

### 卡片现在告诉你「具体领到了什么」

原来每个任务只显示「日期 · 账号数」，回答不了「我最在意的那个任务领到了没」。

现在会**列出这一轮实际领到的奖励名**：

- 任务奖励 → 列出台任务标题（如「体验设计创意模式」「召唤 3 次专家团」）
- 每日签到 → `签到 +100`
- 猫猫旅行 → `猫猫旅行 +10`

连登奖励还没到解锁天数时，会显示**还差几天**（如 `7d in 4d`）——所有档位都是未解锁属于正常状态，但只写「未解锁」会让人以为坏了。

### 修掉「猫猫旅行永远不显示」

有个真 bug：积分自动化面板里只显示签到 / 上报 / 任务 / 连登四行，**猫猫旅行那行永远不出现**，尽管它确实在跑。

根因是那行任务的判断逻辑里，**列表本身就是缺的**——界面渲染一行一个任务，而列表里没有 travel，分支里也没有，类型定义里同样没有。这类「加了功能忘了加列表」的失败模式是**静默的**：任务照跑，用户看不见，也不会报错。

除了补齐三处，还加了个**防回归测试**：卡片的任务列表必须和调度器的任务列表逐项相等、顺序一致。这个不变量之前没人守。

### 其它

- 行内文案「未排程 / 尚未执行」改成「当天不跑 / 还没跑过」，原来的说法不好懂。
- 补上中英两份缺失的「猫猫旅行」标签（之前那行显示的是原始 key）。
- README 重写（中英双语）：按「多账号池」和「积分自动化」两块组织，把 13 个任务名列出来、实测数据写进去，并把几个踩坑结论翻译成大白话。
- 截图更新：卡片全貌换成含自动化面板的新版，另加一张自动化面板特写。
- 测试从 134 增至 139。

### 已知限制（未变）

- `Expert_Philanthropy`（公益专家）需要真实捐款，不做。
- `black_cat`（夜猫子）只在 23:00–08:00 计分且无积分奖励，不做。
- `Model_chat_GLM5.2` 与 `wb_wechat_oa_subscribe_task` 留待下个版本。
- `Expert_team_use_3` 偶发卡在 2/3（怀疑单账号当日额度，跨天恢复，未验证；新账号不受影响）。

## 1.2.0 (2026-09-23)

把成长中心剩下的**八类客户端任务**也接进自动化。这些任务在任务中心里写的是「升级桌面客户端后点击某个入口」，听起来只有人坐在真实客户端前才能完成；实际上计分器看的是**行为事件流**，只要事件形状对、指纹对，任务就会涨进度。这一轮把每条链都在真实账号上跑通并回读确认了计分。

### 新增的任务链

| 任务 | 积分 | 判据 |
| --- | --- | --- |
| 探索优秀灵感 | +100 | `web_element_click` + `playbook_cta_click` + `playbook_prompt_send` 事件组（「发提示词」才是判据，不是卡片曝光） |
| 使用 5 个模板 | +100 | 五组 `agent_task_created_with_template` + `template_used`，判据是**五个不同模板**，所以一次要发五组 |
| 尝鲜热门技能 | +100 | 真实对话（**服务端** requestId）+ `skill_info`（润泽小馆·日报撰写），响应要标成 `finishReason: tool_calls` |
| 体验「和平精英」主题 | +100 | `appearance/set` 存主题 + `appearance_skin_apply` 事件，两者缺一不可 |
| 体验资料库 | +100 | 走 **web 指纹**上报 `library_doc_intro_click` |
| 召唤 5 次专家 | +100 | 专家市场真实 id + 召唤链 + 带 `X-Expert-Id` 的真实对话 |
| 召唤 3 次专家团 | +100 | 同上，`expert_type=team` |
| 体验轻量云专家 | +100 | 同上，但用事件要 `mode: LOCAL`、`type` 留空、`cost=0` |

### 这一轮踩到并修掉的两个坑

**专家链之间必须留间隔。** 连着发两条专家使用，计分器会判成**同一次会话**，只涨一个进度。实测：间隔 300 毫秒时两条链只计一条，拉到 6 秒后每条都计。专家任务因此改为链间固定 6 秒（`EXPERT_SUMMON_GAP_MS`，测试里置 0）。

**三类指纹不能混用。** 计分器按任务认不同的指纹家族：`Library_read` 只认 web 指纹，用桌面指纹发同样的 `web_element_click` 会被接受然后丢弃。事件链现在自带「走哪个通道」，由调度器分流到 `reportDesktopEvents` 或 `reportWebEvent`。

### 其它改进

- 事件链从调度器里搬到了独立的 `task-events.ts`：调度器决定**什么时候**发，这个模块决定**发什么**，每条链都是纯数据，好读也好测。
- `WorkBuddyScheduler` 及其常量现在从包入口导出，方便直接写脚本验证，不用绕过卡片走 HTTP。
- 新增 64 个测试（`task-events` 21 个 + 调度器链路 22 个 + 专家间隔等），全量 134 个通过。

### 已知限制

- **`Expert_team_use_3` 有个号停在 2/3**：该账号当天已用掉两次专家团，第三次不再计分，换未用过的专家团也不涨。怀疑是该任务对单账号有当日额度，跨天恢复，暂未确认。新账号不受影响（实测 0/3 → 3/3）。
- **`Expert_Philanthropy` 不做**：需要真实捐款，没有可绕过的路径。
- **`black_cat` 不做**：只在 23:00–08:00 计分，且纯对话无收益。
- **`Model_chat_GLM5.2` 与 `wb_wechat_oa_subscribe_task` 未接入**：实现路径已明确（前者要真实 glm-5.2 对话 + 对齐模型字段上报），留下个版本。

## 1.1.0 (2026-09-23)

新增**积分自动化**：插件可以在后台替你完成成长中心的日常动作，不用每天手动点一遍。

### 它是怎么工作的

开启后，调度器每分钟醒一次，到点就跑当天的任务，每个任务每天只跑一次（按本地日期记「今天已跑」，过零点自动重置）。四个任务各有独立的执行时段，默认这样安排：

| 任务 | 默认时段 | 做什么 |
| --- | --- | --- |
| 每日签到 | 09:00 | 领取当天签到奖励 |
| 活跃上报 | 10:00 | 上报一次对话活跃 |
| 任务奖励 | 11:00 | 报名开放任务 + 领取已达标的奖励 |
| 连登奖励 | 12:00 | 连登档位兑换 + 抽奖（本轮先占位，下轮接入） |

**为什么上报排在任务之前**：上报会点亮成长中心的任务进度，后跑的任务那一趟才能读到刚涨上去的计数。顺序反了就会出现「进度明明到了却没领到」。这不是随手排的，是实测出来的。

### 一、任务中心自动领取

每个账号走一遍：拉任务列表 → 把还没报名的任务批量报名 → 把已达标的奖励逐个领掉。卡片上汇总显示本次领取了几个任务、加了多少积分。

两个动作都是**幂等**的，重复跑不会重复入账：报名对已报名的任务返回成功，领取对已领过的返回 `already_claimed` 并记为成功。所以某个账号中途失败、下一轮重跑是安全的。

### 二、活跃上报

按客户端 `chat_request_send` 事件的完整形状上报（37 个字段），而不是只发最小几个字段——上游对「字段不全」的表现是**返回 200 然后静默丢弃**，所以字段必须发全，且必须带 `userId`。

上报成功后会回读连登天数做验证。这里有两个实测踩到的坑，都已规避：

- 连登接口的路径**不带 `/v2` 前缀**（和任务的 `/v2/activity/growth/*` 不一样）。用错前缀不会 404，而是返回一个没有 `streak` 字段的响应；
- 天数藏在 `data.streak.days` 里，读平铺的 `data.days` 会永远得到 0，从而把每一次成功的上报都误报成「静默丢弃」。

另外，连登计数是**异步写入**的：上报后立刻回读可能还是旧值（实测某账号上报瞬间读到 0、一分钟后读到 1）。所以回读为 0 时只记一条提示日志，**不重试**——上报本身按天幂等，反复重发只会浪费每天一次的名额。

### 三、只碰该碰的账号

- **国际版账号全部跳过**：global 域没有成长任务体系，调用只会产生噪声。
- **你在卡片上关掉的账号跳过**。
- **正在冷却的账号跳过**。
- **一个账号失败不影响其他账号**：出错的那个跳过，继续跑下一个，并在汇总里记下失败数量。

账号之间默认间隔 800ms 串行执行，避免一排账号同时打上游。

### 四、卡片上的自动化面板

账号卡片新增「积分自动化」区块：一个开关控制总开关，开启后才展开显示各任务的执行时段和上次执行结果（日期 · 成功数/失败数）。

开关默认**关闭**——后台自动发请求这件事应该是你主动开启的。关闭状态下不会发起任何后台请求。

### 配置

配置项 `automation`，对应卡片上的开关：

| 字段 | 默认 | 说明 |
| --- | --- | --- |
| `enabled` | `false` | 总开关 |
| `checkinHours` | `[9]` | 签到时段 |
| `reportHours` | `[10]` | 上报时段 |
| `taskHours` | `[11]` | 任务时段 |
| `streakHours` | `[12]` | 连登时段 |
| `exhaustCooldownMs` | 30 分钟 | 账号额度用尽后休息多久 |

### 实测结果

在真实账号上验证了完整链路：4 个国内账号各领到 1 个任务，合计 **+600 积分 +23 能量**；紧接着再跑一次，四个账号全部领取 0、入账 0，确认幂等。上报后任务进度确实从 3/5 涨到 5/5，验证了「上报点亮任务」这一步是真的。

## 1.0.1 (2026-09-23)

修复两个用号逻辑上的缺陷，并把账号卡片重新排了一遍。

### 一、「当前使用」显示的账号不对

卡片上显示的账号，是你**最近一次实际在用**的那个吗？之前不是 —— 它显示的是「**准备尝试**」的账号。

举个例子：某个账号积分用光了，插件去试它、失败、自动换到另一个号继续服务。但你确实在用（换号成功了），卡片却还显示那个已经废掉的号。

现在改成**只有请求真正成功**才记录，所以显示的永远是你实际在用的那个。

### 二、账号积分用尽时，会直接把错误抛给你

上游有两种"不让用"：

| 情况 | 含义 | 之前的表现 |
| --- | --- | --- |
| **频率限制** | 这个号暂时被限流，等会儿能恢复 | 正确：冷却这个号，**自动换号** |
| **额度用尽** | 这个号这个周期的积分花完了 | ❌ **直接报错给你**，不换号 |

现在额度用尽也会**自动换到有积分的账号**，并把那个号整体停用 30 分钟（不是只停用某个模型）。请求不会再因此失败。

### 三、账号卡片排版重做

- 每个账号的**开关**做成了胶囊按钮（和「账号使用方式」同一套样式），一眼能看出是开还是关
- 账号卡**分层更清楚**：标题行（名字｜状态｜开关）→ 分隔线 → 信息与积分两栏
- 去掉了多余的边框和重复信息（不再显示 `www.workbuddy.cn` 这类域名 —— 上面的区域标签已经说明了）
- 新增顶部「**当前使用**」提示条，一眼看到正在用哪个号

## 1.0.0 (2026-09-21)

这一版把「账号」和「用号方式」都交给你控制。

### 一、可以停用不想用的账号了

账号列表里每个账号右侧新增一个开关，关掉它这个账号就**不再参与请求**。

- 关掉的账号仍然显示在列表里（变灰），随时可以再打开
- 设置会被保存，**重启 DSH 后依然有效**
- 只影响路由，不会删除或改动你的登录凭据

### 二、新增「均衡」用号模式

原来的两种方式都保留，另加一种：

| 模式 | 行为 |
| --- | --- |
| **优先**（默认，行为不变） | 一直用同一个账号，直到它被限流才换下一个 |
| **均衡**（新增） | 每个可用账号都参与抽取，**闲置越久权重越高** |
| **轮换** | 严格轮流，把额度摊平 |

**为什么需要「均衡」**：默认的「优先」会死磕第一个账号，把它打到限流才换 —— 如果你有 5 个号，其余 4 个基本闲着。切到「均衡」后请求会自然分散到各个账号，**更不容易撞限流**，可用时间更长。

在卡片顶部「账号使用方式」里切换，即时生效。

### 其他

- 显式选定的账号（如卡片上「下一个」标记的那个）在三种模式下**都会被优先使用**
- 处于冷却中的账号在「均衡」模式下**一定不会被选中**，冷却结束自动回到抽取池

## 0.4.5 (2026-09-21)

本版**功能与 0.4.4 完全相同**，只是换了一条发布通道。

### 为什么会有这个版本

0.4.4 的改动没能通过 npm 发出去：账号的两步验证绑的是**安全密钥（passkey）**，而 npm 命令行发布只接受**认证器 6 位数字码**，两者不通用。

现在改为由 **GitHub Actions 自动发布**：给仓库打一个 `v*` 标签，GitHub 就用 OIDC 直接把当前版本发到 npm —— **不需要任何 token，也不再需要验证码**。

所以请以 0.4.5 为准，它包含了 0.4.4 的全部修复（图文模型贴图、国内版/国际版模型勾选各自独立）。

### 顺带修好的构建问题

有 3 个依赖此前只在开发机上"碰巧"存在（靠历史安装残留），别人克隆仓库后跑测试会直接失败。现已正式写进 `package.json`，干净环境也能正常构建与测试。

## 0.4.4 (2026-09-21)

这一版修两个毛病：给「支持图片」的模型贴图会报错，以及国内版和国际版的模型勾选会互相覆盖。

### 一、贴图报错

选「图文」模型贴图时，会报 `pi-ai image input requires the durable attachment service`。

上一版把模型真正的图片能力修对了，贴图于是改走「原生图片通道」。但这条通道要求插件把宿主的**图片存取服务**接上，而插件一直没接 —— 以前所有模型都被当成「不支持图片」，这条路根本走不到，所以问题一直藏着。

现在把这一步补上了：插件接上宿主的附件服务与文件服务，图片能被正常读取并随请求发出去。这只是「把该接的线接上」，图片本身仍是原样发给模型。

### 二、国内版和国际版的模型勾选不再互相覆盖

之前两个版本共用同一份模型勾选，所以：在国内版勾好几个模型保存，再切到国际版勾另一套保存，**前面那份就被覆盖了**，两边最终都变成后保存的那一套。

原因是两边的选择存在同一处，写入时也是往同一个地方写。现在改成**各自独立保存**：国内版一套、国际版一套，互不影响。切 tab 时未保存的改动也不会串到另一边。

升级后原来的那份勾选会被两边同时沿用，不用担心配置丢失 —— 之后各改各的即可。

## 0.4.2 (2026-09-19)

这次主要修了三个毛病。

### 一、国际版账号终于能被识别了

之前国际版账号一直检测不到。原因是筛选登录文件时只认「点号」拼出来的文件名，而国际版客户端登录后生成的文件是 `workbuddy-desktop-ai.info`（中间是连字符），于是被整个跳过了。

现在改成只看文件后缀，不管文件名长什么样都能收进来。实测国内版 4 个、国际版 1 个账号都能正常识别。

### 二、国内版和国际版不再共用同一份模型列表

之前两个版本共用同一份模型清单，而且这份清单只从国内版账号拉取 —— 换句话说，国际版看到的其实一直是国内版的模型。

现在两个版本各查各的：

- 国内版：16 个模型
- 国际版：21 个模型（之前只有凑数的 10 个，而且内容还是国内版的）

国际版独有的 Auto / Fast / Balanced 这些模型现在也能正常显示。

顺带修了国际版读取模型的方式：它的接口地址和客户端标识跟国内版都不一样，之前照搬国内版的写法，国际版那边会直接报错，所以才一直退回那份凑数的清单。

### 三、模型选择器里同一个供应商不再被拆成两组

之前模型选择器里「WorkBuddy XD Pool（国内版）」「（国际版）」会各出现两次，免费模型和付费模型被分到不同的组，中间还夹着别的插件，看着像重复注册了。

根因是插件把每个模型都上报成「不支持图片」。宿主上如果装了图片增强类插件，它会给这些模型再补一条**名字一模一样**的条目，于是同一个名字就出现了两遍。

现在按上游真实的能力上报，分组就合并回来了。

另外卡片里的「图片输入」勾选也改了语义：勾选只表示**额外**支持图片，不会再反过来把没勾选的模型降级成「不支持」。

## 0.4.0 (2026-09-16)

本次更新来自两条用户反馈与一次上游兼容性对齐：账号现在可以**按顺序逐个用尽**（不再平均分摊），积分包**逐条显示具体到期时刻**，并修掉了一处会让所有接口返回 401 的凭据选择缺陷。

### 新增

- **账号使用方式可切换（优先 / 轮换）**：卡片状态行下方新增开关，默认**优先模式**。

  - **优先模式**：始终由同一个账号服务，直到它被限流才顺延到下一个；冷却结束后它**立刻回到队首**接管 —— 该账号的积分在冷却期间并未被消耗，所以无需从头排队。
  - **轮换模式**：保留原来的平均分摊行为，供希望把额度摊平到各账号的用户选择。
  - 切换**即时生效**并写入插件设置，**对所有账号、所有切换状态通用**，不需要重启宿主。
  - 优先级顺序是确定性的：桌面 App 当前登录的账号 → 上游签发时间较新者 → 存储过期时间较晚者。此前顺序取决于文件名字典序，实际会出现 `0, 2, 1` 这类非预期排列。

- **积分包逐条显示到期时刻**：原先只给出「3 天内到期」的合计数，看不到具体时间；现在每个积分包单独标注它的到期时刻（精确到分钟，例如「到期 09/19 15:36」），3 天内到期的以琥珀色高亮。月度周期套餐显示下次刷新时刻（「刷新 10/01 00:00」）。

  - 之所以精确到分钟而不是只给日期：上游发放一次性礼包的到期时刻是**任意的钟点**，并非「过 0 点即失效」，只显示日期会让人误判。

### 布局

- **积分包列表改为两行网格**：包名与数量在首行左右分栏，到期时刻在次行跨栏并与包名左对齐。此前到期时刻被挤到第二行且从容器左边缘起排，列表看起来参差不齐。

### 修复

- **同一账号存在多个凭据文件时会选中已失效的那一个，导致积分 / 签到 / 模型全部返回 401**。此前按**存储的 `expiresAt` 最大**来挑选凭据，但 `expiresAt` 描述的是「签发时有效期有多长」，**不代表上游仍然接受** —— 上游吊销 token 时不会同步改写该字段，于是一个早已失效的备份可以声称比真实可用的文件**更晚过期**，从而被长期选中。

  - 现改用 **`auth.lastRefreshTime`（上游自己的签发时间）** 作为新鲜度判据，并在解析凭据时读入该字段。排序优先级：① 桌面 App 当前登录的 live 文件 → ② 签发时间较新者 → ③ 存储过期时间（仅作为文档缺少签发时间时的回退，保证比较是全序的）。

- **国际版登录域名识别不全**：参考桌面客户端自身的国际域名清单（`workbuddy.ai`、`workbuddy.cc`），并补充 CodeBuddy CLI 使用的 `codebuddy.ai`。此前只识别 `workbuddy.ai`，落在其他拼写上的国际账号会被误判为国内版，token 被发往国内网关而在 openresty 层被拒绝。

- **国际网关写死单一域名**：国际版账号按品牌域名区分且**互不通用**（在 `codebuddy.ai` 签发的 token 会被 `workbuddy.ai` 网关拒绝，反之亦然），因此网关地址改为**跟随凭据自身的域**，未识别的域名回落至桌面端网关。chat / billing / referer / 模型目录四处一并生效。

- **上游以 HTML 页面拒绝凭据时给出可执行提示**：识别 openresty / APISIX 的鉴权拒绝（401/403 且响应体是 HTML），改为提示「凭据已被上游网关拒绝，通常说明用的是旧登录留下的失效凭据；请重新登录 WorkBuddy 桌面端后在卡片中选择该账号」，不再原样抛出 HTML 片段。非鉴权类的非 JSON 响应保持原有的通用提示。

- **部分模型不显示思考档位**：上游部分模型的推理元数据使用**单数形式**（`effort` 而非 `supportedEfforts`），此前该形态会被直接丢弃。现将其规范化为插件已理解的复数形状，并携带声明的档位到 `defaultEffort`。

### 测试

- 新增 `tests/pool-priority.test.ts`（10 例）：优先模式下连续请求命中同一账号、仅在该账号冷却后顺延、冷却结束后回归队首、按模型冷却不影响其他模型；轮换模式的轮转与运行时切换；凭据新鲜度的四类排序（live 优先、签发时间优先、缺失签发时间时回退过期时间、秒/毫秒单位归一化）。
- 修正 `tests/failover.test.ts` 中依赖轮转顺序的限流桩：改为按**已出现的不同凭据数**计次，不再假设「token 序号即账号位置」，因此与账号排序解耦。
- 全套 **36 个测试通过**。


## 0.3.0 (2026-09-16)

本次更新把卡片界面按参考插件的形态重做了一遍，并补齐了国内版 / 国际版的完整分离。

### 新增

- **国内版 / 国际版 拆成两个独立供应商**：`workbuddy-xdpool`（国内版）与 `workbuddy-xdpool-global`（国际版）分别注册为独立 provider，模型选择器里各占一个分组。两条链路各有独立的回环端点（各自端口与密钥），互不影响；账号按登录域名严格归属各自区域，国内版请求绝不会走国际版账号，反之亦然。

- **卡片顶部新增「国内版 / 国际版」切换栏**：两个 tab 固定显示，各自带一个健康状态指示点。未登录的那一侧显示明确的空状态与**该区域的登录步骤**（含国际版客户端名称、可用的登录方式、网络环境要求），而不是一片空白。

- **模型管理**：模型列表支持逐项操作 —— **勾选启用 / 停用**、**图片输入**单独开关、**上下文窗口**在「默认上限」与「模型原生上限」之间切换（仅对原生窗口超过默认值的模型显示）。改动为草稿式，需点「保存」生效，另有「放弃修改」。保存后**无需重启宿主**即可在选择器里生效。

- 卡片截图新增「国内版 / 国际版切换」一张（中英 README 均已引用）。

### 变更

- **账号区与积分区重做排版**：账号信息、积分包明细、合计大数字与签到按钮改为分区网格布局，数字更醒目，签到按钮位于合计下方，不再多个区块横向挤在一起。
- 模型行现在同时展示输出上限与推理档位（上游提供时）。

### 修复

- **切换 tab 后仍显示另一区域账号**：`refresh` 回调此前在依赖数组为空的情况下闭包引用了当前区域，导致切换后请求的始终是首次的区域。现改为把区域作为参数传入（回调身份稳定），并**按区域分别保存各自最近一次状态** —— 切换 tab 时不再闪空白，隐藏 tab 的状态指示点也持续有效。
- **国际版域名识别不全**：桌面客户端把 `workbuddy.ai` 与 `workbuddy.cc` 同列为国际版域名，此前只识别前者，登录落在 `.cc` 的账号会被误判为国内版并请求错误网关。现已一并识别。
- **模型勾选控件不可用（显示为灰色）**：客户端注册时未注入设置作用域，导致卡片判定为只读。现注入 `settingsScope` 并通过它写入模型选择 —— 该选择保存在插件设置中，**对所有账号、所有切换状态通用**，设定一次即可。
- 保存的模型选择改由宿主的**模型发现接口**下发，使保存结果即时反映到模型选择器，而无需重启。

- **两个 provider 一直显示「加载失败」**：注册适配器时构造的 provider profile 漏了 modelErrors 字段。宿主解析每个模型时都会读这个 Map，于是每次解析都抛 `Cannot read properties of undefined`，模型目录把它渲染成「{provider} 加载失败」。现已补上该字段（与参考插件一致），两个区域的模型解析全部恢复正常。
- **provider 注册后设置页读不到配置作用域**：插件未在顶层 inject 中声明 settings 服务，宿主不会为该插件挂载设置视图，其 provider 行渲染时读取命名空间视图会得到 undefined。现已声明，并改为同步直接调用 ctx.settings.installSection。

### 说明

- 额度/限流自动切换能力保持不变，并按 (账号, 模型) 粒度冷却：一个模型被限流不影响该账号其它模型；账号令牌失效会自动刷新重试；全部账号耗尽后才向调用方返回 429。

## 0.2.0 (2026-09-16)

本次更新在既有的多账号自动容错池基础上，补齐了每日签到、国内/国际版双区域适配，并把做签到的多账号体验做成了「一个账号一个按钮」的形态。

### 新增

- **每日签到**：设置卡片在每个账号的积分区下方新增签到区块，显示当前连签天数、每日可领积分与里程碑额外奖励，并提供一键领取按钮。

  - 多账号**逐个领取**：池里每个账号各有一个签到按钮，可一次领完所有账号的当日奖励，**不需要先把池的优先账号切过去**。
  - **不会重复领取**：领取前会先重新查询该账号的签到状态；今日已领取的账号直接返回「今日已签到」，不会再打一次领取接口。按钮在已领取 / 未开通签到活动时自动置灰。
  - **失败不拖垮卡片**：某个账号的签到查询失败时，只在该账号下显示一行错误提示，其余账号与整个池状态照常渲染。
  - 新增 CLI 子命令 `checkin`：不带参数查询所有账号今日签到状态，`checkin all` 领取全部账号奖励，`checkin <账号标签>` 只领指定账号；支持 `--json` 输出机器可读结果。

- **国内版 / 国际版自动适配**：按每个账号凭据里的登录域名自动选择上游域名——国际版登录（`workbuddy.ai`）走 `www.workbuddy.ai`，国内版（默认）走 `copilot.tencent.com` 与 `www.codebuddy.cn`。同一池内可以混用两种区域的账号，各自请求各自区域的接口，账号切换与自动容错轮换对两种区域一并生效。

- **签到按钮的连签奖励提示**：到达连签里程碑时，签到区块额外显示里程碑天数与额外奖励积分。

### 安全

- 签到是本插件唯一的写操作，按四重守卫保护：仅接受 `POST`、仅接受回环（same-origin）来源、请求必须显式携带目标 `accountId`（缺失返回 400、未知账号返回 404），且在领取前二次确认当日状态。请求体读取带 64 KB 上限，避免超大/挂起请求占用宿主内存。
- 签到状态进入卡片文档前同样经过脱敏处理，令牌类文本不会外泄到浏览器。

### 修复

- 修正测试中两处已过期的断言：一是 provider 名（`workbuddy-pool` → `workbuddy-xdpool`）；二是限流断言仍按「账号级冷却」校验，与现有的**按 (账号, 模型) 粒度冷却**语义不符——现按 `modelCooldowns` 校验，并断言账号级冷却未被误置。这两处修正让多账号自动容错的回归测试重新可用（测试总数 17 → 26）。

### 安装体验

- **已发布到 npm**：`dsh-workbuddy-xdpool` 现可从 npm 安装，安装只需约 10 秒、仅拉取插件自身一个包（依赖已全部标记为 optional，见下条）。推荐用 `dsh plugin --profile desktop add dsh-workbuddy-xdpool`。

- **安装速度优化（约 140 秒 → 数秒）**：把 6 个由 DSH 宿主进程提供的运行时包（`@deepseek-ai/dsh-llm`、`dsh-llm-pi-ai`、`dsh-settings`、`cordis`、`schemastery`、`@earendil-works/pi-ai`）在 `peerDependenciesMeta` 中标记为 **optional**。插件自身从不拉取它们；此前未标记 optional，包管理器会自动解析并安装它们的整棵依赖树（含 AWS / Google / Anthropic / Mistral SDK 等），实测安装 112 个包、耗时约 140 秒 —— 现在只需约 1 个包、数秒完成。

- **构建产物随仓库提交**：`lib/`（`index.js` + `index.d.ts` + `bin.js` + `client.js`）不再被忽略，直接从 GitHub 安装时**不需要任何安装期脚本**，因此不会再出现 pnpm 的「构建脚本被拦截，请放行后重试」提示，装完即用。
- 相应地，`prepare` 脚本改为 `prepublishOnly`（发布到 npm 前仍会自动构建），安装路径上不再有脚本触发点。
- 新增 `lib/index.d.ts` 类型声明（此前 `package.json` 的 `types` 指向该文件但构建未产出）。

### 说明

- 保留了原有的额度/限流自动切换能力，并在本次改动后重新做了回归验证：单账号限流时同请求内轮换到下一个健康账号、按 (账号, 模型) 粒度冷却（一个模型限流不影响该账号其它模型）、令牌失效自动刷新重试、全部账号耗尽后才向调用方返回 429。
