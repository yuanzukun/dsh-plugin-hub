/**
 * 宿主半路由 —— 前端 ↔ 宿主 的桥（设计文档 §10 的「薄适配层」）
 * @module dsh-breadboard/host/routes
 *
 * ★ 为什么是 HTTP/WS 而不是 `host.call`：
 *   `host.call` 只存在于「动态 Cordis 插件」的 runner 路径（cordis-client-runner），
 *   **bundle 插件的前端半没有这个符号**（已对整个 checkout 核对过）。
 *   本插件是 bundle 插件，所以一律走 `ctx.webServer.register` + 前端 fetch。
 *
 * ★ 为什么这里自定义 `HttpRoute` / `UpgradeRoute` 结构而不 import 宿主类型：
 *   §10.3 要求「内核零依赖宿主 API，一律走 hostAdapter.*」。本文件就是那一层。
 *   结构上与宿主 `WebRoute` / `WebUpgradeRoute` 等价（`kind`/`path`/`handler`），
 *   但宿主接口改名或迁移时，改动**收敛在本文件**，内核不受影响。
 */
import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Duplex } from 'node:stream'
import { WebSocketServer, type WebSocket } from 'ws'

import type { ObserveView } from '../contracts/protocol.ts'
import type { ObservedDevice } from '../contracts/observe.ts'
import type { ProjectStatus } from '../contracts/projects.ts'
import type { ProjectBody, ProjectScanOutcome } from '../core/projects/store.ts'
import { HARDWARE_MODELS, findModel, isExternalModel, modelKeys } from '../contracts/library.ts'
import path from 'node:path'
import { parseModelDefinition, type ModelDefLoadResult } from '../core/models/definitions.ts'
import type { AssemblyState } from '../core/state/assembly-state.ts'
import type { HardwareEventBus } from '../core/events.ts'
import type { ModelStore } from '../core/models/store.ts'
import { ModelStoreError } from '../core/models/store.ts'
import type { StepPartsClient } from '../core/models/step-parts.ts'
import { StepPartsError } from '../core/models/step-parts.ts'
import type { HardwareEvent } from '../contracts/assembly.ts'
import type { ChatSendRequest, ChatSendResult, ClientAction, ClientToHostMessage, HostCapabilities, HostToClientMessage, ModelSearchResult, ModelSearchSource } from '../contracts/protocol.ts'
import { CHAT_ROUTE, HTTP_ROUTES, MODEL_MAX_BYTES, MODEL_ROUTES, WS_ROUTE } from '../contracts/protocol.ts'

/** 结构等价于宿主 `WebRoute`。 */
export interface HttpRoute {
  readonly kind: 'exact' | 'prefix'
  readonly path: string
  readonly handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>
}

/** 结构等价于宿主 `WebUpgradeRoute`。 */
export interface UpgradeRoute {
  readonly path: string
  readonly handler: (req: IncomingMessage, socket: Duplex, head: Buffer) => void | Promise<void>
}

/**
 * 搜索能力注入点。宿主半用 `ctx.web.search` 实现它。
 *
 * ★ 为什么是注入而不是直接调宿主服务：§10.3「内核零依赖宿主 API」。
 *   宿主搜索接口若改名，改动收敛在 `index.ts` 一处。
 *
 * ★ 它只负责**通用搜索那一半**（外链）；结构化候选由 {@link StepPartsClient} 提供。
 *   两半在搜索路由里合成完整的 `ModelSearchResult`。
 */
export type ModelSearcher = (query: string) => Promise<{
  readonly sources: readonly ModelSearchSource[]
  readonly content?: string
  readonly unavailable?: string
}>

/** 安全地把未知值当对象用（模型/请求体可能传 null 或非对象）。 */
function asRecord(value: unknown): Record<string, unknown> {
  return value !== null && typeof value === 'object' ? (value as Record<string, unknown>) : {}
}

/** 搜索结果的可变构造形态（对外仍是只读的 `ModelSearchResult`）。 */
interface MutableSearchResult {
  query: string
  candidates: ModelSearchResult['candidates']
  sources: ModelSearchResult['sources']
  content?: string
  unavailable?: string
}

export interface RouteDeps {
  readonly state: AssemblyState
  readonly bus: HardwareEventBus
  /** 能力探测结果（§10.1）。用函数以便随环境变化。 */
  readonly capabilities: () => HostCapabilities
  /**
   * **型号定义目录**（数据驱动型号的落点）。省略则"加型号"的 POST 返回 501。
   *
   * ★ `reload` 是必需的：落盘后要**立即重载**才生效（读的是目录，不必重载插件）。
   * ★ 只给"目录 + 重载口"，**不把写盘逻辑塞进路由** —— 校验 → 写盘 → 重载是一条链，
   *   拆开就会出现"写了一半没重载"这种**半生效**状态（用户以为加上了，其实没有）。
   */
  readonly modelDefs?: {
    readonly dir: string
    readonly reload: () => Promise<ModelDefLoadResult>
  }
  /**
   * **真机观察的当前状态**（界面读它）。省略则不注册 observe 路由。
   *
   * ★ 交的是**一个取数函数**而不是观察器本身：路由不该能启动/停止观察 ——
   *   那是工具与界面动作的事。**只读面越小，越不容易被误用**。
   * ★ 返回 `ObserveView[]`（界面视图），不是宿主内部结构：
   *   路由只该转出界面需要的那几个字段。
   */
  readonly observe?: () => readonly ObserveView[]
  /**
   * **真机观察的命令面**（界面按钮用：start / stop）。
   *
   * ★ 与上面的只读 `observe` 分开：读与写是两件事，
   *   混在一个函数里会让"只读路由"悄悄获得写能力。
   * ★ 命令面只认两种动作（start/stop），**不是**把观察器整个交出去 ——
   *   界面不需要、也不该能 dispose 观察器。
   */
  readonly observeControl?: (
    body: Record<string, unknown>,
  ) => Promise<{ readonly ok: boolean; readonly reason?: string }>
  /** 用户导入模型的存储。省略则模型路由不注册。 */
  readonly models?: ModelStore
  /** 搜索能力。省略则搜索路由不注册（界面应降级为"只给外链"）。 */
  readonly search?: ModelSearcher
  /**
   * step.parts 客户端 —— **结构化候选 + 一键导入**。
   * 省略则搜索只返回外链（用户自己下载后手动导入）。
   */
  readonly stepParts?: StepPartsClient
  /**
   * 面板浮层输入框的投递口（见 `host/chat.ts`）。
   * 省略则聊天路由不注册（界面应隐藏输入框，而不是给一个发不出去的框）。
   */
  readonly chat?: (request: ChatSendRequest) => ChatSendResult
  /** handler 抛错时的上报口（默认静默）。 */
  readonly onError?: (error: unknown) => void
  /**
   * **项目**：状态查询 + 导入样例 + 删除（省略则项目路由不注册）。
   *
   * ★ 传**一组函数**而不是注册表本身（与 `capabilities` 同一手法）：
   *   路由层不必知道 `ProjectStore` 的存在，也不必知道"连通"怎么算 ——
   *   它只负责把数据发给前端、把用户的操作转下去。判据一变，这里一行都不用改。
   *
   * ★ 为什么"导入样例"和"删除"走 HTTP 而**不是** ClientAction：
   *   action 那条路的语义是"**改装配**"（放器件、连线、钉住），进的是 SSOT；
   *   而项目的增删是"**改用户目录里的文件**"，与装配状态无关。
   *   塞进 action 会让 `AssemblyState` 平白多出一个它管不着的东西。
   */
  readonly projects?: {
    readonly list: () => Promise<readonly ProjectStatus[]>
    /** 把随包样例装进用户目录。**只有用户显式导入时才调**（默认列表是空的）。 */
    readonly importSample: (projectId: string) => Promise<boolean>
    /**
     * **存一份用户给的项目定义**（从**文件**导入 / agent 建的）。
     *
     * ★ 与 `importSample` 分开而不是合成一个：那个的输入是**一个 id**，
     *   这个的输入是**一整份图纸**。合成一个就得在实现里判"到底是哪种"，
     *   而判错的表现是"**导入成功但项目是空的**" —— 最难查的一类。
     *
     * 返回**人话原因**（`undefined` = 成功）：文件是用户给的，可能缺字段、
     * id 非法、根本不是 JSON —— 每一种都要说清是哪种。
     */
    readonly save: (profile: unknown) => Promise<string | undefined>
    /**
     * **把当前场景存回这个项目**（"保存现有建模"）。
     *
     * ★ 与 `save` 分开：那个存的是**用户给的一份图纸**（文件里的），
     *   这个存的是**眼前这套装配**（用户刚摆的、刚连的）。
     *   来源完全不同，合成一个就得在实现里判"到底用哪个"，
     *   而判错的表现是「**保存成功，但存的是旧的那份**」—— 用户以为白干了。
     */
    readonly saveScene: (projectId: string) => Promise<string | undefined>
    readonly remove: (projectId: string) => Promise<boolean>
    /**
     * **项目本体**（用户导入的真实项目文件夹）。
     *
     * ★★ 用户原话：
     *   > 上传项目本体，你**上传后那得显示项目啊**，
     *   > 那个扫描可以**后续扫描按钮**，**先上传项目到那里**
     *
     *   ⇒ 两步分开：**先上传（进列表）**，**再扫描（按钮）**。
     *     而不是"一上传就扫、扫完就没影了"。
     */
    readonly bodies: {
      readonly list: () => Promise<readonly ProjectBody[]>
      /** 存一份本体快照（用户选文件夹上传时）。 */
      readonly save: (body: ProjectBody) => Promise<void>
      readonly remove: (bodyId: string) => Promise<boolean>
      /** **扫描一份已存的本体** —— 只有用户点"扫描"时才调。 */
      readonly scan: (
        bodyId: string,
      ) => Promise<
        | { readonly ok: true; readonly report: ProjectScanOutcome }
        | { readonly ok: false; readonly reason: string }
      >
    }
  }
}

/**
 * **扫描项目本体，得出它"看起来需要哪些硬件"**。
 *
 * ★★ 用户的工作流第②步：
 *   > 导入项目后可以**扫描看看项目需求硬件建模**，根据这个干建模，
 *   > 如果网上有建模自己导入不了就**写个清单发给用户**，没有就**自己建模没有的部分**
 *
 * ⚠️⚠️ **它只出报告，不生成装配。** 装配该怎么接是**看代码后决定的** ——
 *   猜出来的装配会有"看起来对但接错了"的风险，而它**不会报错**
 *   （本项目失败族里最贵的那一类）。
 *
 * ★ 匹配靠**词表**而不是智能推断：词表是**可审计的** ——
 *   报告里会带上"在哪几个文件里看到的"，用户能自己判断对不对。
 *   纯推断给不出证据，而**没有证据的结论在这里等于没有结论**。
 */
export async function scanProjectNeeds(
  files: readonly { path?: unknown; text?: unknown }[],
  models: ModelStore | undefined,
): Promise<{
  readonly fileCount: number
  readonly matched: readonly {
    readonly modelKey: string
    readonly label: string
    readonly hasGeometry: boolean
    readonly evidence: readonly string[]
  }[]
  readonly missingGeometry: readonly string[]
}> {
  // 型号键 → 常见写法（小写匹配）。★ 词表**故意写窄**：
  //   宁可漏报（用户自己看代码能补），也不要误报（那会让他去装不需要的东西）。
  const ALIASES: Readonly<Record<string, readonly string[]>> = {
    'esp32-seat-sensor': ['esp32dev', 'esp32 devkit', 'esp32-devkit', 'esp32', 'platformio.ini'],
    'hc-sr501': ['hc-sr501', 'hc_sr501', 'hcsr501', 'hc-sr501', 'pir', '红外', '人体感应'],
    bme280: ['bme280', 'bmp280'],
    'rpi-4b': ['raspberry pi', '树莓派', 'rpi-4', 'rpi4'],
    mpl3115a2: ['mpl3115'],
    mpr121: ['mpr121'],
    'led-5v': ['led'],
    breadboard: ['面包板', 'breadboard'],
  }

  const lower = files.map((file) => ({
    path: typeof file.path === 'string' ? file.path : '?',
    text: typeof file.text === 'string' ? file.text.toLowerCase() : '',
  }))

  const matched: {
    modelKey: string
    label: string
    hasGeometry: boolean
    evidence: string[]
  }[] = []
  const missingGeometry: string[] = []
  for (const [modelKey, words] of Object.entries(ALIASES)) {
    const evidence: string[] = []
    for (const word of words) {
      for (const file of lower) {
        if (file.text.includes(word) && !evidence.includes(file.path)) evidence.push(file.path)
      }
      if (evidence.length >= 3) break
    }
    if (evidence.length === 0) continue
    const hasGeometry = models === undefined ? false : (await models.get(modelKey)) !== undefined
    matched.push({
      modelKey,
      label: HARDWARE_MODELS[modelKey]?.label ?? modelKey,
      hasGeometry,
      evidence: evidence.slice(0, 3),
    })
    if (!hasGeometry) missingGeometry.push(modelKey)
  }
  return { fileCount: files.length, matched, missingGeometry }
}

/** POST body 上限，防止超大请求打爆内存。 */
const MAX_BODY_BYTES = 256 * 1024

function sendJson(res: ServerResponse, status: number, payload: unknown): void {
  const body = JSON.stringify(payload)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    // 快照必须实时，禁止任何中间层缓存
    'cache-control': 'no-store',
  })
  res.end(body)
}

/**
 * 把 handler 包成「异常也能读出原因」的形态。
 *
 * ★ 为什么必须包：路由 handler 里抛出的异常会被宿主 webserver 吞掉，客户端只看到
 *   一个**空 body 的 400**。实测踩过：`/api/capabilities` 返回 400 空 body，
 *   没有任何线索指向「handler 里访问了已失效的 ctx」。
 *   宁可把内部错误回给本地前端（同机同源、非敏感），也不要留一个无法诊断的 400。
 */
function guarded(route: HttpRoute, onError: (error: unknown) => void): HttpRoute {
  return {
    ...route,
    handler: (req, res) => {
      const fail = (error: unknown): void => {
        onError(error)
        if (!res.headersSent) sendJson(res, 500, { error: 'handler_failed', message: String(error) })
      }
      try {
        const result = route.handler(req, res)
        if (result instanceof Promise) result.catch(fail)
      } catch (error) {
        fail(error)
      }
    },
  }
}

/** 读取并解析 JSON body（带上限）。 */
async function readJsonBody(req: IncomingMessage): Promise<unknown> {
  const chunks: Buffer[] = []
  let total = 0
  for await (const chunk of req) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk))
    total += buffer.length
    if (total > MAX_BODY_BYTES) throw new Error('request body too large')
    chunks.push(buffer)
  }
  if (total === 0) return undefined
  return JSON.parse(Buffer.concat(chunks).toString('utf8'))
}

/**
 * 读取**二进制** body（模型上传用，带上限）。
 *
 * ★ 上限在**读取过程中**就生效，不是读完再判 —— 否则一个超大请求会先把内存吃掉。
 */
async function readBinaryBody(req: IncomingMessage, maxBytes: number): Promise<Buffer> {
  const chunks: Buffer[] = []
  let total = 0
  for await (const chunk of req) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk))
    total += buffer.length
    if (total > maxBytes) {
      throw new ModelStoreError('too_large', `上传超过上限 ${String(maxBytes)} 字节`)
    }
    chunks.push(buffer)
  }
  return Buffer.concat(chunks)
}

/**
 * 把一次动作翻译成对应的事件（§6.2 事件表）。
 *
 * ★ 写入顺序铁律是「状态 → 场景 → 事件」：
 *   状态在本函数调用前已改完；场景是前端的事（它收到事件后自行同步）；
 *   事件在这里发。**绝不先改场景再补状态**。
 */
function eventsForAction(action: ClientAction, state: AssemblyState, at: number): HardwareEvent[] {
  const snapshot = state.snapshot()
  const base = { source: 'user' as const, at }

  switch (action.kind) {
    case 'place_component': {
      const placed = snapshot.components.findLast((component) => component.hardwareModel === action.hardwareModel)
      return placed ? [{ ...base, type: 'hardware/component_placed', component: placed }] : []
    }
    case 'remove_component':
      return [{ ...base, type: 'hardware/component_removed', componentId: action.componentId }]
    case 'move_component':
      return [{ ...base, type: 'hardware/state_changed', revision: snapshot.revision }]
    case 'set_pinned':
      // 钉住/解开不改变拓扑，只是组件的一个属性 → 用通用状态变更事件让场景重调和。
      return [{ ...base, type: 'hardware/state_changed', revision: snapshot.revision }]
    case 'set_rotation':
      // 旋转同理：不改变拓扑，只是组件的一个属性。
      return [{ ...base, type: 'hardware/state_changed', revision: snapshot.revision }]
    case 'import_project':
      // 切换项目是**大改**（清场 + 重建 + 重新绑定）⇒ 让场景**整份重来**。
      // 走 diff 的话旧器件会被逐条删除、新器件逐条新增，中间态里线和端口对不上，
      // 看起来像闪烁 —— 而"闪一下"和"真的错了"在界面上分不出来。
      return [{ ...base, type: 'hardware/state_changed', revision: snapshot.revision }]
    case 'connect': {
      const made = snapshot.connections.findLast(
        (connection) =>
          connection.from.componentId === action.from.componentId &&
          connection.to.componentId === action.to.componentId,
      )
      return made ? [{ ...base, type: 'hardware/connection_made', connection: made, compatible: true }] : []
    }
    case 'disconnect':
      return [{ ...base, type: 'hardware/connection_removed', cableId: action.cableId }]
    default: {
      const exhaustive: never = action
      throw new Error(`未知动作：${JSON.stringify(exhaustive)}`)
    }
  }
}

export function createHttpRoutes(deps: RouteDeps): HttpRoute[] {
  const { state, bus } = deps
  const onError = deps.onError ?? ((): void => undefined)

  // ★ 必须显式标注数组类型：直接 `return [...].map(...)` 会丢掉上下文类型，
  //   `kind: 'exact'` 会放宽成 string，handler 参数也会退化成 any。
  const routes: HttpRoute[] = [
    {
      kind: 'exact',
      path: HTTP_ROUTES.capabilities,
      handler: (_req, res) => {
        sendJson(res, 200, deps.capabilities())
      },
    },
    // ── **可用型号表**（内置 + 运行时加载的外部型号）───────────────────────
    //
    //  ★★ 为什么必须由宿主给：前端对内置型号是**编译期** import，
    //     而外部型号（`model-defs/*.json`）是**运行时**注册的 ⇒
    //     前端不知道它们存在 ⇒ 会出现"工具能用、界面里没有"这种半通状态。
    //  ★ `external` 标记让界面能说清"这是内置的 / 这是你（或别人）加的"。
    {
      kind: 'exact',
      path: HTTP_ROUTES.modelCatalog,
      handler: async (req: IncomingMessage, res: ServerResponse) => {
        const list = modelKeys().map((key) => {
          const model = findModel(key)
          return {
            key,
            label: model?.label ?? key,
            external: isExternalModel(key),
            ports: model?.ports.length ?? 0,
            // ★ 尺寸也要给：① 器件列表上要显示"这块板子多大"，
            //   而**外部型号的尺寸只在宿主手里**（前端编译期表里没有它）。
            size: model?.size ?? { x: 0, y: 0, z: 0 },
          }
        })
        if (req.method === 'GET') {
          sendJson(res, 200, { models: list })
          return
        }
        if (req.method !== 'POST') {
          sendJson(res, 405, { ok: false, reason: 'method_not_allowed' })
          return
        }
        // ── **加一个型号定义**（把"加板子"变成界面动作）────────────────────
        //
        //  ★★ 顺序是刻意的：**先校验、再落盘**。
        //     反过来（先写文件再校验）会把坏定义留在用户目录里 ——
        //     下次启动照样加载、照样失败，而用户以为"我加过了"。
        //  ★ 落盘后**立即重载**（不必重载插件）：重载读的是目录，
        //     所以新定义当场可用，界面刷新即可看到。
        const face = deps.modelDefs
        if (face === undefined) {
          sendJson(res, 501, { ok: false, reason: '这个宿主没有开放型号定义目录（不能写入）' })
          return
        }
        const body = asRecord(await readJsonBody(req))
        const op = typeof body.op === 'string' ? body.op : ''
        if (op !== 'add-def') {
          sendJson(res, 400, { ok: false, reason: `未知操作：${op}` })
          return
        }
        const parsed = parseModelDefinition(body.definition)
        if (!parsed.ok) {
          sendJson(res, 400, { ok: false, reason: parsed.reason })
          return
        }
        const key = parsed.source.key
        // ★ 内置不可被覆盖（与 `buildRegistry` 同一条纪律；这里提前拦，**不写盘**）
        if (HARDWARE_MODELS[key] !== undefined) {
          sendJson(res, 409, {
            ok: false,
            reason: `型号键 ${key} 与内置型号同名 —— 不能覆盖内置（否则会悄悄改掉所有用户的引脚表）`,
          })
          return
        }
        try {
          const { mkdir, writeFile } = await import('node:fs/promises')
          await mkdir(face.dir, { recursive: true })
          const target = path.join(face.dir, `${key}.json`)
          await writeFile(target, `${JSON.stringify(body.definition, null, 2)}\n`, 'utf8')
          const outcome = await face.reload()
          sendJson(res, 200, {
            ok: true,
            key,
            file: target,
            registered: outcome.registered,
            rejected: outcome.rejected,
            failures: outcome.failures,
          })
        } catch (error) {
          sendJson(res, 500, { ok: false, reason: `写入失败：${String(error)}` })
        }
      },
    },
    // ── **真机观察状态**（界面用）─────────────────────────────────────────
    //
    //  ★ 前端只读宿主缓存：**轮询真机的只有宿主一个**（墙钟），
    //    前端再问一遍会把对方服务器打两遍，而且两份状态会不一致。
    {
      kind: 'exact',
      path: HTTP_ROUTES.observe,
      handler: async (req: IncomingMessage, res: ServerResponse) => {
        if (req.method === 'POST') {
          // ★ 写操作走**独立的命令面**：只读路由不该悄悄获得写能力
          const face = deps.observeControl
          if (face === undefined) {
            sendJson(res, 501, { ok: false, reason: '这个宿主没开放观察命令面' })
            return
          }
          const body = asRecord(await readJsonBody(req))
          const result = await face(body)
          sendJson(res, result.ok ? 200 : 400, result)
          return
        }
        // 宿主已经是**唯一**的轮询者，这里只是把它缓存的状态转出去（前端读本地，无外部副作用）
        sendJson(res, 200, { observing: deps.observe?.() ?? [] })
      },
    },
    {
      kind: 'exact',
      path: HTTP_ROUTES.assembly,
      handler: (_req, res) => {
        // 前端首帧与轮询兜底。按 revision 做客户端 diff，未变时前端自行短路。
        sendJson(res, 200, state.snapshot())
      },
    },
    // ★ 项目：GET 列表 / POST 导入样例或删除
    //   （省略 deps.projects 时不注册 —— 前端据此隐藏项目面板，
    //    而不是给一个永远转圈的面板）
    ...(deps.projects === undefined
      ? []
      : [
          {
            kind: 'exact' as const,
            path: HTTP_ROUTES.projects,
            handler: async (req: IncomingMessage, res: ServerResponse) => {
              const face = deps.projects
              if (face === undefined) return
              if (req.method === 'GET') {
                // ★ 项目现在是**用户目录里的文件** ⇒ 每次现读（会变），不能缓存
                // ★ 连**项目本体**一起返回：用户"上传后那得显示项目啊" ——
                //   列表要同时显示"装配图纸"和"导入的真实项目"两类东西。
                const [list, bodies] = await Promise.all([
                  face.list(),
                  deps.projects?.bodies.list() ?? Promise.resolve([]),
                ])
                sendJson(res, 200, { projects: list, bodies })
                return
              }
              if (req.method !== 'POST') {
                sendJson(res, 405, { ok: false, reason: 'method_not_allowed' })
                return
              }
              const body = asRecord(await readJsonBody(req))
              const op = typeof body.op === 'string' ? body.op : ''
              const projectId = typeof body.projectId === 'string' ? body.projectId : ''
              // ★ save 的 id 在图纸里（profile.id），不要求单独传 projectId
              // ★ 本体那几个 op 用的是 `bodyId`（或自带 id）——**本体与项目定义
              //   是完全不同的东西**（真实项目文件夹 vs 装配图纸），
              //   拿 projectId 去要求它们，症状是"上传本体被拒：缺少 projectId"。
              const needsProjectId =
                op !== 'save' && op !== 'scan-project' && !op.endsWith('-body')
              if (needsProjectId && projectId === '') {
                sendJson(res, 400, { ok: false, reason: '缺少 projectId' })
                return
              }
              if (op === 'import-sample') {
                const done = await face.importSample(projectId)
                sendJson(res, done ? 200 : 404, {
                  ok: done,
                  ...(done ? {} : { reason: `没有这个样例："${projectId}"` }),
                })
                return
              }
              if (op === 'save') {
                // ★ 整份图纸在 `profile` 里（用户从文件选的，或 agent 给的）
                const reason = await face.save(body.profile)
                sendJson(res, reason === undefined ? 200 : 400, {
                  ok: reason === undefined,
                  ...(reason === undefined ? {} : { reason }),
                })
                return
              }
              if (op === 'save-scene') {
                // ★ **把眼前这套装配存回项目** —— 用户："关键是在哪把现有建模导出保存"
                const reason = await face.saveScene(projectId)
                sendJson(res, reason === undefined ? 200 : 400, {
                  ok: reason === undefined,
                  ...(reason === undefined ? {} : { reason }),
                })
                return
              }
              if (op === 'import-body') {
                // ★ 先**上传**（进列表），扫描留到用户点按钮 —— 用户明确要求的两步分开
                const body0 = body.body as ProjectBody | undefined
                if (body0 === undefined || typeof body0.id !== 'string') {
                  sendJson(res, 400, { ok: false, reason: '缺少 body' })
                  return
                }
                await face.bodies.save(body0)
                sendJson(res, 200, { ok: true })
                return
              }
              if (op === 'scan-body') {
                const bodyId = typeof body.bodyId === 'string' ? body.bodyId : ''
                const result = await face.bodies.scan(bodyId)
                sendJson(res, result.ok ? 200 : 400, result.ok ? { ok: true, report: result.report } : { ok: false, reason: result.reason })
                return
              }
              if (op === 'delete-body') {
                const bodyId = typeof body.bodyId === 'string' ? body.bodyId : ''
                const done = await face.bodies.remove(bodyId)
                sendJson(res, done ? 200 : 404, { ok: done, ...(done ? {} : { reason: `没有这个本体：${bodyId}` }) })
                return
              }
              if (op === 'scan-project') {
                // ★★ **扫描项目本体，得出它需要哪些硬件** —— 用户的工作流第②步：
                //   "导入项目后可以扫描看看项目需求硬件建模，根据这个干建模"
                //
                // ⚠️ 它**不创建项目**：扫描的结果是**一份需求报告**（哪些型号有几何、
                //   哪些缺），而不是一份可以直接跑的装配 —— 装配该怎么接是**用户/agent
                //   看代码后决定的**，我们猜不出来。猜出来的装配会有"看起来对但接错了"的
                //   风险，而它**不会报错**。
                const scanned = Array.isArray(body.files) ? body.files : []
                const report = await scanProjectNeeds(
                  scanned as { path?: unknown; text?: unknown }[],
                  deps.models,
                )
                sendJson(res, 200, { ok: true, report })
                return
              }
              if (op === 'delete') {
                const done = await face.remove(projectId)
                sendJson(res, done ? 200 : 404, {
                  ok: done,
                  ...(done ? {} : { reason: `没有这个项目："${projectId}"` }),
                })
                return
              }
              sendJson(res, 400, { ok: false, reason: `不认识的 op："${op}"（可用 import-sample / delete）` })
            },
          },
        ]),
    {
      kind: 'exact',
      path: HTTP_ROUTES.action,
      handler: async (req, res) => {
        if (req.method !== 'POST') {
          sendJson(res, 405, { ok: false, reason: 'method_not_allowed' })
          return
        }

        let action: ClientAction
        try {
          action = (await readJsonBody(req)) as ClientAction
        } catch (error) {
          sendJson(res, 400, { ok: false, reason: `bad_request: ${String(error)}` })
          return
        }
        if (action === undefined || typeof action !== 'object' || !('kind' in action)) {
          sendJson(res, 400, { ok: false, reason: 'bad_request: missing kind' })
          return
        }

        const result = state.applyAction(action)

        // 状态已改完 → 发事件（场景由前端收到事件后同步）
        if (result.ok) {
          for (const event of eventsForAction(action, state, 0)) bus.emit(event)
        }
        sendJson(res, 200, result)
      },
    },
  ]

  /* ── 用户导入的模型（几何） ──
   *
   * ★ 宿主路由**没有路径参数**（只有 exact / prefix），所以拆成两条：
   *   精确 `/api/model`（列表）+ 前缀 `/api/model/`（单项，key 由 handler 自己解析）。
   *
   * ★ 存储的是**用户自己导入的东西**，插件不分发任何第三方模型 ——
   *   这也是这条路径在许可上干净的根本原因。
   */
  const models = deps.models
  if (models !== undefined) {
    routes.push({
      kind: 'exact',
      path: MODEL_ROUTES.base,
      handler: async (_req, res) => {
        sendJson(res, 200, await models.list())
      },
    })

    routes.push({
      kind: 'prefix',
      path: MODEL_ROUTES.base,
      handler: async (req, res) => {
        const pathname = new URL(req.url ?? '/', 'http://x').pathname
        // ★ 前缀**不带尾斜杠**（宿主约定），所以 key 从 prefix.length + 1 开始切。
        //   宿主保证 pathname 要么等于 prefix（那条走 exact 的 list 路由），要么以 `prefix/` 开头。
        const raw = pathname.startsWith(`${MODEL_ROUTES.base}/`)
          ? pathname.slice(MODEL_ROUTES.base.length + 1)
          : ''
        const modelKey = decodeURIComponent(raw)

        if (modelKey === '' || modelKey.includes('/')) {
          sendJson(res, 400, { ok: false, reason: 'bad_request: modelKey 不能为空或含 /' })
          return
        }

        try {
          if (req.method === 'GET') {
            const found = await models.get(modelKey)
            if (found === undefined) {
              sendJson(res, 404, { ok: false, reason: 'not_found' })
              return
            }
            const body = found.bytes
            res.writeHead(200, {
              'content-type':
                found.record.format === 'glb' ? 'model/gltf-binary' : 'model/gltf+json',
              'content-length': body.length,
              'cache-control': 'no-store',
            })
            res.end(body)
            return
          }

          if (req.method === 'POST') {
            const bytes = await readBinaryBody(req, MODEL_MAX_BYTES)
            const record = await models.put(modelKey, bytes)
            sendJson(res, 200, { ok: true, record })
            return
          }

          if (req.method === 'DELETE') {
            const removed = await models.delete(modelKey)
            sendJson(res, removed ? 200 : 404, { ok: removed })
            return
          }

          sendJson(res, 405, { ok: false, reason: 'method_not_allowed' })
        } catch (error) {
          if (error instanceof ModelStoreError) {
            // 校验类失败回 400（含目录穿越、格式不符、超限），其余回 500
            sendJson(res, error.code === 'io' ? 500 : 400, {
              ok: false,
              reason: error.code,
              message: error.message,
            })
            return
          }
          throw error
        }
      },
    })
  }

  /* ── 模型搜索：**step.parts 优先（可一键导入）+ 通用搜索兜底（外链）** ──
   *
   * ★ 为什么分两组而不是只留一组：
   *   · **step.parts** 给的是**结构化候选 + GLB 直链** ⇒ 可以**一键导入，全程不跳浏览器**
   *   · **通用搜索** 给的是**外链** ⇒ 覆盖 step.parts 没有的型号，但用户得自己去下
   *   两组并存，界面优先展示能一键导入的那组。
   *
   * ★ 两者都不涉及"抓取厂商站点"：一个走公开 API，一个走宿主搜索服务。
   */
  const search = deps.search
  const stepParts = deps.stepParts
  if (search !== undefined || stepParts !== undefined) {
    routes.push({
      kind: 'exact',
      path: MODEL_ROUTES.search,
      handler: async (req, res) => {
        const query = new URL(req.url ?? '/', 'http://x').searchParams.get('q')?.trim() ?? ''
        if (query === '') {
          sendJson(res, 400, { ok: false, reason: 'bad_request: 缺少查询词 q' })
          return
        }
        if (query.length > 200) {
          sendJson(res, 400, { ok: false, reason: 'bad_request: 查询词过长' })
          return
        }

        const result: MutableSearchResult = { query, candidates: [], sources: [] }
        const notes: string[] = []

        // ① step.parts —— 结构化候选，可一键导入
        if (stepParts !== undefined) {
          try {
            result.candidates = await stepParts.search(query, 20)
          } catch (error) {
            // 单个来源失败不应让整个搜索失败 —— 通用搜索仍可能给出结果
            notes.push(`step.parts 搜索失败：${String(error)}`)
          }
        } else {
          notes.push('未配置 step.parts 客户端，无法提供一键导入候选')
        }

        // ② 通用搜索 —— 外链兜底
        if (search !== undefined) {
          try {
            const web = await search(query)
            result.sources = web.sources
            if (web.content !== undefined) result.content = web.content
            if (web.unavailable !== undefined) notes.push(web.unavailable)
          } catch (error) {
            notes.push(`通用搜索失败：${String(error)}`)
          }
        } else {
          notes.push('宿主未提供通用搜索服务')
        }

        if (notes.length > 0) result.unavailable = notes.join('；')
        sendJson(res, 200, result)
      },
    })
  }

  /* ── 一键导入：客户端只给 partId，glbUrl 由宿主自己从 API 取 ── */
  if (models !== undefined && stepParts !== undefined) {
    routes.push({
      kind: 'exact',
      path: MODEL_ROUTES.import,
      handler: async (req, res) => {
        if (req.method !== 'POST') {
          sendJson(res, 405, { ok: false, reason: 'method_not_allowed' })
          return
        }

        const body = asRecord(await readJsonBody(req))
        const modelKey = typeof body['modelKey'] === 'string' ? body['modelKey'] : ''
        const partId = typeof body['partId'] === 'string' ? body['partId'] : ''
        if (modelKey === '' || partId === '') {
          sendJson(res, 400, { ok: false, reason: 'bad_request: 需要 modelKey 与 partId' })
          return
        }

        try {
          // ★ 客户端**从不**提供 URL —— glbUrl 由宿主从 step.parts API 取，SSRF 面为零
          const { bytes, candidate } = await stepParts.download(partId)
          const record = await models.put(modelKey, bytes)
          sendJson(res, 200, { ok: true, record, candidate })
        } catch (error) {
          if (error instanceof StepPartsError) {
            sendJson(res, error.code === 'too_large' ? 413 : 502, {
              ok: false,
              reason: error.code,
              message: error.message,
            })
            return
          }
          if (error instanceof ModelStoreError) {
            sendJson(res, 400, { ok: false, reason: error.code, message: error.message })
            return
          }
          throw error
        }
      },
    })
  }

  /* ── 面板浮层输入框 → 会话（见 host/chat.ts 的长注释） ──
   *
   * ★ 为什么是 POST 而不是 WebSocket：这是一次性的请求-应答（"发出去了吗、发给谁了"），
   *   没有持续流。走 WS 反而要自己造关联 id 来配对回执。
   * ★ 结果**始终回 200 + `{ok:false, reason}`**（除非请求体本身不合法）——
   *   投递失败是**业务结果**不是传输错误，前端要能拿到那句 reason 显示给用户。
   */
  const chat = deps.chat
  if (chat !== undefined) {
    routes.push({
      kind: 'exact',
      path: CHAT_ROUTE,
      handler: async (req, res) => {
        if (req.method !== 'POST') {
          sendJson(res, 405, { ok: false, reason: 'method_not_allowed' })
          return
        }
        const body = asRecord(await readJsonBody(req))
        const text = typeof body['text'] === 'string' ? body['text'] : ''
        const sessionId = typeof body['sessionId'] === 'string' ? body['sessionId'] : undefined
        const result = chat({ text, ...(sessionId !== undefined ? { sessionId } : {}) })
        sendJson(res, 200, result)
      },
    })
  }

  return routes.map((route) => guarded(route, onError))
}

/**
 * WebSocket 升级路由。
 *
 * ★ 握手必须自己来：宿主的 `registerUpgrade` 只给原始 socket 与 `head`，
 *   协议协商（Sec-WebSocket-Accept 等）由本路由负责。这也是引入 `ws` 的原因 ——
 *   手写帧解析（掩码/分片/ping-pong/close）不值得，且容易出隐蔽 bug。
 */
export function createUpgradeRoutes(deps: RouteDeps): { routes: UpgradeRoute[]; dispose: () => void } {
  const { state, bus } = deps
  const wss = new WebSocketServer({ noServer: true })

  const broadcast = (message: HostToClientMessage): void => {
    const payload = JSON.stringify(message)
    for (const client of wss.clients) {
      if (client.readyState === client.OPEN) client.send(payload)
    }
  }

  // 事件桥 → 所有已连接前端。★ 必须持有退订函数，否则卸载后仍会往已关闭的 socket 写。
  const unsubscribe = bus.on((event) => {
    broadcast({ kind: 'event', event })
  })

  wss.on('connection', (socket: WebSocket) => {
    // 首帧：连接即拿到当前快照，前端不必再等一次轮询
    const hello: HostToClientMessage = {
      kind: 'hello',
      revision: state.revision,
      snapshot: state.snapshot(),
    }
    socket.send(JSON.stringify(hello))

    socket.on('message', (raw) => {
      let message: ClientToHostMessage
      try {
        message = JSON.parse(String(raw)) as ClientToHostMessage
      } catch {
        return
      }
      if (message.kind === 'resync') {
        const frame: HostToClientMessage = { kind: 'snapshot', snapshot: state.snapshot() }
        socket.send(JSON.stringify(frame))
      } else if (message.kind === 'ping') {
        socket.send(JSON.stringify({ kind: 'pong', t: message.t }))
      }
    })

    socket.on('error', () => {
      // 前端断线是常态（切页面/刷新），不视为错误
    })
  })

  return {
    routes: [
      {
        path: WS_ROUTE,
        handler: (req, socket, head) => {
          wss.handleUpgrade(req, socket, head, (client) => {
            wss.emit('connection', client, req)
          })
        },
      },
    ],
    dispose: () => {
      unsubscribe()
      for (const client of wss.clients) client.terminate()
      wss.close()
    },
  }
}

/**
 * 一次性组装全部路由 + 卸载钩子。
 * ★ `dispose` 必须被真的调用（挂到 ctx.effect 上），否则插件热重载会残留
 *   事件订阅与 WebSocket 连接 —— 表现为「卸载了还在推消息」。
 */
export function createRouteBundle(deps: RouteDeps): {
  http: HttpRoute[]
  upgrade: UpgradeRoute[]
  dispose: () => void
} {
  const http = createHttpRoutes(deps)
  const upgrade = createUpgradeRoutes(deps)
  return { http, upgrade: upgrade.routes, dispose: upgrade.dispose }
}
