/**
 * DeepSeek Harness plugin: manage JumpServer assets and operate on them through KoKo.
 * @module @jumpserver-east/jumpserver-dsh
 */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import type {} from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-credentials'
import type {} from '@deepseek-ai/dsh-system-prompt'
import { JumpServerApi } from './api.js'
import { JumpServerClient } from './client.js'
import {
  DEFAULT_ACCESS_KEY_ID_ENV,
  DEFAULT_ACCESS_KEY_SECRET_ENV,
  type Config as PluginConfig,
  type ResolvedConfig,
} from './config.js'
import { resolveAuth, resolveBaseUrl, resolveEnableAssetAdmin, resolveOrgId } from './credentials.js'
import { registerPrompt } from './prompt.js'
import { SessionManager } from './sessions.js'
import { registerAdminTools, registerCatalogTools } from './tools-catalog.js'
import { registerRuntimeTools } from './tools-runtime.js'

export const name = 'jumpserver'
export const inject = ['tools']

export type Config = PluginConfig

export const Config: z<PluginConfig> = z.object({
  baseUrl: z.string(),
  orgId: z.string(),
  accessKeyIdEnv: z.string().role('credential-ref').default(DEFAULT_ACCESS_KEY_ID_ENV),
  accessKeySecretEnv: z.string().role('credential-ref').default(DEFAULT_ACCESS_KEY_SECRET_ENV),
  tlsRejectUnauthorized: z.boolean().default(false),
  enableAssetAdmin: z.boolean(),
  enableDbWrite: z.boolean(),
  idleTimeoutMs: z.number().step(1).min(1_000).default(600_000),
  execTimeoutMs: z.number().step(1).min(1_000).default(120_000),
  outputMaxBytes: z.number().step(1).min(1024).default(512_000),
  writeMaxBytes: z.number().step(1).min(1024).default(1_048_576),
})

/** Mount JumpServer tools, prompt guidance, and KoKo session cleanup. */
export function apply(ctx: Context, config: PluginConfig): void {
  const resolved = config as ResolvedConfig
  const client = new JumpServerClient({
    baseUrl: () => resolveBaseUrl(resolved),
    orgId: () => resolveOrgId(resolved),
    tlsRejectUnauthorized: resolved.tlsRejectUnauthorized,
    auth: () => resolveAuth(ctx, resolved),
  })
  const api = new JumpServerApi(client)
  const sessions = new SessionManager({
    idleTimeoutMs: resolved.idleTimeoutMs,
    execTimeoutMs: resolved.execTimeoutMs,
    outputMaxBytes: resolved.outputMaxBytes,
    writeMaxBytes: resolved.writeMaxBytes,
    onClosed: tokenId => api.expireConnectionToken(tokenId),
  })

  ctx.effect(() => () => sessions.disposeAll().finally(() => client.dispose()))

  registerPrompt(ctx)
  registerCatalogTools(ctx, api)
  registerRuntimeTools(ctx, api, sessions, resolved)
  if (resolveEnableAssetAdmin(resolved)) registerAdminTools(ctx, api)
}

export { JumpServerApi } from './api.js'
export { JumpServerClient, buildRequestUrl, signingPath } from './client.js'
export { signAccessKey, buildSigningString, httpDate } from './auth.js'
export { parseJmsUrl, parseClientUrlPayload } from './jms-url.js'
export { SessionManager } from './sessions.js'
export { JumpServerError } from './types.js'
export { nativeConnectMethods } from './connect-method.js'
export { canonicalProtocol, isDatabaseProtocol, pickAssetProtocol, pickConnectProtocol } from './protocol.js'
export { classifySql, assertSqlAllowed } from './sql-kind.js'
