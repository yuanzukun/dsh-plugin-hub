/**
 * @hyzyn/dsh-profile — DSH Web GUI 的 Profile 管理插件（宿主半体）。
 */
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import { admitRoute, dshHome, registerLiteralSection, spawnPortable } from '@hyzyn/dsh-kit'

export const name = 'profile-manager'
export const inject: string[] = []

export interface Config {
  enabled?: boolean
  announceToAgent?: boolean
}

/* ------------------------------------------------------------------ *
 * 常量与类型
 * ------------------------------------------------------------------ */

const PROFILE_NAME_RE = /^[A-Za-z0-9][A-Za-z0-9._-]*$/
const RESERVED_PROFILE_NAMES = new Set(['node_modules', '.', '..'])
const PROTECTED_PROFILE_NAMES = new Set(['web'])
const BUILTIN_PROFILE_ORDER = ['web', 'headless']
const MAX_JSON_BODY_BYTES = 512 * 1024
const RUNTIME_FILE = 'profile.runtime.json'
const DEFAULT_BUNDLES = ['@deepseek-ai/dsh-base']
const PROFILE_TEMPLATES: Record<string, string[]> = {
  web: ['@deepseek-ai/dsh-base', '@deepseek-ai/dsh-web-app'],
  headless: ['@deepseek-ai/dsh-base', '@deepseek-ai/dsh-headless'],
}

const profilesRoot = () => join(dshHome(), 'profiles')
const profileDir = (name: string) => join(profilesRoot(), name)
const runtimeFilePath = (name: string) => join(profileDir(name), RUNTIME_FILE)

interface ProfileInfo {
  name: string
  initialized: boolean
  packageJson: boolean
  patchExists: boolean
  bundles: string[]
  dependencies: Record<string, string>
  port: number | null
  dir: string
}

/* ------------------------------------------------------------------ *
 * 文件读写
 * ------------------------------------------------------------------ */

function isValidProfileName(name: unknown): name is string {
  if (typeof name !== 'string') return false
  const trimmed = name.trim()
  return PROFILE_NAME_RE.test(trimmed) && !RESERVED_PROFILE_NAMES.has(trimmed)
}

function readProfileRuntime(name: string): { port?: number } {
  const file = runtimeFilePath(name)
  if (!existsSync(file)) return {}
  try {
    const parsed = JSON.parse(readFileSync(file, 'utf8')) as { port?: unknown }
    return typeof parsed.port === 'number' && Number.isInteger(parsed.port) && parsed.port >= 0 && parsed.port <= 65535 ? { port: parsed.port } : {}
  } catch {
    return {}
  }
}

function writeProfileRuntime(name: string, port: number | null): void {
  const file = runtimeFilePath(name)
  if (port === null) {
    if (existsSync(file)) rmSync(file, { force: true })
    return
  }
  writeFileSync(file, JSON.stringify({ port }, null, 2) + '\n')
}

function normalizePort(value: unknown): { port?: number; error?: string } {
  if (value === undefined || value === null || value === '') return {}
  if (typeof value !== 'string' && typeof value !== 'number') {
    return { error: 'port 必须是 0~65535 的整数' }
  }
  const n = Number(value)
  if (!Number.isInteger(n) || n < 0 || n > 65535) {
    return { error: 'port 必须是 0~65535 的整数' }
  }
  return { port: n }
}


function readProfileInfo(name: string): ProfileInfo {
  const dir = profileDir(name)
  const manifestPath = join(dir, 'package.json')
  const patchPath = join(dir, 'cordis.patch.yml')
  const packageJson = existsSync(manifestPath)
  const runtime = readProfileRuntime(name)
  let bundles: string[] = []
  let dependencies: Record<string, string> = {}
  if (packageJson) {
    try {
      const manifest = JSON.parse(readFileSync(manifestPath, 'utf8')) as {
        dsh?: { profile?: { bundles?: unknown } }
        dependencies?: Record<string, unknown>
      }
      if (Array.isArray(manifest.dsh?.profile?.bundles)) {
        bundles = manifest.dsh.profile.bundles.filter((item): item is string => typeof item === 'string')
      }
      dependencies = Object.fromEntries(
        Object.entries(manifest.dependencies ?? {}).map(([key, value]) => [key, String(value)]),
      )
    } catch {
      /* 解析失败时仍展示目录，bundles/dependencies 为空 */
    }
  }
  return {
    name,
    initialized: packageJson,
    packageJson,
    patchExists: existsSync(patchPath),
    bundles,
    dependencies,
    port: runtime.port ?? null,
    dir,
  }
}

function listProfiles(): ProfileInfo[] {
  const root = profilesRoot()
  if (!existsSync(root)) return []
  const names = readdirSync(root, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && !RESERVED_PROFILE_NAMES.has(entry.name))
    .map((entry) => entry.name)
    .sort((a, b) => {
      const ai = BUILTIN_PROFILE_ORDER.indexOf(a)
      const bi = BUILTIN_PROFILE_ORDER.indexOf(b)
      if (ai !== -1 || bi !== -1) {
        return (ai === -1 ? 1 : ai) - (bi === -1 ? 1 : bi)
      }
      return a.localeCompare(b)
    })
  return names.map(readProfileInfo)
}

function ensureProfilesRoot(): void {
  mkdirSync(profilesRoot(), { recursive: true })
}

/** 与 dsh-app-boot 的 initProfile 对齐：创建最小可用的 profile 目录。 */
function createProfile(name: string, template?: string): void {
  const dir = profileDir(name)
  ensureProfilesRoot()
  if (existsSync(join(dir, 'package.json'))) {
    throw new Error('profile 已存在: ' + name)
  }
  mkdirSync(dir, { recursive: true })
  const bundles = (template !== undefined && PROFILE_TEMPLATES[template] !== undefined)
    ? PROFILE_TEMPLATES[template]
    : DEFAULT_BUNDLES
  const manifest = {
    name: `dsh-profile-${name}`,
    private: true,
    dependencies: {},
    dsh: {
      profile: {
        bundles,
      },
    },
  }
  writeFileSync(join(dir, 'package.json'), JSON.stringify(manifest, null, 2) + '\n')
  const patchPath = join(dir, 'cordis.patch.yml')
  if (!existsSync(patchPath)) {
    writeFileSync(
      patchPath,
      [
        '# Your patch layer for this dsh profile, applied after every bundle layer:',
        '# a top-level YAML array of loader patch entries (id-targeted config',
        '# overrides, disables, and insert lists; `!!js` expressions allowed).',
        '',
        '[]',
        '',
      ].join('\n'),
    )
  }
  const workspacePath = join(dir, 'pnpm-workspace.yaml')
  if (!existsSync(workspacePath)) {
    writeFileSync(
      workspacePath,
      [
        'packages:',
        '  - .',
        '',
        'nodeLinker: hoisted',
        'autoInstallPeers: false',
        '',
      ].join('\n'),
    )
  }
}

/**
 * 在新 profile 目录里跑 `pnpm install`。
 *
 * 必须经 kit 的 `spawnPortable`：Windows 上 pnpm 是 `pnpm.CMD`（cmd shim），
 * 裸 `spawn('pnpm')` 既不查 PATHEXT 解析 `.cmd`，写绝对路径又会因 Node 对
 * `.cmd` 的加固报 EINVAL——真机实测原来的 `spawnSync('pnpm', …)` 直接
 * `ENOENT`，于是「复制 Profile」在 Windows 上**一定失败**（与已修的
 * codegraph / mcp 是同一类缺陷）。
 */
async function installProfileDependencies(dir: string): Promise<void> {
  const outcome = await new Promise<{ code: number | null; error?: string; output: string }>((resolve) => {
    let child: ReturnType<typeof spawnPortable>
    try {
      child = spawnPortable('pnpm', ['install'], { cwd: dir })
    } catch (error) {
      resolve({ code: null, error: error instanceof Error ? error.message : String(error), output: '' })
      return
    }
    let output = ''
    child.stdout?.on('data', (chunk: Buffer) => (output += chunk.toString()))
    child.stderr?.on('data', (chunk: Buffer) => (output += chunk.toString()))
    child.on('error', (error: Error) => resolve({ code: null, error: error.message, output }))
    child.on('close', (code: number | null) => resolve({ code, output }))
  })
  if (outcome.error !== undefined) throw new Error('复制后安装依赖失败: ' + outcome.error)
  if (outcome.code !== 0) {
    const detail = outcome.output.trim()
    throw new Error('复制后安装依赖失败（pnpm 退出码 ' + String(outcome.code) + '）' + (detail ? ': ' + detail.slice(-600) : ''))
  }
}

/**
 * 复制 profile：**要么成功，要么什么都没发生**。
 *
 * 两条前置校验（源不存在 / 目标已存在）必须在**创建任何东西之前**抛出，且调用方的
 * 回滚只允许删「本次请求创建的那个目录」——见 duplicate 路由里 `created` 的用法
 * （2026-10-19 外部测评 issue #13 第 1 条：回滚曾无条件 `rm -rf` 目标目录，把用户
 * 本来就存在的 profile 整目录删掉，连受保护的 `web` 也绕过）。
 *
 * @param onCreated - 目标目录**真的被创建之后**调用一次。调用方据此判断失败时能不能
 *   回滚：前置校验（源不存在 / 目标已存在）失败时不会调用它，那时目标目录是用户的、
 *   一个字节都不能动（2026-10-19 外部测评 issue #13 第 1 条）。
 */
async function copyProfile(source: string, target: string, onCreated?: () => void): Promise<void> {
  const src = profileDir(source)
  const dest = profileDir(target)
  /*
   * 两条前置校验放在 try 外面（调用方也不再对它们做回滚）：它们失败时**目标目录
   * 可能是用户早就存在的那个**，删它就是数据丢失。顺序也重要——先判源、再判目标，
   * 否则「源不存在 + 目标存在」会先报目标已存在，掩盖真正的原因。
   */
  if (!existsSync(join(src, 'package.json'))) {
    throw new Error('源 profile 不存在或未初始化: ' + source)
  }
  if (existsSync(join(dest, 'package.json'))) {
    throw new Error('目标 profile 已存在: ' + target)
  }
  ensureProfilesRoot()
  mkdirSync(dest, { recursive: true })
  // 从这一刻起目录是「本次请求建的」：此后任何失败都可以安全回滚
  onCreated?.()
  const entries = readdirSync(src, { withFileTypes: true })
  for (const entry of entries) {
    if (entry.name === 'node_modules' || entry.name === 'pnpm-lock.yaml') continue
    const from = join(src, entry.name)
    const to = join(dest, entry.name)
    if (entry.isDirectory()) {
      cpSync(from, to, { recursive: true })
    } else {
      cpSync(from, to)
    }
  }
  const manifestPath = join(dest, 'package.json')
  if (existsSync(manifestPath)) {
    try {
      const manifest = JSON.parse(readFileSync(manifestPath, 'utf8')) as { name?: string }
      manifest.name = `dsh-profile-${target}`
      writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n')
    } catch {
      /* 复制后改名失败不阻塞，目录仍可用 */
    }
  }
  await installProfileDependencies(dest)
}

function deleteProfile(name: string): void {
  if (PROTECTED_PROFILE_NAMES.has(name)) {
    throw new Error('默认 profile 不能删除: ' + name)
  }
  const dir = profileDir(name)
  if (!existsSync(dir)) {
    throw new Error('profile 不存在: ' + name)
  }
  rmSync(dir, { recursive: true, force: true })
}


function renameProfile(oldName: string, newName: string): void {
  const oldDir = profileDir(oldName)
  const newDir = profileDir(newName)
  if (!existsSync(oldDir)) {
    throw new Error('profile 不存在: ' + oldName)
  }
  if (existsSync(newDir)) {
    throw new Error('目标 profile 已存在: ' + newName)
  }
  ensureProfilesRoot()
  renameSync(oldDir, newDir)
  const manifestPath = join(newDir, 'package.json')
  if (existsSync(manifestPath)) {
    try {
      const manifest = JSON.parse(readFileSync(manifestPath, 'utf8')) as { name?: string }
      manifest.name = `dsh-profile-${newName}`
      writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n')
    } catch {
      /* 改名后更新 manifest 失败不阻塞，目录已移动 */
    }
  }
}

/* ------------------------------------------------------------------ *
 * HTTP 路由（准入 = 本机回环围栏 ∪ 非本机宿主鉴权，见 kit.admitRoute）
 * ------------------------------------------------------------------ */

interface ReqLike {
  method?: string
  url?: string
  headers: Record<string, string | string[] | undefined>
  socket: { remoteAddress?: string }
}

interface ResLike {
  writeHead(status: number, headers?: Record<string, string>): void
  end(body?: string): void
}

function writeJson(res: ResLike, status: number, body: unknown): void {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'referrer-policy': 'no-referrer' })
  res.end(JSON.stringify(body))
}

async function readJsonBody(req: ReqLike & AsyncIterable<Uint8Array>): Promise<Record<string, unknown> | undefined> {
  const chunks: Uint8Array[] = []
  let size = 0
  try {
    for await (const chunk of req) {
      size += chunk.length
      if (size > MAX_JSON_BODY_BYTES) return undefined
      chunks.push(chunk)
    }
  } catch {
    return undefined
  }
  try {
    const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'))
    return typeof parsed === 'object' && parsed !== null && !Array.isArray(parsed) ? (parsed as Record<string, unknown>) : undefined
  } catch {
    return undefined
  }
}

type RouteHandler = (req: ReqLike & AsyncIterable<Uint8Array>, res: ResLike) => Promise<void>

function makeRoutes(ctx: Context): Array<{ kind: 'exact'; path: string; handler: RouteHandler }> {
  const guard = (req: ReqLike, res: ResLike, method: string): boolean => {
    const rejection = admitRoute(ctx, req)
    if (rejection !== undefined) {
      writeJson(res, rejection.status, { error: rejection.error })
      return false
    }
    if (req.method !== method) {
      writeJson(res, 405, { error: 'method not allowed: ' + String(req.method) })
      return false
    }
    return true
  }
  return [
    {
      kind: 'exact',
      path: '/api/dsh-profile/list',
      handler: async (req, res) => {
        if (!guard(req, res, 'GET')) return
        writeJson(res, 200, {
          ok: true,
          home: dshHome(),
          profilesRoot: profilesRoot(),
          profiles: listProfiles(),
        })
      },
    },
    {
      kind: 'exact',
      path: '/api/dsh-profile/create',
      handler: async (req, res) => {
        if (!guard(req, res, 'POST')) return
        const body = await readJsonBody(req)
        if (body === undefined) {
          writeJson(res, 400, { error: 'invalid JSON body' })
          return
        }
        const name = typeof body.name === 'string' ? body.name.trim() : ''
        if (!isValidProfileName(name)) {
          writeJson(res, 400, { error: '非法 profile 名称: ' + JSON.stringify(name) })
          return
        }
        const template = typeof body.template === 'string' ? body.template : undefined
        const portResult = normalizePort(body.port)
        if (portResult.error !== undefined) {
          writeJson(res, 400, { error: portResult.error })
          return
        }
        try {
          createProfile(name, template)
          if (portResult.port !== undefined) writeProfileRuntime(name, portResult.port)
        } catch (error) {
          writeJson(res, 400, { error: error instanceof Error ? error.message : String(error) })
          return
        }
        writeJson(res, 200, { ok: true, profile: readProfileInfo(name) })
      },
    },
    {
      kind: 'exact',
      path: '/api/dsh-profile/duplicate',
      handler: async (req, res) => {
        if (!guard(req, res, 'POST')) return
        const body = await readJsonBody(req)
        if (body === undefined) {
          writeJson(res, 400, { error: 'invalid JSON body' })
          return
        }
        const name = typeof body.name === 'string' ? body.name.trim() : ''
        const from = typeof body.from === 'string' ? body.from.trim() : ''
        if (!isValidProfileName(name)) {
          writeJson(res, 400, { error: '非法 profile 名称: ' + JSON.stringify(name) })
          return
        }
        if (!isValidProfileName(from)) {
          writeJson(res, 400, { error: '非法源 profile 名称: ' + JSON.stringify(from) })
          return
        }
        /*
         * 失败回滚**只删本次请求创建的那个目录**（2026-10-19 外部测评 issue #13 第 1 条）。
         *
         * 原先这里无条件 `rmSync(profileDir(name), { recursive: true, force: true })`。
         * 而 `copyProfile` 会在**创建任何东西之前**抛出两条前置校验（源不存在 /
         * 目标已存在）——于是「把目标名填成一个已存在的 profile」这种最常见的误操作，
         * 结果是**用户那个 profile 被整目录删掉**（package.json、bundle 列表、自己的
         * cordis.patch.yml、端口配置、node_modules 全没），同时还绕过了 `deleteProfile`
         * 对 `web` 的保护。接口返回 400，看起来像「被拒绝了」，用户不会意识到目录已经没了。
         *
         * 现在的判据是「这个目录是不是**我**建的」：
         *   - 前置校验在 copyProfile 里、且在 mkdir 之前 → 抛错时目标目录没被动过，`created` 为 false；
         *   - mkdir 成功之后才置 `created = true`，此后任何失败（复制中途、装依赖）都回滚。
         */
        let created = false
        try {
          // copyProfile 在 mkdir 之前就抛的前置校验，此时目标目录一个字节都没动
          await copyProfile(from, name, () => { created = true })
        } catch (error) {
          if (created) {
            try {
              rmSync(profileDir(name), { recursive: true, force: true })
            } catch {
              /* 回滚失败不改变响应：错误原因仍然要如实回给用户 */
            }
          }
          writeJson(res, 400, { error: error instanceof Error ? error.message : String(error) })
          return
        }
        writeJson(res, 200, { ok: true, profile: readProfileInfo(name) })
      },
    },
    {
      kind: 'exact',
      path: '/api/dsh-profile/rename',
      handler: async (req, res) => {
        if (!guard(req, res, 'POST')) return
        const body = await readJsonBody(req)
        if (body === undefined) {
          writeJson(res, 400, { error: 'invalid JSON body' })
          return
        }
        const name = typeof body.name === 'string' ? body.name.trim() : ''
        const newName = typeof body.newName === 'string' ? body.newName.trim() : ''
        if (!isValidProfileName(name)) {
          writeJson(res, 400, { error: '非法 profile 名称: ' + JSON.stringify(name) })
          return
        }
        if (!isValidProfileName(newName)) {
          writeJson(res, 400, { error: '非法新 profile 名称: ' + JSON.stringify(newName) })
          return
        }
        try {
          renameProfile(name, newName)
        } catch (error) {
          writeJson(res, 400, { error: error instanceof Error ? error.message : String(error) })
          return
        }
        writeJson(res, 200, { ok: true, profile: readProfileInfo(newName) })
      },
    },
    {
      kind: 'exact',
      path: '/api/dsh-profile/port',
      handler: async (req, res) => {
        if (!guard(req, res, 'POST')) return
        const body = await readJsonBody(req)
        if (body === undefined) {
          writeJson(res, 400, { error: 'invalid JSON body' })
          return
        }
        const name = typeof body.name === 'string' ? body.name.trim() : ''
        if (!isValidProfileName(name)) {
          writeJson(res, 400, { error: '非法 profile 名称: ' + JSON.stringify(name) })
          return
        }
        if (!existsSync(profileDir(name))) {
          writeJson(res, 400, { error: 'profile 不存在: ' + name })
          return
        }
        const portResult = normalizePort(body.port)
        if (portResult.error !== undefined) {
          writeJson(res, 400, { error: portResult.error })
          return
        }
        try {
          writeProfileRuntime(name, portResult.port ?? null)
        } catch (error) {
          writeJson(res, 500, { error: '写入端口配置失败: ' + (error instanceof Error ? error.message : String(error)) })
          return
        }
        writeJson(res, 200, { ok: true, profile: readProfileInfo(name) })
      },
    },


    {
      kind: 'exact',
      path: '/api/dsh-profile/delete',
      handler: async (req, res) => {
        if (!guard(req, res, 'POST')) return
        const body = await readJsonBody(req)
        if (body === undefined) {
          writeJson(res, 400, { error: 'invalid JSON body' })
          return
        }
        const name = typeof body.name === 'string' ? body.name.trim() : ''
        if (!isValidProfileName(name)) {
          writeJson(res, 400, { error: '非法 profile 名称: ' + JSON.stringify(name) })
          return
        }
        try {
          deleteProfile(name)
        } catch (error) {
          writeJson(res, 400, { error: error instanceof Error ? error.message : String(error) })
          return
        }
        writeJson(res, 200, { ok: true, deleted: name })
      },
    },
  ]
}

/* ------------------------------------------------------------------ *
 * 插件本体
 * ------------------------------------------------------------------ */

const PROFILE_GUIDANCE = '本机装有 dsh-profile-manager 插件（profile 管理）：用户提到「profile / 配置文件 / 多环境」时，引导他打开 设置 → 插件配置 → Profile 管理 卡片，别手改托管区块。'

export function apply(ctx: Context, config?: Config): void {
  if (config?.enabled === false) return
  const routes = makeRoutes(ctx)
  const announce = config?.announceToAgent !== false

  ctx.inject(['webServer'], (webCtx: Context) => {
    webCtx.effect(() => {
      const server = (webCtx as unknown as { webServer: { register(route: { kind: string; path: string; handler: RouteHandler }): () => void } }).webServer
      const disposers = routes.map((route) => server.register(route))
      return () => {
        for (const dispose of disposers) {
          try {
            dispose()
          } catch {
            /* 释放失败不阻塞 */
          }
        }
      }
    }, 'dsh-profile-manager: routes')
  })

  if (announce) {
    ctx.inject(['systemPrompt'], (promptCtx: Context) => {
      promptCtx.effect(() => {
        const systemPrompt = (promptCtx as unknown as { systemPrompt: { section(options: { name: string; order?: number; text: string }): () => void } }).systemPrompt
        return registerLiteralSection(systemPrompt, { name: 'plugin:dsh-profile-manager', order: 150, text: PROFILE_GUIDANCE })
      }, 'dsh-profile-manager: announcement')
    })
  }

  console.log('[dsh-profile-manager] mounted, profiles root: ' + profilesRoot())
}
