/* eslint-disable */
/**
 * @hyzyn/dsh-profile — 浏览器半体：官方插件配置里的「Profile 管理」卡片。
 * 设置面：0.2.0-rc.1 起挂 plugins.bundle.config（插件详情页「说明」下方内联），
 * 旧宿主回退到 0.1.6 线的 plugins.row.config / ≤0.1.5 的 settings.plugin.item，跨版本兼容。
 * 纯前端 DOM 面板，宿主经 /plugins/@hyzyn/dsh-profile/client.js 提供。
 */
window.__ModuleLoader__.load({
  id: '@hyzyn/dsh-profile',
  factory: (require) => {
    const exports = {}

    const React = require('react')
    const { jsx, jsxs } = require('react/jsx-runtime')

    /* ================================ CSS ================================ */

    const CSS = [
      '.pf_pageHost{display:block}',
      '.pf_pluginCard{list-style:none;border:.5px solid var(--dsw-alias-settings-card-stroke);background:var(--dsw-alias-settings-card-fill);border-radius:var(--dsw-radius-xl);transition:border-color .16s,background .16s}',
      '.pf_pluginCard:hover{border-color:var(--dsw-alias-label-dimmed)}',
      '.pf_pluginCardOpen{background:var(--dsw-alias-bg-layer-1);border-color:var(--dsw-alias-label-dimmed)}',
      '.pf_cardHeader{appearance:none;width:100%;color:inherit;font:inherit;text-align:left;cursor:pointer;background:0 0;border:0;border-radius:var(--dsw-radius-xl);display:flex;align-items:center;gap:12px;padding:14px 16px}',
      '.pf_cardHeader:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:-2px}',
      '.pf_cardHeadText{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}',
      // 卡片标题：本文件另有一条 .pf_cardName（面板内 profile 名）——同选择器后者整条覆盖前者，
      // 那两条 14px/600 与 13.5px/700 都是死声明；合并为官方 cardTitle 角色 14px/500/22px。
      '.pf_cardName{color:var(--dsw-alias-label-primary);font-size:14px;font-weight:500;line-height:22px}',
      '.dshkit_badge{flex:none;margin-left:auto;padding:1px 8px;border-radius:999px;corner-shape:round;font-size:11px;font-weight:600;line-height:16px;letter-spacing:.02em;color:var(--dsw-alias-label-dimmed);background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1)}',
      '.pf_cardDescription{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px}',
      '.pf_chevron{flex:none;color:var(--dsw-alias-label-tertiary);transition:transform .16s}',
      '.pf_pluginCardOpen .pf_chevron{transform:rotate(180deg)}',
      '.pf_cardBody{padding:2px 16px 16px}',
      '.pf_panel{display:flex;flex-direction:column;gap:12px;color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-family);box-sizing:border-box}',
      '.pf_panelHeader{display:flex;align-items:center;gap:10px;flex:none}',
      '.pf_panelTitle{margin:0;font-size:15px;font-weight:500;line-height:22px;white-space:nowrap;flex:1}',
      // 11.5px 的提示/次级正文上收到官方 hint 的 12/18（10–11px 只留给徽标与小 tag）。
      '.pf_subtitle{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;font-family:var(--ds-font-family-code);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:360px}',
      '.pf_toolbar{display:flex;align-items:center;gap:8px;flex:none}',
      // 按钮族对齐宿主 Button primitives：本包属 H28 档（size="sm"），故统一 H28/R8/12px/18px/padding 0 10px，
      // 填充与描边两个变体逐项同尺寸；主按钮底色是 button-primary-fill（button-info 一族是强调蓝，非按钮填充）。
      '.pf_btn{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:4px;height:28px;padding:0 10px;border:none;border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground);font-family:inherit;font-size:12px;line-height:18px;white-space:nowrap;cursor:pointer}',
      '.pf_btn:hover:not(:disabled){background:var(--dsw-alias-button-primary-hover)}',
      '.pf_btn:disabled{opacity:.4;cursor:not-allowed}',
      '.pf_btn:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary))}',
      '.pf_btnGhost{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:4px;height:28px;padding:0 10px;border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-sm);background:transparent;color:var(--dsw-alias-label-primary);font-family:inherit;font-size:12px;line-height:18px;white-space:nowrap;cursor:pointer}',
      '.pf_btnGhost:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}',
      '.pf_btnGhost:active:not(:disabled){background:var(--dsw-alias-interactive-bg-active)}',
      '.pf_btnGhost:disabled{opacity:.4;cursor:not-allowed}',
      '.pf_btnGhost:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary))}',
      '.pf_btnDanger{color:var(--dsw-alias-state-error-primary);border-color:color-mix(in srgb,var(--dsw-alias-state-error-primary) 30%,transparent)}',
      '.pf_btnDanger:hover:not(:disabled){background:color-mix(in srgb,var(--dsw-alias-state-error-primary) 8%,transparent)}',
      '.pf_list{display:flex;flex-direction:column;gap:8px;max-height:480px;overflow-y:auto}',
      '.pf_card{background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-md);padding:10px 12px;display:flex;flex-direction:column;gap:6px}',
      '.pf_cardRow{display:flex;align-items:center;gap:8px;flex-wrap:wrap}',
      '.pf_cardSummary{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px;font-family:var(--ds-font-family-code);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;min-width:0}',
      '.pf_cardActions{display:flex;align-items:center;gap:6px;margin-left:auto;flex-wrap:wrap}',
      '.pf_badge{display:inline-block;border:.5px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);border-radius:999px;corner-shape:round;padding:1px 8px;font-size:11px;line-height:16px;white-space:nowrap}',
      '.pf_badge[data-kind=ok]{color:var(--dsw-alias-state-success-primary);border-color:var(--dsw-alias-state-success-primary)}',
      '.pf_badge[data-kind=warn]{color:var(--dsw-alias-state-warn-primary);border-color:var(--dsw-alias-state-warn-primary)}',
      '.pf_banner{border:.5px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);border-radius:8px;padding:8px 12px;font-size:12.5px;line-height:18px;overflow-wrap:anywhere;flex:none}',
      '.pf_banner[data-kind=error]{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}',
      '.pf_banner[data-kind=ok]{color:var(--dsw-alias-state-success-primary);border-color:var(--dsw-alias-state-success-primary)}',
      '.pf_banner[data-kind=info]{color:var(--dsw-alias-state-business-primary);border-color:var(--dsw-alias-state-business-primary)}',
      '.pf_busyOverlay{position:fixed;left:50%;bottom:80px;transform:translateX(-50%);z-index:2147483647;pointer-events:none;background:var(--dsw-alias-bg-layer-2);border:0;color:var(--dsw-alias-label-primary);border-radius:var(--dsw-radius-md);padding:10px 18px;font-size:13px;line-height:20px;box-shadow:var(--dsw-elevation-prominent);max-width:80vw;text-align:center}',
      '.pf_empty,.pf_loading{text-align:center;color:var(--dsw-alias-label-tertiary);padding:24px 12px;font-size:12.5px;line-height:18px}',
      '.pf_form{display:flex;flex-direction:column;gap:10px;border-top:.5px solid var(--dsw-alias-border-l1);padding-top:12px}',
      '.pf_formTitle{font-weight:500;font-size:13px;line-height:20px}',
      '.pf_formRow{display:flex;gap:8px;align-items:center;flex-wrap:wrap}',
      // 输入档对齐宿主 settings-form 的 .input（H34 / token 圆角 / 13px）。显式 height 主要是给 <select> 的：
      // Chrome 算 select 的高度不看继承的 line-height，缺了它就会比同排 <input> 矮 2px。判据见
      // scripts/client-style-spec.mjs 检查十五。
      '.pf_input{box-sizing:border-box;height:34px;padding:0 12px;border:.5px solid var(--dsw-alias-border-l4);border-radius:var(--dsw-radius-md);background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-label-primary);font-family:inherit;font-size:13px;line-height:1.5;outline:none;min-width:180px;flex:1}',
      '.pf_input:focus{border-color:var(--dsw-alias-state-business-primary)}',
      '.pf_input::placeholder{color:var(--dsw-alias-label-dimmed)}',
      // 下拉与输入同档：同一行并排时不写显式高度就会矮 2px，字号也跟着 <input> 统一到 13px。
      // outline:none 去掉了 UA 焦点环，所以要自己补一条 :focus 描边，否则键盘态没有可见指示。
      '.pf_select{box-sizing:border-box;height:34px;padding:0 12px;border:.5px solid var(--dsw-alias-border-l4);border-radius:var(--dsw-radius-md);background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-label-primary);font-family:inherit;font-size:13px;line-height:1.5;outline:none}',
      '.pf_select:focus{border-color:var(--dsw-alias-state-business-primary)}',
      '.pf_error{color:var(--dsw-alias-state-error-primary);font-size:12px;line-height:18px;margin:0;white-space:pre-wrap}',
      '.pf_ok{color:var(--dsw-alias-state-success-primary);font-size:12px;line-height:18px;margin:0}',
      '.pf_hint{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px}',
    ].join('\n')

    let styleEl
    function ensureStyle() {
      if (document.getElementById('dsh-profile-style')) return
      styleEl = document.createElement('style')
      styleEl.id = 'dsh-profile-style'
      styleEl.textContent = CSS
      document.head.appendChild(styleEl)
    }

    /* ================================ API ================================ */

    const API = {
      list: '/api/dsh-profile/list',
      create: '/api/dsh-profile/create',
      duplicate: '/api/dsh-profile/duplicate',
      rename: '/api/dsh-profile/rename',
      port: '/api/dsh-profile/port',
      delete: '/api/dsh-profile/delete',
    }

    async function apiRequest(path, options) {
      const res = await fetch(path, options)
      let body = {}
      try {
        body = await res.json()
      } catch {
        /* 非 JSON 响应 */
      }
      if (!res.ok) {
        const err = new Error((body && body.error) || ('HTTP ' + res.status))
        err.code = res.status
        throw err
      }
      return body
    }

    const apiList = () => apiRequest(API.list)
    const apiCreate = (name, template, port) => apiRequest(API.create, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name, template, port }),
    })
    const apiDuplicate = (name, from) => apiRequest(API.duplicate, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name, from }),
    })
    const apiRename = (name, newName) => apiRequest(API.rename, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name, newName }),
    })
    const apiSetPort = (name, port) => apiRequest(API.port, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name, port }),
    })


    const apiDelete = (name) => apiRequest(API.delete, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name }),
    })

    /* ================================ 国际化 ================================ */

    /*
     * 界面文案走宿主 `@deepseek-ai/dsh-client-locale` 的目录（方案见 docs/i18n.md）。
     * 下面这一对目录由 `scripts/check-i18n.mjs` 静态校验：键集必须与英文一一对应、
     * `{name}` 占位符两边一致、代码里 `t('…')` 用到的键必须在这里有定义。
     * 目录**内联在 client.js 里**（不是 client-src/）：本包没有构建步骤，client.js 就是源；
     * 而且一旦凭空建出 client-src/，仓库级「宿主地址来源」静态规则会停止覆盖 client.js。
     */
    /* ==== dsh-i18n:begin ==== */
    const I18N_NS = 'profile'
    const I18N_ZH = {
      'card.name': 'Profile 管理',
      'card.desc': '查看、创建、复制、重命名、删除、端口配置 DSH profile。',
      'msg.working': '处理中…',
      'list.loading': '加载中…',
      'list.empty': '还没有 profile，先创建一个吧。',
      'badge.initialized': '已初始化',
      'badge.uninitialized': '未初始化',
      'badge.builtin': '内置',
      'panel.noBundle': '（无 bundle）',
      'panel.port': '端口 {port}',
      'panel.portUnset': '未设端口',
      'panel.depCount': '{count} 个依赖',
      'panel.missingPatch': ' · 缺少 cordis.patch.yml',
      'panel.startHint': '启动: {cmd}',
      'panel.createTitle': '新建 profile',
      'panel.duplicateTitle': '复制 profile',
      'btn.refresh': '刷新',
      'btn.create': '创建',
      'btn.copy': '复制',
      'btn.delete': '删除',
      'btn.deleteProtected': '默认 profile 不能删除',
      'btn.port': '端口',
      'btn.rename': '重命名',
      'btn.copyCommand': '复制启动命令',
      'option.baseTemplate': '基础模板（仅核心 / 自定义开发）',
      'option.templateWeb': 'web（base + web-app）',
      'option.templateHeadless': 'headless（base + headless）',
      'option.noProfile': '（先创建 profile）',
      'placeholder.name': '名称，如 dev',
      'placeholder.port': '端口（可选）',
      'placeholder.dupName': '新名称，如 dev-copy',
      'prompt.port': '设置启动端口（留空清除，0 表示自动分配）：',
      'prompt.rename': '新的 profile 名称：',
      'confirm.delete': '确定删除 profile「{name}」？此操作不可撤销。',
      'error.nameRequired': '请输入 profile 名称',
      'error.sourceRequired': '请选择源 profile 并填写新名称',
      'msg.created': '已创建 profile：{name}',
      'msg.creating': '正在创建 profile…',
      'msg.duplicated': '已复制 profile：{name}',
      'msg.duplicating': '正在复制并安装依赖，请稍候…',
      'msg.portUpdated': '已更新端口：{name}',
      'msg.settingPort': '正在设置端口…',
      'msg.copiedCommand': '已复制：{cmd}',
      'msg.renamed': '已重命名 profile：{name}',
      'msg.renaming': '正在重命名…',
      'msg.deleted': '已删除 profile：{name}',
      'msg.deleting': '正在删除…',
    }
    const I18N_EN = {
      'card.name': 'Profile management',
      'card.desc': 'View, create, duplicate, rename, delete and set the port of DSH profiles.',
      'msg.working': 'Working…',
      'list.loading': 'Loading…',
      'list.empty': 'No profiles yet — create one below.',
      'badge.initialized': 'Initialized',
      'badge.uninitialized': 'Not initialized',
      'badge.builtin': 'Built-in',
      'panel.noBundle': '(no bundle)',
      'panel.port': 'Port {port}',
      'panel.portUnset': 'No port',
      'panel.depCount': '{count} dependencies',
      'panel.missingPatch': ' · missing cordis.patch.yml',
      'panel.startHint': 'Start: {cmd}',
      'panel.createTitle': 'New profile',
      'panel.duplicateTitle': 'Duplicate profile',
      'btn.refresh': 'Refresh',
      'btn.create': 'Create',
      'btn.copy': 'Duplicate',
      'btn.delete': 'Delete',
      'btn.deleteProtected': 'The default profile cannot be deleted',
      'btn.port': 'Port',
      'btn.rename': 'Rename',
      'btn.copyCommand': 'Copy start command',
      'option.baseTemplate': 'Base template (core only / custom development)',
      'option.templateWeb': 'web (base + web-app)',
      'option.templateHeadless': 'headless (base + headless)',
      'option.noProfile': '(create a profile first)',
      'placeholder.name': 'Name, e.g. dev',
      'placeholder.port': 'Port (optional)',
      'placeholder.dupName': 'New name, e.g. dev-copy',
      'prompt.port': 'Startup port (leave empty to clear, 0 to auto-assign):',
      'prompt.rename': 'New profile name:',
      'confirm.delete': 'Delete profile “{name}”? This cannot be undone.',
      'error.nameRequired': 'Enter a profile name',
      'error.sourceRequired': 'Pick a source profile and enter a new name',
      'msg.created': 'Created profile {name}',
      'msg.creating': 'Creating the profile…',
      'msg.duplicated': 'Duplicated profile {name}',
      'msg.duplicating': 'Duplicating and installing dependencies, please wait…',
      'msg.portUpdated': 'Updated the port of {name}',
      'msg.settingPort': 'Setting the port…',
      'msg.copiedCommand': 'Copied: {cmd}',
      'msg.renamed': 'Renamed the profile to {name}',
      'msg.renaming': 'Renaming…',
      'msg.deleted': 'Deleted profile {name}',
      'msg.deleting': 'Deleting…',
    }
    /* ==== dsh-i18n:end ==== */

    /** 占位符替换：`{name}` → params.name（缺参留空，不抛错——文案不该打死界面）。 */
    function i18nFormat(text, params) {
      if (params === undefined) return text
      return String(text).replace(/\{(\w+)\}/g, (_match, name) => (params[name] === undefined ? '' : String(params[name])))
    }

    /** 中文兜底：老宿主（DSH ≤0.1.5）没有 locale 服务时，界面不能变成一串键名。 */
    function i18nFallback(key, params) {
      return i18nFormat(I18N_ZH[key] !== undefined ? I18N_ZH[key] : key, params)
    }

    let t = i18nFallback

    /**
     * 注册目录并绑定翻译函数。**动态 inject**：老宿主上回调永不触发、`t` 保持中文兜底；
     * 写成静态 `inject: ['locale']` 会让整张卡片在老宿主上根本不挂。
     *
     * 语言切换不用自己订阅：插槽 outlet 随 locale revision 重渲染（renderer 的
     * `useLocaleRevision`），而 `bind()` 返回的翻译函数在**调用时**读当前语言。
     */
    function installI18n(ctx) {
      ctx.inject(['locale'], (i18nCtx) => {
        const disposeZh = i18nCtx.locale.register(I18N_NS, 'zh', I18N_ZH)
        const disposeEn = i18nCtx.locale.register(I18N_NS, 'en', I18N_EN)
        t = i18nCtx.locale.bind(I18N_NS)
        return () => {
          disposeEn()
          disposeZh()
          t = i18nFallback
        }
      })
    }

    /* ================================ 面板状态 ================================ */

    const state = {
      profiles: [],
      home: '',
      profilesRoot: '',
      loading: false,
      busy: false,
      busyText: '',
      error: '',
      ok: '',
      newName: '',
      newTemplate: '',
      newPort: '',
      dupName: '',
      dupFrom: '',
    }

    let panelEl
    let toastEl
    let toastTimer
    let busyEl

    function toast(message, kind) {
      if (!toastEl) {
        toastEl = document.createElement('div')
        toastEl.className = 'pf_toast'
        document.body.appendChild(toastEl)
      }
      toastEl.textContent = message
      toastEl.dataset.kind = kind || 'info'
      toastEl.style.display = 'block'
      clearTimeout(toastTimer)
      toastTimer = setTimeout(() => {
        if (toastEl) toastEl.style.display = 'none'
      }, 2400)
    }


    function showBusy(message) {
      if (!busyEl) {
        busyEl = document.createElement('div')
        busyEl.className = 'pf_busyOverlay'
        document.body.appendChild(busyEl)
      }
      busyEl.textContent = message
      busyEl.style.display = 'block'
    }

    function hideBusy() {
      if (busyEl) {
        busyEl.style.display = 'none'
      }
    }

    async function load() {
      state.loading = true
      state.error = ''
      state.ok = ''
      renderAll(panelEl)
      try {
        const data = await apiList()
        state.profiles = data.profiles || []
        state.home = data.home || ''
        state.profilesRoot = data.profilesRoot || ''
      } catch (error) {
        state.error = error.message || String(error)
      } finally {
        state.loading = false
        renderAll(panelEl)
      }
    }

    async function run(action, successMessage, busyMessage) {
      if (state.busy) return
      state.busy = true
      state.busyText = busyMessage || t('msg.working')
      state.error = ''
      state.ok = ''
      showBusy(state.busyText)
      renderAll(panelEl)
      try {
        await action()
        await load()
        state.ok = successMessage
      } catch (error) {
        state.error = error.message || String(error)
      } finally {
        state.busy = false
        state.busyText = ''
        hideBusy()
        renderAll(panelEl)
      }
    }

    /* ================================ 渲染 ================================ */

    const ESC_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }
    const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ESC_MAP[c])

    function renderProfiles() {
      if (state.loading) return '<div class="pf_loading">' + t('list.loading') + '</div>'
      if (state.profiles.length === 0) return '<div class="pf_empty">' + t('list.empty') + '</div>'
      return '<div class="pf_list">' + state.profiles.map((profile) => {
        const status = profile.initialized
          ? '<span class="pf_badge" data-kind="ok">' + t('badge.initialized') + '</span>'
          : '<span class="pf_badge" data-kind="warn">' + t('badge.uninitialized') + '</span>'
        const bundles = Array.isArray(profile.bundles) && profile.bundles.length > 0
          ? esc(profile.bundles.join(', '))
          : t('panel.noBundle')
        const deps = Object.keys(profile.dependencies || {}).length
        const portText = profile.port != null ? t('panel.port', { port: profile.port }) : t('panel.portUnset')
        const launchCmd = 'dsh --profile ' + profile.name + (profile.port != null ? ' --port ' + profile.port : '')
        const protectedProfile = profile.name === 'web'
        const deleteButton = protectedProfile
          ? '<button class="pf_btnGhost pf_btnDanger" disabled title="' + esc(t('btn.deleteProtected')) + '">' + t('btn.delete') + '</button>'
          : '<button class="pf_btnGhost pf_btnDanger" data-action="delete" data-name="' + esc(profile.name) + '">' + t('btn.delete') + '</button>'
        return '<div class="pf_card">' +
          '<div class="pf_cardRow">' +
            '<span class="pf_cardName">' + esc(profile.name) + '</span>' +
            status +
            (protectedProfile ? '<span class="pf_badge" data-kind="warn">' + t('badge.builtin') + '</span>' : '') +
            '<span class="pf_badge">' + esc(portText) + '</span>' +
            '<span class="pf_cardSummary">' + bundles + ' · ' + t('panel.depCount', { count: deps }) + '</span>' +
            '<span class="pf_cardActions">' +
              '<button class="pf_btnGhost" data-action="port" data-name="' + esc(profile.name) + '">' + t('btn.port') + '</button>' +
              '<button class="pf_btnGhost" data-action="copy-command" data-name="' + esc(profile.name) + '">' + t('btn.copyCommand') + '</button>' +
              '<button class="pf_btnGhost" data-action="rename" data-name="' + esc(profile.name) + '">' + t('btn.rename') + '</button>' +
              '<button class="pf_btnGhost" data-action="dup" data-name="' + esc(profile.name) + '">' + t('btn.copy') + '</button>' +
              deleteButton +
            '</span>' +
          '</div>' +
          '<div class="pf_hint">' + esc(profile.dir) + (profile.patchExists ? '' : t('panel.missingPatch')) + '<br>' + esc(t('panel.startHint', { cmd: launchCmd })) + '</div>' +
        '</div>'
      }).join('') + '</div>'
    }

    function renderPanel() {
      const options = state.profiles.map((profile) =>
        '<option value="' + esc(profile.name) + '">' + esc(profile.name) + '</option>',
      ).join('')
      return '<div class="pf_panel">' +
        '<div class="pf_panelHeader">' +
          '<h3 class="pf_panelTitle">' + t('card.name') + '</h3>' +
          '<span class="pf_subtitle">' + esc(state.profilesRoot || state.home + '/profiles') + '</span>' +
          '<span class="pf_toolbar"><button class="pf_btnGhost" id="pfRefresh">' + t('btn.refresh') + '</button></span>' +
        '</div>' +
        (state.error ? '<div class="pf_banner" data-kind="error">' + esc(state.error) + '</div>' : '') +
        (state.ok ? '<div class="pf_banner" data-kind="ok">' + esc(state.ok) + '</div>' : '') +
        (state.busy ? '<div class="pf_banner" data-kind="info">' + esc(state.busyText) + '</div>' : '') +
        renderProfiles() +
        '<div class="pf_form">' +
          '<div class="pf_formTitle">' + t('panel.createTitle') + '</div>' +
          '<div class="pf_formRow">' +
            '<input class="pf_input" id="pfNewName" placeholder="' + esc(t('placeholder.name')) + '" value="' + esc(state.newName) + '">' +
            '<select class="pf_select" id="pfNewTemplate">' +
              '<option value="">' + t('option.baseTemplate') + '</option>' +
              '<option value="web">' + t('option.templateWeb') + '</option>' +
              '<option value="headless">' + t('option.templateHeadless') + '</option>' +
            '</select>' +
            '<input class="pf_input" id="pfNewPort" placeholder="' + esc(t('placeholder.port')) + '" value="' + esc(state.newPort) + '">' +
            '<button class="pf_btn" id="pfCreate" ' + (state.busy ? 'disabled' : '') + '>' + t('btn.create') + '</button>' +
          '</div>' +
        '</div>' +
        '<div class="pf_form">' +
          '<div class="pf_formTitle">' + t('panel.duplicateTitle') + '</div>' +
          '<div class="pf_formRow">' +
            '<select class="pf_select" id="pfDupFrom">' + (options || '<option value="">' + t('option.noProfile') + '</option>') + '</select>' +
            '<input class="pf_input" id="pfDupName" placeholder="' + esc(t('placeholder.dupName')) + '" value="' + esc(state.dupName) + '">' +
            '<button class="pf_btn" id="pfDup" ' + (state.busy ? 'disabled' : '') + '>' + t('btn.copy') + '</button>' +
          '</div>' +
        '</div>' +
      '</div>'
    }

    function renderAll(host) {
      if (!host) return
      host.innerHTML = renderPanel()
    }

    /* ================================ 事件 ================================ */

    function handleClick(event) {
      const target = event.target
      if (!target || !panelEl || !panelEl.contains(target)) return

      if (target.id === 'pfRefresh') {
        load()
        return
      }
      if (target.id === 'pfCreate') {
        const nameInput = document.getElementById('pfNewName')
        const templateSelect = document.getElementById('pfNewTemplate')
        const portInput = document.getElementById('pfNewPort')
        state.newName = nameInput ? nameInput.value.trim() : ''
        state.newTemplate = templateSelect ? templateSelect.value : ''
        state.newPort = portInput ? portInput.value.trim() : ''
        if (!state.newName) {
          state.error = t('error.nameRequired')
          renderAll(panelEl)
          return
        }
        const name = state.newName
        const template = state.newTemplate
        const port = state.newPort === '' ? null : state.newPort
        run(() => apiCreate(name, template, port), t('msg.created', { name }), t('msg.creating'))
        return
      }
      if (target.id === 'pfDup') {
        const fromSelect = document.getElementById('pfDupFrom')
        const nameInput = document.getElementById('pfDupName')
        state.dupFrom = fromSelect ? fromSelect.value : ''
        state.dupName = nameInput ? nameInput.value.trim() : ''
        if (!state.dupFrom || !state.dupName) {
          state.error = t('error.sourceRequired')
          renderAll(panelEl)
          return
        }
        const from = state.dupFrom
        const name = state.dupName
        run(() => apiDuplicate(name, from), t('msg.duplicated', { name }), t('msg.duplicating'))
        return
      }
      const action = target.dataset && target.dataset.action
      const name = target.dataset && target.dataset.name
      if (action === 'dup') {
        state.dupFrom = name || ''
        state.dupName = (name || '') + '-copy'
        renderAll(panelEl)
        const fromSelect = document.getElementById('pfDupFrom')
        const nameInput = document.getElementById('pfDupName')
        if (fromSelect) fromSelect.value = state.dupFrom
        if (nameInput) nameInput.value = state.dupName
        return
      }
      if (action === 'port') {
        if (!name) return
        const profile = state.profiles.find((item) => item.name === name)
        const current = profile && profile.port != null ? String(profile.port) : ''
        const input = window.prompt(t('prompt.port'), current)
        if (input === null) return
        const port = input.trim() === '' ? null : input.trim()
        run(() => apiSetPort(name, port), t('msg.portUpdated', { name }), t('msg.settingPort'))
        return
      }
      if (action === 'copy-command') {
        if (!name) return
        const profile = state.profiles.find((item) => item.name === name)
        const port = profile && profile.port != null ? ' --port ' + profile.port : ''
        const cmd = 'dsh --profile ' + name + port
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(cmd).then(() => {
            toast(t('msg.copiedCommand', { cmd }), 'ok')
          }).catch(() => {
            window.prompt(t('btn.copyCommand'), cmd)
          })
        } else {
          window.prompt(t('btn.copyCommand'), cmd)
        }
        return
      }
      if (action === 'rename') {
        if (!name) return
        const newName = window.prompt(t('prompt.rename'), name)
        if (!newName || newName.trim() === '' || newName === name) return
        run(() => apiRename(name, newName.trim()), t('msg.renamed', { name: newName.trim() }), t('msg.renaming'))
        return
      }

      if (action === 'delete') {
        if (!name) return
        if (!window.confirm(t('confirm.delete', { name }))) return
        run(() => apiDelete(name), t('msg.deleted', { name }), t('msg.deleting'))
      }
    }

    function bindEvents() {
      document.addEventListener('click', handleClick, true)
    }

    /* ================================ 设置卡片（React 外壳） ================================ */

    const CHEVRON_PATH = 'M11.8486 5.5L11.4238 5.92383L8.69727 8.65137C8.44157 8.90706 8.21562 9.13382 8.01172 9.29785C7.79912 9.46883 7.55595 9.61756 7.25 9.66602C7.08435 9.69222 6.91565 9.69222 6.75 9.66602C6.44405 9.61756 6.20088 9.46883 5.98828 9.29785C5.78438 9.13382 5.55843 9.13382 5.30273 8.65137L2.57617 5.92383L2.15137 5.5L3 4.65137L3.42383 5.07617L6.15137 7.80273C6.42595 8.07732 6.59876 8.24849 6.74023 8.3623C6.87291 8.46904 6.92272 8.47813 6.9375 8.48047C6.97895 8.48703 7.02105 8.48703 7.0625 8.48047C7.07728 8.47813 7.12709 8.46904 7.25977 8.3623C7.40124 8.24849 7.57405 8.07732 7.84863 7.80273L10.5762 5.07617L11 4.65137L11.8486 5.5Z'

    function ProfileSettingsCard(props) {
      // DSH ≥0.1.6 的插件配置页把同一条目按 view 渲染两次：summary 一句话摘要、page 完整表单。
      // 旧版（≤0.1.5）的 settings.plugin.item 卡片不带 view，走原有可折叠卡片分支。
      const view = props && props.view
      const pageView = view === 'page'
      const [open, setOpen] = React.useState(pageView)
      const hostRef = React.useRef(null)
      React.useEffect(() => {
        if (!open) return
        const host = hostRef.current
        if (host === null) return
        panelEl = host
        load()
      }, [open])
      if (view === 'summary') {
        return t('card.desc')
      }

      // page 视图：新页面自己画标题/图标/面包屑，这里只交表单本体，不渲染卡片头。
      return jsxs(pageView ? 'div' : 'li', {
        className: pageView ? 'pf_pageHost' : (open ? 'pf_pluginCard pf_pluginCardOpen' : 'pf_pluginCard'),
        children: [
          pageView ? null : jsxs('button', {
            type: 'button',
            className: 'pf_cardHeader',
            'aria-expanded': open,
            onClick: () => setOpen((current) => !current),
            children: [
              jsxs('span', {
                className: 'pf_cardHeadText',
                children: [
                  jsx('span', { className: 'pf_cardName', children: t('card.name') }),
                  jsx('span', { className: 'pf_cardDescription', children: t('card.desc') }),
                ],
              }),
              jsx('span', { className: 'dshkit_badge', children: 'Kit' }),
              jsx('svg', {
                width: '14',
                height: '14',
                viewBox: '0 0 14 14',
                fill: 'none',
                xmlns: 'http://www.w3.org/2000/svg',
                className: 'pf_chevron',
                children: jsx('path', { d: CHEVRON_PATH, fill: 'currentColor' }),
              }),
            ],
          }),
          (pageView || open) ? jsx('div', {
            className: 'pf_cardBody',
            children: jsx('div', { ref: hostRef, className: 'pf_cardHost' }),
          }) : null,
        ],
      })
    }

    /* ================================ 插件入口 ================================ */

    exports.inject = ['slots']

    /**
     * DSH ≥0.1.6-alpha.2 的行配置 key：`<bundle 包名>#<行 id>`，行 id 取自 bundle 的
     * cordis.patch.yml。独立安装时 bundle 是本包，装全家桶时是 @hyzyn/dsh-all —— 两个都注册，
     * 未命中的那个只是躺在 ledger 里，不会渲染。
     */
    const ROW_CONFIG_KEYS = [
      '@hyzyn/dsh-profile#profile-manager',
      '@hyzyn/dsh-all#profile-manager',
    ]

    exports.apply = (ctx) => {
      installI18n(ctx)
      ctx.effect(() => {
        ensureStyle()
        bindEvents()
        return () => {
          document.removeEventListener('click', handleClick, true)
          styleEl?.remove()
          styleEl = undefined
          toastEl?.remove()
          toastEl = undefined
          busyEl?.remove()
          busyEl = undefined
          panelEl = undefined
        }
      })
      /*
       * 设置面：0.2.0-rc.1 起挂 `plugins.bundle.config`——key 是 **bundle 包名**，管理器的插件
       * 详情页把它渲染在「说明」正下方；`plugins.row.config` 是 per-row 的「>」子页。
       *
       * 两条硬约束（第一条踩过坑，见下）：
       *   ① `plugins.bundle.config` 的 key 是**共享命名空间**：同一个 key 只能有一个注册者，
       *      重复注册**直接抛错**（`keyed slot ... already has an entry`），而客户端 `apply`
       *      抛错 = 整个插件起不来（实测：把 `@hyzyn/dsh-all` 也挂上时，八个插件抢同一个 key，
       *      启动页直接变「Failed to load plugins」）（D158）。聚合包 `@hyzyn/dsh-all` 是所有插件共用的
       *      bundle，**不能**挂 bundle.config —— 它没有内联位，设置面走它自己的 row 入口。
       *   ② 内联位可用时，**本包自己的** bundle 不再注册 row 槽（同一份表单两个入口会让人以为
       *      有两套设置）；聚合包那份 row 入口**保留**（那是它在聚合安装下的唯一入口）。旧宿主
       *      （bundle 槽不存在，0.1.6 线）回退注册全部 row 槽，功能一点不减。
       * 就绪顺序不敏感：任一侧先到都收敛到「内联优先」（后到的本包 row 注册会被撤掉）。
       */
      const AGGREGATE_BUNDLE = '@hyzyn/dsh-all'
      const BUNDLE_NAMES = [...new Set(ROW_CONFIG_KEYS.map((key) => key.split('#')[0]))]
      const OWN_BUNDLE = BUNDLE_NAMES.find((name) => name !== AGGREGATE_BUNDLE)
      let bundleConfigLive = false
      const disposeOwnRowConfigs = []
      if (OWN_BUNDLE !== undefined) {
        ctx.slots.inject('plugins.bundle.config', () => {
          bundleConfigLive = true
          while (disposeOwnRowConfigs.length > 0) {
            const disposeRow = disposeOwnRowConfigs.pop()
            if (typeof disposeRow === 'function') disposeRow()
          }
          return ctx.slots.register({
            name: 'plugins.bundle.config',
            key: OWN_BUNDLE,
          }, ProfileSettingsCard)
        })
      }
      for (const key of ROW_CONFIG_KEYS) {
        ctx.slots.inject('plugins.row.config', () => {
          const own = key.split('#')[0] === OWN_BUNDLE
          if (own && bundleConfigLive) return undefined
          const disposeRow = ctx.slots.register({
            name: 'plugins.row.config',
            key,
          }, ProfileSettingsCard)
          if (own) disposeOwnRowConfigs.push(disposeRow)
          return disposeRow
        })
      }
      // DSH ≥0.1.6：设置里与「通用设置」平级的「插件配置」页（子 slot 由
      // @hyzyn/dsh-kit-settings 声明）。不传 view，卡片走各自原有的可折叠形态。
      ctx.slots.inject('settings.kit.item', () => ctx.slots.register({
        name: 'settings.kit.item',
        id: 'profile-manager',
        order: 40,
        label: () => t('card.name'),
      }, ProfileSettingsCard))
      // DSH ≤0.1.5：设置 → 插件 的「插件配置」标签页，keyed 插槽按 settings 命名空间派发。
      ctx.slots.inject('settings.plugin.item', () => ctx.slots.register({
        name: 'settings.plugin.item',
        // settings.plugin.item 是 keyed 插槽：key 必须是该卡片所编辑的 settings 命名空间
        key: 'profile-manager',
        order: 92,
      }, ProfileSettingsCard))
    }

    return exports
  },
})
