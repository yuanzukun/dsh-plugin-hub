/**
 * @hyzyn/dsh-docker — Docker CLI 封装与输出解析。
 *
 * 设计要点：
 *   - **命令一律以 argv 数组构造**，远程经 shJoin 单引号转义、本机直接
 *     spawn（不经 shell）；用户输入（容器名/ID/命令）先过 assertRef 白名单。
 *   - **解析容错优先**：docker CLI 的 `--format '{{json .}}'` 字段随版本增减，
 *     解析器对缺字段一律降级（State 缺失就从 Status 推导），不抛异常；
 *     需要权威数据时用 `docker inspect`。
 *   - 纯函数（parse*）单独导出，供 scripts/smoke.mjs 用固定输出做回归。
 */
import type { ExecResult, HostKeyStore, SshSpec, ExecLogger, StreamHandlers, StreamResult } from './ssh-exec.js'
import { RemoteExec, runLocal, runLocalStream, sshTarget } from './ssh-exec.js'
import { diagnose } from './diagnose.js'
import type { Diagnosis } from './diagnose.js'
import { buildRunCommand } from './recreate.js'
import type { RecreateResult } from './recreate.js'

export type { StreamHandlers, StreamResult } from './ssh-exec.js'

/* ------------------------------------------------------------------ *
 * 通用：校验与解析工具
 * ------------------------------------------------------------------ */

/** 容器名 / ID / 镜像引用白名单（docker 允许字母数字与 _.- ，首字符为字母数字）。 */
const REF_RE = /^[A-Za-z0-9][A-Za-z0-9_.-]*$/

/** 校验一个 docker 引用（容器名 / ID / 镜像）。不合法直接抛错，绝不拼接进命令。 */
export function assertRef(value: unknown, field: string): string {
  if (typeof value !== 'string' || value.trim() === '') throw new Error(`${field} 不能为空`)
  const trimmed = value.trim()
  if (trimmed.length > 128) throw new Error(`${field} 过长（≤128 字符）`)
  if (!REF_RE.test(trimmed)) throw new Error(`${field} 含非法字符（仅允许字母、数字、_ . -）：${trimmed}`)
  return trimmed
}

/**
 * docker CLI 可执行文件 / 路径的白名单（argv[0]，不设默认值以免误用其他程序）。
 *
 * 字符集必须容得下 **Windows 绝对路径**：`C:\Program Files\Docker\Docker\resources\
 * bin\docker.exe` 里有盘符 `:`、分隔符 `\` 和空格。这三样缺任何一个，Windows 用户都
 * 填不进自己的 docker —— 而填不进时拿到的是 400，却没有一句话解释为什么（真机实测）。
 *
 * 仍然拒绝：`;` `&` `|` `<` `>` 引号 反引号 `$` `%` `!` `^` 换行等 shell 元字符，
 * 以及**任何**以 `-` 开头的 token（看起来像 flag 的值会被 docker 当选项解析）——
 * 校验的是每一个空格分隔的 token，不是只看整串首字符（D43）。空格只允许出现在
 * 内部且不成串。本机通道一律以 argv 数组启动、不经 shell（远程走 shJoin），这层是纵深防御。
 */
const BIN_RE = /^(?!-)[A-Za-z0-9_./:\\-]+(?: (?!-)[A-Za-z0-9_./:\\-]+)*$/

/** 校验 docker CLI 可执行文件路径；空值回落到 `docker`。 */
export function assertBin(value: unknown): string {
  if (typeof value !== 'string' || value.trim() === '') return 'docker'
  const trimmed = value.trim()
  if (!BIN_RE.test(trimmed)) throw new Error(`dockerBin 含非法字符（仅允许字母、数字与 _ . / \\ : - 及内部空格，且不能以 - 开头）：${trimmed}`)
  return trimmed
}

/**
 * 镜像引用白名单：比容器名宽松——允许 registry / 仓库路径 / tag / digest
 * （`ghcr.io/foo/bar:1.2`、`sha256:...`、`repo@sha256:...`），但仍拒绝空格、
 * 引号、`;`、`$()`、反引号等 shell 元字符，且**首字符必须是字母数字**——
 * 这样 `-f` / `--force` 这类看起来像 flag 的输入会被直接拒绝，不会被 docker
 * 当成选项解析。命令一律以 argv 数组构造（本机不经 shell、远程经 shJoin 转义），
 * 这层白名单是纵深防御。
 */
const IMAGE_REF_RE = /^[A-Za-z0-9][A-Za-z0-9_.:/@-]*$/

/** 校验一个镜像引用（tag / digest / ID）。不合法直接抛错，绝不拼接进命令。 */
export function assertImageRef(value: unknown, field: string): string {
  if (typeof value !== 'string' || value.trim() === '') throw new Error(`${field} 不能为空`)
  const trimmed = value.trim()
  if (trimmed.length > 255) throw new Error(`${field} 过长（≤255 字符）`)
  if (!IMAGE_REF_RE.test(trimmed)) throw new Error(`${field} 含非法字符（仅允许字母、数字与 _ . : / @ -）：${trimmed}`)
  return trimmed
}

/**
 * 网络 / 卷名白名单：比镜像引用更窄——docker 的网络名与卷名都不允许 `/` 和 `:`。
 * 刻意**不复用** assertImageRef：那一个为了 registry / digest 放行了 `/:@`，
 * 拿来做这里的校验等于把口径放宽了（比如 `a/b` 会被放行）。
 * 首字符必须是字母数字，`--force` 这类看起来像 flag 的输入在进 argv 前就被拒。
 */
const NAME_RE = /^[A-Za-z0-9][A-Za-z0-9_.-]*$/

/** 校验一个 docker 网络 / 卷名（也是 inspect / rm 的引用）。 */
export function assertName(value: unknown, field: string): string {
  if (typeof value !== 'string' || value.trim() === '') throw new Error(`${field} 不能为空`)
  const trimmed = value.trim()
  if (trimmed.length > 128) throw new Error(`${field} 过长（≤128 字符）`)
  if (!NAME_RE.test(trimmed)) throw new Error(`${field} 含非法字符（仅允许字母、数字与 _ . -）：${trimmed}`)
  return trimmed
}

/**
 * 容器名过滤（`docker ps --filter name=<值>`）的校验。
 *
 * 与 `assertRef` 分开：那里是**引用**（要能在 argv 里寻址一个对象，宽松了就可能
 * 被当成 flag），这里是**过滤词**（含空串 = 不过滤，交给调用方决定）。它同样进
 * argv，所以仍拒绝空串以外的注入面（空白 / 换行 / 引号 / shell 元字符）。
 *
 * 为什么允许 `.` `_` `-`：compose 生成的容器名常是 `proj-web-1` / `proj_db_1`，
 * 名字过滤的主要用途正是「在一台跑了几十个容器的机器上找出一个 compose 项目」。
 */
export function assertPsName(value: unknown): string | undefined {
  if (value === undefined || value === null) return undefined
  if (typeof value !== 'string') throw new Error('name 必须是字符串（按容器名子串过滤）')
  const trimmed = value.trim()
  if (trimmed === '') return undefined
  if (trimmed.length > 128) throw new Error('name 过长（≤128 字符）')
  if (!NAME_RE.test(trimmed)) throw new Error(`name 含非法字符（仅允许字母、数字与 _ . -）：${trimmed}`)
  return trimmed
}

/** `docker exec` 精确参数数组的上限（与命令串的 8000 字符上限是两套口径）。 */
export const EXEC_ARGV_MAX_ITEMS = 128
export const EXEC_ARGV_MAX_CHARS = 32_768

/**
 * 校验 `docker exec` 的**精确参数数组**（argv 模式）。
 *
 * 与 `command` 字符串模式的差别就是这里存在的理由：字符串交给容器内 `sh -c`，
 * 空格、引号、空参数都要经过一层 shell 解析；argv 模式一个 token 一个参数，
 * 宿主与容器都不做展开。代价是**不能再依赖 shell**（管道 / 变量要自己显式写
 * `["sh", "-c", "..."]`），所以这是一条可选的第二条通道，不是替换。
 *
 * 逐项保留原样（不 trim）：空参数 `""` 是合法且**有意义**的（`printf '%s' ""`）。
 * 只拒绝会让 docker CLI 无法安全传参的形状：非字符串、NUL、首项为空、总量过大。
 */
export function assertExecArgv(value: unknown): string[] {
  if (!Array.isArray(value)) throw new Error('argv 必须是字符串数组')
  if (value.length === 0) throw new Error('argv 不能为空（至少一个参数）')
  if (value.length > EXEC_ARGV_MAX_ITEMS) throw new Error(`argv 最多 ${String(EXEC_ARGV_MAX_ITEMS)} 项（当前 ${String(value.length)}）`)
  let total = 0
  for (const item of value) {
    if (typeof item !== 'string') throw new Error('argv 的每一项都必须是字符串')
    if (item.includes('\0')) throw new Error('argv 不能包含 NUL 字符')
    total += item.length
  }
  if (total > EXEC_ARGV_MAX_CHARS) throw new Error(`argv 总长超过 ${String(EXEC_ARGV_MAX_CHARS)} 字符（当前 ${String(total)}）`)
  if ((value[0] ?? '').trim() === '') throw new Error('argv 的第一项不能为空（它是容器内要执行的命令）')
  return [...value]
}

/** 逐行 JSON 解析：兼容 `{{json .}}`（每行一个对象）与整体 JSON 数组。 */
export function parseJsonLines(text: string): Record<string, unknown>[] {
  const trimmed = text.trim()
  if (trimmed === '') return []
  if (trimmed.startsWith('[')) {
    try {
      const parsed: unknown = JSON.parse(trimmed)
      if (Array.isArray(parsed)) return parsed.filter((item): item is Record<string, unknown> => typeof item === 'object' && item !== null)
    } catch {
      /* 落到逐行解析 */
    }
  }
  const rows: Record<string, unknown>[] = []
  for (const line of trimmed.split(/\r?\n/)) {
    const one = line.trim()
    if (one === '' || !one.startsWith('{')) continue
    try {
      const parsed: unknown = JSON.parse(one)
      if (typeof parsed === 'object' && parsed !== null) rows.push(parsed as Record<string, unknown>)
    } catch {
      /* 跳过非 JSON 行（警告文本等） */
    }
  }
  return rows
}

/** 取字符串字段（大小写不敏感，兼容不同版本字段名）。 */
function str(row: Record<string, unknown>, ...keys: string[]): string {
  for (const key of keys) {
    const direct = row[key]
    if (typeof direct === 'string') return direct
    const lower = row[key.toLowerCase()]
    if (typeof lower === 'string') return lower
    const upper = row[key.toUpperCase()]
    if (typeof upper === 'string') return upper
  }
  return ''
}

/** `12.3MiB` / `1.2kB` / `0B` → 字节数（解析失败返回 null）。 */
export function parseDockerSize(text: string): number | null {
  const match = /^\s*([0-9]+(?:\.[0-9]+)?)\s*([a-zA-Z]*)\s*$/.exec(text)
  if (match === null) return null
  const value = Number(match[1])
  const unit = (match[2] ?? '').toLowerCase()
  const scale: Record<string, number> = {
    '': 1,
    b: 1,
    kb: 1e3,
    kib: 1024,
    mb: 1e6,
    mib: 1024 ** 2,
    gb: 1e9,
    gib: 1024 ** 3,
    tb: 1e12,
    tib: 1024 ** 4,
    pb: 1e15,
    pib: 1024 ** 5,
  }
  const factor = scale[unit]
  if (factor === undefined) return null
  return Math.round(value * factor)
}

/** `12.34%` → 12.34（解析失败返回 null）。 */
export function parsePercent(text: string): number | null {
  const match = /^\s*([0-9]+(?:\.[0-9]+)?)\s*%\s*$/.exec(text)
  if (match === null) return null
  return Number(match[1])
}

/** `1.2kB / 0B` → { rx, tx }（解析失败一侧为 null）。 */
export function parseIOPair(text: string): { rx: number | null; tx: number | null } {
  const [left = '', right = ''] = text.split('/')
  return { rx: parseDockerSize(left), tx: parseDockerSize(right) }
}

/** docker 失败时的单行摘要：优先 stderr，其次 stdout，最后退出码。 */
function firstLine(stderr: string, stdout: string, code: number | null): string {
  return (stderr.trim() || stdout.trim() || `退出码 ${String(code)}`).split('\n')[0] ?? `退出码 ${String(code)}`
}

/**
 * 把 docker 的原始 stderr 映射成一句**可执行的下一步**（没有命中返回 null）。
 *
 * 为什么不是「把所有失败都包一层」（D105 的口径）：agent 能做的下一步与它执行过
 * 哪条命令无关，只与**失败类型**有关——daemon 没起、权限不足、CLI 不在 PATH、
 * 容器名写错、端口冲突、超时，修法各自不同。此前这些都只回一句 docker 的英文原话，
 * 模型只能原样重试；加上这一层之后，同一段原文后面直接跟「该去做什么」。
 *
 * 判据刻意保守：只认**docker / 我们自己的 SSH 层真的会打出来**的片段。猜测式的
 * 匹配（比如任何包含 error 的行）会把真正的业务报错也改写成运维建议，那比不提示更糟。
 */
export function dockerErrorHint(text: string): string | null {
  if (/Cannot connect to the Docker daemon|Is the docker daemon running|docker\.sock: connect|open .*docker\.sock/i.test(text)) {
    return 'daemon 不可达：启动 Docker Desktop / dockerd（Windows 需 WSL2 或 Hyper-V 后端），再用 `docker_targets`（probe:true）复查'
  }
  if (/permission denied while trying to connect|Got permission denied|permission denied.*docker\.sock/i.test(text)) {
    return '权限不足：把当前用户加入 docker 组并重新登录（SSH 目标要求免 sudo 的 docker）；本机仍失败时确认 dockerBin 指向的 CLI 有执行权限'
  }
  if (/command not found|not recognized as the name|ENOENT|no such file or directory/i.test(text)) {
    return '找不到 docker CLI：PATH 里没有它，把插件配置的 dockerBin 填成绝对路径后重试'
  }
  if (/[Nn]o such container/i.test(text)) {
    return '容器不存在：用 `docker_ps`（all:true 含已停止）确认真实容器名；SSH 目标还要确认 target 选的是那台主机'
  }
  if (/[Nn]o such image/i.test(text)) {
    return '镜像不存在：本地没有就先用 `docker_image_pull` 拉取，`docker_images` 可确认已有哪些'
  }
  if (/context deadline exceeded|i\/o timeout|timed out|timeout/i.test(text)) {
    return '命令超时：目标可能繁忙或网络慢；确认目标与容器状态，必要时调大 timeoutSec（或插件配置里的 execTimeoutSec）后重试'
  }
  if (/port is already allocated|address already in use/i.test(text)) {
    return '端口已被占用：用 `docker_ps` 找到占用该端口的容器，或改用其它端口'
  }
  if (/Conflict\. The container name/i.test(text)) {
    return '容器名冲突：已有同名容器，先用 `docker_ps` 找到它并处理，或改用其它名字'
  }
  if (/no more sessions|Channel open failure|open failed/i.test(text)) {
    return 'SSH 通道额度用尽：先在面板折叠长流（把通道还回去）再重试；根治办法是调大远端 sshd 的 MaxSessions'
  }
  return null
}

/**
 * `--since` 的统一口径（D45）：时长（docker 的 Go duration 语法，允许复合如
 * `1h30m`）、Unix 秒或时间戳。events 与 logs 两条路径此前各有一套——events
 * 白名单偏窄（复合 duration 被拒）、logs 完全不校验（docker 的参数错误变成
 * 不可读的报错）。纯校验函数：合法返回原样串，不合法抛错。
 *
 * 与 docker 的口径**双向对齐**（D99）：
 *   ① duration 支持小数与 `0`——Go 的 `time.ParseDuration` 接受 `1.5h` 与 `0`，
 *      旧正则的 `\d+` 把它们当成非法输入拒了（用户明明写的是合法参数）；
 *   ② 裸数字仍按 docker 语义当 Unix 秒（`--since 3600` = 一小时前）；
 *   ③ 时间戳必须**带时间部分**——`2026-09-13` 这种裸日期此前被放行，docker
 *      多半原样报参数错误，不如在这里拒绝；
 *   ④ 报错回显原始值，否则调用方（尤其是 agent）不知道是哪一段没通过。
 */
export function assertSince(value: unknown, field: string = 'since'): string {
  const usage = '时长（如 30m、2h、1h30m、1.5h）、Unix 秒（如 3600）或含时间的时间戳（如 2026-09-13T10:00:00）'
  if (typeof value !== 'string' || value.trim() === '') throw new Error(`${field} 必填（${usage}）`)
  const text = value.trim()
  // Go duration：`0` 单独合法，其余每段「数字[.小数]+单位」，可复合。单位含
  // µs（U+00B5，Go 文档里的写法）与 μs（U+03BC，常见的希腊字母替代）两种
  if (text === '0' || /^(?:\d+(?:\.\d+)?(?:ns|us|µs|μs|ms|s|m|h))+$/.test(text)) return text
  // 裸数字：docker 按 Unix 秒解释
  if (/^\d+$/.test(text)) return text
  // 时间戳：RFC3339 风格，但 `T` 可写成空格、秒与小数秒可省、时区可省
  if (/^\d{4}-\d{2}-\d{2}[Tt ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?$/.test(text)) return text
  throw new Error(`${field} 无法识别：${text}（只支持 ${usage}）`)
}

/* ------------------------------------------------------------------ *
 * 容器列表（docker ps）
 * ------------------------------------------------------------------ */

export interface PortMapping {
  hostIp?: string
  hostPort?: number
  /** 端口区间映射的宿主侧原文（`8000-8005`）；单端口映射无此字段。 */
  hostPortRange?: [number, number]
  containerPort: number
  /** 端口区间映射的容器侧区间（`8000-8005`）；单端口映射无此字段。 */
  containerPortRange?: [number, number]
  protocol: string
}

export interface ContainerSummary {
  id: string
  shortId: string
  name: string
  image: string
  state: string
  status: string
  health: string | null
  createdAt: string | null
  runningFor: string
  ports: PortMapping[]
  /**
   * 容器所在网络（ps 的 `.Networks`，逗号分隔）。为什么要采（D131）：host 网络容器
   * 在 ps 里**没有端口映射**，`ports` 空与「确实没暴露端口」长得一模一样——只有
   * inspect 才能看出是 host。这个字段让 docker_ps 自己就能说清那一列为什么空。
   */
  networks: string[]
  /** compose 项目 / 服务（有标签时）。 */
  composeProject: string | null
  composeService: string | null
  /** ps 的 `.Size`（需 --size，缺省不请求，通常为空）。 */
  size: string
  /** 已退出容器的退出码（从 `.Status` 的 `Exited (137) …` 解析；非退出态为 null）。 */
  exitCode: number | null
}

/**
 * 「需要关注」的容器（0.15.0）：由摘要筛出候选、再用一次 `docker inspect` 补权威
 * 字段（OOM / 真实退出码 / 重启次数），供面板「需关注」页与 agent 工具使用。
 */
export interface AttentionItem {
  id: string
  shortId: string
  name: string
  image: string
  state: string
  health: string | null
  status: string
  /** 关注原因（可多条；前端据此渲染徽标，agent 侧直出文本）。 */
  reasons: AttentionReason[]
  exitCode: number | null
  oomKilled: boolean
  restartCount: number | null
  startedAt: string | null
  finishedAt: string | null
}

/** 关注原因：不健康 / 正在重启 / 被 OOM 杀 / 非零退出 / 僵死。 */
export type AttentionReason = 'unhealthy' | 'restarting' | 'oom' | 'exit-nonzero' | 'dead'

/** 从 ps 的 `.Status` 解析退出码：`Exited (137) 2 hours ago` → 137。 */
export function parseExitCode(status: string): number | null {
  const match = /^\s*exited\s*\((\d+)\)/i.exec(status)
  if (match === null) return null
  const code = Number(match[1])
  return Number.isInteger(code) ? code : null
}

/* ------------------------------------------------------------------ *
 * attention() 的判据常量（抽在模块级便于回归）
 * ------------------------------------------------------------------ */

/**
 * 「反复重启」的判据阈值（D11）：重启计数 ≥ 该值且刚刚启动的运行中容器计入
 * reasons。阈值不能太低——合法的重新部署也会重启一两次。
 */
const ATTENTION_RESTART_THRESHOLD = 3

/** crash-loop 疑似的「刚启动」窗口：重启退避最长 1 分钟，Up 时间几乎总是秒级。 */
const ATTENTION_FRESH_MS = 120_000

/** inspect 批量上限（候选 + 补捞总量的保险丝）：防巨型主机把输出顶到 maxBytes。 */
const ATTENTION_INSPECT_CAP = 300

/**
 * crash-loop **补捞的独立预算**（D87）：合法三类候选（不健康 / 正在重启 / 非零退出）
 * 先占 ATTENTION_INSPECT_CAP 的名额，补捞另有这 50 个名额。此前补捞与合法候选共用
 * 同一个 300（`if (picked.length >= CAP) break`），主机越乱（300 个 unhealthy）
 * 补捞越一个都进不去——与「反复重启最容易被忽略、才需要补捞」的初衷正好相反。
 * 总量上限因此是 CAP + 本值（≈350），不会随主机规模放大。
 */
const ATTENTION_FRESH_BUDGET = 50

/**
 * 单批 inspect 的 id 数硬上限（D86）：默认 512KB ÷ 40 ≈ 12.8KB/容器，容得下真实的
 * inspect JSON（Config/Labels/Mounts/NetworkSettings/HostConfig，2–6KB）。旧写法一次
 * 送 300 个 id（512KB ÷ 300 ≈ 1.7KB/容器）必然截断，而 assertComplete 一抛错，
 * catch 就把**整批**详情丢掉——比修复前的「尾部静默丢弃」更糟。
 */
const ATTENTION_INSPECT_BATCH = 40

/** 估算单个容器 inspect JSON 的字节数（D86）：用于按 maxBytes 收缩单批大小。 */
const ATTENTION_INSPECT_BYTES_PER_CONTAINER = 8 * 1024

/**
 * 单批 inspect 的 id 数（D86）：既有硬上限，也按调用方配置的 maxBytes 收缩——
 * 把 maxOutputKb 调小的人不该每一批都撞截断（分批的意义就是让失败只影响一批）。
 *
 * 下限 8（而不是 1）：`maxOutputKb` 被调到 1KB 这种极端值下，单容器 inspect 本身就会
 * 超限，每批 1 个只会把「注定降级」变成最多 300 次串行 docker 调用；给个下限让调用次数
 * 有界（≈38 批），降级信号照常由 `degraded` 给出、文案也会提示调大上限。
 */
const ATTENTION_INSPECT_MIN_BATCH = 8
function attentionInspectBatch(maxBytes: number): number {
  const byBudget = Math.floor(maxBytes / ATTENTION_INSPECT_BYTES_PER_CONTAINER)
  return Math.min(ATTENTION_INSPECT_BATCH, Math.max(ATTENTION_INSPECT_MIN_BATCH, byBudget))
}

/**
 * docker ps 的 Status 里「刚刚启动」的形状。**必须覆盖到 ATTENTION_FRESH_MS（D106）**：
 * docker 的 HumanDuration 在 60–119s 给的是 `About a minute`，而判据窗口是 120s——
 * 旧 RE 只认 `\d+ seconds?`（<60s），于是「跑 1–2 分钟才崩」的 crash-loop 在运行
 * 阶段一次都不会入候选（只在刚好崩掉的那一瞬是 exited，很容易错过）。
 * `\d+ minutes?` 由 RE 多放行、再由 freshStart 的 120s 判据挡回：多放行无害，
 * 少放行才是静默漏报——两个窗口必须对齐。
 */
const FRESH_UP_RE = /^up (less than a second|\d+ seconds?|about a minute|\d+ minutes?)( \(|$)/i

/** `startedAt` 落在「刚启动」窗口内（crash-loop 容器最近一次拉起的时间）。 */
function freshStart(iso: string | null): boolean {
  if (iso === null || iso === '') return false
  const time = Date.parse(iso)
  return Number.isFinite(time) && Date.now() - time < ATTENTION_FRESH_MS
}

/** 从 ps 的 `.Status`（`Up 2 hours (healthy)`）推导状态。健康态单独由 deriveHealth 提供。 */
export function deriveState(status: string): string {
  const lower = status.toLowerCase()
  if (lower.startsWith('up')) {
    if (lower.includes('(paused)')) return 'paused'
    if (lower.includes('(restarting)')) return 'restarting'
    // Up 但 unhealthy 的容器状态仍是 running，健康态见 health 字段
    return 'running'
  }
  if (lower.startsWith('exited')) return 'exited'
  if (lower.startsWith('created')) return 'created'
  if (lower.startsWith('restarting')) return 'restarting'
  if (lower.startsWith('paused')) return 'paused'
  if (lower.startsWith('dead')) return 'dead'
  if (lower.startsWith('removal in progress')) return 'removing'
  return 'unknown'
}

/** 从 ps 的 `.Status` 提取健康态（`Up 2 hours (healthy)` → healthy）。 */
export function deriveHealth(status: string): string | null {
  const match = /\((healthy|unhealthy|health: starting)\)/i.exec(status)
  if (match === null) return null
  const value = match[1].toLowerCase()
  return value === 'health: starting' ? 'starting' : value
}

/** 端口号 / 端口区间的解析结果（区间至少保留原文，不再整行丢弃）；port 区间时取下界。 */
function parsePortToken(text: string): { port: number; range?: [number, number] } | null {
  const single = Number(text)
  if (Number.isInteger(single) && single > 0) return { port: single }
  const range = /^(\d+)-(\d+)$/.exec(text)
  if (range !== null) return { port: Number(range[1]), range: [Number(range[1]), Number(range[2])] }
  return null
}

/**
 * 通配 hostIp 归一族（D130）：双栈发布（`0.0.0.0:8848->8848/tcp` 与
 * `[::]:8848->8848/tcp`）是**同一次 -p** 的两种展开，不是两条映射。此前按原文参与
 * 去重，两条都留下；而 ps 的渲染丢掉 hostIp 后就成了「8848→8848/tcp」重复两遍
 * （docker_inspect 因为保留 hostIp 才看着正常）。
 *
 * 只归一化通配符这一族：`127.0.0.1:8080` 与 `0.0.0.0:8080` 并存是真实的两种绑定，
 * 必须继续算两条——所以这里不做「同 hostPort 一律合并」。
 */
function hostIpDedupeKey(hostIp: string): string {
  const trimmed = hostIp.trim()
  return trimmed === '' || trimmed === '0.0.0.0' || trimmed === '::' || trimmed === '[::]' ? '*' : trimmed
}

/** 解析 ps 的 `.Ports` 串：`0.0.0.0:8080->80/tcp, [::]:8080->80/tcp, 9000/tcp, 0.0.0.0:8000-8005->8000-8005/tcp`。 */
export function parsePorts(text: string): PortMapping[] {
  const out: PortMapping[] = []
  const seen = new Set<string>()
  for (const raw of text.split(',')) {
    const item = raw.trim()
    if (item === '') continue
    const arrow = item.split('->')
    if (arrow.length === 2) {
      const [hostPart = '', containerPart = ''] = arrow
      const [containerPortText = '', protocol = 'tcp'] = containerPart.split('/')
      const containerToken = parsePortToken(containerPortText)
      if (containerToken === null) continue
      // hostPart 有两种形态：`0.0.0.0:8080` 与（少数驱动/版本的）裸 `8080`。后者用
      // lastIndexOf(':') = -1 去 slice(0, -1) 会**砍掉最后一个字符**（`84` → hostIp
      // `'8'`）——D130 同批修掉这个既有解析错误。
      const colonAt = hostPart.lastIndexOf(':')
      const hostPortText = colonAt >= 0 ? hostPart.slice(colonAt + 1) : hostPart
      const hostToken = parsePortToken(hostPortText)
      const hostIp = colonAt >= 0 ? hostPart.slice(0, colonAt) : ''
      // 去重键用归一化后的 hostIp（D130）：双栈只留首条；hostIp 原文照旧写进结果
      const key = `${hostIpDedupeKey(hostIp)}:${hostPortText}:${containerPortText}/${protocol}`
      if (seen.has(key)) continue
      seen.add(key)
      // 端口区间（`8000-8005->8000-8005/tcp`）：保留区间字段（D40）——此前 Number 得
      // NaN 直接 continue，整行端口凭空消失
      out.push({
        ...(hostIp === '' ? {} : { hostIp }),
        ...(hostToken?.port !== undefined ? { hostPort: hostToken.port } : {}),
        ...(hostToken?.range !== undefined ? { hostPortRange: hostToken.range } : {}),
        containerPort: containerToken.port,
        ...(containerToken.range !== undefined ? { containerPortRange: containerToken.range } : {}),
        protocol,
      })
      continue
    }
    // 仅暴露容器端口（未映射）：`9000/tcp`
    const [containerPortText = '', protocol = 'tcp'] = item.split('/')
    const containerToken = parsePortToken(containerPortText)
    if (containerToken === null) continue
    const key = `-:${containerPortText}/${protocol}`
    if (seen.has(key)) continue
    seen.add(key)
    out.push({
      containerPort: containerToken.port,
      ...(containerToken.range !== undefined ? { containerPortRange: containerToken.range } : {}),
      protocol,
    })
  }
  return out
}

/** `docker ps --format '{{json .}}'` → ContainerSummary[]。 */
export function parsePsJson(text: string): ContainerSummary[] {
  return parseJsonLines(text).map((row) => {
    const id = str(row, 'ID', 'Id')
    const status = str(row, 'Status')
    const labels = parseLabels(str(row, 'Labels'))
    return {
      id,
      shortId: id.slice(0, 12),
      name: str(row, 'Names', 'Name'),
      image: str(row, 'Image'),
      state: str(row, 'State') === '' ? deriveState(status) : str(row, 'State').toLowerCase(),
      status,
      health: deriveHealth(status),
      createdAt: str(row, 'CreatedAt') === '' ? null : str(row, 'CreatedAt'),
      runningFor: str(row, 'RunningFor'),
      ports: parsePorts(str(row, 'Ports')),
      // ps 的 `.Networks` 是逗号分隔串（host 网络容器为 `host`）
      networks: str(row, 'Networks').split(',').map((name) => name.trim()).filter((name) => name !== ''),
      composeProject: labels['com.docker.compose.project'] ?? null,
      composeService: labels['com.docker.compose.service'] ?? null,
      size: str(row, 'Size'),
      exitCode: parseExitCode(status),
    }
  })
}

/**
 * inspect 未命中时的候选名（D132）：把 `No such object: rmqnamesrv` 变成
 * 「是否想找 607023340cbb_rmqnamesrv？」。
 *
 * 纯函数（名字列表由调用方取，便于离线断言）：前缀命中优先、其次包含；去重后最多 3 个。
 * 精确名匹配是 docker 语义、不改；这里只是**在报错里补一句**，让人少猜一次。
 */
export function suggestContainerNames(id: string, names: string[]): string[] {
  const needle = id.trim().toLowerCase()
  if (needle === '') return []
  const prefix: string[] = []
  const contains: string[] = []
  for (const name of names) {
    if (name === '') continue
    const lower = name.toLowerCase()
    if (lower.startsWith(needle)) prefix.push(name)
    else if (lower.includes(needle)) contains.push(name)
  }
  return [...new Set([...prefix, ...contains])].slice(0, 3)
}

/** ps 的 `.Labels` 是 `k=v,k2=v2` 串。 */
export function parseLabels(text: string): Record<string, string> {
  const out: Record<string, string> = {}
  if (text.trim() === '') return out
  for (const pair of text.split(',')) {
    const eq = pair.indexOf('=')
    if (eq <= 0) continue
    out[pair.slice(0, eq).trim()] = pair.slice(eq + 1).trim()
  }
  return out
}

/* ------------------------------------------------------------------ *
 * 统计（docker stats --no-stream）
 * ------------------------------------------------------------------ */

export interface ContainerStats {
  id: string
  shortId: string
  name: string
  cpuPercent: number | null
  memPercent: number | null
  memUsed: number | null
  memLimit: number | null
  memUsage: string
  netRx: number | null
  netTx: number | null
  netIO: string
  blockRead: number | null
  blockWrite: number | null
  blockIO: string
  pids: number | null
}

/** `docker stats --no-stream --format '{{json .}}'` → ContainerStats[]。 */
export function parseStatsJson(text: string): ContainerStats[] {
  return parseJsonLines(text).map((row) => {
    const id = str(row, 'ID', 'Container', 'ContainerID')
    const mem = str(row, 'MemUsage')
    const [memUsedText = '', memLimitText = ''] = mem.split('/')
    const net = parseIOPair(str(row, 'NetIO'))
    const block = parseIOPair(str(row, 'BlockIO'))
    // PIDs 缺字段时是空串：Number('') === 0 会显示「0 个进程」（D39），与同函数里
    // memUsed / memLimit 缺字段时给 null 的口径对齐
    const pidsText = str(row, 'PIDs')
    const pids = pidsText.trim() === '' ? Number.NaN : Number(pidsText)
    return {
      id,
      shortId: id.slice(0, 12),
      name: str(row, 'Name'),
      cpuPercent: parsePercent(str(row, 'CPUPerc')),
      memPercent: parsePercent(str(row, 'MemPerc')),
      memUsed: parseDockerSize(memUsedText),
      memLimit: parseDockerSize(memLimitText),
      memUsage: mem.trim(),
      netRx: net.rx,
      netTx: net.tx,
      netIO: str(row, 'NetIO').trim(),
      blockRead: block.rx,
      blockWrite: block.tx,
      blockIO: str(row, 'BlockIO').trim(),
      pids: Number.isInteger(pids) ? pids : null,
    }
  })
}

/* ------------------------------------------------------------------ *
 * 进程快照（docker top）
 * ------------------------------------------------------------------ */

/**
 * `docker top <id> -eo <列>` 的列清单：**唯一构造点**（argv 与解析共用同一份顺序）。
 *
 * 为什么钉这八列：本机实测（docker 28.3.2）`docker top <id> -eo <这串>` 的表头稳定，
 * 且 `-eo` 选的列名与 `docker top` 的默认列不同（默认给 `PID TTY TIME CMD`，那是
 * 「容器里那个 tty 在跑什么」，排障没用）。`pcpu` / `pmem` 的表头是 `%CPU` / `%MEM`
 * （ps 的默认 header），所以解析**按表头名归一**而不是按下标猜——见 TOP_HEADER_ALIASES。
 */
export const TOP_PS_FORMAT = 'pid,ppid,user,stat,etime,pcpu,pmem,cmd'

/** `docker top` 单次返回的进程行上限（第二道闸：字节闸之外按行兜一层，超了给 truncated）。 */
export const TOP_MAX_ROWS = 500

/** 容器内一个进程（字段**全 string**：docker 打印什么就是什么，不做单位换算）。 */
export interface TopProcessRow {
  pid: string
  ppid: string
  user: string
  stat: string
  /** ps 的 `etime`（已运行时长，如 `03:24:48`）。 */
  elapsed: string
  /** ps 的 `pcpu`（%CPU）。 */
  cpu: string
  /** ps 的 `pmem`（%MEM）。 */
  mem: string
  /** ps 的 `cmd`（可能含空格，由剩余列合并）。 */
  command: string
}

/** 表头名（归一后）→ 输出字段。表头驱动：列顺序变了也不会错位。 */
const TOP_HEADER_ALIASES: Record<string, keyof TopProcessRow> = {
  pid: 'pid',
  ppid: 'ppid',
  user: 'user',
  uname: 'user',
  stat: 'stat',
  etime: 'elapsed',
  elapsed: 'elapsed',
  pcpu: 'cpu',
  cpu: 'cpu',
  pmem: 'mem',
  mem: 'mem',
  cmd: 'command',
  command: 'command',
  args: 'command',
}

/** 表头单元格归一：小写、去掉 ps 给百分比列的 `%` 前缀。 */
function normalizeTopHeader(cell: string): string {
  return cell.trim().toLowerCase().replace(/^%/, '')
}

/** 空进程行（所有字段都是 string，缺列给空串）。 */
function emptyTopRow(): TopProcessRow {
  return { pid: '', ppid: '', user: '', stat: '', elapsed: '', cpu: '', mem: '', command: '' }
}

/**
 * `docker top -eo …` 的文本输出 → 结构化的进程行。
 *
 * 解析规则（全部由**表头行**驱动）：
 *   - 第一行非空行是表头；每个单元格归一成字段名（`PID` → pid、`%CPU` → cpu）；
 *   - 之后的每一行按空白切成 token：**token 数少于表头列数 → 丢弃该行**（半行 / 被
 *     字节闸切断的行不能当成一条进程）;
 *   - 多出来的 token 全部并进**命令列**（`cmd` 是唯一可以含空格的列，无论它排在
 *     第几列）——其余列各取一个 token，这样列顺序变了也不会错位；
 *   - 表头里认不出的列（不同 ps 版本多给的列）忽略，认不出的行照样保留；
 *   - 输出为空（容器里没有进程 / docker 没打印）→ 空数组，不是错误。
 */
export function parseTopOutput(text: string): { rows: TopProcessRow[]; truncated: boolean } {
  const lines = text.split(/\r?\n/)
  let headerAt = -1
  for (let i = 0; i < lines.length; i++) {
    if ((lines[i] ?? '').trim() !== '') {
      headerAt = i
      break
    }
  }
  if (headerAt === -1) return { rows: [], truncated: false }
  const headers = (lines[headerAt] ?? '').trim().split(/\s+/).map(normalizeTopHeader)
  const mapped = headers.map((cell) => TOP_HEADER_ALIASES[cell] ?? null)
  if (mapped.every((key) => key === null)) return { rows: [], truncated: false }
  // 命令列的位置：表头里说是 cmd 的那一列；认不出来就按「最后一列」处理（ps 的惯例）
  const commandAt = mapped.indexOf('command') === -1 ? headers.length - 1 : mapped.indexOf('command')

  const rows: TopProcessRow[] = []
  for (let i = headerAt + 1; i < lines.length; i++) {
    const line = (lines[i] ?? '').trim()
    if (line === '') continue
    const tokens = line.split(/\s+/)
    // 行数不足 → 丢弃（契约）：半行当成一行进程，比少一行糟得多
    if (tokens.length < headers.length) continue
    const row = emptyTopRow()
    // 多出来的 token 全给命令列；其余列各取一个 token
    const extra = tokens.length - headers.length
    let cursor = 0
    for (let column = 0; column < headers.length; column++) {
      const take = column === commandAt ? extra + 1 : 1
      const value = tokens.slice(cursor, cursor + take).join(' ')
      cursor += take
      const key = mapped[column]
      if (key !== null) row[key] = value
    }
    rows.push(row)
    if (rows.length >= TOP_MAX_ROWS) return { rows, truncated: true }
  }
  return { rows, truncated: false }
}

/* ------------------------------------------------------------------ *
 * 事件（docker events）
 * ------------------------------------------------------------------ */

/**
 * 事件白名单：只放行「容器生命周期」里真正值得刷 UI 的动作。
 *
 * 为什么必须在服务端过滤：docker events 会输出大量噪音（exec_create /
 * exec_start / exec_die 每次 docker exec 三条、attach / detach / resize；
 * network / volume / image 事件已被 --filter type=container 挡掉）。一个跑批的
 * 容器几条 exec 就能把 SSE 帧率顶上去，而客户端收到每一帧都要走一次列表防抖
 * 重取。白名单放服务端，浏览器与 agent 工具（docker_events）拿到的就是同一份。
 */
const EVENT_ACTIONS = new Set(['start', 'die', 'stop', 'kill', 'oom', 'health_status', 'destroy', 'rename', 'update'])

/** 一条容器事件（SSE 帧协议与 docker_events 工具共用同一形状）。 */
export interface ContainerEvent {
  /** 完整动作串；health_status 带状态后缀（如 'health_status: healthy'）。 */
  action: string
  name: string
  image: string
  composeProject: string | null
  /** 事件时间（Unix 秒；缺失为 null，客户端按本地时区格式化）。 */
  time: number | null
  /** 仅 die 事件有：容器退出码。 */
  exitCode: number | null
}

/** 取 Actor.Attributes 里的字符串字段（缺失回空串）。 */
function attr(attributes: Record<string, unknown>, key: string): string {
  const value = attributes[key]
  return typeof value === 'string' ? value : ''
}

/**
 * 单行 docker events --format '{{json .}}' → ContainerEvent；坏行 / 非白名单动作
 * 返回 null，由调用方丢弃：事件流里混进一条解析不了的行（daemon 版本差异、
 * 被截断的 chunk）不该把整条流掐掉，也不该变成 error 帧。
 *
 * Action 在老版本里叫 status；health_status 的两种写法都要吃：
 *   Action: 'health_status: healthy'（新）与 Action: 'health_status'（老）。
 */
export function parseContainerEvent(line: string): ContainerEvent | null {
  const text = line.trim()
  if (text === '' || !text.startsWith('{')) return null
  let row: Record<string, unknown>
  try {
    const parsed: unknown = JSON.parse(text)
    if (typeof parsed !== 'object' || parsed === null) return null
    row = parsed as Record<string, unknown>
  } catch {
    return null
  }
  const rawAction = (str(row, 'Action') || str(row, 'status')).trim()
  if (rawAction === '') return null
  // 'health_status: healthy' → 用冒号前的基础动作过白名单，完整串留给 UI
  const base = (rawAction.split(':')[0] ?? '').trim().toLowerCase()
  if (!EVENT_ACTIONS.has(base)) return null
  const actor = asRecord(row.Actor)
  const attributes = asRecord(actor.Attributes)
  const name = attr(attributes, 'name')
  const exitText = attr(attributes, 'exitCode')
  const exitCode = exitText === '' ? Number.NaN : Number(exitText)
  const timeText = row.time
  const time = typeof timeText === 'number' && Number.isFinite(timeText) ? timeText : null
  const project = attributes['com.docker.compose.project']
  return {
    action: rawAction,
    // 少数事件没有 name（比如容器已删）：回落到 Actor.ID 前 12 位，别让活动条出现空名字
    name: name !== '' ? name : str(actor, 'ID').slice(0, 12),
    image: attr(attributes, 'image'),
    composeProject: project === undefined ? null : String(project),
    time,
    exitCode: Number.isFinite(exitCode) ? exitCode : null,
  }
}

/** 多行事件输出 → ContainerEvent[]（逐行解析，坏行直接丢）。 */
export function parseEventsJson(text: string): ContainerEvent[] {
  const out: ContainerEvent[] = []
  for (const line of text.split(/\r?\n/)) {
    const event = parseContainerEvent(line)
    if (event !== null) out.push(event)
  }
  return out
}

/* ------------------------------------------------------------------ *
 * 镜像（docker images）
 * ------------------------------------------------------------------ */

export interface ImageSummary {
  id: string
  shortId: string
  repository: string
  tag: string
  /** `repository:tag`（dangling 时 ` <none>:<none>`）。 */
  reference: string
  size: number | null
  sizeText: string
  createdAt: string
  createdSince: string
  dangling: boolean
}

/** `docker images --format '{{json .}}'` → ImageSummary[]。 */
export function parseImagesJson(text: string): ImageSummary[] {
  return parseJsonLines(text).map((row) => {
    const id = str(row, 'ID', 'Id')
    const repository = str(row, 'Repository') || '<none>'
    const tag = str(row, 'Tag') || '<none>'
    const sizeText = str(row, 'Size')
    return {
      id,
      shortId: id.replace(/^sha256:/, '').slice(0, 12),
      repository,
      tag,
      reference: `${repository}:${tag}`,
      size: parseDockerSize(sizeText),
      sizeText,
      createdAt: str(row, 'CreatedAt'),
      createdSince: str(row, 'CreatedSince'),
      dangling: repository === '<none>' && tag === '<none>',
    }
  })
}

/* ------------------------------------------------------------------ *
 * 镜像详情（docker image inspect / docker history）
 * ------------------------------------------------------------------ */

/** 镜像详情（`docker image inspect <ref>` 的权威数据）。 */
export interface ImageDetail {
  id: string
  shortId: string
  /** 标签列表（dangling 镜像为空数组）。 */
  repoTags: string[]
  repoDigests: string[]
  /** 压缩后大小（字节；缺字段为 null）。 */
  size: number | null
  /** 含父层的虚拟大小（老版本无此字段）。 */
  virtualSize: number | null
  created: string
  architecture: string
  os: string
  entrypoint: string
  command: string
  workingDir: string
  user: string
  exposedPorts: string[]
  volumes: string[]
  /** 层（RootFS.Layers 的 diff id，底层 → 顶层）。 */
  layers: string[]
  /** 层数（= layers.length，单独给出便于直接展示）。 */
  layerCount: number
  /** 镜像标签（截断展示用；值可能很长，仅回传前 50 条）。 */
  labels: Record<string, string>
}

/** `docker image inspect <ref>` 的 JSON 数组 → ImageDetail[]。 */
export function parseImageInspectJson(text: string): ImageDetail[] {
  return parseJsonLines(text).map((row) => {
    const config = asRecord(row.Config)
    const rootfs = asRecord(row.RootFS)
    const labels = asRecord(config.Labels)
    const layers = Array.isArray(rootfs.Layers) ? rootfs.Layers.map(String) : []
    const id = str(row, 'Id', 'ID')
    const size = typeof row.Size === 'number' ? row.Size : null
    return {
      id,
      shortId: id.replace(/^sha256:/, '').slice(0, 12),
      repoTags: Array.isArray(row.RepoTags) ? row.RepoTags.map(String) : [],
      repoDigests: Array.isArray(row.RepoDigests) ? row.RepoDigests.map(String) : [],
      size,
      virtualSize: typeof row.VirtualSize === 'number' ? row.VirtualSize : null,
      created: typeof row.Created === 'string' ? row.Created : '',
      architecture: str(row, 'Architecture'),
      os: str(row, 'Os', 'OS'),
      entrypoint: Array.isArray(config.Entrypoint) ? config.Entrypoint.map(String).join(' ') : str(config, 'Entrypoint'),
      command: Array.isArray(config.Cmd) ? config.Cmd.map(String).join(' ') : str(config, 'Cmd'),
      workingDir: typeof config.WorkingDir === 'string' ? config.WorkingDir : '',
      user: typeof config.User === 'string' ? config.User : '',
      exposedPorts: Object.keys(asRecord(config.ExposedPorts)).sort(),
      volumes: Object.keys(asRecord(config.Volumes)).sort(),
      layers,
      layerCount: layers.length,
      // env 刻意不回传：inspect 的 Env 里常含密钥，浏览器与 agent 都不需要
      labels: Object.fromEntries(Object.entries(labels).slice(0, 50).map(([k, v]) => [k, String(v)])),
    }
  })
}

/** 构建历史的一条（`docker history`）。 */
export interface ImageHistoryEntry {
  id: string
  shortId: string
  created: string
  createdSince: string
  createdBy: string
  size: number | null
  sizeText: string
  comment: string
  tags: string[]
}

/**
 * `docker history --no-trunc --format '{{json .}}'` → ImageHistoryEntry[]。
 * `--format` 只有 Docker ≥ 26 才支持；老版本输出的是纯文本表格，
 * 由 parseImageHistoryText 兜底（调用方先试 JSON）。
 */
export function parseImageHistoryJson(text: string): ImageHistoryEntry[] {
  return parseJsonLines(text).map((row) => {
    const id = str(row, 'ID', 'Id')
    const sizeText = str(row, 'Size')
    const tags = str(row, 'Tags')
    return {
      id,
      shortId: id.replace(/^sha256:/, '').slice(0, 12),
      created: str(row, 'CreatedAt'),
      createdSince: str(row, 'CreatedSince'),
      createdBy: str(row, 'CreatedBy'),
      size: parseDockerSize(sizeText),
      sizeText,
      comment: str(row, 'Comment'),
      tags: tags === '' ? [] : tags.split(',').map((tag) => tag.trim()).filter((tag) => tag !== ''),
    }
  })
}

/**
 * `docker history --no-trunc` 的纯文本表格兜底解析（老版本 docker 没有 --format）。
 *
 * 表格列以 2 个以上空格对齐，但 **CREATED BY 内部也常出现连续双空格**
 * （`#(nop)  CMD`、`#(nop)  ADD`），所以不按 `\s{2,}` 盲切：先从右往左定位 SIZE
 * （行内最后一个「数字 + 单位」），再用第一个连续双空格把 CREATED 与 CREATED BY 分开。
 * 这是 best-effort：列宽截断（尾部 `…`）与极端构建命令可能让个别字段不完整，
 * 但不会抛错，也不会把整行吞掉。
 */
export function parseImageHistoryText(text: string): ImageHistoryEntry[] {
  const out: ImageHistoryEntry[] = []
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trimEnd()
    const trimmed = line.trim()
    if (trimmed === '') continue
    if (/^IMAGE\s+(CREATED|CREATED BY)/i.test(trimmed)) continue
    const head = /^(\S+)\s+(.+)$/.exec(trimmed)
    if (head === null) continue
    const id = head[1]
    const rest = head[2]
    // SIZE 列：取行内最后一个「数字 + 单位」——构建命令里出现尺寸样式文本的概率远低于 SIZE 列本身
    const sizeRe = /(\d+(?:\.\d+)?)\s*([kKmMgGtTpP]?[bB])/g
    let last: RegExpExecArray | null = null
    let hit: RegExpExecArray | null
    while ((hit = sizeRe.exec(rest)) !== null) last = hit
    if (last === null) continue
    const beforeSize = rest.slice(0, last.index).trimEnd()
    const comment = rest.slice(last.index + last[0].length).trim()
    // CREATED 与 CREATED BY 之间是第一个连续双空格（CREATED BY 内部的双空格留给它自己）
    const createdSplit = /\s{2,}/.exec(beforeSize)
    const created = createdSplit === null ? beforeSize : beforeSize.slice(0, createdSplit.index).trim()
    const createdBy = createdSplit === null ? '' : beforeSize.slice(createdSplit.index).trim()
    const sizeText = last[0].trim()
    out.push({
      id,
      shortId: id.replace(/^sha256:/, '').slice(0, 12),
      created: '',
      createdSince: created,
      createdBy,
      size: parseDockerSize(sizeText),
      sizeText,
      comment,
      tags: [],
    })
  }
  return out
}

/* ------------------------------------------------------------------ *
 * 网络 / 卷（docker network ls|inspect、docker volume ls|inspect）
 * ------------------------------------------------------------------ */

/**
 * docker 的 `ls --format '{{json .}}'` 把布尔值也输出成字符串（`"false"`），
 * 而 `inspect` 里是真 boolean。同一个字段两条路径都要能吃。
 */
function boolish(value: unknown): boolean {
  if (typeof value === 'boolean') return value
  if (typeof value === 'string') return value.trim().toLowerCase() === 'true'
  return false
}

/** 对象型字段（inspect 的 Options / Labels）→ 字符串字典。 */
function stringMap(value: unknown): Record<string, string> {
  return Object.fromEntries(Object.entries(asRecord(value)).map(([key, item]) => [key, String(item)]))
}

export interface NetworkSummary {
  id: string
  shortId: string
  name: string
  driver: string
  scope: string
  internal: boolean
  ipv6: boolean
}

/** `docker network ls --format '{{json .}}'` → NetworkSummary[]。 */
export function parseNetworksJson(text: string): NetworkSummary[] {
  return parseJsonLines(text).map((row) => {
    const id = str(row, 'ID', 'Id')
    return {
      id,
      shortId: id.slice(0, 12),
      name: str(row, 'Name'),
      driver: str(row, 'Driver'),
      scope: str(row, 'Scope'),
      internal: boolish(row.Internal),
      ipv6: boolish(row.IPv6),
    }
  })
}

/** 网络详情（`docker network inspect <name>` 的权威数据）。 */
export interface NetworkDetail {
  id: string
  shortId: string
  name: string
  driver: string
  scope: string
  created: string
  internal: boolean
  attachable: boolean
  ingress: boolean
  enableIpv6: boolean
  /** IPAM.Config 的每一项（子网 / 网关；老 daemon 可能没有）。 */
  subnets: { subnet: string; gateway: string }[]
  options: Record<string, string>
  labels: Record<string, string>
  /** 接入这个网络的容器（Endpoint 视角的数据）。 */
  containers: { id: string; shortId: string; name: string; ipv4: string; ipv6: string; mac: string }[]
}

/** `docker network inspect <name>` 的 JSON 数组 → NetworkDetail[]。 */
export function parseNetworkInspectJson(text: string): NetworkDetail[] {
  return parseJsonLines(text).map((row) => {
    const id = str(row, 'Id', 'ID')
    const ipam = asRecord(row.IPAM)
    const config = Array.isArray(ipam.Config) ? ipam.Config : []
    const containers = asRecord(row.Containers)
    return {
      id,
      shortId: id.slice(0, 12),
      name: str(row, 'Name'),
      driver: str(row, 'Driver'),
      scope: str(row, 'Scope'),
      created: typeof row.Created === 'string' ? row.Created : '',
      internal: boolish(row.Internal),
      attachable: boolish(row.Attachable),
      ingress: boolish(row.Ingress),
      enableIpv6: boolish(row.EnableIPv6),
      subnets: config.map((item) => {
        const entry = asRecord(item)
        return { subnet: typeof entry.Subnet === 'string' ? entry.Subnet : '', gateway: typeof entry.Gateway === 'string' ? entry.Gateway : '' }
      }).filter((entry) => entry.subnet !== '' || entry.gateway !== ''),
      options: stringMap(row.Options),
      labels: stringMap(row.Labels),
      containers: Object.entries(containers).map(([key, value]) => {
        const item = asRecord(value)
        return {
          id: key,
          shortId: key.slice(0, 12),
          name: typeof item.Name === 'string' ? item.Name : '',
          ipv4: typeof item.IPv4Address === 'string' ? item.IPv4Address : '',
          ipv6: typeof item.IPv6Address === 'string' ? item.IPv6Address : '',
          mac: typeof item.MacAddress === 'string' ? item.MacAddress : '',
        }
      }),
    }
  })
}

export interface VolumeSummary {
  name: string
  driver: string
  scope: string
  /**
   * 挂载点。`volume ls` 的模板里**没有** CreatedAt（实测 27.5.1），所以列表不带时间；
   * Mountpoint 也不是所有版本都提供，缺字段就退化成空串，列表显示 '—'。
   */
  mountpoint: string
}

/** `docker volume ls --format '{{json .}}'` → VolumeSummary[]。 */
export function parseVolumesJson(text: string): VolumeSummary[] {
  return parseJsonLines(text).map((row) => ({
    name: str(row, 'Name'),
    driver: str(row, 'Driver'),
    scope: str(row, 'Scope'),
    mountpoint: str(row, 'Mountpoint'),
  }))
}

/** 卷详情（`docker volume inspect <name>` 的权威数据）。 */
export interface VolumeDetail {
  name: string
  driver: string
  scope: string
  mountpoint: string
  created: string
  options: Record<string, string>
  labels: Record<string, string>
}

/** `docker volume inspect <name>` 的 JSON 数组 → VolumeDetail[]。 */
export function parseVolumeInspectJson(text: string): VolumeDetail[] {
  return parseJsonLines(text).map((row) => ({
    name: str(row, 'Name'),
    driver: str(row, 'Driver'),
    scope: str(row, 'Scope'),
    mountpoint: str(row, 'Mountpoint'),
    created: typeof row.CreatedAt === 'string' ? row.CreatedAt : '',
    options: stringMap(row.Options),
    labels: stringMap(row.Labels),
  }))
}

/* ------------------------------------------------------------------ *
 * 详情（docker inspect）
 * ------------------------------------------------------------------ */

export interface MountInfo {
  type: string
  source: string
  destination: string
  mode: string
  readWrite: boolean
}

export interface ContainerDetail {
  id: string
  shortId: string
  name: string
  image: string
  imageId: string
  state: string
  status: string
  health: string | null
  healthLogTail: string | null
  created: string | null
  startedAt: string | null
  finishedAt: string | null
  exitCode: number | null
  oomKilled: boolean
  restartCount: number | null
  restartPolicy: string | null
  platform: string
  pid: number | null
  ports: PortMapping[]
  mounts: MountInfo[]
  networks: { name: string; ip: string | null }[]
  command: string
  entrypoint: string
  workingDir: string
  user: string
  composeProject: string | null
  composeService: string | null
  /** 镜像标签（截断展示用；值可能很长，仅回传前 50 条）。 */
  labels: Record<string, string>
}

/** `docker inspect <id…>` 的 JSON 数组 → ContainerDetail[]。 */
export function parseInspectJson(text: string): ContainerDetail[] {
  const parsed = parseJsonLines(text)
  return parsed.map((row) => {
    const state = asRecord(row.State)
    const config = asRecord(row.Config)
    const hostConfig = asRecord(row.HostConfig)
    const networkSettings = asRecord(row.NetworkSettings)
    const labels = asRecord(config.Labels)
    const mountsRaw = Array.isArray(row.Mounts) ? row.Mounts : []
    const networksRaw = asRecord(networkSettings.Networks)
    const health = asRecord(state.Health)
    const healthLog = Array.isArray(health.Log) ? health.Log : []
    const lastHealth = healthLog.length > 0 ? asRecord(healthLog[healthLog.length - 1]) : {}
    const id = str(row, 'Id', 'ID')
    const name = str(row, 'Name').replace(/^\//, '')
    return {
      id,
      shortId: id.slice(0, 12),
      name,
      image: str(config, 'Image'),
      imageId: str(row, 'Image'),
      state: str(state, 'Status') === '' ? 'unknown' : str(state, 'Status').toLowerCase(),
      status: str(state, 'Status'),
      health: typeof health.Status === 'string' ? health.Status : null,
      healthLogTail: typeof lastHealth.Output === 'string' ? lastHealth.Output.trim() : null,
      created: typeof row.Created === 'string' ? row.Created : null,
      startedAt: dockerTime(state.StartedAt),
      finishedAt: dockerTime(state.FinishedAt),
      exitCode: typeof state.ExitCode === 'number' ? state.ExitCode : null,
      oomKilled: state.OOMKilled === true,
      restartCount: typeof row.RestartCount === 'number' ? row.RestartCount : null,
      restartPolicy: typeof asRecord(hostConfig.RestartPolicy).Name === 'string' ? String(asRecord(hostConfig.RestartPolicy).Name) : null,
      platform: typeof row.Platform === 'string' ? row.Platform : '',
      pid: typeof state.Pid === 'number' ? state.Pid : null,
      ports: parseInspectPorts(networkSettings.Ports),
      mounts: mountsRaw.map((item) => {
        const mount = asRecord(item)
        return {
          type: typeof mount.Type === 'string' ? mount.Type : '',
          source: typeof mount.Source === 'string' ? mount.Source : '',
          destination: typeof mount.Destination === 'string' ? mount.Destination : '',
          mode: typeof mount.Mode === 'string' ? mount.Mode : '',
          readWrite: mount.RW !== false,
        }
      }),
      networks: Object.entries(networksRaw).map(([name, value]) => {
        const net = asRecord(value)
        return { name, ip: typeof net.IPAddress === 'string' && net.IPAddress !== '' ? net.IPAddress : null }
      }),
      command: Array.isArray(config.Cmd) ? config.Cmd.map(String).join(' ') : str(config, 'Cmd'),
      entrypoint: Array.isArray(config.Entrypoint) ? config.Entrypoint.map(String).join(' ') : str(config, 'Entrypoint'),
      workingDir: typeof config.WorkingDir === 'string' ? config.WorkingDir : '',
      user: typeof config.User === 'string' ? config.User : '',
      composeProject: typeof labels['com.docker.compose.project'] === 'string' ? labels['com.docker.compose.project'] : null,
      composeService: typeof labels['com.docker.compose.service'] === 'string' ? labels['com.docker.compose.service'] : null,
      labels: Object.fromEntries(Object.entries(labels).slice(0, 50).map(([k, v]) => [k, String(v)])),
    }
  })
}

function asRecord(value: unknown): Record<string, unknown> {
  return typeof value === 'object' && value !== null ? (value as Record<string, unknown>) : {}
}

/**
 * docker 的零值时间不是有效时间（D41）：从未退出的容器 `FinishedAt` 是
 * `0001-01-01T00:00:00Z`（不是空串），`Date.parse` 还能解析成功 → 「最近出事
 * 优先」排序被打乱、详情/hover 显示公元 1 年。归一成 null。
 */
function dockerTime(value: unknown): string | null {
  if (typeof value !== 'string' || value === '') return null
  if (value.startsWith('0001-01-01')) return null
  return value
}

/**
 * `docker inspect` 里的**资源上限**（`diagnose()` 用）。
 *
 * 刻意不进 `ContainerDetail` 契约：那是「面板详情页要显示什么」的形状，而这两个字段
 * 只有诊断判据（内存 / CPU 逼近上限）需要。0 一律归一成 `null`——docker 用 0 表示
 * **不限制**，把 0 当成上限会让「内存上限 0B」这种假象混进判据与文案里。
 */
export function parseInspectLimits(text: string): { memoryLimitBytes: number | null; cpuQuota: number | null } {
  const row = parseJsonLines(text)[0]
  const hostConfig = asRecord(row?.HostConfig)
  const positive = (value: unknown): number | null => (typeof value === 'number' && Number.isFinite(value) && value > 0 ? value : null)
  return {
    memoryLimitBytes: positive(hostConfig.Memory),
    cpuQuota: positive(hostConfig.NanoCpus),
  }
}

/** inspect 的 `NetworkSettings.Ports`：`{ "80/tcp": [{HostIp, HostPort}] }`。 */
export function parseInspectPorts(value: unknown): PortMapping[] {
  const ports = asRecord(value)
  const out: PortMapping[] = []
  for (const [key, mappings] of Object.entries(ports)) {
    const [containerPortText = '', protocol = 'tcp'] = key.split('/')
    // 键本身可能是**端口区间**（`8000-8005/tcp`）：复用 parsePortToken（D102）。
    // 此前用 Number('8000-8005') 得 NaN → continue，整段端口凭空消失，详情页比
    // 列表页（parsePorts 已在 D40 支持区间）少一条。
    const containerToken = parsePortToken(containerPortText)
    if (containerToken === null) continue
    const containerPort = containerToken.port
    const containerRange = containerToken.range === undefined ? {} : { containerPortRange: containerToken.range }
    const list = Array.isArray(mappings) ? mappings : []
    if (list.length === 0) {
      out.push({ containerPort, ...containerRange, protocol })
      continue
    }
    const seen = new Set<string>()
    for (const item of list) {
      const map = asRecord(item)
      const hostIp = typeof map.HostIp === 'string' ? map.HostIp : ''
      const hostPortRaw = map.HostPort
      const hostPortText = hostPortRaw === undefined || hostPortRaw === null ? '' : String(hostPortRaw)
      // HostPort 与键同口径（D102）：区间映射的 HostPort 也可能是 `8000-8005`；
      // 缺失/空串时 parsePortToken 返回 null → 不产出 Number('') === 0 的幻影映射（D38）
      const hostToken = parsePortToken(hostPortText)
      const hostRange = hostToken === null || hostToken.range === undefined ? {} : { hostPortRange: hostToken.range }
      // 去重键含 hostIp（D38）：`-p 8080:8080` 的 inspect 会给 `0.0.0.0` 与 `::` 两条，
      // 只按端口去重会把 IPv6 那条并掉，详情页比列表页少端口
      const dedupe = `${hostIp}:${hostPortText}`
      if (seen.has(dedupe)) continue
      seen.add(dedupe)
      out.push({
        ...(hostIp === '' ? {} : { hostIp }),
        ...(hostToken === null ? {} : { hostPort: hostToken.port }),
        ...hostRange,
        containerPort,
        ...containerRange,
        protocol,
      })
    }
  }
  return out
}

/* ------------------------------------------------------------------ *
 * 磁盘占用（docker system df）
 * ------------------------------------------------------------------ */

/**
 * 明细每类最多回多少行（宿主侧闸）。客户端要的是「治理视图」，不是迁移清单：
 * 259 个匿名卷全列出来既读不了、也顶爆模型上下文。
 */
export const DISK_DETAIL_LIMIT = 100

/**
 * 明细采集的字节预算下限（与配置的单命令上限取较大者）。
 *
 * `docker system df -v --format '{{json .}}'` 是**一条**大 JSON（真机实测 259 个卷
 * ≈120KB），卷多时会线性涨；512KB 的默认上限在几千个卷的机器上会截断，而截断会让
 * JSON 解析失败 → 白白降级成「只有汇总」。给一份独立预算（同 logsGrep / diagnose 的
 * events 采集），超了仍然如实降级。
 */
export const DISK_DETAIL_SCAN_BYTES = 8 * 1024 * 1024

/** `docker system df` 的汇总行（`Type` 原样保留 docker 的英文分类）。 */
export interface DiskSummaryRow {
  type: string
  totalCount: number
  active: number
  size: string
  reclaimable: string
}

/** 镜像明细（`containers` 就是「谁在用」：`Images[].Containers`，不是按 ps 反推的）。 */
export interface DiskImageRow {
  id: string
  repository: string
  tag: string
  size: string
  sharedSize: string
  uniqueSize: string
  containers: number
}

/** 卷明细（`links` 就是「谁在用」：`Volumes[].Links`）。 */
export interface DiskVolumeRow {
  name: string
  driver: string
  size: string
  links: number
}

export interface DiskBuildCacheRow {
  id: string
  type: string
  size: string
  inUse: boolean
}

export interface DiskUsageTruncated {
  images: boolean
  volumes: boolean
  buildCache: boolean
}

/** 每类明细的**真实条数**（截断前；agent 工具据此在 20 行上限下仍报得准）。 */
export interface DiskUsageTotals {
  images: number
  volumes: number
  buildCache: number
}

/** `docker system df` 的完整结果（路由与 agent 工具共用形状）。 */
export interface DiskUsage {
  summary: DiskSummaryRow[]
  images: DiskImageRow[]
  volumes: DiskVolumeRow[]
  buildCache: DiskBuildCacheRow[]
  /** 截断前的条数（**不进 HTTP 契约**：客户端靠 truncated 就够，工具要报 total）。 */
  totals: DiskUsageTotals
  truncated: DiskUsageTruncated
  /** 只拿到汇总（明细取不到）时为 true；`summary` 仍然可用。 */
  degraded: boolean
  degradedReason: string | null
}

/** 明细解析结果（`null` = 输出解析不了，调用方据此降级）。 */
export interface DiskDetail {
  images: DiskImageRow[]
  volumes: DiskVolumeRow[]
  buildCache: DiskBuildCacheRow[]
  totals: DiskUsageTotals
  truncated: DiskUsageTruncated
}

/** 计数字段在 `{{json .}}` 里是**字符串**（`"TotalCount":"14"`），解析失败给 0。 */
function countOf(value: unknown): number {
  const n = typeof value === 'number' ? value : Number(value)
  return Number.isInteger(n) && n >= 0 ? n : 0
}

/**
 * `docker system df --format '{{json .}}'` → 汇总行。
 *
 * 每行一个 JSON 对象（真机实测四行：Images / Containers / Local Volumes / Build Cache）。
 * `type` 原样保留英文——翻译是客户端 i18n 的事（`status.diskTypeImages` 等）。
 */
export function parseDiskSummary(text: string): DiskSummaryRow[] {
  return parseJsonLines(text)
    .map((row) => ({
      type: str(row, 'Type'),
      totalCount: countOf(row.TotalCount),
      active: countOf(row.Active),
      size: str(row, 'Size'),
      reclaimable: str(row, 'Reclaimable'),
    }))
    .filter((row) => row.type !== '')
}

/**
 * `docker system df -v --format '{{json .}}'` → 明细（images / volumes / buildCache）。
 *
 * 真机实测：整个输出是**一个 JSON 对象**（键 `Images` / `Containers` / `Volumes` /
 * `BuildCache`），`--format` 把它序列化成一行。`Containers` 段刻意不解析——容器明细
 * 与 `docker ps` 重复，而磁盘治理关心的是「谁在用」（Images[].Containers / Volumes[].Links）。
 *
 * **排序**：镜像按 `UniqueSize`、卷按 `Size` 降序（同值保持 docker 原序）。磁盘页要的
 * 「先看占用最大的」在这里就成立，客户端不必再排一遍、也不会排错（字符串大小不可比）。
 * 截断在排序**之后**（`truncated` 如实置位），否则名额会被一堆 0B 的空卷占满。
 *
 * 解析不了（老 docker 不支持 `-v --format`、输出被截断、JSON 坏了）→ `null`：
 * 降级由调用方决定，这里不抛——「明细没有」不该把汇总也带走。
 */
export function parseDiskDetail(text: string, limit: number = DISK_DETAIL_LIMIT): DiskDetail | null {
  const root = parseJsonLines(text)[0]
  if (root === undefined) return null
  const imagesRaw = Array.isArray(root.Images) ? root.Images : null
  const volumesRaw = Array.isArray(root.Volumes) ? root.Volumes : null
  // 三个数组一个都没有 = 这不是 `system df -v` 的形状（老版本会直接报 unknown flag）
  if (imagesRaw === null && volumesRaw === null && !Array.isArray(root.BuildCache)) return null
  const cap = Math.max(Math.trunc(limit), 1)

  const images = (imagesRaw ?? [])
    .map((item) => asRecord(item))
    .map((row) => ({
      id: str(row, 'ID'),
      repository: str(row, 'Repository'),
      tag: str(row, 'Tag'),
      size: str(row, 'Size'),
      sharedSize: str(row, 'SharedSize'),
      // 老 docker 没有 UniqueSize：用 VirtualSize 兜底、都没有就空串（客户端显示 —）
      uniqueSize: str(row, 'UniqueSize') || str(row, 'VirtualSize'),
      containers: countOf(row.Containers),
    }))
    .sort((a, b) => sizeBytesOf(b.uniqueSize) - sizeBytesOf(a.uniqueSize))

  const volumes = (volumesRaw ?? [])
    .map((item) => asRecord(item))
    .map((row) => ({
      name: str(row, 'Name'),
      driver: str(row, 'Driver'),
      size: str(row, 'Size'),
      links: countOf(row.Links),
    }))
    .sort((a, b) => sizeBytesOf(b.size) - sizeBytesOf(a.size))

  const buildCache = (Array.isArray(root.BuildCache) ? root.BuildCache : [])
    .map((item) => asRecord(item))
    .map((row) => ({
      id: str(row, 'ID'),
      type: str(row, 'Type'),
      size: str(row, 'Size'),
      inUse: boolish(row.InUse),
    }))

  return {
    images: images.slice(0, cap),
    volumes: volumes.slice(0, cap),
    buildCache: buildCache.slice(0, cap),
    totals: { images: images.length, volumes: volumes.length, buildCache: buildCache.length },
    truncated: {
      images: images.length > cap,
      volumes: volumes.length > cap,
      buildCache: buildCache.length > cap,
    },
  }
}

/** 大小字符串 → 字节（`264.1MB` → 字节）；解析失败给 0，保证排序稳定。 */
function sizeBytesOf(text: string): number {
  return parseDockerSize(text) ?? 0
}

/* ------------------------------------------------------------------ *
 * 执行器抽象：本地 / SSH 共用一套 DockerApi
 * ------------------------------------------------------------------ */

/**
 * 一次性命令的选项**子集**（Runner 面）：= `ExecOptions` 去掉 `input`（这条通道喂不了
 * stdin）并加上 `signal`。
 *
 * 刻意写成具名类型：它原先在 `Runner.run` 与 `createRunner` 的 `withSignal` 里各写了一份
 * 字面量，于是新增一个字段只能靠对象字面量处的 tsc 报错兜住——`lineAlign` 那次就是先漏在
 * 第二份上。具名类型之后不存在「第二份」。
 */
export interface RunnerRunOptions {
  timeoutMs?: number
  maxBytes?: number
  keepTail?: boolean
  /** 截断后对齐到行边界（见 `ExecOptions.lineAlign`）；只有 `docker_logs_grep` 用。 */
  lineAlign?: boolean
  signal?: AbortSignal
}

/** 一个目标（target）背后的命令执行通道。 */
export interface Runner {
  /** 展示用标签：`本机` 或 `user@host`。 */
  readonly label: string
  /**
   * `signal` 是**可选**的（D161）：已有 20+ 个调用点与测试里的假 runner 只传前两个
   * 参数，加成必填会把它们全部波及，而它们的命令都是短命、不需要外部取消的。
   * 目前只有跨目标聚合（`aggregateAcrossTargets`）会传——单目标路径的截止时间是
   * `timeoutMs`，它本来就够。
   */
  run(argv: readonly string[], options?: RunnerRunOptions): Promise<ExecResult>
  /** 长流（logs --follow）：逐块回调，signal 中止；无总超时与输出上限。 */
  stream(argv: readonly string[], handlers: StreamHandlers, signal?: AbortSignal): Promise<StreamResult>
}

export interface DockerAction {
  action: 'start' | 'stop' | 'restart' | 'remove'
  id: string
}

export interface LogsOptions {
  tail?: number
  timestamps?: boolean
  since?: string
  /** 结束时间（docker --until 语法：ISO 8601 时间戳或 Go duration，如 2026-09-09T10:00:00、1h）。*/
  until?: string
  /** 实时跟随（`docker logs --follow`）：仅 logsStream() 使用，logs() 忽略。 */
  follow?: boolean
}

/**
 * 日志检索选项：**默认字面子串**匹配（grep -F 等价），零 ReDoS 风险；
 * `regexp: true` 时才按 JS 正则解释 pattern（仍建议配 since/until 收窄窗口）。
 */
export interface LogGrepOptions {
  /** 要搜索的字面子串，或（regexp=true 时）正则表达式源文。 */
  pattern: string
  /** true = 把 pattern 当正则；默认 false = 字面子串。 */
  regexp?: boolean
  /** 忽略大小写（字面模式 = grep -i，正则模式 = /i 标志）。 */
  ignoreCase?: boolean
  /** 扫描行数上限（1~5000）；缺省 = `--tail all` 扫全部历史。 */
  tail?: number
  /** 起始时间（与 docker_logs 的 since 同一口径，D45）。 */
  since?: string
  /** 结束时间（docker --until 语法，与 since 同一口径）。 */
  until?: string
  /** 每个命中前后各保留的上下文行数（0~20，默认 2）。 */
  context?: number
  /** 返回命中数上限（1~500，默认 200）。 */
  limit?: number
  /** 时间戳（默认开——深处的命中没有时间等于没用）。 */
  timestamps?: boolean
}

/** 检索结果里的一行（命中行或它的上下文行）。 */
export interface LogGrepLine {
  /** 该通道内的行号（从 1 开始；stdout 在前、stderr 在后，与 logs() 的拼接序一致）。 */
  seq: number
  stream: 'out' | 'err'
  text: string
  /** 这行本身是否命中（false = 只是上下文）。 */
  hit: boolean
  /** 命中时：匹配到的子串（供调用方定位；上下文行为 null）。 */
  highlight: string | null
}

/**
 * logsGrep 的**返回侧行闸**（与扫描侧的 8~32MB 字节预算是两件事）。
 *
 * 扫描预算管「能从多少原文里筛」，这个常量管「筛出来的能塞回多少给模型」：
 * limit 上限 500 × context 上限 20 ⇒ 最多约 20500 行，一次性返回会把模型上下文撑爆
 * （命中多的时候返回的是真有用的行，不是噪音，但超长的结果是另一种不可用）。
 * 超了截到本上限，并给 `truncatedForSize` 与 `notes`——**不给**一个静默截断。
 * `matched` 不受此闸影响：全量命中数仍如实上报，那是缩小窗口时最有用的信号。
 */
export const MAX_RESULT_LINES = 4000

/**
 * 日志检索结果。三个「截断」要分清：truncated = 扫描侧字节闸截断，limited = 命中数达到
 * limit，truncatedForSize = 返回侧行闸截断（见 MAX_RESULT_LINES）。
 */
export interface LogGrepResult {
  id: string
  /** 命中总行数（即使超过 limit 也如实计数；返回侧行闸**不改变**它）。 */
  matched: number
  /** 实际扫描的行数。 */
  scanned: number
  /** **实际返回**的行数（命中 + 去重后的上下文；被返回侧行闸截过就是截断后的条数）。 */
  returned: number
  /** 命中数达到 limit、还有命中没返回。 */
  limited: boolean
  /**
   * 扫描输出超过字节上限（按**字节**丢最旧——窗口偏新，缩小 since/until 或换目标时段）。
   * 窗口已对齐到行边界，所以 `lines` 里不会出现半行；但切口之前的内容确实没参与检索。
   */
  truncated: boolean
  /** 组装出的行数超过 MAX_RESULT_LINES、`lines` 已按上限截断。 */
  truncatedForSize?: boolean
  /** 面向调用方的可执行提示（目前只有返回侧行闸这一档）：缩小 limit / 减小 context / 圈 since~until。 */
  notes?: string[]
  contextLines: number
  lines: LogGrepLine[]
}

export interface ProbeResult {
  ok: boolean
  bin: string
  /** 服务端版本（`docker version --format {{.Server.Version}}`）。 */
  serverVersion: string | null
  /** 失败原因（daemon 未运行 / 未安装 / 权限不足 / 超时）。 */
  error: string | null
  target: string
  /**
   * 失败是不是「CLI 挂住到超时」。单独一档而不并进 `error` 文案：调用方要靠它
   * 区分「没装」与「装了但不应答」——前者去装、后者去看 daemon / context。
   */
  timedOut: boolean
}

/** 诊断默认抓多少行日志（契约 §1.2）。 */
export const DIAGNOSE_LOG_TAIL_DEFAULT = 80

/** 诊断日志行数的上限（与 `docker_logs` 的夹紧风格一致：越界夹到边界，不报错）。 */
export const DIAGNOSE_LOG_TAIL_MAX = 500

/** 诊断默认的事件窗口（契约 §1.2）。 */
export const DIAGNOSE_SINCE_DEFAULT = '1h'

/**
 * 诊断的事件扫描预算（字节，下限；实际取与配置上限的较大者）。
 *
 * 这不是「调大上限」：`docker_events` 工具的默认预算不变。单容器 + `--since 1h` 的
 * 事件里，健康检查每个周期产生 exec_create / exec_start / exec_die 三条，每条都带
 * 整份镜像标签（真机实测 ≈2.3KB/条、256 条/小时、合计 588KB），而这三类在解析时会被
 * 白名单整条丢掉——花 512KB 的预算把 95% 的字节买来再扔掉，正是「时间线永远是空」的成因。
 */
export const DIAGNOSE_EVENTS_SCAN_BYTES = 8 * 1024 * 1024

/** `diagnose()` 的结果：结论 + 三路降级的**原因**（原因同时进 findings，这里留给宿主胶水）。 */
export interface DiagnoseResult {
  diagnosis: Diagnosis
  logError: string | null
  eventError: string | null
  statsError: string | null
}

/** 采集失败的一句话原因（给 `*-unavailable` 判据与面板文案用；空错误也要有话说）。 */
function describeCollectedError(error: unknown, what: string): string {
  const message = error instanceof Error ? error.message : String(error)
  const trimmed = message.trim()
  return trimmed === '' ? `${what}采集失败（无错误信息）` : trimmed
}

/**
 * 统计日志行数（`--tail N` 采到的原文）。
 *
 * 与 D136 同一口径：docker logs 每一行都以 `\n` 结尾，`text.split('\n')` 末尾会多出
 * 一个空串——那个终止符不是一行，计数时必须去掉，否则「抓 80 行」会显示成 81。
 */
function countLogLines(text: string): number {
  if (text === '') return 0
  const lines = text.split('\n')
  if (lines.length > 0 && lines[lines.length - 1] === '') lines.pop()
  return lines.length
}

/** 单个目标上的 Docker 操作集合。 */
export class DockerApi {
  constructor(
    private readonly runner: Runner,
    private readonly bin: string,
    private readonly limits: { timeoutMs: number; maxBytes: number },
  ) {}

  /**
   * 探测：docker CLI 是否可用 + daemon 是否可达。
   *
   * 超时必须单独成一档（`timedOut`），不能落进「退出码 null」——`code` 为 null 时
   * 那句兜底文案对用户零信息量（D159），而超时的真实成因（daemon 卡死 / `docker
   * context` 指向连不上的远端 / CLI 是个挂住的包装脚本）恰恰是可修的那一类。
   */
  async probe(): Promise<ProbeResult> {
    const base = { bin: this.bin, target: this.runner.label, timedOut: false }
    try {
      const result = await this.runner.run([this.bin, 'version', '--format', '{{.Server.Version}}'], { timeoutMs: 15_000 })
      if (result.code === 0) {
        return { ok: true, serverVersion: result.stdout.trim() || null, error: null, ...base }
      }
      if (result.timedOut) {
        return {
          ok: false,
          serverVersion: null,
          error: `${this.bin} version 超时（15 秒未返回）`,
          ...base,
          timedOut: true,
        }
      }
      const message = (result.stderr.trim() || result.stdout.trim() || `退出码 ${String(result.code)}`).split('\n')[0]
      return { ok: false, serverVersion: null, error: message ?? '未知错误', ...base }
    } catch (error) {
      return { ok: false, serverVersion: null, error: error instanceof Error ? error.message : String(error), ...base }
    }
  }

  /**
   * assertOk + 截断检查（D13）：列表 / 详情类方法拿到的必须是**完整**输出。
   * 只检查 code 的话，「输出被截断」会被当成「本来就这么少」——面板静默少列
   * 容器，inspect 系列更会把截断误报成「对象不存在」，把用户引向错误方向。
   *
   * `alternative` 是**这个调用方真正能执行的替代做法**（D105）：agent 改不了插件
   * 设置，「请调大 maxOutputKb」对它不可执行——ps 能改 all、stats 能传 ids、
   * events 能缩小 since。文案里还会回显当前上限（见 truncationHint）。
   */
  private assertComplete(result: ExecResult, what: string, alternative?: string): void {
    this.assertOk(result, what)
    if (result.truncated) {
      throw new Error(`${what}的输出${this.truncationHint(alternative)}`)
    }
  }

  /**
   * 截断提示的统一文案（D105）：带上当前上限（KB）与目标标签——只说「超过上限」
   * 无法判断差多少；再拼上调用方的可执行替代做法。
   * 不抛错的路径（imageInspect 的 history，D104）复用同一句话，保持口径一致。
   */
  private truncationHint(alternative?: string): string {
    const limitKb = Math.round(this.limits.maxBytes / 1024)
    const suggest =
      alternative === undefined || alternative === ''
        ? '调大「单次命令输出上限」（maxOutputKb）'
        : `${alternative}；或调大「单次命令输出上限」（maxOutputKb）`
    return `因超过上限被截断（目标 ${this.runner.label}，当前上限 ${limitKb} KB）：结果不完整。请${suggest}后重试`
  }

  /**
   * 容器列表。`name` 是**服务端过滤**（`docker ps --filter name=`），不是本地筛：
   * 本插件对列表做 limit/offset 分页，先取全量再在内存里筛的话，「第 2 页」会随
   * 过滤词变化而变化，分页语义就与总数对不上了。docker 的 name 过滤是**子串**
   * 匹配（不是精确匹配），对「在一台跑了几十个容器的机器上找 compose 项目」够用。
   */
  async listContainers(all: boolean, name?: string): Promise<ContainerSummary[]> {
    const filter = assertPsName(name)
    const argv = [
      this.bin, 'ps',
      ...(all ? ['-a'] : []),
      ...(filter === undefined ? [] : ['--filter', `name=${filter}`]),
      '--no-trunc', '--format', '{{json .}}',
    ]
    const result = await this.runner.run(argv, { timeoutMs: this.limits.timeoutMs, maxBytes: this.limits.maxBytes })
    this.assertComplete(result, '列出容器', '改传 all=false（默认只看运行中的容器）')
    return parsePsJson(result.stdout)
  }

  async inspect(ids: readonly string[]): Promise<ContainerDetail[]> {
    const safe = ids.map((id) => assertRef(id, 'container'))
    if (safe.length === 0) return []
    const result = await this.runner.run([this.bin, 'inspect', ...safe], {
      timeoutMs: this.limits.timeoutMs,
      maxBytes: this.limits.maxBytes,
    })
    this.assertComplete(result, '读取容器详情', '改用更少的容器 id 分批读取')
    return parseInspectJson(result.stdout)
  }

  /**
   * 「需要关注」的容器（0.15.0）：先按摘要筛候选（不健康 / 重启中 / 僵死 /
   * 非零退出），再**分块** `docker inspect` 补权威字段——OOM 与真实退出码在 ps
   * 摘要里拿不到（137 也可能是手动 kill），只看摘要会误报。inspect 失败时退回摘要，
   * 但一定带 `degraded` 信号（D85/D86）。
   *
   * 反复重启（D11）：crash-loop 的容器多数时间显示 Up（退避最长 1 分钟，其余
   * 时间在跑），RestartCount 只在 inspect 里有——摘要筛不出来。这里把「刚刚
   * 启动」的运行中容器一并送进 inspect，按「重启计数高 + 刚启动」补捞；补捞有
   * 独立预算（D87）：合法候选再多也挤不掉它。
   *
   * 截断在过滤 + 排序**之后**（D12）：先切后拍的话，名额被一堆老的非零退出
   * 容器占满时，最严重的 OOM / unhealthy 反而会被切掉；返回值带 total / truncated
   * 截断信号，不静默。
   */
  async attention(options?: { limit?: number }): Promise<{ items: AttentionItem[]; total: number; truncated: boolean; degraded: boolean }> {
    const containers = await this.listContainers(true)
    const limit = Math.min(Math.max(Math.trunc(options?.limit ?? 100), 1), 500)
    // 合法三类候选（不健康 / 重启中 / 僵死 / 非零退出）：**不设总量闸**——超出的
    // 部分仍然进 items（它们是真实的问题容器），只是拿不到详情，见下面的 uninspected
    const candidates = containers.filter((item) => {
      if (item.health === 'unhealthy') return true
      if (item.state === 'restarting' || item.state === 'dead') return true
      if (item.state === 'exited' && item.exitCode !== null && item.exitCode !== 0) return true
      return false
    })
    // crash-loop 补捞（D11）：合法候选优先，但补捞有**独立预算**（D87）——此前共用
    // ATTENTION_INSPECT_CAP，300 个 unhealthy 一占满，真正的 crash-loop 一个都进不来
    const candidateIds = new Set(candidates.map((item) => item.id))
    const supplemented: ContainerSummary[] = []
    let droppedFresh = 0
    for (const item of containers) {
      if (candidateIds.has(item.id)) continue
      if (!(item.state === 'running' && FRESH_UP_RE.test(item.status))) continue
      if (supplemented.length >= ATTENTION_FRESH_BUDGET) {
        // 预算吃满后仍然「刚启动」的容器没被检查：计入降级信号（D87），不静默
        droppedFresh += 1
        continue
      }
      supplemented.push(item)
    }
    const picked = [...candidates, ...supplemented]
    if (picked.length === 0) return { items: [], total: 0, truncated: false, degraded: false }
    // inspect 集 = 合法候选的前 CAP 条 + **全部**补捞（总量 ≤ CAP + FRESH_BUDGET）
    const inspectIds = [...candidates.slice(0, ATTENTION_INSPECT_CAP), ...supplemented].map((item) => item.id)
    const details = new Map<string, ContainerDetail>()
    // inspect 失败必须有信号（D42）：静默退回摘要口径会把 OOM 降级成 exit-nonzero、
    // 重启次数 / 时间全部缺失，调用方无法区分「没有 OOM」与「权威数据没取到」。
    // 因此**分块** inspect、每块独立 catch（D86）：一块 300 个 id 时 512KB 必然截断，
    // 旧写法一抛错就是整批详情全丢——分块后失败只丢那一块，其余块照常可用。
    let uninspected = picked.length - inspectIds.length + droppedFresh
    const batch = attentionInspectBatch(this.limits.maxBytes)
    for (let offset = 0; offset < inspectIds.length; offset += batch) {
      const chunk = inspectIds.slice(offset, offset + batch)
      try {
        for (const detail of await this.inspect(chunk)) details.set(detail.id, detail)
      } catch {
        uninspected += chunk.length
      }
    }
    // 「有候选没取到详情」同样是降级（D85）：旧写法只在整批抛错时置位，于是 320 个
    // 候选里第 301–320 条静默退回摘要口径（真 OOM 被降成 exit-nonzero、排到最后，
    // 默认 limit 一截就没了），调用方却看到 degraded=false 而以为数据齐全
    const degraded = uninspected > 0
    const items = picked.map((item) => {
      const detail = details.get(item.id)
      const health = detail?.health ?? item.health
      const exitCode = detail?.exitCode ?? item.exitCode
      const oomKilled = detail?.oomKilled === true
      const restartCount = detail?.restartCount ?? null
      const reasons: AttentionReason[] = []
      if (health === 'unhealthy') reasons.push('unhealthy')
      if (item.state === 'restarting' || detail?.state === 'restarting') {
        reasons.push('restarting')
      } else if (restartCount !== null && restartCount >= ATTENTION_RESTART_THRESHOLD && freshStart(detail?.startedAt ?? null)) {
        // 运行中但刚启动 + 重启计数高 = 疑似 crash-loop（D11）
        reasons.push('restarting')
      }
      if (oomKilled) reasons.push('oom')
      else if (exitCode !== null && exitCode !== 0) reasons.push('exit-nonzero')
      if (item.state === 'dead' || detail?.state === 'dead') reasons.push('dead')
      return {
        id: item.id,
        shortId: item.shortId,
        name: item.name,
        image: item.image,
        state: detail?.state ?? item.state,
        health,
        status: item.status,
        reasons,
        exitCode,
        oomKilled,
        restartCount,
        startedAt: detail?.startedAt ?? null,
        finishedAt: detail?.finishedAt ?? null,
      }
    })
    // 严重度排序：OOM/僵死 > 不健康 > 重启中 > 非零退出；同级按名字稳定排序
    const weight = (item: AttentionItem): number => {
      if (item.reasons.includes('oom')) return 0
      if (item.reasons.includes('dead')) return 1
      if (item.reasons.includes('unhealthy')) return 2
      if (item.reasons.includes('restarting')) return 3
      return 4
    }
    // 同权重内按「最近出事」排：一堆非零退出的历史容器里，刚刚崩的那个应该在最上面
    const at = (item: AttentionItem): number => {
      const iso = item.finishedAt ?? item.startedAt
      if (typeof iso !== 'string' || iso === '') return 0
      const time = Date.parse(iso)
      return Number.isFinite(time) ? time : 0
    }
    const sorted = items
      .filter((item) => item.reasons.length > 0)
      .sort((a, b) => weight(a) - weight(b) || at(b) - at(a) || a.name.localeCompare(b.name))
    return { items: sorted.slice(0, limit), total: sorted.length, truncated: sorted.length > limit, degraded }
  }

  async stats(ids: readonly string[]): Promise<ContainerStats[]> {
    const safe = ids.map((id) => assertRef(id, 'container'))
    const result = await this.runner.run(this.statsArgv(safe, false), {
      timeoutMs: Math.max(this.limits.timeoutMs, 20_000),
      maxBytes: this.limits.maxBytes,
    })
    this.assertComplete(result, '读取容器统计', '传具体 ids（docker_stats 的 ids 参数）而不是全量')
    return parseStatsJson(result.stdout)
  }

  /**
   * 实时统计流：`docker stats`（**不带 --no-stream**）每秒为每个容器输出一行
   * `{{json .}}`。与快照共用 statsArgv 的构造，只差 --no-stream。
   *
   * 与日志流的语义差异：这条流**不会自然结束**——容器一直跑，docker stats 就
   * 一直输出；只有全部被统计的容器退出（或 id 无效）时 docker 才自己退出。
   * 因此「关闭」由浏览器主动断（EventSource.close → res close → abort），
   * 服务端在这条路径上静默中止，不写任何帧。
   */
  async statsStream(ids: readonly string[], handlers: StreamHandlers, signal?: AbortSignal): Promise<StreamResult> {
    const safe = ids.map((id) => assertRef(id, 'container'))
    return await this.runner.stream(this.statsArgv(safe, true), handlers, signal)
  }

  /** 统计 argv 的唯一构造点：快照与流式只在 --no-stream 上有差异。 */
  private statsArgv(ids: readonly string[], stream: boolean): string[] {
    return [this.bin, 'stats', ...(stream ? [] : ['--no-stream']), '--format', '{{json .}}', ...ids]
  }

  /**
   * 事件流：docker events 持续输出 JSON 行，**不会自然结束**，关闭由浏览器主动断。
   * 不带 --since：默认只从「现在」开始推，活动条要的是新动静而不是历史回放。
   * 带 --filter type=container 挡掉 network / volume / image 事件。
   */
  async eventsStream(handlers: StreamHandlers, signal?: AbortSignal): Promise<StreamResult> {
    return await this.runner.stream(this.eventsArgv({}), handlers, signal)
  }

  /**
   * 事件快照（agent 工具用）：必须先有 --until 才能让它退出——docker events
   * 只给 --since 时会一直 follow 下去，run() 会挂到超时。这里把 until 取成**请求
   * 时刻的 RFC3339**（不是字符串 'now'：docker 的 --until 只认时间戳或时长）。
   *
   * `container`（诊断用）补一条 `--filter container=<id>`：过滤在**服务端**做，
   * 宿主侧绝不按名字匹配（名字会在 rename / compose 重建后对不上，而 id 不会）。
   * 不传时 argv 与引入前逐字一致。
   *
   * `options`（诊断用）只调**采集预算**，不动 argv：单容器窗口的事件里混着大量
   * `exec_*` 噪音（每次健康检查三连，每条都带着整份镜像标签），真机实测一个
   * 20s 健康检查的容器 1h 就 588KB——而 `exec_*` 在解析时本来就会被白名单丢掉。
   * 所以诊断给一份独立的扫描预算（同 `logsGrep` 的做法）并 `keepTail`（溢出丢最旧：
   * 判断「现在为什么不行」要的是最近的一段）。既有调用点不传，行为逐字不变。
   */
  async events(since: string, container?: string, options?: { maxBytes?: number; keepTail?: boolean }): Promise<ContainerEvent[]> {
    const requested = typeof container === 'string' ? container.trim() : ''
    const scoped = requested === '' ? undefined : assertRef(requested, 'container')
    const result = await this.runner.run(this.eventsArgv({ since, until: new Date().toISOString(), ...(scoped === undefined ? {} : { container: scoped }) }), {
      // 跨 10m 窗口的事件量取决于容器活动量，给足超时但别学流那样无上限
      timeoutMs: Math.max(this.limits.timeoutMs, 30_000),
      maxBytes: options?.maxBytes ?? this.limits.maxBytes,
      ...(options?.keepTail === true ? { keepTail: true } : {}),
    })
    this.assertComplete(result, '读取容器事件', '缩小 since 窗口（如 10m）')
    return parseEventsJson(result.stdout)
  }

  /** 事件 argv 的唯一构造点：流式与快照只差 --since / --until，诊断再多一条 container 过滤。 */
  private eventsArgv(options: { since?: string; until?: string; container?: string }): string[] {
    const since = options.since === undefined ? '' : options.since.trim()
    const until = options.until === undefined ? '' : options.until.trim()
    const container = options.container === undefined ? '' : options.container.trim()
    return [
      this.bin,
      'events',
      ...(since === '' ? [] : ['--since', since]),
      ...(until === '' ? [] : ['--until', until]),
      '--format', '{{json .}}',
      '--filter', 'type=container',
      ...(container === '' ? [] : ['--filter', `container=${container}`]),
    ]
  }

  async images(): Promise<ImageSummary[]> {
    const result = await this.runner.run([this.bin, 'images', '--format', '{{json .}}'], {
      timeoutMs: this.limits.timeoutMs,
      maxBytes: this.limits.maxBytes,
    })
    this.assertComplete(result, '列出镜像', '改用 `limit` + `offset` 分页（默认每页 100），或先缩小目标范围')
    return parseImagesJson(result.stdout)
  }

  /**
   * 镜像详情：`docker image inspect`（权威元数据 + 层列表）加上
   * `docker history`（构建历史）。
   *
   * history 走 **两段降级**：先试 `--format '{{json .}}'`（Docker ≥ 26），
   * 老版本会因 unknown flag 失败，再退回纯文本表格；两段都失败只是
   * `historyError` 非空、detail 照常返回——详情页不该因为构建历史取不到就整页报错。
   */
  async imageInspect(ref: string): Promise<{ ref: string; detail: ImageDetail; history: ImageHistoryEntry[]; historyError: string | null }> {
    const safe = assertImageRef(ref, 'image')
    const result = await this.runner.run([this.bin, 'image', 'inspect', safe], {
      timeoutMs: this.limits.timeoutMs,
      maxBytes: this.limits.maxBytes,
    })
    this.assertComplete(result, '读取镜像详情')
    const detail = parseImageInspectJson(result.stdout)[0]
    if (detail === undefined) throw new Error(`镜像不存在或输出无法解析：${safe}`)

    let history: ImageHistoryEntry[] = []
    let historyError: string | null = null
    try {
      const jsonAttempt = await this.runner.run([this.bin, 'history', '--no-trunc', '--format', '{{json .}}', safe], {
        timeoutMs: this.limits.timeoutMs,
        maxBytes: this.limits.maxBytes,
      })
      if (jsonAttempt.code === 0) {
        history = parseImageHistoryJson(jsonAttempt.stdout)
        if (history.length === 0) history = parseImageHistoryText(jsonAttempt.stdout)
        // 截断必须留痕（D104）：层数多的镜像会静默「变短」，而 historyError 是这条
        // 降级路径唯一的信号位——写进去而不是抛错（历史取不到不该整页报错）
        if (jsonAttempt.truncated) historyError = `构建历史${this.truncationHint()}`
      } else {
        // 老 docker 没有 history --format：退回纯文本表格（仍带 --no-trunc 拿完整命令）
        const plainAttempt = await this.runner.run([this.bin, 'history', '--no-trunc', safe], {
          timeoutMs: this.limits.timeoutMs,
          maxBytes: this.limits.maxBytes,
        })
        if (plainAttempt.code === 0) {
          history = parseImageHistoryText(plainAttempt.stdout)
          if (plainAttempt.truncated) historyError = `构建历史${this.truncationHint()}`
        } else {
          historyError = firstLine(plainAttempt.stderr, plainAttempt.stdout, plainAttempt.code)
        }
      }
    } catch (error) {
      historyError = error instanceof Error ? error.message : String(error)
    }
    return { ref: safe, detail, history, historyError }
  }

  /** 删除镜像（`docker image rm`，不带 -f）。调用方负责 allowMutations 门禁。 */
  async imageRemove(ref: string): Promise<{ ref: string; message: string }> {
    const safe = assertImageRef(ref, 'image')
    const result = await this.runner.run([this.bin, 'image', 'rm', safe], {
      timeoutMs: Math.max(this.limits.timeoutMs, 60_000),
      maxBytes: 64 * 1024,
    })
    if (result.code !== 0) {
      const message = firstLine(result.stderr, result.stdout, result.code)
      const inUse = /image is being used|conflict|must be forced|being used by/i.test(message)
      const hint = inUse ? '（镜像仍被容器或子镜像引用：先删除相关容器；确实要强删请到终端面板手动执行 docker image rm -f）' : ''
      throw new Error(`删除镜像 ${safe} 失败：${message}${hint}`)
    }
    return { ref: safe, message: result.stdout.trim() || 'ok' }
  }

  /**
   * 清理 dangling（无标签）镜像：`docker image prune -f`。
   *
   * 刻意**不加 --all**：`--all` 会删掉所有未被容器使用的镜像（含普通 tag 的
   * 基础镜像），破坏性远超「清 dangling」的直觉。要删有标签的镜像请走单个删除
   * （imageRemove）并二次确认。
   */
  async imagePrune(): Promise<{ message: string }> {
    const result = await this.runner.run([this.bin, 'image', 'prune', '-f'], {
      timeoutMs: Math.max(this.limits.timeoutMs, 120_000),
      maxBytes: 256 * 1024,
      keepTail: true, // Total reclaimed space 在输出末尾（D14）
    })
    this.assertOk(result, '清理 dangling 镜像')
    return { message: result.stdout.trim() || 'ok' }
  }

  /* ---------------- 网络 ---------------- */

  async networks(): Promise<NetworkSummary[]> {
    const result = await this.runner.run([this.bin, 'network', 'ls', '--format', '{{json .}}'], {
      timeoutMs: this.limits.timeoutMs,
      maxBytes: this.limits.maxBytes,
    })
    this.assertComplete(result, '列出网络', '改用 `limit` + `offset` 分页（默认每页 100），或先缩小目标范围')
    return parseNetworksJson(result.stdout)
  }

  /**
   * 网络详情。inspect 顺带返回接入的容器，所以列表行**不**逐行 inspect 算容器数
   * （N 条网络就是 N 次 docker 调用），改成点进详情才取一次。
   */
  async networkInspect(name: string): Promise<{ name: string; detail: NetworkDetail }> {
    const safe = assertName(name, 'network')
    const result = await this.runner.run([this.bin, 'network', 'inspect', safe], {
      timeoutMs: this.limits.timeoutMs,
      maxBytes: this.limits.maxBytes,
    })
    this.assertComplete(result, '读取网络详情')
    const detail = parseNetworkInspectJson(result.stdout)[0]
    if (detail === undefined) throw new Error(`网络不存在或输出无法解析：${safe}`)
    return { name: safe, detail }
  }

  /** 删除网络（`docker network rm`）。调用方负责 allowMutations 门禁。 */
  async networkRemove(name: string): Promise<{ name: string; message: string }> {
    const safe = assertName(name, 'network')
    const result = await this.runner.run([this.bin, 'network', 'rm', safe], {
      timeoutMs: Math.max(this.limits.timeoutMs, 60_000),
      maxBytes: 64 * 1024,
    })
    if (result.code !== 0) {
      const message = firstLine(result.stderr, result.stdout, result.code)
      // 还有容器接着的时候 docker 会拒绝：给出可执行的下一步，而不是只回一句英文
      const inUse = /active endpoints|has active endpoints|in use/i.test(message)
      const hint = inUse ? '（还有容器接着这个网络：先把它们断开或删除；本插件不做 disconnect）' : ''
      throw new Error(`删除网络 ${safe} 失败：${message}${hint}`)
    }
    return { name: safe, message: result.stdout.trim() || 'ok' }
  }

  /**
   * 清理未被使用的网络：`docker network prune -f`。
   * `-f` 是必须的（否则 docker 会等交互确认，我们是非交互调用），
   * 且 prune 只动「没有容器接入」的网络——但 compose 的自定义网络也会被清掉
   * （下次 up 会重建），所以调用方仍然要二次确认。
   */
  async networkPrune(): Promise<{ message: string }> {
    const result = await this.runner.run([this.bin, 'network', 'prune', '-f'], {
      timeoutMs: Math.max(this.limits.timeoutMs, 120_000),
      maxBytes: 256 * 1024,
      keepTail: true,
    })
    this.assertOk(result, '清理未使用的网络')
    return { message: result.stdout.trim() || 'ok' }
  }

  /* ---------------- 卷 ---------------- */

  async volumes(): Promise<VolumeSummary[]> {
    const result = await this.runner.run([this.bin, 'volume', 'ls', '--format', '{{json .}}'], {
      timeoutMs: this.limits.timeoutMs,
      maxBytes: this.limits.maxBytes,
    })
    this.assertComplete(result, '列出卷', '改用 `limit` + `offset` 分页（默认每页 100），或先缩小目标范围')
    return parseVolumesJson(result.stdout)
  }

  /** 卷详情（`docker volume inspect <name>`）。 */
  async volumeInspect(name: string): Promise<{ name: string; detail: VolumeDetail }> {
    const safe = assertName(name, 'volume')
    const result = await this.runner.run([this.bin, 'volume', 'inspect', safe], {
      timeoutMs: this.limits.timeoutMs,
      maxBytes: this.limits.maxBytes,
    })
    this.assertComplete(result, '读取卷详情')
    const detail = parseVolumeInspectJson(result.stdout)[0]
    if (detail === undefined) throw new Error(`卷不存在或输出无法解析：${safe}`)
    return { name: safe, detail }
  }

  /** 删除卷（`docker volume rm`）。数据随卷一起没，调用方负责 allowMutations 门禁。 */
  async volumeRemove(name: string): Promise<{ name: string; message: string }> {
    const safe = assertName(name, 'volume')
    const result = await this.runner.run([this.bin, 'volume', 'rm', safe], {
      timeoutMs: Math.max(this.limits.timeoutMs, 60_000),
      maxBytes: 64 * 1024,
    })
    if (result.code !== 0) {
      const message = firstLine(result.stderr, result.stdout, result.code)
      const inUse = /volume is in use|in use/i.test(message)
      const hint = inUse ? '（卷还被容器占用：先停掉/删除用它的容器）' : ''
      throw new Error(`删除卷 ${safe} 失败：${message}${hint}`)
    }
    return { name: safe, message: result.stdout.trim() || 'ok' }
  }

  /**
   * 清理未被容器使用的卷：`docker volume prune -f`。
   *
   * **破坏性最高的一个 prune**：卷里装的是数据。刻意不带 `--all`——实测 docker 27
   * 的 `volume prune` 有 `-a/--all` 开关、不带时只删**匿名**卷；但 docker < 23 没有这个
   * 开关，plain prune 会把命名卷一起删。所以调用方必须二次确认，并且确认文案要写明
   * 这个版本差异（见 README「已知限制」）。
   */
  async volumePrune(): Promise<{ message: string }> {
    const result = await this.runner.run([this.bin, 'volume', 'prune', '-f'], {
      timeoutMs: Math.max(this.limits.timeoutMs, 120_000),
      maxBytes: 256 * 1024,
      keepTail: true,
    })
    this.assertOk(result, '清理未使用的卷')
    return { message: result.stdout.trim() || 'ok' }
  }

  /**
   * 磁盘占用（`docker system df`）：**两条命令、两份预算**。
   *
   *   - 汇总 `system df --format '{{json .}}'`：失败即整体失败（连汇总都拿不到，
   *     这个视图没有意义）；
   *   - 明细 `system df -v --format '{{json .}}'`：**独立失败**——老 docker 不认
   *     `-v --format`（unknown flag）、输出被截断、JSON 坏了，都只让 `degraded=true`
   *     并带一句人话原因，汇总照常返回。
   *
   * 两条命令不合并（契约 §2.1）：`-v` 是重活（会去 stat 每个卷），而汇总很便宜——
   * 合并后一个慢/一个失败就互相拖累。
   */
  async systemDf(): Promise<DiskUsage> {
    const summaryResult = await this.runner.run([this.bin, 'system', 'df', '--format', '{{json .}}'], {
      timeoutMs: Math.max(this.limits.timeoutMs, 30_000),
      maxBytes: this.limits.maxBytes,
    })
    this.assertComplete(summaryResult, '读取磁盘占用汇总', '换到目标机本地执行 `docker system df`')
    const summary = parseDiskSummary(summaryResult.stdout)

    try {
      const detailResult = await this.runner.run([this.bin, 'system', 'df', '-v', '--format', '{{json .}}'], {
        // `-v` 会去 stat 每个卷 / 镜像层：比汇总慢得多，超时给两档
        timeoutMs: Math.max(this.limits.timeoutMs, 60_000),
        maxBytes: Math.max(this.limits.maxBytes, DISK_DETAIL_SCAN_BYTES),
      })
      this.assertOk(detailResult, '读取磁盘占用明细')
      if (detailResult.truncated) {
        throw new Error(`明细输出超过上限被截断（明细 ${String(Math.round(Math.max(this.limits.maxBytes, DISK_DETAIL_SCAN_BYTES) / 1024 / 1024))}MB 档）`)
      }
      const detail = parseDiskDetail(detailResult.stdout)
      if (detail === null) throw new Error('无法解析明细（这个 docker 版本可能不支持 `system df -v --format`）')
      return { summary, ...detail, degraded: false, degradedReason: null }
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      return {
        summary,
        images: [],
        volumes: [],
        buildCache: [],
        // 明细没拿到 ≠ 明细是空的：三个 truncated 都给 false（它们描述的是「有但被截」），
        // totals 也归零（与「明细取到了但一条都没有」由 degraded 区分）
        totals: { images: 0, volumes: 0, buildCache: 0 },
        truncated: { images: false, volumes: false, buildCache: false },
        degraded: true,
        degradedReason: `只拿到汇总：${message}`,
      }
    }
  }

  /**
   * 现场还原：从 inspect 的原始 JSON 反推等价 `docker run`（只生成文本，**不执行**）。
   *
   * 为什么另起一条读 inspect 的路径而不是复用 `inspect()`：`ContainerDetail` 刻意不含
   * env / binds / hostConfig（那会把凭证灌进 `docker_inspect` 的模型上下文），而还原
   * 需要它们。所以这里拿**原始行**交给纯模块 `src/recreate.ts`，产出纯文本。
   */
  async recreate(id: string): Promise<RecreateResult> {
    const safe = assertRef(id, 'container')
    const result = await this.runner.run([this.bin, 'inspect', safe], {
      timeoutMs: this.limits.timeoutMs,
      maxBytes: this.limits.maxBytes,
    })
    this.assertComplete(result, '读取容器详情', '改用更少的容器 id 分批读取')
    const row = parseJsonLines(result.stdout)[0]
    if (row === undefined) throw new Error(`容器不存在或输出无法解析：${safe}`)
    return buildRunCommand(row)
  }

  /**
   * 拉取镜像（`docker pull`）。逐层进度天然是流：非 TTY 下 docker 按状态行输出
   * （Pulling fs layer / Downloading / Extracting / Pull complete），直接复用
   * ssh-exec 的长流通道（runLocalStream / RemoteExec.stream），无总超时，
   * 由连接生命周期收尾。调用方负责 allowMutations 门禁。
   */
  async pullStream(ref: string, handlers: StreamHandlers, signal?: AbortSignal): Promise<StreamResult> {
    const safe = assertImageRef(ref, 'image')
    return await this.runner.stream([this.bin, 'pull', safe], handlers, signal)
  }

  /** 拉取的快照形态（agent 工具用）：一次性跑完，输出有上限。 */
  async pull(ref: string, timeoutMs?: number): Promise<{ ref: string; code: number | null; text: string; truncated: boolean; durationMs: number }> {
    const safe = assertImageRef(ref, 'image')
    const result = await this.runner.run([this.bin, 'pull', safe], {
      timeoutMs: Math.min(Math.max(timeoutMs ?? 600_000, 10_000), 1_800_000),
      maxBytes: this.limits.maxBytes,
      keepTail: true, // digest / Downloaded 结论在输出末尾（D14）
    })
    // 超时必须报错而不是当成功返回（D16）：模型看到半截「Downloading 12MB/80MB」
    // 且没有 error，会判定为已拉取，直到 start 才暴露 image not found
    if (result.timedOut) {
      throw new Error(`拉取 ${safe} 超时中止（已运行 ${String(Math.round(result.durationMs / 1000))}s），镜像未拉完。可加大 timeoutSec 后重试，或在面板镜像页用进度流观察`)
    }
    const text = result.stdout + (result.stderr === '' ? '' : (result.stdout === '' ? '' : '\n') + result.stderr)
    return { ref: safe, code: result.code, text, truncated: result.truncated, durationMs: result.durationMs }
  }

  /**
   * 日志：stdout / stderr 分别收，stdout 整段在前、stderr 在后。
   *
   * 注意这不是「按到达顺序合并」（D44 注释纠正）：一次性命令的两路输出在
   * run() 里分别累积，时序信息已经丢了；容器交替写两路时快照日志的先后顺序
   * 与真实到达序可能不同。要真实时序请用实时跟随（FOLLOW 流是逐块按到达序推的）。
   */
  async logs(id: string, options?: LogsOptions): Promise<{ id: string; text: string; truncated: boolean }> {
    const safe = assertRef(id, 'container')
    const result = await this.runner.run(this.logsArgv(safe, options, false), {
      timeoutMs: this.limits.timeoutMs,
      maxBytes: this.limits.maxBytes,
      keepTail: true, // 超限时该丢的是最旧的行，最新行在尾部（D14）
    })
    this.assertOk(result, '读取容器日志')
    const text = result.stdout + (result.stderr === '' ? '' : (result.stdout === '' ? '' : '\n') + result.stderr)
    return { id: safe, text, truncated: result.truncated }
  }

  /**
   * 实时日志流：`docker logs --follow`，stdout/stderr 逐块回调，直到容器退出 /
   * 远端关闭 / signal 中止。argv 与快照 logs() 共用同一构造（timestamps / since
   * 语义完全一致），只多一个 --follow，且 **tail 允许 0**（D133：客户端断线重连时
   * 只要新行、不要重放历史；`--tail 0` 正是不补历史、只跟随的原生语义）。
   */
  async logsStream(id: string, options: LogsOptions | undefined, handlers: StreamHandlers, signal?: AbortSignal): Promise<StreamResult> {
    const safe = assertRef(id, 'container')
    return await this.runner.stream(this.logsArgv(safe, options, true), handlers, signal)
  }

  /**
   * 日志检索（grep）：**宿主侧逐行过滤，不碰远端 shell**——绝不拼 `| grep`
   * （那会违反「argv 构造、绝不做字符串拼接」的铁律，且 SSH 路径的转义面完全不同）。
   *
   * 与 logs() 的分工（写进工具描述，供模型选择）：「报错在最近尾部」→ docker_logs；
   * 「埋在深处 / 特定时间窗 / 找关键词」→ docker_logs_grep。扫描与返回的预算是**分开**
   * 的：扫描侧给到 8~32MB（maxOutputKb 只是单命令返回闸，grep 的意义就是从大量原文里
   * 筛出少量命中），返回侧由 limit × context 夹住，且另有**返回侧行闸**
   * MAX_RESULT_LINES（limit 上限 500 × context 上限 20 能凑出两万行，一次返回会撑爆
   * 上下文）；三处截断各有独立信号位（truncated = 扫描侧溢出丢最旧、limited = 命中超过
   * limit、truncatedForSize = 返回行数超上限），都不静默。扫描窗口
   * **对齐到行边界**（`lineAlign`）：切口处的半行不当作一行返回，否则它会以没有时间戳的
   * 噪音形式进模型上下文，看起来像「检索结果里有脏行」。
   *
   * 默认字面子串匹配（grep -F 等价，零 ReDoS）；regexp=true 才按 JS 正则解释，
   * pattern 上限 512 字符。时间戳默认开——深处的命中没有时间等于没用。
   */
  async logsGrep(id: string, options: LogGrepOptions): Promise<LogGrepResult> {
    const safe = assertRef(id, 'container')
    if (typeof options.pattern !== 'string' || options.pattern === '') throw new Error('pattern 必填（要搜索的字面子串或正则表达式）')
    if (options.pattern.length > 512) throw new Error('pattern 过长（≤512 字符）')
    const useRegexp = options.regexp === true
    const ignoreCase = options.ignoreCase === true
    /** 单行判定：命中返回匹配子串（用作 highlight），未命中返回 null。 */
    let testLine: (line: string) => string | null
    if (useRegexp) {
      let re: RegExp
      try {
        re = new RegExp(options.pattern, ignoreCase ? 'i' : '')
      } catch (error) {
        throw new Error(`无效的正则表达式：${error instanceof Error ? error.message : String(error)}`)
      }
      testLine = (line) => {
        const match = re.exec(line)
        return match === null ? null : match[0]
      }
    } else {
      const needle = ignoreCase ? options.pattern.toLowerCase() : options.pattern
      testLine = (line) => {
        const hay = ignoreCase ? line.toLowerCase() : line
        const at = hay.indexOf(needle)
        return at === -1 ? null : line.slice(at, at + needle.length)
      }
    }
    const contextLines = Math.min(Math.max(Math.trunc(options.context ?? 2), 0), 20)
    const limit = Math.min(Math.max(Math.trunc(options.limit ?? 200), 1), 500)
    // tail 缺省 = all（docker logs --tail all）；给了数字就夹到 1~5000——检索的默认语义是「全历史里找」
    const tailOverride = typeof options.tail === 'number' && Number.isInteger(options.tail) && options.tail > 0
      ? String(Math.min(options.tail, 5000))
      : 'all'
    const argv = this.logsArgv(safe, {
      timestamps: options.timestamps !== false,
      ...(typeof options.since === 'string' && options.since.trim() !== '' ? { since: options.since.trim() } : {}),
      ...(typeof options.until === 'string' && options.until.trim() !== '' ? { until: options.until.trim() } : {}),
    }, false, tailOverride)
    // 扫描预算独立于返回预算：下限 8MB、上限 32MB（宿主内存有界），超时给到 60s 档
    const scanBytes = Math.min(Math.max(this.limits.maxBytes, 8 * 1024 * 1024), 32 * 1024 * 1024)
    const result = await this.runner.run(argv, {
      timeoutMs: Math.max(this.limits.timeoutMs, 60_000),
      maxBytes: scanBytes,
      keepTail: true, // 溢出丢最旧（与 logs() 同方向，D14）；报告里如实说明窗口偏新
      // 再对齐到行边界：保留尾部是按字节切的，不对齐的话窗口第一行是**半行**（没有时间戳、
      // 内容从中途开始），会以噪音形式进模型上下文。理由与边界见 ExecOptions.lineAlign。
      lineAlign: true,
    })
    this.assertOk(result, '检索容器日志')
    // 拆行（stdout 在前、stderr 在后，与 logs() 的拼接序一致；只去掉块尾的空行）
    const splitChunk = (text: string): string[] => {
      const lines = text.split('\n')
      if (lines.length > 0 && lines[lines.length - 1] === '') lines.pop()
      return lines
    }
    const rows = [
      ...splitChunk(result.stdout).map((text) => ({ text, stream: 'out' as const })),
      ...splitChunk(result.stderr).map((text) => ({ text, stream: 'err' as const })),
    ]
    // 全量扫命中（matched 如实计数，即使超过 limit）；limit 只决定「返回哪些窗」
    const hitIndexes: number[] = []
    for (let i = 0; i < rows.length; i++) {
      if (testLine(rows[i].text) !== null) hitIndexes.push(i)
    }
    const limited = hitIndexes.length > limit
    const keptHits = hitIndexes.slice(0, limit)
    // 上下文窗口合并去重（相邻命中共享的行只输出一份），按原序输出
    const take = new Set<number>()
    const hitSet = new Set(keptHits)
    for (const idx of keptHits) {
      for (let j = Math.max(0, idx - contextLines); j <= Math.min(rows.length - 1, idx + contextLines); j++) take.add(j)
    }
    const lines: LogGrepLine[] = [...take]
      .sort((a, b) => a - b)
      .map((j) => {
        const row = rows[j]
        return {
          seq: j + 1,
          stream: row.stream,
          text: row.text,
          hit: hitSet.has(j),
          highlight: hitSet.has(j) ? testLine(row.text) : null,
        }
      })
    /*
     * 返回侧行闸：命中多的时候 window 合并出来的行数可以到两万（limit 500 × context 20），
     * 一次性回给模型就是把上下文撑爆——所以按 MAX_RESULT_LINES 截断，并**显式**给出
     * truncatedForSize + 可执行提示（缩小 limit / 减小 context / 圈时间窗），不静默截。
     * matched 仍报全量：模型靠它判断「是命中太多还是日志就只有这些」。
     */
    const exceeded = lines.length > MAX_RESULT_LINES
    const returnedLines = exceeded ? lines.slice(0, MAX_RESULT_LINES) : lines
    return {
      id: safe,
      matched: hitIndexes.length,
      scanned: rows.length,
      returned: returnedLines.length,
      limited,
      truncated: result.truncated,
      ...(exceeded
        ? {
            truncatedForSize: true,
            notes: ['命中过多已截断返回：缩小 `limit`、减小 `context`，或加 `since`/`until` 圈时间窗'],
          }
        : {}),
      contextLines,
      lines: returnedLines,
    }
  }

  /**
   * 日志 argv 的唯一构造点：快照与流式只在 `--follow` 与 tail 下限上有差异，
   * 校验与夹紧必须逐字一致（否则同一 id 在两条路径上行为漂移）。
   * `tailOverride` 供 logsGrep 传 `all`（检索要扫全部历史，而不是尾部 5000 行）。
   */
  private logsArgv(id: string, options: LogsOptions | undefined, follow: boolean, tailOverride?: string): string[] {
    // 流式允许 0（D133：重连只补新行）；快照路径保持 1 起步——「取 0 行快照」没有意义
    const min = follow ? 0 : 1
    const tail = tailOverride ?? String(Math.min(Math.max(Math.trunc(options?.tail ?? 200), min), 5000))
    return [
      this.bin,
      'logs',
      ...(follow ? ['--follow'] : []),
      '--tail',
      tail,
      ...(options?.timestamps === true ? ['--timestamps'] : []),
      ...(typeof options?.since === 'string' && options.since.trim() !== '' ? ['--since', options.since.trim()] : []),
      ...(typeof options?.until === 'string' && options.until.trim() !== '' ? ['--until', options.until.trim()] : []),
      id,
    ]
  }

  /** 生命周期操作；调用方负责 readOnly / allowMutations 门禁。 */
  async action(request: DockerAction): Promise<{ id: string; action: string; message: string }> {
    const safe = assertRef(request.id, 'container')
    const map: Record<DockerAction['action'], string[]> = {
      start: ['start'],
      stop: ['stop'],
      restart: ['restart'],
      remove: ['rm'],
    }
    const sub = map[request.action]
    const result = await this.runner.run([this.bin, ...sub, safe], {
      // stop / restart 可能要等容器优雅退出（docker 默认 10s 超时）
      timeoutMs: Math.max(this.limits.timeoutMs, 60_000),
      maxBytes: 64 * 1024,
    })
    if (result.code !== 0) {
      const message = firstLine(result.stderr, result.stdout, result.code)
      const hint = request.action === 'remove' && /running/i.test(message) ? '（容器仍在运行：先停止再删除）' : ''
      throw new Error(`${request.action} ${safe} 失败：${message}${hint}`)
    }
    return { id: safe, action: request.action, message: result.stdout.trim() || 'ok' }
  }

  /** 一次性 exec（无 TTY）：`docker exec <id> sh -c <command>`。 */
  async exec(id: string, command: string, timeoutMs?: number): Promise<{ id: string; command: string; code: number | null; stdout: string; stderr: string; truncated: boolean; durationMs: number }> {
    const safe = assertRef(id, 'container')
    if (typeof command !== 'string' || command.trim() === '') throw new Error('command 不能为空')
    if (command.length > 8000) throw new Error('command 过长（≤8000 字符）')
    const result = await this.runner.run([this.bin, 'exec', safe, 'sh', '-c', command], {
      timeoutMs: Math.min(Math.max(timeoutMs ?? 30_000, 1_000), 120_000),
      maxBytes: this.limits.maxBytes,
    })
    if (result.timedOut) throw new Error(`exec 超时（${String(Math.round(result.durationMs / 1000))}s）：${safe}`)
    return {
      id: safe,
      command,
      code: result.code,
      stdout: result.stdout,
      stderr: result.stderr,
      truncated: result.truncated,
      durationMs: result.durationMs,
    }
  }

  /**
   * 一次性 exec 的 **argv 模式**：`docker exec <id> <argv…>`，不经容器内 shell。
   *
   * 与上面 command 模式互补，不是替代：
   *   - 字符串模式把整条命令交给容器内 `sh -c`，管道 / 变量 / 重定向都能用，代价是
   *     空格与引号要再过一层 shell 解析（空参数、相邻引号、反斜杠都容易被改写）；
   *   - argv 模式一个 token 一个参数，宿主与容器都不做展开，`["printf","%s","a b"]`
   *     里的 `a b` 就是**一个**参数。需要 shell 语义时显式写 `["sh","-c","…"]`。
   * 两条通道都受同一个 `allowExec` 静态闸与档位闸约束（工具层负责），这里只保证
   * 参数形状合法、不会以字符串拼接的方式进入 argv。
   */
  async execArgv(id: string, argv: unknown, timeoutMs?: number): Promise<{ id: string; argv: string[]; command: string; code: number | null; stdout: string; stderr: string; truncated: boolean; durationMs: number }> {
    const safe = assertRef(id, 'container')
    const safeArgv = assertExecArgv(argv)
    const result = await this.runner.run([this.bin, 'exec', safe, ...safeArgv], {
      timeoutMs: Math.min(Math.max(timeoutMs ?? 30_000, 1_000), 120_000),
      maxBytes: this.limits.maxBytes,
    })
    if (result.timedOut) throw new Error(`exec 超时（${String(Math.round(result.durationMs / 1000))}s）：${safe}`)
    return {
      id: safe,
      argv: safeArgv,
      // 仅用于审计行与错误文案：argv 的『可读形态』，**不回传成可再执行的命令串**。
      command: safeArgv.join(' '),
      code: result.code,
      stdout: result.stdout,
      stderr: result.stderr,
      truncated: result.truncated,
      durationMs: result.durationMs,
    }
  }

  /* ---------------------------------------------------------------- *
   * 诊断（批一）：进程快照 + 「为什么不行」的结构化结论
   * ---------------------------------------------------------------- */

  /**
   * 容器内的进程快照（`docker top <id> -eo <TOP_PS_FORMAT>`）。
   *
   * **容器名要单独取一次**：`docker top` 的输出里没有容器名（本机实测表头就是那八列），
   * 而契约要求返回 `name`。这条是**次要信息**——只读、输出一行、失败不影响 top 的
   * 成功路径（回落成传入的 id，绝不编造）。所以它**不在** top 的 fail-fast 里：
   * top 自己失败照旧走 assertOk 抛错（容器不存在 / 未运行时 docker 就是这么答的）。
   *
   * 容器没在运行时 `docker top` 报错 → assertOk 抛错，**不返回空列表**：空列表会被
   * 读成「容器里没有进程」，而真实情况是「问不了」。
   */
  async top(id: string): Promise<{ id: string; name: string; rows: TopProcessRow[]; truncated: boolean }> {
    const safe = assertRef(id, 'container')
    const result = await this.runner.run([this.bin, 'top', safe, '-eo', TOP_PS_FORMAT], {
      timeoutMs: this.limits.timeoutMs,
      maxBytes: this.limits.maxBytes,
    })
    this.assertOk(result, '读取容器进程')
    const parsed = parseTopOutput(result.stdout)
    const name = await this.containerName(safe)
    // 两道截断取或：字节闸（runner）与行闸（TOP_MAX_ROWS）任一触发都算「不全」
    return { id: safe, name, rows: parsed.rows, truncated: parsed.truncated || result.truncated }
  }

  /**
   * 容器名（`docker inspect --format '{{.Name}}'`）。
   *
   * `.Name` 带前导斜杠（`/dsh-remote-server`），必须 strip；strip 后为空、或这条命令
   * 失败，都回落成传入的 id——名字是次要信息，不该把已经成功的 top 带下去。
   */
  private async containerName(id: string): Promise<string> {
    try {
      const result = await this.runner.run(this.containerNameArgv(id), {
        timeoutMs: this.limits.timeoutMs,
        maxBytes: 64 * 1024,
      })
      if (result.code !== 0) return id
      const name = result.stdout.trim().replace(/^\//, '')
      return name === '' ? id : name
    } catch {
      return id
    }
  }

  /** 容器名 argv 的唯一构造点（`docker top` 的输出里没有名字，top 用这条补）。 */
  private containerNameArgv(id: string): string[] {
    return [this.bin, 'inspect', '--format', '{{.Name}}', id]
  }

  /**
   * 「容器为什么不行」：一次采集四路，交给纯判据（`src/diagnose.ts`）出结论。
   *
   * **顺序与预算**（契约 §1.2）：
   *   ① 先 `inspect`——它是权威状态（退出码 / OOM / 重启次数 / 健康），**失败即整体失败**；
   *   ② 再并发 `logs` / `events`（带 `--filter container=<id>`，服务端过滤）/ `stats`——
   *      任何一路失败**只降级不抛**：该路给 `null`（与「确实是空的」区分），
   *      findings 里多一条 `*-unavailable` 说明原因，evidence 对应字段给 null。
   *
   * 三路各自独立 catch 而不是 `Promise.allSettled`：失败原因要变成给人看的文案
   * （`*Error`），而 allSettled 的 reason 还得再剖一层。
   *
   * `logTail` 夹到 1~500（默认 80），`since` 走 `assertSince`（D45 同一口径，默认 1h）——
   * 两处夹紧都在这里做，HTTP 路由与 agent 工具拿到的是同一套语义。
   */
  async diagnose(id: string, options?: { logTail?: number; since?: string }): Promise<DiagnoseResult> {
    const safe = assertRef(id, 'container')
    // 非有限数（NaN / Infinity）不能进 argv：String(NaN) 会变成字面量 "NaN"，docker 报的是参数错误
    const requestedTail = typeof options?.logTail === 'number' && Number.isFinite(options.logTail)
      ? Math.trunc(options.logTail)
      : DIAGNOSE_LOG_TAIL_DEFAULT
    const logTail = Math.min(Math.max(requestedTail, 1), DIAGNOSE_LOG_TAIL_MAX)
    const since = assertSince(typeof options?.since === 'string' && options.since.trim() !== '' ? options.since : DIAGNOSE_SINCE_DEFAULT)

    /* ① 权威状态：失败即整体失败（其余三路都是以它为前提的补充证据） */
    const inspectResult = await this.runner.run([this.bin, 'inspect', safe], {
      timeoutMs: this.limits.timeoutMs,
      maxBytes: this.limits.maxBytes,
    })
    this.assertComplete(inspectResult, '读取容器详情', '改用更少的容器 id 分批读取')
    const detail = parseInspectJson(inspectResult.stdout)[0]
    if (detail === undefined) throw new Error(`容器不存在或输出无法解析：${safe}`)
    const limits = parseInspectLimits(inspectResult.stdout)

    /* ② 三路并发采集：任何一路失败只降级，不抛 */
    const logsOutcome = this.logs(safe, { tail: logTail, since })
      .then((logs) => ({ ok: true as const, text: logs.text }))
      .catch((error: unknown) => ({ ok: false as const, error: describeCollectedError(error, '日志') }))
    const eventsOutcome = this.events(since, safe, {
      maxBytes: Math.max(this.limits.maxBytes, DIAGNOSE_EVENTS_SCAN_BYTES),
      keepTail: true,
    })
      .then((events) => ({ ok: true as const, events }))
      .catch((error: unknown) => ({ ok: false as const, error: describeCollectedError(error, '事件') }))
    const statsOutcome = this.stats([safe])
      .then((rows) => ({ ok: true as const, row: rows[0] ?? null }))
      .catch((error: unknown) => ({ ok: false as const, error: describeCollectedError(error, '资源统计') }))
    const [logsSettled, eventsSettled, statsSettled] = await Promise.all([logsOutcome, eventsOutcome, statsOutcome])

    const diagnosis = diagnose({
      detail,
      memoryLimitBytes: limits.memoryLimitBytes,
      cpuQuota: limits.cpuQuota,
      logText: logsSettled.ok ? logsSettled.text : null,
      logLines: logsSettled.ok ? countLogLines(logsSettled.text) : null,
      events: eventsSettled.ok ? eventsSettled.events : null,
      stats: statsSettled.ok ? statsSettled.row : null,
      logError: logsSettled.ok ? null : logsSettled.error,
      eventError: eventsSettled.ok ? null : eventsSettled.error,
      statsError: statsSettled.ok ? null : statsSettled.error,
      // 只给 evidence.status 的相对时长用（如 `Up 4 hours`）；判据本身仍然不读时钟
      nowMs: Date.now(),
    })
    return {
      diagnosis,
      logError: logsSettled.ok ? null : logsSettled.error,
      eventError: eventsSettled.ok ? null : eventsSettled.error,
      statsError: statsSettled.ok ? null : statsSettled.error,
    }
  }

  private assertOk(result: ExecResult, what: string): void {
    if (result.code === 0) return
    /*
     * 原文照旧放第一行（用户搜得到的还是 docker 那句话），下一行才是我们给的下一步。
     * 分开看 stderr / stdout：docker 的错误几乎都在 stderr，但个别版本（例如
     * `docker context` 配错时的提示）会走 stdout。
     */
    const hint = dockerErrorHint(result.stderr) ?? dockerErrorHint(result.stdout)
    throw new Error(
      `${what}失败（${this.runner.label}）：${firstLine(result.stderr, result.stdout, result.code)}`
      + (hint === null ? '' : `\n下一步：${hint}`),
    )
  }
}

/* ------------------------------------------------------------------ *
 * 目标 → Runner
 * ------------------------------------------------------------------ */

/** 目标定义（settings 里的 `targets[]`）。 */
export interface DockerTarget {
  /** 展示名（唯一）。 */
  name: string
  /** 本机 / SSH 远程。 */
  kind: 'local' | 'ssh'
  /** kind=ssh 时引用 tty 连接簿条目名（可选；也可直接给内联字段）。 */
  book?: string
  host?: string
  port?: number
  username?: string
  auth?: 'agent' | 'key' | 'password'
  keyPath?: string
  password?: string
  passphrase?: string
  agentForward?: boolean
}

/** 已解析出 SSH 规格的目标（连接簿查找完成）。 */
export interface ResolvedTarget {
  name: string
  kind: 'local' | 'ssh'
  spec?: SshSpec
}

/**
 * 为一个目标构造 Runner。
 *
 * `signal`（D161）是**构造时**绑定的外部取消信号：跨目标聚合给每个目标各配一个
 * `AbortController`，预算到点就 abort 这一条。绑定在构造期而不是每个调用点，是为了
 * **不改那 20+ 个 `runner.run(...)` 调用点**——它们都不需要这个信号（单目标路径的
 * 截止时间本来就是 `timeoutMs`）。
 *
 * 两个分支（local / ssh）**必须都透传**：只给一边接，就会出现「本机能取消、SSH 不能」
 * 的半截行为——比不改更糟（见项目级 ROADMAP 里跳板机那条的同一判据）。
 */
export function createRunner(options: {
  target: ResolvedTarget
  remote: RemoteExec
  logger: ExecLogger
  signal?: AbortSignal
}): Runner {
  const { target, remote, logger } = options
  const signal = options.signal
  /**
   * 把构造期绑定的 `signal` 并进单次调用的选项。调用方**自带** signal 时以它为准
   * （当前无调用点传，留给将来单命令级的取消）；否则用聚合绑定的那个。
   * 都不传时返回原样，避免多造一个对象。
   */
  const withSignal = (runOptions?: RunnerRunOptions): RunnerRunOptions => {
    const merged = runOptions?.signal ?? signal
    return merged === undefined ? (runOptions ?? {}) : { ...runOptions, signal: merged }
  }
  if (target.kind === 'local') {
    return {
      label: `本机（${target.name}）`,
      run: (argv, runOptions) => runLocal(argv, withSignal(runOptions)),
      // 长流**不**接聚合信号：它的取消由面板的 SSE 关闭单独驱动（见 runLocalStream 的文档）。
      stream: (argv, handlers, signal_) => runLocalStream(argv, handlers, signal_),
    }
  }
  const spec = target.spec
  if (spec === undefined) throw new Error(`目标 ${target.name} 缺少 SSH 规格`)
  return {
    label: `${sshTarget(spec)}（${target.name}）`,
    run: (argv, runOptions) => remote.run(spec, argv, withSignal(runOptions)),
    stream: (argv, handlers, signal_) => remote.stream(spec, argv, handlers, signal_),
  }
}

/**
 * 供宿主半体复用：把 HostKeyStore 与 logger 绑到 RemoteExec。
 *
 * `proxyCommandAllowed` 缺省 = 恒关（ProxyCommand 这一档要显式给闸门求值器才开，见
 * `RemoteExec` 的构造参数注释）。
 */
export function createRemoteExec(logger: ExecLogger, store: HostKeyStore, options?: { proxyCommandAllowed?: () => boolean }): RemoteExec {
  return new RemoteExec(logger, store, options ?? {})
}
