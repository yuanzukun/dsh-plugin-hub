/**
 * @hyzyn/dsh-docker — DSH Web GUI 的 Docker 容器面板（host 半体）。
 *
 * 与 dsh-tty 的关系（方案 A：独立插件，tty 零改动）：
 *   - **连接簿**：只读复用 tty 的 entry settings（DSH ≥0.1.7 的
 *     `settings.describe()`，经 kit 的 `readSettingsEntry(ctx, 'tty')`）的
 *     `sshHosts`。tty 未安装时退化为「只支持本机 / 内联 SSH 字段」。
 *   - **主机指纹**：本插件自持一份 `hostKeys`（TOFU），并优先读取 tty 已记录
 *     的指纹作为种子，避免同一主机在两处重复确认。
 *   - **执行通道**：自持池化 SSH exec（src/ssh-exec.ts），与 tty 的 PTY 会话
 *     完全独立；本机目标直接 spawn docker CLI。
 *
 * 信任模型（与 tty 不同，必须强调）：
 *   docker socket ≈ 该主机的 root 权限。因此**默认只读**：
 *   `allowMutations` 未开启时 start/stop/restart/remove 一律拒绝，
 *   `allowExec` 未开启时 `docker exec` 一律拒绝；两个开关都需用户在设置卡片
 *   显式打开。agent 工具同样受这两个开关约束（未开启时连工具都不注册）。
 */
import type { Context } from '@deepseek-ai/cordis'
import { accessSync, constants } from 'node:fs'
import { delimiter, basename, join } from 'node:path'
import z from '@deepseek-ai/schemastery'
import { definePlugin, hasSameOriginProof, isLoopbackRequestStrict, originProofHint, plainConfig, readSettingsEntry, registerLiteralSection, settingsEntryScope, suppressAutoSettingsPage } from '@hyzyn/dsh-kit'
import type { SettingsEntryScope } from '@hyzyn/dsh-kit'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { auditCapabilityUse, audited } from './audit.js'
import type { CapabilityUseFields } from './audit.js'
import {
  DockerApi,
  MAX_RESULT_LINES,
  assertBin,
  assertImageRef,
  assertName,
  assertRef,
  assertSince,
  createRunner,
  parseImageHistoryJson,
  parseImageHistoryText,
  parseContainerEvent,
  parseEventsJson,
  parseImageInspectJson,
  parseInspectJson,
  parsePsJson,
  parseStatsJson,
  suggestContainerNames,
} from './docker.js'
import type { Diagnosis, DiagnosisEvidence } from './diagnose.js'
import { historyTrend, sampleFromDiagnosis } from './history.js'
import type { DiagnosisSample, HistoryTrend } from './history.js'
import { DiagnosisHistoryStore, HISTORY_SCHEMA_VERSION, diagnosisHistoryPaths } from './history-store.js'
import type { DiskUsageTotals } from './docker.js'
import type {
  AttentionItem,
  ContainerDetail,
  ContainerEvent,
  ContainerStats,
  ContainerSummary,
  DockerTarget,
  ImageDetail,
  ImageHistoryEntry,
  ImageSummary,
  NetworkDetail,
  NetworkSummary,
  ResolvedTarget,
  StreamHandlers,
  VolumeDetail,
  VolumeSummary,
} from './docker.js'
import { RemoteExec, sanitizeJumpSpec, sanitizeProxyCommand, setCredentialResolver, sshTarget } from './ssh-exec.js'
import {
  auditLoadedGrants,
  attachTierGate,
  attachTierRestrict,
  bindCapabilitySources,
  capabilityDeniedMessage,
  capabilityGrantAt,
  capabilityGranted,
  capabilityGrantVia,
  capabilityPaths,
  createElevationManager,
  dshHome,
  sharedGrantStore,
} from '@hyzyn/dsh-kit'
import type { TierClass } from '@hyzyn/dsh-kit'
import type { CredentialResolver, ExecLogger, HostKeyRecord, HostKeyStore, SshSpec } from './ssh-exec.js'

export type { HostKeyRecord } from './ssh-exec.js'
export type { ContainerSummary, ContainerDetail, ContainerStats, ContainerEvent, ImageSummary, NetworkSummary, NetworkDetail, VolumeSummary, VolumeDetail, DockerTarget } from './docker.js'

/*
 * 档位闸的分类表（docs/permission-tier-plan.md §2.1）：`read` 纯读 / 固定二进制探测
 * （docker_connect_local 不在能力开关里，见 connectLocal 的注释）；`write` 容器与镜像的变更
 * （docker_image_pull 是拉取非破坏，但改本地状态，且本就注册在 allowMutations 组里）；
 * `exec` 容器内一次性命令。名单必须与 refreshTools 里 add() 注册的工集一一对应——对账由
 * test/tier-gate.test.ts 从 add() 调用处现算（漏分类 → 红）。与 allowMutations / allowExec
 * 的关系是**双层并存**：静态开关管注册（宿主级、持久授权），档位闸管已注册调用的放行
 * （逐调用、会话级），谁也不取代谁。
 */
export const DOCKER_TIER_CLASS: Record<string, TierClass> = {
  docker_targets: 'read',
  docker_connect_local: 'read',
  docker_ps: 'read',
  docker_attention: 'read',
  docker_inspect: 'read',
  docker_logs: 'read',
  docker_logs_grep: 'read',
  docker_stats: 'read',
  docker_events: 'read',
  // 批一的两条诊断工具：四路采集全是只读（inspect / logs / events / stats + top），
  // 对账由 test/tier-gate.test.ts 从 add() 调用处现算——漏分类会让档位闸静默放行
  docker_top: 'read',
  docker_diagnose: 'read',
  // 批二：磁盘汇总（system df）与等价 docker run 推导——都是只读采集/纯文本生成
  docker_disk_usage: 'read',
  docker_run_command: 'read',
  docker_images: 'read',
  docker_image_inspect: 'read',
  docker_networks: 'read',
  docker_volumes: 'read',
  docker_action: 'write',
  docker_image_remove: 'write',
  docker_image_prune: 'write',
  docker_image_pull: 'write',
  docker_exec: 'exec',
}

/** 本插件 agent 工具的名单前缀（档位闸只听这些名字）。 */
export const DOCKER_TIER_PREFIXES = ['docker_'] as const

/* ------------------------------------------------------------------ *
 * 配置
 * ------------------------------------------------------------------ */

export interface Config {
  /** 关闭整个插件。默认开。 */
  enabled?: boolean
  /** 是否向 agent 注入插件能力公告。默认开。 */
  announceToAgent?: boolean
  /** docker CLI 可执行文件名 / 路径（podman 可填 podman）。默认 docker。 */
  dockerBin?: string
  /** 允许 start/stop/restart/remove（含对应 agent 工具）。默认关。 */
  allowMutations?: boolean
  /** 允许一次性 docker exec（含对应 agent 工具）。默认关。 */
  allowExec?: boolean
  /** exec 默认超时秒数（1~120）。默认 30。 */
  execTimeoutSec?: number
  /** 面板统计刷新间隔秒数（1~60）。默认 5。 */
  pollIntervalSec?: number
  /** 日志默认尾部行数（1~5000）。默认 200。 */
  logTailDefault?: number
  /** 单次命令输出上限（KB，1~8192）。默认 512。 */
  maxOutputKb?: number
  /** 目标列表（本机 / SSH）。 */
  targets?: DockerTarget[]
  /** SSH 主机指纹记录（TOFU，随 settings 落盘）。 */
  hostKeys?: HostKeyRecord[]
}

const TARGET_SCHEMA = z.object({
  name: z.string().required(),
  kind: z.union([z.const('local'), z.const('ssh')]).default('local'),
  /** kind=ssh：引用 tty 连接簿条目名（可留空，改用下方内联字段）。 */
  book: z.string().default(''),
  host: z.string().default(''),
  port: z.natural().max(65535).default(22),
  username: z.string().default(''),
  auth: z.union([z.const('agent'), z.const('key'), z.const('password')]).default('agent'),
  keyPath: z.string().default(''),
  /** 建议写 `env:NAME` 凭据引用（官方凭据层解析），避免明文落盘。 */
  password: z.string().default(''),
  passphrase: z.string().default(''),
  agentForward: z.boolean().default(false),
})

const HOST_KEY_SCHEMA = z.object({
  host: z.string().required(),
  port: z.natural().max(65535).default(22),
  /** 同一 host:port 的全部主机密钥指纹（rsa / ed25519 等各一条）。 */
  fingerprints: z.array(z.string()).default([]),
  /** 旧版单指纹字段：仅作迁移输入（sanitizeHostKeys 会并进 fingerprints）。 */
  fingerprint: z.string().default(''),
})

/**
 * 运行时 Config schema——DSH ≥0.1.7 起同时就是本插件的 settings 存储。
 *
 * 全部字段都标 `.volatile()`：它们都是卡片可改项（见 KNOWN_CONFIG_KEYS），而
 * `settings.update(entryId, patch)` 只接受 volatile 路径；loader 对 volatile-only
 * 变更原地更新引用并发 `loader/volatile-update`，不重挂插件——插件订阅后走
 * `applySection` 热应用（见 kit 的 settingsEntryScope）。
 */
export const Config: z = z.object({
  enabled: z.boolean().default(true).volatile(),
  announceToAgent: z.boolean().default(true).volatile(),
  dockerBin: z.string().default('docker').volatile(),
  allowMutations: z.boolean().default(false).volatile(),
  allowExec: z.boolean().default(false).volatile(),
  execTimeoutSec: z.natural().max(120).default(30).volatile(),
  pollIntervalSec: z.natural().max(60).default(5).volatile(),
  logTailDefault: z.natural().max(5000).default(200).volatile(),
  maxOutputKb: z.natural().max(8192).default(512).volatile(),
  targets: z.array(TARGET_SCHEMA).default([]).volatile(),
  hostKeys: z.array(HOST_KEY_SCHEMA).default([]).volatile(),
})

/** 可经 HTTP POST 写入的配置键（白名单）。 */
const KNOWN_CONFIG_KEYS = new Set([
  'enabled',
  'announceToAgent',
  'dockerBin',
  'allowMutations',
  'allowExec',
  'execTimeoutSec',
  'pollIntervalSec',
  'logTailDefault',
  'maxOutputKb',
  'targets',
  'hostKeys',
  /** 显式清空全部目标的确认位（见 POST /config 的空数组防丢保护）。 */
  'clearTargets',
  /** 显式删除 SSH 主机密钥记录：[{host, port}]（hostKeys 是并集合并，删除必须显式）。 */
  'hostKeysRemove',
])

/** 解析后的运行期配置（settings 与 composition 两条来源统一到这一形状）。 */
interface LiveConfig {
  enabled: boolean
  announceToAgent: boolean
  dockerBin: string
  allowMutations: boolean
  allowExec: boolean
  execTimeoutSec: number
  pollIntervalSec: number
  logTailDefault: number
  maxOutputKb: number
  targets: DockerTarget[]
  hostKeys: HostKeyRecord[]
}

/** 工具返回值形状（与 defineTool 的 output.schema 推断结果一致）。 */
interface ToolTargetRow {
  name: string
  kind: string
  label: string
  ok?: boolean
  error?: string
}

/**
 * 「连接本机」的结果（面板按钮 / `POST /connect-local` / `docker_connect_local` 三条入口共用同一份）。
 *
 * `saved` 与 `reachable` 刻意分开：配置写入（本次真正的副作用）与**只读探测**（daemon 现在通不通）
 * 是两件事——探测失败不该把「目标已添加」说成失败（用户下次启动 daemon 后就能用），
 * 但也绝不能只说「已连接」而把 daemon 没起来这件事瞒过去（那正是「面板空的、不知道为啥」的来源）。
 */
interface ConnectLocalResult {
  name: string
  kind: 'local'
  created: boolean
  saved: boolean
  reachable: boolean
  serverVersion?: string
  message: string
}

/**
 * `describeLocalProbeFailure` 的额外上下文（都只能由调用方探测得到，所以外挂进来——
 * 那个函数刻意保持**纯文本进、纯文本出**，好让它能被单测直接驱动）。
 */
interface LocalProbeHint {
  /** 失败是不是超时（来自 `ProbeResult.timedOut`）。 */
  timedOut?: boolean
  /** CLI 缺失时，PATH 里找到的别的容器 CLI（见 findAlternativeLocalCli），如 `podman`。 */
  alternativeCli?: string
}

interface ToolAttentionRow {
  id: string
  name: string
  image: string
  state: string
  health?: string
  reasons: string[]
  exitCode?: number
  oomKilled: boolean
  restartCount?: number
}

interface ToolPsRow {
  id: string
  name: string
  image: string
  state: string
  status: string
  health?: string
  ports?: string
  composeProject?: string
  composeService?: string
}

interface ToolLogRow {
  target: string
  id: string
  text: string
  truncated?: boolean
}

interface ToolStatRow {
  id: string
  name: string
  cpuPercent?: number
  memUsage: string
  memPercent?: number
  netIO: string
  blockIO: string
  pids?: number
}

interface ToolEventRow {
  action: string
  name: string
  image: string
  composeProject?: string
  time?: number
  exitCode?: number
}

/** `docker_top` 的一行进程（字段全 string 的 schema 形状）。 */
interface ToolTopProcess {
  pid: string
  ppid: string
  user: string
  stat: string
  elapsed: string
  cpu: string
  mem: string
  command: string
}

interface ToolTopRow {
  target: string
  id: string
  name: string
  processes: ToolTopProcess[]
  truncated: boolean
}

/**
 * `docker_diagnose` 的证据块：**可缺字段是「省略」而不是 null**。
 *
 * 与 HTTP 响应（`DiagnosisEvidence`）刻意不同：`output.schema` 没有 null 类型，
 * 往 `{type:'string'}` 里塞 null 会被宿主校验挡掉整条结果（本包既有工具一律用
 * 「缺了就不写这个键」的写法）。业务语义不变——缺席 = 没采到 / 不适用，渲染时给 `—`。
 */
interface ToolDiagnosisEvidence {
  state?: string
  status?: string
  health?: string
  healthLastOutput?: string
  exitCode?: number
  oomKilled?: boolean
  restartCount?: number
  startedAt?: string
  finishedAt?: string
  memoryLimitBytes?: number
  cpuQuota?: number
  logLines?: number
  errorLines?: number
  eventCount?: number
  cpuPercent?: number
  memBytes?: number
  memPercent?: number
}

interface ToolDiagnosisTimelineEntry {
  at?: string
  kind: string
  text: string
}

/**
 * 工具侧的历史样本：**可缺字段省略而不是 null**。
 *
 * `defineTool` 的输出 schema 没有 null 类型（写 null 会被宿主校验挡掉**整条**结果），
 * 所以 `restartCount` / `memPercent` / `errorLines` 为 null 时**不出现**——与
 * `toToolEvidence` 同一条规矩（那条注释里记着踩过的现场）。
 */
interface ToolDiagnosisHistorySample {
  at: string
  severity: string
  code: string
  findings: string[]
  restartCount?: number
  memPercent?: number
  errorLines?: number
}

/** 工具侧的趋势：`window` 在样本 <2 时**不出现**（schema 没有 null 类型）。 */
interface ToolHistoryTrend {
  count: number
  window?: { from: string; to: string }
  verdict: HistoryTrend['verdict']
  numbers: HistoryTrend['numbers']
  newFindings: string[]
  resolvedFindings: string[]
  aggravating: boolean
}

interface ToolDiagnosisHistory {
  samples: ToolDiagnosisHistorySample[]
  trend: ToolHistoryTrend
  recorded: boolean
}

interface ToolDiagnosisRow {
  target: string
  id: string
  name: string
  verdict: { severity: string; code: string; summary: string }
  findings: Array<{ code: string; severity: string; title: string; detail: string }>
  evidence: ToolDiagnosisEvidence
  timeline: ToolDiagnosisTimelineEntry[]
  suggestions: string[]
  logTail: string
  /** 最近 N 条历史样本 + 趋势（批三）。写盘 / 读盘失败时是空样本 + `recorded: false`。 */
  history: ToolDiagnosisHistory
}

/**
 * 诊断历史视图（HTTP 与 agent 工具共用的一份形状）：最近 N 条样本 + 趋势 + 本次是否真的记了一条。
 *
 * `samples` 里**没有日志原文**，这是刻意的（见 src/history.ts 文件头）：历史只记结论与数字，
 * 日志原文可能带凭证。客户端在历史块下方也会把这句话写给用户看。
 */
export interface DiagnosisHistoryView {
  samples: DiagnosisSample[]
  trend: HistoryTrend
  /** 本次调用是否真的追加了一条（去重命中时为 false）。 */
  recorded: boolean
}

/** `docker_disk_usage` 的一行汇总（`type` 是 docker 的英文分类，原样给）。 */
interface ToolDiskSummary {
  type: string
  totalCount: number
  active: number
  size: string
  reclaimable: string
}

interface ToolDiskImage {
  id: string
  repository: string
  tag: string
  size: string
  sharedSize: string
  uniqueSize: string
  /** 「谁在用」：用这个镜像的容器数（0 = 未使用，可回收）。 */
  containers: number
}

interface ToolDiskVolume {
  name: string
  driver: string
  size: string
  /** 「谁在用」：挂载这个卷的容器数。 */
  links: number
}

interface ToolDiskBuildCache {
  id: string
  type: string
  size: string
  inUse: boolean
}

/** 磁盘工具每类明细回多少行（契约 §2.2）：模型要的是「有没有可回收的」，不是迁移清单。 */
const DISK_TOOL_ROWS = 20

interface ToolDiskRow {
  target: string
  summary: ToolDiskSummary[]
  images: ToolDiskImage[]
  volumes: ToolDiskVolume[]
  buildCache: ToolDiskBuildCache[]
  /** 截断前的真实条数（每类）——工具只回 20 行，这个数字让模型知道还有多少。 */
  totals: DiskUsageTotals
  truncated: { images: boolean; volumes: boolean; buildCache: boolean }
  degraded: boolean
  degradedReason?: string
}

/** `docker_run_command` 的返回（纯文本生成，没有任何副作用）。 */
interface ToolRunCommandRow {
  target: string
  id: string
  name: string
  command: string
  warnings: string[]
  secretKeys: string[]
  omitted: string[]
}

/** HTTP 契约（null 到齐）→ 工具 schema 形状（null 变「省略」）。 */
function toToolEvidence(evidence: DiagnosisEvidence): ToolDiagnosisEvidence {
  return {
    state: evidence.state,
    status: evidence.status,
    oomKilled: evidence.oomKilled,
    ...(evidence.health === null ? {} : { health: evidence.health }),
    ...(evidence.healthLastOutput === null ? {} : { healthLastOutput: evidence.healthLastOutput }),
    ...(evidence.exitCode === null ? {} : { exitCode: evidence.exitCode }),
    ...(evidence.restartCount === null ? {} : { restartCount: evidence.restartCount }),
    ...(evidence.startedAt === null ? {} : { startedAt: evidence.startedAt }),
    ...(evidence.finishedAt === null ? {} : { finishedAt: evidence.finishedAt }),
    ...(evidence.memoryLimitBytes === null ? {} : { memoryLimitBytes: evidence.memoryLimitBytes }),
    ...(evidence.cpuQuota === null ? {} : { cpuQuota: evidence.cpuQuota }),
    ...(evidence.logLines === null ? {} : { logLines: evidence.logLines }),
    ...(evidence.errorLines === null ? {} : { errorLines: evidence.errorLines }),
    ...(evidence.eventCount === null ? {} : { eventCount: evidence.eventCount }),
    ...(evidence.cpuPercent === null ? {} : { cpuPercent: evidence.cpuPercent }),
    ...(evidence.memBytes === null ? {} : { memBytes: evidence.memBytes }),
    ...(evidence.memPercent === null ? {} : { memPercent: evidence.memPercent }),
  }
}

/**
 * 历史视图 → 工具输出形状。
 *
 * 两处压缩都是**有意的**：
 *   - 样本最多 10 条（再多模型也读不动，而 `trend` 已经把结论给出来了）；
 *   - `null` 字段省略（工具 schema 没有 null 类型，见 `toToolEvidence` 的同款说明）。
 */
function toToolHistory(history: DiagnosisHistoryView): ToolDiagnosisHistory {
  return {
    samples: history.samples.slice(-10).map((sample) => ({
      at: sample.at,
      severity: sample.severity,
      code: sample.code,
      findings: sample.findings,
      ...(sample.restartCount === null ? {} : { restartCount: sample.restartCount }),
      ...(sample.memPercent === null ? {} : { memPercent: sample.memPercent }),
      ...(sample.errorLines === null ? {} : { errorLines: sample.errorLines }),
    })),
    trend: {
      count: history.trend.count,
      ...(history.trend.window === null ? {} : { window: history.trend.window }),
      verdict: history.trend.verdict,
      numbers: history.trend.numbers,
      newFindings: history.trend.newFindings,
      resolvedFindings: history.trend.resolvedFindings,
      aggravating: history.trend.aggravating,
    },
    recorded: history.recorded,
  }
}

interface ToolImageRow {
  reference: string
  sizeText: string
  createdSince?: string
  id: string
}

interface ToolNetworkRow {
  name: string
  driver: string
  scope: string
  internal?: boolean
  id: string
}

interface ToolVolumeRow {
  name: string
  driver: string
  scope: string
  mountpoint?: string
}

interface ToolImageDetailRow {
  target: string
  ref: string
  detail: string
}

interface ToolImagePullRow {
  target: string
  ref: string
  code?: number
  text: string
  truncated?: boolean
}

interface ToolExecRow {
  target: string
  id: string
  code?: number
  stdout: string
  stderr: string
  truncated?: boolean
}

/* ------------------------------------------------------------------ *
 * 列表分页（docker_ps / docker_images / docker_networks / docker_volumes 共用口径）
 * ------------------------------------------------------------------ */

/**
 * 一页的默认条数与上限。与 `docker_attention` 的 `limit` **同口径**（1~500 / 默认 100）：
 * 「一页多少条」跨工具必须是同一个数，否则模型每换一个列表工具都要重新试一遍。
 *
 * 为什么在**插件侧**切而不是交给 docker CLI 的 `-n` / `--filter`：`listContainers` /
 * `images` / `networks` / `volumes` 的返回契约是「该目标的完整列表」（面板、详情页、公告
 * 都依赖它），在这里切不改那条契约。也**不解决**单条命令 512KB（`maxOutputKb`）的物理
 * 上限——超了照旧抛错（见 `assertComplete`）；分页解决的是「结果长到模型读不下去」。
 */
const PAGE_DEFAULT_LIMIT = 100
const PAGE_MAX_LIMIT = 500

/** 归一化后的分页窗口（`limit` 夹在 1~PAGE_MAX_LIMIT，`offset` 非负）。 */
interface PageWindow {
  limit: number
  offset: number
}

/**
 * 分页参数的**唯一**归一化点：缺省 / 非整数落到默认值，越界**夹紧**而不是报错
 * （参数 DSL 没有 minimum/maximum，夹紧是这里唯一能保证的语义）。
 */
function pageWindow(input: { limit?: unknown; offset?: unknown }): PageWindow {
  const limit = typeof input.limit === 'number' && Number.isInteger(input.limit)
    ? Math.min(Math.max(input.limit, 1), PAGE_MAX_LIMIT)
    : PAGE_DEFAULT_LIMIT
  const offset = typeof input.offset === 'number' && Number.isInteger(input.offset) && input.offset > 0
    ? input.offset
    : 0
  return { limit, offset }
}

/** 切页结果：`total` 是**切之前**的总数，`truncated` 表示后面还有没返回的条目。 */
interface PagedRows<T> {
  rows: T[]
  total: number
  truncated: boolean
}

/** 切页的**唯一**实现：`total > offset + limit` 就是「还有下一页」（与 render 的提示同源）。 */
function paginate<T>(rows: T[], window: PageWindow): PagedRows<T> {
  const total = rows.length
  return {
    rows: rows.slice(window.offset, window.offset + window.limit),
    total,
    truncated: total > window.offset + window.limit,
  }
}

/** 分页参数的注册表（四条列表共用；与 `docker_attention` 的 limit 描述同款口径）。 */
const pageParams = {
  limit: { type: 'number', description: '本页最多返回多少条（1~500，默认 100）' },
  offset: { type: 'number', description: '跳过前多少条（默认 0）；翻页时传上一页提示里给出的 offset' },
} as const

/** render 侧的分页上下文：头部「共 N / 本页 M」、空页成因、下一跳 offset 都从这里取。 */
interface ListPage {
  total: number
  offset: number
  truncated: boolean
}

/**
 * 由返回值 + **入参**拼出 render 用的分页上下文。
 *
 * offset 读的是入参（`execute` 已经用同一个 `pageWindow` 归一化过一遍）——这里只读不写，
 * 也不新增第二个「当前页从哪开始」的真相源。
 */
function listPage(args: unknown, total: number | undefined, truncated: boolean): ListPage | undefined {
  if (total === undefined) return undefined
  const { offset } = pageWindow((args ?? {}) as { limit?: unknown; offset?: unknown })
  return { total, offset, truncated }
}

/**
 * 「怎么拿更多」的**唯一**话术（四条列表 render 共用）：只在真的还有下一页时出现。
 *
 * 给的是调用方**下一次调用就能用**的参数。不要写成「请调大 maxOutputKb」——agent 改不了
 * 插件设置，这种话术等于把问题丢回给它自己（D105 的判据在这里同样成立）。
 */
function pagingNote(page: ListPage | undefined, shown: number): string {
  if (page === undefined || page.truncated !== true || page.total <= shown) return ''
  return `\n\n共 ${String(page.total)} 条，本页显示 ${String(shown)} 条：继续用 \`offset=${String(page.offset + shown)}\`，或加 \`limit\`（上限 ${String(PAGE_MAX_LIMIT)}）`
}

/** 列表头：分页时同时给「共 N 个」与「本页 M 个」——只报一页的条数会被当成全部。 */
function listHead(noun: string, target: string, page: ListPage | undefined, shown: number): string {
  return page !== undefined && page.total !== shown
    ? `目标 ${target} 的${noun}（共 ${String(page.total)} 个，本页 ${String(shown)} 个）：`
    : `目标 ${target} 的${noun}（${String(shown)} 个）：`
}

/**
 * 空页的两种成因必须分得开：真的没有条目，还是 `offset` 越过了末页。
 * 后者不说清楚，模型会把「翻过头了」当成「这台机器上没有镜像」——D12/D42 那类假阴性。
 */
function emptyListText(noun: string, target: string, page: ListPage | undefined): string {
  if (page !== undefined && page.total > 0 && page.offset > 0) {
    return `目标 ${target} 的${noun}共 ${String(page.total)} 个，offset=${String(page.offset)} 已越过末页（改用更小的 offset 重试）。`
  }
  return `目标 ${target}：没有${noun}。`
}

/* ------------------------------------------------------------------ *
 * 常量
 * ------------------------------------------------------------------ */

const ROUTE_PREFIX = '/api/dsh-docker'
const BODY_LIMIT = 1024 * 1024

/** 变更类子路由（D32）：要求同源证明（Origin 或 Sec-Fetch-Site: same-origin）。 */
const MUTATION_SUBROUTES = new Set([
  '/action',
  '/images/remove',
  '/images/prune',
  '/networks/remove',
  '/networks/prune',
  '/volumes/remove',
  '/volumes/prune',
  '/exec',
  /*
   * 就地提权三条（判定条件是**精确子路径** + POST，所以必须逐条列；只写 '/elevate' 的话
   * /elevate/status 与 /elevate/revoke 就是裸奔的——跨站页面能撤销授权、能对着确认码试错）。
   */
  '/elevate',
  '/elevate/status',
  '/elevate/revoke',
  /*
   * 一键连接本机（POST /connect-local）：它**会写插件配置**（加一个本机目标），
   * 与其它写路径同一档，必须带同源证明——跨站页面不该有权替用户改目标列表。
   * 注意它**不**在能力开关（allowMutations / allowExec）里：见 connectLocal 的注释。
   * 客户端只在「一个目标都没有」的空态里给入口，但路由本身与调用方无关（agent 工具
   * 在任何时候都能调），所以这条守卫不能省。
   */
  '/connect-local',
])

/** 「这条错误来自目标侧」的标记（见 guardTargetFailures）。 */
const TARGET_FAILURE = Symbol('dsh-docker.target-failure')

/**
 * 给 `DockerApi` 包一层：**只有**从目标 API 抛出的错误才打上 `TARGET_FAILURE` 标记。
 *
 * 为什么需要这个标记：单目标数据路由原来是「api 抛什么，外层 catch 就统一回 500」。
 * 而 SSH 连不上 / 私钥读不到 / docker 不在 PATH 这些都是**运维状况**，不是插件 bug——
 * 多目标聚合路径对同一件事早就回 200 + `ok:false`（`aggregateAcrossTargets` 把 `run()`
 * 的抛错收成每个目标一条 `ok:false`）。于是同一句 `EPERM: open '…id_ed25519'` 在
 * `target='*'` 下是「可读原因」、在单目标下是「不透明 500」：面板点一个连不上的目标就长这样。
 *
 * 为什么不逐个调用点包 try/catch：那要改 20 处，而且**必然漏几个**——本仓「修到一半」
 * 的老毛病（D80–D125 那批 29 条）。包一次就没有漏网之鱼。
 *
 * 为什么不是「把外层 catch 全改成 200 + ok:false」：那会把我们自己的 bug（比如某天
 * 解析写错抛的 TypeError）也伪装成「目标不可达」，正是本仓最忌讳的**静默错误结果**。
 * 打标记之后，没标记的错误仍旧 500。
 */
function guardTargetFailures<T extends object>(api: T): T {
  return new Proxy(api, {
    get(target, prop, receiver) {
      const value: unknown = Reflect.get(target, prop, receiver)
      if (typeof value !== 'function') return value
      return async (...args: unknown[]): Promise<unknown> => {
        try {
          return await (value as (...rest: unknown[]) => Promise<unknown>).apply(target, args)
        } catch (error) {
          if (error !== null && typeof error === 'object') {
            Object.defineProperty(error, TARGET_FAILURE, { value: true, configurable: true })
          }
          throw error
        }
      }
    },
  })
}

/** 这条错误是不是从目标 API 抛出来的（见 guardTargetFailures）。 */
function isTargetFailure(error: unknown): boolean {
  return error !== null && typeof error === 'object' && (error as Record<symbol, unknown>)[TARGET_FAILURE] === true
}

/**
 * agent 公告：只留**能力索引 + 安全契约**（空态出路 / 能力开关 / 两条 exec 通道的边界 /
 * root 权限警示）。
 *
 * 剩下的事实在别处各有一份，**不要再写回来**（2026-10-25 从 562 压到 250 字符时删的三段）：
 *   - 「`*`（全部目标）只有 `docker_ps` / `docker_attention` 支持」——两条工具自己的
 *     `description` 里各写了一遍（`docker_ps`「target 传 `*` = 一次列出所有目标」、
 *     `docker_attention`「target 传 `*` 时跨所有目标聚合」）；`targetParam` 与运行期报错
 *     也各有一份。
 *   - 排障顺序（`docker_attention` → `docker_ps` → `docker_logs` → 尾部看不到成因再
 *     `docker_logs_grep` → `docker_inspect` / `docker_stats`）——散在各工具 `description` 里
 *     （「排障入口」/「排障第一步」/「改用 docker_logs_grep」），挨着要用的那个工具读才有用。
 *   - 网络 / 卷的增删只在面板——插件压根没有给这两个工具，模型做不了，写了也只是噪音。
 *   这三条的「仍在别处」由 `test/announcement.test.ts` 反向钉住：工具描述被精简掉就红。
 *   长度预算归 `scripts/test/announcement-budget.test.ts` 那份名单（docker 公告并入其中），
 *   本文件不再自带一条长度判据。
 *
 * ⚠️ **「允许 exec」只管本插件的一次性通道**（D163）。面板「终端」按钮跑的是
 * `docker exec -it` 交互式 shell——它经 tty 的 `ttyTerminal` 承载、**不检查 `allowExec`**
 * （`client-src/index.js` 的 `openExec` 里没有任何该判断，只读模式下也照常可用），所以这句话
 * 一旦退回「…docker exec，都需要…才有对应工具与按钮」的笼统说法，就是在**声称一条不成立的
 * 安全性质**（2026-10-07 用户正是照着旧措辞问「这算是漏洞吗」）。守卫：
 * `scripts/test/exec-terminal-scope.test.ts`（含「退回旧措辞必须变红」的反例）。
 *
 * ⚠️ **零目标时注册面只剩两条工具**（`ZERO_TARGET_TOOLS`），公告必须给出那条出路：
 * 否则 `docker_targets` 描述里「其他 docker_* 工具的 target 参数取自这里」指向的是一批
 * **此刻并不存在**的工具，模型只能原地打转。守卫：`test/announcement.test.ts`
 * （含「删掉那句必须变红」的反例）。
 */
const DOCKER_GUIDANCE =
  '本机装有 dsh-docker 插件（侧栏「容器」）。**默认只读**：启停删容器、镜像删除/清理/拉取、**一次性** docker exec（本插件），都需要用户在设置里打开「允许变更操作」「允许 exec」；「允许 exec」只管这条一次性通道——面板「终端」按钮的 exec -it 由 tty 承载、**不受它门控**。**一个目标都没有时先 `docker_connect_local` 加上本机目标**。docker socket 等价目标主机 root 权限，用户没明确要求别做变更。'

/* ------------------------------------------------------------------ *
 * 工具函数
 * ------------------------------------------------------------------ */

interface ReqLike {
  method?: string
  url?: string
  headers: Record<string, string | string[] | undefined>
  socket: { remoteAddress?: string | undefined }
}

interface ResLike {
  writeHead(status: number, headers?: Record<string, string>): void
  end(body?: string | Uint8Array): void
  /*
   * SSE 长连接的最小扩展面（结构化类型，不 import node:http）：宿主 webServer
   * 直接把原生 ServerResponse 交给 handler，这些方法天然存在；可选是为了让
   * 既有 JSON 路由与离线冒烟的极简假 res 不必全部实现。
   */
  write?(chunk: string): boolean | void
  flushHeaders?(): void
  on?(event: 'close' | 'drain', listener: () => void): void
}

/**
 * SSE 帧封装：data 一律 `JSON.stringify` 成**单行**——换行 / 引号被转义，
 * 多字节字符也不会被 SSE 的 `\n` 行边界截断（客户端 JSON.parse 还原）。
 */
export function sseFrame(event: string, data: unknown): string {
  return `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`
}

/** SSE 心跳间隔（毫秒）：注释帧只保活，客户端 EventSource 会忽略。 */
const SSE_HEARTBEAT_MS = 15_000

/** 日志 / 拉取流的分片合帧窗口（毫秒）。低一个数量级的渲染合帧是 150ms，用户看不见。 */
const SSE_COALESCE_MS = 50
/** 单个通道攒到这个字节数就立刻推一帧：不让一个大 chunk 在窗口里多等一个周期。 */
const SSE_COALESCE_MAX_BYTES = 256 * 1024

/**
 * 一条日志流最多能带多少个源（`ids=` 的**防御性上限**）。
 *
 * 每个源都是**一条真的 `docker logs -f`**：本机一个子进程、SSH 一条 channel，外加
 * 各自的合帧缓冲。而 `ids` 来自 URL，是客户端可控的量——不设上限时拼一千个条目就能
 * 让宿主一口气起一千个进程（这条流是只读能力，不该成为放大攻击的入口）。32 远高于
 * 「一个 Compose 项目全选」的实际需要，正常视图碰不到它。
 */
const MAX_LOGS_SOURCES = 32

/** 合帧器句柄（生命周期：`flush()` 收尾、`dispose()` 停表）。 */
export interface SseCoalescer {
  /** 追加一个分片：窗口到点（或攒满 maxBytes）时按通道合并成一帧推出去。 */
  push(channel: 'd' | 'e', text: string): void
  /** 立刻把两个通道里攒着的分片推出去（顺序：stdout 先、stderr 后）。 */
  flush(): void
  /** 停掉定时器并丢掉残帧（客户端已走 / 流已收尾，再推只会写进关掉的响应）。 */
  dispose(): void
}

/**
 * SSE 分片合帧器（D151）：把「一个 stdout chunk 一帧」压成「一个窗口一帧」。
 *
 * 为什么要有它：`docker logs -f` / `docker pull` 的分片大小由上游决定，话痨容器
 * （未缓冲 stdout、逐行 flush 的应用）能到每秒几千个 chunk，而每个 chunk 在链路上
 * 的固定成本并不小——服务端一次 `JSON.stringify` + 一次 `res.write`，客户端一次
 * SSE 事件派发 + 一次 `JSON.parse` + 一次 `pushChunk`（字符串拼接 + 扫描换行）。
 * 这些成本与「一行日志多少个字节」无关，只与**事件个数**成正比。
 *
 * 实测（scripts/log-perf.mjs 的事件洪泛剖面，同一行速率 6.2k 行/秒）：每事件 1 行
 * 时事件循环最大延迟 53ms、出现 1 个 >50ms 的长帧；每事件 50 行时 37ms、0 个。
 * 差距在事件率再高一个数量级时会继续放大（浏览器真实 SSE 解析比冒烟桩更贵）。
 *
 * 语义约束（客户端按到达序落行，合帧不能改变「看到的内容」）：
 *   - 同一通道内部**严格保序**（就是字符串拼接）；
 *   - 两个通道各攒各的，一帧最多推 `d` 一条 + `e` 一条——`docker logs` 的 stdout /
 *     stderr 本就是两路，跨通道的先后从来不由单帧保证；
 *   - 收尾前调用方必须 `flush()`：`end` 帧得排在这些 `line` 帧之后（见调用点）。
 */
export function createSseCoalescer(options: {
  emit: (channel: 'd' | 'e', text: string) => void
  windowMs?: number
  maxBytes?: number
}): SseCoalescer {
  const windowMs = typeof options.windowMs === 'number' && options.windowMs > 0 ? options.windowMs : SSE_COALESCE_MS
  const maxBytes = typeof options.maxBytes === 'number' && options.maxBytes > 0 ? options.maxBytes : SSE_COALESCE_MAX_BYTES
  let stdout = ''
  let stderr = ''
  let timer: NodeJS.Timeout | null = null

  const stopTimer = (): void => {
    if (timer === null) return
    clearTimeout(timer)
    timer = null
  }

  const flush = (): void => {
    stopTimer()
    if (stdout !== '') {
      const text = stdout
      stdout = ''
      options.emit('d', text)
    }
    if (stderr !== '') {
      const text = stderr
      stderr = ''
      options.emit('e', text)
    }
  }

  return {
    push(channel, text) {
      if (typeof text !== 'string' || text === '') return
      if (channel === 'd') stdout += text
      else stderr += text
      // 攒满一个上限就立刻推：超大 chunk（整段 JSON / base64）不该在窗口里多等一拍
      if ((channel === 'd' ? stdout : stderr).length >= maxBytes) {
        flush()
        return
      }
      if (timer === null) timer = setTimeout(flush, windowMs)
    },
    flush,
    dispose() {
      stopTimer()
      stdout = ''
      stderr = ''
    },
  }
}

/*
 * 回环围栏与同源证明：**实现已收敛到 `@hyzyn/dsh-kit`**（2026-09-25，项目级 ROADMAP
 * 第 1 项）。本包是那段加固档的来源，行为一字未改；D31 / D32 / D80 / D110 / D139 五条
 * 的成因、时序约束与桌面版例外随实现一起搬到了 `packages/kit/src/http.ts`——**那边的
 * 注释是唯一归宿**，这里只留指针（否则又是「三处各写一份必然漂」）。
 */


function writeJson(res: ResLike, status: number, body: unknown): void {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'referrer-policy': 'no-referrer' })
  res.end(JSON.stringify(body))
}

/** 读取并解析 JSON 请求体；超限/非对象/非法 JSON 返回 undefined。 */
async function readJsonBody(req: AsyncIterable<Uint8Array>): Promise<Record<string, unknown> | undefined> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    size += chunk.byteLength
    if (size > BODY_LIMIT) return undefined
    chunks.push(Buffer.from(chunk))
  }
  if (size === 0) return {}
  try {
    const parsed: unknown = JSON.parse(Buffer.concat(chunks).toString('utf8'))
    if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) return undefined
    return parsed as Record<string, unknown>
  } catch {
    return undefined
  }
}

/** 清洗一份 targets 输入（settings 存储 / 热更新路径共用）。 */
export function sanitizeTargets(input: unknown): DockerTarget[] | undefined {
  if (!Array.isArray(input)) return undefined
  const out: DockerTarget[] = []
  const seen = new Set<string>()
  for (const raw of input) {
    if (typeof raw !== 'object' || raw === null) continue
    const item = raw as Record<string, unknown>
    const name = typeof item.name === 'string' ? item.name.trim() : ''
    if (name === '' || name.length > 64 || seen.has(name)) continue
    const kind = item.kind === 'ssh' ? 'ssh' : 'local'
    const port = typeof item.port === 'number' && Number.isInteger(item.port) && item.port >= 1 && item.port <= 65535 ? item.port : 22
    const auth = item.auth === 'key' || item.auth === 'password' ? item.auth : 'agent'
    seen.add(name)
    out.push({
      name,
      kind,
      book: typeof item.book === 'string' ? item.book.trim() : '',
      host: typeof item.host === 'string' ? item.host.trim() : '',
      port,
      username: typeof item.username === 'string' ? item.username.trim() : '',
      auth,
      keyPath: typeof item.keyPath === 'string' ? item.keyPath.trim() : '',
      password: typeof item.password === 'string' ? item.password : '',
      passphrase: typeof item.passphrase === 'string' ? item.passphrase : '',
      agentForward: item.agentForward === true,
    })
  }
  return out
}

/** 一键连接本机时新建目标的基准名。刻意用稳定的小写 `local`（不是 `本机`）：它是可预测的 id，重名时另起 `local-2`…。 */
export const LOCAL_TARGET_NAME = 'local'

/** 目标列表里第一个 `kind=local` 的名称（没有则 undefined）——「连接本机」靠它判断该新建还是复用。 */
export function findLocalTargetName(targets: readonly DockerTarget[]): string | undefined {
  return targets.find((item) => item.kind === 'local')?.name
}

/**
 * 新建本机目标时挑一个**确定性无冲突**的名称：`local` 被占就顺着 `local-2`、`local-3`… 找第一个空位。
 *
 * 为什么不做随机 / 时间戳后缀：同一个工作区里重复点「连接本机」应当**幂等**（第二次复用第一次那条），
 * 而重名只可能来自用户自己配的其它 `local*`；顺序探测既确定又与用户已有的名字不冲突（不覆盖、不改名）。
 * 上界 1000 是防御性截断（真到那时说明列表已经病态，宁可失败也不能无限循环）。
 */
export function nextLocalTargetName(taken: readonly string[]): string | undefined {
  const used = new Set(taken)
  if (!used.has(LOCAL_TARGET_NAME)) return LOCAL_TARGET_NAME
  for (let index = 2; index <= 1000; index += 1) {
    const candidate = `${LOCAL_TARGET_NAME}-${String(index)}`
    if (!used.has(candidate)) return candidate
  }
  return undefined
}

/**
 * 「探不到 CLI」的判据（`runLocal` 的 ENOENT 抛错形态）。
 *
 * 抽出来当单一来源：文案分档与「要不要去找 podman」都用它，两处各写一遍正则
 * 迟早会漂移——那时会出现「文案说 CLI 缺失、但不去找候选」或反过来。
 */
export function isLocalCliMissing(raw: string): boolean {
  return /ENOENT|not recognized as an internal|command not found/i.test(raw)
}

/** 本机容器 CLI 的候选（除 `dockerBin` 自己之外）：按这个顺序找第一个存在的。 */
const LOCAL_CLI_ALTERNATIVES = ['docker', 'podman', 'nerdctl'] as const

/**
 * 在 PATH 里找**别的**容器 CLI（`dockerBin` 缺失时的候选），返回名字数组（可能为空）。
 *
 * 只读探测，**绝不改配置**：返回的候选交给文案去说「你可以把 docker CLI 改成它」，
 * 改不改由用户在设置卡片决定。静默改写 `dockerBin` 会违背本插件「不替用户决定」的
 * 一贯取向（何况 podman 与本插件的输出格式兼容性并未逐项验证，见 README）。
 *
 * `env` 可注入（测试用）；Windows 按 PATHEXT 补扩展名——本插件明确支持 Windows
 * 盘符路径，不能只认无扩展名的 POSIX 查找。
 */
export function findAlternativeLocalCli(bin: string, env: NodeJS.ProcessEnv = process.env): string[] {
  const dirs = (env.PATH ?? '').split(delimiter).filter((item) => item !== '')
  const win = process.platform === 'win32'
  const exts = win ? (env.PATHEXT ?? '.COM;.EXE;.BAT;.CMD').split(';').filter((item) => item !== '') : ['']
  /*
   * 比的是**工具名**（basename，Windows 再去掉扩展名），不是配置里的原字符串：
   * `dockerBin` 常写成绝对路径（`/usr/local/bin/docker`），拿它直接比对候选名会
   * 把「同一个 docker」当成可切换的候选，给出「把 docker CLI 改成 docker」这种废话。
   */
  const stem = (value: string): string => {
    const base = basename(value).toLowerCase()
    return win ? base.replace(/\.[^.]+$/, '') : base
  }
  const self = stem(bin)
  const found: string[] = []
  for (const candidate of LOCAL_CLI_ALTERNATIVES) {
    if (candidate === self) continue
    const dir = dirs.find((item) => exts.some((ext) => {
      try {
        accessSync(join(item, candidate + ext), constants.X_OK)
        return true
      } catch {
        return false
      }
    }))
    if (dir !== undefined) found.push(candidate)
  }
  return found
}

/**
 * 只读探测失败 → 用户能照着做的一句话。按**成因**分档（而不是原样甩 `exit status 1`）：
 * CLI 不在（装 Docker / 改 `dockerBin`）、超时（daemon 卡死 / context 指错）、
 * daemon 不可达、socket 无权、其它（原样透出）。
 *
 * `probe()` 的两条失败路径形状不同：`runLocal` 对 ENOENT 是**抛错**（`无法执行 docker：spawn docker ENOENT`），
 * 而 daemon 连不上是 docker CLI 自己以非零退出 + stderr 文案返回；两条都要认得出。
 */
export function describeLocalProbeFailure(raw: string, bin = 'docker', hint: LocalProbeHint = {}): string {
  const text = raw.trim()
  if (isLocalCliMissing(text)) {
    const head = `宿主上找不到 docker CLI（${bin}）：请先安装 Docker，或在设置卡片把「docker CLI」改成正确的可执行文件路径`
    // 有候选就点出来——只说「请先安装 Docker」会让 podman 用户以为要装一整套 Docker。
    // 同时写明**面板不会替你改**：这是提示，不是自动切换（见 findAlternativeLocalCli）。
    return hint.alternativeCli === undefined || hint.alternativeCli === ''
      ? head
      : `${head}。这台机器上装了 ${hint.alternativeCli}：把「docker CLI」填成 ${hint.alternativeCli} 就能用（面板不会替你改）`
  }
  /*
   * 超时单独一档（D159）：它和「daemon 没起」的可修动作完全不同，也不能落进下面
   * 那句「退出码 null」。判据来自 `ProbeResult.timedOut` 而不是解析文案——CLI 的
   * 超时输出里根本没有可认的字样。
   */
  if (hint.timedOut === true) {
    return `${bin} version 15 秒没返回：daemon 可能卡死，或 docker context 指向了连不上的远端（用 docker context ls 看当前指向；Docker Desktop 卡死时重启它）`
  }
  if (/ECONNREFUSED|ENOENT.*\.sock|\.sock.*(no such file|不是目录|No such)/i.test(text)) {
    return `docker CLI 可用，但连不上 docker daemon：请确认 daemon 已启动（Linux: systemctl start docker；macOS/Windows: 启动 Docker Desktop）`
  }
  if (/permission denied/i.test(text)) {
    return `docker CLI 可用，但当前账号无权访问 docker socket：把运行宿主的账号加入 docker 组，或改用允许的 socket`
  }
  if (/Is the docker daemon running|Cannot connect to the Docker daemon|error during connect/i.test(text)) {
    return `docker CLI 可用，但连不上 docker daemon：请确认 daemon 已启动（Linux: systemctl start docker；macOS/Windows: 启动 Docker Desktop）`
  }
  return `docker daemon 探测失败：${text === '' ? 'docker version 没有返回任何信息' : text}`
}

/**
 * 清洗一份 hostKeys 输入（settings 存储 / 热更新 / 种子复制共用）。
 *
 * 同时接受两种形状（D03）：
 *   - tty 0.19.0+ 的 `{host, port, fingerprints: [...]}`（多指纹集合）；
 *   - docker 0.6.x 自己落盘的 `{host, port, fingerprint}`（迁移输入）。
 * host 统一 trim + 小写（与 tty 的落盘口径一致，否则种子命中与否取决于大小写），
 * 同一 host:port 的多条记录合并成一组指纹。
 */
export function sanitizeHostKeys(input: unknown): HostKeyRecord[] | undefined {
  if (!Array.isArray(input)) return undefined
  const byKey = new Map<string, HostKeyRecord>()
  for (const raw of input) {
    if (typeof raw !== 'object' || raw === null) continue
    const item = raw as Record<string, unknown>
    const host = typeof item.host === 'string' ? item.host.trim().toLowerCase() : ''
    const port = typeof item.port === 'number' && Number.isInteger(item.port) && item.port >= 1 && item.port <= 65535 ? item.port : 22
    const list = Array.isArray(item.fingerprints) ? item.fingerprints : []
    const single = typeof item.fingerprint === 'string' && item.fingerprint.trim() !== '' ? [item.fingerprint.trim()] : []
    const fingerprints = [...new Set([
      ...list.filter((fp): fp is string => typeof fp === 'string' && fp.trim() !== '').map((fp) => fp.trim()),
      ...single,
    ])]
    if (host === '' || fingerprints.length === 0) continue
    const key = `${host}:${String(port)}`
    const existing = byKey.get(key)
    if (existing !== undefined) {
      existing.fingerprints = [...new Set([...existing.fingerprints, ...fingerprints])]
      continue
    }
    byKey.set(key, { host, port, fingerprints })
  }
  return [...byKey.values()]
}

/**
 * hostKeys **并集**合并（D10）：客户端表单快照回传的表不得整表覆盖 TOFU 运行期
 * 新增的记录——面板一次无关保存就把钉扎回退掉，指纹变更检测随之失效。按
 * host:port 合并指纹集合；删除某条记录走显式的 `hostKeysRemove`。
 */
export function mergeHostKeys(base: HostKeyRecord[], incoming: unknown): HostKeyRecord[] {
  const byKey = new Map<string, HostKeyRecord>()
  for (const record of base) {
    byKey.set(`${record.host}:${String(record.port)}`, { host: record.host, port: record.port, fingerprints: [...record.fingerprints] })
  }
  for (const record of sanitizeHostKeys(incoming) ?? []) {
    const key = `${record.host}:${String(record.port)}`
    const existing = byKey.get(key)
    if (existing === undefined) {
      byKey.set(key, { host: record.host, port: record.port, fingerprints: [...record.fingerprints] })
      continue
    }
    existing.fingerprints = [...new Set([...existing.fingerprints, ...record.fingerprints])]
  }
  return [...byKey.values()]
}

/**
 * 合并凭证：配置卡片从不回显密码 / 口令（只回 passwordSet），因此浏览器提交的
 * targets 里往往**没有** password/passphrase 字段。按目标名把已有值补回来，
 * 避免「改个名字就把密码清了」。（显式传空字符串仍然按清空处理。）
 *
 * 改名的目标按**连接身份**（book / host / port / username / auth / keyPath）认领
 * 旧凭证（D15）：只按名字找的话，改名 = 凭证凭空消失。身份对不上就不继承——
 * 「删一个目标、另建一个无关目标」不应该串密码，宁缺勿错。
 */
export function mergeTargetSecrets(prev: DockerTarget[], incoming: unknown): unknown {
  if (!Array.isArray(incoming)) return incoming
  const incomingNames = new Set<string>()
  for (const raw of incoming) {
    if (typeof raw !== 'object' || raw === null) continue
    const name = (raw as Record<string, unknown>).name
    if (typeof name === 'string' && name.trim() !== '') incomingNames.add(name.trim())
  }
  // 名字没出现在新表里的旧目标 = 改名 / 删除的候选
  const renamed = prev.filter((target) => !incomingNames.has(target.name))
  return incoming.map((raw) => {
    if (typeof raw !== 'object' || raw === null) return raw
    const item = raw as Record<string, unknown>
    const name = typeof item.name === 'string' ? item.name.trim() : ''
    let before = prev.find((target) => target.name === name)
    if (before === undefined && renamed.length > 0) {
      const book = typeof item.book === 'string' ? item.book.trim() : ''
      const host = typeof item.host === 'string' ? item.host.trim() : ''
      const username = typeof item.username === 'string' ? item.username.trim() : ''
      const keyPath = typeof item.keyPath === 'string' ? item.keyPath.trim() : ''
      const auth = item.auth === 'key' || item.auth === 'password' ? item.auth : 'agent'
      const port = typeof item.port === 'number' && Number.isInteger(item.port) ? item.port : 22
      before = renamed.find((target) =>
        (target.book ?? '') === book
        && target.host === host
        && (target.port ?? 22) === port
        && target.username === username
        && (target.auth ?? 'agent') === auth
        && target.keyPath === keyPath)
    }
    if (before === undefined) return item
    const next: Record<string, unknown> = { ...item }
    if (typeof next.password !== 'string') next.password = before.password ?? ''
    if (typeof next.passphrase !== 'string') next.passphrase = before.passphrase ?? ''
    return next
  })
}

/**
 * 两条能力开关的宿主侧授权（见 kit 的 capability.js 与 docs/architecture.md）。
 *
 * 两条提权通道：**启动环境变量**（最严，见 kit 的 capability.ts）与**就地提权**（页内点开关 →
 * 在宿主上落地一个随机名文件 → 免重启生效，见 kit 的 elevation.ts）。HTTP 侧不能凭空打开它们——
 * 回环围栏与同源证明都拦不住跨站页面与页内脚本（它们能自己填 `Sec-Fetch-Site: same-origin`，
 * 那是请求头不是凭据），而 docker socket 等价目标主机 root。
 */
const CAP_MUTATIONS = { env: 'DSH_DOCKER_ALLOW_MUTATIONS', label: '变更操作' } as const
const CAP_EXEC = { env: 'DSH_DOCKER_ALLOW_EXEC', label: 'exec' } as const

/**
 * 客户端/HTTP 用的能力名 → 授权说明。**白名单**：不在表里的一律 400。
 *
 * 为什么要这张表：路由收到的 `capability` 是外部字符串，直接拿它当环境变量名去查授权存储，等于让
 * 请求方决定「查哪个键」——今天查不出问题（存储里只有这两个键），明天就是一类越权。
 */
const CAPABILITIES = new Map<string, { env: string; label: string }>([
  ['allowMutations', CAP_MUTATIONS],
  ['allowExec', CAP_EXEC],
])

/**
 * 零目标时仍然注册的工具——**空态的唯一出路**。
 *
 * 其余每个工具都必须寻址到一个目标（省略 `target` 时回落「唯一目标」，多目标则必填），
 * 一条目标都没有时它们注册了也只会让模型白试一次、拿到「尚未配置任何 Docker 目标」再
 * 回头调 `docker_targets`；而这两条正是让空态可解释、可自救的入口：一条看有哪些目标，
 * 一条一键加本机。名单之外的 `add()` 在 `live.targets` 为空时直接跳过（见 refreshTools），
 * 配好目标后由 applySection 按目标变化**补注册**，不需要重启。
 */
const ZERO_TARGET_TOOLS: ReadonlySet<string> = new Set(['docker_targets', 'docker_connect_local'])

/** 未启用时的文案：没授权要说清「怎么授权」，授权了只是没开就说「去开开关」。 */
function mutationsOffMessage(): string {
  return capabilityGranted(CAP_MUTATIONS)
    ? '变更操作未启用（插件配置 → Docker 容器面板 → 允许变更操作）'
    : capabilityDeniedMessage(CAP_MUTATIONS, { inPlace: true })
}

/** `exec` 那一档的同款文案。 */
function execOffMessage(): string {
  return capabilityGranted(CAP_EXEC)
    ? 'exec 未启用（插件配置 → Docker 容器面板 → 允许 exec）'
    : capabilityDeniedMessage(CAP_EXEC, { inPlace: true })
}

/** 把一份任意来源的配置归一成 LiveConfig。 */
export function normalizeConfig(section: Record<string, unknown>): LiveConfig {
  const targets = sanitizeTargets(section.targets)
  const hostKeys = sanitizeHostKeys(section.hostKeys)
  return {
    enabled: section.enabled !== false,
    announceToAgent: section.announceToAgent !== false,
    dockerBin: assertBin(section.dockerBin),
    /*
     * **有效值 = 配置值 && 宿主授权**。折叠在这一处（而不是每个使用点各判一次）的理由：本包
     * 有二十多处按 `live.allowMutations` 决定「工具注册 / 路由放行 / 面板渲染」，散着判必然
     * 漏一处——漏掉的那处就是「没授权也能执行」。配置里的 true 不算授权：它与 HTTP 写进去的
     * 值存在同一个存储里，分不出来源，只认环境变量才是能说清的规则（升级影响见 README）。
     */
    allowMutations: section.allowMutations === true && capabilityGranted(CAP_MUTATIONS),
    allowExec: section.allowExec === true && capabilityGranted(CAP_EXEC),
    execTimeoutSec: clampInt(section.execTimeoutSec, 1, 120, 30),
    pollIntervalSec: clampInt(section.pollIntervalSec, 1, 60, 5),
    logTailDefault: clampInt(section.logTailDefault, 1, 5000, 200),
    maxOutputKb: clampInt(section.maxOutputKb, 1, 8192, 512),
    targets: targets ?? [],
    hostKeys: hostKeys ?? [],
  }
}

function clampInt(value: unknown, min: number, max: number, fallback: number): number {
  if (typeof value !== 'number' || !Number.isInteger(value)) return fallback
  return Math.min(Math.max(value, min), max)
}

/**
 * 事件时间（Unix 秒）→ 本机时区的 HH:MM:SS（agent 文本输出用）。
 * 只回时间不回日期：事件快照窗口最多几小时，日期对排障没有信息量；
 * 浏览器侧不用这个——那里用 Date 按用户本地时区现算。
 */
export function formatEventTime(seconds: number): string {
  const date = new Date(seconds * 1000)
  if (Number.isNaN(date.getTime())) return '--:--:--'
  const pad = (value: number): string => String(value).padStart(2, '0')
  return `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`
}

/** 字节 → docker 风格的人类可读大小（十进制单位，与 `docker images` 的 SIZE 一致）。 */
export function formatBytes(value: number): string {
  if (!Number.isFinite(value) || value < 0) return '—'
  const units = ['B', 'kB', 'MB', 'GB', 'TB']
  let size = value
  let unit = 0
  while (size >= 1000 && unit < units.length - 1) {
    size /= 1000
    unit += 1
  }
  const text = unit === 0 ? String(Math.round(size)) : size.toFixed(size >= 100 ? 0 : 1)
  return `${text} ${units[unit] ?? 'B'}`
}

/** 从 tty 的 entry settings 读取连接簿（只读；tty 未安装时为空表）。 */
/**
 * 读 tty 连接簿 → 本包的连接规格。**导出仅供单测**（连接簿 → 规格这一跳是「一处配置、两处
 * 生效」的落地处：漏带 jump / proxyCommand 就是「tty 能连、docker 连不上」那种半吊子状态）。
 */
export function readTtyBooks(settings: SettingsLookup | undefined): Map<string, SshSpec> {
  const out = new Map<string, SshSpec>()
  if (settings === undefined) return out
  let raw: unknown
  try {
    raw = settings.get('tty')
  } catch {
    return out
  }
  if (typeof raw !== 'object' || raw === null) return out
  const hosts = (raw as { sshHosts?: unknown }).sshHosts
  if (!Array.isArray(hosts)) return out
  for (const entry of hosts) {
    if (typeof entry !== 'object' || entry === null) continue
    const item = entry as Record<string, unknown>
    const name = typeof item.name === 'string' ? item.name.trim() : ''
    const host = typeof item.host === 'string' ? item.host.trim() : ''
    const username = typeof item.username === 'string' ? item.username.trim() : ''
    if (name === '' || host === '' || username === '') continue
    const spec: SshSpec = {
      host,
      port: typeof item.port === 'number' && Number.isInteger(item.port) ? item.port : 22,
      username,
      auth: item.auth === 'key' || item.auth === 'password' ? item.auth : 'agent',
      keyPath: typeof item.keyPath === 'string' ? item.keyPath : '',
      password: typeof item.password === 'string' ? item.password : '',
      passphrase: typeof item.passphrase === 'string' ? item.passphrase : '',
      agentForward: item.agentForward === true,
    }
    /*
     * 跳板机跟着连接簿一起走（本包**不自建跳板机界面**：目标是「一处配置、两处生效」）。
     * 漏了这一段就是「终端能连、docker 目标连不上」——本项立项时点名的半吊子状态。
     */
    const jump = sanitizeJumpSpec(item.jump)
    if (jump !== undefined) spec.jump = jump
    /*
     * 代理命令同理跟着连接簿走（本包**不自建界面**）。闸门不在这里判：它归 tty settings 的
     * `allowProxyCommand`，由 `readTtyProxyCommandAllowed()` 现读、在**每次拨号**时求值
     * （见 RemoteExec 的 options.proxyCommandAllowed）——这样用户一关开关就立刻生效。
     */
    const proxyCommand = sanitizeProxyCommand(item.proxyCommand)
    if (proxyCommand !== undefined) spec.proxyCommand = proxyCommand
    out.set(name, spec)
  }
  return out
}

/**
 * tty 的 ProxyCommand 能力（**与 tty 包同一份规格**，环境变量名必须逐字相同）。
 *
 * 为什么 docker 也要声明它：本包通过连接簿条目拨号时会执行那条 `proxyCommand`，
 * 而「能不能执行代理命令」的闸门只有一处——tty 的能力开关。两包各写一份 env 名会
 * 悄悄分叉（改名只红一侧），所以这里与 `packages/tty/src/index.ts` 的 `CAP_PROXY_COMMAND`
 * 保持一致，由 `packages/docker/test/ssh-proxy-command.test.ts` 钉住。
 */
const CAP_PROXY_COMMAND = { env: 'DSH_TTY_ALLOW_PROXY_COMMAND', label: '代理命令（ProxyCommand）' } as const

/**
 * 读 tty settings 里的 ProxyCommand 闸门（`allowProxyCommand`，默认关）。
 *
 * 为什么本包要用 **tty 的**开关而不是自己再加一个：连接簿只有一处（tty），代理命令也只有
 * 一处能填；两个开关会让「连接簿配了、这个面板不认」变成说不清的状态。代价是本包多依赖一个
 * 只读 settings 字段——settings 句柄缺失（启动早期）时恒 false，即**关**（失败方向安全）。
 *
 * **但配置值不等于授权**（2026-10-19 外部测评 issue #13 第 4 条）：tty 侧的闸门是
 * `granted && enabled`（`packages/tty/src/index.ts` 的 `setProxyCommandPolicy`），
 * 而这里原先只读配置值。于是「点过撤销宿主授权 / 升级前在界面里开过 / 手改 settings.yaml」
 * 的机器上，tty 自己拒绝执行，docker 引用同一连接簿条目却照样 `spawn(cmd, {shell:true})`
 * ——同一份连接簿在两个面板里得到两种安全结论，而弱的那一侧能执行任意命令。
 *
 * 现在两边同口径：**宿主授权 && 配置开关**，缺一即关。
 */
export function readTtyProxyCommandAllowed(settings: SettingsLookup | undefined): boolean {
  if (settings === undefined) return false
  let raw: unknown
  try {
    raw = settings.get('tty')
  } catch {
    return false
  }
  if (typeof raw !== 'object' || raw === null) return false
  if ((raw as { allowProxyCommand?: unknown }).allowProxyCommand !== true) return false
  // 配置说开还不够：宿主没授权就是没授权（与 tty 的 granted && enabled 同一判据）
  return capabilityGranted(CAP_PROXY_COMMAND)
}

/** 从 tty 的 hostKeys 读取已钉扎指纹（作为本插件 TOFU 的种子）。 */
function readTtyHostKeys(settings: SettingsLookup | undefined): HostKeyRecord[] {
  if (settings === undefined) return []
  let raw: unknown
  try {
    raw = settings.get('tty')
  } catch {
    return []
  }
  if (typeof raw !== 'object' || raw === null) return []
  const keys = (raw as { hostKeys?: unknown }).hostKeys
  return sanitizeHostKeys(keys) ?? []
}

/** 把一个配置目标解析成可连接的规格（连接簿查找在此完成）。 */
export function resolveTarget(target: DockerTarget, books: Map<string, SshSpec>): { resolved?: ResolvedTarget; error?: string } {
  if (target.kind === 'local') return { resolved: { name: target.name, kind: 'local' } }
  if (target.book !== undefined && target.book !== '') {
    const spec = books.get(target.book)
    if (spec === undefined) {
      /*
       * 指引必须指向**用户真能做的动作**。旧文案说"请在 tty 终端面板的设置卡片里添加"——
       * 但那张卡片管的是 tty 自己的连接簿条目，改不了 docker 目标引用的名字：用户照着找
       * 只会扑空（实测：目标引用 HS-248、连接簿里只有 HS_248_ADMIN，进 tty 卡片什么也改不了）。
       * 真正要改的字段是**本卡片这条目标的「连接簿」下拉**，所以先把这里说清楚，再说备选。
       *
       * 末句是给「只能经跳板机 / 代理命令访问」那类情况留的出口（项目级 ROADMAP 第 2 项）：
       * tty 的 ~/.ssh/config 导入会**自动带上 ProxyJump**、但**永不带上 ProxyCommand**，所以
       * 后者的条目要么不存在、要么存在却没配代理命令——用户看到「条目不存在」时的第一反应
       * 是「我明明配过」。
       */
      return { error: `目标「${target.name}」引用的连接簿条目不存在：${target.book}（在本卡片这条目标的「连接簿」下拉里改选一个已有条目；或把 tty 终端面板的连接簿补一个同名条目；也可清空下拉改为手填 host/username。若该主机在 ~/.ssh/config 里只配了 ProxyCommand，导入会跳过它——那种条目要在 tty 连接簿里手动建，并打开「允许 ProxyCommand」，见项目级 ROADMAP 第 2 项）` }
    }
    return { resolved: { name: target.name, kind: 'ssh', spec } }
  }
  const host = target.host ?? ''
  const username = target.username ?? ''
  if (host === '' || username === '') {
    return { error: `目标「${target.name}」缺少 SSH 信息：需要 book（连接簿条目名）或 host + username` }
  }
  const spec: SshSpec = {
    host,
    port: target.port ?? 22,
    username,
    auth: target.auth ?? 'agent',
    keyPath: target.keyPath ?? '',
    password: target.password ?? '',
    passphrase: target.passphrase ?? '',
    agentForward: target.agentForward === true,
  }
  return { resolved: { name: target.name, kind: 'ssh', spec } }
}

/* ------------------------------------------------------------------ *
 * 宿主服务的最小类型面（避免把 DSH 内部类型写进本包）
 * ------------------------------------------------------------------ */

/** 只读其它插件 entry 的 settings（旧 `settings.get(ns)` 的替代）。 */
interface SettingsLookup {
  get(ns: string): unknown
}

interface SettingsFormsLike {
  describe(): Array<{ ns: string; value?: Record<string, unknown>; revision?: number }>
  update(ns: string, patch: Record<string, unknown>, expectedRevision?: number): Promise<void>
}

interface ToolsLike {
  register(definition: unknown): () => void
}

interface WebServerLike {
  register(route: unknown): () => void
}

interface SystemPromptLike {
  section(options: { name: string; order?: number; text: string }): () => void
}

/* ------------------------------------------------------------------ *
 * 插件
 * ------------------------------------------------------------------ */

const plugin = definePlugin<Config>({
  name: 'docker',
  apply(ctx: Context, rawConfig?: Config) {
    /*
     * 授权来源必须在**第一次 capabilityGranted 之前**绑定（下面的 normalizeConfig 就会查它）：
     * 环境变量那一半取宿主的启动快照，就地提权那一半取带外授权存储。详见 kit 的 capability.ts /
     * grant-store.ts。存储每次 apply 新建一个实例 —— 这就是「宿主重启后重新读盘」的语义。
     *
     * 落点全部来自 kit 的 `capabilityPaths`（`<DSH home>/dsh-kit/`）：路径只在那里拼一次，
     * 插件不再自己 join（kit D08：平铺在 DSH 主目录的 `capability-grants.json` / `grant-confirm/`
     * 不带归属，容易与官方或别的插件撞名）。
     */
    const paths = capabilityPaths(dshHome())
    // **共享实例**（kit D11）：docker 与 tty 同装时各 new 一个会各自缓存一份文件快照，
    // 后绑定的那个看不到另一个后来写进去的授权（实测：tty 授权成功后自己的快照仍是 false）
    const grantStore = sharedGrantStore(paths.dir)
    bindCapabilitySources(ctx, grantStore)
    /*
     * 启动期审计：盘上已有的带外授权是**持久**的（重启后直接生效、不再有任何一次确认），所以那次
     * 「静默继承」必须在日志里留下痕迹——否则「三周前授权的能力今天一开机就开着」无可追溯（kit D09）。
     * 只报本插件的两条能力；环境变量通道由启动环境本身表达，不在这里重复。
     *
     * 刻意放在 `enabled` 判定**之前**：授权是宿主级的、与插件这次是否启用无关；插件这次是禁用态时
     * 反而更该说一句（「盘上有授权，但插件没开」与「点了没反应」是两回事）。
     */
    auditLoadedGrants(
      grantStore,
      [CAP_MUTATIONS.env, CAP_EXEC.env],
      '[dsh-docker]',
    )
    // volatile 字段解析后是 `{ get() }` 引用，先还原成纯数据（见 @hyzyn/dsh-kit 的 plainConfig）。
    const config = plainConfig((rawConfig ?? {}) as Config)
    /*
     * 配置里**写着的**能力开关值（**没和授权折叠**）。
     *
     * 为什么必须单独留一份：`live.allowMutations` 是「配置值 && 已授权」折叠后的**有效值**，一旦
     * 用户在没授权时打开过开关，它就成了 false——此后「重算」再拿它当输入，永远回不到 true
     * （授权到了、工具却不注册，就是那个半个状态）。重算必须从**配置值**出发：
     *   - `applySection` 把这一份塞回合并结果里（见那里的注释）；
     *   - 快照里的 `*Configured` 字段也用它，界面靠它把开关画成「开着但未生效」。
     *
     * （D141/D142：折叠后的有效值当输入 = 授权到了也回不来；快照缺配置值/来源 = 界面说不出
     * 「配置开着但没授权」。）
     */
    let configuredCapabilities = {
      allowMutations: config.allowMutations === true,
      allowExec: config.allowExec === true,
    }
    let live = normalizeConfig(config as Record<string, unknown>)
    if (!live.enabled) return

    const logger: ExecLogger = {
      info: (msg) => ctx.logger.info(msg),
      warn: (msg) => ctx.logger.warn(msg),
    }

    /*
     * 诊断历史（批三）：把「一次诊断」变成时间序列，回答「它在慢慢变坏吗」。
     *
     * **为什么历史不是新工具 / 新路由**：它不是新的采集面，只是同一份 diagnosis 的第二种视图。
     * `docker_logs` 与 `docker_logs_grep` 之所以拆成两条，是因为预算模型不同（前者「返回 = 收到」、
     * 后者「扫得多、返回少」）；这里预算完全相同，多拆一条只会让模型多试一次。
     *
     * **写盘失败绝不能让诊断失败**：历史是辅助信息，读不到只是没有趋势，而诊断本身仍然有价值。
     * 所以整段 catch 住、记一行日志、回空历史（`recorded: false`）——「加了个新功能，结果老功能
     * 因为磁盘满了不能用了」是本仓最不能接受的那类回归。
     *
     * 落点只在 `diagnosisHistoryPaths()` 里拼一次（见 history-store.ts 文件头）；store 构造**不碰磁盘**。
     */
    const historyStore = new DiagnosisHistoryStore(diagnosisHistoryPaths(dshHome()).dir)
    const HISTORY_DEFAULT = 10
    const HISTORY_LIMIT_MAX = 50
    /** `history` 参数：非有限数回落默认、越界夹紧——与 `tail` / `logTail` 的既有风格一致（不报错）。 */
    const clampHistoryCount = (value: unknown): number => {
      if (typeof value !== 'number' || !Number.isFinite(value)) return HISTORY_DEFAULT
      return Math.min(Math.max(Math.trunc(value), 0), HISTORY_LIMIT_MAX)
    }
    /**
     * 采集 → 压缩成样本 → 落盘（受去重窗口约束）→ 读回最近 N 条 → 趋势。
     *
     * 索引键用**容器名**（`target + container`）：改名会开一段新历史。这是可见的行为变化，
     * 但比「改名后把两个容器的历史混在一起」好——混起来会让趋势说出根本没发生过的变化。
     */
    const diagnoseWithHistory = async (
      api: DockerApi,
      target: string,
      id: string,
      options: { logTail?: unknown; since?: unknown; history?: unknown },
    ): Promise<{ diagnosis: Diagnosis; history: DiagnosisHistoryView }> => {
      const since = typeof options.since === 'string' && options.since.trim() !== '' ? assertSince(options.since) : undefined
      const result = await api.diagnose(id, {
        ...(typeof options.logTail === 'number' ? { logTail: options.logTail } : {}),
        ...(since === undefined ? {} : { since }),
      })
      const diagnosis = result.diagnosis
      const limit = clampHistoryCount(options.history)
      const container = diagnosis.name === '' ? diagnosis.id : diagnosis.name
      let recorded = false
      try {
        recorded = historyStore.append({
          v: HISTORY_SCHEMA_VERSION,
          target,
          container,
          id: diagnosis.id,
          // 时钟在**这里**读（history.ts 是纯逻辑，时钟由调用方注入，同 diagnose.ts）
          sample: sampleFromDiagnosis(diagnosis, Date.now()),
        })
      } catch (error) {
        logger.warn(`[dsh-docker] 诊断历史写入失败（本次只回空历史）：${error instanceof Error ? error.message : String(error)}`)
        return { diagnosis, history: { samples: [], trend: historyTrend([]), recorded: false } }
      }
      let samples: DiagnosisSample[] = []
      // `history: 0` = 明确不要历史（但**仍然记录**：记录是默认行为，读不读是调用方的选择）
      if (limit > 0) {
        try {
          samples = historyStore.read(target, container).slice(-limit)
        } catch (error) {
          logger.warn(`[dsh-docker] 诊断历史读取失败（趋势本次不可用）：${error instanceof Error ? error.message : String(error)}`)
        }
      }
      return { diagnosis, history: { samples, trend: historyTrend(samples), recorded } }
    }

    /* ---------- 主机指纹（TOFU，本插件自持；tty 记录作种子） ---------- */

    let settingsScope: SettingsEntryScope | undefined
    let settingsForms: SettingsFormsLike | undefined
    /**
     * 只读他人 entry（如 tty 的连接簿）：旧 `settings.get(ns)` 在新宿主已不存在，
     * 改走 `settings.describe()` 的 entry 查找（kit 的 readSettingsEntry）。settings
     * 子上下文就绪前保持 undefined，调用方当空表处理——与旧行为一致。
     */
    let settingsApi: SettingsLookup | undefined
    const ttySeed = (): Map<string, string[]> => {
      const map = new Map<string, string[]>()
      for (const record of readTtyHostKeys(settingsApi)) map.set(`${record.host}:${String(record.port)}`, record.fingerprints)
      return map
    }
    const persistHostKeys = (records: HostKeyRecord[]): void => {
      const scope = settingsScope
      if (scope === undefined) return
      void Promise.resolve(scope.update({ hostKeys: records })).catch((error: unknown) => {
        console.warn('[dsh-docker] 主机密钥记录持久化失败: ' + (error instanceof Error ? error.message : String(error)))
      })
    }
    const hostKeyStore: HostKeyStore = {
      get(host, port) {
        // host 键统一 trim + 小写（D03）：tty 落盘时把 host 小写化，比较口径必须一致
        const key = host.trim().toLowerCase()
        const own = live.hostKeys.find((record) => record.host === key && record.port === port)
        if (own !== undefined && own.fingerprints.length > 0) return own.fingerprints
        // tty 已确认过的主机不再重复确认：种子命中即视为可信，并**整组**复制进本插件的
        // 记录（D03）——此前只认单数 fingerprint 字段，tty 0.19.0 改存 fingerprints[] 后
        // 种子恒为空，对 tty 钉扎过的主机会静默重新 TOFU（指纹变更不再拒绝）。
        const seeded = ttySeed().get(`${key}:${String(port)}`)
        if (seeded !== undefined && seeded.length > 0) {
          live.hostKeys = [...live.hostKeys, { host: key, port, fingerprints: [...seeded] }]
          persistHostKeys(live.hostKeys)
          return seeded
        }
        return own?.fingerprints
      },
      record(host, port, fingerprint) {
        const key = host.trim().toLowerCase()
        const existing = live.hostKeys.find((record) => record.host === key && record.port === port)
        if (existing !== undefined) {
          // 同一主机的第二把主机密钥（rsa + ed25519）：并入集合而不是覆盖（D03）
          if (!existing.fingerprints.includes(fingerprint)) {
            existing.fingerprints = [...existing.fingerprints, fingerprint]
            persistHostKeys(live.hostKeys)
          }
          return
        }
        const next = live.hostKeys.filter((record) => !(record.host === key && record.port === port))
        next.push({ host: key, port, fingerprints: [fingerprint] })
        live.hostKeys = next
        persistHostKeys(next)
      },
    }

    /*
     * ProxyCommand 闸门：**每次拨号现读** tty settings（回调只做一次对象属性读取，无 IO）。
     * 不缓存成布尔值：用户随时可能关掉它，缓存意味着「关了还能用」——这一档最不能出的错。
     * settingsApi 在 settings 子上下文就绪前是 undefined，那时恒 false（= 关，安全方向）。
     */
    const remote = new RemoteExec(logger, hostKeyStore, { proxyCommandAllowed: () => readTtyProxyCommandAllowed(settingsApi) })

    /**
     * 当前生效的 targets：**以 settings 解析值为准**。
     * 为什么不能只读内存里的 live：settings 解析是异步的（服务就绪后才读一次），存在一个
     * 窗口期内 live 仍是 composition 配置（targets 为空）。若此时 GET /config 被
     * 调用，卡片会拿到空目标列表，用户随后保存就把空数组写回 → 目标被清空。
     */
    const targetsNow = (): DockerTarget[] => {
      const scope = settingsScope
      if (scope !== undefined) {
        try {
          const resolved = scope.get()
          if (typeof resolved === 'object' && resolved !== null) {
            const fromScope = sanitizeTargets((resolved as Record<string, unknown>).targets)
            if (fromScope !== undefined) return fromScope
          }
        } catch {
          /* 回落到内存值 */
        }
      }
      return live.targets
    }

    /* ---------- 目标解析与 DockerApi ---------- */

    /** 目标名 → 解析结果（每次现算，连接簿热改立即生效）。 */
    const resolveByName = (name: string): { resolved?: ResolvedTarget; error?: string } => {
      const target = targetsNow().find((item) => item.name === name)
      if (target === undefined) {
        const names = targetsNow().map((item) => item.name).join('、')
        return { error: `未知目标：${name}${names === '' ? '（尚未配置任何目标）' : `（已配置：${names}）`}` }
      }
      return resolveTarget(target, readTtyBooks(settingsApi))
    }

    /**
     * 取某个目标上的 DockerApi（Runner 每次新建，连接由 RemoteExec 池化）。
     *
     * `signal`（D161）只有**跨目标聚合**会传：它把「这一格的预算到点了」串到该目标
     * **底层每一条命令**上（`createRunner` 绑到 Runner 上，见那边的注释）。其余调用点
     * 不传，行为与之前完全一致。
     */
    const apiFor = (name: string, signal?: AbortSignal): { api?: DockerApi; resolved?: ResolvedTarget; error?: string } => {
      const { resolved, error } = resolveByName(name)
      if (resolved === undefined) return { error }
      try {
        const runner = createRunner({ target: resolved, remote, logger, ...(signal === undefined ? {} : { signal }) })
        return { api: new DockerApi(runner, live.dockerBin, { timeoutMs: 30_000, maxBytes: live.maxOutputKb * 1024 }), resolved }
      } catch (error_) {
        return { error: error_ instanceof Error ? error_.message : String(error_) }
      }
    }

    /** 单目标省略 target 参数时的默认目标。 */
    const defaultTargetName = (): string | undefined => {
      const list = targetsNow()
      return list.length === 1 ? list[0]?.name : undefined
    }

    /** 解析工具/路由里的 target 参数。 */
    const pickTarget = (input: unknown): { name?: string; error?: string } => {
      if (typeof input === 'string' && input.trim() !== '') {
        const name = input.trim()
        // `*` 聚合只有 docker_ps / docker_attention 支持（D46）：到这里说明是单目标
        // 工具传了 `*`——给专门文案，而不是一句「未知目标：*」
        if (name === '*') return { error: '`*`（全部目标）只有 docker_ps / docker_attention 支持；请传具体目标名（docker_targets 列出）' }
        return { name }
      }
      // 类型不对（数字 / 数组 / 对象）必须报错（D34）：静默回落到默认目标会让
      // 破坏性操作打错主机的最后一道防线失效
      if (input !== undefined && input !== null && typeof input !== 'string') {
        return { error: 'target 必须是字符串（目标名见 docker_targets）' }
      }
      const fallback = defaultTargetName()
      if (fallback !== undefined) return { name: fallback }
      const list = targetsNow()
      if (list.length === 0) return { error: '尚未配置任何 Docker 目标：可调 docker_connect_local 一键加上本机目标，或到 插件配置 → Docker 容器面板 添加' }
      return { error: 'target 必填（已配置多个目标：' + list.map((item) => item.name).join('、') + '）' }
    }

    /* ---------- 一键连接本机（面板按钮 / HTTP 路由 / agent 工具共用这一份实现） ---------- */

    /**
     * 探测失败 → 给用户的一句话（这次探测的 bin 以**配置里的 `dockerBin`** 为准）。
     *
     * 只有「CLI 缺失」这一档才去 PATH 里找候选：那要 accessSync 若干次，其余档位全是
     * 纯文本判断，不该无谓地跑文件系统。
     */
    const localProbeReason = (raw: string, timedOut = false): string => {
      const alternative = isLocalCliMissing(raw) ? findAlternativeLocalCli(live.dockerBin)[0] : undefined
      return describeLocalProbeFailure(raw, live.dockerBin, {
        timedOut,
        ...(alternative === undefined ? {} : { alternativeCli: alternative }),
      })
    }

    /**
     * 显式加一个本机目标并选中它，然后把只读探测结果一并回报。
     *
     * 四条不变量（缺任何一条都会变成另一种东西）：
     *   - **幂等**：已有 `kind=local` 就复用它（`created:false`），绝不重复创建；重复点、并发点都落到同一条。
     *   - **不改别人的**：SSH / 自定义目标原样保留，`targets` 顺序也只追加（`[...existing, 新建]`）——
     *     不排序、不重写已存在的条目（重写会丢掉 `mergeTargetSecrets` 才补得回的密码）。
     *   - **没有隐式默认目标**：只有本函数被显式调用才动 `targets`；空数组 / `clearTargets` 的既有语义一字不改。
     *   - **落盘成功才算数**：settings 不可用或保存失败一律**明确报错且不改内存配置**（no-op），
     *     绝不出现「界面显示已加上了、刷新就没了」。
     *
     * 权限：这条路径只写**本插件自己的配置**（加一个指向宿主自身的本机目标）+ 只读探测，
     * 与服务端 root 等价的那两档能力（`allowMutations` / `exec`）无关，因此不要求任何授权；
     * 也绝不自动装 Docker、起 daemon、切 docker context 或改 env。
     */
    const connectLocalOnce = async (): Promise<
      { ok: true; result: ConnectLocalResult } | { ok: false; code: number; error: string }
    > => {
      if (!live.enabled) return { ok: false, code: 403, error: 'Docker 插件已禁用' }
      const existing = targetsNow()
      const found = findLocalTargetName(existing)
      // Reusing an existing local target only probes it; it does not need a settings write.
      if (found === undefined && settingsScope === undefined) {
        return { ok: false, code: 503, error: '设置存储不可用（宿主未提供 settings 服务），无法保存本机目标；请稍后重试' }
      }
      const name = found ?? nextLocalTargetName(existing.map((item) => item.name))
      if (name === undefined) {
        return { ok: false, code: 400, error: `本机目标名冲突：已有 1000 个 local* 目标，请先删掉一些再试` }
      }
      let created = false
      if (found === undefined) {
        /* 新条目只写展示名与 kind：其余字段交给 normalizeConfig / sanitizeTargets 的默认值（单一来源）。 */
        const scope = settingsScope!
        let entry: { value?: Record<string, unknown>; revision?: number } | undefined
        try {
          entry = settingsForms?.describe().find((item) => item.ns === scope.ns)
        } catch {
          return { ok: false, code: 503, error: '无法读取当前目标配置，请稍后重试' }
        }
        if (entry === undefined) return { ok: false, code: 503, error: '当前设置条目不可用，请稍后重试' }
        const rawTargets = entry.value?.targets
        const nextTargets = [...(Array.isArray(rawTargets) ? rawTargets : existing), { name, kind: 'local' as const }]
        try {
          await settingsForms!.update(scope.ns, { targets: nextTargets }, entry.revision)
        } catch (error) {
          return { ok: false, code: 500, error: '保存本机目标失败：' + (error instanceof Error ? error.message : String(error)) }
        }
        created = true
        /*
         * `scope.update` 之后必须自己应用一次：真实 loader 会发 `loader/volatile-update` 触发
         * applySection，但那个事件是**异步**的，单测 / 老宿主还可能完全不发。这里同步应用是幂等的
         * （applySection 用同一份 settings 值再归一化一次），而**不应用**的后果是「刚加上的目标
         * 在探测那一步还解析不到」。
         */
        try {
          applySection({ targets: nextTargets })
        } catch (error) {
          return {
            ok: false,
            code: 500,
            error: '本机目标已保存但应用失败：' + (error instanceof Error ? error.message : String(error)),
          }
        }
      }
      // 探测失败一律降级为 message（见 ConnectLocalResult 的注释），不是这次操作的失败
      const built = apiFor(name)
      if (built.api === undefined) {
        return {
          ok: true,
          result: {
            name,
            kind: 'local',
            created,
            saved: true,
            reachable: false,
            message: `已${created ? '添加并选中' : '选中'}本机目标「${name}」，但无法构造执行通道：${built.error ?? '未知错误'}`,
          },
        }
      }
      let reachable = false
      let serverVersion: string | undefined
      let reason = ''
      try {
        const probe = await built.api.probe()
        reachable = probe.ok
        if (probe.serverVersion !== null) serverVersion = probe.serverVersion
        if (!probe.ok) reason = localProbeReason(probe.error ?? '', probe.timedOut)
      } catch (error) {
        reason = localProbeReason(error instanceof Error ? error.message : String(error))
      }
      const head = `已${created ? '添加并选中' : '选中'}本机目标「${name}」`
      return {
        ok: true,
        result: {
          name,
          kind: 'local',
          created,
          saved: true,
          reachable,
          ...(serverVersion === undefined ? {} : { serverVersion }),
          message: reachable
            ? `${head}：docker daemon 可达${serverVersion === undefined ? '' : `（${serverVersion}）`}`
            // 连接失败必须说清**为什么**：daemon 没起 / CLI 缺失 / socket 权限，而不是只报「没有容器」
            : `${head}，但本机 docker 不可用——${reason === '' ? 'docker version 未返回可用信息' : reason}`,
        },
      }
    }

    // Serialize this read-modify-write across HTTP and tool callers. Rejections never poison the queue.
    let localConnectQueue: Promise<unknown> = Promise.resolve()
    const connectLocal = (): ReturnType<typeof connectLocalOnce> => {
      const pending = localConnectQueue.then(connectLocalOnce)
      localConnectQueue = pending.catch(() => {})
      return pending
    }

    /**
     * 跨目标聚合（0.15.0）：所有目标的容器 / 需关注列表在面板与 agent 工具里共用同
     * 一套逻辑。三个必须的性质：
     *   - **并发上限**：ssh exec 扇出太多会互相挤（远端 sshd MaxStartups / 本机 fd）；
     *   - **单目标超时**：一台网络不通不能把整个聚合页拖住；
     *   - **错误隔离**：失败的组带上 error 照常返回，其余目标的结果照常可用。
     *
     * 第四个性质是 **D161 补上的**：单个目标超时的那一刻，**它底下正在跑的命令必须真的被
     * 停掉**。旧写法只 `Promise.race` 出一个 `ok:false`，底层那条 SSH channel 继续跑完——
     * 而它占着的正是 `MaxSessions` 的 session 槽（sshd 在子进程活着时不释放，见 D150）。
     */
    const AGG_CONCURRENCY = 4

    /**
     * 单目标上**每一条**命令的内层预算（30s，DockerApi 构造时传下去的那一个）。
     *
     * 单独取个名字是为了让「外层兜底」与「内层真相」共用一个来源：D161 之前这里是
     * `apiFor` 里的裸字面量 `30_000`，而外层是另一个裸字面量 `45_000`——两个数字各写各的，
     * 谁也不知道它们的关系，于是 45s 那个到底会不会打断一条健康命令，没人说得清。
     */
    const AGG_CMD_TIMEOUT_MS = 30_000

    /**
     * 单个目标那一格的**兜底**预算（D161）。
     *
     * 取舍（两种做法里选了后者）：
     *   - ①「把外层提到大于单目标最坏序列耗时」——`attention()` 是 `listContainers` +
     *     最多约 9 批 `inspect` 的**串行**序列（`ATTENTION_INSPECT_CAP 300 + 补捞 50`，
     *     每批 ≤ 40），最坏 10 × 30s ≈ 300s。真按这个上界设，总览页等一台卡住的机器要
     *     等五分钟，等于没有预算；
     *   - ②**内层超时是唯一真相源，外层只做兜底** ← 选这个。30s/命令已经给每条命令兜了底，
     *     外层存在的意义只是「内层没兜住时（连接获取 / 闸门排队 / 某个实现没遵守
     *     timeoutMs）别把整页拖死」。所以它取 3 倍单条预算（90s）：大于 `attention` 的
     *     典型两段（ps + 首批 inspect ≈ 60s），不会被健康命令序列撞上；又给异常留了一档
     *     天花板。到点即 `abort()`——**这是这次修复的实质**，配置数字只是顺带对齐。
     *
     * `DSH_DOCKER_AGG_TIMEOUT_MS` 可覆盖，**只为测试与排障**（同 `DSH_DOCKER_SHORT_CHANNELS`
     * 的口径）：90s 这条路径没法在单测里等，而「超时后底层有没有真的被取消」恰恰是本轮
     * 的验收点——没有这个口子就只能测到「返回了 ok:false」，那正是修复前就恒绿的那条。
     */
    function aggTimeoutMs(): number {
      const raw = Number(process.env.DSH_DOCKER_AGG_TIMEOUT_MS)
      return Number.isFinite(raw) && raw > 0 ? raw : AGG_CMD_TIMEOUT_MS * 3
    }

    async function mapLimit<T, R>(items: readonly T[], limit: number, run: (item: T, index: number) => Promise<R>): Promise<R[]> {
      const results = new Array<R>(items.length)
      let cursor = 0
      const workers = new Array(Math.min(Math.max(limit, 1), Math.max(items.length, 1))).fill(null).map(async () => {
        for (;;) {
          const index = cursor
          cursor += 1
          if (index >= items.length) return
          results[index] = await run(items[index] as T, index)
        }
      })
      await Promise.all(workers)
      return results
    }

    interface TargetGroup<T> {
      target: string
      label: string
      ok: boolean
      error?: string
      /** 该目标上聚合出来的数据（形状由调用方决定：容器数组 / 需关注数组）。 */
      data?: T
    }

    /** 在所有（或指定）目标上跑同一件事，返回按目标分组的「部分成功」结果。 */
    const aggregateAcrossTargets = async <T>(
      names: readonly string[],
      run: (api: DockerApi, name: string) => Promise<T>,
    ): Promise<Array<TargetGroup<T>>> => {
      return await mapLimit(names, AGG_CONCURRENCY, async (name): Promise<TargetGroup<T>> => {
        /*
         * 控制器必须建在 `run()` **之前**（D161）：Runner 是在 `apiFor` 里构造的，signal
         * 当场绑到 Runner 上（见 createRunner）。先跑再建的话，abort 时底层根本不知道
         * 自己被取消——那正是修复前的行为。
         */
        const controller = new AbortController()
        const budget = aggTimeoutMs()
        const built = apiFor(name, controller.signal)
        const resolved = built.resolved
        const label = resolved === undefined
          ? name
          : (resolved.kind === 'local' ? '本机' : sshTarget(resolved.spec as SshSpec))
        if (built.api === undefined) {
          controller.abort()
          return { target: name, label, ok: false, error: built.error ?? '无法构造执行通道' }
        }
        const api = built.api
        let timer: NodeJS.Timeout | null = null
        try {
          const timeout = new Promise<never>((_resolve, reject) => {
            timer = setTimeout(() => {
              /*
               * 顺序是**先取消、后拒绝**（D161）：反过来的话调用方在 reject 的那一刻就拿到
               * `ok:false` 返回了，而底层（本地子进程 / SSH channel）还在跑——用户看到的是
               * 「这一格失败了」，实际那条 inspect 还占着远端的 session 槽，后续短命令被拒。
               */
              controller.abort()
              reject(new Error(`聚合超时（>${String(budget / 1000)}s）`))
            }, budget)
            timer.unref?.()
          })
          const data = await Promise.race([run(api, name), timeout])
          return { target: name, label, ok: true, data }
        } catch (error) {
          return { target: name, label, ok: false, error: error instanceof Error ? error.message : String(error) }
        } finally {
          if (timer !== null) clearTimeout(timer)
          /*
           * race 另一侧赢（命令正常跑完 / 抛错）时也要兜底取消：`abort()` 是幂等的，命令
           * 已 settle 时它是**无害的空操作**（监听器在收尾时已摘掉），但漏了这一句就会留下
           * 「signal 永不 abort、挂在它上面的闭包链不放」的尾巴。
           */
          controller.abort()
        }
      })
    }

    /** 目标名列表：'*' / 空 表示全部（保持配置顺序）。 */
    const targetsFor = (input: unknown): string[] => {
      if (typeof input === 'string' && input.trim() !== '' && input.trim() !== '*') return [input.trim()]
      return targetsNow().map((item) => item.name)
    }

    /* ---------- 配置快照（凭证不外泄） ---------- */

    const snapshotTarget = (target: DockerTarget): Record<string, unknown> => ({
      name: target.name,
      kind: target.kind,
      book: target.book ?? '',
      host: target.host ?? '',
      port: target.port ?? 22,
      username: target.username ?? '',
      auth: target.auth ?? 'agent',
      keyPath: target.keyPath ?? '',
      agentForward: target.agentForward === true,
      // 密码 / 口令只回「是否已设置」，值永不回传浏览器
      passwordSet: typeof target.password === 'string' && target.password !== '',
      passphraseSet: typeof target.passphrase === 'string' && target.passphrase !== '',
    })

    const snapshot = (): Record<string, unknown> => {
      const books = readTtyBooks(settingsApi)
      return {
        enabled: live.enabled,
        announceToAgent: live.announceToAgent,
        dockerBin: live.dockerBin,
        allowMutations: live.allowMutations,
        allowExec: live.allowExec,
        /*
         * 配置里**写着的**值（未与授权折叠）：开关的视觉状态用它，有效值用上面那两个。
         * 两张都要给客户端，否则「配置开着但没授权」这个状态在界面上无法表达——那正是本仓最忌讳的
         * 「配了没反应」：开关看着是开的、什么都不会发生，却没有任何东西说明原因。
         */
        allowMutationsConfigured: configuredCapabilities.allowMutations,
        allowExecConfigured: configuredCapabilities.allowExec,
        // 宿主侧授权（只读）：客户端用它把开关渲染成「点不动 + 说明怎么开」
        allowMutationsGranted: capabilityGranted(CAP_MUTATIONS),
        allowExecGranted: capabilityGranted(CAP_EXEC),
        /*
         * 授权来源：'env' = 启动环境变量（界面不给「撤销」按钮，因为它只能靠改启动环境撤销）、
         * 'file' = 就地确认写下的带外授权（界面可撤销）、null = 没授权。
         * 客户端据此决定显示「撤销宿主授权」还是「去启动环境里去掉它」，两者完全不同。
         */
        allowMutationsGrantSource: capabilityGrantVia(CAP_MUTATIONS) ?? null,
        allowExecGrantSource: capabilityGrantVia(CAP_EXEC) ?? null,
        /*
         * 授权时刻（Unix 秒；只有 file 通道有值，环境变量通道与未授权都是 null）。授权是**持久**
         * 的：重启后它直接生效、不再确认，所以界面至少要能说出「它是什么时候来的」（D09）。
         */
        allowMutationsGrantedAt: capabilityGrantAt(CAP_MUTATIONS) ?? null,
        allowExecGrantedAt: capabilityGrantAt(CAP_EXEC) ?? null,
        execTimeoutSec: live.execTimeoutSec,
        pollIntervalSec: live.pollIntervalSec,
        logTailDefault: live.logTailDefault,
        maxOutputKb: live.maxOutputKb,
        targets: targetsNow().map(snapshotTarget),
        hostKeys: live.hostKeys,
        // 只读复用 tty 连接簿：卡片用它渲染「从连接簿选择」下拉
        ttyBooks: [...books.keys()],
        /*
         * 连接簿条目 → 解析后的 host:port（**只 name/host/port，凭据永不出宿主**）。
         *
         * 客户端「当前会话主机 ↔ 目标」的匹配要在**连接之前**就能判定：从连接簿打开的
         * SSH 标签，spec 里只有条目名；宿主回显的 `tab.target` 只在**连接成功**后才
         * 有值，而连不上（握手超时 / 主机没开机）恰恰是最需要面板的时候。少了这张表，
         * 面板只能判成「该主机没配目标」，然后沿用上一次选的目标——把另一台主机的容器
         * 显示出来。有了它，按主机配的目标（如目标绑 lab-a 条目、会话走
         * 192.0.2.10 条目）在连接失败时也能对上。
         */
        ttyBookHosts: [...books.entries()].map(([name, spec]) => ({ name, host: spec.host, port: spec.port })),
        ttyAvailable: books.size > 0,
        toolsRegistered: registeredNames,
        /*
         * SSE 帧协议版本（客户端据此决定「怎样才算已就绪」）。
         *
         * 2 = 四条流在**执行管道真的起来**时先发一帧 `ready`（见 readyOnStart）。客户端半体
         * 与宿主半体同包同版本，正常不会错位；但开发档里「宿主进程还是旧代码（模块已在内存
         * 里）、浏览器却从磁盘读到新的 client.js」这种组合会让新客户端死等一帧永远不来的
         * `ready`，把界面钉在「正在连接事件流…」上（2026-10-11 用户在 test profile 上实测到）。
         * 所以把版本放在这里：客户端读到 <2 就退回旧判据（响应头就算连上），读到 2 才只认
         * `ready`。字段缺失（更老的宿主）由客户端按「发 ready」以外的规则兜底，见
         * client-src/index.js 的 hostSendsReadyFrame。
         *
         * 3 = `/logs/stream` 支持多容器单连接（`ids=` + 带 `id` 的分源帧 + source-end /
         * source-error）。为什么必须再升一版：聚合视图要据此决定「一条连接带全部容器」还是
         * 「每个容器各开一条 EventSource」——判定错了，新客户端会去解析老宿主永远不发的事件，
         * 而老客户端拿到多源帧也认不出 `id`（它只读 `d` / `e`，会把几个容器的行混成一本账）。
         * **≥2 的 ready 语义不变**，新增的是同一条流里的源维度。
         */
        streamProtocol: 3,
      }
    }

    /* ---------- 活跃 SSE 长流清点 ---------- */

    /**
     * 活跃的 SSE 长流句柄（日志 / 统计 / 拉取三条流共用）。流本身由 HTTP handler
     * 持有并自清理；这里登记一份，供插件禁用 / 配置热更新 / 卸载时统一收尾
     * （end + abort 执行器）。句柄是每个插件实例一份（不共享模块级集合），
     * 多实例挂载时不会互相误杀。
     */
    const activeStreams = new Set<{ end(): void }>()

    const closeAllStreams = (): void => {
      for (const stream of [...activeStreams]) {
        try {
          stream.end()
        } catch {
          /* 连接已断开 */
        }
      }
      activeStreams.clear()
    }

    /* ---------- 通用 SSE 长连接（三条流共用一份基建） ---------- */

    /**
     * 「执行管道真的起来了」→ 一帧 `ready`（配合 {@link StreamHandlers.onStart}）。
     *
     * 为什么必须有这一帧：SSE 的 `onopen` **只证明响应头到了**——`openSseStream` 是先把
     * 200 + `text/event-stream` flush 出去、再去起 `docker ...`。目标不可达 / SSH 正在
     * 重连时 `acquire()` 可能卡十几秒，浏览器却已经「连上」了；客户端据此把活动条点亮成
     * 绿色的「实时接收中（docker events）」，而那条流一个字都还没收到（2026-10-11 用户现场）。
     * 现在客户端的 `open` 只认这帧，响应头不再算数。
     */
    const readyOnStart = (sendEvent: (event: string, data: unknown) => void): (() => void) => () => sendEvent('ready', {})

    /**
     * 通用 SSE 长连接。日志流（`docker logs -f`）、统计流（`docker stats`）、
     * 拉取流（`docker pull`）三者只差「执行器 + 结束原因 + end 附加字段」，
     * 其余全部共用这一份实现：
     *
     *   - 响应头（text/event-stream / no-cache / keep-alive / x-accel-buffering）
     *     统一在这里写，写完立即 flushHeaders（宿主 gzip 对 SSE 显式跳过）；
     *   - 每 15s 一帧 `: ping` 注释心跳（SSE 规范里客户端忽略）；
     *   - 活跃流登记：插件禁用 / 配置热更新 / 卸载时由 closeAllStreams 统一收尾；
     *   - 客户端断开 → 静默清理（不写任何帧）+ abort 执行器；
     *   - 执行器正常退出 → `end` 帧（带 reason / code / 附加字段）后关闭响应；
     *   - 执行器抛错 → `error` 帧后关闭响应。
     *
     * 调用方负责「参数校验」——校验失败时写常规 JSON（4xx）并直接返回，不建流。
     * 管道起来后要发的那帧 `ready` 见 {@link readyOnStart}（由调用方挂在 `onStart` 上）。
     */
    const openSseStream = async (
      res: ResLike,
      options: {
        /** `end` 帧的 reason（执行器自然退出时发）。 */
        reason: string
        /** 执行器：sendEvent 发帧，signal 中止；resolve 得到 docker 退出码。 */
        run: (sendEvent: (event: string, data: unknown) => void, signal: AbortSignal) => Promise<number | null>
        /** `end` 帧的附加字段（如 ref / ids）。 */
        endData?: (code: number | null) => Record<string, unknown>
        /**
         * 背压队列溢出时的策略（D153，见下）：`'end'`（默认）补一条 end 收尾；
         * `'drop'` 丢最旧的整帧、保留最新并推一条 `skip` 通知——
         * 日志 / 拉取这类**文本尾部流**用它（丢的是本来就会被客户端环形缓冲丢掉的历史）。
         */
        overflow?: 'end' | 'drop'
      },
    ): Promise<void> => {
      const write = res.write?.bind(res)
      const flushHeaders = res.flushHeaders?.bind(res)
      if (write === undefined || flushHeaders === undefined) {
        writeJson(res, 500, { error: '宿主响应不支持 SSE 长连接' })
        return
      }

      res.writeHead(200, {
        'content-type': 'text/event-stream; charset=utf-8',
        'cache-control': 'no-cache',
        connection: 'keep-alive',
        'referrer-policy': 'no-referrer',
        // 反代（nginx 等）默认缓冲响应体：不关掉的话流要等缓冲区满才到浏览器
        'x-accel-buffering': 'no',
      })
      flushHeaders()

      const controller = new AbortController()
      let done = false
      let heartbeat: NodeJS.Timeout | null = null

      /*
       * 背压（D04）：write() 返回 false = socket 写缓冲越过高水位。**注意 Node 的语义**：
       * 返回 false 时数据**已经被收下**（只是缓冲满了，等 drain），所以这里不能把它再排一次
       * 队列——老代码 `writeFrame` 把 false 当失败、随后又 push 进队列，drain 时会重写同一帧
       * （客户端收到重复日志行、pendingBytes 也虚高）。现在的契约：写一次就是写一次，false
       * 只表示「先别再直写」，等 drain 继续。
       *
       * 队列上限仍是每条流 ≤ MAX_PENDING_BYTES（宿主内存有界）。**溢出怎么办**由调用方选：
       *   - `overflow: 'end'`（默认，结构化流）：补一条 `end{reason:'output-limit'}` 收尾，
       *     客户端重连（少一帧事件语义上比缺一个事件好）；
       *   - `overflow: 'drop'`（日志 / 拉取这类**文本尾部流**，D153）：丢掉最旧的整帧、只留
       *     最新的，并推一条 `skip` 帧告诉客户端「中间断了一截」。丢掉的这些行本来也会被
       *     客户端的环形缓冲（5000 行 / 4MB）丢掉——为它们把整条流掐掉，代价远大于收益
       *     （用户现场：话痨容器一冲，面板就变成「连接中断 + 空白正文」在重连里打转）。
       */
      const MAX_PENDING_BYTES = 8 * 1024 * 1024
      /** 溢出后丢到这个水位为止：一次多丢一点，给 drain 留出喘息空间。 */
      const DROP_TARGET_BYTES = MAX_PENDING_BYTES / 2
      const overflow = options.overflow ?? 'end'
      let pendingFrames: string[] = []
      let pendingBytes = 0
      /** 高水位标记：true 时新帧一律进队列，等 drain 再续写。 */
      let waitingDrain = false
      /** 已被丢掉的帧数与字节数（尚未告知客户端）；skip 通知发出后清零。 */
      let droppedFrames = 0
      let droppedBytes = 0
      let skipQueued = false

      const isSkipFrame = (frame: string): boolean => frame.startsWith('event: skip\n')

      const stopHeartbeat = (): void => {
        if (heartbeat === null) return
        clearInterval(heartbeat)
        heartbeat = null
      }
      /** 客户端断开 / 写失败：静默清理（不写帧），中止执行器。 */
      const clientGone = (): void => {
        if (done) return
        done = true
        stopHeartbeat()
        pendingFrames = []
        pendingBytes = 0
        activeStreams.delete(handle)
        controller.abort()
      }
      /** 服务端主动收尾（正常结束 / 出错 / 插件禁用 / 卸载）：关响应。 */
      const finish = (): void => {
        if (done) return
        done = true
        stopHeartbeat()
        activeStreams.delete(handle)
        controller.abort()
        /*
         * 收尾前把没写完的帧交给 res.end 落地（D83）：直接清空队列会把已经入队、还没进
         * socket 的帧（含 end / error 帧）一起丢掉。客户端凭「连接关了但没有 end 帧」
         * 判定异常 → EventSource 自动重连 → **拉取流会把 docker pull 再跑一遍**。
         * 队列本身有 8MB 上限，这里一次 append 不会放大内存。
         */
        const tail = pendingFrames.join('')
        pendingFrames = []
        pendingBytes = 0
        try {
          res.end(tail === '' ? undefined : tail)
        } catch {
          /* 连接已断开 */
        }
      }
      /**
       * 写一帧。
       * @returns `'ok'` 直写完成（可继续直写）｜`'pressure'` 已写入但越过高水位（等 drain）
       *   ｜`'gone'` 连接已断（已走 clientGone）
       */
      const tryWrite = (frame: string): 'ok' | 'pressure' | 'gone' => {
        try {
          const result = write(frame)
          if (isSkipFrame(frame)) {
            // skip 通知真的落到 socket 了：这一轮的丢弃账目清零，下次再丢再报一次
            droppedFrames = 0
            droppedBytes = 0
            skipQueued = false
          }
          return result === false ? 'pressure' : 'ok'
        } catch {
          // 写失败 = 连接已断：与 res close 同一收尾路径
          clientGone()
          return 'gone'
        }
      }
      /**
       * 溢出策略 `'drop'`：丢最旧的整帧保留最新，并保证队列里恰有一条 `skip` 通知。
       * `skip` 帧自己**永不参与丢弃**——它是「这里断了一截」的唯一凭据。
       */
      const dropOldestFrames = (): void => {
        while (pendingBytes > DROP_TARGET_BYTES && pendingFrames.length > 0) {
          const index = pendingFrames.findIndex((frame) => !isSkipFrame(frame))
          if (index === -1) break
          const [frame] = pendingFrames.splice(index, 1)
          pendingBytes -= frame.length
          droppedFrames += 1
          droppedBytes += frame.length
        }
        if (droppedFrames > 0 && !skipQueued) {
          const notice = sseFrame('skip', { frames: droppedFrames, bytes: droppedBytes })
          pendingFrames.push(notice)
          pendingBytes += notice.length
          skipQueued = true
          return
        }
        /*
         * 队列里已有一条 skip 还没写到 socket，而这期间**又发生了丢弃**：原地更新那条
         * skip 的账目（D156）。旧实现只把首次丢弃的数排进队，之后（skip 落地前）再发生
         * 的丢弃虽然记了账，却在 skip 真正写出时被清零一起吞掉——客户端看到的第一段
         * 缺口永远偏小，第二段缺口则完全不可见。skip 还在队列里，改它正合适；账目清零
         * 仍由 `tryWrite` 在它真正写出去时做，时序不变。
         */
        if (droppedFrames > 0) {
          const notice = sseFrame('skip', { frames: droppedFrames, bytes: droppedBytes })
          const index = pendingFrames.findIndex((frame) => isSkipFrame(frame))
          if (index !== -1) {
            pendingBytes += notice.length - (pendingFrames[index] as string).length
            pendingFrames[index] = notice
          } else {
            // 防御：skipQueued 为 true 却找不到帧（不该发生）——退回「新排一条」
            pendingFrames.push(notice)
            pendingBytes += notice.length
          }
        }
      }
      /** drain 后续写暂存的帧；中途再遇高水位就停手等下一次 drain。 */
      const flushPending = (): void => {
        while (!done && pendingFrames.length > 0) {
          const frame = pendingFrames[0] as string
          const result = tryWrite(frame)
          if (result === 'gone') return
          pendingBytes -= frame.length
          pendingFrames.shift()
          if (result === 'pressure') {
            waitingDrain = true
            return
          }
        }
        waitingDrain = false
      }
      const send = (frame: string): void => {
        if (done) return
        if (!waitingDrain && pendingFrames.length === 0) {
          const result = tryWrite(frame)
          // 已写入（含「越过高水位」这一种）：**不许再排一遍**，否则 drain 时会重写
          if (result === 'pressure') waitingDrain = true
          return
        }
        pendingFrames.push(frame)
        pendingBytes += frame.length
        if (pendingBytes > MAX_PENDING_BYTES) {
          if (overflow === 'drop') {
            dropOldestFrames()
            return
          }
          /*
           * 队列溢出 = 客户端消费速度跟不上产出（D133）：收尾前补一条 end，
           * 让客户端知道「是主机侧积压」而不是把它当成正常结束。静默 res.end()
           * 会被 EventSource 判为流正常结束并自动重连——而自动重连复用带 tail
           * 的 URL，服务端就会把历史整段重推一遍（重复回填）。
           */
          pendingFrames.push(sseFrame('end', { reason: 'output-limit', code: null }))
          finish()
        }
      }
      const sendEvent = (event: string, data: unknown): void => send(sseFrame(event, data))

      const handle = { end: finish }
      activeStreams.add(handle)
      res.on?.('close', clientGone)
      res.on?.('drain', flushPending)

      heartbeat = setInterval(() => send(': ping\n\n'), SSE_HEARTBEAT_MS)
      heartbeat.unref?.()

      try {
        const code = await options.run(sendEvent, controller.signal)
        if (done) return
        sendEvent('end', { reason: options.reason, code, ...(options.endData?.(code) ?? {}) })
        finish()
      } catch (error) {
        if (done) return
        sendEvent('error', { message: error instanceof Error ? error.message : String(error) })
        finish()
      }
    }

    /* ---------- 配置热应用 ---------- */

    /**
     * 逐字段比较目标列表（含凭证）：凭证变了，已开的流按旧凭据在跑，也要收尾。
     * **顺序无关**（D108）：面板上重排一次目标不该被当成「目标变了」而收流 —— 那会把
     * 在途的 docker pull 一起 abort 掉（正是 D09 要消除的「一次白拉」）。
     */
    const sameTargets = (a: DockerTarget[], b: DockerTarget[]): boolean => {
      if (a.length !== b.length) return false
      const byName = new Map(b.map((item) => [item.name, item]))
      return a.every((item) => {
        const other = byName.get(item.name)
        if (other === undefined) return false
        return item.kind === other.kind
          && item.book === other.book
          && item.host === other.host
          && item.port === other.port
          && item.username === other.username
          && item.auth === other.auth
          && item.keyPath === other.keyPath
          && item.password === other.password
          && item.passphrase === other.passphrase
          && item.agentForward === other.agentForward
      })
    }

    const applySection = (section: Record<string, unknown>, options?: { forceRefreshTools?: boolean }): void => {
      const before = live
      // 能力开关的**配置值**单独记（D141）：section 里没提到它就保持原样（`{}` = 只重算、不改配置）
      if (section.allowMutations !== undefined) configuredCapabilities.allowMutations = section.allowMutations === true
      if (section.allowExec !== undefined) configuredCapabilities.allowExec = section.allowExec === true
      // hostKeys 只在显式传入时覆盖（避免把 TOFU 运行期新增的记录冲掉）
      // 能力两项用**配置值**覆盖折叠后的 live：否则重算的输入就是折叠后的 false（见 configuredCapabilities）
      const merged: Record<string, unknown> = { ...live, ...section, ...configuredCapabilities }
      if (section.hostKeys === undefined) merged.hostKeys = live.hostKeys
      live = normalizeConfig(merged)
      /*
       * 执行通道相关的键**变了**才收流（D09）：TOFU 落盘会走到这里（hostKeys 变化、
       * 其余不变），此前无差别 closeAllStreams 会把刚开的日志 FOLLOW 掐断、把在途的
       * docker pull abort 掉——一次白拉。浏览器侧 EventSource 虽会自动重连，但拉取
       * 不会自己重来。
       */
      // 能力开关被**撤销**时也必须收流（D84）：在途的 /images/pull/stream 是写操作，
      // 关掉「允许变更操作」就该立刻停手（旧代码无条件收流，D09 收窄条件时漏了这条）。
      const mutationsRevoked = before.allowMutations && !live.allowMutations
      if (before.enabled !== live.enabled || before.dockerBin !== live.dockerBin || !sameTargets(before.targets, live.targets) || mutationsRevoked) {
        closeAllStreams()
      }
      // 工具注册面受启用态 / 能力开关 / **目标列表**影响；dockerBin 不改变工具清单但影响执行，
      // 一起重注册是幂等的，保守带上。forceRefreshTools 给「保存路径」用：上一次注册
      // 可能只成功了一部分，重存同一份配置也要能重试（D107）。
      // 目标列表必须算进来：零目标时只注册两条空态工具（见 ZERO_TARGET_TOOLS），配好目标后
      // 不在这里补注册，就得等重启——那正是「配了目标、工具却没有」的那个半吊子状态。
      if (options?.forceRefreshTools === true
        || before.enabled !== live.enabled
        || before.dockerBin !== live.dockerBin
        || before.allowMutations !== live.allowMutations
        || before.allowExec !== live.allowExec
        || !sameTargets(before.targets, live.targets)) {
        refreshTools()
      }
      if (before.enabled !== live.enabled || before.announceToAgent !== live.announceToAgent) {
        refreshAnnouncement()
      }
      console.log(`[dsh-docker] config applied (enabled=${String(live.enabled)}, bin=${live.dockerBin}, targets=${String(live.targets.length)}, allowMutations=${String(live.allowMutations)}, allowExec=${String(live.allowExec)})`)
    }

    /*
     * 就地提权（见 kit 的 elevation.ts）：页内点开关 → 在宿主上落地一个随机名确认文件 → 授权。
     *
     * `onGrantChange` 是这一整段里**最容易漏、也最要紧**的一下：授权到达与撤销都必须重算 live。
     *   - 授权侧：配置开关可能**早就**是 true（用户先打开过、当时没授权，于是 live.allowMutations
     *     被折叠成 false），授权到了却不重算，症状就是「开关亮着、工具却没注册」；
     *   - 撤销侧：不重算会留下「记录没了、工具还开着」，还要收掉在途的写流（D84）。
     * `applySection({})` 用当前 live 兜底再归一化一次即可（normalizeConfig 会重新问 capabilityGranted）。
     */
    const elevation = createElevationManager({
      confirmDir: paths.confirmDir,
      store: grantStore,
      logger,
      logPrefix: '[dsh-docker]',
      onGrantChange: () => {
        applySection({}, { forceRefreshTools: true })
      },
    })
    ctx.effect(() => {
      return () => {
        elevation.dispose()
      }
    }, 'dsh-docker: elevation cleanup')

    /* ---------- agent 工具 ---------- */

    let toolsApi: ToolsLike | undefined
    let toolDisposers: Array<() => void> = []
    let registeredNames: string[] = []

    /*
     * `docker_targets` 的一行。**render 与 execute 共用这一份形状**：两处各写一遍时，
     * 加字段只改到一侧——render 读不到（或 schema 漏声明，被宿主 `additionalProperties: false`
     * 挡掉整条结果）。D170 的 `book` 就是这么加上来的，所以先把它抽成类型。
     */
    type ToolTargetRow = {
      name: string
      kind: string
      label: string
      /**
       * SSH 目标引用的 tty 连接簿条目名（D170）。**仅当配置里真的引用了条目才出现**：
       * 内联 host/username 的目标没有名字可报，不能凭空编一个；本机目标同样没有。
       */
      book?: string
      ok?: boolean
      error?: string
      serverVersion?: string
    }

    const renderTargets = (rows: ToolTargetRow[]): string => {
      if (rows.length === 0) return '尚未配置任何 Docker 目标（插件配置 → Docker 容器面板 → 目标）。'
      return 'Docker 目标：' + rows.map((row) => {
        const state = row.ok === undefined ? '' : row.ok ? ' [可达]' : ` [不可用：${row.error ?? '未知'}]`
        const version = row.serverVersion === undefined ? '' : ` docker ${row.serverVersion}`
        // 连接簿条目名紧跟在 `user@host` 之后：它就是「同一台主机在 tty 那边叫什么」（D170）
        const book = row.book === undefined ? '' : `（连接簿 ${row.book}）`
        return `\n- ${row.name} (${row.kind}) ${row.label}${book}${version}${state}`
      }).join('')
    }

    /**
     * 容器行 → 一行文本。入参是**工具 schema 的扁平形状**（不是领域类型 `ContainerSummary`）：
     * `ports` 已经是拼好的字符串、id 在 `id` 上、可省字段用 `undefined` 表示「无」。
     *
     * 这里踩过一次：渲染器按领域类型写（`row.ports.map(...)` / `row.shortId` /
     * `row.health === null`），而工具返回的是扁平形状——于是 `ports.map is not a function`
     * 直接崩、`id=undefined`。render 的入参是 `unknown` + 一个不受检查的 `as` 断言，
     * 所以 tsc 抓不到。现在两侧共用下面这些 Tool*Row 类型，形状一变就编译报错。
     */
    const renderPsRow = (row: ToolPsRow): string => {
      const ports = row.ports === undefined || row.ports === '' ? '' : ' ports=' + row.ports
      const health = row.health === undefined ? '' : ` health=${row.health}`
      const compose = row.composeProject === undefined ? '' : ` compose=${row.composeProject}/${row.composeService ?? '-'}`
      return `\n- ${row.name} [${row.state}]${health} image=${row.image}${ports}${compose} id=${row.id}`
    }

    /** 跨目标容器渲染：按目标分组，失败的目标单独一行说明（部分成功也要可读）。 */
    const renderAggregatedContainers = (
      groups: Array<{ target: string; label: string; ok: boolean; error?: string; containers?: ToolPsRow[]; total?: number; truncated?: boolean }>,
      args?: unknown,
    ): string => {
      if (groups.length === 0) return '尚未配置任何 Docker 目标（插件配置 → Docker 容器面板）。'
      // 「共 N 个容器」要说总数而不是本页条数：分页后两者不是一回事，混用会把一页当全部
      const total = groups.reduce((sum, group) => sum + (group.total ?? group.containers?.length ?? 0), 0)
      const failed = groups.filter((group) => !group.ok)
      const head = `所有目标共 ${String(total)} 个容器（${String(groups.length)} 个目标${failed.length > 0 ? `，${String(failed.length)} 个不可达` : ''}）：`
      return head + groups.map((group) => {
        if (!group.ok) return `\n\n■ ${group.target}（${group.label}）— 不可用：${group.error ?? '未知错误'}`
        const rows = group.containers ?? []
        /*
         * 空页的两种成因同样要分开（与单目标的 `emptyListText` 同口径）：offset 翻过头时
         * 若照抄「— 0 个容器」，模型会当成「这台主机上没有容器」——正是 D12/D42 那类假阴性。
         */
        if (rows.length === 0 && (group.total ?? 0) > 0) {
          return `\n\n■ ${group.target}（${group.label}）— 本页没有条目（共 ${String(group.total)} 个，offset 已越过末页，改用更小的 offset 重试）`
        }
        // 每组的截断信号单独给（组数不变、组内切页）：某台主机还有下一页时要说出来
        const note = pagingNote(listPage(args, group.total, group.truncated === true), rows.length)
        return `\n\n■ ${group.target}（${group.label}）— ${String(rows.length)} 个容器${note}` + rows.map(renderPsRow).join('')
      }).join('')
    }

    const ATTENTION_LABEL: Record<string, string> = {
      unhealthy: '不健康',
      restarting: '反复重启',
      oom: '被 OOM 杀',
      'exit-nonzero': '非零退出',
      dead: '僵死',
    }

    /** 需关注列表渲染（单目标 / 跨目标共用）。入参同样是**工具扁平形状**，不是 AttentionItem。 */
    const renderAttention = (
      groups: Array<{ target: string; label: string; ok: boolean; error?: string; items?: ToolAttentionRow[]; total?: number; truncated?: boolean; degraded?: boolean }>,
    ): string => {
      // 零目标不是「一切正常」（D53）：排障入口给出假阴性比报错更糟——与 docker_ps
      // 的「尚未配置任何 Docker 目标」兜底同款
      if (groups.length === 0) return '尚未配置任何 Docker 目标（插件配置 → Docker 容器面板）。'
      const total = groups.reduce((sum, group) => sum + (group.items?.length ?? 0), 0)
      if (total === 0 && groups.every((group) => group.ok)) return '所有目标上没有需要关注的容器（无 unhealthy / 反复重启 / OOM / 非零退出 / 僵死）。'
      return `需关注容器共 ${String(total)} 个：` + groups.map((group) => {
        if (!group.ok) return `\n\n■ ${group.target}（${group.label}）— 不可用：${group.error ?? '未知错误'}`
        const items = group.items ?? []
        if (items.length === 0) return `\n\n■ ${group.target}（${group.label}）— 无异常`
        // 降级信号的措辞要覆盖全部三种成因（D42/D85）：inspect 整体失败、候选超出检查预算、
        // 补捞预算被吃满 —— 都是「权威字段按摘要口径」，而不是单纯的 inspect 失败
        const warn = group.degraded === true ? '（部分条目未取到权威详情：inspect 失败或候选超出检查预算，OOM / 重启次数等按摘要口径）' : ''
        // 截断信号（D12）：名额按严重度排序后切，超出的不静默
        const cut = group.truncated === true && group.total !== undefined && group.total > items.length
          ? `（该目标实际共 ${String(group.total)} 条，已按严重度截断为 ${String(items.length)} 条，可传更大的 limit）`
          : ''
        const notes = [warn, cut].filter((part) => part !== '').join(' ')
        return `\n\n■ ${group.target}（${group.label}）${notes === '' ? '' : '\n' + notes}` + items.map((item) => {
          const reasons = item.reasons.map((reason) => ATTENTION_LABEL[reason] ?? reason).join(' + ')
          const extra = [
            item.exitCode === undefined ? '' : `exit=${String(item.exitCode)}`,
            item.restartCount === undefined ? '' : `restarts=${String(item.restartCount)}`,
            item.oomKilled ? 'OOMKilled=true' : '',
          ].filter((part) => part !== '').join(' ')
          const health = item.health === undefined ? '' : '/' + item.health
          return `\n- ${item.name} [${item.state}${health}] ${reasons} image=${item.image}${extra === '' ? '' : ' ' + extra} id=${item.id}`
        }).join('')
      }).join('')
    }

    const renderContainers = (target: string, rows: ToolPsRow[], page?: ListPage): string => {
      if (rows.length === 0) return emptyListText('容器', target, page)
      return listHead('容器', target, page, rows.length) + rows.map(renderPsRow).join('') + pagingNote(page, rows.length)
    }

    const renderStats = (target: string, rows: ToolStatRow[]): string => {
      if (rows.length === 0) return `目标 ${target}：没有运行中的容器。`
      return `目标 ${target} 的资源占用：` + rows.map((row) => `\n- ${row.name} cpu=${row.cpuPercent === undefined ? '?' : String(row.cpuPercent) + '%'} mem=${row.memUsage} (${row.memPercent === undefined ? '?' : String(row.memPercent) + '%'}) net=${row.netIO} block=${row.blockIO} pids=${row.pids === undefined ? '?' : String(row.pids)}`).join('')
    }

    const renderEvents = (target: string, since: string, rows: ToolEventRow[]): string => {
      if (rows.length === 0) return `目标 ${target}：最近 ${since} 没有容器事件。`
      return `目标 ${target} 的容器事件（最近 ${since}，${String(rows.length)} 条）：` + rows.map((row) => {
        const at = row.time === undefined ? '--:--:--' : formatEventTime(row.time)
        const exit = row.exitCode === undefined ? '' : ` exit=${String(row.exitCode)}`
        const compose = row.composeProject === undefined ? '' : ` compose=${row.composeProject}`
        return `\n- ${at} ${row.name} ${row.action}${exit}${compose} image=${row.image}`
      }).join('')
    }

    /*
     * 进程快照的渲染：表头 + 行。0 行时给一句「容器内没有进程」——注意 top 在容器没在
     * 运行时是**抛错**的（docker 就是这么答的），所以走到这里 0 行只能是 docker 没打印
     * 任何进程行（极少数运行时）；空列表本身不是错误。
     */
    const renderTop = (target: string, row: ToolTopRow): string => {
      const head = `容器 ${row.name === '' ? row.id : row.name}（id=${row.id}，目标 ${target}）的进程`
      const rows = row.processes ?? []
      if (rows.length === 0) return `${head}：容器内没有进程（容器可能未运行）。`
      const body = rows.map((proc) => {
        const cell = (value: string | undefined): string => String(value ?? '')
        return `\n${cell(proc.pid).padStart(7)} ${cell(proc.ppid).padStart(7)} ${cell(proc.user).padEnd(8)} ${cell(proc.stat).padEnd(4)} ${cell(proc.elapsed).padStart(10)} ${cell(proc.cpu).padStart(5)} ${cell(proc.mem).padStart(5)} ${cell(proc.command)}`
      }).join('')
      const cut = row.truncated ? '\n（进程数超过上限已截断：要全量请在容器内跑 ps）' : ''
      return `${head}（${String(rows.length)} 个${row.truncated ? '，已截断' : ''}）：\n     PID    PPID USER     STAT    ELAPSED  CPU%  MEM% COMMAND${body}${cut}`
    }

    /*
     * 诊断的渲染：**只给结论**，不把 80 行日志灌进模型上下文（契约 §2）。
     * 返回值里仍然带着 `logTail` 全量、`evidence` 全字段与 `timeline`，模型要细看可以
     * 自己读；这里只显示 verdict + findings + 建议 + 日志行数（外加三路降级的提示，
     * 那是「结论可不可信」的一部分，不能藏）。
     */
    /**
     * 历史压成**一行**（不逐条铺样本）：模型要的是「它在变坏吗」的结论，不是 10 行时间戳。
     *
     * 时间只保留到分钟（`2026-11-03 07:12`）：秒对趋势判断没有意义，却会把这一行撑长两倍。
     */
    const historyLine = (history: ToolDiagnosisHistory | undefined): string => {
      if (history === undefined || history.samples.length === 0) return ''
      const trend = history.trend
      const from = history.samples[0]?.at ?? ''
      const to = history.samples[history.samples.length - 1]?.at ?? ''
      const short = (iso: string): string => iso.replace('T', ' ').slice(0, 16)
      const window = from === '' || to === '' ? '' : `（最早 ${short(from)} → 最近 ${short(to)}）`
      const note = history.recorded ? '' : '；本次与上一条重复，未追加'
      return `\n历史 ${String(trend.count)} 次${window}：${trend.verdict.summary}${note}`
    }

    const renderDiagnosis = (target: string, row: ToolDiagnosisRow): string => {
      const verdict = row.verdict ?? { severity: '?', code: '?', summary: '' }
      // 标题里用短 id（与 docker_inspect 的 shortId 口径一致）：全量 64 位在返回值里，不占正文
      const shortId = row.id.length > 12 ? row.id.slice(0, 12) : row.id
      const head = `容器 ${row.name === '' ? shortId : row.name}（id=${shortId}，目标 ${target}）诊断结论：**[${verdict.severity}] ${verdict.summary}**（${verdict.code}）`
      const findings = (row.findings ?? []).length === 0
        ? '\n判据：没有命中任何问题判据。'
        : `\n判据（${String(row.findings.length)} 条）：` + row.findings.map((finding) => `\n- [${finding.severity}] ${finding.title}：${finding.detail}`).join('')
      const suggestions = (row.suggestions ?? []).length === 0
        ? ''
        : '\n建议：' + row.suggestions.map((item) => `\n- ${item}`).join('')
      const evidence = row.evidence ?? {}
      const logLines = evidence.logLines === undefined ? '未取到' : `${String(evidence.logLines)} 行`
      const errorLines = evidence.errorLines === undefined ? '未取到' : `${String(evidence.errorLines)} 行`
      const foot = `\n日志：抓取 ${logLines}（疑似报错 ${errorLines}），时间线 ${String((row.timeline ?? []).length)} 条；证据全字段与日志原文在返回值里（要更多日志 / 找关键词用 docker_logs_grep）。`
      return head + findings + suggestions + historyLine(row.history) + foot
    }

    /*
     * 磁盘占用：四行汇总 + 可回收最多的镜像（前 10）+ 一句判据。
     *
     * 「可回收」只算 `containers === 0` 的镜像——镜像的「独占大小」只有在没有容器使用时
     * 才真的能回收；还在用的镜像删了会牵连容器。这句话必须写出来，否则模型看到一张
     * 「大镜像」表就建议用户 `image prune`。
     */
    const renderDiskUsage = (target: string, row: ToolDiskRow): string => {
      const lines = [`目标 ${target} 的磁盘占用（docker system df）：`]
      for (const item of row.summary ?? []) {
        lines.push(`- ${item.type}：${String(item.totalCount)} 个（活跃 ${String(item.active)}）占用 ${item.size}，可回收 ${item.reclaimable}`)
      }
      if (row.degraded) {
        lines.push(`\n明细未取到：${row.degradedReason ?? '未知原因'}（汇总仍可用）`)
        return lines.join('\n')
      }
      const unused = (row.images ?? []).filter((image) => image.containers === 0).slice(0, 10)
      const used = (row.images ?? []).filter((image) => image.containers > 0).length
      lines.push('\n可回收最多的镜像（独占大小降序，只列没有被任何容器使用的）：')
      if (unused.length === 0) {
        lines.push(`- （没有未被使用的镜像；还有 ${String(used)} 个镜像在用）`)
      } else {
        lines.push(unused.map((image) => `- ${image.repository === '' ? image.id : `${image.repository}:${image.tag}`} 独占 ${image.uniqueSize}（大小 ${image.size}）`).join('\n'))
      }
      lines.push('\n删之前先看 `containers` 是不是 0：0 才是没人用，>0 的镜像删了会牵连容器。')
      if (row.truncated.images || row.truncated.volumes || row.truncated.buildCache) {
        lines.push(`明细已截断（镜像 ${String(row.images.length)}/${String(row.totals.images)}、卷 ${String(row.volumes.length)}/${String(row.totals.volumes)}、构建缓存 ${String(row.buildCache.length)}/${String(row.totals.buildCache)}）；面板的磁盘页可看全量。`)
      }
      return lines.join('\n')
    }

    /*
     * 等价 docker run：命令用**围栏块**原样给出（可直接复制），后面才列提醒。
     *
     * 为什么不折行或加省略：这条命令的全部价值就是「能复制粘贴后跑起来」，
     * 任何为了排版做的改动都会让它变成一条错的命令。
     */
    const renderRunCommand = (target: string, row: ToolRunCommandRow): string => {
      const head = `容器 ${row.name}（id=${row.id.slice(0, 12)}，目标 ${target}）的等价 docker run——**只生成命令，没有执行任何操作**：`
      const body = '```sh\n' + (row.command === '' ? '（命令生成失败）' : row.command) + '\n```'
      const warnings = (row.warnings ?? []).length === 0
        ? ''
        : '\n提醒：' + row.warnings.map((item) => `\n- ${item}`).join('')
      const secrets = (row.secretKeys ?? []).length === 0
        ? ''
        : `\n可能含凭证的环境变量键：${row.secretKeys.join('、')}（命令里是原值，贴出去前先确认）`
      const omitted = (row.omitted ?? []).length === 0
        ? ''
        : '\n故意没还原（需要你手动补）：' + row.omitted.map((item) => `\n- ${item}`).join('')
      return `${head}\n${body}${warnings}${secrets}${omitted}`
    }

    const renderDetail = (detail: ContainerDetail): string => {
      const lines = [
        `容器 ${detail.name}（${detail.shortId}）`,
        `- 状态：${detail.state}${detail.health === null ? '' : ' / ' + detail.health}${detail.status === '' ? '' : '（' + detail.status + '）'}`,
        `- 镜像：${detail.image}`,
        `- 启动：${detail.startedAt ?? '—'}  结束：${detail.finishedAt ?? '—'}`,
        `- 退出码：${detail.exitCode === null ? '—' : String(detail.exitCode)}  重启次数：${detail.restartCount === null ? '—' : String(detail.restartCount)}  重启策略：${detail.restartPolicy ?? '—'}`,
        `- 端口：${detail.ports.length === 0 ? '—' : detail.ports.map((p) => (p.hostPort === undefined ? `${String(p.containerPort)}/${p.protocol}` : `${p.hostIp ?? ''}:${String(p.hostPort)}→${String(p.containerPort)}/${p.protocol}`)).join(', ')}`,
        `- 挂载：${detail.mounts.length === 0 ? '—' : detail.mounts.map((m) => `${m.source}→${m.destination}${m.readWrite ? '' : '(ro)'}`).join(', ')}`,
        `- 网络：${detail.networks.length === 0 ? '—' : detail.networks.map((n) => `${n.name}${n.ip === null ? '' : '(' + n.ip + ')'}`).join(', ')}`,
        `- 命令：${detail.entrypoint}${detail.command === '' ? '' : ' ' + detail.command}`,
      ]
      if (detail.healthLogTail !== null) lines.push(`- 最近健康检查：${detail.healthLogTail}`)
      return lines.join('\n')
    }

    const renderNetworks = (target: string, rows: ToolNetworkRow[], page?: ListPage): string => {
      if (rows.length === 0) return emptyListText('网络', target, page)
      return listHead('网络', target, page, rows.length) + rows.map((row) => {
        const internal = row.internal === true ? ' internal=true' : ''
        return `\n- ${row.name} driver=${row.driver} scope=${row.scope}${internal} id=${row.id}`
      }).join('') + pagingNote(page, rows.length)
    }

    const renderVolumes = (target: string, rows: ToolVolumeRow[], page?: ListPage): string => {
      if (rows.length === 0) return emptyListText('卷', target, page)
      return listHead('卷', target, page, rows.length) + rows.map((row) => {
        const mount = row.mountpoint === undefined || row.mountpoint === '' ? '' : ` mount=${row.mountpoint}`
        return `\n- ${row.name} driver=${row.driver} scope=${row.scope}${mount}`
      }).join('') + pagingNote(page, rows.length)
    }

    const renderImages = (target: string, rows: ToolImageRow[], page?: ListPage): string => {
      if (rows.length === 0) return emptyListText('镜像', target, page)
      return listHead('镜像', target, page, rows.length) + rows.map((row) => {
        const created = row.createdSince === undefined || row.createdSince === '' ? '' : ' (' + row.createdSince + ')'
        return `\n- ${row.reference} ${row.sizeText}${created} id=${row.id}`
      }).join('') + pagingNote(page, rows.length)
    }

    /** 镜像详情 + 构建历史（agent 工具 docker_image_inspect 的可读渲染）。 */
    const renderImageDetail = (payload: { detail: ImageDetail; history: ImageHistoryEntry[]; historyError: string | null }): string => {
      const d = payload.detail
      const title = d.repoTags.length === 0 ? `<none>（${d.shortId}）` : d.repoTags.join(', ')
      const lines = [
        `镜像 ${title}`,
        `- ID：${d.id}`,
        `- 大小：${d.size === null ? '—' : formatBytes(d.size)}${d.virtualSize === null || d.virtualSize === d.size ? '' : `（含父层 ${formatBytes(d.virtualSize)}）`}`,
        `- 创建：${d.created === '' ? '—' : d.created}`,
        `- 平台：${d.os === '' && d.architecture === '' ? '—' : `${d.os}/${d.architecture}`}`,
        `- 层：${String(d.layerCount)} 层`,
        `- 入口：${(d.entrypoint + ' ' + d.command).trim() || '—'}`,
        ...(d.exposedPorts.length === 0 ? [] : [`- 暴露端口：${d.exposedPorts.join(', ')}`]),
        ...(d.repoDigests.length === 0 ? [] : [`- digest：${d.repoDigests.join(', ')}`]),
      ]
      if (payload.historyError !== null) lines.push(`- 构建历史：读取失败（${payload.historyError}）`)
      else if (payload.history.length === 0) lines.push('- 构建历史：无')
      else {
        lines.push(`- 构建历史（${String(payload.history.length)} 步，从新到旧）：`)
        for (const step of payload.history.slice(0, 30)) {
          lines.push(`  · ${step.shortId} ${step.createdSince} ${step.sizeText} ${step.createdBy.slice(0, 160)}`)
        }
        if (payload.history.length > 30) lines.push(`  …（其余 ${String(payload.history.length - 30)} 步略）`)
      }
      return lines.join('\n')
    }

    /** 重新注册 agent 工具（能力开关变化时调用；幂等）。 */
    const refreshTools = (): void => {
      for (const dispose of toolDisposers) {
        try {
          dispose()
        } catch {
          /* 工具已注销 */
        }
      }
      toolDisposers = []
      registeredNames = []
      const tools = toolsApi
      if (tools === undefined) return
      // 插件禁用（设置卡片关掉「启用插件」）时不注册任何工具：运行期关掉也要立刻生效
      if (!live.enabled) return
      // 文案要跟语义一致（D46）：`*` 聚合只有 docker_ps / docker_attention 真支持，
      // 其余 12 个单目标工具省略时只在「恰好一个目标」时回落、多目标则报 target 必填
      const targetParam = { type: 'string', description: '目标名（docker_targets 列出；只有一个目标时可省略。`*` 仅 docker_ps / docker_attention 支持，其他工具请传具体目标名）' } as const

      /*
       * 单个工具注册失败不该把整批带下去（D107）：以前 add 直接抛，调用方（applySection）
       * 也就抛了，结果是「旧工具已全拆 + 新工具只注册了一半」，而重存同一份配置又因为
       * 差异判定不再触发 refreshTools —— 半套状态一直缺到重启。现在逐条兜住并汇总，
       * 下次配置变更（或保存路径的 forceRefreshTools）会自然重试。
       */
      const failures: string[] = []
      const add = (toolName: string, definition: unknown): void => {
        /*
         * 零目标闸（见 ZERO_TARGET_TOOLS）：其余工具没有可寻址的目标，注册了只会让模型
         * 白试一次；放在 add 里过滤，是为了保住注册顺序、失败汇总与 registeredNames 的
         * 实况语义（它们仍然是「这次真正注册了什么」的如实记录）。
         */
        if (live.targets.length === 0 && !ZERO_TARGET_TOOLS.has(toolName)) return
        try {
          toolDisposers.push(tools.register(definition))
          registeredNames.push(toolName)
        } catch (error) {
          failures.push(`${toolName}: ${error instanceof Error ? error.message : String(error)}`)
        }
      }

      add('docker_targets', defineTool({
        name: 'docker_targets',
        // 只读工具：与同轮其它工具并发执行（宿主默认把未声明的工具当独占，见项目级 ROADMAP 第 4 项）
        isConcurrencySafe: () => true,
        description: '列出已配置的 Docker 目标（本机 / SSH 主机），可选探测每个目标的 docker daemon 是否可达；SSH 目标会带出它引用的 tty 连接簿条目名（book，可直接用于 sftp_* 的 book）。其他 docker_* 工具的 target 参数取自这里。',
        parameters: { probe: { type: 'boolean', description: 'true 时逐个探测 docker 版本与 daemon 可达性（SSH 目标会建连接，较慢）' } },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              targets: {
                type: 'array',
                required: true,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    name: { type: 'string', required: true },
                    kind: { type: 'string', required: true },
                    label: { type: 'string', required: true },
                    // D170：目标引用的 tty 连接簿条目名（内联 host/username 的目标没有这个字段）
                    book: { type: 'string' },
                    ok: { type: 'boolean' },
                    error: { type: 'string' },
                    serverVersion: { type: 'string' },
                  },
                },
              },
            },
          },
          render: (_args: unknown, value: unknown) => {
            const rows = (value as { targets?: ToolTargetRow[] }).targets ?? []
            return [{ type: 'text', text: renderTargets(rows) }]
          },
        },
        async execute(args: unknown): Promise<{ targets: ToolTargetRow[] }> {
          const input = (args ?? {}) as { probe?: unknown }
          const books = readTtyBooks(settingsApi)
          const rows: ToolTargetRow[] = []
          for (const target of targetsNow()) {
            /*
             * `book` 只在目标**真的引用了连接簿条目**时带出（D170）：`resolveTarget` 内部靠它
             * 查表，但工具输出里从来没有它——于是模型手里只剩 `user@host`，而 tty / sftp_* 认的
             * 是**条目名**。两边不同名时（目标名 `host-a`、条目名 `KB_JUMP_01` 这种）猜不出来，
             * 只能赌一次，赌错就是「连接簿中不存在」。本机目标与内联字段目标一律不带。
             */
            const book = target.book ?? ''
            const bookField = target.kind === 'ssh' && book !== '' ? { book } : {}
            const { resolved, error } = resolveTarget(target, books)
            if (resolved === undefined) {
              rows.push({ name: target.name, kind: target.kind, label: '解析失败', ...bookField, ok: false, error: error ?? '未知错误' })
              continue
            }
            const label = resolved.kind === 'local' ? '本机' : sshTarget(resolved.spec as SshSpec)
            if (input.probe !== true) {
              rows.push({ name: target.name, kind: target.kind, label, ...bookField })
              continue
            }
            const { api } = apiFor(target.name)
            if (api === undefined) {
              rows.push({ name: target.name, kind: target.kind, label, ...bookField, ok: false, error: '无法构造执行通道' })
              continue
            }
            const probe = await api.probe()
            // serverVersion 随 probe 回传（D48）：README 承诺「探测 docker 版本」，
            // probe() 本来就返回了它，只是这里被丢掉了
            rows.push({
              name: target.name,
              kind: target.kind,
              label,
              ...bookField,
              ok: probe.ok,
              ...(probe.ok ? { ...(probe.serverVersion === null ? {} : { serverVersion: probe.serverVersion }) } : { error: probe.error ?? '未知错误' }),
            })
          }
          return { targets: rows }
        },
      }))

      add('docker_connect_local', defineTool({
        name: 'docker_connect_local',
        // 只读之外的唯一副作用是**写本插件自己的配置**，没有别的写路径；并发调用被 connectLocal 的幂等语义收敛
        isConcurrencySafe: () => true,
        description: '添加或复用本机 Docker 目标并探测 daemon，返回目标名、是否新建和连接状态及失败原因。保留已有 SSH 配置；不启动或安装 Docker，不改变 context 或能力授权。随后将返回的 name 作为 docker_ps 等工具的 target。',
        parameters: {},
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              name: { type: 'string', required: true },
              kind: { type: 'string', required: true },
              created: { type: 'boolean', required: true },
              saved: { type: 'boolean', required: true },
              reachable: { type: 'boolean', required: true },
              message: { type: 'string', required: true },
              serverVersion: { type: 'string' },
            },
          },
          render: (_args: unknown, value: unknown) => {
            const row = value as ConnectLocalResult
            return [{
              type: 'text',
              text: `${row.message}\n后续查询请传 target: ${JSON.stringify(row.name)}`,
            }]
          },
        },
        async execute(): Promise<ConnectLocalResult> {
          const outcome = await connectLocal()
          if (!outcome.ok) throw new Error(outcome.error)
          return outcome.result
        },
      }))

      add('docker_ps', defineTool({
        name: 'docker_ps',
        // 只读工具：与同轮其它工具并发执行（宿主默认把未声明的工具当独占，见项目级 ROADMAP 第 4 项）
        isConcurrencySafe: () => true,
        description: '列出容器（默认只列运行中的；all:true 含已停止）。**target 传 `*` = 一次列出所有目标**（跨主机，按目标分组返回，单个目标不可达不影响其他目标）。排障第一步。注意：`ports` 为空**不等于**「没暴露端口」——host 网络容器的端口就是宿主机端口、ps 里没有映射，这种情况会给 `net` 字段（如 `net:"host"`），别为此再逐个 docker_inspect。',
        parameters: {
          target: { type: 'string', description: '目标名；传 `*` 或省略（仅一个目标时）表示当前目标/全部目标（docker_targets 列出）' },
          all: { type: 'boolean', description: 'true 时包含已停止容器（默认 false）' },
          limit: pageParams.limit,
          offset: pageParams.offset,
        },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string' },
              total: { type: 'number' },
              truncated: { type: 'boolean' },
              containers: {
                type: 'array',
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    id: { type: 'string', required: true },
                    name: { type: 'string', required: true },
                    image: { type: 'string', required: true },
                    state: { type: 'string', required: true },
                    status: { type: 'string', required: true },
                    health: { type: 'string' },
                    ports: { type: 'string' },
                    net: { type: 'string' },
                    composeProject: { type: 'string' },
                    composeService: { type: 'string' },
                  },
                },
              },
              groups: {
                type: 'array',
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    target: { type: 'string', required: true },
                    label: { type: 'string', required: true },
                    ok: { type: 'boolean', required: true },
                    error: { type: 'string' },
                    // 组内分页（T1）：组数不变、每组各自切，所以 total / truncated 也在组上
                    total: { type: 'number' },
                    truncated: { type: 'boolean' },
                    containers: {
                      type: 'array',
                      items: {
                        type: 'object',
                        additionalProperties: false,
                        properties: {
                          id: { type: 'string', required: true },
                          name: { type: 'string', required: true },
                          image: { type: 'string', required: true },
                          state: { type: 'string', required: true },
                          status: { type: 'string', required: true },
                          health: { type: 'string' },
                          ports: { type: 'string' },
                          net: { type: 'string' },
                          composeProject: { type: 'string' },
                          composeService: { type: 'string' },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          render: (args: unknown, value: unknown) => {
            const v = value as {
              target?: string
              containers?: ToolPsRow[]
              total?: number
              truncated?: boolean
              groups?: Array<{ target: string; label: string; ok: boolean; error?: string; containers?: ToolPsRow[]; total?: number; truncated?: boolean }>
            }
            if (Array.isArray(v.groups)) return [{ type: 'text', text: renderAggregatedContainers(v.groups, args) }]
            return [{ type: 'text', text: renderContainers(v.target ?? '?', v.containers ?? [], listPage(args, v.total, v.truncated === true)) }]
          },
        },
        async execute(args: unknown): Promise<{
          target?: string
          containers?: ToolPsRow[]
          total?: number
          truncated?: boolean
          groups?: Array<{ target: string; label: string; ok: boolean; error?: string; containers?: ToolPsRow[]; total?: number; truncated?: boolean }>
        }> {
          const input = (args ?? {}) as { target?: unknown; all?: unknown; limit?: unknown; offset?: unknown }
          const window = pageWindow(input)
          const isAll = typeof input.target === 'string' && input.target.trim() === '*'
          const toRow = (row: ContainerSummary): ToolPsRow => ({
            // 短 ID（D47）：docker_attention 已是 shortId，同一字段跨工具宽度要一致
            //（ps 带 --no-trunc，完整 64 位既与 README 的「短 ID」矛盾也多烧 token）
            id: row.shortId,
            name: row.name,
            image: row.image,
            state: row.state,
            status: row.status,
            ...(row.health === null ? {} : { health: row.health }),
            ports: row.ports.map((p) => (p.hostPort === undefined ? `${String(p.containerPort)}/${p.protocol}` : `${String(p.hostPort)}→${String(p.containerPort)}/${p.protocol}`)).join(','),
            // 端口为空才补 net（D131）：host 网络容器的端口即宿主机端口、ps 没有映射，
            // 空 ports 与「没暴露端口」否则无法区分。有映射时不加，避免每行都变长。
            ...(row.ports.length === 0 && row.networks.length > 0 ? { net: row.networks.join(',') } : {}),
            ...(row.composeProject === null ? {} : { composeProject: row.composeProject }),
            ...(row.composeService === null ? {} : { composeService: row.composeService }),
          })
          if (isAll || (input.target === undefined && targetsNow().length > 1)) {
            const names = targetsFor('*')
            const collected = await aggregateAcrossTargets(names, (targetApi) => targetApi.listContainers(input.all === true))
            // 跨目标分页在**组内**切（T1）：组数与「哪些目标不可达」都保持不变，
            // 每组带自己的 total / truncated —— 否则一个目标 150 个容器会把别组挤没
            return {
              groups: collected.map((group) => {
                const paged = group.data === undefined ? undefined : paginate(group.data, window)
                return {
                  target: group.target,
                  label: group.label,
                  ok: group.ok,
                  ...(group.error === undefined ? {} : { error: group.error }),
                  ...(paged === undefined ? {} : {
                    containers: paged.rows.map(toRow),
                    total: paged.total,
                    truncated: paged.truncated,
                  }),
                }
              }),
            }
          }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          const containers = await api.listContainers(input.all === true)
          const paged = paginate(containers, window)
          return { target: picked.name, containers: paged.rows.map(toRow), total: paged.total, truncated: paged.truncated }
        },
      }))

      add('docker_attention', defineTool({
        name: 'docker_attention',
        // 只读工具：与同轮其它工具并发执行（宿主默认把未声明的工具当独占，见项目级 ROADMAP 第 4 项）
        isConcurrencySafe: () => true,
        description: '列出「需要关注」的容器：不健康（unhealthy）/ 反复重启 / 被 OOM 杀 / 非零退出 / 僵死。target 传 `*` 时**跨所有目标聚合**（单目标不可达不影响其他目标）。排障入口：不确定从哪台机器看起时先调它。',
        parameters: {
          target: { type: 'string', description: '目标名；传 `*` 表示全部目标（docker_targets 列出）' },
          limit: { type: 'number', description: '每个目标最多返回多少条（1~500，默认 100）' },
        },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string' },
              total: { type: 'number' },
              truncated: { type: 'boolean' },
              degraded: { type: 'boolean' },
              items: {
                type: 'array',
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    id: { type: 'string', required: true },
                    name: { type: 'string', required: true },
                    image: { type: 'string', required: true },
                    state: { type: 'string', required: true },
                    health: { type: 'string' },
                    reasons: { type: 'array', required: true, items: { type: 'string' } },
                    exitCode: { type: 'number' },
                    oomKilled: { type: 'boolean' },
                    restartCount: { type: 'number' },
                  },
                },
              },
              groups: {
                type: 'array',
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    target: { type: 'string', required: true },
                    label: { type: 'string', required: true },
                    ok: { type: 'boolean', required: true },
                    error: { type: 'string' },
                    total: { type: 'number' },
                    truncated: { type: 'boolean' },
                    degraded: { type: 'boolean' },
                    items: {
                      type: 'array',
                      items: {
                        type: 'object',
                        additionalProperties: false,
                        properties: {
                          id: { type: 'string', required: true },
                          name: { type: 'string', required: true },
                          image: { type: 'string', required: true },
                          state: { type: 'string', required: true },
                          health: { type: 'string' },
                          reasons: { type: 'array', required: true, items: { type: 'string' } },
                          exitCode: { type: 'number' },
                          oomKilled: { type: 'boolean' },
                          restartCount: { type: 'number' },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          render: (_args: unknown, value: unknown) => {
            const v = value as {
              target?: string
              items?: ToolAttentionRow[]
              total?: number
              truncated?: boolean
              degraded?: boolean
              groups?: Array<{ target: string; label: string; ok: boolean; error?: string; items?: ToolAttentionRow[]; total?: number; truncated?: boolean; degraded?: boolean }>
            }
            if (Array.isArray(v.groups)) return [{ type: 'text', text: renderAttention(v.groups) }]
            /*
             * 单目标分支也要把 total / truncated / degraded 带上（D100）：renderAttention 的
             * 「实际共 N 条、已截断」与「inspect 降级」两段提示读的就是这三个字段，漏传时
             * 最常用的单目标调用仍然静默截断 —— D12/D42 想消除的假阴性就还在。
             */
            return [{
              type: 'text',
              text: renderAttention([{
                target: v.target ?? '?',
                label: v.target ?? '?',
                ok: true,
                items: v.items ?? [],
                ...(v.total === undefined ? {} : { total: v.total }),
                ...(v.truncated === true ? { truncated: true } : {}),
                ...(v.degraded === true ? { degraded: true } : {}),
              }]),
            }]
          },
        },
        async execute(args: unknown): Promise<{
          target?: string
          total?: number
          truncated?: boolean
          degraded?: boolean
          items?: ToolAttentionRow[]
          groups?: Array<{ target: string; label: string; ok: boolean; error?: string; total?: number; truncated?: boolean; degraded?: boolean; items?: ToolAttentionRow[] }>
        }> {
          const input = (args ?? {}) as { target?: unknown; limit?: unknown }
          const limit = typeof input.limit === 'number' && Number.isInteger(input.limit) ? input.limit : undefined
          const toRow = (item: AttentionItem): ToolAttentionRow => ({
            id: item.shortId,
            name: item.name,
            image: item.image,
            state: item.state,
            ...(item.health === null ? {} : { health: item.health }),
            reasons: item.reasons,
            ...(item.exitCode === null ? {} : { exitCode: item.exitCode }),
            oomKilled: item.oomKilled,
            ...(item.restartCount === null ? {} : { restartCount: item.restartCount }),
          })
          const isAll = typeof input.target === 'string' && input.target.trim() === '*'
          if (isAll || (input.target === undefined && targetsNow().length > 1)) {
            const names = targetsFor('*')
            const collected = await aggregateAcrossTargets(names, (targetApi) => targetApi.attention(limit === undefined ? undefined : { limit }))
            return {
              groups: collected.map((group) => ({
                target: group.target,
                label: group.label,
                ok: group.ok,
                ...(group.error === undefined ? {} : { error: group.error }),
                ...(group.data === undefined ? {} : {
                  items: group.data.items.map(toRow),
                  total: group.data.total,
                  ...(group.data.truncated ? { truncated: true } : {}),
                  ...(group.data.degraded ? { degraded: true } : {}),
                }),
              })),
            }
          }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          const attention = await api.attention(limit === undefined ? undefined : { limit })
          return {
            target: picked.name,
            items: attention.items.map(toRow),
            total: attention.total,
            ...(attention.truncated ? { truncated: true } : {}),
            ...(attention.degraded ? { degraded: true } : {}),
          }
        },
      }))

      add('docker_inspect', defineTool({
        name: 'docker_inspect',
        // 只读工具：与同轮其它工具并发执行（宿主默认把未声明的工具当独占，见项目级 ROADMAP 第 4 项）
        isConcurrencySafe: () => true,
        description: '读取某个容器的权威详情（docker inspect）：状态/健康检查/退出码/重启次数/端口映射/挂载/网络/启动命令。',
        parameters: { target: targetParam, id: { type: 'string', required: true, description: '容器名或 ID（来自 docker_ps）' } },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string', required: true },
              detail: { type: 'string', required: true },
            },
          },
          render: (_args: unknown, value: unknown) => {
            const v = value as { detail?: string }
            return [{ type: 'text', text: v.detail ?? '' }]
          },
        },
        async execute(args: unknown): Promise<{ target: string; detail: string }> {
          const input = (args ?? {}) as { target?: unknown; id?: unknown }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          if (typeof input.id !== 'string') throw new Error('id 必填')
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          let details: ContainerDetail[]
          try {
            details = await api.inspect([input.id])
          } catch (error) {
            // 未命中时给候选（D132）：`No such object: rmqnamesrv` 只说明这个名字不存在，
            // 而 docker_ps 里可能就躺着 `607023340cbb_rmqnamesrv`（compose 建过的容器名）。
            // 只在失败路径多花一次 ps；候选查不到就静默——提示是锦上添花，不能变成新错误。
            let hint = ''
            try {
              const rows = await api.listContainers(true)
              const hits = suggestContainerNames(input.id, rows.map((row) => row.name))
              if (hits.length > 0) hint = `（是否想找：${hits.join('、')}？）`
            } catch {
              /* 候选获取失败不影响原错误 */
            }
            throw new Error((error instanceof Error ? error.message : String(error)) + hint)
          }
          const detail = details[0]
          if (detail === undefined) throw new Error(`容器不存在：${input.id}`)
          return { target: picked.name, detail: renderDetail(detail) }
        },
      }))

      add('docker_logs', defineTool({
        name: 'docker_logs',
        // 只读工具：与同轮其它工具并发执行（宿主默认把未声明的工具当独占，见项目级 ROADMAP 第 4 项）
        isConcurrencySafe: () => true,
        description: '读取某个容器的日志尾部（docker logs --tail）。默认行数取插件配置 logTailDefault（出厂 200）、不带时间戳；可加 timestamps / since / until。日志可能很大，优先用 tail 而不是全量。报错埋在更早的深处、或要看特定时间窗时改用 docker_logs_grep（服务端检索）。',
        parameters: {
          target: targetParam,
          id: { type: 'string', required: true, description: '容器名或 ID' },
          tail: { type: 'number', description: '尾部行数（1~5000，默认取配置 logTailDefault；越界值会被静默夹紧到边界）' },
          timestamps: { type: 'boolean', description: 'true 时每行带时间戳' },
          since: { type: 'string', description: '起始时间（docker --since 语法，如 10m、2026-09-09T10:00:00）' },
          until: { type: 'string', description: '结束时间（docker --until 语法，与 since 同一口径，如 2026-09-09T10:05:00；配 since 圈定时间窗）' },
        },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string', required: true },
              id: { type: 'string', required: true },
              text: { type: 'string', required: true },
              truncated: { type: 'boolean' },
            },
          },
          render: (_args: unknown, value: unknown) => {
            const v = value as { target?: string; id?: string; text?: string; truncated?: boolean }
            /*
             * 截断时要给出**下一步**（D105 的判据）：只说「已截断」等于告诉模型「没有别的办法」。
             * 三种可执行做法按代价排序：更小的 tail（最省）→ since/until 圈窗 → 换用
             * docker_logs_grep 到深处检索（它扫全历史、只有返回侧才截）。
             */
            const cut = v.truncated === true
              ? '（输出已截断，已丢弃最旧的行：可传更小的 `tail`、加 `since`/`until` 圈时间窗，或改用 `docker_logs_grep` 带 pattern 检索深处）'
              : ''
            const head = `容器 ${v.id ?? '?'}（目标 ${v.target ?? '?'}）日志${cut}：\n\n`
            return [{ type: 'text', text: head + (v.text === undefined || v.text === '' ? '(无日志)' : v.text) }]
          },
        },
        async execute(args: unknown): Promise<ToolLogRow> {
          const input = (args ?? {}) as { target?: unknown; id?: unknown; tail?: unknown; timestamps?: unknown; since?: unknown; until?: unknown }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          if (typeof input.id !== 'string') throw new Error('id 必填')
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          const result = await api.logs(input.id, {
            tail: typeof input.tail === 'number' && Number.isInteger(input.tail) ? input.tail : live.logTailDefault,
            timestamps: input.timestamps === true,
            // since 统一口径（D45）：与 docker_events 同一个 assertSince——此前 logs
            // 完全不校验，docker 的参数错误会变成一句不可读的报错。空/纯空白按「未传」处理（D98）：
            // 否则模型传个空串会拿到「since 必填」这种与事实相反的提示。
            ...(typeof input.since === 'string' && input.since.trim() !== '' ? { since: assertSince(input.since) } : {}),
            // until 与 since 同一口径（docker --until 语法一致），复用同一个校验函数
            ...(typeof input.until === 'string' && input.until.trim() !== '' ? { until: assertSince(input.until, 'until') } : {}),
          })
          return { target: picked.name, id: result.id, text: result.text, truncated: result.truncated }
        },
      }))

      add('docker_logs_grep', defineTool({
        name: 'docker_logs_grep',
        // 只读工具：与同轮其它工具并发执行（同 docker_logs）
        isConcurrencySafe: () => true,
        // 返回侧行上限只认 src/docker.ts 的 MAX_RESULT_LINES：描述里用插值，别再写字面量
        // （这里曾把上限写死在描述里，改常量时描述不跟着变；守卫见 test/result-limit-single-source.test.ts）
        description: `在容器日志里做**服务端检索**：扫全部历史（可用 since/until 圈时间窗），返回命中行及其前后 context 行。与 docker_logs 的分工：报错就在最近尾部 → docker_logs（更便宜）；埋在大量日志深处 / 找关键词、异常码、请求 ID / 特定时间段 → 本工具。默认字面子串匹配（grep -F 语义，零 ReDoS）；regexp=true 才按 JS 正则解释。返回如实报告 matched（总命中数，即使没返回）/ scanned（扫描行数）/ limited / truncated——「只扫到这些」与「扫完了没更多」是可区分的。返回行数另有上限（${String(MAX_RESULT_LINES)}）：超了截到上限并给 truncatedForSize 与 notes（缩小 limit / 减小 context / 加 since·until），matched 仍报全量。`,
        parameters: {
          target: targetParam,
          id: { type: 'string', required: true, description: '容器名或 ID' },
          pattern: { type: 'string', required: true, description: '要搜索的字面子串（默认），或 regexp=true 时的 JS 正则源文；≤512 字符' },
          regexp: { type: 'boolean', description: 'true = 把 pattern 当 JS 正则；默认 false = 字面子串。正则请避免嵌套量词（回溯风险）' },
          ignoreCase: { type: 'boolean', description: 'true = 忽略大小写（字面模式等价 grep -i，正则模式加 i 标志）' },
          since: { type: 'string', description: '起始时间（与 docker_logs 同一口径，如 2h、2026-09-09T10:00:00）；大日志强烈建议配 since/until 圈窗' },
          until: { type: 'string', description: '结束时间（docker --until 语法，与 since 同一口径）' },
          context: { type: 'number', description: '每个命中前后各保留的上下文行数（0~20，默认 2；堆栈需要更大值）' },
          limit: { type: 'number', description: '返回命中数上限（1~500，默认 200；matched 仍报全量命中数）' },
          tail: { type: 'number', description: '扫描行数上限（1~5000）；缺省 = 扫全部历史（--tail all）' },
          timestamps: { type: 'boolean', description: '每行带时间戳（默认 true——深处的命中没有时间等于没用；传 false 关闭）' },
        },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string', required: true },
              id: { type: 'string', required: true },
              matched: { type: 'number', required: true },
              scanned: { type: 'number', required: true },
              returned: { type: 'number', required: true },
              limited: { type: 'boolean' },
              truncated: { type: 'boolean' },
              // 返回侧行闸的两位：与后端 LogGrepResult 同步声明（additionalProperties:false，
              // 漏声明会被宿主校验挡掉整条结果）——见 src/docker.ts 的 MAX_RESULT_LINES。
              truncatedForSize: { type: 'boolean' },
              notes: { type: 'array', items: { type: 'string' } },
              contextLines: { type: 'number', required: true },
              lines: {
                type: 'array',
                required: true,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    seq: { type: 'number', required: true },
                    stream: { type: 'string', required: true },
                    text: { type: 'string', required: true },
                    hit: { type: 'boolean', required: true },
                    highlight: { type: 'string' },
                  },
                },
              },
            },
          },
          render: (_args: unknown, value: unknown) => {
            const v = value as { target?: string; id?: string; matched?: number; scanned?: number; returned?: number; limited?: boolean; truncated?: boolean; truncatedForSize?: boolean; notes?: string[]; contextLines?: number; lines?: Array<{ seq?: number; stream?: string; text?: string; hit?: boolean; highlight?: string }> }
            const notes: string[] = []
            if (v.limited === true) notes.push(`命中超过上限，只返回前几组窗口（总命中 ${String(v.matched ?? 0)}，可加大 limit 或缩小时间窗）`)
            if (v.truncated === true) notes.push('扫描输出超过字节上限，最旧部分未参与检索（窗口偏新；请缩小 since/until）')
            // 返回侧行闸：收窄建议由后端（notes）给出，这里只负责展示，免得两处各写一份
            if (v.truncatedForSize === true) notes.push(...(v.notes ?? ['返回行数超过上限，已截断']))
            const head = `容器 ${v.id ?? '?'}（目标 ${v.target ?? '?'}）日志检索：扫描 ${String(v.scanned ?? 0)} 行，命中 ${String(v.matched ?? 0)} 行，返回 ${String(v.returned ?? 0)} 行（含 ±${String(v.contextLines ?? 0)} 行上下文）${notes.length > 0 ? `——${notes.join('；')}` : ''}：\n\n`
            const body = (v.lines ?? []).map((line) => `${String(line.seq ?? '?').padStart(6, ' ')} ${line.hit === true ? '>' : ' '} [${line.stream ?? 'out'}] ${line.text ?? ''}`).join('\n')
            return [{ type: 'text', text: head + (body === '' ? '(无命中)' : body) }]
          },
        },
        async execute(args: unknown): Promise<{ target: string; id: string; matched: number; scanned: number; returned: number; limited?: boolean; truncated?: boolean; truncatedForSize?: boolean; notes?: string[]; contextLines: number; lines: Array<{ seq: number; stream: string; text: string; hit: boolean; highlight?: string }> }> {
          const input = (args ?? {}) as { target?: unknown; id?: unknown; pattern?: unknown; regexp?: unknown; ignoreCase?: unknown; since?: unknown; until?: unknown; context?: unknown; limit?: unknown; tail?: unknown; timestamps?: unknown }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          if (typeof input.id !== 'string') throw new Error('id 必填')
          if (typeof input.pattern !== 'string' || input.pattern === '') throw new Error('pattern 必填（要搜索的字面子串或正则）')
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          // since/until 与 docker_logs / docker_events 同一口径（D45），同一个校验函数
          const result = await api.logsGrep(input.id, {
            pattern: input.pattern,
            ...(input.regexp === true ? { regexp: true } : {}),
            ...(input.ignoreCase === true ? { ignoreCase: true } : {}),
            ...(typeof input.since === 'string' && input.since.trim() !== '' ? { since: assertSince(input.since) } : {}),
            ...(typeof input.until === 'string' && input.until.trim() !== '' ? { until: assertSince(input.until, 'until') } : {}),
            ...(typeof input.context === 'number' && Number.isInteger(input.context) ? { context: input.context } : {}),
            ...(typeof input.limit === 'number' && Number.isInteger(input.limit) ? { limit: input.limit } : {}),
            ...(typeof input.tail === 'number' && Number.isInteger(input.tail) ? { tail: input.tail } : {}),
            ...(input.timestamps === false ? { timestamps: false } : {}),
          })
          return {
            target: picked.name,
            id: result.id,
            matched: result.matched,
            scanned: result.scanned,
            returned: result.returned,
            ...(result.limited ? { limited: true } : {}),
            ...(result.truncated ? { truncated: true } : {}),
            ...(result.truncatedForSize ? { truncatedForSize: true } : {}),
            ...(result.notes === undefined ? {} : { notes: result.notes }),
            contextLines: result.contextLines,
            lines: result.lines.map((line) => ({
              seq: line.seq,
              stream: line.stream,
              text: line.text,
              hit: line.hit,
              ...(line.highlight === null ? {} : { highlight: line.highlight }),
            })),
          }
        },
      }))

      add('docker_stats', defineTool({
        name: 'docker_stats',
        // 只读工具：与同轮其它工具并发执行（宿主默认把未声明的工具当独占，见项目级 ROADMAP 第 4 项）
        isConcurrencySafe: () => true,
        description: '读取容器实时资源占用（docker stats --no-stream）：CPU%、内存用量/上限、网络与磁盘 IO、PIDs。不传 ids 时返回该目标上全部运行中容器。',
        parameters: {
          target: targetParam,
          ids: { type: 'string', description: '容器名/ID，逗号分隔（省略 = 全部运行中）' },
        },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string', required: true },
              stats: {
                type: 'array',
                required: true,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    id: { type: 'string', required: true },
                    name: { type: 'string', required: true },
                    cpuPercent: { type: 'number' },
                    memUsage: { type: 'string', required: true },
                    memPercent: { type: 'number' },
                    netIO: { type: 'string', required: true },
                    blockIO: { type: 'string', required: true },
                    pids: { type: 'number' },
                  },
                },
              },
            },
          },
          render: (_args: unknown, value: unknown) => {
            const v = value as { target?: string; stats?: ToolStatRow[] }
            return [{ type: 'text', text: renderStats(v.target ?? '?', v.stats ?? []) }]
          },
        },
        async execute(args: unknown): Promise<{ target: string; stats: ToolStatRow[] }> {
          const input = (args ?? {}) as { target?: unknown; ids?: unknown }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          const ids = typeof input.ids === 'string'
            ? input.ids.split(',').map((id) => id.trim()).filter((id) => id !== '')
            : []
          // 传了 ids 但解析为空（空串 / 纯空白 / 全是逗号）必须报错（D52）：静默变成
          // 「全部容器」会让模型把别的容器数据当成目标容器的
          if (typeof input.ids === 'string' && input.ids.trim() !== '' && ids.length === 0) {
            throw new Error('ids 只包含空白：请传容器名/ID（逗号分隔），或干脆省略 ids 表示全部运行中容器')
          }
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          const stats = await api.stats(ids)
          return {
            target: picked.name,
            stats: stats.map((row) => ({
              id: row.id,
              name: row.name,
              ...(row.cpuPercent === null ? {} : { cpuPercent: row.cpuPercent }),
              memUsage: row.memUsage,
              ...(row.memPercent === null ? {} : { memPercent: row.memPercent }),
              netIO: row.netIO,
              blockIO: row.blockIO,
              ...(row.pids === null ? {} : { pids: row.pids }),
            })),
          }
        },
      }))

      add('docker_events', defineTool({
        name: 'docker_events',
        // 只读工具：与同轮其它工具并发执行（宿主默认把未声明的工具当独占，见项目级 ROADMAP 第 4 项）
        isConcurrencySafe: () => true,
        description: '读取某个目标最近的容器事件（docker events 快照）：start / die / stop / kill / oom / health_status / destroy / rename / update 九类，已过滤掉 exec_* 等噪音。默认看最近 10m。要持续观察请让用户打开面板容器列表的「活动」条。',
        parameters: {
          target: targetParam,
          since: { type: 'string', description: '起始时间（docker --since 语法，如 30m、2h；默认 10m）' },
        },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string', required: true },
              since: { type: 'string', required: true },
              events: {
                type: 'array',
                required: true,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    action: { type: 'string', required: true },
                    name: { type: 'string', required: true },
                    image: { type: 'string', required: true },
                    composeProject: { type: 'string' },
                    time: { type: 'number' },
                    exitCode: { type: 'number' },
                  },
                },
              },
            },
          },
          render: (_args: unknown, value: unknown) => {
            const v = value as { target?: string; since?: string; events?: ToolEventRow[] }
            return [{ type: 'text', text: renderEvents(v.target ?? '?', v.since ?? '10m', v.events ?? []) }]
          },
        },
        async execute(args: unknown): Promise<{ target: string; since: string; events: ToolEventRow[] }> {
          const input = (args ?? {}) as { target?: unknown; since?: unknown }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          // since 统一口径（D45）：assertSince 接受复合 duration（1h30m）——旧白名单
          // 会拒掉 docker 明明支持的写法
          const since = assertSince(typeof input.since === 'string' && input.since.trim() !== '' ? input.since : '10m')
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          const rows = await api.events(since)
          return {
            target: picked.name,
            since,
            events: rows.map((row) => ({
              action: row.action,
              name: row.name,
              image: row.image,
              ...(row.composeProject === null ? {} : { composeProject: row.composeProject }),
              ...(row.time === null ? {} : { time: row.time }),
              ...(row.exitCode === null ? {} : { exitCode: row.exitCode }),
            })),
          }
        },
      }))

      add('docker_top', defineTool({
        name: 'docker_top',
        // 只读工具：与同轮其它工具并发执行（宿主默认把未声明的工具当独占，见项目级 ROADMAP 第 4 项）
        isConcurrencySafe: () => true,
        description: '列出容器内的进程快照（docker top）：PID / PPID / USER / STAT / 运行时长 / CPU% / 内存% / 命令。**只读**；看「谁在吃 CPU / 内存」先看这里，整体「为什么不行」用 docker_diagnose。容器没在运行会直接报错（不是空列表）。',
        parameters: {
          target: targetParam,
          id: { type: 'string', required: true, description: '容器名或 ID（来自 docker_ps）' },
        },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string', required: true },
              id: { type: 'string', required: true },
              name: { type: 'string', required: true },
              truncated: { type: 'boolean', required: true },
              processes: {
                type: 'array',
                required: true,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    pid: { type: 'string', required: true },
                    ppid: { type: 'string', required: true },
                    user: { type: 'string', required: true },
                    stat: { type: 'string', required: true },
                    elapsed: { type: 'string', required: true },
                    cpu: { type: 'string', required: true },
                    mem: { type: 'string', required: true },
                    command: { type: 'string', required: true },
                  },
                },
              },
            },
          },
          render: (_args: unknown, value: unknown) => {
            const v = value as Partial<ToolTopRow>
            return [{ type: 'text', text: renderTop(v.target ?? '?', { target: v.target ?? '?', id: v.id ?? '?', name: v.name ?? '', processes: v.processes ?? [], truncated: v.truncated === true }) }]
          },
        },
        async execute(args: unknown): Promise<ToolTopRow> {
          const input = (args ?? {}) as { target?: unknown; id?: unknown }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          if (typeof input.id !== 'string') throw new Error('id 必填')
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          const top = await api.top(input.id)
          return {
            target: picked.name,
            id: top.id,
            name: top.name,
            processes: top.rows.map((row) => ({
              pid: row.pid,
              ppid: row.ppid,
              user: row.user,
              stat: row.stat,
              elapsed: row.elapsed,
              cpu: row.cpu,
              mem: row.mem,
              command: row.command,
            })),
            truncated: top.truncated,
          }
        },
      }))

      add('docker_diagnose', defineTool({
        name: 'docker_diagnose',
        // 只读工具：四路全是只读采集（inspect / logs / events / stats），与同轮其它工具并发执行
        isConcurrencySafe: () => true,
        description: '诊断容器「为什么不行」（**只读**）：一次采集 inspect + logs + events + stats 四路，按固定判据给出结论——OOM / 非零退出 / 反复重启 / 健康检查失败 / 内存或 CPU 逼近上限 / 日志里有报错。结论是**判据**不是猜测：每条 finding 都带证据（detail），evidence 给结构化字段，**没采到的字段是缺席而不是 0**（findings 里另有 *-unavailable 说明原因）。日志默认只抓尾部 80 行：要更多日志 / 找关键词用 docker_logs_grep。',
        parameters: {
          target: targetParam,
          id: { type: 'string', required: true, description: '容器名或 ID（来自 docker_ps）' },
          logTail: { type: 'number', description: '日志尾部行数（1~500，默认 80；越界值会被夹紧到边界）' },
          since: { type: 'string', description: '事件与日志的时间窗（docker --since 语法，默认 1h，如 30m、2h、2026-09-09T10:00:00）' },
          history: { type: 'number', description: '返回多少条历史样本（0~50，默认 10；越界值会被夹紧）。每次调用都会记录本次诊断（30 秒内完全相同的重复不重复记），所以多调几次就能看出「它在慢慢变坏吗」' },
        },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string', required: true },
              id: { type: 'string', required: true },
              name: { type: 'string', required: true },
              verdict: {
                type: 'object',
                required: true,
                additionalProperties: false,
                properties: {
                  severity: { type: 'string', required: true },
                  code: { type: 'string', required: true },
                  summary: { type: 'string', required: true },
                },
              },
              findings: {
                type: 'array',
                required: true,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    code: { type: 'string', required: true },
                    severity: { type: 'string', required: true },
                    title: { type: 'string', required: true },
                    detail: { type: 'string', required: true },
                  },
                },
              },
              evidence: {
                type: 'object',
                required: true,
                additionalProperties: false,
                properties: {
                  state: { type: 'string' },
                  status: { type: 'string' },
                  health: { type: 'string' },
                  healthLastOutput: { type: 'string' },
                  exitCode: { type: 'number' },
                  oomKilled: { type: 'boolean' },
                  restartCount: { type: 'number' },
                  startedAt: { type: 'string' },
                  finishedAt: { type: 'string' },
                  memoryLimitBytes: { type: 'number' },
                  cpuQuota: { type: 'number' },
                  logLines: { type: 'number' },
                  errorLines: { type: 'number' },
                  eventCount: { type: 'number' },
                  cpuPercent: { type: 'number' },
                  memBytes: { type: 'number' },
                  memPercent: { type: 'number' },
                },
              },
              timeline: {
                type: 'array',
                required: true,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    at: { type: 'string' },
                    kind: { type: 'string', required: true },
                    text: { type: 'string', required: true },
                  },
                },
              },
              suggestions: { type: 'array', required: true, items: { type: 'string' } },
              // 批三：历史与趋势（不是新工具，理由见 diagnoseWithHistory 的注释）。
              // `window` 在样本 <2 时**不出现**（schema 没有 null 类型，见 toToolEvidence 的同款说明）
              history: {
                type: 'object',
                required: true,
                additionalProperties: false,
                properties: {
                  samples: {
                    type: 'array',
                    required: true,
                    items: {
                      type: 'object',
                      additionalProperties: false,
                      properties: {
                        at: { type: 'string', required: true },
                        severity: { type: 'string', required: true },
                        code: { type: 'string', required: true },
                        findings: { type: 'array', required: true, items: { type: 'string' } },
                        restartCount: { type: 'number' },
                        memPercent: { type: 'number' },
                        errorLines: { type: 'number' },
                      },
                    },
                  },
                  trend: {
                    type: 'object',
                    required: true,
                    additionalProperties: false,
                    properties: {
                      count: { type: 'number', required: true },
                      window: {
                        type: 'object',
                        additionalProperties: false,
                        properties: { from: { type: 'string', required: true }, to: { type: 'string', required: true } },
                      },
                      verdict: {
                        type: 'object',
                        required: true,
                        additionalProperties: false,
                        properties: {
                          severity: { type: 'string', required: true },
                          code: { type: 'string', required: true },
                          summary: { type: 'string', required: true },
                        },
                      },
                      numbers: {
                        type: 'array',
                        required: true,
                        items: {
                          type: 'object',
                          additionalProperties: false,
                          properties: {
                            key: { type: 'string', required: true },
                            from: { type: 'number', required: true },
                            to: { type: 'number', required: true },
                            delta: { type: 'number', required: true },
                          },
                        },
                      },
                      newFindings: { type: 'array', required: true, items: { type: 'string' } },
                      resolvedFindings: { type: 'array', required: true, items: { type: 'string' } },
                      aggravating: { type: 'boolean', required: true },
                    },
                  },
                  recorded: { type: 'boolean', required: true },
                },
              },
              logTail: { type: 'string', required: true },
            },
          },
          render: (_args: unknown, value: unknown) => {
            const v = value as Partial<ToolDiagnosisRow>
            return [{ type: 'text', text: renderDiagnosis(v.target ?? '?', {
              target: v.target ?? '?',
              id: v.id ?? '?',
              name: v.name ?? '',
              verdict: v.verdict ?? { severity: '?', code: '?', summary: '' },
              findings: v.findings ?? [],
              evidence: v.evidence ?? {},
              timeline: v.timeline ?? [],
              suggestions: v.suggestions ?? [],
              logTail: v.logTail ?? '',
              // render 只在「schema 校验前」跑；正常路径一定有 history，兜底给空样本（形状走同一份转换）
              history: v.history ?? toToolHistory({ samples: [], trend: historyTrend([]), recorded: false }),
            }) }]
          },
        },
        async execute(args: unknown): Promise<ToolDiagnosisRow> {
          const input = (args ?? {}) as { target?: unknown; id?: unknown; logTail?: unknown; since?: unknown; history?: unknown }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          if (typeof input.id !== 'string') throw new Error('id 必填')
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          // logTail / since / history 的夹紧与默认值统一在 diagnoseWithHistory 里做（HTTP 路由与工具
          // 同一份语义）；非法 since 在这里抛成可读错误（与 docker_logs 同一个 assertSince）
          const { diagnosis, history } = await diagnoseWithHistory(api, picked.name, input.id, {
            logTail: input.logTail,
            since: input.since,
            history: input.history,
          })
          return {
            target: picked.name,
            id: diagnosis.id,
            name: diagnosis.name,
            verdict: diagnosis.verdict,
            findings: diagnosis.findings.map((finding) => ({
              code: finding.code,
              severity: finding.severity,
              title: finding.title,
              detail: finding.detail,
            })),
            evidence: toToolEvidence(diagnosis.evidence),
            timeline: diagnosis.timeline.map((entry) => ({
              ...(entry.at === null ? {} : { at: entry.at }),
              kind: entry.kind,
              text: entry.text,
            })),
            suggestions: diagnosis.suggestions,
            logTail: diagnosis.logTail,
            // 给模型的样本最多 10 条（再多也读不动）；`window` 为 null 时省略（schema 没有 null）
            history: toToolHistory(history),
          }
        },
      }))

      add('docker_run_command', defineTool({
        name: 'docker_run_command',
        // 只读工具：只读 inspect + 纯文本推导，没有任何副作用
        isConcurrencySafe: () => true,
        description: '从容器配置反推一条**等价的 docker run 命令**（只生成命令文本，**不执行任何操作**）：端口 / 挂载 / 网络 / 环境变量 / 资源限制 / 设备都会还原。**故意没还原的**东西（--privileged、匿名卷、自定义 ENTRYPOINT、健康检查等）在 omitted 里点名，不许静默丢；命中敏感键名的环境变量在 secretKeys 里（**值不改写**，命令里是原值——贴出去前先确认）。适合手动复现 / 迁移。Compose 管理的容器只是近似。',
        parameters: {
          target: targetParam,
          id: { type: 'string', required: true, description: '容器名或 ID（来自 docker_ps）' },
        },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string', required: true },
              id: { type: 'string', required: true },
              name: { type: 'string', required: true },
              command: { type: 'string', required: true },
              warnings: { type: 'array', required: true, items: { type: 'string' } },
              secretKeys: { type: 'array', required: true, items: { type: 'string' } },
              omitted: { type: 'array', required: true, items: { type: 'string' } },
            },
          },
          render: (_args: unknown, value: unknown) => {
            const v = value as Partial<ToolRunCommandRow>
            return [{ type: 'text', text: renderRunCommand(v.target ?? '?', {
              target: v.target ?? '?',
              id: v.id ?? '?',
              name: v.name ?? '',
              command: v.command ?? '',
              warnings: v.warnings ?? [],
              secretKeys: v.secretKeys ?? [],
              omitted: v.omitted ?? [],
            }) }]
          },
        },
        async execute(args: unknown): Promise<ToolRunCommandRow> {
          const input = (args ?? {}) as { target?: unknown; id?: unknown }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          if (typeof input.id !== 'string') throw new Error('id 必填')
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          const result = await api.recreate(input.id)
          return {
            target: picked.name,
            id: result.id,
            name: result.name,
            command: result.command,
            warnings: result.warnings,
            secretKeys: result.secretKeys,
            omitted: result.omitted,
          }
        },
      }))

      add('docker_images', defineTool({
        name: 'docker_images',
        // 只读工具：与同轮其它工具并发执行（宿主默认把未声明的工具当独占，见项目级 ROADMAP 第 4 项）
        isConcurrencySafe: () => true,
        description: '列出某个目标上的镜像（仓库:标签、大小、创建时间、短 ID）。',
        parameters: {
          target: targetParam,
          limit: pageParams.limit,
          offset: pageParams.offset,
        },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string', required: true },
              // total / truncated 必须在这里声明（additionalProperties: false）：
              // 返回值里有、schema 里没有，宿主校验会挡掉整个结果（ToolOutputError）
              total: { type: 'number' },
              truncated: { type: 'boolean' },
              images: {
                type: 'array',
                required: true,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    reference: { type: 'string', required: true },
                    sizeText: { type: 'string', required: true },
                    createdSince: { type: 'string' },
                    id: { type: 'string', required: true },
                  },
                },
              },
            },
          },
          render: (args: unknown, value: unknown) => {
            const v = value as { target?: string; images?: ToolImageRow[]; total?: number; truncated?: boolean }
            return [{ type: 'text', text: renderImages(v.target ?? '?', v.images ?? [], listPage(args, v.total, v.truncated === true)) }]
          },
        },
        async execute(args: unknown): Promise<{ target: string; images: ToolImageRow[]; total: number; truncated: boolean }> {
          const input = (args ?? {}) as { target?: unknown; limit?: unknown; offset?: unknown }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          const images = await api.images()
          // 全量拿到之后才切（T1）：后端 `images()` 的返回契约不变（面板要完整列表）
          const paged = paginate(images, pageWindow(input))
          return {
            target: picked.name,
            images: paged.rows.map((row) => ({
              reference: row.reference,
              sizeText: row.sizeText,
              ...(row.createdSince === '' ? {} : { createdSince: row.createdSince }),
              id: row.shortId,
            })),
            total: paged.total,
            truncated: paged.truncated,
          }
        },
      }))

      add('docker_image_inspect', defineTool({
        name: 'docker_image_inspect',
        // 只读工具：与同轮其它工具并发执行（宿主默认把未声明的工具当独占，见项目级 ROADMAP 第 4 项）
        isConcurrencySafe: () => true,
        description: '读取某个镜像的详情（docker image inspect）与构建历史（docker history）：大小 / 创建时间 / 平台 / 层数与层列表 / 入口与命令 / 暴露端口 / digest / 每步构建命令与大小。',
        parameters: {
          target: targetParam,
          ref: { type: 'string', required: true, description: '镜像引用：repository:tag、镜像 ID（sha256:…）或 digest' },
        },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string', required: true },
              ref: { type: 'string', required: true },
              detail: { type: 'string', required: true },
            },
          },
          render: (_args: unknown, value: unknown) => {
            const v = value as { detail?: string }
            return [{ type: 'text', text: v.detail ?? '' }]
          },
        },
        async execute(args: unknown): Promise<ToolImageDetailRow> {
          const input = (args ?? {}) as { target?: unknown; ref?: unknown }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          if (typeof input.ref !== 'string' || input.ref.trim() === '') throw new Error('ref 必填')
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          const image = await api.imageInspect(input.ref)
          return { target: picked.name, ref: image.ref, detail: renderImageDetail(image) }
        },
      }))

      add('docker_networks', defineTool({
        name: 'docker_networks',
        // 只读工具：与同轮其它工具并发执行（宿主默认把未声明的工具当独占，见项目级 ROADMAP 第 4 项）
        isConcurrencySafe: () => true,
        description: '列出某个目标上的 docker 网络（名称 / 驱动 / 范围 / 是否 internal / 短 ID）。接入的容器列表要进详情页看，不在列表里逐条 inspect。',
        parameters: {
          target: targetParam,
          limit: pageParams.limit,
          offset: pageParams.offset,
        },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string', required: true },
              // 同 docker_images：additionalProperties: false 下必须声明，否则整个结果被挡
              total: { type: 'number' },
              truncated: { type: 'boolean' },
              networks: {
                type: 'array',
                required: true,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    name: { type: 'string', required: true },
                    driver: { type: 'string', required: true },
                    scope: { type: 'string', required: true },
                    internal: { type: 'boolean' },
                    id: { type: 'string', required: true },
                  },
                },
              },
            },
          },
          render: (args: unknown, value: unknown) => {
            const v = value as { target?: string; networks?: ToolNetworkRow[]; total?: number; truncated?: boolean }
            return [{ type: 'text', text: renderNetworks(v.target ?? '?', v.networks ?? [], listPage(args, v.total, v.truncated === true)) }]
          },
        },
        async execute(args: unknown): Promise<{ target: string; networks: ToolNetworkRow[]; total: number; truncated: boolean }> {
          const input = (args ?? {}) as { target?: unknown; limit?: unknown; offset?: unknown }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          const rows = await api.networks()
          const paged = paginate(rows, pageWindow(input))
          return {
            target: picked.name,
            networks: paged.rows.map((row) => ({
              name: row.name,
              driver: row.driver,
              scope: row.scope,
              ...(row.internal ? { internal: true } : {}),
              id: row.shortId,
            })),
            total: paged.total,
            truncated: paged.truncated,
          }
        },
      }))

      add('docker_volumes', defineTool({
        name: 'docker_volumes',
        // 只读工具：与同轮其它工具并发执行（宿主默认把未声明的工具当独占，见项目级 ROADMAP 第 4 项）
        isConcurrencySafe: () => true,
        description: '列出某个目标上的 docker 卷（名称 / 驱动 / 范围 / 挂载点）。',
        parameters: {
          target: targetParam,
          limit: pageParams.limit,
          offset: pageParams.offset,
        },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string', required: true },
              // 同 docker_images：additionalProperties: false 下必须声明，否则整个结果被挡
              total: { type: 'number' },
              truncated: { type: 'boolean' },
              volumes: {
                type: 'array',
                required: true,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    name: { type: 'string', required: true },
                    driver: { type: 'string', required: true },
                    scope: { type: 'string', required: true },
                    mountpoint: { type: 'string' },
                  },
                },
              },
            },
          },
          render: (args: unknown, value: unknown) => {
            const v = value as { target?: string; volumes?: ToolVolumeRow[]; total?: number; truncated?: boolean }
            return [{ type: 'text', text: renderVolumes(v.target ?? '?', v.volumes ?? [], listPage(args, v.total, v.truncated === true)) }]
          },
        },
        async execute(args: unknown): Promise<{ target: string; volumes: ToolVolumeRow[]; total: number; truncated: boolean }> {
          const input = (args ?? {}) as { target?: unknown; limit?: unknown; offset?: unknown }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          const rows = await api.volumes()
          const paged = paginate(rows, pageWindow(input))
          return {
            target: picked.name,
            volumes: paged.rows.map((row) => ({
              name: row.name,
              driver: row.driver,
              scope: row.scope,
              ...(row.mountpoint === '' ? {} : { mountpoint: row.mountpoint }),
            })),
            total: paged.total,
            truncated: paged.truncated,
          }
        },
      }))

      add('docker_disk_usage', defineTool({
        name: 'docker_disk_usage',
        // 只读工具：`docker system df` 是纯查询（-v 会去 stat 卷，但没有任何写操作）
        isConcurrencySafe: () => true,
        description: '读取目标上的磁盘占用（docker system df）：四类汇总 + 镜像 / 卷 / 构建缓存明细，并给出**谁在用**（镜像的容器数、卷的链接数）——这两个数字来自 docker 自己的 `Images[].Containers` / `Volumes[].Links`，不是按 ps 反推的。只读；明细每类最多 20 行（超了给 truncated 与 total）。**删之前先看 containers 是不是 0**：0 才是没人用。老 docker 取不到明细时 degraded=true，汇总仍可用。',
        parameters: { target: targetParam },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              target: { type: 'string', required: true },
              summary: {
                type: 'array',
                required: true,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    type: { type: 'string', required: true },
                    totalCount: { type: 'number', required: true },
                    active: { type: 'number', required: true },
                    size: { type: 'string', required: true },
                    reclaimable: { type: 'string', required: true },
                  },
                },
              },
              images: {
                type: 'array',
                required: true,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    id: { type: 'string', required: true },
                    repository: { type: 'string', required: true },
                    tag: { type: 'string', required: true },
                    size: { type: 'string', required: true },
                    sharedSize: { type: 'string', required: true },
                    uniqueSize: { type: 'string', required: true },
                    containers: { type: 'number', required: true },
                  },
                },
              },
              volumes: {
                type: 'array',
                required: true,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    name: { type: 'string', required: true },
                    driver: { type: 'string', required: true },
                    size: { type: 'string', required: true },
                    links: { type: 'number', required: true },
                  },
                },
              },
              buildCache: {
                type: 'array',
                required: true,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    id: { type: 'string', required: true },
                    type: { type: 'string', required: true },
                    size: { type: 'string', required: true },
                    inUse: { type: 'boolean', required: true },
                  },
                },
              },
              // 截断前的真实条数（每类）：工具只回 20 行，模型靠它知道「还有多少」
              totals: {
                type: 'object',
                required: true,
                additionalProperties: false,
                properties: {
                  images: { type: 'number', required: true },
                  volumes: { type: 'number', required: true },
                  buildCache: { type: 'number', required: true },
                },
              },
              truncated: {
                type: 'object',
                required: true,
                additionalProperties: false,
                properties: {
                  images: { type: 'boolean', required: true },
                  volumes: { type: 'boolean', required: true },
                  buildCache: { type: 'boolean', required: true },
                },
              },
              degraded: { type: 'boolean', required: true },
              degradedReason: { type: 'string' },
            },
          },
          render: (_args: unknown, value: unknown) => {
            const v = value as Partial<ToolDiskRow>
            return [{ type: 'text', text: renderDiskUsage(v.target ?? '?', {
              target: v.target ?? '?',
              summary: v.summary ?? [],
              images: v.images ?? [],
              volumes: v.volumes ?? [],
              buildCache: v.buildCache ?? [],
              totals: v.totals ?? { images: 0, volumes: 0, buildCache: 0 },
              truncated: v.truncated ?? { images: false, volumes: false, buildCache: false },
              degraded: v.degraded === true,
              ...(v.degradedReason === undefined ? {} : { degradedReason: v.degradedReason }),
            }) }]
          },
        },
        async execute(args: unknown): Promise<ToolDiskRow> {
          const input = (args ?? {}) as { target?: unknown }
          const picked = pickTarget(input.target)
          if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
          const { api } = apiFor(picked.name)
          if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
          const usage = await api.systemDf()
          // 工具是给模型看的：每类只回 20 行（宿主侧上限 100，客户端看全量）
          const take = <T,>(list: readonly T[]): T[] => list.slice(0, DISK_TOOL_ROWS)
          return {
            target: picked.name,
            summary: usage.summary,
            images: take(usage.images),
            volumes: take(usage.volumes),
            buildCache: take(usage.buildCache),
            totals: usage.totals,
            truncated: {
              images: usage.truncated.images || usage.images.length > DISK_TOOL_ROWS,
              volumes: usage.truncated.volumes || usage.volumes.length > DISK_TOOL_ROWS,
              buildCache: usage.truncated.buildCache || usage.buildCache.length > DISK_TOOL_ROWS,
            },
            degraded: usage.degraded,
            ...(usage.degradedReason === null ? {} : { degradedReason: usage.degradedReason }),
          }
        },
      }))

      if (live.allowMutations) {
        add('docker_action', defineTool({
          name: 'docker_action',
          description: '对容器执行生命周期操作：start / stop / restart / remove。**破坏性**：remove 会删除容器（数据卷不在其中，但容器配置与可写层丢失），执行前必须向用户确认目标容器。仅当用户在设置里打开「允许变更操作」时可用。',
          parameters: {
            target: targetParam,
            // enum 把「四选一」前移到派发前（D51 残留）：实测 dsh-tools 的参数 DSL 支持 enum
            // （不支持的是 minimum/maximum），此前只在执行期拒绝，模型会先浪费一次往返
            action: { type: 'string', enum: ['start', 'stop', 'restart', 'remove'], required: true, description: 'start | stop | restart | remove（四选一）' },
            id: { type: 'string', required: true, description: '容器名或 ID' },
          },
          output: {
            schema: {
              type: 'object',
              additionalProperties: false,
              properties: {
                target: { type: 'string', required: true },
                id: { type: 'string', required: true },
                action: { type: 'string', required: true },
                message: { type: 'string', required: true },
              },
            },
            render: (_args: unknown, value: unknown) => {
              const v = value as { id?: string; action?: string; message?: string; target?: string }
              return [{ type: 'text', text: `${v.action ?? '?'} ${v.id ?? '?'}（目标 ${v.target ?? '?'}）：${v.message ?? 'ok'}` }]
            },
          },
          async execute(args: unknown): Promise<{ target: string; id: string; action: string; message: string }> {
            if (!live.allowMutations) throw new Error(mutationsOffMessage())
            const input = (args ?? {}) as { target?: unknown; action?: unknown; id?: unknown }
            const picked = pickTarget(input.target)
            if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
            if (typeof input.id !== 'string') throw new Error('id 必填')
            const id = input.id
            const action = input.action
            if (action !== 'start' && action !== 'stop' && action !== 'restart' && action !== 'remove') {
              throw new Error('action 必须是 start / stop / restart / remove')
            }
            const { api } = apiFor(picked.name)
            if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
            const result = await audited({ capability: 'allowMutations', source: 'tool', action: `container.${action}`, target: picked.name, ref: id }, () => api.action({ action, id }))
            return { target: picked.name, id: result.id, action: result.action, message: result.message }
          },
        }))

        add('docker_image_remove', defineTool({
          name: 'docker_image_remove',
          description: '删除一个镜像（docker image rm，不带 -f）。**破坏性**：镜像被容器或子镜像引用时会失败；执行前须向用户确认目标镜像，并复述后果（需要重新拉取或构建才能恢复）。仅当用户在设置里打开「允许变更操作」时可用。',
          parameters: {
            target: targetParam,
            ref: { type: 'string', required: true, description: '镜像引用：repository:tag 或镜像 ID（sha256:…）' },
          },
          output: {
            schema: {
              type: 'object',
              additionalProperties: false,
              properties: {
                target: { type: 'string', required: true },
                ref: { type: 'string', required: true },
                message: { type: 'string', required: true },
              },
            },
            render: (_args: unknown, value: unknown) => {
              const v = value as { ref?: string; message?: string; target?: string }
              return [{ type: 'text', text: '已删除镜像 ' + String(v.ref ?? '?') + '（目标 ' + String(v.target ?? '?') + '）：' + String(v.message ?? 'ok') }]
            },
          },
          async execute(args: unknown): Promise<{ target: string; ref: string; message: string }> {
            if (!live.allowMutations) throw new Error(mutationsOffMessage())
            const input = (args ?? {}) as { target?: unknown; ref?: unknown }
            const picked = pickTarget(input.target)
            if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
            if (typeof input.ref !== 'string' || input.ref.trim() === '') throw new Error('ref 必填')
            const ref = input.ref
            const { api } = apiFor(picked.name)
            if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
            const result = await audited({ capability: 'allowMutations', source: 'tool', action: 'image.remove', target: picked.name, ref }, () => api.imageRemove(ref))
            return { target: picked.name, ref: result.ref, message: result.message }
          },
        }))

        add('docker_image_prune', defineTool({
          name: 'docker_image_prune',
          description: '清理 dangling（无标签 <none>:<none>）镜像（docker image prune -f）。只删无标签镜像，不动有 tag 的镜像（刻意不加 --all，避免误删未使用的普通镜像）。返回删除列表与释放的空间。仅当用户在设置里打开「允许变更操作」时可用。',
          parameters: { target: targetParam },
          output: {
            schema: {
              type: 'object',
              additionalProperties: false,
              properties: {
                target: { type: 'string', required: true },
                message: { type: 'string', required: true },
              },
            },
            render: (_args: unknown, value: unknown) => {
              const v = value as { message?: string; target?: string }
              return [{ type: 'text', text: '已清理 dangling 镜像（目标 ' + String(v.target ?? '?') + '）：\n' + String(v.message ?? 'ok') }]
            },
          },
          async execute(args: unknown): Promise<{ target: string; message: string }> {
            if (!live.allowMutations) throw new Error(mutationsOffMessage())
            const input = (args ?? {}) as { target?: unknown }
            const picked = pickTarget(input.target)
            if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
            const { api } = apiFor(picked.name)
            if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
            const result = await audited({ capability: 'allowMutations', source: 'tool', action: 'image.prune', target: picked.name }, () => api.imagePrune())
            return { target: picked.name, message: result.message }
          },
        }))

        add('docker_image_pull', defineTool({
          name: 'docker_image_pull',
          description: '拉取镜像（docker pull），例 nginx:1.27、ghcr.io/org/app:latest。**可能耗时数分钟**（逐层下载）；可用 timeoutSec 调整上限（10~1800 秒，默认 600）。仅当用户在设置里打开「允许变更操作」时可用。交互式观察进度请让用户到面板镜像页的「拉取」里看 SSE 进度流。',
          parameters: {
            target: targetParam,
            ref: { type: 'string', required: true, description: '镜像引用：repository:tag 或 digest' },
            timeoutSec: { type: 'number', description: '超时秒数（10~1800，默认 600；越界值会被静默夹紧）' },
          },
          output: {
            schema: {
              type: 'object',
              additionalProperties: false,
              properties: {
                target: { type: 'string', required: true },
                ref: { type: 'string', required: true },
                code: { type: 'number' },
                text: { type: 'string', required: true },
                truncated: { type: 'boolean' },
              },
            },
            render: (_args: unknown, value: unknown) => {
              const v = value as { ref?: string; code?: number; text?: string; truncated?: boolean; target?: string }
              const head = '拉取 ' + String(v.ref ?? '?') + '（目标 ' + String(v.target ?? '?') + '）退出码 ' + String(v.code ?? '?') + (v.truncated === true ? ' · 输出已截断' : '') + '：\n\n'
              return [{ type: 'text', text: head + ((v.text ?? '') === '' ? '(无输出)' : (v.text ?? '')) }]
            },
          },
          async execute(args: unknown): Promise<ToolImagePullRow> {
            if (!live.allowMutations) throw new Error(mutationsOffMessage())
            const input = (args ?? {}) as { target?: unknown; ref?: unknown; timeoutSec?: unknown }
            const picked = pickTarget(input.target)
            if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
            if (typeof input.ref !== 'string' || input.ref.trim() === '') throw new Error('ref 必填')
            const ref = input.ref
            const { api } = apiFor(picked.name)
            if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
            const timeoutSec = typeof input.timeoutSec === 'number' && Number.isInteger(input.timeoutSec) ? input.timeoutSec : 600
            const result = await audited({ capability: 'allowMutations', source: 'tool', action: 'image.pull', target: picked.name, ref }, () => api.pull(ref, timeoutSec * 1000), (row) => row.code === null ? undefined : `code=${String(row.code)}`)
            return {
              target: picked.name,
              ref: result.ref,
              ...(result.code === null ? {} : { code: result.code }),
              text: result.text,
              ...(result.truncated ? { truncated: true } : {}),
            }
          },
        }))
      }

      if (live.allowExec) {
        add('docker_exec', defineTool({
          name: 'docker_exec',
          description: '在容器内执行一条一次性命令（docker exec，无 TTY）：如 `ls -la /app`、`cat /etc/nginx/nginx.conf`、`env`。仅当用户在设置里打开「允许 exec」时可用；不要在容器里做破坏性操作，交互式排障请让用户到终端面板执行 `docker exec -it <容器> sh`。',
          parameters: {
            target: targetParam,
            id: { type: 'string', required: true, description: '容器名或 ID' },
            command: { type: 'string', required: true, description: '要执行的命令（经容器内 sh -c 执行）' },
            timeoutSec: { type: 'number', description: '超时秒数（1~120，默认取插件配置 execTimeoutSec；越界值会被静默夹紧）' },
          },
          output: {
            schema: {
              type: 'object',
              additionalProperties: false,
              properties: {
                target: { type: 'string', required: true },
                id: { type: 'string', required: true },
                code: { type: 'number' },
                stdout: { type: 'string', required: true },
                stderr: { type: 'string', required: true },
                truncated: { type: 'boolean' },
              },
            },
            render: (_args: unknown, value: unknown) => {
              const v = value as { id?: string; code?: number; stdout?: string; stderr?: string; truncated?: boolean }
              const parts = [`容器 ${v.id ?? '?'} 退出码 ${v.code === undefined ? '?' : String(v.code)}`]
              if ((v.stdout ?? '') !== '') parts.push('stdout:\n' + (v.stdout ?? ''))
              if ((v.stderr ?? '') !== '') parts.push('stderr:\n' + (v.stderr ?? ''))
              if (v.truncated === true) parts.push('（输出已截断）')
              return [{ type: 'text', text: parts.join('\n\n') }]
            },
          },
          async execute(args: unknown): Promise<ToolExecRow> {
            if (!live.allowExec) throw new Error(execOffMessage())
            const input = (args ?? {}) as { target?: unknown; id?: unknown; command?: unknown; timeoutSec?: unknown }
            const picked = pickTarget(input.target)
            if (picked.name === undefined) throw new Error(picked.error ?? '无效的 target')
            if (typeof input.id !== 'string') throw new Error('id 必填')
            if (typeof input.command !== 'string' || input.command.trim() === '') throw new Error('command 必填')
            const id = input.id
            const command = input.command
            const timeoutSec = typeof input.timeoutSec === 'number' && Number.isInteger(input.timeoutSec) ? input.timeoutSec : live.execTimeoutSec
            const { api } = apiFor(picked.name)
            if (api === undefined) throw new Error(resolveByName(picked.name).error ?? '无法构造执行通道')
            const result = await audited({ capability: 'allowExec', source: 'tool', action: 'exec', target: picked.name, ref: id }, () => api.exec(id, command, timeoutSec * 1000), (row) => `code=${String(row.code)} cmd=${row.command}`)
            return {
              target: picked.name,
              id: result.id,
              ...(result.code === null ? {} : { code: result.code }),
              stdout: result.stdout,
              stderr: result.stderr,
              truncated: result.truncated,
            }
          },
        }))
      }
      // 档位闸与工具同生命周期：refreshTools 幂等重建时随 toolDisposers 一起撤下/重挂
      // （禁用热生效时工具与闸一起撤；机制见 kit 的 tier-gate.ts，方案见 docs/permission-tier-plan.md）。
      toolDisposers.push(attachTierGate(ctx, {
        pkg: 'docker',
        prefixes: DOCKER_TIER_PREFIXES,
        classify: (tool) => DOCKER_TIER_CLASS[tool],
      }))
      if (failures.length > 0) {
        console.warn(`[dsh-docker] ${String(failures.length)} 个 agent 工具注册失败（下次配置变更会重试）：${failures.join('；')}`)
      }
    }

    // tools 服务（可选）：拿到后注册一次，能力开关变化时 refreshTools 重注册
    /*
     * 官方凭据层（可选，`@deepseek-ai/dsh-credentials` 提供的 `ctx.credentials`）。
     *
     * 配置里的 `env:NAME` 是一个**引用**（这正是官方的模式：配置只持引用，值归 provider），
     * 而 provider 会叠 `file`（`$DSH_HOME/.credentials.yaml`）/ `env` / `project-env` /
     * `user-env` 各层，并保证「每次操作重新解析」——改完下一个操作即生效，不必重启宿主。
     * 我们从前直接读 `process.env`，等于只认其中一层，而且拿的是进程启动时的快照。
     *
     * 服务缺失（老宿主 / 未装该 bundle）时不注册，`resolveSecret` 自己退回 `process.env`，
     * 行为与从前一致——所以这是**可选**依赖，不抬高 engines 下限。
     */
    ctx.inject(['credentials'], (credCtx: Context) => {
      setCredentialResolver((credCtx as unknown as { credentials?: CredentialResolver }).credentials ?? null)
      return () => { setCredentialResolver(null) }
    })

    ctx.inject(['tools'], (toolsCtx: Context) => {
      toolsCtx.effect(() => {
        toolsApi = (toolsCtx as unknown as { tools: ToolsLike }).tools
        refreshTools()
        console.log('[dsh-docker] agent tools ' + (live.enabled ? 'registered (' + registeredNames.join(', ') + ')' : 'skipped (disabled)'))
        /*
         * 按会话档位在 **agent 作用域**上裁掉用不到的 write / exec 工具（与 tty 试点同一份实现，
         * 2026-10 上收到 kit 的 tier-restrict.ts）。
         *
         * 位置是这一层的**关键**：刻意放在 effect 体里、**不放进 refreshTools**。能力开关变化会走
         * refreshTools 重注册工具（先撤后挂），而重注册不该把已有 agent 的裁剪一并撤掉——
         * `agent/created` 不会为老 agent 再发一次，撤了就再也裁不回来。与工具同生命周期的是
         * **这一层订阅**，随插件卸载 / tools 服务撤离一起撤。
         *
         * 传 `toolsCtx` 而不是插件 `ctx`：本插件的 tools 是**动态 inject** 拿到的（插件对象没有
         * 声明式 `inject: ['tools']`），在插件 ctx 上读 `tools` 会撞 cordis 的 inject 守卫——而
         * `attachTierRestrict` 要用 tools 的全局 `schemas()` 现算 deny 名单，拿不到就**静默退化
         * 成不裁剪**（不报错，比抛错更难发现）。`toolsCtx` 是这条 inject 回调里绑定了 tools 的
         * 上下文，正好是它需要的取法。
         *
         * 实测（cordis 4.0.5：服务由**兄弟 fiber** 提供，与真宿主的 dsh-tools 同形）：
         *   - 无声明式 inject 的插件 ctx：`ctx.tools` 抛 `cannot get property "tools" without
         *     inject`，`ctx.get('tools')` 是 `undefined`；
         *   - 同一条 `ctx.inject(['tools'], cb)` 的 `cb` 里：`toolsCtx.tools` 正常，
         *     `toolsCtx.on('agent/created')` 收得到事件（本层两个依赖都在这里成立）。
         */
        const disposeTierRestrict = attachTierRestrict(toolsCtx, {
          pkg: 'docker',
          prefixes: DOCKER_TIER_PREFIXES,
          classify: (tool) => DOCKER_TIER_CLASS[tool],
        })
        return () => {
          toolsApi = undefined
          // 先撤裁剪、再撤工具：撤销走的是 agent scope 上的 disposer，工具还挂着时撤最干净。
          disposeTierRestrict()
          for (const dispose of toolDisposers) {
            try {
              dispose()
            } catch {
              /* 工具已注销 */
            }
          }
          toolDisposers = []
          registeredNames = []
        }
      }, 'dsh-docker: agent tools')
    })

    /* ---------- 能力公告 ---------- */

    let systemPromptApi: SystemPromptLike | undefined
    let announcementDispose: (() => void) | undefined

    /** 按当前配置重建公告 section（enabled / announceToAgent 热变化时调用；幂等）。 */
    const refreshAnnouncement = (): void => {
      if (announcementDispose !== undefined) {
        try {
          announcementDispose()
        } catch {
          /* 已注销 */
        }
        announcementDispose = undefined
      }
      const systemPrompt = systemPromptApi
      if (systemPrompt === undefined) return
      if (!live.enabled || !live.announceToAgent) return
      announcementDispose = registerLiteralSection(systemPrompt, { name: 'plugin:dsh-docker', order: 152, text: DOCKER_GUIDANCE })
    }

    /* ---------- 日志实时流（SSE） ---------- */

    /**
     * GET /logs/stream — 容器日志实时流（`docker logs --follow` → SSE）。
     *
     * 参数：`id`（单容器，老参数）或 `ids=a,b,c`（多容器，一条连接带多个源；聚合视图 /
     * Compose 项目日志走这条），`tail`（0~5000，缺省取配置；**0 = 不补历史只跟随**，
     * 客户端断线重连用，见 D133）、`timestamps`、`since`。
     *
     * 事件协议（每帧 `event:` + 单行 JSON `data:`）：
     *   - `ready` `{}` 执行管道真的起来了（多源时只有第一个源起来的那一次，见 readyOnStart）
     *   - `line`  `{"d":"..."}` stdout 分片 / `{"e":"..."}` stderr 分片
     *   - `line`  `{"id":"<容器 id>","d"|"e":"..."}` —— **仅多源**：这段字节属于哪个容器
     *   - `source-end`   `{"id":"<id>","code":<N|null>}` 该容器的 logs -f 自然退出（仅多源）
     *   - `source-error` `{"id":"<id>","message":"..."}` 该容器**这一条子流**失败（仅多源，
     *     spawn 错 / 远端通道被拒）：其余源继续跟着，整条连接不关
     *   - `end`   `{"reason":"container-exit","code":N}` 全部源结束（多源时 code 取最后一个
     *     非 null 的退出码，都 null 就是 null）
     *   - `end`   `{"reason":"output-limit"}` 宿主侧背压队列溢出（客户端消费跟不上，D133）
     *   - `error` `{"message":"..."}` 后关闭（参数 / 执行失败）
     * 心跳：每 15s 一帧 `: ping` 注释；客户端断开则静默中止执行器（SIGTERM 阶梯 /
     * channel KILL），不写任何帧。安全语义与快照 /logs 一致：只读能力，不走
     * allowMutations / allowExec 门控；loopback 围栏与容器 ID 白名单在外层校验。
     */
    const serveLogsStream = async (req: ReqLike, res: ResLike, params: URLSearchParams): Promise<void> => {
      const picked = pickTarget(params.get('target'))
      if (picked.name === undefined) {
        writeJson(res, 400, { error: picked.error ?? '无效的 target' })
        return
      }
      /*
       * 参数归一：`ids` 非空就按多源走，`id` 是单源的老参数。
       *
       * 为什么 `ids` 优先：它只会来自**按 ≥3 协议协商过的**新客户端，那里一条连接就代表
       * 整个聚合视图；而 `id` 是老客户端一次一个容器的路径。两者同时出现没有合理场景
       * （客户端两处代码各拼各的参数），按更强的那个解释比报 400 更宽容。
       */
      const rawIds = params.get('ids')
      const idsParam = rawIds === null ? [] : rawIds.split(',').map((id) => id.trim()).filter((id) => id !== '')
      const multiSource = idsParam.length > 0
      const idParam = params.get('id')

      let safeIds: string[] = []
      let safeId = ''
      if (multiSource) {
        /*
         * 先判数量、再逐条校验：两者同时不成立时（33 条里还夹着非法条目），先报出的
         * 原因不该取决于那条非法条目排在第几位——数量是一次比较，天然稳定。
         */
        if (idsParam.length > MAX_LOGS_SOURCES) {
          writeJson(res, 400, { error: `ids 最多 ${String(MAX_LOGS_SOURCES)} 个容器（收到 ${String(idsParam.length)} 个）` })
          return
        }
        try {
          // 逐条过同一道白名单：多源只是把「一个 id」重复 N 次，校验口径一个字都不能松
          safeIds = idsParam.map((id) => assertRef(id, 'container'))
        } catch (error) {
          writeJson(res, 400, { error: error instanceof Error ? error.message : String(error) })
          return
        }
      } else if (idParam !== null && idParam.trim() !== '') {
        try {
          safeId = assertRef(idParam, 'container')
        } catch (error) {
          writeJson(res, 400, { error: error instanceof Error ? error.message : String(error) })
          return
        }
      } else {
        // `ids=` 全空（像 `ids=,,`）与「一个参数都没给」是同一件事：没有源可跟
        writeJson(res, 400, { error: 'id 必填' })
        return
      }
      const built = apiFor(picked.name)
      const api = built.api
      if (api === undefined) {
        writeJson(res, 400, { error: built.error ?? '无法构造执行通道' })
        return
      }

      /*
       * tail=0 合法（D133）：客户端断线重连时不补历史、只要新行——否则服务端会把
       * 最后 tail 行当新行重推，客户端重复回填。空值/纯空白按「未传」处理（取默认），
       * 不要落进 Number('') === 0 的坑。
       */
      const tailParam = params.get('tail')
      const tail = tailParam === null || tailParam.trim() === '' ? live.logTailDefault : Number(tailParam)
      const timestampsParam = params.get('timestamps')
      const sinceParam = params.get('since')
      // SSE 与快照同一套 since 校验（D45）；非法直接 400（此处不在 POST 的 try 内）
      let since: string | undefined
      if (sinceParam !== null && sinceParam.trim() !== '') {
        try {
          since = assertSince(sinceParam)
        } catch (error) {
          writeJson(res, 400, { error: error instanceof Error ? error.message : String(error) })
          return
        }
      }
      // 单源 / 多源共用同一份取值规则（非法/越界交给 DockerApi 内的夹紧），抽出来
      // 只为了不让两个分支各写一遍再各自漂掉
      const logOptions = {
        tail: Number.isInteger(tail) ? tail : live.logTailDefault,
        timestamps: timestampsParam === '1' || timestampsParam === 'true',
        ...(since !== undefined ? { since } : {}),
      }

      await openSseStream(res, {
        reason: 'container-exit',
        // 文本尾部流：积压时丢最旧的帧继续跟随，不掐流（D153）
        overflow: 'drop',
        run: async (sendEvent, signal) => {
          /*
           * 单源老路径：帧仍是 `{d}` / `{e}`，不发 source-end / source-error。
           * 这条分支必须**逐字节不变**——老客户端（streamProtocol < 3）仍在用，
           * 多出的帧名它不认识，多出的字段则会破坏它对 `d` / `e` 的解析。
           */
          if (!multiSource) {
            /*
             * 事件协议与快照 /logs 完全一致，只多一个 end.reason——**只多一层合帧**
             * （D151）：docker 的分片边界与「一行日志」无关，逐 chunk 一帧时话痨容器
             * 每秒能推几千个事件，客户端的每事件固定开销（SSE 派发 + JSON.parse +
             * 拼残行）全砸在主线程上。合帧后客户端收到的仍是同一串字节，只是按窗口
             * 合并成了更少的帧。
             */
            const coalescer = createSseCoalescer({
              emit: (channel, text) => sendEvent('line', channel === 'd' ? { d: text } : { e: text }),
            })
            try {
              const result = await api.logsStream(safeId, logOptions, {
                onStdout: (chunk) => coalescer.push('d', chunk),
                onStderr: (chunk) => coalescer.push('e', chunk),
                onStart: readyOnStart(sendEvent),
              }, signal)
              return result.code
            } finally {
              /*
               * 收尾前把窗口里剩下的行推出去：`end` 帧必须排在它们之后——客户端按到达
               * 序落行，先收到 end 会当场切回快照，窗口里那批行就再也显示不出来了。
               */
              coalescer.flush()
              coalescer.dispose()
            }
          }

          /*
           * 多源：一条 SSE 带多个容器。
           *
           * 为什么不是「每个容器一条 EventSource」：宿主是 HTTP/1.1，浏览器对同一源只有
           * 6 条连接，而 EventSource 每条独占且**永不释放**——聚合视图一开，4 个服务就吃掉
           * 大半配额，其余请求开始排队（D165 / README「已知限制」）。一条连接带多源把占用
           * 压到 1 条，帧里补 `id` 让客户端把分片归位。别顺手把统计 / 事件流也改成这样：
           * 它们的分帧与去重都按「一条流一个源」写死了，是另一摊事。
           *
           * 两个必须守住的语义：
           *   - **单个源失败不许拖垮整条连接**：一个容器 spawn 不起来（或 SSH 配额已满，
           *     MAX_STREAMS_PER_TARGET 是 8）时，其余容器的日志必须照常跟着——否则一个
           *     坏容器就把整个聚合视图变成空白，还得用户手动重连才能看别的容器。所以每个
           *     源各自 try/catch，失败落一帧 `source-error`，`run` 整体永远正常 resolve。
           *   - **客户端断开只有一个 signal**（openSseStream 的 controller）：必须传给每一个
           *     源，否则用户关掉面板后没人认领的 `docker logs -f` 子进程 / SSH channel 会
           *     一直跑下去。
           */
          const sendReady = readyOnStart(sendEvent)
          let readySent = false
          /** ready 只发一帧：第一个源起来已足以证明「这条连接真有管道在跑」，每个源各发一遍是噪音。 */
          const sendReadyOnce = (): void => {
            if (readySent) return
            readySent = true
            sendReady()
          }
          // 按 ids 顺序记退出码（失败的源保持 null）：end 帧的 code 要从这里挑最后一个非 null
          const codes: Array<number | null> = safeIds.map(() => null)
          await Promise.all(safeIds.map(async (containerId, index) => {
            // 每个源一个合帧器：窗口是「这个容器」的，混用会让一个话痨容器把别人的行拖到
            // 它自己的窗口边界上（帧里虽然带 id，但同窗口内两源的字节顺序将不再是各自的到达序）
            const coalescer = createSseCoalescer({
              emit: (channel, text) => sendEvent('line', channel === 'd' ? { id: containerId, d: text } : { id: containerId, e: text }),
            })
            try {
              const result = await api.logsStream(containerId, logOptions, {
                onStdout: (chunk) => coalescer.push('d', chunk),
                onStderr: (chunk) => coalescer.push('e', chunk),
                onStart: sendReadyOnce,
              }, signal)
              /*
               * 该源的收尾顺序：先 flush 再发 source-end。
               *
               * flush 是**同步**的（emit 直接写帧），所以「窗口里最后一批 line」一定排在
               * 这一帧 source-end 之前——反过来客户端会提前把这个容器判成已结束，最后
               * 那批行要么丢归属、要么被当成下一条流的行。
               */
              coalescer.flush()
              sendEvent('source-end', { id: containerId, code: result.code })
              codes[index] = result.code
            } catch (error) {
              coalescer.flush()
              sendEvent('source-error', { id: containerId, message: error instanceof Error ? error.message : String(error) })
            } finally {
              coalescer.dispose()
            }
          }))
          /*
           * 全部源都结束了（正常退出或已各自报错）→ 正常返回，由 openSseStream 发既有的
           * `end{reason:'container-exit', code}`。
           *
           * code 的口径：**按 ids 顺序最后一个非 null 的退出码**，都 null 就是 null。多源时
           * 「整条连接的退出码」只有摘要意义（每个容器的真实退出码在各自的 source-end 里），
           * 取最后一个是有确定性的那一种，避免让「谁先退出」这种并发时序决定帧内容。
           */
          let finalCode: number | null = null
          for (const code of codes) if (code !== null) finalCode = code
          return finalCode
        },
      })
    }

    /**
     * GET /stats/stream — 容器资源占用实时流（`docker stats` → SSE）。
     *
     * 与日志流的**本质差异**：这条流不会自然结束（容器在跑，docker stats 就每秒
     * 出一行），关闭语义是「浏览器主动断」——EventSource.close() → res close →
     * 静默 abort。docker stats 因全部容器退出而自行退出时，发 `end`
     * （reason=stats-exit）让客户端回到快照轮询。
     *
     * 事件：`stats` 每行一个 ContainerStats JSON；`end` / `error` 同日志流。
     * 只读能力：不受 allowMutations / allowExec 门控。
     */
    const serveStatsStream = async (req: ReqLike, res: ResLike, params: URLSearchParams): Promise<void> => {
      const picked = pickTarget(params.get('target'))
      if (picked.name === undefined) {
        writeJson(res, 400, { error: picked.error ?? '无效的 target' })
        return
      }
      const rawIds = params.get('ids')
      let safeIds: string[]
      try {
        safeIds = (rawIds === null || rawIds.trim() === '' ? [] : rawIds.split(','))
          .map((id) => id.trim())
          .filter((id) => id !== '')
          .map((id) => assertRef(id, 'container'))
      } catch (error) {
        writeJson(res, 400, { error: error instanceof Error ? error.message : String(error) })
        return
      }
      const built = apiFor(picked.name)
      const api = built.api
      if (api === undefined) {
        writeJson(res, 400, { error: built.error ?? '无法构造执行通道' })
        return
      }

      await openSseStream(res, {
        reason: 'stats-exit',
        run: async (sendEvent, signal) => {
          /*
           * docker stats 的输出**不看 stdout 是不是 TTY**——它一律走 TTY 渲染器，
           * 每帧都被 ESC[H / ESC[K / ESC[J 包着，而且同一个采样会重复渲染两次：
           *   \x1b[H{"CPUPerc":"0.04%",...}\n\x1b[H{"CPUPerc":"0.04%",...} \x1b[K\n \x1b[K\n\x1b[J
           * 所以不能按行解析：行首是 ESC 不是 `{`，parseJsonLines 会把整行跳过，
           * 结果就是「流建上了、一个采样都不来」。这里直接抽取扁平的 {...} 对象——
           * docker stats 的 {{json .}} 字段全是标量、没有嵌套括号，抽取是安全的——
           * 再用与 /stats 快照同一个 parseStatsJson 归一，客户端拿到的形状与快照一致。
           * 同一 chunk 内的重复采样（键相同）只发一次，免得环形缓冲被重复点占掉半窗。
           */
          let pending = ''
          /*
           * 跨 chunk 去重：实测 docker stats 会把**同一个采样渲染两次**（约 500ms 一轮，
           * 0.04 / 0.04 / 0.16 / 0.16 …），两次是逐字节相同的 JSON 且可能落在不同 chunk 里。
           * 不去重的话，客户端 60 点环形缓冲会被重复点占掉一半窗口（实际只剩 ~30 秒）。
           * 去重键按**容器**记（D33）：此前只与紧邻上一条比较——单容器序列 A A 能去重，
           * 多容器交错 A B A B 就漏了；按 Name 各记上次值，交错情形同样覆盖。
           */
          const lastRawByName = new Map<string, string>()
          const handlers: StreamHandlers = {
            onStdout: (chunk) => {
              pending += chunk
              const re = /\{[^{}]*\}/g
              const found: string[] = []
              let consumed = 0
              let hit: RegExpExecArray | null
              while ((hit = re.exec(pending)) !== null) {
                found.push(hit[0])
                consumed = hit.index + hit[0].length
              }
              // 只丢已消费的前缀：半截 JSON（未闭合的对象）留给下一个 chunk
              if (consumed > 0) pending = pending.slice(consumed)
              // 对方吐的不是我们认识的输出时别让缓冲无限涨（最多留 4KB 尾巴）
              if (pending.length > 64 * 1024) pending = pending.slice(-4096)
              for (const raw of found) {
                const rows = parseStatsJson(raw)
                if (rows.length === 0) continue
                const key = rows[0]?.name === undefined || rows[0].name === '' ? raw : rows[0].name
                if (lastRawByName.get(key) === raw) continue
                lastRawByName.set(key, raw)
                for (const row of rows) sendEvent('stats', row)
              }
            },
            onStderr: (chunk) => sendEvent('line', { e: chunk }),
            onStart: readyOnStart(sendEvent),
          }
          const result = await api.statsStream(safeIds, handlers, signal)
          // 收尾：最后一个对象可能还没闭合（进程退出前只写了半行），能解析就发
          if (pending !== '') for (const row of parseStatsJson(pending)) sendEvent('stats', row)
          return result.code
        },
      })
    }

    /**
     * GET /events/stream — 容器事件活动流（`docker events` → SSE）。
     *
     * 与统计流同构：**不会自然结束**（docker events 会一直跟着 daemon 推），关闭
     * 语义是浏览器主动断；docker events 自己退出时发 `end`（reason=events-exit）。
     *
     * 帧：`event` 一条一个 ContainerEvent（已在服务端过白名单，见 docker.ts 的
     * EVENT_ACTIONS）；`line{e}` 透传 stderr；`end` / `error` 与其它流一致。
     * 只读能力：不受 allowMutations / allowExec 门控。
     */
    const serveEventsStream = async (req: ReqLike, res: ResLike, params: URLSearchParams): Promise<void> => {
      const picked = pickTarget(params.get('target'))
      if (picked.name === undefined) {
        writeJson(res, 400, { error: picked.error ?? '无效的 target' })
        return
      }
      const built = apiFor(picked.name)
      const api = built.api
      if (api === undefined) {
        writeJson(res, 400, { error: built.error ?? '无法构造执行通道' })
        return
      }

      await openSseStream(res, {
        reason: 'events-exit',
        run: async (sendEvent, signal) => {
          /*
           * docker events 与 docker stats 不同：输出是老老实实一行一个 JSON，没有 TTY
           * 渲染器的转义码，所以按行合帧即可（stats 那边才需要抽扁平对象）。这里**不能**
           * 学 stats 做「相同行去重」——两条内容完全一样的 health_status 是两次真实事件，
           * 去重会把活动条吞掉一半。
           */
          let pending = ''
          /** 帧里省略值为 null 的字段（agent 工具那边同样处理），客户端按缺失判断。 */
          const frame = (event: ContainerEvent): Record<string, unknown> => ({
            action: event.action,
            name: event.name,
            image: event.image,
            ...(event.composeProject === null ? {} : { composeProject: event.composeProject }),
            ...(event.time === null ? {} : { time: event.time }),
            ...(event.exitCode === null ? {} : { exitCode: event.exitCode }),
          })
          const handlers: StreamHandlers = {
            onStdout: (chunk) => {
              pending += chunk
              const parts = pending.split('\n')
              pending = parts.pop() ?? ''
              for (const line of parts) {
                const event = parseContainerEvent(line)
                if (event !== null) sendEvent('event', frame(event))
              }
              // 对方吐的不是我们认识的输出时别让缓冲无限涨（最多留 4KB 尾巴）
              if (pending.length > 64 * 1024) pending = pending.slice(-4096)
            },
            onStderr: (chunk) => sendEvent('line', { e: chunk }),
            onStart: readyOnStart(sendEvent),
          }
          const result = await api.eventsStream(handlers, signal)
          // 收尾：最后一行可能没换行符（进程退出前只写半行），能解析就发
          if (pending !== '') {
            const tail = parseContainerEvent(pending)
            if (tail !== null) sendEvent('event', frame(tail))
          }
          return result.code
        },
      })
    }

    /**
     * GET /images/pull/stream — 镜像拉取进度流（`docker pull` → SSE）。
     *
     * **变更能力**：拉取会写入目标机的镜像存储、占用磁盘与带宽，因此与
     * /action、/images/remove、/images/prune 同一把 allowMutations 门（未开启
     * 时 403，且不建流）。逐层进度天然是流，直接复用 ssh-exec 的长流通道；
     * 事件与日志流同构（line{d|e} / end{reason:pull-exit,code,ref} / error）。
     */
    const servePullStream = async (req: ReqLike, res: ResLike, params: URLSearchParams): Promise<void> => {
      if (!live.allowMutations) {
        writeJson(res, 403, { error: mutationsOffMessage() })
        return
      }
      const picked = pickTarget(params.get('target'))
      if (picked.name === undefined) {
        writeJson(res, 400, { error: picked.error ?? '无效的 target' })
        return
      }
      const refParam = params.get('ref')
      if (refParam === null || refParam.trim() === '') {
        writeJson(res, 400, { error: 'ref 必填' })
        return
      }
      let safeRef: string
      try {
        safeRef = assertImageRef(refParam, 'image')
      } catch (error) {
        writeJson(res, 400, { error: error instanceof Error ? error.message : String(error) })
        return
      }
      const built = apiFor(picked.name)
      const api = built.api
      if (api === undefined) {
        writeJson(res, 400, { error: built.error ?? '无法构造执行通道' })
        return
      }
      // run 回调里 TS 不保留 picked.name 的属性窄化，先落局部 const
      const targetName = picked.name

      await openSseStream(res, {
        reason: 'pull-exit',
        // 同日志流：逐层进度是文本尾部流，积压时丢最旧而不是把整条流掐掉（D153）
        overflow: 'drop',
        endData: () => ({ ref: safeRef }),
        run: async (sendEvent, signal) => {
          // 与日志流同一层合帧（D151）：docker pull 逐层刷进度时也是每秒几百行的流
          const coalescer = createSseCoalescer({
            emit: (channel, text) => sendEvent('line', channel === 'd' ? { d: text } : { e: text }),
          })
          /*
           * 使用审计拆成 start / end 两行（capability-use 是逐次事件，不是逐行日志）：
           * 开流记 start（宿主中途挂掉时至少「有人拉过这个镜像」还在），收尾记 end——
           * 被中止时 runner 以 code=null 落定，end 行省略 code；抛错则 ok=false + detail。
           */
          const useFields: CapabilityUseFields = { capability: 'allowMutations', source: 'http', action: 'image.pull', target: targetName, ref: safeRef }
          const startedAt = Date.now()
          auditCapabilityUse({ ...useFields, event: 'start' })
          try {
            const result = await api.pullStream(safeRef, {
              onStdout: (chunk) => coalescer.push('d', chunk),
              onStderr: (chunk) => coalescer.push('e', chunk),
              onStart: readyOnStart(sendEvent),
            }, signal)
            auditCapabilityUse({ ...useFields, event: 'end', ok: true, durationMs: Date.now() - startedAt, reason: 'pull-exit', ...(result.code === null ? {} : { code: result.code }) })
            return result.code
          } catch (error) {
            auditCapabilityUse({ ...useFields, event: 'end', ok: false, durationMs: Date.now() - startedAt, detail: error instanceof Error ? error.message : String(error) })
            throw error
          } finally {
            coalescer.flush()
            coalescer.dispose()
          }
        },
      })
    }

    /* ---------- HTTP 路由（loopback 围栏） ---------- */

    ctx.inject(['webServer'], (webCtx: Context) => {
      webCtx.effect(() => {
        const webServer = (webCtx as unknown as { webServer: WebServerLike }).webServer
        const dispose = webServer.register({
          kind: 'prefix',
          path: ROUTE_PREFIX,
          handler: async (req: ReqLike & AsyncIterable<Uint8Array>, res: ResLike) => {
            const loopback = isLoopbackRequestStrict(req)
            // 字面量环回同步判定（保持「第一拍就建流」的时序）；仅别名主机名才等 DNS
            if (loopback instanceof Promise) {
              if (!(await loopback)) {
                writeJson(res, 403, { error: 'forbidden: loopback-only' })
                return
              }
            } else if (!loopback) {
              writeJson(res, 403, { error: 'forbidden: loopback-only' })
              return
            }
            const sub = new URL(req.url ?? '/', 'http://loopback').pathname.slice(ROUTE_PREFIX.length)

            // 插件禁用时只保留 /config 读写与 /elevate 族：设置卡片靠前者渲染，也是重新启用插件的
            // 唯一 UI 入口（不能一并关掉，否则卡片消失就没有恢复路径了）；授权的宿主级操作也不该
            // 因为插件被停用而失效（用户先授权再启用插件同样合理）。其余数据路由一律 403——
            // agent 工具已由 refreshTools 同步清空，这里只管 HTTP 半体。
            if (!live.enabled && sub !== '/config' && !sub.startsWith('/elevate')) {
              writeJson(res, 403, { error: '插件已禁用（插件配置 → Docker 容器面板 → 启用插件）' })
              return
            }

            if (sub === '/config') {
              if (req.method === 'GET') {
                writeJson(res, 200, { ok: true, config: snapshot() })
                return
              }
              if (req.method !== 'POST') {
                writeJson(res, 405, { error: 'method not allowed: ' + String(req.method) })
                return
              }
              const body = await readJsonBody(req)
              if (body === undefined) {
                writeJson(res, 400, { error: 'invalid JSON body' })
                return
              }
              const patch: Record<string, unknown> = {}
              let warning: string | undefined
              for (const key of Object.keys(body)) {
                if (!KNOWN_CONFIG_KEYS.has(key)) {
                  writeJson(res, 400, { error: '未知配置项: ' + key })
                  return
                }
                if (key === 'clearTargets' || key === 'hostKeysRemove') continue
                patch[key] = body[key]
              }
              /*
               * **能力开关不能凭空升**：提权只认宿主侧来源（启动环境变量，或带外确认写下的授权）。
               * HTTP 侧给 true 而没有授权一律驳回并说清两条路。这不是「输入不合法」而是「没获授权」——
               * 文案必须给出**怎么授权**，否则用户会对着一个点不动的开关反复点。
               * 校验放在**落盘之前**（与下面那条 normalizeConfig 干跑同一口径）：错误路径不留脏配置。
               */
              for (const [key, spec] of [['allowMutations', CAP_MUTATIONS], ['allowExec', CAP_EXEC]] as const) {
                if (patch[key] === true && !capabilityGranted(spec)) {
                  writeJson(res, 400, { error: capabilityDeniedMessage(spec, { inPlace: true }) })
                  return
                }
              }
              // 空 targets 只在显式 clearTargets 时才允许清空：卡片若因启动竞态拿到
              // 空列表，保存不会再把已配置的目标抹掉（防数据丢失）
              if (Array.isArray(patch.targets) && patch.targets.length === 0 && body.clearTargets !== true) {
                const existing = targetsNow()
                if (existing.length > 0) {
                  delete patch.targets
                  warning = `已忽略空的目标列表：当前仍有 ${String(existing.length)} 个目标。请刷新设置卡片后重试（若确实要清空全部目标，请逐个删除后保存）。`
                }
              }
              // 凭证补全必须在写盘之前：否则提交的 targets 会把密码清空
              if (patch.targets !== undefined) {
                // 读路径会丢弃的条目（重名 / 空名 / 超 64 字符）要有信号（D35）：否则
                // 面板只看到留下来的那条，下一次保存把丢弃结果固化，另一台主机凭空消失
                const rawTargets = Array.isArray(patch.targets) ? patch.targets.length : 0
                patch.targets = mergeTargetSecrets(targetsNow(), patch.targets)
                /*
                 * 计数必须取**真正会丢弃**的那一步（D89）：mergeTargetSecrets 是 1:1 的
                 * map（只补凭证、从不删条目），丢弃发生在 sanitizeTargets（读路径与
                 * normalizeConfig 都用它）—— 原来的判据恒为 false，warning 是死代码。
                 */
                const keptTargets = sanitizeTargets(patch.targets)?.length ?? 0
                if (rawTargets > keptTargets) {
                  warning = [warning, `目标列表中有 ${String(rawTargets - keptTargets)} 条无效条目（重名 / 名称为空 / 超过 64 字符）已被丢弃。`].filter((part) => part !== undefined && part !== '').join(' ')
                }
              }
              /*
               * hostKeys 采用「并集合并 + 显式删除」（D10）：客户端表单快照里的
               * hostKeys 落后于运行期（打开卡片期间可能刚记录了新指纹），整表覆盖
               * 会把 TOFU 钉扎回退掉。传上来的记录按 host:port 并入现有记录；
               * 删除某条记录走显式的 hostKeysRemove: [{host, port}]。
               */
              if (patch.hostKeys !== undefined || body.hostKeysRemove !== undefined) {
                let removeRequested = false
                const removeKeys = new Set<string>()
                if (Array.isArray(body.hostKeysRemove)) {
                  for (const raw of body.hostKeysRemove) {
                    if (typeof raw !== 'object' || raw === null) continue
                    const item = raw as Record<string, unknown>
                    const host = typeof item.host === 'string' ? item.host.trim().toLowerCase() : ''
                    const port = typeof item.port === 'number' && Number.isInteger(item.port) ? item.port : 22
                    if (host !== '') removeKeys.add(`${host}:${String(port)}`)
                  }
                  removeRequested = true
                } else if (body.hostKeysRemove !== undefined) {
                  // 形状非法不能静默忽略（D109）：用户点了「删除」却什么都没发生，且没有任何反馈
                  warning = [warning, 'hostKeysRemove 必须是 [{host, port}] 数组，本条已忽略。'].filter((part) => part !== undefined && part !== '').join(' ')
                }
                patch.hostKeys = mergeHostKeys(live.hostKeys, patch.hostKeys ?? [])
                /*
                 * 删除在并集**之后**生效（D109）：同一请求既带 hostKeys 又带 hostKeysRemove 时，
                 * 「删除」必须赢 —— 否则手写请求 / 旧客户端会把刚删掉的指纹又并回来，同样没有提示。
                 */
                if (removeKeys.size > 0) {
                  const merged = patch.hostKeys as HostKeyRecord[]
                  const kept = merged.filter((record) => !removeKeys.has(`${record.host}:${String(record.port)}`))
                  patch.hostKeys = kept
                  if (removeRequested && kept.length === merged.length) {
                    warning = [warning, '要删除的主机指纹记录不存在（可能已被别处删除）。'].filter((part) => part !== undefined && part !== '').join(' ')
                  }
                }
              }
              // 校验必须在**落盘之前**。原先只有 applySection 会做校验，而它跑在
              // scope.update 之后：值不合法的 patch 已经被写进 settings.yaml，随后
              // applySection 抛出，异常穿到宿主 HTTP 层 → 用户收到一个**没有正文的
              // 400**，而配置里已经留下一个非法值；下次启动 normalizeConfig 再抛，
              // 整段 docker 配置（含目标列表）静默退回默认。这里先按同一套合并规则
              // 干跑一遍 normalizeConfig：不合法就地 400 并带上原因，不写盘。
              {
                const dryRun: Record<string, unknown> = { ...live, ...patch }
                if (patch.hostKeys === undefined) dryRun.hostKeys = live.hostKeys
                try {
                  normalizeConfig(dryRun)
                } catch (error) {
                  writeJson(res, 400, { error: '配置无效: ' + (error instanceof Error ? error.message : String(error)) })
                  return
                }
              }
              const scope = settingsScope
              if (scope !== undefined) {
                try {
                  await scope.update(patch)
                } catch (error) {
                  writeJson(res, 400, { error: error instanceof Error ? error.message : String(error) })
                  return
                }
                // volatile 更新事件会触发 applySection；无事件时也应用一次（幂等）
              }
              // applySection 也可能抛（tools.register / systemPrompt.section，D36）：
              // 此时配置已落盘，必须把原因带回给用户，而不是一个空 400/500。
              // forceRefreshTools：保存路径无条件重注册一次（幂等），这样「上一次只注册了
              // 一半」的状态能被用户的**重试**修复，而不是必须等到下一次真实配置变化（D107）。
              try {
                applySection(patch, { forceRefreshTools: true })
              } catch (error) {
                writeJson(res, 500, { error: '配置已保存但应用失败：' + (error instanceof Error ? error.message : String(error)) })
                return
              }
              writeJson(res, 200, { ok: true, config: snapshot(), ...(warning === undefined ? {} : { warning }) })
              return
            }

            /*
             * 一键连接本机：把「加一个 local 目标」从「先开设置卡片、手填名字、保存、再切回来」压缩成一下。
             * 为什么是显式按钮而不是隐式默认目标：空 `targets` 的语义（= 用户没配、面板给引导）不能被悄悄改掉。
             * 只读探测的结果作为 `message` 回传（含「daemon 未启动 / CLI 缺失」的成因），
             * 客户端拿它直接给提示，不必再单独发一次 /probe 往返。
             */
            if (sub === '/connect-local') {
              if (req.method !== 'POST') {
                writeJson(res, 405, { error: 'method not allowed: ' + String(req.method) })
                return
              }
              if (!hasSameOriginProof(req)) {
                writeJson(res, 403, { error: originProofHint(req) })
                return
              }
              const outcome = await connectLocal()
              if (!outcome.ok) {
                writeJson(res, outcome.code, { error: outcome.error })
                return
              }
              writeJson(res, 200, { ok: true, result: outcome.result, config: snapshot() })
              return
            }

            if (sub === '/targets') {
              if (req.method !== 'GET' && req.method !== 'POST') {
                writeJson(res, 405, { error: 'method not allowed: ' + String(req.method) })
                return
              }
              const books = readTtyBooks(settingsApi)
              writeJson(res, 200, {
                ok: true,
                targets: targetsNow().map((target) => {
                  const { resolved, error } = resolveTarget(target, books)
                  return {
                    name: target.name,
                    kind: target.kind,
                    ...(resolved === undefined ? { error } : { label: resolved.kind === 'local' ? '本机' : sshTarget(resolved.spec as SshSpec) }),
                  }
                }),
              })
              return
            }

            // SSE 长连接（GET）：必须放在下面「非 POST 一律 405」之前，否则
            // GET 会被 method 检查拦掉。四条流共用 openSseStream，各自只做参数
            // 校验与执行器接线；响应由对应的 serve*Stream 长持有。
            const serveStream = sub === '/logs/stream'
              ? serveLogsStream
              : sub === '/stats/stream'
                ? serveStatsStream
                : sub === '/events/stream'
                  ? serveEventsStream
                  : sub === '/images/pull/stream'
                    ? servePullStream
                    : undefined
            if (serveStream !== undefined) {
              if (req.method !== 'GET') {
                writeJson(res, 405, { error: 'method not allowed: ' + String(req.method) })
                return
              }
              // 四条 SSE 都要有「同源证明」（D32）：无 Origin 且无 Sec-Fetch-Site 的
              // 请求（旧 Safari / 部分 WebView / 裸 curl）在长流端点上拒绝——浏览器
              // 的 EventSource / fetch 同源请求都会带其中之一；桌面壳的转发链只带
              // Cookie，由 hasSameOriginProof 内的例外放行（D139）
              if (!hasSameOriginProof(req)) {
                ctx.logger.warn(`dsh-docker: 拒绝无同源证明的实时流请求 ${sub}（${originProofHint(req)}）`)
                writeJson(res, 403, { error: '缺少同源证明（需要 Origin 或 Sec-Fetch-Site: same-origin）：实时流端点拒绝无来源请求' })
                return
              }
              const params = new URL(req.url ?? '/', 'http://loopback').searchParams
              await serveStream(req, res, params)
              return
            }

            // 变更类端点（写操作）同样要求同源证明（D32）；/config 刻意不在名单里：
            // 它是禁用状态下的唯一恢复入口，跨站 POST 已由 loopback + Origin 比对拦住
            if (req.method === 'POST' && MUTATION_SUBROUTES.has(sub) && !hasSameOriginProof(req)) {
              ctx.logger.warn(`dsh-docker: 拒绝无同源证明的变更请求 ${sub}（${originProofHint(req)}）`)
              writeJson(res, 403, { error: '缺少同源证明（需要 Origin 或 Sec-Fetch-Site: same-origin）：变更端点拒绝无来源请求' })
              return
            }

            if (req.method !== 'POST') {
              writeJson(res, 405, { error: 'method not allowed: ' + String(req.method) })
              return
            }
            const body = await readJsonBody(req)
            if (body === undefined) {
              writeJson(res, 400, { error: 'invalid JSON body' })
              return
            }

            /*
             * 就地提权（三条子路由）。放在这里而不是 `/config` 旁边是有原因的：**同源证明由上面那段
             * MUTATION_SUBROUTES 判据提供**，而它只覆盖它后面这段分发——写在它前面就是裸的了
             * （跨站页面能撤销授权、能反复试确认）。三条都做成 POST 也是为了复用那一条判据
             * （它只认 POST；`status` 做成 GET 会绕过）。
             */
            if (sub === '/elevate' || sub === '/elevate/status' || sub === '/elevate/revoke') {
              const capability = typeof body.capability === 'string' ? body.capability : ''
              const spec = CAPABILITIES.get(capability)
              if (spec === undefined) {
                writeJson(res, 400, { error: `未知能力开关: ${capability === '' ? '(空)' : capability}（可用：${[...CAPABILITIES.keys()].join(' / ')}）` })
                return
              }
              if (sub === '/elevate/status') {
                writeJson(res, 200, elevation.status(spec.env))
                return
              }
              if (sub === '/elevate/revoke') {
                // 降权零门槛：不要求任何确认（紧急刹车不等重启）。撤销带来的重算由 elevation 的
                // onGrantChange 回调负责（不变量 6），这里不再补一刀。
                const revoked = elevation.revoke(spec.env)
                writeJson(res, 200, { ok: true, revoked, config: snapshot() })
                return
              }
              const result = elevation.begin(spec.env)
              if (result.status === 'rate-limited') {
                writeJson(res, 429, { ...result, error: '短时间内发起太多次，请稍后再试' })
                return
              }
              if (result.status === 'error') {
                writeJson(res, 500, result)
                return
              }
              writeJson(res, 200, result)
              return
            }
            // 跨目标聚合（0.15.0）：target='*' 不是目标名，必须在 pickTarget 之前分流，
            // 否则会被当成「未知目标」直接 400
            const wantsAllTargets = typeof body.target === 'string' && body.target.trim() === '*'
            if (wantsAllTargets && (sub === '/containers' || sub === '/attention')) {
              const names = targetsFor('*')
              try {
                if (sub === '/containers') {
                  const groups = await aggregateAcrossTargets(names, (targetApi) => targetApi.listContainers(body.all === true))
                  writeJson(res, 200, { ok: true, groups })
                  return
                }
                const groups = await aggregateAcrossTargets(names, (targetApi) => targetApi.attention())
                writeJson(res, 200, { ok: true, groups })
              } catch (error) {
                writeJson(res, 500, { error: error instanceof Error ? error.message : String(error) })
              }
              return
            }

            const picked = pickTarget(body.target)
            if (picked.name === undefined) {
              writeJson(res, 400, { error: picked.error ?? '无效的 target' })
              return
            }
            const built = apiFor(picked.name)
            if (built.api === undefined) {
              writeJson(res, 400, { error: built.error ?? '无法构造执行通道' })
              return
            }
            // 目标级抛错打标记，由外层 catch 分流成 200 + ok:false（见 guardTargetFailures）
            const api = guardTargetFailures(built.api)

            // 引用白名单在路由层先跑一次（D37）：非法引用是**客户端**错误，直接 400
            // 带原因——落到 DockerApi 里才抛的话会被外层 catch 统一写成 500。
            // D97：`/action` 的 id、`/stats` 的 ids[] 与 `/exec` 的空 command 原先漏在外，
            // 于是同一类错误在有的路由是 400、有的是 500。
            try {
              if ((sub === '/inspect' || sub === '/logs' || sub === '/exec' || sub === '/action' || sub === '/top' || sub === '/diagnose' || sub === '/run-command') && typeof body.id === 'string') assertRef(body.id, 'container')
              if (sub === '/stats' && Array.isArray(body.ids)) {
                for (const id of body.ids) if (typeof id === 'string') assertRef(id, 'container')
              }
              if ((sub === '/images/inspect' || sub === '/images/remove') && typeof body.ref === 'string') assertImageRef(body.ref, 'image')
              if ((sub === '/networks/inspect' || sub === '/networks/remove') && typeof body.name === 'string') assertName(body.name, 'network')
              if ((sub === '/volumes/inspect' || sub === '/volumes/remove') && typeof body.name === 'string') assertName(body.name, 'volume')
              // /diagnose 的 since 也在这里先校验（与 /logs 的 since 同一口径，D45）：放进
              // switch 里抛的话会被外层 catch 写成 500，而非法 since 是**客户端**错误。
              if (sub === '/diagnose' && typeof body.since === 'string' && body.since.trim() !== '') assertSince(body.since)
              if (sub === '/exec' && typeof body.command === 'string' && body.command.trim() === '') {
                writeJson(res, 400, { error: 'command 不能为空' })
                return
              }
            } catch (error) {
              writeJson(res, 400, { error: error instanceof Error ? error.message : String(error) })
              return
            }

            try {
              switch (sub) {
                case '/probe': {
                  writeJson(res, 200, { ok: true, probe: await api.probe() })
                  return
                }
                case '/containers': {
                  writeJson(res, 200, { ok: true, containers: await api.listContainers(body.all === true) })
                  return
                }
                case '/attention': {
                  // limit 可由调用方给（D101）：面板想一次拿全量时不必被隐式钉在默认 100
                  const limitRaw = body.limit
                  const limit = typeof limitRaw === 'number' && Number.isInteger(limitRaw)
                    ? Math.min(Math.max(limitRaw, 1), 500)
                    : undefined
                  const attention = await api.attention(limit === undefined ? undefined : { limit })
                  writeJson(res, 200, { ok: true, items: attention.items, total: attention.total, truncated: attention.truncated, degraded: attention.degraded })
                  return
                }
                case '/inspect': {
                  if (typeof body.id !== 'string') {
                    writeJson(res, 400, { error: 'id 必填' })
                    return
                  }
                  writeJson(res, 200, { ok: true, details: await api.inspect([body.id]) })
                  return
                }
                case '/stats': {
                  const ids = Array.isArray(body.ids) ? body.ids.filter((id): id is string => typeof id === 'string') : []
                  writeJson(res, 200, { ok: true, stats: await api.stats(ids) })
                  return
                }
                case '/logs': {
                  if (typeof body.id !== 'string') {
                    writeJson(res, 400, { error: 'id 必填' })
                    return
                  }
                  const tail = typeof body.tail === 'number' && Number.isInteger(body.tail) ? body.tail : live.logTailDefault
                  writeJson(res, 200, {
                    ok: true,
                    logs: await api.logs(body.id, {
                      tail,
                      timestamps: body.timestamps === true,
                      // `/logs` 此前裸透传（D98）：同一参数在 `/logs/stream` 与 agent 工具上是 400/抛错，
                      // 在快照路由上却变成 docker 的参数错误再被写成 500。空/纯空白 = 未传。
                      ...(typeof body.since === 'string' && body.since.trim() !== '' ? { since: assertSince(body.since) } : {}),
                    }),
                  })
                  return
                }
                // 批一的两条只读路由：位置紧挨 /logs /stats（同一段「单容器采集」语义）。
                // 都不是 MUTATION_SUBROUTES 成员——只读、不走审计、不要求同源证明。
                case '/top': {
                  if (typeof body.id !== 'string') {
                    writeJson(res, 400, { error: 'id 必填' })
                    return
                  }
                  writeJson(res, 200, { ok: true, top: await api.top(body.id) })
                  return
                }
                case '/diagnose': {
                  if (typeof body.id !== 'string') {
                    writeJson(res, 400, { error: 'id 必填' })
                    return
                  }
                  /*
                   * 批三：多一个 `history` 字段（最近 N 条样本 + 趋势）。**没有新路由**——历史不是新的
                   * 采集面，只是同一份诊断的第二种视图（理由见 `diagnoseWithHistory` 的注释）。
                   *
                   * logTail / since 的默认值与夹紧仍在 api.diagnose 里做（agent 工具同一份语义）；
                   * 非法 since 已经在上面的引用白名单段拦成 400。
                   */
                  const { diagnosis, history } = await diagnoseWithHistory(api, picked.name, body.id, {
                    logTail: body.logTail,
                    since: body.since,
                    history: body.history,
                  })
                  // 三路降级的**原因**不进 HTTP 契约（客户端按 evidence 的 null 渲染 `—`，
                  // findings 里已有 *-unavailable 说明）；这里只回契约里的 diagnosis + history。
                  writeJson(res, 200, { ok: true, diagnosis: { ...diagnosis, history } })
                  return
                }
                // 批二：现场还原。只读（inspect + 纯文本推导），不执行任何命令、不走审计。
                case '/run-command': {
                  if (typeof body.id !== 'string') {
                    writeJson(res, 400, { error: 'id 必填' })
                    return
                  }
                  writeJson(res, 200, { ok: true, recreate: await api.recreate(body.id) })
                  return
                }
                case '/images': {
                  writeJson(res, 200, { ok: true, images: await api.images() })
                  return
                }
                case '/images/inspect': {
                  if (typeof body.ref !== 'string' || body.ref.trim() === '') {
                    writeJson(res, 400, { error: 'ref 必填' })
                    return
                  }
                  writeJson(res, 200, { ok: true, image: await api.imageInspect(body.ref) })
                  return
                }
                case '/images/remove': {
                  if (!live.allowMutations) {
                    writeJson(res, 403, { error: mutationsOffMessage() })
                    return
                  }
                  if (typeof body.ref !== 'string' || body.ref.trim() === '') {
                    writeJson(res, 400, { error: 'ref 必填' })
                    return
                  }
                  // 能力闸之后包审计（「使用 = 过了闸」；403 不记）——下同；
                  // ref 先落局部 const：回调里 TS 不保留属性窄化
                  const ref = body.ref
                  writeJson(res, 200, { ok: true, result: await audited({ capability: 'allowMutations', source: 'http', action: 'image.remove', target: picked.name, ref }, () => api.imageRemove(ref)) })
                  return
                }
                case '/images/prune': {
                  if (!live.allowMutations) {
                    writeJson(res, 403, { error: mutationsOffMessage() })
                    return
                  }
                  writeJson(res, 200, { ok: true, result: await audited({ capability: 'allowMutations', source: 'http', action: 'image.prune', target: picked.name }, () => api.imagePrune()) })
                  return
                }
                case '/networks': {
                  writeJson(res, 200, { ok: true, networks: await api.networks() })
                  return
                }
                case '/networks/inspect': {
                  if (typeof body.name !== 'string' || body.name.trim() === '') {
                    writeJson(res, 400, { error: 'name 必填' })
                    return
                  }
                  writeJson(res, 200, { ok: true, network: await api.networkInspect(body.name) })
                  return
                }
                case '/networks/remove': {
                  if (!live.allowMutations) {
                    writeJson(res, 403, { error: mutationsOffMessage() })
                    return
                  }
                  if (typeof body.name !== 'string' || body.name.trim() === '') {
                    writeJson(res, 400, { error: 'name 必填' })
                    return
                  }
                  const name = body.name
                  writeJson(res, 200, { ok: true, result: await audited({ capability: 'allowMutations', source: 'http', action: 'network.remove', target: picked.name, ref: name }, () => api.networkRemove(name)) })
                  return
                }
                case '/networks/prune': {
                  if (!live.allowMutations) {
                    writeJson(res, 403, { error: mutationsOffMessage() })
                    return
                  }
                  writeJson(res, 200, { ok: true, result: await audited({ capability: 'allowMutations', source: 'http', action: 'network.prune', target: picked.name }, () => api.networkPrune()) })
                  return
                }
                case '/volumes': {
                  writeJson(res, 200, { ok: true, volumes: await api.volumes() })
                  return
                }
                // 批二：磁盘占用（只读）。`totals` 是宿主内部字段（工具用它报「还有多少」），
                // 契约 §2.1 里没有它，所以这里显式挑字段，不做整对象透传。
                case '/system-df': {
                  const usage = await api.systemDf()
                  writeJson(res, 200, {
                    ok: true,
                    disk: {
                      summary: usage.summary,
                      images: usage.images,
                      volumes: usage.volumes,
                      buildCache: usage.buildCache,
                      truncated: usage.truncated,
                      degraded: usage.degraded,
                      degradedReason: usage.degradedReason,
                    },
                  })
                  return
                }
                case '/volumes/inspect': {
                  if (typeof body.name !== 'string' || body.name.trim() === '') {
                    writeJson(res, 400, { error: 'name 必填' })
                    return
                  }
                  writeJson(res, 200, { ok: true, volume: await api.volumeInspect(body.name) })
                  return
                }
                case '/volumes/remove': {
                  if (!live.allowMutations) {
                    writeJson(res, 403, { error: mutationsOffMessage() })
                    return
                  }
                  if (typeof body.name !== 'string' || body.name.trim() === '') {
                    writeJson(res, 400, { error: 'name 必填' })
                    return
                  }
                  const name = body.name
                  writeJson(res, 200, { ok: true, result: await audited({ capability: 'allowMutations', source: 'http', action: 'volume.remove', target: picked.name, ref: name }, () => api.volumeRemove(name)) })
                  return
                }
                case '/volumes/prune': {
                  if (!live.allowMutations) {
                    writeJson(res, 403, { error: mutationsOffMessage() })
                    return
                  }
                  writeJson(res, 200, { ok: true, result: await audited({ capability: 'allowMutations', source: 'http', action: 'volume.prune', target: picked.name }, () => api.volumePrune()) })
                  return
                }
                case '/action': {
                  if (!live.allowMutations) {
                    writeJson(res, 403, { error: mutationsOffMessage() })
                    return
                  }
                  if (typeof body.id !== 'string') {
                    writeJson(res, 400, { error: 'id 必填' })
                    return
                  }
                  const action = body.action
                  if (action !== 'start' && action !== 'stop' && action !== 'restart' && action !== 'remove') {
                    writeJson(res, 400, { error: 'action 必须是 start / stop / restart / remove' })
                    return
                  }
                  const id = body.id
                  writeJson(res, 200, { ok: true, result: await audited({ capability: 'allowMutations', source: 'http', action: `container.${action}`, target: picked.name, ref: id }, () => api.action({ action, id })) })
                  return
                }
                case '/exec': {
                  if (!live.allowExec) {
                    writeJson(res, 403, { error: execOffMessage() })
                    return
                  }
                  if (typeof body.id !== 'string' || typeof body.command !== 'string') {
                    writeJson(res, 400, { error: 'id 与 command 必填' })
                    return
                  }
                  const timeoutSec = typeof body.timeoutSec === 'number' && Number.isInteger(body.timeoutSec) ? body.timeoutSec : live.execTimeoutSec
                  const id = body.id
                  const command = body.command
                  // exec 的退出码是命令自己的结果（非 0 不是 docker 报错）：ok 只随 api 成败；
                  // 命令随行进日志（这是要写进 README 的代价）——截断与控制字符转义由 helper 统一做
                  writeJson(res, 200, { ok: true, result: await audited({ capability: 'allowExec', source: 'http', action: 'exec', target: picked.name, ref: id }, () => api.exec(id, command, timeoutSec * 1000), (row) => `code=${String(row.code)} cmd=${row.command}`) })
                  return
                }
                default: {
                  writeJson(res, 404, { error: 'unknown route: ' + sub })
                }
              }
            } catch (error) {
              const message = error instanceof Error ? error.message : String(error)
              /*
               * 目标级失败（SSH 不可达 / 密钥读不到 / docker 不在）不是服务端 bug：
               * 按多目标聚合的同一口径回 200 + ok:false，客户端两条路都取 payload.error
               * （client-src 的 request()：!response.ok 与 ok === false 都抛 error），
               * 面板显示的文案不变，但语义对了——500 该留给真正的服务端故障。
               */
              if (isTargetFailure(error)) {
                writeJson(res, 200, { ok: false, target: picked.name, error: message })
                return
              }
              writeJson(res, 500, { error: message })
            }
          },
        })
        return () => dispose()
      }, 'dsh-docker: web routes')
    })

    /* ---------- settings ---------- */

    ctx.inject(['settings'], (settingsCtx: Context) => {
      settingsCtx.effect(() => {
        const scope = settingsEntryScope(settingsCtx, 'docker')
        if (scope === undefined) return () => {}
        // 卡片是自定义页（plugins.row.config），别再让 DSH 为本 entry 自动生成一份。
        const offAutoPage = suppressAutoSettingsPage(settingsCtx, ctx)
        settingsScope = scope
        settingsForms = (settingsCtx as unknown as { settings: SettingsFormsLike }).settings
        settingsApi = { get: (ns: string) => readSettingsEntry(settingsCtx, ns) }
        // 立刻读一次 resolved 值（schema 默认值 ← composition base ← 用户层）。
        // 走 applySection 而不是直接 normalizeConfig：能力开关的**配置值**要一起记下来（见
        // configuredCapabilities），否则此后的就地提权重算会拿折叠后的 false 当输入。
        const resolved = scope.get()
        if (typeof resolved === 'object' && resolved !== null) {
          applySection(resolved as Record<string, unknown>, { forceRefreshTools: true })
        }
        const diag = (resolved ?? {}) as Record<string, unknown>
        console.log(`[dsh-docker] settings resolved (keys=${Object.keys(diag).join('|')}, targets=${Array.isArray(diag.targets) ? String(diag.targets.length) : 'not-array'}, hostKeys=${Array.isArray(diag.hostKeys) ? String(diag.hostKeys.length) : 'not-array'})`)
        refreshTools()
        refreshAnnouncement()
        const off = scope.onChanged(() => applySection(scope.get()))
        return () => {
          off()
          offAutoPage()
          settingsScope = undefined
          settingsForms = undefined
          settingsApi = undefined
        }
      }, 'dsh-docker: settings')
    })

    /* ---------- 能力公告 ---------- */

    ctx.inject(['systemPrompt'], (promptCtx: Context) => {
      promptCtx.effect(() => {
        systemPromptApi = (promptCtx as unknown as { systemPrompt: SystemPromptLike }).systemPrompt
        refreshAnnouncement()
        return () => {
          systemPromptApi = undefined
          if (announcementDispose !== undefined) {
            try {
              announcementDispose()
            } catch {
              /* 已注销 */
            }
            announcementDispose = undefined
          }
        }
      }, 'dsh-docker: announcement')
    })

    /* ---------- 卸载清理 ---------- */

    ctx.effect(() => {
      return () => {
        // 先收掉长流（结束响应 + 中止 docker logs -f），再关连接池
        closeAllStreams()
        remote.disposeAll()
      }
    }, 'dsh-docker: cleanup')

    console.log(`[dsh-docker] mounted (bin=${live.dockerBin}, targets=${String(live.targets.length)}, allowMutations=${String(live.allowMutations)}, allowExec=${String(live.allowExec)})`)
  },
})

export const { name, inject, apply } = plugin

/* ------------------------------------------------------------------ *
 * 供 scripts/smoke.mjs 直接复用的纯函数（解析器回归）
 * ------------------------------------------------------------------ */

export { parsePsJson, parseStatsJson, parseInspectJson, assertBin, assertImageRef, parseImageInspectJson, parseImageHistoryJson, parseImageHistoryText, DockerApi }
export type { Runner } from './docker.js'
