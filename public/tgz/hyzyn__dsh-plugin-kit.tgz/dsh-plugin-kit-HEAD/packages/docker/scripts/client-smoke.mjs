#!/usr/bin/env node
/**
 * @hyzyn/dsh-docker — 浏览器半体装载回归（无浏览器，最小 DOM / React / fetch 桩）。
 *
 * 目的：client.js 是随包发布的构建产物，语法或顶层引用一旦出错，只有用户
 * 打开页面时才会暴露。这里在 Node 里用最小桩执行它，验证：
 *   - window.__ModuleLoader__.load 的 id 与 factory 形状正确
 *   - factory 只 require 平台 seed 提供的模块（react / react/jsx-runtime /
 *     react-dom/client），不会引入未提供的依赖
 *   - apply 注册了 settings.plugin.item 卡片且 key 为 settings 命名空间 `docker`
 *   - 侧边栏入口挂载在「找不到宿主侧边栏」时安静降级，不抛异常
 *   - 卸载函数可重复调用（宿主热重载路径）
 *   - ttyConnbar 集成：SSH 会话按连接簿名 / host:port 命中目标才插入「容器」
 *     按钮；未命中、非 SSH、tty 未安装三种情况都不报错
 *
 * 用法：pnpm --filter @hyzyn/dsh-docker build && node scripts/client-smoke.mjs
 */
import { strict as assert } from 'node:assert'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const code = readFileSync(join(root, 'client.js'), 'utf8')

/**
 * 还原 esbuild 的 ASCII 转义，便于断言中文文案：
 * 码位 ≥ 0x100 是 \uXXXX（中文），< 0x100 是 \xHH（间隔号 · 这类）。
 * 只处理 \uXXXX 会漏掉后者，断言里会莫名差一个字符。
 */
function decodeBundle(text) {
  return text
    .replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
    .replace(/\\x([0-9a-fA-F]{2})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
}

const results = []
/*
 * 看门狗（D71）：任一用例挂起不该把整个脚本永久挂住（CI 会一直转到超时被杀）。
 * 两层：单用例 15s（挂起的用例标失败，其余继续跑）+ 全局 90s（兜底，直接退出 1）。
 */
// 25s > ssh 建连超时 20s（D122）：否则「目标不回 RST」的环境里，
// 用例会被看门狗报成「用例超时」，把真因盖住
const CASE_TIMEOUT_MS = 25_000
const WATCHDOG_MS = 90_000
const watchdog = setTimeout(() => {
  const last = [...results].reverse().find((result) => result.ok)
  console.error(`\n[dsh-docker] 看门狗超时（${String(WATCHDOG_MS / 1000)}s），脚本挂起；最后通过的用例：${last === undefined ? '(无)' : last.name}`)
  process.exit(1)
}, WATCHDOG_MS)
async function test(name, fn) {
  let timer = null
  try {
    await Promise.race([
      Promise.resolve().then(fn),
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(`用例超时（${String(CASE_TIMEOUT_MS / 1000)}s）`)), CASE_TIMEOUT_MS)
      }),
    ])
    results.push({ name, ok: true })
  } catch (error) {
    results.push({ name, ok: false, message: error instanceof Error ? error.message : String(error) })
  } finally {
    if (timer !== null) clearTimeout(timer)
  }
}

/* ------------------------------------------------------------------ *
 * 最小 DOM / React / fetch 桩
 * ------------------------------------------------------------------ */

function makeElement(tag) {
  const element = {
    tagName: String(tag).toUpperCase(),
    className: '',
    dataset: {},
    style: {},
    children: [],
    parentElement: null,
    isConnected: false,
    id: '',
    textContent: '',
    innerHTML: '',
    setAttribute() {},
    addEventListener() {},
    removeEventListener() {},
    appendChild(child) {
      child.parentElement = element
      element.children.push(child)
      return child
    },
    remove() {},
    closest() { return null },
    querySelector() { return null },
    querySelectorAll() { return [] },
    contains() { return false },
    matches() { return false },
  }
  return element
}

const documentStub = {
  head: makeElement('head'),
  body: makeElement('body'),
  createElement: (tag) => makeElement(tag),
  getElementById: () => null,
  querySelector: () => null,
  querySelectorAll: () => [],
  addEventListener() {},
  removeEventListener() {},
}

const ReactStub = {
  useState: (initial) => [typeof initial === 'function' ? initial() : initial, () => {}],
  useEffect: () => {},
  /*
   * layout effect（D152 的窗口化挂载用它量高 + 锚点修正）：桩里必须存在，否则
   * `const { useLayoutEffect } = React` 拿到 undefined，组件体一进 hook 就抛。
   * 桩不做真实挂载，所以空的实现正好——量高那条路径在真 Chrome 里由性能门禁覆盖。
   */
  useLayoutEffect: () => {},
  useRef: (initial) => ({ current: initial }),
  useCallback: (fn) => fn,
  /*
   * 上下文（S3 的「面板是否可见」用）：桩不做真实渲染，所以 useContext 只能拿到
   * createContext 的**默认值**。对本文件够用——既有用例全走「默认可见」的模态路径，
   * 而门控真正的行为（visible=false → 断流）发生在 effect 里，本就不在这个桩的射程内，
   * 那条路径由手工验收覆盖。
   */
  createContext: (initial) => ({ __context: true, initial }),
  useContext: (context) => (context === null || context === undefined ? undefined : context.initial),
  /*
   * 类组件基类（探针的错误边界用）：桩里缺这一项时 `class X extends React.Component`
   * **直接死在工厂体**（extends undefined），整套用例一起挂——和当初漏 createContext 同因。
   * 只提供构造与 props/state 的最小语义，不做真实挂载。
   */
  Component: class {
    constructor(props) {
      this.props = props
      this.state = {}
    }

    setState() {}
  },
}
const jsx = (type, props, key) => ({ type, props: { ...(props ?? {}), key } })
const jsxs = (type, props, key) => ({ type, props: { ...(props ?? {}), key } })
/** 记录每次 createRoot().render() 的调用，供断言面板入参。 */
const renders = []
const createRoot = () => ({ render(element) { renders.push(element) }, unmount() {} })

const SEED = {
  react: ReactStub,
  'react/jsx-runtime': { jsx, jsxs },
  'react-dom/client': { createRoot },
}

/** 假 /config 与 /targets：让连接栏匹配逻辑拿到真实形状的数据。 */
const FAKE_CONFIG = {
  enabled: true,
  announceToAgent: true,
  dockerBin: 'docker',
  allowMutations: false,
  allowExec: false,
  execTimeoutSec: 30,
  pollIntervalSec: 5,
  logTailDefault: 200,
  maxOutputKb: 512,
  targets: [
    { name: '本机', kind: 'local', book: '', host: '', port: 22, username: '', auth: 'agent', keyPath: '', agentForward: false, passwordSet: false, passphraseSet: false },
    { name: 'prod', kind: 'ssh', book: 'prod-a', host: '', port: 22, username: '', auth: 'agent', keyPath: '', agentForward: false, passwordSet: false, passphraseSet: false },
    { name: 'inline', kind: 'ssh', book: '', host: '10.0.0.9', port: 2200, username: 'ops', auth: 'agent', keyPath: '', agentForward: false, passwordSet: false, passphraseSet: false },
  ],
  hostKeys: [],
  ttyBooks: ['prod-a', 'prod-legacy'],
  /*
   * 连接簿条目 → host:port（宿主只回 name/host/port）。`prod-legacy` 不被任何目标的
   * book 引用，但和目标是同一台主机：用它钉住「连接失败时按 host 兜底」这条路径。
   */
  ttyBookHosts: [
    { name: 'prod-a', host: '10.0.0.5', port: 2222 },
    { name: 'prod-legacy', host: '10.0.0.5', port: 2222 },
  ],
  ttyAvailable: true,
  toolsRegistered: [],
}
const FAKE_TARGETS = [
  { name: '本机', kind: 'local', label: '本机' },
  { name: 'prod', kind: 'ssh', label: 'root@10.0.0.5:2222' },
  { name: 'inline', kind: 'ssh', label: 'ops@10.0.0.9:2200' },
]

const fetchStub = (url) => {
  const path = String(url)
  const payload = path.endsWith('/config')
    ? { ok: true, config: FAKE_CONFIG }
    : path.endsWith('/targets')
      ? { ok: true, targets: FAKE_TARGETS }
      : { ok: false, error: 'unexpected ' + path }
  return Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve(payload) })
}

let registration = null
const windowStub = {
  __ModuleLoader__: {
    load: (entry) => {
      registration = entry
    },
  },
}

/* ------------------------------------------------------------------ *
 * 执行 bundle
 * ------------------------------------------------------------------ */

await test('client.js 可执行并注册 @hyzyn/dsh-docker', () => {
  const run = new Function('window', 'document', 'MutationObserver', 'fetch', code)
  run(windowStub, documentStub, class { observe() {} disconnect() {} }, fetchStub)
  assert.ok(registration !== null, '未调用 __ModuleLoader__.load')
  assert.equal(registration.id, '@hyzyn/dsh-docker')
  assert.equal(typeof registration.factory, 'function')
})

await test('factory 只 require 平台 seed 提供的模块', () => {
  const required = []
  const requireStub = (spec) => {
    required.push(spec)
    const module = SEED[spec]
    if (module === undefined) throw new Error(`client-modules: require("${spec}") missed the module table`)
    return module
  }
  const exports_ = registration.factory(requireStub)
  assert.deepEqual(required.sort(), ['react', 'react-dom/client', 'react/jsx-runtime'])
  assert.deepEqual(exports_.inject, ['slots'])
  assert.equal(typeof exports_.apply, 'function')
})

/** 造一个最小 client ctx：slots 恒有，ttyConnbar 可选。 */
function makeClientCtx(options = {}) {
  const state = {
    cards: [],
    injected: [],
    connbarFactory: null,
    renders: 0,
    unmounted: 0,
    execCalls: [],
    mountCalls: [],
    paneCalls: [],
    openTabs: [],
    // 会话桥的桩状态：默认按 DSH 0.1.6（快照无 current，靠 retainedBy.mainView 标记选中）
    sessionCurrent: 'session-smoke',
    sessionCwd: '/repo/current',
    // 宿主形状：默认按 0.1.6（无 current，靠 mainView 标记）；'0.1.5' 走老读法
    sessionShape: options.sessionShape ?? '0.1.6',
    sessionListeners: [],
    sentPrompts: [],
    drafts: [],
    notices: [],
    /** 宿主侧的标签关闭钩子（registerCloseHandler）：用例用它模拟用户点标签栏的 ✕。 */
    closeHandlers: new Map(),
  }
  const ctx = {
    slots: {
      inject: (slot, callback) => {
        /*
         * 默认按新宿主：所有槽都存在（回调立即触发）。传 `options.slots` 可只暴露其中几个，
         * 用来模拟「宿主还没有这个槽」的旧版（如 0.1.6 线只有 plugins.row.config、
         * 没有 plugins.bundle.config）——设置面在旧宿主上的回退路径靠它测。
         */
        if (options.slots !== undefined && !options.slots.includes(slot)) return () => {}
        callback()
        return () => {}
      },
      register: (options_, component) => {
        state.cards.push({ options: options_, component })
        return () => {
          const index = state.cards.findIndex((card) => card.options === options_)
          if (index !== -1) state.cards.splice(index, 1)
        }
      },
    },
    inject: (names, callback) => {
      state.injected.push(...names)
      if (names.includes('ttyConnbar') && options.ttyConnbar === true) {
        callback({
          ttyConnbar: {
            addAction(factory) {
              state.connbarFactory = factory
              return () => { state.connbarFactory = null }
            },
            requestRender() {
              state.renders += 1
            },
          },
        })
      }
      if (names.includes('ttyPanel') && options.ttyPanel === true) {
        // tty ≥ 0.16 的右侧挂载位；传 ttyPanelOpen: false 可模拟「面板没开」
        const service = {
          version: 1,
          isOpen: () => options.ttyPanelOpen !== false,
          mountPane(call) {
            state.paneCalls.push(call)
            return { element: { tagName: 'DIV', appendChild() {}, remove() {} }, dispose() {} }
          },
        }
        callback({ ttyPanel: service })
      }
      if (names.includes('ttyTerminal') && options.ttyTerminal === true) {
        // 默认按最新契约（version 2 = 有 mount）；传 ttyTerminalVersion: 1 可模拟老版本
        const version = options.ttyTerminalVersion ?? 2
        const service = {
          version,
          open(call) {
            state.execCalls.push(call)
          },
        }
        if (version >= 2) {
          service.mount = (host, call) => {
            state.mountCalls.push({ host, call })
            return () => {}
          }
        }
        callback({ ttyTerminal: service })
      }
      if (names.includes('sessions') && options.sessions !== false) {
        /*
         * 会话桥：日志右键「问 Agent」经它拿**会话作用域**里的 conversation。
         * 传 sessions: false 可模拟宿主未提供该服务（apply 不能崩，菜单运行期置灰）。
         *
         * 快照形状必须跟真实宿主对齐，否则桩会把 bug 遮住：DSH 0.1.6 起会话列表快照
         * **没有 current 字段**（视图选中项搬到了 workspace 域），客户端要用
         * `retainedBy.mainView > 0` 判「主视图正在展示哪个会话」。默认就按 0.1.6 建模，
         * `sessionShape: '0.1.5'` 才带 current —— 老宿主的兼容路径也要能过。
         */
        const sessionSnapshot = () => {
          const current = typeof state.sessionCurrent === 'string' && state.sessionCurrent !== '' ? state.sessionCurrent : null
          const ids = current === null ? [] : [current]
          const byId = {}
          if (current !== null) {
            byId[current] = {
              id: current,
              cwd: state.sessionCwd,
              running: false,
              // ≤0.1.5 的宿主没有 retainedBy 这套引用计数
              retainedBy: state.sessionShape === '0.1.5' ? {} : { mainView: 1 },
            }
          }
          if (state.sessionShape === '0.1.5') {
            return { ids, byId, phase: 'ready', current: current ?? undefined }
          }
          return { ids, byId, phase: 'ready', subagentsByParent: {}, jobsBySession: {} }
        }
        const conversation = {
          send: (text) => { state.sentPrompts.push(text); return Promise.resolve() },
          input: { for: () => ({ setDraft: (text) => { state.drafts.push(text) }, notify: (kind, text) => { state.notices.push({ kind, text }) } }) },
        }
        callback({
          sessions: {
            // 选中哪个会话走 state 便于用例模拟「切会话」；subscribe 收集订阅者，由用例手动通报
            list: {
              getSnapshot: () => sessionSnapshot(),
              subscribe: (fn) => { state.sessionListeners.push(fn); return () => {} },
            },
            scope: () => ({ get: (name) => (name === 'conversation' ? conversation : undefined) }),
          },
        })
      }
      // 默认**不提供**右侧栏服务，于是缺省路径仍是模态——这与「老版本 DSH」同形，
      // 既有用例因此不必改。传 sidebarRightTabs: true 才模拟「有标签宿主」的新宿主。
      if (names.includes('sidebarRightTabs') && options.sidebarRightTabs === true) {
        callback({
          slots: ctx.slots,
          sidebarRightTabs: { register: () => () => {} },
          sidebarRight: {
            openTab: (kind, openOptions) => { state.openTabs.push({ kind, options: openOptions ?? {} }) },
            /*
             * 宿主关闭标签时先回收插件资源（sidebarRight 的 closeIn → removeAfterCleanup）。
             * 用例用它模拟「用户点了标签栏上的 ✕」——真实宿主里这是**唯一**能把关闭
             * 通知到插件的地方：面板自己的 onClose 收不到这个动作。
             * 传 sidebarRightCloseHook: false 可模拟没有该 API 的老宿主（≤0.1.5）。
             */
            ...(options.sidebarRightCloseHook === false
              ? {}
              : { registerCloseHandler: (kind, handler) => { state.closeHandlers.set(kind, handler); return () => { state.closeHandlers.delete(kind) } } }),
          },
        })
      }
      return () => {}
    },
  }
  return { ctx, state }
}

await test('apply 注册设置卡片与配置入口（settings.plugin.item / settings.kit.item / plugins.bundle.config）并挂载侧边栏入口', () => {
  const requireStub = (spec) => SEED[spec]
  const exports_ = registration.factory(requireStub)
  const { ctx, state } = makeClientCtx()
  const dispose = exports_.apply(ctx)
  /*
   * 卡片注册面（新宿主 0.2.0-rc.1）：
   *   - settings.plugin.item：DSH ≤0.1.5 的设置页插件卡片；
   *   - settings.kit.item：0.1.6 起设置里的「插件配置」行（kit-settings 提供的子槽）；
   *   - plugins.bundle.config：**详情页「说明」下方的内联配置**——**只挂本包自己的 bundle 名**；
   *   - plugins.row.config：聚合包（`@hyzyn/dsh-all`）那一份**保留**（内联位挂不了聚合包，
   *     见下）。
   * 关键约束（实测踩过）：`plugins.bundle.config` 的 key 是**共享命名空间**，同一个 key 只能
   * 有一个注册者——重复注册会**直接抛错**，而客户端 apply 抛错就是整插件起不来（启动页
   * 「Failed to load plugins」）。`@hyzyn/dsh-all` 是所有插件共用的聚合 bundle，八个插件都去
   * 挂它必然崩，所以它只能走 row 入口。
   */
  const names = state.cards.map((card) => card.options.name).sort()
  assert.deepEqual(names, ['plugins.bundle.config', 'plugins.row.config', 'settings.kit.item', 'settings.plugin.item'])
  const settingsCard = state.cards.find((card) => card.options.name === 'settings.plugin.item')
  assert.equal(settingsCard.options.key, 'docker', 'settings 卡片 key 必须等于命名空间')
  assert.equal(state.cards.find((card) => card.options.name === 'settings.kit.item').options.id, 'docker', '插件配置行 id')
  assert.deepEqual(
    state.cards.filter((card) => card.options.name === 'plugins.bundle.config').map((card) => card.options.key),
    ['@hyzyn/dsh-docker'],
    '内联配置只挂**本包自己的** bundle 名（挂聚合包会与其它插件撞 key → 客户端启动即崩）',
  )
  assert.deepEqual(
    state.cards.filter((card) => card.options.name === 'plugins.row.config').map((card) => card.options.key),
    ['@hyzyn/dsh-all#docker'],
    '内联可用时只撤掉**本包**那份 row 入口；聚合包那份要留着（它的唯一入口）',
  )
  for (const card of state.cards) assert.equal(typeof card.component, 'function', card.options.name + ' 未暴露组件')
  // 宿主侧边栏找不到时安静降级（不抛异常），卸载可重复调用
  assert.equal(typeof dispose, 'function')
  dispose()
  dispose()
})

await test('旧宿主（只有 plugins.row.config 槽）回退：设置面走 per-row「>」子页，功能不减', () => {
  const requireStub = (spec) => SEED[spec]
  const exports_ = registration.factory(requireStub)
  const { ctx, state } = makeClientCtx({ slots: ['plugins.row.config', 'settings.kit.item', 'settings.plugin.item'] })
  exports_.apply(ctx)
  assert.deepEqual(
    state.cards.filter((card) => card.options.name === 'plugins.row.config').map((card) => card.options.key).sort(),
    ['@hyzyn/dsh-all#docker', '@hyzyn/dsh-docker#docker'],
    'bundle 槽不存在时必须回退注册 row 槽（两个 key 都要）',
  )
  assert.equal(state.cards.some((card) => card.options.name === 'plugins.bundle.config'), false, '槽不存在时不该凭空注册')
  assert.equal(state.cards.filter((card) => card.options.name === 'settings.kit.item').length, 1, '旧宿主上其余入口照常')
})

await test('tty 未安装时：可选注入不触发、apply 仍成功', () => {
  const requireStub = (spec) => SEED[spec]
  const exports_ = registration.factory(requireStub)
  const { ctx, state } = makeClientCtx({ ttyConnbar: false, ttyTerminal: false })
  const dispose = exports_.apply(ctx)
  // 这里只断言「那几个可选注入被尝试过」；*全集*清单在下面单独一条用例里锁，
  // 于是以后新增一个可选注入只需改那一处，不再连带打断这条例外路径用例。
  for (const name of ['ttyConnbar', 'ttyPanel', 'ttyTerminal']) {
    assert.ok(state.injected.includes(name), '缺少可选注入 ' + name)
  }
  assert.equal(state.connbarFactory, null)
  assert.equal(state.execCalls.length, 0)
  dispose()
})

await test('日志 → 会话桥：宿主未提供 sessions 时 apply 仍成功（菜单运行期置灰）', () => {
  const requireStub = (spec) => SEED[spec]
  const exports_ = registration.factory(requireStub)
  const { ctx, state } = makeClientCtx({ sessions: false })
  const dispose = exports_.apply(ctx)
  // 可选注入：服务缺失不能让 apply 抛错，面板其余功能（设置卡片）照常注册
  assert.ok(state.cards.length > 0, 'sessions 缺失时设置卡片仍应注册')
  assert.equal(state.connbarFactory, null)
  dispose()
})

await test('ttyConnbar：SSH 标签一律显示「容器」，目标在点击时解析', async () => {
  const requireStub = (spec) => SEED[spec]
  const exports_ = registration.factory(requireStub)
  const { ctx, state } = makeClientCtx({ ttyConnbar: true })
  const dispose = exports_.apply(ctx)
  await new Promise((resolve) => setTimeout(resolve, 0))
  assert.equal(typeof state.connbarFactory, 'function', 'apply 未注册连接栏工厂')

  const buttons = []
  const addAction = (icon, label, title, onClick) => buttons.push({ icon, label, title, onClick })
  // 1) 连接簿条目名命中 → 按钮标题带目标名
  state.connbarFactory({ spec: { t: 'ssh', name: 'prod-a', host: '10.0.0.5', port: 2222 }, bookName: 'prod-a', addAction })
  assert.equal(buttons.length, 1)
  assert.equal(buttons[0].label, '容器')
  assert.match(buttons[0].title, /目标：prod/)

  // 2) 内联会话按 host:port 命中（label 解析路径）
  state.connbarFactory({ spec: { t: 'ssh', host: '10.0.0.9', port: 2200 }, bookName: '', addAction })
  assert.equal(buttons.length, 2)
  assert.match(buttons[1].title, /目标：inline/)

  // 3) 未配置的主机 → 仍然显示按钮（注册即显示），标题提示去配置
  state.connbarFactory({ spec: { t: 'ssh', host: '192.168.1.2', port: 22 }, bookName: '', addAction })
  assert.equal(buttons.length, 3)
  assert.match(buttons[2].title, /尚未配置/)

  // 4) 本地标签（非 SSH）→ 不插入按钮
  state.connbarFactory({ spec: { t: 'local' }, bookName: '', addAction })
  assert.equal(buttons.length, 3)

  // 5) 点击未命中目标的按钮：异步解析后打开面板（body 上出现挂载容器）
  const before = documentStub.body.children.length
  buttons[2].onClick()
  await new Promise((resolve) => setTimeout(resolve, 30))
  assert.ok(documentStub.body.children.length > before, '点击后未挂载面板容器')
  const hinted = renders[renders.length - 1]
  assert.equal(hinted.props.initialTarget, '', '未命中时不应默认选中任何目标')
  assert.equal(typeof hinted.props.sessionHint, 'object', '未命中时应带会话提示')

  dispose()
})

await test('插件禁用（config.enabled=false）：连接栏不再提供「容器」按钮', async () => {
  // 重新执行 bundle：模块级缓存 / 显隐状态归零；fetch 返回禁用态 config，
  // /targets 按宿主禁用行为返回 403 形状的失败载荷
  let reg = null
  const disabledFetch = (url) => {
    const payload = String(url).endsWith('/config')
      ? { ok: true, config: { ...FAKE_CONFIG, enabled: false } }
      : { ok: false, error: 'forbidden: disabled' }
    return Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve(payload) })
  }
  const run = new Function('window', 'document', 'MutationObserver', 'fetch', code)
  run({ __ModuleLoader__: { load: (entry) => { reg = entry } } }, documentStub, class { observe() {} disconnect() {} }, disabledFetch)
  const exports_ = reg.factory((spec) => SEED[spec])
  const { ctx, state } = makeClientCtx({ ttyConnbar: true })
  const dispose = exports_.apply(ctx)
  await new Promise((resolve) => setTimeout(resolve, 10))
  const buttons = []
  state.connbarFactory({ spec: { t: 'ssh', name: 'prod-a', host: '10.0.0.5', port: 2222 }, bookName: 'prod-a', addAction: (icon, label, title, onClick) => buttons.push({ label, onClick }) })
  assert.equal(buttons.length, 0, '禁用后连接栏不应插入「容器」按钮')
  // 卸载后再触发迟到的一次缓存刷新：不允许把入口状态挂回已卸载的实例
  dispose()
  await new Promise((resolve) => setTimeout(resolve, 10))
})

await test('缓存尚未就绪时点击：现场重拉并锁定当前会话对应的目标', async () => {
  // 重新执行 bundle，得到干净的模块级缓存（不 await → 挂载时的刷新还没落地）
  let reg = null
  const run = new Function('window', 'document', 'MutationObserver', 'fetch', code)
  run({ __ModuleLoader__: { load: (entry) => { reg = entry } } }, documentStub, class { observe() {} disconnect() {} }, fetchStub)
  const exports_ = reg.factory((spec) => SEED[spec])
  const { ctx, state } = makeClientCtx({ ttyConnbar: true })
  exports_.apply(ctx)

  const buttons = []
  state.connbarFactory({ spec: { t: 'ssh', name: 'prod-a', host: '10.0.0.5', port: 2222 }, bookName: 'prod-a', addAction: (icon, label, title, onClick) => buttons.push({ title, onClick }) })
  // 此刻缓存为空 → 标题是中性的，不应断言「未配置」
  assert.match(buttons[0].title, /打开当前会话主机/)

  const before = renders.length
  buttons[0].onClick()
  await new Promise((resolve) => setTimeout(resolve, 40))
  assert.ok(renders.length > before, '点击后未打开面板')
  const panel = renders[renders.length - 1]
  assert.equal(panel.props.initialTarget, 'prod', '应锁定当前会话对应的目标')
  assert.equal(panel.props.sessionHint, undefined, '命中目标时不应再带未配置提示')
})

await test('连接失败（没有 tab.target）：用连接簿自带的 host 兜底命中目标', async () => {
  // 干净的模块级缓存：重新执行 bundle，再把挂载时那次 /config + /targets 放落地
  let reg = null
  const run = new Function('window', 'document', 'MutationObserver', 'fetch', code)
  run({ __ModuleLoader__: { load: (entry) => { reg = entry } } }, documentStub, class { observe() {} disconnect() {} }, fetchStub)
  const exports_ = reg.factory((spec) => SEED[spec])
  const { ctx, state } = makeClientCtx({ ttyConnbar: true })
  exports_.apply(ctx)
  await new Promise((resolve) => setTimeout(resolve, 40))

  const buttons = []
  /*
   * 用户实际场景：会话来自连接簿「prod-legacy」（目标 prod 引用的是另一条 prod-a），
   * 而这台机器的 SSH **握手超时**——宿主只在连接成功后才回显 tab.target，所以这里
   * 是空的。旧实现没有第二层兜底，会判成「该主机没配目标」，面板随后沿用上次记住的
   * 目标，把另一台主机的容器显示出来。
   */
  state.connbarFactory({
    spec: { t: 'ssh', name: 'prod-legacy', command: '' },
    bookName: 'prod-legacy',
    tab: { target: '' },
    addAction: (icon, label, title, onClick) => buttons.push({ title, onClick }),
  })
  assert.match(buttons[0].title, /目标：prod/, '连接簿 host 应能把会话对到目标')

  buttons[0].onClick()
  await new Promise((resolve) => setTimeout(resolve, 40))
  const panel = renders[renders.length - 1]
  assert.equal(panel.props.initialTarget, 'prod', '应直接锁定按 host 命中的目标')
  assert.equal(panel.props.sessionHint, undefined, '命中目标时不应再带「未配置」提示')

  // 反例：连接簿条目和任何目标都不相干时，仍然判「未配置」，并带上解析出的主机地址
  buttons.length = 0
  state.connbarFactory({
    spec: { t: 'ssh', name: '未知条目', command: '' },
    bookName: '未知条目',
    tab: { target: '' },
    addAction: (icon, label, title, onClick) => buttons.push({ title, onClick }),
  })
  assert.match(buttons[0].title, /尚未配置为 Docker 目标/)
  buttons[0].onClick()
  await new Promise((resolve) => setTimeout(resolve, 40))
  const unmatched = renders[renders.length - 1]
  assert.equal(unmatched.props.initialTarget, '')
  assert.equal(unmatched.props.sessionHint.book, '未知条目')
  assert.equal(unmatched.props.sessionHint.host, '')
})

await test('承载分发（S2）：框架侧入口开右侧栏标签（带目标），不再弹模态', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const { ctx, state } = makeClientCtx({ sidebarRightTabs: true })
  exports_.apply(ctx)

  const before = renders.length
  // 走测试缝直接驱动分发：DOM 桩的 querySelector 返回 null，点不到页边栏那个入口
  exports_.__carrier.open({ target: 'prod' })
  assert.equal(state.openTabs.length, 1, '有右侧栏服务时应开标签')
  assert.equal(state.openTabs[0].kind, 'docker', 'kind 必须与注册的 kind 一致')
  assert.equal(state.openTabs[0].options.params.target, 'prod', '目标应随 navigation params 带进标签')
  assert.equal(renders.length, before, '开标签时不应再渲染模态')
})

await test('承载分发（S2）：终端连接栏入口走 dock、不开标签（弹窗会挡住标签）', async () => {
  let reg = null
  const run = new Function('window', 'document', 'MutationObserver', 'fetch', code)
  run({ __ModuleLoader__: { load: (entry) => { reg = entry } } }, documentStub, class { observe() {} disconnect() {} }, fetchStub)
  const exports_ = reg.factory((spec) => SEED[spec])
  // 连接栏按钮长在 tty 面板上 → 点击时弹窗一定开着，且它盖满视口
  const { ctx, state } = makeClientCtx({ ttyConnbar: true, ttyPanel: true, sidebarRightTabs: true })
  exports_.apply(ctx)

  const buttons = []
  state.connbarFactory({ spec: { t: 'ssh', name: 'prod-a', host: '10.0.0.5', port: 2222 }, bookName: 'prod-a', addAction: (icon, label, title, onClick) => buttons.push({ title, onClick }) })
  buttons[0].onClick()
  await new Promise((resolve) => setTimeout(resolve, 40))
  assert.equal(state.openTabs.length, 0, '连接栏入口不该开标签 —— 它会被 tty 弹窗整个挡住')
  assert.ok(state.paneCalls.length > 0, '应停靠到 tty 面板右侧的 dock')
})

await test('连接栏：本插件自己开的 exec 标签不再提供「容器」入口', async () => {
  // 纯函数部分：只认 spawnSpec.command（API 开的命令标签），用户手敲的不算
  const carrier = carrierApi()
  assert.equal(carrier.isOwnExec(carrier.buildExec('app-svc-1-test')), true, '自家生成的命令必须认得出来')
  assert.equal(carrier.isOwnExec("docker exec -it 'x' sh"), true)
  assert.equal(carrier.isOwnExec(undefined), false, '普通 SSH 标签没有 command → 照旧带按钮')
  assert.equal(carrier.isOwnExec(''), false)
  assert.equal(carrier.isOwnExec('docker ps'), false)

  // 端到端：连接栏工厂拿到的 spec 带 command 时不再插按钮
  let reg = null
  const run = new Function('window', 'document', 'MutationObserver', 'fetch', code)
  run({ __ModuleLoader__: { load: (entry) => { reg = entry } } }, documentStub, class { observe() {} disconnect() {} }, fetchStub)
  const exports_ = reg.factory((spec) => SEED[spec])
  const { ctx, state } = makeClientCtx({ ttyConnbar: true })
  exports_.apply(ctx)
  const buttons = []
  const push = (icon, label, title, onClick) => buttons.push({ label, onClick })
  const base = { t: 'ssh', name: 'prod-a', host: '10.0.0.5', port: 2222 }
  state.connbarFactory({ spec: base, bookName: 'prod-a', addAction: push })
  assert.equal(buttons.length, 1, '普通 SSH 标签应带「容器」按钮')
  buttons.length = 0
  state.connbarFactory({ spec: { ...base, command: "docker exec -it 'app-svc-1-test' sh" }, bookName: 'prod-a', addAction: push })
  assert.equal(buttons.length, 0, 'exec 标签不该再给「容器」入口')
})

await test('承载分发（S2）：localStorage 置 modal 时退回模态（灰度回滚开关）', () => {
  let reg = null
  const run = new Function('window', 'document', 'MutationObserver', 'fetch', code)
  // 偏好读的是 window.localStorage；harness 的 window 桩默认没有它（越界读取会被 try/catch 吃掉）
  run({
    __ModuleLoader__: { load: (entry) => { reg = entry } },
    localStorage: { getItem: () => 'modal' },
  }, documentStub, class { observe() {} disconnect() {} }, fetchStub)
  const exports_ = reg.factory((spec) => SEED[spec])
  const { ctx, state } = makeClientCtx({ sidebarRightTabs: true })
  exports_.apply(ctx)

  const before = renders.length
  exports_.__carrier.open({ target: 'prod' })
  assert.equal(state.openTabs.length, 0, '置 modal 后不应开标签')
  assert.ok(renders.length > before, '置 modal 后应走模态（渲染面板）')
})

await test('粘性：切会话时自动把容器标签带过去（判定抽成纯函数）', () => {
  const carrier = carrierApi()
  assert.equal(carrier.shouldReopen(true, 'a', 'b', true), true, '切会话 + 有意图 + 有服务 → 重开')
  assert.equal(carrier.shouldReopen(true, 'a', 'a', true), false, '当前会话没换（只是列表变了）→ 不动作')
  assert.equal(carrier.shouldReopen(false, 'a', 'b', true), false, '用户没要过 / 已点 ✕ 关掉 → 不重开')
  assert.equal(carrier.shouldReopen(true, 'a', 'b', false), false, '没有右侧栏服务 → 不重开')
  assert.equal(carrier.shouldReopen(true, 'a', null, true), false, '没有当前会话 → 不重开')
  assert.equal(carrier.shouldReopen(true, null, 'b', true), true, '首个会话 id 到达也算一次切换')
})

await test('粘性：订阅接线（打开 → 切会话重开 → 同会话不重复开）', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const { ctx, state } = makeClientCtx({ sidebarRightTabs: true })
  exports_.apply(ctx)
  assert.equal(state.sessionListeners.length, 1, '应订阅一次会话列表')
  exports_.__carrier.open({})
  assert.equal(state.openTabs.length, 1, '打开时应开标签')
  // 模拟切会话：改 current 再通报订阅者
  state.sessionCurrent = 'session-two'
  for (const notify of state.sessionListeners) notify()
  assert.equal(state.openTabs.length, 2, '切会话应在新的会话里重开标签')
  for (const notify of state.sessionListeners) notify()
  assert.equal(state.openTabs.length, 2, '同一会话重复通报不该再开')
})

await test('粘性：关掉标签后切会话不再把它带回来（标签 ✕ 由宿主关闭，插件收不到 onClose）', () => {
  /*
   * 实测的回归：用户点标签栏上的 ✕ 关掉 Docker，切会话它又冒出来；再关、切回原会话
   * 又冒一次。原因是「已关闭」只写进了面板自己的 onClose，而标签栏的 ✕ 是宿主直接
   * 摘标签的——插件必须登记 registerCloseHandler 才知道用户真的关掉了。
   */
  const exports_ = registration.factory((spec) => SEED[spec])
  const { ctx, state } = makeClientCtx({ sidebarRightTabs: true })
  exports_.apply(ctx)
  exports_.__carrier.open({})
  assert.equal(state.openTabs.length, 1, '打开时应开标签')

  const closeHook = state.closeHandlers.get('docker')
  assert.equal(
    typeof closeHook,
    'function',
    '没登记关闭钩子：关掉标签后粘性意图还在，切会话会把它带回来',
  )
  closeHook('session-smoke', { id: 'tab', kind: 'docker' })

  state.sessionCurrent = 'session-two'
  for (const notify of state.sessionListeners) notify()
  assert.equal(state.openTabs.length, 1, '用户已经关掉了，切会话不该再开')
  // 再切一次也不该复活
  state.sessionCurrent = 'session-three'
  for (const notify of state.sessionListeners) notify()
  assert.equal(state.openTabs.length, 1, '切第三次也不该复活')
})

await test('粘性：老宿主（没有 registerCloseHandler）不因缺 API 报错，行为保持原样', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const { ctx, state } = makeClientCtx({ sidebarRightTabs: true, sidebarRightCloseHook: false })
  assert.doesNotThrow(() => exports_.apply(ctx))
  exports_.__carrier.open({})
  assert.equal(state.openTabs.length, 1, '打开照常')
  state.sessionCurrent = 'session-two'
  for (const notify of state.sessionListeners) notify()
  assert.equal(state.openTabs.length, 2, '拿不到钩子时保持既有行为（切会话仍带过去）')
})

await test('日志过滤对齐：级别门槛的「续行继承」对行对象与纯文本行是同一套', () => {
  const pick = aggLogsApi()
  const rows = [
    { text: '16:11:34,150 |INFO boot' },
    { text: '  at foo(Bar.java:1)' },
    { text: '16:11:35,200 |ERROR boom' },
    { text: '  at baz(Qux.java:2)' },
    { text: 'plain continuation' },
  ]
  const warnPlus = pick.filterByLevel(rows, 3)
  assert.deepEqual(
    warnPlus.map((row) => row.text),
    ['16:11:35,200 |ERROR boom', '  at baz(Qux.java:2)', 'plain continuation'],
    'WARN+ 必须保留 ERROR 头行**及其续行**——否则堆栈被拦腰截断，筛选形同虚设',
  )
  const lines = rows.map((row) => row.text)
  assert.deepEqual(pick.filterLinesByLevel(lines, 3), warnPlus.map((row) => row.text), '两种形状必须给出同一结果（共用内核）')
  assert.equal(pick.filterByLevel(rows, 0), rows, '门槛 0 原样返回，不做无谓拷贝')
  assert.equal(pick.filterLinesByLevel(lines, 0), lines)
  assert.deepEqual(pick.filterLinesByLevel(['  at orphan(X.java:9)'], 4), ['  at orphan(X.java:9)'], '窗口开头就是续行 → 无从判断，保留')
})

await test('日志级别档位：共用一份定义，含 INFO+（真实日志里最常用的那一档）', () => {
  const agg = aggLogsApi()
  const options = agg.LEVEL_OPTIONS
  assert.ok(Array.isArray(options), '缺少 LEVEL_OPTIONS 测试缝')
  // 档位：全部 / INFO+ / WARN+ / ERROR+（rank 2 = INFO）。没有 DEBUG+/TRACE+ 的理由见源码注释：
  // 噪音几乎都在 DEBUG 及以下，而 INFO 往往正是要看的那档。
  assert.deepEqual(options.map((option) => option.value), [0, 2, 3, 4])
  assert.deepEqual(options.map((option) => option.label), ['全部级别', 'INFO+', 'WARN+', 'ERROR+'])

  // INFO+ 的**行为**：留下 INFO 及以上，丢掉 DEBUG —— 这正是它存在的意义
  const lines = ['[DEBUG] noise', '[INFO] useful', '[ERROR] boom']
  assert.deepEqual(agg.filterLinesByLevel(lines, 2), ['[INFO] useful', '[ERROR] boom'])

  // 「共用一份定义」不是口号：每个标签在产物里只能出现一次——两个视图各写一套必然出现两次
  const decoded = code.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
  for (const option of options) {
    assert.equal(decoded.split(option.label).length - 1, 1, option.label + ' 在产物里出现了多次（视图各写了一套选项？）')
  }
})

await test('日志级别过滤：`%5p` 右填充的 `[INFO ]` / `[WARN ]` 必须认出来（否则门槛整个失效）', () => {
  const agg = aggLogsApi()
  /*
   * 回归现场（用户截图）：Logback / Spring 的 `%5p` 把级别右填充到 5 字符，
   * 于是 INFO/WARN/DEBUG 写成 `[INFO ]`，而 ERROR/FATAL 恰好 5 字符不带空格。
   * 旧正则只认 `[INFO]`，这些行被判成「无级别」——looks 无害，实则致命：
   * filterByLevelCore 对未知级别走「不误杀」分支（rank=null 一律保留），
   * 所以选了 WARN+ 仍会显示一屏 INFO，过滤像没生效。
   */
  assert.equal(agg.levelName('[INFO ] [2026-09-25 11:31:00] [scheduling-1] ==> x'), 'INFO')
  assert.equal(agg.levelName('[WARN ] [2026-09-25 11:31:00] [scheduling-1] ==> x'), 'WARN')
  assert.equal(agg.levelName('[DEBUG] [2026-09-25 11:31:00] [scheduling-1] ==> x'), 'DEBUG')
  assert.equal(agg.levelName('[ERROR] [2026-09-25 11:31:00] [scheduling-1] ==> x'), 'ERROR')
  // 既有形态不能被这次放宽改坏：未填充 / 前导空格 / Spring 竖线 / 无级别
  assert.equal(agg.levelName('[INFO] [2026-09-09 18:05:52] unpadded'), 'INFO')
  assert.equal(agg.levelName('[ INFO] leading pad'), 'INFO')
  assert.equal(agg.levelName('16:11:34,150 |INFO in Spring'), 'INFO')
  assert.equal(agg.levelName('没有待处理的考试，定时任务结束'), null)

  // 端到端：WARN+ 滤掉填充过的 INFO 行，且紧邻的续行继承语义不受影响
  const lines = [
    '[INFO ] [2026-09-25 11:31:00] [scheduling-1] ==> 没有待处理的考试，定时任务结束',
    '[WARN ] [2026-09-25 11:31:05] [scheduling-1] ==> 磁盘将满',
    '  续行继承上一行的级别',
  ]
  assert.deepEqual(agg.filterLinesByLevel(lines, 3), [lines[1], lines[2]], 'WARN+ 必须滤掉填充过的 INFO')
  assert.deepEqual(agg.filterLinesByLevel(lines, 2), lines, 'INFO+ 三行都该留下')
  assert.deepEqual(agg.filterLinesByLevel(lines, 4), [], 'ERROR+ 该清空（续行继承 WARN）')
  // 行对象适配器与纯文本适配器必须给出同一结论
  const rows = lines.map((text) => ({ text }))
  assert.deepEqual(agg.filterByLevel(rows, 3).map((row) => row.text), agg.filterLinesByLevel(lines, 3))
})

await test('日志导出对齐：两种格式共用构建器，只有标题与作用域不同', () => {
  const pick = aggLogsApi()
  const rows = [{ service: 'web', ts: 1755000000000, text: 'ERROR boom' }]
  const plain = pick.buildLogExport(rows, { format: 'log', target: '目标1' })
  assert.ok(!plain.includes('# '), '.log 只是正文')
  assert.match(plain, /\[web\] .*ERROR boom/)
  const one = pick.buildLogExport(rows, { format: 'md', scope: '容器日志', target: '目标1', targetLabel: '目标1', items: [{ name: 'web' }] })
  const many = pick.buildLogExport(rows, { format: 'md', target: '目标1', items: [{ name: 'web' }, { name: 'db' }] })
  assert.match(one, /^# 容器日志/)
  assert.match(many, /^# 聚合日志/)
  for (const md of [one, many]) {
    assert.match(md, /- 行数：1/)
    assert.match(md, /```text/)
  }
  assert.match(many, /容器（2）：web、db/)
})

await test('日志导出：两个格式合并成一个菜单按钮（D137 —— 窄面板下不再各占一格）', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const agg = exports_.__aggLogs
  const decoded = decodeBundle(code)

  // 「一份定义」不是口号：按钮文案在产物里出现两次 = 两个视图又各写了一套
  // （级别档位、过滤内核当初就是这么漂的）
  assert.equal(typeof agg.EXPORT_LABEL, 'string', '缺少 __aggLogs.EXPORT_LABEL 测试缝')
  assert.ok(decoded.includes(agg.EXPORT_LABEL), '产物里没有导出按钮文案')
  assert.equal(
    decoded.split(agg.EXPORT_LABEL).length - 1,
    1,
    agg.EXPORT_LABEL + ' 在产物里出现了多次（视图各写了一套按钮？）',
  )
  // 两个视图的按钮都必须是「菜单触发器」——否则「这是个菜单」对读屏用户不可知
  assert.equal(decoded.split('aria-haspopup').length - 1, 2, '两个视图的导出按钮都要标 aria-haspopup')
  // 旧的「一个格式一个按钮」不许回来（正是它把 .md 挤到第二行）
  assert.ok(!decoded.includes('导出当前显示内容为 .log'), '旧的单格式按钮文案残留（又拆回两个按钮了？）')

  // 菜单里两个格式都在，且各自把正确的 format 交回导出函数
  const picked = []
  const items = agg.exportMenuItems((format) => picked.push(format))
  assert.equal(items.length, 2, '导出菜单必须恰好两个格式')
  assert.deepEqual(items.map((item) => item.label), ['⬇ .log', '⬇ .md'])
  for (const item of items) item.onPick()
  assert.deepEqual(picked, ['log', 'md'], '菜单项必须把对应的 format 传回导出函数')
})

await test('渲染期守卫：面板组件体直接跑一遍不能抛（TDZ 那类错误曾让面板整个空白）', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  assert.ok(exports_.__render !== undefined, '缺少 __render 测试缝')
  const cases = [
    ['DockerTabBody', {}],
    ['ContainerPanel', { carrier: 'tab', onClose: () => {}, initialTarget: '' }],
    ['ContainerPanel', { onClose: () => {}, initialTarget: '' }], // 模态 / docked 形态（carrier 缺省）
    // 聚合日志视图（D137 也动了它的导出按钮）：它的工具条与单容器那条共用同一份定义，
    // 但只在「多选聚合 / compose 详情」下才挂载，上面两个入口都盖不到它
    ['ComposeLogs', { target: '目标1', targetLabel: '目标1', items: [{ id: 'a', name: 'web' }, { id: 'b', name: 'db' }] }],
  ]
  for (const [name, props] of cases) {
    const component = exports_.__render[name]
    assert.equal(typeof component, 'function', name + ' 未暴露')
    let element = null
    assert.doesNotThrow(() => { element = component(props) }, name + ' 渲染期抛错')
    assert.ok(element !== null && element !== undefined, name + ' 返回了空')
  }
})

await test('会话桥（DSH 0.1.6 形状）：右键「问 Agent」能解出当前会话，不再恒判「没有打开的会话」', async () => {
  /*
   * 实测的回归：0.1.6 起 `sessions.list` 快照不再带 `current`（视图选中项搬到了
   * workspace 域），只读老字段的实现把「有会话」判成「当前没有打开的会话」——
   * 日志右键的两个菜单项全灰，功能整体失效且不报错。
   * 这里两种宿主形状都要解得出，且投递真的落到作用域里的 conversation 上。
   */
  for (const shape of ['0.1.6', '0.1.5']) {
    const exports_ = registration.factory((spec) => SEED[spec])
    const { ctx, state } = makeClientCtx({ sessionShape: shape })
    assert.equal(state.sessionShape, shape)
    exports_.apply(ctx)

    const sent = await exports_.__carrier.deliver('诊断包', 'send')
    assert.equal(sent.ok, true, shape + '：当前会话在场时不该判成「没有打开的会话」')
    assert.deepEqual(state.sentPrompts, ['诊断包'], shape + '：应经会话作用域的 conversation 发出')

    const drafted = await exports_.__carrier.deliver('诊断包', 'draft')
    assert.equal(drafted.ok, true, shape + '：草稿档也应可用')
    assert.deepEqual(state.drafts, ['诊断包'], shape + '：应落到会话输入门面的 setDraft')
  }
})

await test('会话桥：没有打开的会话时给出明确原因（菜单据此置灰，而不是崩）', async () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const { ctx, state } = makeClientCtx({})
  exports_.apply(ctx)
  state.sessionCurrent = null // 列表空：0.1.6 形状下 byId 里没有任何一行带 mainView
  const failed = await exports_.__carrier.deliver('诊断包', 'send')
  assert.equal(failed.ok, false)
  assert.match(failed.message, /当前没有打开的会话/)
})

await test('投递回执：成功也在视口级发声（以前只有失败才提示）', async () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const { ctx } = makeClientCtx({ sidebarRightTabs: true })
  exports_.apply(ctx)
  // 成功：应追加一枚绿色 toast。这条锁的是「模态 / docked 下面板盖着会话时，
  // 用户至少能在视口右下角看到『已发送』」——以前成功是静默的，体感是「点了没反应」。
  const before = documentStub.body.children.length
  const ok = await exports_.__carrier.deliver('诊断包', 'send')
  assert.equal(ok.ok, true, '会话桩应接受投递')
  assert.equal(documentStub.body.children.length, before + 1, '成功要有视口级回执')
  const toast = documentStub.body.children[documentStub.body.children.length - 1]
  assert.equal(toast.dataset.kind, 'ok', '成功用绿色那套')
  assert.match(toast.textContent, /已发送/)
  // 「会话在面板后面」那半句由面板按承载设置（tab 下不该出现），不是写死在文案里；
  // 这里面板没挂载，所以后缀应为空。
  assert.ok(!toast.textContent.includes('面板后面'), '承载相关的后缀不该硬编码在投递层')

  // 失败：deliver 只回结果，提示由调用方（右键菜单）负责，不该自己乱发 toast
  const fresh = registration.factory((spec) => SEED[spec])
  const { ctx: bare } = makeClientCtx({ sessions: false })
  fresh.apply(bare)
  const beforeFail = documentStub.body.children.length
  const failed = await fresh.__carrier.deliver('诊断包', 'send')
  assert.equal(failed.ok, false, '没有 sessions 服务应失败')
  assert.match(failed.message, /sessions/)
  assert.equal(documentStub.body.children.length, beforeFail, '失败不该由投递层自己发 toast')
})

await test('注入清单快照：本插件注入过的服务全集（加可选注入时只改这一处）', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const { ctx, state } = makeClientCtx({ ttyConnbar: false, ttyTerminal: false })
  const dispose = exports_.apply(ctx)
  // locale 是 i18n 的动态注入（docs/i18n.md）：夹具**刻意不为它回调** = 老宿主那条路，
  // 渲染走 zh 兜底，所以本文件里的中文断言照旧成立。
  assert.deepEqual(state.injected.sort(), ['locale', 'sessions', 'sidebarRight', 'sidebarRightTabs', 'ttyConnbar', 'ttyPanel', 'ttyTerminal'])
  dispose()
})

await test('右侧栏标签承载（S1）：类型 / body / 外壳样式装配进 bundle', () => {
  assert.ok(code.includes('sidebar.right.pane.tab'), '缺少右侧栏标签 body 槽名')
  assert.ok(code.includes('sidebarRightTabs'), '缺少右侧栏类型注册')
  assert.ok(code.includes('dk_panelTab'), '缺少标签承载的面板外壳样式')
  // 契约要求 body 注册在**实现 id** 下（不是 kind）：写错的表现是「标签能开、body 空白」
  assert.ok(code.includes('"@hyzyn/dsh-docker"') || code.includes("'@hyzyn/dsh-docker'"), '缺少标签实现 id')
  // 卡片「终端」按钮要按右侧栏是否铺满分流，fullscreen 得透传进面板（属性名不会被 minify）
  assert.ok(code.includes('tabFullscreen'), '缺少 sidebar.fullscreen 的透传')
  // esbuild 默认 charset=ascii：中文在 bundle 里是 \uXXXX，先解码再断言
  const decoded = code.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
  assert.ok(decoded.includes('本机与 SSH 主机的容器、镜像、Compose、网络与卷'), '缺少指南页描述文案')
})

await test('ttyTerminal：可选注入成功，且 bundle 内含 exec 命令与复制兜底', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const { ctx, state } = makeClientCtx({ ttyConnbar: false, ttyTerminal: true })
  const dispose = exports_.apply(ctx)
  assert.ok(state.injected.includes('ttyTerminal'), '缺少 ttyTerminal 可选注入')
  // 命令构造与兜底路径：静态断言（点击路径在真实应用里由端到端脚本覆盖）
  // esbuild 默认 charset=ascii：中文在 bundle 里是 \uXXXX，先解码再断言
  const decoded = code.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
  assert.ok(decoded.includes('docker exec -it'), '缺少 exec 命令构造')
  assert.ok(decoded.includes('未安装 dsh-tty 终端面板'), '缺少 tty 未安装时的复制兜底提示')
  assert.ok(decoded.includes('终端面板版本过旧'), '缺少 tty 版本过旧时的提示')
  dispose()
})

await test('ttyTerminal：按契约版本选择 mount（就地嵌入）/ open（开标签），旧版本不报错', () => {
  const decoded = code.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
  // 静态断言锁住契约：能力判断走 version，且两条路径与抽屉 DOM 都在 bundle 里。
  // 点击路径（点卡片 → 抽屉里出现真终端）由 tty 的预览夹具端到端覆盖：
  //   packages/tty/scripts/preview.mjs 的 docker-exec / embed / embed-panel 场景
  assert.ok(code.includes('version'), '缺少 ttyTerminal 契约版本判断')
  assert.ok(code.includes('.mount(') || code.includes('mount('), '缺少 mount 调用路径')
  assert.ok(code.includes('dk_drawerBody'), '缺少终端抽屉挂载点')
  assert.ok(decoded.includes('由终端面板承载'), '缺少抽屉说明文案')
  // 老版本（只有 open）注入不应抛异常：apply 全程不碰 mount
  const old = makeClientCtx({ ttyTerminal: true, ttyTerminalVersion: 1 })
  const exports_ = registration.factory((spec) => SEED[spec])
  const dispose = exports_.apply(old.ctx)
  assert.equal(typeof dispose, 'function')
  dispose()
})

await test('ttyPanel：面板开着时挂进右侧侧栏（docked），没开则回退弹窗', async () => {
  const requireStub = (spec) => SEED[spec]
  // 1) 面板开着（isOpen → true）：走 ttyPanel.mountPane，ContainerPanel 拿到 docked
  const exports_ = registration.factory(requireStub)
  const { ctx, state } = makeClientCtx({ ttyConnbar: true, ttyPanel: true })
  const dispose = exports_.apply(ctx)
  await new Promise((resolve) => setTimeout(resolve, 0))
  const buttons = []
  state.connbarFactory({ spec: { t: 'ssh', name: 'prod-a', host: '10.0.0.5', port: 2222 }, bookName: 'prod-a', addAction: (icon, label, title, onClick) => buttons.push({ onClick }) })
  buttons[0].onClick()
  await new Promise((resolve) => setTimeout(resolve, 30))
  assert.equal(state.paneCalls.length, 1, '面板开着时应挂进 ttyPanel')
  assert.equal(state.paneCalls[0].title, 'Docker 容器')
  const docked = renders[renders.length - 1]
  assert.equal(docked.props.docked, true, 'dock 模式必须显式传给 ContainerPanel')
  // 2) 面板没开（isOpen → false）：仍然挂 body 级模态
  const modal = makeClientCtx({ ttyConnbar: true, ttyPanel: true, ttyPanelOpen: false })
  const exports2 = registration.factory(requireStub)
  const dispose2 = exports2.apply(modal.ctx)
  await new Promise((resolve) => setTimeout(resolve, 0))
  const buttons2 = []
  modal.state.connbarFactory({ spec: { t: 'ssh', name: 'prod-a', host: '10.0.0.5', port: 2222 }, bookName: 'prod-a', addAction: (icon, label, title, onClick) => buttons2.push({ onClick }) })
  const before = documentStub.body.children.length
  buttons2[0].onClick()
  await new Promise((resolve) => setTimeout(resolve, 30))
  assert.equal(modal.state.paneCalls.length, 0, '面板没开时不该挂 pane')
  assert.ok(documentStub.body.children.length > before, '没开面板时应回退到 body 级模态')
  const modalPanel = renders[renders.length - 1]
  assert.notEqual(modalPanel.props.docked, true)
  dispose()
  dispose2()
})

await test('按条件一键选择：preset 判定 / 计数截断 / 上限语义', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const pick = exports_.__pick
  assert.ok(typeof pick.apply === 'function' && typeof pick.presetCounts === 'function', '缺少 __pick 条件选择测试缝')
  const visible = [
    { id: 'a', name: 'web', image: 'nginx:1.27', state: 'running', health: 'unhealthy', composeProject: 'shop', exitCode: null },
    { id: 'b', name: 'api', image: 'app:1', state: 'running', health: null, composeProject: 'shop', exitCode: null },
    { id: 'c', name: 'cron', image: 'app:1', state: 'exited', health: null, composeProject: 'ops', exitCode: 137 },
    { id: 'd', name: 'clean', image: 'app:2', state: 'exited', health: null, composeProject: 'ops', exitCode: 0 },
  ]

  // 不健康 → 只挑 a
  assert.deepEqual(pick.apply(visible, [], 'unhealthy', null, 8).ids, ['a'])
  // 需关注（摘要口径：unhealthy + 非零退出）→ a、c
  assert.deepEqual(pick.apply(visible, [], 'abnormal', null, 8).ids, ['a', 'c'])
  // 已停止 → c、d
  assert.deepEqual(pick.apply(visible, [], 'stopped', null, 8).ids, ['c', 'd'])
  // 已勾选的不重复选
  assert.deepEqual(pick.apply(visible, ['a'], 'unhealthy', null, 8).ids, ['a'])
  // 上限截断：全部可见但只剩 2 个名额 → 加 2 个、略过 2 个
  const capped = pick.apply(visible, ['a', 'b'], 'all', null, 4)
  assert.equal(capped.added, 2)
  assert.equal(capped.skipped, 0)
  const tight = pick.apply(visible, ['a'], 'all', null, 3)
  assert.equal(tight.added, 2)
  assert.equal(tight.skipped, 1)
  assert.equal(tight.ids.length, 3)

  // 同镜像 / 同项目：以第一个勾选的容器为基准
  assert.deepEqual(pick.apply(visible, [], 'sameImage', visible[1], 8).ids, ['b', 'c'])
  assert.deepEqual(pick.apply(visible, [], 'sameProject', visible[0], 8).ids, ['a', 'b'])
  // 基准为非 compose 容器 → 同项目不选任何东西
  assert.deepEqual(pick.apply(visible, [], 'sameProject', { id: 'x', composeProject: null }, 8).ids, [])

  // 计数按剩余名额截断；over 如实报出被略过的数量
  // 4 个可见、上限 2 → chip 显示 2、另有 2 个超出上限
  const counts = pick.presetCounts(visible, [], null, 2)
  const all = counts.find((item) => item.key === 'all')
  assert.equal(all.count, 2)
  assert.equal(all.over, 2)
  // 已勾 1 个、上限 3 → 只剩 2 个名额
  const tightCounts = pick.presetCounts(visible, ['a'], null, 3).find((item) => item.key === 'all')
  assert.equal(tightCounts.count, 2)
  assert.equal(tightCounts.over, 1)
  // 基准类预设在没有勾选时不出现
  assert.equal(pick.presetCounts(visible, [], null, 8).some((item) => item.key === 'sameImage'), false)
})

await test('聚合日志：暂停期间的缓冲合并（环形上限、不丢行、越界带 dropped 标志）', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const agg = exports_.__aggLogs
  assert.ok(agg !== undefined && typeof agg.mergeBuffered === 'function', '缺少 __aggLogs 测试缝')
  const entries = [{ service: 'a', text: '1' }, { service: 'a', text: '2' }]
  // 无缓冲：原样返回（同一引用，避免无谓重渲染）且无截断
  assert.deepEqual(agg.mergeBuffered(entries, [], 5000), { entries, dropped: false })
  // 有缓冲：按到达顺序追加在后
  const merged = agg.mergeBuffered(entries, [{ service: 'b', text: '3' }], 5000)
  assert.deepEqual(merged.entries.map((row) => row.text), ['1', '2', '3'])
  assert.equal(merged.dropped, false)
  // 超过上限：丢最旧、保最新（与 FOLLOW 的环形语义一致），并置 dropped（D57）
  const many = Array.from({ length: 5 }, (_, index) => ({ service: 'a', text: String(index) }))
  // 旧 1 行 + 新 5 行 = 6 行，上限 3 → 保留最新 3 行（[2,3,4]）
  const capped = agg.mergeBuffered([{ service: 'a', text: 'old' }], many, 3)
  assert.equal(capped.entries.length, 3)
  assert.deepEqual(capped.entries.map((row) => row.text), ['2', '3', '4'])
  assert.equal(capped.dropped, true)
})

await test('聚合日志增强：时间戳解析 / 级别过滤 / 按时间合并 / 导出', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const agg = exports_.__aggLogs
  assert.ok(agg !== undefined && typeof agg.orderByTs === 'function', '缺少 __aggLogs 增强测试缝')

  // 时间戳：解析出毫秒并从正文里剥掉；无前缀的行保持原样
  const a = agg.splitTs('2026-09-09T16:11:34.150123456Z hello')
  assert.equal(a.text, 'hello')
  assert.equal(a.ts, Date.parse('2026-09-09T16:11:34.150Z'))
  const b = agg.splitTs('no-prefix line')
  assert.equal(b.ts, null)
  assert.equal(b.text, 'no-prefix line')
  // 带时区偏移的写法
  assert.equal(agg.splitTs('2026-09-09T16:11:34+08:00 x').ts, Date.parse('2026-09-09T16:11:34+08:00'))

  // 级别：两种常见前缀都认
  assert.equal(agg.levelName('[INFO] [2026-09-09 16:11:34] [main] x'), 'INFO')
  assert.equal(agg.levelName('16:11:34,150 |ERROR in x'), 'ERROR')
  assert.equal(agg.levelName('plain text'), null)

  // 按时间合并：两个容器的行交错成一条真时间线
  const rows = [
    { service: 'a', text: 'a2', ts: 200 },
    { service: 'b', text: 'b1', ts: 100 },
    { service: 'a', text: 'a3', ts: 300 },
    { service: 'b', text: 'b2', ts: 150 },
  ]
  assert.deepEqual(agg.orderByTs(rows).map((row) => row.text), ['b1', 'b2', 'a2', 'a3'])
  // 尾部回填重排：先到的 A 历史批次、后到的 B 历史批次，能在最近 N 行内被纠正
  const batch1 = [{ service: 'a', text: 'a-late', ts: 900 }, { service: 'a', text: 'a-early', ts: 100 }]
  const afterBatch1 = agg.orderByTs(batch1)
  assert.deepEqual(afterBatch1.map((r) => r.text), ['a-early', 'a-late'])
  const batch2 = [{ service: 'b', text: 'b-mid', ts: 500 }]
  const merged = agg.reorderTail(afterBatch1, batch2, agg.REORDER_TAIL)
  assert.deepEqual(merged.map((r) => r.text), ['a-early', 'b-mid', 'a-late'], '后到的批次应把尾部重新排好')
  // 超出尾部窗口的旧行保持不动（只回填最近 N 行）
  const longTail = Array.from({ length: 5 }, (_, i) => ({ service: 'a', text: 'old' + String(i), ts: i }))
  const kept = agg.reorderTail(longTail, [{ service: 'b', text: 'new', ts: 100 }], 2)
  assert.deepEqual(kept.slice(0, 3).map((r) => r.text), ['old0', 'old1', 'old2'], '窗口外的旧行保持原序')

  // 无时间戳的行沿用前一行的时间（不会被甩到最前/最后）
  const withNull = [
    { service: 'a', text: 'x', ts: 500 },
    { service: 'b', text: 'no-ts', ts: null },
    { service: 'a', text: 'y', ts: 100 },
  ]
  assert.deepEqual(agg.orderByTs(withNull).map((row) => row.text), ['y', 'x', 'no-ts'])
  // 窗口首行是无前缀续行时，继承**窗口外**前一行的时序种子（D56）：
  // 它属于 400 那条记录，不能因为 carried 初值 0 被排到 ts=300 的行前面
  const windowHead = [
    { service: 'b', text: 'no-ts-head', ts: null },
    { service: 'a', text: 'x', ts: 300 },
  ]
  assert.deepEqual(agg.orderByTs(windowHead, 400).map((row) => row.text), ['x', 'no-ts-head'])
  assert.deepEqual(agg.orderByTs(windowHead).map((row) => row.text), ['no-ts-head', 'x'], '不传种子时是旧缺陷形态（续行被甩到窗口最前）')

  // 级别过滤：ERROR+ 只留 ERROR/FATAL 与**无级别前缀**的行（未知级别不误杀）
  const mixed = [
    { service: 'a', text: '[INFO] i', ts: 1 },
    { service: 'a', text: '[WARN] w', ts: 2 },
    { service: 'a', text: '[ERROR] e', ts: 3 },
    { service: 'a', text: 'plain continuation', ts: 4 },
  ]
  // 续行继承上一条的级别：ERROR 后面的续行跟着留下，INFO 后面的续行被滤掉
  assert.deepEqual(agg.filterByLevel(mixed, 4).map((row) => row.text), ['[ERROR] e', 'plain continuation'])
  assert.deepEqual(agg.filterByLevel(mixed, 3).map((row) => row.text), ['[WARN] w', '[ERROR] e', 'plain continuation'])
  assert.equal(agg.filterByLevel(mixed, 0).length, 4)
  // Spring Boot 形态：时间戳在前、级别用竖线；其后的堆栈续行应继承 ERROR
  const spring = [
    { service: 'a', text: '16:11:34,150 |INFO in x', ts: 1 },
    { service: 'a', text: '16:11:35,150 |ERROR in y', ts: 2 },
    { service: 'a', text: '  at com.foo.Bar(baz.java:1)', ts: 3 },
    { service: 'a', text: '  at com.foo.Qux(baz.java:2)', ts: 4 },
    { service: 'a', text: '16:11:36,150 |DEBUG in z', ts: 5 },
  ]
  assert.deepEqual(agg.filterByLevel(spring, 4).map((row) => row.text), [
    '16:11:35,150 |ERROR in y',
    '  at com.foo.Bar(baz.java:1)',
    '  at com.foo.Qux(baz.java:2)',
  ])
  // 窗口开头的续行（记录头在窗口外）无从判断 → 保留
  assert.deepEqual(agg.filterByLevel([{ service: 'a', text: 'orphan continuation', ts: 1 }], 4).map((r) => r.text), ['orphan continuation'])

  // 导出：.log 是纯行；.md 带来源表头且正文进围栏
  const items = [{ name: 'web' }, { name: 'api' }]
  const logText = agg.exportText(mixed.slice(0, 2), { format: 'log' })
  assert.equal(logText.split('\n').length, 2)
  assert.ok(logText.startsWith('[a] '), '每行应带服务前缀')
  assert.ok(logText.includes(new Date(1).toISOString()), '.log 行内含 ISO 时间戳')
  const md = agg.exportText(mixed.slice(0, 2), { format: 'md', target: '目标1', targetLabel: 'root@10.0.0.5', items })
  assert.ok(md.startsWith('# 聚合日志'), 'md 应有标题')
  assert.ok(md.includes('容器（2）：web、api'), 'md 应列出源容器')
  assert.ok(md.includes('```text'), 'md 正文应在代码围栏里')
  assert.ok(md.includes('- 行数：2'))
})

await test('记住上次选的目标：优先级与失效回退', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const panel = exports_.__panel
  assert.ok(panel !== undefined && typeof panel.chooseInitialTarget === 'function', '缺少 __panel 测试缝')
  const list = [{ name: '本机' }, { name: 'prod' }, { name: 'lab' }]

  // 连接栏指定（current 非空）优先于一切
  assert.equal(panel.chooseInitialTarget(list, 'lab', 'prod', false), 'lab')
  // 记住的目标仍在列表里 → 用它
  assert.equal(panel.chooseInitialTarget(list, '', 'lab', false), 'lab')
  // 记住的目标已被删/改名 → 退回第一个，而不是停在一个不存在的目标上
  assert.equal(panel.chooseInitialTarget(list, '', 'gone', false), '本机')
  // 没有记忆 → 第一个；列表为空 → 空串
  assert.equal(panel.chooseInitialTarget(list, '', '', false), '本机')
  assert.equal(panel.chooseInitialTarget([], '', 'prod', false), '')
  // 连接栏进来但会话主机没匹配到目标（sessionScoped）→ 不自动选
  assert.equal(panel.chooseInitialTarget(list, '', 'prod', true), '')
  /*
   * 同上，但面板初值已经是「上次记住的目标」：**也不能沿用**。current 优先于
   * sessionScoped 正是用户报的那个 bug —— 面板会显示另一台主机的容器，只留一条
   * 浅色横幅，比空着更误导（空态文案明确说「不会自动切到其他目标」）。
   */
  assert.equal(panel.chooseInitialTarget(list, 'prod', 'prod', true), '')

  // 侧边栏入口传空串（不是 undefined）：必须当「没指定」处理，否则会盖掉记忆值
  assert.equal(''.trim() !== '' ? '' : 'prod', 'prod')
  // 存储不可用（Node 桩里没有 localStorage / 隐私模式）时必须静默降级，不抛异常
  assert.equal(panel.readLastTarget(), '')
  panel.writeLastTarget('prod')
  assert.equal(panel.readLastTarget(), '')
  assert.equal(panel.LAST_TARGET_KEY, 'dsh-docker:last-target')
})

await test('切目标的过渡：过期标注 / 内容锁定 / 淡入 / 失败清空', () => {
  const decoded = decodeBundle(code)
  // 归属不一致时出横幅并锁住正文；数据落地才解锁
  // 可见文案：状态 + 归属两段，不写成一句话；完整解释在 title 里
  assert.ok(decoded.includes('正在切换到'), '缺少切换状态文案')
  assert.ok(decoded.includes('当前显示：'), '缺少数据归属文案')
  assert.ok(decoded.includes('切换完成前不可操作'), '缺少 title 里的完整说明')
  assert.ok(!decoded.includes('暂时点不动'), '不该再出现口语化的「点不动」')
  assert.ok(code.includes('dk_switchOverlay'), '缺少切换过渡浮层钩子')
  assert.ok(code.includes('dk_switchPill'), '缺少切换提示胶囊钩子')
  assert.ok(code.includes('@keyframes dk_indeterminate'), '缺少顶部不定长进度条动画')
  // esbuild 会把对象键统一成双引号，所以断言产出形态而不是源码写法
  assert.ok(code.includes('data-stale":'), '缺少正文过期标记（JS 侧设置 data-stale 属性）')
  const staleRule = /\.dk_body\[data-stale="1"\] \.dk_main \{[^}]*\}/.exec(code)?.[0] ?? ''
  assert.ok(staleRule.includes('pointer-events: none'), '过期内容必须锁住指针（否则会把命令发到错的主机）')
  assert.ok(staleRule.includes('opacity'), '过期内容要与当前数据区分')
  // 过渡浮层必须是绝对定位（不推版：横幅会把内容整块推下去）
  const overlayRule = /\.dk_switchOverlay \{[^}]*\}/.exec(code)?.[0] ?? ''
  assert.ok(overlayRule.includes('position: absolute'), '过渡浮层要绝对定位，避免顶部跳动')
  assert.ok(overlayRule.includes('pointer-events: none'), '浮层自身不能吃掉滚动事件')
  // 浮层要水平居中（与 dsh-rss 的加载胶囊同一位置语言：内容区顶部居中）
  assert.ok(overlayRule.includes('justify-content: center'), '胶囊应在内容区顶部居中')
  const pillRule = /\.dk_switchPill \{[^}]*\}/.exec(code)?.[0] ?? ''
  assert.ok(pillRule.includes('color-mix(in srgb, var(--dk-accent)'), '胶囊底色/描边走强调色（蓝色）')
  assert.ok(pillRule.includes('color: var(--dk-accent)'), '胶囊文字走强调色')
  assert.ok(pillRule.includes('backdrop-filter'), '压在旧内容上仍要可读')
  // 淡入动画 + 尊重 reduced-motion
  assert.ok(code.includes('@keyframes dk_dataIn'), '缺少数据落地淡入动画')
  assert.ok(/\.dk_grid \{[^}]*dk_dataIn/.test(code), '网格应带淡入动画')
  assert.ok(code.includes('prefers-reduced-motion'), '动效要尊重 reduced-motion')
  /*
   * 切换失败时清空上个目标的列表，而不是继续张冠李戴。
   * 这条断言看**源码**而不是 bundle：bundle 里局部变量名已被压缩，grep 不到；
   * 而「四个加载器的 catch 都清空自己那份列表」是需要被防回归的结构。
   */
  const source = readFileSync(new URL('../client-src/index.js', import.meta.url), 'utf8')
  for (const clearer of ['setContainers([])', 'setImages([])', 'setNetworks([])', 'setVolumes([])']) {
    assert.ok(source.includes('if (listTargetRef.current !== target) ' + clearer), '切换失败要清空：' + clearer)
  }
})

await test('样式表：折叠态（data-sidebar-collapsed）隐藏入口标签', () => {
  // DSH 外壳（dsh-client-ui-layout）在侧边栏折叠时打这个属性；tty 入口同款规则。
  // 少了它，窄栏里会溢出一条竖排文字（真实踩过的回归）
  assert.ok(code.includes('[data-sidebar-collapsed] [data-dsh-docker-entry]'), '缺少折叠态入口规则')
  assert.ok(code.includes('[data-sidebar-collapsed] .dk_entryLabel'), '缺少折叠态标签隐藏规则')
})

await test('样式表：字段标签锁死 line-height（中英混排的行框不等高会让输入框错开）', () => {
  // 中文走 PingFang SC 回退字体，行框比纯拉丁文本高 ~2px；.dk_fieldGrid 是 align-items:start，
  // 同一行里「docker CLI」和「统计刷新间隔（秒）」的输入框就会差 2px（真实踩过的回归）。
  // 行高必须写死，不能留给字体度量决定 —— 这条只在无浏览器环境里守「规则还在」。
  const rule = /\.dk_label \{[^}]*\}/.exec(code)?.[0] ?? ''
  assert.notEqual(rule, '', '找不到 .dk_label 规则')
  assert.ok(/line-height:\s*[0-9]/.test(rule), '.dk_label 缺少数值 line-height')
})

await test('样式表：聚合日志的过滤行不参与纵向伸缩（否则过滤后整条工具条被撑高）', () => {
  // 同一条 .dk_filterBar 挂在两处：单容器视图在 .dk_tabs（横向行）里，flex:1 1 auto 是
  // 「横向占满剩余宽度」，正确；聚合日志（ComposeLogs）里它是 .dk_logs（纵向 flex）的直接
  // 子项，同一个 flex:1 1 auto 变成**纵向撑高**——过滤到少量行时日志体基准高度变小、剩余
  // 空间出现，工具条与 .dk_logBody 各分一半，整条工具条长成两百多像素的横条（输入框垂直
  // 居中、状态行被顶到下面），也就是「输入文字后界面变形」（真实踩过的回归）。
  // 这里只守「规则还在」，真实布局需浏览器。
  const rule = /\.dk_logs > \.dk_filterBar \{[^}]*\}/.exec(code)?.[0] ?? ''
  assert.notEqual(rule, '', '缺少 .dk_logs > .dk_filterBar 规则')
  assert.ok(/flex:\s*0\s+0\s+auto/.test(rule), '.dk_logs > .dk_filterBar 必须 flex:0 0 auto（否则工具条被纵向撑高）')
})

await test('样式表：分段选中态不得与分段条同底色（暗色下会完全看不见）', () => {
  /*
   * 真实踩过的回归：分段条 `.dk_seg` 底色用 --dk-surface-2，选中态以前用 --dk-surface-solid ——
   * 两者都解析到宿主同一个令牌 `--dsw-alias-bg-layer-2`，暗色主题里**完全同色**，选中态只剩一层
   * 1px 阴影可辨（浅色下能看见，靠的也只是阴影）。改成强调色淡染后，暗色下才有可辨的色彩差。
   *
   * 这条只在无浏览器环境里守「规则形态」：底色差异必须来自色彩，不是来自阴影。
   */
  const barRule = /\.dk_seg \{[^}]*\}/.exec(code)?.[0] ?? ''
  const onRule = /\.dk_segBtn\[data-on="1"\] \{[^}]*\}/.exec(code)?.[0] ?? ''
  assert.notEqual(barRule, '', '找不到 .dk_seg 规则')
  assert.notEqual(onRule, '', '找不到 .dk_segBtn[data-on="1"] 规则')
  assert.ok(!onRule.includes('--dk-surface-solid'), '选中态不得用与分段条同源的 --dk-surface-solid（暗色下会与底色同色）')
  assert.ok(onRule.includes('color-mix(in srgb, var(--dk-accent)'), '选中态要走强调色淡染，靠色彩差而非阴影')
  // 分段条自己仍然可以走 surface-2（它是浅底槽），但两者不得落在同一个令牌上
  const barToken = /background:\s*var\((--[a-z0-9-]+)/.exec(barRule)?.[1] ?? ''
  const onToken = /background:\s*var\((--[a-z0-9-]+)/.exec(onRule)?.[1] ?? ''
  assert.notEqual(barToken, onToken, `分段条与选中态不得同底色令牌（都是 ${barToken}）`)
})

await test('日志 FOLLOW：bundle 内含 SSE 订阅与「回到底部」交互', () => {
  // 静态断言锁住契约（真实点击路径需要浏览器，由手工清单覆盖）：
  assert.ok(code.includes('/logs/stream'), '缺少 SSE 订阅 URL')
  assert.ok(code.includes('EventSource'), '缺少 EventSource 订阅')
  assert.ok(code.includes('dk_pillFollow'), '缺少 FOLLOW 激活态样式钩子')
  assert.ok(code.includes('dk_backToBottom'), '缺少「回到底部」浮层')
  // esbuild 默认 charset=ascii：中文在 bundle 里是 \uXXXX，先解码再断言
  const decoded = code.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
  assert.ok(decoded.includes('实时跟随'), '缺少 FOLLOW 提示文案')
  assert.ok(decoded.includes('回到底部'), '缺少回到底部文案')
  assert.ok(decoded.includes('容器已退出'), '缺少流结束（容器退出）提示')
})

await test('日志 → 会话桥：右键菜单 / 诊断包 / 投递面装配进 bundle', () => {
  // 静态断言只锁**字符串字面量**：局部函数名会被 esbuild minify 改名，断在函数名
  // 上必假（实测产物里查不到 buildAskPrompt / onLogContextMenu / askTarget）。
  assert.ok(code.includes('data-log-ts'), '聚合日志行缺时间戳 dataset（诊断包时间窗的唯一来源）')
  assert.ok(code.includes('dk_menu'), '缺少右键菜单样式钩子')
  // 菜单收成两项：卡片去掉后，编辑面收敛到会话输入框（卡片曾是"多开一个更弱的编辑器"）
  assert.ok(!code.includes('dk_askCard'), '预览卡片样式应已删除')
  assert.ok(code.includes('dk_askToast'), '缺少失败提示样式钩子')
  // 投递必须经**会话作用域**取 conversation：写成根上的会在运行期抛
  // （conversation.send requires a session scope）
  assert.ok(code.includes('"conversation"') || code.includes("'conversation'"), '缺少 scope-addressed 的 conversation 解析')
  assert.ok(code.includes('setDraft'), '缺少「只填输入框」的 setDraft 调用')
  assert.ok(code.includes('.send('), '缺少「直接发送」的 send 调用')
  assert.ok(code.includes('inject(["sessions"]') || code.includes("inject(['sessions']"), 'sessions 未按可选注入挂载')
  // esbuild 默认 charset=ascii：中文在 bundle 里是 \uXXXX，先解码再断言
  const decoded = code.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
  for (const label of ['问 Agent', '直接发送到当前会话', '填入输入框，我先改改', '不构成对你的指令']) {
    assert.ok(decoded.includes(label), '缺少文案：' + label)
  }
  // 拿不到会话时菜单项必须能置灰：降级原因要有可显示文案
  assert.ok(decoded.includes('当前没有打开的会话'), '缺少「无当前会话」的降级原因')
  assert.ok(decoded.includes('宿主未提供 sessions 服务'), '缺少「宿主无 sessions」的降级原因')
})

await test('样式表内联进了 bundle（dk_ 前缀 + 侧边栏入口属性）', () => {
  assert.ok(code.includes('dk_backdrop'))
  assert.ok(code.includes('data-dsh-docker-entry'))
  // dock 模式下的刷新 / 只读徽标容器：必须靠右（margin-left:auto），不能回到工具条最左
  assert.ok(code.includes('dk_toolbarEnd'), '缺少 dock 工具条尾部动作容器')
  const toolbarEndRule = /\.dk_toolbarEnd \{[^}]*\}/.exec(code)?.[0] ?? ''
  assert.ok(toolbarEndRule.includes('margin-left: auto'), '.dk_toolbarEnd 缺少 margin-left:auto（刷新必须靠右）')
  // 工具条末尾两个开关必须成组：分开排时末尾那个会被单独挤到第二行（一行一个复选框）
  assert.ok(code.includes('dk_toolbarToggles'), '缺少「含已停止 / 自动刷新」开关组容器')
  const togglesRule = /\.dk_toolbarToggles \{[^}]*\}/.exec(code)?.[0] ?? ''
  assert.ok(togglesRule.includes('inline-flex'), '.dk_toolbarToggles 必须是不可拆的 inline-flex 组')
  // 搜索框是工具条里唯一可伸缩的项：min-width 太大时它会宁可把末尾开关挤到第二行
  const searchRule = /\.dk_search \{[^}]*\}/.exec(code)?.[0] ?? ''
  const searchMin = Number(/min-width:\s*(\d+)px/.exec(searchRule)?.[1] ?? '999')
  assert.ok(searchMin <= 130, '.dk_search 的 min-width 太大（' + String(searchMin) + 'px）：工具条会多出一行只放开关')
  // esbuild 默认 charset=ascii，中文被写成 \uXXXX：解码后再断言文案
  const decoded = code.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
  assert.ok(decoded.includes('Docker 容器'))
  assert.ok(decoded.includes('只读模式'))
})

await test('镜像管理：bundle 内含详情 / 拉取 SSE / 删除 / prune 入口', () => {
  // 静态断言锁住契约：路由与关键 DOM 钩子必须在 bundle 里（真实点击路径需浏览器）
  for (const path of ['/images/inspect', '/images/remove', '/images/prune', '/images/pull/stream']) {
    assert.ok(code.includes(path), '缺少路由 ' + path)
  }
  assert.ok(code.includes('dk_pullBox'), '缺少拉取进度容器')
  // 拉取入口是图标按钮（文字会把窄栏挤换行）：用 ICON_PULL 独有的路径片段锁住
  assert.ok(code.includes('M5.3 6.5L8 9.2l2.7-2.7'), '缺少拉取镜像图标')
  assert.ok(code.includes('dk_historyTable'), '缺少构建历史表')
  assert.ok(code.includes('dk_layerList'), '缺少层列表')
  const decoded = code.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
  assert.ok(decoded.includes('构建历史'), '缺少构建历史文案')
  assert.ok(decoded.includes('拉取镜像'), '缺少拉取镜像文案')
  assert.ok(decoded.includes('清理 dangling 镜像'), '缺少 dangling 清理文案')
  assert.ok(decoded.includes('删除镜像'), '缺少删除镜像文案')
})

await test('stats 实时跟随：SSE 订阅 + 60 点 sparkline', () => {
  assert.ok(code.includes('/stats/stream'), '缺少统计流订阅 URL')
  assert.ok(code.includes('dk_spark'), '缺少 sparkline 样式钩子')
  assert.ok(code.includes('dk_sparkEmpty'), '缺少 sparkline 占位样式钩子')
  assert.ok(code.includes('dk_statsBar'), '缺少统计工具条样式钩子')
  const decoded = code.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
  assert.ok(decoded.includes('实时跟随资源占用'), '缺少 stats FOLLOW 提示文案')
  assert.ok(decoded.includes('60 点'), '缺少 60 点窗口说明')
  assert.ok(decoded.includes('已切回快照轮询'), '缺少统计流结束后的回落文案')
})

await test('Compose 项目视图：按项目分组 + 客户端聚合日志混流', () => {
  assert.ok(code.includes('dk_project'), '缺少项目卡片样式钩子')
  assert.ok(code.includes('dk_logSvc'), '缺少聚合日志来源前缀钩子')
  assert.ok(code.includes('dk_projectRows'), '缺少项目容器行样式钩子')
  assert.ok(code.includes('dk_composeTable'), '缺少项目服务表')
  const decoded = code.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
  assert.ok(decoded.includes('聚合日志'), '缺少聚合日志页签')
  assert.ok(decoded.includes('个项目'), '缺少项目计数文案')
  assert.ok(decoded.includes('自动滚动'), '缺少聚合日志自动滚动开关')
})

/* ------------------------------------------------------------------ *
 * 容器列表多选 → 临时聚合日志
 * ------------------------------------------------------------------ */

/** 取当前 bundle 里的选择态纯逻辑（factory 返回值上的 __pick 测试缝）。 */
function pickApi() {
  const exports_ = registration.factory((spec) => SEED[spec])
  assert.ok(exports_.__pick !== undefined, '缺少 __pick 测试缝')
  return exports_.__pick
}

function aggLogsApi() {
  const exports_ = registration.factory((spec) => SEED[spec])
  assert.ok(exports_.__aggLogs !== undefined, '缺少 __aggLogs 测试缝')
  return exports_.__aggLogs
}

function carrierApi() {
  const exports_ = registration.factory((spec) => SEED[spec])
  assert.ok(exports_.__carrier !== undefined, '缺少 __carrier 测试缝')
  return exports_.__carrier
}

await test('聚合选择：入口 / 勾选框 / 操作条装配进 bundle', () => {
  // 交互契约用静态断言锁住（真实点击路径需要浏览器，由手工清单覆盖）：
  // 同一个按钮在两种标签间切换、操作条计数与提示、聚合视图标题、Esc 退出。
  const decoded = decodeBundle(code)
  assert.ok(decoded.includes('聚合选择'), '缺少「聚合选择」入口')
  assert.ok(decoded.includes('退出选择'), '缺少选择态下的退出标签（同一个按钮切换）')
  assert.ok(decoded.includes('已选 '), '缺少「已选 N 个容器」计数')
  assert.ok(decoded.includes('聚合日志 · '), '缺少聚合视图标题')
  assert.ok(decoded.includes('至少选择 2 个容器'), '缺少 N<2 的提示')
  assert.ok(decoded.includes('已接近上限，再选下去整个页面会变卡'), '缺少软上限提示')
  // 硬上限文案由「数字 + 后缀」拼出来（数字不写死），所以这里只锁静态部分；
  // 具体数字由下面 pickDecide 的用例断言（它同时钉住「数字从哪来」）。
  assert.ok(decoded.includes('最多 '), '缺少硬上限的「最多」前缀')
  assert.ok(decoded.includes('个容器'), '缺少硬上限的「个容器」文案')
  assert.ok(decoded.includes('会占满浏览器的同源连接，整个页面都会卡'), '缺少硬上限的成因后缀')
  // 上限的来由要写在选择条上（D165）：不写清楚，3 看起来就只是个随手定的数字
  assert.ok(decoded.includes('浏览器每个站点最多同时保持 4 条实时流'), '缺少「预算从哪来」的说明')
  assert.ok(code.includes('dk_pickBudget'), '缺少预算说明的样式钩子')
  // 接线判据走源码级：局部标识符会被压缩改名，产物里 `budget: t(` 认不出来
  const pickSource = readFileSync(new URL('../client-src/index.js', import.meta.url), 'utf8')
  assert.ok(/budget: t\('hint\.pickBudget'\)/.test(pickSource), '预算说明必须真的接到操作条上')
  assert.ok(/props\.budget === undefined \? null/.test(pickSource), '操作条要渲染 budget（拿到不渲染等于没接）')
  assert.ok(decoded.includes('Escape'), '缺少 Esc 退出选择态')
  assert.ok(code.includes('dk_pick'), '缺少勾选框样式钩子')
  assert.ok(code.includes('dk_pickBar'), '缺少聚合操作条样式钩子')
  assert.ok(code.includes('dk_pillPick'), '缺少「聚合选择」激活态样式钩子')
})

await test('聚合选择：上限绑在浏览器同源连接预算上（4 条流 − 事件流 = 3）', () => {
  const pick = pickApi()
  /*
   * D165（2026-10-08 真机实测）：宿主是 HTTP/1.1，每条 EventSource 独占一条同源
   * 连接且不释放。实测常驻流 4 条 → 页内请求 6/6 成功（中位 29ms）；5 条 → 0/6 全部超时
   * （同时刻进程外请求 41ms 正常，堵在浏览器不在宿主）。容器页常开着事件流，所以聚合
   * 只能用掉剩下的 3 条。这条用例把「数字从哪来」钉住，免得后人凭手感调大。
   */
  assert.equal(pick.MAX, 3)
  assert.equal(pick.SSH_MAX, 3, 'SSH 与本地共用同一个浏览器预算（卡页面的是浏览器，不是 MaxSessions）')
  assert.equal(pick.SOFT_MAX, 2)
  assert.equal(pick.BUDGET, 4, '同源预算：4 条常驻流')
  assert.equal(pick.RESERVED, 1, '其中 1 条留给活动条的事件流')
  assert.deepEqual(pick.decide(0), { canRun: false, hint: '' })
  assert.deepEqual(pick.decide(1), { canRun: false, hint: '至少选择 2 个容器' })
  assert.deepEqual(pick.decide(2), { canRun: true, hint: '' })
  // 第 3 个已经在吃满预算前的最后一格：可点，但给一句软提示
  assert.equal(pick.decide(3).canRun, true)
  assert.match(pick.decide(3).hint, /整个页面会变卡/)
  const over = pick.decide(4)
  assert.equal(over.canRun, false, '超过硬上限必须置灰')
  assert.match(over.hint, /最多 3 个容器/)

  // 两个目标类型走同一套上限：真正卡住页面的是浏览器同源预算，与目标是 SSH 还是本机无关
  assert.deepEqual(pick.decide(4, true).canRun, false, 'SSH 目标同样在 4 个时置灰')
  assert.match(pick.decide(4, true).hint, /最多 3 个容器/)
})

await test('聚合选择：勾选增删保序 + 列表刷新按 id 对账', () => {
  const pick = pickApi()
  let ids = []
  ids = pick.toggle(ids, 'a')
  ids = pick.toggle(ids, 'b')
  assert.deepEqual(ids, ['a', 'b'], '新勾选追加在末尾（= 流的打开顺序）')
  ids = pick.toggle(ids, 'a')
  assert.deepEqual(ids, ['b'], '再点一次 = 取消，剩余顺序不变')
  assert.deepEqual(pick.toggle(ids, 'c'), ['b', 'c'])
  // 列表刷新：c 已消失 → 自动剔除；没变化时必须返回原引用（自动刷新 5s 一次，
  // 否则每次都会白触发一轮渲染）
  const containers = [{ id: 'b' }, { id: 'd' }]
  assert.deepEqual(pick.reconcile(['b', 'c'], containers), ['b'])
  const untouched = ['b']
  assert.equal(pick.reconcile(untouched, containers), untouched)
})

await test('聚合选择：聚合视图的 items = 所选容器集合（按勾选顺序）', () => {
  const pick = pickApi()
  const containers = [
    { id: 'a', name: 'web' },
    { id: 'b', name: 'api' },
    { id: 'c', name: 'db' },
  ]
  assert.deepEqual(pick.items(containers, ['c', 'a']).map((item) => item.name), ['db', 'web'])
  // 对账兜底：勾选里混进已消失的 id 时跳过（不抛错、不在结果里留空位）
  assert.deepEqual(pick.items(containers, ['a', 'gone']).map((item) => item.name), ['web'])
  assert.deepEqual(pick.items(containers, []), [])
})

/* ------------------------------------------------------------------ *
 * 容器列表「活动」条（docker events）
 * ------------------------------------------------------------------ */

/** 取当前 bundle 里事件活动条的纯逻辑（factory 返回值上的 __events 测试缝）。 */
function eventsApi() {
  const exports_ = registration.factory((spec) => SEED[spec])
  assert.ok(exports_.__events !== undefined, '缺少 __events 测试缝')
  return exports_.__events
}

await test('活动条：bundle 内含 /events/stream + 活动条装配', () => {
  assert.ok(code.includes('/events/stream'), '缺少事件流订阅 URL')
  assert.ok(code.includes('dk_activity'), '缺少活动条样式钩子')
  assert.ok(code.includes('dk_activityChevron'), '缺少折叠箭头样式钩子')
  assert.ok(code.includes('data-action'), '缺少动作着色键')
  const decoded = decodeBundle(code)
  assert.ok(decoded.includes('活动'), '缺少「活动」标题')
  assert.ok(decoded.includes('实时接收中（docker events）'), '缺少事件流连接态文案')
  assert.ok(decoded.includes('暂无事件'), '缺少空态文案')
  assert.ok(decoded.includes('事件流已结束'), '缺少事件流结束提示')
  assert.ok(decoded.includes('正在自动重连'), '缺少重连文案')
})

await test('活动条：环形缓冲（新的在前、超限丢最旧）与动作标签', () => {
  const api = eventsApi()
  assert.equal(api.LIMIT, 50)
  assert.equal(api.RECENT, 8)
  let list = []
  list = api.append(list, { action: 'start', name: 'a' }, api.LIMIT)
  list = api.append(list, { action: 'die', name: 'b', exitCode: 137 }, api.LIMIT)
  assert.deepEqual(list.map((event) => event.name), ['b', 'a'], '新事件排在最前')
  // 超限丢最旧：塞 LIMIT + 5 条，留下的应是最新 LIMIT 条
  let many = []
  for (let index = 0; index < api.LIMIT + 5; index += 1) many = api.append(many, { action: 'start', name: 'c' + String(index) }, api.LIMIT)
  assert.equal(many.length, api.LIMIT)
  assert.equal(many[0].name, 'c' + String(api.LIMIT + 4))
  assert.equal(many[many.length - 1].name, 'c5')
  // die 带上退出码更好认；其它动作原样
  assert.equal(api.actionText({ action: 'die', exitCode: 137 }), 'die(137)')
  assert.equal(api.actionText({ action: 'die' }), 'die')
  assert.equal(api.actionText({ action: 'start' }), 'start')
  assert.equal(api.actionText({ action: 'health_status: healthy' }), 'health_status: healthy')
  assert.equal(api.actionText({ action: '' }), '?')
})

await test('活动条：时间格式化（本地时区）与防抖（连续事件只刷一次列表）', async () => {
  const api = eventsApi()
  assert.equal(api.DEBOUNCE_MS, 500)
  const at = new Date(1700000000 * 1000)
  const pad = (value) => String(value).padStart(2, '0')
  const expected = pad(at.getHours()) + ':' + pad(at.getMinutes()) + ':' + pad(at.getSeconds())
  assert.equal(api.timeText(1700000000), expected)
  assert.equal(api.timeText(null), '--:--:--')

  // 防抖：一帧事件一次列表重取会把刚省掉的轮询成本原样搬回来，所以必须合并
  let runs = 0
  const debounced = api.debounce(20, () => { runs += 1 })
  debounced.schedule()
  debounced.schedule()
  debounced.schedule()
  await new Promise((resolve) => setTimeout(resolve, 60))
  assert.equal(runs, 1, '连续 3 次事件只应触发 1 次刷新')
  debounced.schedule()
  debounced.cancel()
  await new Promise((resolve) => setTimeout(resolve, 60))
  assert.equal(runs, 1, 'cancel 后不应再触发（切 target / 关面板的清理路径）')
})

await test('事件流断开：状态判定只认 closed，unsupported 不给重连', () => {
  const api = eventsApi()
  assert.ok(api.canReconnect !== undefined, '缺少 __events.canReconnect 测试缝')
  assert.equal(api.canReconnect('closed'), true, 'closed 是终止态，必须能重连')
  // 其余都不是「需要人工重连」：open 正常、connecting / reconnecting 在自愈路上
  assert.equal(api.canReconnect('open'), false)
  assert.equal(api.canReconnect('connecting'), false)
  assert.equal(api.canReconnect('reconnecting'), false)
  // 环境没有 EventSource：重连必然再失败，给按钮等于骗人
  assert.equal(api.canReconnect('unsupported'), false)
  assert.equal(api.canReconnect(''), false)
  assert.equal(api.canReconnect(undefined), false)
})

await test('事件流断开：活动条接线（兄弟按钮、不是嵌套按钮）与 ⟳ 接手动刷新', () => {
  const decoded = decodeBundle(code)
  assert.ok(decoded.includes('重连'), '缺少重连按钮文案')
  assert.ok(decoded.includes('不会自动恢复'), '缺少「不会自愈」的说明')
  assert.ok(code.includes('dk_activityHeadRow'), '缺少头行容器（兄弟布局的前提）')
  assert.ok(code.includes('dk_activityRetry'), '缺少重连按钮样式钩子')

  /*
   * 接线判据走**源码级**（局部标识符会被压缩改名，产物里只剩属性名 / 字符串）：
   * 与上面那条「哨兵被拦在换目标逻辑之前」同一套路。
   */
  const source = readFileSync(new URL('../client-src/index.js', import.meta.url), 'utf8')

  // 按钮不能嵌套：折叠头本身是 <button>，重连必须是它的兄弟
  const headRow = source.indexOf('dk_activityHeadRow')
  const retry = source.indexOf('dk_activityRetry')
  assert.ok(headRow !== -1, 'ActivityBar 应有头行容器')
  assert.ok(retry !== -1, 'ActivityBar 应有重连按钮')
  assert.ok(headRow < retry, '重连按钮应挂在头行容器（head 的兄弟）里')
  const headOpen = source.indexOf("className: 'dk_activityHead'")
  assert.ok(headOpen !== -1)
  assert.ok(retry > headOpen, '重连是要排在折叠头之后的兄弟')
  // 折叠头的 children 里不许出现重连按钮（那就是嵌套按钮）
  const headClose = source.indexOf("}, 'head')", headOpen)
  assert.ok(headClose !== -1, '折叠头应有结束标记')
  assert.ok(!source.slice(headOpen, headClose).includes('dk_activityRetry'), '重连按钮不能嵌在折叠按钮里（非法 HTML + 读屏会听成一个动作）')

  // 事件流 effect 的依赖里必须有重连令牌，否则点了不重开
  assert.ok(/\}, \[active, view, target, eventsReconnect\]\)/.test(source), '事件流 effect 的依赖数组里必须含 eventsReconnect（否则点了不重开）')
  // 令牌必须自增：布尔翻回 false 时 effect 看不出「又要求了一次」
  assert.ok(/setEventsReconnect\(\(value\) => value \+ 1\)/.test(source), '重连令牌必须自增')

  /*
   * ⟳ 走 refreshManually（既刷列表也重连）；AUTO REFRESH 轮询必须仍只调 refresh——
   * 塞进轮询会让一条已终止的流被不断重开，既掩盖「它断了」，又白建 SSE。
   */
  assert.ok(source.includes('refreshManually'), '缺少 ⟳ 的手动刷新包装')
  assert.ok(/setInterval\(refresh,/.test(source), 'AUTO REFRESH 轮询不该被改成重连（否则把终止态掩盖成自愈）')
  assert.ok(/onClick: refreshManually/.test(source), '⟳ 按钮应接手动刷新')

  /*
   * 重连成功后要补一次全量列表刷新：daemon 全程没起时流**从未 open 过**，只按
   * 「opened」判会把补偿一起省掉——活动条绿了但列表还停在「这个目标的数据没读到」，
   * 看着像好了其实没好。所以判据里必须把「这次是用户点的重连」也算进去。
   */
  assert.ok(/manualReconnect/.test(source), '缺少「这次是手动重连」的判定')
  assert.ok(/eventsOpenedRef\.current\.opened \|\| manualReconnect/.test(source),
    '重连补偿的判据必须含 manualReconnect（否则从未 open 过的流重连后列表不刷新）')
})

/*
 * D164：服务端**拒绝了**这条流时，「重连」看起来毫无反应——真机现场（2026-10-08）：
 * 248 上长流配额恒满 8/8，每次点重连都被拒；而客户端把 `event: error` 的 data 整个丢掉，
 * 只置 `closed`，于是界面与点击前逐像素相同。统计流一直是读出 message 的，这里补齐。
 */
await test('D164：事件流的 error 帧要解出服务端原因（而不是丢掉）', () => {
  const api = eventsApi()
  assert.ok(api.errorMessage !== undefined, '缺少 __events.errorMessage 测试缝')
  // 配额拒绝：必须原样带出那句可执行的文案
  const refused = api.errorMessage({ data: JSON.stringify({ message: '目标 248 上已有 8 条实时流（上限 8）' }) })
  assert.equal(refused, '目标 248 上已有 8 条实时流（上限 8）')
  // 非 JSON 的 data：整段当原因（宁可显示原文，也别显示「不知道」）
  assert.equal(api.errorMessage({ data: 'boom' }), 'boom')
  // 连接层错误（无 data）：不是「服务端说了什么」，必须返回空串——
  // 那种情况 EventSource 会自己重连，不能冒充成一次被拒绝的重连
  assert.equal(api.errorMessage({}), '')
  assert.equal(api.errorMessage({ data: '' }), '')
  assert.equal(api.errorMessage(new Event('error')), '')
  assert.equal(api.errorMessage(null), '')
  assert.equal(api.errorMessage(undefined), '')
  // 畸形 JSON 不许把半截载荷当文案漏出去
  assert.equal(api.errorMessage({ data: '{"message":' }), '{"message":')
  // message 不是字符串时退回原文，而不是渲染出 [object Object]
  assert.equal(api.errorMessage({ data: JSON.stringify({ message: 42 }) }), '{"message":42}')
})

await test('D164：被拒原因要接到界面上（接线判据）', () => {
  const decoded = decodeBundle(code)
  assert.ok(decoded.includes('重连被拒'), '缺少「被拒绝」的提示文案')
  assert.ok(decoded.includes('不会自动恢复'), '原有的「不会自愈」说明必须保留')
  const source = readFileSync(new URL('../client-src/index.js', import.meta.url), 'utf8')
  // 拒绝原因必须进 state，并作为 props 传给活动条（只解出来不传等于没修）
  assert.ok(/setEventsRefused\(message\)/.test(source), 'error 帧的原因必须写进 state')
  assert.ok(/refused: eventsRefused/.test(source), '活动条必须拿到被拒原因')
  assert.ok(/hint\.eventsReconnectRefused/.test(source), '活动条必须渲染被拒文案')
  // 重连成功要清掉（否则「上次被拒」会一直挂着，看着像现在还坏着）
  assert.ok(/setEventsRefused\(''\)/.test(source), '重连成功 / 重新建流时必须清掉上一条原因')
})

/*
 * 2026-10-11 用户现场：目标连不上 / SSH 正在重连时，活动条已经亮成绿色的「实时接收中
 * （docker events）」，而那条流一个字都没收到。成因是「已连接」只等于**响应头到了**——
 * 宿主先把 200 + text/event-stream flush 出去，再去起 `docker events`（src/index.ts 的
 * readyOnStart）；`acquire()` 建连 / 等池 / D150 重建可以卡十几秒。
 *
 * 修法：宿主在**管道真的起来**时发一帧 `ready`（StreamHandlers.onStart），客户端只认它。
 * 宿主侧的行为由 vitest 的 ready 用例钉住，这里钉客户端接线。
 */
await test('活动条 / 日志 / 统计 / 拉取：绿点只认 ready 帧（响应头不算「在收数据」）', () => {
  const index = readFileSync(new URL('../client-src/index.js', import.meta.url), 'utf8')
  const logStream = readFileSync(new URL('../client-src/log-stream.js', import.meta.url), 'utf8')
  const readyAt = index.indexOf("es.addEventListener('ready'")
  assert.ok(readyAt !== -1, '事件流必须监听宿主的 ready 帧')
  const openAt = index.indexOf('const applyEventsReady')
  assert.ok(openAt !== -1, '缺 applyEventsReady（ready 与各兜底判据共用的那一个出口）')
  assert.ok(index.indexOf("setEventsStatus('open')") > openAt, "setEventsStatus('open') 必须落在 applyEventsReady 里")
  const readyCount = (index.match(/addEventListener\('ready'/g) ?? []).length
  assert.ok(readyCount >= 3, '统计 / 事件 / 拉取三条 SSE 都要监听 ready（实际 ' + String(readyCount) + '）')
  // 日志订阅同一口径（subscribeLogStream 供单容器与聚合两个视图共用）
  assert.ok(/addEventListener\('ready'/.test(logStream), '日志订阅也必须监听 ready')
  /*
   * 但**不许**把 onopen 无条件下重新当成「已就绪」：事件流那条 onopen 必须挂在
   * 「宿主是旧的」这个闸后面（否则假绿回归）；日志订阅的 onopen 里不许出现任何 onStatus。
   */
  assert.ok(/es\.onopen = \(\) => \{\s*eventsLinkedRef\.current = true\s*if \(!hostReadyFrameRef\.current\) applyEventsReady\(\)/.test(index),
    '事件流的 onopen 只许在「旧宿主」分支里兜底（hostReadyFrameRef 闸门）')
  assert.ok(!/onopen\s*=\s*\(\)\s*=>\s*\{[^}]*onStatus/.test(logStream), '日志订阅的 onopen 不许置 open')
})

/*
 * 2026-10-11 用户第二条反馈（test profile 实测）：**宿主进程还是旧代码、浏览器却是新
 * client.js** 这种开发档错位下，新客户端死等一帧永远不来的 `ready`，界面被钉在
 * 「正在连接事件流…」（卡片能读到容器，活动条却在转）。三类兜底各管一段：
 *   - 事件流：`/config` 的 `streamProtocol` 协商 + 第一个真实事件帧；
 *   - 日志 / 统计 / 拉取：第一个真实数据帧（那些流一定会很快出帧）。
 */
await test('旧宿主（无 ready 帧）不许把界面钉在「连接中」：版本协商 + 数据帧兜底', () => {
  const api = eventsApi()
  assert.ok(api.hostSendsReadyFrame !== undefined, '缺少 __events.hostSendsReadyFrame 测试缝')
  assert.equal(api.hostSendsReadyFrame({ streamProtocol: 2 }), true, 'streamProtocol=2 才是发 ready 的宿主')
  assert.equal(api.hostSendsReadyFrame({ streamProtocol: 3 }), true, '更高的协议版本同样发 ready')
  assert.equal(api.hostSendsReadyFrame({ streamProtocol: 1 }), false, 'streamProtocol=1 → 老宿主，退回响应头判据')
  assert.equal(api.hostSendsReadyFrame({}), false, '比本包更老的宿主根本没有这个字段 → 不发 ready')
  assert.equal(api.hostSendsReadyFrame(null), true, 'config 还没加载：先按发 ready 处理，到达后由 effect 纠正')
  const index = readFileSync(new URL('../client-src/index.js', import.meta.url), 'utf8')
  // config 晚到的一拍：已经拿到响应头但还没就绪 → 重开一次让 onopen 的回退判据生效
  assert.ok(/if \(!next && eventsLinkedRef\.current\) setEventsReconnect/.test(index),
    'config 晚到时必须补一次重开（否则停在「正在连接事件流…」）')
  assert.ok(/if \(eventsLinkedRef\.current\) applyEventsReady\(\)/.test(index),
    '第一个真实事件帧也算就绪（旧宿主 / 仿真宿主没有 ready 时靠它点亮）')
  assert.ok(/setStatsStatus\('open'\)/.test(index.slice(index.indexOf('const onStats'))),
    '统计流：第一个采样就是「已就绪」的证据')
  assert.ok(/setStatus\('open'\)/.test(index.slice(index.indexOf('const onLine = '), index.indexOf('const onEnd', index.indexOf('const onLine = ')))),
    '拉取流：第一个进度帧就是「已就绪」的证据')
  const logStream = readFileSync(new URL('../client-src/log-stream.js', import.meta.url), 'utf8')
  assert.ok(/markOpen\(\)/.test(logStream), '日志订阅缺少 markOpen')
  const lineBlock = logStream.slice(logStream.indexOf("addEventListener('line'"), logStream.indexOf("addEventListener('skip'"))
  assert.ok(lineBlock.includes('markOpen()'), '日志订阅：第一行真实日志必须点亮「已就绪」（旧宿主唯一证据）')
})

await test('变更操作执行中态：按钮转圈 + 卡片锁组 + 确认框不关', () => {
  // 三处过渡态钩子：按钮 data-busy（图标换转圈）、卡片 data-pending（整组变更按钮压暗锁住）、
  // 确认框 k_confirmBusy（保持打开 + 「执行中…」）。真实点击路径需要浏览器，这里锁契约。
  assert.ok(code.includes('data-busy'), '缺少按钮执行中钩子')
  assert.ok(code.includes('data-pending'), '缺少卡片执行中钩子')
  assert.ok(code.includes('dk_confirmBusy'), '缺少确认框忙碌样式钩子')
  const decoded = decodeBundle(code)
  assert.ok(decoded.includes('执行中…'), '缺少确认框忙碌文案')
  assert.ok(decoded.includes('正在执行 '), '缺少按钮「正在执行 …」提示')
  assert.ok(decoded.includes('…请稍候'), '缺少「请稍候」提示')
  // busy 按钮同时也是 disabled：必须把 disabled 的 opacity .45 顶回 1，否则转圈跟着变淡
  const busyRule = /\.dk_iconBtn\[data-busy="1"\]:disabled \{[^}]*\}/.exec(code)?.[0] ?? ''
  assert.ok(busyRule.includes('opacity: 1'), '.dk_iconBtn[data-busy] 没顶掉 disabled 的透明度')
  const busyConfirmRule = /\.dk_confirm\[data-busy="1"\] \.dk_btnDanger \{[^}]*\}/.exec(code)?.[0] ?? ''
  assert.ok(busyConfirmRule.includes('opacity: 1'), '忙碌确认键没顶掉 disabled 的透明度')
})

/* ------------------------------------------------------------------ *
 * 网络 / 卷（列表 + 详情）
 * ------------------------------------------------------------------ */

await test('网络 / 卷：五段切换 + 两个列表 + 详情装配进 bundle', () => {
  // 静态断言锁契约（真实点击路径需要浏览器，由手工清单覆盖）
  const decoded = decodeBundle(code)
  // 分段从三段长到五段
  for (const label of ['容器', '镜像', 'Compose', '网络', '卷']) {
    assert.ok(decoded.includes(label), '缺少分段标签 ' + label)
  }
  // 8 个新端点都在客户端有调用点
  for (const path of ['/networks', '/networks/inspect', '/networks/remove', '/networks/prune', '/volumes', '/volumes/inspect', '/volumes/remove', '/volumes/prune']) {
    assert.ok(code.includes(path), '缺少端点调用 ' + path)
  }
  // 样式钩子：可点击行 + 路径列省略
  assert.ok(code.includes('dk_rowClickable'), '缺少可点击行样式钩子')
  assert.ok(code.includes('dk_pathCell'), '缺少挂载点列样式钩子')
  // 图标（ICON_NETWORK / ICON_VOLUME 独有的路径片段）
  assert.ok(code.includes('M5.1 12.2h5.8'), '缺少网络图标')
  assert.ok(code.includes('M3.4 4.2v7.6'), '缺少卷图标')
  // 列表列名与详情页文案
  assert.ok(decoded.includes('接入的容器'), '缺少「接入的容器」页签')
  assert.ok(decoded.includes('子网'), '缺少子网一行')
  assert.ok(decoded.includes('挂载点'), '缺少挂载点一行')
  assert.ok(decoded.includes('搜索网络'), '缺少网络搜索框')
  assert.ok(decoded.includes('搜索卷'), '缺少卷搜索框')
  // 分段容器允许横向滚动（五段在 520px 窄栏里可能放不下）
  const segRule = /\.dk_seg \{[^}]*\}/.exec(code)?.[0] ?? ''
  assert.ok(segRule.includes('overflow-x: auto'), '.dk_seg 没允许横向滚动')
})

await test('网络 / 卷：删除与 prune 的 gated 文案 + 卷清理的数据警告', () => {
  const decoded = decodeBundle(code)
  // 每个 prune / 删除都有「需要打开允许变更操作」的两态文案（图标化后 title 是唯一入口）
  assert.ok(decoded.includes('清理未使用的网络'), '缺少网络 prune 文案')
  assert.ok(decoded.includes('清理未使用的卷'), '缺少卷 prune 文案')
  assert.ok(decoded.includes('清理网络需要打开「允许变更操作」'), '缺少网络 prune 门控文案')
  assert.ok(decoded.includes('清理卷需要打开「允许变更操作」'), '缺少卷 prune 门控文案')
  assert.ok(decoded.includes('删除网络'), '缺少删除网络文案')
  assert.ok(decoded.includes('删除卷'), '缺少删除卷文案')
  // 卷 prune 是唯一会删数据的：确认文案必须写明
  assert.ok(decoded.includes('卷里的数据会一起删除'), '缺少卷 prune 的数据丢失警告')
  // 网络删除失败时的可执行提示
  assert.ok(decoded.includes('还有容器接着'), '缺少网络被占用时的提示')
})

/* ------------------------------------------------------------------ *
 * 多目标总览（不选目标，一屏看全部主机）
 * ------------------------------------------------------------------ */

/** 取当前 bundle 里的总览纯逻辑 / 正文渲染（factory 返回值上的 __overview 测试缝）。 */
function overviewApi() {
  const exports_ = registration.factory((spec) => SEED[spec])
  assert.ok(exports_.__overview !== undefined, '缺少 __overview 测试缝')
  return exports_.__overview
}

/** 造一格总览数据（默认一个 SSH 目标，且已经答完）。 */
function ovGroup(name, containers, extra) {
  return { name, kind: 'ssh', label: 'root@10.0.0.5:22', containers, error: '', loaded: true, ...(extra ?? {}) }
}

/**
 * 遍历 bundle 返回的 jsx 树：它只是 { type, props } 的普通对象（见上面的 jsx/jsxs 桩），
 * 所以离线冒烟真能「渲染」总览正文并断言，而不是只 grep bundle 里的字符串。
 */
function treeFind(node, predicate, out) {
  const found = out ?? []
  if (node === null || node === undefined || node === false) return found
  if (Array.isArray(node)) {
    for (const child of node) treeFind(child, predicate, found)
    return found
  }
  if (typeof node !== 'object') return found
  if (predicate(node)) found.push(node)
  treeFind(node.props === undefined ? undefined : node.props.children, predicate, found)
  return found
}

/** 树里所有文本拼起来（断言文案用）。 */
function treeText(node) {
  if (node === null || node === undefined || node === false) return ''
  if (Array.isArray(node)) return node.map(treeText).join('')
  if (typeof node === 'string') return node
  if (typeof node === 'number') return String(node)
  if (typeof node !== 'object') return ''
  return treeText(node.props === undefined ? undefined : node.props.children)
}

await test('总览：入口与文案装配进 bundle（只读页，不做跨目标操作）', () => {
  const decoded = decodeBundle(code)
  assert.ok(decoded.includes('总览'), '缺少「总览」入口')
  assert.ok(decoded.includes('（总览 · 全部目标）'), '缺少总览态的目标选择器说明项')
  assert.ok(decoded.includes('个目标不可达'), '缺少不可达横幅标题')
  assert.ok(decoded.includes('一切正常'), '缺少空态文案')
  assert.ok(decoded.includes('所有目标上都没有需要关注的容器'), '缺少空态说明')
  assert.ok(decoded.includes('需关注容器'), '缺少异常表标题')
  assert.ok(code.includes('dk_ovCards'), '缺少计数卡行样式钩子')
  assert.ok(code.includes('dk_ovCard'), '缺少计数卡钩子')
  assert.ok(code.includes('dk_ovCount'), '缺少计数钩子')
  assert.ok(code.includes('dk_pillOverview'), '缺少总览 pill 样式钩子')
  assert.ok(code.includes('dk_ovTable'), '缺少异常表样式钩子')
  assert.ok(code.includes('dk_rowClickable'), '缺少异常表的可点击行钩子')
  const cardsRule = /\.dk_ovCards \{[^}]*\}/.exec(code)?.[0] ?? ''
  assert.ok(cardsRule.includes('grid'), '.dk_ovCards 应该是网格（一屏多个目标）')
  const errRule = /\.dk_ovCard\[data-state="error"\] \{[^}]*\}/.exec(code)?.[0] ?? ''
  assert.ok(errRule.includes('--dk-danger'), '不可达的计数卡缺少危险色提示')
  assert.ok(code.includes('dk_ovCardLoading'), '缺少计数卡读取态钩子')
  const loadingRule = /\.dk_ovCard\[data-state="loading"\] \{[^}]*\}/.exec(code)?.[0] ?? ''
  assert.ok(loadingRule.includes('opacity'), '读取中的计数卡应压暗，与已有结果区分')
  /*
   * 总览里不再渲染「操作失败」那条单目标失败横幅：它讲的是当前这一个目标，而总览自己按
   * 目标归因（红卡 + 上方不可达横幅）——两条一起出现，同一个 SSH 超时会被看成两个故障。
   * 这条正则贴着压缩后的形状（和其它静态断言一样），minifier 一变就会显式失败。
   *
   * i18n 迁移后文案进了目录：这里从「钉中文字面量」改成「钉键名」——断言的**结构**没变
   * （仍然是「总览短路在横幅之前」），只是横幅标题从内联字符串变成了 `t('banner.actionFailed')`。
   * 渲染出来的文案由上面的 catalog 断言与各视图用例覆盖。
   */
  assert.match(decoded, /[\w$]+===""\|\|[\w$]+==="overview"\?null:[\s\S]{0,60}actionFailed/, '总览里不该再渲染单目标失败横幅')
})

await test('总览：计数口径与列表页「运行中」一致，异常表只收 unhealthy / restarting', () => {
  const api = overviewApi()
  assert.deepEqual(api.counts([
    { state: 'running', health: null },
    { state: 'paused', health: null },
    { state: 'restarting', health: null },
    { state: 'exited', health: null },
    { state: 'created', health: null },
    { state: 'running', health: 'unhealthy' },
  ]), { running: 4, stopped: 2, unhealthy: 1 })
  assert.deepEqual(api.abnormal([
    { name: 'a', state: 'running', health: 'unhealthy' },
    { name: 'b', state: 'restarting', health: null },
    { name: 'c', state: 'exited', health: null },
    { name: 'd', state: 'running', health: 'starting' },
  ]).map((item) => item.name), ['a', 'b'], 'exited 不算异常：没有 exitCode，无法区分崩溃退出与人工停掉')
})

await test('总览：不健康优先于重启中，同级按目标配置顺序；不可达目标独立成清单', () => {
  const api = overviewApi()
  const data = api.data([
    ovGroup('prod', [
      { id: 'p1', name: 'web', state: 'running', health: 'unhealthy', image: 'nginx:1.27', status: 'Up (unhealthy)' },
      { id: 'p2', name: 'api', state: 'restarting', health: null, image: 'app:1', status: 'Restarting' },
      { id: 'p3', name: 'ok', state: 'running', health: null, image: 'redis:7', status: 'Up' },
    ]),
    ovGroup('stg', [
      { id: 's1', name: 'worker', state: 'restarting', health: null, image: 'app:1', status: 'Restarting' },
      { id: 's2', name: 'db', state: 'running', health: 'unhealthy', image: 'pg:16', status: 'Up (unhealthy)' },
    ]),
    ovGroup('lab', [], { error: 'connect ETIMEDOUT 10.0.0.7:22' }),
  ])
  assert.deepEqual(data.rows.map((row) => row.target + '/' + row.item.name), ['prod/web', 'stg/db', 'prod/api', 'stg/worker'], '不健康置顶，同级按目标顺序')
  assert.deepEqual(data.cards.map((card) => [card.name, card.running, card.stopped, card.unhealthy]), [
    ['prod', 3, 0, 1],
    ['stg', 2, 0, 1],
    ['lab', 0, 0, 0],
  ])
  assert.deepEqual(data.unreachable.map((card) => card.name), ['lab'])
  assert.equal(data.loading, false)
})

await test('总览：渐进式落地（一格失败不牵连其余）+ 失败文案压成一行', () => {
  const api = overviewApi()
  let groups = [
    { name: 'prod', kind: 'ssh', label: 'root@10.0.0.5:22', containers: [], error: '', loaded: false },
    { name: 'lab', kind: 'ssh', label: 'root@10.0.0.7:22', containers: [], error: '', loaded: false },
  ]
  groups = api.patch(groups, 'prod', { containers: [{ id: 'a', name: 'web', state: 'running', health: null }], loaded: true })
  const untouched = api.patch(groups, 'nobody', { loaded: true })
  assert.equal(untouched, groups, '目标名不匹配时必须返回原引用（自动刷新每轮都 setState 会白渲染）')
  groups = api.patch(groups, 'lab', { error: ('BOOM ' + 'x'.repeat(400)), loaded: true })
  const data = api.data(groups)
  assert.equal(data.cards[0].error, '', 'prod 的成功结果不能被 lab 的失败污染')
  assert.equal(data.cards[0].running, 1)
  assert.equal(data.cards[1].error.length, api.ERROR_MAX + 1, '失败文案应截断到上限 + 省略号')
  assert.equal(data.unreachable.length, 1)
  assert.equal(data.loading, false)
  assert.equal(api.errorText('first\nsecond'), 'first', 'SSH 报错只留首行')
  assert.equal(api.errorText(''), '未知错误')
})

await test('总览：渲染多目标计数卡 + 异常置顶表 + 单目标失败横幅（遍历 jsx 树）', () => {
  const api = overviewApi()
  const opened = []
  const tree = api.body(api.data([
    ovGroup('本机', [{ id: 'l1', name: 'web', state: 'running', health: null, image: 'nginx:1.27', status: 'Up' }], { kind: 'local', label: '本机' }),
    ovGroup('prod', [
      { id: 'p1', name: 'api', state: 'restarting', health: null, image: 'app:1', status: 'Restarting' },
      { id: 'p2', name: 'db', state: 'running', health: 'unhealthy', image: 'pg:16', status: 'Up (unhealthy)' },
    ]),
    ovGroup('lab', [], { error: 'connect ETIMEDOUT 10.0.0.7:22' }),
  ]), {
    onOpenTarget: (name) => opened.push(['target', name]),
    onOpenContainer: (name, item) => opened.push(['container', name, item.name]),
  })
  const cards = treeFind(tree, (el) => el.props?.className === 'dk_ovCard')
  assert.equal(cards.length, 3, '每个目标一张计数卡')
  const texts = treeText(tree)
  for (const expected of ['本机', '运行中', '已停止', '不健康', '需关注容器（2）', 'api', 'db', '不可达']) {
    assert.ok(texts.includes(expected), '渲染结果缺少 ' + expected)
  }
  // 原因徽标（摘要兜底口径）：restarting → 反复重启、unhealthy → 不健康
  const reasons = treeFind(tree, (el) => el.props?.className === 'dk_reason')
  assert.deepEqual(reasons.map((el) => el.props['data-reason']).sort(), ['restarting', 'unhealthy'], '异常行应带原因徽标')
  // 横幅是组件元素（className 由 Banner 自己给），所以断言它的入参而不是 className
  assert.equal(treeFind(tree, (el) => typeof el.props?.title === 'string' && el.props.title.includes('个目标不可达')).length, 1, '单个目标失败应出一条横幅')
  assert.equal(cards.filter((card) => card.props['data-state'] === 'error').length, 1)
  const rows = treeFind(tree, (el) => el.props?.className === 'dk_rowClickable')
  assert.equal(rows.length, 2)
  assert.equal(treeFind(tree, (el) => el.props?.className === 'dk_actionBar').length, 0, '总览是只读页，不该出现变更入口')
  assert.equal(treeFind(tree, (el) => el.props?.className === 'dk_iconBtn').length, 0, '总览不该出现任何操作按钮')
  rows[0].props.onClick()
  assert.deepEqual(opened, [['container', 'prod', 'db']], '点第一行 = 不健康那条，且带的是它自己的 target')
  cards[1].props.onClick()
  assert.deepEqual(opened[1], ['target', 'prod'], '点计数卡 = 切到该目标的常规列表')
  const badges = treeFind(tree, (el) => el.props !== undefined && Object.prototype.hasOwnProperty.call(el.props, 'health'))
  assert.deepEqual(badges.map((el) => el.props.health), ['unhealthy', null], '状态格复用 Badge，拿到规范化后的 health')
})

await test('总览：/attention 权威结果优先于摘要兜底（OOM 可识别）', () => {
  const api = overviewApi()
  const tree = api.body(api.data([
    ovGroup('prod', [
      // 摘要层看不出问题（running + healthy），只有 inspect 才知道它刚被 OOM 杀过
      { id: 'x1', name: 'worker', state: 'running', health: null, image: 'app:1', status: 'Up 3 seconds' },
    ], {
      attention: [{
        id: 'x1',
        name: 'worker',
        state: 'running',
        health: null,
        status: 'Up 3 seconds',
        image: 'app:1',
        reasons: ['oom'],
        oomKilled: true,
        exitCode: 137,
        restartCount: 9,
      }],
    }),
  ]), { onOpenTarget: () => {}, onOpenContainer: () => {} })
  const texts = treeText(tree)
  assert.ok(texts.includes('被 OOM 杀'), '权威原因应渲染出「被 OOM 杀」')
  assert.ok(texts.includes('需关注容器（1）'), '异常表应包含这条权威结果')
  const reasons = treeFind(tree, (el) => el.props?.className === 'dk_reason')
  assert.deepEqual(reasons.map((el) => el.props['data-reason']), ['oom'])

  // 同一份容器，没有 attention 时摘要兜底认不出 → 一切正常（这是精度差异，不是 bug）
  const fallbackTree = api.body(api.data([
    ovGroup('prod', [{ id: 'x1', name: 'worker', state: 'running', health: null, image: 'app:1', status: 'Up 3 seconds' }]),
  ]), { onOpenTarget: () => {}, onOpenContainer: () => {} })
  assert.ok(treeText(fallbackTree).includes('一切正常'), '没有 attention 且摘要正常时应显示一切正常')
})

await test('总览：空态分三种——一切正常 / 还没答完 / 没有目标', () => {
  const api = overviewApi()
  const actions = { onOpenTarget: () => {}, onOpenContainer: () => {} }
  const clean = api.body(api.data([ovGroup('本机', [{ id: 'a', name: 'web', state: 'running', health: null, image: 'nginx', status: 'Up' }], { kind: 'local' }) ]), actions)
  const cleanText = treeText(clean)
  assert.ok(cleanText.includes('一切正常'), '没有异常时应显示「一切正常」')
  assert.equal(treeFind(clean, (el) => el.props?.className === 'dk_ovTable').length, 0, '无异常时不该有异常表')
  const pendingTree = api.body(api.data([
    ovGroup('本机', [{ id: 'a', name: 'web', state: 'running', health: null, image: 'nginx', status: 'Up' }], { kind: 'local' }),
    { name: 'prod', kind: 'ssh', label: '', containers: [], error: '', loaded: false },
  ]), actions)
  const pending = treeText(pendingTree)
  assert.ok(!pending.includes('一切正常'), '还有目标没答完时不能下「一切正常」的结论')
  assert.ok(pending.includes('读取中'), '未答完时应显示读取中')
  // 还没答完的卡不能显示 0/0/0（会被读成「这台机器没有容器」）：只给读取态
  const pendingCards = treeFind(pendingTree, (el) => el.props?.className === 'dk_ovCard')
  assert.deepEqual(pendingCards.map((card) => card.props['data-state']), ['ok', 'loading'])
  assert.equal(treeFind(pendingTree, (el) => el.props?.className === 'dk_ovCardLoading').length, 1)
  assert.equal(treeFind(pendingTree, (el) => el.props?.className === 'dk_ovCardCounts').length, 1, '只有答完的那张卡出数字')
  assert.ok(treeText(api.body(api.data([]), actions)).includes('还没有配置 Docker 目标'), '没有目标时应引导去设置卡片')
})

/* ------------------------------------------------------------------ *
 * 列表写入闸（旧请求作废）
 * ------------------------------------------------------------------ */

await test('列表写入闸：被新请求取代的那一代作废（切目标 / 换页后迟到的响应不许写状态）', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  assert.ok(exports_.__listSeq !== undefined, '缺少 __listSeq 测试缝')
  const seq = exports_.__listSeq.make()
  const first = seq.next()
  assert.ok(seq.isCurrent(first), '当前这一代有效')
  const second = seq.next()
  assert.ok(!seq.isCurrent(first), '被新请求取代的那一代必须作废（否则旧目标的数据会盖住新目标）')
  assert.ok(seq.isCurrent(second))
  assert.ok(!seq.isCurrent(0))
  // 闸必须真的接在加载器上，而不是只活在测试缝里：属性名不会被压缩改名，按出现次数兜。
  // 四个列表加载器 + 总览，各在 then / catch / finally(settle) 三处过闸。
  const gateUses = code.split('.isCurrent(').length - 1
  assert.ok(gateUses >= 15, '列表写入闸没接在加载器上（期望 ≥ 15 处，实际 ' + String(gateUses) + '）')
})

/* ------------------------------------------------------------------ *
 * 总览：/attention 的 total / truncated / degraded（D101）
 * ------------------------------------------------------------------ */

await test('总览：需关注计数用服务端 total，而不是被 limit 截断后的条数（D101）', () => {
  const { data } = overviewApi()
  const items = [{ name: 'a', reasons: ['oom'] }]
  const groups = [ovGroup('prod', [], { attention: items, attentionTotal: 320, attentionTruncated: true })]
  const value = data(groups)
  assert.equal(value.cards[0].attention, 320, '计数必须是 total（320），不是 items.length（1）')
  assert.equal(value.cards[0].attentionTruncated, true)
  assert.equal(value.cards[0].attentionApprox, false, '有权威结果时不该标成摘要口径')
  assert.match(value.attentionNotice, /实际共 320 条/)
  assert.match(value.attentionNotice, /只列出前 1 条/)
  // 异常表仍按实际行数渲染（与计数卡的差异由上面的提示解释）
  assert.equal(value.rows.length, 1)
})

await test('总览：无 total 的旧宿主回落 items.length，行为与 D101 之前一致', () => {
  const { data } = overviewApi()
  const items = [{ name: 'a', reasons: ['oom'] }, { name: 'b', reasons: ['dead'] }]
  const value = data([ovGroup('prod', [], { attention: items })])
  assert.equal(value.cards[0].attention, 2)
  assert.equal(value.cards[0].attentionTruncated, false)
  assert.equal(value.attentionNotice, '')
})

await test('总览：degraded 目标出提示（inspect 降级 / 候选超预算）（D101）', () => {
  const { data } = overviewApi()
  const value = data([ovGroup('prod', [], { attention: [{ name: 'a', reasons: ['exit-nonzero'] }], attentionTotal: 1, attentionDegraded: true })])
  assert.equal(value.cards[0].attentionDegraded, true)
  assert.match(value.attentionNotice, /已降级/)
})

/* ------------------------------------------------------------------ *
 * 日志缓冲(D63 根治):环形上限 / 残行分片 / 单调 id——突发灌入的内存护栏。
 * 真实 EventSource 时序进不了 Node 桩,但「缓冲吃多少、渲染信号发多少次」
 * 是纯逻辑,在这里钉死。
 * ------------------------------------------------------------------ */

await test('日志缓冲:burst 灌入上行数/字节双限与单调 id(D63 根治)', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const seam = exports_.__logBuffer
  assert.ok(seam !== undefined && typeof seam.create === 'function', '缺少 __logBuffer 测试缝')
  const { create, MAX_LINES, BYTE_LIMIT, PENDING_MAX, FLUSH_MS } = seam
  // 常量在场:缓冲行数/字节上限与合帧节奏(显示层不再另设截断)
  assert.equal(MAX_LINES, 5000)
  assert.equal(BYTE_LIMIT, 4 * 1024 * 1024)
  assert.equal(PENDING_MAX, 1024 * 1024)
  assert.equal(FLUSH_MS, 150)

  // burst:3 万行一次灌入,行数上限收口;id 严格递增(渲染 key 稳定性的前提)
  const buffer = create({ maxLines: MAX_LINES, maxBytes: BYTE_LIMIT, maxPendingBytes: PENDING_MAX })
  const lines = Array.from({ length: 30_000 }, (_, index) => 'line-' + String(index))
  assert.equal(buffer.pushChunk(lines.join('\n') + '\n').appended, lines.length)
  assert.equal(buffer.count(), MAX_LINES)
  const snap = buffer.snapshot()
  assert.equal(snap[0].text, 'line-' + String(lines.length - MAX_LINES))
  for (let i = 1; i < snap.length; i++) assert.ok(snap[i].id > snap[i - 1].id, '行 id 必须单调递增')
  assert.equal(buffer.takeDropped(), true)
  assert.equal(buffer.takeDropped(), false)

  // 大行:字节上限收口(旧行为只限行数,大行场景能吃掉数百 MB)
  const bigLine = 'x'.repeat(64 * 1024)
  const buffer2 = create({ maxLines: MAX_LINES, maxBytes: 1024 * 1024, maxPendingBytes: PENDING_MAX })
  for (let i = 0; i < 64; i++) buffer2.pushChunk(bigLine + '\n')
  const live = buffer2.snapshot().reduce((sum, entry) => sum + entry.bytes, 0)
  assert.ok(live <= 1024 * 1024, '存活字节必须 ≤ maxBytes,实际 ' + String(live))
})

await test('日志流重连:首连带 tail、重连一律 tail=0（D133 不重放历史）', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const seam = exports_.__logStream
  assert.ok(seam !== undefined && typeof seam.subscribe === 'function', '缺少 __logStream 测试缝')
  assert.equal(seam.RECONNECT_BASE_MS, 1000)
  assert.equal(seam.RECONNECT_MAX_MS, 15000)
  // 规则本身：首连保持调用方给的 tail,重连恒为 0
  assert.equal(seam.reconnectTail(200, false), 200)
  assert.equal(seam.reconnectTail(200, true), 0)
  assert.equal(seam.reconnectTail(5000, true), 0)

  // 用可注入的假 EventSource 真跑一遍订阅：首连 URL 带 200,断线重连后带 0
  const urls = []
  const instances = []
  class FakeEventSource {
    constructor(url) {
      this.url = url
      this.readyState = 0
      this.listeners = new Map()
      urls.push(url)
      instances.push(this)
    }
    addEventListener(name, fn) {
      const list = this.listeners.get(name) ?? []
      list.push(fn)
      this.listeners.set(name, list)
    }
    /** data 省略 = 连接层错误那种「没有 data 的普通 Event」。 */
    emit(name, data) {
      for (const fn of this.listeners.get(name) ?? []) fn(data === undefined ? {} : { data: JSON.stringify(data) })
    }
    open() {
      this.readyState = 1
      if (this.onopen) this.onopen()
    }
    close() {
      this.readyState = 2
    }
  }
  const previous = globalThis.EventSource
  const previousSetTimeout = globalThis.setTimeout
  globalThis.EventSource = FakeEventSource
  // 退避定时器直接同步执行,免得用例等着真实 1s
  globalThis.setTimeout = (fn) => {
    fn()
    return 0
  }
  try {
    const lines = []
    const handle = seam.subscribe({
      buildUrl: (tail) => '/api/dsh-docker/logs/stream?tail=' + String(tail),
      tail: 200,
      onLine: (text) => lines.push(text),
    })
    assert.deepEqual(urls, ['/api/dsh-docker/logs/stream?tail=200'])
    instances[0].open()
    instances[0].emit('line', { d: 'first\n' })
    // 连接层错误（无 data 的 Event）：触发手动重连,URL 必须换成 tail=0
    instances[0].emit('error')
    assert.deepEqual(urls, [
      '/api/dsh-docker/logs/stream?tail=200',
      '/api/dsh-docker/logs/stream?tail=0',
    ])
    instances[1].open()
    instances[1].emit('line', { d: 'second\n' })
    assert.deepEqual(lines, ['first\n', 'second\n'])
    handle.close()
  } finally {
    globalThis.EventSource = previous
    globalThis.setTimeout = previousSetTimeout
  }
})

await test('日志流重连:服务端 end{output-limit} 交给调用方决定重连,不静默当成正常结束', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const seam = exports_.__logStream
  const urls = []
  const instances = []
  class FakeEventSource {
    constructor(url) {
      this.url = url
      this.readyState = 0
      this.listeners = new Map()
      urls.push(url)
      instances.push(this)
    }
    addEventListener(name, fn) {
      const list = this.listeners.get(name) ?? []
      list.push(fn)
      this.listeners.set(name, list)
    }
    /** data 省略 = 连接层错误那种「没有 data 的普通 Event」。 */
    emit(name, data) {
      for (const fn of this.listeners.get(name) ?? []) fn(data === undefined ? {} : { data: JSON.stringify(data) })
    }
    open() {
      this.readyState = 1
      if (this.onopen) this.onopen()
    }
    close() {
      this.readyState = 2
    }
  }
  const previous = globalThis.EventSource
  const previousSetTimeout = globalThis.setTimeout
  globalThis.EventSource = FakeEventSource
  globalThis.setTimeout = (fn) => {
    fn()
    return 0
  }
  try {
    const seen = []
    seam.subscribe({
      buildUrl: (tail) => '/logs/stream?tail=' + String(tail),
      tail: 50,
      onEnd: (payload, controls) => {
        seen.push(payload)
        if (payload && payload.reason === 'output-limit') controls.reconnect()
      },
    })
    instances[0].open()
    instances[0].emit('end', { reason: 'output-limit' })
    assert.equal(seen.length, 1)
    assert.equal(seen[0].reason, 'output-limit')
    // 溢出后重连:同样不许带历史(否则重复回填)
    assert.deepEqual(urls, ['/logs/stream?tail=50', '/logs/stream?tail=0'])
  } finally {
    globalThis.EventSource = previous
    globalThis.setTimeout = previousSetTimeout
  }
})

await test('窗口化挂载(D152):只挂可见的几十行,垫高与总高自洽,贴底锚在尾部', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const seam = exports_.__logWindow
  assert.ok(seam !== undefined && typeof seam.create === 'function', '缺少 __logWindow 测试缝')
  const { create, ESTIMATE, OVERSCAN, LIMIT } = seam
  // 常量在场：估算高度、overscan（≥ 右键「问 Agent」要的前后 20 行上下文）、缓存上限
  assert.equal(ESTIMATE, 20)
  assert.ok(OVERSCAN >= 20, 'overscan 必须 ≥ ASK_CONTEXT_LINES(20)')
  assert.ok(LIMIT >= 5000)

  const win = create()
  const rows = Array.from({ length: 5000 }, (_, i) => ({ id: i + 1 }))
  // 非贴底（快照视图）：顶部只挂「视口 + 下 overscan」，不挂 5000 行
  const top = win.layout(rows, { scrollTop: 0, viewportHeight: 600 })
  assert.equal(top.start, 0)
  const mounted = top.end - top.start + 1
  assert.ok(mounted < 100 && mounted > 20, '挂载行数应是可见 + overscan 的几十行，实测 ' + String(mounted))
  // 垫高与总高自洽（虚拟滚动的全部前提）
  assert.equal(top.topPad + mounted * ESTIMATE + top.bottomPad, top.total)
  assert.equal(top.total, 5000 * ESTIMATE)

  // 贴底（FOLLOW）：窗口锚到尾部、下垫为 0 —— 贴底判定与 scrollTop=scrollHeight 靠它精确
  const tail = win.layout(rows, { scrollTop: 999999, viewportHeight: 600, pinned: true })
  assert.equal(tail.end, 4999)
  assert.equal(tail.bottomPad, 0)
  assert.ok(tail.end - tail.start + 1 < 100, '贴底也只挂几十行')

  // 实测高度生效 + 锚点修正：锚点上方行变高 → scrollTop 要补等量像素
  assert.ok(win.measure(1, 60), '第一条实测 60px 应算变化')
  const after = win.layout(rows, { scrollTop: 0, viewportHeight: 600 })
  assert.equal(after.total, 60 + 4999 * ESTIMATE)
  const offsetOf = (id) => {
    let acc = 0
    for (const row of rows) {
      if (row.id === id) return acc
      acc += win.heightOf(row.id)
    }
    return 0
  }
  const before = offsetOf(100)
  assert.ok(win.measure(3, 60), '锚点上方的另一行变高')
  assert.equal(win.reanchor(rows, 100, before), 40, '锚点上方 +40 必须补偿 40')
  assert.equal(win.reanchor(rows, 1, 0), 0, '锚点自身变高不补偿')

  /*
   * offsetOf（D154）：跨代锚点每帧要记「这一行现在在哪」，它和 reanchor 一起构成
   * 「相对上一帧记录的锚补偿」这套机制；两段缺口（淘汰位移 / 量高位移）都靠它吸收。
   */
  assert.equal(win.offsetOf(rows, 1), 0, '第一行偏移为 0')
  assert.equal(win.offsetOf(rows, 3), 60 + ESTIMATE, '第 3 行偏移 = 前两行实测/估算之和')
  assert.equal(win.offsetOf(rows, 9999), null, '不在表里的行返回 null（不猜）')
  assert.equal(win.offsetOf(rows, null), null, '空 id 返回 null')
  // 淘汰头部后：相对旧记录的补偿 = 被淘汰行的总高（洪泛中读历史的位移来源）
  const evicted = rows.slice(2)
  assert.equal(win.reanchor(evicted, 3, 60 + ESTIMATE), -(60 + ESTIMATE), '淘汰掉的前两行总高必须补偿回来')
})

await test('日志窗口换代(D155):两个视图都传 resetKey,hook 里按它整代作废(源码级)', () => {
  /*
   * 这条看**源码**而不是 bundle：bundle 里局部变量名被压缩，grep 不到 `resetKey` 的
   * 形参名；而「换代必须作废高度缓存与锚点」是结构契约——漏了它，快照刷新（行 id 是
   * 位置寻址 `'s'+index`）会把上一代的高度套到这一代第 N 行的陌生内容上，跨代锚点
   * 更会把补偿量算飞（D154 在快照模式下的安全前提）。
   */
  const source = readFileSync(new URL('../client-src/index.js', import.meta.url), 'utf8')
  assert.ok(source.includes('const resetKey = options === undefined ? undefined : options.resetKey'), 'useLogRows 要接 resetKey 选项')
  assert.ok(source.includes('if (resetKey !== resetKeyRef.current) {'), 'resetKey 变了要进换代分支')
  assert.ok(source.includes('resetKeyRef.current = resetKey\n          cache.clear()'), '换代必须清高度缓存')
  assert.ok(source.includes('anchorRef.current = null\n        }\n        if (list.length === 0 && hadRowsRef.current) {'), '换代必须同时作废锚点')
  // 两个日志视图（单容器 / 聚合）都要传：漏一个就等于那个视图不换代
  assert.ok(source.includes('resetKey: follow ? followBufRef.current : logs,'), '单容器视图：跟随传缓冲身份、快照传 logs 响应身份')
  assert.ok(source.includes('resetKey: aggBufRef.current,'), '聚合视图：传缓冲身份')
  // 兜底信号仍在（调用方漏传时靠「有行 → 空」自愈）
  assert.ok(source.includes('if (list.length === 0 && hadRowsRef.current) {'), '「有行 → 空」兜底换代信号不许丢')
  // bundle 里也要能看见这条契约（证明它确实被打进了产物）
  assert.ok(code.includes('resetKey'), '产物里缺少 resetKey 契约')
})

await test('日志缓冲:无换行的超长输出被残行分片钉在有界内存内', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const { create, PENDING_MAX } = exports_.__logBuffer
  const buffer = create({ maxLines: 100, maxBytes: 1024 * 1024, maxPendingBytes: PENDING_MAX })
  // 模拟「永远不换行的输出」:32MB 连续灌入,残行每次到 1MB 强制落行
  for (let i = 0; i < 32; i++) buffer.pushChunk('y'.repeat(PENDING_MAX))
  const live = buffer.snapshot().reduce((sum, entry) => sum + entry.bytes, 0)
  assert.ok(live <= 1024 * 1024 + PENDING_MAX, '存活字节必须有界,实际 ' + String(live))
  assert.ok(buffer.pendingLength() <= PENDING_MAX)
  assert.ok(buffer.takeDropped(), '持续超限必须置 dropped')
})

await test('日志缓冲:快照切分不把结尾换行算成一行(D136 —— --tail 201 必须显示 201 行)', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const { splitLines, create } = exports_.__logBuffer
  assert.equal(typeof splitLines, 'function', '缺少 __logBuffer.splitLines 测试缝')
  // 现场:docker logs --tail 201 → 201 行、每行以 \n 结尾。旧的 text.split('\n') 会切出 202 段。
  const text = Array.from({ length: 201 }, (_, i) => 'line ' + String(i)).join('\n') + '\n'
  assert.equal(splitLines(text).length, 201, '计数必须等于 --tail 的行数')
  assert.equal(splitLines(text).at(-1), 'line 200', '末尾不该多出一条空行')
  // 与 FOLLOW 缓冲的结论一致:同一份文本,两个视图的行数不许不同
  const buffer = create({ maxLines: 5000, maxBytes: 4 * 1024 * 1024 })
  buffer.pushChunk(text)
  assert.equal(buffer.snapshot().length, splitLines(text).length, '快照视图与 FOLLOW 视图必须同行数')
  // 真正以空行结尾的日志要留住那个空行(只剥终止符)
  assert.deepEqual(splitLines('a\n\n'), ['a', ''])
  assert.deepEqual(splitLines(''), [])
})

/* ------------------------------------------------------------------ *
 * 一键连接本机：按钮出现的位置与 HTTP 接线
 * ------------------------------------------------------------------ */

/**
 * 往模块级 config 缓存里塞一份 config（按钮的三态判定读的就是它，而它平时只由
 * `/config` 响应推进去）。走 bundle 自己导出的 publishConfig，与生产路径同一份语义。
 */
function publishConfigForTest(config) {
  registration.factory((spec) => SEED[spec]).__config.publishConfig(config)
}

/*
 * 「复用已有本机目标，不看名字」这条判定的**归属**是宿主：它是写路径的一部分，由
 * /connect-local 的 connectLocal() / findLocalTargetName 决定，用例在 connect-local.test.ts。
 * 客户端曾经也有一份 localTargetName（按钮三态用），按钮搬进空态后那份就没了——这里不再重复钉。
 */
await test('连接本机：客户端不再自己判「复用还是新建」（那是宿主的写路径）', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  assert.equal(exports_.__panel.localTargetName, undefined, '客户端不该保留写路径的判定副本')
  assert.equal(typeof exports_.__api.connectLocal, 'function', '真正该有的客户端能力是这条 HTTP 接线')
})

await test('连接本机：api.connectLocal 走 POST /api/dsh-docker/connect-local（不带参数）', async () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const api = exports_.__api
  assert.ok(api !== undefined && typeof api.connectLocal === 'function', '缺少 __api.connectLocal 测试缝')
  /*
   * bundle 闭包里的 `fetch` 是 factory 注入的那个参数（见冒烟脚本开头的 fetchStub），
   * 不是 globalThis.fetch —— 所以「真的打到了哪个 URL」要看桩的兜底错误：
   * 兜底分支把路径原样写进 error，命中它就等于证明这次调用打的就是这个路径。
   * （成功路径的响应体由 fetchStub 决定，这里只钉接线，不重复测宿主的行为。）
   */
  await assert.rejects(() => api.connectLocal(), /unexpected \/api\/dsh-docker\/connect-local/)
})

await test('连接本机：已配目标时**不得**出现在工具条（用户报的「多余」就是这条）', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const Panel = exports_.__render.ContainerPanel
  assert.equal(typeof Panel, 'function')

  /*
   * 这条用例是**反向**钉住一个设计决定，所以断言方向很重要：第一版把按钮挂在工具条上
   * （目标选择器右边）常驻，已有目标时它是纯噪音——用户当场指着截图说「有点多余」。
   * 所以判据不是「按钮在不在」，而是「有目标时它**不在**」。
   * 只看 dk_pillLocal 这个类：空态那个按钮用的是 dk_btn dk_btnPrimary，不会误命中。
   */
  const toolbarButton = (tree) => treeFind(tree, (el) => {
    const cls = String(el.props?.className ?? '')
    return cls.includes('dk_pillLocal')
  })

  // ① 全是 SSH 目标（选择器里有可用目标）：工具条不该有这个按钮
  publishConfigForTest({ ...FAKE_CONFIG, targets: [{ name: 'prod', kind: 'ssh', book: 'prod-a' }] })
  const sshOnly = Panel({ carrier: 'modal', onClose: () => {}, initialTarget: 'prod' })
  assert.equal(toolbarButton(sshOnly).length, 0, '有可用目标时工具条里不该有「连接本机」')

  // ② 已经有本机目标、且当前看的就是它：同样不该出现
  publishConfigForTest({
    ...FAKE_CONFIG,
    targets: [{ name: 'prod', kind: 'ssh', book: 'prod-a' }, { name: 'local', kind: 'local' }],
  })
  const withLocal = Panel({ carrier: 'modal', onClose: () => {}, initialTarget: 'local' })
  assert.equal(toolbarButton(withLocal).length, 0, '当前目标就是本机时更不该有它')

  publishConfigForTest(FAKE_CONFIG)
})

await test('连接本机：只在「一个目标都没有」的空态里出现，且是可点的主按钮', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const Panel = exports_.__render.ContainerPanel

  /*
   * 这正是它该在的唯一场景：面板全空、原先只让你去设置卡片手配。
   * 空态里 `target === ''` ⇒ 不可能已有本机目标可复用 ⇒ 这一下必然是「新建并选中」，
   * 所以这里只断言「有一个可点的主按钮，文案是『连接本机』」——没有三态。
   */
  publishConfigForTest({ ...FAKE_CONFIG, targets: [] })
  const empty = Panel({ carrier: 'modal', onClose: () => {}, initialTarget: '' })
  const buttons = treeFind(empty, (el) => el.props?.className === 'dk_btn dk_btnPrimary')
  assert.equal(buttons.length, 1, '无目标空态里应恰有一个一键入口')
  assert.equal(buttons[0].props.type, 'button')
  assert.equal(buttons[0].props.disabled, false)
  assert.equal(typeof buttons[0].props.onClick, 'function')
  assert.ok(treeText(empty).includes('还没有配置 Docker 目标'), '空态文案应保留（一键入口是它的补充，不是替代）')
  assert.ok(treeText(empty).includes('连接本机'))
  // 恢复模块级 configCache，避免影响后续用例
  publishConfigForTest(FAKE_CONFIG)
})

await test('连接本机：目标下拉里的「＋ 连接本机」判定（有 SSH、无本机时才列）', () => {
  const exports_ = registration.factory((spec) => SEED[spec])
  const panel = exports_.__panel
  const SENTINEL = panel.CONNECT_LOCAL_OPTION
  const offer = panel.shouldOfferConnectLocal
  assert.equal(typeof SENTINEL, 'string', '哨兵值应作为测试缝暴露')
  assert.equal(typeof offer, 'function', '判定应作为纯函数暴露')

  /*
   * 这条对应的正是用户报的场景：手上有几台 SSH、想加本机。第一版把按钮从工具条撤掉后，
   * 这条路只剩「开设置卡片」，用户直接问「我怎么看到本机的容器」。入口要放在**用户找机器
   * 的地方**（目标下拉末尾），而不是常驻工具条。
   *
   * 为什么驱动纯函数而不是遍历渲染树：离线冒烟的 React 桩把 useState 冻在初值上
   * （组件里 `targets` 初值是 []），树里永远走不到那一项——所以判定抽成了纯函数。
   */
  assert.equal(offer([{ name: 'prod', kind: 'ssh' }]), true,
    '有目标但没有本机目标时，应列出「＋ 连接本机」')
  assert.equal(offer([
    { name: 'prod', kind: 'ssh' },
    { name: '本机-自定义', kind: 'local' },
  ]), false, '已经有本机目标时不该再列（选择器里已经有它了）')
  assert.equal(offer([]), false,
    '一个目标都没有时入口在正文空态里，下拉里不该重复列一项')

  /*
   * 哨兵值必须撞不上真实目标名：目标名是用户自由填的（sanitizeTargets 只限非空与长度）。
   * 若用普通字符串（如 `local`），用户恰好有同名目标时点「连接本机」就会切到那台机器。
   * NUL 开头的值在输入框里打不出来，所以它不可能与任何真实目标重名。
   */
  assert.equal(SENTINEL.charCodeAt(0), 0, '哨兵应以 NUL 开头（输入框里打不出来）')
  assert.ok(SENTINEL.length > 1, '哨兵不能就是那个 NUL 本身')
})

await test('连接本机：下拉项接的是 connectLocal（哨兵被拦在换目标逻辑之前）', () => {
  const source = readFileSync(new URL('../client-src/index.js', import.meta.url), 'utf8')
  /*
   * 接线判据（源码级）：哨兵一旦漏进 setTarget 就会把当前目标换成一个不存在的名字，
   * 面板随即报「未知目标」。所以 `if (... === CONNECT_LOCAL_OPTION)` 分支必须在
   * `setTarget(event.target.value)` **之前**，且分支里调的是 connectLocal。
   */
  const guard = source.indexOf('if (event.target.value === CONNECT_LOCAL_OPTION)')
  const setTarget = source.indexOf('setTarget(event.target.value)')
  assert.ok(guard !== -1, 'onChange 里应有哨兵分支')
  assert.ok(setTarget !== -1, 'onChange 里应有 setTarget')
  assert.ok(guard < setTarget, '哨兵分支必须排在 setTarget 之前（否则会切到不存在的目标）')
  const branch = source.slice(guard, setTarget)
  assert.ok(/connectLocal\(\)/.test(branch), '哨兵分支里应调用 connectLocal()')
  assert.ok(/return/.test(branch), '哨兵分支必须 return，不能继续走换目标')
})

/* ------------------------------------------------------------------ *
 * 就地提权：多能力 pending → 一条命令解锁全部（一次粘贴）
 * ------------------------------------------------------------------ */

/**
 * 为什么这一组用例必须存在：改前 `elevation` 是**单槽** state（`setElevation({capability})`），
 * 面板开着时再点另一个开关会把前一个能力的面板**替换**掉、它的命令从界面消失（宿主侧 challenge
 * 仍在 pending）。2026-09-26 的设置卡片截图实测：两次授权时刻差 14 秒——用户必须在宿主终端
 * **粘贴两次**。逐能力记录 + 合并复制修掉的就是这件事：两个开关各点一次，界面上同时有两块面板
 * 与一个「复制全部」，终端**粘贴一次**两行。
 *
 * 断言打在**渲染树**与**按钮交下去的字节**上（不只是纯函数）：纯函数对而接线错（按钮接错回调、
 * 只复制了第一条、顺序反了）在真机上才暴露，正是离线冒烟要拦的那一类。
 */
function elevationApi() {
  const exports_ = registration.factory((spec) => SEED[spec])
  assert.ok(exports_.__elevation !== undefined, '缺少 __elevation 测试缝')
  return exports_.__elevation
}

/** 面板组的渲染：回调用桩记录，配置值默认都关着（与「开关还没打开」的真实初态一致）。 */
function renderElevationPanels(records, overrides = {}) {
  const api = elevationApi()
  const copied = []
  const closed = []
  const regenerated = []
  const tree = api.view(records, {
    now: overrides.now ?? 1_700_000_000_000,
    copiedKey: overrides.copiedKey ?? '',
    configured: overrides.configured ?? (() => false),
    onCopy: (capability, command) => copied.push({ capability, command }),
    onCopyAll: (text) => copied.push({ capability: api.COPY_ALL_KEY, command: text }),
    onRegenerate: (capability) => regenerated.push(capability),
    onClose: (capability) => closed.push(capability),
    onDisableFirst: () => {},
  })
  return { api, tree, copied, closed, regenerated }
}

/** 合并按钮：从渲染树里找（而不是读入参），保证「界面上真的有」这件事被测到。 */
function mergeButtonOf(tree) {
  return treeFind(tree, (node) => node.type === 'button' && node.props?.key === 'copyAll')[0]
}

await test('就地提权：两个 pending → 合并按钮复制的内容 = 两条命令按发起顺序的换行连接（逐字节）', () => {
  const api = elevationApi()
  const expiresAt = 1_700_000_000_000 + 300_000
  // 发起顺序：先点 allowMutations，再点 allowExec（数组顺序就是点击顺序）
  const records = [
    { capability: 'allowMutations', command: "touch '/home/u/.dsh/dsh-kit/grant-confirm/aaa'", expiresAt },
    { capability: 'allowExec', command: "touch '/home/u/.dsh/dsh-kit/grant-confirm/bbb'", expiresAt },
  ]
  const { tree, copied } = renderElevationPanels(records)
  const button = mergeButtonOf(tree)
  assert.ok(button !== undefined, '两个 pending 时必须出「复制全部」按钮')

  /*
   * 驱动按钮的 onClick（真跑一次「点了会怎样」）：断言的是**交给复制动作的那个字符串**
   * （桩里没有 navigator，剪贴板本身是浏览器的事）——内容错（少一条 / 顺序反 / 用 && 连接）
   * 才是本用例要拦的。
   */
  button.props.onClick()
  assert.equal(copied.length, 1, '点一次合并按钮应恰好触发一次复制')
  const text = copied[0].command
  const expected = records[0].command + '\n' + records[1].command
  assert.equal(text, expected, '合并内容必须逐字节等于两条命令的换行连接')
  assert.equal(
    Buffer.from(text, 'utf8').toString('base64'),
    Buffer.from(expected, 'utf8').toString('base64'),
    '按字节比对（换行符形态也是契约）',
  )
  assert.equal(text.split('\n').length, 2, '两条命令 = 两行')
  assert.ok(!text.includes('&&'), '不得用 && 连接（PS 5.1 不认）')
  assert.ok(!text.includes('; '), '不得用 ; 连接（cmd 不认）')
  assert.ok(text.indexOf(records[0].command) < text.indexOf(records[1].command), '顺序必须是发起顺序（先点的在前）')
  assert.equal(copied[0].capability, api.COPY_ALL_KEY, '合并复制的反馈键必须与单条按钮隔离')

  // 每块面板自己的单条复制按钮仍在（用户仍可只复制一条），且只复制自己那条
  const singleButtons = treeFind(tree, (node) => node.type === 'button' && node.props?.key === 'copy')
  assert.equal(singleButtons.length, 2, '两块面板各自保留单条复制按钮')
  singleButtons[0].props.onClick()
  assert.equal(copied[1].command, records[0].command, '单条复制只复制自己那条命令')
  assert.equal(copied[1].capability, 'allowMutations', '单条复制的反馈键是能力名（与合并按钮互不串）')
})

await test('就地提权：单个 pending → 无合并按钮（那条命令就在自己的面板里）', () => {
  const expiresAt = 1_700_000_000_000 + 300_000
  const single = [{ capability: 'allowMutations', command: "touch '/tmp/a'", expiresAt }]
  const { tree, api } = renderElevationPanels(single)
  assert.equal(mergeButtonOf(tree), undefined, '只点过一个开关时不该出现「复制全部（1 条）」')
  // 反面判据：纯判定同样为假（防止某天有人把「≥2」放宽成「≥1」而用例只看渲染树）
  assert.equal(api.shouldOfferMerge(single, 1_700_000_000_000), false)
  // 界面结构不变形：一块面板 + 一个单条复制按钮
  assert.equal(treeFind(tree, (node) => node.props?.className === 'dk_elevPanel').length, 1)
  assert.equal(treeFind(tree, (node) => node.type === 'button' && node.props?.key === 'copy').length, 1)
})

await test('就地提权：一个 granted 后 → 合并按钮只剩剩下那一条（组里还有别的能力没解锁）', () => {
  const api = elevationApi()
  const expiresAt = 1_700_000_000_000 + 300_000
  const two = [
    { capability: 'allowMutations', command: "touch '/tmp/a'", expiresAt },
    { capability: 'allowExec', command: "touch '/tmp/b'", expiresAt },
  ]
  // allowMutations 先解锁：记录留痕（面板消失），命令清掉
  const afterGrant = api.markGranted(two, 'allowMutations')
  assert.equal(api.shouldOfferMerge(afterGrant, 1_700_000_000_000), true, '还有一条没解锁时按钮要留着')
  assert.deepEqual(api.merge(afterGrant, 1_700_000_000_000), ["touch '/tmp/b'"], '只剩仍 pending 的那一条')
  assert.equal(api.text(afterGrant, 1_700_000_000_000), "touch '/tmp/b'", '合并内容退化成那一行（没有多余换行）')

  const { tree, copied } = renderElevationPanels(afterGrant)
  const button = mergeButtonOf(tree)
  assert.ok(button !== undefined, '一个 granted 后合并按钮仍在')
  button.props.onClick()
  assert.equal(copied[0].command, "touch '/tmp/b'", '按钮此刻只复制仍 pending 的那条')
  // 已授权的那块面板消失，仍 pending 的那块还在
  assert.equal(treeFind(tree, (node) => node.props?.className === 'dk_elevPanel').length, 1, '已授权的面板必须消失')

  // 两条都解锁 → 组里没有可复制命令：留痕被收掉，按钮自然消失
  const allGranted = api.markGranted(afterGrant, 'allowExec')
  assert.deepEqual(allGranted, [], '全部解锁后整组清空（含留痕）')
  assert.equal(
    api.view(allGranted, { copiedKey: '', configured: () => false, onCopy() {}, onCopyAll() {}, onRegenerate() {}, onClose() {}, onDisableFirst() {} }),
    null,
    '全部结束后面板组不渲染',
  )
})

await test('就地提权：过期的那条不进合并（复制过去只会让宿主落一个过期后才出现的文件）', () => {
  const api = elevationApi()
  const now = 1_700_000_000_000
  const records = [
    { capability: 'allowMutations', command: "touch '/tmp/a'", expiresAt: now - 1 },
    { capability: 'allowExec', command: "touch '/tmp/b'", expiresAt: now + 300_000 },
  ]
  assert.deepEqual(api.merge(records, now), ["touch '/tmp/b'"], '过期的从合并里剔掉')
  const { tree, copied } = renderElevationPanels(records, { now })
  const button = mergeButtonOf(tree)
  assert.ok(button !== undefined, '组里仍有两条记录时按钮在（只是内容少了一条）')
  button.props.onClick()
  assert.equal(copied[0].command, "touch '/tmp/b'", '合并按钮只复制仍 pending 的那些')
  // 两条都过期 → 没有可复制的：按钮收起（不再承诺一个不可能发生的解锁）
  const bothExpired = records.map((record) => ({ ...record, expiresAt: now - 1 }))
  assert.equal(api.shouldOfferMerge(bothExpired, now), false)
})

await test('就地提权：✕ 只关一个能力的面板，另一个照常解锁（不撤销宿主 challenge）', () => {
  const api = elevationApi()
  const expiresAt = 1_700_000_000_000 + 300_000
  const records = [
    { capability: 'allowMutations', command: "touch '/tmp/a'", expiresAt },
    { capability: 'allowExec', command: "touch '/tmp/b'", expiresAt },
  ]
  const { tree, closed } = renderElevationPanels(records)
  const closeButtons = treeFind(tree, (node) => node.type === 'button' && node.props?.key === 'close')
  assert.equal(closeButtons.length, 2, '每块面板各有自己的收起按钮')
  closeButtons[0].props.onClick()
  assert.deepEqual(closed, ['allowMutations'], '✕ 只收起被点的那一个能力')
  // 关掉 A 之后 B 照常解锁：记录集里仍留着 B，合并内容只剩 B 那条
  const afterClose = api.remove(records, 'allowMutations')
  assert.deepEqual(api.merge(afterClose, 1_700_000_000_000), ["touch '/tmp/b'"])
  assert.equal(api.shouldOfferMerge(afterClose, 1_700_000_000_000), false, '只剩一个 pending 时合并按钮收起')
})

await test('就地提权：两条命令各自独立——一条出错 / 在途不影响另一条的合并', () => {
  const api = elevationApi()
  const expiresAt = 1_700_000_000_000 + 300_000
  const records = [
    { capability: 'allowMutations', error: 'HTTP 429' },
    { capability: 'allowExec', command: "touch '/tmp/b'", expiresAt },
  ]
  assert.deepEqual(api.merge(records, 1_700_000_000_000), ["touch '/tmp/b'"], '出错那条没有命令，不进合并')
  assert.equal(api.shouldOfferMerge(records, 1_700_000_000_000), false, '只有一条可复制时不出按钮')
  // 在途（begin 还没回）同样不参与合并
  assert.deepEqual(api.merge([{ capability: 'allowExec' }], 1_700_000_000_000), [])
})

await test('就地提权：i18n 双份齐（新增键 zh/en 都在，且都进了产物）', () => {
  const source = readFileSync(new URL('../client-src/index.js', import.meta.url), 'utf8')
  for (const key of ['elev.copyAll', 'elev.copyAllHint', 'elev.copyAllCopied']) {
    const hits = source.split(`'${key}':`).length - 1
    assert.equal(hits, 2, `${key} 必须在 zh / en 两份目录里各出现一次（现在是 ${String(hits)} 次）`)
  }
  const decoded = decodeBundle(code)
  assert.ok(decoded.includes('复制全部'), 'bundle 里应有合并按钮的中文兜底文案')
  assert.ok(code.includes('dk_elevPanels'), 'bundle 里应有面板组的样式钩子')
  assert.ok(code.includes('dk_elevMerge'), 'bundle 里应有合并复制行的样式钩子')
})

/* ------------------------------------------------------------------ *
 * 结果
 * ------------------------------------------------------------------ */

let failed = 0
for (const result of results) {
  if (result.ok) {
    console.log(`  ✓ ${result.name}`)
  } else {
    failed += 1
    console.error(`  ✗ ${result.name}\n      ${result.message}`)
  }
}
console.log(`\n[dsh-docker] client-smoke: ${String(results.length - failed)}/${String(results.length)} 通过`)
clearTimeout(watchdog)
// 成功路径也要显式退出（D121）：主体结束后仍有周期句柄漏着的话，
// 关掉看门狗就再也没人兜底了 —— 直接 exit 既保证退出也省掉排空等待
process.exit(failed > 0 ? 1 : 0)
