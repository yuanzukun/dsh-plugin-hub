# @hyzyn/dsh-search

[中文](README.md) | English

> The DSH sidebar “Global Search” entry (**⌘ / Ctrl + K** also opens it): a command-palette-style search that finds past sessions, Prompts, MCP tools, and settings in one place.

## Features

- **Local cache renders first**: no request, zero latency — the cache paints results first, then remote results fill in.
- **Four target classes in one palette**: past sessions, Prompts, MCP tools and settings panels, shown in groups.
- **Keyboard first**: open it with ⌘/Ctrl+K; a row = icon + title (with an optional subtitle) + metadata on the right + a shortcut chip.
- **Results jump directly**: hit a result and go, without first working out "which settings page does this live on".

![Global Search plugin](https://cdn.jsdelivr.net/gh/hyzyn/dsh-plugin-kit@main/docs/dsh-plugin-kit-search.png)
![Global Search results (recent sessions / past sessions / Prompts / MCP tools / settings groups)](https://cdn.jsdelivr.net/gh/hyzyn/dsh-plugin-kit@main/docs/dsh-plugin-kit-search-query.png)

## Panel behavior

**Content on open** (no request, zero latency):

- **Recent**: the recent sessions in the browser-side `ctx.sessions.list` snapshot (empty sessions and subagent sessions are filtered out), with a relative time on the right; up to 8 rows (`RECENT_SESSION_LIMIT`), the same limit for the empty query and for searching, with `⌥/Alt + digit` shortcuts on the first 8;
- **Quick actions**: new session / open folder / open settings — the row does not appear when the target is missing (for example, when the directory picker plugin is not installed);
- **Settings**: the top-level settings categories are taken **live** from the `settings.section` slot of the client slots registry — categories registered by third-party plugins such as Skins / Pets / Sidebar cards / Web plugins / Creative workshop / Usage stats / Session archive management also appear, in the same order as the settings window navigation; the in-row keywords and descriptions are filled in by the host's `/api/dsh-search/catalog` directory. When the host does not have that route (the host itself is an older build), or the slots service is unavailable, it falls back to the directory, and then to the client-side fallback list of the four built-in official categories.

**After a keyword is typed**: local candidates (recent session titles, quick actions, the settings directory) are filtered and redrawn instantly, while `/api/dsh-search/query` is requested asynchronously to fill in the host's full-text hits:

- **Past sessions**: uses the `sessionQuery` full-text index that ships with DSH; clicking opens the session and automatically locates the matching text (the session view is a bottom-anchored virtual list, so locating loads earlier messages screen by screen, and the original position is restored when no match is found);
- **Prompts**: reads the managed block of `~/.dsh/prompts.yml`; clicking jumps to the “Prompt Management” settings card (when it cannot jump there, it falls back to copying the snippet);
- **MCP tools**: tools with the `mcp__` prefix, showing the owning server on the right; clicking jumps to the “MCP Server Configuration” card;
- **Settings**: matched locally by title / keyword / description (including plugin cards).

**How a jump finds the settings window** (two host generations; pinned by `packages/search/test/settings-entry.test.ts`):

| Host | The settings entry at the sidebar foot | The route this plugin takes |
| --- | --- | --- |
| ≤0.2.0 | `button[aria-haspopup="dialog"]`, one click opens the window | Click it |
| ≥0.2.1 | The account menu (`aria-haspopup="menu"`, accessible name “账号菜单”), with **the settings window as its first item** | Open the menu → click “Settings” |
| any | The host provides a `shortcuts` service (with `settings.open`) | `invoke` the command directly, independent of DOM shape |

When the settings window is already open, `settings.open` is not invoked again — with `modal === "settings"` that command means “close the topmost modal”, so repeating it would close the window the user just opened. The window itself is identified by `data-shortcut-modal="settings"`, not by “any `role="dialog"` on the page” (approval prompts and attachment previews are dialogs too).

## Keyboard

| Key | Action |
| --- | --- |
| ⌘/Ctrl+K | Open (focuses the input when already open) |
| ↑ / ↓ | Move the highlight through all candidates (the first item is selected by default) |
| ↵ | Open the highlighted item |
| esc | Close |
| ⌥/Alt + 1…8 | Open the Nth "Recent" session (capped at 8, see `RECENT_SESSION_LIMIT`) |
| ⌥/Alt + N / O / , | New session / open folder / open settings |

Moving the mouse brings the highlight to the row under the pointer; the keyboard and the mouse share a single selection state.

## Routes

Loopback requests keep the local loopback + same-origin fence. Every other request (behind a reverse proxy, or a `--trusted-host` name) goes through the host's own auth: `connection.requestRejection` applies the Host/Origin fence and requires a signed-in browser session (401 without one, 403 for an untrusted Host). On hosts without that service or method such requests still get the loopback fence's 403:

- `GET /api/dsh-search/query?q=<keyword>` — returns `{ sessions, prompts, tools, panels }`: search results for past sessions, Prompts, MCP tools, and settings panels
- `GET /api/dsh-search/catalog` — returns `{ panels }`: the currently available settings panel directory (with `titles` / `keywords` / `description`), used by the browser half for "content on open" and instant filtering

**When adding a plugin card, remember to update `PANEL_DIRECTORY`** (`src/index.ts`): that directory is
**hard-coded**, and plugin cards are shown or hidden by the `registryName` gate according to whether
their settings namespace is registered. Miss one line and the result is "the plugin is installed and
its card is in Settings, but global search cannot find it" — `docker` was missed once (caught on a
real machine); `packages/search/test/panel-catalog.test.ts` now pins the presence of the plugin cards.

## Installation

```bash
pnpm --filter @hyzyn/dsh-search build
dsh plugin --profile web add link:$(pwd)/packages/search
```

The plugin's own row is mounted by `insert: { id: global-search, name: '@hyzyn/dsh-search' }` in `cordis.patch.yml`; the browser half adds the Global Search entry below "New Session" in the sidebar.

## Configuration

```ts
interface Config {
  /** Disable the whole plugin (no routes registered, no GUI injected). Defaults to true. */
  enabled?: boolean
  /** Maximum number of results per category. Defaults to 8. */
  maxResults?: number
  /** Whether to search past sessions. Defaults to true. */
  includeSessions?: boolean
  /** Whether to search Prompts. Defaults to true. */
  includePrompts?: boolean
  /** Whether to search MCP tools. Defaults to true. */
  includeMcpTools?: boolean
  /** Whether to search settings panels. Defaults to true. */
  includePanels?: boolean
  /** Whether to inject the plugin capability announcement to the agent. Defaults to true. */
  announceToAgent?: boolean
  /** Maximum number of sessions for the fallback session scan: when the host FTS is unavailable, sessions are truncated to this many, most recent first, cap 500. Defaults to 80. */
  maxScanSessions?: number
}
```

## Visual preview

`scripts/preview.mjs` loads `client.js` into a pure static fixture page (`scripts/preview/harness.html`, which contains a fake host: module loader / fetch / sessions service), then renders scene-by-scene screenshots with headless Chrome — useful for walking through changes when tweaking styles:

```bash
pnpm --filter @hyzyn/dsh-search preview                          # all scenes (dark) → .preview/shots/
pnpm --filter @hyzyn/dsh-search preview -- --theme=light --out=shots-light
pnpm --filter @hyzyn/dsh-search preview -- --list                # list scenes
```

Scenes: `empty` (content on open), `query` (mixed results after a keyword is typed), `loading` (full-text search in progress). After the screenshot, the `empty` scene also runs a set of keyboard-contract self-checks (default selection / ↑↓ / ↵ / ⌥number / esc), and failures are printed with `⚠`. Chrome/Chromium is required on the machine (by default it looks for the playwright-cached Chrome for Testing; `CHROME_PATH` can be used to point at another one).

## Notes

- The browser half depends on the core client `sessions` service (to read recent sessions and to open a session on click), and injects the sidebar entry through the DOM: it lands **in the host's panel navigation, directly below the “Plugins” row**, shaped exactly like its neighbours (a full-width icon + text row, with font size, ink, radius and hover all taken from the host panel row's token set); a click or keyboard activation opens the command palette;
- "Click a session to open it" is **view navigation**: DSH 0.1.6 moved it to `uiWorkspace.openSession(id)` (the session domain's `sessions.open()` left the contract), while older hosts still go through `sessions.open()`. An implementation that only knows the legacy call turns a click into "cannot open a session in this environment" on a new host — indistinguishable from "nothing happened";
- Closing the panel restores focus, but **skips elements inside the sidebar entry** (the entry's `focusin` is the open path, so restoring focus there would mean "closed it only for it to pop straight back"), and blocks the entry's focusin within 250ms as a fallback;
- "New session" calls the GUI's own `uiWorkspace.startSession()` first (reuse the current workspace's empty session → create → select, all in one step); when that service is unavailable it falls back to clicking the sidebar "New Session" button, and only as a last resort does it call `sessions.create()` + `sessions.open()` itself — create without open shows up as "clicked but nothing happened";
- "Open folder" is located by the aria-label of the sidebar "Add workspace" button; when the directory picker plugin is absent the button does not exist, and the row is hidden automatically;
- The settings directory is built into the host half: the panels that are always present officially (General Settings, Models, Plugins, Agent presets, Plugin marketplace, Terminal, Agent loop, Web search) are always searchable; plugin cards are filtered by the plugins currently loaded in the host;
- If the host does not have the `sessionQuery` service installed, session search returns an empty array instead of throwing an error;
- If the `session-query` full-text index is configured with `openAt: "never"`, past-session search automatically degrades to scanning the raw events session by session instead of failing the whole search; the fallback scan is truncated by most-recent-first (`maxScanSessions`), and hits are returned in reverse chronological order;
- Session documents / query results / visible session sets / Prompt parsing all have short TTL caches, so repeated queries are cheap;
- Session results are filtered to the sessions currently visible / jumpable in DSH, avoiding the "searchable but not openable" case.
