/**
 * @hyzyn/dsh-tty — shell 集成注入（OSC 133 命令边界标记 + OSC 7 cwd 上报）。
 *
 * 动机：tty_capture 只能读原始尾部，agent 拿不到「上一条命令」的边界与退出码；
 * tty_list 的 cwd 是 spawn 时的快照，用户 cd 之后失真。借 shell 钩子在输出流里
 * 打标记即可两全，不需要动 DSH 的 spawnTerminal 协议。
 *
 * 注入方式（对用户透明，不要求改 rc）：
 *   - zsh：把桩文件写到**稳定目录**（`<DSH_HOME|~/.dsh>/tty[/<profile>]/shell/zsh/`
 *     下的 .zshenv/.zprofile/.zshrc/.zlogin，各自先 source 用户 ZDOTDIR/HOME 下的
 *     原文件，.zshrc 追加钩子），spawn 时经 `-c` 包装层 `export ZDOTDIR=<桩目录>`
 *     生效 —— VS Code 同款成熟方案；
 *   - bash：写桩 rc（先 source ~/.bashrc 再挂钩子），`exec bash --rcfile <桩>`；
 *     B 标记按版本二选一：bash ≥ 4.4 走 PS0；bash < 4.4（macOS 自带 3.2）无
 *     PS0，用**自卸式 DEBUG trap** 兜底——首次触发即发 B 并卸载（避免复合命令
 *     内部逐条触发），再由 PROMPT_COMMAND 尾段在每轮 prompt 前重新武装；
 *     PROMPT_COMMAND 挂钩兼容字符串与数组（bash 5.1+）两种形态；
 *   - 其他 shell：返回 null，集成静默关闭（tty_capture{last} 会明确报错）。
 *
 * 稳定目录（0.10.0）：桩文件必须在跨进程、跨宿主重启的路径上 —— tmux 持久
 * 会话的内层 pane 由 tmux server（比宿主进程活得久）按 inner.sh 启动，若桩
 * 在每次进程的临时目录里，宿主重启后新开 pane 的钩子会指向已失效路径。内容
 * 静态（不含配置），write-if-changed 原子覆盖。
 *
 * tmux passthrough（0.10.0）：持久标签的 pane 跑在 tmux 里，tmux 会吞掉不认
 * 识的转义序列 —— 钩子检测 $TMUX，把 OSC 133/7 包进 DCS tmux; 信封
 * （`\ePtmux;\e\e]133;…\a\e\\`，payload 内 ESC 需双写），tmux ≥3.3 且
 * allow-passthrough on 时解包后原样转发到外层终端；宿主侧解析器看到的仍是
 * 裸标记，零改动。低版本 tmux（<3.3）会吞掉信封：持久化本身可用，
 * capture{last} / expect 的命令粒度降级（README 已知限制）。
 *
 * 标记语义（iTerm2/kitty/VS Code 同一约定）：
 *   OSC 133;A —— prompt 开始；OSC 133;B —— 命令开始（preexec/PS0）；
 *   OSC 133;D;<exit> —— 命令结束带退出码；OSC 7;file://<host><path> —— cwd 上报。
 */
import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { dshHome } from '@hyzyn/dsh-kit'
import { homedir } from 'node:os'
import { basename, dirname, join } from 'node:path'

/** shell 集成的 spawn 片段：argv（-c 包装层）与额外 env。 */
export interface ShellSpawnPlan {
  argv: string[]
  env: Record<string, string>
}

/** profile 段的安全字符集（同时用于 tmux socket 名与运行时目录名）。 */
const PROFILE_SAFE_RE = /^[A-Za-z0-9_-]{1,24}$/

/**
 * 当前 profile 的**路径 / socket 安全段**；未设 profile（不带 profile 启动）时返回空串。
 *
 * 为什么需要它（tty D60）：插件有两样东西按**机器**这一层落盘——tmux 专用 socket 与
 * 运行时资产目录（tmux.conf / inner.sh / shell 桩）。两者都必须**按 profile 各存一份**：
 * `shellIntegration` 等配置是 per-profile 的，共用一个 `inner.sh` 就是「A 的 pane 用
 * B 的启动器」；共用 socket 则让会话清单跨 profile 串味、`kill-server` 误杀别人。
 *
 * **只在调用时读 `process.env.DSH_PROFILE`**（不在模块加载时快照）：测试里要造两个
 * profile 各断言一次，模块级快照会让第二组永远读到第一组的值。名字含字符集外字符
 * （空格 / 斜杠 / 中文…）或超长时退化为「干净前缀 + 6 位摘要」，保证两个不同的
 * profile **永不**落到同一段。
 */
export function dshProfileSegment(): string {
  const profile = (process.env.DSH_PROFILE ?? '').trim()
  if (profile === '') return ''
  if (PROFILE_SAFE_RE.test(profile)) return profile
  const clean = profile.replace(/[^A-Za-z0-9_-]/g, '-').replace(/^-+|-+$/g, '').slice(0, 16)
  const digest = createHash('sha256').update(profile).digest('hex').slice(0, 6)
  return clean === '' ? digest : `${clean}-${digest}`
}

/**
 * 专用 tmux socket 名，**按 profile 区分**（tty D60 的第二半）。
 *
 * 为什么必须是函数而不是常量：socket 是**机器级资源**，而写死的 `-L dsh-tty` 让同一台
 * 机器上所有 profile 的宿主共用一个 tmux server——两个后果都实测过：
 *   1. `tty_list` 的持久会话清单**跨 profile 出现**（另一个 profile 的 dev server 会话
 *      被当成自己的）；
 *   2. 「改完 tmux 配置要 `kill-server` 才生效」这一步会**一并杀掉另一个 profile 的
 *      持久会话**。
 *
 * 未设 `DSH_PROFILE`（不带 profile 启动的宿主）时退回历史名 `dsh-tty`：单 profile 的
 * 用户行为与从前**完全一致**，升级也不需要迁移（老会话仍能用老 socket 接回）。设了
 * profile 时是 `dsh-tty-<profile 段>`。
 *
 * 住在 shell-integration 而不是 tmux：**shell 桩里也要用它**（pane 内的
 * `tmux capture-pane` 必须连本 profile 的 server，否则 `tty_capture{last}` 永远拿不到
 * 快照），而 tmux.ts 反过来 import 本模块——放这边才不会形成循环依赖。
 */
export function tmuxSocketName(): string {
  const segment = dshProfileSegment()
  return segment === '' ? 'dsh-tty' : `dsh-tty-${segment}`
}

/**
 * 插件运行时资产根目录（稳定路径；DSH_HOME 优先，与 env 插件同语义）。
 *
 * **按 profile 分层**（tty D60）：有 profile 时是 `<DSH_HOME>/tty/<profile>/`，无 profile
 * 时仍是历史的 `<DSH_HOME>/tty/`——单 profile 用户路径一字不变（老会话的资产仍在原处，
 * 升级不需要一次性迁移）。内容静态（不含配置），write-if-changed 原子覆盖。
 */
export function pluginRuntimeDir(): string {
  const segment = dshProfileSegment()
  return segment === '' ? join(dshHome(), 'tty') : join(dshHome(), 'tty', segment)
}

/** 原子 write-if-changed：内容相同跳过；不同则写同目录临时文件后 rename（避免半截文件）。 */
function writeIfChanged(file: string, content: string): void {
  try {
    if (readFileSync(file, 'utf8') === content) return
  } catch {
    /* 不存在：继续写入 */
  }
  mkdirSync(dirname(file), { recursive: true })
  const tmp = `${file}.${process.pid}.tmp`
  writeFileSync(tmp, content)
  renameSync(tmp, file)
}

/**
 * ⚠️ 这里曾经是手写的 `dirname`（只按 `'/'` 找最后一段）。Windows 上传进来的本地
 * 路径是 `C:\…\tty\shell\zsh`，`lastIndexOf('/')` 落到 -1 → 返回 `'/'`，于是桩文件
 * 被往盘根写（`mkdirSync('/')` 成功、`writeFileSync('/.zshenv…')` 失败），异常被
 * `ensureZshStubDir` 的 catch 吞掉 → shell 集成**静默降级**成最简包装层。
 * 真机跑单测时正是这条露出水面：`POSIX 分支回归 > zsh + integration 仍走 ZDOTDIR 桩`
 * 在 Windows 上拿到的是非集成形态。改用 `node:path` 的 dirname（两个分隔符都认）。
 */

/**
 * 桩文件路径的进程内缓存（避免每个标签都重复 stat / 重写一遍文件）。
 *
 * key 里**必须同时带 `DSH_HOME` 与 profile 段**。只按 `'zsh'` / `'bash'` 做 key 时，
 * 「桩目录」缓存会在环境变了之后继续指向旧路径——而这两者都可能在同一进程内变：
 * profile 段决定 tmux socket 名（桩内容随它变，tty D60），`DSH_HOME` 决定落盘根目录
 * （测试把它指到临时目录，插件运行期也可能被改）。命中陈旧缓存的表现是「桩写到了
 * 上一个环境的位置，而 spawn 计划按新位置去找」——集成静默降级，正是本仓最忌讳的那类。
 */
const stubDirs = new Map<string, string>()

/** 桩缓存 key：`<shell>:<DSH_HOME>:<profile 段>`。 */
function stubKey(shell: 'zsh' | 'bash' | 'powershell'): string {
  return `${shell}:${dshHome()}:${dshProfileSegment()}`
}

/**
 * zsh 钩子片段。**socket 名由参数传进来**（tty D60）：这些行会被写进 tmux pane 里跑的
 * 桩文件，而 pane 用的 socket 现在是 per-profile 的——写死 `-L dsh-tty` 时，profile
 * 宿主的 pane 里 `tmux capture-pane` 会去连**另一个 profile** 的 server，`tty_capture{last}`
 * 永远拿不到快照（假升级成「命令没输出」）。
 */
function zshHooks(socket: string): string[] {
  return [
  '',
  '# >>> dsh-tty shell integration >>>',
  'if [ -z "$DSH_TTY_HOOKS_LOADED" ]; then',
  '  export DSH_TTY_HOOKS_LOADED=1',
  '  typeset -g __DSH_TTY_IN_CMD=0',
  '  # tmux 持久标签：标记包 DCS passthrough 信封（payload 内 ESC 双写），',
  '  # tmux ≥3.3 + allow-passthrough 解包后原样转发；低版本 tmux 吞信封 → 降级',
  '  if [ -n "$TMUX" ]; then',
  "    __DSH_TTY_FMT_A='\\ePtmux;\\e\\e]133;A\\a\\e\\\\'",
  "    __DSH_TTY_FMT_B='\\ePtmux;\\e\\e]133;B\\a\\e\\\\'",
  "    __DSH_TTY_FMT_D='\\ePtmux;\\e\\e]133;D;%s\\a\\e\\\\'",
  "    __DSH_TTY_FMT_CWD='\\ePtmux;\\e\\e]7;file://%s%s\\a\\e\\\\'",
  "    __DSH_TTY_FMT_T='\\ePtmux;\\e\\e]133;T;%s\\a\\e\\\\'",
  '  else',
  "    __DSH_TTY_FMT_A='\\e]133;A\\a'",
  "    __DSH_TTY_FMT_B='\\e]133;B\\a'",
  "    __DSH_TTY_FMT_D='\\e]133;D;%s\\a'",
  "    __DSH_TTY_FMT_CWD='\\e]7;file://%s%s\\a'",
  '  fi',
  '  # tmux 里 pane 内容的重画是异步批量的（passthrough 标记即时直写），命令',
  '  # 输出会落在 D 标记之后、逃出宿主的 B..D 捕获窗口。precmd 在发 D 前先',
  '  # capture-pane 快照 pane 内容，经 OSC 133;T（base64）随流直送宿主，',
  '  # 宿主优先用 T 快照作为 tty_capture{last} 的输出',
  '  __dsh_tty_capture() {',
  '    local __dsh_tty_precmd_cap',
  `    __dsh_tty_precmd_cap=$(tmux -L ${socket} capture-pane -p -t "$TMUX_PANE" -S -200 2>/dev/null)`,
  '    if [ -n "$__dsh_tty_precmd_cap" ]; then',
  '      printf "$__DSH_TTY_FMT_T" "$(printf \'%s\' "$__dsh_tty_precmd_cap" | base64 | tr -d \'\\n\')"',
  '    fi',
  '  }',
  '  __dsh_tty_precmd() {',
  '    local ec=$?',
  '    if (( __DSH_TTY_IN_CMD )); then',
  '      [ -n "$TMUX" ] && __dsh_tty_capture',
  '      printf "$__DSH_TTY_FMT_D" "$ec"; __DSH_TTY_IN_CMD=0; fi',
  '    printf "$__DSH_TTY_FMT_A"',
  '    printf "$__DSH_TTY_FMT_CWD" "${HOST}" "${PWD}"',
  '  }',
  '  __dsh_tty_preexec() {',
  '    __DSH_TTY_IN_CMD=1',
  '    printf "$__DSH_TTY_FMT_B"',
  '  }',
  '  # 前置插入：后置追加（+=）会让前序钩子的返回码污染 $?，D 标记记到的',
  '  # 就不是用户命令的退出码（preexec 同理前置，保持对称）',
  '  precmd_functions=(__dsh_tty_precmd "${precmd_functions[@]}")',
  '  preexec_functions=(__dsh_tty_preexec "${preexec_functions[@]}")',
  'fi',
  '# <<< dsh-tty shell integration <<<',
  '',
  ]
}

/** bash 前置片段；socket 名同样由参数传入（理由见 {@link zshHooks}）。 */
function bashPrelude(socket: string): string[] {
  return [
  '',
  '# >>> dsh-tty shell integration >>>',
  'if [ -z "$DSH_TTY_HOOKS_LOADED" ]; then',
  '  export DSH_TTY_HOOKS_LOADED=1',
  '  __DSH_TTY_IN_CMD=0',
  '  # tmux 持久标签：标记包 DCS passthrough 信封（同 zsh 桩说明）',
  '  if [ -n "$TMUX" ]; then',
  "    __DSH_TTY_FMT_A='\\ePtmux;\\e\\e]133;A\\a\\e\\\\'",
  "    __DSH_TTY_FMT_B='\\ePtmux;\\e\\e]133;B\\a\\e\\\\'",
  "    __DSH_TTY_FMT_D='\\ePtmux;\\e\\e]133;D;%s\\a\\e\\\\'",
  "    __DSH_TTY_FMT_CWD='\\ePtmux;\\e\\e]7;file://%s%s\\a\\e\\\\'",
  "    __DSH_TTY_FMT_T='\\ePtmux;\\e\\e]133;T;%s\\a\\e\\\\'",
  '  else',
  "    __DSH_TTY_FMT_A='\\e]133;A\\a'",
  "    __DSH_TTY_FMT_B='\\e]133;B\\a'",
  "    __DSH_TTY_FMT_D='\\e]133;D;%s\\a'",
  "    __DSH_TTY_FMT_CWD='\\e]7;file://%s%s\\a'",
  '  fi',
  '  # tmux 重画异步：precmd 发 D 前 capture-pane 快照（OSC 133;T base64，同 zsh 桩说明）',
  '  __dsh_tty_capture() {',
  '    local __dsh_tty_precmd_cap',
  `    __dsh_tty_precmd_cap=$(tmux -L ${socket} capture-pane -p -t "$TMUX_PANE" -S -200 2>/dev/null)`,
  '    if [ -n "$__dsh_tty_precmd_cap" ]; then',
  '      printf "$__DSH_TTY_FMT_T" "$(printf \'%s\' "$__dsh_tty_precmd_cap" | base64 | tr -d \'\\n\')"',
  '    fi',
  '  }',
  '  __dsh_tty_precmd() {',
  '    local ec=$?',
  '    # D 标记**无条件**发（0.19.0 修）：bash ≥4.4 的 B 由 PS0 发，而 PS0 的展开',
  '    # 在子 shell 里 —— 它设不了父 shell 的 __DSH_TTY_IN_CMD，于是守着这个 flag',
  '    # 会让 D 永远不发（实测 ubuntu bash 5：B 到了、D 没到，capture{last} 恒',
  '    # 返回 inProgress、tty_expect 永远超时）。配对交给宿主解析器：没有配对 B 的',
  '    # D 被忽略，所以空回车不会造出假命令。',
  '    [ -n "$TMUX" ] && __dsh_tty_capture',
  '    printf "$__DSH_TTY_FMT_D" "$ec"; __DSH_TTY_IN_CMD=0',
  '    printf "$__DSH_TTY_FMT_A"',
  '    printf "$__DSH_TTY_FMT_CWD" "${HOSTNAME}" "${PWD}"',
  '  }',
  ]
}

const BASH_POSTLUDE = [
  'fi',
  '# <<< dsh-tty shell integration <<<',
  '',
]

function ensureZshStubDir(): string | undefined {
  const cached = stubDirs.get(stubKey('zsh'))
  if (cached !== undefined) return cached
  try {
    const dir = join(pluginRuntimeDir(), 'shell', 'zsh')
    // 桩只做「source 用户原文件 + 追加钩子」；DSH_TTY_ORIG_ZDOTDIR 在包装层里
    // 固化为用户原 ZDOTDIR（无则 $HOME），保证用户 rc 链路不变。
    // .zlogout 也要链（0.19.0）：ZDOTDIR 指到桩目录后，登录 shell 退出时只读
    // ZDOTDIR 下的 .zlogout——缺了它用户的退出钩子被静默吞掉
    /*
     * 桩里的**自愈兜底**（D106）：包装层已经把 ORIG 解析对了，但桩可能来自旧版本
     * （write-if-changed 只在内容变化时重写，而 tmux pane 用的是落盘那份），或者外层
     * wrapper 被第三方改过。ORIG 一旦等于桩目录，`source` 自己就是无穷递归——所以在
     * 每个桩文件里再判一次，等于桩目录就退回 `$HOME`，并 export 让后续桩文件也用修正值。
     */
    const origGuard = (name: string): string[] => [
      `if [ -z "\${DSH_TTY_ORIG_ZDOTDIR:-}" ] || [ "\${DSH_TTY_ORIG_ZDOTDIR}" = ${shSingleQuote(dir)} ]; then export DSH_TTY_ORIG_ZDOTDIR="$HOME"; fi`,
      `if [ -f "$DSH_TTY_ORIG_ZDOTDIR/${name}" ]; then source "$DSH_TTY_ORIG_ZDOTDIR/${name}"; fi`,
    ]
    for (const name of ['.zshenv', '.zprofile', '.zlogin', '.zlogout'] as const) {
      writeIfChanged(join(dir, name), [
        '# dsh-tty shell integration stub (chain to user file)',
        ...origGuard(name),
        '',
      ].join('\n'))
    }
    writeIfChanged(join(dir, '.zshrc'), [
      '# dsh-tty shell integration stub (chain to user file, then add hooks)',
      ...origGuard('.zshrc'),
      ...zshHooks(tmuxSocketName()),
    ].join('\n'))
    stubDirs.set(stubKey('zsh'), dir)
    return dir
  } catch {
    return undefined
  }
}

function ensureBashStubRc(): string | undefined {
  const cached = stubDirs.get(stubKey('bash'))
  if (cached !== undefined) return cached
  try {
    const dir = join(pluginRuntimeDir(), 'shell', 'bash')
    const rc = join(dir, 'bashrc')
    writeIfChanged(rc, [
      '# dsh-tty shell integration stub (chain to user file, then add hooks)',
      '[ -f "$HOME/.bashrc" ] && source "$HOME/.bashrc"',
      ...bashPrelude(tmuxSocketName()),
      '  # —— B 标记（命令开始）：按 bash 版本二选一 ——',
      '  __dsh_tty_major=${BASH_VERSION%%.*}',
      '  __dsh_tty_minor=${BASH_VERSION#*.}; __dsh_tty_minor=${__dsh_tty_minor%%.*}',
      '  if [ "$__dsh_tty_major" -gt 4 ] || { [ "$__dsh_tty_major" -eq 4 ] && [ "$__dsh_tty_minor" -ge 4 ]; }; then',
      '    # bash ≥ 4.4：PS0 在每个提示符后、命令输出前展开',
      '    case "${PS0:-}" in',
      "      *'133;B'*) ;;",
      '      *) PS0="$__DSH_TTY_FMT_B""$PS0" ;;',
      '    esac',
      '    # PROMPT_COMMAND 挂钩：兼容字符串与数组（bash 5.1+）两种形态。',
      '    # 两种形态都必须**前置**：后置追加会让前序条目的返回码污染 $?，',
      '    # D 标记记到的就不是用户命令的退出码（数组形态的 += 恰好加在末尾）',
      '    case "$(declare -p PROMPT_COMMAND 2>/dev/null)" in',
      '      "declare -a"*)',
      '        case "${PROMPT_COMMAND[*]}" in',
      '          *__dsh_tty_precmd*) ;;',
      '          *) PROMPT_COMMAND=("__dsh_tty_precmd" "${PROMPT_COMMAND[@]}") ;;',
      '        esac ;;',
      '      *)',
      '        case "${PROMPT_COMMAND:-}" in',
      '          *__dsh_tty_precmd*) ;;',
      '          *) PROMPT_COMMAND="__dsh_tty_precmd${PROMPT_COMMAND:+;$PROMPT_COMMAND}" ;;',
      '        esac ;;',
      '    esac',
      '  else',
      '    # bash < 4.4（macOS 自带 3.2）：无 PS0，用 DEBUG trap 兜底。实测两个 3.2 怪癖：',
      '    #   1) handler 内 trap - DEBUG 卸载不生效（trap 保持武装）；',
      '    #   2) PROMPT_COMMAND 机制自身（precmd/rearm 段）也会触发 DEBUG fire。',
      '    # 因此按「永久武装 + handler 过滤」设计：$BASH_COMMAND 含桩内函数名的',
      '    # fire 直接忽略（否则幻影 B 会重启捕获区间，把用户输出切出 last 区域）；',
      '    # PROMPT_COMMAND 尾段每轮重新武装（bash 4.0~4.3 上 trap - DEBUG 生效时',
      '    # 走正常卸载/重装轮转）。副作用：循环体等内部命令会多发 B，仅影响',
      '    # capture{last} 的截取起点，D/退出码与 tty_expect 不受影响。',
      '    __dsh_tty_preexec() {',
      '      case "$BASH_COMMAND" in',
      '        ""|*__dsh_tty_precmd*|*__dsh_tty_rearm*) return ;;',
      '      esac',
      '      __DSH_TTY_IN_CMD=1',
      '      printf "$__DSH_TTY_FMT_B"',
      '      trap - DEBUG',
      '    }',
      '    __dsh_tty_rearm() { trap \'__dsh_tty_preexec\' DEBUG; }',
      '    # 不在 rc 加载时武装：bash 启动横幅（"default interactive shell" 等）',
      '    # 会触发一次无主 fire，产生幻影 B/D；首次 PROMPT_COMMAND 尾段武装即可',
      '    case "${PROMPT_COMMAND:-}" in',
      '      *__dsh_tty_precmd*) ;;',
      '      *) PROMPT_COMMAND="__dsh_tty_precmd${PROMPT_COMMAND:+;$PROMPT_COMMAND}; __dsh_tty_rearm" ;;',
      '    esac',
      '  fi',
      ...BASH_POSTLUDE,
    ].join('\n'))
    stubDirs.set(stubKey('bash'), rc)
    return rc
  } catch {
    return undefined
  }
}

/* ------------------------------------------------------------------ *
 * PowerShell 桩（Windows 宿主）
 * ------------------------------------------------------------------ */

/**
 * PowerShell 钩子（纯 ASCII）。
 *
 * 为什么必须纯 ASCII：Windows PowerShell 5.1 把**无 BOM** 的 .ps1 按当前 ANSI 代码页读，
 * 一个非 ASCII 字节就能让解析错位（本桩由 `-File` 载入，解析失败＝集成静默失效）。ESC/BEL
 * 因此用 `[char]27` / `[char]7` 现构造 —— PS 5.1 没有 `` `e `` 转义（6+ 才有）。
 *
 * 钩子形态：包装 `prompt`（发 `D;<退出码>`、`A`、OSC 7，再调用用户原 prompt）与
 * `PSConsoleHostReadLine`（命令被接受时发 `B`）。桩在 profile **之后**由 `-File` 载入，
 * 所以 `$function:prompt` 拿到的就是用户主题定义过的那个，包装后原样生效。
 *
 * 退出码取值：B 时刻快照 `$LASTEXITCODE`，D 时刻若它**变了**就报它（原生命令），否则按
 * `$?` 报 0/1（cmdlet）。刻意**不清空** `$LASTEXITCODE` —— 清了会让用户紧接着的
 * `echo $LASTEXITCODE` 读到空值。代价：连续两次原生命令给出同一个非零码时，第二次降级
 * 报 1（仍如实标失败，只是丢了具体码值）。
 *
 * **解析错误例外**（两版一致，2026-10-13 真机实测）：整行解析失败时命令一条都没跑，但
 * `$?` 与 `$LASTEXITCODE` 都没变，于是 D 报 **0**（`echo (1` 在 7.6.6 与 5.1 上都是 0；
 * 5.1 上 `echo A && echo B` 同样报 0）。没有可靠的钩子能区分「解析失败」与「命令成功但
 * 无输出」，所以如实记着：**PowerShell 上不能只看退出码判成功**，报错文本就在输出里。
 *
 * 只在原 `PSConsoleHostReadLine` 存在时才装钩子：用户若关掉了 PSReadLine，那个函数不
 * 存在，此时**一个标记都不发**（连 A/7 也不发）——只发 A/7 会让宿主 `sawMark=true` 而
 * `inCommand` 恒 false，`running` 就从「未知」退化成「没在跑」，正是 D77 警告的静默事故
 * （往正在跑的程序里塞命令）。
 *
 * 已知副作用（未修；VS Code 的 shell integration 是同一个取舍）：包装里先抓 `$?`、写完 OSC
 * 才调用户原 `prompt`，于是**用户原 prompt 读到的 `$?` 是那几次 `[Console]::Write` 的成败**
 * （恒真），而不是上一条命令的 —— `function prompt { if ($?) {…} }` 那种「失败变红」会因此
 * 失效。要修得先把失败态还原回去（例如按捕获到的状态补发一条错误记录），而那必须两版
 * PowerShell 都真机验过才能落。
 *
 * 已知限制（**未复现**，见 README 的 Windows 一节）：曾有记录说 PowerShell 7 上命令 stdout
 * 在 ConPTY 里晚于 D 标记抵达（渲染管线批量重画 vs 直通序列即时转发，与 tmux 场景同根因），
 * 于是宿主的 B..D 捕获窗口为空 —— cwd 跟随 / 退出码 / running 三态都正常，只有 `capture{last}`
 * 的输出在 PS 7 上可能为空。2026-10-13 在 pwsh **7.6.6**（Win11 ARM64）上按三档输出量复测
 * （20 次小输出、2000 行大输出、2s 内分 20 次的慢输出）：**0/20 空窗**，大输出保尾、慢输出
 * 完整，窗口里也没混进命令行回显 —— 未复现。留作待复现项（遇到空窗用 `tty_capture` 读尾部，
 * 并把当时的 pwsh 版本报回来）；tmux 那边用 OSC 133;T 快照绕过同类问题。
 */
function powershellHooks(): string[] {
  return [
  '',
  '# >>> dsh-tty shell integration >>>',
  '# Emits OSC 133 (A/B/D + exit code) and OSC 7 (cwd); the host parses the stream.',
  '# ASCII only: Windows PowerShell 5.1 reads a BOM-less .ps1 as ANSI text, so a',
  '# single non-ASCII byte (even inside a comment) breaks the whole script.',
  'if (-not $global:DSH_TTY_HOOKS_LOADED) {',
  '  $global:DSH_TTY_HOOKS_LOADED = $true',
  '  $global:__DSH_TTY_ESC = [char]27',
  '  $global:__DSH_TTY_BEL = [char]7',
  '  $global:__DSH_TTY_ORIG_PROMPT = $function:prompt',
  '  $global:__DSH_TTY_ORIG_RL = $function:PSConsoleHostReadLine',
  '  $global:__DSH_TTY_IN_CMD = $false',
  '  $global:__DSH_TTY_LEC_AT_B = $null',
  '  # No PSReadLine (user disabled it) -> emit nothing at all: an unpaired A/7 would',
  '  # make the host report "not running" for a busy session (see the TS comment).',
  '  if ($null -ne $global:__DSH_TTY_ORIG_RL) {',
  '    function global:PSConsoleHostReadLine {',
  '      $__dsh_tty_line = & $global:__DSH_TTY_ORIG_RL',
  '      if ($null -ne $__dsh_tty_line -and "$__dsh_tty_line".Trim().Length -gt 0) {',
  '        $global:__DSH_TTY_IN_CMD = $true',
  '        $global:__DSH_TTY_LEC_AT_B = "$global:LASTEXITCODE"',
  '        [Console]::Write($global:__DSH_TTY_ESC + "]133;B" + $global:__DSH_TTY_BEL)',
  '      }',
  '      $__dsh_tty_line',
  '    }',
  '    function global:prompt {',
  '      $__dsh_tty_ok = $?',
  '      if ($global:__DSH_TTY_IN_CMD) {',
  '        $__dsh_tty_ec = "0"',
  '        if (-not $__dsh_tty_ok) { $__dsh_tty_ec = "1" }',
  '        if ($null -ne $global:LASTEXITCODE -and "$global:LASTEXITCODE" -ne $global:__DSH_TTY_LEC_AT_B) {',
  '          $__dsh_tty_ec = "$global:LASTEXITCODE"',
  '        }',
  '        [Console]::Write($global:__DSH_TTY_ESC + "]133;D;" + $__dsh_tty_ec + $global:__DSH_TTY_BEL)',
  '        $global:__DSH_TTY_IN_CMD = $false',
  '      }',
  '      [Console]::Write($global:__DSH_TTY_ESC + "]133;A" + $global:__DSH_TTY_BEL)',
  '      try {',
  '        $__dsh_tty_uri = ([System.Uri]::new((Get-Location).Path)).AbsoluteUri',
  '        [Console]::Write($global:__DSH_TTY_ESC + "]7;" + $__dsh_tty_uri + $global:__DSH_TTY_BEL)',
  '      } catch { }',
  '      & $global:__DSH_TTY_ORIG_PROMPT',
  '    }',
  '  }',
  '}',
  '# <<< dsh-tty shell integration <<<',
  '',
  ]
}

/** 写 PowerShell 桩（稳定路径 + write-if-changed）并返回桩文件路径；失败返回 undefined（集成静默降级）。 */
function ensurePowerShellStub(): string | undefined {
  const cached = stubDirs.get(stubKey('powershell'))
  if (cached !== undefined) return cached
  try {
    const stub = join(pluginRuntimeDir(), 'shell', 'powershell', 'bootstrap.ps1')
    writeIfChanged(stub, powershellHooks().join('\n'))
    stubDirs.set(stubKey('powershell'), stub)
    return stub
  } catch {
    return undefined
  }
}

/**
 * 组装 shell 启动计划：在原有 TERM/COLORTERM 包装层之上，按 shell basename
 * 注入集成（zsh → ZDOTDIR 桩；bash → --rcfile 桩）。integration=false 或不
 * 支持的 shell 返回最简包装层。
 */
/**
 * 带自定义命令的本地 spawn 计划（0.14.0）：给「开一个标签直接跑某条命令」用
 * （如 dsh-docker 的 `docker exec -it <容器> sh`）。命令由**宿主侧插件**提供，
 * 信任级与插件本身相同；TERM / COLORTERM 仍走白名单值。
 * 命令必须单行（换行会破坏 -c 包装层），由调用方（src/index.ts 的帧解析）保证。
 */
export function buildCommandSpawn(shell: string, term: string, colorTerm: string, command: string, platform: NodeJS.Platform = process.platform): ShellSpawnPlan {
  if (platform === 'win32') return buildWindowsCommandSpawn(shell, command)
  const pre = `export TERM='${term}'; export COLORTERM='${colorTerm}';`
  /*
   * D78：命令**整体**交给内层 shell（`-c`），不再直接缀在 `exec` 后面。
   *
   * 旧写法是 `${pre} exec ${command}`，而 `exec` 只是**简单命令**的前缀：zsh 会把
   * `exec echo A; echo B` 解析成 `[exec echo A] ; [echo B]`，第一条把 shell 进程替换
   * 掉之后 `echo B` 永远不会被调度；`cd x && cmd` 的右支同理；`exec for …` 直接在
   * 解析阶段报错；退出码也变成被 exec 的那条命令的。更狠的是内建命令：`exec cd /tmp`
   * 在 zsh 里的语义是「跑完内建即结束当前 shell」，于是连第一条的输出都没有、
   * `&&` 右支连同外层 shell 一起消失（`tty_open command="cd /tmp && pwd"` 实测空输出、
   * rc=0，2026-09-27 报告）。
   *
   * 用户的命令是**一段 shell 代码**，不是一条 argv——这是「跑一条命令」这个工具的
   * 基本契约：`cd dir && cmd`、`cmd; echo rc=$?` 正是 agent 最惯用的写法，静默少跑
   * 后半段比报错更难查。内层仍用同一个 shell（交互习惯一致：zsh 的 `for` 语法照旧），
   * 且不加 `-l/-i`（维持非交互语义，不 source rc，与旧路径一致）。
   *
   * 外层 `exec` 保留：进程被内层 shell 替换，「进程即命令」的语义不变——退出码取自
   * 命令列表最后一条，**被信号打死时仍如实报 signal**（不套 exec 的话外层 shell 会把
   * 信号退化成 128+n 的退出码，而 D77 的面板与工具文案正是靠 signal 区分崩溃与正常退出）。
   *
   * 内层用 `shSingleQuote` 包住：命令里的单引号由 `'\''` 转义，带引号 / 多行的命令
   * 都能安全穿过外层 shell 的解析。
   */
  const inner = `${shSingleQuote(shell)} -c ${shSingleQuote(command)}`
  return { argv: [shell, '-c', `${pre} exec ${inner}`], env: {} }
}

/**
 * 本地终端默认 shell。
 *
 * POSIX 取 `$SHELL`（macOS 上通常 /bin/zsh）；**Windows 上根本没有 `$SHELL`** —— 旧实现
 * 无条件回落 `/bin/zsh`，于是 Windows 宿主上每个本地标签都在 spawn 阶段 ENOENT（2026-09
 * 在 Windows 11 ARM 上实测：`spawn /bin/zsh -> ENOENT`，而 `%COMSPEC%` 可用），整个面板
 * 一条终端都开不起来。Windows 取 `%COMSPEC%`（系统保证存在），要 PowerShell 就在设置卡片
 * 里把「Shell 路径」填成 powershell.exe / pwsh.exe。
 */
export function defaultShellPath(platform: NodeJS.Platform = process.platform, env: NodeJS.ProcessEnv = process.env): string {
  if (platform === 'win32') return env.COMSPEC?.trim() || 'cmd.exe'
  return env.SHELL?.trim() || '/bin/zsh'
}

/**
 * PowerShell 家族（Windows PowerShell 5.1 与 PowerShell 7）——启动参数与 cmd 不同。
 *
 * 这里**不用 `path.basename`**：它按当前平台的规则切，在 POSIX 上拿到
 * `C:\Program Files\PowerShell\7\pwsh.exe` 会整串返回（没有 `/`），判定就漏了。
 * 两个分隔符一起切，任何平台上都对。
 */
/**
 * 本地「跑一条命令」时，**命令由哪个 shell 执行、按什么语法**（D78 补，2026-09-27 复核报告）。
 *
 * 为什么需要它：`command` 是整段交给宿主 shell 的（POSIX 分支 `exec <shell> -c`，Windows 分支
 * `cmd /c` / `-Command` / `bash -c`），也就是**语法随宿主平台与「Shell 路径」设置变**。
 * 只写「按整段 shell 代码执行、`a; b` 都可以」会误导模型：在 Windows 的 cmd 上，`;`、`for …; do`、
 * `$?`、`$$`、单引号全都不是 cmd 语法——报告方就是在 Windows 上按 POSIX 语法复测，9 条全红。
 *
 * 文案要短（进 systemPrompt 每轮都出现），但必须点明「哪些不是这个 shell 的语法」。
 */
export function commandShellHint(shell: string, platform: NodeJS.Platform = process.platform): string {
  const name = shell.trim() === '' ? '(未配置)' : shell.trim()
  if (platform !== 'win32') {
    return `本地命令由 ${name} 执行：按 POSIX shell 语法（\`a; b\`、\`cd x && y\`、\`for …; do …; done\`、管道、单引号）`
  }
  if (isPowerShellShell(name)) {
    const kind = name.split(/[\\/]/).pop()?.toLowerCase() ?? ''
    // PowerShell 7（pwsh）与 Windows PowerShell 5.1 的语法**不一样**，这句话每一轮都进
    // systemPrompt，说错会直接把模型引到不存在的坑里（D101，2026-10-13 真机实测：
    // 7.6.6 上 `echo A && echo B` 正常输出 A/B、5.1 上同一行是解析错误且一条都没跑）。
    if (kind === 'pwsh' || kind === 'pwsh.exe') {
      return `本地命令由 ${name} 执行：按 **PowerShell 7** 语法（\`;\` 分隔语句、\`$env:VAR\` 取环境变量、\`$(…)\` 子表达式、\`&&\`/\`||\` 链式、\`$?\` 判上一条是否成功、\`$LASTEXITCODE\` 取原生命令退出码；单引号是字面量、双引号才插值）`
    }
    return `本地命令由 ${name} 执行：按 **Windows PowerShell 5.1** 语法（\`;\` 分隔语句、\`$env:VAR\` 取环境变量、\`$(…)\` 子表达式；**5.1 没有 \`&&\`/\`||\`**——条件执行写 \`if ($?) { … }\`，退出码用 \`$LASTEXITCODE\`；单引号是字面量）`
  }
  const kind = name.split(/[\\/]/).pop()?.toLowerCase() ?? ''
  if (kind === 'bash.exe' || kind === 'bash' || kind === 'sh.exe' || kind === 'sh' || kind === 'zsh.exe' || kind === 'zsh') {
    return `本地命令由 ${name} 执行：这是 POSIX shell，按 POSIX 语法（\`a; b\`、\`cd x && y\`、\`for …; do …; done\`）`
  }
  if (kind === 'wsl.exe' || kind === 'wsl') {
    return `本地命令由 ${name} 执行：命令经默认发行版的 \`sh -c\`，按 POSIX 语法`
  }
  return `本地命令由 ${name} 执行：按 **cmd** 语法（\`&\` 顺序执行、\`&&\` 条件执行、\`|\` 管道、\`%VAR%\` 取环境变量；POSIX 的 \`;\`、\`for …; do\`、\`$?\`、\`$$\`、单引号都不是 cmd 语法）`
}

export function isPowerShellShell(shell: string): boolean {
  const kind = shell.split(/[\\/]/).pop()?.toLowerCase() ?? ''
  return kind === 'powershell' || kind === 'powershell.exe' || kind === 'pwsh' || kind === 'pwsh.exe'
}

/**
 * 该平台 + 该 shell 下，OSC 133/7 集成**能不能注入**（宿主把开关存成什么值的判据）。
 *
 * POSIX 恒 true：注入只对 zsh / bash 有实现，其他 shell 在 buildShellSpawn 里自然退回最简
 * 包装层 —— 这是历史行为，不动它（把 fish 之流一并拨 false 会改变既有快照语义）。
 *
 * Windows 只有 PowerShell 家族为 true（`-File` 桩 + prompt / PSConsoleHostReadLine 钩子）；
 * cmd 没有命令开始/结束钩子，注入无从谈起。
 */
export function shellIntegrationSupported(shell: string, platform: NodeJS.Platform = process.platform): boolean {
  if (platform !== 'win32') return true
  return isPowerShellShell(shell)
}

/**
 * Windows 宿主的启动计划：**直接跑 shell 本体，不做 `-c` 包装层**。
 *
 * 为什么不能沿用 POSIX 那层（`-c 'export TERM=…; exec "$shell"'`）：cmd.exe 不认 `-c`，
 * 会把整行忽略掉、开一场空跑然后立刻退出（标签开了就消失）；PowerShell 认 `-c` 但把
 * `export` 当不存在的 cmdlet 直接报错（两条都在 Windows 11 上实测过）。TERM / COLORTERM
 * 对 ConPTY 也没有意义。
 *
 * OSC 133/7 集成的注入形态与 POSIX 不同：Windows 走 PowerShell 的 `-File` 稳定桩（rc 注入
 * 在这里不成立 —— 没有 rc 文件可挂）。cmd 维持「不注入」：没有命令开始/结束钩子就发不出
 * A/B/D，`capture{last}`、running 三态与 cwd 跟随全都无从谈起（宿主侧因此对 Windows + cmd
 * 把 shellIntegration 存 false，见 index.ts 与 shellIntegrationSupported）。
 *
 * PowerShell 补 `-NoLogo` 只是去掉启动横幅；**不补 `-NoProfile`** —— 用户的 profile 正是
 * 别名与函数的来源，终端面板不该替用户把它关掉；桩也要靠「profile 之后」载入才能拿到用户
 * 自定义的 prompt 去包装。
 *
 * `-NoExit` 必须给：`-File` 跑完脚本就退出，标签会开了即关。桩只装钩子、不做别的。
 *
 * `-ExecutionPolicy Bypass` 是**进程级**的：机器策略若为 Restricted / AllSigned，不加它连
 * 这个未签名的桩都载不进去（表现是集成静默失效）。它不改机器策略，也不放宽本插件的信任级
 * —— 终端面板本来就在以用户身份执行任意命令。取值停在 Bypass（不改用更窄的 RemoteSigned：
 * 收益只是策略窄一点，代价是载入路径要在真机上重验一遍）。两条边界如实记下：
 *   1. **组策略优先**：`-ExecutionPolicy` 能压过注册表里的策略，但压不过**组策略**设置的
 *      策略。GPO 锁成 Restricted / AllSigned 的机器上，桩照样载不进去 —— 标签开着、集成
 *      没有（与「用户关了 PSReadLine」同一种静默降级，见 README 的 Windows 一节）；
 *   2. **会外溢给子进程**：这个参数把值写进 `$Env:PSExecutionPolicyPreference`，从该会话里
 *      再起 powershell / pwsh 会继承它。
 */
function buildWindowsShellSpawn(shell: string, integration: boolean): ShellSpawnPlan {
  if (!isPowerShellShell(shell)) return { argv: [shell], env: {} }
  if (integration) {
    const stub = ensurePowerShellStub()
    if (stub !== undefined) {
      return { argv: [shell, '-NoLogo', '-NoExit', '-ExecutionPolicy', 'Bypass', '-File', stub], env: {} }
    }
  }
  return { argv: [shell, '-NoLogo'], env: {} }
}

/**
 * Windows 宿主的「跑一条命令」计划：按 shell 家族选参数（0.19.0 前一律 /c，Git Bash / WSL 静默失败）。
 *
 * PowerShell 的退出码口径（2026-10-13 真机实测，两版一致）：`-Command` 会把**末条命令非零**的
 * 情况塌成进程退出码 **1**，拿不到具体码值 —— `cmd /c exit 5` 经 `-Command` 出来是 1，而
 * `exit 5` 出来是 5。POSIX 侧 `sh -c` 不会这样（`exit 5` → 5、末条命令是它自己）。所以
 * `tty_run` 在 PowerShell 上要拿到具体退出码，命令得自己 `exit`（README 的「跑一条命令」一节记着）。
 */
function buildWindowsCommandSpawn(shell: string, command: string): ShellSpawnPlan {
  if (isPowerShellShell(shell)) {
    return { argv: [shell, '-NoLogo', '-Command', command], env: {} }
  }
  const kind = shell.split(/[\\/]/).pop()?.toLowerCase() ?? ''
  // Git Bash 等 POSIX shell 认 -c
  if (kind === 'bash.exe' || kind === 'bash' || kind === 'sh.exe' || kind === 'sh' || kind === 'zsh.exe' || kind === 'zsh') {
    return { argv: [shell, '-c', command], env: {} }
  }
  // WSL：-e 直跑默认发行版的 sh，再由它 -c（wsl.exe 自身不认 /c / -c）
  if (kind === 'wsl.exe' || kind === 'wsl') {
    return { argv: [shell, '-e', 'sh', '-c', command], env: {} }
  }
  return { argv: [shell, '/c', command], env: {} }
}

/**
 * zsh 集成里 `DSH_TTY_ORIG_ZDOTDIR`（用户真正的 ZDOTDIR）的解析片段（POSIX sh 单行）。
 *
 * ## 为什么不能直接写 `${ZDOTDIR:-$HOME}`
 *
 * 宿主的**进程环境**里 `ZDOTDIR` 可能**已经是桩目录**——最典型的场景：在 dsh 的终端面板里
 * 再起一个 dsh（嵌套），子宿主的 env 就带着父会话导出的 `ZDOTDIR=<桩目录>/shell/zsh`。
 * 旧实现把继承值当 ORIG，于是桩 `.zshenv` 的 `source "$DSH_TTY_ORIG_ZDOTDIR/.zshenv"`
 * 指回**自己** → 递归 → zsh 打满 job table：
 *
 * ```
 * /Users/<u>/.dsh/tty/shell/zsh/.zshenv:2: job table full or recursion limit exceeded
 * ```
 *
 * 结果是这条本地会话**一个 OSC 133 标记都没有**（`tty_list` 恒「命令状态未知」、
 * `tty_capture{last}` 报「暂无上一条命令」）。tmux 持久会话反而正常——pane 的启动器由
 * tmux server 执行，环境里没有桩值，这条差别正是 2026-11-05 真机复测抓到它的位置。
 *
 * ## 判据（三层，从最可信往下）
 *
 * 1. 已有 `DSH_TTY_ORIG_ZDOTDIR` 且**不是**桩目录 → 保留（嵌套 dsh：父会话已把真值传下来）；
 * 2. 否则用继承的 `ZDOTDIR`，但**必须不是桩目录**；
 * 3. 否则 `$HOME`。
 *
 * 片段自己会 `export`，调用方后接 `export ZDOTDIR=<桩目录>` 即可（顺序不能反）。
 */
export function zshOrigResolveSnippet(stubDir: string): string {
  const stub = shSingleQuote(stubDir)
  return [
    `if [ -z "\${DSH_TTY_ORIG_ZDOTDIR:-}" ] || [ "\${DSH_TTY_ORIG_ZDOTDIR}" = ${stub} ]; then`,
    `if [ -n "\${ZDOTDIR:-}" ] && [ "\${ZDOTDIR}" != ${stub} ]; then export DSH_TTY_ORIG_ZDOTDIR="$ZDOTDIR";`,
    'else export DSH_TTY_ORIG_ZDOTDIR="$HOME"; fi; fi',
  ].join(' ')
}

export function buildShellSpawn(shell: string, term: string, colorTerm: string, integration: boolean, platform: NodeJS.Platform = process.platform): ShellSpawnPlan {
  if (platform === 'win32') return buildWindowsShellSpawn(shell, integration)
  const pre = `export TERM='${term}'; export COLORTERM='${colorTerm}';`
  const exec = `exec "${shell}"`
  if (integration) {
    const kind = basename(shell)
    if (kind === 'zsh') {
      const stubDir = ensureZshStubDir()
      if (stubDir !== undefined) {
        return {
          argv: [shell, '-c', `${pre} ${zshOrigResolveSnippet(stubDir)}; export ZDOTDIR='${stubDir}'; ${exec}`],
          env: {},
        }
      }
    } else if (kind === 'bash') {
      const stubRc = ensureBashStubRc()
      if (stubRc !== undefined) {
        return {
          argv: [shell, '-c', `${pre} ${exec} --rcfile '${stubRc}'`],
          env: {},
        }
      }
    }
  }
  return { argv: [shell, '-c', `${pre} ${exec}`], env: {} }
}

/* ------------------------------------------------------------------ *
 * tmux 持久会话的内层 pane 启动器（0.10.0）
 * ------------------------------------------------------------------ */

/** POSIX 单引号安全包裹（路径/值进 inner.sh 与 -c 包装层用）。 */
export function shSingleQuote(value: string): string {
  return "'" + value.replace(/'/g, `'\\''`) + "'"
}

/**
 * 生成 tmux `default-command` 指向的内层启动器脚本：pane 里的 shell 由它
 * exec 出来（非登录式，与非持久标签语义一致），并按当前配置注入 shell 集成。
 * 脚本内容随配置重写（路径稳定、内容原子覆盖），tmux server 无需重启即可
 * 让新 pane 用上新配置。
 */
export function buildTmuxInnerLauncher(shell: string, colorTerm: string, integration: boolean): string {
  const lines = [
    '#!/bin/sh',
    '# generated by dsh-tty（tmux 持久会话内层 shell 启动器）— 手改会被覆盖',
    `export COLORTERM=${shSingleQuote(colorTerm)}`,
  ]
  if (integration) {
    const kind = basename(shell)
    if (kind === 'zsh') {
      const stubDir = ensureZshStubDir()
      if (stubDir !== undefined) {
        lines.push(
          zshOrigResolveSnippet(stubDir),
          `export ZDOTDIR=${shSingleQuote(stubDir)}`,
          `exec ${shSingleQuote(shell)}`,
        )
        return lines.join('\n') + '\n'
      }
    } else if (kind === 'bash') {
      const stubRc = ensureBashStubRc()
      if (stubRc !== undefined) {
        lines.push(`exec ${shSingleQuote(shell)} --rcfile ${shSingleQuote(stubRc)}`)
        return lines.join('\n') + '\n'
      }
    }
  }
  lines.push(`exec ${shSingleQuote(shell)}`)
  return lines.join('\n') + '\n'
}
