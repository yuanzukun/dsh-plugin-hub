/* eslint-disable */
/**
 * dsh-tty 预览夹具：在纯静态页面里伪造 DSH 宿主环境（module loader / fetch /
 * WebSocket），让 packages/tty/client.js 能在浏览器中独立渲染，用于视觉走查
 * 与截图回归。仅供 scripts/preview.mjs 使用，不随 npm 包发布。
 */
(function () {
  'use strict'

  const React = window.React

  /* ---------- react/jsx-runtime 垫片（React 18 UMD 不含该入口） ---------- */
  const jsx = (type, props, key) => {
    const p = {}
    let children
    if (props !== null && props !== undefined) {
      for (const k in props) {
        if (k === 'children') children = props[k]
        else p[k] = props[k]
      }
    }
    if (key !== undefined) p.key = key
    if (children === undefined) return React.createElement(type, p)
    return Array.isArray(children) ? React.createElement(type, p, ...children) : React.createElement(type, p, children)
  }
  window.__jsxRuntime = { jsx, jsxs: jsx, Fragment: React.Fragment }

  /* ---------- 假配置（结构与宿主 /api/dsh-tty/config 一致） ---------- */
  const CONFIG = {
    enabled: true,
    announceToAgent: true,
    maxSessions: 4,
    shell: '/bin/zsh',
    term: 'xterm-256color',
    colorTerm: 'truecolor',
    cwd: window.__PREVIEW_CWD || '/home/user/project',
    reconnectGraceSec: 120,
    shellIntegration: true,
    sftpStyle: window.__PREVIEW_SFTP_STYLE || 'dialog',
    persistence: window.__PREVIEW_PERSISTENCE || 'off',
    endOnPageClose: false,
    statsEnabled: true,
    // AI 辅助：**默认关**（与宿主 Config 的默认值一致；夹具要开就自己改这一项，
    // 顺带把「关着时一个徽标都不摆」这条也验掉）
    assistEnabled: false,
    assistProvider: '',
    assistModel: '',
    sftpLimits: { maxDownloadMb: 1024, maxUploadMb: 2048, maxUploadFiles: 1000 },
    toolsRegistered: true,
    sshHosts: [
      { name: 'prod-web-01', host: '198.51.100.20', port: 22, username: 'deploy', auth: 'key', keyPath: '~/.ssh/id_ed25519', passphrase: '', password: '', agentForward: true, persist: false },
      { name: 'staging-db', host: 'db.staging.internal', port: 2222, username: 'root', auth: 'password', keyPath: '', passphrase: '', password: 'env:STAGING_DB_PASSWORD', agentForward: false, persist: false },
      // 刻意**没有**任何隧道：验证「没配隧道时收进 ⋯ 更多」这条路径
      // （上面两条都有隧道，走的是常驻「隧道 N」按钮）
      { name: 'bare-host', host: 'bare.internal', port: 22, username: 'ops', auth: 'agent', keyPath: '', passphrase: '', password: '', agentForward: false, persist: false },
      /*
       * 唯一一条把「高级」三段**都配上**的条目（跳板机 + 代理命令 + 主机密钥别名）：
       * `ssh-jump` 场景用它验折叠区的默认展开判据——配过却收起来，等于把配置藏了。
       */
      {
        name: 'bastion-jump',
        host: 'internal.corp',
        port: 22,
        username: 'deploy',
        auth: 'key',
        keyPath: '~/.ssh/id_ed25519',
        passphrase: '',
        password: '',
        agentForward: false,
        persist: false,
        hostKeyAlias: 'corp-internal',
        proxyCommand: 'ssh -W %h:%p bastion.corp',
        jump: { host: 'bastion.corp', port: 2222 },
      },
    ],
    hostKeys: [
      { host: '198.51.100.20', port: 22, fingerprint: 'SHA256:9xQ2mVr7Kp3sTf1cZbLd8uYwAe4nHjR6gPoXkMvQ2Bc' },
      { host: 'db.staging.internal', port: 2222, fingerprint: 'SHA256:3fLp8Rt2Wq9yUvC4dXzN6mBsAe1hKjG7oPwXiMnQ5Bd' },
    ],
    tunnels: [
      { name: 'staging-pg', bookName: 'staging-db', direction: 'local', localPort: 15432, remoteHost: '127.0.0.1', remotePort: 5432, localTargetHost: '127.0.0.1', localTargetPort: 5432, enabled: true },
      { name: 'prod-redis', bookName: 'prod-web-01', direction: 'local', localPort: 16379, remoteHost: 'redis.internal', remotePort: 6379, localTargetHost: '127.0.0.1', localTargetPort: 6379, enabled: true },
    ],
  }
  window.__PREVIEW_CONFIG = CONFIG

  const json = (body) => Promise.resolve({ ok: true, status: 200, json: async () => body, text: async () => JSON.stringify(body) })

  // 字段名与宿主 /api/dsh-tty/sftp/list 的 entry 一致（isDir / isSymlink / size / mtime）
  const SFTP_FILES = [
    { name: 'app', isDir: true, size: 4096, mtime: 1757300000000 },
    { name: 'logs', isDir: true, size: 4096, mtime: 1757312000000 },
    { name: 'releases', isDir: true, size: 4096, mtime: 1757290000000 },
    { name: '.env', isDir: false, size: 812, mtime: 1757311000000 },
    { name: 'docker-compose.yml', isDir: false, size: 2481, mtime: 1757309000000 },
    { name: 'nginx.conf', isDir: false, size: 1743, mtime: 1757301000000 },
    { name: 'deploy.sh', isDir: false, size: 5120, mtime: 1757311500000 },
    { name: 'current', isDir: false, isSymlink: true, size: 17, mtime: 1757311800000 },
  ]
  const LOCAL_FILES = [
    { name: 'docs', isDir: true, size: 4096, mtime: 1757300000000 },
    { name: 'packages', isDir: true, size: 4096, mtime: 1757312000000 },
    { name: 'scripts', isDir: true, size: 4096, mtime: 1757290000000 },
    { name: 'README.md', isDir: false, size: 23194, mtime: 1757311000000 },
    { name: 'package.json', isDir: false, size: 1450, mtime: 1757309000000 },
    { name: 'pnpm-lock.yaml', isDir: false, size: 53560, mtime: 1757301000000 },
  ]

  const route = (url, body) => {
    if (url.indexOf('/api/dsh-tty/config') === 0) {
      /*
       * POST = 保存：**照真实宿主的样子把补丁应用进 CONFIG 再回快照**（不是原样回一份旧的）。
       * 这是 D91 的照妖镜——客户端保存成功后拿**这份响应**重置整张表单，夹具要永远回旧值，
       * 就等于把「到底存下去了没有」这件事从测试里抠掉了。
       */
      if (body !== null && typeof body === 'object') {
        window.__mockConfigPosts = (window.__mockConfigPosts || []).concat([body])
        for (const [key, value] of Object.entries(body)) {
          if (key === 'sshHosts' || key === 'tunnels' || key === 'hostKeys' || key === 'sftpLimits') continue
          CONFIG[key] = value
        }
      }
      /*
       * 保存前端口探测（tty D60 前半）：真宿主在 **200** 里带回 `warnings`，客户端据此
       * 把「已生效」换成黄色警告。夹具必须照这个形状回，否则 `port-warn` 场景验的是
       * 一条不存在的路（同 D91 那条：夹具自己扮演宿主，它撒谎测试就永远绿）。
       *
       * `window.__PREVIEW_PORT_WARNINGS` 决定回什么：数组即照发，缺省 = 一次都不报
       * （与真实宿主「端口都空着」的常态一致）。
       */
      const warnings = window.__PREVIEW_PORT_WARNINGS
      return Array.isArray(warnings) && warnings.length > 0
        ? { ok: true, config: CONFIG, warnings }
        : { ok: true, config: CONFIG }
    }
    if (url.indexOf('/api/dsh-tty/shells') === 0) return { ok: true, shells: ['/bin/zsh', '/bin/bash', '/bin/sh', '/opt/homebrew/bin/fish'] }
    /*
     * 模型候选目录（/api/dsh-tty/model-catalog）。形状与宿主一致：providers **恒有**、models
     * **按 provider 才有**（目录是 per-provider 的）。场景据此断言「选了 provider，模型候选跟着来」。
     */
    if (url.indexOf('/api/dsh-tty/model-catalog') === 0) {
      const provider = new URL(url, 'http://preview').searchParams.get('provider') || ''
      window.__mockLog.push('fetch:model-catalog:' + provider)
      /*
       * `window.__PREVIEW_CATALOG = { fail: true }` 模拟**宿主没这条路由**（多半是没重启）：
       * 真机上那是 401，客户端只看得到「拿不到」。这是用户实测撞到的那个现场，
       * 界面必须说「拿不到」，而不是笼统说一句「没有候选」把人引到「我配错了」上去。
       */
      const canned = window.__PREVIEW_CATALOG
      if (canned && canned.fail === true) return { ok: false, error: 'unauthorized' }
      return {
        ok: true,
        available: true,
        providers: [
          { id: 'mock-provider', name: 'Mock Provider' },
          { id: 'tokenrhythm', name: 'tokenrhythm' },
        ],
        groups: [
          { id: 'mock-provider', name: 'Mock Provider', models: [
            { id: 'mock-fast', name: 'mock-fast' },
            { id: 'mock-reasoning', name: 'Mock Reasoning' },
          ] },
          { id: 'tokenrhythm', name: 'tokenrhythm', models: [
            { id: 'deepseek-flash', name: 'DeepSeek Flash' },
          ] },
        ],
        models: provider === '' ? [] : [
          { id: 'mock-fast', name: 'mock-fast' },
          { id: 'mock-reasoning', name: 'Mock Reasoning' },
        ],
        provider: provider,
      }
    }
    if (url.indexOf('/api/dsh-tty/env-vars') === 0) return { ok: true, names: ['STAGING_DB_PASSWORD', 'PROD_DEPLOY_KEY', 'GITHUB_TOKEN', 'OPENAI_API_KEY', 'SSH_PASSPHRASE'] }
    if (url.indexOf('/api/dsh-tty/tunnels') === 0) return { ok: true, tunnels: [
      { name: 'staging-pg', state: 'active', connections: 2, totalConnections: 17, error: '', lastForwardError: '' },
      { name: 'prod-redis', state: 'connecting', connections: 0, totalConnections: 3, error: '', lastForwardError: '' },
    ] }
    if (url.indexOf('/api/dsh-tty/sftp/list') === 0) return { ok: true, path: body && body.path ? body.path : '/srv/app', entries: SFTP_FILES }
    if (url.indexOf('/api/dsh-tty/sftp/') === 0) return { ok: true }
    if (url.indexOf('/api/dsh-tty/local-fs/list') === 0) return { ok: true, path: body && body.path ? body.path : (window.__PREVIEW_CWD || '/home/user/project'), entries: LOCAL_FILES }
    if (url.indexOf('/api/dsh-tty/local-fs') === 0) return { ok: true, home: window.__PREVIEW_HOME || '/home/user' }
    // 形状对齐 probeSummary()：{ tcp:{ok,ms}, banner:{ok}, hostkey:{state}, auth:{ok,ms} }
    if (url.indexOf('/api/dsh-tty/probe') === 0) return { ok: true, result: {
      tcp: { ok: true, ms: 8 },
      banner: { ok: true },
      hostkey: { state: 'matched' },
      auth: { ok: true, ms: 296 },
    } }
    /*
     * AI 辅助「失败即解释」（0.24.0）。答案由 `window.__PREVIEW_ASSIST` 供给：
     *   - `{ error: '…' }` → 模拟「没有可用的模型路由」（宿主也是这个形状：ok:false + error）
     *   - `{ answer, command }` → 正常答案（command 就是宿主的 extractCommandFromAnswer 结果）
     * 默认答案里刻意塞了 **HTML 与围栏**：答案必须原样显示（`<b>` 不许被当标签解析），
     * 而围栏块是宿主机侧取命令的来源。
     */
    if (url.indexOf('/api/dsh-tty/assist') === 0) {
      // 记一笔：场景要断言「点徽标之前不许有请求」（零输入入口 ≠ 自动外发）
      window.__mockLog.push('fetch:assist')
      const canned = window.__PREVIEW_ASSIST
      if (canned && typeof canned.error === 'string') return { ok: false, error: canned.error }
      // 形状与真实宿主一致：answer 是**已去标记**的正文（Markdown 的解析在宿主做）
      const answer = canned && typeof canned.answer === 'string'
        ? canned.answer
        : '发生了什么：<b>这不是加粗</b>，是输出里的原文；依赖装漏了一个。\n\n下一步：\n装完再跑一次。'
      return {
        ok: true,
        answer,
        command: canned && typeof canned.command === 'string' ? canned.command : 'npm install',
        route: 'mock/model',
        chars: 812,
        ms: 37,
      }
    }
    if (url.indexOf('/api/dsh-tty/ssh-config') === 0) return { ok: true, hosts: [] }
    if (url.indexOf('/api/dsh-tty/known-hosts') === 0) return { ok: true, keys: [] }
    if (url.indexOf('/api/dsh-docker/') === 0) return dockerRoute(url.slice('/api/dsh-docker'.length), body)
    return { ok: true }
  }

  /* ---------- 假 dsh-docker API：让 docker 面板与 tty 的 ttyTerminal 端到端联调 ---------- */
  const DOCKER_TARGETS = [
    { name: '目标1', kind: 'ssh', label: 'root@192.0.2.10' },
    { name: '目标2', kind: 'local', label: '本机' },
    // 与 tty 连接簿的 prod-web-01 对齐：连接栏「容器」按钮的命中路径（docker-dock 场景）
    { name: 'prod-web-01', kind: 'ssh', label: 'deploy@198.51.100.20' },
  ]
  // 形状照搬宿主 /config：设置卡片会读 ttyBooks / hostKeys / ttyAvailable，
  // 少一个字段就是「渲染期 undefined.length」——离线场景直接崩
  window.__PREVIEW_DOCKER_CONFIG = {
    enabled: true,
    announceToAgent: true,
    dockerBin: 'docker',
    allowMutations: false,
    allowExec: true,
    pollIntervalSec: 5,
    logTailDefault: 200,
    maxOutputKb: 512,
    execTimeoutSec: 30,
    hostKeys: [],
    ttyBooks: ['prod-web-01'],
    ttyAvailable: true,
    toolsRegistered: [],
    targets: [
      { name: '目标1', kind: 'ssh', book: '', host: '192.0.2.10', port: 22, username: 'root', auth: 'agent', agentForward: false },
      { name: '目标2', kind: 'local', book: '', host: '', port: 22, username: '', auth: 'agent', agentForward: false },
      { name: 'prod-web-01', kind: 'ssh', book: 'prod-web-01', host: '', port: 22, username: '', auth: 'agent', agentForward: false },
      // 刻意引用一个**不在 ttyBooks 里**的条目名：验证设置卡片能把"失效引用"标出来
      // （不标的话那个 book 下拉渲染成空白，看不出错，要等真去连才报）
      { name: '陈旧引用', kind: 'ssh', book: '已改名的条目', host: '', port: 22, username: '', auth: 'agent', agentForward: false },
    ],
  }
  window.__PREVIEW_DOCKER_CONTAINERS = [
    { id: 'a1b2c3d4e5f6a7b8c9d0', shortId: 'a1b2c3d4e5f6', name: 'app-web-1', image: 'app:2026.09.07', state: 'running', health: 'healthy', status: 'Up 3 days', ports: [{ hostPort: 8080, containerPort: 8080, protocol: 'tcp' }], createdAt: null, runningFor: 'Up 3 days', composeProject: 'app', composeService: 'web' },
    { id: 'b2c3d4e5f6a7b8c9d0e1', shortId: 'b2c3d4e5f6a7', name: 'app-worker-1', image: 'app:2026.09.07', state: 'running', health: null, status: 'Up 3 days', ports: [], createdAt: null, runningFor: 'Up 3 days', composeProject: 'app', composeService: 'worker' },
    { id: 'c3d4e5f6a7b8c9d0e1f2', shortId: 'c3d4e5f6a7b8', name: 'postgres', image: 'postgres:16-alpine', state: 'running', health: 'healthy', status: 'Up 5 days', ports: [{ hostPort: 5432, containerPort: 5432, protocol: 'tcp' }], createdAt: null, runningFor: 'Up 5 days', composeProject: null, composeService: null },
    { id: 'd4e5f6a7b8c9d0e1f2a3', shortId: 'd4e5f6a7b8c9', name: 'redis', image: 'redis:7-alpine', state: 'exited', health: null, status: 'Exited (0) 2 hours ago', ports: [], createdAt: null, runningFor: '', composeProject: null, composeService: null },
  ]
  const dockerRoute = (path, body) => {
    if (path === '/config') return { ok: true, config: window.__PREVIEW_DOCKER_CONFIG }
    if (path === '/targets') return { ok: true, targets: DOCKER_TARGETS }
    if (path === '/containers') return { ok: true, containers: window.__PREVIEW_DOCKER_CONTAINERS }
    if (path === '/images') return { ok: true, images: [
      { id: 'sha256:11aa', shortId: '11aa22bb33cc', tags: ['app:2026.09.07'], size: 184320000, createdAt: null, createdSince: '2 days ago' },
      { id: 'sha256:22bb', shortId: '22bb33cc44dd', tags: ['postgres:16-alpine'], size: 42000000, createdAt: null, createdSince: '3 weeks ago' },
    ] }
    // 详情形状按宿主 /inspect 的真实返回补齐：缺字段会让「概览」页在渲染期崩掉
    // （detail.mounts.length 之类），预览也就看不到日志/概览页
    if (path === '/inspect') {
      const base = window.__PREVIEW_DOCKER_CONTAINERS[0]
      return { ok: true, details: [{
        ...base,
        startedAt: '2026-09-06 04:11:22 +0800 CST',
        finishedAt: null,
        exitCode: null,
        restartCount: 0,
        restartPolicy: 'unless-stopped',
        pid: 48213,
        healthLogTail: null,
        mounts: [{ source: '/srv/app', destination: '/app', readWrite: true }],
        networks: [{ name: 'app_default', ip: '172.20.0.7' }],
        entrypoint: 'docker-entrypoint.sh',
        command: 'node server.js',
        workingDir: '/app',
        user: 'node',
      }] }
    }
    // /logs 的真实响应形状是 { id, text, truncated }（见 dsh-docker 宿主 /logs 路由）；
    // 早先这里回的是裸字符串，客户端 logs.text 拿到 undefined 直接崩掉整面板
    if (path === '/logs') return { ok: true, logs: {
      id: body && body.id ? body.id : 'app-web-1',
      truncated: false,
      text: '2026-09-09T12:00:00Z INFO  server listening on :8080\n2026-09-09T12:00:01Z INFO  connected to postgres\n2026-09-09T12:00:02Z WARN  slow query 412ms\n2026-09-09T12:00:03Z INFO  request GET /health 200 3ms\n',
    } }
    if (path === '/stats') return { ok: true, stats: [null] }
    return { ok: true }
  }

  const realFetch = window.fetch ? window.fetch.bind(window) : null
  window.fetch = (url, init) => {
    const target = typeof url === 'string' ? url : String(url && url.url ? url.url : url)
    if (target.indexOf('/api/dsh-tty/') === -1 && target.indexOf('/api/dsh-docker/') === -1) {
      return realFetch ? realFetch(url, init) : json({ ok: true })
    }
    let body = null
    try {
      body = init && typeof init.body === 'string' ? JSON.parse(init.body) : null
    } catch {
      body = null
    }
    return json(route(target, body))
  }

  /* ---------- 假 WebSocket：本地 spawn/ssh 回 ready，并投喂演示输出 ---------- */
  const SESSIONS = []
  class MockSocket extends EventTarget {
    static CONNECTING = 0
    static OPEN = 1
    static CLOSING = 2
    static CLOSED = 3
    constructor(url) {
      super()
      this.url = url
      this.readyState = MockSocket.CONNECTING
      this.onopen = null
      this.onmessage = null
      this.onclose = null
      this.onerror = null
      window.__mockSockets.push(this)
      setTimeout(() => {
        if (this.readyState !== MockSocket.CONNECTING) return
        this.readyState = MockSocket.OPEN
        if (typeof this.onopen === 'function') this.onopen({})
      }, 0)
    }
    addEventListener(type, fn, opts) {
      super.addEventListener(type, fn, opts)
    }
    removeEventListener(type, fn, opts) {
      super.removeEventListener(type, fn, opts)
    }
    _deliver(msg) {
      window.__mockLog.push('out:' + msg.t + (msg.d ? '(' + msg.d.length + ')' : ''))
      const event = new MessageEvent('message', { data: JSON.stringify(msg) })
      if (typeof this.onmessage === 'function') this.onmessage(event)
      this.dispatchEvent(event)
    }
    send(raw) {
      let msg
      try {
        msg = JSON.parse(raw)
      } catch {
        return
      }
      window.__mockLog.push('in:' + msg.t)
      // D79：留完整帧（不只类型）——「后台标签不得发出退化尺寸的 resize」这类断言要读 cols/rows
      window.__mockFrames.push(msg)
      const sid = msg.sid
      if (msg.t === 'spawn' || msg.t === 'ssh') {
        if (!SESSIONS.some((s) => s.sid === sid)) SESSIONS.push({ sid, attachable: true, kind: msg.t === 'ssh' ? 'ssh' : 'local', tmux: msg.persistName })
        const target = msg.t === 'ssh' ? (msg.username || 'deploy') + '@' + (msg.host || '198.51.100.20') + (msg.port && Number(msg.port) !== 22 ? ':' + msg.port : '') : undefined
        setTimeout(() => {
          this._deliver(msg.t === 'ssh'
            ? { t: 'ready', sid, kind: 'ssh', pid: null, target: msg.name ? target : target, persist: msg.persist === true }
            : { t: 'ready', sid, kind: 'local', pid: 48213, persist: msg.persist === true })
          setTimeout(() => this._deliver({ t: 'data', sid, d: msg.t === 'ssh' ? window.__PREVIEW_SSH_BANNER : window.__PREVIEW_BANNER }), 10)
        }, 20)
        return
      }
      if (msg.t === 'attach') {
        setTimeout(() => {
          this._deliver({ t: 'ready', sid, kind: 'local', pid: 48213, reattached: true })
          setTimeout(() => this._deliver({ t: 'data', sid, d: window.__PREVIEW_BANNER }), 10)
        }, 20)
        return
      }
      if (msg.t === 'sessions') {
        // D79 夹具：`window.__PREVIEW_AGENT_SESSIONS` = 真实宿主推的「agent 开的会话」
        // （owner:'agent'，客户端采纳成标签但不 switchTab ⇒ 它一直在后台）。
        const agentSessions = Array.isArray(window.__PREVIEW_AGENT_SESSIONS) ? window.__PREVIEW_AGENT_SESSIONS : []
        // D85 夹具：`window.__PREVIEW_EXITED_SESSIONS` = 宿主的**只读保留态**（进程已退出、
        // 带 `exited: true`；D77 起这种条目会在 sessions 帧里一直留着，最多 16 条）。
        // 它们不占并发名额，客户端的上限预检也不能数它们。
        const exitedSessions = Array.isArray(window.__PREVIEW_EXITED_SESSIONS) ? window.__PREVIEW_EXITED_SESSIONS : []
        const list = window.__PREVIEW_AT_LIMIT
          ? [{ sid: 'other-1', attachable: true }, { sid: 'other-2', attachable: true }, { sid: 'other-3', attachable: true }, { sid: 'other-4', attachable: true }]
          : SESSIONS.slice().concat(agentSessions, exitedSessions)
        setTimeout(() => this._deliver({ t: 'sessions', list }), 5)
        return
      }
      if (msg.t === 'input') {
        // 演示用：回车回一个新提示符，普通字符回显
        if (typeof msg.d === 'string') {
          if (msg.d === '\r' || msg.d === '\n') setTimeout(() => this._deliver({ t: 'data', sid, d: '\r\n\x1b[38;2;122;162;247m❯\x1b[0m ' }), 15)
          else if (!msg.d.includes('\u0003')) setTimeout(() => this._deliver({ t: 'data', sid, d: msg.d }), 5)
        }
        return
      }
      if (msg.t === 'statsOn') {
        // 与真实宿主同语义：宿主的订阅路由要求本连接上已有该 sid（会话已 ready）。
        // 客户端若在 spawn 之前/之后就绪没重发，这里就什么都不回——状态条不出来。
        if (!SESSIONS.some((entry) => entry.sid === sid)) {
          window.__mockLog.push('in:statsOn(unknown)')
          return
        }
        // 服务器状态条（0.17.0）：立刻回一帧再每秒推一帧，数值轻微浮动（截图里能看出"在动"）
        this._statsSid = sid
        this._statsTick = 0
        if (this._statsTimer) clearInterval(this._statsTimer)
        // 每核：16 个核各有相位，截图里能看出「有的忙、有的闲」
        const makeCores = (tick) => {
          const list = []
          for (let i = 0; i < 16; i += 1) {
            const wave = Math.abs(Math.sin((tick + i * 2.7) / 3.4))
            list.push(Math.max(1, Math.round(8 + wave * 84)))
          }
          return list
        }
        // 路径写成 macOS 的形状：真实 `ps comm` 给的是完整可执行文件路径，
        // 卡片要显示文件名（夹具里也这么写，预览才验得到截断逻辑）
        /*
         * 两条**同前缀、只有尾部不同**的超长名字：真实 macOS 上一串
         * `Framework Helper (Renderer) / (GPU) / (Plugin)` 就是这样，纯尾部省略号会把它们
         * 截成同一个 `Framew…`，而首尾截断要保住能区分它们的 `(GPU)` / `(Renderer)`。
         * 名字刻意给到 60+ 字符，保证在 720px 卡片里一定放不下（预览才验得到截断）。
         */
        const makeProcs = (tick) => ([
          { pid: 431, cmd: '/opt/homebrew/bin/node', cpuPct: Math.round((12.4 + (tick % 4) * 1.7) * 10) / 10, memPct: 4.2 },
          { pid: 88, cmd: '/usr/local/bin/dockerd', cpuPct: Math.round((5.1 + (tick % 3) * 0.9) * 10) / 10, memPct: 2.8 },
          { pid: 1022, cmd: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', cpuPct: 3.4, memPct: 7.8 },
          { pid: 76, cmd: '/opt/homebrew/opt/postgresql@16/bin/postgres', cpuPct: 0.9, memPct: 6.4 },
          { pid: 2201, cmd: '/System/Library/Frameworks/WebKit.framework/Versions/A/XPCServices/com.apple.WebKit.WebContent.xpc/Contents/MacOS/com.apple.WebKit.WebContent (Renderer)', cpuPct: 2.2, memPct: 3.1 },
          { pid: 2202, cmd: '/System/Library/Frameworks/WebKit.framework/Versions/A/XPCServices/com.apple.WebKit.WebContent.xpc/Contents/MacOS/com.apple.WebKit.WebContent (GPU)', cpuPct: 1.4, memPct: 1.9 },
        ])
        const push = () => {
          this._statsTick += 1
          const tick = this._statsTick
          // 坏帧注入（stats-broken 场景）：字符串 / 数组 / null / 越界值轮流来
          const junk = window.__PREVIEW_STATS_PAYLOAD
          if (Array.isArray(junk) && junk.length > 0) {
            this._deliver({ t: 'stats', sid, stats: junk[(tick - 1) % junk.length] })
            return
          }
          /*
           * 低频字段（2026-10-31）：真实宿主**不是每帧都带** `cpuCores` / `procs`——
           * SSH 远端的常驻 awk 把 `ps` 压到 5 拍一次（`tick % 5 == 1`），本地 `os.cpus()`
           * 的差值窗口也是第二帧才有。`__PREVIEW_STATS_SPARSE = 5` 复现「每 5 帧才带一次
           * procs」，用来验「缺席的帧不能把进程卡片打回『暂无进程数据』」（用户报的
           * 「一闪一闪」）。
           */
          const sparse = Number(window.__PREVIEW_STATS_SPARSE) || 0
          const withProcs = sparse <= 1 || tick % sparse === 1
          /*
           * 常态 18~54%，每 9 帧来一次尖峰（78% → 橙，96% → 红）：截图里能看出
           * 「超过阈值换色」这条档位逻辑真的在跑，而不是只有一条绿线。
           * `__PREVIEW_STATS_LOAD` 把总量钉死在一个值上（stats-alert 场景要验 80% 那条
           * 虚线两侧的换色 + 跌回绿，用自动上下的曲线断言不了时序）。
           */
          const forcedLoad = Number(window.__PREVIEW_STATS_LOAD)
          const cpuPct = Number.isFinite(forcedLoad) ? forcedLoad : tick % 9 === 0 ? 96 : tick % 5 === 0 ? 78 : 18 + (tick % 5) * 9
          const frame = {
            cpuPct,
            cores: 16,
            memUsed: Math.round(53.3e9 + (tick % 3) * 0.9e9),
            memTotal: 64e9,
            memPct: Math.round((83.2 + (tick % 3) * 1.4) * 10) / 10,
            diskUsed: 40.8e9,
            diskTotal: 68.8e9,
            diskPct: 59.3,
            uptimeSec: 2 * 604800 + 4 * 86400 + 7 * 3600 + 16 * 60 + tick,
            tcpConns: 570 + (tick % 7),
            rxRate: (58 + (tick % 7) * 17.5) * 1024,
            txRate: (34 + (tick % 5) * 11.5) * 1024,
            // tempC 缺席：走「CPU温度 无」的降级渲染（与 macOS 本机一致）
            // 明细仪表盘：每核 + Top 进程（宿主真实采集是可选字段，这里给 16 核的形状）
            cpuCores: makeCores(tick),
          }
          if (withProcs) frame.procs = makeProcs(tick)
          this._deliver({ t: 'stats', sid, stats: frame })
        }
        push()
        // 推送间隔可调（stats-slow 场景用 4s 复现「宿主采样慢」：D50 里那台 macOS
        // 的 netstat -ib 挂 3s、帧间隔被拉到 4s，旧的 3s 陈旧窗口于是每 4 秒闪一次）
        this._statsTimer = setInterval(push, Number(window.__PREVIEW_STATS_INTERVAL_MS) || 1000)
        return
      }
      if (msg.t === 'statsOff') {
        if (this._statsTimer) {
          clearInterval(this._statsTimer)
          this._statsTimer = null
        }
        return
      }
      if (msg.t === 'kill') {
        const idx = SESSIONS.findIndex((s) => s.sid === sid)
        if (idx >= 0) SESSIONS.splice(idx, 1)
      }
    }
    close() {
      if (this._statsTimer) {
        clearInterval(this._statsTimer)
        this._statsTimer = null
      }
      this.readyState = MockSocket.CLOSED
      if (typeof this.onclose === 'function') this.onclose({ code: 1000, wasClean: true })
    }
  }
  window.__mockSockets = []
  window.__mockLog = []
  window.__mockFrames = []
  /**
   * 宿主侧会话表的只读快照：预览场景要自己造 `sessions` 帧时用它当基准（#7④ 要逐帧改变
   * 清单——先有这条 agent 会话、下一帧它出表）。返回副本：场景改它不该影响宿主。
   */
  window.__mockSessionList = () => SESSIONS.map((entry) => ({ ...entry }))
  window.WebSocket = MockSocket

  /* ---------- module loader ---------- */
  window.__modules = new Map()
  window.__ModuleLoader__ = {
    load(def) {
      window.__modules.set(def.id, def)
      // 兼容：夹具最早只跑 tty 一个插件
      if (def.id === '@hyzyn/dsh-tty') window.__ttyModule = def
    },
  }

  window.__PREVIEW_SSH_BANNER =
    '\x1b[38;2;110;118;129mWelcome to Ubuntu 24.04.1 LTS (GNU/Linux 6.8.0-45-generic aarch64)\x1b[0m\r\n' +
    '\x1b[38;2;110;118;129mLast login: Mon Sep  8 12:38:52 2026 from 198.51.100.7\x1b[0m\r\n' +
    '\x1b[38;2;126;206;153mdeploy@prod-web-01\x1b[0m:\x1b[38;2;122;162;247m~/app\x1b[0m$ docker compose ps\r\n' +
    '\x1b[38;2;110;118;129mNAME                IMAGE               STATUS          PORTS\x1b[0m\r\n' +
    'app-web-1           app:2026.09.07      \x1b[38;2;126;206;153mUp 3 days\x1b[0m       0.0.0.0:8080->8080/tcp\r\n' +
    'app-worker-1        app:2026.09.07      \x1b[38;2;126;206;153mUp 3 days\x1b[0m\r\n' +
    '\x1b[38;2;126;206;153mdeploy@prod-web-01\x1b[0m:\x1b[38;2;122;162;247m~/app\x1b[0m$ '

  window.__PREVIEW_BANNER =
    '\x1b[38;2;110;118;129mLast login: Mon Sep  8 12:41:07 on ttys003\x1b[0m\r\n' +
    '\x1b[38;2;122;162;247m~/projects/demo-app\x1b[0m \x1b[38;2;158;206;106mpnpm\x1b[0m -r build\r\n' +
    '\x1b[38;2;97;175;239mpackages/tty build$\x1b[0m tsc -p tsconfig.json && node scripts/build-client.mjs\r\n' +
    '  client-src/index.js  \x1b[38;2;229;192;123m486.2kb\x1b[0m  \x1b[38;2;110;118;129m⟳\x1b[0m 200ms\r\n' +
    '\x1b[38;2;152;195;121m[dsh-tty] client.js built\x1b[0m\r\n' +
    '\x1b[38;2;110;118;129mDone in 1.8s\x1b[0m\r\n' +
    '\x1b[38;2;122;162;247m~/projects/demo-app\x1b[0m \x1b[38;2;122;162;247m❯\x1b[0m '
})()
