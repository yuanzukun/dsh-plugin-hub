#!/usr/bin/env node
/**
 * @hyzyn/dsh-tty — 视觉预览 / 截图回归工具。
 *
 * 把 packages/tty/client.js 装进一个纯静态夹具页（scripts/preview/harness.html，
 * 内含伪造的 DSH 宿主：module loader / fetch / WebSocket），用 headless Chrome
 * 逐个场景渲染并截图到 .preview/shots/，用于改样式时的视觉走查。
 *
 * 用法：
 *   node scripts/preview.mjs                    # 全场景截图
 *   node scripts/preview.mjs local multi        # 指定场景
 *   node scripts/preview.mjs --list             # 列出场景
 *   node scripts/preview.mjs --build            # 顺带重建 client.js（默认不重建，产物落后直接报错）
 *   node scripts/preview.mjs --theme=light      # 浅色主题
 *   node scripts/preview.mjs --width=560        # 压窄视口走查窄容器排版（默认 1680）
 *   node scripts/preview.mjs --height=560       # 压矮视口走查「内容溢出时头尾还固不固定」（默认 1050）
 *   PREVIEW_CHROME_ARGS=--no-sandbox node scripts/preview.mjs   # 受限沙箱 / CI 里 Chrome 起不来时
 *
 * 需要本机有 Chrome/Chromium（默认找 playwright 缓存的 Chrome for Testing，
 * 也可用 CHROME_PATH 指定）。
 */
import { spawn } from 'node:child_process'
import { createRequire } from 'node:module'
import { existsSync, mkdirSync, readFileSync, writeFileSync, rmSync, readdirSync, statSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { homedir, tmpdir } from 'node:os'
import { describeChromeSearch, findChrome, playwrightChromeCandidates } from '../../../scripts/chrome-path.mjs'

const require = createRequire(import.meta.url)
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const previewDir = join(root, '.preview')

const argv = process.argv.slice(2)
const flags = new Set(argv.filter((a) => a.startsWith('--')))
const positional = argv.filter((a) => !a.startsWith('--'))
const theme = (argv.find((a) => a.startsWith('--theme=')) || '--theme=dark').split('=')[1]
// 默认不再重建（0.19.0）：此前隐式跑 build 会悄悄改掉必须入库的 client.js。
// 需要重建时显式 `--build`；产物落后于源码时直接报错，绝不「对着旧产物截图」。
const wantBuild = flags.has('--build')
/** 输出子目录：--out=shots-light 之类，便于并排比较明暗主题。 */
const outName = (argv.find((a) => a.startsWith('--out=')) || '--out=shots').split('=')[1]
const shotsDir = join(previewDir, outName)
/**
 * 视口宽度（默认 1680）。真实宿主里这张卡片常挂在窄容器里（插件管理页 / 侧栏），
 * 1680px 的宽视口会把「一行塞不塞得下」这类排版问题盖掉——走查窄排版时用
 * `--width=560` 之类显式压窄。
 */
const viewportWidth = Number((argv.find((a) => a.startsWith('--width=')) || '--width=1680').split('=')[1]) || 1680
/**
 * 视口高度（默认 1050）。**与连接对话框的「头尾固定」直接相关**：那张卡片是
 * `max-height: 86vh`，矮视口下内容才会溢出中段——1050px 高时展开态刚好塞得下，
 * 「滚到底头尾还在不在」这条断言就永远走不到。走查时用 `--height=560` 压矮。
 */
const viewportHeight = Number((argv.find((a) => a.startsWith('--height=')) || '--height=1050').split('=')[1]) || 1050
/**
 * 额外 Chrome 参数（空格分隔）。受限环境（文件沙箱 / CI 容器）里 Chrome 自己的
 * sandbox 起不来，CDP 会一直卡在 `Page.enable` 直到超时——此时用
 * `PREVIEW_CHROME_ARGS=--no-sandbox`。刻意不做默认：那会削弱所有调用方的隔离。
 */
const extraChromeArgs = (process.env.PREVIEW_CHROME_ARGS ?? '').split(' ').filter((a) => a !== '')

/* ------------------------------- 场景清单 ------------------------------- */

const SCENARIOS = [
  ['local', '单标签本地终端'],
  ['stats-off', '服务器状态条关闭（整条收起）'],
  ['stats-broken', '服务器状态条坏数据兜底（不崩、不变形）'],
  ['stats-slow', '服务器状态条：宿主采样慢（4s 一帧）时不能整条消失又出现'],
  ['stats-minimal', '服务器状态条：极简模式（CPU / 内存 / 网络 + 趋势线，条上切换）'],
  ['stats-minimal-noping', '服务器状态条：没有 Ping / Swap 的机器（两格整格隐藏）'],
  ['stats-dashboard', '服务器状态条：明细仪表盘（悬浮卡片：每核 / 网络 / 进程）'],
  ['stats-tip', '服务器状态条：条目悬停卡片（当前 / 近 1 分钟峰值 / 上下文）'],
  ['stats-tip-net', '服务器状态条：网络格的悬停卡片（↓/↑ 分段着色）'],
  ['stats-extra', '服务器状态条：右侧的「负载 / 时钟」（时钟走自己的 1s 定时器）'],
  ['stats-sparse', '服务器状态条：低频字段（每 5 拍才带一次进程）时进程卡片不能闪'],
  ['multi', '多标签 + SSH 连接栏'],
  ['menu', '「+」新建菜单'],
  ['ssh', 'SSH 连接对话框'],
  ['ssh-probe', 'SSH 连接对话框（试连结果）'],
  ['ssh-edit', 'SSH 连接对话框（编辑）'],
  ['ssh-save-book', 'SSH 连接对话框：连接簿名称行常显 + 填名字自动勾上'],
  ['ssh-adv', 'SSH 连接对话框：「高级」展开 + 中段滚动（头尾固定）'],
  ['ssh-jump', 'SSH 连接对话框：配过高级项的条目默认展开折叠区'],
  ['settings', '设置卡片'],
  ['settings-assist', '设置卡片：AI 辅助小节（默认关 + 模型路由一个控件）'],
  ['settings-shell', '设置卡片：Shell 路径候选表（浮层，不顶动卡片布局）'],
  ['settings-docker', '设置卡片（docker 与 tty 并排对照）'],
  ['docker-stale-book', 'docker 设置卡片：失效的连接簿引用要看得出来'],
  ['tunnel-edit', '端口转发：编辑隧道（回填 / 改端口换名 / 停用的不被启用）'],
  ['port-warn', '端口转发：保存时宿主报端口占用（警告档，不是成功也不是失败）'],
  ['sftp', 'SFTP 单窗体（挂右侧挂载位）'],
  ['sftp-dual', 'SFTP 双栏（挂右侧挂载位）'],
  ['sftp-fallback', 'SFTP 落点回退（抽屉被容器面板占用 → 对话框）'],
  ['dock-pane-tab', '挂载位跟着标签切（切走收起 / 切回恢复 / 不堵死另一个标签的入口）'],
  ['minimized', '最小化（侧边栏徽标）'],
  ['exited', '会话退出：不遮输出 + 顶部提示条（issue #7①②）'],
  ['clean-exited', '「⋯」里的「清理已退出的标签」（issue #7③）'],
  ['clean-exited-apply', '「清理已退出的标签」点下去之后（issue #7③）'],
  ['agent-release', 'AI 释放会话 → 标签跟着走（后台当场收 / 正在看的留一台阶，issue #7④）'],
  ['agent-release-neighbor', 'AI 释放「被客户端顶上去」的活动标签 → 仍直接收走（4b 现场回归）'],
  ['close-confirm', '关面板二次确认：有活会话先问一句（issue #8）'],
  ['close-confirm-empty', '关面板二次确认：只剩已退出的标签就不问（issue #8）'],
  ['error', '连接错误遮罩'],
  ['tunnel', '隧道状态弹层'],
  ['connbar-more', '连接栏「⋯」更多（没配隧道的连接也能找到端口转发入口）'],
  ['conn-detail', '连接栏地址 → 连接详情弹层（目标 / 跳板机 / 持久化）+ 两个复制项'],
  ['search', '搜索框展开'],
  ['toast', 'toast 提醒'],
  ['embed', '嵌入式终端（ttyTerminal.mount）'],
  ['embed-panel', '嵌入终端与面板共存（关面板不掉线）'],
  ['docker-panel', 'docker 面板（只读：变更组整组置灰）'],
  ['docker-panel-rw', 'docker 面板（允许变更：动作条全可用）'],
  ['docker-exec', 'docker 面板 → 终端抽屉（端到端）'],
  ['docker-exec-logs', 'docker 面板 → 终端抽屉 + 日志页（折叠保留会话）'],
  ['dock-pane', '终端面板右侧挂载位（ttyPanel 骨架）'],
  ['dock-pane-bottom', '底部挂载位 + 终端重排（视口钉底）'],
  ['docker-dock', '连接栏「容器」→ docker 面板挂进右侧 dock（终端不被盖住）'],
  ['resize-hidden', '后台标签的 PTY 不得被压成 2×2（D79）'],
  ['limit-retained', '只读保留（已退出）的会话不算并发名额（D85）'],
  ['tab-add', '「+」贴着页签，且标签栏溢出时不跟着滚走（D89）'],
  ['tab-list', '标签栏溢出：「⋯」标签列表（切/关/Esc，0.23.0）'],
  ['tab-bulk-menu', '标签 ≥ 2 个时的「⋯」批量入口（关闭其他 / 左侧 / 右侧，0.29.0）'],
  ['tab-context-menu', '标签右键菜单：以这个标签为参照（0.29.0）'],
  ['tab-context-close-others', '右键「关闭其他标签」→ 活会话 ≥ 2 先确认（0.29.0）'],
  ['tab-mid-click', '中键关标签（与 ✕ 同一条路，不问，0.29.0）'],
  ['tty-assist', 'AI 辅助「失败即解释」：徽标 → 答案 → 填入不回车（0.24.0）'],
]

if (flags.has('--list')) {
  for (const [name, label] of SCENARIOS) console.log(name.padEnd(12), label)
  process.exit(0)
}

const wanted = positional.length > 0 ? positional : SCENARIOS.map(([n]) => n)
for (const name of wanted) {
  if (!SCENARIOS.some(([n]) => n === name)) {
    console.error('未知场景：' + name + '（--list 查看可用场景）')
    process.exit(1)
  }
}

/* ------------------------------ 夹具准备 ------------------------------ */

function log(msg) {
  process.stdout.write('[preview] ' + msg + '\n')
}

async function buildClient() {
  await new Promise((res, rej) => {
    const child = spawn(process.execPath, [join(root, 'scripts/build-client.mjs')], { cwd: root, stdio: 'inherit' })
    child.on('exit', (code) => (code === 0 ? res() : rej(new Error('build-client 退出码 ' + code))))
  })
}

/** 下载 React 18 UMD（只做一次，缓存在 .preview/vendor）。 */
async function ensureVendor() {
  const dir = join(previewDir, 'vendor')
  mkdirSync(dir, { recursive: true })
  const targets = [
    ['react.js', 'https://unpkg.com/react@18.3.1/umd/react.production.min.js'],
    ['react-dom.js', 'https://unpkg.com/react-dom@18.3.1/umd/react-dom.production.min.js'],
  ]
  for (const [file, url] of targets) {
    const dest = join(dir, file)
    if (existsSync(dest)) continue
    log('下载 ' + file)
    const res = await fetch(url)
    if (!res.ok) throw new Error('下载 ' + url + ' 失败：HTTP ' + res.status)
    writeFileSync(dest, Buffer.from(await res.arrayBuffer()))
  }
}

/** 皮肤变量：优先用本机 skin-center 的真实 token 表，找不到则用内置兜底。 */
function skinCss() {
  const candidates = []
  const skinsRoot = join(homedir(), '.dsh/profiles/web/node_modules/@linxin666/dsh-client-ui-skin-center/skins')
  if (existsSync(skinsRoot)) {
    for (const name of readdirSync(skinsRoot)) {
      const file = join(skinsRoot, name, 'skin.css')
      if (existsSync(file)) candidates.push(file)
    }
  }
  // 基础层**始终**在前：它住在宿主的 base.css / focus.css / corner-shape.css 里，
  // 真皮肤表里没有这些名字（实测 blue-fantasy 一条都不含）。
  if (candidates.length > 0) return BASE_LAYER_CSS + '\n' + readFileSync(candidates[0], 'utf8')
  log('未找到本机 skin token 表，使用内置兜底变量')
  return BASE_LAYER_CSS + '\n' + FALLBACK_SKIN_CSS
}

/**
 * 宿主基础层：圆角阶梯、卡片材质、焦点环、全局超椭圆。
 *
 * 值取自 `@deepseek-ai/dsh-client-ui-theme` 的 `base.css` / `focus.css` / `corner-shape.css`
 * ——**名字与值都必须与真主题逐字一致**：夹具里缺一个名字的代价是「预览是对的、只有真机是错的」
 * （卡片改走 `--dsw-radius-xl` 后，缺了它圆角算成 0，而真机是 20px）。
 * 真皮肤表只有「皮肤」那一层，基础层必须由这里补。
 *
 * 本包 client-src 引用的**每一个** --dsw-* 都必须在这里（或真皮肤表里）能解析出值：生产 CSS
 * 已按 client-lint 检查十六去掉所有颜色字面量兜底，假主题就是「脱离宿主」时唯一的兜底。
 */
const BASE_LAYER_CSS = `
:root{
  --dsw-radius-xs:4px; --dsw-radius-sm:8px; --dsw-radius-md:12px; --dsw-radius-lg:16px; --dsw-radius-xl:20px;
  --dsw-radius-panel:28px;
  --dsw-alias-settings-card-fill:var(--dsw-alias-bg-layer-2);
  --dsw-alias-settings-card-stroke:var(--dsw-alias-border-l4);
  --dsw-focus-ring-width:2px;
  /* 宿主 focus.css 只声明宽度，颜色走 var(--dsw-focus-ring-color, var(--dsw-alias-state-business-primary))
     —— 这里按宿主那条兜底表达式把「最近语义令牌」补上，别写死某个蓝。 */
  --dsw-focus-ring-color:var(--dsw-alias-state-business-primary);
}
/* elevation 与宿主 gradient-shadow-text.css 逐字相同，且必须声明在 body 上（不是 :root）：
   它内含 var(--dsw-elevation-stroke-color) → var(--dsw-alias-border-l4)，在 :root 上求值就
   钉死了浅色档，深色主题下描边色不会跟着走。 */
body, body *{
  --dsw-elevation-stroke-color:var(--dsw-alias-border-l4);
  --dsw-elevation-stroke:0 0 0 .5px var(--dsw-elevation-stroke-color);
  --dsw-elevation-panel:var(--dsw-elevation-stroke), 0 3px 8px 0 #00000008, 0 0 16px 0 #00000005;
  --dsw-elevation-prominent:var(--dsw-elevation-stroke), 0 3px 8px 0 #0000000a, 0 0 20px 0 #0000000d;
}
@supports (corner-shape:superellipse(1.5)){:root{--dsw-corner-shape:superellipse(1.5)}*,:before,:after{corner-shape:var(--dsw-corner-shape)}}
`

const FALLBACK_SKIN_CSS = `
:root {
  --dsw-alias-bg-base: #ffffff;
  --dsw-alias-bg-layer-1: #f6f7f9;
  --dsw-alias-bg-layer-2: #eef0f4;
  --dsw-alias-bg-layer-3: #e5e8ee;
  --dsw-alias-bg-mask-1: #00000059;
  --dsw-alias-bg-overlay: #fffffff0;
  --dsw-alias-border-l1: #00000014;
  --dsw-alias-border-l2: #00000024;
  --dsw-alias-border-l3: #00000038;
  --dsw-alias-border-l4: #0000004d;
  --dsw-alias-interactive-bg-hover: #0000000f;
  --dsw-alias-interactive-bg-active: #0000001f;
  --dsw-alias-interactive-bg-hover-danger: #c000000f;
  --dsw-alias-label-primary: #0f1115;
  --dsw-alias-label-secondary: #4b5158;
  --dsw-alias-label-tertiary: #767c85;
  --dsw-alias-label-dimmed: #9aa0a8;
  --dsw-alias-label-primary-inverted: #ffffff;
  --dsw-alias-brand-primary: #4d6bfe;
  --dsw-alias-state-business-primary: #4d6bfe;
  --dsw-alias-state-error-primary: #d1242f;
  --dsw-alias-state-success-primary: #1a7f37;
  --dsw-alias-state-warn-primary: #bf8700;
  --dsw-alias-button-primary-fill: #0f1115;
  --dsw-alias-button-primary-hover: #43454a;
  --dsw-alias-interactive-bg-hover-solid: #f1f3f5;
  --dsw-alias-label-primary-foreground: #fff;
  --dsw-specific-input-major: #ffffff;
  --dsw-specific-menu: #ffffff;
  --dsw-specific-tip: #f6f7f9;
  --dsw-specific-sidebar-fill: #f2f3f5;
  --dsw-specific-sidebar-nav-item-hover: #0000000f;
  --dsw-specific-sidebar-nav-item-active: #0000001a;
  --dsw-alias-scrollbar-bg-l1: #d0d3d8;
  --dsw-alias-scrollbar-hover-l1: #b0b4ba;
  --dsw-shadow-lv3: 0 12px 32px -8px #0000002e;
}
body[data-ds-dark-theme] {
  --dsw-alias-bg-base: #1b1b1f;
  --dsw-alias-bg-layer-1: #202024;
  --dsw-alias-bg-layer-2: #26262b;
  --dsw-alias-bg-layer-3: #2d2d33;
  --dsw-alias-bg-mask-1: #0000008c;
  --dsw-alias-bg-overlay: #202024eb;
  --dsw-alias-border-l1: #ffffff14;
  --dsw-alias-border-l2: #ffffff26;
  --dsw-alias-border-l3: #ffffff3d;
  --dsw-alias-border-l4: #ffffff52;
  --dsw-alias-interactive-bg-hover: #ffffff14;
  --dsw-alias-interactive-bg-active: #ffffff24;
  --dsw-alias-interactive-bg-hover-danger: #ff6b6b1f;
  --dsw-alias-label-primary: #ececf1;
  --dsw-alias-label-secondary: #b4b4bd;
  --dsw-alias-label-tertiary: #8e8e99;
  --dsw-alias-label-dimmed: #6b6b75;
  --dsw-alias-label-primary-inverted: #101014;
  --dsw-alias-brand-primary: #7c9cff;
  --dsw-alias-state-business-primary: #7c9cff;
  --dsw-alias-state-error-primary: #ff6b6b;
  --dsw-alias-state-success-primary: #4cc38a;
  --dsw-alias-state-warn-primary: #e0a94a;
  --dsw-alias-button-primary-fill: #f9fafb;
  --dsw-alias-button-primary-hover: #ebeef2;
  --dsw-alias-interactive-bg-hover-solid: #353638;
  --dsw-alias-label-primary-foreground: #0f1115;
  --dsw-specific-input-major: #17171a;
  --dsw-specific-menu: #24242af0;
  --dsw-specific-tip: #24242a;
  --dsw-specific-sidebar-fill: #17171a;
  --dsw-specific-sidebar-nav-item-hover: #ffffff12;
  --dsw-specific-sidebar-nav-item-active: #ffffff1f;
  --dsw-alias-scrollbar-bg-l1: #3a3a42;
  --dsw-alias-scrollbar-hover-l1: #4d4d57;
  --dsw-shadow-lv3: 0 12px 32px -8px #000000a6;
}
`

function prepare() {
  mkdirSync(shotsDir, { recursive: true })
  for (const file of ['harness.html', 'harness.js', 'mock-host.js']) {
    writeFileSync(join(previewDir, file), readFileSync(join(root, 'scripts/preview', file)))
  }
  writeFileSync(join(previewDir, 'skin.css'), skinCss())
  writeFileSync(join(previewDir, 'client.js'), readFileSync(join(root, 'client.js')))
  // dsh-docker 的浏览器半体（可选）：在同一页面里跑「tty 提供服务 + docker 消费」的联调场景
  const dockerClient = join(root, '..', 'docker', 'client.js')
  if (existsSync(dockerClient)) writeFileSync(join(previewDir, 'docker-client.js'), readFileSync(dockerClient))
}

/* ------------------------------ Chrome/CDP ------------------------------ */

/*
 * 浏览器发现走仓库根的共享模块（`scripts/chrome-path.mjs`）：此前这里抄了一份
 * 「扫 playwright 缓存 → 退回平台候选」的实现，`packages/search` 那份与它**逐字相同**，
 * 两份都只在 macOS 上找得到浏览器（Linux 上必然抛「找不到 Chrome/Chromium」）。
 * playwright 缓存仍排在平台候选**之前**——缓存里那个 Chrome for Testing 版本确定，
 * 比机器上随便装的 Chrome 更适合当截图基准（顺序经 `extraCandidates` 原样保留）。
 */
function resolveChrome() {
  const found = findChrome({ extraCandidates: playwrightChromeCandidates })
  if (found === null) throw new Error('找不到 Chrome/Chromium：' + describeChromeSearch())
  return found
}

const WebSocketImpl = (() => {
  try {
    return require('ws')
  } catch {
    return null // 回退到 Node 内置 WebSocket
  }
})()

class Cdp {
  constructor(socket, kind) {
    this.socket = socket
    this.kind = kind
    this.id = 0
    this.pending = new Map()
    this.listeners = new Set()
    const handle = (raw) => {
      let msg
      try {
        msg = JSON.parse(typeof raw === 'string' ? raw : String(raw))
      } catch {
        return
      }
      if (msg.id !== undefined && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id)
        this.pending.delete(msg.id)
        if (msg.error) reject(new Error((msg.error && msg.error.message) || JSON.stringify(msg.error)))
        else resolve(msg.result)
        return
      }
      for (const fn of this.listeners) fn(msg)
    }
    if (kind === 'ws') socket.on('message', handle)
    else socket.addEventListener('message', (event) => handle(event.data))
  }

  static async connect(url) {
    if (WebSocketImpl !== null) {
      const socket = new WebSocketImpl(url, { perMessageDeflate: false })
      await new Promise((res, rej) => {
        socket.once('open', res)
        socket.once('error', rej)
      })
      return new Cdp(socket, 'ws')
    }
    const socket = new WebSocket(url)
    await new Promise((res, rej) => {
      socket.addEventListener('open', res, { once: true })
      socket.addEventListener('error', () => rej(new Error('CDP 连接失败')), { once: true })
    })
    return new Cdp(socket, 'node')
  }

  /*
   * `timeoutMs` 可调（2026-11-02）：截图会偶发卡到超时，那条路要能自己设短一点、早点重试，
   * 而不是陪着通用通道的 30s 一起干等。
   */
  send(method, params = {}, timeoutMs = 30000) {
    const id = ++this.id
    this.socket.send(JSON.stringify({ id, method, params }))
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject })
      setTimeout(() => {
        if (this.pending.has(id)) {
          this.pending.delete(id)
          reject(new Error('CDP 超时：' + method))
        }
      }, timeoutMs)
    })
  }

  on(fn) {
    this.listeners.add(fn)
    return () => this.listeners.delete(fn)
  }
}

async function launchChrome() {
  const chrome = resolveChrome()
  const userDataDir = join(previewDir, 'chrome-profile')
  rmSync(userDataDir, { recursive: true, force: true })
  const child = spawn(chrome, [
    '--headless=new',
    '--remote-debugging-port=0',
    '--user-data-dir=' + userDataDir,
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-extensions',
    '--disable-background-networking',
    '--disable-sync',
    '--disable-features=Translate,OptimizationGuideModelDownloading,MediaRouter',
    // 关掉 WebGL：xterm 的 WebglAddon 在无 GPU 的 headless 里会拿到一个画不出
    // 东西的上下文（不抛错 → 不会回退 DOM 渲染器），截图里终端永远空白
    '--disable-3d-apis',
    '--disable-webgl',
    /*
     * Chrome 自己的进程沙箱在**外层沙箱里起不来**（2026-10-31 实测：agent 的
     * workspace-write 沙箱内 CLI 起 headless Chrome，GPU/渲染进程一崩，DevTools
     * 连接开了就断——socket `open` 后立刻 `close 1006`，或 `Page.enable` 永远不回）。
     * 截图工具读的是本地夹具文件、不访问外网，关掉 Chrome 的沙箱换来可复现的截图。
     */
    '--no-sandbox',
    '--force-color-profile=srgb',
    '--font-render-hinting=none',
    ...extraChromeArgs,
    'about:blank',
  ], { stdio: ['ignore', 'ignore', 'pipe'] })

  const wsUrl = await new Promise((resolvePromise, reject) => {
    let buffer = ''
    const timer = setTimeout(() => reject(new Error('等待 Chrome DevTools 端口超时')), 25000)
    child.stderr.on('data', (chunk) => {
      buffer += String(chunk)
      const match = buffer.match(/DevTools listening on (ws:\/\/\S+)/)
      if (match) {
        clearTimeout(timer)
        resolvePromise(match[1])
      }
    })
    child.on('exit', (code) => {
      clearTimeout(timer)
      reject(new Error('Chrome 退出，code=' + code))
    })
  })

  // 直接连页面 target：省掉 Target.attachToTarget 的 session 路由，命令最简单
  const port = new URL(wsUrl).port
  const targets = await (await fetch('http://127.0.0.1:' + port + '/json/list')).json()
  const page = targets.find((t) => t.type === 'page')
  if (!page) throw new Error('Chrome 没有可用的页面 target')
  const cdp = await Cdp.connect(page.webSocketDebuggerUrl)
  await cdp.send('Page.enable')
  await cdp.send('Runtime.enable')
  return { child, cdp, userDataDir }
}

/* ------------------------------- 截图流程 ------------------------------- */

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

/** 截图单次尝试的 CDP 超时：比通道默认的 30s 短——真要卡住，早放弃才能早重试。 */
const SHOT_TIMEOUT_MS = 20000
/** 截图尝试次数（卡住的是那一帧、不是页面，所以重试一次；真挂了由下面的探活提前收敛）。 */
const SHOT_ATTEMPTS = 2

/**
 * 截图（2026-11-02）。`Page.captureScreenshot` 会偶发卡到 CDP 超时，一次就把整轮走查带走，
 * 而原始报错只有一句「CDP 超时：Page.captureScreenshot」——看不出卡在哪一场，也看不出渲染进程
 * 是真死了还是只是那一帧没来。
 *
 * 排查记录（2026-11-02）：一段窗口里连跑 5 次，5 次全卡在第 11 张截图上（`stats-sparse`；也试过
 * `--disable-gpu`，一样卡）。同一窗口里把 `client-src` 的改动 stash 回上一版同样复现，
 * `pnpm test` 与前面 10 个场景一直正常，跑完立刻查进程也没有残留 Chrome
 * （`--user-data-dir` 是固定路径 `.preview/chrome-profile`，起跑前会 `rmSync`，不存在多实例抢
 * profile）。隔了半小时后再连跑 6 次，全部通过。结论是**环境侧**的偶发：无头 Chrome 那一帧的
 * 合成迟迟不来，与本插件代码无关——但注释解释不掉「它下次又挂」这件事。
 *
 * 处置上不再当致命错误：卡住时先探一次渲染进程还活着没有，活着就重试一帧；两次都拿不到才失败，
 * 并把「哪一场 · 渲染进程是否响应 · 每次耗时」写清楚——下次它再出现时不用重新排查一遍。
 */
async function captureShot(cdp, name) {
  let last = null
  for (let attempt = 1; attempt <= SHOT_ATTEMPTS; attempt += 1) {
    const started = Date.now()
    try {
      const shot = await cdp.send(
        'Page.captureScreenshot',
        { format: 'png', captureBeyondViewport: false },
        SHOT_TIMEOUT_MS,
      )
      if (attempt > 1) log('   · ' + name + ' 重试拿到截图（' + String(Date.now() - started) + 'ms）')
      return shot
    } catch (error) {
      last = error
      // 探活：渲染进程还答得上话，说明是合成帧没来（重试有意义）；答不上来就是它挂了（重试没意义）
      const alive = await cdp
        .send('Runtime.evaluate', { expression: '1 + 1', returnByValue: true }, 3000)
        .then((result) => result?.result?.value === 2)
        .catch(() => false)
      log(
        '   · ' + name + ' 截图超时（第 ' + String(attempt) + '/' + String(SHOT_ATTEMPTS) +
        ' 次，' + String(Date.now() - started) + 'ms，渲染进程' + (alive ? '仍响应' : '无响应') + '）',
      )
      if (!alive) break
    }
  }
  throw new Error('截图失败（' + name + '）：' + String((last && last.message) || last))
}

async function shoot(cdp, name, label) {
  const problems = []
  const off = cdp.on((msg) => {
    if (msg.method === 'Runtime.exceptionThrown') {
      problems.push('异常：' + (msg.params.exceptionDetails.exception?.description || msg.params.exceptionDetails.text))
    } else if (msg.method === 'Runtime.consoleAPICalled' && msg.params.type === 'error') {
      problems.push('console.error：' + msg.params.args.map((a) => a.description || a.value).join(' '))
    }
  })
  try {
    const url = 'file://' + join(previewDir, 'harness.html') + '?scenario=' + encodeURIComponent(name) + '&theme=' + theme
      // 样例路径随机器变化：运行时注入，避免把开发者目录写进夹具源码
      + '&cwd=' + encodeURIComponent(root) + '&home=' + encodeURIComponent(homedir())
    await cdp.send('Page.navigate', { url })
    // 导航提交是异步的：必须等到新文档真的挂上了本次场景，否则会拿到上一个
    // 场景的 __previewReady（截图就会停在半成品状态）
    let ready = false
    for (let i = 0; i < 120; i += 1) {
      const probe = await cdp.send('Runtime.evaluate', {
        expression: 'window.__previewState ? window.__previewState.name : null',
        returnByValue: true,
      }).catch(() => null)
      if (probe?.result?.value === name) {
        ready = true
        break
      }
      await sleep(50)
    }
    if (!ready) problems.push('场景未挂载（导航超时）')
    const outcome = await cdp.send('Runtime.evaluate', {
      expression: 'window.__previewReady.then(() => ({ ok: true })).catch((e) => ({ ok: false, error: String((e && e.message) || e) }))',
      awaitPromise: true,
      returnByValue: true,
    })
    const value = outcome?.result?.value
    if (value && value.ok === false) problems.push('场景失败：' + value.error)
    /*
     * 场景可以挂一份**函数形态**的断言到 `window.__previewAssert`：返回 null 表示通过，
     * 返回字符串/数组表示失败（与各场景既有写法一致）。截图工具顺手把它跑掉——否则
     * 那些断言只有手工 CDP 取 diag 时才有人看，回归就白钉了。
     *
     * 单独发一条 evaluate：`window.__previewDiag()` 的返回值里带着函数
     * （`assert: window.__previewAssert`），和断言结果混在一个 `returnByValue` 里会
     * 让整条求值失败——那正是「断言看着跑了、其实一条都没生效」的由来。
     * 对象形态的 `__previewAssert`（纯数据快照，供人工比对）不在此列。
     */
    const check = await cdp.send('Runtime.evaluate', {
      expression: '(async () => {'
        + ' const a = window.__previewAssert;'
        + ' if (typeof a !== "function") return null;'
        + ' const r = await a();'
        + ' return Array.isArray(r) ? r.join("；") : (r == null ? null : String(r));'
        + '})()',
      awaitPromise: true,
      returnByValue: true,
    })
    if (check?.exceptionDetails !== undefined) {
      // 断言自己抛错（拼错选择器之类）也要算失败，不能悄悄变成「通过」
      problems.push('断言执行出错：' + String(check.exceptionDetails.exception?.description ?? JSON.stringify(check.exceptionDetails)))
    } else if (typeof check?.result?.value === 'string' && check.result.value !== '') {
      problems.push('断言未通过：' + check.result.value)
    }
    if (process.env.PREVIEW_DIAG) {
      const diag = await cdp.send('Runtime.evaluate', {
        expression: 'JSON.stringify({ ...window.__previewDiag(), assert: undefined })',
        returnByValue: true,
      })
      if (typeof diag?.result?.value === 'string') log('   · diag ' + diag.result.value)
    }
    await sleep(500)
    const shot = await captureShot(cdp, name)
    const file = join(shotsDir, name + '.png')
    writeFileSync(file, Buffer.from(shot.data, 'base64'))
    return { file, problems }
  } finally {
    off()
  }
}

/* --------------------------------- main --------------------------------- */

/** client-src/ 下最新源码的 mtime（递归一层足够）。 */
function newestSourceMtime() {
  let newest = 0
  const srcDir = join(root, 'client-src')
  for (const entry of readdirSync(srcDir)) {
    const st = statSync(join(srcDir, entry))
    if (st.isFile()) newest = Math.max(newest, st.mtimeMs)
  }
  return newest
}

async function main() {
  const artifact = join(root, 'client.js')
  if (wantBuild) {
    log('重新打包 client.js')
    await buildClient()
  } else {
    if (!existsSync(artifact)) {
      throw new Error('client.js 不存在：先跑 pnpm -r build，或用 --build 让 preview 重建')
    }
    if (newestSourceMtime() > statSync(artifact).mtimeMs) {
      throw new Error('client.js 落后于 client-src/：先跑 pnpm -r build，或用 --build 让 preview 重建（不再默认隐式重建）')
    }
  }
  prepare()
  await ensureVendor()
  log('启动 headless Chrome（' + theme + ' 主题）')
  const { child, cdp, userDataDir } = await launchChrome()
  await cdp.send('Emulation.setDeviceMetricsOverride', { width: viewportWidth, height: viewportHeight, deviceScaleFactor: 2, mobile: false })
  let failed = 0
  try {
    for (const name of wanted) {
      const label = SCENARIOS.find(([n]) => n === name)[1]
      const { file, problems } = await shoot(cdp, name, label)
      const mark = problems.length > 0 ? '✗' : '✓'
      log(mark + ' ' + name.padEnd(12) + label + '  →  ' + file.replace(process.cwd() + '/', ''))
      for (const p of problems) log('   ⚠ ' + p)
      if (problems.length > 0) failed += 1
    }
  } finally {
    child.kill('SIGTERM')
    // Chrome 收尾可能还在写 profile：清理失败不该让整轮截图算失败
    try {
      rmSync(userDataDir, { recursive: true, force: true })
    } catch {
      /* 下次运行会覆盖 */
    }
  }
  log('完成：' + (wanted.length - failed) + '/' + wanted.length + ' 场景正常，截图在 ' + shotsDir.replace(process.cwd() + '/', ''))
  if (failed > 0) process.exitCode = 1
}

main().catch((error) => {
  console.error('[preview] ' + (error && error.stack ? error.stack : error))
  process.exit(1)
})

