/**
 * @hyzyn/dsh-tty — 本地终端的启动计划：POSIX 与 **Windows** 两条分支。
 *
 * 为什么单独立一档：Windows 宿主的失败是「装得上、起得来、但一条终端都开不了」——
 *   1. `$SHELL` 在 Windows 上根本不存在，旧实现无条件回落 `/bin/zsh`，spawn 直接 ENOENT；
 *   2. 包装层是 POSIX 语法（`-c 'export TERM=…; exec "$shell"'`），cmd.exe 不认 `-c`
 *      （忽略整行、空跑一场就退出）、PowerShell 认 `-c` 但把 `export` 当不存在的 cmdlet 报错。
 * 两条都在 Windows 11 ARM 上实测复现过（见 README「Windows 宿主」一节）。
 *
 * 平台用**参数注入**（默认 process.platform），所以两个分支都能在 macOS/Linux 上断言，
 * 不必等 Windows runner —— 而 Windows runner 上跑同一份用例同样成立。
 */
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import {
  buildCommandSpawn,
  buildShellSpawn,
  commandShellHint,
  defaultShellPath,
  isPowerShellShell,
  shellIntegrationSupported,
} from '../src/shell-integration.js'

/*
 * 桩文件写在 $DSH_HOME/tty/shell/… 下。把它指到测试自己的临时目录，有两个好处：
 *   1. 不依赖机器上 ~/.dsh 里那份桩是否恰好最新——`writeIfChanged` 只在内容变了才写，
 *      若恰好一致就走 early-return，测试的成立条件会悄悄依赖外部状态；
 *   2. 受限文件沙箱（写不了工作区之外）下不再假红。
 */
let savedDshHome: string | undefined
let stubHome = ''
beforeAll(() => {
  savedDshHome = process.env.DSH_HOME
  stubHome = mkdtempSync(join(tmpdir(), 'dsh-tty-stub-'))
  process.env.DSH_HOME = stubHome
})
afterAll(() => {
  if (savedDshHome === undefined) delete process.env.DSH_HOME
  else process.env.DSH_HOME = savedDshHome
  rmSync(stubHome, { recursive: true, force: true })
})

describe('defaultShellPath', () => {
  it('POSIX 取 $SHELL，缺省 /bin/zsh', () => {
    expect(defaultShellPath('darwin', { SHELL: '/opt/homebrew/bin/zsh' })).toBe('/opt/homebrew/bin/zsh')
    expect(defaultShellPath('darwin', { SHELL: '  ' })).toBe('/bin/zsh')
    expect(defaultShellPath('linux', {})).toBe('/bin/zsh')
  })

  it('Windows 取 %COMSPEC%，不再回落 /bin/zsh（回归）', () => {
    expect(defaultShellPath('win32', { COMSPEC: 'C:\\WINDOWS\\system32\\cmd.exe' })).toBe('C:\\WINDOWS\\system32\\cmd.exe')
    expect(defaultShellPath('win32', { COMSPEC: '  ' })).toBe('cmd.exe')
    // 就算环境里塞了个 $SHELL（MSYS/Git Bash 会），Windows 也不该拿它当默认：
    // 面板默认要的是「系统保证存在」的那个解释器
    expect(defaultShellPath('win32', { SHELL: '/bin/zsh' })).not.toBe('/bin/zsh')
  })
})

describe('isPowerShellShell', () => {
  it('认得 Windows PowerShell 5.1 与 PowerShell 7（全路径 / 大小写都算）', () => {
    expect(isPowerShellShell('powershell.exe')).toBe(true)
    expect(isPowerShellShell('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe')).toBe(true)
    expect(isPowerShellShell('C:\\Program Files\\PowerShell\\7\\pwsh.exe')).toBe(true)
    expect(isPowerShellShell('PWSH')).toBe(true)
    expect(isPowerShellShell('cmd.exe')).toBe(false)
    expect(isPowerShellShell('/bin/zsh')).toBe(false)
  })
})

describe('buildShellSpawn：Windows 分支', () => {
  it('cmd 直接跑本体——没有 -c 包装层（cmd 会忽略 -c、空跑一场然后退出）', () => {
    const plan = buildShellSpawn('C:\\WINDOWS\\system32\\cmd.exe', 'xterm-256color', 'truecolor', true, 'win32')
    expect(plan.argv).toEqual(['C:\\WINDOWS\\system32\\cmd.exe'])
    expect(plan.env).toEqual({})
  })

  it('integration=false 时只补 -NoLogo；不补 -NoProfile（用户的 profile 正是别名与函数的来源）', () => {
    const plan = buildShellSpawn('C:/Program Files/PowerShell/7/pwsh.exe', 'xterm-256color', 'truecolor', false, 'win32')
    expect(plan.argv).toEqual(['C:/Program Files/PowerShell/7/pwsh.exe', '-NoLogo'])
    expect(plan.argv).not.toContain('-NoProfile')
  })

  it('PowerShell + integration：走 -File 桩（-NoExit 必给，否则桩跑完标签就关）', () => {
    const plan = buildShellSpawn('C:/Program Files/PowerShell/7/pwsh.exe', 'xterm-256color', 'truecolor', true, 'win32')
    const [bin, ...rest] = plan.argv
    expect(bin).toBe('C:/Program Files/PowerShell/7/pwsh.exe')
    expect(rest.slice(0, 3)).toEqual(['-NoLogo', '-NoExit', '-ExecutionPolicy'])
    expect(rest[3]).toBe('Bypass')
    expect(rest[4]).toBe('-File')
    const stub = rest[5]
    expect(stub.endsWith('bootstrap.ps1')).toBe(true)
    // 桩落在 $DSH_HOME 下（测试把它指向临时目录，见文件头）
    expect(stub.startsWith(stubHome)).toBe(true)
    expect(readFileSync(stub, 'utf8')).toContain('dsh-tty shell integration')
  })

  it('cmd + integration：一个标记都不注入（没有命令开始/结束钩子可比）', () => {
    const plan = buildShellSpawn('C:/Windows/System32/cmd.exe', 'xterm-256color', 'truecolor', true, 'win32')
    expect(plan.argv).toEqual(['C:/Windows/System32/cmd.exe'])
    // 也不能把 POSIX 那套混进来（PowerShell 会把 export 当不存在的 cmdlet 报错）
    expect(plan.argv.join(' ')).not.toMatch(/export|ZDOTDIR|rcfile|DSH_TTY_ORIG/)
  })
})

/** PowerShell 桩的落盘路径（走公开入口取，不在测试里重写一遍路径推导）。 */
function stubOf(): string {
  const argv = buildShellSpawn('powershell.exe', 'xterm-256color', 'truecolor', true, 'win32').argv
  return argv[argv.length - 1]
}

/*
 * 桩内容的三条硬约束，每条都对应一个真实故障：
 *   1. 纯 ASCII —— Windows PowerShell 5.1 按当前 ANSI 代码页读无 BOM 的 .ps1，
 *      中文注释会让解析错位，而 `-File` 解析失败＝集成静默失效；
 *   2. ESC/BEL 用 [char] 现构造 —— PS 5.1 没有 `e 转义（6+ 才有）；
 *   3. 拿不到原 PSConsoleHostReadLine（用户关了 PSReadLine）时**一个标记都不发** ——
 *      只发 A/7 会让宿主 sawMark=true 而 inCommand 恒 false，running 从「未知」退化成
 *      「没在跑」，正是 D77 要防的「往正在跑的程序里塞命令」。
 */
describe('PowerShell 桩内容', () => {
  it('纯 ASCII，且用 [char] 构造 ESC/BEL', () => {
    const content = readFileSync(stubOf(), 'utf8')
    expect(/[^\x00-\x7F]/.test(content)).toBe(false)
    expect(content).toContain('[char]27')
    expect(content).toContain('[char]7')
  })

  it('挂 prompt 与 PSConsoleHostReadLine 双钩子，发全 A/B/D 与 OSC 7', () => {
    const content = readFileSync(stubOf(), 'utf8')
    expect(content).toContain('function global:prompt')
    expect(content).toContain('function global:PSConsoleHostReadLine')
    expect(content).toContain(']133;A')
    expect(content).toContain(']133;B')
    expect(content).toContain(']133;D;')
    expect(content).toContain(']7;')
    // 用户自定义的 prompt 要被包住、原样调用（桩在 profile 之后载入）
    expect(content).toContain('& $global:__DSH_TTY_ORIG_PROMPT')
    // 没有 PSReadLine 就什么都不发
    expect(content).toContain('if ($null -ne $global:__DSH_TTY_ORIG_RL) {')
  })

  it('不碰用户可见状态：不清空 $LASTEXITCODE（清了 `echo $LASTEXITCODE` 会读到空）', () => {
    const content = readFileSync(stubOf(), 'utf8')
    expect(content).not.toMatch(/LASTEXITCODE\s*=\s*\$null/)
    // 退出码口径：B 时刻快照，D 时刻变了才报（原生命令用真码，cmdlet 用 $? 的 0/1）
    expect(content).toContain('$global:__DSH_TTY_LEC_AT_B')
  })
})

describe('shellIntegrationSupported（宿主把开关存成什么值的判据）', () => {
  it('POSIX 恒 true（具体能不能注入由 buildShellSpawn 按 shell 家族决定，历史行为）', () => {
    for (const shell of ['/bin/zsh', '/bin/bash', '/usr/bin/fish']) {
      expect(shellIntegrationSupported(shell, 'darwin'), shell).toBe(true)
    }
  })

  it('Windows：PowerShell 家族 true（-File 桩），cmd / Git Bash / WSL false', () => {
    for (const shell of ['powershell.exe', 'C:/Program Files/PowerShell/7/pwsh.exe', 'PWSH.EXE']) {
      expect(shellIntegrationSupported(shell, 'win32'), shell).toBe(true)
    }
    for (const shell of ['C:/Windows/System32/cmd.exe', 'C:/Program Files/Git/bin/bash.exe', 'wsl.exe']) {
      expect(shellIntegrationSupported(shell, 'win32'), shell).toBe(false)
    }
  })
})

describe('buildCommandSpawn：Windows 分支', () => {
  it('cmd 走 /c，PowerShell 走 -Command', () => {
    expect(buildCommandSpawn('cmd.exe', 'xterm-256color', 'truecolor', 'docker ps', 'win32').argv)
      .toEqual(['cmd.exe', '/c', 'docker ps'])
    expect(buildCommandSpawn('pwsh.exe', 'xterm-256color', 'truecolor', 'docker ps', 'win32').argv)
      .toEqual(['pwsh.exe', '-NoLogo', '-Command', 'docker ps'])
  })

  it('Git Bash / WSL 用 -c / -e sh -c，不再一律 /c（0.19.0：/c 对它们静默失败）', () => {
    expect(buildCommandSpawn('C:\\Program Files\\Git\\bin\\bash.exe', 'xterm-256color', 'truecolor', 'docker ps', 'win32').argv)
      .toEqual(['C:\\Program Files\\Git\\bin\\bash.exe', '-c', 'docker ps'])
    expect(buildCommandSpawn('wsl.exe', 'xterm-256color', 'truecolor', 'docker ps', 'win32').argv)
      .toEqual(['wsl.exe', '-e', 'sh', '-c', 'docker ps'])
  })

  it('Windows 分支不带 POSIX 包装（回归：PowerShell 会报 export 不是 cmdlet）', () => {
    const text = buildCommandSpawn('powershell.exe', 'xterm-256color', 'truecolor', 'ls', 'win32').argv.join(' ')
    expect(text).not.toContain('export')
    expect(text).not.toContain('exec ')
  })
})

describe('POSIX 分支回归（改动不能碰现有的 zsh/bash 路径）', () => {
  it('integration=false 时是最简包装层', () => {
    expect(buildShellSpawn('/bin/zsh', 'xterm-256color', 'truecolor', false, 'linux').argv).toEqual([
      '/bin/zsh',
      '-c',
      "export TERM='xterm-256color'; export COLORTERM='truecolor'; exec \"/bin/zsh\"",
    ])
  })

  it('zsh + integration 仍走 ZDOTDIR 桩', () => {
    const plan = buildShellSpawn('/bin/zsh', 'xterm-256color', 'truecolor', true, 'darwin')
    expect(plan.argv[0]).toBe('/bin/zsh')
    expect(plan.argv[1]).toBe('-c')
    expect(plan.argv[2]).toContain('DSH_TTY_ORIG_ZDOTDIR')
    expect(plan.argv[2]).toContain('ZDOTDIR=')
    expect(plan.argv[2]).toContain('exec "/bin/zsh"')
  })

  it('zsh 桩链全四个 rc（含 .zlogout——ZDOTDIR 指过去后用户的退出钩子不该被吞）', () => {
    const plan = buildShellSpawn('/bin/zsh', 'xterm-256color', 'truecolor', true, 'darwin')
    const stubDir = String(plan.argv[2]).match(/ZDOTDIR='([^']+)'/)?.[1]
    expect(stubDir).toBeDefined()
    for (const name of ['.zshenv', '.zprofile', '.zlogin', '.zlogout']) {
      const content = readFileSync(join(stubDir as string, name), 'utf8')
      expect(content).toContain('DSH_TTY_ORIG_ZDOTDIR')
    }
  })

  it('钩子必须前置挂载（0.19.0：后置追加会让前序钩子的返回码污染 $?）', () => {
    const plan = buildShellSpawn('/bin/bash', 'xterm-256color', 'truecolor', true, 'linux')
    const stubRc = String(plan.argv[2]).match(/--rcfile '([^']+)'/)?.[1]
    expect(stubRc).toBeDefined()
    const rc = readFileSync(stubRc as string, 'utf8')
    // bash 数组形态：插到数组头部而不是 +=
    expect(rc).toContain('PROMPT_COMMAND=("__dsh_tty_precmd" "${PROMPT_COMMAND[@]}")')
    expect(rc).not.toContain('PROMPT_COMMAND+=')
    // zsh：precmd/preexec 同样前置
    const zshPlan = buildShellSpawn('/bin/zsh', 'xterm-256color', 'truecolor', true, 'linux')
    const zshDir = String(zshPlan.argv[2]).match(/ZDOTDIR='([^']+)'/)?.[1]
    const zshrc = readFileSync(join(zshDir as string, '.zshrc'), 'utf8')
    expect(zshrc).toContain('precmd_functions=(__dsh_tty_precmd "${precmd_functions[@]}")')
    expect(zshrc).not.toContain('precmd_functions+=')
  })

  it('带命令的本地 spawn 仍是 -c + export 包装，且命令**整体**交给内层 shell（D78）', () => {
    const plan = buildCommandSpawn('/bin/zsh', 'xterm-256color', 'truecolor', 'docker exec -it web sh', 'darwin')
    expect(plan.argv).toEqual([
      '/bin/zsh',
      '-c',
      "export TERM='xterm-256color'; export COLORTERM='truecolor'; exec '/bin/zsh' -c 'docker exec -it web sh'",
    ])
  })

  /*
   * D78：旧实现把用户命令直接缀在 `exec` 后面，而 `exec` 只作用于**简单命令**——
   * `a; b` 的后半段、`cd x && cmd` 的右支永远不会被调度（`exec cd …` 这类内建更是
   * 直接结束外层 shell），退出码也取自第一条。用户命令是「一段 shell 代码」，所以
   * 这里钉的不是某一条形态，而是**整段命令必须原样出现在单引号里**。
   */
  it('复合命令整段进单引号：`a; b` / `cd x && cmd` / `for` 都不再被 exec 截断（D78）', () => {
    for (const command of ['echo A; echo B', 'cd /tmp && pwd', 'for i in 1 2 3; do echo L$i; done', 'echo X; exit 3']) {
      const plan = buildCommandSpawn('/bin/zsh', 'xterm-256color', 'truecolor', command, 'darwin')
      const script = String(plan.argv[2])
      expect(script, command).toBe(`export TERM='xterm-256color'; export COLORTERM='truecolor'; exec '/bin/zsh' -c '${command}'`)
      // 旧形状（`exec <command>`）必须不再出现：那才是「只跑第一条」的写法
      expect(script.startsWith(`export TERM='xterm-256color'; export COLORTERM='truecolor'; exec ${command}`), command).toBe(false)
    }
  })

  it('命令里的单引号被转义，带引号 / 多行的命令也能安全穿过外层 shell（D78）', () => {
    const quoted = buildCommandSpawn('/bin/zsh', 'xterm-256color', 'truecolor', "echo 'it'", 'darwin')
    expect(String(quoted.argv[2])).toBe(
      "export TERM='xterm-256color'; export COLORTERM='truecolor'; exec '/bin/zsh' -c 'echo '\\''it'\\'''",
    )
    const multiline = buildCommandSpawn('/bin/zsh', 'xterm-256color', 'truecolor', 'echo A\necho B', 'darwin')
    expect(String(multiline.argv[2])).toContain("exec '/bin/zsh' -c 'echo A\necho B'")
  })

  it('命令语法提示随宿主 shell 变（D78 补：Windows 上无条件说 POSIX 语法会误导模型）', () => {
    const posix = commandShellHint('/bin/zsh', 'darwin')
    expect(posix).toContain('/bin/zsh')
    expect(posix).toContain('POSIX')
    expect(commandShellHint('   ', 'darwin')).toContain('(未配置)')

    const cmd = commandShellHint('C:\\WINDOWS\\system32\\cmd.exe', 'win32')
    expect(cmd).toContain('cmd')
    expect(cmd).toContain('%VAR%')
    // 必须明确否定 POSIX 那几样——报告方就是在 Windows 上按 POSIX 语法复测，9 条全红
    expect(cmd).toContain('不是 cmd 语法')

    const pwsh = commandShellHint('C:\\Program Files\\PowerShell\\7\\pwsh.exe', 'win32')
    expect(pwsh).toContain('PowerShell')
    expect(pwsh).toContain('$env:VAR')
    // D101：PowerShell 7 与 5.1 的语法**不一样**，这句话每轮都进 systemPrompt。
    // 2026-10-13 真机实测（pwsh 7.6.6 / 5.1.26100）：`echo A && echo B` 在 7 上正常输出 A/B，
    // 在 5.1 上是解析错误且一条都没跑——旧文案对 7 说「&& 不是语法」会把模型引到坑里。
    expect(pwsh).toContain('PowerShell 7')
    expect(pwsh).toContain('&&')
    const ps51 = commandShellHint('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe', 'win32')
    expect(ps51).toContain('5.1')
    expect(ps51).toContain('没有')
    expect(ps51).not.toContain('PowerShell 7')

    expect(commandShellHint('C:\\Program Files\\Git\\bin\\bash.exe', 'win32')).toContain('POSIX')
    expect(commandShellHint('C:\\Windows\\System32\\wsl.exe', 'win32')).toContain('sh -c')
  })

  it('Windows 四个分支都不带 exec（跨平台一致：复合命令在那边本来就完整执行，D78）', () => {
    const cases: Array<[string, string[]]> = [
      ['C:\\Windows\\System32\\cmd.exe', ['/c']],
      ['C:\\Program Files\\PowerShell\\7\\pwsh.exe', ['-NoLogo', '-Command']],
      ['C:\\Program Files\\Git\\bin\\bash.exe', ['-c']],
      ['C:\\Windows\\System32\\wsl.exe', ['-e', 'sh', '-c']],
    ]
    for (const [shell, flags] of cases) {
      const plan = buildCommandSpawn(shell, 'xterm-256color', 'truecolor', 'echo A; echo B', 'win32')
      expect(String(plan.argv.at(-1)), shell).toBe('echo A; echo B')
      expect(plan.argv, shell).not.toContain('exec')
      expect(plan.argv.slice(1, -1), shell).toEqual(flags)
    }
  })

  it('bash 的 D 标记必须无条件发（0.19.0 修 D46：PS0 的展开在子 shell 里，设不了 IN_CMD）', () => {
    const plan = buildShellSpawn('/bin/bash', 'xterm-256color', 'truecolor', true, 'linux')
    const stubRc = String(plan.argv[2]).match(/--rcfile '([^']+)'/)?.[1]
    expect(stubRc).toBeDefined()
    const rc = readFileSync(stubRc as string, 'utf8')
    // 无条件发 D：不能再被 __DSH_TTY_IN_CMD 的 if 包住（否则 bash ≥4.4 上 D 永远不发，
    // capture{last} 恒 inProgress、tty_expect 永远超时——CI 首跑 ubuntu 暴露）
    expect(rc).toContain('printf "$__DSH_TTY_FMT_D" "$ec"; __DSH_TTY_IN_CMD=0')
    expect(rc).not.toContain('if [ "$__DSH_TTY_IN_CMD" = "1" ]; then')
    // <4.4 的 DEBUG trap 仍要设这个 flag（3.2 上它是 B 的唯一来源）
    expect(rc).toContain('__DSH_TTY_IN_CMD=1')
  })
})
