# @hyzyn/dsh-tty

[中文](README.md) | English

> The DSH sidebar “Terminal” panel: a complete terminal built on xterm.js + a **real PTY**, treating local and SSH alike, with sessions kept alive across disconnects for long-running work.

## Features

- **Real PTY + WebGL rendering**: node-pty real PTY, so TUIs such as vim / htop / a dev server all run; multi-tab.
- **Optional tmux session persistence**: reopen after a host restart / network blip and the scene is back; “command tabs” such as docker exec reopen automatically.
- **Native ssh2 connections**: agent forwarding + host-key TOFU pinning, managed uniformly through the connection book; plus **SFTP** upload/download and **port forwarding** (-L / -R, reconnecting automatically after a drop).
- **The agent reads the terminal at “command” granularity**: shell integration (OSC 133/7) lets `tty_capture{last}` / `tty_expect` read the output and exit code of “the previous command” instead of capturing the screen and guessing; `tty_list` reports whether a command is currently running (`running`, three states: running / finished / cannot tell), and `tty_run` returns the output and exit code of one command in a single call.
- **Two client services exposed to other plugins**: `ttyConnbar` (connection-bar actions) and `ttyTerminal` (open a terminal in place); dsh-docker’s “Containers / Terminal” buttons go through them.
- **AI assist: explain failures (0.24.0, off by default)**: when a command exits non-zero a chip appears in the corner; clicking it sends **that command's output tail** (cleaned / truncated / secrets masked) plus the current screen to the model and renders a short "what happened / next step". A suggested command is only typed into the prompt line — never submitted for you. See [AI assist](#ai-assist-explain-failures-0240-off-by-default).

![Terminal panel: a multi-tab xterm modal; the header toolbar has the search box expanded (hint “Search (Enter ↓ / Shift+Enter ↑)”) plus clear, and the title bar has the minimize “—” and close ✕](https://cdn.jsdelivr.net/gh/hyzyn/dsh-plugin-kit@main/docs/dsh-plugin-kit-tty.png)

## Installation

```bash
dsh plugin --profile web add @hyzyn/dsh-tty    # npm install (after release)
dsh plugin --profile web add link:$(pwd)/packages/tty   # repo development/debugging
```

After installing, restart `dsh web`; a “Terminal” entry appears in the sidebar — click it to open the panel; the Settings → Plugins → “Terminal Panel” card lets you change the configuration (**saving takes effect immediately**, no restart needed).

## How to use

- Opening the panel automatically creates the first terminal (default `$SHELL`, usually zsh on macOS);
- **Multi-tab**: “+” in the tab bar creates a new terminal (since 0.2.0 “+” is a menu: local terminal /
  SSH connection book (entries have ✎ to edit) / SSH connection…, see the next section for SSH), and ✕ closes
  a tab; **double-clicking a tab renames it** (the name is persisted with the tab and survives a reconnect);
  each tab is an independent session (local PTY or SSH channel); when the tab bar runs out of room it
  **scrolls horizontally** (no scrollbar — wheel / trackpad, with fades at both edges) and a
  **“⋯” tab list** appears at the strip’s right edge listing only the tabs **scrolled out of view**
  (status dot + target, with the current tab highlighted when it is one of them): one click to switch,
  and an inline ✕ to close it right there (the list stays open so you can close several in a row);
- **Close a batch of tabs at once (0.30.0)**: no more clicking ✕ one by one — **right-click** any tab to get
  a menu anchored on it (Close this tab / Close other tabs (N) / Close tabs to the left (N) / Close tabs to
  the right (N) / Clean up exited tabs (N); rows with nothing to close are not shown — no “left” row when the
  anchored tab is first, no “right” row when it is last), and **middle-click** closes the tab under the
  pointer. The **“⋯” menu carries the same batch rows** (anchored on the current tab) and, since 0.30.0,
  **appears whenever there are ≥ 2 tabs** (overflow or dead tabs are no longer required): right-click is the
  fast path, but it must not be the only way in; with a single tab it still stays hidden (there is nothing to
  manage — that is the only real noise here). Actions that would **end ≥ 2 live sessions** ask once first
  (how many, and how many of those the AI opened); closing a single live session is the same as clicking its
  own ✕, so it does not ask (the rule lives in `client-src/tab-bulk.js`, same “what do you lose” criterion
  as the D98 panel-close guard);
- **“Hidden from the AI” tabs (0.30.0, off by default)**: the context menu gains “Hide this tab from the AI” —
  once hidden, the **agent side cannot see it at all**: it is absent from `tty_list` and from the per-turn
  systemPrompt session block (not even cwd or whether a command is running; that block only reports
  “N more tabs are set to be invisible to the agent”), and `tty_capture` / `tty_screen` / `tty_send` /
  `tty_expect` / `tty_stats` are refused for it by sid. The marker is a 🙈 before the tab title plus a
  tooltip (the “⋯” list shows it too). **In your own panel the tab stays fully usable** (view, type, close);
  enforcement happens on the host and applies to the agent only — keep one terminal of your own for keys,
  personal work, or anything unrelated to this turn without worrying about it being screen-scraped.
  **Tabs the AI opened do not get this item** (hiding them would erase its behaviour from your view); the
  rule lives in `client-src/tab-hidden.js` plus the host’s `setHiddenFromAgent`, and after a reconnect only
  “hidden” is re-asserted (the hidden state is never silently cleared);
- **The working directory follows the current DSH session**: new tabs open in the current session’s
  working directory (the host `cwd` configuration is the fallback). Since 0.1.6 the session list
  snapshot no longer carries `current` (view selection moved to the workspace domain), so the client
  reads `retainedBy.mainView > 0` to find the current session — trusting only the legacy field leaves
  the cwd empty and new tabs fall back to the host’s start directory;
- Supports TUIs such as vim / htop / less (TERM is injected as `xterm-256color`);
- Panel size changes are resized automatically (xterm fit → native PTY resize); **inactive tabs do not
  follow** — each keeps its own last valid size (D79: when the container is invisible or the probe is
  degenerate, no resize frame is sent at all);
- **Ctrl+F searches inside the terminal** (Enter next / Shift+Enter previous / Esc closes only the search
  box), links in the output are clickable, and the header toolbar keeps just search / clear — copy and
  paste use the terminal’s own shortcuts (Cmd+C / Ctrl+Shift+C to copy a selection, Cmd+V / Ctrl+V to paste);
- **Reconnect on disconnect (0.3.0)**: after an abnormal disconnect such as a page refresh or a network
  blip, the session is kept alive on the host for `reconnectGraceSec` (120 seconds by default) and the
  client reconnects automatically with exponential backoff (capped at 5s); after reconnecting it
  **attaches back to the original session by sid and replays the output buffered during the disconnect**;
  after a page refresh the tab list is restored from sessionStorage (sessions already finished on the host are dropped);
- **WebGL renderer (0.3.0)**: high-throughput output (build logs) renders dramatically faster; on WebGL
  context loss (e.g. too many tabs exceeding the browser quota) it automatically falls back to the DOM renderer;
- **Minimize (state folded into the sidebar entry)**: clicking outside the modal, pressing Esc or the
  title-bar “—” collapses the panel — PTY sessions and output buffers stay alive, the sidebar “Terminal”
  entry shows a “running / total” badge and a status dot (pulsing when there is output), and clicking the
  entry restores it; only the floating bar’s ✕ / the title-bar ✕ really closes it and ends every session;
- **Closing the panel asks first (issue #8)**: while the panel still has live sessions, ✕ (including the
  one on the floating bar) opens a confirmation that states how many sessions this ends, how many of them
  the AI opened, and puts **Minimize** (sessions and output keep running) on the same button row — it used
  to only point at «—» on the title bar, which that very layer covers and swallows, so the way out was
  “cancel first, then go find «—»”; putting it in reach turns the misclick into the right action. With only
  exited tabs (or none) it closes straight away: the predicate is *what would be lost*, not *how many tabs
  are open* (a confirmation that fires too often gets clicked out of habit, and then the real one stops
  working);
- **Exited sessions no longer cover their output (issue #7①②)**: the exited state is now a strip at the top
  of the terminal area (one line — “Exited code=…” / “The AI finished this session” — plus at most one action
  button), so output stays readable, scrollable and selectable. The previous full-area overlay was both why
  “the AI’s command output is unreadable” (users hid `.tt_overlay` from devtools) and why clicking anywhere
  was swallowed — even selecting text was impossible. Error and “reconnecting” overlays stay: their job is
  to explain why there is no output;
- **“Clean up exited tabs (N)” in the “⋯” menu (issue #7③)**: removes every exited tab in one go (which also
  makes the host release their read-only retention right away); the “⋯” button now also appears when there
  are dead tabs without overflow — it used to show up only on overflow, while the AI leaves one dead tab per
  command (a user collected 47 of them and had to close them one by one);
- **Tabs opened by the AI follow their session (issue #7④)**: once the AI releases a session (`tty_close`,
  or `tty_run`’s default cleanup), its tab goes away with it — the one **you switched to and are looking at** gets
  one step of grace (a tab the client itself promoted to the foreground does not count) (the strip says “The AI finished this session” with a “Dismiss” button; switching away or
  clicking it closes the tab). Sessions still in read-only retention (`tty_run keep:true`, `tty_open command=`
  that was never closed) keep their tabs — readable, swept by the cleanup entry above;
- The title-bar ✕ closes the panel and ends every session (PTY tree-level cleanup; tmux persistent tabs also
  get kill-session); after a session exits, reopen it from the top strip (a local tab opens a fresh session
  from its spec, persistent tabs reattach to tmux, command tabs run again);
- The concurrency limit defaults to 4 (`maxSessions` configuration, 1~16).

![Terminal panel settings card: shell / TERM / concurrency limit and so on take effect on save](https://cdn.jsdelivr.net/gh/hyzyn/dsh-plugin-kit@main/docs/dsh-plugin-kit-tty-setting.png)

## Windows hosts (0.18.1, best-effort)

**Before 0.18.1 a Windows host could not open a single local terminal**, for two reasons on the same path:

1. `$SHELL` **does not exist on Windows**, and the default shell fell back to `/bin/zsh` unconditionally →
   `spawn` fails with ENOENT (measured: `spawn /bin/zsh -> ENOENT`, while `%COMSPEC%` works);
2. the spawn plan was POSIX-shaped (`-c 'export TERM=…; export COLORTERM=…; exec "$shell"'`) — cmd.exe does
   not understand `-c` (it ignores the whole line, runs an empty session and exits, so the tab appears and
   vanishes), and PowerShell understands `-c` but rejects `export` as an unknown cmdlet.

Both were reproduced on **Windows 11 ARM (24H2) + Node 22 ARM64**. The fix:

- **Default shell is `%COMSPEC%`** (guaranteed to exist); for PowerShell put the full path to
  `powershell.exe` / `pwsh.exe` in the settings card’s “Shell path”. On Windows the candidate list offers
  `%COMSPEC%` + Windows PowerShell 5.1 + PowerShell 7 (when installed), with the default first;
- **No wrapper layer on Windows**: plain `[shell]`; the PowerShell family gets `-NoLogo` (drops the copyright
  banner) but deliberately **not `-NoProfile`** — the user’s profile is where aliases and functions come from.
  TERM / COLORTERM are meaningless for ConPTY and are no longer injected;
- **“Run one command” tabs** (docker exec, command tabs opened by the agent) use `cmd /c` or
  `PowerShell -Command`; **PowerShell’s `-Command` collapses a non-zero last command into process exit code
  1** (`cmd /c exit 5` → 1, both versions), so to get a concrete code let the command `exit 5` itself (POSIX
  `sh -c` does not behave this way);
- **Input line-ending normalisation (D74, reported on real hardware 2026-09-27)**: conhost treats Enter as
  **CR**, so a bare LF only moves the cursor down and **does not submit the command line** — `tty_send`
  writing `echo X\n` as the tool description says leaves the command sitting on the input line (no output,
  no new prompt, looking like “it was sent but never ran”). For **local sessions on win32** the plugin now
  turns a bare LF into CRLF (an existing CRLF is not doubled; non-Windows and SSH sessions pass through
  untouched), so the documented `\n` path just works;
- **Shell integration (OSC 133/7) depends on the shell family**: the **PowerShell family is supported**
  (`powershell.exe` / `pwsh.exe`) through a stable `-File` stub that hooks `prompt` and
  `PSConsoleHostReadLine` — this yields cwd tracking (`tty_list.cwd` following `cd`), exit codes, the
  `running` state and command-granular `tty_expect`. **cmd is not** (it has no command-boundary hooks), so
  the settings card greys the switch out and points at “switch the shell path to PowerShell”. **The two
  versions differ, and the syntax hint is branched by version**: `&&` / `||` are **PowerShell 7** only —
  on 5.1 `&&` is a parse error and not a single command runs. **Known limit (not reproduced)**: it was
  recorded that on PowerShell 7 the command output reaches ConPTY *after* the D marker, so
  `tty_capture{last}` may come back empty; on 2026-10-13 this was re-measured on pwsh **7.6.6** (Win11
  ARM64) across three output shapes (20 small outputs / a 2000-line burst / 20 writes over 2s) with
  **0/20 empty windows** — not reproduced. If you do hit one, read the tail with `tty_capture` and report
  the pwsh version. One more **exit-code rule**: in the PowerShell family a **parse error** (`&&` on 5.1,
  `echo (1` on both) runs nothing at all yet the D marker reports **0** — never judge success by the exit
  code alone; the error text is in the output. The stub only loads through `-ExecutionPolicy Bypass` (process-scoped); two boundaries
  are recorded as they are: when **Group Policy** locks the execution policy to Restricted / AllSigned that
  parameter does **not** override GPO, so the stub fails to load and the tab opens with integration silently
  absent (the same degradation as “the user turned PSReadLine off”); the parameter also writes the value into
  `$Env:PSExecutionPolicyPreference`, which PowerShell processes started from that session inherit. One more
  known side effect: wrapping `prompt` makes **the user’s original prompt see its own `$?`** as the result of
  our writes (always true), so failure indicators that rely on `$?` stop working;
- **Two things are not supported** (the host turns them off and the settings card explains why):
  - **tmux persistence**: there is no tmux on Windows, so local tabs open normally but are not managed
    (SSH into a Linux host still works);
  - **Server status bar**: locally only CPU / memory / uptime are available (`node:os`); disk / TCP / network
    throughput / temperature show “无” (remote **Windows** hosts go through the PowerShell hop — see the
    status-bar section);
- **How far this was verified**: on Windows 11 ARM a full install (`dsh plugin add @hyzyn/dsh-all`), all nine
  plugins mounting, `dsh web` serving, and the browser half being delivered (the same artifact macOS serves;
  size and new-code markers compared after a build rather than pinning a byte count, which changes on every
  rebuild), plus `[dsh-tty] mounted (shell=C:\WINDOWS\system32\cmd.exe)`.
  x64 Windows is covered by the CI matrix (build / typecheck / test, see Development).
- **End-to-end coverage (0.19.0)**: `scripts/windows-smoke.mjs` drives a real `cmd.exe` through
  spawn → input echo → kill → respawn on the CI windows-latest runner, plus two links that only hold on
  a real machine (W6: after normalisation a bare LF really does submit in conhost, D74; W7: a `command`
  session that exits turns into read-only retention and `tty_capture` still reads its pre-exit output, D77).
  **W8 (the PowerShell OSC 133/7 stage) runs on CI** (since 2026-10-13): it used to be guarded by the
  **real-machine lane** only, because killing a ConPTY session there tripped `0xC0000374` — the root cause
  (the same PTY being natively `kill()`ed twice) is now located and fixed, see **D100** in
  [DEFECTS.md](./DEFECTS.md) and the 2026-10-13 section of [ROADMAP.md](./ROADMAP.md). Where no PowerShell
  exists the stage honestly reports its own `SKIP` row (excluded from the denominator, never dressed up as
  `12/12`). It caught and now pins a
  Windows-only failure class: force-killing a local PTY crashed the host — node-pty rejects signals
  on Windows, and its `_deferNoArgs` re-throws that error from a socket callback, where the caller’s
  try/catch cannot see it.

## Agent tools

The plugin injects nineteen tools into the agent (operations show up live in the user’s terminal; **every call is subject to the session permission tier**, see below):

| Tool | Purpose |
| --- | --- |
| `tty_list` | List terminal sessions (sid / kind (`local\|ssh`) / target / pid / **cwd tracked live as you `cd`** / activity time; tmux persistent sessions carry a `persist` marker; sessions the agent opened carry `owner: 'agent'`). **Includes sessions whose process has exited but which are still inside their read-only retention window** (`exited:true` + exit code/signal, see below). **`running` says whether a command is currently executing** (true = it is: do not send into it now; false = the command has finished; **omitted = cannot tell** — non-persistent SSH / fish·csh / Windows cmd sessions carry no shell-integration markers, which is *not* the same as “idle”), and the same-source `lastExitCode` / `lastExitAt` are the exit code and end time of “the previous completed command” (0.23.0). The rendered text spells the three states `[空闲]` / `[运行中——现在别往里发命令]` / `[命令状态未知——…]`; **“unknown” also covers one more case** — the host has seen **no marker for that session since this boot** (typically a tmux persistent session already sitting at its prompt before the host restarted): send it a bare Enter or run a command and the marker arrives, turning it into `[空闲]`; non-persistent SSH / fish·csh / Windows cmd sessions never emit markers, so `[命令状态未知]` is their normal state |
| `tty_open` | **Open a terminal session yourself** (0.20.0): a local shell, or a command via `command` (dev server / watch; it runs as **a whole piece of code in the host shell’s syntax** — on a POSIX shell `cd x && cmd`, `a; b` and multi-line scripts work, while **Windows cmd / PowerShell use their own syntax**; the current shell and syntax are restated every turn in the systemPrompt terminal line; it is *not* subject to the “single line ≤2000” client rule below — D78), with optional tmux persistence via `persistName`. The session **shows up in the user’s terminal panel** as an ordinary tab the user can see and take over — never a hidden session |
| `tty_close` | Close a session opened by `tty_open` (0.20.0). **Only the agent’s own sessions may be closed**: a tab the user opened is refused, so the agent never ends a terminal the user is working in. It also works on an **exited session that is still in read-only retention** — that is its release entry point (by default it is retained **until explicitly closed**, never on a timer) |
| `tty_run` | **One-shot command** (0.23.0): open a session, run `command`, wait for it to finish and return the tail output + exit code directly — collapsing “`tty_open` → wait → `tty_capture{last}` → `tty_close`” into a single call. It **closes the session once the command finishes** by default (the result is already in this call); `keep:true` leaves it in read-only retention instead. If it is still running at `timeoutSec` (1~600, default 120) it returns `running:true` and **does not kill the session** (whether to keep waiting or close it is the caller’s call). When to use this instead of the bash tool: when the user should **see** the command, or when it must run inside a terminal session; for purely non-interactive commands bash is more direct |
| `tty_stats` | Read live host metrics for a session’s machine (0.20.0): CPU / memory / disk / TCP connections / network rates / temperature / uptime. Local sessions report the host; SSH sessions report that remote host over a separate non-PTY channel that never touches the terminal. Check it before deploying or load-testing |
| `tty_capture` | Read recent output (last N lines, ANSI stripped by default, `raw:true` for the raw stream); **`last:true` returns only the output + exit code of the previous completed command** (shell integration markers, see the next section); when a command is **in flight** (just sent, completion marker not in yet) it returns `inProgress:true` without the stale result, so the previous command is never mistaken for this one (0.19.0). **A command-type session (`tty_open command=` / `tty_run`) has no “previous command”** (it injects no shell-integration hooks), so `last:true` on one errors explicitly and points at `lines` (0.23.0, D87) |
| `tty_screen` | Read the **currently visible screen** as rendered (xterm-headless virtual screen, plain text) — it can genuinely read TUI interfaces such as vim / htop / menus |
| `tty_expect` | Wait with a regex for a readiness signal (dev server URL, build finished, …). It **looks back first** at output that has not been read yet (including the full output of “the previous command”, so a command that finished instantly no longer burns the whole timeout) and then waits for subsequent output; on a hit it returns `matched:true` plus `matchedFrom` (`live` produced during this wait / `last` the previous command’s output / `buffered` buffered output that had already arrived). A timeout does not throw (`matched:false` + tail output, and it **does not consume the unread region**, so a different pattern can still look back at the same output), and a command that ends early also returns early with its exit code; **the echo of the command just sent never counts as a hit** (via the OSC 133 A..B boundary, or via the send record where there are no markers — see the next section; when only the echo ever matched, the timeout result carries `echoOnly:true`); at most 5 in-flight calls per session, and the accumulated window keeps only the last 64KB (0.19.0; look-back matching, see D72; echo exclusion, see D75) |
| `tty_send` | Send text and/or keys to a given session (such as `q` to a dev server, a menu selection, or `:wq` in vim). **Use the named `keys` for control and arrow keys** (`["C-c"]`, `["Down","Down","Enter"]` — a whitelisted lookup: an unknown name errors out instead of being silently sent as a literal), and **never hand-build escape sequences inside `data`** — `"\\x1b[B"` / `"^[[B"` get printed into the terminal as ordinary characters while the `sent` count looks identical (0.23.0); give at least one of `data`/`keys`, and when both are present `data` goes first followed by `keys` in order. End a command with `\n`: on a **local Windows session** a trailing bare LF is normalised to CRLF (D74, see the “Windows hosts” section); non-Windows and SSH sessions pass through untouched. On an **exited** session it fails explicitly (such sessions are read-only) |
| `sftp_list` | List a remote SSH directory (name/type/size/mtime, directories first); `book` is the connection-book entry name and `path` defaults to the login home; at most 500 entries by default (`truncated:true` beyond that), and `isSymlink` distinguishes a symlink from a real directory (0.19.0) |
| `sftp_read` | Read a remote **text** file (≤256KB by default, adjustable to 1MB, truncated beyond that); `offset` pages from a given byte (handy for log tails), an invalid `maxBytes` errors out instead of silently falling back, and binary detection is a double test (NUL + illegal-UTF-8 ratio) (0.19.0) |
| `sftp_write` | Write a remote text file (overwrite by default, `append:true` appends; ≤1MB per call) |
| `sftp_mkdir` | Create a remote directory; `parents:true` fills in missing parents level by level (equivalent to `mkdir -p`, created bottom-up, existing directories skipped idempotently) |
| `sftp_rename` | Rename/move a remote file or directory (a `to` in a different directory means a move; never overwrites an existing target) |
| `sftp_remove` | Delete a remote file/directory; a directory uses rmdir by default (a non-empty one errors explicitly), and `recursive:true` deletes the whole tree (irrecoverable); paths pointing at `/`, `~`, or containing `.`/`..` segments are refused (guard for an irrecoverable operation, 0.19.0) |
| `sftp_tree` | Recursively list a remote directory structure (depth-first, directories first; `maxDepth` 1~8 / `maxEntries` 1~2000 cap it, `truncated:true` when exceeded; symlinks are not followed, to avoid cycles) |
| `tunnel_list` | List port-forwarding tunnels and their live state (active/connecting/error/stopped, rules, connection counts) |
| `tunnel_start` / `tunnel_stop` | Start or stop one port-forwarding tunnel (0.25.0; `name` comes from `tunnel_list`). These **rewrite the configuration** — the same thing as ticking/unticking “Enable” in the settings card (settings → hot apply → `reconcile`), so the change is persistent and visible to the user. The returned snapshot usually still says `connecting` (dialling is async); call `tunnel_list` again for the final verdict |

### Session permission tier gate (tier gate)

Tools are classified by risk; **every call** is judged against the session’s permission tier
(Read Only / Workspace Write / Full access / Auto review) and allowed, asked, or denied — the tier is
switched by the user in the session, and the very next call follows the new tier:

| Class | Tools | Behaviour under a confined tier (Read Only / Workspace Write) |
| --- | --- | --- |
| Read | `tty_list` `tty_capture` `tty_screen` `tty_expect` `tty_stats` `tunnel_list` `sftp_list` `sftp_read` `sftp_tree` `tty_close` | Allowed on every tier |
| Write (bounded mutation) | `sftp_write` `sftp_mkdir` `sftp_rename` `sftp_remove` `tunnel_stop` | Approval prompt (runs only if the user allows this one call); deterministically denied when unattended (approval policy `never`) |
| Execute (unbounded command surface) | `tty_open` `tty_run` `tty_send` `tunnel_start` | Same — these tools can run arbitrary commands on the local or a remote shell and open listening ports; they are the fence-sensitive surface |

**Full access never prompts** (that tier’s intent is fewer confirmation steps); under **Auto review the
plugin does not add its own prompt** (the host’s model pre-review already examines every call). When the
host has not composed the `sandboxPolicy` / `approval` services (older hosts, minimal deployments) the
gate is **off** (behaviour identical to before the gate), and the startup log says so:
`tier-gate: services absent (…), per-call gate disabled`. The mechanism (decision matrix / the two-layer
relationship with the static `allowProxyCommand` switch) lives in
[docs/permission-tier-plan.md](../../docs/permission-tier-plan.md).

Typical agent flow (recommended): for a command that simply runs to completion, use `tty_run` to get its
output + exit code in one call; for a **long-lived** session, `tty_open` opens one (pass `persistName` for tmux
persistence on long-running work) → `tty_send` starts the command → `tty_expect` waits for the readiness marker →
`tty_capture{last:true}` gets the result of that single command → `tty_close` when done. In addition, a dynamic
context is registered in `systemPrompt` so that every turn automatically carries a snapshot of active
terminals (sid / kind / cwd / owner, plus a `[running]` marker) — you have context without calling `tty_list` first.

**Agent-opened session boundaries (0.20.0)**: a session opened by `tty_open` is an **ordinary tab in the
panel** (marked “agent”) — the user can see it, switch to it, take it over and close it. Hidden sessions
are deliberately not used, because “the user does not know what is running on the machine” is exactly
where zombie sessions come from. Such a session has no client bound from birth, so it is **not reaped by
the orphan collector** (which only reaps disconnected *user* sessions); it ends via the agent’s
`tty_close` or the user closing the tab. Conversely the agent **cannot close a user-opened tab**
(`tty_close` refuses explicitly).

### Read-only retention after the process exits (D77)

A process exit **no longer means the session is gone** — the session turns into a **read-only retained** one,
**kept until it is explicitly closed** by default (`EXITED_RETAIN_MS = ∞`; a host/plugin restart clears them).
While retained:

- **Reads keep working**: `tty_capture` (tail or `last`, including the final batch of output printed
  before exit), `tty_screen` (the screen as of the exit) and `tty_list` (entry carries `exited:true` +
  `exitCode`/`signal`) all still answer, and their results carry an `exited` marker;
  `tty_expect` no longer burns its timeout — it settles against the existing output and returns
  `exited:true`;
- **Writes are refused**: `tty_send` reports an explicit error (the process is gone; a write would
  vanish into a dead PTY), and `tty_resize` / `tty_stats` no longer apply to it (stats honestly returns
  `available:false`);
- **No re-attaching a terminal**: `attach` is explicitly refused (there is no live PTY; the panel does
  not create a tab for it either) — read the output with `tty_capture`;
- **Who releases it**: the agent’s `tty_close` (its own sessions only), the user closing that tab in the
  panel, or a host/plugin restart (retention lives in memory). The concurrency limit counts **live
  sessions only** (retained ones do not consume a slot) — and the client’s “+” pre-check counts the same
  way (D85: the `sessions` frame’s list includes retained sessions, so taking `list.length` as the live
  count made the client block the user’s own “+” with “session limit reached” even though there was no
  tab left to close). At most `MAX_EXITED_SESSIONS` (8) retained
  sessions are kept — the oldest is evicted beyond that (each eviction logs the sid it drops). So the
  rule is “the last 16 exited sessions stay readable”, which is the only bound on memory and handles
  (16 of them is on the order of ~20MB).

  Why **not** a timer: memory and handles are not actually time-driven (see above), while a deadline is a
  second surprise for whoever reads the output — the gap between “the command finished” and “the next
  round reads the result” spans people walking away and queued model turns. An output that vanishes on
  schedule is harder to reason about than one you have to close. If you do want a time bound (or no
  retention at all), set `EXITED_RETAIN_MS` to a millisecond value / 0 — the `reapExited` path is still
  wired into the reaper, and `tty_list`’s `retainMs` field only appears when a timer is in play.

This is why “`tty_open` a command that finishes and read the result afterwards” now just works — no
`sh` wrapper needed (the request in issue #4).

### Shell integration (OSC 133/7, 0.4.0)

On POSIX, hooks are injected through the existing `-c` wrapper layer according to the shell type; on
Windows the PowerShell family gets a stable `-File` stub instead (see the Windows section above). Both are
transparent to the user and change no rc:

- **zsh**: `ZDOTDIR` points at a temporary stub directory (the same approach VS Code uses); the stub sources
  the user’s original rc first and then appends `precmd`/`preexec` hooks;
- **bash**: an `--rcfile` stub (sources `~/.bashrc` first); the command-start marker has two variants by
  version: bash ≥ 4.4 uses `PS0`; bash < 4.4 (the 3.2 shipped with macOS) has no PS0 and falls back to a
  **DEBUG trap** (the handler filters by `$BASH_COMMAND` to drop fires caused by the PROMPT_COMMAND
  machinery itself, so phantom markers do not cut the user’s output out of the capture window; on bash 3.2
  `trap - DEBUG` inside the handler does not take effect, hence the “permanently armed + filtered” design).
  Side effect: internal commands of compound commands such as loops emit extra B markers, which only affects
  where `tty_capture{last}` starts capturing for those commands — D/exit-code and `tty_expect` are
  unaffected; the PROMPT_COMMAND hook supports both the string and the array (bash 5.1+) forms;
- Marker semantics: `133;A` prompt start / `133;B` command start / `133;D;<exit>` command end with exit
  code / `OSC 7 file://…` cwd reporting (`tty_list.cwd` follows `cd`, and SSH sessions report the remote path);
- Other shells are silently disabled; `shellIntegration: false` turns the whole thing off (escape hatch).

**Look-back matching and the read watermark (D72)**: `tty_expect` first looks back at output that has
**not been read yet** (when a command finishes instantly, the marker you are waiting for is already in the
buffer). The look-back lower bound is raised to “just after the last `B` marker” inside the unread region —
the echo sits between `A` and `B`, so text in the echo never counts as a hit (deliberately no text
comparison here: line wrapping / ANSI / multi-line paste would break it).

- **Environments without `B` markers** (integration off / local Windows cmd tabs / a remote host without
  the hooks / PSReadLine turned off by the user) have no boundary to cut at, so since D75 the echo is
  excluded by a different test: the command
  lines that the most recent `tty_send` submitted are stripped out of the candidate text and the pattern
  is retried — only “no longer matches after stripping” counts as a pure echo. That removes the false
  positive where the command never ran yet the wait reported `matched:true`, while the same text really
  printed later still matches. When the wait times out and the pattern only ever matched the echo, the
  result carries `echoOnly:true` and the message says plainly that the command was probably never
  executed. **Boundary**: only lines written by `tty_send` are known (typing in the panel is not
  simulated as line editing), and stripping is disabled while a command is running (in a full-screen TUI
  redraw, the typed text appearing on screen is real output);
- **The tradeoff in that look-back range**: raising the lower bound to “just after the last `B` marker”
  costs you the unread output that precedes the newest command’s start. It deliberately prefers a miss
  over a false hit — treating the echo as a match would make the agent believe the event just happened.
  Use `tty_capture` for that text. The mirror-image corner exists too: right after `tty_send`, before the
  new command’s `B` marker arrives, the unread region still holds the previous command’s output, so a
  pattern in it matches at once (the agent’s next call almost always lands after that `B`, where this
  text has already been cut off by it);
- **Read watermark**: whatever `tty_capture` / `tty_expect` returns counts as read, and later
  `tty_expect` calls will not look back at it (use `tty_capture` to re-read older output). `tty_screen`
  deliberately does **not** advance it (the screen is a different representation, not a text stream);
  `tty_send` only initialises it (the output of the command just sent has not been seen yet); **a timeout
  does not consume the unread region** either (another pattern can still look back at the same output).
  A tab the user opened gets its watermark placed at the moment the agent first touches it — history
  before that does not count as unread.

SSH sessions are scheduled on the same table: entries with `kind: 'ssh'` in `tty_list` are identified by
`target` (user@host[:port]), and `tty_capture` / `tty_expect` / `tty_send` are used exactly as for local
sessions — dev server logs and key interactions on the remote machine remain available as usual.

### Credential storage (a connection password need not stay plaintext)

Under **Password** in the connection dialog sits a **credential storage** row: tick "store when saving" and the
password is written to the **official credential store**, leaving only an `env:NAME` reference in the field (the value
lives in `~/.dsh/.credentials.yaml`, never materialized into the environment and never sent back to the browser).
**That checkbox is ticked by default** (whenever the host provides `remote.credentials`): type a plaintext password,
save, and the value goes to the store while the settings keep only a reference — better than writing the password
plaintext into the settings file, which *is* shipped to the browser while the store's values never are. When the host
lacks that service the box is switched back off and disabled, with a note that only plaintext saving is available.

- **It rides along with saving — no extra click**: the tick is executed by "save changes" / "connect (and save)", so
  there is no dangling reference from "stored but not saved". **Without "save to the connection book" it never touches
  the store** — there would be no configuration to reference the value, only an orphan. **The settings card's inline
  editor is the same row with the same default**, except that its commit entry point is "apply" (that card's
  row-level commit, followed by the card's "save"), so the checkbox reads "store into credential storage on apply";
  the same caveat applies there: the value lands in the store first, and abandoning "save" afterwards leaves a name
  that is not referenced yet (visible and clearable in the reference picker).
- **Two side effects of the default (so neither is a surprise)**: (1) editing an older connection whose password is
  **plaintext** and hitting "save changes" for an unrelated field also moves the password into the store (the settings
  keep a reference instead) — untick the box if you do not want that; (2) when the store refuses the write (typically a
  read-only source shadowing the reference) **saving is aborted** and the official verbatim error is shown, rather than
  quietly falling back to plaintext (the derived name carries a `DSH_TTY_` prefix plus a hash, so shadowing is
  practically impossible).
- **Deliberately compact**: in plaintext mode the row is a single checkbox; only once the field holds a reference does
  it swap in "clear stored credential" and the status (`already stored (source file) · reference name`). The full
  security boundary lives in the checkbox's tooltip instead of taking up dialog space.

- **Model**: configuration holds a **reference**, the store owns the value — the same family as SecureCRT's
  "credential set referenced by title" and iTerm2's "pick a named entry from the password manager". The
  implementation goes through DSH's official `ctx.remote.credentials` (`describe` / `set` / `unset`, where
  **values cross in one direction only — no read path exists**), exactly as the official settings cards do.
- **Name** (the rule is fixed): `DSH_TTY_<username>_<host>[_<port>]_<field>`, where the port is **omitted when
  empty or 22 (the default)** — matching the connecting side's `spec.port ?? 22` (empty means 22), so
  “empty / `22` / `" 22 "`” all collapse into one key and the same account never ends up with two names or one
  password stored twice; a non-default port does take part (the same host on another port is often a different
  box behind NAT). `field` is `PASSWORD` / `PASSPHRASE`; e.g. `hsadmin@192.0.2.10:22` →
  `DSH_TTY_HSADMIN_192_0_2_10_PASSWORD` (the dots of a dotted IP fold to `_`). It is **derived from the resource identity and carries no hash** — the
  same school as git-credential-store's `protocol://username@host` and docker credential helpers'
  `ServerURL` + `Username`: host and username **are ASCII identifiers already**, so nothing needs sanitizing and
  nothing needs a hash to disambiguate. The old hash-based version was patching over "sanitize a human label into a
  key": the reference grammar accepts ASCII only, so `web 01` / `web_01` (space vs underscore) collapse to exactly the same
  string and only a hash could stop them silently overwriting each other. A resource identity has no such trap — a
  collision can only happen for **the same host, the same user, the same port**, which is the same password by
  definition (sharing it is correct behaviour). **The connection name never takes part in the key**, so renaming a
  connection or rewriting its label never changes the key. An empty host or username is refused (they are the key's
  entire source; drop either and the derivation degenerates into a constant). The trade-off is readability: this
  dialog's "store" **names it by the rule above and offers no custom name** ✗ — to reuse a custom name, type
  `env:name` into the field directly (the name must already resolve in the credential layer, e.g. managed by the
  official settings or env card).
- **Derivation happens only at store time**: afterwards the `env:NAME` in the configuration is the single source of
  truth and nothing re-derives it — so renaming a connection does **not** invalidate a stored value and no longer
  leaves an orphan (only the old hash-based rule did: with the name in the key, storing again after a rename left the
  previous name behind; clear it with "clear stored credential", which acts on the reference in the field).
- **Shared**: references live in one flat namespace, so any consumer resolving the same way can use it — put
  the same name in a dsh-docker target's `password` and one secret serves both.
- **Visibility**: the dialog's reference picker lists **the names the store already holds** — the host-side
  `/api/dsh-tty/credential-refs` reads back only the `refs:` keys (names only; values never leave the host).
  Why read it ourselves: the reference half is **not enumerable** over the protocol (rationale in the picker
  section), yet “which names have I stored” is exactly the question this picker answers. It also makes
  **orphan references** (old names left behind by a naming-rule change) visible, selectable and
  clearable again.
- **Resolution path (what makes a stored value actually usable when connecting)**: connecting, the probe, SFTP
  and port tunnels all funnel through one `buildConnectConfig`, whose `env:NAME` is resolved by the **official
  credential provider** (`resolve`, re-resolved per operation — a change lands on the next operation, no host
  restart). Only when the provider has no such reference, or the host has no such service, does it fall back to
  `process.env`. **Why the provider is mandatory here**: values in the credential store are **never materialized
  into the environment** (the provider README's own words: “a store the harness owns and never materializes into
  the environment”), so reading `process.env` alone means “a stored password is unreadable at connect time”. A
  provider error is never swallowed — when the environment lacks it too, the error names both sources (otherwise
  “the credential service is broken” masquerades as “you did not configure it”).
- **The conservative boundary (know this)**: `~/.credentials.yaml` is a **0600 plain file with no master
  password and no OS keychain** — it keeps out **other OS users**, not processes running as you, and not the
  agent; and it is **machine-local**, so a new machine means storing again. The industry consensus still
  stands: **prefer keys / agent over stored passwords** (this plugin supports both).
- **Degradation**: without `remote.credentials` (older host) the buttons disable with a reason and plaintext
  saving still works.

## Port forwarding (0.5.0)

Maintain tunnels in the “Port forwarding” block of the Settings → Plugins → Terminal Panel card; each tunnel
references one connection-book entry (host and authentication come with it), in two directions:

- **Local forwarding (-L)**: listen on local `127.0.0.1:localPort` → connect through SSH on the server side
  to `remoteHost:remotePort` — maps a remote database/internal service to the local machine (the most
  frequent use: `localPort=5432 → db.internal:5432`);
- **Remote forwarding (-R)**: the server listens on `remoteHost:remotePort` (default
  127.0.0.1) → inbound connections are dialed back to local `localTargetHost:localTargetPort` — exposes a
  local dev server to a remote network/intranet;
- **The host owns the lifecycle**: tunnels and terminal tabs are independent of each other (each has its own
  SSH connection), and tunnels keep running with the panel closed; SSH disconnects reconnect automatically
  with exponential backoff (1s→15s cap), and the remote direction re-runs forwardIn after a reconnect; after
  the connection-book password changes, a reconnect uses the new credentials automatically;
- **Profiles running side by side must offset their localPort**: port forwarding is a **machine-level**
  resource, while the configuration is stored per profile (copying a profile copies its tunnels too). Two
  profiles running the same tunnel at the same time leave the later one with `EADDRINUSE`, stuck in
  `error` with `fatal:true` (**no retry**; changing the configuration rebuilds it from the new spec). The
  error message names “possibly the host process of another DSH profile” and offers two ways out;
- **Ports are probed at save time (0.26.0)**: saving the tunnel configuration first **probes each local
  port** (an exclusive probe: `listen`, then release immediately) so two classes of problem surface at the
  moment you save instead of later — ① the configuration being submitted has two local tunnels on the same
  `localPort` (decidable at configuration level), and ② the port is held by something **outside this
  process** (another profile's host, or another program).
  **The probe only warns; it never blocks the save**: the 200 response carries an extra `warnings` array and
  the card shows it in the **yellow** warning slot (which replaces the green “is active” — that tunnel will
  sit in red `error` and never retry, so “is active” would read as everything being fine). Why not reject:
  the card saves the **whole table at once**, so rejecting would lock a user whose config already contains a
  conflict out of saving *anything* — and fixing it is exactly what requires saving first.
  Two rules worth remembering: a port **this process already holds is exempt** (editing a running tunnel's
  other fields leaves its port held by itself — that is not a conflict, since reconcile stops then starts and
  the port returns in the same tick), while a **disabled** tunnel still counts as a duplicate (it can be
  enabled at any moment). A remote direction's `remotePort` is listened on the server side and is not probed
  locally;
- **Status badges**: while the card is expanded it polls live status every 2s (active green/connecting
  blue/error red/stopped grey + last error); connection-book entries in the “+” menu show a `⇄N` tunnel
  badge; the agent can query status with the `tunnel_list` tool;
- **Connbar entry (0.20.0)**: a connection **with enabled tunnels** gets a permanent “隧道 N” button
  (click for live status); one **without** them folds into a “**⋯ More**” menu — previously such a
  connection gave **no hint at all** that port forwarding existed, so the user had to stumble onto the
  settings card. Folding it into “⋯” adds a discovery path without occupying permanent width (the connbar
  gives its width to the tab strip first). Note a tunnel must reference a connection-book entry, so only
  book-backed connections get this entry; an unsaved ad-hoc connection from the “new connection” dialog
  cannot have tunnels.
- **Form layout (0.20.0)**: direction uses a **segmented control** (local -L / remote -R — two values do
  not deserve a dropdown); the two ends are shown in pairs as **host:port**, with an **arrow** between them
  showing the data flow (it flips when you switch to -R). Each direction has **exactly one fixed end**
  (the host hardcodes it) and that end renders as **static text rather than an input** — an input you cannot
  change would be a lie:
  - `-L`: the left end is fixed at `127.0.0.1` (bound locally, not exposed to the LAN); the right end takes
    the SSH-server-side target;
  - `-R`: the left end takes the SSH-server-side listen address; the right end is fixed at `127.0.0.1`
    (the local service being reached).
  Two styling rules (from a user screenshot: “输入框的样式优化一下”): the group **hugs its content** instead of
  stretching with the row (otherwise the left group leaves a dead zone after the port box, while the right
  group's host soaks up all the slack and pushes the colon and port to the card's right edge); and the inputs
  inside the group **do not paint their own focus ring** — the group is `overflow: hidden`, so a 2px ring gets
  clipped down to a single vertical line that reads like a stray separator; the whole group lights up instead
  (`test/tunnel-endpoint.test.ts` pins that pairing).
- **Editing (0.20.0)**: “Edit” on a row loads it back into the form below and the button pair becomes
  “Save changes / Cancel”. Saving locates the entry by its **original name** — a tunnel name is derived
  (`<book>-L<localPort>`), so changing the port *is* changing the name and the new name cannot find the old
  row; `enabled` **keeps its previous value** (editing a spec never silently enables a stopped tunnel); the
  row being edited gets a left accent bar. **A name clash is reported explicitly** (no more silent `-2`
  suffix, which used to spawn a second tunnel differing only by a trailing number).
- **A failed local listen is sticky**: when the port is taken (`EADDRINUSE`) the state stays red `error`
  with the reason kept, and is **not** rewritten to “connecting” by the SSH-side retry (fixed in 0.20.0).
  Recover by changing the port (with the editor) or freeing it.
  ⚠️ `~/.dsh/settings.yaml` is **shared across profiles**: with several profiles on one machine the same
  tunnel gets started by each of them and they fight over the same local port — a configuration conflict,
  not a plugin bug.
- TOFU shares the same `hostKeys` pinning as terminal sessions; ports do not consume `maxSessions` slots.

## SFTP file transfer (0.7.0, enhanced in 0.8.0/0.9.0)

Remote file operations go straight over the SSH connection without touching the terminal or using a session
slot (`ssh2`’s sftp subsystem, host half in `src/sftp.ts`):

![SFTP single pane (docked in a drawer below the terminal since 0.16.0): browsing a remote directory, with inline download/rename/delete](https://cdn.jsdelivr.net/gh/hyzyn/dsh-plugin-kit@main/docs/dsh-plugin-kit-tty-sftp-dialog.png)

![SFTP dual pane (0.9.0; docked in a drawer below the terminal since 0.16.0): local on the left / remote on the right, with inline ⇨/⇦ server-side direct transfer](https://cdn.jsdelivr.net/gh/hyzyn/dsh-plugin-kit@main/docs/dsh-plugin-kit-tty-sftp-dual.png)

- **Placement (0.16.0)**: when the terminal panel is open and **this tab’s** mount slot is free, the File Browser
  **docks below the terminal** — the path bar / list / transfer progress take the full width (a file list is
  a wide table, so full width below beats a narrow column on the right, and the terminal also keeps its width
  without wrapping; a dual pane side by side needs that width even more), and the terminal stays visible and
  usable. The height is draggable and can collapse into a single title bar (collapsing neither closes the
  panel nor interrupts browsing); when another panel (such as the containers panel) already holds the slot on
  the same tab, or the panel is not open, it falls back to the original centered dialog, **without pushing
  anyone else’s panel out**. The title / collapse / ✕ come from tty’s mount slot;
- **Follows the tab (0.19.0)**: the File Browser talks to the host of the tab that opened it, so it belongs to
  that tab: switching away hides it (in-flight transfers keep running and the scene is restored when you come
  back), and closing the tab tears it down. **Every entry follows the same rule** — the connection bar’s
  “SFTP”, the 📂 on a connection-book entry and “File Browser” in the SSH dialog / settings card all become
  owned by whatever tab was active when they were opened; only “panel open with no tabs at all” counts as
  owned by no tab (always visible). Before this, the pane stayed put across a tab switch — title reading host
  A while the active tab was B, worst case uploading to the wrong host;
- **Entries**: ① connection-book entries in the tab bar “+” menu carry a 📂 (open the File Browser for that
  entry); ② fill in host/authentication in the SSH connection dialog and click “File Browser” (you can
  browse without saving to the connection book); ③ the “SFTP” button in an SSH tab’s connection bar (owned by
  that tab, see the previous bullet);
- **Operations**: directory browsing (Enter in the path box to jump, `.. (parent directory)`, a single click
  on a file downloads it), **upload** (multi-select files, XHR streaming + percentage progress; since 0.8.0
  **drag & drop** is supported — files and folders can be dropped straight into the dialog, folders are
  expanded recursively through `webkitGetAsEntry` and uploaded one by one, and directories are filled in
  level by level with mkdir parents), **download** (POST → browser Blob
  → `<a download>`), **new directory**, **rename** (inline editor), **delete**
  (🗑 with a second click to confirm, directories deleted with `recursive`);
- **Transfer progress bar (0.11.0)**: a thin progress bar + percentage was added on the right of the bottom
  status line — uploads use XHR streaming progress (multi-file shows an `i/n · filename` label); downloads
  now stream `response.body` and compute the percentage live from the response `content-length` (with no
  length it degrades to a transferred-bytes text);
- **Cancelling a transfer (0.12.0)**: the ✕ on the right of the progress bar — **upload** aborts the
  in-flight XHR (remaining files in the batch are skipped too); **download** uses `AbortController` to break
  off the streaming read; **dual-pane ⇨/⇦ direct transfer** became a server-side job (start returns a jobId
  → 400ms polling of real byte progress → ✕ sends cancel to abort), no longer an unbreakable synchronous
  HTTP request. After a cancel the **half-written file is deleted automatically** (the leftover remote file
  of an upload / the leftover local file of a download; a failed cleanup is only logged), the status line
  reads “cancelled” instead of a red failure state; closing the File Browser dialog also collects in-flight
  transfers, leaving no background copying that is “invisible but still writing to the remote”;
- **Connection management**: a lazy connection pool — the SSH connection is created on the first operation,
  recycled after 120 seconds idle, and reconnected automatically on the next operation after a drop;
  connection-book entries are resolved live on every (re)connect (a changed password takes effect
  automatically); TOFU shares the same `hostKeys` pinning with terminal sessions/tunnels, and a changed
  fingerprint is rejected the same way; SFTP does not count against `maxSessions`;
- **Resumable downloads (0.25.0, panel downloads)**: when a download drops, it **resumes from the bytes
  already received** — the host's `/sftp/download` route now accepts `offset` (`>0` returns 206 +
  `content-range` with `content-length` reporting the **remaining** length; `offset ≥ file size` returns 416
  rather than a zero-byte 200, so “what you wanted is already local” is never mistaken for “the file is
  empty”). The rules live in the pure module `client-src/download-resume.js` (`planResume`): **clicking ✕
  never resumes** (cancel means “stop”, auto-retrying ignores the user), zero progress never resumes, the
  retry budget is capped (3 by default), and the progress bar does **not** reset to zero while resuming.
  Directory-level direct transfer (dual-pane ⇨/⇦) still sends everything again;
- **Dual-pane drag & drop and hidden files (0.25.0)**: drop a file/folder from the file manager onto the
  **right-hand remote pane** to upload it into that pane's current directory (folders are expanded through
  `webkitGetAsEntry` and filled in with `mkdir parents`, same as the single-pane path); dropping onto the
  **local pane** says explicitly that there is nothing to do instead of failing silently — the rule lives in
  `client-src/sftp-view.js` (`planDrop`). Each pane's toolbar gains a “Hidden files” toggle (off by default,
  preference kept in localStorage) so `.env` / `.gitignore` can be shown on demand; **filtering happens only
  in the render layer** — the host `list` and the agent's `sftp_list` always return every entry (an agent
  that cannot see hidden files draws wrong conclusions);
- **Transfer channel**: `POST /api/dsh-tty/sftp/list|mkdir|rename|remove|download|
  upload` (all loopback-fenced). `download` also accepts an optional `offset` (resume). The connection spec travels in the JSON body (connection-book name or
  inline fields, with the same semantics as WS ssh frames: “entry as the base + inline per-field overrides”)
  or, for upload, in the `x-dsh-sftp-meta` header (base64url) — **credentials never enter the URL/query
  string**; uploads and downloads are streamed pipes, and a whole file never enters memory;
- **Agent tools**: `sftp_list` / `sftp_read` / `sftp_write` / `sftp_mkdir` /
  `sftp_rename` / `sftp_remove` / `sftp_tree` (see the table above) — they accept only a
  `book` connection-book entry name and **take no inline credentials** (agent context never carries plaintext secrets);
- **Dual-pane style (0.9.0, optional, `sftpStyle` configuration)**: local left / remote right — browsing and
  file operations on the local side go through the new `/api/dsh-tty/local-fs` route (list/mkdir/rename/
  remove, loopback-fenced); the inline `⇨ / ⇦` copies an entry to the current directory of the opposite pane
  (`/api/dsh-tty/local-fs/transfer` streams the two paths server-side, recursing into directories and
  overwriting same-named files, **with bytes never passing through the browser**); the single-pane style is
  unchanged; switch it in the settings card and reopen SFTP for it to take effect.

## Session persistence (tmux, 0.10.0)

The default safety model is unchanged: sessions live and die with the host (kernel-level PTY cleanup). For
work that must “outlive the host” (dev servers, builds, training jobs), turn on a **persistent terminal** —
session state is delegated to a tmux server (a dedicated socket, fully isolated from the user’s own tmux),
so it survives the keep-alive timeout and can even be reattached after a host restart:

> **The socket is profile-scoped** (since 0.25.0): `tmux -L dsh-tty-<profile>`, and the runtime assets
> (`tmux.conf` / `inner.sh` / shell stubs under `<DSH_HOME>/tty/<profile>/`) are layered the same way — with
> several profiles running, each sees only its own persistent sessions and `kill-server` only affects its
> own. **A host started without a profile keeps the historical `dsh-tty`** (and `<DSH_HOME>/tty/`), so a
> single-profile user sees no path or behaviour change after upgrading.

- **Entry (simplified in 0.10.1)**: choosing `tmux` for “Session persistence” in the settings card is the
  only switch — once it is on, **every newly opened tab is persistent by default**: “Local terminal” in the
  “+” menu, clicking a connection-book entry, and the SSH connection dialog (“persistent session” is checked
  by default and can be unchecked for a single connection). There is no longer a separate “persistent
  terminal” menu item;
- **Per-entry opt-out (`sshHosts[].persist`)**: the “persistent session” checkbox on a connection-book entry
  stores an **opt-out** — entries explicitly unchecked (`persist: false`) are no longer tmux-backed when
  clicked, everything else (`true` or never written, e.g. entries imported from `~/.ssh/config`) follows the
  global switch. Both the settings card and the connection dialog show that checkbox only while the global
  switch is on, and **editing an entry in the settings card no longer drops it** (before 0.17.x, renaming a
  single field silently reset it to `false`);
- **Mechanism**: spawn/ssh frames carry `persist` plus a stable `persistName` generated by the client and
  saved with the tab spec — locally the `-c` wrapper layer becomes `exec tmux -L <socket> -f
  <conf> new-session -A -s dsh-<name>` (cwd is inherited from the node-pty spawn); over SSH the remote runs
  `exec tmux -L <socket> -f /dev/null new-session -A -s dsh-<name>` to open the pty channel
  (`<socket>` = `tmuxSocketName()`, profile-scoped since 0.25.0). `-A` is
  attach-or-create: after a host restart, reopening a tab reattaches to the same tmux session by name,
  restoring running programs and pane state exactly;
- **Recovery chain**: after the browser reconnects it queries `sessions` — persistent tabs whose sid is gone
  are respawned automatically by the client with the original persistName (non-persistent tabs keep the drop
  semantics); when the keep-alive reaper times out it kills only the PTY (the tmux client) and **not the tmux
  session**, so it can still be reattached afterwards; a reconnect (attach) within the same host does **not
  replay the host buffer** for a tmux session — replaying would first write the visible screen into a
  brand-new xterm (ghost scrollbar) and then the tmux full-screen redraw would paint it again (double image)
  — instead it forces exactly one `tmux refresh-client` redraw;
  persistent tab specs are also written to **localStorage** (sessionStorage is visible only to the same
  browser tab, so a new window that dsh opens automatically after a restart could not read it and recovery
  broke exactly there) — when a brand-new window opens the panel it respawns straight from the spec: if the
  tmux session is alive it reattaches to the original scene, and if it is gone (remote reinstall/lost) it
  starts a new shell; specs are only dropped when “the tab is actively closed/exited”, with no up-front
  liveness check (once the retained state such a check relies on drifts, recovery would fail silently);
- **Close semantics**: for a tmux-backed session the kill frame (tab ✕ / closing the panel) runs
  `tmux kill-session` before killing the client — a real end, not a detach that leaves a live session
  behind; closing the whole page **retains** by default (recoverable after the keep-alive window), while
  `endOnPageClose: true` also ends the tmux session when the keep-alive window expires;
- **Shell integration compatibility**: tmux swallows escape sequences it does not recognize — the hooks
  detect `$TMUX` and wrap OSC 133/7 in a DCS passthrough envelope (ESC inside the payload is doubled), and
  with tmux ≥3.3 + `allow-passthrough on` (written into the stub conf by the host automatically) it is
  unwrapped and forwarded, so the host parser still sees bare markers: `tty_expect` / OSC 7 cwd tracking keep
  working inside persistent tabs; `tty_capture{last}` has one further correction — tmux pane redraws are
  asynchronous and batched, so command output can land after the D marker and escape the capture window, so
  the hook runs `capture-pane` before emitting D and sends the pane content inline as `OSC 133;T` (base64,
  last 200 lines), and the host prefers the T snapshot as the command output (output beyond 200 lines is
  truncated at the head, consistent with the ring-buffer semantics);
- **Runtime assets**: a stable stub directory under `<DSH_HOME|~/.dsh>/tty/` (the tmux server outlives the
  host process, so a temporary directory will not do): `tmux.conf` (status off to keep redraws from
  polluting captures, true-color overrides, `default-command` pointing at the inner launcher) and `inner.sh`
  (execs the inner shell from the current configuration, with the zsh ZDOTDIR / bash --rcfile stubs injected
  as usual); configuration changes apply hot to newly opened panes, while `tmux.conf` itself is read only
  when the tmux server first starts;
- **Degradation**: with no tmux installed locally/remotely, a persistent spawn falls back to a normal session
  automatically and the terminal prints a grey one-line hint; everything works fine without installing
  anything, just without persistence.

## SSH connections

Since 0.2.0 the tab bar “+” is a one-click menu that, besides local terminals, also opens **SSH tabs**: the
host half connects natively with `ssh2` and opens a shell channel (no local ssh process and no node-pty),
wrapped into a session object identical to a local PTY — input, resize, close, output buffer, backpressure
and the agent tools all reuse the same scheduling.

- **Three entries in the “+” menu**: local terminal / **SSH connection book** (entries saved in the
  configuration, shown as `user@host[:port] · auth`, **entries carry 📂 File Browser and ✎ edit**) / SSH connection…
  (a form for host / port / username / auth with an option to save before connecting, and a “File Browser” at
  the bottom of the dialog to open SFTP with the current information, skipping the terminal);
- **Connection book**: ticking “save to connection book” in the SSH connection dialog stores an entry (the
  same name overwrites; an empty name uses the hostname); the ✎ on a “+” menu entry and the **edit** in the
  settings card use the **same form** — three grouped sections (connection / authentication / options) plus
  credential storage, the credential-reference picker, “test connection” and “File Browser”, renaming
  supported and duplicate names rejected. The “Book name” row is **always visible** (0.31.0): typing a name
  **automatically ticks** “save to connection book”, clearing it **automatically unticks**, and unticking by
  hand clears the name too — what a click will save is always what the form shows. The dialog itself is a
  **three-part shell** (0.31.0): the title
  and the bottom action row are pinned and **only the middle scrolls**; the low-frequency items (jump host /
  proxy command / host key alias) live in an “**Advanced**” disclosure that starts expanded when the entry
  actually has them and collapsed otherwise (when collapsed, that row names what is configured — it is not a
  black box). The only difference is **how it is submitted**: the menu dialog
  (“save changes” / “connect (and save)”) writes through immediately, while the settings card commits into the
  card's form with “apply” and persists with the card's “save”;
- **Authentication (auth), one of three**:
  - `agent` (default) — uses ssh-agent (`SSH_AUTH_SOCK`), credentials never touch disk, most recommended;
  - `key` — `keyPath` private key file (a leading `~` may omit home), `passphrase` optional;
  - `password` — password authentication, with keyboard-interactive attached as well (many servers only offer that);
- **Passwords / passphrases support `env:VAR`**: when `password` / `passphrase` is `env:MY_SECRET`, the value
  is resolved through the **credential layer** — the official credential provider first (layering
  `$DSH_HOME/.credentials.yaml`, the process environment, `project-env` and `user-env`, re-resolved on every
  connection), falling back to the host process environment only when the provider has no such reference
  (pair it with the dsh-env-manager plugin to hold secrets, keeping plaintext out of the settings file). A
  failed resolution names both the reference and the fact that neither source had it;
- **Port**: 22 by default; a non-22 port shows in the target as `user@host:port`;
- **Tabs and status**: an SSH tab title uses the connection name or `user@host` (local tabs are
  “Terminal N”); while connecting it first echoes a grey `Connecting user@host …`, and once ready the status
  bar shows `SSH user@host connected`; a failed connection (connection timeout / authentication rejected /
  host unreachable) comes back in an `error` frame with the reason, and since the tab spec was saved with the
  tab, clicking the terminal area reopens it from the original spec; the status bar describes the **currently
  active tab** — switching or closing a tab immediately swaps in that tab’s own state (the failure reason and
  the exit code are kept on the tab itself), so the red text no longer stays on screen after you close the tab
  that could not connect (host-level messages such as “connection lost — reconnecting” belong to no tab and
  are not wiped by a tab switch); conversely, **a background tab’s own failure is only recorded on that tab**
  (its tab-bar status dot turns red and the terminal overlay carries the full text) and never takes over the
  active tab’s status;
- **Agent forwarding (0.4.0)**: with “agent forwarding” ticked in the SSH dialog, the remote side can use the
  local ssh-agent’s keys (such as `git clone` of a private repository remotely). It can be enabled with any
  authentication method (credentials still never touch disk); if no ssh-agent is running locally the
  connection fails with an explicit error instead of silently doing nothing. Connection-book entries save
  `agentForward` and show `· fwd` in the list;
- **`~/.ssh/config` import (0.4.0)**: “Import from ~/.ssh/config” in the connection-book area of the settings
  card — parses `HostName/User/Port/IdentityFile` into candidate entries (skipping wildcard blocks and
  entries without a User; `Include` is not expanded), skips same names, and writes them on “save”.
  **Every skip is now reported** (this round): blocks that depend on a jump host (`ProxyJump` /
  `ProxyCommand`) are **not imported and are named** — this version does not support jump hosts, and
  importing one would only produce an entry that cannot connect and reports a generic timeout; the
  over-limit count and the “not a concrete host” count are reported too. `ProxyJump none` /
  `ProxyCommand none` mean an explicit direct connection and are imported as usual.
  **`ProxyJump` is resolved into the entry's jump host (single hop) and imported with it**: the
  value may be `user@host:port` (IPv6 as `[::1]:22`) or another concrete Host in the same config
  (resolved by block name, in any order); the jump host **inherits the target hop's credentials**
  by default, so set `jump.keyPath` / `jump.password` on the entry when it needs its own.
  Unresolvable ones (missing alias, or an alias that itself needs a jump) are still skipped and
  named; `ProxyCommand` is not supported (it would let a settings field drive arbitrary local
  command execution — a different trust tier, see project ROADMAP item 2). **The dialog also has a “Jump host” section**: one
  `[user@]host[:port]` input (matching OpenSSH), with user / auth / key / passphrase overrides
  revealed only after ticking “use separate credentials”; entry rows show “⇢ via X”, and the
  “Test” button reports the jump hop on its own line;
- **Credential-reference picker (0.4.0; decoupled from the env plugin since 0.17)**: next to the password /
  passphrase fields in the SSH dialog there is a filter box plus a height-limited list whose candidates are
  **the reference names the credential store already knows** (the host reads the `refs:` keys of
  `.credentials.yaml` — **names only, never values**) ∪ **the reference names this machine's connection book
  already uses**; clicking one fills in `env:NAME`, and any `env:NAME` can still be typed by hand (resolution at
  connect time goes through the **credential layer**: the provider first, `process.env` as the fallback).
  **Why read the file / why not the env plugin's managed list**: the official discovery path for references is
  "a configuration surface learns which references exist **from its own settings schema**" — the reference half is
  **deliberately not enumerable** (the wording in `@deepseek-ai/dsh-credentials`'s `listRecords` docs: “the
  reference half, which has no enumeration because configuration surfaces learn which references exist from
  settings schemas”), and the browser-side `ctx.remote.credentials` opens only `describe` / `set` / `unset` — not
  even `listRecords`. So “what names does this store actually hold” is unanswerable in the browser, while the
  picker's whole purpose is exactly that question. The host therefore exposes a **read-only** route,
  `/api/dsh-tty/credential-refs` (behind the loopback fence; it parses `refs:` keys and never returns values —
  see `readCredentialRefNames`). This is a **deliberate departure** from the official “references are not
  enumerable” design (cost: reference names reach the browser, values never do); to stay strictly on the official
  route, use only the connection-book half. Boundaries: references behind a custom provider `path` / `dshHome` are
  invisible here, and when the host read fails (or an older host lacks the route) the candidates quietly fall back
  to the connection-book half.
  When there are no candidates at all, the row **degrades to a single explanatory line** (rather than an input
  that can never open, which just looks broken): it says either to tick “store on save” above, or to type
  `env:NAME` into the field. The passphrase row has no checkbox above it, so its wording only mentions typing.
  **The settings card's edit form has the same row with the same candidates** (also opening only when the filter
  box takes focus); the only difference is presentation — there it is an **inline** list rather than an overlay,
  because that card is a long scrollable form where an overlay would be clipped;
- **Host-key TOFU pinning (0.3.0)**: after the first successful connection the host’s (host:port) sha256
  fingerprint is recorded in `hostKeys` (persisted with settings); every later connection is verified, any
  fingerprint in the set matches, and **a changed fingerprint rejects the connection outright** (defense
  against impersonation), with a reset pointer in the error message. A host’s multiple keys (0.19.0, e.g.
  rsa + ed25519) are each recorded and merged into one record — algorithm negotiation changes no longer
  cause false alarms. After a host reinstall or key change,
  delete the record under Settings → Plugins → Terminal Panel → “SSH host key
  records” and reconnect (the record list supports deletion). **“Import from known_hosts”
  (0.4.1)**: parses `~/.ssh/known_hosts` in one click to pre-fill existing host fingerprints in bulk, keeping
  all of a host’s rsa/ed25519 entries (no longer first-entry-only); host
  names from the connection book are also used to restore `|1|` hashed entries, and non-default ports are
  parsed as `[host]:port`;
- **Host-key alias (`hostKeyAlias`, 0.25.0)**: TOFU records and comparisons are located by **connection
  address** by default, but one real host is often reached through several addresses — the internal IP behind
  a bastion, or `127.0.0.1:2222` through a port forward. “Same key, different record” then makes every
  address switch look like a **fingerprint change** (a false MITM alarm that **rejects the connection**),
  while the user’s `known_hosts` only has one line. Filling in the same alias lets those addresses share a
  single host-key record. Semantics match OpenSSH’s `HostKeyAlias`: **it only decides where the fingerprint
  is stored, never the connection address**; empty means address-based (byte-for-byte the old behaviour).
  A `HostKeyAlias` in `~/.ssh/config` is **imported as-is** (it is a purely local locator with no executable
  component, a very different trust level from `ProxyCommand`). All four connection points (terminal / SFTP /
  tunnel / test probe) share one key derivation, so “the test says it matches, the real connection says it
  changed” cannot happen;
- **Connection test (0.11.0)**: a “Test” button on each connection-book row of the settings card, plus a
  “Test connection” button in the SSH connection dialog — both perform **link diagnostics only** (no session,
  no `maxSessions` slot, no shell): first a TCP pre-check (DNS + connect, failures classified as
  refused/timeout/DNS/unreachable), then the ssh2 handshake for a host-key TOFU comparison, and finally
  authentication. The result is shown stage by stage: on success the elapsed time and “host key matched /
  recorded”; on failure the exact stage reason (such as “authentication rejected: all methods failed” or
  “host key mismatch” with the recorded and current fingerprints plus a reset pointer). **The connection-book
  “Test”** does full TOFU: the first test records the new fingerprint into `hostKeys` (the same semantics as a
  real connection); **the dialog “Test connection”** only compares without persisting (a draft not yet stored
  establishes no pinning).
- **Counts against the `maxSessions` concurrency limit**; closing matches local sessions: the tab ✕ / the
  `kill` frame closes the ssh2 channel, and the `exit` frame brings back the exit code / signal as usual.

## Server status bar (0.17.0)

![Terminal panel (with the server status bar): a thin monitor bar above the terminal showing CPU / memory / disk / cores / uptime / TCP / network speed](https://cdn.jsdelivr.net/gh/hyzyn/dsh-plugin-kit@main/docs/dsh-plugin-kit-tty-stats.png)

(The screenshot shows a **local session**; an SSH session’s status bar is the same bar with the same fields — see the single-pane SFTP screenshot below, where the bar above the terminal shows the remote host’s metrics.)

Every **visible** tab gets a thin status bar above the terminal showing the resource metrics of the host the
session belongs to (visually aligned with FinalShell’s session monitor bar):

    CPU ▮▮▯▯ 6% │ Mem ▮▮▮▮ 78% │ Disk ▮▮▮ 63% │ Cores 16 │ Mem 49.6G/62.3G │
    Uptime 2w4d7h16m │ TCP 570 │ Disk 40.8G/68.8G │ CPU Temp n/a │ Network ↓92.3K/s ↑93.1K/s

- **Two collection paths, one frame shape**: for an SSH session a second **non-PTY exec channel** is opened
  on **the same ssh2 connection**, running a resident loop on the remote that emits one line of JSON per
  second (rates such as CPU%/network speed are computed remotely); local sessions are sampled by the host
  itself (Linux reads /proc directly, macOS uses os/netstat/vm_stat). Neither path touches the PTY data stream.
- **Remote platform coverage: Linux / Windows**: a POSIX sh + awk script runs by default; if the channel ends
  **before a single frame of data has been read** (cmd.exe / PowerShell on Windows cannot parse the script),
  it automatically retries once with the PowerShell version (`-EncodedCommand` delivery, same field shape),
  and only fails when both hops fail — macOS/BSD remotes are exactly this path (no /proc and no PowerShell).
- **Subscription-based, lazy start**: the client sends `{t:'statsOn'}` / `{t:'statsOff'}` according to tab
  visibility, and the host starts collecting only on the first subscription; unsubscribing clears it, and
  session exit, orphan reaping, plugin disable and configuration off all stop the meter and close the remote
  channel, leaving no timers or remote loops.
- **Best-effort**: a field that cannot be obtained is omitted (the frontend shows “n/a”); a collection
  failure silently stops the meter and hides the whole status bar (it collapses after **8s** without a new
  frame — not 3s: when a sampling subprocess on the host occasionally slows down, frames get further apart,
  and too tight a window makes the whole bar blink) — it never writes to the PTY and never raises an error.
  Progress-bar thresholds: <70 normal / 70~90 yellow / >90 red.
- **A slow command cannot stall the cadence**: subprocess-backed fields (df / netstat / vm_stat) are awaited
  only on the very first sample; afterwards the sampler uses the last known value and refreshes in the
  background, so a command that hangs on some machine only leaves that one field briefly stale instead of
  stretching the one-frame-per-second timeline (measured: 3000ms → 3~12ms per frame).
- **Hot effect**: turning `statsEnabled` off stops collection at once (the status bar disappears and no more
  stats frames go over the WS), and turning it back on restores automatically from the subscriptions still in
  place — no restart and no need to reopen tabs.
- **Fixed slots + incremental repaint**: every value owns a fixed-width character slot (right
  aligned, so even the widest form only takes that one slot), and the items are built once — afterwards only
  text that actually changed is written. Hence `CPU 5% → 12%`, `TCP 36 → 1024` and
  `memory 9.2 GB → 17.8 GB` no longer push every following item sideways (which showed up as the whole bar
  jumping once a second), the progress-bar width can finally animate through its CSS transition, and
  horizontally scrolling to `Network` in a narrow window is no longer snapped back to the start by the next
  refresh.

## AI assist: explain failures (0.24.0, off by default)

When a command **exits non-zero**, a low-key chip showing the exit code appears in the corner of the
terminal; clicking it sends **the tail of that command's output** to the model and renders a short
"what happened / next step" answer.

- **Zero input, never automatic**: the chip only says "this failed — want a look?". Sending terminal
  content off the machine is always a user click. `Ctrl-C` (130) and `SIGPIPE` (141) never raise it (they
  happen all day; raising it for them just gets the feature turned off), and neither does a missing exit code.
- **What is sent**: the output tail of that one command (colors and `\r` progress lines stripped, repeated
  lines collapsed, truncated to 40 lines / 6000 chars, keys / tokens / passwords in connection strings
  masked) **plus the current screen** — never the scrollback. The two are complementary: the output answers
  "what did this command do", the screen answers "which command was it" (an empirically confirmed fact:
  the captured output contains **no command echo**).
- **Using the answer**: the popover header carries the exit code as a pill; a suggested command is rendered
  as a "Suggested command" block with an **Insert command** button that only types the bytes into the prompt
  line (sending `Ctrl-U` first, to clear any half-typed input) and **never presses Enter**; Copy and Close
  sit next to it. With no suggested command the block is simply absent. The answer lives in the panel UI only
  and is never echoed into the terminal.
- **Errors are actionable too**: when the host fails (no model route, a provider error, a timeout) the popover
  shows a copyable "Copy error" button rather than a dead line of red text with no buttons.
- **One call per failure**: the answer is cached per failed command — closing the popover and clicking the chip
  again replays it instead of asking again, and only a previous **error** retries. The host additionally
  de-duplicates in-flight asks per session, so two tabs clicking at once cannot spend two calls.
- **Model route**: candidates come from the host's registered model catalog (`provider` / `model` as a
  **pair**; leave it empty to follow the host default model). When nothing resolves, the panel says
  "no usable model route" instead of doing nothing.
- **One control for the pair**: `provider` and `model` are a pair, and neither stands alone (the host
  rejects a half-filled route), so the card has a single **Model route** field written as `provider/model`.
  Focusing it lists the host's registered providers grouped together (the whole table arrives in one round
  trip) and one click fills **both** keys; you can also type, split at the **first** slash (a model id may
  contain slashes itself: the control is **read-only** — **no manual entry**, because the candidates are exactly
  what the host can route, and an empty catalog would mean DSH's own chat cannot pick a model either. The
  candidates are a **floating** list (it never shifts the card's layout), the first row is always "Follow the
  host default model" (leave it empty to follow), and the currently effective route is highlighted.
- **A failed fetch says so**: the panel keeps "candidates unavailable — the host may not have restarted"
  apart from "the host advertises no models" instead of blurring them into one sentence. This route comes
  from the host half, so a page refresh alone will not make it appear.
- **Privacy**: off by default. Turning it on authorises terminal content to leave the machine — only the
  excerpt above, and lightly masked before sending (explicit-form secrets only; normal log lines are never
  mangled).

## Configuration (Settings → Plugins → “Terminal Panel”, saving takes effect immediately)

Where the settings surface lives depends on the DSH version, but it is always the **same form**: from
`0.2.0-rc.1` it is registered as `plugins.bundle.config` — **inline on the plugin detail page, directly
below the description**, with no extra ">" step; older hosts (the 0.1.6 line) fall back to the row's ">"
sub-page under the Plugins sidebar, and `≤0.1.5` uses the settings-page card.

| Item | Default | Description |
| --- | --- | --- |
| `enabled` | true | Disables the whole plugin (needs a restart) |
| `announceToAgent` | true | Whether to announce the terminal panel capability to the agent (systemPrompt injection) |
| `maxSessions` | 4 | Concurrent PTY session limit (1~16) |
| `shell` | `$SHELL` | Shell path; the settings card offers a picker and free input (its dropdown is a **floating** list that never shifts the card's layout; candidates come from `/etc/shells` + `$SHELL` + common install paths, listing only existing and executable ones, with `$SHELL` first), and any path can also be typed |
| `term` | `xterm-256color` | TERM value |
| `colorTerm` | `truecolor` | COLORTERM value |
| `cwd` | host startup directory | Fallback working directory (the client’s current session cwd wins) |
| `reconnectGraceSec` | 120 | Seconds a session is kept alive after an abnormal disconnect (0~3600): the session survives a page refresh/network blip waiting for a reconnect, and the reaper ends it on timeout; `0` = the old behavior, end immediately on disconnect |
| `sshHosts` | `[]` | SSH connection book (selectable in the panel “+” menu): entries `{name, host, port=22, username, auth=agent\|key\|password, keyPath, passphrase, password, agentForward, hostKeyAlias='', persist=false}`; saved as a whole-set replacement, the same name overwrites; `password` / `passphrase` support `env:VAR` references so no plaintext is stored; with persistence on, clicking an entry opens a tmux persistent session by default, and `persist=false` is an **opt-out**; an empty `hostKeyAlias` locates fingerprints by host address (TOFU), while a non-empty one locates them by alias (several addresses of one host share a record — see “SSH connections”) |
| `hostKeys` | `[]` | SSH host key records (TOFU, maintained automatically): entries `{host, port, fingerprints[]}` (the legacy single `fingerprint` field is migrated and merged on read); unique by host:port, one record holds all of a host’s keys, appended automatically on the first connection, any matching fingerprint is allowed, and a full mismatch rejects the connection; the settings card can delete them to reset |
| `shellIntegration` | true | Injects the OSC 133/7 shell integration (command boundary markers + cwd reporting; `tty_capture{last}` depends on it); zsh/bash on POSIX and the PowerShell family on Windows (`-File` stub), other shells (including Windows cmd) skipped automatically; can be turned off when compatibility problems appear |
| `tunnels` | `[]` | Port-forwarding tunnels: entries `{name, bookName, direction=local\|remote, localPort?, remoteHost?, remotePort?, localTargetHost?, localTargetPort?, enabled}`; `bookName` references a connection-book entry for host and authentication; maintained graphically in the “Port forwarding” block of the card |
| `sftpStyle` | `dialog` | SFTP File Browser UI style: `dialog` single pane (remote directory + upload/download/drag & drop) / `dual` two panes (local left / remote right, inline `⇨/⇦` server-side direct transfer); reopen SFTP for it to take effect |
| `persistence` | `off` | Session persistence: `off` sessions live and die with the host (default); `tmux` makes **every newly opened tab hosted by the tmux server by default**, recoverable across a host restart (requires tmux locally/remotely); the SSH dialog can opt out for a single connection |
| `endOnPageClose` | `false` | Whether to end the tmux persistent session as well when the page (the last connection) disconnects and the keep-alive window ends. `false` by default = retained and recoverable; `true` = nothing is kept alive once the page is closed (a refresh within the keep-alive window still reattaches seamlessly) |
| `sftpLimits` | `{maxDownloadMb: 1024, maxUploadMb: 2048, maxUploadFiles: 1000}` | SFTP transfer limits (browser-side guardrails, all **0 = unlimited**): `maxDownloadMb` per-file download limit (over the limit it aborts and suggests the dual-pane `⇦`/terminal scp), `maxUploadMb` per-file upload limit, `maxUploadFiles` files per batch/drag & drop upload; for large files use dual-pane `⇨/⇦` server-side direct transfer (bytes never pass through the browser, no memory cost) |
| `assistEnabled` | false | AI assist: explain failures (0.24.0). **Off by default**: when on, a chip appears after a command exits non-zero, and clicking it sends that command's output tail (cleaned, de-duplicated, truncated, secrets masked) plus the current screen to the model — never the scrollback. A suggested command is only typed into the prompt line, never submitted. While off the host also rejects `/api/dsh-tty/assist` |
| `assistProvider` | `''` | Model route provider for the AI assist; must be set **together** with `assistModel` (both empty = follow the host default model). Setting only one has no effect and does **not** silently fall back |
| `assistModel` | `''` | Model route model for the AI assist; pairs with `assistProvider` |
| `statsEnabled` | true | Server status bar (0.17.0): collects and pushes CPU / memory / disk / uptime / TCP connections / network speed / CPU temperature by tab visibility; turning it off stops the meter at once (the remote exec channel is closed too), and saving takes effect immediately |

## Connection-bar extension point (client service `ttyConnbar`, 0.13.0)

Other plugins can append their own contextual buttons to the SSH connection bar (the row with the SFTP /
tunnel buttons) without tty knowing about them — tty only exposes one generic client service. **The built-in
actions (reopen / SFTP / tunnel) go through the same registration channel**, and display order = registration
order; with no extension registered the behavior is exactly as before.

```js
// Optional injection in a consumer's own client half (e.g. dsh-docker): it never fires when tty is absent
ctx.inject(['ttyConnbar'], (c) => {
  const dispose = c.ttyConnbar.addAction(({ tab, spec, bookName, addAction }) => {
    // Called once per renderConnbar; decide for yourself whether to add a button this time
    if (spec.t !== 'ssh') return
    addAction(iconSvg, 'Containers', 'Open the Docker container panel for this host', () => { /* open your own panel */ })
  })
  // Call dispose() on unload
})
```

| Member | Description |
| --- | --- |
| `addAction(factory)` | Registers a button factory; returns a deregister function. `factory` receives `{tab, spec, bookName, addAction}`: `spec` is the session’s spawnSpec (`{t:'ssh', name?, host, port, username, ...}`), `bookName` is the connection-book entry name (`''` for an inline connection), and `addAction(icon, label, title, onClick)` appends a button using tty’s button style |
| `requestRender()` | Asks tty to re-render the connection bar (for when a consumer has new data asynchronously and needs the button to appear immediately) |

- It only fires on **SSH tabs**; the connection bar of a local tab is hidden anyway.
- **Command tabs do not fire it** (`spawnSpec.command` non-empty, i.e. a tab running a command through
  `ttyTerminal.open`, such as dsh-docker’s `docker exec -it …`): those connection-bar extensions act on
  **the connection itself**, and hanging them on a command tab would mislead (SFTP would browse the host,
  not the inside of the container the user has in mind). Built-in and third-party actions are hidden
  together; the reopen entry point for an exited tab is not affected — the terminal body already carries a
  “click to reopen” overlay.
- A throwing factory is only logged with `console.warn`, without affecting the connection bar or the built-in buttons.
- The service name `ttyConnbar` is not declared on tty’s `Context` type surface, so consumers can inject it by
  string; when tty is not installed or is older than 0.13.0 the injection never fires, so consumers must treat
  it as an optional dependency.

### Terminal command tabs (client service `ttyTerminal`, 0.14.0)

An extension point one step beyond connection-bar buttons: it lets other plugins **open a tab that runs a
single command** (the typical use is dsh-docker’s card “Terminal” button → `docker exec -it <container> sh`).

```js
ctx.inject(['ttyTerminal'], (c) => {
  c.ttyTerminal.open({
    command: "docker exec -it 'ems-consumer-test' sh",  // required, single line, ≤2000 characters
    book: 'lab-a',        // one of the two: connection-book entry name → SSH tab
    // spec: { host, port, username, auth, agentForward },  // inline SSH fields
    // (neither = local tab, with cwd giving the working directory)
    label: 'ems-consumer-test · exec',
    cwd: '/optional/local/cwd',
  })
})
```

- Command tabs are **not persisted in tmux** (commands are short-lived and attaching is meaningless) and do
  not go through a login shell; the SSH side uses `conn.exec(command, {pty})`, and the local side uses
  `sh -c 'export TERM=…; exec <the same shell> -c <command>'` — the outer `exec` makes the process
  the command itself (faithful exit code and signal), and the **inner `-c`** is what makes the whole
  string run as shell code: `cd x && cmd`, `a; b`, `for …; do …; done` all run to completion
  (D78: the old form appended the command straight after `exec`, so only the first one ran and a
  builtin such as `cd` ended the wrapper shell outright).
- **Command tabs reopen automatically**: after a host restart / reconnect the sid is gone, and the client
  re-runs the command from the original spec for tabs with `spawnSpec.command` (ordinary non-persistent tabs
  keep the old “click to retry” behavior). After a page refresh they are restored by the original command too.
- The command comes from a **host-side plugin** (not from remote user input), so its trust level equals the
  plugin’s own; tty only validates the shape: non-empty, single line, length ≤2000 (a newline would break the
  local `-c` wrapper layer).
- **“Single line, ≤2000” is this channel’s rule, not `tty_open`’s** (raised in the 2026-09-27 review): the
  `command` in a `spawn` / `ssh` frame gets spliced into the `-c` wrapper, so `sanitizeCommand` rejects
  newlines and NUL. The agent’s `tty_open.command` takes a different path — the command is wrapped **whole**
  in `shSingleQuote` and handed to the inner `-c` (see above), so it **may contain newlines** (multi-line
  scripts do run) and is bounded only by the tool parameter’s string type. Do not read this section’s limit
  as a `tty_open` restriction.
- The service name `ttyTerminal` is likewise not declared on the `Context` type surface; inject it as an
  optional dependency; when tty is not installed or is older than 0.14.0 it never fires (dsh-docker degrades
  to “copy command”).
- **`ttyTerminal` / WS `spawn` is a command surface with no static capability gate** (added 2026-10-07;
  consumers must not describe it the other way round): this service and the `{t:'spawn'}` frame both accept an
  arbitrary `command` and are **not governed by any `DSH_*_ALLOW_*`** (this plugin’s own static gate covers only
  ProxyCommand, the “a config field drives a local command” tier). That is deliberate — the terminal panel *is*
  the product, and **its permission ceiling rests on the user acting directly**: a human clicks “+” to open a
  tab and types commands inside it. **Note carefully that the tier gate does not reach here**: the tier gate
  above hangs on the `tools/pre-execute` waterfall and filters by the `tty_` / `sftp_` / `tunnel_` **prefixes**
  (`TTY_TIER_PREFIXES`) — i.e. it gates **agent tool calls only**. A browser `spawn` frame or a
  `ttyTerminal.open` call is a **WS / client-service** path and **never passes through it**. So do not treat it
  as this command surface’s gate: it does not block a single byte of it (only the `tty_open` agent path is
  governed).
  **The cost**: no consumer should advertise “the plugin’s own exec switch” as the boundary that keeps you out of
  a container — once tty is installed, an in-page script can use `ttyTerminal.open` or a WS `spawn` frame to get
  an arbitrary command surface strictly stronger than a one-shot exec. See
  [architecture.md § 7](../../docs/architecture.md#7-一条请求经过什么) for the threat-model boundary; docker states
  the same boundary in its own README under “Known limitations”.

### Embedded in-place terminal (`ttyTerminal.mount`, 0.15.0)

`open` is “borrow tty’s modal to open a tab” — the user’s panel gets covered or pushed behind by the modal; if
a consumer would rather **place a terminal inside its own panel** (typically dsh-docker’s terminal drawer:
watch container logs and drop into the container to type commands without losing context), use `mount`:

```js
ctx.inject(['ttyTerminal'], (c) => {
  if (Number(c.ttyTerminal.version ?? 0) < 2) { /* older version: fall back to open */ }
  const dispose = c.ttyTerminal.mount(hostEl, {
    command: "docker exec -it 'ems-consumer-test' sh",  // the same set of options as open
    book: 'lab-a',                                     // book > spec > local
    label: 'ems-consumer-test · exec',
  })
  // When collapsing your own drawer:
  // dispose()
})
```

- `hostEl` must be an `HTMLElement`: tty inserts an absolutely positioned `.tt_term` into it, so the mount
  point needs `position: relative` and a definite size (size changes are caught by a ResizeObserver and
  synced to the PTY).
- An embedded terminal **shares the same WebSocket and session table** as tabs, but its semantics are “a piece
  of terminal inside someone else’s panel”: it does not enter the tab bar, does not write sessionStorage, and
  does not take part in showing/hiding the tty panel; **closing the tty panel does not affect it** (and
  conversely: while an embedded session is running, tty’s connection is not closed).
- Reconnect on disconnect, re-running by the original command after a host restart, and clicking the overlay
  to reopen after exit all reuse the existing logic; `dispose()` ends the session and unmounts the DOM.
  Mounting is **cold-start safe** — with the tty panel closed and no connection yet, `mount` still brings the
  connection up (creation frames are queued first and sent after `onopen`).
- An embedded terminal has no search/clear toolbar from the tty panel header, and Ctrl+F is handed back to the browser.

### In-panel mount slots (client service `ttyPanel`, 0.16.0)

> tty’s own SFTP File Browser goes through this channel too (0.16.0): when the mount slot is free it docks
> below, and when another panel on the same tab has taken it, it falls back to the dialog.

`mount` solves “a consumer gives the host and tty puts a terminal in it”; `ttyPanel` is its **mirror** — tty
gives consumers a slot inside the terminal panel to mount their own UI into. A typical case: dsh-docker opens
“Containers” from the SSH connection bar and the containers panel docks to the **right** of the terminal,
which stays visible, clickable and typable instead of being covered by a full-screen modal (which was exactly
the pain before 0.15).

A mount slot is **connection-scoped**: its credentials / target come from the terminal tab that opened it.
So since 0.19.0 every pane records its **owner tab** (`options.ownerSid`, defaulting to the active tab at
mount time): switching to another tab **hides** the pane (`data-dock-hidden`; its DOM and your rendered tree
survive, in-flight transfers keep running) and switching back restores the scene; closing the owner tab tears
the pane down. Without this, the pane stayed put across a tab switch — its title read `SFTP · lab-b`
while the active tab was `192.0.2.10`, leaving **another host**’s file listing on screen (worst case:
uploading to the wrong host). Passing `ownerSid: null` means “owned by no tab” (always visible); that is what
happens automatically when the panel is open with no tabs at all, and a consumer can use it to declare “this
pane has nothing to do with tabs, do not hide it on a switch”.

```js
ctx.inject(['ttyPanel'], (c) => {
  // Use your own modal when the panel is not open (or tty < 0.16)
  if (Number(c.ttyPanel.version ?? 0) < 1 || c.ttyPanel.isOpen() !== true) { /* fallback */ }
  const pane = c.ttyPanel.mountPane({
    title: 'Docker Containers',  // panel title
    hint: 'prod-web-01',   // grey text right of the title (optional)
    side: 'right',         // 'right' (default, vertical list / list+detail) | 'bottom' (wide horizontal table)
    size: 520,             // initial size in px: right = width (default 460), bottom = height (default 320)
    min: 360,              // minimum size in px (optional, default 280 / 160)
    ownerSid: tab.sid,     // owner tab (optional): omitted = current active tab, null = owned by no tab
    onClose: () => { /* called when tty tears the panel down: unmount your React root here */ },
  })
  createRoot(pane.element).render(<MyPanel />)
  // When collapsing it yourself: pane.dispose()
})
```

| Member | Description |
| --- | --- |
| `isOpen()` | Whether the terminal panel is currently open (minimized does not count). Consumers use it to decide “mount in here” or “use my own modal” |
| `mountPane(options)` | Mounts a slot on the right / at the bottom of the panel and returns a handle; **only one at a time**, and a later `mountPane` first tears the previous one down (calling its `onClose`). With `side:'bottom'` it spans the full width and is sized by height (drag the top edge), collapsing into a title bar. `ownerSid` records the owner tab (default: the active one); panes owned by another tab are **hidden** on tab switch (DOM and your React tree survive, restored when you switch back — see “connection-scoped” above) |
| `handle.element` | The host the consumer renders into (flex column, already `overflow:hidden`, filling the body area) |
| `handle.setTitle(text)` / `setHint(text)` | Change the title / the grey hint |
| `handle.expand() / collapse() / toggle() / isCollapsed()` | Collapse into a 32px strip (vertical title + expand/close buttons), and the terminal immediately gets its width back |
| `handle.dispose()` | The consumer tears it down itself (idempotent, does not fire `onClose` again) |

- **Lifecycle**: the side panel’s DOM lives inside the terminal modal — minimize / restore follow the panel,
  and consumers need not care; when the panel is closed (✕ / host unload) tty **calls `onClose` first**
  (consumers unmount there) and only then detaches the DOM.
- **Resizing**: a right pane drags its left edge, a bottom pane drags its top edge (the cap is 72% of the
  panel card’s long side, leaving room for the terminal), and the size is remembered per direction within the
  same page session. Terminal-area size changes are caught by the existing ResizeObserver, which refits
  automatically and syncs the new rows/cols to the PTY.
- **Viewport anchoring**: opening/closing a pane or dragging its size changes the terminal area’s height, and
  xterm moving its viewport by itself would “push the content up”. Refit anchors to what the user was doing —
  if they were at the bottom (watching the newest output) it stays at the bottom, and if they had scrolled
  back through history it locks to the same lines, so nothing jumps away.
- **Choosing a direction**: vertical lists / list+detail (such as the containers panel) use `right`; wide
  tables (such as the SFTP file list or the local↔remote dual pane) use `bottom` — the full width fits more
  columns and does not squeeze the terminal’s width.
- The title bar (title / collapse / ✕) is provided by tty, and consumers only own their own body; a throwing
  `onClose` is only logged with `console.warn`, without affecting closing the panel.

**`minimize()` (contract v2)** folds the whole terminal panel away: the modal is hidden, but the DOM /
WebSocket / xterm buffers are all kept and **the session keeps running**; restoring it goes through the badge
on the sidebar’s “Terminal” entry. Consumers use it to “give the stage back” — the typical case is dsh-docker
handing the logs over to the session and folding the terminal away automatically, so the user sees the session
directly instead of staring at a modal covering it and guessing “did my click do nothing?”. The return value is
the minimized state after the call, which the caller uses to decide whether its message still needs to say
“the session is behind the panel”.

```js
ctx.inject(['ttyPanel'], (c) => {
  if (Number(c.ttyPanel.version ?? 0) < 2 || typeof c.ttyPanel.minimize !== 'function') return false
  if (c.ttyPanel.isOpen() !== true) return false
  return c.ttyPanel.minimize()   // fold the terminal away so the session shows through
})
```

> Contract versions: `ttyConnbar.version === 1`, `ttyTerminal.version === 3` (1 = `open` only,
> 2 = adds `mount`, 3 = `open` reuses an existing live tab for the same connection + command by default),
> `ttyPanel.version === 2` (1 = `mountPane` + `isOpen`, 2 = adds `minimize`). Consumers **decide capabilities
> by version number**; do not rely on assumptions beyond `typeof fn === 'function'`; on an older tty the
> `inject` still fires, but the corresponding fields are absent.

## Frame protocol (/api/dsh-tty/ws, JSON text frames; v3 = one connection with many sessions + reconnect)

| Direction | Frame | Description |
| --- | --- | --- |
| C→S | `{t:'spawn', sid?, cols?, rows?, cwd?, persist?, persistName?, command?}` | Create a session; sid defaults to one generated by the host and cwd to the configured fallback; `persist` + a stable `persistName` (0.10.0) = tmux persistent session (`dsh-<name>`, requires persistence=tmux); `command` (0.14.0) = run a single command directly (no persistence) |
| C→S | `{t:'ssh', sid?, cols?, rows?, name? \| host, username, …, persist?, persistName?}` | Create an SSH session (native ssh2); `name` references a connection-book entry as the base, and inline `host/port/username/auth/keyPath/passphrase/password/agentForward` can override it field by field; `persist` has the same semantics as spawn (remote tmux hosting) |
| C→S | `{t:'input', sid?, d}` | Key/paste data |
| C→S | `{t:'resize', sid?, cols, rows}` | Panel size change. **The client only sends it when the container is visible and the size is trustworthy** (D79: hidden tab / detached element / minimized panel send nothing, so the PTY keeps its last valid size); the host clamp is only a safety floor, and non-numeric values (including `null`) fall back to 80×24 instead of being clamped to the floor |
| C→S | `{t:'refresh', sid?}` | Force a redraw (0.10.1): the host runs `refresh-client` on a tmux session (the client resets to clear stale scrollback and then asks for a fresh redraw; a no-op for non-tmux sessions) |
| C→S | `{t:'kill', sid?}` | Close a session (orphan sessions can also be killed across connections, to prevent leaks) |
| C→S | `{t:'sessions'}` | List a global session snapshot (`attachable` marks the reattachable ones) |
| C→S | `{t:'attach', sid}` | Reattach an orphan session (inside the keep-alive window): after `ready(reattached:true)` a single `data` frame replays the output buffer |
| C→S | `{t:'statsOn' \| 'statsOff', sid}` | Subscribe/unsubscribe that session’s server status bar (0.17.0): driven by tab visibility, and the host collects only while a subscription exists (lazy start + unsubscribing stops the meter and closes the remote channel) |
| S→C | `{t:'ready', sid, pid, kind, target?, persist?, reattached?}` | Session ready; `kind:'local'` carries a pid, while `kind:'ssh'` has pid=null and target=user@host[:port]; attach reuses this frame with `reattached:true`; `persist:true` means a tmux persistent session (0.10.0) |
| S→C | `{t:'data', sid, d}` | Terminal output (utf8 text, StringDecoder covers multi-byte sequences split across frames); **coalesced into frames over a 12ms window / 64KB threshold** (0.4.1), with a forced flush before exit/kill to guarantee frame order — **the last batch before exit is always sent** (D76: it used to be swallowed whole by the exit path’s own `closed` guard, so a process that printed and exited immediately was permanently missing its final lines) |
| S→C | `{t:'stats', sid, stats}` | Resource metric frame (0.17.0): `{cpuPct, cores, memUsed, memTotal, memPct, diskUsed, diskTotal, diskPct, uptimeSec, tcpConns, rxRate, txRate, tempC?}`; missing fields are omitted (best-effort, the frontend shows “n/a”), byte fields are bytes and rates are B/s |
| S→C | `{t:'exit', sid, code, signal}` | The PTY exit fact (exactly once; after attach moves to a new connection it is still delivered over the current connection) |
| S→C | `{t:'error', sid?, m}` | Error |
| S→C | `{t:'sessions', list, tmux?}` | Session snapshot (`{sid, kind, target, pid?, cwd, startedAt, lastOutputAt, attachable, persist?}`); `tmux` = the persistent session names alive on the dedicated socket + retained SSH persistent session names (0.10.1, an observable field) |

Disconnect keep-alive semantics: when the client closes the panel normally it sends `kill` for each session
before disconnecting; therefore “WS closed with sessions still alive” is treated as an abnormal disconnect —
sessions become orphans (output keeps accumulating into the ring buffer and is sent to no connection), and
after `reconnectGraceSec` of keep-alive the reaper cleans them up; during that window a new connection can
query `{t:'sessions'}` and `{t:'attach', sid}` to reconnect and replay.

When sid is omitted the frame is routed to “the connection’s only session”; with 0 or multiple sessions on the
connection, omitting sid errors out. The upgrade route carries a loopback trust fence (remoteAddress + Host +
Origin checks), so only the local Web GUI can connect.

## Development

```bash
pnpm --filter @hyzyn/dsh-tty build        # tsc host + esbuild browser half (client.js)
pnpm --filter @hyzyn/dsh-tty typecheck
pnpm --filter @hyzyn/dsh-tty probe        # M0 probe: PTY primitive verification (needs a real PTY)
pnpm --filter @hyzyn/dsh-tty integration  # integration tests: real plugin × real DSH service composition
pnpm --filter @hyzyn/dsh-tty live         # liveness smoke: start dsh web first (default ws://127.0.0.1:3080; DSH_TTY_WS_URL overrides)
pnpm --filter @hyzyn/dsh-tty tui          # TUI smoke: vim/htop full-screen rendering (start dsh web first, default :3090; DSH_TTY_WS_URL overrides)
pnpm --filter @hyzyn/dsh-tty ssh-smoke    # SSH smoke: in-memory SSH server (ssh2.Server) × real spawnSsh end to end (build first)
pnpm --filter @hyzyn/dsh-tty probe-smoke        # probe classification & TOFU (7 cases, self-contained)
pnpm --filter @hyzyn/dsh-tty probe-route-smoke  # probe HTTP route + connection book (9 cases)
pnpm --filter @hyzyn/dsh-tty sftplimits-smoke   # sftpLimits normalisation (6 cases)
pnpm --filter @hyzyn/dsh-tty windows-smoke      # Windows end to end (only meaningful on Windows; skips elsewhere)

CI (`.github/workflows/ci.yml`) runs `integration` + `ssh-smoke` + the three smokes on ubuntu and
`windows-smoke` on windows-latest, plus a “build artifacts match sources” gate (`client.js` + `lib/`).
The 48 fixes shipped in 0.19.0 and their audit index live in [`DEFECTS.md`](./DEFECTS.md).
pnpm --filter @hyzyn/dsh-tty preview      # visual preview: headless Chrome screenshots per scene (see below)
```

The browser half’s source is `client-src/index.js`, with the stylesheet living separately in
`client-src/tty.css` (inlined into `client.js` by esbuild’s text loader). The build output `client.js`
(including the xterm core) needs another `pnpm build` and a page refresh (possibly a hard refresh) after
client-side changes.

### Visual preview / screenshot regression (`scripts/preview.mjs`)

Styles should not be changed by “refresh the page and take a look”: the script loads `client.js` into a pure
static fixture page (`scripts/preview/harness.html` + a fake DSH host from `mock-host.js`: module
loader / fetch / WebSocket) and renders 50 UI states one by one with headless Chrome, screenshotting them to
`packages/tty/.preview/shots/`:

```bash
node scripts/preview.mjs                 # all scenes
node scripts/preview.mjs local menu ssh  # specific scenes
node scripts/preview.mjs --list          # list scenes
node scripts/preview.mjs --theme=light   # light theme
```

Coverage: local terminal / multi-tab + SSH connection bar / the “+” menu / SSH dialog (new, edit, probe)/
settings card (also side by side with docker)/ SFTP (single pane, dual pane, placement fallback)/
**mount slot follows the tab** (`dock-pane-tab`, the 0.19.0 regression)/ minimized badge / exit and error
overlays / “clean up exited tabs” in the “⋯” menu (and after clicking it)/ where tabs go when the AI
releases a session / the panel-close confirmation (with live sessions and with only exited tabs)/
batch tab closing (the “⋯” batch rows, the tab context menu, the “close others” confirmation, middle-click;
0.30.0)/ tunnel popover / search box / toast / embedded terminals (alone and alongside the panel)/
docker panel and “containers → terminal drawer”.

A scene may attach a **function-shaped** assertion to `window.__previewAssert` (returning `null` means pass,
a string / array means fail); the script runs it and folds the result into `✓/✗`. An assertion that only
lives in the fixture, seen by nobody unless someone pulls `diag` by hand, is a regression that is not really
pinned — which is exactly what bit the 0.19.0 “panel does not follow the tab” fix: the assertion was written
already, but because it was mixed into a `diag` object containing a function, the whole evaluation failed
silently and everything reported ✓.

The fixture also renders the `--dsw-*` skin variables together with the real UI, so it can
verify things like “is there still a white panel after switching light/dark themes”. The output directory
`.preview/` is gitignored.

> The fixture’s `ctx.inject` mirrors real cordis: **if any requested service is missing the callback is not
> invoked** instead of receiving `undefined` in the scope. Filling in `undefined` means one optional
> dependency (for example the `sidebarRight` / `sidebarRightTabs` branch of dsh-docker) makes **every** scene
> blow up during mount (`Cannot read properties of undefined (reading 'register')`) — when the fixture does
> not provide a host-side sidebar service, that branch should simply stay unregistered.

> The fixture needs Chrome/Chromium (it looks for playwright’s cached Chrome for Testing by default, or use
> `CHROME_PATH`). If the host environment restricts Chrome’s sandbox (child processes denied), it must be
> loosened before running, otherwise the browser cannot start.

## Known limitations

- **Resize is an internal coupling**: DSH’s `spawnTerminal` handle does not expose resize, so the plugin
  passes through `(handle).terminal.resize(cols, rows)` directly (node-pty’s native API, reachable in the
  same process). If a DSH upgrade changes the internals, since 0.3.0 it warns once and degrades to a fixed
  size instead of throwing on every frame. **D79 addendum**: the check is now an explicit
  `typeof terminal.resize === 'function'` — the old `handle.terminal?.resize?.(…)` only reached the warning
  branch when resize *threw*, so a DSH that renamed or removed `handle.terminal` would neither resize nor
  warn (the promise was empty and debugging had no lead at all).
- **TERM is injected through a `-c` wrapper layer (POSIX only)**: DSH hardcodes node-pty `name:"dumb"`, and in
  node-pty name takes precedence over env.TERM, so the shell is started as
  `sh -c 'export TERM=...; exec "$shell"'` (transparent to the user; the TERM /
  COLORTERM values are whitelisted to avoid breaking the wrapper command). **There is no such layer on
  Windows** — neither cmd nor PowerShell understands that syntax, and ConPTY does not need TERM (see the
  “Windows hosts” section).
- **Windows hosts**: local terminals work (default `%COMSPEC%`), but shell integration, tmux persistence and
  disk / TCP / throughput / temperature are unsupported or unavailable — the full boundary and verification
  scope are in the “Windows hosts” section.
- **terminate() has a “survivor” race**: DSH’s tree-level cleanup occasionally reports
  `terminal cleanup failed; surviving pids`, which the plugin handles best-effort
  (on failure it degrades to SIGKILL on the top-level shell), and the exit code/signal may be null.
- **Output is a utf8 text stream**: node-pty data is transported by DSH as utf8, so non-UTF-8
  bytes get eaten by replacement characters (such as `cat` on a binary file) — expected behavior; multi-byte
  UTF-8 sequences split across chunks are covered by StringDecoder (0.3.0), so fast Chinese output no longer garbles.
- The browser half depends on the official `dsh-web-app` sidebar structure (`[data-pane="sidebar"]`), so an
  unofficial Web GUI may not show the entry.
- **The keep-alive window is limited**: after an abnormal disconnect a session is kept alive and reattachable
  only for `reconnectGraceSec` (120s by default), and a host process restart ends all sessions; sessions not
  reconnected before the deadline are ended by the reaper, and scroll history beyond the output buffer
  (last 256KB) cannot be recovered.
- **Shell integration covers zsh / bash on POSIX and the PowerShell family on Windows**: other shells
  (Windows cmd) are skipped automatically (`tty_capture{last}` reports a clear error rather than a wrong
  one); a PowerShell 7 `tty_capture{last}` empty window was recorded but **not reproduced on pwsh 7.6.6**
  on 2026-10-13 (0/20 across three output shapes) — if you see one, read the tail with `tty_capture`. bash < 4.4 uses the DEBUG trap fallback: internal commands
  of compound commands such as loops emit extra B markers, and `tty_capture{last}` captures only the output
  after the last internal command for those commands (exit codes and `tty_expect` are unaffected). If the
  user’s rc overrides `PROMPT_COMMAND`/the hook array, the integration may stop working — turn off
  `shellIntegration` or report a patch for compatibility.
- **Port-forwarding boundaries**: local listeners are fixed to 127.0.0.1 (never exposed to the LAN); listening
  on the server side for the remote direction is also limited by the server sshd’s `GatewayPorts`; a tunnel’s
  SSH connection is independent of terminal sessions and both use TOFU pinning and connection-book
  authentication; tunnel spec changes (port/target/start-stop) take effect hot on “save”, while hot-changing
  connection-book credentials takes effect on the next reconnect.
- **Session persistence (tmux) boundaries**: persistent tabs are hosted by the tmux server (a dedicated socket,
  profile-scoped since 0.25.0 — `dsh-tty` without a profile, `dsh-tty-<profile>` with one)
  `dsh-tty`) — when the host is hard-killed / the keep-alive reaper fires / the browser loses the tab spec,
  the tmux session is **retained** (which is exactly what makes recovery possible) until the machine restarts
  or `tmux -L <socket> kill-server` is run manually; the agent’s command-granularity tools
  (capture{last}/expect) depend on DCS `allow-passthrough` in tmux ≥3.3, and on older versions persistence
  works but that capability degrades (SSH remote sessions do not inject shell integration hooks, so
  capture{last} was never available there, independently of persistence); recovery redraws the currently
  visible screen, while pre-disconnect scroll history lives in tmux’s own history buffer (copy-mode), not in
  the outer xterm scrollback; a persistent tab’s `exit` frame exit code is the tmux client’s (0), while the
  shell’s exit code remains available through the OSC 133;D marker as usual; `tmux.conf` is read only when the
  tmux server first starts (after changing the configuration, run `tmux -L <socket> kill-server` so the next
  spawn rebuilds the server); with `grace=0`, “end immediately on disconnect” also kill-sessions persistent
  tabs (the tmux session does not survive); persistent SSH sessions require tmux on the remote (without it
  they degrade to a normal session automatically, and the connection bar shows a permanent “not persistent”
  marker), and the remote `~/.tmux.conf` does not affect the dedicated socket’s independent conf
  (`-f /dev/null`); SSH persistent session names are retained with settings; when **two windows reattach to
  the same persistent session at the same time** they share one host PTY (0.10.1, single-client fan-out, slots
  do not double), and the row/column count follows the most recently resized window (when the sizes differ,
  the larger side self-heals with a redraw through onResize).
- **SFTP boundaries**: file permissions = the terminal permissions of the corresponding SSH account (no extra
  sandbox/chroot); downloads go through browser memory (for very large files prefer `scp`/`rsync` in the
  terminal); the agent tool `sftp_read` is ≤1MB and rejects binaries, and `sftp_write` is ≤1MB per call (use
  panel upload or the terminal for larger content); the `sftp_*` tools accept only connection-book entry
  names, and inline credentials are for the panel dialog only; overwrite writes go through a same-directory
  temp part `.dsh-part-<uuid>` + rename (atomic) — if the host process crashes / loses power, a part orphan
  may remain, and the next overwrite upload to the same directory automatically cleans parts older than 24h.
- **SSH host keys are TOFU-pinned**: the first connection records the sha256 fingerprint automatically
  (trust on first use), after which any recorded fingerprint matching is allowed and a full mismatch is
  rejected — no longer an
  unconditional accept-and-log. Note TOFU’s inherent boundary: if the first connection already met a MITM,
  what was recorded is a fake fingerprint; `hostKeys` is persisted with settings, and a fingerprint change
  requires a human to confirm in the settings card and delete the record; a host’s multiple key types
  (rsa/ed25519/ecdsa) are merged into one record’s fingerprint set (0.19.0), so algorithm negotiation
  changes no longer report a false “fingerprint changed”; known_hosts import likewise keeps every
  fingerprint of a host.
- **Browser tab persistence contains no plaintext credentials** (0.19.0): the spec copies that SSH tabs
  write into sessionStorage / localStorage have plaintext `password` / `passphrase` stripped (`env:`
  references are kept) and are flagged with `credsStripped` — on restore/respawn the terminal asks for
  re-entry. The in-memory spec of the live session is unaffected.
- **SSH passwords / passphrases should use `env:VAR` references**: the connection book is persisted in the
  settings file, so plaintext `password` / `passphrase` is an exposure surface; prefer `env:VAR` +
  dsh-env-manager, or `agent` authentication outright (credentials never touch disk).
- **Server status bar (0.17.0) boundaries**: the remote side relies on two fallback hops: POSIX first (needs
  `/proc` + `awk`), and if not a single frame appears it falls back to PowerShell — this is what covers
  **Windows remotes** (most components have no temperature and show “n/a”, the disk is the system drive
  `%SystemDrive%`, TCP comes from `netstat -an`, and network speed from `Get-NetAdapterStatistics` deltas;
  integers only, which avoids locale decimal points and scientific notation at the root), while **macOS/BSD
  remotes** satisfy neither hop, get not a single field, and hide the whole status bar; on non-Linux remotes
  every (re)subscription costs one extra doomed exec (about a hundred milliseconds, without affecting frame
  latency); on Linux CPU temperature exists only on machines that expose `/sys/class/thermal` (most cloud
  hosts/VMs do not, showing “n/a”); the disk is always the filesystem holding `/` (the system drive on
  Windows) (no multi-mount support); the remote script is single-quoted through `sh -c` (so it runs even when
  the login shell is fish/csh); local-session metrics belong to the **host machine** (several local tabs share
  one sampling, with a continuous CPU/network delta window), and since macOS has no /proc, `ss` or sysfs it
  uses os/netstat/vm_stat instead, so the temperature is always “n/a” and memory is active+wired+compressed
  from vm_stat (os.freemem counts file cache as used and sits at 99% long-term); the metrics are
  **instantaneous values** with no history curves, and there is no agent tool for them (the agent keeps using
  the command-granularity tty_* capabilities).
- **SSH sessions have no local pid**: an ssh2 shell channel is not a local process, so `ready.pid`
  is `null` and `tty_list` shows `target` instead of a pid; local `ps` / `kill` do not work on remote
  processes — close with the tab ✕ or the `kill` frame (which closes the ssh2 channel).

## How it works

```
Browser half (client.js, esbuild bundle)
  ├─ sidebar “Terminal” entry → large modal
  ├─ tab bar: one xterm.js instance per tab (independent sid; WebGL renderer, DOM fallback on loss)
  ├─ reconnect: exponential-backoff auto-reconnect + sessions query + attach restore;
  │  the tab list lives in sessionStorage (after a refresh, reconnect by sid and keep sessions alive)
  ├─ sessions client service: a new tab carries the current session cwd
  └─ WebSocket ──→ /api/dsh-tty/ws (webServer.registerUpgrade)
                        │
Host half (src/index.ts)
  ├─ per-connection session table (sid → local PTY / SSH channel, many sessions per connection)
  ├─ SessionManager (maxSessions cap, hot-adjustable; SSH sessions scheduled from the same table;
  │  the orphan reaper cleans up abnormally disconnected sessions per reconnectGraceSec)
  ├─ per-session 256KB ring buffer (tty_capture / disconnect replay) + xterm-headless
  │  virtual screen (tty_screen) + StringDecoder (utf8 split-frame fallback)
  ├─ shell integration (src/shell-integration.ts): zsh ZDOTDIR / bash --rcfile
  │  stub injection of OSC 133/7 hooks; output stream parsing (feedShellIntegration, carrying
  │  truncated packets across chunks) → command boundary capture (tty_capture{last} / tty_expect
  │  early stop) and cwd tracking (tty_list)
  ├─ local path: ctx.get('subprocess').spawnTerminal({ argv: shell -c wrapper, cwd })
  │  persistent tabs (0.10.0): the wrapper becomes `exec tmux -L <socket> -f <conf> new -A -s dsh-<name>`
  │  (src/tmux.ts: probing / asset generation / spawn planning / kill-session; stable assets under
  │  <DSH_HOME|~/.dsh>/tty/ — tmux.conf + inner.sh + zsh/bash stubs; tmux swallows sequences it
  │  does not recognize, so the shell-integration hook detects $TMUX and wraps OSC 133/7 in a DCS
  │  passthrough envelope, tmux ≥3.3 unwraps and forwards it, and the host parser needs no change)
  ├─ auxiliary routes: /api/dsh-tty/ssh-config (~/.ssh/config import candidates),
  │  /api/dsh-tty/credential-refs (reference names known to the credential store — names only, see
  │  “Credential storage”), /api/dsh-tty/env-vars (variable names managed by the env plugin), /api/dsh-tty/known-hosts
  │  (TOFU fingerprint prefill, src/known-hosts.ts parses hashed entries too),
  │  /api/dsh-tty/shells (shell path candidates) — all behind the loopback fence (hardened
  │  tier: the whole 127/8 range + DNS confirmation for alias hostnames + source checks before
  │  DNS; one implementation only, in @hyzyn/dsh-kit); **state-changing endpoints additionally
  │  require a same-origin proof** (POST /probe, sftp mkdir/rename/remove/upload, local-fs
  │  mkdir/rename/remove/transfer); read-only endpoints (including sftp /list and /download)
  │  need no proof, so bare curl still works. POST /config is deliberately exempt — it is the
  │  only recovery entry once the plugin is disabled
  ├─ SFTP (src/sftp.ts, 0.7.0): lazy connection pool (reclaimed after 120s idle, reconnected on
  │  demand when dropped, TOFU shared) → POST /api/dsh-tty/sftp/list|mkdir|rename|remove|download|
  │  upload (spec in body/headers, credentials never in the URL; uploads/downloads streamed via pipe) +
  │  sftp_list/read/write/mkdir/rename/remove/tree tools (accept only a connection-book name;
  │  mkdir supports parents, filling levels bottom-up, tree recurses with depth/count limits)
  ├─ port forwarding (src/tunnels.ts): host-owned tunnels (-L/-R both ways), backoff reconnect on
  │  drop, TOFU shared, connection counters; GET /api/dsh-tty/tunnels live status + tunnel_list /
  │  tunnel_start / tunnel_stop tools
  └─ frame protocol: spawn|ssh / input / resize / kill / sessions / attach
     ↔ ready/data/exit/error/sessions + backpressure

SSH path (src/ssh.ts)
  └─ {t:'ssh'} → spawnSsh: native ssh2 Client connection (agent / key / password,
     password·passphrase support taking secrets from env:VAR; the host key is TOFU-pinned
     through HostKeyStore), opening a shell channel wrapped into a TermHandle shaped like a PTY
     (pid=null, kind='ssh', target=user@host[:port]),
     backpressure is passed through to the channel as well — after that it is scheduled just like a local PTY;
     with persist on it first probes `command -v tmux` and then `exec tmux -L <socket> -f /dev/null
     new -A -s dsh-<name>` to open a pty channel (remote tmux hosting; without tmux it degrades to a plain
     shell channel + a grey-text hint; kill is finished off by `tmux kill-session` inside the connection)
```

The M0 probe, the integration tests (B1~B24, 58 assertions in total) and real-instance smoke tests
(live / TUI) were verified on a real DSH service composition: TERM injection, resize passthrough, sid
conflicts, the concurrency limit, the loopback fence, multi-session data isolation, cwd tracking and
validation, hot configuration reload (settings/updated), the full kill→exit chain, disconnect keep-alive +
sessions/attach reconnect replay, the tty_screen virtual screen, tty_capture ANSI cleanup, shell integration
(capture{last} + exitCode, OSC 7 cwd tracking), tty_expect matching and timeout, the ~/.ssh/config parser,
port forwarding (two active tunnels + forwardOut round trip + reconcile cleanup),
the shells candidate route, bash 3.2 shell integration (DEBUG trap fallback: capture{last} +
exitCode, tty_expect early stop when the command ends), SFTP file transfer (list/mkdir/upload/
download/remove routes + sftp_* tools, test-sshd in-memory sshd end to end), the SFTP management
loop (agent sftp_mkdir/-rename/-remove/-tree: parents creation, tree depth truncation,
cross-directory moves, non-empty delete rejection and recursive delete); session persistence (B25/B26: persistence
gating, tmux session hosting and kill-session cleanup, the no-tmux degradation hint, capture{last} under DCS
passthrough, keep-alive reaping that kills only the PTY and not the tmux session, reattaching to the same
persistName — with no local tmux it automatically runs only the degraded path). The SSH path is verified by `ssh-smoke`
(in-memory SSH server × real `spawnSsh`): password authentication and prompt,
command round trip, pty-req initial size and resize (window-change), the full terminate /
exit-status chain, plus TOFU fingerprint recording (S7) and fingerprint-change connection rejection (S8);
SFTP is covered by ssh-smoke S9 (test-sshd’s sftp subsystem × the real SftpManager):
directory listing and realpath home, upload overwrite+append, download (stat size as content-length),
mkdir/rename/non-recursive delete rejection/recursive delete, TOFU fingerprint-change rejection; S9g covers mkdir
`parents` creation level by level (idempotent) and `tree` depth truncation/full output.

