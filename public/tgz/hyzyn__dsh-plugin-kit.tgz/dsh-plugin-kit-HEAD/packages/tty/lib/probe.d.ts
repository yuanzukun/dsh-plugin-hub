import type { HostKeyStore, SshSpec } from './ssh.js';
/** TCP 预检超时（毫秒）：DNS 解析 + 建连。 */
export declare const PROBE_TCP_TIMEOUT_MS = 6000;
/** ssh2 握手/认证阶段超时（毫秒）；覆盖 buildConnectConfig 的 readyTimeout。 */
export declare const PROBE_AUTH_TIMEOUT_MS = 8000;
/**
 * 代理命令这条路上，拼错误文案**之前**等「子进程证据（exit / stderr）」的有界窗口（毫秒，tty D95）。
 *
 * 为什么是「有界」而不是「一直等」：代理命令没死透时等它是无意义的（那属于握手超时的活），
 * 而用户点「试连」要的是一个答案。200ms 覆盖实测的 1~2ms 竞态，又不改变探针的数量级。
 */
export declare const PROXY_EVIDENCE_GRACE_MS = 200;
/** 分类结果载荷（HTTP 回传；字段全部可 JSON）。 */
export interface ProbeResult {
    /**
     * tcp 阶段：DNS 解析 + TCP 建连。
     *
     * **有跳板机时探的是跳板机那一跳**（目标根本不能直连），标签与它的结论另见 `jump`——
     * 客户端据此把这一行写成「跳板机 X 通/不通」，而不是让人读成「目标 TCP 可达」。
     * **走代理命令时这一阶段整个跳过**（`skipped=true`）：连不连得上由那条命令自己决定，
     * 直连预检探的是目标主机、与本次连接路径无关，报「不可达」纯属误导读者的噪音。
     */
    tcp: {
        ok: boolean;
        error?: string;
        ms?: number;
        skipped?: boolean;
    };
    /** 跳板机维度（单跳）：标签 + 它那一跳的 TCP 预检结论（与 `tcp` 同一份数据，便于客户端直接渲染）。 */
    jump?: {
        label: string;
        tcp: {
            ok: boolean;
            error?: string;
            ms: number;
        };
    };
    /**
     * 代理命令维度：配了 `proxyCommand` 时非空。
     *
     * `active=false` 表示**配了但闸门关着**（`allowProxyCommand` 未开），本次不会执行任何本机
     * 命令——探针在这里就返回，把开关路径写清楚（而不是让人读成「目标连不上」）。
     * **不回显命令原文**（它可能含凭据）。
     */
    proxy?: {
        active: boolean;
        error?: string;
    };
    /** hostkey 阶段：TOFU 比对（未到握手时为 unknown）。 */
    hostkey: {
        state: 'unknown' | 'matched' | 'recorded' | 'mismatch';
        /** 服务端 host key 的 sha256 指纹（hostHash:'sha256' 下 hostVerifier 收到的原样值）。 */
        fingerprint: string;
        /** 已记录指纹集合（mismatch 时展示对照；0.19.0 起一机多指纹）。 */
        known?: string[];
        /** mismatch 时的完整指引文案（与 spawnSsh 一致）。 */
        error?: string;
    };
    /** auth 阶段：认证是否通过（ready）。 */
    auth: {
        ok: boolean;
        error?: string;
        ms?: number;
    };
    /** 总耗时。 */
    totalMs: number;
}
/** 仅校验一份连接簿 / 对话框条目的形状（新增 / 编辑前先过一遍；不做网络请求）。 */
export declare function validateSshFields(input: Record<string, unknown>): {
    spec?: SshSpec;
    error?: string;
};
/**
 * 单次连接诊断。无论成败都会关闭连接、在超时内返回，绝不悬挂。
 * 分类见文件头；tcp 预检通过后才进入 ssh2 握手。
 */
export declare function probeSsh(spec: SshSpec, store?: HostKeyStore): Promise<ProbeResult>;
