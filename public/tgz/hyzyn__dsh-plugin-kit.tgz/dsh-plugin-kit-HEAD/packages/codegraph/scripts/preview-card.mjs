/**
 * 卡片预览渲染器：把 client.js 的**真实标记与 CSS** 渲染成独立 HTML（可选再截图）。
 *
 * 为什么不用真实 GUI 截图：卡片要展开、面板要滚到位置，脚本化成本高；而 client.js 的
 * CSS 与 React 元素树是可以离线渲染的——用一个最小 fake React 跑一遍组件（真实 hook
 * 顺序、真实样式），把元素树序列化成 HTML，颜色用 @deepseek-ai/dsh-client-ui-theme 的
 * 亮色 token 补齐，得到的就是卡片本身，而不是手写的近似 mock。
 *
 * 用法：
 *   node packages/codegraph/scripts/preview-card.mjs            # 写 .preview/codegraph-card.html
 *   node packages/codegraph/scripts/preview-card.mjs --png      # 再调本机 Chrome 渲染成 PNG
 *   node packages/codegraph/scripts/preview-card.mjs --per-agent # 预览 P0 per-agent 生效态的卡片
 *   node packages/codegraph/scripts/preview-card.mjs --fallback  # 预览 P0「要 per-agent 但退回 managed」的卡片
 *   node packages/codegraph/scripts/preview-card.mjs --busy      # 预览忙碌态（/status 挂住 → 标题行指示器）
 *   node packages/codegraph/scripts/preview-card.mjs --png --tall # 截更高的图（860×1500），看折叠线以下的按钮分组
 *   node packages/codegraph/scripts/preview-card.mjs --result    # 点一次「文件」，看结果区（页签）带内容的样子
 *   node packages/codegraph/scripts/preview-card.mjs --feedback  # 点「重新探测」「诊断包」，看反馈区与脚注的顺序
 *   node packages/codegraph/scripts/preview-card.mjs --alert     # 让 CLI 探测失败，看页面最前的「问题区」
 *   node packages/codegraph/scripts/preview-card.mjs --adoption  # 给采纳率一份真实数据，看那行会不会被截断
 *   DSH_PREVIEW_LOCALE=en node packages/codegraph/scripts/preview-card.mjs  # 预览英文界面（i18n）
 *
 * 注意：无头 Chrome 在 DSH 文件沙箱里起不来（它要初始化自己的 sandbox），--png 需要在
 * 普通终端里跑；也可以直接打开 HTML 手动截图。产物目录 .preview/ 已在 .gitignore 里。
 */
import { execFileSync } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { describeChromeSearch, findChrome, playwrightChromeCandidates } from '../../../scripts/chrome-path.mjs'

const here = dirname(fileURLToPath(import.meta.url))
const pkgRoot = resolve(here, '..')
const clientPath = join(pkgRoot, 'client.js')
const outDir = join(pkgRoot, '.preview')

/**
 * 预览模式。**必须在 htmlPath 之前声明**（TDZ）：第一版把这两个 const 放在
 * htmlPath 之后，`--fallback` 直接 `ReferenceError: Cannot access 'perAgent' before
 * initialization` —— 与 `client-lint.mjs` 存在的理由（TS2448「块级变量先用后声明」）
 * 是同一类错误，只是这个脚本不在客户端半体的检查范围内，所以没被闸门拦住。
 */
const perAgent = process.argv.includes('--per-agent')
const fallback = process.argv.includes('--fallback')
/**
 * --busy：把 `/status` 的响应**永远挂住**，于是组件的 `loading` 保持为 true，
 * 好把标题行上的忙碌指示器（转圈 + 文案 + 取消）截出来看。
 * 这是唯一能在无头环境里离线看到忙碌态的办法（真机上它一闪而过）。
 */
const busy = process.argv.includes('--busy')
/**
 * --tall：截图用更高的视口（860×1500）。
 *
 * 默认 860×600 只够看到卡片上半部分——而「索引维护 / 搜索与查询 / Agent 集成」这些
 * 分组都在折叠线以下，改它们时截出来看不到（实测：验证「撤销索引」并入生命周期行时，
 * 默认视口正好把那一行切掉）。只影响截图，不影响 HTML。
 */
const tall = process.argv.includes('--tall')
/**
 * --result：点一次「文件」，让结果区带着真实内容出现。
 *
 * 为什么需要：结果区默认不渲染（没有查询结果就没有页签），于是「结果区上移到
 * 搜索与查询下方」这条改动在预览里看不到——而它正是用户反馈「点击文件看不到列表」
 * 的修复点。这里在渲染流程里真的去调一次那个按钮的 onClick，走完整条链路。
 */
const result = process.argv.includes('--result')
/**
 * --feedback：依次点「重新探测」与「诊断包」，把**反馈区**（成功提示 + 诊断包行）
 * 连同它后面的遥测脚注一起渲染出来。
 *
 * 为什么要单独一档：用户反馈「这一块交互 ui 挺乱的」，而乱在**顺序**——遥测脚注原先
 * 夹在按钮与它们自己的结果之间。这条顺序只有在「有反馈」时才看得见，默认预览里
 * 反馈区是空的。
 */
const feedback = process.argv.includes('--feedback')
/**
 * --alert：把 CLI 探测结果改成「不可用」，渲染出**问题区**（页面最前的那两条警告）。
 *
 * 为什么要单独一档：问题区健康时**完全不渲染**，默认预览里看不到——而它正是本次
 * 改动的对象（把「什么都干不了」的警告从卡片最底部挪到最前面）。
 */
const alert = process.argv.includes('--alert')
/**
 * --adoption：给 `/metrics` 一份真实的 summary，把「采纳率」那行渲染出来。
 *
 * 为什么需要单独一个模式：那行的长度随两个口径的数字变化（空态 / 只有读取 / 正常三档），
 * 而它承担的信息比一行 360px 能放下的多——不给它数据，预览里这一行根本不出现，
 * 「整句被截成半句」就只有真机截图能发现（实测就是这么来的）。
 */
const adoption = process.argv.includes('--adoption')
const htmlPath = join(outDir, perAgent ? 'codegraph-card-per-agent.html' : fallback ? 'codegraph-card-fallback.html' : busy ? 'codegraph-card-busy.html' : result ? 'codegraph-card-result.html' : feedback ? 'codegraph-card-feedback.html' : alert ? 'codegraph-card-alert.html' : adoption ? 'codegraph-card-adoption.html' : 'codegraph-card.html')
const pngPath = join(outDir, perAgent ? 'codegraph-card-per-agent.png' : fallback ? 'codegraph-card-fallback.png' : busy ? 'codegraph-card-busy.png' : result ? 'codegraph-card-result.png' : feedback ? 'codegraph-card-feedback.png' : alert ? 'codegraph-card-alert.png' : adoption ? 'codegraph-card-adoption.png' : 'codegraph-card.png')

/** 预览用的假数据：跟随开启、会话目录与绑定路径不同，好让「跟随会话」这一行有内容。 */
const RESPONSES = {
  '/api/dsh-codegraph/default-path': {
    ok: true,
    defaultPath: '/Users/zz/code/pinned-app',
    effectivePath: '/Users/zz/code/my-app',
    sessionPath: '/Users/zz/code/my-app',
    followSession: true,
    manageEnabled: true,
    announceToAgent: true,
    usageGuidance: true,
    cliAvailable: true,
    command: 'codegraph',
    indexed: true,
    indexState: 'indexed',
    mcp: { mode: 'own', cwd: '/Users/zz/code/my-app', note: '' },
    // --alert：CLI 探测失败（问题区第一条）+ 托管行指向非索引目录（第二条）
    cliAvailable: alert ? false : true,
    ...(alert
      ? {
          cliProbeError: 'spawn codegraph ENOENT（宿主进程的 PATH 在启动时就固定了）',
          cliProbeAt: 1789000000000,
          indexed: false,
          indexState: 'not-a-project',
          effectivePath: '/Users/zz',
        }
      : {}),
    // P0：默认 managed（保持原行为）。--per-agent 时改成「per-agent 生效」的形态，
    // 好把那条状态文案与勾选态也看一遍（卡片上新增的 UI 必须有办法离线看）。
    mcpScope: perAgent || fallback ? 'per-agent' : 'managed',
    effectiveMcpScope: perAgent ? 'per-agent' : 'managed',
    mcpScopeReason: fallback
      ? '要 per-agent 但宿主没有 agent 事件面（拿不到 agent/created），已退回 managed'
      : perAgent
        ? 'per-agent（每个 agent 一个 scoped MCP 进程）'
        : 'managed（默认：托管行 + 按会话热切换）',
    agentMounts: perAgent ? 2 : 0,
  },
  // --result 用：点「文件」后结果区要有真实内容，否则只能看到「（无输出）」，
  // 而这一档正是要验证「结果看得见」。
  '/api/dsh-codegraph/files': {
    ok: true,
    path: '/Users/zz/code/my-app',
    raw: '',
    files: [
      { path: 'src/index.ts', language: 'typescript', symbolCount: 42, sizeBytes: 18422 },
      { path: 'src/router.ts', language: 'typescript', symbolCount: 18, sizeBytes: 6110 },
      { path: 'src/store.ts', language: 'typescript', symbolCount: 27, sizeBytes: 9034 },
      { path: 'src/components/App.tsx', language: 'typescript', symbolCount: 12, sizeBytes: 4210 },
      { path: 'src/components/Header.tsx', language: 'typescript', symbolCount: 7, sizeBytes: 2380 },
      { path: 'src/components/Sidebar.tsx', language: 'typescript', symbolCount: 9, sizeBytes: 3105 },
      { path: 'src/utils/format.ts', language: 'typescript', symbolCount: 15, sizeBytes: 4022 },
      { path: 'src/utils/request.ts', language: 'typescript', symbolCount: 11, sizeBytes: 3711 },
      { path: 'src/styles/global.css', language: 'css', symbolCount: 0, sizeBytes: 1840 },
      { path: 'package.json', language: 'json', symbolCount: 0, sizeBytes: 902 },
      { path: 'tsconfig.json', language: 'json', symbolCount: 0, sizeBytes: 610 },
      { path: 'README.md', language: 'markdown', symbolCount: 0, sizeBytes: 5240 },
    ],
  },
  // --feedback 用
  '/api/dsh-codegraph/reprobe': { ok: true, cliAvailable: true },
  '/api/dsh-codegraph/diagnose': {
    ok: true,
    report: '@hyzyn/dsh-codegraph 0.4.2 · node v22.23.2 · darwin arm64\n时间：2026-09-22T13:00:00.000Z\n\ncommand：codegraph\nCLI 探测：可用\n\n托管行生效路径：/Users/zz/code/my-app\n  索引状态：indexed\n（预览夹具：真实诊断包会含补丁区块与 daemon 日志尾，此处截断）',
  },
  '/api/dsh-codegraph/status': {
    ok: true,
    path: '/Users/zz/code/my-app',
    status: {
      initialized: true,
      version: '1.5.0',
      projectPath: '/Users/zz/code/my-app',
      lastIndexed: '2026-09-15T02:21:26.167Z',
      fileCount: 173,
      nodeCount: 4553,
      edgeCount: 21414,
      dbSizeBytes: 32694272,
      pendingChanges: { added: 2, modified: 5, removed: 0 },
      languages: ['javascript', 'typescript', 'yaml'],
    },
  },
  // --adoption 用：真机实测那一档（1 次 codegraph / 1 次发现类 → 50%，另含 1 次读取）。
  // 特意取**真实数字**而不是 `0/0`：0 分母那档文案更短，短文案本来就放得下，
  // 用它会恰好绕开「截断」这个要验的问题。
  ...(adoption
    ? {
        '/api/dsh-codegraph/metrics': {
          ok: true,
          path: '/Users/zz/code/my-app',
          project: '/Users/zz/code/my-app',
          summary: {
            project: '/Users/zz/code/my-app',
            indexed: true,
            codegraph: 1,
            file: 1,
            discovery: 1,
            other: 0,
            exploratory: 2,
            discoveryTotal: 2,
            rate: 0.5,
            discoveryRate: 0.5,
          },
          text: '采纳率：codegraph 1 次 / 发现类 1 次 → 50%（宽口径含读取共 1 次，50%）',
          since: 1789000000000,
        },
      }
    : {}),
}
const SESSION = { byId: { s1: { cwd: '/Users/zz/code/my-app' } }, current: 's1' }

/**
 * 亮色主题 token 子集（值取自 @deepseek-ai/dsh-client-ui-theme）。
 *
 * **名字必须与真主题逐字一致**：这张表是预览脚本自己造的假主题，写错一个名字的代价是
 * 「预览里颜色/框都对、装进真宿主就变样」——`state-warning` 那一族就是这么漏过去的
 * （真名是 `--dsw-alias-state-warn-primary`；见 `scripts/client-lint.mjs` 的检查四）。
 *
 * **基础层（圆角阶梯 / 卡片材质 / 焦点环 / 全局超椭圆）也必须在这里**：它们住在宿主的
 * `base.css` / `focus.css` / `corner-shape.css` 里，不在「皮肤」那份 token 表里。缺了它们的
 * 后果同样是「预览是对的、只有真机是错的」——卡片改走 `--dsw-radius-xl` 后，夹具里没有这个
 * 名字 → 圆角算成 0，而真机是 20px。
 */
const TOKENS = `:root{
  --dsw-font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
  /* 基础层：圆角阶梯与卡片材质（宿主 base.css） */
  --dsw-radius-xs:4px; --dsw-radius-sm:8px; --dsw-radius-md:12px; --dsw-radius-lg:16px; --dsw-radius-xl:20px;
  --dsw-alias-settings-card-fill:var(--dsw-alias-bg-layer-2); --dsw-alias-settings-card-stroke:var(--dsw-alias-border-l4);
  /* 焦点环（宿主 focus.css） */
  --dsw-focus-ring-width:2px;
  /* bg-base：探针详情块（.cg_probeDetail）读它。2026-10-06 起客户端半体去掉了那里的
     字面量兜底（检查十六），夹具必须自己给值——否则预览里那一块的 background 整条作废。 */
  --dsw-alias-bg-base:#fff;
  --dsw-alias-bg-layer-1:#f6f7f9; --dsw-alias-bg-layer-2:#fff; --dsw-alias-bg-layer-3:#fff;
  --dsw-alias-border-l1:#0000000a; --dsw-alias-border-l2:#0000001a; --dsw-alias-border-l3:#0000001f; --dsw-alias-border-l4:#00000029;
  --dsw-alias-label-primary:#0f1115; --dsw-alias-label-secondary:#61666b; --dsw-alias-label-tertiary:#81858c;
  --dsw-alias-label-dimmed:#e1e5ee; --dsw-alias-label-primary-foreground:#fff;
  --dsw-alias-brand-primary:#0f1115; --dsw-alias-button-info-fill:#4176e6; --dsw-alias-button-info-hover:#5686fe;
  /* 按钮族（宿主 Button.module.css）：填充变体用的是 brand 系，不是上面那组强调蓝。
     少了这两行，主按钮 background 简写里的无效 var() 会让**整条声明作废**，预览里就是「白字没底」。 */
  --dsw-alias-button-primary-fill:var(--dsw-alias-brand-primary); --dsw-alias-button-primary-hover:#43454a;
  --dsw-specific-input-major:#fff; --dsw-alias-interactive-bg-hover:#2631480f; --dsw-alias-interactive-bg-active:#2631481a;
  --dsw-alias-state-success-primary:#22c55e; --dsw-alias-state-error-primary:#ec1313;
  --dsw-alias-state-warn-primary:#f59e0b; --dsw-alias-state-business-primary:#4176e6;
}
/* 宿主 corner-shape.css：全局超椭圆（不带这一条，预览就看不到「胶囊被拉变形」这件事，
   也就验不出补上的 corner-shape:round 到底有没有用） */
@supports (corner-shape:superellipse(1.5)){:root{--dsw-corner-shape:superellipse(1.5)}*,:before,:after{corner-shape:var(--dsw-corner-shape)}}
body{margin:0;padding:26px 30px 30px;background:#f5f6f7;font-family:var(--dsw-font-family);-webkit-font-smoothing:antialiased}
.panel{max-width:820px;margin:0 auto}
.panelTitle{color:#0f1115;font-size:18px;font-weight:700;margin:0 0 14px}
ul{margin:0;padding:0}
`

/** 最小 fake React：够跑卡片用到的几个 hook，hook 顺序与真实一致。 */
function makeReact() {
  let hookIndex = 0
  const states = []
  let effects = []
  return {
    React: {
      useState(init) {
        const i = hookIndex++
        if (!(i in states)) states[i] = typeof init === 'function' ? init() : init
        return [states[i], (v) => { states[i] = typeof v === 'function' ? v(states[i]) : v }]
      },
      useMemo(fn) { hookIndex++; return fn() },
      useCallback(fn) { hookIndex++; return fn },
      useEffect(fn) { hookIndex++; effects.push(fn) },
      // 结果区自动滚到可见处用到它。假 DOM 里 ref.current 恒为 null（没有真实节点），
      // 客户端的滚动调用有 typeof 守卫，所以预览下它是安全的空操作。
      useRef(init) { hookIndex++; return { current: init } },
      useSyncExternalStore(_subscribe, get) { hookIndex++; return get() },
    },
    /** 开始一次渲染：重置 hook 游标与本次收集到的 effect。 */
    start() { hookIndex = 0; effects = [] },
    /** 取出并清空本次渲染收集到的 effect。 */
    takeEffects() { const taken = effects; effects = []; return taken },
  }
}

const VOID_TAGS = new Set(['input', 'br', 'img'])
const escapeHtml = (value) => String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')

function toHtml(node) {
  if (node === null || node === undefined || node === false || node === true) return ''
  if (typeof node === 'string' || typeof node === 'number') return escapeHtml(node)
  if (Array.isArray(node)) return node.map(toHtml).join('')
  if (typeof node !== 'object') return ''
  const { type, props = {} } = node
  if (typeof type !== 'string') return toHtml(props.children)
  const attrs = Object.entries(props)
    .filter(([key, value]) => key !== 'children' && value !== undefined && value !== null && typeof value !== 'function' && typeof value !== 'object')
    .map(([key, value]) => (key === 'className' ? ` class="${escapeHtml(value)}"` : ` ${key}="${escapeHtml(value)}"`))
    .join('')
  const inner = toHtml(props.children)
  return VOID_TAGS.has(type) ? `<${type}${attrs}>` : `<${type}${attrs}>${inner}</${type}>`
}

async function renderCardHtml() {
  const source = readFileSync(clientPath, 'utf8')
  let capturedCss = ''
  let Card = null
  const fake = makeReact()

  globalThis.fetch = async (url) => {
    const key = Object.keys(RESPONSES).find((k) => String(url).startsWith(k))
    // --busy：让 /status 挂住不返回 → 组件停在 loading 态（见 busy 的注释）
    if (busy && key === '/api/dsh-codegraph/status') return new Promise(() => {})
    return { ok: true, status: 200, json: async () => (key === undefined ? {} : RESPONSES[key]) }
  }
  globalThis.document = {
    getElementById: () => null,
    createElement: () => {
      // CG37 之后 ensureStyle/releaseStyle 的引用计数挂在**元素 dataset** 上
      // （跨代共享的节点要配跨代共享的计数），所以这个假元素必须带 dataset——
      // 早前只有 { id, textContent, remove }，脚本会在这里 TypeError 直接崩。
      const el = { id: '', textContent: '', dataset: /** @type {Record<string,string>} */ ({}), remove() {} }
      // ensureStyle() 会把真实 CSS 写进这个 style 元素——顺路把它捞出来
      queueMicrotask(() => { capturedCss = el.textContent })
      return el
    },
    head: { appendChild() {} },
  }
  globalThis.window = {
    // 界面语言：`DSH_PREVIEW_LOCALE=en node scripts/preview-card.mjs` 预览英文卡片
    // （默认 zh = 老宿主上的中文兜底，也是既有中文断言的来源）
    __previewLocale: process.env.DSH_PREVIEW_LOCALE,
    __ModuleLoader__: { load: (mod) => { globalThis.__codegraphModule = mod } },
  }
  const requireShim = (name) => {
    if (name === 'react') return fake.React
    if (name === 'react/jsx-runtime') return { jsx: (type, props) => ({ type, props: props ?? {} }), jsxs: (type, props) => ({ type, props: props ?? {} }) }
    throw new Error('unexpected require: ' + name)
  }

  eval(source)
  const exports = globalThis.__codegraphModule.factory(requireShim)
  /**
   * 假 locale 服务（`@deepseek-ai/dsh-client-locale`）：插件用 `ctx.inject(['locale'], cb)`
   * **动态**取它（老宿主上取不到就保持中文兜底）。没有这个桩，`exports.apply` 第一句
   * `installI18n(ctx)` 会直接抛 `ctx.inject is not a function`（search 的 mock-host 踩过，
   * 见 docs/i18n.md § 预览与 smoke 夹具）。boot 前把 `window.__previewLocale` 设成 `'en'`
   * 就能预览英文界面；不设时走 zh，本脚本里既有的中文断言因此不用改。
   */
  const localeDicts = new Map()
  const localeStub = {
    register: (ns, locale, dict) => {
      const entry = localeDicts.get(ns) || {}
      entry[locale] = dict
      localeDicts.set(ns, entry)
      return () => {}
    },
    bind: (ns) => (key, params) => {
      const active = globalThis.window.__previewLocale === 'en' ? 'en' : 'zh'
      const text = ((localeDicts.get(ns) || {})[active] || {})[key] || key
      if (params === undefined) return text
      return String(text).replace(/\{(\w+)\}/g, (_match, name) => (params[name] === undefined ? '' : String(params[name])))
    },
  }
  exports.apply({
    sessions: { list: { subscribe: () => () => {}, getSnapshot: () => SESSION } },
    slots: { inject: (_ns, cb) => cb(), register: (_config, component) => { Card = component } },
    effect: (fn) => fn(),
    inject: (_deps, cb) => {
      const dispose = cb({ locale: localeStub })
      return () => { if (typeof dispose === 'function') dispose() }
    },
  })
  if (Card === null) throw new Error('卡片组件未注册')

  const flatten = (node, acc = []) => {
    if (node === null || node === undefined || typeof node !== 'object') return acc
    if (Array.isArray(node)) { for (const child of node) flatten(child, acc); return acc }
    if (node.type !== undefined) acc.push(node)
    flatten(node.props?.children, acc)
    return acc
  }

  /**
   * 按可见文案找按钮。按钮文案已进 i18n 目录（docs/i18n.md），所以中英各给一份：
   * 默认（zh）走兜底文案，`DSH_PREVIEW_LOCALE=en` 时走英文——只认一种会让另一种语言下的
   * 预览直接抛「找不到按钮」。
   */
  const findButtonByText = (node, texts) => flatten(node).find((n) => n.type === 'button' && texts.includes(n.props?.children))

  // 第一次渲染：卡片折叠
  fake.start()
  const collapsed = Card()
  // 展开卡片（点表头）后再渲染一次，让 body 出现并收集它的 effect
  flatten(collapsed).find((n) => n.props?.className === 'cg_cardHeader').props.onClick()
  fake.start()
  let tree = Card()
  for (const fn of fake.takeEffects()) {
    const dispose = fn()
    if (typeof dispose === 'function') dispose()
  }
  // 等 effect 里的 fetch 落地，再渲染出有数据的版本
  await new Promise((r) => setTimeout(r, 30))
  fake.start()
  tree = Card()

  if (result) {
    // 真的去点一次「文件」：走完整链路（busy → fetch → 写 outputs → 切页签 → 结果区出现）
    const fileButton = findButtonByText(tree, ['文件', 'Files'])
    if (fileButton === undefined) throw new Error('预览：找不到「文件」按钮，--result 失效')
    fileButton.props.onClick()
    fake.start()
    tree = Card()
    for (const fn of fake.takeEffects()) {
      const dispose = fn()
      if (typeof dispose === 'function') dispose()
    }
    await new Promise((r) => setTimeout(r, 30))
    fake.start()
    tree = Card()
  }

  if (feedback) {
    // 点一次「诊断包」：走完整链路（busy → fetch → setReport）。
    //
    // 只点一个而不是连点两个：`loadReport` 开头就 `setOk('')`（新动作清掉上一次结果，
    // 这是既有设计），连点的话成功提示会被清掉，看不到「成功 + 诊断包行」并存的样子。
    // 诊断包行是反馈区里最高的一块，也最能看出脚注有没有被夹在中间。
    const button = findButtonByText(tree, ['诊断包', 'Diagnostics'])
    if (button === undefined) throw new Error('预览：找不到「诊断包」按钮，--feedback 失效')
    button.props.onClick()
    await new Promise((r) => setTimeout(r, 30))
    fake.start()
    tree = Card()
  }

  return `<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8"><style>${TOKENS}${capturedCss}</style></head>
<body><div class="panel"><h1 class="panelTitle">设置 · 插件</h1><ul>${toHtml(tree)}</ul></div></body></html>`
}

const html = await renderCardHtml()
mkdirSync(outDir, { recursive: true })
writeFileSync(htmlPath, html)
console.log('预览 HTML:', htmlPath)

if (process.argv.includes('--png')) {
  /*
   * 浏览器发现走仓库根的共享模块（`scripts/chrome-path.mjs`）。此前这里写死一条
   * **只对 macOS 成立**的 Chrome 路径——任何非 macOS 调用方都命中不了它，而症状是
   * 「未找到 Google Chrome，跳过 PNG」这句**听起来像环境没装浏览器**的话，
   * 真正的原因（路径写死了平台）被这句话盖掉了。
   */
  const chrome = findChrome({ extraCandidates: playwrightChromeCandidates })
  if (chrome === null) {
    console.log('未找到 Chrome/Chromium，跳过 PNG；HTML 已生成，可在浏览器里打开截图。')
    console.log(describeChromeSearch())
  } else {
    // 老版 headless + virtual-time-budget 是这里唯一能稳定退出的组合；
    // --no-sandbox 是因为在受限环境里 Chrome 自己的 sandbox 起不来。
    execFileSync(chrome, [
      '--headless', '--disable-gpu', '--no-sandbox', '--disable-breakpad',
      `--user-data-dir=${join(outDir, 'chrome-profile')}`,
      '--virtual-time-budget=3000', `--window-size=860,${tall ? '1500' : '600'}`,
      `--screenshot=${pngPath}`, `file://${htmlPath}`,
    ], { stdio: 'inherit' })
    console.log('截图 PNG:', pngPath)
  }
}
