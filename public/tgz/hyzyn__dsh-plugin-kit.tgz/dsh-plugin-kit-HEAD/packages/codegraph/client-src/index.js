/* eslint-disable */
/**
 * @hyzyn/dsh-codegraph — 浏览器半体（**源码**）。包根的 client.js 是它的构建产物：
 * `pnpm --filter @hyzyn/dsh-codegraph build` 经 scripts/build-client.mjs 产出
 * （去掉下面那行对 pure.js 的 import，再把 pure.js 的 `export` 前缀剥掉后内联进
 * factory），CI 的 artifact-diff 以逐字节一致为闸——以前是手写产物、与源码之间
 * 没有闸，漂移 CI 看不见（CG28）。
 *
 * 纯逻辑（无 DOM / React 依赖的判定）放 client-src/pure.js，因为那边能进 vitest；
 * 本文件里剩下的都是 React 组件与宿主交互，没有测试底座。新增纯判定请加到 pure.js，
 * 不要写回这里的闭包。
 * 设置面：0.2.0-rc.1 起挂 plugins.bundle.config（插件详情页「说明」下方内联），
 * 旧宿主回退到 0.1.6 线的 plugins.row.config / ≤0.1.5 的 settings.plugin.item，跨版本兼容。
 * 纯前端 React 卡片，宿主经 client-modules 的 combo 路由（/plugins/??<id>/client.js&rev=…）
 * 按 boot graph 下发的 URL 提供；单包直链 /plugins/@hyzyn/dsh-codegraph/client.js 在
 * 当前 DSH（0.1.5-rc.2）上不再直接可用。
 */
import { REL_LIMIT, adoptionText, buildQuery, fmtBytes, fmtNum, fmtTime, nextRetryDelayMs, seenAgoText, shortPath, staleReasons, truncationNote } from './pure.js'

window.__ModuleLoader__.load({
  id: '@hyzyn/dsh-codegraph',
  factory: (require) => {
    const exports = {}

    /* __CODEGRAPH_PURE_INLINE__ */

    const React = require('react')
    const { jsx, jsxs } = require('react/jsx-runtime')

    /* ================================ 国际化 ================================ */

    /*
     * 界面文案走宿主 `@deepseek-ai/dsh-client-locale` 的目录（方案见 docs/i18n.md）。
     * **文案里不许出现字面 `**`**（CG64）：浏览器半体没有 markdown 渲染器，用户看到的就是两个星号；
     * 强调用「」/ “” 或直接换行。
     * 目录**内联在 client-src/index.js**（不是单独一个模块）：本包的 scripts/build-client.mjs
     * 是文本变换脚本，产物必须是单文件，遇到任何残留 import 直接 exit(1)——为目录去改构建
     * 脚本得不偿失。下面这一对目录由 `scripts/check-i18n.mjs` 静态校验：zh/en 键集一致、
     * `{name}` 占位符两边一致、代码里 `t('…')` 用到的键必须在这里有定义。
     *
     * 本文件的界面是 React（jsx/jsxs）渲染，没有手拼 HTML 串，所以不需要 esc()：转义由
     * React 负责（mcp / prompt 那两个包是手拼 innerHTML，那边才必须 esc(t(…))）。
     *
     * **模块级常量里的 `t()` 必须走 getter**：`t()` 在模块加载时求值等于把当前语言冻住
     * （`installI18n(ctx)` 要等 apply 才跑，语言切换也不会重算）——`RESULT_TABS` 的 label
     * 因此写成 getter。
     */
    /* ==== dsh-i18n:begin ==== */
    const I18N_NS = 'codegraph'
    const I18N_ZH = {
      'card.desc': '代码图谱：索引状态、符号搜索、callers/callees/impact、一键 sync/index。',
      'card.summary': '代码图谱：索引状态、符号搜索、探索/上下文、影响面分析、一键 sync/index。',
      'panel.title': 'Codegraph 控制台',
      'panel.tabSearch': '搜索结果',
      'panel.tabDetail': '符号详情',
      'panel.cancelTitle': '终止正在跑的 codegraph CLI（SIGTERM，3s 后整组 SIGKILL）',
      'panel.groupTarget': '目标项目',
      'panel.groupStatus': '索引状态',
      'panel.groupMaintenance': '索引维护',
      'panel.groupSearch': '搜索与查询',
      'panel.groupResults': '结果',
      'panel.groupAgent': 'Agent 集成',
      'panel.rowLifecycle': '生命周期',
      'panel.rowDiagnostics': '查看与诊断',
      'panel.rowOtherQueries': '其他查询',
      'panel.rowFollow': '跟随与提示词',
      'panel.rowMcp': 'MCP 挂载',
      'panel.setDefaultTitle': '把当前路径持久化为默认项目（同时关闭「跟随当前项目」，避免被会话切换顶掉），codegraph MCP 服务器的工作目录随之热切换',
      'panel.seenProjects': '已见项目',
      'panel.defaultProject': '(默认项目)',
      'panel.rawStatusJson': '原始 JSON（status --json）',
      'panel.refreshingAria': '正在读取索引状态',
      'panel.refreshAria': '刷新索引状态',
      'panel.refreshingTitle': '正在读取索引状态…',
      'panel.refreshTitle': '重新读取 `codegraph status --json`，刷新本组的索引状态（不会重建索引）',
      'panel.confirmInitTitle': '再点一次即在 {path} 里创建 .codegraph/ 并建立首次索引',
      'panel.initTitle': 'codegraph index / sync 都要求项目先初始化过（干净目录会报 “CodeGraph not initialized”）。这个按钮在该目录跑一次 `codegraph init`。',
      'panel.syncTitle': 'codegraph sync：增量同步索引（只更新改动的部分；全量重建用右边的「重建索引」）',
      'panel.unlockTitle': 'codegraph unlock：清掉挡住索引的陈旧锁文件（索引被强杀后常见）。没锁时什么也不做',
      'panel.confirmUninitTitle': '再点一次即删除 {path} 的 .codegraph/（索引数据全部丢失，源文件不动）',
      'panel.uninitTitle': 'codegraph uninit：删除该项目的 .codegraph/（索引数据全部丢失，源文件不动）。这是本卡片唯一的删除类动作',
      'panel.reprobeTitle': '重跑一次 `<command> --version`：CLI 是后装的、或 command 改成了绝对路径时，无需重启宿主即可恢复',
      'panel.diagnoseTitle': '收集一段可直接复制的诊断文本：CLI 探测实测原文、托管行与补丁区块（值已脱敏）、索引状态、codegraph daemon 与日志尾、最近一次 CLI 失败',
      'panel.reportSummary': '诊断包（可整段复制贴 issue）',
      'panel.telemetryOn': '匿名用量统计：已开启（init / 重建索引会上报）· 关闭：`codegraph telemetry off` 或 `CODEGRAPH_TELEMETRY=0`',
      'panel.telemetryOff': '匿名用量统计：已关闭',
      'panel.telemetryUnknown': '匿名用量统计：状态未知（CLI 输出未含可识别的状态行）',
      'panel.exploreTitle': 'codegraph explore：与 MCP 的 codegraph_explore 同输出（相关符号源码 + 调用路径）。用左侧搜索框里的关键词',
      'panel.contextTitle': 'codegraph context：为一个任务组装上下文（相关符号 + 关系 + 代码块）。用左侧搜索框里的关键词',
      'panel.kindTitle': 'codegraph query -k/--kind：按节点类型过滤（function / class / method / interface / type_alias / constant / variable / property / file / import）',
      'panel.limitTitle': 'codegraph query -l/--limit：返回条数上限（默认 20）。callers/callees 也吃这个值',
      'panel.filesTitle': 'codegraph files --json：列出索引里的文件结构（语言 / 符号数 / 大小）。不吃搜索框的关键词',
      'panel.affectedTitle': 'codegraph affected <files…>：由改动文件反查受影响的测试。一行一个，也可用逗号分隔；留空则 CLI 回「No files provided」',
      'panel.affectedButtonTitle': 'codegraph affected <files>：由改动文件反查受影响的测试。用左侧「改动文件」里的列表',
      'panel.symbolDetail': '符号详情：{name}',
      'panel.callers': '调用者 (callers)',
      'panel.callees': '被调用 (callees)',
      'panel.impactTitle': '影响面 (impact) · {nodes} 个节点 / {edges} 条边',
      'panel.affectedSymbols': '受影响符号',
      'panel.rawDetailJson': '原始 JSON（node / callers / callees / impact）',
      'panel.followTitle': '开启后：会话切到某个已索引项目时，MCP 托管行的 cwd 自动对齐它；会话目录没有索引时回落到默认项目。「设为默认项目」会关掉它（那是一次显式指定）',
      'panel.announceTitle': '向 agent 注入本插件的能力公告（一段中文提示，告诉模型有这张卡片）',
      'panel.announceDisabled': 'codegraph CLI 不可用，公告不会注入',
      'panel.guidanceTitle': '注入 CodeGraph 使用指引（CODEGRAPH_START 区块：何时优先用 codegraph、失败怎么兜底）',
      'panel.guidanceDisabled': 'codegraph CLI 不可用，使用指引不会注入',
      'panel.perAgentTitle': '每 agent 一个独立的 codegraph MCP 进程（cwd = 该 agent 会话的索引根）：多项目并行时不再共享一个全局 cwd，也不再需要写盘热切换。代价是每个 agent 一个子进程（约 40MB 内存 / 每个），且只有会话目录真的「有索引」时才挂。',
      'panel.perAgentReason': '前提不成立',
      'panel.perAgentTail': '（当前仍是单服务器按会话热切换，功能正常）',
      'panel.perAgentFallback': '⚠ per-agent 未生效，已退回 managed：{reason}{tail}',
      'panel.perAgentActiveTitle': '每个 agent 一个独立的 codegraph MCP 进程；会话目录没有可用索引的 agent 不会挂载（避免拿到别的项目上下文）',
      'panel.perAgentActive': 'per-agent 生效中：已挂载 {count} 个 agent 的独立 MCP 进程。全局托管行已挂起（disabled: true），切回 managed 会自动恢复。',
      'panel.adoptionTitle': '来自宿主的内存计数（session/event 的 tool/call），宿主重启即归零；项目按索引根归并。「文件探索」= grep/glob/read 这类本可交给 codegraph 的工具，bash 等不计入',
      'btn.cancel': '取消',
      'btn.setDefault': '设为默认项目',
      'btn.confirmInit': '确认初始化？',
      'btn.initIndex': '初始化索引',
      'btn.reindex': '重建索引',
      'btn.unlock': '解锁',
      'btn.confirmUninit': '确认撤销？',
      'btn.uninit': '撤销索引',
      'btn.reprobe': '重新探测',
      'btn.diagnose': '诊断包',
      'btn.copy': '复制',
      'btn.search': '搜索',
      'btn.explore': '探索',
      'btn.context': '上下文',
      'btn.files': '文件',
      'btn.affected': '影响面',
      'field.kind': '类型',
      'field.limit': '上限',
      'field.changedFiles': '改动文件',
      'placeholder.projectPath': '项目路径（留空使用默认）',
      'placeholder.searchSymbol': '搜索符号，例如 definePlugin',
      'placeholder.kindAny': '任意（function…）',
      'placeholder.changedFiles': '如 packages/codegraph/src/index.ts（点「影响面」查询）',
      'check.followSession': '跟随当前项目',
      'check.announce': '向 agent 公告能力',
      'check.guidance': '注入使用指引',
      'check.perAgent': 'per-agent MCP 隔离',
      'hint.queryButtons': '搜索 = 符号列表（可点进详情）· 探索 = 相关符号源码 + 调用链 · 上下文 = 为任务组装上下文 · 三者都用左侧关键词',
      'list.statusEmpty': '还没读取到索引状态。',
      'list.noIndexHint': '该目录还没有索引：点下方「初始化索引」即可在本目录跑一次 `codegraph init`（只创建 .codegraph/，源文件不动；可用 `codegraph uninit` 撤销）。',
      'list.noSymbols': '没有匹配的符号。换个关键词，或去掉「类型」过滤。',
      'list.noCallers': '没有调用者',
      'list.noCallees': '没有下游调用',
      'list.noAffected': '没有受影响的符号',
      'list.noResult': '（还没有结果）',
      'list.emptyJson': '（空）',
      'list.noOutput': '（无输出）',
      'list.outputTruncated': '输出较长：只显示了前 {shown} 字符（共 {total} 字符）',
      'list.loadingSymbol': '正在加载符号详情…',
      'list.separator': '；',
      'list.truncatedShown': '已显示前 {shown} 条，共 {total} 条',
      'status.reasonReindex': 'CLI 建议重建索引（reindexRecommended）',
      'status.reasonBuiltWith': '索引由 CLI {built} 构建，当前 CLI 是 {current}',
      'status.reasonExtraction': '索引的提取器版本 {built} 已落后于当前的 {current}',
      'status.reasonWorktree': '索引与当前 worktree 不匹配',
      'meta.adoptionNoRecords': '采纳率：本次宿主运行期间该项目还没有工具调用记录',
      'meta.adoptionNoDiscoveryCalls': '采纳率：还没有探索类调用（另 {other} 次其它工具，如 bash / edit）',
      'meta.adoptionNoDiscovery': '采纳率：还没有发现类调用（codegraph {codegraph} 次 / 读取 {file} 次；另 {other} 次其它工具）',
      'meta.adoptionUnindexed': '（该项目未索引，这个数字不代表提示词效果）',
      'meta.adoptionMain': '采纳率：codegraph {codegraph} 次 / 发现类 {discovery} 次 → {narrow}%',
      'meta.adoptionBroad': '（宽口径含读取 {broad}%）',
      'meta.adoptionOther': '（另 {other} 次其它工具）',
      'meta.seenJustNow': '刚刚',
      'meta.seenMinutes': '{count} 分钟前',
      'meta.seenHours': '{count} 小时前',
      'meta.seenDays': '{count} 天前',
      'badge.notIndexed': ' · 未索引',
      'status.mcpUnknown': 'MCP：状态未知',
      'status.mcpOwn': 'MCP：已托管（本插件维护工作目录）· cwd {cwd}{disabled}{deadCwd}{following}{note}',
      'status.mcpAligned': 'MCP：已对齐 MCP 卡片里的行 · cwd {cwd}{disabled}{deadCwd}{following}{note}',
      'status.mcpExternal': 'MCP：检测到手工配置行，插件不接管',
      'status.mcpUntracked': 'MCP：{note}',
      'status.mcpUnmanaged': '未托管',
      'status.mcpDisabled': ' · 已停用',
      'status.mcpCwdUnset': '(未设置)',
      'status.deadCwd': ' · ⚠ cwd 目录已不存在',
      'status.followingSession': ' · 跟随会话 {path}',
      'status.notAProjectWhy': '它的 .codegraph/ 里没有索引库，不是 codegraph 项目（家目录最常见：~/.codegraph 是 CLI 自身的安装目录）',
      'status.noIndexWhy': '它没有 .codegraph/ 索引',
      'status.fromSession': '（来自当前会话）',
      'status.fromDefault': '（来自默认项目）',
      'status.fixCurrent': '当前路径 {path} 已是有效索引，点「设为默认项目」即可修复。',
      'status.fixOther': '把默认项目切到已索引目录即可自动挂载（也可以直接在该目录里运行 `codegraph init` 建索引）。',
      'status.defaultWarning': '⚠ 托管行用的目录 {shown}{source} 不是有效索引：{why}。未加载项目的 codegraph_* 工具需要显式传 projectPath；{fix}',
      'status.cliMissing': '⚠ 探测不到可执行的 CLI 命令 {command}（`--version` 失败）：systemPrompt 的能力公告与使用指引都不会注入，卡片里的状态 / 搜索 / sync / 重建索引也会报错。',
      'status.cliFix': '\n修法二选一：① 把插件配置里的 command 写成该 CLI 的绝对路径（改 profile 补丁会触发热重载并重新探测）；② 从新开的终端重启宿主，让新的环境块生效。',
      'status.cliNote': '注意：宿主进程的 PATH 在它启动时就固定了，刷新页面 / 重开卡片都不会改变它——改完上面任一项后，点「重新探测」即可就地确认，不必重启宿主。',
      'status.cliTimeoutHint': '\n这次失败是「超时」而不是「命令不存在」：多半是宿主启动时机器繁忙（大量子进程并发 spawn，Windows 上常见；宿主会在超时后于 10s / 30s 各自动重试一次）。等机器空闲后点「重新探测」即可；若空闲时仍超时，再检查 command 路径与命令本身。',
      'status.probeReason': '实测原因：{error}',
      'status.probeAt': '\n上次探测：{time}',
      'status.staleWarning': '⚠ 索引可能过期：{reasons}。MCP 工具此刻给的是旧提取器产出的图——点「重建索引」修复（实测此时 Sync 会报 Already up to date 且不解决问题）。',
      'status.projectSeen': '{path}（{ago}见过，来自{via}）',
      'status.projectNotIndexed': '{path}：未索引，切换无效——先在该目录跑 codegraph init（{via}）',
      'meta.status': '状态',
      'meta.indexed': '● 已索引',
      'meta.uninitialized': '○ 未初始化',
      'meta.version': '版本',
      'meta.project': '项目',
      'meta.scale': '规模',
      'meta.scaleValue': '{files} 文件 · {nodes} 符号 · {edges} 边',
      'meta.lastIndexed': '最后索引',
      'meta.pending': '待同步',
      'meta.languages': '语言',
      'meta.db': '索引库',
      'msg.readingStatus': '读取索引状态…',
      'msg.searching': '搜索中…',
      'msg.loadingSymbol': '加载符号详情…',
      'msg.syncing': '同步中…',
      'msg.reindexing': '重建索引中…',
      'msg.rebuilding': '重建中…',
      'msg.unlocking': '解锁中…',
      'msg.working': '处理中…',
      'msg.uninitializing': '撤销索引中…',
      'msg.removingIndex': '撤销中…',
      'msg.initializingIndex': '初始化索引中…',
      'msg.initializing': '初始化中…',
      'msg.exploring': '探索中…',
      'msg.buildingContext': '组装上下文…',
      'msg.assembling': '组装中…',
      'msg.readingFiles': '读取文件结构…',
      'msg.reading': '读取中…',
      'msg.analyzingImpact': '分析影响面…',
      'msg.analyzing': '分析中…',
      'msg.querying': '查询中…',
      'msg.reprobing': '重新探测 CLI…',
      'msg.collectingDiagnostics': '收集诊断信息…',
      'msg.probing': '探测中…',
      'msg.collecting': '收集中…',
      'msg.switching': '切换中…',
      'msg.synced': '已同步',
      'msg.reindexed': '已重建',
      'msg.unlocked': '解锁完成',
      'msg.done': '已完成',
      'msg.actionResult': '{label}：{output}',
      'msg.uninitDone': '已撤销 {path} 的索引（.codegraph/ 已删除，源文件未动）：{output}',
      'msg.noMatchingFiles': '索引里没有匹配的文件',
      'msg.cancelSent': '已发送取消请求：CLI 进程正在被终止（SIGTERM，3s 后强制）。',
      'msg.initDone': '已初始化并建立索引：{output}',
      'msg.defaultSet': '已把默认项目切到 {path}{session}，并关闭「跟随当前项目」；codegraph MCP 服务器将热切换。',
      'msg.sessionOnly': '（本次会话内生效）',
      'msg.switched': '已切换到 {path}，并关闭「跟随当前项目」；codegraph MCP 服务器将热切换。',
      'msg.announceUpdated': '能力公告已更新',
      'msg.guidanceUpdated': '使用指引已更新',
      'msg.followOn': '已开启跟随当前项目',
      'msg.followOff': '已关闭跟随，托管行使用默认项目',
      'msg.mcpScopePerAgent': '已切到 per-agent：新会话将各挂一个独立的 MCP 进程（已开的会话也会补挂）',
      'msg.mcpScopeManaged': '已切回 managed：全局托管行已恢复，per-agent 挂载已回收',
      'msg.settingUpdated': '设置已更新',
      'msg.reprobeOk': '重新探测成功：CLI 可用，systemPrompt 两段已注入。',
      'msg.reprobeFailed': '重新探测完成：CLI 仍不可用，原因见下方。',
      'msg.reportCopied': '诊断包已复制到剪贴板。',
      'msg.copyUnavailable': '自动复制不可用（{error}）：诊断包已展开在下方，手动全选复制即可。',
      'error.noClipboard': '当前环境没有 navigator.clipboard（非安全上下文？）',
    }
    const I18N_EN = {
      'card.desc': 'Code graph: index status, symbol search, callers/callees/impact, one-click sync/index.',
      'card.summary': 'Code graph: index status, symbol search, explore/context, impact analysis, one-click sync/index.',
      'panel.title': 'Codegraph console',
      'panel.tabSearch': 'Search results',
      'panel.tabDetail': 'Symbol detail',
      'panel.cancelTitle': 'Terminate the running codegraph CLI (SIGTERM, then SIGKILL the whole group after 3s)',
      'panel.groupTarget': 'Target project',
      'panel.groupStatus': 'Index status',
      'panel.groupMaintenance': 'Index maintenance',
      'panel.groupSearch': 'Search and queries',
      'panel.groupResults': 'Results',
      'panel.groupAgent': 'Agent integration',
      'panel.rowLifecycle': 'Lifecycle',
      'panel.rowDiagnostics': 'Inspect and diagnose',
      'panel.rowOtherQueries': 'Other queries',
      'panel.rowFollow': 'Following and prompts',
      'panel.rowMcp': 'MCP mounts',
      'panel.setDefaultTitle': 'Persist the current path as the default project (this also turns off “Follow the current project” so a session switch cannot override it); the codegraph MCP server’s working directory hot-switches with it',
      'panel.seenProjects': 'Projects seen',
      'panel.defaultProject': '(default project)',
      'panel.rawStatusJson': 'Raw JSON (status --json)',
      'panel.refreshingAria': 'Reading index status',
      'panel.refreshAria': 'Refresh index status',
      'panel.refreshingTitle': 'Reading index status…',
      'panel.refreshTitle': 'Re-read `codegraph status --json` to refresh this section’s index status (it does not rebuild the index)',
      'panel.confirmInitTitle': 'Click again to create .codegraph/ in {path} and build the first index',
      'panel.initTitle': 'codegraph index / sync both require an initialized project (a clean directory reports “CodeGraph not initialized”). This button runs `codegraph init` once in that directory.',
      'panel.syncTitle': 'codegraph sync: incrementally sync the index (only the changed parts; use “Reindex” on the right for a full rebuild)',
      'panel.unlockTitle': 'codegraph unlock: clear the stale lock file blocking indexing (common after an index run was killed). Does nothing when there is no lock',
      'panel.confirmUninitTitle': 'Click again to delete .codegraph/ in {path} (all index data is lost; source files are untouched)',
      'panel.uninitTitle': 'codegraph uninit: delete this project’s .codegraph/ (all index data is lost; source files are untouched). This is the only destructive action on this card',
      'panel.reprobeTitle': 'Re-run `<command> --version`: recovers without a host restart when the CLI was installed later or `command` was changed to an absolute path',
      'panel.diagnoseTitle': 'Collect a copy-pasteable diagnostic text: the raw CLI probe result, the managed row and patch block (values redacted), index status, the codegraph daemon and log tail, and the last CLI failure',
      'panel.reportSummary': 'Diagnostic bundle (copy the whole thing into an issue)',
      'panel.telemetryOn': 'Anonymous usage statistics: on (init / reindex report) · turn off: `codegraph telemetry off` or `CODEGRAPH_TELEMETRY=0`',
      'panel.telemetryOff': 'Anonymous usage statistics: off',
      'panel.telemetryUnknown': 'Anonymous usage statistics: status unknown (the CLI output had no recognizable status line)',
      'panel.exploreTitle': 'codegraph explore: same output as the MCP codegraph_explore (relevant symbol sources + call paths). Uses the keyword in the search box on the left',
      'panel.contextTitle': 'codegraph context: assemble context for a task (relevant symbols + relations + code blocks). Uses the keyword in the search box on the left',
      'panel.kindTitle': 'codegraph query -k/--kind: filter by node kind (function / class / method / interface / type_alias / constant / variable / property / file / import)',
      'panel.limitTitle': 'codegraph query -l/--limit: maximum number of results (default 20). callers/callees use it too',
      'panel.filesTitle': 'codegraph files --json: list the file structure in the index (language / symbol count / size). Does not use the search box keyword',
      'panel.affectedTitle': 'codegraph affected <files…>: find the tests affected by the changed files. One per line or comma-separated; leaving it empty makes the CLI answer “No files provided”',
      'panel.affectedButtonTitle': 'codegraph affected <files>: find the tests affected by the changed files. Uses the list in “Changed files” on the left',
      'panel.symbolDetail': 'Symbol detail: {name}',
      'panel.callers': 'Callers',
      'panel.callees': 'Callees',
      'panel.impactTitle': 'Impact · {nodes} nodes / {edges} edges',
      'panel.affectedSymbols': 'Affected symbols',
      'panel.rawDetailJson': 'Raw JSON (node / callers / callees / impact)',
      'panel.followTitle': 'When on: switching to an indexed project aligns the MCP managed row’s cwd with it; when the session directory has no index it falls back to the default project. “Set as default project” turns it off (that is an explicit choice)',
      'panel.announceTitle': 'Inject this plugin’s capability announcement into the agent (a short note in Chinese telling the model this card exists)',
      'panel.announceDisabled': 'The codegraph CLI is unavailable, so the announcement is not injected',
      'panel.guidanceTitle': 'Inject the CodeGraph usage guidance (the CODEGRAPH_START block: when to prefer codegraph and how to fall back when it fails)',
      'panel.guidanceDisabled': 'The codegraph CLI is unavailable, so the usage guidance is not injected',
      'panel.perAgentTitle': 'One separate codegraph MCP process per agent (cwd = that agent session’s index root): parallel projects no longer share a single global cwd and no longer need an on-disk hot switch. The cost is one child process per agent (about 40 MB each), and it mounts only when the session directory really “has an index”.',
      'panel.perAgentReason': 'the precondition does not hold',
      'panel.perAgentTail': ' (still a single server hot-switching per session — everything works normally)',
      'panel.perAgentFallback': '⚠ per-agent is not in effect; fell back to managed: {reason}{tail}',
      'panel.perAgentActiveTitle': 'One separate codegraph MCP process per agent; agents whose session directory has no usable index do not mount one (so they cannot pick up another project’s context)',
      'panel.perAgentActive': 'per-agent is active: {count} agents have their own MCP process. The global managed row is suspended (disabled: true) and is restored when you switch back to managed.',
      'panel.adoptionTitle': 'In-memory counters from the host (session/event tool/call), reset when the host restarts; projects are merged by index root. “File exploration” = tools like grep/glob/read that codegraph could have handled; bash and friends are not counted',
      'btn.cancel': 'Cancel',
      'btn.setDefault': 'Set as default project',
      'btn.confirmInit': 'Initialize?',
      'btn.initIndex': 'Initialize index',
      'btn.reindex': 'Reindex',
      'btn.unlock': 'Unlock',
      'btn.confirmUninit': 'Remove index?',
      'btn.uninit': 'Remove index',
      'btn.reprobe': 'Reprobe',
      'btn.diagnose': 'Diagnostics',
      'btn.copy': 'Copy',
      'btn.search': 'Search',
      'btn.explore': 'Explore',
      'btn.context': 'Context',
      'btn.files': 'Files',
      'btn.affected': 'Impact',
      'field.kind': 'Kind',
      'field.limit': 'Limit',
      'field.changedFiles': 'Changed files',
      'placeholder.projectPath': 'Project path (leave empty to use the default)',
      'placeholder.searchSymbol': 'Search symbols, e.g. definePlugin',
      'placeholder.kindAny': 'Any (function…)',
      'placeholder.changedFiles': 'e.g. packages/codegraph/src/index.ts (then click “Impact”)',
      'check.followSession': 'Follow the current project',
      'check.announce': 'Announce capabilities to the agent',
      'check.guidance': 'Inject usage guidance',
      'check.perAgent': 'per-agent MCP isolation',
      'hint.queryButtons': 'Search = symbol list (click through to details) · Explore = relevant symbol sources + call chains · Context = assemble context for a task · all three use the keyword on the left',
      'list.statusEmpty': 'Index status has not been read yet.',
      'list.noIndexHint': 'This directory has no index yet: click “Initialize index” below to run `codegraph init` once here (it only creates .codegraph/ and leaves source files alone; `codegraph uninit` removes it).',
      'list.noSymbols': 'No matching symbols. Try another keyword, or drop the “Kind” filter.',
      'list.noCallers': 'No callers',
      'list.noCallees': 'No outgoing calls',
      'list.noAffected': 'No affected symbols',
      'list.noResult': '(no results yet)',
      'list.emptyJson': '(empty)',
      'list.noOutput': '(no output)',
      'list.outputTruncated': 'Long output: showing only the first {shown} characters (of {total})',
      'list.loadingSymbol': 'Loading symbol details…',
      'list.separator': '; ',
      'list.truncatedShown': 'Showing the first {shown} of {total}',
      'status.reasonReindex': 'CLI recommends rebuilding the index (reindexRecommended)',
      'status.reasonBuiltWith': 'The index was built by CLI {built}, while the current CLI is {current}',
      'status.reasonExtraction': 'The index extractor version {built} is behind the current {current}',
      'status.reasonWorktree': 'The index does not match the current worktree',
      'meta.adoptionNoRecords': 'Adoption: no tool calls recorded for this project during this host run',
      'meta.adoptionNoDiscoveryCalls': 'Adoption: no exploration calls yet ({other} other tool calls, e.g. bash / edit)',
      'meta.adoptionNoDiscovery': 'Adoption: no discovery calls yet (codegraph {codegraph} / reads {file}; {other} other tool calls)',
      'meta.adoptionUnindexed': ' (this project is not indexed, so the number does not reflect prompt effectiveness)',
      'meta.adoptionMain': 'Adoption: codegraph {codegraph} / discovery {discovery} → {narrow}%',
      'meta.adoptionBroad': ' (broad, reads included: {broad}%)',
      'meta.adoptionOther': ' ({other} other tool calls)',
      'meta.seenJustNow': 'just now',
      'meta.seenMinutes': '{count} minutes ago',
      'meta.seenHours': '{count} hours ago',
      'meta.seenDays': '{count} days ago',
      'badge.notIndexed': ' · not indexed',
      'status.mcpUnknown': 'MCP: status unknown',
      'status.mcpOwn': 'MCP: managed (this plugin maintains the working directory) · cwd {cwd}{disabled}{deadCwd}{following}{note}',
      'status.mcpAligned': 'MCP: aligned with the row in the MCP card · cwd {cwd}{disabled}{deadCwd}{following}{note}',
      'status.mcpExternal': 'MCP: a manually configured row was found; this plugin does not take it over',
      'status.mcpUntracked': 'MCP: {note}',
      'status.mcpUnmanaged': 'unmanaged',
      'status.mcpDisabled': ' · disabled',
      'status.mcpCwdUnset': '(not set)',
      'status.deadCwd': ' · ⚠ cwd directory no longer exists',
      'status.followingSession': ' · following session {path}',
      'status.notAProjectWhy': 'its .codegraph/ has no index database, so it is not a codegraph project (the home directory is the usual case: ~/.codegraph is the CLI’s own install directory)',
      'status.noIndexWhy': 'it has no .codegraph/ index',
      'status.fromSession': ' (from the current session)',
      'status.fromDefault': ' (from the default project)',
      'status.fixCurrent': 'The current path {path} already has a valid index — click “Set as default project” to fix it.',
      'status.fixOther': 'Switch the default project to an indexed directory to mount it automatically (or run `codegraph init` in that directory to build an index).',
      'status.defaultWarning': '⚠ The directory used by the managed row {shown}{source} is not a valid index: {why}. codegraph_* tools without a loaded project need an explicit projectPath; {fix}',
      'status.cliMissing': '⚠ No runnable CLI command found ({command}) (`--version` failed): neither the systemPrompt capability announcement nor the usage guidance will be injected, and status / search / sync / reindex on this card will fail too.',
      'status.cliFix': '\nTwo fixes, pick one: (1) set `command` in the plugin config to that CLI’s absolute path (editing the profile patch triggers a hot reload and a fresh probe); (2) restart the host from a newly opened terminal so the new environment block takes effect.',
      'status.cliNote': 'Note: the host process PATH is fixed when it starts — refreshing the page or reopening the card will not change it. After either fix above, click “Reprobe” to confirm in place; no host restart is needed.',
      'status.cliTimeoutHint': '\nThis failure is a timeout, not a missing command: most likely the machine was busy while the host was booting (dozens of concurrent child-process spawns, common on Windows; the host now retries automatically at 10s and 30s). Click “Reprobe” once the machine is idle; if it still times out on an idle machine, check the command path and the command itself.',
      'status.probeReason': 'Probe result: {error}',
      'status.probeAt': '\nLast probe: {time}',
      'status.staleWarning': '⚠ The index may be stale: {reasons}. MCP tools are currently serving a graph produced by an older extractor — click “Reindex” to fix it (in this state Sync reports Already up to date and does not solve it).',
      'status.projectSeen': '{path} ({ago} seen, via {via})',
      'status.projectNotIndexed': '{path}: not indexed, switching has no effect — run codegraph init in that directory first ({via})',
      'meta.status': 'Status',
      'meta.indexed': '● Indexed',
      'meta.uninitialized': '○ Not initialized',
      'meta.version': 'Version',
      'meta.project': 'Project',
      'meta.scale': 'Scale',
      'meta.scaleValue': '{files} files · {nodes} symbols · {edges} edges',
      'meta.lastIndexed': 'Last indexed',
      'meta.pending': 'Pending',
      'meta.languages': 'Languages',
      'meta.db': 'Index DB',
      'msg.readingStatus': 'Reading index status…',
      'msg.searching': 'Searching…',
      'msg.loadingSymbol': 'Loading symbol details…',
      'msg.syncing': 'Syncing…',
      'msg.reindexing': 'Reindexing…',
      'msg.rebuilding': 'Rebuilding…',
      'msg.unlocking': 'Unlocking…',
      'msg.working': 'Working…',
      'msg.uninitializing': 'Removing index…',
      'msg.removingIndex': 'Removing…',
      'msg.initializingIndex': 'Initializing index…',
      'msg.initializing': 'Initializing…',
      'msg.exploring': 'Exploring…',
      'msg.buildingContext': 'Assembling context…',
      'msg.assembling': 'Assembling…',
      'msg.readingFiles': 'Reading file structure…',
      'msg.reading': 'Reading…',
      'msg.analyzingImpact': 'Analyzing impact…',
      'msg.analyzing': 'Analyzing…',
      'msg.querying': 'Querying…',
      'msg.reprobing': 'Reprobing the CLI…',
      'msg.collectingDiagnostics': 'Collecting diagnostics…',
      'msg.probing': 'Probing…',
      'msg.collecting': 'Collecting…',
      'msg.switching': 'Switching…',
      'msg.synced': 'Synced',
      'msg.reindexed': 'Rebuilt',
      'msg.unlocked': 'Unlocked',
      'msg.done': 'Done',
      'msg.actionResult': '{label}: {output}',
      'msg.uninitDone': 'Removed the index for {path} (.codegraph/ deleted, source files untouched): {output}',
      'msg.noMatchingFiles': 'No matching files in the index',
      'msg.cancelSent': 'Cancellation requested: the CLI process is being terminated (SIGTERM, forced after 3s).',
      'msg.initDone': 'Initialized and indexed: {output}',
      'msg.defaultSet': 'Default project switched to {path}{session}; “Follow the current project” was turned off and the codegraph MCP server will hot-switch.',
      'msg.sessionOnly': ' (effective for this session only)',
      'msg.switched': 'Switched to {path} and turned off “Follow the current project”; the codegraph MCP server will hot-switch.',
      'msg.announceUpdated': 'Capability announcement updated',
      'msg.guidanceUpdated': 'Usage guidance updated',
      'msg.followOn': 'Now following the current project',
      'msg.followOff': 'Following turned off; the managed row uses the default project',
      'msg.mcpScopePerAgent': 'Switched to per-agent: new sessions each mount a separate MCP process (open sessions are backfilled too)',
      'msg.mcpScopeManaged': 'Switched back to managed: the global managed row is restored and per-agent mounts are reclaimed',
      'msg.settingUpdated': 'Setting updated',
      'msg.reprobeOk': 'Reprobe succeeded: the CLI is available and both systemPrompt sections are injected.',
      'msg.reprobeFailed': 'Reprobe finished: the CLI is still unavailable — see the reason below.',
      'msg.reportCopied': 'Diagnostic bundle copied to the clipboard.',
      'msg.copyUnavailable': 'Auto-copy is unavailable ({error}): the diagnostic bundle is expanded below — select it all and copy manually.',
      'error.noClipboard': 'This environment has no navigator.clipboard (insecure context?)',
    }
    /* ==== dsh-i18n:end ==== */

    /** 占位符替换：`{name}` → params.name（缺参留空，不抛错——文案不该打死界面）。 */
    function i18nFormat(text, params) {
      if (params === undefined) return text
      return String(text).replace(/\{(\w+)\}/g, (_match, name) => (params[name] === undefined ? '' : String(params[name])))
    }

    /** 中文兜底：老宿主（DSH ≤0.1.5）没有 locale 服务时，界面不能变成一串键名。 */
    function i18nFallback(key, params) {
      return i18nFormat(I18N_ZH[key] !== undefined ? I18N_ZH[key] : key, params)
    }

    let t = i18nFallback

    /**
     * 注册目录并绑定翻译函数。**动态 inject**：老宿主上回调永不触发、`t` 保持中文兜底；
     * 写成静态 `inject: ['locale']` 会让整张卡片在老宿主上根本不挂。
     */
    function installI18n(ctx) {
      ctx.inject(['locale'], (i18nCtx) => {
        const disposeZh = i18nCtx.locale.register(I18N_NS, 'zh', I18N_ZH)
        const disposeEn = i18nCtx.locale.register(I18N_NS, 'en', I18N_EN)
        t = i18nCtx.locale.bind(I18N_NS)
        return () => {
          disposeEn()
          disposeZh()
          t = i18nFallback
        }
      })
    }

    /* ================================ CSS ================================ */

    const CSS = [
      '.cg_pageHost{display:block}',
      '.cg_pluginCard{list-style:none;border:.5px solid var(--dsw-alias-settings-card-stroke);background:var(--dsw-alias-settings-card-fill);border-radius:var(--dsw-radius-xl);transition:border-color .16s,background .16s}',
      '.cg_pluginCard:hover{border-color:var(--dsw-alias-label-dimmed)}',
      '.cg_pluginCardOpen{background:var(--dsw-alias-bg-layer-1);border-color:var(--dsw-alias-label-dimmed)}',
      '.cg_cardHeader{appearance:none;width:100%;color:inherit;font:inherit;text-align:left;cursor:pointer;background:0 0;border:0;border-radius:var(--dsw-radius-xl);display:flex;align-items:center;gap:12px;padding:14px 16px}',
      '.cg_cardHeader:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:-2px}',
      '.cg_cardHeadText{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}',
      // 卡片标题 = 宿主 cardTitle 的角色（14 / 500 / 20）：600/700 会让插件卡片的标题比宿主
      // 自己那排卡片重一档；行高按官方成对值写（规范：font-size 必须配 line-height）。
      '.cg_cardName{color:var(--dsw-alias-label-primary);font-size:14px;font-weight:500;line-height:20px}',
      '.dshkit_badge{flex:none;margin-left:auto;padding:1px 8px;border-radius:999px;corner-shape:round;font-size:11px;font-weight:600;line-height:16px;letter-spacing:.02em;color:var(--dsw-alias-label-dimmed);background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1)}',
      '.cg_cardDescription{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px}',
      '.cg_chevron{flex:none;color:var(--dsw-alias-label-tertiary);transition:transform .16s}',
      '.cg_pluginCardOpen .cg_chevron{transform:rotate(180deg)}',
      '.cg_cardBody{padding:2px 16px 16px}',
      '.cg_panel{display:flex;flex-direction:column;gap:12px;color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-family);box-sizing:border-box}',
      // 面板头只剩标题（布局分组后工具栏自成分组，不再挤在标题旁边），包一层的
      // .cg_panelHeader 随之删除；.cg_panelTitle 原来的 flex:1 是给「标题 + 按钮组」
      // 那个 flex 行用的，单独成行后留着只会在列布局里引入无意义的伸缩。
      '.cg_panelTitle{margin:0;font-size:15px;font-weight:500;line-height:22px;white-space:nowrap}',
      // 面板标题行：标题 + 忙碌指示器（+ 取消）。忙碌指示器放在这里而不是正文中间，
      // 是因为索引操作可能跑十分钟——放正文里会随滚动移出视野，而且插入/移除会让
      // 下面整组控件上下跳动。标题行本来就在，挂在它右边是**零布局跳动**且常驻可见。
      '.cg_panelHeader{display:flex;align-items:center;gap:10px;flex-wrap:wrap}',
      // 忙碌指示器：转圈 + 「在做什么」+（可取消时）取消按钮，三者挨着——
      // 「停」的对象就是左边那件事，不该分到另一行去。
      '.cg_busy{display:inline-flex;align-items:center;gap:7px;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);min-width:0}',
      // 纯 CSS 转圈：不引图标、不加 DOM。用当前色描边 + 主题色顶边，跟着文字颜色走。
      '.cg_spinner{flex:none;width:12px;height:12px;border:2px solid var(--dsw-alias-border-l2);border-top-color:var(--dsw-alias-state-business-primary);border-radius:50%;corner-shape:round;animation:cg_spin .7s linear infinite}',
      // 按钮内的忙碌内容（转圈 + 文案）。按钮本身是 inline 元素，包一层 inline-flex
      // 才能让转圈与文字基线对齐；不设固定宽度——忙碌文案比静止时略长，按钮会宽一点，
      // 这点局部位移远好过「点了没有任何反馈」。
      // gap 取 4px = 宿主 .button 的 gap：转圈与忙碌文案的间距跟按钮原语一致。
      '.cg_btnBusy{display:inline-flex;align-items:center;gap:4px}',
      '@keyframes cg_spin{to{transform:rotate(360deg)}}',
      // 尊重「减少动态效果」：关掉旋转，靠文案与取消按钮继续表达「正在进行」。
      // 组头里的图标按钮：紧凑、无边框，hover 才给底色——它是辅助动作，不抢视觉。
      // 尺寸与圆角不动（24×24/R8 本就合规），只统一状态：禁用 .4 + not-allowed、补 :active，
      // 焦点环换成宿主 51 处组件用的官方 outline（不自造私有环——那会顶掉宿主全局 :focus-visible）。
      '.cg_iconBtn{display:inline-flex;align-items:center;justify-content:center;flex:none;width:24px;height:24px;padding:0;color:var(--dsw-alias-label-secondary);background:0 0;border:1px solid transparent;border-radius:var(--dsw-radius-sm);cursor:pointer}',
      '.cg_iconBtn:hover:not(:disabled){color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-hover)}',
      '.cg_iconBtn:active:not(:disabled){background:var(--dsw-alias-interactive-bg-active)}',
      '.cg_iconBtn:disabled{opacity:.4;cursor:not-allowed}',
      '.cg_iconBtn:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary))}',
      // 刷新进行中：图标自转（复用 cg_spin）。只在**本动作**在跑时转（data-busy 由
      // busyAction 驱动），否则搜个符号也会让刷新图标转起来，等于报错信息。
      '.cg_iconBtn[data-busy="1"] svg{animation:cg_spin .7s linear infinite}',
      '@media (prefers-reduced-motion:reduce){.cg_spinner,.cg_iconBtn[data-busy="1"] svg{animation:none}}',
      // 采纳率那行**不截断**：它是卡片里唯一一行长度不可控的说明文案（数字随两个口径与
      // 工具种类变化），而 nowrap + ellipsis + max-width:360px 会把它切成半句——用户实测
      // 看到的是「…→ 50%（宽口径含」，后半句（宽口径的解释）永远读不到。数字说明宁可两行、
      // 不可半句：与同分区的 .cg_mcpMeta / .cg_warn 一致地换行，只保留等宽字体。
      '.cg_subtitle{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;font-family:var(--ds-font-family-code);min-width:0}',
      // 索引维护按钮组改成「可换行的行」而不是「整组 nowrap」：
      // 早先只有 5 个按钮，整组 nowrap + margin-left:auto 能让它们要么留在标题右边、
      // 要么整组换行；P2 加到 12 个之后这招失效——12 个按钮约 900px，而侧边栏只有
      // ~360px，整组不许断行就只能溢出被裁（实测截图里「撤销索引」被切掉）。
      // 布局分组后 margin-left:auto + 右对齐也一并去掉：按钮组不再和标题抢一行，
      // 右对齐只会让折行后的行尾参差（截图实证：「诊断包 / 撤销索引」孤零零悬在
      // 第二行右侧）。现在组自成分组、左对齐自然换行，阅读顺序 = 视觉顺序。
      '.cg_toolbarBtns{display:flex;align-items:center;gap:8px;flex-wrap:wrap}',
      // 按钮族对齐宿主 ui-primitives 的 Button：本包按钮原本就是 H28 档，故统一取官方 size="sm"
      // （H28 / R8 / 12px + 18px / padding 0 10px）。填充与描边**逐项同尺寸**——否则同一枚按钮
      // 换变体时会跳一下。底色从 --dsw-alias-button-info-fill 换成 button-primary-fill：前者是
      // 宿主给图标/徽标/圆形发送键的**强调蓝**，后者才是 .primary 的填充；不设字重（宿主 Button
      // 不设，跟着容器继承）；字号必须配行高（官方规范硬性条款）。
      '.cg_btn{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:4px;height:28px;padding:0 10px;border:none;border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground);font-family:inherit;font-size:12px;line-height:18px;white-space:nowrap;cursor:pointer}',
      '.cg_btn:hover:not(:disabled){background:var(--dsw-alias-button-primary-hover)}',
      '.cg_btn:disabled{opacity:.4;cursor:not-allowed}',
      '.cg_btn:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary))}',
      // 描边档 = Button variant="outline" size="sm"：尺寸与主按钮逐项一致，只差描边与底色。
      // 描边取 border-l3（宿主 .outline 用的那一档，-l2 更淡）。
      '.cg_btnGhost{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:4px;height:28px;padding:0 10px;border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-sm);background:transparent;color:var(--dsw-alias-label-primary);font-family:inherit;font-size:12px;line-height:18px;white-space:nowrap;cursor:pointer}',
      '.cg_btnGhost:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}',
      '.cg_btnGhost:active:not(:disabled){background:var(--dsw-alias-interactive-bg-active)}',
      '.cg_btnGhost:disabled{opacity:.4;cursor:not-allowed}',
      '.cg_btnGhost:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary))}',
      // 「初始化索引」的二次确认态：它会往用户项目里写 .codegraph/，用告警色区别于普通按钮。
      // 它与被替换掉的 Ghost 是**同一个按钮元素**（JSX 里二选一），所以几何必须逐项相同，
      // 只有 color / border / hover 是危险色——尺寸不同会让「确认」那一下按钮跳一格。
      '.cg_btnDanger{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:4px;height:28px;padding:0 10px;border:.5px solid color-mix(in srgb,var(--dsw-alias-state-error-primary) 30%,transparent);border-radius:var(--dsw-radius-sm);background:0 0;color:var(--dsw-alias-state-error-primary);font-family:inherit;font-size:12px;line-height:18px;white-space:nowrap;cursor:pointer}',
      // danger 是独立类（不叠加 Ghost），必须自带 hover：否则悬停只吃到 Ghost 的中性灰底。
      // 两条同为 :not(:disabled) 形状、权重相同 (0,3,0)，靠源码顺序（本行在 Ghost 之后）取胜；
      // 底色 8% 红对齐官方 danger 的 interactive-bg-hover 重绑。
      '.cg_btnDanger:hover:not(:disabled){background:color-mix(in srgb,var(--dsw-alias-state-error-primary) 8%,transparent)}',
      // 输入档对齐宿主 settings-form 的 .input（H34 / R12 / border-l4 / bg-layer-3 / 13px）：
      // 显式 height 是关键——同一个类套到 <select> 上时 Chrome 不看继承的 line-height，
      // 没有它就会比同排的 <input> 矮 2px；圆角取 token 而非 8px 字面量，才看得出选的是哪一档。
      '.cg_input{box-sizing:border-box;width:100%;height:34px;padding:0 12px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-3);border:.5px solid var(--dsw-alias-border-l4);border-radius:var(--dsw-radius-md);outline:none;font-family:inherit;font-size:13px;line-height:1.5}',
      '.cg_input:focus{border-color:var(--dsw-alias-state-business-primary)}',
      '.cg_input::placeholder{color:var(--dsw-alias-label-tertiary)}',
      // 搜索行：原来固定 3 列 grid（路径输入 / 搜索输入 / 搜索按钮）。P2 把「探索」「上下文」
      // 也放进这一行（它们吃搜索框的关键词），4-5 列会把两个输入框挤到无法使用，
      // 所以改成 flex：输入框按 flex 比例伸缩，按钮按内容宽度、放不下就整行换行。
      '.cg_row{display:flex;flex-wrap:wrap;gap:8px;align-items:center}',
      '.cg_row .cg_input{flex:1 1 160px;width:auto;min-width:120px}',
      '.cg_list{display:flex;flex-direction:column;gap:8px;max-height:360px;overflow-y:auto}',
      '.cg_item{background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-md);padding:8px 10px;cursor:pointer;font-size:12.5px;line-height:18px}',
      '.cg_item:hover{border-color:var(--dsw-alias-label-dimmed)}',
      '.cg_itemName{font-weight:500;color:var(--dsw-alias-label-primary)}',
      '.cg_itemMeta{color:var(--dsw-alias-label-tertiary);font-family:var(--ds-font-family-code);font-size:12px;line-height:18px;margin-top:2px}',
      '.cg_pre{background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1);border-radius:8px;padding:10px;max-height:320px;overflow:auto;font-family:var(--ds-font-family-code);font-size:12px;line-height:18px;white-space:pre-wrap;word-break:break-all;color:var(--dsw-alias-label-primary)}',
      // 空态文案（列表为空时的占位）。`.cg_loading` 已退役：忙碌态改成标题行里的
      // 内联指示器（见 .cg_busy / .cg_spinner）——原先它是**居中大块**
      // （padding:24px 12px），既不说在加载什么、又把下面整组控件推下去（布局跳动），
      // 而且 Sync 跑十分钟时它会随滚动移出视野。
      '.cg_empty{text-align:center;color:var(--dsw-alias-label-tertiary);padding:24px 12px;font-size:12.5px;line-height:18px}',
      // 反馈容器：面板统一 12px 间距，但「刚才那次操作的结果」这几条之间用 6px——
      // 收紧后它们读成一个整体，而不是几条互不相干的段落（用户反馈「这一块挺乱」）。
      '.cg_feedback{display:flex;flex-direction:column;gap:6px}',
      // 问题区（页面最前）：与反馈区同样收紧间距，让几条警告读成一个整体。
      '.cg_alerts{display:flex;flex-direction:column;gap:6px}',
      '.cg_error{color:var(--dsw-alias-state-error-primary);font-size:12px;line-height:18px;margin:0;white-space:pre-wrap}',
      '.cg_ok{color:var(--dsw-alias-state-success-primary);font-size:12px;line-height:18px;margin:0}',
      '.cg_sectionTitle{margin:0;font-size:13px;font-weight:500;line-height:20px;color:var(--dsw-alias-label-secondary)}',
      // 面板分组（布局重构）：小标题 + 通栏细线。把原先「12 个按钮 + 5 类控件挤在一条
      // 无分层长列」的面板（截图实证：按钮换行后行尾参差、复选框和说明文字混排、
      // 「设为默认项目」孤悬在两组控件之间）按语义分组，每组内部仍是可换行的 flex 行。
      //
      // UX 重构后的自上而下顺序：目标项目 → 索引状态 → 索引维护 → 搜索与查询 →
      // Agent 集成。此前「索引状态」沉在最底部，打开卡片要先越过两行输入框和 9 个
      // 按钮才知道索引健不健康——状态先于操作，且「过期警告」与修它的「重建索引」
      // 按钮上下相邻。
      '.cg_section{display:flex;flex-direction:column;gap:8px}',
      '.cg_sectionHead{display:flex;align-items:center;gap:10px}',
      // 小号分区标签（11px + 字距）属于「小 tag」档：字号保留，只补官方成对行高 16，
      // 并把区块标题的 700 降回宿主标题用的 500。
      '.cg_sectionHeadText{font-size:11px;font-weight:500;line-height:16px;letter-spacing:.08em;color:var(--dsw-alias-label-tertiary);white-space:nowrap}',
      '.cg_sectionRule{flex:1;height:1px;background:var(--dsw-alias-border-l1)}',
      '.cg_grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px}',
      '.cg_cell{background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-md);padding:8px 10px;min-width:0}',
      '.cg_k{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;letter-spacing:.02em}',
      '.cg_v{color:var(--dsw-alias-label-primary);font-size:13px;font-weight:500;line-height:20px;margin-top:3px;overflow-wrap:anywhere}',
      '.cg_vMono{font-family:var(--ds-font-family-code);font-size:12px;font-weight:500;line-height:18px}',
      '.cg_badgeOk{color:var(--dsw-alias-state-success-primary)}',
      '.cg_badgeWarn{color:var(--dsw-alias-state-warn-primary,var(--dsw-alias-state-error-primary))}',
      '.cg_details{border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-md);background:var(--dsw-alias-bg-layer-2)}',
      '.cg_details>summary{cursor:pointer;padding:7px 10px;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);list-style:none}',
      '.cg_details>summary::-webkit-details-marker{display:none}',
      '.cg_details>summary::before{content:"▸ ";color:var(--dsw-alias-label-tertiary)}',
      '.cg_details[open]>summary::before{content:"▾ "}',
      '.cg_details .cg_pre{border:0;border-top:.5px solid var(--dsw-alias-border-l1);border-radius:0 0 9px 9px;max-height:260px;margin:0}',
      '.cg_rel{display:flex;flex-direction:column;gap:4px}',
      '.cg_relItem{display:flex;gap:8px;align-items:baseline;font-size:12px;line-height:18px;min-width:0}',
      '.cg_relName{color:var(--dsw-alias-label-primary);font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '.cg_relMeta{color:var(--dsw-alias-label-tertiary);font-family:var(--ds-font-family-code);font-size:12px;line-height:18px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '.cg_mcpMeta{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;min-width:0}',
      '.cg_warn{color:var(--dsw-alias-state-warn-primary,var(--dsw-alias-state-error-primary));font-size:12px;line-height:18px;margin:0;white-space:pre-wrap}',
      // 探测失败的实测原文：用等宽 + 淡色和上面的指引分开，让「ENOENT / 非零退出 / 超时」
      // 一眼可辨，而不是混在说明文字里被当成人话略过去。
      '.cg_probeDetail{color:var(--dsw-alias-label-secondary);background:var(--dsw-alias-bg-base);border-radius:var(--dsw-radius-sm);font-family:var(--ds-font-family-code);font-size:12px;line-height:18px;margin:0;padding:6px 8px;white-space:pre-wrap;word-break:break-all}',
      '.cg_checks{display:flex;align-items:center;gap:16px;flex-wrap:wrap;font-size:12.5px;line-height:18px;color:var(--dsw-alias-label-secondary)}',
      '.cg_check{display:inline-flex;align-items:center;gap:6px;cursor:pointer}',
      '.cg_check input{cursor:pointer}',
      // 原生复选框的选中态走宿主的中性 brand（Checkbox.module.css 是唯一原语）：
      // brand-primary 浅色近黑，而 business-primary(#4176e6) 是状态与徽标用的强调蓝——
      // 用后者就是浏览器默认蓝勾那种错。尺寸也取宿主的 16×16。
      '.cg_check input[type=checkbox]{width:16px;height:16px;margin:0;flex:none;cursor:pointer;accent-color:var(--dsw-alias-brand-primary)}',
      '.cg_check input[type=checkbox]:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:2px}',
      '.cg_check[data-off="1"]{opacity:.55;cursor:default}',
      // P2 项目列表：一行横向滚动的胶囊按钮。flex-wrap 而不是滚动条——项目一般
      // 个位数，换行比隐藏更利于发现；窄屏下自动堆成多行。
      '.cg_projects{display:flex;align-items:center;gap:6px;flex-wrap:wrap;font-size:12px;line-height:18px}',
      '.cg_projectsLabel{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;white-space:nowrap}',
      // 胶囊按钮：形状保持不动（999px + corner-shape 是既有形状），排版改回按钮族的官方 sm 配方
      // （12px + 18px）——它此前是全包唯一漏网的 11.5/16，跟同族的 .cg_btn 不同档；
      // 禁用态跟族里其它按钮统一成 .4 + not-allowed。
      '.cg_projectBtn{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l2);border-radius:999px;corner-shape:round;padding:2px 10px;font-size:12px;line-height:18px;cursor:pointer;font-family:var(--ds-font-family-code);white-space:nowrap;max-width:260px;overflow:hidden;text-overflow:ellipsis}',
      '.cg_projectBtn:hover:not(:disabled){border-color:var(--dsw-alias-state-business-primary)}',
      '.cg_projectBtn:disabled{opacity:.4;cursor:not-allowed}',
      // P2 查询参数面板：小号输入 + 内联标签，跟搜索行区分开（搜索行是主操作）
      '.cg_queryOpts{display:flex;align-items:center;gap:12px;flex-wrap:wrap;font-size:12px;line-height:18px}',
      '.cg_opt{display:inline-flex;align-items:center;gap:6px;color:var(--dsw-alias-label-tertiary);white-space:nowrap}',
      '.cg_optWide{flex:1;min-width:220px}',
      '.cg_optWide .cg_inputSm{flex:1}',
      '.cg_inputSm{width:150px;padding:4px 8px;font-size:12px;line-height:18px}',
      // 「上限」这类纯数字小输入用不着 150px，紧凑尺寸让参数行一行能多放一项
      '.cg_inputXs{width:64px;padding:4px 8px;font-size:12px;line-height:18px}',
      // 组内小标题（UX 重构）：比 .cg_sectionHeadText 更轻，用于一个分组内部的子层级——
      // 「生命周期 / 查看与诊断 / 危险」「符号查询 / 改动影响」「跟随与提示词 / MCP 挂载」。
      // 只留文字不带通栏线：组已经有自己的分隔线，组内再画一条就是噪音。
      '.cg_rowLabel{font-size:11px;font-weight:500;line-height:16px;letter-spacing:.06em;color:var(--dsw-alias-label-tertiary);white-space:nowrap}',
      // 删除类动作的行内槽位：与左侧常规按钮之间一道**竖向虚线**。
      // 为什么是行内槽而不是独立一行：独立成行会让「一个按钮 + 右侧大片空白」看起来
      // 像换行 bug（用户实证提问），而它本来就属于「生命周期」这一档。竖向虚线保留
      // 「这个与前面那几个不是一类」的标记，又不浪费一整行。
      // 换行时它可能落到行首，那时左边虚线正好当行首标记，仍然成立。
      '.cg_dangerSlot{display:inline-flex;align-items:center;padding-left:9px;margin-left:1px;border-left:1px dashed var(--dsw-alias-border-l2)}',
      // 结果区页签栏：下划线的页签（比按钮更像「视图切换」），底部一条细线把整栏连起来。
      '.cg_tabs{display:flex;align-items:center;gap:2px;flex-wrap:wrap;border-bottom:.5px solid var(--dsw-alias-border-l1)}',
      '.cg_tab{color:var(--dsw-alias-label-secondary);background:0 0;border:0;border-bottom:2px solid transparent;padding:5px 10px;font-size:12.5px;line-height:18px;font-family:inherit;cursor:pointer;white-space:nowrap}',
      '.cg_tab:hover{color:var(--dsw-alias-label-primary)}',
      '.cg_tabOn{color:var(--dsw-alias-label-primary);font-weight:600;border-bottom-color:var(--dsw-alias-state-business-primary)}',
      // 面板给个内边距，让内容与页签栏分开；min-height 避免空态时整块塌成一条线。
      '.cg_tabPanel{padding-top:2px;min-height:20px}',
    ].join('\n')

    // CG08/CG37：样式引用计数。同一次挂载会把这张卡片注册进多个插槽（0.1.6 上
    // plugins.row.config 与 settings.kit.item 会同时命中），「任一实例卸载即 remove」
    // 会让另一张还在显示的卡片瞬间全裸。且**计数必须挂在元素上**（dataset）、不能
    // 挂在闭包里：同一份 client.js 可能被宿主再次执行（HMR / 重载不换 document 的
    // 场景），闭包计数是每一代各一份、节点却是文档共享的——闭包计数下旧一代卸载
    // 会摘掉新一代在用的节点，新一代也因 getElementById 早退而永远摘不掉。
    function ensureStyle() {
      let el = document.getElementById('dsh-codegraph-style')
      if (el === null) {
        el = document.createElement('style')
        el.id = 'dsh-codegraph-style'
        el.textContent = CSS
        document.head.appendChild(el)
      }
      el.dataset.cgRefs = String(Number(el.dataset.cgRefs ?? '0') + 1)
    }
    function releaseStyle() {
      const el = document.getElementById('dsh-codegraph-style')
      if (el === null) return
      const refs = Math.max(0, Number(el.dataset.cgRefs ?? '1') - 1)
      if (refs === 0) el.remove()
      else el.dataset.cgRefs = String(refs)
    }

    /* ================================ API ================================ */

    async function api(path, options) {
      const response = await fetch(path, options)
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        throw new Error(data.error || ('HTTP ' + response.status))
      }
      return data
    }

    // CG51：查询串拼装已抽到 client-src/pure.js 的 buildQuery（数组逐个 append，
    // 否则 affected 的多文件会被折成 "a.ts,b.ts" 一个值），构建时内联进本 factory。
    const qs = (params) => buildQuery(params)

    /* ======================== 运行时会话引用 ======================== */

    // apply 时注入的 sessions 服务（浏览器运行时全局 store，非 React 内部状态）。
    // 用于读取「当前活动会话的工作目录」，让 Codegraph 默认跟随当前项目，
    // 而不是钉死在宿主启动目录（process.cwd()）。
    let sessionsService = null

    /**
     * 当前活动会话的工作目录；没有活动会话（或它没有 cwd）时返回 ''。
     *
     * 会话列表快照（SessionListState）只有 ids / byId / phase / subagentsByParent /
     * jobsBySession —— **没有 current 字段**，所以旧实现读的 `snapshot.current` 恒为
     * undefined，`byId[undefined]` 取不到任何会话，cwd 永远是 ''：卡片不跟随会话，
     * 上报接口只会报到空路径，托管行 cwd 就永远停在默认项目上。
     *
     * 「主视图正在展示的那个会话」由 retainedBy.mainView > 0 标记，宿主自带的
     * layout / workspace / cordis / settings-general 等客户端插件都这么取。
     */
    const activeSessionCwd = () => {
      try {
        const snapshot = sessionsService?.list?.getSnapshot?.()
        const active = Object.values(snapshot?.byId ?? {}).find((row) => (row?.retainedBy?.mainView ?? 0) > 0)
        const cwd = active?.cwd
        return typeof cwd === 'string' && cwd !== '' ? cwd : ''
      } catch {
        return ''
      }
    }

    /* ================================ 设置卡片 ================================ */

    /**
     * 刷新图标（Material「refresh」的路径，viewBox 24×24）。
     * 组头里的动作用图标而不是文字：它是「属于这一组」的辅助动作，不该和组内主控件
     * 抢视觉重量（用户建议改成图标）。语义靠 `title` + `aria-label` 补足——
     * 纯图标按钮对读屏与悬停都必须有话说。
     */
    const REFRESH_PATH = 'M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-8 8s3.58 8 8 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z'
    const CHEVRON_PATH = 'M11.8486 5.5L11.4238 5.92383L8.69727 8.65137C8.44157 8.90706 8.21562 9.13382 8.01172 9.29785C7.79912 9.46883 7.55595 9.61756 7.25 9.66602C7.08435 9.69222 6.91565 9.69222 6.75 9.66602C6.44405 9.61756 6.20088 9.46883 5.98828 9.29785C5.78438 9.13382 5.55843 9.13382 5.30273 8.65137L2.57617 5.92383L2.15137 5.5L3 4.65137L3.42383 5.07617L6.15137 7.80273C6.42595 8.07732 6.59876 8.24849 6.74023 8.3623C6.87291 8.46904 6.92272 8.47813 6.9375 8.48047C6.97895 8.48703 7.02105 8.48703 7.0625 8.48047C7.07728 8.47813 7.12709 8.46904 7.25977 8.3623C7.40124 8.24849 7.57405 8.07732 7.84863 7.80273L10.5762 5.07617L11 4.65137L11.8486 5.5Z'

    // P3：fmtNum / fmtBytes / fmtTime 已抽到 client-src/pure.js（可直接进 vitest），
    // 构建时内联进本 factory；此处只留调用点。

    /** 一个「标签 + 值」的单元格。 */
    const cell = (key, value, options) => jsxs('div', {
      className: 'cg_cell',
      children: [
        jsx('div', { className: 'cg_k', children: key }),
        jsx('div', {
          className: (options && options.mono ? 'cg_v cg_vMono' : 'cg_v') + (options && options.tone ? ' ' + options.tone : ''),
          title: options && options.title ? options.title : undefined,
          children: value,
        }),
      ],
    }, 'cell-' + key)

    /**
     * 索引状态：按 CLI `status --json` 的字段铺成紧凑网格。
     * 形状不符（JSON 解析失败时的 `{raw}`、或 CLI 报错文本）才回落到原始文本。
     */
    const statusCells = (status) => {
      const pending = status.pendingChanges && typeof status.pendingChanges === 'object' ? status.pendingChanges : {}
      return [
        cell(t('meta.status'), status.initialized ? t('meta.indexed') : t('meta.uninitialized'), { tone: status.initialized ? 'cg_badgeOk' : 'cg_badgeWarn' }),
        cell(t('meta.version'), String(status.version ?? '—'), { mono: true }),
        cell(t('meta.project'), String(status.projectPath ?? '—'), { mono: true, title: status.projectPath }),
        cell(t('meta.scale'), t('meta.scaleValue', { files: fmtNum(status.fileCount), nodes: fmtNum(status.nodeCount), edges: fmtNum(status.edgeCount) })),
        cell(t('meta.lastIndexed'), fmtTime(status.lastIndexed)),
        cell(t('meta.pending'), '+' + fmtNum(pending.added ?? 0) + ' ~' + fmtNum(pending.modified ?? 0) + ' -' + fmtNum(pending.removed ?? 0)),
        cell(t('meta.languages'), Array.isArray(status.languages) && status.languages.length > 0 ? status.languages.join(' / ') : '—'),
        cell(t('meta.db'), fmtBytes(status.dbSizeBytes), { mono: true }),
      ]
    }

    // CG11 的 staleReasons 已抽到 client-src/pure.js（可直接进 vitest），构建时内联进本
    // factory；此处只留调用点（面板警告行）。

    /** 关系列表（callers / callees / affected 共用）；超过 REL_LIMIT 条给出截断计数（CG17）。 */
    const relList = (title, items, emptyText) => {
      const truncated = truncationNote(items.length, REL_LIMIT, t)
      return jsxs('div', {
        children: [
          jsx('p', { className: 'cg_sectionTitle', children: title }),
          items.length === 0
            ? jsx('div', { className: 'cg_itemMeta', children: emptyText })
            : jsxs('div', {
              className: 'cg_rel',
              children: [
                ...items.slice(0, REL_LIMIT).map((item, index) => jsxs('div', {
                  className: 'cg_relItem',
                  children: [
                    jsx('span', { className: 'cg_relName', children: item.name || '(unnamed)' }),
                    jsx('span', { className: 'cg_relMeta', children: (item.kind || '') + ' · ' + (item.filePath || '') + (item.startLine ? ':' + item.startLine : '') }),
                  ],
                }, 'rel-' + title + '-' + index)),
                ...(truncated === ''
                  ? []
                  : [jsx('div', { className: 'cg_itemMeta', children: truncated }, 'rel-truncated-' + title)]),
              ],
            }),
        ],
      })
    }

    /**
     * 面板分组（布局重构）：小标题 + 通栏细线的分组头，下面挂该组的具体控件行。
     * 为什么分组：控件涨到 P2 规模后（12 个工具按钮、4 个开关、3 类查询参数），
     * 一条无分层的长列在窄栏里就是「按钮换行行尾参差、开关和说明文字混排、
     * 「设为默认项目」孤悬两组之间」的乱（用户截图实证）；按「目标项目 / 搜索与
     * 查询 / 索引维护 / Agent 集成 / 索引状态」分组后，每组语义单一，扫一眼能定位。
     */
    /**
     * 结果区的页签（顺序 = 展示顺序）。触发按钮用同一批 key 调 setActiveTab，
     * 所以新增一种查询时只需在这里加一行、在按钮上接一次 busyOr/setActiveTab。
     *
     * label 写成 **getter**：这是模块级常量，直接 `t(...)` 会在模块加载时求值、把语言冻住
     * （mcp 的 STATUS_TEXT 踩过这个坑）。`文件` / `影响面` / `探索` / `上下文` 四个页签与
     * 同名按钮用的是同一批键——两处文案本来就是同一个词，共用一个键免得两边译文漂开。
     */
    const RESULT_TABS = [
      { key: 'search', get label() { return t('panel.tabSearch') } },
      { key: 'files', get label() { return t('btn.files') } },
      { key: 'affected', get label() { return t('btn.affected') } },
      { key: 'explore', get label() { return t('btn.explore') } },
      { key: 'context', get label() { return t('btn.context') } },
      { key: 'detail', get label() { return t('panel.tabDetail') } },
    ]
    /** 会被「索引变化」弄陈旧的那几个页签（重建 / 撤销后要清掉）。 */
    const INDEX_RESULT_TABS = ['files', 'affected', 'explore', 'context']

    /**
     * explore / context / files 这类输出的渲染上限（字符）。
     *
     * CG61：超限以前是**静默** `slice(0, 4000)`——与本包自己的 CG17 纪律（「不再静默丢」，
     * 关系列表截断要报计数）不一致：用户看到的是「输出就这么长」，真相是被截了，而
     * explore 的 markdown 恰恰是「相关符号 + 调用链」，末尾被吃掉会误导判断。
     * 现在超限时在下面补一行计数，并说明完整输出在宿主侧（`raw` 也在响应里）。
     */
    const OUTPUT_LIMIT = 4000

    /** 单个查询结果（files / affected / explore / context）的正文。 */
    const renderOutputBody = (output) => {
      if (output.text !== '') {
        // explore / context 的 markdown：原样按等宽显示（卡片不做 markdown 渲染，
        // 免得引一套 renderer；内容本身就是给模型读的源码 + 关系）
        // 截断计数自己拼而不是复用 truncationNote：那个函数的量词是「条」（给关系列表用），
        // 这里数的是字符，套上去会变成「已显示前 4000 条」。
        return jsxs('div', {
          children: [
            jsx('pre', { className: 'cg_pre', children: output.text.slice(0, OUTPUT_LIMIT) }),
            output.text.length > OUTPUT_LIMIT
              ? jsx('p', {
                className: 'cg_itemMeta',
                children: t('list.outputTruncated', { shown: OUTPUT_LIMIT, total: output.text.length }),
              })
              : null,
          ],
        })
      }
      return Array.isArray(output.json)
        ? (output.json.length === 0
          ? jsx('p', { className: 'cg_mcpMeta', children: t('list.emptyJson') })
          : jsx('pre', {
            className: 'cg_pre',
            children: output.json.map((item) => typeof item === 'string'
              ? item
              : (item.path ?? item.file ?? JSON.stringify(item))).join('\n'),
          }))
        : jsx('pre', { className: 'cg_pre', children: (output.raw || t('list.noOutput')).slice(0, OUTPUT_LIMIT) })
    }

    /**
     * 面板分组：小标题 + 通栏细线 +（可选）尾随动作。
     *
     * `action` 是「属于本组的**单个辅助动作**」——典型例子是「刷新」：它重新读取的正是
     * 「索引状态」这一组的数据，原先却放在「索引维护 → 查看与诊断」里，隔着一整屏
     * （用户直接问「这个状态和刷新状态有关系吗」）。放到组头右侧，关系一眼可见。
     *
     * **不要把主操作组放进这个槽**（被问过「生命周期那几个按钮要不要也放到头上」）：
     *
     *   - 组头是「标签 + 细线 + 一个紧凑控件」，细线靠 flex:1 占满剩余宽度；塞进 4 个
     *     文字按钮（约 390px）会把细线挤没，窄栏下还会折成两截，看起来像布局坏了；
     *   - 更要紧的是**视觉重量**：Sync 是这张卡片的主按钮（cg_btn 实心蓝），进组头就
     *     降级成与标签并排的小控件，主次颠倒；而「索引维护」这一节的**内容本来就是
     *     这些动作**，组头只负责给它命名，不该把内容搬到名字旁边。
     *
     * 判据：**一个**动作、且是辅助性的（图标 / 小按钮）→ 放组头；**一组**动作、
     * 或这组的主体就是它们 → 留在组内。
     *
     * 细线用显式元素而不是 `::after`：伪元素永远排在盒内最后，尾随按钮会跑到细线
     * **左边**（贴着标签），右对齐就失效了。
     */
    const group = (label, children, action) => jsxs('div', {
      className: 'cg_section',
      children: [
        jsxs('div', {
          className: 'cg_sectionHead',
          children: [
            jsx('span', { className: 'cg_sectionHeadText', children: label }),
            jsx('span', { className: 'cg_sectionRule' }),
            ...(action === undefined || action === null ? [] : [action]),
          ],
        }),
        ...children,
      ],
    }, 'cg-group-' + label)

    function CodegraphSettingsCard(props) {
      // DSH ≥0.1.6 的插件配置页把同一条目按 view 渲染两次：summary 一句话摘要、page 完整表单。
      // 旧版（≤0.1.5）的 settings.plugin.item 卡片不带 view，走原有可折叠卡片分支。
      const view = props && props.view
      const pageView = view === 'page'
      // CG08：样式跟着卡片实例走（引用计数，见 ensureStyle/releaseStyle）
      React.useEffect(() => {
        ensureStyle()
        return releaseStyle
      }, [])
      const [open, setOpen] = React.useState(pageView)
      const [path, setPath] = React.useState('')
      const [manual, setManual] = React.useState(false)
      const [status, setStatus] = React.useState(null)
      const [query, setQuery] = React.useState('')
      // P2 查询参数面板：CLI 的 -k/--kind 与 -l/--limit 此前卡片够不着（limit 固定 20）。
      // kind 刻意用**自由文本**而不是下拉枚举：上游加新 kind 时插件不必跟着改，
      // 填错 CLI 自己会回空结果（与卡片上其它旋钮的取向一致）。
      const [queryKind, setQueryKind] = React.useState('')
      // P2「影响面」：affected 需要一份**改动文件**列表。刻意不让插件去猜（不读 git status、
      // 不猜编辑器状态）——待测文件从哪来是用户/上游流程的事，插件只负责把给定的列表
      // 交给 CLI。多行或逗号分隔都收。
      const [changedFiles, setChangedFiles] = React.useState('')
      const [queryLimit, setQueryLimit] = React.useState('20')
      const [results, setResults] = React.useState([])
      const [selected, setSelected] = React.useState(null)
      const [detail, setDetail] = React.useState(null)
      const [error, setError] = React.useState('')
      const [ok, setOk] = React.useState('')
      const [loading, setLoading] = React.useState(false)
      /**
       * 忙碌指示器上那句「在做什么」（`''` = 不显示）。
       *
       * 为什么不能只有一个布尔：索引重建可能跑十分钟，而一句笼统的「加载中…」既让
       * 用户不知道在等什么、也无法判断该不该按「取消」。各动作进入忙碌态时给一句
       * 具体文案（同步中 / 重建索引中 / 搜索中…），由 {@link beginBusy} 统一设置。
       */
      const [busy, setBusy] = React.useState('')
      /**
       * 正在跑的是**哪个动作**（`''` = 没有）。用于让被点的那个按钮自己显示忙碌态。
       *
       * 为什么不能只靠标题行的全局指示器（用户截图实证）：卡片很长，滚到下半部分
       * （搜索与查询 / Agent 集成）时标题行已经移出视野——在那里点「搜索」「影响面」
       * 完全没有反馈。按钮就在手指底下，是唯一「无论滚到哪都看得见」的位置。
       */
      const [busyAction, setBusyAction] = React.useState('')
      const [mcp, setMcp] = React.useState(null)
      // GET /default-path 的索引态：默认项目（= 托管 MCP 的 cwd）是否真是有效索引。
      // 只看 mcp.mode 会把「已对齐一个非项目目录」显示成一切正常。
      const [defaultInfo, setDefaultInfo] = React.useState(null)
      const [settingDefault, setSettingDefault] = React.useState(false)
      // CG21：「重新探测」和「设为默认项目」是两个动作，各自有忙态——共用一个布尔
      // 会把对方一起禁掉（点一个灰另一个）。
      const [reprobing, setReprobing] = React.useState(false)
      // P1-b：诊断包（GET /diagnose 回一段纯文本）。与其它忙态分开：它会读 daemon 日志，
      // 不该把「刷新状态 / 重新探测」一起灰掉。
      const [diagnosing, setDiagnosing] = React.useState(false)
      const [report, setReport] = React.useState('')
      // P1「采纳率仪表」：本会话/本项目里模型用 codegraph 还是用 grep/read。
      const [adoption, setAdoption] = React.useState(null)
      // P2 项目列表：一键切换的候选（宿主侧登记表，只含工作过的目录）。
      const [projects, setProjects] = React.useState([])
      // P2 CLI 面：explore / context 的文本输出（markdown），files / affected 的结构化结果。
      /**
       * 查询结果按**路由分槽**保存（`files` / `affected` / `explore` / `context` 各一格）。
       *
       * 为什么不再用单槽：结果区改成页签后，切回上一个页签必须还能看到那次的结果——
       * 单槽会让「点文件 → 点探索 → 切回文件」变成空白。
       */
      const [outputs, setOutputs] = React.useState({})
      /**
       * 结果区当前显示的页签：`'search'` / `'detail'` / 四个查询路由之一。
       * 由触发它的按钮设置，所以「点哪就跳到哪一页」。
       */
      const [activeTab, setActiveTab] = React.useState('')
      /** 结果区容器：查询完成后若它不在视野里就滚过去（否则「点了看不到」）。 */
      const resultRef = React.useRef(null)
      // P2 遥测提示：上游 CLI 会为 init / index 发匿名用量统计，用户该看得见这件事。
      const [telemetry, setTelemetry] = React.useState(null)
      // 撤销索引是破坏性动作（删 .codegraph/）：与「初始化索引」一样两步确认
      const [confirmUninit, setConfirmUninit] = React.useState(false)
      // CG05：sync / index / init 是可能跑 10 分钟的索引类操作，进行中给出「取消」。
      const [cancelable, setCancelable] = React.useState(false)
      // 「初始化索引」是两步确认：它会**往用户的项目里写 `.codegraph/`**，是本卡片唯一
      // 的写操作。第一次点只改成确认文案，第二次才真的发请求（比 window.confirm 可控，
      // 也不用为一次动作引一套弹窗组件）。
      const [confirmInit, setConfirmInit] = React.useState(false)

      // 当前活动会话的工作目录（随会话切换实时更新；无活动会话时为 ''）。
      const currentCwd = React.useSyncExternalStore(
        (subscribe) => sessionsService.list.subscribe(subscribe),
        activeSessionCwd,
      )

      // 有效路径：手动编辑过就用手动值（清空则回落后端默认）；
      // 未编辑过则跟随当前活动会话的工作目录。
      const effectivePath = path !== '' ? path : (manual ? '' : currentCwd)

      const loadMcpStatus = React.useCallback(async () => {
        try {
          const data = await api('/api/dsh-codegraph/default-path')
          setMcp(data.mcp || null)
          setDefaultInfo({
            defaultPath: typeof data.defaultPath === 'string' ? data.defaultPath : '',
            indexed: data.indexed === true,
            indexState: typeof data.indexState === 'string' ? data.indexState : '',
            // 提示词注入开关（settings 命名空间里的真值）+ CLI 探测结果
            // （undefined = 宿主还没探测完，此时不提示不可用）。
            announceToAgent: data.announceToAgent === true,
            usageGuidance: data.usageGuidance === true,
            cliAvailable: data.cliAvailable,
            // 探测失败的实测原因（ENOENT / 非零退出 / 超时原文）与探测时刻。
            // 有它才能把「常见原因是…」这种猜测换成用户一眼能判断的原文。
            cliProbeError: typeof data.cliProbeError === 'string' ? data.cliProbeError : '',
            cliProbeAt: typeof data.cliProbeAt === 'number' ? data.cliProbeAt : 0,
            command: typeof data.command === 'string' ? data.command : '',
            followSession: data.followSession === true,
            effectivePath: typeof data.effectivePath === 'string' ? data.effectivePath : '',
            sessionPath: typeof data.sessionPath === 'string' ? data.sessionPath : '',
            // P0：MCP 挂载模式。requested = 用户选的，effective = 实际生效的；
            // 两者不等时说明前提不成立（宿主没有 agent 事件面 / 有区块外手工行），
            // 原因由宿主给出，卡片照原样显示——静默退回等于骗用户。
            mcpScope: typeof data.mcpScope === 'string' ? data.mcpScope : 'managed',
            effectiveMcpScope: typeof data.effectiveMcpScope === 'string' ? data.effectiveMcpScope : 'managed',
            mcpScopeReason: typeof data.mcpScopeReason === 'string' ? data.mcpScopeReason : '',
            agentMounts: typeof data.agentMounts === 'number' ? data.agentMounts : 0,
          })
        } catch {
          setMcp(null)
          setDefaultInfo(null)
        }
      }, [])

      /**
       * 进入 / 退出忙碌态。`loading` 管「禁用控件」，`busy` 管「在做什么」——
       * 两个一起动，避免出现「控件灰着但不知道在等什么」或「提示说在忙但按钮还能点」。
       * 文案一律具体到动作（不用笼统的「加载中」）。
       */
      const beginBusy = (label, action) => {
        setLoading(true)
        setBusy(label)
        setBusyAction(action)
      }
      const endBusy = () => {
        setLoading(false)
        setBusy('')
        setBusyAction('')
      }

      /**
       * 按钮内容的忙碌呈现：正在跑的那个动作显示「转圈 + 忙碌文案」，其余保持原样。
       * 局部反馈（这里）与全局指示器（标题行）**都要有**：前者保证「点哪看得见哪」，
       * 后者保证「滚到顶时一眼看到在忙什么」。
       */
      const busyOr = (action, idle, active) => (busyAction === action
        ? jsxs('span', { className: 'cg_btnBusy', children: [jsx('span', { className: 'cg_spinner' }), active] })
        : idle)

      const loadStatus = React.useCallback(async () => {
        beginBusy(t('msg.readingStatus'), 'status')
        setError('')
        setOk('')
        try {
          const data = await api('/api/dsh-codegraph/status' + qs({ path: effectivePath }))
          setStatus(data.status || data)
          if (!manual && !currentCwd) setPath(data.path || '')
        } catch (err) {
          setError(err.message)
        } finally {
          endBusy()
        }
      }, [effectivePath, manual, currentCwd])

      /**
       * 取采纳率（P1）。刻意**不**并入 loadStatus：采纳率是宿主侧内存里的累计值，
       * 与目标路径的索引状态是两件事——某个项目未索引也可能有数字（模型在这个目录里
       * 用不用 codegraph），失败不该影响状态面板。
       */
      const loadAdoption = React.useCallback(async () => {
        try {
          const data = await api('/api/dsh-codegraph/metrics' + qs({ path: effectivePath }))
          setAdoption(data && data.summary ? data.summary : null)
        } catch {
          // 采纳率是观测功能：拿不到就不显示，不打扰用户（也不覆盖已有的错误提示）
          setAdoption(null)
        }
      }, [effectivePath])

      /**
       * 拉项目列表（P2）。候选由宿主侧登记表给出——只含「用户真的在这里工作过」的目录
       * （活跃会话 / 跟随上报 / 查过状态的路径），每条现算索引态。
       */
      const loadTelemetry = React.useCallback(async () => {
        try {
          const data = await api('/api/dsh-codegraph/telemetry')
          setTelemetry({ enabled: data.enabled, output: typeof data.output === 'string' ? data.output : '' })
        } catch {
          // 旧版 CLI 没有 telemetry 子命令：不显示这一行，也不打扰用户
          setTelemetry(null)
        }
      }, [])

      const loadProjects = React.useCallback(async () => {
        try {
          const data = await api('/api/dsh-codegraph/projects')
          setProjects(Array.isArray(data.projects) ? data.projects : [])
        } catch {
          // 项目列表是便利功能：拿不到就不显示，不打扰用户
          setProjects([])
        }
      }, [])

      /**
       * 结果出来后，若结果区不在视野里就滚过去。
       *
       * 为什么需要：触发按钮与结果区隔着一段（「文件」在索引维护、结果区在搜索与查询
       * 下方），窄面板 + 展开的诊断包会把结果推到视野外——用户报的「点击文件看不到
       * 对应的列表」正是如此。`block:'nearest'` 的语义是**已经在视野里就不动**，
       * 所以手动切页签时页面不会无故跳动。
       */
      React.useEffect(() => {
        if (activeTab === '') return
        const el = resultRef.current
        // 预览的假 DOM 里 ref.current 恒为 null、节点也没有 scrollIntoView：静默跳过
        if (el === null || el === undefined || typeof el.scrollIntoView !== 'function') return
        try {
          el.scrollIntoView({ block: 'nearest' })
        } catch {
          /* 老浏览器不认参数对象：忽略（不滚也比抛错好） */
        }
      }, [activeTab])

      React.useEffect(() => {
        if (open) {
          loadStatus()
          loadMcpStatus()
          loadAdoption()
          loadProjects()
          loadTelemetry()
        }
      }, [open, loadStatus, loadMcpStatus, loadAdoption, loadProjects, loadTelemetry])

      // 跟随当前项目：打开卡片或切换会话时，若用户未手动编辑过路径，
      // 自动采用当前活动会话的工作目录；手动编辑后停止跟随。
      React.useEffect(() => {
        if (!open || manual) return
        setPath(currentCwd)
      }, [open, manual, currentCwd])

      // 目标路径一换，上一个目录的「确认初始化」就不该还挂着——否则很容易在 A 目录点上
      // 确认、切到 B 目录再点一次，把 B 给初始化了（那正是这个动作最该防的误伤）。
      React.useEffect(() => {
        setConfirmInit(false)
        setConfirmUninit(false)
      }, [effectivePath, open])

      const search = async () => {
        if (!query.trim()) return
        beginBusy(t('msg.searching'), 'search')
        setError('')
        setOk('')
        setSelected(null)
        setDetail(null)
        try {
          const limit = Number(queryLimit)
          const data = await api('/api/dsh-codegraph/query' + qs({
            q: query.trim(),
            path: effectivePath,
            limit: Number.isInteger(limit) && limit > 0 ? String(limit) : '20',
            ...(queryKind.trim() === '' ? {} : { kind: queryKind.trim() }),
          }))
          setResults(Array.isArray(data.results) ? data.results : [])
          setActiveTab('search')
        } catch (err) {
          setError(err.message)
        } finally {
          endBusy()
        }
      }

      const loadSymbol = async (name) => {
        beginBusy(t('msg.loadingSymbol'), 'symbol')
        setError('')
        setOk('')
        // CG16：先清掉上一个符号的详情——标题马上要换成新符号，面板还挂着旧的
        // callers/callees/impact，加载失败时就是张冠李戴（search() 清了，这里漏了）
        setDetail(null)
        setSelected(name)
        setActiveTab('detail')
        try {
          const [node, callers, callees, impact] = await Promise.all([
            api('/api/dsh-codegraph/node' + qs({ name, path: effectivePath })),
            api('/api/dsh-codegraph/callers' + qs({ symbol: name, path: effectivePath })),
            api('/api/dsh-codegraph/callees' + qs({ symbol: name, path: effectivePath })),
            api('/api/dsh-codegraph/impact' + qs({ symbol: name, path: effectivePath, depth: 2 })),
          ])
          setDetail({ node, callers, callees, impact })
        } catch (err) {
          setError(err.message)
        } finally {
          endBusy()
        }
      }

      /**
       * 索引被重建 / 撤销后，之前查的「文件 / 影响面 / 探索 / 上下文」结果就是陈旧的了
       * （它们描述的是旧索引），清掉并把页签退出去——留着会让用户照着旧文件列表做判断。
       * 搜索结果与符号详情不清：那是符号级查询，用户多半还要对照着看。
       */
      const clearIndexResults = () => {
        setOutputs({})
        setActiveTab((current) => (INDEX_RESULT_TABS.includes(current) ? '' : current))
      }

      const runAction = async (action) => {
        // 忙碌文案按动作分派：重建索引可能跑十分钟，用户需要知道在等的是哪件事，
        // 才能判断该不该按旁边的「取消」
        beginBusy({ sync: t('msg.syncing'), index: t('msg.reindexing'), unlock: t('msg.unlocking') }[action] || t('msg.working'), action)
        setError('')
        setOk('')
        // unlock 是秒级操作，不给取消按钮（给了一个点完就消失的「取消」只会让人困惑）
        setCancelable(action === 'sync' || action === 'index')
        // 文案按动作分派；`unlock` 的 CLI 输出在「本来就没锁」时是
        // "No stale lock files found"，原样带出来最诚实
        const successLabel = { sync: t('msg.synced'), index: t('msg.reindexed'), unlock: t('msg.unlocked') }[action] || t('msg.done')
        try {
          const data = await api('/api/dsh-codegraph/' + action, {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ path: effectivePath }),
          })
          setOk(t('msg.actionResult', { label: successLabel, output: (data.output || '').slice(0, 200) }))
          await loadStatus()
        } catch (err) {
          setError(err.message)
        } finally {
          endBusy()
          setCancelable(false)
        }
      }

      /**
       * 撤销索引（P2）：删除 `.codegraph/`。与 init 反向，是本卡片第二个破坏性动作，
       * 所以同样两步确认；目标路径一换就重置确认态（同 init 的理由：避免在 A 目录
       * 点上确认、切到 B 再点一次，把 B 给删了）。
       */
      const runUninit = async () => {
        if (!confirmUninit) {
          setConfirmUninit(true)
          setError('')
          setOk('')
          clearIndexResults()
          return
        }
        setConfirmUninit(false)
        beginBusy(t('msg.uninitializing'), 'uninit')
        setError('')
        setOk('')
        setCancelable(true)
        try {
          const data = await api('/api/dsh-codegraph/uninit', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ path: effectivePath }),
          })
          setOk(t('msg.uninitDone', { path: data.path || effectivePath, output: (data.output || '').slice(0, 160) }))
          setStatus(null)
          clearIndexResults()
          await Promise.all([loadStatus(), loadMcpStatus(), loadProjects()])
        } catch (err) {
          setError(err.message)
        } finally {
          endBusy()
          setCancelable(false)
        }
      }

      /** 把「改动文件」输入解析成数组（逗号 / 换行 / 空格分隔都收，去重去空）。 */
      const manualFiles = () => {
        const seen = new Set()
        for (const piece of changedFiles.split(/[\n,]/)) {
          const value = piece.trim()
          if (value !== '') seen.add(value)
        }
        return [...seen]
      }

      /**
       * 跑一个只读文本/结构化命令（P2）：files / affected / explore / context。
       * 与 runAction 分开是因为它们**不改状态**，只需展示输出，不该触发 loadStatus。
       */
      const runQuery = async (route, params = {}) => {
        beginBusy({ files: t('msg.readingFiles'), affected: t('msg.analyzingImpact'), explore: t('msg.exploring'), context: t('msg.buildingContext') }[route] || t('msg.querying'), route)
        setError('')
        setOk('')
        try {
          const data = await api('/api/dsh-codegraph/' + route + qs({ path: effectivePath, ...params }))
          // explore / context 回 markdown 文本；files / affected 回结构化数组。
          // 按路由分槽保存，切页签回来还在（见 outputs 的注释）。
          setOutputs((previous) => ({
            ...previous,
            [route]: {
              route,
              text: typeof data.output === 'string' ? data.output : '',
              json: data.files ?? data.affected ?? null,
              raw: typeof data.raw === 'string' ? data.raw : '',
            },
          }))
          setActiveTab(route)
          if (data.files !== undefined && (!Array.isArray(data.files) || data.files.length === 0)) {
            setOk(t('msg.noMatchingFiles'))
          }
        } catch (err) {
          setError(err.message)
        } finally {
          endBusy()
        }
      }

      /** 取消进行中的 sync / index / init（CG05：以前关标签页都止不住 10 分钟的 index）。 */
      const cancelRun = async () => {
        setError('')
        try {
          await api('/api/dsh-codegraph/cancel', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ path: effectivePath }),
          })
          setOk(t('msg.cancelSent'))
        } catch (err) {
          setError(err.message)
        }
      }

      /**
       * 在未初始化的项目里跑 `codegraph init`（建 `.codegraph/` + 首次索引）。
       *
       * 为什么需要它：`codegraph index` / `sync` 都要求项目**已经** init 过——对干净目录
       * 直接报 `CodeGraph not initialized in <path>` / `Run "codegraph init" first`
       * （`index --help` 那句「same result as a fresh init」说的是全量重建的结果，不是
       * 「index 会替你初始化」）。没有这个按钮，本卡片是唯一还要把用户赶回终端的一步；
       * 而 MCP 托管行也只在目标已是有效索引时才写，新项目等于整块功能不可用。
       */
      const runInit = async () => {
        if (!confirmInit) {
          setConfirmInit(true)
          setError('')
          setOk('')
          return
        }
        setConfirmInit(false)
        beginBusy(t('msg.initializingIndex'), 'init')
        setError('')
        setOk('')
        setCancelable(true)
        try {
          const data = await api('/api/dsh-codegraph/init', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ path: effectivePath }),
          })
          setOk(t('msg.initDone', { output: (data.output || '').slice(0, 200) }))
          clearIndexResults()
          await loadStatus()
          // 索引态变了 → MCP 托管行的决策也跟着变，必须重新取一次
          await loadMcpStatus()
        } catch (err) {
          setError(err.message)
        } finally {
          endBusy()
          setCancelable(false)
        }
      }

      // 把当前有效路径设为默认项目：宿主会持久化并热切换 codegraph MCP 服务器
      const setDefaultProject = async () => {
        if (!effectivePath) return
        setSettingDefault(true)
        setError('')
        setOk('')
        try {
          const data = await api('/api/dsh-codegraph/default-path', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ path: effectivePath }),
          })
          setMcp(data.mcp || null)
          setOk(t('msg.defaultSet', {
            path: data.defaultPath || effectivePath,
            session: data.persisted === false ? t('msg.sessionOnly') : '',
          }))
          await loadMcpStatus()
        } catch (err) {
          setError(err.message)
        } finally {
          setSettingDefault(false)
        }
      }

      /**
       * 切到某个项目：复用「设为默认项目」那条链路（它会持久化 defaultPath 并关掉跟随、
       * 热切换 MCP 服务器）。与点「设为默认项目」的区别只是路径来自列表而不是输入框。
       */
      const switchProject = async (target) => {
        if (!target) return
        setSettingDefault(true)
        setError('')
        setOk('')
        try {
          const data = await api('/api/dsh-codegraph/default-path', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ path: target }),
          })
          // 切完把输入框也同步过去，否则卡片上「正在看的路径」还是旧的那个
          setManual(true)
          setPath(target)
          setMcp(data.mcp || null)
          setOk(t('msg.switched', { path: data.defaultPath || target }))
          await Promise.all([loadMcpStatus(), loadProjects()])
        } catch (err) {
          setError(err.message)
        } finally {
          setSettingDefault(false)
        }
      }

      // 提示词注入开关：写 settings 命名空间（宿主即时增删 systemPrompt section，
      // 不需要重启）；CLI 探测失败时禁用——那时候两段本来就不会注入。
      const toggleSetting = async (key, value) => {
        setError('')
        setOk('')
        try {
          await api('/api/dsh-codegraph/settings', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ [key]: value }),
          })
          await loadMcpStatus()
          setOk({
            announceToAgent: t('msg.announceUpdated'),
            usageGuidance: t('msg.guidanceUpdated'),
            followSession: value ? t('msg.followOn') : t('msg.followOff'),
            mcpScope: value === 'per-agent'
              ? t('msg.mcpScopePerAgent')
              : t('msg.mcpScopeManaged'),
          }[key] || t('msg.settingUpdated'))
        } catch (err) {
          setError(err.message)
          await loadMcpStatus()
        }
      }

      /**
       * 重新探测 CLI。为什么必须是一个显式动作：探测结果原先是挂载时锁存的一个布尔，
       * 刷新卡片只是再读一次同一个缓存——那句「刷新本卡片重试」在服务端不可能生效。
       * 现在它真的会重跑 `<command> --version`，并把实测原因（含失败原文）取回来。
       * 忙态独立于「设为默认项目」（CG21：共用一个布尔会互相禁用）。
       */
      const reprobe = async () => {
        setReprobing(true)
        setError('')
        setOk('')
        try {
          const data = await api('/api/dsh-codegraph/reprobe', { method: 'POST' })
          await loadMcpStatus()
          setOk(data.cliAvailable === true
            ? t('msg.reprobeOk')
            : t('msg.reprobeFailed'))
        } catch (err) {
          setError(err.message)
          await loadMcpStatus()
        } finally {
          setReprobing(false)
        }
      }

      /**
       * 拉诊断包（P1-b）。为什么值得做成按钮：这个插件的故障几乎全是环境性的——
       * PATH 里没有 CLI、`~/.codegraph` 被当成项目索引、托管行 cwd 被删、一次被强杀的
       * index 留下坏锁、daemon 登记的是另一个版本。以前这些要用户从四五个地方凑原文，
       * 而排查者最需要的就是那几段原文。结果是一整段纯文本，直接复制即可。
       */
      const loadReport = async () => {
        setDiagnosing(true)
        setError('')
        setOk('')
        try {
          const data = await api('/api/dsh-codegraph/diagnose' + qs({ path: effectivePath }))
          setReport(typeof data.report === 'string' ? data.report : '')
        } catch (err) {
          setError(err.message)
        } finally {
          setDiagnosing(false)
        }
      }

      /** 复制诊断包到剪贴板：优先 Clipboard API，不可用（非安全上下文）时退回选中文本。 */
      const copyReport = async () => {
        setError('')
        try {
          const clipboard = typeof navigator !== 'undefined' ? navigator.clipboard : undefined
          if (clipboard && typeof clipboard.writeText === 'function') {
            await clipboard.writeText(report)
            setOk(t('msg.reportCopied'))
            return
          }
          throw new Error(t('error.noClipboard'))
        } catch (err) {
          // 退回「让用户自己按 Ctrl/Cmd+C」：把一个可展开的 pre 放在眼前，比一句
          // 「复制失败」有用——文本已经拿到了，差的只是一次系统级操作。
          setOk(t('msg.copyUnavailable', { error: err.message }))
        }
      }

      const mcpText = React.useMemo(() => {
        if (!mcp) return t('status.mcpUnknown')
        // 所有模式都带上宿主给的 note：未索引 / 手工行 / 联动关闭这些「没有托管」的
        // 情况必须说出来，否则「已对齐 cwd」看起来像一切正常。
        // 宿主给的 note 是**宿主侧正文**（不经 ctx.locale），原样透出。
        const note = mcp.note ? ' · ' + mcp.note : ''
        const following = defaultInfo && defaultInfo.followSession && defaultInfo.sessionPath && defaultInfo.sessionPath !== defaultInfo.defaultPath
          ? t('status.followingSession', { path: defaultInfo.sessionPath })
          : ''
        // CG12：项目被删 / uninit 后坏行会一直留在 cordis.patch.yml 里（没有 fs.watch），
        // 卡片至少要把「cwd 目录已经不在了」说出来。
        const deadCwd = mcp.cwdExists === false ? t('status.deadCwd') : ''
        // 可选片段一律走占位符：中英的语序与标点不同，拼接会把语序写死。
        const suffix = {
          disabled: mcp.disabled ? t('status.mcpDisabled') : '',
          deadCwd,
          following,
          note,
        }
        const cwd = mcp.cwd || t('status.mcpCwdUnset')
        if (mcp.mode === 'own') return t('status.mcpOwn', { cwd, ...suffix })
        if (mcp.mode === 'dsh-mcp') return t('status.mcpAligned', { cwd, ...suffix })
        if (mcp.mode === 'external') return t('status.mcpExternal')
        return t('status.mcpUntracked', { note: mcp.note || t('status.mcpUnmanaged') })
      }, [mcp, defaultInfo])

      // 托管行实际用的目录不是有效索引时必须点名：MCP 服务器以它为 cwd，未加载项目时
      // codegraph_* 工具会要求显式传 projectPath（家目录最常见——~/.codegraph 是
      // codegraph CLI 自己的安装目录，插件不认它之后这里就会报警）。
      const defaultWarning = React.useMemo(() => {
        if (!defaultInfo || defaultInfo.indexed) return ''
        const why = defaultInfo.indexState === 'not-a-project'
          ? t('status.notAProjectWhy')
          : t('status.noIndexWhy')
        const shown = defaultInfo.effectivePath || defaultInfo.defaultPath || t('status.mcpCwdUnset')
        const source = defaultInfo.followSession && defaultInfo.sessionPath === shown
          ? t('status.fromSession')
          : t('status.fromDefault')
        const fix = status && status.initialized === true && effectivePath && effectivePath !== shown
          ? t('status.fixCurrent', { path: effectivePath })
          // 注意这里谈的是**托管行用的那个目录**（shown），它未必等于下面你正在看的路径；
          // 所以只给不依赖「当前路径」的说法，别让人以为点卡片上的按钮就能修它。
          : t('status.fixOther')
        return t('status.defaultWarning', { shown, source, why, fix })
      }, [defaultInfo, status, effectivePath])

      // 修法建议按失败原因分流（CG65）：「命令不存在」才谈 PATH / 绝对路径；「超时」
      // 是机器忙——改 command 路径救不了它，指引应是等空闲重探。判定只认运行器写入
      // 报错原文的 `(timeout after …)` 字样，平台无关、不依赖 i18n。
      const cliProbeTimedOut = defaultInfo != null
        && typeof defaultInfo.cliProbeError === 'string'
        && defaultInfo.cliProbeError.includes('timeout after')
      const cliWarning = defaultInfo && defaultInfo.cliAvailable === false
        ? t('status.cliMissing', { command: defaultInfo.command || 'codegraph' })
          + (cliProbeTimedOut ? t('status.cliTimeoutHint') : t('status.cliFix') + t('status.cliNote'))
        : ''

      /** 某个页签有没有内容（决定它是否出现在页签栏里）。 */
      const hasResultTab = (key) => (key === 'search'
        ? results.length > 0
        : key === 'detail'
          ? selected !== null
          : outputs[key] !== undefined)

      /**
       * 结果区可见的页签 = **有内容的那些** + 当前活动那个。
       *
       * 为什么把 activeTab 也算进来：查询返回空结果时该页签没有内容，但用户刚点了
       * 它——这时候页签栏不能整个消失（否则「点了没反应」），要让他看到
       * 「没有匹配的符号」这种明确的空态。
       */
      const resultTabs = RESULT_TABS.filter((tab) => hasResultTab(tab.key) || tab.key === activeTab)

      /**
       * 忙碌指示器文案。`loading` 的文案由各动作经 beginBusy 给出；「重新探测」与
       * 「收集诊断包」有自己的忙态布尔（CG21：两个动作各有忙态，共用一个会把对方
       * 一起禁掉），文案在这里补上，好让标题行统一显示「在做什么」。
       */
      const busyText = loading
        ? (busy || t('msg.working'))
        : reprobing
          ? t('msg.reprobing')
          : diagnosing
            ? t('msg.collectingDiagnostics')
            : ''

      /** 探测失败的实测原文：ENOENT / 非零退出 / 超时三种情况靠它区分。 */
      const cliProbeDetail = defaultInfo && defaultInfo.cliAvailable === false && defaultInfo.cliProbeError
        ? t('status.probeReason', { error: defaultInfo.cliProbeError })
          + (defaultInfo.cliProbeAt ? t('status.probeAt', { time: new Date(defaultInfo.cliProbeAt).toLocaleTimeString() }) : '')
        : ''

      // 状态区：能识别的 status 形状就铺成网格，否则回落到原始文本（CLI 报错时 status 可能是 {raw}）
      const statusIsStructured = status !== null && typeof status === 'object' && typeof status.initialized === 'boolean'
      const statusRawText = status
        ? JSON.stringify(status, null, 2)
        : ''

      /** callers / callees / impact 取列表（形状随 CLI 版本可能稍有差异，取不到就当空）。 */
      const relItems = (value, key) => {
        const list = value && value[key]
        return Array.isArray(list) ? list : []
      }

      if (view === 'summary') {
        return t('card.summary')
      }

      // page 视图：新页面自己画标题/图标/面包屑，这里只交表单本体，不渲染卡片头。
      return jsxs(pageView ? 'div' : 'li', {
        className: pageView ? 'cg_pageHost' : (open ? 'cg_pluginCard cg_pluginCardOpen' : 'cg_pluginCard'),
        children: [
          pageView ? null : jsxs('button', {
            type: 'button',
            className: 'cg_cardHeader',
            'aria-expanded': open,
            onClick: () => setOpen((current) => !current),
            children: [
              jsxs('span', {
                className: 'cg_cardHeadText',
                children: [
                  jsx('span', { className: 'cg_cardName', children: 'Codegraph' }),
                  jsx('span', { className: 'cg_cardDescription', children: t('card.desc') }),
                ],
              }),
              jsx('span', { className: 'dshkit_badge', children: 'Kit' }),
              jsx('svg', {
                width: '14',
                height: '14',
                viewBox: '0 0 14 14',
                fill: 'none',
                xmlns: 'http://www.w3.org/2000/svg',
                className: 'cg_chevron',
                children: jsx('path', { d: CHEVRON_PATH, fill: 'currentColor' }),
              }),
            ],
          }),
          (pageView || open) ? jsx('div', {
            className: 'cg_cardBody',
            children: jsxs('div', {
              className: 'cg_panel',
              children: [
                // 面板标题行：标题 + 忙碌指示器（+ 取消）。这是**全局**指示器。
                //
                // 分工（两级反馈都要有）：
                //   - **按钮自己**（busyOr）负责「点哪看得见哪」——卡片很长，滚到下半部分
                //     时标题行已移出视野，那时点「搜索 / 影响面」只有按钮上的反馈看得见；
                //   - **这里**负责「滚到顶时一眼看到在忙什么」，以及承载「取消」。
                //
                // 这里也替代了原先正文中间那句**居中大块**的「加载中…」（padding:24px 12px）：
                // 它既不说在加载什么、又把下面整组控件上下推（布局跳动，用户截图实证）。
                jsxs('div', {
                  className: 'cg_panelHeader',
                  children: [
                    jsx('span', { className: 'cg_panelTitle', children: t('panel.title') }),
                    busyText !== ''
                      ? jsxs('span', {
                        className: 'cg_busy',
                        // 屏幕阅读器：进度文案变化时播报（视觉上转圈，非视觉上靠这句）
                        'aria-live': 'polite',
                        children: [
                          jsx('span', { className: 'cg_spinner' }),
                          jsx('span', { children: busyText }),
                          // 「取消」紧挨着它要停的那件事。原先它在危险行里，与进度提示
                          // 之间隔着用量统计——真要取消时找不到。
                          cancelable && loading
                            ? jsx('button', {
                              type: 'button',
                              className: 'cg_btnGhost',
                              title: t('panel.cancelTitle'),
                              onClick: cancelRun,
                              children: t('btn.cancel'),
                            })
                            : null,
                        ],
                      })
                      : null,
                  ],
                }),
                // ── 目标项目 ──「在看哪个目录 / 设默认 / 托管行状态 / 见过哪些项目」
                // 收进同一组。此前路径输入框在面板第二行、「设为默认项目」孤悬在查询
                // 参数之后（截图实证：按钮和它作用的路径隔了两屏），托管行文案又挂在
                // 按钮后面——三件事散在三处，现在自上而下是一条「我在看哪个项目」的动线。
                group(t('panel.groupTarget'), [
                  jsxs('div', {
                    className: 'cg_row',
                    children: [
                      jsx('input', {
                        className: 'cg_input',
                        placeholder: t('placeholder.projectPath'),
                        value: path,
                        onChange: (event) => {
                          const value = event.target.value
                          setManual(value !== '')
                          setPath(value)
                        },
                      }),
                      jsx('button', {
                        type: 'button',
                        className: 'cg_btnGhost',
                        disabled: settingDefault || loading || !effectivePath,
                        title: t('panel.setDefaultTitle'),
                        onClick: setDefaultProject,
                        children: settingDefault ? t('msg.switching') : t('btn.setDefault'),
                      }),
                    ],
                  }),
                  jsx('span', { className: 'cg_mcpMeta', children: mcpText }),
                  // P2 项目列表：一台 MCP 服务器同一时刻只挂一个项目，所以「换项目」是
                  // 高频动作；以前只能手敲绝对路径。只列「用户真在这里工作过」的目录
                  // （活跃会话 / 跟随上报 / 查过状态），不做全盘扫描。
                  // 未索引的也列出来并标灰——用户会想知道「这个项目还没索引」，但它不能
                  // 作为切换目标（切换要求有效索引），所以按钮禁用而不是隐藏。
                  projects.length > 0
                    ? jsxs('div', {
                      className: 'cg_projects',
                      children: [
                        jsx('span', { className: 'cg_projectsLabel', children: t('panel.seenProjects') }),
                        ...projects.map((item) => jsx('button', {
                          type: 'button',
                          key: 'cg-project-' + item.path,
                          className: 'cg_projectBtn',
                          disabled: settingDefault || !item.indexed || item.path === effectivePath,
                          title: item.indexed
                            ? t('status.projectSeen', { path: item.path, ago: seenAgoText(item.seenAgoMs, t), via: item.via })
                            : t('status.projectNotIndexed', { path: item.path, via: item.via }),
                          onClick: () => switchProject(item.path),
                          children: shortPath(item.path) + (item.indexed ? '' : t('badge.notIndexed')),
                        })),
                      ],
                    })
                    : null,
                ]),
                // ── 索引状态（UX 重构：状态先于操作）── 原先这组在面板最底部：打开卡片要
                // 先越过两行输入框和 9 个按钮才知道「这个目录索引健不健康」。卡片回答的
                // 第一个问题应该是「现在状态如何」，所以它紧跟目标项目；紧接着的索引维护
                // 组就是「看到问题 → 修复它」的那一排按钮（过期警告与「重建索引」上下相邻）。
                // ── 问题（UX：只放**会让下面全部失效**的警告，且必须在最前面）──
                //
                // 这两条原先在「Agent 集成」里——那是卡片的**最后一个分区**，要滚到底才看得见。
                // 但它们的严重性是「什么都干不了」：
                //   - CLI 探测不到 → systemPrompt 不注入，状态 / 搜索 / sync / 重建索引**全部报错**；
                //   - 托管行指向的目录不是有效索引 → MCP 工具拿到的是错的/没有的项目上下文。
                // 有问题的东西必须排在数据与操作之前，否则用户会先看到一张「看着正常」的卡片，
                // 点下去才发现全失败。健康时这一块**完全不渲染**，不占位。
                (cliWarning || defaultWarning)
                  ? jsxs('div', {
                    className: 'cg_alerts',
                    children: [
                      cliWarning ? jsx('p', { className: 'cg_warn', children: cliWarning }) : null,
                      cliProbeDetail ? jsx('p', { className: 'cg_probeDetail', children: cliProbeDetail }) : null,
                      defaultWarning ? jsx('p', { className: 'cg_warn', children: defaultWarning }) : null,
                    ],
                  })
                  : null,
                // 本组**无条件渲染**（即使还没拿到数据）：「刷新」按钮挂在这个组的组头，
                // 若整组随 status 一起消失，读取失败时用户就没有就地重试的入口了。
                group(t('panel.groupStatus'), status === null
                  ? [jsx('p', { className: 'cg_mcpMeta', children: t('list.statusEmpty') })]
                  : statusIsStructured
                    ? [
                        jsx('div', { className: 'cg_grid', children: statusCells(status) }),
                        // CG11：CLI 明说「建议重建」时不能只报「● 已索引」——MCP 这时给的是旧图。
                        // 实测补一句「Sync 修不了它」：codegraph 1.6.0 的 `sync` 对「提取器版本
                        // 落后」这类过期返回 Already up to date 且不清除信号，只有「重建索引」能修。
                        // 以前文案只说「点重建索引可修复」，用户很可能先点 Sync 然后发现没用。
                        staleReasons(status, t).length > 0
                          ? jsx('p', {
                            className: 'cg_warn',
                            children: t('status.staleWarning', { reasons: staleReasons(status, t).join(t('list.separator')) }),
                          })
                          : null,
                        status.initialized === false
                          ? jsx('p', { className: 'cg_mcpMeta', children: t('list.noIndexHint') })
                          : null,
                        statusRawText !== ''
                          ? jsxs('details', {
                            className: 'cg_details',
                            children: [
                              jsx('summary', { children: t('panel.rawStatusJson') }),
                              jsx('pre', { className: 'cg_pre', children: statusRawText }),
                            ],
                          })
                          : null,
                      ]
                    : [jsx('pre', { className: 'cg_pre', children: statusRawText })], jsx('button', {
                  type: 'button',
                  className: 'cg_iconBtn',
                  disabled: loading,
                  // 只有**本动作**在跑时才转（busyAction），不是任何动作都转
                  'data-busy': busyAction === 'status' ? '1' : undefined,
                  'aria-label': busyAction === 'status' ? t('panel.refreshingAria') : t('panel.refreshAria'),
                  title: busyAction === 'status'
                    ? t('panel.refreshingTitle')
                    : t('panel.refreshTitle'),
                  onClick: loadStatus,
                  children: jsx('svg', {
                    width: '14',
                    height: '14',
                    viewBox: '0 0 24 24',
                    fill: 'none',
                    xmlns: 'http://www.w3.org/2000/svg',
                    'aria-hidden': 'true',
                    children: jsx('path', { d: REFRESH_PATH, fill: 'currentColor' }),
                  }),
                })),
                // ── 索引维护（UX 重构：贴着索引状态，按钮分三层）──
                // 原先把 9 个按钮无层级地铺在一行里：每天点的 Sync、排障用的诊断包、罕见的
                // 解锁、破坏性的撤销索引完全同样式混排（用户看到的「乱」主要在这里）。
                // 现在按「动作性质」分三行并给 Sync 主按钮样式：
                //   生命周期（会写索引）→ 查看与诊断（只读）→ 危险（删数据，视觉隔开）。
                group(t('panel.groupMaintenance'), [
                  // 生命周期：改索引的动作。Sync 是这张卡片最高频的安全操作，给主按钮样式
                  // 做视觉锚点；「初始化索引」在未索引时是唯一主操作，排在最前（判定见下）。
                  jsx('div', { className: 'cg_rowLabel', children: t('panel.rowLifecycle') }),
                  // 按钮要包一层 .cg_toolbarBtns 行容器：group 本体是纵向 flex（分组头 +
                  // 内容自上而下），按钮直接塞进去会被拉成一条条通栏；包一行容器才能
                  // 左对齐横向排布、放不下再折行。
                  jsxs('div', {
                    className: 'cg_toolbarBtns',
                    children: [
                      // 只有「用户正看着的这个目录还不是有效索引」时才出现。放在最前面：
                      // 那种情况下它就是这张卡片的主操作。
                      //
                      // 判定必须用 `status.initialized === false`（= /status?path=<本卡片路径>），
                      // **不能**用 `defaultInfo.indexed`：那个来自 /default-path，走的是后端的
                      // effectiveProjectPath——「跟随当前项目」开着、而会话目录未索引时，它会回落到
                      // **默认项目**，于是回一个 `indexed: true`（默认项目往往正是某个已索引的仓库），
                      // 按钮就永远不出现。两个口径在这个场景下必然分叉，这里跟底部那句文案
                      // （同一个条件）保持一致。
                      status && status.initialized === false
                        ? jsx('button', {
                          type: 'button',
                          className: confirmInit ? 'cg_btnDanger' : 'cg_btnGhost',
                          disabled: loading,
                          title: confirmInit
                            ? t('panel.confirmInitTitle', { path: effectivePath || t('panel.defaultProject') })
                            : t('panel.initTitle'),
                          onClick: runInit,
                          children: busyOr('init', confirmInit ? t('btn.confirmInit') : t('btn.initIndex'), t('msg.initializing')),
                        })
                        : null,
                      jsx('button', {
                        type: 'button',
                        className: 'cg_btn',
                        disabled: loading,
                        title: t('panel.syncTitle'),
                        onClick: () => runAction('sync'),
                        children: busyOr('sync', 'Sync', t('msg.syncing')),
                      }),
                      jsx('button', {
                        type: 'button',
                        className: 'cg_btnGhost',
                        disabled: loading,
                        onClick: () => runAction('index'),
                        children: busyOr('index', t('btn.reindex'), t('msg.rebuilding')),
                      }),
                      // 清陈旧锁：一次被强杀的 index 留下的 codegraph.lock 会挡住后续
                      // **所有**索引操作，而在此之前卡片没有任何入口（只能去终端）。
                      // CLI 侧幂等（没锁时 exit 0），所以不需要二次确认。
                      jsx('button', {
                        type: 'button',
                        className: 'cg_btnGhost',
                        disabled: loading,
                        title: t('panel.unlockTitle'),
                        onClick: () => runAction('unlock'),
                        children: busyOr('unlock', t('btn.unlock'), t('msg.unlocking')),
                      }),
                      // 撤销索引（唯一的删除类动作）接在生命周期行尾，用**竖向虚线**与
                      // 常规按钮隔开。
                      //
                      // 为什么不再单独占一行：上一版把它放进独立的 .cg_dangerRow，结果是
                      // 「一个按钮 + 上方虚线 + 右侧大片空白」——用户直接问「为什么单独换行」，
                      // 看起来像换行 bug 而不是有意的安全标记。而它**本来就是生命周期动作**
                      // （写索引，与 Sync/重建/解锁同一档），不该另起一档。
                      //
                      // 安全上真正的防线是**两步确认**（第一次点击只进入红色确认态，
                      // 单次误点删不掉任何东西）；视觉分隔只提供边际收益，不值得一整行。
                      status && status.initialized === true
                        ? jsx('span', {
                          className: 'cg_dangerSlot',
                          children: jsx('button', {
                            type: 'button',
                            className: confirmUninit ? 'cg_btnDanger' : 'cg_btnGhost',
                            disabled: loading,
                            title: confirmUninit
                              ? t('panel.confirmUninitTitle', { path: effectivePath || t('panel.defaultProject') })
                              : t('panel.uninitTitle'),
                            onClick: runUninit,
                            children: busyOr('uninit', confirmUninit ? t('btn.confirmUninit') : t('btn.uninit'), t('msg.removingIndex')),
                          }),
                        })
                        : null,
                    ],
                  }),
                  // 查看与诊断：只读动作（刷新卡片数据 / 重新探测 CLI / 看文件结构 / 收诊断包）。
                  // 与「会写索引」的按钮分开，扫一眼就知道这排不会改任何东西。
                  jsx('div', { className: 'cg_rowLabel', children: t('panel.rowDiagnostics') }),
                  jsxs('div', {
                    className: 'cg_toolbarBtns',
                    children: [
                      jsx('button', {
                        type: 'button',
                        className: 'cg_btnGhost',
                        disabled: reprobing,
                        title: t('panel.reprobeTitle'),
                        onClick: reprobe,
                        children: reprobing ? t('msg.probing') : t('btn.reprobe'),
                      }),
                      // 一键诊断包（P1-b）：把 PATH / 托管行 / 索引 / daemon / 最近失败
                      // 的原文一次收齐，供排障与贴 issue。它是**只读**动作，排在危险动作之前；
                      // 此前排在「撤销索引」之后、紧邻「取消」，语义上是错位的。
                      jsx('button', {
                        type: 'button',
                        className: 'cg_btnGhost',
                        disabled: diagnosing,
                        title: t('panel.diagnoseTitle'),
                        onClick: loadReport,
                        children: diagnosing ? t('msg.collecting') : t('btn.diagnose'),
                      }),
                    ],
                  }),
                ]),
                // 动作反馈（出错 / 成功 / 诊断包）：紧跟索引维护组——大部分按钮在这里，
                // 反馈落在按键下方最近的位置；来自搜索的报错也汇到同一条反馈区。
                //
                // 包一层 .cg_feedback 是为了**收紧内部间距**（面板统一 12px，这几条之间用
                // 6px）：它们读起来才是一个整体（「刚才那次操作的结果」），而不是几条互不
                // 相干的段落。
                error || ok || report !== ''
                  ? jsxs('div', {
                    className: 'cg_feedback',
                    children: [
                      error ? jsx('p', { className: 'cg_error', children: error }) : null,
                      ok ? jsx('p', { className: 'cg_ok', children: ok }) : null,
                      // 诊断包（P1-b）：**默认折叠** + 复制按钮。它很长（补丁区块 + daemon
                      // 日志尾，上限 260px），自动展开会把下方的「搜索与查询 / 结果区」整块
                      // 推远——用户反馈的「文件与结果太割裂」里，这一块正是中间那道墙。
                      // 摘要行本身（含「复制」）出现就是「已生成」的反馈，要看内容点一下即可。
                      report !== ''
                        ? jsxs('details', {
                          className: 'cg_details',
                          children: [
                            jsxs('summary', {
                              children: [
                                t('panel.reportSummary'),
                                jsx('button', {
                                  type: 'button',
                                  className: 'cg_btnGhost',
                                  style: { marginLeft: '8px' },
                                  onClick: (event) => {
                                    // details 的 summary 上放按钮：不拦住冒泡的话点「复制」
                                    // 会顺带把这块折叠起来
                                    event.preventDefault()
                                    event.stopPropagation()
                                    copyReport()
                                  },
                                  children: t('btn.copy'),
                                }),
                              ],
                            }),
                            jsx('pre', { className: 'cg_pre', children: report }),
                          ],
                        })
                        : null,
                    ],
                  })
                  : null,
                // 遥测脚注：放在**反馈之后**。它原先在「索引维护」组的末尾，于是正好插在
                // 「重新探测 / 诊断包」两个按钮与它们自己的结果之间——读起来是
                // 「按钮 → 一段无关的说明 → 按钮的结果」（用户截图里的乱）。脚注属于
                // 「背景说明」，就该排在结果之后。
                //
                // P2 遥测提示：`init` / `index` 会触发上游的匿名用量统计。只如实转达 CLI 的
                // 状态并指出关闭方式，**不给开关**——那是用户的全局偏好，存在
                // ~/.codegraph/telemetry.json，插件替他翻等于越权改别人的全局设置。
                telemetry !== null
                  ? jsx('p', {
                    className: 'cg_mcpMeta',
                    children: telemetry.enabled === true
                      ? t('panel.telemetryOn')
                      : telemetry.enabled === false
                        ? t('panel.telemetryOff')
                        : t('panel.telemetryUnknown'),
                  })
                  : null,
                // ── 搜索与查询（UX 重构：拆两个工作流）──
                // 「搜索 / 探索 / 上下文」是符号查询（吃同一个关键词），「改动文件 + 影响面」
                // 是「改动 → 受影响测试」的另一个工作流——原先两者混在一行参数里，
                // 看起来像一回事。现在符号查询在上、「改动影响」单列一行小标题。
                group(t('panel.groupSearch'), [
                  jsx('div', {
                    className: 'cg_row',
                    children: [
                      jsx('input', {
                        className: 'cg_input',
                        placeholder: t('placeholder.searchSymbol'),
                        value: query,
                        onChange: (event) => setQuery(event.target.value),
                        onKeyDown: (event) => { if (event.key === 'Enter') search() },
                      }),
                      jsx('button', {
                        type: 'button',
                        className: 'cg_btn',
                        disabled: loading || !query.trim(),
                        onClick: search,
                        children: busyOr('search', t('btn.search'), t('msg.searching')),
                      }),
                      // explore / context 与「搜索」共用 query，语义上是一组（见上）。
                      jsx('button', {
                        type: 'button',
                        className: 'cg_btnGhost',
                        disabled: loading || !query.trim(),
                        title: t('panel.exploreTitle'),
                        onClick: () => runQuery('explore', { q: query.trim() }),
                        children: busyOr('explore', t('btn.explore'), t('msg.exploring')),
                      }),
                      jsx('button', {
                        type: 'button',
                        className: 'cg_btnGhost',
                        disabled: loading || !query.trim(),
                        title: t('panel.contextTitle'),
                        onClick: () => runQuery('context', { q: query.trim() }),
                        children: busyOr('context', t('btn.context'), t('msg.assembling')),
                      }),
                      // kind / limit 是 query 的 -k/-l：贴着它们作用的搜索，不另起一行。
                      jsx('label', {
                        className: 'cg_opt',
                        title: t('panel.kindTitle'),
                        children: [
                          t('field.kind'),
                          jsx('input', {
                            className: 'cg_input cg_inputSm',
                            placeholder: t('placeholder.kindAny'),
                            value: queryKind,
                            onChange: (event) => setQueryKind(event.target.value),
                            onKeyDown: (event) => { if (event.key === 'Enter') search() },
                          }),
                        ],
                      }),
                      jsx('label', {
                        className: 'cg_opt',
                        title: t('panel.limitTitle'),
                        children: [
                          t('field.limit'),
                          jsx('input', {
                            className: 'cg_input cg_inputXs',
                            value: queryLimit,
                            onChange: (event) => setQueryLimit(event.target.value),
                            onKeyDown: (event) => { if (event.key === 'Enter') search() },
                          }),
                        ],
                      }),
                    ],
                  }),
                  // 三个查询按钮的说明行。
                  //
                  // 为什么需要：它们的信息原先只在 `title` 悬停提示里——用户直接问
                  // 「这两个按钮做啥的」。搜索/探索/上下文都是「拿同一个关键词查」，但**产物
                  // 不同**，光看标签分不出来（标签保持 CLI 子命令的对应关系，所以不改名）。
                  jsx('p', {
                    className: 'cg_mcpMeta',
                    children: t('hint.queryButtons'),
                  }),
                  // 其他查询：**不用搜索框关键词**的几种查询。与上面那行分开是因为它们的
                  // 心智不同（上面是「拿关键词查符号」），混在一起会让人以为「文件」也吃关键词。
                  //
                  // 「文件」原先在「查看与诊断」里，与它的结果分居两处——用户直接问
                  // 「上面的文件和下面的搜索是一个东西吗，现在太割裂了」。按钮和它产生的
                  // 结果必须挨着：结果区（页签）就在本组下方，所以它属于这一组。
                  //
                  // 「改动文件 / 影响面」：插件刻意不自己去猜改动列表（不读 git status、
                  // 不猜编辑器状态），所以需要用户手填；「影响面」吃左边这份列表，
                  // 依赖关系贴着输入框一眼可见。窄栏下自动折行。
                  jsx('div', { className: 'cg_rowLabel', children: t('panel.rowOtherQueries') }),
                  jsxs('div', {
                    className: 'cg_queryOpts',
                    children: [
                      jsx('button', {
                        type: 'button',
                        className: 'cg_btnGhost',
                        disabled: loading,
                        title: t('panel.filesTitle'),
                        onClick: () => runQuery('files'),
                        children: busyOr('files', t('btn.files'), t('msg.reading')),
                      }),
                      jsx('label', {
                        className: 'cg_opt cg_optWide',
                        title: t('panel.affectedTitle'),
                        children: [
                          t('field.changedFiles'),
                          jsx('input', {
                            className: 'cg_input cg_inputSm',
                            placeholder: t('placeholder.changedFiles'),
                            value: changedFiles,
                            onChange: (event) => setChangedFiles(event.target.value),
                            onKeyDown: (event) => { if (event.key === 'Enter') runQuery('affected', { files: manualFiles() }) },
                          }),
                        ],
                      }),
                      jsx('button', {
                        type: 'button',
                        className: 'cg_btnGhost',
                        disabled: loading || !(status && status.projectPath),
                        title: t('panel.affectedButtonTitle'),
                        onClick: () => runQuery('affected', { files: manualFiles() }),
                        children: busyOr('affected', t('btn.affected'), t('msg.analyzing')),
                      }),
                    ],
                  }),
                ]),
                // ── 结果（UX 重构：页签 + 上移）──
                // 用户反馈：「点击文件看不到对应的列表」。根因是结果区原先在面板**最底部**
                // （Agent 集成之后），而触发它的按钮在「索引维护 / 搜索与查询」——点完要往下
                // 翻两屏，中间还可能横着一个展开的诊断包。
                //
                // 三处改动一起解决「看不到」：
                //   ① 结果区上移到「搜索与查询」正下方（离触发按钮最近的位置）；
                //   ② 各类结果做成**页签**，点哪个按钮就切到哪一页——位置固定，不用找；
                //   ③ outputs 按路由分槽，切页签不会丢上一次的结果。
                // 另有 useEffect 在结果出来且不在视野时滚过去（block:'nearest'，已在视野就不动）。
                resultTabs.length > 0
                  ? group(t('panel.groupResults'), [
                      jsxs('div', {
                        className: 'cg_tabs',
                        children: resultTabs.map((tab) => jsx('button', {
                          type: 'button',
                          key: 'cg-tab-' + tab.key,
                          className: tab.key === activeTab ? 'cg_tab cg_tabOn' : 'cg_tab',
                          'aria-selected': tab.key === activeTab,
                          onClick: () => setActiveTab(tab.key),
                          children: tab.label,
                        })),
                      }),
                      jsx('div', {
                        className: 'cg_tabPanel',
                        ref: resultRef,
                        children: activeTab === 'search'
                          // 搜索结果：点一行下钻到符号详情（同时切到「符号详情」页签）
                          ? (results.length > 0
                            ? jsx('div', {
                              className: 'cg_list',
                              children: results.map((item, index) => {
                                const node = item && item.node ? item.node : item
                                return jsxs('div', {
                                  className: 'cg_item',
                                  key: 'cg-result-' + index,
                                  onClick: () => loadSymbol(node.qualifiedName || node.name),
                                  children: [
                                    jsx('div', { className: 'cg_itemName', children: node.qualifiedName || node.name || '(unnamed)' }),
                                    jsx('div', { className: 'cg_itemMeta', children: (node.kind || '') + ' · ' + (node.filePath || '') + ':' + (node.startLine || '') }),
                                  ],
                                })
                              }),
                            })
                            : jsx('p', { className: 'cg_mcpMeta', children: t('list.noSymbols') }))
                          : activeTab === 'detail'
                            ? (detail
                              ? jsxs('div', {
                                children: [
                                  jsx('p', { className: 'cg_sectionTitle', children: t('panel.symbolDetail', { name: selected }) }),
                                  // node 侧返回的是带行号的 markdown 源码/调用轨迹（不是 JSON），直接按文本显示
                                  typeof detail.node?.node === 'string' && detail.node.node.trim() !== ''
                                    ? jsx('pre', { className: 'cg_pre', children: detail.node.node })
                                    : null,
                                  relList(t('panel.callers'), relItems(detail.callers?.callers, 'callers'), t('list.noCallers')),
                                  relList(t('panel.callees'), relItems(detail.callees?.callees, 'callees'), t('list.noCallees')),
                                  jsxs('div', {
                                    children: [
                                      jsx('p', {
                                        className: 'cg_sectionTitle',
                                        children: t('panel.impactTitle', { nodes: fmtNum(detail.impact?.impact?.nodeCount), edges: fmtNum(detail.impact?.impact?.edgeCount) }),
                                      }),
                                      relList(t('panel.affectedSymbols'), relItems(detail.impact?.impact?.affected, 'affected'), t('list.noAffected')),
                                    ],
                                  }),
                                  jsxs('details', {
                                    className: 'cg_details',
                                    children: [
                                      jsx('summary', { children: t('panel.rawDetailJson') }),
                                      jsx('pre', { className: 'cg_pre', children: JSON.stringify(detail, null, 2) }),
                                    ],
                                  }),
                                ],
                              })
                              : jsx('p', { className: 'cg_mcpMeta', children: t('list.loadingSymbol') }))
                            : (outputs[activeTab] !== undefined
                              ? renderOutputBody(outputs[activeTab])
                              : jsx('p', { className: 'cg_mcpMeta', children: t('list.noResult') })),
                      }),
                    ])
                  : null,
                // ── Agent 集成 ── 提示词注入与 MCP 挂载的开关、相关警告收进一组。
                // UX 重构：四个开关拆两行——「跟随与提示词」是轻量行为开关，
                // 「per-agent MCP 隔离」是改 MCP 拓扑、有内存代价的决策，视觉同权正是
                // 「乱」的来源之一。各自一行小标题，代价与后果各归各位。
                group(t('panel.groupAgent'), [
                  // UX 重构：四个开关拆两行——「跟随与提示词」是轻量行为开关，
                  // 「per-agent MCP 隔离」是改 MCP 拓扑、有内存代价的决策，两者视觉同权
                  // 正是「乱」的来源之一。各自一行小标题，代价与后果各归各位。
                  jsx('div', { className: 'cg_rowLabel', children: t('panel.rowFollow') }),
                  jsxs('div', {
                    className: 'cg_checks',
                    children: [
                      jsx('label', {
                        className: 'cg_check',
                        title: t('panel.followTitle'),
                        children: [
                          jsx('input', {
                            type: 'checkbox',
                            checked: defaultInfo ? defaultInfo.followSession === true : false,
                            disabled: !defaultInfo,
                            onChange: (event) => toggleSetting('followSession', event.target.checked),
                          }),
                          t('check.followSession'),
                        ],
                      }),
                      jsx('label', {
                        className: 'cg_check',
                        'data-off': !defaultInfo || defaultInfo.cliAvailable !== true ? '1' : undefined,
                        title: defaultInfo && defaultInfo.cliAvailable === true
                          ? t('panel.announceTitle')
                          : t('panel.announceDisabled'),
                        children: [
                          jsx('input', {
                            type: 'checkbox',
                            checked: defaultInfo ? defaultInfo.announceToAgent === true : false,
                            disabled: !defaultInfo || defaultInfo.cliAvailable !== true,
                            onChange: (event) => toggleSetting('announceToAgent', event.target.checked),
                          }),
                          t('check.announce'),
                        ],
                      }),
                      jsx('label', {
                        className: 'cg_check',
                        'data-off': !defaultInfo || defaultInfo.cliAvailable !== true ? '1' : undefined,
                        title: defaultInfo && defaultInfo.cliAvailable === true
                          ? t('panel.guidanceTitle')
                          : t('panel.guidanceDisabled'),
                        children: [
                          jsx('input', {
                            type: 'checkbox',
                            checked: defaultInfo ? defaultInfo.usageGuidance === true : false,
                            disabled: !defaultInfo || defaultInfo.cliAvailable !== true,
                            onChange: (event) => toggleSetting('usageGuidance', event.target.checked),
                          }),
                          t('check.guidance'),
                        ],
                      }),
                    ],
                  }),
                  jsx('div', { className: 'cg_rowLabel', children: t('panel.rowMcp') }),
                  jsx('div', {
                    className: 'cg_checks',
                    children:
                      // P0：MCP 挂载模式。默认 managed（保持原行为），per-agent 是显式选择。
                      // 用户选了 per-agent 但前提不成立时，宿主会退回 managed 并给出原因——
                      // 卡片必须显示「已退回」，否则用户以为开了、实际没开。
                      // 与旧版一致，整个 label 仍以 defaultInfo 为前提（它直接读
                      // defaultInfo.mcpScope；探测结果没回来时无从渲染，preview-card 的
                      // null 探测用例盯的就是这条）。
                      defaultInfo
                        ? jsx('label', {
                          className: 'cg_check',
                          // 不给「未开启」挂 data-off 灰显：勾选框本身已经表达了
                          // 「没勾 = 关」，再叠 55% 透明度会被读成**禁用**（用户实测
                          // 截图：看起来点不了，实际能点）。它只在状态未加载时禁用
                          // （下面的 disabled）。data-off 语义保留给真正不可用的开关
                          // ——CLI 探测失败的那两个（灰 = 确实注不了入）。
                          title: t('panel.perAgentTitle'),
                          children: [
                            jsx('input', {
                              type: 'checkbox',
                              checked: defaultInfo.mcpScope === 'per-agent',
                              disabled: !defaultInfo,
                              onChange: (event) => toggleSetting('mcpScope', event.target.checked ? 'per-agent' : 'managed'),
                            }),
                            t('check.perAgent'),
                          ],
                        })
                        : null,
                  }),
                  // 退回提示：只在「用户要 per-agent、实际不是」时出现。
                  defaultInfo && defaultInfo.mcpScope === 'per-agent' && defaultInfo.effectiveMcpScope !== 'per-agent'
                    ? jsx('p', {
                      className: 'cg_warn',
                      children: t('panel.perAgentFallback', {
                        reason: defaultInfo.mcpScopeReason || t('panel.perAgentReason'),
                        tail: t('panel.perAgentTail'),
                      }),
                    })
                    : null,
                  defaultInfo && defaultInfo.effectiveMcpScope === 'per-agent'
                    ? jsx('p', {
                      className: 'cg_mcpMeta',
                      title: t('panel.perAgentActiveTitle'),
                      children: t('panel.perAgentActive', { count: String(defaultInfo.agentMounts) }),
                    })
                    : null,
                  // P1 采纳率：模型到底用不用 codegraph。放在开关下面——它是「配置对不对」
                  // 之后的第二个问题（「配好了，模型买账吗」）。
                  adoptionText(adoption, t) !== ''
                    ? jsx('p', {
                      className: 'cg_subtitle',
                      title: t('panel.adoptionTitle'),
                      children: adoptionText(adoption, t),
                    })
                    : null,
                ]),
              ],
            }),
          }) : null,
        ],
      })
    }

    /* ============================ 活动会话上报 ============================ */

    /**
     * 把当前活动会话的工作目录报给宿主，让宿主把 MCP 托管行的 cwd 对齐过去。
     *
     * 为什么放在 apply 而不是卡片里：卡片只在设置面板展开时挂载，而「跟着当前项目走」
     * 必须在这之前就成立。客户端半体在页面加载时就跑 apply，所以订阅会话列表放在这里。
     * 连续切换（打开会话 → 切项目）用 400ms 合并，只在取值变化时发一次请求。
     *
     * CG15：失败要能重试。旧实现把 lastSent 写在 fetch 之前、失败只 console.warn——
     * 一次网络抖动 / 宿主重启就把「跟随当前项目」永久关死，直到用户切换会话。现在
     * lastSent 只在成功（或服务端明确拒绝的 4xx）后落位；网络错误 / 5xx 走指数退避
     * 重试（1s 起、封顶 30s）；404（宿主启动期路由未挂上）与 5xx 同为瞬态，一并重试。
     */
    function installSessionReporter(ctx) {
      let lastSent = null
      let timer = null
      let retryTimer = null
      let retryDelayMs = 0
      let disposed = false

      const readCwd = () => activeSessionCwd()

      const report = async () => {
        const cwd = readCwd()
        if (disposed || cwd === lastSent) return
        try {
          const response = await fetch('/api/dsh-codegraph/follow', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ path: cwd }),
          })
          // 404 也要重试（评审追记）：宿主启动期路由还没挂上时 /follow 会 404，那是
          // 瞬态而不是拒绝；5xx 是服务端抖动。其余 4xx（400 目录不存在、403 越权）
          // 才是明确拒绝——记下这个值等下一次会话变化，不重试轰炸。
          if (!response.ok && (response.status === 404 || response.status >= 500)) {
            throw new Error('HTTP ' + response.status)
          }
          lastSent = cwd
          retryDelayMs = 0
        } catch (error) {
          console.warn('[dsh-codegraph] failed to report the active session directory; will retry: ' + (error instanceof Error ? error.message : String(error)))
          if (disposed) return
          retryDelayMs = nextRetryDelayMs(retryDelayMs)
          if (retryTimer !== null) clearTimeout(retryTimer)
          retryTimer = setTimeout(() => {
            retryTimer = null
            void report()
          }, retryDelayMs)
        }
      }

      const schedule = () => {
        if (disposed) return
        if (timer !== null) clearTimeout(timer)
        timer = setTimeout(() => {
          timer = null
          void report()
        }, 400)
      }

      ctx.effect(() => {
        const subscribe = sessionsService?.list?.subscribe
        // 首次进入先报一次：宿主重启后也能立刻对齐，不用等用户切会话
        schedule()
        const off = typeof subscribe === 'function' ? subscribe(schedule) : undefined
        return () => {
          disposed = true
          if (timer !== null) clearTimeout(timer)
          if (retryTimer !== null) clearTimeout(retryTimer)
          if (typeof off === 'function') off()
        }
      })
    }

    /* ================================ 插件入口 ================================ */

    exports.inject = ['slots', 'sessions']

    /**
     * DSH ≥0.1.6-alpha.2 的行配置 key：`<bundle 包名>#<行 id>`，行 id 取自 bundle 的
     * cordis.patch.yml。独立安装时 bundle 是本包，装全家桶时是 @hyzyn/dsh-all —— 两个都注册，
     * 未命中的那个只是躺在 ledger 里，不会渲染。
     */
    const ROW_CONFIG_KEYS = [
      '@hyzyn/dsh-codegraph#codegraph',
      '@hyzyn/dsh-all#codegraph',
    ]

    exports.apply = (ctx) => {
      installI18n(ctx)
      sessionsService = ctx.sessions
      installSessionReporter(ctx)
      // 样式由卡片实例自管（ensureStyle/releaseStyle 引用计数，CG08）——这里不再全局
      // 注入一次又随插件卸载摘掉，那会让另一张还在显示的卡片全裸。
      /*
       * 设置面：0.2.0-rc.1 起挂 `plugins.bundle.config`——key 是 **bundle 包名**，管理器的插件
       * 详情页把它渲染在「说明」正下方；`plugins.row.config` 是 per-row 的「>」子页。
       *
       * 两条硬约束（第一条踩过坑，见下）：
       *   ① `plugins.bundle.config` 的 key 是**共享命名空间**：同一个 key 只能有一个注册者，
       *      重复注册**直接抛错**（`keyed slot ... already has an entry`），而客户端 `apply`
       *      抛错 = 整个插件起不来（实测：把 `@hyzyn/dsh-all` 也挂上时，八个插件抢同一个 key，
       *      启动页直接变「Failed to load plugins」）（D158）。聚合包 `@hyzyn/dsh-all` 是所有插件共用的
       *      bundle，**不能**挂 bundle.config —— 它没有内联位，设置面走它自己的 row 入口。
       *   ② 内联位可用时，**本包自己的** bundle 不再注册 row 槽（同一份表单两个入口会让人以为
       *      有两套设置）；聚合包那份 row 入口**保留**（那是它在聚合安装下的唯一入口）。旧宿主
       *      （bundle 槽不存在，0.1.6 线）回退注册全部 row 槽，功能一点不减。
       * 就绪顺序不敏感：任一侧先到都收敛到「内联优先」（后到的本包 row 注册会被撤掉）。
       */
      const AGGREGATE_BUNDLE = '@hyzyn/dsh-all'
      const BUNDLE_NAMES = [...new Set(ROW_CONFIG_KEYS.map((key) => key.split('#')[0]))]
      const OWN_BUNDLE = BUNDLE_NAMES.find((name) => name !== AGGREGATE_BUNDLE)
      let bundleConfigLive = false
      const disposeOwnRowConfigs = []
      if (OWN_BUNDLE !== undefined) {
        ctx.slots.inject('plugins.bundle.config', () => {
          bundleConfigLive = true
          while (disposeOwnRowConfigs.length > 0) {
            const disposeRow = disposeOwnRowConfigs.pop()
            if (typeof disposeRow === 'function') disposeRow()
          }
          return ctx.slots.register({
            name: 'plugins.bundle.config',
            key: OWN_BUNDLE,
          }, CodegraphSettingsCard)
        })
      }
      for (const key of ROW_CONFIG_KEYS) {
        ctx.slots.inject('plugins.row.config', () => {
          const own = key.split('#')[0] === OWN_BUNDLE
          if (own && bundleConfigLive) return undefined
          const disposeRow = ctx.slots.register({
            name: 'plugins.row.config',
            key,
          }, CodegraphSettingsCard)
          if (own) disposeOwnRowConfigs.push(disposeRow)
          return disposeRow
        })
      }
      // DSH ≥0.1.6：设置里与「通用设置」平级的「插件配置」页（子 slot 由
      // @hyzyn/dsh-kit-settings 声明）。不传 view，卡片走各自原有的可折叠形态。
      ctx.slots.inject('settings.kit.item', () => ctx.slots.register({
        name: 'settings.kit.item',
        id: 'codegraph',
        order: 60,
        label: () => "Codegraph",
      }, CodegraphSettingsCard))
      // DSH ≤0.1.5：设置 → 插件 的「插件配置」标签页，keyed 插槽按 settings 命名空间派发。
      ctx.slots.inject('settings.plugin.item', () => ctx.slots.register({
        name: 'settings.plugin.item',
        // settings.plugin.item 是 keyed 插槽：key 必须是该卡片所编辑的 settings 命名空间
        key: 'codegraph',
        order: 104,
      }, CodegraphSettingsCard))
    }

    return exports
  },
})
