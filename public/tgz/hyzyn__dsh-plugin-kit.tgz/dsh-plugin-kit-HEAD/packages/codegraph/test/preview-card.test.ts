/**
 * 卡片预览渲染器（`scripts/preview-card.mjs`）的守卫。
 *
 * 为什么要有这条用例：这个脚本**不在任何闸门里**——`client-lint.mjs` 只查客户端半体
 * （`client.js` / `client-src/index.js`），而这个脚本是构建期工具。于是它自己的低级错误
 * 一路漏到手工运行时才炸：
 *
 *   实测（2026-09-22，加 P0 预览模式时）：把两个 `const` 声明写在 `htmlPath` 之后，
 *   `--fallback` 直接 `ReferenceError: Cannot access 'perAgent' before initialization`
 *   —— 正是 `client-lint.mjs` 头注释里列的第 1 类错误（TS2448「块级变量先用后声明」），
 *   只是发生在一个它不覆盖的文件里。
 *
 * 所以这里不是「读源码断言字符串」（那样只能测出我刚好想到的形状），而是**真的把三个
 * 模式各跑一遍**：脚本 0.4s 就能跑完、产物落在包内 `.preview/`（已在 .gitignore），
 * 完全负担得起。跑得动 = 没有引用错误、没有 TDZ、选项解析可用。
 */
import { execFileSync } from 'node:child_process'
import { existsSync, readFileSync, rmSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { describe, expect, it } from 'vitest'

const pkgRoot = join(dirname(fileURLToPath(import.meta.url)), '..')
const script = join(pkgRoot, 'scripts', 'preview-card.mjs')
const previewDir = join(pkgRoot, '.preview')

/** 跑一个预览模式，返回产物 HTML（失败时抛出带 stderr 的错误）。 */
const render = (args, outName) => {
  try {
    execFileSync(process.execPath, [script, ...args], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
  } catch (error) {
    const stderr = error instanceof Error ? error.stderr?.toString() ?? '' : ''
    throw new Error(`preview-card.mjs ${args.join(' ')} 跑失败：\n${stderr}`, { cause: error })
  }
  const out = join(previewDir, outName)
  expect(existsSync(out), `产物不存在：${out}`).toBe(true)
  return readFileSync(out, 'utf8')
}

describe('卡片预览渲染器：三种模式都要能跑出产物', () => {
  it('默认（managed）：能渲染，且**不**出现 per-agent 生效文案', () => {
    const html = render([], 'codegraph-card.html')
    expect(html).toContain('per-agent MCP 隔离')
    expect(html, 'managed 态下不该显示「生效中」').not.toContain('per-agent 生效中')
    expect(html, 'managed 态下不该显示退回警告').not.toContain('已退回 managed')
  })

  it('--per-agent：渲染生效态文案与挂载数', () => {
    const html = render(['--per-agent'], 'codegraph-card-per-agent.html')
    expect(html).toContain('per-agent 生效中')
    expect(html).toContain('已挂载 2 个 agent')
  })

  it('--fallback：渲染「已退回 managed」的原因（这一档最容易写错，必须能离线看）', () => {
    const html = render(['--fallback'], 'codegraph-card-fallback.html')
    expect(html).toContain('per-agent 未生效，已退回 managed')
    // 退回时不能说「生效中」——同时出现两句自相矛盾的文案就是卡片在骗用户
    expect(html, '退回态下不该又说「生效中」').not.toContain('per-agent 生效中')
  })

  it('--busy：两级反馈都要出现（按钮自己 + 标题行全局）', () => {
    /*
     * 用户反馈（截图）：「在这里点，会看不到加载的 loading」——滚到卡片下半部分
     * （搜索与查询 / Agent 集成）时，标题行的全局指示器已经移出视野，点「搜索」
     * 「影响面」就完全没有反馈。所以忙碌呈现必须**两级都有**：
     *   - 被点的那个按钮自己显示（busyOr）：手指底下，无论滚到哪都看得见；
     *   - 标题行的全局指示器：滚到顶时一眼看到在忙什么，并承载「取消」。
     *
     * --busy 让 /status 永不 resolve，于是 busyAction='status'：
     * 「刷新状态」按钮应变成「刷新中…」，标题行应显示「读取索引状态…」。
     */
    const html = render(['--busy'], 'codegraph-card-busy.html')
    // 组头刷新是**图标**按钮：忙碌态用 data-busy 自转 + aria/title 换文案，没有可见文字
    expect(html, '图标按钮的忙碌态缺失（data-busy）').toContain('data-busy="1"')
    expect(html, '忙碌时应给出可读文案').toContain('正在读取索引状态')
    expect(html, '标题行全局指示器缺失').toContain('读取索引状态…')
    // 只有正在跑的那个动作显示忙碌，其余按钮保持静止文案（否则整排都在转圈=噪音）
    expect(html, '非活动按钮不该显示忙碌文案').toContain('>Sync<')
    expect(html, '非活动按钮不该显示忙碌文案').toContain('>重建索引<')
    expect(html).toContain('cg_btnBusy')
    /*
     * 顺带钉住「索引状态组无条件渲染」：--busy 让 /status 永不 resolve，于是 status
     * 为 null——这一组仍必须在，否则「刷新」按钮（挂在它的组头）会连同整组一起消失，
     * 用户就没有就地重试的入口。这是把刷新挪进组头时**必须**同时保证的前提。
     */
    expect(html, '索引状态组应无条件渲染').toContain('索引状态')
    expect(html, '无数据时应给占位而不是空白').toContain('还没读取到索引状态')
    // 组头右侧的刷新图标按钮（处于忙碌态：data-busy=1 + aria-label）
    expect(html).toMatch(/cg_sectionRule"><\/span><button[^>]*data-busy="1"/)
  })

  it('--result：点「文件」后结果出现在**搜索与查询下方**（不是面板最底部）', () => {
    /*
     * 用户反馈：「点击文件看不到对应的列表」。根因是结果区原先在面板**最底部**
     * （Agent 集成之后），而触发按钮在「索引维护」——点完要往下翻两屏，中间还可能
     * 横着一个展开的诊断包。
     *
     * 修法：① 结果区上移到「搜索与查询」正下方；② 各类结果做成页签，点哪个按钮切到
     * 哪一页；③ outputs 按路由分槽，切页签不丢上一次的结果。
     */
    const html = render(['--result'], 'codegraph-card-result.html')
    expect(html, '结果区缺少页签栏').toContain('cg_tabs')
    expect(html, '缺少活动页签高亮').toContain('cg_tabOn')
    expect(html, '缺少结果面板').toContain('cg_tabPanel')
    // 「文件」页签被点亮（点了「文件」就应切到它）
    expect(html).toMatch(/cg_tab cg_tabOn"[^>]*>文件</)
    // 夹具里的文件列表真的渲染出来了（空态说明链路没走通）
    expect(html).toContain('src/index.ts')
    // 关键位置断言：结果区必须在「Agent 集成」**之前**（原先在它之后 = 最底部）
    expect(html.indexOf('class="cg_tabs"')).toBeLessThan(html.indexOf('Agent 集成'))
  })

  it('--feedback：顺序必须是「按钮 → 结果 → 脚注」（脚注不再夹在中间）', () => {
    /*
     * 用户反馈（截图）：「这一块交互 ui 挺乱的」。乱在**顺序**：遥测脚注原先在
     * 「索引维护」组的末尾，于是正好插在「重新探测 / 诊断包」两个按钮与它们自己的
     * 结果之间——读起来是「按钮 → 一段无关的说明 → 按钮的结果」。
     *
     * 修法：① 反馈项包进 .cg_feedback（内部间距 12px→6px，读成一个整体）；
     * ② 脚注移到反馈**之后**（脚注属于背景说明，就该排在结果之后）。
     */
    const html = render(['--feedback'], 'codegraph-card-feedback.html')
    const plain = html.replace(/<style[\s\S]*?<\/style>/, '')
    const feedbackAt = plain.indexOf('class="cg_feedback"')
    const reportAt = plain.indexOf('诊断包（可整段复制贴 issue）')
    const telemetryAt = plain.indexOf('匿名用量统计')
    expect(feedbackAt, '缺少反馈容器').toBeGreaterThan(-1)
    expect(reportAt, '反馈容器里应含诊断包行').toBeGreaterThan(feedbackAt)
    expect(telemetryAt, '遥测脚注应在诊断包行**之后**（原先在按钮与结果之间）').toBeGreaterThan(reportAt)
  })

  it('--alert：两条「什么都干不了」的警告排在**数据之前**（不再埋在卡片最底部）', () => {
    /*
     * 用户问「Agent 集成这个是否有必要放在前面」。设置项留在后面是对的（配置一次、用很久），
     * 但那一节里混着两条**问题警告**，它们的严重性是「什么都干不了」：
     *   - CLI 探测不到 → systemPrompt 不注入，状态 / 搜索 / sync / 重建索引**全部报错**；
     *   - 托管行指向的目录不是有效索引 → MCP 工具拿到错的/没有的项目上下文。
     * 却渲染在「Agent 集成」——卡片的**最后一个分区**，要滚到底才看得见。
     * 现在挪进页面最前的「问题区」；健康时该区完全不渲染。
     */
    const html = render(['--alert'], 'codegraph-card-alert.html')
    const plain = html.replace(/<style[\s\S]*?<\/style>/, '')
    // 用组头标记定位，不要用裸文本——卡片描述里也有「索引状态」四个字（第一版就是这么假失败的）
    const head = (label) => plain.indexOf(`cg_sectionHeadText">${label}<`)
    const alertsAt = plain.indexOf('class="cg_alerts"')
    expect(alertsAt, '缺少问题区').toBeGreaterThan(-1)
    expect(alertsAt, '问题区应在目标项目之后').toBeGreaterThan(head('目标项目'))
    expect(alertsAt, '问题区应在索引状态之前（先看问题、再看数据）').toBeLessThan(head('索引状态'))
    expect(plain).toContain('探测不到可执行的 CLI 命令')
    expect(plain).toContain('不是有效索引')
    // 「Agent 集成」里不该再有它们
    const agentSection = plain.slice(head('Agent 集成'))
    expect(agentSection, 'Agent 集成里不该再有 CLI 警告').not.toContain('探测不到可执行的 CLI 命令')
  })

  it('--adoption：采纳率整行必须可见（不许 nowrap/ellipsis 截成半句）', () => {
    /*
     * 用户反馈（截图）：卡片上那行被截成
     *   `采纳率：codegraph 1 次 / 发现类 1 次 → 50%（宽口径含…`
     * ——后半句（另一个口径的解释）永远读不到。根因是 `.cg_subtitle` 沿用了
     * `nowrap + text-overflow:ellipsis + max-width:360px`，而这行是卡片里唯一一行
     * **长度不可控**的说明文案（数字随两个口径与工具种类变化；空态那句更长）。
     *
     * 两条判据缺一不可：① 整句确实在 HTML 里；② 承载它的规则不再带 nowrap / ellipsis。
     * 只看 ① 会漏掉「文本在、样式把它裁了」——而这次现场恰恰是后者。
     */
    const html = render(['--adoption'], 'codegraph-card-adoption.html')
    expect(html, '整句（含宽口径那半句）必须都在').toContain('宽口径含读取 50%')
    const rule = /\.cg_subtitle\{([^}]*)\}/.exec(html)?.[1] ?? ''
    expect(rule, '.cg_subtitle 规则没渲染出来（选择器改名了？）').not.toBe('')
    expect(rule, 'cg_subtitle 不许 nowrap：它就是「截成半句」的那一半原因').not.toContain('nowrap')
    expect(rule, 'cg_subtitle 不许 text-overflow：省略号就是用户看到的那半句').not.toContain('text-overflow')
  })

  it('三种模式写不同文件（互不覆盖）', () => {
    render([], 'codegraph-card.html')
    render(['--per-agent'], 'codegraph-card-per-agent.html')
    render(['--fallback'], 'codegraph-card-fallback.html')
    for (const name of ['codegraph-card.html', 'codegraph-card-per-agent.html', 'codegraph-card-fallback.html']) {
      expect(existsSync(join(previewDir, name)), `${name} 不存在`).toBe(true)
    }
  })
})

// 产物是构建期临时物（.preview/ 在 .gitignore 里），用完即清，不给仓库留垃圾。
process.on('exit', () => {
  try {
    rmSync(previewDir, { recursive: true, force: true })
  } catch {
    /* 清不掉也不影响用例结论 */
  }
})
