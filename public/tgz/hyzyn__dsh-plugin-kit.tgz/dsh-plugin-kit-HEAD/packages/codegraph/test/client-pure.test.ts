import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'

import {
  REL_LIMIT,
  adoptionText,
  buildQuery,
  fmtBytes,
  fmtNum,
  fmtTime,
  nextRetryDelayMs,
  seenAgoText,
  shortPath,
  staleReasons,
  truncationNote,
} from '../client-src/pure.js'

/*
 * 浏览器半体的纯逻辑测试（首次给 client-src 配上单测）。
 *
 * 为什么只有这几个函数：client-src/index.js 剩下的部分都要 React / DOM 才能跑，而仓库的
 * 测试底座（vitest.config.ts）刻意只收宿主半体、也没装 react / jsdom。纯判定抽到
 * client-src/pure.js 后可以在这里直接测——CG11 / CG15 / CG17 三条修复的判定核心从此有了
 * 自动化防线，不再只靠「人工点卡片」。
 *
 * 注意：本文件 import 的是**源码** pure.js，不是构建产物 client.js。产物那一侧由 CI 的
 * artifact-diff（构建前后 git diff）与 scripts/build-client.mjs 里的残留 import 检查兜住。
 */

/**
 * 断言用的翻译桩：把「键 + 参数」渲染成一行可读文本。
 *
 * 为什么不用一份中文夹具：文案的唯一归宿是目录（`client-src/index.js` 的 `I18N_ZH`，
 * 键集与占位符由 `scripts/check-i18n.mjs` 校验）。测试再抄一份中文就是本仓最忌讳的
 * 「同一件事实现在两处」。所以这批函数只断言**抛哪个键、带哪些参数**，措辞归目录。
 */
const t = (key: string, params?: Record<string, unknown>): string =>
  params === undefined
    ? key
    : key + '(' + Object.entries(params).map(([name, value]) => name + '=' + String(value)).join(',') + ')'

describe('CG11：staleReasons 汇总 CLI 的过期信号', () => {
  it('四个信号全在顶层时报全四条', () => {
    expect(staleReasons({
      reindexRecommended: true,
      version: '1.6.0',
      builtWithVersion: '1.1.1',
      builtWithExtractionVersion: 24,
      currentExtractionVersion: 25,
      worktreeMismatch: true,
    }, t)).toEqual([
      'status.reasonReindex',
      'status.reasonBuiltWith(built=1.1.1,current=1.6.0)',
      'status.reasonExtraction(built=24,current=25)',
      'status.reasonWorktree',
    ])
  })

  it('嵌套在 index.* 下时同样读到（CLI 版本间字段位置有差异）', () => {
    const reasons = staleReasons({
      version: '1.6.0',
      index: {
        reindexRecommended: true,
        builtWithVersion: '1.1.1',
        builtWithExtractionVersion: 24,
        currentExtractionVersion: 25,
        worktreeMismatch: true,
      },
    })
    expect(reasons).toHaveLength(4)
  })

  it('CLI 版本一致时不报版本漂移（只比字符串，不做版本序比较）', () => {
    expect(staleReasons({ version: '1.6.0', builtWithVersion: '1.6.0' })).toEqual([])
  })

  it('提取器版本相等或更新时不报（只有严格落后才算）', () => {
    const base = { builtWithExtractionVersion: 25, currentExtractionVersion: 25 }
    expect(staleReasons(base)).toEqual([])
    expect(staleReasons({ builtWithExtractionVersion: 26, currentExtractionVersion: 25 })).toEqual([])
  })

  it('健康索引 / 非对象入参都返回空数组（面板据此不渲染警告行）', () => {
    expect(staleReasons({ version: '1.6.0', index: { reindexRecommended: false } })).toEqual([])
    expect(staleReasons(null)).toEqual([])
    expect(staleReasons(undefined)).toEqual([])
    expect(staleReasons('boom')).toEqual([])
  })

  it('真值不是布尔 true 时不算信号（CLI 给字符串 "true" 不该误报）', () => {
    expect(staleReasons({ reindexRecommended: 'true', worktreeMismatch: 1 })).toEqual([])
  })

  it('index 字段不是对象时退回顶层读，不抛错', () => {
    expect(staleReasons({ index: 'oops', reindexRecommended: true }, t)).toEqual([
      'status.reasonReindex',
    ])
  })
})

describe('CG15：nextRetryDelayMs 的退避阶梯', () => {
  it('从 1s 起步', () => {
    expect(nextRetryDelayMs(0)).toBe(1_000)
  })

  it('逐次翻倍', () => {
    expect(nextRetryDelayMs(1_000)).toBe(2_000)
    expect(nextRetryDelayMs(2_000)).toBe(4_000)
    expect(nextRetryDelayMs(8_000)).toBe(16_000)
  })

  it('封顶 30s，且到顶后稳定不再增长', () => {
    expect(nextRetryDelayMs(16_000)).toBe(30_000)
    expect(nextRetryDelayMs(30_000)).toBe(30_000)
    expect(nextRetryDelayMs(60_000)).toBe(30_000)
  })

  it('走满整条阶梯：0 → 1s → 2s → 4s → 8s → 16s → 30s → 30s', () => {
    const ladder = [0]
    // 起始 0（首次失败）之上要走 7 步才到「封顶后再一次」：1s→2s→4s→8s→16s→30s→30s
    for (let index = 0; index < 7; index++) ladder.push(nextRetryDelayMs(ladder[index]))
    expect(ladder).toEqual([0, 1_000, 2_000, 4_000, 8_000, 16_000, 30_000, 30_000])
  })
})

describe('CG17：truncationNote 不再静默截断', () => {
  it('超出上限时报出「已显示前 N 条，共 M 条」', () => {
    expect(truncationNote(31, REL_LIMIT, t)).toBe('list.truncatedShown(shown=30,total=31)')
    expect(truncationNote(500, REL_LIMIT, t)).toBe('list.truncatedShown(shown=30,total=500)')
  })

  it('恰好等于上限时不提示（全部都在，没有截断）', () => {
    expect(truncationNote(REL_LIMIT, REL_LIMIT)).toBe('')
  })

  it('未超上限（含空列表）时不提示', () => {
    expect(truncationNote(0, REL_LIMIT)).toBe('')
    expect(truncationNote(29, REL_LIMIT)).toBe('')
  })

  it('上限是 30（与 relList 的 slice(0, REL_LIMIT) 同源，改一处即两边同步）', () => {
    expect(REL_LIMIT).toBe(30)
  })
})

describe('P1 采纳率：adoptionText 的边界', () => {
  it('无 summary / 非对象 → 空串（不渲染那一行）', () => {
    expect(adoptionText(null)).toBe('')
    expect(adoptionText(undefined)).toBe('')
    expect(adoptionText('nope')).toBe('')
  })

  it('一次调用都没有：明说没有记录，而不是 0%', () => {
    const text = adoptionText({ codegraph: 0, discovery: 0, discoveryTotal: 0, file: 0, other: 0 }, t)
    expect(text).toContain('meta.adoptionNoRecords')
    expect(text).not.toContain('0%')
  })

  it('只有其它工具：说「还没有探索类调用」，不显示 0%', () => {
    const text = adoptionText({ codegraph: 0, discovery: 0, discoveryTotal: 0, file: 0, other: 5 }, t)
    expect(text).toContain('meta.adoptionNoDiscoveryCalls')
    expect(text).toContain('other=5')
    expect(text).not.toContain('0%')
  })

  it('有读取但没有发现类：与「只有其它工具」区分开', () => {
    const onlyReads = adoptionText({ codegraph: 0, discovery: 0, discoveryTotal: 0, file: 4, other: 0 }, t)
    expect(onlyReads).toContain('meta.adoptionNoDiscovery')
    expect(onlyReads).toContain('file=4')
    const onlyOther = adoptionText({ codegraph: 0, discovery: 0, discoveryTotal: 0, file: 0, other: 4 }, t)
    expect(onlyOther).toContain('meta.adoptionNoDiscoveryCalls')
  })

  it('有发现类调用：窄口径是主口径，宽口径仅在不同时带出', () => {
    // grep 进 discovery；read 只进 file —— 两个口径给出不同的百分比
    expect(adoptionText({ codegraph: 2, discovery: 1, discoveryTotal: 3, file: 1, other: 0, indexed: true }, t))
      .toBe('meta.adoptionMain(codegraph=2,discovery=1,narrow=67)meta.adoptionBroad(broad=67)')
    // 只有读取时宽口径不同，必须标出来
    expect(adoptionText({ codegraph: 0, discovery: 0, discoveryTotal: 0, file: 4, other: 2, indexed: true }, t))
      .toBe('meta.adoptionNoDiscovery(codegraph=0,file=4,other=2)')
    expect(adoptionText({ codegraph: 3, discovery: 0, discoveryTotal: 3, file: 0, other: 0, indexed: true }, t))
      .toBe('meta.adoptionMain(codegraph=3,discovery=0,narrow=100)')
  })

  it('两个口径确实是两个数（真实历史里差别巨大：2.2% vs 28.8%）', () => {
    const text = adoptionText({ codegraph: 1, discovery: 3, discoveryTotal: 4, file: 20, other: 0, indexed: true }, t)
    expect(text).toContain('discovery=3')
    expect(text).toContain('narrow=25')
    expect(text).toContain('broad=5')
  })

  it('未索引项目要标明数字不代表提示词效果', () => {
    const text = adoptionText({ codegraph: 0, discovery: 2, discoveryTotal: 2, file: 2, other: 0, indexed: false }, t)
    expect(text).toContain('meta.adoptionUnindexed')
  })
})

describe('P2 项目列表：shortPath / seenAgoText', () => {
  it('shortPath 保留最后两段（这是还能分辨的粒度），非字符串原样空串', () => {
    expect(shortPath('/Users/czz/coding/project/cdc-manage')).toBe('…/project/cdc-manage')
    expect(shortPath('/a/b')).toBe('/a/b')            // 两段以内不动
    expect(shortPath('/a')).toBe('/a')
    expect(shortPath('')).toBe('')
    expect(shortPath(null)).toBe('')
    expect(shortPath(undefined)).toBe('')
    // 尾斜杠不该产生空段
    expect(shortPath('/a/b/c/')).toBe('…/b/c')
  })

  it('CG59：Windows 路径也缩短（分隔符要认 \\，否则整串是一段、永远不缩）', () => {
    // 只按 '/' 切时，下面这些会整串命中 `parts.length <= 2` 而原样返回
    expect(shortPath('C:\\Users\\me\\proj\\repo')).toBe('…/proj/repo')
    expect(shortPath('C:\\repo')).toBe('C:\\repo')          // 两段以内仍不动
    expect(shortPath('C:\\a\\b\\c\\')).toBe('…/b/c')         // 尾分隔符不产生空段
    expect(shortPath('\\\\server\\share\\a\\b')).toBe('…/a/b') // UNC 前缀不产生空段
    // 混合分隔符（编辑器 / git 在不同平台给出来的形状）
    expect(shortPath('C:/Users/me/proj/repo')).toBe('…/proj/repo')
  })

  it('seenAgoText 分档给人话，非法值返回空串', () => {
    expect(seenAgoText(0, t)).toBe('meta.seenJustNow')
    expect(seenAgoText(30_000, t)).toBe('meta.seenJustNow')
    expect(seenAgoText(90_000, t)).toBe('meta.seenMinutes(count=1)')
    expect(seenAgoText(3 * 3600_000, t)).toBe('meta.seenHours(count=3)')
    expect(seenAgoText(2 * 86400_000, t)).toBe('meta.seenDays(count=2)')
    expect(seenAgoText(-1)).toBe('')
    expect(seenAgoText(NaN)).toBe('')
    expect(seenAgoText('nope')).toBe('')
  })
})

describe('CG51：查询串拼装（数组必须逐个 append）', () => {
  it('数组 → 重复参数；这是 affected 多文件的唯一正确形态', () => {
    // 关键：不能是 `files=a.ts%2Cb.ts`（一个值）——宿主按 getAll('files') 收，
    // 那样 CLI 会收到一个名叫 "a.ts,b.ts" 的、不存在的文件
    expect(buildQuery({ files: ['a.ts', 'b.ts'] })).toBe('?files=a.ts&files=b.ts')
    expect(buildQuery({ path: '/p', files: ['a.ts', 'b.ts'] })).toBe('?path=%2Fp&files=a.ts&files=b.ts')
  })

  it('空数组不产生参数；数组里的空值被跳过', () => {
    expect(buildQuery({ path: '/p', files: [] })).toBe('?path=%2Fp')
    expect(buildQuery({ files: ['a.ts', '', undefined, null, 'b.ts'] })).toBe('?files=a.ts&files=b.ts')
  })

  it('标量照旧；undefined / null / 空串整键跳过；没有参数时返回空串', () => {
    expect(buildQuery({ q: 'x', limit: 20 })).toBe('?q=x&limit=20')
    expect(buildQuery({ q: '', path: undefined, kind: null })).toBe('')
    expect(buildQuery({})).toBe('')
    expect(buildQuery()).toBe('')
    expect(buildQuery({ n: 0 })).toBe('?n=0') // 0 是合法值，不该被当空
  })
})

describe('P3 状态面板格式化：fmtNum / fmtBytes / fmtTime 的边界', () => {
  it('fmtNum：非有限值与非数字一律占位符（状态里字段缺失是常态）', () => {
    expect(fmtNum(6542)).toBe((6542).toLocaleString())
    expect(fmtNum(0)).toBe('0')
    for (const bad of [NaN, Infinity, -Infinity, '6542', null, undefined, {}]) {
      expect(fmtNum(bad), String(bad)).toBe('—')
    }
  })

  it('fmtBytes：1000 进制进位、>=100 不留小数、非法值占位符', () => {
    expect(fmtBytes(0)).toBe('0 B')
    expect(fmtBytes(999)).toBe('999 B')
    // 1000 整就进位（十进制口径，与 CLI 的 dbSizeBytes 一致）
    expect(fmtBytes(1000)).toBe('1.0 kB')
    expect(fmtBytes(1500)).toBe('1.5 kB')
    // >= 100 的带单位量值不留小数
    expect(fmtBytes(99900)).toBe('99.9 kB')
    expect(fmtBytes(100000)).toBe('100 kB')
    expect(fmtBytes(45105152)).toBe('45.1 MB')
    // 上限封在 TB，不越界
    expect(fmtBytes(1e15)).toBe('1000 TB')
    for (const bad of [-1, NaN, Infinity, '100', null, undefined]) {
      expect(fmtBytes(bad), String(bad)).toBe('—')
    }
  })

  it('fmtTime：解析不出来【原样返回】，不是 Invalid Date、也不是 —', () => {
    // 这条是刻意的：吞掉原串会让人以为索引从未建立，而真相是 CLI 换了格式
    expect(fmtTime('not-a-date')).toBe('not-a-date')
    expect(fmtTime('2026-09-22T05:28:00.708Z')).not.toBe('—')
    expect(fmtTime('2026-09-22T05:28:00.708Z')).not.toContain('Invalid')
    for (const bad of ['', null, undefined, 42, {}]) {
      expect(fmtTime(bad), String(bad)).toBe('—')
    }
  })
})

describe('工具栏布局守卫：按钮组不许「整组不可断行」', () => {
  /*
   * 实测过的 bug（用户截图）：P2 把按钮从 5 个加到 12 个之后，「撤销索引」被裁掉。
   *
   * 根因不是按钮太多，而是 CSS 的选择错了：`.cg_toolbarBtns` 当时是
   * `flex-wrap:nowrap` + `flex-shrink:0`——**整组不许断行**。5 个按钮（约 300px）时
   * 这招是对的（要么整组留在标题右边、要么整组换行）；12 个按钮约 900px，而侧边栏
   * 只有 ~360px，整组不许断行就只能溢出被裁。
   *
   * 这条守卫钉的是**性质**而不是像素：只要按钮数超出一行能放下的量，容器就必须允许
   * 换行。它跑在源码文本上（不需要 DOM），所以在这个没有 jsdom / 无头 Chrome 的仓库里
   * 也能挡住回归。
   */
  const src = readFileSync(new URL('../client-src/index.js', import.meta.url), 'utf8')
  const cssOf = (cls: string): string => {
    const m = src.match(new RegExp(`'\\.${cls}\\{([^}]*)\\}'`))
    expect(m, `找不到 .${cls} 的样式定义`).not.toBeNull()
    return m?.[1] ?? ''
  }

  it('.cg_toolbarBtns 必须允许换行（nowrap 是那条被裁的根因）', () => {
    const css = cssOf('cg_toolbarBtns')
    expect(css).toContain('flex-wrap:wrap')
    expect(css).not.toContain('nowrap')
  })

  it('.cg_row 必须允许换行（P2 把探索/上下文放进这一行后列数变多）', () => {
    const css = cssOf('cg_row')
    expect(css).toContain('flex-wrap:wrap')
    // 不能再是固定列数的 grid：4-5 列会把两个输入框挤到不可用
    expect(css).not.toContain('grid-template-columns')
  })

  it('输入框在 flex 行里可伸缩（否则窄栏下会撑破容器）', () => {
    expect(cssOf('cg_row .cg_input')).toContain('flex:1 1')
  })

  it('探索 / 上下文 与搜索按钮同处搜索行（它们吃搜索框的关键词）', () => {
    // 结构断言的近似：这三个按钮的 onClick 都读 query，应当出现在同一区块里。
    // 锚点用动作键（busyOr('search'）而不是按钮文案——文案会随 UX 调整变，
    // 动作键是稳定标识（第一版锚在 "children: '搜索'" 上，加了忙碌态文案后立刻失效）。
    const anchor = "busyOr('search'"
    const searchBlock = src.slice(src.indexOf(anchor), src.indexOf(anchor) + 1400)
    expect(searchBlock).toContain("runQuery('explore'")
    expect(searchBlock).toContain("runQuery('context'")
  })
})

describe('UX 重构：面板信息架构（顺序 / 分层）守卫', () => {
  /*
   * 2026-09-22 的卡片重构：用户反馈「设置面板有点乱」。乱的具体形态是——
   *   1. 「索引状态」沉在最底部：打开卡片要先越过两行输入框和 9 个按钮，才知道
   *      这个目录索引健不健康。首屏应该回答「状态如何」，而不是先给一堆操作。
   *   2. 索引维护 9 个按钮零层级：每天点的 Sync、排障用的诊断包、罕见的解锁、
   *      破坏性的撤销索引完全同样式混在一行。
   *   3. 查询区混了两个工作流：符号查询（搜索/探索/上下文）和「改动文件 → 影响面」
   *      是两种不同心智，却共享一行参数。
   *   4. Agent 集成四个开关视觉同权：轻量开关（跟随/公告/指引）与改 MCP 拓扑的
   *      per-agent 隔离长得一样。
   *
   * 修法是**重排 + 分层**而不是删功能。下面钉的是这次重构的核心性质，
   * 免得下次「顺手调一下」又把状态塞回底部、把按钮拍平。
   */
  const src = readFileSync(new URL('../client-src/index.js', import.meta.url), 'utf8')

  /*
   * 锚点用 **i18n 键**（`group(t('panel.groupStatus')`）而不是界面文案（原来是 `group('索引状态'`）：
   * 文案已进 `client-src/index.js` 的目录块（docs/i18n.md），源码里不再有中文字面量，
   * 而键是比文案更稳定的标识——这条守卫钉的是**结构顺序**，与界面用哪种语言无关。
   * 与上面「探索 / 上下文」那条同一个理由（第一版锚在 "children: '搜索'" 上，加了忙碌态
   * 文案后立刻失效）。
   */
  /** 某个结构标记在源码里的位置（用源码文本顺序近似 DOM 顺序；所有标记都在同一个 children 数组里）。 */
  const pos = (needle: string): number => {
    const at = src.indexOf(needle)
    expect(at, `结构标记缺失：${needle}`).toBeGreaterThan(-1)
    return at
  }

  it('状态先于操作：索引状态 必须排在 索引维护 之前', () => {
    expect(pos("group(t('panel.groupStatus')")).toBeLessThan(pos("group(t('panel.groupMaintenance')"))
  })

  it('自上而下顺序：目标项目 → 索引状态 → 索引维护 → 搜索与查询 → Agent 集成', () => {
    const order = ["group(t('panel.groupTarget')", "group(t('panel.groupStatus')", "group(t('panel.groupMaintenance')", "group(t('panel.groupSearch')", "group(t('panel.groupAgent')"]
    for (let index = 1; index < order.length; index++) {
      expect(pos(order[index]), `${order[index - 1]} 应在 ${order[index]} 之前`).toBeGreaterThan(pos(order[index - 1]))
    }
  })

  it('索引维护按动作性质分层（生命周期 / 查看与诊断），删除类动作带独立标记', () => {
    expect(src).toContain("t('panel.rowLifecycle')")
    expect(src).toContain("t('panel.rowDiagnostics')")
    expect(pos("t('panel.rowLifecycle')")).toBeLessThan(pos("t('panel.rowDiagnostics')"))
    /*
     * 删除类动作（撤销索引）的落点变过一次，这里钉住**现在**的设计：
     *   - 它在「生命周期」行内（写索引的动作同档），不另起一行——独立成行会变成
     *     「一个按钮 + 右侧大片空白」，用户直接问「为什么单独换行」，看起来像换行 bug；
     *   - 但用竖向虚线槽（.cg_dangerSlot）与常规按钮隔开，排在它们之后。
     * 取 JSX 用法（className）而不是 CSS 定义——样式表里先出现该名字。
     */
    expect(src).toContain('cg_dangerSlot')
    const slotAt = pos("className: 'cg_dangerSlot'")
    expect(slotAt, '危险槽应在生命周期行内（查看与诊断之前）').toBeLessThan(pos("t('panel.rowDiagnostics')"))
    expect(slotAt, '危险槽应排在常规生命周期按钮之后').toBeGreaterThan(pos("busyOr('unlock'"))
  })

  it('Sync 是生命周期行的主按钮（cg_btn）：这张卡片最高频的安全操作要做视觉锚点', () => {
    // 生命周期子行内，Sync 用 cg_btn 而其它用 cg_btnGhost
    const lifecycle = src.slice(pos("t('panel.rowLifecycle')"), pos("t('panel.rowDiagnostics')"))
    expect(lifecycle).toContain("busyOr('sync'")
    const syncAt = lifecycle.indexOf("busyOr('sync'")
    expect(lifecycle.lastIndexOf("className: 'cg_btn'", syncAt), 'Sync 应使用 cg_btn 主样式').toBeGreaterThan(lifecycle.lastIndexOf("className: 'cg_btnGhost'", syncAt))
  })

  it('查询区拆成两个工作流：符号查询（吃关键词）在上，「其他查询」单列子行', () => {
    expect(src).toContain("t('panel.rowOtherQueries')")
    // 改动文件输入必须在「其他查询」标记之后（原先与类型/上限混在一行）
    expect(pos("t('panel.rowOtherQueries')")).toBeLessThan(pos("t('field.changedFiles')"))
    // 「类型」「上限」贴着搜索按钮（它们是 query 的参数），不跟改动文件混
    expect(pos("busyOr('search'")).toBeLessThan(pos("t('field.kind')"))
    expect(pos("t('field.kind')")).toBeLessThan(pos("t('panel.rowOtherQueries')"))
  })

  it('「文件」按钮与它的结果同处一区（不再与结果区割裂）', () => {
    /*
     * 用户反馈：「上面的文件和下面的搜索是一个东西吗，现在太割裂了」。
     * 上一轮我只把**结果区**上移，忘了「文件」的**按钮**还在「查看与诊断」里——
     * 同一个东西的按钮与结果分居两处，中间还夹着一个展开的诊断包。
     *
     * 这条钉住：文件按钮在「搜索与查询」组内、且在结果区之前（= 与结果区同处一区）。
     */
    const fileButton = pos("busyOr('files'")
    expect(fileButton, '文件按钮应在「搜索与查询」组内').toBeGreaterThan(pos("group(t('panel.groupSearch')"))
    expect(fileButton, '文件按钮应在结果区之前（同处一区）').toBeLessThan(pos("group(t('panel.groupResults')"))
    // 且不该再出现在「查看与诊断」里（那是卡片/CLI 自检动作，不产生查询结果）
    const diagnostics = src.slice(pos("t('panel.rowDiagnostics')"), pos("group(t('panel.groupSearch')"))
    expect(diagnostics, '「查看与诊断」里不该再有文件按钮').not.toContain("busyOr('files'")
  })

  it('「刷新」挂在「索引状态」组头（它刷的就是这一组，不该隔着一屏）', () => {
    /*
     * 用户反馈（截图）：「这个状态和刷新状态有关系吗」——箭头从「状态 ● 已索引」格
     * 指到「刷新状态」按钮。有关系：那个按钮重新读取的正是填充本组网格的数据
     * （`loadStatus` 只打 `/status`）。但它原先在「索引维护 → 查看与诊断」里，
     * 与它刷新的东西隔着一整屏，而且两边都叫「状态」。
     *
     * 修法：挪进「索引状态」的**组头右侧**——「这个按钮属于这一组」一眼可见。
     */
    const refresh = pos('onClick: loadStatus')
    expect(refresh, '刷新应在「索引状态」组内').toBeGreaterThan(pos("group(t('panel.groupStatus')"))
    expect(refresh, '刷新应在「索引维护」之前（即属于索引状态组）').toBeLessThan(pos("group(t('panel.groupMaintenance')"))
    // 组头里的辅助动作用**图标**而不是文字按钮（不抢组内主控件的视觉重量）
    const button = src.slice(refresh - 700, refresh + 700)
    expect(button, '刷新应是图标按钮').toContain('cg_iconBtn')
    expect(button, '图标按钮必须带 aria-label').toContain("'aria-label'")
    expect(button, '图标按钮必须带 title（悬停可读）').toContain('title:')
    expect(button, '应使用刷新图标路径').toContain('REFRESH_PATH')
    // 「查看与诊断」里不该再有它
    const diagnostics = src.slice(pos("t('panel.rowDiagnostics')"), pos("group(t('panel.groupSearch')"))
    expect(diagnostics, '「查看与诊断」里不该再有刷新').not.toContain('onClick: loadStatus')
  })

  it('「索引状态」组无条件渲染（否则读取失败时连重试入口都没了）', () => {
    // 刷新按钮挂在这个组的组头；整组若随 status 一起消失，status 读失败就无从重试
    expect(src, '缺少无数据占位').toContain("t('list.statusEmpty')")
    const groupAt = pos("group(t('panel.groupStatus')")
    // 组调用前不能是「status ? ...」那种整体守卫
    const before = src.slice(groupAt - 200, groupAt)
    expect(before, '「索引状态」组不该被 status 守卫包住').not.toMatch(/status\s*\n\s*\?\s*$/)
  })

  it('组头尾随动作靠显式细线元素右对齐（::after 会让按钮跑到细线左边）', () => {
    expect(src).toContain('cg_sectionRule')
    expect(src, '::after 已换成显式元素').not.toContain('.cg_sectionHead::after')
    // group 的第三个参数就是尾随动作槽
    expect(src).toMatch(/const group = \(label, children, action\)/)
  })

  it('诊断包默认折叠（展开的 260px 会把下方结果区推远）', () => {
    // report 的 details 不该带 open:true——它很长，自动展开会挡住结果
    const details = src.slice(pos("t('panel.reportSummary')") - 400, pos("t('panel.reportSummary')"))
    expect(details, '诊断包应默认折叠').not.toContain('open: true')
  })

  it('Agent 集成拆两行：「跟随与提示词」与「MCP 挂载」分开', () => {
    expect(src).toContain("t('panel.rowFollow')")
    expect(src).toContain("t('panel.rowMcp')")
    expect(pos("t('panel.rowFollow')")).toBeLessThan(pos("t('panel.rowMcp')"))
    // per-agent 开关必须在 MCP 挂载子行里（不能在提示词那行）
    expect(pos("t('panel.rowMcp')")).toBeLessThan(pos("t('check.perAgent')"))
    expect(pos("t('check.guidance')")).toBeLessThan(pos("t('panel.rowMcp')"))
  })
})

describe('UX 重构：忙碌态指示器（在标题行，不在正文中间）', () => {
  /*
   * 用户反馈（截图）：正文中间那句**居中大块**的「加载中…」不好——它夹在
   * 「匿名用量统计」与「搜索与查询」之间，三个毛病：
   *   ① 不说在加载**什么**（同步？重建？搜索？）；
   *   ② 插入/移除会把下面整组控件上下推（布局跳动，约 70px）；
   *   ③ 索引重建可能跑十分钟，而它会随滚动移出视野——最需要它的时候看不见。
   *
   * 改法：指示器提到**面板标题行**（常驻、零布局跳动），带动作文案，并把「取消」
   * 挪到它旁边（原先在危险行，与进度隔着用量统计，真要取消时找不到）。
   */
  const src = readFileSync(new URL('../client-src/index.js', import.meta.url), 'utf8')
  const pos = (needle: string): number => {
    const at = src.indexOf(needle)
    expect(at, `结构标记缺失：${needle}`).toBeGreaterThan(-1)
    return at
  }

  it('不再有笼统的居中大块「加载中…」', () => {
    expect(src, '旧的居中 loading 块应已删除').not.toContain("children: '加载中…'")
    // 只查**实际用法**（className），不查任何提及——注释里会说明「cg_loading 已退役」，
    // 直接断言源码不含该字样会把那条注释本身判红（第一版就是这么假失败的）。
    expect(src, '.cg_loading 的用法应已移除').not.toContain("className: 'cg_loading'")
  })

  it('忙碌指示器在面板标题行里（标题之后、目标项目之前 = 常驻且零布局跳动）', () => {
    expect(src).toContain('cg_panelHeader')
    expect(src).toContain('cg_busy')
    expect(pos('cg_panelHeader')).toBeLessThan(pos("group(t('panel.groupTarget')"))
    // 标题文案已进 i18n 目录（docs/i18n.md），锚点用键而不是中文字面量
    expect(pos("children: t('panel.title')")).toBeLessThan(pos("className: 'cg_busy'"))
  })

  it('忙碌文案具体到动作（不用笼统的「加载中」）', () => {
    /*
     * 每个动作各给一句，用户才知道在等什么、该不该取消。
     *
     * 文案迁移到 i18n 目录后（docs/i18n.md），这里钉两件事：
     *   ① 源码里用的是**动作键**（`t('msg.syncing')`）——键是稳定标识，文案会随语言变；
     *   ② 中文目录里这些键的译文仍是那六句具体动作文案（不是笼统的「加载中」）。
     * 键集 / 空值 / 中英一致由 `scripts/check-i18n.mjs` 兜，这里只钉「哪几句」。
     */
    const catalog = src.slice(src.indexOf('dsh-i18n:begin'), src.indexOf('dsh-i18n:end'))
    const expected: [string, string][] = [
      ['msg.syncing', '同步中…'],
      ['msg.reindexing', '重建索引中…'],
      ['msg.searching', '搜索中…'],
      ['msg.initializingIndex', '初始化索引中…'],
      ['msg.uninitializing', '撤销索引中…'],
      ['msg.readingStatus', '读取索引状态…'],
    ]
    for (const [key, label] of expected) {
      expect(src, `源码里缺少动作键：${key}`).toContain(`t('${key}')`)
      expect(catalog, `${key} 的中文译文应仍是「${label}」`).toContain(`'${key}': '${label}'`)
    }
  })

  it('「取消」紧挨着它要停的那件事（在 cg_busy 里，不在删除类动作那一格）', () => {
    const busyAt = pos("className: 'cg_busy'")
    const cancelAt = pos("children: t('btn.cancel')")
    const slotAt = pos("className: 'cg_dangerSlot'")
    expect(cancelAt, '取消应在忙碌指示器之后').toBeGreaterThan(busyAt)
    expect(cancelAt, '取消不应与删除类动作同格（那是撤销索引的位置）').toBeLessThan(slotAt)
  })

  it('刷新图标只在**本动作**在跑时自转（不是任何动作都转）', () => {
    /*
     * `loading` 是全局忙态：搜索时它也是 true。若图标跟着 loading 转，搜个符号就会看到
     * 刷新图标在转——那不是「正在刷新」而是错误信息。所以自转由 busyAction === 'status'
     * 驱动（busyAction 正是为「哪个动作在跑」引入的）。
     */
    expect(src).toContain("'data-busy': busyAction === 'status' ? '1' : undefined")
    expect(src).toContain('.cg_iconBtn[data-busy="1"] svg')
    // 减少动态效果时不自转，靠 aria/title 表达
    expect(src).toMatch(/prefers-reduced-motion:reduce\)\{\.cg_spinner,\.cg_iconBtn\[data-busy="1"\] svg\{animation:none\}\}/)
  })

  it('问题警告排在数据之前，且不再留在「Agent 集成」里', () => {
    /*
     * 用户问「Agent 集成这个是否有必要放在前面」。设置项留在后面是对的，但那一节里
     * 混着两条「什么都干不了」的警告，被埋在卡片最底部。现在它们进「问题区」，
     * 位置在「目标项目」之后、「索引状态」之前。
     */
    expect(src).toContain('cg_alerts')
    // 取 JSX 用法（className）而不是 CSS 定义——样式表里先出现该名字，
    // 直接 indexOf 会把 CSS 那一处当成结构位置（第一版就是这么假失败的）。
    const alerts = pos("className: 'cg_alerts'")
    expect(alerts, '问题区应在目标项目之后').toBeGreaterThan(pos("group(t('panel.groupTarget')"))
    expect(alerts, '问题区应在索引状态之前').toBeLessThan(pos("group(t('panel.groupStatus')"))
    // Agent 集成里不该再有它们
    const agent = src.slice(pos("group(t('panel.groupAgent')"))
    expect(agent, 'Agent 集成里不该再有 CLI 警告').not.toContain('cliWarning ?')
    expect(agent, 'Agent 集成里不该再有托管行警告').not.toContain('defaultWarning ?')
  })

  it('三个查询按钮有就地说明（信息不能只藏在 title 悬停里）', () => {
    /*
     * 用户直接问「这两个按钮做啥的」（指 探索 / 上下文）。它们的信息原先只在 `title`
     * 悬停提示里，而卡片是要被「扫一眼」的——需要就地说明。
     *
     * 标签保持 CLI 子命令的对应关系（query/explore/context）不改名，改用一行说明把
     * 「产物有什么不同」讲清楚。
     */
    expect(src, '缺少查询按钮说明行').toContain("t('hint.queryButtons')")
    // 说明行的中文译文仍要把「产物有什么不同」讲清楚（键存在 ≠ 文案还在）
    for (const phrase of ['搜索 = 符号列表', '探索 = 相关符号源码 + 调用链', '上下文 = 为任务组装上下文']) {
      expect(src, `说明行缺少：${phrase}`).toContain(phrase)
    }
    // 说明行必须紧跟这三个按钮之后、且在「其他查询」之前
    const legend = pos("t('hint.queryButtons')")
    expect(legend, '说明应在三个按钮之后').toBeGreaterThan(pos("runQuery('context'"))
    expect(legend, '说明应在「其他查询」之前').toBeLessThan(pos("t('panel.rowOtherQueries')"))
  })

  it('反馈项包成一个整体（.cg_feedback 收紧间距），且遥测脚注排在它之后', () => {
    /*
     * 用户反馈「这一块交互 ui 挺乱的」：四段（成功提示 / 脚注 / 诊断包行）各 12px 堆着，
     * 且脚注被夹在按钮与结果之间。
     */
    expect(src, '缺少反馈容器').toContain('cg_feedback')
    expect(src, '反馈容器应收紧间距').toMatch(/\.cg_feedback\{[^}]*gap:6px/)
    // 脚注在源码顺序上必须晚于反馈容器（= 晚于结果）
    expect(pos('cg_feedback')).toBeLessThan(pos("t('panel.telemetryOn')"))
    // 且脚注不该再留在「索引维护」组内（那正是它夹在中间的原因）
    const maintenance = src.slice(pos("group(t('panel.groupMaintenance')"), pos('cg_feedback'))
    expect(maintenance, '遥测脚注不该留在索引维护组里').not.toContain("t('panel.telemetryOn')")
  })

  it('组头槽只放单个辅助动作，不放主操作组（生命周期那排按钮不该上组头）', () => {
    /*
     * 被问过：「生命周期那几个按钮要不要也放到头上」。不该：
     *   - 组头细线靠 flex:1 占满剩余宽度，塞进 4 个文字按钮（约 390px）会把细线挤没、
     *     窄栏折行成两截，看起来像布局坏了；
     *   - Sync 是主按钮（cg_btn 实心蓝），进组头就降级成与标签并排的小控件，主次颠倒；
     *   - 「索引维护」这一节的**内容本来就是这些动作**，组头只负责命名。
     * 判据：一个辅助动作 → 组头；一组动作 / 本节主体 → 组内。
     */
    // 组头的第三个参数不该是一整排按钮（cg_toolbarBtns）
    expect(src, '组头槽里不该出现按钮行').not.toMatch(/\],\s*jsxs?\('div',\s*\{\s*className: 'cg_toolbarBtns'/)
    // 生命周期那排必须在「索引维护」组**体内**
    const sync = pos("busyOr('sync'")
    expect(pos("group(t('panel.groupMaintenance')")).toBeLessThan(pos("t('panel.rowLifecycle')"))
    expect(pos("t('panel.rowLifecycle')")).toBeLessThan(sync)
  })

  it('结果区在「搜索与查询」下方、且在「Agent 集成」之前（不再沉到面板最底部）', () => {
    /*
     * 用户反馈：「点击文件看不到对应的列表」——结果区原先在 Agent 集成**之后**
     * （面板最底部），而触发按钮在索引维护 / 搜索与查询，点完要翻两屏。
     */
    expect(src).toContain("group(t('panel.groupResults')")
    const resultAt = pos("group(t('panel.groupResults')")
    expect(resultAt, '结果区应在搜索与查询之后').toBeGreaterThan(pos("group(t('panel.groupSearch')"))
    expect(resultAt, '结果区应在 Agent 集成之前（这是本次修复的核心）').toBeLessThan(pos("group(t('panel.groupAgent')"))
  })

  it('结果按路由分槽保存（页签切回去还在，不是单槽覆盖）', () => {
    // 单槽 output 会让「点文件 → 点探索 → 切回文件」变空白
    expect(src).toContain('setOutputs((previous) =>')
    expect(src).toContain('outputs[activeTab]')
    expect(src, '单槽 output 应已退役').not.toContain('const [output, setOutput]')
  })

  it('每个触发按钮都会切到自己的页签', () => {
    for (const key of ['search', 'files', 'affected', 'explore', 'context', 'detail']) {
      expect(src, `缺少页签 key：${key}`).toContain(`key: '${key}'`)
    }
    // 查询路由用同一个 key 既当动作键又当页签键（busyOr(route) 与 setActiveTab(route) 同源）
    expect(src).toContain('setActiveTab(route)')
    expect(src).toContain("setActiveTab('search')")
    expect(src).toContain("setActiveTab('detail')")
  })

  it('结果出来后滚到可见处，且对假 DOM 有守卫（block:nearest = 已在视野就不动）', () => {
    expect(src).toContain('scrollIntoView')
    expect(src).toContain("block: 'nearest'")
    // 预览的假 DOM 没有 scrollIntoView：不守卫的话预览会直接崩
    expect(src).toMatch(/typeof el\.scrollIntoView !== 'function'/)
  })

  it('索引被重建 / 撤销后清掉陈旧的结果（文件列表描述的是旧索引）', () => {
    expect(src).toContain('clearIndexResults')
    expect(src).toContain('INDEX_RESULT_TABS')
  })

  it('转圈是纯 CSS 且尊重「减少动态效果」', () => {
    expect(src).toContain('@keyframes cg_spin')
    expect(src).toContain('prefers-reduced-motion')
  })

  it('每个动作按钮自己也要显示忙碌态（不能只靠标题行）', () => {
    /*
     * 用户反馈（截图）：「在这里点，会看不到加载的 loading」。根因是我上一轮把指示器
     * 只放到了标题行——卡片很长，滚到下半部分时它已移出视野。修法是**两级反馈**：
     * 按钮自己（busyOr）+ 标题行全局。
     *
     * 这条守卫钉住「每个动作按钮都接了 busyOr」：漏掉任何一个，那个按钮点了就没反馈。
     */
    expect(src, '缺少 busyAction 状态').toContain('busyAction')
    expect(src, '缺少 busyOr 助手').toContain('const busyOr =')
    expect(src, '缺少按钮内忙碌样式').toContain('cg_btnBusy')
    // 10 个**文字**动作按钮走 busyOr：init / sync / index / unlock / files / uninit /
    // search / explore / context / affected。
    // 第 11 个（status = 索引状态组头的刷新）是**图标**按钮，文案换成 aria/title，
    // 忙碌态用图标自转（data-busy）——见下一条断言。
    const used = [...src.matchAll(/busyOr\('/g)].length
    expect(used, `接了 busyOr 的按钮数 = ${String(used)}，应为 10`).toBe(10)
    for (const action of ['init', 'sync', 'index', 'unlock', 'files', 'uninit', 'search', 'explore', 'context', 'affected']) {
      expect(src, `缺少动作键：${action}`).toContain(`busyOr('${action}'`)
    }
  })
})
