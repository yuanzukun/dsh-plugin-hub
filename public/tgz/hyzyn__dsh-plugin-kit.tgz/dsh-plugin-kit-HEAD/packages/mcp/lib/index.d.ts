import type { Context } from '@deepseek-ai/cordis';
export declare const name = "mcp-config";
export declare const inject: string[];
export interface Config {
    /** 关闭整个插件（不注册路由、不发布提示）。默认开。 */
    enabled?: boolean;
    /** 是否向 agent 注入插件能力公告。默认开。 */
    announceToAgent?: boolean;
    /**
     * MCP 工具面怎么进 agent 的工具表。默认 `'eager'`（= 今天的行为：全部一次给出）。
     *
     * `'on-demand'` 时**工具仍由宿主注册**，但本插件给每个 agent 装一条限制把全部 `mcp__*`
     * 摘掉，只留 `mcp_servers`（看有哪些 server）与 `mcp_load`（按需装载）——请求体里不再有那
     * 几十 KB 的 MCP 工具定义，模型需要时自己装载。实现与判据见 `src/agent-surface.ts`。
     */
    agentToolLoading?: 'eager' | 'on-demand';
}
/**
 * MCP 工具面的**成本阈值**（个）：卡片据此在「合计超过多少」时给一行提示。
 *
 * 为什么这个数在**宿主侧**而不是浏览器半体：它是「成本可见性」这条产品判据的取值，卡片只是
 * 渲染器。放客户端等于同一件事两份真相（README 引用哪个都对不上另一个），而且换阈值要同时改
 * 两个文件、漏一个就静默漂移。所以 DTO 带 `toolBudget`，客户端只负责比较。
 *
 * 也**刻意 `export`**：README 里写「超过 N 个（`AGENT_TOOL_BUDGET`）」时，`scripts/check-readme-facts.mjs`
 * 只收集 `src/` 下的导出常量——私有常量会让这处引用恒绿（文档与代码一起漂也没人发现）。
 */
export declare const AGENT_TOOL_BUDGET = 80;
/**
 * `reconnect` 的默认值——**具名常量而不是散在 validateReconnect 里的字面量**。
 *
 * 为什么单独提出来：这三个数在 README 的排障表里是**判据的一部分**（「`maxAttempts`
 * 用完就放弃、必须重启」正是最常见的误判点），而 README 里的数字由
 * `scripts/check-readme-facts.mjs` 现算校验。
 *
 * **必须 `export`**：那个闸门只收集 `export const`（`collectConstants` 的判据是
 * 「非导出常量不是对外承诺的一部分」）。第一版写成模块内私有常量，抽不到 →
 * 比对不到 → 闸门恒绿，改错数字也不会红（实测：把 10 改成 99 仍然「通过」）。
 */
export declare const RECONNECT_DEFAULT_INITIAL_DELAY_MS = 500;
export declare const RECONNECT_DEFAULT_MAX_DELAY_MS = 30000;
export declare const RECONNECT_DEFAULT_MAX_ATTEMPTS = 10;
interface JsExpr {
    __jsExpr: string;
}
interface ReconnectConfig {
    enabled?: boolean;
    initialDelayMs?: number;
    maxDelayMs?: number;
    maxAttempts?: number;
}
/** 与 @deepseek-ai/dsh-mcp-client 的 Config 对齐（env/headers 值可为 !!js 表达式）。 */
interface McpServerConfig {
    serverName: string;
    transport: 'stdio' | 'streamable-http';
    command?: string;
    args?: string[];
    env?: Record<string, string | JsExpr>;
    cwd?: string;
    url?: string;
    headers?: Record<string, string | JsExpr>;
    toolCallTimeoutMs?: number;
    failOnStartupError?: boolean;
    reconnect?: ReconnectConfig;
}
interface McpRow {
    id: string;
    config: McpServerConfig;
    disabled?: boolean;
}
/**
 * 纯函数：把托管区块（含首尾标记行）拼进 home 补丁文本，保留区块外的所有内容。
 *
 * 实现已收进 kit 的 `spliceManagedBlock`（2026-10-19 外部测评 issue #13 第 3 条）：
 * 标记**整行相等**才算边界（值里的多行文本含标记名时不会被误判），根位置上的裸 `[]`
 * 会被换掉而不是追加（CG67 同源），悬空起始标记只重写标记行。这三条此前在本包各写了
 * 一遍、且是子串匹配版本——同一份判据只有 kit 一份实现。
 *
 * 本函数保留原签名（`(text, rows) => string`）是为了不惊动本包已有的用例与调用方。
 */
export declare function spliceManagedBlock(text: string, rows: McpRow[]): string;
/**
 * 保存前的「清空防护」判定：返回拒绝文案，放行则返回 undefined。
 *
 * 为什么需要：`/servers/save` 是**整表替换**语义——请求体里的 servers 就是全部内容，
 * 空数组等于把托管区块清空。卡片若因启动竞态、陈旧快照或任何自动化拿到空列表，
 * 一次保存就会把已配置的服务器全部抹掉，而文件里不会留下任何痕迹（实测踩过）。
 *
 * 因此空列表必须由调用方显式确认（`clearAll: true`）；卡片只在用户明确删光时才带。
 * 区块本来就是空的（existing === 0）不构成破坏，放行——免得把「保存一张空卡片」
 * 变成一个没必要的报错。
 */
export declare function emptyServersRejection(incoming: number, existing: number, clearAll: unknown): string | undefined;
/**
 * 提交前的「外部重名」检测：serverName 被**本插件之外**的 mcp-client 实例占用时拒绝。
 *
 * 为什么必须拦：mcp-client 的工具按 serverName 命名（`mcp__<serverName>__<tool>`），
 * 同名两个实例抢同一套工具名，其中一个必然加载失败——而在文件里看不出谁失败了，
 * 用户只会看到「加进去了但不生效」。外部实例（例如 Codegraph 插件自管的 codegraph）
 * 不在本插件的托管区块里，本插件也不该把别人的行挪进自己的区块，所以正确动作是拒绝。
 *
 * **只拦「新引入」的重复**：某条已保存的行如果本来就带着这个外部同名实例（历史遗留），
 * 放行——否则用户连别的字段都改不了，编辑另一行也会被这条历史问题挡住。用户真要清理，
 * 应当删除或改名那条行本身。
 *
 * @param incoming 本次提交的行（id + serverName）。
 * @param existing 当前文件里已保存的行（用于识别「本来就存在」的重复）。
 * @param external 本插件之外的 mcp-client 实例（`externalMcpEntries` 的结果）。
 */
export declare function externalNameRejection(incoming: Array<{
    id: string;
    serverName: string;
}>, existing: Array<{
    id: string;
    serverName: string;
}>, external: Array<{
    id: string;
    serverName: string;
}>): string | undefined;
/**
 * 纯函数：从托管行里挑出与本插件之外的 mcp-client 实例**真正重名**的那些行。
 *
 * 与 `externalMcpEntries()` 的分工（issue #5 的核心）：
 * - `externalMcpEntries()` = 「外部实例清单」，**不与托管行求交集**，供保存护栏 / 外部占用名单用；
 * - 本函数 = 上面这份清单与托管行的**交集**，即 DTO 里 `servers[].conflict === true` 的行，
 *   只有它才配叫「冲突」（同名两个实例抢同一套 `mcp__<serverName>__*` 工具名，其中一个必然加载失败）。
 *
 * 一条都不相交时返回空数组 ⇒ 界面不该出现任何冲突横幅（这正是它要修的行为）。
 */
export declare function externalNameClashes(rows: Array<{
    id: string;
    serverName: string;
}>, external: Array<{
    id: string;
    serverName: string;
}>): Array<{
    id: string;
    serverName: string;
}>;
/** 把所有 `mcp__*` 工具归到「本插件接进档位裁剪」的同一族（见 apply 里的 attachTierRestrict）。 */
export declare const MCP_TIER_PREFIXES: readonly string[];
/**
 * 本插件自己注册的两个 agent 工具（`agentToolLoading: 'on-demand'` 才有）。
 *
 * **必须 `export`** 并单独成表：档位接线要把它们一起交给 `attachTierRestrict`（否则受限档下
 * 仍会露出它们——而 `mcp_load` 会改变工具面，等于把「只能看」的档位又开了一条装配通道）。
 * 它们是**前缀之外**的独立名字：`mcp_servers` / `mcp_load` 都不以 `mcp__` 开头，不会被那条
 * 宿主族前缀顺带覆盖，所以必须逐个列进 `prefixes`。
 */
export declare const MCP_OWN_TOOL_NAMES: readonly string[];
export declare function buildServersDto(ctx: Context): {
    servers: Array<Record<string, unknown>>;
    fileError?: string;
    patchFile: string;
    /** 托管行里**真正**与外部实例重名的那些行（横幅只该渲染这份）。 */
    conflicts: Array<{
        id: string;
        serverName: string;
    }>;
    /** 本插件之外的 mcp-client 实例清单（保存护栏与「外部占用」信息条用；与 conflicts 不是一回事）。 */
    externalServers: Array<{
        id: string;
        serverName: string;
    }>;
    /** 成本可见性的阈值（见 `AGENT_TOOL_BUDGET`）：卡片拿它跟已知工具数合计比较，自己不留第二份。 */
    toolBudget: number;
};
interface ProbeResult {
    ok: boolean;
    transport: 'stdio' | 'streamable-http';
    durationMs: number;
    protocolVersion?: string;
    serverInfo?: {
        name?: string;
        version?: string;
    };
    tools?: Array<{
        name: string;
        description?: string;
    }>;
    toolsCount: number;
    error?: string;
}
/**
 * 连接测试入口（`POST /api/dsh-mcp/test` 走这里）。
 *
 * 导出只为单测：探测的两条关键判据（401/403 定性、凭据未注入自检）都在**网络之前**，
 * 用用例钉住比真机截图稳定。运行期它只被路由调用。
 */
export declare function testServer(rawConfig: unknown): Promise<ProbeResult>;
/**
 * 重启的等待预算（毫秒）。与 `PROBE_TIMEOUT_MS` 同款写法、同一个数级。
 *
 * **超时不算失败**：`fiber.restart()` 内部是 `await fiber.await()`（cordis 4.1.0），MCP 连接
 * 建立慢（stdio 冷启动、远端不可达）时它可能远超任何合理的前端等待窗口。此刻重启**已经发出**、
 * 只是还没有结论——报 500 会把一个进行中的动作说成失败，用户重试还会再叠一次重启。所以超时走
 * 200 + `settled:false` + `warning`，由卡片说「重启已发出，连接仍在建立中」。
 *
 * 刻意 `export`：它是「等多久算还在建立」这条对外承诺的取值，README 引用它时
 * `scripts/check-readme-facts.mjs` 才收得到——该闸门只认 `export const`，私有常量会让引用
 * 恒绿（同 `AGENT_TOOL_BUDGET` 的理由）。
 */
export declare const RESTART_TIMEOUT_MS = 25000;
/**
 * 等待工具注册的轮询间隔（毫秒）。
 *
 * 纯内存读注册表，所以这个数只影响「多久发现一次」，与网络无关；50ms 让能连上的行走得跟
 * 「点下去就回来了」一样快，又不至于把事件循环占满。
 */
export declare const RESTART_POLL_INTERVAL_MS = 50;
/**
 * 等工具注册的**上限**（毫秒）。与 `RESTART_TIMEOUT_MS` 分开是因为它们回答不同的问题：
 *
 * - `RESTART_TIMEOUT_MS`：`restart()` 本身（rebuild fiber + 重跑 apply）最长等多久；
 * - 本值：apply 跑完之后，**再花多久认命说「它还是没连上」**。
 *
 * 为什么不是「等满预算」：一条连不上的行（人不在内网）**永远**不会有工具回来，等满任何预算
 * 都只是让用户对着按钮干等。远端的失败通常在几秒内就有结论（TLS/DNS 立刻失败，或 SDK 自己的
 * 请求超时），所以这个值刻意小于 `RESTART_TIMEOUT_MS`——宁可早一点说「仍未连上，再点一次」，
 * 也不要让人等半分钟。工具**一回来就立即返回**，所以能连上的行感觉不到这个上限。
 */
export declare const RESTART_CONNECT_WAIT_MS = 8000;
/** 重启的结果：成功（`settled` = 有没有在预算内给出结论）或拒绝（带该回出去的 HTTP 状态）。 */
export type RestartManagedResult = {
    ok: true;
    /** `restart()` 有没有在预算内跑完（apply 是否返回）。 */
    settled: boolean;
    /**
     * 该行**重启之后的真实连接态**，判据是工具注册表而不是 `restart()` 的返回：
     * `connected` = 工具的真的回来了；`pending` = 重启已发出但预算内没等到工具。
     * 连不上的行（例如人不在内网）**永远是 `pending`**——这正是要区分的那件事。
     */
    connection: 'connected' | 'pending';
    /** 重启后该行在注册表里的工具数（`connection === 'connected'` 时必然 > 0）。 */
    toolCount: number;
} | {
    ok: false;
    status: 400 | 500;
    error: string;
};
/**
 * 重启一**行**托管实例（纯函数：判据全在这里，路由只负责把 status/error 写出去）。
 *
 * 拒绝分支按契约顺序（**先**看这是不是本卡的行，再看实例状态——否则一个拼错的 id 会被报成
 * 「还没起来」，用户永远查不到真相）：
 * 1. 400 非法 id（`ROW_ID_RE`，与保存路由同一条判据）；
 * 2. 400 不在托管区块里（`readManagedRows()`，区块解析失败时自然也是这一支）；
 * 3. 400 该行已停用（重启一条停用行等于绕过用户的「关掉」）；
 * 4. 400 loader 里找不到这条 entry（刚保存、热加载还没跑完就是这个形状）；
 * 5. 400 `fiber` 缺失或 `uid === null`（cordis 用 uid 被清表示 fiber 已 dispose /
 *    还没起来——这时 `restart()` 只会 `assertActive()` 抛 INACTIVE_EFFECT，不要调它）；
 * 6. 500 `fiber.restart()` 抛出（含「fiber 上没有 restart」这种宿主版本不符）。
 *
 * **成功 ≠ 连上了**（2026-11-18 真机事故）：`fiber.restart()` 的 `await` 只等到「apply 跑完」，
 * 而 mcp-client 的 apply 在连不上时**照常 resolve**（`failOnStartupError` 默认 false）。于是
 * 「重启成功了」与「工具一个都没回来」可以同时为真——用户看到的就是一条「已重连」提示配一个
 * 「未连接 / 工具 0」的行。所以这里在预算内**等真实的工具注册**：拿到 ≥1 个工具才算 `connected`；
 * 等不到就如实报 `pending`，由卡片说「仍未连上」而不是「已重连」。
 *
 * @param timeoutMs 等待预算，默认 {@link RESTART_TIMEOUT_MS}；单测注入小值来打超时那条分支。
 * @returns `connection` 是**判据而不是猜测**：`connected` 仅当该行的工具的真的回到了注册表。
 */
export declare function restartManagedEntry(ctx: Context, id: string, timeoutMs?: number, connectWaitMs?: number): Promise<RestartManagedResult>;
interface ReqLike {
    method?: string;
    url?: string;
    headers: Record<string, string | string[] | undefined>;
    socket: {
        remoteAddress?: string;
    };
}
interface ResLike {
    writeHead(status: number, headers?: Record<string, string>): void;
    end(body?: string): void;
}
/** 拒绝日志的最小形状（宿主 logger 结构上兼容）。 */
interface RouteLogger {
    warn(message: string): void;
}
/**
 * 路由闸门（导出仅供单测，与 tty 的 `gateRoute` 同思路）：**回环围栏（加固档，docker D31）
 * + 方法闸门 + 写操作的同源证明（docker D32，含桌面壳例外 D139）**。三条路由共用它，
 * 所以「拒绝分支」只有一份，负例也只测这一份。
 *
 * 顺序与 docker 一致：先回环 → 再方法 → 最后同源证明。跨站 GET 打到写路由仍是 405
 * （方法不对就说方法不对），不会因为「没带证明」而多给一条信息。
 *
 * 本插件的 POST 有三条：`/servers/save`（写 home 补丁文件）、`/test`（起子进程探活）与
 * `/restart`（重跑一条托管 entry），都是货真价实的变更端点；GET `/servers` 只读，维持 loopback-only。
 */
export declare function routeGate(req: ReqLike, res: ResLike, method: string, logger?: RouteLogger): Promise<boolean>;
export declare function apply(ctx: Context, rawConfig?: Config): void;
export {};
