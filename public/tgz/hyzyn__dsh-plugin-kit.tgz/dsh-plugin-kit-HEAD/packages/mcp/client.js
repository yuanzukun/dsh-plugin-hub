/* eslint-disable */
/**
 * @hyzyn/dsh-mcp — 浏览器半体：官方插件配置里的「MCP 服务器配置」卡片。
 * 通过核心 slots 服务注册到 settings.plugin.item 插槽（与官方终端 / Agent 循环 /
 * 网页搜索卡片同级），不再占用侧边栏、不做全屏面板接管。
 * 纯 DOM 渲染（React 只承担卡片外壳与展开状态），无构建步骤，
 * 宿主经 /plugins/@hyzyn/dsh-mcp/client.js 提供。
 */
window.__ModuleLoader__.load({
  id: '@hyzyn/dsh-mcp',
  factory: (require) => {
    const exports = {}

    const React = require('react')
    const { jsx, jsxs } = require('react/jsx-runtime')

    /* ================================ CSS ================================ */

    const CSS = [
      // 设置插件卡片外壳（与官方 PluginCard 一致的轮廓）
      '.mX_pageHost{display:block}',
      '.mX_pluginCard{list-style:none;border:.5px solid var(--dsw-alias-settings-card-stroke);background:var(--dsw-alias-settings-card-fill);border-radius:var(--dsw-radius-xl);transition:border-color .16s,background .16s}',
      '.mX_pluginCard:hover{border-color:var(--dsw-alias-label-dimmed)}',
      '.mX_pluginCardOpen{background:var(--dsw-alias-bg-layer-1);border-color:var(--dsw-alias-label-dimmed)}',
      '.mX_cardHeader{appearance:none;width:100%;color:inherit;font:inherit;text-align:left;cursor:pointer;background:0 0;border:0;border-radius:var(--dsw-radius-xl);display:flex;align-items:center;gap:12px;padding:14px 16px}',
      '.mX_cardHeader:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:-2px}',
      '.mX_cardHeadText{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}',
      // 卡片标题：本文件另有一条 .mX_cardName（面板内实体名）——同选择器后者整条覆盖前者，
      // 那两条 14px/600 与 13.5px/700 都是死声明；合并为官方 cardTitle 角色 14px/500/22px。
      '.mX_cardName{color:var(--dsw-alias-label-primary);font-size:14px;font-weight:500;line-height:22px}',
      '.dshkit_badge{flex:none;margin-left:auto;padding:1px 8px;border-radius:999px;corner-shape:round;font-size:11px;font-weight:600;line-height:16px;letter-spacing:.02em;color:var(--dsw-alias-label-dimmed);background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1)}',
      '.mX_cardDescription{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px}',
      '.mX_chevron{flex:none;color:var(--dsw-alias-label-tertiary);transition:transform .16s}',
      '.mX_pluginCardOpen .mX_chevron{transform:rotate(180deg)}',
      '.mX_cardBody{padding:2px 16px 16px}',
      // 面板
      '.mX_panel{display:flex;flex-direction:column;gap:12px;color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-family);box-sizing:border-box}',
      '.mX_panelHeader{display:flex;align-items:center;gap:10px;flex:none}',
      '.mX_panelTitle{margin:0;font-size:15px;font-weight:500;line-height:22px;white-space:nowrap;flex:1}',
      // 11.5px 的提示/次级正文上收到官方 hint 的 12/18（10–11px 只留给徽标与小 tag）。
      '.mX_subtitle{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;font-family:var(--ds-font-family-code);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:320px}',
      '.mX_toolbar{display:flex;align-items:center;gap:8px;flex:none}',
      '.mX_toolbarSpacer{flex:1}',
      // 按钮族对齐宿主 Button primitives：本包属 H28 档（size="sm"），故统一 H28/R8/12px/18px/padding 0 10px，
      // 填充与描边两个变体逐项同尺寸；主按钮底色是 button-primary-fill（button-info 一族是强调蓝，非按钮填充）。
      '.mX_btn{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:4px;height:28px;padding:0 10px;border:none;border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground);font-family:inherit;font-size:12px;line-height:18px;white-space:nowrap;cursor:pointer}',
      '.mX_btn:hover:not(:disabled){background:var(--dsw-alias-button-primary-hover)}',
      '.mX_btn:disabled{opacity:.4;cursor:not-allowed}',
      '.mX_btn:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary))}',
      '.mX_btnGhost{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:4px;height:28px;padding:0 10px;border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-sm);background:transparent;color:var(--dsw-alias-label-primary);font-family:inherit;font-size:12px;line-height:18px;white-space:nowrap;cursor:pointer}',
      '.mX_btnGhost:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}',
      '.mX_btnGhost:active:not(:disabled){background:var(--dsw-alias-interactive-bg-active)}',
      '.mX_btnGhost:disabled{opacity:.4;cursor:not-allowed}',
      '.mX_btnGhost:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary))}',
      '.mX_btnDanger{color:var(--dsw-alias-state-error-primary);border-color:color-mix(in srgb,var(--dsw-alias-state-error-primary) 30%,transparent)}',
      '.mX_btnDanger:hover:not(:disabled){background:color-mix(in srgb,var(--dsw-alias-state-error-primary) 8%,transparent)}',
      '.mX_linkBtn{color:var(--dsw-alias-link);background:0 0;border:none;padding:0;font-size:12px;line-height:18px;font-weight:500;cursor:pointer;white-space:nowrap;text-decoration:none}',
      '.mX_linkBtn:hover:not(:disabled){text-decoration:underline dotted;text-underline-offset:3px}',
      '.mX_list{display:flex;flex-direction:column;gap:8px;max-height:420px;overflow-y:auto}',
      '.mX_card{background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-md);padding:10px 12px;display:flex;flex-direction:column;gap:6px}',
      '.mX_cardRow{display:flex;align-items:center;gap:8px;flex-wrap:wrap}',
      '.mX_cardSummary{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px;font-family:var(--ds-font-family-code);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;min-width:0}',
      '.mX_cardActions{display:flex;align-items:center;gap:6px;margin-left:auto}',
      // 卡片内的问题行（目前只有「已挂载但没连上」一种）：与摘要之间加一道分隔，
      // 文字保持次要色（长句用警告色会吵），靠徽标与左边的停用按钮传达该干什么。
      '.mX_cardWarn{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap;border-top:.5px solid var(--dsw-alias-border-l1);margin-top:2px;padding-top:8px;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary)}',
      '.mX_cardWarnText{flex:1;min-width:0}',
      '.mX_badge{display:inline-block;border:.5px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);border-radius:999px;corner-shape:round;padding:1px 8px;font-size:11px;line-height:16px;white-space:nowrap}',
      '.mX_badge[data-kind=stdio]{color:var(--dsw-alias-state-business-primary);border-color:var(--dsw-alias-state-business-primary)}',
      '.mX_badge[data-kind=http]{color:var(--dsw-alias-state-business-primary);border-color:var(--dsw-alias-state-business-primary)}',
      '.mX_badge[data-status=ok]{color:var(--dsw-alias-state-success-primary);border-color:var(--dsw-alias-state-success-primary)}',
      '.mX_badge[data-status=error]{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}',
      '.mX_badge[data-status=warn]{color:var(--dsw-alias-state-warn-primary);border-color:var(--dsw-alias-state-warn-primary)}',
      '.mX_banner{border:.5px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);border-radius:8px;padding:8px 12px;font-size:12.5px;line-height:18px;overflow-wrap:anywhere;flex:none}',
      '.mX_banner[data-kind=ok]{color:var(--dsw-alias-state-success-primary);border-color:var(--dsw-alias-state-success-primary)}',
      '.mX_banner[data-kind=error]{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}',
      '.mX_banner[data-kind=info]{color:var(--dsw-alias-state-business-primary);border-color:var(--dsw-alias-state-business-primary)}',
      '.mX_banner[data-kind=warn]{color:var(--dsw-alias-state-warn-primary);border-color:var(--dsw-alias-state-warn-primary)}',
      // 「外部占用」是**信息**、不是告警：做成列表下方的紧凑脚注（一行小字 + 名字 chip），
      // 尺寸与位置都与真冲突的黄色横幅（.mX_banner[data-kind=warn]）明显拉开。
      '.mX_note{display:flex;align-items:center;flex-wrap:wrap;gap:6px;flex:none;background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1);border-radius:8px;padding:6px 10px;font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary)}',
      '.mX_noteGlyph{flex:none;width:13px;height:13px;border-radius:50%;corner-shape:round;border:1px solid var(--dsw-alias-state-business-primary);color:var(--dsw-alias-state-business-primary);font-size:9px;font-weight:600;font-style:normal;line-height:11px;text-align:center}',
      '.mX_noteName{font-family:var(--ds-font-family-code);font-size:11px;line-height:16px;color:var(--dsw-alias-label-secondary);background:var(--dsw-alias-bg-layer-3);border:.5px solid var(--dsw-alias-border-l2);border-radius:var(--dsw-radius-sm);padding:0 6px}',
      '.mX_empty,.mX_loading{text-align:center;color:var(--dsw-alias-label-tertiary);padding:24px 12px;font-size:12.5px;line-height:18px}',
      '.mX_modalBackdrop{position:absolute;inset:0;z-index:70;background:var(--dsw-alias-bg-mask-1);display:flex;justify-content:center;align-items:flex-start;padding:24px 12px;overflow-y:auto}',
      '.mX_modal{background:var(--dsw-alias-bg-base);border:0;width:min(640px,100%);max-width:100%;box-shadow:var(--dsw-elevation-prominent);color:var(--dsw-alias-label-primary);border-radius:var(--dsw-radius-lg);display:flex;flex-direction:column;gap:12px;padding:18px;box-sizing:border-box}',
      '.mX_modalTitle{margin:0;font-size:15px;font-weight:600;line-height:22px}',
      '.mX_modalBody{display:flex;flex-direction:column;gap:10px}',
      '.mX_modalFooter{display:flex;justify-content:flex-end;align-items:center;gap:10px;margin-top:4px}',
      '.mX_formRow{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px 12px}',
      '.mX_field{display:flex;flex-direction:column;gap:5px}',
      '.mX_fieldLabel{color:var(--dsw-alias-label-secondary);font-size:12px;font-weight:500;line-height:18px}',
      // 输入档对齐宿主 settings-form 的 .input：显式 H34 + --dsw-radius-md（原来靠 7px 10px 撑高、
      // 圆角写死 8px）。高度必须显式：<select> 复用同一个类时 Chrome 不算继承的 line-height
      // （内容高实测 16px），没有高度就会比同排输入框矮 2px；textarea 由下面的 .mX_textarea 覆盖回 auto。
      '.mX_input{box-sizing:border-box;width:100%;height:34px;padding:0 12px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-3);border:.5px solid var(--dsw-alias-border-l4);border-radius:var(--dsw-radius-md);outline:none;font-family:inherit;font-size:13px;line-height:1.5}',
      '.mX_input:focus{border-color:var(--dsw-alias-state-business-primary)}',
      '.mX_input::placeholder{color:var(--dsw-alias-label-dimmed)}',
      // 多行 textarea 不吃输入档的 H34（官方：textarea 用 height:auto + min-height）与横向内边距。
      '.mX_textarea{height:auto;min-height:64px;padding:8px 12px;resize:vertical;font-family:var(--ds-font-family-code);font-size:12px;line-height:18px}',
      '.mX_hint{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px}',
      // 字段级实时校验（serverName 撞名）：必须排在 `.mX_input:focus` **之后**，
      // 否则聚焦时那抹主题蓝会盖掉标红（两条选择器权重相同，比的是顺序）。
      '.mX_input[data-invalid]{border-color:var(--dsw-alias-state-error-primary)}',
      '.mX_fieldError{color:var(--dsw-alias-state-error-primary);font-size:12px;line-height:18px;margin:0;white-space:pre-wrap}',
      '.mX_fieldError:empty{display:none}',
      '.mX_radioRow{display:flex;align-items:center;gap:16px}',
      '.mX_radioLabel{display:inline-flex;align-items:center;gap:6px;font-size:13px;line-height:20px;cursor:pointer;color:var(--dsw-alias-label-primary)}',
      '.mX_checkRow{display:flex;align-items:center;gap:8px;font-size:13px;line-height:20px;color:var(--dsw-alias-label-primary);cursor:pointer}',
      // 原生复选框按宿主 Checkbox 写：16×16 + accent-color 走中性 brand（浅色近黑）。
      // 用强调蓝 state-business-primary（#4176e6）就是浏览器默认蓝勾那种错——那是状态与徽标的颜色。
      '.mX_checkRow input[type=checkbox]{width:16px;height:16px;margin:0;flex:none;cursor:pointer;accent-color:var(--dsw-alias-brand-primary)}',
      '.mX_checkRow input[type=checkbox]:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:2px}',
      '.mX_formError{color:var(--dsw-alias-state-error-primary);font-size:12px;line-height:18px;margin:0;white-space:pre-wrap}',
      '.mX_toolWrap{border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-md);flex:none;overflow:hidden}',
      '.mX_toolHeader{background:var(--dsw-alias-bg-layer-2);border-bottom:.5px solid var(--dsw-alias-border-l1);padding:8px 10px;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);display:flex;gap:12px;flex-wrap:wrap}',
      '.mX_toolList{max-height:220px;overflow-y:auto;padding:4px 0}',
      '.mX_toolItem{padding:5px 10px;font-size:12px;line-height:18px;display:flex;flex-direction:column;gap:2px;border-bottom:.5px solid var(--dsw-alias-border-l2)}',
      '.mX_toolItem:last-child{border-bottom:none}',
      '.mX_toolName{font-family:var(--ds-font-family-code);color:var(--dsw-alias-state-business-primary)}',
      '.mX_toolDesc{color:var(--dsw-alias-label-tertiary)}',
      '.mX_spinner{border:2px solid var(--dsw-alias-state-business-primary);border-top-color:transparent;border-radius:50%;corner-shape:round;width:11px;height:11px;display:inline-block;flex:none;vertical-align:-1px;animation:mXSpin .8s linear infinite}',
      '@keyframes mXSpin{to{transform:rotate(360deg)}}',
      '.mX_toast{position:fixed;left:50%;bottom:36px;transform:translateX(-50%);z-index:200;background:var(--dsw-alias-bg-layer-2);border:0;color:var(--dsw-alias-label-primary);border-radius:var(--dsw-radius-md);padding:9px 16px;font-size:13px;line-height:20px;box-shadow:var(--dsw-elevation-prominent);max-width:70vw}',
      '.mX_toast[data-kind=ok]{color:var(--dsw-alias-state-success-primary);box-shadow:var(--dsw-elevation-prominent), inset 0 0 0 .5px var(--dsw-alias-state-success-primary)}',
      '.mX_toast[data-kind=error]{color:var(--dsw-alias-state-error-primary);box-shadow:var(--dsw-elevation-prominent), inset 0 0 0 .5px var(--dsw-alias-state-error-primary)}',
      '.mX_mono{font-family:var(--ds-font-family-code)}',
    ].join('\n')

    let styleEl
    function ensureStyle() {
      if (document.getElementById('dsh-mcp-style')) return
      styleEl = document.createElement('style')
      styleEl.id = 'dsh-mcp-style'
      styleEl.textContent = CSS
      document.head.appendChild(styleEl)
    }

    /* ================================ 基础工具 ================================ */

    const ESC_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }
    const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ESC_MAP[c])

    /* ================================ 国际化 ================================ */

    /*
     * 界面文案走宿主 `@deepseek-ai/dsh-client-locale` 的目录（方案见 docs/i18n.md）。
     * 下面这一对目录由 `scripts/check-i18n.mjs` 静态校验：键集必须与英文一一对应、
     * `{name}` 占位符两边一致、代码里 `t('…')` 用到的键必须在这里有定义。
     * 目录**内联在 client.js 里**（不是 client-src/）：本包没有构建步骤，client.js 就是源；
     * 而且一旦凭空建出 client-src/，仓库级「宿主地址来源」静态规则会停止覆盖 client.js。
     *
     * 面板 DOM 是**手写 HTML 字符串**拼的，所以带 `<` / `&` 的文案一律用 `esc(t(...))`
     * 包住（如 `mcp__<serverName>__<tool>`）：原先 `&lt;` 是写死在标记里的，拆成目录后
     * 必须由 esc 负责转义，否则会被 innerHTML 当成标签。
     */
    /* ==== dsh-i18n:begin ==== */
    const I18N_NS = 'mcp'
    const I18N_ZH = {
      'card.name': 'MCP 服务器配置',
      'card.desc': '管理 MCP 服务器：stdio 本地进程或 streamable-http 远程服务；保存后热加载为 mcp__<server>__<tool> 工具，无需重启。',
      'panel.title': 'MCP 服务器',
      'btn.refresh': '刷新',
      'btn.addServer': '+ 添加服务器',
      'btn.test': '测试',
      'btn.edit': '编辑',
      'btn.enable': '启用',
      'btn.disable': '停用',
      'btn.remove': '删除',
      'btn.cancel': '取消',
      'btn.testConnection': '测试连接',
      'btn.save': '保存',
      'list.statusActive': '运行中',
      'list.statusDisabled': '已停用',
      'list.statusError': '错误',
      'list.statusLoading': '加载中',
      'list.statusNotLoaded': '未加载',
      'list.conflict': 'serverName 冲突',
      'list.notConnected': '未连接',
      'list.notConnectedDetail': '这行当前没有注册任何工具。每次启动都要为它等一次连接尝试（地址不可达约 10 秒、能连上但不回应最长 60 秒），会拖慢启动完成；用不上时建议停用。',
      'panel.editorCreate': '添加 MCP 服务器',
      'panel.editorEdit': '编辑 MCP 服务器',
      'panel.fieldName': 'serverName（模型侧命名空间，[A-Za-z0-9_-] 1~32 字符）',
      'placeholder.serverName': '例如 github',
      'panel.fieldTransport': '传输方式',
      'panel.transportStdio': ' stdio（本地进程）',
      'panel.transportHttp': ' streamable-http（远程）',
      'panel.fieldCommand': 'command（可执行文件）',
      'panel.fieldCwd': 'cwd（工作目录，可选；目录需已存在）',
      'panel.fieldArgs': 'args（JSON 数组，或每行一个参数）',
      'panel.fieldEnv': 'env（每行 KEY=VALUE；js: 开头为 JS 表达式）',
      'panel.fieldUrl': 'url（MCP 端点）',
      'panel.fieldHeaders': 'headers（每行 KEY=VALUE；js: 开头为 JS 表达式，模板串可引用环境变量）',
      'panel.fieldFailOnStartupError': ' failOnStartupError（启动失败即拒绝加载）',
      'panel.fieldEnabled': ' 启用',
      'panel.fieldReconnect': ' 断线自动重连',
      'panel.hint': 'env/headers 的 VALUE 以 js: 开头会原样写入 !!js 表达式（例如 js:process.env.GITHUB_TOKEN）。保存后服务器会热加载，工具名形如 mcp__<serverName>__<tool>。',
      'banner.fileError': '配置区块异常：{error}（保存一次即可修复）',
      'banner.conflicts': '⚠ 以下 serverName 与本插件之外的 mcp-client 实例重名，两个实例会抢同一套工具名 mcp__<serverName>__*，其中一个必然加载失败：{names}',
      'banner.externalOccupied': '以下名字已被本卡片之外的 mcp-client 实例占用，在本卡片内起名请避开：',
      'banner.externalOccupiedHint': '这些行由别的插件自管（不在本卡片的托管区块里），本卡片管不到它们。同名会让两个 mcp-client 实例抢同一套工具名 mcp__<serverName>__*，其中一个必然加载失败；要改名请到对应插件的设置里改。',
      'msg.hotReload': '改动写入 ~/.dsh/cordis.patch.yml 的托管区块后经 HMR 热加载（约 1~2 秒生效）。env/headers 值以 js: 开头会被当作 !!js 表达式（如 js:process.env.GITHUB_TOKEN）。',
      'msg.testConnecting': '正在连接并列出工具…（最长 25 秒）',
      'msg.testOk': '连接成功',
      'msg.testFailed': '连接失败：{error}',
      'msg.metaDuration': '耗时 {ms}ms',
      'msg.metaProtocol': '协议 {version}',
      'msg.metaServer': '服务器 {name}',
      'msg.metaTools': '工具数 {count}',
      'list.loading': '加载中…',
      'list.empty': '还没有配置 MCP 服务器。',
      'list.emptyHint': '点击右上角「+ 添加服务器」开始：stdio 本地进程或 streamable-http 远程服务都支持。',
      'list.emptyReload': '保存后 DSH 会热加载为 mcp__<serverName>__<tool> 工具，无需重启。',
      'list.separator': '、',
      'error.unknown': '未知错误',
      'error.argsNotArray': 'args 必须是 JSON 字符串数组',
      'error.unparsableLine': '无法解析的行：{line}',
      'error.duplicateName': 'serverName 与已有服务器重复：{name}',
      'error.externalClash': 'serverName「{name}」已被本插件之外的 mcp-client 实例占用（{id}）：两个实例会抢同一套工具名，其中一个必然加载失败。该行由别的插件托管，请到对应插件的设置里修改。',
      'msg.saveFailed': '保存失败：{error}',
      'msg.removeFailed': '删除失败：{error}',
      'msg.updateFailed': '更新失败：{error}',
      'msg.saved': '已保存，正在热加载…',
      'msg.deleted': '已删除，正在热卸载…',
      'msg.updated': '已更新，正在热加载…',
      'msg.testOkHint': '连接成功（确认无误后点保存）',
      'msg.testFailedToast': '连接失败',
      'msg.confirmRemoveLast': '确定删除最后一条 MCP 服务器「{name}」？删除后托管区块会清空，其注册的工具会立即被卸载。',
      'msg.confirmRemove': '确定删除 MCP 服务器「{name}」？其注册的工具会立即被卸载。',
    }
    const I18N_EN = {
      'card.name': 'MCP server configuration',
      'card.desc': 'Manage MCP servers: stdio local processes or streamable-http remote services; saving hot-loads them as mcp__<server>__<tool> tools — no restart needed.',
      'panel.title': 'MCP servers',
      'btn.refresh': 'Refresh',
      'btn.addServer': '+ Add server',
      'btn.test': 'Test',
      'btn.edit': 'Edit',
      'btn.enable': 'Enable',
      'btn.disable': 'Disable',
      'btn.remove': 'Remove',
      'btn.cancel': 'Cancel',
      'btn.testConnection': 'Test connection',
      'btn.save': 'Save',
      'list.statusActive': 'Running',
      'list.statusDisabled': 'Disabled',
      'list.statusError': 'Error',
      'list.statusLoading': 'Loading',
      'list.statusNotLoaded': 'Not loaded',
      'list.conflict': 'serverName conflict',
      'list.notConnected': 'Not connected',
      'list.notConnectedDetail': 'This row currently registers no tools. Every boot waits once for its connection attempt (about 10s when the address is unreachable, up to 60s when it is reachable but unresponsive), which delays startup — disable it while you do not need it.',
      'panel.editorCreate': 'Add MCP server',
      'panel.editorEdit': 'Edit MCP server',
      'panel.fieldName': 'serverName (model-side namespace, [A-Za-z0-9_-], 1–32 chars)',
      'placeholder.serverName': 'e.g. github',
      'panel.fieldTransport': 'Transport',
      'panel.transportStdio': ' stdio (local process)',
      'panel.transportHttp': ' streamable-http (remote)',
      'panel.fieldCommand': 'command (executable)',
      'panel.fieldCwd': 'cwd (working directory, optional; the directory must already exist)',
      'panel.fieldArgs': 'args (JSON array, or one argument per line)',
      'panel.fieldEnv': 'env (KEY=VALUE per line; a js: prefix is a JS expression)',
      'panel.fieldUrl': 'url (MCP endpoint)',
      'panel.fieldHeaders': 'headers (KEY=VALUE per line; a js: prefix is a JS expression, templates may reference env vars)',
      'panel.fieldFailOnStartupError': ' failOnStartupError (refuse to load when startup fails)',
      'panel.fieldEnabled': ' Enabled',
      'panel.fieldReconnect': ' Reconnect automatically after a drop',
      'panel.hint': 'An env/headers VALUE starting with js: is written as a !!js expression verbatim (e.g. js:process.env.GITHUB_TOKEN). Saving hot-loads the server; tool names look like mcp__<serverName>__<tool>.',
      'banner.fileError': 'Malformed configuration block: {error} (saving once repairs it)',
      'banner.conflicts': '⚠ These serverNames clash with mcp-client instances outside this plugin — both would claim the same tool names mcp__<serverName>__*, and one of them is bound to fail loading: {names}',
      'banner.externalOccupied': 'Already taken by mcp-client instances outside this card — avoid these names here:',
      'banner.externalOccupiedHint': 'These rows are managed by other plugins (they live outside this card’s managed block), so this card cannot change them. A same-named server would make two mcp-client instances claim the same mcp__<serverName>__* tool names and one of them is bound to fail loading; rename it in that plugin’s settings instead.',
      'msg.hotReload': 'Changes are written to the managed block of ~/.dsh/cordis.patch.yml and hot-loaded via HMR (effective in about 1–2 seconds). An env/headers value starting with js: is treated as a !!js expression (e.g. js:process.env.GITHUB_TOKEN).',
      'msg.testConnecting': 'Connecting and listing tools… (up to 25 seconds)',
      'msg.testOk': 'Connected',
      'msg.testFailed': 'Connection failed: {error}',
      'msg.metaDuration': 'took {ms}ms',
      'msg.metaProtocol': 'protocol {version}',
      'msg.metaServer': 'server {name}',
      'msg.metaTools': '{count} tools',
      'list.loading': 'Loading…',
      'list.empty': 'No MCP servers configured yet.',
      'list.emptyHint': 'Click “+ Add server” in the top right to start: both stdio local processes and streamable-http services are supported.',
      'list.emptyReload': 'After saving, DSH hot-loads it as mcp__<serverName>__<tool> tools — no restart needed.',
      'list.separator': ', ',
      'error.unknown': 'unknown error',
      'error.argsNotArray': 'args must be a JSON array of strings',
      'error.unparsableLine': 'Unparsable line: {line}',
      'error.duplicateName': 'serverName already exists: {name}',
      'error.externalClash': 'serverName “{name}” is already taken by an mcp-client instance outside this plugin ({id}): the two instances would fight over the same tool names and one of them is bound to fail loading. That row is managed by another plugin — change it in that plugin’s settings.',
      'msg.saveFailed': 'Could not save: {error}',
      'msg.removeFailed': 'Could not remove: {error}',
      'msg.updateFailed': 'Could not update: {error}',
      'msg.saved': 'Saved, hot-loading…',
      'msg.deleted': 'Removed, hot-unloading…',
      'msg.updated': 'Updated, hot-loading…',
      'msg.testOkHint': 'Connected (click Save once it looks right)',
      'msg.testFailedToast': 'Connection failed',
      'msg.confirmRemoveLast': 'Remove the last MCP server “{name}”? The managed block will be emptied and its tools unloaded immediately.',
      'msg.confirmRemove': 'Remove MCP server “{name}”? Its tools will be unloaded immediately.',
    }
    /* ==== dsh-i18n:end ==== */

    /** 占位符替换：`{name}` → params.name（缺参留空，不抛错——文案不该打死界面）。 */
    function i18nFormat(text, params) {
      if (params === undefined) return text
      return String(text).replace(/\{(\w+)\}/g, (_match, name) => (params[name] === undefined ? '' : String(params[name])))
    }

    /** 中文兜底：老宿主（DSH ≤0.1.5）没有 locale 服务时，界面不能变成一串键名。 */
    function i18nFallback(key, params) {
      return i18nFormat(I18N_ZH[key] !== undefined ? I18N_ZH[key] : key, params)
    }

    let t = i18nFallback

    /**
     * 注册目录并绑定翻译函数。**动态 inject**：老宿主上回调永不触发、`t` 保持中文兜底；
     * 写成静态 `inject: ['locale']` 会让整张卡片在老宿主上根本不挂。
     */
    function installI18n(ctx) {
      ctx.inject(['locale'], (i18nCtx) => {
        const disposeZh = i18nCtx.locale.register(I18N_NS, 'zh', I18N_ZH)
        const disposeEn = i18nCtx.locale.register(I18N_NS, 'en', I18N_EN)
        t = i18nCtx.locale.bind(I18N_NS)
        return () => {
          disposeEn()
          disposeZh()
          t = i18nFallback
        }
      })
    }

    /* ================================ API ================================ */

    const API = {
      list: '/api/dsh-mcp/servers',
      save: '/api/dsh-mcp/servers/save',
      test: '/api/dsh-mcp/test',
    }

    async function apiRequest(path, options) {
      const res = await fetch(path, options)
      let body = {}
      try {
        body = await res.json()
      } catch {
        /* 非 JSON 响应 */
      }
      if (!res.ok) {
        const err = new Error((body && body.error) || ('HTTP ' + res.status))
        err.code = res.status
        throw err
      }
      return body
    }

    const apiList = () => apiRequest(API.list)
    // clearAll 只在「用户明确删光」时带上：宿主对「空列表且无该标记」的保存会返回 400，
    // 避免启动竞态 / 陈旧卡片拿到空列表时把已配置的服务器静默清空。
    const apiSave = (servers, options) => apiRequest(API.save, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ servers, ...(options !== undefined && options.clearAll === true ? { clearAll: true } : {}) }),
    })
    const apiTest = (config) => apiRequest(API.test, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ config }),
    })

    /* ================================ 面板状态 ================================ */

    const state = {
      servers: [],
      // 真正重名的托管行（横幅只渲染这份）；外部实例清单另存 externalServers，两者别混用。
      conflicts: [],
      externalServers: [],
      fileError: '',
      patchFile: '',
      loading: false,
      busy: false,
      toast: '',
      toastKind: 'info',
      editor: null,
      test: null,
    }

    let toastTimer
    function toast(message, kind) {
      state.toast = message
      state.toastKind = kind || 'info'
      renderToast()
      clearTimeout(toastTimer)
      toastTimer = setTimeout(() => {
        state.toast = ''
        renderToast()
      }, 3200)
    }

    /* ================================ 渲染：主视图 ================================ */

    /*
     * 状态文案**必须走 getter**：`t()` 在模块加载时求值等于把当前语言冻住——
     * `installI18n(ctx)` 要等 apply 才跑（那时已经晚了），语言切换后这里会永远停在
     * 首次求值的结果上。
     */
    const STATUS_TEXT = {
      get active() { return t('list.statusActive') },
      get disabled() { return t('list.statusDisabled') },
      get error() { return t('list.statusError') },
      get loading() { return t('list.statusLoading') },
      get 'not-loaded'() { return t('list.statusNotLoaded') },
    }
    const STATUS_KIND = { active: 'ok', disabled: '', error: 'error', loading: 'warn', 'not-loaded': '' }

    let panelEl
    let toastEl

    function renderAll(container) {
      panelEl = container
      container.innerHTML = state.editor ? renderEditorHtml() : renderMainHtml()
      bindEditorEvents(container)
      renderToast()
    }

    function renderToast() {
      if (toastEl === undefined || !toastEl.isConnected) {
        toastEl = document.createElement('div')
        toastEl.className = 'mX_toast'
        document.body.appendChild(toastEl)
      }
      if (state.toast) {
        toastEl.textContent = state.toast
        toastEl.dataset.kind = state.toastKind
        toastEl.style.display = ''
      } else {
        toastEl.style.display = 'none'
      }
    }

    function badge(text, kind, cls) {
      return '<span class="mX_badge' + (cls ? ' ' + cls : '') + '"' + (kind ? ' data-status="' + kind + '"' : '') + '>' + esc(text) + '</span>'
    }

    function transportBadge(transport) {
      return badge(transport === 'stdio' ? 'stdio' : 'http', '', '')
    }

    function summaryOf(server) {
      const config = server.config || {}
      if (config.transport === 'stdio') {
        const command = (config.command || '') + (config.args && config.args.length ? ' ' + config.args.join(' ') : '')
        return config.cwd ? config.cwd + ' $ ' + command : command
      }
      return config.url || ''
    }

    function statusBadge(status) {
      return badge(STATUS_TEXT[status] || status, STATUS_KIND[status] || '')
    }

    /**
     * 「已挂载，但没连上」：判据是宿主 DTO 的 `toolCount`（工具注册表里属于这行的工具数）。
     *
     * 为什么不看 `status`：它来自 fiber 生命周期，而连不上时 mcp-client 的 apply 照样 resolve
     * （默认 `failOnStartupError: false`，不抛错）⇒ 徽标显示「运行中」，可这个服务器一个工具
     * 都没有。工具是「连接成功 + tools/list」之后**唯一**会留下的产物，所以「active 且 0 个工具」
     * 就等于没连上；而且它是零成本的（读内存注册表，不做任何网络探测）。
     *
     * `toolCount === undefined` = 宿主读不到注册表（老宿主）⇒ 返回 false：宁可什么都不说，
     * 也不能把「读不到」显示成「未连接」。disabled 的行本来就不该有工具，不算；
     * loading / error 各有自己的徽标，不叠加。
     */
    function notConnected(server) {
      return server.toolCount === 0 && server.disabled !== true && server.status === 'active'
    }

    /**
     * 「外部占用」脚注：本卡之外还挂着哪些 mcp-client（别的插件自管的行）。
     *
     * 三处刻意与真冲突拉开距离，因为**两者不是一回事**（issue #5 的教训）：
     * 判据不同（这是清单本身，不与托管行求交集；冲突是清单 ∩ 托管行）、颜色不同（中性灰 vs 黄）、
     * 位置不同（列表下方脚注 vs 列表上方横幅）。零重名时它照样显示——它说的是「这些名字被占了」，
     * 不是「你重名了」。**只有真重名才该报警**。
     *
     * 名字逐个渲染成 chip，并把**托管它的 loader 行 id** 放进 title：只给一个 serverName 时，
     * 用户看不出它打哪来（`codegraph` 这种名字尤其像本卡自己的）。
     */
    function renderExternalNoteHtml() {
      const list = state.externalServers || []
      if (list.length === 0) return ''
      const chips = list.map((item) => '<span class="mX_noteName" title="' + esc(item.id) + '">' + esc(item.serverName) + '</span>').join('')
      return '<div class="mX_note" title="' + esc(t('banner.externalOccupiedHint')) + '">'
        + '<i class="mX_noteGlyph">i</i>'
        + '<span>' + esc(t('banner.externalOccupied')) + '</span>'
        + chips
        + '</div>'
    }

    function renderMainHtml() {
      const parts = []
      parts.push('<div class="mX_panel">')
      parts.push('<div class="mX_panelHeader"><h2 class="mX_panelTitle">' + t('panel.title') + '</h2>')
      parts.push('<span class="mX_subtitle" title="' + esc(state.patchFile) + '">' + esc(state.patchFile) + '</span>')
      parts.push('<span class="mX_toolbarSpacer"></span>')
      parts.push('<button class="mX_btnGhost" data-action="refresh"' + (state.loading ? ' disabled' : '') + '>' + t('btn.refresh') + '</button>')
      parts.push('<button class="mX_btn" data-action="add">' + t('btn.addServer') + '</button>')
      parts.push('</div>')
      if (state.fileError) parts.push('<div class="mX_banner" data-kind="error">' + esc(t('banner.fileError', { error: state.fileError })) + '</div>')
      // 冲突横幅只报**真重名**（host 端的 conflicts 已与托管行求过交集）：一条都不相交时
      // 这里什么都不渲染——曾经把「外部实例清单」原样当冲突渲染，于是不重名也常驻报警（issue #5）。
      // 整句也必须 `esc()` 包住：文案里有 `mcp__<serverName>__*`，不转义时 `<serverName>` 会被
      // innerHTML 当成一个未知标签吃掉，用户在界面上看到的是 `mcp____*`（见文件头「带 < 的文案
      // 一律 esc 包住」那条约定——这里当初漏了，缺陷只在**真有冲突**时才可见，所以一直没被发现）。
      if (state.conflicts && state.conflicts.length) {
        parts.push('<div class="mX_banner" data-kind="warn">' + esc(t('banner.conflicts', { names: state.conflicts.map((c) => c.serverName).join(t('list.separator')) })) + '</div>')
      }
      // 外部占用**不在这里**渲染：它是信息不是告警，放在列表下方当脚注（renderExternalNoteHtml），
      // 免得一条「不重名也常驻」的蓝框顶在列表前面被读成报错。
      parts.push('<div class="mX_list">')
      if (state.loading) {
        parts.push('<div class="mX_loading">' + t('list.loading') + '</div>')
      } else if (state.servers.length === 0) {
        parts.push('<div class="mX_empty">' + esc(t('list.empty')) + '<br>' + esc(t('list.emptyHint')) + '<br><br>' + esc(t('list.emptyReload')) + '</div>')
      } else {
        for (const server of state.servers) parts.push(renderCardHtml(server))
      }
      parts.push('</div>')
      parts.push(renderExternalNoteHtml())
      if (state.test) parts.push(renderTestHtml())
      parts.push('<div class="mX_banner" data-kind="info">' + t('msg.hotReload') + '</div>')
      parts.push('</div>')
      return parts.join('')
    }

    function renderCardHtml(server) {
      const parts = []
      parts.push('<div class="mX_card">')
      parts.push('<div class="mX_cardRow">')
      parts.push(transportBadge(server.transport))
      parts.push('<span class="mX_cardName">' + esc(server.serverName) + '</span>')
      // 「未连接」要顶掉绿色的「运行中」：fiber 是 ACTIVE 不代表连上了（见 notConnected），
      // 两个徽标并排只会让人以为它既活着又没连上。
      parts.push(notConnected(server) ? badge(t('list.notConnected'), 'warn', '') : statusBadge(server.status))
      if (server.conflict) parts.push(badge(t('list.conflict'), 'warn', ''))
      parts.push('<span class="mX_cardActions">')
      parts.push('<button class="mX_linkBtn" data-action="test" data-id="' + esc(server.id) + '"' + (state.busy ? ' disabled' : '') + '>' + t('btn.test') + '</button>')
      parts.push('<button class="mX_linkBtn" data-action="edit" data-id="' + esc(server.id) + '"' + (state.busy ? ' disabled' : '') + '>' + t('btn.edit') + '</button>')
      parts.push('<button class="mX_linkBtn" data-action="toggle" data-id="' + esc(server.id) + '"' + (state.busy ? ' disabled' : '') + '>' + (server.disabled ? t('btn.enable') : t('btn.disable')) + '</button>')
      parts.push('<button class="mX_btnGhost mX_btnDanger" data-action="remove" data-id="' + esc(server.id) + '"' + (state.busy ? ' disabled' : '') + '>' + t('btn.remove') + '</button>')
      parts.push('</span>')
      parts.push('</div>')
      parts.push('<div class="mX_cardSummary" title="' + esc(summaryOf(server)) + '">' + esc(summaryOf(server)) + '</div>')
      // 问题行里再放一个「停用」：宿主那一行 `.cardActions` 里的同名按钮在右上角，
      // 而人在读这段解释时手边正好该有个按钮——这就是「一键停用」。
      if (notConnected(server)) {
        parts.push('<div class="mX_cardWarn"><span class="mX_cardWarnText">' + esc(t('list.notConnectedDetail')) + '</span>'
          + '<button class="mX_linkBtn" data-action="toggle" data-id="' + esc(server.id) + '"' + (state.busy ? ' disabled' : '') + '>' + t('btn.disable') + '</button></div>')
      }
      parts.push('</div>')
      return parts.join('')
    }

    function renderTestHtml() {
      const test = state.test
      const parts = []
      parts.push('<div class="mX_toolWrap">')
      if (test.running) {
        parts.push('<div class="mX_banner" data-kind="info"><span class="mX_spinner"></span> ' + t('msg.testConnecting') + '</div>')
      } else {
        const result = test.result || {}
        parts.push(result.ok ? '<div class="mX_banner" data-kind="ok">' + t('msg.testOk') + '</div>' : '<div class="mX_banner" data-kind="error">' + t('msg.testFailed', { error: esc(result.error || t('error.unknown')) }) + '</div>')
        const meta = []
        if (result.durationMs !== undefined) meta.push(t('msg.metaDuration', { ms: result.durationMs }))
        if (result.protocolVersion) meta.push(t('msg.metaProtocol', { version: result.protocolVersion }))
        if (result.serverInfo && (result.serverInfo.name || result.serverInfo.version)) meta.push(t('msg.metaServer', { name: [result.serverInfo.name, result.serverInfo.version].filter(Boolean).join(' ') }))
        meta.push(t('msg.metaTools', { count: result.toolsCount || 0 }))
        parts.push('<div class="mX_toolHeader">' + esc(meta.join(' · ')) + '</div>')
        if (result.ok && result.tools && result.tools.length) {
          parts.push('<div class="mX_toolList">')
          for (const tool of result.tools) {
            parts.push('<div class="mX_toolItem"><span class="mX_toolName">mcp__' + esc(test.serverName) + '__' + esc(tool.name) + '</span>')
            if (tool.description) parts.push('<span class="mX_toolDesc">' + esc(String(tool.description).slice(0, 200)) + '</span>')
            parts.push('</div>')
          }
          parts.push('</div>')
        }
      }
      parts.push('</div>')
      return parts.join('')
    }

    /* ================================ 渲染：编辑表单 ================================ */

    function kvToText(map) {
      if (!map) return ''
      return Object.entries(map).map((pair) => pair[0] + '=' + pair[1]).join('\n')
    }

    function renderEditorHtml() {
      const editor = state.editor
      const server = editor.server
      const config = (server && server.config) || {}
      const title = editor.mode === 'create' ? t('panel.editorCreate') : t('panel.editorEdit')
      const transport = config.transport || 'stdio'
      const reconnect = config.reconnect || {}
      const parts = []
      parts.push('<div class="mX_panel">')
      parts.push('<div class="mX_panelHeader"><h2 class="mX_panelTitle">' + esc(title) + '</h2></div>')
      parts.push('<div class="mX_modalBody">')
      parts.push('<div class="mX_formRow">')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_name">' + esc(t('panel.fieldName')) + '</label><input class="mX_input" id="ed_name" placeholder="' + esc(t('placeholder.serverName')) + '" value="' + esc(config.serverName || '') + '"><p class="mX_fieldError" id="ed_nameError"></p></div>')
      parts.push('<div class="mX_field"><span class="mX_fieldLabel">' + esc(t('panel.fieldTransport')) + '</span><span class="mX_radioRow">')
      parts.push('<label class="mX_radioLabel"><input type="radio" name="ed_transport" value="stdio"' + (transport === 'stdio' ? ' checked' : '') + '>' + esc(t('panel.transportStdio')) + '</label>')
      parts.push('<label class="mX_radioLabel"><input type="radio" name="ed_transport" value="streamable-http"' + (transport === 'streamable-http' ? ' checked' : '') + '>' + esc(t('panel.transportHttp')) + '</label>')
      parts.push('</span></div>')
      parts.push('</div>')
      parts.push('<div id="ed_stdio" style="display:' + (transport === 'stdio' ? 'flex' : 'none') + ';flex-direction:column;gap:10px">')
      parts.push('<div class="mX_formRow">')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_command">' + esc(t('panel.fieldCommand')) + '</label><input class="mX_input" id="ed_command" placeholder="npx" value="' + esc(config.command || '') + '"></div>')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_cwd">' + esc(t('panel.fieldCwd')) + '</label><input class="mX_input" id="ed_cwd" placeholder="/path/to/project" value="' + esc(config.cwd || '') + '"></div>')
      parts.push('</div>')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_args">' + esc(t('panel.fieldArgs')) + '</label><textarea class="mX_input mX_textarea" id="ed_args" placeholder="[-y, @modelcontextprotocol/server-filesystem]">' + esc(JSON.stringify(config.args || [])) + '</textarea></div>')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_env">' + esc(t('panel.fieldEnv')) + '</label><textarea class="mX_input mX_textarea" id="ed_env" placeholder="GITHUB_TOKEN=js:process.env.GITHUB_TOKEN">' + esc(kvToText(config.env)) + '</textarea></div>')
      parts.push('</div>')
      parts.push('<div id="ed_http" style="display:' + (transport === 'streamable-http' ? 'flex' : 'none') + ';flex-direction:column;gap:10px">')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_url">' + esc(t('panel.fieldUrl')) + '</label><input class="mX_input" id="ed_url" placeholder="http://localhost:3000/mcp" value="' + esc(config.url || '') + '"></div>')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_headers">' + esc(t('panel.fieldHeaders')) + '</label><textarea class="mX_input mX_textarea" id="ed_headers" placeholder="Authorization=js:process.env.MCP_TOKEN">' + esc(kvToText(config.headers)) + '</textarea></div>')
      parts.push('</div>')
      parts.push('<div class="mX_formRow">')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_timeout">toolCallTimeoutMs</label><input class="mX_input" id="ed_timeout" type="number" min="1" value="' + esc(String(config.toolCallTimeoutMs ?? 60000)) + '"></div>')
      parts.push('<label class="mX_checkRow" style="padding-top:18px"><input type="checkbox" id="ed_failStartup"' + (config.failOnStartupError ? ' checked' : '') + '>' + esc(t('panel.fieldFailOnStartupError')) + '</label>')
      parts.push('<label class="mX_checkRow" style="padding-top:18px"><input type="checkbox" id="ed_enabled"' + (server && server.disabled ? '' : ' checked') + '>' + esc(t('panel.fieldEnabled')) + '</label>')
      parts.push('</div>')
      parts.push('<div class="mX_formRow" style="align-items:end">')
      parts.push('<label class="mX_checkRow" style="padding-top:18px"><input type="checkbox" id="ed_rcEnabled"' + (reconnect.enabled !== false ? ' checked' : '') + '>' + esc(t('panel.fieldReconnect')) + '</label>')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_rcInitial">initialDelayMs</label><input class="mX_input" id="ed_rcInitial" type="number" min="1" value="' + esc(String(reconnect.initialDelayMs ?? 500)) + '"></div>')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_rcMax">maxDelayMs</label><input class="mX_input" id="ed_rcMax" type="number" min="1" value="' + esc(String(reconnect.maxDelayMs ?? 30000)) + '"></div>')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_rcAttempts">maxAttempts</label><input class="mX_input" id="ed_rcAttempts" type="number" min="1" value="' + esc(String(reconnect.maxAttempts ?? 10)) + '"></div>')
      parts.push('</div>')
      parts.push('<p class="mX_formError" id="ed_error"></p>')
      parts.push('<div class="mX_hint">' + esc(t('panel.hint')) + '</div>')
      // 测试结果就地展示在编辑器里（容器固定，由 testEditor 直接改 innerHTML）：
      // 这样「测试连接 → 保存」是一条连续动作，表单与已填内容都留着
      parts.push('<div id="ed_testResult">' + (state.test ? renderTestHtml() : '') + '</div>')
      parts.push('</div>')
      parts.push('<div class="mX_modalFooter">')
      parts.push('<button class="mX_btnGhost" data-action="editor-cancel">' + t('btn.cancel') + '</button>')
      parts.push('<button class="mX_btnGhost" data-action="editor-test"' + (state.busy ? ' disabled' : '') + '>' + t('btn.testConnection') + '</button>')
      parts.push('<button class="mX_btn" data-action="editor-save"' + (state.busy ? ' disabled' : '') + '>' + t('btn.save') + '</button>')
      parts.push('</div>')
      parts.push('</div>')
      return parts.join('')
    }

    function bindEditorEvents(container) {
      if (!state.editor) return
      const toggleSections = () => {
        const stdio = container.querySelector('#ed_stdio')
        const http = container.querySelector('#ed_http')
        const checked = container.querySelector('input[name="ed_transport"]:checked')
        const transport = checked ? checked.value : 'stdio'
        if (stdio) stdio.style.display = transport === 'stdio' ? 'flex' : 'none'
        if (http) http.style.display = transport === 'streamable-http' ? 'flex' : 'none'
      }
      const radios = container.querySelectorAll('input[name="ed_transport"]')
      for (const radio of radios) radio.addEventListener('change', toggleSections)
      toggleSections()
      // serverName 一撞名就当场标红：这是「直观」的主力——用户不必先点保存、再读一条
      // 事后错误。事件挂在 input 上而不是 blur 上，因为撞名多半是边打边发生（打到第 3 个
      // 字符就撞上了）。开表单时先跑一次，编辑一条历史遗留的同名行也能立刻看到原因。
      const nameInput = container.querySelector('#ed_name')
      if (nameInput !== null) {
        nameInput.addEventListener('input', () => validateEditorName())
        validateEditorName()
      }
    }

    function parseArgs(text) {
      const trimmed = (text || '').trim()
      if (trimmed === '') return []
      if (trimmed.startsWith('[')) {
        const parsed = JSON.parse(trimmed)
        if (!Array.isArray(parsed) || parsed.some((item) => typeof item !== 'string')) throw new Error(t('error.argsNotArray'))
        return parsed
      }
      return trimmed.split('\n').map((line) => line.trim()).filter(Boolean)
    }

    function parseKvText(text) {
      const out = {}
      for (const raw of String(text || '').split('\n')) {
        const line = raw.trim()
        if (line === '' || line.startsWith('#')) continue
        const match = line.match(/^([A-Za-z_][A-Za-z0-9_.-]*)\s*[:=]\s*(.*)$/)
        if (match === null) throw new Error(t('error.unparsableLine', { line }))
        out[match[1]] = match[2]
      }
      return out
    }

    function newId() {
      let id = 'mcp-'
      const chars = 'abcdefghijklmnopqrstuvwxyz0123456789'
      if (window.crypto && crypto.randomUUID) {
        id = 'mcp-' + crypto.randomUUID().replace(/-/g, '').slice(0, 10)
      } else {
        for (let i = 0; i < 10; i++) id += chars[Math.floor(Math.random() * chars.length)]
      }
      return id
    }

    function collectEditor() {
      const value = (id) => {
        const input = document.getElementById(id)
        return input ? String(input.value || '').trim() : ''
      }
      const checked = (id) => {
        const input = document.getElementById(id)
        return input ? input.checked : false
      }
      const config = { serverName: value('ed_name') }
      const transportInput = document.querySelector('input[name="ed_transport"]:checked')
      config.transport = transportInput ? transportInput.value : 'stdio'
      if (config.transport === 'stdio') {
        config.command = value('ed_command')
        config.args = parseArgs(document.getElementById('ed_args')?.value || '')
        config.env = parseKvText(document.getElementById('ed_env')?.value || '')
        const cwd = value('ed_cwd')
        if (cwd !== '') config.cwd = cwd
      } else {
        config.url = value('ed_url')
        config.headers = parseKvText(document.getElementById('ed_headers')?.value || '')
      }
      const timeoutText = value('ed_timeout')
      if (timeoutText !== '') config.toolCallTimeoutMs = Number(timeoutText)
      if (checked('ed_failStartup')) config.failOnStartupError = true
      if (checked('ed_rcEnabled')) {
        config.reconnect = {
          enabled: true,
          initialDelayMs: Number(value('ed_rcInitial') || 500),
          maxDelayMs: Number(value('ed_rcMax') || 30000),
          maxAttempts: Number(value('ed_rcAttempts') || 10),
        }
      } else {
        config.reconnect = { enabled: false }
      }
      const row = { id: (state.editor.server && state.editor.server.id) || newId(), config }
      if (!checked('ed_enabled')) row.disabled = true
      return row
    }

    function setEditorError(message) {
      const errorEl = document.getElementById('ed_error')
      if (errorEl) errorEl.textContent = message || ''
    }

    /**
     * serverName 的**字段级**实时校验：撞名当场在输入框下给原因，并把输入框标红。
     *
     * 它只是「一眼看见」，**不是闸门**——真正拒绝保存的是 `saveEditor()`（本地即时反馈，
     * 见下面 externalClash 那段）与宿主侧的 `externalNameRejection()`（权威）。所以这里
     * 刻意**不**禁用保存按钮：历史遗留的同名行要能改别的字段，而「能不能存」由那两道说。
     *
     * 两个判据与保存侧逐字对齐（口径分叉过一次就很难再对齐了）：
     * ① 与本卡其它行重名 → `error.duplicateName`；
     * ② 撞上外部实例名单 → `error.externalClash`，但**这行本来就叫这个名字**时放行。
     */
    function validateEditorName() {
      const input = document.getElementById('ed_name')
      const errorEl = document.getElementById('ed_nameError')
      if (input === null) return ''
      const name = String(input.value || '').trim()
      const setError = (message) => {
        if (errorEl !== null) errorEl.textContent = message
        if (message === '') delete input.dataset.invalid
        else input.dataset.invalid = 'true'
        return message
      }
      const original = state.editor !== null && state.editor.server !== null ? state.editor.server : null
      if (name === '') return setError('')
      const selfId = original !== null ? original.id : null
      if (state.servers.some((server) => server.id !== selfId && server.serverName === name)) {
        return setError(t('error.duplicateName', { name }))
      }
      const clash = (state.externalServers || []).find((item) => item.serverName === name)
      if (clash !== undefined && !(original !== null && original.serverName === name)) {
        return setError(t('error.externalClash', { name, id: clash.id }))
      }
      return setError('')
    }

    /* ================================ 动作 ================================ */

    function refresh() {
      if (panelEl) renderAll(panelEl)
    }

    async function load() {
      if (state.loading) return
      state.loading = true
      refresh()
      try {
        const body = await apiList()
        state.servers = Array.isArray(body.servers) ? body.servers : []
        state.conflicts = Array.isArray(body.conflicts) ? body.conflicts : []
        state.externalServers = Array.isArray(body.externalServers) ? body.externalServers : []
        state.fileError = body.fileError || ''
        state.patchFile = body.patchFile || ''
      } catch (error) {
        state.fileError = error instanceof Error ? error.message : String(error)
      } finally {
        state.loading = false
        refresh()
      }
    }

    function openEditor(mode, server) {
      state.editor = { mode, server: server || null }
      state.test = null
      refresh()
    }

    function closeEditor() {
      state.editor = null
      refresh()
    }

    async function saveEditor() {
      let row
      try {
        row = collectEditor()
      } catch (error) {
        setEditorError(error instanceof Error ? error.message : String(error))
        return
      }
      const others = state.servers.filter((server) => server.id !== row.id)
      if (others.some((server) => server.serverName === row.config.serverName)) {
        setEditorError(t('error.duplicateName', { name: row.config.serverName }))
        return
      }
      // 外部实例同名（别的插件托管的 mcp-client，如 codegraph 归 Codegraph 插件管）：本地先拦
      // 一道给即时反馈；宿主侧还会再拦一次（权威）。比的是**外部实例清单**（externalServers），
      // 不是 conflicts——conflicts 只是「已经重名」的那几行，这里要拦的是任何撞上外部名单的新名字。
      // 已经是这一行原本的名字（历史遗留）不拦，否则连它的其它字段都改不了 —— 宿主侧同样按「是否新引入」判定。
      const clash = (state.externalServers || []).find((item) => item.serverName === row.config.serverName)
      const original = state.editor !== null && state.editor.server !== null ? state.editor.server : null
      if (clash !== undefined && !(original !== null && original.serverName === row.config.serverName)) {
        setEditorError(t('error.externalClash', { name: row.config.serverName, id: clash.id }))
        return
      }
      const servers = [...others, row]
      state.busy = true
      setEditorError('')
      try {
        await apiSave(servers)
        toast(t('msg.saved'), 'ok')
        state.editor = null
        setTimeout(() => load(), 800)
      } catch (error) {
        setEditorError(error instanceof Error ? error.message : String(error))
        toast(t('msg.saveFailed', { error: error instanceof Error ? error.message : String(error) }), 'error')
      } finally {
        state.busy = false
        refresh()
      }
    }

    async function removeServer(id) {
      const server = state.servers.find((item) => item.id === id)
      if (server === undefined) return
      // 删掉最后一条＝清空托管区块，确认文案要说清这一点，保存时也要显式带 clearAll
      const last = state.servers.length === 1
      const question = last
        ? t('msg.confirmRemoveLast', { name: server.serverName })
        : t('msg.confirmRemove', { name: server.serverName })
      if (!window.confirm(question)) return
      const servers = state.servers.filter((item) => item.id !== id)
      state.busy = true
      refresh()
      try {
        await apiSave(servers, { clearAll: last })
        toast(t('msg.deleted'), 'ok')
        setTimeout(() => load(), 800)
      } catch (error) {
        toast(t('msg.removeFailed', { error: error instanceof Error ? error.message : String(error) }), 'error')
      } finally {
        state.busy = false
        refresh()
      }
    }

    async function toggleServer(id) {
      const servers = state.servers.map((server) => (server.id === id ? { ...server, disabled: !server.disabled } : server))
      state.busy = true
      refresh()
      try {
        await apiSave(servers)
        toast(t('msg.updated'), 'ok')
        setTimeout(() => load(), 800)
      } catch (error) {
        toast(t('msg.updateFailed', { error: error instanceof Error ? error.message : String(error) }), 'error')
      } finally {
        state.busy = false
        refresh()
      }
    }

    async function runTest(server) {
      state.test = { serverName: server.serverName, running: true, result: null }
      state.editor = null
      refresh()
      try {
        const body = await apiTest(server.config)
        state.test = { serverName: server.serverName, running: false, result: body.result || {} }
      } catch (error) {
        state.test = { serverName: server.serverName, running: false, result: { ok: false, error: error instanceof Error ? error.message : String(error), toolsCount: 0 } }
      }
      refresh()
    }

    /**
     * 编辑器里的「测试连接」。
     *
     * 两条硬约束（都是实测踩出来的）：
     *   1. **不关编辑器**——测试只是确认配置能不能连上，紧接着就要点「保存」。早先这里把
     *      `state.editor` 置空，而编辑器是整块替换渲染（`editor ? editorHtml : mainHtml`），
     *      于是表单连同「保存」按钮一起消失，用户看到的就是「一点测试连接，保存就没了」。
     *   2. **不整体重渲染**——用户的输入只活在 DOM 里（渲染始终以原始 config 为源），
     *      `refresh()` 一次就把填好的内容冲回原样。所以结果只就地写进 `#ed_testResult`，
     *      按钮的禁用/恢复也直接改 DOM。
     */
    async function testEditor() {
      let row
      try {
        row = collectEditor()
      } catch (error) {
        setEditorError(error instanceof Error ? error.message : String(error))
        return
      }
      setEditorError('')
      const setBusy = (busy) => {
        state.busy = busy
        for (const el of document.querySelectorAll('[data-action="editor-test"], [data-action="editor-save"]')) {
          if (el instanceof HTMLButtonElement) el.disabled = busy
        }
      }
      state.test = { serverName: row.config.serverName, running: true, result: null }
      const running = document.getElementById('ed_testResult')
      if (running !== null) running.innerHTML = renderTestHtml()
      setBusy(true)
      try {
        const body = await apiTest(row.config)
        state.test = { serverName: row.config.serverName, running: false, result: body.result || {} }
        toast(body.result && body.result.ok ? t('msg.testOkHint') : t('msg.testFailedToast'), body.result && body.result.ok ? 'ok' : 'error')
      } catch (error) {
        // 请求本身失败（路由/网络）：清掉「正在连接…」，把原因写进编辑器错误行
        state.test = null
        setEditorError(error instanceof Error ? error.message : String(error))
      } finally {
        setBusy(false)
        const host = document.getElementById('ed_testResult')
        if (host !== null) host.innerHTML = state.test === null ? '' : renderTestHtml()
      }
    }

    /* ================================ 事件委托 ================================ */

    function handleClick(event) {
      const target = event.target
      if (!(target instanceof Element)) return
      /*
       * 作用域：只处理**自己卡片 DOM 内**的点击。
       * 为什么必须有：prompt 卡片的按钮也用通用 `data-action`（refresh / edit / editor-save
       * 与这里同名），不判作用域时点 prompt 的「刷新」「编辑」「保存」都会落到这里，
       * 拿 undefined 的 id 去操作 MCP 服务器（轻则空跑；MCP 编辑态开着时会把那张表单存下去）。
       * 2026-10-03 实测过同一类：profile 的「删除」被 prompt 的处理器接走并报错。
       */
      if (panelEl === undefined || !panelEl.contains(target)) return
      const actionEl = target.closest('[data-action]')
      if (actionEl === null || actionEl.disabled) return
      const action = actionEl.dataset.action
      const id = actionEl.dataset.id
      if (action === 'refresh') load()
      else if (action === 'add') openEditor('create')
      else if (action === 'edit') {
        const server = state.servers.find((item) => item.id === id)
        if (server) openEditor('edit', server)
      } else if (action === 'remove') removeServer(id)
      else if (action === 'toggle') toggleServer(id)
      else if (action === 'test') {
        const server = state.servers.find((item) => item.id === id)
        if (server) runTest(server)
      } else if (action === 'editor-cancel') closeEditor()
      else if (action === 'editor-save') saveEditor()
      else if (action === 'editor-test') testEditor()
    }

    /* ================================ 面板宿主挂载 ================================ */

    function mountDomPanel(host) {
      if (panelEl !== undefined && panelEl.isConnected && panelEl.parentElement === host) return
      if (panelEl !== undefined) panelEl.remove()
      panelEl = document.createElement('div')
      panelEl.className = 'mX_panelHost'
      host.appendChild(panelEl)
      renderAll(panelEl)
    }

    /* ================================ 设置卡片（React 外壳） ================================ */

    const CHEVRON_PATH = 'M11.8486 5.5L11.4238 5.92383L8.69727 8.65137C8.44157 8.90706 8.21562 9.13382 8.01172 9.29785C7.79912 9.46883 7.55595 9.61756 7.25 9.66602C7.08435 9.69222 6.91565 9.69222 6.75 9.66602C6.44405 9.61756 6.20088 9.46883 5.98828 9.29785C5.78438 9.13382 5.55843 9.13382 5.30273 8.65137L2.57617 5.92383L2.15137 5.5L3 4.65137L3.42383 5.07617L6.15137 7.80273C6.42595 8.07732 6.59876 8.24849 6.74023 8.3623C6.87291 8.46904 6.92272 8.47813 6.9375 8.48047C6.97895 8.48703 7.02105 8.48703 7.0625 8.48047C7.07728 8.47813 7.12709 8.46904 7.25977 8.3623C7.40124 8.24849 7.57405 8.07732 7.84863 7.80273L10.5762 5.07617L11 4.65137L11.8486 5.5Z'

    function McpSettingsCard(props) {
      // DSH ≥0.1.6 的插件配置页把同一条目按 view 渲染两次：summary 一句话摘要、page 完整表单。
      // 旧版（≤0.1.5）的 settings.plugin.item 卡片不带 view，走原有可折叠卡片分支。
      const view = props && props.view
      const pageView = view === 'page'
      const [open, setOpen] = React.useState(pageView)
      const hostRef = React.useRef(null)
      React.useEffect(() => {
        if (!open) return
        const host = hostRef.current
        if (host === null) return
        mountDomPanel(host)
        load()
      }, [open])
      if (view === 'summary') {
        return t('card.desc')
      }

      // page 视图：新页面自己画标题/图标/面包屑，这里只交表单本体，不渲染卡片头。
      return jsxs(pageView ? 'div' : 'li', {
        className: pageView ? 'mX_pageHost' : (open ? 'mX_pluginCard mX_pluginCardOpen' : 'mX_pluginCard'),
        children: [
          pageView ? null : jsxs('button', {
            type: 'button',
            className: 'mX_cardHeader',
            'aria-expanded': open,
            onClick: () => setOpen((current) => !current),
            children: [
              jsxs('span', {
                className: 'mX_cardHeadText',
                children: [
                  jsx('span', { className: 'mX_cardName', children: t('card.name') }),
                  jsx('span', { className: 'mX_cardDescription', children: t('card.desc') }),
                ],
              }),
              jsx('span', { className: 'dshkit_badge', children: 'Kit' }),
              jsx('svg', {
                width: '14',
                height: '14',
                viewBox: '0 0 14 14',
                fill: 'none',
                xmlns: 'http://www.w3.org/2000/svg',
                className: 'mX_chevron',
                children: jsx('path', { d: CHEVRON_PATH, fill: 'currentColor' }),
              }),
            ],
          }),
          (pageView || open) ? jsx('div', {
            className: 'mX_cardBody',
            children: jsx('div', { ref: hostRef, className: 'mX_cardHost' }),
          }) : null,
        ],
      })
    }

    /* ================================ 插件入口 ================================ */

    exports.inject = ['slots']

    /**
     * DSH ≥0.1.6-alpha.2 的行配置 key：`<bundle 包名>#<行 id>`，行 id 取自 bundle 的
     * cordis.patch.yml。独立安装时 bundle 是本包，装全家桶时是 @hyzyn/dsh-all —— 两个都注册，
     * 未命中的那个只是躺在 ledger 里，不会渲染。
     */
    const ROW_CONFIG_KEYS = [
      '@hyzyn/dsh-mcp#mcp-config',
      '@hyzyn/dsh-all#mcp-config',
    ]

    exports.apply = (ctx) => {
      installI18n(ctx)
      ctx.effect(() => {
        ensureStyle()
        // 面板 DOM 点击委托：挂在 document 上，避免随重渲染丢失
        document.addEventListener('click', handleClick, true)
        return () => {
          document.removeEventListener('click', handleClick, true)
          styleEl?.remove()
          styleEl = undefined
          toastEl?.remove()
          toastEl = undefined
          panelEl?.remove()
          panelEl = undefined
        }
      })
      // 注册到官方插件配置 → 可配置 卡片列表（与终端 / Agent 循环 / 网页搜索同级）
      /*
       * 设置面：0.2.0-rc.1 起挂 `plugins.bundle.config`——key 是 **bundle 包名**，管理器的插件
       * 详情页把它渲染在「说明」正下方；`plugins.row.config` 是 per-row 的「>」子页。
       *
       * 两条硬约束（第一条踩过坑，见下）：
       *   ① `plugins.bundle.config` 的 key 是**共享命名空间**：同一个 key 只能有一个注册者，
       *      重复注册**直接抛错**（`keyed slot ... already has an entry`），而客户端 `apply`
       *      抛错 = 整个插件起不来（实测：把 `@hyzyn/dsh-all` 也挂上时，八个插件抢同一个 key，
       *      启动页直接变「Failed to load plugins」）（D158）。聚合包 `@hyzyn/dsh-all` 是所有插件共用的
       *      bundle，**不能**挂 bundle.config —— 它没有内联位，设置面走它自己的 row 入口。
       *   ② 内联位可用时，**本包自己的** bundle 不再注册 row 槽（同一份表单两个入口会让人以为
       *      有两套设置）；聚合包那份 row 入口**保留**（那是它在聚合安装下的唯一入口）。旧宿主
       *      （bundle 槽不存在，0.1.6 线）回退注册全部 row 槽，功能一点不减。
       * 就绪顺序不敏感：任一侧先到都收敛到「内联优先」（后到的本包 row 注册会被撤掉）。
       */
      const AGGREGATE_BUNDLE = '@hyzyn/dsh-all'
      const BUNDLE_NAMES = [...new Set(ROW_CONFIG_KEYS.map((key) => key.split('#')[0]))]
      const OWN_BUNDLE = BUNDLE_NAMES.find((name) => name !== AGGREGATE_BUNDLE)
      let bundleConfigLive = false
      const disposeOwnRowConfigs = []
      if (OWN_BUNDLE !== undefined) {
        ctx.slots.inject('plugins.bundle.config', () => {
          bundleConfigLive = true
          while (disposeOwnRowConfigs.length > 0) {
            const disposeRow = disposeOwnRowConfigs.pop()
            if (typeof disposeRow === 'function') disposeRow()
          }
          return ctx.slots.register({
            name: 'plugins.bundle.config',
            key: OWN_BUNDLE,
          }, McpSettingsCard)
        })
      }
      for (const key of ROW_CONFIG_KEYS) {
        ctx.slots.inject('plugins.row.config', () => {
          const own = key.split('#')[0] === OWN_BUNDLE
          if (own && bundleConfigLive) return undefined
          const disposeRow = ctx.slots.register({
            name: 'plugins.row.config',
            key,
          }, McpSettingsCard)
          if (own) disposeOwnRowConfigs.push(disposeRow)
          return disposeRow
        })
      }
      // DSH ≥0.1.6：设置里与「通用设置」平级的「插件配置」页（子 slot 由
      // @hyzyn/dsh-kit-settings 声明）。不传 view，卡片走各自原有的可折叠形态。
      ctx.slots.inject('settings.kit.item', () => ctx.slots.register({
        name: 'settings.kit.item',
        id: 'mcp-config',
        order: 20,
        label: () => t('card.name'),
      }, McpSettingsCard))
      // DSH ≤0.1.5：设置 → 插件 的「插件配置」标签页，keyed 插槽按 settings 命名空间派发。
      ctx.slots.inject('settings.plugin.item', () => ctx.slots.register({
        name: 'settings.plugin.item',
        // settings.plugin.item 是 keyed 插槽：key 必须是该卡片所编辑的 settings 命名空间
        key: 'mcp-config',
        order: 96,
      }, McpSettingsCard))
    }

    return exports
  },
})
