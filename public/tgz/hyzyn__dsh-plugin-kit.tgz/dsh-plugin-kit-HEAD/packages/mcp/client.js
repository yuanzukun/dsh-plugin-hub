/* eslint-disable */
/**
 * @hyzyn/dsh-mcp — 浏览器半体：官方插件配置里的「MCP 服务器配置」卡片。
 * 通过核心 slots 服务注册到 settings.plugin.item 插槽（与官方终端 / Agent 循环 /
 * 网页搜索卡片同级），不再占用侧边栏、不做全屏面板接管。
 * 纯 DOM 渲染（React 只承担卡片外壳与展开状态），无构建步骤，
 * 宿主经 /plugins/@hyzyn/dsh-mcp/client.js 提供。
 */
window.__ModuleLoader__.load({
  id: '@hyzyn/dsh-mcp',
  factory: (require) => {
    const exports = {}

    const React = require('react')
    const { jsx, jsxs } = require('react/jsx-runtime')

    /* ================================ CSS ================================ */

    const CSS = [
      // 设置插件卡片外壳（与官方 PluginCard 一致的轮廓）
      '.mX_pageHost{display:block}',
      '.mX_pluginCard{list-style:none;border:.5px solid var(--dsw-alias-settings-card-stroke);background:var(--dsw-alias-settings-card-fill);border-radius:var(--dsw-radius-xl);transition:border-color .16s,background .16s}',
      '.mX_pluginCard:hover{border-color:var(--dsw-alias-label-dimmed)}',
      '.mX_pluginCardOpen{background:var(--dsw-alias-bg-layer-1);border-color:var(--dsw-alias-label-dimmed)}',
      '.mX_cardHeader{appearance:none;width:100%;color:inherit;font:inherit;text-align:left;cursor:pointer;background:0 0;border:0;border-radius:var(--dsw-radius-xl);display:flex;align-items:center;gap:12px;padding:14px 16px}',
      '.mX_cardHeader:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:-2px}',
      '.mX_cardHeadText{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}',
      // 卡片标题：本文件另有一条 .mX_cardName（面板内实体名）——同选择器后者整条覆盖前者，
      // 那两条 14px/600 与 13.5px/700 都是死声明；合并为官方 cardTitle 角色 14px/500/22px。
      '.mX_cardName{color:var(--dsw-alias-label-primary);font-size:14px;font-weight:500;line-height:22px}',
      '.dshkit_badge{flex:none;margin-left:auto;padding:1px 8px;border-radius:999px;corner-shape:round;font-size:11px;font-weight:600;line-height:16px;letter-spacing:.02em;color:var(--dsw-alias-label-dimmed);background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1)}',
      '.mX_cardDescription{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px}',
      '.mX_chevron{flex:none;color:var(--dsw-alias-label-tertiary);transition:transform .16s}',
      '.mX_pluginCardOpen .mX_chevron{transform:rotate(180deg)}',
      '.mX_cardBody{padding:2px 16px 16px}',
      // 面板
      '.mX_panel{display:flex;flex-direction:column;gap:12px;color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-family);box-sizing:border-box}',
      '.mX_panelHeader{display:flex;align-items:center;gap:10px;flex:none}',
      '.mX_panelTitle{margin:0;font-size:15px;font-weight:500;line-height:22px;white-space:nowrap;flex:1}',
      // 11.5px 的提示/次级正文上收到官方 hint 的 12/18（10–11px 只留给徽标与小 tag）。
      '.mX_subtitle{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;font-family:var(--ds-font-family-code);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:320px}',
      '.mX_toolbar{display:flex;align-items:center;gap:8px;flex:none}',
      '.mX_toolbarSpacer{flex:1}',
      // 按钮族对齐宿主 Button primitives：本包属 H28 档（size="sm"），故统一 H28/R8/12px/18px/padding 0 10px，
      // 填充与描边两个变体逐项同尺寸；主按钮底色是 button-primary-fill（button-info 一族是强调蓝，非按钮填充）。
      '.mX_btn{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:4px;height:28px;padding:0 10px;border:none;border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground);font-family:inherit;font-size:12px;line-height:18px;white-space:nowrap;cursor:pointer}',
      '.mX_btn:hover:not(:disabled){background:var(--dsw-alias-button-primary-hover)}',
      '.mX_btn:disabled{opacity:.4;cursor:not-allowed}',
      '.mX_btn:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary))}',
      '.mX_btnGhost{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:4px;height:28px;padding:0 10px;border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-sm);background:transparent;color:var(--dsw-alias-label-primary);font-family:inherit;font-size:12px;line-height:18px;white-space:nowrap;cursor:pointer}',
      '.mX_btnGhost:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}',
      '.mX_btnGhost:active:not(:disabled){background:var(--dsw-alias-interactive-bg-active)}',
      '.mX_btnGhost:disabled{opacity:.4;cursor:not-allowed}',
      '.mX_btnGhost:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary))}',
      '.mX_actionSep{flex:none;width:1px;height:12px;background:var(--dsw-alias-border-l1)}',
      '.mX_btnDanger{color:var(--dsw-alias-state-error-primary);border-color:color-mix(in srgb,var(--dsw-alias-state-error-primary) 30%,transparent)}',
      '.mX_btnDanger:hover:not(:disabled){background:color-mix(in srgb,var(--dsw-alias-state-error-primary) 8%,transparent)}',
      '.mX_linkBtn{color:var(--dsw-alias-link);background:0 0;border:none;padding:0;font-size:12px;line-height:18px;font-weight:500;cursor:pointer;white-space:nowrap;text-decoration:none}',
      '.mX_linkBtn:hover:not(:disabled){text-decoration:underline dotted;text-underline-offset:3px}',
      '.mX_list{display:flex;flex-direction:column;gap:8px;max-height:420px;overflow-y:auto}',
      '.mX_card{background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-md);padding:10px 12px;display:flex;flex-direction:column;gap:6px}',
      '.mX_cardRow{display:flex;align-items:center;gap:8px;flex-wrap:wrap}',
      '.mX_cardSummary{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px;font-family:var(--ds-font-family-code);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;min-width:0}',
      '.mX_cardActions{display:flex;align-items:center;gap:10px;margin-left:auto}',
      // 卡片内的问题行（目前只有「已挂载但没连上」一种）：与摘要之间加一道分隔，
      // 文字保持次要色（长句用警告色会吵），靠徽标与左边的停用按钮传达该干什么。
      '.mX_badge{display:inline-block;border:.5px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);border-radius:999px;corner-shape:round;padding:1px 8px;font-size:11px;line-height:16px;white-space:nowrap}',
      '.mX_badge[data-kind=stdio]{color:var(--dsw-alias-state-business-primary);border-color:var(--dsw-alias-state-business-primary)}',
      '.mX_badge[data-kind=http]{color:var(--dsw-alias-state-business-primary);border-color:var(--dsw-alias-state-business-primary)}',
      '.mX_badge[data-status=ok]{color:var(--dsw-alias-state-success-primary);border-color:var(--dsw-alias-state-success-primary)}',
      '.mX_badge[data-status=error]{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}',
      '.mX_badge[data-status=warn]{color:var(--dsw-alias-state-warn-primary);border-color:var(--dsw-alias-state-warn-primary)}',
      '.mX_banner{border:.5px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);border-radius:8px;padding:8px 12px;font-size:12.5px;line-height:18px;overflow-wrap:anywhere;flex:none}',
      '.mX_banner[data-kind=ok]{color:var(--dsw-alias-state-success-primary);border-color:var(--dsw-alias-state-success-primary)}',
      '.mX_banner[data-kind=error]{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}',
      '.mX_banner[data-kind=info]{color:var(--dsw-alias-state-business-primary);border-color:var(--dsw-alias-state-business-primary)}',
      '.mX_banner[data-kind=warn]{color:var(--dsw-alias-state-warn-primary);border-color:var(--dsw-alias-state-warn-primary)}',
      // 「外部占用」是**信息**、不是告警：做成列表下方的紧凑脚注（一行小字 + 名字 chip），
      // 尺寸与位置都与真冲突的黄色横幅（.mX_banner[data-kind=warn]）明显拉开。
      '.mX_note{display:flex;align-items:center;flex-wrap:wrap;gap:6px;flex:none;background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1);border-radius:8px;padding:6px 10px;font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary)}',
      '.mX_noteGlyph{flex:none;width:13px;height:13px;border-radius:50%;corner-shape:round;border:1px solid var(--dsw-alias-state-business-primary);color:var(--dsw-alias-state-business-primary);font-size:9px;font-weight:600;font-style:normal;line-height:11px;text-align:center}',
      '.mX_noteName{font-family:var(--ds-font-family-code);font-size:11px;line-height:16px;color:var(--dsw-alias-label-secondary);background:var(--dsw-alias-bg-layer-3);border:.5px solid var(--dsw-alias-border-l2);border-radius:var(--dsw-radius-sm);padding:0 6px}',
      '.mX_empty,.mX_loading{text-align:center;color:var(--dsw-alias-label-tertiary);padding:24px 12px;font-size:12.5px;line-height:18px}',
      '.mX_modalBackdrop{position:absolute;inset:0;z-index:70;background:var(--dsw-alias-bg-mask-1);display:flex;justify-content:center;align-items:flex-start;padding:24px 12px;overflow-y:auto}',
      '.mX_modal{background:var(--dsw-alias-bg-base);border:0;width:min(640px,100%);max-width:100%;box-shadow:var(--dsw-elevation-prominent);color:var(--dsw-alias-label-primary);border-radius:var(--dsw-radius-lg);display:flex;flex-direction:column;gap:12px;padding:18px;box-sizing:border-box}',
      '.mX_modalTitle{margin:0;font-size:15px;font-weight:600;line-height:22px}',
      '.mX_modalBody{display:flex;flex-direction:column;gap:10px}',
      '.mX_modalFooter{display:flex;justify-content:flex-end;align-items:center;gap:10px;margin-top:4px}',
      '.mX_formRow{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px 12px}',
      '.mX_field{display:flex;flex-direction:column;gap:5px}',
      '.mX_fieldLabel{color:var(--dsw-alias-label-secondary);font-size:12px;font-weight:500;line-height:18px}',
      // 输入档对齐宿主 settings-form 的 .input：显式 H34 + --dsw-radius-md（原来靠 7px 10px 撑高、
      // 圆角写死 8px）。高度必须显式：<select> 复用同一个类时 Chrome 不算继承的 line-height
      // （内容高实测 16px），没有高度就会比同排输入框矮 2px；textarea 由下面的 .mX_textarea 覆盖回 auto。
      '.mX_input{box-sizing:border-box;width:100%;height:34px;padding:0 12px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-3);border:.5px solid var(--dsw-alias-border-l4);border-radius:var(--dsw-radius-md);outline:none;font-family:inherit;font-size:13px;line-height:1.5}',
      '.mX_input:focus{border-color:var(--dsw-alias-state-business-primary)}',
      '.mX_input::placeholder{color:var(--dsw-alias-label-dimmed)}',
      // 多行 textarea 不吃输入档的 H34（官方：textarea 用 height:auto + min-height）与横向内边距。
      '.mX_textarea{height:auto;min-height:64px;padding:8px 12px;resize:vertical;font-family:var(--ds-font-family-code);font-size:12px;line-height:18px}',
      '.mX_hint{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px}',
      // 字段级实时校验（serverName 撞名）：必须排在 `.mX_input:focus` **之后**，
      // 否则聚焦时那抹主题蓝会盖掉标红（两条选择器权重相同，比的是顺序）。
      '.mX_input[data-invalid]{border-color:var(--dsw-alias-state-error-primary)}',
      '.mX_fieldError{color:var(--dsw-alias-state-error-primary);font-size:12px;line-height:18px;margin:0;white-space:pre-wrap}',
      '.mX_fieldError:empty{display:none}',
      '.mX_radioRow{display:flex;align-items:center;gap:16px}',
      '.mX_radioLabel{display:inline-flex;align-items:center;gap:6px;font-size:13px;line-height:20px;cursor:pointer;color:var(--dsw-alias-label-primary)}',
      '.mX_checkRow{display:flex;align-items:center;gap:8px;font-size:13px;line-height:20px;color:var(--dsw-alias-label-primary);cursor:pointer}',
      // 原生复选框按宿主 Checkbox 写：16×16 + accent-color 走中性 brand（浅色近黑）。
      // 用强调蓝 state-business-primary（#4176e6）就是浏览器默认蓝勾那种错——那是状态与徽标的颜色。
      '.mX_checkRow input[type=checkbox]{width:16px;height:16px;margin:0;flex:none;cursor:pointer;accent-color:var(--dsw-alias-brand-primary)}',
      '.mX_checkRow input[type=checkbox]:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:2px}',
      // 该行贡献的工具数：**成本**信息（次级色，与传输/运行中/冲突那些徽标同一行）。
      // 不并进徽标族——本卡的徽标是「状态」语义，工具数是「这一行要付多少常驻上下文」。
      '.mX_metaRow{display:flex;align-items:center;gap:10px;flex-wrap:wrap}',
      '.mX_toolCount{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;font-family:var(--ds-font-family-code)}',
      '.mX_formError{color:var(--dsw-alias-state-error-primary);font-size:12px;line-height:18px;margin:0;white-space:pre-wrap}',
      '.mX_toolWrap{border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-md);flex:none;overflow:hidden}',
      // 试连结果槽：没有结果时是空的，:empty 把节点整个摘出布局——否则它会以 flex gap 的形式
      // 在列表和底栏之间多留 12px（每次打开面板都看得见）。
      '.mX_testPanel:empty{display:none}',
      '.mX_toolHeader{background:var(--dsw-alias-bg-layer-2);border-bottom:.5px solid var(--dsw-alias-border-l1);padding:8px 10px;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);display:flex;gap:12px;flex-wrap:wrap}',
      '.mX_toolList{max-height:220px;overflow-y:auto;padding:4px 0}',
      '.mX_toolItem{padding:5px 10px;font-size:12px;line-height:18px;display:flex;flex-direction:column;gap:2px;border-bottom:.5px solid var(--dsw-alias-border-l2)}',
      '.mX_toolItem:last-child{border-bottom:none}',
      '.mX_toolName{font-family:var(--ds-font-family-code);color:var(--dsw-alias-state-business-primary)}',
      '.mX_toolDesc{color:var(--dsw-alias-label-tertiary)}',
      '.mX_spinner{border:2px solid var(--dsw-alias-state-business-primary);border-top-color:transparent;border-radius:50%;corner-shape:round;width:11px;height:11px;display:inline-block;flex:none;vertical-align:-1px;animation:mXSpin .8s linear infinite}',
      '@keyframes mXSpin{to{transform:rotate(360deg)}}',
      '.mX_toast{position:fixed;left:50%;bottom:36px;transform:translateX(-50%);z-index:200;background:var(--dsw-alias-bg-layer-2);border:0;color:var(--dsw-alias-label-primary);border-radius:var(--dsw-radius-md);padding:9px 16px;font-size:13px;line-height:20px;box-shadow:var(--dsw-elevation-prominent);max-width:70vw}',
      '.mX_toast[data-kind=ok]{color:var(--dsw-alias-state-success-primary);box-shadow:var(--dsw-elevation-prominent), inset 0 0 0 .5px var(--dsw-alias-state-success-primary)}',
      '.mX_toast[data-kind=error]{color:var(--dsw-alias-state-error-primary);box-shadow:var(--dsw-elevation-prominent), inset 0 0 0 .5px var(--dsw-alias-state-error-primary)}',
      // 宿主给的 warning（例如「宿主没有 settings 服务：改动只在本次进程内有效」）走第三档：
      // 它不是错误（这次改动生效了），也不是成功（重启后会丢），所以复用告警色而不是红或绿。
      '.mX_toast[data-kind=warn]{color:var(--dsw-alias-state-warn-primary);box-shadow:var(--dsw-elevation-prominent), inset 0 0 0 .5px var(--dsw-alias-state-warn-primary)}',
      '.mX_mono{font-family:var(--ds-font-family-code)}',
    ].join('\n')

    let styleEl
    function ensureStyle() {
      if (document.getElementById('dsh-mcp-style')) return
      styleEl = document.createElement('style')
      styleEl.id = 'dsh-mcp-style'
      styleEl.textContent = CSS
      document.head.appendChild(styleEl)
    }

    /* ================================ 基础工具 ================================ */

    const ESC_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }
    const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ESC_MAP[c])

    /* ================================ 国际化 ================================ */

    /*
     * 界面文案走宿主 `@deepseek-ai/dsh-client-locale` 的目录（方案见 docs/i18n.md）。
     * 下面这一对目录由 `scripts/check-i18n.mjs` 静态校验：键集必须与英文一一对应、
     * `{name}` 占位符两边一致、代码里 `t('…')` 用到的键必须在这里有定义。
     * 目录**内联在 client.js 里**（不是 client-src/）：本包没有构建步骤，client.js 就是源；
     * 而且一旦凭空建出 client-src/，仓库级「宿主地址来源」静态规则会停止覆盖 client.js。
     *
     * 面板 DOM 是**手写 HTML 字符串**拼的，所以带 `<` / `&` 的文案一律用 `esc(t(...))`
     * 包住（如 `mcp__<serverName>__<tool>`）：原先 `&lt;` 是写死在标记里的，拆成目录后
     * 必须由 esc 负责转义，否则会被 innerHTML 当成标签。
     */
    /* ==== dsh-i18n:begin ==== */
    const I18N_NS = 'mcp'
    const I18N_ZH = {
      'card.name': 'MCP 服务器配置',
      'card.desc': '管理 MCP 服务器：stdio 本地进程或 streamable-http 远程服务；保存后热加载为 mcp__<server>__<tool> 工具，无需重启。',
      'panel.title': 'MCP 服务器',
      'btn.refresh': '刷新',
      'btn.addServer': '+ 添加服务器',
      'btn.test': '测试',
      'btn.edit': '编辑',
      'btn.enable': '启用',
      'btn.disable': '停用',
      'btn.restart': '重连',
      'btn.remove': '删除',
      'btn.cancel': '取消',
      'btn.testConnection': '测试连接',
      'btn.save': '保存',
      'list.statusActive': '运行中',
      'list.notConnected': '未连接',
      'list.statusDisabled': '已停用',
      'list.statusError': '错误',
      'list.statusLoading': '加载中',
      'list.statusNotLoaded': '未加载',
      'list.conflict': 'serverName 冲突',
      'list.toolsCount': '工具 {count}',
      'list.toolsUnknown': '工具数未知',
      'list.toolsCountHint': '该 server 目前在工具注册表里注册的工具数（宿主 DTO 的 toolCount）。显示「未知」表示宿主读不到注册表，不是 0。',
      'list.agentBudget': 'MCP 工具合计 {total} 个，已超过 {budget} 这条阈值：这些工具会常驻每一轮上下文。用不上时停用几行——停用后不再注册工具，也不再占这份成本。',
      'panel.editorCreate': '添加 MCP 服务器',
      'panel.editorEdit': '编辑 MCP 服务器',
      'panel.fieldName': 'serverName（模型侧命名空间，[A-Za-z0-9_-] 1~32 字符）',
      'placeholder.serverName': '例如 github',
      'panel.fieldTransport': '传输方式',
      'panel.transportStdio': ' stdio（本地进程）',
      'panel.transportHttp': ' streamable-http（远程）',
      'panel.fieldCommand': 'command（可执行文件）',
      'panel.fieldCwd': 'cwd（工作目录，可选；目录需已存在）',
      'panel.fieldArgs': 'args（JSON 数组，或每行一个参数）',
      'panel.fieldEnv': 'env（每行 KEY=VALUE；js: 开头为 JS 表达式）',
      'panel.fieldUrl': 'url（MCP 端点）',
      'panel.fieldHeaders': 'headers（每行 KEY=VALUE；js: 开头为 JS 表达式，模板串可引用环境变量）',
      'panel.fieldFailOnStartupError': ' failOnStartupError（启动失败即拒绝加载）',
      'panel.fieldEnabled': ' 启用',
      'panel.fieldReconnect': ' 断线自动重连',
      'panel.hint': 'env/headers 的 VALUE 以 js: 开头会原样写入 !!js 表达式（例如 js:process.env.GITHUB_TOKEN）。保存后服务器会热加载，工具名形如 mcp__<serverName>__<tool>。',
      'banner.fileError': '配置区块异常：{error}（保存一次即可修复）',
      'banner.conflicts': '⚠ 以下 serverName 与本插件之外的 mcp-client 实例重名，两个实例会抢同一套工具名 mcp__<serverName>__*，其中一个必然加载失败：{names}',
      'banner.externalOccupied': '以下名字已被本卡片之外的 mcp-client 实例占用，在本卡片内起名请避开：',
      'banner.externalOccupiedHint': '这些行由别的插件自管（不在本卡片的托管区块里），本卡片管不到它们。同名会让两个 mcp-client 实例抢同一套工具名 mcp__<serverName>__*，其中一个必然加载失败；要改名请到对应插件的设置里改。',
      'msg.hotReload': '改动写入 ~/.dsh/cordis.patch.yml 的托管区块后经 HMR 热加载（约 1~2 秒生效）。env/headers 值以 js: 开头会被当作 !!js 表达式（如 js:process.env.GITHUB_TOKEN）。',
      'msg.testConnecting': '正在连接并列出工具…（最长 25 秒）',
      'msg.testOk': '连接成功',
      'msg.testFailed': '连接失败：{error}',
      'msg.metaDuration': '耗时 {ms}ms',
      'msg.metaProtocol': '协议 {version}',
      'msg.metaServer': '服务器 {name}',
      'msg.metaTools': '工具数 {count}',
      'list.loading': '加载中…',
      'list.empty': '还没有配置 MCP 服务器。',
      'list.emptyHint': '点击右上角「+ 添加服务器」开始：stdio 本地进程或 streamable-http 远程服务都支持。',
      'list.emptyReload': '保存后 DSH 会热加载为 mcp__<serverName>__<tool> 工具，无需重启。',
      'list.separator': '、',
      'error.unknown': '未知错误',
      'error.argsNotArray': 'args 必须是 JSON 字符串数组',
      'error.unparsableLine': '无法解析的行：{line}',
      'error.duplicateName': 'serverName 与已有服务器重复：{name}',
      'error.externalClash': 'serverName「{name}」已被本插件之外的 mcp-client 实例占用（{id}）：两个实例会抢同一套工具名，其中一个必然加载失败。该行由别的插件托管，请到对应插件的设置里修改。',
      'msg.saveFailed': '保存失败：{error}',
      'msg.removeFailed': '删除失败：{error}',
      'msg.updateFailed': '更新失败：{error}',
      'msg.saved': '已保存，正在热加载…',
      'msg.deleted': '已删除，正在热卸载…',
      'msg.updated': '已更新，正在热加载…',
      'msg.restarted': '{name} 已重连，工具已重新注册',
      'msg.restartPending': '{name} 重启已发出，但当前仍未连上（没有任何工具注册）——检查网络 / VPN 后再点一次重连',
      'msg.restartFailed': '重连失败：{error}',
      'msg.testOkHint': '连接成功（确认无误后点保存）',
      'msg.testFailedToast': '连接失败',
      'msg.confirmRemoveLast': '确定删除最后一条 MCP 服务器「{name}」？删除后托管区块会清空，其注册的工具会立即被卸载。',
      'msg.confirmRemove': '确定删除 MCP 服务器「{name}」？其注册的工具会立即被卸载。',
    }
    const I18N_EN = {
      'card.name': 'MCP server configuration',
      'card.desc': 'Manage MCP servers: stdio local processes or streamable-http remote services; saving hot-loads them as mcp__<server>__<tool> tools — no restart needed.',
      'panel.title': 'MCP servers',
      'btn.refresh': 'Refresh',
      'btn.addServer': '+ Add server',
      'btn.test': 'Test',
      'btn.edit': 'Edit',
      'btn.enable': 'Enable',
      'btn.disable': 'Disable',
      'btn.restart': 'Reconnect',
      'btn.remove': 'Remove',
      'btn.cancel': 'Cancel',
      'btn.testConnection': 'Test connection',
      'btn.save': 'Save',
      'list.statusActive': 'Running',
      'list.notConnected': 'Not connected',
      'list.statusDisabled': 'Disabled',
      'list.statusError': 'Error',
      'list.statusLoading': 'Loading',
      'list.statusNotLoaded': 'Not loaded',
      'list.conflict': 'serverName conflict',
      'list.toolsCount': '{count} tools',
      'list.toolsUnknown': 'tool count unknown',
      'list.toolsCountHint': 'How many tools this server currently has in the tool registry (the host DTO’s toolCount). “Unknown” means the host cannot read the registry — that is not 0.',
      'list.agentBudget': 'MCP tools add up to {total}, past the {budget} line: they ride along in every request. Disable a few rows you do not need — a disabled row registers no tools, so it stops costing anything.',
      'panel.editorCreate': 'Add MCP server',
      'panel.editorEdit': 'Edit MCP server',
      'panel.fieldName': 'serverName (model-side namespace, [A-Za-z0-9_-], 1–32 chars)',
      'placeholder.serverName': 'e.g. github',
      'panel.fieldTransport': 'Transport',
      'panel.transportStdio': ' stdio (local process)',
      'panel.transportHttp': ' streamable-http (remote)',
      'panel.fieldCommand': 'command (executable)',
      'panel.fieldCwd': 'cwd (working directory, optional; the directory must already exist)',
      'panel.fieldArgs': 'args (JSON array, or one argument per line)',
      'panel.fieldEnv': 'env (KEY=VALUE per line; a js: prefix is a JS expression)',
      'panel.fieldUrl': 'url (MCP endpoint)',
      'panel.fieldHeaders': 'headers (KEY=VALUE per line; a js: prefix is a JS expression, templates may reference env vars)',
      'panel.fieldFailOnStartupError': ' failOnStartupError (refuse to load when startup fails)',
      'panel.fieldEnabled': ' Enabled',
      'panel.fieldReconnect': ' Reconnect automatically after a drop',
      'panel.hint': 'An env/headers VALUE starting with js: is written as a !!js expression verbatim (e.g. js:process.env.GITHUB_TOKEN). Saving hot-loads the server; tool names look like mcp__<serverName>__<tool>.',
      'banner.fileError': 'Malformed configuration block: {error} (saving once repairs it)',
      'banner.conflicts': '⚠ These serverNames clash with mcp-client instances outside this plugin — both would claim the same tool names mcp__<serverName>__*, and one of them is bound to fail loading: {names}',
      'banner.externalOccupied': 'Already taken by mcp-client instances outside this card — avoid these names here:',
      'banner.externalOccupiedHint': 'These rows are managed by other plugins (they live outside this card’s managed block), so this card cannot change them. A same-named server would make two mcp-client instances claim the same mcp__<serverName>__* tool names and one of them is bound to fail loading; rename it in that plugin’s settings instead.',
      'msg.hotReload': 'Changes are written to the managed block of ~/.dsh/cordis.patch.yml and hot-loaded via HMR (effective in about 1–2 seconds). An env/headers value starting with js: is treated as a !!js expression (e.g. js:process.env.GITHUB_TOKEN).',
      'msg.testConnecting': 'Connecting and listing tools… (up to 25 seconds)',
      'msg.testOk': 'Connected',
      'msg.testFailed': 'Connection failed: {error}',
      'msg.metaDuration': 'took {ms}ms',
      'msg.metaProtocol': 'protocol {version}',
      'msg.metaServer': 'server {name}',
      'msg.metaTools': '{count} tools',
      'list.loading': 'Loading…',
      'list.empty': 'No MCP servers configured yet.',
      'list.emptyHint': 'Click “+ Add server” in the top right to start: both stdio local processes and streamable-http services are supported.',
      'list.emptyReload': 'After saving, DSH hot-loads it as mcp__<serverName>__<tool> tools — no restart needed.',
      'list.separator': ', ',
      'error.unknown': 'unknown error',
      'error.argsNotArray': 'args must be a JSON array of strings',
      'error.unparsableLine': 'Unparsable line: {line}',
      'error.duplicateName': 'serverName already exists: {name}',
      'error.externalClash': 'serverName “{name}” is already taken by an mcp-client instance outside this plugin ({id}): the two instances would fight over the same tool names and one of them is bound to fail loading. That row is managed by another plugin — change it in that plugin’s settings.',
      'msg.saveFailed': 'Could not save: {error}',
      'msg.removeFailed': 'Could not remove: {error}',
      'msg.updateFailed': 'Could not update: {error}',
      'msg.saved': 'Saved, hot-loading…',
      'msg.deleted': 'Removed, hot-unloading…',
      'msg.updated': 'Updated, hot-loading…',
      'msg.restarted': '{name} reconnected; its tools re-registered',
      'msg.restartPending': '{name} restart issued, but it is still not connected (no tools registered) — check the network / VPN and click Reconnect again',
      'msg.restartFailed': 'Reconnect failed: {error}',
      'msg.testOkHint': 'Connected (click Save once it looks right)',
      'msg.testFailedToast': 'Connection failed',
      'msg.confirmRemoveLast': 'Remove the last MCP server “{name}”? The managed block will be emptied and its tools unloaded immediately.',
      'msg.confirmRemove': 'Remove MCP server “{name}”? Its tools will be unloaded immediately.',
    }
    /* ==== dsh-i18n:end ==== */

    /** 占位符替换：`{name}` → params.name（缺参留空，不抛错——文案不该打死界面）。 */
    function i18nFormat(text, params) {
      if (params === undefined) return text
      return String(text).replace(/\{(\w+)\}/g, (_match, name) => (params[name] === undefined ? '' : String(params[name])))
    }

    /** 中文兜底：老宿主（DSH ≤0.1.5）没有 locale 服务时，界面不能变成一串键名。 */
    function i18nFallback(key, params) {
      return i18nFormat(I18N_ZH[key] !== undefined ? I18N_ZH[key] : key, params)
    }

    let t = i18nFallback

    /**
     * 注册目录并绑定翻译函数。**动态 inject**：老宿主上回调永不触发、`t` 保持中文兜底；
     * 写成静态 `inject: ['locale']` 会让整张卡片在老宿主上根本不挂。
     */
    function installI18n(ctx) {
      ctx.inject(['locale'], (i18nCtx) => {
        const disposeZh = i18nCtx.locale.register(I18N_NS, 'zh', I18N_ZH)
        const disposeEn = i18nCtx.locale.register(I18N_NS, 'en', I18N_EN)
        t = i18nCtx.locale.bind(I18N_NS)
        return () => {
          disposeEn()
          disposeZh()
          t = i18nFallback
        }
      })
    }

    /* ================================ API ================================ */

    const API = {
      list: '/api/dsh-mcp/servers',
      save: '/api/dsh-mcp/servers/save',
      test: '/api/dsh-mcp/test',
      restart: '/api/dsh-mcp/restart',
    }

    async function apiRequest(path, options) {
      const res = await fetch(path, options)
      let body = {}
      try {
        body = await res.json()
      } catch {
        /* 非 JSON 响应 */
      }
      if (!res.ok) {
        const err = new Error((body && body.error) || ('HTTP ' + res.status))
        err.code = res.status
        throw err
      }
      return body
    }

    const apiList = () => apiRequest(API.list)
    /*
     * `options.clearAll` 是**显式信号**：只在「用户明确删光」时带上。宿主对「空列表且无该标记」
     * 的保存会返回 400，避免启动竞态 / 陈旧卡片拿到空列表时把已配置的服务器静默清空。
     */
    const apiSave = (servers, options) => {
      const opts = options !== undefined ? options : {}
      return apiRequest(API.save, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          servers,
          ...(opts.clearAll === true ? { clearAll: true } : {}),
        }),
      })
    }
    const apiTest = (config) => apiRequest(API.test, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ config }),
    })
    /*
     * 「重连」= 让宿主把这一行 mcp-client 条目重新挂载一次（工具由它重新注册）。
     * 与 save 的区别：**不改配置**——所以不发整份 servers 列表，只报 id；宿主那边
     * 拿不到 id 会返回 4xx，正好在 catch 里变成一条 toast。
     */
    const apiRestart = (id) => apiRequest(API.restart, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ id }),
    })

    /* ================================ 面板状态 ================================ */

    const state = {
      servers: [],
      // 真正重名的托管行（横幅只渲染这份）；外部实例清单另存 externalServers，两者别混用。
      conflicts: [],
      externalServers: [],
      // 宿主下发的成本阈值（DTO 的 toolBudget）；老宿主没有这个字段 → null → 不提示。
      toolBudget: null,
      // 正在等宿主把 patch 热加载完（见 reloadUntilSettled）：这段时间徽标按**期望态**渲染。
      settling: false,
      fileError: '',
      patchFile: '',
      loading: false,
      busy: false,
      toast: '',
      toastKind: 'info',
      editor: null,
      test: null,
    }

    let toastTimer
    function toast(message, kind) {
      state.toast = message
      state.toastKind = kind || 'info'
      renderToast()
      clearTimeout(toastTimer)
      toastTimer = setTimeout(() => {
        state.toast = ''
        renderToast()
      }, 3200)
    }

    /**
     * 保存类请求的统一收尾：**宿主给的 warning 优先**。
     *
     * 它说的是「宿主没有 settings 服务，改动只在本次进程内有效」这类比「已保存」重要得多的事实；
     * 被后一条 toast 顶掉等于没说（toast 只有一条）。
     */
    function notifySaved(body, message) {
      const warning = body !== undefined && body !== null ? body.warning : undefined
      if (typeof warning === 'string' && warning !== '') toast(warning, 'warn')
      else toast(message, 'ok')
    }

    /* ================================ 渲染：主视图 ================================ */

    /*
     * 状态文案**必须走 getter**：`t()` 在模块加载时求值等于把当前语言冻住——
     * `installI18n(ctx)` 要等 apply 才跑（那时已经晚了），语言切换后这里会永远停在
     * 首次求值的结果上。
     */
    const STATUS_TEXT = {
      get active() { return t('list.statusActive') },
      get disabled() { return t('list.statusDisabled') },
      get error() { return t('list.statusError') },
      get loading() { return t('list.statusLoading') },
      get 'not-loaded'() { return t('list.statusNotLoaded') },
    }
    const STATUS_KIND = { active: 'ok', disabled: '', error: 'error', loading: 'warn', 'not-loaded': '' }

    let panelEl
    let toastEl

    /*
     * 上一次渲染出去的 HTML（判断「要不要真的重绘」用，见 renderAll）。
     * 放在闭包里而不是 DOM 属性上：整份 HTML 有几 KB，塞进 data-* 既难看又会被别处读到。
     */
    let lastRenderedHtml = ''

    function renderAll(container) {
      panelEl = container
      const html = state.editor ? renderEditorHtml() : renderMainHtml()
      /*
       * 内容没变就**别碰 DOM**。
       *
       * 整块 `innerHTML = …` 会把所有节点重建一遍：滚动位置跳回顶部、hover / 焦点全丢。
       * 而保存后有一段轮询（见 reloadUntilSettled），每 600ms 一次整块重建 = 肉眼可见的
       * 「点一下卡片在闪」（2026-10-25 实测反馈）。这里记一份上次渲染的 HTML，逐字相同就跳过；
       * 真变了（状态徽标 / 工具数 / 行集）才重绘一次。
       */
      if (lastRenderedHtml === html) {
        renderToast()
        return
      }
      /*
       * 整块重建会把列表的滚动位置清零（`.mX_list` 是独立滚动容器）。先记下来、重建完放回去——
       * 试连已经改成原地更新（见 refreshTestPanel），但保存 / 刷新 / 行集变化仍会走整块重绘，
       * 不还原就会「滚到某一行操作一下、界面跳回顶部」。
       */
      const listBefore = container.querySelector('.mX_list')
      const listScrollTop = listBefore === null ? 0 : listBefore.scrollTop
      lastRenderedHtml = html
      container.innerHTML = html
      const listAfter = container.querySelector('.mX_list')
      if (listAfter !== null && listScrollTop > 0) listAfter.scrollTop = listScrollTop
      bindEditorEvents(container)
      renderToast()
    }

    function renderToast() {
      if (toastEl === undefined || !toastEl.isConnected) {
        toastEl = document.createElement('div')
        toastEl.className = 'mX_toast'
        document.body.appendChild(toastEl)
      }
      if (state.toast) {
        toastEl.textContent = state.toast
        toastEl.dataset.kind = state.toastKind
        toastEl.style.display = ''
      } else {
        toastEl.style.display = 'none'
      }
    }

    function badge(text, kind, cls) {
      return '<span class="mX_badge' + (cls ? ' ' + cls : '') + '"' + (kind ? ' data-status="' + kind + '"' : '') + '>' + esc(text) + '</span>'
    }

    function transportBadge(transport) {
      return badge(transport === 'stdio' ? 'stdio' : 'http', '', '')
    }

    function summaryOf(server) {
      const config = server.config || {}
      if (config.transport === 'stdio') {
        const command = (config.command || '') + (config.args && config.args.length ? ' ' + config.args.join(' ') : '')
        return config.cwd ? config.cwd + ' $ ' + command : command
      }
      return config.url || ''
    }

    function statusBadge(status) {
      return badge(STATUS_TEXT[status] || status, STATUS_KIND[status] || '')
    }

    /**
     * 徽标显示哪一态：平时用**观测态**（`server.status`，loader 说了算）。
     *
     * 只有「刚保存、正在等 HMR 收敛」的那一两秒（`state.settling`）改按文件里的**期望态**
     * （`server.disabled`）渲染：保存早就成功了，但宿主重读补丁层、重挂 mcp-client 有 1~2 秒
     * 延迟，这期间徽标若继续写「运行中」，用户会以为「点了没反应」（2026-10-25 实测反馈）。
     * 收敛窗口一结束就回到观测态——宿主真的没重载成功时，界面上不会留下一个骗人的「已停用」。
     */
    function displayStatus(server) {
      if (!state.settling) return server.status
      if (server.disabled === true) return 'disabled'
      return server.status === 'disabled' ? 'loading' : server.status
    }

    /**
     * 「运行中但一个工具都没有」按**未连接**显示。
     *
     * 为什么不只看 `status`：mcp-client 连不上时 apply 照样 resolve（`failOnStartupError` 默认
     * false），fiber 还是 active——只看它就会显示「运行中」，可服务器一个工具都没有。工具是
     * 「连接成功 + tools/list」之后唯一会留下的产物，所以 active 且 0 个工具就是没连上。
     * `toolCount === undefined`（宿主读不到注册表）**不猜**；停用的行也不叠加。
     */
    function notConnected(server) {
      return server.status === 'active' && server.disabled !== true && server.toolCount === 0
    }

    /** 状态槽位的 HTML（渲染与原地同步共用同一判据，否则两处迟早不一致）。 */
    function statusSlotHtml(server) {
      return notConnected(server) ? badge(t('list.notConnected'), 'warn', '') : statusBadge(displayStatus(server))
    }


    /** 启停按钮文案（渲染与原地同步共用）。 */
    function toggleLabel(server) {
      return server.disabled ? t('btn.enable') : t('btn.disable')
    }

    /**
     * 只同步「会随宿主变化的那几个点」，**不重建 DOM**。
     *
     * 为什么需要它：整块 `innerHTML = …` 会把列表里所有节点重建一遍（滚动跳、hover / 焦点丢），
     * 而点一次启停、等宿主 HMR 收敛的那几秒里状态会变两三次——逐次整块重绘就是用户看到的
     * 「点一下就闪」（2026-10-25 实测反馈）。这里改成只改状态徽标、工具数与启停文案；
     * 只有**结构性**变化（增删行、编辑器开关）才回落整块重绘。
     */
    function syncLiveState() {
      if (panelEl === undefined || panelEl === null) return
      if (state.editor !== null) {
        refresh()
        return
      }
      const cards = [...panelEl.querySelectorAll('.mX_card[data-id]')]
      if (cards.length !== state.servers.length) {
        refresh()
        return
      }
      const byId = new Map(cards.map((card) => [card.getAttribute('data-id'), card]))
      for (const server of state.servers) {
        const card = byId.get(server.id)
        if (card === undefined) {
          refresh()
          return
        }
        const statusSlot = card.querySelector('[data-role="status"]')
        if (statusSlot !== null) statusSlot.innerHTML = statusSlotHtml(server)
        const toolSlot = card.querySelector('[data-role="toolCount"]')
        if (toolSlot !== null) toolSlot.textContent = toolCountText(server)
        const toggle = card.querySelector('[data-role="toggle"]')
        if (toggle !== null) toggle.textContent = toggleLabel(server)
      }
      renderToast()
    }

    /**
     * 已知工具数的合计（列表上方成本提示用）。
     *
     * 口径与 `scripts/mcp-tool-budget.mjs` 的 `summarizeServers` 逐条对齐：
     *   · 停用的行不注册工具 → 不计入；
     *   · `toolCount === undefined` = 宿主读不到注册表（或该行没连上）→ **不当作 0**，也不计入。
     *
     * 注意这里**没有阈值常量**：阈值由宿主下发（DTO 的 `toolBudget`，宿主侧 `AGENT_TOOL_BUDGET`），
     * 客户端只负责比较——写死一个 80 就是同一件事的第二份真相，换阈值时两边必漂。
     */
    function knownToolTotal(servers) {
      let total = 0
      for (const server of servers) {
        if (server.disabled === true) continue
        if (typeof server.toolCount !== 'number' || !Number.isFinite(server.toolCount)) continue
        total += server.toolCount
      }
      return total
    }

    /** 行上的工具数文案：缺失显示「未知」而不是 0（缺失是「读不到」，不是「没有」）。 */
    function toolCountText(server) {
      return typeof server.toolCount === 'number' && Number.isFinite(server.toolCount)
        ? t('list.toolsCount', { count: server.toolCount })
        : t('list.toolsUnknown')
    }

    /**
     * 「外部占用」脚注：本卡之外还挂着哪些 mcp-client（别的插件自管的行）。
     *
     * 三处刻意与真冲突拉开距离，因为**两者不是一回事**（issue #5 的教训）：
     * 判据不同（这是清单本身，不与托管行求交集；冲突是清单 ∩ 托管行）、颜色不同（中性灰 vs 黄）、
     * 位置不同（列表下方脚注 vs 列表上方横幅）。零重名时它照样显示——它说的是「这些名字被占了」，
     * 不是「你重名了」。**只有真重名才该报警**。
     *
     * 名字逐个渲染成 chip，并把**托管它的 loader 行 id** 放进 title：只给一个 serverName 时，
     * 用户看不出它打哪来（`codegraph` 这种名字尤其像本卡自己的）。
     */
    function renderExternalNoteHtml() {
      const list = state.externalServers || []
      if (list.length === 0) return ''
      const chips = list.map((item) => '<span class="mX_noteName" title="' + esc(item.id) + '">' + esc(item.serverName) + '</span>').join('')
      return '<div class="mX_note" title="' + esc(t('banner.externalOccupiedHint')) + '">'
        + '<i class="mX_noteGlyph">i</i>'
        + '<span>' + esc(t('banner.externalOccupied')) + '</span>'
        + chips
        + '</div>'
    }

    function renderMainHtml() {
      const parts = []
      parts.push('<div class="mX_panel">')
      parts.push('<div class="mX_panelHeader"><h2 class="mX_panelTitle">' + t('panel.title') + '</h2>')
      parts.push('<span class="mX_subtitle" title="' + esc(state.patchFile) + '">' + esc(state.patchFile) + '</span>')
      parts.push('<span class="mX_toolbarSpacer"></span>')
      parts.push('<button class="mX_btnGhost" data-action="refresh"' + (state.loading ? ' disabled' : '') + '>' + t('btn.refresh') + '</button>')
      parts.push('<button class="mX_btn" data-action="add">' + t('btn.addServer') + '</button>')
      parts.push('</div>')
      if (state.fileError) parts.push('<div class="mX_banner" data-kind="error">' + esc(t('banner.fileError', { error: state.fileError })) + '</div>')
      // 冲突横幅只报**真重名**（host 端的 conflicts 已与托管行求过交集）：一条都不相交时
      // 这里什么都不渲染——曾经把「外部实例清单」原样当冲突渲染，于是不重名也常驻报警（issue #5）。
      // 整句也必须 `esc()` 包住：文案里有 `mcp__<serverName>__*`，不转义时 `<serverName>` 会被
      // innerHTML 当成一个未知标签吃掉，用户在界面上看到的是 `mcp____*`（见文件头「带 < 的文案
      // 一律 esc 包住」那条约定——这里当初漏了，缺陷只在**真有冲突**时才可见，所以一直没被发现）。
      if (state.conflicts && state.conflicts.length) {
        parts.push('<div class="mX_banner" data-kind="warn">' + esc(t('banner.conflicts', { names: state.conflicts.map((c) => c.serverName).join(t('list.separator')) })) + '</div>')
      }
      // 成本可见：MCP 工具的数量不由本仓决定，阈值也由宿主下发（DTO 的 toolBudget）——客户端
      // 只比较、不留第二份数字。老宿主不下发就没有阈值，宁可不提示也不写死一个 80。
      const toolTotal = knownToolTotal(state.servers)
      if (!state.loading && typeof state.toolBudget === 'number' && toolTotal > state.toolBudget) {
        parts.push('<div class="mX_banner" data-kind="warn">' + esc(t('list.agentBudget', { total: toolTotal, budget: state.toolBudget })) + '</div>')
      }
      // 外部占用**不在这里**渲染：它是信息不是告警，放在列表下方当脚注（renderExternalNoteHtml），
      // 免得一条「不重名也常驻」的蓝框顶在列表前面被读成报错。
      parts.push('<div class="mX_list">')
      // 「加载中」只在整个列表还空着时占位：已经有行时刷新仍显示旧列表（按钮已置灰），
      // 否则内容高度会瞬间塌掉，滚动位置跟着归零——那正是「点刷新跳回顶部」的另一半原因。
      if (state.loading && state.servers.length === 0) {
        parts.push('<div class="mX_loading">' + t('list.loading') + '</div>')
      } else if (state.servers.length === 0) {
        parts.push('<div class="mX_empty">' + esc(t('list.empty')) + '<br>' + esc(t('list.emptyHint')) + '<br><br>' + esc(t('list.emptyReload')) + '</div>')
      } else {
        for (const server of state.servers) parts.push(renderCardHtml(server))
      }
      parts.push('</div>')
      parts.push(renderExternalNoteHtml())
      // 试连结果单独占一个槽：`runTest()` 只换这一块，不整块重绘（见 refreshTestPanel）。
      parts.push('<div class="mX_testPanel" data-role="testPanel">' + (state.test ? renderTestHtml() : '') + '</div>')
      parts.push('<div class="mX_banner" data-kind="info">' + t('msg.hotReload') + '</div>')
      parts.push('</div>')
      return parts.join('')
    }

    function renderCardHtml(server) {
      const parts = []
      // `data-id` + 三个 `data-role` 槽位是给 `syncLiveState()` 用的：状态 / 工具数 / 启停文案会
      // 随宿主变化，那些变化**不必重建整张卡**（重建就是「闪」），原地改这几个点就够。
      parts.push('<div class="mX_card" data-id="' + esc(server.id) + '">')
      parts.push('<div class="mX_cardRow">')
      parts.push(transportBadge(server.transport))
      parts.push('<span class="mX_cardName">' + esc(server.serverName) + '</span>')
      parts.push('<span data-role="status">' + statusSlotHtml(server) + '</span>')
      if (server.conflict) parts.push(badge(t('list.conflict'), 'warn', ''))
      parts.push('<span class="mX_cardActions">')
      parts.push('<button class="mX_linkBtn" data-action="test" data-id="' + esc(server.id) + '"' + (state.busy ? ' disabled' : '') + '>' + t('btn.test') + '</button>')
      parts.push('<button class="mX_linkBtn" data-action="edit" data-id="' + esc(server.id) + '"' + (state.busy ? ' disabled' : '') + '>' + t('btn.edit') + '</button>')
      parts.push('<button class="mX_linkBtn" data-action="toggle" data-role="toggle" data-id="' + esc(server.id) + '"' + (state.busy ? ' disabled' : '') + '>' + toggleLabel(server) + '</button>')
      // 重连放在安全动作那一组（toggle 之后、发丝线之前）：它不改配置，只让宿主重挂这一行。
      // 停用中没有可重连的条目，所以 disabled 多一条 `server.disabled`。
      parts.push('<button class="mX_linkBtn" data-action="restart" data-id="' + esc(server.id) + '"' + (state.busy || server.disabled ? ' disabled' : '') + '>' + t('btn.restart') + '</button>')
      // 危险动作与上面四个安全动作之间隔一条发丝线：靠位置分组，不靠换样式（删除必须用官方
      // danger 配方，见脚本检查十一）。
      parts.push('<span class="mX_actionSep" aria-hidden="true"></span>')
      parts.push('<button class="mX_btnGhost mX_btnDanger" data-action="remove" data-id="' + esc(server.id) + '"' + (state.busy ? ' disabled' : '') + '>' + t('btn.remove') + '</button>')
      parts.push('</span>')
      parts.push('</div>')
      parts.push('<div class="mX_cardSummary" title="' + esc(summaryOf(server)) + '">' + esc(summaryOf(server)) + '</div>')
      // 该行贡献的工具数：成本信息，单独一行（次级色）。
      parts.push('<div class="mX_metaRow">')
      parts.push('<span class="mX_toolCount" data-role="toolCount" title="' + esc(t('list.toolsCountHint')) + '">' + esc(toolCountText(server)) + '</span>')
      parts.push('</div>')
      parts.push('</div>')
      return parts.join('')
    }

    function renderTestHtml() {
      const test = state.test
      const parts = []
      parts.push('<div class="mX_toolWrap">')
      if (test.running) {
        parts.push('<div class="mX_banner" data-kind="info"><span class="mX_spinner"></span> ' + t('msg.testConnecting') + '</div>')
      } else {
        const result = test.result || {}
        parts.push(result.ok ? '<div class="mX_banner" data-kind="ok">' + t('msg.testOk') + '</div>' : '<div class="mX_banner" data-kind="error">' + t('msg.testFailed', { error: esc(result.error || t('error.unknown')) }) + '</div>')
        const meta = []
        if (result.durationMs !== undefined) meta.push(t('msg.metaDuration', { ms: result.durationMs }))
        if (result.protocolVersion) meta.push(t('msg.metaProtocol', { version: result.protocolVersion }))
        if (result.serverInfo && (result.serverInfo.name || result.serverInfo.version)) meta.push(t('msg.metaServer', { name: [result.serverInfo.name, result.serverInfo.version].filter(Boolean).join(' ') }))
        meta.push(t('msg.metaTools', { count: result.toolsCount || 0 }))
        parts.push('<div class="mX_toolHeader">' + esc(meta.join(' · ')) + '</div>')
        if (result.ok && result.tools && result.tools.length) {
          parts.push('<div class="mX_toolList">')
          for (const tool of result.tools) {
            parts.push('<div class="mX_toolItem"><span class="mX_toolName">mcp__' + esc(test.serverName) + '__' + esc(tool.name) + '</span>')
            if (tool.description) parts.push('<span class="mX_toolDesc">' + esc(String(tool.description).slice(0, 200)) + '</span>')
            parts.push('</div>')
          }
          parts.push('</div>')
        }
      }
      parts.push('</div>')
      return parts.join('')
    }

    /* ================================ 渲染：编辑表单 ================================ */

    function kvToText(map) {
      if (!map) return ''
      return Object.entries(map).map((pair) => pair[0] + '=' + pair[1]).join('\n')
    }

    function renderEditorHtml() {
      const editor = state.editor
      const server = editor.server
      const config = (server && server.config) || {}
      const title = editor.mode === 'create' ? t('panel.editorCreate') : t('panel.editorEdit')
      const transport = config.transport || 'stdio'
      const reconnect = config.reconnect || {}
      const parts = []
      parts.push('<div class="mX_panel">')
      parts.push('<div class="mX_panelHeader"><h2 class="mX_panelTitle">' + esc(title) + '</h2></div>')
      parts.push('<div class="mX_modalBody">')
      parts.push('<div class="mX_formRow">')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_name">' + esc(t('panel.fieldName')) + '</label><input class="mX_input" id="ed_name" placeholder="' + esc(t('placeholder.serverName')) + '" value="' + esc(config.serverName || '') + '"><p class="mX_fieldError" id="ed_nameError"></p></div>')
      parts.push('<div class="mX_field"><span class="mX_fieldLabel">' + esc(t('panel.fieldTransport')) + '</span><span class="mX_radioRow">')
      parts.push('<label class="mX_radioLabel"><input type="radio" name="ed_transport" value="stdio"' + (transport === 'stdio' ? ' checked' : '') + '>' + esc(t('panel.transportStdio')) + '</label>')
      parts.push('<label class="mX_radioLabel"><input type="radio" name="ed_transport" value="streamable-http"' + (transport === 'streamable-http' ? ' checked' : '') + '>' + esc(t('panel.transportHttp')) + '</label>')
      parts.push('</span></div>')
      parts.push('</div>')
      parts.push('<div id="ed_stdio" style="display:' + (transport === 'stdio' ? 'flex' : 'none') + ';flex-direction:column;gap:10px">')
      parts.push('<div class="mX_formRow">')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_command">' + esc(t('panel.fieldCommand')) + '</label><input class="mX_input" id="ed_command" placeholder="npx" value="' + esc(config.command || '') + '"></div>')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_cwd">' + esc(t('panel.fieldCwd')) + '</label><input class="mX_input" id="ed_cwd" placeholder="/path/to/project" value="' + esc(config.cwd || '') + '"></div>')
      parts.push('</div>')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_args">' + esc(t('panel.fieldArgs')) + '</label><textarea class="mX_input mX_textarea" id="ed_args" placeholder="[-y, @modelcontextprotocol/server-filesystem]">' + esc(JSON.stringify(config.args || [])) + '</textarea></div>')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_env">' + esc(t('panel.fieldEnv')) + '</label><textarea class="mX_input mX_textarea" id="ed_env" placeholder="GITHUB_TOKEN=js:process.env.GITHUB_TOKEN">' + esc(kvToText(config.env)) + '</textarea></div>')
      parts.push('</div>')
      parts.push('<div id="ed_http" style="display:' + (transport === 'streamable-http' ? 'flex' : 'none') + ';flex-direction:column;gap:10px">')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_url">' + esc(t('panel.fieldUrl')) + '</label><input class="mX_input" id="ed_url" placeholder="http://localhost:3000/mcp" value="' + esc(config.url || '') + '"></div>')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_headers">' + esc(t('panel.fieldHeaders')) + '</label><textarea class="mX_input mX_textarea" id="ed_headers" placeholder="Authorization=js:process.env.MCP_TOKEN">' + esc(kvToText(config.headers)) + '</textarea></div>')
      parts.push('</div>')
      parts.push('<div class="mX_formRow">')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_timeout">toolCallTimeoutMs</label><input class="mX_input" id="ed_timeout" type="number" min="1" value="' + esc(String(config.toolCallTimeoutMs ?? 60000)) + '"></div>')
      parts.push('<label class="mX_checkRow" style="padding-top:18px"><input type="checkbox" id="ed_failStartup"' + (config.failOnStartupError ? ' checked' : '') + '>' + esc(t('panel.fieldFailOnStartupError')) + '</label>')
      parts.push('<label class="mX_checkRow" style="padding-top:18px"><input type="checkbox" id="ed_enabled"' + (server && server.disabled ? '' : ' checked') + '>' + esc(t('panel.fieldEnabled')) + '</label>')
      parts.push('</div>')
      parts.push('<div class="mX_formRow" style="align-items:end">')
      parts.push('<label class="mX_checkRow" style="padding-top:18px"><input type="checkbox" id="ed_rcEnabled"' + (reconnect.enabled !== false ? ' checked' : '') + '>' + esc(t('panel.fieldReconnect')) + '</label>')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_rcInitial">initialDelayMs</label><input class="mX_input" id="ed_rcInitial" type="number" min="1" value="' + esc(String(reconnect.initialDelayMs ?? 500)) + '"></div>')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_rcMax">maxDelayMs</label><input class="mX_input" id="ed_rcMax" type="number" min="1" value="' + esc(String(reconnect.maxDelayMs ?? 30000)) + '"></div>')
      parts.push('<div class="mX_field"><label class="mX_fieldLabel" for="ed_rcAttempts">maxAttempts</label><input class="mX_input" id="ed_rcAttempts" type="number" min="1" value="' + esc(String(reconnect.maxAttempts ?? 10)) + '"></div>')
      parts.push('</div>')
      parts.push('<p class="mX_formError" id="ed_error"></p>')
      parts.push('<div class="mX_hint">' + esc(t('panel.hint')) + '</div>')
      // 测试结果就地展示在编辑器里（容器固定，由 testEditor 直接改 innerHTML）：
      // 这样「测试连接 → 保存」是一条连续动作，表单与已填内容都留着
      parts.push('<div id="ed_testResult">' + (state.test ? renderTestHtml() : '') + '</div>')
      parts.push('</div>')
      parts.push('<div class="mX_modalFooter">')
      parts.push('<button class="mX_btnGhost" data-action="editor-cancel">' + t('btn.cancel') + '</button>')
      parts.push('<button class="mX_btnGhost" data-action="editor-test"' + (state.busy ? ' disabled' : '') + '>' + t('btn.testConnection') + '</button>')
      parts.push('<button class="mX_btn" data-action="editor-save"' + (state.busy ? ' disabled' : '') + '>' + t('btn.save') + '</button>')
      parts.push('</div>')
      parts.push('</div>')
      return parts.join('')
    }

    function bindEditorEvents(container) {
      if (!state.editor) return
      const toggleSections = () => {
        const stdio = container.querySelector('#ed_stdio')
        const http = container.querySelector('#ed_http')
        const checked = container.querySelector('input[name="ed_transport"]:checked')
        const transport = checked ? checked.value : 'stdio'
        if (stdio) stdio.style.display = transport === 'stdio' ? 'flex' : 'none'
        if (http) http.style.display = transport === 'streamable-http' ? 'flex' : 'none'
      }
      const radios = container.querySelectorAll('input[name="ed_transport"]')
      for (const radio of radios) radio.addEventListener('change', toggleSections)
      toggleSections()
      // serverName 一撞名就当场标红：这是「直观」的主力——用户不必先点保存、再读一条
      // 事后错误。事件挂在 input 上而不是 blur 上，因为撞名多半是边打边发生（打到第 3 个
      // 字符就撞上了）。开表单时先跑一次，编辑一条历史遗留的同名行也能立刻看到原因。
      const nameInput = container.querySelector('#ed_name')
      if (nameInput !== null) {
        nameInput.addEventListener('input', () => validateEditorName())
        validateEditorName()
      }
    }

    function parseArgs(text) {
      const trimmed = (text || '').trim()
      if (trimmed === '') return []
      if (trimmed.startsWith('[')) {
        const parsed = JSON.parse(trimmed)
        if (!Array.isArray(parsed) || parsed.some((item) => typeof item !== 'string')) throw new Error(t('error.argsNotArray'))
        return parsed
      }
      return trimmed.split('\n').map((line) => line.trim()).filter(Boolean)
    }

    function parseKvText(text) {
      const out = {}
      for (const raw of String(text || '').split('\n')) {
        const line = raw.trim()
        if (line === '' || line.startsWith('#')) continue
        const match = line.match(/^([A-Za-z_][A-Za-z0-9_.-]*)\s*[:=]\s*(.*)$/)
        if (match === null) throw new Error(t('error.unparsableLine', { line }))
        out[match[1]] = match[2]
      }
      return out
    }

    function newId() {
      let id = 'mcp-'
      const chars = 'abcdefghijklmnopqrstuvwxyz0123456789'
      if (window.crypto && crypto.randomUUID) {
        id = 'mcp-' + crypto.randomUUID().replace(/-/g, '').slice(0, 10)
      } else {
        for (let i = 0; i < 10; i++) id += chars[Math.floor(Math.random() * chars.length)]
      }
      return id
    }

    function collectEditor() {
      const value = (id) => {
        const input = document.getElementById(id)
        return input ? String(input.value || '').trim() : ''
      }
      const checked = (id) => {
        const input = document.getElementById(id)
        return input ? input.checked : false
      }
      const config = { serverName: value('ed_name') }
      const transportInput = document.querySelector('input[name="ed_transport"]:checked')
      config.transport = transportInput ? transportInput.value : 'stdio'
      if (config.transport === 'stdio') {
        config.command = value('ed_command')
        config.args = parseArgs(document.getElementById('ed_args')?.value || '')
        config.env = parseKvText(document.getElementById('ed_env')?.value || '')
        const cwd = value('ed_cwd')
        if (cwd !== '') config.cwd = cwd
      } else {
        config.url = value('ed_url')
        config.headers = parseKvText(document.getElementById('ed_headers')?.value || '')
      }
      const timeoutText = value('ed_timeout')
      if (timeoutText !== '') config.toolCallTimeoutMs = Number(timeoutText)
      if (checked('ed_failStartup')) config.failOnStartupError = true
      if (checked('ed_rcEnabled')) {
        config.reconnect = {
          enabled: true,
          initialDelayMs: Number(value('ed_rcInitial') || 500),
          maxDelayMs: Number(value('ed_rcMax') || 30000),
          maxAttempts: Number(value('ed_rcAttempts') || 10),
        }
      } else {
        config.reconnect = { enabled: false }
      }
      const row = { id: (state.editor.server && state.editor.server.id) || newId(), config }
      if (!checked('ed_enabled')) row.disabled = true
      return row
    }

    function setEditorError(message) {
      const errorEl = document.getElementById('ed_error')
      if (errorEl) errorEl.textContent = message || ''
    }

    /**
     * serverName 的**字段级**实时校验：撞名当场在输入框下给原因，并把输入框标红。
     *
     * 它只是「一眼看见」，**不是闸门**——真正拒绝保存的是 `saveEditor()`（本地即时反馈，
     * 见下面 externalClash 那段）与宿主侧的 `externalNameRejection()`（权威）。所以这里
     * 刻意**不**禁用保存按钮：历史遗留的同名行要能改别的字段，而「能不能存」由那两道说。
     *
     * 两个判据与保存侧逐字对齐（口径分叉过一次就很难再对齐了）：
     * ① 与本卡其它行重名 → `error.duplicateName`；
     * ② 撞上外部实例名单 → `error.externalClash`，但**这行本来就叫这个名字**时放行。
     */
    function validateEditorName() {
      const input = document.getElementById('ed_name')
      const errorEl = document.getElementById('ed_nameError')
      if (input === null) return ''
      const name = String(input.value || '').trim()
      const setError = (message) => {
        if (errorEl !== null) errorEl.textContent = message
        if (message === '') delete input.dataset.invalid
        else input.dataset.invalid = 'true'
        return message
      }
      const original = state.editor !== null && state.editor.server !== null ? state.editor.server : null
      if (name === '') return setError('')
      const selfId = original !== null ? original.id : null
      if (state.servers.some((server) => server.id !== selfId && server.serverName === name)) {
        return setError(t('error.duplicateName', { name }))
      }
      const clash = (state.externalServers || []).find((item) => item.serverName === name)
      if (clash !== undefined && !(original !== null && original.serverName === name)) {
        return setError(t('error.externalClash', { name, id: clash.id }))
      }
      return setError('')
    }

    /* ================================ 动作 ================================ */

    function refresh() {
      if (panelEl) renderAll(panelEl)
    }

    /**
     * 只重绘**试连结果**那一块（`[data-role="testPanel"]`），不整块重建。
     *
     * 为什么必须单开一条：试连结果渲染在卡片列表**下方**，而列表自己是可滚动的
     * （`.mX_list`，max-height 420px）。整块 `innerHTML` 重建会把列表的滚动位置清零——用户滚到
     * 某一行点「测试」，界面当场跳回顶部（2026-10-25 实测反馈）。这一块不在列表里，单独换它，
     * 列表的滚动 / hover / 焦点全都留着。
     */
    function refreshTestPanel() {
      if (panelEl === undefined || panelEl === null) return
      const slot = panelEl.querySelector('[data-role="testPanel"]')
      if (slot === null) {
        // 当前不是主视图（编辑器打开 / 还没渲染过）：退回整块重绘。
        refresh()
        return
      }
      slot.innerHTML = state.test ? renderTestHtml() : ''
      // 缓存要跟着走：否则下一次 refresh() 会以为 HTML 变了而整块重建，又把列表滚回顶部。
      lastRenderedHtml = state.editor ? renderEditorHtml() : renderMainHtml()
      renderToast()
    }

    /**
     * 把宿主 DTO 写回 state。
     *
     * **GET 列表与 POST 保存的响应是同一份形状**，所以两边共用这一处：保存成功后不必再发一次
     * GET 就能拿到权威的 `servers`（宿主现算的 status / toolCount 就在里面）与 `toolBudget`。
     */
    function applyServersDto(body) {
      const dto = body !== undefined && body !== null ? body : {}
      state.servers = Array.isArray(dto.servers) ? dto.servers : []
      state.conflicts = Array.isArray(dto.conflicts) ? dto.conflicts : []
      state.externalServers = Array.isArray(dto.externalServers) ? dto.externalServers : []
      // 阈值只在宿主**真的下发**时才存（缺失 = 老宿主，不是 0：0 会让每一行都报警）。
      state.toolBudget = typeof dto.toolBudget === 'number' ? dto.toolBudget : null
      state.fileError = dto.fileError || ''
      state.patchFile = dto.patchFile || ''
    }

    /**
     * 拉一次列表。
     *
     * `quiet` = 轮询专用：不翻 `state.loading`、不自己主动重绘（由调用方决定何时 `refresh()`）。
     * 不安静的话，等待收敛的那几秒里每次都要「置 loading → 重绘 → 复位 → 再重绘」，按钮与整块
     * 列表跟着抖——这正是用户看到的「闪动」。
     */
    async function load(options) {
      const quiet = options !== undefined && options.quiet === true
      if (state.loading) return
      if (!quiet) {
        state.loading = true
        refresh()
      }
      try {
        applyServersDto(await apiList())
      } catch (error) {
        state.fileError = error instanceof Error ? error.message : String(error)
      } finally {
        if (!quiet) {
          state.loading = false
          refresh()
        }
      }
    }

    /**
     * 每一行的**观测态**（loader 的 fiber 状态）是否已经追上了文件里的**期望态**（`disabled`）。
     *
     * 两者不是一回事：保存请求把 `disabled` 写进托管区块只需要一次写盘，而 `status` 要等宿主
     * 重读补丁层、重挂 / 卸下那条 mcp-client 条目（HMR 约 1~2 秒）才会变。中间这段时间里
     * 「点完停用仍显示运行中」不是没生效，只是还没重载完。
     */
    function statusSettled() {
      return state.servers.every((server) => {
        if (server.disabled === true) return server.status === 'disabled'
        /*
         * 启用方向必须等它**真的起来**：`loading` 是过渡态（宿主还在重挂那条 mcp-client、
         * 或还在跟 server 握手，连不上时最长要等一次连接尝试）。只判 `!== 'disabled'` 会在
         * status 刚变成 `loading` 的那一刻就收工、此后不再轮询——徽标就冻在「加载中 / 工具 0」，
         * 而宿主上其实早就 active 了（实测：dbx 已是 active + 25 个工具，卡片还写着加载中）。
         */
        return server.status !== 'disabled' && server.status !== 'loading'
      })
    }

    /**
     * 保存之后**轮询到收敛**，而不是等一个固定延迟再读一次。
     *
     * 原来是 `setTimeout(() => load(), 800)`：800ms 通常**早于** HMR 完成，于是拿到的是旧
     * `status`，而且只读这一次——徽标就永远停在「运行中」，直到用户手动点「刷新」（2026-10-25
     * 实测反馈）。固定改成 2s 也只是把「永远不更新」换成「在慢机器上还是不更新」，所以这里按
     * **收敛条件**轮询（有上限：8 秒后放弃，按真实状态渲染，不假装成功）。
     */
    async function reloadUntilSettled(timeoutMs = 20000) {
      state.settling = true
      // 只原地改状态徽标 / 工具数：不重建 DOM，所以点完按钮不会有整块刷新感。
      syncLiveState()
      const deadline = Date.now() + timeoutMs
      try {
        for (;;) {
          await load({ quiet: true })
          syncLiveState()
          if (statusSettled() || Date.now() >= deadline) return
          await new Promise((resolve) => setTimeout(resolve, 600))
        }
      } finally {
        state.settling = false
        syncLiveState()
      }
    }

    function openEditor(mode, server) {
      state.editor = { mode, server: server || null }
      state.test = null
      refresh()
    }

    function closeEditor() {
      state.editor = null
      refresh()
    }

    async function saveEditor() {
      let row
      try {
        row = collectEditor()
      } catch (error) {
        setEditorError(error instanceof Error ? error.message : String(error))
        return
      }
      const others = state.servers.filter((server) => server.id !== row.id)
      if (others.some((server) => server.serverName === row.config.serverName)) {
        setEditorError(t('error.duplicateName', { name: row.config.serverName }))
        return
      }
      // 外部实例同名（别的插件托管的 mcp-client，如 codegraph 归 Codegraph 插件管）：本地先拦
      // 一道给即时反馈；宿主侧还会再拦一次（权威）。比的是**外部实例清单**（externalServers），
      // 不是 conflicts——conflicts 只是「已经重名」的那几行，这里要拦的是任何撞上外部名单的新名字。
      // 已经是这一行原本的名字（历史遗留）不拦，否则连它的其它字段都改不了 —— 宿主侧同样按「是否新引入」判定。
      const clash = (state.externalServers || []).find((item) => item.serverName === row.config.serverName)
      const original = state.editor !== null && state.editor.server !== null ? state.editor.server : null
      if (clash !== undefined && !(original !== null && original.serverName === row.config.serverName)) {
        setEditorError(t('error.externalClash', { name: row.config.serverName, id: clash.id }))
        return
      }
      const servers = [...others, row]
      state.busy = true
      setEditorError('')
      try {
        // 响应与 GET 是同一份 DTO：先落 state 再收尾，界面立刻是保存后的样子（不用等下一次轮询）。
        const body = await apiSave(servers)
        applyServersDto(body)
        notifySaved(body, t('msg.saved'))
        state.editor = null
        void reloadUntilSettled()
      } catch (error) {
        setEditorError(error instanceof Error ? error.message : String(error))
        toast(t('msg.saveFailed', { error: error instanceof Error ? error.message : String(error) }), 'error')
      } finally {
        // 不重绘：`reloadUntilSettled` 的 `syncLiveState()` 会按需原地更新 / 结构变了才整块重绘。
        state.busy = false
      }
    }

    async function removeServer(id) {
      const server = state.servers.find((item) => item.id === id)
      if (server === undefined) return
      // 删掉最后一条＝清空托管区块，确认文案要说清这一点，保存时也要显式带 clearAll
      const last = state.servers.length === 1
      const question = last
        ? t('msg.confirmRemoveLast', { name: server.serverName })
        : t('msg.confirmRemove', { name: server.serverName })
      if (!window.confirm(question)) return
      const servers = state.servers.filter((item) => item.id !== id)
      /*
       * 只置忙、**不重绘**：整块 `innerHTML` 重建就是用户看到的「点一下卡片在闪」。
       * 请求在本机是毫秒级返回的，按钮短暂仍可点（真要连点两下，第二次会以新 state 再算一次，
       * 结果仍然是幂等的翻转）；换来的是点完只重绘一次（收敛时那一次，且内容没变就跳过）。
       */
      state.busy = true
      try {
        const body = await apiSave(servers, { clearAll: last })
        applyServersDto(body)
        notifySaved(body, t('msg.deleted'))
        void reloadUntilSettled()
      } catch (error) {
        toast(t('msg.removeFailed', { error: error instanceof Error ? error.message : String(error) }), 'error')
      } finally {
        state.busy = false
      }
    }

    async function toggleServer(id) {
      const servers = state.servers.map((server) => (server.id === id ? { ...server, disabled: !server.disabled } : server))
      /*
       * 只置忙、**不重绘**：整块 `innerHTML` 重建就是用户看到的「点一下卡片在闪」。
       * 请求在本机是毫秒级返回的，按钮短暂仍可点（真要连点两下，第二次会以新 state 再算一次，
       * 结果仍然是幂等的翻转）；换来的是点完只重绘一次（收敛时那一次，且内容没变就跳过）。
       */
      state.busy = true
      try {
        const body = await apiSave(servers)
        applyServersDto(body)
        notifySaved(body, t('msg.updated'))
        void reloadUntilSettled()
      } catch (error) {
        toast(t('msg.updateFailed', { error: error instanceof Error ? error.message : String(error) }), 'error')
      } finally {
        state.busy = false
      }
    }

    /*
     * 「重连」：让宿主把这一行 mcp-client 条目重挂一次，工具随之重新注册。
     *
     * 形状照 toggleServer：置忙 → 请求 → applyServersDto → notifySaved → 轮询到收敛，
     * **不整卡重绘**（重建就是用户看到的「点一下在闪」）。
     * 收尾必须走 notifySaved：宿主在超时里返回 `warning`（「已经重连但工具还没注册完」之类），
     * 那条比「已重连」重要，toast 只有一条，所以由它决定显示哪句。
     */
    async function restartServer(id) {
      const server = state.servers.find((item) => item.id === id)
      if (server === undefined) return
      state.busy = true
      try {
        const body = await apiRestart(id)
        applyServersDto(body)
        /*
         * 提示语按**宿主的判据**分两种，绝不一律说「已重连」：
         * `connection === 'connected'` 才是真的重新注册上了；`pending` 表示重启发出了、
         * 但预算内没有任何工具回到注册表（人不在内网时永远是这一档）。
         *
         * 2026-11-18 真机事故：原来无条件报「已重连，工具会重新注册」，而同一行还显示着
         * 「未连接 / 工具 0」——提示在撒谎。`connection` 缺失（老宿主）时退回中性说法。
         */
        const connected = body !== undefined && body !== null && body.connection === 'connected'
        const pending = body !== undefined && body !== null && body.connection === 'pending'
        const fallback = t('msg.restarted', { name: server.serverName })
        const message = connected
          ? t('msg.restarted', { name: server.serverName })
          : pending
            ? t('msg.restartPending', { name: server.serverName })
            : fallback
        notifySaved(body, message)
        void reloadUntilSettled()
      } catch (error) {
        toast(t('msg.restartFailed', { error: error instanceof Error ? error.message : String(error) }), 'error')
      } finally {
        state.busy = false
      }
    }

    async function runTest(server) {
      state.test = { serverName: server.serverName, running: true, result: null }
      state.editor = null
      refreshTestPanel()
      try {
        const body = await apiTest(server.config)
        state.test = { serverName: server.serverName, running: false, result: body.result || {} }
      } catch (error) {
        state.test = { serverName: server.serverName, running: false, result: { ok: false, error: error instanceof Error ? error.message : String(error), toolsCount: 0 } }
      }
      refreshTestPanel()
    }

    /**
     * 编辑器里的「测试连接」。
     *
     * 两条硬约束（都是实测踩出来的）：
     *   1. **不关编辑器**——测试只是确认配置能不能连上，紧接着就要点「保存」。早先这里把
     *      `state.editor` 置空，而编辑器是整块替换渲染（`editor ? editorHtml : mainHtml`），
     *      于是表单连同「保存」按钮一起消失，用户看到的就是「一点测试连接，保存就没了」。
     *   2. **不整体重渲染**——用户的输入只活在 DOM 里（渲染始终以原始 config 为源），
     *      `refresh()` 一次就把填好的内容冲回原样。所以结果只就地写进 `#ed_testResult`，
     *      按钮的禁用/恢复也直接改 DOM。
     */
    async function testEditor() {
      let row
      try {
        row = collectEditor()
      } catch (error) {
        setEditorError(error instanceof Error ? error.message : String(error))
        return
      }
      setEditorError('')
      const setBusy = (busy) => {
        state.busy = busy
        for (const el of document.querySelectorAll('[data-action="editor-test"], [data-action="editor-save"]')) {
          if (el instanceof HTMLButtonElement) el.disabled = busy
        }
      }
      state.test = { serverName: row.config.serverName, running: true, result: null }
      const running = document.getElementById('ed_testResult')
      if (running !== null) running.innerHTML = renderTestHtml()
      setBusy(true)
      try {
        const body = await apiTest(row.config)
        state.test = { serverName: row.config.serverName, running: false, result: body.result || {} }
        toast(body.result && body.result.ok ? t('msg.testOkHint') : t('msg.testFailedToast'), body.result && body.result.ok ? 'ok' : 'error')
      } catch (error) {
        // 请求本身失败（路由/网络）：清掉「正在连接…」，把原因写进编辑器错误行
        state.test = null
        setEditorError(error instanceof Error ? error.message : String(error))
      } finally {
        setBusy(false)
        const host = document.getElementById('ed_testResult')
        if (host !== null) host.innerHTML = state.test === null ? '' : renderTestHtml()
      }
    }

    /* ================================ 事件委托 ================================ */

    function handleClick(event) {
      const target = event.target
      if (!(target instanceof Element)) return
      /*
       * 作用域：只处理**自己卡片 DOM 内**的点击。
       * 为什么必须有：prompt 卡片的按钮也用通用 `data-action`（refresh / edit / editor-save
       * 与这里同名），不判作用域时点 prompt 的「刷新」「编辑」「保存」都会落到这里，
       * 拿 undefined 的 id 去操作 MCP 服务器（轻则空跑；MCP 编辑态开着时会把那张表单存下去）。
       * 2026-10-03 实测过同一类：profile 的「删除」被 prompt 的处理器接走并报错。
       */
      if (panelEl === undefined || !panelEl.contains(target)) return
      const actionEl = target.closest('[data-action]')
      if (actionEl === null || actionEl.disabled) return
      const action = actionEl.dataset.action
      const id = actionEl.dataset.id
      if (action === 'refresh') load()
      else if (action === 'add') openEditor('create')
      else if (action === 'edit') {
        const server = state.servers.find((item) => item.id === id)
        if (server) openEditor('edit', server)
      } else if (action === 'remove') removeServer(id)
      else if (action === 'toggle') toggleServer(id)
      else if (action === 'restart') restartServer(id)
      else if (action === 'test') {
        const server = state.servers.find((item) => item.id === id)
        if (server) runTest(server)
      } else if (action === 'editor-cancel') closeEditor()
      else if (action === 'editor-save') saveEditor()
      else if (action === 'editor-test') testEditor()
    }

    /* ================================ 面板宿主挂载 ================================ */

    function mountDomPanel(host) {
      if (panelEl !== undefined && panelEl.isConnected && panelEl.parentElement === host) return
      if (panelEl !== undefined) panelEl.remove()
      panelEl = document.createElement('div')
      panelEl.className = 'mX_panelHost'
      host.appendChild(panelEl)
      renderAll(panelEl)
    }

    /* ================================ 设置卡片（React 外壳） ================================ */

    const CHEVRON_PATH = 'M11.8486 5.5L11.4238 5.92383L8.69727 8.65137C8.44157 8.90706 8.21562 9.13382 8.01172 9.29785C7.79912 9.46883 7.55595 9.61756 7.25 9.66602C7.08435 9.69222 6.91565 9.69222 6.75 9.66602C6.44405 9.61756 6.20088 9.46883 5.98828 9.29785C5.78438 9.13382 5.55843 9.13382 5.30273 8.65137L2.57617 5.92383L2.15137 5.5L3 4.65137L3.42383 5.07617L6.15137 7.80273C6.42595 8.07732 6.59876 8.24849 6.74023 8.3623C6.87291 8.46904 6.92272 8.47813 6.9375 8.48047C6.97895 8.48703 7.02105 8.48703 7.0625 8.48047C7.07728 8.47813 7.12709 8.46904 7.25977 8.3623C7.40124 8.24849 7.57405 8.07732 7.84863 7.80273L10.5762 5.07617L11 4.65137L11.8486 5.5Z'

    function McpSettingsCard(props) {
      // DSH ≥0.1.6 的插件配置页把同一条目按 view 渲染两次：summary 一句话摘要、page 完整表单。
      // 旧版（≤0.1.5）的 settings.plugin.item 卡片不带 view，走原有可折叠卡片分支。
      const view = props && props.view
      const pageView = view === 'page'
      const [open, setOpen] = React.useState(pageView)
      const hostRef = React.useRef(null)
      React.useEffect(() => {
        if (!open) return
        const host = hostRef.current
        if (host === null) return
        mountDomPanel(host)
        load()
      }, [open])
      if (view === 'summary') {
        return t('card.desc')
      }

      // page 视图：新页面自己画标题/图标/面包屑，这里只交表单本体，不渲染卡片头。
      return jsxs(pageView ? 'div' : 'li', {
        className: pageView ? 'mX_pageHost' : (open ? 'mX_pluginCard mX_pluginCardOpen' : 'mX_pluginCard'),
        children: [
          pageView ? null : jsxs('button', {
            type: 'button',
            className: 'mX_cardHeader',
            'aria-expanded': open,
            onClick: () => setOpen((current) => !current),
            children: [
              jsxs('span', {
                className: 'mX_cardHeadText',
                children: [
                  jsx('span', { className: 'mX_cardName', children: t('card.name') }),
                  jsx('span', { className: 'mX_cardDescription', children: t('card.desc') }),
                ],
              }),
              jsx('span', { className: 'dshkit_badge', children: 'Kit' }),
              jsx('svg', {
                width: '14',
                height: '14',
                viewBox: '0 0 14 14',
                fill: 'none',
                xmlns: 'http://www.w3.org/2000/svg',
                className: 'mX_chevron',
                children: jsx('path', { d: CHEVRON_PATH, fill: 'currentColor' }),
              }),
            ],
          }),
          (pageView || open) ? jsx('div', {
            className: 'mX_cardBody',
            children: jsx('div', { ref: hostRef, className: 'mX_cardHost' }),
          }) : null,
        ],
      })
    }

    /* ================================ 插件入口 ================================ */

    exports.inject = ['slots']

    /**
     * DSH ≥0.1.6-alpha.2 的行配置 key：`<bundle 包名>#<行 id>`，行 id 取自 bundle 的
     * cordis.patch.yml。独立安装时 bundle 是本包，装全家桶时是 @hyzyn/dsh-all —— 两个都注册，
     * 未命中的那个只是躺在 ledger 里，不会渲染。
     */
    const ROW_CONFIG_KEYS = [
      '@hyzyn/dsh-mcp#mcp-config',
      '@hyzyn/dsh-all#mcp-config',
    ]

    exports.apply = (ctx) => {
      installI18n(ctx)
      ctx.effect(() => {
        ensureStyle()
        // 面板 DOM 点击委托：挂在 document 上，避免随重渲染丢失
        document.addEventListener('click', handleClick, true)
        return () => {
          document.removeEventListener('click', handleClick, true)
          styleEl?.remove()
          styleEl = undefined
          toastEl?.remove()
          toastEl = undefined
          panelEl?.remove()
          panelEl = undefined
        }
      })
      // 注册到官方插件配置 → 可配置 卡片列表（与终端 / Agent 循环 / 网页搜索同级）
      /*
       * 设置面：0.2.0-rc.1 起挂 `plugins.bundle.config`——key 是 **bundle 包名**，管理器的插件
       * 详情页把它渲染在「说明」正下方；`plugins.row.config` 是 per-row 的「>」子页。
       *
       * 两条硬约束（第一条踩过坑，见下）：
       *   ① `plugins.bundle.config` 的 key 是**共享命名空间**：同一个 key 只能有一个注册者，
       *      重复注册**直接抛错**（`keyed slot ... already has an entry`），而客户端 `apply`
       *      抛错 = 整个插件起不来（实测：把 `@hyzyn/dsh-all` 也挂上时，八个插件抢同一个 key，
       *      启动页直接变「Failed to load plugins」）（D158）。聚合包 `@hyzyn/dsh-all` 是所有插件共用的
       *      bundle，**不能**挂 bundle.config —— 它没有内联位，设置面走它自己的 row 入口。
       *   ② 内联位可用时，**本包自己的** bundle 不再注册 row 槽（同一份表单两个入口会让人以为
       *      有两套设置）；聚合包那份 row 入口**保留**（那是它在聚合安装下的唯一入口）。旧宿主
       *      （bundle 槽不存在，0.1.6 线）回退注册全部 row 槽，功能一点不减。
       * 就绪顺序不敏感：任一侧先到都收敛到「内联优先」（后到的本包 row 注册会被撤掉）。
       */
      const AGGREGATE_BUNDLE = '@hyzyn/dsh-all'
      const BUNDLE_NAMES = [...new Set(ROW_CONFIG_KEYS.map((key) => key.split('#')[0]))]
      const OWN_BUNDLE = BUNDLE_NAMES.find((name) => name !== AGGREGATE_BUNDLE)
      let bundleConfigLive = false
      const disposeOwnRowConfigs = []
      if (OWN_BUNDLE !== undefined) {
        ctx.slots.inject('plugins.bundle.config', () => {
          bundleConfigLive = true
          while (disposeOwnRowConfigs.length > 0) {
            const disposeRow = disposeOwnRowConfigs.pop()
            if (typeof disposeRow === 'function') disposeRow()
          }
          return ctx.slots.register({
            name: 'plugins.bundle.config',
            key: OWN_BUNDLE,
          }, McpSettingsCard)
        })
      }
      for (const key of ROW_CONFIG_KEYS) {
        ctx.slots.inject('plugins.row.config', () => {
          const own = key.split('#')[0] === OWN_BUNDLE
          if (own && bundleConfigLive) return undefined
          const disposeRow = ctx.slots.register({
            name: 'plugins.row.config',
            key,
          }, McpSettingsCard)
          if (own) disposeOwnRowConfigs.push(disposeRow)
          return disposeRow
        })
      }
      // DSH ≥0.1.6：设置里与「通用设置」平级的「插件配置」页（子 slot 由
      // @hyzyn/dsh-kit-settings 声明）。不传 view，卡片走各自原有的可折叠形态。
      ctx.slots.inject('settings.kit.item', () => ctx.slots.register({
        name: 'settings.kit.item',
        id: 'mcp-config',
        order: 20,
        label: () => t('card.name'),
      }, McpSettingsCard))
      // DSH ≤0.1.5：设置 → 插件 的「插件配置」标签页，keyed 插槽按 settings 命名空间派发。
      ctx.slots.inject('settings.plugin.item', () => ctx.slots.register({
        name: 'settings.plugin.item',
        // settings.plugin.item 是 keyed 插槽：key 必须是该卡片所编辑的 settings 命名空间
        key: 'mcp-config',
        order: 96,
      }, McpSettingsCard))
    }

    return exports
  },
})
