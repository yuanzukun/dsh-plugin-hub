/* eslint-disable */
/**
 * @hyzyn/dsh-rss — 浏览器半体：设置 → 插件 →「RSS / 新闻聚合」卡片。
 * 设置面：0.2.0-rc.1 起挂 plugins.bundle.config（插件详情页「说明」下方内联），
 * 旧宿主回退到 0.1.6 线的 plugins.row.config / ≤0.1.5 的 settings.plugin.item，跨版本兼容。
 * 支持在设置页顶部直接预览今日 digest（统计 / 失败告警 / 查看、刷新、复制），
 * 维护订阅渠道 / 新闻分类，浏览搜索 awesome-rsshub-routes 精选订阅源目录并一键添加订阅；
 * 侧边栏「今日值得读」弹窗支持搜索、按分类筛选、复制 Markdown。
 *
 * 渲染采用「分区块更新」：输入、目录搜索、增删渠道只重建受影响区块，
 * 不再整面板 innerHTML 替换，避免焦点 / 光标 / 滚动丢失。
 */
window.__ModuleLoader__.load({
  id: '@hyzyn/dsh-rss',
  factory: (require) => {
    const exports = {}

    const React = require('react')
    const { jsx, jsxs } = require('react/jsx-runtime')

    /* ================================ CSS ================================ */

    const CSS = [
      '.rss_pageHost{display:block}',
      '.rss_pluginCard{list-style:none;border:.5px solid var(--dsw-alias-settings-card-stroke);background:var(--dsw-alias-settings-card-fill);border-radius:var(--dsw-radius-xl);transition:border-color .16s,background .16s}',
      '.rss_pluginCard:hover{border-color:var(--dsw-alias-label-dimmed)}',
      '.rss_pluginCardOpen{background:var(--dsw-alias-bg-layer-1);border-color:var(--dsw-alias-label-dimmed)}',
      '.rss_cardHeader{appearance:none;width:100%;color:inherit;font:inherit;text-align:left;cursor:pointer;background:0 0;border:0;border-radius:var(--dsw-radius-xl);display:flex;align-items:center;gap:12px;padding:14px 16px}',
      '.rss_cardHeader:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:-2px}',
      '.rss_cardHeadText{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}',
      // 卡片标题 = 宿主 cardTitle 的角色（14 / 500 / 20）；说明行是正文 12/18。
      // 行高按官方成对值写（规范：font-size 必须配 line-height）。
      '.rss_cardName{color:var(--dsw-alias-label-primary);font-size:14px;font-weight:500;line-height:20px}',
      '.dshkit_badge{flex:none;margin-left:auto;padding:1px 8px;border-radius:999px;corner-shape:round;font-size:11px;font-weight:600;line-height:16px;letter-spacing:.02em;color:var(--dsw-alias-label-dimmed);background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1)}',
      '.rss_cardDescription{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px}',
      '.rss_chevron{flex:none;color:var(--dsw-alias-label-tertiary);transition:transform .16s}',
      '.rss_pluginCardOpen .rss_chevron{transform:rotate(180deg)}',
      '.rss_cardBody{padding:2px 16px 16px}',
      '.rss_panel{display:flex;flex-direction:column;gap:12px;color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-family);box-sizing:border-box}',
      '.rss_panelHeader{display:flex;align-items:center;gap:8px 10px;flex:none;flex-wrap:wrap;position:sticky;top:0;z-index:20;background:var(--dsw-alias-bg-layer-3);padding:8px 0;margin:-2px 0 0}',
      '.rss_panelTitle{margin:0;font-size:15px;font-weight:500;line-height:22px;white-space:nowrap;flex:1;min-width:0}',
      '.rss_toolbar{display:flex;align-items:center;justify-content:flex-end;gap:8px;flex:1 1 100%;min-width:0;flex-wrap:wrap}',
      // 按钮族对齐宿主 ui-primitives 的 Button：本包属 H28 档，故统一取官方 size="sm"
      // （H28 / R8 / 12px + 18px / padding 0 10px），填充与描边**逐项同尺寸**。
      // 底色从 --dsw-alias-button-info-fill 换成 button-primary-fill：前者是宿主给图标/徽标/
      // 圆形发送键的**强调蓝**，后者才是 .primary 的填充（浅色近黑、深色近白）；不设字重。
      '.rss_btn{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:4px;height:28px;padding:0 10px;border:none;border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground);font-family:inherit;font-size:12px;line-height:18px;white-space:nowrap;cursor:pointer}',
      '.rss_btn:hover:not(:disabled){background:var(--dsw-alias-button-primary-hover)}',
      '.rss_btn:disabled{opacity:.4;cursor:not-allowed}',
      '.rss_btn:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary))}',
      // 描边档 = Button variant="outline" size="sm"：尺寸与主按钮逐项一致，只差描边与底色；
      // 描边取 border-l3（宿主 .outline 那一档）。焦点环去掉 outline-offset——宿主 51 处官方写法都不带。
      '.rss_btnGhost{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:4px;height:28px;padding:0 10px;border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-sm);background:transparent;color:var(--dsw-alias-label-primary);font-family:inherit;font-size:12px;line-height:18px;white-space:nowrap;cursor:pointer}',
      '.rss_btnGhost:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}',
      '.rss_btnGhost:active:not(:disabled){background:var(--dsw-alias-interactive-bg-active)}',
      '.rss_btnGhost:disabled{opacity:.4;cursor:not-allowed}',
      '.rss_btnGhost:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary))}',
      // 危险按钮 = 宿主 plugin-manager「卸载」的 danger 配方（透明底 + 30% 红描边 + 8% 红 hover），
      // 与 docker / codegraph / env / mcp 的 *.btnDanger 同一套。用法：class="rss_btnGhost rss_btnDanger"
      // （几何与禁用态/焦点态都走 .rss_btnGhost，这里只覆盖颜色）。
      // 必须写在 .rss_btnGhost:hover 之后：两者权重相同，先写会被中性灰 hover 盖掉。
      // 此前这里是红字链接 + 点状下划线——那是「链接」的示能，不是按钮。
      '.rss_btnDanger{color:var(--dsw-alias-state-error-primary);border-color:color-mix(in srgb,var(--dsw-alias-state-error-primary) 30%,transparent)}',
      '.rss_btnDanger:hover:not(:disabled){background:color-mix(in srgb,var(--dsw-alias-state-error-primary) 8%,transparent)}',
      // 图标按钮不带可见边框：这个家族里图标按钮一律靠 hover 底色表达可点（宿主 .hHd-Xa_iconButton、
      // 同弹窗 .rss_modalClose、docker .dk_iconBtn 都如此），边框是文字按钮的语汇。
      // 仍留 1px transparent 占位，保证盒子尺寸与 hover 时不跳动。
      // 尺寸与圆角不动（28×28 → R8 本就合规），只统一状态：禁用 .4 + not-allowed、补 :active，
      // 焦点环与描边按钮同一条官方 outline；圆角写成 token（值仍是 R8，视觉不变）。
      '.rss_btnIcon{width:28px;height:28px;padding:0;border:1px solid transparent;border-radius:var(--dsw-radius-sm);background:0 0;color:var(--dsw-alias-label-secondary);display:inline-flex;align-items:center;justify-content:center;flex:none;transition:background .16s,color .16s}',
      '.rss_btnIcon:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}',
      '.rss_btnIcon:active:not(:disabled){background:var(--dsw-alias-interactive-bg-active)}',
      '.rss_btnIcon:disabled{opacity:.4;cursor:not-allowed}',
      '.rss_btnIcon:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary))}',
      '.rss_btnIcon svg{display:block}',
      '@keyframes rss_spin{to{transform:rotate(360deg)}}',
      '.rss_btnIcon[data-loading] svg{animation:rss_spin .9s linear infinite}',
      '@media (prefers-reduced-motion:reduce){.rss_btnIcon[data-loading] svg{animation:none}}',
      '.rss_dirtyChip{flex:none;display:inline-flex;align-items:center;gap:5px;border:1px solid var(--dsw-alias-state-warn-primary);color:var(--dsw-alias-state-warn-primary);border-radius:999px;corner-shape:round;padding:1px 9px;font-size:11px;line-height:16px;white-space:nowrap}',
      '.rss_dirtyChip::before{content:"";width:6px;height:6px;border-radius:50%;corner-shape:round;background:currentColor;flex:none}',
      '.rss_meta{display:flex;flex-wrap:wrap;gap:6px 14px;color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px}',
      '.rss_file{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;font-family:var(--ds-font-family-code);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}',
      '.rss_banner{border:.5px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);border-radius:8px;padding:8px 12px;font-size:12.5px;line-height:18px;overflow-wrap:anywhere;flex:none}',
      '.rss_banner[data-kind=error]{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}',
      '.rss_banner[data-kind=warn]{color:var(--dsw-alias-state-warn-primary);border-color:var(--dsw-alias-state-warn-primary)}',
      '.rss_banner[data-kind=ok]{color:var(--dsw-alias-state-success-primary);border-color:var(--dsw-alias-state-success-primary)}',
      '.rss_loading,.rss_empty{text-align:center;color:var(--dsw-alias-label-tertiary);padding:24px 12px;font-size:12.5px;line-height:18px}',
      // 骨架屏：只在「真没数据 + 加载已过消抖阈值」时出现（见 renderSkeleton / beginLoading）。
      // 卡片几何与 .rss_item 完全一致，避免真内容替换时跳版。
      '.rss_skel{display:flex;flex-direction:column;gap:6px;transition:opacity .18s}',
      '.rss_skel[data-pending]{opacity:0}',
      '.rss_skelCard{background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-md);padding:8px 12px;display:flex;flex-direction:column;gap:4px}',
      '.rss_skelLine{height:13px;border-radius:var(--dsw-radius-sm);background:linear-gradient(90deg,color-mix(in srgb,var(--dsw-alias-label-tertiary) 10%,transparent) 25%,color-mix(in srgb,var(--dsw-alias-label-tertiary) 22%,transparent) 37%,color-mix(in srgb,var(--dsw-alias-label-tertiary) 10%,transparent) 63%);background-size:400% 100%;animation:rss_shimmer 1.4s linear infinite}',
      '.rss_skelLine[data-w=sm]{height:9px}',
      '@keyframes rss_shimmer{from{background-position:100% 0}to{background-position:0 0}}',
      '@media (prefers-reduced-motion:reduce){.rss_skelLine{animation:none}}',
      // 刷新中：旧列表继续显示（stale-while-revalidate），压暗表示「正在更新」。
      // 不用 pointer-events:none —— 那会连滚轮一起吃掉，刷新期间列表就滚不动了。
      '.rss_modalBody[data-updating]{opacity:.55;transition:opacity .16s}',
      '.rss_digestStats{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px;margin:2px 0 8px}',
      '.rss_digestActions{display:flex;gap:8px;flex-wrap:wrap}',
      '.rss_customCount{flex:none;color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;white-space:nowrap}',
      '.rss_srcNameCell{display:flex;flex-direction:column;gap:4px;min-width:0}',
      '.rss_dupRow{border-left:2px solid var(--dsw-alias-state-warn-primary)}',
      '.rss_dupBadge{display:inline-block;align-self:flex-start;color:var(--dsw-alias-state-warn-primary);border:1px solid var(--dsw-alias-state-warn-primary);border-radius:999px;corner-shape:round;font-size:10px;line-height:14px;padding:0 6px}',
      '.rss_catalogToolbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px}',
      '.rss_catalogStats{flex:1;min-width:0;color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px}',
      '.rss_customImport{display:flex;gap:8px;align-items:center;flex-wrap:wrap;flex:none}',
      '.rss_customImportHint{flex:1 1 100%;color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px}',
      '.rss_importPaste{display:flex;gap:8px;align-items:flex-end}',
      // 选择器带上 .rss_input：两条规则同权重时源码顺序决定胜负，而 .rss_input 在后面——不加这一级，
      // 这里的 padding 与行高会被输入档覆盖（文本贴顶、行高变 1.5）。
      '.rss_input.rss_importTextarea{min-height:76px;height:auto;padding:8px 12px;resize:vertical;font-family:var(--ds-font-family-code);font-size:12px;line-height:18px}',
      // 复选框的「选中态」走宿主的中性 brand：宿主 Checkbox 的 accent-color 与 Switch 的开启态都是
      // --dsw-alias-brand-primary（浅色近黑），而 state-business-primary 是本包的**强调蓝**（给状态与
      // 徽标用）。尺寸 16×16 与宿主一致（原来是 15 / 14）。判据见 client-style-spec.mjs 检查十四。
      // 三个复选框容器共用一条规则：摘要弹窗的行首（.rss_itemTop）、渠道行（.rss_builtinRow）、
      // 设置卡里的开关行（.rss_checkRow，AI 摘要与总开关那两处——它们此前完全没有样式，
      // 于是走的是浏览器 UA 的蓝勾 #0275ff）。
      '.rss_itemTop input[type=checkbox],.rss_builtinRow input[type=checkbox],.rss_checkRow input[type=checkbox]{width:16px;height:16px;margin:0;flex:none;cursor:pointer;accent-color:var(--dsw-alias-brand-primary)}',
      '.rss_itemTop input[type=checkbox],.rss_checkRow input[type=checkbox]{margin:2px 0 0}',
      '.rss_itemTop input[type=checkbox]:focus-visible,.rss_builtinRow input[type=checkbox]:focus-visible,.rss_checkRow input[type=checkbox]:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:2px}',
      '.rss_itemTop input[type=checkbox]:disabled{opacity:.5;cursor:default}',
      '.rss_catalogSources{display:flex;flex-direction:column;gap:6px;border:1px dashed var(--dsw-alias-border-l2);border-radius:8px;padding:10px}',
      '.rss_catalogSourceRow{display:flex;align-items:center;gap:10px;font-size:12px;line-height:18px}',
      '.rss_catalogSourceName{flex:none;max-width:160px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--dsw-alias-label-primary);font-weight:500}',
      '.rss_catalogSourceMeta{flex:1;min-width:0;color:var(--dsw-alias-label-tertiary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '.rss_catalogSourceError{color:var(--dsw-alias-state-error-primary)}',
      '.rss_catalogSourcePending{color:var(--dsw-alias-state-warn-primary)}',
      '.rss_catalogSourceActions{flex:none}',
      '.rss_catalogOrigin{border-color:var(--dsw-alias-state-business-primary);color:var(--dsw-alias-state-business-primary)}',
      '.rss_source{margin-top:4px}',
      '.rss_sourceName{font-size:13px;font-weight:500;line-height:20px;margin:8px 0 6px}',
      '.rss_subSource{display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:12.5px;font-weight:500;line-height:18px;color:var(--dsw-alias-label-secondary);margin:2px 0 4px}',
      '.rss_list{display:flex;flex-direction:column;gap:8px;max-height:420px;overflow-y:auto}',
      '.rss_item{background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-md);padding:8px 12px;display:flex;flex-direction:column;gap:4px}',
      '.rss_itemTop{display:flex;align-items:flex-start;gap:8px}',
      '.rss_itemMain{flex:1;min-width:0}',
      '.rss_itemTitle{font-size:13px;line-height:20px}',
      '.rss_itemTitle a{color:var(--dsw-alias-state-business-primary);text-decoration:none}',
      '.rss_itemTitle a:hover{text-decoration:underline}',
      '.rss_itemMeta{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;font-weight:400}',
      '.rss_itemSummary{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px}',
      '.rss_sourcesTitle{font-size:12px;font-weight:500;line-height:18px;color:var(--dsw-alias-label-secondary);margin-top:4px}',
      '.rss_sources{display:flex;flex-wrap:wrap;gap:6px}',
      '.rss_sourceChip{display:inline-block;border:.5px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);border-radius:999px;corner-shape:round;padding:1px 8px;font-size:11px;line-height:16px;white-space:nowrap}',
      // 区块：R16 是官方「嵌套编辑器」那一档（R20 设置卡内）。不再写 background——原来填的
      // bg-layer-2 与设置卡自己的 settings-card-fill 是**同一个 token**（浅色主题下都是纯白），
      // 那条声明不产生任何视觉差，只让「三层同底色」看起来像是有层级。
      '.rss_settingSection{position:relative;display:flex;flex-direction:column;gap:8px;border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-lg);padding:12px}',
      '.rss_checkRow{display:flex;gap:8px;align-items:flex-start;font-size:13px;line-height:20px;color:var(--dsw-alias-label-primary);cursor:pointer}',
      '.rss_settingTitle{font-size:13px;font-weight:500;line-height:20px}',
      '.rss_settingHint{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px}',
      '.rss_sourceEditorList{display:flex;flex-direction:column;gap:8px}',
      '.rss_sourceEditor{display:grid;grid-template-columns:1fr 2fr 1fr 70px auto;gap:6px;align-items:center}',
      '.rss_sourceEditor .rss_input{min-width:0}',
      // 行列表对齐宿主设置页的形态（settings-form/fields.module.css 是 .field + .field{border-top:.5px}）：
      // 行与行之间用发丝线分隔，不再每行一个盒子。盒子的底色 bg-layer-2 与设置卡的 settings-card-fill
      // 是同一个 token，套三层盒子只会多出两圈线、分不出层级。第一列 24px 给拖拽把手的命中盒。
      '.rss_channelList{display:flex;flex-direction:column;min-width:0}',
      '.rss_channelRow{display:grid;grid-template-columns:24px 24px minmax(80px,1.2fr) minmax(100px,1.5fr) minmax(80px,0.8fr) 52px 52px;gap:6px;align-items:center;padding:8px 0;min-width:0}',
      '.rss_channelRow + .rss_channelRow{border-top:.5px solid var(--dsw-alias-border-l2)}',
      '.rss_channelRow .rss_input{min-width:0}',
      '.rss_channelRow > *{min-width:0}',
      '.rss_channelRow.rss_dragging{opacity:.45}',
      // 拖拽把手是**图形**不是文字：原来用「⋮⋮」字形（14px / line-height:1），字距与命中盒都随字体漂移。
      // 现在 24×24 的盒 + SVG（宿主 DisclosureRow 的 leading 就是 16px 盒 + 图标）。
      '.rss_dragHandle{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;cursor:grab;color:var(--dsw-alias-label-tertiary);user-select:none}',
      '.rss_dragHandle svg{display:block}',
      '.rss_dragHandle:active{cursor:grabbing}',
      '.rss_channelName,.rss_channelUrl{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;line-height:18px;color:var(--dsw-alias-label-primary)}',
      '.rss_channelUrl{color:var(--dsw-alias-label-tertiary)}',
      // 「内置 / 自定义」是徽标档，对齐宿主 Tag 原语：11px / 17px / 500（原来没有字重、行高也差 1px）。
      '.rss_channelType{font-size:11px;font-weight:500;line-height:17px;color:var(--dsw-alias-label-tertiary);white-space:nowrap}',
      '.rss_disabledTitle{font-size:12px;font-weight:500;line-height:18px;color:var(--dsw-alias-label-tertiary);margin:8px 0 2px}',
      '.rss_builtinList{display:flex;flex-direction:column;gap:2px}',
      '.rss_builtinRow{display:flex;align-items:center;gap:10px;font-size:13px;line-height:20px;color:var(--dsw-alias-label-primary);cursor:pointer;padding:3px 0}',
      '.rss_builtinName{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '.rss_builtinRow .rss_builtinCategory{flex:none;width:120px}',
      '.rss_builtinNote{font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary);padding:0 0 2px 24px}',
      '.rss_channelRow.rss_builtinRow{display:grid;padding:8px 0;gap:6px}',
      '.rss_channelRow.rss_builtinRow .rss_builtinCategory{width:auto;flex:none}',
      // 输入档对齐宿主 settings-form 的 .input（fields.module.css）：H34 / R12 / border-l4 /
      // bg-layer-3 / 13px + 1.5 行高；placeholder 用 label-dimmed（Input 原语那一档）。
      // 显式高度是为了 <select>：它复用同一个类，而 Chrome 给 select 算内容高时不看继承的
      // line-height（实测内容高 16px），于是下拉比同排输入框矮 2px、上下沿对不齐。
      '.rss_input{box-sizing:border-box;width:100%;height:34px;padding:0 12px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-3);border:.5px solid var(--dsw-alias-border-l4);border-radius:var(--dsw-radius-md);outline:none;font-family:inherit;font-size:13px;line-height:1.5}',
      '.rss_input:focus{border-color:var(--dsw-alias-state-business-primary)}',
      '.rss_input::placeholder{color:var(--dsw-alias-label-dimmed)}',
      '.rss_addRow{display:flex;gap:6px;align-items:center}',
      '.rss_addRow > .rss_input:first-child{flex:1;min-width:0}',
      '.rss_addRow > .rss_input:last-child{flex:none;width:auto;max-width:55%}',
      '.rss_catalogAddRow{display:grid;grid-template-columns:minmax(140px,1fr) minmax(220px,2fr) auto;gap:6px;align-items:center}',
      '.rss_catalogAddRow .rss_input{min-width:0}',
      '.rss_catalogSearchRow{display:grid;grid-template-columns:minmax(220px,2fr) minmax(110px,1fr) minmax(110px,1fr);gap:6px;align-items:center}',
      '.rss_catalogSearchRow .rss_input{min-width:0}',
      '.rss_categories{display:flex;flex-wrap:wrap;gap:6px}',
      '.rss_categoryChip{display:inline-flex;align-items:center;gap:6px;border:.5px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);border-radius:999px;corner-shape:round;padding:2px 6px 2px 10px;font-size:11px;line-height:16px;white-space:nowrap}',
      // 分类 chip 上的「×」也是图形：给 20×20 命中盒 + SVG，不再拿 "×" 字形撑（它随字体漂移、
      // 命中盒就是字形本身，键盘焦点也画不出来）。
      '.rss_categoryRemove{appearance:none;display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;padding:0;background:0 0;border:0;border-radius:var(--dsw-radius-xs);color:var(--dsw-alias-label-tertiary);cursor:pointer}',
      '.rss_categoryRemove:hover{color:var(--dsw-alias-state-error-primary)}',
      '.rss_categoryRemove:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:1px}',
      '.rss_categoryRemove svg{display:block}',
      // 链接式按钮：配方本已是官方的（link 色 + 500 + 点状下划线），只补字号配行高这一条硬性条款。
      '.rss_linkBtn{color:var(--dsw-alias-link);background:0 0;border:none;padding:0;font-size:12px;line-height:18px;font-weight:500;cursor:pointer;white-space:nowrap;text-decoration:none}',
      '.rss_linkBtn:hover:not(:disabled){text-decoration:underline dotted;text-underline-offset:3px}',
      '.rss_formGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px}',
      '.rss_field{display:flex;flex-direction:column;gap:5px}',
      '.rss_fieldLabel{color:var(--dsw-alias-label-secondary);font-size:12px;font-weight:500;line-height:18px}',
      '.rss_toast{position:fixed;left:50%;bottom:36px;transform:translateX(-50%);transform-origin:center;z-index:2147483647;pointer-events:none;display:flex;align-items:center;gap:8px;background:var(--dsw-alias-bg-layer-2);border:0;color:var(--dsw-alias-label-primary);border-radius:var(--dsw-radius-md);padding:9px 16px;font-size:13px;line-height:20px;box-shadow:var(--dsw-elevation-prominent);max-width:70vw;animation:rss_toastIn .18s ease-out}',
      '.rss_toast[data-kind=ok]{color:var(--dsw-alias-state-success-primary);box-shadow:var(--dsw-elevation-prominent), inset 0 0 0 .5px var(--dsw-alias-state-success-primary)}',
      '.rss_toast[data-kind=error]{color:var(--dsw-alias-state-error-primary);box-shadow:var(--dsw-elevation-prominent), inset 0 0 0 .5px var(--dsw-alias-state-error-primary)}',
      // toast 图标是图标不是正文：字重按「强调」档留 600（宿主自家组件没有 700）。
      '.rss_toastIcon{flex:none;font-weight:600}',
      '@keyframes rss_toastIn{from{opacity:0;transform:translate(-50%,8px)}to{opacity:1;transform:translate(-50%,0)}}',
      // 侧边栏不在宿主 box-sizing reset 的作用域内：width:100% + 左右 padding 会按
      // content-box 撑出 24px，右侧被侧边栏裁掉（hover 底色右边缺角）。必须显式声明。
      '.rss_sidebarEntry{box-sizing:border-box;width:100%;height:32px;color:var(--dsw-alias-label-secondary);cursor:pointer;white-space:nowrap;background:0 0;border:none;border-radius:8px;align-items:center;gap:8px;padding:0 12px;font-size:13px;line-height:20px;display:flex}',
      '.rss_sidebarEntry:hover{background:var(--dsw-specific-sidebar-nav-item-hover);color:var(--dsw-alias-label-primary)}',
      '.rss_sidebarEntry[data-active]{background:var(--dsw-specific-sidebar-nav-item-active);color:var(--dsw-alias-label-primary);font-weight:600}',
      '.rss_sidebarEntryIcon{flex:none;justify-content:center;align-items:center;display:inline-flex}',
      '.rss_sidebarEntryLabel{text-overflow:ellipsis;overflow:hidden}',
      '[data-sidebar-collapsed] .rss_sidebarEntry{justify-content:center;width:100%;padding:0}',
      '[data-sidebar-collapsed] .rss_sidebarEntryLabel{display:none}',
      '.rss_modalBackdrop{z-index:1300;background:var(--dsw-alias-bg-mask-1);justify-content:center;align-items:center;display:flex;position:fixed;inset:0}',
      // 刷新中的过渡层：与 dsh-docker 的「切目标过渡」同一套语言——不推版、有方向感。
      // 两者都是绝对定位：插入文档流会把标题/列表整块推下去（这正是要避免的跳动）。
      '.rss_busyBar{position:absolute;top:0;left:0;right:0;height:2px;overflow:hidden;pointer-events:none;z-index:5}',
      /*
       * 流光用**强调色**，不是 brand-primary：实测这个皮肤里 `--dsw-alias-brand-primary`
       * 是 #0f1115（品牌墨色、近黑），拿它画进度条就是一条黑波纹；
       * 强调色 `--dsw-alias-state-business-primary` 实测 #4176e6，与胶囊同一个 token。
       */
      '.rss_busyBar::before{content:"";position:absolute;inset:0;background-image:linear-gradient(90deg,transparent,var(--dsw-alias-state-business-primary),transparent);background-size:35% 100%;background-repeat:no-repeat;animation:rss_busy 1.15s linear infinite}',
      '@keyframes rss_busy{from{background-position:-40% 0}to{background-position:140% 0}}',
      /*
       * 胶囊外观：走这个弹窗自己的语汇——边框用 border-l2、文字用 label-secondary，
       * 背景**取所在容器同一个表面 token**（弹窗是 bg-base、设置卡是 bg-layer-2）。
       * 不用「层」token + color-mix：那在不同皮肤下会算出深色块，有的环境还不支持
       * color-mix（整条声明失效 → 背景全无），两种都会跟白底对话框对不上。
       */
      '.rss_busyPill{flex:none;display:flex;align-items:center;gap:6px;max-width:min(420px,70%);padding:4px 12px;border:1px solid color-mix(in srgb,var(--dsw-alias-state-business-primary) 42%,transparent);border-radius:999px;corner-shape:round;background:color-mix(in srgb,var(--dsw-alias-state-business-primary) 12%,var(--dsw-alias-bg-base));box-shadow:var(--dsw-elevation-panel);font-size:12px;line-height:18px;color:var(--dsw-alias-state-business-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none}',
      '.rss_busyPill svg{flex:none;animation:rss_spin .9s linear infinite;color:var(--dsw-alias-state-business-primary)}',
      '.rss_busyPill strong{color:var(--dsw-alias-state-business-primary);font-weight:600}',
      '.rss_busyPill .rss_busyDim{color:color-mix(in srgb,var(--dsw-alias-state-business-primary) 72%,var(--dsw-alias-label-secondary))}',
      // 弹窗里的位置：列表区**顶部居中**（与 dsh-docker 的过渡胶囊同一位置语言），
      // 用零高度 sticky 锚点——不占文档流所以不推版，滚列表时也不会跟着滚走。
      // margin-bottom 抵消 .rss_modalBody 的 flex gap(10px)，避免第一项被顶下去。
      '.rss_modal{position:relative}',
      /*
       * 位置：**分类行右端**（那一带是空的）。
       * 观感与 dsh-docker 的 dk_switchOverlay 同一套（蓝底、蓝描边、顶部 2px 流光），但位置
       * 不能照搬它的「内容区顶部居中」：docker 那边背后是「活动」条、中间本来就空，而这里
       * 列表第一项经常是失败横幅（整行文字），居中浮层会横跨那行字。
       * 绝对定位在 .rss_modalFilter 上 → 不占文档流（不推版），也不压任何文字。
       */
      '.rss_modalFilter{position:relative}',
      /*
       * 进度条落在**分类行下面那条线**上（= 列表区顶部），胶囊骑在这条线上、水平居中——
       * 与 dsh-docker 的 dk_switchOverlay 同一形态（内容区顶部一条线 + 居中胶囊）。
       * 两者都绝对定位在 .rss_modalFilter 上：不占文档流（不推版），也不压到分类 chip。
       */
      '.rss_modalFilter .rss_busyBar{top:auto;bottom:0;z-index:6}',
      '.rss_modalFilter .rss_busyPill{position:absolute;left:50%;right:auto;top:auto;bottom:-13px;transform:translateX(-50%);z-index:7;max-width:min(420px,80%)}',
      // 设置卡：进度条贴区块顶边，胶囊落在区块标题行右侧（那边本来就是空的）
      '.rss_settingSection{overflow:hidden}',
      '.rss_settingSection .rss_busyPill{position:absolute;top:10px;right:12px}',
      '.rss_settingSection .rss_busyBar{border-radius:var(--dsw-radius-lg) var(--dsw-radius-lg) 0 0}',
      // 数据落地：8px 上滑 + 淡入，让「换了一批内容」看得见
      '.rss_modalBody[data-landed] > *{animation:rss_landIn .2s ease both}',
      '.rss_settingSection[data-landed] > *{animation:rss_landIn .2s ease both}',
      '@keyframes rss_landIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}',
      '@media (prefers-reduced-motion:reduce){.rss_busyBar::before,.rss_busyPill svg{animation:none}.rss_modalBody[data-landed] > *{animation:none}}',
      '.rss_modal{background:var(--dsw-alias-bg-base);border:0;width:min(720px,100vw - 48px);max-height:calc(100vh - 96px);box-shadow:var(--dsw-elevation-prominent);color:var(--dsw-alias-label-primary);border-radius:var(--dsw-radius-lg);flex-direction:column;gap:12px;padding:16px;display:flex;overflow:hidden}',
      '.rss_modalHeader{flex:none;align-items:center;gap:10px;display:flex}',
      // 弹窗标题属于「强调」档：16 / 600 / 24（不是 700——宿主自家组件的弹窗标题就是 600）。
      '.rss_modalTitle{flex:1;min-width:0;margin:0;font-size:16px;font-weight:600;line-height:24px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      // 关闭键也是图形不是文字（原来用 18px 的 "×" 字形撑 30px 盒子）：同上，换成 SVG + 固定盒。
      '.rss_modalClose{appearance:none;display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;padding:0;background:0 0;border:none;border-radius:var(--dsw-radius-sm);color:var(--dsw-alias-label-tertiary);cursor:pointer}',
      '.rss_modalClose svg{display:block;width:16px;height:16px}',
      '.rss_modalClose:focus-visible{outline:var(--dsw-focus-ring-width) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary))}',
      '.rss_modalClose:hover{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-hover)}',
      '.rss_modalBody{flex:1;min-height:0;overflow-y:auto;display:flex;flex-direction:column;gap:10px}',
      // 筛选 + 动作行改成 .rss_modal 的固定子项（不再放进滚动区）：不必再靠 sticky +
      // 背景遮罩 + 负 margin 这套 hack 让筛选条件「假装吸顶」
      '.rss_modalFilter{flex:none;display:flex;flex-direction:column;gap:10px}',
      '.rss_modalToolbar{display:flex;gap:8px;flex:none;align-items:center}',
      '.rss_modalToolbar .rss_input{flex:1;min-width:0}',
      // 计数贴住右侧动作簇；无 digest 时不渲染搜索框，此时靠 margin-left:auto 把动作推到右边
      '.rss_modalToolbar .rss_modalCount{flex:none;margin-left:auto;white-space:nowrap}',
      '.rss_modalChips{display:flex;flex-wrap:wrap;gap:6px;flex:none}',
      '.rss_modalChip{border:.5px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);background:0 0;border-radius:999px;corner-shape:round;padding:2px 10px;font-size:12px;line-height:18px;cursor:pointer}',
      '.rss_modalChip:hover{border-color:var(--dsw-alias-label-dimmed);color:var(--dsw-alias-label-primary)}',
      '.rss_modalChipActive{border-color:var(--dsw-alias-state-business-primary);color:var(--dsw-alias-state-business-primary)}',
      '.rss_modalFooter{flex:none;display:flex;justify-content:flex-end;gap:8px;align-items:center}',
      '.rss_modalCount{flex:1;color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;align-self:center;min-width:0}',
    ].join('\n')

    /* 底栏图标：与 dsh-tty 同一套 16×16 描边风格（1.6 线宽），语义靠 title/aria-label */
    const ICON_COPY = '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5.5" y="5.5" width="8" height="8" rx="1.4"/><path d="M3.5 10.5h-1v-8h8v1"/></svg>'
    const ICON_REFRESH = '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.5 8a5.5 5.5 0 1 1-1.6-3.9"/><path d="M13.7 1.8v2.7H11"/></svg>'
    /*
     * 拖拽把手与分类 chip 的「×」原来是**文本字形**（"⋮⋮" / "×"）：字距与命中盒随字体漂移，
     * 也没法给屏幕阅读器一个稳定的名字。宿主一律是固定盒 + SVG（DisclosureRow 的 leading 就是
     * 16px 盒 + 图标）。这两个图标同 ICON_COPY / ICON_REFRESH 一套 16×16 描边风格。
     */
    const ICON_GRIP = '<svg viewBox="0 0 16 16" width="16" height="16" fill="currentColor" aria-hidden="true"><circle cx="6" cy="4" r="1.1"/><circle cx="10" cy="4" r="1.1"/><circle cx="6" cy="8" r="1.1"/><circle cx="10" cy="8" r="1.1"/><circle cx="6" cy="12" r="1.1"/><circle cx="10" cy="12" r="1.1"/></svg>'
    const ICON_CLOSE = '<svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><path d="M4.5 4.5l7 7M11.5 4.5l-7 7"/></svg>'

    let styleEl
    function ensureStyle() {
      // 复用页面上的 style 节点并强制刷新内容：HMR / 热重载时旧版 CSS 会残留，
      // 若不覆盖会导致新样式（弹窗 chips、digest 预览等）缺失、界面错乱。
      styleEl = document.getElementById('dsh-rss-style') || (() => {
        const el = document.createElement('style')
        el.id = 'dsh-rss-style'
        document.head.appendChild(el)
        return el
      })()
      styleEl.textContent = CSS
    }

    /* ================================ 基础工具 ================================ */

    const ESC_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }
    const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ESC_MAP[c])
    const fmtTime = (value) => {
      if (!value) return ''
      const date = new Date(value)
      if (Number.isNaN(date.getTime())) return value
      return date.toLocaleString()
    }

    /* ================================ API ================================ */

    const API = {
      digest: '/api/dsh-rss/digest',
      refresh: '/api/dsh-rss/refresh',
      config: '/api/dsh-rss/config',
      sources: '/api/dsh-rss/sources',
      catalog: '/api/dsh-rss/catalog',
    }

    /* 内置渠道库（与宿主端保持一致；服务端返回时以服务端为准，这里是兜底） */
    const BUILTIN_CHANNELS = [
      { key: 'ruanyifeng', name: '阮一峰的网络日志', url: 'https://www.ruanyifeng.com/blog/atom.xml', category: '技术', site: 'http://www.ruanyifeng.com/blog/' },
      { key: 'sspai', name: '少数派', url: 'https://sspai.com/feed', category: '效率', site: 'https://sspai.com/' },
      { key: 'solidot', name: 'Solidot', url: 'https://www.solidot.org/index.rss', category: '科技', site: 'https://www.solidot.org/' },
      { key: 'hackernews', name: 'Hacker News', url: 'https://news.ycombinator.com/rss', category: '科技', site: 'https://news.ycombinator.com/' },
      { key: 'juejin', name: '掘金', url: 'https://juejin.cn/rss', category: '技术', site: 'https://juejin.cn/' },
      { key: 'ithome', name: 'IT之家', url: 'https://www.ithome.com/rss/', category: '科技', site: 'https://www.ithome.com/' },
      { key: '36kr', name: '36氪', url: 'https://rsshub.rssforever.com/36kr/newsflashes', category: '商业', site: 'https://36kr.com/', note: '官方 feed 被反爬拦截，此处为第三方 RSSHub 镜像，可能不稳定' },
    ]

    async function apiRequest(path, options) {
      const res = await fetch(path, options)
      let body = {}
      try {
        body = await res.json()
      } catch {
        /* 非 JSON 响应 */
      }
      if (!res.ok) {
        const err = new Error((body && body.error) || ('HTTP ' + res.status))
        err.code = res.status
        throw err
      }
      return body
    }

    /* ================================ 国际化 ================================ */

    /*
     * 界面文案走宿主 `@deepseek-ai/dsh-client-locale` 的目录（方案见 docs/i18n.md）。
     * 下面这一对目录由 `scripts/check-i18n.mjs` 静态校验：键集必须与英文一一对应、
     * `{name}` 占位符两边一致、代码里 `t('…')` 用到的键必须在这里有定义。
     * 目录**内联在 client.js 里**（不是 client-src/）：本包没有构建步骤，client.js 就是源；
     * 而且一旦凭空建出 client-src/，仓库级「宿主地址来源」静态规则会停止覆盖 client.js。
     */
    /* ==== dsh-i18n:begin ==== */
    const I18N_NS = 'rss'
    const I18N_ZH = {
      'card.name': 'RSS / 新闻聚合',
      'card.desc': '订阅 RSS/Atom，管理渠道与分类，每天自动汇总「今日值得读」。',
      'panel.title': 'RSS 设置',
      'panel.digest': '今日值得读',
      'panel.unsaved': '未保存修改',
      'panel.unsavedTitle': '有未保存的修改',
      'panel.channels': '订阅渠道',
      'panel.channelsHint': '内置渠道和自定义渠道统一管理；拖拽手柄可排序，常用修改会自动保存。',
      'panel.channelCount': '{count} 个',
      'panel.disabledBuiltins': '未启用内置渠道',
      'panel.builtin': '内置',
      'panel.custom': '自定义',
      'panel.importHint': '支持从任何 RSS 阅读器 / 网站导入订阅（OPML 文件或 URL 列表），也可导出给其他应用使用；导入后会自动校验并保存。',
      'panel.categories': '新闻分类',
      'panel.categoriesHint': '维护分类标签；上方渠道的「分类」从这里选择，digest 按分类分组展示。',
      'panel.aggregate': '聚合设置',
      'panel.maxPerSource': '每源条数',
      'panel.maxTotal': '每日总条数',
      'panel.dailyTime': '每日生成时间',
      'panel.aggregateHint': '修改后点击顶部「保存」，保存成功会自动重新抓取当天 digest。',
      'panel.ai': 'AI 摘要',
      'panel.aiEnabled': '启用 AI 摘要：生成 digest 时调用宿主模型为每条资讯生成一句话摘要（单条失败只回落原文摘要，不影响其它条目）',
      'panel.aiProvider': '模型 Provider',
      'panel.aiModel': '模型 Model',
      'panel.aiMaxItems': '最多摘要条数',
      'panel.aiHint': 'Provider / Model 需成对填写：都留空时跟随宿主默认模型，只填一个保存时整段 AI 配置会被忽略并提示。摘要结果按条目缓存 30 天（最多 500 条，存在 digest 目录的 ai-cache.json），重复条目不会重复请求。',
      'panel.plugin': '插件',
      'panel.pluginEnabled': '启用插件（保存后热生效：关闭即收起侧栏入口、停用每日汇总与 agent 公告；本卡片保持可用）',
      'panel.entryCount': '{count} 条',
      'panel.feedCount': '{count} 个订阅源',
      'panel.generatedAt': '生成于 {time}',
      'panel.dailyAt': '每日 {time} 自动生成',
      'panel.visibleCount': '{visible} / {total} 条',
      'panel.uncategorized': '未分类',
      'panel.allCategories': '全部分类',
      'panel.allSources': '全部来源',
      'panel.catalogStats': '共 {total} 条 · 已订阅 {subscribed} · 已选 {selected}',
      'panel.catalogHintBefore': '目录可来自多个来源：内置 ',
      'panel.catalogHintAfter': ' 精选列表 + 你添加的其他 OPML 目录；搜索结果统一汇总并标注来源，可一键加入自定义渠道并保存。',
      'panel.builtinSource': '内置 {name}',
      'panel.fixed': '固定',
      'panel.fromCatalogTitle': '来自目录 {name}',
      'panel.fromCatalog': '来自 {name}',
      'panel.unknownCatalog': '未知',
      'panel.feedCatalog': '订阅源目录',
      'panel.errorDetail': '：{error}',
      'btn.refresh': '刷新',
      'btn.discard': '放弃修改',
      'btn.save': '保存',
      'btn.viewList': '查看列表',
      'btn.copyMarkdown': '复制 Markdown',
      'btn.dragToSort': '拖拽排序',
      'btn.delete': '删除',
      'btn.addSource': '+ 添加源',
      'btn.importOpml': '导入 OPML',
      'btn.hidePasteImport': '收起粘贴导入',
      'btn.pasteUrlList': '粘贴 URL 列表',
      'btn.exportOpml': '导出 OPML',
      'btn.feedCatalog': '订阅源目录',
      'btn.import': '导入',
      'btn.selectAll': '全选',
      'btn.clear': '清空',
      'btn.addSelected': '添加选中并保存',
      'btn.add': '添加',
      'btn.added': '已添加',
      'btn.addCatalog': '添加目录',
      'btn.cancel': '取消',
      'btn.remove': '移除',
      'btn.close': '关闭',
      'btn.all': '全部',
      'btn.viewMore': '查看更多',
      'btn.removeCategory': '删除分类 {category}',
      'btn.bulkSelect': '用于批量添加',
      'placeholder.name': '名称',
      'placeholder.filterChannels': '筛选名称 / URL…',
      'placeholder.importList': '每行一个订阅地址；也可用「名称, 地址」格式：',
      'placeholder.catalogSearch': '搜索目录，如 arxiv、Hacker News…',
      'placeholder.catalogName': '目录名称，如：我的精选',
      'placeholder.catalogUrl': 'OPML 目录 URL（https://…/feeds.opml）',
      'placeholder.newCategory': '新分类，例如：AI',
      'placeholder.modalSearch': '搜索标题 / 摘要 / 来源…',
      'placeholder.aiModel': '留空跟随宿主默认模型',
      'list.loading': '加载中…',
      'list.loadingCatalog': '加载目录…',
      'list.loadFailed': '加载失败',
      'list.pendingSave': '待保存 · 保存后读取',
      'list.emptyChannels': '没有匹配的渠道。',
      'list.noCategories': '暂无分类。',
      'list.noDigest': '还没有生成 digest，点击「刷新」抓取。',
      'list.noDigestItems': '今日暂无可展示条目。',
      'list.noItemsToday': '今天暂无条目。',
      'list.noMatchingItems': '没有匹配的条目。',
      'list.noMatchingFeeds': '没有匹配的订阅源。',
      'list.catalogIdle': '输入关键词搜索精选订阅源，或勾选后批量添加。',
      'list.catalogDisabled': '目录已停用（配置 includeCatalog: false）。',
      'list.untitled': '(无标题)',
      'msg.refreshing': '刷新中…',
      'msg.refreshingFeeds': '正在刷新订阅源',
      'msg.refreshingFeedsAt': '正在刷新订阅源 · 当前数据生成于 {clock}',
      'msg.refreshingTitle': '正在刷新订阅源：抓取全部订阅源并重新生成今日 digest。',
      'msg.refreshingTitleData': '下面仍是 {stamp} 生成的数据，刷新完成后整体替换。',
      'msg.saving': '保存中…',
      'msg.refreshed': '已刷新',
      'msg.saved': '已保存，热生效',
      'msg.savedWithWarnings': '已保存：{warnings}',
      'msg.aiFallback': '{count} 条失败，已回落到原文摘要',
      'msg.aiError': 'AI 摘要：{reason}',
      'msg.fetchFailedCount': '{count} 个订阅源抓取失败',
      'msg.fetchFailedCountDetail': '{count} 个订阅源抓取失败：{preview}',
      'msg.fetchFailedList': '抓取失败：{list}',
      'msg.nothingToCopy': '没有可复制的内容',
      'msg.copied': '已复制',
      'msg.copyFailed': '复制失败',
      'msg.nothingToImport': '没有可导入的内容',
      'msg.importParseFailed': '未能从内容中解析出订阅源，请检查格式',
      'msg.noNewSources': '没有新增订阅源（{count} 个已订阅或无效）',
      'msg.importSkipped': '，跳过 {count} 个已存在',
      'msg.importedSaving': '已导入 {added} 个订阅源{skipped}，正在保存…',
      'msg.importedPending': '已导入 {added} 个订阅源{skipped}，点击「保存」校验生效',
      'msg.exportedCount': '已导出 {count} 个订阅源',
      'msg.allSubscribed': '所选条目均已订阅',
      'msg.nothingSelected': '未选择条目',
      'msg.addSkipped': '，跳过 {count} 个已订阅',
      'msg.addedSaving': '已添加 {added} 个订阅源{skipped}，正在保存…',
      'msg.catalogExists': '该目录已存在',
      'msg.catalogAdded': '目录已加入，正在保存…',
      'msg.catalogRemoved': '目录已移除，正在保存…',
      'msg.confirmDiscard': '放弃未保存的修改并重新加载？',
      'msg.opmlTitle': 'DSH RSS 订阅源',
      'error.catalogNameRequired': '请填写目录名称',
      'error.catalogUrlRequired': '请填写 OPML 目录 URL',
      'error.catalogUrlInvalid': '目录 URL 不合法',
    }
    const I18N_EN = {
      'card.name': 'RSS / news aggregation',
      'card.desc': 'Subscribe to RSS/Atom feeds, manage channels and categories, and get an automatic “Today’s picks” digest every day.',
      'panel.title': 'RSS settings',
      'panel.digest': 'Today’s picks',
      'panel.unsaved': 'Unsaved changes',
      'panel.unsavedTitle': 'You have unsaved changes',
      'panel.channels': 'Subscriptions',
      'panel.channelsHint': 'Built-in and custom feeds are managed in one place; drag the handle to reorder, and common edits are saved automatically.',
      'panel.channelCount': '{count} channels',
      'panel.disabledBuiltins': 'Built-in channels not enabled',
      'panel.builtin': 'Built-in',
      'panel.custom': 'Custom',
      'panel.importHint': 'Import subscriptions from any RSS reader or website (OPML file or URL list), or export them for use in other apps; imports are validated and saved automatically.',
      'panel.categories': 'News categories',
      'panel.categoriesHint': 'Manage category tags; the Category field of each channel picks from this list, and the digest is grouped by category.',
      'panel.aggregate': 'Aggregation',
      'panel.maxPerSource': 'Items per feed',
      'panel.maxTotal': 'Total items per day',
      'panel.dailyTime': 'Daily generation time',
      'panel.aggregateHint': 'After editing, click Save at the top; a successful save fetches the current digest again automatically.',
      'panel.ai': 'AI summaries',
      'panel.aiEnabled': 'Enable AI summaries: when generating the digest, ask the host model for a one-sentence summary of each item (a single failure just falls back to the original summary and does not affect other items)',
      'panel.aiProvider': 'Model provider',
      'panel.aiModel': 'Model',
      'panel.aiMaxItems': 'Max summaries',
      'panel.aiHint': 'Provider and Model must be filled in together: leave both empty to follow the host default model, and if only one is set the whole AI config is ignored on save and a warning is shown. Summaries are cached per item for 30 days (up to 500 entries, in ai-cache.json in the digest directory), so repeated items are not requested again.',
      'panel.plugin': 'Plugin',
      'panel.pluginEnabled': 'Enable the plugin (applied live after saving: turning it off hides the sidebar entry and stops the daily digest and the agent announcement; this card stays usable)',
      'panel.entryCount': '{count} entries',
      'panel.feedCount': '{count} feeds',
      'panel.generatedAt': 'Generated at {time}',
      'panel.dailyAt': 'Auto-generated daily at {time}',
      'panel.visibleCount': '{visible} / {total} items',
      'panel.uncategorized': 'Uncategorized',
      'panel.allCategories': 'All categories',
      'panel.allSources': 'All sources',
      'panel.catalogStats': '{total} entries · {subscribed} subscribed · {selected} selected',
      'panel.catalogHintBefore': 'Catalogs can come from several sources: the built-in ',
      'panel.catalogHintAfter': ' curated list plus any OPML catalogs you add; search results are merged and labeled with their origin, and can be added to your custom channels and saved in one click.',
      'panel.builtinSource': 'Built-in {name}',
      'panel.fixed': 'fixed',
      'panel.fromCatalogTitle': 'From catalog {name}',
      'panel.fromCatalog': 'From {name}',
      'panel.unknownCatalog': 'Unknown',
      'panel.feedCatalog': 'Feed catalog',
      'panel.errorDetail': ': {error}',
      'btn.refresh': 'Refresh',
      'btn.discard': 'Discard changes',
      'btn.save': 'Save',
      'btn.viewList': 'View list',
      'btn.copyMarkdown': 'Copy Markdown',
      'btn.dragToSort': 'Drag to reorder',
      'btn.delete': 'Delete',
      'btn.addSource': '+ Add feed',
      'btn.importOpml': 'Import OPML',
      'btn.hidePasteImport': 'Hide paste import',
      'btn.pasteUrlList': 'Paste URL list',
      'btn.exportOpml': 'Export OPML',
      'btn.feedCatalog': 'Feed catalog',
      'btn.import': 'Import',
      'btn.selectAll': 'Select all',
      'btn.clear': 'Clear',
      'btn.addSelected': 'Add selected and save',
      'btn.add': 'Add',
      'btn.added': 'Added',
      'btn.addCatalog': 'Add catalog',
      'btn.cancel': 'Cancel',
      'btn.remove': 'Remove',
      'btn.close': 'Close',
      'btn.all': 'All',
      'btn.viewMore': 'View more',
      'btn.removeCategory': 'Remove category {category}',
      'btn.bulkSelect': 'Select for bulk add',
      'placeholder.name': 'Name',
      'placeholder.filterChannels': 'Filter by name / URL…',
      'placeholder.importList': 'One feed URL per line; you can also use the “name, URL” format:',
      'placeholder.catalogSearch': 'Search the catalog, e.g. arxiv, Hacker News…',
      'placeholder.catalogName': 'Catalog name, e.g. My picks',
      'placeholder.catalogUrl': 'OPML catalog URL (https://…/feeds.opml)',
      'placeholder.newCategory': 'New category, e.g. AI',
      'placeholder.modalSearch': 'Search title / summary / source…',
      'placeholder.aiModel': 'Leave empty to use the host default model',
      'list.loading': 'Loading…',
      'list.loadingCatalog': 'Loading catalog…',
      'list.loadFailed': 'Load failed',
      'list.pendingSave': 'Pending save · read after saving',
      'list.emptyChannels': 'No matching channels.',
      'list.noCategories': 'No categories yet.',
      'list.noDigest': 'No digest yet — click Refresh to fetch one.',
      'list.noDigestItems': 'No items to show today.',
      'list.noItemsToday': 'No items today.',
      'list.noMatchingItems': 'No matching items.',
      'list.noMatchingFeeds': 'No matching feeds.',
      'list.catalogIdle': 'Type a keyword to search curated feeds, or check items to add them in bulk.',
      'list.catalogDisabled': 'The catalog is disabled (config includeCatalog: false).',
      'list.untitled': '(untitled)',
      'msg.refreshing': 'Refreshing…',
      'msg.refreshingFeeds': 'Refreshing feeds',
      'msg.refreshingFeedsAt': 'Refreshing feeds · currently showing data generated at {clock}',
      'msg.refreshingTitle': 'Refreshing feeds: fetching every feed and regenerating today’s digest.',
      'msg.refreshingTitleData': 'The list below is still the data generated at {stamp}; it is replaced once the refresh completes.',
      'msg.saving': 'Saving…',
      'msg.refreshed': 'Refreshed',
      'msg.saved': 'Saved, applied live',
      'msg.savedWithWarnings': 'Saved: {warnings}',
      'msg.aiFallback': '{count} items failed; fell back to the original summaries',
      'msg.aiError': 'AI summaries: {reason}',
      'msg.fetchFailedCount': '{count} feeds failed to fetch',
      'msg.fetchFailedCountDetail': '{count} feeds failed to fetch: {preview}',
      'msg.fetchFailedList': 'Fetch failed: {list}',
      'msg.nothingToCopy': 'Nothing to copy',
      'msg.copied': 'Copied',
      'msg.copyFailed': 'Copy failed',
      'msg.nothingToImport': 'Nothing to import',
      'msg.importParseFailed': 'Could not parse any feeds from the content; please check the format',
      'msg.noNewSources': 'No new feeds added ({count} already subscribed or invalid)',
      'msg.importSkipped': ', skipped {count} already present',
      'msg.importedSaving': 'Imported {added} feeds{skipped}, saving…',
      'msg.importedPending': 'Imported {added} feeds{skipped} — click Save to validate',
      'msg.exportedCount': 'Exported {count} feeds',
      'msg.allSubscribed': 'All selected items are already subscribed',
      'msg.nothingSelected': 'Nothing selected',
      'msg.addSkipped': ', skipped {count} already subscribed',
      'msg.addedSaving': 'Added {added} feeds{skipped}, saving…',
      'msg.catalogExists': 'That catalog already exists',
      'msg.catalogAdded': 'Catalog added, saving…',
      'msg.catalogRemoved': 'Catalog removed, saving…',
      'msg.confirmDiscard': 'Discard unsaved changes and reload?',
      'msg.opmlTitle': 'DSH RSS subscriptions',
      'error.catalogNameRequired': 'Enter a catalog name',
      'error.catalogUrlRequired': 'Enter the OPML catalog URL',
      'error.catalogUrlInvalid': 'Invalid catalog URL',
    }
    /* ==== dsh-i18n:end ==== */

    /** 占位符替换：`{name}` → params.name（缺参留空，不抛错——文案不该打死界面）。 */
    function i18nFormat(text, params) {
      if (params === undefined) return text
      return String(text).replace(/\{(\w+)\}/g, (_match, name) => (params[name] === undefined ? '' : String(params[name])))
    }

    /** 中文兜底：老宿主（DSH ≤0.1.5）没有 locale 服务时，界面不能变成一串键名。 */
    function i18nFallback(key, params) {
      return i18nFormat(I18N_ZH[key] !== undefined ? I18N_ZH[key] : key, params)
    }

    let t = i18nFallback

    /**
     * 注册目录并绑定翻译函数。**动态 inject**：老宿主上回调永不触发、`t` 保持中文兜底；
     * 写成静态 `inject: ['locale']` 会让整张卡片在老宿主上根本不挂。
     *
     * 语言切换不用自己订阅：插槽 outlet 随 locale revision 重渲染（renderer 的
     * `useLocaleRevision`），而 `bind()` 返回的翻译函数在**调用时**读当前语言。
     */
    function installI18n(ctx) {
      ctx.inject(['locale'], (i18nCtx) => {
        const disposeZh = i18nCtx.locale.register(I18N_NS, 'zh', I18N_ZH)
        const disposeEn = i18nCtx.locale.register(I18N_NS, 'en', I18N_EN)
        t = i18nCtx.locale.bind(I18N_NS)
        return () => {
          disposeEn()
          disposeZh()
          t = i18nFallback
        }
      })
    }

    /* ================================ 面板状态 ================================ */

    const state = {
      digest: null,
      config: null,
      builtins: BUILTIN_CHANNELS,
      newCategory: '',
      loading: false,
      refreshing: false,
      /** 刷新超过消抖阈值（180ms）才置真：卡片上的过渡层只在慢刷新时出现，避免闪一下。 */
      refreshSlow: false,
      saving: false,
      modalLoading: false,
      modalSlow: false,
      error: '',
      dirty: false,
      catalogQuery: '',
      catalogCategory: '',
      catalogEntries: [],
      catalogCategories: [],
      catalogLoading: false,
      catalogError: '',
      catalogDisabled: false,
      catalogSelected: new Set(),
      catalogSource: '',
      catalogSources: [],
      catalogBuiltin: null,
      catalogNewName: '',
      catalogNewUrl: '',
      catalogOpen: false,
      customQuery: '',
      modalQuery: '',
      modalCategory: '',
      modalOpener: null,
      importOpen: false,
      importText: '',
    }

    let panelEl
    let modalEl
    let catalogModalEl
    let toastEl
    let toastTimer
    let saveTimer
    let dragIndex = null

    /* ================================ Toast ================================ */

    const TOAST_ICONS = { ok: '✓', error: '✕', info: 'ⓘ' }

    function toast(message, kind) {
      if (toastEl !== undefined) toastEl.remove()
      toastEl = document.createElement('div')
      toastEl.className = 'rss_toast'
      toastEl.setAttribute('role', 'status')
      toastEl.dataset.kind = kind || 'info'
      const icon = TOAST_ICONS[kind || 'info'] || ''
      toastEl.innerHTML = (icon ? '<span class="rss_toastIcon">' + icon + '</span>' : '') + '<span>' + esc(message) + '</span>'
      document.body.appendChild(toastEl)
      clearTimeout(toastTimer)
      toastTimer = setTimeout(() => {
        toastEl.remove()
        toastEl = undefined
      }, 3200)
    }

    /* ================================ 区块渲染 ================================ */

    function categoryOptions(selected) {
      const options = new Set(state.config?.categories || [])
      if (selected) options.add(selected)
      let html = '<option value="">' + t('panel.uncategorized') + '</option>'
      for (const category of options) {
        html += '<option value="' + esc(category) + '"' + (category === selected ? ' selected' : '') + '>' + esc(category) + '</option>'
      }
      return html
    }

    function catalogCategoryOptions() {
      const selected = state.catalogCategory || ''
      let html = '<option value="">' + t('panel.allCategories') + '</option>'
      for (const cat of state.catalogCategories || []) {
        html += '<option value="' + esc(cat) + '"' + (cat === selected ? ' selected' : '') + '>' + esc(cat) + '</option>'
      }
      return html
    }

    function catalogSourceOptions() {
      const selected = state.catalogSource || ''
      let html = '<option value="">' + t('panel.allSources') + '</option>'
      const builtin = state.catalogBuiltin
      if (builtin && builtin.enabled) {
        html += '<option value="' + esc(builtin.name || 'awesome-rsshub-routes') + '"' + (selected === builtin.name ? ' selected' : '') + '>' + esc(builtin.name || 'awesome-rsshub-routes') + '</option>'
      }
      for (const source of state.catalogSources || []) {
        const value = source.name
        html += '<option value="' + esc(value) + '"' + (selected === value ? ' selected' : '') + '>' + esc(value) + '</option>'
      }
      return html
    }

    function catalogRoot() {
      if (catalogModalEl !== undefined && catalogModalEl.isConnected) return catalogModalEl
      return panelEl
    }

    function updateCatalogSources() {
      const root = catalogRoot()
      const node = root !== undefined ? root.querySelector('#rss-catalog-sources') : null
      if (node === null) return
      node.outerHTML = '<div id="rss-catalog-sources">' + renderCatalogSourcesBlock() + '</div>'
    }

    function builtinOf(source) {
      if (!source) return null
      for (const builtin of state.builtins || []) {
        if ((source.builtin && source.builtin === builtin.key) || source.url === builtin.url || source.name === builtin.name) return builtin
      }
      return null
    }

    function findBuiltinSource(builtin) {
      return (state.config?.sources || []).find((source) => builtinOf(source)?.key === builtin.key) || null
    }

    function channelListHtml() {
      const query = (state.customQuery || '').trim().toLowerCase()
      const sources = state.config?.sources || []
      const urlCount = new Map()
      for (const source of sources) {
        const key = (source.url || '').trim().toLowerCase()
        urlCount.set(key, (urlCount.get(key) || 0) + 1)
      }
      const enabled = []
      for (let i = 0; i < sources.length; i++) {
        const source = sources[i]
        const builtin = builtinOf(source)
        if (!query || (source.name || '').toLowerCase().includes(query) || (source.url || '').toLowerCase().includes(query)) {
          enabled.push({
            source,
            index: i,
            builtin,
            dup: urlCount.get((source.url || '').trim().toLowerCase()) > 1,
          })
        }
      }
      const disabledBuiltins = (state.builtins || [])
        .filter((builtin) => findBuiltinSource(builtin) === null)
        .filter((builtin) => !query || (builtin.name || '').toLowerCase().includes(query) || (builtin.url || '').toLowerCase().includes(query))
      if (enabled.length === 0 && disabledBuiltins.length === 0) {
        return '<div class="rss_empty">' + t('list.emptyChannels') + '</div>'
      }
      const parts = []
      parts.push('<div class="rss_channelList" id="rss-channel-list">')
      for (const row of enabled) parts.push(renderChannelRow(row))
      if (disabledBuiltins.length > 0) {
        parts.push('<div class="rss_disabledTitle">' + t('panel.disabledBuiltins') + '</div>')
        for (const builtin of disabledBuiltins) parts.push(renderDisabledBuiltinRow(builtin))
      }
      // 慢刷新：进度条贴分类行下沿（列表区顶部那条线），胶囊骑在线上、水平居中
      // 注意 digest 必须从 state 取：这里原先直接引用了一个未绑定的 `digest`，
      // 于是只要渲染到这一行就 ReferenceError（整张设置卡片挂掉）。见 scripts/client-lint.mjs 第 4 条。
      const digest = state.digest
      if (digest && state.modalLoading && state.modalSlow) parts.push(busyBarHtml() + busyPillHtml(digest))
      parts.push('</div>')
      return parts.join('')
    }

    function renderChannelRow(row) {
      const { source, index, builtin, dup } = row
      if (builtin) {
        const category = source.category?.trim() || builtin.category
        return '<div class="rss_channelRow rss_builtinRow" data-channel-index="' + index + '">' +
          '<span class="rss_dragHandle" draggable="true" data-drag-index="' + index + '" role="img" aria-label="' + esc(t('btn.dragToSort')) + '" title="' + esc(t('btn.dragToSort')) + '">' + ICON_GRIP + '</span>' +
          '<input type="checkbox" data-action="builtin-toggle" data-key="' + esc(builtin.key) + '" checked />' +
          '<span class="rss_channelName" title="' + esc(builtin.name) + '">' + esc(builtin.name) + '</span>' +
          '<span class="rss_channelUrl" title="' + esc(builtin.url) + '">' + esc(builtin.url) + '</span>' +
          '<select class="rss_input rss_builtinCategory" data-field="rss-builtin-category" data-key="' + esc(builtin.key) + '">' + categoryOptions(category) + '</select>' +
          '<span class="rss_channelType">' + t('panel.builtin') + '</span>' +
          '<span></span>' +
          '</div>'
      }
      return '<div class="rss_channelRow' + (dup ? ' rss_dupRow' : '') + '" data-channel-index="' + index + '">' +
        '<span class="rss_dragHandle" draggable="true" data-drag-index="' + index + '" role="img" aria-label="' + esc(t('btn.dragToSort')) + '" title="' + esc(t('btn.dragToSort')) + '">' + ICON_GRIP + '</span>' +
        '<span></span>' +
        '<input class="rss_input" data-field="rss-source-name" data-index="' + index + '" value="' + esc(source.name || '') + '" placeholder="' + esc(t('placeholder.name')) + '" />' +
        '<input class="rss_input" data-field="rss-source-url" data-index="' + index + '" value="' + esc(source.url || '') + '" placeholder="RSS/Atom URL" spellcheck="false" />' +
        '<select class="rss_input" data-field="rss-source-category" data-index="' + index + '">' + categoryOptions(source.category) + '</select>' +
        '<span class="rss_channelType">' + t('panel.custom') + '</span>' +
        '<button class="rss_btnGhost rss_btnDanger" data-action="config-remove-source" data-index="' + index + '">' + t('btn.delete') + '</button>' +
        '</div>'
    }

    function renderDisabledBuiltinRow(builtin) {
      return '<div class="rss_channelRow rss_builtinRow" data-disabled="true">' +
        '<span class="rss_dragHandle" aria-hidden="true" style="visibility:hidden">' + ICON_GRIP + '</span>' +
        '<input type="checkbox" data-action="builtin-toggle" data-key="' + esc(builtin.key) + '" />' +
        '<span class="rss_channelName" title="' + esc(builtin.name) + '">' + esc(builtin.name) + '</span>' +
        '<span class="rss_channelUrl" title="' + esc(builtin.url) + '">' + esc(builtin.url) + '</span>' +
        '<span class="rss_channelType">' + t('panel.builtin') + '</span>' +
        '<span></span><span></span>' +
        '</div>'
    }

    function renderChannelsSection() {
      const all = state.config?.sources || []
      const parts = []
      parts.push('<div class="rss_settingSection" id="rss-sec-channels">')
      parts.push('<div class="rss_settingTitle">' + t('panel.channels') + '</div>')
      parts.push('<div class="rss_settingHint">' + t('panel.channelsHint') + '</div>')
      parts.push('<div class="rss_addRow" id="rss-custom-tools">')
      parts.push('<input class="rss_input" data-field="rss-custom-query" value="' + esc(state.customQuery) + '" placeholder="' + esc(t('placeholder.filterChannels')) + '" autocomplete="off" spellcheck="false" />')
      parts.push('<span class="rss_customCount">' + t('panel.channelCount', { count: all.length }) + '</span>')
      parts.push('<button class="rss_btnGhost" data-action="config-add-source">' + t('btn.addSource') + '</button>')
      parts.push('</div>')
      parts.push('<div class="rss_customImport">')
      parts.push('<input type="file" id="rss-import-file" data-field="rss-import-file" accept=".opml,.xml,text/xml,application/xml" style="display:none" />')
      parts.push('<button class="rss_btnGhost" data-action="custom-import-opml">' + t('btn.importOpml') + '</button>')
      parts.push('<button class="rss_btnGhost" data-action="custom-import-paste">' + (state.importOpen ? t('btn.hidePasteImport') : t('btn.pasteUrlList')) + '</button>')
      parts.push('<button class="rss_btnGhost" data-action="custom-export-opml">' + t('btn.exportOpml') + '</button>')
      parts.push('<button class="rss_btnGhost" data-action="catalog-open">' + t('btn.feedCatalog') + '</button>')
      parts.push('<span class="rss_customImportHint">' + t('panel.importHint') + '</span>')
      parts.push('</div>')
      if (state.importOpen) {
        parts.push('<div class="rss_importPaste">')
        parts.push('<textarea class="rss_input rss_importTextarea" data-field="rss-import-text" placeholder="' + esc(t('placeholder.importList')) + '&#10;阮一峰的网络日志, https://www.ruanyifeng.com/blog/atom.xml&#10;https://example.com/feed">' + esc(state.importText) + '</textarea>')
        parts.push('<button class="rss_btn" data-action="custom-import-paste-go">' + t('btn.import') + '</button>')
        parts.push('</div>')
      }
      parts.push('<div id="rss-channel-list">' + channelListHtml() + '</div>')
      parts.push('</div>')
      return parts.join('')
    }

    function updateChannels() {
      updateSection('rss-sec-channels', renderChannelsSection())
    }

    function updateChannelList() {
      const node = panelEl !== undefined ? panelEl.querySelector('#rss-channel-list') : null
      if (node === null) return
      node.innerHTML = channelListHtml()
    }

    function moveChannel(from, to) {
      const sources = state.config?.sources
      if (!sources || from === to || from < 0 || from >= sources.length || to < 0 || to >= sources.length) return
      const [moved] = sources.splice(from, 1)
      sources.splice(to, 0, moved)
      updateChannels()
      markDirty()
      scheduleSave()
    }

    function handleChannelDragStart(event) {
      if ((state.customQuery || '').trim()) return
      const handle = event.target.closest ? event.target.closest('[data-drag-index]') : null
      if (!handle) return
      dragIndex = Number(handle.dataset.dragIndex)
      const row = handle.closest('[data-channel-index]')
      if (row) row.classList.add('rss_dragging')
      if (event.dataTransfer) {
        event.dataTransfer.effectAllowed = 'move'
        try {
          event.dataTransfer.setData('text/plain', String(dragIndex))
        } catch {
          /* 某些环境不允许 setData */
        }
      }
    }

    function handleChannelDragOver(event) {
      if (dragIndex === null) return
      const row = event.target.closest ? event.target.closest('[data-channel-index]') : null
      if (!row) return
      event.preventDefault()
      if (event.dataTransfer) event.dataTransfer.dropEffect = 'move'
    }

    function handleChannelDrop(event) {
      if (dragIndex === null) return
      const row = event.target.closest ? event.target.closest('[data-channel-index]') : null
      if (!row) return
      event.preventDefault()
      const toIndex = Number(row.dataset.channelIndex)
      moveChannel(dragIndex, toIndex)
      dragIndex = null
    }

    function handleChannelDragEnd() {
      dragIndex = null
      const dragging = panelEl !== undefined ? panelEl.querySelector('.rss_channelRow.rss_dragging') : null
      if (dragging) dragging.classList.remove('rss_dragging')
    }


    function renderHeader() {
      const parts = []
      parts.push('<div class="rss_panelHeader" id="rss-header">')
      parts.push('<h2 class="rss_panelTitle">' + t('panel.title') + '</h2>')
      if (state.dirty) {
        parts.push('<span class="rss_dirtyChip" title="' + esc(t('panel.unsavedTitle')) + '">' + t('panel.unsaved') + '</span>')
      }
      parts.push('<div class="rss_toolbar">')
      parts.push('<button class="rss_btnGhost" data-action="digest-refresh"' + (state.refreshing ? ' disabled' : '') + '>' + (state.refreshing ? t('msg.refreshing') : t('btn.refresh')) + '</button>')
      parts.push('<button class="rss_btnGhost" data-action="config-reset"' + (state.loading ? ' disabled' : '') + '>' + t('btn.discard') + '</button>')
      parts.push('<button class="rss_btn" data-action="config-save" title="Ctrl / Cmd + S"' + (state.saving ? ' disabled' : '') + '>' + (state.saving ? t('msg.saving') : t('btn.save')) + '</button>')
      parts.push('</div>')
      parts.push('</div>')
      return parts.join('')
    }

    function renderErrorNode() {
      if (!state.error) return '<div id="rss-error"></div>'
      return '<div id="rss-error"><div class="rss_banner" data-kind="error">' + esc(state.error) + '</div></div>'
    }

    function renderDigestSection() {
      const digest = state.digest
      const parts = []
      parts.push('<div class="rss_settingSection" id="rss-sec-digest">')
      // 慢刷新才出过渡层（顶部进度条 + 「当前显示：08:12 生成」胶囊），绝对定位不推版
      if (state.refreshing && state.refreshSlow && digest) parts.push(busyCardHtml(digest))
      parts.push('<div class="rss_settingTitle">' + t('panel.digest') + '</div>')
      if (!digest) {
        parts.push('<div class="rss_empty">' + t('list.noDigest') + '</div>')
      } else {
        const items = digest.items || []
        const sources = digest.sources || []
        const errors = digest.errors || []
        const meta = []
        if (digest.date) meta.push(esc(digest.date))
        meta.push(t('panel.entryCount', { count: items.length }))
        if (sources.length > 0) meta.push(t('panel.feedCount', { count: sources.length }))
        if (digest.generatedAt) meta.push(t('panel.generatedAt', { time: esc(fmtTime(digest.generatedAt)) }))
        if (state.config?.dailyTime) meta.push(t('panel.dailyAt', { time: esc(state.config.dailyTime) }))
        parts.push('<div class="rss_digestStats">' + meta.join(' · ') + '</div>')
        if (errors.length > 0) {
          const preview = errors.slice(0, 2).map((e) => esc(e.source + ': ' + e.error)).join('; ')
          parts.push('<div class="rss_banner" data-kind="warn">' + (preview ? t('msg.fetchFailedCountDetail', { count: errors.length, preview }) : t('msg.fetchFailedCount', { count: errors.length })) + (errors.length > 2 ? '…' : '') + '</div>')
        }
        // AI 摘要整体不可用 / 全部失败时也要让用户看见原因（部分失败在弹窗条目标注里可感知）
        if (digest.aiSummary && (digest.aiSummary.reason || digest.aiSummary.failed > 0)) {
          const aiText = digest.aiSummary.reason || t('msg.aiFallback', { count: digest.aiSummary.failed })
          parts.push('<div class="rss_banner" data-kind="warn">' + esc(t('msg.aiError', { reason: aiText })) + '</div>')
        }
        if (items.length === 0) {
          parts.push('<div class="rss_empty">' + t('list.noDigestItems') + '</div>')
        }
        parts.push('<div class="rss_digestActions">')
        parts.push('<button class="rss_btnGhost" data-action="digest-view"' + (items.length === 0 ? ' disabled' : '') + '>' + t('btn.viewList') + '</button>')
        parts.push('<button class="rss_btnGhost rss_btnIcon" data-action="digest-refresh"' + (state.refreshing ? ' disabled data-loading aria-busy="true"' : '') + ' title="' + (state.refreshing ? t('msg.refreshing') : t('btn.refresh')) + '" aria-label="' + esc(t('btn.refresh')) + '">' + ICON_REFRESH + '</button>')
        parts.push('<button class="rss_btnGhost rss_btnIcon" data-action="digest-copy"' + (items.length === 0 ? ' disabled' : '') + ' title="' + esc(t('btn.copyMarkdown')) + '" aria-label="' + esc(t('btn.copyMarkdown')) + '">' + ICON_COPY + '</button>')
        parts.push('</div>')
      }
      parts.push('</div>')
      return parts.join('')
    }

    function isSubscribed(url) {
      return (state.config?.sources || []).some((source) => source.url === url)
    }

    function catalogToolsHtml() {
      const entries = state.catalogEntries || []
      const subscribed = entries.filter((entry) => isSubscribed(entry.url)).length
      const selectedCount = entries.filter((entry) => state.catalogSelected.has(entry.url)).length
      let html = '<div class="rss_catalogToolbar" id="rss-catalog-tools">'
      html += '<span class="rss_catalogStats">' + t('panel.catalogStats', { total: entries.length, subscribed, selected: selectedCount }) + '</span>'
      html += '<button class="rss_btnGhost" data-action="catalog-select-all">' + t('btn.selectAll') + '</button>'
      html += '<button class="rss_btnGhost" data-action="catalog-clear"' + (selectedCount === 0 ? ' disabled' : '') + '>' + t('btn.clear') + '</button>'
      html += '<button class="rss_btn" data-action="catalog-add-selected"' + (selectedCount === 0 ? ' disabled' : '') + '>' + t('btn.addSelected') + (selectedCount > 0 ? ' (' + selectedCount + ')' : '') + '</button>'
      html += '</div>'
      return html
    }

    function renderCatalogResults() {
      if (state.catalogError) {
        return '<div class="rss_banner" data-kind="error">' + esc(state.catalogError) + '</div>'
      }
      if (state.catalogLoading) {
        return '<div class="rss_loading">' + t('list.loadingCatalog') + '</div>'
      }
      if (state.catalogDisabled) {
        return '<div class="rss_empty">' + t('list.catalogDisabled') + '</div>'
      }
      const entries = state.catalogEntries || []
      if (entries.length === 0) {
        return state.catalogQuery || state.catalogCategory
          ? '<div class="rss_empty">' + t('list.noMatchingFeeds') + '</div>'
          : '<div class="rss_empty">' + t('list.catalogIdle') + '</div>'
      }
      const parts = []
      parts.push(catalogToolsHtml())
      parts.push('<div class="rss_list" id="rss-catalog-list">')
      for (let i = 0; i < entries.length; i++) {
        const entry = entries[i]
        const added = isSubscribed(entry.url)
        parts.push('<div class="rss_item">')
        parts.push('<div class="rss_itemTop">')
        parts.push('<input type="checkbox" data-action="catalog-toggle" data-url="' + esc(entry.url) + '" title="' + esc(t('btn.bulkSelect')) + '"' + (added ? ' disabled' : '') + (state.catalogSelected.has(entry.url) ? ' checked' : '') + ' />')
        parts.push('<div class="rss_itemMain">')
        const originName = entry.catalog || ''
        parts.push('<div class="rss_itemTitle">' + esc(entry.name) + ' <span class="rss_sourceChip">' + esc(entry.category) + '</span><span class="rss_sourceChip rss_catalogOrigin" title="' + esc(t('panel.fromCatalogTitle', { name: originName })) + '">' + esc(t('panel.fromCatalog', { name: originName || t('panel.unknownCatalog') })) + '</span></div>')
        parts.push('<div class="rss_itemMeta">' + esc(entry.url) + '</div>')
        parts.push('</div>')
        parts.push('<button class="rss_linkBtn" data-action="catalog-add" data-index="' + i + '"' + (added ? ' disabled' : '') + '>' + (added ? t('btn.added') : t('btn.add')) + '</button>')
        parts.push('</div>')
        parts.push('</div>')
      }
      parts.push('</div>')
      return parts.join('')
    }

    function renderCatalogSection() {
      const parts = []
      parts.push('<div class="rss_settingSection" id="rss-sec-catalog">')
      parts.push('<div class="rss_settingHint">' + t('panel.catalogHintBefore') + '<a class="rss_linkBtn" href="https://jackyst0.github.io/awesome-rsshub-routes/" target="_blank" rel="noreferrer">awesome-rsshub-routes</a>' + t('panel.catalogHintAfter') + '</div>')
      parts.push('<div id="rss-catalog-sources">' + renderCatalogSourcesBlock() + '</div>')
      parts.push('<div class="rss_addRow rss_catalogSearchRow">')
      parts.push('<input class="rss_input" data-field="rss-catalog-query" value="' + esc(state.catalogQuery) + '" placeholder="' + esc(t('placeholder.catalogSearch')) + '" autocomplete="off" spellcheck="false" />')
      parts.push('<select class="rss_input" data-field="rss-catalog-category">' + catalogCategoryOptions() + '</select>')
      parts.push('<select class="rss_input" data-field="rss-catalog-source">' + catalogSourceOptions() + '</select>')
      parts.push('</div>')
      parts.push('<div id="rss-catalog-results">' + renderCatalogResults() + '</div>')
      parts.push('</div>')
      return parts.join('')
    }

    function renderCatalogSourcesBlock() {
      const parts = []
      parts.push('<div class="rss_catalogSources">')
      const builtin = state.catalogBuiltin
      parts.push('<div class="rss_catalogSourceRow">')
      parts.push('<span class="rss_catalogSourceName">' + t('panel.builtinSource', { name: builtin ? esc(builtin.name) : 'awesome-rsshub-routes' }) + '</span>')
      parts.push('<span class="rss_catalogSourceMeta">' + (builtin ? t('panel.entryCount', { count: builtin.entryCount }) : '…') + ' · ' + t('panel.fixed') + '</span>')
      parts.push('<span class="rss_catalogSourceActions"></span>')
      parts.push('</div>')
      const catalogs = state.config?.catalogs || []
      const statusByUrl = new Map((state.catalogSources || []).map((source) => [source.url, source]))
      for (const catalog of catalogs) {
        const status = statusByUrl.get(catalog.url)
        let meta
        let stateText
        if (status !== undefined) {
          meta = 'title="' + esc(catalog.url) + (status.error ? esc(t('panel.errorDetail', { error: status.error })) : '') + '"'
          stateText = status.ok
            ? t('panel.entryCount', { count: status.entryCount })
            : '<span class="rss_catalogSourceError">' + t('list.loadFailed') + '</span>' + (status.error ? ' · ' + esc(status.error) : '')
        } else {
          stateText = '<span class="rss_catalogSourcePending">' + t('list.pendingSave') + '</span>'
        }
        parts.push('<div class="rss_catalogSourceRow">')
        parts.push('<span class="rss_catalogSourceName" title="' + esc(catalog.name) + '">' + esc(catalog.name) + '</span>')
        parts.push('<span class="rss_catalogSourceMeta" ' + (meta || 'title="' + esc(catalog.url) + '"') + '>' + stateText + '</span>')
        parts.push('<span class="rss_catalogSourceActions"><button class="' + (status === undefined ? 'rss_btnGhost' : 'rss_btnGhost rss_btnDanger') + '" data-action="catalog-remove-source" data-url="' + esc(catalog.url) + '">' + (status === undefined ? t('btn.cancel') : t('btn.remove')) + '</button></span>')
        parts.push('</div>')
      }
      parts.push('<div class="rss_addRow rss_catalogAddRow">')
      parts.push('<input class="rss_input" data-field="rss-catalog-new-name" value="' + esc(state.catalogNewName) + '" placeholder="' + esc(t('placeholder.catalogName')) + '" />')
      parts.push('<input class="rss_input" data-field="rss-catalog-new-url" value="' + esc(state.catalogNewUrl) + '" placeholder="' + esc(t('placeholder.catalogUrl')) + '" spellcheck="false" />')
      parts.push('<button class="rss_btnGhost" data-action="catalog-add-source">' + t('btn.addCatalog') + '</button>')
      parts.push('</div>')
      parts.push('</div>')
      return parts.join('')
    }

    function renderCategoriesSection() {
      const parts = []
      parts.push('<div class="rss_settingSection" id="rss-sec-categories">')
      parts.push('<div class="rss_settingTitle">' + t('panel.categories') + '</div>')
      parts.push('<div class="rss_settingHint">' + t('panel.categoriesHint') + '</div>')
      const categories = state.config?.categories || []
      if (categories.length > 0) {
        parts.push('<div class="rss_categories">')
        for (const category of categories) {
          parts.push('<span class="rss_categoryChip">' + esc(category) + '<button class="rss_categoryRemove" data-action="config-remove-category" data-value="' + esc(category) + '" aria-label="' + esc(t('btn.removeCategory', { category })) + '">' + ICON_CLOSE + '</button></span>')
        }
        parts.push('</div>')
      } else {
        parts.push('<div class="rss_empty">' + t('list.noCategories') + '</div>')
      }
      parts.push('<div class="rss_addRow">')
      parts.push('<input class="rss_input" data-field="rss-new-category" value="' + esc(state.newCategory) + '" placeholder="' + esc(t('placeholder.newCategory')) + '" />')
      parts.push('<button class="rss_btnGhost" data-action="config-add-category">' + t('btn.add') + '</button>')
      parts.push('</div>')
      parts.push('</div>')
      return parts.join('')
    }

    function renderAggregateSection() {
      const config = state.config
      const parts = []
      parts.push('<div class="rss_settingSection" id="rss-sec-aggregate">')
      parts.push('<div class="rss_settingTitle">' + t('panel.aggregate') + '</div>')
      parts.push('<div class="rss_formGrid">')
      parts.push('<div class="rss_field"><span class="rss_fieldLabel">' + t('panel.maxPerSource') + '</span><input class="rss_input" data-field="rss-max-items" type="number" min="1" value="' + (config.maxItemsPerSource || 5) + '" /></div>')
      parts.push('<div class="rss_field"><span class="rss_fieldLabel">' + t('panel.maxTotal') + '</span><input class="rss_input" data-field="rss-max-total" type="number" min="1" value="' + (config.maxTotalItems || 30) + '" /></div>')
      parts.push('<div class="rss_field"><span class="rss_fieldLabel">' + t('panel.dailyTime') + '</span><input class="rss_input" data-field="rss-daily-time" type="time" value="' + esc(config.dailyTime || '08:00') + '" /></div>')
      parts.push('</div>')
      parts.push('<div class="rss_settingHint">' + t('panel.aggregateHint') + '</div>')
      parts.push('</div>')
      return parts.join('')
    }

    function renderAiSection() {
      const ai = state.config?.ai || {}
      const parts = []
      parts.push('<div class="rss_settingSection" id="rss-sec-ai">')
      parts.push('<div class="rss_settingTitle">' + t('panel.ai') + '</div>')
      parts.push('<label class="rss_checkRow"><input type="checkbox" data-field="rss-ai-enabled" ' + (ai.enabled === true ? 'checked' : '') + ' /> ' + t('panel.aiEnabled') + '</label>')
      parts.push('<div class="rss_formGrid">')
      parts.push('<div class="rss_field"><span class="rss_fieldLabel">' + t('panel.aiProvider') + '</span><input class="rss_input" data-field="rss-ai-provider" value="' + esc(ai.provider || '') + '" placeholder="' + esc(t('placeholder.aiModel')) + '" autocomplete="off" spellcheck="false" /></div>')
      parts.push('<div class="rss_field"><span class="rss_fieldLabel">' + t('panel.aiModel') + '</span><input class="rss_input" data-field="rss-ai-model" value="' + esc(ai.model || '') + '" placeholder="' + esc(t('placeholder.aiModel')) + '" autocomplete="off" spellcheck="false" /></div>')
      parts.push('<div class="rss_field"><span class="rss_fieldLabel">' + t('panel.aiMaxItems') + '</span><input class="rss_input" data-field="rss-ai-max-items" type="number" min="1" max="50" value="' + (ai.maxItems || 20) + '" /></div>')
      parts.push('</div>')
      parts.push('<div class="rss_settingHint">' + t('panel.aiHint') + '</div>')
      parts.push('</div>')
      return parts.join('')
    }

    /** 懒创建 state.config.ai：首次编辑 AI 字段时补上默认关闭的空壳。 */
    function aiConfig() {
      if (!state.config.ai) state.config.ai = { enabled: false }
      return state.config.ai
    }

    function renderPluginSection() {
      const config = state.config
      const parts = []
      parts.push('<div class="rss_settingSection" id="rss-sec-plugin">')
      parts.push('<div class="rss_settingTitle">' + t('panel.plugin') + '</div>')
      parts.push('<label class="rss_checkRow"><input type="checkbox" data-field="rss-enabled" ' + (config.enabled !== false ? 'checked' : '') + ' /> ' + t('panel.pluginEnabled') + '</label>')
      parts.push('</div>')
      return parts.join('')
    }


    function renderAll(container) {
      panelEl = container
      const parts = []
      parts.push('<div class="rss_panel">')
      parts.push(renderHeader())
      parts.push(renderErrorNode())
      if (state.loading || !state.config) {
        parts.push('<div class="rss_loading">' + t('list.loading') + '</div>')
      } else {
        parts.push(renderPluginSection())
        parts.push(renderDigestSection())
        parts.push(renderChannelsSection())
        parts.push(renderCategoriesSection())
        parts.push(renderAggregateSection())
        parts.push(renderAiSection())
      }
      parts.push('</div>')
      container.innerHTML = parts.join('')
    }

    /* ================================ 区块更新 ================================ */

    function updateSection(id, html) {
      if (panelEl === undefined || !panelEl.isConnected) return
      const node = panelEl.querySelector('#' + id)
      if (node === null) return
      node.outerHTML = html
    }

    function updateHeader() {
      updateSection('rss-header', renderHeader())
    }


    function updateError() {
      updateSection('rss-error', renderErrorNode())
    }

    function updateCatalogResults() {
      const root = catalogRoot()
      const node = root !== undefined ? root.querySelector('#rss-catalog-results') : null
      if (node === null) return
      node.innerHTML = renderCatalogResults()
    }

    function updateCatalogTools() {
      const root = catalogRoot()
      const node = root !== undefined ? root.querySelector('#rss-catalog-tools') : null
      if (node === null) return
      node.outerHTML = catalogToolsHtml()
    }

    function updateCustomList() {
      updateChannelList()
    }

    function updateCatalogSelect() {
      const root = catalogRoot()
      const select = root !== undefined ? root.querySelector('[data-field="rss-catalog-category"]') : null
      if (select === null) return
      select.innerHTML = catalogCategoryOptions()
    }

    function markDirty() {
      if (state.dirty) return
      state.dirty = true
      updateHeader()
    }

    /* ================================ 弹窗 ================================ */

    function siteFromFeedUrl(url) {
      try {
        return new URL(url).origin + '/'
      } catch {
        return ''
      }
    }

    function sourceSiteMap(digest, config) {
      const map = {}
      for (const source of config?.sources || []) {
        if (source && source.name && source.url) map[source.name] = siteFromFeedUrl(source.url)
      }
      for (const source of digest?.sources || []) {
        if (source && source.name) map[source.name] = source.site || map[source.name] || ''
      }
      return map
    }

    function modalCategories() {
      const set = new Set()
      for (const item of state.digest?.items || []) {
        set.add(item.category || t('panel.uncategorized'))
      }
      return Array.from(set)
    }

    function filteredModalItems() {
      const query = (state.modalQuery || '').trim().toLowerCase()
      const items = state.digest?.items || []
      if (!query && !state.modalCategory) return items
      return items.filter((item) => {
        if (state.modalCategory && (item.category || t('panel.uncategorized')) !== state.modalCategory) return false
        if (!query) return true
        const hay = [item.title, item.aiSummary, item.summary, item.source, item.category].filter(Boolean).join(' ').toLowerCase()
        return hay.includes(query)
      })
    }

    function renderModalItems(items, sourceSites) {
      if (!items || items.length === 0) return '<div class="rss_empty">' + t('list.noItemsToday') + '</div>'
      const sites = sourceSites || {}
      const byCategory = {}
      for (const item of items) {
        const key = item.category || t('panel.uncategorized')
        if (!byCategory[key]) byCategory[key] = []
        byCategory[key].push(item)
      }
      const parts = []
      for (const category of Object.keys(byCategory)) {
        const bySource = {}
        for (const item of byCategory[category]) {
          const key = item.source || t('panel.uncategorized')
          if (!bySource[key]) bySource[key] = []
          bySource[key].push(item)
        }
        parts.push('<div class="rss_source">')
        parts.push('<div class="rss_sourceName">' + esc(category) + '</div>')
        for (const source of Object.keys(bySource)) {
          const site = sites[source]
          const siteLink = site
            ? ' <a class="rss_linkBtn" href="' + esc(site) + '" target="_blank" rel="noreferrer">' + t('btn.viewMore') + '</a>'
            : ''
          parts.push('<div class="rss_subSource">')
          parts.push('<span>' + esc(source) + '</span>' + siteLink)
          parts.push('</div>')
          parts.push('<div class="rss_list">')
          for (const item of bySource[source]) {
            const title = item.title || t('list.untitled')
            const meta = []
            if (item.date) meta.push(esc(String(item.date).slice(0, 10)))
            parts.push('<div class="rss_item">')
            parts.push('<div class="rss_itemTop">')
            parts.push('<div class="rss_itemMain">')
            parts.push('<div class="rss_itemTitle">' + (item.link
              ? '<a href="' + esc(item.link) + '" target="_blank" rel="noreferrer">' + esc(title) + '</a>'
              : esc(title)) + (meta.length ? ' <span class="rss_itemMeta">' + meta.join(' / ') + '</span>' : '') + '</div>')
            // AI 摘要优先，无则退回原文摘要（两者都按 120 字截断展示）
            const summary = item.aiSummary || item.summary
            if (summary) {
              const text = summary.length > 120 ? summary.slice(0, 120) + '…' : summary
              parts.push('<div class="rss_itemSummary">' + esc(text) + '</div>')
            }
            parts.push('</div>')
            parts.push('</div>')
            parts.push('</div>')
          }
          parts.push('</div>')
        }
        parts.push('</div>')
      }
      return parts.join('')
    }

    /**
     * 筛选 + 动作行：搜索框、计数、复制 / 刷新，以及分类 chips。
     * 它是 .rss_modal 的固定子项（不在滚动区里），所以列表怎么滚都看得见——
     * 与 tty 的 SFTP 面板「路径输入 + 刷新/新建目录/上传」同一形态。
     */
    function renderModalFilter() {
      const digest = state.digest
      const total = digest ? (digest.items || []).length : 0
      const visible = digest ? filteredModalItems().length : 0
      const empty = !digest || total === 0
      const cats = modalCategories()
      const parts = []
      parts.push('<div class="rss_modalFilter">')
      parts.push('<div class="rss_modalToolbar">')
      // 没有 digest 时不渲染搜索框（列表是空的，搜也没意义），只留动作
      if (digest) {
        parts.push('<input class="rss_input" data-field="rss-modal-search" value="' + esc(state.modalQuery) + '" placeholder="' + esc(t('placeholder.modalSearch')) + '" autocomplete="off" spellcheck="false" />')
      }
      parts.push('<span class="rss_modalCount">' + (digest ? t('panel.visibleCount', { visible, total }) : '') + '</span>')
      parts.push('<button class="rss_btnGhost rss_btnIcon" data-action="modal-copy"' + (empty ? ' disabled' : '') + ' title="' + esc(t('btn.copyMarkdown')) + '" aria-label="' + esc(t('btn.copyMarkdown')) + '">' + ICON_COPY + '</button>')
      parts.push('<button class="rss_btnGhost rss_btnIcon" data-action="modal-refresh"' + (state.modalLoading ? ' disabled data-loading aria-busy="true"' : '') + ' title="' + (state.modalLoading ? t('msg.refreshing') : t('btn.refresh')) + '" aria-label="' + esc(t('btn.refresh')) + '">' + ICON_REFRESH + '</button>')
      parts.push('</div>')
      if (cats.length > 1) {
        parts.push('<div class="rss_modalChips">')
        parts.push('<button class="rss_modalChip' + (state.modalCategory === '' ? ' rss_modalChipActive' : '') + '" data-action="modal-cat" data-value="">' + t('btn.all') + '</button>')
        for (const cat of cats) {
          parts.push('<button class="rss_modalChip' + (state.modalCategory === cat ? ' rss_modalChipActive' : '') + '" data-action="modal-cat" data-value="' + esc(cat) + '">' + esc(cat) + '</button>')
        }
        parts.push('</div>')
      }
      parts.push('</div>')
      return parts.join('')
    }

    /**
     * 「正在刷新订阅源」的过渡层（0.3.1）：顶部 2px 不定长进度条 + 浮层胶囊。
     *
     * 与 dsh-docker 的切目标过渡同一套语言，三条理由也一样：
     *   - **不推版**：两者都绝对定位。插进文档流会把标题与列表整块推下去；
     *   - **有归属**：胶囊写「当前显示：08:12 生成」——刷新期间看到的是旧数据这件事
     *     要说清楚，否则用户会以为刷新没生效；
     *   - **不抢眼**：可见文案只两段（状态 · 归属），完整解释放 title。
     * 只在**慢加载**（沿用 180ms 消抖）时出现，毫秒级请求不会闪。
     */
    /** 只取时钟 HH:MM：胶囊里写「生成于 14:25」比带日期的全量时间戳利落。 */
    function clockText(iso) {
      const date = new Date(iso)
      if (Number.isNaN(date.getTime())) return ''
      return String(date.getHours()).padStart(2, '0') + ':' + String(date.getMinutes()).padStart(2, '0')
    }

    /** 胶囊文案：可见部分只两段（状态 · 归属），完整解释进 title。 */
    function busyText(digest) {
      const stamp = digest && digest.generatedAt ? fmtTime(digest.generatedAt) : ''
      const clock = digest && digest.generatedAt ? clockText(digest.generatedAt) : ''
      const label = clock === ''
        ? t('msg.refreshingFeeds')
        : t('msg.refreshingFeedsAt', { clock })
      // fmtTime 已经带了日期，不要再拼 digest.date（会变成「2026-09-14 2026/9/14 14:25」）
      const full = t('msg.refreshingTitle')
        + (stamp === '' ? '' : t('msg.refreshingTitleData', { stamp }))
      return { label, full }
    }

    /** 顶部 2px 不定长进度条（绝对定位在容器顶边）。 */
    function busyBarHtml() {
      return '<div class="rss_busyBar" aria-hidden="true"></div>'
    }

    /** 胶囊本体（视觉由 CSS 按容器区分：弹窗行内 / 设置卡绝对定位）。 */
    function busyPillHtml(digest) {
      const { label, full } = busyText(digest)
      // 层次与 docker 一致：状态与归属里的「值」用强调色，连接词压淡
      const [head, tail] = label.split(' · ')
      const text = tail === undefined
        ? '<span class="rss_busyDim">' + esc(head) + '</span>'
        : '<span class="rss_busyDim">' + esc(head) + ' · </span><strong>' + esc(tail) + '</strong>'
      return '<div class="rss_busyPill" title="' + esc(full) + '" aria-busy="true">' + ICON_REFRESH + text + '</div>'
    }

    /** 设置卡用：进度条 + 绝对定位胶囊（都挂在区块上）。 */
    function busyCardHtml(digest) {
      return busyBarHtml() + busyPillHtml(digest)
    }

    function renderModalBody() {
      const digest = state.digest
      const allItems = digest?.items || []
      const items = filteredModalItems()
      const parts = []
      if (digest?.errors && digest.errors.length) {
        parts.push('<div class="rss_banner" data-kind="warn">' + t('msg.fetchFailedList', { list: digest.errors.map((e) => esc(e.source + ': ' + e.error)).join('; ') }) + '</div>')
      }
      if (items.length === 0) {
        parts.push('<div class="rss_empty">' + (allItems.length === 0 ? t('list.noItemsToday') : t('list.noMatchingItems')) + '</div>')
      } else {
        parts.push(renderModalItems(items, sourceSiteMap(digest, state.config)))
      }
      return parts.join('')
    }

    /* ---------- 加载态：消抖 + 骨架屏 ---------- */

    /**
     * 超过这个时长仍未加载完，才允许出占位。
     * GET /api/dsh-rss/digest 只是读 ~/.dsh/rss-digest/ 里的文件（毫秒级），不加消抖的话
     * 骨架屏会闪一帧就被真内容替掉，比直接出内容更难受。
     */
    const LOADING_DEBOUNCE_MS = 180
    let modalSlowTimer = null

    function beginLoading() {
      state.modalLoading = true
      state.modalSlow = false
      clearTimeout(modalSlowTimer)
      modalSlowTimer = setTimeout(() => {
        modalSlowTimer = null
        if (!state.modalLoading) return
        state.modalSlow = true
        if (state.digest) {
          // 有旧数据：只把 body 标记成「更新中」，绝不整树重渲染——重渲染会重置滚动位置、
          // 打断正在输入的搜索框。慢刷新（>阈值）才需要这个提示。
          const body = modalEl !== undefined ? modalEl.querySelector('.rss_modalBody') : null
          if (body !== null) {
            body.setAttribute('data-updating', '')
            body.setAttribute('aria-busy', 'true')
          }
          /*
           * 过渡层（进度条 + 胶囊）也是**只插入、不重渲染**：它俩是绝对定位的独立节点，
           * 插进去不会动列表布局，正好绕开「重渲染会丢焦点/滚动」这个约束。
           * （放在 renderDigestModal 里生成是不够的——这条路径根本不重渲染。）
           */
          const modal = modalEl !== undefined ? modalEl.querySelector('.rss_modal') : null
          if (modal !== null && modal.querySelector('.rss_busyBar') === null) {
            // 进度条 + 胶囊都挂在 .rss_modalFilter 上：条贴分类行下沿，胶囊骑线上居中
            const filter = modal.querySelector('.rss_modalFilter')
            if (filter !== null) filter.insertAdjacentHTML('beforeend', busyBarHtml() + busyPillHtml(state.digest))
          }
          return
        }
        // 没数据可显示：重渲染以淡入骨架
        renderDigestModal()
      }, LOADING_DEBOUNCE_MS)
    }

    function endLoading() {
      clearTimeout(modalSlowTimer)
      modalSlowTimer = null
      state.modalLoading = false
      state.modalSlow = false
      // 收掉过渡层。整树重渲染的路径会自然清掉，这里覆盖「只插节点、不重渲染」那条。
      if (modalEl !== undefined) {
        for (const node of modalEl.querySelectorAll('.rss_busyBar, .rss_busyPill')) node.remove()
      }
    }

    /**
     * 骨架屏：4 张与 .rss_item 同形的卡片轮廓（标题条 + 两行摘要）。
     * pending=true 时先渲染但保持透明——先占住高度（弹窗不会从矮变高跳一下），
     * 等消抖阈值过了再去掉 data-pending 淡入，毫秒级请求就不会「闪一下骨架」。
     */
    function renderSkeleton(pending) {
      const widths = [88, 72, 94, 66]
      const parts = ['<div class="rss_skel"' + (pending ? ' data-pending' : '') + ' aria-hidden="true">']
      for (const width of widths) {
        parts.push('<div class="rss_skelCard">')
        parts.push('<div class="rss_skelLine" style="width:' + width + '%"></div>')
        parts.push('<div class="rss_skelLine" data-w="sm" style="width:96%"></div>')
        parts.push('<div class="rss_skelLine" data-w="sm" style="width:58%"></div>')
        parts.push('</div>')
      }
      parts.push('</div>')
      return parts.join('')
    }

    /**
     * 整树重渲染弹窗。
     * @param keepScroll 数据落地时保留列表滚动位置（刷新不该把用户读到一半的列表弹回顶部）。
     *                   搜索/筛选触发的重渲染传 false。
     */
    function renderDigestModal(keepScroll = false) {
      if (modalEl === undefined) return
      const digest = state.digest
      let content
      let updating = false
      if (digest) {
        // 已有数据：刷新不清空列表（stale-while-revalidate），新数据回来整体替换。
        // 原来这里会无条件换成「加载中…」，把看得好好的条目抹掉。
        content = renderModalBody()
        // 压暗同样要消抖：GET /digest 是毫秒级，打开弹窗时立刻压暗会出现
        // 「列表出现 → 变淡几帧 → 恢复」的闪烁，只有慢加载才需要这个提示
        updating = state.modalLoading && state.modalSlow
      } else if (state.modalLoading) {
        // 真没数据可显示：骨架先以透明态占位，过了消抖阈值才淡入（见 renderSkeleton）
        content = renderSkeleton(!state.modalSlow)
      } else {
        content = '<div class="rss_empty">' + t('list.noDigest') + '</div>'
      }
      if (state.error) {
        content = '<div class="rss_banner" data-kind="error">' + esc(state.error) + '</div>' + content
      }
      const title = t('panel.digest') + (digest && digest.date ? ' · ' + esc(digest.date) : '')
      // 重渲染会重建整棵 DOM，两样东西要还回去：
      //  - 搜索框焦点/光标：刷新期间列表是活的，用户可能正在输入，落地时不能把人踢出去；
      //  - 列表滚动位置（仅 keepScroll）：刷新落地不该把读到一半的列表弹回顶部。
      //    筛选/搜索引起的重渲染传 false —— 那是换了内容，理应回到顶部。
      const prevSearch = modalEl.querySelector('[data-field="rss-modal-search"]')
      const searchFocused = prevSearch !== null && document.activeElement === prevSearch
      const caretPos = searchFocused ? prevSearch.selectionStart : null
      const prevBody = keepScroll ? modalEl.querySelector('.rss_modalBody') : null
      const prevScroll = prevBody !== null ? prevBody.scrollTop : 0
      modalEl.innerHTML =
        '<div class="rss_modalBackdrop" data-action="modal-backdrop">' +
          '<div class="rss_modal" role="dialog" aria-modal="true" aria-label="' + title + '">' +
            '<div class="rss_modalHeader">' +
              '<h3 class="rss_modalTitle">' + title + '</h3>' +
              '<button class="rss_modalClose" data-action="modal-close" aria-label="' + esc(t('btn.close')) + '">' + ICON_CLOSE + '</button>' +
            '</div>' +
            renderModalFilter() +
            // 过渡层（进度条 + 胶囊）在 renderModalFilter 里，绝对定位在 .rss_modalFilter 上；
            // 正文照旧（stale-while-revalidate）
            '<div class="rss_modalBody"' + (updating ? ' data-updating aria-busy="true"' : '')
              // keepScroll=true 只出现在「数据落地」那次渲染（loadDigestModal / refreshDigestModal
              // 的 finally），用它当落地信号做 8px 上滑淡入；搜索/筛选的重渲染不带这个标记
              + (keepScroll ? ' data-landed' : '') + '>'
              + content + '</div>' +
          '</div>' +
        '</div>'
      const search = modalEl.querySelector('[data-field="rss-modal-search"]')
      if (search !== null) {
        search.addEventListener('input', () => {
          const caret = search.selectionStart
          state.modalQuery = search.value
          renderDigestModal()
          const next = modalEl.querySelector('[data-field="rss-modal-search"]')
          if (next !== null) {
            next.focus()
            try {
              next.setSelectionRange(caret, caret)
            } catch {
              /* 无 caret 的输入框忽略 */
            }
          }
        })
        if (searchFocused) {
          search.focus()
          if (caretPos !== null) {
            try {
              search.setSelectionRange(caretPos, caretPos)
            } catch {
              /* 无 caret 的输入框忽略 */
            }
          }
        }
      }
      if (prevScroll > 0) {
        const nextBody = modalEl.querySelector('.rss_modalBody')
        if (nextBody !== null) nextBody.scrollTop = prevScroll
      }
    }

    function openDigestModal() {
      if (modalEl === undefined || !modalEl.isConnected) {
        modalEl = document.createElement('div')
        modalEl.className = 'rss_modalRoot'
        document.body.appendChild(modalEl)
      }
      state.modalOpener = document.activeElement instanceof HTMLElement ? document.activeElement : null
      modalEl.style.display = ''
      beginLoading()
      state.modalQuery = ''
      state.modalCategory = ''
      renderDigestModal()
      bindModalKeys()
      void loadDigestModal()
      const closeBtn = modalEl.querySelector('[data-action="modal-close"]')
      if (closeBtn !== null) closeBtn.focus()
    }

    function closeDigestModal() {
      if (modalEl !== undefined) modalEl.style.display = 'none'
      const opener = state.modalOpener
      if (opener !== null && opener.isConnected && typeof opener.focus === 'function') {
        opener.focus()
      }
    }

    function bindModalKeys() {
      if (modalEl === undefined || modalEl.dataset.keysBound === '1') return
      modalEl.dataset.keysBound = '1'
      modalEl.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
          event.stopPropagation()
          closeDigestModal()
          return
        }
        if (event.key !== 'Tab') return
        const focusables = Array.from(modalEl.querySelectorAll('button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'))
        if (focusables.length === 0) return
        const first = focusables[0]
        const last = focusables[focusables.length - 1]
        const active = document.activeElement
        if (event.shiftKey) {
          if (active === first || active === modalEl || active === null) {
            event.preventDefault()
            last.focus()
          }
        } else if (active === last) {
          event.preventDefault()
          first.focus()
        }
      })
    }

    async function loadDigestModal() {
      beginLoading()
      renderDigestModal()
      try {
        const [digestRes, configRes] = await Promise.all([
          apiRequest(API.digest),
          apiRequest(API.config),
        ])
        state.digest = digestRes
        state.config = configRes.config || { sources: [], categories: [], maxItemsPerSource: 5, maxTotalItems: 30, dailyTime: '08:00' }
        state.error = ''
      } catch (error) {
        state.error = error.message
      } finally {
        endLoading()
        renderDigestModal(true)
      }
    }

    async function refreshDigestModal() {
      beginLoading()
      renderDigestModal()
      try {
        const data = await apiRequest(API.refresh, { method: 'POST' })
        state.digest = data
        toast(t('msg.refreshed'), 'ok')
      } catch (error) {
        toast(error.message, 'error')
      } finally {
        endLoading()
        renderDigestModal(true)
      }
    }

    /* ================================ 侧边栏入口 ================================ */

    const RSS_SIDEBAR_ICON = '<svg viewBox="0 0 16 16" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12h.01M4 8a4 4 0 0 1 4 4M4 4a8 8 0 0 1 8 8"/><circle cx="12" cy="12" r="1" fill="currentColor" stroke="none"/></svg>'

    /* ================================ 订阅源目录弹窗 ================================ */

    function renderCatalogModalHtml() {
      return '<div class="rss_modalBackdrop" data-action="catalog-backdrop">' +
        '<div class="rss_modal rss_catalogModal" role="dialog" aria-modal="true" aria-label="' + esc(t('panel.feedCatalog')) + '">' +
          '<div class="rss_modalHeader">' +
            '<h3 class="rss_modalTitle">' + t('panel.feedCatalog') + '</h3>' +
            '<button class="rss_modalClose" data-action="catalog-close" aria-label="' + esc(t('btn.close')) + '">' + ICON_CLOSE + '</button>' +
          '</div>' +
          '<div class="rss_modalBody">' + renderCatalogSection() + '</div>' +
          '<div class="rss_modalFooter">' +
            '<span class="rss_modalCount"></span>' +
            '<button class="rss_btnGhost" data-action="catalog-close">' + t('btn.close') + '</button>' +
          '</div>' +
        '</div>' +
      '</div>'
    }

    function renderCatalogModal() {
      if (catalogModalEl === undefined) return
      catalogModalEl.innerHTML = renderCatalogModalHtml()
    }

    function openCatalogModal() {
      if (catalogModalEl === undefined || !catalogModalEl.isConnected) {
        catalogModalEl = document.createElement('div')
        catalogModalEl.className = 'rss_modalRoot'
        document.body.appendChild(catalogModalEl)
      }
      state.catalogOpen = true
      renderCatalogModal()
      catalogModalEl.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') closeCatalogModal()
      })
      loadCatalog()
      const search = catalogModalEl.querySelector('[data-field="rss-catalog-query"]')
      if (search !== null) search.focus()
    }

    function closeCatalogModal() {
      state.catalogOpen = false
      if (catalogModalEl !== undefined) {
        catalogModalEl.remove()
        catalogModalEl = undefined
      }
    }


    function sidebarRoot() {
      const column = document.querySelector('[data-pane="sidebar"], [class*="sidebarCol"]')
      if (column === null) return undefined
      return column.querySelector('[class*="logoRow"]')?.parentElement ?? column.firstElementChild
    }

    function newSessionButton(root) {
      const nested = root.querySelector('button[class*="newSession"]')
      if (nested !== null) return nested
      for (const child of root.children) {
        if (child.tagName === 'BUTTON') return child
      }
      return undefined
    }

    function createSidebarEntry() {
      const entry = document.createElement('button')
      entry.type = 'button'
      entry.dataset.dshRssEntry = ''
      entry.className = 'rss_sidebarEntry'
      entry.setAttribute('aria-label', t('panel.digest'))
      entry.title = t('panel.digest')
      entry.innerHTML = '<span class="rss_sidebarEntryIcon">' + RSS_SIDEBAR_ICON + '</span><span class="rss_sidebarEntryLabel">' + t('panel.digest') + '</span>'
      entry.addEventListener('click', () => {
        openDigestModal()
      })
      return entry
    }

    /* ============================ 入口显隐闸门 ============================ */

    /**
     * 「今日值得读」入口的显隐：config 确认「插件已禁用」（enabled === false）后
     * 收起，其余情况（含 config 拉取失败）保持显示。entryGate 由 apply 挂载期间
     * 注入（null = 已卸载，迟到的缓存刷新不允许再把入口挂回来）；禁用瞬间已打开
     * 的摘要弹窗一并收掉。
     */
    let entryGate = null
    let entryVisible = false

    function setEntryVisible(visible) {
      entryVisible = visible
      if (entryGate !== null) entryGate.set(visible)
    }

    /** 由 config 推进入口显隐：仅「确认 enabled:false」收起。 */
    function syncEntryFromConfig(config) {
      setEntryVisible(!(config !== null && typeof config === 'object' && config.enabled === false))
    }

    /** 挂载时预取一次配置：驱动入口显隐（打开面板时 load() 会再拉一次）。 */
    async function primeConfig() {
      try {
        const res = await apiRequest(API.config)
        state.config = res.config || state.config
        syncEntryFromConfig(state.config)
      } catch {
        /* 挂载时宿主可能未就绪：入口先保持显示 */
      }
    }

    function placeSidebarEntry(root, entry) {
      const button = newSessionButton(root)
      if (button === undefined) return false
      if (entry.parentElement !== root) {
        const row = button.closest('[class*="logoRow"]')
        const base = row !== null && row.parentElement === root ? row : button
        const family = Array.from(root.children).filter((el) => el instanceof HTMLElement && el.matches('[data-dsh-rss-entry], [data-dsh-taskboard-entry], [data-dsh-ssh-entry]'))
        if (family.length > 0) {
          const last = family[family.length - 1]
          root.insertBefore(entry, last.nextSibling)
        } else {
          root.insertBefore(entry, base.nextElementSibling)
        }
      }
      return true
    }

    function mountSidebarEntry() {
      if (typeof document !== 'undefined' && document.querySelector('[data-dsh-rss-entry]') !== null) return () => {}
      const entry = createSidebarEntry()
      let root
      let placed = false

      const tryPlace = () => {
        if (root !== undefined && !root.isConnected) {
          rootObserver.disconnect()
          root = undefined
          placed = false
        }
        if (placed) {
          if (document.body.contains(entry)) return
          rootObserver.disconnect()
          root = undefined
          placed = false
        }
        root ??= sidebarRoot()
        if (root === undefined) return
        placed = placeSidebarEntry(root, entry)
        if (placed) {
          rootObserver.observe(root, { childList: true, subtree: true })
        }
      }

      const waitObserver = new MutationObserver(() => {
        tryPlace()
      })
      waitObserver.observe(document.body, { childList: true, subtree: true })

      const rootObserver = new MutationObserver(() => {
        if (root === undefined || !root.isConnected) {
          placed = false
          tryPlace()
          return
        }
        if (!root.contains(entry)) placed = placeSidebarEntry(root, entry)
      })

      tryPlace()
      return () => {
        waitObserver.disconnect()
        rootObserver.disconnect()
        entry.remove()
      }
    }

    /* ================================ 输入委托（按需更新，不再整面板重建） ================================ */

    const FIELD_HANDLERS = {
      'rss-enabled': (el) => {
        if (!state.config) return
        state.config.enabled = el.checked
        markDirty()
      },
      'rss-source-name': (el) => {
        if (!state.config || el.dataset.index === undefined) return
        const source = state.config.sources[Number(el.dataset.index)]
        if (source) {
          source.name = el.value
          markDirty()
        }
      },
      'rss-source-url': (el) => {
        if (!state.config || el.dataset.index === undefined) return
        const source = state.config.sources[Number(el.dataset.index)]
        if (source) {
          source.url = el.value
          markDirty()
        }
      },
      'rss-source-category': (el) => {
        if (!state.config || el.dataset.index === undefined) return
        const source = state.config.sources[Number(el.dataset.index)]
        if (source) {
          source.category = el.value || undefined
          markDirty()
        }
      },
      'rss-source-limit': (el) => {
        if (!state.config || el.dataset.index === undefined) return
        const source = state.config.sources[Number(el.dataset.index)]
        if (source) {
          const value = Number(el.value)
          source.limit = Number.isFinite(value) && value > 0 ? value : undefined
          markDirty()
        }
      },
      'rss-builtin-category': (el) => {
        if (!state.config) return
        const key = el.dataset.key
        const builtin = (state.builtins || []).find((item) => item.key === key)
        if (!builtin) return
        let entry = state.config.sources.find((source) => builtinOf(source)?.key === key)
        if (!entry) {
          entry = { name: builtin.name, url: builtin.url, builtin: builtin.key }
          state.config.sources.push(entry)
          const checkbox = panelEl !== undefined ? panelEl.querySelector('[data-action="builtin-toggle"][data-key="' + key + '"]') : null
          if (checkbox !== null) checkbox.checked = true
          updateChannels()
        }
        entry.category = el.value || undefined
        markDirty()
        scheduleSave()
      },
      'rss-new-category': (el) => {
        state.newCategory = el.value
      },
      'rss-catalog-query': (el) => {
        state.catalogQuery = el.value
        scheduleCatalogLoad()
      },
      'rss-custom-query': (el) => {
        state.customQuery = el.value
        updateCustomList()
      },
      'rss-import-text': (el) => {
        state.importText = el.value
      },
      'rss-import-file': (el) => {
        const file = el.files && el.files[0]
        if (!file) return
        const reader = new FileReader()
        reader.onload = () => importSourcesFromText(String(reader.result || ''), 'OPML', true)
        reader.readAsText(file)
        el.value = '' // 允许再次选择同一文件
      },
      'rss-catalog-category': (el) => {
        state.catalogCategory = el.value
        loadCatalog()
      },
      'rss-catalog-source': (el) => {
        state.catalogSource = el.value
        loadCatalog()
      },
      'rss-catalog-new-name': (el) => {
        state.catalogNewName = el.value
      },
      'rss-catalog-new-url': (el) => {
        state.catalogNewUrl = el.value
      },
      'rss-max-items': (el) => {
        if (!state.config) return
        const value = Number(el.value)
        state.config.maxItemsPerSource = Number.isFinite(value) && value > 0 ? value : undefined
        markDirty()
      },
      'rss-max-total': (el) => {
        if (!state.config) return
        const value = Number(el.value)
        state.config.maxTotalItems = Number.isFinite(value) && value > 0 ? value : undefined
        markDirty()
      },
      'rss-daily-time': (el) => {
        if (!state.config) return
        state.config.dailyTime = el.value
        markDirty()
      },
      'rss-ai-enabled': (el) => {
        if (!state.config) return
        aiConfig().enabled = el.checked
        markDirty()
      },
      'rss-ai-provider': (el) => {
        if (!state.config) return
        aiConfig().provider = el.value.trim()
        markDirty()
      },
      'rss-ai-model': (el) => {
        if (!state.config) return
        aiConfig().model = el.value.trim()
        markDirty()
      },
      'rss-ai-max-items': (el) => {
        if (!state.config) return
        const value = Number(el.value)
        aiConfig().maxItems = Number.isFinite(value) && value > 0 ? Math.min(50, Math.round(value)) : undefined
        markDirty()
      },
    }

    function handleFieldEvent(event) {
      const target = event.target
      const el = target !== null && target.closest ? target.closest('[data-field^="rss-"]') : null
      if (el === null) return
      const field = el.dataset.field
      if (field === 'rss-modal-search') return
      const handler = FIELD_HANDLERS[field]
      if (typeof handler !== 'function') return
      handler(el)
    }

    /* ================================ 数据操作 ================================ */

    let catalogTimer = null

    function scheduleCatalogLoad() {
      clearTimeout(catalogTimer)
      catalogTimer = setTimeout(loadCatalog, 250)
    }

    async function loadCatalog() {
      state.catalogLoading = true
      state.catalogError = ''
      updateCatalogResults()
      try {
        const params = new URLSearchParams()
        if (state.catalogQuery && state.catalogQuery.trim()) params.set('q', state.catalogQuery.trim())
        if (state.catalogCategory) params.set('category', state.catalogCategory)
        if (state.catalogSource) params.set('source', state.catalogSource)
        const suffix = params.toString() ? '?' + params.toString() : ''
        const data = await apiRequest(API.catalog + suffix)
        state.catalogEntries = data.entries || []
        state.catalogCategories = data.categories || state.catalogCategories
        state.catalogSourceNames = data.sources || state.catalogSourceNames
        state.catalogSources = data.catalogs || []
        state.catalogBuiltin = data.builtin || null
        state.catalogDisabled = data.disabled === true
        updateCatalogSelect()
        updateCatalogSources()
      } catch (error) {
        state.catalogError = error.message
        state.catalogEntries = []
      } finally {
        state.catalogLoading = false
        updateCatalogResults()
      }
    }

    async function load() {
      state.loading = true
      state.error = ''
      if (panelEl !== undefined) renderAll(panelEl)
      try {
        const [digestRes, configRes] = await Promise.all([
          apiRequest(API.digest),
          apiRequest(API.config),
        ])
        state.digest = digestRes
        state.config = configRes.config || { sources: [], categories: [], maxItemsPerSource: 5, maxTotalItems: 30, dailyTime: '08:00' }
        state.builtins = configRes.builtins || BUILTIN_CHANNELS
        syncEntryFromConfig(state.config)
      } catch (error) {
        state.error = error.message
      } finally {
        state.loading = false
        if (panelEl !== undefined) {
          renderAll(panelEl)
          loadCatalog()
        }
      }
    }

    async function refresh() {
      state.refreshing = true
      state.refreshSlow = false
      state.error = ''
      updateHeader()
      updateError()
      // 与弹窗同一套消抖：刷新是抓订阅源，通常不止 180ms，慢下来才给提示
      clearTimeout(refreshSlowTimer)
      refreshSlowTimer = setTimeout(() => {
        refreshSlowTimer = null
        if (!state.refreshing) return
        state.refreshSlow = true
        updateSection('rss-sec-digest', renderDigestSection())
      }, LOADING_DEBOUNCE_MS)
      try {
        const data = await apiRequest(API.refresh, { method: 'POST' })
        state.digest = data
        toast(t('msg.refreshed'), 'ok')
      } catch (error) {
        state.error = error.message
        toast(error.message, 'error')
      } finally {
        state.refreshing = false
        state.refreshSlow = false
        clearTimeout(refreshSlowTimer)
        refreshSlowTimer = null
        updateHeader()
        updateError()
        // 这一版渲染是「数据落地」→ 给区块加入场动画标记
        updateSection('rss-sec-digest', renderDigestSection().replace('<div class="rss_settingSection" id="rss-sec-digest">', '<div class="rss_settingSection" id="rss-sec-digest" data-landed>'))
      }
    }

    /** refreshSlow 的定时器（与弹窗的 modalSlowTimer 同构）。 */
    let refreshSlowTimer = null


    function scheduleSave(delay) {
      clearTimeout(saveTimer)
      saveTimer = setTimeout(() => {
        saveTimer = undefined
        if (state.saving) {
          scheduleSave(200)
          return
        }
        saveConfig()
      }, delay || 500)
    }

    async function saveConfig() {
      if (!state.config) return
      clearTimeout(saveTimer)
      saveTimer = undefined
      state.saving = true
      state.error = ''
      updateHeader()
      updateError()
      try {
        const data = await apiRequest(API.config, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ config: state.config }),
        })
        state.config = data.config || state.config
        state.builtins = data.builtins || BUILTIN_CHANNELS
        state.newCategory = ''
        state.dirty = false
        syncEntryFromConfig(state.config)
        // 服务端归一化后的 AI 配置可能与输入不同（不成对被忽略、数值夹紧），重渲染该区块
        updateSection('rss-sec-ai', renderAiSection())
        if (data.warnings && data.warnings.length > 0) {
          toast(t('msg.savedWithWarnings', { warnings: data.warnings.join('; ') }), 'info')
        } else {
          toast(t('msg.saved'), 'ok')
        }
        await refresh()
        loadCatalog()
      } catch (error) {
        state.error = error.message
        toast(error.message, 'error')
      } finally {
        state.saving = false
        updateHeader()
        updateError()
      }
    }

    async function copyText(text) {
      const value = text || ''
      if (!value) {
        toast(t('msg.nothingToCopy'), 'error')
        return
      }
      try {
        await navigator.clipboard.writeText(value)
        toast(t('msg.copied'), 'ok')
      } catch {
        try {
          const textarea = document.createElement('textarea')
          textarea.value = value
          textarea.style.position = 'fixed'
          textarea.style.opacity = '0'
          document.body.appendChild(textarea)
          textarea.select()
          document.execCommand('copy')
          textarea.remove()
          toast(t('msg.copied'), 'ok')
        } catch {
          toast(t('msg.copyFailed'), 'error')
        }
      }
    }

    /* ================================ OPML / 批量导入导出 ================================ */

    function hostnameOf(url) {
      try {
        return new URL(url).hostname.replace(/^www\./, '')
      } catch {
        return url
      }
    }

    function escXml(value) {
      return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;')
    }

    function parseOpmlFallback(text) {
      const items = []
      const re = /<outline\b[^>]*>/gi
      let match
      while ((match = re.exec(text)) !== null) {
        const tag = match[0]
        const url = /xmlUrl\s*=\s*["']([^"']+)["']/i.exec(tag)?.[1]
        if (!url) continue
        const name = (/text\s*=\s*["']([^"']*)["']/i.exec(tag)?.[1] || /title\s*=\s*["']([^"']*)["']/i.exec(tag)?.[1] || '').trim()
        const category = (/category\s*=\s*["']([^"']*)["']/i.exec(tag)?.[1] || '').trim()
        if (!name) continue
        try {
          new URL(url)
        } catch {
          continue
        }
        items.push({ name, url, ...(category ? { category } : {}) })
      }
      return items
    }

    function parseOpmlText(text) {
      if (typeof DOMParser !== 'undefined') {
        try {
          const doc = new DOMParser().parseFromString(text, 'text/xml')
          const items = []
          const outlines = doc.getElementsByTagName('outline')
          for (const node of outlines) {
            const url = node.getAttribute('xmlUrl')
            if (!url) continue
            const name = (node.getAttribute('text') || node.getAttribute('title') || '').trim()
            const category = (node.getAttribute('category') || '').trim()
            if (!name) continue
            try {
              new URL(url)
            } catch {
              continue
            }
            items.push({ name, url, ...(category ? { category } : {}) })
          }
          if (items.length > 0) return items
        } catch {
          /* 解析失败则走正则兜底 */
        }
      }
      return parseOpmlFallback(text)
    }

    function parseUrlList(text) {
      const items = []
      for (const rawLine of text.split(/\r?\n/)) {
        const line = rawLine.trim()
        if (!line) continue
        let name = ''
        let url = line
        const m = /^(.*?)[,，\t ]+(https?:\/\/\S+)$/i.exec(line)
        if (m) {
          name = m[1].trim()
          url = m[2].trim()
        }
        try {
          new URL(url)
        } catch {
          continue
        }
        items.push({ name: name || hostnameOf(url), url, category: '' })
      }
      return items
    }

    function mergeSources(items) {
      const existing = new Set((state.config?.sources || []).map((source) => (source.url || '').trim().toLowerCase()))
      let added = 0
      let skipped = 0
      for (const item of items) {
        const key = (item.url || '').trim().toLowerCase()
        if (!key || existing.has(key)) {
          skipped += 1
          continue
        }
        existing.add(key)
        state.config.sources.push({
          name: item.name || hostnameOf(item.url),
          url: item.url.trim(),
          ...(item.category ? { category: item.category } : {}),
          limit: 5,
        })
        added += 1
      }
      return { added, skipped }
    }

    function importSourcesFromText(text, kind, autoSave) {
      if (!text || !text.trim()) {
        toast(t('msg.nothingToImport'), 'error')
        return
      }
      const items = kind === 'OPML' ? parseOpmlText(text) : parseUrlList(text)
      if (items.length === 0) {
        toast(t('msg.importParseFailed'), 'error')
        return
      }
      const result = mergeSources(items)
      state.importOpen = false
      state.importText = ''
      updateChannels()
      if (result.added === 0) {
        toast(t('msg.noNewSources', { count: result.skipped }), 'info')
        return
      }
      markDirty()
      if (autoSave) {
        toast(t('msg.importedSaving', { added: result.added, skipped: result.skipped > 0 ? t('msg.importSkipped', { count: result.skipped }) : '' }), 'info')
        saveConfig()
      } else {
        toast(t('msg.importedPending', { added: result.added, skipped: result.skipped > 0 ? t('msg.importSkipped', { count: result.skipped }) : '' }), 'ok')
      }
    }

    function buildOpml() {
      const lines = []
      lines.push('<?xml version="1.0" encoding="UTF-8"?>')
      lines.push('<opml version="2.0">')
      lines.push('<head><title>' + t('msg.opmlTitle') + '</title></head>')
      lines.push('<body>')
      for (const source of state.config?.sources || []) {
        const name = source.name || hostnameOf(source.url)
        const cat = source.category || ''
        lines.push('  <outline type="rss" text="' + escXml(name) + '" title="' + escXml(name) + '"' + (cat ? ' category="' + escXml(cat) + '"' : '') + ' xmlUrl="' + escXml(source.url) + '"/>')
      }
      lines.push('</body>')
      lines.push('</opml>')
      return lines.join('\n')
    }

    function exportOpml() {
      const xml = buildOpml()
      const blob = new Blob([xml], { type: 'application/xml' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'dsh-rss-subscriptions.opml'
      document.body.appendChild(a)
      a.click()
      a.remove()
      setTimeout(() => URL.revokeObjectURL(url), 1000)
      toast(t('msg.exportedCount', { count: state.config?.sources?.length || 0 }), 'ok')
    }

    /* ================================ 事件 ================================ */

    function handleClick(event) {
      const target = event.target
      const el = target && target.closest ? target.closest('[data-action]') : null
      if (!el) return
      /*
       * 作用域：只处理自己卡片 / 自己浮层里的点击。浮层（digest / catalog）挂在
       * `document.body` 上、不在 panelEl 里，所以两个根都要判。
       * 不判作用域时，别张卡片上同名 `data-action`（delete / refresh / edit…）的点击
       * 会被这里接走——2026-10-03 实测过同类：profile 的「删除」弹 prompt 的报错。
       */
      const inPanel = panelEl !== undefined && panelEl.contains(el)
      const inModal = (modalEl !== undefined && modalEl.contains(el))
        || (catalogModalEl !== undefined && catalogModalEl.contains(el))
      if (!inPanel && !inModal) return
      const action = el.dataset.action
      const index = el.dataset.index
      const value = el.dataset.value

      if (action === 'modal-close') {
        closeDigestModal()
      } else if (action === 'modal-refresh') {
        refreshDigestModal()
      } else if (action === 'modal-backdrop') {
        if (event.target === el) closeDigestModal()
      } else if (action === 'modal-copy') {
        copyText(state.digest ? state.digest.markdown : '')
      } else if (action === 'modal-cat') {
        state.modalCategory = value || ''
        renderDigestModal()
      } else if (action === 'catalog-open') {
        openCatalogModal()
      } else if (action === 'catalog-close') {
        closeCatalogModal()
      } else if (action === 'catalog-backdrop') {
        if (event.target === el) closeCatalogModal()
      } else if (action === 'digest-view') {
        openDigestModal()
      } else if (action === 'digest-refresh') {
        refresh()
      } else if (action === 'digest-copy') {
        copyText(state.digest ? state.digest.markdown : '')
      } else if (action === 'builtin-toggle') {
        if (!state.config) return
        const key = el.dataset.key
        const builtin = (state.builtins || []).find((item) => item.key === key)
        if (!builtin) return
        if (el.checked) {
          if (findBuiltinSource(builtin) === null) {
            state.config.sources.push({ name: builtin.name, url: builtin.url, category: builtin.category, builtin: builtin.key })
          }
        } else {
          const indexOf = state.config.sources.findIndex((source) => builtinOf(source)?.key === key)
          if (indexOf !== -1) state.config.sources.splice(indexOf, 1)
        }
        markDirty()
        updateChannels()
        scheduleSave()
      } else if (action === 'config-add-source') {
        if (!state.config) return
        state.config.sources.push({ name: '', url: '', category: '', limit: 5 })
        updateChannels()
        markDirty()
        const rows = panelEl !== undefined ? panelEl.querySelectorAll('#rss-sec-channels [data-field="rss-source-name"]') : []
        const lastRow = rows.length > 0 ? rows[rows.length - 1] : null
        if (lastRow !== null) {
          lastRow.focus()
          lastRow.scrollIntoView({ block: 'center', behavior: 'smooth' })
        }
      } else if (action === 'config-remove-source') {
        if (!state.config || index === undefined) return
        state.config.sources.splice(Number(index), 1)
        updateChannels()
        markDirty()
      } else if (action === 'config-add-category') {
        if (!state.config) return
        const trimmed = (state.newCategory || '').trim()
        if (!trimmed) return
        if (!state.config.categories) state.config.categories = []
        if (!state.config.categories.includes(trimmed)) state.config.categories.push(trimmed)
        state.newCategory = ''
        updateSection('rss-sec-categories', renderCategoriesSection())
        markDirty()
        scheduleSave()
      } else if (action === 'config-remove-category') {
        if (!state.config) return
        state.config.categories = (state.config.categories || []).filter((item) => item !== value)
        updateSection('rss-sec-categories', renderCategoriesSection())
        markDirty()
        scheduleSave()
      } else if (action === 'catalog-add') {
        if (!state.config || index === undefined) return
        const entry = (state.catalogEntries || [])[Number(index)]
        if (!entry) return
        if (isSubscribed(entry.url)) return
        state.config.sources.push({ name: entry.name, url: entry.url, category: entry.category, limit: 5 })
        state.catalogSelected.delete(entry.url)
        updateChannels()
        updateCatalogResults()
        markDirty()
        scheduleSave()
      } else if (action === 'catalog-toggle') {
        if (!state.config) return
        const url = el.dataset.url
        if (!url) return
        if (state.catalogSelected.has(url)) {
          state.catalogSelected.delete(url)
        } else {
          state.catalogSelected.add(url)
        }
        updateCatalogTools()
      } else if (action === 'catalog-select-all') {
        if (!state.config) return
        for (const entry of state.catalogEntries || []) {
          if (!isSubscribed(entry.url)) state.catalogSelected.add(entry.url)
        }
        const checkboxes = panelEl !== undefined ? panelEl.querySelectorAll('#rss-catalog-list input[data-action="catalog-toggle"]') : []
        for (const box of checkboxes) {
          if (box.disabled) continue
          box.checked = true
        }
        updateCatalogTools()
      } else if (action === 'catalog-clear') {
        for (const entry of state.catalogEntries || []) {
          state.catalogSelected.delete(entry.url)
        }
        const checkboxes = panelEl !== undefined ? panelEl.querySelectorAll('#rss-catalog-list input[data-action="catalog-toggle"]') : []
        for (const box of checkboxes) {
          box.checked = false
        }
        updateCatalogTools()
      } else if (action === 'catalog-add-selected') {
        if (!state.config) return
        let added = 0
        let skipped = 0
        for (const entry of state.catalogEntries || []) {
          if (!state.catalogSelected.has(entry.url)) continue
          if (isSubscribed(entry.url)) {
            skipped += 1
          } else {
            state.config.sources.push({ name: entry.name, url: entry.url, category: entry.category, limit: 5 })
            added += 1
          }
          state.catalogSelected.delete(entry.url)
        }
        if (added === 0) {
          updateCatalogTools()
          toast(skipped > 0 ? t('msg.allSubscribed') : t('msg.nothingSelected'), 'info')
          return
        }
        updateChannels()
        updateCatalogResults()
        markDirty()
        toast(t('msg.addedSaving', { added, skipped: skipped > 0 ? t('msg.addSkipped', { count: skipped }) : '' }), 'info')
        saveConfig()
      } else if (action === 'custom-import-opml') {
        const fileInput = panelEl !== undefined ? panelEl.querySelector('#rss-import-file') : null
        if (fileInput !== null) fileInput.click()
      } else if (action === 'custom-import-paste') {
        state.importOpen = !state.importOpen
        updateChannels()
        if (state.importOpen) {
          const textarea = panelEl !== undefined ? panelEl.querySelector('#rss-sec-channels [data-field="rss-import-text"]') : null
          if (textarea !== null) textarea.focus()
        }
      } else if (action === 'custom-import-paste-go') {
        importSourcesFromText(state.importText || '', 'URL', true)
      } else if (action === 'custom-export-opml') {
        exportOpml()
      } else if (action === 'catalog-add-source') {
        if (!state.config) return
        const name = (state.catalogNewName || '').trim()
        const url = (state.catalogNewUrl || '').trim()
        if (!name) {
          toast(t('error.catalogNameRequired'), 'error')
          return
        }
        if (!url) {
          toast(t('error.catalogUrlRequired'), 'error')
          return
        }
        let valid = false
        try {
          new URL(url)
          valid = true
        } catch {
          valid = false
        }
        if (!valid) {
          toast(t('error.catalogUrlInvalid'), 'error')
          return
        }
        if (!state.config.catalogs) state.config.catalogs = []
        if (state.config.catalogs.some((item) => item.url === url)) {
          toast(t('msg.catalogExists'), 'info')
          return
        }
        state.config.catalogs.push({ name, url })
        state.catalogNewName = ''
        state.catalogNewUrl = ''
        updateCatalogSources()
        markDirty()
        toast(t('msg.catalogAdded'), 'info')
        saveConfig()
      } else if (action === 'catalog-remove-source') {
        if (!state.config) return
        const url = el.dataset.url
        if (!url) return
        state.config.catalogs = (state.config.catalogs || []).filter((item) => item.url !== url)
        updateCatalogSources()
        markDirty()
        toast(t('msg.catalogRemoved'), 'info')
        saveConfig()
      } else if (action === 'config-reset') {
        if (state.dirty && !window.confirm(t('msg.confirmDiscard'))) return
        state.dirty = false
        load()
      } else if (action === 'config-save') {
        saveConfig()
      }
    }

    /* ================================ 面板宿主挂载 ================================ */

    function mountDomPanel(host) {
      if (panelEl !== undefined && panelEl.isConnected && panelEl.parentElement === host) {
        renderAll(panelEl)
        return
      }
      if (panelEl !== undefined) panelEl.remove()
      panelEl = document.createElement('div')
      panelEl.className = 'rss_panelHost'
      host.appendChild(panelEl)
      renderAll(panelEl)
    }

    /* ================================ 设置卡片（React 外壳） ================================ */

    const CHEVRON_PATH = 'M11.8486 5.5L11.4238 5.92383L8.69727 8.65137C8.44157 8.90706 8.21562 9.13382 8.01172 9.29785C7.79912 9.46883 7.55595 9.61756 7.25 9.66602C7.08435 9.69222 6.91565 9.69222 6.75 9.66602C6.44405 9.61756 6.20088 9.46883 5.98828 9.29785C5.78438 9.13382 5.55843 9.13382 5.30273 8.65137L2.57617 5.92383L2.15137 5.5L3 4.65137L3.42383 5.07617L6.15137 7.80273C6.42595 8.07732 6.59876 8.24849 6.74023 8.3623C6.87291 8.46904 6.92272 8.47813 6.9375 8.48047C6.97895 8.48703 7.02105 8.48703 7.0625 8.48047C7.07728 8.47813 7.12709 8.46904 7.25977 8.3623C7.40124 8.24849 7.57405 8.07732 7.84863 7.80273L10.5762 5.07617L11 4.65137L11.8486 5.5Z'

    function RssSettingsCard(props) {
      // DSH ≥0.1.6 的插件配置页把同一条目按 view 渲染两次：summary 一句话摘要、page 完整表单。
      // 旧版（≤0.1.5）的 settings.plugin.item 卡片不带 view，走原有可折叠卡片分支。
      const view = props && props.view
      const pageView = view === 'page'
      const [open, setOpen] = React.useState(pageView)
      const hostRef = React.useRef(null)
      React.useEffect(() => {
        if (!open) return
        const host = hostRef.current
        if (host === null) return
        mountDomPanel(host)
        load()
      }, [open])
      if (view === 'summary') {
        return t('card.desc')
      }

      // page 视图：新页面自己画标题/图标/面包屑，这里只交表单本体，不渲染卡片头。
      return jsxs(pageView ? 'div' : 'li', {
        className: pageView ? 'rss_pageHost' : (open ? 'rss_pluginCard rss_pluginCardOpen' : 'rss_pluginCard'),
        children: [
          pageView ? null : jsxs('button', {
            type: 'button',
            className: 'rss_cardHeader',
            'aria-expanded': open,
            onClick: () => setOpen((current) => !current),
            children: [
              jsxs('span', {
                className: 'rss_cardHeadText',
                children: [
                  jsx('span', { className: 'rss_cardName', children: t('card.name') }),
                  jsx('span', { className: 'rss_cardDescription', children: t('card.desc') }),
                ],
              }),
              jsx('span', { className: 'dshkit_badge', children: 'Kit' }),
              jsx('svg', {
                width: '14',
                height: '14',
                viewBox: '0 0 14 14',
                fill: 'none',
                xmlns: 'http://www.w3.org/2000/svg',
                className: 'rss_chevron',
                children: jsx('path', { d: CHEVRON_PATH, fill: 'currentColor' }),
              }),
            ],
          }),
          (pageView || open) ? jsx('div', {
            className: 'rss_cardBody',
            children: jsx('div', { ref: hostRef, className: 'rss_cardHost' }),
          }) : null,
        ],
      })
    }

    /* ================================ 插件入口 ================================ */

    exports.inject = ['slots']

    /**
     * DSH ≥0.1.6-alpha.2 的行配置 key：`<bundle 包名>#<行 id>`，行 id 取自 bundle 的
     * cordis.patch.yml。独立安装时 bundle 是本包，装全家桶时是 @hyzyn/dsh-all —— 两个都注册，
     * 未命中的那个只是躺在 ledger 里，不会渲染。
     */
    const ROW_CONFIG_KEYS = [
      '@hyzyn/dsh-rss#rss-digest',
      '@hyzyn/dsh-all#rss-digest',
    ]

    exports.apply = (ctx) => {
      installI18n(ctx)
      ctx.effect(() => {
        ensureStyle()
        // 侧栏入口先按可见挂载（与旧行为一致），config 确认禁用后由闸门收起；
        // 运行期显隐由 syncEntryFromConfig（配置加载/保存后）驱动
        let entryMounted = false
        let unmountEntry = () => {}
        entryGate = {
          set(visible) {
            if (visible === entryMounted) return
            entryMounted = visible
            if (visible) {
              unmountEntry = mountSidebarEntry()
              return
            }
            unmountEntry()
            unmountEntry = () => {}
            // 禁用瞬间的摘要弹窗一起收掉：数据路由已被宿主 403，留着只会报错
            closeDigestModal()
          },
        }
        setEntryVisible(true)
        void primeConfig()
        const onKeyDown = (event) => {
          if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 's') {
            if (panelEl !== undefined && panelEl.isConnected) {
              event.preventDefault()
              saveConfig()
            }
          }
        }
        document.addEventListener('click', handleClick, true)
        document.addEventListener('input', handleFieldEvent, true)
        document.addEventListener('change', handleFieldEvent, true)
        document.addEventListener('keydown', onKeyDown, true)
        document.addEventListener('dragstart', handleChannelDragStart, true)
        document.addEventListener('dragover', handleChannelDragOver, true)
        document.addEventListener('drop', handleChannelDrop, true)
        document.addEventListener('dragend', handleChannelDragEnd, true)
        return () => {
          document.removeEventListener('click', handleClick, true)
          document.removeEventListener('input', handleFieldEvent, true)
          document.removeEventListener('change', handleFieldEvent, true)
          document.removeEventListener('keydown', onKeyDown, true)
          document.removeEventListener('dragstart', handleChannelDragStart, true)
          document.removeEventListener('dragover', handleChannelDragOver, true)
          document.removeEventListener('drop', handleChannelDrop, true)
          document.removeEventListener('dragend', handleChannelDragEnd, true)
          entryGate = null
          entryVisible = false
          unmountEntry()
          clearTimeout(toastTimer)
          clearTimeout(saveTimer)
          styleEl?.remove()
          styleEl = undefined
          toastEl?.remove()
          toastEl = undefined
          panelEl?.remove()
          panelEl = undefined
          modalEl?.remove()
          modalEl = undefined
          catalogModalEl?.remove()
          catalogModalEl = undefined
        }
      })
      /*
       * 设置面：0.2.0-rc.1 起挂 `plugins.bundle.config`——key 是 **bundle 包名**，管理器的插件
       * 详情页把它渲染在「说明」正下方；`plugins.row.config` 是 per-row 的「>」子页。
       *
       * 两条硬约束（第一条踩过坑，见下）：
       *   ① `plugins.bundle.config` 的 key 是**共享命名空间**：同一个 key 只能有一个注册者，
       *      重复注册**直接抛错**（`keyed slot ... already has an entry`），而客户端 `apply`
       *      抛错 = 整个插件起不来（实测：把 `@hyzyn/dsh-all` 也挂上时，八个插件抢同一个 key，
       *      启动页直接变「Failed to load plugins」）（D158）。聚合包 `@hyzyn/dsh-all` 是所有插件共用的
       *      bundle，**不能**挂 bundle.config —— 它没有内联位，设置面走它自己的 row 入口。
       *   ② 内联位可用时，**本包自己的** bundle 不再注册 row 槽（同一份表单两个入口会让人以为
       *      有两套设置）；聚合包那份 row 入口**保留**（那是它在聚合安装下的唯一入口）。旧宿主
       *      （bundle 槽不存在，0.1.6 线）回退注册全部 row 槽，功能一点不减。
       * 就绪顺序不敏感：任一侧先到都收敛到「内联优先」（后到的本包 row 注册会被撤掉）。
       */
      const AGGREGATE_BUNDLE = '@hyzyn/dsh-all'
      const BUNDLE_NAMES = [...new Set(ROW_CONFIG_KEYS.map((key) => key.split('#')[0]))]
      const OWN_BUNDLE = BUNDLE_NAMES.find((name) => name !== AGGREGATE_BUNDLE)
      let bundleConfigLive = false
      const disposeOwnRowConfigs = []
      if (OWN_BUNDLE !== undefined) {
        ctx.slots.inject('plugins.bundle.config', () => {
          bundleConfigLive = true
          while (disposeOwnRowConfigs.length > 0) {
            const disposeRow = disposeOwnRowConfigs.pop()
            if (typeof disposeRow === 'function') disposeRow()
          }
          return ctx.slots.register({
            name: 'plugins.bundle.config',
            key: OWN_BUNDLE,
          }, RssSettingsCard)
        })
      }
      for (const key of ROW_CONFIG_KEYS) {
        ctx.slots.inject('plugins.row.config', () => {
          const own = key.split('#')[0] === OWN_BUNDLE
          if (own && bundleConfigLive) return undefined
          const disposeRow = ctx.slots.register({
            name: 'plugins.row.config',
            key,
          }, RssSettingsCard)
          if (own) disposeOwnRowConfigs.push(disposeRow)
          return disposeRow
        })
      }
      // DSH ≥0.1.6：设置里与「通用设置」平级的「插件配置」页（子 slot 由
      // @hyzyn/dsh-kit-settings 声明）。不传 view，卡片走各自原有的可折叠形态。
      ctx.slots.inject('settings.kit.item', () => ctx.slots.register({
        name: 'settings.kit.item',
        id: 'rss-digest',
        order: 50,
        label: () => t('card.name'),
      }, RssSettingsCard))
      // DSH ≤0.1.5：设置 → 插件 的「插件配置」标签页，keyed 插槽按 settings 命名空间派发。
      ctx.slots.inject('settings.plugin.item', () => ctx.slots.register({
        name: 'settings.plugin.item',
        // settings.plugin.item 是 keyed 插槽：key 必须是该卡片所编辑的 settings 命名空间
        key: 'rss-digest',
        order: 94,
      }, RssSettingsCard))
    }

    return exports
  },
})