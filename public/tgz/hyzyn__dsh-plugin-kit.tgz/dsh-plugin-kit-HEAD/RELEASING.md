# 发布流程

目标：让每个版本号值得点开。发布频率是给用户的信号预算——攒批发、过门槛、高危改动走 rc。
与 dsh-safe 的单包流程不同，本仓库是 monorepo：一次发布可涉及多个包，**tag 锚点是
`@hyzyn/dsh-all`**（用户视角的聚合包，沿用 v0.1.15 起的惯例，workflow 会强校验）。

## 一次性配置

发布认证有两条路，**它们同时生效、由 npm 客户端决定用哪条**：可信发布（OIDC）优先，
`NPM_TOKEN` 兜底。两条都配齐才算配完。

### 1. 可信发布（OIDC，preferred）

发布走**可信发布**：workflow 的 `id-token: write` 换一个短命令牌，npm 用它覆盖
`~/.npmrc` 里的 `_authToken`。好处是不必再长期保管一个能写全 scope 的 token，且发布自动带
provenance 证明。**前提是每个包在 npm 上都注册了这个 workflow 为 trusted publisher**——
没注册的包不会被拦，只是**静默退回 token 那条路**（所以配不齐也能发，但省不掉 token）。

**14 个可发布包逐个注册**（npm 只能按包配，没有 org 级开关；清单见
`scripts/publish-targets.mjs`）：

```sh
# 先登录（需要账号级 2FA；npm trust 明确不支持「2FA bypass」的 granular token，
# 所以必须是交互登录，不能拿 CI 那个 token 来配）
npm login

# 配置全部 14 个包并逐个回读核验（幂等，已配好的会跳过）
pnpm trusted-publishing:setup

# 只想看会做什么、不写入：
pnpm trusted-publishing:setup --dry-run
# 只处理个别包：
pnpm trusted-publishing:setup --only=packages/tty,@hyzyn/dsh-all
```

第一次会要求 2FA，网页上会提供「接下来 5 分钟免重复 2FA」的选项——勾上，14 个包可以一次跑完。
注册 `npmjs.com → Packages → <pack> → Settings → Trusted publishing` 里能看到，等同网页配置。

> **为什么用脚本而不是手抄循环**：漏配一个包**不会报错**——npm 的 OIDC 交换失败只打 verbose
> 日志并退回 `NPM_TOKEN`（`oidc()` 在任何失败分支都 `return undefined`），于是「全配好了」与
> 「漏了两个」在 CI 输出里长得一模一样。脚本最后会**逐个回读 registry** 核验，并把未就绪的包
> 点名报红。

> `--file` 只写文件名（`release.yml`），必须带 `.yml`；必须是 `.github/workflows/` 下真实存在的
> 那个文件。本仓的发布 workflow 就叫 `release.yml`。

#### CLI 配不了时的走法：**凭据不能是 2FA-bypass 的 GAT**

实测（2026-11-14，npm 11.19.1）：拿 `~/.npmrc` 里的凭据跑 `npm trust`，`whoami` 正常返回 200，
但 trust 端点回

```
403 {"message":"Please enable 2fa for your account"}
```

按 [GitHub 2026-07-31 公告](https://github.blog/changelog/2026-07-31-restricting-npm-bypass-2fa-granular-access-tokens/)，
**bypass-2FA 的 GAT 已不能修改 trusted publishing 配置**（「Changing package access, maintainers,
or trusted publishing configuration」就在被禁清单里），必须交互式 2FA 挑战。`whoami` 能过
**不代表**能改 trust——两者权限不同，脚本的前置检查因此按 403 内容单列一类。

> ⚠️ **重新 `npm login` 救不了这个 403**。实测：15:12 `npm login` 写进 `~/.npmrc` 的凭据，
> 15:12 立即跑脚本就 403。那一步本身已经完成 2FA，服务端发回来的就是「免再验」的会话凭据
> （它不在账号 `tokens` 列表里——那是 GAT 列表）。而 npm 文档写死「GAT with the bypass 2FA
> option are not supported」。
>
> ⚠️ 判定时**别只看 `npm-notice` 那行**：实测它在 **200 成功响应里也会出现**（同一凭据读
> `/-/npm/v1/tokens` 就带），是账号级全局横幅，不是「这个 token 是 bypass」的证据。真正的
> 判据是响应体的 `Please enable 2fa` 加上「该凭据不在 GAT 列表里」。

**三条出路**（按省事程度排序）：

| 路子 | 怎么做 | 代价 |
| --- | --- | --- |
| **CLI 铸一个不勾 bypass 的 GAT**（最快） | ```npm token create --name trust-setup --scopes @hyzyn --packages-and-scopes-permission read-write``` 把它输出的 `Created token npm_xxx` 替换 `~/.npmrc` 的 `_authToken`，再跑 `pnpm trusted-publishing:setup` | 要账号密码 + 一次邮箱 OTP；**别加 `--bypass-2fa`**（加了又 403）；**必须用 `--scopes` 而不是 `--packages-all`**（见下） |
| **网页配**（不依赖 token） | 每个包 `npmjs.com → Packages → <包> → Settings → Trusted publishing`：选 GitHub Actions，User `hyzyn`、Repository `dsh-plugin-kit`、Workflow `release.yml`，勾 **Allow npm publish**（要 OIDC 管 dist-tag 再勾 **Allow npm dist-tag**） | 14 个包手工点；「Allow npm dist-tag」本来就只能在网页勾（CLI 没这个开关） |
| ~~交互式登录再跑脚本~~ | ~~`npm login` 后 `pnpm trusted-publishing:setup`~~ | ❌ 实测**走不通**（见上）：登录产出的就是免验凭据，会 403 |

> 为什么 CLI 铸 token 这条路通（已实测）：同一个凭据打 `POST /-/npm/v1/tokens` 返回的是
> `400 {"message":"\"password\" is required"}` ——**不是 403**，说明它**有权限铸 token、
> 只是不能改 trust**。而铸出来的新 GAT 不勾 bypass，正好是 trust 接口要的类型。

> ⚠️ **`--packages-all` 会被 registry 拒**（实测 2026-11-14）：npm 11.19.1 只往请求体里放
> `packages_all: true`，而 registry 要的是「至少一个**显式**的 package / scope / organization」，
> 于是回 `400 You must have at least one package / scope or organization added to this token`。
> 改用 `--scopes @hyzyn`（14 个包全在这个 scope 下）即可，且将来新增 `@hyzyn/*` 包自动覆盖。

> ⚠️ **网页配完≠CI 能发**：网页是无状态的服务端配置，配完要回读核验。CLI 能跑通时用
> `pnpm trusted-publishing:setup` 回读；CLI 被 403 时只能换一个能过交互 2FA 的凭据再回读
> （`curl -s -H "Authorization: Bearer <token>" 'https://registry.npmjs.org/-/package/@hyzyn%2Fdsh-tty/trust'`）。

### 2. `NPM_TOKEN` 兜底（当前仍然必需）

GitHub 仓库 Settings → Secrets and variables → Actions 新增 `NPM_TOKEN`。token 在
npmjs.com → Access Tokens → Generate New Token（granular）生成：

- **Packages and scopes**：勾选要发布的包（或 Select all packages）；
- **Permissions**：必须 **Read and write**（只读 token 发包会被拒）；
- **2FA**：选 bypass（CI 没法输动态码）。

未配置时 Release workflow **直接失败**（`::error::` + 退出 1），不会建 GitHub Release。
早期行为是「warning + 跳过发布」，结果是 workflow 全绿、包一个都没发上 npm、却照样建出
Release 页——绿条里的假成功比红条难发现得多，所以改成硬失败。补上 secret 后重跑同一个
tag 即可（幂等）。

**为什么现在还不能删它**：`scripts/release-publish-tag.mjs` 末尾会把 `next` dist-tag 指到本仓
版本（`npm dist-tag add`），而 npm CLI 直到 **12.2.0** 才支持 dist-tag 走 OIDC（runner 上
Node 24 自带的是 11.19.1）。此刻删 token 的结果是「包都发成功了、dist-tag 那一步红、整个
release job 红」。

#### 去掉 `NPM_TOKEN` 的前置条件

两件事都做到，才可以把 secret 与 workflow 里的写入步骤一起删掉：

1. **runner 的 npm ≥ 12.2.0**：在 `actions/setup-node` 之后加一步 `npm install -g npm@^12`；
2. **每个包的 trusted publisher 上勾「Allow npm dist-tag」**：这一项 `npm trust` CLI 没有开关，
   只能逐个包在网页 `Settings → Trusted publishing` 里改（14 个包）。

做完后先发一个**带 `-rc` 的版本**验证一次（rc 走 `next` tag，出问题的爆炸半径小），绿了再删
secret。

### 本地钩子（提交前闸门）

```sh
git config core.hooksPath .githooks    # 克隆后必做一次，否则钩子不生效
```

`.githooks/` 下两个钩子：

| 钩子 | 作用 |
| --- | --- |
| `pre-commit` | ① 挡下「源码有未暂存改动、产物却要入库」的提交；② `pnpm -r build` 重建产物并 `git add`（保证入库的 `lib/`、`client.js` 与源码同步）；③ 按 index 依次扫五道：i18n（`check-i18n`）→ 公网 IP（`check-no-public-ip --staged`）→ 内部标识（`check-internal-identifiers --staged`）→ README 常量一致性（`check-readme-facts --staged`）→ 中英 README 结构（`check-readme-structure`） |
| `commit-msg` | 扫**提交信息**里的公网 IP（`--message-file`）与真实内部标识（`--message-file`） |

> 判据与每道的放行口径以 [docs/conventions.md § 提交](./docs/conventions.md#提交) 为准，本表只列动作名。

**为什么提交信息也要扫**：`filter-repo` 的 `--replace-message` 默认不开，只重写工作区内容；
提交信息是要入库的另一份内容，漏进历史只能**重写全部历史**来补救
（所有 sha 变化、全部文档引用失效、远端必须 force push）。重写的代价远高于在入口拦一次。

闸门按用途分类放行：私网 / 回环 / 链路本地 / CGN / ULA / RFC 5737 文档网段（`192.0.2.0/24`、
`198.51.100.0/24`、`203.0.113.0/24`）/ RFC 2544 基准段 / 显式占位符白名单。文档与测试夹具
**请用文档网段**，别写真实地址。

CI 另有两道兜底（`--no-verify`、别的机器、别的工具提交都能绕过钩子）：自检分类器 + 全仓扫描，
以及只查本次推送新增提交的信息。

## 发布门槛（每次 tag 前过一遍）

1. `pnpm -r build && pnpm -r typecheck && pnpm test` 全绿。本地 `pnpm publish` 没有闸，
   全靠自觉——CI 在发布前会再跑一遍兜底。
   **`pnpm test` 不包含端到端脚本**：`packages/*/scripts/integration.mjs` 这类要真宿主 /
   真 PTY / 内存 sshd 的用例是 CI 单独一步跑的（`ci.yml` 的 `dsh-tty end-to-end scripts`），
   途经 `lib/` 行为面（工具 output.schema、采集通道的 exec 次数、订阅生命周期）的改动必须
   补跑对应包的那一条，否则只能等 CI 红（v0.37.0 → v0.37.1 就是这么出的 hotfix 链：
   `tty_stats` 漏声明 `swapUsed` / `swapTotal`、Ping 探针在订阅前就开始 exec，全部躲过了
   `pnpm test`）：

   ```bash
   pnpm --filter @hyzyn/dsh-tty run integration     # tty：真宿主 / PTY / 内存 sshd
   ```

   **bump 完版本号先同步 lockfile**，且顺序必须是：**bump → `pnpm aggregate`（聚合层
   钉新版本）→ `pnpm install --lockfile-only`**。workspace 内部依赖是按版本号写进
   lockfile 的（`specifier:` 那一行），只改 package.json 不改 lockfile，CI 第一步
   `pnpm install --frozen-lockfile` 就会红——v0.1.22 就是两次卡在这里（两次都只
   同步了 package.json，白等两轮 CI）；顺序颠倒同样会红：aggregate 晚于 install，
   聚合层重钉的 specifier 没进 lockfile（v0.1.24，第一轮 Release 就折在这）。一条
   命令过完前三项：

   ```bash
   pnpm aggregate && pnpm install --lockfile-only \
     && pnpm -r build && pnpm -r typecheck && pnpm test
   git diff pnpm-lock.yaml   # 自查：应能看到本轮 specifier 变化；没有 = 没同步上
   ```
2. `pnpm aggregate` 无 diff。聚合层（根 `cordis.patch.yml`、`packages/all`）必须钉住
   本次要发的插件版本；CI 与 Release workflow 都强制检查，过期直接红。
   同一步顺带跑 `pnpm package-contents:check`：它真的打一次包，断言 `main` / `exports` /
   `dsh.bundle.patch` / `client.js` 这些**声明的入口都在 tarball 里**。`files` 是手工清单，
   漏一项**发出去就只能靠新版本补救**——而挂载车道走 `link:`、绕过 `files` 字段，看不见它
   （2026-10-03 实测：删掉 tty 的 `client.js` 后十三道闸门 + 1700 条用例仍全绿）。
   理由与守卫形态见
   [docs/conventions.md § 发包内容守卫](docs/conventions.md#发包内容守卫files-字段漏一项不许静默)。
3. 动了插件运行行为的改动，真实装进 DSH 跑一遍：`dsh plugin --profile <name> add
   @hyzyn/dsh-<pkg>`（或 link: 路径调试）。build 绿不等于装上没问题。
   tty 的 integration/live/ssh-smoke、codegraph 的 5 个 `verify-codegraph-*-smoke`、mcp 的
   http-smoke/tools-smoke、rss 的 opml-smoke（以及根 `scripts/verify-*.mjs` 全部 9 条）都需要真机，
   按需本地跑——它们**也都不在 CI 里**（真机脚本进不了 CI，见
   [docs/conventions.md § 真机脚本与 CI 接线](docs/conventions.md#真机脚本与-ci-接线)）；
   清单与可粘贴命令见 `pnpm verify:list`。
   **能力开关 / 权限 / 文案类改动跑一次 `pnpm live-smoke`**：它从你已有的「link 到本仓」的
   profile 复制两份一次性 profile，起两个真宿主（无授权 / 带授权各一），把授权阶梯、路由门控、
   agent 工具清单、试连文案、宿主正在服务的 `client.js` 全打一遍，跑完删干净——就是本节
   「真实装进 DSH 跑一遍」的自动化形态（未装 DSH 时打印 SKIP，加 `--strict` 可让它变成失败）。
   两个实例的**授权目录也用一次性 profile 里的 `.kit-home` 隔离**（`DSH_KIT_HOME`，kit D12）：
   带外授权是持久的，不隔离的话「无授权」那一半会在你用过提权卡片的机器上继承授权、九条断言
   全变成假红。**机器上没有 link profile（干净 VM / 新克隆）时加 `--bootstrap`**：它会从 dsh
   自带的 `web` 模板现场造一个（link 本仓的 docker/tty、自证插件真进了阵容），跑完连它一起删。
   **加 `--render` 还会用无头浏览器打开界面**，断言本仓插件的 `client.js` 真的被加载、无未捕获
   异常——这是唯一能看见「构建绿 / 单测绿 / 用户白屏」那类失败的验收（受限环境要配
   `--chrome-arg --no-sandbox`）。
   **2026-10-03 起它也在 CI 与发布流水里跑**（`ci.yml` 的 `mount-smoke` job + `release.yml`
   对应 step，形态 `--bootstrap --strict --render --chrome-arg --no-sandbox`）——本地手工跑仍是
   主要用法，但发布路径不再只依赖「你记得跑」。决策记录见
   [docs/conventions.md § 挂载车道](docs/conventions.md#真机脚本与-ci-接线)。
   **tag 前建议看一眼 nightly**（`gh run list --workflow=nightly.yml --limit 3`）：它每天跑并发
   flake 与 coverage 棘轮。两条都不挡发版，但**带着一条已知红状态发版是错的信号**——
   尤其 flake 那条：本仓已经有三次「发了版才发现用例在赌墙钟」。两条车道的分工与为什么不进
   CI 见 [docs/conventions.md § 车道分工](docs/conventions.md#车道分工哪条车道管什么)。
4. 各包依赖**不要写 `workspace:*`**。它只在 monorepo 内部有效：`pnpm publish` 会把它
   换成真实版本（所以 npm 产物看起来是对的），但用户从 git 子路径安装
   （`git+https://github.com/hyzyn/dsh-plugin-kit.git#main&path:packages/tty`）时协议
   原样保留，pnpm 报 `ERR_PNPM_WORKSPACE_PKG_NOT_FOUND` 装不上——而报错指不到本仓库，
   只能靠用户来提 issue。写真实版本（如 `^0.1.2`）即可；本地开发靠根 `.npmrc` 的
   `link-workspace-packages=true` 仍然链接到 `packages/*`，体验不变。
   CI 与 Release workflow 都会跑 `node scripts/check-publishable.mjs` 兜底。
   **例外是 `@hyzyn/dsh-kit`：它必须是精确版本，且全仓一致、等于 `packages/kit` 自己的
   版本。** kit 的跨插件一致性（授权存储、能力绑定，`kit D11`）靠**模块级单例**，
   而 pnpm 的 hoisted 布局只能把一个版本提升到顶层、另一个嵌进消费者自己的
   `node_modules`——两份 kit 就是两套单例，`kit D11` 的症状会回来。所以 bump kit 时必须
   跟齐**每一个**消费者，一次发完；`node scripts/check-kit-pins.mjs` 兜底（CI 与 Release
   workflow 都跑）。
   **新包的钉子不用手抄**：`pnpm create-plugin` 生成时从 `packages/kit/package.json#version`
   **现算**（[scripts/create-plugin-manifest.mjs](scripts/create-plugin-manifest.mjs)），
   模板 [templates/hello/package.json](templates/hello/package.json) 里的字面值只是给人看的
   参考、**不是真相源**。模板仍要在同一轮跟着 bump（见下面「攒批」那一步），但**漏改不会再让新包
   带着旧钉子上路**——而那条漂移此前是无人会红的：`templates/` 不在 `collectKitPins()` 的扫描面，
   模板也不在 `pnpm-workspace.yaml` / `pnpm-lock.yaml` 里。

   **这条规矩的另一半同样成立：`packages/kit` 的 `src` / `lib` 只要有改动，就必须 bump kit
   ——即使没有任何消费者需要改代码。** 理由见下面第 6 条：npm 上一个版本号只能对应一份内容，
   而发布流按版本号跳过；kit 内容变了却没 bump，消费者钉到的就还是旧内容。
5. 可安装插件必须用 `peerDependencies` 声明 DSH 兼容范围。DSH 0.1.7-rc.1 起
   **安装前与启动时**都强制校验，且只看 `@deepseek-ai/dsh` / `@deepseek-ai/dsh-*`
   的 peer（预发布参与范围匹配）。写法统一为**逐 cohort 写全**：
   `"@deepseek-ai/dsh": "^<cohort-1> || … || ^<cohort-N>"`（当前十六档是
   `^0.1.7-rc.2 || ^0.2.0-rc.1 || ^0.2.0-rc.2 || ^0.2.1-alpha.1 || ^0.2.1-alpha.2 || ^0.2.1-alpha.5 || ^0.2.1-rc.1 || ^0.2.1-rc.2 || ^0.2.1-rc.3 || ^0.2.1-rc.4 || ^0.2.1-rc.5 || ^0.2.2-alpha.3 || ^0.2.2-rc.1 || ^0.2.2-rc.2 || ^0.2.2-rc.3 || ^0.2.2-rc.4`；单 cohort 时就是 `^<cohort>`），
   并在 `peerDependenciesMeta` 里标 `optional`——只压 pnpm 的 unmet-peer 噪音，
   DSH 判定器不看它，照旧强制。
   被判定不兼容的插件安装时抛 `incompatible-version`、启动时整行 `disabled`
   （bundle 则整包被 skip）；豁免要写进 profile 自己的 `compatibility.json`
   （`dsh plugin allow-version`）。
   同时保留 `dsh.engines.dsh: ">=<最低档 cohort>"`（市场解析器唯一支持的 `>=X.Y.Z[-预发布]`
   形式，写 `||` 会被判「无法验证」）作为**展示**位：rc.1 宿主不读它，但插件市场 /
   社区条目仍按它展示兼容性——它必须与 peer 覆盖的最低档一致，脚本会拦。
   cohort 增删时同步改**全部**包与 `scripts/check-dsh-peers.mjs` 里的 `DSH_COHORTS`
   （列表，旧 → 新；新插件从 `templates/hello` 复制，模板也要跟着改）。**每加一档都必须
   实测过**：用该 cohort 的 `app-boot` 判定器逐包核对，并至少跑一遍真宿主加载
   （`dsh plugin add` 不需要豁免 + 启动后无 `skipping profile bundle`），
   写进对应 README 的兼容性段。注意加档分两种：**修边界**（老段本来就判死它，例如
   `0.2.0-rc.1` 落在 `>=0.1.7-rc.2 <0.2.0-0` 之外）和**显式化**（老段其实已覆盖它，
   例如 `0.2.0-rc.2` 落在 `^0.2.0-rc.1` 内、`0.2.1-alpha.1` 与 `0.2.1-alpha.2` 落在 `^0.2.0-rc.2` 内、
   `0.2.1-rc.1` 落在 `^0.2.1-alpha.5` 内、`0.2.2-rc.2` 落在 `^0.2.2-rc.1` 内、`0.2.2-rc.3` 落在 `^0.2.2-rc.2` 内、`0.2.2-rc.4` 落在 `^0.2.2-rc.3` 内）——后者通常在
   **宿主行为上零差异**，但同样要走完
   实测，否则那一段就是一句没有证据的声明。⚠️ **「零差异」不是显式化的定义、只是常态**：
   `0.2.1-alpha.5` 也落在 `^0.2.1-alpha.2` 内（显式化），可它那一档**真的改了宿主行为**——
   判定器字段名 `peers` → `requirements`、顶层 `engines.dsh` 开始短路 peer、凭据层级翻面、
   macOS picker 换 JXA。加这种档不能照抄前几档的「只改声明」说法：要么按修边界的力度逐条比对
   API 面与本仓引用，要么别加（逐条见 `scripts/check-dsh-peers.mjs` 头部的 cohort 说明）。
   退役 cohort 前先确认没有宿主还在服役。
   CI 与 Release workflow 都会跑
   `node scripts/check-dsh-peers.mjs` 兜底；本机装了对应 cohort 时可用
   `--app-boot <path>` 让 DSH 自己的判定器对**每一档**再核一遍。
6. **已发布版本的内容必须与本仓一致**。`pnpm release:preflight`（`release:publish` 在真正
   publish 之前会自动跑一遍，所有包都还没发）对每个**已在 registry** 的「包名@版本」下载
   tarball，把 `lib/**`（不含 `.map`）/ `client.js` / `cordis.patch.yml` 与本仓逐字节比对；
   不一致立即中止，并点名包、版本与文件。判据与实现见
   [`scripts/lib/published-content.mjs`](scripts/lib/published-content.mjs) 头注释。
   这一条补的是发布流的**版本级跳过**：跳过只看「版本在不在」，而 npm 上一个版本号只能对应
   一份内容——**内容变了就必须 bump**，否则消费者钉到的还是旧内容。

   **2026-10-17 的现场（外部 issue #12）**：CG67 修复往 `@hyzyn/dsh-kit` 加了
   `stripEmptyFlowSequenceRoot` / `…RootLines` 两个导出并让 codegraph / mcp / env / prompt
   直接消费，但 kit 的版本仍停在 0.5.2（10-07 发的那份），`lib/` 却已重建入库。发版提交只
   bump 了消费者，发布流对 kit@0.5.2 打印「已在 registry，跳过」，四个消费者带着新 import
   发了出去。用户装到 codegraph 0.6.9 + kit 0.5.2 就是
   `The requested module '@hyzyn/dsh-kit' does not provide an export named
   'stripEmptyFlowSequenceRootLines'`，整条 entry 不激活。**当时十几道闸门全绿**：
   kit 钉子闸只比版本号是否一致（本地 kit 的版本就是 0.5.2，自洽）、开发与测试走 workspace
   link 永远解析到本地新 kit、`artifacts:check` 只比「入库产物 vs 重新构建」、
   `package-contents:check` 只比「声明的入口在不在 tarball 里」。没有一道闸门问过
   「npm 上这个版本里的代码，和本仓这份代码是不是同一份」。

   **推论（写进日常）**：只要动了 `packages/kit` 的 `src` / `lib`，就顺手 bump kit 版本；
   发 tag 前先跑 `pnpm release:preflight`，红了先 bump 再打 tag。

## 攒批

- 多个 fix 攒一个版本发；feature 单独发。目标一天 ≤ 1–2 个版本。
- 版本号语义（各包独立）：**patch** = 不改行为的修复；**minor** = 新能力或行为变化。
  用户靠这个决定要不要更。发版时受影响的包各自 bump；只要有插件变化，
  `@hyzyn/dsh-all` 和根 `@hyzyn/dsh-plugin-kit` 也要 bump。
- 出 hotfix 链（x.y.1 → x.y.2 → x.y.3）通常说明上一版发布前没过门槛——回看是哪步省了，
  而不是接着发下一版。

## 正式发布

```bash
git switch main && git pull
# 1. bump 受影响包的 package.json 版本号
# 2. pnpm aggregate                  # 重新生成聚合层（钉新版本）
# 3. pnpm install --lockfile-only    # 必须在 aggregate 之后：聚合层重钉要进 lockfile
# 4. 提交全部改动并推送 main（CI 先绿）
# 5. pnpm release:preflight          # 已发布版本的内容必须与本仓一致；红了先 bump，别打 tag
git tag "v$(node -p "require('./packages/all/package.json').version")"
git push origin main --tags
```

tag 推上去后 Release workflow 接管：校验 tag 与 `@hyzyn/dsh-all` 版本一致 →
build + typecheck + 聚合检查 → 按依赖序发布全部包（**先对 registry 上已存在的「包名@版本」做
内容预检，内容与本仓不一致即整体中止；一致的跳过，未 bump 的包不拦路**）→ 逐包回查 registry
核实 → **把全部包的 `next` dist-tag 逐包同步到本仓版本再核实**（稳定版只更新 `latest`，
不补这一步 `next` 会一直停在很久以前的 rc 上，见 § 高危改动走 prerelease）→ 建 GitHub Release
（Highlights 自动过滤 chore 提交，并附全部 workspace 包的版本清单）。

发布中途失败：修复后删除并重打同一个 tag 再推即可，已发出的包重跑时自动跳过（幂等）。
兜底的手动发布：`node scripts/release-publish-all.mjs [6位OTP] [only=]包目录,...`
（bypass-2FA token 不需要 OTP；经典 token 传 6 位动态码）。

## 排错（CI 发布出错时对照）

| 症状 | 原因与处理 |
| --- | --- |
| 用户报 `The requested module '@hyzyn/dsh-kit' does not provide an export named …`（或整条 entry 报 `failed to import`） | **kit 的内容变了但版本号没 bump**：发布流按「版本已在 registry」跳过，消费者钉到的还是旧 kit 内容（2026-10-17 事故，外部 issue #12：codegraph 0.6.9 / env 0.3.9 / mcp 0.3.5 / prompt 0.2.8 四个包中招）。修法：bump kit → 全仓消费者钉子跟齐 → `pnpm aggregate` → 发新版；旧包只能靠回滚（codegraph 0.6.8 / env 0.3.8 / mcp 0.3.4 / prompt 0.2.7）。`pnpm release:preflight` 现在会在发布前拦下这一类（发布门槛第 6 条） |
| workflow 绿了、但日志里有 `::warning::` 说「窗口内未核实 / 无法判定」 | publish 命令已退出 0（真失败会在发布那一步直接红），只是回查没在窗口内读到目标版本。**先别删 tag 重打**：`curl -s https://registry.npmjs.org/<包名>/<版本>` 直查，在就无需处理；确实不在才重跑（幂等）。回查用单版本小端点 + 随机 `?cb=`（详见 `scripts/release-publish-tag.mjs` 顶部注释），只有当权威文档**已刷新到本次发布之后**却仍没有该版本时才判红 |
| 用户装 `@next` 拿到的是半年前的 rc，或 `npm view <包名> dist-tags` 里连 `next` 都没有 | **`next` 漂了**：稳定版只更新 `latest`，预发布才写 `next`，中间没人补就一直是老值（2026-11-05 实测 `dsh-tty` 停在 `0.22.0-rc.2`、`dsh-loglens` 干脆没有这个 tag，最少落后 15 个版本，而**没有任何东西会红**）。发布脚本收尾现在会逐包 `dist-tag add` 再核实（判据见 `scripts/lib/dist-tags.mjs`，单测 `scripts/test/dist-tags.test.ts`）；手工补：`npm dist-tag add <包名>@<版本> next --registry https://registry.npmjs.org` |
| `ERR_PNPM_OUTDATED_LOCKFILE ... specifiers in the lockfile don't match` | lockfile 与 package.json 脱节：aggregate 晚于 `install --lockfile-only`，聚合层重钉的 specifier 没进 lockfile（v0.1.24）。按「bump → aggregate → install --lockfile-only」顺序重跑；已发包的修复直接追加 lockfile 提交、删 tag 重打（幂等） |
| `403 ... Two-factor authentication or granular access token with bypass 2fa` | 缺动态码或 token 不是 bypass-2FA：换 bypass granular token |
| `404 Not found - PUT <包名>` / `404 ... install from a tarball` | token 对该包无发布权（npm 故意 404 隐藏存在性）：检查 granular token 的 Packages and scopes 是否勾到该包、权限是否 Read and write |
| 用户报 `ERR_PNPM_WORKSPACE_PKG_NOT_FOUND ... "@hyzyn/dsh-kit@workspace:*"` | 某包依赖残留 `workspace:*`：从 git 子路径安装必炸（npm 安装正常，因为 publish 期已转换）。改真实版本 + bump 受影响包重发；本地先跑 `node scripts/check-publishable.mjs` 确认 |
| `check-kit-pins` 报「全仓出现 N 个不同的 kit 钉子」或「全仓钉子 X ≠ packages/kit 的版本 Y」 | 本轮的 bump 只跟了部分消费者。把点名的包改成本轮 kit 的精确版本、**同一轮一起发**（顺序照门槛 1：bump → `pnpm aggregate` → `pnpm install --lockfile-only`）。为什么不能只发一半：hoisted 布局下两份 kit 会让 `kit D11` 的模块级单例失效 |
| 手动兜底发布时 `pnpm publish` 说 `This command requires you to be logged in to https://registry.npmmirror.com/`，或包发完在 npmjs 上查不到 | **本机 registry 指向了镜像**（`npm config get registry`，2026-10-06 实测本机为 `registry.npmmirror.com`）：手动流会把包往镜像发、真 registry 上自然没有。**CI 路径不受影响**——runner 上是干净的 npmjs 配置，脚本又显式把 token 写进 `~/.npmrc`、回查直接打 `registry.npmjs.org`。本地手动发布前改用 `pnpm publish --registry https://registry.npmjs.org`（或临时 `npm config set registry`），发完确认改回 |

校验 token 身份（不泄露值）：

```sh
curl -s -H "Authorization: Bearer $TOKEN" https://registry.npmjs.org/-/whoami
# → {"username":"hyzyn"} 即为正确账号
```

## 高危改动走 prerelease

版本号带 `-` 的包（如 `0.16.0-rc.1`）workflow 自动以 `--tag next` 发布，
GitHub Release 标记为 prerelease：

- `next` dist-tag 不进用户的每日版本检查（检查只读 npm `latest`），正式用户无感。
- 自测：`dsh plugin --profile <name> add @hyzyn/dsh-tty@next`，真实环境跑一天；
  稳定后去掉 `-rc.n` 发 latest。
- **稳定版发完要把 `next` 也指过去**。稳定版只更新 `latest`，而 `next` 只在上一次预发布时被写过
  ——不补这一步它会一直停在很久以前的 rc 上（2026-11-05 实测：`dsh-tty` 指着 `0.22.0-rc.2`、
  `dsh-kit` 指着 `0.5.0-rc.1`、`dsh-loglens` 干脆没有这个 tag）。发布脚本的收尾现在会**逐包
  同步再核实**（判据 `scripts/lib/dist-tags.mjs` 是纯函数，由 `scripts/test/dist-tags.test.ts`
  钉住；不一致会让 workflow 红并打印逐条修法），手工补一条就是
  `npm dist-tag add <包名>@<版本> next --registry https://registry.npmjs.org`。
  **判据是「相等」不是「不落后」**：`next` 指向一个未来版本同样是错的（有人在仓库外发过包，
  或上次发布只回滚了一半），而那类错用 semver 比较会静默通过。
