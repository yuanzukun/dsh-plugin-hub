<div align="center">

<img src="icon.svg" width="88" alt="">

# dsh-language-bridge

**各モデルに作業言語を指定** — あなたは自分の言語で入力し、モデルは作業言語で回答し、DeepSeek Flash がその間を翻訳します。

<img src="https://img.shields.io/badge/DeepSeek_Harness-コミュニティプラグイン-4d6bfe?style=flat-square" alt="DeepSeek Harness コミュニティプラグイン">
<img src="https://img.shields.io/badge/翻訳-DeepSeek_Flash-4d6bfe?style=flat-square" alt="翻訳：DeepSeek Flash">
<img src="https://img.shields.io/badge/UI-8_言語-555?style=flat-square" alt="UI 8 言語対応">

[中文](README.md) · [English](README.en.md) · **日本語** · [Español](README.es.md) · [Français](README.fr.md) · [Deutsch](README.de.md) · [Русский](README.ru.md) · [Português](README.pt.md)

[機能](#機能) · [インストール](#インストール) · [設定](#設定) · [仕組み](#仕組み) · [言語検出](#言語検出) · [既知の制限](#既知の制限)

</div>

<br>

[DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) のコミュニティプラグインです。あなたは自分の言語で入力し、DeepSeek Flash がそれをモデルの作業言語に翻訳してから送信します。モデルの回答は再びあなたの言語に翻訳され、元の位置に表示されます。どの言語、どのモデルでも設定できます——例：あなたはスペイン語を使い、Claude と Gemini は英語、ある中国語モデルは `zh-CN` に設定する、といった構成です。

<p align="center">
  <img src="docs/demo.gif" width="932" alt="中国語で Claude に質問：モデルは英語を受け取り英語で回答し、画面には中国語訳が表示される。「原文を表示」「送信内容を表示」で切り替えられる">
</p>

<p align="center"><sub>あなたの言語は <code>auto</code>（中国語の UI に従う）、Claude の作業言語は英語です。回答が終わると自動的に中国語に置き換わります。「原文を表示」（查看原文）はモデルの英語の回答を、「送信内容を表示」（查看发送内容）は実際にモデルへ送られた英文を表示します。このデモは中国語インターフェースで録画したものです。</sub></p>

## 機能

- 🧭 **モデル → 言語ルール** — 順序付きリストで、モデル id を正規表現で照合します（大文字小文字は区別しません）。最初に一致したルールが適用され、一致しないモデルはそのままです。
- 🌐 **あなたの言語** — 任意の BCP 47 コード（`es`、`ja`、`zh-CN`…）、または `auto` で UI の言語に従います。
- ➡️ **入力の翻訳** — 送信前に、あなたが書いた文章を作業言語に翻訳します。コードブロック、インラインコード、リンク、`@パス` はそのまま保持されます。
- ⬅️ **回答の翻訳** — 各ターンの終了後に回答を訳文に置き換えて表示し、「原文を表示 / 翻訳を表示」で元の位置のまま切り替えられます。思考内容は翻訳しません。
- 📌 **作業言語の維持** — ブリッジ対象のモデルのシステムプロンプトにルールを 1 つ追加し、他の言語のツール出力を受け取っても作業言語で思考・回答するよう求めます。
- ⚠️ **失敗を可視化** — 翻訳に失敗した場合も原文をそのまま送信してそのターンを失わず、メッセージの下に警告を表示します。
- 🆓 **同一言語ならコストゼロ** — あなたの言語とモデルの作業言語が同じ（`en-GB` と `en` など）場合は、翻訳もシステムプロンプトの追加も行わず、費用は発生しません。

<p align="center">
  <img src="docs/translation-failed.png" width="740" alt="翻訳に失敗すると、メッセージの下に「⚠ 翻訳に失敗しました。モデルには原文が送信されました」と表示される">
  <br>
  <sub>翻訳に失敗した場合も原文はそのまま送信され、メッセージの下に警告が表示されます。</sub>
</p>

## インストール

**動作要件**：DeepSeek Harness（macOS 版 0.2.1-rc.5 で動作確認済み）と、そこに設定した DeepSeek API キーまたはログイン済みの DeepSeek アカウント。翻訳は DeepSeek Flash が行います。

**いちばん簡単な方法**：次の文を DSH の任意のチャットに貼り付けると、エージェントがインストールします：

```text
Install the DeepSeek Harness plugin https://github.com/tonyzdev/dsh-language-bridge into my current profile. If you have the plugin_manager tool, call install_bundle to install and enable it. Otherwise read the profile name ($DSH_PROFILE in bash, $env:DSH_PROFILE in PowerShell) and run `dsh plugin --profile <profile> add github:tonyzdev/dsh-language-bridge`, using the bundled CLI next to app.asar (runtime/cli/bin/dsh, or dsh.cmd on Windows) when the profile is desktop; ask for sandbox approval if needed. Do not edit profile files by hand.
```

Harness の「プラグイン」ページで **Add plugin** をクリックし、次のアドレスを入力します。インストールが完了したら **Enable now** をクリックします。プラグインのボタンが表示されない場合は、ページを再読み込みするか DeepSeek Harness を再起動してください。

```
https://github.com/tonyzdev/dsh-language-bridge
```

<details>
<summary><b>コマンドラインでのインストールと削除</b></summary>

<br>

まず DeepSeek Harness を完全に終了してから、次を実行します（これは macOS での `dsh` のパスです）：

```sh
DSH="/Applications/DeepSeek Harness.app/Contents/Resources/runtime/cli/bin/dsh"
"$DSH" plugin --profile desktop add github:tonyzdev/dsh-language-bridge
```

コードに手を加える場合は、クローンしてリンクとしてインストールします。編集内容はそのコピーに直接反映されます：

```sh
git clone https://github.com/tonyzdev/dsh-language-bridge ~/.dsh/local-plugins/dsh-language-bridge
"$DSH" plugin --profile desktop add link:$HOME/.dsh/local-plugins/dsh-language-bridge
```

削除するには、「プラグイン」ページでアンインストールするか、Harness を終了してから次を実行します：

```sh
"$DSH" plugin --profile desktop remove dsh-language-bridge
```

</details>

## 設定

「プラグイン → Language Bridge」を開きます。保存すると次のステップから有効になり、再起動は不要です。

<p align="center">
  <img src="docs/settings.gif" width="833" alt="ルール qwen → zh-CN を追加：無効な正規表現は即座にエラー表示され、Test a model id でどのルールに一致するかを確認し、Save で反映される">
</p>

| 項目 | 説明 |
| --- | --- |
| **Your language** | `auto` を指定すると、ブラウザが UI の言語を Host に報告して保存します。UI 言語 `zh` は `zh-CN` として扱われます。 |
| **Model rules** | 追加・削除、上下への移動ができます。正規表現と言語コードはフォーム内で即時に検証され、エラーがある間は保存できません。 |
| **Test a model id** | モデル id を入力すると、どのルールに一致するか、翻訳が必要かどうかを確認できます。 |

**デフォルトルール**

| モデル id の正規表現 | 作業言語 |
| --- | :---: |
| `claude` | `en` |
| `gemini` | `en` |
| `(^\|[^a-z0-9])(chat)?gpt($\|[^a-z])` | `en` |

GPT のルールには境界が付いており、`gpt-5`、`openai/gpt-4o`、`chatgpt-4o`、`gpt-oss` に一致し、`egpt-1` や `mygpt` のような id には誤って一致しません。

> [!TIP]
> 設定は `$DSH_HOME/storages/language-bridge.json`（`DSH_HOME` のデフォルトは `~/.dsh`）に保存され、`cordis.patch.yml` より優先されます。`cordis.patch.yml` で `rules`、`userLanguage` により初期値を設定し、`provider`（`auto` / `deepseek-official` / `deepseek-account`）、`translateInput`、`translateOutput` で動作を調整することもできます。

## 仕組み

```mermaid
flowchart LR
    A([あなたの入力]) -- 言語検出 --> B[DeepSeek Flash<br/>翻訳]
    B --> C[["モデル<br/>作業言語 + システムプロンプトのルール"]]
    C -- 言語検出 --> D[DeepSeek Flash<br/>翻訳]
    D --> E([表示される回答])
    classDef tr fill:#4d6bfe,stroke:#4d6bfe,color:#fff
    classDef model fill:#1f2335,stroke:#4d6bfe,color:#fff
    class B,D tr
    class C model
```

<p align="center"><sub>言語検出でテキストがすでにターゲット言語だと判定された場合は、翻訳をスキップしてそのまま送信または表示します。</sub></p>

| ファイル | 場所 | 役割 |
| --- | :---: | --- |
| `index.js` | Host | `agent/pre-step` で入力を翻訳；システムプロンプトの段落；`/api/language-bridge/*` API（回答の翻訳、設定の読み書き、UI 言語の報告。owner のみ） |
| `rules.js` | 共通 | ルールの照合、言語コードの検証、設定のマージ、システムプロンプトの文面（純粋関数） |
| `detect.js` | 共通 | テキストにまだ翻訳が必要かどうかの判定（純粋関数） |
| `protect.js` | 共通 | プレースホルダーでコードとリンクを保護し、分割して翻訳 |
| `client.js` | ブラウザ | 回答の元の位置での置き換えと切り替え、ユーザーメッセージの「送信内容を表示 / 原文を表示」と失敗警告、設定ページ |
| `cordis.patch.yml` | パッチ | translator サービスの行と本プラグインの行を挿入 |

<details>
<summary><b>実装の詳細</b></summary>

<br>

- 翻訳には dsh 同梱の `@deepseek-ai/dsh-experimental-translator` を使い、`deepseek-official`（API キー）を優先し、次に `deepseek-account` を使います。有料の結果はセッション内に保存され、再度開いても課金されません。
- 原文はメッセージの `source.languageBridge` に保存され、モデルからは見えず、UI 表示にのみ使われます。
- 翻訳するのはあなたが書いたメッセージだけです。システムが注入するコンテキストやサブエージェントのメッセージは翻訳しません。
- 翻訳モデルがプレースホルダーを落とした場合は、プレースホルダーの間のテキストだけを翻訳する方式に切り替え、コードとリンクが失われないようにします。
- 設定ページはプラグイン詳細ページの `plugins.bundle.config` スロットを使っており、Harness 組み込みの設定フォームは使っていません。後者は `schemastery` を必要としますが、`link:` でインストールしたローカルプラグインからはこのパッケージを解決できないためです。

</details>

## 言語検出

`needsTranslation(text, { target, source })` は、テキストをまだ `target` に翻訳する必要があるかを判定します。順に次を確認します：

1. **本文以外を除去** — 保護された断片と、コードのように見える語（`parseConfig`、`foo_bar`、`src/app.ts`、`v2`、`--flag`、略語）を取り除きます。文字が残らなければ翻訳しません。
2. **文字体系の比較** — `Intl.Locale` でターゲット言語の文字体系を推定するため、言語テーブルは不要です。他の非ラテン文字の割合が十分に高ければ翻訳します。ターゲットがラテン文字でない場合、ラテン文字が 60% 以上を占めて初めて外国語とみなします。中国語・日本語・韓国語・ロシア語の文中に英語の名詞が混じるのはよくあるためです。
3. **機能語の比較** — 同じ文字体系内の言語（スペイン語と英語など）は、内蔵の 17 言語分の機能語テーブルで区別します。他の言語が明らかに優勢なら翻訳し、ターゲット言語が明らかに優勢なら翻訳しません。
4. **それでも判定できない場合** — あなたの言語とターゲットの文字体系が異なるときだけ翻訳しません（日本語ユーザーが `run tests` と入力した場合）。それ以外はすべて翻訳します。

> [!IMPORTANT]
> 方針は**翻訳漏れより翻訳しすぎを選ぶ**ことです。余分に 1 回翻訳しても DeepSeek Flash のわずかな費用で済み、訳文が原文と同じなら置き換えも切り替えボタンの表示も行いません。一方、翻訳漏れはモデルが誤った言語のテキストを受け取るうえ、誰も気づきません。

その代償：

- スペイン語ユーザーが `run tests` のような機能語のない短文を入力すると、呼び出しが 1 回増えます。
- 機能語テーブルのない同一文字体系の言語ペア（インドネシア語ユーザーとスワヒリ語モデルなど）では、段落ごとに 1 回呼び出します。
- 漢字のみの場合は中国語と日本語、また簡体字と繁体字を区別できないため、翻訳が必要なものとして扱います。

## claude-zh-bridge からの移行

本プラグインは、中国語専用だった前身の `claude-zh-bridge` に代わるものです。使ったことがなければ、このセクションは読み飛ばしてください。

> [!WARNING]
> 2 つのプラグインを同時に有効にしないでください。すべてが二重に翻訳されてしまいます。先に「プラグイン」ページで旧プラグインをアンインストールするか、コマンドラインで次を実行してください：
>
> ```sh
> DSH="/Applications/DeepSeek Harness.app/Contents/Resources/runtime/cli/bin/dsh"
> "$DSH" plugin --profile desktop remove @local/claude-zh-bridge
> ```

旧セッションには影響しません：旧プラグインが `source.claudeZhBridge` に保存した原文はそのまま表示されます。翻訳キャッシュのキーはテキスト断片、言語、ルートを含み、本プラグインは同じプレースホルダーと分割方式を維持している（ユニットテストで保証）ため、あなたの言語が `zh-CN` に解決される場合、旧セッションで支払い済みの訳文はそのまま再利用されます。

## 開発

```sh
node --test test/*.test.js
```

テストはルールの順序と照合、言語検出（ラテン↔ラテン、中日韓/キリル/アラビア/デーヴァナーガリー文字の双方向、識別子の混在）、保護された断片、プレースホルダーのフォールバック、および旧フィールドの読み取りと失敗警告の表示をカバーしています。

> [!NOTE]
> `index.js` または `cordis.patch.yml` を変更した後は DeepSeek Harness の再起動が必要です。`client.js` を変更しても UI に変化がない場合は、再インストールしてページを更新してください。

## 既知の制限

> [!CAUTION]
> **システムプロンプトのルールは確率を上げるだけで、強制はできません。** テストではモデルが従わない例を確認しています：翻訳が失敗して Claude が日本語をそのまま受け取ったときは日本語で回答し、セッションの途中でルールを追加したときは、すでにスペイン語の履歴がある Gemini Flash Lite がスペイン語で回答し続けました。回答がすでにあなたの言語である場合は再翻訳しません。

- 見える思考内容はモデルのルートに依存し、要約だけの場合があります。見えない場合、モデルがどの言語で思考しているかは確認できません。
- 保護されるのはコードブロック、インラインコード、リンク、`@パス` だけです。バッククォートで囲まれていないコマンドや引用文も翻訳されます。たとえば `printf "..."` 内の文字列などです。翻訳されたくない内容はバッククォートで囲んでください。英語の文に挟まれた中国語の一節も翻訳されます。
- セッションログとモデルの入力に残るのは訳文です（プラグインはメッセージの書き込み前にしか書き換えられません）。原文は UI 表示にのみ使われます。
- 回答が訳文に置き換わるのはターンの終了後で、生成中はモデルの原文が表示されます。
- `auto` はブラウザが UI 言語を報告するまで同一言語かどうかを判定できず、その間は言語検出だけに頼ります。
- キャッシュされていないテキストは、段落ごとに 1 回の有料 DeepSeek Flash リクエストになります。
- ボタンと警告の文言は中国語、英語、日本語、スペイン語、フランス語、ドイツ語、ロシア語、ポルトガル語の 8 言語に対応しています。設定ページは中国語と英語のみで、その他の言語では英語で表示されます。
- 公式の「推理翻译」（推論翻訳）bundle と同時に有効にすると、両者がそれぞれ translator サービスを登録するため、競合する可能性があります。
- プラグインはユーザーメッセージのレンダリングを引き継いでいるため、Harness のアップグレードで Chat の構造が変わった場合は調整が必要になることがあります。
