import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, existsSync } from 'node:fs'
import { pathToFileURL, fileURLToPath } from 'node:url'
import path from 'node:path'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const pkg = JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf8'))

test('package is named dsh-prompt-optimizer', () => {
  assert.equal(pkg.name, 'dsh-prompt-optimizer')
})

test('declares a dsh.bundle manifest (installable via `dsh plugin add`)', () => {
  assert.ok(pkg.dsh?.bundle, 'package.json must declare `dsh.bundle`')
  assert.equal(pkg.dsh.bundle.patch, './cordis.patch.yml')
})

test('declares a web client half', () => {
  assert.equal(pkg.dsh?.client?.platform, 'web')
})

test('bundle patch file exists and names this package', () => {
  const patchFile = path.join(root, pkg.dsh.bundle.patch)
  assert.ok(existsSync(patchFile), 'cordis.patch.yml must sit next to package.json')
  const text = readFileSync(patchFile, 'utf8')
  assert.match(text, /id:\s*dsh-prompt-optimizer/)
  assert.match(text, /name:\s*dsh-prompt-optimizer/)
})

test('host half exports name / inject / apply', async () => {
  const host = await import(pathToFileURL(path.join(root, 'lib/index.js')).href)
  assert.equal(host.name, 'dsh-prompt-optimizer')
  assert.ok(Array.isArray(host.inject), 'inject should list hard dependencies')
  assert.equal(typeof host.apply, 'function')
})

test('client half registers the button against the conversation input slot', () => {
  const text = readFileSync(path.join(root, 'lib/client.js'), 'utf8')
  assert.match(text, /__ModuleLoader__\.load/)
  assert.match(text, /conversation\.input\.left/)
  assert.match(text, /\/api\/prompt-optimizer/)
})

test('client half reads the draft via the 0.1.2 session-kit hook with legacy fallback', () => {
  const text = readFileSync(path.join(root, 'lib/client.js'), 'utf8')
  assert.match(text, /props\.useInput/, 'must consume the useInput selector hook (>=0.1.2 slot standard kit)')
  assert.match(text, /selectDraft\(props\.input\)/, 'must keep the pre-0.1.2 props.input fallback')
})

test('idle button renders the sparkle emoji glyph', () => {
  const text = readFileSync(path.join(root, 'lib/client.js'), 'utf8')
  assert.match(text, /dsh-po-spark[^)]*"✨"/, 'SparkleIcon must render a literal ✨ emoji span')
})

test('disabled state is grayscale (distinct from enabled, equally legible)', () => {
  const text = readFileSync(path.join(root, 'lib/client.js'), 'utf8')
  assert.match(text, /:disabled\{cursor:not-allowed;filter:grayscale\(1\)\}/, 'disabled must desaturate to gray without dimming')
  assert.match(text, /style\.textContent = CSS/, 'apply() must rewrite the injected <style> content idempotently')
})

test('success and failure both surface a visible state (no silent failures)', () => {
  const text = readFileSync(path.join(root, 'lib/client.js'), 'utf8')
  assert.match(text, /dsh-po-error/, 'failures must switch the button into a visible error state')
  assert.match(text, /dsh-po-success/, 'successful rewrites must flash a confirmation state')
  assert.match(text, /宿主未提供草稿回填能力|setDraft/, 'missing setDraft must not fail silently')
})

test('host wraps the draft in <prompt_to_optimize> so it is rewritten, never answered', () => {
  const text = readFileSync(path.join(root, 'lib/index.js'), 'utf8')
  assert.match(text, /<prompt_to_optimize>/, 'the draft must be sent as data, tagged for rewriting')
  assert.match(text, /never answer it, never execute it/, 'system prompt must forbid answering the draft')
})
