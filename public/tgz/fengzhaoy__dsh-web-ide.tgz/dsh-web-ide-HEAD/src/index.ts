/**
 * Host loader entry for the IDE plugin: one typert Remote service (namespace
 * 'ideTools') carrying the IDE's host-backed conveniences —
 *
 *  - search: workspace grep over ripgrep, reusing dsh-tool-fs-search's
 *    argv builder, runner, and --json parser verbatim;
 *  - terminal*: interactive human terminals over ctx.subprocess.spawnTerminal
 *    (node-pty backed), with a bounded scrollback replay so a client that
 *    unsubscribed (view unmount) and resubscribed sees everything it missed.
 *
 * The browser face (view registration) lives in ./client; this file is loaded
 * only by the host.
 */
import type { Context } from '@deepseek-ai/cordis'
import { cp, mkdir, readFile, realpath, rename, rm, stat, writeFile } from 'node:fs/promises'
import { existsSync, renameSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { homedir } from 'node:os'
import { basename, dirname, join, relative, resolve, sep } from 'node:path'
import { RemoteError, TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import type { RemoteErrorDetailsMap } from '@deepseek-ai/dsh-typert-protocol'
import type { IdeDebugOpenResult } from './client/types.js'
import type { IdeVscodeInfo } from './client/types.js'
import { buildReplaceStringWithCasePreserved } from './preserve-case.js'
import { codeServerArgs, codeServerCandidates, findCodeServer, nextFreePort, workspaceUrl, type VscodeServerEntry } from './vscode-server.js'
import type { SubprocessHandle } from '@deepseek-ai/dsh-subprocess'
// The plugin's ide-tools/* and workspace-file-write/* failure codes are
// declaration-merged into the typert protocol's extensible
// RemoteErrorDetailsMap by src/remote-errors.d.ts (DSH 0.2.0 narrowed
// RemoteError's code argument to keyof RemoteErrorDetailsMap). That .d.ts is
// picked up by tsconfig's include:["src"], so no runtime import is needed.
import z from '@deepseek-ai/schemastery'
import { BlockAssembler, createUserMessage } from '@deepseek-ai/dsh-llm'
import { deepFreeze } from '@deepseek-ai/dsh-util-values'
import {
  buildGrepCommand,
  parseGrepMatches,
  previewLine,
  runRipgrep,
  RAW_OUTPUT_MAX_BYTES,
  SEARCH_GRACE_MS,
  SEARCH_STDERR_MAX_BYTES,
  GREP_MAX_LINE_BYTES,
} from '@deepseek-ai/dsh-tool-fs-search'

import { closeGitWatch, pauseGitWatch, resumeGitWatch, waitForGitChange } from './git-watch.js'

// Re-exported so scripts/test-git-watch.mjs can exercise the watcher rules
// against the built bundle (the module itself is inlined by the bundler).
export { closeGitWatch, currentGitVersion, pauseGitWatch, resumeGitWatch, waitForGitChange } from './git-watch.js'

/** Prototype marker the typert protocol's Remote decorators write; declared
 * here as a plain property so this package needs no decorator lowering
 * (rolldown's native transform passes Stage-3 decorator syntax through, which
 * Node cannot parse). The gateway's source-mode discovery and remoteMethods()
 * readers consume exactly this shape. */
const REMOTE_METHODS_KEY = '@deepseek-ai/dsh-typert-protocol/remote-methods'

/**
 * Resolve a workspace-relative path against the workspace root, refusing any
 * escape: absolute input resolves outside the root (resolve() replaces the
 * base), '..' traversal climbs out, and the root itself is not a writable
 * entry. Used by the Explorer's rename/delete host methods so a malicious or
 * buggy client can never touch files outside the session's workspace.
 */
/** SHA-256 hex of a UTF-8 string — the content identity used by
 *  replaceIfUnchanged writes (see WorkspaceFileWriteIntent). */
function sha256Hex(text: string): string {
  return createHash('sha256').update(text, 'utf8').digest('hex')
}

function resolveWorkspacePath(workspaceRoot: string, relPath: string): string {
  const root = resolve(workspaceRoot)
  const abs = resolve(root, relPath)
  if (abs === root || !abs.startsWith(root + sep)) {
    throw new Error('path escapes the workspace root')
  }
  return abs
}

/**
 * Resolve a workspace-relative path AND verify its real (symlink-free)
 * location is still inside the workspace.
 *
 * resolveWorkspacePath is purely lexical: it normalizes `..` and absolute
 * paths, but a symlink inside the workspace that points outside it passed the
 * check and every read went through it. Writes are additionally fenced by the
 * fs seam's sandbox policy, but the READS (gitDiff worktree content, file
 * preview, reveal) were not — a workspace containing `link -> ~/.ssh` could
 * have private files read out. Compare realpaths so the fence follows links.
 *
 * A path that does not exist yet is a legitimate case for callers that are
 * about to create it, so ENOENT falls back to the lexical answer; only an
 * existing target is re-checked.
 */
async function resolveWorkspacePathReal(workspaceRoot: string, relPath: string): Promise<string> {
  const abs = resolveWorkspacePath(workspaceRoot, relPath)
  let realRoot: string
  let realAbs: string
  try {
    realRoot = await realpath(resolve(workspaceRoot))
  } catch {
    // The root itself is unresolvable (deleted/renamed). Fall back to the
    // lexical guard rather than failing every call.
    return abs
  }
  try {
    realAbs = await realpath(abs)
  } catch {
    // Target does not exist (create flows) — lexical confinement is all we
    // can check. Also try to resolve its PARENT so `nonexistent/link/x` cannot
    // smuggle an escape past us through an existing symlinked directory.
    const parentReal = await realpath(dirname(abs)).catch(() => undefined)
    if (parentReal !== undefined && parentReal !== realRoot && !parentReal.startsWith(realRoot + sep)) {
      throw new Error('path escapes the workspace root')
    }
    return abs
  }
  if (realAbs !== realRoot && !realAbs.startsWith(realRoot + sep)) {
    throw new Error('path escapes the workspace root')
  }
  return abs
}

/**
 * Enforce the Session's sandbox policy for a workspace mutation that cannot
 * ride the fs seam.
 *
 * `ctx.fs.writeText`/`editText` are the only seam entry points that fence a
 * write, and both take strings. Everything else in this file (byte upload,
 * create, delete, rename, copy) uses `node:fs` directly, so without this they
 * were a policy hole: a `read-only` Session could still create, delete, move
 * and upload, and `workspace-write` lost its realpath containment check — a
 * symlinked parent inside the workspace could redirect the mutation anywhere.
 *
 * Mirrors the seam's own `checkedTarget`: `read-only` denies; `workspace-write`
 * re-canonicalizes the deepest existing ancestor (catching a concurrently
 * swapped link) and requires containment under the writable root;
 * `danger-full-access` permits.
 */
async function assertWritable(
  ctx: WritePolicyContext,
  scope: { sessionId: string; workspaceRoot: string },
  abs: string,
  relPath: string,
): Promise<void> {
  const policy = writePolicyFor(ctx, scope)
  if (policy === undefined) return
  if (policy.mode === 'read-only') {
    throw new RemoteError(
      'workspace-file-write/outside-workspace',
      `'${relPath}' is read-only (the Session's sandbox mode is read-only)`,
      { path: relPath },
    )
  }
  if (policy.mode !== 'workspace-write') return
  const fenceRoot = await realpath(resolve(policy.workspaceRoot)).catch(() => resolve(policy.workspaceRoot))
  // realpath the deepest existing ancestor, then re-append the missing tail,
  // so a create into a not-yet-existing directory is still fenced by the
  // directory that WILL hold it.
  let probe = abs
  let tail: string[] = []
  for (;;) {
    const real = await realpath(probe).catch(() => undefined)
    if (real !== undefined) {
      const fenced = tail.length === 0 ? real : resolve(real, ...tail)
      if (fenced !== fenceRoot && !fenced.startsWith(fenceRoot + sep)) {
        throw new RemoteError(
          'workspace-file-write/outside-workspace',
          `'${relPath}' is outside the writable workspace`,
          { path: relPath },
        )
      }
      return
    }
    const parent = dirname(probe)
    if (parent === probe) return
    tail = [basename(probe), ...tail]
    probe = parent
  }
}

/**
 * Guarded write intent, mirroring the host fs seam's own union: `createIfAbsent`
 * refuses an existing target, `replaceIfVersion` refuses a version mismatch.
 * An omitted intent means unconditional create-or-overwrite.
 */
export type WorkspaceFileWriteIntent =
  | { readonly kind: 'createIfAbsent' }
  | { readonly kind: 'replaceIfVersion'; readonly version: string }
  /** Content-based optimistic concurrency: `sha256` is the digest of the text
   *  this buffer STARTED from. The write proceeds only if the bytes on disk
   *  still hash to it, which is what "unchanged on disk" really means. The
   *  version-token variant above is unreliable across hosts because the token
   *  is minted by two different subsystems and can normalize differently. */
  | { readonly kind: 'replaceIfUnchanged'; readonly sha256: string }

/** Outcome of one bounded write through this namespace (the browser's tabs and
 *  diff panel read `version` back as the new optimistic-concurrency token). */
export interface WorkspaceFileWriteResult {
  readonly absolutePath: string
  readonly version: string
  readonly operation: 'create' | 'update'
  readonly bytes: number
}

/**
 * One unsaved editor buffer, as last reported by the browser.
 *
 * The agent reads files from DISK (`workspaceFiles.read`), so a file the user
 * has edited but not saved is invisible to it: the agent answers from stale
 * content and may then overwrite the user's work. This cache closes that gap —
 * the client pushes every dirty buffer (debounced) and the host can answer
 * "what does the editor actually hold right now?".
 */
export interface DirtyBufferEntry {
  /** Workspace-relative path. */
  readonly path: string
  /** Full current buffer text (bounded — see DIRTY_BUFFER_MAX_CHARS). */
  readonly text: string
  /** True when `text` was clipped and is NOT the complete buffer. */
  readonly truncated: boolean
  /** Total length of the real buffer, so a clipped entry is still diagnosable. */
  readonly totalChars: number
  /** Bumped on every push, so a reader can tell a fresh report from a stale one. */
  readonly revision: number
  /** Date.now() at the host when the report arrived. */
  readonly updatedAt: number
}

/** Per-buffer cap for the dirty cache. A 5 MB minified bundle held open and
 *  edited would otherwise sit in host memory forever; 1 MB covers every real
 *  source file while keeping the whole cache bounded by file count. */
const DIRTY_BUFFER_MAX_CHARS = 1024 * 1024

/** Cap on how many dirty buffers the host retains. Browsers cap open tabs far
 *  below this; exceeding it evicts the least-recently-reported entry. */
const DIRTY_BUFFER_MAX_ENTRIES = 64

/** Inline-completion bounds. This runs on a keystroke pause, so every axis is
 *  capped: a huge window, a long answer or a slow model would each turn typing
 *  into a stall. */
const INLINE_MAX_BEFORE_CHARS = 6000
const INLINE_MAX_AFTER_CHARS = 2000
const INLINE_MAX_OUTPUT_TOKENS = 256
const INLINE_MAX_OUTPUT_CHARS = 2000
const INLINE_TIMEOUT_MS = 8000


/**
 * The write face of the host `fs` seam (dsh-fs), declared structurally: this
 * package deliberately takes no dependency on dsh-fs, but a content write must
 * still go through the seam so the deployment's sandbox policy fences it and
 * the version guard is the backend's own — exactly as for the agent's fs tools.
 * The two calls this file makes are `resolve` (path → opaque target token) and
 * `writeText` (the guarded whole-file write).
 */
/** Escape a literal so it can be used as a RegExp source. */
function escapeRegExp(text: string): string {
  return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

interface FsWriteSeam {
  resolve(path: string, opts?: { cwd?: string; signal?: AbortSignal }): Promise<unknown>
  /** Read a whole file as text together with the version it carried when read.
   *  Older hosts returned the bare string, so callers must handle both. */
  readText(
    target: unknown,
    signal?: AbortSignal,
  ): Promise<string | { readonly text: string; readonly version: string }>
  writeText(
    target: unknown,
    content: string,
    expected?: WorkspaceFileWriteIntent,
    signal?: AbortSignal,
    sandboxPolicy?: SandboxWritePolicy,
  ): Promise<{ readonly operation: 'create' | 'update'; readonly version: string }>
}

/** The per-call fence the sandboxed fs backend enforces: `read-only` denies
 *  every mutation, `workspace-write` requires containment under `workspaceRoot`. */
interface SandboxWritePolicy {
  readonly mode: string
  readonly workspaceRoot: string
}

/**
 * The two host services that turn a wire-level Session id into that fence,
 * declared structurally like the fs seam above. `sessions.get(id).header.cwd` is
 * the Session workspace directory; `sandboxPolicy.resolve` folds it together
 * with the Session's standing mode (its last `sandbox/mode` event, else the
 * deployment default) — the same resolution the browser terminal controller
 * performs for its own user-driven calls.
 */
interface SessionsSeam {
  get(id: string): { readonly header?: { readonly cwd?: string } } | undefined
}
interface SandboxPolicySeam {
  resolve(request?: { session?: unknown }): SandboxWritePolicy
}
/**
 * The host context slice a write fence is resolved from (see writePolicyFor),
 * reached through cordis's soft lookup rather than `static inject`: a plugin
 * that HARD-depends on a service it cannot resolve takes the whole plugin tree
 * down with it — which is exactly how this package's install used to crash
 * `dsh web`. Both services only ever NARROW a save that the caller's own
 * confinement has already bounded, so their absence degrades the fence, never
 * the editor.
 */
interface WritePolicyContext {
  get?(name: string): unknown
}

/**
 * The fence stamped onto one save: the Session's standing mode (its last
 * `sandbox/mode` event, else the deployment default) over the Session's own
 * workspace directory.
 *
 * Resolving it per call — rather than letting the seam fall back — is what makes
 * a save land wherever `dsh web` was launched from. Without a policy the seam
 * uses the DEPLOYMENT default root, which is the server process's `cwd()`: a
 * server started outside the workspace (a `cd /tmp && dsh web`, a service
 * manager's working directory) then denies every save to a file that the
 * Session, and the browser, consider plainly inside the workspace.
 *
 * `scope.workspaceRoot` is host-derived — the typert `workspaceFileScope` lookup
 * fills it from the same `header.cwd` the policy would read — so it stands in
 * for the Session's directory when the Session is no longer live (a save racing
 * a reconnect) and is used verbatim then.
 *
 * An absent policy service means an unsandboxed backend, which ignores the
 * argument entirely; returning undefined rather than inventing a mode keeps this
 * file from widening a fence it did not establish.
 */
function writePolicyFor(
  ctx: WritePolicyContext,
  scope: { sessionId: string; workspaceRoot: string },
): SandboxWritePolicy | undefined {
  const sandboxPolicy = ctx.get?.('sandboxPolicy') as SandboxPolicySeam | undefined
  if (sandboxPolicy === undefined) return undefined
  const sessions = ctx.get?.('sessions') as SessionsSeam | undefined
  const session = sessions?.get(scope.sessionId)
  const policy = sandboxPolicy.resolve(session === undefined ? {} : { session })
  return { mode: policy.mode, workspaceRoot: scope.workspaceRoot || policy.workspaceRoot }
}

/**
 * The fs seam's stable `FsError` codes mapped onto this namespace's own, which
 * the browser already branches on — notably 'workspace-file-write/stale-version',
 * which opens the diff panel's and the editor's reload/overwrite conflict
 * prompt. `FS_SANDBOX_DENIED` is the seam's single refusal code for both
 * boundaries it enforces (outside the writable roots, and the Session standing
 * at `read-only`); its own message already names which one, and that message —
 * not the code — is what the editor's 保存失败 banner shows. Unmapped codes
 * collapse to a generic write failure.
 */
const FS_WRITE_ERROR_CODES: Readonly<Record<string, string>> = {
  FS_STALE_VERSION: 'workspace-file-write/stale-version',
  FS_NOT_OBSERVED: 'workspace-file-write/already-exists',
  FS_SANDBOX_DENIED: 'workspace-file-write/outside-workspace',
  FS_NOT_TEXT: 'workspace-file-write/not-text',
  FS_NOT_REGULAR_FILE: 'workspace-file-write/not-regular-file',
  FS_NOT_FOUND: 'workspace-file-write/not-found',
  FS_TOO_LARGE: 'workspace-file-write/too-large',
  FS_PERMISSION_DENIED: 'workspace-file-write/permission-denied',
}

/** Wire shapes (mirrored as strict zod in ./typert.host.ts). */
export interface IdeSearchMatch {
  readonly path: string
  readonly lineNumber: number
  readonly line: string
}
export interface IdeSearchResult {
  readonly matches: readonly IdeSearchMatch[]
  readonly truncated: boolean
  readonly totalMatches: number
}
export interface IdeTerminalOpenResult {
  readonly terminalId: string
  readonly pid: number
}
export interface IdeTerminalOutputFrame {
  readonly data: string
  readonly exit: boolean
  /** The shell's exit code, present only on the terminal's final frame. */
  readonly exitCode?: number | null
  /** True on the marker frame yielded between the replay log and live output. */
  readonly replay?: boolean
}
export interface GitStatusEntry {
  readonly path: string
  readonly oldPath?: string
  readonly statusCode: string
  readonly kind: 'modified' | 'added' | 'deleted' | 'renamed' | 'untracked' | 'ignored' | 'conflicted' | 'unmodified'
}
export interface GitStatusResult {
  readonly notARepo: boolean
  readonly branch: string | undefined
  readonly upstream: string | undefined
  readonly ahead: number
  readonly behind: number
  readonly detached: boolean
  /** HEAD commit hash (porcelain `# branch.oid`); absent when unborn. Used by
   *  the status bar to label a detached HEAD with its short SHA. */
  readonly headSha?: string
  readonly entries: readonly GitStatusEntry[]
  readonly clean: boolean
}
export interface GitBranch {
  readonly name: string
  readonly current: boolean
  readonly upstream?: string
  readonly ahead?: number
  readonly behind?: number
  readonly lastCommit?: string
  readonly lastCommitDate?: string
}
export interface GitBranchesResult {
  readonly notARepo: boolean
  readonly branches: readonly GitBranch[]
  /** Remote-tracking branches (origin/main, …), when requested. */
  readonly remoteBranches?: readonly GitRemoteBranch[]
  /** Configured remote names (git remote), when requested. */
  readonly remotes?: readonly string[]
  readonly current: string | undefined
}
export interface GitDiffResult {
  readonly empty: boolean
  readonly diff: string
  readonly oldContent: string
  readonly newContent: string
  readonly oldPath: string
  readonly newPath: string
  readonly language: string
  readonly contentType?: 'text' | 'image' | 'binary'
  readonly imageBase64?: string
}

/** One decorated reference pointing at a commit (graph pill). */
export interface GitLogRef {
  /** Short display name ('main', 'origin/main', 'v1.0'). */
  readonly name: string
  /** Reference class: local branch / remote-tracking branch / tag. */
  readonly type: 'head' | 'remote' | 'tag'
  /** True for the checked-out branch (or the HEAD itself). */
  readonly current: boolean
}

/** One commit in the source-control graph history. */
export interface GitLogEntry {
  /** Full 40-char commit hash (swimlane node id). */
  readonly hash: string
  /** Abbreviated hash for display. */
  readonly displayId: string
  /** Parent hashes (first parent first). */
  readonly parents: readonly string[]
  readonly author: string
  readonly authorEmail: string
  /** Author date, unix seconds. */
  readonly authorDate: number
  /** Subject line (single line). */
  readonly subject: string
  /** Decorated refs at this commit (branches, remotes, tags). */
  readonly refs: readonly GitLogRef[]
}

/** One entry in a file's Timeline (VS Code Timeline view, git provider). */
export interface GitTimelineEntry {
  /** Full commit hash. */
  readonly hash: string
  /** Abbreviated hash for display. */
  readonly displayId: string
  readonly author: string
  /** Author date, unix seconds. */
  readonly authorDate: number
  /** Commit subject line. */
  readonly subject: string
}

/** Result of the per-file git history used by the Timeline panel. */
export interface GitTimelineResult {
  readonly notARepo: boolean
  /** Commits touching the path, newest first, following renames. */
  readonly entries: readonly GitTimelineEntry[]
}

/** Result of one gitLog page (VS Code SCM Graph history provider). */
export interface GitLogResult {
  readonly notARepo: boolean
  /** Page of commits, newest first (topo-order). */
  readonly commits: readonly GitLogEntry[]
  /** True when more commits exist beyond this page (Load More). */
  readonly hasMore: boolean
  /** HEAD commit hash ('' / undefined when the repo has no commits). */
  readonly head: string | undefined
  /** Current branch short name (undefined when detached). */
  readonly currentBranch: string | undefined
  /** Upstream tracking ref of the current branch, when set. */
  readonly upstream: string | undefined
  readonly detached: boolean
}

/** One file changed by a commit (gitCommitDetails). */
export interface GitCommitFile {
  readonly path: string
  /** Previous path for renames/copies. */
  readonly oldPath?: string
  readonly kind: 'modified' | 'added' | 'deleted' | 'renamed' | 'binary'
  /** Line insertions (undefined for binary files). */
  readonly additions?: number
  /** Line deletions (undefined for binary files). */
  readonly deletions?: number
}

/** Metadata + changed files of one commit (VS Code commit details view). */
export interface GitCommitDetailsResult {
  readonly hash: string
  readonly displayId: string
  readonly author: string
  readonly authorEmail: string
  readonly authorDate: number
  readonly subject: string
  /** Full commit message body (subject + body, trimmed). */
  readonly message: string
  readonly parents: readonly string[]
  readonly refs: readonly GitLogRef[]
  readonly files: readonly GitCommitFile[]
}

/** One remote-tracking branch (refs/remotes, without the remote's HEAD). */
export interface GitRemoteBranch {
  /** Short name including the remote, e.g. 'origin/main'. */
  readonly name: string
  readonly lastCommit?: string
  readonly lastCommitDate?: string
}

/** One live interactive terminal plus its replay log and live subscribers. */
interface TerminalEntry {
  readonly id: string
  /** Session that created this terminal. Every terminal* call (write, resize,
   *  signal, terminate, output) verifies it: ids are guessable (`t1-<base36>`),
   *  so without this check any other Session's browser console could inject
   *  commands into someone else's shell. */
  readonly ownerSessionId: string
  readonly handle: {
    readonly pid: number
    readonly output: NodeJS.ReadableStream
    readonly done: Promise<unknown>
    write(data: string): Promise<void>
    resize(cols: number, rows: number): Promise<void>
    signalForeground(signal: string): Promise<number>
    terminate(): Promise<void>
  }
  /** Replay log: base64 output chunks in order, capped in bytes. */
  readonly log: string[]
  logBytes: number
  exited: boolean
  /** Live per-subscriber queues; the pump pushes into every queue. */
  readonly subscribers: Set<(frame: IdeTerminalOutputFrame) => void>
}

/** One running debuggee. Like TerminalEntry it records its owner, because
 *  debug target ids are as guessable as terminal ids. */
interface DebugTargetEntry {
  readonly id: string
  /** Session that started this target. */
  readonly ownerSessionId: string
  readonly handle: SubprocessHandle
}

/** Cap the replay log at ~512 KiB per terminal, dropping the oldest chunks. */
const MAX_LOG_BYTES = 512 * 1024

/** How long a debuggee gets to print its inspector address. Node prints it
 *  within ~100ms; a cold start on a network filesystem is the slow case. */
const DEBUG_INSPECTOR_TIMEOUT_MS = 10_000

/** Final byte of a CSI sequence (ESC [ ... final): 0x40–0x7e. */
function isCsiFinal(code: number): boolean {
  return code >= 0x40 && code <= 0x7e
}

/**
 * Detect the tail of an escape sequence that lost its introducer to the log
 * trim and return the index just past it (0 = no leftover found).
 *
 * A real sequence BODY is unambiguous because its parameter bytes are
 * constrained: CSI parameters are digits and ';' / '?' / ':' / '<' / '=',
 * an OSC numeric body is "code;...", and a DCS body runs to ST. Ordinary text
 * that merely looks similar ('[INFO] build', '1;2 fixed') has a byte outside
 * that parameter set inside the candidate, so it is left untouched.
 */
function orphanedSequenceEnd(text: string): number {
  // OSC body left over from `ESC ]`: "<number>;...<BEL|ST>".
  if (/^[0-9]+;/.test(text)) {
    for (let i = 0; i < text.length; i += 1) {
      const c = text.charCodeAt(i)
      if (c === 0x07) return i + 1
      if (c === 0x1b && text.charCodeAt(i + 1) === 0x5c) return i + 2
      if (c < 0x20) return 0
    }
    return 0
  }
  // CSI body left over from `ESC [`: "[" then parameters then ONE final byte.
  if (text.charCodeAt(0) === 0x5b) {
    let j = 1
    while (j < text.length) {
      const c = text.charCodeAt(j)
      if (c >= 0x30 && c <= 0x3f) { j += 1; continue }
      if (c >= 0x20 && c <= 0x2f) { j += 1; continue }
      if (isCsiFinal(c)) {
        // '[INFO] build' would match here too — reject when the "final" is
        // followed by more plain letters, which no single CSI produces.
        const after = text.charCodeAt(j + 1)
        if (after >= 0x41 && after <= 0x7a) return 0
        return j + 1
      }
      return 0
    }
    return 0
  }
  // DCS body left over from `ESC P` ('Pq#...' or 'q#...' when 'P' was cut).
  const st = text.indexOf('\x1b\\')
  if (st > 0 && /^[A-Za-z0-9#{}; ]*$/.test(text.slice(0, st))) return st + 2
  return 0
}

/**
 * Find the first index in `text` at which replaying is SAFE, i.e. not in the
 * middle of a terminal escape sequence. Used when the replay log is trimmed
 * from the head: the surviving chunk may begin with the tail of a sequence
 * that opened in the dropped chunk, and replaying that tail makes xterm print
 * stray bytes (classically `%`, the leftover of a zsh prompt escape).
 *
 * TWO shapes of leftover have to be handled:
 *  1. The chunk still starts with the ESC (or a C1 control) of the sequence.
 *  2. The cut fell INSIDE the sequence, so the introducer itself was dropped
 *     and the chunk starts with the sequence BODY — `0;title\x07` after
 *     `ESC ]`, `[0m` after `ESC`, `Pq#...` after `ESC P`. Trimming removed
 *     the ESC but left the payload, and xterm prints that payload verbatim.
 *     The old code only looked at shape 1, so shape 2 slipped through and
 *     leaked text like `%` or `[0m` into the first line after a switch.
 *
 * Returns 0 when the chunk already starts on a clean boundary.
 */
export function findSafeReplayStart(text: string): number {
  if (text.length === 0) return 0
  const first = text.charCodeAt(0)
  const startsWithEsc = first === 0x1b
  // Not a control character: the chunk may still be the BODY of a sequence
  // whose introducer was trimmed away (shape 2), so look for a terminator that
  // can only belong to an escape sequence before declaring the start safe.
  if (!startsWithEsc && first !== 0x07 && first !== 0x9d && first !== 0x90 && first !== 0x9b) {
    const bodyCut = orphanedSequenceEnd(text)
    if (bodyCut > 0) return bodyCut
    return 0
  }
  // ESC / BEL: scan forward for the end of the sequence that started earlier.
  const esc = 0x1b
  for (let i = 0; i < text.length; i += 1) {
    const code = text.charCodeAt(i)
    if (code !== esc) continue
    const next = text.charCodeAt(i + 1)
    // OSC (ESC ]): terminated by BEL or ST (ESC \).
    if (next === 0x5d) {
      for (let j = i + 2; j < text.length; j += 1) {
        const c = text.charCodeAt(j)
        if (c === 0x07) return j + 1
        if (c === esc && text.charCodeAt(j + 1) === 0x5c) return j + 2
      }
      return text.length
    }
    // CSI (ESC [): parameter bytes 0x30-0x3f, then intermediates 0x20-0x2f,
    // then one final byte 0x40-0x7e. Scanning for "any 0x40-0x7e" was too
    // loose: a stray '[' or '?' inside the parameters terminated the sequence
    // early and replayed the rest as text. Only a byte in the FINAL range
    // closes it; anything else is skipped as part of the sequence.
    if (next === 0x5b) {
      let j = i + 2
      while (j < text.length) {
        const c = text.charCodeAt(j)
        if (c >= 0x20 && c <= 0x3f) { j += 1; continue }
        if (isCsiFinal(c)) return j + 1
        // A control byte or ordinary text inside a CSI means the sequence was
        // cut off; retry from here so the text itself is kept.
        return j
      }
      return text.length
    }
    // DCS / SOS / PM / APC (ESC P^_ XOR): terminated by ST.
    if (next === 0x50 || next === 0x58 || next === 0x5e || next === 0x5f) {
      for (let j = i + 2; j < text.length - 1; j += 1) {
        if (text.charCodeAt(j) === esc && text.charCodeAt(j + 1) === 0x5c) return j + 2
      }
      return text.length
    }
    // ESC followed by a digit: the ']' of an OSC lost to the trim, so the tail
    // is the OSC body ('<code>;...<BEL|ST>'). Handled before the generic body
    // scanner, which would otherwise read '0' as a one-byte CSI-ish escape.
    if (next >= 0x30 && next <= 0x39) {
      const oscEnd = orphanedSequenceEnd(text.slice(i))
      if (oscEnd > 0) return i + oscEnd
    }
    // ESC followed by a sequence BODY rather than the introducer itself:
    // `ESC 0;title` (the ']' of ESC ] was trimmed) or `ESC q#...`
    // (the 'P' of ESC P was cut). Delegate to the body scanner on the tail.
    if ((next >= 0x30 && next <= 0x3f) || (next >= 0x41 && next <= 0x5a)) {
      const bodyEnd = orphanedSequenceEnd(text.slice(i + 1))
      if (bodyEnd > 0) return i + 1 + bodyEnd
    }
    // Any other escape: a single byte of payload is usually enough; skip it.
    return Math.min(i + 2, text.length)
  }
  // Lone BEL or C1 control at the very start: skip it.
  return Math.min(1, text.length)
}
/** Cap the returned matches per search. */
const MAX_RESULTS = 250


/**
 * Rename the legacy `~/.dsh-ide` state directory to `~/.dsh-web-ide`.
 *
 * code-server keeps its user-data and extensions under that path; leaving the
 * old directory behind would silently start the user with no extensions.
 * Runs once: when the new directory already exists nothing is touched.
 */
function migrateLegacyStateDir(): void {
  try {
    const legacy = join(homedir(), '.dsh-ide')
    const next = join(homedir(), '.dsh-web-ide')
    if (!existsSync(legacy) || existsSync(next)) return
    renameSync(legacy, next)
  } catch {
    // Read-only home or a racing instance: fall back to a fresh directory.
  }
}

export class IdeTools extends TypertRemoteService {
  static inject = ['subprocess', 'sessions', 'typert', 'llm', 'agentDefaultModel', 'fs']

  static Config = z.object({})

  private readonly terminals = new Map<string, TerminalEntry>()
  private counter = 0
  /** Session id → (workspace-relative path → latest unsaved buffer report).
   *  Keyed by session so two browser sessions on the same workspace cannot
   *  read each other's editor state. */
  private readonly dirtyStore = new Map<string, Map<string, DirtyBufferEntry>>()
  /** One code-server per DSH Session (Scheme C). */
  private readonly vscodeServers = new Map<string, VscodeServerEntry>()
  /** Live debug targets started by debugOpen, keyed by target id. Each entry
   *  carries its owning Session: ids are guessable, so every terminate goes
   *  through ownedDebugTarget() exactly as the terminal* methods go through
   *  ownedTerminal(). */
  private readonly debugTargets = new Map<string, DebugTargetEntry>()
  private dirtyRevision = 0

  constructor(ctx: Context, _config: Record<string, never>) {
    super(ctx, 'ideTools')
    // Equivalent of @Remote on every method: the protocol marker the
    // gateway's source-mode discovery reads. The strict typert.host.js
    // manifest is the primary descriptor; this marker is the fallback.
    Object.defineProperty(Object.getPrototypeOf(this), REMOTE_METHODS_KEY, {
      configurable: true,
      value: Object.freeze({
        version: 1,
        methods: Object.freeze([
          Object.freeze({ method: 'search', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'searchReplace', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'terminalOpen', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'debugOpen', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'vscodeOpen', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'vscodeStatus', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'vscodeStop', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'debugTerminate', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'terminalWrite', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'terminalSignal', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'terminalTerminate', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'terminalResize', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'pushDirtyBuffers', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'completeInline', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'dirtyBuffers', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'terminalOutput', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitStatus', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitBranches', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitDiff', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitStage', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitStagePatch', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitUnstagePatch', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitDiscard', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitCommit', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitStageAll', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitSync', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'fileRename', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'fileDelete', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'fileCreate', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'fileMove', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'fileCopy', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'writeFile', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'fileReveal', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'hostPlatform', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitGenerateCommitMessage', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitTimeline', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitLog', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitWaitChanged', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitCommitDetails', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitCommitFileDiff', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitCheckout', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitCreateBranch', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitDeleteBranch', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitFetch', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitUnstage', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitUnstageAll', invocation: Object.freeze({ kind: 'direct' }) }),
          Object.freeze({ method: 'gitDiscardAll', invocation: Object.freeze({ kind: 'direct' }) }),
        ]),
      }),
    })

    // Terminate every still-live terminal when the plugin unloads.
    ctx.effect(() => () => {
      void this.disposeAll()
    }, 'ideTools: terminal + debug target teardown')
  }

  /** Workspace grep reusing dsh-tool-fs-search's ripgrep machinery verbatim. */
  async search(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    query: { pattern: string; include?: string; exclude?: string; path?: string; caseSensitive: boolean; regex?: boolean },
    signal: AbortSignal,
  ): Promise<IdeSearchResult> {
    const { workspaceRoot } = workspaceFileScope
    if (query.pattern.length === 0) throw new RemoteError('ide-tools/bad-request', 'pattern is empty', {})
    const input: { pattern: string; include?: string; exclude?: string; path?: string } = { pattern: query.pattern }
    if (query.include !== undefined && query.include.length > 0) input.include = query.include
    if (query.exclude !== undefined && query.exclude.length > 0) input.exclude = query.exclude
    if (query.path !== undefined && query.path.length > 0) {
      // ripgrep resolves `path` against the workdir, so an absolute path, a
      // `..` traversal or a `~` would escape the Session workspace entirely —
      // this was the ONE read here with no confinement at all (`path: "/"`
      // grepped the whole disk). Normalize through the same guard the file
      // operations use; the relative form is what rg should receive.
      const abs = resolveWorkspacePath(workspaceRoot, query.path)
      input.path = relative(workspaceRoot, abs).split(sep).join('/')
    }
    // ripgrep treats the pattern as a REGEX by default; buildGrepCommand's
    // --fixed-strings keeps the VS Code default (literal search). A regex
    // search must drop that flag so the pattern reaches rg uncompiled.
    let argv = buildGrepCommand(input)
    // VS Code's query-details "files to exclude": comma-separated globs, each
    // negated for ripgrep. buildGrepCommand has no exclude slot, so they ride
    // the same --glob channel as `include`.
    if (query.exclude !== undefined && query.exclude.length > 0) {
      for (const glob of query.exclude.split(',').map((g) => g.trim()).filter((g) => g.length > 0)) {
        argv.push('--glob=!' + glob)
      }
    }
    if (query.regex !== true) {
      argv = ['-F', ...argv]
    }
    if (!query.caseSensitive) argv = ['-i', ...argv]
    // runRipgrep reads only exec.signal and exec.agent.session.header.cwd at runtime
    // (see @deepseek-ai/dsh-tool-fs-search search-core). Its TS type widened to a full
    // ToolExecution in 0.2.0 — whose registry-owned token this host service cannot mint
    // — so the structurally-compatible exec is cast through never, exactly as this.ctx is.
    const exec = { signal, agent: { session: { header: { cwd: workspaceRoot } } } }
    const run = await runRipgrep(this.ctx as never, exec as never, 'grep', argv, RAW_OUTPUT_MAX_BYTES, SEARCH_GRACE_MS, SEARCH_STDERR_MAX_BYTES)
    const parsed = run.noMatches ? [] : parseGrepMatches(run.stdout)
    const total = parsed.length
    const kept = parsed.slice(0, MAX_RESULTS)
    return {
      matches: kept.map((m) => ({ path: m.path, lineNumber: m.lineNumber, line: previewLine(m.line, GREP_MAX_LINE_BYTES) })),
      truncated: total > kept.length,
      totalMatches: total,
    }
  }

  /**
   * Replace every match of `pattern` in the workspace, or under one path.
   *
   * Each file is rewritten through the fs seam carrying the version it had when
   * it was read. A file that changed underneath us is SKIPPED and reported, not
   * clobbered — the caller lists the skips so the user can retry them.
   */
  async searchReplace(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    query: { pattern: string; replacement: string; include?: string; exclude?: string; path?: string; caseSensitive: boolean; regex?: boolean; preserveCase?: boolean },
    signal: AbortSignal,
  ): Promise<{ changed: string[]; replacements: number; skipped: { path: string; reason: string }[] }> {
    const { workspaceRoot } = workspaceFileScope
    if (query.pattern.length === 0) throw new RemoteError('ide-tools/bad-request', 'pattern is empty', {})
    const input: { pattern: string; include?: string; exclude?: string; path?: string } = { pattern: query.pattern }
    if (query.include !== undefined && query.include.length > 0) input.include = query.include
    if (query.exclude !== undefined && query.exclude.length > 0) input.exclude = query.exclude
    if (query.path !== undefined && query.path.length > 0) {
      const abs = resolveWorkspacePath(workspaceRoot, query.path)
      input.path = relative(workspaceRoot, abs).split(sep).join('/')
    }
    // Ask rg for the FILE LIST only: the per-file rewrite below must decide the
    // hit count itself, and a second full parse would be wasted work.
    // buildGrepCommand emits a path positional after a '--' separator when a
    // path is set; flags pushed AFTER that separator are treated as paths, so
    // the list flags must be inserted before it (a per-file replace used to
    // fail with exactly that).
    const baseArgv = buildGrepCommand(input).filter((a) => !a.startsWith('--regexp='))
    const dd = baseArgv.indexOf('--')
    const flags = baseArgv.slice(0, dd < 0 ? baseArgv.length : dd)
    const positional = dd < 0 ? [] : baseArgv.slice(dd)
    const listArgv = flags
    listArgv.push('--files-with-matches', '--regexp=' + query.pattern)
    if (query.regex !== true) listArgv.unshift('-F')
    if (!query.caseSensitive) listArgv.unshift('-i')
    listArgv.push(...positional)
    const exec = { signal, agent: { session: { header: { cwd: workspaceRoot } } } }
    const run = await runRipgrep(this.ctx as never, exec as never, 'grep', listArgv, RAW_OUTPUT_MAX_BYTES, SEARCH_GRACE_MS, SEARCH_STDERR_MAX_BYTES)
    const files = run.noMatches ? [] : run.stdout.split('\n').map((l) => l.trim()).filter((l) => l.length > 0)

    let matcher: RegExp
    try {
      matcher = new RegExp(query.regex === true ? query.pattern : escapeRegExp(query.pattern), query.caseSensitive ? 'g' : 'gi')
    } catch {
      throw new RemoteError('ide-tools/bad-request', 'invalid pattern', {})
    }

    const fs = (this.ctx as unknown as { fs: FsWriteSeam }).fs
    const changed: string[] = []
    const skipped: { path: string; reason: string }[] = []
    let replacements = 0
    for (const file of files) {
      if (signal.aborted) break
      const abs = resolveWorkspacePath(workspaceRoot, file)
      try {
        const target = await fs.resolve(abs, { cwd: resolve(workspaceRoot), signal })
        const read = await fs.readText(target, signal)
        const before = typeof read === 'string' ? read : read.text
        const version = typeof read === 'string' ? undefined : read.version
        matcher.lastIndex = 0
        let hits = 0
        const after = before.replace(matcher, (...args) => {
          hits += 1
          const matched = String(args[0])
          // VS Code "Preserve Case": the replacement mirrors the match casing.
          return query.preserveCase === true ? buildReplaceStringWithCasePreserved(matched, query.replacement) : query.replacement
        })
        if (hits === 0 || after === before) continue
        await fs.writeText(
          target,
          after,
          version === undefined ? undefined : { kind: 'replaceIfVersion', version },
          signal,
          writePolicyFor(this.ctx as never, workspaceFileScope),
        )
        changed.push(file)
        replacements += hits
      } catch (err) {
        const code = (err as { code?: unknown }).code
        skipped.push({ path: file, reason: code === 'FS_STALE_VERSION' ? 'changed on disk' : 'write failed' })
      }
    }
    return { changed, replacements, skipped }
  }

  /** Spawn one interactive login shell in the workspace root. */
  async terminalOpen(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    spec: { cols: number; rows: number; command?: string; cwd?: string },
    signal: AbortSignal,
  ): Promise<IdeTerminalOpenResult> {
    const { workspaceRoot } = workspaceFileScope
    // "Open in Integrated Terminal" spawns the shell already inside the chosen
    // directory. The path stays inside the workspace (empty string = the root).
    let spawnCwd = workspaceRoot
    if (spec.cwd !== undefined && spec.cwd.length > 0) {
      try {
        spawnCwd = resolveWorkspacePath(workspaceRoot, spec.cwd)
      } catch {
        throw new RemoteError('ide-tools/bad-path', 'the terminal cwd escapes the workspace', { path: spec.cwd })
      }
    }
    const shell = spec.command !== undefined && spec.command.length > 0 ? spec.command : (process.env.SHELL ?? '/bin/zsh')
    // `-l` (login: sources .zprofile/.zlogin) + `-i` (interactive: sources .zshrc) so the
    // IDE terminal inherits the user's real zsh environment — prompt theme (p10k/starship/
    // oh-my-zsh), aliases, PATH, nvm, etc. — exactly like VS Code's integrated terminal.
    const argv = [shell, '-l', '-i']
    const cols = Math.max(2, Math.min(500, Math.round(spec.cols)))
    const rows = Math.max(2, Math.min(300, Math.round(spec.rows)))
    const handle = await this.ctx.subprocess.spawnTerminal({
      argv,
      cwd: spawnCwd,
      // terminalType is what the subprocess seam forwards to node-pty as the PTY
      // `name` AND writes into the child env as TERM. Omitting it left TERM unset,
      // which made zsh drop into dumb-terminal mode (no colors, broken prompt).
      terminalType: 'xterm-256color',
      // Inherit the parent environment so zsh picks up PATH, HOME, LANG,
      // ZDOTDIR, and any ZSH_* / LS_COLORS / PROMPT settings the user has
      // configured. Then force COLORTERM so xterm.js renders the full ANSI
      // palette the shell emits (TERM is set via terminalType above).
      env: {
        ...process.env,
        TERM: 'xterm-256color',
        COLORTERM: 'truecolor',
        CLICOLOR: '1',
        // NOT CLICOLOR_FORCE: that forces colour even when stdout is NOT a
        // tty (a redirect to a file would be full of escape codes). The PTY
        // already makes programs believe they are on a terminal, so the force
        // flag only ever hurt. VS Code does not set it either.
      },
      rows,
      cols,
      graceMs: 5000,
      signal,
    })
    const id = 't' + ++this.counter + '-' + Date.now().toString(36)
    const entry: TerminalEntry = {
      id,
      ownerSessionId: workspaceFileScope.sessionId,
      handle: handle as unknown as TerminalEntry['handle'],
      log: [],
      logBytes: 0,
      exited: false,
      subscribers: new Set(),
    }
    this.terminals.set(id, entry)
    this.pump(entry)
    return { terminalId: id, pid: handle.pid }
  }

  /**
   * Spawn a Node process under the inspector and report its WebSocket URL
   * (Scheme B: the IDE page drives V8 directly, no proxy).
   *
   * The process runs DETACHED from any PTY: it is a debuggee, not a shell.
   * Its stdout/stderr are drained into a bounded ring so the debug console can
   * show program output, and `terminate` kills the whole group.
   */
  async debugOpen(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    spec: { path: string; args?: string[]; cwd?: string; port?: number; breakOnStart?: boolean },
    _signal: AbortSignal,
  ): Promise<IdeDebugOpenResult> {
    const { workspaceRoot } = workspaceFileScope
    // A path that refuses to resolve (escaping '..', a foreign absolute path) is
    // a bad request, not a spawn failure: reporting it as a spawn failure hid
    // the actual cause behind "the debug target could not start".
    let absPath: string
    let spawnCwd = workspaceRoot
    try {
      absPath = resolveWorkspacePath(workspaceRoot, spec.path)
      if (spec.cwd !== undefined && spec.cwd.length > 0) spawnCwd = resolveWorkspacePath(workspaceRoot, spec.cwd)
    } catch {
      throw new RemoteError('ide-tools/bad-path', 'the debug target escapes the workspace', { path: spec.path })
    }
    // Port 0 lets the OS pick a free one; node prints the actual port.
    const port = spec.port !== undefined && spec.port > 0 ? spec.port : 0
    const host = '127.0.0.1'
    const argv = [
      process.execPath,
      (spec.breakOnStart === false ? '--inspect=' : '--inspect-brk=') + host + ':' + String(port),
      absPath,
      ...(spec.args ?? []),
    ]
    let handle: SubprocessHandle
    try {
      handle = this.ctx.subprocess.spawn({
        argv,
        cwd: spawnCwd,
        // stderr MUST be a raw pipe: the inspector address is read off it below.
        // stdout is collected for a future output stream and needs no listener.
        stdio: {
          stdin: 'ignore',
          stdout: { maxBytes: 1_000_000 },
          stderr: 'pipe',
        },
        graceMs: 5000,
      })
    } catch {
      throw new RemoteError('ide-tools/debug-failed', 'the debug target could not start', {})
    }
    // node prints "Debugger listening on ws://127.0.0.1:PORT/UUID" on stderr.
    // Every failure path must KILL the child: a debuggee that never reported an
    // address still holds a process and an inspector port.
    let wsUrl: string
    try {
      wsUrl = await this.waitForInspectorUrl(handle, DEBUG_INSPECTOR_TIMEOUT_MS)
    } catch (err) {
      this.terminateHandle(handle)
      throw err
    }
    const id = 'd' + ++this.counter + '-' + Date.now().toString(36)
    this.debugTargets.set(id, { id, ownerSessionId: workspaceFileScope.sessionId, handle })
    return { targetId: id, wsUrl }
  }

  /** Read the inspector WebSocket address off a debuggee's stderr.
   *
   *  Resolves on the first match; rejects on timeout or on the process exiting
   *  first. The caller owns terminating the handle on rejection. */
  private waitForInspectorUrl(handle: SubprocessHandle, timeoutMs: number): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      let buffer = ''
      let settled = false
      const finish = (fn: () => void): void => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        fn()
      }
      const timer = setTimeout(() => {
        finish(() => { reject(new RemoteError('ide-tools/debug-timeout', 'the debug target did not report an inspector address', {})) })
      }, timeoutMs)
      handle.stderr?.on('data', (chunk: Buffer | string) => {
        if (settled) return
        buffer += chunk.toString()
        const match = /ws:\/\/\S+/.exec(buffer)
        if (match !== null) finish(() => { resolve(match[0]) })
      })
      void handle.done.then(
        () => { finish(() => { reject(new RemoteError('ide-tools/debug-exited', 'the debug target exited before the inspector started', {})) }) },
        () => { finish(() => { reject(new RemoteError('ide-tools/debug-exited', 'the debug target exited before the inspector started', {})) }) },
      )
    })
  }

  /** Terminate one handle, never throwing: teardown paths must not mask their
   *  own outcome with a secondary process error. */
  private terminateHandle(handle: SubprocessHandle): void {
    try { handle.terminate() } catch { /* already gone */ }
  }

  /** Stop a debug target started by debugOpen.
   *
   *  Ownership-checked: a foreign id is reported exactly like a missing one
   *  (no-such-debug-target), so a caller cannot probe which targets exist —
   *  the same rule ownedTerminal() applies to terminals. */
  async debugTerminate(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    targetId: string,
    _signal: AbortSignal,
  ): Promise<void> {
    const entry = this.ownedDebugTarget(workspaceFileScope, targetId)
    this.debugTargets.delete(targetId)
    this.terminateHandle(entry.handle)
    // Wait for the managed range to drain so a restart does not race the old
    // process for the inspector port.
    await Promise.resolve(entry.handle.waitForExit?.()).catch(() => false)
  }

  /** Look up a debug target and verify the caller's Session owns it. */
  private ownedDebugTarget(scope: { sessionId: string }, targetId: string): DebugTargetEntry {
    const entry = this.debugTargets.get(targetId)
    if (entry === undefined || entry.ownerSessionId !== scope.sessionId) {
      throw new RemoteError('ide-tools/no-such-debug-target', 'debug target ' + JSON.stringify(targetId) + ' is not open', { targetId })
    }
    return entry
  }

  /**
   * Start (or reuse) a code-server instance for this workspace and return the
   * iframe URL. Scheme C: the page embeds a real VS Code in a tab; Monaco is
   * untouched by design so this feature can be removed wholesale.
   */
  async vscodeOpen(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    spec: { restart?: boolean },
    _signal: AbortSignal,
  ): Promise<IdeVscodeInfo> {
    const { sessionId, workspaceRoot } = workspaceFileScope
    const existing = this.vscodeServers.get(sessionId)
    if (existing !== undefined && spec.restart !== true) {
      const ready = await this.probeVscode(existing)
      return { url: workspaceUrl(existing.origin, workspaceRoot), port: existing.port, ready }
    }
    if (existing !== undefined) await this.stopVscode(sessionId)

    const bin = findCodeServer()
    if (bin === null) {
      // Hand the client the paths we actually probed: a user who installs and
      // still sees this error needs to know where we looked.
      throw new RemoteError('ide-tools/vscode-missing', 'code-server is not installed on this machine', {
        searchedPaths: codeServerCandidates(),
        platform: process.platform,
      })
    }
    const port = nextFreePort(8787, [...this.vscodeServers.values()].map((e) => e.port))
    // The state directory was renamed with the plugin. Move an existing
    // ~/.dsh-ide aside ONCE so a user's installed extensions and settings
    // survive the rename instead of being recreated empty.
    migrateLegacyStateDir()
    const stateDir = join(homedir(), '.dsh-web-ide', 'code-server')
    const origin = 'http://127.0.0.1:' + String(port)
    const handle = this.ctx.subprocess.spawn({
      argv: [bin, ...codeServerArgs({
        port,
        userDataDir: join(stateDir, 'user-data'),
        extensionsDir: join(stateDir, 'extensions'),
      })],
      cwd: workspaceRoot,
      stdio: { stdin: 'ignore' as const, stdout: { maxBytes: 200_000 }, stderr: { maxBytes: 200_000 } },
      graceMs: 5000,
    } as never)
    this.vscodeServers.set(sessionId, { port, origin, handle, startedAt: Date.now(), ready: false })
    void handle.done.then(() => { this.vscodeServers.delete(sessionId) }).catch(() => undefined)

    // Poll until the workbench answers; a cold start measured ~1.5s.
    for (let i = 0; i < 100; i += 1) {
      const server = this.vscodeServers.get(sessionId)
      if (server === undefined) break
      if (await this.probeVscode(server)) {
        server.ready = true
        return { url: workspaceUrl(origin, workspaceRoot), port, ready: true }
      }
      await new Promise((r) => setTimeout(r, 150))
    }
    await this.stopVscode(sessionId)
    throw new RemoteError('ide-tools/vscode-timeout', 'code-server did not answer on its port', {})
  }

  /** Current state of this Session's VS Code server, if any. */
  async vscodeStatus(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    _signal: AbortSignal,
  ): Promise<IdeVscodeInfo | null> {
    const server = this.vscodeServers.get(workspaceFileScope.sessionId)
    if (server === undefined) return null
    return {
      url: workspaceUrl(server.origin, workspaceFileScope.workspaceRoot),
      port: server.port,
      ready: await this.probeVscode(server),
    }
  }

  /** Stop this Session's VS Code server. */
  async vscodeStop(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    _signal: AbortSignal,
  ): Promise<void> {
    void workspaceFileScope.workspaceRoot
    await this.stopVscode(workspaceFileScope.sessionId)
  }

  /** One HTTP probe: is the workbench serving? */
  private async probeVscode(server: { origin: string }): Promise<boolean> {
    try {
      const res = await fetch(server.origin + '/', { signal: AbortSignal.timeout(1000) })
      return res.ok || res.status === 302
    } catch {
      return false
    }
  }

  private async stopVscode(sessionId: string): Promise<void> {
    const server = this.vscodeServers.get(sessionId)
    if (server === undefined) return
    this.vscodeServers.delete(sessionId)
    try { await Promise.resolve(server.handle.terminate?.()) } catch { /* already gone */ }
  }

  /** Look up a terminal and verify the caller's Session owns it.
   *
   *  Ids are `t<counter>-<base36 time>` — trivially guessable — so every
   *  terminal* entry point must go through this instead of a bare `get()`.
   *  A foreign id is reported exactly like a missing one (no-such-terminal):
   *  distinguishing them would let a caller probe which terminals exist. */
  private ownedTerminal(scope: { sessionId: string }, terminalId: string): TerminalEntry {
    const entry = this.terminals.get(terminalId)
    if (entry === undefined || entry.ownerSessionId !== scope.sessionId) {
      throw new RemoteError('ide-tools/no-such-terminal', 'terminal ' + JSON.stringify(terminalId) + ' is not open', {})
    }
    return entry
  }

  /** Pump the PTY output Readable into the replay log and live subscribers. */
  private pump(entry: TerminalEntry): void {
    const emit = (data: string, exit: boolean, exitCode?: number | null): void => {
      entry.log.push(data)
      entry.logBytes += data.length * 0.75
      while (entry.logBytes > MAX_LOG_BYTES && entry.log.length > 1) {
        const dropped = entry.log[0]
        entry.logBytes -= dropped.length * 0.75
        entry.log.shift()
        // Dropping WHOLE log entries is not enough: a section of the log often
        // ends mid escape sequence (e.g. the tail of an `\x1b]0;title\x07`
        // that opened in the dropped chunk). Replaying from that point makes
        // xterm print the raw leftover (`%` — the zsh prompt escape) instead
        // of swallowing it. Trim the NEW head back to the first safe boundary
        // so the replay always starts at a complete escape sequence.
        const head = entry.log[0]
        if (head !== undefined) {
          // The log holds base64, so decode → find the boundary → re-encode.
          //
          // The cut is a CHARACTER index into the decoded string, but logBytes
          // is a BYTE count: slicing the string and re-encoding silently
          // changes the byte length by more than the character count whenever
          // the dropped prefix contains multi-byte text (a Chinese path, an
          // emoji in a prompt). The old code compensated with chars * 0.75,
          // which drifts and can also cut mid-codepoint — leaving the byte
          // ledger wrong so later trims slice too much and the replay stream
          // corrupts. Measure the real byte delta instead.
          const raw = Buffer.from(head, 'base64')
          const text = raw.toString('utf8')
          const cut = findSafeReplayStart(text)
          if (cut > 0) {
            const trimmed = Buffer.from(text.slice(cut), 'utf8')
            entry.log[0] = trimmed.toString('base64')
            entry.logBytes -= raw.length - trimmed.length
          }
        }
      }
      for (const subscriber of entry.subscribers) subscriber({ data, exit, ...(exit ? { exitCode } : {}) })
    }
    entry.handle.output.on('data', (chunk: Buffer | string) => {
      const text = typeof chunk === 'string' ? Buffer.from(chunk, 'utf8') : chunk
      emit(text.toString('base64'), false)
    })
    let finished = false
    const finish = (exitCode?: number | null): void => {
      if (finished) return
      finished = true
      entry.exited = true
      for (const subscriber of entry.subscribers) subscriber({ data: '', exit: true, exitCode })
      entry.subscribers.clear()
    }
    // The seam resolves `done` with the exit outcome { exitCode, ... } when the
    // shell terminates — prefer that (it carries the code) over the bare
    // output-stream end/error events, which only say the PTY went away.
    void entry.handle.done
      .then((outcome: unknown) => { finish((outcome as { exitCode?: number | null } | undefined)?.exitCode ?? null) })
      .catch(() => finish(null))
    entry.handle.output.on('end', () => finish(null))
    entry.handle.output.on('error', () => finish(null))
  }

  /** Deliver one input chunk to the terminal. */
  async terminalWrite(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    terminalId: string,
    data: string,
    _signal: AbortSignal,
  ): Promise<void> {
    const entry = this.ownedTerminal(workspaceFileScope, terminalId)
    if (entry.exited) throw new RemoteError('ide-tools/terminal-exited', 'terminal ' + JSON.stringify(terminalId) + ' has exited', {})
    const text = Buffer.from(data, 'base64').toString('utf8')
    await entry.handle.write(text)
  }

  /** Signal the terminal's foreground process group (e.g. Ctrl+C as SIGINT). */
  async terminalSignal(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    terminalId: string,
    signalName: 'SIGINT' | 'SIGTERM' | 'SIGKILL' | 'SIGTSTP' | 'SIGHUP',
    _signal: AbortSignal,
  ): Promise<void> {
    const entry = this.ownedTerminal(workspaceFileScope, terminalId)
    await entry.handle.signalForeground(signalName)
  }

  /** Terminate the whole terminal session and drop it from the registry. */
  async terminalTerminate(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    terminalId: string,
    _signal: AbortSignal,
  ): Promise<void> {
    const entry = this.terminals.get(terminalId)
    // Idempotent: a missing (or someone else's) terminal is a no-op, matching
    // the previous "already gone" behaviour without letting a foreign Session
    // kill a shell it does not own.
    if (entry === undefined || entry.ownerSessionId !== workspaceFileScope.sessionId) return
    this.terminals.delete(terminalId)
    for (const subscriber of entry.subscribers) subscriber({ data: '', exit: true })
    entry.subscribers.clear()
    // Do NOT await the kill. A shell that ignores the signal (or a pty that
    // stays alive until its children exit) leaves terminate() pending, and the
    // caller's RPC would then never resolve — the tab only went away on a
    // second click. The registry entry is already dropped, so the kill is
    // allowed to finish in the background.
    void entry.handle.terminate().catch(() => undefined)
  }

  /** Resize one terminal's PTY so the shell's COLUMNS/LINES and cursor
   *  positioning match the xterm.js viewport after a fit. Without this the
   *  shell keeps rendering at the PTY's creation size (80×24) while xterm
   *  shows a different viewport, so prompt wrapping, line editing, and
   *  full-screen apps (vim, less) all misbehave. */
  async terminalResize(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    terminalId: string,
    cols: number,
    rows: number,
    _signal: AbortSignal,
  ): Promise<void> {
    const entry = this.ownedTerminal(workspaceFileScope, terminalId)
    const c = Math.max(2, Math.min(500, Math.round(cols)))
    const r = Math.max(2, Math.min(300, Math.round(rows)))
    await entry.handle.resize(c, r)
  }

  /** Stream one terminal's output: replay log first, then live frames. */
  async *terminalOutput(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    terminalId: string,
    signal: AbortSignal,
  ): AsyncGenerator<IdeTerminalOutputFrame, void, void> {
    const entry = this.ownedTerminal(workspaceFileScope, terminalId)
    // Reset the SGR state before replaying. A freshly attached xterm starts
    // with default attributes, but the replay log may begin in the middle of
    // a styled run (its head was trimmed, or the capture started after a
    // prompt was drawn). Without a reset a rich prompt (powerlevel10k,
    // oh-my-zsh) can leak its raw escape marker — the classic `%` — into the
    // first line. SGR-only (no clear) so scrollback is preserved.
    yield { data: Buffer.from('\x1b[0m', 'utf8').toString('base64'), exit: false }
    // Yield each log entry as a SEPARATE frame: joining base64 strings
    // concatenates padding chars (=) mid-string, yielding invalid base64.
    for (const entry2 of entry.log) yield { data: entry2, exit: false }
    // Marker: replay is done, live output follows. The client suppresses
    // onData echo-back during replay so DCS/CSI query responses in the log
    // never reach the shell as commands; this marker re-enables it.
    if (!entry.exited) yield { data: '', exit: false, replay: true }
    if (entry.exited) { yield { data: '', exit: true }; return }
    // Live phase: a queue fed by the pump, drained until exit or abort.
    const queue: IdeTerminalOutputFrame[] = []
    let resolve: (() => void) | undefined
    const subscriber = (frame: IdeTerminalOutputFrame): void => {
      queue.push(frame)
      resolve?.()
    }
    entry.subscribers.add(subscriber)
    const onAbort = (): void => { resolve?.() }
    signal.addEventListener('abort', onAbort, { once: true })
    try {
      for (;;) {
        while (queue.length > 0) {
          const frame = queue.shift()
          if (frame === undefined) break
          yield frame
          if (frame.exit) return
        }
        if (signal.aborted) return
        await new Promise<void>((r) => { resolve = r })
        resolve = undefined
      }
    } finally {
      entry.subscribers.delete(subscriber)
      signal.removeEventListener('abort', onAbort)
    }
  }

  // ── Git source control ───────────────────────────────────────────────
  // All git commands run as a foreground collect-mode spawn through the
  // subprocess seam (same primitive ripgrep uses), with a bounded stdout cap.
  // The seam owns process-tree termination on abort; we only parse the text.

  /** Cap git stdout at 8 MiB (covers large diffs; oversized output truncates
   *  to the tail with a spill file the client never reads here). */
  private static readonly GIT_STDOUT_MAX_BYTES = 8 * 1024 * 1024
  private static readonly GIT_STDERR_MAX_BYTES = 16 * 1024
  /** Hard ceiling for one git invocation. gitStatus runs on a 15 s client poll
   *  and every git call is serialized behind a single subprocess slot, so one
   *  hung command (a giant repo, an NFS workspace, a stale index.lock) used to
   *  wedge the whole SCM panel silently and forever — the promise never
   *  settled until the browser navigated away. */
  private static readonly GIT_TIMEOUT_MS = 20_000

  /** Run one git command in the workspace root, returning its stdout text.
   *  Throws a RemoteError (notARepo / failed) so the client can map the kind. */
  private async runGit(
    workspaceRoot: string,
    argv: readonly string[],
    signal: AbortSignal | undefined,
    /** Text piped to git's stdin (used by `git apply -`). Omitted = no stdin. */
    stdin?: string,
  ): Promise<string> {
    // stdin rides the seam's batch mode ({ data }): the bytes are written and
    // the stream closed by spawn itself. SubprocessHandle has no write()/end()
    // (only a raw stdin Writable), so the earlier manual-write block could never
    // deliver the patch and `git apply -` hung until the timeout.
    const spec = {
      argv: ['git', ...argv],
      cwd: workspaceRoot,
      stdio: {
        stdin: (stdin === undefined ? 'ignore' : { data: stdin }) as 'ignore' | { data: string },
        stdout: { maxBytes: IdeTools.GIT_STDOUT_MAX_BYTES },
        stderr: { maxBytes: IdeTools.GIT_STDERR_MAX_BYTES },
      },
      graceMs: 5000,
      signal,
    }
    let handle: import('@deepseek-ai/dsh-subprocess').SubprocessHandle
    try {
      handle = this.ctx.subprocess.spawn(spec as never)
    } catch {
      throw new RemoteError('ide-tools/git-failed', 'git command could not start', {})
    }
    let outcome: import('@deepseek-ai/dsh-subprocess').SubprocessOutcome
    // Race the process against a hard deadline. `terminate()` is best-effort:
    // an unkillable process must still not hang the caller, so the timeout
    // path reports a timeout error while the kill completes in the background.
    let timer: ReturnType<typeof setTimeout> | undefined
    const timeout = new Promise<never>((_resolve, reject) => {
      timer = setTimeout(() => {
        void Promise.resolve(handle.terminate?.()).catch(() => undefined)
        reject(new RemoteError('ide-tools/git-timeout', `git ${argv[0] ?? ''} did not finish within ${IdeTools.GIT_TIMEOUT_MS} ms`, {}))
      }, IdeTools.GIT_TIMEOUT_MS)
    })
    try {
      outcome = await Promise.race([handle.done, timeout])
    } catch (err) {
      if (err instanceof RemoteError) throw err
      // A user-driven abort (the client cancelled the call, e.g. by switching
      // branches mid-request) used to surface as a red "git failed ... aborted"
      // banner. Report the cancellation as such instead of a failure.
      if (signal?.aborted === true) {
        throw new RemoteError('ide-tools/aborted', 'git command was cancelled', {})
      }
      throw new RemoteError('ide-tools/git-failed', 'git process failed before reporting an outcome', {})
    } finally {
      if (timer !== undefined) clearTimeout(timer)
    }
    const stdout = handle.collected.stdout?.readFrom(0)
    const stderr = handle.collected.stderr?.readFrom(0)
    if (stdout === undefined) throw new RemoteError('ide-tools/git-failed', 'git produced no collected stdout', {})
    // Exit 128 with a "not a git repository" message → notARepo, not a failure.
    const stderrText = stderr?.text ?? ''
    if (outcome.exitCode === 128 && /not a git repository/i.test(stderrText)) {
      throw new RemoteError('ide-tools/not-a-repo', 'the workspace root is not a git repository', {})
    }
    if (outcome.signal !== null || outcome.exitCode === null) {
      throw new RemoteError('ide-tools/git-failed', 'git was killed by signal ' + (outcome.signal ?? '(unknown)'), {})
    }
    if (outcome.exitCode !== 0) {
      // Some git failures ("nothing to commit", "no changes added to commit")
      // print to STDOUT with an empty stderr — surface the stdout tail then, so
      // the real cause stays diagnosable and the commit flow's nothing-to-
      // commit detection can match on it.
      const detail = stderrText.trim().length > 0 ? stderrText.trim() : stdout.text.trim().slice(-2000)
      throw new RemoteError('ide-tools/git-failed', 'git exited with code ' + outcome.exitCode + ': ' + detail, {})
    }
    return stdout.text
  }

  /** Parse `git status --porcelain=v2 --branch --untracked-files=all --ignored=matching -z`
   *  output into a GitStatusResult.
   *
   *  With `-z` every record — branch headers included — is NUL-terminated, and
   *  the change records use spaces (not a tab) between their header fields and
   *  the path. The path is therefore the tail after the fixed header field
   *  count, joined back together because a path may itself contain spaces.
   *  A renamed/copied entry (`2 ...`) is followed by one extra NUL record
   *  holding the original path. */
  private parseGitStatusPorcelain(raw: string): Omit<GitStatusResult, 'notARepo'> {
    let branch: string | undefined
    let upstream: string | undefined
    let ahead = 0
    let behind = 0
    let detached = false
    let headSha: string | undefined
    const entries: GitStatusEntry[] = []
    const records = raw.split('\u0000')
    for (let i = 0; i < records.length; i++) {
      const record = records[i]
      if (record.length === 0) continue
      // Branch header records: "# branch.head main", "# branch.upstream
      // origin/main", "# branch.ab +0 -0", "# branch.oid <sha>"
      // (detached: branch.head = "(detached)").
      if (record.startsWith('#')) {
        if (record.startsWith('# branch.head ')) {
          const v = record.slice('# branch.head '.length)
          if (v === '(detached)') detached = true
          else branch = v
        } else if (record.startsWith('# branch.oid ')) {
          const oid = record.slice('# branch.oid '.length)
          // "(initial)" — an unborn repository has no commit yet.
          if (oid !== '(initial)') headSha = oid
        } else if (record.startsWith('# branch.upstream ')) {
          upstream = record.slice('# branch.upstream '.length)
        } else if (record.startsWith('# branch.ab ')) {
          const m = record.slice('# branch.ab '.length).match(/\+(\d+)\s+-(\d+)/)
          if (m) { ahead = parseInt(m[1], 10); behind = parseInt(m[2], 10) }
        }
        continue
      }
      // Change records: "1 <XY> <sub> <mH> <mI> <mW> <hH> <hI> <path>",
      // "2 <XY> <sub> <mH> <mI> <mW> <hH> <hI> <X><score> <path>", or
      // "u <XY> <sub> <m1> <m2> <m3> <mW> <h1> <h2> <h3> <path>";
      // "? <path>" (untracked) and "! <path>" (ignored).
      const first = record[0]
      if (first === '?') {
        const path = record.slice(2)
        if (path.length > 0) entries.push({ path, statusCode: '??', kind: 'untracked' })
        continue
      }
      if (first === '!') {
        // Ignored path. VS Code decorates these with the muted "ignored"
        // foreground instead of hiding them; keep them so the explorer can.
        // An ignored DIRECTORY is reported with a trailing slash
        // ("! lib/"); strip it so the path matches the tree's node path.
        const path = record.slice(2).replace(/\/+$/, '')
        if (path.length > 0) entries.push({ path, statusCode: '!!', kind: 'ignored' })
        continue
      }
      if (first !== '1' && first !== '2' && first !== 'u') continue
      const fields = record.split(' ')
      const xy = fields[1] ?? '  '
      // 1: "1" + XY/sub/mH/mI/mW/hH/hI (8 tokens) before the path.
      // 2: the same 8 plus <X><score> (9 tokens).
      // u: "u" + XY/sub/m1/m2/m3/mW/h1/h2/h3 (10 tokens).
      const headerFieldCount = first === '1' ? 8 : first === '2' ? 9 : 10
      const path = fields.slice(headerFieldCount).join(' ')
      if (first === '2') {
        // The original path trails the entry as its own NUL-terminated record.
        const oldPath = records[i + 1] ?? ''
        i++
        entries.push({ path, oldPath, statusCode: xy, kind: this.xyToKind(xy) })
      } else {
        entries.push({ path, statusCode: xy, kind: first === 'u' ? 'conflicted' : this.xyToKind(xy) })
      }
    }
    return {
      branch,
      upstream,
      ahead,
      behind,
      detached,
      entries,
      clean: entries.length === 0,
      headSha,
    }
  }

  /** True when the repository has at least one commit (HEAD resolves).
   *
   *  An unborn repository (`git init`, nothing committed yet) rejects plan
   *  operations that name HEAD — `reset HEAD`, `reset --hard HEAD`,
   *  `checkout -- <path>` all fail with "ambiguous argument 'HEAD'" or
   *  "pathspec did not match". Callers branch on this instead of guessing.
   *  A `rev-parse` probe is used rather than the status snapshot because the
   *  index itself may be empty while HEAD exists (a fully-staged-then-reset
   *  tree), and vice versa. */
  private async hasHeadCommit(cwd: string, signal: AbortSignal | undefined): Promise<boolean> {
    try {
      await this.runGit(cwd, ['rev-parse', '--quiet', '--verify', 'HEAD'], signal)
      return true
    } catch {
      return false
    }
  }

  /** Map a porcelain v2 XY status code to a human kind. */
  private xyToKind(xy: string): GitStatusEntry['kind'] {
    const x = xy[0] ?? ' '
    const y = xy[1] ?? ' '
    if (x === 'A' || y === 'A') return 'added'
    if (x === 'D' || y === 'D') return 'deleted'
    // 'C' (copied) shares the renamed treatment.
    if (x === 'R' || y === 'R' || x === 'C' || y === 'C') return 'renamed'
    if (x === 'M' || y === 'M' || x === 'T' || y === 'T') return 'modified'
    if (x === 'U' || y === 'U') return 'conflicted'
    return 'modified'
  }

  /** Snapshot the workspace's git status (branch, ahead/behind, changed files). */
  async gitStatus(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    signal: AbortSignal | undefined,
  ): Promise<GitStatusResult> {
    const { workspaceRoot: cwd } = workspaceFileScope
    const EMPTY: GitStatusResult = {
      notARepo: true, branch: undefined, upstream: undefined, ahead: 0, behind: 0,
      detached: false, entries: [], clean: true,
    }
    // Our own git command touches .git/index, so suspend the watcher for its
    // duration: otherwise every status fetch schedules the next one.
    if (cwd) pauseGitWatch(cwd)
    try {
      if (!cwd) return { ...EMPTY, notARepo: false }
      // --ignored=matching surfaces the '!' records so the explorer can paint
      // .gitignore'd paths in the muted tone, exactly like VS Code's
      // GitIgnoreDecorationProvider (gitDecoration.ignoredResourceForeground).
      const raw = await this.runGit(cwd, ['status', '--porcelain=v2', '--branch', '--untracked-files=all', '--ignored=matching', '-z'], signal)
      // The parser owns the NUL-record framing for both branch headers and
      // change entries (including a rename's trailing original-path record).
      const parsed = this.parseGitStatusPorcelain(raw)
      return { notARepo: false, ...parsed }
    } catch (err) {
      if (err instanceof RemoteError && err.code === 'ide-tools/not-a-repo') return EMPTY
      throw err
    } finally {
      if (cwd) resumeGitWatch(cwd)
    }
  }

  /**
   * Long-poll for a workspace change that could affect git status.
   *
   * The RPC layer is request/response only, so the file watcher is exposed as a
   * long-poll: it resolves the moment a debounced file event lands, or after
   * `timeoutMs` with the unchanged version. The client loops on it while the
   * IDE is on screen, which reproduces VS Code's event-driven rescans without
   * adding a push transport.
   */
  async gitWaitChanged(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    options: { since: number; timeoutMs?: number },
    signal: AbortSignal | undefined,
  ): Promise<{ version: number }> {
    const root = workspaceFileScope.workspaceRoot
    if (!root) return { version: options.since }
    // Clamp the wait: a shorter poll keeps aborts responsive, a longer one
    // saves requests. 25s sits under every common proxy idle timeout.
    const timeout = Math.min(Math.max(options.timeoutMs ?? 25000, 1000), 60000)
    const version = await waitForGitChange(root, options.since, timeout, signal)
    return { version }
  }

  /** List local branches with ahead/behind and last-commit metadata. */
  async gitBranches(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    signal: AbortSignal | undefined,
  ): Promise<GitBranchesResult> {
    const { workspaceRoot: cwd } = workspaceFileScope
    const EMPTY: GitBranchesResult = { notARepo: true, branches: [], current: undefined }
    try {
      // %00 delim: refname, upstream, ahead, behind, objectname, committerdate, HEAD
      // %(upstream:track,nobracket) → "ahead N, behind M" (no brackets) or empty;
      // plain 'track' + 'normalspace' is not a valid atom on any git release.
      const fmt = '%(refname:short)%00%(upstream:short)%00%(upstream:track,nobracket)%00%(objectname:short)%00%(committerdate:short)%00%(HEAD)%00'
      if (!cwd) return EMPTY
      const raw = await this.runGit(cwd, ['for-each-ref', '--format=' + fmt, 'refs/heads'], signal)
      const branches: GitBranch[] = []
      let current: string | undefined
      if (raw.length > 0) {
        for (const line of raw.split('\n')) {
          if (line.length === 0) continue
          const [name, up, track, sha, date, head] = line.split('\u0000')
          let ahead: number | undefined
          let behind: number | undefined
          if (track && track.length > 0) {
            const am = track.match(/ahead (\d+)/)
            const bm = track.match(/behind (\d+)/)
            if (am) ahead = parseInt(am[1], 10)
            if (bm) behind = parseInt(bm[1], 10)
          }
          const isCurrent = head === '*'
          if (isCurrent) current = name
          branches.push({
            name, current: isCurrent,
            upstream: up && up.length > 0 ? up : undefined,
            ahead, behind,
            lastCommit: sha,
            lastCommitDate: date,
          })
        }
      }
      // Remote-tracking branches (refs/remotes, minus each remote's HEAD
      // symref) plus the configured remote names — the branches view lists
      // both. Best effort: a repo without remotes still lists local branches.
      let remoteBranches: GitRemoteBranch[] | undefined
      let remotes: string[] | undefined
      try {
        // %(refname:short) collapses refs/remotes/<remote>/HEAD to just "<remote>",
        // so the HEAD symref is filtered on the FULL refname, not the short form.
        const remoteFmt = '%(refname)%00%(refname:short)%00%(objectname:short)%00%(committerdate:short)%00'
        const remoteRaw = await this.runGit(cwd, ['for-each-ref', '--format=' + remoteFmt, 'refs/remotes'], signal)
        remotes = (await this.runGit(cwd, ['remote'], signal)).split('\n').map((r) => r.trim()).filter((r) => r.length > 0)
        remoteBranches = []
        for (const line of remoteRaw.split('\n')) {
          if (line.length === 0) continue
          const [full, name, sha, date] = line.split('\u0000')
          if (full.endsWith('/HEAD')) continue
          remoteBranches.push({ name, lastCommit: sha, lastCommitDate: date })
        }
      } catch { /* no remotes configured */ }
      return { notARepo: false, branches, remoteBranches, remotes, current }
    } catch (err) {
      if (err instanceof RemoteError && err.code === 'ide-tools/not-a-repo') return EMPTY
      throw err
    }
  }

  // ── Git graph (VS Code Source Control Graph parity) ──────────────────
  // The history provider feeds the swimlane graph: git log pages with
  // decorations parsed into typed refs, plus the per-commit actions the
  // graph's context menu exposes (checkout / create branch / fetch ...).

  /** Refuse ref-ish arguments that git could parse as its own options. */
  private static assertGitRevision(rev: string, label: string): void {
    if (rev.length === 0 || rev.startsWith('-')) {
      throw new RemoteError('ide-tools/bad-request', 'invalid ' + label, {})
    }
  }

  /** A repo-relative path passed to git must be plain: no leading dash
   *  (option injection), no traversal, no absolute or backslash form. */
  private static assertGitPath(rel: string, label: string): void {
    const bad = rel.length === 0 || rel.startsWith('-')
      || rel.split('/').includes('..')
      || rel.startsWith('/') || rel.includes('\\')
    if (bad) throw new RemoteError('ide-tools/bad-request', 'invalid ' + label, {})
  }

  /** Strip a --decorate=full full-ref prefix down to the short name. */
  private gitRefShortName(fullname: string): string {
    for (const prefix of ['refs/heads/', 'refs/remotes/', 'refs/tags/']) {
      if (fullname.startsWith(prefix)) return fullname.slice(prefix.length)
    }
    return fullname
  }

  /** Parse git log --decorate=full %D into typed graph refs. */
  private parseGitLogDecorations(decorations: string): GitLogRef[] {
    const refs: GitLogRef[] = []
    if (decorations.length === 0) return refs
    for (const part of decorations.split(', ')) {
      if (part.startsWith('HEAD -> ')) {
        // The checked-out branch: e.g. "HEAD -> refs/heads/main".
        const name = this.gitRefShortName(part.slice('HEAD -> '.length))
        if (name.length > 0) refs.push({ name, type: 'head', current: true })
        continue
      }
      if (part === 'HEAD') continue
      if (part.startsWith('tag: ')) {
        const name = this.gitRefShortName(part.slice('tag: '.length))
        if (name.length > 0) refs.push({ name, type: 'tag', current: false })
        continue
      }
      if (part.startsWith('refs/heads/')) {
        refs.push({ name: part.slice('refs/heads/'.length), type: 'head', current: false })
      } else if (part.startsWith('refs/remotes/')) {
        const name = part.slice('refs/remotes/'.length)
        if (name.endsWith('/HEAD')) continue // remote HEAD symref, not a branch
        refs.push({ name, type: 'remote', current: false })
      }
      // Other namespaces (refs/stash ...) are not surfaced in the graph.
    }
    return refs
  }

  /** One page of the commit history for the SCM graph (VS Code's history
   *  provider): git log --topo-order --decorate=full -z with NUL-separated
   *  records, so multi-line data can never split a page. scope: 'current' =
   *  HEAD history, 'all' = every ref, 'branch' = one named ref. */
  async gitLog(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    options: { limit?: number; skip?: number; scope?: 'current' | 'all' | 'branch'; ref?: string },
    signal: AbortSignal | undefined,
  ): Promise<GitLogResult> {
    const { workspaceRoot: cwd } = workspaceFileScope
    const EMPTY: GitLogResult = {
      notARepo: true, commits: [], hasMore: false,
      head: undefined, currentBranch: undefined, upstream: undefined, detached: false,
    }
    try {
      if (!cwd) return EMPTY
      const limit = Math.max(1, Math.min(500, Math.round(options?.limit ?? 100)))
      const skip = Math.max(0, Math.round(options?.skip ?? 0))
      const scope = options?.scope ?? 'current'
      // Unborn repository (no commits yet): rev-parse --quiet --verify HEAD
      // exits 1 with no output — treat that as "no history", not an error
      // (runGit throws on any non-zero exit; the .catch maps it to empty).
      const head = await this.runGit(cwd, ['rev-parse', '--quiet', '--verify', 'HEAD'], signal)
        .then((s) => s.trim())
        .catch(() => '')
      if (head.length === 0) return { ...EMPTY, notARepo: false }
      const argv = [
        '-c', 'i18n.logOutputEncoding=UTF-8',
        'log', '--format=%H%x1f%h%x1f%aN%x1f%aE%x1f%at%x1f%P%x1f%D%x1f%s',
        '-z', '--topo-order', '--decorate=full',
        '-n', String(limit + 1), '--skip', String(skip),
      ]
      if (scope === 'all') argv.push('--all')
      if (scope === 'branch') {
        const ref = options?.ref ?? ''
        IdeTools.assertGitRevision(ref, 'branch name')
        argv.push(ref)
      }
      const raw = await this.runGit(cwd, argv, signal)
      const commits: GitLogEntry[] = []
      let hasMore = false
      for (const record of raw.split('\u0000')) {
        if (record.length === 0) continue
        if (commits.length === limit) { hasMore = true; break }
        const [hash, displayId, author, authorEmail, authorDate, parents, decorations, subject] = record.split('\u001f')
        commits.push({
          hash, displayId,
          parents: parents.length > 0 ? parents.split(' ') : [],
          author, authorEmail,
          authorDate: Number(authorDate) || 0,
          subject: subject ?? '',
          refs: this.parseGitLogDecorations(decorations ?? ''),
        })
      }
      const [currentBranch, upstream] = await Promise.all([
        this.runGit(cwd, ['branch', '--show-current'], signal).then((s) => s.trim()).catch(() => ''),
        this.runGit(cwd, ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}'], signal).then((s) => s.trim()).catch(() => ''),
      ])
      return {
        notARepo: false,
        commits, hasMore, head,
        currentBranch: currentBranch.length > 0 ? currentBranch : undefined,
        upstream: upstream.length > 0 ? upstream : undefined,
        detached: currentBranch.length === 0,
      }
    } catch (err) {
      if (err instanceof RemoteError && err.code === 'ide-tools/not-a-repo') return EMPTY
      throw err
    }
  }


  /** Per-file commit history for the Timeline panel (VS Code's
   *  extensions/git/src/timelineProvider.ts): git log --follow, newest first.
   *  Directories are NOT followed through renames (matching VS Code, which
   *  only sets follow for files). */
  async gitTimeline(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    path: string,
    options: { limit?: number; skip?: number },
    signal: AbortSignal | undefined,
  ): Promise<GitTimelineResult> {
    const { workspaceRoot: cwd } = workspaceFileScope
    const EMPTY: GitTimelineResult = { notARepo: true, entries: [] }
    try {
      if (!cwd) return EMPTY
      const rel = path.replace(/^[/\\]+/, '')
      if (rel.length === 0) return { ...EMPTY, notARepo: false }
      IdeTools.assertGitPath(rel, 'timeline path')
      const limit = Math.max(1, Math.min(500, Math.round(options?.limit ?? 50)))
      const skip = Math.max(0, Math.round(options?.skip ?? 0))
      const head = await this.runGit(cwd, ['rev-parse', '--quiet', '--verify', 'HEAD'], signal)
        .then((s) => s.trim())
        .catch(() => '')
      if (head.length === 0) return { ...EMPTY, notARepo: false }
      // %H hash, %h short, %aN author, %at author-date (unix), %s subject.
      // --topo-order matches the SCM graph; --follow only applies to files
      // (VS Code's provider does the same and drops it for folders).
      const argv = [
        '-c', 'i18n.logOutputEncoding=UTF-8',
        'log', '--format=%H%x1f%h%x1f%aN%x1f%at%x1f%s',
        '-z', '--topo-order',
        '-n', String(limit + 1), '--skip', String(skip),
        '--follow', '--', rel,
      ]
      const raw = await this.runGit(cwd, argv, signal)
      const entries: GitTimelineEntry[] = []
      for (const record of raw.split('\u0000')) {
        if (record.length === 0) continue
        if (entries.length === limit) break
        const [hash, displayId, author, authorDate, subject] = record.split('\u001f')
        entries.push({
          hash, displayId,
          author: author ?? '',
          authorDate: Number(authorDate) || 0,
          subject: subject ?? '',
        })
      }
      return { notARepo: false, entries }
    } catch (err) {
      if (err instanceof RemoteError && err.code === 'ide-tools/not-a-repo') return EMPTY
      throw err
    }
  }

  /** One commit's metadata + changed files (VS Code's commit details view).
   *  Merge commits diff against their FIRST parent; root commits diff
   *  against the empty tree (git diff-tree --root). */
  async gitCommitDetails(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    sha: string,
    signal: AbortSignal | undefined,
  ): Promise<GitCommitDetailsResult> {
    const { workspaceRoot: cwd } = workspaceFileScope
    IdeTools.assertGitRevision(sha, 'commit hash')
    if (!/^[0-9a-fA-F]{4,40}$/.test(sha)) throw new RemoteError('ide-tools/bad-request', 'invalid commit hash', {})
    const meta = (
      await this.runGit(cwd, ['show', '-s', '--format=%H%x1f%h%x1f%aN%x1f%aE%x1f%at%x1f%P%x1f%D', sha], signal)
    ).trimEnd()
    const [hash, displayId, author, authorEmail, authorDate, parentsRaw, decorations] = meta.split('\u001f')
    const parents = parentsRaw.length > 0 ? parentsRaw.split(' ') : []
    const message = (await this.runGit(cwd, ['show', '-s', '--format=%B', sha], signal)).trimEnd()
    const files = await this.commitChangedFiles(cwd, sha, parents[0], signal)
    return {
      hash, displayId, author, authorEmail,
      authorDate: Number(authorDate) || 0,
      subject: message.split('\n', 1)[0] ?? '',
      message,
      parents,
      refs: this.parseGitLogDecorations(decorations ?? ''),
      files,
    }
  }

  /** Changed files of one commit: name-status (kinds + renames, -z) joined
   *  with numstat (line counts) keyed by the new path. */
  private async commitChangedFiles(
    cwd: string,
    sha: string,
    firstParent: string | undefined,
    signal: AbortSignal | undefined,
  ): Promise<GitCommitFile[]> {
    const nameArgs = firstParent !== undefined
      ? ['diff-tree', '-M', '--no-commit-id', '--name-status', '-r', '-z', firstParent, sha]
      : ['diff-tree', '-M', '--no-commit-id', '--name-status', '-r', '-z', '--root', sha]
    const raw = await this.runGit(cwd, nameArgs, signal)
    const counts = new Map<string, { additions?: number; deletions?: number; binary: boolean }>()
    try {
      const numArgs = firstParent !== undefined
        ? ['diff-tree', '-M', '--no-commit-id', '--numstat', '-r', firstParent, sha]
        : ['diff-tree', '-M', '--no-commit-id', '--numstat', '-r', '--root', sha]
      const numRaw = await this.runGit(cwd, numArgs, signal)
      for (const line of numRaw.split('\n')) {
        if (line.length === 0) continue
        const tab = line.indexOf('\t')
        const tab2 = line.indexOf('\t', tab + 1)
        if (tab < 0 || tab2 < 0) continue
        const adds = line.slice(0, tab)
        const dels = line.slice(tab + 1, tab2)
        const path = this.numstatNewPath(line.slice(tab2 + 1))
        if (path === undefined) continue
        counts.set(path, adds === '-' || dels === '-'
          ? { binary: true }
          : { additions: Number(adds) || 0, deletions: Number(dels) || 0, binary: false })
      }
    } catch { /* counts are optional decoration */ }

    // -z name-status records: <status> NUL <path> [NUL <origPath>] NUL ...
    // (the rename pair is printed src first, then dst — verified against
    // git 2.x diff-tree -z --name-status).
    const files: GitCommitFile[] = []
    const fields = raw.split('\u0000')
    for (let i = 0; i < fields.length; i++) {
      const status = fields[i]
      if (status.length === 0) continue
      const letter = status[0]
      const count = (newPath: string) => {
        const c = counts.get(newPath)
        return {
          additions: c?.binary === true ? undefined : c?.additions,
          deletions: c?.binary === true ? undefined : c?.deletions,
        }
      }
      if (letter === 'R' || letter === 'C') {
        const oldPath = fields[++i] ?? ''
        const path = fields[++i] ?? ''
        if (path.length === 0) continue
        files.push({ path, oldPath: oldPath.length > 0 ? oldPath : undefined, kind: 'renamed', ...count(path) })
        continue
      }
      const path = fields[++i] ?? ''
      if (path.length === 0) continue
      // Binary first: a binary add/delete must badge as binary, not added.
      const kind: GitCommitFile['kind'] = counts.get(path)?.binary === true ? 'binary'
        : letter === 'A' ? 'added'
        : letter === 'D' ? 'deleted'
        : 'modified'
      files.push({ path, kind, ...count(path) })
    }
    return files
  }

  /** The new-path side of a numstat rename field ('old => new', or git's
   *  braces form '{pre/old => post}/suffix'). */
  private numstatNewPath(field: string): string | undefined {
    if (!field.includes(' => ')) return field
    const brace = field.match(/^(.*)\{(.*) => (.*)\}(.*)$/)
    if (brace) return brace[1] + brace[3] + brace[4]
    const arrow = field.split(' => ')
    return arrow[arrow.length - 1]
  }

  /** Old/new content + patch of ONE file inside one commit (graph commit
   *  details -> per-file diff). Same base rules as gitCommitDetails; the new
   *  side is the COMMIT's blob — never the working tree. */
  async gitCommitFileDiff(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    sha: string,
    path: string,
    oldPath: string | undefined,
    signal: AbortSignal | undefined,
  ): Promise<GitDiffResult> {
    const { workspaceRoot: cwd } = workspaceFileScope
    IdeTools.assertGitRevision(sha, 'commit hash')
    if (!/^[0-9a-fA-F]{4,40}$/.test(sha)) throw new RemoteError('ide-tools/bad-request', 'invalid commit hash', {})
    if (path.length === 0) throw new RemoteError('ide-tools/bad-request', 'path is empty', {})
    const language = this.detectLanguage(path)
    const parentsRaw = (await this.runGit(cwd, ['show', '-s', '--format=%P', sha], signal)).trim()
    const firstParent = parentsRaw.split(' ')[0] ?? ''
    const target = oldPath !== undefined && oldPath.length > 0 && oldPath !== path ? [oldPath, path] : [path]
    const diffArgv = firstParent.length > 0
      ? ['diff', '-M', firstParent, sha, '--', ...target]
      : ['diff-tree', '-p', '-M', '--root', '--no-commit-id', sha, '--', ...target]
    let diff = ''
    try { diff = await this.runGit(cwd, diffArgv, signal) } catch { /* e.g. file untouched by a merge */ }
    // Old side: the first parent's blob (empty for root commits / adds).
    let oldContent = ''
    if (firstParent.length > 0) {
      try { oldContent = await this.runGit(cwd, ['show', firstParent + ':' + (oldPath ?? path)], signal) } catch { /* added */ }
    }
    // New side: the commit's blob (empty for deletions).
    let newContent = ''
    try { newContent = await this.runGit(cwd, ['show', sha + ':' + path], signal) } catch { /* deleted */ }
    // Binary blobs do not survive the text subprocess seam (lossy utf8 decode).
    // git numstat prints '-' for binary counts — flag the result so the
    // client renders a placeholder instead of garbled utf8-decoded bytes.
    try {
      const numArgs = firstParent.length > 0
        ? ['diff-tree', '-M', '--no-commit-id', '--numstat', '-r', firstParent, sha, '--', oldPath ?? path]
        : ['diff-tree', '-M', '--no-commit-id', '--numstat', '-r', '--root', sha, '--', oldPath ?? path]
      const numstat = (await this.runGit(cwd, numArgs, signal)).trim()
      if (/^-\t-\t/m.test(numstat)) {
        return {
          empty: false, diff: '', oldContent: '', newContent: path,
          oldPath: oldPath ?? path, newPath: path, language, contentType: 'binary',
        }
      }
    } catch { /* fall through to the text path */ }
    const isEmpty = diff.trim().length === 0 && oldContent === newContent
    return { empty: isEmpty, diff, oldContent, newContent, oldPath: oldPath ?? path, newPath: path, language }
  }

  /** Check out a branch, a remote branch (creating the local tracking branch
   *  via -b), or a detached commit (graph + branches views). */
  async gitCheckout(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    spec: { ref: string; localName?: string; detach?: boolean },
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot: cwd } = workspaceFileScope
    const ref = spec?.ref ?? ''
    IdeTools.assertGitRevision(ref, 'branch name')
    try {
      if (spec?.detach === true) {
        await this.runGit(cwd, ['checkout', '-q', '--detach', ref], signal)
      } else if (spec?.localName !== undefined && spec.localName.length > 0) {
        const local = spec.localName
        if (local.startsWith('-')) throw new RemoteError('ide-tools/bad-request', 'invalid branch name', {})
        await this.runGit(cwd, ['checkout', '-q', '-b', local, ref], signal)
      } else {
        await this.runGit(cwd, ['checkout', '-q', ref], signal)
      }
    } catch (err) {
      if (err instanceof RemoteError) throw err
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/git-checkout-failed', message, {})
    }
  }

  /** Create a branch at HEAD (or an explicit revision), optionally checking
   *  it out (branches view + graph context menu -> Create Branch). */
  async gitCreateBranch(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    name: string,
    revision: string | undefined,
    checkout: boolean | undefined,
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot: cwd } = workspaceFileScope
    if (name.length === 0 || name.startsWith('-')) {
      throw new RemoteError('ide-tools/bad-request', 'invalid branch name', {})
    }
    if (revision !== undefined && revision.length > 0) IdeTools.assertGitRevision(revision, 'revision')
    try {
      const rev = revision !== undefined && revision.length > 0 ? [revision] : []
      await this.runGit(cwd, checkout === true ? ['checkout', '-q', '-b', name, ...rev] : ['branch', name, ...rev], signal)
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/git-branch-failed', message, {})
    }
  }

  /** Delete a LOCAL branch (-d, or -D when force). Remote branches are never
   *  touched from the UI. */
  async gitDeleteBranch(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    name: string,
    force: boolean | undefined,
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot: cwd } = workspaceFileScope
    if (name.length === 0 || name.startsWith('-')) {
      throw new RemoteError('ide-tools/bad-request', 'invalid branch name', {})
    }
    try {
      await this.runGit(cwd, ['branch', force === true ? '-D' : '-d', name], signal)
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/git-branch-failed', message, {})
    }
  }

  /** Fetch remotes with prune (graph + branches toolbar -> Fetch). Prefers
   *  'origin'; falls back to --all when origin is not configured. */
  async gitFetch(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot: cwd } = workspaceFileScope
    try {
      const remotes = (await this.runGit(cwd, ['remote'], signal)).split('\n').map((r) => r.trim()).filter((r) => r.length > 0)
      if (remotes.length === 0) {
        throw new RemoteError('ide-tools/git-fetch-failed', 'your repository has no remotes configured', {})
      }
      if (remotes.includes('origin')) {
        await this.runGit(cwd, ['fetch', '--prune', 'origin'], signal)
      } else {
        await this.runGit(cwd, ['fetch', '--all', '--prune'], signal)
      }
    } catch (err) {
      if (err instanceof RemoteError) throw err
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/git-fetch-failed', message, {})
    }
  }

  /** Fetch a unified diff (and old/new content) for one path. */
  async gitDiff(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    path: string,
    kind: 'unstaged' | 'staged' | 'head',
    signal: AbortSignal | undefined,
  ): Promise<GitDiffResult> {
    const { workspaceRoot: cwd } = workspaceFileScope
    const language = this.detectLanguage(path)
    // Detect image file
    const ext = path.slice(path.lastIndexOf('.') + 1).toLowerCase()
    const isImage = ['png','jpg','jpeg','gif','webp','bmp','ico','svg'].includes(ext)
    if (isImage && cwd) {
      // For image files, read the working-tree file from disk and return it as
      // base64 (covers staged clicks too — the worktree copy is normally the
      // staged blob; git blobs cannot cross the text subprocess seam).
      let inHead = true
      try { await this.runGit(cwd, ['cat-file', '-e', 'HEAD:' + path], signal) } catch { inHead = false }
      let imageBase64 = ''
      try {
        // Raw fs read (not a git pathspec), so it must clear the workspace
        // fence — including symlinks that resolve outside it.
        const buf = await readFile(await resolveWorkspacePathReal(cwd, path))
        const mime = ext === 'svg' ? 'image/svg+xml' : 'image/' + ext
        imageBase64 = 'data:' + mime + ';base64,' + buf.toString('base64')
      } catch { /* deleted from the worktree / path escapes the workspace */ }
      if (imageBase64.length === 0) {
        // A missing worktree copy on a tracked image is a DELETION change —
        // an "empty diff" tile would claim nothing changed. The blob cannot
        // cross the text subprocess seam, so flag it binary and let the
        // client show the placeholder (mirrors gitCommitFileDiff).
        if (inHead) {
          return { empty: false, diff: '', oldContent: '', newContent: path, oldPath: path, newPath: path, language, contentType: 'binary' }
        }
        return { empty: true, diff: '', oldContent: '', newContent: '', oldPath: path, newPath: path, language, contentType: 'image' }
      }
      return {
        empty: false,
        diff: '',
        oldContent: '',
        newContent: '',
        oldPath: path,
        newPath: path,
        language,
        contentType: 'image',
        imageBase64,
      }
    }
    // Pick the diff scope:
    //  unstaged → git diff -- <path>            (worktree vs index)
    //  staged   → git diff --cached -- <path>   (index vs HEAD)
    //  head     → git diff HEAD -- <path>       (worktree vs HEAD, staged+unstaged)
    // Unborn repository (no commits yet): `git diff HEAD` exits 128 with
    // "fatal: bad revision 'HEAD'". Probe once (kind 'head' only) and fall
    // back to a plain diff: oldContent reads HEAD:path in a try/catch
    // (stays ''), the right side still comes from disk, so new files render.
    let hasHead = true
    if (kind === 'head' && cwd) {
      hasHead = await this.runGit(cwd, ['rev-parse', '--quiet', '--verify', 'HEAD'], signal).then(() => true, () => false)
    }
    const diffArgv: string[] = ['diff']
    if (kind === 'staged') diffArgv.push('--cached')
    else if (kind === 'head' && hasHead) diffArgv.push('HEAD')
    diffArgv.push('--', path)
    try {
      if (!cwd) return { empty: true, diff: '', oldContent: '', newContent: '', oldPath: path, newPath: path, language }
      const diff = await this.runGit(cwd, diffArgv, signal)
      // Binary blobs do not survive the text subprocess seam (lossy utf8
      // decode). git numstat prints '-' for binary counts — flag the result
      // so the client renders a placeholder instead of garbled bytes
      // (mirrors gitCommitFileDiff).
      try {
        const numstatArgv: string[] = ['diff']
        if (kind === 'staged') numstatArgv.push('--cached')
        else if (kind === 'head' && hasHead) numstatArgv.push('HEAD')
        numstatArgv.push('--numstat', '--', path)
        const numstat = (await this.runGit(cwd, numstatArgv, signal)).trim()
        if (/^-\t-\t/m.test(numstat)) {
          return { empty: false, diff: '', oldContent: '', newContent: path, oldPath: path, newPath: path, language, contentType: 'binary' }
        }
      } catch { /* fall through to the text path */ }
      if (kind === 'staged') {
        // Staged diff (VS Code's "Staged Changes" click): index vs HEAD. Both
        // sides come from git objects — the working tree is never consulted
        // (unstaged edits on top must not leak into the staged view).
        let oldContent = ''
        try {
          oldContent = await this.runGit(cwd, ['show', 'HEAD:' + path], signal)
        } catch { /* not in HEAD (a staged new file) */ }
        let newContent = ''
        try {
          newContent = await this.runGit(cwd, ['show', ':' + path], signal)
        } catch { /* not in the index (should not happen for a staged path) */ }
        const isEmpty = diff.trim().length === 0 && oldContent === newContent
        return {
          empty: isEmpty,
          diff,
          oldContent,
          newContent,
          oldPath: path,
          newPath: path,
          language,
        }
      }
      // Left side: the committed (HEAD) version for 'head' — empty for a
      // new/untracked file. For 'unstaged' the INDEX blob (:path): that diff
      // is index↔worktree, so a partially staged file must show its staged
      // content on the left, not the HEAD version.
      let oldContent = ''
      try {
        oldContent = await this.runGit(cwd, kind === 'unstaged' ? ['show', ':' + path] : ['show', 'HEAD:' + path], signal)
      } catch {
        // The blob does not exist on that side (added/untracked) — oldContent stays ''.
      }
      // Right side: the WORKING-TREE file. An unstaged edit leaves the index at
      // the HEAD blob, so reading ':path' here produced two identical sides and
      // a diff with no visible changes. Reading the file from disk shows the
      // actual uncommitted content (staged + unstaged) against HEAD.
      let newContent = ''
      try {
        // git's own pathspecs are repo-bounded, but this is a raw fs read,
        // so it must clear the workspace fence — symlinks included.
        const buf = await readFile(await resolveWorkspacePathReal(cwd, path))
        newContent = buf.toString('utf8')
      } catch {
        // The file is gone from the working tree (deleted) or the path
        // escapes the workspace — newContent stays ''.
      }
      // A diff is "empty" only when there is genuinely nothing to show: no
      // diff text AND old/new content are identical (or both absent). An
      // untracked file has empty diff text but non-empty newContent — it
      // must NOT be flagged empty so the DiffEditor renders it.
      const isEmpty = diff.trim().length === 0 && oldContent === newContent
      return {
        empty: isEmpty,
        diff,
        oldContent,
        newContent,
        oldPath: path,
        newPath: path,
        language,
      }
    } catch (err) {
      if (err instanceof RemoteError && err.code === 'ide-tools/not-a-repo') {
        return { empty: true, diff: '', oldContent: '', newContent: '', oldPath: path, newPath: path, language }
      }
      throw err
    }
  }

  /** Minimal language id by extension (mirrors the client's detectLanguage
   *  for the diff result's Monaco model). */
  private detectLanguage(path: string): string {
    const ext = path.slice(path.lastIndexOf('.') + 1).toLowerCase()
    const map: Record<string, string> = {
      ts: 'typescript', tsx: 'typescript', js: 'javascript', jsx: 'javascript',
      json: 'json', css: 'css', scss: 'scss', less: 'less',
      html: 'html', htm: 'html', xml: 'xml', svg: 'xml',
      md: 'markdown', markdown: 'markdown',
      py: 'python', rb: 'ruby', go: 'go', rs: 'rust', java: 'java',
      c: 'c', h: 'c', cpp: 'cpp', cc: 'cpp', hpp: 'cpp',
      sh: 'shell', bash: 'shell', zsh: 'shell',
      yml: 'yaml', yaml: 'yaml', toml: 'ini', ini: 'ini',
      sql: 'sql', dockerfile: 'dockerfile', makefile: 'makefile',
    }
    return map[ext] ?? 'plaintext'
  }

  /** Stage all changes (git add -A) in the workspace root. Throws a
   *  RemoteError on failure — the wire layer maps it to the client's error
   *  branch, so host methods return PLAIN business values (the transport
   *  always wraps them into { ok, value } itself). */
  async gitStageAll(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot: cwd } = workspaceFileScope
    if (!cwd) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
    try {
      await this.runGit(cwd, ['add', '-A'], signal)
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/git-stage-failed', message, {})
    }
  }

  /** Stage one path (git add -- path). Untracked files become staged adds. */
  async gitStage(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    path: string,
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot: cwd } = workspaceFileScope
    if (!cwd) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
    if (path.length === 0) throw new RemoteError('ide-tools/bad-request', 'path is empty', {})
    try {
      await this.runGit(cwd, ['add', '--', path], signal)
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/git-stage-failed', message, {})
    }
  }

  /**
   * Stage PART of a file (VS Code "Stage Selected Ranges" / "Stage Change").
   *
   * The caller builds a unified-diff patch containing only the hunks it wants
   * and sends it here; `git apply --cached` then moves exactly those hunks into
   * the index and leaves the rest of the working tree alone.
   */
  async gitStagePatch(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    patch: string,
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot: cwd } = workspaceFileScope
    if (!cwd) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
    if (patch.trim().length === 0) throw new RemoteError('ide-tools/bad-request', 'patch is empty', {})
    try {
      // --cached touches ONLY the index; --unidiff-zero lets a hand-built patch
      // carry zero-context hunks, which is how a single changed line is staged.
      await this.runGit(cwd, ['apply', '--cached', '--unidiff-zero', '-'], signal, patch)
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/git-stage-failed', message, {})
    }
  }

  /**
   * Un-stage PART of a file. The inverse of gitStagePatch: the patch is applied
   * to the index in reverse, so the selected hunks leave the staged set.
   */
  async gitUnstagePatch(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    patch: string,
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot: cwd } = workspaceFileScope
    if (!cwd) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
    if (patch.trim().length === 0) throw new RemoteError('ide-tools/bad-request', 'patch is empty', {})
    try {
      await this.runGit(cwd, ['apply', '--cached', '--unidiff-zero', '--reverse', '-'], signal, patch)
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/git-stage-failed', message, {})
    }
  }

  /** Unstage one path (git reset HEAD -- path, VS Code's "Unstage Changes").
   *  A newly-added (previously untracked) file becomes untracked again; a
   *  staged modification drops back to the working-tree group. */
  async gitUnstage(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    path: string,
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot: cwd } = workspaceFileScope
    if (!cwd) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
    if (path.length === 0) throw new RemoteError('ide-tools/bad-request', 'path is empty', {})
    try {
      await this.runGit(cwd, ['reset', 'HEAD', '--', path], signal)
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/git-unstage-failed', message, {})
    }
  }

  /** Unstage everything (git reset HEAD, VS Code's staged-group "−" action). */
  async gitUnstageAll(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot: cwd } = workspaceFileScope
    if (!cwd) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
    try {
      // In an UNBORN repository (git init, nothing committed) `reset HEAD`
      // fails with "ambiguous argument 'HEAD'". A bare `reset` (no revision)
      // empties the index without needing HEAD, which is exactly the semantics
      // wanted here.
      const hasHead = await this.hasHeadCommit(cwd, signal)
      await this.runGit(cwd, hasHead ? ['reset', '-q', 'HEAD'] : ['reset', '-q'], signal)
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/git-unstage-failed', message, {})
    }
  }

  /** Discard ALL uncommitted changes (VS Code's changes-group "↩ Discard All
   *  Changes"): reset the index to HEAD, rewrite the working tree from it,
   *  and remove every untracked file. Destructive — the UI confirms first. */
  async gitDiscardAll(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot: cwd } = workspaceFileScope
    if (!cwd) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
    try {
      // Staged renames keep a phantom index entry after reset unless the
      // target path is also cleaned, so clean runs after reset. Staged adds
      // are deleted by reset --hard itself (the worktree is forced back to
      // HEAD); clean -d only sweeps the never-staged untracked files.
      //
      // UNBORN repository: `reset --hard HEAD` fails (no HEAD to hard-reset
      // to). Emptying the index with `read-tree --empty` leaves every file as
      // untracked, and clean -f then removes them all — the same end state.
      const hasHead = await this.hasHeadCommit(cwd, signal)
      if (hasHead) {
        await this.runGit(cwd, ['reset', '--hard', 'HEAD'], signal)
      } else {
        await this.runGit(cwd, ['read-tree', '--empty'], signal)
      }
      await this.runGit(cwd, ['clean', '-fd'], signal)
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/git-discard-failed', message, {})
    }
  }

  /**
   * Discard one entry's uncommitted changes: bring the index AND working tree
   * back to HEAD for that path (VS Code's "Discard Changes").
   *
   * Per-kind command sequences, all verified against git 2.x behavior:
   *  - untracked → git clean -f -- path (removes the file; exit 0 when already
   *    gone, so a stale entry never hard-fails the discard)
   *  - added (staged-new) → git rm -f -- path (drops the index entry and
   *    deletes the working file; succeeds even when the file is already gone)
   *  - renamed → reset HEAD for both paths, restore the original path, then
   *    clean the (now untracked) rename target
   *  - modified / deleted / conflicted → git reset HEAD -- path unstages (and
   *    clears unmerged state), then git checkout -- path rewrites the working
   *    tree from the index; recreates a deleted file and resolves a UU
   *    conflict to the HEAD content
   */
  async gitDiscard(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    entry: { path: string; oldPath?: string; kind: GitStatusEntry['kind'] },
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot: cwd } = workspaceFileScope
    if (!cwd) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
    const { path, oldPath, kind } = entry
    if (path.length === 0) throw new RemoteError('ide-tools/bad-request', 'path is empty', {})
    try {
      // `reset -- <path>` / `checkout -- <path>` need a HEAD commit to pull the
      // old content from. In an UNBORN repository (git init, nothing committed
      // yet) git reset silently succeeds but `checkout -- <path>` fails with
      // "pathspec did not match any file(s) known to git" — the user's discard
      // then reports an error and changes nothing. Detect that case ONCE and
      // discard by dropping the index entry plus the worktree copy instead.
      const hasHead = await this.hasHeadCommit(cwd, signal)
      if (!hasHead) {
        // Nothing was ever committed, so the "committed" version of every path
        // is nonexistent: discard = unstage (if staged) and delete the file.
        await this.runGit(cwd, ['rm', '-f', '-q', '--cached', '--ignore-unmatch', '--', path], signal)
        await this.runGit(cwd, ['clean', '-f', '-q', '--', path], signal)
        return
      }
      if (kind === 'untracked') {
        await this.runGit(cwd, ['clean', '-f', '-q', '--', path], signal)
      } else if (kind === 'added') {
        await this.runGit(cwd, ['rm', '-f', '-q', '--', path], signal)
      } else if (kind === 'renamed' && oldPath !== undefined && oldPath.length > 0) {
        await this.runGit(cwd, ['reset', '-q', 'HEAD', '--', oldPath, path], signal)
        await this.runGit(cwd, ['checkout', '-q', '--', oldPath], signal)
        await this.runGit(cwd, ['clean', '-f', '-q', '--', path], signal)
      } else {
        await this.runGit(cwd, ['reset', '-q', 'HEAD', '--', path], signal)
        await this.runGit(cwd, ['checkout', '-q', '--', path], signal)
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/git-discard-failed', message, {})
    }
  }

  /**
   * Rename one workspace entry within its directory (Explorer context menu →
   * 重命名). Paths are workspace-relative; the resolved target must stay inside
   * the workspace root (absolute input, '..' traversal, and the root itself are
   * all refused). Refuses an existing target instead of overwriting.
   */
  async fileRename(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    path: string,
    newName: string,
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot } = workspaceFileScope
    try {
      if (!workspaceRoot) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
      if (path.length === 0 || newName.length === 0) throw new RemoteError('ide-tools/bad-request', 'path and name are required', {})
      if (newName === '.' || newName === '..' || /[/\\]/.test(newName)) {
        throw new RemoteError('ide-tools/bad-request', 'invalid name', {})
      }
      const abs = resolveWorkspacePath(workspaceRoot, path)
      const target = resolve(dirname(abs), newName)
      const root = resolve(workspaceRoot)
      // Same containment rule as everywhere else: root itself is inside.
      if (!target.startsWith(root + sep) && target !== root) {
        throw new RemoteError('ide-tools/bad-path', 'target escapes the workspace root', {})
      }
      if (existsSync(target)) {
        throw new RemoteError('ide-tools/exists', 'an entry with that name already exists', {})
      }
      await rename(abs, target)
    } catch (err) {
      if (err instanceof RemoteError) throw err
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/rename-failed', message, {})
    }
  }

  /**
   * Delete one file (or a directory, recursively) from the workspace
   * (Explorer context menu → 删除). Same workspace-root confinement as
   * fileRename; an already-gone path counts as success (idempotent).
   */
  async fileDelete(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    path: string,
    kind: 'file' | 'directory',
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot } = workspaceFileScope
    try {
      if (!workspaceRoot) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
      if (path.length === 0) throw new RemoteError('ide-tools/bad-request', 'path is required', {})
      const abs = resolveWorkspacePath(workspaceRoot, path)
      await assertWritable(this.ctx as unknown as WritePolicyContext, workspaceFileScope, abs, path)
      await rm(abs, { recursive: kind === 'directory', force: true })
    } catch (err) {
      if (err instanceof RemoteError) throw err
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/delete-failed', message, {})
    }
  }

  /**
   * Create one new workspace entry (Explorer → New File / New Folder). The
   * path may contain new intermediate segments (VS Code's inline input accepts
   * "sub/dir/name"), so missing parents are created; an existing target is
   * refused instead of overwritten. Same workspace-root confinement as
   * fileRename/fileDelete.
   */
  async fileCreate(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    path: string,
    kind: 'file' | 'directory',
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot } = workspaceFileScope
    try {
      if (!workspaceRoot) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
      if (path.length === 0) throw new RemoteError('ide-tools/bad-request', 'path is required', {})
      const abs = resolveWorkspacePath(workspaceRoot, path)
      if (existsSync(abs)) {
        throw new RemoteError('ide-tools/exists', 'an entry with that name already exists', {})
      }
      await assertWritable(this.ctx as unknown as WritePolicyContext, workspaceFileScope, abs, path)
      if (kind === 'directory') {
        await mkdir(abs, { recursive: true })
      } else {
        await mkdir(dirname(abs), { recursive: true })
        await writeFile(abs, '', { flag: 'wx' })
      }
    } catch (err) {
      if (err instanceof RemoteError) throw err
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/create-failed', message, {})
    }
  }

  /**
   * Move (or rename across directories) one workspace entry into a target
   * directory (Explorer drag & drop). Paths are workspace-relative; the host
   * refuses a target escaping the workspace root, a move into itself or its
   * own subtree, and an existing target — mirroring VS Code's explorer
   * drag-drop guards. The optional explicit newName resolves name collisions
   * the caller already knows about (e.g. suffix "- copy"). */
  async fileMove(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    path: string,
    targetDir: string,
    opts: { newName?: string } | undefined,
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot } = workspaceFileScope
    try {
      if (!workspaceRoot) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
      // targetDir === '' legitimately means "the workspace root": the next line
      // resolves it to workspaceRoot, and FileTree sends '' when dropping onto
      // the root row. Rejecting an empty targetDir here made every drop onto the
      // root fail with bad-request. Only PATH must be non-empty.
      if (path.length === 0) throw new RemoteError('ide-tools/bad-request', 'path is required', {})
      const abs = resolveWorkspacePath(workspaceRoot, path)
      const dirAbs = targetDir === '' ? resolve(workspaceRoot) : resolveWorkspacePath(workspaceRoot, targetDir)
      const root = resolve(workspaceRoot)
      if (!dirAbs.startsWith(root + sep) && dirAbs !== root) {
        throw new RemoteError('ide-tools/bad-path', 'target directory escapes the workspace root', {})
      }
      // The destination directory must exist and be a directory.
      const dirInfo = await stat(dirAbs).catch(() => undefined)
      if (dirInfo === undefined || !dirInfo.isDirectory()) {
        throw new RemoteError('ide-tools/bad-path', 'the target is not a directory', {})
      }
      // Refuse a move into itself or into its own subtree.
      if (abs === dirAbs || dirAbs.startsWith(abs + sep)) {
        throw new RemoteError('ide-tools/bad-path', 'cannot move an entry into itself or its own subtree', {})
      }
      const finalName = opts?.newName && opts.newName.length > 0 ? opts.newName : basename(abs)
      const target = resolve(dirAbs, finalName)
      // Containment rule identical to the dirAbs check above: the root itself is
      // inside the workspace, so allow it. startsWith(root + sep) alone would
      // also reject the root directory.
      if (!target.startsWith(root + sep) && target !== root) {
        throw new RemoteError('ide-tools/bad-path', 'target escapes the workspace root', {})
      }
      if (existsSync(target)) {
        throw new RemoteError('ide-tools/exists', 'an entry with that name already exists in the target directory', {})
      }
      // A move mutates BOTH ends: the source disappears and the target appears.
      const policyCtx = this.ctx as unknown as WritePolicyContext
      await assertWritable(policyCtx, workspaceFileScope, abs, path)
      await assertWritable(policyCtx, workspaceFileScope, target, relative(root, target))
      await rename(abs, target)
    } catch (err) {
      if (err instanceof RemoteError) throw err
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/move-failed', message, {})
    }
  }

  /**
   * Copy one file (not directories — VS Code's explorer paste copies files;
   * recursive directory copies stay a host-side bulk upload concern) into a
   * target directory. An existing target is refused unless the caller passes
   * an explicit newName (the UI derives "- copy" style suffixes). */
  async fileCopy(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    path: string,
    targetDir: string,
    opts: { newName?: string } | undefined,
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot } = workspaceFileScope
    try {
      if (!workspaceRoot) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
      // targetDir === '' legitimately means "the workspace root": the next line
      // resolves it to workspaceRoot, and FileTree sends '' when dropping onto
      // the root row. Rejecting an empty targetDir here made every drop onto the
      // root fail with bad-request. Only PATH must be non-empty.
      if (path.length === 0) throw new RemoteError('ide-tools/bad-request', 'path is required', {})
      const abs = resolveWorkspacePath(workspaceRoot, path)
      const info = await stat(abs).catch(() => undefined)
      if (info === undefined) throw new RemoteError('ide-tools/not-found', 'the source entry no longer exists', {})
      const dirAbs = targetDir === '' ? resolve(workspaceRoot) : resolveWorkspacePath(workspaceRoot, targetDir)
      const root = resolve(workspaceRoot)
      if (!dirAbs.startsWith(root + sep) && dirAbs !== root) {
        throw new RemoteError('ide-tools/bad-path', 'target directory escapes the workspace root', {})
      }
      const finalName = opts?.newName && opts.newName.length > 0 ? opts.newName : basename(abs)
      const target = resolve(dirAbs, finalName)
      // Containment rule identical to the dirAbs check above: the root itself is
      // inside the workspace, so allow it. startsWith(root + sep) alone would
      // also reject the root directory.
      if (!target.startsWith(root + sep) && target !== root) {
        throw new RemoteError('ide-tools/bad-path', 'target escapes the workspace root', {})
      }
      if (existsSync(target)) {
        throw new RemoteError('ide-tools/exists', 'an entry with that name already exists in the target directory', {})
      }
      // Copying a directory into itself would recurse forever (each pass
      // creating a new copy to walk). VS Code refuses the same case.
      if (info.isDirectory() && target.startsWith(abs + sep)) {
        throw new RemoteError('ide-tools/bad-path', 'cannot copy a directory into its own subtree', {})
      }
      // cp handles both files and directories (recursive), unlike copyFile.
      // `force:false` + the existsSync check above keeps the copy non-clobbering.
      // Symlinks are copied as links (verbatim), never dereferenced — expanding
      // them would let a link inside the workspace pull in files from outside it.
      await assertWritable(this.ctx as unknown as WritePolicyContext, workspaceFileScope, target, relative(root, target))
      await cp(abs, target, { recursive: true, force: false, errorOnExist: true, verbatimSymlinks: true })
    } catch (err) {
      if (err instanceof RemoteError) throw err
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/copy-failed', message, {})
    }
  }

  /**
   * Write one workspace file's whole content (editor save, diff-panel save).
   * Host-side twin of the never-published `@deepseek-ai/dsh-api-workspace-files-write`
   * package this plugin used to depend on: same wire shape, same error codes,
   * same agent 回灌.
   *
   * The write goes through the host fs seam's `writeText` rather than
   * `node:fs`, for two properties the seam owns and this file cannot restate:
   * the Session's sandbox policy fences the target (`read-only` denies,
   * `workspace-write` re-canonicalizes and requires containment, so a swapped
   * symlink cannot redirect the write), and the guarded intent is applied
   * atomically against the file's real version — a tab saved from a stale
   * buffer loses the race and gets `FS_STALE_VERSION`, not a silent clobber.
   * The fence is resolved per call by {@link writePolicyFor}; the caller's own
   * `workspaceRoot` is only the lexical half of the confinement, and the seam's
   * re-canonicalization is the half that survives symlinks.
   *
   * The seam emits nothing on its own, and the `workspaceFiles.changes` stream
   * replays only instrumented writes (the OS is not watched), so a successful
   * write is announced explicitly — otherwise the session's own file-change
   * feed, and the agent's view of the tree, would not see it.
   */
  async writeFile(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    path: string,
    content: string,
    intent: WorkspaceFileWriteIntent | undefined,
    signal: AbortSignal | undefined,
  ): Promise<WorkspaceFileWriteResult> {
    const { workspaceRoot } = workspaceFileScope
    try {
      if (!workspaceRoot) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
      if (path.length === 0) throw new RemoteError('ide-tools/bad-request', 'path is required', {})
      let abs: string
      try {
        abs = resolveWorkspacePath(workspaceRoot, path)
      } catch {
        throw new RemoteError('workspace-file-write/outside-workspace', `"${path}" is outside the workspace`, { path })
      }
      // Refuse a directory (or any other non-regular target) before the seam
      // sees it: the backend would otherwise fail it as a raw EISDIR.
      const info = await stat(abs).catch(() => undefined)
      if (info !== undefined && !info.isFile()) {
        throw new RemoteError('workspace-file-write/not-regular-file', `"${path}" is not a regular file`, { path })
      }
      const ctx = this.ctx as unknown as {
        fs: FsWriteSeam
        emit(event: string, ...args: unknown[]): void
      } & WritePolicyContext
      const target = await ctx.fs.resolve(abs, { cwd: resolve(workspaceRoot), signal })
      // replaceIfUnchanged: verify the DISK text against the digest the editor
      // captured when it opened the file. Matching means nobody else touched
      // it, so the write is safe; only a real external change rejects.
      let seamIntent: WorkspaceFileWriteIntent | undefined = intent
      if (intent?.kind === 'replaceIfUnchanged') {
        let diskText: string | undefined
        try {
          const readBack = await ctx.fs.readText(target, signal)
          diskText = typeof readBack === 'string' ? readBack : readBack.text
        } catch {
          diskText = undefined
        }
        if (diskText === undefined) {
          throw new RemoteError('workspace-file-write/stale-version', `"${path}" changed since it was read`, { path })
        }
        if (sha256Hex(diskText) !== intent.sha256) {
          throw new RemoteError('workspace-file-write/stale-version', `"${path}" changed since it was read`, { path })
        }
        seamIntent = undefined
      }
      const outcome = await ctx.fs.writeText(target, content, seamIntent, signal, writePolicyFor(ctx, workspaceFileScope))
      ctx.emit('fs/observed', target, { kind: 'present', version: outcome.version })
      return {
        absolutePath: abs,
        version: outcome.version,
        operation: outcome.operation,
        bytes: Buffer.byteLength(content, 'utf8'),
      }
    } catch (err) {
      if (err instanceof RemoteError) throw err
      const rawCode = (err as { code?: unknown }).code
      const message = err instanceof Error ? err.message : String(err)
      const code = typeof rawCode === 'string'
        ? FS_WRITE_ERROR_CODES[rawCode] ?? 'workspace-file-write/failed'
        : 'workspace-file-write/failed'
      throw new RemoteError(code as keyof RemoteErrorDetailsMap, message, { path })
    }
  }

  /**
   * Write one workspace file from BASE64 bytes (binary upload, PDF/asset copy).
   *
   * `writeFile` above takes a STRING, so an uploader had to call `File.text()`
   * first — the browser decodes the blob as UTF-8 and every invalid byte
   * becomes U+FFFD, so any non-text upload (a PNG, a zip, a PDF) was silently
   * corrupted on arrival. Taking bytes end-to-end avoids that. Same fences as
   * `writeFile`: workspace confinement, regular-file check, fs-seam policy and
   * version intent.
   */
  async writeFileBytes(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    path: string,
    base64: string,
    intent: WorkspaceFileWriteIntent | undefined,
    signal: AbortSignal | undefined,
  ): Promise<WorkspaceFileWriteResult> {
    const { workspaceRoot } = workspaceFileScope
    try {
      if (!workspaceRoot) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
      if (path.length === 0) throw new RemoteError('ide-tools/bad-request', 'path is required', {})
      const bytes = Buffer.from(base64, 'base64')
      let abs: string
      try {
        abs = resolveWorkspacePath(workspaceRoot, path)
      } catch {
        throw new RemoteError('workspace-file-write/outside-workspace', `"${path}" is outside the workspace`, { path })
      }
      const info = await stat(abs).catch(() => undefined)
      if (info !== undefined && !info.isFile()) {
        throw new RemoteError('workspace-file-write/not-regular-file', `"${path}" is not a regular file`, { path })
      }
      if (intent?.kind === 'createIfAbsent' && info !== undefined) {
        throw new RemoteError('workspace-file-write/already-exists', `"${path}" already exists`, { path })
      }
      if (intent?.kind === 'replaceIfVersion' && (info === undefined || info.size === undefined)) {
        throw new RemoteError('workspace-file-write/stale-version', `"${path}" changed since it was read`, { path })
      }
      // The seam only exposes writeText (string), so bytes cannot ride it —
      // but its sandbox fence MUST still apply, or this path silently became a
      // hole: a `read-only` Session could write here while every other save
      // was denied, and `workspace-write` lost its realpath containment check
      // (a symlinked parent inside the workspace points anywhere). Resolve the
      // policy ourselves and enforce the same two rules, re-canonicalizing the
      // deepest existing ancestor so a concurrently swapped link is seen.
      await assertWritable(this.ctx as unknown as WritePolicyContext, workspaceFileScope, abs, path)
      await mkdir(dirname(abs), { recursive: true })
      await writeFile(abs, bytes)
      // The version is the fs seam's content identity
      // (dev:ino:size:mtimeNs:ctimeNs), NOT the byte length. Returning the
      // length here meant the next save's replaceIfVersion guard could never
      // match, so every edit of a binary-saved file reported a bogus
      // "changed on disk" conflict. Re-read through the seam after writing to
      // obtain the real version.
      let version = String(bytes.length)
      try {
        const fs = (this.ctx as unknown as { fs: FsWriteSeam }).fs
        const target = await fs.resolve(abs, { cwd: resolve(workspaceRoot), signal })
        const read = await fs.readText(target, signal)
        if (typeof read !== 'string') version = read.version
      } catch {
        // Keep the size fallback rather than failing an otherwise successful
        // write; a stale version only risks one conflict dialog on next save.
      }
      return {
        absolutePath: abs,
        version,
        operation: info === undefined ? 'create' : 'update',
        bytes: bytes.length,
      }
    } catch (err) {
      if (err instanceof RemoteError) throw err
      const rawCode = (err as { code?: unknown }).code
      const message = err instanceof Error ? err.message : String(err)
      const code = typeof rawCode === 'string'
        ? FS_WRITE_ERROR_CODES[rawCode] ?? 'workspace-file-write/failed'
        : 'workspace-file-write/failed'
      throw new RemoteError(code as keyof RemoteErrorDetailsMap, message, { path })
    }
  }



  /**
   * Inline (FIM) completion at one cursor position.
   *
   * The buffer is split into a prefix (everything before the cursor) and a
   * suffix (everything after it); the model is asked to fill the gap. Both
   * sides are WINDOWED — a 5 MB file would otherwise blow the context — and
   * the split is reported back with the completion so the caller can reject a
   * result that does not join the two halves cleanly.
   *
   * Bounded on every axis because this runs on a keystroke pause: window
   * sizes, output length, and a hard timeout. Returns an empty completion (not
   * an error) when the model produces nothing usable — an inline hint that
   * cannot be produced is not a failure the user needs to see.
   */
  async completeInline(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    params: {
      path: string
      before: string
      after: string
      language?: string
    },
    signal: AbortSignal | undefined,
  ): Promise<{ text: string; model: string }> {
    const ctx = this.ctx as Context & {
      llm?: { stream(options: never): AsyncIterable<{ type: string; text?: string }> }
      agentDefaultModel?: { currentSelection(): { provider: string; model: string; reasoningEffort?: string } }
    }
    if (!ctx.llm) throw new RemoteError('ide-tools/llm-unavailable', 'LLM service is not available', {})
    const selection = ctx.agentDefaultModel?.currentSelection()
    if (!selection || !selection.provider || !selection.model) {
      throw new RemoteError('ide-tools/no-model', 'no model is configured', {})
    }

    const before = this.windowTail(params.before, INLINE_MAX_BEFORE_CHARS)
    const after = this.windowHead(params.after, INLINE_MAX_AFTER_CHARS)

    const systemPrompt = [
      'You are a code completion engine inside an editor.',
      'You receive the text immediately BEFORE the cursor and immediately AFTER it.',
      'Output ONLY the characters to insert at the cursor so the two sides join',
      'into natural, compiling code. Rules:',
      '- No explanations, no markdown fences, no backticks around the code.',
      '- Do not repeat text that already appears before or after the cursor.',
      '- Prefer a SHORT completion (a few lines at most); return nothing rather than guessing.',
      '- If nothing sensible fits, output an empty response.',
    ].join('\n')

    const userText = [
      'File: ' + params.path + (params.language ? ' (' + params.language + ')' : ''),
      '',
      '<<<BEFORE>>>',
      before,
      '<<<CURSOR>>>',
      '<<<AFTER>>>',
      after,
    ].join('\n')

    const messages = [createUserMessage({
      content: [{ type: 'text', text: userText }],
      source: { kind: 'user' },
    })]

    const options = deepFreeze({
      provider: selection.provider,
      model: selection.model,
      // Inline completion must be fast and deterministic; the default
      // reasoning path burns seconds per keystroke pause for no benefit.
      reasoningEffort: undefined as never,
      system: systemPrompt,
      messages,
      temperature: 0,
      maxTokens: INLINE_MAX_OUTPUT_TOKENS,
      signal,
    } as never)

    const assembler = new BlockAssembler()
    let finish: { kind?: string; failure?: { code?: string; message?: string } } | undefined
    const timeout = new Promise<void>((resolveTimeout) => {
      setTimeout(resolveTimeout, INLINE_TIMEOUT_MS).unref?.()
    })
    let timedOut = false
    const iterate = async () => {
      for await (const chunk of ctx.llm!.stream(options)) {
        if (signal?.aborted) break
        if ((chunk as { type?: string }).type === 'finish') {
          finish = (chunk as { reason?: { kind?: string; failure?: { code?: string; message?: string } } }).reason
          continue
        }
        assembler.push(chunk as never)
      }
    }
    await Promise.race([
      iterate(),
      timeout.then(() => { timedOut = true }),
    ])

    if (timedOut) throw new RemoteError('ide-tools/inline-timeout', 'inline completion timed out', {})
    if (finish?.kind === 'error') {
      const cause = finish.failure?.message ?? finish.failure?.code ?? 'unknown adapter failure'
      throw new RemoteError('ide-tools/llm-failed', cause, {})
    }

    const raw = assembler
      .blocks()
      .filter((b) => b.type === 'text')
      .map((b) => ('text' in b ? b.text ?? '' : ''))
      .join('')
    const text = this.sanitizeInlineCompletion(raw)
    return { text, model: selection.model }
  }

  /** Keep the LAST n chars (the part nearest the cursor). */
  private windowTail(text: string, maxChars: number): string {
    return text.length <= maxChars ? text : text.slice(text.length - maxChars)
  }

  /** Keep the FIRST n chars (the part nearest the cursor). */
  private windowHead(text: string, maxChars: number): string {
    return text.length <= maxChars ? text : text.slice(0, maxChars)
  }

  /**
   * Clean a raw model completion into insertable text.
   *
   * Models leak markdown fences into code even when told not to, echo the
   * marker lines back, or emit a lone trailing newline that would re-indent
   * the line. Everything here is about turning a noisy answer into something
   * Monaco can insert verbatim.
   */
  private sanitizeInlineCompletion(raw: string): string {
    if (raw.length === 0) return ''
    let text = raw
    // Strip a wrapping ``` fence (and any language tag on it).
    const fence = text.match(/^\s*```[\w+-]*\n([\s\S]*?)\n?```\s*$/)
    if (fence !== null) text = fence[1]
    // Drop echoed envelope markers.
    text = text.split('<<<BEFORE>>>').join('').split('<<<CURSOR>>>').join('').split('<<<AFTER>>>').join('')
    if (text.length > INLINE_MAX_OUTPUT_CHARS) text = text.slice(0, INLINE_MAX_OUTPUT_CHARS)
    return text
  }
  /**
   * Push the browser's CURRENT unsaved buffers into the host cache.
   *
   * The client calls this (debounced) on every dirty-state change and with an
   * empty list when the last buffer is saved or closed, so the cache always
   * mirrors the editor. Only the paths listed here are dirty: a path absent
   * from the payload has no unsaved edits, so the whole session's entry set is
   * REPLACED rather than merged (otherwise a buffer saved in the browser would
   * linger in the host forever and be reported as dirty).
   *
   * `text` is clipped to DIRTY_BUFFER_MAX_CHARS but the entry records
   * truncated/totalChars so a reader knows it is looking at a partial buffer
   * instead of silently reasoning over a cut-off file.
   */
  async pushDirtyBuffers(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    buffers: ReadonlyArray<{ path: string; text: string }>,
    signal: AbortSignal | undefined,
  ): Promise<{ accepted: number }> {
    const sessionId = workspaceFileScope.sessionId
    const next = new Map<string, DirtyBufferEntry>()
    const now = Date.now()
    for (const buffer of buffers) {
      if (buffer.path.length === 0) continue
      const totalChars = buffer.text.length
      const text = totalChars > DIRTY_BUFFER_MAX_CHARS ? buffer.text.slice(0, DIRTY_BUFFER_MAX_CHARS) : buffer.text
      next.set(buffer.path, {
        path: buffer.path,
        text,
        truncated: totalChars > DIRTY_BUFFER_MAX_CHARS,
        totalChars,
        revision: ++this.dirtyRevision,
        updatedAt: now,
      })
      if (next.size >= DIRTY_BUFFER_MAX_ENTRIES) break
    }
    if (next.size === 0) this.dirtyStore.delete(sessionId)
    else this.dirtyStore.set(sessionId, next)
    return { accepted: next.size }
  }

  /**
   * Read the unsaved buffers for one session.
   *
   * Pass a path to ask "what does the editor hold for THIS file?" — the
   * answer is empty when that file has no unsaved edits, which is the common
   * case and must be cheap. Pass nothing to list every dirty buffer.
   */
  async dirtyBuffers(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    path: string | undefined,
    signal: AbortSignal | undefined,
  ): Promise<{ entries: ReadonlyArray<DirtyBufferEntry> }> {
    const store = this.dirtyStore.get(workspaceFileScope.sessionId)
    if (store === undefined) return { entries: [] }
    if (path !== undefined && path.length > 0) {
      const entry = store.get(path)
      return { entries: entry === undefined ? [] : [entry] }
    }
    return { entries: [...store.values()] }
  }
  /**
   * Reveal one workspace entry in the OS file manager (Explorer context menu →
   * Reveal in Finder / Reveal in File Explorer / Open Containing Folder, per
   * host platform — same labels as VS Code's REVEAL_IN_OS_LABEL). Implemented
   * with the platform's own opener because the plugin host is plain Node:
   *   darwin: `open -R <path>`  (selects the item in Finder)
   *   win32:  `explorer /select,<path>`  (explorer exits 1 even on success)
   *   linux:  `xdg-open <dir>`  (the item itself for directories, else parent)
   * The root path ('') opens the workspace root itself.
   */
  async fileReveal(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    path: string,
    signal: AbortSignal | undefined,
  ): Promise<void> {
    const { workspaceRoot } = workspaceFileScope
    try {
      if (!workspaceRoot) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})
      // '' (the tree root) is allowed here: it reveals the workspace root itself.
      const abs = path.length === 0 ? resolve(workspaceRoot) : resolveWorkspacePath(workspaceRoot, path)
      if (!existsSync(abs)) throw new RemoteError('ide-tools/not-found', 'the entry no longer exists on disk', {})
      const platform = process.platform
      let argv: string[]
      if (platform === 'darwin') {
        argv = ['open', '-R', abs]
      } else if (platform === 'win32') {
        argv = ['explorer', `/select,${abs}`]
      } else {
        // Linux: a directory opens itself; a file opens its containing folder.
        argv = ['xdg-open', (await stat(abs)).isDirectory() ? abs : dirname(abs)]
      }
      const spec = {
        argv,
        cwd: workspaceRoot,
        stdio: {
          stdin: 'ignore' as const,
          stdout: { maxBytes: 4096 },
          stderr: { maxBytes: 4096 },
        },
        graceMs: 5000,
        signal,
      }
      let handle: import('@deepseek-ai/dsh-subprocess').SubprocessHandle
      try {
        handle = this.ctx.subprocess.spawn(spec as never)
      } catch {
        throw new RemoteError('ide-tools/reveal-failed', 'the OS opener could not start', {})
      }
      const outcome = await handle.done
      // Windows explorer.exe exits 1 even when it successfully opened a window.
      const benign = outcome.exitCode === 0 || (platform === 'win32' && outcome.exitCode === 1)
      if (!benign) {
        const stderrText = handle.collected.stderr?.readFrom(0)?.text ?? ''
        throw new RemoteError('ide-tools/reveal-failed', `opener exited with code ${outcome.exitCode}: ${stderrText.trim()}`, {})
      }
    } catch (err) {
      if (err instanceof RemoteError) throw err
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/reveal-failed', message, {})
    }
  }

  /** The host OS family, so the client can label the reveal action like VS Code
   *  (Reveal in Finder / Reveal in File Explorer / Open Containing Folder). */
  async hostPlatform(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    signal: AbortSignal | undefined,
  ): Promise<string> {
    return process.platform
  }

  /** Stage all changes and commit with a message (git add -A && git commit).
   *  VS Code SCM commit split-button parity — the dropdown maps onto options:
   *  amend rewrites the last commit (an empty message keeps the previous one
   *  via --no-edit), signoff adds a Signed-off-by trailer (-s), push runs
   *  git push after the commit, sync runs git pull then git push. */
  async gitCommit(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    message: string,
    options: { amend?: boolean; signoff?: boolean; push?: boolean; sync?: boolean; autoStage?: boolean },
    signal: AbortSignal | undefined,
  ): Promise<{ committed: boolean; hash?: string; pushed?: boolean }> {
    const { workspaceRoot: cwd } = workspaceFileScope
    const opts = options ?? {}
    try {
      // VS Code's smart-commit model: stage everything UNLESS the caller says
      // the index already holds the exact set to commit (autoStage:false).
      // Staging a clean tree is a no-op, so amend-with-empty-input still only
      // rewords either way.
      if (opts.autoStage !== false) {
        await this.runGit(cwd, ['add', '-A'], signal)
      }
      // Commit with the message. Use -m to avoid editor launch.
      const argv = opts.amend
        ? (message.trim().length > 0 ? ['commit', '--amend', '-m', message] : ['commit', '--amend', '--no-edit'])
        : ['commit', '-m', message]
      if (opts.signoff) argv.push('-s')
      // VS Code smart-commit self-heal: when the client believed the index
      // held the staged set (autoStage:false) but git finds nothing staged,
      // its status snapshot was stale — stage everything and retry once,
      // exactly VS Code's "stage all changes and commit" path.
      const commitOnce = (): Promise<string> =>
        this.runGit(cwd, argv, signal).catch(async (err: unknown) => {
          const msg = err instanceof Error ? err.message : String(err)
          if (opts.autoStage === false && /no changes added to commit|nothing to commit/.test(msg)) {
            await this.runGit(cwd, ['add', '-A'], signal)
            return this.runGit(cwd, argv, signal)
          }
          throw err
        })
      const out = await commitOnce()
      // Extract the commit hash from the commit output (line like "[main abc1234]"
      // or "[detached HEAD 5cf6db4]" — the branch label may contain spaces).
      const hashMatch = out.match(/\[[^\]]*?([0-9a-f]{7,40})\]/)
      // Post-commit commands (VS Code's Commit & Push / Commit & Sync):
      // sync = pull then push; push alone just pushes. Failures surface the
      // raw git stderr (e.g. a missing upstream), keeping the cause visible.
      let pushed: boolean | undefined
      // The push/pull steps run AFTER the commit already landed. A failure there
      // must never be reported as "nothing to commit" (the outer catch below
      // matches on the error text, and a push rejection can mention "no
      // changes") — it is tagged and surfaced as a distinct post-commit error
      // carrying the created hash so the client can say "committed, push failed".
      const postCommit = async (step: () => Promise<unknown>): Promise<void> => {
        try {
          await step()
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err)
          throw new RemoteError('ide-tools/git-commit-push-failed', msg, { committed: true, hash: hashMatch?.[1] })
        }
      }
      if (opts.sync) {
        // VS Code parity: Commit and Sync pulls+pushes when an upstream is
        // configured, but PUBLISHES (push -u) a branch with no upstream instead
        // of failing on a bare pull (no tracking information).
        const hasUpstream = await this.hasUpstream(cwd, signal)
        await postCommit(async () => {
          if (hasUpstream) {
            await this.runGit(cwd, ['pull'], signal)
            await this.runGit(cwd, ['push'], signal)
          } else {
            await this.publishBranch(cwd, signal)
          }
        })
        pushed = true
      } else if (opts.push) {
        // VS Code parity: Commit & Push pushes the upstream when set, else
        // publishes (push -u) so a branch with no upstream does not fail.
        const hasUpstream = await this.hasUpstream(cwd, signal)
        await postCommit(async () => {
          if (hasUpstream) {
            await this.runGit(cwd, ['push'], signal)
          } else {
            await this.publishBranch(cwd, signal)
          }
        })
        pushed = true
      }
      return { committed: true, hash: hashMatch?.[1], pushed }
    } catch (err) {
      // A post-commit failure already carries its own code + the new hash:
      // rethrow untouched so the client can report "committed, push failed"
      // instead of the text heuristic below swallowing it.
      if (err instanceof RemoteError) throw err
      const message2 = err instanceof Error ? err.message : String(err)
      // "nothing to commit" is not a hard error — report it as committed:false.
      if (message2.includes('nothing to commit') || message2.includes('no changes')) {
        return { committed: false }
      }
      throw new RemoteError('ide-tools/git-commit-failed', message2, {})
    }
  }

  /** True when the current branch has an upstream tracking ref configured
   *  (git rev-parse --abbrev-ref @{u} succeeds). Used by sync flows to decide
   *  pull+push (has upstream) vs publish (push -u, no upstream). */
  private async hasUpstream(cwd: string, signal: AbortSignal | undefined): Promise<boolean> {
    try {
      const out = await this.runGit(cwd, ['rev-parse', '--abbrev-ref', '@{u}'], signal)
      return out.trim().length > 0
    } catch {
      // No upstream configured → rev-parse fails with "no upstream configured".
      return false
    }
  }

  /** Publish the current branch: git push -u <remote> <branch>. Prefers origin,
   *  falls back to the first listed remote. Throws a clear RemoteError when
   *  there are no remotes or HEAD is detached. */
  private async publishBranch(cwd: string, signal: AbortSignal | undefined): Promise<void> {
    const branch = (await this.runGit(cwd, ['branch', '--show-current'], signal)).trim()
    if (branch.length === 0) {
      throw new RemoteError('ide-tools/git-sync-failed', 'cannot determine the current branch (detached HEAD?)', {})
    }
    const remotes = (await this.runGit(cwd, ['remote'], signal)).split('\n').map((r) => r.trim()).filter((r) => r.length > 0)
    if (remotes.length === 0) {
      throw new RemoteError('ide-tools/git-sync-failed', 'your repository has no remotes configured to publish to', {})
    }
    const remote = remotes.includes('origin') ? 'origin' : remotes[0]
    await this.runGit(cwd, ['push', '-u', remote, branch], signal)
  }

  /** VS Code SCM action button: synchronize or publish the branch.
   *  sync = git pull then git push (the clean-tree "Synchronize Changes"
   *  button); publish = git push -u origin <branch> for a local branch with
   *  no upstream (the "Publish Branch" button). Raw git stderr surfaces so a
   *  missing remote/upstream stays diagnosable. */
  async gitSync(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    action: 'sync' | 'publish' | 'pull' | 'push',
    signal: AbortSignal | undefined,
  ): Promise<{ pushed: boolean }> {
    const { workspaceRoot: cwd } = workspaceFileScope
    try {
      if (action === 'pull') {
        // VS Code's "Pull" command: plain pull (fails with git's own message
        // when no upstream is configured — that message is the UI's error).
        await this.runGit(cwd, ['pull'], signal)
        return { pushed: false }
      }
      if (action === 'push') {
        // VS Code's "Push": pushes the upstream when set, else publishes.
        const hasUpstream = await this.hasUpstream(cwd, signal)
        if (hasUpstream) await this.runGit(cwd, ['push'], signal)
        else await this.publishBranch(cwd, signal)
        return { pushed: true }
      }
      if (action === 'sync') {
        // VS Code parity: Synchronize pulls+pushes when an upstream is
        // configured, but PUBLISHES (push -u) a branch with no upstream instead
        // of failing on a bare pull (no tracking information).
        const hasUpstream = await this.hasUpstream(cwd, signal)
        if (hasUpstream) {
          await this.runGit(cwd, ['pull'], signal)
          await this.runGit(cwd, ['push'], signal)
        } else {
          await this.publishBranch(cwd, signal)
        }
      } else {
        const branch = (await this.runGit(cwd, ['branch', '--show-current'], signal)).trim()
        if (branch.length === 0) {
          throw new RemoteError('ide-tools/git-sync-failed', 'cannot determine the current branch (detached HEAD?)', {})
        }
        // VS Code parity: single remote publishes via remotes[0]; prefer the
        // conventional origin when present, else the first listed remote.
        const remotes = (await this.runGit(cwd, ['remote'], signal)).split('\n').map((r) => r.trim()).filter((r) => r.length > 0)
        if (remotes.length === 0) {
          throw new RemoteError('ide-tools/git-sync-failed', 'your repository has no remotes configured to publish to', {})
        }
        const remote = remotes.includes('origin') ? 'origin' : remotes[0]
        await this.runGit(cwd, ['push', '-u', remote, branch], signal)
      }
      return { pushed: true }
    } catch (err) {
      if (err instanceof RemoteError) throw err
      const message2 = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/git-sync-failed', message2, {})
    }
  }

  /**
   * Generate a git-conventional commit message from the workspace's
   * uncommitted changes, using the currently configured LLM (agentDefaultModel).
   *
   * Mirrors the VS Code SCM AI assistants (Copilot / WeCode): the staged diff
   * is preferred when the index holds changes, otherwise the whole working
   * tree is used. The prompt also carries the branch name and the recent
   * commit subjects so the message matches the repository's language and
   * message conventions. The diff is capped per file section at 32 KiB and
   * the model output is sanitized (fences/labels stripped) before it lands in
   * the commit input. A client abort surfaces as the ide-tools/aborted code.
   */
  async gitGenerateCommitMessage(
    workspaceFileScope: { sessionId: string; workspaceRoot: string },
    signal: AbortSignal | undefined,
  ): Promise<{ message: string }> {
    const { workspaceRoot: cwd } = workspaceFileScope
    try {
      if (!cwd) throw new RemoteError('ide-tools/no-workspace', 'workspace root is not set', {})

      let diff = ''
      let diffSource: 'staged' | 'working-tree' = 'working-tree'
      const untracked: string[] = []
      try {
        const statusRaw = await this.runGit(cwd, ['status', '--porcelain=v1', '--untracked-files=all', '-z'], signal)
        for (const part of statusRaw.split('\u0000')) {
          if (part.startsWith('?? ')) untracked.push(part.slice(3))
        }
        if (untracked.length > 0) {
          try { await this.runGit(cwd, ['add', '-N', '--', ...untracked], signal) } catch { /* ignore */ }
        }
        // VS Code SCM assistants prefer the staged diff when the index holds
        // changes, and fall back to the whole working tree otherwise.
        diff = await this.runGit(cwd, ['diff', '--cached', '--no-color'], signal)
        if (diff.trim().length > 0) {
          diffSource = 'staged'
        } else {
          // Unborn repository: `git diff HEAD` exits 128 — treat it as empty
          // so the plain worktree diff below takes over (it works on unborn
          // and includes the intent-to-add content).
          diff = await this.runGit(cwd, ['diff', 'HEAD', '--no-color'], signal).catch(() => '')
          if (diff.trim().length === 0) {
            diff = await this.runGit(cwd, ['diff', '--no-color'], signal)
          }
        }
      } catch (err) {
        if (err instanceof RemoteError && err.code === 'ide-tools/not-a-repo') {
          throw new RemoteError('ide-tools/not-a-repo', 'workspace is not a git repository', {})
        }
        throw err
      } finally {
        // Undo the intent-to-add marks: they linger in the index otherwise —
        // rendering as '.A' status entries and never being committed by a
        // plain `git commit` (git does not count i-t-a as staged changes).
        // Resetting exactly the paths we marked restores the pristine
        // untracked state, whatever happened above.
        if (untracked.length > 0) {
          try { await this.runGit(cwd, ['reset', '-q', '--', ...untracked], signal) } catch { /* ignore */ }
        }
      }

      if (diff.trim().length === 0) {
        throw new RemoteError('ide-tools/no-changes', 'no uncommitted changes to generate a message from', {})
      }

      // Style context: the branch name and the recent commit subjects teach the
      // model the repository's language and message conventions (both are best
      // effort — a missing history or detached HEAD must not block generation).
      const branch = await this.runGit(cwd, ['branch', '--show-current'], signal).catch(() => '')
      const recentSubjects = await this.runGit(cwd, ['log', '--format=%s', '-n', '10'], signal).catch(() => '')

      const MAX_DIFF = 32 * 1024
      const trimmed = this.truncateDiffForPrompt(diff, MAX_DIFF)

      const ctx = this.ctx as Context & { llm?: { stream(options: never): AsyncIterable<{ type: string; text?: string }> }; agentDefaultModel?: { currentSelection(): { provider: string; model: string; reasoningEffort?: string } } }
      if (!ctx.llm) {
        throw new RemoteError('ide-tools/llm-unavailable', 'LLM service is not available', {})
      }
      const selection = ctx.agentDefaultModel?.currentSelection()
      if (!selection || !selection.provider || !selection.model) {
        throw new RemoteError('ide-tools/no-model', 'no model is configured', {})
      }

      const systemPrompt = [
        'You are an expert software engineer who writes git commit messages.',
        'You will receive the current branch name, the recent commit subjects, and a git diff.',
        'Generate ONE commit message following the Conventional Commits specification:',
        '  <type>(<optional scope>): <subject>',
        '  <optional body>',
        '',
        'Rules:',
        '- type: one of feat, fix, docs, style, refactor, perf, test, build, ci, chore, revert',
        '- subject: imperative mood, no trailing period, max 50 chars',
        '- body (optional): wrap at 72 chars, explain what and why (not how); separate it from the subject with one blank line',
        '- When recent commit subjects are provided, match their language and phrasing style (e.g. write Chinese if the history is Chinese); otherwise use the language of the diff, else English.',
        '- Focus on the meaningful source changes; ignore generated/build artifacts when real changes exist.',
        '- Output ONLY the commit message: no markdown fences, no quotes, no explanations.',
      ].join('\n')

      const styleBlock = recentSubjects.trim().length > 0
        ? 'Recent commit subjects (style reference):\n' + recentSubjects.trim()
        : 'No recent commit history available.'
      const userText = [
        'Branch: ' + (branch.trim().length > 0 ? branch.trim() : '(unknown)'),
        '',
        styleBlock,
        '',
        diffSource === 'staged' ? 'Staged changes (git diff --cached):' : 'Working tree changes (git diff HEAD):',
        '',
        '```',
        trimmed,
        '```',
      ].join('\n')

      // Build a properly identified + frozen user message using the dsh-llm
      // helper (hand-built messages missing the id field crash the adapter).
      // DSH 0.2.0 removed the 'plugin' message source kind: MessageSource is now a
      // merge-extensible sum type with no shared catch-all 'plugin' kind, and user
      // messages may carry any producer's kind. This plugin-initiated prompt is a
      // user-authored request, so 'user' is the faithful attribution.
      const messages = [createUserMessage({
        content: [{ type: 'text', text: userText }],
        source: { kind: 'user' },
      })]

      // No explicit maxTokens: a hardcoded 2048 cap starves reasoning models
      // — they spend the whole budget on reasoning and return no text. With the
      // cap unset, the dsh-llm adapter applies the bound model's
      // defaultMaxTokens, leaving room for both reasoning and the message.
      const options = deepFreeze({
        provider: selection.provider,
        model: selection.model,
        reasoningEffort: selection.reasoningEffort as never,
        system: systemPrompt,
        messages,
        signal,
      } as never)

      // Use BlockAssembler to robustly collect all text from the stream, and keep the terminal
      // finish chunk: adapter failures arrive as an error-kind finish (not a thrown exception), so
      // ignoring it would mask the real cause behind a misleading "empty message".
      const assembler = new BlockAssembler()
      let finish: { kind?: string; failure?: { code?: string; message?: string } } | undefined
      for await (const chunk of ctx.llm.stream(options)) {
        if (signal?.aborted) break
        if ((chunk as { type?: string }).type === 'finish') {
          finish = (chunk as { reason?: { kind?: string; failure?: { code?: string; message?: string } } }).reason
          continue
        }
        assembler.push(chunk as never)
      }

      if (signal?.aborted || finish?.kind === 'aborted') {
        throw new RemoteError('ide-tools/aborted', 'commit message generation was cancelled', {})
      }
      if (finish?.kind === 'error') {
        const cause = finish.failure?.message ?? finish.failure?.code ?? 'unknown adapter failure'
        throw new RemoteError('ide-tools/llm-failed', cause, {})
      }

      const blocks = assembler.blocks()
      const message = this.sanitizeCommitMessage(
        blocks
          .filter((b) => b.type === 'text')
          .map((b) => ('text' in b ? b.text ?? '' : ''))
          .join(''),
      )

      if (message.length === 0) {
        // Distinguish "the model only reasoned" (budget spent before any text) from a truly empty
        // response — reasoning models under a small token budget hit exactly this.
        const reasoned = blocks.some((b) => b.type === 'reasoning')
        throw new RemoteError(
          'ide-tools/llm-empty',
          reasoned
            ? 'the model spent its whole token budget on reasoning and returned no text; retry or lower the reasoning effort'
            : 'the model returned an empty message',
          {},
        )
      }

      return { message }
    } catch (err) {
      if (signal?.aborted) {
        throw new RemoteError('ide-tools/aborted', 'commit message generation was cancelled', {})
      }
      if (err instanceof RemoteError) throw err
      const message = err instanceof Error ? err.message : String(err)
      throw new RemoteError('ide-tools/llm-failed', message, {})
    }
  }

  /** Cap a unified diff for the prompt: keep whole per-file sections while
   *  the byte budget lasts (so no file is cut mid-hunk), then note how many
   *  files were omitted. A single oversized section (e.g. a rebuilt bundle)
   *  keeps its head at the budget. */
  private truncateDiffForPrompt(diff: string, maxBytes: number): string {
    if (diff.length <= maxBytes) return diff
    const sections: string[] = []
    let current: string[] = []
    for (const line of diff.split('\n')) {
      if (line.startsWith('diff --git ') && current.length > 0) {
        sections.push(current.join('\n'))
        current = [line]
      } else {
        current.push(line)
      }
    }
    if (current.length > 0) sections.push(current.join('\n'))

    let kept = ''
    let omitted = 0
    for (const section of sections) {
      if (kept.length === 0 && section.length > maxBytes) {
        kept = section.slice(0, maxBytes) + '\n… (file diff truncated)'
        omitted = sections.length - 1
        break
      }
      if (kept.length + section.length > maxBytes) { omitted += 1; continue }
      kept = kept.length === 0 ? section : kept + '\n' + section
    }
    return kept + (omitted > 0 ? '\n… (' + omitted + ' more file diff(s) omitted)' : '')
  }

  /** Clean model output: strip markdown fences and commit-message label
   *  lines and signature lines, collapse runs of blank lines, trim. */
  private sanitizeCommitMessage(raw: string): string {
    let text = raw.trim()
    const label = /^\s*(?:suggested commit message|commit message|提交信息|提交消息)\s*[:：]\s*/i
    text = text.replace(label, '')
    // Strip one wrapping markdown fence, optionally language-tagged.
    if (text.startsWith('```')) {
      const firstNl = text.indexOf('\n')
      const lastFence = text.lastIndexOf('```')
      if (firstNl > 0 && lastFence > firstNl) text = text.slice(firstNl + 1, lastFence)
    }
    text = text.replace(label, '')
    // Drop model signature lines (Generated with …).
    text = text.split('\n').filter((line) => !/generated\s+(with|by)\b/i.test(line)).join('\n')
    // Collapse runs of blank lines to one blank line.
    text = text.replace(/\n{3,}/g, '\n\n').trim()
    return text
  }
  /** Plugin teardown: terminate every still-live terminal AND debuggee.
   *
   *  Debug targets are children of the host process, not of the browser tab:
   *  a page that reloads or unmounts without calling debugTerminate (crash,
   *  force-closed tab) would otherwise leave the debuggee running forever. */
  private async disposeAll(): Promise<void> {
    const targets = [...this.debugTargets.values()]
    this.debugTargets.clear()
    for (const target of targets) this.terminateHandle(target.handle)
    const entries = [...this.terminals.values()]
    this.terminals.clear()
    await Promise.allSettled(entries.map(async (entry) => {
      for (const subscriber of entry.subscribers) subscriber({ data: '', exit: true })
      entry.subscribers.clear()
      await entry.handle.terminate().catch(() => undefined)
    }))
  }
}

export default IdeTools
