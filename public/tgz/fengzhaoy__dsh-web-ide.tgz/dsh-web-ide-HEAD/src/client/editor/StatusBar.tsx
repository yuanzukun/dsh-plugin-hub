/**
 * Status bar (VS Code parity): left = remote indicator, branch + sync
 * (ahead/behind), problems, workspace, terminal toggle, save state; right =
 * model, cursor, lines, indentation + EOL pickers, language picker, encoding,
 * layout buttons, notification bell. All pickers reuse the ContextMenu.
 */
import { languageLabel } from '../language.js'
import { copyText } from '../clipboard.js'
import { Icons } from '../icons.js'
import { showContextMenu } from '../ContextMenu.js'
import { notifications } from '../notifications.js'
import { NotificationBell } from '../NotificationCenter.js'
import type { OpenTab } from './TabBar.js'
import { encodingLabel, type TextEncoding } from './encoding.js'

interface StatusBarProps {
  activeTab: OpenTab | undefined
  /** Detected encoding of the active tab (status-bar label). */
  encoding?: TextEncoding
  cursor: { line: number; column: number }
  t: (key: string, params?: Record<string, string | number>) => string
  /** Save state of the active tab. */
  saveState: 'idle' | 'saving' | 'conflict'
  /** Save the active tab (status-bar affordance). */
  onSave: () => void
  /** Current AI model identifier, shown in the status bar (right side). */
  model?: string
  /** Current git branch name (HEAD short name), shown on the left side. */
  branch?: string
  /** Detached HEAD: short SHA shown in place of the branch name (VS Code
   *  parity — otherwise the whole branch + sync block disappears). */
  detachedSha?: string
  /** Commits ahead of upstream (status-bar sync indicator). */
  ahead?: number
  /** Commits behind upstream (status-bar sync indicator). */
  behind?: number
  /** Click the branch sync indicator: pull + push (gitSync 'sync'). */
  onSync?: () => void
  /** Click the branch name: toggle the Source Control Branches view (open it
   *  when collapsed, collapse it again on the next click). */
  onOpenBranch?: () => void
  /** Whether the Source Control Branches view is currently showing; drives the
   *  branch button's active state. */
  branchPanelOpen?: boolean
  /** Whether a git sync is in flight (spins the sync button, blocks re-entry). */
  syncBusy?: boolean
  /** Problem counts from Monaco markers (status-bar problems indicator). */
  problems?: { errors: number; warnings: number }
  /** Click the problems indicator: open the Problems bottom-panel tab. */
  onOpenProblems?: () => void
  /** Workspace (session cwd basename) for the remote indicator. */
  workspaceName?: string
  /** Session id shown in the remote info card. */
  sessionId?: string
  /** Session cwd shown in the remote info card. */
  cwd?: string
  /** Toggle the bottom terminal panel open/closed. */
  onToggleTerminal?: () => void
  /** Whether the terminal panel is currently open. */
  terminalOpen?: boolean
  /** Active bottom-panel tab. The terminal button must only light up when the
   *  TERMINAL tab is showing: the panel's open flag is shared with the Problems
   *  tab, so keying the highlight on terminalOpen alone painted the terminal
   *  icon blue while the Problems view was open. */
  bottomTab?: 'terminal' | 'problems'
  /** Current model language id of the active editor tab. */
  language?: string
  /** Switch the active model's language (setModelLanguage). */
  onSetLanguage?: (lang: string) => void
  /** Current indentation of the active model. */
  indent?: { tabSize: number; insertSpaces: boolean }
  /** Change the active model's indentation. */
  onSetIndent?: (tabSize: number, insertSpaces: boolean) => void
  /** Current EOL of the active model ('\n' | '\r\n'). */
  eol?: '\n' | '\r\n'
  onSetEol?: (eol: '\n' | '\r\n') => void

}

const LANGUAGE_OPTIONS = ['typescript', 'javascript', 'json', 'css', 'scss', 'less', 'html', 'markdown', 'xml', 'yaml', 'python', 'go', 'rust', 'java', 'c', 'cpp', 'csharp', 'ruby', 'php', 'swift', 'kotlin', 'shell', 'sql', 'ini', 'dockerfile', 'makefile', 'plaintext']

export function StatusBar(props: StatusBarProps) {
  const { activeTab, encoding, cursor, t, saveState, onSave, model, branch, detachedSha, ahead, behind, onSync, onOpenBranch, branchPanelOpen, syncBusy, problems, onOpenProblems, workspaceName, sessionId, cwd, onToggleTerminal, terminalOpen, bottomTab, language, onSetLanguage, indent, onSetIndent, eol, onSetEol } = props

  const menuAt = (el: HTMLElement | null, items: Parameters<typeof showContextMenu>[2]) => {
    const rect = el?.getBoundingClientRect()
    showContextMenu(rect ? rect.left : 100, rect ? rect.top - 4 : 100, items)
  }

  const openIndentMenu = (e: React.MouseEvent) => {
    const items = [
      { id: 'sp2', label: t('status.spaces', { count: 2 }), onClick: () => onSetIndent?.(2, true) },
      { id: 'sp4', label: t('status.spaces', { count: 4 }), onClick: () => onSetIndent?.(4, true) },
      { id: 'sp8', label: t('status.spaces', { count: 8 }), onClick: () => onSetIndent?.(8, true) },
      { id: 'tab4', label: t('status.tabs', { count: 4 }), onClick: () => onSetIndent?.(4, false) },
      { id: 'tab8', label: t('status.tabs', { count: 8 }), onClick: () => onSetIndent?.(8, false) },
    ]
    showContextMenu(e.clientX, e.clientY - 4, items)
  }

  const openEolMenu = (e: React.MouseEvent) => {
    showContextMenu(e.clientX, e.clientY - 4, [
      { id: 'lf', label: 'LF', onClick: () => onSetEol?.('\n') },
      { id: 'crlf', label: 'CRLF', onClick: () => onSetEol?.('\r\n') },
    ])
  }

  const openLanguageMenu = (e: React.MouseEvent) => {
    showContextMenu(e.clientX, e.clientY - 4, LANGUAGE_OPTIONS.map((lang) => ({
      id: lang,
      label: languageLabel(lang),
      onClick: () => onSetLanguage?.(lang),
    })))
  }

  /** Copy a value to the clipboard and acknowledge it with a toast. The
   *  fallback chain lives in ../clipboard.ts so every panel behaves the same
   *  on insecure origins, where the async Clipboard API is unavailable. */
  const copyToClipboard = async (value: string, what: string): Promise<void> => {
    if (await copyText(value)) notifications.info(t('status.copied', { what, value }))
    else notifications.error(t('status.copyFailed', { what }))
  }

  const openRemoteMenu = (e: React.MouseEvent) => {
    // The workspace path row is clickable (copies the full project path);
    // name and session id stay informational.
    const pathRow = cwd !== undefined && cwd.length > 0
      ? {
          id: 'cwd',
          label: cwd,
          // The copy affordance sits at the RIGHT end of the row; the whole row
          // (path text or icon) copies, so no explanatory text is needed.
          actionIcon: Icons.copy,
          onClick: () => { void copyToClipboard(cwd, t('status.pathWhat')) },
        }
      : { id: 'cwd', label: cwd ?? '—', disabled: true }
    showContextMenu(e.clientX, e.clientY - 4, [
      { id: 'ws', label: workspaceName ?? '—', disabled: true },
      pathRow,
      { id: 'sid', label: (sessionId ?? '').slice(0, 18), disabled: true },
    ])
  }

  return (
    <div className="ide-statusbar" data-testid="ide-statusbar">
      <div className="ide-statusbar-left">
        {/* Branch indicator — leftmost, VS Code order: branch name, then the
            sync button, then the remote/workspace indicator. Clicking the
            branch name opens the Source Control Branches view; the sync button
            (shown only when there is something to pull or push) runs
            gitSync('sync'). */}
        {(branch !== undefined || detachedSha !== undefined) && (
          <span className="ide-statusbar-item ide-statusbar-branch-group" data-testid="ide-statusbar-branch">
            <button
              type="button"
              className="ide-statusbar-item ide-statusbar-branch"
              title={detachedSha !== undefined ? t('status.detachedSha', { sha: detachedSha }) : t('status.branchClick', { branch: branch ?? '' })}
              data-testid="ide-statusbar-branch-name"
              data-active={branchPanelOpen === true || undefined}
              aria-expanded={branchPanelOpen === true}
              onClick={() => onOpenBranch?.()}
            >
              <span className="ide-statusbar-branch-icon">{Icons.branch}</span>
              <span className="ide-statusbar-branch-name">{branch ?? detachedSha}</span>
            </button>
            {/* Always rendered (VS Code keeps the synchronize affordance in
                place): only the ahead/behind counters appear when there is
                something to pull or push. While a sync is running it spins and
                refuses re-entry; when there is nothing to sync it stays visible
                but muted, so the button never seems to vanish. */}
            {onSync !== undefined && (
              <button
                type="button"
                className="ide-statusbar-item ide-statusbar-sync"
                title={syncBusy === true ? t('status.syncing') : (ahead ?? 0) > 0 || (behind ?? 0) > 0 ? t('status.sync') : t('status.nothingToSync')}
                aria-label={t('status.sync')}
                data-testid="ide-statusbar-sync"
                data-busy={syncBusy === true || undefined}
                data-idle={((ahead ?? 0) === 0 && (behind ?? 0) === 0) || undefined}
                disabled={syncBusy === true}
                onClick={onSync}
              >
                <span className="ide-statusbar-sync-ring">{Icons.sync}</span>
                {(ahead !== undefined && ahead > 0) && <span className="ide-statusbar-sync-count" title={t('status.ahead', { count: ahead })}>{ahead}</span>}
                {(behind !== undefined && behind > 0) && <span className="ide-statusbar-sync-count" title={t('status.behind', { count: behind })}>{behind}</span>}
              </button>
            )}
          </span>
        )}
        {/* Remote/workspace indicator (VS Code remote indicator position). */}
        <button
          type="button"
          className="ide-statusbar-item ide-statusbar-remote"
          title={t('status.remoteInfo')}
          data-testid="ide-statusbar-remote"
          onClick={openRemoteMenu}
        >
          <span className="ide-statusbar-remote-icon">{Icons.remote}</span>
          {workspaceName ?? t('status.workspace')}
        </button>
        {onToggleTerminal && (
          <button
            type="button"
            className="ide-statusbar-item ide-statusbar-terminal"
            data-active={(terminalOpen && (bottomTab === undefined || bottomTab === 'terminal')) || undefined}
            title={t('panel.toggleBottom')}
            aria-label={t('panel.toggleBottom')}
            onClick={onToggleTerminal}
          >{Icons.terminal}</button>
        )}
        {problems && onOpenProblems && (
          <button
            type="button"
            className="ide-statusbar-item ide-statusbar-problems"
            data-active={(terminalOpen && bottomTab === 'problems') || undefined}
            title={t('status.problemsCounts', { errors: problems.errors, warnings: problems.warnings })}
            data-testid="ide-statusbar-problems"
            onClick={onOpenProblems}
          >
            <span className="ide-statusbar-prob-icon ide-statusbar-prob-error">{Icons.close}</span>{problems.errors}
            <span className="ide-statusbar-prob-icon ide-statusbar-prob-warn">{Icons.warning}</span>{problems.warnings}
          </button>
        )}
        {saveState === 'saving' ? (
          <span className="ide-statusbar-item">{t('status.saving')}</span>
        ) : saveState === 'conflict' ? (
          <span className="ide-statusbar-item ide-statusbar-conflict">{t('status.conflict')}</span>
        ) : activeTab?.dirty ? (
          <button type="button" className="ide-statusbar-item ide-statusbar-dirty" title={t('save.dirtyHint')} onClick={onSave}>
            {t('status.dirty')}
          </button>
        ) : (
          <span className="ide-statusbar-item">{t('status.saved')}</span>
        )}
      </div>
      <div className="ide-statusbar-right">
        {model && (
          <span className="ide-statusbar-item ide-statusbar-model">{t('status.model', { model })}</span>
        )}
        {activeTab && activeTab.status === 'ready' && (
          <>
            <span className="ide-statusbar-item">{t('status.lineColumn', { line: cursor.line, column: cursor.column })}</span>
            <span className="ide-statusbar-item">{t('status.lines', { lines: activeTab.lines })}</span>
            {indent && onSetIndent && (
              <button type="button" className="ide-statusbar-item" title={t('status.selectIndentation')} data-testid="ide-statusbar-indent" onClick={openIndentMenu}>
                {indent.insertSpaces ? t('status.spaces', { count: indent.tabSize }) : t('status.tabs', { count: indent.tabSize })}
              </button>
            )}
          </>
        )}
        {/* The real detected encoding. It used to say UTF-8 unconditionally,
            which was actively misleading for GBK / Latin-1 files. Order follows
            VS Code's measured status bar: Spaces → UTF-8 → LF → language. */}
        <span
          className="ide-statusbar-item"
          title={encoding !== undefined ? encodingLabel(encoding) : t('status.utf8')}
          data-testid="ide-statusbar-encoding"
        >
          {encoding !== undefined ? encodingLabel(encoding) : t('status.utf8')}
        </span>
        {activeTab && activeTab.status === 'ready' && eol && onSetEol && (
          <button type="button" className="ide-statusbar-item" title={t('status.selectEol')} data-testid="ide-statusbar-eol" onClick={openEolMenu}>
            {eol === '\n' ? 'LF' : 'CRLF'}
          </button>
        )}
        {activeTab && activeTab.status === 'ready' && language && onSetLanguage && (
          <button type="button" className="ide-statusbar-item" title={t('status.selectLanguage')} data-testid="ide-statusbar-language" onClick={openLanguageMenu}>
            {languageLabel(language)}
          </button>
        )}
        {/* Notification bell is the LAST item, exactly like VS Code's status
            bar (class last-visible-item there). Shows bell-dot while there are
            unseen notifications, plain bell otherwise. The old layout-control
            buttons (toggle sidebar / right sidebar / layout menu) were removed
            at the user's request — those toggles remain in the editor toolbar
            and the ≡ Appearance submenu. */}
        <NotificationBell t={t} />
      </div>
    </div>
  )
}
