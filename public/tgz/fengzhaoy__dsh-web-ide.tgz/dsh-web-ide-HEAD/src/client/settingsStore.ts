/**
 * IDE user settings store (VS Code Settings parity): localStorage-backed,
 * subscribe/notify, hot-applied to Monaco (editor options), xterm (terminal
 * options) and the CSS-variable theme. Pure module, no React — components
 * subscribe via useSyncExternalStore-friendly subscribe()/getSnapshot().
 *
 * Keys intentionally mirror VS Code's user settings semantics (but flat, and
 * namespaced): theme, editor.*, terminal.*.
 */
import type * as Monaco from 'monaco-editor'

export interface IdeSettings {
  /** Color theme: 'dark-modern' (default, VS Code Dark Modern), 'dark-2026' or 'light-modern'. */
  theme: 'dark-2026' | 'dark-modern' | 'light-modern'
  /** Editor font size in px (Monaco fontSize). */
  'editor.fontSize': number
  /** Editor line height in px (Monaco lineHeight; 0 = auto). */
  'editor.lineHeight': number
  /** Show the minimap (Monaco minimap.enabled). */
  'editor.minimap': boolean
  /** Word wrap (Monaco wordWrap: 'on' | 'off'). */
  'editor.wordWrap': 'on' | 'off'
  /** Render whitespace (Monaco renderWhitespace). */
  'editor.renderWhitespace': 'none' | 'boundary' | 'selection' | 'all'
  /** Show line numbers (Monaco lineNumbers). */
  'editor.lineNumbers': boolean
  /** Cursor blink style (Monaco cursorBlinking). */
  'editor.cursorBlinking': 'blink' | 'smooth' | 'phase' | 'expand' | 'solid'
  /** Smooth scrolling (Monaco smoothScrolling). */
  'editor.smoothScrolling': boolean
  /** Terminal font size in px (xterm fontSize). */
  'terminal.fontSize': number
  /** Terminal cursor blink (xterm cursorBlink). */
  'terminal.cursorBlink': boolean
  /** Terminal scrollback lines (xterm scrollback). */
  'terminal.scrollback': number
  /** Copy the selection to the clipboard as soon as it is made (VS Code
   *  terminal.copyOnSelection, default off there — match it). */
  'terminal.copyOnSelection': boolean
  /** Terminal line height multiplier (xterm lineHeight, 1.0 default). */
  'terminal.lineHeight': number
  /** Terminal font weight ('normal' | 'bold' | 100–900, xterm fontWeight). */
  'terminal.fontWeight': number
  /** Play a soft system beep when the terminal bell (\a) fires (VS Code
   *  terminal.integrated.enableBell; the flash variant is always shown). */
  'terminal.bellSound': boolean
  /** Enable FIM inline completion (experimental; needs DEEPSEEK_API_KEY). */
  'fim.enabled': boolean
  /** FIM debounce in ms (how long after the cursor stops before requesting). */
  'fim.debounceMs': number
  /** Zen mode (VS Code Appearance ▸ Zen Mode): hides the activity bar, the
   *  side bar, the bottom panel and the status bar until toggled off. */
  'appearance.zenMode': boolean
  /** Show the status bar (VS Code Appearance ▸ Status Bar). */
  'appearance.statusBar': boolean
  /** Show breadcrumbs on top of the editor (VS Code Appearance ▸ Breadcrumbs). */
  'appearance.breadcrumbs': boolean
  /** Sticky scroll: the editor pins the current scope's opening lines (VS Code
   *  Appearance ▸ Sticky Scroll, Monaco stickyScroll.enabled). */
  'appearance.stickyScroll': boolean
  /** Render control characters as glyphs (Monaco renderControlCharacters). */
  'appearance.renderControlCharacters': boolean
  /** Show the hamburger application-menu button at the top of the activity
   *  bar (VS Code's menubar-more toggle). Hiding removes the button entirely —
   *  it does not keep its 48px slot. */
  'appearance.appMenuIcon': boolean
  /** Show the VS Code (code-server) launcher icon in the activity bar. */
  'appearance.vscodeIcon': boolean
  /** Which activity-bar icon opens with the IDE view. VS Code restores the
   *  last used view; this pins the first one instead (default: Source Control). */
  'appearance.defaultSidebarView': 'explorer' | 'search' | 'git' | 'run' | 'extensions' | 'vscode'
}

export const DEFAULT_SETTINGS: IdeSettings = {
  theme: 'dark-modern',
  'editor.fontSize': 13,
  'editor.lineHeight': 20,
  'editor.minimap': true,
  'editor.wordWrap': 'off',
  'editor.renderWhitespace': 'selection',
  'editor.lineNumbers': true,
  'editor.cursorBlinking': 'smooth',
  'editor.smoothScrolling': true,
  'terminal.fontSize': 13,
  'terminal.cursorBlink': true,
  'terminal.scrollback': 5000,
  'terminal.copyOnSelection': false,
  'terminal.lineHeight': 1,
  'terminal.fontWeight': 400,
  'terminal.bellSound': false,
  'fim.enabled': false,
  'fim.debounceMs': 250,
  'appearance.zenMode': false,
  'appearance.statusBar': true,
  'appearance.breadcrumbs': true,
  'appearance.stickyScroll': true,
  'appearance.renderControlCharacters': false,
  // The application-menu icon stays hidden by default (clean activity bar); it
  // remains available from Settings > Appearance and the palette command.
  'appearance.appMenuIcon': false,
  // Visible by default: the VS Code launcher is a first-class entry point now,
  // not an opt-in extra.
  'appearance.vscodeIcon': true,
  // VS Code opens on Source Control when no previous view was stored; same here.
  'appearance.defaultSidebarView': 'git',
}

const STORAGE_KEY = 'dsh-web-ide.settings'

/** Window-parked store so a client hot-reload (pnpm run bundle) keeps the
 *  in-memory settings and subscribers — same lifetime trick as
 *  __dshIdeSessionTerminals in IdeView. */
interface SettingsWindow { __dshIdeSettingsStore?: SettingsStore }
const win = window as unknown as SettingsWindow

type Listener = (s: IdeSettings) => void

class SettingsStore {
  private listeners = new Set<Listener>()
  private data: IdeSettings

  constructor() {
    this.data = { ...DEFAULT_SETTINGS, ...loadPersisted() }
  }

  getSnapshot = (): IdeSettings => { return this.data }

  subscribe = (fn: Listener): (() => void) => {
    this.listeners.add(fn)
    return () => { this.listeners.delete(fn) }
  }

  update(patch: Partial<IdeSettings>): void {
    this.data = { ...this.data, ...patch }
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data)) } catch { /* denied */ }
    for (const fn of this.listeners) fn(this.data)
  }

  /** Replace wholesale (import). Invalid fields fall back to defaults. */
  replace(raw: unknown): void {
    const next = sanitize(raw)
    this.data = next
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)) } catch { /* denied */ }
    for (const fn of this.listeners) fn(this.data)
  }

  /** Exportable JSON (round-trips through replace). */
  export(): string { return JSON.stringify(this.data, null, 2) }
}

/** Bumped when a default flips in a way existing users should follow.
 *  v2: the application-menu icon and the VS Code launcher icon default to hidden.
 *  v3: the VS Code launcher defaults to VISIBLE again (it is a first-class
 *      entry point); the stored v2 value is ambiguous, so it is re-seeded. */
const SETTINGS_VERSION = 3
const VERSION_KEY = 'dsh-web-ide.settingsVersion'

function loadPersisted(): Partial<IdeSettings> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return {}
    const parsed = sanitize(JSON.parse(raw))
    // One-time migration. v2 hid both launcher icons; v3 brings the VS Code
    // launcher back (the menu icon stays hidden). A stored value from an older
    // version is ambiguous, so the defaults are re-seeded once per version.
    const version = Number(localStorage.getItem(VERSION_KEY))
    if (!(version >= SETTINGS_VERSION)) {
      parsed['appearance.appMenuIcon'] = false
      // v3: the launcher is visible again; re-seed so v2 users follow it.
      parsed['appearance.vscodeIcon'] = true
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(parsed))
        localStorage.setItem(VERSION_KEY, String(SETTINGS_VERSION))
      } catch { /* storage denied */ }
    }
    return parsed
  } catch { return {} }
}

function sanitize(raw: unknown): IdeSettings {
  const out = { ...DEFAULT_SETTINGS }
  if (raw == null || typeof raw !== 'object') return out
  const r = raw as Record<string, unknown>
  if (r['theme'] === 'light-modern' || r['theme'] === 'dark-modern' || r['theme'] === 'dark-2026') out['theme'] = r['theme']
  const fontSize = clampInt(r['editor.fontSize'], 6, 40)
  if (fontSize !== undefined) out['editor.fontSize'] = fontSize
  const lineHeight = clampInt(r['editor.lineHeight'], 0, 80)
  if (lineHeight !== undefined) out['editor.lineHeight'] = lineHeight
  if (typeof r['editor.minimap'] === 'boolean') out['editor.minimap'] = r['editor.minimap']
  if (r['editor.wordWrap'] === 'on' || r['editor.wordWrap'] === 'off') out['editor.wordWrap'] = r['editor.wordWrap']
  const ws = r['editor.renderWhitespace']
  if (ws === 'none' || ws === 'boundary' || ws === 'selection' || ws === 'all') out['editor.renderWhitespace'] = ws
  if (typeof r['editor.lineNumbers'] === 'boolean') out['editor.lineNumbers'] = r['editor.lineNumbers']
  const cb = r['editor.cursorBlinking']
  if (cb === 'blink' || cb === 'smooth' || cb === 'phase' || cb === 'expand' || cb === 'solid') out['editor.cursorBlinking'] = cb
  if (typeof r['editor.smoothScrolling'] === 'boolean') out['editor.smoothScrolling'] = r['editor.smoothScrolling']
  const tf = clampInt(r['terminal.fontSize'], 6, 40)
  if (tf !== undefined) out['terminal.fontSize'] = tf
  if (typeof r['terminal.cursorBlink'] === 'boolean') out['terminal.cursorBlink'] = r['terminal.cursorBlink']
  const sb = clampInt(r['terminal.scrollback'], 100, 100000)
  if (sb !== undefined) out['terminal.scrollback'] = sb
  if (typeof r['terminal.copyOnSelection'] === 'boolean') out['terminal.copyOnSelection'] = r['terminal.copyOnSelection']
  const tlh = clampInt(r['terminal.lineHeight'], 1, 2)
  if (tlh !== undefined) out['terminal.lineHeight'] = tlh
  const tfw = clampInt(r['terminal.fontWeight'], 100, 900)
  if (tfw !== undefined) out['terminal.fontWeight'] = tfw
  if (typeof r['terminal.bellSound'] === 'boolean') out['terminal.bellSound'] = r['terminal.bellSound']
  if (typeof r['fim.enabled'] === 'boolean') out['fim.enabled'] = r['fim.enabled']
  const fd = clampInt(r['fim.debounceMs'], 50, 2000)
  if (fd !== undefined) out['fim.debounceMs'] = fd
  if (typeof r['appearance.zenMode'] === 'boolean') out['appearance.zenMode'] = r['appearance.zenMode']
  if (typeof r['appearance.statusBar'] === 'boolean') out['appearance.statusBar'] = r['appearance.statusBar']
  if (typeof r['appearance.breadcrumbs'] === 'boolean') out['appearance.breadcrumbs'] = r['appearance.breadcrumbs']
  if (typeof r['appearance.stickyScroll'] === 'boolean') out['appearance.stickyScroll'] = r['appearance.stickyScroll']
  if (typeof r['appearance.renderControlCharacters'] === 'boolean') out['appearance.renderControlCharacters'] = r['appearance.renderControlCharacters']
  if (typeof r['appearance.appMenuIcon'] === 'boolean') out['appearance.appMenuIcon'] = r['appearance.appMenuIcon']
  if (typeof r['appearance.vscodeIcon'] === 'boolean') out['appearance.vscodeIcon'] = r['appearance.vscodeIcon']
  const dsv = r['appearance.defaultSidebarView']
  if (dsv === 'explorer' || dsv === 'search' || dsv === 'git'
    || dsv === 'run' || dsv === 'extensions' || dsv === 'vscode') out['appearance.defaultSidebarView'] = dsv
  return out
}

function clampInt(v: unknown, min: number, max: number): number | undefined {
  const n = typeof v === 'number' ? v : typeof v === 'string' ? Number(v) : NaN
  if (!Number.isFinite(n)) return undefined
  return Math.min(max, Math.max(min, Math.round(n)))
}

/** The single settings store instance (window-parked across hot reloads). */
export const ideSettings: SettingsStore = win.__dshIdeSettingsStore ??= new SettingsStore()

/** Apply the editor-related settings to a Monaco editor instance. */
export function applyEditorOptions(editor: Monaco.editor.ICodeEditor, s: IdeSettings): void {
  editor.updateOptions({
    fontSize: s['editor.fontSize'],
    lineHeight: s['editor.lineHeight'] === 0 ? 0 : s['editor.lineHeight'],
    minimap: { enabled: s['editor.minimap'] },
    wordWrap: s['editor.wordWrap'],
    renderWhitespace: s['editor.renderWhitespace'],
    lineNumbers: s['editor.lineNumbers'] ? 'on' : 'off',
    cursorBlinking: s['editor.cursorBlinking'],
    smoothScrolling: s['editor.smoothScrolling'],
    // Appearance-menu toggles (VS Code View ▸ Appearance parity).
    stickyScroll: { enabled: s['appearance.stickyScroll'] },
    renderControlCharacters: s['appearance.renderControlCharacters'],
  })
}

/** Terminal options projection (consumed by TerminalPanel at attach time and
 *  on settings change via term.options). */
export function terminalXtermOptions(s: IdeSettings): {
  fontSize: number
  cursorBlink: boolean
  scrollback: number
  lineHeight: number
  fontWeight: number
} {
  return {
    fontSize: s['terminal.fontSize'],
    cursorBlink: s['terminal.cursorBlink'],
    scrollback: s['terminal.scrollback'],
    lineHeight: s['terminal.lineHeight'],
    fontWeight: s['terminal.fontWeight'],
  }
}

/** xterm.js colour theme for an IDE theme id. The terminal panel used to
 *  hardcode the dark palette regardless of the active theme: on the light
 *  theme the shell's own default-foreground output (and anything it repainted)
 *  came out as near-white-on-white, which is what users read as "grey/faded
 *  leftover history" text. */
export function xtermThemeFor(theme: IdeSettings['theme']): Record<string, string> {
  const light = theme === 'light-modern'
  // 2026 Dark: terminal.background #191A1B, terminalCursor.foreground #bfbfbf.
  const background = light ? '#ffffff' : theme === 'dark-2026' ? '#191a1b' : '#1f1f1f'
  return {
    background,
    foreground: light ? '#3b3b3b' : theme === 'dark-2026' ? '#bfbfbf' : '#cccccc',
    cursor: light ? '#000000' : theme === 'dark-2026' ? '#bfbfbf' : '#aeafad',
    cursorAccent: background,
    selectionBackground: light ? 'rgba(0,0,0,0.18)' : theme === 'dark-2026' ? '#3994bc33' : '#264f78',
    selectionForeground: light ? '#1f1f1f' : '#ffffff',
    // Standard ANSI 16-color palette (Dark+ / Light+ variants).
    black: light ? '#000000' : '#000000',
    red: light ? '#cd3131' : '#cd3131',
    green: light ? '#0dbc79' : '#0dbc79',
    yellow: light ? '#949800' : '#e5e510',
    blue: light ? '#0451a5' : '#2472c8',
    magenta: light ? '#bc05bc' : '#bc3fbc',
    cyan: light ? '#0598bc' : '#11a8cd',
    white: light ? '#555555' : '#e5e5e5',
    brightBlack: light ? '#666666' : '#666666',
    brightRed: light ? '#cd3131' : '#f14c4c',
    brightGreen: light ? '#14ce14' : '#23d18b',
    brightYellow: light ? '#b5ba00' : '#f5f543',
    brightBlue: light ? '#0451a5' : '#3b8eea',
    brightMagenta: light ? '#bc05bc' : '#d670d6',
    brightCyan: light ? '#0598bc' : '#29b8db',
    brightWhite: light ? '#a5a5a5' : '#e5e5e5',
  }
}

/**
 * ── Keybindings (VS Code Keyboard Shortcuts parity) ─────────────────────
 * Command ids match the command registry (commands.ts). Defaults mirror the
 * VS Code chords (Cmd/Ctrl overridable per binding).
 */
export interface Keybinding { command: string; keys: string }

const KB_STORAGE_KEY = 'dsh-web-ide.keybindings'

/** Default bindings: serialized key chords, platform-agnostic "Mod" prefix
 *  (Mod = Cmd on macOS, Ctrl elsewhere). */
export const DEFAULT_KEYBINDINGS: Keybinding[] = [
  { command: 'ide.find', keys: 'Mod+F' },
  { command: 'ide.commandPalette', keys: 'Mod+Shift+P' },
  { command: 'ide.settings', keys: 'Mod+,' },
  { command: 'ide.keybindings', keys: 'Mod+K Mod+S' },
  { command: 'ide.save', keys: 'Mod+S' },
  { command: 'ide.toggleTerminal', keys: 'Mod+`' },
  { command: 'ide.toggleSidebar', keys: 'Mod+B' },
  { command: 'ide.problems', keys: 'Mod+Shift+M' },
]

class KeybindingStore {
  private listeners = new Set<(kb: Keybinding[]) => void>()
  private data: Keybinding[]

  constructor() { this.data = loadKb() }

  getSnapshot = (): Keybinding[] => { return this.data }

  subscribe = (fn: (kb: Keybinding[]) => void): (() => void) => {
    this.listeners.add(fn)
    return () => { this.listeners.delete(fn) }
  }

  /** Set one command's binding. keys='' clears it (falls back to command
   *  palette only). Duplicate chords on other commands are removed. */
  set(command: string, keys: string): void {
    const rest = this.data.filter((k) => k.command !== command && k.keys !== keys)
    this.data = [...rest, { command, keys }]
    try { localStorage.setItem(KB_STORAGE_KEY, JSON.stringify(this.data)) } catch { /* denied */ }
    for (const fn of this.listeners) fn(this.data)
  }

  reset(command: string): void {
    const def = DEFAULT_KEYBINDINGS.find((k) => k.command === command)
    const rest = this.data.filter((k) => k.command !== command && !(def && k.keys === def.keys))
    this.data = [...rest, def ?? { command, keys: '' }]
    try { localStorage.setItem(KB_STORAGE_KEY, JSON.stringify(this.data)) } catch { /* denied */ }
    for (const fn of this.listeners) fn(this.data)
  }

  resetAll(): void {
    this.data = DEFAULT_KEYBINDINGS.map((k) => ({ ...k }))
    try { localStorage.setItem(KB_STORAGE_KEY, JSON.stringify(this.data)) } catch { /* denied */ }
    for (const fn of this.listeners) fn(this.data)
  }

  exportAll(): string { return JSON.stringify({ keybindings: this.data }, null, 2) }

  keysFor(command: string): string {
    return this.data.find((k) => k.command === command)?.keys ?? ''
  }
}

function loadKb(): Keybinding[] {
  try {
    const raw = localStorage.getItem(KB_STORAGE_KEY)
    if (!raw) return DEFAULT_KEYBINDINGS.map((k) => ({ ...k }))
    const parsed = JSON.parse(raw)
    if (!Array.isArray(parsed)) return DEFAULT_KEYBINDINGS.map((k) => ({ ...k }))
    const out: Keybinding[] = []
    for (const e of parsed) {
      if (e && typeof e === 'object' && typeof e.command === 'string' && typeof e.keys === 'string') out.push({ command: e.command, keys: e.keys })
    }
    return out
  } catch { return DEFAULT_KEYBINDINGS.map((k) => ({ ...k })) }
}

interface KbWindow { __dshIdeKeybindings?: KeybindingStore }
const kbWin = window as unknown as KbWindow
export const ideKeybindings: KeybindingStore = kbWin.__dshIdeKeybindings ??= new KeybindingStore()

/** Normalize a KeyboardEvent into a serialized chord like "Mod+Shift+P".
 *  Mod resolves to Cmd on macOS, Ctrl elsewhere. Returns '' for unprintable
 *  solo modifiers. */
export function eventToChord(e: KeyboardEvent, isMac: boolean): string {
  // Mod = Cmd on mac / Ctrl elsewhere; on mac an explicit Ctrl chord is also
  // accepted (VS Code lets both Cmd and Ctrl combos be bound).
  const mod = isMac ? (e.metaKey || e.ctrlKey) : e.ctrlKey
  const parts: string[] = []
  if (mod) parts.push('Mod')
  if (e.shiftKey) parts.push('Shift')
  if (e.altKey) parts.push('Alt')
  const k = e.key
  if (k === 'Shift' || k === 'Control' || k === 'Meta' || k === 'Alt' || k === 'Dead') return ''
  let key = k
  if (key.length === 1) key = key.toUpperCase()
  parts.push(key)
  return parts.join('+')
}

/** Match a keydown event against a serialized chord. */
export function chordMatches(chord: string, e: KeyboardEvent, isMac: boolean): boolean {
  if (!chord) return false
  return eventToChord(e, isMac) === chord
}

/**
 * ── Snippets (VS Code User Snippets parity) ─────────────────────────────
 * Per-language JSON snippet maps, persisted in localStorage. Shape mirrors
 * VS Code: { [prefix]: { prefix, body: string[], description } }.
 */
export interface SnippetDef { prefix: string; body: string[]; description?: string }

const SN_STORAGE_KEY = 'dsh-web-ide.snippets'

class SnippetStore {
  private listeners = new Set<() => void>()
  private data: Record<string, Record<string, SnippetDef>>

  constructor() {
    this.data = loadSnippets()
  }

  getSnapshot = (): Record<string, Record<string, SnippetDef>> => { return this.data }

  subscribe = (fn: () => void): (() => void) => {
    this.listeners.add(fn)
    return () => { this.listeners.delete(fn) }
  }

  /** Set one language's snippet map (parsed JSON or {}). */
  setLanguage(languageId: string, map: Record<string, SnippetDef>): void {
    const next = { ...this.data }
    if (Object.keys(map).length === 0) delete next[languageId]
    else next[languageId] = map
    this.data = next
    try { localStorage.setItem(SN_STORAGE_KEY, JSON.stringify(next)) } catch { /* denied */ }
    for (const fn of this.listeners) fn()
  }

  snippetsFor(languageId: string): SnippetDef[] {
    const map = this.data[languageId]
    return map ? Object.values(map) : []
  }
}

function loadSnippets(): Record<string, Record<string, SnippetDef>> {
  try {
    const raw = localStorage.getItem(SN_STORAGE_KEY)
    if (!raw) return {}
    const parsed = JSON.parse(raw)
    if (parsed == null || typeof parsed !== 'object' || Array.isArray(parsed)) return {}
    return parsed as Record<string, Record<string, SnippetDef>>
  } catch { return {} }
}

interface SnWindow { __dshIdeSnippets?: SnippetStore }
const snWin = window as unknown as SnWindow
export const ideSnippets: SnippetStore = snWin.__dshIdeSnippets ??= new SnippetStore()
