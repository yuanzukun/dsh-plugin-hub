import { randomUUID } from 'node:crypto';
import { externalGroup, cleanReceipt } from './external.mjs';
/**
 * Durable spawn registry for dsh-plugin-task-coordinator.
 *
 * Absorbed from the SCDP workstream idea (junwei529/session-coordinator-dsh),
 * kept deliberately lightweight: one JSON file records which sessions the
 * coordinator spawned, under which team, and with what intent — so after a
 * host restart the supervisor can still answer "which tasks are mine and how
 * do they group", which native session listing alone cannot tell it.
 *
 * Design rules:
 *  - never throws on load/save: a corrupt or missing file degrades to an
 *    empty registry (corrupt files are preserved as `*.corrupt-<ts>` for
 *    inspection instead of being silently dropped);
 *  - writes are near-atomic (temp file + rename);
 *  - the registry is capped (`maxEntries`) and pruned oldest-first.
 */

import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';

const REGISTRY_FORMAT_VERSION = 1;

export class SpawnRegistry {
  /**
   * @param {string} filePath absolute path of the registry JSON file
   * @param {{ maxEntries?: number; now?: () => number }} [options]
   */
  constructor(filePath, options = {}) {
    this.filePath = filePath;
    this.maxEntries = Number.isFinite(options.maxEntries) && options.maxEntries > 0
      ? Math.floor(options.maxEntries)
      : 500;
    this.now = typeof options.now === 'function' ? options.now : () => Date.now();
    /** @type {Map<string, { team?: string; createdAt: number; title?: string; promptExcerpt?: string; expectedWorkspace?: string; externalRef?: string }>} */
    this.entries = new Map();
    this.loaded = false;
    this.loadState = 'unloaded';
  }

  /** Load lazily and tolerantly; safe to call repeatedly. */
  ensureLoaded() {
    if (this.loaded) return;
    this.loaded = true;
    if (!existsSync(this.filePath)) { this.loadState = 'missing'; return; }
    try {
      const parsed = JSON.parse(readFileSync(this.filePath, 'utf8'));
      const raw = parsed && typeof parsed === 'object' ? parsed.entries : null;
      if (!raw || typeof raw !== 'object' || Array.isArray(raw)) { this.loadState = 'invalid'; return; }
      let malformed = parsed.version !== undefined && parsed.version !== REGISTRY_FORMAT_VERSION;
      if (raw && typeof raw === 'object') {
        for (const [sessionId, entry] of Object.entries(raw)) {
          if (typeof sessionId === 'string' && entry && typeof entry === 'object' && Number.isFinite(entry.createdAt)) {
            this.entries.set(sessionId, {
              createdAt: entry.createdAt,
              ...(Array.isArray(entry.bridgeReceipts) ? { bridgeReceipts: entry.bridgeReceipts.map(cleanReceipt).filter(Boolean).slice(-100) } : {}),
              ...(Number.isSafeInteger(entry.receiptSeq) && entry.receiptSeq >= 0 ? { receiptSeq: entry.receiptSeq } : {}),
              ...(typeof entry.team === 'string' && entry.team.length > 0 ? { team: entry.team } : {}),
              ...(typeof entry.title === 'string' && entry.title.length > 0 ? { title: entry.title } : {}),
              ...(typeof entry.promptExcerpt === 'string' && entry.promptExcerpt.length > 0 ? { promptExcerpt: entry.promptExcerpt } : {}),
              ...(typeof entry.depth === 'number' && Number.isFinite(entry.depth) && entry.depth >= 1 ? { depth: entry.depth } : {}),
              ...(typeof entry.parentSessionId === 'string' && entry.parentSessionId.length > 0 ? { parentSessionId: entry.parentSessionId } : {}),
              ...(typeof entry.expectedWorkspace === 'string' && entry.expectedWorkspace.length > 0 ? { expectedWorkspace: entry.expectedWorkspace } : {}),
              // externalRef (0.25.0): free-form external caller reference for
              // cross-agent correspondence (bridge dispatchers record which
              // external conversation/wave spawned a session). Stored and echoed
              // verbatim, never parsed. Same field-level whitelist discipline as
              // expectedWorkspace (0.19.0 precedent): malformed values drop on load.
              ...(typeof entry.externalRef === 'string' && entry.externalRef.length > 0 ? { externalRef: entry.externalRef } : {}),
            });
          } else malformed = true;
        }
      }
      this.loadState = malformed ? 'invalid' : 'ready';
    } catch {
      // Preserve the broken file for inspection, start clean.
      try { renameSync(this.filePath, `${this.filePath}.corrupt-${this.now()}`); } catch { /* best effort */ }
      this.entries.clear();
      this.loadState = 'invalid';
    }
  }

  /**
   * Record one spawned session. Existing entries are merged (never lost).
   * @param {string} sessionId
   * @param {{ team?: string; title?: string; promptExcerpt?: string; createdAt?: number; depth?: number; parentSessionId?: string; expectedWorkspace?: string; externalRef?: string }} entry
   */
  record(sessionId, entry = {}) {
    this.ensureLoaded();
    const existing = this.entries.get(sessionId);
    const merged = {
      ...(existing?.bridgeReceipts ? { bridgeReceipts: existing.bridgeReceipts, receiptSeq: existing.receiptSeq } : {}),
      createdAt: existing?.createdAt ?? (Number.isFinite(entry.createdAt) ? entry.createdAt : this.now()),
      ...(entry.team !== undefined || existing?.team !== undefined
        ? { team: typeof entry.team === 'string' && entry.team.length > 0 ? entry.team : existing?.team }
        : {}),
      ...(entry.title !== undefined || existing?.title !== undefined
        ? { title: typeof entry.title === 'string' && entry.title.length > 0 ? entry.title : existing?.title }
        : {}),
      ...(entry.promptExcerpt !== undefined || existing?.promptExcerpt !== undefined
        ? { promptExcerpt: typeof entry.promptExcerpt === 'string' && entry.promptExcerpt.length > 0 ? entry.promptExcerpt : existing?.promptExcerpt }
        : {}),
      ...(entry.depth !== undefined || existing?.depth !== undefined
        ? { depth: typeof entry.depth === 'number' && Number.isFinite(entry.depth) && entry.depth >= 1 ? entry.depth : existing?.depth }
        : {}),
      ...(entry.parentSessionId !== undefined || existing?.parentSessionId !== undefined
        ? { parentSessionId: typeof entry.parentSessionId === 'string' && entry.parentSessionId.length > 0 ? entry.parentSessionId : existing?.parentSessionId }
        : {}),
      ...(entry.expectedWorkspace !== undefined || existing?.expectedWorkspace !== undefined
        ? { expectedWorkspace: typeof entry.expectedWorkspace === 'string' && entry.expectedWorkspace.length > 0 ? entry.expectedWorkspace : existing?.expectedWorkspace }
        : {}),
      ...(entry.externalRef !== undefined || existing?.externalRef !== undefined
        ? { externalRef: typeof entry.externalRef === 'string' && entry.externalRef.length > 0 ? entry.externalRef : existing?.externalRef }
        : {}),
    };
    if (merged.team === undefined) delete merged.team;
    if (merged.title === undefined) delete merged.title;
    if (merged.promptExcerpt === undefined) delete merged.promptExcerpt;
    if (merged.depth === undefined) delete merged.depth;
    if (merged.parentSessionId === undefined) delete merged.parentSessionId;
    if (merged.expectedWorkspace === undefined) delete merged.expectedWorkspace;
    if (merged.externalRef === undefined) delete merged.externalRef;
    this.entries.set(sessionId, merged);
    this.loadState = 'ready';
    this.prune();
    this.save();
  }

  /** @returns {{ team?: string; createdAt: number; title?: string; promptExcerpt?: string; expectedWorkspace?: string; externalRef?: string } | undefined} */
  get(sessionId) {
    this.ensureLoaded();
    return this.entries.get(sessionId);
  }

  recordBridgeReceipt(sessionId, value) {
    this.ensureLoaded();
    const entry = this.entries.get(sessionId);
    if (!entry) return false; // Do not invent ownership for existing unregistered sessions.
    const seq = Math.max(entry.receiptSeq ?? 0, ...((entry.bridgeReceipts ?? []).map(r => r.seq)), 0) + 1;
    const receipt = cleanReceipt({ ...value, seq });
    if (!receipt) return false;
    entry.bridgeReceipts = [...(entry.bridgeReceipts ?? []), receipt].slice(-100);
    entry.receiptSeq = seq;
    return this.save();
  }

  /** Minimal, detached topology projection; never expose prompts or local paths. */
  snapshot() {
    this.ensureLoaded();
    return { state: this.loadState, maxEntries: this.maxEntries, entries: [...this.entries].map(([sessionId, row]) => ({
      sessionId, externalGroup: externalGroup({ sessionId, ...row }),
      bridgeReceipts: (row.bridgeReceipts ?? []).map(r => ({ ...r })), receiptSeq: row.receiptSeq ?? 0,
      createdAt: row.createdAt, parentSessionId: row.parentSessionId, depth: row.depth, title: row.title, team: row.team,
    })) };
  }

  /** @returns {string[]} session ids recorded under one team, oldest first */
  listTeam(team) {
    this.ensureLoaded();
    return [...this.entries.entries()]
      .filter(([, entry]) => entry.team === team)
      .sort((a, b) => a[1].createdAt - b[1].createdAt)
      .map(([sessionId]) => sessionId);
  }

  /** @returns {string[]} all known team names */
  teams() {
    this.ensureLoaded();
    return [...new Set([...this.entries.values()].map((entry) => entry.team).filter((team) => typeof team === 'string'))];
  }

  prune() {
    if (this.entries.size <= this.maxEntries) return;
    const ordered = [...this.entries.entries()].sort((a, b) => a[1].createdAt - b[1].createdAt);
    const dropCount = this.entries.size - this.maxEntries;
    for (let index = 0; index < dropCount; index += 1) {
      this.entries.delete(ordered[index][0]);
    }
  }

  save() {
    try {
      mkdirSync(dirname(this.filePath), { recursive: true });
      const payload = JSON.stringify(
        { version: REGISTRY_FORMAT_VERSION, updatedAt: this.now(), entries: Object.fromEntries(this.entries) },
        null,
        2,
      );
      const tmp = `${this.filePath}.tmp-${randomUUID()}`;
      writeFileSync(tmp, payload, 'utf8');
      for (let attempt = 0; ; attempt++) {
        try { renameSync(tmp, this.filePath); break; }
        catch (error) {
          if (attempt >= 3 || !['EBUSY', 'EPERM', 'EACCES'].includes(error?.code)) throw error;
          Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 10 * (attempt + 1));
        }
      }
      return true;
    } catch {
      // The registry is an enhancement, never a failure path for coordination.
      return false;
    }
  }
}
