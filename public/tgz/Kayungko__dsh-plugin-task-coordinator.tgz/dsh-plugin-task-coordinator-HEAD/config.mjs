/**
 * Configuration resolution for dsh-plugin-task-coordinator.
 * Pure module: no harness imports, fully unit-testable.
 */

import { DEFAULT_TITLE_TYPES } from './title.mjs';

/**
 * Accepted `workspacePolicy` values (0.19.0). 'grouping' is a RESERVED
 * future tier (forced-grouping incl. worktree→main-repo attachment with a
 * git -C kickoff rewrite) and is rejected as invalid until it ships — see
 * research/workspace-placement-fallback.md §4③.
 */
export const WORKSPACE_POLICIES = Object.freeze(['exact', 'ancestor']);

export const DEFAULTS = Object.freeze({
  /** Master switch. When false the plugin mounts no tools at all. */
  enabled: true,
  /** Allow agents whose session origin is 'subagent' to use coordination tools. */
  allowSubagentUse: false,
  /** task_list hides subagent-origin sessions unless asked explicitly. */
  includeSubagentsInList: false,
  /**
   * Spawn-title rule (format: MMDD｜类型｜主题).
   * The date prefix is always stamped from the session creation time in
   * `titleTimeZone` — the model only supplies 类型｜主题.
   */
  /** Allowed 类型 values (fully customizable — an English set works: values match exactly or case-insensitively); anything else falls back to `titleFallbackType`. */
  titleTypes: DEFAULT_TITLE_TYPES,
  /** 类型 used when the caller's type is missing or not in `titleTypes`. */
  titleFallbackType: '探索',
  /** Topic used when both `title` and the kickoff prompt yield nothing. */
  titleFallbackTopic: '新任务',
  /** Max characters kept for 主题 (sidebar-friendly truncation). */
  titleMaxTopicChars: 16,
  /** IANA time zone for the MMDD date prefix. */
  titleTimeZone: 'Asia/Shanghai',
  /**
   * Durable spawn registry (workstream/team memory surviving host restarts).
   * Default file path: <DSH_HOME or ~/.dsh>/task-coordinator/registry.json
   */
  registryFile: '',
  /** Max spawn records kept in the registry (oldest pruned first). */
  registryMaxEntries: 500,
  /** Max tasks one task_spawn_batch call may create. */
  maxBatchSpawn: 6,
  /**
   * Dispatch confirmation gate: when true, task_spawn_batch calls with at
   * least `confirmBatchThreshold` tasks are rejected unless they carry a
   * confirmationId minted by an approved task_confirm call. Keeps big
   * fan-outs user-approved instead of silently decided.
   */
  confirmBeforeBatch: true,
  /** Batch size (>=) at which the confirmation gate engages. */
  confirmBatchThreshold: 2,
  /**
   * Recursion governance: max spawn depth of the coordination tree.
   * Tasks spawned by a never-spawned (root) session are depth 1; tasks they
   * spawn are depth 2; deeper spawn attempts are rejected so coordinators at
   * the bottom fall back to subagents instead of growing the session tree.
   */
  maxSpawnDepth: 2,
  /** Max pending inbox messages a single target may hold before task_send refuses. */
  maxQueuePerTask: 5,
  /** Minimum interval between task_send/task_spawn kickoffs toward one target. */
  minSendIntervalMs: 2000,
  /** Default timeout for task_wait. */
  waitDefaultTimeoutMs: 120000,
  /** Hard cap for task_wait timeout arguments. */
  waitMaxTimeoutMs: 600000,
  /** Max characters kept per message excerpt in progress reports. */
  excerptChars: 400,
  /** Max messages included in progress reports. */
  progressTailMessages: 6,
  /**
   * Workspace placement policy for spawned tasks (0.19.0).
   *  - 'exact'    (conservative tier): only an exact cwd→workspace-path match
   *    attaches; everything else stays cwd/ungrouped (pre-0.19 semantics).
   *  - 'ancestor' (default): additionally, a cwd that is a true subdirectory
   *    of a registered workspace is normalized up to the NEAREST ancestor
   *    workspace (the host derives the session cwd from the workspace path);
   *    git worktrees are identified via the .git-file probe and deliberately
   *    left ungrouped (isolation preserved) with a strong receipt warning.
   *  - 'grouping' is RESERVED for a future release and rejected as invalid.
   */
  workspacePolicy: 'ancestor',
});

/**
 * Merge user config over defaults, rejecting wrong types instead of guessing.
 * @param {unknown} input raw plugin config (usually an object from cordis.yml)
 * @returns {typeof DEFAULTS & Record<string, unknown>}
 */
export function resolveConfig(input = {}) {
  const source = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
  const config = { ...DEFAULTS };
  const booleans = ['enabled', 'allowSubagentUse', 'includeSubagentsInList', 'confirmBeforeBatch'];
  const numbers = [
    'maxQueuePerTask',
    'minSendIntervalMs',
    'waitDefaultTimeoutMs',
    'waitMaxTimeoutMs',
    'excerptChars',
    'progressTailMessages',
    'titleMaxTopicChars',
    'registryMaxEntries',
    'maxBatchSpawn',
    'confirmBatchThreshold',
    'maxSpawnDepth',
  ];
  const strings = ['titleFallbackType', 'titleFallbackTopic', 'titleTimeZone', 'registryFile'];
  for (const key of booleans) {
    if (source[key] !== undefined) {
      if (typeof source[key] !== 'boolean') throw new TypeError(`task-coordinator config "${key}" must be boolean`);
      config[key] = source[key];
    }
  }
  for (const key of numbers) {
    if (source[key] !== undefined) {
      const value = source[key];
      if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) {
        throw new TypeError(`task-coordinator config "${key}" must be a finite non-negative number`);
      }
      config[key] = value;
    }
  }
  for (const key of strings) {
    if (source[key] !== undefined) {
      if (typeof source[key] !== 'string') throw new TypeError(`task-coordinator config "${key}" must be string`);
      config[key] = source[key];
    }
  }
  if (source.titleTypes !== undefined) {
    if (!Array.isArray(source.titleTypes) || source.titleTypes.length === 0
      || source.titleTypes.some((value) => typeof value !== 'string' || value.trim().length === 0)) {
      throw new TypeError('task-coordinator config "titleTypes" must be a non-empty array of non-empty strings');
    }
    config.titleTypes = source.titleTypes.map((value) => value.trim());
  }
  if (source.workspacePolicy !== undefined) {
    const policy = source.workspacePolicy;
    if (typeof policy !== 'string' || !WORKSPACE_POLICIES.includes(policy)) {
      throw new TypeError(
        `task-coordinator config "workspacePolicy" must be one of ${WORKSPACE_POLICIES.map((value) => `'${value}'`).join(' | ')}`
        + ` ('grouping' is reserved for a future release and is not accepted yet)`,
      );
    }
    config.workspacePolicy = policy;
  }
  // 0.27.0: bridge tunables sub-object passthrough (the old task-bridge-runtime
  // patch-row keys: defaultCwd / tokenFile / maxBodyBytes / spawnWindowMs /
  // spawnMaxPerWindow). The whitelist above would silently drop `bridge` and
  // kill the patch-row fallback layer index.mjs documents — value validation
  // and defaults stay owned by bridge-runtime.mjs resolveConfig (single source
  // of truth); this layer only guards the shape.
  if (source.bridge !== undefined) {
    if (typeof source.bridge !== 'object' || source.bridge === null || Array.isArray(source.bridge)) {
      throw new TypeError('task-coordinator config "bridge" must be an object');
    }
    config.bridge = source.bridge;
  }
  if (config.maxQueuePerTask < 1) config.maxQueuePerTask = 1;
  if (config.titleMaxTopicChars < 1) config.titleMaxTopicChars = 1;
  if (config.registryMaxEntries < 1) config.registryMaxEntries = 1;
  if (config.maxBatchSpawn < 1) config.maxBatchSpawn = 1;
  if (config.confirmBatchThreshold < 1) config.confirmBatchThreshold = 1;
  if (config.maxSpawnDepth < 1) config.maxSpawnDepth = 1;
  if (config.waitMaxTimeoutMs < config.waitDefaultTimeoutMs) {
    config.waitDefaultTimeoutMs = config.waitMaxTimeoutMs;
  }
  return config;
}
