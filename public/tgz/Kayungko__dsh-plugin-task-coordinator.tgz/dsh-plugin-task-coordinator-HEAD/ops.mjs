import { decodeCursor, feedbackPage, messageProjection, RECENT_SCAN_WINDOW } from './feedback.mjs';
import { EXTERNAL_CALLER } from './external.mjs';
/**
 * Session operations for dsh-plugin-task-coordinator.
 *
 * Factory module: `createOps(deps)` receives every harness object through
 * dependency injection so the logic is unit-testable outside the host process.
 *
 * Expected deps (host wiring in index.mjs):
 *  - sessionController: ctx.sessionController (Remote-facade signatures:
 *    list(request, signal), search(request, signal), create(request),
 *    prompt(request, signal), cancel(request), rename(request),
 *    resolveAgent(sessionId), inspect(sessionId, signal))
 *  - agents: ctx.agents registry, `.get(sessionId) -> live agent | undefined`
 *  - createUserMessage: message factory from @deepseek-ai/dsh-llm
 *  - config: resolved plugin config (config.mjs)
 *  - limiter: SendLimiter instance (safety.mjs)
 *  - registry: SpawnRegistry instance (registry.mjs), optional
 *  - uuid: () => string unique request/session id source
 *  - probeWorktree: (cwd) => boolean fs probe (0.19.0, optional): true when
 *    `<cwd>/.git` is a FILE (linked-worktree marker). Injected by index.mjs;
 *    any absence or exception degrades to "not a worktree" inside ops.
 *
 * Failure shape is `{ ok: false, code, error }` with stable machine-readable
 * codes (absorbed from SCDP's typed-error idea), so callers can branch
 * programmatically instead of parsing prose.
 */

import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { blocksToText, checkCaller, checkTarget, excerpt } from './safety.mjs';
import { buildSpawnTitle } from './title.mjs';
import { uiStrings } from './i18n.mjs';

/** Operation-level failure codes (guard denials carry their own codes). */
export const OP_CODES = Object.freeze({
  BAD_REQUEST: 'bad-request',
  SPAWN_CREATE_FAILED: 'spawn-create-failed',
  KICKOFF_REJECTED: 'kickoff-rejected',
  SPAWN_DEPTH_EXCEEDED: 'spawn-depth-exceeded',
  BATCH_ALL_FAILED: 'batch-all-failed',
  CONFIRMATION_REQUIRED: 'confirmation-required',
  CONFIRMATION_MISMATCH: 'confirmation-mismatch',
  CONFIRM_CANCELLED: 'confirm-cancelled',
  CONFIRM_ABORTED: 'confirm-aborted',
  NO_QUESTION_CHANNEL: 'no-question-channel',
  DELEGATED_CALLER: 'delegated-caller',
  CALLER_NOT_LIVE: 'caller-not-live',
  TARGET_BUSY: 'target-busy',
  TARGET_VANISHED: 'target-vanished',
  RESOLVE_FAILED: 'resolve-failed',
  TARGET_COLD: 'target-cold',
  WAIT_FAILED: 'wait-failed',
  CANCEL_REJECTED: 'cancel-rejected',
  WORKSPACE_NOT_FOUND: 'workspace-not-found',
  WORKSPACE_OP_FAILED: 'workspace-op-failed',
  MIGRATE_UNAVAILABLE: 'migrate-unavailable',
  MIGRATE_BUSY: 'migrate-busy',
  MIGRATE_FAILED: 'migrate-failed',
  MIGRATE_DISABLED: 'migrate-disabled',
  MODEL_UNAVAILABLE: 'model-unavailable',
  MODEL_SELECT_FAILED: 'model-select-failed',
  CATALOG_UNAVAILABLE: 'catalog-unavailable',
});

/**
 * Host core version detection (0.25.1): the migrate clone route
 * (sessions.create + flush) is only valid on host core < 0.1.5. On
 * >= 0.1.5-rc.1 the upstream sessions.flush silently no-ops for
 * plugin-created sessions (the clone "succeeds" in-process then vanishes on
 * restart) and readSession throws on seeded/forked sessions — see
 * research/host-upgrade-drift-0.1.2-0.1.5.md face 1 P0/P1. The guard reads
 * @deepseek-ai/dsh-session's package.json version (resolved from the plugin's
 * own location via createRequire — the plugin runs inside the host process,
 * so the peer package always resolves), compares the numeric major.minor.patch
 * tuple, and refuses migrate on >= 0.1.5. A failed probe returns null and
 * fail-opens (pre-0.25.1 behavior) with a single warning.
 */

const MIGRATE_GUARD_MIN = [0, 1, 5];

let cachedHostCoreVersion;
let hostCoreVersionSettled = false;

/**
 * Parse a `major.minor.patch[-prerelease]` string into a numeric triple.
 * Returns null for anything that is not a plain three-segment version
 * (missing/blank/non-string/leading garbage all fail open).
 * @param {string|null|undefined} version
 * @returns {[number, number, number]|null}
 */
export function parseCoreVersion(version) {
  if (typeof version !== 'string' || version.trim().length === 0) return null;
  const match = /^(\d+)\.(\d+)\.(\d+)(?:[-+].*)?$/.exec(version.trim());
  if (!match) return null;
  return [Number(match[1]), Number(match[2]), Number(match[3])];
}

/**
 * Host-core guard decision (0.25.1). True = refuse migrate. Comparison is
 * numeric major.minor.patch only: prerelease identifiers are ignored, so
 * 0.1.5-rc.1 and 0.1.5-0 both count as the new core (>= 0.1.5). null /
 * unparseable / missing all fail open (false — keep the pre-0.25.1 behavior).
 * @param {string|null|undefined} coreVersion - the resolved @deepseek-ai/dsh-session version
 * @returns {boolean}
 */
export function shouldGuardMigrate(coreVersion) {
  const triple = parseCoreVersion(coreVersion);
  if (!triple) return false;
  for (let i = 0; i < 3; i += 1) {
    if (triple[i] > MIGRATE_GUARD_MIN[i]) return true;
    if (triple[i] < MIGRATE_GUARD_MIN[i]) return false;
  }
  return true;
}

/**
 * Lazily resolve the host core version (module-level cache; settled once per
 * process). A failed resolution — the peer package does not resolve, or its
 * version field is absent/unparsable — returns null (fail-open) and warns
 * exactly once. Exported so verify-installed.mjs can assert the REAL host
 * (0.1.2-rc.1) resolves and does not trigger the guard.
 * @param {{ warn?: (message: string) => void }|undefined} logger
 * @returns {string|null}
 */
export function detectHostCoreVersion(logger) {
  if (hostCoreVersionSettled) return cachedHostCoreVersion;
  hostCoreVersionSettled = true;
  let failure;
  try {
    const require = createRequire(import.meta.url);
    const pkgPath = require.resolve('@deepseek-ai/dsh-session/package.json');
    const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'));
    const version = typeof pkg?.version === 'string' && pkg.version.trim().length > 0 ? pkg.version.trim() : null;
    cachedHostCoreVersion = parseCoreVersion(version) ? version : null;
    if (cachedHostCoreVersion === null) failure = 'unreadable or unparsable @deepseek-ai/dsh-session version';
  } catch (error) {
    cachedHostCoreVersion = null;
    failure = error?.message ?? error;
  }
  if (cachedHostCoreVersion === null && failure) {
    try {
      logger?.warn?.(`task-coordinator: host core version probe failed (${failure}); migrate guard fail-open — keeping the pre-0.25.1 migrate behavior`);
    } catch {
      // a failing logger must never break the op
    }
  }
  return cachedHostCoreVersion;
}

/**
 * Resolve the workspace a spawn should attach to: the workspace (if any)
 * whose membership contains the caller or one of its recorded spawn
 * ancestors. Pure and failure-tolerant — any missing piece yields undefined
 * and the caller falls back to plain cwd semantics.
 * @param {string} callerSessionId - the session doing the spawning
 * @param {object|null} registry - durable spawn registry (parent chain)
 * @param {Function|undefined} listWorkspaces - lazy host registry snapshot
 * @returns {string|undefined} workspaceId to pass to sessionController.create
 */
export function resolveCallerWorkspaceId(callerSessionId, registry, listWorkspaces) {
  if (typeof callerSessionId !== 'string' || callerSessionId.length === 0) return undefined;
  if (typeof listWorkspaces !== 'function') return undefined;
  let workspaces;
  try {
    workspaces = listWorkspaces();
  } catch {
    return undefined;
  }
  if (!Array.isArray(workspaces) || workspaces.length === 0) return undefined;
  const candidates = new Set([callerSessionId]);
  let entry = registry?.get?.(callerSessionId);
  let hops = 0;
  while (entry?.parentSessionId && hops < 8) {
    candidates.add(entry.parentSessionId);
    entry = registry?.get?.(entry.parentSessionId);
    hops += 1;
  }
  const hit = workspaces.find(
    (workspace) => Array.isArray(workspace?.sessionIds) && workspace.sessionIds.some((id) => candidates.has(id)),
  );
  return typeof hit?.id === 'string' && hit.id.length > 0 ? hit.id : undefined;
}

/**
 * Best-effort path lookup for a workspace id (result payload only — the host
 * derives the real cwd itself). Failure-tolerant like resolveCallerWorkspaceId.
 * @param {string} workspaceId - workspace to look up
 * @param {Function|undefined} listWorkspaces - lazy host registry snapshot
 * @returns {string|undefined} the workspace path when known
 */
export function workspacePathOf(workspaceId, listWorkspaces) {
  if (typeof workspaceId !== 'string' || workspaceId.length === 0) return undefined;
  if (typeof listWorkspaces !== 'function') return undefined;
  let workspaces;
  try {
    workspaces = listWorkspaces();
  } catch {
    return undefined;
  }
  if (!Array.isArray(workspaces)) return undefined;
  const hit = workspaces.find((workspace) => workspace?.id === workspaceId);
  return typeof hit?.path === 'string' && hit.path.length > 0 ? hit.path : undefined;
}

/**
 * Normalize a filesystem path for exact workspace matching. Platform-aware
 * (0.12.1): win32 unifies separators to backslash, strips trailing
 * separators (drive roots kept) and folds case (NTFS is case-insensitive);
 * darwin folds case only (default volumes are case-insensitive); POSIX keeps
 * case and treats backslash as a regular filename character. 0.19.0: pure
 * `.` path segments are now stripped (`D:\repo\.` == `D:\repo`), closing the
 * lexical/physical canon gap the placement research surfaced (S21) — the
 * host's realpath resolves those, so the pre-filter must too. `..` segments
 * are deliberately NOT resolved (that needs physical filesystem access; the
 * host entity's realpath validation on attach stays the final authority).
 * Not a general realpath.
 * @param {string} value - raw path
 * @param {string} [platform] - override for tests; defaults to process.platform
 * @returns {string} comparable form
 */
export function normalizeWorkspacePath(value, platform = process.platform) {
  let path = String(value).trim();
  if (platform === 'win32') {
    path = path.replaceAll('/', '\\');
    const unc = path.startsWith('\\\\');
    if (unc) path = path.slice(2);
    while (path.length > 1 && path.endsWith('\\') && !/^[A-Za-z]:\\$/.test(path)) path = path.slice(0, -1);
    let joined = path.split('\\').filter((segment) => segment !== '.' && segment !== '').join('\\');
    if (/^[A-Za-z]:$/.test(joined)) joined += '\\'; // bare drive letter == drive root
    if (unc) joined = `\\\\${joined}`;
    if (joined.length === 0) joined = '.';
    return joined.toLowerCase();
  }
  const rooted = path.startsWith('/');
  while (path.length > 1 && path.endsWith('/')) path = path.slice(0, -1);
  let joined = path.split('/').filter((segment) => segment !== '.' && segment !== '').join('/');
  if (rooted) joined = `/${joined}`;
  if (joined.length === 0) joined = rooted ? '/' : '.';
  return platform === 'darwin' ? joined.toLowerCase() : joined;
}

/** Placement enum reported on spawn/batch receipts (0.19.0). */
export const WORKSPACE_PLACEMENTS = Object.freeze([
  'exact-match',
  'caller-inherited',
  'ancestor-normalized',
  'ungrouped-worktree',
  'ungrouped',
]);

/**
 * The single source of truth for lexical workspace matching (0.19.0),
 * shared by the spawn placement chain and task_list's ungrouped filter.
 * Resolves one directory against the registered workspace snapshot in two
 * tiers — both PURE lexical judgments over normalizeWorkspacePath; the host
 * entity's realpath validation on attach remains the final authority:
 *  - exact: the workspace whose normalized path equals the normalized cwd;
 *  - ancestor: the NEAREST (longest normalized-path prefix) workspace that
 *    strictly CONTAINS the cwd as a subdirectory — a cwd equal to the
 *    workspace path is exact, never ancestor.
 * Failure-tolerant like the other registry helpers: any missing or throwing
 * dependency yields `{ exact: undefined, ancestor: undefined }`.
 * @param {string|undefined} cwd - directory to resolve
 * @param {Function|undefined} listWorkspaces - lazy host registry snapshot
 * @param {string} [platform] - normalization override for tests
 * @returns {{ exact: object|undefined, ancestor: object|undefined }}
 */
export function matchWorkspacePaths(cwd, listWorkspaces, platform) {
  const none = { exact: undefined, ancestor: undefined };
  if (typeof cwd !== 'string' || cwd.trim().length === 0) return none;
  if (typeof listWorkspaces !== 'function') return none;
  let workspaces;
  try {
    workspaces = listWorkspaces();
  } catch {
    return none;
  }
  if (!Array.isArray(workspaces)) return none;
  const target = normalizeWorkspacePath(cwd, platform);
  const separator = (platform ?? process.platform) === 'win32' ? '\\' : '/';
  let exact;
  let ancestor;
  let ancestorLength = -1;
  for (const workspace of workspaces) {
    if (typeof workspace?.path !== 'string' || workspace.path.length === 0) continue;
    const normalized = normalizeWorkspacePath(workspace.path, platform);
    if (normalized.length === 0) continue;
    if (exact === undefined && normalized === target) {
      exact = workspace;
      continue;
    }
    // strict containment: target must start with the workspace path plus a
    // separator (a workspace path already ending in one — drive roots — is
    // used as-is) and be longer than it.
    const prefix = normalized.endsWith(separator) ? normalized : `${normalized}${separator}`;
    if (target.length > prefix.length && target.startsWith(prefix) && normalized.length > ancestorLength) {
      ancestor = workspace;
      ancestorLength = normalized.length;
    }
  }
  return { exact, ancestor };
}

/**
 * Find the workspace whose path exactly matches a directory (0.12.0):
 * powers the spawn cwd→workspace upgrade and task_workspace path targeting.
 * Failure-tolerant like the other registry helpers.
 * @param {string|undefined} cwd - directory to match
 * @param {Function|undefined} listWorkspaces - lazy host registry snapshot
 * @param {string} [platform] - normalization override for tests
 * @returns {object|undefined} the matching workspace snapshot entry
 */
export function findWorkspaceByPath(cwd, listWorkspaces, platform) {
  if (typeof cwd !== 'string' || cwd.trim().length === 0) return undefined;
  if (typeof listWorkspaces !== 'function') return undefined;
  let workspaces;
  try {
    workspaces = listWorkspaces();
  } catch {
    return undefined;
  }
  if (!Array.isArray(workspaces)) return undefined;
  const target = normalizeWorkspacePath(cwd, platform);
  return workspaces.find(
    (workspace) => typeof workspace?.path === 'string' && normalizeWorkspacePath(workspace.path, platform) === target,
  );
}

/**
 * Build a best-effort "available routes" hint for model-unavailable errors
 * (0.14.0). Marketplace reality: every deployment connects different
 * providers/models, so a rejected pair is only actionable when the error
 * shows what IS routable. Prefers the requested provider's model ids, falls
 * back to the routable provider ids. Failure-tolerant by contract: any
 * dependency problem yields an empty hint — never masks the original
 * rejection.
 * @param {string|undefined} provider - provider id from the rejected selection
 * @param {Function|undefined} listProviders - () => [{id, name}] (sync or async)
 * @param {Function|undefined} listModels - (providerId) => [{id, name}] (async)
 * @returns {Promise<string>} hint suffix ('' when nothing can be listed)
 */
export async function describeModelRoutes(provider, listProviders, listModels) {
  try {
    if (typeof listModels === 'function' && typeof provider === 'string' && provider.length > 0) {
      const models = await listModels(provider);
      if (Array.isArray(models) && models.length > 0) {
        const ids = models.map((model) => (typeof model?.id === 'string' ? model.id : undefined)).filter(Boolean);
        if (ids.length > 0) return ` — models served by provider "${provider}": ${ids.join(', ')} (full catalog: task_models)`;
      }
    }
    if (typeof listProviders === 'function') {
      const providers = await listProviders();
      if (Array.isArray(providers) && providers.length > 0) {
        const ids = providers.map((entry) => (typeof entry?.id === 'string' ? entry.id : undefined)).filter(Boolean);
        if (ids.length > 0) return ` — routable providers in this deployment: ${ids.join(', ')} (their models: task_models)`;
      }
    }
  } catch {
    // best effort only — the original rejection message stands alone
  }
  return '';
}

/**
 * @param {object} deps
 * @returns {TaskOps}
 */
export function createOps(deps) {
  const { sessionController, agents, createUserMessage, config, limiter, registry, uuid, askUser, listWorkspaces, getWorkspace, resolveModelConfig, listModelProviders, listProviderModels, readUiLocale, readSpawnDefaults, readSessionSnapshot, createSeededSession, archiveSession, probeWorktree, logger } = deps;

  const fail = (code, message) => ({ ok: false, code, error: message });
  const failDeny = (denial) => fail(denial.code, denial.message);
  const shortId = (sessionId) => String(sessionId).replace(/^session-/, '').slice(0, 8);
  // UI strings follow the host locale preference, read live per call (0.15.0):
  // switching the GUI language applies from the next card/kickoff onward, no
  // remount needed. Absent reader or preference keeps the historical zh set.
  const currentStrings = () => uiStrings(typeof readUiLocale === 'function' ? readUiLocale() : undefined);
  // Failure-tolerant workspace snapshot (0.19.0): one guard for every
  // listWorkspaces consumer inside the factory — a missing or throwing host
  // registry degrades to an empty list, never breaks the operation.
  const safeListWorkspaces = (list = listWorkspaces) => {
    try {
      const workspaces = typeof list === 'function' ? list() : [];
      return Array.isArray(workspaces) ? workspaces : [];
    } catch {
      return [];
    }
  };

  /**
   * Approved-but-unused dispatch confirmations (confirmationId -> record).
   * Process-local on purpose: after a host restart the supervisor simply
   * confirms again rather than acting on stale approvals.
   */
  const confirmations = new Map();

  /** Map one user-questions service error to our stable codes. */
  function failQuestionError(error) {
    const code = error?.code;
    if (code === 'ASK_CANCELLED') {
      return fail(OP_CODES.CONFIRM_CANCELLED, 'the user closed the confirmation card without answering; stop dispatching and wait for the user\'s next message');
    }
    if (code === 'ASK_ABORTED') {
      return fail(OP_CODES.CONFIRM_ABORTED, 'confirmation was aborted before the user answered');
    }
    if (code === 'NO_PROVIDER') {
      return fail(OP_CODES.NO_QUESTION_CHANNEL, 'no UI is connected to answer interactive questions; present the plan in plain text and get the user\'s go-ahead in chat');
    }
    if (code === 'DELEGATED_CALLER') {
      return fail(OP_CODES.DELEGATED_CALLER, 'human interaction is only available from a live root session; include the plan and the pending decision in your final result instead');
    }
    if (code === 'CALLER_NOT_LIVE') {
      return fail(OP_CODES.CALLER_NOT_LIVE, 'the calling agent is no longer the exact live instance; retry from a fresh tool call');
    }
    return fail('internal', `confirmation channel failed: ${error?.message ?? error}`);
  }

  /** Locate one session row in the visible list without activating agents. */
  async function findRow(targetId, signal) {
    const rows = await sessionController.list({}, signal);
    const items = rows?.items ?? rows ?? [];
    return items.find((row) => row.sessionId === targetId);
  }

  /** Compact list row for model consumption, enriched with registry team. */
  function summarizeRow(row) {
    const projections = row.projections?.values ?? {};
    const todos = Array.isArray(projections.todos) ? projections.todos : null;
    const goal = projections.goal ?? null;
    const pending = todos === null ? 0 : todos.filter((todo) => todo.status !== 'completed').length;
    const recorded = registry?.get(row.sessionId);
    return {
      sessionId: row.sessionId,
      title: projections.title ?? null,
      ...(recorded?.team !== undefined ? { team: recorded.team } : {}),
      // externalRef (0.25.0): registry-merged like team — lets an external
      // dispatcher scan the list and recognize its own spawns.
      ...(recorded?.externalRef !== undefined ? { externalRef: recorded.externalRef } : {}),
      status: row.running ? 'running' : row.blank ? 'blank' : 'idle',
      cwd: row.cwd ?? null,
      updatedAt: row.updatedAt,
      origin: row.origin ?? 'top-level',
      todos: todos === null ? null : `${todos.filter((todo) => todo.status === 'completed').length}/${todos.length} done`,
      goal: goal ? { objective: excerpt(goal.goal?.objective ?? '', 120), phase: goal.goal?.phase } : null,
      pendingTodos: pending,
    };
  }

  /**
   * Bounded scan window (events) for the live-session recent projection:
   * snapshotEvents() copies a range, so a huge session (100k+ events) must
   * never be copied whole just to read the tail. 400 events comfortably
   * contain progressTailMessages user/assistant messages amid tool noise.
   */
  // RECENT_SCAN_WINDOW: 单一源移至 feedback.mjs（P3-2，0918 评审）。

  /**
   * Recent-tail projection from a LIVE agent session (0.24.1 fix): the real
   * host Session entity exposes seq + eventAt()/snapshotEvents(from, to) —
   * NOT a plain `.events` array (dsh-session lib/index.js L1331/L1342;
   * host consumers like dsh-time-context walk seq backwards the same way).
   * Reading the imaginary `.events` made task_progress's recent silently
   * EMPTY in production since inception — the verify mock carried the same
   * imaginary shape, so the gap never surfaced (same mock≠real class as the
   * 0.18.4 envelope bug). The legacy `.events` fallback stays for test hosts
   * only; verify/smoke mocks now model the REAL snapshotEvents shape.
   */
  function tailFromSession(session, limit, capture, nextSeq = null) {
    if (!session || typeof session !== 'object') return [];
    try {
      if (typeof session.snapshotEvents === 'function' && Number.isFinite(session.seq)) {
        const from = nextSeq ?? Math.max(0, session.seq - RECENT_SCAN_WINDOW);
        const throughSeq = session.seq;
        const events = session.snapshotEvents(from, Math.min(throughSeq, from + RECENT_SCAN_WINDOW));
        if (capture) Object.assign(capture, { events, from, throughSeq });
        return tailFromEvents(events, limit);
      }
      return tailFromEvents(session.events, limit); // legacy/test-host shape
    } catch {
      return []; // a hostile snapshotEvents must never break progress itself
    }
  }

  /** Extract the last surface-visible messages from a session event array. */
  function tailFromEvents(events, limit) {
    return (events ?? []).map(event => messageProjection(event, config.excerptChars)).filter(Boolean).slice(-limit);
  }

  /** Inbox depth probe used by the rate limiter. */
  function pendingCount(targetId) {
    const agent = agents.get(targetId);
    if (!agent) return 0;
    return (agent.inbox?.nextTurn?.length ?? 0) + (agent.inbox?.nextStep?.length ?? 0);
  }

  /** Normalize the wait tool's target input to a clean id array. */
  function normalizeTargetIds({ sessionId, sessionIds }) {
    const raw = Array.isArray(sessionIds) && sessionIds.length > 0
      ? sessionIds
      : typeof sessionId === 'string' && sessionId.length > 0 ? [sessionId] : [];
    const cleaned = [];
    for (const id of raw) {
      if (typeof id === 'string' && id.trim().length > 0 && !cleaned.includes(id.trim())) {
        cleaned.push(id.trim());
      }
    }
    return cleaned;
  }

  const ops = {
    pendingCount,

    /** Capability 1: discover tasks and their stable ids. */
    async listTasks({ filter, team, includeSubagents = false, ungrouped = false, limit = 50 } = {}, caller, signal) {
      const callerDeny = checkCaller(caller, config);
      if (callerDeny) return failDeny(callerDeny);
      const rows = await sessionController.list({}, signal);
      const items = rows?.items ?? rows ?? [];
      const wantedSubagents = includeSubagents || config.includeSubagentsInList;
      const needle = typeof filter === 'string' && filter.trim().length > 0 ? filter.trim().toLowerCase() : null;
      const wantedTeam = typeof team === 'string' && team.trim().length > 0 ? team.trim() : null;
      const teamMembers = wantedTeam && registry ? new Set(registry.listTeam(wantedTeam)) : null;
      // ungrouped:true (0.19.0) keeps only sessions that belong to NO
      // workspace — the remediation view for the ungrouped bucket. Judgment
      // is lexical-exact against the registered workspace paths via the same
      // single source of truth the spawn chain uses (matchWorkspacePaths.exact
      // — the host's sessionIds getter buckets the same way); a subdirectory
      // cwd does NOT count as belonging (that session IS ungrouped in the
      // GUI and is exactly the remediation candidate this filter exists to
      // surface). Rows without a cwd cannot prove membership either → kept.
      const wantedUngrouped = ungrouped === true;
      const workspaceSnapshot = wantedUngrouped ? safeListWorkspaces() : [];
      const snapshotList = () => workspaceSnapshot;
      const tasks = [];
      for (const row of items) {
        if (row.origin === 'subagent' && !wantedSubagents) continue;
        if (teamMembers && !teamMembers.has(row.sessionId)) continue;
        if (wantedUngrouped && matchWorkspacePaths(row.cwd ?? '', snapshotList).exact !== undefined) continue;
        if (needle) {
          const title = row.projections?.values?.title ?? '';
          const haystack = `${row.sessionId} ${title} ${row.cwd ?? ''}`.toLowerCase();
          if (!haystack.includes(needle)) continue;
        }
        tasks.push(summarizeRow(row));
      }
      tasks.sort((a, b) => b.updatedAt - a.updatedAt);
      const truncated = tasks.length > limit;
      return {
        ok: true,
        count: tasks.length,
        truncated,
        callerSessionId: caller.sessionId,
        ...(wantedTeam ? { team: wantedTeam } : {}),
        ...(wantedUngrouped ? { ungrouped: true } : {}),
        tasks: tasks.slice(0, limit),
        hint: wantedUngrouped
          ? 'ungrouped view: these sessions belong to no workspace — remediate with task_workspace (attach when the stored cwd equals a workspace path, migrate otherwise); check the spawn registry expectedWorkspace for what the caller intended'
          : 'use task_progress to read one task in depth; task_send to message it',
      };
    },

    /** Capability 2: read one task's current progress without disturbing it. */
    async progress(targetId, caller, signal, { cursor, messageId } = {}) {
      const callerDeny = checkCaller(caller, config);
      if (callerDeny) return failDeny(callerDeny);
      if (typeof targetId !== 'string' || targetId.length === 0) {
        return fail(OP_CODES.BAD_REQUEST, 'sessionId is required');
      }
      let nextSeq;
      try { nextSeq = decodeCursor(cursor, targetId); } catch { return fail(OP_CODES.BAD_REQUEST, 'invalid progress cursor for this session'); }
      if (messageId !== undefined && (typeof messageId !== 'string' || !messageId || messageId.length > 256)) return fail(OP_CODES.BAD_REQUEST, 'invalid messageId');
      const captured = { events: null, from: 0, throughSeq: null };
      const row = await findRow(targetId, signal);
      const targetDeny = checkTarget(caller, row && { sessionId: row.sessionId, origin: row.origin });
      if (targetDeny) return failDeny(targetDeny);
      const recorded = registry?.get(targetId);
      const agent = agents.get(targetId);
      const result = {
        ok: true,
        sessionId: targetId,
        shortId: shortId(targetId),
        ...(recorded?.team !== undefined ? { team: recorded.team } : {}),
        // externalRef (0.25.0): the durable cross-agent correspondence marker,
        // surfaced exactly like team (registry merge, absent when never given).
        ...(recorded?.externalRef !== undefined ? { externalRef: recorded.externalRef } : {}),
        title: row?.projections?.values?.title ?? null,
        cwd: row?.cwd ?? null,
        updatedAt: row?.updatedAt ?? null,
        todos: row?.projections?.values?.todos ?? null,
        goal: row?.projections?.values?.goal ?? null,
      };
      if (agent) {
        result.agentState = agent.status; // 'idle' | 'running'
        result.queue = [
          ...(agent.inbox?.nextTurn ?? []).map((message) => ({
            placement: 'next-turn',
            ...(typeof message.id === 'string' ? { messageId: message.id } : {}),
            source: message.source?.kind ?? 'unknown',
            text: excerpt(blocksToText(message.content), config.excerptChars),
          })),
          ...(agent.inbox?.nextStep ?? []).map((message) => ({
            placement: 'next-step',
            ...(typeof message.id === 'string' ? { messageId: message.id } : {}),
            source: message.source?.kind ?? 'unknown',
            text: excerpt(blocksToText(message.content), config.excerptChars),
          })),
        ];
        result.recent = tailFromSession(agent.session, config.progressTailMessages, captured, nextSeq);
        result.seq = agent.session?.seq ?? null;
      } else {
        result.agentState = 'cold-idle';
        result.note = 'cold session (no live agent): not running does not mean no pending work — a persisted queue may exist, and the send-depth guard (maxQueuePerTask) does not cover cold targets';
        result.queue = [];
        try {
          const observed = await sessionController.inspect(targetId, signal);
          const events = observed?.events;
          result.recent = tailFromEvents(events, config.progressTailMessages);
          if (Array.isArray(events) && events.length && events.every(e => Number.isSafeInteger(e?.seq))) {
            const throughSeq = events.reduce((max, e) => Math.max(max, e.seq), -1) + 1;
            const from = nextSeq ?? Math.max(0, throughSeq - RECENT_SCAN_WINDOW);
            Object.assign(captured, { throughSeq, from, events: events.filter(e => e.seq >= from && e.seq < Math.min(throughSeq, from + RECENT_SCAN_WINDOW)) });
          }
        } catch (error) {
          result.recent = [];
          result.inspectError = error?.message ?? String(error);
        }
      }
      result.feedback = feedbackPage({ sessionId: targetId, ...captured, nextSeq,
        limit: config.progressTailMessages, chars: config.excerptChars, source: agent ? 'live' : 'persisted' });
      if (cursor !== undefined) result.recent = []; // Incremental callers consume feedback.messages only.
      if (messageId !== undefined) result.consumption = {
        messageId,
        state: result.queue.some(m => m.messageId === messageId) ? 'queued' :
          (captured.events ?? []).some(e => e.type === 'user/message' && e.data?.id === messageId) ? 'observed' : 'unknown',
        meaning: 'observed means present in the scanned transcript; it does not prove execution or completion',
      };
      return result;
    },

    /** Capabilities 3+4: deliver a visible follow-up prompt to one task. */
    async sendMessage({ targetId, text, mode = 'queue', reference }, caller) {
      const callerDeny = checkCaller(caller, config);
      if (callerDeny) return failDeny(callerDeny);
      if (typeof targetId !== 'string' || targetId.length === 0) {
        return fail(OP_CODES.BAD_REQUEST, 'sessionId is required');
      }
      if (typeof text !== 'string' || text.trim().length === 0) {
        return fail(OP_CODES.BAD_REQUEST, 'message text is required');
      }
      if (mode !== 'queue' && mode !== 'steer') {
        return fail(OP_CODES.BAD_REQUEST, "mode must be 'queue' or 'steer'");
      }
      const row = await findRow(targetId);
      const targetDeny = checkTarget(caller, row && { sessionId: row.sessionId, origin: row.origin });
      if (targetDeny) return failDeny(targetDeny);
      const limitDeny = limiter.check(targetId);
      if (limitDeny) return failDeny(limitDeny);
      const wasCold = !agents.get(targetId);
      const resolved = await sessionController.resolveAgent(targetId);
      if (!resolved || resolved.error) {
        const code = resolved?.error?.code ?? 'internal';
        if (code === 'agent-busy') {
          return fail(OP_CODES.TARGET_BUSY, 'target task is briefly busy admitting other work; retry in a moment');
        }
        if (code === 'session-not-found') {
          return fail(OP_CODES.TARGET_VANISHED, 'target session vanished before delivery');
        }
        return fail(OP_CODES.RESOLVE_FAILED, `target task could not be resolved: ${resolved?.error?.message ?? code}`);
      }
      // Optional correlation: a visible annotation line quoting an earlier
      // instruction id, so corrections and handoffs stay traceable.
      const annotation = typeof reference === 'string' && reference.trim().length > 0
        ? `[reference: ${reference.trim()}]\n`
        : '';
      const message = createUserMessage({
        content: [{ type: 'text', text: `${annotation}${text}` }],
        source: { kind: 'coordinator', form: 'relay', senderSessionId: caller.sessionId },
      });
      if (mode === 'steer') resolved.agent.steer(message);
      else resolved.agent.followup(message);
      limiter.accept(targetId);
      const receiptPersisted = caller.sessionId === EXTERNAL_CALLER ? registry?.recordBridgeReceipt?.(targetId, {
        kind: 'send', time: Date.now(), messageId: message?.id, mode, delivered: true,
      }) : undefined;
      // Post-send queue depth (includes this message): the nextTurn count is the
      // number of rounds before this message is read — the host claims exactly
      // one next-turn message per round.
      const queueDepth = {
        nextTurn: resolved.agent.inbox?.nextTurn?.length ?? 0,
        nextStep: resolved.agent.inbox?.nextStep?.length ?? 0,
      };
      const running = resolved.agent.status === 'running';
      let hint = 'delivered != consumed; verify with task_progress before resending';
      if (mode === 'steer' && running) {
        hint = 'delivered at the next step boundary; extends the current round (multiple queued steers land in one batch); verify with task_progress before resending';
      } else if (mode === 'queue' && running && queueDepth.nextTurn >= 2) {
        hint = `delivered != consumed; next-turn depth ${queueDepth.nextTurn} (post-send, including this message) — one next-turn message is consumed per round, so this one is read after ~${queueDepth.nextTurn} rounds; if this message changes the target's next step, consider steer`;
      }
      return {
        ok: true,
        delivered: true,
        ...(receiptPersisted !== undefined ? { receiptPersisted } : {}),
        targetId,
        mode,
        ...(message?.id !== undefined ? { messageId: message.id } : {}),
        ...(annotation ? { reference: reference.trim() } : {}),
        placement: mode === 'steer' ? 'next-step (mid-run steering)' : 'next-turn (queued; starts a new round when the task is idle)',
        targetStatus: resolved.agent.status,
        queueDepth,
        hint,
        ...(wasCold ? { note: 'target was cold before this send (no live agent): the queue-depth guard (maxQueuePerTask) does not cover cold targets — cold does not mean no pending work' } : {}),
      };
    },

    /** Capability 6: spawn a brand-new task; it appears in the session list. */
    async spawnTask({ title, prompt, cwd, sessionId, agentPreset, team, reportBack, provider, model, reasoningEffort, externalRef }, caller, signal) {
      const callerDeny = checkCaller(caller, config);
      if (callerDeny) return failDeny(callerDeny);
      if (typeof prompt !== 'string' || prompt.trim().length === 0) {
        return fail(OP_CODES.BAD_REQUEST, 'prompt is required to start the new task');
      }
      // externalRef (0.25.0, wire contract C1 of research/dshq-ledger-mailbox-
      // spec.md Part C — locked, do not change unilaterally): optional free-form
      // external caller reference for cross-agent correspondence (suggested
      // shape "<thread-short-id>:<wave-name>"). Stored and echoed VERBATIM,
      // never parsed. Rules: string only; trimmed; <=200 chars after trim;
      // empty/whitespace-only counts as ABSENT (not an error); null/undefined
      // count as absent too (same convention as every other optional field on
      // both layers); any other non-string or an over-length value is
      // bad-request. Validation lives here (not only in the tool schema)
      // because bridge consumers call ops directly.
      let cleanExternalRef;
      if (externalRef !== undefined && externalRef !== null) {
        if (typeof externalRef !== 'string') {
          return fail(OP_CODES.BAD_REQUEST, 'externalRef must be a string (free-form external caller reference, <=200 chars after trim)');
        }
        const trimmedRef = externalRef.trim();
        if (trimmedRef.length > 200) {
          return fail(OP_CODES.BAD_REQUEST, `externalRef must be at most 200 characters after trim (got ${trimmedRef.length})`);
        }
        if (trimmedRef.length > 0) cleanExternalRef = trimmedRef;
      }
      // Per-child model selection (0.13.0): provider+model are a pair; the
      // optional reasoningEffort only rides along with them. Validated up-front
      // through the host LLM catalog when available so an invalid route never
      // creates an orphan session; installed after creation via the host's
      // sessionController.selectModel (the same API the GUI model picker uses —
      // note it also updates the app-wide default model, host semantics).
      // 0.18.0: a call that omits both falls back to the plugin's configured
      // default route (durable "task-coordinator" settings section, GUI-editable
      // in Settings → 任务编排) before landing on the host default. The
      // resolution order is: explicit tool args > plugin default > host default.
      let modelFromDefaults = false;
      if ((provider === undefined || provider === null || String(provider).trim().length === 0)
        && (model === undefined || model === null || String(model).trim().length === 0)
        && typeof readSpawnDefaults === 'function') {
        const fallback = (() => {
          try { return readSpawnDefaults(); } catch { return null; } // never breaks the spawn
        })();
        if (fallback) {
          provider = fallback.provider;
          model = fallback.model;
          if (reasoningEffort === undefined || reasoningEffort === null || String(reasoningEffort).trim().length === 0) {
            reasoningEffort = fallback.reasoningEffort;
          }
          modelFromDefaults = true;
        }
      }
      const hasProvider = provider !== undefined && provider !== null && String(provider).trim().length > 0;
      const hasModel = model !== undefined && model !== null && String(model).trim().length > 0;
      if (hasProvider !== hasModel) {
        return fail(OP_CODES.BAD_REQUEST, 'provider and model must be supplied together (or both omitted to use the configured default / host default model)');
      }
      const modelSpec = hasProvider
        ? {
            provider: String(provider).trim(),
            model: String(model).trim(),
            ...(reasoningEffort !== undefined && reasoningEffort !== null && String(reasoningEffort).trim().length > 0
              ? { reasoningEffort: String(reasoningEffort).trim() }
              : {}),
          }
        : undefined;
      const modelSource = modelSpec === undefined ? 'host-default' : (modelFromDefaults ? 'plugin-default' : 'explicit');
      if (modelSpec && typeof resolveModelConfig === 'function') {
        const precheck = resolveModelConfig(modelSpec);
        if (precheck) {
          try {
            await precheck;
          } catch (error) {
            const hint = await describeModelRoutes(modelSpec.provider, listModelProviders, listProviderModels);
            return fail(OP_CODES.MODEL_UNAVAILABLE, `model selection was rejected by the host catalog: ${error?.message ?? error}${hint}`);
          }
        }
      }
      // Recursion governance: the child's depth derives from the caller's
      // recorded depth (a never-spawned root session counts as depth 0).
      // Beyond maxSpawnDepth the tree stops growing; the rejected coordinator
      // should fall back to subagents for deeper parallelism.
      const parentEntry = registry?.get(caller.sessionId);
      const childDepth = (parentEntry?.depth ?? 0) + 1;
      if (childDepth > config.maxSpawnDepth) {
        return fail(
          OP_CODES.SPAWN_DEPTH_EXCEEDED,
          `spawn depth would be ${childDepth} but maxSpawnDepth is ${config.maxSpawnDepth}; use subagents for deeper parallelism instead of spawning new task sessions`,
        );
      }
      const cleanTeam = typeof team === 'string' && team.trim().length > 0 ? team.trim() : undefined;
      if (sessionId !== undefined) {
        const limitDeny = limiter.check(sessionId);
        if (limitDeny) return failDeny(limitDeny);
      }
      const request = {};
      if (typeof sessionId === 'string' && sessionId.length > 0) request.sessionId = sessionId;
      if (typeof agentPreset === 'string' && agentPreset.length > 0) request.agentPreset = agentPreset;
      // Workspace placement chain (0.19.0 — research/workspace-placement-
      // fallback.md approved tiering). The host takes workspaceId XOR cwd on
      // create, derives the session cwd from the workspace path and attaches
      // the session to that workspace, so every tier that CAN group must send
      // workspaceId; the chain degrades level by level:
      //  ① lexical exact match (normalizeWorkspacePath strips trailing
      //     separators AND '.' segments; case/separators fold per platform);
      //  ② caller inheritance — caller workspace membership (incl. the spawn
      //     ancestor chain), then caller.cwd exact match (unchanged legacy);
      //  ③ ancestor upgrade (workspacePolicy 'ancestor', the default): the
      //     cwd we would send is a TRUE subdirectory of a registered
      //     workspace → attach to the NEAREST ancestor workspace; the host
      //     then derives the session cwd from the workspace ROOT, so the
      //     receipt and the kickoff prompt both say so (i18n suffix);
      //  ④ git-worktree recognition (classification only, never an upgrade):
      //     an unmatched cwd whose `.git` is a FILE (linked-worktree marker,
      //     injected fs probe) stays ungrouped ON PURPOSE — worktree
      //     isolation beats grouping, and the host's attach validation
      //     (stored cwd must equal the workspace path) would destroy it —
      //     but the receipt carries a strong warning;
      //  ⑤ ungrouped terminal: request carries cwd; the receipt always
      //     reports workspace:null + placement + warning + remediation hint,
      //     and the registry records the caller's expected workspace path
      //     (expectedWorkspace) for later batch remediation.
      const explicitCwd = typeof cwd === 'string' && cwd.trim().length > 0 ? cwd : undefined;
      const expectedWorkspace = explicitCwd
        ?? (typeof caller.cwd === 'string' && caller.cwd.trim().length > 0 ? caller.cwd : undefined);
      const isWorktree = (candidate) => {
        if (typeof probeWorktree !== 'function') return false;
        try {
          return probeWorktree(candidate) === true;
        } catch {
          return false; // any probe problem degrades to "not a worktree"
        }
      };
      /** Best-effort {id,title} receipt projection for a workspace snapshot. */
      const workspaceOf = (workspace) => (workspace && typeof workspace.id === 'string' && workspace.id.length > 0
        ? { id: workspace.id, title: typeof workspace.title === 'string' ? workspace.title : null }
        : null);
      let effectiveCwd;
      let placement;
      let placementWorkspace = null;
      let normalizedFrom; // ③: the subdirectory the caller actually asked for
      let normalizedRoot;
      if (explicitCwd) {
        const { exact, ancestor } = matchWorkspacePaths(explicitCwd, listWorkspaces);
        if (exact?.id) {
          request.workspaceId = exact.id;
          effectiveCwd = exact.path ?? explicitCwd;
          placement = 'exact-match';
          placementWorkspace = workspaceOf(exact);
        } else if (config.workspacePolicy === 'ancestor' && ancestor?.id) {
          request.workspaceId = ancestor.id;
          effectiveCwd = ancestor.path ?? explicitCwd;
          placement = 'ancestor-normalized';
          placementWorkspace = workspaceOf(ancestor);
          normalizedFrom = explicitCwd;
          normalizedRoot = ancestor.path ?? effectiveCwd;
        } else {
          request.cwd = explicitCwd;
          effectiveCwd = explicitCwd;
          placement = isWorktree(explicitCwd) ? 'ungrouped-worktree' : 'ungrouped';
        }
      } else {
        const inheritedId = resolveCallerWorkspaceId(caller.sessionId, registry, listWorkspaces);
        if (inheritedId) {
          request.workspaceId = inheritedId;
          effectiveCwd = workspacePathOf(inheritedId, listWorkspaces) ?? caller.cwd;
          placement = 'caller-inherited';
          placementWorkspace = workspaceOf(
            safeListWorkspaces(listWorkspaces).find((workspace) => workspace?.id === inheritedId),
          );
        } else if (caller.cwd) {
          const { exact, ancestor } = matchWorkspacePaths(caller.cwd, listWorkspaces);
          if (exact?.id) {
            request.workspaceId = exact.id;
            effectiveCwd = exact.path ?? caller.cwd;
            placement = 'caller-inherited';
            placementWorkspace = workspaceOf(exact);
          } else if (config.workspacePolicy === 'ancestor' && ancestor?.id) {
            request.workspaceId = ancestor.id;
            effectiveCwd = ancestor.path ?? caller.cwd;
            placement = 'ancestor-normalized';
            placementWorkspace = workspaceOf(ancestor);
            normalizedFrom = caller.cwd;
            normalizedRoot = ancestor.path ?? effectiveCwd;
          } else {
            request.cwd = caller.cwd;
            effectiveCwd = caller.cwd;
            placement = isWorktree(caller.cwd) ? 'ungrouped-worktree' : 'ungrouped';
          }
        } else {
          // no explicit cwd, no caller cwd: the host lands the session on its
          // default cwd — nothing this plugin can attach to.
          placement = 'ungrouped';
        }
      }
      const workspaceWarning = placement === 'ungrouped-worktree'
        ? `ungrouped placement (git worktree): cwd '${effectiveCwd}' looks like a linked git worktree ('.git' is a file, not a directory) and no workspace matched it — the session deliberately stays UNGROUPED to preserve worktree isolation (the host attaches a session only when its stored cwd equals the workspace path, so joining the main repo's workspace would rewrite the cwd and destroy the isolation). If grouping matters more than isolation: task_workspace action 'migrate' (clone + archive; the clone is born at the workspace root and the isolation is lost). The registry recorded this spawn's expectedWorkspace; audit such sessions with task_list({ ungrouped: true })`
        : placement === 'ungrouped'
          ? `ungrouped placement: no registered workspace matched cwd '${effectiveCwd ?? '(default)'}' — the session sits in the ungrouped bucket (visible in the session list, outside every workspace group). Remediation: task_workspace action 'migrate' (cross-path clone + archive) or 'attach' (only when the stored cwd already equals a workspace path); audit such sessions with task_list({ ungrouped: true }); logical grouping still works via spawn team= + task_list({ team })`
          : undefined;
      let created;
      try {
        created = await sessionController.create(request);
      } catch (error) {
        return fail(OP_CODES.SPAWN_CREATE_FAILED, `session creation failed: ${error?.message ?? error}`);
      }
      const newId = created.sessionId;
      // Spawn-title rule: MMDD｜类型｜主题. The date prefix is stamped mechanically
      // from the creation time (Asia/Shanghai by default); the caller supplies the
      // semantic part (类型｜主题), and the topic falls back to the kickoff prompt's
      // first line when no title is given. Renaming is cosmetic — never fail the
      // spawn over it.
      let appliedTitle = null;
      const builtTitle = buildSpawnTitle({ title, prompt }, config, Date.now());
      try {
        const renamed = await sessionController.rename({ sessionId: newId, title: builtTitle });
        appliedTitle = renamed.title;
      } catch (error) {
        appliedTitle = null;
      }
      // Record the spawn durably (team + intent) so the supervisor can recover
      // "its" tasks after a host restart. Recorded before kickoff so even a
      // created-but-not-started orphan remains traceable. expectedWorkspace
      // (0.19.0) preserves the directory the CALLER expected the task to
      // belong to (explicit cwd, else the caller's cwd) — for ungrouped and
      // worktree placements this is the lead for later batch remediation
      // (task_workspace attach/migrate).
      registry?.record(newId, {
        ...(cleanTeam !== undefined ? { team: cleanTeam } : {}),
        ...(appliedTitle ? { title: appliedTitle } : {}),
        promptExcerpt: excerpt(prompt.trim(), 120),
        depth: childDepth,
        parentSessionId: caller.sessionId,
        ...(expectedWorkspace !== undefined ? { expectedWorkspace } : {}),
        // externalRef (0.25.0): durable so the correspondence survives restarts
        ...(cleanExternalRef !== undefined ? { externalRef: cleanExternalRef } : {}),
      });
      // Install the per-child model BEFORE the kickoff so the very first turn
      // runs on the requested route. A failure leaves a traceable orphan (the
      // registry record above) and never kicks off on the wrong model.
      let installedModel;
      if (modelSpec) {
        try {
          const selection = await sessionController.selectModel({ sessionId: newId, ...modelSpec });
          installedModel = selection?.selected ?? modelSpec;
        } catch (error) {
          return {
            ok: false,
            code: OP_CODES.MODEL_SELECT_FAILED,
            error: `session ${newId} was created but the model could not be installed: ${error?.message ?? error} — the kickoff was NOT sent; pick the model manually (or task_cancel the orphan) and task_send the prompt`,
            sessionId: newId,
            depth: childDepth,
            ...(cleanTeam !== undefined ? { team: cleanTeam } : {}),
          };
        }
      }
      const correlationId = uuid();
      // Kickoff suffixes (both optional, appended in this order):
      //  - ancestor normalization note (0.19.0): when placement ③ normalized
      //    the session cwd up to the workspace root, the task is TOLD so —
      //    its target directory and the explicit-path discipline — through
      //    the same i18n surface as the report-back suffix (zh/en follows
      //    the host locale preference);
      //  - report-back convention (default on): the kickoff prompt tells the
      //    new task to push its result summary back to the spawning session
      //    via task_send, so the supervisor gets push instead of only pull.
      //    The registry excerpt keeps the user's original prompt.
      const wantsReport = reportBack !== false;
      const strings = currentStrings();
      const kickoffParts = [prompt.trim()];
      if (placement === 'ancestor-normalized' && normalizedFrom !== undefined) {
        kickoffParts.push(strings.workspaceNormalizedSuffix(normalizedRoot ?? effectiveCwd ?? '', normalizedFrom));
      }
      if (wantsReport) kickoffParts.push(strings.reportBackSuffix(caller.sessionId));
      const kickoffText = kickoffParts.join('\n\n---\n');
      let started = false;
      try {
        // The Remote facade's prompt(request, signal) dereferences the signal
        // unconditionally (signal.throwIfAborted()), so a valid AbortSignal is
        // always supplied: the caller's when present, else a fresh one.
        await sessionController.prompt({
          requestId: correlationId,
          sessionId: newId,
          mode: 'queue',
          content: [{ type: 'text', text: kickoffText }],
        }, signal ?? new AbortController().signal);
        started = true;
        limiter.accept(newId);
      } catch (error) {
        return {
          ok: false,
          code: OP_CODES.KICKOFF_REJECTED,
          error: `session ${newId} was created but the kickoff prompt was rejected: ${error?.message ?? error}`,
          sessionId: newId,
          depth: childDepth,
          ...(cleanTeam !== undefined ? { team: cleanTeam } : {}),
        };
      }
      const receiptPersisted = caller.sessionId === EXTERNAL_CALLER ? registry?.recordBridgeReceipt?.(newId, {
        kind: 'spawn', time: Date.now(), correlationId, delivered: started,
      }) : undefined;
      return {
        ok: true,
        sessionId: newId,
        ...(receiptPersisted !== undefined ? { receiptPersisted } : {}),
        shortId: shortId(newId),
        title: appliedTitle,
        ...(cleanTeam !== undefined ? { team: cleanTeam } : {}),
        // externalRef (0.25.0): echoed on the success receipt (trimmed form) so
        // the dispatcher can confirm what was recorded — contract C1.
        ...(cleanExternalRef !== undefined ? { externalRef: cleanExternalRef } : {}),
        cwd: effectiveCwd ?? null,
        // Workspace observability (0.19.0): every spawn receipt states which
        // workspace the task attached to ({id,title} | null) and HOW it was
        // placed (WORKSPACE_PLACEMENTS); ungrouped placements always carry a
        // warning + remediation hint, ancestor-normalized ones state the
        // requested directory that was normalized away.
        workspace: placementWorkspace,
        placement,
        ...(placement === 'ancestor-normalized'
          ? {
              normalizedFrom,
              note: `ancestor normalization: the requested cwd '${normalizedFrom}' is inside workspace '${placementWorkspace?.id}' ('${normalizedRoot}'); the host derives the session cwd from the workspace path, so the task works at the workspace ROOT — its kickoff prompt names the target directory and says to use explicit paths`,
            }
          : {}),
        ...(workspaceWarning !== undefined ? { warning: workspaceWarning } : {}),
        ...(installedModel !== undefined ? { model: installedModel, modelSource } : {}),
        started,
        correlationId,
        depth: childDepth,
        hint: workspaceWarning !== undefined
          ? 'track it with task_progress; consider task_workspace (attach/migrate) to fix the placement, or keep it ungrouped deliberately'
          : 'the new task is now visible in the session list; track it with task_progress',
      };
    },

    /**
     * Capability 6c: interactive dispatch confirmation. Presents the plan as a
     * plan-review card through the ctx.userQuestions seam (same mechanism as
     * the official exit_plan_mode) and blocks until the user answers.
     * Approval mints a single-use confirmationId consumed by task_spawn_batch.
     */
    async confirmPlan({ plan, question, reusable }, caller, agent, signal) {
      const callerDeny = checkCaller(caller, config);
      if (callerDeny) return failDeny(callerDeny);
      if (typeof plan !== 'string' || plan.trim().length === 0) {
        return fail(OP_CODES.BAD_REQUEST, 'plan is required (markdown: what gets split into how many tasks and why)');
      }
      // Host plan-review convention (dsh-plan-mode exit_plan_mode uses the same
      // check): the reviewed body must be markdown starting with a # heading,
      // so every card body renders with the same structure as official plans.
      if (!/^#\s+\S/.test(plan.trim())) {
        return fail(OP_CODES.BAD_REQUEST, 'plan must be markdown starting with a # heading (host plan-review convention, same as exit_plan_mode)');
      }
      if (typeof askUser !== 'function') {
        return fail(OP_CODES.NO_QUESTION_CHANNEL, 'no user-questions channel composed; present the plan in plain text and get the go-ahead in chat');
      }
      // Plan-review narrowing (verified against dsh-user-questions + client
      // PlanReviewPanel): single question, no multiSelect, <=2 options, detail
      // present, and the approve label must name one option exactly.
      const strings = currentStrings();
      const approveLabel = strings.confirmApproveLabel;
      const reviewQuestion = {
        id: 'task-dispatch-review',
        header: strings.confirmHeader,
        question: typeof question === 'string' && question.trim().length > 0 ? question.trim() : strings.confirmQuestionDefault,
        detail: plan.trim(),
        options: [
          { label: approveLabel, description: strings.confirmApproveDescription },
          { label: strings.confirmDeclineLabel, description: strings.confirmDeclineDescription },
        ],
        intent: { kind: 'plan-review', approve: approveLabel },
      };
      let result;
      try {
        result = await askUser({ questions: [reviewQuestion], agent, signal });
      } catch (error) {
        return failQuestionError(error);
      }
      if (result === null || result === undefined) {
        return fail(OP_CODES.NO_QUESTION_CHANNEL, 'no UI is connected to answer interactive questions; present the plan in plain text and get the user\'s go-ahead in chat');
      }
      const answer = Array.isArray(result.answers) ? result.answers.find((entry) => entry?.id === reviewQuestion.id) : undefined;
      const selected = Array.isArray(answer?.selected) ? answer.selected : [];
      const approved = selected.includes(approveLabel);
      if (approved) {
        const confirmationId = `confirm-${uuid()}`;
        confirmations.set(confirmationId, {
          callerSessionId: caller.sessionId,
          approvedAt: Date.now(),
          taskHint: excerpt(plan.trim(), 80),
          ...(reusable === true ? { reusable: true } : {}),
        });
        return {
          ok: true,
          approved: true,
          confirmationId,
          ...(reusable === true ? { reusable: true } : {}),
          hint: reusable === true
            ? 'pass this confirmationId to every task_spawn_batch of this mission; it is REUSABLE (survives successful batches) and bound to your session'
            : 'pass this confirmationId to task_spawn_batch for this plan; it is single-use and bound to your session',
        };
      }
      return {
        ok: true,
        approved: false,
        feedback: typeof answer?.custom === 'string' && answer.custom.trim().length > 0 ? answer.custom.trim() : (selected[0] ?? strings.confirmDeclineLabel),
        hint: 'do not dispatch; fold the user\'s feedback into a revised plan and confirm again',
      };
    },

    /**
     * Capability 6d (0.10.0): multi-select dispatch confirmation. Renders the
     * proposed task list as ONE multi-select question in the host's neutral
     * question UI (no plan-review intent → no amber warn styling; multiSelect +
     * the custom input row are generic-UI capabilities). The user checks WHICH
     * of the proposed tasks to dispatch; approval mints a confirmationId bound
     * to the selected subset, and spawnBatch enforces the batch stays within it.
     * The generic UI renders no markdown body, so the supervisor presents the
     * full plan in chat before calling this (the tool description says so).
     */
    async confirmSelect({ question, tasks, reusable }, caller, agent, signal) {
      const callerDeny = checkCaller(caller, config);
      if (callerDeny) return failDeny(callerDeny);
      if (!Array.isArray(tasks) || tasks.length === 0) {
        return fail(OP_CODES.BAD_REQUEST, 'tasks must be a non-empty array of {title, scope?} items (or plain title strings)');
      }
      const options = [];
      const seen = new Set();
      for (const [index, item] of tasks.entries()) {
        const title = typeof item === 'string' ? item.trim() : typeof item?.title === 'string' ? item.title.trim() : '';
        if (title.length === 0) return fail(OP_CODES.BAD_REQUEST, `tasks[${index}].title is required`);
        if (seen.has(title)) return fail(OP_CODES.BAD_REQUEST, `tasks[${index}].title duplicates "${title}" — option labels must be unique`);
        seen.add(title);
        const scope = typeof item === 'string' ? undefined : typeof item?.scope === 'string' && item.scope.trim().length > 0 ? item.scope.trim() : undefined;
        options.push(scope === undefined ? { label: title } : { label: title, description: scope });
      }
      if (typeof askUser !== 'function') {
        return fail(OP_CODES.NO_QUESTION_CHANNEL, 'no user-questions channel composed; list the tasks in chat and let the user pick by replying');
      }
      const selectStrings = currentStrings();
      const selectQuestion = {
        id: 'task-dispatch-select',
        question: typeof question === 'string' && question.trim().length > 0
          ? question.trim()
          : selectStrings.selectQuestionDefault(options.length),
        multiSelect: true,
        options,
      };
      let result;
      try {
        result = await askUser({ questions: [selectQuestion], agent, signal });
      } catch (error) {
        return failQuestionError(error);
      }
      if (result === null || result === undefined) {
        return fail(OP_CODES.NO_QUESTION_CHANNEL, 'no UI is connected to answer interactive questions; list the tasks in chat and get the user\'s pick there');
      }
      const answer = Array.isArray(result.answers) ? result.answers.find((entry) => entry?.id === selectQuestion.id) : undefined;
      const selected = Array.isArray(answer?.selected) ? answer.selected.filter((label) => typeof label === 'string') : [];
      const custom = typeof answer?.custom === 'string' && answer.custom.trim().length > 0 ? answer.custom.trim() : undefined;
      if (selected.length === 0) {
        return {
          ok: true,
          approved: false,
          feedback: custom ?? selectStrings.selectEmptyFeedback,
          hint: 'do not dispatch; fold the user\'s feedback into a revised task list and confirm again',
        };
      }
      const confirmationId = `confirm-${uuid()}`;
      confirmations.set(confirmationId, {
        callerSessionId: caller.sessionId,
        approvedAt: Date.now(),
        taskHint: excerpt(`select ${selected.length}/${options.length}: ${selected.join(', ')}`, 80),
        selected,
        ...(reusable === true ? { reusable: true } : {}),
      });
      return {
        ok: true,
        approved: true,
        selected,
        ...(custom !== undefined ? { custom } : {}),
        confirmationId,
        ...(reusable === true ? { reusable: true } : {}),
        hint: reusable === true
          ? 'pass this confirmationId to every task_spawn_batch of this mission; it is REUSABLE (survives successful batches) but the batch must still contain ONLY the selected tasks; bound to your session'
          : 'pass this confirmationId to task_spawn_batch; the batch must contain ONLY the selected tasks (titles match exactly); single-use and bound to your session',
      };
    },

    /** Consume one approved confirmationId for this caller, if valid. */
    consumeConfirmation(confirmationId, caller) {
      const record = typeof confirmationId === 'string' ? confirmations.get(confirmationId) : undefined;
      if (!record || record.callerSessionId !== caller.sessionId) return false;
      confirmations.delete(confirmationId);
      return true;
    },

    /**
     * task_workspace (0.12.0): list host workspaces or move an EXISTING
     * top-level session into/out of one. Attach/detach go through the live
     * workspace entity — the same API the host's session.create uses
     * internally (workspace.attachSession validates the session's stored cwd
     * against the workspace path). Never injects a message into the session.
     * Migrate (0.16.0) crosses workspaces whose paths differ from the
     * session's stored cwd — the one thing attach can never do — by cloning
     * the full history into a new session born with the target cwd and
     * archiving the original; the task continues under a NEW session id.
     */
    async workspaceOp({ action, sessionId, workspaceId, workspacePath }, caller) {
      const callerDeny = checkCaller(caller, config);
      if (callerDeny) return failDeny(callerDeny);
      const mode = typeof action === 'string' && action.trim().length > 0 ? action.trim().toLowerCase() : 'list';
      if (!['list', 'attach', 'detach', 'migrate'].includes(mode)) {
        return fail(OP_CODES.BAD_REQUEST, `unknown action '${action}' (expected list | attach | detach | migrate)`);
      }
      if (mode === 'list') {
        let workspaces;
        try {
          workspaces = typeof listWorkspaces === 'function' ? listWorkspaces() : [];
        } catch {
          workspaces = [];
        }
        if (!Array.isArray(workspaces)) workspaces = [];
        return {
          ok: true,
          action: 'list',
          workspaces: workspaces.map((workspace) => ({
            id: workspace?.id,
            path: workspace?.path,
            ...(typeof workspace?.title === 'string' ? { title: workspace.title } : {}),
            sessionIds: Array.isArray(workspace?.sessionIds) ? [...workspace.sessionIds] : [],
          })),
        };
      }
      if (typeof sessionId !== 'string' || sessionId.trim().length === 0) {
        return fail(OP_CODES.BAD_REQUEST, `action '${mode}' requires sessionId`);
      }
      const cleanSessionId = sessionId.trim();
      // Resolve the target workspace: explicit id wins, else exact path match.
      let targetId = typeof workspaceId === 'string' && workspaceId.trim().length > 0 ? workspaceId.trim() : undefined;
      if (!targetId) {
        const byPath = findWorkspaceByPath(workspacePath, listWorkspaces);
        if (byPath?.id) targetId = byPath.id;
      }
      if (!targetId) {
        return fail(OP_CODES.WORKSPACE_NOT_FOUND, 'no workspace matched: pass workspaceId (see action list) or an exact workspacePath');
      }
      if (mode === 'migrate') {
        // (0.25.1) Host-upgrade guard: refuse migrate on host core >= 0.1.5,
        // where the clone route is broken (upstream sessions.flush silently
        // drops plugin-created sessions — the clone "succeeds" in-process then
        // vanishes on restart; readSession throws on seeded/forked sessions —
        // see research/host-upgrade-drift-0.1.2-0.1.5.md face 1 P0/P1). A
        // failed probe returns null and fail-opens (pre-0.25.1 behavior).
        if (shouldGuardMigrate(detectHostCoreVersion(logger))) {
          return fail(OP_CODES.MIGRATE_DISABLED, 'host core >=0.1.5: task_workspace migrate is guard-disabled — upstream sessions.flush no longer persists plugin-created sessions (the clone would "succeed" in-process but vanish on restart) and readSession throws on seeded/forked sessions (upstream regression, unfixed through rc.2); see research/host-upgrade-drift-0.1.2-0.1.5.md face 1 P0/P1. Alternatives: attach/detach still work; cross-workspace migration returns in v0.26 wired to the sessionPersistence.create(header) write-handle seam, or once the host fixes the upstream regression');
        }
        // (0.16.0) True cross-workspace move. The host never rewrites a
        // session's stored cwd — attach validates against it — so a move is a
        // clone: read the complete log (sessionQuery.readSession), seed a NEW
        // session whose header cwd is the target workspace path
        // (sessions.create + flush, the route the host's own fork() uses
        // internally), attach the clone, then archive the original. Rejects
        // running sources: the clone seeds from the persisted log, so a
        // mid-turn migration would drop the in-flight tail.
        const targetPath = workspacePathOf(targetId, listWorkspaces);
        if (typeof targetPath !== 'string' || targetPath.length === 0) {
          return fail(OP_CODES.WORKSPACE_NOT_FOUND, `workspace '${targetId}' exposes no path to migrate into`);
        }
        const live = typeof agents?.get === 'function' ? agents.get(cleanSessionId) : undefined;
        if (live && live.status === 'running') {
          return fail(OP_CODES.MIGRATE_BUSY, `session '${cleanSessionId}' is running; migration clones the persisted log, so wait for the turn to settle (task_wait) first`);
        }
        let snapshot;
        try {
          snapshot = typeof readSessionSnapshot === 'function' ? await readSessionSnapshot(cleanSessionId) : undefined;
        } catch (error) {
          return fail(OP_CODES.MIGRATE_FAILED, `cannot read source session '${cleanSessionId}': ${error?.message ?? error}`);
        }
        if (snapshot === undefined) {
          return fail(OP_CODES.MIGRATE_UNAVAILABLE, 'this host build exposes no session snapshot service (sessionQuery.readSession) for migration');
        }
        const sourceHeader = snapshot?.header;
        if (!sourceHeader || !Array.isArray(snapshot?.events)) {
          return fail(OP_CODES.MIGRATE_FAILED, `source session '${cleanSessionId}' returned no readable log`);
        }
        if (sourceHeader.cwd === targetPath) {
          return fail(OP_CODES.BAD_REQUEST, `session '${cleanSessionId}' already has cwd '${targetPath}' — it belongs to this workspace; use action 'attach' to affiliate it without cloning`);
        }
        let created;
        try {
          created = typeof createSeededSession === 'function'
            ? await createSeededSession({
                seed: snapshot.events,
                meta: {
                  cwd: targetPath,
                  ...(Number.isFinite(sourceHeader.createdAt) ? { createdAt: sourceHeader.createdAt } : {}),
                  ...(typeof sourceHeader.agentPreset === 'string' ? { agentPreset: sourceHeader.agentPreset } : {}),
                },
              })
            : undefined;
        } catch (error) {
          return fail(OP_CODES.MIGRATE_FAILED, `clone failed: ${error?.message ?? error}`);
        }
        const newSessionId = typeof created?.id === 'string' && created.id.length > 0 ? created.id : undefined;
        if (!newSessionId) {
          return fail(OP_CODES.MIGRATE_UNAVAILABLE, 'this host build exposes no seeded-session creation (sessions.create) for migration');
        }
        const migrateEntity = typeof getWorkspace === 'function' ? getWorkspace(targetId) : undefined;
        if (!migrateEntity || typeof migrateEntity.attachSession !== 'function') {
          return fail(OP_CODES.MIGRATE_FAILED, `clone '${newSessionId}' was created but workspace '${targetId}' is not attachable; attach the clone manually (action attach) and archive '${cleanSessionId}' when done`);
        }
        try {
          await migrateEntity.attachSession(newSessionId);
        } catch (error) {
          return fail(OP_CODES.MIGRATE_FAILED, `clone '${newSessionId}' was created but attach to '${targetId}' failed: ${error?.message ?? error}; the original '${cleanSessionId}' was NOT archived`);
        }
        let archived = true;
        let warning;
        try {
          if (typeof archiveSession === 'function') await archiveSession(cleanSessionId);
          else archived = false;
        } catch (error) {
          archived = false;
          warning = `clone '${newSessionId}' is live in '${targetId}' but archiving the original failed: ${error?.message ?? error}`;
        }
        // Carry the registry record (team/depth/parent lineage/title) over to
        // the new id so team filtering and recursion governance survive the
        // move; the old entry stays as history of the archived original.
        const carried = typeof registry?.get === 'function' ? registry.get(cleanSessionId) : undefined;
        if (carried && typeof registry?.record === 'function') {
          registry.record(newSessionId, carried);
        }
        return {
          ok: true,
          action: 'migrate',
          sessionId: newSessionId,
          migratedFrom: cleanSessionId,
          workspaceId: targetId,
          archived,
          ...(carried?.team !== undefined ? { team: carried.team } : {}),
          ...(warning ? { warning } : {}),
          note: `the migrated task continues under the NEW id '${newSessionId}'; message and steer that id, not '${cleanSessionId}' — host archive is workspace-level: the original stays readable and RESUMABLE, and messaging the old id would fork the work into two diverging copies`,
        };
      }
      const entity = typeof getWorkspace === 'function' ? getWorkspace(targetId) : undefined;
      const method = mode === 'attach' ? 'attachSession' : 'detachSession';
      if (!entity || typeof entity[method] !== 'function') {
        return fail(OP_CODES.WORKSPACE_NOT_FOUND, `workspace '${targetId}' is not available from the host registry`);
      }
      try {
        await entity[method](cleanSessionId);
      } catch (error) {
        return fail(OP_CODES.WORKSPACE_OP_FAILED, `${mode} failed: ${error?.message ?? error}`);
      }
      return { ok: true, action: mode, sessionId: cleanSessionId, workspaceId: targetId };
    },

    /**
     * Capability 11 (0.14.0): model-route discovery. Every deployment
     * connects different providers/models, so supervisors must never guess
     * ids: this projects the host's LIVE model catalog
     * (sessionController.modelCatalog — the same source the GUI model picker
     * renders) down to the exact provider/model/reasoning-effort ids
     * task_spawn accepts. Read-only, needs no session.
     */
    async models(_args, caller) {
      const callerDeny = checkCaller(caller, config);
      if (callerDeny) return failDeny(callerDeny);
      if (typeof sessionController?.modelCatalog !== 'function') {
        return fail(OP_CODES.CATALOG_UNAVAILABLE, 'this host build exposes no sessionController.modelCatalog(); rely on the model-unavailable error hints from task_spawn instead');
      }
      let catalog;
      try {
        catalog = await sessionController.modelCatalog();
      } catch (error) {
        return fail(OP_CODES.CATALOG_UNAVAILABLE, `the host model catalog failed: ${error?.message ?? error}`);
      }
      const groups = Array.isArray(catalog?.groups) ? catalog.groups : [];
      const providers = groups.map((group) => ({
        id: group.id,
        ...(typeof group.name === 'string' && group.name.length > 0 && group.name !== group.id ? { name: group.name } : {}),
        models: (Array.isArray(group.models) ? group.models : []).map((model) => ({
          id: model.id,
          ...(typeof model.name === 'string' && model.name.length > 0 && model.name !== model.id ? { name: model.name } : {}),
          ...(model.reasoning
            ? {
                efforts: (Array.isArray(model.reasoning.efforts) ? model.reasoning.efforts : []).map((effort) => effort?.id).filter(Boolean),
                ...(model.reasoning.defaultEffort ? { defaultEffort: model.reasoning.defaultEffort } : {}),
              }
            : {}),
        })),
      }));
      const failures = Array.isArray(catalog?.failures) ? catalog.failures : [];
      // 0.18.0: surface the plugin's configured spawn default (if any) beside
      // the host default so a supervisor sees the whole resolution chain in
      // one read: explicit tool args > pluginDefault > default.
      let pluginDefault;
      if (typeof readSpawnDefaults === 'function') {
        try {
          pluginDefault = readSpawnDefaults() ?? undefined;
        } catch {
          pluginDefault = undefined;
        }
      }
      return {
        ok: true,
        ...(catalog?.default ? { default: catalog.default } : {}),
        ...(pluginDefault !== undefined ? { pluginDefault } : {}),
        providers,
        ...(failures.length > 0 ? { failedProviders: failures.map((entry) => ({ id: entry.id, message: entry.message })) } : {}),
        hint: 'use these exact provider/model ids in task_spawn / task_spawn_batch; reasoningEffort must be one of the listed efforts; a spawn that omits provider+model uses the pluginDefault route (if listed), then the host default',
      };
    },

    /**
     * Capability 6b: spawn a whole decomposition plan in one call.
     * Every item goes through spawnTask (title rule, registry, depth
     * governance); one failed item does not abort the rest. Batches at or
     * above confirmBatchThreshold require an approved confirmationId when
     * confirmBeforeBatch is on.
     */
    async spawnBatch({ tasks, team, confirmationId, reportBack }, caller, signal) {
      const callerDeny = checkCaller(caller, config);
      if (callerDeny) return failDeny(callerDeny);
      if (!Array.isArray(tasks) || tasks.length === 0) {
        return fail(OP_CODES.BAD_REQUEST, 'tasks must be a non-empty array of {title?, prompt} items');
      }
      if (tasks.length > config.maxBatchSpawn) {
        return fail(OP_CODES.BAD_REQUEST, `batch of ${tasks.length} exceeds maxBatchSpawn (${config.maxBatchSpawn}); split into smaller batches`);
      }
      for (const [index, item] of tasks.entries()) {
        if (!item || typeof item !== 'object' || typeof item.prompt !== 'string' || item.prompt.trim().length === 0) {
          return fail(OP_CODES.BAD_REQUEST, `tasks[${index}].prompt is required`);
        }
      }
      // Dispatch confirmation gate: big fan-outs must be user-approved first.
      const needsConfirmation = config.confirmBeforeBatch && tasks.length >= config.confirmBatchThreshold;
      const record = typeof confirmationId === 'string' ? confirmations.get(confirmationId) : undefined;
      if (needsConfirmation && (!record || record.callerSessionId !== caller.sessionId)) {
        return fail(
          OP_CODES.CONFIRMATION_REQUIRED,
          `batches of ${config.confirmBatchThreshold}+ tasks need user approval: call task_confirm with this plan first, then pass its confirmationId`,
        );
      }
      // Select-form approval (task_confirm_select, 0.10.0): the batch must stay
      // within the user-checked subset regardless of whether the size gate fired.
      if (record && record.callerSessionId === caller.sessionId && Array.isArray(record.selected)) {
        const approved = new Set(record.selected);
        const unapproved = tasks
          .map((item) => (typeof item.title === 'string' && item.title.trim().length > 0 ? item.title.trim() : '(untitled)'))
          .filter((title) => !approved.has(title));
        if (unapproved.length > 0) {
          return fail(
            OP_CODES.CONFIRMATION_MISMATCH,
            `the user only approved: ${record.selected.join(', ')} — not approved in this batch: ${unapproved.join(', ')}. Drop the unapproved items or re-confirm with task_confirm_select`,
          );
        }
      }
      const cleanTeam = typeof team === 'string' && team.trim().length > 0 ? team.trim() : undefined;
      const results = [];
      let startedCount = 0;
      for (const item of tasks) {
        // Each item gets its own signal-free path; abort the whole batch when
        // the caller's signal is already gone.
        if (signal?.aborted) {
          results.push({ ok: false, code: 'bad-request', error: 'batch aborted by caller' });
          continue;
        }
        const result = await ops.spawnTask({
          title: item.title,
          prompt: item.prompt,
          cwd: item.cwd,
          sessionId: item.sessionId,
          agentPreset: item.agentPreset,
          provider: item.provider,
          model: item.model,
          reasoningEffort: item.reasoningEffort,
          team: cleanTeam,
          reportBack,
          // NOTE (0.25.0): externalRef is deliberately NOT forwarded — batch
          // dispatch is out of scope for this version (the bridge MVP has no
          // batch endpoint). An item.externalRef present on the raw input is
          // ignored (never recorded, never echoed); the tool schema's
          // additionalProperties:false rejects it at the host schema layer.
        }, caller, signal);
        if (result.ok) startedCount += 1;
        // Per-item receipts carry the workspace observability fields (0.19.0)
        // — workspace/placement on every item, warning on ungrouped ones —
        // so a batch supervisor sees placements without N task_list calls.
        results.push(result.ok
          ? {
              ok: true,
              sessionId: result.sessionId,
              title: result.title,
              correlationId: result.correlationId,
              depth: result.depth,
              workspace: result.workspace,
              placement: result.placement,
              ...(result.warning !== undefined ? { warning: result.warning } : {}),
            }
          : { ok: false, code: result.code, error: result.error, ...(result.sessionId !== undefined ? { sessionId: result.sessionId } : {}) });
      }
      if (startedCount === 0) {
        // Keep the confirmation usable so the supervisor does not re-ask for
        // the same plan after an all-failed attempt.
        return { ok: false, code: OP_CODES.BATCH_ALL_FAILED, error: `all ${tasks.length} batch spawns failed`, results };
      }
      if (needsConfirmation && typeof confirmationId === 'string' && record?.reusable !== true) {
        confirmations.delete(confirmationId); // single-use: consumed on success (reusable credentials survive)
      }
      return {
        ok: true,
        startedCount,
        failedCount: results.length - startedCount,
        ...(cleanTeam !== undefined ? { team: cleanTeam } : {}),
        results,
        hint: 'wait for the whole batch with task_wait({ sessionIds: [...], mode: "all" })',
      };
    },

    /**
     * Capability 5 (wait): block until task(s) become idle, or time out.
     * mode 'all' settles when every target is idle; 'any' when the first is.
     */
    async waitFor({ sessionId, sessionIds, timeoutMs, mode = 'all', signal } = {}, caller) {
      const callerDeny = checkCaller(caller, config);
      if (callerDeny) return failDeny(callerDeny);
      const targets = normalizeTargetIds({ sessionId, sessionIds });
      if (targets.length === 0) {
        return fail(OP_CODES.BAD_REQUEST, 'sessionId or sessionIds is required');
      }
      if (mode !== 'all' && mode !== 'any') {
        return fail(OP_CODES.BAD_REQUEST, "mode must be 'all' or 'any'");
      }
      const requested = Number.isFinite(timeoutMs) && timeoutMs > 0 ? timeoutMs : config.waitDefaultTimeoutMs;
      const clamped = Math.min(requested, config.waitMaxTimeoutMs);
      const startedAt = Date.now();

      let rows;
      try {
        const listed = await sessionController.list({}, signal);
        rows = Array.isArray(listed) ? listed : listed?.items;
        if (!Array.isArray(rows)) throw new Error();
      } catch { return fail(OP_CODES.WAIT_FAILED, 'target list unavailable; task state is unknown'); }
      for (const id of targets) {
        const row = rows.find(row => row.sessionId === id);
        const denial = checkTarget(caller, row);
        if (denial) return { ...failDeny(denial), sessionId: id };
        if (!agents.get(id) && row.running === true) return { ...fail(OP_CODES.WAIT_FAILED, 'target is running without an observable local agent'), sessionId: id };
      }
      const snapshot = targets.map((id) => {
        const agent = agents.get(id);
        const alreadyIdle = !agent || agent.status === 'idle';
        return { sessionId: id, agent, idle: alreadyIdle };
      });
      const targetOf = (id) => snapshot.find((entry) => entry.sessionId === id);
      const finish = (settled, reason) => ({
        ok: true,
        mode,
        settled,
        reason,
        waitedMs: Date.now() - startedAt,
        count: targets.length,
        targets: snapshot.map((entry) => ({
          sessionId: entry.sessionId,
          idle: entry.idle,
          agentState: entry.agent ? entry.agent.status : 'cold-idle',
        })),
        ...(targets.length === 1 ? { sessionId: targets[0] } : {}),
      });

      if (mode === 'all' && snapshot.every((entry) => entry.idle)) {
        return finish(true, targets.length === 1 ? 'target already idle' : 'all targets already idle');
      }
      if (mode === 'any' && snapshot.some((entry) => entry.idle)) {
        const first = snapshot.find((entry) => entry.idle);
        return finish(true, `target ${first.sessionId} already idle`);
      }

      const idleWatches = snapshot
        .filter((entry) => !entry.idle && entry.agent)
        .map((entry) => entry.agent.whenIdle().then(() => { entry.idle = true; return entry.sessionId; }));
      let timer, abortHandler;
      const timeout = new Promise((resolve) => {
        timer = setTimeout(() => resolve('timeout'), clamped);
        if (typeof timer.unref === 'function') timer.unref();
      });
      const aborted = new Promise((resolve) => {
        if (!signal) return;
        if (signal.aborted) return resolve('aborted');
        abortHandler = () => resolve('aborted');
        signal.addEventListener('abort', abortHandler, { once: true });
      });
      const barrier = mode === 'all' ? Promise.all(idleWatches).then(() => 'all-idle') : Promise.race(idleWatches);
      let woke;
      try {
        woke = await Promise.race([barrier, timeout, aborted]);
      } catch (error) {
        return fail(OP_CODES.WAIT_FAILED, `wait failed: ${error?.message ?? error}`);
      } finally {
        clearTimeout(timer);
        if (abortHandler) signal?.removeEventListener('abort', abortHandler);
      }
      if (woke === 'aborted') return finish(false, 'wait aborted by caller');
      if (woke === 'timeout') {
        const pending = snapshot.filter((entry) => !entry.idle).map((entry) => entry.sessionId);
        return {
          ...finish(false, `timed out after ${clamped}ms; still running: ${pending.join(', ')}`),
          hint: 'still running: check task_progress for the real state; as a supervisor, consider ending your turn instead of blocking — queued messages auto-open a new round on an idle session (one next-turn message per round)',
        };
      }
      if (mode === 'any') return finish(true, `target ${woke} became idle`);
      return finish(true, targets.length === 1 ? 'target became idle' : 'all targets became idle');
    },

    /** Capability 5 (hard stop): cancel the active turn, keep the inbox. */
    async cancelTask(targetId, caller) {
      const callerDeny = checkCaller(caller, config);
      if (callerDeny) return failDeny(callerDeny);
      const agent = agents.get(targetId);
      if (!agent) return fail(OP_CODES.TARGET_COLD, 'target has no live agent; nothing to cancel');
      const targetDeny = checkTarget(caller, { sessionId: targetId, origin: agent.session?.header?.origin });
      if (targetDeny) return failDeny(targetDeny);
      try {
        await sessionController.cancel({ sessionId: targetId });
      } catch (error) {
        return fail(OP_CODES.CANCEL_REJECTED, `cancel rejected: ${error?.message ?? error}`);
      }
      limiter.forget(targetId);
      return { ok: true, cancelled: true, sessionId: targetId, note: 'active turn cancelled; queued messages are kept' };
    },
  };

  return ops;
}
