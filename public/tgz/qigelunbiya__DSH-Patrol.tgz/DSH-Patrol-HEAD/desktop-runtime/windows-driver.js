import { execFile } from 'node:child_process'
import { mkdir, readFile, readdir } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { basename, dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { promisify } from 'node:util'
import { randomUUID } from 'node:crypto'

const execFileAsync = promisify(execFile)
const SCRIPT_PATH = fileURLToPath(new URL('./windows-desktop.ps1', import.meta.url))
const BUNDLED_GUIDES = fileURLToPath(new URL('../desktop-knowledge/', import.meta.url))
const MAX_STDOUT = 4 * 1024 * 1024
const MAX_GUIDE_CHARS = 30000
const MAX_OCR_CHARS = 12000
const DESKTOP_MODEL_IMAGE_MAX_WIDTH = 768
const DESKTOP_MODEL_IMAGE_MAX_HEIGHT = 768
const DESKTOP_MODEL_IMAGE_JPEG_QUALITY = 65
const READ_IMAGE_EXACT_PATH_CONTRACT = 'Call read_image with readImagePath EXACTLY as returned by this tool. Never reconstruct, guess, or synthesize a desktop capture filename from timestamps, UUID-like suffixes, or prior screenshots.'

export class WindowsDesktopDriver {
  constructor(options = {}) {
    this.logger = options.logger
    this.commandTimeoutMs = options.commandTimeoutMs ?? 30000
    this.powerShell = options.powerShell || process.env.DSH_PATROL_POWERSHELL || 'powershell.exe'
    this.visualFrames = new Map()
    this.visualRegions = new Map()
    this.visualActionMaps = new Map()
    this.lastVisualFrameId = undefined
  }

  get supported() {
    return process.platform === 'win32'
  }

  async status(exec) {
    const base = {
      platform: process.platform,
      supported: this.supported,
      backend: this.supported ? 'windows-uia+powershell' : 'unsupported',
      permissionMode: 'unrestricted',
      strategy: ['vision', 'keyboard', 'ocr', 'uia', 'visual-point', 'coordinates'],
    }
    if (!this.supported) return { ok: true, ...base, backendReachable: false }
    try {
      const probe = await this.run('list-windows', {}, exec)
      return {
        ok: true,
        ...base,
        backendReachable: true,
        visibleWindowCount: Array.isArray(probe.windows) ? probe.windows.length : 0,
      }
    } catch (error) {
      return {
        ok: false,
        ...base,
        backendReachable: false,
        error: error instanceof Error ? error.message : String(error),
      }
    }
  }

  async run(action, args = {}, exec) {
    if (!this.supported) {
      throw new Error(`Desktop Automation currently requires Windows; current platform=${process.platform}`)
    }
    const payload = Buffer.from(JSON.stringify(args), 'utf8').toString('base64')
    let stdout
    let stderr
    try {
      const result = await execFileAsync(this.powerShell, [
        '-NoProfile',
        '-NonInteractive',
        '-STA',
        '-ExecutionPolicy', 'Bypass',
        '-File', SCRIPT_PATH,
        '-Action', action,
        '-Payload', payload,
      ], {
        windowsHide: true,
        timeout: this.commandTimeoutMs,
        maxBuffer: MAX_STDOUT,
        encoding: 'utf8',
        signal: exec?.signal,
      })
      stdout = result.stdout
      stderr = result.stderr
    } catch (error) {
      stdout = error?.stdout
      stderr = error?.stderr
      const parsed = parseLastJson(stdout)
      if (parsed?.error) throw new Error(parsed.error)
      throw new Error(cleanPowerShellError(error, stderr))
    }
    const parsed = parseLastJson(stdout)
    if (!parsed || parsed.ok !== true) {
      throw new Error(parsed?.error || `desktop action ${action} returned invalid output`)
    }
    return parsed
  }

  async screenshot(args = {}, exec) {
    const path = await this.nextScreenshotPath(exec, args.fileName)
    const shot = await this.run('screenshot', { ...args, path }, exec)
    if (args.visualGuide !== true || !shot?.path) return shot

    const rawPath = String(shot.path)
    const guidePath = siblingPngPath(rawPath, '-visual-guide')
    try {
      const guide = await this.run('annotate-visual-guide', {
        sourcePath: rawPath,
        path: guidePath,
      }, exec)
      return {
        ...shot,
        rawPath,
        path: String(guide?.path || guidePath),
        visualGuide: true,
        coordinateGridUnits: 1000,
      }
    } catch (error) {
      this.logger?.warn?.(`[dsh-patrol/desktop] visual guide overlay failed; using raw screenshot: ${errorMessage(error)}`)
      return {
        ...shot,
        rawPath,
        visualGuide: false,
      }
    }
  }

  async visualScreenshot(args = {}, exec) {
    const scope = args.scope === 'screen' ? 'screen' : 'active-window'
    const rawShot = await this.screenshot({
      ...args,
      scope,
      captureMethod: 'screen',
      visualGuide: false,
    }, exec)
    const rawPath = String(rawShot?.rawPath ?? rawShot?.path ?? '')
    if (!rawPath) throw new Error('desktop_screenshot did not return a raw capture path')

    const modelPath = siblingJpegPath(rawPath, '-model')
    const modelImage = await this.run('prepare-model-vision', {
      sourcePath: rawPath,
      path: modelPath,
      maxWidth: DESKTOP_MODEL_IMAGE_MAX_WIDTH,
      maxHeight: DESKTOP_MODEL_IMAGE_MAX_HEIGHT,
      jpegQuality: DESKTOP_MODEL_IMAGE_JPEG_QUALITY,
      upscale: false,
    }, exec)
    const modelReadPath = String(modelImage?.path || modelPath)
    await assertReadableGeneratedImage(modelReadPath, 'desktop model vision', exec?.signal)
    const shot = {
      ...rawShot,
      rawPath,
      path: modelReadPath,
      readImagePath: modelReadPath,
      imageReady: true,
      readImageContract: READ_IMAGE_EXACT_PATH_CONTRACT,
      rawWidth: finiteNumber(rawShot.width, 0),
      rawHeight: finiteNumber(rawShot.height, 0),
      width: finiteNumber(modelImage?.width, rawShot.width),
      height: finiteNumber(modelImage?.height, rawShot.height),
      modelVisionBounded: true,
      modelVisionMaxWidth: DESKTOP_MODEL_IMAGE_MAX_WIDTH,
      modelVisionMaxHeight: DESKTOP_MODEL_IMAGE_MAX_HEIGHT,
      modelVisionJpegQuality: DESKTOP_MODEL_IMAGE_JPEG_QUALITY,
    }
    if (scope !== 'active-window') return shot

    const rect = screenshotBounds(rawShot)
    const window = rawShot?.window
    const hwnd = finiteNumber(window?.hwnd, 0)
    const windowRect = {
      x: finiteNumber(window?.rect?.x, NaN),
      y: finiteNumber(window?.rect?.y, NaN),
      width: finiteNumber(window?.rect?.width, NaN),
      height: finiteNumber(window?.rect?.height, NaN),
    }
    if (!Number.isFinite(hwnd) || hwnd === 0 || rect.width <= 0 || rect.height <= 0) {
      throw new Error('desktop_screenshot did not return a valid top-level window frame')
    }
    if (!sameRect(rect, windowRect, 2)) {
      throw new Error(`desktop_screenshot frame mismatch: capture=${formatRect(rect)} window=${formatRect(windowRect)}`)
    }

    const frameId = `visual-${randomUUID()}`
    const frame = {
      frameId,
      createdAt: Date.now(),
      path: shot.path,
      rawPath,
      hwnd,
      processName: String(window?.processName ?? ''),
      title: String(window?.title ?? ''),
      rect,
      imageWidth: finiteNumber(shot.width, rect.width),
      imageHeight: finiteNumber(shot.height, rect.height),
      rawImageWidth: finiteNumber(rawShot.width, rect.width),
      rawImageHeight: finiteNumber(rawShot.height, rect.height),
    }
    this.visualFrames.set(frameId, frame)
    this.lastVisualFrameId = frameId
    while (this.visualFrames.size > 12) {
      const oldest = this.visualFrames.keys().next().value
      if (!oldest) break
      this.visualFrames.delete(oldest)
    }

    return {
      ...shot,
      frameId,
      visualFrame: {
        frameId,
        hwnd,
        processName: frame.processName,
        title: frame.title,
        rect,
        imageWidth: frame.imageWidth,
        imageHeight: frame.imageHeight,
        rawImageWidth: frame.rawImageWidth,
        rawImageHeight: frame.rawImageHeight,
        coordinateSpace: 'physical-screen-top-level-window',
      },
    }
  }

  async focusVisualRegion(args = {}, exec) {
    const requestedFrameId = String(args.frameId ?? '').trim()
    const frameId = requestedFrameId || this.lastVisualFrameId
    if (!frameId) throw new Error('desktop_focus_visual_region requires a fresh desktop_screenshot first')
    const frame = this.visualFrames.get(frameId)
    if (!frame) throw new Error(`desktop visual frame ${JSON.stringify(frameId)} is unavailable; take a new desktop_screenshot`)
    if (Date.now() - frame.createdAt > 120000) {
      this.visualFrames.delete(frameId)
      if (this.lastVisualFrameId === frameId) this.lastVisualFrameId = undefined
      throw new Error('desktop visual frame is stale; take a new desktop_screenshot')
    }
    assertVisualFrameTarget(frame, args)

    const centerX = ratioValue(args.centerXRatio, NaN, 'centerXRatio')
    const centerY = ratioValue(args.centerYRatio, NaN, 'centerYRatio')
    const requestedWidth = Number.isFinite(Number(args.widthRatio)) ? Number(args.widthRatio) : 0.24
    const requestedHeight = Number.isFinite(Number(args.heightRatio)) ? Number(args.heightRatio) : 0.24
    const widthRatio = Math.max(0.06, Math.min(0.70, requestedWidth))
    const heightRatio = Math.max(0.06, Math.min(0.70, requestedHeight))
    const xRatio = Math.max(0, Math.min(1 - widthRatio, centerX - widthRatio / 2))
    const yRatio = Math.max(0, Math.min(1 - heightRatio, centerY - heightRatio / 2))

    const regionPath = siblingJpegPath(frame.rawPath || frame.path, `-focus-${randomUUID().slice(0, 8)}`)
    const prepared = await this.run('prepare-model-vision', {
      sourcePath: frame.rawPath || frame.path,
      path: regionPath,
      maxWidth: 768,
      maxHeight: 768,
      jpegQuality: 70,
      cropXRatio: xRatio,
      cropYRatio: yRatio,
      cropWidthRatio: widthRatio,
      cropHeightRatio: heightRatio,
      upscale: true,
    }, exec)
    const regionReadPath = String(prepared?.path || regionPath)
    await assertReadableGeneratedImage(regionReadPath, 'desktop focused region', exec?.signal)
    const crop = prepared?.crop ?? { xRatio, yRatio, widthRatio, heightRatio }
    const regionId = `desktop-region-${randomUUID()}`
    const region = {
      regionId,
      frameId,
      createdAt: Date.now(),
      path: regionReadPath,
      width: finiteNumber(prepared?.width, 0),
      height: finiteNumber(prepared?.height, 0),
      crop: {
        xRatio: ratioValue(crop.xRatio, xRatio, 'crop.xRatio'),
        yRatio: ratioValue(crop.yRatio, yRatio, 'crop.yRatio'),
        widthRatio: ratioValue(crop.widthRatio, widthRatio, 'crop.widthRatio'),
        heightRatio: ratioValue(crop.heightRatio, heightRatio, 'crop.heightRatio'),
      },
    }
    this.visualRegions.set(regionId, region)
    frame.focusedRegionId = regionId
    frame.visualMode = 'focused-region'
    while (this.visualRegions.size > 24) {
      const oldest = this.visualRegions.keys().next().value
      if (!oldest) break
      this.visualRegions.delete(oldest)
    }
    return {
      ok: true,
      frameId,
      regionId,
      path: region.path,
      readImagePath: region.path,
      imageReady: true,
      readImageContract: READ_IMAGE_EXACT_PATH_CONTRACT,
      width: region.width,
      height: region.height,
      crop: region.crop,
      coordinateMapping: 'focused-region-observation-only',
      clickContract: 'This focused region is OBSERVATION ONLY. Read it, then call desktop_visual_action_map with SAME frameId + regionId. Choose D# and click via desktop_click_visual_candidate. Direct focused-image x/y clicking is disabled.',
    }
  }

  async visualActionMap(args = {}, exec) {
    const requestedFrameId = String(args.frameId ?? '').trim()
    const frameId = requestedFrameId || this.lastVisualFrameId
    if (!frameId) throw new Error('desktop_visual_action_map requires a fresh desktop_screenshot first')
    const frame = this.visualFrames.get(frameId)
    if (!frame) throw new Error(`desktop visual frame ${JSON.stringify(frameId)} is unavailable; take a new desktop_screenshot`)
    if (Date.now() - frame.createdAt > 120000) {
      this.consumeVisualFrame(frameId)
      throw new Error('desktop visual frame is stale; take a new desktop_screenshot')
    }
    assertVisualFrameTarget(frame, args)

    let crop
    const regionId = String(args.regionId ?? '').trim()
    if (regionId) {
      const region = this.visualRegions.get(regionId)
      if (!region || region.frameId !== frameId) throw new Error('desktop_visual_action_map regionId is unavailable or belongs to another frame')
      crop = region.crop
    } else {
      const centerX = ratioValue(args.centerXRatio, 0.5, 'centerXRatio')
      const centerY = ratioValue(args.centerYRatio, 0.5, 'centerYRatio')
      const widthRatio = Math.max(0.08, Math.min(0.75, Number.isFinite(Number(args.widthRatio)) ? Number(args.widthRatio) : 0.28))
      const heightRatio = Math.max(0.08, Math.min(0.75, Number.isFinite(Number(args.heightRatio)) ? Number(args.heightRatio) : 0.28))
      crop = {
        xRatio: Math.max(0, Math.min(1 - widthRatio, centerX - widthRatio / 2)),
        yRatio: Math.max(0, Math.min(1 - heightRatio, centerY - heightRatio / 2)),
        widthRatio,
        heightRatio,
      }
    }

    const mapId = `desktop-map-${randomUUID()}`
    const path = siblingJpegPath(frame.rawPath || frame.path, `-action-map-${randomUUID().slice(0, 8)}`)
    const built = await this.run('build-visual-action-map', {
      sourcePath: frame.rawPath || frame.path,
      path,
      cropXRatio: crop.xRatio,
      cropYRatio: crop.yRatio,
      cropWidthRatio: crop.widthRatio,
      cropHeightRatio: crop.heightRatio,
      maxCandidates: Number.isInteger(args.maxCandidates) ? Math.max(3, Math.min(30, args.maxCandidates)) : 18,
    }, exec)
    const mapReadPath = String(built?.path || path)
    await assertReadableGeneratedImage(mapReadPath, 'desktop visual Action Map', exec?.signal)
    const candidates = normalizeDesktopVisualCandidates(built?.candidates)
    if (candidates.length === 0) {
      throw new Error('desktop visual Action Map found no stable visual candidates in this region; focus a tighter/different CURRENT region')
    }
    const map = {
      mapId,
      frameId,
      createdAt: Date.now(),
      path: mapReadPath,
      crop,
      candidates,
    }
    this.visualActionMaps.set(mapId, map)
    frame.activeActionMapId = mapId
    frame.visualMode = 'action-map'
    while (this.visualActionMaps.size > 24) {
      const oldest = this.visualActionMaps.keys().next().value
      if (!oldest) break
      this.visualActionMaps.delete(oldest)
    }
    return {
      ok: true,
      frameId,
      actionMapId: mapId,
      path: map.path,
      readImagePath: map.path,
      imageReady: true,
      readImageContract: READ_IMAGE_EXACT_PATH_CONTRACT,
      crop,
      candidateCount: candidates.length,
      candidates,
      clickContract: 'Read this Desktop Action Map and choose D#. Call desktop_click_visual_candidate with SAME frameId + actionMapId + candidateId. Patrol clicks the program-computed bbox center; do not provide x/y.',
    }
  }

  async clickVisualCandidate(args = {}, exec) {
    const frameId = String(args.frameId ?? '').trim()
    const mapId = String(args.actionMapId ?? '').trim()
    const candidateId = String(args.candidateId ?? '').trim().toUpperCase()
    if (!frameId || !mapId || !candidateId) throw new Error('desktop_click_visual_candidate requires frameId, actionMapId and candidateId')
    const frame = this.visualFrames.get(frameId)
    const map = this.visualActionMaps.get(mapId)
    if (!frame || !map || map.frameId !== frameId) throw new Error('desktop visual Action Map is unavailable or stale; take a new screenshot/map')
    if (frame.activeActionMapId !== mapId) throw new Error('desktop visual frame is bound to a different CURRENT Action Map')
    assertVisualFrameTarget(frame, args)
    const candidate = map.candidates.find(item => item.candidateId === candidateId)
    if (!candidate) throw new Error(`desktop visual candidate ${JSON.stringify(candidateId)} not found; available=${map.candidates.map(item => item.candidateId).join(',')}`)

    let templatePath
    if (typeof args.templatePath === 'string' && args.templatePath.trim()) {
      templatePath = args.templatePath.trim()
      await this.run('prepare-model-vision', {
        sourcePath: frame.rawPath || frame.path,
        path: templatePath,
        maxWidth: 2048,
        maxHeight: 2048,
        jpegQuality: 92,
        cropXRatio: candidate.leftRatio,
        cropYRatio: candidate.topRatio,
        cropWidthRatio: candidate.widthRatio,
        cropHeightRatio: candidate.heightRatio,
        upscale: false,
      }, exec)
    }

    const result = await this.run('click-visual-point', {
      processName: frame.processName,
      title: frame.title,
      xRatio: candidate.centerXRatio,
      yRatio: candidate.centerYRatio,
      button: args.button === 'right' ? 'right' : 'left',
      hwnd: frame.hwnd,
      frameHwnd: frame.hwnd,
      frameX: frame.rect.x,
      frameY: frame.rect.y,
      frameWidth: frame.rect.width,
      frameHeight: frame.rect.height,
    }, exec)
    this.consumeVisualFrame(frameId)
    return {
      ...result,
      frameId,
      actionMapId: mapId,
      candidateId,
      candidate,
      xRatio: candidate.centerXRatio,
      yRatio: candidate.centerYRatio,
      coordinateMapping: 'desktop-action-map-bbox-center',
      ...(templatePath ? {
        templatePath,
        templateSearchWidthRatio: Math.max(0.12, Math.min(0.32, candidate.widthRatio * 8)),
        templateSearchHeightRatio: Math.max(0.12, Math.min(0.32, candidate.heightRatio * 8)),
        templateMinScore: 0.76,
      } : {}),
    }
  }

  async clickVisualTemplate(args = {}, exec) {
    const templatePath = String(args.templatePath ?? '').trim()
    if (!templatePath) throw new Error('desktop_click_visual_template requires templatePath')
    const expectedXRatio = ratioValue(args.expectedXRatio, NaN, 'expectedXRatio')
    const expectedYRatio = ratioValue(args.expectedYRatio, NaN, 'expectedYRatio')
    const searchWidthRatio = Math.max(0.08, Math.min(0.45, Number.isFinite(Number(args.searchWidthRatio)) ? Number(args.searchWidthRatio) : 0.20))
    const searchHeightRatio = Math.max(0.08, Math.min(0.45, Number.isFinite(Number(args.searchHeightRatio)) ? Number(args.searchHeightRatio) : 0.20))
    const minScore = Math.max(0.50, Math.min(0.98, Number.isFinite(Number(args.minScore)) ? Number(args.minScore) : 0.76))

    const shot = await this.screenshot({
      ...args,
      scope: 'active-window',
      captureMethod: 'screen',
      visualGuide: false,
    }, exec)
    const sourcePath = String(shot?.rawPath ?? shot?.path ?? '')
    const rect = screenshotBounds(shot)
    const window = shot?.window
    const hwnd = finiteNumber(window?.hwnd, 0)
    if (!sourcePath || !hwnd || rect.width <= 0 || rect.height <= 0) throw new Error('desktop template replay could not capture a valid target window')
    const match = await this.run('match-visual-template', {
      sourcePath,
      templatePath,
      expectedXRatio,
      expectedYRatio,
      searchWidthRatio,
      searchHeightRatio,
    }, exec)
    const score = finiteNumber(match?.score, -1)
    if (match?.matched !== true || score < minScore) {
      throw new Error(`desktop learned icon template did not match confidently: score=${score.toFixed(3)} required>=${minScore.toFixed(3)}; rebuild the teaching candidate/template`)
    }
    const xRatio = ratioValue(match.centerXRatio, NaN, 'template centerXRatio')
    const yRatio = ratioValue(match.centerYRatio, NaN, 'template centerYRatio')
    const result = await this.run('click-visual-point', {
      processName: String(window?.processName ?? args.processName ?? ''),
      title: String(window?.title ?? ''),
      xRatio,
      yRatio,
      button: args.button === 'right' ? 'right' : 'left',
      hwnd,
      frameHwnd: hwnd,
      frameX: rect.x,
      frameY: rect.y,
      frameWidth: rect.width,
      frameHeight: rect.height,
    }, exec)
    return {
      ...result,
      method: 'learned-icon-template',
      templatePath,
      templateScore: score,
      templateScale: finiteNumber(match?.scale, 1),
      xRatio,
      yRatio,
      searchWidthRatio,
      searchHeightRatio,
      minScore,
    }
  }

  async clickVisualPoint(args = {}, exec) {
    const requestedFrameId = String(args.frameId ?? '').trim()
    const frameId = requestedFrameId || this.lastVisualFrameId
    if (!frameId) throw new Error('desktop_click_visual_point requires a fresh desktop_screenshot first')
    const frame = this.visualFrames.get(frameId)
    if (!frame) {
      throw new Error(`desktop visual frame ${JSON.stringify(frameId)} is unavailable or already consumed; take a new desktop_screenshot`)
    }
    if (Date.now() - frame.createdAt > 120000) {
      this.visualFrames.delete(frameId)
      if (this.lastVisualFrameId === frameId) this.lastVisualFrameId = undefined
      throw new Error('desktop visual frame is stale; take a new desktop_screenshot')
    }
    assertVisualFrameTarget(frame, args)
    if (frame.focusedRegionId) {
      throw new Error('desktop visual frame is focused-region constrained; build desktop_visual_action_map with the SAME frameId + regionId and click a D# candidate, or take a new desktop_screenshot')
    }
    if (frame.activeActionMapId) {
      throw new Error('desktop visual frame has an active Action Map; use desktop_click_visual_candidate with candidateId, or take a new desktop_screenshot')
    }

    const directRatioX = Number(args.xRatio)
    const directRatioY = Number(args.yRatio)
    const hasDirectRatio = Number.isFinite(directRatioX) && Number.isFinite(directRatioY)
    const imageX = Number(args.imageX)
    const imageY = Number(args.imageY)
    const imageWidth = Number(args.imageWidth)
    const imageHeight = Number(args.imageHeight)
    const hasImagePoint = [imageX, imageY, imageWidth, imageHeight].every(Number.isFinite)
      && imageWidth > 1 && imageHeight > 1
      && imageX >= 0 && imageX <= imageWidth
      && imageY >= 0 && imageY <= imageHeight
    if (!hasDirectRatio && !hasImagePoint) {
      throw new Error('desktop_click_visual_point requires either xRatio/yRatio or imageX/imageY/imageWidth/imageHeight')
    }

    const localXRatio = hasImagePoint ? ratioValue(imageX / imageWidth, NaN, 'imageX/imageWidth') : undefined
    const localYRatio = hasImagePoint ? ratioValue(imageY / imageHeight, NaN, 'imageY/imageHeight') : undefined
    const xRatio = hasDirectRatio ? ratioValue(directRatioX, NaN, 'xRatio') : localXRatio
    const yRatio = hasDirectRatio ? ratioValue(directRatioY, NaN, 'yRatio') : localYRatio

    const result = await this.run('click-visual-point', {
      ...args,
      xRatio,
      yRatio,
      hwnd: frame.hwnd,
      frameHwnd: frame.hwnd,
      frameX: frame.rect.x,
      frameY: frame.rect.y,
      frameWidth: frame.rect.width,
      frameHeight: frame.rect.height,
    }, exec)
    this.consumeVisualFrame(frameId)
    return {
      ...result,
      frameId,
      screenshotPath: frame.path,
      rawScreenshotPath: frame.rawPath,
      frameBounds: frame.rect,
      xRatio,
      yRatio,
      coordinateMapping: hasDirectRatio
        ? 'full-window-normalized-ratio'
        : 'model-image-pixel-to-full-window-ratio',
      ...(hasImagePoint ? {
        modelImagePoint: { x: imageX, y: imageY, width: imageWidth, height: imageHeight },
      } : {}),
    }
  }

  consumeVisualFrame(frameId) {
    this.visualFrames.delete(frameId)
    for (const [id, item] of this.visualRegions) {
      if (item.frameId === frameId) this.visualRegions.delete(id)
    }
    for (const [id, item] of this.visualActionMaps) {
      if (item.frameId === frameId) this.visualActionMaps.delete(id)
    }
    if (this.lastVisualFrameId === frameId) this.lastVisualFrameId = undefined
  }

  async previewVisualPoint(args = {}, exec) {
    const requestedFrameId = String(args.frameId ?? '').trim()
    const frameId = requestedFrameId || this.lastVisualFrameId
    if (!frameId) throw new Error('desktop_preview_visual_point requires a fresh desktop_screenshot first')
    const frame = this.visualFrames.get(frameId)
    if (!frame) throw new Error(`desktop visual frame ${JSON.stringify(frameId)} is unavailable; take a new desktop_screenshot`)
    if (Date.now() - frame.createdAt > 120000) {
      this.visualFrames.delete(frameId)
      if (this.lastVisualFrameId === frameId) this.lastVisualFrameId = undefined
      throw new Error('desktop visual frame is stale; take a new desktop_screenshot')
    }
    assertVisualFrameTarget(frame, args)
    const xRatio = ratioValue(args.xRatio, NaN, 'xRatio')
    const yRatio = ratioValue(args.yRatio, NaN, 'yRatio')
    const previewPath = siblingPngPath(frame.rawPath || frame.path, `-preview-${randomUUID().slice(0, 8)}`)
    const preview = await this.run('annotate-visual-guide', {
      sourcePath: frame.rawPath || frame.path,
      path: previewPath,
      markXRatio: xRatio,
      markYRatio: yRatio,
    }, exec)
    return {
      ...preview,
      ok: true,
      frameId,
      xRatio,
      yRatio,
      previewPath: String(preview?.path || previewPath),
      rawScreenshotPath: frame.rawPath,
      frameBounds: frame.rect,
      coordinateGridUnits: 1000,
      physicalClickDispatched: false,
    }
  }

  async ocr(args = {}, exec) {
    const shot = await this.screenshot(args, exec)
    const image = await readFile(shot.path)
    const systemOcr = await import('@napi-rs/system-ocr')
    const recognize = systemOcr.recognize ?? systemOcr.default?.recognize
    const OcrAccuracy = systemOcr.OcrAccuracy ?? systemOcr.default?.OcrAccuracy
    if (typeof recognize !== 'function' || !OcrAccuracy) {
      return {
        ok: true,
        status: 'unavailable',
        text: '',
        lines: [],
        screenshotPath: shot.path,
        screenshotBounds: screenshotBounds(shot),
      }
    }

    const locale = Intl.DateTimeFormat().resolvedOptions().locale || 'zh-CN'
    const requested = Array.isArray(args.languages)
      ? args.languages.map(value => String(value ?? '').trim()).filter(Boolean)
      : []
    const languages = [...new Set([...requested, locale, 'zh-CN', 'en-US'])].slice(0, 4)
    const observations = []
    const failures = []
    for (const language of languages) {
      try {
        // system-ocr on Windows only consumes the first preferred language,
        // so run bounded passes and merge the line geometry. This matters for
        // Chinese apps such as WeChat on machines whose Node locale is en-US.
        const result = await recognize(image, OcrAccuracy.Accurate, [language], exec?.signal)
        observations.push({ language, result })
      } catch (error) {
        failures.push({ language, error: String(error?.message ?? error) })
      }
    }

    const lines = normalizeOcrObservations(observations, shot)
    const lineText = lines.map(line => line.text).join('\n')
    const fallbackText = observations.map(item => item?.result?.text ?? '').join('\n')
    const text = normalizeOcr(lineText || fallbackText)
    return {
      ok: true,
      status: text ? 'recognized' : observations.length > 0 ? 'empty' : 'unavailable',
      text,
      lines,
      languagesTried: languages,
      languagesSucceeded: observations.map(item => item.language),
      ...(failures.length === 0 ? {} : { languageErrors: failures }),
      screenshotPath: shot.path,
      screenshotBounds: screenshotBounds(shot),
      scope: shot.scope ?? args.scope ?? 'active-window',
      ...(shot.captureMethod === undefined ? {} : { captureMethod: shot.captureMethod }),
      ...(shot.window === undefined ? {} : { window: shot.window }),
      x: shot.x,
      y: shot.y,
      width: shot.width,
      height: shot.height,
    }
  }

  async clickOcrText(args = {}, exec) {
    const text = String(args.text ?? '').trim()
    if (!text) throw new Error('desktop_click_ocr_text requires text')
    const match = args.match === 'contains' ? 'contains' : 'exact'
    const caseSensitive = args.caseSensitive === true
    const windowArgs = Object.fromEntries(
      ['processName', 'title', 'titleContains']
        .filter(key => typeof args[key] === 'string' && args[key].trim() !== '')
        .map(key => [key, args[key]]),
    )
    if (Number.isInteger(args.processId)) windowArgs.processId = args.processId
    if (Number.isInteger(args.hwnd)) windowArgs.hwnd = args.hwnd
    if (Object.keys(windowArgs).length > 0) {
      await this.run('activate-window', windowArgs, exec)
    }
    const ocr = await this.ocr(args, exec)
    const textMatches = findOcrTextMatches(ocr.lines, { text, match, caseSensitive })
    const candidates = filterOcrMatchesByRegion(textMatches, ocr.screenshotBounds, args)

    let target
    if (args.index !== undefined) {
      const index = Number(args.index)
      if (!Number.isInteger(index) || index < 0 || index >= candidates.length) {
        throw new Error(`desktop OCR target index ${args.index} is out of range; matches=${candidates.length}`)
      }
      target = candidates[index]
    } else {
      if (candidates.length === 0) {
        throw new Error(`desktop OCR text target not found: ${JSON.stringify(text)}`)
      }
      if (candidates.length !== 1) {
        const sample = candidates.slice(0, 8).map(item => `${item.text}@(${item.center.x},${item.center.y})`).join(' | ')
        throw new Error(`desktop OCR text target is ambiguous (${candidates.length} matches): ${sample}`)
      }
      target = candidates[0]
    }

    await this.run('click-coordinates', {
      x: target.center.x,
      y: target.center.y,
      button: args.button === 'right' ? 'right' : 'left',
    }, exec)
    return {
      ok: true,
      method: 'ocr-line-center',
      match,
      query: text,
      matchCount: candidates.length,
      target,
      screenshotPath: ocr.screenshotPath,
      screenshotBounds: ocr.screenshotBounds,
      languagesTried: ocr.languagesTried,
    }
  }

  async waitForTarget(args = {}, exec) {
    const source = args.source === 'uia' || args.source === 'ocr' ? args.source : 'auto'
    const timeoutMs = boundedInteger(args.timeoutMs, 10000, 100, 120000)
    const pollMs = boundedInteger(args.pollMs, 300, 100, 5000)
    const requireUnique = args.requireUnique !== false
    const text = String(args.text ?? '').trim()
    const hasUiaSelector = ['name', 'automationId', 'controlType', 'className', 'value']
      .some(key => typeof args[key] === 'string' && args[key].trim() !== '')
    if (!hasUiaSelector && !text) {
      throw new Error('desktop_wait_for_target requires text or a UI Automation selector')
    }
    if (source === 'ocr' && !text) {
      throw new Error('desktop_wait_for_target source=ocr requires text')
    }

    const windowArgs = Object.fromEntries(
      ['processName', 'title', 'titleContains']
        .filter(key => typeof args[key] === 'string' && args[key].trim() !== '')
        .map(key => [key, args[key]]),
    )
    if (Number.isInteger(args.processId)) windowArgs.processId = args.processId
    if (Number.isInteger(args.hwnd)) windowArgs.hwnd = args.hwnd
    const startedAt = Date.now()
    const waitCaptureName = typeof args.fileName === 'string' && args.fileName.trim() !== ''
      ? args.fileName
      : `desktop-wait-${randomUUID().slice(0, 8)}`
    let attempts = 0
    let lastUiaCount = 0
    let lastOcrCount = 0
    let lastError = ''

    while (true) {
      attempts += 1

      if (Object.keys(windowArgs).length > 0) {
        try {
          await this.run('activate-window', windowArgs, exec)
        } catch (error) {
          lastError = `window activation: ${String(error?.message ?? error)}`
        }
      }

      if (source !== 'ocr') {
        try {
          const snapshot = await this.run('snapshot', {
            ...windowArgs,
            maxElements: boundedInteger(args.maxElements, 500, 1, 1000),
            includeOffscreen: false,
          }, exec)
          const uiArgs = {
            ...args,
            ...(typeof args.name === 'string' && args.name.trim() !== '' ? {} : text ? { name: text } : {}),
          }
          const matches = findUiaTargetMatches(snapshot.elements, uiArgs)
          lastUiaCount = matches.length
          if (matches.length > 0 && (!requireUnique || matches.length === 1)) {
            return {
              ok: true,
              method: 'uia',
              attempts,
              elapsedMs: Date.now() - startedAt,
              matchCount: matches.length,
              target: matches[0],
              window: snapshot.window,
            }
          }
        } catch (error) {
          lastError = `UIA: ${String(error?.message ?? error)}`
        }
      }

      if (source !== 'uia' && text) {
        try {
          const ocr = await this.ocr({ ...args, fileName: waitCaptureName }, exec)
          const textMatches = findOcrTextMatches(ocr.lines, {
            text,
            match: args.match,
            caseSensitive: args.caseSensitive,
          })
          const matches = filterOcrMatchesByRegion(textMatches, ocr.screenshotBounds, args)
          lastOcrCount = matches.length
          if (matches.length > 0 && (!requireUnique || matches.length === 1)) {
            return {
              ok: true,
              method: 'ocr',
              attempts,
              elapsedMs: Date.now() - startedAt,
              matchCount: matches.length,
              target: matches[0],
              screenshotPath: ocr.screenshotPath,
              screenshotBounds: ocr.screenshotBounds,
              ...(ocr.scope === undefined ? {} : { scope: ocr.scope }),
              ...(ocr.captureMethod === undefined ? {} : { captureMethod: ocr.captureMethod }),
              ...(ocr.window === undefined ? {} : { window: ocr.window }),
              ...(ocrRegionDescriptor(args) === undefined ? {} : { region: ocrRegionDescriptor(args) }),
              languagesTried: ocr.languagesTried,
            }
          }
        } catch (error) {
          lastError = `OCR: ${String(error?.message ?? error)}`
        }
      }

      const elapsedMs = Date.now() - startedAt
      if (elapsedMs >= timeoutMs) {
        const uniqueness = requireUnique ? 'exactly one matching target' : 'at least one matching target'
        const evidence = [
          source === 'ocr' ? '' : `uiaMatches=${lastUiaCount}`,
          source === 'uia' ? '' : `ocrMatches=${lastOcrCount}`,
          lastError,
        ].filter(Boolean).join('; ')
        throw new Error(`desktop_wait_for_target timed out after ${elapsedMs}ms waiting for ${uniqueness}; ${evidence || 'no matching CURRENT evidence'}`)
      }
      await waitWithSignal(Math.min(pollMs, timeoutMs - elapsedMs), exec?.signal)
    }
  }

  async listGuides(exec) {
    const roots = guideRoots(exec)
    const names = new Set()
    const sources = []
    for (const root of roots) {
      try {
        const entries = await readdir(root, { withFileTypes: true })
        for (const entry of entries) {
          if (!entry.isFile() || !entry.name.toLowerCase().endsWith('.md')) continue
          names.add(entry.name.slice(0, -3))
        }
        sources.push(root)
      } catch (error) {
        if (error?.code !== 'ENOENT') this.logger?.warn?.(`[dsh-patrol/desktop] guide scan failed for ${root}: ${error?.message ?? error}`)
      }
    }
    return { ok: true, guides: [...names].sort((a, b) => a.localeCompare(b, 'zh-CN')), sources }
  }

  async readGuide(app, exec) {
    const safe = safeGuideName(app)
    const roots = guideRoots(exec)
    for (const root of roots) {
      const path = join(root, `${safe}.md`)
      try {
        const content = await readFile(path, 'utf8')
        return {
          ok: true,
          app: safe,
          path,
          source: root === BUNDLED_GUIDES ? 'bundled' : 'workspace',
          content: content.length <= MAX_GUIDE_CHARS ? content : `${content.slice(0, MAX_GUIDE_CHARS)}\n…[truncated]`,
        }
      } catch (error) {
        if (error?.code !== 'ENOENT') throw error
      }
    }
    const available = await this.listGuides(exec)
    throw new Error(`desktop app guide ${JSON.stringify(safe)} not found; available=[${available.guides.join(', ')}]`)
  }

  async nextScreenshotPath(exec, requestedName) {
    const workspace = exec?.agent?.session?.header?.cwd
    const root = workspace
      ? join(resolve(workspace), 'patrol-results', 'desktop-captures')
      : join(tmpdir(), 'dsh-patrol-desktop')
    await mkdir(root, { recursive: true })
    const stem = safeFileStem(requestedName || `desktop-${new Date().toISOString().replace(/[:.]/g, '-')}-${randomUUID().slice(0, 6)}`)
    return join(root, `${stem}.png`)
  }
}

function guideRoots(exec) {
  const workspace = exec?.agent?.session?.header?.cwd
  return [
    ...(workspace ? [
      join(resolve(workspace), 'patrol-desktop-knowledge'),
      join(resolve(workspace), '.dsh-patrol', 'desktop-knowledge'),
    ] : []),
    BUNDLED_GUIDES,
  ]
}

function safeGuideName(value) {
  const name = String(value ?? '').trim().replace(/\.md$/i, '')
  if (!name || /[\\/:*?"<>|\u0000-\u001f]/.test(name) || name.includes('..')) {
    throw new Error('app guide name must be a simple file stem, for example 微信 or WPS')
  }
  return name
}

function safeFileStem(value) {
  const stem = basename(String(value ?? '').replace(/\.png$/i, ''))
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, '-')
    .replace(/[. ]+$/g, '')
    .trim()
    .slice(0, 96)
  return stem || 'desktop'
}

function parseLastJson(stdout) {
  const lines = String(stdout ?? '').split(/\r?\n/).map(line => line.trim()).filter(Boolean)
  for (let index = lines.length - 1; index >= 0; index -= 1) {
    try {
      const value = JSON.parse(lines[index])
      if (value && typeof value === 'object') return value
    } catch {}
  }
  return undefined
}

function cleanPowerShellError(error, stderr) {
  const message = String(error?.message ?? error ?? 'desktop PowerShell action failed')
  const details = String(stderr ?? '').trim()
  return details ? `${message}: ${details.slice(0, 1000)}` : message
}

export function normalizeOcrObservations(observations, shot, maxLines = 240) {
  const out = []
  const width = finiteNumber(shot?.width, 0)
  const height = finiteNumber(shot?.height, 0)
  const originX = finiteNumber(shot?.x, 0)
  const originY = finiteNumber(shot?.y, 0)
  if (width <= 0 || height <= 0) return out

  for (const observation of observations ?? []) {
    const language = String(observation?.language ?? '')
    const lines = Array.isArray(observation?.result?.lines) ? observation.result.lines : []
    for (const raw of lines) {
      const text = normalizeOcrLine(raw?.text)
      const box = raw?.boundingBox
      if (!text || !validNormalizedBox(box)) continue
      const x = Math.round(originX + box.x * width)
      const y = Math.round(originY + box.y * height)
      const lineWidth = Math.max(1, Math.round(box.width * width))
      const lineHeight = Math.max(1, Math.round(box.height * height))
      const center = {
        x: Math.round(x + lineWidth / 2),
        y: Math.round(y + lineHeight / 2),
      }
      if (out.some(existing =>
        ocrMatchKey(existing.text) === ocrMatchKey(text)
        && Math.abs(existing.center.x - center.x) <= 8
        && Math.abs(existing.center.y - center.y) <= 8)) {
        continue
      }
      out.push({
        text,
        confidence: finiteNumber(raw?.confidence, 0),
        language,
        rect: { x, y, width: lineWidth, height: lineHeight },
        center,
      })
      if (out.length >= maxLines) return out
    }
  }
  return out
}

export function findUiaTargetMatches(elements, args = {}) {
  const rows = Array.isArray(elements) ? elements : []
  const match = args.match === 'contains' ? 'contains' : 'exact'
  const caseSensitive = args.caseSensitive === true
  const requestedName = String(args.name ?? '').trim()
  const requestedAutomationId = String(args.automationId ?? '').trim()
  const requestedControlType = String(args.controlType ?? '').trim()
  const requestedClassName = String(args.className ?? '').trim()
  const requestedValue = String(args.value ?? '').trim()
  const normalize = value => caseSensitive ? String(value ?? '') : String(value ?? '').toLocaleLowerCase()
  const compare = (actual, expected, mode = 'exact') => {
    if (!expected) return true
    const left = normalize(actual)
    const right = normalize(expected)
    return mode === 'contains' ? left.includes(right) : left === right
  }
  return rows.filter(row =>
    compare(row?.name, requestedName, match)
    && compare(row?.automationId, requestedAutomationId)
    && compare(row?.controlType, requestedControlType)
    && compare(row?.className, requestedClassName)
    && compare(row?.value, requestedValue, match))
}

export function filterOcrMatchesByRegion(lines, bounds, args = {}) {
  const rows = Array.isArray(lines) ? lines : []
  const region = ocrRegionDescriptor(args)
  if (region === undefined) return rows
  const originX = finiteNumber(bounds?.x, 0)
  const originY = finiteNumber(bounds?.y, 0)
  const width = finiteNumber(bounds?.width, 0)
  const height = finiteNumber(bounds?.height, 0)
  if (width <= 0 || height <= 0) throw new Error('OCR region filtering requires valid CURRENT screenshot bounds')
  return rows.filter(line => {
    const x = finiteNumber(line?.center?.x, Number.NaN)
    const y = finiteNumber(line?.center?.y, Number.NaN)
    if (!Number.isFinite(x) || !Number.isFinite(y)) return false
    const rx = (x - originX) / width
    const ry = (y - originY) / height
    return rx >= region.minXRatio && rx <= region.maxXRatio
      && ry >= region.minYRatio && ry <= region.maxYRatio
  })
}

export function ocrRegionDescriptor(args = {}) {
  const keys = ['minXRatio', 'maxXRatio', 'minYRatio', 'maxYRatio']
  if (!keys.some(key => args[key] !== undefined)) return undefined
  const region = {
    minXRatio: ratioValue(args.minXRatio, 0, 'minXRatio'),
    maxXRatio: ratioValue(args.maxXRatio, 1, 'maxXRatio'),
    minYRatio: ratioValue(args.minYRatio, 0, 'minYRatio'),
    maxYRatio: ratioValue(args.maxYRatio, 1, 'maxYRatio'),
  }
  if (region.minXRatio > region.maxXRatio || region.minYRatio > region.maxYRatio) {
    throw new Error('OCR region minimum ratios must not exceed maximum ratios')
  }
  return region
}

function normalizeDesktopVisualCandidates(value) {
  if (!Array.isArray(value)) return []
  return value.flatMap((item, index) => {
    if (!item || typeof item !== 'object' || Array.isArray(item)) return []
    const row = item
    const candidateId = String(row.CandidateId ?? row.candidateId ?? `D${index + 1}`).trim().toUpperCase()
    const leftRatio = finiteNumber(row.LeftRatio ?? row.leftRatio, NaN)
    const topRatio = finiteNumber(row.TopRatio ?? row.topRatio, NaN)
    const widthRatio = finiteNumber(row.WidthRatio ?? row.widthRatio, NaN)
    const heightRatio = finiteNumber(row.HeightRatio ?? row.heightRatio, NaN)
    const centerXRatio = finiteNumber(row.CenterXRatio ?? row.centerXRatio, NaN)
    const centerYRatio = finiteNumber(row.CenterYRatio ?? row.centerYRatio, NaN)
    if (![leftRatio, topRatio, widthRatio, heightRatio, centerXRatio, centerYRatio].every(Number.isFinite)) return []
    return [{
      candidateId,
      leftRatio,
      topRatio,
      widthRatio,
      heightRatio,
      centerXRatio,
      centerYRatio,
      score: finiteNumber(row.Score ?? row.score, 0),
    }]
  })
}

function ratioValue(value, fallback, name) {
  if (value === undefined) return fallback
  const number = Number(value)
  if (!Number.isFinite(number) || number < 0 || number > 1) {
    throw new Error(`OCR region ${name} must be a finite number between 0 and 1`)
  }
  return number
}

export function findOcrTextMatches(lines, args = {}) {
  const rows = Array.isArray(lines) ? lines : []
  const text = String(args.text ?? '').trim()
  if (!text) return []
  const match = args.match === 'contains' ? 'contains' : 'exact'
  const caseSensitive = args.caseSensitive === true
  const needle = ocrMatchVariants(text, caseSensitive)
  return rows.filter(line => {
    const haystack = ocrMatchVariants(line?.text, caseSensitive)
    if (match === 'contains') {
      return haystack.spaced.includes(needle.spaced) || haystack.compact.includes(needle.compact)
    }
    return haystack.spaced === needle.spaced || haystack.compact === needle.compact
  })
}

function ocrMatchVariants(value, caseSensitive = false) {
  const nfkc = String(value ?? '').normalize('NFKC').replace(/\u00a0/g, ' ')
  const spaced = nfkc.replace(/\s+/g, ' ').trim()
  const cased = caseSensitive ? spaced : spaced.toLocaleLowerCase()
  return { spaced: cased, compact: cased.replace(/\s+/g, '') }
}

function ocrMatchKey(value) {
  return ocrMatchVariants(value, false).compact
}

function boundedInteger(value, fallback, min, max) {
  const numeric = Number(value)
  if (!Number.isInteger(numeric)) return fallback
  return Math.min(max, Math.max(min, numeric))
}

async function assertReadableGeneratedImage(path, label, signal) {
  const target = String(path ?? '').trim()
  if (!target) throw new Error(`${label} image path is empty`)
  let lastError
  for (const delay of [0, 30, 90]) {
    if (delay > 0) await waitWithSignal(delay, signal)
    try {
      const bytes = await readFile(target)
      if (bytes.length > 0) return target
      lastError = new Error('file is empty')
    } catch (error) {
      lastError = error
    }
  }
  throw new Error(`${label} image is not readable after generation: ${target}: ${errorMessage(lastError)}`)
}

async function waitWithSignal(milliseconds, signal) {
  if (milliseconds <= 0) return
  if (signal?.aborted) throw signal.reason ?? new Error('desktop wait aborted')
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      cleanup()
      resolve()
    }, milliseconds)
    const onAbort = () => {
      cleanup()
      reject(signal.reason ?? new Error('desktop wait aborted'))
    }
    const cleanup = () => {
      clearTimeout(timer)
      signal?.removeEventListener?.('abort', onAbort)
    }
    signal?.addEventListener?.('abort', onAbort, { once: true })
  })
}

function errorMessage(error) {
  return error instanceof Error ? error.message : String(error)
}

function siblingJpegPath(path, suffix) {
  const file = basename(String(path || 'screenshot.png'))
  const stem = file.replace(/\.(?:png|jpe?g)$/i, '')
  return join(dirname(String(path || '.')), `${stem}${suffix}.jpg`)
}

function siblingPngPath(path, suffix) {
  const file = basename(String(path || 'screenshot.png'))
  const stem = file.replace(/\.png$/i, '')
  return join(dirname(String(path || '.')), `${stem}${suffix}.png`)
}

function screenshotBounds(shot) {
  return {
    x: finiteNumber(shot?.x, 0),
    y: finiteNumber(shot?.y, 0),
    width: finiteNumber(shot?.width, 0),
    height: finiteNumber(shot?.height, 0),
  }
}

function sameRect(left, right, tolerance = 0) {
  return ['x', 'y', 'width', 'height'].every(key =>
    Number.isFinite(left?.[key])
    && Number.isFinite(right?.[key])
    && Math.abs(Number(left[key]) - Number(right[key])) <= tolerance)
}

function formatRect(rect) {
  return `(${rect?.x},${rect?.y}) ${rect?.width}x${rect?.height}`
}

function assertVisualFrameTarget(frame, args) {
  const processName = String(args.processName ?? '').trim()
  const title = String(args.title ?? '').trim()
  const titleContains = String(args.titleContains ?? '').trim()
  if (processName && frame.processName.toLocaleLowerCase() !== processName.toLocaleLowerCase()) {
    throw new Error(`latest visual frame belongs to process ${JSON.stringify(frame.processName)}, not ${JSON.stringify(processName)}; take a new desktop_screenshot`)
  }
  if (title && frame.title.toLocaleLowerCase() !== title.toLocaleLowerCase()) {
    throw new Error(`latest visual frame belongs to title ${JSON.stringify(frame.title)}, not ${JSON.stringify(title)}; take a new desktop_screenshot`)
  }
  if (titleContains && !frame.title.toLocaleLowerCase().includes(titleContains.toLocaleLowerCase())) {
    throw new Error(`latest visual frame title ${JSON.stringify(frame.title)} does not contain ${JSON.stringify(titleContains)}; take a new desktop_screenshot`)
  }
}

function validNormalizedBox(box) {
  return box
    && Number.isFinite(box.x)
    && Number.isFinite(box.y)
    && Number.isFinite(box.width)
    && Number.isFinite(box.height)
    && box.width > 0
    && box.height > 0
}

function finiteNumber(value, fallback) {
  return Number.isFinite(value) ? Number(value) : fallback
}

function normalizeOcrLine(value) {
  return String(value ?? '').replace(/\u0000/g, ' ').replace(/[\t ]+/g, ' ').trim()
}

function normalizeOcr(value) {
  const seen = new Set()
  const lines = String(value ?? '')
    .replace(/\u0000/g, ' ')
    .split(/\r?\n/)
    .map(line => line.replace(/[\t ]+/g, ' ').trim())
    .filter(Boolean)
    .filter(line => {
      const key = line.toLocaleLowerCase()
      if (seen.has(key)) return false
      seen.add(key)
      return true
    })
  const text = lines.join('\n')
  return text.length <= MAX_OCR_CHARS ? text : `${text.slice(0, MAX_OCR_CHARS)}…`
}
