import type { Context } from '@deepseek-ai/cordis'
import { defineTool, type ToolRunContext } from '@deepseek-ai/dsh-tools'
import { forgetTransientSecret, rememberTransientSecret } from '../browser-bridge-runtime/transient-secret-store.js'
import { imageCodeConstraintError, inferImageCodeConstraint, renderImageCodeConstraint } from './captcha-constraints.js'
import { issueImageCodeVisualAuthorization } from '../browser-bridge-runtime/image-code-visual-authorization.js'
import { isPatrolTestMode } from './test-mode.js'
import { assertSafePersistentText } from './security.js'
import { PatrolRunner } from './runner.js'
import { stepExecutionNotes } from './step-notes.js'
import { assertPersistedTaskChecklist, PatrolStore } from './store.js'
import type { InspectionStep, ToolStep } from './types.js'

const TEXT_OUTPUT = {
  schema: { type: 'string' as const },
  render: (_args: unknown, value: string) => [{ type: 'text' as const, text: value }],
}

const IMAGE_CODE_SELECTOR_HINT = /(captcha|image[-_ ]?code|img[-_ ]?code|图形验证码|图片验证码|字符验证码|验证码图片|验证码|校验码|图形码)/i
const IMAGE_CODE_MIN_CONFIDENCE = 0.90
const MULTIPLE_IMAGE_CODE_CANDIDATES = /(?:\bor\b|或者|或|候选|candidate|[,，/、;；|]|\r?\n)/i
const VISUAL_SOLVER_NOTE = 'PATROL_DYNAMIC_IMAGE_CODE_SOLVER'

export const PATROL_TRANSIENT_INPUT_PROMPT = `敏感输入规则：
- 用户在当前对话里已经明确提供密码或其他敏感字段值时，直接使用 patrol_type_transient，不要因为没有 Harness credential reference 而停止，也不要要求用户额外运行 credential helper。
- patrol_type_transient 明文只在本次工具执行与浏览器输入瞬间存在，随后以 AES-256-GCM 认证加密保存到本机 Patrol secret vault；Runbook 只保存不透明引用。不要把明文密码写进 Runbook、报告、notes 或回复。
- 只有用户明确要求 Harness credential reference 时才使用 patrol_type_credential / patrol_credential_help。
- 普通图片字符验证码 image-code 是一次性页面状态，不得存入 secret vault，也不得作为固定 browser_type 值写进 Runbook。
- TEST MODE 图片字符验证码必须先调用 patrol_solve_current_image_code。该工具会在 Patrol 授权上下文中执行 browser_detect_auth_challenge，优先走现有本地 OCR（包括 Windows OCR）路径；禁止直接从 browser_capture_image_code_visual 开始。
- 当 patrol_solve_current_image_code 返回 autoFilled=true 时，验证码已经由本地 solver 填写，直接继续登录/提交，不要重复截图、重复 OCR 或再次填写同一张验证码。
- 只有 patrol_solve_current_image_code 明确返回 testModeFallback=true / strategy=model-visual-test 时，才允许 browser_capture_image_code_visual + patrol_type_current_image_code 作为模型视觉后备。Model Vision 是 fallback，不是第一路径。
- 用户在 taskChecklist 中声明的验证码格式是硬约束。例如“四位英文、没有数字”只允许恰好 4 个 ASCII 字母；即使视觉模型给出高置信度、但候选包含数字，也不得填写或提交，必须重新读取/刷新 CURRENT 验证码。
- 模型视觉后备高置信度填写成功后，Patrol 只记录一个不含验证码字符的动态 browser_detect_auth_challenge solver 步骤，供后续 replay 动态识别未来的新验证码；重复视觉尝试不会重复追加 solver 步骤。
- 密码、TOTP/OTP、token 等真正敏感值仍必须走专用敏感输入流程。`

export function registerPatrolTransientInputTools(
  ctx: Context,
  store: PatrolStore,
  runner: PatrolRunner,
): () => void {
  const typeTransient = defineTool({
    name: 'patrol_type_transient',
    description: 'Type a sensitive value already supplied by the user, persist only authenticated AES-256-GCM ciphertext, and record an opaque PATROL_SECRET reference so validation/runs can replay it across Harness restarts. The plaintext is never written to the Runbook, reports, or visible tool card.',
    parameters: {
      inspectionId: { type: 'string', required: true },
      stepName: { type: 'string', required: true },
      selector: { type: 'string', required: true },
      text: { type: 'string', required: true },
      clear: { type: 'boolean' },
      notes: { type: 'string' },
    },
    output: TEXT_OUTPUT,
    presentCall: args => ({
      card: 'generic',
      title: 'Type encrypted sensitive text',
      kind: 'other',
      rawInput: {
        inspectionId: args.inspectionId,
        stepName: args.stepName,
        selector: args.selector,
        clear: args.clear,
        text: '[REDACTED]',
      },
    }),
    async execute(args, exec: ToolRunContext) {
      assertSafePersistentText(args.stepName, 'stepName')
      if (args.notes !== undefined) assertSafePersistentText(args.notes, 'step notes')
      if (typeof args.text !== 'string' || args.text.length === 0) throw new Error('sensitive text must not be empty')
      const definition = await store.load(args.inspectionId)
      if (definition.status !== 'draft') throw new Error(`inspection ${definition.id} is ${definition.status}; call patrol_begin_edit before teaching sensitive input`)
      assertPersistedTaskChecklist(definition)

      const transientRef = rememberTransientSecret(args.text)
      const dispatched = await runner.dispatch('browser_type', {
        selector: args.selector,
        text: args.text,
        clear: args.clear ?? true,
      }, exec, [args.text])
      if (!dispatched.ok) {
        forgetTransientSecret(transientRef)
        return `Sensitive input failed and its encrypted vault entry was removed. ${dispatched.error ?? dispatched.text}`
      }

      const step: ToolStep = {
        id: nextStepId(definition.steps),
        kind: 'tool',
        name: args.stepName,
        tool: 'browser_type_transient_ref',
        arguments: { selector: args.selector, transientRef, clear: args.clear ?? true },
        sensitive: true,
        notes: stepExecutionNotes({
          tool: 'browser_type_transient_ref',
          args: { selector: args.selector, transientRef, clear: args.clear ?? true },
          providedNotes: args.notes,
        }),
        recordedAt: new Date().toISOString(),
      }
      definition.steps.push(step)
      definition.schemaVersion = '0.2'
      definition.metadata.updatedAt = new Date().toISOString()
      await store.save(definition)

      return [
        `Typed sensitive text and recorded ${step.id} as an encrypted Patrol secret reference.`,
        'The plaintext value was NOT written to the Patrol Runbook, workspace reports, or tool card.',
        'The encrypted reference can be replayed by patrol_validate/patrol_run after Harness restarts on this machine.',
      ].join('\n')
    },
  })

  const solveCurrentImageCode = defineTool({
    name: 'patrol_solve_current_image_code',
    description: 'TEST MODE image-code solver entrypoint. It always runs the existing local OCR detector first (including the Windows OCR path) through browser_detect_auth_challenge. Model vision is allowed only when that detector explicitly returns testModeFallback=true / strategy=model-visual-test.',
    parameters: {
      inspectionId: { type: 'string', required: true },
      stepName: { type: 'string' },
      tabId: { type: 'integer' },
    },
    output: TEXT_OUTPUT,
    async execute(args, exec: ToolRunContext) {
      if (!isPatrolTestMode()) {
        throw new Error('patrol_solve_current_image_code is available only in DSH Patrol TEST MODE; normal mode uses the replay detector/solver')
      }
      const definition = await store.load(args.inspectionId)
      if (definition.status !== 'draft') throw new Error(`inspection ${definition.id} is ${definition.status}; call patrol_begin_edit before teaching image-code handling`)
      assertPersistedTaskChecklist(definition)
      if (args.stepName !== undefined) assertSafePersistentText(args.stepName, 'stepName')

      const dispatched = await runner.dispatch(
        'browser_detect_auth_challenge',
        args.tabId === undefined ? {} : { tabId: args.tabId },
        exec,
      )
      if (!dispatched.ok) {
        return [
          `TEST MODE local OCR attempt failed and was NOT converted into a model-vision guess. ${dispatched.error ?? 'Unknown browser error'}`,
          dispatched.text,
          'Fix/retry the CURRENT browser state. Model vision is allowed only after an explicit detector fallback result, not after a transport/tool error.',
        ].filter(Boolean).join('\n')
      }

      const detector = dispatched.value as {
        autoFilled?: boolean
        testModeFallback?: boolean
        strategy?: string
      } | undefined
      const autoFilled = detector?.autoFilled === true
      const visualFallback = detector?.testModeFallback === true && detector?.strategy === 'model-visual-test'

      if (autoFilled) {
        let solverStep = definition.steps.find(step =>
          step.kind === 'tool'
          && step.tool === 'browser_detect_auth_challenge'
          && typeof step.notes === 'string'
          && step.notes.includes(VISUAL_SOLVER_NOTE),
        ) as ToolStep | undefined
        let recorded = false
        if (solverStep === undefined) {
          solverStep = {
            id: nextStepId(definition.steps),
            kind: 'tool',
            name: '动态识别并填写图片验证码',
            tool: 'browser_detect_auth_challenge',
            arguments: {},
            notes: stepExecutionNotes({
              tool: 'browser_detect_auth_challenge',
              args: {},
              providedNotes: `${VISUAL_SOLVER_NOTE}；TEST/NORMAL 优先使用本地 OCR（包括 Windows OCR）动态识别未来的新验证码；TEST MODE 仅在明确 fallback 时才允许 CURRENT 模型视觉；不保存一次性验证码字符。`,
            }),
            recordedAt: new Date().toISOString(),
          }
          definition.steps.push(solverStep)
          definition.schemaVersion = '0.2'
          definition.metadata.updatedAt = new Date().toISOString()
          await store.save(definition)
          recorded = true
        }

        return [
          dispatched.text,
          'TEST MODE: local OCR auto-filled the CURRENT image-code. Continue with the login/submit step; do NOT capture or recognize the same CAPTCHA again.',
          recorded
            ? `Recorded ${solverStep.id} as the single dynamic image-code solver step for future replay.`
            : `Reused existing dynamic image-code solver step ${solverStep.id}; no duplicate solver step was appended.`,
        ].filter(Boolean).join('\n')
      }

      if (visualFallback) {
        const fallbackToken = issueImageCodeVisualAuthorization()
        return [
          dispatched.text,
          'TEST MODE: local OCR did not safely auto-fill the CURRENT image-code and explicitly authorized one model-vision fallback capture.',
          `Now call browser_capture_image_code_visual with fallbackToken=${fallbackToken} on the CURRENT page, then patrol_type_current_image_code only when confidence >= 0.90 and the persisted taskChecklist format is satisfied.`,
          'The fallbackToken is one-use and expires quickly; without this exact authorization the visual CAPTCHA tool will refuse to run.',
        ].filter(Boolean).join('\n')
      }

      return [
        dispatched.text,
        'No model-vision fallback was authorized. Do not call browser_capture_image_code_visual unless the detector explicitly returns testModeFallback=true / strategy=model-visual-test.',
      ].filter(Boolean).join('\n')
    },
  })

  const typeCurrentImageCode = defineTool({
    name: 'patrol_type_current_image_code',
    description: 'TEST MODE model-vision fallback input: type the CURRENT conventional image-text CAPTCHA without persisting its one-time characters. Use only after patrol_solve_current_image_code explicitly authorizes model-visual-test fallback. Requires confidence >= 0.90 and also enforces the persisted taskChecklist CAPTCHA length/character-set contract.',
    parameters: {
      inspectionId: { type: 'string', required: true },
      selector: { type: 'string', required: true },
      text: { type: 'string', required: true },
      confidence: { type: 'number', required: true },
      source: { type: 'string', enum: ['model-visual', 'ddddocr', 'consensus', 'manual-debug'] },
      clear: { type: 'boolean' },
    },
    output: TEXT_OUTPUT,
    presentCall: args => ({
      card: 'generic',
      title: 'Type current CAPTCHA',
      kind: 'other',
      rawInput: {
        inspectionId: args.inspectionId,
        selector: args.selector,
        confidence: args.confidence,
        source: args.source,
        clear: args.clear,
        text: '[CURRENT CAPTCHA]',
      },
    }),
    async execute(args, exec: ToolRunContext) {
      if (!isPatrolTestMode()) throw new Error('patrol_type_current_image_code is available only in DSH Patrol TEST MODE')
      if (!IMAGE_CODE_SELECTOR_HINT.test(String(args.selector || ''))) {
        throw new Error('patrol_type_current_image_code requires an explicit image-code/CAPTCHA input selector')
      }
      const confidence = Number(args.confidence)
      if (!Number.isFinite(confidence) || confidence < 0 || confidence > 1) {
        throw new Error('image-code confidence must be a finite number from 0 to 1')
      }
      if (confidence < IMAGE_CODE_MIN_CONFIDENCE) {
        return `CURRENT CAPTCHA was NOT typed because confidence=${confidence.toFixed(3)} is below ${IMAGE_CODE_MIN_CONFIDENCE.toFixed(2)}. Refresh the CAPTCHA and capture the fresh visual before any login submission.`
      }

      const rawCode = String(args.text || '').trim()
      if (MULTIPLE_IMAGE_CODE_CANDIDATES.test(rawCode)) {
        throw new Error('current image-code must be one single candidate; refresh the CAPTCHA when recognition produces multiple possible answers')
      }
      const code = rawCode.replace(/\s+/g, '')
      if (!/^[A-Za-z0-9]{2,16}$/.test(code)) {
        throw new Error('current image-code must contain 2-16 ASCII letters/digits after whitespace removal')
      }

      const definition = await store.load(args.inspectionId)
      if (definition.status !== 'draft') throw new Error(`inspection ${definition.id} is ${definition.status}; call patrol_begin_edit before teaching image-code handling`)
      assertPersistedTaskChecklist(definition)
      const constraint = inferImageCodeConstraint(definition.metadata.taskChecklist ?? [])
      const constraintError = imageCodeConstraintError(code, constraint)
      if (constraintError !== undefined) {
        return [
          `CURRENT CAPTCHA was NOT typed because it violates the persisted task contract: ${constraintError}.`,
          renderImageCodeConstraint(constraint),
          'Re-read or refresh the CURRENT CAPTCHA under the declared format before any login submission.',
        ].filter(Boolean).join(' ')
      }

      const dispatched = await runner.dispatch('browser_type', {
        selector: args.selector,
        text: code,
        clear: args.clear ?? true,
      }, exec)
      if (!dispatched.ok) return `CURRENT CAPTCHA typing failed and nothing was recorded. ${dispatched.error ?? dispatched.text}`

      let solverStep = definition.steps.find(step =>
        step.kind === 'tool'
        && step.tool === 'browser_detect_auth_challenge'
        && typeof step.notes === 'string'
        && step.notes.includes(VISUAL_SOLVER_NOTE),
      ) as ToolStep | undefined
      let recorded = false
      if (solverStep === undefined) {
        solverStep = {
          id: nextStepId(definition.steps),
          kind: 'tool',
          name: '动态识别并填写图片验证码',
          tool: 'browser_detect_auth_challenge',
          arguments: {},
          notes: stepExecutionNotes({
            tool: 'browser_detect_auth_challenge',
            args: {},
            providedNotes: `${VISUAL_SOLVER_NOTE}；TEST/NORMAL 优先使用本地 OCR（包括 Windows OCR）动态识别未来的新验证码；TEST MODE 仅在明确 fallback 时才允许 CURRENT 模型视觉；不保存一次性验证码字符。`,
          }),
          recordedAt: new Date().toISOString(),
        }
        definition.steps.push(solverStep)
        definition.schemaVersion = '0.2'
        definition.metadata.updatedAt = new Date().toISOString()
        await store.save(definition)
        recorded = true
      }

      return [
        `TEST MODE fallback: typed the CURRENT image-code with confidence=${confidence.toFixed(3)}${args.source ? ` (${args.source})` : ''}.`,
        renderImageCodeConstraint(constraint),
        'Its one-time characters were NOT written to the Runbook, Patrol secret vault, notes, reports, or visible tool card.',
        recorded
          ? `Recorded ${solverStep.id} as the single dynamic image-code solver step for future replay.`
          : `Reused existing dynamic image-code solver step ${solverStep.id}; no duplicate solver step was appended.`,
      ].filter(Boolean).join('\n')
    },
  })

  const reteachTransient = defineTool({
    name: 'patrol_reteach_transient',
    description: 'Replace one existing encrypted sensitive-input step with a newly supplied value while preserving its stable step id. The previous encrypted vault entry is removed after the replacement is safely stored.',
    parameters: {
      inspectionId: { type: 'string', required: true },
      stepId: { type: 'string', required: true },
      selector: { type: 'string', required: true },
      text: { type: 'string', required: true },
      clear: { type: 'boolean' },
      stepName: { type: 'string' },
      notes: { type: 'string' },
    },
    output: TEXT_OUTPUT,
    presentCall: args => ({
      card: 'generic',
      title: 'Refresh encrypted sensitive step',
      kind: 'other',
      rawInput: {
        inspectionId: args.inspectionId,
        stepId: args.stepId,
        selector: args.selector,
        clear: args.clear,
        stepName: args.stepName,
        text: '[REDACTED]',
      },
    }),
    async execute(args, exec: ToolRunContext) {
      if (args.stepName !== undefined) assertSafePersistentText(args.stepName, 'stepName')
      if (args.notes !== undefined) assertSafePersistentText(args.notes, 'step notes')
      if (typeof args.text !== 'string' || args.text.length === 0) throw new Error('sensitive text must not be empty')
      const definition = await store.load(args.inspectionId)
      if (definition.status !== 'draft') throw new Error(`inspection ${definition.id} is ${definition.status}; call patrol_begin_edit before re-teaching`)
      const index = definition.steps.findIndex(step => step.id === args.stepId)
      const current = index >= 0 ? definition.steps[index] : undefined
      if (current === undefined || current.kind !== 'tool' || current.tool !== 'browser_type_transient_ref') {
        throw new Error(`${args.stepId} is not an encrypted sensitive input step`)
      }
      const oldRef = typeof current.arguments.transientRef === 'string' ? current.arguments.transientRef : undefined

      const transientRef = rememberTransientSecret(args.text)
      const dispatched = await runner.dispatch('browser_type', {
        selector: args.selector,
        text: args.text,
        clear: args.clear ?? true,
      }, exec, [args.text])
      if (!dispatched.ok) {
        forgetTransientSecret(transientRef)
        return `Sensitive re-teach failed and the stored step was NOT changed. ${dispatched.error ?? dispatched.text}`
      }

      const replacement: ToolStep = {
        id: current.id,
        kind: 'tool',
        name: args.stepName ?? current.name,
        tool: 'browser_type_transient_ref',
        arguments: { selector: args.selector, transientRef, clear: args.clear ?? true },
        sensitive: true,
        notes: stepExecutionNotes({
          tool: 'browser_type_transient_ref',
          args: { selector: args.selector, transientRef, clear: args.clear ?? true },
          providedNotes: args.notes ?? current.notes,
        }),
        recordedAt: new Date().toISOString(),
      }
      definition.steps[index] = replacement
      definition.metadata.updatedAt = new Date().toISOString()
      delete definition.metadata.validatedAt
      await store.save(definition)
      if (oldRef !== undefined && oldRef !== transientRef) forgetTransientSecret(oldRef)
      return `Re-taught ${current.id} with a persistent encrypted Patrol secret reference. No plaintext secret was persisted.`
    },
  })

  const disposers = [typeTransient, solveCurrentImageCode, typeCurrentImageCode, reteachTransient].map(tool => ctx.tools.register(tool))
  return () => { for (const dispose of disposers) dispose() }
}

function nextStepId(steps: readonly InspectionStep[]): string {
  let max = 0
  for (const step of steps) {
    const match = /^step-(\d+)$/.exec(step.id)
    if (match !== null) max = Math.max(max, Number.parseInt(match[1] ?? '0', 10))
  }
  return `step-${String(max + 1).padStart(3, '0')}`
}