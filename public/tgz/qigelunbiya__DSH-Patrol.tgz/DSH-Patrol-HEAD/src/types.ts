export type JsonPrimitive = string | number | boolean | null
export type JsonValue = JsonPrimitive | JsonValue[] | JsonObject
export interface JsonObject { [key: string]: JsonValue }

export type InspectionSchemaVersion = '0.1' | '0.2'
export type InspectionStatus = 'draft' | 'ready'
export type RunPurpose = 'patrol' | 'validation' | 'teaching'
export type AuthMode = 'none' | 'existing-session' | 'manual-checkpoint' | 'secret-ref'
export type ExpectationMode = 'contains' | 'not-contains'

export type ChallengeKind = 'otp' | 'captcha' | 'slider' | 'approval' | 'unknown'
export type ChallengeSubtype = 'otp' | 'image-code' | 'click-sequence' | 'third-party' | 'generic-captcha' | 'slider' | 'slider-puzzle' | 'rotate' | 'approval' | 'unknown'
export type ChallengeStrategy = 'windows-system-ocr' | 'ddddocr-click-sequence-demo' | 'ddddocr-slider-demo' | 'manual-click-sequence' | 'manual-slider' | 'manual-third-party' | 'manual-otp' | 'manual-approval' | 'manual-review'

export interface ChallengeProfile {
  kind: ChallengeKind
  subtype: ChallengeSubtype
  strategy: ChallengeStrategy
  firstObservedAt: string
  lastObservedAt: string
  occurrences: number
  autoCompletedOccurrences: number
}

export const INSPECTION_ARTIFACTS = ['markdown-report', 'json-report', 'screenshot', 'page-text', 'page-summary'] as const
export type InspectionArtifact = typeof INSPECTION_ARTIFACTS[number]

export interface TextExpectation {
  mode: ExpectationMode
  value: string
  caseSensitive: boolean
}

export interface StepCondition extends TextExpectation {
  sourceStepId: string
}

export interface SemanticLocator {
  text?: string
  role?: string
  tag?: string
}

export interface TeachingVerification {
  /**
   * verified means the teaching action reached an observable post-action state.
   * unverified means the browser mutation happened, but it must never be
   * finalized into a reusable READY flow.
   */
  status: 'verified' | 'unverified'
  method: 'expected-text' | 'state-change' | 'execution-only'
  evidence?: string
}

export type StepArtifactKind = 'page-text' | 'screenshot'

export interface ToolStep {
  id: string
  kind: 'tool'
  name: string
  tool: string
  arguments: JsonObject
  expectation?: TextExpectation
  when?: StepCondition
  locator?: SemanticLocator
  artifact?: StepArtifactKind | undefined
  sensitive?: boolean
  notes?: string
  /** Execution plane shown in the flow graph. Older flows may omit it and derive it from tool prefix. */
  executionPlane?: 'browser' | 'desktop'
  /** Human-readable CURRENT execution recipe, especially for desktop/application steps. */
  executionInstruction?: string
  /** Business-task instruction this reusable step is intended to satisfy. */
  taskHint?: string
  /** Teaching-only verification metadata. Finalized flows strip this field. */
  teaching?: TeachingVerification
  recordedAt: string
}

export interface CheckpointStep {
  id: string
  kind: 'checkpoint'
  name: string
  prompt: string
  reason: 'login' | 'otp' | 'approval' | 'other'
  when?: StepCondition
  notes?: string
  recordedAt: string
}

export type InspectionStep = ToolStep | CheckpointStep

export interface FlowHealth {
  complete: boolean
  warnings: string[]
  checkedAt: string
}

export type InspectionTarget =
  | {
      type: 'browser'
      url: string
    }
  | {
      type: 'desktop'
      app: string
      processName?: string
      titleContains?: string
    }

export interface InspectionDefinition {
  schemaVersion: InspectionSchemaVersion
  id: string
  name: string
  description: string
  status: InspectionStatus
  target: InspectionTarget
  expectedResult: string
  artifacts: InspectionArtifact[]
  auth: {
    mode: AuthMode
    notes?: string
    /** Non-secret learned verification taxonomy. No cookie, OTP, captcha answer, or raw challenge image is stored here. */
    challengeProfiles?: ChallengeProfile[]
  }
  schedule: null | {
    enabled: boolean
    cron?: string
  }
  steps: InspectionStep[]
  metadata: {
    createdAt: string
    updatedAt: string
    validatedAt?: string
    /** Last interactive Harness workspace used by this inspection. Scheduled runs use it for user-visible outputs. */
    workspaceRoot?: string
    /** Ordered business contract captured before teaching begins. */
    taskChecklist?: string[]
    /** Dashboard cleanup/finalization health result for user-visible diagnosis. */
    flowHealth?: FlowHealth
    /**
     * Append-only snapshot of successful live-teaching actions. Structural
     * Runbook edits do not write this trace. It exists so a later repair can
     * restore a successfully executed step that was accidentally omitted from
     * the visible Runbook without guessing selectors, coordinates, or step ids.
     */
    successfulTeachingTrace?: InspectionStep[]
  }
}

export type StepRunStatus = 'passed' | 'failed' | 'waiting' | 'skipped'

export interface RunArtifact {
  kind: StepArtifactKind
  path: string
}

export interface StepRunResult {
  stepId: string
  name: string
  kind: InspectionStep['kind']
  status: StepRunStatus
  startedAt: string
  finishedAt: string
  tool?: string
  output?: string
  error?: string
  artifacts?: RunArtifact[]
  healedSelector?: string
}

export interface RunReport {
  schemaVersion: '0.2'
  runId: string
  inspectionId: string
  inspectionName: string
  startedAt: string
  finishedAt: string
  status: 'passed' | 'failed' | 'waiting'
  /** Formal patrols are shown in Patrol Records; validation/teaching runs are internal edit diagnostics. */
  purpose?: RunPurpose
  expectedResult: string
  results: StepRunResult[]
  summary?: string
  /** Non-fatal evidence/quality issues. Business execution may still be passed. */
  warnings?: string[]
  /** Harness session workspace where user-visible reports/artifacts were exported. */
  outputWorkspace?: string
  /** Snapshot of the user-facing business checklist at run time for historical review. */
  taskChecklist?: string[]
}

export interface ResumeState {
  schemaVersion: '0.2'
  inspectionId: string
  runId: string
  startedAt: string
  definitionUpdatedAt: string
  purpose?: RunPurpose
  nextStepIndex: number
  results: StepRunResult[]
}

export interface SavedRunPaths {
  directory: string
  json: string
  markdown: string
}
