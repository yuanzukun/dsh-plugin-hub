import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { imageCodeConstraintError, inferImageCodeConstraint, renderImageCodeConstraint, type ImageCodeConstraint } from './captcha-constraints.js'
import { assertSafeForStorage, assertSafePersistentText } from './security.js'
import { PatrolStore } from './store.js'
import { INSPECTION_ARTIFACTS, type AuthMode, type InspectionArtifact, type InspectionDefinition, type RunReport } from './types.js'
import { assertInspectionId, normalizeInspectionId } from './validation.js'

const TEXT_OUTPUT = {
  schema: { type: 'string' as const },
  render: (_args: unknown, value: string) => [{ type: 'text' as const, text: value }],
}

type InteractivePatrolStore = PatrolStore & {
  beginTeachingRun?: (inspectionId: string, workspaceRoot?: string) => Promise<RunReport>
}

export function registerPatrolCreationTools(ctx: Context, store: PatrolStore): () => void {
  const captchaConstraints = new Map<string, ImageCodeConstraint>()
  const createInspection = defineTool({
    name: 'patrol_create_inspection',
    description: 'Create or reuse a browser or Windows-desktop Patrol DRAFT using only non-secret metadata. inspectionId may be human-friendly input; Patrol normalizes it to the supported ASCII id format before storage. targetType defaults to browser for backward compatibility. Triggering this tool for a DRAFT also starts an in-progress patrol history record immediately, before teaching is finished.',
    parameters: {
      inspectionId: { type: 'string', required: true, description: 'Stable short id. ASCII letters/digits/dot/underscore/hyphen are preserved; unsupported characters are normalized automatically.' },
      name: { type: 'string', required: true },
      description: { type: 'string', required: true },
      targetType: { type: 'string', enum: ['browser', 'desktop'], description: 'Defaults to browser. Use desktop for app-only Patrol flows such as WeChat.' },
      targetUrl: { type: 'string', description: 'Required when targetType=browser.' },
      desktopApp: { type: 'string', description: 'Required when targetType=desktop, for example 微信.' },
      desktopProcessName: { type: 'string', description: 'Optional stable process name hint, for example WeChat or Weixin.' },
      desktopTitleContains: { type: 'string', description: 'Optional stable window-title substring.' },
      expectedResult: { type: 'string', required: true },
      authMode: { type: 'string', required: true, enum: ['none', 'existing-session', 'manual-checkpoint', 'secret-ref'] },
      artifacts: { type: 'array', items: { type: 'string', enum: [...INSPECTION_ARTIFACTS] } },
    },
    output: TEXT_OUTPUT,
    async execute(args, exec) {
      const requestedInspectionId = String(args.inspectionId ?? '').trim()
      const inspectionId = normalizeInspectionId(requestedInspectionId)
      assertInspectionId(inspectionId)
      const normalizedNotice = requestedInspectionId === inspectionId
        ? ''
        : ` Requested inspectionId was normalized to ${inspectionId}; use this id for subsequent Patrol calls.`
      const workspaceRoot = exec?.agent?.session.header.cwd
      if (await store.exists(inspectionId)) {
        const existing = await store.load(inspectionId)
        if (existing.status === 'draft' && existing.steps.length === 0) {
          await beginInteractivePatrol(store, existing.id, workspaceRoot ?? existing.metadata.workspaceRoot)
          return `Inspection ${existing.id} already exists as an empty DRAFT.${normalizedNotice} Continue teaching it with patrol_* action tools; this interactive patrol has already been added to patrol history as an in-progress run.`
        }
        return `Inspection ${existing.id} already exists with status=${existing.status} and ${existing.steps.length} step(s).${normalizedNotice} Reuse it without appending: call patrol_run_flow to execute the existing flow, or call patrol_begin_edit only when the user explicitly wants to change a specific step. Do not continue recording browser actions at the end of this Runbook.`
      }

      assertSafePersistentText(args.name, 'inspection.name')
      assertSafePersistentText(args.description, 'inspection.description')
      assertSafePersistentText(args.expectedResult, 'inspection.expectedResult')
      const targetType = args.targetType === 'desktop' ? 'desktop' : 'browser'
      const target: InspectionDefinition['target'] = targetType === 'desktop'
        ? desktopTarget(args.desktopApp, args.desktopProcessName, args.desktopTitleContains)
        : browserTarget(args.targetUrl)

      const now = new Date().toISOString()
      const definition: InspectionDefinition = {
        schemaVersion: '0.2',
        id: inspectionId,
        name: args.name,
        description: args.description,
        status: 'draft',
        target,
        expectedResult: args.expectedResult,
        artifacts: (args.artifacts ?? ['markdown-report', 'json-report']) as InspectionArtifact[],
        auth: { mode: args.authMode as AuthMode },
        schedule: null,
        steps: [],
        metadata: {
          createdAt: now,
          updatedAt: now,
          ...(workspaceRoot === undefined ? {} : { workspaceRoot }),
        },
      }
      await store.create(definition)
      await beginInteractivePatrol(store, definition.id, workspaceRoot)
      return `Created DRAFT ${definition.id} with ${definition.target.type} target without persisting any auth notes or plaintext secret.${normalizedNotice} An in-progress patrol history record was created immediately. User-visible run outputs will default to the current Harness workspace${workspaceRoot === undefined ? '' : `: ${workspaceRoot}`}. Next run patrol_doctor, then teach with the flat patrol_* action tools${definition.target.type === 'desktop' ? ' (desktop_* for CURRENT exploration, patrol_desktop_action for reusable desktop steps)' : ''}.`
    },
  })

  const disposers: Array<() => void> = [ctx.tools.register(createInspection)]
  const tools = ctx.tools as unknown as { guard?: (callback: (execution: any) => string | undefined) => (() => void) }
  if (typeof tools.guard === 'function') {
    disposers.push(tools.guard(execution => {
      const name = String(execution?.name ?? '')
      const args = execution?.arguments
      if (args === null || typeof args !== 'object' || Array.isArray(args)) return undefined
      const rawInspectionId = typeof args.inspectionId === 'string' ? args.inspectionId.trim() : ''
      const inspectionId = rawInspectionId ? normalizeInspectionId(rawInspectionId) : ''
      if (!inspectionId) return undefined

      if (name === 'patrol_set_task_checklist' && Array.isArray(args.items)) {
        const items = args.items.filter((item: unknown): item is string => typeof item === 'string')
        captchaConstraints.set(inspectionId, inferImageCodeConstraint(items))
        return undefined
      }

      if (name !== 'patrol_type_current_image_code') return undefined
      const constraint = captchaConstraints.get(inspectionId)
      const code = typeof args.text === 'string' ? args.text.trim().replace(/\s+/g, '') : ''
      if (constraint === undefined || !code) return undefined
      const error = imageCodeConstraintError(code, constraint)
      if (error === undefined) return undefined
      return [
        `DSH Patrol CAPTCHA format guard: candidate was NOT typed (${error}).`,
        renderImageCodeConstraint(constraint),
        'The task checklist is authoritative. Re-read the current image-code under the declared length/character-set constraint before submitting it.',
      ].filter(Boolean).join(' ')
    }))
  }

  return () => { for (const dispose of disposers) dispose() }
}

function browserTarget(value: unknown): InspectionDefinition['target'] {
  if (typeof value !== 'string' || value.trim().length === 0) {
    throw new Error('targetUrl is required when targetType=browser')
  }
  assertSafeForStorage({ url: value })
  return { type: 'browser', url: value }
}

function desktopTarget(appValue: unknown, processValue: unknown, titleValue: unknown): InspectionDefinition['target'] {
  const app = typeof appValue === 'string' ? appValue.trim() : ''
  if (!app) throw new Error('desktopApp is required when targetType=desktop')
  assertSafePersistentText(app, 'inspection.target.app')
  const processName = typeof processValue === 'string' ? processValue.trim() : ''
  const titleContains = typeof titleValue === 'string' ? titleValue.trim() : ''
  if (processName) assertSafePersistentText(processName, 'inspection.target.processName')
  if (titleContains) assertSafePersistentText(titleContains, 'inspection.target.titleContains')
  return {
    type: 'desktop',
    app,
    ...(processName ? { processName } : {}),
    ...(titleContains ? { titleContains } : {}),
  }
}

async function beginInteractivePatrol(store: PatrolStore, inspectionId: string, workspaceRoot?: string): Promise<void> {
  const lifecycle = store as InteractivePatrolStore
  if (typeof lifecycle.beginTeachingRun !== 'function') return
  await lifecycle.beginTeachingRun(inspectionId, workspaceRoot)
}
