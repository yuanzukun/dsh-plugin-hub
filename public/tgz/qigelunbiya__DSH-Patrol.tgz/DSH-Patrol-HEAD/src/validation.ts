import { INSPECTION_ARTIFACTS, type InspectionDefinition, type InspectionStep, type JsonObject, type JsonValue, type StepCondition, type TextExpectation } from './types.js'
import { isReplayableBrowserTool } from './browser.js'
import { isReplayableDesktopTool } from './desktop.js'
import { assertSafeCheckpointPrompt, assertSafeForStorage, assertSafePersistentText, assertSafePublicInputText, collectCredentialReferences, credentialReferenceName } from './security.js'

const INSPECTION_ID = /^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$/
const STEP_ID = /^step-\d{3,}$/
const CHALLENGE_KINDS = ['otp', 'captcha', 'slider', 'approval', 'unknown'] as const
const CHALLENGE_SUBTYPES = ['otp', 'image-code', 'click-sequence', 'third-party', 'generic-captcha', 'slider', 'slider-puzzle', 'rotate', 'approval', 'unknown'] as const
const CHALLENGE_STRATEGIES = ['windows-system-ocr', 'ddddocr-click-sequence-demo', 'ddddocr-slider-demo', 'manual-click-sequence', 'manual-slider', 'manual-third-party', 'manual-otp', 'manual-approval', 'manual-review'] as const
const FOCUS_RELATIVE_DESKTOP_TOOLS = new Set([
  'desktop_type_text',
  'desktop_hotkey',
  'desktop_press',
  'desktop_paste',
])

export function assertInspectionId(id: string): void {
  if (!INSPECTION_ID.test(id)) {
    throw new Error('inspectionId must match /^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$/')
  }
}

export function normalizeInspectionId(id: string): string {
  const normalized = id
    .normalize('NFKD')
    .replace(/[^a-zA-Z0-9._-]+/g, '-')
    .replace(/^[^a-zA-Z0-9]+/, '')
    .replace(/[^a-zA-Z0-9]+$/, '')
    .replace(/[._-]{2,}/g, '-')
    .slice(0, 64)
    .replace(/[^a-zA-Z0-9]+$/, '')
  return normalized.length > 0 ? normalized : 'patrol'
}

export function asJsonObject(value: JsonValue): JsonObject {
  if (value === null || Array.isArray(value) || typeof value !== 'object') {
    throw new Error('tool arguments must be a JSON object')
  }
  return value
}

export function assertInspectionDefinition(value: unknown): asserts value is InspectionDefinition {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error('inspection.json must contain an object')
  const candidate = value as Partial<InspectionDefinition>
  if (candidate.schemaVersion !== '0.1' && candidate.schemaVersion !== '0.2') throw new Error('unsupported inspection schemaVersion')
  if (typeof candidate.id !== 'string') throw new Error('inspection.id must be a string')
  assertInspectionId(candidate.id)
  if (typeof candidate.name !== 'string' || candidate.name.trim().length === 0) throw new Error('inspection.name is required')
  assertSafePersistentText(candidate.name, 'inspection.name')
  if (typeof candidate.description !== 'string' || candidate.description.trim().length === 0) throw new Error('inspection.description is required')
  assertSafePersistentText(candidate.description, 'inspection.description')
  if (candidate.status !== 'draft' && candidate.status !== 'ready') throw new Error('inspection.status is invalid')
  if (typeof candidate.expectedResult !== 'string' || candidate.expectedResult.trim().length === 0) throw new Error('inspection.expectedResult is required')
  assertSafePersistentText(candidate.expectedResult, 'inspection.expectedResult')
  if (!Array.isArray(candidate.artifacts) || candidate.artifacts.some(item => typeof item !== 'string' || !(INSPECTION_ARTIFACTS as readonly string[]).includes(item))) throw new Error(`inspection.artifacts must contain only: ${INSPECTION_ARTIFACTS.join(', ')}`)
  if (!Array.isArray(candidate.steps)) throw new Error('inspection.steps must be an array')

  const auth = candidate.auth as unknown
  if (auth === null || typeof auth !== 'object' || Array.isArray(auth)) throw new Error('inspection.auth must be an object')
  const authRecord = auth as Record<string, unknown>
  if (!['none', 'existing-session', 'manual-checkpoint', 'secret-ref'].includes(String(authRecord.mode ?? ''))) throw new Error('inspection.auth.mode is invalid')
  if (authRecord.notes !== undefined) {
    if (typeof authRecord.notes !== 'string') throw new Error('inspection.auth.notes must be a string')
    assertSafePersistentText(authRecord.notes, 'inspection.auth.notes')
  }
  if (authRecord.challengeProfiles !== undefined) assertChallengeProfiles(authRecord.challengeProfiles)

  const schedule = candidate.schedule as unknown
  if (schedule !== null) {
    if (schedule === undefined || typeof schedule !== 'object' || Array.isArray(schedule)) throw new Error('inspection.schedule must be null or an object')
    const scheduleRecord = schedule as Record<string, unknown>
    if (typeof scheduleRecord.enabled !== 'boolean') throw new Error('inspection.schedule.enabled must be boolean')
    if (scheduleRecord.cron !== undefined) {
      if (typeof scheduleRecord.cron !== 'string' || scheduleRecord.cron.trim().length === 0) throw new Error('inspection.schedule.cron must be a non-empty string')
      assertSafePersistentText(scheduleRecord.cron, 'inspection.schedule.cron')
    }
  }

  const metadata = candidate.metadata as unknown
  if (metadata === null || typeof metadata !== 'object' || Array.isArray(metadata)) throw new Error('inspection.metadata must be an object')
  const metadataRecord = metadata as Record<string, unknown>
  if (typeof metadataRecord.createdAt !== 'string' || typeof metadataRecord.updatedAt !== 'string') throw new Error('inspection.metadata timestamps are required')
  if (metadataRecord.validatedAt !== undefined && typeof metadataRecord.validatedAt !== 'string') throw new Error('inspection.metadata.validatedAt must be a string')
  if (metadataRecord.successfulTeachingTrace !== undefined) {
    if (!Array.isArray(metadataRecord.successfulTeachingTrace)) {
      throw new Error('inspection.metadata.successfulTeachingTrace must be an array')
    }
    if (metadataRecord.successfulTeachingTrace.length > 512) {
      throw new Error('inspection.metadata.successfulTeachingTrace may contain at most 512 steps')
    }
    const traceIds = new Set<string>()
    for (const rawStep of metadataRecord.successfulTeachingTrace) {
      assertStep(rawStep)
      if (traceIds.has(rawStep.id)) {
        // Reused live ids can legitimately occur after an older build dropped a
        // step and later teaching reused that id. recordedAt disambiguates the
        // journal event, so duplicate step ids are allowed in the trace.
        continue
      }
      traceIds.add(rawStep.id)
    }
  }

  const target = candidate.target as unknown
  if (target === null || typeof target !== 'object' || Array.isArray(target)) {
    throw new Error('inspection.target must be a browser or desktop target')
  }
  const targetRecord = target as Record<string, unknown>
  if (targetRecord.type === 'browser') {
    if (typeof targetRecord.url !== 'string' || targetRecord.url.length === 0) {
      throw new Error('browser inspection target requires url')
    }
    assertHttpUrl(targetRecord.url)
    assertSafeForStorage({ url: targetRecord.url })
  } else if (targetRecord.type === 'desktop') {
    if (typeof targetRecord.app !== 'string' || targetRecord.app.trim().length === 0) {
      throw new Error('desktop inspection target requires app')
    }
    assertSafePersistentText(targetRecord.app, 'inspection.target.app')
    if (targetRecord.processName !== undefined) {
      if (typeof targetRecord.processName !== 'string' || targetRecord.processName.trim().length === 0) {
        throw new Error('inspection.target.processName must be a non-empty string')
      }
      assertSafePersistentText(targetRecord.processName, 'inspection.target.processName')
    }
    if (targetRecord.titleContains !== undefined) {
      if (typeof targetRecord.titleContains !== 'string' || targetRecord.titleContains.trim().length === 0) {
        throw new Error('inspection.target.titleContains must be a non-empty string')
      }
      assertSafePersistentText(targetRecord.titleContains, 'inspection.target.titleContains')
    }
    if ('url' in targetRecord) throw new Error('desktop inspection target must not contain url')
  } else {
    throw new Error('inspection.target.type must be browser or desktop')
  }

  const seen = new Set<string>()
  for (const rawStep of candidate.steps) {
    assertStep(rawStep)
    if (seen.has(rawStep.id)) throw new Error(`duplicate step id ${rawStep.id}`)
    if (rawStep.when !== undefined && !seen.has(rawStep.when.sourceStepId)) {
      throw new Error(`step ${rawStep.id} condition must reference an earlier step; unavailable source ${rawStep.when.sourceStepId}`)
    }
    seen.add(rawStep.id)
  }

  const targetHasDesktopWindowDefault = targetRecord.type === 'desktop'
    && (typeof targetRecord.processName === 'string' || typeof targetRecord.titleContains === 'string')
  for (const rawStep of candidate.steps) {
    if (rawStep.kind !== 'tool' || !FOCUS_RELATIVE_DESKTOP_TOOLS.has(rawStep.tool)) continue
    if (targetHasDesktopWindowDefault || hasStableDesktopWindowSelector(rawStep.arguments)) continue
    throw new Error(`step ${rawStep.id} ${rawStep.tool} requires processName/title/titleContains for replay-safe desktop focus; desktop-only flows may instead define processName/titleContains on inspection.target`)
  }
}

function assertChallengeProfiles(value: unknown): void {
  if (!Array.isArray(value)) throw new Error('inspection.auth.challengeProfiles must be an array')
  if (value.length > 8) throw new Error('inspection.auth.challengeProfiles may contain at most 8 learned profiles')
  const seen = new Set<string>()
  for (let index = 0; index < value.length; index += 1) {
    const profile = value[index]
    if (profile === null || typeof profile !== 'object' || Array.isArray(profile)) throw new Error(`inspection.auth.challengeProfiles[${index}] must be an object`)
    const record = profile as Record<string, unknown>
    if (!(CHALLENGE_KINDS as readonly unknown[]).includes(record.kind)) throw new Error(`inspection.auth.challengeProfiles[${index}].kind is invalid`)
    if (!(CHALLENGE_SUBTYPES as readonly unknown[]).includes(record.subtype)) throw new Error(`inspection.auth.challengeProfiles[${index}].subtype is invalid`)
    if (!(CHALLENGE_STRATEGIES as readonly unknown[]).includes(record.strategy)) throw new Error(`inspection.auth.challengeProfiles[${index}].strategy is invalid`)
    if (typeof record.firstObservedAt !== 'string' || typeof record.lastObservedAt !== 'string') throw new Error(`inspection.auth.challengeProfiles[${index}] timestamps are required`)
    if (!Number.isInteger(record.occurrences) || Number(record.occurrences) < 1) throw new Error(`inspection.auth.challengeProfiles[${index}].occurrences must be a positive integer`)
    if (!Number.isInteger(record.autoCompletedOccurrences) || Number(record.autoCompletedOccurrences) < 0 || Number(record.autoCompletedOccurrences) > Number(record.occurrences)) {
      throw new Error(`inspection.auth.challengeProfiles[${index}].autoCompletedOccurrences is invalid`)
    }
    const key = `${String(record.kind)}/${String(record.subtype)}`
    if (seen.has(key)) throw new Error(`inspection.auth.challengeProfiles contains duplicate ${key}`)
    seen.add(key)
  }
}

function assertStep(value: unknown): asserts value is InspectionStep {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error('inspection step must be an object')
  const step = value as Partial<InspectionStep>
  if (typeof step.id !== 'string' || !STEP_ID.test(step.id)) throw new Error('inspection step id is invalid')
  if (typeof step.name !== 'string' || step.name.trim().length === 0) throw new Error(`step ${step.id} name is required`)
  assertSafePersistentText(step.name, `step ${step.id} name`)
  if (typeof step.recordedAt !== 'string') throw new Error(`step ${step.id} recordedAt is required`)
  if (step.when !== undefined) assertCondition(step.when, `step ${step.id} when`)
  if (step.notes !== undefined) {
    if (typeof step.notes !== 'string') throw new Error(`step ${step.id} notes must be a string`)
    assertSafePersistentText(step.notes, `step ${step.id} notes`)
  }

  if (step.kind === 'checkpoint') {
    if (typeof step.prompt !== 'string' || step.prompt.trim().length === 0) throw new Error(`checkpoint ${step.id} prompt is required`)
    assertSafeCheckpointPrompt(step.prompt)
    if (!['login', 'otp', 'approval', 'other'].includes(step.reason ?? '')) throw new Error(`checkpoint ${step.id} reason is invalid`)
    return
  }
  if (step.kind !== 'tool') throw new Error(`step ${step.id} kind is invalid`)
  if (step.executionPlane !== undefined && step.executionPlane !== 'browser' && step.executionPlane !== 'desktop') {
    throw new Error(`step ${step.id} executionPlane must be browser or desktop`)
  }
  if (step.executionInstruction !== undefined) {
    if (typeof step.executionInstruction !== 'string' || step.executionInstruction.trim().length === 0) {
      throw new Error(`step ${step.id} executionInstruction must be a non-empty string`)
    }
    assertSafePersistentText(step.executionInstruction, `step ${step.id} executionInstruction`)
  }
  if (typeof step.tool !== 'string' || step.tool.length === 0) throw new Error(`tool step ${step.id} tool is required`)
  const expectedPlane = step.tool.startsWith('browser_') ? 'browser' : step.tool.startsWith('desktop_') ? 'desktop' : undefined
  if (expectedPlane !== undefined && step.executionPlane !== undefined && step.executionPlane !== expectedPlane) {
    throw new Error(`step ${step.id} executionPlane=${step.executionPlane} conflicts with tool ${step.tool}`)
  }
  if (!isReplayableBrowserTool(step.tool) && !isReplayableDesktopTool(step.tool)) {
    const family = step.tool.startsWith('browser_')
      ? 'browser'
      : step.tool.startsWith('desktop_')
        ? 'desktop'
        : 'Patrol'
    throw new Error(`tool step ${step.id} uses non-replayable ${family} tool ${step.tool}`)
  }
  if (step.arguments === undefined) throw new Error(`tool step ${step.id} arguments are required`)
  assertSafeForStorage(step.arguments)
  assertToolArgumentPolicy(step.id, step.tool, step.arguments)
  if (step.expectation !== undefined) assertExpectation(step.expectation, `step ${step.id} expectation`)
  if (step.sensitive !== undefined && typeof step.sensitive !== 'boolean') throw new Error(`step ${step.id} sensitive must be boolean`)
  if (step.locator !== undefined) {
    if (step.locator === null || typeof step.locator !== 'object' || Array.isArray(step.locator)) throw new Error(`step ${step.id} locator must be an object`)
    for (const [key, locatorValue] of Object.entries(step.locator)) {
      if (!['text', 'role', 'tag'].includes(key) || typeof locatorValue !== 'string' || locatorValue.trim().length === 0) {
        throw new Error(`step ${step.id} locator is invalid`)
      }
      assertSafePersistentText(locatorValue, `step ${step.id} locator.${key}`)
    }
  }
  if (step.artifact !== undefined && step.artifact !== 'page-text' && step.artifact !== 'screenshot') {
    throw new Error(`step ${step.id} artifact is invalid`)
  }
  if (step.artifact === 'page-text' && step.tool !== 'browser_read_page') throw new Error(`step ${step.id} page-text artifact requires browser_read_page`)
  if (step.artifact === 'screenshot' && step.tool !== 'browser_screenshot' && step.tool !== 'desktop_screenshot') {
    throw new Error(`step ${step.id} screenshot artifact requires browser_screenshot or desktop_screenshot`)
  }
}

function assertToolArgumentPolicy(stepId: string, tool: string, args: JsonObject): void {
  if ('tabId' in args) {
    throw new Error(`step ${stepId} must not persist ephemeral browser tabId values`)
  }
  if (isReplayableDesktopTool(tool)) {
    assertDesktopToolArgumentPolicy(stepId, tool, args)
  }
  if (tool === 'browser_navigate') {
    const action = args.action ?? 'navigate'
    if (!['navigate', 'back', 'forward', 'reload'].includes(String(action))) {
      throw new Error(`step ${stepId} browser_navigate action is invalid: ${String(action)}`)
    }
    if (action === 'navigate') {
      if (typeof args.url !== 'string' || args.url.length === 0) throw new Error(`step ${stepId} browser_navigate requires url`)
      if (args.newTab === true) throw new Error(`step ${stepId} browser_navigate must reuse the active tab; newTab is not replay-stable`)
    } else {
      if ('url' in args) throw new Error(`step ${stepId} browser_navigate history action ${String(action)} must not persist url`)
      if ('newTab' in args) throw new Error(`step ${stepId} browser_navigate history action ${String(action)} must not persist newTab`)
    }
  }
  const refs = collectCredentialReferences(args)
  if (tool === 'browser_type_credential') {
    const raw = args.credentialRef
    if (typeof raw !== 'string' || credentialReferenceName(raw) === undefined) {
      throw new Error(`step ${stepId} browser_type_credential must store credentialRef as \${credential:REF}`)
    }
    if (refs.size !== 1 || !refs.has(credentialReferenceName(raw) as string)) {
      throw new Error(`step ${stepId} browser_type_credential contains unexpected credential references`)
    }
    if ('text' in args) throw new Error(`step ${stepId} browser_type_credential must not store a text value`)
    return
  }
  if (refs.size > 0) throw new Error(`step ${stepId} may not embed credential references in ${tool}; use browser_type_credential`)
  if (tool === 'browser_type') {
    const text = args.text
    if (typeof text !== 'string') throw new Error(`step ${stepId} browser_type requires text`)
    assertSafePublicInputText(text)
  }
}

function hasStableDesktopWindowSelector(args: JsonObject): boolean {
  return ['processName', 'title', 'titleContains'].some(key =>
    typeof args[key] === 'string' && String(args[key]).trim().length > 0)
}

function assertDesktopToolArgumentPolicy(stepId: string, tool: string, args: JsonObject): void {
  if ('hwnd' in args || 'processId' in args) {
    throw new Error(`step ${stepId} may not persist ephemeral desktop hwnd/processId values; use processName/title/titleContains`)
  }

  const requireString = (key: string): string => {
    const value = args[key]
    if (typeof value !== 'string' || value.trim().length === 0) {
      throw new Error(`step ${stepId} ${tool} requires ${key}`)
    }
    return value
  }
  const requireInteger = (key: string): number => {
    const value = args[key]
    if (typeof value !== 'number' || !Number.isInteger(value)) {
      throw new Error(`step ${stepId} ${tool} requires integer ${key}`)
    }
    return value
  }

  if (tool === 'desktop_launch_app') {
    const file = typeof args.file === 'string' ? args.file.trim() : ''
    const app = typeof args.app === 'string' ? args.app.trim() : ''
    if (!file && !app) throw new Error(`step ${stepId} desktop_launch_app requires file or app`)
  }
  if (tool === 'desktop_open_path' || tool === 'desktop_delete_path') requireString('path')
  if (tool === 'desktop_click_target') {
    const selectors = [args.name, args.automationId, args.controlType, args.className]
    if (selectors.every(value => typeof value !== 'string' || value.trim() === '')) {
      throw new Error(`step ${stepId} desktop_click_target requires name, automationId, controlType, or className`)
    }
  }
  if (tool === 'desktop_click_ocr_text') requireString('text')
  if (tool === 'desktop_click_coordinates') {
    requireInteger('x')
    requireInteger('y')
  }
  if (tool === 'desktop_drag') {
    requireInteger('fromX')
    requireInteger('fromY')
    requireInteger('toX')
    requireInteger('toY')
  }
  if (tool === 'desktop_type_text' || tool === 'desktop_set_clipboard_text') requireString('text')
  if (tool === 'desktop_type_target') {
    requireString('text')
    const selectors = [args.name, args.automationId, args.controlType, args.className]
    if (selectors.every(value => typeof value !== 'string' || value.trim() === '')) {
      throw new Error(`step ${stepId} desktop_type_target requires name, automationId, controlType, or className`)
    }
  }
  if (tool === 'desktop_paste_target' || tool === 'desktop_press_target') {
    if (tool === 'desktop_press_target') requireString('key')
    const selectors = [args.name, args.automationId, args.controlType, args.className]
    if (selectors.every(value => typeof value !== 'string' || value.trim() === '')) {
      throw new Error(`step ${stepId} ${tool} requires name, automationId, controlType, or className`)
    }
  }

  if (tool === 'desktop_hotkey') requireString('combo')
  if (tool === 'desktop_press') requireString('key')
  if (tool === 'desktop_wait') {
    const milliseconds = requireInteger('milliseconds')
    if (milliseconds < 0 || milliseconds > 600000) throw new Error(`step ${stepId} desktop_wait milliseconds must be between 0 and 600000`)
  }
  if (tool === 'desktop_wait_for_target') {
    const selectors = [args.name, args.automationId, args.controlType, args.className, args.value, args.text]
    if (selectors.every(value => typeof value !== 'string' || value.trim() === '')) {
      throw new Error(`step ${stepId} desktop_wait_for_target requires text or a UI Automation selector`)
    }
    if (args.source !== undefined && args.source !== 'auto' && args.source !== 'uia' && args.source !== 'ocr') {
      throw new Error(`step ${stepId} desktop_wait_for_target source must be auto, uia, or ocr`)
    }
    if (args.source === 'ocr') requireString('text')
    if (args.match !== undefined && args.match !== 'exact' && args.match !== 'contains') {
      throw new Error(`step ${stepId} desktop_wait_for_target match must be exact or contains`)
    }
    if (args.caseSensitive !== undefined && typeof args.caseSensitive !== 'boolean') {
      throw new Error(`step ${stepId} desktop_wait_for_target caseSensitive must be boolean`)
    }
    if (args.requireUnique !== undefined && typeof args.requireUnique !== 'boolean') {
      throw new Error(`step ${stepId} desktop_wait_for_target requireUnique must be boolean`)
    }
    if (args.timeoutMs !== undefined) {
      const timeoutMs = requireInteger('timeoutMs')
      if (timeoutMs < 100 || timeoutMs > 120000) {
        throw new Error(`step ${stepId} desktop_wait_for_target timeoutMs must be between 100 and 120000`)
      }
    }
    if (args.pollMs !== undefined) {
      const pollMs = requireInteger('pollMs')
      if (pollMs < 100 || pollMs > 5000) {
        throw new Error(`step ${stepId} desktop_wait_for_target pollMs must be between 100 and 5000`)
      }
    }
    if (args.maxElements !== undefined) {
      const maxElements = requireInteger('maxElements')
      if (maxElements < 1 || maxElements > 1000) {
        throw new Error(`step ${stepId} desktop_wait_for_target maxElements must be between 1 and 1000`)
      }
    }
  }
  if (tool === 'desktop_set_clipboard_files') {
    const paths = args.paths
    if (!Array.isArray(paths) || paths.length === 0 || paths.some(item => typeof item !== 'string' || item.trim() === '')) {
      throw new Error(`step ${stepId} desktop_set_clipboard_files requires a non-empty string paths array`)
    }
  }
}

function assertCondition(condition: StepCondition, at: string): void {
  if (typeof condition.sourceStepId !== 'string' || !STEP_ID.test(condition.sourceStepId)) throw new Error(`${at}.sourceStepId is invalid`)
  assertExpectation(condition, at)
}

function assertExpectation(expectation: TextExpectation, at: string): void {
  if (expectation.mode !== 'contains' && expectation.mode !== 'not-contains') throw new Error(`${at}.mode is invalid`)
  if (typeof expectation.value !== 'string' || expectation.value.length === 0) throw new Error(`${at}.value is required`)
  assertSafePersistentText(expectation.value, `${at}.value`)
  if (typeof expectation.caseSensitive !== 'boolean') throw new Error(`${at}.caseSensitive must be boolean`)
}

function assertHttpUrl(value: string): void {
  let parsed: URL
  try {
    parsed = new URL(value)
  } catch {
    throw new Error(`invalid target URL: ${value}`)
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') throw new Error('inspection target URL must use http or https')
  if (parsed.username !== '' || parsed.password !== '') throw new Error('inspection target URL must not embed credentials')
}
