param(
    [string]$HarnessRoot = "",
    [string]$Profile = "web",
    [bool]$InstallCaptchaDemoSolver = $true
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot

function Write-Utf8NoBom {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Content
    )

    $encoding = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $encoding)
}

function ConvertTo-YamlSingleQuoted {
    param([Parameter(Mandatory = $true)][string]$Value)
    return $Value.Replace("'", "''")
}

function Install-ClientHostDependency {
    param(
        [Parameter(Mandatory = $true)][string]$ProfileDir,
        [Parameter(Mandatory = $true)][string]$ClientHostRoot
    )

    $profileManifestPath = Join-Path $ProfileDir "package.json"
    if (-not (Test-Path -LiteralPath $profileManifestPath)) {
        throw "Harness profile is not initialized: $ProfileDir. Start the profile once before installing DSH Patrol."
    }

    Push-Location $ProfileDir
    try {
        pnpm add --save-prod $ClientHostRoot
        if ($LASTEXITCODE -ne 0) { throw "failed to install dsh-patrol-client-host into Harness profile $ProfileDir" }
    } finally {
        Pop-Location
    }

    $profileManifest = [System.IO.File]::ReadAllText($profileManifestPath) | ConvertFrom-Json
    $dependency = $profileManifest.dependencies.'dsh-patrol-client-host'
    if ([string]::IsNullOrWhiteSpace([string]$dependency)) {
        throw "Harness profile dependency dsh-patrol-client-host was not recorded in $profileManifestPath"
    }

    $installedManifestPath = Join-Path $ProfileDir "node_modules\dsh-patrol-client-host\package.json"
    if (-not (Test-Path -LiteralPath $installedManifestPath)) {
        throw "Harness profile cannot resolve installed dsh-patrol-client-host: $installedManifestPath"
    }
    $installedManifest = [System.IO.File]::ReadAllText($installedManifestPath) | ConvertFrom-Json
    if ($installedManifest.name -ne "dsh-patrol-client-host" -or $installedManifest.dsh.client.platform -ne "web") {
        throw "Installed dsh-patrol-client-host manifest is missing its web client declaration: $installedManifestPath"
    }
}

function Install-HarnessClientHostCompatMirror {
    param(
        [Parameter(Mandatory = $true)][string]$HarnessRootPath,
        [Parameter(Mandatory = $true)][string]$ClientHostRoot
    )

    $resolvedHarnessRoot = [System.IO.Path]::GetFullPath($HarnessRootPath)
    $nodeModules = Join-Path $resolvedHarnessRoot "node_modules"
    if (-not (Test-Path -LiteralPath $nodeModules)) {
        throw "Harness node_modules does not exist: $nodeModules. Run pnpm install in the Harness checkout first."
    }

    $target = Join-Path $nodeModules "dsh-patrol-client-host"
    $marker = Join-Path $target ".managed-by-dsh-patrol"
    if (Test-Path -LiteralPath $target) {
        if (-not (Test-Path -LiteralPath $marker)) {
            throw "Refusing to replace unmanaged Harness package path: $target"
        }
        Remove-Item -LiteralPath $target -Recurse -Force
    }

    New-Item -ItemType Directory -Force -Path $target | Out-Null
    foreach ($name in @("package.json", "index.js", "client.js")) {
        $source = Join-Path $ClientHostRoot $name
        if (-not (Test-Path -LiteralPath $source)) {
            throw "Patrol client host source file is missing: $source"
        }
        Copy-Item -LiteralPath $source -Destination (Join-Path $target $name) -Force
    }
    Write-Utf8NoBom -Path $marker -Content "managed by dsh-patrol local installer`n"

    $targetManifestPath = Join-Path $target "package.json"
    $targetManifest = [System.IO.File]::ReadAllText($targetManifestPath) | ConvertFrom-Json
    if ($targetManifest.name -ne "dsh-patrol-client-host" -or $targetManifest.dsh.client.platform -ne "web") {
        throw "Harness compatibility mirror has an invalid Patrol client manifest: $targetManifestPath"
    }

    Push-Location $resolvedHarnessRoot
    try {
        $resolvedManifest = (& node -e "console.log(require.resolve('dsh-patrol-client-host/package.json'))" 2>&1 | Out-String).Trim()
        if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($resolvedManifest)) {
            throw "Harness root cannot resolve dsh-patrol-client-host/package.json after compatibility install"
        }
        $expectedManifest = [System.IO.Path]::GetFullPath($targetManifestPath)
        $actualManifest = [System.IO.Path]::GetFullPath($resolvedManifest)
        if ($actualManifest -ne $expectedManifest) {
            throw "Harness root resolves dsh-patrol-client-host from an unexpected location: $actualManifest (expected $expectedManifest)"
        }
    } finally {
        Pop-Location
    }

    return $target
}

function Remove-LegacyGlobalPatrolRows {
    param([Parameter(Mandatory = $true)][string]$PatchPath)

    if (-not (Test-Path -LiteralPath $PatchPath)) { return }
    $lines = [System.IO.File]::ReadAllLines($PatchPath)
    $result = New-Object System.Collections.Generic.List[string]
    $skip = $false
    $skipIndent = -1
    $removed = 0

    foreach ($line in $lines) {
        if (-not $skip) {
            $match = [regex]::Match($line, '^(\s*)-\s*id:\s*dsh-patrol\s*$')
            if ($match.Success) {
                $skip = $true
                $skipIndent = $match.Groups[1].Value.Length
                $removed += 1
                continue
            }
            $result.Add($line)
            continue
        }

        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        $indent = $line.Length - $line.TrimStart().Length
        if ($indent -le $skipIndent) {
            $skip = $false
            $skipIndent = -1
            $result.Add($line)
        }
    }

    if ($removed -gt 0) {
        Write-Utf8NoBom -Path $PatchPath -Content (($result -join "`r`n").TrimEnd() + "`r`n")
        Write-Host "Removed $removed legacy global dsh-patrol profile row(s); the Patrol preset is now the single orchestration owner." -ForegroundColor Yellow
    }
}

function Install-ManagedHostBridgePatch {
    param(
        [Parameter(Mandatory = $true)][string]$PatchPath,
        [Parameter(Mandatory = $true)][string]$BridgeHostUri,
        [Parameter(Mandatory = $true)][string]$ScreenshotDir
    )

    $patchDir = Split-Path -Parent $PatchPath
    New-Item -ItemType Directory -Force -Path $patchDir | Out-Null

    $begin = "# BEGIN DSH-PATROL MANAGED HOST BRIDGE"
    $end = "# END DSH-PATROL MANAGED HOST BRIDGE"
    $existing = if (Test-Path $PatchPath) { [System.IO.File]::ReadAllText($PatchPath) } else { "" }
    $pattern = "(?ms)^" + [regex]::Escape($begin) + "\r?\n.*?^" + [regex]::Escape($end) + "\r?\n?"
    $clean = [regex]::Replace($existing, $pattern, "").TrimEnd()
    $safeBridgeHostUri = ConvertTo-YamlSingleQuoted -Value $BridgeHostUri
    $safeScreenshotDir = ConvertTo-YamlSingleQuoted -Value $ScreenshotDir

    $block = @"
$begin
- insert:
    - id: dsh-patrol-browser-host
      name: '$safeBridgeHostUri'
      config:
        path: /patrol-browser-bridge
        commandTimeoutMs: 60000
        maxMessageBytes: 8388608
        managedBrowser: true
        browserStartTimeoutMs: 30000
        browserConnectTimeoutMs: 15000
        screenshotDir: '$safeScreenshotDir'

    - id: dsh-patrol-client-host
      name: 'dsh-patrol-client-host'
$end
"@

    $next = if ($clean.Length -gt 0) { "$clean`r`n`r`n$block`r`n" } else { "$block`r`n" }
    Write-Utf8NoBom -Path $PatchPath -Content $next
}

function Install-ManagedCleanupPatch {
    param(
        [Parameter(Mandatory = $true)][string]$PatchPath,
        [Parameter(Mandatory = $true)][string]$CleanupUri,
        [Parameter(Mandatory = $true)][string]$ProfileName
    )

    $patchDir = Split-Path -Parent $PatchPath
    New-Item -ItemType Directory -Force -Path $patchDir | Out-Null

    $begin = "# BEGIN DSH-PATROL MANAGED CLEANUP"
    $end = "# END DSH-PATROL MANAGED CLEANUP"
    $existing = if (Test-Path $PatchPath) { [System.IO.File]::ReadAllText($PatchPath) } else { "" }
    $pattern = "(?ms)^" + [regex]::Escape($begin) + "\r?\n.*?^" + [regex]::Escape($end) + "\r?\n?"
    $clean = [regex]::Replace($existing, $pattern, "").TrimEnd()
    $safeUri = ConvertTo-YamlSingleQuoted -Value $CleanupUri
    $safeProfile = ConvertTo-YamlSingleQuoted -Value $ProfileName

    $block = @"
$begin
- insert:
    - id: dsh-patrol-cleanup
      name: '$safeUri'
      config:
        profile: '$safeProfile'
$end
"@

    $next = if ($clean.Length -gt 0) { "$clean`r`n`r`n$block`r`n" } else { "$block`r`n" }
    Write-Utf8NoBom -Path $PatchPath -Content $next
}

function Copy-LegacyPatrolData {
    param(
        [Parameter(Mandatory = $true)][string]$LegacyRoot,
        [Parameter(Mandatory = $true)][string]$WorkspaceRoot
    )

    if (-not (Test-Path -LiteralPath $LegacyRoot)) { return }
    New-Item -ItemType Directory -Force -Path $WorkspaceRoot | Out-Null
    foreach ($name in @("inspections", "runs", "resumes")) {
        $source = Join-Path $LegacyRoot $name
        $target = Join-Path $WorkspaceRoot $name
        if ((Test-Path -LiteralPath $source) -and -not (Test-Path -LiteralPath $target)) {
            Copy-Item -LiteralPath $source -Destination $target -Recurse -Force
            Write-Host "Migrated legacy Patrol $name into workspace storage." -ForegroundColor Yellow
        }
    }
}

Write-Host "===== Build and verify DSH Patrol =====" -ForegroundColor Cyan
Push-Location $ProjectRoot
try {
    pnpm install
    if ($LASTEXITCODE -ne 0) { throw "pnpm install failed" }
    pnpm typecheck
    if ($LASTEXITCODE -ne 0) { throw "typecheck failed" }
    pnpm test
    if ($LASTEXITCODE -ne 0) { throw "tests failed" }
    pnpm check:extension
    if ($LASTEXITCODE -ne 0) { throw "extension checks failed" }
    pnpm check:encoding
    if ($LASTEXITCODE -ne 0) { throw "encoding checks failed" }
    pnpm build
    if ($LASTEXITCODE -ne 0) { throw "build failed" }
} finally {
    Pop-Location
}

if ($InstallCaptchaDemoSolver) {
    try {
        & (Join-Path $PSScriptRoot "install-captcha-demo.ps1") -ProjectRoot $ProjectRoot
    } catch {
        Write-Warning "Optional owned-site CAPTCHA demo solver was not installed: $($_.Exception.Message)"
        Write-Warning "Core Patrol remains installed. After fixing Python/network prerequisites, run scripts\install-captcha-demo.ps1 manually."
    }
}

$DshHome = if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $HOME ".dsh" }
$ProfileDir = Join-Path $DshHome "profiles\$Profile"
$PresetDir = Join-Path $DshHome ".agent-presets\patrol"
New-Item -ItemType Directory -Force -Path $PresetDir | Out-Null

$WorkspaceRoot = if ($HarnessRoot) { [System.IO.Path]::GetFullPath($HarnessRoot) } else { [System.IO.Path]::GetFullPath((Get-Location).Path) }
if (-not (Test-Path -LiteralPath $WorkspaceRoot)) {
    throw "Harness workspace does not exist: $WorkspaceRoot"
}
$PatrolStorage = Join-Path $WorkspaceRoot ".dsh-patrol"
$PatrolScreenshotDir = Join-Path $PatrolStorage "browser-tmp"
New-Item -ItemType Directory -Force -Path $PatrolStorage | Out-Null
New-Item -ItemType Directory -Force -Path $PatrolScreenshotDir | Out-Null
Copy-LegacyPatrolData -LegacyRoot (Join-Path $DshHome "patrol") -WorkspaceRoot $PatrolStorage

$CredentialHelperSource = Join-Path $ProjectRoot "scripts\set-patrol-credential.ps1"
$CredentialHelperTarget = Join-Path $PatrolStorage "set-patrol-credential.ps1"
Copy-Item -LiteralPath $CredentialHelperSource -Destination $CredentialHelperTarget -Force
$CredentialHelperSourceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $CredentialHelperSource).Hash
$CredentialHelperTargetHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $CredentialHelperTarget).Hash
if ($CredentialHelperSourceHash -ne $CredentialHelperTargetHash) {
    throw "credential helper copy verification failed"
}

$PatrolIndex = (New-Object System.Uri((Resolve-Path (Join-Path $ProjectRoot "lib\index.js")))).AbsoluteUri
$BridgeHostIndex = (New-Object System.Uri((Resolve-Path (Join-Path $ProjectRoot "browser-bridge-runtime\index.js")))).AbsoluteUri
$ClientHostRoot = [System.IO.Path]::GetFullPath((Join-Path $ProjectRoot "client-host-runtime"))
$BrowserToolsIndex = (New-Object System.Uri((Resolve-Path (Join-Path $ProjectRoot "browser-bridge-runtime\tools-plugin.js")))).AbsoluteUri
$DesktopToolsIndex = (New-Object System.Uri((Resolve-Path (Join-Path $ProjectRoot "desktop-runtime\tools-plugin.js")))).AbsoluteUri
$SafeStoragePath = ConvertTo-YamlSingleQuoted -Value $PatrolStorage

# Newer Harness versions resolve client rows from the profile's dependency
# closure, while dsh@0.1.1-rc.2 (b150a55) resolves them from the Harness config
# tree's ctx.baseUrl. Install both surfaces so the same Patrol checkout works on
# either loader implementation without asking the user to upgrade Harness.
Install-ClientHostDependency -ProfileDir $ProfileDir -ClientHostRoot $ClientHostRoot
$HarnessClientHostMirror = $null
if ($HarnessRoot) {
    $HarnessClientHostMirror = Install-HarnessClientHostCompatMirror -HarnessRootPath $HarnessRoot -ClientHostRoot $ClientHostRoot
}

# Keep this PowerShell source ASCII-only for Windows PowerShell 5.1 compatibility.
# Copy the UTF-8 preset bytes directly instead of embedding non-ASCII literals here.
$PresetSource = Join-Path $ProjectRoot "presets\patrol\preset.yml"
$PresetTarget = Join-Path $PresetDir "preset.yml"
Copy-Item -LiteralPath $PresetSource -Destination $PresetTarget -Force

$SourceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $PresetSource).Hash
$TargetHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $PresetTarget).Hash
if ($SourceHash -ne $TargetHash) {
    throw "preset.yml copy verification failed"
}

$AgentPresetSource = Join-Path $ProjectRoot "presets\patrol\agent.cordis.yml"
$AgentYaml = [System.IO.File]::ReadAllText($AgentPresetSource)
$AgentYaml = $AgentYaml.Replace("name: 'dsh-patrol/browser-tools'", "name: '$BrowserToolsIndex'")
$AgentYaml = $AgentYaml.Replace("name: 'dsh-patrol/desktop-tools'", "name: '$DesktopToolsIndex'")
$AgentYaml = $AgentYaml.Replace("name: 'dsh-patrol'", "name: '$PatrolIndex'")
$AgentYaml = $AgentYaml.Replace("storagePath: .dsh-patrol", "storagePath: '$SafeStoragePath'")
$AgentPresetPath = Join-Path $PresetDir "agent.cordis.yml"
Write-Utf8NoBom -Path $AgentPresetPath -Content $AgentYaml
$InstalledAgentYaml = [System.IO.File]::ReadAllText($AgentPresetPath)
foreach ($requiredRow in @(
    "id: browser-tools",
    "name: '$BrowserToolsIndex'",
    "id: desktop-tools",
    "name: '$DesktopToolsIndex'",
    "id: dsh-patrol",
    "name: '$PatrolIndex'"
)) {
    if (-not $InstalledAgentYaml.Contains($requiredRow)) {
        throw "Patrol agent preset is incomplete after local install; missing row: $requiredRow"
    }
}
Write-Utf8NoBom -Path (Join-Path $PresetDir ".managed-by-dsh-patrol") -Content "managed by dsh-patrol local installer`n"

# Copy a self-contained cleanup plugin outside the source checkout. If the
# local Patrol source is later uninstalled, this small Node-only plugin can
# remove stale preset/browser integration on the next Harness boot.
$PatrolRuntimeDir = Join-Path $DshHome "patrol"
New-Item -ItemType Directory -Force -Path $PatrolRuntimeDir | Out-Null
$CleanupSource = Join-Path $ProjectRoot "cleanup-runtime\index.js"
$CleanupTarget = Join-Path $PatrolRuntimeDir "integration-cleanup.mjs"
Copy-Item -LiteralPath $CleanupSource -Destination $CleanupTarget -Force
$CleanupUri = (New-Object System.Uri((Resolve-Path $CleanupTarget))).AbsoluteUri

$WebPatch = Join-Path $ProfileDir "cordis.patch.yml"
Remove-LegacyGlobalPatrolRows -PatchPath $WebPatch
Install-ManagedHostBridgePatch -PatchPath $WebPatch -BridgeHostUri $BridgeHostIndex -ScreenshotDir $PatrolScreenshotDir
Install-ManagedCleanupPatch -PatchPath $WebPatch -CleanupUri $CleanupUri -ProfileName $Profile

if (Test-Path $WebPatch) {
    $patchText = [System.IO.File]::ReadAllText($WebPatch)
    if (-not $patchText.Contains("id: dsh-patrol-client-host") -or -not $patchText.Contains("name: 'dsh-patrol-client-host'")) {
        throw "Patrol web client host package row was not written to profile patch: $WebPatch"
    }
    $oldGlobal = Select-String -Path $WebPatch -Pattern "^\s*-?\s*id:\s*dsh-patrol\s*$|DSH-Patrol/lib/index" -Quiet
    if ($oldGlobal) {
        throw "Legacy global DSH Patrol row is still present after cleanup: $WebPatch"
    }
}

Write-Host ""
Write-Host "Local Patrol preset installed and UTF-8 verified: $PresetDir" -ForegroundColor Green
Write-Host "Host browser bridge patch installed: $WebPatch" -ForegroundColor Green
Write-Host "Patrol web client package installed into profile: $ProfileDir" -ForegroundColor Green
if ($HarnessClientHostMirror) {
    Write-Host "Patrol web client compatibility mirror installed: $HarnessClientHostMirror" -ForegroundColor Green
}
Write-Host "Lifecycle cleanup coordinator installed: $CleanupTarget" -ForegroundColor Green
Write-Host "Patrol workspace storage: $PatrolStorage" -ForegroundColor Green
Write-Host "Patrol screenshot temp storage: $PatrolScreenshotDir" -ForegroundColor Green
Write-Host "Patrol credential helper: $CredentialHelperTarget" -ForegroundColor Green
Write-Host "Browser provider: installed in Patrol preset from $BrowserToolsIndex" -ForegroundColor Green
Write-Host "Desktop provider: installed in Patrol preset from $DesktopToolsIndex" -ForegroundColor Green
Write-Host "Browser provisioning: automatic managed Chromium profile; no manual extension installation is required." -ForegroundColor Green
if ($HarnessRoot) {
    Write-Host "Start Harness with:" -ForegroundColor Cyan
    Write-Host "  cd $HarnessRoot"
    Write-Host "  pnpm dsh web"
} else {
    Write-Host "Start your Harness normally with: pnpm dsh web" -ForegroundColor Cyan
}
Write-Host "Then open a NEW session and choose the Patrol preset. Patrol will launch the managed browser and load the bundled extension automatically." -ForegroundColor Cyan
