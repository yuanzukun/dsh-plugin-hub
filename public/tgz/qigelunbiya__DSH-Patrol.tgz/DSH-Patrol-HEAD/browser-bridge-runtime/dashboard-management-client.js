(() => {
  'use strict'

  const API = location.pathname.replace(/\/ui$/, '')
  const qs = new URLSearchParams(location.search)
  const WORKSPACE = qs.get('workspace') || ''
  const root = document.getElementById('root')
  if (!root || !WORKSPACE) return

  let cardsById = new Map()
  let patchQueued = false

  const fmt = value => {
    if (!value) return '—'
    const date = new Date(value)
    return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString('zh-CN', { hour12: false })
  }

  async function request(path, options = {}) {
    const response = await fetch(API + path, {
      cache: 'no-store',
      credentials: 'same-origin',
      headers: { accept: 'application/json', 'content-type': 'application/json' },
      ...options,
    })
    const payload = await response.json()
    if (!response.ok || payload.ok !== true) throw new Error(payload.error || '请求失败')
    return payload
  }

  async function loadCatalog() {
    const payload = await request(`/catalog?workspace=${encodeURIComponent(WORKSPACE)}`)
    cardsById = new Map((payload.inspections || []).map(item => [item.definition.id, item]))
    schedulePatch()
  }

  function schedulePatch() {
    if (patchQueued) return
    patchQueued = true
    setTimeout(() => {
      patchQueued = false
      patchCards()
      patchDetail()
    }, 0)
  }

  function patchCards() {
    for (const card of root.querySelectorAll('[data-flow-id]')) {
      if (!(card instanceof HTMLElement)) continue
      const id = card.getAttribute('data-flow-id') || ''
      const item = cardsById.get(id)
      if (!item) continue

      const meta = card.querySelector('.flow-meta')
      const time = meta?.querySelector('span:last-child')
      if (time) {
        const nextText = `更新 ${fmt(item.definition?.metadata?.updatedAt)}`
        if (time.textContent !== nextText) time.textContent = nextText
        if (time.getAttribute('title') !== '流程定义最近更新时间') time.setAttribute('title', '流程定义最近更新时间')
      }

      if (!card.querySelector('[data-flow-tools]')) {
        const tools = document.createElement('div')
        tools.setAttribute('data-flow-tools', '')
        tools.className = 'flow-manage-actions'
        tools.innerHTML = [
          `<button class="mini-btn" data-manage-action="rename" data-manage-id="${escapeAttr(id)}">改名</button>`,
          `<button class="mini-btn" data-manage-action="json" data-manage-id="${escapeAttr(id)}">查看 JSON</button>`,
          `<button class="mini-btn" title="清理探针、被后续重置废弃的轮次和重复输入修正" data-manage-action="optimize" data-manage-id="${escapeAttr(id)}">清理试错</button>`,
          `<button class="mini-btn danger" data-manage-action="delete" data-manage-id="${escapeAttr(id)}">删除</button>`,
          `<button class="mini-btn run" data-manage-action="run" data-manage-id="${escapeAttr(id)}">▶ 运行</button>`,
        ].join('')
        meta?.before(tools)
      }
    }
  }

  function patchDetail() {
    const hero = root.querySelector('.hero')
    const actions = root.querySelector('.top .actions')
    if (!hero || !actions) return
    const id = hero.querySelector('.tiny.muted')?.textContent?.trim() || ''
    const item = cardsById.get(id)
    if (!id || !item) return

    if (!actions.querySelector('[data-detail-flow-tools]')) {
      const wrap = document.createElement('span')
      wrap.setAttribute('data-detail-flow-tools', '')
      wrap.className = 'detail-flow-actions'
      wrap.innerHTML = [
        `<button class="btn run-btn" data-manage-action="run" data-manage-id="${escapeAttr(id)}">▶ 运行流程</button>`,
        `<button class="btn" data-manage-action="json" data-manage-id="${escapeAttr(id)}">查看流程 JSON</button>`,
        `<button class="btn" data-manage-action="rename" data-manage-id="${escapeAttr(id)}">编辑名称</button>`,
        `<button class="btn" title="清理探针、重置前的废弃轮次和被后续输入覆盖的修正步骤" data-manage-action="optimize" data-manage-id="${escapeAttr(id)}">清理试错步骤</button>`,
        `<button class="btn danger-btn" data-manage-action="delete" data-manage-id="${escapeAttr(id)}">删除流程</button>`,
      ].join('')
      actions.prepend(wrap)
    }

    // The original flow diagram intentionally stayed compact, but that made an
    // input step look like it had "no concrete operation". Add a safe exact
    // arguments block to each node so selector/text/reference details are
    // inspectable without requiring a screenshot. Stored secret steps contain
    // references, not plaintext values.
    const nodes = [...root.querySelectorAll('.steps .node')]
    const steps = Array.isArray(item.definition?.steps) ? item.definition.steps : []
    nodes.forEach((node, index) => {
      if (!(node instanceof HTMLElement) || node.querySelector('[data-step-execution]')) return
      const step = steps[index]
      if (!step) return
      const details = document.createElement('div')
      details.setAttribute('data-step-execution', '')
      details.className = 'step-execution'
      if (step.kind === 'checkpoint') {
        details.textContent = `检查点：${step.reason || 'other'}${step.prompt ? ` · ${step.prompt}` : ''}`
      } else {
        const plane = step.executionPlane === 'desktop' || String(step.tool || '').startsWith('desktop_')
          ? '应用'
          : step.executionPlane === 'browser' || String(step.tool || '').startsWith('browser_')
            ? '浏览器'
            : '自动'
        const instruction = step.executionInstruction
          ? `<div class="step-execution-label">${escapeHtml(plane)} · 实际命令</div><div class="step-execution-instruction">${escapeHtml(step.executionInstruction)}</div>`
          : `<div class="step-execution-label">${escapeHtml(plane)} · 实际命令</div>`
        details.innerHTML = instruction + `<pre>${escapeHtml(JSON.stringify({ tool: step.tool, arguments: step.arguments || {}, locator: step.locator || undefined, expectation: step.expectation || undefined, when: step.when || undefined }, null, 2))}</pre>`
      }
      node.appendChild(details)
    })
  }

  function runFlow(id) {
    const item = cardsById.get(id)
    if (!item) return
    const flowName = String(item.definition?.name || id).trim() || id
    window.parent.postMessage({
      type: 'dsh-patrol:run-flow',
      inspectionId: id,
      flowName,
    }, location.origin)
  }

  function showFlowJson(id) {
    const item = cardsById.get(id)
    if (!item) return
    document.getElementById('patrol-flow-json-modal')?.remove()
    const modal = document.createElement('div')
    modal.id = 'patrol-flow-json-modal'
    modal.className = 'flow-json-modal-bg'
    modal.innerHTML = `<div class="flow-json-modal" role="dialog" aria-modal="true" aria-label="流程 JSON">
      <div class="flow-json-head"><div><b>流程 JSON</b><div class="tiny muted">${escapeHtml(item.definition?.name || id)} · ${escapeHtml(id)}</div></div><div class="flow-json-actions"><button class="btn" data-manage-action="copy-json">复制 JSON</button><button class="btn" data-manage-action="close-json">关闭</button></div></div>
      <pre id="patrol-flow-json-code" class="flow-json-code">${escapeHtml(JSON.stringify(item.definition, null, 2))}</pre>
    </div>`
    document.body.appendChild(modal)
  }

  async function copyFlowJson() {
    const code = document.getElementById('patrol-flow-json-code')
    const text = code?.textContent || ''
    if (!text) return
    try {
      await navigator.clipboard.writeText(text)
    } catch {
      const area = document.createElement('textarea')
      area.value = text
      area.style.position = 'fixed'
      area.style.opacity = '0'
      document.body.appendChild(area)
      area.select()
      document.execCommand('copy')
      area.remove()
    }
  }

  async function renameFlow(id) {
    const item = cardsById.get(id)
    if (!item) return
    const current = item.definition?.name || id
    const value = window.prompt('编辑流程名称（稳定流程 ID 保持不变，以保证引用关系不损坏；工作区会同步生成以新名称命名的 .flow.md 文件）', current)
    if (value === null) return
    const name = value.trim()
    if (!name || name === current) return
    const result = await postAction('/flow/rename', { inspectionId: id, name })
    if (result.workspaceFlowFile) window.alert(`流程已改名并写入真实 Runbook。\n工作区流程文件：${result.workspaceFlowFile}`)
    location.reload()
  }

  async function optimizeFlow(id) {
    const item = cardsById.get(id)
    if (!item) return
    const count = Array.isArray(item.definition?.steps) ? item.definition.steps.length : 0
    const message = [
      '这是“清理教学试错步骤”，不是删除流程。',
      '',
      '会自动清理：snapshot/count/read/wait 诊断探针、自动生成执行说明保护下的无效步骤、重新回到同一页面前已废弃的猜 URL/试错轮次、同一输入框被后续值覆盖的重复输入。',
      '会保留：与任务清单语义对应的真实业务导航/点击/输入/滚动/刷新、人工检查点、条件依赖、成功断言，以及最终截图/页面产物。',
      '若候选清理会让任何原本已覆盖的任务清单项丢失，本次清理会整体取消，原 Runbook 不写回。',
      '',
      '新教学流程在对话结束时还会由 patrol_finalize_flow 根据“真正成功路径 + 任务清单逐项覆盖”做语义精简；这里用于清理已有旧流程和异常中断留下的教学垃圾。',
      '只有业务覆盖不退化时才会更新真实 Runbook 和工作区流程文件。',
      `当前流程共 ${count} 个步骤。是否继续清理？`,
    ].join('\n')
    if (!window.confirm(message)) return
    const result = await postAction('/flow/optimize', { inspectionId: id })
    window.alert(`清理完成：${result.originalSteps} → ${result.finalSteps} 个步骤，移除 ${result.removedSteps} 个教学试错/探针步骤。`)
    location.reload()
  }

  async function deleteFlow(id) {
    const item = cardsById.get(id)
    if (!item) return
    const name = item.definition?.name || id
    const message = [
      `确定彻底删除流程“${name}”吗？`,
      '',
      '这是物理删除，不是从界面隐藏：',
      '• 删除内部流程定义和 pending 状态',
      '• 删除该流程全部内部巡检历史',
      '• 删除工作区 patrol-results/<flow-id>/ 整个目录（Runbook、教学产物、历史报告和截图）',
      '',
      '删除后无法从“流程管理”或“巡检记录”恢复。',
    ].join('\n')
    if (!window.confirm(message)) return
    await postAction('/flow/delete', { inspectionId: id, confirmed: true, deleteHistory: true })
    location.reload()
  }

  async function postAction(path, payload) {
    try {
      return await request(path, {
        method: 'POST',
        body: JSON.stringify({ workspace: WORKSPACE, ...payload }),
      })
    } catch (error) {
      window.alert(error instanceof Error ? error.message : String(error))
      throw error
    }
  }

  function escapeAttr(value) {
    return String(value).replace(/[&<>"']/g, char => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    })[char])
  }

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, char => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    })[char])
  }

  function installStyle() {
    if (document.getElementById('patrol-flow-management-style')) return
    const style = document.createElement('style')
    style.id = 'patrol-flow-management-style'
    style.textContent = `
      .flow-manage-actions{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;margin:2px 0 10px;position:relative;z-index:2}
      .mini-btn{border:1px solid #e5e9f0;background:#fff;border-radius:8px;padding:5px 7px;font-size:11px;color:#475467;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;white-space:nowrap}
      .mini-btn:hover{border-color:#b9c6da;background:#f8fafc}
      .flow-manage-actions .mini-btn.run{grid-column:1/-1;margin-left:0;width:100%}.mini-btn.run,.run-btn{color:#1d4ed8!important;border-color:#bfd0f6!important;background:#f7faff!important}
      .mini-btn.run:hover,.run-btn:hover{background:#eff6ff!important;border-color:#93b4ef!important}
      .mini-btn.danger,.danger-btn{color:#c43225!important;border-color:#f0c7c3!important}
      .mini-btn.danger:hover,.danger-btn:hover{background:#fef3f2!important}
      .detail-flow-actions{display:inline-flex;gap:8px;flex-wrap:wrap}
      .step-execution{margin-top:10px;border-top:1px dashed #e5e9f0;padding-top:9px;font-size:11px;color:#667085}
      .step-execution-label{font-weight:700;color:#475467;margin-bottom:5px}
      .step-execution pre{margin:0;padding:8px 10px;background:#f8fafc;border-radius:8px;white-space:pre-wrap;word-break:break-word;font:11px/1.55 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;color:#344054}
      .flow-json-modal-bg{position:fixed;inset:0;background:rgba(15,23,42,.56);display:grid;place-items:center;padding:24px;z-index:1000}
      .flow-json-modal{width:min(1100px,96vw);max-height:92vh;display:flex;flex-direction:column;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 25px 80px rgba(15,23,42,.28)}
      .flow-json-head{display:flex;justify-content:space-between;gap:16px;align-items:center;padding:14px 16px;border-bottom:1px solid #e5e9f0}
      .flow-json-actions{display:flex;gap:8px}.flow-json-code{margin:0;padding:16px;overflow:auto;background:#0f172a;color:#dbeafe;white-space:pre;font:12px/1.6 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
    `
    document.head.appendChild(style)
  }

  document.addEventListener('click', event => {
    const target = event.target instanceof Element ? event.target.closest('[data-manage-action]') : null
    if (!target) {
      if (event.target instanceof Element && event.target.id === 'patrol-flow-json-modal') event.target.remove()
      return
    }
    event.preventDefault()
    event.stopPropagation()
    if (typeof event.stopImmediatePropagation === 'function') event.stopImmediatePropagation()
    const action = target.getAttribute('data-manage-action') || ''
    if (action === 'close-json') {
      document.getElementById('patrol-flow-json-modal')?.remove()
      return
    }
    if (action === 'copy-json') {
      void copyFlowJson()
      return
    }
    const id = target.getAttribute('data-manage-id') || ''
    if (!id) return
    if (action === 'run') runFlow(id)
    else if (action === 'json') showFlowJson(id)
    else if (action === 'rename') void renameFlow(id)
    else if (action === 'optimize') void optimizeFlow(id)
    else if (action === 'delete') void deleteFlow(id)
  }, true)

  const observer = new MutationObserver(schedulePatch)
  observer.observe(root, { childList: true, subtree: true })
  installStyle()
  void loadCatalog()
})()
