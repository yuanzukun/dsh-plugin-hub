import { Context } from '@deepseek-ai/cordis'
import { describe, expect, it, vi } from 'vitest'
import {
  PATROL_QWEN_HARDENED_COMPACT_LIMIT,
  PATROL_QWEN_HARDENED_PRUNE_LIMIT,
  PATROL_QWEN_NO_METER_COMPACT_STEP,
  isContextLengthExceededFailure,
  registerPatrolContextPressureGuard,
} from '../src/context-pressure-hardening.js'

const QWEN_ROUTE = { provider: 'cliproxy', model: 'qwen3.5_122b_a10b_fp4' }

function agent() {
  const session = {
    requestHeader: () => ({ config: QWEN_ROUTE }),
    surface: { replaceGeneration: 0 },
  }
  return { session, options: QWEN_ROUTE }
}

function payload(value: ReturnType<typeof agent>, step: number, turn = 1) {
  return {
    agent: value,
    messages: [],
    turn,
    step,
    signal: new AbortController().signal,
  }
}

describe('mounted Patrol local-Qwen hardening', () => {
  it('keeps materially more headroom than the previous 16k dispatch threshold', () => {
    expect(PATROL_QWEN_HARDENED_PRUNE_LIMIT).toBeLessThanOrEqual(6_000)
    expect(PATROL_QWEN_HARDENED_COMPACT_LIMIT).toBeLessThanOrEqual(10_000)
  })

  it('forces compaction by model-step count when tokenMeter is unavailable', async () => {
    const ctx = new Context()
    const current = agent()
    const pruneSession = vi.fn(() => {
      current.session.surface.replaceGeneration += 1
      return { pruned: [{ callId: 'old-observe' }], charsRemoved: 12_000 }
    })
    const compactIfNeeded = vi.fn(async () => {
      current.session.surface.replaceGeneration += 1
      return { shadowedSeqs: [1] }
    })
    ctx.provide('toolResultPruner', { pruneSession })
    ctx.provide('compaction', { compactIfNeeded })
    registerPatrolContextPressureGuard(ctx)

    await ctx.waterfall(
      'agent/pre-step',
      payload(current, PATROL_QWEN_NO_METER_COMPACT_STEP) as never,
      async () => ({ kind: 'enter' as const, messages: [] }),
    )

    expect(pruneSession).toHaveBeenCalledOnce()
    expect(compactIfNeeded).toHaveBeenCalledOnce()
    expect(compactIfNeeded).toHaveBeenCalledWith(current, 'context-overflow', expect.any(AbortSignal))
    await ctx.fiber.dispose()
  })

  it('carries the no-meter fallback counter across Harness turns', async () => {
    const ctx = new Context()
    const current = agent()
    const pruneSession = vi.fn(() => ({ pruned: [], charsRemoved: 0 }))
    const compactIfNeeded = vi.fn(async () => null)
    ctx.provide('toolResultPruner', { pruneSession })
    ctx.provide('compaction', { compactIfNeeded })
    registerPatrolContextPressureGuard(ctx)

    for (let turn = 1; turn <= PATROL_QWEN_NO_METER_COMPACT_STEP; turn += 1) {
      await ctx.waterfall(
        'agent/pre-step',
        payload(current, 1, turn) as never,
        async () => ({ kind: 'enter' as const, messages: [] }),
      )
    }

    expect(compactIfNeeded).toHaveBeenCalledOnce()
    await ctx.fiber.dispose()
  })

  it('still prunes and compacts by cumulative step cadence when tokenMeter under-counts image-heavy patrol pressure', async () => {
    const ctx = new Context()
    const current = agent()
    const pruneSession = vi.fn(() => {
      current.session.surface.replaceGeneration += 1
      return { pruned: [{ callId: 'old-visual-observe' }], charsRemoved: 16_000 }
    })
    const compactIfNeeded = vi.fn(async () => {
      current.session.surface.replaceGeneration += 1
      return { shadowedSeqs: [1] }
    })
    ctx.provide('tokenMeter', { measure: () => ({ totalTokens: 1_500 }) })
    ctx.provide('toolResultPruner', { pruneSession })
    ctx.provide('compaction', { compactIfNeeded })
    registerPatrolContextPressureGuard(ctx)

    for (let turn = 1; turn <= PATROL_QWEN_NO_METER_COMPACT_STEP; turn += 1) {
      await ctx.waterfall(
        'agent/pre-step',
        payload(current, 1, turn) as never,
        async () => ({ kind: 'enter' as const, messages: [] }),
      )
    }

    expect(pruneSession).toHaveBeenCalled()
    expect(compactIfNeeded).toHaveBeenCalledOnce()
    await ctx.fiber.dispose()
  })

  it('prunes at 6k and avoids compaction when measurement proves pruning made enough room', async () => {
    const ctx = new Context()
    const current = agent()
    const measure = vi.fn()
      .mockReturnValueOnce({ totalTokens: PATROL_QWEN_HARDENED_PRUNE_LIMIT + 500 })
      .mockReturnValueOnce({ totalTokens: PATROL_QWEN_HARDENED_PRUNE_LIMIT - 1_000 })
    const pruneSession = vi.fn(() => {
      current.session.surface.replaceGeneration += 1
      return { pruned: [{ callId: 'large-snapshot' }], charsRemoved: 8_000 }
    })
    const compactIfNeeded = vi.fn(async () => null)
    ctx.provide('tokenMeter', { measure })
    ctx.provide('toolResultPruner', { pruneSession })
    ctx.provide('compaction', { compactIfNeeded })
    registerPatrolContextPressureGuard(ctx)

    await ctx.waterfall(
      'agent/pre-step',
      payload(current, 2) as never,
      async () => ({ kind: 'enter' as const, messages: [] }),
    )

    expect(pruneSession).toHaveBeenCalledOnce()
    expect(compactIfNeeded).not.toHaveBeenCalled()
    await ctx.fiber.dispose()
  })
  it('retries auth_unavailable once even when proactive pruning already left nothing else to remove', async () => {
    vi.useFakeTimers()
    try {
      const ctx = new Context()
      const current = agent()
      const pruneSession = vi.fn(() => ({ pruned: [], charsRemoved: 0 }))
      const compactIfNeeded = vi.fn(async () => null)
      ctx.provide('tokenMeter', { measure: () => ({ totalTokens: 1_500 }) })
      ctx.provide('toolResultPruner', { pruneSession })
      ctx.provide('compaction', { compactIfNeeded })
      registerPatrolContextPressureGuard(ctx)

      await ctx.waterfall(
        'agent/pre-step',
        payload(current, 1, 1) as never,
        async () => ({ kind: 'enter' as const, messages: [] }),
      )

      const failure = {
        code: 'internal_server_error',
        message: '503: auth_unavailable: no auth available (providers=qwen-local, model=qwen3.5_122b_a10b_fp4)',
      }
      const requestError = ctx.waterfall(
        'agent/request-error',
        {
          agent: current,
          turn: 1,
          step: 1,
          provider: 'cliproxy',
          failure,
          signal: new AbortController().signal,
        } as never,
        async () => ({ kind: 'throw' as const }),
      )
      await vi.runAllTimersAsync()
      const result = await requestError

      expect(result).toMatchObject({ kind: 'retry' })
      expect(pruneSession).toHaveBeenCalled()
      expect(compactIfNeeded).not.toHaveBeenCalled()
      expect(failure.message).toContain('[DSH Patrol diagnostic]')
      expect(failure.message).toContain('auth_unavailable')
      await ctx.fiber.dispose()
    } finally {
      vi.useRealTimers()
    }
  })


  it('bounds repeated auth_unavailable recovery to four model-free retries with no compaction summary call', async () => {
    vi.useFakeTimers()
    try {
      const ctx = new Context()
      const current = agent()
      const pruneSession = vi.fn(() => ({ pruned: [], charsRemoved: 0 }))
      const compactIfNeeded = vi.fn(async () => null)
      ctx.provide('tokenMeter', { measure: () => ({ totalTokens: 1_500 }) })
      ctx.provide('toolResultPruner', { pruneSession })
      ctx.provide('compaction', { compactIfNeeded })
      registerPatrolContextPressureGuard(ctx)

      await ctx.waterfall(
        'agent/pre-step',
        payload(current, 1, 1) as never,
        async () => ({ kind: 'enter' as const, messages: [] }),
      )

      const failure = {
        code: 'internal_server_error',
        message: '503: auth_unavailable: no auth available (providers=qwen-local, model=qwen3.5_122b_a10b_fp4)',
      }
      for (let attempt = 1; attempt <= 4; attempt += 1) {
        const pending = ctx.waterfall(
          'agent/request-error',
          {
            agent: current, turn: 1, step: 1, provider: 'cliproxy', failure,
            signal: new AbortController().signal,
          } as never,
          async () => ({ kind: 'throw' as const }),
        )
        await vi.runAllTimersAsync()
        await expect(pending).resolves.toMatchObject({ kind: 'retry' })
      }

      const downstreamRetry = vi.fn(async () => ({ kind: 'retry' as const }))
      const exhausted = await ctx.waterfall(
        'agent/request-error',
        {
          agent: current, turn: 1, step: 1, provider: 'cliproxy', failure,
          signal: new AbortController().signal,
        } as never,
        downstreamRetry,
      )
      expect(exhausted).toBeUndefined()
      expect(downstreamRetry).not.toHaveBeenCalled()
      expect(compactIfNeeded).not.toHaveBeenCalled()
      await ctx.fiber.dispose()
    } finally {
      vi.useRealTimers()
    }
  })


  it('drops the newest retained Patrol image after CUDA OOM and retries the failed model request without it', async () => {
    vi.useFakeTimers()
    try {
      const ctx = new Context()
      const current = agent() as any
      const image = { type: 'image', attachment: { attachmentId: 'current-visual' }, offloaded: false }
      const event = {
        type: 'tool/result',
        message: { role: 'user', content: [{ type: 'tool-result', content: [image] }] },
      }
      current.session.surface.nodes = [1]
      current.session.eventAt = (seq: number) => seq === 1 ? event : undefined
      current.session.deriveEventMessage = (value: any) => value.message
      current.session.append = (type: string, data: any) => {
        if (type !== 'image/offload') throw new Error(`unexpected event ${type}`)
        for (const target of data.targets) {
          if (target.seq === 1 && target.imageIndexes.includes(0)) image.offloaded = true
        }
        current.session.surface.replaceGeneration += 1
        return { seq: 2 }
      }

      const pruneSession = vi.fn(() => ({ pruned: [], charsRemoved: 0 }))
      ctx.provide('tokenMeter', { measure: () => ({ totalTokens: 1_500 }) })
      ctx.provide('toolResultPruner', { pruneSession })
      registerPatrolContextPressureGuard(ctx)

      await ctx.waterfall(
        'agent/pre-step',
        payload(current, 1, 1) as never,
        async () => ({ kind: 'enter' as const, messages: [] }),
      )

      // The pre-step intentionally retains the newest CURRENT visual.
      expect(image.offloaded).toBe(false)

      const failure = {
        code: 'internal_server_error',
        message: '500: CUDA out of memory. Tried to allocate 672.00 MiB.',
      }
      const pending = ctx.waterfall(
        'agent/request-error',
        {
          agent: current, turn: 1, step: 1, provider: 'cliproxy', failure,
          signal: new AbortController().signal,
        } as never,
        async () => undefined,
      )
      await vi.runAllTimersAsync()
      const result = await pending

      expect(image.offloaded).toBe(true)
      expect(result).toMatchObject({ kind: 'retry' })
      expect(failure.message).toContain('CUDA/GPU OOM')
      await ctx.fiber.dispose()
    } finally {
      vi.useRealTimers()
    }
  })

  it('recognizes the exact upstream 262144 context-length failure reported by long Patrol sessions', () => {
    expect(isContextLengthExceededFailure({
      code: 'bad_response_status_code',
      status: 400,
      message: 'Requested token count exceeds the model\'s maximum context length of 262144 tokens. You requested a total of 262534 tokens: 229766 tokens from the input messages and 32768 tokens for the completion.',
    })).toBe(true)
  })

  it('prunes and retries only the failed model request after deterministic context overflow', async () => {
    const ctx = new Context()
    const current = agent()
    const pruneSession = vi.fn(() => {
      current.session.surface.replaceGeneration += 1
      return { pruned: [{ callId: 'old-observe' }], charsRemoved: 24_000 }
    })
    const compactIfNeeded = vi.fn(async () => null)
    ctx.provide('tokenMeter', { measure: () => ({ totalTokens: 220_000 }) })
    ctx.provide('toolResultPruner', { pruneSession })
    ctx.provide('compaction', { compactIfNeeded })
    registerPatrolContextPressureGuard(ctx)

    await ctx.waterfall(
      'agent/pre-step',
      payload(current, 9, 7) as never,
      async () => ({ kind: 'enter' as const, messages: [] }),
    )
    pruneSession.mockClear()
    compactIfNeeded.mockClear()

    const failure = {
      status: 400,
      code: 'bad_response_status_code',
      message: 'Requested token count exceeds the model\'s maximum context length of 262144 tokens. You requested a total of 262534 tokens: 229766 tokens from the input messages and 32768 tokens for the completion.',
    }
    const downstream = vi.fn(async () => ({ kind: 'throw' as const }))
    const result = await ctx.waterfall(
      'agent/request-error',
      {
        agent: current,
        turn: 7,
        step: 9,
        provider: 'cliproxy',
        failure,
        signal: new AbortController().signal,
      } as never,
      downstream,
    )

    expect(result).toMatchObject({ kind: 'retry' })
    expect(pruneSession).toHaveBeenCalled()
    expect(compactIfNeeded).toHaveBeenCalledWith(current, 'context-overflow', expect.any(AbortSignal))
    expect(downstream).not.toHaveBeenCalled()
    expect(failure.message).toContain('[DSH Patrol context recovery]')
    expect(failure.message).toContain('不会重放已成功的点击/输入')

    const second = await ctx.waterfall(
      'agent/request-error',
      {
        agent: current,
        turn: 7,
        step: 9,
        provider: 'cliproxy',
        failure: {
          status: 400,
          code: 'bad_response_status_code',
          message: 'Requested token count exceeds the model\'s maximum context length of 262144 tokens.',
        },
        signal: new AbortController().signal,
      } as never,
      downstream,
    )
    expect(second).toBeUndefined()
    expect(downstream).not.toHaveBeenCalled()
    await ctx.fiber.dispose()
  })

  it('does not delegate a raw CUDA OOM to generic retries when no model-free reduction occurred', async () => {
    const ctx = new Context()
    const current = agent()
    const pruneSession = vi.fn(() => ({ pruned: [], charsRemoved: 0 }))
    ctx.provide('tokenMeter', { measure: () => ({ totalTokens: 1_500 }) })
    ctx.provide('toolResultPruner', { pruneSession })
    registerPatrolContextPressureGuard(ctx)

    await ctx.waterfall(
      'agent/pre-step',
      payload(current, 1, 1) as never,
      async () => ({ kind: 'enter' as const, messages: [] }),
    )

    const failure = {
      code: 'internal_server_error',
      message: 'CUDA out of memory while allocating tensor',
    }
    const downstreamRetry = vi.fn(async () => ({ kind: 'retry' as const }))
    const result = await ctx.waterfall(
      'agent/request-error',
      {
        agent: current, turn: 1, step: 1, provider: 'cliproxy', failure,
        signal: new AbortController().signal,
      } as never,
      downstreamRetry,
    )

    expect(result).toBeUndefined()
    expect(downstreamRetry).not.toHaveBeenCalled()
    expect(pruneSession).toHaveBeenCalled()
    expect(failure.message).toContain('CUDA/GPU OOM')
    await ctx.fiber.dispose()
  })

})
