import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import vm from 'node:vm'
import { describe, expect, it } from 'vitest'

const source = readFileSync(join(process.cwd(), 'browser-extension', 'content.js'), 'utf8')

class FakeElement {
  nodeType = 1
  id = ''
  className = ''
  parentElement: FakeElement | null = null
  children: FakeElement[] = []
  textContent = ''
  innerText = ''
  style = { display: 'block', visibility: 'visible', opacity: '1', cursor: 'default' }
  attributes = new Map<string, string>()

  constructor(public tagName: string, public bounds = rect(0, 0, 100, 24)) {}

  getBoundingClientRect() { return this.bounds }
  getAttribute(name: string) { return this.attributes.get(name) ?? null }
  querySelectorAll() { return this.children }
  matches(selector: string) {
    if (selector.includes('[onclick]') && this.attributes.has('onclick')) return true
    return selector.split(',').map(item => item.trim()).includes(this.tagName.toLowerCase())
  }
}

function rect(left: number, top: number, width: number, height: number) {
  return { left, top, width, height, right: left + width, bottom: top + height }
}

function setup(elements: FakeElement[]) {
  const body = new FakeElement('BODY', rect(0, 0, 1280, 720))
  body.children = elements
  for (const element of elements) element.parentElement = body
  const document = {
    body,
    documentElement: body,
    querySelector() { return body },
    querySelectorAll(selector: string) {
      if (selector.includes('div') || selector.includes('span')) return elements
      return []
    },
  }
  const context = vm.createContext({
    chrome: { runtime: { onMessage: { addListener() {} } } },
    document,
    location: { href: 'https://example.test' },
    window: { innerWidth: 1280, innerHeight: 720 },
    Element: FakeElement,
    HTMLInputElement: class {},
    HTMLAnchorElement: class {},
    getComputedStyle: (element: FakeElement) => element.style,
    CSS: { escape: (value: string) => value },
    Node: { ELEMENT_NODE: 1 },
    Promise,
    Math,
    Number,
    String,
    Array,
    Object,
    RegExp,
    Error,
    Set,
    Map,
  })
  vm.runInContext(source, context)
  return context
}

describe('browser content snapshot', () => {
  it('does not invent button roles for custom clickable spans and supports unique title selectors', () => {
    const source = readFileSync(join(process.cwd(), 'browser-extension', 'content.js'), 'utf8')
    expect(source).not.toContain("if (isLikelyClickable(element)) return 'button'")
    expect(source).toContain("const title = element.getAttribute('title')")
    expect(source).toContain('[title="')
  })


  it('surfaces Ant table action text carried by a title even when the span itself has no pointer cursor', () => {
    const rdp = new FakeElement('SPAN', rect(990, 420, 180, 32))
    rdp.className = 'act_margin_left'
    rdp.attributes.set('title', '[RDP] [EMPTY]')

    const context = setup([rdp])
    const value = JSON.parse(JSON.stringify(vm.runInContext('snapshot({ maxElements: 20 })', context)))

    expect(value.elements).toContainEqual(expect.objectContaining({
      tag: 'span',
      text: '[RDP] [EMPTY]',
    }))
  })

  it('prioritizes a real visible link over generic cursor containers when the snapshot budget is tight', () => {
    const generic = new FakeElement('DIV', rect(0, 0, 1280, 280))
    generic.textContent = '顶部活动广告'
    generic.innerText = '顶部活动广告'
    generic.style.cursor = 'pointer'

    const video = new FakeElement('A', rect(160, 320, 360, 210))
    video.textContent = '我们无法找到外星文明的原因'
    video.innerText = '我们无法找到外星文明的原因'
    video.attributes.set('href', '/video/BV-test')

    const context = setup([generic, video])
    const value = JSON.parse(JSON.stringify(vm.runInContext('snapshot({ maxElements: 1 })', context)))

    expect(value.elements).toHaveLength(1)
    expect(value.elements[0]).toMatchObject({
      tag: 'a',
      role: 'link',
      text: '我们无法找到外星文明的原因',
    })
  })

  it('traverses open shadow roots instead of limiting CURRENT evidence to document.querySelectorAll', () => {
    expect(source).toContain('function deepQueryAll(root, selector)')
    expect(source).toContain('element?.shadowRoot')
    expect(source).toContain('snapshotCandidatePriority')
  })

  it('excludes off-viewport duplicate navigation targets from the current snapshot', () => {
    const desktop = new FakeElement('DIV', rect(240, 16, 96, 32))
    desktop.textContent = '我的工作台'
    desktop.innerText = '我的工作台'
    desktop.style.cursor = 'pointer'

    const collapsed = new FakeElement('DIV', rect(-10000, 16, 96, 32))
    collapsed.textContent = '我的工作台'
    collapsed.innerText = '我的工作台'
    collapsed.style.cursor = 'pointer'

    const context = setup([desktop, collapsed])
    const value = JSON.parse(JSON.stringify(vm.runInContext('snapshot({ maxElements: 20 })', context)))

    expect(value.elements).toHaveLength(1)
    expect(value.elements[0]).toMatchObject({ text: '我的工作台' })
  })
})
