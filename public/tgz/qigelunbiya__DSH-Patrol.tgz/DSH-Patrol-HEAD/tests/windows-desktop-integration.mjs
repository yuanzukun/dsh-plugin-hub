import { spawn } from 'node:child_process'
import { access } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { WindowsDesktopDriver } from '../desktop-runtime/windows-driver.js'

if (process.platform !== 'win32') {
  console.log('windows-desktop-integration: skipped (non-Windows)')
  process.exit(0)
}

const TITLE = 'DSH Patrol Desktop Smoke'
const TEXT = 'DSH Patrol UIA integration'
const HOTKEY_TEXT = 'window-targeted input'
const PASTE_SUFFIX = ' + paste'
const fixture = fileURLToPath(new URL('./windows-desktop-fixture.ps1', import.meta.url))
const powershell = process.env.DSH_PATROL_POWERSHELL || 'powershell.exe'
const child = spawn(powershell, [
  '-NoProfile',
  '-STA',
  '-ExecutionPolicy', 'Bypass',
  '-File', fixture,
  '-Title', TITLE,
], {
  windowsHide: false,
  stdio: ['ignore', 'pipe', 'pipe'],
})

let stderr = ''
child.stderr.on('data', chunk => { stderr += String(chunk) })

const driver = new WindowsDesktopDriver({ commandTimeoutMs: 20000, powerShell: powershell })

try {
  const snapshot = await waitForSnapshot(driver, child.pid, 15000)
  const window = snapshot.window
  console.log(`fixture window: ${window?.processName ?? 'unknown'} / pid=${child.pid}`)
  const input = snapshot.elements.find(element =>
    element.automationId === 'SmokeInput'
    || element.name === 'Smoke Input'
    || (element.controlType === 'Edit' && element.className))
  if (!input) {
    throw new Error(`fixture input not present in UIA snapshot: ${JSON.stringify(snapshot.elements.slice(0, 20))}`)
  }
  if (input.isPassword !== false) {
    throw new Error(`fixture input should be non-password: ${JSON.stringify(input)}`)
  }

  const selector = input.automationId
    ? { automationId: input.automationId }
    : input.name
      ? { name: input.name }
      : { controlType: input.controlType, className: input.className }

  const typed = await driver.run('type-target', {
    processId: child.pid,
    ...selector,
    text: TEXT,
    clear: true,
  })
  if (!typed.ok || typed.chars !== TEXT.length) {
    throw new Error(`type-target did not report expected result: ${JSON.stringify(typed)}`)
  }

  const ready = await driver.waitForTarget({
    source: 'uia',
    processId: child.pid,
    ...selector,
    value: TEXT,
    match: 'exact',
    requireUnique: true,
    timeoutMs: 5000,
    pollMs: 200,
  })
  if (ready.method !== 'uia' || ready.matchCount !== 1) {
    throw new Error(`value-aware semantic wait failed: ${JSON.stringify(ready)}`)
  }

  const selected = await driver.run('hotkey', {
    processId: child.pid,
    combo: 'Ctrl+A',
  })
  if (selected.window?.title !== TITLE) {
    throw new Error(`targeted hotkey did not activate fixture window: ${JSON.stringify(selected)}`)
  }

  const relativeTyped = await driver.run('type-text', {
    processId: child.pid,
    text: HOTKEY_TEXT,
    clear: false,
  })
  if (relativeTyped.window?.title !== TITLE || relativeTyped.chars !== HOTKEY_TEXT.length) {
    throw new Error(`targeted type-text did not report fixture window: ${JSON.stringify(relativeTyped)}`)
  }
  await driver.waitForTarget({
    source: 'uia',
    processId: child.pid,
    ...selector,
    value: HOTKEY_TEXT,
    match: 'exact',
    requireUnique: true,
    timeoutMs: 5000,
    pollMs: 200,
  })

  await driver.run('set-clipboard-text', { text: PASTE_SUFFIX })
  const pasted = await driver.run('paste-target', { processId: child.pid, ...selector })
  if (pasted.window?.title !== TITLE || !pasted.focusMethod) {
    throw new Error(`atomic target paste did not focus fixture input: ${JSON.stringify(pasted)}`)
  }
  const pastedText = `${HOTKEY_TEXT}${PASTE_SUFFIX}`
  await driver.waitForTarget({
    source: 'uia',
    processId: child.pid,
    ...selector,
    value: pastedText,
    match: 'exact',
    requireUnique: true,
    timeoutMs: 5000,
    pollMs: 200,
  })

  const pressed = await driver.run('press-target', { processId: child.pid, ...selector, key: 'Enter' })
  if (pressed.window?.title !== TITLE || !pressed.focusMethod) {
    throw new Error(`atomic target key press did not focus fixture input: ${JSON.stringify(pressed)}`)
  }
  await driver.waitForTarget({
    source: 'uia',
    processId: child.pid,
    name: `applied:${pastedText}`,
    match: 'exact',
    requireUnique: true,
    timeoutMs: 5000,
    pollMs: 200,
  })

  await driver.run('type-target', {
    processId: child.pid,
    ...selector,
    text: TEXT,
    clear: true,
  })

  const clicked = await driver.run('click-target', {
    processId: child.pid,
    name: 'Apply Smoke',
  })
  if (!clicked.ok) throw new Error(`click-target failed: ${JSON.stringify(clicked)}`)

  const applied = await driver.waitForTarget({
    source: 'uia',
    processId: child.pid,
    name: `applied:${TEXT}`,
    match: 'exact',
    requireUnique: true,
    timeoutMs: 5000,
    pollMs: 200,
  })
  if (applied.method !== 'uia' || applied.matchCount !== 1) {
    throw new Error(`post-click UIA state wait failed: ${JSON.stringify(applied)}`)
  }

  const shot = await driver.screenshot({ processId: child.pid, fileName: 'windows-uia-integration' })
  await access(shot.path)
  if (!(shot.width > 0 && shot.height > 0)) {
    throw new Error(`desktop screenshot returned invalid bounds: ${JSON.stringify(shot)}`)
  }

  const ocr = await driver.ocr({
    processId: child.pid,
    languages: ['en-US'],
    fileName: 'windows-ocr-integration',
  })
  if (ocr.status !== 'recognized' || !Array.isArray(ocr.lines) || ocr.lines.length === 0) {
    throw new Error(`desktop OCR did not recognize fixture text: ${JSON.stringify(ocr)}`)
  }
  const recognizable = ocr.lines.find(line => /apply|smoke input|dsh patrol/i.test(String(line.text ?? '')))
  if (!recognizable
    || !Number.isFinite(recognizable.center?.x)
    || !Number.isFinite(recognizable.center?.y)
    || !(recognizable.rect?.width > 0)
    || !(recognizable.rect?.height > 0)) {
    throw new Error(`desktop OCR did not return usable line geometry: ${JSON.stringify(ocr.lines.slice(0, 20))}`)
  }

  console.log(JSON.stringify({
    ok: true,
    selector,
    typedChars: typed.chars,
    semanticWait: ready.method,
    clickMethod: clicked.method,
    postClickWait: applied.method,
    targetedKeyboard: {
      hotkeyWindow: selected.window?.title,
      typeTextWindow: relativeTyped.window?.title,
      pasteTargetWindow: pasted.window?.title,
      pasteTargetFocus: pasted.focusMethod,
      pressTargetWindow: pressed.window?.title,
      pressTargetFocus: pressed.focusMethod,
    },
    screenshot: { width: shot.width, height: shot.height },
    ocr: {
      status: ocr.status,
      languagesSucceeded: ocr.languagesSucceeded,
      matchedText: recognizable.text,
      center: recognizable.center,
    },
  }, null, 2))
} finally {
  if (!child.killed) child.kill()
  await Promise.race([
    new Promise(resolve => child.once('exit', resolve)),
    new Promise(resolve => setTimeout(resolve, 1500)),
  ])
  if (child.exitCode === null && !child.killed) child.kill('SIGKILL')
  if (stderr.trim()) console.error(stderr.trim())
}

async function waitForSnapshot(driver, processId, timeoutMs) {
  const started = Date.now()
  let lastError = ''
  while (Date.now() - started < timeoutMs) {
    try {
      const snapshot = await driver.run('snapshot', { processId, maxElements: 200 })
      if (snapshot?.ok && snapshot?.window?.hwnd) return snapshot
      lastError = `snapshot did not expose hwnd: ${JSON.stringify(snapshot?.window ?? {})}`
    } catch (error) {
      lastError = error instanceof Error ? error.message : String(error)
    }
    await new Promise(resolve => setTimeout(resolve, 250))
  }
  throw new Error(`fixture window did not become snapshot-ready for pid=${processId}; lastError=${lastError}`)
}
