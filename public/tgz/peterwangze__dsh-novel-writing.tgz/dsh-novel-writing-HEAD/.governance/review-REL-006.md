# 发布审查报告 — REL-006 v0.5.2（BUG-006 安装通道适配承载）

- **任务 ID**：REL-006（P1，v0.5.2 发布）
- **round**：**R1**（首轮；无前轮 review 报告，复审链起点）
- **审查时间**：2026-09-12（发布同日）
- **审查员**：Release Reviewer Agent（只读；除本报告两份落盘外未修改任何发布文档/代码）
- **绑定 SKILL**：`release-review`（`<plugin_root>/skills/release-review/SKILL.md`）
- **被审对象（SHA 三元组）**：
  | 对象 | SHA | 说明 |
  | --- | --- | --- |
  | 发布提交 | `e1f25df84ead0a4d07c655f9afcd379a8a96a2a8` | `REL-006: 发布 v0.5.2（BUG-006 安装通道适配承载）`，4 文件 **+198/−2** |
  | 补充提交 | `e093e72` | `REL-006: 补建 v0.5.2 发布工件（release-checklist / feature-flags / rollback-plan）`，4 文件 **+190/−3** |
  | tag 对象 | `7ca99d6d612d90aadeba83d4c7ad40ed61feafa4`（annotated `v0.5.2`） | peel → `e1f25df8…`；**未 push** |
  | 改动面 | `git diff --stat dd6b5ef..HEAD` = **7 文件 +385/−2** | REL-006 合计 |
- **审查输入**：`docs/review/REL-006-release-notes.md`（196 行）、`docs/release/release-checklist-0.5.2.md`（75 行）、`docs/release/rollback-plan-0.5.2.md`（79 行）、`docs/release/feature-flags-0.5.2.md`（28 行）、`CHANGELOG.md`（`[Unreleased]` / `[0.5.2]` 段）
- **结论**：**NEEDS_CHANGE**（硬门槛 5 项：**3 PASS / 2 FAIL**；findings 9 条 = P0×0 / P1×4 / P2×3 / P3×2）

---

## 0. 证据基准与不可复查项声明（P-01 事实驱动）

本报告事实来源分三类，逐条标注，**不以「流程看起来完整」替代发布事实**：

| 标记 | 含义 |
| --- | --- |
| 【文档】 | 本次实际读取的文件 + 行号（可复查） |
| 【C】 | Coordinator 实测提供（本 Reviewer 无 Bash 权限，**无法复跑**；按任务书内联事实引用） |
| 【待验证】 | 文档自述但本次无独立证据者——**不计入 PASS 依据** |

**审查员能力边界（如实声明）**：本次审查为**只读文档 + 内联事实交叉核对**，未执行任何命令、未跑门禁、未复算 diff。凡门禁结果均以【C】引用，未独立复现。

---

## 1. 五维度逐项结论

### 1.1 发布检查清单 — **PARTIAL**

**逐项核实**（清单 6 步骤 21 项，据 `release-checklist-0.5.2.md` §A~§F + `release-notes` §8）：

| 步骤 | 关键项 | 文档自述 | 审查裁定 | 证据 |
| --- | --- | --- | --- | --- |
| 一 发布准备 | 版本号已定义 | ✅ `0.5.2` | PASS | 清单 L15（worktree + `git show HEAD:package.json` 双读）【文档】；`CHANGELOG.md` L119 `## [0.5.2] - 2026-09-12`【文档】 |
| 一 | 变更范围已列出 | ✅ BUG-006 = `471ed00` + `3442f39` | PASS | 清单 L16；`CHANGELOG.md` L122【文档】；两提交在远端【C】 |
| 一 | 变更类型已标注 | ✅ 修复（PATCH） | PASS | 清单 L17 + `release-notes` §2 L35【文档】 |
| 一 | 发布时间窗口 | ✅ 2026-09-12 | PASS | 清单 L18（用户定案） |
| 二 变更日志 | CHANGELOG 覆盖全部变更 | ✅ 逐字移动 | PASS | 清单 L24；`CHANGELOG.md` L119-122【文档】；diff 为纯移动【C】 |
| 二 | breaking change 已高亮 | ✅ 无 breaking | PASS | 清单 L25；BUG-006 条目内「旧布局行为完全不变」【文档】 |
| 二 | 依赖变更已记录 | ✅ 无依赖变更 | PASS | 清单 L26；本版 `package.json` 仅版本行【C】 |
| 二 | 已知问题已列出 | ✅ | **PARTIAL** | 清单 L27 与 `release-notes` §8 L155 均引用「§7（R1~**R7**）」，而实际为 **R1~R8** ⇒ 引用陈旧（见 F8） |
| 三 回滚方案 | 已编写（具体步骤） | ✅ A/B/C 三路径 | PASS | `rollback-plan-0.5.2.md` L16-51【文档】 |
| 三 | **已验证（测试环境执行）** | ⚠️ **未执行** | **FAIL** | 清单 L36、`release-notes` §4.1 L77 / §6 L108、`rollback-plan` §6 L78【文档】——文档自述「**不主张已验证**」（诚实，但门槛未满足） |
| 三 | 数据兼容性 / 影响范围 | ✅ 不涉及 | PASS | `rollback-plan` §3 L53-61【文档】 |
| 四 发布后验证 | 核心功能验证清单 | ✅ | **PARTIAL** | 清单 L44 以「三件套 + 用户侧实机使用」为证；但本版**唯一交付面 = 安装通道**，而本次**未执行安装冒烟**（`release-notes` §4.1 L75 自述）⇒ 唯一交付面对**被发布树**无验证（见 F5） |
| 四 | 监控基线 / 告警 | N/A | N/A（核实诚实不适用） | 清单 L45-46；`release-notes` §4.1 L78 说明「插件无生产监控面」——**非伪造**；N/A 项不计 PASS 亦不计 FAIL |
| 五 数据验证 | 核心指标基线 / 观察期 | N/A / ✅替代口径 | N/A（同上，代以 `smoke` 282/0 不劣化）【C】 |
| 五 | 回滚触发条件 | ✅ | PASS | `rollback-plan` §1 L13-14【文档】 |
| 六 发布决策 | 可以发布 / 有条件 / 暂缓 | ⚠️ **有条件发布（Go — 本地）** | **PARTIAL** | 清单 §F L63：条件 = ①push 待授权 ②`check-release` 不可用已升级 |
| §G 门禁 | 语法 / 预设 / 冒烟 | ✅ 12/0、PASSED、282/0 | PASS | 清单 §G L69-71【文档】；与【C】两次执行同结果一致 |
| §G 门禁 | `check-release`（发布就绪） | ❌ **FAILED 21 issues（不可用）** | **FAIL** | 清单 §G L73 + `release-notes` §7 R5 L120-140【文档】；【C】一致。文档**未包装为 PASS**（合规） |

**维度裁定：PARTIAL** — 逐项均有证据出处（合规），但存在 2 项未执行/不可用 + 1 项证据面错位 + 1 项决策为「有条件」，**未达「全部 PASS = 100%」**。

### 1.2 回滚方案 — **PARTIAL**

| 检查面 | 裁定 | 证据 |
| --- | --- | --- |
| 步骤可执行（命令级、非泛化） | PASS | `rollback-plan` L20-51：A 路径 `git checkout v0.5.1` + 幂等 `install.ps1/sh`；B 路径 `checkout 3442f39`；C 路径 `tag -d` + `revert`/`reset`【文档】 |
| 影响面与数据兼容已评估 | PASS | `rollback-plan` §3 L53-60（数据面不涉及；书稿零影响；宿主配置幂等重建）【文档】 |
| 时间可接受 | PASS | §4 L64：**< 1 分钟**（无迁移、无服务端状态回置）【文档】 |
| 撤销语义正确 | PASS | §2 路径 C 明示「一旦 push 完成本路径失效，须走 revert + 新版本号，不得改写已发布历史」——口径正确【文档】 |
| 验证方式定义 | PASS | §5 L68-71：`rev-parse` + 三件套 + 安装面幂等 + 用户侧启动【文档】 |
| **已演练（至少一次）** | **FAIL** | §6 L78「已在测试环境**实际演练** ⚠️ **未执行** …… **不主张已验证**」；`release-notes` §4.1 L77 同【文档】 |

**维度裁定：PARTIAL** — 方案质量高（命令级、影响面清晰、时间可接受），但 Skills 硬门槛「回滚方案存在且**已验证**」**未满足**；文档对此**如实披露，无造假**。

### 1.3 CHANGELOG 质量 — **PASS**

| 检查面 | 裁定 | 证据 |
| --- | --- | --- |
| `[0.5.2]` 段存在且格式合规 | PASS | `CHANGELOG.md` **L119** `## [0.5.2] - 2026-09-12` + **L121** `### 修复` + **L122** 单条 BUG-006【文档】（Keep a Changelog；文件头 L3 声明遵循） |
| 用户视角完整 | PASS | L122 含用户可理解的症状链路（宿主布局重构 → 安装链不可用）+ 双通道适配 + 「旧布局行为完全不变」+ README 同步说明【文档】 |
| breaking change 显式标注 | PASS（无 breaking） | 版本为纯修复；本版**零产品代码改动**（`lib/**`/`test/**`/`install.*`/`README.md` 零改动【C】）⇒ breaking 面为空集；条目内已声明向后兼容【文档】 |
| 分层正确性（v0.5.2 不含 v0.6.0 线条目） | PASS | `[Unreleased]` = **L5-117**（`### 新增` L7 / `### 修复` L32，含 COMPAT-002~016 全部条目）；`[0.5.2]` = **L119-122** 恰 1 条且**无任何 COMPAT-*** 【文档】；程序化切段（`[0.5.2]` contains BUG-006=True ∧ COMPAT-=False；`[Unreleased]` COMPAT- 70 次 ∧ BUG-006=False）【C】一致 |
| 移动纯粹性 | PASS | diff 仅 4 行插入（段头 + `### 修复` + 2 空行），BUG-006 条目行**无 ± 变化**【C】 |
| 版本三方一致 | PASS | `CHANGELOG` 段头 `[0.5.2]`（L119）≡ `package.json` `"version": "0.5.2"`【C】≡ tag 名 `v0.5.2`【C】 |

**维度裁定：PASS** — 用户视角、分层、移动纯粹性、三方一致性均满足；无用户可见功能面 ⇒ 无迁移指南需求（无 breaking）。

### 1.4 Feature Flag — **PASS**（空集，不适用；取证充分）

| 检查面 | 裁定 | 证据 |
| --- | --- | --- |
| flag 清单 | PASS | `feature-flags-0.5.2.md` §1：本版**未引入任何 flag**（本版改动面 = 元数据 + 治理记录 + 发布工件）【文档】 |
| 「不适用」取证（非推断） | PASS | §2：`grep featureFlag\|feature_flag\|FEATURE_FLAG\|flagEnabled` 于 `lib/*.js`/`*.mjs` = **0 命中**；改动面 4 文件零 `lib/**`【文档】；与【C】「`lib/**` 零改动 / 合计 7 文件」一致 |
| 既有等效控制面登记 | PASS | §3：`lib/index.js` L42 `enabled`（等效 kill switch，`assertEnabled()`）+ L53/L61-64 平台开关；**本版未修改其行为**（零 `lib/` 改动【C】） |
| Kill Switch 验证记录 | PASS（间接） | 本版无 flag ⇒ 无新增 flag 关闭验证需求（**空集真空满足**）；既有 kill switch 由 `test/smoke.mjs` 断言看护，而 smoke **282 passed / 0 failed**【C】⇒ 该断言集合绿。**待验证**：`feature-flags` §3 所引「`enabled=false 拒绝变更/不落盘` 由 smoke 断言看护」的具体断言身份，本次未独立定位（不影响本维度裁定，因本版未触及该控制面） |
| flag 清理 / 债务 | PASS | §末：无 flag 债务、无需清理计划（N/A）【文档】 |

**维度裁定：PASS** — 硬门槛「Feature Flag 关闭验证 / 全部通过」在**空集语义下满足**（本版零 flag、零产品代码改动），且「不适用」有命令级取证而非陈述式断言。

### 1.5 版本号合规 — **PASS**

| 检查面 | 裁定 | 证据 |
| --- | --- | --- |
| semver 规则 | PASS | `0.5.1 → 0.5.2` = **PATCH**；变更类型 = 修复/安装通道适配（无新功能、无 breaking）【文档：`release-notes` §2 L35-36 + `CHANGELOG.md` L122】 |
| bump 理由充分 | PASS | 仓库自述口径（`CHANGELOG.md` **L3**「0.x 阶段以次要版本承载功能批，补丁号承载修复」）与 PATCH 一致【文档】；BUG-006 属修复而非功能批 ⇒ 不升至 0.6.0 有据 |
| 不跳号 | PASS | 前一版本 `## [0.5.1] - 2026-09-07`（`CHANGELOG.md` **L124**），序列连续【文档】 |
| 时效性 | PASS | `[0.5.2] - 2026-09-12` 与发布日一致 |
| 版本一致性 | PASS | CHANGELOG 段头 ≡ package.json ≡ tag 名【C】；与 `[Unreleased]` 未提前标注任何版本号（L5 保持 `[Unreleased]`）一致 |

**维度裁定：PASS**。

---

## 2. 硬门槛裁决表（5 行，逐项如实裁决）

| # | 硬门槛项 | 阈值 | 裁决 | 证据与理由 |
| --- | --- | --- | --- | --- |
| H1 | 发布检查清单全部 PASS | = 100% | ❌ **FAIL** | 清单 §C.2「回滚方案已验证」= **未执行**（L36）；§G `check-release` = **FAILED 21 issues / 不可用**（L73）；§F 决策 = **有条件发布**而非「可以发布」（L63）；§D.1 的 ✅ 经验证实为 PARTIAL（唯一交付面未做安装冒烟）。**N/A 项（监控/告警/量化指标）经核为诚实的结构性不适用，不构成 FAIL** —— 驱动 FAIL 的是上述 4 项。**未达 100% PASS** |
| H2 | 回滚方案存在且**已验证** | = 已验证 | ❌ **FAIL** | 方案**存在**（`rollback-plan-0.5.2.md` 79 行、命令级、影响面已评估）但**未演练**（§6 L78；`release-notes` §4.1 L77）。文档自述「**不主张已验证**」——诚实，但门槛为「= 已验证」⇒ **未满足**。与 F2（未 push）的交互：本次**无生产可见面**，故**实际风险敞口低**（撤销/回退零远端影响），但**门槛判定不因此变 PASS** |
| H3 | CHANGELOG 用户视角完整 | 关键段全部覆盖 | ✅ **PASS** | `CHANGELOG.md` L119-122：本版仅「修复」段，无新增/变更面（与零代码改动一致，非缺段）；用户视角含症状链路与兼容边界；L5-117 正确保留 v0.6.0 线全部条目 |
| H4 | breaking changes 已标注 | = 100%（与 diff 对比） | ✅ **PASS** | diff 中 breaking 面 = **空集**（7 文件全为 CHANGELOG/package.json/治理记录/发布工件，零 `lib/**`、零 `install.*`、零 CI【C】）⇒ 100% 覆盖（0/0）；条目内已显式声明「旧布局行为完全不变」 |
| H5 | Feature Flag 关闭验证 | 全部通过 | ✅ **PASS** | 本版**零 flag**（`feature-flags` §2 取证 0 命中 + 零 `lib/` 改动【文档/C】）⇒ 验证集为空集，真空满足；既有 kill switch 未触及，且 `smoke` 282/0【C】覆盖其既有断言 |

**裁决汇总：3 PASS / 2 FAIL** ⇒ 存在硬门槛未通过 ⇒ 结论**不得为 APPROVED / APPROVED_WITH_NOTES**。

---

## 3. Findings（9 条）

### F1 — 回滚方案未演练（硬门槛 H2 FAIL）｜严重度 **P1**
- **现象**：方案完备但从未在测试环境执行过一次往返。
- **证据**：`rollback-plan-0.5.2.md` §6 L78「已在测试环境实际演练 ⚠️ **未执行** …… 不主张已验证」；`release-notes` §4.1 L77；`release-checklist-0.5.2.md` §C.2 L36【文档】。
- **影响**：回滚路径 A/B/C 的命令正确性与幂等性均未实证；若发布后发现安装面异常，回退动作本身将成为「未验证的操作」。**但**：回滚对象为本地 tag/安装版本（非运行态系统），且本版未 push ⇒ 无生产面、无用户可见面，实际风险敞口低（K3 待验证：`install.ps1` 幂等性证据来自 BUG-006 交付的隔离实测，其对象 ≠ 被发布树）。
- **修复建议**（二选一，须留痕）：① **补一次隔离演练**——在 `%TEMP%` 隔离根 + `DSH_HOME`/`npm_config_*` 重定向下执行路径 A 往返（`checkout v0.5.2 → install → checkout v0.5.1 → install → 回 v0.5.2`）并记录原始输出；② 由 Coordinator 走**显式风险接受**（关键决策，需用户确认）并在 `decision-log` 落条 + 清单 §C.2 改写为「不适用（非运行态对象）· 已接受风险」，附观察窗（push 后用户侧首次安装前）。
- **复审需验证点**：演练输出（命令 + 实际结果 + 幂等 diff 为零）**或** decision-log 的风险接受条目（含 ID、范围、有效期）。

### F2 — push 未执行；且 push 范围含未发布的 v0.6.0 线工作（可见面变化未显式声明/授权）｜严重度 **P1**
- **现象**：(a) 发布提交与 `v0.5.2` tag 仅在本地，远端 `origin/main` 仍 = `3442f396`，用户**无法通过远端获得 v0.5.2**；(b) 建议动作 `git push origin main v0.5.2` 会把**本机领先远端的 44 commits**（含 COMPAT-002~016 全部 v0.6.0 线工作）一并推上远端主线。
- **证据**：`release-notes` 头 L5 + §7 R1 L116 + §9-1 L172【文档】；【C】本地 tag 存在/未 push、远端 main = `3442f396`、领先 44 commits、远端无该 tag。
- **影响**：(a) 发布的**用户可见性为零**（用户视角三问之②「用户怎么知道变更存在」当前无答案）⇒ 本次仅为「本地发布动作」，尚未构成对用户交付；(b) push 是**不可逆可见面动作**——一旦执行，v0.6.0 线的未发布内容（含 `.github/workflows/ci.yml` 探测轨、宿主契约层等）即刻公开，而该线**尚未走 v0.6.0 发布流程**。发布记录 §3.1 仅述「可随 main 一并推送（无额外合并/切分动作）」，**未声明该推送的可见面后果**。
- **修复建议**：① 在 `release-notes` §3.1/§9-1 显式写明「`git push origin main v0.5.2` 将同时把 v0.6.0 线工作树内容推送至远端主线（可见面变化）」；② 该动作按**发布决策**处理（关键决策）——用户授权后方可执行；③ push 完成后即刻补 `check-release --version 0.5.2 --require-changelog --lineage-mode released --release-commit <最终 tag target SHA>`（fail-closed 完成态证据）；④ 若不愿公开 v0.6.0 线，则须先切分主线（在 `3442f39` 之上重建发布提交）——与 F4 的处置合并决策。
- **复审需验证点**：发布记录中的推送范围声明 + 用户授权留痕（或切分方案）；若已 push，则 `ls-remote` 结果 + `--lineage-mode released` 输出。

### F3 — `check-release` 门禁不可用（21 issues）⇒ stage-release 退出条件未满足、发布就绪无可复查机检 PASS｜严重度 **P1**
- **现象**：`check-release --version 0.5.2 --require-changelog --lineage-mode candidate` = **FAILED 21 issues（exit 1）**，归因于工具**跨根期望源缺陷**（读插件仓自身 `project/CHANGELOG.md`、期望插件仓 `1.0.0 依赖链`/`REQ-059~064`、执行插件自家测试路径）。
- **证据**：`release-notes` §7 R5 L120-140 + §4.1 L76 + §8 门禁诚实声明 L166；`release-checklist` §G L73 与 L75 诚实声明【文档】；【C】同结果。**12 项子检查 PASS**（version consistency / hot fact source / runtime readiness matrix / first session measurement / governance pack status / agent adapters / projection sync / cross references / archive integrity / release lineage(candidate) / gate sequence for release / one dot zero blockers）【C】。
- **影响**：发布就绪的**唯一机检门禁缺位**；`stage-release` SKILL 退出条件「候选态 check-release PASS」**未满足**。文档已如实记为「不可用（FAIL）」并**拒绝以三件套替代其结论**（合规，无包装）。剩余风险 = 发布就绪除「三件套 + 版本三方一致 + 分层机检」外，无自动化发布面校验。
- **修复建议**：Coordinator 裁定并留痕——① 登记 `SYSGAP`（SYSGAP-001 家族：跨根期望源）并指定修复任务；② 明确本仓发布就绪的**替代判据集合**（现为：`node --check` ×N 0 错 + `validate-preset` 29/29 + `smoke` 不劣化 + 版本三方一致 + CHANGELOG 分层机检 + 发布工件齐备）；③ 该项作为「门禁不可用」进入 risk-log（附 escalation 期限），**不得**改写为 PASS。
- **复审需验证点**：SYSGAP 登记条目 ID + 替代判据的裁定记录（decision-log 或 risk-log 行）。

### F4 — tag 树边界三重不一致（不含发布工件 / 含 v0.6.0 线 / 范围仅靠声明承担）｜严重度 **P1**
- **现象**：`v0.5.2` tag → peel `e1f25df8`（版本 bump 提交）。由此产生三重不一致：
  1. `docs/release/{release-checklist,feature-flags,rollback-plan}-0.5.2.md` 落在其后的补充提交 `e093e72` ⇒ **不在 tag 树内**（tag 树缺 3 份发布工件）；
  2. tag 树 = 本机 HEAD 侧历史树，**包含 v0.6.0 线（COMPAT-002~016）全部工作树内容**（本机领先远端 44 commits）⇒ 「tag 树 ≡ v0.5.2 代码范围」不成立；
  3. tag ↔ CHANGELOG ↔ package.json 三方一致（`0.5.2`）**成立**——即「版本声明」正确，但「范围」不严格。
- **证据**：`release-notes` §3.2 L54-56 + §7 R8 L123 + §5 L91【文档】；【C】tag/sha/44 commits/tag 未 push 事实。文档**已如实留痕**并给出零成本重定命令（合规）。
- **影响**：下游若以「tag 树」为判据（含 `--lineage-mode released --release-commit`，其语义以 tag target 为准）会得到：**发布工件缺失 + 范围含未发布线**。目前仅靠「发布记录声明 + 路线图行」承担范围口径 ⇒ **无机器可查面**（声明式口径不可机检）。
- **修复建议**（tag 未 push，**零成本**，二选一并留痕）：① **重定 tag** 至 `e093e72`（`git tag -d v0.5.2 && git tag -a v0.5.2 -m "…" e093e72`）——使 tag 树 ⊇ 全部发布工件，范围仍以声明为准；② 若要求「tag 树 = BUG-006 代码面 + 版本号 0.5.2」严格成立，则需在 `3442f39` 之上**重建发布提交**（改写本地未推送历史，代价较高）；③ 若保持现状，须由用户显式确认「接受 tag 树含 v0.6.0 线且不含发布工件」，并把确认写入 decision-log。**本 Reviewer 裁定：不因该边界判 BLOCKED**（未 push、零远端影响、可零成本修正），但在转 APPROVED 前**必须完成三选一**——否则「tag 树 / 范围 / 工件」三者将持续不可机检地漂移。
- **复审需验证点**：重定后的 `git for-each-ref refs/tags/v0.5.2`（新 target SHA）**或** 用户确认条目 + `--release-commit` 最终采用的 SHA 与记录一致。

### F5 — 唯一交付面（安装通道）未对**被发布树**执行安装冒烟；清单 §D.1 的 ✅ 实为 PARTIAL｜严重度 **P2**
- **现象**：本版唯一用户可见内容 = `install.ps1` / `install.sh` 的版本自适应；但发布验证三件套（`node --check` / `validate-preset` / `smoke`）**均不覆盖安装面**，本次**未执行任何安装冒烟**。
- **证据**：`release-notes` §4.1 L75「安装冒烟 …… **未执行** …… 本记录**不主张**新增安装验证」；`release-checklist` §D.1 L44 仍标 ✅【文档】；§4 L67-69 三件套清单【文档/C】。
- **影响**：唯一交付面对被发布树**无验证**，其证据来自 BUG-006 交付内（早于本次发布提交）的隔离实例实测——**证据对象 ≠ 被发布树**。缓解事实：`install.ps1` / `install.sh` 在 REL-006 中**零改动**（diff 范围【C】）⇒ 发布树中安装脚本内容 ≡ BUG-006 交付内容，实际残差低。措辞合规性：文档**未**使用「真实安装通过」（符合 M7.7 措辞纪律）。
- **修复建议**：① 在隔离环境（`DSH_HOME` + `npm_config_cache/userconfig/globalconfig` 重定向临时根）执行一次安装冒烟并记录原始输出；或 ② Coordinator 裁定「install 脚本零改动 + BUG-006 隔离实例实证 ⇒ 等效接受」并写入 risk-log（含理由与有效期）；同时把清单 §D.1 由 ✅ 改标 `PARTIAL（替代证据）` 以保持自述与事实一致。
- **复审需验证点**：隔离安装冒烟输出（三要素：隔离根路径、命令、结果），或等效接受的 risk-log 条目 ID。

### F6 — 版本里程碑表缺 `v0.5.1 发布` 行（R3 历史遗留已上报）｜严重度 **P2**
- **现象**：里程碑表在 `v0.5.0 发布` 后直接接本次新增的 `v0.5.2 发布`，缺少 2026-09-07 已发布的 v0.5.1。
- **证据**：`release-notes` §7 R3 L118【文档】。**未独立复核 plan-tracker 原文**（本次读取预算未覆盖，标【待验证】：本次未读 `.governance/plan-tracker.md`）。
- **影响**：版本里程碑链条断裂 ⇒ 发布史核对（如「上一已发布版本」判定）需旁证；不影响本版交付正确性。
- **修复建议**：协调者补录 `v0.5.1 发布` 行（治理记录变更，非产品代码）；或将缺口显式登记为已知治理债务。
- **复审需验证点**：里程碑表含 v0.5.1 行，或 decision/risk-log 中的显式延期条目。

### F7 — `archive.py migrate --auto --dry-run` 解析已发布版本 = 0 个（SYSGAP-001 家族边缘）｜严重度 **P2**
- **现象**：仓库实有 8 个 tag（v0.2.0~v0.5.1），工具解析到 **0 个**已发布版本 ⇒ 归档触发判定恒为「跳过」。
- **证据**：`release-notes` §7 R4 L119 + §10 L189；`release-checklist` §G L72【文档】；【C】一致（exit 0、无数据损失）。
- **影响**：**归档触发检测不可用**（非本版交付缺陷）；长期将导致治理热文件膨胀与归档策略失效。无数据损失、不阻断本次发布。
- **修复建议**：并入 F3 的 SYSGAP 登记（同族跨根/解析缺陷），并指定修复任务；修复前由 Coordinator 以人工判据替代归档触发检测。
- **复审需验证点**：SYSGAP 条目（含本项）或修复后的 dry-run 真实输出。

### F8 — 发布文档交叉引用陈旧（「§7（R1~R7）」实际为 R1~R8）｜严重度 **P3**
- **现象**：`release-checklist-0.5.2.md` §B.4（L27）与 `release-notes` §8（L155）均引用「§7（R1~R7）」，而 §7 表格实际含 **R8**（tag 提交边界，L123）。
- **证据**：上述行号【文档】。
- **影响**：审阅者引导遗漏最关键的边界风险条目（R8 正是 F4 的证据源）⇒ 文档可用性缺陷，无事实性错误。
- **修复建议**：改为「R1~R8」或在引用处去除行号区间，改为「§7 残余风险全表」。
- **复审需验证点**：两处引用与 §7 实际条目数一致。

### F9 — `feature-flags-0.5.2.md` §2 取证命令为相对引用，事后不可复现｜严重度 **P3**
- **现象**：取证行使用 `git diff HEAD~1 HEAD --name-only`（发布提交）。当时 HEAD = `e1f25df8`，此后 HEAD 已前进（`e093e72` 及后续治理提交）⇒ 该命令**现在会返回不同结果**（当前 4 文件 ≠ 发布提交的 4 文件集合），无法按原样复算。
- **证据**：`feature-flags-0.5.2.md` §2 L17【文档】；HEAD 已前进【C】。
- **影响**：取证的可复查性下降（违反「命令输出可复查」红线的最小面）；结论本身（本版零 `lib/**` 改动）已有【C】独立支撑，无事实错误。
- **修复建议**：改为绝对 SHA：`git diff e1f25df8^ e1f25df8 --name-only`（或 `e093e72^ e093e72`），并注明取证时点。
- **复审需验证点**：§2 取证命令含绝对 SHA 且复算结果 = 4 文件（`CHANGELOG.md` / `package.json` / `.governance/plan-tracker.md` / `docs/review/REL-006-release-notes.md`）。

---

## 4. tag 边界与范围口径判断（专门裁决）

**问题**：`v0.5.2` tag 指向版本 bump 提交 `e1f25df8`（与 v0.3.0/v0.4.0/v0.5.0/v0.5.1 四个历史 tag 的惯例一致），因此补建的三件 `docs/release/*` **不在 tag 树内**（在其后的 `e093e72`）；同时 tag 树因本机领先远端 44 commits 而含 v0.6.0 线（COMPAT-002~016）内容。

**判断（四条）**：

1. **边界本身是否可接受**：**方向可接受，状态不可接受（须处置）**。「tag 指向发布提交（含版本 bump）」是仓库**既定惯例**（4 个历史 tag 同构），方案 A 的选择**有据、非失误**；且方案 B（tag → `3442f39`）会导致「checkout v0.5.2 得到 version 0.5.1」的更严重误导——**方案 A 优于方案 B 的论证成立**（`release-notes` §3.1 L47-48）。
2. **是否需重定 tag**：**需处置，但本 Reviewer 不建议重定到 `3442f39`**。「范围 = BUG-006 代码面」与「tag 树内 version = 0.5.2」在当前线性历史上**不可兼得**；重定到 `3442f39` 会以牺牲版本一致性换取范围精确性——**以更严重的错误替换较轻的错误，不采纳**。可行选项按优先级：① **重定至 `e093e72`**（消除「工件不在 tag 树内」这一**可机器观测**的不一致，成本为零，范围仍以声明承担）；② 在 `3442f39` 之上重建发布提交后重打 tag（同时满足范围与版本一致性，但需改写本地未推送历史 + 重新生成记录 SHA）；③ 保持现状 + 用户显式确认。**三选一必须留痕**。
3. **口径本身的效力边界（重要）**：现口径「v0.5.2 代码范围 = BUG-006 安装通道适配；COMPAT-* 属未发布 v0.6.0 线」仅存在于**声明面**（`release-notes` §1.1 + §3.2 + 路线图行 + `checklist` §B 分层机检）。**声明面不可机检**——任何下游消费者若改用 tag 树/工作树作判据，即会偏离。因此口径**有效但不自证**：必须由 §3 的处置把「tag 树 ↔ 声明」差距**缩小到可机器核对**（至少消除「发布工件缺失」这一条）。
4. **未 push 使一切可逆**：tag 与发布提交均未 push（远端 main = `3442f396`，远端无该 tag）⇒ 复议、重定、甚至整体重做**零远端副作用**。这**降低**了本 finding 的紧迫度（故为 P1 而非 P0），但**不消除**——一旦按现状 push，边界即固化，此后修正须走 revert + 新版本号。

---

## 5. 结论（三选一）

> **结论：`NEEDS_CHANGE`**

**理由**：硬门槛 5 项中 **H1（发布检查清单 100% PASS）与 H2（回滚方案已验证）FAIL** ⇒ 按角色定义「任一 FAIL 即阻断」，**不得 APPROVED**；同时，发布工件主体（CHANGELOG / 版本号 / rollback 方案 / feature-flags 取证 / 发布记录）质量合格且**如实披露**了全部未执行项与工具缺陷（无造假、无包装、无虚假绿灯），缺陷均为**可低成本补齐或可裁定**的治理/证据完备性问题，而非「发布流程致命缺陷」⇒ **不判 BLOCKED**。故取 **NEEDS_CHANGE**：退回 Release Agent 补充工件后重 spawn **本 Reviewer（round R2）**复审。

**附带说明（避免误读）**：本次发布为**本地发布且未 push**，未产生任何远端/用户可见面 ⇒ 判 NEEDS_CHANGE 的**返工成本极低、风险敞口为零**；反之若在补齐前 push，F2/F4 的不一致将固化为不可逆事实。**建议先补齐、后 push**。

### 转 APPROVED 需 Release 补充的内容（4 项，缺一不可）

| # | 补什么 | 对应 finding | 可接受的替代路径 |
| --- | --- | --- | --- |
| 1 | **回滚演练记录**（隔离环境路径 A 往返：命令 + 原始输出 + 幂等 diff 为零） | F1 / H2 | Coordinator 显式**风险接受**（decision-log 条目 + 用户确认 + 观察窗），并改写清单 §C.2 口径 |
| 2 | **tag 边界处置**：重定 tag 至 `e093e72`（推荐）／重建发布提交后重打／用户显式确认现状 | F4 | 任一选项均须**留痕**并与 `--release-commit` 最终取值一致 |
| 3 | **push 范围声明**：在发布记录显式写明「push main 将同时发布 v0.6.0 线工作树内容至远端主线」+ 用户授权留痕 | F2 | 或切分主线（在 `3442f39` 之上重建发布提交） |
| 4 | **`check-release` 替代口径裁定**：SYSGAP 登记（含 archive 解析缺陷）+ 本仓发布就绪替代判据集合 | F3 / F7 | risk-log 条目（含 escalation 期限），**不得**记为 PASS |

**复审（R2）时的必查项**：① 上述 4 项补强证据在仓内可读；② 清单 §C.2 / §D.1 / §F 的结论与补强后事实一致（不得出现「✅ 已验证」而无演练输出的自述—事实错位）；③ 发布文档交叉引用已修正（F8）；④ `feature-flags` §2 取证命令已改绝对 SHA（F9）；⑤ 结论终态字段自洽（若届时判 `APPROVED_WITH_NOTES`，其 REVIEW 输出 MUST 含独立结构字段 `unresolved_blockers=0`；本 round 为 NEEDS_CHANGE，**不适用该字段**）。

---

## 6. Reviewer 自检（SKILL 自检清单）

- [x] 所有 Gate 是否通过？（**否** —— 硬门槛 2 项 FAIL，已如实裁决；`check-release` 门禁**不可用**已记 F3，未包装为 PASS）
- [x] 回滚方案是否可执行（非理论）？（**命令级可执行，但未演练** ⇒ 判 PARTIAL/FAIL，未按理论通过）
- [x] Breaking change 是否有迁移指南？（本版 breaking 面为空集，无需迁移指南，已在 §1.3 说明依据）
- [x] 监控告警是否已配置且可触发？（**N/A 已核实为结构性不适用**，非伪造；未计 PASS）
- [x] 事实依据红线（P-01）：本报告所有结论均可回溯至【文档】行号或【C】内联事实；无法证实者已标【待验证】（F6 / F5 的 K3 / §1.4 断言身份）；**未执行项一律标「未执行」**，未以推测填充。
- [x] 只读约束：未修改任何发布文档/代码，未修改 tag/commit；写入仅限本报告两份（`.governance/review-REL-006.md` + `docs/review/REL-006-R1.md`）。
- [x] 未与用户交互（无 AskUserQuestion）。

---

<!-- review-verdict: {"task_id":"REL-006","round":"R1","verdict":"NEEDS_CHANGE","hard_gates":{"total":5,"pass":3,"fail":["H1_publish_checklist_100pct","H2_rollback_verified"]},"findings":{"P0":0,"P1":4,"P2":3,"P3":2,"total":9},"next_round_required":true} -->
