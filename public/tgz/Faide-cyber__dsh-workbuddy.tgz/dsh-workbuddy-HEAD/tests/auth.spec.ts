import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { parseWorkBuddyAuth, parseWorkBuddyAuthIdentity, WorkBuddyAccountStore } from '../src/auth.ts'
import type { WorkBuddyCredits } from '../src/upstream.ts'

const cleanup: string[] = []
afterEach(async () => {
  while (cleanup.length > 0) {
    const path = cleanup.pop()
    if (path !== undefined) await rm(path, { recursive: true, force: true })
  }
})

describe('official account edition', () => {
  it('reads account.type and does not infer edition from enterpriseId', () => {
    const personal = parseWorkBuddyAuth(JSON.stringify({ auth: { accessToken: 'a' }, account: { type: 'personal' } }))
    const education = parseWorkBuddyAuth(JSON.stringify({ auth: { accessToken: 'b' }, account: { type: 'education' } }))
    const ultimate = parseWorkBuddyAuth(JSON.stringify({ auth: { accessToken: 'u' }, account: { type: 'ultimate' } }))
    const legacy = parseWorkBuddyAuth(JSON.stringify({ auth: { accessToken: 'c' }, account: { enterpriseId: 'enterprise' } }))
    const encrypted = parseWorkBuddyAuthIdentity(JSON.stringify({
      auth: { accessToken: { $wbEncrypted: 1, envelope: 'ciphertext' } },
      account: { uid: 'desktop-user', type: 'personal' },
    }))
    expect(personal?.edition).toBe('personal')
    expect(education?.edition).toBe('education')
    expect(ultimate?.edition).toBe('education')
    expect(legacy?.edition).toBeUndefined()
    expect(encrypted).toEqual({ uid: 'desktop-user', edition: 'personal' })
  })
})

describe('WorkBuddyAccountStore', () => {
  it('keeps explicit selection stable while exposing multiple token-free accounts', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'dsh-workbuddy-ai-auth-'))
    cleanup.push(dir)
    const store = new WorkBuddyAccountStore({
      region: 'cn',
      ownPath: join(dir, 'cn-auth.json'),
      refresh: async credential => ({ accessToken: credential.accessToken, expiresInSec: 3600 }),
    })
    const expiresAtMs = Date.now() + 60 * 60 * 1000
    await store.importCredential({ accessToken: 'token-a', refreshToken: '', expiresAtMs, domain: '', uid: 'u-a', source: 'dsh' })
    await store.importCredential({ accessToken: 'token-b', refreshToken: '', expiresAtMs, domain: '', uid: 'u-b', source: 'dsh' })
    const accounts = await store.accounts()
    expect(accounts).toHaveLength(2)
    expect(accounts.every(account => account.region === 'cn')).toBe(true)
    const first = accounts[0]!
    await store.select(first.id)
    await store.setNote(first.id, '主账号')
    expect((await store.accounts()).find(account => account.id === first.id)?.note).toBe('主账号')
    expect((await store.current())?.accessToken).toBe('token-a')
    expect((await store.resolveFor(accounts[1]!.id)).accessToken).toBe('token-b')
    expect((await store.current())?.accessToken).toBe('token-a')
    const restored = new WorkBuddyAccountStore({
      region: 'cn',
      ownPath: join(dir, 'cn-auth.json'),
      refresh: async credential => ({ accessToken: credential.accessToken, expiresInSec: 3600 }),
    })
    expect((await restored.accounts()).find(account => account.id === first.id)?.note).toBe('主账号')
    await restored.setNote(first.id, ' ')
    expect((await restored.accounts()).find(account => account.id === first.id)?.note).toBeUndefined()
  })

  it('disables check-in only for education accounts', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'dsh-workbuddy-ai-auth-'))
    cleanup.push(dir)
    const store = new WorkBuddyAccountStore({
      region: 'cn',
      ownPath: join(dir, 'cn-auth.json'),
      refresh: async credential => ({ accessToken: credential.accessToken, expiresInSec: 3600 }),
    })
    await store.importCredential({ accessToken: 'education-token', refreshToken: '', expiresAtMs: Date.now() + 3_600_000, domain: '', uid: 'education-user', edition: 'education', source: 'dsh' })
    await store.importCredential({ accessToken: 'personal-token', refreshToken: '', expiresAtMs: Date.now() + 3_600_000, domain: '', uid: 'personal-user', edition: 'personal', source: 'dsh' })
    const accounts = await store.accounts()
    expect(accounts.find(account => account.edition === 'education')).toMatchObject({ edition: 'education', checkinEnabled: false })
    expect(await store.checkinSupported(accounts.find(account => account.edition === 'education')!.id)).toBe(false)
    expect(await store.checkinSupported(accounts.find(account => account.edition === 'personal')!.id)).toBe(true)
  })

  it('re-reads credits only when forced, not on every poll', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'dsh-workbuddy-ai-auth-'))
    cleanup.push(dir)
    const store = new WorkBuddyAccountStore({
      region: 'cn',
      ownPath: join(dir, 'cn-auth.json'),
      refresh: async credential => ({ accessToken: credential.accessToken, expiresInSec: 3600 }),
    })
    await store.importCredential({ accessToken: 'token', refreshToken: '', expiresAtMs: Date.now() + 3_600_000, domain: '', uid: 'u', source: 'dsh' })

    let reads = 0
    const fetchCredits = async (): Promise<WorkBuddyCredits> => {
      reads += 1
      return { total: reads, accounts: [] }
    }
    // A 15-minute TTL: the background poll must not re-read inside it.
    const ttl = 15 * 60_000
    await store.refreshCreditSnapshots(fetchCredits, ttl, ttl)
    expect(reads).toBe(1)
    await store.refreshCreditSnapshots(fetchCredits, ttl, ttl)
    expect(reads).toBe(1)
    // The card's 刷新 button passes `force`, which the TTL must not swallow.
    await store.refreshCreditSnapshots(fetchCredits, ttl, ttl, { force: true })
    expect(reads).toBe(2)
    const forced = await store.refreshCreditSnapshots(fetchCredits, ttl, ttl, { force: true })
    expect(reads).toBe(3)
    expect([...forced.values()][0]?.credits?.total).toBe(3)
  })

  it('merges the official desktop edition into an existing sidecar account', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'dsh-workbuddy-ai-auth-'))
    cleanup.push(dir)
    const ownPath = join(dir, 'cn-auth.json')
    const desktopPath = join(dir, 'workbuddy-desktop.info')
    const store = new WorkBuddyAccountStore({
      region: 'cn',
      ownPath,
      refresh: async credential => ({ accessToken: credential.accessToken, expiresInSec: 3600 }),
    })
    await store.importCredential({ accessToken: 'stored-token', refreshToken: '', expiresAtMs: Date.now() + 3_600_000, domain: '', uid: 'same-user', source: 'dsh' })
    await writeFile(desktopPath, JSON.stringify({
      auth: { accessToken: { $wbEncrypted: 1, envelope: 'ciphertext' }, expiresAt: 4_102_444_800 },
      account: { uid: 'same-user', type: 'personal' },
    }))
    const restored = new WorkBuddyAccountStore({
      region: 'cn',
      ownPath,
      desktopPath,
      refresh: async credential => ({ accessToken: credential.accessToken, expiresInSec: 3600 }),
    })
    const id = (await store.accounts())[0]!.id
    expect((await restored.accounts()).find(account => account.id === id)?.edition).toBe('personal')
    expect((await restored.resolve()).accessToken).toBe('stored-token')
  })

  it('persists an edition filled from the official profile', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'dsh-workbuddy-ai-auth-'))
    cleanup.push(dir)
    const ownPath = join(dir, 'cn-auth.json')
    const store = new WorkBuddyAccountStore({
      region: 'cn',
      ownPath,
      refresh: async credential => ({ accessToken: credential.accessToken, expiresInSec: 3600 }),
    })
    await store.importCredential({ accessToken: 'enterprise-token', refreshToken: '', expiresAtMs: Date.now() + 3_600_000, domain: '', uid: 'enterprise-user', enterpriseId: 'enterprise', source: 'dsh' })
    await store.refreshAccountEditions(async credential => credential.enterpriseId === 'enterprise' ? 'education' : undefined)
    const id = (await store.accounts())[0]!.id
    expect((await store.accounts())[0]).toMatchObject({ id, edition: 'education', checkinEnabled: false })
    const restored = new WorkBuddyAccountStore({
      region: 'cn',
      ownPath,
      refresh: async credential => ({ accessToken: credential.accessToken, expiresInSec: 3600 }),
    })
    expect((await restored.accounts())[0]?.edition).toBe('education')
  })

  it('returns the normalized note so the card can echo it without re-reading', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'dsh-workbuddy-ai-auth-'))
    cleanup.push(dir)
    const store = new WorkBuddyAccountStore({
      region: 'cn',
      ownPath: join(dir, 'cn-auth.json'),
      refresh: async credential => ({ accessToken: credential.accessToken, expiresInSec: 3600 }),
    })
    await store.importCredential({ accessToken: 'token-a', refreshToken: '', expiresAtMs: Date.now() + 3_600_000, domain: '', uid: 'u-a', source: 'dsh' })
    const id = (await store.accounts())[0]!.id
    // The echo must equal what a later read sees, or the card paints one name
    // and the next poll replaces it with another.
    expect(await store.setNote(id, '  主力  号  ')).toBe('主力 号')
    expect((await store.accounts())[0]!.note).toBe('主力 号')
    // An empty save clears the note, so the card falls back to the nickname.
    expect(await store.setNote(id, '   ')).toBeUndefined()
    expect((await store.accounts())[0]!.note).toBeUndefined()
    // An unknown account is a failure, not a silent no-op that echoes a name
    // the host never stored.
    await expect(store.setNote('no-such-account', 'x')).rejects.toThrow(/not found/u)
  })

  it('uses an access-token-only import without trying an unavailable refresh', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'dsh-workbuddy-ai-auth-'))
    cleanup.push(dir)
    const store = new WorkBuddyAccountStore({
      region: 'global',
      ownPath: join(dir, 'global-auth.json'),
      refresh: async () => { throw new Error('refresh should not run') },
    })
    await store.importCredential({ accessToken: 'opaque-access-token', refreshToken: '', expiresAtMs: 0, domain: '', uid: 'opaque-user', source: 'dsh' })
    expect((await store.resolve())?.accessToken).toBe('opaque-access-token')
  })
})
