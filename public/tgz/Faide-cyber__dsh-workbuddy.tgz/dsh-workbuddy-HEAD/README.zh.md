<h1 align="center">DSH WorkBuddy</h1>

<p align="center">
  <em>把 WorkBuddy 国内版和国际版的免费/付费模型接进 DeepSeek Harness —— 无需下载 WorkBuddy 桌面端。</em>
</p>

<p align="center">
  <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-65a30d?style=flat" alt="MIT license"></a>
  <img src="https://img.shields.io/badge/dsh-0.2.x-4f46e5?style=flat" alt="DSH 0.2.x">
  <img src="https://img.shields.io/badge/providers-two-0ea5e9?style=flat" alt="two providers">
  <img src="https://img.shields.io/badge/prices-live_catalog-brightgreen?style=flat" alt="prices from the live catalog">
  <img src="https://img.shields.io/badge/runtime_dependencies-zero-brightgreen?style=flat" alt="zero runtime dependencies">
</p>

<p align="center">
  <a href="./README.md">English</a> · <b>中文</b>
</p>

- **登录**：按区域使用浏览器 OAuth，免桌面端登录；已装桌面 App 的凭据也可只读导入
- **账号**：区域隔离的多账号列表、显式切换、余额显示与预警；提供账号备注功能；已支持接入教育公益版；插件副本与桌面 auth 文件分离
- **一键签到**：支持的个人账号可一键收取每日签到、猫猫旅行、成长中心全部任务（签到 / 猫猫旅行）；提供自动签到，默认关闭
- **设备隔离**：各自的凭据、模型目录、余额相互隔离；切换账号不影响在途请求
- **开箱即用**：安装并启用插件后，在 DSH 中直接使用，无需额外配置；现已支持 0.2.x 桌面端

<p align="center">
  <img src="./docs/card-accounts.png" alt="DSH WorkBuddy 设置卡片：账号与余额" width="46%">
  <img src="./docs/card-models.png" alt="DSH WorkBuddy 设置卡片：模型范围与开关" width="46%">
</p>

<p align="center">
  <img src="./docs/model-picker.png" alt="在 DSH 模型选择器里选择 WorkBuddy 模型" width="92%">
</p>

## 快速开始

1. Node 22+，已安装 DSH。
2. 安装插件并启动：

```sh
dsh plugin --profile web add github:Faide-cyber/dsh-workbuddy
dsh web
```

3. 打开 **设置 → 插件 → DSH WorkBuddy**，点 **连接**，在弹出的 WorkBuddy 网站里登录。
4. 模型选择器里选一个 **WorkBuddy** 模型 —— 默认「仅免费模型」范围下，列表就是该区域目录当前标的 `x0.00` 的那些。

也可以在终端登录：

```sh
dsh plugin --profile web exec dsh-workbuddy login
```

安装、更新或登录后必须**重启 `dsh web`**。刷新浏览器不够，Node 模块常驻内存。

默认模型可以写在 `~/.dsh/settings.yaml`：

```yaml
agent-default-model:
  provider: workbuddy-ai
  model: hy3
  reasoningEffort: high
```

请填该区域当前确实列出的 id：模型列表就是该区域实时目录返回的内容，写死的默认模型可能过时。`hy3` 在撰写时两区都免费。

## 登录怎么工作

每个区域独立走官方 CLI 登录接口：

1. `POST /v2/plugin/auth/state?platform=CLI&nonce=`（国际 `www.workbuddy.ai`，国内 `copilot.tencent.com`）
2. 打开返回的 `authUrl`
3. 轮询 `GET /v2/plugin/auth/token?state=`（还在等时上游返回 `11217`）
4. Token 写入区域专属的插件副本：国际 `$DSH_HOME/.workbuddy-ai-auth.json`，国内 `$DSH_HOME/.workbuddy-cn-auth.json`

桌面 App 的 `workbuddy-desktop-ai.info`（国际）与 `workbuddy-desktop.info`（国内）只读、不写；插件只保存自己通过 OAuth 获得的区域凭据副本。

设置卡片会显示所有已导入账号。切换只影响后续请求，在途请求继续使用原账号；批量余额/签到不会改变当前选择。

**断开** / `logout` 只删对应区域插件自己的凭据，不影响桌面 App。

## 配置

设置 → 插件 → **DSH WorkBuddy**：

- **连接 / 断开**：按区域浏览器登录，或删掉该区域插件凭据
- 国内/国际账号列表、官方版型徽标、显式切换、剩余积分和连通性测试
- 国内个人账号可勾选自动签到（默认关闭）；教育公益版不显示签到控件
- 当前账号默认每 15 分钟、其他账号默认每 60 分钟只读刷新，可自定义
- 模型目录与价格每 24 小时自动从上游重拉（错峰几十分钟），上游新上的模型会出现在列表里并标「新增」；点「刷新」立刻重拉目录并刷新积分
- **仅免费模型**（默认）/ **全部模型**

也可以在 profile 的 `cordis.patch.yml` 里写：

```yaml
- id: llm-workbuddy
  config:
    modelScope: free          # 国际版：或 all
    cnModelScope: free        # 国内版：或 all
    probeConsent: false       # 真实模型探测默认关闭
    autoCheckin: false        # 国内自动签到默认关闭
    refreshActiveMinutes: 15
    refreshInactiveMinutes: 60
    # 局域网打开 DSH Web 时写访问用的 Host（不要写进 LOOPBACK）
    # allowedHosts: ["192.168.1.10"]
    # authFile / cnAuthFile: 一般不用；仅在桌面凭据不在默认位置时写绝对路径
```

环境变量：

| 变量 | 作用 |
|---|---|
| `DSH_WORKBUDDY_AUTH_FILE` | 覆盖国际桌面凭据路径（OAuth 凭据仍写插件自己的文件） |
| `DSH_WORKBUDDY_CN_AUTH_FILE` | 覆盖国内桌面凭据路径 |

## 命令行

```sh
dsh plugin --profile web exec dsh-workbuddy login
dsh plugin --profile web exec dsh-workbuddy status
dsh plugin --profile web exec dsh-workbuddy doctor
dsh plugin --profile web exec dsh-workbuddy logout
```

`status` / `doctor` 可加 `--json`。`logout` 只删 `$DSH_HOME/.workbuddy-ai-auth.json`。

## 故障排查

| 现象 | 处理 |
|---|---|
| 设置里没有这张卡片 / 模型列表没有 WorkBuddy | 重启 `dsh web`，不要只刷新浏览器 |
| 点连接后 `dsh web` 进程退出 | 无头 Linux 没有 `xdg-open` 时请更新到含 spawn `error` 处理的版本；用卡片上的登录链接 |
| 局域网 IP 打开卡片 403 `request-not-trusted` | 在 `allowedHosts` 里写该 IP/主机名，不要把它加进回环名单 |
| 登录成功但没有模型 | 该区域目录请求失败或返回为空——检查网络与 token 是否仍有效；此时列表保持为空，不会借用另一区域的模型 |
| `doctor` 显示 signed-out | 先 `login`，或确认国际版桌面 App 已登录 |
| `doctor` 里出现 `desktopAuthFile.encryptedFields` | 该桌面端版本把 token 字段封进 `$wbEncrypted` 信封，解封密钥只在桌面端进程内存里，只读导入在这里拿不到凭据。请用卡片上的「连接」登录 |
| 想用付费模型 | 设置卡片把范围改成「全部模型」，注意会扣积分 |
| 国内版每个请求都 400 `code 11128` | 国内网关按**字面连续子串**匹配 DSH 自己提示词里的原文：最初是身份横幅 `DeepSeek Harness`，2026-10-27 起扩大到其他段落，实测最小触发串是 112 字符、顺序敏感、确定性的 `Tokens prefixed with @ are paths the user explicitly referenced. Relative paths resolve to the workspace root`（出自 `@deepseek-ai/dsh-file-reference`）。插件转发前做两层处理，都无需设置：**语义层**把已登记的原文改写成同义句（国际/国内两个区都生效；无命中时逐字节不动，不破坏前缀缓存）；**结构层**两个区都跑，把过长的连续片段用换行打断——空格处换成换行，中文段落则在词句边界**插入**换行且不在行首留标点。这样长度 ≥40 的含空格片段不再存在；**无空格的长 ASCII 串**（URL、base64、`a/b/c` 这类斜杠串）打不断，属已知上限。网关只扫 `system` 与 `assistant`，不扫 `user`/`tool`，所以这两类不做改动。若你绕过插件，或上游再收紧，可在 `cordis.patch.yml` 给 `@deepseek-ai/dsh-system-prompt` 设 `includeHarnessIdentity: false` |
| 国际版每个请求都 400 `code 11128` | 两种成因，看 `msg`：`request illegal` 是缺 `X-Conversation-ID`、`X-Conversation-Request-ID`、`X-Conversation-Message-ID`（1.0.15 起自动补齐）；`Illegal API invocation from an unapproved channel` 是内容级字面指纹（2026-10-30 起国际网关也启用），1.0.23 起与国内走同一套两层处理，无需设置。 |
| 某模型默认推理档位下每个请求都 400 `code 11133`（或上下文压缩每次必挂） | 上游该行同时声明了两个矛盾的标记：`onlyReasoning: true`（只能思考）和 `canDisableThinking: true`（思考能关）。1.0.23 及之前插件信了后者，把「关闭」档翻译成字符串 `off` 交给 pi-ai，界面不选档位时它就真的写进请求体，上游不认，回这个业务码。压缩每次必挂是同一个原因：`dsh-compaction-basic` 组装摘要请求时不传 `reasoningEffort`，所以必然落在 `off` 上。1.0.24 起 `onlyReasoning` 优先：「关闭」档不再暴露，默认请求不带 `reasoning_effort`，由插件补 `high`。受影响行：`deepseek-v4.1-flash`、`kimi-k2.8-preview`（国内），`glm-5.3`、`glm-5.3-flash`、`gpt-6-astra`（国际）。升级插件并重启 DSH 即可，无需改配置。 |
| DSH 升级后插件不加载 / 提示 incompatible-version | 声明支持 DSH `>=0.2.0-rc.2 <0.2.1-0 \|\| >=0.2.1-rc.1 <0.3.0-0`（1.0.20 起写在 `engines.dsh`）；更旧的插件版本需要 `dsh plugin --profile desktop allow-version dsh-workbuddy@<版本> --dsh-version <当前版本> --accept-risk` |

```sh
dsh plugin --profile web exec dsh-workbuddy doctor
```

## 免责声明

仅供个人学习和研究，只驱动你自己的 WorkBuddy 账号在本机调用。请遵守 WorkBuddy 服务条款。本项目与腾讯、WorkBuddy、DeepSeek 均无关联。

## 许可证

[MIT](./LICENSE)
