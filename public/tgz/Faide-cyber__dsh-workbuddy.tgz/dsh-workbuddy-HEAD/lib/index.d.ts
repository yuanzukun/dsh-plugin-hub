import z from "@deepseek-ai/schemastery";
import { ThinkingLevelMap } from "@earendil-works/pi-ai";
import { PiAiAdapter } from "@deepseek-ai/dsh-llm-pi-ai";
import { Context } from "@deepseek-ai/cordis";
import { SettingsNamespace } from "@deepseek-ai/dsh-settings";
import { AttachmentStore } from "@deepseek-ai/dsh-attachment";
//#region src/status-paths.d.ts
/**
 * Node-free constants and types shared by the Host and browser halves.
 *
 * @module dsh-workbuddy/status-paths
 */
/** Plugin-owned status endpoint consumed by its browser half. */
declare const WORKBUDDY_STATUS_PATH = "/plugins/dsh-workbuddy/status";
/**
 * Plugin-owned control endpoint.
 *
 * Separate from the status route because it accepts writes: the status route's
 * loopback Host/Origin guard protects against a DNS-rebinding *page*, which is
 * not the same as authorizing a state-changing action. This route therefore also
 * requires the in-process key the browser half receives with the status document.
 */
declare const WORKBUDDY_CONTROL_PATH = "/plugins/dsh-workbuddy/control";
/** Official WorkBuddy account editions surfaced by the auth document. */
type WorkBuddyAccountEdition = 'personal' | 'education' | 'unknown';
/** One model's recorded probe observation, as the card displays it. */
interface WorkBuddyWebProbeModel {
  id: string;
  name: string;
  /** `validating` results carry efforts; the other states never do. */
  validation: 'validating' | 'non-validating' | 'unknown';
  efforts: readonly string[];
  probedAt: number;
}
/** Probe section of the status document. */
interface WorkBuddyWebProbeSection {
  /** Whether the user has authorized probing. */
  consent: boolean;
  /** Whether a sweep is in flight right now. */
  running: boolean;
  /** Models the user could probe by hand (undeclared yet reasoning-capable). */
  candidates: readonly string[];
  /** Recorded observations. */
  results: readonly WorkBuddyWebProbeModel[];
}
/** One billing package and its remaining credit. */
interface WorkBuddyWebCreditAccount {
  packageName: string;
  remain: number;
  size: number;
  /** Upstream `CapacityType`: 4 = monthly plan quota, 1 = granted bonus pack. */
  capacityType: number;
  /** Epoch ms when the package expires; absent when the upstream reports none. */
  expiresAt?: number;
}
/** Aggregated credit answer rendered by the plugin card. */
interface WorkBuddyWebCredits {
  total: number;
  accounts: readonly WorkBuddyWebCreditAccount[];
}
/** Billing convenience facts for one model, rendered as card badges. */
interface WorkBuddyWebModelBadge {
  id: string;
  name: string;
  /** Whether the model is currently free (`x0.00` credits). */
  free?: boolean;
  /** Promotional badges, e.g. `限时免费`, `夜间折扣`. */
  badges?: readonly string[];
  /** Credits multiplier in display form, e.g. `x0.79`. */
  credits?: string;
  /** Context capacity in tokens, taken verbatim from the upstream catalog. */
  contextWindow?: number;
  /**
   * Whether the free-only policy currently admits this model into the picker.
   * A card needs this to explain why a listed model is not selectable.
   */
  selectable?: boolean;
  /**
   * Whether the per-model switch is on. `false` means the picker no longer
   * lists the model, though a session that already selected it keeps working.
   */
  enabled?: boolean;
}
/**
 * Which models the picker is allowed to show.
 *
 * `free` is the default: only models the product configuration prices `x0.00`.
 * `all` lifts the filter and exposes every model the account can reach, which
 * means paid models become selectable and their credit cost is real.
 */
type WorkBuddyModelScope$1 = 'free' | 'all';
/** A token-free account row shown in the region tab. */
interface WorkBuddyWebAccount {
  id: string;
  nickname?: string;
  note?: string;
  domain?: string;
  source?: 'desktop' | 'dsh';
  edition?: WorkBuddyAccountEdition;
  expiresAt?: number;
  selected: boolean;
  checkinEnabled?: boolean;
  /** Today's check-in state for this account; absent when it was never read. */
  checkin?: {
    todayCheckedIn?: boolean;
    todayCredit?: number;
    streakDays?: number;
  };
  /** Growth-plan ("小猫成长计划") state; absent when it was never read. */
  growth?: {
    state: string;
    dailyLimitReached?: boolean;
    rewardCredit?: number;
    arriveAt?: number;
    locationName?: string;
    claimedToday?: number;
  };
  /** Growth-center tasks still unclaimed today; absent when no sweep has run. */
  tasks?: {
    outstanding: number;
  };
  credits?: WorkBuddyWebCredits;
  creditsError?: string;
  connectivity?: {
    state: 'unknown' | 'checking' | 'ok' | 'error';
    checkedAt?: number;
    message?: string;
  };
}
interface WorkBuddyWebCheckin {
  supported: boolean;
  enabled: boolean;
  active?: boolean;
  todayCheckedIn?: boolean;
  streakDays?: number;
  dailyCredit?: number;
  /** What today actually paid out, which differs from `dailyCredit` on a bonus day. */
  todayCredit?: number;
  error?: string;
}
interface WorkBuddyWebRegion {
  region: 'cn' | 'global';
  signedIn: boolean;
  selectedAccountId?: string;
  accounts: readonly WorkBuddyWebAccount[];
  models?: readonly WorkBuddyWebModelBadge[];
  probe?: WorkBuddyWebProbeSection;
  scope?: WorkBuddyModelScope$1;
  freeIds?: readonly string[];
  priceSource?: 'upstream';
  checkin?: WorkBuddyWebCheckin;
}
/** The JSON document the plugin card renders. */
type WorkBuddyWebStatus = {
  status: 'signed-out';
  controlKey?: string;
  regions?: readonly WorkBuddyWebRegion[];
} | {
  status: 'signed-in';
  nickname?: string;
  domain?: string;
  source?: 'desktop' | 'dsh';
  expiresAt?: number;
  credits?: WorkBuddyWebCredits;
  creditsError?: string;
  /** Billing convenience facts for the models the plugin serves. */
  models?: readonly WorkBuddyWebModelBadge[];
  /** Reasoning-effort probe state, consent, and recorded observations. */
  probe?: WorkBuddyWebProbeSection;
  /** The active billing policy. */
  scope?: WorkBuddyModelScope$1;
  /** Model ids the selected region's live catalog prices free. */
  freeIds?: readonly string[];
  /** Where the price data came from, for the card's provenance line. */
  priceSource?: 'upstream';
  /**
   * In-process key authorizing control writes. Handed to the card with the
   * status document (the card is same-origin and already had to pass the
   * loopback guard); it is never persisted and rotates per process.
   */
  controlKey?: string;
  regions?: readonly WorkBuddyWebRegion[];
  refreshPolicy?: {
    activeMinutes: number;
    inactiveMinutes: number;
  };
  autoCheckin?: boolean;
} | {
  status: 'error';
  message: string;
};
/** Action requested from the control route. */
type WorkBuddyControlAction = {
  action: 'probe';
  model: string;
} | {
  action: 'clearProbe';
} | {
  action: 'setScope';
  scope: WorkBuddyModelScope$1;
  region?: 'cn' | 'global';
} | {
  action: 'loginStart';
  region?: 'cn' | 'global';
} | {
  action: 'loginPoll';
  region?: 'cn' | 'global';
} | {
  action: 'logout';
  region?: 'cn' | 'global';
} | {
  action: 'selectAccount';
  region: 'cn' | 'global';
  accountId: string;
} | {
  action: 'removeAccount';
  region: 'cn' | 'global';
  accountId: string;
} | {
  action: 'setAccountNote';
  region: 'cn' | 'global';
  accountId: string;
  note: string;
} | {
  action: 'setCheckinEnabled';
  accountId: string;
  enabled: boolean;
} | {
  action: 'checkin';
  accountId: string;
} | {
  action: 'connectivity';
  region: 'cn' | 'global';
  accountId?: string;
} | {
  action: 'setRefreshPolicy';
  activeMinutes: number;
  inactiveMinutes: number;
} | {
  action: 'setAutoCheckin';
  enabled: boolean;
} | {
  action: 'setModelEnabled';
  model: string;
  enabled: boolean;
  region?: 'cn' | 'global';
} | {
  action: 'setModelsEnabled';
  models: readonly string[];
  enabled: boolean;
  region?: 'cn' | 'global';
};
//#endregion
//#region src/auth.d.ts
/** Normalized WorkBuddy credential, timestamps in epoch milliseconds. */
interface WorkBuddyCredential {
  accessToken: string;
  refreshToken: string;
  expiresAtMs: number;
  refreshExpiresAtMs?: number;
  domain: string;
  uid: string;
  enterpriseId?: string;
  nickname?: string;
  /** Official account type; absent means an older auth file had no type field. */
  edition?: WorkBuddyAccountEdition;
  /** Which storage the credential was read from; refreshes are always `dsh`. */
  source: 'desktop' | 'dsh';
}
/** Read-only sign-in summary for status and doctor output. */
interface WorkBuddyAuthStatus {
  state: 'signed-in' | 'signed-out';
  expiresAtMs?: number;
  refreshExpiresAtMs?: number;
  nickname?: string;
  domain?: string;
  edition?: WorkBuddyAccountEdition;
  source?: 'desktop' | 'dsh';
}
/** Constructor options; only {@link refresh} is required. */
interface WorkBuddyStoreOptions {
  /** Explicit desktop auth-file path, overriding env and platform defaults. */
  desktopPath?: string;
  /** Explicit plugin-owned copy path, defaulting under `$DSH_HOME`. */
  ownPath?: string;
  /** Region used by the account-aware store; the legacy store defaults global. */
  region?: WorkBuddyRegion;
  /** Performs the upstream token refresh. */
  refresh: (credential: WorkBuddyCredential) => Promise<WorkBuddyRefreshOutcome>;
  /** Refresh this long before actual expiry; default five minutes. */
  refreshMarginMs?: number;
}
/** Basename of the plugin-owned credential copy inside the Harness home. */
declare const WORKBUDDY_AUTH_FILENAME = ".workbuddy-ai-auth.json";
/** Region-scoped plugin copy for domestic credentials. */
declare const WORKBUDDY_CN_AUTH_FILENAME = ".workbuddy-cn-auth.json";
/** Env variable that overrides the desktop auth-file location. */
declare const WORKBUDDY_AUTH_FILE_ENV = "WORKBUDDY_AUTH_FILE";
/** Domestic desktop path override. */
declare const WORKBUDDY_CN_AUTH_FILE_ENV = "WORKBUDDY_CN_AUTH_FILE";
/** Domestic desktop auth basename. */
declare const WORKBUDDY_CN_DESKTOP_AUTH_BASENAME = "workbuddy-desktop.info";
/**
 * Basename of the WorkBuddy **international** desktop auth document.
 *
 * The domestic build writes `workbuddy-desktop.info` in the same directory;
 * only the `.ai` suffix names the overseas sign-in this plugin is built for.
 */
declare const WORKBUDDY_DESKTOP_AUTH_BASENAME = "workbuddy-desktop-ai.info";
/** Plugin-owned copy path inside the Harness home. */
declare function workBuddyOwnAuthPath(): string;
/** Plugin-owned primary path for a region; global keeps the legacy filename. */
declare function workBuddyRegionOwnAuthPath(region: WorkBuddyRegion): string;
/**
 * Platform-default candidates for the WorkBuddy **international** desktop
 * app's auth file, in probe order. Windows probes both AppData roots: current
 * builds write under `%LOCALAPPDATA%` (Local), older ones under `%APPDATA%`
 * (Roaming). WSL probes those same Windows locations through its mounted
 * Windows profile before the native Linux location.
 */
declare function defaultDesktopAuthCandidates(): string[];
/** First platform-default candidate; see {@link defaultDesktopAuthCandidates}. */
declare function defaultDesktopAuthPath(): string | undefined;
/** Normalize the official account `type` field without guessing from entitlements. */
declare function normalizeAccountEdition(value: unknown): WorkBuddyAccountEdition | undefined;
interface WorkBuddyAuthIdentity {
  uid?: string;
  edition?: WorkBuddyAccountEdition;
}
/** Read token-free official account identity, including encrypted desktop auth files. */
declare function parseWorkBuddyAuthIdentity(text: string): WorkBuddyAuthIdentity | undefined;
declare function parseWorkBuddyAuth(text: string): WorkBuddyCredential | undefined;
/**
 * Turn the official CLI `/v2/plugin/auth/token` payload into a credential.
 * Identity fields come from the access-token JWT; the desktop file is not used.
 */
declare function credentialFromPluginToken(data: Record<string, unknown>, region?: WorkBuddyRegion): WorkBuddyCredential;
/** Minimal store contract shared by legacy and multi-account stores. */
interface WorkBuddyCredentialStoreLike {
  current(): Promise<WorkBuddyCredential | undefined>;
  resolve(): Promise<WorkBuddyCredential>;
  status(): Promise<WorkBuddyAuthStatus>;
  importCredential(credential: WorkBuddyCredential): Promise<WorkBuddyCredential>;
  logout(): Promise<void>;
}
/**
 * Read-only credential store with demand-driven refresh.
 *
 * Refresh policy: refresh only when the access token is inside the margin (or
 * already expired), keep the refreshed credential in the plugin-owned copy,
 * and never write the desktop app's file. A failed refresh still returns a
 * not-yet-expired token, so an unreachable refresh endpoint does not take down
 * a working session.
 */
declare class WorkBuddyCredentialStore implements WorkBuddyCredentialStoreLike {
  private readonly refresh;
  private readonly refreshMarginMs;
  private readonly ownPath;
  private desktopPathOverride;
  private inflight;
  constructor(options: WorkBuddyStoreOptions);
  /**
   * Configuration precedence for the desktop file: the plugin's configured
   * path, then the environment variable, then the platform defaults. An
   * explicit path is used verbatim; the defaults are a probe order.
   */
  private resolveDesktopCandidates;
  private resolveDesktopPath;
  /** Repoint the desktop file; a settings change applies on the next read. */
  setDesktopPath(path: string | undefined): void;
  /** The resolved desktop auth-file path, for diagnostics. */
  desktopAuthPath(): string | undefined;
  /** The plugin-owned copy path, for diagnostics. */
  ownAuthPath(): string;
  /** Read the freshest stored credential without refreshing anything. */
  current(): Promise<WorkBuddyCredential | undefined>;
  /**
   * The credential to send upstream: {@link current}, refreshed on demand.
   * Single-flight, so parallel requests share one refresh.
   */
  resolve(): Promise<WorkBuddyCredential>;
  /** Read-only sign-in summary; never refreshes and never throws. */
  status(): Promise<WorkBuddyAuthStatus>;
  /** Remove the plugin-owned copy; the desktop file is untouched. */
  logout(): Promise<void>;
  /** Persist a browser-OAuth credential into the plugin-owned copy. */
  importCredential(credential: WorkBuddyCredential): Promise<WorkBuddyCredential>;
  private needsRefresh;
  private refreshNow;
  private saveOwn;
  /**
   * Read the first desktop candidate that exists. Only an absent file (ENOENT)
   * falls through to the next candidate; a file that is present but unparsable
   * is authoritative for its slot, so a stale older-version file never silently
   * wins over a broken newer one.
   */
  private readDesktop;
  private readOwn;
  /** Whether any desktop-file candidate exists as a regular file; diagnostics only. */
  desktopFilePresent(): Promise<boolean>;
}
/** Token-free account row exposed to the settings card. */
interface WorkBuddyAccountSummary {
  id: string;
  region: WorkBuddyRegion;
  nickname?: string;
  note?: string;
  domain?: string;
  source: 'desktop' | 'dsh';
  edition: WorkBuddyAccountEdition;
  expiresAtMs: number;
  selected: boolean;
  checkinEnabled: boolean;
}
interface WorkBuddyCreditSnapshot {
  credits?: WorkBuddyCredits;
  error?: string;
  checkedAt: number;
}
/**
 * Region-aware, multi-account store. The legacy primary file remains in its
 * version-1 shape for CLI/backward compatibility; additional accounts live in a
 * token-bearing sidecar owned by this plugin only.
 */
declare class WorkBuddyAccountStore implements WorkBuddyCredentialStoreLike {
  private readonly accountRefresh;
  private readonly accountRefreshMarginMs;
  private readonly region;
  private readonly accountOwnPath;
  private readonly accountsPath;
  private desktopPathOverride;
  private selectedAccountId;
  private records;
  private inflight;
  private creditSnapshots;
  private creditInflight;
  constructor(options: WorkBuddyStoreOptions);
  accountRegion(): WorkBuddyRegion;
  private desktopBasename;
  private desktopEnv;
  private desktopCandidates;
  setDesktopPath(path: string | undefined): void;
  desktopAuthPath(): string | undefined;
  ownAuthPath(): string;
  accountsAuthPath(): string;
  private readAccounts;
  private readPrimary;
  private readDesktopCredential;
  private readDesktopIdentity;
  private persist;
  private needsRefresh;
  private refreshAccount;
  accounts(): Promise<readonly WorkBuddyAccountSummary[]>;
  /** Fill missing editions from the upstream's official account profile once. */
  refreshAccountEditions(fetchEdition: (credential: WorkBuddyCredential) => Promise<WorkBuddyAccountEdition | undefined>): Promise<void>;
  current(): Promise<WorkBuddyCredential | undefined>;
  credentialFor(accountId: string): Promise<WorkBuddyCredential | undefined>;
  checkinSupported(accountId: string): Promise<boolean>;
  selectedId(): string | undefined;
  resolveFor(accountId: string): Promise<WorkBuddyCredential>;
  resolve(): Promise<WorkBuddyCredential>;
  status(): Promise<WorkBuddyAuthStatus>;
  refreshCreditSnapshots(fetchCredits: (credential: WorkBuddyCredential) => Promise<WorkBuddyCredits>, activeIntervalMs: number, inactiveIntervalMs: number): Promise<ReadonlyMap<string, WorkBuddyCreditSnapshot>>;
  creditSnapshot(accountId: string): WorkBuddyCreditSnapshot | undefined;
  select(accountId: string): Promise<void>;
  importCredential(credential: WorkBuddyCredential, accountId?: string): Promise<WorkBuddyCredential>;
  setCheckinEnabled(accountId: string, enabled: boolean): Promise<void>;
  /** Store a note and return the normalized value kept, or undefined when cleared. */
  setNote(accountId: string, note: string): Promise<string | undefined>;
  removeAccount(accountId: string): Promise<void>;
  /** Existing logout semantics: remove all plugin-owned credentials, never desktop auth. */
  logout(): Promise<void>;
}
//#endregion
//#region src/probe.d.ts
/**
 * The canonical values a probe tests, in a fixed order.
 *
 * `minimal` is absent: it appears in no upstream vocabulary. `off` is absent
 * by policy — disabling thinking is a separate capability the upstream must
 * declare through `canDisableThinking`, never something probing may infer.
 */
declare const PROBE_EFFORT_CANDIDATES: readonly WorkBuddyEffort[];
/** Sentinel generator; injectable so tests get deterministic values. */
type SentinelFactory = () => string;
/** Default sentinel: unmistakably non-canonical, different on every call. */
declare function randomSentinel(): string;
/**
 * One response as the probe sees it, split into the only distinctions the
 * attribution rule needs.
 */
interface ProbeAttempt {
  /** HTTP status, or 0 for a transport failure. */
  status: number;
  /** True when a parseable SSE event arrived. */
  streamed: boolean;
  /** `extError.code` from a JSON error body, when present. */
  errorCode?: string;
  /** Free-form detail for logs; never shown as a capability claim. */
  detail?: string;
}
/** How one attempt is performed; the caller owns credentials and HTTP. */
type ProbeSender = (effort: string | undefined, signal: AbortSignal) => Promise<ProbeAttempt>;
/** The outcome of probing one model. */
type ProbeOutcome = {
  validation: 'validating';
  efforts: readonly WorkBuddyEffort[];
  requests: number;
} | {
  validation: 'non-validating';
  efforts: readonly [];
  requests: number;
} | {
  validation: 'unknown';
  efforts: readonly [];
  requests: number;
  reason: string;
};
/**
 * Probe one model.
 *
 * `options.candidates` exists so tests can shorten the sweep; production always
 * uses {@link PROBE_EFFORT_CANDIDATES}.
 */
declare function probeModel(options: {
  send: ProbeSender;
  sentinel?: SentinelFactory;
  candidates?: readonly WorkBuddyEffort[];
  timeoutMs?: number;
}): Promise<ProbeOutcome>;
//#endregion
//#region src/upstream.d.ts
/** WorkBuddy region selected by the credential's login domain. */
type WorkBuddyRegion = 'cn' | 'global';
/** Upstream failure classes the shim maps onto distinct HTTP answers. */
type UpstreamErrorKind = 'hard_credit' | 'soft_rate' | 'session_dead' | 'not_found' | 'server' | 'client';
/** One CLI-usable model as the upstream catalog describes it. */
interface WorkBuddyUpstreamModel {
  id: string;
  name: string;
  contextWindow: number;
  maxTokens: number;
  /**
   * Upstream-declared image input capability. Missing or false upstream data
   * resolves to false, so an unknown model stays text-only: over-claiming
   * admits an image the provider then rejects after the message is durable.
   */
  supportsImages: boolean;
  /**
   * Reasoning metadata the upstream catalog declares per model. The wire effort
   * values (`low`, `medium`, `high`, `xhigh`, `max`) map directly onto pi-ai's
   * thinking levels, and the supported set decides which levels the DSH model
   * selector offers.
   */
  reasoning?: WorkBuddyModelReasoning;
  /**
   * Billing convenience metadata: the credits multiplier the upstream reports
   * (e.g. `"x0.00"` for free) and promotional badges like
   * `badge:限时免费:#FF0000`.
   *
   * The multiplier reaches the browser through the host LLM seam, which has no
   * locale service, so {@link normalizeCredits} trims it to a language-neutral
   * display form (`x0.79`) that reads the same in every UI language.
   */
  billing?: WorkBuddyModelBilling;
}
/** Reasoning metadata the upstream catalog declares for one model. */
interface WorkBuddyModelReasoning {
  /** Whether the model does any reasoning at all (upstream `supportsReasoning`). */
  supports: boolean;
  /** Whether the model can only think (upstream `onlyReasoning`). */
  onlyReasoning: boolean;
  /** Selectable effort values; absent means the model has no explicit set. */
  supportedEfforts?: readonly WorkBuddyEffort[];
  /** Default effort the upstream uses when none is chosen. */
  defaultEffort?: WorkBuddyEffort;
  /** Whether thinking can be switched off; false means it is always on. */
  canDisableThinking: boolean;
}
/** The concrete effort spellings WorkBuddy exposes on the wire. */
type WorkBuddyEffort = 'low' | 'medium' | 'high' | 'xhigh' | 'max';
/** Billing convenience metadata reported for one model. */
interface WorkBuddyModelBilling {
  /** Credits multiplier, e.g. `"x0.00"` (free) or `"x0.79"`. */
  credits?: string;
  /** Promotional tags, e.g. `"限时免费"`, `"夜间折扣"`. */
  badges?: readonly string[];
  /** Whether the model is currently free (`x0.00` credits). */
  free: boolean;
}
/** One billing package and its remaining credit. */
interface WorkBuddyCreditAccount {
  packageName: string;
  remain: number;
  size: number;
  /**
   * Upstream `CapacityType`. `4` is the monthly plan quota (`套餐基础积分`),
   * `1` a granted bonus pack (`平台奖励积分`); the app groups credits by this
   * and never shows the upstream package name. Verified identical on both
   * regions: the global account reports `Free Plan Subscription` type 4 and
   * `Bonus Pack` type 1.
   */
  capacityType: number;
  /**
   * When this package stops being usable, as epoch ms. The upstream leaves
   * `ExpiredTime` empty on every package it reports and puts the real end on
   * `CycleEndTime` (`YYYY-MM-DD HH:mm:ss`), so that is the field read.
   */
  expiresAt?: number;
}
/** Aggregated credit answer for one credential. */
interface WorkBuddyCredits {
  total: number;
  accounts: readonly WorkBuddyCreditAccount[];
}
/** Token refresh answer; fields the upstream omits stay absent. */
interface WorkBuddyRefreshOutcome {
  accessToken: string;
  refreshToken?: string;
  expiresInSec?: number;
  domain?: string;
}
/** Chat answer: either a live SSE response or a classified failure. */
type WorkBuddyChatResult = {
  ok: true;
  response: Response;
} | {
  ok: false;
  status: number;
  kind: UpstreamErrorKind;
  message: string;
};
declare function normalizeCredits(credits: string | undefined): string | undefined;
/**
 * Whether a credits multiplier means "free".
 *
 * Only an explicit `x0.00` (with or without the `x`, any number of decimals)
 * counts. An absent multiplier is *not* free: the upstream omits the field for
 * some rows and treating absence as free would advertise a paid model.
 */
declare function isFreeCredits(credits: string | undefined): boolean;
/** Classify an upstream failure from its HTTP status and body excerpt. */
declare function classifyUpstreamError(status: number, body: string): UpstreamErrorKind;
/**
 * Region for a login domain.
 *
 * An empty domain resolves to `global`, not `cn`: this plugin is the
 * international one, so an unlabelled credential is treated as belonging to the
 * deployment it was configured for. A credential that names the domestic domain
 * still routes domestic, because the `domain` field is the upstream's own
 * routing fact and second-guessing it would send a `.cn` token to `.ai`.
 */
declare function regionOf(domain: string): WorkBuddyRegion;
/**
 * Normalize an OpenAI chat-completions body for the WorkBuddy upstream.
 *
 * Three rewrites, each fixing a measured rejection:
 *
 * 1. `stream` is forced true — the upstream refuses a non-streaming chat call.
 * 2. `role: "developer"` becomes `role: "system"` — pi-ai emits the system
 *    prompt with the OpenAI `developer` role, which this upstream answers with
 *    HTTP 400 code 11128.
 * 3. `tool_choice` is flattened to the string form the upstream expects; an
 *    object form returns 400.
 *
 * It additionally guarantees the upstream's "first message is system prompt"
 * rule: a request whose first message is not a system message is answered with
 * code 11128 and never reaches a model. DSH normally supplies a system prompt,
 * but a session with an empty instruction set would otherwise fail every call,
 * so a minimal one is prepended rather than letting the request die.
 *
 * 4. `rewriteHarnessBanner` renames the brand word in the harness identity
 *    banner, which the domestic gateway fingerprints at the sentence start.
 *
 * A fifth rewrite is conditional: when the row is declared `onlyReasoning`
 * (thinking cannot be switched off) and the body carries no `reasoning_effort`,
 * the caller's fixed effort is injected. pi-ai only emits that parameter when an
 * effort was actually selected *or* `thinkingLevelMap.off` is a wire value; with
 * neither, the field is absent, upstream builds no `reasoning_content` channel,
 * and the model's `<analysis>` scaffolding spills into the visible content.
 *
 * @param source - the JSON request body pi-ai produced.
 * @param fixedEffort - the effort to force when the body has none, if any.
 * @returns the rewritten body, or the input unchanged when it is not a JSON object.
 */
declare function prepareChatBody(source: string, fixedEffort?: string): string;
/**
 * Upstream HTTP client. One instance serves the whole plugin; requests take the
 * credential explicitly so token refreshes apply on the next call.
 */
declare class WorkBuddyUpstreamClient {
  /** POST the chat endpoint; a successful answer is the raw SSE response. */
  chatStream(credential: WorkBuddyCredential, bodyJson: string, signal?: AbortSignal): Promise<WorkBuddyChatResult>;
  /** POST the token-refresh endpoint; the caller merges the outcome. */
  refreshToken(credential: WorkBuddyCredential): Promise<WorkBuddyRefreshOutcome>;
  /** POST the official CLI login start; returns the browser `authUrl`. */
  startPluginLogin(nonce: string, region?: WorkBuddyRegion): Promise<{
    state: string;
    authUrl: string;
  }>;
  /**
   * GET the CLI login token. Envelope code `11217` means the browser has not
   * finished yet — returns `undefined` so the caller can poll again.
   */
  pollPluginToken(state: string, region?: WorkBuddyRegion): Promise<Record<string, unknown> | undefined>;
  /**
   * GET the personal model catalog from the region's own path and keep the
   * `cli` agent's models only.
   *
   * The path is chosen from the credential's domain (see {@link CATALOG_PATH}):
   * the overseas host answers the domestic path with HTTP 500, so this is what
   * makes an international sign-in work at all.
   */
  fetchModels(credential: WorkBuddyCredential): Promise<readonly WorkBuddyUpstreamModel[]>;
  /** GET one catalog path and keep the `cli` agent's models only. */
  private readCatalog;
  /** Read the official account type without inferring it from entitlements. */
  fetchAccountEdition(credential: WorkBuddyCredential): Promise<WorkBuddyAccountEdition | undefined>;
  /** POST the billing endpoint for the aggregated remaining credit. */
  fetchCredits(credential: WorkBuddyCredential): Promise<WorkBuddyCredits>;
  /** A catalog request is a low-cost connectivity check; it never sends a chat completion. */
  testConnectivity(credential: WorkBuddyCredential): Promise<void>;
  /** Read the domestic daily-check-in state. International accounts do not support this API. */
  fetchCheckinStatus(credential: WorkBuddyCredential): Promise<{
    active: boolean;
    todayCheckedIn: boolean;
    streakDays?: number;
    dailyCredit?: number;
    todayCredit?: number;
  }>;
  /** Claim the domestic daily check-in reward after status says it is needed. */
  claimDailyCheckin(credential: WorkBuddyCredential): Promise<void>;
  /**
   * One probe request: a real streaming chat call carrying the effort under
   * test.
   *
   * Shares {@link chatHeaders} with the normal chat path on purpose — a probe
   * must describe what a real message would experience, not a parallel code
   * path. The caller aborts as soon as a parseable event arrives; the body is
   * never assembled into an answer. `reasoning_effort` is omitted entirely
   * (rather than sent empty) when `effort` is undefined, so the baseline case is
   * a genuinely bare request.
   */
  probeEffort(credential: WorkBuddyCredential, model: string, effort: string | undefined, signal: AbortSignal): Promise<ProbeAttempt>;
}
/** Where the buddy is, and what is still claimable. */
interface WorkBuddyGrowthStatus {
  /** `idle` | `traveling` | `arrived`; anything else is an upstream surprise. */
  state: string;
  recordId?: number;
  /** Today's travel is used up (claimed or dispatched and already handled). */
  dailyLimitReached: boolean;
  /** Credit the pending trip pays on arrival; 0 when idle. */
  rewardCredit?: number;
  arriveAt?: number;
  locationName?: string;
}
/**
 * Read the growth-plan state.
 *
 * Deliberately read-only: a `GET` here is what the card polls, and it must
 * never be the call that dispatches a trip.
 */
declare function fetchGrowthStatus(credential: WorkBuddyCredential): Promise<WorkBuddyGrowthStatus>;
/**
 * What today's trip paid, read from the trip log.
 *
 * `/status` cannot answer this: once the buddy is idle it reports
 * `reward_credit: 0` whether or not a payout happened, so the card could only
 * ever say "今日旅行已完成" and hide the credits. `/records` is the log of
 * finished trips and keeps the real amount per day.
 *
 * Returns `undefined` when there is no finished trip today, so the caller can
 * tell "not yet" apart from "paid zero".
 */
declare function fetchGrowthRewardToday(credential: WorkBuddyCredential, day: string): Promise<number | undefined>;
/**
 * Send the buddy on a trip, then claim whatever is already claimable.
 *
 * One call, because the two halves belong together: a card that dispatches at
 * dusk and claims at dawn is a card the user has to come back for. `claim` is
 * idempotent upstream (it reports "nothing to claim" rather than erroring), so
 * calling it first is safe and is what lets a trip that arrived while DSH was
 * closed get its credit on the next poll.
 *
 * `locationId` of 0 means "no preference": the first destination from `/config`
 * is used. It cannot mean "send no location" — the upstream answers that with
 * HTTP 400, which is what made this a silent no-op on the card.
 */
declare function runGrowthTrip(credential: WorkBuddyCredential, locationId?: number): Promise<{
  dispatched: boolean;
  claimed?: number;
  reason?: string;
}>;
//#endregion
//#region src/catalog.d.ts
/** One model entry the adapter exposes. */
type WorkBuddyModelInfo = WorkBuddyUpstreamModel;
/** How the catalog decides which models the picker may show. */
type WorkBuddyModelScope = 'free' | 'all';
/** Constructor dependencies for {@link WorkBuddyCatalog}. */
interface WorkBuddyCatalogOptions {
  /** Which models the picker may show; see {@link WorkBuddyModelScope}. */
  scope?: WorkBuddyModelScope;
}
/**
 * Apply the billing policy to the region's upstream rows.
 *
 * The filter runs last and only over the rows the region actually returned: an
 * empty upstream yields an empty list, deliberately. A region with no answer
 * yet must not borrow another region's models, or a sign-in to one deployment
 * would advertise the other's lineup.
 *
 * @param upstream - rows from the live catalog; empty before the first fetch.
 * @param options - the active billing policy.
 * @returns the effective model list, upstream order preserved.
 */
declare function composeCatalog(upstream: readonly WorkBuddyModelInfo[], options?: WorkBuddyCatalogOptions): readonly WorkBuddyModelInfo[];
/**
 * The plugin's live catalog.
 *
 * `scope` is mutable because the settings card can flip between "free only" and
 * "all models" without a restart; the adapter rebuilds its snapshot from
 * {@link current} on every read, so a change lands on the next request.
 */
declare class WorkBuddyCatalog {
  private upstream;
  private scope;
  /**
   * Models the user switched off in the card. Kept here rather than folded into
   * `scope` because the two answer different questions: the scope decides which
   * models are *offered*, this decides which of the offered ones the picker still
   * *lists*. Absent ids are enabled, so an install that never touched the
   * switches behaves exactly as before.
   */
  private disabled;
  /**
   * Models the upstream refused for *this* account ("model [...] is not allowed
   * for user type [...]"). The catalog never says who may use what — the refusal
   * only shows up on a real request — so it is learned from failures and kept
   * for the session. Not persisted: availability changes with the plan.
   */
  private unavailable;
  constructor(options?: WorkBuddyCatalogOptions);
  /** Replace the upstream rows; the effective list is recomposed immediately. */
  setUpstream(models: readonly WorkBuddyModelInfo[]): void;
  /** Record that the upstream refused this model for the signed-in account. */
  markUnavailable(id: string): void;
  /** Whether a previous request was refused for this account. */
  isUnavailable(id: string): boolean;
  /** The upstream rows as last received, before any policy is applied. */
  upstreamModels(): readonly WorkBuddyModelInfo[];
  /** Switch the billing policy; takes effect on the next {@link current} read. */
  setScope(scope: WorkBuddyModelScope): void;
  /**
   * Replace the set of models the picker must not list.
   *
   * This never touches {@link current}: the pi-ai snapshot that resolves a
   * request is built from it, so dropping a model here would turn a switched-off
   * model into `UNKNOWN_MODEL` for a session that had already selected it. The
   * filter is applied one layer up, in the adapter's `listModels`, which is what
   * the picker reads and the request path does not.
   */
  setDisabled(ids: readonly string[]): void;
  /** The ids the picker must not list. */
  disabledIds(): readonly string[];
  /** Whether one model is switched off. */
  isDisabled(id: string): boolean;
  /** The active billing policy. */
  currentScope(): WorkBuddyModelScope;
  /** The effective entries; empty until the region's catalog arrives. */
  current(): readonly WorkBuddyModelInfo[];
  /** Every model in this region, before the free/all picker policy is applied. */
  all(): readonly WorkBuddyModelInfo[];
  /** Every model id this region prices as free. */
  freeIds(): readonly string[];
  /** Whether a model is free according to this region's authority. */
  isFree(id: string): boolean;
  /** Display suffix for one row: the rate, then any promotional badges. */
  displaySuffix(id: string): string | undefined;
}
//#endregion
//#region src/probe-store.d.ts
/** Basename of the probe record inside the Harness home. */
declare const WORKBUDDY_PROBE_FILENAME = ".workbuddy-ai-probe.json";
/**
 * Whether the model's effort parameter is actually validated.
 *
 * - `validating`: the upstream rejected an unknown sentinel value, so a
 *   per-level answer is meaningful.
 * - `non-validating`: the upstream accepted the sentinel, so it ignores or
 *   loosely coerces the parameter and no per-level answer can be trusted.
 * - `unknown`: baseline or sentinel failed for an unrelated reason (auth,
 *   rate limit, transport, ambiguous error body). Not a negative claim.
 */
type WorkBuddyProbeValidation = 'validating' | 'non-validating' | 'unknown';
/** One model's recorded observation. */
interface WorkBuddyProbeRecord {
  /** Fingerprint of the catalog row this observation was made against. */
  fingerprint: string;
  validation: WorkBuddyProbeValidation;
  /** Efforts verified as accepted; only ever non-empty for `validating`. */
  efforts: readonly WorkBuddyEffort[];
  /** When the probe ran, epoch milliseconds. */
  probedAtMs: number;
  /** Plugin version that produced the record. */
  pluginVersion: string;
}
/** Plugin-owned probe record path inside the Harness home. */
declare function workBuddyProbePath(): string;
/**
 * Fingerprint the catalog fields a probe depends on.
 *
 * Deliberately excludes display-only fields (`name`, `billing`, `contextWindow`)
 * so a rename or a promo badge does not throw away a valid observation, and
 * deliberately includes the whole reasoning object so any change to the
 * declared shape re-probes.
 */
declare function fingerprintModel(info: WorkBuddyModelInfo): string;
/** Options for {@link WorkBuddyProbeStore}. */
interface WorkBuddyProbeStoreOptions {
  /** Explicit state-file path, overriding the `$DSH_HOME` default. */
  path?: string;
  /** Observation lifetime; defaults to 14 days. */
  ttlMs?: number;
  /** Plugin version stamped into new records. */
  pluginVersion: string;
  /** Clock injection for tests. */
  now?: () => number;
}
/**
 * The plugin's probe records: read once, written atomically, never trusted
 * across a fingerprint change or past the TTL.
 */
declare class WorkBuddyProbeStore {
  private readonly path;
  private readonly ttlMs;
  private readonly pluginVersion;
  private readonly now;
  private records;
  constructor(options: WorkBuddyProbeStoreOptions | string);
  /** Resolved state-file path, for the CLI and tests. */
  filePath(): string;
  private load;
  /**
   * The usable record for a model, or `undefined` when there is none, it is
   * expired, or it was taken against a different catalog row.
   */
  get(modelId: string, fingerprint: string): WorkBuddyProbeRecord | undefined;
  /**
   * Store one observation. Only a decisive answer (`validating` /
   * `non-validating`) replaces an existing decisive record: a transient
   * `unknown` must not erase knowledge the user already paid for.
   */
  set(modelId: string, record: WorkBuddyProbeRecord): void;
  /** Drop every record; used by the card's explicit "clear" action. */
  clear(): void;
  /** Every record currently held, for status display. */
  all(): Readonly<Record<string, WorkBuddyProbeRecord>>;
  /** Build a record stamped with this store's clock and version. */
  record(fingerprint: string, validation: WorkBuddyProbeValidation, efforts: readonly WorkBuddyEffort[]): WorkBuddyProbeRecord;
  /**
   * Write through a temporary file and rename, so a crash mid-write cannot
   * leave a half-parsed document that reads as "no records" and silently drops
   * every observation.
   */
  private persist;
}
//#endregion
//#region src/shim.d.ts
/** Minimal logger surface the plugin context already provides. */
interface ShimLogger {
  warn(...args: unknown[]): void;
  error(...args: unknown[]): void;
}
/** What the plugin needs from a running shim. */
interface WorkBuddyShim {
  /** Resolves once the listener is up; rejects if listening failed. */
  ready: Promise<void>;
  /** The shim origin, e.g. `http://127.0.0.1:39271`; valid after ready. */
  baseUrl(): string;
  /**
   * The per-process shared secret the plugin's own client must carry as
   * `Authorization: Bearer <token>`. Lives only in memory; the adapter resolves
   * this instead of the upstream access token, because the shim resolves the
   * real credential itself via the store.
   */
  token(): string;
  /** Stop serving and destroy open connections. */
  close(): Promise<void>;
}
/** Constructor dependencies. */
interface WorkBuddyShimOptions {
  store: WorkBuddyCredentialStoreLike;
  client: Pick<WorkBuddyUpstreamClient, 'chatStream'>;
  catalog: WorkBuddyCatalog;
  /**
   * Called after a refusal is recorded on the catalog, so the host can re-emit
   * its model list and the picker stops offering a model this account cannot use.
   */
  onModelUnavailable?: (id: string) => void;
  logger?: ShimLogger;
}
/**
 * Start the loopback endpoint. Requests carry the shim's own bearer; the
 * upstream credential comes from the store alone and never reaches the caller.
 */
declare function createWorkBuddyShim(options: WorkBuddyShimOptions): WorkBuddyShim;
//#endregion
//#region src/adapter.d.ts
/**
 * Provider route this bundle owns.
 *
 * Distinct from the domestic plugin's `workbuddy` on purpose: both routes may be
 * mounted in one profile, and the LLM registry rejects a second adapter claiming
 * a route another already serves.
 */
declare const WORKBUDDY_PROVIDER = "workbuddy-ai";
/** Domestic route owned by this plugin; kept distinct from other WorkBuddy bundles. */
declare const WORKBUDDY_CN_PROVIDER = "workbuddy-cn";
/** Display name shown by the model picker and configuration surfaces. */
declare const WORKBUDDY_DISPLAY_NAME = "WorkBuddy 国际版";
declare const WORKBUDDY_CN_DISPLAY_NAME = "WorkBuddy 国内版";
/** Constructor dependencies. */
interface WorkBuddyAdapterOptions {
  shim: WorkBuddyShim;
  store: WorkBuddyCredentialStoreLike;
  catalog: WorkBuddyCatalog;
  /** Defaults to the legacy international provider. */
  provider?: string;
  displayName?: string;
  /** Resolve the durable attachment service at request time, when present. */
  resolveAttachments?: () => AttachmentStore | undefined;
  /**
   * Look up a local probe observation for a model. Consulted only for rows the
   * upstream left undeclared; absent means declared-set-only behavior.
   */
  observe?: (modelId: string) => WorkBuddyProbeRecord | undefined;
}
/** What {@link createWorkBuddyAdapter} hands back. */
interface WorkBuddyAdapter {
  adapter: PiAiAdapter;
  /** Rebuild the adapter's provider snapshot; call after a catalog update. */
  invalidate: () => void;
}
declare function reasoningFields(info: WorkBuddyModelInfo, observed?: WorkBuddyProbeRecord): {
  reasoning: boolean;
  thinkingLevelMap?: ThinkingLevelMap;
};
/**
 * Assemble the adapter.
 *
 * The provider's `getModels` reads the live catalog, and every model's `baseUrl`
 * is re-resolved per read so the shim's ephemeral port applies from the first
 * snapshot after startup. The profile is constructed by hand rather than through
 * dsh-llm-pi-ai's internal `resolveProfiles()`: that helper is not part of the
 * package's public export surface, so hand-assembly is the only supported path
 * and every required field must be adopted here explicitly.
 */
declare function createWorkBuddyAdapter(options: WorkBuddyAdapterOptions): WorkBuddyAdapter;
//#endregion
//#region src/probe-service.d.ts
/** What the caller learns about a completed probe. */
type WorkBuddyProbeStatus = {
  state: 'ok';
  validation: WorkBuddyProbeRecord['validation'];
  efforts: readonly string[];
  requests: number;
} | {
  state: 'unavailable';
  reason: string;
};
/** Options for {@link WorkBuddyProbeService}. */
interface WorkBuddyProbeServiceOptions {
  store: WorkBuddyProbeStore;
  catalog: WorkBuddyCatalog;
  credentials: WorkBuddyCredentialStoreLike;
  client: WorkBuddyUpstreamClient;
  /** Whether probing is permitted at all; consulted before every sweep. */
  consent: () => boolean;
  sentinel?: SentinelFactory;
  /** Injectable for tests; defaults to the live upstream sender. */
  send?: (modelId: string) => ProbeSender;
}
/**
 * Serial probe runner. One instance is shared by the manual API and any
 * future automatic trigger, so the two can never overlap.
 */
declare class WorkBuddyProbeService {
  private readonly options;
  private queue;
  private readonly pending;
  private running;
  constructor(options: WorkBuddyProbeServiceOptions);
  /** Whether a sweep is in flight right now. */
  isRunning(): boolean;
  /**
   * The record the adapter may use for this model, or `undefined`.
   *
   * A declared set always wins, so a model that declares `supportedEfforts` is
   * never answered from an observation.
   */
  recordFor(modelId: string): WorkBuddyProbeRecord | undefined;
  /**
   * Probe one model, serially.
   *
   * The authenticated manual route supplies one-request consent after UI
   * confirmation. Other callers must pass the configured consent gate.
   * Manual consent never changes the automatic-probing configuration.
   * Explicit requests bypass historical results, but share an ongoing run.
   */
  probe(modelId: string, manualConsent?: boolean): Promise<WorkBuddyProbeStatus>;
}
//#endregion
//#region src/oauth.d.ts
/** Give up if the browser never finishes. */
declare const LOGIN_TIMEOUT_MS: number;
/** Upstream client surface this helper needs. */
type WorkBuddyOAuthClient = Pick<WorkBuddyUpstreamClient, 'startPluginLogin' | 'pollPluginToken'>;
/** One poll tick: still waiting, or a credential ready to import. */
type WorkBuddyOAuthPoll = {
  pending: true;
} | {
  auth: WorkBuddyCredential;
};
/**
 * In-process CLI login. One instance per plugin; overlapping `start()` calls
 * replace the previous wait.
 */
declare class WorkBuddyOAuthLogin {
  private readonly client;
  private readonly open;
  private readonly region;
  private waiting;
  constructor(client: WorkBuddyOAuthClient, open?: (url: string) => boolean, region?: WorkBuddyRegion);
  /** Begin a login and try to open the browser. */
  start(): Promise<{
    authUrl: string;
    opened: boolean;
  }>;
  /**
   * One poll of the login `state`. `pending` means the user has not finished;
   * otherwise the caller must persist {@link WorkBuddyOAuthPoll.auth}.
   */
  poll(): Promise<WorkBuddyOAuthPoll>;
  /** Drop an in-flight login without touching stored credentials. */
  cancel(): void;
}
//#endregion
//#region src/host-heartbeat.d.ts
/**
 * Host-side heartbeat: a small JSON file written under `$DSH_HOME` once the
 * `workbuddy-ai` provider is registered. The status CLI reads it to report
 * whether the host bundle is alive, independent of the browser card.
 *
 * The browser (client) bundle cannot write files; its health is reported only
 * through `console.error` on failure. This asymmetry is intentional: the host is
 * the load-bearing half, and a missing heartbeat unambiguously means the host
 * never started.
 *
 * @module dsh-workbuddy/host-heartbeat
 */
/** Basename of the host heartbeat file inside the Harness home. */
declare const WORKBUDDY_HOST_HEARTBEAT_FILENAME = ".workbuddy-ai-host-heartbeat.json";
/** Package name stamped into the heartbeat, so readers can tell the two plugins apart. */
declare const HEARTBEAT_PACKAGE = "dsh-workbuddy";
/** Current on-disk heartbeat format; readers reject others. */
declare const HEARTBEAT_FORMAT_VERSION = 1;
/** On-disk shape of the heartbeat. */
interface WorkBuddyHostHeartbeat {
  version: typeof HEARTBEAT_FORMAT_VERSION;
  package: typeof HEARTBEAT_PACKAGE;
  pluginVersion: string;
  /** Epoch milliseconds when the host registered the provider. */
  registeredAt: number;
  /** Host process PID, to distinguish a stale heartbeat after a crash. */
  pid: number;
}
/** Absolute path of the host heartbeat file. */
declare function workBuddyHostHeartbeatPath(): string;
/** Remove the heartbeat on plugin disposal so a stale file does not linger. */
declare function clearHostHeartbeat(): Promise<void>;
/** Read and validate the heartbeat; returns `undefined` when absent or malformed. */
declare function readHostHeartbeat(): Promise<WorkBuddyHostHeartbeat | undefined>;
/**
 * Absolute start time (epoch ms) of the process holding `pid`, or `undefined`
 * when it cannot be determined (no such PID, platform lacks a readable source).
 *
 * - macOS / Linux: `ps -o lstart=` prints a local-time "EEE MMM DD HH:MM:SS YYYY";
 *   `Date.parse` resolves it against the local clock, which matches how
 *   `registeredAt` (a `Date.now()` absolute value) is expressed.
 * - Windows: WMI `CreationDate` is UTC (`YYYYMMDDHHMMSS.mmm+zzzz`); parsed with
 *   `Date.UTC`, again comparable to `registeredAt`.
 *
 * Failures return `undefined` so callers can fall back to plain PID liveness
 * rather than mis-report a running host as dead.
 */
declare function processStartTimeMs(pid: number): number | undefined;
/**
 * Whether the heartbeat's PID is still alive *and* still the same process that
 * registered it. A stale heartbeat (host crashed without clearing the file) is
 * distinguished from a live host by two checks:
 *
 * 1. `process.kill(pid, 0)` — the PID exists (signal 0 tests existence).
 * 2. The process holding that PID started at or before `registeredAt`. A host
 *    that registered the heartbeat must have been started before writing it, so
 *    `start <= registeredAt`; a recycled PID belongs to an unrelated process
 *    started after the host died, so `start > registeredAt` correctly reads dead.
 *
 * PID-only detection is not enough: after a crash the OS may hand the same PID to
 * an unrelated process, and the un-cleared stale heartbeat would otherwise
 * produce a false "Host running". When the process start time cannot be read
 * (e.g. unsupported platform) the check degrades to plain PID liveness.
 */
declare function isHeartbeatProcessAlive(heartbeat: WorkBuddyHostHeartbeat): boolean;
//#endregion
//#region src/index.d.ts
/** Stable Cordis plugin name. */
declare const name = "llm-workbuddy-ai";
/** The model registry required before the provider can register. */
declare const inject: string[];
/**
 * Settings namespace owning the configuration card.
 *
 * A namespace is a nominal string, validated by the type system where it is used
 * rather than at runtime. The cast is applied once here so the public constant
 * carries the seam's type without pulling the brand helper into this package.
 */
declare const WORKBUDDY_SETTINGS_NS: SettingsNamespace;
/** Plugin configuration. */
interface Config {
  /** Explicit international WorkBuddy desktop auth-file path. */
  authFile?: string;
  /** Explicit domestic WorkBuddy desktop auth-file path. */
  cnAuthFile?: string;
  /** Active-account read-only refresh cadence in minutes. */
  refreshActiveMinutes?: number;
  /** Inactive-account read-only refresh cadence in minutes. */
  refreshInactiveMinutes?: number;
  /** Domestic daily check-in; off by default. */
  autoCheckin?: boolean;
  /**
   * Whether the user has authorized sending probe requests about reasoning
   * efforts. Off by default: a probe spends real credit, so nothing is sent until
   * the user explicitly agrees.
   */
  probeConsent?: boolean;
  /**
   * Which models the picker may show. `free` (the default) lists only models the
   * region's live catalog prices `x0.00`; `all` lifts the filter and makes paid
   * models selectable, so their credit cost becomes real.
   */
  modelScope?: WorkBuddyModelScope;
  /** Domestic model scope, independent from the international card. */
  cnModelScope?: WorkBuddyModelScope;
  /**
   * Model ids the picker must stop listing in the international card. Purely a
   * picker filter: an already-selected model keeps resolving and sending.
   */
  disabledModels?: string[];
  /** Same picker filter, for the domestic card. */
  cnDisabledModels?: string[];
  /**
   * Extra Host/Origin authorities for the settings card when DSH Web is
   * reached over LAN (e.g. `192.168.1.10`). Empty (the default) keeps the
   * card on loopback only. Never put LAN names into the loopback set.
   */
  allowedHosts?: string[];
}
declare const Config: z<Config>;
/**
 * Start the loopback endpoint, register the `workbuddy-ai` provider, and refresh
 * the model catalog from the upstream once credentials allow it. The list is
 * empty until a region answers: both regions are priced from their own live
 * catalog, so there is no local list to fall back to.
 */
declare function apply(ctx: Context, config: Config): void;
//#endregion
export { Config, LOGIN_TIMEOUT_MS, PROBE_EFFORT_CANDIDATES, type ProbeAttempt, type ProbeOutcome, type ProbeSender, type UpstreamErrorKind, WORKBUDDY_AUTH_FILENAME, WORKBUDDY_AUTH_FILE_ENV, WORKBUDDY_CN_AUTH_FILENAME, WORKBUDDY_CN_AUTH_FILE_ENV, WORKBUDDY_CN_DESKTOP_AUTH_BASENAME, WORKBUDDY_CN_DISPLAY_NAME, WORKBUDDY_CN_PROVIDER, WORKBUDDY_CONTROL_PATH, WORKBUDDY_DESKTOP_AUTH_BASENAME, WORKBUDDY_DISPLAY_NAME, WORKBUDDY_HOST_HEARTBEAT_FILENAME, WORKBUDDY_PROBE_FILENAME, WORKBUDDY_PROVIDER, WORKBUDDY_SETTINGS_NS, WORKBUDDY_STATUS_PATH, type WorkBuddyAccountEdition, WorkBuddyAccountStore, type WorkBuddyAccountSummary, type WorkBuddyAdapter, type WorkBuddyAuthIdentity, type WorkBuddyAuthStatus, WorkBuddyCatalog, type WorkBuddyChatResult, type WorkBuddyControlAction, type WorkBuddyCredential, WorkBuddyCredentialStore, type WorkBuddyCredentialStoreLike, type WorkBuddyCredits, type WorkBuddyEffort, type WorkBuddyGrowthStatus, type WorkBuddyHostHeartbeat, type WorkBuddyModelBilling, type WorkBuddyModelInfo, type WorkBuddyModelReasoning, type WorkBuddyModelScope, WorkBuddyOAuthLogin, type WorkBuddyProbeRecord, WorkBuddyProbeService, type WorkBuddyProbeStatus, WorkBuddyProbeStore, type WorkBuddyProbeValidation, type WorkBuddyRefreshOutcome, type WorkBuddyRegion, type WorkBuddyShim, WorkBuddyUpstreamClient, type WorkBuddyUpstreamModel, type WorkBuddyWebAccount, type WorkBuddyWebCheckin, type WorkBuddyWebModelBadge, type WorkBuddyWebProbeModel, type WorkBuddyWebProbeSection, type WorkBuddyWebRegion, type WorkBuddyWebStatus, apply, classifyUpstreamError, clearHostHeartbeat, composeCatalog, createWorkBuddyAdapter, createWorkBuddyShim, credentialFromPluginToken, defaultDesktopAuthCandidates, defaultDesktopAuthPath, fetchGrowthRewardToday, fetchGrowthStatus, fingerprintModel, inject, isFreeCredits, isHeartbeatProcessAlive, name, normalizeAccountEdition, normalizeCredits, parseWorkBuddyAuth, parseWorkBuddyAuthIdentity, prepareChatBody, probeModel, processStartTimeMs, randomSentinel, readHostHeartbeat, reasoningFields, regionOf, runGrowthTrip, workBuddyHostHeartbeatPath, workBuddyOwnAuthPath, workBuddyProbePath, workBuddyRegionOwnAuthPath };