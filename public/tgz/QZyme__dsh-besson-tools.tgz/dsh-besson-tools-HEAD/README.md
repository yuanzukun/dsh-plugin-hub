# dsh-besson-tools

北山Besson（BeiShan_Besson）Minecraft 模组开发教程的 **DSH 插件**：**11 个独立组件**（每个工具一个组件），覆盖「检索 → 路线规划 → 版本迁移对比 → 环境搭建 → 正文抓取 → 工程体检 → 骨架生成 → 中文映射」全流程；内置 **Web 左栏面板**（实时数据 + 工具速查 + 系列矩阵）。

- 教程站：https://beishanair.github.io/
- 主仓库（Skill + MCP + 插件三件套）：https://github.com/QZyme/Besson-Tools
- 数据：站点 217 篇（2026-11-07 同步），212 章节 + 4 独立文章 + 1 教程总汇页

## 安装（两种方式任选）

**方式 1 · DSH 插件栏（推荐）**：打开 DSH → 插件栏 → 「添加插件」→ 输入 GitHub 仓库地址

```
https://github.com/QZyme/dsh-besson-tools
```

或本仓库源码目录（下载解压后选择该目录即可）。

安装后插件页会显示 **11 个组件**（`besson-tutorial-lookup` … `besson-tutorial-env` + `besson-mod-project` / `besson-mod-migrate` / `besson-mod-scaffold` / `besson-mod-mapping`，每工具一行），所有会话可用 11 个 `besson_*` 工具；左上栏出现「北山 Besson 模组助手」入口面板（含实时数据）。

**支持的 DSH 版本**：0.2.2-rc.1 及以上（0.2.1 桌面版已实测：GitHub 仓库地址安装、7 组件加载、工具功能全部通过）。

**方式 2 · 预设内挂载（只在 Besson 预设里用，v2.5.0 起已内置，通常不需要）**：把仓库放进 `.dsh` 下任意目录，在预设插件列表加 7 行（与 `cordis.patch.yml` 相同）：

```yaml
- id: besson-tutorial-lookup
  name: dsh-besson-tools/lookup
- id: besson-tutorial-index
  name: dsh-besson-tools/index
- id: besson-tutorial-series
  name: dsh-besson-tools/series
- id: besson-tutorial-fetch
  name: dsh-besson-tools/fetch
- id: besson-tutorial-plan
  name: dsh-besson-tools/plan
- id: besson-tutorial-compare
  name: dsh-besson-tools/compare
- id: besson-tutorial-env
  name: dsh-besson-tools/env
```

## 组件与工具

bundle 补丁共 **12 行**（1 行客户端载体 + 11 个组件行，每个工具单独一个组件，互不依赖）：

| 组件 id | 模块 | 工具 | 作用 |
|---|---|---|---|
| `besson-tutorial-lookup` | `dsh-besson-tools/lookup` | `besson_tutorial_lookup` | 关键词检索章节（系列/版本/章节号/主题词，limit 1-25） |
| `besson-tutorial-index` | `dsh-besson-tools/index` | `besson_tutorial_index` | 六大系列总览：MC 版本、Java、章节数、缺号、数据健康 |
| `besson-tutorial-series` | `dsh-besson-tools/series` | `besson_tutorial_series` | 列某系列全部章节，或取单章详情（`chapter` 参数） |
| `besson-tutorial-fetch` | `dsh-besson-tools/fetch` | `besson_tutorial_fetch` | 抓取一篇教程正文（url 或 query 自动解析；仅站内 https） |
| `besson-tutorial-plan` | `dsh-besson-tools/plan` | `besson_tutorial_plan` | 按目标生成学习路线（新手/进阶/neoforge/forge/迁移/26.1） |
| `besson-tutorial-compare` | `dsh-besson-tools/compare` | `besson_tutorial_compare` | 两系列/版本工程与 API 差异对比（11 项） |
| `besson-tutorial-env` | `dsh-besson-tools/env` | `besson_tutorial_env` | 环境搭建清单与命令 |

> 说明：`lib/index.js`（包主入口）为客户端载体行（空 apply），左栏面板由精确包名行触发；11 个工具由 cordis.patch.yml 的 11 个组件行分别注册。

## 系列总览

| 系列 | MC | Loader | Java | 章节 |
|---|---|---|---|---|
| A | 1.20.1 | Fabric | 17 | 55 |
| B | 1.21.X | Fabric | 21 | 57 |
| C | 1.20.1 | Forge | 17 | 38 |
| D | 1.21.1 | NeoForge | 21 | 32 |
| E | 26.1 | Fabric | 25 | 30 |
| F | 26.1 | NeoForge | 25 | 待开更 |

## 版本与许可

- v2.5.0：bundle **内置「Besson 教程助手」agent 预设**（persona 工作流 + 11 工具集），安装插件即自动出现；`cordis.patch.yml` 含预设行
- v2.4.6：plan/lookup 工程优先（path/series/loader/mcVersion 参数）；lookup 计数区分标题/元数据命中
- v2.4.5：工具缺陷修复（工程体检模板清单/主入口识别、映射输出合法 JSON、检索评分标题优先、代码块行号清理）
- v2.4.4：面板「工具调用统计」（usage.json 持久化 + 宿主 /api/dsh-besson-tools/usage 路由）
- v2.4.3：左栏面板新增数据统计图表（系列分布柱状图/上下文开销表/数据新鲜度）与实时刷新；预设增加模组开发工作流提示词
- v2.4.2：面板实时数据（stats.json 自动刷新）、11 工具 / 11 组件（新增骨架生成 + 中文映射）、面板加载修复（精确包名载体行）、DSH 0.2.2-rc.1 实测
- v2.4.1：11 工具对齐（mod_project / mod_migrate）
- v2.4.0：版本号统一、9 组件、数据 207 篇（2026-10-29）
- v2.3.0：模组开发辅助（工程体检 + 迁移清单）、Web 左栏面板
- v2.2.0：7 工具、数据 217 篇、DSH 0.2.2-rc.1
- v2.1.0：数据同步、7 工具
- v2.0.0：组件拆分（7 个工具各自独立组件）
- v1.1.1：数据同步 2026-10-03
- v1.0.0：首个发布
