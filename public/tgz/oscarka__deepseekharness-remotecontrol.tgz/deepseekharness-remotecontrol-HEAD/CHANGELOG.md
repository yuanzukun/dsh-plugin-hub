# Changelog

本项目的重要变更都记录在这里。格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，版本号遵循 [SemVer](https://semver.org/lang/zh-CN/)。

## [0.7.4] - 2026-11-16

### Added

- **AI 回复零配置纯算法语音播报（`hub/web/src/utils/speech.js` / `controller.js`）**：
  - 在每条 AI 回复底部紧邻 `📋 复制全文` 新增 **`🔊 播报`** 按钮，基于零 LLM、零人工词表的结构化 Markdown AST 清洗、词法可发音度分类与 TextRank 图排序摘要算法（`< 5ms`），支持 **`⚡ 重点` / `📖 全文`** 切换、优选系统神经网络单嗓子不断气直读、语音输入防串音自动停播，以及 `onboundary` + 已播时长双保险的**原地无损倍速切换（`1x / 1.25x / 1.5x`）**。

### Fixed

- **Cloud Run 反向文件隧道断连清理、多 `language_server` 摘要仲裁与内嵌视频懒加载（`hub/server.js` / `hub/hub-core.js` / `antigravity-ide.js` / `deploy-cloudrun.sh`）**：
  - 透传客户端断开 `AbortController` 信号并及时回收 `/api/fs-tunnel` 流槽位；多实例 `language_server` 按 `lastModifiedTime` 与活跃状态确定性择优；内嵌 `<video>` 改为 `preload="none"`；Cloud Run 默认升级为 `1Gi` 内存、`200` 并发与 `--cpu-boost`。
- **CI 发布防并发撞车与 README 折叠历史记录（`publish-npm.yml` / `docker-publish.yml` / `README*.md`）**：
  - 增加 GitHub Actions 工作流级 `concurrency` 互斥锁与 `EPUBLISHCONFLICT` 幂等保护，并将中英文 README 历史更新记录收敛为单行 `<details>` 折叠面板。

## [0.7.0] - 2026-11-12

### Added

- **全面支持上架 DSH Market 与官方 `dsh plugin` 一键安装（根目录标准 DSH Bundle 规范）**：
  - 仓库根目录补齐标准 DSH 插件清单与元数据（`package.json` 的 `dsh.bundle.patch`、`engines.dsh: ">=0.2.0"`、`exports`、`icon.svg`、`locale/en.json`、`locale/zh.json`、`locale/zh-CN.json`、`cordis.patch.yml` 与 `index.js`），支持通过 DSH 插件市场或 `dsh plugin --profile desktop add github:oscarka/deepseekharness-remotecontrol` 直接一键安装启用，同时完整兼容现有 Cloud Run / Docker / Railway 零依赖部署与 `connect-host.sh` 守护进程。
- **插件市场用户「零配置局域网总控台」即装即用模式（`dsh-feishu/lib/local-hub.js` / `dsh-feishu/index.js`）**：
  - 从 DSH 插件市场安装后若尚未配置远程 `hubUrl` 或飞书应用，插件自动在本机嵌入式拉起零依赖总控台（默认监听 `8788`，端口冲突时智能复用同机已启动的本地总控台或自动回退空闲端口），自动生成并持久化本机管理员密码（`~/.dsh/local-hub.token`）与 24 小时免密扫码配对链接（`~/.dsh/local-hub-info.json`），手机连同一 Wi-Fi 打开链接即可免配置直接遥控本机 DSH、Antigravity、Codex、Claude Code、WorkBuddy 与豆包；当用户后续配置 Cloud Run / Railway `hubUrl` 时无缝切换至云端跨网模式。

## [0.6.9] - 2026-11-12

### Added

- **零依赖智能媒体探测与三档自适应兼容流引擎（`workspace-ops.js` / `controller.js` / `filePreview.ts`）**：
  - 纯 Node.js 零外部依赖解析 ISO BMFF（`.mp4` / `.m4v` / `.mov`）盒子结构与 `avcC` 编码档位（`< 2ms`），自动分流 **L1 原画直出**（`H.264 yuv420p + faststart`）、**L2 无损毫秒级重封装**（`ffmpeg -c copy -movflags +faststart`，解决 `moov` 索引在文件尾或 `.mov` 容器）与 **L3 硬件优先兼容转码**（macOS `h264_videotoolbox` 硬件加速 → 跨平台 `libx264` 偶像素缩放保底 → macOS 原生 `/usr/bin/avconvert Preset1920x1080` 免依赖兜底，彻底解决 Blender / OpenCV 默认导出 `H.264 High 4:4:4 yuv444p`、`mp4v`、`hev1`、`.webm`、`.mkv`、`.avi` 在 iOS Safari 无法播放的问题），并内置并发请求单航道锁（Single-Flight Lock）与前端 `<video>` 错误 + 黑屏双保险自动降级。

### Changed

- **全链路真流式穿透隧道（True Stream Piping）与大文件多段无损拼接下载（`server.js` / `hub-core.js` / `hub-agent.js` / `controller.js`）**：
  - 移除 `/api/fs-tunnel/:reqId` 原先整块缓存在云端内存的 `readRawBodyBuffer` 存储转发，改为 `createReadStream` → `Readable.toWeb` → `stream.pipeline` 零缓冲直通转发，首字节响应（TTFB）降至 `< 100ms`，彻底消除跨国大视频上传引发的 `15s 504` 超时与云端内存峰值；`download=1` 遇到 `> 16 MiB` 文件返回 `HTTP 206` 时，前端自动循环拉取后续 `Range` 分片并无损拼装原始字节（规避 Cloud Run HTTP/1.1 `32 MiB` 网关单请求上限与 `16 MiB` 截断）。
- **无状态确定性媒体票据（Stateless Deterministic `mediaTicket`）**：
  - `HubCore` 基于 `HUB_TOKEN` 通过 HMAC-SHA256 确定性派生 `mediaTicket` 签名密钥（无密码本地模式持久化 `mediaSeed`，修改管理员密码时立即轮转失效），Cloud Run 缩容冷启动、Railway 重部署或多实例负载均衡下手机已打开页面的图片/视频流不再出现偶发 `401`。

## [0.6.8] - 2026-11-12

### Added

- **接入「豆包电脑版 (Doubao Desktop)」只读观测适配器（`doubao-adapter.js` / `harness-router.js` / `session-labels.js`）**：
  - 自动发现并解析本机豆包电脑版会话记录与 `aiboard` 编程任务，内置增量单文件 LevelDB + 沙盒元数据缓存与 `300ms` 监听防抖、`10 分钟` 异常强退僵尸运行态超时清理、纯闲聊会话空 `cwd` 隔离，以及观察态聊天框自动隐藏语音/图片发送栏与设置页第 6 行能力边界展示。
- **手机端 HTML 网页交互预览与全屏体验（`html-sandbox.js` / `markdown.ts` / `Sheets.tsx` / `controller.js` / `server.js`）**：
  - 全面覆盖 3 种场景：① 对话内 ```` ```html ```` 代码块右上角直接点 **`🌐 交互预览`**；② 对话中的 `.html` 本地路径胶囊（`` `demo.html` `` / `[index.html](file:///...)`）与产物卡片点 **`🌐 体验网页 ›`**；③ 文件抽屉或「项目文件」页直接打开 `.html` 文件。
  - 采用无同源权限的隔离沙盒 `<iframe sandbox="allow-scripts allow-forms allow-modals allow-popups" srcdoc="...">`（阻断读取 `HUB_TOKEN` 与 `localStorage`），自动补全移动端自适应 `<meta name="viewport">`，通过只读短效 `mediaTicket`（服务端精准下发 `Access-Control-Allow-Origin: *`）自动重写相对路径 CSS/JS/图片资源，并内置带顶部安全区 **`‹ 返回对话`** 栏与 **`</> 源码` / `🌐 预览`** 一键切换的 `#htmlPreviewOverlay` 全屏浮层。

### Fixed

- **修复手机 / iOS 主屏幕 PWA 点击「下载视频 / 下载文件」跳入无返回键系统预览死胡同页的问题（`controller.js`）**：
  - 移除会导致独立全屏窗口顶层跳转的裸 `<a href="...download=1" download>` 链接，改为原地流式 `fetch`（实时显示百分比进度）后直接唤起手机系统原生分享/保存面板（支持一键「存储视频」到系统相册、「存储到“文件”」、AirDrop 或微信发送；大文件蜂窝网络超时自动降级为二次轻触 `0ms` 瞬时拉起面板），全程不离开当前对话与预览页。

## [0.6.7] - 2026-11-12

### Fixed

- **会话列表排序优先级修正**（`session-labels.js` / `controller.js`）：将置顶会话（`📌 已置顶`）真正固定在列表最顶部（置顶组内仍按状态紧急度排序），并将未读完结结论 / 中断会话（`🔵 已出结论` / `⚠️ 中断待继续`）排在后台 `● 运行中` 会话之上，避免刚跑完出结论或手动置顶的对话被后台长任务挤到下方。
- **「设备与设置 → 各后端功能边界（诚实矩阵）」与电脑详情徽章同步更新**：补齐五大工具（`DSH`、`Antigravity IDE`、`Codex`、`WorkBuddy`、`Claude Code`）官方品牌矢量徽章与最新能力状态（`Codex` 与 `WorkBuddy` 均已完整支持手机审批与实时插话），并同步刷新 README 中英文配图。

## [0.6.6] - 2026-11-12

### Changed

- 全新重构「✨ 新建远程对话任务」半屏面板（`Sheets.tsx` / `controller.js` / `app.css`）：
  - 合并顶部「💻 执行电脑」与「⚡ 执行引擎」为双行紧凑结构化卡片
  - 「📁 项目工作区」改为单行横滑胶囊 + `全部 (N) ▾` 独立带搜索抽屉（`#newTaskProjectPickerSheet`），告别多项目折行刷屏并把首屏空间留给大号任务输入框
  - 输入卡片内置底栏工具条（`🤖 模型`、`🖼️ 截图`、`🎤 语音`）：保留原生 `<button>` 直接唤起手机系统语音识别（免弹键盘、录音态红底脉冲 `⏹ 停止`），并优化模型简称清洗以保留 `(High)` / `(Low)` 档位与精确版本号

### Fixed

- 修复腾讯 WorkBuddy 存活进程心跳文件（`~/.workbuddy/sessions/<pid>.json`，每 30 秒刷新 `lastHeartbeat`）被误导入为幽灵会话并持续排在会话列表顶部的 Bug（`WorkBuddyAdapter` 跳过进程心跳锁文件并保持真实会话历史时间戳，`HubCore` 服务端双保险过滤旧节点上报的 `workbuddy:<pid>` 空记录）

## [0.6.5] - 2026-11-12

### Fixed

- 修复 iOS Safari 网页语音识别（`webkitSpeechRecognition`）转文字缺少标点符号的问题（`useVoiceInput.ts`）：
  - 新增 `650ms` 说话停顿实时断句检测器（停顿换气时在绿色气泡内实时补上逗号 `，` 或问号 `？`，且兼容苹果对断点前同音字的动态修正）
  - 新增多分段衔接标点（`mergeSpeechResults`）、中文连读疑问分句自动加问号（如 `…吗？…`）与松手收尾句末标点补全（`？` / `。`，自动剥离悬空尾逗号，同时开启标准 `unspokenPunctuation = true`）

## [0.6.4] - 2026-11-11

### Added

- 手机端升级为**微信同款「按住 说话」语音交互**（`useVoiceInput.ts` / `ChatStage.tsx` / `app.css`）：
  - 底部输入栏支持一键切换「`🎙️ 按住 说话`」大按钮模式与「`⌨️ 打字`」键盘模式（手机端默认开启按住说话，记忆用户偏好，有未发草稿时自动展露文本框）
  - 按住按钮立即唤起微信风格全屏录音浮层：绿色语音气泡实时展示已识别文字与动态声波动画（按住期间停顿换气同样无缝续听不断流）
  - 完整支持三向手势操作：**直接松手 → 立即发送消息**（内置 380ms 尾音收尾缓冲确保最后半句不漏字 + `abort()` 强制熄灭麦克风红点）、**左滑松手 → 取消不发**、**右滑到「文」松手 → 填入输入框修改后再发**（发完自动切回按住说话条）

## [0.6.3] - 2026-11-11

### Fixed

- 修复手机端语音识别在说话中途换气/短暂停顿时自动中断的问题：开启 `continuous = true` 持续听写模式，新增 iOS Safari 静默断流（`onend` / `no-speech`）180ms 无缝续接新实例机制与 `mergeSpeechResults` 累积叠字去重算法，并改为按每次说话动态顺延 60 秒空闲看门狗（直到用户主动点 `⏹` 或直接点「发送」才结束）

## [0.6.2] - 2026-11-11

### Fixed

- 恢复手机端点击 `🎤` 直接调用系统自带原生语音识别（`SpeechRecognition` / `webkitSpeechRecognition`）而无需弹起软键盘的能力（移除 `useVoiceInput.ts` 中的 `isMobileTouch` 人为封锁与 `<label>` 强制弹键盘行为，彻底清理所有第三方输入法提示文案，新增 `audio-capture` 麦克风占用明确提示）
- 优化 `applyLangToDom` 与 `autoGrowComposer`：默认中文模式下跳过每次 SSE 推送的全页面 DOM 遍历且绝不改写聚焦输入框的 `placeholder` 属性，流式输入/听写期间避免无谓高度重算，防止打断系统听写

## [0.6.1] - 2026-11-11

### Changed

- 精简会话列表与头部信息架构，全面升级官方品牌矢量图标体系（抽离独立模块 `hub/web/src/utils/session-labels.js`）：
  - 内置 Antigravity IDE、腾讯 WorkBuddy、OpenAI Codex、Claude Code、DeepSeek Harness 5 套官方矢量 `<symbol>` 图标（采用 `24×24` 离屏视口容器保障 iOS Safari WebKit `<mask>` / `<filter>` 零裁剪渲染，并为聊天头 `#chatSub` 增加增量 DOM 比对防流式重绘闪烁）
  - 会话列表标题自动剥离与下方 `📁 工作区` 标签重复的 `<project> / ` 前缀，消除双倍冗余
  - 多机视图下的电脑徽章自动简写（如 `cc的MacBook Air` → `Air`；多台同型号 Mac mini 智能区分归属前缀并兼容拼音 `de` 主机名，如 `digtal·Mini`、`no2·Mini`，告别双重省略号截断）
  - WorkBuddy 时间戳工作区目录（`YYYY-MM-DD-HH-mm-ss`）智能浓缩：今日显示 `11:59`，同年份跨日显示 `11/10 15:09`（避免多会话筛选胶囊同名碰撞），跨年显示 `2025/12/31 09:05`

## [0.6.0] - 2026-11-11

### Added

- 实现真正的 **SSE 增量状态推送 (`event: state_delta`)**：新增服务端差分引擎 `hub/delta-state.js` 与前端无损合并器 `hub/web/src/state/delta-merge.js`，`/api/events?delta=1` 仅推送发生变更的主机元数据与单条会话（压缩后每次更新仅 `~1–3 KB`，相比此前全量广播降低 **98%+** 移动端实时流量），内置单调递增 `stateSeq` 连续性校验与断序自动回退 `/api/state` 自愈能力
- 推进前端 `controller.js` 模块化拆分：抽离 `hub/web/src/state/delta-merge.js`、`hub/web/src/utils/image-compress.js` 与 `hub/web/src/utils/semver.js` 独立模块

### Fixed

- 彻底修复移动端「已出结论」长回复内容被截断的问题：
  - `HubCore.compactBridgeStateForWire` 将每个主机前 6 条、所有运行中/待审批、以及最近 60 分钟内刚出结论或活跃的会话均纳入热会话保护，最新回复与结论配额恢复至完整 **`48,000` 字**（零截断）
  - 在 `renderActiveChatStage` 渲染阶段增加 `_wireTruncated` 自动检测与静默全文回填（`hydrateColdSessionTranscript`），即使直接停留在会话内跨状态切换或打开早先冷门历史会话也自动补齐 100% 原始全文
- 修复移动端发送高分辨率截图/长截图后偶发卡死、导致短时间内打不开页面的问题：
  - `compressImageFile` 改为低内存 `URL.createObjectURL` 异步解码 + iOS WebKit 安全像素面积上限（`3.6M px`，规避 Safari `16.7M px` Canvas GPU 进程崩溃白屏）+ 绘制后立即释放显存（`canvas.width = 0`）+ 自适应阶梯 JPEG 压缩，并禁止解码失败时回退裸发数 MB 原始图片
  - `dispatchHostCommand` 增加 `AbortController` 请求超时保护（附图 15 秒 / 普通指令 10 秒 + `cache: 'no-store'`），杜绝移动网络代理偶发卡包拖死 iOS Safari 复用的单条 HTTP/2 连接
  - 在版本热更新 `location.reload()`、`pagehide` 与 `beforeunload` 前显式调用 `closeSSE()`，根除幽灵双路 SSE 并发占满带宽

## [0.5.9] - 2026-11-11

### Fixed

- 修复多主机大工作区下移动端前台频繁弹出「网络连接中断，正在自动重连…」的问题：
  - `HubCore.compactBridgeStateForWire` 区分活跃会话与冷门历史会话预算（活跃会话保留 14 条详情，冷门空闲会话压缩为 3 条短摘要并支持点开对话时毫秒级静默按需回填全文），将 3 台电脑 65+ 会话的 `/api/state` 与 SSE 单帧压缩体积从 ~1MB 降至 ~100–200KB
  - `hub/server.js` 为浏览器 `/api/events` SSE 增加首帧立即推送 + 450ms 多主机心跳突发合并节流、`TCP_NODELAY`、`X-Accel-Buffering: no` 与 12 秒保活 `ping`
  - 前端 `fetchState()` 升级为单飞去重 + 12 秒 `AbortController` 超时 + 350ms 自动静默重试 + SSE 存活感知防抖（SSE 正常收包时绝不因后台兜底拉取偶发重置而误报断网横幅），并消除点击审批/发消息后的重复 `/api/state` 并发洪峰与 240 秒 SSE 轮转时的冗余拉取
- 优化移动端「设备与设置」主机一键升级版本号语义比对（`compareSemver`），支持直接从手机一键触发旧版 Mac mini 拉取最新 `main` 并热重启守护进程

## [0.5.8] - 2026-11-11

### Added

- 完善腾讯 WorkBuddy（v5.9.3）真机生产闭环：通过 `ACC_PRODUCT_CONFIG_PATH` 隔离独立 `workbuddy-cli` OAuth 凭证（与桌面端钥匙串凭证互不覆盖，支持自动弹浏览器授权与 `node dsh-feishu/daemon.mjs --workbuddy-login` 一键独立预授权）、按会话 `cwd` 隔离 `codebuddy --serve` 进程池（含进程退出与断连自动驱逐重拉，覆盖新建、追问与实时插话）、手机新建会话自动创建 `~/WorkBuddy/<时间戳>` Playground 目录，以及 `workbuddy.db` 与 `.jsonl` 双向落盘同步

## [0.5.7] - 2026-11-11

### Fixed

- 修复 iOS 主屏幕模式（Standalone PWA）点击语音按钮无法唤起系统键盘的问题：移动端统一采用手机自带键盘 / 豆包语音输入，升级为原生 `<label for>` 无拦截焦点关联并适配灵动岛安全区引导提示
- 修复电脑端先点审批、手机端再点残留按钮导致回退敲入数字 `"1"` 的竞态问题（待审批轨迹缓存缩短至 `350ms`，已处理审批幂等返回 `alreadySettled: true` 绝不触发模拟按键）
- 修复单元测试在宿主环境变量继承及空 `dshHome` 配置下的测试隔离问题

## [0.5.6] - 2026-11-11

### Fixed

- 修复 `/api/events` SSE 长连接满 300 秒被 Google Cloud Run 强制截断（`Truncated response body`）导致复用同一 HTTP/2 连接的 iOS 移动端 `POST /command` 偶发抛出 `Load failed` 审批异常报错的问题（新增 240 秒服务端优雅轮转 `event: rotate` + 浏览器与 Host 端平滑换流）
- 为 `dispatchHostCommand` 与 `HubCore.queueCommand` 增加客户端幂等 `id` 去重及网络闪断自动静默重试，消除手机唤醒/切网瞬间的偶发红字报错

## [0.5.5] - 2026-11-11

### Added

- 独立反向 HTTP 流式文件与媒体直连隧道（`/api/hosts/:hostId/fs/list|read|stream` + `/api/fs-tunnel/:reqId` + Host SSE `event: fs_req` 0ms 唤醒）
- 移动端原生视频预览与拖动分片秒播（`HTTP 206 Partial Content` + `Accept-Ranges: bytes` + `ETag` `304` 协商缓存 + `ffmpeg` / macOS `avconvert` 一键 H.264 转码兜底）
- 保长截图清晰度的 `sips` 智能缩略图（`> 300KB` 位图自动压缩并保留无损原图一键切换）、`walkthrough.md` 增量热缓存预热，以及不暴露 `HUB_TOKEN` 的短效只读 `mediaTicket` 票据
- OpenAI Codex（`codex app-server` JSON-RPC）与腾讯 WorkBuddy（ACP HTTP+SSE）全托管流式控制、实时插话与移动端权限审批支持

### Fixed

- 修复移动端/跨 Cloud Run 发送消息时，在「Host 心跳拉走指令 ~ 会话日志落盘回传」空窗期内气泡先消失再重现的问题（新增 `inflightCommands` 桥接与同名短句基线计数防误删）
- 修复 `deploy-cloudrun.sh` 升级已有 Cloud Run 服务时未保留线上 `HUB_TOKEN` 的问题

## [0.5.4] - 2026-11-10

### Added

- Antigravity IDE `walkthrough.md` 及产物文件在移动端对话气泡内的可点击胶囊与 Markdown 原生渲染预览
- 会话级模型双向同步（Antigravity IDE LanguageServer / DSH 会话模型识别与持久化）
- 首屏 `0ms` 本地快照瞬时渲染，彻底消除移动端浏览器打开时的白屏等待
- 中英双语 README（`README.md` / `README.zh-CN.md` / `README.en.md`）、`FAQ.md`、`SECURITY.md`、`CONTRIBUTING.md`、`CODE_OF_CONDUCT.md` 与 `LICENSE`（MIT）

### Changed

- 极速心跳与增量同步（`v0.5.3`）：稳态网络流量降低 99.9%，静态资源与 API 全面启用 Gzip 压缩
- 移动端语音输入直接唤起系统键盘原生麦克风 / 豆包语音输入
- 重写 README：提供 3 步快速启动路径与中英双语实机演示 GIF（`docs/assets/`）
- 关于第三方托管服务的表述改为「兼容 / 可替代」，并补充独立性免责声明

## [0.2.0] - 2026-11-07

### Added

- 多 Harness 支持：Codex、Claude Code 适配器与能力矩阵，`FEISHU_ENABLED_HARNESSES` 开关
- 移动端体验优化：底部 5 Tab、手势、语音输入、深色模式修正
- 服务端 JSON gzip 压缩、会话记录裁剪、SSE 去重、预览快速切片
- 会话思考过程与工具步骤合并展示，完整工具参数/结果提取，回复上限提升到 48k
- 主机守护进程支持 macOS LaunchAgent 注册

### Fixed

- 修复 Apple APNs 403 `BadJwtToken`（`.local` subject），VAPID 改为确定性派生并自动重同步
- 修复空闲 POSIX 会话 `session.lock` 未释放导致 headless 恢复失败
- 修复审批回调 `renderAll` 崩溃及第二轮审计发现的 N1–N12 问题
- 修复语音输入中断生命周期、二进制预览与推送深链缺失

## [0.1.0] - 2026-11-02

### Added

- 飞书自建应用长连接遥控：`!sessions` / `!new` / `!steer` / `!files` / `!share`
- 工具审批卡片、完成与异常推送、白名单与审计日志
- 自托管 Hub：多机主从切换、一键迁移与源机清理
- 远程会话管理、工作区文件树与安全预览
- AES-256-GCM 端到端加密分享与回放
- Ed25519 设备指纹锁定 / 吊销、6 位配对码
- iOS 主屏幕 PWA 与 W3C Web Push（RFC 8292 / RFC 8291）
- 自托管 WebRTC 信令与 TURN 临时凭据
