#!/usr/bin/env bash
set -euo pipefail

# dsh-turbo/enable-turbo.sh
# 自动检测/编译 Rust 原生加速模块，并检测/引导开启 macOS 辅助功能权限 (Accessibility)

TURBO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$TURBO_DIR/.." && pwd)"
BIN_DIR="$TURBO_DIR/bin"
NATIVE_BIN="$BIN_DIR/dsh-turbo-native"
SRC_FILE="$TURBO_DIR/src/main.rs"

mkdir -p "$BIN_DIR"

# 1. 如果本机装了 rustc 且二进制不存在或源码更新过，自动编译最新原生加速模块；否则直接使用仓库预置二进制
if [ ! -x "$NATIVE_BIN" ] || [ "$SRC_FILE" -nt "$NATIVE_BIN" ]; then
  if command -v rustc >/dev/null 2>&1; then
    echo "🦀 正在编译 Rust 原生极速加速模块 (dsh-turbo-native)..."
    rustc -O -C strip=symbols "$SRC_FILE" -o "$NATIVE_BIN" 2>/dev/null || true
    chmod +x "$NATIVE_BIN" 2>/dev/null || true
  fi
fi

if [ -x "$NATIVE_BIN" ]; then
  chmod +x "$NATIVE_BIN" 2>/dev/null || true
  echo "⚡ 已启用 Rust 原生加速引擎: $NATIVE_BIN"
  # 2. 自动检测 macOS 辅助功能权限；若未开启则立即弹出系统授权引导窗口
  AX_OUT="$("$NATIVE_BIN" check-ax 2>/dev/null || echo '{"trusted":true}')"
  if echo "$AX_OUT" | grep -q '"trusted":false'; then
    echo "🔓 检测到当前电脑尚未开启「辅助功能 (Accessibility)」遥控权限，正在为您自动弹出系统授权窗口..."
    "$NATIVE_BIN" prompt-ax >/dev/null 2>&1 || true
    echo "👉 请在弹出的「系统设置 → 隐私与安全性 → 辅助功能」中打开终端/守护进程开关，手机端即可毫秒级点击审批！"
  else
    echo "✅ macOS 辅助功能遥控权限已就绪 (Accessibility Trusted)"
  fi
else
  echo "⚡ 已启用 Node FSEvents 实时加速流模式"
fi

# 3. 如果是由远端 upgrade_turbo 触发（非 connect-host.sh 初次引导），确保工作区对齐最新 origin/main 并延迟热重启后台 daemon
if [ -z "${CONNECT_HOST_RUNNING:-}" ]; then
  if command -v git >/dev/null 2>&1 && [ -d "$REPO_DIR/.git" ]; then
    git -C "$REPO_DIR" fetch origin main >/dev/null 2>&1 || true
    LOCAL_HEAD="$(git -C "$REPO_DIR" rev-parse HEAD 2>/dev/null || true)"
    REMOTE_HEAD="$(git -C "$REPO_DIR" rev-parse origin/main 2>/dev/null || true)"
    if [ -n "$LOCAL_HEAD" ] && [ -n "$REMOTE_HEAD" ] && [ "$LOCAL_HEAD" != "$REMOTE_HEAD" ]; then
      git -C "$REPO_DIR" reset --hard origin/main >/dev/null 2>&1 || true
    fi
  fi
fi

if [ -z "${CONNECT_HOST_RUNNING:-}" ] && { [ -f "$HOME/.dsh/hub-daemon.pid" ] || [ -f "$HOME/.dsh/daemon.lock" ]; }; then
  (
    sleep 2.5
    if command -v launchctl >/dev/null 2>&1 && [ -f "$HOME/Library/LaunchAgents/com.dsh.remotecontrol.plist" ]; then
      if [ -f "$HOME/.dsh/hub-daemon.pid" ]; then
        OLD_PID="$(cat "$HOME/.dsh/hub-daemon.pid" 2>/dev/null || true)"
        [ -n "$OLD_PID" ] && kill -TERM "$OLD_PID" 2>/dev/null || true
      fi
      launchctl kickstart -k "gui/$(id -u)/com.dsh.remotecontrol" 2>/dev/null && exit 0
    fi
    NODE_BIN="$(command -v node 2>/dev/null || true)"
    USE_ELECTRON_NODE=0
    if [ -z "$NODE_BIN" ]; then
      for dsh_app_bin in \
        "/opt/homebrew/bin/node" \
        "/usr/local/bin/node" \
        "/Applications/DeepSeek Harness.app/Contents/MacOS/DeepSeek Harness" \
        "$HOME/Applications/DeepSeek Harness.app/Contents/MacOS/DeepSeek Harness" \
        "/Applications/Antigravity IDE.app/Contents/MacOS/Electron" \
        "$HOME/Applications/Antigravity IDE.app/Contents/MacOS/Electron"; do
        if [ -x "$dsh_app_bin" ]; then
          NODE_BIN="$dsh_app_bin"
          case "$dsh_app_bin" in
            */node) USE_ELECTRON_NODE=0 ;;
            *) USE_ELECTRON_NODE=1 ;;
          esac
          break
        fi
      done
    fi
    if [ -n "$NODE_BIN" ]; then
      if [ "$USE_ELECTRON_NODE" = "1" ]; then
        nohup env ELECTRON_RUN_AS_NODE=1 "$NODE_BIN" "$REPO_DIR/dsh-feishu/daemon.mjs" --replace < /dev/null >> "$HOME/.dsh/hub-daemon.log" 2>&1 &
      else
        nohup "$NODE_BIN" "$REPO_DIR/dsh-feishu/daemon.mjs" --replace < /dev/null >> "$HOME/.dsh/hub-daemon.log" 2>&1 &
      fi
      echo $! > "$HOME/.dsh/hub-daemon.pid"
    fi
  ) >/dev/null 2>&1 &
fi


