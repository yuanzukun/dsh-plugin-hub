---
name: diagnosis
description: Use when diagnosing 3D printing failures — warping, poor adhesion, stringing, layer lines, layer separation, clogging, elephant foot, pillowing, over/under-extrusion, Z banding — and recommending prioritized fixes.
---

# 打印故障诊断

按「症状 → 最可能原因（按概率排序）→ 修复动作」诊断。先问清材料、喷嘴/热床温度、打印速度、是否有保温箱，再给结论。一次只改一个变量。

## 故障表

### 翘边 / 首层不粘（warping / poor adhesion）
原因（按序）：热床温度低 → 热床未调平/喷嘴距床过高 → 首层风扇开 → 床面脏/有油 → 材料本身（ABS/PC 必翘）。
修复：调平并校 Z 偏移；热床 +5~10℃；首层风扇关；床面用酒精清洁或上胶水/美纹纸；ABS/PC 加保温箱；加 brim（裙边）。

### 拉丝（stringing）
原因：回抽距离/速度不足 → 温度过高 → 喷嘴移动路径跨空。
修复：加大回抽（远程 3→7mm、直驱 0.5→2mm）；降喷嘴 5~10℃；开「避免跨空移动」；干燥耗材（PETG/Nylon 吸湿易拉丝）。

### 层纹 / 波纹（layer lines / ringing 振纹）
原因：打印速度过快 → 加速度过高 → 机械松动（皮带/滑轮/平台）。
修复：降速 20~40%；降加速度/急动度；紧固皮带与导轨；把 Z 轴丝杆清洁润滑。

### 层间分离 / 开裂（layer separation / delamination）
原因：喷嘴温度过低 → 层高过大 → 冷却过快 → 保温不足。
修复：喷嘴 +5~15℃；减小层高；降低风扇；加保温箱（ABS/PC/PA 尤其）。

### 堵塞 / 挤出不足（clogging / under-extrusion）
原因：喷嘴堵塞 → 挤出机打滑/张力不足 → 打印温度过低 → 速度过快超出流量上限。
修复：冷拉（cold pull）清堵；校紧挤出机；升温；降速；换硬化钢喷嘴打碳纤料。

### 大象脚（elephant's foot，首层外扩）
原因：首层过高→喷嘴离床太近 → 床温过高 → 首层层高过大。
修复：抬 Z 偏移；床温 -5℃；首层层高减小；开「首层水平补偿」（PrusaSlicer）。

### 上表面麻点 / 起泡（pillowing）
原因：顶层过薄 → 填充率过低 → 顶层冷却不足。
修复：顶层增加到 ≥5 层；填充率提高；顶层风扇 100%。

### 过挤出（over-extrusion）
原因：流量倍率过高 → 线宽设置过大 → E-steps 未校准。
修复：流量 100%→95%；校准 E-steps；线宽回 100% 喷嘴直径。

### Z 轴纹路（Z banding）
原因：Z 丝杆弯曲/不同心 → 联轴器松动 → Z 步进与螺距不匹配。
修复：检查丝杆与联轴器；润滑；核对 Z 步进/螺距配置。

### 首层起皱 / 波浪（first layer rippling）
原因：喷嘴离床过近 → 挤出过量 → 床脏。
修复：抬 Z；降首层流量；清洁床面。

## 诊断流程

0. 优先直接用 `print3d_diagnose_print`（照片 `image_path` 或口述 `symptoms` + 材料/温度/速度/保温），它会按本表给出排序疑因与修复；命令行等价物是插件的 `scripts/print_diagnosis.cjs`。
1. 明确症状（可让用户发照片描述）。
2. 确认材料 + 当前温度/速度/层高。
3. 从表里给出**按概率排序**的 2–3 个原因与对应动作。
4. 建议「一次只改一个变量」，避免同时改温度又改速度无法归因。
5. 涉及耗材吸湿（PETG/Nylon/PVA）优先提醒干燥。

## 边界

- 无法确诊的（如主板/热敏电阻硬件故障），明确说需要硬件排查，不要瞎猜。
- 涉及 220V 电源、热端拆卸等危险操作，提醒断电并谨慎处理。
