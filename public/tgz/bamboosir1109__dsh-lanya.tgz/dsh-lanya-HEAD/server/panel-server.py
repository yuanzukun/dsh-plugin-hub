# Lanya panel server - serves the control panel AND its API from ONE origin.
#
# Why this exists: the panel used to live on the works server (19388) and talk to
# the DSH host on 19387. Every write failed with "Failed to fetch":
#   - plain GET: the OPTIONS preflight hit a route that answers 400
#   - POST: the DSH web server does not accept cross-origin writes at all
# Fighting CORS was the wrong direction. Serving the page and the API from the same
# origin removes the whole class of problem - no preflight, no CORS, no proxy.
#
# Static files come from her made/ folder, so existing game links keep working.
#
#   python lanya-panel-server.py            run on 19389
#   python lanya-panel-server.py --port N
#
# ASCII-only source.

import json
import re
import os
import shutil
import subprocess
import sys
import threading
import time
import stat
import sqlite3
import contextlib
import hashlib
import math
from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

HERE = os.path.dirname(os.path.abspath(__file__))
with open(__file__, "rb") as _program:
    _PANEL_SCRIPT_SHA256 = hashlib.sha256(_program.read()).hexdigest()
_HELPERS = os.path.join(os.path.dirname(HERE), "scripts")
if os.path.basename(HERE).lower() == "server":
    sys.path.insert(0, _HELPERS)
else:
    sys.path.insert(0, HERE)
import project_conf
import qq_backend
import qq_backend_selection

REPO = project_conf.work_dir()
DATA = project_conf.data_dir()
DATA_NAME = os.path.basename(DATA)
ROOT = os.path.join(DATA, "made")
NAPCAT = os.path.join(REPO, "napcat")
_PERSONA_NAME = DATA_NAME + "-\u4eba\u8bbe\u6b63\u6587.md"
_PERSONAS = [os.environ.get("LANYA_PERSONA_FILE"), os.path.join(NAPCAT, "persona.md"),
             os.path.join(NAPCAT, _PERSONA_NAME), os.path.join(DATA, _PERSONA_NAME)]
# An explicit override is authoritative even before the file is created.
PERSONA = (os.path.abspath(os.path.expanduser(_PERSONAS[0])) if _PERSONAS[0] else
           next((p for p in _PERSONAS[1:] if os.path.isfile(p)), _PERSONAS[1]))
CONFIG  = os.path.join(DATA, "lanya-config.json")
TUNABLES = os.path.join(DATA, "lanya-tunables.json")
MEMECFG  = os.path.join(DATA, "lanya-memes-config.json")
MEME_TAGS = os.path.join(DATA, "lanya-memes-tags.json")

PROFILE = os.path.join(os.path.expanduser("~"), ".dsh", "profiles", "desktop")
PROFILE_PKG = os.path.join(PROFILE, "package.json")
def _configured_path(env_name, key, default=""):
    value = os.environ.get(env_name) or project_conf.get(key, default)
    return os.path.abspath(os.path.expandvars(os.path.expanduser(str(value)))) if value else ""


def _executable_paths(env_name, key, command, extra=()):
    paths = [_configured_path(env_name, key), shutil.which(command), *extra]
    return list(dict.fromkeys(p for p in paths if p))


DSH_ROOT = _configured_path("DSH_ROOT", "dshRoot")
_DSH_ON_PATH = shutil.which("dsh.cmd") or shutil.which("dsh")
if not DSH_ROOT:
    # A conventional sibling installation remains discoverable without a
    # machine-specific drive or a hardcoded author installation directory.
    _sibling = os.path.join(os.path.dirname(REPO), "DSH")
    if os.path.isfile(os.path.join(_sibling, "resources", "runtime", "cli", "bin", "dsh.cmd")):
        DSH_ROOT = _sibling
DSH_CLI = (os.path.join(DSH_ROOT, "resources", "runtime", "cli", "bin", "dsh.cmd")
           if DSH_ROOT else (_DSH_ON_PATH or "dsh.cmd"))
TTS_START = _configured_path("LANYA_TTS_START_SCRIPT", "tts.startScript",
                             os.path.join(REPO, "tts", "start-tts-server.ps1"))

SCRIPTS = {
    "groupwatch": "groupwatch.ps1",
    "lifeloop": "lifeloop.ps1",
    "voicedaemon": "voicedaemon.ps1",
    "supervisor": "lanya-supervisor.ps1",
    "napcat-heal": "napcat-heal.ps1",
    "qq-backend-heal": "qq-backend-heal.ps1",
    "kill-strays": "kill-strays.ps1",
    "settings-guard": "settings-guard.py",
    "state": "lanya-state.ps1",
    "tick": "lanya-tick.ps1",
    # 面板上每个部件都应该有自己的启动按钮，不然显示"0 个"就不知道怎么办。
    "browserd": "browserd.py",
    # tts 不是普通脚本：它跑在单独的 conda 环境里、有自己的工作目录，\n    # 交给下面的 SPECIAL 分支处理。
    "works": "made-server.ps1",
}


def start_napcat_elevated():
    """Delegate to the existing local launcher after checking injection files.

    The local launcher owns QQ discovery and its preflight checks. Never kill
    QQ from this server, or build a second, divergent injection command here.
    """
    project = project_conf.load(reload=True)
    spec, settings, root, _, _, _ = qq_backend.describe(project=project, workspace=REPO)
    if spec.key != "napcat":
        raise qq_backend.BackendError("NapCat is not the selected QQ backend")
    configured = (os.environ.get("LANYA_NAPCAT_LAUNCHER") or settings.get("startScript")
                  or project.get("napcat", {}).get("startScript"))
    if configured:
        if not isinstance(configured, str) or "\x00" in configured:
            raise qq_backend.BackendError("Invalid NapCat launcher configuration")
        launcher_path = Path(os.path.expandvars(os.path.expanduser(configured)))
        launcher = str(launcher_path if launcher_path.is_absolute() else root / launcher_path)
    else:
        launcher = str(root.parent / "\u542f\u52a8NapCat-\u6b63\u786e.cmd")
    for file in (launcher, *(os.path.join(root, name) for name in
                            ("napimain.exe", "napiloader.dll", "nativeLoader.cjs"))):
        if not os.path.isfile(file):
            raise FileNotFoundError("NapCat launcher preflight failed: " + os.path.basename(file))
    quoted = launcher.replace("'", "''")
    working = os.path.dirname(launcher).replace("'", "''")
    ps = [
        "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass",
        "-Command",
        # The launcher process may stay alive without showing a new console.
        "Start-Process -FilePath '" + quoted + "' -WorkingDirectory '" + working +
        "' -Verb RunAs -WindowStyle Hidden -PassThru -ErrorAction Stop | Select-Object -ExpandProperty Id"
    ]
    p = subprocess.run(ps, capture_output=True, timeout=120,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if p.returncode:
        raise RuntimeError("NapCat launcher was not started; elevation may have been cancelled")
    output = (p.stdout or b"").decode("utf-8", "replace").strip()
    if not output.isdigit():
        raise RuntimeError("NapCat launcher did not return a process id")
    return int(output)


# 有些部件不能当普通脚本起：解释器不同、工作目录不同、还要带参数。
SPECIAL = {
    "tts": {
        "exe": "powershell.exe",
        "cwd": os.path.dirname(TTS_START),
        "script": TTS_START,
        "args": ["-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", TTS_START],
    },
}


def run_script(name):
    if name == "works":
        raise ValueError("Works service belongs to the panel service supervisor")
    if name in _RETIRED_UNIFIED and decision_mode() != "legacy":
        raise ValueError("Unified mode retires this independent loop; request a main-agent check")
    sp = SPECIAL.get(name)
    if sp:
        if not os.path.isfile(sp["script"]):
            raise FileNotFoundError("Configure tts.startScript or LANYA_TTS_START_SCRIPT")
        p = subprocess.Popen(
            [sp["exe"]] + sp["args"], cwd=sp["cwd"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        return p.pid

    script = SCRIPTS.get(name)
    if not script:
        raise ValueError("unknown target: " + name)
    full = os.path.join(NAPCAT, script)
    if not os.path.isfile(full):
        raise FileNotFoundError(script)
    if script.endswith(".py"):
        exe, args = "python", [full]
    else:
        exe = "powershell.exe"
        args = ["-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", full]
    child = subprocess.Popen(
        [exe] + args,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    return child.pid


# 部件 -> 计划任务名。
#
# 直接起脚本是错的：groupwatch / lifeloop 这些内部会调 dsh.cmd（批处理），
# 每调一次就弹一个控制台窗口——外层隐藏了没用，内层管不到。而且面板起的是
# 第二个副本，跟任务里那个打架。
#
# 触发已有任务才是对的：任务本来就配了 -WindowStyle Hidden，由计划程序拉起，
# 不会有窗口；schtasks /run 也不需要管理员。
TASKS = {
    "groupwatch":  "DSH-GroupWatch",
    "lifeloop":    "DSH-Lanya-Life",
    "voicedaemon": "DSH-Lanya-Voice",
    "browserd":    "DSH-Lanya-Browser",
    "works":       "DSH-Lanya-Works",
    "tts":         "DSH-Lanya-TTS",
}


_AUTONOMY_REQUEST_LOCK = threading.Lock()
_SOURCE_UPDATE_LOCK = threading.Lock()
_AUTONOMY_REQUEST = {"at": 0.0, "process": None}
_RETIRED_UNIFIED = frozenset(("lifeloop", "voicedaemon", "supervisor", "tick"))


def decision_mode():
    # Actions must not reuse cached legacy permission after a configuration change.
    config = project_conf.load(reload=True)
    decisions = config.get("decisions", {})
    if not isinstance(decisions, dict):
        raise ValueError("Invalid decision configuration")
    mode = decisions.get("mode", "unified")
    if mode not in ("unified", "legacy"):
        raise ValueError("Invalid decision mode; independent activity refused")
    return mode


def bili_entertainment_review(body):
    """Only an explicitly configured legacy mode may use the old subprocess."""
    if not isinstance(body, dict):
        raise ValueError("Invalid entertainment preferences")
    if decision_mode() == "legacy":
        return None
    from autonomy_observers import entertainment_review
    return entertainment_review(do_comment=body.get("comment", True) is not False,
                                mention=body.get("mention", False) is True)


def _ordinary_metadata(path):
    absolute = os.path.abspath(path)
    current = absolute
    while True:
        if os.path.lexists(current):
            info = os.lstat(current)
            if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                raise ValueError("Metadata link refused")
        parent = os.path.dirname(current)
        if parent == current:
            break
        current = parent
    return absolute


def _read_metadata(path, limit=1024 * 1024):
    path = _ordinary_metadata(path)
    before = os.stat(path)
    if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
        raise ValueError("Invalid metadata file")
    signature = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns)
    with open(path, "rb") as stream:
        raw = stream.read(limit + 1)
        if signature(os.fstat(stream.fileno())) != signature(before):
            raise ValueError("Metadata changed")
    if len(raw) != before.st_size or signature(os.stat(path)) != signature(before):
        raise ValueError("Metadata changed")
    value = json.loads(raw.decode("utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError("Metadata object required")
    return value


def _scheduler_owner_verified(pid, marker_at):
    """Read-only Windows handle check; never use Python os.kill on Windows."""
    if os.name != "nt" or not DSH_ROOT:
        return None
    import ctypes
    from ctypes import wintypes
    api = ctypes.WinDLL("kernel32", use_last_error=True)
    api.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    api.OpenProcess.restype = wintypes.HANDLE
    api.CloseHandle.argtypes = [wintypes.HANDLE]
    api.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    api.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
    api.GetProcessTimes.argtypes = [wintypes.HANDLE, ctypes.POINTER(ctypes.c_uint64), ctypes.POINTER(ctypes.c_uint64), ctypes.POINTER(ctypes.c_uint64), ctypes.POINTER(ctypes.c_uint64)]
    handle = api.OpenProcess(0x1000, False, pid)
    if not handle:
        return False if ctypes.get_last_error() == 87 else None
    try:
        exit_code = wintypes.DWORD()
        size = wintypes.DWORD(32768)
        image = ctypes.create_unicode_buffer(size.value)
        born, ended, kernel, user = (ctypes.c_uint64() for _ in range(4))
        if (not api.GetExitCodeProcess(handle, ctypes.byref(exit_code))
                or not api.QueryFullProcessImageNameW(handle, 0, image, ctypes.byref(size))
                or not api.GetProcessTimes(handle, ctypes.byref(born), ctypes.byref(ended), ctypes.byref(kernel), ctypes.byref(user))):
            return None
        expected = os.path.normcase(os.path.join(DSH_ROOT, "DeepSeek Harness.exe"))
        return (exit_code.value == 259 and os.path.normcase(image.value) == expected
                and (born.value - 116444736000000000) // 10000 <= marker_at)
    finally:
        api.CloseHandle(handle)


def _consumer_matches(pid):
    file = _ordinary_metadata(os.path.join(DATA, "decision-inbox", "consumer.sqlite"))
    if not os.path.isfile(file):
        return False
    if os.path.isfile(file + "-wal") and not os.path.isfile(file + "-shm"):
        return None
    from pathlib import Path
    with contextlib.closing(sqlite3.connect(Path(file).as_uri() + "?mode=ro", uri=True, timeout=0.2, isolation_level=None)) as db:
        deadline = time.monotonic() + 0.3
        db.set_progress_handler(lambda: int(time.monotonic() > deadline), 1000)
        db.execute("PRAGMA query_only=ON")
        db.execute("BEGIN")
        if db.execute("PRAGMA user_version").fetchone()[0] != 1:
            return None
        rows = db.execute("SELECT id,pid FROM consumer ORDER BY id LIMIT 3").fetchall()
        db.rollback()
    return rows == [(1, pid)]


def _mind_metadata(value):
    """Aggregate only control metadata; never return plan, scope or event IDs."""
    version = value.get("decision_observers_version", 1)
    if type(version) is not int or version not in (1, 2):
        raise ValueError("Unknown observer metadata schema")
    rows = value.get("decision_scopes", {}) if version == 2 else {"legacy": {
        "pending": value.get("decision_pending"), "next_review_at": value.get("decision_next_review_at"),
        "last_status": value.get("last_decision_status"), "next_opportunity_at": None,
    }}
    if not isinstance(rows, dict) or len(rows) > 128:
        raise ValueError("Invalid observer metadata")
    out = {"schema_version": version, "scope_count": len(rows), "pending_count": 0, "error_count": 0,
           "no_decision_count": 0,
           "scheduled_review_count": 0, "unknown_count": 0, "last_completed_at": None,
           "next_review_at": None, "next_opportunity_at": None}
    for key, row in rows.items():
        if (not isinstance(row, dict) or version == 2 and
                (not isinstance(key, str) or re.fullmatch(r"(?:private|group):[1-9][0-9]*", key) is None)):
            raise ValueError("Invalid observer owner metadata")
        if row.get("pending") is not None:
            if not isinstance(row["pending"], dict):
                raise ValueError("Invalid pending metadata")
            out["pending_count"] += 1
        error = row.get("observer_error")
        if error is not None:
            if (not isinstance(error, dict) or not isinstance(error.get("error_class"), str) or
                    not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,79}", error["error_class"]) or
                    any(type(error.get(key)) is not int or not 0 <= error[key] <= 9007199254740991
                        for key in ("first_seen_at", "last_seen_at"))):
                raise ValueError("Invalid observer error metadata")
            out["error_count"] += 1
        status = row.get("last_status")
        if status not in (None, "decided", "sent", "unknown", "suppressed", "no_decision"):
            raise ValueError("Invalid decision status")
        out["unknown_count"] += int(status == "unknown")
        out["no_decision_count"] += int(status == "no_decision")
        for field in ("last_completed_at", "next_review_at", "next_opportunity_at"):
            when = row.get(field)
            if when is not None:
                if type(when) is not int or not 0 <= when <= 9007199254740991:
                    raise ValueError("Invalid observer timestamp")
                previous = out[field]
                out[field] = when if previous is None else (max(previous, when) if field == "last_completed_at" else min(previous, when))
        out["scheduled_review_count"] += int(row.get("next_review_at") is not None)
    return out


def autonomy_snapshot(now=None, owner_probe=None):
    result = {"mode": "unknown", "managed_by": "main_agent", "status": "unknown",
              "reason": "metadata_unavailable", "can_request_check": False}
    try:
        from main_agent_watch import public_status
        result["watch"] = public_status(DATA, now=now)
    except (ImportError, OSError, ValueError, TypeError):
        result["watch"] = {"configured": False, "status": "unknown", "reason": "watch_reader_unavailable"}
    try:
        mode = decision_mode()
        result["mode"] = mode
        if mode == "legacy":
            return dict(result, managed_by="legacy_task", status="legacy", reason="legacy_mode")
        stamp = _read_metadata(os.path.join(NAPCAT, "scheduler-in-plugin.flag"), 65536)
        pid, at, jobs = stamp.get("pid"), stamp.get("at"), stamp.get("jobs")
        if (stamp.get("version") != 2 or type(pid) is not int or not 0 < pid <= 0xffffffff
                or type(at) is not int or not isinstance(jobs, list) or "mind" not in jobs
                or len(jobs) > 64 or not all(isinstance(job, str) and len(job) <= 128 for job in jobs)):
            return dict(result, reason="scheduler_metadata_invalid")
        age = ((time.time() if now is None else now) * 1000 - at) / 1000
        if not -5 <= age <= 120:
            return dict(result, status="offline", reason="scheduler_stale")
        owner = (owner_probe or _scheduler_owner_verified)(pid, at)
        if owner is not True:
            return dict(result, status="offline" if owner is False else "unknown", reason="scheduler_owner_unverified")
        lease = _consumer_matches(pid)
        if lease is not True:
            return dict(result, status="offline" if lease is False else "unknown", reason="consumer_owner_unverified")
        mind_file = os.path.join(DATA, "mind.json")
        summary = _mind_metadata(_read_metadata(mind_file) if os.path.isfile(mind_file) else {})
        if summary["error_count"]:
            status, reason = "uncertain", "observer_evidence_missing"
        elif summary["scheduled_review_count"]:
            status, reason = "scheduled", "main_review_scheduled"
        elif summary["pending_count"]:
            status, reason = "processing", "decision_pending"
        elif summary["unknown_count"]:
            status, reason = "uncertain", "previous_outcome_unknown"
        else:
            status, reason = "waiting", "waiting_for_opportunity"
        return dict(result, status=status, reason=reason, can_request_check=True,
                    scheduler_verified=True, consumer_verified=True, observer=summary)
    except (OSError, ValueError, TypeError, sqlite3.Error, project_conf.ConfigError):
        return result


def decorate_autonomy_components(components, status):
    output = []
    for original in components:
        row = dict(original)
        if row.get("tag") in ("lifeloop", "mind") and status.get("mode") != "legacy":
            row.update(kind="timer", managed_by="main_agent", autonomy=status,
                       control="request_check", status=status["status"])
        elif row.get("tag") in _RETIRED_UNIFIED and status.get("mode") != "legacy":
            row["control"] = "retired"
        output.append(row)
    return output


def request_autonomy_check():
    global _AUTONOMY_REQUEST
    status = autonomy_snapshot()
    if status.get("mode") != "unified" or status.get("can_request_check") is not True:
        return {"ok": False, "code": "autonomy_unavailable", "error": "\u4e3b agent \u8c03\u5ea6\u72b6\u6001\u672a\u786e\u8ba4\uff0c\u8bf7\u68c0\u67e5\u8fd0\u884c\u72b6\u6001", "autonomy": status}
    with _AUTONOMY_REQUEST_LOCK:
        now = time.monotonic()
        previous = _AUTONOMY_REQUEST["process"]
        if previous is not None and (previous.poll() is None or now - _AUTONOMY_REQUEST["at"] < 15):
            return {"ok": True, "status": "already_requested", "observation_only": True,
                    "producer_started": False, "decision_completed": False,
                    "note": "\u5df2\u6709\u68c0\u67e5\u8bf7\u6c42\uff0c\u6ca1\u6709\u91cd\u590d\u542f\u52a8"}
        script = _ordinary_metadata(os.path.join(NAPCAT, "mind.py"))
        if not os.path.isfile(script):
            return {"ok": False, "code": "observer_missing", "error": "mind.py \u89c2\u5bdf\u751f\u4ea7\u8005\u4e0d\u5b58\u5728"}
        try:
            process = subprocess.Popen([str(project_conf.get("pythonExecutable", sys.executable) or sys.executable), script, "--force", "--observe-only"],
                                       cwd=NAPCAT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except OSError:
            return {"ok": False, "code": "observer_start_failed", "error": "\u89c2\u5bdf\u751f\u4ea7\u8005\u542f\u52a8\u5931\u8d25\uff0c\u6ca1\u6709\u6267\u884c\u6d3b\u52a8"}
        _AUTONOMY_REQUEST = {"at": now, "process": process}
        return {"ok": True, "status": "requested", "observation_only": True,
                "producer_started": True, "decision_completed": False,
                "note": "\u5df2\u8bf7\u6c42\u4e3b agent \u68c0\u67e5\u3002\u53ea\u63d0\u4ea4\u89c2\u5bdf\uff0c\u4e0d\u4ee3\u8868\u5df2\u5f00\u59cb\u6d3b\u52a8\u6216\u53d1\u9001\u6d88\u606f"}


def autonomy_label(status):
    if status.get("reason") == "observer_evidence_missing":
        return "\u4e3b agent \u6258\u7ba1\uff0c\u90e8\u5206\u89c2\u5bdf\u8bc1\u636e\u7f3a\u5931"
    return {"waiting": "\u4e3b agent \u6258\u7ba1\uff0c\u7b49\u5f85\u81ea\u4e3b\u673a\u4f1a", "scheduled": "\u4e3b agent \u6258\u7ba1\uff0c\u5df2\u7ea6\u590d\u67e5",
            "processing": "\u4e3b agent \u6258\u7ba1\uff0c\u89c2\u5bdf\u5f85\u5904\u7406", "uncertain": "\u4e3b agent \u6258\u7ba1\uff0c\u4e0a\u6b21\u7ed3\u679c\u672a\u77e5",
            "offline": "\u4e3b agent \u8c03\u5ea6\u79bb\u7ebf", "unknown": "\u4e3b agent \u8c03\u5ea6\u72b6\u6001\u672a\u786e\u8ba4"}.get(status.get("status"), "\u72ec\u7acb\u6d3b\u52a8\u5faa\u73af")


def autonomy_settings_snapshot():
    from panel_autonomy import get_settings
    result = get_settings()
    result["runtime"] = autonomy_snapshot()
    return result


def unified_budget_snapshot(*, include_daily=True):
    try:
        import budget_runtime
        value = budget_runtime.get_snapshot()
        enforcement = dict(value.get("enforcement") or {})
        bound = False
        if enforcement.get("runtime_gate_bound") is True:
            try:
                from panel_autonomy import _record
                evidence = budget_runtime.gate_evidence()
                stamp = _read_metadata(os.path.join(NAPCAT, "scheduler-in-plugin.flag"), 65536)
                pid, at = evidence.get("pid"), evidence.get("at")
                scheduler_at = stamp.get("at")
                valid = (type(pid) is int and 0 < pid <= 0xffffffff and type(at) is int and
                         at == enforcement.get("gate_last_seen") and stamp.get("version") == 2 and
                         stamp.get("pid") == pid and type(scheduler_at) is int and
                         isinstance(stamp.get("jobs"), list) and "mind" in stamp["jobs"] and
                         0 <= time.time() * 1000 - at <= 90000 and
                         -5000 <= time.time() * 1000 - scheduler_at <= 120000)
                adapter = os.path.join(PROFILE, "node_modules", "dsh-onebot-qq", "lib", "lanya-policy-adapter.js")
                config = _read_metadata(os.path.join(os.path.dirname(adapter), "lanya-policy.config.json"))
                helper = os.path.abspath(budget_runtime.__file__)
                configured_helper = config.get("budgetRuntimeScript")
                valid = (valid and isinstance(configured_helper, str) and os.path.isabs(configured_helper) and
                         os.path.normcase(os.path.abspath(configured_helper)) == os.path.normcase(helper) and
                         _record(helper)[0]["sha256"] == evidence.get("helper_source_sha256") and
                         _record(adapter)[0]["sha256"] == evidence.get("adapter_source_sha256"))
                bound = (valid and _scheduler_owner_verified(pid, min(at, scheduler_at)) is True and
                         _consumer_matches(pid) is True and _read_metadata(os.path.join(NAPCAT, "scheduler-in-plugin.flag"), 65536) == stamp)
            except Exception:
                bound = False
        enforcement.pop("gate_pid", None)
        enforcement.update(runtime_gate_bound=bool(bound), runtime_owner_verified=bool(bound))
        value = dict(value, enforcement=enforcement)
        if include_daily:
            try:
                from budget_reports import native_daily_spending
                options = _panel_native_record_options()
                node = next((path for path in _executable_paths("NODE_EXE", "tools.nodeExecutable", "node", (
                    [os.path.join(DSH_ROOT, "resources", "runtime", "node", "node.exe")] if DSH_ROOT else []))
                    if os.path.isabs(path) and os.path.isfile(path)), None)
                value["daily_spending"] = native_daily_spending(**options, node_executable=node)
            except Exception:
                # Reporting failures never become zero spending or weaken the gate.
                value["daily_spending"] = None
        # Reporting can cover earlier native turns; quota enforcement retains
        # its own recorded usage and is never reconstructed from the report.
        value["gate_usage"] = value.get("usage")
        return value
    except Exception:
        # A missing/unreadable ledger is unavailable, never a fresh zero balance.
        return {"schema": "unified-budget/v2", "availability": "error", "status": "unavailable",
                "revision": None, "effective": None, "usage": None,
                "enforcement": {"before_turn": False, "before_action": False, "provider_hard_cap": False}}


def panel_voice_status_snapshot(components, observed_at):
    try:
        from voice_status import voice_status
        return voice_status(runtime_dir=NAPCAT, components=components,
                            mode=decision_mode(), port=project_conf.get("ttsPort", 9880),
                            observed_at=observed_at)
    except Exception:
        # Reporting is read-only. Unknown infrastructure is not a synthesis failure.
        return {"schema": "dsh-voice-status/v1", "mode": "unknown", "execution": "unknown",
                "daemon_required": None, "daemon_process_count": None,
                "executor": {"installed": None},
                "engine": {"type": "local_tts_process_observation", "process_count": None,
                           "observed_at": None, "observation_state": "unavailable", "port": None},
                "synthesis": {"state": "not_probed"}, "delivery": {"state": "unverified"},
                "read_only": True}


def panel_raw_state_metadata():
    candidates = []
    for name in ("lanya-state.json", "dafeiyu-state.json"):
        try:
            file = os.path.join(ROOT, name)
            value = _read_metadata(file, 4 * 1024 * 1024)
            candidates.append((os.stat(file).st_mtime_ns, value))
        except (OSError, ValueError, TypeError):
            pass
    return max(candidates, key=lambda row: row[0])[1] if candidates else {"at": None, "memory": {}, "components": [], "plugins": []}


def voice_status_snapshot():
    value = panel_raw_state_metadata()
    return panel_voice_status_snapshot(value.get("components") or [], value.get("at"))


def selected_backend_component(observed=None):
    """Current configuration plus fresh matching background health, no probe."""
    facts = dict(provider=None, name="QQ 接入", verified=False, status="unconfirmed")
    try:
        project_conf.load(reload=True)
        spec, _, _, _, _, _ = qq_backend.describe()
        facts.update(provider=spec.key, name=spec.name)
        selected = _qq_connection()
        facts.update(provider=selected.provider, name=selected.name)
        age = time.time() * 1000 - observed.get("observed_at", -1) if type(observed) is dict else -1
        if (type(age) in (int, float) and 0 <= age <= 120000 and
                observed.get("provider") == selected.provider and observed.get("config_fingerprint") == selected.fingerprint and
                observed.get("verified") is True and all(observed.get(key) is True for key in
                    ("online", "good", "logged_in", "provider_matches", "account_matches"))):
            facts.update(verified=True, status="online")
    except (qq_backend.BackendError, TypeError, ValueError):
        pass
    return dict(tag="qq-backend", desc="selected QQ backend", count=1 if facts["verified"] else None,
        mb=0, aging=0, backend=facts)


def panel_state_snapshot():
    value = panel_raw_state_metadata()
    memory = value.setdefault("memory", {})
    if "lanyaMb" not in memory and "dafeiyuMb" in memory:
        memory["lanyaMb"] = memory["dafeiyuMb"]
    status = autonomy_snapshot()
    value["autonomy"] = status
    value["components"] = decorate_autonomy_components(value.get("components") or [], status)
    value["components"] = [row for row in value["components"] if row.get("tag") not in ("napcat", "qq-backend")]
    backend_row = selected_backend_component(value.get("qqBackend"))
    value["components"].append(backend_row)
    value["qqBackend"] = backend_row["backend"]
    services = panel_services()
    old = [row for row in value["components"] if row.get("tag") in ("works", "panel-api")]
    value["components"] = [row for row in value["components"] if row.get("tag") not in ("works", "panel-api")]
    for role, tag in (("works", "works"), ("api", "panel-api")):
        service = services[role]
        row = dict(next((row for row in old if row.get("tag") == tag), {}))
        row.update(tag=tag, kind="server", service=service)
        for field in ("count", "mb"):
            if service[field] is not None:
                row[field] = service[field]
            else:
                row.setdefault(field, None)
        if role == "works":
            row["control"] = "ensure_works"
        value["components"].append(row)
    delta = sum((row.get("mb") or 0) for row in value["components"] if row.get("tag") in ("works", "panel-api")) - sum((row.get("mb") or 0) for row in old)
    for key in ("lanyaMb", "dafeiyuMb"):
        if type(memory.get(key)) in (int, float):
            memory[key] = round(memory[key] + delta, 1)
    value["services"] = services
    value["voice"] = panel_voice_status_snapshot(value["components"], value.get("at"))
    if status.get("mode") == "unified":
        value["components"] = [row for row in value["components"] if row.get("tag") != "voicedaemon"]
    return value


def panel_services():
    ports = {"works": project_conf.get("panelStaticPort", 19388), "api": project_conf.get("panelPort", 19389)}
    unknown = lambda: {role: {"role": role, "port": port, "count": None, "mb": None,
                              "healthy": False, "status": "unknown", "listening": None} for role, port in ports.items()}
    try:
        import urllib.request
        with urllib.request.urlopen("http://127.0.0.1:19387/dsh-lanya/api/services", timeout=12) as response:
            raw = response.read(16385)
            if len(raw) > 16384:
                return unknown()
        value = json.loads(raw.decode("utf-8"))
        if value.get("ok") is not True:
            return unknown()
        result = {}
        for role, port in ports.items():
            row = value["services"][role]
            if (row.get("role") != role or type(row.get("port")) is not int or row["port"] != port or
                    type(row.get("healthy")) is not bool or row.get("status") not in ("healthy", "offline", "starting", "unhealthy", "blocked", "unknown") or
                    row.get("listening") is not None and type(row["listening"]) is not bool or
                    row.get("count") is not None and (type(row["count"]) is not int or row["count"] < 0) or
                    row.get("mb") is not None and (type(row["mb"]) not in (int, float) or not math.isfinite(row["mb"]) or row["mb"] < 0) or
                    row["healthy"] and (row["status"] != "healthy" or row["count"] != 1 or row["listening"] is not True)):
                return unknown()
            result[role] = {key: row.get(key) for key in ("role", "port", "count", "mb", "healthy", "status", "listening")}
        return result
    except Exception:
        return unknown()


def request_works_service():
    try:
        import urllib.request
        request = urllib.request.Request("http://127.0.0.1:19387/dsh-lanya/api/action",
            data=b'{"target":"works","op":"ensure"}', headers={"content-type": "application/json"}, method="POST")
        with urllib.request.urlopen(request, timeout=25) as response:
            raw = response.read(4097)
        if len(raw) > 4096:
            raise ValueError()
        value = json.loads(raw.decode("utf-8"))
        if (value.get("ok") is True and value.get("service_check") is True and type(value.get("healthy")) is bool
                and value.get("status") in ("healthy", "starting")):
            return {"ok": True, "service_check": True, "healthy": value["healthy"], "status": value["status"],
                    "note": "\u670d\u52a1\u5df2\u5728\u8fd0\u884c\uff0c\u6ca1\u6709\u91cd\u590d\u542f\u52a8" if value["healthy"] else "\u5df2\u8bf7\u6c42\u540e\u53f0\u6062\u590d\uff0c\u7b49\u5f85\u771f\u5b9e\u5065\u5eb7\u68c0\u67e5"}
    except Exception:
        pass
    return {"ok": False, "service_check": True, "healthy": False, "error": "\u4f5c\u54c1\u670d\u52a1\u770b\u62a4\u672a\u786e\u8ba4\uff0c\u8bf7\u68c0\u67e5\u8fd0\u884c\u72b6\u6001"}


def control_action(body):
    target, op = str(body.get("target") or ""), str(body.get("op") or "run")
    if target == "works":
        if op not in ("run", "start", "restart", "ensure"):
            return {"ok": False, "error": "Works service is supervised; stop is not offered"}
        return request_works_service()
    if target in ("lifeloop", "mind"):
        mode = decision_mode()
        if mode != "legacy":
            if op not in ("run", "start", "restart", "check"):
                return {"ok": False, "error": "\u7edf\u4e00\u6a21\u5f0f\u53ea\u63a5\u53d7\u8bf7\u6c42\u68c0\u67e5\uff0c\u4e0d\u505c\u6b62\u4e3b agent"}
            return request_autonomy_check()
    if op not in ("run", "start", "restart"):
        return {"ok": False, "error": "Unsupported component action"}
    result = run_task(target)
    if result is not None:
        return result
    return {"ok": True, "pid": run_script(target)}


def update_source_repository():
    """Pull this checkout's upstream once; never deploy or reload programs."""
    if not _SOURCE_UPDATE_LOCK.acquire(blocking=False):
        return 409, {"ok": False, "code": "source_update_busy", "error": "A source update is already running"}
    try:
        repo = os.environ.get("LANYA_REPO") or os.path.join(os.path.dirname(NAPCAT), "dsh-lanya")

        def git(*args, timeout=20):
            return subprocess.run(["git", "-C", repo, *args], capture_output=True, text=True,
                                  encoding="utf-8", errors="replace", timeout=timeout,
                                  creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))

        before = git("rev-parse", "--verify", "HEAD")
        branch = git("symbolic-ref", "--quiet", "HEAD")
        if before.returncode or re.fullmatch(r"(?:[a-f0-9]{40}|[a-f0-9]{64})", before.stdout.strip()) is None:
            return 409, {"ok": False, "code": "source_head_unavailable", "error": "A valid repository HEAD is required"}
        upstream = git("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{upstream}")
        tracked = git("rev-parse", "--verify", "@{upstream}^{commit}") if upstream.returncode == 0 else None
        if (branch.returncode or not branch.stdout.strip() or upstream.returncode or not upstream.stdout.strip() or tracked is None or tracked.returncode or
                re.fullmatch(r"(?:[a-f0-9]{40}|[a-f0-9]{64})", tracked.stdout.strip()) is None):
            return 409, {"ok": False, "code": "source_upstream_unavailable", "error": "The current branch needs a valid tracking upstream"}
        status = git("status", "--porcelain", "--untracked-files=normal")
        if status.returncode:
            return 503, {"ok": False, "code": "source_status_unavailable", "error": "Cannot verify a clean working tree"}
        if status.stdout.strip():
            return 409, {"ok": False, "code": "source_worktree_dirty", "error": "Commit or preserve local changes before updating source"}
        fetched = git("fetch", timeout=180)
        if fetched.returncode:
            return 502, {"ok": False, "code": "source_fetch_failed", "error": "Source fetch failed; no merge or deployment was requested"}
        current_head, current_branch = git("rev-parse", "--verify", "HEAD"), git("symbolic-ref", "--quiet", "HEAD")
        current_upstream = git("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{upstream}")
        target = git("rev-parse", "--verify", "@{upstream}^{commit}")
        status = git("status", "--porcelain", "--untracked-files=normal")
        if (current_head.returncode or current_branch.returncode or current_upstream.returncode or target.returncode or status.returncode or
                current_head.stdout.strip() != before.stdout.strip() or current_branch.stdout.strip() != branch.stdout.strip() or
                current_upstream.stdout.strip() != upstream.stdout.strip() or status.stdout.strip() or
                re.fullmatch(r"(?:[a-f0-9]{40}|[a-f0-9]{64})", target.stdout.strip()) is None):
            return 409, {"ok": False, "code": "source_changed_during_fetch", "error": "Source checkout changed during fetch; merge refused"}
        merged = git("merge", "--ff-only", "--no-edit", "--no-overwrite-ignore", "--", target.stdout.strip(), timeout=180)
        if merged.returncode:
            return 502, {"ok": False, "code": "source_merge_failed", "error": "Fast-forward source merge refused; local files were not intentionally overwritten"}
        after = git("rev-parse", "--verify", "HEAD")
        if after.returncode or re.fullmatch(r"(?:[a-f0-9]{40}|[a-f0-9]{64})", after.stdout.strip()) is None:
            return 503, {"ok": False, "code": "source_readback_unavailable", "error": "Pull finished but its source HEAD could not be verified"}
        first, last = before.stdout.strip(), after.stdout.strip()
        changed = []
        if first != last:
            history = git("log", "--oneline", "-20", first + ".." + last)
            if history.returncode:
                return 503, {"ok": False, "code": "source_readback_unavailable", "error": "Source changed but its commit summary could not be verified"}
            changed = [line[:300] for line in history.stdout.splitlines() if line.strip()]
        return 200, {"ok": True, "changed": changed, "before": first, "after": last,
                     "source_only": True, "deployment_performed": False, "runtime_loading": "not_verified",
                     "message": "源码已拉取新提交；本接口不执行部署或重载。" if first != last else
                                "源码没有新提交；本接口不执行部署或重载。"}
    except (OSError, subprocess.SubprocessError):
        return 503, {"ok": False, "code": "source_update_unavailable", "error": "Source update could not be verified; no automatic retry"}
    finally:
        _SOURCE_UPDATE_LOCK.release()



# ---------------------------------------------------------------------------
# 外部工具：NapCat / QQ / Node / Python / Git / DSH 本身。
# 面板上要能看到它们在不在、什么版本、跑没跑，用不着开命令行去查。
# ---------------------------------------------------------------------------
TOOLS = [
    {"key": "napcat", "name": "NapCat", "kind": "QQ 注入框架",
     "paths": [os.path.join(REPO, "napcat", "framework", "napimain.exe")],
      "port": project_conf.get("onebotPort", 8720),
     "note": "注入进 QQ 的那一层。没有它，机器人连不上。"},
    {"key": "qq", "name": "QQ", "kind": "QQ 客户端",
     "paths": _executable_paths("QQ_EXE", "tools.qqExecutable", "QQ.exe"),
     "proc": "QQ.exe",
     "note": "机器人小号登录的地方。"},
    {"key": "dsh", "name": "DeepSeek Harness", "kind": "宿主程序",
     "paths": [os.path.join(DSH_ROOT, "DeepSeek Harness.exe")] if DSH_ROOT else [],
     "port": 19387,
     "note": "整个系统跑在里面。插件都挂在它上面。"},
    {"key": "node", "name": "Node.js", "kind": "运行时",
     "paths": _executable_paths("NODE_EXE", "tools.nodeExecutable", "node", (
         [os.path.join(DSH_ROOT, "resources", "runtime", "node", "node.exe")] if DSH_ROOT else [])),
     "note": "插件是 JS 写的，靠它跑。"},
    {"key": "python", "name": "Python", "kind": "运行时",
     "paths": _executable_paths("LANYA_PYTHON", "tools.pythonExecutable", "python", [sys.executable]),
     "note": "面板服务、表情包处理、刷 B 站都靠它。"},
    {"key": "python-tts", "name": "Python (语音环境)", "kind": "专用环境",
     "paths": _executable_paths("LANYA_TTS_PYTHON", "tts.pythonExecutable", "python-tts", [TTS_START]),
     "note": "独立语音环境由本机 TTS 启动脚本管理。"},
    {"key": "git", "name": "Git", "kind": "版本控制",
     "paths": _executable_paths("GIT_EXE", "tools.gitExecutable", "git"),
     "note": "拉插件、更新插件用。"},
]


def port_open(port):
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.35)
    try:
        return s.connect_ex(("127.0.0.1", int(port))) == 0
    finally:
        s.close()


def tool_status(item):
    found = None
    for p in item.get("paths", []):
        if os.path.isfile(p):
            found = p
            break
    version = ""
    if found:
        try:
            # FileVersionInfo 只有 Windows 有；纯 Python 读不到的话就留空。
            version = ""
        except Exception:
            version = ""
    running = None
    if item.get("port"):
        running = port_open(item["port"])
    elif item.get("proc"):
        try:
            out = subprocess.run(["tasklist.exe", "/FI", "IMAGENAME eq " + item["proc"]],
                                 capture_output=True, timeout=10,
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            running = item["proc"].lower() in (out.stdout or b"").decode("utf-8", "replace").lower()
        except Exception:
            running = False
    return {
        "key": item["key"],
        "name": item["name"],
        "kind": item.get("kind", ""),
        "note": item.get("note", ""),
        "path": found or "",
        "installed": bool(found) or running is True,
        "running": running,
        "update_supported": item["key"] in UPSTREAM,
        "port": item.get("port"),
    }



# 每个工具的上游仓库，用来查最新版本。查不到不算错——离线时本来就不通。
UPSTREAM = {
    "napcat": ("NapNeko/NapCatQQ", "NapCat"),
    "snowluma": ("SnowLuma/SnowLuma", "SnowLuma"),
}


def check_upstream(key):
    """Return the latest release tag from GitHub, or None if unreachable."""
    repo = UPSTREAM.get(key)
    if not repo:
        return None
    url = "https://api.github.com/repos/" + repo[0] + "/releases/latest"
    try:
        import urllib.request, json as _json
        req = urllib.request.Request(url, headers={
            "User-Agent": "lanya-panel",
            "Accept": "application/vnd.github+json",
        })
        with urllib.request.urlopen(req, timeout=12) as r:
            data = _json.loads(r.read().decode("utf-8", "replace"))
        return data.get("tag_name") or data.get("name")
    except Exception:
        return None


def tools_snapshot():
    result = [tool_status(x) for x in TOOLS if x['key'] != 'napcat']
    facts = selected_backend_component(panel_raw_state_metadata().get('qqBackend'))['backend']
    try:
        project_conf.load(reload=True)
        spec, _, root, _, _, _ = qq_backend.describe()
        result.insert(0, dict(key=spec.key, name=spec.name, kind="QQ 接入后端",
            note="部件页选择的后端；在线状态依据近期账号与版本核验，实际消息单独确认。",
            path=str(root) if qq_backend.installed(spec, root) else '', installed=qq_backend.installed(spec, root),
            running=True if facts['verified'] else None, update_supported=True, port=None))
    except qq_backend.BackendError:
        result.insert(0, dict(key='qq-backend', name='QQ 接入', kind='QQ 接入后端',
            note='所选接入配置未确认，请在部件页重新读取。', path='', installed=False,
            running=None, update_supported=False, port=None))
    return result


def decode_task_output(raw, oem_encoding=None):
    """schtasks writes the Windows OEM codepage, not UTF-8."""
    if not raw:
        return ""
    if raw.startswith(b"\xff\xfe") or raw.startswith(b"\xfe\xff"):
        encoding = "utf-16"
    elif raw.startswith(b"\xef\xbb\xbf"):
        encoding = "utf-8-sig"
    else:
        if oem_encoding is None:
            if os.name == "nt":
                import ctypes
                oem_encoding = "cp" + str(ctypes.windll.kernel32.GetOEMCP())
            else:
                oem_encoding = "utf-8"
        encoding = oem_encoding
    try:
        return raw.decode(encoding, "strict").strip()
    except (UnicodeError, LookupError):
        return "Windows task output could not be decoded (" + encoding + ")"


def run_task(name):
    if name == "works":
        raise ValueError("Works service belongs to the panel service supervisor")
    if name in _RETIRED_UNIFIED and decision_mode() != "legacy":
        raise ValueError("Unified mode retires this scheduled task; request a main-agent check")
    task = TASKS.get(name)
    if not task:
        return None
    p = subprocess.run(
        ["schtasks.exe", "/run", "/tn", task],
        capture_output=True, timeout=60,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    ok = p.returncode == 0
    return {"ok": ok, "task": task,
            "log": decode_task_output(p.stdout) or decode_task_output(p.stderr)}



# ---------------------------------------------------------------------------
# Extra data the multi-page console needs: budget, memes, notes/diary, works.
# ---------------------------------------------------------------------------
LANYA_DIR = DATA
MEME_ROOT = os.path.join(
    os.path.join(os.path.expanduser("~"), ".dsh", "profiles", "desktop",
                            "node_modules", "dsh-meme", "memes"),
    "dafeiyu-001", "memes")

# 允许页面上浏览的目录。白名单，不接受任意路径 - 这是给浏览器用的接口，
# 不能让它顺着 ../ 读到别处去。
ACTIVITIES = os.path.join(DATA, "activities.json")
ARCHIVE_ROOT = os.path.join(REPO, DATA_NAME + "-\u5f52\u6863")

FILE_DIRS = {
    "diary":  os.path.join(LANYA_DIR, "diary"),
    "notes":  os.path.join(LANYA_DIR, "notes"),
    "made":   os.path.join(LANYA_DIR, "made"),
    "people": os.path.join(LANYA_DIR, "people"),
    "archive": ARCHIVE_ROOT,
}

IMG_EXT = (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp")


def safe_name(name):
    """Reject anything that could escape its directory."""
    if not name:
        return None
    base = os.path.basename(str(name))
    if base != str(name) or base.startswith("."):
        return None
    return base


def list_memes(tag=None):
    out = []
    if not os.path.isdir(MEME_ROOT):
        return out
    tags = [tag] if tag else sorted(os.listdir(MEME_ROOT))
    for tg in tags:
        d = os.path.join(MEME_ROOT, tg)
        if not os.path.isdir(d):
            continue
        files = [f for f in sorted(os.listdir(d)) if f.lower().endswith(IMG_EXT)]
        if files:
            out.append({"tag": tg, "count": len(files), "files": files})
    return out


# The panel's own files are not her works. Deciding that by a "lanya-" prefix
# broke the moment everything got renamed: every picture and page in made/ then
# started with lanya- too, and the works page went blank. Match the artifacts
# the server actually writes, in either naming generation.
_PANEL_PREFIXES = ("lanya-panel", "dafeiyu-panel", "theme-")
_PANEL_STEMS = {"state", "persona", "memory", "memes", "memes-config", "tools", "works",
                "schedule", "budget", "config", "bili", "tunables"}


def is_panel_artifact(name):
    low = name.lower()
    if low.startswith(_PANEL_PREFIXES):
        return True
    for pre in ("lanya-", "dafeiyu-"):
        if low.startswith(pre):
            rest = low[len(pre):]
            stem = rest.split(".")[0]
            return stem.startswith("files-") or stem in _PANEL_STEMS
    return False


def list_dir_files(key, with_preview=False, limit=0):
    # 归档目录按批次分子文件夹，得递归；名字带上子目录才分得清。
    if key == "archive":
        out = []
        root = FILE_DIRS["archive"]
        for dirpath, _dn, filenames in os.walk(root):
            rel = os.path.relpath(dirpath, root)
            for f in filenames:
                # 归档里混着会话日志（session.v4.jsonl.zstd）——那是聊天
                # 隐私数据，不是作品，不能列在页面上给人翻。
                if f.endswith(".zstd") or "session.v4" in f or f.endswith(".lock.json"):
                    continue
                p = os.path.join(dirpath, f)
                try:
                    st = os.stat(p)
                except OSError:
                    continue
                nm = f if rel == "." else (rel.replace("\\", "/") + "/" + f)
                out.append({"name": nm, "size": st.st_size,
                            "mtime": int(st.st_mtime)})
        out.sort(key=lambda x: x["mtime"], reverse=True)
        return out[:800]

    """List files in one of the whitelisted folders.

    with_preview reads just the head of each file so the page can show a snippet
    instead of forcing a click on every entry. Reading all 8000 notes would be
    slow, so limit caps how many previews are produced.
    """
    root = FILE_DIRS.get(key)
    if not root or not os.path.isdir(root):
        return []
    items = []
    rows = []
    for f in os.listdir(root):
        p = os.path.join(root, f)
        if not os.path.isfile(p):
            continue
        try:
            st = os.stat(p)
        except OSError:
            continue
        # 面板自己的快照（state/memory/memes/... ）不是她的作品，
        # 列在作品页里只会让人更看不懂。判断按服务真正写的那几个文件名来，
        # 不再按前缀——改名之后前缀把所有东西都吞掉了。
        if is_panel_artifact(f):
            continue
        rows.append((f, p, st))
    rows.sort(key=lambda row: (-row[2].st_mtime_ns, row[0].casefold(), row[0]))
    if limit and limit > 0:
        rows = rows[:limit]
    for f, p, st in rows:
        row = {"name": f, "size": st.st_size, "mtime": int(st.st_mtime)}
        if key in ("diary", "notes", "people"):
            from memory_presentation import file_title
            row.update(file_title(p))
        if with_preview:
            try:
                with open(p, "r", encoding="utf-8", errors="replace") as fh:
                    head = fh.read(260)
                row["preview"] = " ".join(head.split())[:160]
            except Exception:
                row["preview"] = ""
        items.append(row)
    return items



# ---------------------------------------------------------------------------
# B 站插件（dsh-bili-scroll）的状态和 duty.md 编辑。
#
# 这个插件没有 HTTP 接口，它的「值得调」的东西只有两样：
#   duty.md   它要做什么 —— 改这个真的会影响行为
#   duty.log  它最近干了什么
#
# 所以页面不去伪造一堆看着能调其实没用的开关，只暴露这两个真的有效的。
# ---------------------------------------------------------------------------
BILI_HOME = os.path.join(os.path.expanduser("~"), ".dsh", "bili-duty")
BILI_DUTY = os.path.join(BILI_HOME, "duty.md")
BILI_LOG  = os.path.join(BILI_HOME, "duty.log")
BILI_SEEN = os.path.join(BILI_HOME, "seen.md")
COVER_CACHE_FILE = os.path.join(BILI_HOME, "cover-cache.json")


def _panel_native_record_options():
    """Only local trusted configuration selects native record owners."""
    config = project_conf.load(reload=True)
    decisions = config.get("decisions", {})
    if not isinstance(decisions, dict) or decisions.get("mode", "unified") not in ("unified", "legacy"):
        raise ValueError("Invalid decision configuration")
    preset = decisions.get("agentPreset", "")
    records = config.get("panelRecords", {})
    if not isinstance(records, dict) or not isinstance(preset, str):
        raise ValueError("Invalid record configuration")
    home = records.get("dshHome", os.path.join(os.path.expanduser("~"), ".dsh"))
    mapping = records.get("onebotMappingFile")
    if not isinstance(home, str) or not os.path.isabs(home) or (mapping is not None and
            (not isinstance(mapping, str) or not os.path.isabs(mapping))):
        raise ValueError("Invalid record paths")
    return dict(workspace=REPO, agent_preset=preset, identity_file=CONFIG,
                dsh_home=home, mapping_file=mapping, group_fallback=config.get("fanGroup", ""))


def panel_main_activity():
    """Trusted local projection only; request parameters cannot select owners."""
    try:
        from panel_activity import activity_snapshot
        return activity_snapshot(**_panel_native_record_options())
    except (OSError, ValueError, TypeError, ImportError, project_conf.ConfigError):
        base = {"status": "unavailable", "generated_at": int(time.time() * 1000),
                "records": [], "coverage": {"reasons": ["invalid_configuration"],
                                             "current_mapped_sessions_only": True}}
        return {"mainAgent": dict(base, schema="panel-bili-native/v1", counts={}),
                "recentActivity": dict(base, schema="panel-native-tools/v1")}


def panel_autonomy_plans():
    """Read existing intent reports using the local owner's fixed scopes."""
    try:
        from autonomy_intents_panel import intent_snapshot
        options = _panel_native_record_options()
        return intent_snapshot(workspace=options["workspace"], agent_preset=options["agent_preset"],
            identity_file=options["identity_file"], data_directory=DATA,
            group_fallback=options["group_fallback"])
    except (OSError, ValueError, TypeError, ImportError, project_conf.ConfigError):
        return {"schema": "dsh-autonomy-plans-panel/v1", "status": "unavailable", "read_only": True,
                "private": True, "plans": [], "summary_is_agent_report": True}


def panel_activity_journal(day=None, limit=90):
    """Only the configured local owner's managed fact diaries; never generates."""
    try:
        from activity_journal import journal_snapshot
        options = _panel_native_record_options()
        return journal_snapshot(workspace=options["workspace"], agent_preset=options["agent_preset"],
                                data_directory=DATA, day=day, limit=limit)
    except (OSError, ValueError, TypeError, ImportError, project_conf.ConfigError):
        return {"schema": "activity-journal/v1", "status": "error", "generated_at": int(time.time() * 1000),
                "read_only": True, "private": True, "days": [], "selected": None, "selected_status": "unavailable"}


def panel_narrative_diary(day=None, limit=90):
    """Local console reads the configured primary's diary, without generating."""
    try:
        from narrative_diary import narrative_snapshot
        from decision_events import project_scope
        options = _panel_native_record_options()
        return narrative_snapshot(workspace=options["workspace"], agent_preset=options["agent_preset"],
            data_directory=DATA, conversation_key=project_scope(), day=day, limit=limit)
    except (OSError, ValueError, TypeError, ImportError, project_conf.ConfigError):
        return {"schema": "narrative-diary/v1", "status": "error", "read_only": True,
                "private": True, "days": [], "selected": None, "error": "DiaryReadUnavailable"}


def _bili_cached_covers(bvids):
    """Panel refresh must not fetch platform data or write a cache."""
    try:
        cache = _read_metadata(COVER_CACHE_FILE, 2 * 1024 * 1024)
    except (OSError, ValueError, TypeError):
        cache = {}
    return {bvid: cache[bvid] for bvid in bvids if isinstance(cache.get(bvid), str)
            and re.fullmatch(r"https://[^\s<>]+", cache[bvid])}


def tail_file(path, lines=40, limit=20000):
    try:
        # A log preview must not allocate the entire growing file.
        with open(path, "rb") as fh:
            fh.seek(0, os.SEEK_END)
            fh.seek(max(0, fh.tell() - max(65536, limit * 4)))
            data = fh.read(max(65536, limit * 4)).decode("utf-8", "replace")
        return "\n".join(data.splitlines()[-lines:])[-limit:]
    except (OSError, ValueError, TypeError):
        return ""


# duty.log 里的启动噪音——这些每重启一次写一遍，跟刷了什么无关。
_BILI_NOISE = (
    "已挂载", "插件加载自", "私信监听", "值班轮用", "schemastery",
    "dsh-tools", "信任栅栏", "开始一轮", "轮次结束",
)


def bili_activity(log_text):
    """把 duty.log 分成「真活动」和「启动噪音」。"""
    real, noise = [], []
    for ln in (log_text or "").splitlines():
        ln = ln.strip()
        if not ln:
            continue
        if any(n in ln for n in _BILI_NOISE):
            noise.append(ln)
        else:
            real.append(ln)
    return real, noise


def _md_rows(text):
    """把一段 markdown 表格拆成行（去掉表头和分隔线）。"""
    rows = []
    for ln in (text or "").splitlines():
        ln = ln.strip()
        if not ln.startswith("|"):
            continue
        if set(ln) <= set("|-: "):
            continue
        cells = [c.strip() for c in ln.strip("|").split("|")]
        rows.append(cells)
    return rows


# ---------------------------------------------------------------------------
# B 站写操作：直接在这里发请求，不转子进程。
#
# 之前每删一条评论都 spawn 一个 venv python 跑 bili_account.py，光启动就
# 一两秒；再加上整页重载拉封面，删一条要等好几秒。这几件事都能就地做完。
# ---------------------------------------------------------------------------
_BILI_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/126.0 Safari/537.36")
_AID_CACHE_FILE = os.path.join(os.path.expanduser("~"), ".dsh", "bili-duty",
                               "aid-cache.json")


def _bili_cred():
    """Use the login writer's path, with the legacy location as a fallback."""
    home = os.path.join(os.path.expanduser("~"), ".dsh")
    for folder in (os.path.join(home, "bili-duty"), home):
        try:
            with open(os.path.join(folder, "bili_credential.json"), "r",
                      encoding="utf-8-sig") as fh:
                cred = json.load(fh)
            if isinstance(cred, dict) and cred.get("sessdata") and cred.get("bili_jct"):
                return cred
        except (OSError, ValueError):
            continue
    return {}


def _bili_cookie(c):
    parts = []
    for k, v in (("SESSDATA", "sessdata"), ("bili_jct", "bili_jct"),
                 ("buvid3", "buvid3"), ("DedeUserID", "dedeuserid")):
        if c.get(v):
            parts.append("%s=%s" % (k, c[v]))
    return "; ".join(parts)


def _bili_get(url, c):
    import urllib.request as _u
    req = _u.Request(url, headers={
        "user-agent": _BILI_UA,
        "referer": "https://www.bilibili.com/",
        "cookie": _bili_cookie(c)})
    with _u.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode("utf-8"))


def _bili_post(url, form, c):
    import urllib.parse as _up
    import urllib.request as _u
    body = _up.urlencode(form).encode("utf-8")
    req = _u.Request(url, data=body, headers={
        "user-agent": _BILI_UA,
        "referer": "https://www.bilibili.com/",
        "origin": "https://www.bilibili.com",
        "content-type": "application/x-www-form-urlencoded",
        "cookie": _bili_cookie(c)})
    with _u.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode("utf-8"))


def _aid_of(bvid):
    """BV -> aid，带本地缓存。同一个视频只查一次。"""
    try:
        with open(_AID_CACHE_FILE, "r", encoding="utf-8") as fh:
            cache = json.load(fh)
    except Exception:
        cache = {}
    if cache.get(bvid):
        return cache[bvid]
    try:
        d = _bili_get("https://api.bilibili.com/x/web-interface/view?bvid="
                      + bvid, _bili_cred())
        aid = (d.get("data") or {}).get("aid")
    except Exception:
        return None
    if aid:
        cache[bvid] = aid
        try:
            with open(_AID_CACHE_FILE, "w", encoding="utf-8") as fh:
                json.dump(cache, fh)
        except Exception:
            pass
    return aid


def bili_delete_comment(bvid, rpid):
    """删自己在某条视频下的评论。返回 (ok, 说明)。"""
    c = _bili_cred()
    if not c.get("bili_jct"):
        return False, "没有 bili_jct，重扫一次码"
    aid = _aid_of(bvid)
    if not aid:
        return False, "拿不到 aid"
    try:
        d = _bili_post("https://api.bilibili.com/x/v2/reply/del",
                       {"oid": aid, "rpid": rpid, "type": 1,
                        "csrf": c.get("bili_jct", "")}, c)
    except Exception as e:
        return False, str(e)[:120]
    if d.get("code") == 0:
        return True, "删掉了"
    return False, "code=%s %s" % (d.get("code"), d.get("message"))


def bili_follow(uid, act=1):
    c = _bili_cred()
    if not c.get("bili_jct"):
        return False, "没有 bili_jct"
    try:
        d = _bili_post("https://api.bilibili.com/x/relation/modify",
                       {"fid": uid, "act": act, "re_src": 11,
                        "csrf": c.get("bili_jct", "")}, c)
    except Exception as e:
        return False, str(e)[:120]
    if d.get("code") == 0:
        return True, "关注了" if act == 1 else "取关了"
    if d.get("code") == 22003:
        return True, "本来就关注着"
    return False, "code=%s %s" % (d.get("code"), d.get("message"))


def bili_cover_urls(bvids):
    """给一批 BV 号查封面图 URL，缓存在本地。

    只查没缓存的。B 站这个接口不需要登录。
    """
    cache = {}
    try:
        with open(COVER_CACHE_FILE, "r", encoding="utf-8") as fhc:
            cache = json.load(fhc)
    except Exception:
        cache = {}

    todo = [b for b in bvids if b and b not in cache]
    for bv in todo[:12]:           # 一次别查太多，页面会卡
        try:
            import urllib.request as _urc
            url = ("https://api.bilibili.com/x/web-interface/view?bvid=" + bv)
            req = _urc.Request(url, headers={
                "user-agent": "Mozilla/5.0",
                "referer": "https://www.bilibili.com/"})
            with _urc.urlopen(req, timeout=12) as rc:
                d = json.loads(rc.read().decode("utf-8"))
            pic = ((d.get("data") or {}).get("pic") or "")
            cache[bv] = pic
        except Exception:
            cache[bv] = ""

    try:
        os.makedirs(os.path.dirname(COVER_CACHE_FILE), exist_ok=True)
        with open(COVER_CACHE_FILE, "w", encoding="utf-8") as fhc2:
            json.dump(cache, fhc2, ensure_ascii=False)
    except Exception:
        pass
    return {b: cache.get(b, "") for b in bvids}


def bili_seen_detail(seen_text):
    """从判重表里拆出「评论记录」和「看过的视频」。

    真实格式（插件写的）：
      评论：| BV | rpid | root | 时间 | 正文前 20 字 |
      视频：| 日期 | BV | 标题 | UP | 状态 |
    表头行（第一行含 BV 字样）要跳过。
    """
    comments, videos = [], []
    if not seen_text:
        return comments, videos

    seg = seen_text.split("## 评论记录", 1)
    if len(seg) == 2:
        body = seg[1].split("## 看过的视频")[0]
        for cells in _md_rows(body):
            if not cells or cells[0].lower() == "bv" or "BV" == cells[0]:
                continue              # 表头
            if len(cells) < 5 or not cells[0].startswith("BV"):
                continue
            comments.append({"bv": cells[0],
                             "rpid": cells[1],
                             "time": cells[3],
                             "text": cells[4]})

    seg2 = seen_text.split("## 看过的视频", 1)
    if len(seg2) == 2:
        for cells in _md_rows(seg2[1]):
            if not cells:
                continue
            if cells[0] in ("日期", "date"):
                continue              # 表头
            if len(cells) >= 5:
                videos.append({"date": cells[0], "bv": cells[1],
                               "title": cells[2], "up": cells[3],
                               "status": cells[4]})
            elif len(cells) >= 2:
                videos.append({"date": cells[0], "bv": cells[1],
                               "title": "", "up": "", "status": ""})
            elif cells[0].startswith("BV"):
                videos.append({"date": "", "bv": cells[0],
                               "title": "", "up": "", "status": ""})
    return comments, videos


def bili_snapshot():
    loaded = os.path.isdir(BILI_HOME)
    duty = ""
    if os.path.isfile(BILI_DUTY):
        try:
            with open(BILI_DUTY, "r", encoding="utf-8", errors="replace") as fh:
                duty = fh.read(1024 * 1024)
        except Exception:
            duty = ""
    # 不能只读尾巴：评论表在文件开头，视频表在末尾。
    # 之前 tail_file(60) 把评论全截掉了，页面上「她发过的评论」一直是空的。
    try:
        with open(BILI_SEEN, "r", encoding="utf-8", errors="replace") as _fhs:
            seen = _fhs.read(4 * 1024 * 1024)
    except Exception:
        seen = ""
    try:
        from panel_activity import read_bytes
        log = "\n".join(read_bytes(BILI_LOG, 2 * 1024 * 1024).decode("utf-8", "replace").splitlines()[-30:])
    except (OSError, ValueError, TypeError):
        log = ""
    # 判重表里「看过的视频」那段有内容 = 刷过
    watched = 0
    try:
        seg = seen.split("## 看过的视频", 1)
        if len(seg) == 2:
            watched = len([x for x in seg[1].splitlines() if x.strip()])
    except Exception:
        pass
    real, noise = bili_activity(log)
    comments, videos = bili_seen_detail(seen)
    return {
        "installed": loaded,
        "home": BILI_HOME,
        "dutyChars": len(duty),
        "hasDuty": bool(duty.strip()),
        "watched": len(videos),
        "log": "\n".join(real[-40:]),       # 只给真活动
        "noiseCount": len(noise),
        "noise": "\n".join(noise[-5:]),
        "seen": seen,
        "comments": comments,
        "videos": videos,
        "covers": _bili_cached_covers([v.get("bv", "") for v in videos]),
        "mainAgent": panel_main_activity()["mainAgent"],
    }



# ---------------------------------------------------------------------------
# 统一的记忆视图。
#
# 她的记忆现在散在几处：memento 的审计流水（谁在什么时候写了什么）、
# 人物档案、日记、随笔。分开看就是四套东西，合成一个视图才能管。
# 模型写入仍走 memento；面板操作使用独立、可恢复的维护事务。
# ---------------------------------------------------------------------------
MEMENTO_DB = os.path.join(os.path.expanduser("~"), ".dsh", "dsh-memento", "memory.db")


def memento_rows(sql, args=(), limit=200, strict=False):
    try:
        from pathlib import Path
        uri = Path(MEMENTO_DB).absolute().as_uri() + "?mode=ro"
        with contextlib.closing(sqlite3.connect(uri, uri=True, timeout=5)) as con:
            con.execute("PRAGMA query_only=ON")
            cur = con.execute(sql, args)
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchmany(limit)]
    except Exception:
        if strict:
            raise ValueError("MemoryReadUnavailable") from None
        return []


def memory_owner_choices():
    from memory_context import list_owners, workspace_key_of, agent_key_of
    owners = list_owners(db_path=MEMENTO_DB)
    configured = dict(scope="workspace", workspace_key=workspace_key_of(project_conf.work_dir()),
                      agent_key=agent_key_of(project_conf.get("decisions.agentPreset", "") or ""))
    for track in ("user", "agent"):
        selected = dict(configured, track=track)
        if not any(all(row.get(key) == value for key, value in selected.items()) for row in owners):
            owners.append(dict(selected, count=0, origin="configured"))
    return owners


def memory_mutation(operation, body):
    from memory_mutations import mutate
    return mutate(operation, body, db_path=MEMENTO_DB, apply=True)


def memory_maintenance(operation, body):
    from memory_context import maintenance_selection
    selection = maintenance_selection(body.get("selection"))
    dry = body.get("dry", True)
    if type(dry) is not bool:
        raise ValueError("dry must be true or false")
    if operation not in ("consolidate", "compress"):
        raise ValueError("Unknown memory maintenance operation")
    import memory_plastic
    result = getattr(memory_plastic, operation)(dry=dry, **selection)
    return dict(result, selection=selection, view="maintenance")


def memory_records(query=None, limit=200, start=None, end=None, kind=None):
    """Administrator projection; never called to construct model context."""
    from memory_context import connect_readonly
    from memory_presentation import (project_entries, parse_date_range,
                                     in_recorded_range, KINDS)
    first, last = parse_date_range(start, end)
    if kind and kind not in KINDS and kind != "unspecified":
        raise ValueError("InvalidMemoryKind")
    if query is not None and (not isinstance(query, str) or len(query) > 2000):
        raise ValueError("InvalidMemoryQuery")
    con = connect_readonly(MEMENTO_DB)
    try:
        con.execute("BEGIN")
        total = con.execute("SELECT COUNT(*) FROM entries").fetchone()[0]
        rows = [dict(row) for row in con.execute(
            "SELECT * FROM entries ORDER BY created_at DESC, id LIMIT 10000")]
        scoped = [row for row in rows if in_recorded_range(row, first, last)]
        projected = project_entries(con, scoped)
        if kind:
            projected = [row for row in projected if row["presentation"]["kind"] == kind]
        selected = projected
        if query:
            from memory_index import Index
            by_id = {row["id"]: row for row in projected}
            ranked = Index(entries=projected, management=True).search(query, limit=limit)
            selected = [dict(by_id[hit["id"]], score=hit.get("score"),
                             matched_terms=hit.get("matched_terms", [])) for hit in ranked]
        else:
            selected = selected[:limit]
        return {"entries": selected, "total": total, "filtered_candidates": len(projected),
                "candidate_limit": 10000, "truncated": total > len(rows),
                "time_basis": "recorded_at", "view": "management", "read_only": True}
    finally:
        con.close()


def memory_overview():
    # 过滤掉 snapshot：它们每轮都写一条、内容全是同一句话，341 条把真正
    # 有价值的记忆操作淹没了。只在实在没有其它记录时才退回显示它们。
    snapshot_count = 0
    # 真正的记忆条目——之前页面只查 audit（流水），entries 一条都没查过，
    # 所以永远显示"还没有写进长期记忆"。
    try:
        audit = memento_rows(
            "SELECT seq, ts, action, track, scope, text, outcome FROM audit "
            "WHERE action <> 'snapshot' ORDER BY seq DESC LIMIT 60", strict=True)
        if not audit:
            rows = memento_rows("SELECT COUNT(*) AS n FROM audit WHERE action = 'snapshot'", strict=True)
            snapshot_count = rows[0]["n"]
            audit = memento_rows(
                "SELECT seq, ts, action, track, scope, text, outcome FROM audit "
                "ORDER BY seq DESC LIMIT 5", strict=True)
        props = memento_rows(
            "SELECT id, kind, track, scope, text, status, created_at FROM proposals "
            "ORDER BY created_at DESC LIMIT 30", strict=True)
        record_view = memory_records(limit=200)
        entries = record_view["entries"]
        totals = {key: memento_rows("SELECT COUNT(*) AS n FROM " + table, strict=True)[0]["n"]
                  for key, table in (("active", "entries"), ("audit", "audit"), ("proposals", "proposals"))}
        availability = {"status": "available", "counts_complete": True,
                        "listed_entries": len(entries), "entry_limit": 200,
                        "entries_complete": len(entries) == totals["active"]}
    except (ValueError, IndexError, KeyError, TypeError, OSError, sqlite3.Error):
        audit, props, entries = [], [], []
        totals = {key: None for key in ("active", "audit", "proposals")}
        availability = {"status": "error", "counts_complete": False, "error": "MemoryReadUnavailable"}
    counts = {
        **totals,
        "people": len(list_dir_files("people")),
        "diary": len(list_dir_files("diary")),
        "notes": len(list_dir_files("notes")),
    }
    return {"view": "management", "counts": counts, "audit": audit, "proposals": props,
            "entries": entries, "snapshotOnly": snapshot_count > 0, "availability": availability}


# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
# 表情包的多来源支持（v2：补上 meme-packs 里那两个包）
#
# 之前只扫了 dafeiyu-001 一个包，所以 815 张里只显示 107 张。
# 现在扫三个位置：
#   .dsh/meme-packs/<pack>/memes/<tag>/   插件市场装的包（official-001 / whale-girl-emoji）
#   dsh-meme/memes/dafeiyu-001/memes/<tag>/  大肥鱼那个包
#   大肥鱼/memes/...                        她自己的
#
# ASCII-only 的标识符；注释里用中文没问题，这个文件是 python 不是 ps1。

import os

IMG_EXT = (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp")

DSH_HOME = os.path.join(os.path.expanduser("~"), ".dsh")
PACKS = os.path.join(DSH_HOME, "meme-packs")
DSH_MEME = os.path.join(
    DSH_HOME, "profiles", "desktop", "node_modules", "dsh-meme", "memes",
    "dafeiyu-001", "memes")
LANYA_MEMES = os.path.join(DATA, "memes")

# 这些子目录是临时/回收区，不算分类
SKIP_DIRS = {"rejected", "_scratch", "_stage", "_conv", "_tmpcls", "_archive"}

# pack id -> 中文显示名（manifest 里有 name，但直接读文件更省事，读不到就用 id）
PACK_LABELS = {
    "official-001": "官方表情包",
    "whale-girl-emoji": "鲸鱼娘",
    "dafeiyu-001": "大肥鱼",
}


def _imgs(folder, recursive=False):
    out = []
    if not os.path.isdir(folder):
        return out
    if recursive:
        for root, dirs, files in os.walk(folder):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for f in files:
                if f.lower().endswith(IMG_EXT) and not f.startswith("."):
                    out.append(os.path.relpath(os.path.join(root, f), folder))
    else:
        for f in os.listdir(folder):
            p = os.path.join(folder, f)
            if os.path.isfile(p) and f.lower().endswith(IMG_EXT) and not f.startswith("."):
                out.append(f)
    return sorted(out)


def _pack_label(pack_id):
    label = PACK_LABELS.get(pack_id)
    if label:
        return label
    try:
        import json
        with open(os.path.join(PACKS, pack_id, "manifest.json"), "r", encoding="utf-8") as fh:
            return json.load(fh).get("name") or pack_id
    except Exception:
        return pack_id


def sources():
    """(key, 显示名, 根目录, 是否按标签分目录)"""
    out = []

    # 1. meme-packs 下的每个包
    if os.path.isdir(PACKS):
        for pid in sorted(os.listdir(PACKS)):
            memes_dir = os.path.join(PACKS, pid, "memes")
            if os.path.isdir(memes_dir) and _imgs_count(memes_dir) > 0:
                out.append((pid, _pack_label(pid), memes_dir, True))

    # 2. 大肥鱼那个包（在插件目录下，不在 meme-packs）
    if os.path.isdir(DSH_MEME):
        out.append(("plugin", "大肥鱼", DSH_MEME, True))

    # 3. 她自己的
    out.append(("stolen", "收回来的", os.path.join(LANYA_MEMES, "stolen"), True))
    out.append(("mine", "自己做的", LANYA_MEMES, False))
    out.append(("firefly", "firefly 那批", os.path.join(LANYA_MEMES, "firefly-2026-10-16"), False))
    return out


def _imgs_count(folder):
    n = 0
    for root, dirs, files in os.walk(folder):
        for f in files:
            if f.lower().endswith(IMG_EXT) and not f.startswith("."):
                n += 1
    return n


def meme_groups():
    groups = []
    for key, label, root, tagged in sources():
        if not os.path.isdir(root):
            continue
        if tagged:
            for tag in sorted(os.listdir(root)):
                d = os.path.join(root, tag)
                if not os.path.isdir(d) or tag in SKIP_DIRS:
                    continue
                files = _imgs(d)
                if files:
                    groups.append({"source": key, "name": label, "tag": tag,
                                   "count": len(files), "files": files})
        else:
            files = _imgs(root)
            if files:
                groups.append({"source": key, "name": label, "tag": label,
                               "count": len(files), "files": files})
    return groups


_ACT_LABEL = {
    "groupwatch": ("\u81ea\u5df1\u6c34\u7fa4", "\u76ef\u7740\u7c89\u4e1d\u7fa4\uff0c\u89c9\u5f97\u8be5\u8bf4\u8bdd\u5c31\u63d2\u4e00\u53e5"),
    "lifeloop": ("\u81ea\u5df1\u8fc7\u65e5\u5b50", "\u81ea\u5df1\u5b89\u6392\u6d3b\u52a8\uff0c\u662f\u5426\u6267\u884c\u7531\u5f53\u524d\u8c03\u5ea6\u6a21\u5f0f\u51b3\u5b9a"),
    "mind": ("\u81ea\u4e3b\u6d3b\u52a8", "\u4e3b agent \u6839\u636e\u89c2\u5bdf\u51b3\u5b9a\u662f\u5426\u884c\u52a8"),
    "voicedaemon": ("\u53d1\u8bed\u97f3", "\u628a\u8981\u8bf4\u7684\u8bdd\u5408\u6210\u8bed\u97f3\u53d1\u51fa\u53bb"),
    "tts": ("\u8bed\u97f3\u5f15\u64ce", "\u672c\u5730\u5408\u6210\u58f0\u97f3"),
    "browserd": ("\u4e0a\u7f51\u901b", "\u7528\u6d4f\u89c8\u5668\u770b\u7f51\u9875\u3001\u8bfb\u6587\u7ae0"),
    "works": ("\u521b\u4f5c", "\u5199\u968f\u7b14\u3001\u753b\u4e1c\u897f\u3001\u505a\u5c0f\u9875\u9762"),
    "napcat": ("\u63a5 QQ", "QQ \u90a3\u4e00\u5c42\uff0c\u6ca1\u5b83\u8fde\u4e0d\u4e0a"),
    "headless": ("\u5e72\u6d3b", "\u4e34\u65f6\u7b97\u4e1c\u897f\u7528"),
}


def activity_suggestions(components, acts):
    """已装但还没列进活动的部件，给个建议。"""
    have = set((a.get("bound") or "") for a in acts)
    out = []
    for c in components:
        tag = c.get("tag") or ""
        if tag in have or tag not in _ACT_LABEL:
            continue
        name, desc = _ACT_LABEL[tag]
        out.append({"tag": tag, "name": name, "desc": desc,
                    "running": int(c.get("count") or 0) > 0})
    return out

def _onebot_token():
    """Compatibility helper; credentials always belong to the selected backend."""
    return _qq_connection().token


def _qq_connection():
    return qq_backend.resolve(project=project_conf.load(reload=True))


def _onebot_call(action, payload=None, connection=None):
    current = _qq_connection()
    if connection is not None and current.fingerprint != connection.fingerprint:
        raise qq_backend.BackendError('Selected backend changed; the earlier operation was refused')
    return qq_backend.call(action, payload, connection=connection or current)


def _qq_profile_account(value):
    if not isinstance(value, (str, int)) or isinstance(value, bool) or not re.fullmatch(r'[1-9][0-9]{0,19}', str(value)):
        raise qq_backend.BackendError('Configure a trusted QQ account before editing its profile')
    return str(value)


def _qq_profile_expected():
    value, _ = qq_backend._read(Path(CONFIG))
    return _qq_profile_account(value.get('botQQ'))


def _qq_profile_paths(connection, account):
    # Local accepted-value caches must not carry another provider/account's
    # signature or avatar across a switch. Existing unbound files stay intact.
    from panel_autonomy import _ordinary
    account = _qq_profile_account(account)
    key = connection.provider + '-' + hashlib.sha256(account.encode()).hexdigest()
    folder = _ordinary(Path(NAPCAT) / 'qq-profile-cache')
    return _ordinary(folder / (key + '.json')), _ordinary(folder / (key + '.png'))


def _write_qq_profile_cache(file, raw):
    import uuid
    from panel_autonomy import _ordinary
    file = _ordinary(file); file.parent.mkdir(parents=True, exist_ok=True)
    candidate = _ordinary(file.with_name('.' + file.name + '-' + uuid.uuid4().hex))
    with candidate.open('xb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    os.replace(candidate, file)


def _extra_tags():
    try:
        with open(MEME_TAGS, "r", encoding="utf-8") as fh:
            value = json.load(fh)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _meme_key(source, tag, name):
    identity = json.dumps([source, tag, name], ensure_ascii=False, separators=(",", ":"))
    return "item:v1:" + hashlib.sha256(identity.encode("utf-8")).hexdigest()


def meme_behavior():
    unified = decision_mode() != "legacy"
    return {"mode": "unified" if unified else "legacy",
            "collection": "group-history-quarantine" if unified else "group-history",
            "fast_send": "indexed-tags-current-ticket" if unified else None,
            "managed_by": "main_agent" if unified else "independent_worker",
            "batch_max": 20 if unified else None,
            "independent_classification": not unified}


def meme_groups_with_tags():
    """Display tags retain each image's exact physical source and directory."""
    base = meme_groups()
    extra = _extra_tags()
    by_legacy_key = {}
    for group in base:
        group["items"] = []
        for name in group["files"]:
            item = {"key": _meme_key(group["source"], group["tag"], name),
                    "source": group["source"], "tag": group["tag"], "file": name}
            group["items"].append(item)
            for key in (name, group["tag"] + "/" + name):
                by_legacy_key.setdefault(key, set()).add(item["key"])
    if not extra:
        return base

    merged = {}
    for group in base:
        for item in group["items"]:
            keys = (item["file"], item["tag"] + "/" + item["file"])
            # An exact key, including an empty list, overrides legacy aliases.
            tags = extra.get(item["key"])
            if item["key"] not in extra:
                tags = []
                for key in keys:
                    old = extra.get(key)
                    if by_legacy_key.get(key) == {item["key"]} and isinstance(old, list):
                        tags.extend(old)
            labels = {item["tag"]}
            if isinstance(tags, list):
                labels.update(tag for tag in tags if isinstance(tag, str) and tag.strip())
            for label in sorted(labels):
                row = merged.setdefault(label, {"source": "merged", "name": label, "tag": label,
                    "count": 0, "files": [], "refs": {}, "sources": [], "items": []})
                if item["key"] not in {present["key"] for present in row["items"]}:
                    row["items"].append(dict(item))
                if item["source"] not in row["sources"]:
                    row["sources"].append(item["source"])
    out = []
    for row in merged.values():
        row["items"].sort(key=lambda item: (item["file"], item["source"], item["tag"]))
        row["files"] = sorted({item["file"] for item in row["items"]})
        for name in row["files"]:
            matches = [item for item in row["items"] if item["file"] == name]
            if len(matches) == 1:
                row["refs"][name] = matches[0]["source"]
        row["count"] = len(row["items"])
        out.append(row)
    # 常用情绪排前面，别的按字数
    order = ["happy","sad","angry","speechless","cute","shy","surprise",
             "confused","refuse","pray","cheer","thanks","sleepy","lazy",
             "hungry","work","money","scared","cool","other"]
    def k(r):
        try:
            return (0, order.index(r["tag"]))
        except ValueError:
            return (1, r["tag"])
    out.sort(key=k)
    return out


def meme_path(source, tag, name):
    """Resolve a meme to a real file path, or None. Used by both the image
    endpoint and delete - one resolver means they cannot disagree."""
    if not source or not name:
        return None
    base = os.path.basename(str(name))
    if (base != str(name) or base.startswith(".") or "/" in base or "\\" in base or ":" in base
            or not base.lower().endswith(IMG_EXT)):
        return None
    if source == "merged":
        # Old clients may use a display group; ambiguity never selects a file.
        matches = [path for key, _label, _root, _tagged in sources() if key != "merged"
                   if (path := meme_path(key, tag, base)) is not None]
        return matches[0] if len(matches) == 1 else None

    matches = [s for s in sources() if s[0] == source]
    if len(matches) != 1:
        return None
    _key, _label, root, tagged = matches[0]
    if tagged:
        tagbase = os.path.basename(str(tag or ""))
        if (not tagbase or tagbase != str(tag or "") or tagbase.startswith(".")
                or tagbase in SKIP_DIRS or "/" in tagbase or "\\" in tagbase or ":" in tagbase):
            return None
        full = os.path.join(root, tagbase, base)
    else:
        full = os.path.join(root, base)
    try:
        real_root = os.path.normcase(os.path.realpath(root))
        if os.path.commonpath([real_root, os.path.normcase(os.path.realpath(full))]) != real_root:
            return None
    except (OSError, ValueError):
        return None
    return full if os.path.isfile(full) else None


# -*- coding: utf-8 -*-
"""定时任务：提醒清单 + 系统计划任务，都在页面上看得到。"""
import io
import json
import os
import subprocess

LANYA_DIR_ = DATA
REMINDERS_ = os.path.join(LANYA_DIR_, "reminders.json")

# 插件调度器已经接管的那些，在页面上标出来，免得用户以为重复的也需要留
COVERED_BY_PLUGIN = {
    "DSH-Reminders": "插件每 30 秒查提醒",
    "DSH-Lanya-Chats": "插件每 10 分钟导记录",
    "DSH-Lanya-Steal": "插件定期提交已有图片审阅机会",
    "DSH-Lanya-Greet": "插件定期提交社交机会",
    "NapCat-DSH-Bridge": "插件每 10 分钟查 QQ",
}
_RETIRED_TASK_OWNERS = {
    "DSH-Lanya-Life": "main_agent", "DSH-Lanya-Voice": "main_agent",
    "DSH-Lanya-Mind": "main_agent", "DSH-Lanya-Supervisor": "plugin_supervisor",
    "DSH-Lanya-Works": "panel_service_supervisor",
    "DSH-Dafeiyu-Life": "main_agent", "DSH-Dafeiyu-Voice": "main_agent",
    "DSH-Dafeiyu-Mind": "main_agent", "DSH-Dafeiyu-Supervisor": "plugin_supervisor",
    "DSH-Dafeiyu-Works": "panel_service_supervisor",
}


def _scheduled_task_metadata(name, current_state, enabled_state, mode):
    state = {"disabled": "disabled", "已禁用": "disabled", "running": "running",
             "正在运行": "running", "ready": "ready", "就绪": "ready"}.get(current_state.casefold(), "unknown")
    enabled = {"enabled": True, "已启用": True, "disabled": False, "已禁用": False}.get(enabled_state.casefold())
    owner = _RETIRED_TASK_OWNERS.get(name) if mode == "unified" else None
    return {"mode": mode, "task_state": state, "enabled": enabled,
            "retired": owner is not None, "managed_by": owner,
            "inactive_verified": state == "disabled" and enabled is False}


def reminders_snapshot():
    """她自己的提醒清单（文本调用写进去的那种）。"""
    try:
        with io.open(REMINDERS_, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        return []
    if isinstance(data, dict):
        data = [data]
    out = []
    for i, r in enumerate(data if isinstance(data, list) else []):
        if not isinstance(r, dict):
            continue
        out.append({
            "i": i,
            "text": r.get("text", ""),
            "at": r.get("at", ""),
            "daily": r.get("daily", ""),
            "target": r.get("target", ""),
            "mention": r.get("mention", ""),
            "image": r.get("image", ""),
        })
    return out


def scheduled_tasks():
    """Windows 计划任务里和大肥鱼有关的那些。"""
    try:
        p = subprocess.run(
            ["schtasks.exe", "/query", "/fo", "CSV", "/v"],
            capture_output=True, timeout=40,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        text = decode_task_output(p.stdout)
    except Exception:
        return []
    # 中文 Windows 下 schtasks 的表头是中文，DictReader 靠列名取不到，
    # 所以按位置取。CSV 顺序：TaskName, Next Run Time, Status, Last Run Time,
    # Last Result, ... Task To Run 在后面。
    import csv as _csv
    rows = []
    try:
        rows = list(_csv.reader(io.StringIO(text)))
    except Exception:
        return []
    if len(rows) < 2:
        return []
    try:
        mode = decision_mode()
    except Exception:
        mode = "unavailable"
    by_name = {}
    out = []
    for r in rows[1:]:
        if not r:
            continue
        # 列顺序（中文 Windows /fo CSV /v）:
        #   0 主机名  1 任务名  2 下次运行  3 模式  4 登录状态
        #   5 上次运行  6 上次结果  7 创建者  8 要运行的任务  11 计划任务状态
        # 之前按第 0 列取名字，拿到的是主机名，所以一个都匹配不上。
        name = (r[1] if len(r) > 1 else "").strip()
        if name.startswith("\\"):
            name = name[1:]
        if not name:
            continue
        if not (name.startswith("DSH-") or name.startswith("NapCat")):
            continue
        st = (r[3] if len(r) > 3 else "").strip()
        enabled = (r[11] if len(r) > 11 else "").strip()
        metadata = _scheduled_task_metadata(name, st, enabled, mode)
        if name in by_name:
            previous = by_name[name]
            if any(previous[key] != metadata[key] for key in ("task_state", "enabled")):
                previous.update(task_state="unknown", enabled=None, inactive_verified=False,
                                status="状态变化中")
            continue
        row = {
            "name": name,
            "next": (r[2] if len(r) > 2 else "").strip(),
            "status": st,
            "last": (r[5] if len(r) > 5 else "").strip(),
            "result": (r[6] if len(r) > 6 else "").strip(),
            "action": (r[8] if len(r) > 8 else "").strip()[:120],
            "plugin": COVERED_BY_PLUGIN.get(name, ""),
            **metadata,
        }
        by_name[name] = row
        out.append(row)
    out.sort(key=lambda x: x["name"])
    return out


class Handler(SimpleHTTPRequestHandler):
    server_version = "LanyaPanel/1.0"

    def __init__(self, *a, **kw):
        super().__init__(*a, directory=ROOT, **kw)

    def log_message(self, fmt, *args):
        pass   # 静默，别刷控制台

    def end_headers(self):
        # 页面和样式绝不能被缓存。
        # 之前改完代码用户刷新还是旧页面——DSH 内置视图的缓存很难清，
        # 与其让他到处找 "清缓存"，不如直接告诉浏览器别存。
        p = urlparse(self.path).path.lower()
        if p.endswith(".html") or p.endswith(".css") or p.endswith(".js"):
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
        super().end_headers()

    # ---- helpers -------------------------------------------------------
    def _cors(self):
        # 页面可能来自 19388（作品站，计划任务常驻），接口在这里（19389）。
        # 跨端口就必须自己给 CORS 头，否则浏览器连 OPTIONS 预检都过不去。
        self.send_header("access-control-allow-origin", "*")
        self.send_header("access-control-allow-methods", "GET, POST, OPTIONS")
        self.send_header("access-control-allow-headers", "content-type")
        self.send_header("access-control-max-age", "86400")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.send_header("content-length", "0")
        self.end_headers()

    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-length", str(len(body)))
        self.send_header("cache-control", "no-store")
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def _read(self):
        try:
            n = int(self.headers.get("content-length") or 0)
            raw = self.rfile.read(n) if n > 0 else b""
            return json.loads(raw.decode("utf-8")) if raw else {}
        except Exception:
            return {}

    def _android_error(self, error):
        from android_panel import PanelAndroidError
        if isinstance(error, PanelAndroidError):
            return self._json(error.http_status, {"ok": False, "status": "error",
                "code": error.code, "error": str(error), "shot_id": ""})
        return self._json(503, {"ok": False, "status": "error", "code": "adapter_error",
            "error": type(error).__name__, "shot_id": ""})

    def _android_post(self):
        # Android controls accept the local panel/works origins, never arbitrary
        # websites using the older panel API's permissive CORS policy.
        from android_panel import AndroidPanel, PanelAndroidError
        origin = self.headers.get("Origin")
        if origin:
            parsed = urlparse(origin)
            ports = {int(project_conf.get("panelPort", 19389)),
                     int(project_conf.get("panelStaticPort", 19388)), self.server.server_port}
            if (parsed.scheme != "http" or parsed.hostname not in ("127.0.0.1", "localhost", "::1")
                    or parsed.port not in ports or parsed.username or parsed.password
                    or parsed.path or parsed.query or parsed.fragment):
                raise PanelAndroidError("origin", "Android control requires a local panel origin", 403)
        try:
            size = int(self.headers.get("content-length") or 0)
            if not 0 < size <= 16 * 1024:
                raise ValueError()
            body = json.loads(self.rfile.read(size).decode("utf-8"))
        except (ValueError, UnicodeError):
            raise PanelAndroidError("bad_job", "Invalid Android JSON body", 400) from None
        return self._json(202, AndroidPanel().submit(body))

    def _settings_body(self):
        # These new controls accept local panel origins only, independent of
        # the older generic routes' permissive CORS compatibility behavior.
        from panel_autonomy import SettingsError
        origin = self.headers.get("Origin")
        if origin:
            parsed = urlparse(origin)
            ports = {int(project_conf.get("panelPort", 19389)), int(project_conf.get("panelStaticPort", 19388))}
            if hasattr(self, "server"):
                ports.add(self.server.server_port)
            if (parsed.scheme != "http" or parsed.hostname not in ("127.0.0.1", "localhost", "::1") or
                    parsed.port not in ports or parsed.username or parsed.password or parsed.path or parsed.query or parsed.fragment):
                raise SettingsError("origin", "Settings require a local panel origin", 403)
        def unique(pairs):
            out = {}
            for key, value in pairs:
                if key in out:
                    raise ValueError()
                out[key] = value
            return out
        try:
            size = int(self.headers.get("content-length", "0"))
            if not 0 < size <= 16 * 1024:
                raise ValueError()
            def constant(_):
                raise ValueError()
            body = json.loads(self.rfile.read(size).decode("utf-8"), object_pairs_hook=unique, parse_constant=constant)
            if type(body) is not dict:
                raise ValueError()
            return body
        except (ValueError, UnicodeError):
            raise SettingsError("invalid_json", "Expected a bounded JSON object", 400) from None

    # ---- routes --------------------------------------------------------
    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/activity/journal":
            # This private local reader does not inherit generic wildcard CORS.
            origin = self.headers.get("Origin")
            code, selected, limit = 200, None, 90
            try:
                import ipaddress
                if not ipaddress.ip_address(self.client_address[0]).is_loopback:
                    raise PermissionError()
                ports = {int(project_conf.get("panelPort", 19389)), int(project_conf.get("panelStaticPort", 19388)), self.server.server_port}
                host = urlparse("http://" + self.headers.get("Host", ""))
                if host.hostname not in ("127.0.0.1", "localhost", "::1") or host.port not in ports or host.username or host.password:
                    raise PermissionError()
                if origin:
                    parsed = urlparse(origin)
                    if (parsed.scheme != "http" or parsed.hostname not in ("127.0.0.1", "localhost", "::1") or
                            parsed.port not in ports or parsed.username or parsed.password or parsed.path or parsed.query or parsed.fragment):
                        raise PermissionError()
                query = parse_qs(urlparse(self.path).query, keep_blank_values=True)
                if set(query) - {"day", "limit"} or any(len(values) != 1 for values in query.values()):
                    raise ValueError()
                selected = query.get("day", [None])[0]
                if selected is not None and re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", selected) is None:
                    raise ValueError()
                limit = int(query.get("limit", ["90"])[0])
                if not 1 <= limit <= 90:
                    raise ValueError()
                result = panel_activity_journal(selected, limit)
            except PermissionError:
                code, origin = 403, None
                result = {"schema": "activity-journal/v1", "status": "error", "read_only": True, "private": True, "days": [], "selected": None}
            except (ValueError, TypeError):
                code = 400
                result = {"schema": "activity-journal/v1", "status": "error", "read_only": True, "private": True, "days": [], "selected": None}
            body = json.dumps(result, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("content-type", "application/json; charset=utf-8")
            self.send_header("content-length", str(len(body)))
            self.send_header("cache-control", "no-store")
            self.send_header("x-content-type-options", "nosniff")
            self.send_header("vary", "Origin")
            if origin:
                self.send_header("access-control-allow-origin", origin)
            self.end_headers()
            self.wfile.write(body)
            return
        if path == "/api/service-health":
            port = self.server.server_port
            role = "works" if port == project_conf.get("panelStaticPort", 19388) else "api" if port == project_conf.get("panelPort", 19389) else "unknown"
            return self._json(200, {"ok": True, "service": "lanya-panel", "version": 1,
                "pid": os.getpid(), "port": port, "role": role, "script_sha256": _PANEL_SCRIPT_SHA256})
        if path == "/api/autonomy":
            return self._json(200, {"ok": True, "autonomy": autonomy_snapshot()})
        if path == "/api/autonomy/settings":
            settings = autonomy_settings_snapshot()
            return self._json(200, {"ok": settings["availability"] == "available", "settings": settings})
        if path == "/api/state":
            return self._json(200, panel_state_snapshot())
        if path == "/api/voice-status":
            return self._json(200, {"ok": True, "voice": voice_status_snapshot()})
        if path in ("/api/android/status", "/api/android/shot"):
            try:
                from android_panel import AndroidPanel, PanelAndroidError
                query = parse_qs(urlparse(self.path).query, keep_blank_values=True)
                if any(len(values) != 1 for values in query.values()):
                    raise PanelAndroidError("bad_query", "Android query fields must be unique", 400)
                adapter = AndroidPanel()
                serial = query.get("serial", [None])[0]
                if path.endswith("/status"):
                    return self._json(200, adapter.status(serial))
                raw = adapter.image(serial, query.get("shot_id", [None])[0])
                self.send_response(200)
                self.send_header("content-type", "image/png")
                self.send_header("content-length", str(len(raw)))
                self.send_header("cache-control", "no-store, no-cache, must-revalidate, max-age=0")
                self.send_header("pragma", "no-cache")
                self.send_header("expires", "0")
                self.send_header("x-content-type-options", "nosniff")
                self.end_headers()
                self.wfile.write(raw)
                return
            except Exception as error:
                return self._android_error(error)
        if path == "/api/memory/owners":
            try:
                return self._json(200, {"ok": True, "view": "management", "owners": memory_owner_choices()})
            except Exception as error:
                return self._json(200, {"ok": False, "owners": [], "error": str(error)[:200]})
        if path == "/api/memory/corpus":
            # 三个来源各多少条：数据库 / 日记 / 判重表（刷过哪些视频）
            try:
                import memory_plastic as _mp
                cp = _mp.Corpus()
                st = cp.stats()
                groups = _mp.cluster(cp.db)
                mergeable = sum(1 for g in groups if _mp.merge_group(g))
                return self._json(200, {
                    "ok": True, "stats": st,
                    "view": "management",
                    "mergeable": mergeable,
                    "dbAfterMerge": len(groups),
                    "thresholds": {"merge": _mp.COMPRESS_OVER,
                                   "target": _mp.COMPRESS_TO},
                })
            except Exception as e:
                return self._json(200, {"ok": False, "error": str(e)[:200]})

        if path == "/api/memory/diary":
            q = parse_qs(urlparse(self.path).query)
            day = (q.get("day") or [None])[0]
            if day is not None and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
                return self._json(400, {"ok": False, "error": "InvalidDiaryDate"})
            view = panel_narrative_diary(day)
            return self._json(200 if view["status"] != "error" else 503,
                              dict(ok=view["status"] != "error", diary=view))

        if path == "/api/memory/search":
            # 关键词 / 相似度检索（BM25 + 中文 bigram），不是子串过滤。
            q = parse_qs(urlparse(self.path).query)
            kw = (q.get("q") or [""])[0].strip()
            try:
                lim = int((q.get("limit") or ["8"])[0])
            except Exception:
                lim = 8
            lim = max(1, min(50, lim))
            try:
                view = memory_records(query=kw, limit=lim,
                    start=(q.get("start") or [None])[0],
                    end=(q.get("end") or [None])[0],
                    kind=(q.get("kind") or [None])[0])
                return self._json(200, {"ok": True, "view": "management", "q": kw,
                                        **{key: val for key, val in view.items() if key != "entries"},
                                        "hits": view["entries"]})
            except Exception as e:
                return self._json(200, {"ok": False, "hits": [],
                                        "error": "MemorySearchUnavailable"})

        if path == "/api/memory/graph":
            try:
                import memory_index as _mi
                g = _mi.Index.management().graph()
                return self._json(200, dict(ok=True, view="management", **g))
            except Exception as e:
                return self._json(200, {"ok": False, "nodes": [], "edges": [],
                                        "error": str(e)[:200]})

        if path == "/api/bili/verify":
            # Ask Bilibili whether a comment we recorded is actually public yet.
            try:
                import subprocess as _spv
                q = parse_qs(urlparse(self.path).query, keep_blank_values=True)
                bv = (q.get("bv") or [""])[0].strip()
                txt = (q.get("text") or [""])[0]
                rpid = (q.get("rpid") or [""])[0]
                if (re.fullmatch(r"BV[A-Za-z0-9]{10}", bv) is None or len(q.get("bv", [])) != 1 or
                        len(q.get("rpid", [])) > 1 or ("rpid" in q and re.fullmatch(r"[1-9][0-9]{0,31}", rpid) is None)):
                    return self._json(400, {"ok": False, "error": "Expected a video BV id and optional exact positive decimal rpid"})
                script = os.path.join(NAPCAT, "bili_onerun.py")
                _venv = os.path.join(os.path.expanduser("~"), ".dsh", "bili-duty",
                                     ".venv", "Scripts", "python.exe")
                _py = _venv if os.path.isfile(_venv) else "python"
                _env = dict(os.environ)
                _env["PYTHONUTF8"] = "1"
                _env["PYTHONIOENCODING"] = "utf-8"
                import base64 as _b64v
                _tb = _b64v.b64encode(txt.encode("utf-8")).decode("ascii")
                # text=True 会用系统编码（中文 Windows 是 GBK）解码子进程输出，
                # 而子进程按 PYTHONUTF8 写的是 UTF-8 —— 解出来是空的。
                args = [_py, script, "--verify", bv, "--text-b64", _tb]
                if rpid:
                    args.extend(["--rpid", rpid])
                r = _spv.run(args,
                             capture_output=True, text=True, encoding="utf-8",
                             errors="replace", timeout=120,
                             cwd=NAPCAT, env=_env,
                             creationflags=getattr(_spv, "CREATE_NO_WINDOW", 0))
                out = (r.stdout or "").strip()
                st = out.find("{")
                data = json.loads(out[st:]) if st >= 0 else {"state": "unknown"}
                return self._json(200, {"ok": True, "result": data})
            except Exception:
                return self._json(503, {"ok": False, "code": "comment_verification_unavailable",
                    "error": "Comment verification could not be completed", "result": {"state": "unknown"}})

        if path == "/api/bili/cover":
            # B站的图床要 Referer，浏览器从本地页面直接 img 会被挡（403）。
            # 走服务端代理一次，带上正确的头。
            q = parse_qs(urlparse(self.path).query)
            bv = (q.get("bv") or [""])[0].strip()
            if not bv:
                return self._json(400, {"ok": False, "error": "missing bv"})
            try:
                import urllib.request as _urv
                urls = bili_cover_urls([bv])
                pic = urls.get(bv) or ""
                if not pic:
                    return self._json(404, {"ok": False, "error": "no cover"})
                if pic.startswith("//"):
                    pic = "https:" + pic
                req = _urv.Request(pic, headers={
                    "user-agent": "Mozilla/5.0",
                    "referer": "https://www.bilibili.com/"})
                with _urv.urlopen(req, timeout=20) as rv:
                    data = rv.read()
                self.send_response(200)
                self.send_header("content-type", "image/jpeg")
                self.send_header("content-length", str(len(data)))
                self.send_header("cache-control", "max-age=3600")
                self.end_headers()
                self.wfile.write(data)
                return
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)[:200]})

        if path == "/api/persona":
            try:
                with open(PERSONA, "r", encoding="utf-8") as fh:
                    return self._json(200, {"ok": True, "text": fh.read()})
            except Exception as e:
                return self._json(200, {"ok": False, "text": "", "error": str(e)})
        if path == "/api/schedule":
            try:
                mode = decision_mode()
            except Exception:
                mode = "unavailable"
            return self._json(200, {
                "ok": True,
                "mode": mode,
                "reminders": reminders_snapshot(),
                "tasks": scheduled_tasks(),
            })

        if path == "/api/memory":
            return self._json(200, {"ok": True, "memory": memory_overview()})

        if path == "/api/bili/login/credential":
            # 凭证在就算登录过——bili-qr.json 只是"这一轮扫码"的临时状态，
            # 用户扫完以后它会一直停在 waiting，不能拿它判断登没登录。
            cc = _bili_cred()
            ok = bool(cc.get("sessdata")) and bool(cc.get("bili_jct"))
            uid = str(cc.get("dedeuserid") or "")
            return self._json(200, {"ok": True, "loggedIn": ok, "uid": uid})

        if path == "/api/bili/login/status":
            qr = os.path.join(NAPCAT, "bili-qr.png")
            st = os.path.join(NAPCAT, "bili-qr.json")
            info = {}
            if os.path.isfile(st):
                try:
                    with open(st, "r", encoding="utf-8") as fh2:
                        info = json.load(fh2)
                except Exception:
                    info = {}
            return self._json(200, {"ok": True,
                                    "hasImage": os.path.isfile(qr),
                                    "mtime": int(os.path.getmtime(qr)) if os.path.isfile(qr) else 0,
                                    "state": info})

        if path == "/api/qq/backend":
            try:
                return self._json(200, {"ok": True, "backend": qq_backend_selection.snapshot()})
            except (qq_backend.BackendError, qq_backend_selection.SelectionError) as error:
                return self._json(409, {"ok": False, "error": str(error)})
            except Exception:
                return self._json(503, {"ok": False, "error": "Backend settings are unavailable"})

        if path == "/api/qq/backend/health":
            try:
                expected = {}
                if os.path.isfile(CONFIG):
                    expected, _ = qq_backend._read(Path(CONFIG))
                connection = _qq_connection()
                health = qq_backend.health(connection, expected_account=expected.get("botQQ"))
                health['config_fingerprint'] = connection.fingerprint
                health.pop("account", None)
                return self._json(200, {"ok": True, "health": health})
            except qq_backend.BackendError as error:
                return self._json(200, {"ok": False, "error": str(error), "health": {"online": False}})

        if path == "/api/qq/backend/status":
            facts = selected_backend_component(panel_raw_state_metadata().get("qqBackend"))["backend"]
            return self._json(200, {"ok": facts["provider"] is not None, "backend": facts})

        if path == "/api/qq/account-activity":
            try:
                from account_activity import snapshot
                return self._json(200, {"ok": True, "activity": snapshot()})
            except Exception:
                return self._json(503, {"ok": False, "error": "Account activity is unavailable; private records were preserved"})

        if path in ("/api/qq/friends", "/api/qq/groups"):
            key = "friends" if path.endswith("friends") else "groups"
            action = "get_friend_list" if key == "friends" else "get_group_list"
            try:
                connection = _qq_connection()
                result = _onebot_call(action, connection=connection)
                rows = result.get("data")
                if not isinstance(rows, list):
                    raise qq_backend.BackendError("OneBot returned an invalid contact list")
                return self._json(200, {"ok": True, key: rows, "backend": {
                    "provider": connection.provider, "config_fingerprint": connection.fingerprint}})
            except qq_backend.BackendError as error:
                return self._json(200, {"ok": False, "error": str(error)})

        if path in ("/api/qq/profile", "/api/napcat/profile"):
            try:
                connection = _qq_connection()
                info = _onebot_call("get_login_info", connection=connection)
                d = info.get("data")
                if not isinstance(d, dict):
                    raise qq_backend.BackendError('Backend returned an invalid profile')
                prof_file, avatar_file = _qq_profile_paths(connection, d.get('user_id'))
                saved, _ = qq_backend._read(prof_file, optional=True)
                saved = saved or {}; d = dict(d)
                # OneBot 只能给昵称；签名和头像读不回来，用本地记的最后一次值
                d["signature"] = saved.get("signature", "")
                try:
                    from account_activity import history
                    cutoff = prof_file.stat().st_mtime * 1000 if prof_file.exists() else 0
                    latest = next((row for row in history(project_conf.load(reload=True), connection.provider)
                                   if row['kind'] == 'signature' and row['state'] == 'accepted'), None)
                    if latest and latest['at'] > cutoff:
                        d['signature'] = latest['text']
                except Exception:
                    pass  # Keep the separately labeled last manual cache on unavailable history.
                d["hasAvatar"] = avatar_file.is_file()
                d["avatarFile"] = '/qq-avatar.png' if d['hasAvatar'] else ''
                return self._json(200, {"ok": True, "profile": d, "backend": {
                    "provider": connection.provider, "config_fingerprint": connection.fingerprint}})
            except Exception as e:
                return self._json(200, {"ok": False, "error": str(e) if isinstance(e, qq_backend.BackendError) else 'Profile could not be read'})

        if path in ("/api/qq/connection", "/api/napcat"):
            key = "napcat" if path == "/api/napcat" else "backend"
            try:
                out = _qq_connection().public()
                out.update(found=True, tokenMasked="\u5df2\u8bbe\u7f6e" if out["token_configured"] else "\uff08\u7a7a\uff09")
                return self._json(200, {"ok": True, key: out})
            except qq_backend.BackendError as error:
                return self._json(200, {"ok": False, key: {"found": False, "error": str(error)}})

        if path == "/api/activities":
            settings = autonomy_settings_snapshot()
            return self._json(200, {"ok": settings["availability"] == "available", "data": {
                "managed_by": "main_agent", "retired_controls": True, "activities": [],
                "replacement": "/api/autonomy/settings", "autonomy": settings["runtime"],
                "settings": settings, "recentActivity": panel_main_activity()["recentActivity"]}})

        if path == "/api/live":
            # 她现在在做什么：lifeloop 的日志 + 最后一条分享
            out = {"log": [], "last": "", "lastAt": "", "nextIn": ""}
            out["plans"] = panel_autonomy_plans()
            autonomy = autonomy_snapshot()
            if autonomy["mode"] != "legacy":
                # Old Life logs are not evidence of current main-agent activity.
                out["autonomy"] = autonomy
                out["statusLabel"] = autonomy_label(autonomy)
                out["recentActivity"] = panel_main_activity()["recentActivity"]
                out["budget"] = unified_budget_snapshot(include_daily=False)
                out["settings"] = autonomy_settings_snapshot()
                return self._json(200, {"ok": True, "live": out})
            try:
                lf = tail_file(os.path.join(LANYA_DIR_, "lifeloop.log"), 12)
                out["log"] = [x.strip() for x in (lf or "").splitlines() if x.strip()]
            except Exception:
                pass
            try:
                with open(os.path.join(LANYA_DIR_, "lifeloop.state.json"), "r",
                          encoding="utf-8") as fhs2:
                    st2 = json.load(fhs2)
                out["last"] = st2.get("lastShare", "")
                out["lastAt"] = st2.get("lastAt", "")
            except Exception:
                pass
            out["budget"] = unified_budget_snapshot(include_daily=False)
            out["settings"] = autonomy_settings_snapshot()
            return self._json(200, {"ok": True, "live": out})

        if path == "/api/bili":
            return self._json(200, {"ok": True, "bili": bili_snapshot()})

        if path == "/api/reminders/delete":
            try:
                idx = int(body.get("i"))
            except Exception:
                return self._json(400, {"ok": False, "error": "bad index"})
            try:
                with io.open(REMINDERS_, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                if isinstance(data, dict):
                    data = [data]
                if not isinstance(data, list) or idx < 0 or idx >= len(data):
                    return self._json(404, {"ok": False, "error": "not found"})
                removed = data.pop(idx)
                with io.open(REMINDERS_, "w", encoding="utf-8") as fh:
                    json.dump(data, fh, ensure_ascii=False, indent=2)
                return self._json(200, {"ok": True, "removed": removed})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/bili/duty":
            try:
                with open(BILI_DUTY, "r", encoding="utf-8") as fh:
                    return self._json(200, {"ok": True, "text": fh.read()})
            except Exception as e:
                return self._json(200, {"ok": False, "text": "", "error": str(e)})

        if path == "/api/tools/check":
            q = parse_qs(urlparse(self.path).query)
            key = (q.get("key") or [""])[0]
            latest = check_upstream(key)
            return self._json(200, {"ok": True, "key": key, "latest": latest,
                                    "reachable": latest is not None})

        if path == "/api/tools":
            return self._json(200, {"ok": True, "tools": tools_snapshot()})

        if path in ("/api/budget", "/api/budget/summary"):
            budget = unified_budget_snapshot() if path == "/api/budget" else unified_budget_snapshot(include_daily=False)
            return self._json(200, {"ok": budget.get("availability") in ("available", "not_started"), "budget": budget})

        if path == "/api/memes/config":
            try:
                with open(MEMECFG, "r", encoding="utf-8") as fh:
                    return self._json(200, {"ok": True, "config": json.load(fh), "behavior": meme_behavior()})
            except Exception as e:
                return self._json(200, {"ok": False, "config": {}, "error": str(e)})

        if path == "/api/memes":
            groups = meme_groups_with_tags()
            return self._json(200, {"ok": True,
                                    "tagMap": _extra_tags(),
                                    "total": sum(g["count"] for g in groups),
                                    "groups": groups})

        if path == "/api/files/raw":
            q = parse_qs(urlparse(self.path).query)
            key = (q.get("dir") or [""])[0]
            name = (q.get("name") or [""])[0]
            if key not in FILE_DIRS or not name:
                return self._json(400, {"ok": False, "error": "bad params"})
            # 归档里的 name 是 "子目录/文件"，basename 会把子目录砍掉，
            # 结果永远找不到文件。改成按相对路径拼，并挡掉 ..
            rel = "/".join(p for p in str(name).replace("\\", "/").split("/")
                           if p and p not in (".", ".."))
            full = os.path.join(FILE_DIRS[key], *rel.split("/")) if rel else ""
            if not full or not os.path.isfile(full):
                return self._json(404, {"ok": False, "error": "not found"})
            ext = os.path.splitext(full)[1].lower()
            ctype = {".png": "image/png", ".gif": "image/gif",
                     ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                     ".webp": "image/webp", ".bmp": "image/bmp"}.get(ext, "application/octet-stream")
            try:
                with open(full, "rb") as fh2:
                    data = fh2.read()
                self.send_response(200)
                self.send_header("content-type", ctype)
                self.send_header("content-length", str(len(data)))
                self.send_header("cache-control", "max-age=600")
                self.end_headers()
                self.wfile.write(data)
                return
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/works":
            try:
                from panel_record_files import works_snapshot
                return self._json(200, works_snapshot(FILE_DIRS["made"], excluded=is_panel_artifact))
            except (OSError, ValueError, TypeError, ImportError):
                return self._json(503, {"ok": False, "error": "WorksReadUnavailable", "files": []})

        if path == "/api/files":
            q = parse_qs(urlparse(self.path).query)
            key = (q.get("dir") or [""])[0]
            if key not in FILE_DIRS:
                return self._json(400, {"ok": False, "error": "unknown dir"})
            prev = (q.get("preview") or ["0"])[0] in ("1", "true", "yes")
            try:
                lim = int((q.get("limit") or ["0"])[0])
            except Exception:
                lim = 0
            return self._json(200, {"ok": True, "dir": key,
                                    "files": list_dir_files(key, prev, lim)})

        if path == "/api/files/search":
            q = parse_qs(urlparse(self.path).query)
            key = (q.get("dir") or [""])[0]
            kw = (q.get("q") or [""])[0].strip()
            if key not in FILE_DIRS or not kw:
                return self._json(400, {"ok": False, "error": "bad params"})
            root = FILE_DIRS[key]
            hits = []
            limit = 80
            if os.path.isdir(root):
                for f in sorted(os.listdir(root), reverse=True):
                    p = os.path.join(root, f)
                    if not os.path.isfile(p):
                        continue
                    try:
                        with open(p, "r", encoding="utf-8", errors="replace") as fh:
                            text = fh.read(400000)
                    except Exception:
                        continue
                    idx = text.find(kw)
                    if idx < 0 and kw.lower() not in f.lower():
                        continue
                    if idx < 0:
                        idx = 0
                    start = max(0, idx - 40)
                    snippet = text[start:idx + len(kw) + 80]
                    snippet = " ".join(snippet.split())
                    hits.append({"name": f, "snippet": snippet})
                    if len(hits) >= limit:
                        break
            return self._json(200, {"ok": True, "q": kw, "hits": hits})

        if path == "/api/files/read":
            q = parse_qs(urlparse(self.path).query)
            key = (q.get("dir") or [""])[0]
            name = safe_name((q.get("name") or [""])[0])
            if key not in FILE_DIRS or not name:
                return self._json(400, {"ok": False, "error": "bad params"})
            full = os.path.join(FILE_DIRS[key], name)
            if not os.path.isfile(full):
                return self._json(404, {"ok": False, "error": "not found"})
            try:
                with open(full, "r", encoding="utf-8", errors="replace") as fh:
                    txt = fh.read(200000)
                return self._json(200, {"ok": True, "name": name, "text": txt})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/tunables":
            settings = autonomy_settings_snapshot()
            return self._json(200, {"ok": True, "retired": True, "read_only": True,
                "replacement": "/api/autonomy/settings", "group_observation": settings["group_observation"]})
        if path == "/api/config":
            try:
                with open(CONFIG, "r", encoding="utf-8") as fh:
                    return self._json(200, {"ok": True, "config": json.load(fh)})
            except Exception as e:
                return self._json(200, {"ok": False, "config": {}, "error": str(e)})

        if path.startswith("/archive/"):
            # 归档里的图片/文件：给作品页的「归档」标签看图用
            rel = path[len("/archive/"):]
            from urllib.parse import unquote as _uq
            rel = _uq(rel)
            parts = [p for p in rel.split("/") if p and p not in ("..", ".")]
            if not parts:
                return self._json(400, {"ok": False, "error": "bad path"})
            full = os.path.join(ARCHIVE_ROOT, *parts)
            if os.path.isfile(full):
                ext = os.path.splitext(full)[1].lower()
                ctype = {".png": "image/png", ".gif": "image/gif",
                         ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                         ".webp": "image/webp", ".bmp": "image/bmp"}.get(
                             ext, "application/octet-stream")
                try:
                    with open(full, "rb") as fh:
                        data = fh.read()
                    self.send_response(200)
                    self.send_header("content-type", ctype)
                    self.send_header("content-length", str(len(data)))
                    self.send_header("cache-control", "max-age=600")
                    self.end_headers()
                    self.wfile.write(data)
                    return
                except Exception:
                    pass
            return self._json(404, {"ok": False, "error": "no archive file"})

        if path == "/qq-avatar.png":
            try:
                connection = _qq_connection()
                query = parse_qs(urlparse(self.path).query)
                if query.get('backend_fingerprint', [connection.fingerprint]) != [connection.fingerprint]:
                    raise qq_backend.BackendError('Selected backend changed')
                _, avatar = _qq_profile_paths(connection, _qq_profile_expected())
                if avatar.is_file():
                    from panel_autonomy import _record
                    _, dav = _record(avatar, 5 * 1024 * 1024)
                    self.send_response(200)
                    self.send_header("content-type", "image/png")
                    self.send_header("content-length", str(len(dav)))
                    self.send_header("cache-control", "no-store")
                    self.end_headers()
                    self.wfile.write(dav)
                    return
            except Exception:
                pass
            return self._json(404, {"ok": False, "error": "no avatar"})

        if path == "/bili-qr.png":
            qp = os.path.join(NAPCAT, "bili-qr.png")
            if os.path.isfile(qp):
                try:
                    with open(qp, "rb") as fh3:
                        data = fh3.read()
                    self.send_response(200)
                    self.send_header("content-type", "image/png")
                    self.send_header("content-length", str(len(data)))
                    self.send_header("cache-control", "no-store")
                    self.end_headers()
                    self.wfile.write(data)
                    return
                except Exception:
                    pass
            return self._json(404, {"ok": False, "error": "no qr"})

        if path.startswith("/memes/"):
            parts = [p for p in path.split("/") if p]
            if len(parts) == 4:
                # BaseHTTPRequestHandler 给的是 URL 编码过的路径，中文文件名必须
                # 先解码，否则 os.path.isfile 永远 False——表现就是图全是 404。
                from urllib.parse import unquote as _unq
                src, tg, fn = _unq(parts[1]), _unq(parts[2]), _unq(parts[3])
                full = meme_path(src, tg, fn)
                if full:
                    ext = os.path.splitext(full)[1].lower()
                    ctype = {".png": "image/png", ".gif": "image/gif",
                             ".webp": "image/webp", ".bmp": "image/bmp"}.get(ext, "image/jpeg")
                    with open(full, "rb") as fh:
                        data = fh.read()
                    self.send_response(200)
                    self.send_header("content-type", ctype)
                    self.send_header("content-length", str(len(data)))
                    self.send_header("cache-control", "max-age=300")
                    self.end_headers()
                    self.wfile.write(data)
                    return
            return self._json(404, {"ok": False, "error": "no meme"})

        if path in ("/", ""):
            self.path = "/lanya-panel.html"
        return super().do_GET()

    def do_POST(self):
        path = urlparse(self.path).path
        if path == "/api/qq/backend":
            try:
                from qq_backend_selection import select, SelectionError
                origin = self.headers.get("Origin")
                if origin:
                    parsed = urlparse(origin)
                    ports = {int(project_conf.get("panelPort", 19389)), int(project_conf.get("panelStaticPort", 19388))}
                    if (parsed.scheme != "http" or parsed.hostname not in ("127.0.0.1", "localhost", "::1") or
                            parsed.port not in ports or parsed.username or parsed.password or parsed.path not in ("", "/") or
                            parsed.query or parsed.fragment):
                        raise SelectionError("origin_refused", "Backend selection requires the local console", 403)
                size = int(self.headers.get("content-length", "0"))
                if not 0 < size <= 2048:
                    raise SelectionError("invalid_selection", "Invalid backend selection body", 400)
                body = json.loads(self.rfile.read(size).decode("utf-8"))
                return self._json(200, {"ok": True, "backend": select(body)})
            except (SelectionError, qq_backend.BackendError) as error:
                return self._json(getattr(error, "status", 409), {"ok": False, "error": str(error), "code": getattr(error, "code", "backend_unavailable")})
            except (ValueError, UnicodeError):
                return self._json(400, {"ok": False, "error": "Invalid backend selection body"})
            except Exception:
                return self._json(503, {"ok": False, "error": "Backend selection is unconfirmed; refresh before trying another action"})
        if path == "/api/android/job":
            try:
                return self._android_post()
            except Exception as error:
                return self._android_error(error)
        if path == "/api/autonomy/check":
            try:
                size = int(self.headers.get("content-length", "0"))
                if not 0 <= size <= 1024:
                    raise ValueError()
                raw = self.rfile.read(size)
                body = json.loads(raw.decode("utf-8")) if size else {}
                if not isinstance(body, dict) or body:
                    raise ValueError()
            except (ValueError, UnicodeError):
                return self._json(400, {"ok": False, "error": "Check request takes no owner or event parameters"})
            result = request_autonomy_check()
            return self._json(200 if result["ok"] else 409, result)
        if path in ("/api/activities", "/api/activities/add", "/api/activities/delete", "/api/tunables", "/api/budget/topup"):
            return self._json(410, {"ok": False, "code": "legacy_control_retired",
                "error": "This legacy control does not configure the main agent",
                "replacement": "/api/budget" if path.endswith("topup") else "/api/autonomy/settings"})
        if path in ("/api/autonomy/settings", "/api/budget", "/api/qq/account-activity/settings"):
            try:
                from panel_autonomy import SettingsError, save_settings
                body = self._settings_body()
                if path == "/api/qq/account-activity/settings":
                    from account_activity import save_settings as save_account_activity
                    return self._json(200, {"ok": True, "activity": save_account_activity(body)})
                if path == "/api/autonomy/settings":
                    settings = save_settings(body)
                    settings["runtime"] = autonomy_snapshot()
                    return self._json(200, {"ok": True, "settings": settings})
                if set(body) == {"budget"}:
                    return self._json(410, {"ok": False, "code": "legacy_budget_retired",
                        "error": "Use current budget settings and a fresh revision"})
                if set(body) != {"revision", "settings"} or type(body.get("settings")) is not dict:
                    raise SettingsError("invalid_budget", "Expected settings and a fresh revision", 400)
                from budget_runtime import save_config
                save_config(body["settings"], body["revision"])
                budget = unified_budget_snapshot()
                return self._json(200, {"ok": True, "budget": budget})
            except Exception as error:
                status = getattr(error, "http_status", getattr(error, "status", 503))
                if type(status) is not int or status not in (400, 403, 409, 503):
                    status = 503
                code = getattr(error, "code", "settings_unavailable")
                if not isinstance(code, str) or not re.fullmatch(r"[a-z_]{1,64}", code):
                    code = "settings_unavailable"
                message = "Settings changed; refresh before saving" if status == 409 else "Settings update refused"
                return self._json(status, {"ok": False, "code": code, "error": message})
        if path in ("/api/qq/profile", "/api/napcat/profile"):
            did = []; warn = []
            try:
                size = int(self.headers.get("content-length", "0"))
                if not 0 <= size <= 8 * 1024 * 1024:
                    return self._json(413, {"ok": False, "error": "Profile request exceeds limit"})
            except ValueError:
                return self._json(400, {"ok": False, "error": "Invalid profile request size"})
        body = self._read()

        if path == "/api/memory/consolidate":
            try:
                r = memory_maintenance("consolidate", body)
                return self._json(200, dict(ok=True, **r))
            except ValueError as e:
                return self._json(400, {"ok": False, "error": str(e)[:200]})
            except Exception as e:
                return self._json(200, {"ok": False, "error": str(e)[:200]})

        if path == "/api/memory/trim-seen":
            try:
                import seen_cap as _sc
                r = _sc.trim_seen(dry=False)
                r.pop("ok", None)
                return self._json(200, dict(ok=True, **r))
            except Exception as e:
                return self._json(200, {"ok": False, "error": str(e)[:200]})

        if path == "/api/memory/compress":
            try:
                r = memory_maintenance("compress", body)
                return self._json(200, dict(ok=True, **r))
            except ValueError as e:
                return self._json(400, {"ok": False, "error": str(e)[:200]})
            except Exception as e:
                return self._json(200, {"ok": False, "error": str(e)[:200]})

        if path == "/api/bili/reply/delete":
            # 直接发请求，不起子进程 —— 光 python 启动就要一两秒。
            bv = str(body.get("bv") or "").strip()
            rpid = str(body.get("rpid") or "").strip()
            if not bv or not rpid:
                return self._json(400, {"ok": False, "error": "missing bv or rpid"})
            try:
                okk, note = bili_delete_comment(bv, rpid)
            except Exception as e:
                okk, note = False, str(e)[:150]
            if okk:
                # 顺手把本地那行也去掉，页面才对得上
                try:
                    with open(BILI_SEEN, "r", encoding="utf-8") as fhs:
                        lines = fhs.readlines()
                    keep = []
                    for ln in lines:
                        cells = [x.strip() for x in ln.strip().strip("|").split("|")]
                        if len(cells) >= 2 and cells[0] == bv and cells[1] == rpid:
                            continue
                        keep.append(ln)
                    with open(BILI_SEEN, "w", encoding="utf-8", newline="") as fhs2:
                        fhs2.writelines(keep)
                except Exception:
                    pass
            return self._json(200, {"ok": okk, "note": note,
                                    "error": "" if okk else note})

        if path == "/api/bili/follow":
            uid = str(body.get("uid") or "").strip()
            act = 1 if body.get("act", 1) == 1 else 2
            if not uid:
                return self._json(400, {"ok": False, "error": "missing uid"})
            try:
                okk2, note2 = bili_follow(uid, act)
            except Exception as e:
                okk2, note2 = False, str(e)[:150]
            return self._json(200, {"ok": okk2, "note": note2})

        if path == "/api/bili/onerun":
            try:
                observed = bili_entertainment_review(body)
            except Exception as error:
                return self._json(503, {"ok": False, "queued": False, "delivered": False,
                                        "error_class": type(error).__name__})
            if observed is not None:
                return self._json(200, observed)
            # Really do one round: pick a video, write a comment, post it, record it.
            # Talks to the bili MCP server over JSON-RPC directly, so it does not
            # need a DSH agent with tools loaded.
            try:
                import subprocess as _spo
                script = os.path.join(NAPCAT, "bili_onerun.py")
                if not os.path.isfile(script):
                    return self._json(404, {"ok": False, "error": "bili_onerun.py missing"})
                _venv = os.path.join(os.path.expanduser("~"), ".dsh", "bili-duty",
                                     ".venv", "Scripts", "python.exe")
                _py = _venv if os.path.isfile(_venv) else "python"
                _env = dict(os.environ)
                _env["PYTHONUTF8"] = "1"
                _env["PYTHONIOENCODING"] = "utf-8"
                want_comment = body.get("comment", True) is not False
                want_mention = body.get("mention", False) is True
                args = [_py, script]
                if not want_comment:
                    args.append("--no-comment")
                if want_mention:
                    args.append("--mention")
                p = _spo.Popen(args, stdout=_spo.PIPE, stderr=_spo.PIPE,
                               cwd=NAPCAT, env=_env,
                               creationflags=getattr(_spo, "CREATE_NO_WINDOW", 0))
                out, err = p.communicate(timeout=300)
                txt = (out or b"").decode("utf-8", "replace")
                # 最后一段 JSON 就是结果
                st = txt.find("{")
                data = {}
                if st >= 0:
                    try:
                        data = json.loads(txt[st:])
                    except Exception:
                        data = {}
                if not data:
                    data = {"ok": False,
                            "error": (txt or (err or b"").decode("utf-8", "replace"))[-300:]}
                return self._json(200, data)
            except Exception as e:
                return self._json(200, {"ok": False, "error": str(e)[:300]})

        if path == "/api/bili/seen/delete":
            kind = str(body.get("kind") or "")
            bv = str(body.get("bv") or "").strip()
            if not bv:
                return self._json(400, {"ok": False, "error": "missing bv"})
            try:
                with open(BILI_SEEN, "r", encoding="utf-8") as fhs:
                    lines = fhs.readlines()
                out = []
                removed = 0
                for ln in lines:
                    hit = False
                    if "|" in ln and bv in ln:
                        if kind == "comment":
                            # 评论表：| BV | rpid | ...
                            cells = [c.strip() for c in ln.strip().strip("|").split("|")]
                            if cells and cells[0] == bv and len(cells) >= 2:
                                hit = True
                        elif kind == "video":
                            # 视频表：| 日期 | BV | ...
                            cells = [c.strip() for c in ln.strip().strip("|").split("|")]
                            if len(cells) >= 2 and cells[1] == bv:
                                hit = True
                    if hit:
                        removed += 1
                        continue
                    out.append(ln)
                if not removed:
                    return self._json(404, {"ok": False, "error": "not found"})
                with open(BILI_SEEN, "w", encoding="utf-8", newline="") as fhs2:
                    fhs2.writelines(out)
                return self._json(200, {"ok": True, "removed": removed,
                                        "note": "只删了本地记录，B站上的没动"})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/bili/run":
            try:
                observed = bili_entertainment_review(body)
            except Exception as error:
                return self._json(503, {"ok": False, "queued": False, "delivered": False,
                                        "error_class": type(error).__name__})
            if observed is not None:
                return self._json(200, observed)
            # Spawn a headless agent to actually run one Bilibili duty pass.
            # Nothing happens on its own: seen.md stays empty until asked.
            try:
                import subprocess as _spb
                duty = os.path.join(os.path.expanduser("~"), ".dsh",
                                    "bili-duty", "duty.md")
                if not os.path.isfile(duty):
                    return self._json(200, {"ok": False, "error": "duty.md not found"})
                dsh = DSH_CLI
                if not os.path.isfile(dsh):
                    return self._json(200, {"ok": False, "error": "dsh.cmd not found"})
                with open(duty, "r", encoding="utf-8", errors="replace") as fhd:
                    brief = ("Go do one Bilibili duty pass now. Use your bili tools.\n\n"
                             + fhd.read()[:20000])
                pr = _spb.Popen([dsh, "--profile", "headless", "-"],
                                stdin=_spb.PIPE, stdout=_spb.DEVNULL,
                                stderr=_spb.DEVNULL,
                                creationflags=getattr(_spb, "CREATE_NO_WINDOW", 0))
                try:
                    pr.stdin.write(brief.encode("utf-8"))
                    pr.stdin.close()
                except Exception:
                    pass
                return self._json(200, {"ok": True, "pid": pr.pid})
            except Exception as e:
                return self._json(200, {"ok": False, "error": str(e)[:200]})

        if path == "/api/action":
            if not isinstance(body, dict):
                return self._json(400, {"ok": False, "error": "Invalid component action"})
            target = str(body.get("target") or "")
            # Start only the selected provider. Configuration revision prevents
            # a stale page from launching a newly selected, different runtime.
            if target in ("qq-backend", "napcat-elevated"):
                try:
                    from qq_backend_control import start
                    if target == "qq-backend" and (type(body.get('provider')) is not str or type(body.get('revision')) is not str):
                        raise qq_backend.BackendError("Refresh backend settings before starting")
                    return self._json(200, start(napcat_launcher=start_napcat_elevated,
                        expected_provider=body.get('provider'), expected_revision=body.get('revision')))
                except qq_backend.BackendError as error:
                    return self._json(409, {"ok": False, "error": str(error)})
                except Exception:
                    return self._json(503, {"ok": False, "error": "QQ backend start is unconfirmed; inspect the service before retrying"})
            try:
                result = control_action(body)
                return self._json(200 if result["ok"] else 409, result)
            except Exception as e:
                return self._json(400, {"ok": False, "error": str(e)})

        if path == "/api/persona":
            text = body.get("text") or ""
            if not text.strip():
                return self._json(400, {"ok": False, "error": "empty"})
            try:
                with open(PERSONA, "w", encoding="utf-8") as fh:
                    fh.write(text)
                return self._json(200, {"ok": True, "chars": len(text)})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/memory":
            return self._json(200, {"ok": True, "memory": memory_overview()})

        if path == "/api/bili/duty":
            # 真的写。之前这里放的是读处理器的副本，面板点保存只是把当前内容
            # 读回来再显示一遍，文件一个字都没变。
            want = body.get("text")
            if not isinstance(want, str):
                return self._json(400, {"ok": False, "error": "text must be a string"})
            try:
                import uuid as _uduty
                tmp = BILI_DUTY + "." + _uduty.uuid4().hex[:8] + ".tmp"
                with open(tmp, "w", encoding="utf-8", newline="") as _fd:
                    _fd.write(want)
                for _k in range(6):
                    try:
                        os.replace(tmp, BILI_DUTY)
                        break
                    except OSError:
                        if _k == 5:
                            raise
                        import time as _td
                        _td.sleep(0.08)
                return self._json(200, {"ok": True, "bytes": len(want)})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/bili":
            return self._json(200, {"ok": True, "bili": bili_snapshot()})


        if path == "/api/tools/check":
            q = parse_qs(urlparse(self.path).query)
            key = (q.get("key") or [""])[0]
            latest = check_upstream(key)
            return self._json(200, {"ok": True, "key": key, "latest": latest,
                                    "reachable": latest is not None})

        if path == "/api/memes":
            groups = meme_groups()
            return self._json(200, {"ok": True,
                                    "total": sum(g["count"] for g in groups),
                                    "groups": groups})

        if path == "/api/files":
            q = parse_qs(urlparse(self.path).query)
            key = (q.get("dir") or [""])[0]
            if key not in FILE_DIRS:
                return self._json(400, {"ok": False, "error": "unknown dir"})
            return self._json(200, {"ok": True, "dir": key, "files": list_dir_files(key)})

        if path == "/api/files/read":
            q = parse_qs(urlparse(self.path).query)
            key = (q.get("dir") or [""])[0]
            name = safe_name((q.get("name") or [""])[0])
            if key not in FILE_DIRS or not name:
                return self._json(400, {"ok": False, "error": "bad params"})
            full = os.path.join(FILE_DIRS[key], name)
            if not os.path.isfile(full):
                return self._json(404, {"ok": False, "error": "not found"})
            try:
                with open(full, "r", encoding="utf-8", errors="replace") as fh:
                    txt = fh.read(200000)
                return self._json(200, {"ok": True, "name": name, "text": txt})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/schedule":
            return self._json(200, {
                "ok": True,
                "reminders": reminders_snapshot(),
                "tasks": scheduled_tasks(),
            })

        if path == "/api/memory":
            return self._json(200, {"ok": True, "memory": memory_overview()})

        if path == "/api/bili":
            return self._json(200, {"ok": True, "bili": bili_snapshot()})


        if path == "/api/tools/check":
            q = parse_qs(urlparse(self.path).query)
            key = (q.get("key") or [""])[0]
            latest = check_upstream(key)
            return self._json(200, {"ok": True, "key": key, "latest": latest,
                                    "reachable": latest is not None})

        if path == "/api/tools":
            return self._json(200, {"ok": True, "tools": tools_snapshot()})


        if path == "/api/memes/config":
            cfg = body.get("config")
            if not isinstance(cfg, dict):
                return self._json(400, {"ok": False, "error": "config must be an object"})
            for key in ("stealEnabled", "autoClassify"):
                if key in cfg and type(cfg[key]) is not bool:
                    return self._json(400, {"ok": False, "error": key + " must be boolean"})
            if "maxPerRun" in cfg and (type(cfg["maxPerRun"]) is not int or not 1 <= cfg["maxPerRun"] <= 20):
                return self._json(400, {"ok": False, "error": "maxPerRun must be an integer from 1 to 20"})
            try:
                with open(MEMECFG, "r", encoding="utf-8") as fh:
                    cur = json.load(fh)
            except Exception:
                cur = {}
            if isinstance(cur, dict):
                cur.update(cfg)
                cfg = cur
            try:
                tmp = MEMECFG + ".tmp"
                with open(tmp, "w", encoding="utf-8") as fh:
                    json.dump(cfg, fh, ensure_ascii=False, indent=2)
                os.replace(tmp, MEMECFG)
                return self._json(200, {"ok": True})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/memes/classify":
            if decision_mode() != "legacy":
                try:
                    from meme_observations import observe_existing_memes
                    result = observe_existing_memes(limit=20)
                    return self._json(200, dict(result, ok=True, managed_by="main_agent"))
                except Exception:
                    return self._json(503, {"ok": False, "error": "MemeReviewUnavailable"})
            # An explicitly configured independent worker retains its own path.
            script = os.path.join(NAPCAT, "classify_emotion.py")
            if not os.path.isfile(script):
                return self._json(404, {"ok": False, "error": "classifier missing"})
            try:
                p = subprocess.Popen(
                    ["python", script],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                return self._json(200, {"ok": True, "pid": p.pid,
                                        "note": "classifying in background"})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/memes/tag":
            src = str(body.get("source") or "")
            tag = str(body.get("tag") or "")
            fname = str(body.get("file") or "")
            want = body.get("tags")
            if not isinstance(want, list):
                return self._json(400, {"ok": False, "error": "tags must be a list"})
            if src == "merged" or not meme_path(src, tag, fname):
                return self._json(404, {"ok": False, "error": "exact meme file not found"})
            try:
                cur = _extra_tags()
                key = _meme_key(src, tag, fname)
                cleaned = [str(t).strip()[:24] for t in want if str(t).strip()][:6]
                # Retain an empty exact entry to override any legacy alias.
                cur[key] = cleaned
                tmp = MEME_TAGS + ".tmp"
                with open(tmp, "w", encoding="utf-8") as fh:
                    json.dump(cur, fh, ensure_ascii=False, indent=1)
                os.replace(tmp, MEME_TAGS)
                return self._json(200, {"ok": True, "tags": cleaned})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/memes/move":
            src = str(body.get("source") or "")
            tag = str(body.get("tag") or "")
            fname = str(body.get("file") or "")
            to_tag = str(body.get("toTag") or "").strip()
            if not to_tag:
                return self._json(400, {"ok": False, "error": "missing toTag"})
            # 只允许移动「收回来的」那一批——其它来源是包自带的，动了会乱
            if src != "stolen":
                return self._json(400, {"ok": False, "error": "only stolen can be moved"})
            full = meme_path(src, tag, fname)
            if not full:
                return self._json(404, {"ok": False, "error": "not found"})
            safe_tag = re.sub(r"[^\w\u4e00-\u9fff-]+", "_", to_tag)[:32]
            if not safe_tag:
                return self._json(400, {"ok": False, "error": "bad tag"})
            dst_dir = os.path.join(LANYA_MEMES, "stolen", safe_tag)
            try:
                real_root = os.path.normcase(os.path.realpath(os.path.join(LANYA_MEMES, "stolen")))
                if (safe_tag in SKIP_DIRS or os.path.commonpath([
                        real_root, os.path.normcase(os.path.realpath(dst_dir))]) != real_root):
                    return self._json(400, {"ok": False, "error": "bad tag"})
                destination = os.path.join(dst_dir, os.path.basename(full))
                if os.path.lexists(destination):
                    return self._json(409, {"ok": False, "error": "destination already exists"})
                os.makedirs(dst_dir, exist_ok=True)
                # On Windows rename refuses a target created after the check.
                os.rename(full, destination)
                return self._json(200, {"ok": True, "toTag": safe_tag})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/memes/delete":
            full = meme_path(body.get("source"), body.get("tag"), body.get("file"))
            if not full:
                return self._json(404, {"ok": False, "error": "not found"})
            try:
                os.remove(full)
                return self._json(200, {"ok": True})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/bili/login/start":
            # 扫码登录：起一个 python 子进程调 bilibili-api 的登录，把二维码图存下来
            try:
                import subprocess as _sp2
                script = os.path.join(NAPCAT, "bili_login3.py")
                if not os.path.isfile(script):
                    return self._json(404, {"ok": False, "error": "bili_login2.py missing"})
                # bilibili_api / qrcode 装在 bili-duty 的 venv 里，系统 python 没有
                _venv = os.path.join(os.path.expanduser("~"), ".dsh", "bili-duty",
                                     ".venv", "Scripts", "python.exe")
                _py = _venv if os.path.isfile(_venv) else "python"
                _sp2.Popen([_py, script],
                           stdout=_sp2.DEVNULL, stderr=_sp2.DEVNULL,
                           creationflags=getattr(_sp2, "CREATE_NO_WINDOW", 0))
                return self._json(200, {"ok": True, "note": "starting"})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path in ("/api/qq/profile", "/api/napcat/profile"):
            try:
                if not isinstance(body, dict) or any(body.get(key) is not None and not isinstance(body[key], str)
                        for key in ('nickname', 'signature', 'avatarBase64', 'backend_fingerprint')):
                    raise qq_backend.BackendError("Invalid profile fields")
                nick = (body.get("nickname") or "").strip()
                sig = (body.get("signature") or "").strip()
                av = (body.get("avatarBase64") or "").strip()
                if len(nick) > 512 or len(sig) > 4096 or len(av) > 8 * 1024 * 1024:
                    raise qq_backend.BackendError("Profile fields exceed limit")
                decoded = None
                if av:
                    if av.startswith("data:"):
                        av = av.split(",", 1)[-1]
                    import base64 as _b64
                    decoded = _b64.b64decode(av, validate=True)
                    if not 0 < len(decoded) <= 5 * 1024 * 1024:
                        raise qq_backend.BackendError("Avatar exceeds the supported limit")
                connection = _qq_connection()
                if body.get("backend_fingerprint") not in (None, connection.fingerprint):
                    raise qq_backend.BackendError("Selected backend changed; reload the profile before editing")
                expected = _qq_profile_expected()
                verified = qq_backend.health(connection, expected_account=expected)
                if not all(verified.get(key) is True for key in ('online', 'good', 'logged_in', 'provider_matches', 'account_matches')):
                    raise qq_backend.BackendError('Backend and QQ account must be verified before editing the profile')

                def _ob(action, payload):
                    return _onebot_call(action, payload, connection=connection)

                # 本地那份档案（页面读的就是它）
                pf0, avatar = _qq_profile_paths(connection, expected)
                saved0, _ = qq_backend._read(pf0, optional=True)
                saved0 = saved0 or {}

                if nick:
                    try:
                        _ob("set_qq_profile", {"nickname": nick})
                        saved0["nickname"] = nick
                        did.append("nickname")
                    except qq_backend.BackendError:
                        warn.append("nickname: backend did not confirm the change")

                if sig:
                    try:
                        rs = _ob("set_self_longnick", {"longNick": sig})
                        details = rs.get("data") if isinstance(rs.get("data"), dict) else rs
                        outcome = details.get("result")
                        if outcome is not None and (type(outcome) is not int or outcome != 0):
                            raise qq_backend.BackendError("Signature change was not accepted")
                        saved0["signature"] = sig
                        did.append("signature")
                    except qq_backend.BackendError:
                        warn.append("signature: backend did not confirm the change")

                if did:
                    try:
                        _write_qq_profile_cache(pf0, json.dumps(saved0, ensure_ascii=False).encode())
                    except Exception:
                        warn.append('local profile cache could not be saved')
                if av:
                    try:
                        _ob("set_qq_avatar", {"file": "base64://" + av})
                    except qq_backend.BackendError:
                        warn.append("avatar: backend did not confirm the change")
                        av = ""
                if av:
                    did.append("avatar")
                    try:
                        _write_qq_profile_cache(avatar, decoded)
                    except Exception:
                        warn.append('local avatar cache could not be saved')
                return self._json(200, {"ok": bool(did) or not warn, "did": did,
                                        "warn": warn, "error": "; ".join(warn) if not did else ""})
            except Exception as e:
                return self._json(200, {"ok": bool(did), "did": did, "warn": warn,
                    "error": str(e) if isinstance(e, qq_backend.BackendError) else 'Profile update could not be confirmed'})

        if path == "/api/update":
            code, result = update_source_repository()
            return self._json(code, result)

        if path == "/api/memory/edit":
            try:
                return self._json(200, memory_mutation("edit", body))
            except ValueError as error:
                return self._json(getattr(error, "status", 400),
                                  {"ok": False, "error": str(error), "code": getattr(error, "code", "invalid_request")})
            except Exception:
                return self._json(500, {"ok": False, "error": "memory maintenance failed"})

        if path == "/api/memory/add":
            try:
                return self._json(200, memory_mutation("add", body))
            except ValueError as error:
                return self._json(getattr(error, "status", 400),
                                  {"ok": False, "error": str(error), "code": getattr(error, "code", "invalid_request")})
            except Exception:
                return self._json(500, {"ok": False, "error": "memory maintenance failed"})

        if path == "/api/memory/delete":
            try:
                return self._json(200, memory_mutation("delete", body))
            except ValueError as error:
                return self._json(getattr(error, "status", 400),
                                  {"ok": False, "error": str(error), "code": getattr(error, "code", "invalid_request")})
            except Exception:
                return self._json(500, {"ok": False, "error": "memory maintenance failed"})

        if path == "/api/files/delete":
            key = str(body.get("dir") or "")
            name = safe_name(body.get("name"))
            if key not in FILE_DIRS or not name:
                return self._json(400, {"ok": False, "error": "bad params"})
            full = os.path.join(FILE_DIRS[key], name)
            if not os.path.isfile(full):
                return self._json(404, {"ok": False, "error": "not found"})
            try:
                os.remove(full)
                return self._json(200, {"ok": True})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/config":
            cfg = body.get("config")
            if not isinstance(cfg, dict):
                return self._json(400, {"ok": False, "error": "config must be an object"})
            try:
                # Merge, do not replace. This used to overwrite the whole file,
                # and the panel sent a hardcoded object, so every identity save
                # wiped adminIdentity / novelTitle / penNames and reset the
                # group and bot QQ numbers to whatever the client had baked in.
                cur = {}
                if os.path.lexists(CONFIG):
                    try:
                        with open(CONFIG, "r", encoding="utf-8-sig") as fh:
                            cur = json.load(fh)
                        if not isinstance(cur, dict):
                            raise ValueError("Existing configuration is not an object")
                    except Exception:
                        return self._json(409, {"ok": False, "code": "existing_config_unavailable",
                            "error": "Existing configuration cannot be safely merged; original file preserved"})
                merged = dict(cur)
                for k, v in cfg.items():
                    # An explicit null means "remove this key".
                    if v is None:
                        merged.pop(k, None)
                    else:
                        merged[k] = v
                import uuid as _ucfg
                tmp = CONFIG + "." + _ucfg.uuid4().hex[:8] + ".tmp"
                with open(tmp, "w", encoding="utf-8") as fh:
                    json.dump(merged, fh, ensure_ascii=False, indent=2)
                for _try in range(6):
                    try:
                        os.replace(tmp, CONFIG)
                        break
                    except OSError:
                        if _try == 5:
                            raise
                        import time as _t
                        _t.sleep(0.08)
                return self._json(200, {"ok": True, "keys": sorted(merged.keys())})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/plugin-toggle":
            name = str(body.get("name") or "").strip()
            want = body.get("enabled") is not False
            if not name:
                return self._json(400, {"ok": False, "error": "missing name"})
            try:
                with open(PROFILE_PKG, "r", encoding="utf-8") as fh:
                    doc = json.load(fh)
                bundles = doc.setdefault("dsh", {}).setdefault("profile", {}).setdefault("bundles", [])
                if want and name not in bundles:
                    bundles.append(name)
                if not want and name in bundles:
                    bundles.remove(name)
                tmp = PROFILE_PKG + ".tmp"
                with open(tmp, "w", encoding="utf-8") as fh:
                    json.dump(doc, fh, ensure_ascii=False, indent=2)
                os.replace(tmp, PROFILE_PKG)
                return self._json(200, {"ok": True, "enabled": want, "restart": True})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})

        if path == "/api/plugin":
            op = str(body.get("op") or "add")
            spec = str(body.get("spec") or "").strip()
            if not spec:
                return self._json(400, {"ok": False, "log": "missing spec"})
            try:
                p = subprocess.run(
                    [DSH_CLI, "plugin", "--profile", "desktop", op, spec],
                    capture_output=True, timeout=900,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                out = (p.stdout or b"").decode("utf-8", "replace") + (p.stderr or b"").decode("utf-8", "replace")
                return self._json(200, {"ok": p.returncode == 0, "log": out.strip() or "(no output)"})
            except Exception as e:
                return self._json(200, {"ok": False, "log": "failed: " + str(e)})

        return self._json(404, {"ok": False, "error": "no such route"})


def main():
    port = int(os.environ.get("LANYA_PANEL_PORT") or project_conf.get("panelPort", 19389))
    if "--port" in sys.argv:
        try:
            port = int(sys.argv[sys.argv.index("--port") + 1])
        except Exception:
            pass
    os.makedirs(ROOT, exist_ok=True)
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print("lanya panel server on http://127.0.0.1:%d/lanya-panel.html" % port, flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    while True:
        try:
            main()
        except KeyboardInterrupt:
            break
        except Exception as e:
            print("crashed: %s - restarting in 5s" % e, flush=True)
            import time
            time.sleep(5)
