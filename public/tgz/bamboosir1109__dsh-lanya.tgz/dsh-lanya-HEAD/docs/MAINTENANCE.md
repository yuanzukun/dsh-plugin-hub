# 维护与发布

## 聊天导出

定时入口 `scripts/export-chats.py` 调用同目录的 `chat_export.py`。部署时一起提供模块和既有的原生读取、文件保护辅助程序。当前导出只按可信配置的工作区、角色和 QQ 映射读取原生来源；不按修改时间寻找其他工作区，也不把 GUI 会话当成 QQ 对话。

导出位于角色目录的 `chats/current/<工作区与角色摘要>/`，以 `index.json` 列出的生成物为当前集合。未变的来源跳过解压；源文件变化但可读正文不变时不重写 Markdown。文本采用来源时间和北京时间，区分群消息、对方、助手生成及精确配对的内联发送回执；接口接受不证明对方客户端可见。

人工文件与历史 `chats/` 根目录不由新导出器扫描或删除。只更新已核对哈希的生成物；退出当前集合的生成物移入隐藏历史，保留字节及原权限描述。人工修改、来源歧义、范围不匹配或继承边界不完整时保留原件并报告不可用或部分结果。不要为了导出通过而删除原生记录或退回全局扫描。

## QQ 后端维护

开发版本的后端选择与真实连接分开验收。切换前检查当前加载的接入保护、保存本机配置及完整权限，并确认另一套接入停止；不要依据端口可达或进程名断言 QQ 已登录。原生连接核验只在同一 socket 和配置代次内复用，不给每条消息重复增加握手。

连接补丁与引用补丁必须跟主适配器和预算心跳辅助程序成对加载；切换检查需要新鲜心跳的两项实际运行标志，不只核对磁盘哈希。重连会拒收原 socket 的迟到帧，替换反向连接会立即结束原调用的等待并标记结果未确认；不得在新连接自动补发。两个独立编译器仅生成精确输入候选，部署前仍需完整备份、停止宿主、原件及父链核验和重载后的读回。

供应商模块可能与包存储共享硬链接。只读生成候选不修改任一链接；实际部署须核对全部原链接与文件身份、保留原件及权限，以新文件原子替换目标，不能原地覆写共享文件。其他链接继续保留原内容，回退仍须逐项核对；配置文件的单链接保护不因此放宽。

启动记录位于共享服务目录的 `backend-runtime/`，不放入角色的可写家目录。未决启动意图、未知 PID 身份或仍在运行的另一套后端必须先核查，不删除记录来触发重试，不强杀整个 QQ。已核验的完成记录可移入本机归档，保留原件与权限。资料缓存按后端及账号隔离，接口接受修改仍需与手机实际显示区分。

源码改动、安装器部署、常驻进程加载、SnowLuma 独立安装登录和真实业务矩阵分别登记；隔离 WebUI 截图不能证明真实 QQ 已切换。供应商程序、协议、账号数据和本机审计材料不进入公开仓库。完整规则见 [QQ 后端](QQ-BACKENDS.md)。

## 交互链路排查

每次按输入分别核对接收、准入、准备、原生入队、领取、决定、发送与客户端，不以在线状态代替回复成功。启用 native claim 时可用 `scripts/interaction_health.py --log ABSOLUTE_PRIVATE_INTERACTION_LOG` 只读汇总本机阶段日志；没有正文、不触发模型或发送，不自动重放。安静决定、拒发、未知回执与真正等待分别展示，来源达到容量或截断时保留部分状态。

当前原生队列可在条件允许时接收并合并连发；非原生／诊断或拥挤边界继续按既有接收限制。独立 `patch_onebot_burst_intake.py` 只编译已审的 contextual group 层后 bridge／inbound，输出须精确输入 SHA 且独占创建，不自动安装。须与成对 adapter 受控部署，保留全部之前的准入、引用、权限和出口修改。详见 [交互可靠性检查](INTERACTION-RELIABILITY.md)。

## 人设语气与自主提示

修改实际加载的人设之前，先从运行配置解析 `personaFile`，区分源码模板、正在读取的正文和作品目录里的历史副本；保留原文与完整权限，再替换与当前偏好冲突的强制顶嘴、刻薄或推责指令。只在新段落写“温柔”而保留冲突规则，会继续误导角色。身份、真实关系、私人记忆不复制进公开模板。

聊天简版与自主完整说明共用温和语气；自主机会另外包含自选下一步、真实行动和适度参与的偏好。提示不提高发言配额、不缩短私聊间隔、不解除静默、不唤醒夜间任务，也不授权跨会话发送。说明只包含简洁活动摘要，不要求公开隐藏推理。

人设 section 使用当前文件读取回调，运行工具说明在每次 helper 调用时生成；只更新这些提示与版本元数据不需要重启主服务。核验文件哈希、实际配置路径、已注册读取回调及真实 helper 输出；自然语气和行为频率仍需后续真实对话观察，静态短语检查不是模型行为验收。

## 回复前的准备时间

真实来信的运行工具说明使用 `live_chat` 模式，模式只来自 adapter 的当前同范围 live 绑定，不从消息内容、引用或旧会话推断。该模式每次仍读取当前配置和归属，保留记忆、图像、语音与发送边界；只省略阻塞的进程列表／设备锁探测和不相关的自主长说明。未探测的已安装组件标为未核验，不能断言离线或可以直接操作。自主观察仍使用完整工具协议，工具真正执行前仍以新鲜结果为准。

排查回复慢时分别计时入站准备、排队、模型步骤、压缩、工具和发送。简化一次 helper 不代表消除模型、网络或正在执行工具的等待；压缩原件与当前费用必须保留，不通过清空会话或取消未知发送“提速”。

## 页面与加载验收

在源码根目录运行只读本机检查，分别核验两个端口：

```powershell
python -B scripts/panel_health.py --base-url http://127.0.0.1:19388
python -B scripts/panel_health.py --base-url http://127.0.0.1:19389
```

检查实际嵌套的 B站、活动、每日花销、记忆和日记来源，不能只看 HTTP 200、顶层 `ok` 或进程在线。输出只有路由、状态和耗时；`degraded` 表示部分结果仍未知，`unavailable` 才使整体检查失败。已核验空列表、尚未写日记与读取失败分别处理。它不验证真实 QQ 收件端或平台公开可见性，也不触发模型、发送或生成日记。

发现加载慢时区分冷解析与同一来源的缓存命中、预算摘要与完整日报，固定同一端口和实际来源再比较，不把一轮缓存时间宣称为所有页面都达到同样延迟。并发单元测试、自然活动和文件变化均可能影响实测。

当前程序静态检查排除按受控安装器命名的 `.名称-original-<32位标识>`／stage 副本；它们是恢复材料，完整原件与权限仍应另行核对。要检查这些文件本身，使用 `python -B scripts/fullcheck.py --live --root ABSOLUTE_RUNTIME --include-recovery`。不要因恢复副本包含当时的问题就删除它，也不能凭文件名推断实际是否仍有引用。

内部 `agent-instructions`、`runtime-context`、`repeat-tool-reminder`、`compact-checkpoint` 使用原生来源字段识别，不从聊天文字推断。它们不创建或替换入站绑定；已经登记为真实输入的同 ID 消息继续完整验证，未知来源继续拒绝。真实验收须覆盖工具提醒前后和压缩后的下一轮，不只发一句普通问候。

## 纯表情回复

`qq_decide(reply, expression=meme)` 表示本轮只发表情，不自动附加 assistant 最后文字。真实表情须经过现有主机分类与发送守卫；其它沟通在发送预留前以 `meme_only_reply` 拒绝，不把这类本地拒绝登记成未知送达。有独立正文时应在首次输出前选择 `text_meme`，图文仍分消息、一轮最多一张表情。不可用图片或未知送达不自动换文字、不假造成功；下一轮可以独立选择文字。工具回执、消息编号、预算与次数不自动外显，原生会话和真实发送记录分别保留。

## 自主休息与联系节奏

统一自主休息固定为北京时间 `00:00 <= time < 08:00`。生产者、待派观察、原生步前、工具执行和 QQ 最终出口分别守住边界；不靠修改 LLM 的远期复查时间来表示睡眠。真实来信仍走原会话和原规则；基础连接、只读采集与维护可继续，已经发起的外部调用不声称被撤回。

主动私聊间隔为一小时，并要求上一次主动联系后出现新的已接收真实来信；该状态与第一次实际发送预留一同持久保存，同轮多包共享一次联系。缺少主动来源的历史发送只用于保守初始间隔，不推断未读、不重放未知项。管理员正常来信后的回复及白天内部娱乐不受主动冷却限制。

休息／过期观察使用明确的本地 `no_decision` 收尾，不能伪造 `decision_id`、模型 idle 或成功送达。新本地条目不推进前台 revision；提醒调度需使用真实 `local_outcome_id` 消费这种终态，避免无模型决定的提醒永久 pending。维护时保留原事件、策略、提醒状态、预算与完整恢复原件；新增本地终态或持久联系字段不代表可将旧源码直接覆盖回来，回退前须核对相应状态兼容性。

定时提醒采用受信 occurrence 的 `due_at`，队列生成的复查绑定真实父决定与原始机会的文件指纹、所属范围和时间，不能用新复查时间刷新跨夜机会。新链保留可直接核对的原始锚点；升级前无锚点的复查最多追溯六十四层，超过边界或原件冲突时保留事件并拒绝派发，不声称所有历史长链已迁移。

## 可塑记忆与日记维护

可塑注释是 memento 事实版本的附属历史，不替换 entries schema，也不导入模板或批量改写已有记忆。`patch_memento_metadata.build_candidates` 仅接受已完成可见性、原生历史和当前会话召回补丁的精确三份程序，生成三份增量候选与独立 helper；它不是安装、数据库迁移或自动恢复命令。未知安装源码应拒绝，不强制覆盖定制。新增 schema 需由实际宿主工厂验收，隔离注册替身不能证明工具能加载。

停止相关 writer 并一致备份后，协调部署原生工具消费入口、协议、Provider、metadata helper，以及 Python 的注释、检索、维护与显示投影。注释只在实际事实写事务中创建；安装源码不表示真实条目已经带有新注释。历史编译器输出须可重现，旧事实、审批、原生历史、召回范围与所有恢复记录均保留。撤回程序也不删除已经产生的注释表或派生历史；事实版本不匹配的注释保持未知。

日记还需同批部署主 adapter、精确编译 alias、独立 diary helper、事实底稿、primary 机会提示和面板 API／HTML。API GET 不调用模型或代写日记；当天真实成文回执、自然检索效果与内容质量另行观察。私域正文不从群聊工具读取，也不上传公开仓库。

维护备份需同时覆盖现存 `diary/` 原件与 `activity-journal/`，包括 personal 日记、来源快照及未决恢复需要的普通文件；操作系统锁与跨文件原子性分别记录。SQLite 采用一致快照，不能将几份独立文件副本说成跨文件全局原子。新增数据库出现后纳入实际备份清单，不盲用固定库数。恢复不清除未决项、不抹去原件权限或重置预算。

## 同一主 agent 的语音维护

`qq_synthesize_voice` 按需调用本机引擎，成功后由 adapter 校验并准备渠道媒体副本，`qq_send_voice` 沿当前会话的既有许可和媒体围栏发送。更新 adapter 时，公开源与精确编译的实际 OneBot alias 必须成对部署；只复制合成器不能修复普通成员的路径围栏。不能为发送音频给成员开放整个工作区。

系统页与 `GET /api/voice-status` 只投影安装与进程线索，不自动合成、不读历史音频或队列；引擎进程正常不等于 QQ 已送达。统一模式下不恢复独立语音队列，不清空原积压。维护应保留音频、请求账本及旧结果，未知合成／发送不自动重试；新增格式参数导致旧请求哈希不一致时拒绝，不能覆盖旧请求或回写为已发送。

实际本地合成可使用固定泛用短句单独验收，结果与参考音色仅存本机；不能把维护样本记为角色主动发送。发布前分别记录隔离媒体围栏、同轮静默撤销、可解码 WAV、实际宿主加载与自然 QQ 回执。仅改文档或版本元数据时不重启业务。

## 持续监控与后台窗口

双击安装目录的 `napcat/monitor.cmd`，或在同一个终端运行：

```powershell
& 'ABSOLUTE_INSTALLED_MONITOR_PS1' -Root 'ABSOLUTE_WORKSPACE'
# 只读取一次，适合排查输出；不会启动守护或模型
& 'ABSOLUTE_INSTALLED_MONITOR_PS1' -Root 'ABSOLUTE_WORKSPACE' -Once
```

窗口每五秒原地刷新，工作区命名互斥锁防止重复监控。它只读取状态文件、本机有界健康接口与现有预算任务信息，不产生检查子进程，也不启动、停止或重注册服务。关闭窗口或 Ctrl+C 仅结束监视。文件中的版本明确标为安装文件或源码版本，不能推断已加载；QQ 端口可达也不表示登录或消息已经送达。临时不可用和失效心跳如实显示。

`hidden_task.py` 供 pythonw 调用，以 Windows 无控制台标志执行一个明确的本地 PowerShell 文件，保留工作目录与退出码，丢弃该任务的控制台输出。结果从计划任务的最近执行时间和结果码读取；不要把业务输出重定向到公开目录。注册器新建周期任务时解析配置的 Python 或默认 Python 的实际位置，要求同目录 pythonw 真实存在，不退回可见控制台。

`ensure-tasks.ps1` 仍不覆盖已有任务。修复已注册的预算任务时，先备份完整 XML 与安全描述符，再只修改该任务的执行动作；保持触发器、五分钟周期、执行账户、权限、设置和启用状态，回读其余任务不变。不为显示一个窗口启动额外 supervisor，不重新注册整套任务。

## 主 agent 持续待命与恢复

预算心跳与观察消费者有同一个有界恢复循环：首次启动失败、租约暂被活 owner 占用或临时异常不会永久停止重试；活 owner 的租约不能因时间过去被抢走。停止后迟到的异步启动不能重新持租约，进行中或 unknown 的轮次不能通过重启被自动重放。

`scripts/main_agent_watch.py` 是独立于 DSH 宿主的 Windows 看护。默认只读预览，`--watch --apply` 才允许持续运行和恢复。它持有原生文件锁，每十五秒检查真实进程、两个核心端口和调度心跳；只在连续确认没有宿主、没有不明进程且端口未占用后，复核固定程序和启动配置哈希再启动一次，失败后退避。端口可达性仍分为成功、拒绝与未知，连接超时不能直接视为关闭；恢复准入另外要求连接前后两次完整的原生 IPv4、IPv6 监听表都确认目标端口缺席，任意地址的监听或不完整清单都会阻止启动。健康状态仍要求实际连接成功及新鲜调度证据，监听表缺席不能冒充服务正常。它不会发送消息、调用模型、强杀存活宿主或因旧心跳启动第二个实例。活动页分别展示调度与看护，不能用看护在线掩盖消费者离线。

私有配置放在角色目录的 `main-agent-watch.config.json`：`schema` 为 `dsh-main-agent-watch/v1`，`enabled` 为布尔值，`host_executable` 为已核实的 DSH 绝对路径，`host_sha256` 为该程序 SHA-256，`arguments` 固定为空数组，`scheduler_file` 为本工作区 `napcat/scheduler-in-plugin.flag`，`core_ports` 为该宿主的两个核心端口。`startup_bindings` 固定包含两项 `{path, sha256}`，分别绑定实际 profile 和当前 profile 选择配置，防止恢复错环境。真实路径和内容留在本机，不提交这份配置。

```powershell
# 用已部署位置和实际私有配置替换占位值；默认只读，不拉起宿主
python -B ABSOLUTE_INSTALLED_MAIN_AGENT_WATCH --config ABSOLUTE_PRIVATE_WATCH_CONFIG

# 已确认配置后，使用该安装的 pythonw 隐藏运行
pythonw -B ABSOLUTE_INSTALLED_MAIN_AGENT_WATCH --config ABSOLUTE_PRIVATE_WATCH_CONFIG --watch --apply
```

登录待命可通过当前用户 Startup 中的独立快捷方式调用同一命令，明确绑定 Python、已部署脚本及私有配置；先核实已有入口，不能覆盖不明启动项。操作性维护前将私有配置 `enabled` 设为 `false`，核对暂停状态后再停宿主，维护完成后恢复 `true`。这是停机维护的抑制开关，不是清空队列。DSH 程序或启动 profile 改变后先重新核验绑定；阻塞或未知状态要核对原因，不能删除状态、抢租约或关掉校验来强行变绿。

## 私聊与群提及接收

排查不回复时，按实际会话分别核对接收过滤、原生入队、回合开始、决策和发送回执；主进程或管理员会话正常不足以证明其它私聊正常。原生记录看不到 dispatch 前被丢弃的消息，回合完成也不证明 QQ 已送达。`reply` 许可、平台接受及客户端显示要分别判断，发送未知时保留原件，不能补发或改写为成功。

OneBot 0.8.1 的接收顺序升级由 `scripts/patch_onebot_inbound_admission.py` 生成增量。它只接受已审 policy 和 scoped inbound 层，将登记入站移到限流和最终非空检查之后；还须同批安装当前主 adapter 与显式编译的 OneBot alias。适配器使用可信到达序号和按会话的短登记串行段，较早的慢媒体／引用不能晚完成后覆盖已接收的新输入。过滤、命令处理或空展开不再制造新 revision，正常新输入仍撤销旧票。原限流语义保留，不承诺每条连发或持续洪流都立即得到回复。

`scripts/patch_onebot_mentions.py` 单独生成原生 `cq.js` 的提及兼容增量，统一字符串与可精确表示的正整数 QQ 身份；不猜测超出安全整数范围的数字，不把布尔或对象转换成账号。`@all`、别人的提及和缺少作者的引用各保留原有语义，能通过接收门槛不代表可信上下文已经证实是在叫自己。两个生成器默认只读预览；指定全新 `--output` 还须匹配 `--expected-sha256`，不会自行安装或重启。共享硬链接的原生模块必须以新 inode 替换目标并保留其它别名，不能就地写入共享原件。

升级后用隔离真实接收管线覆盖私聊、群提及、限流、空展开、命令、慢引用与持久化失败释放；真实模型仍按当前上下文决定是否回复，静默、预算及最终发送 guard 不变。历史未决发送不自动重试，未开始的旧消息也不凭正文恢复权限。常驻看护只处理已核实的主进程缺席，不因某次没有回复就反复重启或清空队列。

## QQ 群消息队列升级

当前私聊按用户、群聊按群映射到独立 session 和持久 inbox，实时输入不经过全局自主观察的模型队列。观察消费者按 scope 保序并有界并行；轮询期间即使某一轮仍在等待，也须能发现其它 scope 的新事件。同 scope 的活动轮与待处理输入继续串行，停止消费者要等在飞处理收尾后才释放唯一租约，不能另起第二个宿主抢占。

排查零点等定时提醒时，检索对应日期、scope 与实际原生轮次，依次核对观察入队、`qq_decide`、媒体工具结果、最终 assistant 文本及发送记录。工具 `unknown` 后再调用 `idle` 会因本轮已决定而被拒绝，不能把它当作已撤销旧 reply 票。adapter 因此根据当前原生 record 的真实 `unknown`／`partial` 结果停止本轮后续外发；不要清掉历史不确定项，也不要发一条“不要重试”的 QQ 说明充当收尾。正常括号解释、新用户追问和未来独立提醒各按原边界处理。

收到消息不等于已经开始处理。宿主每轮只取一条 `next-turn`；群消息连续到达时，过期输入可能逐条消耗模型轮次，而新版策略已经按更新输入递增 revision。此时 `stale_revision` 必须保留，不能通过放宽票或关闭静默校验来让旧回答发出。

`scripts/patch_onebot_live_inbox.py` 在已安装 policy 层的 OneBot 0.8.1 bridge 上构建独立增量，保留 replay、egress 等现有修改。它只生成新文件，不改安装目录、不证明停机、不启动宿主。先明确实际 bridge 与全新暂存目录，从仓库根目录运行：

```powershell
python -B scripts/patch_onebot_live_inbox.py --bridge ABSOLUTE_INSTALLED_BRIDGE --build-dir NEW_PRIVATE_BUILD_DIRECTORY
python -B scripts/patch_onebot_live_inbox.py --bridge ABSOLUTE_INSTALLED_BRIDGE --build-dir NEW_PRIVATE_BUILD_DIRECTORY --expected-fingerprint FRESH_PREVIEW_FINGERPRINT
```

第一次只读返回输入、生成模块和整体指纹，第二次才独占创建暂存目录。输入变动、重复标记、歧义锚点或已存在的输出应拒绝；不要删除已有输出后盲重跑。暂存内的 bridge、别名 adapter 与恢复 helper 必须作为同一批受控部署，并更新本项目包内的 adapter／helper，保留每项真实 before、完整权限与私有恢复原件。安装器复制脚本不会自动更新外部 OneBot 插件，生成完文件也不表示当前宿主已经加载。

运行模式按 `agent/inbox/claimed` 的实际消息 ID 与完整内容绑定权限，不再将一个独立 FIFO 当作真实消费。只有同一 bridge 实例、agent、范围、owner 与角色下仍未开始处理的真实 QQ 输入可以合并；不同来源、观察、外部输入、权限变化或未知条目保持边界。被替换的原输入仍留在原生队列变更历史，较早内容仅作为上下文，不借当前管理员的权限执行旧指令。活动轮次的旧票仍可能过期，持续不断的新输入也不能保证立即回复；合并减少待处理积压，不承诺固定延迟或强制开口。

新模式仅在真实 claimed 后、宿主进入模型前，通过 awaited pre-step 完成本轮预算准入。尚未开始的合并输入不逐条创建预留，不借用活动轮预算。原账、历史未知项及升级前已有预留保留；权限冲突或未知 claim 不进入模型和发送，不能从消息正文重建信任。

宿主恢复的历史 pending 不自动获得新进程的内存绑定。首步因无绑定阻断后，适配器可在原生空闲时继续排在其后的本实例已绑定输入，严格复核队首身份、完整内容、当前归属和取消状态。此恢复依赖已审 SDK 内部 `wakeDriver` 方法的精确指纹，不是公开稳定 API；版本变化时保守拒绝并重新审查。它不删除或重注入 pending，不替预算拒绝或用户取消自动续跑。

已有积压必须单独维护。本机可信 adapter 配置可显式设置 `inboxRecovery` 的 `planFile` 与 `planSha256`；没有这项配置时恢复 helper 无效果。一次性私有计划须精确绑定实际群、会话、workspace／preset、原定 pending ID 和完整消息哈希，在受限目录先保存完整队列原件与意图，再由原宿主的同步 inbox API 逐项验证并归档。它不建立旧输入的回复票、不重放旧请求、不改预算、不触活动轮或观察。失败或部分执行保留证据，不在下一条消息上自动重试；完成后移除本机临时配置并保留恢复记录，不把这些私有计划提交源码仓库。

若入站报 `POLICY_LOCK_UNAVAILABLE`，先检查决策锁及恢复 claim 的真实文件身份和内容。当前实现先完整写入同目录唯一 owner 候选，fsync、关闭后再以硬链接独占发布；需要支持硬链接的文件系统，失败时直接拒绝，不回退覆盖改名。已有空文件、损坏 owner 或未知 claim 不能当作死亡进程并按超时删除。常规 `repairPolicyLocks` 仍需预览、完整停写证明及原件校验；本次 Windows 零字节锁的独占句柄归档仅适用于已独立核实的特定事故，不是通用抢锁入口。崩溃候选留在本地供核查，不自动全目录清理。

## 群聊指向、引用与单表情升级

`scripts/patch_onebot_inbound_context.py` 为已经有 policy 的 OneBot 0.8.1 构建独立增量，分别处理 bridge、inbound 和此前部署的 prompt；不会安装、启动宿主或查询 QQ。先核实当前各文件及既有层的真实 before，在受保护的新目录预览和生成：

```powershell
python -B scripts/patch_onebot_inbound_context.py --input ABSOLUTE_INSTALLED_INBOUND --name inbound.js
python -B scripts/patch_onebot_inbound_context.py --input ABSOLUTE_INSTALLED_INBOUND --name inbound.js --expected-sha256 EXACT_BEFORE_SHA256 --output NEW_PRIVATE_INBOUND_ARTIFACT
```

bridge 与旧 prompt 按各自文件名独立预检，不能把一个文件的哈希用到另一个文件。已由当前 policy 生成的新 prompt 本身已有新的周期、引用和单表情说明，不再叠加旧 prompt 的增量；不符合锚点或已有增量标记时拒绝，不能通过删除标记或放宽身份检查强行覆盖。引用、原生 inbox、重放和内容出口的既有修改须一起保留。

部署是同一批受控变更：policy 的项目副本和 OneBot 别名副本、项目 adapter 和经当前完整编译链生成的 OneBot alias、OneBot 内容出口模块、bridge／inbound／prompt、运行能力脚本和版本元数据逐项核验。新版 alias 依赖新版出口的表情识别与明确拒绝标记，不能只替换其中一件。保留实际程序、配置、会话、队列及账本原件和权限，确认空闲并暂停看护后按固定 before／after 安装；恢复看护、实际重载，再核对新进程加载证据。生成文件或更新版本元数据本身不等于已加载。

群复查只影响新配置群机会，复用页面现有周期，不重写较早持久预约、不重放未知动作。真实 QQ 验收分别确认对象判断、引用文字和图片、文字／表情独立消息及同轮一张；增加判断机会不能冒充已经更活跃，成功选图也不能冒充已发送。协议见 [主 LLM 决策](DECISIONS.md#群聊对象与引用)。

## QQ 上下文与原生压缩

待处理条数少仍可能很慢。分别核对领取到 `step/start`、模型步骤到决策的时间，以及原生用量中的输入和缓存读取 token；缓存命中不能当作没有上下文成本。处理越久，新输入使旧许可过期的机会越多；大量历史可能加重延迟，步前等待与实际模型请求仍须分别核验。保留 `stale_revision`，不要以允许旧回答发送来掩盖延迟。

DSH 的正式 `/compact` 是命令，不是发给模型的聊天内容。它通过原生维护阶段生成摘要并追加压缩标记，原始事件历史保留；活动轮或待唤醒工作未完成时会返回忙，不应清空 pending、取消未知发送或伪造空闲来运行。短期上下文、原生会话摘要和工作区长期记忆是不同层，压缩不等于删除长期记忆。

阈值来自当前 agent preset 的压缩插件、实际模型窗口、最大输出与安全预留，不能仅按模型宣称的窗口推断。本机曾采用 `thresholdRatio=0.1`、`retainRatio=0.02`、`maxTokens=8192`，但频繁压缩本身也会增加等待，不能把低阈值当作低延迟保证。应先减少重复注入，再根据真实提示与工具体积、压缩次数和模型耗时评估参数；这些值分别控制触发比例、保留尾部和摘要输出上限，不能把摘要上限误改为聊天输出上限。参数仍受原生 schema 和模型能力限制。

排查回复慢时，分别量取原生入队到领取、装配与 admission、压缩、模型步骤、工具调用和实际发送。入队到 `user/message` 的间隔可能包含压缩，不能再把同一段重复计为排队；无 `qq_decide(reply)` 的正常结束也不是发出回复。当前轮指南通过独立提示节装配，历史中早期的重复说明保留给正常原生压缩处理。不要为了减小输入清空会话、降低记忆范围保护或重发未知送达。进程健康、helper 完成和发送端接受均不能代替手机端收到及端到端测时。

含图轮次还应检查 `read_image` 是否因扩展名与真实格式不符而报错，之后又多次调用命令行查文件和复制。适配器在实际媒体 resolver 返回后，为四种受支持格式提供正确扩展名的同字节副本，覆盖直接图、引用图和转发图；原图不重命名，副本沿用媒体缓存清理。它只识别文件头，不替代真实图片解码、解码上限或工具权限；未知内容和校正失败仍交给原有路径与明确错误处理，不虚称已经看图。

维护前从实际会话映射冻结完整清单，不固定会话数量；新增熟人会话也要核对原生记录、归属和队列。结构或归属检查失败时停止维护并恢复看护，不能当作普通忙碌反复扫描；仅对真实活跃状态作有间隔的有限等待。会话清单在停止前变化时重新评估，不遗漏新会话或强行清空队列。

连续来信还应核对 `stale_revision` 后是否继续消耗模型步骤。当前适配器仅在确认物理队首为可信更新 live 输入时，在步骤边界结束旧聊天轮次；记账后再沿用原生 driver 继续队列。看到 `blocked` 时，要区分正常让位、预算拒绝和无绑定输入，不能一律认为掉线，也不能删除 pending 或手工重放。同步压缩正在执行时仍须等待安全边界，本机制不保证每条碎片单独回复。

本机在确认一百万 token 窗口、最大输出和安全预留后，仅将该 preset 的触发比例调为 `0.2`，其余保留与摘要参数保持。这不是其他模型的通用默认值；迁移须先验证实际容量与原生 schema，并同步看护启动绑定。群聊机会若长期等待，还应检查不可变祖先链是否超出迁移边界；当前 JS／Python 均允许最多 128 个节点，新锚点继续避免长链增长。旧链过期应保留原件并由正式生命周期收尾，不能删除 pending 或伪造模型决定来解除等待。

配置持久保存与现有 agent 生效分别验收。本机已核验的原生设置入口拒绝这些非 volatile 压缩字段的在线修改，preset 文件变化也不会自动替换已绑定的旧 revision；不要仅改文件或看保存成功就宣称在线生效。已有运行环境通过已核实版本的正式命令或 Loader 生命周期维护目标压缩服务，并读回实际服务、原 agent 与队列身份；共享同一 preset revision 的多个 agent 会共同受影响。在线维护没有实际执行回执时，保留未知记录并移除临时入口，按正式退出、重新加载及生效核验处理。私有配置、原件、维护模块及结果留在本机，具体部署与压缩是否真正发生见开发日志。

本机持久覆盖应保留已安装标准 preset 的完整节点，仅修改核对过的压缩配置；不要以一个只有压缩插件的同名 preset 替换整棵标准树。复制的定义不会自动吸收后续 DSH 更新，升级宿主时须对照新内置定义复核；看护的启动绑定也须与最终 profile 一致。

## QQ 响应与自主复查性能

群提及或私聊未见回复时，分别核对实际平台输入、入站登记、原生领取、步前等待、模型决定和发送记录。不同会话虽各有 agent 和队列，仍共享一个 Node 后台；某个同步扫描占住事件循环，也会拖慢其它会话。新消息入队或进程健康，不能代替响应延迟核验。

大量历史复查完成后，扫描不应先为每项重走祖先，再发现其后继早已完成。当前优化只对完整终态、逐字段符合当前父项及其回执的无锚后继，确认没有新工作后提前结束；损坏或冲突仍拒绝。尚需调度、未完成后继及带锚记录继续执行原有来源、父回执、循环和深度检查，不保存跨轮的祖先许可缓存。

长扫描还须避免周期 tick 在扫描期间要求立即重扫。内部周期唤醒在扫描中合并，显式 `drain()` 仍请求重扫，等待模型中的其它范围仍可被后续周期发现。目录每层执行真实 lstat，创建后继续验证普通目录；扫描和调度以单调工作时间决定何时让出事件循环，单个完整证据读取仍同步完成，不宣称硬延迟上限。不能为提速跳过哈希、原件、未知结果或祖先边界校验。

更新时同步项目队列模块和 OneBot 对应队列副本，再按实际加载过程核验；仅更新 adapter 或根版本号不能启用该修复。历史 pending、done、未知发送和原始消息保留，不靠删除历史或重放消息提速。

平台成功回执、本机群历史和非零序列仍只说明发送端可查；接收端是否显示需单独确认。用户未见消息时不要将其直接归为模型不回复、账号风控或手机缓存问题，也不要自动重发未知结果。性能修复与接收端显示分别验收。

## 本地无决策收尾升级

最新自主链同时依赖 `decision-policy.js`、`observation-queue.js`、`onebot-policy-adapter.js` 与 Python `decision_events.py`、`mind.py`。OneBot 安装副本中的三个对应模块也必须同步；仅替换 adapter 会缺少本地收尾方法。面板服务和 HTML 同步更新，才能识别 `no_decision` 并显示等待下次机会。

全新安装使用当前源码生成模块。已有多层补丁的环境须先核验全部父层、实际 before、ACL 与文件身份，保留旧 manifest，为本次精确目标建立独立增量与恢复原件，再协调重载宿主。下述旧连续性增量工具只负责其标记声明的目标，不能拿它覆盖安装最新三个模块。保留所有 pending、done、policy、发送记录和预算数据库；无需清空记忆或重放观察来启用新终态。

## 自主连续性增量层

`scripts/patch_autonomy_continuity.py` 更新已完成 autonomy V1 安装的外部 OneBot 适配器和观察队列。默认 preview 只读；应用需先确认对应宿主停止，提供新的私有备份目录和本次 preview fingerprint。它核验历史父层、保存两个程序的精确原件及生成副本，使用独立 `lanya-continuity.patch.json` 标记，不覆盖旧层记录或策略状态。未知修改与部分应用必须用该层自己的私有 manifest 诊断、恢复，不能重跑旧安装器覆盖。

同时部署本项目的 `decision_events.py`、`runtime_capabilities.py` 及观察生产者等对应源码，然后重载实际 OneBot 宿主；只更新磁盘或热读取 helper 不算完成。版本 1 的缺失事件从原归档逐一按完成标记 SHA 恢复，保留归档原件和 done；不能删 done、清空 mind 或重放旧事件。新的版本 2 完成记录可在 pending 原件归档后继续校验；尚未完成的事件及整个 done 目录仍是运行数据，不能作为冗余清理。

设置保存先比较完整 owner/group/DACL 描述符：两边已相同且再次读回仍一致时保留现有权限，避免 Windows 拒绝无意义的重复设置；不同描述符仍须严格复制并核对完整结果。新 helper 应部署到实际运行位置，面板进程也需加载它，不能只更新公开源码就声称保存已恢复。

## 意图工具与控制台升级

当前 OneBot alias 在编译时把 `autonomy-intents.js` 放入封闭作用域，保持旧模块名和父层清单；直接插件副本仍需部署该新 helper。编译器必须使用同一批冻结源码，不能混用新 helper 与旧 adapter 生成所谓原件。真实工具注册通过既有 `tools.js` 持有的 SDK `defineTool` 工厂，不能把原始工具选项直接注册成已完成的 SDK 定义。

已有安装的 `tools.js` 需要独立增量。`patch_autonomy_tools.py --input <ONEBOT>/lib/tools.js` 默认只读生成前后指纹；加 `--expected-sha256 <BEFORE_SHA> --output <PRIVATE>/tools-candidate.js` 只在新的私有位置生成候选，不替换运行程序，也不更新旧 manifest。确认宿主停止、逐项核验现状并保存工具模块的精确原件、文件身份及完整权限后，才由受控维护替换该候选；恢复使用同批原件，不能运行旧安装器覆盖新模块。全新 policy 安装会直接生成同一工厂入口。

该生成器不能代替整批安装。除适配器外，还需同步当前策略、观察队列、Python 完成记录校验、能力指引及生产者；保留 pending、done、原发送票和账本。面板同步 `autonomy_intents_panel.py`、服务程序和 HTML；服务程序被两个角色共用时，API 与静态服务均需按精确身份重载并各自回验新脚本指纹。计划库由主 agent 的工具创建，控制台只读，缺库不补造计划或改写状态。

意图库首次创建后，后续维护的一致备份必须纳入 `autonomy-intents.sqlite3`，不能沿用创建前的固定数据库数量。普通文件与各库分别备份不等于跨文件全局原子快照；收集期间发生的队列变化须在凭据中保留。

## 修改在哪里生效

公开源码、`napcat/` 运行副本与 DSH profile 中的插件可能处在不同版本。排查前分别记录源码 HEAD、运行文件内容与进程启动时间、插件实际加载位置与版本。磁盘文件变了，不代表常驻进程已经加载新代码。

修复应先落到源码和离线测试。部署时运行安装器，把已验证的程序同步到运行位置，然后有针对性地重启受影响的进程。不要在实际运行的身份配置中做“脱敏”；脱敏目标是准备公开的副本。

`auto-update.ps1` 跟随当前分支已配置的远端 upstream，不固定比较 `origin/main`。它明确拒绝脏工作树、分离 HEAD、缺失 upstream、拉取失败及分叉；本地领先不视为有更新。fetch 后重新核对分支、HEAD、upstream 与工作树，再以固定取得的 commit 做 fast-forward，拒绝覆盖本地 ignored 文件。只更新源码和刷新快照，不调用安装器、不更新 profile 插件、不重启进程；自动更新日志不能替代部署记录。

## 按症状排查

| 症状 | 先检查 |
|---|---|
| 页面打开但空白 | 浏览器控制台、19389 API、`lanya-panel.html` 与 CSS 是否来自同一版本 |
| 旧界面仍显示 | 是否访问正确工作区/端口；浏览器缓存；常驻面板是否已重启 |
| QQ 不回复 | NapCat 登录和注入、OneBot 端口/token、插件准入、实际 bot/group 配置 |
| 群监听不工作 | 单实例是否存活、日志时间、时间窗口/频率上限、群历史是否在变 |
| 自主活动停了 | 负责 Mind 的调度、观察原件/完成链、当前自主周期、真实复查时刻；新版预算的预留、未知项与运行门控证据 |
| 保存提示成功但值没变 | POST 前后读回；目标文件是否正确；重启后是否又被后台覆盖 |
| 重复消息或重复作业 | 重复监听、调度职责、旧任务、插件分段补丁是否被升级覆盖 |
| 表情页为空 | 当前数据目录、来源路径、图片实际文件和分类结果 |
| B 站无记录 | 登录状态、工具环境、判重表、外部调用结果；不要用公开发评论作为默认探活 |

DSH 的 19387 与角色控制台不是同一服务。不要为了重启面板结束所有 Node、Python 或 PowerShell 进程；先按端口、脚本路径和所属 profile 精确定位。

部署后的 `napcat/lanya-ctl.ps1 status` 提供只读状态入口，查看端口、计划任务与调度标记年龄；`logs` 会输出本机日志尾部，内容可能包含私人上下文。`start` / `stop` / `restart` 操作已有任务，属于运行状态变更，不能混入纯检查。

## 统一自主设置与费用

自主周期用 `/api/autonomy/settings` 读取和保存实际 `mind.opportunityMin`，范围为 2—60 分钟。先读取 revision，再保存当前字段；冲突时重新读取，不自动覆盖。页面展示的群观察 quiet/poll 是启动配置，不能据此宣称常驻观察器已重载。改周期不改既有复查，不清队列，也不解除静默。

新版 `/api/budget` 使用 `unified-budget/v2`，币种 CNY，分别展示自主、私聊、群聊的已计费用、预留与未知项。记账依据 `owner_confirmed_numeric_cny_estimate` 表示所有者确认将成本估算的原数值直接按元管理，不作汇率换算；不表示已核实供应商扣款。配置在角色目录的 `autonomy-budget.json`，记录在 `autonomy-budget.sqlite`；保留两者的一致性备份。排查时先核覆盖起点、原生计价回执和运行门控是否新鲜，不能把未起算、接口错误或未知费用看作零花费。额度为 0 表示不限，预留必须大于 0；原生轮次结束后才结算，轮次内多次调用及必要控制判断可能继续产生费用，动作前检查不逐个截断 provider 请求，不能将此功能当作服务商硬限额。

响应中的 `daily_spending` 是当前可信会话映射的原生费用日统计，`gate_usage` 是接入预算门控后的执行用量。页面的今日花销、日期明细和 14／30 日柱状图使用前者；预留、额度剩余与生效状态使用后者。二者覆盖范围不同，不能相加或互相替代。缺少原生来源、成本插件、计价记录或归属证据时显示待核算；不要根据会话名称、看视频次数或总额差值补分类。跨日自动跟随北京时间当天，手动选择的日期在刷新时保留。

零花钱页面、可信主 agent 预算上下文、配置与 API 使用同一人民币单位。例如原估值 0.9 直接显示 0.9 元，日限额 5 直接保存为 5 元，不能再额外乘除 7.2。每日费用使用 `daily-spending/v2`，明确估值来源与记账依据；只接受当前 CNY 协议，单位不明的响应不能覆盖成功记录。成本插件的展示币种不能作为报价币种的证明，默认价表也不代表渠道真实报价。

页面保存时，未编辑的字段复用原始金额精度；正限额不足一个人民币微单位必须拒绝，不能变成 0 不限额。`reserve_cny=0.05` 直接显示 0.05 元。修改上限不会清掉当天已花、预留或未知费用。升级须先备份原配置和一致性账本，暂停旧适配器写入，经明确的一次迁移后协调加载新程序；保留逐行金额与回执，不能把未知项补为零或让旧单位回执继续写入新协议。原始成本插件账本及全账号价格配置不在此次单位修正中改写。

原迁移 API 由已部署 `budget_runtime.py --migration-preview` 提供只读配置版本、完整账目摘要与指纹，通过 `--migrate-cny FRESH_FINGERPRINT --migration-archive NEW_PRIVATE_DIRECTORY` 显式执行。它只接受本批已审定的 v1 配置和 DELETE 日志模式，其他设置或 WAL 模式先拒绝；迁移后为 CNY v2，不对已迁移配置重复执行。成功保留原配置物理原件、完整权限、SQLite 一致副本与一次性意图。

Windows 上源目录与受保护备份目录的继承权限可能不同，直接在备份目录复制会触发完整权限不一致拒绝。此时使用随源码提供的 [Windows 迁移维护工具](../scripts/migrate-cny-windows.py)，从仓库根目录先运行 `python -B scripts/migrate-cny-windows.py --help`。工具固定核验本批 `budget_runtime.py`、`panel_autonomy.py` 与 `project_conf.py` 的内容；不兼容其他版本，也不替代安装、看护管理或宿主重载。

默认只读预览必须明确给出 `--runtime`、`--workdir` 与 `--project-config`。正式执行前，独立核验主宿主已经退出，并在维护窗口阻止自动拉起；保留原看护的身份和恢复方式。用新预览的 `--fingerprint`，另给两个尚不存在、互不包含且与配置同卷的私有目录 `--archive` 和 `--evidence-dir`，其父目录须已存在并预先设置受限权限；再给 `--apply --confirm-main-stopped`。同时用 `--caller-file` 和 `--expected-caller-sha256` 绑定实际调用文件；直接执行本工具时可绑定工具自身，以 `Get-FileHash -Algorithm SHA256` 读取并转为小写。停机确认参数只记录操作者确认，工具本身不证明进程已经停止。

Windows 工具仅在本次调用内接管配置候选与数据库备份的两次权限复制：先在各自源目录创建临时文件，使用原完整权限复制函数严格核验，再同卷移动至受保护私有目录。原迁移 API、SQL、配置实体校验与金额不变校验保持，原始权限函数在退出时恢复；执行证据明确记录此接管，不修改全局权限策略。失败、响应未知或目录已存在时保留所有原件与阶段证据，读取实际配置、数据库和意图判断进度，不自动重试、不删除备份后重跑，也不把失败回执改成成功。

旧 `activities.json`、`budget.json` 和娱乐体检 `audit_fun.py` 已退出当前管理流程。旧文件原件保留，新安装不生成旧活动模板；旧活动、群频率和 topup 写 API 已退役。不要通过改旧文件、删除未知预留或重新提交旧观察“恢复娱乐”。程序复制、外部适配器更新、宿主加载与真实费用验收要分别留证，不能仅凭页面保存成功宣称门控已运行。

## 离线检查

从源码仓库根目录运行：

```powershell
python -B scripts/fullcheck.py --quiet
python -B -m unittest discover -s tests -p 'test_*.py'
node --test tests/test_*.mjs
node --check plugin/lib/index.js
npm pack --dry-run --ignore-scripts
python -B scripts/privacy-scan.py
git diff --check
```

`fullcheck` 必须报告实际扫描文件数；0 个文件应视为失败。它覆盖语法和常见静态问题，不证明外部服务、消息发送或浏览器界面正常。PowerShell 5.1 脚本需要保持纯 ASCII，涉及中文时用显式 Unicode 转义或外部 UTF-8 文本。

`tests/test_install.py` 在临时目录验证安装映射、`-WhatIf`、升级保护与旧配置；不会启动守护或连接 QQ/B 站。其他离线回归以测试代码为准，新增测试应使用隔离配置，不读取本机身份和私人记忆。

## 在线与浏览器验证

`tests/post_audit.py`、`tests/effect_test.mjs` 等历史交互脚本会写状态、保存配置或触发真实按钮。先阅读脚本、指定测试工作区，再运行，不能把它们当纯只读健康检查。`tests/test_memory_crud.mjs` 已改为隔离 API fixture，不再启动浏览器增删真实记忆；上方 Node 命令只选择 `test_*.mjs`，不要随意扩大为整个 tests 目录。

界面验证至少确认页面可显示、按钮能操作，以及保存后读回的数据发生预期变化。API 返回 200 或 `ok: true` 只是其中一步。不要为了验证路径而向真实 QQ/B 站账号随意发测试内容。

审计工具如 `audit_qq.py` 可能读取本机配置并查询外部服务；输出可能包含账号、群、路径或上下文。运行前确认当前目标，公开报告只保留规则名、脱敏路径、计数和必要错误信息。

## 安全升级

记忆合并、压缩与恢复的范围要求、事务批次及调用方兼容边界见 [记忆维护](MEMORY.md)。不能将未经范围接入的旧面板直接连接到新的维护写入口。

升级前备份本机配置、角色数据、记忆数据库和账号凭证，记录恢复方式。检查仓库工作区是否有本地修改，不用强制覆盖来解决 Git 冲突。部署操作见[安装与升级](INSTALL.md)。

`-Force` 保护已有本机配置和人设，但会更新程序、前端和提示词；提示词也是行为的一部分，升级前需要看差异。安装器不会替你判断外部插件版本是否兼容。

`dsh-onebot-qq` 的历史 `MAX_PIECES` 补丁位于它自己的 `node_modules` 中，升级该插件可能覆盖。见[补丁记录](PATCH-qq-burst.md)；修改后需要重启 DSH。不要把历史补丁说明当成当前外部插件已经自带该能力的证明。

## 可逆工作区归档

`scripts/workspace_archive.py` 按人工核查的 JSON 计划归档工作区顶层文件或目录。先核对进程、任务、启动项、profile 和代码引用，把全部活动及兼容目录列入 `protected_roots`；不改活动路径，不用归档整理代替服务迁移。计划中的 `approved` 只是该项通过审核，不代表已经移动。

计划文件中的路径均相对于 `--workspace`，不能用绝对路径或 `..`。`destination` 和 `manifest` 必须位于 `archive_root` 下。根 README、AGENTS 和 `.git` 始终受保护。下面是通用示例，实际使用前替换条目并逐项核查；未标记为 `approved` 的项会跳过。

```json
{
  "version": 1,
  "archive_root": "maintenance/workspace-archive/example-batch",
  "manifest": "maintenance/workspace-archive/example-batch/manifest.json",
  "protected_roots": [
    "repository", "runtime", "data", "voice", "android", "maintenance"
  ],
  "items": [
    {
      "source": "old-repository",
      "destination": "maintenance/workspace-archive/example-batch/repositories/old-repository",
      "status": "approved"
    },
    {
      "source": "inactive-index-copy.db",
      "destination": "maintenance/workspace-archive/example-batch/snapshots/inactive-index-copy.db",
      "status": "approved",
      "database_inactive": true
    },
    {
      "source": "bili-qr.png",
      "destination": "maintenance/workspace-archive/example-batch/images/bili-qr.png",
      "status": "approved",
      "reviewed_root_copy": true
    }
  ]
}
```

`database_inactive: true` 仅用于已确认停用、没有活动引用的数据库副本，不能把它当成停止数据库或生成一致性备份的开关。活动数据库及其锁、WAL、SHM 文件不在此流程中搬迁。根目录 `bili-qr.png` 需要额外的 `reviewed_root_copy: true`：只有核实它是历史副本、活动登录二维码另在原位时才填写；这不授权移动运行目录中的二维码。

从源码仓库根目录运行；示例假定工作区是仓库的上级目录，计划存放在工作区的 `maintenance/archive-plan.json`：

```powershell
# 默认只预览和校验，不移动文件、不写归档 manifest
python -B scripts/workspace_archive.py --workspace .. --plan maintenance/archive-plan.json

# 核对预览后，显式执行归档
python -B scripts/workspace_archive.py --workspace .. --plan maintenance/archive-plan.json --apply

# 恢复默认也只预检：核对哈希和原位置冲突
python -B scripts/workspace_archive.py --workspace .. --restore maintenance/workspace-archive/example-batch/manifest.json

# 显式执行逆向恢复
python -B scripts/workspace_archive.py --workspace .. --restore maintenance/workspace-archive/example-batch/manifest.json --apply
```

工具使用同盘移动，不删除文件、不覆盖已有目标、不跟随符号链接或 Windows junction/reparse point；源路径和父路径不能是链接，子目录内的链接只记录自身元数据。保留整个历史 Git 目录，包括 `.git`、dirty 修改、ignored 和 untracked 文件，不做 reset、清理或同名去重；外置 Git worktree 需要另行迁移。

执行记录以 manifest 的状态、逐项结果和文件校验为准，不能用计划清单或一次预览宣称已完成。中断后先检查 manifest 和实际位置；恢复会拒绝原位置冲突或内容变化，不要删除冲突文件来强行继续。恢复后保留 manifest 和空归档目录作为记录。归档里的历史脚本可能仍写死旧路径，先按记录恢复其依赖再运行。

配置、账号和凭据备份只保存在受保护的本机归档，不能进入公开仓库、打包产物或面板可访问的作品目录。manifest 也可能包含真实路径、文件名和 Git 状态，不直接作为公开维护报告。

## B 站主 agent 补丁

当前主 agent 桥接的 V2 增量保留原私信账本并为评论增加同目标未决保护；缺少明确的 `bilibili.social.comment/reply/mentionAdmin` 布尔授权时关闭对应写入。公开 `config/project.json` 是默认关闭的示例，不能整份覆盖运行项目配置。管理员 B站身份仍在私有 `lanya-config.json` 的 `adminBiliUid`，发送时按真实账号名建立提及映射。

已有 V1 安装需用新版预览与受控迁移，同时处理 index、bridge、配置及 marker；不能只换程序后留下旧 after 指纹。`patch_bili_content.py` 仅针对审定 MCP 原件生成候选及两个 helper，不安装、不读取凭据。当前运行 MCP 与插件 vendor MCP 应分别核对原件，再安装同批 helper；`autonomy_observers.py` 也依赖同目录的 `bili_social_backend.py`。重载后需要确认旧 MCP 子进程退出、新工具 schema 和实际使用的 MCP 路径，磁盘文件变更不是加载证据。

维护备份须按现状纳入已有 B站动作账本及意图库，不假定固定数据库数量；V1 私信记录不得删改或凭空猜成新评论目标。未知评论写入不能用新调用号或改字重发；没有确定回执不标成功，默认探活只读元数据及真实自然调用。

`scripts/patch_bili_main_agent.py` 只支持已审阅的 `dsh-bili-scroll 2.2.0` 文件哈希与 direct MCP client。它按精确锚点修改 index，新增一个 bridge 和仅含 project/ledger 路径的配置；保留其余本机定制，不覆盖整包，不读取凭据。未知版本、文件变化或不完整旧补丁会拒绝。

以下路径是占位值，需改为已确认的绝对私有路径；project 应与同一角色的其他执行器共用，SQLite 账本按 B 站账号独立且不能复用记忆库或 QQ policy JSON：

```powershell
python -B scripts/patch_bili_main_agent.py --plugin-dir ABSOLUTE_BILI_PACKAGE --project-config ABSOLUTE_PRIVATE_PROJECT_JSON --ledger-file ABSOLUTE_PRIVATE_BILI_ACTIONS_SQLITE

# 停止相关宿主后，使用刚取得的预览指纹和新的私有备份目录
python -B scripts/patch_bili_main_agent.py --plugin-dir ABSOLUTE_BILI_PACKAGE --project-config ABSOLUTE_PRIVATE_PROJECT_JSON --ledger-file ABSOLUTE_PRIVATE_BILI_ACTIONS_SQLITE --apply --host-stopped --expected-fingerprint PREVIEW_FINGERPRINT --backup-dir ABSOLUTE_PRIVATE_BACKUP_DIRECTORY

# 恢复同样默认只预检，再显式执行
python -B scripts/patch_bili_main_agent.py --plugin-dir ABSOLUTE_BILI_PACKAGE --restore-manifest ABSOLUTE_PRIVATE_BACKUP_PATCH_JSON
python -B scripts/patch_bili_main_agent.py --plugin-dir ABSOLUTE_BILI_PACKAGE --restore-manifest ABSOLUTE_PRIVATE_BACKUP_PATCH_JSON --apply --host-stopped --expected-fingerprint RESTORE_PREVIEW_FINGERPRINT
```

`--host-stopped` 是操作者前提，不是工具自动证明。应用前绑定包、MCP client、当前文件身份和输出哈希；替换使用新文件，切断可能的 HardLink。多文件写入不具备整批原子性，故障时保留私有原件与记录，先重新预检恢复。恢复只接受原件 before/after 和生成件 after 的已知状态；任一后续修改先整批拒绝，不覆盖新定制。恢复不删除 project、凭据、私信执行账本或观察队列；private backup 也必须继续保留。

补丁加载后仍需核对主 agent 工具可见性、统一调度所有者和实际 MCP 能力。推荐与详情只读；发送结果须有回执。模型和真实平台验收应另行安排，不能以离线 fixture 声称已经对外投递。

## 原生 memento 历史补丁

`scripts/patch_memento_history.py` 针对已审阅的 memento 0.5.23 generic store/protocol 及依赖哈希。顺序是先应用可见性补丁，再预览原生历史补丁；撤回必须先移除后加的会话范围层，再历史、后可见性。未知形状或不完整补丁会拒绝，不整包替换、不访问记忆库。测试用原生代码保留 Apache-2.0 LICENSE 和第三方声明。

```powershell
# 对已完成 visibility 补丁的包预览
python -B scripts/patch_memento_history.py --package-root ABSOLUTE_MEMENTO_PACKAGE

# 停止对应宿主与 writer 后，使用新私有备份及本次预览指纹
python -B scripts/patch_memento_history.py --package-root ABSOLUTE_MEMENTO_PACKAGE --apply --host-stopped --expected-fingerprint PREVIEW_FINGERPRINT --backup-dir ABSOLUTE_PRIVATE_BACKUP_DIRECTORY

# 仅撤回程序补丁：先预检，再显式执行
python -B scripts/patch_memento_history.py --package-root ABSOLUTE_MEMENTO_PACKAGE --restore-manifest ABSOLUTE_PRIVATE_PATCH_JSON
python -B scripts/patch_memento_history.py --package-root ABSOLUTE_MEMENTO_PACKAGE --restore-manifest ABSOLUTE_PRIVATE_PATCH_JSON --apply --host-stopped --expected-fingerprint RESTORE_PREVIEW_FINGERPRINT
```

两个补丁共享 OS 文件锁，排除同时操作同一包的维护进程；锁文件保留，不按 PID/时间删除。host-stopped 仍是操作者断言。应用保存完整私有原件，以新 inode 替换文件，保护共享 HardLink 源。多文件应用不是整批原子操作；中断后使用其 prepared manifest 重新预检，已知 before/after 的部分状态可恢复，任何后续编辑先整批拒绝。程序撤回保留数据库及全部 native history，不自动恢复事实；事实恢复单独按 [MEMORY](MEMORY.md#原生历史恢复) 执行。

## 原生会话历史范围补丁

`scripts/patch_memento_recall_scope.py` 是 memento 0.5.23 的独立增量层。它要求可见性与原生事实历史两层已完整匹配，只改 `index.mjs` 并新增 `lib/lanya-memento-recall-scope.mjs`，不访问事实库或真实会话服务。缺少可信当前 session/cwd、preset 不一致或继承边界无效时，历史原文不返回；长期事实查询不受此限制，详见 [MEMORY](MEMORY.md#会话原文与长期事实分开核验)。

```powershell
# 只读预览；未知版本、旧层变化或后续修改拒绝
python -B scripts/patch_memento_recall_scope.py --package-root ABSOLUTE_MEMENTO_PACKAGE

# 停止对应宿主，核对新的 preview fingerprint 后执行
python -B scripts/patch_memento_recall_scope.py --package-root ABSOLUTE_MEMENTO_PACKAGE --apply --host-stopped --expected-fingerprint PREVIEW_FINGERPRINT --backup-dir ABSOLUTE_PRIVATE_BACKUP_DIRECTORY

# 撤回顺序：本范围层 → 原生事实历史层 → 可见性层
python -B scripts/patch_memento_recall_scope.py --package-root ABSOLUTE_MEMENTO_PACKAGE --restore-manifest ABSOLUTE_RECALL_SCOPE_PATCH_JSON
python -B scripts/patch_memento_recall_scope.py --package-root ABSOLUTE_MEMENTO_PACKAGE --restore-manifest ABSOLUTE_RECALL_SCOPE_PATCH_JSON --apply --host-stopped --expected-fingerprint RESTORE_PREVIEW_FINGERPRINT
```

同包共享 OS 锁；保存完整私有原件、生成模块与 prepared manifest，新 inode 替换保护 HardLink 源。中断后先按 prepared manifest 做整批恢复预检，不假定多文件替换原子完成，不覆盖后续修改或回滚记忆数据。`--host-stopped` 只声明对应宿主已停，不表示其他面板或数据库 writer 都已停止。

## OneBot 离线 replay 隔离补丁

`scripts/patch_onebot_replay.py` 是 `lanya-onebot-replay-isolation-v1` 独立增量层，针对已完成 policy V1 的已审阅 OneBot 0.8.1。它校验原 V1 私有 manifest、原件、安装 marker、生成模块和当前文件身份，只修改 `lib/bridge.js`、`lib/replay.js`、`lib/inbound.js`，不改原 V1 marker。未知版本、后续修改、生成模块漂移或不完整状态先拒绝。

```powershell
# 默认只读预览；POLICY_V1_PATCH_JSON 是原 policy 补丁的私有 patch.json
python -B scripts/patch_onebot_replay.py --plugin-dir ABSOLUTE_ONEBOT_PACKAGE --policy-manifest ABSOLUTE_POLICY_V1_PATCH_JSON

# 停止对应宿主后，使用刚取得的指纹和新的私有备份目录
python -B scripts/patch_onebot_replay.py --plugin-dir ABSOLUTE_ONEBOT_PACKAGE --policy-manifest ABSOLUTE_POLICY_V1_PATCH_JSON --apply --host-stopped --expected-fingerprint PREVIEW_FINGERPRINT --backup-dir ABSOLUTE_PRIVATE_BACKUP_DIRECTORY

# 若存在 images 层，先撤 images 与内容出口层；然后撤 replay，最后才可撤原 policy V1
python -B scripts/patch_onebot_replay.py --plugin-dir ABSOLUTE_ONEBOT_PACKAGE --restore-manifest ABSOLUTE_REPLAY_BACKUP_PATCH_JSON
python -B scripts/patch_onebot_replay.py --plugin-dir ABSOLUTE_ONEBOT_PACKAGE --restore-manifest ABSOLUTE_REPLAY_BACKUP_PATCH_JSON --apply --host-stopped --expected-fingerprint RESTORE_PREVIEW_FINGERPRINT
```

`--host-stopped` 是操作者断言；工具不启动或停止宿主。私有备份不得放进公开源码或安装包。应用和恢复使用包内 OS 文件锁、全批预检、逐项身份重查与最终整批读回；新 inode 替换切断 HardLink。多文件写入不是整批原子事务，中断时保留 prepared manifest 和完整原件；用该层自己的 `--restore-manifest` 预检已知 before/after 的部分状态，任何未知后续修改都拒绝覆盖。锁文件保留，不按 PID 或时间删除。恢复只改程序及该层 marker，不读取或删除生产 policy、队列、会话与记忆。

隔离后的 replay 保留操作员明确选择的录制输入与报告输出；这两条路径仍是显式文件操作，勿指向生产状态文件。bridge 构造前改用新建临时目录，不读默认 policy 配置、不认领 inbox、不调用记忆/能力 helper，不下载媒体或写本机跨聊日志。录制 agent 只记录 followup；真实注入仍标记为非 live，不借诊断入口取得控制权限。离线回放通过只证明解析与隔离，不能替代已加载主 agent 的真实静默/恢复验收。测试中的原 replay 模块保留原包 BSD 3-Clause LICENSE。

## OneBot 内容出口补丁

`scripts/patch_onebot_egress.py` 是 OneBot 0.8.1 的独立增量层，要求 policy V1 与 replay 隔离层的私有 manifest、原件、安装 marker 和当前文件一致。它修改 `lib/bridge.js`、`lib/outbound.js`、`lib/lanya-policy-adapter.js`，新增 `lib/lanya-qq-egress.js`，不改旧层的源码或 marker。未知版本、父层变化和不完整状态拒绝。

```powershell
# 默认只预览；使用上一层 replay 的私有 patch.json
python -B scripts/patch_onebot_egress.py --plugin-dir ABSOLUTE_ONEBOT_PACKAGE --replay-manifest ABSOLUTE_REPLAY_PATCH_JSON

# 对应宿主停止后，绑定本次指纹和新的私有备份目录
python -B scripts/patch_onebot_egress.py --plugin-dir ABSOLUTE_ONEBOT_PACKAGE --replay-manifest ABSOLUTE_REPLAY_PATCH_JSON --apply --host-stopped --expected-fingerprint PREVIEW_FINGERPRINT --backup-dir ABSOLUTE_PRIVATE_BACKUP_DIRECTORY

# 若有 images 增量，先撤该层；然后：内容出口层 → replay 隔离层 → policy V1
python -B scripts/patch_onebot_egress.py --plugin-dir ABSOLUTE_ONEBOT_PACKAGE --restore-manifest ABSOLUTE_EGRESS_PATCH_JSON
python -B scripts/patch_onebot_egress.py --plugin-dir ABSOLUTE_ONEBOT_PACKAGE --restore-manifest ABSOLUTE_EGRESS_PATCH_JSON --apply --host-stopped --expected-fingerprint RESTORE_PREVIEW_FINGERPRINT
```

普通消息、媒体说明和原始消息调用在最终出口校验相同的内容规则。普通叙述气泡最多 40 个 Unicode 字素，不拼接溢出内容，不用假图片文字占位；代码、完整链接、错误和明确步骤保留完整。角色扮演例外仅来自当前可信实时入站中的明确邀请，引用、旧历史或模型参数不能授予例外，详见 [决策协议](DECISIONS.md#qq-内容与许可分别校验)。

内容清理不授予发送许可。每个分段仍绑定原 turn/ticket 并重新校验；静默或版本变化停止余段，部分发送与未知结果分别保留，未知结果不自动重发。补丁器沿用包内 OS 锁、全批预检、新 inode 替换、私有原件与 prepared manifest；中断后按该层记录预检恢复，不覆盖后续编辑或回滚生产 policy、队列及记忆。`--host-stopped` 不表示所有工作区 writer 都已停止。测试中的上游原生代码保留 BSD 3-Clause LICENSE 与来源哈希。

## OneBot 伪图解析增量层

旧内容模块遇到 URL 中的平衡圆括号会过早结束 Markdown 图片匹配，留下 `.png)` 一类尾部。修复整体移除完整单行 inline 图片，支持嵌套/转义圆括号、尖括号目标及双引号、单引号或圆括号标题；代码、可信技术上下文中的完整 JSON、普通链接和其余正文保留。未闭合、坏标题或跨行语法保守保留，不吞后续正文，也不生成假图片占位。

`scripts/patch_onebot_egress_images.py` 是独立的 `lanya-onebot-egress-images-v1` 层。它绑定已审阅 egress V1 私有 manifest 及其父链，只替换 `lib/lanya-qq-egress.js`，新增 `lib/lanya-egress-images.patch.json`；旧层 marker 原样保留。旧 V1 检查只兼容明确审阅过的旧模块哈希，不接受任意漂移。新装 V1 若已记录当前 canonical 模块且没有 images 层，预览返回 `not_needed`、`applied=false`，不创建备份或 marker。

```powershell
# 默认预览；父 manifest 是现有 egress V1 的私有 patch.json
python -B scripts/patch_onebot_egress_images.py --plugin-dir ABSOLUTE_ONEBOT_PACKAGE --egress-manifest ABSOLUTE_EGRESS_PATCH_JSON

# 对应宿主已停止，使用本次预览指纹及新的私有备份根
python -B scripts/patch_onebot_egress_images.py --plugin-dir ABSOLUTE_ONEBOT_PACKAGE --egress-manifest ABSOLUTE_EGRESS_PATCH_JSON --apply --host-stopped --expected-fingerprint PREVIEW_FINGERPRINT --backup-dir ABSOLUTE_PRIVATE_BACKUP_DIRECTORY

# 先撤 images，再撤 egress → replay → policy；先预检，再显式执行
python -B scripts/patch_onebot_egress_images.py --plugin-dir ABSOLUTE_ONEBOT_PACKAGE --restore-manifest ABSOLUTE_IMAGES_PATCH_JSON
python -B scripts/patch_onebot_egress_images.py --plugin-dir ABSOLUTE_ONEBOT_PACKAGE --restore-manifest ABSOLUTE_IMAGES_PATCH_JSON --apply --host-stopped --expected-fingerprint RESTORE_PREVIEW_FINGERPRINT
```

`--host-stopped` 仍是操作者断言，不会停止进程或证明全工作区停写；应用和恢复都要 fresh 指纹。私有备份须在公开源码与安装包之外，保留原模块、哈希和本层 manifest；中断后的部分状态先按该层 manifest 预检恢复，未知父层或后续编辑拒绝覆盖。替换使用新 inode，避免改写 HardLink 共享原件。恢复仅撤本层程序与 marker，不倒回 policy、队列、会话或记忆。源码及隔离验证不代表运行实例已经升级，也不代替真实 QQ 格式或媒体验收。

## QQ 表情选图补丁

`scripts/patch_meme_qq_picker.py` 仅支持已审阅文件哈希的 `dsh-meme 0.1.47` 与 `dsh-onebot-qq 0.8.1`。OneBot 必须已完整安装 autonomy V1、continuity 及其 policy V1、replay、egress、images 父链，原私有 manifest、原件、marker 与当前程序均须通过核验；只有版本号相同不够，未知定制不能整包覆盖。

本层只改四个程序：meme 包的 `index.js`、`memes.js`、新增 `lanya-qq-meme.mjs`，以及 OneBot 包的 `lib/bridge.js`；另写本层 `.lanya-qq-picker.patch.json` 标记。它不改图库、设置、角色数据或发送策略。以下均是绝对路径占位值，从源码仓库运行；沿用创建父层维护记录时的 Python 解释器，不能编辑旧 manifest 绕过文件身份差异。

```powershell
# 默认只读预览；工具不寻找默认安装位置
python -B scripts/patch_meme_qq_picker.py --meme-dir ABSOLUTE_MEME_PACKAGE --onebot-dir ABSOLUTE_ONEBOT_PACKAGE

# 先停止对应宿主，再取 fresh preview fingerprint；备份放在源码和两个包之外
python -B scripts/patch_meme_qq_picker.py --meme-dir ABSOLUTE_MEME_PACKAGE --onebot-dir ABSOLUTE_ONEBOT_PACKAGE --apply --host-stopped --expected-fingerprint PREVIEW_FINGERPRINT --backup-dir ABSOLUTE_PRIVATE_BACKUP_DIRECTORY

# 恢复默认只预检；使用本层实际返回的私有 patch.json
python -B scripts/patch_meme_qq_picker.py --meme-dir ABSOLUTE_MEME_PACKAGE --onebot-dir ABSOLUTE_ONEBOT_PACKAGE --restore-manifest ABSOLUTE_PICKER_PATCH_JSON
python -B scripts/patch_meme_qq_picker.py --meme-dir ABSOLUTE_MEME_PACKAGE --onebot-dir ABSOLUTE_ONEBOT_PACKAGE --restore-manifest ABSOLUTE_PICKER_PATCH_JSON --apply --host-stopped --expected-fingerprint RESTORE_PREVIEW_FINGERPRINT
```

`--host-stopped` 是操作者断言，不会停止或重启进程；应用和恢复都要求新指纹。两包 OS 锁、完整私有原件和生成副本须保留。bridge 替换前另保留包内同卷实体原件槽位，恢复时用它归回原 inode，再实际复核旧父层；私有字节副本不能代替这个实体槽位。不要清理槽位或锁文件。多文件替换不是整批原子事务，中断后只用本层 manifest 预检已知 before/after 状态，未知修改、原件缺失或身份变化先拒绝，不覆盖后续定制。

升级已安装的旧 helper 时，先停宿主，用**旧层自己的 manifest** 完成恢复并确认旧 bridge 原身份及父链通过；再用新源码重新 preview、fresh fingerprint 和新的私有备份执行 apply。恢复从私有生成副本核验 helper，不依赖当前源码仍为旧版本；不能直接覆盖已安装 helper、重写旧 manifest，或把旧指纹用于新版本。最后读回四文件与标记，并单独重载、核对实际加载版本。

QQ 中 `send_meme` 只选图，参数是 `query`、`tag`、`limit`（1–20，默认 8），不加 `action` 或任意文件路径。例如：

```json
{"query":"开心","tag":"happy","limit":3}
```

`mode=qq_selection` 返回受控媒体目录中的真实候选路径，`selected` 不等于已发送，`delivered` 仍为 `false`。caption 为空或 `requires_visual_review=true` 时，先用实际可用的图片读取工具查看原图，不能把标签或来源记录编成描述。需要发图时，仍须本轮 `qq_decide(reply)` 的有效许可，再调用 `qq_send_image({sources:[candidate.path]})`；选图不解除静默，也不授权重试未知发送。无图就不发，不写占位表情文字。无 QQ capability 的 Web 选图行为保留。

轻松对话优先考虑真实表情，可只发图片；普通情绪可先用 `happy`、`angry`、`sad`、`shy`、`confused`、`daily` 情绪桶，不必要求关键词精确匹配描述。关键词结果不适合时，最多再作一次情绪选图，不能反复挑图制造活跃。已有本轮有效 reply 票时直接复用；工具回执中的“先决策”表示确保许可，不表示重复调用 `qq_decide`。这些是每轮重新读取的表达偏好，不是固定图片配额，也不代替真实图片读取、最终发送保护或自然使用验收。

本机维护的 746 张图库是私有资产，不随仓库或 npm 包分发；安装补丁不会下载、识图或自动补齐素材。其他环境需独立准备并启用可信索引图库。只从已启用索引中读取真实常规图片，拒绝越界、链接和非法格式；受支持图片即使旧扩展名不符，转存后缀也按真实文件头确定，原图不修改。离线选图和模拟媒体回执不代表真实 QQ 客户端已经收到或正确显示图片。

## QQ 内部活动引用与气泡拆分

`patch_onebot_egress_activity.py` 是已审定历史 images 模块与完整 QQ 选图父链上的单模块后继，只替换 OneBot 的 `lib/lanya-qq-egress.js` 并新增本层 marker。它不改旧 manifest、bridge、策略、会话或图库。它只接受精确旧字节及完整父层；其他已定制或不同版本先拒绝，不能用直接覆盖模块代替核验。

默认只读 preview，显式提供两个包根与当前选图层私有 manifest：

```powershell
python -B scripts/patch_onebot_egress_activity.py --meme-dir $memePlugin --onebot-dir $onebotPlugin --picker-manifest $pickerManifest
```

应用追加 `--apply --host-stopped --expected-fingerprint <本次指纹> --backup-dir <包及源码外的私有目录>`。`--host-stopped` 是操作者断言；工具不会替你停止宿主。恢复先用 `--restore-manifest <本层patch.json>` 预检，再追加 apply、host-stopped 和新的恢复指纹。恢复从本层私有生成副本核验，不要求当前源码仍是已安装版本；先撤本层，才撤父层。

保存本层私有原件、生成副本及包内同卷实体原件槽。原 inode 用于恢复后真实核验旧父层，不能删槽位、篡改 marker 或把相同字节的新文件当作原件。未知后续修改、中断与身份不匹配先停下核对，不自动覆盖或重试。

普通 QQ 主动输出会去掉内部 `notes/activity*.md` 引用，并清理仅剩的连接语；用户当前明确索要文件或路径时保留完整路径，代码、普通文件及公网链接不受此清理影响。40 字只是普通气泡偏好，完整英文词不硬截；不重新设固定句数或总条数。日常逐步游戏进度由主 LLM 留在活动笔记，有意义内容是否分享仍由它判断，静默与发送票继续生效。能力说明在每次派发时重新读取；egress 模块变更需单独重载宿主并验证实际加载。

## 面板记录与刷新

页面优先读取同源 `/api`，失败后尝试默认 API 服务；只有传输或 HTTP 失败时才使用离线快照。快照须有 `_snapshot.schema=1` 及 UTC `generated_at`，最长接受两分钟，并明确标示离线来源。接口返回的业务错误不被旧成功快照掩盖。`make_snapshots.py` 对成功来源同目录暂存后原子替换；失败保留上次完整内容和原时间，不能通过改时间把旧记录变新。

可见页每十五秒检查记录，回到页面时再次读取；后台隐藏页暂停。自动刷新保护未保存表单、记忆范围、搜索、展开、选中及作品预览；相同目录文件列表和图库没有变化时不重绘。手动刷新按钮和当前页记录时间独立于部件状态时间，读取失败明确保留过时状态。

`scripts/panel_activity.py` 只读验证当前 OneBot 映射、原生会话版本 4 header、工作区、preset、继承边界及调用／结果配对，输出白名单字段。默认读取 DSH home 下的 `media/onebot/chat-sessions.json`；自定义位置通过可信 project 配置 `panelRecords.dshHome`、`panelRecords.onebotMappingFile` 指定绝对路径。HTTP 参数不能挑选其他身份或会话。记录限最近七天及有界当前会话，压缩文件需要本机已有 zstandard；不扫描目录猜最新、不重放事件、不输出聊天原文、原始参数或凭证。公共评论的正文由专用白名单投影，私信正文与接收人不输出。

`/api/bili` 的 `mainAgent` 与 `/api/live` 的 `recentActivity` 共享该读取器，历史值班原件和兼容字段仍独立保留，不进入当前页面。`mainAgent.recent_videos` 仅归并定向视频读取，不混入推荐候选或仅评论的目标；`replies` 展示评论尝试正文及接口状态，`accepted` 仅代表接口接受，公开可见性仍未核验，`unknown` 不当作发送成功。公共正文限 2000 字并标记截取，私信只给状态；兼容 `records` 不带回复正文，活动经过的 `episodes.evidence` 仅增加白名单公开评论。B 站页只展示当前主 agent 的近七天记录，不提供历史存档入口、值班编辑、手动娱乐检查或删除评论按钮；兼容 API 仍保留。`/api/works` 使用 `panel_record_files.py` 列出真实子目录入口；内部浏览器资料、缓存、依赖及归档目录不作为作品展示，遇到读取上限明确表示列表不完整。作品归档原件继续留在本机，当前页面不展示归档标签。嵌套作品通过受控相对 URL 打开，不传给仅支持平铺文件的旧删除入口。安装器自动包含这些 helper，更新服务程序时需一并复制，并核对 `/api/service-health` 的实际加载哈希；只复制 HTML 不会升级后台读取器。

## 活动经过与每日回顾

活动页的 `recentActivity.episodes` 按真实轮次展示经过；`decisions` 单独展示决策状态，不能把 idle 算成已进行娱乐。内容和证据只取白名单工具结果，来源未知时保留未知。B站作者与内容摘录来自实际结果，字幕只表示已读取文本，抽帧只表示取得画面；平台回复的接口接受仍不等于公开可见。

每日事实回顾由 `scripts/activity_journal.py` 维护，当前管理员与配置群的可信原生源按北京时间归日，独立于活动页近七天与显示条数。`GET /api/activity/journal` 只读列出本机生成记录，`?day=YYYY-MM-DD` 读取选日正文；HTTP 不能指定工作区、身份或文件路径。Mind 每轮优先更新当天，并最多追补一个未完成历史日，不增加模型调用。缺失、截取及当前映射限定均写入覆盖说明；日终仅是事实快照，不虚构完整经历或感受。

回顾保存在角色数据的 `activity-journal/` 专用归属目录，清单记录本工具创建的文件身份与内容。现有 `diary/`、笔记及陌生同名文件不覆盖；异常保留前次成功记录，不自动重发任何平台动作。读接口不生成文件，维护运行目录时同时保留正文、清单和恢复证据。安装器自动包含新 helper，部署后需一并更新 Mind、事实读取器、面板后台及页面，核对两个端口实际加载与新回顾的自然生成，不只检查源码。

## 提交与隐私

每批准备推送的更新必须有新的版本号，以根 `package.json` 为准，同时更新 README 当前版本、CHANGELOG 和 DEVLOG。开发预览从 `1.4.0-dev.1` 起逐批递增 `dev.N`，包括仅文档或修复更新；同批多个提交共用该批版本，已经推送的版本不再用于下一批改动。正式版本按兼容性递增 patch、minor 或 major。

```powershell
git status --short
git diff --stat
git diff --check
python -B scripts/privacy-scan.py
```

扫描范围是 Git 已跟踪文件与未被忽略的新文件。`BLOCK` 必须解决；`NOTE` 需要人工判断。可在未跟踪的 `privacy-terms.local.json` 中维护本机禁词，但不要公开其内容。没有本机词表时，只能说明内置规则没命中，不能声称“没有任何隐私”。

逐一检查身份配置、账号凭证、私人对话、角色记忆、日记、真实安装路径和截图。`.gitignore` 只防止误加，已经被 Git 跟踪的文件不会因为新规则自动消失。提交时显式选择文件，避免把运行数据与程序一起添加。

脱敏和删除针对公开副本及待推送内容，不删除或清空正在使用的本机配置、凭据和记忆。除当前文件外，还要检查本次待推送提交的新增内容、PR 说明和最终打包清单；检查报告只保留脱敏计数与结果。发现已公开的凭据须另外处理撤销／轮换和历史清理，不能仅靠删除当前文件宣称泄露已消除。

仓库没有提供 `sync_sanitize.py` 或 `verify_privacy.py`。它们在历史记录中出现过，不能作为新使用者必须依赖的步骤；当前提供的是 `scripts/privacy-scan.py`。从线上复制文件时，要自行核对映射与脱敏结果，再运行检查。

## 打包与发布

`package.json` 的入口是 `plugin/lib/index.js`，bundle patch 是根目录 `cordis.patch.yml`。打包白名单包括后台程序、前端、提示词、默认配置和公开说明，不包含历史完整 profile 示例。用 `npm pack --dry-run --ignore-scripts` 检查最终清单，不要仅检查 Git 中的目录是否存在。

每次开发更新都先对齐版本与日志，通过适当检查和隐私审阅后提交、推送开发分支，读回远端 commit 并同步现有 PR。版本号和推送不等于生产重载或正式发布；仅更新版本与文档无需重启业务服务。

正式发布另需对齐 `package.json` 版本、CHANGELOG、Git tag 和 GitHub Release。未完成正式验收时保留 `-dev.N` 开发版本，不为已推送源码伪造稳定版、tag 或 Release 状态。

发布流程：审核差异与隐私 → 离线检查 → 隔离安装/界面验证 → 确定版本与说明 → 创建对应提交和 tag → 推送 → 创建 Release → 用 GitHub API 或网页核对 commit、tag 和 Release。推送、发布和生产部署是独立动作，执行前要有对应授权。

2026-10-27 的公开状态核对曾发现：源码包版本为 1.3.7，最新 tag/Release 为 v1.3.6。这是一次历史检查结果，发布前应重新核对 [GitHub Releases](https://github.com/bamboosir1109/dsh-lanya/releases)；不要因为本地版本号较新就直接补发未经验证的版本。

## 回退记录

部署记录至少写明源码 commit、更新了哪些运行文件、DSH profile 插件版本、重启对象、验证结果和备份位置。本机备份位置与真实路径留在私有运维记录，不进公开文档。

回退程序用已验证的旧版本重新部署，再重启对应进程。数据回退单独决定；新版程序可能已经写入新的状态，不能只回退代码就假设数据库和配置也自动恢复。
