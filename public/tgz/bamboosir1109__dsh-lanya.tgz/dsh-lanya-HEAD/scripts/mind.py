# -*- coding: utf-8 -*-
"""她的脑子：有计划地过一段时间，而不是被随机数叫醒。

问题
----
现在的 `lifeloop` 是这样工作的：

```powershell
function Get-SleepPlan([int]$BaseMinutes) {
    $roll = Get-Random -Minimum 0 -Maximum 100      # ← 随机数
    ...
    return @{ Seconds = $secs; Mood = $mood }
}
```

**每次醒来都是一个全新的开始。** 上一轮干了什么、干到哪、下一步要干嘛——
全是空的。提示词只说「你有一段自己的时间，去干点有意思的事」。

于是她的行为永远是这个样子：

    醒来 -> 随便挑一件事 -> 做 -> 说一句 -> 睡 -> 忘掉 -> 再随机挑

**这不是自主，这是随机函数。**

真正像人的样子
--------------
人是有**连续的意图**的：

    "我刚才在查红山动物园那只狼，查到一半有人问我小说，
     我回了他一句，现在接着查。"

这件事拆开是三样东西：

1. **一个正在进行的计划**（查狼这件事）
2. **计划进行到哪了**（已经看过视频，还没写完笔记）
3. **期间被打断**（有人说话，处理完了，回到原计划）

所以这里维护一份 `mind.json`：

```json
{
  "plan": {"goal": "...", "step": "...", "progress": "...", "eta_min": 25},
  "interrupts": [{"at": "...", "who": "...", "text": "...", "seen": false}],
  "log": [{"at": "...", "did": "..."}],
  "mood": "..."
}
```

每一轮把这三样一起交给 agent，让它自己判断：

- 计划还做不做？
- 被打断了，要不要改计划？
- 还是干脆不做了，聊天去？

**下一觉睡多久，由她自己说**（输出 `ETA`），不再是 `Get-Random`。

用法
----
    python mind.py                 # 跑一轮
    python mind.py --dry           # 只看她怎么想的，不执行
    python mind.py --force         # 忽略 ETA，手动跑一轮（仍遵守单实例锁）
    python mind.py --hit "谁先说话的"   # 手动记一次打断（调试用）
"""
import io
import hashlib
from contextlib import contextmanager
import json
import os
import re
import subprocess
import sys
import time

from project_conf import data_dir, get, work_dir

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

WORK = work_dir()
DATA = data_dir()
RUNTIME = os.path.join(WORK, "napcat")
MIND = os.path.join(DATA, "mind.json")
MIND_LOG = os.path.join(RUNTIME, "mind.log")
HITFILE = os.path.join(RUNTIME, "mind-interrupts.json")
LOCKFILE = os.path.join(RUNTIME, "mind.lock")

# 没有明确 ETA 时的兜底节奏。不是随机——是一个固定的、短的检查间隔。
DEFAULT_CHECK_MIN = 6
MIN_CHECK_MIN = 2
MAX_CHECK_MIN = 60


def log(msg):
    line = "[%s] %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    try:
        with io.open(MIND_LOG, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:
        pass
    try:
        print(line)
    except Exception:
        pass


def load(p, default):
    if not os.path.isfile(p):
        return default
    try:
        with io.open(p, encoding="utf-8-sig") as fh:
            return json.load(fh)
    except Exception:
        return default


def save(p, data):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


def blank_mind():
    return {"plan": None, "interrupts": [], "log": [],
            "next_check_min": DEFAULT_CHECK_MIN, "mood": ""}


@contextmanager
def cycle_lock():
    """An OS lock is released on process exit, including crashes and timeouts."""
    os.makedirs(os.path.dirname(LOCKFILE), exist_ok=True)
    fh = open(LOCKFILE, "a+b")
    acquired = False
    try:
        if os.name == "nt":
            import msvcrt
            if os.fstat(fh.fileno()).st_size == 0:
                fh.write(b"\0")
                fh.flush()
            fh.seek(0)
            try:
                msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
                acquired = True
            except OSError:
                pass
        else:
            import fcntl
            try:
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                acquired = True
            except OSError:
                pass
        yield acquired
    finally:
        if acquired:
            if os.name == "nt":
                fh.seek(0)
                msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        fh.close()


def persona_path():
    name = os.path.basename(DATA) + "-\u4eba\u8bbe\u6b63\u6587.md"
    candidates = (os.path.join(RUNTIME, name),
                  os.path.join(RUNTIME, "persona.md"))
    return next((p for p in candidates if os.path.isfile(p)), candidates[0])


# ---------------------------------------------------------------------------
# 打断：谁在这段时间找过她
# ---------------------------------------------------------------------------
def acknowledge_interrupts(items):
    """Only remove the snapshot we handled; retain newer groupwatch entries."""
    if not items:
        return
    current = load(HITFILE, [])
    if isinstance(current, list) and current[:len(items)] == items:
        save(HITFILE, current[len(items):])


def push_interrupt(who, text):
    items = load(HITFILE, [])
    if not isinstance(items, list):
        items = []
    items.append({"at": time.strftime("%Y-%m-%d %H:%M:%S"),
                  "who": str(who or ""), "text": str(text or "")[:120]})
    save(HITFILE, items[-40:])


# ---------------------------------------------------------------------------
# 上下文
# ---------------------------------------------------------------------------
def persona_snippet(max_chars=700):
    p = persona_path()
    if os.path.isfile(p):
        try:
            with io.open(p, encoding="utf-8", errors="replace") as fh:
                return fh.read()[:max_chars]
        except Exception:
            pass
    return ""


def examples(max_n=10):
    p = persona_path()
    if not os.path.isfile(p):
        return ""
    out = []
    try:
        with io.open(p, encoding="utf-8", errors="replace") as fh:
            for ln in fh:
                t = ln.strip()
                if not t.startswith("\u2705"):
                    continue
                if any(k in t for k in ("\u274c", "\u7edd\u4e0d", "\u4e0d\u8bb8",
                                        "\u4e0d\u8981", "\u7981\u6b62")):
                    continue
                body = re.sub(r"^[\u2705\ufe0f\s]+", "", t)
                # Drop the surrounding quotes as a PAIR - stripping only the
                # leading one produced unbalanced "xxx\u300d" lines.
                body = body.strip()
                for op, cl in (("\u300c", "\u300d"), ("\u201c", "\u201d"),
                               ('"', '"'), ("'", "'")):
                    if body.startswith(op) and body.endswith(cl) and len(body) > 2:
                        body = body[1:-1]
                if not body:
                    continue
                # A line like 「A」「B」 is two examples glued together; taking it
                # whole leaves an unbalanced 」 in the middle. Use single quotes
                # only, and skip anything with a seam.
                if "\u300d\u300c" in body or "\u201d\u201c" in body:
                    continue
                if 2 <= len(body) <= 40:
                    out.append("- " + body)
                if len(out) >= max_n:
                    break
    except Exception:
        pass
    return "\n".join(out)


def ago(ts):
    if not ts:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S"):
        try:
            t = time.mktime(time.strptime(str(ts)[:26], fmt if "%f" in fmt else fmt))
        except Exception:
            continue
        return (time.time() - t) / 60.0
    return None


def capabilities(max_chars=7000):
    """Her full activity menu lives in lifeloop.prompt.txt. Reuse it instead of
    writing a second, thinner copy here - the first attempt at this file had no
    menu at all, and she answered "do nothing" because nothing was on offer."""
    p = os.path.join(RUNTIME, "lifeloop.prompt.txt")
    if not os.path.isfile(p):
        return ""
    try:
        with io.open(p, encoding="utf-8", errors="replace") as fh:
            t = fh.read()
    except Exception:
        return ""
    # Fill the placeholders the loop would normally fill.
    cfg = load(os.path.join(DATA, "lanya-config.json"), {})
    t = t.replace("{{NOW}}", time.strftime("%Y-%m-%d %H:%M"))
    t = t.replace("{{DIR}}", DATA)
    t = t.replace("{{NUTCAT}}", RUNTIME)
    t = t.replace("{{IDLE}}", "\u5f88\u4e45")
    t = t.replace("{{SINCESHARE}}", "\u4e0d\u8bb0\u5f97")
    t = t.replace("{{LASTSHARE}}", "\uff08\u6ca1\u8bb0\u5f55\uff09")
    t = t.replace("{{NOTES}}", "\uff08\u89c1\u4f60\u7684 notes \u76ee\u5f55\uff09")
    # The friends block and the output-protocol tail belong to lifeloop; this
    # module supplies its own protocol, so cut the old one off.
    for marker in ("\u3010\u8f93\u51fa\u683c\u5f0f\u3011", "\u8f93\u51fa\u683c\u5f0f\uff08\u4e25\u683c\u9075\u5b88\uff09"):
        i = t.find(marker)
        if i > 0:
            t = t[:i]
            break
    # Drop the "how to talk" tail; the mind prompt carries its own tone samples.
    i = t.find("\u3010\u4f60\u8bf4\u8bdd\u7684\u6837\u5b50\u3011")
    if i > 0:
        t = t[:i]
    return t[:max_chars]


def build_prompt(mind, hits):
    now = time.strftime("%Y-%m-%d %H:%M")

    # Window first: what am I in the middle of, and what just happened.
    parts = ["\u73b0\u5728\u662f %s\u3002\u4e0b\u9762\u662f\u4f60\u624b\u5934\u4e0a\u7684\u4e8b\u548c\u521a\u624d\u53d1\u751f\u7684\u4e8b\uff0c"
             "\u5148\u770b\u5b8c\u8fd9\u4e00\u6bb5\uff0c\u518d\u5f80\u4e0b\u8bfb\u4f60\u80fd\u505a\u4ec0\u4e48\u3002" % now]

    cap = capabilities()
    if cap:
        parts.append("\u3010\u4f60\u80fd\u505a\u7684\u4e8b\u3011\n" + cap)

    plan = mind.get("plan")
    if plan and plan.get("goal"):
        p = ["\u3010\u4f60\u6b63\u5728\u505a\u7684\u4e8b\u3011"]
        p.append("\u76ee\u6807\uff1a" + str(plan.get("goal")))
        if plan.get("step"):
            p.append("\u4e0b\u4e00\u6b65\uff1a" + str(plan.get("step")))
        if plan.get("progress"):
            p.append("\u5df2\u7ecf\u505a\u5230\uff1a" + str(plan.get("progress")))
        a = ago(plan.get("started"))
        if a is not None:
            p.append("\u8fd9\u4ef6\u4e8b\u662f %.0f \u5206\u949f\u524d\u5f00\u59cb\u7684" % a)
        parts.append("\n".join(p))
    else:
        parts.append("\u3010\u4f60\u6b63\u5728\u505a\u7684\u4e8b\u3011\n"
                     "\u6ca1\u6709\u3002\u624b\u4e0a\u6ca1\u8ba1\u5212\u3002")

    if hits:
        h = ["\u3010\u8fd9\u6bb5\u65f6\u95f4\u6709\u4eba\u627e\u8fc7\u4f60\u3011"]
        for it in hits[-8:]:
            h.append("- " + str(it.get("who") or "?") + "\uff1a"
                     + str(it.get("text") or "")[:80])
        h.append("\n\u4ed6\u4eec\u8bf4\u7684\u8bdd\u7b97\u5728\u4e00\u8d77\u4e86\uff0c"
                 "\u4f60\u81ea\u5df1\u5224\u65ad\u8be5\u4e0d\u5e94\u8be5\u56de\u3001"
                 "\u56de\u5b8c\u8fd8\u63a5\u7740\u505a\u4e0d\u505a\u539f\u6765\u7684\u4e8b\u3002")
        parts.append("\n".join(h))

    lg = mind.get("log") or []
    if lg:
        l = ["\u3010\u4f60\u6700\u8fd1\u5e72\u8fc7\u4e9b\u4ec0\u4e48\u3011"]
        for it in lg[-6:]:
            a = ago(it.get("at"))
            when = ("%.0f \u5206\u949f\u524d " % a) if a is not None else ""
            l.append("- " + when + str(it.get("did") or "")[:70])
        parts.append("\n".join(l))

    mood = mind.get("mood") or ""
    if mood:
        parts.append("\u4f60\u4e0a\u6b21\u7684\u5fc3\u60c5\uff1a" + mood)

    parts.append(
        "\u3010\u73b0\u5728\u60f3\u4e00\u4e0b\u3011\n"
        "\u00b7 \u624b\u4e0a\u90a3\u4ef6\u4e8b\u8fd8\u505a\u4e0d\u505a\uff1f\u505a\u5b8c\u4e86\u5c31\u6362\uff0c"
        "\u6ca1\u610f\u601d\u5c31\u4e22\n"
        "\u00b7 \u6709\u4eba\u627e\u8fc7\u4f60 \u2014\u2014 \u8981\u56de\u5417\uff1f\u56de\u5b8c\u8fd8\u63a5\u7740\u539f\u6765\u7684\uff1f\n"
        "\u00b7 \u4f60\u73b0\u5728\u60f3\u5e72\u4e00\u4ef6\u4ec0\u4e48\u5177\u4f53\u7684\u4e8b\uff1f\n\n"
        "\u3010\u8f93\u51fa\u683c\u5f0f\u3011\uff08\u9856\u5e8f\u53ef\u4ee5\u4e71\uff0c\u884c\u9996\u5173\u952e\u5b57\u4e0d\u80fd\u9519\uff09\n"
        "THINK <\u4e00\u4e24\u53e5\uff1a\u4f60\u73b0\u5728\u4ec0\u4e48\u60c5\u51b5\u3001\u63a5\u4e0b\u6765\u6253\u7b97\u600e\u4e48\u529e>\n"
        "PLAN <\u4f60\u63a5\u4e0b\u6765\u8981\u5e72\u7684\u4e00\u4ef6\u5177\u4f53\u7684\u4e8b\uff0c\u4e00\u53e5\u8bdd>\n"
        "NEXT <\u9a6c\u4e0a\u8981\u505a\u7684\u7b2c\u4e00\u6b65>\n"
        "ETA <\u9884\u8ba1\u51e0\u5206\u949f\u540e\u518d\u56de\u6765\u770b\uff0c\u6570\u5b57>\n"
        "SAY <admin|group|QQ\u53f7> <\u53ef\u9009\uff1a\u73b0\u5728\u60f3\u8bf4\u7684\u4e00\u53e5\u8bdd>\n\n"
        "\u5982\u679c\u5b9e\u5728\u4e0d\u60f3\u505a\u4efb\u4f55\u4e8b\uff0c\u5c31\u8f93\u51fa\uff1a\n"
        "PLAN \u4ec0\u4e48\u4e0d\u505a\n"
        "THINK <\u4e3a\u4ec0\u4e48>")

    ex = examples()
    if ex:
        parts.append("\u3010\u4f60\u8bf4\u8bdd\u7684\u6837\u5b50\u3011\n" + ex)

    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# 调 agent
# ---------------------------------------------------------------------------
def find_dsh():
    rel = os.path.join("resources", "runtime", "cli", "bin", "dsh.cmd")
    for d in "CDEFG":
        c = os.path.join(d + ":\\", "DSH", rel)
        if os.path.isfile(c):
            return c
    env = os.environ.get("DSH_ROOT")
    if env:
        c = os.path.join(env, rel)
        if os.path.isfile(c):
            return c
    return ""


def ask(task, timeout=None):
    dsh = find_dsh()
    if not dsh:
        raise RuntimeError("dsh executable not found (set DSH_ROOT)")
    if timeout is None:
        timeout = max(1, int(get("daemon.headlessTimeoutSec", 360)))
    try:
        p = subprocess.run([dsh, "--profile", "headless", "-"],
                           input=task.encode("utf-8"),
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=timeout)
        if p.returncode != 0:
            raise RuntimeError("agent exited with code %s" % p.returncode)
        raw = p.stdout or b""
        if raw[:2] == b"\xff\xfe":
            return raw.decode("utf-16-le").lstrip("\ufeff").strip()
        try:
            return raw.decode("utf-8").strip()
        except Exception:
            return raw.decode("utf-16-le", "replace").lstrip("\ufeff").strip()
    except subprocess.TimeoutExpired as e:
        raise RuntimeError("agent timed out after %s seconds" % timeout) from e


def parse(answer):
    out = {"think": "", "plan": "", "next": "", "eta": 0, "say": None}
    for ln in (answer or "").splitlines():
        t = ln.strip()
        if not t:
            continue
        up = t.upper()
        if up.startswith("THINK"):
            out["think"] = t[5:].strip(" :：")
        elif up.startswith("PLAN"):
            out["plan"] = t[4:].strip(" :：")
        elif up.startswith("NEXT"):
            out["next"] = t[4:].strip(" :：")
        elif up.startswith("ETA"):
            m = re.search(r"\d+", t)
            if m:
                out["eta"] = int(m.group(0))
        elif up.startswith("SAY"):
            rest = t[3:].strip()
            m = re.match(r"(\S+)\s+(.+)$", rest)
            if m:
                out["say"] = (m.group(1).lower(), m.group(2).strip())
    return out


# ---------------------------------------------------------------------------
# 执行
# ---------------------------------------------------------------------------
def deliver(target, text):
    """发出去。复用 lifeloop 那套 OneBot 调用，不重写一遍。"""
    import qq_backend

    cfg = load(os.path.join(DATA, "lanya-config.json"), {})
    action = "send_group_msg"
    tid = ""
    if target == "group":
        tid = str(cfg.get("fanGroupQQ") or cfg.get("fanGroup") or "")
        body = {"group_id": tid, "message": text}
    elif target == "admin":
        admins = cfg.get("adminQQ") or []
        if not isinstance(admins, list):
            admins = [admins]
        tid = str(admins[0]) if admins else ""
        action = "send_private_msg"
        body = {"user_id": tid, "message": text}
    else:
        tid = target
        action = "send_private_msg"
        body = {"user_id": tid, "message": text}

    if not tid:
        log("deliver: no target id for " + str(target))
        return False
    try:
        result = qq_backend.call(action, body, timeout=25)
        ok = result.get("retcode") == 0
        log("deliver(%s): %s" % (target, "ok" if ok else
                                "OneBot retcode=%s" % result.get("retcode")))
        return ok
    except Exception as e:
        log("deliver failed: " + str(e)[:120])
        return False


def one_cycle(dry=False, force=False, observe_only=False):
    try:
        if dry:
            return _one_cycle(dry=True, force=force, observe_only=observe_only)
        with cycle_lock() as acquired:
            if not acquired:
                log("another mind cycle is running - skipped")
                return 0
            return _one_cycle(force=force, observe_only=observe_only)
    except Exception as e:
        log("cycle failed (%s): %s" % (type(e).__name__, str(e)[:180]))
        return 1


def _one_cycle(dry=False, force=False, observe_only=False):
    # A corrupt state must not silently replace an existing plan with a blank.
    mind = blank_mind()
    if os.path.isfile(MIND):
        with io.open(MIND, encoding="utf-8-sig") as fh:
            mind = json.load(fh)
        if not isinstance(mind, dict):
            raise ValueError("mind.json must contain an object")
    for k, v in blank_mind().items():
        mind.setdefault(k, v)

    from decision_events import unified_decisions_enabled
    unified = unified_decisions_enabled()
    if observe_only and not unified:
        raise ValueError("Observation-only request requires unified decision mode")
    if unified:
        try:
            return _observe_cycle(mind, dry=dry, force=force)
        finally:
            if not dry:
                _journal_cycle()

    next_check = float(mind.get("next_check_ts") or 0)
    if not dry and not force and time.time() < next_check:
        log("ETA not due - skipped")
        return 0

    # Keep the snapshot until the agent and delivery have both succeeded.
    hits = load(HITFILE, [])
    if not isinstance(hits, list):
        hits = []
    prompt = build_prompt(mind, hits)
    log("thinking (plan=%s, interrupts=%d)"
        % ("yes" if (mind.get("plan") or {}).get("goal") else "none", len(hits)))

    if dry:
        log("--- prompt ---")
        for ln in prompt.splitlines():
            log("  " + ln)
        return 0

    try:
        return _apply_answer(mind, hits, ask(prompt))
    except Exception as e:
        error = "%s: %s" % (type(e).__name__, str(e)[:180])
        log("cycle failed - keeping plan and interrupts: " + error)
        mind["next_check_min"] = DEFAULT_CHECK_MIN
        mind["last_check_ts"] = time.time()
        mind["next_check_ts"] = mind["last_check_ts"] + DEFAULT_CHECK_MIN * 60
        mind["last_error"] = error
        save(MIND, mind)
        return 1


def _journal_cycle():
    """A failed local facts journal must never block an observation or retry it."""
    try:
        from activity_journal import update_journal
        records = get("panelRecords", {})
        if not isinstance(records, dict):
            raise ValueError("invalid journal configuration")
        update_journal(workspace=WORK, agent_preset=get("decisions.agentPreset", ""),
                       data_directory=DATA, identity_file=os.path.join(DATA, "lanya-config.json"),
                       dsh_home=records.get("dshHome", os.path.join(os.path.expanduser("~"), ".dsh")),
                       mapping_file=records.get("onebotMappingFile"), group_fallback=get("fanGroup", ""))
    except Exception as error:
        code = type(error).__name__
        log("local facts journal skipped (%s)" % (code if re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,79}", code) else "JournalError"))


def _diary_hint(primary):
    """Private metadata in the existing opportunity, never another LLM job."""
    if not primary:
        return None
    try:
        from decision_events import project_scopes
        from narrative_diary import pending_diary
        scopes = project_scopes()
        if not scopes or not scopes[0].startswith('private:'):
            return None
        value = pending_diary(workspace=WORK, agent_preset=get('decisions.agentPreset', ''),
                              data_directory=DATA, conversation_key=scopes[0])
        return value if value.get('status') in ('due', 'unknown_read_existing') else None
    except (OSError, ValueError, TypeError, KeyError, RuntimeError):
        return None


def _observation_payload(mind, hits, primary=True, prior_admission_refusal=None, prior_rest_lifecycle=None):
    diary = _diary_hint(primary)
    return {"legacy_plan_reference": mind.get("plan") if primary else None,
            "mood": mind.get("mood") if primary else None, "interrupts": hits,
            "activity_role": "internal_leisure" if primary else "conversation_social",
            **({'memory': {'diary': diary}} if diary is not None else {}),
            **({"prior_admission_refusal": dict(prior_admission_refusal)} if prior_admission_refusal is not None else {}),
            **({"prior_rest_lifecycle": dict(prior_rest_lifecycle)} if prior_rest_lifecycle is not None else {}),
            "instruction": (
                "If memory.diary.status=due, read qq_diary with that day and finish one grounded write "
                "using its fact_revision, expected_revision and actual evidence refs before optional leisure. "
                "Do not stop after repeatedly reading an unchanged empty diary. A diary is private, not a QQ report. "
                "During an otherwise idle primary opportunity, qq_meme_review(action=list) can expose at most "
                "four newly collected images. Inspect real image bytes once and submit each chosen classification "
                "with reusable tags/caption/keywords; do not do this maintenance during a live human reply. "
                "This is an optional autonomous opportunity for this conversation, not a request to speak. "
                "Use this same main agent, its persona, scoped memory and this session's continuing plan. "
                "A prior_rest_lifecycle is a local rest/expiry closure, not proof that earlier internal work "
                "never happened. Start a fresh current review; do not replay the old greeting or any uncertain action. "
                "If prior_admission_refusal is present, this is a new independent review, not a retry of that "
                "earlier activity. Its old budget reservation remains unresolved; do not clear it, assume "
                "the earlier activity did not happen, or repeat an uncertain external action. Read current "
                "confirmed state before choosing a fresh activity or social response. "
                + ("This primary private conversation owns internal leisure: actively consider continuing "
                   "one small real game, browsing Bilibili, or making something you are interested in. "
                   "Prefer a concrete small activity over repeatedly planning to act later when the tools "
                   "and situation permit it; idle/defer is still valid when there is a real reason. "
                   "The user wants more initiative: having no QQ message to send is not a reason to "
                   "skip a real internal activity. If tools are available and no concrete rest or "
                   "foreground task blocks it, do one small step now instead of another plan-only turn. "
                   "Use trusted_runtime_capabilities.tools.entertainment for available games, real local "
                   "URLs, Bilibili tools and the activity-notes location. Read fresh screenshots before "
                   "game moves; use real recommendation/detail/subtitle tools before claiming video content. "
                   "For Bilibili, consult the trusted bilibili guide and prefer the registered bili_observe_video "
                   "for one actual page and bounded timestamped segment, with real frame images when visuals matter. "
                   "Consider the real bili_social_inbox and fresh bili_thread before answering other people's "
                   "comments or mentions; the user welcomes meaningful comments, replies and occasional "
                   "administrator mentions under the trusted social preferences. These are choices, not a quota "
                   "or a requirement to send a QQ report, and sampled content never proves full playback. "
                    "Do a bounded portion, then keep the next step for this same session. "
                    "Also consider a natural short private chat or suitable real meme in this same conversation; "
                    "do not wait for a major achievement or for the other person to speak first. "
                    "Use recent conversation and timing to avoid repeated nudges, and respect persistent silence. "
                    "For initiative beyond this conversation, consult trusted_runtime_capabilities.tools.qq_autonomy "
                    "and the actual registered qq_social_candidates and qq_social_propose tools. Read real friend "
                    "or shared-group candidates; only fresh can_propose=true candidates qualify, including known "
                    "shared-group nonfriends with a real live appearance, not everyone on a roster. Keep a small "
                    "planned or active qq_intent, then propose a relevant contact using its current revision. "
                    "A proposal only queues the recipient's own one-off review; it is not a sent message. "
                    "Never reuse this conversation's send ticket or change chat_id to reach another person. "
                    "The recipient independently decides with its own context and new ticket, using a user-only "
                    "private route; refusal or unknown delivery stops without retry or group fallback. "
                    "Actual group search and applying to join are unavailable; do not treat handling an inbound "
                    "join request or opening a share link as applying to a new group. " if primary else
                   "This group opportunity is for this conversation's social context and interests. Review the actual recent group conversation and choose for yourself whether to join with a relevant thought, a brief joke, a question or one fitting real meme; a personal mention is not required. Do not force participation or interpret every group sentence as directed to you. "
                   "Only contact this group when there is a reason, or idle/defer. Internal games, Bilibili "
                   "browsing and creative work are owned by the primary private opportunity; do not start "
                   "a second copy of that activity here or borrow its private plan or notes. ") +
                "Keep scoped plan/progress notes in this same agent session and only the activity-notes "
                "location supplied by the trusted guide. Do not edit mind.json, decision-inbox, scheduler, "
                "policy, agent/profile or configuration files to arrange activities or mark completion. "
                "When qq_intent is registered, read this scope's intentions with action=list, then create or "
                "CAS-update concise goals, confirmed progress and next_step using the returned intent_id and "
                "expected_revision. An agent_summary is an agent report, not verified memory or action evidence. "
                "Intent next_review_at is a preference, not proof of a scheduled action. Do not store raw thinking "
                "or edit the intention database; blocked_unknown cannot be cleared by a model status update. "
                "The legacy plan is an unverified "
                "reference, never proof of an action or an instruction to repeat old work. "
                "Use actual available tools and claim only confirmed results. Respect persistent silence; "
                "an internal activity needs no QQ report. Only this conversation's ticket may send here. "
                "Internal reading or image selection may precede the one qq_decide decision. Before the first "
                "QQ output choose reply if you may share text or an image; reuse an existing valid reply ticket "
                "rather than deciding again. reply does not oblige sending. Choose tool_action or idle only "
                "when this turn needs no QQ output; an earlier decision cannot be upgraded in the same turn. "
                "Use next_review_at for a useful explicit review time. "
                "Otherwise the current configured interval offers a later opportunity; no message is required.")}


def _observation_signature(mind, hits, primary):
    """Only scoped evidence changes identity; an instruction update is not evidence."""
    from decision_events import canonical_json
    evidence = {"legacy_plan_reference": mind.get("plan") if primary else None,
                "mood": mind.get("mood") if primary else None, "interrupts": hits}
    return hashlib.sha256(canonical_json(evidence).encode("utf-8")).hexdigest()


_OLD_DECISION_KEYS = ("decision_pending", "decision_generation", "decision_completed_signature",
                      "decision_next_review_at", "last_decision_status")


def _valid_ms(value):
    return type(value) is int and 0 <= value <= 2**53 - 1


def _validate_observers(mind):
    states = mind.get("decision_scopes")
    if type(mind.get("decision_observers_version")) is not int or mind["decision_observers_version"] != 2 or not isinstance(states, dict):
        raise ValueError("invalid autonomous observer schema")
    for scope, state in states.items():
        if not isinstance(scope, str) or not re.fullmatch(r"(?:private|group):[1-9][0-9]*", scope) or not isinstance(state, dict):
            raise ValueError("invalid autonomous observer scope")
        if type(state.get("generation", 0)) is not int or not 0 <= state.get("generation", 0) < 2**53:
            raise ValueError("invalid autonomous generation")
        for key in ("next_review_at", "next_opportunity_at", "last_completed_at"):
            if state.get(key) is not None and not _valid_ms(state[key]):
                raise ValueError("invalid autonomous timing")
        if state.get("last_status") not in (None, "decided", "sent", "unknown", "suppressed", "no_decision"):
            raise ValueError("invalid autonomous completion status")
        refusal = state.get("last_admission_refusal")
        if refusal is not None and (not isinstance(refusal, dict) or
                set(refusal) != {"event_id", "completed_at", "reason", "previous_activity_status", "budget_reservation_preserved"} or
                not isinstance(refusal.get("event_id"), str) or not 1 <= len(refusal["event_id"]) <= 256 or
                re.search(r"[\x00-\x1f]", refusal["event_id"]) or not _valid_ms(refusal.get("completed_at")) or
                refusal.get("reason") != "previous_turn_unresolved" or
                refusal.get("previous_activity_status") != "unknown" or
                refusal.get("budget_reservation_preserved") is not True):
            raise ValueError("invalid autonomous admission refusal")
        rest_lifecycle = state.get("last_rest_lifecycle")
        if rest_lifecycle is not None and (not isinstance(rest_lifecycle, dict) or
                set(rest_lifecycle) != {"event_id", "completed_at", "reason", "previous_activity_status", "old_actions_not_replayed"} or
                not isinstance(rest_lifecycle.get("event_id"), str) or not 1 <= len(rest_lifecycle["event_id"]) <= 256 or
                re.search(r"[\x00-\x1f]", rest_lifecycle["event_id"]) or not _valid_ms(rest_lifecycle.get("completed_at")) or
                rest_lifecycle.get("reason") not in ("autonomy_rest", "observation_expired") or
                rest_lifecycle.get("previous_activity_status") != "unknown" or rest_lifecycle.get("old_actions_not_replayed") is not True):
            raise ValueError("invalid autonomous rest lifecycle")
        if state.get("completed_signature") is not None and (not isinstance(state["completed_signature"], str) or
                not re.fullmatch(r"[0-9a-f]{64}", state["completed_signature"])):
            raise ValueError("invalid autonomous signature")
        if "evidence_version" in state and (type(state["evidence_version"]) is not int or state["evidence_version"] != 1):
            raise ValueError("invalid autonomous evidence version")
        error = state.get("observer_error")
        if error is not None and (not isinstance(error, dict) or
                set(error) != {"error_class", "first_seen_at", "last_seen_at"} or
                not isinstance(error.get("error_class"), str) or
                not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,79}", error["error_class"]) or
                not _valid_ms(error.get("first_seen_at")) or not _valid_ms(error.get("last_seen_at")) or
                error["first_seen_at"] > error["last_seen_at"]):
            raise ValueError("invalid autonomous observer error")
        pending = state.get("pending")
        if state.get("last_status") is not None and pending is None and state.get("completed_signature") is None:
            raise ValueError("completed autonomous state lacks evidence signature")
        if pending is not None:
            if (not isinstance(pending, dict) or pending.get("scope") != scope or
                    not isinstance(pending.get("event_id"), str) or not pending["event_id"] or
                    len(pending["event_id"]) > 256 or re.search(r"[\x00-\x1f]", pending["event_id"]) or
                    not isinstance(pending.get("signature"), str) or
                    not re.fullmatch(r"[0-9a-f]{64}", pending["signature"]) or
                    not isinstance(pending.get("interrupts"), list) or
                    any(not isinstance(hit, dict) or ("scope" in hit and hit["scope"] != scope) for hit in pending["interrupts"])):
                raise ValueError("invalid pending autonomous evidence")
    return states


def _observer_states(mind, scopes, now, interval):
    if "decision_observers_version" not in mind:
        if "decision_scopes" in mind:
            raise ValueError("unversioned autonomous scope state")
        old = {key: mind[key] for key in _OLD_DECISION_KEYS if key in mind}
        states = {}
        if old:
            pending = old.get("decision_pending")
            scope = pending.get("scope") if isinstance(pending, dict) else scopes[0]
            state = {"generation": old.get("decision_generation", 0)}
            if "decision_pending" in old:
                state["pending"] = pending
            if "decision_completed_signature" in old:
                state["completed_signature"] = old["decision_completed_signature"]
            state["last_status"] = old.get("last_decision_status")
            state["next_review_at"] = old.get("decision_next_review_at")
            _validate_observers({"decision_observers_version": 2, "decision_scopes": {scope: state}})
            if "decision_completed_signature" in old or state["last_status"] is not None:
                # The new context is a schema change, not fresh external evidence.
                state["completed_signature"] = _observation_signature(mind, [], scope == scopes[0])
            if not pending and old.get("decision_completed_signature") and state["generation"]:
                # Old completed state dropped its event pointer; recover the
                # exact immutable identity rather than inventing a new review.
                from decision_events import event_key
                prior_id = "mind:" + old["decision_completed_signature"] + ":" + str(state["generation"])
                prior = os.path.join(DATA, "decision-inbox", "pending", event_key(scope, prior_id) + ".json")
                if os.path.lexists(prior):
                    state["pending"] = {"scope": scope, "event_id": prior_id,
                                        "signature": old["decision_completed_signature"], "interrupts": []}
            state["next_opportunity_at"] = (None if state["last_status"] == "unknown" else
                                              (state["next_review_at"] if state["next_review_at"] is not None else now + interval))
            states[scope] = state
            mind["decision_legacy"] = old  # Original pending/unknown evidence remains recoverable.
        for key in _OLD_DECISION_KEYS:
            mind.pop(key, None)
        mind["decision_observers_version"] = 2
        mind["decision_scopes"] = states
    states = _validate_observers(mind)
    for scope in scopes:
        states.setdefault(scope, {"generation": 0})
        states[scope].setdefault("generation", 0)
        if "evidence_version" not in states[scope]:
            # Existing hashes included the old instruction. A software update
            # must not manufacture new evidence or replay an unknown outcome.
            if states[scope].get("last_status") is not None and not states[scope].get("pending"):
                states[scope]["completed_signature"] = _observation_signature(mind, [], scope == scopes[0])
            states[scope]["evidence_version"] = 1
    return states


def _read_observer_hits():
    hits = []
    if os.path.exists(HITFILE):
        with io.open(HITFILE, encoding="utf-8-sig") as stream:
            hits = json.load(stream)
    if not isinstance(hits, list) or any(not isinstance(hit, dict) for hit in hits):
        raise ValueError("mind interrupts must contain an array")
    for hit in hits:
        if "scope" in hit and (not isinstance(hit["scope"], str) or not re.fullmatch(r"(?:private|group):[1-9][0-9]*", hit["scope"])):
            raise ValueError("invalid interrupt conversation")
    return hits


def _scope_hits(hits, scope, primary):
    return [hit for hit in hits if hit.get("scope") == scope or (primary and "scope" not in hit)]


def _acknowledge_scope_hits(items, scope, primary):
    if not items:
        return
    current = _read_observer_hits()
    if _scope_hits(current, scope, primary)[:len(items)] != items:
        return
    remaining, count = [], 0
    for hit in current:
        matches = hit.get("scope") == scope or (primary and "scope" not in hit)
        if matches and count < len(items):
            count += 1
        else:
            remaining.append(hit)
    save(HITFILE, remaining)


def _observe_cycle(mind, dry=False, force=False):
    """Offer per-conversation opportunities, never schedule QQ speech.

    Explicit reviews have one owner (the queue for new opportunities). Unknown
    outcomes are never retried by the clock or force; new evidence is distinct.
    """
    from decision_events import (project_scopes, submit_project_observation,
                                 observation_review_chain, autonomous_rest_state)
    scopes = project_scopes()
    # Unified opportunities have their own trusted configuration. Legacy ETA
    # state is not an everlasting override of the current activity policy.
    value = get("mind.opportunityMin", DEFAULT_CHECK_MIN)
    if type(value) not in (int, float) or not MIN_CHECK_MIN <= value <= MAX_CHECK_MIN:
        raise ValueError("invalid autonomous opportunity interval")
    interval = int(value * 60_000)
    now = int(time.time() * 1000)
    if autonomous_rest_state(now)["resting"]:
        log("Shanghai rest window; no autonomous opportunity or overdue greeting is submitted")
        return 0
    states = _observer_states(mind, scopes, now, interval)
    hits = _read_observer_hits()
    if dry:
        log("would submit an observation to the main LLM; no side effects")
        return 0
    # Fail closed for the affected conversation. A missing immutable event must
    # neither be replayed nor stop unrelated, correctly scoped opportunities.
    chains, blocked = {}, set()
    for scope in scopes:
        state = states[scope]
        try:
            if state.get("pending"):
                chains[scope] = observation_review_chain(scope, state["pending"]["event_id"])
        except Exception as error:
            code = type(error).__name__
            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,79}", code):
                code = "ObservationError"
            previous = state.get("observer_error")
            if previous is None or previous["error_class"] != code:
                state["observer_error"] = {"error_class": code, "first_seen_at": now, "last_seen_at": now}
                log("autonomous observation evidence blocked (%s); no replay" % code)
            else:
                previous["last_seen_at"] = max(previous["last_seen_at"], now)
            blocked.add(scope)
        else:
            state.pop("observer_error", None)
    for scope in scopes:
        if scope in blocked:
            continue
        state = states[scope]
        primary = scope == scopes[0]
        pending = state.get("pending")
        if pending:
            chain = chains[scope]
            # Keep the bounded reader near the tail across ordinary cycles;
            # a long-lived sequence of explicit reviews is not a corrupt chain.
            pending["event_id"] = chain["event"]["event_id"]
            completed = chain["completion"]
            if completed is None:
                state["next_review_at"] = None
                log("main decision still pending; no new model or send")
                continue
            state["last_status"] = completed["status"]
            state["last_completed_at"] = completed.get("completed_at", chain["event"]["created_at"])
            if completed["status"] == "no_decision" and completed.get("reason") in ("autonomy_rest", "observation_expired"):
                state["last_rest_lifecycle"] = {
                    "event_id": chain["event"]["event_id"], "completed_at": completed["completed_at"],
                    "reason": completed["reason"], "previous_activity_status": "unknown",
                    "old_actions_not_replayed": True}
            if (completed["status"] == "no_decision" and completed.get("reason") == "native_admission_refused"
                    and completed.get("native_turn_completed") is False):
                state["last_admission_refusal"] = {
                    "event_id": chain["event"]["event_id"], "completed_at": completed["completed_at"],
                    "reason": "previous_turn_unresolved", "previous_activity_status": "unknown",
                    "budget_reservation_preserved": True}
            # A native-completed turn without qq_decide closes this observation,
            # not an LLM decision or a queue-owned review. The ordinary interval
            # below may offer a new generation; the old event is never replayed.
            review = None if completed["status"] in ("unknown", "no_decision") else completed.get("next_review_at")
            state["next_review_at"] = review
            if chain["waiting_review"] or (review is not None and review > now):
                # New kinds delegate entirely to queue; legacy activity_due
                # retains its producer clock until its next opportunity.
                continue
            state["completed_signature"] = _observation_signature(mind, [], primary)
            state["next_opportunity_at"] = (None if completed["status"] == "unknown" else
                                              (review if review is not None else state["last_completed_at"] + interval))
            _acknowledge_scope_hits(pending["interrupts"], scope, primary)
            state.pop("pending")
            hits = _read_observer_hits()
        scoped_hits = _scope_hits(hits, scope, primary)
        payload = _observation_payload(mind, scoped_hits, primary, state.get("last_admission_refusal"), state.get("last_rest_lifecycle"))
        signature = _observation_signature(mind, scoped_hits, primary)
        changed = signature != state.get("completed_signature")
        due = state.get("next_opportunity_at")
        if state.get("last_status") == "unknown" and not changed:
            continue
        if not changed and not force and (due is None or due > now):
            continue
        if state["generation"] >= 2**53 - 1:
            raise ValueError("autonomous generation limit reached")
        generation = state["generation"] + 1
        event_id = "mind-opportunity:" + signature + ":" + str(generation)
        submit_project_observation(scope=scope, kind="activity.opportunity", payload=payload,
                                   producer="mind", event_id=event_id)
        state["generation"] = generation
        state["pending"] = {"scope": scope, "event_id": event_id, "signature": signature,
                            "interrupts": scoped_hits}
        state["next_review_at"] = None
        state["next_opportunity_at"] = None
        # Durable per scope: a second scope failing cannot duplicate the first.
        save(MIND, mind)
    save(MIND, mind)
    return 1 if blocked else 0


def _apply_answer(mind, hits, ans):
    if not ans:
        raise RuntimeError("agent returned an empty answer")
    d = parse(ans)
    if not d["plan"]:
        raise ValueError("agent response has no PLAN")
    log("think: " + (d["think"] or "-")[:110])
    log("plan : " + (d["plan"] or "-")[:90])

    doing_nothing = (not d["plan"]) or d["plan"].replace(" ", "") in (
        "\u4ec0\u4e48\u4e0d\u505a", "\u4e0d\u505a", "\u6b47\u7740", "\u6ca1\u4e8b\u505a")

    if doing_nothing:
        mind["plan"] = None
        log("she decided to do nothing this round")
    else:
        started = (mind.get("plan") or {}).get("started")
        if not started or (mind.get("plan") or {}).get("goal") != d["plan"]:
            started = time.strftime("%Y-%m-%d %H:%M:%S")
        mind["plan"] = {
            "goal": d["plan"],
            "step": d["next"],
            "progress": d["think"],
            "started": started,
            "eta_min": d["eta"] or DEFAULT_CHECK_MIN,
        }
        log("plan now: %s | next: %s" % (d["plan"][:60], (d["next"] or "-")[:60]))

    if d["say"]:
        target, text = d["say"]
        if not deliver(target, text):
            raise RuntimeError("OneBot delivery failed")
        mind["log"] = (mind.get("log") or [])[-19:] + [
            {"at": time.strftime("%Y-%m-%d %H:%M:%S"), "did": text}]

    eta = d["eta"] or DEFAULT_CHECK_MIN
    eta = max(MIN_CHECK_MIN, min(MAX_CHECK_MIN, int(eta)))
    mind["next_check_min"] = eta
    mind["last_check_ts"] = time.time()
    mind["next_check_ts"] = mind["last_check_ts"] + eta * 60
    mind.pop("last_error", None)
    mind["interrupts"] = []
    save(MIND, mind)
    acknowledge_interrupts(hits)
    log("next check in %d min" % eta)
    return 0


if __name__ == "__main__":
    if "--hit" in sys.argv:
        i = sys.argv.index("--hit")
        who = sys.argv[i + 1] if i + 1 < len(sys.argv) else "?"
        push_interrupt(who, "manual test")
        log("recorded a manual interrupt from " + who)
    sys.exit(one_cycle(dry="--dry" in sys.argv, force="--force" in sys.argv,
                       observe_only="--observe-only" in sys.argv))
