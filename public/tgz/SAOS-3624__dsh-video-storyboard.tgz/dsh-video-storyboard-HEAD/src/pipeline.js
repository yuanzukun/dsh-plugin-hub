/**
 * pipeline.js — 端到端编排：探测 → 切分 → 分段 → 取帧 → 拼图 → 清单。
 *
 * CLI（bin/storyboard.mjs）和 DSH 工具（index.js）都走这里，避免两份实现漂移。
 * 本模块只返回内存里的 PNG buffer 与结构化清单，落盘由调用方决定。
 */

import { probeVideo, DEFAULT_FFMPEG, DEFAULT_FFPROBE } from './probe.js';
import { resolveInput } from './fetch.js';
import { loadTranscriptFile } from './transcript-file.js';
import { scanShots } from './scan.js';
import { fitSegments, segmentsFromCuts, totalDur } from './segments.js';
import { bestLayout, groupByCount, suggest } from './plan.js';
import { findBursts, planCellRanges } from './density.js';
import { describeMemory, remember } from './memory.js';
import { analyzeAudio, describeAudio, detectOnsets } from './audio.js';
import {
  ASR_DEFAULTS, alignCells, applyTermMap, describeAsrTarget, explainFetchError, extractSubtitleTrack,
  filterSuspectSegments, resolveAsrConfig, speechCurve, transcribeLong,
} from './asr.js';
import { cacheKey, pruneCache, withCache } from './cache.js';
import {
  addAudioStrip, composeSheet, encodeRaw, encodePngBuffer, extractFrameRaw, extractSharpest, layoutCanvas,
} from './sheet.js';

export const PICK_MODES = ['sharp', 'mid', 'thumb'];// 只有两种：时间码不烧进画面 —— 它占像素、压缩后先糊，而清单里已经有 0.01 秒精度的时间。
// （历史上 `index+time` 在参数表里但从没实现过，等于一个会静默失效的选项。）
export const BURN_MODES = ['index', 'none'];

/**
 * 取一帧：有高清直链就先走远程，失败回落本地低清。
 *
 * **远程时把候选帧降到 1。** 一次 HTTP seek 实测 1.92 s，3 候选即使并发也要 3–4 s/格，
 * 6 格就是 20 秒以上；而 zoom 的窗口本来就短、格间距小，段中点足够代表。
 * 本地文件仍然用 3 候选（0.35 s/次，几乎免费，且段内可能有转场帧）。
 */
async function extractFrameWithFallback({ input, remote, at, dur, cellW, cellH, ffmpegPath, pick }) {
  const grab = (src, http, candidates) => {
    if (pick === 'sharp') {
      return extractSharpest({ input: src, at, dur, cellW, cellH, ffmpegPath, http, candidates });
    }
    return extractFrameRaw({
      input: src, at, dur, cellW, cellH, ffmpegPath, http,
      mode: pick === 'thumb' ? 'thumb' : 'mid',
    });
  };
  if (remote?.uri) {
    try {
      return { ...(await grab(remote.uri, remote.http, 1)), via: 'remote' };
    } catch {
      /* 直链过期或 CDN 抖动：不整次失败，落到本地那份低清 */
    }
  }
  return { ...(await grab(input, null, 3)), via: remote?.uri ? 'local-fallback' : 'local' };
}

/**
 * @param {object} opts
 * @param {string} opts.input 视频路径
 * @param {number} [opts.from] 窗口起点（秒）
 * @param {number} [opts.to] 窗口终点（秒）
 * @param {number} [opts.cells] 每张格数（0=自动）
 * @param {number} [opts.sheets] 张数（0=自动）
 * @param {number|'auto'} [opts.threshold]
 * @param {number} [opts.minGap] 采样最小间隔
 * @param {'sharp'|'mid'|'thumb'} [opts.pick]
 * @param {'index'|'none'} [opts.burn]
 * @param {number} [opts.badgeRatio]
 * @param {number} [opts.budget] 单图像素预算
 * @param {string} [opts.ffmpegPath]
 * @param {string} [opts.ffprobePath]
 * @param {(p:object)=>void} [opts.onProgress]
 */
export async function runStoryboard(opts) {
  const {
    input: inputRaw,
    from = 0,
    to,
    threshold = 'auto',
    minGap = 1.2,
    adaptive = true,
    pick = 'sharp',
    burn = 'index',
    transcript = 'auto',
    transcriptFile,
    frameSource = null,
    fetchOptions = null,
    audioStrip = true,
    asrMaxChunk = 45,
    cache = true,
    textOnly = false,
    precomputed = null,
    badgeRatio = 0.15,
    budget = 640_000,
    encode = true,
    ffmpegPath = DEFAULT_FFMPEG,
    ffprobePath = DEFAULT_FFPROBE,
    onProgress,
  } = opts;
  if (!inputRaw) throw new Error('input is required');
  if (!PICK_MODES.includes(pick)) throw new RangeError(`pick must be one of ${PICK_MODES.join('/')}`);
  if (!BURN_MODES.includes(burn)) throw new RangeError(`burn must be one of ${BURN_MODES.join('/')}`);

  // 链接在这里变成一份本地文件；本地路径原样返回（source 为 null）。
  // 后面的所有阶段都只面对 input，不知道它原来是不是个 URL。
  const resolved = await resolveInput(inputRaw, fetchOptions ?? {});
  const input = resolved.path;
  const sourceInfo = resolved.source;
  // zoom 用高清直链取帧；失败要能回落到本地低清，所以这里只记"首选源"，不替换 input
  const remoteFrame = frameSource?.uri
    ? { uri: frameSource.uri, http: { userAgent: frameSource.userAgent, referer: frameSource.referer } }
    : null;

  const info = { ...(await probeVideo(input, { ffprobePath })), path: input };
  const winStart = Math.max(0, Math.min(Number(from) || 0, Math.max(0, info.duration - 0.2)));
  const winEnd = Math.min(info.duration, Number(to) > 0 ? Number(to) : info.duration);
  const winDur = Math.max(0.2, winEnd - winStart);

  // 扫描结果按 (文件, 窗口, 阈值策略) 缓存：storyboard 之后的 zoom 能直接复用
  const key = cache ? await cacheKey({ input, start: winStart, end: winStart + winDur, threshold }) : null;
  // precomputed：批量模式下全片已经扫过一次，窗口直接复用那份切点与摘要，
  // 不再为每个窗口重新解码一遍（2 小时的片子能省掉 24 次重复扫描）。
  const scan = precomputed
    ? {
      cuts: (precomputed.cuts ?? []).filter((c) => c.t >= winStart && c.t < winStart + winDur),
      summary: precomputed.summary ?? { frames: 0, p90: 0, p99: 0 },
      threshold: precomputed.threshold ?? threshold,
      cached: false,
      reused: true,
    }
    : await withCache(key, () => scanShots({
      input, fps: info.fps, threshold, start: winStart, end: winStart + winDur,
      ffmpegPath, onProgress,
    }), { enabled: cache });
  if (cache && !scan.cached && !precomputed) await pruneCache();

  // ---- 音频测量（零模型：响度 + 静音）。先做，因为静音位置要用来切 ASR 请求。
  const needAudio = info.hasAudio && !textOnly && (audioStrip !== false || transcript !== 'off');
  const audio = needAudio
    ? await analyzeAudio({ input, ffmpegPath, start: winStart, end: winStart + winDur })
    : null;
  const stripAudio = audioStrip !== false ? audio : null;
  const silences = audio?.silences ?? [];
  // 声音事件：突然变响/突然安静。画面没动但事情发生的时刻，只能靠它抓到。
  // 口播片里"每句话的停顿"都会触发，所以**只用最突出的若干个**参与格位加权
  // （全部 90 多个事件铺上去等于把密度曲线压平），清单里也按强度排序展示。
  const allEvents = audio ? detectOnsets(audio) : [];

  // ---- 台词：显式文件 > 字幕轨 > ASR；三者都没有就静默跳过（绝不让分镜失败）
  let transcriptInfo = null;
  if (transcriptFile) {
    // 显式给了转写就只用它：不查字幕轨、不跑 ASR。
    // 接 B 站时这一步最省 —— 字幕本来就有，没必要再识别一遍（10 分钟口播省 60–120 秒）。
    // 也**不跑幻觉过滤**：那是给 ASR 兜底的，用户递进来的文件按可信处理。
    try {
      const loaded = await loadTranscriptFile(transcriptFile);
      const { segments: fixed, replaced } = applyTermMap(loaded.segments, resolveAsrConfig().terms);
      transcriptInfo = {
        ...(replaced > 0 ? { termsFixed: replaced } : {}),
        source: fixed.length > 0 ? 'file' : 'file-empty',
        model: `file:${loaded.format}`,
        segments: fixed,
        suspect: 0,
        suspectDetail: [],
      };
    } catch (error) {
      transcriptInfo = {
        segments: [],
        source: 'file-failed',
        error: String(error?.message ?? error).slice(0, 300),
      };
    }
  } else if (transcript !== 'off' && info.hasAudio) {
    const subtitle = info.hasSubtitle
      ? await extractSubtitleTrack({ input, ffmpegPath })
      : null;
    if (subtitle) {
      transcriptInfo = { segments: subtitle, source: 'subtitle', model: 'embedded' };
    } else {
      try {
        // 切片调用：单次请求过长会让时间码整体压早（实测 299s 压早 13s）。
        // 结果按 (文件, 窗口, 后端, 切片长度) 缓存 —— 否则 textOnly 分页每翻一页都要重跑 ASR。
        const asrKey = await cacheKey({
          input, start: winStart, end: winStart + winDur,
          threshold: `asr|${ASR_DEFAULTS.baseUrl}|${ASR_DEFAULTS.model}|${asrMaxChunk}|${transcript}`,
        });
        const asr = await withCache(asrKey, () => transcribeLong({
          input, ffmpegPath, start: winStart, end: winStart + winDur,
          silences, maxChunk: asrMaxChunk,
        }), { enabled: cache });
        if (asr) {
          // 音乐段的幻觉句会命中多个格子、被复制好几遍，先过滤（结果里报出来，不静默丢）
          const { kept, dropped } = filterSuspectSegments(asr.segments);
          // 用户词典校正（确定性替换，替换次数会报出来）
          const { segments: fixed, replaced } = applyTermMap(kept, resolveAsrConfig().terms);
          transcriptInfo = {
            ...(replaced > 0 ? { termsFixed: replaced } : {}),
            ...asr,
            // 空结果（没配 key / 整片纯音乐）不该自称 asr —— 见 PR #3
            source: asr.empty || fixed.length === 0 ? 'asr-empty' : 'asr',
            segments: fixed,
            suspect: dropped.length,
            suspectDetail: dropped.slice(0, 3).map((d) => ({
              from: +d.from.toFixed(2), to: +d.to.toFixed(2),
              charsPerSec: d.charsPerSec, reason: d.reason,
            })),
          };
        }
      } catch (error) {
        transcriptInfo = {
          segments: [],
          source: 'asr-failed',
          // 把真实原因带出来 —— 只写 "ASR call failed" 会让每次故障都得重新猜
          error: `${explainFetchError(error).slice(0, 300)}  [${describeAsrTarget()}]`,
        };
      }
    }
  } else if (transcript !== 'off' && !info.hasAudio) {
    transcriptInfo = { segments: [], source: 'no-audio' };
  }
  // 一致性检查：台词落在"被判静音"的区间里 = 两种可能，轻声被吞了，或者 ASR 编的。
  const textInSilence = transcriptInfo?.source === 'asr'
    ? countTextInSilence(transcriptInfo.segments, silences)
    : 0;

  const relSegments = (transcriptInfo?.segments ?? [])
    .map((seg) => ({ ...seg, from: seg.from - winStart, to: seg.to - winStart }))
    .filter((seg) => seg.to > 0 && seg.from < winDur);
  const speech = relSegments.length > 0
    ? speechCurve(relSegments, { duration: winDur })
    : null;

  // 声音事件只有在"话不密"的片子里才有信息量：
  // 口播片每句话的停顿都会触发（实测 299s 里 92 次），铺到密度曲线上等于把它压平。
  const speechRateForEvents = winDur > 0
    ? relSegments.reduce((n, seg) => n + seg.text.length, 0) / winDur : 0;
  const audioEvents = speechRateForEvents < 3
    ? [...allEvents]
      .sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta))
      .slice(0, 12)
      .sort((a, b) => a.t - b.t)
    : [];

  // ---- 格数：放在台词与音频之后，是为了让"口播多不多 / 是不是音乐驱动"参与决策
  let cells = Math.max(0, Number(opts.cells) || 0);
  let sheets = Math.max(0, Number(opts.sheets) || 0);
  let suggestion;
  if (cells === 0) {
    const speechChars = relSegments.reduce((n, seg) => n + seg.text.length, 0);
    const speechRate = winDur > 0 ? speechChars / winDur : 0;
    suggestion = suggest({
      duration: winDur,
      cuts: scan.cuts.length,
      motion: scan.summary.p90,
      aspect: info.aspect,
      speechRate,
      hasSubtitle: info.hasSubtitle,
      meanLufs: audio?.mean,
    });
    cells = suggestion.cells;
    sheets = sheets || suggestion.sheets;
  }
  sheets = sheets || 1;

  // 两条路：自适应按密度分配格位（快切区多给格），否则退回"并段到 k 格"
  const relCuts = scan.cuts.map((c) => c.t - winStart);
  let cellRanges;
  if (adaptive && relCuts.length > 0) {
    cellRanges = planCellRanges({
      duration: winDur, cuts: relCuts, cells: cells * sheets, speech, audioEvents,
    })
      .map((r) => ({ from: r.from + winStart, to: r.to + winStart, density: r.density }));
  } else {
    const segs = segmentsFromCuts(winDur, relCuts, 0.4, winStart);
    cellRanges = fitSegments(segs, cells * sheets, { minGap })
      .map(([a, b]) => ({ from: a, to: b, density: 1 }));
  }
  const groups = [];
  for (let i = 0; i < sheets; i++) groups.push(cellRanges.slice(i * cells, (i + 1) * cells));

  // textOnly：只重算"格 → 时间段 → 台词"，一帧都不解、一张图都不拼。
  // 用途：总览文本被宿主截断后，按 cellRange 分批把剩下的台词取回来（第二次调用命中缓存，几乎瞬时）。
  if (textOnly) {
    const cellsMeta = [];
    let n = 0;
    for (const group of groups) {
      const aligned = alignCells(group, transcriptInfo?.segments ?? []);
      group.forEach(({ from: a, to: b }, gi) => {
        n += 1;
        const t = aligned[gi] ?? null;
        cellsMeta.push({
          i: n,
          t_start: +a.toFixed(3),
          t_end: +b.toFixed(3),
          ...(t?.text ? { text: t.text, charsPerSec: t.charsPerSec } : {}),
        });
      });
    }
    return {
      info,
      window: { from: winStart, to: winStart + winDur, duration: winDur },
      cuts: scan.cuts,
      summary: scan.summary,
      threshold: scan.threshold,
    ...(scan.degraded ? { degraded: scan.degraded } : {}),
      cached: Boolean(scan.cached),
      audio: null,
      transcript: transcriptInfo
        ? { source: transcriptInfo.source, model: transcriptInfo.model ?? null,
          segments: (transcriptInfo.segments ?? []).length }
        : null,
      plan: { cells, sheets, adaptive, pick, burn, minGap, reason: suggestion?.reason ?? 'explicit', bursts: [] },
      sheets: [],
      cells: cellsMeta,
      textOnly: true,
      ...(sourceInfo ? { source: sourceInfo } : {}),
      totalDuration: +cellRanges.reduce((n2, r) => n2 + (r.to - r.from), 0).toFixed(3),
    };
  }

  const out = [];
  let index = 0;
  let fallbacks = 0;
  for (const [si, group] of groups.entries()) {
    if (group.length === 0) continue;
    const { cols, rows } = bestLayout(Math.max(1, group.length), info.aspect);
    // 有音频带时先扣掉条带占用的预算：layoutCanvas 与 composeSheet 必须用**同一个** budget，
    // 否则取帧尺寸和拼图尺寸不一致，图会变成斜条纹（踩过）
    const cellBudget = stripAudio ? Math.round(budget * 0.9) : budget;
    const { width, height, cellW, cellH } = layoutCanvas(cols, rows, info.aspect, cellBudget);
    const aligned = alignCells(group, transcriptInfo?.segments ?? []);
    const frames = [];
    const cellMeta = [];
    for (const [gi, { from: a, to: b }] of group.entries()) {
      index += 1;
      const frame = await extractFrameWithFallback({
        input, remote: remoteFrame, at: a, dur: b - a, cellW, cellH, ffmpegPath, pick,
      });
      if (frame.via === 'local-fallback') fallbacks += 1;
      frames.push({ buffer: frame.buffer, index });
      const text = aligned[gi] ?? null;
      // 这一格里切了几刀 —— 快闪蒙太奇的"速度"就是这个数字，模型不用自己数刻度
      const cellCuts = scan.cuts.filter((c) => c.t >= a && c.t < b).length;
      cellMeta.push({
        i: index,
        sheet: si + 1,
        t_start: +a.toFixed(3),
        t_end: +b.toFixed(3),
        t_frame: +frame.t.toFixed(3),
        ...(cellCuts > 0 ? { cuts: cellCuts } : {}),
        ...(frame.sharp !== undefined ? { sharp: +frame.sharp.toFixed(1) } : {}),
        ...(text?.text ? { text: text.text, charsPerSec: text.charsPerSec } : {}),
      });
    }
    let sheet = composeSheet({
      frames, cols, rows, cellAspect: info.aspect, budget: cellBudget, burn, badgeRatio,
    });
    if (stripAudio) {
      // 条带高度按"宽的 5.5%"会在大长条上失控（2476px 宽 → 136px 高，占掉 37% 画面），
      // 所以同时受格高的 40% 约束。
      const stripH = Math.max(24, Math.min(Math.round(width * 0.055), Math.round(cellH * 0.28)));
      sheet = addAudioStrip(sheet, {
        loudness: stripAudio, silences: stripAudio.silences, cuts: scan.cuts.map((c) => c.t),
        window: { from: winStart, to: winStart + winDur }, stripH,
      });
    }
    out.push({
      sheet: si + 1, cols, rows, cellW, cellH,
      width: sheet.width, height: sheet.height, buffer: sheet.buffer, cells: cellMeta,
      ...(sheet.stripH ? { stripH: sheet.stripH } : {}),
      ...(encode ? { png: await encodePngBuffer(sheet.buffer, sheet.width, sheet.height, { ffmpegPath }) } : {}),
    });
  }

  const totalDuration = +cellRanges.reduce((n, r) => n + (r.to - r.from), 0).toFixed(3);

  // 记一笔"看过什么"：下次 probe 能告诉模型"这部片子你看过"，避免重新描述一遍。
  // 失败不影响结果（记忆是锦上添花）。
  // 必须 await：不 await 的话下一次 probe 可能读不到这一笔（实测踩到，少了一整段）
  await remember(info, {
    from: winStart, to: winStart + winDur, cells: cellRanges.length, cuts: scan.cuts.length,
  }).catch(() => {});

  return {
    info,
    window: { from: winStart, to: winStart + winDur, duration: winDur },
    cuts: scan.cuts,
    summary: scan.summary,
    threshold: scan.threshold,
    ...(scan.degraded ? { degraded: scan.degraded } : {}),
    cached: Boolean(scan.cached),
    // 链接来源的元信息（本地文件时没有这一段）。直链不在里面，那是临时凭证。
    ...(sourceInfo ? { source: sourceInfo } : {}),
    // 有高清直链却有格子落了回来 —— 要报，否则"这格怎么这么糊"没有解释
    ...(fallbacks > 0 ? { frameFallbacks: fallbacks } : {}),
    audio: stripAudio
      ? {
        ...stripAudio,
        events: allEvents,
        summary: describeAudio(stripAudio, winDur),
      }
      : null,
    transcript: transcriptInfo
      ? { source: transcriptInfo.source, model: transcriptInfo.model ?? null,
        segments: (transcriptInfo.segments ?? []).length,
        // 全片口径（不是"格内文本"口径）：字/秒是判定内容类型最稳的一个数字
        chars: (transcriptInfo.segments ?? []).reduce((n, seg) => n + String(seg.text ?? '').length, 0),
        charsPerSec: +(((transcriptInfo.segments ?? []).reduce((n, seg) => n + String(seg.text ?? '').length, 0))
          / Math.max(1, winDur)).toFixed(2),
        ...(transcriptInfo.chunks ? { chunks: transcriptInfo.chunks } : {}),
        ...(transcriptInfo.suspect ? {
          suspect: transcriptInfo.suspect, suspectDetail: transcriptInfo.suspectDetail,
        } : {}),
        ...(transcriptInfo.termsFixed ? { termsFixed: transcriptInfo.termsFixed } : {}),
        ...(textInSilence ? { textInSilence } : {}),
        ...(transcriptInfo.error ? { error: transcriptInfo.error } : {}) }
      : null,
    plan: {
      cells, sheets, adaptive, pick, burn, minGap,
      reason: suggestion?.reason ?? 'explicit',
      bursts: findBursts(relCuts, winDur).map((b) => ({
        from: +(b.from + winStart).toFixed(2), to: +(b.to + winStart).toFixed(2),
        shots: b.shots, density: b.density,
      })),
    },
    sheets: out,
    totalDuration,
  };
}

/** 把结果编码成 PNG 落盘（CLI 用；插件走附件服务，不落盘） */
export async function saveStoryboards(result, outPath, { ffmpegPath = DEFAULT_FFMPEG, quality } = {}) {
  const paths = [];
  for (const s of result.sheets) {
    // 多张图时要保证文件名唯一：原来只认 `.png` 后缀，
    // 传 `out.jpg` 时替换不生效 → 每张都写到同一个路径，最后只剩最后一张。
    const path = result.sheets.length === 1
      ? outPath
      : withSheetSuffix(outPath, s.sheet);
    await encodeRaw(s.buffer, s.width, s.height, path, { ffmpegPath, quality });
    paths.push(path);
  }
  return paths;
}

/** `out.png` + 2 → `out-2.png`；`out.jpg` + 2 → `out-2.jpg`（任何扩展名都成立） */
export function withSheetSuffix(outPath, sheet) {
  const m = /^(.*?)(\.[^./\\]+)?$/.exec(String(outPath));
  const base = m?.[1] ?? outPath;
  const ext = m?.[2] ?? '';
  return `${base}-${sheet}${ext}`;
}

const tc = (t) => {
  const m = Math.floor(t / 60);
  return `${String(m).padStart(2, '0')}:${(t % 60).toFixed(2).padStart(5, '0')}`;
};

/**
 * 给模型的文本块：可寻址的格位表。
 * 编号同时给"序号"和"行列"，任一读不出来还能靠另一个定位。
 */
/**
 * 数一下有多少句台词落在"被判静音"的区间里。
 *
 * 两种成因都值得知道：**轻声说话被 -40 dB 阈值吞了**，或者 **ASR 在静音段编了字**。
 * 纯内存比较（句子数 × 静音段数，实测 222 × 11 ≈ 2400 次），不额外跑 ffmpeg，<1ms。
 *
 * @param {Array<{from:number,to:number}>} segments
 * @param {Array<{from:number,to:number}>} silences
 * @param {number} ratio 句子有多大比例压在静音里才算（默认 0.6）
 */
export function countTextInSilence(segments, silences, ratio = 0.6) {
  if (!segments?.length || !silences?.length) return 0;
  let n = 0;
  for (const seg of segments) {
    const dur = Math.max(0.01, seg.to - seg.from);
    let overlap = 0;
    for (const gap of silences) {
      const a = Math.max(seg.from, gap.from);
      const b = Math.min(seg.to, gap.to);
      if (b > a) overlap += b - a;
    }
    if (overlap / dur > ratio) n += 1;
  }
  return n;
}

/**
 * video_probe 的文本：容器信息 + 一个"该怎么读"的建议。
 * 不扫描、不取帧，只花 ffprobe 的时间（几毫秒）。
 */
export async function formatProbe(info) {
  const mins = info.duration / 60;
  const lines = [
    `<video path="${info.path ?? ''}" duration="${info.duration.toFixed(2)}" ` +
      `size="${info.width}x${info.height}" fps="${info.fps.toFixed(2)}" ` +
      `aspect="${info.aspect.toFixed(3)}" rotation="${info.rotation}" ` +
      `video="${info.videoCodec}" container="${info.container}" ` +
      `audio="${info.hasAudio ? (info.audioCodec ?? 'yes') : 'no'}" ` +
      `subtitles="${info.hasSubtitle ? 'yes' : 'no'}" />`,
  ];
  // 两种读法，**明确标出哪种会剧透**。
  // 追剧情时不能先看全片总览：一张盖住片尾的图等于把结局摆在你脸上。
  // 短片不铺这些：一句话能说完的片子，给一条建议就够，别用通用模板灌水。
  if (mins > 8) {
    // 只看时长给个粗估（不调 suggest：probe 没扫描，cuts=0 会被当成"单镜头"，算出 4 格那种假结果）
    const estCells = Math.min(16, Math.max(4, Math.round(info.duration / 40)));
    const estSheets = Math.min(4, Math.ceil(info.duration / 300));
    lines.push(`one-shot overview would be about ${estCells} cells x ${estSheets} image(s) ` +
      '(duration-only estimate; cut density can change it).');
    lines.push('Two ways to read this, pick by what you need:');
    lines.push(`  • STRUCTURE (spoils the ending): one wide pass — ` +
      `video_storyboard({ input, cells: 16, sheets: 4 }) → whole film in 4 images, ` +
      `then open the 2-3 sections that look interesting. ~${(info.duration / 30).toFixed(0)} s of CPU.`);
    lines.push(`  • SEQUENCE (no spoilers, like watching it): ` +
      `video_storyboard({ input, from: 0, to: 300 }) then 300-600, 600-900 … one window at a time, ` +
      `never looking ahead. Each window is ~${Math.ceil(mins / 5)} calls in total; ` +
      'the scan of each window is cached, so re-reading a stretch is free.');
  } else if (mins < 1) {
    lines.push(`under a minute (${info.duration.toFixed(0)}s): one call is enough.`);
  } else {
    lines.push(`Short (${mins.toFixed(0)} min): one call is enough. Following a story rather than ` +
      'analysing structure? Use `from`/`to` windows so later scenes are not on screen early.');
  }
  const seen = await describeMemory(info).catch(() => null);
  if (seen) lines.push(`seen before: ${seen}`);

  if (!info.hasAudio) lines.push('no audio track: transcript will be empty, the grid is visual only.');
  else if (!info.hasSubtitle) lines.push('no subtitle track: transcript (if any) must come from ASR.');
  return lines.join('\n');
}

/**
 * 链接版的 probe 清单。和本地版的关键差别：**什么都没下载**，所以要说清楚"下一步会发生什么"，
 * 否则模型会以为已经看过这条视频了。
 */
export function formatRemoteProbe(remote) {
  const lines = [`link: ${remote.url}`];
  if (remote.title) lines.push(`title: ${remote.title}`);
  if (Number.isFinite(remote.duration)) lines.push(`duration: ${remote.duration.toFixed(2)}s`);
  lines.push(remote.heights?.length
    ? `available: ${remote.heights.map((h) => `${h}p`).join(', ')} (max ${remote.maxHeight}p)`
    : 'available: no video formats reported');
  lines.push(`auth: ${remote.auth}${remote.auth === 'anonymous' ? ' (resolution not guaranteed)' : ''}`);

  const dur = Number(remote.duration) || 0;
  if (dur > 1200) {
    lines.push(`note: ${Math.round(dur / 60)} min long — read it in windows (from/to) instead of one pass.`);
  }
  lines.push('nothing was downloaded yet. video_storyboard with this link downloads a low-res copy ' +
    'once (fast, and cached afterwards); video_zoom then reads the original stream at ' +
    `${remote.maxHeight ?? 1080}p for close-ups.`);
  return lines.join('\n');
}

/** 三档台词预算（字符）：low 只判断"这段在讲什么"，high 要能引用原话 */
export const DETAIL_CHARS = { low: 60, med: 120, high: 400 };

/**
 * 在**句末**截断，而不是从第 N 个字符硬切。
 *
 * 硬切的坏处很具体：`"…而且都混在一"` 这种半截句子会让模型以为台词本身就这样断了。
 * 规则：
 *  1. 文本不超限 → 原样返回；
 *  2. 在 `[limit*0.5, limit]` 里找最后一个句末标点（中英都认），在那之后截且补 `…`；
 *  3. 找不到 → 退回硬切（总比丢了整段好）。
 */
export function truncateAtSentence(text, limit) {
  const src = String(text ?? '');
  if (!(limit > 0) || src.length <= limit) return src;
  // 省略号本身占一格：内容只取 limit-1，保证总长不超过 limit（方便预算）
  const room = Math.max(1, limit - 1);
  const head = src.slice(0, room);
  const re = /[。！？；…!?;]|\.(?=\s|$)/g;
  let best = -1;
  let m;
  while ((m = re.exec(head)) !== null) {
    if (m.index + 1 >= Math.floor(room * 0.5)) best = m.index + 1;
  }
  if (best > 0) return `${src.slice(0, best)}…`;
  return `${head.trimEnd()}…`;
}

/**
 * 多窗口批处理的汇总表（Markdown）。
 *
 * 一部 2 小时半的电影按 5 分钟读 = 24 个窗口，人只需要看这一张表：
 * 它把 24 张图串成一条时间线。
 */
export function formatTimeline(rows, { title = 'batch timeline' } = {}) {
  const total = rows.reduce((n, r) => n + (r.to - r.from), 0);
  const totalCells = rows.reduce((n, r) => n + r.cells, 0);
  const totalChars = rows.reduce((n, r) => n + (r.chars ?? 0), 0);
  const lines = [
    `# ${title}`,
    '',
    `- windows: **${rows.length}** · total ${tc(total)} · cells ${totalCells} · transcript ${totalChars} chars`,
    `- tokens: ${rows.length} image(s) ≈ **${rows.length * 384}** (one image per window)`,
    '',
    '| # | window | cells | cuts | chars | image |',
    '|---|---|---|---|---|---|',
  ];
  for (const r of rows) {
    lines.push(`| ${r.index} | ${tc(r.from)}–${tc(r.to)} | ${r.cells} | ${r.cuts} | ${r.chars ?? 0} | \`${r.image}\` |`);
  }
  return lines.join('\n');
}

/**
 * 把结果渲染成给模型看的文本清单。
 *
 * **为什么要有预算**：一部 2 小时 35 分的电影，64 个 cell 的完整清单约 75KB。宿主对单次工具
 * 结果有上限，超出部分会被折进磁盘上的溢出文件，而模型往往不会去读它（实测发生过：44% 的文本
 * 被折叠，中段 44 分钟的台词等于没给）。所以这里做三件事：
 *
 *   1. 每格台词默认截到 `maxCellChars` 字符 —— 总览只需要"这一段在说什么"；
 *   2. 总量超过 `maxChars` 时**在 cell 边界**截断，并写明续读方式（不切断句子、不丢格）；
 *   3. `cellRange` 只取一段，配合 `textOnly` 二次调用可以零成本把剩下的台词取回来。
 *
 * @param {object} result runStoryboard 的返回值
 * @param {{maxCellChars?:number, maxChars?:number, cellRange?:[number,number]}} opts
 */
export function formatManifest(result, {
  maxCellChars = 120, maxChars = 24_000, cellRange = null,
} = {}) {
  const { info, window: win, plan } = result;
  const hasSheets = Boolean(result.sheets?.length);
  const sheet0 = result.sheets?.[0];

  // 统一成一条平坦的 cell 列表：有图时从 sheets 里取（带行列），textOnly 时从 cells 里取
  const all = [];
  if (hasSheets) {
    for (const sheet of result.sheets) {
      for (const c of sheet.cells) all.push({ ...c, cols: sheet.cols, sheet: sheet.sheet });
    }
  } else if (Array.isArray(result.cells)) {
    for (const c of result.cells) all.push(c);
  }
  const total = all.length;
  const [lo, hi] = Array.isArray(cellRange) && cellRange.length === 2
    ? [Math.max(1, cellRange[0]), Math.min(total, cellRange[1])]
    : [1, total];
  const picked = all.filter((c) => c.i >= lo && c.i <= hi);

  const lines = [
    `<storyboard path="${info.path ?? 'video'}" duration="${info.duration.toFixed(2)}" ` +
      `window="${win.from.toFixed(2)}-${win.to.toFixed(2)}" ` +
      `image="${hasSheets ? `${sheet0.width}x${sheet0.height}` : 'none (text only)'}" ` +
      `grid="${plan.cells} cells x ${plan.sheets} image(s)" burn="${plan.burn}"` +
      `${result.audio ? ` footer="audio-strip(${sheet0.stripH ?? 0}px)"` : ''}` +
      `${result.transcript?.source ? ` transcript="${result.transcript.source}"` : ''}` +
      (cellRange ? ` cells="${lo}-${hi} of ${total}"` : '') +
      (result.cuts?.length
        ? ` cuts="${result.cuts.length} (avg ${(result.window.duration / Math.max(1, result.cuts.length)).toFixed(1)}s)"`
        : '') + '>',
  ];
  if (result.audio) {
    lines.push('footer strip shares the timeline: teal bars = loudness (taller = louder), ' +
      'grey blocks = silence, yellow ticks = cut points.');
  }
  // 这一句专治"把格的起点当画面时刻"：标题板常常出现在格的中后段，
  // 不给 frame@ 的话，模型会以为格首就是标题板，整段判断提前几十秒。
  if (plan.pick === 'sharp' && picked.some((c) => Number.isFinite(c.t_frame))) {
    lines.push('frame@ = the exact moment the cell\'s picture was taken (sharpest of 3 candidates), ' +
      'which is NOT the cell start — a title card showing at frame@ belongs to a cell that begins earlier.');
  }
  if (picked.some((c) => c.broken)) {
    lines.push('a [m:ss.s] marker inside a cell means the speech breaks there: that cell covers two ' +
      'separate statements, so do not treat the cell start as the start of the new topic.');
  }
  // 链接来源：模型必须知道"我看的是一份下载副本，而且只有 360p"。
  // 不说的话，它会把"这格字看不清"归因成视频本身糊，而不是"扫描用的是低清版、细看要 zoom"。
  if (result.source) {
    const s = result.source;
    lines.push(`source: ${s.url} (auth=${s.auth}${s.cached ? ', cached' : ''}); ` +
      `scanned at ${s.scanActual ?? s.scanHeight}p` +
      (s.maxAvailable ? `, source max ${s.maxAvailable}p` : '') +
      (s.zoomTarget ? `; video_zoom reads ${s.zoomTarget}p from the original stream` : '') + '.');
    if (Array.isArray(s.degraded) && s.degraded.length > 0) {
      const cap = s.maxAvailable ? `${s.maxAvailable}p` : 'a lower tier';
      lines.push(`source limit: this video tops out at ${cap} (${s.degraded.join(', ')}) — ` +
        'that is the source ceiling, not a fetch failure, so asking for more will not help.');
    }
    if (s.auth === 'anonymous') {
      lines.push('warning: scanned anonymously, so the resolution was not guaranteed. ' +
        'Configure cookies to get a predictable source tier.');
    }
  }
  if (result.frameFallbacks) {
    lines.push(`${result.frameFallbacks} cell(s) fell back to the low-resolution copy ` +
      '(direct URL expired or the CDN hiccuped) — those cells are softer than the rest.');
  }
  // 切点数字不可信时必须说出来 —— 否则模型会拿 cuts=N 当节奏依据
  if (result.degraded === 'motion') {
    lines.push('cut count unreliable here: median shot under 0.5s with many frames above the threshold — ' +
      'this is likely continuous camera motion being cut into pieces. Read the pictures; do not quote cuts=N as pacing.');
  }

  // 快剪爆发点：只给"密度"和"每格几刀"还不够——模型不知道"哪一段是连拍的"。
  // 这一行把片段区间和镜头数直接说出来，并给出可执行的下一步。
  if (result.plan?.bursts?.length) {
    const top = [...result.plan.bursts].sort((a, b) => (b.shots ?? 0) - (a.shots ?? 0)).slice(0, 3);
    lines.push(`fast cuts: ${top.map((b) => `${tc(b.from)}-${tc(b.to)} (${b.shots} shots)`).join(', ')}` +
      ' — video_zoom({ from, to, cells: 6, minGap: 0.4 }) splits these into single shots.');
  }

  // 切点不多时直接列出精确时间：条带只能读个 ±2~4 秒的大概，而这一行是 0.01 秒的准确值。
  // 多于 24 个就不列（总览只需要知道"多密"，精确值留给 zoom）。
  const inWin = (result.cuts ?? []).filter((c) => c.t >= win.from && c.t <= win.to);
  if (inWin.length > 0 && inWin.length <= 24) {
    lines.push(`cut points (${inWin.length}): ${inWin.map((c) => tc(c.t)).join(', ')}`);
  }
  // 声音事件只写"稀疏"的片子：口播片几十次起伏会把真正重要的信息淹掉
  if (result.audio?.events?.length && result.audio.events.length <= 20) {
    const list = [...result.audio.events]
      .sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta))
      .slice(0, 6)
      .map((e) => `${tc(e.t)} ${e.kind === 'rise' ? '+' : ''}${e.delta}dB`).join(', ');
    lines.push(`audio events (${result.audio.events.length}): ${list}` +
      (result.audio.events.length > 6 ? ', …' : '') +
      ' — the picture may be static here; the change is in the sound.');
  }

  let used = lines.join('\n').length;
  let stoppedAt = null;
  for (const c of picked) {
    const pos = (c.i - 1) % plan.cells;
    // 单图时 "image 1" 是纯冗余（64 格能省 500 字符）；多图时必须保留
    const where = typeof c.cols === 'number'
      ? ` (r${Math.floor(pos / c.cols) + 1}c${(pos % c.cols) + 1}` +
        `${result.sheets.length > 1 ? `, image ${c.sheet}` : ''})`
      : '';
    const text = truncateAtSentence(c.text, maxCellChars);
    // sharp 只留在 JSON 清单里：给模型一个 "479.7" 它无法判断好坏，纯占字符
    // frame@ 只在 pick='sharp' 时给：mid 的取帧时刻就是格中点，模型自己能算，
    // 而 sharp 是"3 个候选里选最锐的那个"，**推不出来** —— 少了它就等于暗示"画面在格首"。
    const showFrame = plan.pick === 'sharp' && Number.isFinite(c.t_frame);
    const head = `cell ${c.i}${where} = ${tc(c.t_start)}-${tc(c.t_end)}` +
      (showFrame ? ` frame@${tc(c.t_frame)}` : '') +
      (c.cuts ? `  cuts ${c.cuts}` : '');
    const body = text ? `${head}\n    "${text}"` : head;
    if (used + body.length + 1 > maxChars) { stoppedAt = c.i - 1; break; }
    lines.push(body);
    used += body.length + 1;
  }

  if (stoppedAt !== null) {
    lines.push(`[text stopped at cell ${stoppedAt} of ${hi} — ` +
      `call again with cellRange: [${stoppedAt + 1}, ${hi}] and textOnly: true to read the rest]`);
  }
  if (result.transcript?.source === 'asr') {
    lines.push('transcript is ASR output (not a subtitle track): technical terms and names may be ' +
      'misheard — cross-check against on-screen text before quoting them.');
    if (result.transcript.termsFixed > 0) {
      lines.push(`${result.transcript.termsFixed} term(s) corrected by the local dictionary (DSH_ASR_TERMS / asr.json "terms")`);
    }
    if (result.transcript.textInSilence > 0) {
      lines.push(`${result.transcript.textInSilence} line(s) of text sit inside a detected silence — ` +
        'either the speech is below the -40 dB gate, or the ASR invented it');
    }
    if (result.transcript.suspect > 0) {
      const detail = (result.transcript.suspectDetail ?? [])
        .map((d) => `${d.from}-${d.to}s (${d.charsPerSec} chars/s, ${d.reason})`).join(', ');
      lines.push(`${result.transcript.suspect} segment(s) ignored as non-speech: ${detail}` +
        (result.transcript.suspect > 3 ? ', …' : ''));
    }
  }
  if (result.transcript?.source === 'asr-failed') {
    lines.push(`transcript unavailable: ${result.transcript.error ?? 'ASR call failed'}`);
  }
  if (result.transcript?.source === 'asr-empty') {
    lines.push('transcript: ASR ran and found no speech here — treat this as a video with no dialogue ' +
      '(this is different from a subtitle-track failure). Read the pictures and the audio strip.');
  }
  if (result.transcript?.source === 'no-audio') lines.push('no audio track: grid is visual only');
  lines.push(`total ${picked.length} of ${total} cells shown` +
    (hasSheets ? '; unlabeled cells are padding, not content.' : '.'));
  lines.push('</storyboard>');
  return lines.join('\n');
}
