# @deepseek-ai/dsh-tool-microsandbox

[English](README.md) | 中文

面向 [`ctx.microsandbox`](../sandbox-microsandbox/) 服务的模型可见 microsandbox microVM 工具：`microsandbox_exec`（启动镜像或复用命名沙箱、运行精确 argv、返回带 guest 退出码的捕获输出）和 `microsandbox_fs`（无需挂载即可读/写/列出 guest 文件）。每次调用都继承 provider 的失败关闭契约：不合格宿主、禁用 provider 或被拒操作会呈现 `MICROSANDBOX_UNAVAILABLE` / 结构化 runner 失败，而不是无约束回退。

[microsandbox 适配 Agent Note](../../../.agents/notes/proposed/architecture/2026-08-08-microsandbox-adaptation.md) 拥有其形态、门和迁移计划。

## 模型体验

### `microsandbox_exec`

#### 模型看到什么

模型看到生成的 `microsandbox_exec` schema（精确 argv，绝不 shell 引用）。结果携带捕获的 stdout/stderr、guest 退出码，以及 runner/载荷区分：沙箱从未运行时 `runnerFailed` 带结构化错误；调用方截止时间触发时 `timedOut`/`aborted`；渲染输出为捕获文本加分类行（`[microsandbox: exit code N]`、`[microsandbox: runner failed (CODE)]`，适用时追加 `timed out`/`aborted` 标记）。

##### Schema

```markdown
| Arg | Type | Notes |
|---|---|---|
| `image` | string (required) | OCI image reference (e.g. `python:alpine`) to boot. |
| `argv` | string[] (required) | Exact command line: program followed by arguments, never shell-quoted. |
| `name` | string | Reuse a named sandbox instead of creating an ephemeral one. |
| `timeoutMs` | number | Caller-owned deadline; the provider kills the payload on fire. |
| `workdir` | string | Working directory inside the guest. |
| `user` | string | Guest user to run as. |
```

#### Token 影响

输出为 guest 捕获的 stdout/stderr 原文（去除尾部换行）；不添加提示词或 schema 文本。

#### KV 缓存影响

无直接失效；工具结果按调用返回，不缓存。

### `microsandbox_fs`

#### 模型看到什么

模型看到生成的 `microsandbox_fs` schema。`read` 返回文件内容，`list` 返回换行连接的条目，`write` 返回写入确认。

##### Schema

```markdown
| Arg | Type | Notes |
|---|---|---|
| `operation` | string (required) | `read`, `write`, or `list` on the guest filesystem. |
| `sandbox` | string (required) | Sandbox name to operate on. |
| `path` | string (required) | Absolute guest path. |
| `content` | string | Content to write (required when operation is `write`). |
```

#### Token 影响

输出为文件内容或条目列表原文；不添加提示词或 schema 文本。

#### KV 缓存影响

无直接失效；工具结果按调用返回，不缓存。

## 已知限制与延期工作

- 工具集最小：仅 exec 与 guest 文件系统。生命周期管理、镜像管理、卷、机密和网络策略不作为工具暴露，通过 provider 请求时失败关闭。
- 真实宿主验收：**Windows WHP 已通过**且 **Linux KVM 已通过**（real-host.e2e.ts 各 3/3，2026-08-08；Linux 为 WSL2 嵌套虚拟化宿主）。**macOS Apple Silicon 不在验收范围内**（无宿主；该平台在随附组合中保持不可用）。
- 工具已挂载进随附 `dsh-base` 组合并启用 provider；在没有硬件虚拟化的宿主上，限定门报告 `MICROSANDBOX_UNAVAILABLE`，每个工具调用失败关闭。
