# @deepseek-ai/dsh-tool-microsandbox

English | [中文](README.zh.md)

Model-facing microsandbox microVM tools over the [`ctx.microsandbox`](../sandbox-microsandbox/) service: `microsandbox_exec` (boot an image or reuse a named sandbox, run an exact argv, return captured output with the guest exit code) and `microsandbox_fs` (read/write/list one guest file without mounting). Every call inherits the provider's fail-closed contract: an unqualified host, a disabled provider, or a rejected operation surfaces `MICROSANDBOX_UNAVAILABLE` / a structured runner failure rather than an unconfined fallback.

The [microsandbox adaptation Agent Note](../../../.agents/notes/proposed/architecture/2026-08-08-microsandbox-adaptation.md) owns the shape, gates, and migration plan.

## Model Experience

### `microsandbox_exec`

#### What the model sees

The model sees the generated `microsandbox_exec` schema (exact argv, never shell-quoted). The result carries the captured stdout/stderr, the guest exit code, and the runner/payload distinction: `runnerFailed` with a structured error when the sandbox never ran, `timedOut`/`aborted` when a caller deadline fired; rendered output is the captured text plus a classification line (`[microsandbox: exit code N]`, `[microsandbox: runner failed (CODE)]`, with `timed out`/`aborted` markers appended when applicable).

##### Schema

```markdown
| Arg | Type | Notes |
|---|---|---|
| `image` | string (required) | OCI image reference (e.g. `python:alpine`) to boot. |
| `argv` | string[] (required) | Exact command line: program followed by arguments, never shell-quoted. |
| `name` | string | Reuse a named sandbox instead of creating an ephemeral one. |
| `timeoutMs` | number | Caller-owned deadline; the provider kills the payload on fire. |
| `workdir` | string | Working directory inside the guest. |
| `user` | string | Guest user to run as. |
```

#### Token effect

Output is the guest's captured stdout/stderr verbatim (trailing newlines trimmed); no prompt or schema text is added.

#### KV Cache effect

No direct invalidation; tool results are per-call and not cached.

### `microsandbox_fs`

#### What the model sees

The model sees the generated `microsandbox_fs` schema. File content for `read`, newline-joined entries for `list`, or a write confirmation for `write`.

##### Schema

```markdown
| Arg | Type | Notes |
|---|---|---|
| `operation` | string (required) | `read`, `write`, or `list` on the guest filesystem. |
| `sandbox` | string (required) | Sandbox name to operate on. |
| `path` | string (required) | Absolute guest path. |
| `content` | string | Content to write (required when operation is `write`). |
```

#### Token effect

Output is the file content or entry list verbatim; no prompt or schema text is added.

#### KV Cache effect

No direct invalidation; tool results are per-call and not cached.

## Known Limitations and Deferred Work

- The tool set is minimal: exec and guest filesystem only. Lifecycle management, image management, volumes, secrets, and network policy are not exposed as tools and fail closed when requested through the provider.
- Real-host acceptance: **Windows WHP passed** and **Linux KVM passed** (real-host.e2e.ts 3/3 each on 2026-08-08, Linux on a WSL2 nested-virtualization host). **macOS Apple Silicon is not in the acceptance scope** (no host; the platform stays unavailable in shipped compositions).
- The tools are mounted in the shipped `dsh-base` bundle with the provider enabled; on hosts without hardware virtualization the qualification gate reports `MICROSANDBOX_UNAVAILABLE` and every tool call fails closed.
