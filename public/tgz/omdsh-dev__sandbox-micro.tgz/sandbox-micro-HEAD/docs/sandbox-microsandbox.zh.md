# @deepseek-ai/dsh-sandbox-microsandbox

[English](README.md) | 中文

面向 DeepSeek Harness 的 Microsandbox microVM 后端：基于精确钉住的官方 [`microsandbox`](https://github.com/superradcompany/microsandbox) node-ts SDK 的 DSH 自有 microVM 执行服务。[microsandbox 适配 Agent Note](../../../.agents/notes/proposed/architecture/2026-08-08-microsandbox-adaptation.md) 拥有其形态、门和迁移计划。

该 provider **不是** `SandboxProvider` 后端：microsandbox 是拥有自有内核和文件系统世界的 microVM，而沙箱接缝承诺的是同世界进程约束。MXC 与本地 provider 仍是约束后端；本服务是与之并列的环境连贯能力。

provider 以包自有方式解析 `msb` 二进制（`@superradcompany/microsandbox-<triple>` 平台包，回退到 `~/.microsandbox/bin`），对宿主的硬件虚拟化姿态分类（Linux 上的 KVM、macOS 上的 Apple Silicon Hypervisor.framework、Windows 上的 WHP），并把每个操作都置于对精确解析二进制的有界功能限定门之后。不合格宿主以 `MICROSANDBOX_UNAVAILABLE` 失败关闭——没有降级或无约束路径。

依赖精确钉住（`microsandbox@0.6.7`）：0.6.8 版本从未发布其 `linux-x64-gnu` 平台包，因此 0.6.7 是平台矩阵完整的最新版本。每次更新都要审慎重钉并重新验证完整平台矩阵。

## 服务表面（`ctx.microsandbox`）

`exec(request)` 从请求的镜像启动沙箱（给定命名沙箱时复用，否则创建临时一次性沙箱），挂载任何 bind 卷，通过官方 SDK 以请求的 env/cwd/user 运行精确 `argv`，并返回捕获的 guest 退出码、stdout、stderr，以及 runner 失败与载荷退出之区分。provider 拥有截止时间：`timeoutMs` 与可选 `signal` 融合为单个信号，触发时杀掉载荷并把结果分类为 `timedOut`（provider 超时）或 `aborted`（上游取消）——绝不是 runner 失败。`create(request)` 启动命名沙箱并保持运行；`start`/`stop`/`remove`/`list` 管理生命周期。`readFile`/`writeFile`/`listDir` 在不挂载的情况下操作运行中沙箱的 guest 文件系统。`listImages`/`removeImage` 管理缓存镜像存储；`createVolume`/`listVolumes`/`removeVolume` 管理命名卷。

provider 不做任何 shell 引用，绝不构造原始 `msb` 命令行；SDK 被隔离在可注入的 `MicrosandboxRuntime` 之后，因此测试无需硬件虚拟化即可重放结构化输出。参数校验（非空名称/镜像/argv、绝对 guest 路径、绝对 bind 卷宿主路径与 guest 挂载点）、启用门和限定门都在触及 runtime 之前执行。

## 模型体验

间接：通过未来的 exec/生命周期消费方呈现，它们拥有 microVM 服务的任何模型可见投影。

#### KV 缓存影响

无直接失效；本包不引入模型可见输入。

## 已知限制与延期工作

- 镜像拉取尚未实现（SDK 在 create 时拉取）；provider 目前交付限定门、二进制解析、平台分类、`exec`、沙箱生命周期、guest 文件系统操作、缓存镜像列出/删除、命名卷管理和 bind 卷校验（Agent Note 迁移计划第 2–3 步）。
- Linux microVM 运行需要 `/dev/kvm`；没有硬件虚拟化的宿主（包括当前宿主）报告不可用。
- 真实宿主验收：**Windows WHP 已通过**（real-host.e2e.ts 3/3，2026-08-08）且 **Linux KVM 已通过**（real-host.e2e.ts 3/3，WSL2 嵌套虚拟化宿主，2026-08-08）。**macOS Apple Silicon 不在验收范围内**（无宿主；该平台在随附组合中保持不可用）。没有记录通过的平台在随附组合中保持不可用。
- 机密、网络策略和快照不在第一版范围内，请求时失败关闭。
