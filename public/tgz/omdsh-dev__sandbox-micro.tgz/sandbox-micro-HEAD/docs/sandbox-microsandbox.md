# @deepseek-ai/dsh-sandbox-microsandbox

English | [中文](README.zh.md)

Microsandbox microVM backend for the DeepSeek Harness: a DSH-owned microVM execution service over the exactly pinned official [`microsandbox`](https://github.com/superradcompany/microsandbox) node-ts SDK. The [microsandbox adaptation Agent Note](../../../.agents/notes/proposed/architecture/2026-08-08-microsandbox-adaptation.md) owns the shape, gates, and migration plan.

This provider is **not** a `SandboxProvider` backend: microsandbox is a microVM with its own kernel and filesystem world, while the sandbox seam promises same-world process confinement. The MXC and local providers remain the confinement backends; this service is an environment-coherent capability alongside them.

The provider resolves the `msb` binary package-owned (the `@superradcompany/microsandbox-<triple>` platform package, falling back to `~/.microsandbox/bin`), classifies the host's hardware-virtualization posture (KVM on Linux, Apple Silicon Hypervisor.framework on macOS, WHP on Windows), and gates every operation behind a bounded functional qualification of the exact resolved binary. An unqualified host fails closed with `MICROSANDBOX_UNAVAILABLE` — no degraded or unconfined path.

The dependency is pinned exactly (`microsandbox@0.6.7`): the 0.6.8 release never published its `linux-x64-gnu` platform package, so 0.6.7 is the newest release whose platform matrix is complete. Re-pin deliberately and re-verify the full platform matrix on every update.

## Service surface (`ctx.microsandbox`)

`exec(request)` boots a sandbox from the request's image (reusing a named sandbox when given, ephemeral one-offs otherwise), attaches any bind volumes, runs the exact `argv` with the requested env/cwd/user through the official SDK, and returns the captured guest exit code, stdout, stderr, and a runner-failure-vs-payload-exit distinction. The provider owns the deadline: `timeoutMs` and the optional `signal` fuse into one signal that kills the payload on fire and classifies the outcome `timedOut` (provider timeout) or `aborted` (upstream cancellation) — never a runner failure. `create(request)` boots a named sandbox and keeps it running; `start`/`stop`/`remove`/`list` manage the lifecycle. `readFile`/`writeFile`/`listDir` operate on a running sandbox's guest filesystem without mounting. `listImages`/`removeImage` manage the cached-image store; `createVolume`/`listVolumes`/`removeVolume` manage named volumes.

The provider performs no shell quoting and never constructs raw `msb` command lines; the SDK is isolated behind the injectable `MicrosandboxRuntime` so tests replay structured outputs without hardware virtualization. Validation (non-empty names/images/argv, absolute guest paths, absolute bind-volume host paths and guest mount points), the enable gate, and the qualification gate all run before the runtime is reached.

## Model Experience

Indirectly, through future exec/lifecycle consumers, which own any model-visible projection of the microVM service.

#### KV Cache effect

No direct invalidation; no model-visible input is introduced by this package.

## Known Limitations and Deferred Work

- Image pulling is not implemented yet (the SDK pulls on create); the provider currently ships the qualification gate, binary resolution, platform classification, `exec`, sandbox lifecycle, guest-filesystem operations, cached-image listing/removal, named-volume management, and bind-volume validation (migration plan steps 2–3 of the Agent Note).
- Linux microVM runs require `/dev/kvm`; hosts without hardware virtualization (including the current host) report unavailable.
- Real-host acceptance: **Windows WHP passed** (real-host.e2e.ts 3/3 on 2026-08-08) and **Linux KVM passed** (real-host.e2e.ts 3/3 on a WSL2 nested-virtualization host on 2026-08-08). **macOS Apple Silicon is not in the acceptance scope** (no host; the platform stays unavailable in shipped compositions). A platform without a recorded pass stays unavailable in shipped compositions.
- Secrets, network policy, and snapshots are out of scope for the first iteration and fail closed when requested.
