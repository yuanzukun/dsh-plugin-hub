# `@deepseek-ai/dsh-sandbox-microsandbox`

[English](README.md) | 中文

失败关闭的 microsandbox microVM 能力 DSH profile 组合包。root package 提供 `ctx.microsandbox` provider，并以 `@deepseek-ai/dsh-sandbox-microsandbox/tool` 导出模型可见工具。

## 仓库结构

```text
package.json              # provider/tool 包和 dsh.bundle 清单
cordis.patch.yml          # dormant provider/tool 行
src/                      # provider、runtime、resolver 和 tool subpath
lib/                      # 生成的安装产物
legacy/                   # 旧 DSH 快照的宿主接线补丁，仅作迁移资料
docs/                     # provider/tool 详细说明
tests/provider/            # provider、resolver、SDK 和 host 测试
tests/tool/                # model tool 和 renderer 测试
```

单一 root 产物保持 Git/profile 安装自包含，同时保留两个 Cordis entry：

```yaml
- id: microsandbox
  name: '@deepseek-ai/dsh-sandbox-microsandbox'

- id: tool-microsandbox
  name: '@deepseek-ai/dsh-sandbox-microsandbox/tool'
```

两个行都默认禁用。启用时 profile 必须显式打开 provider 的 `config.enabled: true`，并单独打开 tool 行，避免安装组合包就启动 microVM 能力或向模型暴露工具。

## 能力边界

`ctx.microsandbox` 是环境连贯的 microVM service，不是 `dsh-sandbox` 的同世界 provider。它使用固定版本 `microsandbox@0.6.7` SDK、包自有 `msb` 解析、有界功能限定和失败关闭的平台检查，绝不会退化为无约束宿主执行。

工具 entry 提供：

```text
microsandbox_exec  精确 argv 执行和 captured output
microsandbox_fs    guest 文件读、写和目录列表
```

旧宿主接线补丁保留在 `legacy/` 中，供尚未提供 provider/tool catalog 和 composition 接缝的 DSH 快照使用；新的 bundle 层不修改 DSH 宿主源码。

## 开发

完整 typecheck 需要 sibling checkout：

```text
~/git/deepseek-harness
~/git/sandbox-micro
```

```sh
pnpm install
pnpm run typecheck
pnpm test
pnpm run build
```

`prepare` 直接从 `src/` 构建 provider、invariant 和 tool entry，因此 Git 安装不需要 sibling project references。pnpm 10 可能要求 profile 允许 prepare 脚本；只应批准固定且可信的 checkout。

## 已知限制

- Linux 需要可用 `/dev/kvm`；不支持或未通过限定的 host 保持 unavailable。
- 第一版不纳入 macOS Apple Silicon real-host acceptance。
- Secrets、network policy、snapshots 和 image/volume lifecycle tools 仍是 provider-only 或请求时失败关闭。
- 外部 SDK 和平台二进制固定为 `0.6.7`，需要对应的 registry package。
