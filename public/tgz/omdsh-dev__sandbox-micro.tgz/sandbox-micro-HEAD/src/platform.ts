/**
 * Platform qualification facts for the microsandbox microVM backend.
 *
 * `getPlatformSupport()` is ADVISORY, not the trust decision: the provider's
 * functional qualification (`MicrosandboxProvider.qualificationVerdict`)
 * resolves and probes the exact `msb` binary before any sandbox work. This
 * module only classifies the host's hardware-virtualization posture so the
 * qualification gate can fail fast and report a reason.
 * @module @deepseek-ai/dsh-sandbox-microsandbox/platform
 */

import { statSync } from 'node:fs'

/**
 * The advisory hardware-virtualization posture of the current host.
 * `unknown` means the platform is recognized but the capability cannot be
 * cheaply proven from Node (WHP); the qualification probe still decides.
 */
export type PlatformSupport = 'supported' | 'unsupported' | 'unknown'

/**
 * Classify the host's microVM posture without probing the binary.
 * @param platform - target platform (test seam; defaults to `process.platform`).
 * @param arch - target architecture (test seam; defaults to `process.arch`).
 * @param kvm - whether `/dev/kvm` is present (test seam; defaults to the real check).
 * @returns the advisory posture; only `unsupported` is fail-closed on its own.
 */
export function getPlatformSupport(
  platform: NodeJS.Platform = process.platform,
  arch: string = process.arch,
  kvm: boolean = existsKvm(),
): PlatformSupport {
  switch (platform) {
    case 'linux':
      // KVM is the Linux hypervisor surface; its absence means no microVM.
      return kvm ? 'supported' : 'unsupported'
    case 'darwin':
      // Hypervisor.framework is Apple-Silicon-only in microsandbox's support
      // matrix; x64 macOS builds are not a declared platform.
      return arch === 'arm64' ? 'supported' : 'unsupported'
    case 'win32':
      // WHP presence is not cheaply provable from Node; the functional probe
      // of the pinned `msb` binary is the deciding check.
      return 'unknown'
    default:
      return 'unsupported'
  }
}

/**
 * Whether the Linux KVM device node is present. Read access is not required.
 * @returns true when `/dev/kvm` exists as a character device.
 */
export function existsKvm(): boolean {
  try {
    return statSync('/dev/kvm').isCharacterDevice()
  } catch {
    return false
  }
}
