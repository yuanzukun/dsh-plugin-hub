/**
 * Default microsandbox runtime: drives the official `microsandbox` node-ts
 * SDK (N-API binding) through its fluent builder surface. The module is
 * imported lazily so the provider can qualify and fail closed without loading
 * the native binding; sandbox work loads it on first use.
 * @module @deepseek-ai/dsh-sandbox-microsandbox/runtime-sdk
 */

import { timeoutOf } from '@deepseek-ai/dsh-timeout'
import { MICROSANDBOX_TIMEOUT } from './runtime.ts'
import type {
  MicrosandboxCreateRequest,
  MicrosandboxExecRequest,
  MicrosandboxExecResult,
  MicrosandboxFsRequest,
  MicrosandboxRuntime,
} from './runtime.ts'

/** Whether the signal carries THIS provider's timeout reason. */
function timeoutReasonOf(signal: AbortSignal | undefined): boolean {
  return signal !== undefined && timeoutOf(signal, MICROSANDBOX_TIMEOUT) !== undefined
}

/**
 * The SDK's `volume()` configure callback is typed `(b: any) => any`
 * upstream (napi-emitted setters), so the typed mount surface is asserted
 * here once: `MountBuilder` carries `.bind(host)` returning a builder and
 * `.readonly()` returning a builder. The assertion is the boundary — every
 * call inside is against the narrow interface, not `any`.
 */
interface SdkMountBuilder {
  bind(host: string): SdkMountBuilder
  readonly(): SdkMountBuilder
}

/** Configure one bind volume on an SDK sandbox builder. */
function bindVolume(
  builder: {
    volume: (guestPath: string, configure: (mount: SdkMountBuilder) => SdkMountBuilder) => unknown
  },
  volume: { guestPath: string; hostPath: string; readonly?: boolean },
): void {
  builder.volume(volume.guestPath, (mount) => {
    // The builder parameter is declared against the typed mount surface, so
    // every call below stays typed even though the upstream callback is `any`.
    let configured = mount.bind(volume.hostPath)
    if (volume.readonly === true) configured = configured.readonly()
    return configured
  })
}

/**
 * Lazily import the official SDK. Import errors (missing platform package,
 * broken native binding) surface here and map to a structured runner failure.
 */
async function loadSdk(): Promise<typeof import('microsandbox')> {
  return import('microsandbox')
}

/** Build and create a sandbox from a create/exec request's image and options. */
async function buildSandbox(
  sdk: typeof import('microsandbox'),
  name: string,
  options: {
    image: string
    cpus?: number
    memory?: number
    volumes?: readonly { guestPath: string; hostPath: string; readonly?: boolean }[]
    ephemeral?: boolean
  },
): Promise<InstanceType<typeof sdk.Sandbox>> {
  let builder = sdk.Sandbox.builder(name).image(options.image)
  if (options.cpus !== undefined) builder = builder.cpus(options.cpus)
  if (options.memory !== undefined) builder = builder.memory(options.memory)
  for (const volume of options.volumes ?? []) {
    bindVolume(builder, volume)
  }
  if (options.ephemeral === true) builder = builder.ephemeral(true)
  return builder.create()
}

/** Map one SDK error to the structured runner-failure shape. */
function runnerError(error: unknown): { code: string; message: string } {
  if (typeof error === 'object' && error !== null) {
    const candidate = error as { code?: unknown; message?: unknown }
    if (typeof candidate.code === 'string' && typeof candidate.message === 'string') {
      return { code: candidate.code, message: candidate.message }
    }
    if (typeof candidate.message === 'string') {
      return { code: 'MICROSANDBOX_ERROR', message: candidate.message }
    }
  }
  /* v8 ignore next -- plain-Error-without-code is defensive; SDK errors always carry structured fields */
  if (error instanceof Error) return { code: 'MICROSANDBOX_ERROR', message: error.message }
  return { code: 'MICROSANDBOX_ERROR', message: String(error) }
}

/**
 * Attach to an existing sandbox by name without tripping the SDK's
 * still-running guard: a running sandbox must be CONNECTED (start() on a
 * running sandbox throws `SandboxStillRunningError`), while a stopped one
 * must be STARTED. `crashed` and `draining` states are left to the SDK to
 * reject — the caller learns the concrete failure rather than a masked
 * start-vs-connect guess.
 * @param sdk - the loaded microsandbox SDK.
 * @param name - the sandbox to attach to.
 * @returns a live sandbox handle ready for exec/fs work.
 */
async function attachSandbox(
  sdk: typeof import('microsandbox'),
  name: string,
): Promise<InstanceType<typeof sdk.Sandbox>> {
  const handle = await sdk.Sandbox.get(name)
  return handle.status === 'running' ? handle.connect() : handle.start()
}

/**
 * The SDK-backed runtime. Stateless; each exec boots (or reuses) a sandbox
 * and tears down ephemeral ones on exit.
 */
export class SdkRuntime implements MicrosandboxRuntime {
  /**
   * Run one payload through the official SDK: create an ephemeral sandbox
   * from the image (or reuse the named sandbox), attach volumes, exec the
   * exact argv, capture stdout/stderr and the guest exit code, then stop and
   * remove ephemeral sandboxes. A thrown SDK error reads as a runner
   * failure; a non-zero guest exit is an ordinary payload outcome. The
   * caller-owned deadline rides the request signal: when it fires the runtime
   * kills the payload and reports `timedOut`/`aborted` instead of a runner
   * failure — the SDK's own exec timer is deliberately not used, per the
   * provider deadline contract.
   * @param request - the fully validated exec request.
   * @returns the captured outcome.
   */
  async exec(request: MicrosandboxExecRequest): Promise<MicrosandboxExecResult> {
    const sdk = await loadSdk()
    const { Sandbox } = sdk
    const name = request.name ?? `dsh-msb-${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
    const ephemeral = request.name === undefined
    let sandbox: InstanceType<typeof Sandbox> | undefined
    try {
      if (request.name === undefined) {
        // Fresh ephemeral sandbox from the image.
        sandbox = await buildSandbox(sdk, name, { ...request, ephemeral: true })
      } else {
        // Named sandbox: reuse when present (running or stopped), else create
        // and keep. A running sandbox must be connected, not started.
        try {
          sandbox = await attachSandbox(sdk, name)
        } catch {
          sandbox = await buildSandbox(sdk, name, request)
        }
      }
      const [cmd, ...args] = request.argv
      if (cmd === undefined) {
        return { exitCode: null, stdout: Buffer.alloc(0), stderr: Buffer.alloc(0), runnerFailed: true, error: { code: 'EMPTY_ARGV', message: 'exec request carries no command' } }
      }
      // Streaming handle so the provider's deadline can kill the PAYLOAD (not
      // the whole sandbox): ExecHandle.kill() targets the guest process.
      const handle = await sandbox.execStreamWith(cmd, (options) => {
        let builder = options.args(args)
        if (request.env !== undefined) builder = builder.envs(request.env)
        if (request.workdir !== undefined) builder = builder.cwd(request.workdir)
        if (request.user !== undefined) builder = builder.user(request.user)
        return builder
      })
      /* v8 ignore next 3 -- closure body runs only when a caller signal fires; covered through the abort-path tests */
      const deadlineAbort = (): void => {
        // Caller-owned deadline: kill the payload, never the sandbox.
        void handle.kill().catch(() => undefined)
      }
      request.signal?.addEventListener('abort', deadlineAbort, { once: true })
      try {
        const output = await handle.collect()
        return {
          exitCode: output.code,
          stdout: Buffer.from(output.stdoutBytes()),
          stderr: Buffer.from(output.stderrBytes()),
          runnerFailed: false,
        }
      } finally {
        request.signal?.removeEventListener('abort', deadlineAbort)
      }
    } catch (error) {
      if (request.signal?.aborted === true) {
        // Caller-owned deadline fired (timeout or upstream cancellation): the
        // payload ran until the deadline; this is never a runner failure.
        const timedOut = timeoutReasonOf(request.signal)
        return {
          exitCode: null,
          stdout: Buffer.alloc(0),
          stderr: Buffer.alloc(0),
          runnerFailed: false,
          timedOut,
          aborted: !timedOut,
        }
      }
      return { exitCode: null, stdout: Buffer.alloc(0), stderr: Buffer.alloc(0), runnerFailed: true, error: runnerError(error) }
    } finally {
      if (ephemeral && sandbox !== undefined) {
        try {
          await sandbox.stop()
        } catch {
          // Ephemeral teardown is best-effort; the runtime reclaims on exit.
        }
      }
    }
  }

  /**
   * Create a named sandbox from an image and keep it running.
   * @param request - the validated create request.
   * @returns the created sandbox's name.
   */
  async create(request: MicrosandboxCreateRequest): Promise<string> {
    const sdk = await loadSdk()
    const sandbox = await buildSandbox(sdk, request.name, request)
    return sandbox.name
  }

  /** Start a stopped sandbox by name. */
  async start(name: string): Promise<void> {
    const sdk = await loadSdk()
    await sdk.Sandbox.start(name)
  }

  /** Stop a running sandbox by name. */
  async stop(name: string): Promise<void> {
    const sdk = await loadSdk()
    const handle = await sdk.Sandbox.get(name)
    await handle.stop()
  }

  /** Remove a stopped sandbox by name. */
  async remove(name: string): Promise<void> {
    const sdk = await loadSdk()
    await sdk.Sandbox.remove(name)
  }

  /** List known sandbox names. */
  async list(): Promise<string[]> {
    const sdk = await loadSdk()
    const handles = await sdk.Sandbox.list()
    return handles.map(handle => handle.name)
  }

  /** Read one guest file's bytes. */
  async readFile(request: MicrosandboxFsRequest): Promise<Buffer> {
    const sdk = await loadSdk()
    const sandbox = await attachSandbox(sdk, request.sandbox)
    const bytes = await sandbox.fs().read(request.path)
    return Buffer.from(bytes)
  }

  /** Write bytes to one guest file. */
  async writeFile(request: MicrosandboxFsRequest, data: Buffer): Promise<void> {
    const sdk = await loadSdk()
    const sandbox = await attachSandbox(sdk, request.sandbox)
    await sandbox.fs().write(request.path, data)
  }

  /** List the entries of one guest directory. */
  async listDir(request: MicrosandboxFsRequest): Promise<string[]> {
    const sdk = await loadSdk()
    const sandbox = await attachSandbox(sdk, request.sandbox)
    const entries = await sandbox.fs().list(request.path)
    return entries.map(entry => entry.path)
  }

  /** List cached image references. */
  async listImages(): Promise<string[]> {
    const sdk = await loadSdk()
    const images = await sdk.Image.list()
    return images.map(handle => handle.reference)
  }

  /** Remove a cached image by reference. */
  async removeImage(reference: string): Promise<void> {
    const sdk = await loadSdk()
    await sdk.Image.remove(reference)
  }

  /** Create a named volume. */
  async createVolume(name: string): Promise<void> {
    const sdk = await loadSdk()
    await sdk.Volume.builder(name).create()
  }

  /** List known volume names. */
  async listVolumes(): Promise<string[]> {
    const sdk = await loadSdk()
    const volumes = await sdk.Volume.list()
    return volumes.map(volume => volume.name)
  }

  /** Remove a named volume. */
  async removeVolume(name: string): Promise<void> {
    const sdk = await loadSdk()
    await sdk.Volume.remove(name)
  }
}
