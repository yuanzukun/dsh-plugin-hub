/**
 * Microsandbox microVM backend for the DeepSeek Harness.
 *
 * Registers one `ctx.microsandbox` service: a DSH-owned microVM execution
 * service over the exactly pinned official `microsandbox` node-ts SDK.
 * Package-owned `msb` binary resolution (platform package, then
 * `~/.microsandbox/bin`), advisory platform classification, and a bounded
 * functional qualification gate decide availability; an unqualified host
 * fails closed with `MICROSANDBOX_UNAVAILABLE` before any sandbox work.
 *
 * This provider is NOT a `SandboxProvider` backend: microsandbox is a
 * microVM with its own kernel and filesystem world, while the sandbox seam
 * promises same-world process confinement. The MXC and local providers
 * remain the confinement backends; this service is an environment-coherent
 * capability alongside them (see the microsandbox adaptation Agent Note
 * under `.agents/notes/proposed/architecture/2026-08-08-microsandbox-adaptation.md`).
 * @module @deepseek-ai/dsh-sandbox-microsandbox
 */

import { spawnSync } from 'node:child_process'
import { Context, Service } from 'cordis'
import { HarnessError } from '@deepseek-ai/dsh-llm'
import { deadline } from '@deepseek-ai/dsh-timeout'
import z from 'schemastery'
import { getPlatformSupport } from './platform.ts'
import type { PlatformSupport } from './platform.ts'
import { msbPath } from './resolve.ts'
import { SdkRuntime } from './runtime-sdk.ts'
import { MICROSANDBOX_TIMEOUT } from './runtime.ts'
import type {
  MicrosandboxCreateRequest,
  MicrosandboxExecRequest,
  MicrosandboxExecResult,
  MicrosandboxFsRequest,
  MicrosandboxRuntime,
  MicrosandboxVolumeRequest,
} from './runtime.ts'

export { MICROSANDBOX_TIMEOUT } from './runtime.ts'

/**
 * Stable machine-routable code for "the microsandbox backend is unavailable
 * on this host". Distinct from the sandbox seam's `SANDBOX_UNAVAILABLE`
 * because this service is a separate capability, not a confinement backend.
 */
export const MICROSANDBOX_UNAVAILABLE = 'MICROSANDBOX_UNAVAILABLE'

/**
 * Thrown when {@link MicrosandboxProvider} cannot serve: provider disabled,
 * host without hardware virtualization, unresolved `msb` binary, or a failed
 * functional qualification. Fails closed — no unconfined or degraded path.
 */
export class MicrosandboxUnavailableError extends HarnessError {
  constructor(detail?: string) {
    super(
      'the microsandbox microVM backend is unavailable on this host; refusing microVM work. '
      + 'Requires hardware virtualization (KVM on Linux, Apple Silicon Hypervisor.framework on '
      + 'macOS, WHP on Windows), an installed microsandbox runtime, and a passing functional '
      + 'qualification.'
      + (detail === undefined ? '' : ` ${detail}`),
      MICROSANDBOX_UNAVAILABLE,
    )
    this.name = 'MicrosandboxUnavailableError'
  }
}

/** Plugin config. All optional — `static Config` supplies the defaults. */
export interface Config {
  /**
   * Explicit opt-in for this provider. Every operation fails closed with
   * `MICROSANDBOX_UNAVAILABLE` unless a deployment sets `enabled: true`;
   * shipped compositions do not enable the provider yet.
   */
  enabled?: boolean
  /**
   * Positive timeout for the bounded functional qualification probe; zero
   * would mean unbounded to `spawnSync`, so it is validated.
   */
  probeTimeoutMs?: number
}

/** Test seam: inject the binary path, platform facts, the qualification verdict, or the runtime. */
export interface MicrosandboxInternals {
  /** Replaces the resolved `msb` binary path (a fake executor script). */
  msbPath?: string
  /** Replaces the platform facts (fake host posture). */
  platform?: NodeJS.Platform
  /** Replaces the bounded qualification (inject a verdict). */
  qualify?: (executor: string) => 'usable' | 'unavailable'
  /** Replaces the SDK runtime (a fake runtime replaying structured outputs). */
  runtime?: MicrosandboxRuntime
}

/**
 * A probe bound must be a positive finite number: Node treats
 * `spawnSync({ timeout: 0 })` as NO timeout, so an unvalidated 0 would
 * silently mean "unbounded" — the opposite of what the field promises.
 */
function assertPositiveFinite(name: string, value: number): void {
  if (!Number.isFinite(value) || value <= 0) {
    throw new Error(`sandbox-microsandbox: ${name} must be a positive finite number`)
  }
}

/** Sandbox names must be non-empty (the SDK caps them at 128 UTF-8 bytes). */
function assertNonEmptyName(name: string): void {
  if (name.length === 0) {
    throw new Error('sandbox-microsandbox: operation requires a non-empty sandbox name')
  }
}

/** Filesystem targets need a non-empty sandbox name and an absolute guest path. */
function assertFsRequest(request: MicrosandboxFsRequest): void {
  assertNonEmptyName(request.sandbox)
  if (!request.path.startsWith('/')) {
    throw new Error('sandbox-microsandbox: filesystem operations require an absolute guest path')
  }
}

/**
 * Bind volumes need an absolute host path (the provider validates before the
 * runtime binds a host directory into the guest) and an absolute guest mount
 * point. Existence is deliberately NOT checked here: a missing host path may
 * be created by the runtime, and checking would race with later writes.
 */
function assertVolumes(volumes: readonly MicrosandboxVolumeRequest[] | undefined): void {
  for (const volume of volumes ?? []) {
    if (!volume.hostPath.startsWith('/')) {
      throw new Error('sandbox-microsandbox: bind volumes require an absolute host path')
    }
    if (!volume.guestPath.startsWith('/')) {
      throw new Error('sandbox-microsandbox: bind volumes require an absolute guest mount point')
    }
  }
}

/**
 * Dormant microVM execution service. Stateless apart from the cached
 * qualification verdict. Fail-closed end: a disabled provider, an
 * unsupported platform, a missing `msb` binary, or a failed functional
 * qualification throws `MicrosandboxUnavailableError` before any sandbox
 * work begins.
 */
export class MicrosandboxProvider extends Service {
  // Inline schema call: the config catalog walks `static Config` statically.
  static Config: z<Config> = z.object({
    enabled: z.boolean().default(false),
    probeTimeoutMs: z.natural().default(5_000),
  })

  /** Test seam (mirrors the bash executors' `internals`). */
  internals: MicrosandboxInternals = {}

  private readonly enabled: boolean
  private readonly probeTimeoutMs: number
  /** Cached qualification verdict; undefined until the first operation needs it. */
  private qualification: 'usable' | 'unavailable' | undefined

  constructor(ctx: Context, config: Config) {
    super(ctx, 'microsandbox')
    // The schema (static Config) defaults every field — the casts record
    // those runtime facts.
    this.enabled = config.enabled as boolean
    this.probeTimeoutMs = config.probeTimeoutMs as number
    assertPositiveFinite('probeTimeoutMs', this.probeTimeoutMs)
  }

  /**
   * The advisory platform posture for the target platform.
   * @returns the classified posture; only `unsupported` fails closed on its own.
   */
  platformSupport(): PlatformSupport {
    return getPlatformSupport(this.internals.platform ?? process.platform)
  }

  /**
   * Whether a deployment explicitly enabled this provider. Operations gate on this before qualifying.
   * @returns the configured enabled flag.
   */
  isEnabled(): boolean {
    return this.enabled
  }

  /**
   * Resolve the `msb` binary the provider would execute: the internals
   * override first (fake executor in tests), then the package-owned
   * resolution (platform package, then `~/.microsandbox/bin`).
   * @returns the absolute executable path, or null when unresolvable.
   */
  executorPath(): string | null {
    return this.internals.msbPath ?? msbPath(this.internals.platform ?? process.platform)
  }

  /**
   * The bounded functional qualification verdict for this provider
   * incarnation, cached after the first evaluation. The advisory platform
   * posture and the exact resolved binary are both required: an
   * unsupported host, a missing binary, a timed-out probe, or a non-zero
   * probe exit reads as unavailable.
   * @returns `'usable'` only when every gate passes; anything else fails closed.
   */
  qualificationVerdict(): 'usable' | 'unavailable' {
    this.qualification ??= this.qualificationVerdictUncached()
    return this.qualification
  }

  private qualificationVerdictUncached(): 'usable' | 'unavailable' {
    const platform = this.internals.platform ?? process.platform
    if (getPlatformSupport(platform) === 'unsupported') return 'unavailable'
    const executor = this.executorPath()
    /* v8 ignore next -- unresolvable binary; every test injects a path, and installed hosts always resolve */
    if (executor === null) return 'unavailable'
    const injected = this.internals.qualify
    if (injected !== undefined) return injected(executor)
    const probe = spawnSync(executor, ['--version'], {
      timeout: this.probeTimeoutMs,
      encoding: 'utf8',
    })
    if (probe.error !== undefined) return 'unavailable'
    if (probe.status === null || probe.status !== 0) return 'unavailable'
    return 'usable'
  }

  /**
   * Fail-closed gate every sandbox operation passes through: enabled,
   * qualified, and resolved. Throws instead of degrading.
   */
  private requireUsable(): void {
    if (!this.enabled) {
      throw new MicrosandboxUnavailableError('the microsandbox backend is not enabled: set enabled: true on the provider config to activate it; while disabled every operation fails closed')
    }
    if (this.qualificationVerdict() !== 'usable') {
      throw new MicrosandboxUnavailableError('the microsandbox runtime failed functional qualification on this host')
    }
  }

  /**
   * Execute one payload inside a microVM sandbox: boot the image (or reuse
   * the named sandbox), run the exact argv with the requested env/cwd/user,
   * and return the captured outcome. The provider owns the caller deadline:
   * `timeoutMs` and `signal` fuse into one signal that kills the payload on
   * fire and classifies the outcome `timedOut` (provider timeout) or
   * `aborted` (upstream cancellation) — never a runner failure. The runtime
   * abstraction isolates the official SDK; the provider owns gating and
   * argument validation.
   * @param request - image, exact argv, and execution options.
   * @returns the captured guest outcome with the runner/payload/deadline distinction.
   * @throws `MicrosandboxUnavailableError` when disabled or unqualified.
   */
  async exec(request: MicrosandboxExecRequest): Promise<MicrosandboxExecResult> {
    this.requireUsable()
    if (request.image.length === 0) {
      throw new Error('sandbox-microsandbox: exec request requires a non-empty image reference')
    }
    if (request.argv.length === 0) {
      throw new Error('sandbox-microsandbox: exec request requires a non-empty argv')
    }
    assertVolumes(request.volumes)
    // One deadline combines the upstream signal and the provider timeout; the
    // disposer clears the timer at scope exit. The timeout reason carries the
    // provider's code so timedOut vs aborted classification is exact. The
    // await must complete INSIDE the using scope: a bare `return promise`
    // would dispose the timer while the promise is still pending.
    using d = deadline(request.signal, request.timeoutMs ?? 0, MICROSANDBOX_TIMEOUT)
    const runtime = this.internals.runtime ?? new SdkRuntime()
    const result = await runtime.exec({ ...request, signal: d.signal })
    return result
  }

  /**
   * Create a named sandbox from an image and keep it running for later
   * exec/fs operations.
   * @param request - name, image, and optional cpus/memory/volumes.
   * @returns the created sandbox's name.
   * @throws `MicrosandboxUnavailableError` when disabled or unqualified.
   */
  async create(request: MicrosandboxCreateRequest): Promise<string> {
    this.requireUsable()
    if (request.name.length === 0) {
      throw new Error('sandbox-microsandbox: create request requires a non-empty sandbox name')
    }
    if (request.image.length === 0) {
      throw new Error('sandbox-microsandbox: create request requires a non-empty image reference')
    }
    assertVolumes(request.volumes)
    const runtime = this.internals.runtime ?? new SdkRuntime()
    return runtime.create(request)
  }

  /**
   * Start a stopped sandbox by name.
   * @param name - sandbox to start.
   * @throws `MicrosandboxUnavailableError` when disabled or unqualified.
   */
  async start(name: string): Promise<void> {
    this.requireUsable()
    assertNonEmptyName(name)
    const runtime = this.internals.runtime ?? new SdkRuntime()
    await runtime.start(name)
  }

  /**
   * Stop a running sandbox by name.
   * @param name - sandbox to stop.
   * @throws `MicrosandboxUnavailableError` when disabled or unqualified.
   */
  async stop(name: string): Promise<void> {
    this.requireUsable()
    assertNonEmptyName(name)
    const runtime = this.internals.runtime ?? new SdkRuntime()
    await runtime.stop(name)
  }

  /**
   * Remove a stopped sandbox by name.
   * @param name - sandbox to remove.
   * @throws `MicrosandboxUnavailableError` when disabled or unqualified.
   */
  async remove(name: string): Promise<void> {
    this.requireUsable()
    assertNonEmptyName(name)
    const runtime = this.internals.runtime ?? new SdkRuntime()
    await runtime.remove(name)
  }

  /**
   * List known sandbox names.
   * @returns the known sandbox names.
   * @throws `MicrosandboxUnavailableError` when disabled or unqualified.
   */
  async list(): Promise<string[]> {
    this.requireUsable()
    const runtime = this.internals.runtime ?? new SdkRuntime()
    return runtime.list()
  }

  /**
   * Read one guest file's bytes.
   * @param request - sandbox and absolute guest path.
   * @returns the file's bytes.
   * @throws `MicrosandboxUnavailableError` when disabled or unqualified.
   */
  async readFile(request: MicrosandboxFsRequest): Promise<Buffer> {
    this.requireUsable()
    assertFsRequest(request)
    const runtime = this.internals.runtime ?? new SdkRuntime()
    return runtime.readFile(request)
  }

  /**
   * Write bytes to one guest file.
   * @param request - sandbox and absolute guest path.
   * @param data - bytes to write.
   * @throws `MicrosandboxUnavailableError` when disabled or unqualified.
   */
  async writeFile(request: MicrosandboxFsRequest, data: Buffer): Promise<void> {
    this.requireUsable()
    assertFsRequest(request)
    const runtime = this.internals.runtime ?? new SdkRuntime()
    await runtime.writeFile(request, data)
  }

  /**
   * List the entries of one guest directory.
   * @param request - sandbox and absolute guest path.
   * @returns the entry paths.
   * @throws `MicrosandboxUnavailableError` when disabled or unqualified.
   */
  async listDir(request: MicrosandboxFsRequest): Promise<string[]> {
    this.requireUsable()
    assertFsRequest(request)
    const runtime = this.internals.runtime ?? new SdkRuntime()
    return runtime.listDir(request)
  }

  /**
   * List cached image references.
   * @returns the cached image references.
   * @throws `MicrosandboxUnavailableError` when disabled or unqualified.
   */
  async listImages(): Promise<string[]> {
    this.requireUsable()
    const runtime = this.internals.runtime ?? new SdkRuntime()
    return runtime.listImages()
  }

  /**
   * Remove a cached image by reference.
   * @param reference - image reference to remove.
   * @throws `MicrosandboxUnavailableError` when disabled or unqualified.
   */
  async removeImage(reference: string): Promise<void> {
    this.requireUsable()
    if (reference.length === 0) {
      throw new Error('sandbox-microsandbox: removeImage requires a non-empty image reference')
    }
    const runtime = this.internals.runtime ?? new SdkRuntime()
    await runtime.removeImage(reference)
  }

  /**
   * Create a named volume.
   * @param name - volume name.
   * @throws `MicrosandboxUnavailableError` when disabled or unqualified.
   */
  async createVolume(name: string): Promise<void> {
    this.requireUsable()
    assertNonEmptyName(name)
    const runtime = this.internals.runtime ?? new SdkRuntime()
    await runtime.createVolume(name)
  }

  /**
   * List known volume names.
   * @returns the known volume names.
   * @throws `MicrosandboxUnavailableError` when disabled or unqualified.
   */
  async listVolumes(): Promise<string[]> {
    this.requireUsable()
    const runtime = this.internals.runtime ?? new SdkRuntime()
    return runtime.listVolumes()
  }

  /**
   * Remove a named volume.
   * @param name - volume name.
   * @throws `MicrosandboxUnavailableError` when disabled or unqualified.
   */
  async removeVolume(name: string): Promise<void> {
    this.requireUsable()
    assertNonEmptyName(name)
    const runtime = this.internals.runtime ?? new SdkRuntime()
    await runtime.removeVolume(name)
  }
}

declare module 'cordis' {
  interface Context {
    microsandbox: MicrosandboxProvider
  }
}

export { detectTriple, msbFileName, msbPath } from './resolve.ts'
export type {
  MicrosandboxCreateRequest,
  MicrosandboxExecRequest,
  MicrosandboxExecResult,
  MicrosandboxFsRequest,
  MicrosandboxRuntime,
  MicrosandboxVolumeRequest,
} from './runtime.ts'
export default MicrosandboxProvider
