/**
 * Microsandbox execution runtime abstraction.
 *
 * The provider never constructs raw `msb` command lines: all sandbox work
 * goes through this interface, whose default implementation drives the
 * official `microsandbox` node-ts SDK (N-API binding). Tests inject a fake
 * runtime that replays structured outputs, so provider orchestration
 * (fail-closed gates, argument validation, result mapping, timeout) is
 * exercised without hardware virtualization.
 * @module @deepseek-ai/dsh-sandbox-microsandbox/runtime
 */

/**
 * Capability-owned code stamped onto the provider's deadline TimeoutReason
 * (mirrors `BASH_TIMEOUT`). Distinguishes this deadline from a nested
 * upstream deadline so `timedOut` vs `aborted` classification stays exact.
 */
export const MICROSANDBOX_TIMEOUT = 'MICROSANDBOX_TIMEOUT'

/**
 * One bind volume request: a host directory mapped into the guest.
 */
export interface MicrosandboxVolumeRequest {
  /** Guest mount point (absolute path inside the sandbox). */
  guestPath: string
  /** Host directory to bind (validated by the provider before binding). */
  hostPath: string
  /** Mount read-only inside the guest. Defaults to false. */
  readonly?: boolean
}

/**
 * One exec request: boot a sandbox from `image` (reusing `name` when given)
 * and run the exact `argv` inside it.
 */
export interface MicrosandboxExecRequest {
  /** OCI image reference (e.g. `python:alpine`); required. */
  image: string
  /** Exact payload argv (command plus arguments) — never shell-quoted. */
  argv: readonly string[]
  /** Sandbox name; unnamed executions create a one-off ephemeral sandbox. */
  name?: string
  /** Virtual CPUs for a freshly created sandbox. */
  cpus?: number
  /** Memory in MiB for a freshly created sandbox. */
  memory?: number
  /** Deadline in milliseconds; the provider aborts the exec and kills the payload. */
  timeoutMs?: number
  /** Upstream cancellation fused with the timeout; the provider aborts the exec. */
  signal?: AbortSignal | undefined
  /** Environment overrides inside the guest. */
  env?: Readonly<Record<string, string>>
  /** Working directory inside the guest. */
  workdir?: string
  /** Guest user to run as. */
  user?: string
  /** Bind volumes to attach to a freshly created sandbox. */
  volumes?: readonly MicrosandboxVolumeRequest[]
}

/**
 * The outcome of one exec. `runnerFailed` distinguishes a broken sandbox or
 * runtime (the payload never ran, or its result cannot be trusted) from an
 * ordinary non-zero payload exit. `timedOut` and `aborted` carry the
 * caller-owned deadline classification: a provider-side timeout kill is
 * `timedOut`, an upstream cancellation is `aborted`, and neither is a runner
 * failure — the payload ran until the deadline.
 */
export interface MicrosandboxExecResult {
  /** Guest exit code; null when the payload was killed by a signal. */
  exitCode: number | null
  /** Captured stdout bytes. */
  stdout: Buffer
  /** Captured stderr bytes. */
  stderr: Buffer
  /** True when the runner failed before or during execution, not the payload. */
  runnerFailed: boolean
  /** True when the caller-owned deadline fired and the payload was killed. */
  timedOut?: boolean
  /** True when an upstream cancellation aborted the exec. */
  aborted?: boolean
  /** Structured runner-failure detail; present only when `runnerFailed`. */
  error?: { code: string; message: string }
}

/**
 * One create request: boot a named sandbox from an image and keep it
 * running for later exec/fs operations.
 */
export interface MicrosandboxCreateRequest {
  /** Sandbox name (reused by later operations). */
  name: string
  /** OCI image reference (e.g. `python:alpine`); required. */
  image: string
  /** Virtual CPUs for the sandbox. */
  cpus?: number
  /** Memory in MiB for the sandbox. */
  memory?: number
  /** Bind volumes to attach. */
  volumes?: readonly MicrosandboxVolumeRequest[]
}

/** A filesystem operation target: the sandbox name and an absolute guest path. */
export interface MicrosandboxFsRequest {
  /** Sandbox to operate on. */
  sandbox: string
  /** Absolute path inside the guest. */
  path: string
}

/**
 * The lifecycle/execution surface the provider delegates to. Implementations
 * own sandbox creation, image resolution, volume attachment, and teardown;
 * the provider owns gating, validation, and result classification.
 */
export interface MicrosandboxRuntime {
  /**
   * Run one payload inside a sandbox.
   * @param request - the fully validated exec request.
   * @returns the captured outcome with the runner/payload distinction.
   */
  exec(request: MicrosandboxExecRequest): Promise<MicrosandboxExecResult>

  /**
   * Create a named sandbox from an image and keep it running.
   * @param request - the validated create request.
   * @returns the created sandbox's name.
   */
  create(request: MicrosandboxCreateRequest): Promise<string>

  /** Start a stopped sandbox by name. */
  start(name: string): Promise<void>

  /** Stop a running sandbox by name. */
  stop(name: string): Promise<void>

  /** Remove a stopped sandbox by name. */
  remove(name: string): Promise<void>

  /** List known sandbox names. */
  list(): Promise<string[]>

  /** Read one guest file's bytes. */
  readFile(request: MicrosandboxFsRequest): Promise<Buffer>

  /** Write bytes to one guest file. */
  writeFile(request: MicrosandboxFsRequest, data: Buffer): Promise<void>

  /** List the entries of one guest directory. */
  listDir(request: MicrosandboxFsRequest): Promise<string[]>

  /** List cached image references. */
  listImages(): Promise<string[]>

  /** Remove a cached image by reference. */
  removeImage(reference: string): Promise<void>

  /** Create a named volume. */
  createVolume(name: string): Promise<void>

  /** List known volume names. */
  listVolumes(): Promise<string[]>

  /** Remove a named volume. */
  removeVolume(name: string): Promise<void>
}
