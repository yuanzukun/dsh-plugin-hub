/**
 * Package-owned `msb` binary resolution for the microsandbox microVM backend.
 *
 * Mirrors the upstream node-ts SDK's resolver contract (platform package
 * `@superradcompany/microsandbox-<triple>` carrying `bin/msb`[`.exe`],
 * falling back to `~/.microsandbox/bin`) so DSH never hardcodes a binary
 * path and never depends on the SDK's unexported internal resolver. The
 * resolved path is what the qualification gate probes and what the SDK
 * runtime uses to locate its own backend.
 * @module @deepseek-ai/dsh-sandbox-microsandbox/resolve
 */

import { createRequire } from 'node:module'
import { existsSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { homedir } from 'node:os'

/**
 * The Rust target triple the microsandbox platform packages are named after.
 * @param platform - target platform (test seam; defaults to `process.platform`).
 * @param arch - target architecture (test seam; defaults to `process.arch`).
 * @returns the triple, or `undefined` for an unsupported combination.
 */
export function detectTriple(
  platform: NodeJS.Platform = process.platform,
  arch: string = process.arch,
): string | undefined {
  if (platform === 'darwin' && arch === 'arm64') return 'darwin-arm64'
  if (platform === 'linux' && arch === 'x64') return 'linux-x64-gnu'
  if (platform === 'linux' && arch === 'arm64') return 'linux-arm64-gnu'
  if (platform === 'win32' && arch === 'x64') return 'win32-x64-msvc'
  if (platform === 'win32' && arch === 'arm64') return 'win32-arm64-msvc'
  return undefined
}

/**
 * The `msb` binary file name for the platform.
 * @param platform - target platform (test seam; defaults to `process.platform`).
 * @returns `msb.exe` on Windows, `msb` elsewhere.
 */
export function msbFileName(platform: NodeJS.Platform = process.platform): string {
  return platform === 'win32' ? 'msb.exe' : 'msb'
}

/**
 * Search from multiple bases so the platform package resolves whether the
 * SDK was installed normally (the platform pkg sits beside the consumer's
 * `node_modules/microsandbox/`) or via a `file:` link (in which case
 * `import.meta.url` follows symlinks back to the SDK source, where no
 * platform pkg is installed). The `microsandbox` main package root is also
 * a base: under pnpm's isolated layout the platform package is linked only
 * inside the main package's own `node_modules`, so resolution must start
 * from there as well. Same contract as the upstream resolver.
 */
function resolutionBases(): string[] {
  const bases = new Set<string>()
  bases.add(import.meta.url)
  /* v8 ignore next -- CLI-entry base only exists when a script path is available */
  if (process.argv[1]) bases.add(`file://${process.argv[1]}`)
  bases.add(`file://${process.cwd()}/`)
  // The main package's own resolution context: pnpm links the platform
  // package next to `microsandbox`, so requiring through the main package
  // finds it even when our own node_modules does not carry a top-level link.
  try {
    const r = createRequire(import.meta.url)
    const mainEntry = r.resolve('microsandbox')
    bases.add(mainEntry)
  } catch {
    /* v8 ignore next -- SDK not installed; remaining bases still cover direct installs */
  }
  return Array.from(bases)
}

/** Resolve the platform package root that actually carries `bin/msb`, if any. */
function resolvePlatformRoot(): string | null {
  const triple = detectTriple()
  /* v8 ignore next 2 -- internal guard; callers already rejected unsupported triples */
  if (triple === undefined) return null
  for (const base of resolutionBases()) {
    try {
      const r = createRequire(base)
      const pkgPath = r.resolve(`@superradcompany/microsandbox-${triple}/package.json`)
      const root = dirname(pkgPath)
      if (existsSync(join(root, 'bin', msbFileName()))) return root
    } catch {
      /* v8 ignore next -- a base that fails to resolve just falls through to the next one */
      // try next base
    }
  }
  /* v8 ignore next -- every base failed to carry the platform package */
  return null
}

let cachedBinDir: string | null = null

/** The directory holding `msb`: the platform package's `bin`, or `~/.microsandbox/bin`. */
function resolveBinDir(): string {
  /* v8 ignore next -- per-incarnation cache; a second call within one process hits it */
  if (cachedBinDir) return cachedBinDir
  const root = resolvePlatformRoot()
  /* v8 ignore next 3 -- no-platform-package branch; hosts with the package installed never take it */
  if (root) {
    cachedBinDir = join(root, 'bin')
    return cachedBinDir
  }
  /* v8 ignore next 3 -- HOME fallback is exercised only on hosts without an installed platform package */
  const home = process.env.HOME ?? process.env.USERPROFILE ?? homedir()
  cachedBinDir = join(home, '.microsandbox', 'bin')
  return cachedBinDir
}

/**
 * Path to the `msb` binary, or null when not installed.
 * @param platform - target platform (test seam; defaults to `process.platform`).
 * @param arch - target architecture (test seam; defaults to `process.arch`).
 * @returns the absolute executable path, or null.
 */
export function msbPath(
  platform: NodeJS.Platform = process.platform,
  arch: string = process.arch,
): string | null {
  if (detectTriple(platform, arch) === undefined) return null
  const p = join(resolveBinDir(), msbFileName(platform))
  /* v8 ignore next -- resolved root exists but the binary vanished between check and use */
  return existsSync(p) ? p : null
}
