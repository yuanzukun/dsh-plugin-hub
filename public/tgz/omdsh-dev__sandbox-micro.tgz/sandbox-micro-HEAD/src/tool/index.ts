/**
 * Model-facing microsandbox microVM tools over the dormant `ctx.microsandbox`
 * service. Registers `microsandbox_exec` (boot an image or reuse a named
 * sandbox, run an exact argv, return captured output with the guest exit
 * code) and `microsandbox_fs` (read or write one guest file, or list a guest
 * directory). Every call inherits the provider's fail-closed contract:
 * an unqualified host, a disabled provider, or a rejected operation surfaces
 * `MICROSANDBOX_UNAVAILABLE` / structured runner failure rather than an
 * unconfined fallback.
 *
 * No shipped composition mounts this plugin; like the provider it is dormant
 * until a deployment enables both the provider and the tool.
 * @module @deepseek-ai/dsh-sandbox-microsandbox/tool
 */

import type { Context } from 'cordis'
import z from 'schemastery'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { MicrosandboxExecResult } from '@deepseek-ai/dsh-sandbox-microsandbox'

export const name = 'tool-microsandbox'
export const inject = ['tools', 'microsandbox']

/** Runtime configuration schema for the tool plugin. */
export const Config: z<object> = z.object({})

import { renderExec, renderFs, trimOutput } from './render.ts'

/** Serialize one exec outcome for the model-facing result. */
function execOutcome(result: MicrosandboxExecResult) {
  return {
    exitCode: result.exitCode,
    stdout: trimOutput(result.stdout.toString('utf8')),
    stderr: trimOutput(result.stderr.toString('utf8')),
    runnerFailed: result.runnerFailed,
    ...(result.timedOut !== undefined ? { timedOut: result.timedOut } : {}),
    ...(result.aborted !== undefined ? { aborted: result.aborted } : {}),
    ...(result.error !== undefined ? { error: result.error } : {}),
  }
}

/**
 * Apply the tool plugin: register the two model tools.
 * @param ctx - Cordis context with the tools registry and the microsandbox provider.
 */
export const apply = (ctx: Context): void => {
  ctx.tools.register(defineTool({
    name: 'microsandbox_exec',
    description: 'Run an exact argv inside a microVM sandbox: boots the image (or reuses the named sandbox), '
      + 'executes the command with the given timeout, and returns the captured stdout, stderr, and guest exit code.',
    parameters: {
      image: { type: 'string', required: true, description: 'OCI image reference (e.g. python:alpine) to boot.' },
      argv: {
        type: 'array',
        required: true,
        description: 'Exact command line: the program followed by its arguments, never shell-quoted.',
        items: { type: 'string' },
      },
      name: { type: 'string', description: 'Reuse a named sandbox instead of creating an ephemeral one.' },
      timeoutMs: { type: 'number', description: 'Kill the payload after this many milliseconds (caller-owned deadline).' },
      workdir: { type: 'string', description: 'Working directory inside the guest.' },
      user: { type: 'string', description: 'Guest user to run as.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          exitCode: { required: true, oneOf: [{ type: 'integer' }, { type: 'null' }] },
          stdout: { type: 'string', required: true },
          stderr: { type: 'string', required: true },
          runnerFailed: { type: 'boolean', required: true },
          timedOut: { type: 'boolean' },
          aborted: { type: 'boolean' },
          error: {
            type: 'object',
            additionalProperties: false,
            properties: {
              code: { type: 'string', required: true },
              message: { type: 'string', required: true },
            },
          },
        },
      },
      render: renderExec,
    },
    async execute(args) {
      const { microsandbox } = ctx
      const result = await microsandbox.exec({
        image: args.image,
        argv: args.argv,
        ...(args.name !== undefined ? { name: args.name } : {}),
        ...(args.timeoutMs !== undefined ? { timeoutMs: args.timeoutMs } : {}),
        ...(args.workdir !== undefined ? { workdir: args.workdir } : {}),
        ...(args.user !== undefined ? { user: args.user } : {}),
      })
      return execOutcome(result)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'microsandbox_fs',
    description: 'Read, write, or list files inside a running microsandbox without mounting: '
      + 'operation read|write|list, sandbox name, and an absolute guest path.',
    parameters: {
      operation: {
        type: 'string',
        required: true,
        enum: ['read', 'write', 'list'],
        description: 'What to do: read a file, write a file, or list a directory.',
      },
      sandbox: { type: 'string', required: true, description: 'Sandbox name to operate on.' },
      path: { type: 'string', required: true, description: 'Absolute guest path.' },
      content: { type: 'string', description: 'Content to write (required when operation is write).' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          operation: { type: 'string', required: true },
          path: { type: 'string', required: true },
          ok: { type: 'boolean', required: true },
          content: { type: 'string' },
          entries: { type: 'array', items: { type: 'string' } },
        },
      },
      render: renderFs,
    },
    async execute(args) {
      const { microsandbox } = ctx
      if (args.operation === 'read') {
        const data = await microsandbox.readFile({ sandbox: args.sandbox, path: args.path })
        return { operation: 'read', path: args.path, ok: true, content: data.toString('utf8') }
      }
      if (args.operation === 'list') {
        const entries = await microsandbox.listDir({ sandbox: args.sandbox, path: args.path })
        return { operation: 'list', path: args.path, ok: true, entries }
      }
      if (args.content === undefined) {
        throw new Error('sandbox-microsandbox tool: content is required when operation is write')
      }
      await microsandbox.writeFile({ sandbox: args.sandbox, path: args.path }, Buffer.from(args.content, 'utf8'))
      return { operation: 'write', path: args.path, ok: true }
    },
  }))
}
