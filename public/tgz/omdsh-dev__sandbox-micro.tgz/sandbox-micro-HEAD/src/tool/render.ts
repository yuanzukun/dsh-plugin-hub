/**
 * Pure presenters for the microsandbox tools. Replay-only: they never throw
 * and fall back to generic text for unexpected shapes.
 * @module @deepseek-ai/dsh-sandbox-microsandbox/tool/render
 */

/**
 * Strip trailing newlines for compact display.
 * @param text - output to trim.
 * @returns the text without trailing newlines.
 */
export function trimOutput(text: string): string {
  return text.replace(/\n+$/u, '')
}

/**
 * One exec outcome's render: captured output plus a classification line.
 * @param _args - tool arguments (unused; present for the presenter contract).
 * @param value - the exec outcome to render.
 * @returns text blocks: captured stdout/stderr plus the classification line.
 */
export function renderExec(_args: unknown, value: unknown): Array<{ type: 'text'; text: string }> {
  const outcome = (value ?? {}) as {
    stdout?: unknown
    stderr?: unknown
    exitCode?: number | null
    runnerFailed?: unknown
    timedOut?: unknown
    aborted?: unknown
    error?: { code?: string } | undefined
  }
  const lines: string[] = []
  if (typeof outcome.stdout === 'string' && outcome.stdout.length > 0) lines.push(outcome.stdout)
  if (typeof outcome.stderr === 'string' && outcome.stderr.length > 0) lines.push(outcome.stderr)
  const status = outcome.runnerFailed === true
    ? `[microsandbox: runner failed${outcome.error?.code !== undefined ? ` (${outcome.error.code})` : ''}]`
    : `[microsandbox: exit code ${outcome.exitCode ?? 'signal'}${outcome.timedOut === true ? ', timed out' : ''}${outcome.aborted === true ? ', aborted' : ''}]`
  return [{ type: 'text', text: lines.length > 0 ? lines.join('\n') + '\n' + status : status }]
}

/**
 * One fs result's render: content for read, entries for list, confirmation for write.
 * @param _args - tool arguments (unused; present for the presenter contract).
 * @param value - the fs result to render.
 * @returns one text block with the rendered content, entries, or confirmation.
 */
export function renderFs(_args: unknown, value: unknown): Array<{ type: 'text'; text: string }> {
  const result = (value ?? {}) as { operation?: unknown; content?: unknown; entries?: unknown; path?: unknown }
  if (result.operation === 'read') return [{ type: 'text', text: typeof result.content === 'string' ? result.content : '' }]
  if (result.operation === 'list') {
    return [{ type: 'text', text: Array.isArray(result.entries) ? result.entries.join('\n') : '' }]
  }
  return [{ type: 'text', text: `[microsandbox: wrote ${typeof result.path === 'string' ? result.path : ''}]` }]
}
