/**
 * Real-package resolution tests. These exercise the package-owned resolver
 * against the ACTUAL installed `microsandbox` platform package (no fake
 * injection): the `msb` binary must resolve to the platform package's
 * `bin/` directory and answer `--version` with the pinned release. No
 * hardware virtualization is required — only the installed platform package.
 */

import { existsSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
import { describe, expect, it } from 'vitest'
import { msbPath, detectTriple } from '../../src/resolve.ts'

const triple = detectTriple()
const skippable = triple === undefined

describe.skipIf(skippable)('real platform-package resolution', () => {
  it('resolves msb to an existing executable inside the platform package', () => {
    const path = msbPath()
    expect(path).not.toBeNull()
    expect(existsSync(path as string)).toBe(true)
    // Must live under the platform package's bin, not a random PATH entry.
    expect(path).toContain(`@superradcompany/microsandbox-${triple}`)
    expect(path).toMatch(/[\\/]bin[\\/]msb(\.exe)?$/)
  })

  it('answers --version with the pinned release and exits zero', () => {
    const path = msbPath()
    expect(path).not.toBeNull()
    const probe = spawnSync(path as string, ['--version'], { encoding: 'utf8' })
    expect(probe.error).toBeUndefined()
    expect(probe.status).toBe(0)
    expect(probe.stdout).toMatch(/msb \d+\.\d+\.\d+/)
  })
})
