/**
 * Keyless publish-path rehearsal. It packs the provider package and its
 * workspace peers, installs those exact tarballs in an external plain-Node
 * consumer, and lets pnpm/npm resolve the registry `microsandbox` package
 * plus its platform package. No tsx, path mapping, or workspace resolution
 * can hide missing files, dependency errors, or lost executable modes.
 *
 * The installed consumer must resolve `msbPath()` into the platform package's
 * `bin/` and the resolved binary must answer `--version` with the pinned
 * release. Hardware virtualization is deliberately not required: the probe
 * is the same bounded `spawnSync` the qualification gate runs.
 */

import { spawnSync } from 'node:child_process'
import { existsSync, mkdtempSync, writeFileSync } from 'node:fs'
import { rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { afterAll, beforeAll, describe, expect, it } from 'vitest'

const packageDir = fileURLToPath(new URL('../..', import.meta.url))
const repoRoot = packageDir

/** The root package is the complete publish artifact; DSH capabilities remain peers supplied by the profile. */
const WORKSPACE_CLOSURE = ['.']

const buildable = existsSync(join(packageDir, 'lib', 'index.js'))

let consumerDir = ''
let packDest = ''
let workDir = ''
/** The consumer script's JSON verdict (see its source below). */
let verdict: {
  msb: string | null
  msbExists: boolean
  probeStatus: number | null
  probeStdout: string
} = { msb: null, msbExists: false, probeStatus: null, probeStdout: '' }

describe.skipIf(!buildable)('sandbox-microsandbox: packed-tarball distribution (publish-path rehearsal)', () => {
  beforeAll(async () => {
    packDest = mkdtempSync(join(tmpdir(), 'dsh-pack-'))
    consumerDir = mkdtempSync(join(tmpdir(), 'dsh-packed-consumer-'))
    workDir = mkdtempSync(join(tmpdir(), 'dsh-packed-work-'))

    // Pack each closure member with the exact bytes publish would upload.
    const tarballs: string[] = []
    for (const pkg of WORKSPACE_CLOSURE) {
      // Local sandboxes with a read-only pnpm home need an explicit store;
      // CI environments resolve the default store and pass no override.
      const storeOverride = process.env.DSH_PNPM_STORE_DIR === undefined
        ? []
        : ['--config.store-dir=' + process.env.DSH_PNPM_STORE_DIR]
      const pack = spawnSync('pnpm', ['pack', '--pack-destination', packDest, ...storeOverride], {
        cwd: join(repoRoot, pkg),
        encoding: 'utf8',
        timeout: 120_000,
      })
      expect(pack.status, `pnpm pack failed for ${pkg}:\n${pack.stdout}\n${pack.stderr}`).toBe(0)
      const lines = pack.stdout.trim().split('\n')
      tarballs.push(lines[lines.length - 1] as string)
    }

    writeFileSync(join(consumerDir, 'package.json'), JSON.stringify({ name: 'dsh-packed-consumer', private: true, type: 'module' }))
    // Local sandboxes with a read-only npm home need an explicit cache dir;
    // CI environments resolve the default and pass no override.
    const npmCacheOverride = process.env.DSH_NPM_CACHE_DIR === undefined
      ? []
      : ['--cache', process.env.DSH_NPM_CACHE_DIR, '--logs-max=0']
    const install = spawnSync('npm', ['install', '--no-audit', '--no-fund', ...npmCacheOverride, ...tarballs, 'cordis@4.0.0-rc.7'], {
      cwd: consumerDir,
      encoding: 'utf8',
      timeout: 300_000,
    })
    expect(install.status, `npm install failed:\n${install.stdout}\n${install.stderr}`).toBe(0)

    // The consumer script runs under PLAIN node against the installed
    // packages and reports a JSON verdict; every assertion happens back in
    // the test. The qualification probe is the same bounded spawnSync the
    // provider's gate runs, so no hardware virtualization is needed.
    writeFileSync(join(consumerDir, 'consumer.mjs'), `
      import { spawnSync } from 'node:child_process'
      import { existsSync } from 'node:fs'
      import { msbPath } from '@deepseek-ai/dsh-sandbox-microsandbox'
      const msb = msbPath()
      const out = { msb, msbExists: msb !== null && existsSync(msb) }
      if (msb !== null) {
        const probe = spawnSync(msb, ['--version'], { encoding: 'utf8', timeout: 5000 })
        out.probeStatus = probe.status
        out.probeStdout = probe.stdout
      }
      console.log(JSON.stringify(out))
    `)
    const consumer = spawnSync('node', ['consumer.mjs'], { cwd: consumerDir, encoding: 'utf8', timeout: 60_000 })
    expect(consumer.status, `consumer script failed:\n${consumer.stdout}\n${consumer.stderr}`).toBe(0)
    verdict = JSON.parse(consumer.stdout.trim().split('\n').pop() as string) as typeof verdict
  }, 480_000)

  afterAll(async () => {
    // The dirs are set in beforeAll; the filter narrows them to non-empty strings.
    await Promise.all([consumerDir, workDir, packDest].filter(Boolean).map(dir => rm(dir, { recursive: true, force: true })))
  })

  it('installs the registry platform package for this host: msb present and executable', () => {
    expect(verdict.msbExists, 'msb binary missing from the installed tree').toBe(true)
    const installed = verdict.msb as string
    expect(installed).toContain('@superradcompany/microsandbox-')
    expect(installed).toMatch(/[\\/]bin[\\/]msb(\.exe)?$/)
    // A tarball or extraction step that stripped the mode bit would make the
    // probe fail exactly like a broken install — assert it apart.
    const probe = spawnSync(installed, ['--version'], { encoding: 'utf8', timeout: 5000 })
    expect(probe.status).toBe(0)
  })

  it('the installed resolver locates the platform package INSIDE the consumer node_modules', () => {
    expect(verdict.msb).toContain(join(consumerDir, 'node_modules'))
  })

  it('the pinned binary answers --version with the release', () => {
    expect(verdict.probeStatus).toBe(0)
    expect(verdict.probeStdout).toMatch(/msb \d+\.\d+\.\d+/)
  })
})
