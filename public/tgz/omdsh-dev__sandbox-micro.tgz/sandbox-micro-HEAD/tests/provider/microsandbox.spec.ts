/**
 * MicrosandboxProvider tests. No real `msb` binary or hardware virtualization
 * is assumed: `internals.msbPath` injects fake executor scripts,
 * `internals.platform` injects host posture, and `internals.runtime` injects
 * a fake runtime replaying structured outputs, so platform classification,
 * binary resolution, bounded qualification (usable / unavailable / timeout),
 * verdict caching, the fail-closed error contract, and exec orchestration
 * (argv forwarding, exit-code propagation, stdout/stderr separation, timeout,
 * runner-failure-vs-payload-exit) are exercised through the real provider
 * path.
 */

import { mkdtempSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it, vi } from 'vitest'
import { Context } from 'cordis'
import {
  MICROSANDBOX_TIMEOUT,
  MICROSANDBOX_UNAVAILABLE,
  MicrosandboxUnavailableError,
  MicrosandboxProvider,
} from '@deepseek-ai/dsh-sandbox-microsandbox'
import type { Config } from '@deepseek-ai/dsh-sandbox-microsandbox'
import type {
  MicrosandboxCreateRequest,
  MicrosandboxExecRequest,
  MicrosandboxFsRequest,
  MicrosandboxRuntime,
} from '@deepseek-ai/dsh-sandbox-microsandbox/src/runtime.ts'
import { getPlatformSupport } from '../../src/platform.ts'
import { detectTriple, msbFileName, msbPath } from '../../src/resolve.ts'

async function setup(config: Config = {}, internals: MicrosandboxProvider['internals'] = {}) {
  const ctx = new Context()
  await ctx.plugin(MicrosandboxProvider, config)
  const provider = ctx.microsandbox
  provider.internals = internals
  return { ctx, provider }
}

/** Write an executable fake `msb` that answers `--version` with `exitCode`. */
function fakeMsb(exitCode = 0, output = 'microsandbox 0.6.7'): string {
  const dir = mkdtempSync(join(tmpdir(), 'dsh-fake-msb-'))
  const bin = join(dir, 'msb')
  writeFileSync(bin, `#!/bin/sh\nif [ "$1" = "--version" ]; then echo "${output}"; exit ${exitCode}; fi\nexit 1\n`, { mode: 0o755 })
  return bin
}

/** A fake runtime that records requests and replays a fixed result. */
function fakeRuntime(impl: Partial<MicrosandboxRuntime> = {}): {
  runtime: MicrosandboxRuntime
  exec: ReturnType<typeof vi.fn>
  spies: {
    create: ReturnType<typeof vi.fn>
    start: ReturnType<typeof vi.fn>
    stop: ReturnType<typeof vi.fn>
    remove: ReturnType<typeof vi.fn>
    list: ReturnType<typeof vi.fn>
    readFile: ReturnType<typeof vi.fn>
    writeFile: ReturnType<typeof vi.fn>
    listDir: ReturnType<typeof vi.fn>
    listImages: ReturnType<typeof vi.fn>
    removeImage: ReturnType<typeof vi.fn>
    createVolume: ReturnType<typeof vi.fn>
    listVolumes: ReturnType<typeof vi.fn>
    removeVolume: ReturnType<typeof vi.fn>
  }
} {
  const exec = vi.fn(async (request: MicrosandboxExecRequest) => ({
    exitCode: 0,
    stdout: Buffer.from(`stdout:${request.argv.join(' ')}`),
    stderr: Buffer.alloc(0),
    runnerFailed: false,
  }))
  const spies = {
    create: vi.fn(async (request: MicrosandboxCreateRequest) => request.name),
    start: vi.fn(async () => undefined),
    stop: vi.fn(async () => undefined),
    remove: vi.fn(async () => undefined),
    list: vi.fn(async () => ['alpha', 'beta']),
    readFile: vi.fn(async (request: MicrosandboxFsRequest) => Buffer.from(`bytes:${request.path}`)),
    writeFile: vi.fn(async () => undefined),
    listDir: vi.fn(async (request: MicrosandboxFsRequest) => [`${request.path}/a`, `${request.path}/b`]),
    listImages: vi.fn(async () => ['python:alpine']),
    removeImage: vi.fn(async () => undefined),
    createVolume: vi.fn(async () => undefined),
    listVolumes: vi.fn(async () => ['data']),
    removeVolume: vi.fn(async () => undefined),
  }
  const runtime: MicrosandboxRuntime = { exec, ...spies, ...impl }
  return { runtime, exec, spies }
}

describe('platform posture', () => {
  it('classifies linux as supported only with /dev/kvm present', () => {
    expect(getPlatformSupport('linux', 'x64', false)).toBe('unsupported')
    expect(getPlatformSupport('linux', 'x64', true)).toBe('supported')
  })

  it('classifies darwin arm64 as supported and x64 as unsupported', () => {
    expect(getPlatformSupport('darwin', 'arm64')).toBe('supported')
    expect(getPlatformSupport('darwin', 'x64')).toBe('unsupported')
  })

  it('classifies win32 as unknown (WHP is decided by the probe)', () => {
    expect(getPlatformSupport('win32', 'x64')).toBe('unknown')
  })

  it('classifies other platforms as unsupported', () => {
    expect(getPlatformSupport('freebsd', 'x64')).toBe('unsupported')
  })
})

describe('binary resolution', () => {
  it('maps supported platform/arch pairs to triples', () => {
    expect(detectTriple('linux', 'x64')).toBe('linux-x64-gnu')
    expect(detectTriple('linux', 'arm64')).toBe('linux-arm64-gnu')
    expect(detectTriple('darwin', 'arm64')).toBe('darwin-arm64')
    expect(detectTriple('win32', 'x64')).toBe('win32-x64-msvc')
    expect(detectTriple('win32', 'arm64')).toBe('win32-arm64-msvc')
  })

  it('returns no triple for unsupported combinations', () => {
    expect(detectTriple('darwin', 'x64')).toBeUndefined()
    expect(detectTriple('linux', 'ia32')).toBeUndefined()
  })

  it('resolves no msb path for an unsupported platform', () => {
    expect(msbPath('darwin', 'x64')).toBeNull()
  })

  it('names the binary msb.exe on Windows', () => {
    expect(msbFileName('win32')).toBe('msb.exe')
    expect(msbFileName('linux')).toBe('msb')
  })

  it('falls back to a HOME-based bin directory when no platform package resolves', () => {
    // A platform with a valid triple but no installed platform package
    // exercises the `~/.microsandbox/bin` fallback path.
    expect(msbPath('linux', 'x64')).not.toBeNull()
  })
})

describe('qualification gate', () => {
  it('fails closed on an unsupported platform even with a present binary', async () => {
    const bin = fakeMsb()
    const { provider } = await setup(
      { enabled: true },
      { msbPath: bin, platform: 'freebsd' },
    )
    expect(provider.platformSupport()).toBe('unsupported')
    expect(provider.qualificationVerdict()).toBe('unavailable')
  })

  it('fails closed on linux when /dev/kvm is absent despite a fake binary answering --version', async () => {
    // The platform posture unit test owns the KVM-present branch; here the
    // injected Linux platform makes the gate consult the real /dev/kvm
    // check, and the fake binary must never rescue an unqualified host.
    const bin = fakeMsb()
    const { provider } = await setup(
      { enabled: true },
      { msbPath: bin, platform: 'linux' },
    )
    const verdict = provider.qualificationVerdict()
    // On a KVM host the posture alone passes, so the verdict may be usable;
    // the fail-closed guarantee is that 'unsupported' posture never is.
    if (getPlatformSupport('linux', process.arch) === 'unsupported') {
      expect(verdict).toBe('unavailable')
    } else {
      expect(verdict).toBe('usable')
    }
  })

  it('declares a fake executor usable when every gate passes (win32 posture is probe-decided)', async () => {
    const bin = fakeMsb()
    const { provider } = await setup(
      { enabled: true },
      { msbPath: bin, platform: 'win32' },
    )
    expect(provider.platformSupport()).toBe('unknown')
    expect(provider.qualificationVerdict()).toBe('usable')
  })

  it('qualifies through the real spawnSync probe when no verdict is injected', async () => {
    const bin = fakeMsb()
    const { provider } = await setup(
      { enabled: true },
      { msbPath: bin, platform: 'win32' },
    )
    // win32 posture is probe-decided and the fake binary answers --version
    // with exit 0, so the REAL spawnSync path (no internals.qualify) yields usable.
    expect(provider.qualificationVerdict()).toBe('usable')
  })

  it('declares a fake executor usable under an injected qualify verdict', async () => {
    const bin = fakeMsb()
    const { provider } = await setup(
      { enabled: true },
      { msbPath: bin, platform: 'win32', qualify: () => 'usable' },
    )
    expect(provider.qualificationVerdict()).toBe('usable')
  })

  it('respects an injected unavailable verdict', async () => {
    const bin = fakeMsb()
    const { provider } = await setup(
      { enabled: true },
      { msbPath: bin, platform: 'win32', qualify: () => 'unavailable' },
    )
    expect(provider.qualificationVerdict()).toBe('unavailable')
  })

  it('fails closed when the probe exits non-zero', async () => {
    const bin = fakeMsb(2)
    const { provider } = await setup(
      { enabled: true },
      { msbPath: bin, platform: 'win32' },
    )
    expect(provider.qualificationVerdict()).toBe('unavailable')
  })

  it('fails closed when the probe cannot be spawned at all', async () => {
    // A non-executable file makes spawnSync set `error` (e.g. EACCES).
    const dir = mkdtempSync(join(tmpdir(), 'dsh-not-exec-'))
    const bin = join(dir, 'msb')
    writeFileSync(bin, '#!/bin/sh\nexit 0\n', { mode: 0o644 })
    const { provider } = await setup(
      { enabled: true },
      { msbPath: bin, platform: 'win32' },
    )
    expect(provider.qualificationVerdict()).toBe('unavailable')
  })

  it('fails closed when the binary is missing', async () => {
    const { provider } = await setup(
      { enabled: true },
      { msbPath: join(tmpdir(), 'dsh-no-such-msb'), platform: 'win32' },
    )
    expect(provider.qualificationVerdict()).toBe('unavailable')
  })

  it('caches the verdict for the provider incarnation', async () => {
    let calls = 0
    const bin = fakeMsb()
    const { provider } = await setup(
      { enabled: true },
      {
        msbPath: bin,
        platform: 'win32',
        qualify: () => {
          calls += 1
          return 'usable'
        },
      },
    )
    expect(provider.qualificationVerdict()).toBe('usable')
    expect(provider.qualificationVerdict()).toBe('usable')
    expect(calls).toBe(1)
  })

  it('rejects a non-positive probeTimeoutMs as misconfiguration', async () => {
    await expect(setup({ enabled: true, probeTimeoutMs: 0 })).rejects.toThrow(
      'probeTimeoutMs must be a positive finite number',
    )
  })
})

describe('default paths (no internals injected)', () => {
  it('platformSupport and executorPath use the real host platform and resolution', async () => {
    const { provider } = await setup({ enabled: true })
    // Real platform posture is whatever the host is; the point is the call
    // succeeds and the executor resolves through the package-owned resolver.
    expect(provider.platformSupport()).toMatch(/^(supported|unsupported|unknown)$/)
    expect(provider.executorPath()).not.toBeNull()
  })

  it('isEnabled reflects the configured flag', async () => {
    const { provider } = await setup({ enabled: true })
    expect(provider.isEnabled()).toBe(true)
  })

  it('exec with no injected runtime uses the default SdkRuntime', async () => {
    // The default runtime lazily imports the real SDK; on a host without
    // hardware virtualization the exec fails closed through qualification
    // BEFORE the runtime is reached, so no SDK import happens here.
    const { provider } = await setup({ enabled: true })
    await expect(provider.exec({ image: 'alpine', argv: ['true'] })).rejects.toThrow()
  })

  it('qualificationVerdict with no internals resolves the real binary path', async () => {
    const { provider } = await setup({ enabled: true })
    // Either the host qualifies (usable) or fails closed (unavailable) —
    // both paths run the real resolution; the assertion pins that no
    // injection is required for the gate to produce a verdict.
    expect(['usable', 'unavailable']).toContain(provider.qualificationVerdict())
  })

  it('exec without an injected runtime instantiates the default SdkRuntime', async () => {
    // Qualification passes through the injected verdict, the executor path is
    // the fake script, and NO runtime is injected — so the operation must
    // construct the default SdkRuntime, which lazily imports the real SDK
    // and fails the exec (no live sandbox on this host) as a runner failure
    // rather than an unavailable error.
    const bin = fakeMsb()
    const { provider } = await setup(
      { enabled: true },
      { msbPath: bin, platform: 'win32', qualify: () => 'usable' },
    )
    const result = await provider.exec({ image: 'alpine', argv: ['true'] })
    expect(result.runnerFailed).toBe(true)
    expect(result.error).toBeDefined()
  })

  it('every lifecycle/fs/image/volume operation constructs the default SdkRuntime when none is injected', async () => {
    const bin = fakeMsb()
    const { provider } = await setup(
      { enabled: true },
      { msbPath: bin, platform: 'win32', qualify: () => 'usable' },
    )
    // Each call passes the enable+qualification gates, then constructs the
    // default SdkRuntime and fails on the real SDK (no live sandbox/images on
    // this host). Rejections are expected; the point is the default-runtime
    // branch executes for every operation.
    await expect(provider.create({ name: 'build', image: 'alpine' })).rejects.toThrow()
    await expect(provider.start('build')).rejects.toThrow()
    await expect(provider.stop('build')).rejects.toThrow()
    await expect(provider.remove('build')).rejects.toThrow()
    await expect(provider.list()).rejects.toThrow()
    await expect(provider.readFile({ sandbox: 'build', path: '/x' })).rejects.toThrow()
    await expect(provider.writeFile({ sandbox: 'build', path: '/x' }, Buffer.alloc(0))).rejects.toThrow()
    await expect(provider.listDir({ sandbox: 'build', path: '/x' })).rejects.toThrow()
    await expect(provider.listImages()).rejects.toThrow()
    await expect(provider.removeImage('alpine')).rejects.toThrow()
    await expect(provider.createVolume('data')).rejects.toThrow()
    await expect(provider.listVolumes()).rejects.toThrow()
    await expect(provider.removeVolume('data')).rejects.toThrow()
  })
})

describe('unavailable error', () => {
  it('carries the MICROSANDBOX_UNAVAILABLE code and a fail-closed message', () => {
    const error = new MicrosandboxUnavailableError()
    expect(error.code).toBe(MICROSANDBOX_UNAVAILABLE)
    expect(error.name).toBe('MicrosandboxUnavailableError')
    expect(error.message).toContain('refusing microVM work')
  })
})

describe('exec orchestration', () => {
  const USABLE: MicrosandboxProvider['internals'] = {
    msbPath: join(tmpdir(), 'dsh-msb-usable'),
    platform: 'win32',
    qualify: () => 'usable',
  }

  it('forwards the exact argv and image to the runtime and returns its outcome', async () => {
    const { runtime, exec } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    const result = await provider.exec({
      image: 'python:alpine',
      argv: ['python3', '-c', 'print("hi")'],
      timeoutMs: 30_000,
      env: { FOO: 'bar' },
      workdir: '/work',
      user: 'nobody',
    })
    expect(exec).toHaveBeenCalledTimes(1)
    const request = exec.mock.calls[0]?.[0] as MicrosandboxExecRequest
    expect(request.image).toBe('python:alpine')
    expect(request.argv).toEqual(['python3', '-c', 'print("hi")'])
    expect(request.timeoutMs).toBe(30_000)
    expect(request.env).toEqual({ FOO: 'bar' })
    expect(request.workdir).toBe('/work')
    expect(request.user).toBe('nobody')
    // The provider fuses the request signal into the deadline it hands the runtime.
    expect(request.signal).toBeInstanceOf(AbortSignal)
    expect(result.exitCode).toBe(0)
    expect(result.stdout.toString()).toBe('stdout:python3 -c print("hi")')
    expect(result.runnerFailed).toBe(false)
  })

  it('classifies a provider-timeout deadline as timedOut, not runner failure', async () => {
    // The fake runtime honors the fused signal: it waits until the deadline
    // fires and reports the caller-owned classification.
    const { runtime } = fakeRuntime({
      exec: async (request: MicrosandboxExecRequest) => {
        await new Promise<void>((resolve) => {
          request.signal?.addEventListener('abort', () => { resolve() }, { once: true })
        })
        const reason = request.signal?.reason as { code?: string } | undefined
        return {
          exitCode: null,
          stdout: Buffer.alloc(0),
          stderr: Buffer.alloc(0),
          runnerFailed: false,
          timedOut: reason?.code === MICROSANDBOX_TIMEOUT,
          aborted: reason !== undefined && reason.code !== MICROSANDBOX_TIMEOUT,
        }
      },
    })
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    const result = await provider.exec({ image: 'alpine', argv: ['sleep', '10'], timeoutMs: 50 })
    expect(result.runnerFailed).toBe(false)
    expect(result.timedOut).toBe(true)
    expect(result.aborted).toBe(false)
  })

  it('classifies an upstream cancellation as aborted, not runner failure', async () => {
    const controller = new AbortController()
    const { runtime } = fakeRuntime({
      exec: async (request: MicrosandboxExecRequest) => {
        await new Promise<void>((resolve) => {
          request.signal?.addEventListener('abort', () => { resolve() }, { once: true })
        })
        return {
          exitCode: null,
          stdout: Buffer.alloc(0),
          stderr: Buffer.alloc(0),
          runnerFailed: false,
          aborted: true,
        }
      },
    })
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    const pending = provider.exec({ image: 'alpine', argv: ['sleep', '10'], signal: controller.signal })
    controller.abort()
    const result = await pending
    expect(result.runnerFailed).toBe(false)
    expect(result.aborted).toBe(true)
  })

  it('propagates a non-zero payload exit without calling it a runner failure', async () => {
    const { runtime } = fakeRuntime({
      exec: async () => ({
        exitCode: 42,
        stdout: Buffer.from('partial'),
        stderr: Buffer.from('boom'),
        runnerFailed: false,
      }),
    })
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    const result = await provider.exec({ image: 'alpine', argv: ['sh', '-c', 'exit 42'] })
    expect(result.exitCode).toBe(42)
    expect(result.stdout.toString()).toBe('partial')
    expect(result.stderr.toString()).toBe('boom')
    expect(result.runnerFailed).toBe(false)
  })

  it('preserves a runner-failure verdict from the runtime', async () => {
    const { runtime } = fakeRuntime({
      exec: async () => ({
        exitCode: null,
        stdout: Buffer.alloc(0),
        stderr: Buffer.alloc(0),
        runnerFailed: true,
        error: { code: 'SANDBOX_NOT_FOUND', message: 'no such sandbox' },
      }),
    })
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    const result = await provider.exec({ image: 'alpine', argv: ['true'] })
    expect(result.runnerFailed).toBe(true)
    expect(result.error?.code).toBe('SANDBOX_NOT_FOUND')
  })

  it('fails closed when disabled, never reaching the runtime', async () => {
    const { runtime, exec } = fakeRuntime()
    const { provider } = await setup({ enabled: false }, { ...USABLE, runtime })
    await expect(provider.exec({ image: 'alpine', argv: ['true'] })).rejects.toBeInstanceOf(
      MicrosandboxUnavailableError,
    )
    expect(exec).not.toHaveBeenCalled()
  })

  it('fails closed when the qualification verdict is unavailable, never reaching the runtime', async () => {
    const { runtime, exec } = fakeRuntime()
    const { provider } = await setup(
      { enabled: true },
      { msbPath: join(tmpdir(), 'dsh-msb-bad'), platform: 'win32', qualify: () => 'unavailable', runtime },
    )
    await expect(provider.exec({ image: 'alpine', argv: ['true'] })).rejects.toBeInstanceOf(
      MicrosandboxUnavailableError,
    )
    expect(exec).not.toHaveBeenCalled()
  })

  it('rejects an empty image reference before reaching the runtime', async () => {
    const { runtime, exec } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    await expect(provider.exec({ image: '', argv: ['true'] })).rejects.toThrow(
      'requires a non-empty image reference',
    )
    expect(exec).not.toHaveBeenCalled()
  })

  it('rejects an empty argv before reaching the runtime', async () => {
    const { runtime, exec } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    await expect(provider.exec({ image: 'alpine', argv: [] })).rejects.toThrow(
      'requires a non-empty argv',
    )
    expect(exec).not.toHaveBeenCalled()
  })
})

describe('lifecycle orchestration', () => {
  const USABLE: MicrosandboxProvider['internals'] = {
    msbPath: join(tmpdir(), 'dsh-msb-usable'),
    platform: 'win32',
    qualify: () => 'usable',
  }

  it('create forwards the name/image and returns the sandbox name', async () => {
    const { runtime, spies } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    const name = await provider.create({ name: 'build', image: 'debian:12', cpus: 2, memory: 1024 })
    expect(name).toBe('build')
    const spy = spies.create.mock.calls[0]?.[0] as MicrosandboxCreateRequest
    expect(spy.image).toBe('debian:12')
    expect(spy.cpus).toBe(2)
    expect(spy.memory).toBe(1024)
  })

  it('start/stop/remove/list forward their names to the runtime', async () => {
    const { runtime, spies } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    await provider.start('build')
    await provider.stop('build')
    await provider.remove('build')
    const names = await provider.list()
    expect(names).toEqual(['alpha', 'beta'])
    expect(spies.start).toHaveBeenCalledWith('build')
    expect(spies.stop).toHaveBeenCalledWith('build')
    expect(spies.remove).toHaveBeenCalledWith('build')
  })

  it('rejects an empty name before reaching the runtime', async () => {
    const { runtime, spies } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    await expect(provider.start('')).rejects.toThrow('requires a non-empty sandbox name')
    await expect(provider.create({ name: '', image: 'alpine' })).rejects.toThrow(
      'requires a non-empty sandbox name',
    )
    expect(spies.start).not.toHaveBeenCalled()
    expect(spies.create).not.toHaveBeenCalled()
  })

  it('rejects an empty create image before reaching the runtime', async () => {
    const { runtime, spies } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    await expect(provider.create({ name: 'build', image: '' })).rejects.toThrow(
      'requires a non-empty image reference',
    )
    expect(spies.create).not.toHaveBeenCalled()
  })

  it('fails closed when disabled, never reaching the runtime', async () => {
    const { runtime, spies } = fakeRuntime()
    const { provider } = await setup({ enabled: false }, { ...USABLE, runtime })
    await expect(provider.create({ name: 'build', image: 'alpine' })).rejects.toBeInstanceOf(
      MicrosandboxUnavailableError,
    )
    await expect(provider.list()).rejects.toBeInstanceOf(MicrosandboxUnavailableError)
    expect(spies.create).not.toHaveBeenCalled()
    expect(spies.list).not.toHaveBeenCalled()
  })
})

describe('filesystem orchestration', () => {
  const USABLE: MicrosandboxProvider['internals'] = {
    msbPath: join(tmpdir(), 'dsh-msb-usable'),
    platform: 'win32',
    qualify: () => 'usable',
  }

  it('readFile/writeFile/listDir forward the sandbox and absolute path', async () => {
    const { runtime, spies } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    const data = await provider.readFile({ sandbox: 'build', path: '/work/out.txt' })
    expect(data.toString()).toBe('bytes:/work/out.txt')
    await provider.writeFile({ sandbox: 'build', path: '/work/out.txt' }, Buffer.from('hi'))
    const entries = await provider.listDir({ sandbox: 'build', path: '/work' })
    expect(entries).toEqual(['/work/a', '/work/b'])
    expect(spies.readFile).toHaveBeenCalledWith({ sandbox: 'build', path: '/work/out.txt' })
    expect(spies.writeFile).toHaveBeenCalledWith({ sandbox: 'build', path: '/work/out.txt' }, Buffer.from('hi'))
    expect(spies.listDir).toHaveBeenCalledWith({ sandbox: 'build', path: '/work' })
  })

  it('rejects a non-absolute guest path before reaching the runtime', async () => {
    const { runtime, spies } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    await expect(provider.readFile({ sandbox: 'build', path: 'relative.txt' })).rejects.toThrow(
      'require an absolute guest path',
    )
    expect(spies.readFile).not.toHaveBeenCalled()
  })

  it('rejects an empty sandbox name before reaching the runtime', async () => {
    const { runtime, spies } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    await expect(provider.readFile({ sandbox: '', path: '/x' })).rejects.toThrow(
      'requires a non-empty sandbox name',
    )
    expect(spies.readFile).not.toHaveBeenCalled()
  })
})

describe('image orchestration', () => {
  const USABLE: MicrosandboxProvider['internals'] = {
    msbPath: join(tmpdir(), 'dsh-msb-usable'),
    platform: 'win32',
    qualify: () => 'usable',
  }

  it('listImages returns cached references and removeImage forwards the reference', async () => {
    const { runtime, spies } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    const images = await provider.listImages()
    expect(images).toEqual(['python:alpine'])
    await provider.removeImage('python:alpine')
    expect(spies.removeImage).toHaveBeenCalledWith('python:alpine')
  })

  it('rejects an empty image reference before reaching the runtime', async () => {
    const { runtime, spies } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    await expect(provider.removeImage('')).rejects.toThrow(
      'requires a non-empty image reference',
    )
    expect(spies.removeImage).not.toHaveBeenCalled()
  })
})

describe('volume orchestration', () => {
  const USABLE: MicrosandboxProvider['internals'] = {
    msbPath: join(tmpdir(), 'dsh-msb-usable'),
    platform: 'win32',
    qualify: () => 'usable',
  }

  it('createVolume/removeVolume forward names and listVolumes returns known volumes', async () => {
    const { runtime, spies } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    await provider.createVolume('data')
    const volumes = await provider.listVolumes()
    await provider.removeVolume('data')
    expect(volumes).toEqual(['data'])
    expect(spies.createVolume).toHaveBeenCalledWith('data')
    expect(spies.removeVolume).toHaveBeenCalledWith('data')
  })

  it('rejects an empty volume name before reaching the runtime', async () => {
    const { runtime, spies } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    await expect(provider.createVolume('')).rejects.toThrow('requires a non-empty sandbox name')
    await expect(provider.removeVolume('')).rejects.toThrow('requires a non-empty sandbox name')
    expect(spies.createVolume).not.toHaveBeenCalled()
    expect(spies.removeVolume).not.toHaveBeenCalled()
  })
})

describe('bind volume validation', () => {
  const USABLE: MicrosandboxProvider['internals'] = {
    msbPath: join(tmpdir(), 'dsh-msb-usable'),
    platform: 'win32',
    qualify: () => 'usable',
  }

  it('exec accepts absolute host and guest volume paths', async () => {
    const { runtime, exec } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    await provider.exec({
      image: 'alpine',
      argv: ['true'],
      volumes: [{ guestPath: '/mnt', hostPath: '/home/raum/work' }],
    })
    expect(exec).toHaveBeenCalledTimes(1)
  })

  it('exec rejects a relative host path before reaching the runtime', async () => {
    const { runtime, exec } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    await expect(provider.exec({
      image: 'alpine',
      argv: ['true'],
      volumes: [{ guestPath: '/mnt', hostPath: 'relative' }],
    })).rejects.toThrow('bind volumes require an absolute host path')
    expect(exec).not.toHaveBeenCalled()
  })

  it('exec rejects a relative guest mount point before reaching the runtime', async () => {
    const { runtime, exec } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    await expect(provider.exec({
      image: 'alpine',
      argv: ['true'],
      volumes: [{ guestPath: 'mnt', hostPath: '/home/raum/work' }],
    })).rejects.toThrow('bind volumes require an absolute guest mount point')
    expect(exec).not.toHaveBeenCalled()
  })

  it('create validates volumes the same way', async () => {
    const { runtime, spies } = fakeRuntime()
    const { provider } = await setup({ enabled: true }, { ...USABLE, runtime })
    await expect(provider.create({
      name: 'build',
      image: 'alpine',
      volumes: [{ guestPath: '/mnt', hostPath: 'relative' }],
    })).rejects.toThrow('bind volumes require an absolute host path')
    expect(spies.create).not.toHaveBeenCalled()
  })
})
