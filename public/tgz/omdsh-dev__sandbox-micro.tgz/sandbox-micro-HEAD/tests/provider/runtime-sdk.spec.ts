/**
 * SdkRuntime tests. The official `microsandbox` SDK is an N-API binding that
 * cannot boot a microVM without hardware virtualization, so this suite mocks
 * the module and verifies the runtime's orchestration through the real
 * `SdkRuntime` class: builder chains (image/cpus/memory/volumes/ephemeral),
 * named-sandbox reuse, exact-argv exec options, SDK-error mapping, ephemeral
 * teardown, and every lifecycle/fs/image/volume forwarding call.
 */

import { beforeEach, describe, expect, it, vi } from 'vitest'
import type { MicrosandboxRuntime } from '@deepseek-ai/dsh-sandbox-microsandbox/src/runtime.ts'
import { SdkRuntime } from '../../src/runtime-sdk.ts'

/** The mocked `microsandbox` module surface the runtime imports. */
const mocks = vi.hoisted(() => {
  const execStreamWith = vi.fn()
  const stop = vi.fn()
  const builderCreate = vi.fn()
  const builderVolume = vi.fn()
  const start = vi.fn()
  const get = vi.fn()
  const connect = vi.fn()
  const remove = vi.fn()
  const list = vi.fn()
  const fsOps = { read: vi.fn(), write: vi.fn(), list: vi.fn() }
  const imageList = vi.fn()
  const imageRemove = vi.fn()
  const volumeBuilderCreate = vi.fn()
  const volumeList = vi.fn()
  const volumeRemove = vi.fn()
  return {
    execStreamWith, stop, builderCreate, builderVolume, start, get, connect, remove, list, fsOps,
    imageList, imageRemove, volumeBuilderCreate, volumeList, volumeRemove,
  }
})

vi.mock('microsandbox', () => {
  const makeBuilder = () => {
    const builder = {
      image: vi.fn(() => builder),
      cpus: vi.fn(() => builder),
      memory: vi.fn(() => builder),
      ephemeral: vi.fn(() => builder),
      volume: mocks.builderVolume,
      create: mocks.builderCreate,
    }
    return builder
  }
  const Sandbox = {
    builder: vi.fn(() => makeBuilder()),
    start: mocks.start,
    get: mocks.get,
    remove: mocks.remove,
    list: mocks.list,
  }
  return {
    Sandbox,
    Image: { list: mocks.imageList, remove: mocks.imageRemove },
    Volume: {
      builder: vi.fn(() => ({ create: mocks.volumeBuilderCreate })),
      list: mocks.volumeList,
      remove: mocks.volumeRemove,
    },
  }
})

/** A minimal ExecOutput-shaped object the runtime reads. */
function execOutput(code: number, stdout: string, stderr: string) {
  return {
    code,
    success: code === 0,
    stdoutBytes: () => Buffer.from(stdout),
    stderrBytes: () => Buffer.from(stderr),
  }
}

let runtime: MicrosandboxRuntime

beforeEach(() => {
  vi.clearAllMocks()
  runtime = new SdkRuntime()
})

describe('exec orchestration', () => {
  it('builds an ephemeral sandbox with image, cpus, memory, volumes and runs the exact argv', async () => {
    mocks.builderCreate.mockResolvedValue({ execStreamWith: mocks.execStreamWith, stop: mocks.stop, name: 'ephemeral' })
    mocks.execStreamWith.mockResolvedValue({ collect: async () => execOutput(0, 'out', '') })
    const result = await runtime.exec({
      image: 'python:alpine',
      argv: ['python3', '-c', 'print(1)'],
      cpus: 2,
      memory: 512,
      timeoutMs: 30_000,
      env: { FOO: 'bar' },
      workdir: '/work',
      user: 'nobody',
      volumes: [{ guestPath: '/mnt', hostPath: '/home/raum/work', readonly: true }],
    })
    expect(result.exitCode).toBe(0)
    expect(result.stdout.toString()).toBe('out')
    expect(result.runnerFailed).toBe(false)
    // Builder chain: image + cpus + memory + volume + ephemeral, then create.
    const builder = (mocks.builderCreate.mock.instances[0] as {
      image: ReturnType<typeof vi.fn>
      cpus: ReturnType<typeof vi.fn>
      memory: ReturnType<typeof vi.fn>
      ephemeral: ReturnType<typeof vi.fn>
    })
    expect(builder.image).toHaveBeenCalledWith('python:alpine')
    expect(builder.cpus).toHaveBeenCalledWith(2)
    expect(builder.memory).toHaveBeenCalledWith(512)
    expect(builder.ephemeral).toHaveBeenCalledWith(true)
    expect(mocks.builderVolume).toHaveBeenCalledWith('/mnt', expect.any(Function))
    // The volume configure callback binds and marks read-only.
    const configure = mocks.builderVolume.mock.calls[0]?.[1] as (mount: { bind: ReturnType<typeof vi.fn> }) => unknown
    const mount = { bind: vi.fn(() => ({ readonly: vi.fn(() => 'configured') })) }
    configure(mount)
    expect(mount.bind).toHaveBeenCalledWith('/home/raum/work')
    // Exec options: exact argv, env, cwd, user. The SDK's own exec timer is
    // deliberately NOT set — the provider deadline owns timeouts.
    expect(mocks.execStreamWith).toHaveBeenCalledWith('python3', expect.any(Function))
    const configureExec = mocks.execStreamWith.mock.calls[0]?.[1] as (options: Record<string, ReturnType<typeof vi.fn>>) => unknown
    const options = {
      args: vi.fn(() => options),
      stdinBytes: vi.fn(() => options),
      timeout: vi.fn(() => options),
      envs: vi.fn(() => options),
      cwd: vi.fn(() => options),
      user: vi.fn(() => options),
    }
    configureExec(options)
    expect(options.args).toHaveBeenCalledWith(['-c', 'print(1)'])
    expect(options.timeout).not.toHaveBeenCalled()
    expect(options.envs).toHaveBeenCalledWith({ FOO: 'bar' })
    expect(options.cwd).toHaveBeenCalledWith('/work')
    expect(options.user).toHaveBeenCalledWith('nobody')
    // Ephemeral teardown: stop was called after exec.
    expect(mocks.stop).toHaveBeenCalledTimes(1)
  })

  it('reuses a RUNNING named sandbox by connecting, never starting it', async () => {
    // A running sandbox must be connected; start() on it would throw
    // SandboxStillRunningError (the real-host failure this guards against).
    mocks.get.mockResolvedValue({ status: 'running', connect: mocks.connect })
    mocks.connect.mockResolvedValue({ execStreamWith: mocks.execStreamWith, stop: mocks.stop, name: 'named-sandbox' })
    mocks.execStreamWith.mockResolvedValue({ collect: async () => execOutput(42, '', 'boom') })
    const result = await runtime.exec({ image: 'alpine', name: 'named-sandbox', argv: ['sh', '-c', 'exit 42'] })
    expect(result.exitCode).toBe(42)
    expect(result.runnerFailed).toBe(false)
    expect(mocks.get).toHaveBeenCalledWith('named-sandbox')
    expect(mocks.connect).toHaveBeenCalled()
    expect(mocks.start).not.toHaveBeenCalled()
    expect(mocks.builderCreate).not.toHaveBeenCalled()
    // Named sandbox is not torn down.
    expect(mocks.stop).not.toHaveBeenCalled()
  })

  it('starts a STOPPED named sandbox and reuses it', async () => {
    mocks.get.mockResolvedValue({ status: 'stopped', connect: mocks.connect, start: mocks.start })
    mocks.start.mockResolvedValue({ execStreamWith: mocks.execStreamWith, stop: mocks.stop, name: 'named-sandbox' })
    mocks.execStreamWith.mockResolvedValue({ collect: async () => execOutput(0, '', '') })
    await runtime.exec({ image: 'alpine', name: 'named-sandbox', argv: ['true'] })
    expect(mocks.get).toHaveBeenCalledWith('named-sandbox')
    expect(mocks.start).toHaveBeenCalled()
    expect(mocks.connect).not.toHaveBeenCalled()
    expect(mocks.builderCreate).not.toHaveBeenCalled()
    expect(mocks.stop).not.toHaveBeenCalled()
  })

  it('creates a named sandbox when attachment fails', async () => {
    mocks.get.mockRejectedValue(new Error('not found'))
    mocks.builderCreate.mockResolvedValue({ execStreamWith: mocks.execStreamWith, stop: mocks.stop, name: 'named-sandbox' })
    mocks.execStreamWith.mockResolvedValue({ collect: async () => execOutput(0, '', '') })
    await runtime.exec({ image: 'alpine', name: 'named-sandbox', argv: ['true'] })
    expect(mocks.get).toHaveBeenCalledWith('named-sandbox')
    expect(mocks.builderCreate).toHaveBeenCalled()
    expect(mocks.stop).not.toHaveBeenCalled()
  })

  it('maps a thrown SDK error to a structured runner failure', async () => {
    mocks.start.mockRejectedValue(Object.assign(new Error('sandbox exploded'), { code: 'SANDBOX_BROKEN' }))
    mocks.builderCreate.mockRejectedValue(Object.assign(new Error('create failed'), { code: 'CREATE_FAILED' }))
    const result = await runtime.exec({ image: 'alpine', name: 'missing', argv: ['true'] })
    expect(result.runnerFailed).toBe(true)
    expect(result.exitCode).toBeNull()
    expect(result.error?.code).toBe('CREATE_FAILED')
  })

  it('reports an empty argv as a runner failure without invoking the SDK exec', async () => {
    mocks.builderCreate.mockResolvedValue({ execStreamWith: mocks.execStreamWith, stop: mocks.stop, name: 'ephemeral' })
    const result = await runtime.exec({ image: 'alpine', argv: [] })
    expect(result.runnerFailed).toBe(true)
    expect(result.error?.code).toBe('EMPTY_ARGV')
    expect(mocks.execStreamWith).not.toHaveBeenCalled()
  })

  it('kills the payload handle when the deadline signal fires', async () => {
    const controller = new AbortController()
    const kill = vi.fn(async () => undefined)
    // collect never settles until the handle is killed; the deadline kill is
    // what lets the SDK call return (here modeled as a rejected collect).
    mocks.execStreamWith.mockResolvedValue({
      collect: vi.fn(async () => {
        await new Promise<void>((resolve) => {
          controller.signal.addEventListener('abort', () => { resolve() }, { once: true })
        })
        throw Object.assign(new Error('exec killed'), { code: 'ExecKilled' })
      }),
      kill,
    })
    const pending = runtime.exec({
      image: 'alpine',
      argv: ['sleep', '10'],
      signal: controller.signal,
    })
    // Give the runtime a tick to attach its abort listener, then fire.
    await new Promise(resolve => setTimeout(resolve, 10))
    controller.abort()
    const result = await pending
    expect(kill).toHaveBeenCalledTimes(1)
    expect(result.runnerFailed).toBe(false)
    expect(result.aborted).toBe(true)
    expect(result.timedOut).toBe(false)
  })

  it('classifies a fired deadline as timedOut only for the provider timeout reason', async () => {
    const controller = new AbortController()
    mocks.execStreamWith.mockResolvedValue({
      collect: vi.fn(async () => {
        await new Promise<void>((resolve) => {
          controller.signal.addEventListener('abort', () => { resolve() }, { once: true })
        })
        throw Object.assign(new Error('exec killed'), { code: 'ExecKilled' })
      }),
      kill: vi.fn(async () => undefined),
    })
    // The provider stamps its own TimeoutReason onto the fused signal; the
    // runtime must read it back and classify timedOut.
    const { TimeoutReason } = await import('@deepseek-ai/dsh-timeout')
    const pending = runtime.exec({
      image: 'alpine',
      argv: ['sleep', '10'],
      signal: controller.signal,
    })
    await new Promise(resolve => setTimeout(resolve, 10))
    const timeout = new TimeoutReason('MICROSANDBOX_TIMEOUT', 5000)
    controller.abort(timeout)
    const result = await pending
    expect(result.runnerFailed).toBe(false)
    expect(result.timedOut).toBe(true)
    expect(result.aborted).toBe(false)
  })

  it('does not attach a deadline listener when the request carries no signal', async () => {
    mocks.execStreamWith.mockResolvedValue({ collect: async () => execOutput(0, '', '') })
    const result = await runtime.exec({ image: 'alpine', argv: ['true'] })
    expect(result.runnerFailed).toBe(false)
    expect(result.exitCode).toBe(0)
  })

  it('skips optional exec options when the request omits them', async () => {
    mocks.execStreamWith.mockResolvedValue({ collect: async () => execOutput(0, '', '') })
    await runtime.exec({ image: 'alpine', argv: ['true'] })
    const configureExec = mocks.execStreamWith.mock.calls[0]?.[1] as (options: Record<string, ReturnType<typeof vi.fn>>) => unknown
    const options = {
      args: vi.fn(() => options),
      stdinBytes: vi.fn(() => options),
      timeout: vi.fn(() => options),
      envs: vi.fn(() => options),
      cwd: vi.fn(() => options),
      user: vi.fn(() => options),
    }
    configureExec(options)
    expect(options.args).toHaveBeenCalledWith([])
    expect(options.envs).not.toHaveBeenCalled()
    expect(options.cwd).not.toHaveBeenCalled()
    expect(options.user).not.toHaveBeenCalled()
  })

  it('maps a non-Error thrown value to a structured runner failure', async () => {
    mocks.start.mockRejectedValue('plain string failure')
    mocks.builderCreate.mockRejectedValue('plain string failure')
    const result = await runtime.exec({ image: 'alpine', name: 'missing', argv: ['true'] })
    expect(result.runnerFailed).toBe(true)
    expect(result.error?.code).toBe('MICROSANDBOX_ERROR')
    expect(result.error?.message).toBe('plain string failure')
  })

  it('maps a message-only object error to the generic code', async () => {
    mocks.builderCreate.mockRejectedValue({ message: 'no code here' })
    const result = await runtime.exec({ image: 'alpine', argv: ['true'] })
    expect(result.runnerFailed).toBe(true)
    expect(result.error?.code).toBe('MICROSANDBOX_ERROR')
    expect(result.error?.message).toBe('no code here')
  })

  it('maps a plain Error with no extra fields to the generic code', async () => {
    mocks.builderCreate.mockRejectedValue(new Error('plain error'))
    const result = await runtime.exec({ image: 'alpine', argv: ['true'] })
    expect(result.runnerFailed).toBe(true)
    expect(result.error?.code).toBe('MICROSANDBOX_ERROR')
    expect(result.error?.message).toBe('plain error')
  })

  it('maps an object with neither code nor message through String()', async () => {
    // An object that is not an Error and carries no usable message falls
    // through every structured branch to the String() fallback.
    mocks.builderCreate.mockRejectedValue({ code: 123 })
    const result = await runtime.exec({ image: 'alpine', argv: ['true'] })
    expect(result.runnerFailed).toBe(true)
    expect(result.error?.code).toBe('MICROSANDBOX_ERROR')
    expect(result.error?.message).toBe('[object Object]')
  })

  it('binds a writable volume without calling readonly()', async () => {
    mocks.builderCreate.mockResolvedValue({ execStreamWith: mocks.execStreamWith, stop: mocks.stop, name: 'ephemeral' })
    mocks.execStreamWith.mockResolvedValue({ collect: async () => execOutput(0, '', '') })
    await runtime.exec({
      image: 'alpine',
      argv: ['true'],
      volumes: [{ guestPath: '/mnt', hostPath: '/home/raum/work' }],
    })
    const configure = mocks.builderVolume.mock.calls[0]?.[1] as (
      mount: { bind: ReturnType<typeof vi.fn>; readonly: ReturnType<typeof vi.fn> },
    ) => unknown
    const mount = {
      bind: vi.fn(() => ({ readonly: vi.fn(() => 'configured') })),
      readonly: vi.fn(() => 'configured'),
    }
    configure(mount)
    expect(mount.bind).toHaveBeenCalledWith('/home/raum/work')
    expect(mount.readonly).not.toHaveBeenCalled()
  })
})

describe('lifecycle and data-surface forwarding', () => {
  it('create builds a named sandbox and returns its name', async () => {
    mocks.builderCreate.mockResolvedValue({ name: 'build', stop: mocks.stop })
    const name = await runtime.create({ name: 'build', image: 'debian:12', cpus: 1, memory: 256 })
    expect(name).toBe('build')
    expect(mocks.builderCreate).toHaveBeenCalled()
  })

  it('start, stop, remove, and list forward to the SDK statics', async () => {
    mocks.start.mockResolvedValue({})
    mocks.get.mockResolvedValue({ stop: mocks.stop })
    mocks.list.mockResolvedValue([{ name: 'a' }, { name: 'b' }])
    await runtime.start('a')
    await runtime.stop('a')
    await runtime.remove('a')
    const names = await runtime.list()
    expect(mocks.start).toHaveBeenCalledWith('a')
    expect(mocks.get).toHaveBeenCalledWith('a')
    expect(mocks.stop).toHaveBeenCalled()
    expect(mocks.remove).toHaveBeenCalledWith('a')
    expect(names).toEqual(['a', 'b'])
  })

  it('readFile, writeFile, and listDir use the sandbox fs surface', async () => {
    // The named sandbox is running, so fs operations connect instead of start.
    mocks.get.mockResolvedValue({ status: 'running', connect: mocks.connect })
    mocks.connect.mockResolvedValue({
      fs: vi.fn(() => mocks.fsOps),
      stop: mocks.stop,
    })
    mocks.fsOps.read.mockResolvedValue(new Uint8Array([1, 2, 3]))
    mocks.fsOps.list.mockResolvedValue([{ path: '/x/a' }, { path: '/x/b' }])
    const data = await runtime.readFile({ sandbox: 'build', path: '/x/out' })
    await runtime.writeFile({ sandbox: 'build', path: '/x/out' }, Buffer.from('hi'))
    const entries = await runtime.listDir({ sandbox: 'build', path: '/x' })
    expect(mocks.fsOps.read).toHaveBeenCalledWith('/x/out')
    expect(mocks.fsOps.write).toHaveBeenCalledWith('/x/out', Buffer.from('hi'))
    expect(mocks.fsOps.list).toHaveBeenCalledWith('/x')
    expect(Buffer.from(data)).toEqual(Buffer.from([1, 2, 3]))
    expect(entries).toEqual(['/x/a', '/x/b'])
  })

  it('listImages, removeImage, createVolume, listVolumes, and removeVolume forward', async () => {
    mocks.imageList.mockResolvedValue([{ reference: 'python:alpine' }])
    mocks.volumeList.mockResolvedValue([{ name: 'data' }])
    const images = await runtime.listImages()
    await runtime.removeImage('python:alpine')
    await runtime.createVolume('data')
    const volumes = await runtime.listVolumes()
    await runtime.removeVolume('data')
    expect(images).toEqual(['python:alpine'])
    expect(mocks.imageRemove).toHaveBeenCalledWith('python:alpine')
    expect(mocks.volumeBuilderCreate).toHaveBeenCalled()
    expect(volumes).toEqual(['data'])
    expect(mocks.volumeRemove).toHaveBeenCalledWith('data')
  })
})
