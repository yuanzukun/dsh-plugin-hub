/**
 * Real-host microVM acceptance matrix (migration plan step 4 of the
 * microsandbox adaptation Agent Note). Requires hardware virtualization:
 * `/dev/kvm` on Linux, Apple Silicon Hypervisor.framework on macOS, WHP on
 * Windows. Skips only when the host posture is `unsupported` (e.g. Linux
 * without `/dev/kvm`, x64 macOS); a `win32` host is `unknown` until the
 * qualification probe decides, so the suite runs there and the provider's
 * fail-closed gate arbitrates WHP availability. On a qualified host it runs
 * the full lifecycle through the REAL provider and SDK: qualification,
 * create, exec with captured output, guest filesystem write/read, stop, and
 * remove.
 *
 * Run with the provider enabled and the e2e config:
 *   pnpm run test:e2e packages/sandbox/sandbox-microsandbox/tests/real-host.e2e.ts
 */

import { describe, expect, it } from 'vitest'
import { Context } from 'cordis'
import {
  MicrosandboxProvider,
} from '@deepseek-ai/dsh-sandbox-microsandbox'
import type { MicrosandboxProvider as Provider } from '@deepseek-ai/dsh-sandbox-microsandbox'
import { getPlatformSupport } from '../../src/platform.ts'

/**
 * Hardware virtualization is the trust gate; only a posture the provider
 * itself declares unsupported self-skips. `win32` is `unknown` (WHP is not
 * cheaply provable from Node), so the suite runs and the qualification probe
 * is the deciding check — that is exactly what real-host acceptance is for.
 */
const hostUnsupported = getPlatformSupport() === 'unsupported'

async function provider(): Promise<Provider> {
  const ctx = new Context()
  await ctx.plugin(MicrosandboxProvider, { enabled: true })
  return ctx.microsandbox
}

describe.skipIf(hostUnsupported)('microsandbox real-host acceptance', () => {
  it('qualifies the host and resolves the package-owned msb binary', async () => {
    const sandbox = await provider()
    expect(sandbox.platformSupport()).not.toBe('unsupported')
    expect(sandbox.qualificationVerdict()).toBe('usable')
    expect(sandbox.executorPath()).not.toBeNull()
  })

  it('runs a payload and captures stdout with the guest exit code', async () => {
    const sandbox = await provider()
    const result = await sandbox.exec({
      image: 'alpine',
      argv: ['sh', '-c', 'echo hello-from-microvm'],
    })
    expect(result.runnerFailed).toBe(false)
    expect(result.exitCode).toBe(0)
    expect(result.stdout.toString()).toContain('hello-from-microvm')
  }, 180_000)

  it('creates a named sandbox, writes and reads a guest file, then stops and removes it', async () => {
    const sandbox = await provider()
    const name = `dsh-accept-${Date.now()}`
    try {
      await sandbox.create({ name, image: 'alpine', cpus: 1, memory: 256 })
      await sandbox.writeFile({ sandbox: name, path: '/tmp/acceptance.txt' }, Buffer.from('ok'))
      const data = await sandbox.readFile({ sandbox: name, path: '/tmp/acceptance.txt' })
      expect(data.toString()).toBe('ok')
      const entries = await sandbox.listDir({ sandbox: name, path: '/tmp' })
      expect(entries).toContain('/tmp/acceptance.txt')
    } finally {
      await sandbox.stop(name)
      await sandbox.remove(name)
    }
  }, 240_000)
})
