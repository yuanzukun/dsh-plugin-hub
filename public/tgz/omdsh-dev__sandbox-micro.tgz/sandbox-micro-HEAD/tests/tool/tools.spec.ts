/**
 * tool-microsandbox tests. The provider is injected as a fake so no hardware
 * virtualization is needed: the suite verifies tool registration, argument
 * validation, exec/fs forwarding to `ctx.microsandbox`, result shaping, and
 * the render contract.
 */

import { describe, expect, it, vi } from 'vitest'
import { Context } from 'cordis'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import ToolRegistry, { TOOL_ABORTED } from '@deepseek-ai/dsh-tools'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import AgentRegistry from '@deepseek-ai/dsh-agent'
import { MicrosandboxProvider } from '@deepseek-ai/dsh-sandbox-microsandbox'
import type { MicrosandboxExecResult, MicrosandboxFsRequest, MicrosandboxRuntime } from '@deepseek-ai/dsh-sandbox-microsandbox'
import * as ToolMicrosandbox from '@deepseek-ai/dsh-sandbox-microsandbox/tool'

/** A fake runtime injected into the real provider (no hardware needed). */
function fakeRuntime() {
  const exec = vi.fn(async (_request: unknown): Promise<MicrosandboxExecResult> => ({
    exitCode: 0,
    stdout: Buffer.from('hello from guest'),
    stderr: Buffer.alloc(0),
    runnerFailed: false,
  }))
  const readFile = vi.fn(async (_request: unknown): Promise<Buffer> => Buffer.from('file contents'))
  const writeFile = vi.fn(async (_request: unknown, _data: unknown) => undefined)
  const listDir = vi.fn(async (): Promise<string[]> => ['/tmp/a', '/tmp/b'])
  return { exec, readFile, writeFile, listDir }
}

async function setup() {
  const ctx = new Context()
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRegistry)
  await ctx.plugin(AgentRegistry)
  await ctx.plugin(MicrosandboxProvider, { enabled: true })
  const fake = fakeRuntime()
  ctx.microsandbox.internals = {
    msbPath: join(tmpdir(), 'dsh-tool-msb'),
    platform: 'win32',
    qualify: () => 'usable',
    runtime: fake as unknown as MicrosandboxRuntime,
  }
  await ctx.plugin(ToolMicrosandbox)
  return { ctx, fake }
}

/** Resolve one registered tool by name and run its execute with args. */
async function runTool(ctx: Context, name: string, args: Record<string, unknown>) {
  const tools = ctx.get('tools') as unknown as {
    get: (name: string) => { execute: (args: unknown, exec: { signal: AbortSignal; callId: unknown }) => Promise<unknown> } | undefined
  }
  const tool = tools.get(name)
  expect(tool, `tool ${name} registered`).toBeDefined()
  return tool!.execute(args, { signal: new AbortController().signal, callId: undefined })
}

describe('tool registration', () => {
  it('registers microsandbox_exec and microsandbox_fs', async () => {
    const { ctx } = await setup()
    const tools = ctx.get('tools') as unknown as {
      get: (name: string) => unknown
    }
    expect(tools.get('microsandbox_exec')).toBeDefined()
    expect(tools.get('microsandbox_fs')).toBeDefined()
  })

  it('exposes both tool schemas through the registry (experimental composition shape)', async () => {
    const { ctx } = await setup()
    const tools = ctx.get('tools') as unknown as {
      schemas: () => Array<{ name: string }>
    }
    const names = tools.schemas().map(schema => schema.name)
    expect(names).toContain('microsandbox_exec')
    expect(names).toContain('microsandbox_fs')
  })
})

describe('dormant fail-closed path', () => {
  it('tool calls surface MICROSANDBOX_UNAVAILABLE when the provider is unqualified', async () => {
    // Real provider, no internals injection, no hardware: the qualification
    // gate fails closed and the tool call must reject with the provider's
    // unavailable error instead of crashing or falling back unconfined.
    const ctx = new Context()
    await ctx.plugin(SystemPrompt)
    await ctx.plugin(ToolRegistry)
    await ctx.plugin(AgentRegistry)
    await ctx.plugin(MicrosandboxProvider, { enabled: true })
    await ctx.plugin(ToolMicrosandbox)
    const tools = ctx.get('tools') as unknown as {
      execute: (req: { name: string; arguments: Record<string, unknown>; signal: AbortSignal }) => Promise<unknown>
    }
    const result = await tools.execute({
      name: 'microsandbox_exec',
      arguments: { image: 'alpine', argv: ['true'] },
      signal: new AbortController().signal,
    }) as { isError?: boolean; error?: { info?: { code?: string } } }
    // dsh-tools wraps execute failures into a structured result; the code
    // must be the provider's fail-closed error, never an unconfined fallback.
    expect(result.isError).toBe(true)
    expect(result.error?.info?.code).toBe('MICROSANDBOX_UNAVAILABLE')
  })
})

describe('microsandbox_exec', () => {
  it('forwards image/argv/options to the provider and shapes the outcome', async () => {
    const { ctx, fake } = await setup()
    const result = await runTool(ctx, 'microsandbox_exec', {
      image: 'alpine',
      argv: ['echo', 'hi'],
      timeoutMs: 5000,
    }) as { exitCode: number; stdout: string; stderr: string; runnerFailed: boolean }
    expect(fake.exec).toHaveBeenCalledTimes(1)
    const request = fake.exec.mock.calls[0]?.[0] as { image: string; argv: string[]; timeoutMs: number }
    expect(request.image).toBe('alpine')
    expect(request.argv).toEqual(['echo', 'hi'])
    expect(request.timeoutMs).toBe(5000)
    expect(result.exitCode).toBe(0)
    expect(result.stdout).toBe('hello from guest')
    expect(result.runnerFailed).toBe(false)
  })

  it('forwards optional name/workdir and preserves deadline classification', async () => {
    const { ctx, fake } = await setup()
    fake.exec.mockResolvedValueOnce({
      exitCode: null,
      stdout: Buffer.alloc(0),
      stderr: Buffer.alloc(0),
      runnerFailed: false,
      timedOut: true,
      aborted: false,
    })
    const result = await runTool(ctx, 'microsandbox_exec', {
      image: 'alpine',
      argv: ['sleep', '10'],
      name: 'build',
      workdir: '/work',
      user: 'nobody',
    }) as { timedOut?: boolean; aborted?: boolean }
    const request = fake.exec.mock.calls[0]?.[0] as { name: string; workdir: string; user: string }
    expect(request.name).toBe('build')
    expect(request.workdir).toBe('/work')
    expect(request.user).toBe('nobody')
    expect(result.timedOut).toBe(true)
    expect(result.aborted).toBe(false)
  })

  it('propagates a runner failure with its structured error', async () => {
    const { ctx, fake } = await setup()
    fake.exec.mockResolvedValueOnce({
      exitCode: null,
      stdout: Buffer.alloc(0),
      stderr: Buffer.alloc(0),
      runnerFailed: true,
      error: { code: 'SANDBOX_NOT_FOUND', message: 'no such sandbox' },
    })
    const result = await runTool(ctx, 'microsandbox_exec', { image: 'alpine', argv: ['true'] }) as {
      runnerFailed: boolean
      error?: { code: string }
    }
    expect(result.runnerFailed).toBe(true)
    expect(result.error?.code).toBe('SANDBOX_NOT_FOUND')
  })

  it('rejects invalid argv types through tool validation', async () => {
    const { ctx, fake } = await setup()
    await expect(runTool(ctx, 'microsandbox_exec', { image: 'alpine', argv: 'not-an-array' }))
      .rejects.toBeInstanceOf(Error)
    expect(fake.exec).not.toHaveBeenCalled()
  })
})

describe('microsandbox_fs', () => {
  it('read forwards the sandbox and path and returns content', async () => {
    const { ctx, fake } = await setup()
    const result = await runTool(ctx, 'microsandbox_fs', {
      operation: 'read',
      sandbox: 'build',
      path: '/tmp/x.txt',
    }) as { operation: string; content: string; ok: boolean }
    const request = fake.readFile.mock.calls[0]?.[0] as MicrosandboxFsRequest
    expect(request.sandbox).toBe('build')
    expect(request.path).toBe('/tmp/x.txt')
    expect(result.content).toBe('file contents')
    expect(result.ok).toBe(true)
  })

  it('write forwards content and confirms', async () => {
    const { ctx, fake } = await setup()
    const result = await runTool(ctx, 'microsandbox_fs', {
      operation: 'write',
      sandbox: 'build',
      path: '/tmp/x.txt',
      content: 'hi',
    }) as { operation: string; ok: boolean }
    expect(fake.writeFile).toHaveBeenCalledTimes(1)
    const [request, data] = fake.writeFile.mock.calls[0] as [MicrosandboxFsRequest, Buffer]
    expect(request.path).toBe('/tmp/x.txt')
    expect(data.toString()).toBe('hi')
    expect(result.ok).toBe(true)
  })

  it('list returns guest directory entries', async () => {
    const { ctx } = await setup()
    const result = await runTool(ctx, 'microsandbox_fs', {
      operation: 'list',
      sandbox: 'build',
      path: '/tmp',
    }) as { entries: string[] }
    expect(result.entries).toEqual(['/tmp/a', '/tmp/b'])
  })

  it('write without content is rejected before reaching the provider', async () => {
    const { ctx, fake } = await setup()
    await expect(runTool(ctx, 'microsandbox_fs', {
      operation: 'write',
      sandbox: 'build',
      path: '/tmp/x.txt',
    })).rejects.toThrow('content is required when operation is write')
    expect(fake.writeFile).not.toHaveBeenCalled()
  })
})

// TOOL_ABORTED is a runtime constant; referencing it keeps the import contract honest.
void TOOL_ABORTED
