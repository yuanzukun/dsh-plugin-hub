/**
 * Pure presenter tests for the microsandbox tools. No provider or registry
 * needed: these functions render logged outcomes and must never throw.
 */

import { describe, expect, it } from 'vitest'
import { renderExec, renderFs, trimOutput } from '../../src/tool/render.ts'

describe('trimOutput', () => {
  it('strips trailing newlines', () => {
    expect(trimOutput('hello\n')).toBe('hello')
    expect(trimOutput('hello\n\n')).toBe('hello')
    expect(trimOutput('hello')).toBe('hello')
  })
})

describe('renderExec', () => {
  it('renders stdout, stderr, and a success exit line', () => {
    const blocks = renderExec({}, {
      exitCode: 0,
      stdout: 'out',
      stderr: 'err',
      runnerFailed: false,
    })
    expect(blocks).toEqual([{ type: 'text', text: 'out\nerr\n[microsandbox: exit code 0]' }])
  })

  it('renders only the status when there is no output', () => {
    const blocks = renderExec({}, { exitCode: 42, stdout: '', stderr: '', runnerFailed: false })
    expect(blocks).toEqual([{ type: 'text', text: '[microsandbox: exit code 42]' }])
  })

  it('renders a runner failure without a code', () => {
    const blocks = renderExec({}, {
      exitCode: null,
      stdout: '',
      stderr: '',
      runnerFailed: true,
    })
    expect(blocks).toEqual([{ type: 'text', text: '[microsandbox: runner failed]' }])
  })

  it('renders a runner failure with its code', () => {
    const blocks = renderExec({}, {
      exitCode: null,
      stdout: '',
      stderr: '',
      runnerFailed: true,
      error: { code: 'SANDBOX_NOT_FOUND', message: 'x' },
    })
    expect(blocks).toEqual([{ type: 'text', text: '[microsandbox: runner failed (SANDBOX_NOT_FOUND)]' }])
  })

  it('renders signal exit without a failure marker', () => {
    const blocks = renderExec({}, { exitCode: null, stdout: '', stderr: '', runnerFailed: false })
    expect(blocks).toEqual([{ type: 'text', text: '[microsandbox: exit code signal]' }])
  })

  it('renders timedOut and aborted markers', () => {
    const blocks = renderExec({}, {
      exitCode: null,
      stdout: '',
      stderr: '',
      runnerFailed: false,
      timedOut: true,
      aborted: true,
    })
    expect(blocks).toEqual([{ type: 'text', text: '[microsandbox: exit code signal, timed out, aborted]' }])
  })

  it('tolerates malformed shapes without throwing', () => {
    expect(renderExec({}, undefined)).toEqual([{ type: 'text', text: '[microsandbox: exit code signal]' }])
  })
})

describe('renderFs', () => {
  it('renders read content', () => {
    expect(renderFs({}, { operation: 'read', content: 'hello', ok: true }))
      .toEqual([{ type: 'text', text: 'hello' }])
  })

  it('renders read with missing content as empty', () => {
    expect(renderFs({}, { operation: 'read', ok: true }))
      .toEqual([{ type: 'text', text: '' }])
  })

  it('renders list with non-array entries as empty', () => {
    expect(renderFs({}, { operation: 'list', entries: 'oops', ok: true }))
      .toEqual([{ type: 'text', text: '' }])
  })

  it('renders list entries joined by newlines', () => {
    expect(renderFs({}, { operation: 'list', entries: ['/a', '/b'], ok: true }))
      .toEqual([{ type: 'text', text: '/a\n/b' }])
  })

  it('renders write confirmation with the path', () => {
    expect(renderFs({}, { operation: 'write', path: '/tmp/x', ok: true }))
      .toEqual([{ type: 'text', text: '[microsandbox: wrote /tmp/x]' }])
  })

  it('tolerates malformed shapes without throwing', () => {
    expect(renderFs({}, undefined)).toEqual([{ type: 'text', text: '[microsandbox: wrote ]' }])
  })
})
