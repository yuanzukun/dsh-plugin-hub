---
name: dsh-plugin-release
description: Check packed, Git, or npm release readiness for this DSH plugin without publishing: identity, compatibility, artifacts, clean consumer, and docs.
---

# Prepare a Plugin for Distribution

This skill proves that a plugin's ready-made artifact can be consumed through the selected channel. It is guidance, not publishing authority: never change remotes, push, tag, release, or run a registry publish command without a direct user request. Validate the repository's configured build, declaration, generated-asset, and artifact gates rather than assuming one fixed bundle layout.

## Select the channel

Record one or more intended channels:

- **Packed local artifact:** consumer installs the tarball produced inside this repository; no repository-relative `link:` or `file:` dependency is allowed.
- **Git source:** only supported when the repository deliberately tracks complete built output or documents a separate source-build step; the selected repository channel determines which model applies.
- **npm/tarball:** consumer installs prepacked files; the tarball must already contain every exported runtime, declaration, locale, icon, and client artifact.

Keep `private: true` unless npm publication is explicitly intended. A private package may still be consumed as a packed local artifact or from a GitHub Release. Distribution readiness does not grant permission to make it public.

## Audit identity and portability

Search source-controlled identity owners for template markers, old package names, stale row ids, absolute local paths, credentials, and forbidden local dependencies. Include all configured source, test, script, build, patch, display, and documentation owners; adjust the path list to the package's actual layout and exclude only generated or skill metadata directories that are not identity owners.

```sh
grep -R -n -E '@your-scope/dsh-plugin-template|plugin-template|Plugin Authors|link:|file:|\.\./' \
  --exclude-dir=node_modules --exclude-dir=lib --exclude-dir=.agents \
  package.json src tests cordis.patch.yml README.md README.zh.md AGENTS.md tsconfig*.json scripts
```

Review every match. Also reject template-only `src/LAYOUT.md` in a completed plugin repository; it belongs only in `plugin-template`. This template does not permit repository-relative `link:`, `file:`, repository-external source, or repository-external project-reference paths. Registry packages and runtime host peers are package dependencies, not filesystem inputs; every consumer must resolve the ready-made build from the repository's own manifest and lockfile.

Confirm the explicitly selected package name, version, description, keywords, license, repository metadata, Node engine, `engines.dsh`, package manager, Cordis plugin id, bundle rows, display resources, README examples, and lockfile all describe the same package. The package name may be scoped or unscoped; compare the exact name rather than requiring the template's `@scope/dsh-` prefix.

If `pnpm-workspace.yaml` declares `patchedDependencies`, verify every project-root patch path exists under `patches/`, targets the exact installed version, has a documented reason, and is available during a clean install. A DSH host patch under `patches/` must be a self-contained diff with a documented pinned host snapshot, regenerated and applied through `scripts/extract-patch.mjs` and `scripts/patch.sh` (configured in `patches/host-patch.config.json`), and must not appear in the published package's `files`. If no dependency or DSH-host patch is declared or planned, do not require `patches/` or patch-only scripts; their absence is the expected state.

## Run package verification

Install from the lockfile using the package's documented package manager, then run:

```sh
pnpm run lint
pnpm test
pnpm run build
pnpm pack --dry-run --json
```

The repository's Oxlint configuration is part of the static-analysis contract; verify that it and the local documentation are synchronized before treating the gate as meaningful.

Import every public runtime export from `lib/` under plain Node. Verify `package.json` `main`, `types`, `exports`, and `files` point to files that actually exist after the build. Function plugins must retain their namespace exports; service plugins must resolve to the intended default class. A client face must export `./client` and load through the ModuleLoader contract.

## Inspect the package archive

Run:

```sh
pnpm pack --dry-run --json
```

`pnpm pack` calculates the archive from the already-built output; inspect the complete file list. Require every runtime and declaration file promised by `main`, `types`, `exports`, and `files`, plus `cordis.patch.yml` when the package declares a bundle, the physical files behind the exported `./locale/*.json` and `./icon` resources (here `src/assets/locale/*.json` and `src/assets/icon.svg`), and any deliberately shipped client bundle. Reject credentials, `.env`, `.git`, tests, temporary stores, local caches, unexpected generated chunks, unexpected `node_modules` content, host runtime copies, or files outside the documented package contract. Required host peers must be absent from the archive; only a package that owns and provides a runtime may use `bundledDependencies`.

When practical, create the tarball in a temporary directory, install it into a fresh minimal consumer, and import every public entry. Use the tarball rather than the source checkout so missing `files`, exports, display resources, and runtime dependencies fail.

## Verify release installation

Install the packed artifact (or the published release URL) into an isolated profile after providing every required peer. Confirm the package manager adds the declared bundle when applicable, the `engines.dsh` compatibility check passes, the effective rows match the package's composition contract, and every manifest-declared runtime and type entry resolves from the archive. If the profile does not enable strict peer checking, record missing-peer rejection as unverified rather than claiming the package manager hard-failed. Load and follow `dsh-plugin-compose` at `.agents/skills/dsh-plugin-compose/SKILL.md` for isolated profile installation, compatibility exemptions, and real-entry activation. A successful pack command does not prove profile resolution, activation, or rendered display metadata.

## Documentation and repository state

Confirm README instructions cover prerequisites, local install, selected remote install, `allowBuilds` when applicable, profile activation, `engines.dsh` compatibility, configuration, display metadata, failures, verification, and known limitations. Keep public JSDoc synchronized with config, events, errors, and exports. Update the changelog or release notes only when that repository uses them.

Check source-control status and whitespace:

```sh
git status --short --branch
git diff --check
```

Ensure generated `lib/`, `node_modules/`, coverage output, and local tarballs are ignored unless the chosen distribution policy deliberately tracks them. Do not delete the user's uncommitted work, rewrite history, create a commit, or clean an unrelated file.

## Version and publication

If the repository has a release workflow, follow its documented version, tag, overwrite, checksum, and artifact naming policy; do not infer that an existing release may be overwritten or that a checksum is published. Tagging, GitHub release creation, npm authentication, `pnpm publish`, and pushing are separate user-authorized actions; when authorized, inspect the destination and package owner before executing them and never print tokens.

## Git source installations

A Git install fetches sources, not built artifacts. Do not claim Git readiness unless the repository has a self-contained `prepare` build and the consumer has approved that package's build script. Prefer npm or tarball distribution for this template, which ships ready-made `lib/` output and needs no install-time build permission.

## Release-readiness report

Report the selected channel, version/private status, placeholder/link audit, `engines.dsh` range, exact verification commands, public-entry imports, packed file findings, display resources, clean-consumer result, profile activation result, documentation status, Git status, and every unrun platform or credential-dependent step. State “ready” only for the channels actually proven, and list publication actions as not performed unless separately authorized.
