---
name: dsh-plugin-development
description: Coordinate the complete standalone DSH plugin workflow from plan through release readiness; load the stage skills this router names.
---

# Develop a Standalone DSH Plugin

This skill coordinates the complete standalone-plugin workflow. It is guidance, not an autonomous workflow engine: load the stage skill named below before performing that stage, preserve its handoff facts, and use current source when a copied example disagrees with the installed DSH version.

## Scope

Use this suite for an ESM Cordis plugin package based on this repository's `README.md`, including a package manifest with `engines.dsh`, optional display metadata, an optional profile bundle patch, and an optional browser face declared with `dsh.client`. A package may be host-only, client-only, or split across host and browser faces; record the actual owners rather than imposing one layout. The repository-local contract reference below is the source for the conventions this template can verify.

Read the applicable project-root files before implementation:

- `AGENTS.md`
- `README.md`
- `docs/dsh-plugin-contracts.md`
- the source, configuration, contract, display, and focused test owners named by the current package layout

## Required inputs

Establish these facts before editing. Ask one concise batch of questions when the request does not determine them:

- plugin objective and observable behavior;
- target directory or existing checkout;
- npm package name and stable Cordis plugin id;
- intended profile or consuming application;
- whether the package is new or existing;
- supported DSH range for `engines.dsh`;
- whether the package has a browser face and, if so, its slots and display resources;
- intended distribution channel: local checkout, Git, npm, or not yet selected;
- required host peers and their provider installation order;

Do not invent a package scope, target path, credential source, public default, or publishing destination. A package name may be scoped or unscoped; use the explicitly selected name and never infer an `@scope/dsh-` prefix.

## Shared handoff

At every stage transition, retain and update one concise handoff in the task state or user-approved design document:

```text
objective:
target:
packageName:
pluginId:
pluginForm: function | service
roles:
enginesDsh:
requiredServices:
optionalServices:
config:
displayMetadata:
clientFace:
bundleRows:
testTiers:
distribution:
completedChecks:
openDecisions:
```

Do not create a transient planning file merely to move between skills. Create a durable design document only when the user requests one or the plugin introduces a non-trivial public contract that needs its own repository documentation.

## Stage sequence

For an existing non-template repository, load `dsh-plugin-align` from `.agents/skills/dsh-plugin-align/SKILL.md` before planning. It audits and migrates repository mechanics without replacing product behavior; it does not scaffold over a non-empty target.

1. Load `dsh-plugin-plan` from `.agents/skills/dsh-plugin-plan/SKILL.md`. Leave planning only after the plugin form, roles, dependencies, configuration, DSH compatibility, display metadata, composition, test tiers, and distribution assumptions are explicit.
2. For a new repository, load `dsh-plugin-scaffold` from `.agents/skills/dsh-plugin-scaffold/SKILL.md`. Leave scaffolding only after identity, manifest metadata, display resources, dependency metadata, and the package's actual static-analysis, test, build, and pack checks pass. Skip file creation for an existing plugin, but still audit it against the scaffold exit conditions.
3. Load `dsh-plugin-implement` from `.agents/skills/dsh-plugin-implement/SKILL.md`. Implement only the planned behavior, update the package contract and display resources, delete template-only `src/LAYOUT.md` from the target repository, and keep all registrations owned by the plugin fiber.
4. Load `dsh-plugin-client` from `.agents/skills/dsh-plugin-client/SKILL.md` when the plugin owns a browser client. Keep the client boundary proportional to the UI, declare `dsh.client`, use the host-compatible client build, and verify the built ModuleLoader artifact.
5. Load `dsh-plugin-i18n` from `.agents/skills/dsh-plugin-i18n/SKILL.md` alongside it when the client owns product-visible copy. Register the feature's typed dictionaries, route copy through the locale seat, and prove fallback and disposal before composing or releasing the client face.
6. Load `dsh-plugin-compose` from `.agents/skills/dsh-plugin-compose/SKILL.md` when the package contributes a profile bundle or must be proven in an assembled DSH profile. Verify the effective rows and the compatibility decision rather than assuming the patch applied.
7. Load `dsh-plugin-test` from `.agents/skills/dsh-plugin-test/SKILL.md`. Run the smallest evidence that covers the behavior; product-visible plugins require a real Loader/profile composition test in addition to hand-mounted unit tests.
8. Load `dsh-plugin-release` from `.agents/skills/dsh-plugin-release/SKILL.md` for Git/npm delivery or when claiming the package is distribution-ready. Local-only work still performs its placeholder, exports, files-list, display-resource, and build-artifact checks.

Stages may be performed in one coding pass, but their exit conditions do not disappear. Planning is never skipped. Composition may be omitted only for a package that deliberately declares no bundle and is tested through its actual consumer. Publishing actions require a direct user request; release readiness never implies permission to publish, tag, push, or create a remote.

## Hard stops

- Apply `docs/dsh-plugin-contracts.md` for package form, dependencies, compatibility, display, client, and bundle composition. Do not restate, weaken, or bypass those rules in a stage.
- A function plugin named-exports `name`, `inject`, `Config`, and `apply` and has no default export. A service plugin default-exports its service class. Never mix the two forms.
- Every source, compiler, documentation, and skill input must resolve below the repository root. Add a registry dependency or local contract file instead of reading another checkout.
- Never commit credentials. Accept secret references or environment-variable names according to the owning DSH service.
- Do not add compatibility shims for hypothetical consumers or hardcode deployment-varying tunables.
- Never claim a check passed unless its exact command completed successfully. Distinguish code failures from proven sandbox, network, credential, or platform blockers.
- Do not publish, push, rewrite Git history, or configure a remote without explicit authority.

## Skill discovery

This suite is repository-local and is part of the template source. Preserve `.agents/skills/dsh-plugin-*` when creating a standalone plugin so future sessions rooted in that repository discover the workflow. Do not replace the directories with absolute symlinks that fail in another clone.

## Completion report

Report the final package path, plugin form, injected services, DSH compatibility range, display metadata, bundle rows, browser face when present, behavior added, commands actually run, distribution status, and any unverified environment-dependent step. Keep release actions and readiness claims separate.
