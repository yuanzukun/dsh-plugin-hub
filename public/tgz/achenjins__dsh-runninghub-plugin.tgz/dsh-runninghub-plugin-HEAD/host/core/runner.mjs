/**
 * `host/core/runner.mjs` —— 后台任务：提交 / 轮询 / 下载 / 落盘 / 通知
 *
 * 契约（**Lead 已锁定**）：
 *   - `new TaskRunner({api, keys, store, download, attach, onEvent, logger})`
 *   - `submit({workflowConfig, values, region, images})` → **立即返回** `{ok, taskId, jobId, status:'QUEUED'}`
 *   - `wait(taskId, timeoutMs)` → `{ok, task, results:[{kind,url?,localPath?,attachment?}]}`（**不取消任务**）
 *   - `cancel(taskId)` / `resume()` / `list()` / `get(taskId)` / `stop()`
 *   - **核心层不认识 DSH**：要通知外部就调注入的 `onEvent(event, payload)`；
 *     要变成聊天附件就调注入的 `attach({taskId, kind, bytes, url, filename, path})`。
 *
 * ⚠️ **两个可选注入的精确语义（很容易被误读成别的形状）**：
 *   - `download(spec)` —— **是「下载 + 落盘 + 附件」的整体接管，不是 URL 下载器**。
 *     `spec = {taskId, url, filename, kind, index}`；返回 `{ok, path?, bytes?:number, attachment?}`。
 *     **不注入**就走内置路径：`api.downloadTo(url, tmpPath)` → `store.writeOutput(...)` → `attach(...)`。
 *     千万别写成 `(url, opts) => api.downloadBytes(url, opts)` —— spec 是对象，会被当 URL 解析并抛
 *     `Failed to parse URL from [object Object]`。
 *   - `attach(spec)` —— 返回**附件对象本身**（`ImageAttachmentRef` / `FileAttachmentRef`），失败时抛错，
 *     **不要**返回 `{ok, attachment}`（那会变成两层嵌套，render 出来的 image block 不合法）。
 *     拆包由注入方做；附件失败不影响已经保存的结果文件。
 *
 * 排雷语义：
 *   - **提交阶段 TRANSPORT_UNCERTAIN** → 任务进 `UNCERTAIN` 状态，**绝不重投**，等用户核对；
 *     核对后用 `adopt(localTaskId, remoteTaskId)` 接回远端任务，或 `dismiss(localTaskId)` 结案。
 *   - **提交阶段 CAPACITY**（1520 / 421 并发已满、415 独占机器不足）→ RH 明确拒绝受理、没有扣费：
 *     任务进 `LOCAL_QUEUED`，**不冷却 Key**，后台按 30s → 60s → 120s 退避重投；
 *     本地有已提交的任务结束时也会提前唤醒一次。受理后记下 `remoteTaskId`，转入正常轮询。
 *     重投前先落 `localQueue.inflightAt`：进程在请求途中退出时，`resume()` 把它转成 `UNCERTAIN`，不再重投。
 *   - 本地 taskId 与远端 taskId 可以不同（排队 / 接回的任务）：一切远端调用都走 `remoteIdOf(task)`。
 *   - **查询阶段 uncertain** → 继续轮询（查询是幂等的，不值得把任务判死）。
 *   - `tasks/<taskId>.json` 是唯一真相 → 插件重启后 `resume()` 能把没跑完的轮询接上。
 *   - 轮询退避 3s → 5s → 10s，上限 15s；`unref()` 的定时器，不会拖住 Node 退出。
 *
 * @module dsh-runninghub-plugin/host/core/runner
 */

import fsSync from 'node:fs'
import fsPromises from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

import { asString, toNumber, nowMs, lossless, errorShape, clip, shortId, maskKey } from './util.mjs'
import { STATUS, normalizeStatus, isTerminal, MAX_UPLOAD_BYTES, withMediaTransfer } from './api.mjs'
import { buildNodeInfoList, validateRun } from './workflow.mjs'

/** 容量已满（1520 / 421 / 415）时本地排队的重投退避阶梯（毫秒），最后一级封顶；官方原文「请等待 30–120 秒后重试」。 */
export const CAPACITY_BACKOFF = [30000, 60000, 120000]

const QUEUED_UNCERTAIN_HINT = '本地排队后重投时连接中断 / 进程退出：**任务可能已经创建并扣费，绝不自动重发**。请到 RunningHub 后台按工作流核对，' +
  '找到了用 task.adopt 接回，确认没有用 task.dismiss 结案。'

/**
 * 任务的**远端** taskId。普通任务本地 id 就是远端 id；本地排队后受理的任务、
 * 以及从 UNCERTAIN 接回的任务，远端 id 记在 `remoteTaskId`。
 * @param {object} task 任务记录
 * @returns {string} 远端 taskId（本地排队中、尚未受理时为 `''`）
 */
export function remoteIdOf(task) {
  if (asString(task.remoteTaskId) !== '') return asString(task.remoteTaskId)
  const id = asString(task.taskId)
  return id.startsWith('queued-') || id.startsWith('uncertain-') ? '' : id
}

/** 轮询退避阶梯（毫秒），最后一级封顶。 */
export const POLL_BACKOFF = [3000, 5000, 10000]
/** 退避上限。 */
export const POLL_MAX_MS = 15000
/** 单个任务的最长轮询时间（默认 30 分钟）。 */
export const DEFAULT_TASK_TIMEOUT_MS = 30 * 60 * 1000
/** 一次 `wait()` 的默认上限。 */
export const DEFAULT_WAIT_MS = 60 * 1000
/** 收口时下载全部结果的**总预算**（慢 CDN 不能让终态写盘无限期拖住）。 */
export const DEFAULT_DOWNLOAD_MS = 60 * 1000
export const MAX_ATTACHMENT_BYTES = 64 * 1024 * 1024

const MEDIA_EXTENSIONS = {
  image: ['.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp', '.tif', '.tiff', '.avif', '.heic', '.heif'],
  audio: ['.mp3', '.wav', '.flac', '.ogg', '.m4a', '.aac', '.opus'],
  video: ['.mp4', '.mov', '.webm', '.avi', '.mkv', '.m4v'],
}

/** 只识别媒体容器头；文件名不能把配置或机密伪装成参考素材。 */
function mediaKind(head, ext) {
  const hex = head.subarray(0, 12).toString('hex')
  const text = head.subarray(0, 12).toString('ascii')
  if (hex.startsWith('89504e470d0a1a0a') || hex.startsWith('ffd8ff') || /^GIF8[79]a/.test(text) || text.startsWith('BM') || /^(49492a00|4d4d002a)/.test(hex)) return 'image'
  if (text.startsWith('RIFF')) {
    if (text.slice(8) === 'WEBP') return 'image'
    if (text.slice(8) === 'WAVE') return 'audio'
    if (text.slice(8) === 'AVI ') return 'video'
  }
  if (text.startsWith('ID3') || text.startsWith('fLaC') || text.startsWith('OggS') || (head[0] === 0xff && (head[1] & 0xe0) === 0xe0)) return 'audio'
  if (hex.startsWith('1a45dfa3')) return 'video'
  if (text.slice(4, 8) === 'ftyp') {
    const brands = head.subarray(8).toString('ascii')
    if (/avif|avis|heic|heix|hevc|hevx|mif1|msf1/.test(brands)) return 'image'
    return MEDIA_EXTENSIONS.audio.includes(ext) ? 'audio' : 'video'
  }
  return ''
}

/**
 * 取路径里的文件名（**跨平台**：Windows 的 `E:\a\b.png` 在 POSIX 上 `path.basename` 会整串返回）。
 * @param {string} p 路径
 * @returns {string} 文件名（取不到时回落到 `upload.bin`）
 */
export function basenameOf(p) {
  const s = asString(p)
  const cut = Math.max(s.lastIndexOf('/'), s.lastIndexOf('\\'))
  const base = cut >= 0 ? s.slice(cut + 1) : s
  return base !== '' ? base : 'upload.bin'
}
/** 连续多少次"查不到可用状态"后给一次可见提示（只提示，不放弃）。 */
export const STALL_WARN_AFTER = 6

/** `fileType`/kind → 扩展名（文件名缺扩展名时补齐，别落一堆叫 `9` 的文件）。 */
export const EXT_OF_TYPE = {
  png: 'png',
  jpg: 'jpg',
  jpeg: 'jpg',
  webp: 'webp',
  gif: 'gif',
  bmp: 'bmp',
  tiff: 'tiff',
  mp4: 'mp4',
  mov: 'mov',
  webm: 'webm',
  avi: 'avi',
  mkv: 'mkv',
  mp3: 'mp3',
  wav: 'wav',
  flac: 'flac',
  m4a: 'm4a',
  ogg: 'ogg',
  glb: 'glb',
  gltf: 'gltf',
  obj: 'obj',
  fbx: 'fbx',
  stl: 'stl',
  txt: 'txt',
  json: 'json',
  image: 'png',
  video: 'mp4',
  audio: 'wav',
  text: 'txt',
}

/** 终态。 */
export const FINAL_STATUSES = [STATUS.SUCCESS, STATUS.FAILED, STATUS.CANCEL, STATUS.ERROR, STATUS.UNCERTAIN]

/**
 * 轮询退避：第 n 次轮询用多少毫秒。
 *
 * ⚠️ `POLL_MAX_MS`（15s）是**退避增长的上限**，不是"配置值的上限"。
 * 早先写成 `Math.min(POLL_MAX_MS, initial * scale)`，于是用户把 `pollIntervalMs`
 * 配成 60s 时，实际间隔反而被**压到 15s** —— "逐步增加"变成了"逐步降低"。
 * 现在把配置值当**下限**，退避阶梯只在它之上往上长。
 *
 * @param {number} attempt 已轮询次数（从 0 开始）
 * @param {number} [initialMs] 配置的起始间隔
 * @returns {number} 毫秒
 */
export function pollDelay(attempt, initialMs = POLL_BACKOFF[0]) {
  const i = Math.max(0, Math.floor(toNumber(attempt, 0)))
  const initial = Math.max(1, toNumber(initialMs, POLL_BACKOFF[0]))
  const scale = i < POLL_BACKOFF.length ? POLL_BACKOFF[i] / POLL_BACKOFF[0] : 5 * 2 ** Math.min(i - 3, 20)
  return Math.max(initial, Math.min(POLL_MAX_MS, Math.round(initial * scale)))
}

/**
 * 从输出项里猜文件类型。
 *
 * **显式 `fileType` 字段优先于 URL 扩展名**：RH 的「隐写载图」（社区叫小黄鸭：视频/音频藏在 PNG 里）
 * 正是 `fileType=mp4` 而 URL 以 `.png` 结尾。这时按声明类型走，并打上 `steganography:true`，
 * **不假装它是普通图片**。
 *
 * @param {unknown} item 输出项（字符串 URL / `{fileUrl,fileType,url,fileName}`）
 * @param {string} [fallbackKind] 工作流的 outputKind
 * @returns {{url:string,kind:string,filename:string,declaredType:string,steganography?:boolean,note?:string}} 结果
 */
export function describeOutput(item, fallbackKind = 'image') {
  let url = ''
  let rawType = ''
  let filename = ''
  let nodeId = ''
  if (typeof item === 'string') {
    url = item
  } else if (item && typeof item === 'object') {
    url = asString(item.fileUrl || item.file_url || item.url || item.download_url || item.downloadUrl)
    rawType = asString(item.fileType || item.file_type || item.outputType)
    // `nodeId` **不是**文件名（RH 的旧族输出项里它只是产出节点的 id）
    filename = asString(item.fileName || item.filename || item.file_name)
    nodeId = item.nodeId !== undefined && item.nodeId !== null ? asString(item.nodeId) : ''
  }
  const urlText = (url + ' ' + filename).toLowerCase()
  if (filename === '') {
    const base = url.split('?')[0].split('/').pop() || ''
    filename = base !== '' ? base : 'output-' + shortId()
  }  /** 从一段文本里认类型（既认扩展名，也认裸的类型 token 如 `png`/`mp4`）。 @param {string} s 文本 @returns {string} 类型或 `''` */
  const kindOfText = (s) => {
    if (!s) return ''
    if (/\.(mp4|mov|webm|avi|mkv)\b/.test(s) || s.includes('video') || /\b(mp4|mov|webm|avi|mkv)\b/.test(s)) return 'video'
    if (/\.(mp3|wav|flac|m4a|ogg)\b/.test(s) || s.includes('audio') || /\b(mp3|wav|flac|m4a|ogg)\b/.test(s)) return 'audio'
    if (/\.(glb|gltf|obj|fbx|stl)\b/.test(s) || s.includes('3d') || /\b(glb|gltf|obj|fbx|stl)\b/.test(s)) return '3d'
    if (/\.(txt|json|md|csv)\b/.test(s) || /\b(txt|json|md|csv|text)\b/.test(s)) return 'text'
    if (/\.(png|jpe?g|webp|gif|bmp|tiff?)\b/.test(s) || s.includes('image') || /\b(png|jpe?g|webp|gif|bmp|tiff?)\b/.test(s)) return 'image'
    return ''
  }
  const declared = kindOfText(rawType.toLowerCase())
  const byUrl = kindOfText(urlText)
  const fb = ['image', 'video', 'audio', '3d', 'text'].includes(asString(fallbackKind)) ? asString(fallbackKind) : 'image'
  const kind = declared || byUrl || fb
  // 文件名缺扩展名时用声明的类型补上：`store.writeOutput()` 会拿它当落盘文件名，
  // 一堆没有扩展名的文件（如 `9`）既不能双击打开，也让下游按扩展名判类型失效。
  if (!/\.[0-9a-z]{1,5}$/i.test(filename)) {
    const ext = EXT_OF_TYPE[rawType.toLowerCase()] || EXT_OF_TYPE[kind] || ''
    if (ext) filename = filename + '.' + ext
  }
  const out = { url, kind, filename, declaredType: rawType }
  if (nodeId !== '') out.nodeId = nodeId
  if (declared && byUrl && declared !== byUrl) {
    out.steganography = true
    out.note =
      'RH 声明的类型是 ' +
      declared +
      '，但文件名/链接看起来是 ' +
      byUrl +
      '：这很可能是「隐写载图」（视频/音频藏在 PNG 里）。原图已保留，可用支持提取的工具（如 RHStudio2）取出真实内容。'
  }
  return out
}

/**
 * 把任务记录投影成给模型/UI 看的 lossless JSON（**不含明文 key**）。
 * @param {object} task 任务记录
 * @returns {object} 投影
 */
export function projectTask(task) {
  const t = task && typeof task === 'object' ? task : {}
  return lossless({
    taskId: asString(t.taskId),
    remoteTaskId: asString(t.remoteTaskId),
    jobId: asString(t.jobId),
    workflowName: asString(t.workflowName),
    workflowId: asString(t.workflowId),
    region: asString(t.region),
    keyMasked: asString(t.keyMasked),
    status: normalizeStatus(t.status) || STATUS.QUEUED,
    instanceType: asString(t.instanceType),
    createdAt: toNumber(t.createdAt, 0),
    updatedAt: toNumber(t.updatedAt, 0),
    finishedAt: toNumber(t.finishedAt, 0),
    pollCount: toNumber(t.pollCount, 0),
    nodeInfoCount: Array.isArray(t.nodeInfoList) ? t.nodeInfoList.length : 0,
    promptPreview: clip(asString(t.promptPreview), 120),
    outputs: Array.isArray(t.outputs) ? t.outputs : [],
    results: Array.isArray(t.results) ? t.results : [],
    failedReason: asString(t.failedReason),
    errorCode: asString(t.errorCode),
    errorMessage: asString(t.errorMessage),
    queryFailures: toNumber(t.queryFailures, 0),
    lastQueryError: asString(t.lastQueryError),
    uncertain: t.uncertain === true,
    hint: asString(t.hint),
    persisted: t.persisted !== false,
    localQueue: t.localQueue && typeof t.localQueue === 'object'
      ? { attempts: toNumber(t.localQueue.attempts, 0), nextAt: toNumber(t.localQueue.nextAt, 0) }
      : null,
  })
}

/* ══════════════════════════════ TaskRunner ══════════════════════════════ */

/**
 * 后台任务执行器。构造后即可 `submit()`；轮询在内部定时器上跑，`stop()` 收尾。
 */
export class TaskRunner {
  /**
   * @param {object} deps 依赖（全部由 Lead 注入）
   * @param {object} deps.api `RunningHubApi`
   * @param {object} deps.keys `KeyPool`
   * @param {object} deps.store `Store`
   * @param {(spec:{taskId:string,url:string,filename:string,kind:string}) => Promise<{ok:boolean,bytes?:number,path?:string,error?:object}>} [deps.download] 下载和保存结果（默认流式下载）
   * @param {(spec:{taskId:string,kind:string,bytes?:Uint8Array,url:string,filename:string,path?:string}) => Promise<any>} [deps.attach] 变成聊天附件（DSH 侧实现）
   * @param {(event:string, payload:object) => void} [deps.onEvent] 事件回调（`task.submitted` / `task.progress` / `task.done` / `task.failed` / `task.uncertain`）
   * @param {object} [deps.logger] 日志器
   * @param {()=>number} [deps.now] 注入时钟（测试用）
   * @param {(ms:number)=>Promise<void>} [deps.sleep] 注入等待（测试用）
   * @param {number} [deps.taskTimeoutMs] 单任务轮询上限
   * @param {number} [deps.maxWaitMs] `wait()` 的硬上限
   */
  constructor(deps = {}) {
    this.api = deps.api
    this.keys = deps.keys
    this.store = deps.store
    this.download = typeof deps.download === 'function' ? deps.download : null
    this.attach = typeof deps.attach === 'function' ? deps.attach : null
    this.onEvent = typeof deps.onEvent === 'function' ? deps.onEvent : null
    this.logger = deps.logger || null
    this.now = typeof deps.now === 'function' ? deps.now : nowMs
    this.sleepImpl = typeof deps.sleep === 'function' ? deps.sleep : null
    this.taskTimeoutMs = Math.max(1000, toNumber(deps.taskTimeoutMs, DEFAULT_TASK_TIMEOUT_MS))
    this.maxWaitMs = Math.max(1000, toNumber(deps.maxWaitMs, 30 * 60 * 1000))
    /** 收口时下载全部结果的总预算（默认 60s）。 */
    this.downloadTimeoutMs = Math.max(1000, toNumber(deps.downloadTimeoutMs, DEFAULT_DOWNLOAD_MS))
    /**
     * 文件系统访问。默认走 `node:fs`；单测可注入文件和 FileHandle 的实现
     * 不碰真实磁盘地验证"本地路径 → 上传"这条链。
     */
    this.fs = { existsSync: (p) => fsSync.existsSync(p), readFile: (p) => fsPromises.readFile(p), realpath: fsPromises.realpath, stat: fsPromises.stat, open: fsPromises.open, ...deps.fs }
    /** 第一次轮询前等多久（默认 3s；单测注入小值即可秒级跑完）。 */
    this.firstPollDelayMs = Math.max(0, toNumber(deps.firstPollDelayMs, POLL_BACKOFF[0]))
    this.pollIntervalMs = Math.max(1, toNumber(deps.pollIntervalMs, POLL_BACKOFF[0]))
    /** 容量已满时的本地排队退避阶梯（单测可注入小值）。 */
    this.capacityBackoff = Array.isArray(deps.capacityBackoff) && deps.capacityBackoff.length > 0
      ? deps.capacityBackoff.map((v) => Math.max(0, toNumber(v, 0)))
      : CAPACITY_BACKOFF.slice()
    /** 本地排队最多等多久（默认与单任务轮询上限相同），超时判 ERROR(CAPACITY_TIMEOUT)。 */
    this.capacityTimeoutMs = Math.max(1000, toNumber(deps.capacityTimeoutMs, this.taskTimeoutMs))
    /** @type {Map<string, {task:object, stopped:boolean}>} 在跑的任务 */
    this._live = new Map()
    this._taskLocks = new Map()
    this._waitReads = new Map()
    this._stopped = false
  }

  /** 安全日志（**只输出掩码**）。 @param {'info'|'warn'|'error'} level 级别 @param {string} msg 消息 @param {object} [meta] 附加 @returns {void} */
  _log(level, msg, meta) {
    const fn = this.logger && (this.logger[level] || this.logger.log)
    if (typeof fn !== 'function') return
    try {
      fn.call(this.logger, '[rh-runner] ' + msg, meta ? lossless(meta) : '')
    } catch {
      /* 忽略 */
    }
  }

  /** 发事件（失败不影响主流程）。 @param {string} event 事件名 @param {object} payload 载荷 @returns {void} */
  _emit(event, payload) {
    if (!this.onEvent) return
    try {
      this.onEvent(event, lossless(payload))
    } catch (e) {
      this._log('warn', 'onEvent(' + event + ') 抛异常：' + String((e && e.message) || e))
    }
  }

  /** 当前时间。 @returns {number} epoch ms */
  nowMs() {
    const v = toNumber(this.now(), 0)
    return v > 0 ? v : nowMs()
  }

  /** 等待（可注入）。 @param {number} ms 毫秒 @returns {Promise<void>} */
  _sleep(ms) {
    if (this.sleepImpl) return this.sleepImpl(Math.max(0, ms))
    return new Promise((r) => {
      const t = setTimeout(r, Math.max(0, ms))
      if (t && typeof t.unref === 'function') t.unref()
    })
  }

  /* ────────────────────────────── 读写流水 ────────────────────────────── */

  /** 读任务流水（找不到 / 读失败 → `undefined`，**不抛**）。 @param {string} taskId 任务 id @returns {Promise<object|undefined>} 任务 */
  async get(taskId) {
    const unsaved = this._live.get(asString(taskId))?.unsaved
    if (unsaved) return { ...unsaved }
    if (!this.store || typeof this.store.getTask !== 'function') return undefined
    try {
      const t = await this.store.getTask(taskId)
      return t && typeof t === 'object' ? t : undefined
    } catch (e) {
      this._log('warn', '读任务流水失败：' + String((e && e.message) || e))
      return undefined
    }
  }

  /**
   * 写任务流水（**不抛**：注入的 store 自己抛异常也只记 warn）。
   * 未写入的记录暂存于正在跟踪的任务里，落盘恢复后再结束跟踪。
   * @param {object} task 任务
   * @returns {Promise<boolean>} 是否写成功
   */
  async _save(task) {
    try {
      const r = await this.store.saveTask({ ...task, persisted: true, updatedAt: this.nowMs() }, { backup: false })
      if (!r || r.ok !== true) this._log('warn', '写任务流水失败：' + asString(r && r.error && r.error.message))
      task.persisted = !!(r && r.ok)
    } catch (e) {
      this._log('warn', '写任务流水抛异常：' + String((e && e.message) || e))
      task.persisted = false
    }
    const entry = this._live.get(asString(task.taskId))
    if (entry) {
      if (task.persisted) delete entry.unsaved
      else entry.unsaved = { ...task }
    }
    return task.persisted
  }

  /** 列任务投影（给 `task.list` 用）。 @param {{status?:string, limit?:number}} [opts] 过滤 @returns {Promise<object[]>} 投影数组 */
  async list(opts = {}) {
    let tasks = []
    try {
      tasks = await this.store.listTasks()
    } catch (e) {
      this._log('warn', '列任务流水失败：' + String((e && e.message) || e))
    }
    const merged = new Map(tasks.map(task => [task.taskId, task]))
    for (const entry of this._live.values()) if (entry.unsaved) merged.set(entry.unsaved.taskId, entry.unsaved)
    tasks = Array.from(merged.values()).filter(task => !opts.status || normalizeStatus(task.status) === normalizeStatus(opts.status))
    tasks.sort((a, b) => toNumber(a.createdAt, 0) - toNumber(b.createdAt, 0))
    const limit = Math.floor(toNumber(opts.limit, 0))
    return (limit > 0 ? tasks.slice(-limit) : tasks).map(projectTask)
  }

  /* ────────────────────── 参考素材：本地路径 → 上传 ────────────────────── */

  /**
   * 判断一个 `images` 值**是不是本地文件路径**（而不是"已经是 RH 文件名"）。
   *
   * 存在的文件需要上传；缺失的显式本地路径由 `_resolveImages` 报错。
   * `openapi/a.png` 等服务端文件名可以直接使用。
   * @param {string} value 原始值
   * @returns {boolean} 需要上传为 true
   */
  _isLocalPath(value) {
    const v = asString(value)
    if (v === '') return false
    try {
      return this.fs.existsSync(v) === true
    } catch {
      return false
    }
  }

  async _inspectMaterial(value, role, cache) {
    let handle
    try {
      const localPath = value.startsWith('file:') ? fileURLToPath(value) : value
      const real = await this.fs.realpath(localPath)
      const name = basenameOf(real).toLowerCase()
      const parts = real.toLowerCase().split(/[\\/]/)
      const dataDir = this.store?.dataDir ? await this.fs.realpath(this.store.dataDir) : ''
      const internal = dataDir ? path.relative(dataDir, real).split(path.sep)[0] : ''
      if (parts.some(part => ['.git', '.ssh', '.aws', '.codex', '.agents'].includes(part)) || /^(?:secrets?|credentials?|state|keys|config|settings)(?:\.(?:json|ya?ml|toml|ini|conf)(?:$|[.-])|$)/.test(name) || name.startsWith('.env') || ['workflows', 'tasks', 'prompts', 'logs', 'tmp'].includes(internal.toLowerCase())) {
        return { ok: false, error: errorShape('MATERIAL_REFUSED', '不能上传机密、配置或插件内部记录：' + value) }
      }
      const ext = path.extname(real).toLowerCase()
      const kind = Object.keys(MEDIA_EXTENSIONS).find(type => MEDIA_EXTENSIONS[type].includes(ext))
      if (!kind || (MEDIA_EXTENSIONS[role] && role !== kind)) return { ok: false, error: errorShape('MATERIAL_TYPE_REFUSED', '参考素材类型与节点不匹配：' + value) }
      handle = await this.fs.open(real, 'r')
      const stat = await handle.stat()
      if (!stat.isFile() || stat.size > MAX_UPLOAD_BYTES) return { ok: false, error: errorShape('MATERIAL_TOO_LARGE', '参考素材必须是文件且不超过 128 MiB：' + value) }
      const signature = JSON.stringify([kind, stat.size, stat.mtimeMs, stat.ctimeMs, stat.ino])
      const uploaded = cache.get(real)
      if (uploaded?.signature === signature) return { ok: true, path: real, kind, size: stat.size, uploaded }
      const head = Buffer.alloc(64)
      const { bytesRead } = await handle.read(head, 0, head.length, 0)
      if (mediaKind(head.subarray(0, bytesRead), ext) !== kind) return { ok: false, error: errorShape('MATERIAL_TYPE_REFUSED', '文件内容不是声明的媒体类型：' + value) }
      const bytes = await handle.readFile()
      if (bytes.length > MAX_UPLOAD_BYTES) return { ok: false, error: errorShape('MATERIAL_TOO_LARGE', '参考素材不得超过 128 MiB：' + value) }
      return { ok: true, path: real, kind, bytes, signature }
    } catch (e) {
      if (e.code === 'ENOENT') return { ok: false, error: errorShape('MATERIAL_NOT_FOUND', '参考素材不存在：' + value) }
      return { ok: false, error: errorShape('UPLOAD_FAILED', '参考素材读不到：' + value, { hint: String(e.message || e) }) }
    } finally {
      await handle?.close()
    }
  }

  /**
   * 把 `values.images` 里的**本地路径**逐个上传成 RH 文件名，其余原样放行。
   *
   * **必须用与 create 同一把 key、同一个 region**：换 key 上传会让文件落在另一把 key 的
   * 上下文里，create 时就找不到它 —— 所以这一步只能在 `keys.pick()` 之后做。
   *
   * 失败语义：**如实失败，绝不把本地路径透传出去**。透传的后果是 RunningHub 在 3 秒后回一句
   * `[node:LoadImage#420] ["image - Invalid image file: E:\..."]` —— 用户完全看不懂，
   * 而且以为"插件会上传"。宁可在本地就说清"第 2 个素材（节点 420）上传失败"。
   * @param {string} key 明文 key（与 create 同一把）
   * @param {string} region 地域
   * @param {object} values 运行参数（会被浅拷贝后替换 `images`）
   * @param {object} cfg 工作流配置（用来按节点 role 定 `fileType`）
   * @param {Map} uploadCache 本次提交或批量运行共享的上传记录
   * @returns {Promise<{ok:true,values:object,uploads:object[]}|{ok:false,error:object}>} 结果
   */
  async _resolveImages(key, region, values, cfg, uploadCache) {
    const nodes = Array.isArray(cfg && cfg.nodes) ? cfg.nodes : []
    const media = nodes.filter((n) => n && ['image', 'audio', 'video'].includes(n.role))

    // ── 素材集合 = 「调用方显式传的 images」 ∪ 「媒体角色节点的生效值（含配置默认值）」 ──
    //
    // ⚠️ 这里**不能**用 `media.length` 当开关。早先的写法是
    //     `media.length ? <只取 media 节点的值> : values.images`，
    //     于是配置里只要有**一个**媒体节点，调用方传给**其它节点**的条目就被整个丢掉 ——
    //     那些条目**既不进上传、也不进存在性检查**，但 buildNodeInfoList 仍会从原始
    //     `values.images` 取到它们，结果**本地绝对路径原样发给 RunningHub**：
    //     正是这一层要根除的 `Invalid image file: E:\...`（旧代码全量上传，属回退）。
    //
    // 用**并集**：显式传入的条目一律参与上传与存在性检查；媒体节点上的配置默认值也照旧参与
    //（那是"配置里写死了本地素材"的场景）。两者按 `(nodeId, fieldName)` 规范化后合并，
    // 所以同一个素材**不会**被上传两次。
    const explicit = values && typeof values.images === 'object' && values.images !== null ? values.images : {}
    // 复用 buildNodeInfoList 的键解析（`resolveTarget`）把调用方给的键（`420` / `420:image` / 角色名…）
    // 规范成 (nodeId, fieldName)，不自己重写一套。
    const explicitTargets = new Set(
      Object.keys(explicit).length > 0
        ? buildNodeInfoList(cfg, { images: explicit }).map((item) => item.nodeId + '\u0000' + item.fieldName)
        : [],
    )
    const isMediaNode = (item) => media.some((n) => String(n.nodeId) === item.nodeId && n.fieldName === item.fieldName)
    const images = Object.fromEntries(
      buildNodeInfoList(cfg, values, { includeDefaults: true })
        .filter((item) => explicitTargets.has(item.nodeId + '\u0000' + item.fieldName) || isMediaNode(item))
        .map((item) => [item.nodeId + ':' + item.fieldName, item.fieldValue]),
    )

    const entries = Object.entries(images).filter(([, v]) => v !== undefined && v !== null && asString(v) !== '')
    if (entries.length === 0) return { ok: true, values, uploads: [] }
    const localFiles = new Map()
    for (const [nodeRef, raw] of entries) {
      const value = asString(raw)
      const local = path.isAbsolute(value) || /^[A-Za-z]:[\\/]/.test(value) || /^(\.\.?[\\/]|file:)/.test(value)
      if (local || this._isLocalPath(value)) {
        const [nodeId, fieldName] = nodeRef.split(':')
        const role = nodes.find(node => String(node.nodeId) === nodeId && node.fieldName === fieldName)?.role
        localFiles.set(nodeRef, role)
      }
    }
    if (!this.api || typeof this.api.uploadFile !== 'function') {
      // 没有上传能力时**不能**把路径透传：那正是线上那个看不懂的远端报错
      const hasPath = localFiles.size > 0
      if (hasPath) {
        return {
          ok: false,
          error: errorShape('UPLOAD_FAILED', '参考素材是本地路径，但当前 api 不支持上传', {
            hint: '请在配置里改用 RunningHub 侧已有的文件名，或升级插件',
          }),
        }
      }
      return { ok: true, values, uploads: [] }
    }

    const scope = JSON.stringify([key, region])
    if (!uploadCache.has(scope)) uploadCache.set(scope, new Map())
    const cache = uploadCache.get(scope)
    const next = { ...images }
    const uploads = []
    for (let i = 0; i < entries.length; i++) {
      const [nodeRef, raw] = entries[i]
      const nodeId = nodeRef.split(':')[0]
      const value = asString(raw)
      if (!localFiles.has(nodeRef)) {
        // 已经是 RH 文件名 → **原样放行**（老调用方靠这条活着，别弄坏）
        uploads.push({ nodeId, action: 'passthrough', fileName: value })
        continue
      }
      let up, bytes, filename, fileType, reused
      try {
        const transferred = await withMediaTransfer(async () => {
          const material = await this._inspectMaterial(value, localFiles.get(nodeRef), cache)
          if (!material.ok) return { failure: material }
          filename = basenameOf(material.path)
          fileType = material.kind
          if (material.uploaded) return { response: { ok: true, fileName: material.uploaded.fileName, via: material.uploaded.via }, bytes: material.size, reused: true }
          const response = await this.api.uploadFile(key, region, material.bytes, filename, { fileType })
          if (response?.ok === true) cache.set(material.path, { signature: material.signature, fileName: response.fileName, via: response.via })
          return { response, bytes: material.bytes.length }
        })
        if (transferred.failure) return transferred.failure
        up = transferred.response
        bytes = transferred.bytes
        reused = transferred.reused
      } catch (e) {
        return {
          ok: false,
          error: errorShape('UPLOAD_FAILED', '第 ' + String(i + 1) + '/' + String(entries.length) + ' 个素材读取或上传失败：' + value, {
            hint: '节点 ' + nodeId + ' · ' + String((e && e.message) || e),
          }),
        }
      }
      if (!up || up.ok !== true) {
        const err = (up && up.error) || errorShape('UPLOAD_FAILED', '上传失败')
        return {
          ok: false,
          error: errorShape('UPLOAD_FAILED', '第 ' + String(i + 1) + '/' + String(entries.length) + ' 个素材上传失败（节点 ' + nodeId + '：' + filename + '）', {
            // `uploadFile` 已经把 v2 / legacy 两边的真实错误都带在 hint 里了，原样传出
            hint: asString(err.hint) || asString(err.message),
            nodeId: String(nodeId),
            index: i + 1,
            total: entries.length,
            cause: asString(err.cause || err.code),
            attempts: err.attempts,
          }),
        }
      }
      next[nodeRef] = up.fileName
      uploads.push({ nodeId, action: reused ? 'reused' : 'uploaded', fileName: asString(up.fileName), bytes, via: asString(up.via), fileType })
      this._log('info', (reused ? '素材复用' : '素材已上传') + ' node ' + nodeId + ' → ' + asString(up.fileName) + '（' + String(bytes) + 'B · via ' + asString(up.via) + '）')
    }
    return { ok: true, values: { ...values, images: next }, uploads }
  }

  /* ────────────────────────────── 提交 ────────────────────────────── */

  /**
   * 组装提交参数（纯函数，便于单测与 `task.status` 复用）。
   * @param {object} req `submit` 的入参
   * @returns {{ok:true, region:string, nodeInfoList:object[], instanceType:string, workflowId:string}|{ok:false,error:object}} 结果
   */
  _prepare(req) {
    const cfg = req && req.workflowConfig
    if (!cfg || typeof cfg !== 'object') {
      return { ok: false, error: errorShape('WORKFLOW_NOT_FOUND', 'submit 需要 workflowConfig') }
    }
    const workflowId = asString(cfg.rhWorkflowId)
    if (workflowId === '') {
      return {
        ok: false,
        error: errorShape('WORKFLOW_NOT_FOUND', '工作流配置缺少 rhWorkflowId', {
          hint: '先用 workflow.probe 取回节点提案，再 workflow.configure 落盘',
        }),
      }
    }
    const region = asString(req.region) || asString(cfg.region) || 'cn'
    // 图片：允许 images 直接给 RH 文件名；也可以给 {nodeId: value} 语义
    const values = { ...(req.values && typeof req.values === 'object' ? req.values : {}) }
    if (req.images && typeof req.images === 'object') {
      values.images = { ...(values.images || {}), ...req.images }
    }
    const issues = []
    const nodeInfoList = buildNodeInfoList(cfg, values, { issues })
    if (issues.length) return { ok: false, error: errorShape('INPUT_NOT_MAPPED', issues.map(issue => issue.message).join('；'), { issues }) }
    const instanceType = asString(req.instanceType) || asString(cfg.instanceType) || 'default'
    return { ok: true, region, nodeInfoList, instanceType, workflowId, values }
  }

  /**
   * 提交任务并**立即返回**。轮询在后台定时器上进行。
   *
   * @param {{workflowConfig:object, values?:object, region?:string, images?:object, instanceType?:string, validated?:boolean, uploadCache?:Map}} req 提交请求
   * @returns {Promise<{ok:true,taskId:string,jobId:string,status:string,region:string,instanceType:string,nodeInfoCount:number,keyMasked:string}|{ok:false,error:object}>} 结果
   */
  async submit(req = {}) {
    if (this._stopped) return { ok: false, error: errorShape('STOPPED', '插件已停止，无法提交新任务') }
    const prep = this._prepare(req)
    if (!prep.ok) return prep
    const cfg = req.workflowConfig
    const { region, instanceType, workflowId } = prep

    // ① 选 key —— **只在本 region 池里选，绝不跨池回退**
    if (!this.keys || typeof this.keys.pick !== 'function') {
      return { ok: false, error: errorShape('NO_KEY', 'TaskRunner 没有注入 keys') }
    }
    // ② 干跑校验（必填 / 枚举 / 范围）；只在没显式说 validated 时跑
    if (req.validated !== true) {
      const chk = validateRun({ ...cfg, region }, prep.values)
      if (!chk.ok) {
        return {
          ok: false,
          error: errorShape('NODE_MISSING', '运行前校验没过：' + chk.issues.map((i) => i.message).join('；'), {
            hint: '用 workflow.validate 看完整问题清单',
            issues: chk.issues,
          }),
        }
      }
    }

    // 余额不足的 Key 不会自己恢复：选 key 前先对到期的那几把查一次余额
    await this.keys.recheckDepleted(this.api, region)

    const uploadCache = req.uploadCache || new Map()
    const attempted = []
    let lastFailure = null
    // 第一把回「容量已满」的 key：后面的 key 都没受理时，就在它上面本地排队
    let capacity = null
    const enqueue = () => this._enqueueLocal(capacity, { req, cfg, region, instanceType, workflowId, values: prep.values })
    let picked, submitted, nodeInfoList
    for (;;) {
      picked = this.keys.pick({ region, exclude: attempted })
      if (!picked || picked.ok !== true) {
        if (capacity) return enqueue()
        return lastFailure || { ok: false, error: (picked && picked.error) || errorShape('NO_KEY', 'region=' + region + ' 没有可用 key') }
      }
      attempted.push(picked.id)
      // 只对明确拒绝的认证/额度/限流错误换 Key；未知提交结果必须立即停止。
      const resolved = await this._resolveImages(picked.key, region, prep.values, cfg, uploadCache)
      if (!resolved.ok) {
        const cause = asString(resolved.error && (resolved.error.cause || resolved.error.code))
        if (['AUTH', 'QUOTA', 'RATE_LIMIT'].includes(cause)) {
          this.keys.report(picked.id, cause)
          lastFailure = resolved
          continue
        }
        return capacity ? enqueue() : resolved
      }
      nodeInfoList = buildNodeInfoList(cfg, resolved.values, { includeDefaults: true })
      submitted = await this.api.createTask(picked.key, region, { workflowId, nodeInfoList, instanceType, addMetadata: true })
      if (submitted && submitted.ok === true) break
      lastFailure = await this._handleSubmitFailure(picked, submitted, cfg, region, nodeInfoList, instanceType, workflowId)
      const err = lastFailure.error || {}
      if (err.uncertain) return lastFailure
      if (err.code === 'CAPACITY') {
        // 并发/机器已满不是这把 key 的错：不冷却它；不同账号的 key 可能还有空位，先换下一把试
        if (!capacity) capacity = { picked, nodeInfoList, error: err }
        continue
      }
      if (!['AUTH', 'QUOTA', 'RATE_LIMIT'].includes(err.code)) return capacity ? enqueue() : lastFailure
    }

    const taskId = asString(submitted.taskId)
    const jobId = shortId('rhjob')
    const at = this.nowMs()
    const task = {
      taskId,
      jobId,
      workflowId,
      workflowName: asString(cfg.name) || asString(cfg.displayNameEn) || workflowId,
      workflowConfigId: asString(cfg.id),
      outputKind: asString(cfg.outputKind) || 'image',
      output: req.output && typeof req.output === 'object' ? { ...req.output } : null,
      region,
      keyId: picked.id,
      keyMasked: picked.maskedKey || maskKey(picked.key),
      instanceType,
      status: normalizeStatus(submitted.taskStatus) || STATUS.QUEUED,
      createdAt: at,
      trackingStartedAt: at,
      updatedAt: at,
      finishedAt: 0,
      pollCount: 0,
      nodeInfoList: lossless(nodeInfoList),
      promptPreview: clip(asString(prep.values.prompt), 200),
      outputs: [],
      results: [],
      failedReason: '',
      uncertain: false,
    }
    this.keys.report(picked.id, 'ok')
    const persisted = await this._save(task)
    this._log('info', '提交成功 taskId=' + taskId + ' region=' + region + ' ' + asString(task.keyMasked))
    this._emit('task.submitted', { taskId, jobId, status: task.status, workflowName: task.workflowName, region, persisted })
    this._startPolling(task)
    return {
      ok: true,
      taskId,
      jobId,
      status: task.status,
      region,
      instanceType,
      nodeInfoCount: nodeInfoList.length,
      keyMasked: asString(task.keyMasked),
      persisted,
      ...(persisted ? {} : { hint: '云端任务已创建，本地记录未保存；插件会继续跟踪，请勿重复提交。' }),
    }
  }

  /* ────────────────────────── 容量已满：本地排队 ────────────────────────── */

  /**
   * 第 n 次（从 1 起）容量重投前要等多久。
   * @param {number} attempt 已失败次数
   * @returns {number} 毫秒
   */
  _capacityDelay(attempt) {
    const steps = this.capacityBackoff
    const i = Math.min(Math.max(1, Math.floor(toNumber(attempt, 1))), steps.length) - 1
    return steps[i]
  }

  /**
   * 所有 key 都回「容量已满」：把任务落成 `LOCAL_QUEUED` 并**立即返回**，后台退避重投。
   *
   * 1520 / 415 是 RH 明确拒绝受理的业务码，任务没有建、也没有扣费，重投是安全的。
   * 排队任务**固定在第一次碰壁的那把 key 上**：参考图是用这把 key 上传的，换 key 不一定读得到。
   * @param {{picked:object,nodeInfoList:object[],error:object}} capacity 碰壁现场
   * @param {{req:object,cfg:object,region:string,instanceType:string,workflowId:string,values:object}} ctx 提交上下文
   * @returns {Promise<object>} 与成功提交同形的回执（`status:'LOCAL_QUEUED'`, `queued:true`）
   */
  async _enqueueLocal(capacity, ctx) {
    const { picked, nodeInfoList, error } = capacity
    const { req, cfg, region, instanceType, workflowId, values } = ctx
    const taskId = 'queued-' + shortId()
    const jobId = shortId('rhjob')
    const at = this.nowMs()
    const delay = this._capacityDelay(1)
    const hint = '并发或机器已满（' + (asString(error.bizCode) || asString(error.code)) + '），RunningHub 尚未受理、没有扣费。' +
      '任务已在本地排队，会自动重投；不要重复提交。'
    const task = {
      taskId,
      jobId,
      workflowId,
      workflowName: asString(cfg.name) || asString(cfg.displayNameEn) || workflowId,
      workflowConfigId: asString(cfg.id),
      outputKind: asString(cfg.outputKind) || 'image',
      output: req.output && typeof req.output === 'object' ? { ...req.output } : null,
      region,
      keyId: picked.id,
      keyMasked: picked.maskedKey || maskKey(picked.key),
      instanceType,
      status: STATUS.LOCAL_QUEUED,
      createdAt: at,
      trackingStartedAt: at,
      updatedAt: at,
      finishedAt: 0,
      pollCount: 0,
      nodeInfoList: lossless(nodeInfoList),
      promptPreview: clip(asString(values && values.prompt), 200),
      outputs: [],
      results: [],
      failedReason: '',
      uncertain: false,
      hint,
      localQueue: {
        attempts: 1,
        firstAt: at,
        nextAt: at + delay,
        lastCode: asString(error.bizCode) || asString(error.code),
        lastMessage: asString(error.message),
      },
    }
    const persisted = await this._save(task)
    this._log('info', '容量已满，本地排队 ' + taskId + ' region=' + region + ' ' + asString(task.keyMasked) + '，' + String(delay) + 'ms 后重投')
    this._emit('task.queued', { taskId, jobId, status: task.status, workflowName: task.workflowName, region, nextAt: task.localQueue.nextAt })
    this._startQueue(task, delay)
    return {
      ok: true,
      taskId,
      jobId,
      status: STATUS.LOCAL_QUEUED,
      queued: true,
      region,
      instanceType,
      nodeInfoCount: nodeInfoList.length,
      keyMasked: asString(task.keyMasked),
      persisted,
      hint,
    }
  }

  /**
   * 把一个 `LOCAL_QUEUED` 任务挂进后台重投链（幂等）。
   * @param {object} task 任务
   * @param {number} delayMs 首次重投前等待
   * @returns {void}
   */
  _startQueue(task, delayMs) {
    const taskId = asString(task.taskId)
    if (taskId === '' || this._stopped) return
    const existing = this._live.get(taskId)
    if (existing && !existing.stopped && existing.queued) return
    const entry = { task: { ...task }, stopped: false, queued: true, gen: 0, ...(task.persisted === false ? { unsaved: { ...task } } : {}) }
    if (task.output && this.store && typeof this.store.setTaskOutput === 'function') this.store.setTaskOutput(taskId, task.output)
    this._live.set(taskId, entry)
    this._queueChain(taskId, delayMs)
  }

  /**
   * 排下一次重投。用代数 `gen` 让「提前唤醒」作废旧的定时器，保证同一任务同时只有一条链。
   * @param {string} taskId 本地任务 id
   * @param {number} delayMs 延迟
   * @returns {void}
   */
  _queueChain(taskId, delayMs) {
    const entry = this._live.get(taskId)
    if (!entry || entry.stopped || !entry.queued) return
    const gen = ++entry.gen
    // 拿到锁后再比一次 gen：等锁期间若已排了新的一轮（退避或唤醒），这一轮作废
    const current = () => this._live.get(taskId) === entry && entry.gen === gen && !entry.stopped && !this._stopped
    void this._sleep(Math.max(0, toNumber(delayMs, 0)))
      .then(() => current() && this._withTaskLock(taskId, () => current() && this._retryQueued(taskId, entry)))
      .catch((e) => {
        this._log('error', '本地排队重投异常 taskId=' + taskId + '：' + clip(String((e && e.stack) || e), 300))
        const cur = this._live.get(taskId)
        if (cur === entry && !entry.stopped) this._queueChain(taskId, this._capacityDelay(toNumber(entry.task.localQueue && entry.task.localQueue.attempts, 1)))
      })
  }

  /**
   * 有已提交的任务结束时调用：提前唤醒同地域里**排得最早**的一个本地排队任务（槽位可能刚空出来）。
   * @param {string} region 地域
   * @returns {void}
   */
  _kickQueued(region) {
    let oldest = null
    for (const [id, entry] of this._live) {
      if (!entry.queued || entry.stopped) continue
      if ((asString(entry.task.region) || 'cn') !== (asString(region) || 'cn')) continue
      if (!oldest || toNumber(entry.task.createdAt, 0) < toNumber(oldest.entry.task.createdAt, 0)) oldest = { id, entry }
    }
    if (oldest) this._queueChain(oldest.id, 0)
  }

  /**
   * 重投一次本地排队任务（持有任务锁）。
   * @param {string} taskId 本地任务 id
   * @param {object} entry 跟踪项（调用方已确认仍是当前这一轮）
   * @returns {Promise<void>}
   */
  async _retryQueued(taskId, entry) {
    const task = entry.task
    const lq = task.localQueue
    const region = asString(task.region) || 'cn'
    const notCharged = '任务从未被 RunningHub 受理、没有扣费，可以放心重新提交。'

    if (this.nowMs() - lq.firstAt > this.capacityTimeoutMs) {
      await this._finishQueued(taskId, entry, {
        status: STATUS.ERROR,
        errorCode: 'CAPACITY_TIMEOUT',
        errorMessage: '排队超过 ' + String(Math.round(this.capacityTimeoutMs / 1000)) + 's 仍没有空闲并发 / 机器，已放弃重投',
        hint: notCharged + '可以先用 account.balance 看看并发占用。',
      })
      return
    }

    // 排队任务固定用原来那把 key（参考图是它上传的）
    const keyId = asString(task.keyId)
    const view = this.keys.list().find((k) => k.id === keyId)
    const raw = this.keys.rawKey(keyId)
    if (!view || !raw || view.invalid || view.depleted || view.enabled === false || (view.region && view.region !== region)) {
      await this._finishQueued(taskId, entry, {
        status: STATUS.ERROR,
        errorCode: 'NO_KEY',
        errorMessage: '排队期间这把 key 已不可用（' + (view ? (view.invalid ? '失效' : view.depleted ? '余额不足' : view.enabled === false ? '已禁用' : '地域变化') : '已删除') + '）',
        hint: notCharged,
      })
      return
    }
    if (view.cooldownRemainingMs > 0) {
      // 被限流冷却：等冷却结束再投，不算一次容量失败
      lq.nextAt = this.nowMs() + view.cooldownRemainingMs
      await this._save(task)
      this._queueChain(taskId, view.cooldownRemainingMs)
      return
    }

    // 先落 inflight 标记再发请求：进程在请求途中退出时，resume() 据此转 UNCERTAIN 而不是再投一次
    lq.inflightAt = this.nowMs()
    if (!await this._save(task)) {
      delete lq.inflightAt
      this._queueChain(taskId, this._capacityDelay(lq.attempts))
      return
    }
    const submitted = await this.api.createTask(raw, region, {
      workflowId: asString(task.workflowId),
      nodeInfoList: task.nodeInfoList,
      instanceType: asString(task.instanceType) || 'default',
      addMetadata: true,
    })
    delete lq.inflightAt
    // 期间即使 stop() 了也照常往下走：结果（尤其是已受理的 remoteTaskId）必须落盘，否则重启后会重复提交

    if (submitted && submitted.ok === true) {
      const at = this.nowMs()
      task.remoteTaskId = asString(submitted.taskId)
      task.status = normalizeStatus(submitted.taskStatus) || STATUS.QUEUED
      task.trackingStartedAt = at
      task.hint = ''
      lq.submittedAt = at
      lq.nextAt = 0
      this.keys.report(keyId, 'ok')
      entry.stopped = true
      this._live.delete(taskId)
      const persisted = await this._save(task)
      this._log('info', '本地排队任务已受理 ' + taskId + ' → ' + task.remoteTaskId + '（第 ' + String(lq.attempts + 1) + ' 次提交）')
      this._emit('task.submitted', { taskId, remoteTaskId: task.remoteTaskId, jobId: task.jobId, status: task.status, workflowName: task.workflowName, region, persisted })
      this._startPolling(task)
      return
    }

    const err = (submitted && submitted.error) || errorShape('BUSINESS', '提交失败')
    const code = asString(err.code)
    if (code === 'TRANSPORT_UNCERTAIN' || err.uncertain === true) {
      this.keys.report(keyId, 'TRANSPORT')
      this._emit('task.uncertain', { taskId, workflowId: task.workflowId, message: asString(err.message) })
      await this._finishQueued(taskId, entry, {
        status: STATUS.UNCERTAIN,
        uncertain: true,
        errorCode: code || 'TRANSPORT_UNCERTAIN',
        errorMessage: asString(err.message),
        failedReason: asString(err.message),
        hint: QUEUED_UNCERTAIN_HINT,
      })
      return
    }
    if (code === 'CAPACITY' || code === 'RATE_LIMIT') {
      if (code === 'RATE_LIMIT') this.keys.report(keyId, 'RATE_LIMIT')
      lq.attempts += 1
      lq.lastCode = asString(err.bizCode) || code
      lq.lastMessage = asString(err.message)
      const delay = this._capacityDelay(lq.attempts)
      lq.nextAt = this.nowMs() + delay
      await this._save(task)
      this._emit('task.progress', { taskId, status: task.status, attempts: lq.attempts, nextAt: lq.nextAt })
      this._queueChain(taskId, delay)
      return
    }
    // AUTH / QUOTA / 业务错误：RH 明确拒绝，任务没有建 → 收口为 ERROR，并照常回报 key 状态
    if (code === 'AUTH' || code === 'QUOTA') this.keys.report(keyId, code)
    await this._finishQueued(taskId, entry, {
      status: STATUS.ERROR,
      errorCode: code || 'BUSINESS',
      errorMessage: asString(err.message) || '重投被拒绝',
      hint: notCharged + (code === 'QUOTA' ? '这把 key 余额不足，充值或换一把再提交。' : code === 'AUTH' ? '这把 key 已失效，换一把再提交。' : asString(err.hint)),
    })
  }

  /**
   * 本地排队任务收口（不进轮询，直接写终态并唤醒下一个）。
   * @param {string} taskId 本地任务 id
   * @param {object} entry 跟踪项
   * @param {object} patch 终态字段
   * @returns {Promise<void>}
   */
  async _finishQueued(taskId, entry, patch) {
    const task = entry.task
    Object.assign(task, patch, { finishedAt: this.nowMs() })
    task.localQueue.nextAt = 0
    this._live.delete(taskId)
    await this._settle(taskId, task)
  }

  /**
   * 提交失败的统一处理：区分「明确被拒（换 key 有意义）」与「结果不确定（绝不重投）」。
   * @param {object} picked `keys.pick()` 的结果
   * @param {any} submitted `api.createTask` 的结果
   * @param {object} cfg 工作流配置
   * @param {string} region 地域
   * @param {object[]} nodeInfoList 参数
   * @param {string} instanceType 机型
   * @param {string} workflowId 工作流 id
   * @returns {Promise<{ok:false,error:object}>} 失败回执
   */
  async _handleSubmitFailure(picked, submitted, cfg, region, nodeInfoList, instanceType, workflowId) {
    const err = (submitted && submitted.error) || errorShape('BUSINESS', '提交失败')
    const code = asString(err.code)

    // 结果不确定：任务可能已经建好并扣费 → **不重投**，落一条 UNCERTAIN 流水等用户核对
    if (code === 'TRANSPORT_UNCERTAIN' || err.uncertain === true) {
      const taskId = 'uncertain-' + shortId()
      const at = this.nowMs()
      const task = {
        taskId,
        jobId: shortId('rhjob'),
        workflowId,
        workflowName: asString(cfg.name) || workflowId,
        region,
        keyId: picked.id,
        keyMasked: picked.maskedKey || maskKey(picked.key),
        instanceType,
        status: STATUS.UNCERTAIN,
        createdAt: at,
        updatedAt: at,
        finishedAt: at,
        pollCount: 0,
        nodeInfoList: lossless(nodeInfoList),
        outputs: [],
        results: [],
        failedReason: asString(err.message),
        errorCode: code,
        errorMessage: asString(err.message),
        uncertain: true,
        hint: '提交阶段连接中断/超时：**任务可能已经创建并扣费，绝不自动重发**。请到 RunningHub 后台按提交时间与工作流核对最近任务：' +
          '找到了就用 task.adopt（填远端 taskId）接回继续取结果；确认没有创建就用 task.dismiss 结案后再重跑。',
      }
      this.keys.report(picked.id, 'TRANSPORT')
      const persisted = await this._save(task)
      if (!persisted) this._deferSettlement(task)
      this._log('warn', '提交结果不确定' + (persisted ? '，已记 UNCERTAIN' : '，本地记录尚未保存') + '：' + asString(err.message))
      this._emit('task.uncertain', { taskId, workflowId, message: asString(err.message) })
      return { ok: false, error: errorShape('TRANSPORT_UNCERTAIN', asString(err.message), { hint: task.hint + (persisted ? '' : ' 本地记录尚未保存，插件正在补存。'), uncertain: true, localTaskId: taskId, persisted }) }
    }

    // 明确被拒：按分类回报，方便上层换 key 重试
    const outcome = code === 'AUTH' ? 'AUTH' : code === 'QUOTA' ? 'QUOTA' : code === 'RATE_LIMIT' ? 'RATE_LIMIT' : null
    if (outcome) this.keys.report(picked.id, outcome)
    return { ok: false, error: err }
  }

  /* ────────────────────────────── 轮询 ────────────────────────────── */

  /**
   * 启动后台轮询（幂等）。
   *
   * 用**可注入的 `_sleep`** 而不是裸 `setTimeout`：单测把 sleep 换快之后整条链路秒级跑完，
   * 生产里 `_sleep` 的定时器已经 `unref()`，不会拖住 Node 退出。
   * @param {object} task 任务记录
   * @returns {void}
   */
  _startPolling(task) {
    const taskId = asString(task.taskId)
    if (taskId === '' || this._stopped) return
    if (normalizeStatus(task.status) === STATUS.LOCAL_QUEUED) return this._startQueue(task, this.pollIntervalMs)
    const existing = this._live.get(taskId)
    if (existing && !existing.stopped) return
    const entry = { task: { ...task }, stopped: false, ...(task.persisted === false ? { unsaved: { ...task } } : {}) }
    if (task.output && this.store && typeof this.store.setTaskOutput === 'function') this.store.setTaskOutput(taskId, task.output)
    this._live.set(taskId, entry)
    this._pollChain(taskId, this.firstPollDelayMs)
  }

  /**
   * 排下一次轮询。
   *
   * **必须带 `.catch`**：`void promise.then(...)` 一旦 `_tick` 抛异常（落盘抖动、注入的 download 抛、
   * 任何没被内层 try 兜住的错），整条轮询链会**静默死掉** —— 任务永远停在 RUNNING，
   * `wait()` 只能等到超时，而且日志里什么都没有。这类"链子断了却没人知道"是最难查的。
   * 现在：崩了就记 error 日志 + 退避后重来（查询是幂等的），连续崩 5 次才收口成 ERROR。
   * @param {string} taskId 任务 id
   * @param {number} delayMs 延迟
   * @returns {void}
   */
  _pollChain(taskId, delayMs) {
    void this._sleep(Math.max(0, toNumber(delayMs, 0)))
      .then(() => this._tick(taskId))
      .catch((e) => this._onPollCrash(taskId, e))
  }

  /**
   * 轮询链异常的处理（**不让链子死掉**）。
   * @param {string} taskId 任务 id
   * @param {any} e 异常
   * @returns {void}
   */
  _onPollCrash(taskId, e) {
    const entry = this._live.get(taskId)
    const msg = String((e && e.message) || e)
    this._log('error', '轮询链异常 taskId=' + taskId + '（任务仍在 RH 侧跑）：' + clip(String((e && e.stack) || msg), 300))
    if (!entry || entry.stopped || this._stopped) return
    entry.crashes = toNumber(entry.crashes, 0) + 1
    if (entry.crashes > 5) {
      void this._finish(taskId, {
        status: STATUS.ERROR,
        errorCode: 'POLL_CRASH',
        errorMessage: '轮询连续异常 5 次，已停止：' + msg,
        hint: '任务在 RH 侧可能已完成：用 task.status 单查，或重开插件后 resume() 继续轮询',
      })
      return
    }
    this._pollChain(taskId, pollDelay(entry.crashes, this.pollIntervalMs))
  }

  /**
   * 一次轮询：查状态 → 终态则收口。
   * @param {string} taskId 任务 id
   * @returns {Promise<void>}
   */
  async _tick(taskId) {
    return this._withTaskLock(taskId, () => this._tickNow(taskId))
  }

  _withTaskLock(taskId, fn) {
    const previous = this._taskLocks.get(taskId) || Promise.resolve()
    const next = previous.then(fn, fn)
    const tail = next.then(() => undefined, () => undefined)
    this._taskLocks.set(taskId, tail)
    void tail.then(() => {
      if (this._taskLocks.get(taskId) === tail) this._taskLocks.delete(taskId)
    })
    return next
  }

  async _tickNow(taskId) {
    const entry = this._live.get(taskId)
    if (!entry || entry.stopped || this._stopped) return
    const task = entry.task
    if (entry.settling) return this._settle(taskId, task)
    const region = asString(task.region) || 'cn'
    const key = this._queryKeyFor(task)
    if (key === '') {
      // key 被判失效/删掉了：不能跨池借，直接判 ERROR 并说清原因
      await this._finish(taskId, {
        status: STATUS.ERROR,
        errorCode: 'NO_KEY',
        errorMessage: '轮询时该任务所属 region 已没有可用的 key',
        hint: '恢复一把 region=' + region + ' 的 key 后用 task.status 继续查（任务本身仍在 RunningHub 侧跑）',
      })
      return
    }

    task.pollCount = toNumber(task.pollCount, 0) + 1
    const ageMs = this.nowMs() - toNumber(task.trackingStartedAt || task.createdAt, 0)
    if (ageMs > this.taskTimeoutMs) {
      await this._finish(taskId, {
        status: STATUS.ERROR,
        errorCode: 'TIMEOUT',
        errorMessage: '超过 ' + String(Math.round(this.taskTimeoutMs / 1000)) + 's 仍未到终态，已停止轮询',
        hint: '任务在 RH 侧可能还在跑：task.status 可以继续单次查询；不要再提交一次（会重复扣费）',
      })
      return
    }

    const q = await this._queryOnce(key, region, remoteIdOf(task) || taskId)
    if (entry.stopped || this._stopped) return
    this._applyQuery(task, q)

    // **终态不先落盘**：先把结果下完再写一次流水。
    // 否则 `wait()` 会看到「status=SUCCESS 但 results 还是空」的中间态（竞态）。
    if (FINAL_STATUSES.includes(normalizeStatus(task.status))) {
      this._emit('task.progress', { taskId, status: task.status, pollCount: task.pollCount })
      await this._settle(taskId, task)
      return
    }
    await this._save(task)
    this._emit('task.progress', { taskId, status: task.status, pollCount: task.pollCount })
    // 没到终态 → 按退避阶梯继续（仍然走可注入的 sleep；带 catch，链子不会静默断）
    this._pollChain(taskId, pollDelay(task.pollCount, this.pollIntervalMs))
  }

  /**
   * 取任务所属 key 的明文（**只在本 region 池里找**；找不到返回 `''`）。
   * @param {object} task 任务
   * @returns {string} 明文 key 或 `''`
   */
  _keyFor(task) {
    if (!this.keys || typeof this.keys.rawKey !== 'function') return ''
    const direct = this.keys.rawKey(asString(task.keyId))
    const available = typeof this.keys.isAvailable !== 'function' || this.keys.isAvailable(asString(task.keyId))
    const current = typeof this.keys.list === 'function' ? this.keys.list().find((entry) => entry.id === task.keyId) : null
    const sameRegion = !current || current.region === (asString(task.region) || 'cn')
    if (available && sameRegion && typeof direct === 'string' && direct !== '') return direct
    // 原 key 被删了：退而在同 region 里挑一把（仍然不跨池）
    if (typeof this.keys.pick === 'function') {
      const p = this.keys.pick({ region: asString(task.region) || 'cn' })
      if (p && p.ok === true) {
        task.keyId = p.id
        task.keyMasked = p.maskedKey || maskKey(p.key)
        return p.key
      }
    }
    return ''
  }

  /**
   * 只读查询用的 key：优先用任务原来那把（**冷却中也可以**——冷却是为了保护付费提交，
   * 查询是幂等的；而且提交不确定后那把 key 正好在 30s 冷却里，接回时不该被它挡住），
   * 原 key 失效 / 被删 / 地域不符时退回 `_keyFor` 在同地域里挑。
   * @param {object} task 任务（可能被改写 keyId / keyMasked）
   * @returns {string} 明文 key 或 `''`
   */
  _queryKeyFor(task) {
    const view = this.keys.list().find((k) => k.id === task.keyId)
    if (view && !view.invalid && view.enabled !== false && view.region === (asString(task.region) || 'cn')) return this.keys.rawKey(view.id)
    return this._keyFor(task)
  }

  /**
   * 查一次任务（`outputs` 优先，失败退回 `/openapi/v2/query`）。
   * **查询阶段的不确定不是错误**：继续轮询即可（查询幂等）。
   * @param {string} key 明文 key
   * @param {string} region 地域
   * @param {string} taskId 任务 id
   * @returns {Promise<object>} 归一化的查询结果
   */
  async _queryOnce(key, region, taskId) {
    const canOutputs = this.api && typeof this.api.queryOutputs === 'function'
    if (canOutputs) {
      const r = await this.api.queryOutputs(key, region, taskId)
      if (r && r.ok === true) {
        return { ok: true, status: normalizeStatus(r.status), outputs: Array.isArray(r.outputs) ? r.outputs : [], failedReason: asString(r.failedReason), via: 'outputs' }
      }
      const code = asString(r && r.error && r.error.code)
      if (code === 'AUTH' || code === 'QUOTA') return { ok: false, code, message: asString(r.error.message) }
      // 其余（含 TRANSPORT_UNCERTAIN / SERVER）继续走 v2 兜底
      if (this.api && typeof this.api.queryV2 === 'function') {
        const v2 = await this.api.queryV2(key, region, taskId)
        if (v2 && v2.ok === true) return { ok: true, status: normalizeStatus(v2.status), outputs: Array.isArray(v2.results) ? v2.results : [], failedReason: asString(v2.failedReason), via: 'v2' }
        return { ok: false, code: asString(v2 && v2.error && v2.error.code), message: asString(v2 && v2.error && v2.error.message) }
      }
      return { ok: false, code, message: asString(r.error.message) }
    }
    const v2 = await this.api.queryV2(key, region, taskId)
    if (v2 && v2.ok === true) return { ok: true, status: normalizeStatus(v2.status), outputs: Array.isArray(v2.results) ? v2.results : [], failedReason: asString(v2.failedReason), via: 'v2' }
    return { ok: false, code: asString(v2 && v2.error && v2.error.code), message: asString(v2 && v2.error && v2.error.message) }
  }

  /**
   * 把查询结果写回任务对象（**查询阶段不确定 = 保持原状态继续轮询**）。
   * @param {object} task 任务
   * @param {object} q 查询结果
   * @returns {void}
   */
  _applyQuery(task, q) {
    if (!q || q.ok !== true) {
      const code = asString(q && q.code)
      if (code === 'AUTH') {
        this.keys.report(asString(task.keyId), 'AUTH')
        task.lastQueryError = 'AUTH'
        return // 下次 _keyFor 会换一把同 region 的 key
      }
      if (code === 'QUOTA') {
        this.keys.report(asString(task.keyId), 'QUOTA')
        task.lastQueryError = 'QUOTA'
        return
      }
      // TRANSPORT_UNCERTAIN / SERVER：查询幂等 → **继续轮询**
      task.lastQueryError = code || 'UNKNOWN'
      task.queryFailures = toNumber(task.queryFailures, 0) + 1
      this._warnIfStalled(task)
      return
    }
    const st = normalizeStatus(q.status)
    if (st === '') {
      // **查得到响应、但拿不到可用状态**（典型：`/openapi/v2/query` 对旧族 taskId 返回空 status）。
      // 这不能算"查询成功" —— 否则 queryFailures 永远是 0，这个指标就变成摆设
      // （`tests/core/runner.test.mjs` 锁定了这一点）。
      task.queryFailures = toNumber(task.queryFailures, 0) + 1
      task.lastQueryError = q.via ? 'EMPTY_STATUS:' + asString(q.via) : 'EMPTY_STATUS'
      this._warnIfStalled(task)
      return
    }
    task.queryFailures = 0
    task.lastQueryError = ''
    task.status = st
    if (Array.isArray(q.outputs) && q.outputs.length > 0) task.outputs = lossless(q.outputs)
    if (asString(q.failedReason) !== '') task.failedReason = asString(q.failedReason)
    task.queryVia = asString(q.via)
  }

  /**
   * 连续查不到可用状态时给用户一条可见的提示（**只提示，不放弃**）。
   *
   * 真正决定"什么时候不再轮询"的是 `_tick` 的墙钟上限 `taskTimeoutMs`；
   * 这里做的是"别让用户对着一个永远不动的 RUNNING 干等却不知道为什么"。
   * @param {object} task 任务
   * @returns {void}
   */
  _warnIfStalled(task) {
    const n = toNumber(task.queryFailures, 0)
    if (n !== STALL_WARN_AFTER) return // 只在刚跨过阈值那一次提示
    this._log(
      'warn',
      '任务 ' + asString(task.taskId) + ' 连续 ' + String(n) + ' 次查询都拿不到可用状态（最后错误：' + asString(task.lastQueryError) + '），仍在轮询直到超时',
    )
    task.hint =
      '连续 ' + String(n) + ' 次查询都没有返回可用状态（最后：' + asString(task.lastQueryError) + '）。' +
      '任务在 RunningHub 侧可能仍在跑：可以继续等，或去后台按工作流核对。'
    this._emit('task.stalled', {
      taskId: asString(task.taskId),
      queryFailures: n,
      lastQueryError: asString(task.lastQueryError),
      status: normalizeStatus(task.status),
    })
  }

  /**
   * 收口：终态后下载结果并通知外部。**只在全部收尾完成后才把终态写进流水**，
   * 这样 `tasks/<taskId>.json` 里看到 SUCCESS 时 `results` 一定已经就绪。
   * @param {string} taskId 任务 id
   * @param {object} [memTask] 内存里最新的任务（比流水更新）
   * @returns {Promise<void>}
   */
  async _settle(taskId, memTask) {
    let entry = this._live.get(taskId)
    const stored = await this.get(taskId)
    const task = { ...(stored || {}), ...(memTask || entry?.task || {}), taskId }
    if (asString(task.taskId) === '') return
    if (!entry) {
      entry = { task, stopped: false }
      this._live.set(taskId, entry)
    }
    if (!entry.settling) {
      if (normalizeStatus(task.status) === STATUS.SUCCESS) task.results = await this._collect(task)
      task.finishedAt = this.nowMs()
      entry.settling = true
    }
    entry.task = task
    if (!await this._save(task)) {
      this._pollChain(taskId, this.pollIntervalMs)
      return
    }
    entry.stopped = true
    this._live.delete(taskId)
    // 只有真正提交过的任务结束才可能空出远端并发槽位
    if (remoteIdOf(task) !== '') this._kickQueued(asString(task.region) || 'cn')
    if (normalizeStatus(task.status) === STATUS.SUCCESS) {
      const results = task.results
      this._log('info', '任务完成 taskId=' + taskId + '，结果 ' + String(results.length) + ' 个')
      this._emit('task.done', { taskId, jobId: task.jobId, status: task.status, results, workflowName: task.workflowName })
      return
    }
    this._log('warn', '任务终态 ' + asString(task.status) + ' taskId=' + taskId + '：' + clip(asString(task.failedReason), 160))
    this._emit('task.failed', {
      taskId,
      jobId: task.jobId,
      status: task.status,
      failedReason: asString(task.failedReason),
      workflowName: task.workflowName,
    })
  }

  _deferSettlement(task) {
    this._live.set(task.taskId, { task, unsaved: { ...task }, settling: true, stopped: false })
    this._pollChain(task.taskId, this.pollIntervalMs)
  }

  /**
   * 下载全部输出，落到 `<dataDir>/outputs/<taskId>/`，并逐个调 `attach()`。
   *
   * **有总预算**（`downloadTimeoutMs`，默认 60s）：结果 URL 挂在慢 CDN 上时，
   * 不能让一次下载把终态写盘无限期拖住 —— 那会导致 `wait()` 明明任务已完成却一直超时。
   * 预算用尽后剩余条目照实记 `error`，然后**照常收口**（不是把整条任务判死）。
   * @param {object} task 任务
   * @returns {Promise<object[]>} `[{kind,url,filename,localPath,attachment?}]`
   */
  async _collect(task, { retry = false, resend = false } = {}) {
    const taskId = asString(task.taskId)
    if (task.output && this.store && typeof this.store.setTaskOutput === 'function') this.store.setTaskOutput(taskId, task.output)
    const kindHint = asString(task.outputKind) || 'image'
    const items = Array.isArray(task.outputs) ? task.outputs : []
    const results = []
    const deadline = this.nowMs() + Math.max(1000, toNumber(this.downloadTimeoutMs, DEFAULT_DOWNLOAD_MS))
    let index = 0
    for (const item of items) {
      index += 1
      const info = describeOutput(item, kindHint)
      const previous = retry ? task.results?.[index - 1] : null
      if (previous?.localPath) {
        const rec = { ...previous }
        if (resend || rec.attachmentError || !rec.attachment) {
          delete rec.attachment
          delete rec.attachmentError
          delete rec.attachmentErrorCode
          Object.assign(rec, await this._attachOne({ taskId, kind: rec.kind, filename: rec.filename, url: rec.url, path: rec.localPath }))
        }
        results.push(lossless(rec))
        continue
      }
      const textOut = item && typeof item === 'object' ? asString(item.text) : ''
      if (info.url === '') {
        // 官方 v2 schema：`results[].{url,outputType,text}` —— 文本类结果只有 `text` 没有 `url`。
        if (textOut !== '') {
          results.push(lossless({ kind: 'text', url: '', filename: info.filename, text: textOut }))
          continue
        }
        results.push(lossless({ kind: info.kind, url: '', filename: info.filename, error: '输出项里没有 URL，无法下载' }))
        continue
      }
      const left = deadline - this.nowMs()
      if (left <= 500) {
        // 预算用尽：**不再尝试**，但要留一条可读的结果（否则用户以为"任务成功却没结果"）
        results.push(lossless({ kind: info.kind, url: info.url, filename: info.filename, error: '下载超时预算已用尽，未下载；可从此 URL 手动下载。' }))
        continue
      }
      const dl = await this._downloadOne({ taskId, ...info, index, timeoutMs: Math.min(left, 120000) })
      const rec = { kind: info.kind, url: info.url, filename: info.filename }
      if (info.steganography) Object.assign(rec, { steganography: true, note: info.note })
      if (dl.ok) {
        rec.localPath = asString(dl.path)
        rec.bytes = toNumber(dl.bytes, 0)
        if (dl.attachment !== undefined && dl.attachment !== null) rec.attachment = lossless(dl.attachment)
        if (dl.attachmentError) {
          rec.attachmentError = dl.attachmentError
          rec.attachmentErrorCode = dl.attachmentErrorCode
        }
      } else {
        rec.error = asString(dl.error && dl.error.message) || '下载失败'
        rec.errorCode = asString(dl.error && dl.error.code)
      }
      results.push(lossless(rec))
    }
    return results
  }

  /**
   * 下载单个输出（先走注入的 `download`，否则流式写到 store 的临时文件）。
   * @param {{taskId:string,url:string,filename:string,kind:string,index:number,timeoutMs?:number}} spec 规格
   * @returns {Promise<{ok:boolean,path?:string,bytes?:number,attachment?:any,error?:object}>} 结果
   */
  async _downloadOne(spec) {
    try {
      if (this.download) {
        const r = await this.download(spec)
        if (r && r.ok === true) return { ok: true, path: asString(r.path), bytes: toNumber(r.bytes, 0), attachment: r.attachment, attachmentError: r.attachmentError, attachmentErrorCode: r.attachmentErrorCode }
        return { ok: false, error: (r && r.error) || errorShape('TASK_FAILED', '下载失败') }
      }
      const options = spec.timeoutMs ? { timeoutMs: spec.timeoutMs } : undefined
      let saved, bytes
      if (this.api.downloadTo) {
        saved = await this.store.writeOutput(spec.taskId, spec.filename, tmp => this.api.downloadTo(spec.url, tmp, options))
      } else {
        // 内存接口只保留给已有注入方和测试桩。
        const dl = await this.api.downloadBytes(spec.url, options)
        if (!dl.ok) return dl
        bytes = dl.bytes
        saved = await this.store.writeOutput(spec.taskId, spec.filename, bytes)
      }
      if (!saved.ok) return saved
      const attached = await this._attachOne({ ...spec, bytes, path: saved.path })
      return { ok: true, path: saved.path, bytes: saved.bytes, ...attached }
    } catch (e) {
      return { ok: false, error: errorShape('TASK_FAILED', '下载异常：' + String((e && e.message) || e)) }
    }
  }

  /** 附件失败单独记录；补发直接读已保存的文件。 */
  async _attachOne(spec) {
    if (!this.attach) return {}
    try {
      return await withMediaTransfer(async () => {
        const size = spec.bytes ? spec.bytes.byteLength : (await this.fs.stat(spec.path)).size
        if (size > MAX_ATTACHMENT_BYTES) return { attachmentError: '文件超过 64 MiB 附件上限，已保留本地文件', attachmentErrorCode: 'ATTACH_TOO_LARGE' }
        const bytes = spec.bytes || await this.fs.readFile(spec.path)
        const attachment = await this.attach({ ...spec, bytes })
        if (!attachment) return { attachmentError: '宿主没有返回附件', attachmentErrorCode: 'ATTACH_FAILED' }
        return { attachment }
      })
    } catch (e) {
      return { attachmentError: String(e.message || e), attachmentErrorCode: asString(e.code) || 'ATTACH_FAILED' }
    }
  }

  /**
   * 收口一个任务并写状态。
   * @param {string} taskId 任务 id
   * @param {object} patch 要合并进流水的字段
   * @returns {Promise<void>}
   */
  async _finish(taskId, patch) {
    const entry = this._live.get(taskId)
    const task = (await this.get(taskId)) || (entry && entry.task) || { taskId }
    Object.assign(task, patch, { taskId, finishedAt: this.nowMs() })
    await this._settle(taskId, task)
  }

  /* ────────────────────────────── 对外查询 ────────────────────────────── */

  /** 同一任务的等待者共用下一次磁盘读取；较短的截止时间不被其它等待拖长。 */
  _waitRead(id, delay = 0) {
    const at = this.nowMs() + delay
    const current = this._waitReads.get(id)
    if (current && current.at <= at) return current.promise
    const entry = { at, promise: null }
    entry.promise = (async () => {
      if (delay > 0) await this._sleep(delay)
      return this.get(id)
    })().finally(() => {
      if (this._waitReads.get(id) === entry) this._waitReads.delete(id)
    })
    this._waitReads.set(id, entry)
    return entry.promise
  }

  /**
   * 等到终态（**不取消任务**）。超时返回当前投影 + `timedOut:true`。
   * @param {string} taskId 任务 id
   * @param {number} [timeoutMs] 本次等待上限（默认 60s，硬上限 `maxWaitMs`）
   * @returns {Promise<{ok:true,task:object,results:object[],timedOut:boolean}|{ok:false,error:object,task?:object}>} 结果
   */
  async wait(taskId, timeoutMs) {
    const id = asString(taskId)
    if (id === '') return { ok: false, error: errorShape('BAD_REQUEST', 'wait 需要 taskId') }
    const release = this.store?.retainTasks?.([id])
    try {
      let task = await this._waitRead(id)
      if (!task) return { ok: false, error: errorShape('TASK_NOT_FOUND', '本地没有这个任务的流水：' + id, { hint: '用 task.list 看本地任务' }) }

      const budget = Math.min(Math.max(1000, toNumber(timeoutMs, DEFAULT_WAIT_MS)), this.maxWaitMs)
      const deadline = this.nowMs() + budget
      while (!FINAL_STATUSES.includes(normalizeStatus(task.status))) {
        const left = deadline - this.nowMs()
        if (left <= 0) {
          return { ok: true, task: projectTask(task), results: Array.isArray(task.results) ? task.results : [], timedOut: true }
        }
        const fresh = await this._waitRead(id, Math.min(1000, Math.max(50, left)))
        if (!fresh) return { ok: false, error: errorShape('TASK_NOT_FOUND', '任务记录已不存在：' + id) }
        task = fresh
      }
      const status = normalizeStatus(task.status)
      if (task.persisted === false) return { ok: false, task: projectTask(task), results: task.results, error: errorShape('STORE_WRITE_FAILED', '云端任务已结束，本地记录尚未保存；插件会继续补存，请勿重新提交。') }
      if (status === STATUS.SUCCESS) {
        return { ok: true, task: projectTask(task), results: Array.isArray(task.results) ? task.results : [], timedOut: false }
      }
      return {
        ok: false,
        task: projectTask(task),
        error: errorShape(
          status === STATUS.UNCERTAIN ? 'TRANSPORT_UNCERTAIN' : 'TASK_FAILED',
          asString(task.failedReason) || asString(task.errorMessage) || ('任务终态：' + status),
          { hint: asString(task.hint), status },
        ),
      }
    } finally {
      await release?.()
    }
  }

  /** 补失败下载和附件；resend 时从本地重新生成附件，绝不重新提交工作流。 */
  async retryResults(taskId, { resend = false } = {}) {
    const id = asString(taskId)
    const release = this.store?.retainTasks?.([id])
    try {
      return await this._withTaskLock(id, async () => {
        const task = await this.get(id)
        if (!task) return { ok: false, error: errorShape('TASK_NOT_FOUND', '本地没有这个任务的流水：' + id) }
        if (normalizeStatus(task.status) !== STATUS.SUCCESS) return { ok: false, task: projectTask(task), error: errorShape('TASK_NOT_SUCCESS', '任务尚未生成成功，请先用 task.status 查询') }
        task.results = await this._collect(task, { retry: true, resend })
        if (!await this._save(task)) return { ok: false, task: projectTask(task), results: task.results, error: errorShape('STORE_WRITE_FAILED', '结果已处理，但任务记录保存失败') }
        return { ok: true, task: projectTask(task), results: task.results, timedOut: false }
      })
    } finally {
      await release?.()
    }
  }

  /**
   * 查任务（本地流水；可选向 RH 侧单查一次）。
   * @param {string} taskId 任务 id
   * @param {{refresh?:boolean}} [opts] `refresh:true` 时顺带查一次远端
   * @returns {Promise<{ok:true,task:object}|{ok:false,error:object}>} 结果
   */
  async status(taskId, opts = {}) {
    const id = asString(taskId)
    if (opts.refresh === true) return this._withTaskLock(id, () => this._refreshStatus(id))
    const task = await this.get(id)
    if (!task) return { ok: false, error: errorShape('TASK_NOT_FOUND', '本地没有这个任务的流水：' + id) }
    return { ok: true, task: projectTask(task) }
  }

  async _refreshStatus(id) {
    const task = await this.get(id)
    if (!task) return { ok: false, error: errorShape('TASK_NOT_FOUND', '本地没有这个任务的流水：' + id) }
    // 本地排队中：远端还没有这个任务，没什么可查的
    if (normalizeStatus(task.status) === STATUS.LOCAL_QUEUED) return { ok: true, task: projectTask(task) }
    const recoverable = normalizeStatus(task.status) === STATUS.ERROR && ['TIMEOUT', 'NO_KEY', 'POLL_CRASH'].includes(task.errorCode) && remoteIdOf(task) !== ''
    if (isTerminal(task.status) && !recoverable) return { ok: true, task: projectTask(task) }
    const key = this._queryKeyFor(task)
    if (!key) return { ok: false, task: projectTask(task), error: errorShape('NO_KEY', '该任务所属地域没有可用 Key') }
    const q = await this._queryOnce(key, asString(task.region) || 'cn', remoteIdOf(task) || id)
    this._applyQuery(task, q)
    if (!q || !q.ok || !normalizeStatus(q.status)) {
      await this._save(task)
      return { ok: false, task: projectTask(task), error: errorShape(asString(q && q.code) || 'QUERY_FAILED', asString(q && q.message) || '查询没有返回任务状态') }
    }
    if (recoverable) {
      task.errorCode = ''
      task.errorMessage = ''
      task.hint = ''
      task.finishedAt = 0
      task.trackingStartedAt = this.nowMs()
    }
    if (isTerminal(task.status)) await this._settle(id, task)
    else {
      const entry = this._live.get(id)
      if (entry) entry.task = task
      await this._save(task)
      this._startPolling(task)
    }
    return { ok: true, task: projectTask((await this.get(id)) || task) }
  }

  /**
   * 取消任务（RH 侧 + 本地状态）。
   * @param {string} taskId 任务 id
   * @returns {Promise<{ok:true,task:object}|{ok:false,error:object}>} 结果
   */
  async cancel(taskId) {
    return this._withTaskLock(asString(taskId), () => this._cancelNow(taskId))
  }

  async _cancelNow(taskId) {
    const id = asString(taskId)
    const task = await this.get(id)
    if (!task) return { ok: false, error: errorShape('TASK_NOT_FOUND', '本地没有这个任务的流水：' + id) }

    // 本地排队中：RH 侧还没有这个任务，只需停掉本地重投
    if (normalizeStatus(task.status) === STATUS.LOCAL_QUEUED) {
      const entry = this._live.get(id)
      if (entry) entry.stopped = true
      this._live.delete(id)
      task.status = STATUS.CANCEL
      task.failedReason = '用户取消（尚未提交到 RunningHub，没有扣费）'
      task.localQueue.nextAt = 0
      await this._settle(id, task)
      return { ok: true, task: projectTask((await this.get(id)) || task) }
    }

    // ── 已经结束的任务：**不是失败**，别让用户看到一个红色业务错误 ──
    //
    // 血泪：用户在面板上对一个已完成的任务点了「取消」，RunningHub 直接回业务错误，
    // 面板就渲染成一条红色报错（真机 `clientCalls.lastError = tasksCancel:BUSINESS`）。
    // 取消一个跑完的任务本来就是无意义操作，正确回应是"它已经结束了"，不是"取消失败"。
    if (isTerminal(task.status)) {
      return {
        ok: true,
        alreadyFinished: true,
        status: normalizeStatus(task.status),
        task: projectTask(task),
      }
    }

    const key = this._keyFor(task)
    if (key === '') {
      return { ok: false, error: errorShape('NO_KEY', 'region=' + asString(task.region) + ' 没有可用 key，无法取消') }
    }
    const r = await this.api.cancelTask(key, asString(task.region) || 'cn', remoteIdOf(task) || id)
    if (!r || r.ok !== true) {
      // 本地流水可能落后于远端：远端其实已经跑完了，我们却还在拿旧状态去取消。
      // 这时**再查一次** —— 若确实已终态，就当"它已经结束了"处理，而不是把
      // 一个对用户毫无意义的业务错误码原样抛上去。
      const fresh = await this._refreshStatus(id).catch(() => null)
      const freshStatus = fresh && fresh.ok !== false ? normalizeStatus((fresh.task && fresh.task.status) || '') : ''
      if (freshStatus !== '' && isTerminal(freshStatus)) {
        return { ok: true, alreadyFinished: true, status: freshStatus, task: (fresh && fresh.task) || projectTask(task) }
      }
      return { ok: false, error: (r && r.error) || errorShape('BUSINESS', '取消失败') }
    }
    task.status = STATUS.CANCEL
    task.failedReason = '用户取消'
    await this._settle(id, task)
    return { ok: true, task: projectTask((await this.get(id)) || task) }
  }

  /* ────────────────────── UNCERTAIN 闭环：接回 / 结案 ────────────────────── */

  /**
   * 把一条 `UNCERTAIN`（待核对）记录**接回**到 RunningHub 上真实存在的任务。
   *
   * 先用本地域的 key 查一次 `remoteTaskId`：查不到（不存在 / 跨地域 / 网络失败）就报错，
   * **原记录一字不改**；查到了才把它改写成正常任务——已到终态就直接收口下载结果，
   * 还在跑就接上轮询。
   * @param {string} localTaskId 本地记录 id（通常是 `uncertain-*`）
   * @param {string} remoteTaskId 用户在 RH 后台找到的远端 taskId
   * @returns {Promise<{ok:true,task:object}|{ok:false,error:object,task?:object}>} 结果
   */
  async adopt(localTaskId, remoteTaskId) {
    const id = asString(localTaskId).trim()
    const remote = asString(remoteTaskId).trim()
    if (id === '') return { ok: false, error: errorShape('BAD_REQUEST', 'adopt 需要 taskId（本地待核对记录）') }
    if (!/^[A-Za-z0-9_-]{1,64}$/.test(remote) || /^(?:uncertain|queued)-/.test(remote)) {
      return { ok: false, error: errorShape('BAD_REQUEST', '远端 taskId 格式不对：' + clip(remote, 80), { hint: '填 RunningHub 后台任务详情里的任务 ID（一串数字）' }) }
    }
    // 远端 id 也加锁：两条不同的待核对记录并发接回同一个远端任务时，查重 + 写入必须串行
    return this._withTaskLock('remote:' + remote, () => this._withTaskLock(id, async () => {
      const task = await this.get(id)
      if (!task) return { ok: false, error: errorShape('TASK_NOT_FOUND', '本地没有这个任务的流水：' + id) }
      if (normalizeStatus(task.status) !== STATUS.UNCERTAIN) {
        return { ok: false, task: projectTask(task), error: errorShape('TASK_NOT_UNCERTAIN', '只有「待核对」的任务可以接回（当前 ' + normalizeStatus(task.status) + '）') }
      }
      const dup = (await this.list()).find((t) => t.taskId !== id && (t.taskId === remote || t.remoteTaskId === remote))
      if (dup) {
        return { ok: false, task: projectTask(task), error: errorShape('TASK_ALREADY_TRACKED', '这个远端任务已经由本地记录 ' + asString(dup.taskId) + ' 跟踪', { hint: '同一个远端任务只能对应一条本地记录' }) }
      }
      const region = asString(task.region) || 'cn'
      const probe = { ...task }
      const key = this._queryKeyFor(probe)
      if (key === '') return { ok: false, task: projectTask(task), error: errorShape('NO_KEY', 'region=' + region + ' 没有可用 key，无法核对远端任务') }
      const q = await this._queryOnce(key, region, remote)
      if (!q || q.ok !== true || normalizeStatus(q.status) === '') {
        return {
          ok: false,
          task: projectTask(task),
          error: errorShape(asString(q && q.code) || 'ADOPT_QUERY_FAILED', '在 region=' + region + ' 查不到远端任务 ' + remote + (q && q.message ? '：' + clip(asString(q.message), 160) : ''), {
            hint: '确认 taskId 抄写无误，且属于该地域（国内 / 海外）的账号；原记录未改动',
          }),
        }
      }
      const at = this.nowMs()
      Object.assign(task, probe, {
        remoteTaskId: remote,
        uncertain: false,
        adoptedAt: at,
        errorCode: '',
        errorMessage: '',
        failedReason: '',
        hint: '',
        finishedAt: 0,
        trackingStartedAt: at,
        pollCount: 0,
        queryFailures: 0,
      })
      this._applyQuery(task, q)
      const stale = this._live.get(id)
      if (stale) {
        stale.stopped = true
        this._live.delete(id)
      }
      this._log('info', '已接回待核对任务 ' + id + ' → ' + remote + '（' + task.status + '）')
      this._emit('task.adopted', { taskId: id, remoteTaskId: remote, status: task.status })
      if (FINAL_STATUSES.includes(normalizeStatus(task.status))) await this._settle(id, task)
      else {
        await this._save(task)
        this._startPolling(task)
      }
      return { ok: true, task: projectTask((await this.get(id)) || task) }
    }))
  }

  /**
   * 用户在 RH 后台确认**没有**创建这个任务 → 把 `UNCERTAIN` 记录手动结案（记为 `CANCEL`），
   * 不再占用「待核对」的保留名额。
   * @param {string} localTaskId 本地记录 id
   * @param {{reason?:string}} [opts] 备注
   * @returns {Promise<{ok:true,task:object}|{ok:false,error:object,task?:object}>} 结果
   */
  async dismiss(localTaskId, opts = {}) {
    const id = asString(localTaskId).trim()
    if (id === '') return { ok: false, error: errorShape('BAD_REQUEST', 'dismiss 需要 taskId') }
    return this._withTaskLock(id, async () => {
      const task = await this.get(id)
      if (!task) return { ok: false, error: errorShape('TASK_NOT_FOUND', '本地没有这个任务的流水：' + id) }
      if (normalizeStatus(task.status) !== STATUS.UNCERTAIN) {
        return { ok: false, task: projectTask(task), error: errorShape('TASK_NOT_UNCERTAIN', '只有「待核对」的任务可以结案（当前 ' + normalizeStatus(task.status) + '）') }
      }
      const reason = clip(asString(opts && opts.reason).trim(), 200)
      const at = this.nowMs()
      Object.assign(task, {
        status: STATUS.CANCEL,
        uncertain: false,
        dismissedAt: at,
        finishedAt: at,
        failedReason: '已确认 RunningHub 上没有创建这个任务，手动结案' + (reason ? '：' + reason : ''),
        hint: '',
      })
      const stale = this._live.get(id)
      if (stale) {
        stale.stopped = true
        this._live.delete(id)
      }
      if (!await this._save(task)) return { ok: false, task: projectTask(task), error: errorShape('STORE_WRITE_FAILED', '结案记录保存失败') }
      this._emit('task.dismissed', { taskId: id })
      return { ok: true, task: projectTask(task) }
    })
  }

  /**
   * 插件启动时恢复未完成任务的轮询（**幂等**：终态任务不会被重新捡起来）。
   * @returns {Promise<{ok:true,resumed:string[],scanned:number}>} 结果
   */
  async resume() {
    if (!this.store || typeof this.store.listTasks !== 'function') return { ok: true, resumed: [], scanned: 0 }
    const tasks = await this.store.listTasks()
    const resumed = []
    for (const t of tasks) {
      if (!t || typeof t !== 'object') continue
      const st = normalizeStatus(t.status)
      if (FINAL_STATUSES.includes(st)) continue
      if (asString(t.taskId) === '') continue
      if (st === STATUS.LOCAL_QUEUED && t.localQueue.inflightAt) {
        this._log('warn', '本地排队任务 ' + t.taskId + ' 上次重投请求未确认结果，转为待核对')
        await this._save({ ...t, status: STATUS.UNCERTAIN, uncertain: true, errorCode: 'TRANSPORT_UNCERTAIN', hint: QUEUED_UNCERTAIN_HINT, localQueue: { ...t.localQueue, nextAt: 0 } })
        // 热重载时旧 runner 的请求可能还在路上，返回后会把记录改回 QUEUED / LOCAL_QUEUED；等它肯定结束后复读一次接管
        const id = t.taskId
        void this._sleep(this.api.submitTimeoutMs + 5000).then(() => this._withTaskLock(id, async () => {
          const cur = await this.get(id)
          if (cur && !FINAL_STATUSES.includes(normalizeStatus(cur.status)) && !cur.localQueue?.inflightAt) this._startPolling(cur)
        }))
        continue
      }
      this._startPolling(t)
      resumed.push(asString(t.taskId))
    }
    if (resumed.length > 0) this._log('info', '恢复 ' + String(resumed.length) + ' 个未完成任务的轮询')
    return { ok: true, resumed, scanned: tasks.length }
  }

  /** 正在轮询的任务 id 列表。 @returns {string[]} id 数组 */
  liveTaskIds() {
    return Array.from(this._live.keys())
  }

  /** 停掉内部轮询定时器（dispose 时调）。 @returns {void} */
  stop() {
    this._stopped = true
    for (const [, entry] of this._live) entry.stopped = true
    this._live.clear()
  }
}

/**
 * 便捷工厂。
 * @param {object} deps 同 `TaskRunner` 构造器
 * @returns {TaskRunner} 实例
 */
export function createRunner(deps) {
  return new TaskRunner(deps)
}
