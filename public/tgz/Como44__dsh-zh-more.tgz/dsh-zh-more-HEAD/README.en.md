# dsh-zh-more — Chinese enhancement for DeepSeek Harness

> Translates the English that the official DSH Chinese UI can't reach:
> **slash-command names** and the **Settings → Plugins inventory cards** — with three display modes.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![dsh-plugin](https://img.shields.io/badge/dsh-plugin-4d7fff)](https://github.com/topics/dsh-plugin)

## What it fixes

The official DSH Chinese UI localizes most copy, but two places stay English:

1. **Slash-command menu** — command names are machine identifiers (`/compact`, `/goal` …) and are never translated;
2. **Settings → Plugins → Plugin list** — every card shows only the English module name (`session`, `sandbox-policy` …) with no hint of what it does.

This plugin makes both Chinese-first without losing the English information.

## Three display modes

Pick one in **Settings → Translation** (choice is remembered, applies instantly):

| Mode | Command menu | Plugin list |
|---|---|---|
| **Chinese only** (default) | `压缩对话`, description line prefixed with `/compact · 压缩较早的对话历史` | `会话核心` + one-line purpose |
| **Chinese + English** | `压缩对话 /compact` | `定时器服务` + `Cordis 定时任务调度 · timer` |
| **No translation** | `compact` (original) | `timer` (original, no description) |

- Active only when the UI language is Chinese; switching back to English restores everything — no functionality is affected.
- Command names are translated **for display only**; execution still uses the English token (`/compact` works as usual).
- Expanding a plugin card still shows the full English package name; English search still works.

## Plugin list: category tabs + source badges

At the top of **Settings → Plugins → Plugin list**, a **category tab bar** is added. Categories are organized the way a non-expert thinks — "what is it for" — and one click filters the cards:

| Tab | What it contains |
|---|---|
| **All** | every plugin |
| **System** | DSH core: sessions, storage, agents, jobs, networking, scheduling |
| **Interface** | UI display & interaction (chat, settings, sidebar, theme, language) |
| **Models** | LLM providers, default model, model selection |
| **Tools** | what the agent can use: files, commands, web, skills, subagents, workflows |
| **Security** | sandbox, approvals, permissions, credentials |
| **Enhancements** | Chinese UI, cost tracking, remote access, TTS and other extras |

Each card also gets a **source badge** on its top-right corner:

- **Official** (blue): DeepSeek Harness components (`@deepseek-ai/*`)
- **Self-made** (green): plugins you wrote yourself (defaults: this plugin and dsh-image-inline — edit the `SELF_MADE` set)
- **Third-party** (orange): community plugins

> Tabs and badges are independent of the translation mode: category filtering and source badges stay available even in "No translation" mode. Adjust `SELF_MADE` and `CATEGORY_OVERRIDE` at the top of `lib/client.js` to fit your own setup.

## Install

```sh
# From GitHub (no build step — plain ESM)
dsh plugin --profile web add github:Como44/dsh-zh-more
```

Also installable in one click from DSH plugin marketplaces (dsh-market / awesome-dsh-plugin directory).

> Restart `dsh web` once after installing, then hard-refresh the browser (Ctrl+Shift+R).

## Usage

1. Settings → Language → 中文 (Chinese);
2. Settings → Translation → choose a mode;
3. Press `/` in the composer to see the command menu; open Settings → Plugins → Plugin list to see the cards.

## Customizing the dictionaries

All translations live in two tables at the top of `lib/client.js` — edit and refresh the page:

- `COMMAND_NAMES`: command name → Chinese name;
- `PLUGIN_INFO`: full package name → `[Chinese name, one-line purpose]`.

## How it works

A pure **browser-side** plugin (plus a no-op host half so the loader row mounts). A MutationObserver rewrites, on the Chinese UI:

- the command-name text and description prefix of menu rows;
- the plugin-card title and a wrapping one-line description (two-row card layout).

Original text is kept in the `data-dsh-zh-more-orig` attribute and restored fully when the UI switches to English or the mode is off. No network calls; it never touches credentials or session data.

## Compatibility

- Targets DSH `0.1.0-rc.6` Web profile (current official release);
- Works alongside [deepseek-harness-zh_pro](https://github.com/magian1127/deepseek-harness-zh_pro) without conflicts. The "No translation" mode disables only this plugin; zh_pro's own completion can be toggled off separately in its "增强设置".

## Uninstall

```sh
dsh plugin --profile web remove dsh-zh-more
```

## License

[MIT](LICENSE) © 2026 Como44
