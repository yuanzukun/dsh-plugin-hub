/**
 * 客户端形状冒烟：lib/client.js 必须是 window.__ModuleLoader__.load factory 形态，
 * 并满足输入触发源契约（分组名 / order / onPick 文本）与设置卡片槽位契约。
 * 运行：node test/client-shape-smoke.mjs
 */
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { join } from "node:path";

const here = fileURLToPath(new URL(".", import.meta.url));
const code = readFileSync(join(here, "..", "lib", "client.js"), "utf8");

assert.ok(code.startsWith("window.__ModuleLoader__.load("), "ModuleLoader factory 形态");
assert.ok(code.includes('id: "dsh-v-skill-links"'), "插件 id");
assert.ok(code.includes('name: "映射技能"'), "分组标题（词典未登记键原样展示）");
assert.ok(code.includes("trigger: \"/\""), "绑定 / 触发");
assert.ok(code.includes("order: -1"), "映射技能分组置顶（命令=默认 0 之前）");
assert.ok(code.includes('name: "自定义指令"') && code.includes("order: -0.5"), "自定义指令分组紧跟其后");
assert.ok(code.includes("registerSource(source)") && code.includes("registerSource(commandSource)"), "注册两个触发源");
/* 静态清单收窄（change add-dual-host-seam-compat）：只留两类宿主都提供的服务；设置服务是版本
   特有的（0.1.5 settingsScope / 0.2.0 configForms），放进静态 inject 会让缺失侧 entry 永久
   pending（桌面端 fail-fast boot 直接整体启动失败）。 */
const injectLiteral = /const inject = (\[[^\]]*\]);/.exec(code);
assert.ok(injectLiteral, "静态 inject 清单存在");
const injectList = JSON.parse(injectLiteral[1]);
assert.deepEqual(injectList, ["inputTriggers", "slots", "locale"], "静态清单 = 两代宿主（0.1.5 / 0.2.0）交集");
assert.ok(!injectList.includes("settingsScope") && !injectList.includes("configForms"), "版本特有设置服务 MUST NOT 进静态清单");
assert.ok(code.includes("exports.inject = inject"), "exports.inject = inject 挂载契约保持不变（loader 实际读取位置）");
assert.ok(code.includes('ctx.inject(["settingsScope"]') && code.includes('ctx.inject(["configForms"]'),
	"设置读写经运行时双通道子注入（服务缺失只让该子任务 pending，不阻塞本体）");
assert.ok(code.includes('const CONFIG_FORMS_ENTRY = "dsh-v-skill-links"'), "configForms 取键 = profile 条目 id");
assert.ok(code.includes('fetch(API + "/list"'), "候选来自宿主 API");
assert.ok(code.includes("matchByName(data.skills, query)") && code.includes("matchByName(data.commands ?? [], query)"), "两个分组都用子串匹配");
assert.ok(code.includes("includes(q)") && code.includes("startsWith(q) ? 0 : 1"), "子串命中 + 前缀优先排序");
assert.ok(code.includes("return { text: `/${candidate.name} ` }"), "技能选中落 /name 字面文本");
assert.ok(code.includes('return "handled"') && code.includes("runCommand(session.sessionId, candidate.name)"), "自定义指令选中即执行");
assert.ok(code.includes('fetch(API + "/run"'), "执行走宿主 /run（followup）");
/* 设置节「技能管理」（settings.section + 节内标签页；旧插件配置卡片已移除） */
assert.ok(code.includes('"settings.section"'), "注册设置左栏第一层节");
assert.ok(code.includes('const SECTION_ID = "v-skills"') && code.includes("id: SECTION_ID"), "节 id v-skills");
assert.ok(code.includes('const SECTION_TAB_SLOT = "settings.v-skills.tab"') && code.includes("renderSlot(SECTION_TAB_SLOT, {}, { only: active })"), "节内标签页槽 + only 渲染");
assert.ok(code.includes("resolveSlotLabel"), "标签经官方 resolveSlotLabel 解析");
assert.ok(code.includes("SkillManagerSection") && code.includes("MappingPanel") && code.includes("CommandsPanel") && code.includes("QuickPanel"), "节组件 + 三个面板组件");
assert.ok(code.includes("installSectionCss") && code.includes("v-sm-section") && code.includes("v-sm-tab"), "节自有稳定 class（v-sm-*）");
assert.ok(!code.includes('"settings.plugin.item"'), "settings.plugin.item 旧卡片已移除");
assert.ok(code.includes('bind({'), "绑定设置作用域（settingsScope 通道原样透传）");
assert.ok(code.includes('scope.set("directories"') && code.includes('scope.set("commands"') && code.includes('scope.set("buttons"'), "保存写 directories / commands / buttons 节");
assert.ok(code.includes('scope.unset("directories"') && code.includes('scope.unset("commands"') && code.includes('scope.unset("buttons"'), "重置清对应覆盖");
assert.ok(code.includes("createSnapshotStore"), "快照存储驱动节状态");
/* 双代 seam 归一 + 降级底座（change add-dual-host-seam-compat）：归一目标就是控制器/store 已
   消费的 { getSnapshot, subscribe, set, unset }；两通道皆缺时合成只读 scope（面板 notWritable）。 */
assert.ok(code.includes("function createActiveScope()") && code.includes("function createReadOnlyScope()")
	&& code.includes("function adaptConfigFormsChannel(sctx)") && code.includes("function bindSettingsScopeChannel(sctx)"),
	"活动作用域层 + 只读底座 + 两通道适配齐备");
assert.ok(code.includes("writable: false"), "降级快照呈 writable:false（面板走 notWritable 词典）");
assert.ok(code.includes("exports.createActiveScope = createActiveScope") && code.includes("exports.adaptConfigFormsChannel = adaptConfigFormsChannel"),
	"seam 内部面导出（smoke 直测 attach 所有权与通道归一）");
/* 共享配置存储 API 通道 + 待命位（change shared-config-store）：第三通道为读写首选，apply 内
   同步 attach（seam 子注入回调异步 ⇒ 先到者持有语义下必然赢）；首取失败经句柄自拆，待命 seam 晋升。 */
assert.ok(code.includes('const CONFIG_POLL_MS = 5000'), "订阅期 5s revision 轮询间隔");
assert.ok(code.includes('API + "/config"'), "API 通道打 /api/v-skill-links/config");
assert.ok(code.includes("function createApiChannel(options = {})") && code.includes("exports.createApiChannel = createApiChannel"),
	"API 通道适配器存在并导出（冒烟直测）");
assert.ok(code.includes("let standby = null;") && code.includes("const promoted = standby;"),
	"活动作用域提供待命位：活动连接拆卸时自动晋升待命者（fallback 与 seam 解析时序无关）");
assert.ok(code.includes("standby = next;") && code.includes("if (standby !== null) return null;"),
	"首个后来者静默登记待命（不订阅、无日志），第二个及以后仍忽略");
assert.ok(code.includes("retire()"), "首取失败经 attach 句柄自拆并停止轮询（静默退场）");
/* 挂载顺序契约（源码级）：API 通道 attach 必须先于两条 seam 子注入 */
const apiAttachAt = code.indexOf("apiChannel.bind(activeScope.attach(apiChannel));");
const seamInjectAt = code.indexOf('ctx.inject(["settingsScope"]');
const formsInjectAt = code.indexOf('ctx.inject(["configForms"]');
assert.ok(apiAttachAt > 0, "apply 内同步 attach API 通道");
assert.ok(apiAttachAt < seamInjectAt && apiAttachAt < formsInjectAt,
	"API 通道 attach 先于两个 seam 子注入（apply 内同步 ⇒ 恒先到，seam 只能登记待命）");
/* 快捷按钮网格（conversation.composer.dock） */
assert.ok(code.includes('"conversation.composer.dock"'), "注册输入卡片下方 dock 槽");
assert.ok(code.includes('const DOCK_ID = "v-quick-buttons"') && code.includes("id: DOCK_ID"), "dock 条目 id（与官方 stats 行并肩）");
assert.ok(code.includes("order: -1"), "dock 紧贴输入卡片（stats=0 在其下）");
assert.ok(code.includes("QuickButtonsGrid") && code.includes("createButtonsStore") && code.includes("appendPrompt"), "dock 组件 / 快照 store / 追加语义齐备");
/* 前插方向（add-quick-button-prepend，design D2/D3/D4）：对称纯函数 + 方向实参 + 行内勾选框 + 条件键 */
assert.ok(code.includes("function prependPrompt(draft, prompt)") && code.includes("exports.prependPrompt = prependPrompt"),
	"前插纯函数存在并导出（appendPrompt 既有导出保留，MUST NOT 被替换）");
assert.ok(code.includes("exports.appendPrompt = appendPrompt"), "appendPrompt 导出保持不破（既有冒烟依赖）");
assert.ok(code.includes("button.prepend === true ? prependPrompt(draft, button.prompt) : appendPrompt(draft, button.prompt)"),
	"activate 仅按 prepend 选 setDraft 实参（其余时序不动）");
assert.ok(code.includes('field === "prepend"') && code.includes("buttonEntry({ ...b, prepend: value })"),
	"editButton 对 prepend 走条件键特判（取消勾选删键，对齐 model 字段断言模式）");
assert.ok(code.includes("if (b.prepend === true) entry.prepend = true") && code.includes("if (source.prepend === true) entry.prepend = true"),
	"buttonEntry / save 条件写出 prepend（未勾选 MUST NOT 输出该键）");
assert.ok(code.includes('"prependLabel"') && code.includes("prependTitle"), "词典含前插键（勾选框文案与组合语义 title）");
assert.ok(code.includes('editButton(index, "prepend", event.target.checked)'), "行内勾选框提交 field=prepend（暂存-保存模型）");
assert.ok(code.includes("inputActions.setDraft(") && code.includes("inputActions.submit()"), "点击走 InputActions 正门（追加 / 等同回车）");
assert.ok(code.includes("installDockCss") && code.includes("v-qb-grid") && code.includes("v-qb-btn") && code.includes("v-qb-label"), "dock 自有稳定 class（用户美化钩子）");
assert.ok(code.includes('"data-v-button"'), "按钮带 data-v-button 属性");
assert.ok(code.includes('require("@deepseek-ai/dsh-client-ui-primitives")'), "按钮底子 require 官方 primitives（design D6）");
/* hero 条目（conversation.input.dock：新增会话首屏，design D10；0.1.2-rc.1 起
   composer.dock 渲染点只在会话态（variant === "composer"）、input.dock 只看 zone 存在） */
assert.ok(code.includes('const DOCK_HERO_ID = "v-quick-buttons-hero"') && code.includes("id: DOCK_HERO_ID"), "hero 条目 id");
assert.ok(code.includes('"conversation.input.dock"'), "hero 条目注册输入区 dock 槽");
assert.ok(code.includes('session.openState === "open"') && code.includes("session.blank === true")
	&& code.includes("session.running !== true") && code.includes("session.promptAttempted !== true")
	&& code.includes("hero: true"), "hero 门控读 SessionSnapshot 原始字段（非 blank 首屏返回 null）");
assert.ok(code.includes("v-qb-grid--hero"), "hero 修饰类（CSS order 置于 hero 卡片下方）");
/* 对齐锚点 C（design D1 补充）：网格自我约束文本宽度列 + 按钮左聚拢 */
assert.ok(code.includes("minmax(96px,max-content)"), "网格列 max-content（按钮随内容收缩、自左聚拢）");
assert.ok(code.includes("max-width:var(--dsh-chat-content-width)"), "网格自我约束为输入文本宽度列（左缘=文本左缘）");
assert.ok(code.includes("max-width:220px"), "单钮 220px 封顶截断");
/* 快捷按钮排序（add-quick-buttons-reorder）：把手 / 指示线 / 上移下移 / 纯函数与动作 */
assert.ok(code.includes("v-sc-grip") && code.includes("v-sc-dropLine") && code.includes("v-sc-move"), "排序控件自有稳定 class（把手 / 指示线 / 上下移）");
assert.ok(code.includes("draggable: canReorder"), "draggable 仅置于把手（整行不可拖）");
assert.ok(code.includes("onDragStart") && code.includes("onDragOver") && code.includes("onDrop") && code.includes("onDragEnd"), "HTML5 DnD 事件胶水齐备（指示线 + 松手落下）");
assert.ok(code.includes("exports.moveButton = moveButton"), "排序纯函数导出（smoke 直测）");
assert.ok(code.includes("face.moveButton("), "面板经 face.moveButton 提交换位（暂存-保存模型）");
assert.ok(code.includes('"gripLabel"') && code.includes('"moveUp"') && code.includes('"moveDown"'), "词典含排序键（把手 aria-label / 上下移 title）");
assert.ok(code.includes("--dsw-alias-border-inverted)"), "排序控件配色走官方 token（明暗主题跟随）");
/* 模型绑定（add-quick-button-model）：可选注入（remote.session 声明进列表，cordis 独立服务键门）+ 官方 client remote + 显式判信封 + 先切后发 */
assert.ok(code.includes('ctx.inject(["remote", "remote.session", "sessions"]'), "模型目录走单处可选注入，remote.session 声明在列表（cordis 独立服务键，不声明读取即抛错）");
assert.ok(code.includes(".modelCatalog()") && code.includes(".selectModel("), "目录与切换都走官方 client remote（与会话模型菜单同源）");
assert.ok(code.includes("response.ok !== true"), "显式判结果信封 ok（失败不抛异常，MUST NOT 只包 try/catch）");
assert.ok(code.includes("llm/adapters-updated") && code.includes("settings/document-updated") && code.includes("credentials/reference-updated"), "目录刷新订阅官方同款三个事件");
assert.ok(code.includes('scope.on("connection/reset"'), "连接重置清旧值");
assert.ok(code.includes("exports.highestEffort = highestEffort") && code.includes("exports.modelKeyOf = modelKeyOf")
	&& code.includes("exports.catalogOptions = catalogOptions") && code.includes("exports.createModelBridge = createModelBridge"),
	"模型绑定纯函数与目录桥导出（smoke 直测）");
assert.ok(code.includes('field === "model"') && code.includes("buttonEntry({ ...b, model: value })"), "editButton 支持 model 字段（未绑定删键）");
assert.ok(code.includes("canSwitch: canSwitchSession(sessionId)") && code.includes("switchModel: switchSessionModel"),
	"两处 dock inject 收 sessionId 并给出可切换判据与切换函数");
assert.ok(code.includes("busyRef"), "in-flight 保护（切换/提交序列进行中忽略连点）");
assert.ok(code.includes("v-sc-modelRow") && code.includes("v-sc-select") && code.includes("v-sc-modelHint"), "模型/级别下拉自有稳定 class");
assert.ok(code.includes('const DOCK_CSS') && code.includes("v-qb-grid"), "dock 样式与模型绑定同文件共存（零新增依赖）");
assert.ok(!/require\("(?!react"|@deepseek-ai\/dsh-client-store"|@deepseek-ai\/dsh-client-ui-primitives"|@deepseek-ai\/dsh-client-ui-slots")/.test(code), "require 仅限 react / client-store / primitives / slots（均静态种子词）");
/* 模块声明：store / primitives / slots 均为 shell 静态种子词，dsh.client 只留 platform（fix-dsh-012-compat design D2） */
const pkg = JSON.parse(readFileSync(join(here, "..", "package.json"), "utf8"));
assert.ok(!("inject" in pkg.dsh.client), "无 inject 声明（种子词无需动态 graph 行）");
assert.ok(!("external" in pkg.dsh.client), "无 external 声明（种子词无需 external）");
assert.equal(pkg.dsh.client.platform, "web", "platform 为 web");

/* 语法整体可解析（node --check 的兜底等价） */
new Function(code);
console.log("client-shape-smoke: ok");
