import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import { __testing, apply } from "./index.js";
import {
  workBuddyApiKeyEntries,
  activeWorkBuddySession,
  workBuddySessionAccounts,
  createWorkBuddyApiKeyStore,
  createWorkBuddySessionStore,
  createWorkBuddySessionRoutingState,
  parseWorkBuddyApiKeys,
  parseWorkBuddySession,
  parseWorkBuddySessions,
  refreshWorkBuddySession,
  serializeWorkBuddyApiKeys,
  serializeWorkBuddySession,
  serializeWorkBuddySessions,
  serializeWorkBuddySessionRouting,
  parseWorkBuddySessionRouting,
  sessionNeedsRefresh,
  upsertWorkBuddyApiKey,
  upsertWorkBuddySession,
} from "./workbuddy-auth.js";
import { authenticationMode, installWorkBuddyWeb, __testing as webTesting } from "./workbuddy-web.js";
import { __testing as creditsTesting, fetchWorkBuddyCredits } from "./workbuddy-credits.js";
import { probeEndpoint } from "./workbuddy-discovery.js";

test("桌面端页面可调用本机认证接口，外部来源仍被拒绝", () => {
  const req = (address, origin) => ({ socket: { remoteAddress: address }, headers: { origin } });
  assert.equal(webTesting.localPost(req("127.0.0.1", "dsh-app://app")), true);
  assert.equal(webTesting.localPost(req("127.0.0.1", "dsh-app://evil")), false);
  assert.equal(webTesting.localPost(req("192.0.2.1", "dsh-app://app")), false);
  const desktop = { socket: { remoteAddress: "127.0.0.1" }, headers: { "user-agent": "Mozilla/5.0 @deepseek-ai/dsh-desktop/0.2.0-rc.2 Electron/44.0.0" } };
  assert.equal(webTesting.localPost(desktop), true);
  assert.equal(webTesting.localPost({ ...desktop, socket: { remoteAddress: "192.0.2.1" } }), false);
  assert.equal(webTesting.localPost({ ...desktop, headers: { "user-agent": "Mozilla/5.0" } }), false);
});

test("自定义 OpenAI Provider 可从端点读取模型目录，并优先使用本次输入的 Key", async () => {
  const previous = globalThis.fetch;
  let observed;
  globalThis.fetch = async (url, options) => {
    observed = { url, options };
    return new Response(JSON.stringify({ data: [
      { id: "model-a", name: "Model A", context_window: 128000, max_output_tokens: 8192 },
      { id: "" },
    ] }), { status: 200, headers: { "content-type": "application/json" } });
  };
  try {
    const models = await probeEndpoint({ provider: "my-provider", api: "openai-responses", apiKey: "new-key" }, {
      profiles: () => new Map([["my-provider", { baseURL: "https://example.test/v1/", headers: { "x-extra": "yes" } }]]),
      resolveCredential: () => { throw new Error("输入新 Key 时不应读取旧凭证"); },
    });
    assert.equal(observed.url, "https://example.test/v1/models");
    assert.equal(observed.options.headers.get("authorization"), "Bearer new-key");
    assert.equal(observed.options.headers.get("x-extra"), "yes");
    assert.deepEqual(models, [{ id: "model-a", name: "Model A", contextWindow: 128000, maxTokens: 8192 }]);
  } finally {
    globalThis.fetch = previous;
  }
});

test("自定义 Anthropic Provider 使用对应端点和认证头", async () => {
  const previous = globalThis.fetch;
  let observed;
  globalThis.fetch = async (url, options) => {
    observed = { url, options };
    return new Response(JSON.stringify({ data: [{ id: "claude-test", display_name: "Claude Test" }] }), { status: 200 });
  };
  try {
    const models = await probeEndpoint({ provider: "anthropic-custom", baseURL: "https://example.test", api: "anthropic-messages" }, {
      profiles: () => new Map([["anthropic-custom", { headers: { authorization: "Bearer stale" } }]]),
      resolveCredential: async () => ({ value: "saved-key" }),
    });
    assert.equal(observed.url, "https://example.test/v1/models?limit=1000");
    assert.equal(observed.options.headers.get("x-api-key"), "saved-key");
    assert.equal(observed.options.headers.get("authorization"), null);
    assert.equal(observed.options.headers.get("anthropic-version"), "2023-06-01");
    assert.deepEqual(models, [{ id: "claude-test", name: "Claude Test" }]);
  } finally {
    globalThis.fetch = previous;
  }
});

test("富模型目录忽略非对象项，超限响应被拒绝", async () => {
  const previous = globalThis.fetch;
  const discovery = () => probeEndpoint({ baseURL: "https://example.test/v1" }, {
    profiles: () => new Map(), resolveCredential: async () => undefined,
  });
  try {
    globalThis.fetch = async () => new Response(JSON.stringify({ models: {
      "model-b": { name: "Model B", limit: { context: 64000 }, top_provider: { max_completion_tokens: 4096 } },
      invalid: "not-a-model",
    } }), { status: 200 });
    assert.deepEqual(await discovery(), [{ id: "model-b", name: "Model B", contextWindow: 64000, maxTokens: 4096 }]);
    globalThis.fetch = async () => new Response("oversized", { status: 200, headers: { "content-length": String(4 * 1024 * 1024 + 1) } });
    await assert.rejects(discovery(), (error) => error.code === "DISCOVERY_FAILED" && /4 MiB/.test(error.message));
  } finally {
    globalThis.fetch = previous;
  }
});

test("模型探测的失败保留可操作错误，且不回显凭证", async () => {
  const previous = globalThis.fetch;
  globalThis.fetch = async () => new Response("unauthorized", { status: 401 });
  try {
    await assert.rejects(
      probeEndpoint({ provider: "custom", baseURL: "https://example.test/v1", apiKey: "secret-value" }, {
        profiles: () => new Map(), resolveCredential: async () => undefined,
      }),
      (error) => error.code === "DISCOVERY_FAILED" && /401/.test(error.message) && !error.message.includes("secret-value"),
    );
    await assert.rejects(
      probeEndpoint({ baseURL: "https://example.test/v1", api: "unsupported" }, {
        profiles: () => new Map(), resolveCredential: async () => undefined,
      }),
      (error) => error.code === "DISCOVERY_UNSUPPORTED",
    );
  } finally {
    globalThis.fetch = previous;
  }
});

test("当前 DSH 适配器在无 WebUI 的调用前拉取新模型并完成 prepareCall", async () => {
  const previous = globalThis.fetch;
  let adapter;
  let discover;
  let requestCount = 0;
  const ctx = {
    inject() {},
    get(key) {
      if (key === "launchEnvironment") return { get: () => undefined };
      if (key === "credentials") return {
        resolve: async (ref) => String(ref).includes("WORKBUDDY_API_KEY") ? { value: "test-key" } : undefined,
      };
      return undefined;
    },
    llm: {
      registerConfigurableProviders: () => ({ replace() {} }),
      registerAdapter: (_providers, value) => { adapter = value; return { replace() {} }; },
      registerModelDiscovery: (_ns, value) => { discover = value; },
    },
  };
  globalThis.fetch = async (url) => {
    assert.equal(url, "https://copilot.tencent.com/v3/config");
    requestCount += 1;
    return new Response(JSON.stringify({ code: 0, data: {
      agents: [{ name: "cli", models: ["deepseek-v4.1-flash"] }],
      models: [{ id: "deepseek-v4.1-flash", name: "Deepseek V4.1 Flash", maxInputTokens: 128000, maxOutputTokens: 8192 }],
    } }), { status: 200 });
  };
  try {
    apply(ctx, { providers: {} });
    const prepared = await adapter.prepareCall("workbuddy-cn", "deepseek-v4.1-flash");
    assert.equal(prepared.model.id, "deepseek-v4.1-flash");
    assert.equal(typeof prepared.stream, "function");
    assert.equal(requestCount, 1);
    const controller = new AbortController();
    globalThis.fetch = async (url, options) => {
      assert.equal(url, "https://example.test/v1/models");
      assert.strictEqual(options.signal, controller.signal);
      return new Response(JSON.stringify({ data: [{ id: "custom-model" }] }), { status: 200 });
    };
    assert.deepEqual(await discover({ baseURL: "https://example.test/v1", apiKey: "test-key" }, controller.signal), [{ id: "custom-model" }]);
  } finally {
    globalThis.fetch = previous;
  }
});

test("桌面端 prepared stream 能发送文本并收到首个模型输出", async () => {
  const previous = globalThis.fetch;
  let adapter;
  const ctx = {
    inject() {},
    get(key) {
      if (key === "launchEnvironment") return { get: () => undefined };
      if (key === "credentials") return {
        resolve: async (ref) => String(ref).includes("WORKBUDDY_API_KEY") ? { value: "test-key" } : undefined,
      };
      return undefined;
    },
    llm: {
      registerConfigurableProviders: () => ({ replace() {} }),
      registerAdapter: (_providers, value) => { adapter = value; return { replace() {} }; },
      registerModelDiscovery() {},
    },
  };
  globalThis.fetch = async (url, options) => {
    if (String(url).endsWith("/v3/config")) return new Response(JSON.stringify({ code: 0, data: {
      agents: [{ name: "cli", models: ["deepseek-v4.1-flash"] }],
      models: [{ id: "deepseek-v4.1-flash", maxInputTokens: 128000, maxOutputTokens: 8192 }],
    } }), { status: 200 });
    assert.match(String(url), /\/v2\/chat\/completions$/);
    assert.equal(new Headers(options.headers).get("authorization"), "Bearer test-key");
    return new Response([
      'data: {"id":"test","model":"deepseek-v4.1-flash","choices":[{"index":0,"delta":{"content":"你好"},"finish_reason":null}]}',
      'data: {"id":"test","model":"deepseek-v4.1-flash","choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}',
      "data: [DONE]",
      "",
    ].join("\n\n"), { status: 200, headers: { "content-type": "text/event-stream" } });
  };
  try {
    apply(ctx, { providers: {} });
    const prepared = await adapter.prepareCall("workbuddy-cn", "deepseek-v4.1-flash");
    for (const request of [
      { messages: [{ role: "user", content: [{ type: "text", text: "你好" }] }] },
      { messages: [{ role: "system", content: [{ type: "text", text: "系统提示" }] }, { role: "user", content: [{ type: "text", text: "你好" }] }] },
      { tools: [{ name: "test", description: "test", parameters: { type: "object", properties: {} } }], messages: [{ role: "user", content: [{ type: "text", text: "你好" }] }] },
      { system: "系统提示", maxTokens: 128, purpose: "title", messages: [{ role: "user", content: [{ type: "text", text: "你好" }] }] },
    ]) {
      const chunks = [];
      for await (const chunk of prepared.stream({ provider: "workbuddy-cn", model: "deepseek-v4.1-flash", sessionId: "desktop-test", ...request })) chunks.push(chunk);
      assert.ok(chunks.some((chunk) => chunk.type === "text-delta" && chunk.text === "你好"), JSON.stringify(chunks));
      assert.ok(chunks.some((chunk) => chunk.type === "finish" && chunk.reason?.kind === "stop"), JSON.stringify(chunks));
    }
  } finally {
    globalThis.fetch = previous;
  }
});

test("新旧 DSH 配置都注册 WorkBuddy，next 使用插件条目命名空间", () => {
  const registered = [];
  const directories = [];
  const discoveries = [];
  const listeners = new Map();
  const injected = [];
  const ctx = {
    fiber: { entry: { options: { id: "llm-workbuddy" } } },
    inject(names, callback) { injected.push({ names, callback }); },
    on(event, callback) { listeners.set(event, callback); },
    llm: {
      registerConfigurableProviders(entries) {
        directories.push(entries);
        return { replace(next) { directories.push(next); } };
      },
      registerAdapter(providers) {
        registered.push(providers);
        return { replace(next) { registered.push(next); } };
      },
      registerModelDiscovery(ns) { discoveries.push(ns); },
    },
  };
  const reactive = { providers: { get: () => ({
    "custom-gateway": { api: "openai-completions", baseURL: "https://example.test/v1", models: [{ id: "custom-model" }] },
  }) } };
  assert.ok(__testing.providerSettings(reactive)["custom-gateway"]);
  apply(ctx, reactive);
  assert.deepEqual(registered[0], ["workbuddy-cn"]);
  assert.deepEqual(directories[0].map((entry) => entry.provider), ["workbuddy-cn"]);
  assert.equal(directories[0][0].settingsNs, "llm-workbuddy");
  assert.deepEqual(discoveries, ["llm-workbuddy"]);
  assert.ok(listeners.has("loader/volatile-update"));
  assert.ok(injected.some(({ names }) => names.includes("settings")));

  const legacy = { ...ctx, on: undefined, inject() {} };
  registered.length = directories.length = discoveries.length = 0;
  apply(legacy, { providers: {} });
  assert.deepEqual(registered[0], ["workbuddy-cn"]);
  assert.equal(directories[0][0].settingsNs, "llm-pi-ai");
  assert.deepEqual(discoveries, ["llm-pi-ai"]);
});

test("认证模式写入新旧 DSH 各自的配置命名空间", async () => {
  for (const modern of [false, true]) {
    const ns = modern ? "llm-workbuddy" : "llm-pi-ai";
    const calls = [];
    const service = {
      ...(modern
        ? { describe: () => [{ ns, value: { providers: {} } }] }
        : { get: () => ({ providers: {} }) }),
      mutate: async (target, ops) => { calls.push({ target, ops }); },
    };
    await webTesting.setMode(webTesting.settingsAccess(service, ns), "token");
    assert.equal(calls[0].target, ns);
    assert.deepEqual(calls[0].ops[0].path, ["providers", "workbuddy-cn"]);
  }
});

test("新版 WorkBuddy 卡片保留旧版认证入口并提供模型编辑", () => {
  const client = readFileSync(new URL("./client.js", import.meta.url), "utf8");
  assert.match(client, /settings\.models\.provider-card/);
  assert.match(client, /key: "llm-workbuddy"/);
  assert.match(client, /name: "plugins\.detail\.section",\s*id: "llm-workbuddy"/);
  assert.match(client, /mount\(input\)/);
  assert.match(client, /mountModelEditor\(models\)/);
  assert.equal(webTesting.validModelOverrides([{ id: "glm-5.3", contextWindow: 262144, maxTokens: 32768 }]), true);
  assert.equal(webTesting.validModelOverrides([{ id: "duplicate" }, { id: "duplicate" }]), false);
  assert.equal(webTesting.validModelOverrides([{ id: "bad", maxTokens: -1 }]), false);
});

test("新版模型接口只修改 WorkBuddy 条目并保留认证模式", async () => {
  const routes = new Map();
  let providers = { "workbuddy-cn": {} };
  let revision = 4;
  const settings = {
    describe: () => [{ ns: "llm-workbuddy", value: { providers }, revision }],
    mutate: async (ns, ops, expected) => {
      assert.equal(ns, "llm-workbuddy");
      assert.equal(expected, revision);
      assert.deepEqual(ops[0].path, ["providers", "workbuddy-cn", "models"]);
      providers = { "workbuddy-cn": { ...providers["workbuddy-cn"], models: ops[0].value } };
      revision++;
    },
  };
  installWorkBuddyWeb({ inject: (_services, callback) => callback({
    settings,
    credentials: {},
    llm: { discoverModels: async () => [{ id: "glm-5.3" }] },
    webServer: { register: ({ path, handler }) => { routes.set(path, handler); return () => {}; } },
    effect: (callback) => callback(),
  }) }, "llm-workbuddy");
  const handler = routes.get("/dsh-llm-workbuddy/auth/models");
  async function call(method, body) {
    let response;
    const req = {
      method,
      url: "/dsh-llm-workbuddy/auth/models",
      socket: { remoteAddress: "127.0.0.1" },
      headers: { origin: "http://localhost:3000" },
      async *[Symbol.asyncIterator]() { if (body) yield Buffer.from(JSON.stringify(body)); },
    };
    await handler(req, {
      writeHead(status) { response = { status }; },
      end(text) { response.body = JSON.parse(text); },
    });
    return response;
  }
  assert.deepEqual((await call("GET")).body, { ok: true, models: null, revision: 4 });
  assert.deepEqual((await call("POST", { action: "discover" })).body.models, [{ id: "glm-5.3" }]);
  const saved = await call("POST", { action: "save", revision: 4, models: [{ id: "glm-5.3" }] });
  assert.equal(saved.status, 200);
  assert.deepEqual(providers["workbuddy-cn"], { models: [{ id: "glm-5.3" }] });
  assert.equal((await call("POST", { action: "save", models: [{ id: "bad", maxTokens: -1 }] })).status, 400);
});

test("旧版接管 pi-ai，新版保留内置 pi-ai 供自定义 Provider 使用", () => {
  const patch = readFileSync(new URL("./cordis.patch.yml", import.meta.url), "utf8");
  const expression = patch.match(/disabled: !!js >-\r?\n((?: {4}[^\r\n]+\r?\n)+)/)?.[1]
    .trim().replace(/\r?\n\s*/g, " ");
  assert.ok(expression);
  const disabled = new Function("ctx", "process", `return (${expression})`);
  const ctx = { get: () => ({ installAnchor: "dsh-package.json" }) };
  const host = (version) => ({ getBuiltinModule: () => ({ readFileSync: () => JSON.stringify({ version }) }) });
  assert.equal(disabled(ctx, host("0.1.6")), true);
  assert.equal(disabled(ctx, host("0.1.7-rc.1")), false);
  assert.equal(disabled(ctx, host("0.1.8")), false);
  assert.equal(disabled(ctx, host("0.2.0-rc.2")), false);
  assert.equal(disabled({ get: () => undefined }, host("0.1.8")), true);
});

test("客户端兼容包装 Provider 并将 WorkBuddy 用量并入统计行", () => {
  const client = readFileSync(new URL("./client.js", import.meta.url), "utf8");
  const index = readFileSync(new URL("./index.js", import.meta.url), "utf8");
  const web = readFileSync(new URL("./workbuddy-web.js", import.meta.url), "utf8");
  assert.match(client, /WORKBUDDY_PROVIDER_PATTERN/);
  assert.match(client, /isWorkBuddyProvider\(provider\)/);
  assert.match(client, /isModLensWorkBuddyProvider/);
  assert.match(client, /data-workbuddy-modlens-hint/);
  assert.match(client, /出现 429 时请检查视觉引擎与额度/);
  assert.match(client, /data-composer-stats/);
  assert.match(client, /display: grid !important/);
  assert.match(client, /会话级账号\/API Key/);
  assert.match(client, /新会话默认凭证/);
  assert.match(client, /data-workbuddy-new-session-selector/);
  assert.match(client, /发送时自动绑定所选凭证/);
  assert.match(client, /解除绑定/);
  assert.match(client, /window\.confirm/);
  assert.match(client, /sessionId/);
  assert.match(client, /const hasTokenAccount = state\?\.mode === "token"/);
  assert.match(client, /state\.routingEnabled && sessionId \? createElement/);
  assert.match(client, /const seats = Array\.from\(document\.querySelectorAll\("\[data-composer-seat\]"\)\)/);
  assert.match(client, /for \(const panel of panels\) panel\.remove\(\)/);
  assert.match(client, /ctx\.slots\.inject\("plugins\.detail\.section"/);
  assert.match(client, /subject\?\.kind === "bundle" && subject\.pkg\?\.name === "@axiaohungry\/dsh-llm-workbuddy"/);
  assert.match(index, /const legacyAdapter = typeof adapter\.prepareCall !== "function"/);
  assert.match(index, /adapter\.prepareCall = async \(provider, model, signal\)/);
  assert.match(index, /persistDefaultSessionBinding/);
  assert.match(index, /bindings: \{ \.\.\.latest\.bindings, \[sessionId\]: binding \}/);
  assert.match(web, /path: `\$\{ROUTE\}\/unbind`/);
  assert.match(web, /const effectiveBinding = sessionBinding;/);
  assert.match(web, /const displayedBinding = effectiveBinding \?\? suggestedBinding/);
});

test("旧版适配器对未知 replay 状态降级为普通历史", () => {
  const legacy = {
    kind: "pi-ai",
    version: 1,
    api: "openai-completions",
    provider: "workbuddy-cn",
    model: "model",
    stopReason: "stop",
    blocks: [],
  };
  const modern = { response: { kind: "pi-ai", version: 2 }, blocks: [] };
  const options = {
    messages: [
      { source: { kind: "model", replayState: modern }, content: [] },
      { source: { kind: "model", replayState: legacy }, content: [] },
      { source: { kind: "model", replayState: { kind: "other", version: 1 } }, content: [] },
    ],
  };

  const normalized = __testing.stripUnsupportedReplay(options);
  assert.equal(normalized.messages[0].source.replayState, undefined);
  assert.deepEqual(normalized.messages[1].source.replayState, legacy);
  assert.equal(normalized.messages[2].source.replayState, undefined);
  assert.notStrictEqual(normalized, options);
  assert.ok(options.messages[0].source.replayState.response);
});

test("直接 Provider 和 ModLens 包装 Provider 都能归一化 WorkBuddy replay 身份", () => {
  const replay = {
    kind: "pi-ai",
    version: 1,
    api: "openai-completions",
    provider: "workbuddy-cn",
    model: "model",
    stopReason: "stop",
    blocks: [],
  };
  const wrapped = {
    provider: "modlens-workbuddy-cn",
    messages: [{
      role: "assistant",
      content: [],
      source: { kind: "model", provider: "modlens-workbuddy-cn", replayState: replay },
    }],
  };
  const normalized = __testing.normalizeWorkBuddyReplay(wrapped);
  assert.notStrictEqual(normalized, wrapped);
  assert.equal(normalized.messages[0].source.provider, "workbuddy-cn");
  assert.equal(normalized.messages[0].source.replayState.provider, "workbuddy-cn");
  assert.equal(wrapped.messages[0].source.provider, "modlens-workbuddy-cn");
  assert.equal(wrapped.messages[0].source.replayState.provider, "workbuddy-cn");

  const direct = {
    provider: "workbuddy-cn",
    messages: [{
      role: "assistant",
      content: [],
      source: { kind: "model", provider: "workbuddy-cn", replayState: replay },
    }],
  };
  assert.strictEqual(__testing.normalizeWorkBuddyReplay(direct), direct);
});

test("中断工具错误只移除最后一次助手消息的 replayState", () => {
  const replay = {
    kind: "pi-ai",
    version: 1,
    api: "openai-completions",
    provider: "workbuddy-cn",
    model: "model",
    stopReason: "toolUse",
    blocks: [{ type: "tool-call" }],
  };
  const options = {
    provider: "workbuddy-cn",
    messages: [
      { role: "assistant", content: [{ type: "text", text: "earlier" }], source: { kind: "model", provider: "workbuddy-cn", replayState: { ...replay, blocks: [{ type: "text" }] } } },
      { role: "assistant", content: [{ type: "tool-call", id: "call-1", name: "pwsh", arguments: "{}" }], source: { kind: "model", provider: "workbuddy-cn", replayState: replay } },
      { role: "user", content: [{ type: "tool-result", toolCallId: "call-1", isError: true, content: [{ type: "text", text: "unknown outcome" }] }] },
      { role: "system", content: [{ type: "text", text: "interrupted" }] },
    ],
  };
  const normalized = __testing.prepareWorkBuddyOptions(options);
  assert.equal(normalized.messages[0].source.replayState.kind, "pi-ai");
  assert.equal(normalized.messages[1].source.replayState, undefined);
  assert.equal(normalized.messages[2].content[0].isError, true);
});

test("非 WorkBuddy Provider 不会被 replay 兜底改写", () => {
  const options = {
    provider: "opencode-go-live",
    messages: [{
      role: "assistant",
      content: [],
      source: { kind: "model", provider: "opencode-go-live", replayState: { kind: "pi-ai", version: 1 } },
    }],
  };
  assert.strictEqual(__testing.normalizeWorkBuddyReplay(options), options);
});

test("会话级认证状态只保存账号或 API Key 引用", () => {
  const state = createWorkBuddySessionRoutingState(true, {
    "session-a": { mode: "token", accountId: "user:user-a" },
    "session-b": { mode: "api-key", apiKeyRef: "WORKBUDDY_API_KEY_DSH_B" },
    ignored: { mode: "token", accountId: "" },
    secret: { mode: "api-key", apiKey: "should-not-persist" },
  }, { mode: "token", accountId: "user:user-a" });
  const restored = parseWorkBuddySessionRouting(serializeWorkBuddySessionRouting(state));
  assert.equal(restored.enabled, true);
  assert.deepEqual(restored.lastUsed, { mode: "token", accountId: "user:user-a" });
  assert.deepEqual(restored.bindings, {
    "session-a": { mode: "token", accountId: "user:user-a" },
    "session-b": { mode: "api-key", apiKeyRef: "WORKBUDDY_API_KEY_DSH_B" },
  });
  assert.equal(JSON.stringify(restored).includes("should-not-persist"), false);
});

test("直连与 ModLens 转发都保留明确会话绑定，默认值只供未绑定会话首次固化", () => {
  const first = createWorkBuddySessionRoutingState(true, {
    "session-a": { mode: "token", accountId: "user:user-a" },
  }, { mode: "token", accountId: "user:user-b" });
  const changedDefault = createWorkBuddySessionRoutingState(true, first.bindings, { mode: "token", accountId: "user:user-c" });
  assert.deepEqual(__testing.sessionBindingFor(first, "session-a"), { mode: "token", accountId: "user:user-a" });
  assert.deepEqual(__testing.sessionBindingFor(changedDefault, "session-a"), { mode: "token", accountId: "user:user-a" });
  // ModLens 保留原始 options.sessionId 后再转发到 workbuddy-cn，因而与直连走同一绑定解析。
  assert.deepEqual(__testing.sessionBindingFor(changedDefault, "session-a"), __testing.sessionBindingFor(first, "session-a"));
  assert.equal(__testing.sessionBindingFor(changedDefault, "session-missing"), undefined);
  assert.equal(__testing.sessionBindingFor(changedDefault, undefined), undefined);
});

test("忽略由其他插件负责的 Provider", () => {
  const builtins = new Map([["deepseek", {}]]);

  assert.equal(__testing.ownsProvider("workbuddy-cn", builtins), true);
  assert.equal(__testing.ownsProvider("codebuddy-cn", builtins), true);
  assert.equal(__testing.ownsProvider("deepseek", builtins), true);
  assert.equal(__testing.ownsProvider("opencode-go-live", builtins), false);
});

test("完整的自定义 Provider 配置由插件注册为通用路由", () => {
  const provider = __testing.genericProvider("txcodingplan", {
    displayName: "Deepseek-v4-flash",
    api: "openai-completions",
    baseURL: "https://chatapi.weixin.qq.com/openai/v1",
    models: [{ id: "Deepseek-v4-flash", name: "Deepseek-v4-flash", maxTokens: 48000 }],
  });

  assert.equal(provider.id, "txcodingplan");
  assert.equal(provider.getModels()[0].provider, "txcodingplan");
  assert.equal(provider.getModels()[0].api, "openai-completions");
  assert.equal(__testing.ownsProvider("txcodingplan", new Map(), { api: "openai-completions", baseURL: "https://example.com", models: [{ id: "model" }] }), true);
});

test("API Key 和登录令牌使用各自的认证头", () => {
  assert.deepEqual(__testing.authenticationHeaders({ value: "api-key", kind: "api-key" }), { "x-api-key": "api-key" });
  assert.deepEqual(__testing.authenticationHeaders({ value: "login-token", kind: "bearer" }), { authorization: "Bearer login-token" });
});

test("WorkBuddy 自有认证助手兼容新旧 DSH 的 signal 调用约定", async () => {
  const auth = __testing.workBuddyApiKeyAuth();
  const credential = { type: "api_key", key: "login-token" };

  // Older DSH calls resolve without a signal. This must not dereference it.
  assert.deepEqual(await auth.resolve({ credential }), {
    auth: { apiKey: "login-token" },
    source: "DSH credential",
  });

  // Newer DSH supplies an AbortSignal. The same resolver must remain valid.
  const controller = new AbortController();
  assert.deepEqual(await auth.resolve({ credential, signal: controller.signal }), {
    auth: { apiKey: "login-token" },
    source: "DSH credential",
  });
});

test("登录请求头不修改 DSH 冻结的配置对象", () => {
  const headers = __testing.runtimeHeaders(Object.freeze({ existing: "value" }));
  headers["X-User-Id"] = "user";
  assert.deepEqual(headers, { existing: "value", "X-User-Id": "user" });
});

test("模型请求恢复 WorkBuddy 官方 User-Agent", () => {
  const options = Object.freeze({ headers: Object.freeze({ "user-agent": "deepseek-harness", existing: "value" }) });
  const resolved = __testing.workBuddyRequestOptions(options);

  assert.equal(resolved.headers["user-agent"], "CLI/unknown CodeBuddy/2.137.1");
  assert.equal(resolved.headers.existing, "value");
  assert.equal(resolved.timeoutMs, 300_000);
  assert.equal(options.headers["user-agent"], "deepseek-harness");

  assert.equal(__testing.workBuddyRequestOptions({ timeoutMs: 12_000 }).timeoutMs, 12_000);
});

test("显式空配置启用令牌模式，未配置时仍使用 API Key", () => {
  assert.equal(__testing.workBuddySource({}, {}).apiKeyEnv, "WORKBUDDY_API_KEY");
  assert.equal(__testing.workBuddySource({ providers: { "workbuddy-cn": {} } }, {}).apiKeyEnv, undefined);
  assert.equal(__testing.workBuddySource({ providers: { "codebuddy-cn": {} } }, {}).apiKeyEnv, undefined);
});

test("WebUI 可以区分 API Key 与令牌认证模式", () => {
  assert.equal(authenticationMode({ providers: {} }), "api-key");
  assert.equal(authenticationMode({ providers: { "workbuddy-cn": { apiKeyEnv: "WORKBUDDY_API_KEY" } } }), "api-key");
  assert.equal(authenticationMode({ providers: { "workbuddy-cn": {} } }), "token");
  assert.equal(authenticationMode({ providers: { "codebuddy-cn": {} } }), "token");
});

test("登录会话可以安全序列化并按过期时间刷新", () => {
  const session = {
    auth: { accessToken: "access", refreshToken: "refresh", expiresAt: 2_000_000 },
    account: { userId: "user", enterpriseId: "enterprise", ignored: "not-stored" },
  };
  const restored = parseWorkBuddySession(serializeWorkBuddySession(session));
  assert.deepEqual(restored.account, { userId: "user", enterpriseId: "enterprise" });
  assert.equal(sessionNeedsRefresh(restored, 1_000_000), false);
  assert.equal(sessionNeedsRefresh(restored, 1_900_000), true);
});

test("多个登录账号可以持久化、去重并切换", () => {
  const first = { auth: { accessToken: "access-1", refreshToken: "refresh-1" }, account: { userId: "user-1" } };
  const second = { auth: { accessToken: "access-2", refreshToken: "refresh-2" }, account: { userId: "user-2" } };
  const store = upsertWorkBuddySession(upsertWorkBuddySession(createWorkBuddySessionStore(), first), second);
  const restored = parseWorkBuddySessions(serializeWorkBuddySessions({ ...store, activeId: store.sessions[0].id }));
  assert.equal(restored.sessions.length, 2);
  assert.equal(activeWorkBuddySession(restored).account.userId, "user-1");
  assert.deepEqual(workBuddySessionAccounts(restored).map((entry) => entry.label), ["user-1", "user-2"]);
  assert.equal(JSON.stringify(workBuddySessionAccounts(restored)).includes("refresh-1"), false);
  const replaced = upsertWorkBuddySession(restored, { ...first, auth: { accessToken: "access-1-new", refreshToken: "refresh-1-new" } });
  assert.equal(replaced.sessions.length, 2);
  assert.equal(replaced.sessions.find((entry) => entry.id === "user:user-1").auth.accessToken, "access-1-new");
});

test("新增登录账号统一生成账号名称和 UID 展示字段", () => {
  const session = {
    auth: { accessToken: "access-new", refreshToken: "refresh-new" },
    account: { account: { uid: "new-user-id", nickname: "新账号" } },
  };
  const store = upsertWorkBuddySession(createWorkBuddySessionStore(), session);
  const [account] = workBuddySessionAccounts(store);

  assert.equal(account.label, "新账号");
  assert.equal(account.accountName, "新账号");
  assert.equal(account.userId, "new-user-id");
  assert.equal(account.account.displayName, "新账号");
  assert.equal(account.account.userId, "new-user-id");
});

test("账号接口缺少名称时从 UIN 或登录令牌补齐展示信息", () => {
  const payload = Buffer.from(JSON.stringify({ sub: "jwt-user-id", preferred_username: "jwt-account" })).toString("base64url");
  const session = {
    auth: { accessToken: `header.${payload}.signature`, refreshToken: "refresh-jwt" },
    account: { uin: "uin-account" },
  };
  const store = upsertWorkBuddySession(createWorkBuddySessionStore(), session);
  const [account] = workBuddySessionAccounts(store);

  assert.equal(account.label, "uin-account");
  assert.equal(account.userId, "jwt-user-id");
  assert.equal(account.account.displayName, "uin-account");
  assert.equal(account.account.uin, "uin-account");
});

test("API Key 目录只保存引用和展示元数据，不保存密钥值", () => {
  const store = upsertWorkBuddyApiKey(createWorkBuddyApiKeyStore(), {
    id: "dsh:WORKBUDDY_API_KEY_DSH_TEST",
    ref: "WORKBUDDY_API_KEY_DSH_TEST",
    label: "DSH API Key 1",
  });
  const restored = parseWorkBuddyApiKeys(serializeWorkBuddyApiKeys(store));
  assert.deepEqual(workBuddyApiKeyEntries(restored).map((entry) => entry.ref), ["WORKBUDDY_API_KEY_DSH_TEST"]);
  assert.equal(JSON.stringify(workBuddyApiKeyEntries(restored)).includes("secret"), false);
  const noActive = createWorkBuddyApiKeyStore(restored.entries, null);
  assert.equal(noActive.activeId, null);
});

test("插件直接调用官方刷新接口且不复用旧过期时间", async () => {
  const originalFetch = globalThis.fetch;
  let request;
  globalThis.fetch = async (url, options) => {
    request = { url, options };
    return new Response(JSON.stringify({ code: 0, data: { accessToken: "new-access", expiresIn: 3600 } }), {
      status: 200,
      headers: { "content-type": "application/json" },
    });
  };
  try {
    const refreshed = await refreshWorkBuddySession({
      auth: { accessToken: "old-access", refreshToken: "refresh", expiresAt: 1 },
      account: { uid: "user", enterpriseId: "enterprise" },
    });
    assert.equal(request.url, "https://copilot.tencent.com/v2/plugin/auth/token/refresh");
    assert.equal(request.options.headers["X-Refresh-Token"], "refresh");
    assert.equal(request.options.headers["X-Enterprise-Id"], "enterprise");
    assert.equal(refreshed.auth.accessToken, "new-access");
    assert.ok(refreshed.auth.expiresAt > Date.now() + 3_500_000);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("模型目录保留逐模型思考能力和默认档位", () => {
  const models = __testing.modelsFromConfig({
    agents: [{ name: "cli", models: ["reasoning", "plain"] }],
    models: [
      { id: "reasoning", name: "Reasoning", maxInputTokens: 1000, maxOutputTokens: 100, supportsReasoning: true, onlyReasoning: true, reasoning: { effort: "high" } },
      { id: "plain", name: "Plain", maxInputTokens: 1000, maxOutputTokens: 100, supportsReasoning: false },
    ],
  });

  assert.deepEqual(models.map((model) => model.id), ["reasoning", "plain"]);
  assert.equal(models[0].reasoning, true);
  assert.equal(models[0].thinkingLevelMap.off, null);
  assert.equal(models[0].thinkingLevelMap.xhigh, undefined);
  assert.equal(models[0].defaultReasoningEffort, "high");
  assert.equal(models[1].reasoning, false);
});

test("自定义模型可覆盖自己的思考档位", () => {
  const [model] = __testing.selectWorkBuddyModels([], [{
    id: "custom",
    contextWindow: 1000,
    maxTokens: 100,
    reasoningEfforts: { off: null, medium: "balanced" },
  }]);

  assert.equal(model.reasoning, true);
  assert.equal(Object.hasOwn(model.thinkingLevelMap, "off"), false);
  assert.equal(model.thinkingLevelMap.medium, "balanced");
  assert.equal(model.thinkingLevelMap.high, null);
});

test("积分查询复用 WorkBuddy billing 接口并汇总有效资源", async () => {
  const originalFetch = globalThis.fetch;
  const requests = [];
  globalThis.fetch = async (url, options) => {
    requests.push({ url, options });
    if (String(url).includes("get-user-resource")) {
      return new Response(JSON.stringify({ code: 0, data: { Response: { Data: { Accounts: [
        { CycleCapacityRemainPrecise: 12.5, CapacityRemainPrecise: 100, PackageName: "月度包" },
        { CapacityRemain: 7 },
      ] } } } }), { status: 200 });
    }
    return new Response(JSON.stringify({ code: 0, data: { total: 2, data: [
      { requestId: "r1", requestTime: Date.now(), credit: 1.25 },
      { requestId: "r2", requestTime: Date.now() - 1000, credit: 2.75 },
    ] } }), { status: 200 });
  };
  try {
    const result = await fetchWorkBuddyCredits({ auth: { accessToken: "token" }, account: { userId: "user" } });
    assert.equal(result.credits, 19.5);
    assert.equal(result.todayUsage.count, 2);
    assert.equal(result.todayUsage.used, 4);
    assert.equal(result.creditError, null);
    assert.equal(requests[0].url, "https://www.codebuddy.cn/v2/billing/meter/get-user-resource");
    assert.equal(requests[0].options.headers.authorization, "Bearer token");
    assert.equal(requests[1].url, "https://www.codebuddy.cn/billing/meter/get-user-request-usage");
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("企业积分响应支持不限量和周期重置时间", () => {
  const result = creditsTesting.enterpriseUsage({ data: { limitNum: -1, cycleResetTime: "2026-09-01 00:00:00" } });
  assert.equal(result.unlimited, true);
  assert.equal(result.credits, null);
  assert.ok(Number.isFinite(result.cycleResetTime));
});

test("积分查询只接受受信任的 WorkBuddy billing 域名", () => {
  assert.equal(creditsTesting.normalizeHost("https://www.codebuddy.cn"), "https://www.codebuddy.cn");
  assert.equal(creditsTesting.normalizeHost("https://evil.example"), "https://www.codebuddy.cn");
  assert.deepEqual(creditsTesting.buildCreditResourceBody(new Date(2026, 7, 31, 9, 8, 7)), {
    PageNumber: 1,
    PageSize: 100,
    ProductCode: "p_tcaca",
    Status: [0, 3],
    PackageEndTimeRangeBegin: "2026-08-31 09:08:07",
    PackageEndTimeRangeEnd: "2127-08-31 09:08:07",
  });
});
