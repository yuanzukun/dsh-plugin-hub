# DSH WorkBuddy Provider

在 DeepSeek Harness（DSH）桌面端和 WebUI 中使用 WorkBuddy 中国区模型，支持 API Key 和账号登录。

> 本插件是第三方适配工具，不属于 WorkBuddy 或 DSH 官方项目。使用前需准备有效账号或 API Key。

## 功能

| 功能 | 说明 |
| --- | --- |
| 两种认证方式 | 支持 API Key、浏览器账号登录，可随时切换 |
| 多凭据管理 | 添加、切换和删除多个 API Key 或登录账号 |
| 会话独立选择 | 可为不同会话分别指定账号或 API Key |
| 模型管理 | 获取可用模型，添加、编辑、删除模型或恢复在线目录 |
| 模型参数 | 按模型配置上下文窗口、最大输出 Token 和思考档位 |
| 账号用量 | 令牌模式下查看剩余积分、今日请求次数和积分用量 |
| 多端支持 | 支持桌面、Web 和 Headless 使用方式，兼容 ModLens 包装模型 |

不需要安装本机 WorkBuddy CLI。模型可用范围及用量以当前账号权限和服务返回结果为准。

## 环境要求

- 已安装 DSH，支持已声明兼容的旧版和 `0.2.x` 系列。
- Node.js `>= 22.19.0`。
- 支持 Windows、Linux、macOS。

DSH 升级到新版本系列后，请先确认插件兼容性。

## 安装与更新

### 桌面端

在 **设置 → 插件 → 添加插件** 中安装：

```text
@axiaohungry/dsh-llm-workbuddy
```

也可以在终端执行，更新时使用同一条命令：

```powershell
dsh plugin --profile desktop add @axiaohungry/dsh-llm-workbuddy@latest
```

### Web / Headless

一键安装或更新这两个 Profile：

```powershell
npx --yes @axiaohungry/dsh-llm-workbuddy@latest install
```

仅安装 Web Profile：

```powershell
dsh plugin --profile web add @axiaohungry/dsh-llm-workbuddy@latest
```

**安装或更新后，完整退出并重新启动 DSH。** 只刷新页面不会完成更新。
更新可保留已有模型、账号和 Key 配置。

## 使用方法

### 1. 打开配置

桌面端进入 **设置 → 插件 → WorkBuddy 插件详情**。
WebUI 进入 **设置 → 模型**，添加或编辑 **WorkBuddy 中国区**。
具体入口可能随 DSH 版本略有不同。

### 2. 选择认证方式

**API Key**

1. 选择 `API Key` 模式。
2. 在“新增 API Key”中粘贴 Key，可填写便于识别的名称。
3. 点击“添加并使用”，或从下拉列表中选择已有 Key。

也可选择环境变量 `WORKBUDDY_API_KEY`；兼容已有的 `CODEBUDDY_API_KEY`。
API Key 模式不显示账号令牌积分。

**令牌登录**

1. 选择 `令牌登录`。
2. 点击登录或添加账号，在浏览器中完成登录。
3. 返回 DSH，选择要使用的账号。

支持保存多个账号。删除账号会移除该账号的本地登录凭据。

### 3. 选择模型

点击“获取可用模型”，选择需要的模型，再点击“保存模型”。
可按需修改模型名称、上下文窗口、最大输出 Token 和思考档位。

更换账号或 Key 后，建议重新获取可用模型。手动添加模型时，请确认模型 ID 和账号权限。
“恢复在线目录”会取消手工覆盖的模型列表。

### 4. 可选：为会话单独选择凭据

打开“会话级账号/API Key”开关后，可在新会话或输入框附近选择凭据。

- 未绑定会话首次调用时，使用当前默认选择。
- 已绑定会话继续使用自己的选择，不随全局默认值变化。
- 可单独切换或解除当前会话绑定。
- 关闭开关后使用全局选择；重新开启后恢复已有绑定。

账号模型权限不同时，还需选择该账号可用的模型。

## 近期解决的问题

`1.3.25` 主要改善：

- 部分会话出现 `400 / 11128`、请求失败的问题。
- 新旧 DSH 版本下系统指令、工具调用的兼容性。
- API Key 和令牌两种方式的调用一致性。

已完成自动化检查，并验证两种认证方式均可获取模型、发送请求及接收回复。
上游服务或 DSH 发生变化时，仍可能需要更新插件。

## 常见问题

| 问题 | 处理方法 |
| --- | --- |
| 找不到 WorkBuddy 提供方或设置入口 | 确认安装到正在使用的 Profile，完整重启 DSH 后再查看插件详情或模型设置 |
| 更新后仍是旧版本或旧界面 | 重新执行对应 Profile 的更新命令，完整退出并重新打开 DSH |
| API Key 下拉列表没有新 Key | 在插件自己的“新增 API Key”区域提交，点击“添加并使用” |
| 登录成功但调用使用了其他账号 | 检查是否启用了会话级凭据，并核对当前会话的绑定 |
| 获取模型失败或找不到模型 | 核对当前账号或 Key，重新获取目录；手动添加时检查模型 ID 和账号权限 |
| 返回 `401 / 403` | 检查 Key 是否有效、账号是否过期，以及是否具有目标模型权限；必要时重新登录 |
| 返回 `400 / 11128` | 更新到最新版本并完整重启；仍失败时记录业务码、插件版本和使用的模型后反馈 |
| 返回 `500`、空响应或请求长时间无结果 | 更新并重启，检查网络；使用包装模型时，也检查相应服务状态 |
| 不显示积分，或显示“暂不可用” | 确认使用令牌模式；积分服务暂时不可用不一定影响模型调用 |
| 思考档位选项与其他模型不同 | 属于正常情况，按该模型显示的可用选项选择 |
| ModLens 模型慢、超时或返回 `429` | 检查 ModLens 视觉引擎的登录、网络和额度；纯文本任务可先切换 WorkBuddy 直连验证 |

查看桌面 Profile 的安装版本：

```powershell
dsh plugin --profile desktop list --depth 0
```

Web 用户将 `desktop` 改为 `web`。ModLens 用户也可运行：

```powershell
modlens doctor --json
```

反馈问题时，请提供插件版本、DSH 版本、模型名称、认证方式和脱敏后的错误信息。
**不要公开 API Key、登录令牌或未经脱敏的完整日志。**

## 卸载

桌面 Profile：

```powershell
dsh plugin --profile desktop remove @axiaohungry/dsh-llm-workbuddy
```

Web / Headless 安装器：

```powershell
npx --yes @axiaohungry/dsh-llm-workbuddy@latest uninstall
```

卸载后重启 DSH。安装器默认保留凭据，便于后续重新安装。

## License

[MIT](./LICENSE)
