/**
 * dsh-shutdown 浏览器半部的测试。
 *
 * client.js 是 ModuleLoader 格式（不是 ESM），所以这里造一个最小的 window /
 * document / react 替身把 factory 取出来，再直接驱动插件注册的组件函数。
 * 测的是组件的行为（点了按钮发生什么），不是它的渲染结果。
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

/** 极简 hooks 运行时：useState 带真实状态，useEffect 只记录。 */
function makeReact() {
  const states = [];
  let cursor = 0;
  return {
    states,
    React: {
      createElement(type, props, ...children) { return { type, props: props || {}, children }; },
      useState(init) {
        const i = cursor++;
        if (!(i in states)) states[i] = typeof init === 'function' ? init() : init;
        return [states[i], (v) => { states[i] = typeof v === 'function' ? v(states[i]) : v; }];
      },
      useEffect() { /* 测试里不跑副作用 */ },
    },
    reset() { cursor = 0; },
  };
}

/** 装载 client.js，返回取 factory 的入口与 DOM 记录。 */
function loadClient() {
  let factory = null;
  const styles = [];
  globalThis.window = {
    __ModuleLoader__: { load(def) { factory = def.factory; } },
    setTimeout: () => 0,
    close: () => {},
  };
  globalThis.document = {
    createElement() {
      return {
        attrs: {},
        textContent: '',
        parentNode: null,
        setAttribute(k, v) { this.attrs[k] = v; },
      };
    },
    head: {
      appendChild(el) { el.parentNode = globalThis.document.head; styles.push(el); },
      removeChild(el) { el.parentNode = null; },
    },
  };
  return { getFactory: () => factory, styles };
}

async function boot() {
  const env = loadClient();
  await import(`../lib/client.js?case=${Math.random().toString(36).slice(2)}`);
  const factory = env.getFactory();
  assert.ok(factory, 'client.js 应通过 ModuleLoader 注册 factory');

  const react = makeReact();
  const mod = factory((name) => {
    if (name === 'react') return react.React;
    throw new Error('未预期的 require: ' + name);
  });
  return { env, react, mod };
}

/** 造一个记录调用的 slots 服务替身。 */
function makeSlots() {
  const registrations = [];
  let injectDisposerCalls = 0;
  const slots = {
    inject(key, cb) {
      registrations.push({ key, entry: cb() });
      return () => { injectDisposerCalls += 1; };
    },
    register(opts, render) { return { opts, render }; },
  };
  return { slots, registrations, getInjectDisposerCalls: () => injectDisposerCalls };
}

function makeCtx(slots) {
  const effects = [];
  return {
    ctx: {
      get(name) { return name === 'slots' ? slots : undefined; },
      effect(fn) { const cleanup = fn(); effects.push(cleanup); return () => {}; },
    },
    effects,
  };
}

/** 在组件返回的树里按文本找按钮。 */
function findButton(tree, text) {
  const stack = [tree];
  while (stack.length) {
    const node = stack.pop();
    if (!node || typeof node !== 'object') continue;
    if (node.type === 'button' && node.children.includes(text)) return node;
    for (const child of node.children || []) stack.push(child);
  }
  return null;
}

function treeText(tree) {
  let out = '';
  const stack = [tree];
  while (stack.length) {
    const node = stack.pop();
    if (node === null || node === undefined) continue;
    if (typeof node === 'string') { out += node; continue; }
    if (typeof node !== 'object') continue;
    for (const child of node.children || []) stack.push(child);
  }
  return out;
}

// ---------------------------------------------------------------- 注册与清理

test('apply 应向 settings.section 注册一个条目', async () => {
  const { mod } = await boot();
  const { slots, registrations } = makeSlots();
  const { ctx } = makeCtx(slots);

  mod.apply(ctx);

  assert.equal(registrations.length, 1, '应恰好注入一个 slot');
  assert.equal(registrations[0].key, 'settings.section');
  assert.equal(registrations[0].entry.opts.id, 'dsh-shutdown');
});

test('插件卸载时应撤销 slots.inject 返回的 disposer', async () => {
  const { mod } = await boot();
  const { slots, getInjectDisposerCalls } = makeSlots();
  const { ctx, effects } = makeCtx(slots);

  mod.apply(ctx);
  assert.equal(getInjectDisposerCalls(), 0, '挂载阶段不应立即撤销');

  assert.equal(effects.length, 1, '应注册一个清理 effect');
  effects[0]();

  assert.equal(getInjectDisposerCalls(), 1, '卸载时必须调用 slots.inject 的 disposer，否则设置页会残留条目');
});

test('卸载时应移除注入的样式元素', async () => {
  const { mod, env } = await boot();
  const { slots } = makeSlots();
  const { ctx, effects } = makeCtx(slots);

  mod.apply(ctx);
  assert.equal(env.styles.length, 1, '应注入一份样式');
  assert.equal(env.styles[0].parentNode !== null, true, '样式应已挂到 head');

  effects[0]();
  assert.equal(env.styles[0].parentNode, null, '卸载后样式应已从 head 移除');
});

test('slots 服务不存在时 apply 不应抛错', async () => {
  const { mod } = await boot();
  const ctx = { get() { return undefined; }, effect() { return () => {}; } };
  assert.doesNotThrow(() => mod.apply(ctx));
});

// ---------------------------------------------------------------- 响应判定

test('端点返回 500 时应显示错误，而不是显示成功', async () => {
  const { mod, react } = await boot();
  const { slots, registrations } = makeSlots();
  const { ctx } = makeCtx(slots);
  mod.apply(ctx);

  const ShutdownSection = registrations[0].entry.render().type;
  assert.equal(typeof ShutdownSection, 'function', 'slot 渲染函数应返回组件元素');

  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => ({
    ok: false,
    status: 500,
    json: async () => { throw new SyntaxError('Unexpected token < in JSON'); },
  });
  try {
    // 第一次渲染：点「关闭 DSH 服务」
    react.reset();
    let tree = ShutdownSection();
    const startBtn = findButton(tree, '关闭 DSH 服务');
    assert.ok(startBtn, '应能找到关闭按钮');
    startBtn.props.onClick();

    // 第二次渲染：点「确认关闭」，触发请求
    react.reset();
    tree = ShutdownSection();
    const confirmBtn = findButton(tree, '确认关闭');
    assert.ok(confirmBtn, '应能找到确认按钮');
    await confirmBtn.props.onClick();
  } finally {
    globalThis.fetch = originalFetch;
  }

  react.reset();
  const finalText = treeText(ShutdownSection());
  assert.ok(
    !finalText.includes('关闭成功'),
    `端点返回 500 时不应显示成功，实际渲染：${finalText}`,
  );
  assert.ok(finalText.includes('错误'), `应显示错误信息，实际渲染：${finalText}`);
});

test('网络层失败（进程已退出）时仍视为成功', async () => {
  const { mod, react } = await boot();
  const { slots, registrations } = makeSlots();
  const { ctx } = makeCtx(slots);
  mod.apply(ctx);

  const ShutdownSection = registrations[0].entry.render().type;
  assert.equal(typeof ShutdownSection, 'function', 'slot 渲染函数应返回组件元素');

  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => { throw new TypeError('fetch failed'); };
  try {
    react.reset();
    let tree = ShutdownSection();
    findButton(tree, '关闭 DSH 服务').props.onClick();

    react.reset();
    tree = ShutdownSection();
    await findButton(tree, '确认关闭').props.onClick();
  } finally {
    globalThis.fetch = originalFetch;
  }

  react.reset();
  const finalText = treeText(ShutdownSection());
  assert.ok(finalText.includes('关闭成功'), `连接被断开说明进程确已退出，应显示成功，实际：${finalText}`);
});

test('端点返回 ok:true 时显示成功', async () => {
  const { mod, react } = await boot();
  const { slots, registrations } = makeSlots();
  const { ctx } = makeCtx(slots);
  mod.apply(ctx);

  const ShutdownSection = registrations[0].entry.render().type;
  assert.equal(typeof ShutdownSection, 'function', 'slot 渲染函数应返回组件元素');

  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => ({ ok: true, status: 200, json: async () => ({ ok: true, message: '正在关闭 DSH 服务' }) });
  try {
    react.reset();
    let tree = ShutdownSection();
    findButton(tree, '关闭 DSH 服务').props.onClick();

    react.reset();
    tree = ShutdownSection();
    await findButton(tree, '确认关闭').props.onClick();
  } finally {
    globalThis.fetch = originalFetch;
  }

  react.reset();
  const finalText = treeText(ShutdownSection());
  assert.ok(finalText.includes('关闭成功'), `正常响应应显示成功，实际：${finalText}`);
});
