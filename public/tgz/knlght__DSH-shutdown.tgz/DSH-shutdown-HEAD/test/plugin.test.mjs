/**
 * dsh-shutdown host 半部的行为测试。
 *
 * 重点覆盖两个动作端点的请求守卫：跨站 POST 必须被拒（否则任意网页都能关掉本机
 * DSH），同源与无 Origin（curl 等非浏览器客户端）必须放行。
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

const MOD = '../lib/index.js';

/** 收集插件注册的路由。 */
function makeCtx() {
  const routes = [];
  const ctx = {
    inject(deps, cb) {
      cb({ webServer: { register(opts) { routes.push(opts); return () => {}; } } });
      return () => {};
    },
  };
  return { ctx, routes };
}

function makeRes() {
  return {
    statusCode: 200,
    headers: {},
    body: null,
    ended: false,
    setHeader(k, v) { this.headers[String(k).toLowerCase()] = v; },
    end(s) { this.body = s === undefined ? '' : s; this.ended = true; },
  };
}

async function freshModule() {
  return import(`${MOD}?case=${Math.random().toString(36).slice(2)}`);
}

/** 在拦截 process.exit 的前提下执行一次请求，返回 { res, exitCode }。 */
async function fire(routes, path, method, headers) {
  const route = routes.find((r) => r.path === path);
  assert.ok(route, `${path} 路由应已注册`);
  const req = { method, headers, socket: {} };
  const res = makeRes();

  let exitCode = null;
  const originalExit = process.exit;
  process.exit = (code) => { exitCode = code; };
  try {
    route.handler(req, res);
    // registerAction 用 500ms 定时器退出进程，这里等足够久以捕获它
    await new Promise((r) => setTimeout(r, 700));
  } finally {
    process.exit = originalExit;
  }
  return { res, exitCode };
}

// ---------------------------------------------------------------- CSRF 守卫

test('携带外部 Origin 的 POST 应被拒绝，且不触发进程退出', async () => {
  const { ctx, routes } = makeCtx();
  const mod = await freshModule();
  await mod.apply(ctx);

  const { res, exitCode } = await fire(routes, '/_dsh/shutdown', 'POST', {
    origin: 'https://evil.example.com',
    host: '127.0.0.1:3080',
  });

  assert.equal(res.statusCode, 403, `跨站请求应返回 403，实际 ${res.statusCode}`);
  assert.equal(exitCode, null, '跨站请求绝不应触发进程退出');
});

test('外部 Origin 的 restart 请求同样应被拒绝', async () => {
  const { ctx, routes } = makeCtx();
  const mod = await freshModule();
  await mod.apply(ctx);

  const { res, exitCode } = await fire(routes, '/_dsh/restart', 'POST', {
    origin: 'http://attacker.local',
    host: '127.0.0.1:3080',
  });

  assert.equal(res.statusCode, 403);
  assert.equal(exitCode, null);
});

test('同源 POST（127.0.0.1）应放行并触发退出码 0（shutdown）', async () => {
  const { ctx, routes } = makeCtx();
  const mod = await freshModule();
  await mod.apply(ctx);

  const { res, exitCode } = await fire(routes, '/_dsh/shutdown', 'POST', {
    origin: 'http://127.0.0.1:3080',
    host: '127.0.0.1:3080',
  });

  assert.equal(res.statusCode, 200, `同源请求应放行，实际 ${res.statusCode}`);
  assert.equal(exitCode, 0, 'shutdown 应以退出码 0 结束进程');
});

test('同源 POST（localhost）应放行并触发退出码 42（restart）', async () => {
  const { ctx, routes } = makeCtx();
  const mod = await freshModule();
  await mod.apply(ctx);

  const { res, exitCode } = await fire(routes, '/_dsh/restart', 'POST', {
    origin: 'http://localhost:3080',
    host: '127.0.0.1:3080',
  });

  assert.equal(res.statusCode, 200);
  assert.equal(exitCode, 42, 'restart 应以退出码 42 结束进程，交由启动脚本重新拉起');
});

test('无 Origin 的 POST（curl 等非浏览器客户端）应放行', async () => {
  const { ctx, routes } = makeCtx();
  const mod = await freshModule();
  await mod.apply(ctx);

  const { res, exitCode } = await fire(routes, '/_dsh/shutdown', 'POST', { host: '127.0.0.1:3080' });

  assert.equal(res.statusCode, 200, `命令行客户端应放行，实际 ${res.statusCode}`);
  assert.equal(exitCode, 0);
});

test('畸形的 Origin 头应被拒绝而不是放行', async () => {
  const { ctx, routes } = makeCtx();
  const mod = await freshModule();
  await mod.apply(ctx);

  const { res, exitCode } = await fire(routes, '/_dsh/shutdown', 'POST', {
    origin: 'not a url',
    host: '127.0.0.1:3080',
  });

  assert.equal(res.statusCode, 403, '无法解析的 Origin 必须保守拒绝');
  assert.equal(exitCode, null);
});

// ---------------------------------------------------------------- 方法守卫

test('GET 请求应返回 405', async () => {
  const { ctx, routes } = makeCtx();
  const mod = await freshModule();
  await mod.apply(ctx);

  const { res, exitCode } = await fire(routes, '/_dsh/shutdown', 'GET', {
    origin: 'http://127.0.0.1:3080',
    host: '127.0.0.1:3080',
  });

  assert.equal(res.statusCode, 405);
  assert.equal(exitCode, null, '非 POST 不应触发退出');
});

test('两个端点都应注册为 exact 类型', async () => {
  const { ctx, routes } = makeCtx();
  const mod = await freshModule();
  await mod.apply(ctx);

  const paths = routes.map((r) => r.path).sort();
  assert.deepEqual(paths, ['/_dsh/restart', '/_dsh/shutdown']);
  for (const r of routes) assert.equal(r.kind, 'exact');
});
test('Origin 与 Host 一致时（局域网访问）应放行', async () => {
  const { ctx, routes } = makeCtx();
  const mod = await freshModule();
  await mod.apply(ctx);

  const { res, exitCode } = await fire(routes, '/_dsh/shutdown', 'POST', {
    origin: 'http://192.0.2.10:3080',
    host: '192.0.2.10:3080',
  });

  assert.equal(res.statusCode, 200, `同源请求应放行，实际 ${res.statusCode}`);
  assert.equal(exitCode, 0);
});

test('Origin 与 Host 不一致（伪造同源）应被拒绝', async () => {
  const { ctx, routes } = makeCtx();
  const mod = await freshModule();
  await mod.apply(ctx);

  const { res, exitCode } = await fire(routes, '/_dsh/shutdown', 'POST', {
    origin: 'http://192.0.2.99:3080',
    host: '192.0.2.10:3080',
  });

  assert.equal(res.statusCode, 403, `Origin 与 Host 不一致必须拒绝，实际 ${res.statusCode}`);
  assert.equal(exitCode, null);
});
