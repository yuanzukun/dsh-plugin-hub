﻿# dsh-web.ps1 — DeepSeek Harness quick launcher
#
# Starts `dsh web` (the DeepSeek Harness browser UI) in the foreground and lets
# dsh hand the UI to the browser itself: dsh opens the authenticated (?token=...)
# URL only after the whole plugin tree has settled (loader.await()) — a far more
# accurate readiness signal than probing the TCP port, because the port starts
# listening while plugins are still loading.
#
# dsh-web.cmd launches this script in HIDDEN mode by default (no terminal
# window stays open; output goes to dsh-web-hidden.log). Run this .ps1
# directly (without -Hidden) if you want a visible console and Ctrl+C stop.
#
# Usage (from a terminal):
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\dsh-web.ps1
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\dsh-web.ps1 -Dir G:\myproject -Port 8080
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\dsh-web.ps1 -Hidden
#
# Or simply double-click dsh-web.cmd next to this file.

param(
    # Workspace root for the session (dsh's default workspace). Empty = use the
    # script's own folder.
    [string]$Dir = "",
    # Port to listen on. Default matches dsh web's own default (3080).
    [int]$Port = 3080,
    # 隐藏模式：不保留终端窗口，dsh 输出写入脚本目录下的 dsh-web-hidden.log。
    [switch]$Hidden
)

# ---------------------------------------------------------------------------
# OPTIONAL: pin a fixed workspace root here (leave empty to use the script's
# own folder, or whatever -Dir says). Example:
#   $FixedDir = 'G:\myproject'
$FixedDir = ''
# ---------------------------------------------------------------------------

$ErrorActionPreference = 'Stop'

if ($Port -le 0 -or $Port -gt 65535) {
    Write-Host "[dsh-web] Invalid port: $Port (must be 1-65535)." -ForegroundColor Red
    exit 2
}

# --- resolve the workspace directory ----------------------------------------
$workspace = $Dir
if ([string]::IsNullOrWhiteSpace($workspace)) { $workspace = $FixedDir }
if ([string]::IsNullOrWhiteSpace($workspace)) { $workspace = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) }
if (Test-Path -LiteralPath $workspace -PathType Container) {
    Set-Location -LiteralPath $workspace
    Write-Host "[dsh-web] Workspace: $workspace"
} else {
    Write-Warning "[dsh-web] Folder not found: $workspace — using the current folder instead."
}

$url = "http://127.0.0.1:$Port"

# --- helpers -----------------------------------------------------------------
function Test-PortUp {
    param([int]$P)
    try {
        $client = New-Object System.Net.Sockets.TcpClient
        $result = $client.BeginConnect('127.0.0.1', $P, $null, $null)
        if ($result.AsyncWaitHandle.WaitOne(300)) {
            $client.EndConnect($result)   # throws if the connect failed
            $client.Close()
            return $true
        }
        $client.Close()
        return $false
    } catch {
        return $false
    }
}

function Open-InDefaultBrowser {
    param([string]$Url)
    Start-Process $Url
    Write-Host "[dsh-web] Opening $Url in the default browser."
}

# --- already running? --------------------------------------------------------
$restartExitCode = 42
$hiddenLog = Join-Path $PSScriptRoot 'dsh-web-hidden.log'
$serverCode = 0
$firstRun = $true

do {
    # 首次启动时若端口已被占用，先等 3 秒复测：服务可能正处于关闭过程（TCP 半开
    # 会被误判为“已在运行”，导致只开浏览器却撞上 ERR_CONNECTION_REFUSED）。
    # 复测仍占用才算真的已在运行；释放了则继续正常启动流程。
    if ($firstRun -and (Test-PortUp $Port)) {
        Start-Sleep -Seconds 3
        if (Test-PortUp $Port) {
            Write-Host "[dsh-web] Port $Port is already serving (harness already running)."
            Open-InDefaultBrowser $url
            exit 0
        }
        Write-Host "[dsh-web] Port $Port was still releasing; proceeding to start the harness."
    }
    $isFirstRun = $firstRun
    $firstRun = $false

    # 重启时等待旧进程释放端口，避免误判为“已在运行”。
    if (-not $isFirstRun) {
        $portDeadline = (Get-Date).AddSeconds(10)
        while ((Get-Date) -lt $portDeadline -and (Test-PortUp $Port)) {
            Start-Sleep -Milliseconds 300
        }
    }

    if ($Hidden) {
        Add-Content -LiteralPath $hiddenLog -Value "===== dsh web starting at $(Get-Date -Format o) =====" -ErrorAction SilentlyContinue
    }

    Write-Host "[dsh-web] Starting DeepSeek Harness on $url ..."
    Write-Host "[dsh-web] The browser opens automatically once the harness is fully ready."
    Write-Host "[dsh-web] Press Ctrl+C to stop the server."

    # --- run the server in the foreground ----------------------------------------
    try {
        # PS 5.1：原生命令写 stderr 在 $ErrorActionPreference='Stop' 下会抛 NativeCommandError，
        # 把 dsh web 误判为启动失败（MCP 子进程的 stderr 会立即触发）。调用期间临时降级，
        # 真正的异常（如 dsh 不存在）仍由外层 catch 捕获。
        $prevEAP = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try {
            # 浏览器交给 dsh 自己打开：它在整个插件树加载完成（loader.await() 落定）
            # 之后才打开带 token 的 URL，这个就绪判断远比探测 TCP 端口准确 ——
            # 端口开始 listen 时，插件其实还在加载。
            if ($Hidden) {
                & dsh web --port $Port *>> $hiddenLog
            } else {
                & dsh web --port $Port
            }
            $serverCode = $LASTEXITCODE
        } finally {
            $ErrorActionPreference = $prevEAP
        }
        if ($null -eq $serverCode) { $serverCode = 0 }
        # Ctrl+C / console-close exit codes count as an intentional stop
        if ($serverCode -eq 130 -or $serverCode -eq 3221225786) { $serverCode = 0 }
    } catch {
        if ($Hidden) {
            Add-Content -LiteralPath $hiddenLog -Value "[dsh-web] FATAL: $_" -ErrorAction SilentlyContinue
        } else {
            Write-Host "[dsh-web] FATAL: $_" -ForegroundColor Red
        }
        $serverCode = 1
    }

    if ($serverCode -eq $restartExitCode) {
        if ($Hidden) {
            Add-Content -LiteralPath $hiddenLog -Value "[dsh-web] Restart requested, relaunching..." -ErrorAction SilentlyContinue
        } else {
            Write-Host "[dsh-web] Restart requested, relaunching..."
        }
    }
} while ($serverCode -eq $restartExitCode)

# --- keep the window open so errors are readable ------------------------------
if (-not $Hidden) {
    Write-Host ""
    if ($serverCode -ne 0) {
        Write-Host "[dsh-web] dsh exited with code $serverCode." -ForegroundColor Red
    } else {
        Write-Host "[dsh-web] Server stopped."
    }
    Write-Host "[dsh-web] Press Enter to close this window."
    Read-Host | Out-Null
}
exit $serverCode
