@echo off
rem DeepSeek Harness quick launcher.
rem Double-click this file (or run it from a terminal with optional args):
rem   dsh-web.cmd -Dir G:\myproject -Port 8080
rem Hidden mode is the default: no terminal window stays open.
start "DeepSeek Harness" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0dsh-web.ps1" -Hidden %*
exit /b 0
