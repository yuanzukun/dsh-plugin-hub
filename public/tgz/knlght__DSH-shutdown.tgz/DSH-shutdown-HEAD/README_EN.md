# dsh-shutdown

<!-- Hero -->
<div align="center">
  <b style="font-size: 1.15em;">One-click shutdown / restart for DeepSeek Harness</b><br /><br />
  Settings page · double confirmation · graceful exit / auto restart<br /><br />
  <b>Closing the browser no longer leaves a background process behind, and you can restart with one click</b>.
</div>

<div align="center">
  🌏 <a href="./README.md"><b>中文</b></a> · <a href="./README_EN.md">English</a>
</div>

## ✨ Why

Closing the browser does **not** stop the dsh background service——it keeps holding the port and memory. This plugin adds an in-page shutdown/restart entry, no CLI needed.

## ✨ Features

- **🖥️ Settings page**: a new "Service Control" section at the bottom of the sidebar
- **🛡️ Double confirmation**: click "Shut down" or "Restart" → "Confirm / Cancel" buttons appear, preventing accidents
- **✅ Success feedback**: a green "shut down successfully / restarting" panel renders immediately (and tries to close the tab)
- **🔁 Auto restart**: the restart request makes the host process exit with a special code; the `launcher/dsh-web.ps1` launcher catches it (root `dsh-web.cmd`/`dsh-web.ps1` are shortcuts) and relaunches `dsh web`
- **🎨 Native look**: all colors reference DSH theme tokens (`--dsw-alias-*`), light/dark adaptive

## 📦 Install

```bash
dsh plugin --profile web add <this repo / npm package>
# restart dsh web
```

## 🧠 Design notes

- Shutdown endpoint: `/_dsh/shutdown` (POST only) —— responds "shutting down" first, then `process.exit(0)` after 500ms
- Restart endpoint: `/_dsh/restart` (POST only) —— responds "restarting" first, then exits with code 42 after 500ms; `dsh-web.ps1` catches that code and relaunches `dsh web`
- Session logs are appended per event; exiting while idle is safe. Let an in-flight turn finish first
- Browsers only allow scripts to close windows they opened——manually opened tabs keep the success panel, so the result is always visible

## 🧩 Ecosystem

Tag your own plugins with <a href="https://github.com/topics/dsh-shutdown"><code>dsh-shutdown</code></a> to join the ecosystem. PRs welcome.

## 📄 License

[MIT](./LICENSE)

## 🔒 Security

The shutdown endpoint terminates the whole service, so it guards itself against cross-site requests:

- **Browser requests**: the `Origin` header is validated. Requests from external sites receive `403`, preventing any web page from shutting down your local DSH in the background — browsers do not preflight such cross-origin simple POSTs, so the endpoint has to check for itself
- **Same-origin access**: `127.0.0.1` / `localhost` / `::1` pass directly; when accessed via a LAN IP or a custom hostname (`dsh web --host 0.0.0.0`), `Origin` must equal `Host`
- **Requests without `Origin`**: non-browser clients such as `curl` and launch scripts pass, so scripting keeps working

## 📝 Changelog

### v0.2.0

- **Added** CSRF protection (see Security above)
- **Fixed** the UI reporting "shut down successfully" when the endpoint returned an error such as 500 — previously any non-throwing `fetch` counted as success; network failure, response parsing failure and HTTP errors are now distinguished
- **Fixed** `slots.inject` registration not being disposed on plugin unload or hot reload, which could leave duplicate entries in the Settings page
- **Added** 17 behavioural tests (10 host + 7 client) covering the CSRF guard, exit-code semantics, teardown and response handling
