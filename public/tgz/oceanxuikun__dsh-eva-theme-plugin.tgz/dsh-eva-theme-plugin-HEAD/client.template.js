/*!
 * dsh-eva-theme-plugin — browser bundle (classic script).
 *
 * Neon Genesis Evangelion themed surfaces for the DeepSeek Harness Web GUI.
 * Three unit schemes, switchable in the sidebar:
 *   - eva-unit01  初号機 (Unit-01): purple body, neon-green accents
 *   - eva-unit00  零号機 (Unit-00): blue-grey body, yellow accents
 *   - eva-unit02  弐号機 (Unit-02): crimson body, orange accents
 *
 * Implementation (all sanctioned plugin surfaces, no harness source touched):
 *   1. Registers the three themes through ctx.theme.register(...) — each with
 *      a complete --dsw-alias-* / --dsw-specific-* token set, so EVERY page
 *      element (surfaces, labels, buttons, states, bubbles, input, sidebar,
 *      scrollbars, menus) re-tints when the scheme switches.
 *   2. Paints the unit wallpaper behind the app (embedded data URI) through a
 *      <style> tag that is rewritten on every theme/change to match the
 *      active unit (left-side protection gradient keeps the chat legible),
 *      layered under an A.T.-field honeycomb grid.
 *   3. Renders a mecha banner + 3-unit switcher into the sidebar's
 *      'sidebar.footer.action' slot, headed by an EVA title-card serif
 *      "EVANGELION" block; the switcher calls ctx.theme.setTheme(...).
 *   4. Overlays a full NERV combat HUD: animated hazard tapes (top/bottom),
 *      corner targeting brackets, CRT scanlines + flicker + sweep beam,
 *      rotating reticle, giant unit-number watermark, vertical katakana,
 *      and a blinking telemetry status bar — all token-driven, re-tinting
 *      per unit with zero JS on theme/change.
 *   5. Restyles real harness nodes (data-composer-card, data-chat-flow-kind,
 *      data-tool, .md-code-block, role=treeitem/dialog/...) into squared,
 *      chamfered, state-railed mecha panels.
 */
window.__ModuleLoader__.load({
  id: 'dsh-eva-theme-plugin',
  factory: (require) => {
    'use strict'
    var module = { exports: {} }
    var exports = module.exports

    var React = require('react')

    var UNIT01_URI = 'data:image/webp;base64,__UNIT01_B64__'
    var UNIT00_URI = 'data:image/webp;base64,__UNIT00_B64__'
    var UNIT02_URI = 'data:image/webp;base64,__UNIT02_B64__'

    var name = 'dsh-eva-theme-plugin'
    /* Activation ordering: the theme service (tokens + registry) and the
       slots service (sidebar injection) must be live first. */
    var inject = ['theme', 'slots']

    /* ------------------------------------------------------------------ */
    /* Unit palettes (dark schemes)                                        */
    /* ------------------------------------------------------------------ */
    var UNITS = {
      'eva-unit01': {
        label: '初号機',
        short: '01',
        type: 'TEST TYPE',
        sync: '96.4%',
        image: UNIT01_URI,
        glow: 'rgba(185, 107, 255, 0.18)',
        palette: {
          bgBase: 'rgba(12, 8, 24, 0.7)',
          layer1: 'rgba(18, 12, 34, 0.78)',
          layer2: 'rgba(24, 16, 44, 0.86)',
          layer3: 'rgba(31, 21, 56, 0.95)',
          overlay: 'rgba(16, 10, 32, 0.96)',
          deep: '#0a0618',
          sidebar: 'rgba(10, 6, 20, 0.62)',
          sidebarActive: 'rgba(22, 14, 42, 0.85)',
          sidebarHover: 'rgba(16, 10, 30, 0.75)',
          brand: '#b96bff',
          brandBright: '#cf8fff',
          brandDim: 'rgba(185, 107, 255, 0.16)',
          brandDimStrong: 'rgba(185, 107, 255, 0.26)',
          accent: '#8cff3f',
          accentBright: '#abff70',
          labelPrimary: '#f4f1ff',
          labelSecondary: '#c9c0e8',
          labelTertiary: '#9a8fc4',
          labelCaption: '#7f75a8',
          labelDim: '#5c5480',
          border: '185, 107, 255',
          bubble: 'rgba(22, 14, 40, 0.55)',
          bubbleHighlight: 'rgba(40, 28, 72, 0.5)',
          input: 'rgba(18, 12, 36, 0.85)',
          codeBlock: 'rgba(6, 4, 14, 0.62)',
          codeBanner: 'rgba(9, 6, 20, 0.7)',
          success: '#63e6a0',
          successBright: '#8af2bc',
          successDim: 'rgba(99, 230, 160, 0.16)',
          warn: '#ffb454',
          warnBright: '#ffc87d',
          warnDim: 'rgba(255, 180, 84, 0.18)',
          error: '#ff6b8a',
          errorBright: '#ff94ab',
          scroll1: '#241a44',
          scroll2: '#2e2254',
          toast: 'rgba(14, 9, 28, 0.96)',
          toolbar: 'rgba(10, 6, 20, 0.55)',
          toolbarInvisible: 'rgba(10, 6, 20, 0.4)',
          toolbarHover: 'rgba(20, 13, 38, 0.7)',
        },
      },
      'eva-unit00': {
        label: '零号機',
        short: '00',
        type: 'PROTOTYPE',
        sync: '87.1%',
        image: UNIT00_URI,
        glow: 'rgba(255, 194, 51, 0.15)',
        palette: {
          bgBase: 'rgba(14, 15, 20, 0.7)',
          layer1: 'rgba(20, 22, 30, 0.78)',
          layer2: 'rgba(26, 28, 40, 0.86)',
          layer3: 'rgba(33, 36, 52, 0.95)',
          overlay: 'rgba(12, 13, 18, 0.96)',
          deep: '#0c0d12',
          sidebar: 'rgba(11, 12, 17, 0.62)',
          sidebarActive: 'rgba(22, 24, 34, 0.85)',
          sidebarHover: 'rgba(16, 17, 24, 0.75)',
          brand: '#ffc233',
          brandBright: '#ffd566',
          brandDim: 'rgba(255, 194, 51, 0.16)',
          brandDimStrong: 'rgba(255, 194, 51, 0.26)',
          accent: '#5a9bdc',
          accentBright: '#7ab4ec',
          labelPrimary: '#f6f4ee',
          labelSecondary: '#cfcabd',
          labelTertiary: '#a29b8a',
          labelCaption: '#8a8474',
          labelDim: '#635f52',
          border: '255, 194, 51',
          bubble: 'rgba(22, 24, 32, 0.55)',
          bubbleHighlight: 'rgba(36, 40, 54, 0.5)',
          input: 'rgba(20, 22, 30, 0.85)',
          codeBlock: 'rgba(8, 9, 12, 0.62)',
          codeBanner: 'rgba(10, 11, 16, 0.7)',
          success: '#7fd3a5',
          successBright: '#9fe3bd',
          successDim: 'rgba(127, 211, 165, 0.16)',
          warn: '#ffb454',
          warnBright: '#ffc87d',
          warnDim: 'rgba(255, 180, 84, 0.18)',
          error: '#ff7a6b',
          errorBright: '#ffa394',
          scroll1: '#262838',
          scroll2: '#303348',
          toast: 'rgba(14, 15, 20, 0.96)',
          toolbar: 'rgba(11, 12, 17, 0.55)',
          toolbarInvisible: 'rgba(11, 12, 17, 0.4)',
          toolbarHover: 'rgba(20, 22, 30, 0.7)',
        },
      },
      'eva-unit02': {
        label: '弐号機',
        short: '02',
        type: 'PRODUCTION MODEL',
        sync: '92.8%',
        image: UNIT02_URI,
        glow: 'rgba(255, 75, 58, 0.16)',
        palette: {
          bgBase: 'rgba(22, 10, 12, 0.7)',
          layer1: 'rgba(30, 14, 18, 0.78)',
          layer2: 'rgba(40, 18, 24, 0.86)',
          layer3: 'rgba(50, 23, 31, 0.95)',
          overlay: 'rgba(20, 9, 11, 0.96)',
          deep: '#140608',
          sidebar: 'rgba(18, 8, 10, 0.62)',
          sidebarActive: 'rgba(38, 16, 21, 0.85)',
          sidebarHover: 'rgba(28, 12, 15, 0.75)',
          brand: '#ff4b3a',
          brandBright: '#ff6b52',
          brandDim: 'rgba(255, 75, 58, 0.16)',
          brandDimStrong: 'rgba(255, 75, 58, 0.26)',
          accent: '#ff9a3c',
          accentBright: '#ffb45e',
          labelPrimary: '#fdf2f0',
          labelSecondary: '#e3c6c0',
          labelTertiary: '#bc948c',
          labelCaption: '#a07a72',
          labelDim: '#77554e',
          border: '255, 75, 58',
          bubble: 'rgba(34, 16, 20, 0.55)',
          bubbleHighlight: 'rgba(56, 26, 32, 0.5)',
          input: 'rgba(30, 14, 18, 0.85)',
          codeBlock: 'rgba(14, 6, 8, 0.62)',
          codeBanner: 'rgba(18, 8, 10, 0.7)',
          success: '#7fd3a5',
          successBright: '#9fe3bd',
          successDim: 'rgba(127, 211, 165, 0.16)',
          warn: '#ffb454',
          warnBright: '#ffc87d',
          warnDim: 'rgba(255, 180, 84, 0.18)',
          error: '#ff5252',
          errorBright: '#ff8484',
          scroll1: '#38202a',
          scroll2: '#462836',
          toast: 'rgba(22, 10, 12, 0.96)',
          toolbar: 'rgba(18, 8, 10, 0.55)',
          toolbarInvisible: 'rgba(18, 8, 10, 0.4)',
          toolbarHover: 'rgba(34, 16, 20, 0.7)',
        },
      },
    }

    /* ------------------------------------------------------------------ */
    /* Token builder: palette → full --dsw-* override set                  */
    /* ------------------------------------------------------------------ */
    function buildTokens(p) {
      return {
        '--dsw-alias-bg-base': p.bgBase,
        '--dsw-alias-bg-layer-1': p.layer1,
        '--dsw-alias-bg-layer-2': p.layer2,
        '--dsw-alias-bg-layer-3': p.layer3,
        '--dsw-alias-bg-overlay': p.overlay,
        '--dsw-alias-bg-module-platform': p.layer1,
        '--dsw-alias-bg-multi-select': p.layer2,
        '--dsw-alias-bg-mask-1': 'rgba(3, 5, 12, 0.52)',
        '--dsw-alias-bg-mask-2': 'rgba(3, 5, 12, 0.24)',
        '--dsw-alias-bg-mask-drop': 'rgba(10, 13, 30, 0.7)',
        '--dsw-alias-bg-skeleton': 'rgba(255, 255, 255, 0.08)',

        '--dsw-alias-border-l1': 'rgba(' + p.border + ', 0.1)',
        '--dsw-alias-border-l2-darkmode-thin': 'rgba(' + p.border + ', 0.13)',
        '--dsw-alias-border-l2': 'rgba(' + p.border + ', 0.16)',
        '--dsw-alias-border-l3': 'rgba(' + p.border + ', 0.22)',
        '--dsw-alias-border-l4': 'rgba(' + p.border + ', 0.3)',
        '--dsw-alias-border-inverted': 'rgba(255, 255, 255, 0.07)',
        '--dsw-alias-border-inverted2': 'rgba(255, 255, 255, 0.1)',

        '--dsw-alias-brand-primary': p.brand,
        '--dsw-alias-brand-text': p.labelPrimary,
        '--dsw-alias-brand-primary-invert': p.deep,
        '--dsw-alias-brand-primary-new-colorprimary-new-color': p.brand,
        '--dsw-alias-button-contrast-fill': p.brand,
        '--dsw-alias-button-primary-fill': p.brand,
        '--dsw-alias-button-primary-hover': p.brandBright,
        '--dsw-alias-button-primary-dimmed': p.brandDim,
        '--dsw-alias-button-info-fill': p.accent,
        '--dsw-alias-button-info-hover': p.accentBright,
        '--dsw-alias-button-floating-fill': p.layer2,
        '--dsw-alias-button-floating-hover': p.layer3,
        '--dsw-alias-button-elevated-fill': p.layer2,
        '--dsw-alias-button-ghost-active-fill': p.brandDim,
        '--dsw-alias-button-ghost-active-hover': p.brandDimStrong,
        '--dsw-alias-button-ghost-active-border': p.brand,
        '--dsw-alias-button-tool-bar-fill': p.toolbar,
        '--dsw-alias-button-tool-bar-fill-invisible': p.toolbarInvisible,
        '--dsw-alias-button-tool-bar-hover': p.toolbarHover,

        '--dsw-alias-interactive-bg-hover': 'rgba(255, 255, 255, 0.07)',
        '--dsw-alias-interactive-bg-hover-accent': p.brandDim,
        '--dsw-alias-interactive-bg-hover-solid': p.layer3,
        '--dsw-alias-interactive-bg-active': 'rgba(255, 255, 255, 0.12)',

        '--dsw-alias-label-primary': p.labelPrimary,
        '--dsw-alias-label-primary-bluish': p.labelPrimary,
        '--dsw-alias-label-primary-dimmed': p.labelSecondary,
        '--dsw-alias-label-primary-foreground': p.deep,
        '--dsw-alias-label-primary-inverted': p.deep,
        '--dsw-alias-label-secondary': p.labelSecondary,
        '--dsw-alias-label-tertiary': p.labelTertiary,
        '--dsw-alias-label-caption': p.labelCaption,
        '--dsw-alias-label-dimmed': p.labelDim,

        '--dsw-alias-markdown-citation': p.layer3,
        '--dsw-alias-markdown-code-block': p.codeBlock,
        '--dsw-alias-markdown-code-block-banner': p.codeBanner,
        '--dsw-alias-markdown-code-segment-selected': p.layer3,
        '--dsw-alias-markdown-code-segment-unselected': p.codeBlock,
        '--dsw-alias-markdown-inline-code': p.brandDim,
        '--dsw-alias-markdown-placeholder': p.layer1,
        '--dsw-alias-markdown-tag': p.layer3,

        '--dsw-alias-scrollbar-bg-l1': p.scroll1,
        '--dsw-alias-scrollbar-bg-l2': p.scroll2,
        '--dsw-alias-scrollbar-hover-l1': p.brandDimStrong,
        '--dsw-alias-scrollbar-hover-l2': p.brand,

        '--dsw-alias-state-business-primary': p.brand,
        '--dsw-alias-state-business-tertiary': p.brandDim,
        '--dsw-alias-state-success-primary': p.success,
        '--dsw-alias-state-success-secondary': p.successBright,
        '--dsw-alias-state-success-tertiary': p.successDim,
        '--dsw-alias-state-warn-primary': p.warn,
        '--dsw-alias-state-warn-secondary': p.warnBright,
        '--dsw-alias-state-warn-label': p.warnBright,
        '--dsw-alias-state-warn-tertiary': p.warnDim,
        '--dsw-alias-state-error-primary': p.error,
        '--dsw-alias-state-error-secondary': p.errorBright,

        '--dsw-alias-toast-bg': p.toast,
        '--dsw-alias-tooltip-bg': p.toast,

        '--dsw-specific-sidebar-fill': p.sidebar,
        '--dsw-specific-sidebar-nav-item-active': p.sidebarActive,
        '--dsw-specific-sidebar-nav-item-active-accent': p.brandDim,
        '--dsw-specific-sidebar-nav-item-hover': p.sidebarHover,
        '--dsw-specific-bubble': p.bubble,
        '--dsw-specific-bubble-highlight': p.bubbleHighlight,
        '--dsw-specific-input-major': p.input,
        '--dsw-specific-menu': p.layer3,
        '--dsw-specific-selector': p.layer2,
        '--dsw-specific-login-input': p.layer1,
        '--dsw-specific-tip': p.layer1,

        /* dangling in the harness (referenced by ui-jobs/ui-agent-preset but
           never defined) — claim it so those surfaces go full NERV mono. */
        '--dsw-font-mono': "'SF Mono','JetBrains Mono',Consolas,monospace",
      }
    }

    /* ------------------------------------------------------------------ */
    /* Backdrop CSS for one unit                                           */
    /* ------------------------------------------------------------------ */
    /* A.T. field honeycomb tile (unit-independent, sits behind panels). */
    var HEX_TILE = "data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20width='28'%20height='49'%20viewBox='0%200%2028%2049'%3E%3Cpath%20d='M13.99%209.25l13%207.5v15l-13%207.5L1%2031.75v-15l12.99-7.5zM3%2017.9v12.7l10.99%206.34%2011-6.35V17.9l-11-6.34L3%2017.9z'%20fill='none'%20stroke='white'%20stroke-opacity='0.055'/%3E%3C/svg%3E"

    function buildBackdropCss(unit) {
      var p = unit.palette
      return [
        'body {',
        '  background-color: ' + p.deep + ';',
        '  background-image:',
        '    linear-gradient(90deg, ' + p.deep + ' 0%, ' + p.deep + 'f2 38%, ' + p.deep + '99 58%, ' + p.deep + '2e 80%, ' + p.deep + '52 100%),',
        '    radial-gradient(ellipse at 78% 26%, ' + unit.glow + ' 0%, transparent 55%),',
        '    /* A.T. field hex grid */',
        '    url("' + HEX_TILE + '"),',
        '    /* blueprint grid, visible through the translucent panels */',
        '    repeating-linear-gradient(90deg, rgba(255, 255, 255, 0.03) 0 1px, transparent 1px 44px),',
        '    repeating-linear-gradient(0deg, rgba(255, 255, 255, 0.03) 0 1px, transparent 1px 44px),',
        '    url("' + unit.image + '");',
        '  background-repeat: no-repeat, no-repeat, repeat, no-repeat, no-repeat, no-repeat;',
        '  background-size: cover, cover, 28px 49px, cover, cover, cover;',
        '  background-position: right center;',
        '}',
        '::selection { background: ' + p.brand + '; color: ' + p.deep + '; }',
        ':focus-visible { outline-color: ' + p.brand + '; }',
      ].join('\n')
    }

    /* ------------------------------------------------------------------ */
    /* Static mecha chrome (token-driven, so it re-tints per unit)         */
    /*                                                                     */
    /* Selectors target STABLE harness nodes only: data-slot wrappers are  */
    /* display:contents (no box), so real elements are addressed via       */
    /* data-composer-card / data-chat-flow-kind / data-tool / role=...     */
    /* ------------------------------------------------------------------ */
    var MECHA_CSS = [
      '/* === NERV warning tapes: animated hazard stripes, top + bottom === */',
      'body::before {',
      '  content: \'\';',
      '  position: fixed;',
      '  top: 0; left: 0; right: 0;',
      '  height: 10px;',
      '  z-index: 80;',
      '  pointer-events: none;',
      '  background: repeating-linear-gradient(-45deg, var(--dsw-alias-brand-primary) 0 12px, #0b0b0b 12px 24px);',
      '  animation: eva-tape 0.9s linear infinite;',
      '}',
      '.eva-tape {',
      '  position: fixed;',
      '  left: 0; right: 0; bottom: 0;',
      '  height: 10px;',
      '  z-index: 80;',
      '  pointer-events: none;',
      '  background: repeating-linear-gradient(45deg, var(--dsw-alias-brand-primary) 0 12px, #0b0b0b 12px 24px);',
      '  animation: eva-tape 0.9s linear infinite reverse;',
      '}',
      '@keyframes eva-tape { to { background-position: 33.94px 0; } }',

      '/* === HUD targeting brackets at the four viewport corners === */',
      '.eva-bracket {',
      '  position: fixed;',
      '  width: 34px; height: 34px;',
      '  z-index: 79;',
      '  pointer-events: none;',
      '  opacity: 0.8;',
      '  border: 2px solid var(--dsw-alias-brand-primary);',
      '}',
      '.eva-bracket-tl { top: 14px; left: 10px; border-right: none; border-bottom: none; }',
      '.eva-bracket-tr { top: 14px; right: 10px; border-left: none; border-bottom: none; }',
      '.eva-bracket-bl { bottom: 36px; left: 10px; border-right: none; border-top: none; }',
      '.eva-bracket-br { bottom: 36px; right: 10px; border-left: none; border-top: none; }',

      '/* === CRT layer: scanlines + flicker + slow vertical sweep beam === */',
      '.eva-scanlines {',
      '  position: fixed;',
      '  inset: 0;',
      '  z-index: 54;',
      '  pointer-events: none;',
      '  background:',
      '    repeating-linear-gradient(0deg, rgba(0, 0, 0, 0.05) 0 1px, transparent 1px 3px),',
      '    radial-gradient(ellipse at 50% 50%, transparent 62%, rgba(0, 0, 0, 0.32) 100%);',
      '  animation: eva-flicker 7s steps(84) infinite;',
      '}',
      '@keyframes eva-flicker {',
      '  0%, 100% { opacity: 1; }',
      '  47% { opacity: 0.93; } 48% { opacity: 1; }',
      '  71% { opacity: 0.96; } 72% { opacity: 1; }',
      '}',
      '.eva-sweep {',
      '  position: fixed;',
      '  left: 0; right: 0; top: 0; height: 28vh;',
      '  z-index: 54;',
      '  pointer-events: none;',
      '  background: linear-gradient(180deg, transparent 0%, rgba(255, 255, 255, 0.04) 44%, rgba(255, 255, 255, 0.08) 50%, rgba(255, 255, 255, 0.04) 56%, transparent 100%);',
      '  animation: eva-sweep 8s linear infinite;',
      '}',
      '@keyframes eva-sweep { from { transform: translateY(-32vh); } to { transform: translateY(112vh); } }',

      '/* === Rotating target reticle (ghost layer over the wallpaper zone) === */',
      '.eva-reticle {',
      '  position: fixed;',
      '  right: 4vw; top: 16vh;',
      '  width: 200px; height: 200px;',
      '  z-index: 53;',
      '  pointer-events: none;',
      '  color: var(--dsw-alias-brand-primary);',
      '  opacity: 0.22;',
      '}',
      '.eva-reticle i { position: absolute; inset: 0; border: 1px solid currentColor; border-radius: 50%; }',
      '.eva-reticle i:nth-child(1) { border-style: dashed; animation: eva-spin 26s linear infinite; }',
      '.eva-reticle i:nth-child(2) { inset: 22%; animation: eva-spin 18s linear infinite reverse; }',
      '.eva-reticle i:nth-child(3) { inset: 44%; border-width: 2px; }',
      '.eva-reticle::before, .eva-reticle::after { content: \'\'; position: absolute; background: currentColor; }',
      '.eva-reticle::before { left: -16%; right: -16%; top: 50%; height: 1px; }',
      '.eva-reticle::after { top: -16%; bottom: -16%; left: 50%; width: 1px; }',
      '@keyframes eva-spin { to { transform: rotate(360deg); } }',

      '/* === Giant unit-number watermark + vertical katakana (title style) === */',
      '.eva-watermark {',
      '  position: fixed;',
      '  right: 1vw; bottom: 9vh;',
      '  z-index: 53;',
      '  pointer-events: none;',
      '  font-family: Georgia, \'Times New Roman\', \'Songti SC\', serif;',
      '  font-size: 36vh; font-weight: 900; line-height: 0.8;',
      '  letter-spacing: -0.04em;',
      '  color: var(--dsw-alias-brand-primary);',
      '  opacity: 0.07;',
      '}',
      '.eva-vertical {',
      '  position: fixed;',
      '  right: 16px; top: 50%;',
      '  transform: translateY(-50%);',
      '  writing-mode: vertical-rl;',
      '  z-index: 53;',
      '  pointer-events: none;',
      '  font-family: Georgia, \'Songti SC\', serif;',
      '  font-size: 15px; font-weight: 700;',
      '  letter-spacing: 0.42em;',
      '  color: var(--dsw-alias-brand-primary);',
      '  opacity: 0.22;',
      '}',

      '/* === NERV telemetry status bar (bottom HUD strip) === */',
      '.eva-statusbar {',
      '  position: fixed;',
      '  left: 0; right: 0; bottom: 10px; height: 20px;',
      '  z-index: 79;',
      '  pointer-events: none;',
      '  display: flex; align-items: center; gap: 10px;',
      '  padding: 0 18px;',
      '  font-family: var(--ds-font-family-code);',
      '  font-size: 10px; letter-spacing: 0.14em;',
      '  color: var(--dsw-alias-label-tertiary);',
      '  background: rgba(0, 0, 0, 0.5);',
      '  border-top: 1px solid var(--dsw-alias-border-l3);',
      '}',
      '.eva-statusbar b { color: var(--dsw-alias-brand-primary); font-weight: 700; }',
      '.eva-dot {',
      '  width: 7px; height: 7px; flex: none;',
      '  background: var(--dsw-alias-brand-primary);',
      '  box-shadow: 0 0 6px var(--dsw-alias-brand-primary);',
      '  animation: eva-blink 1.1s steps(2) infinite;',
      '}',
      '@keyframes eva-blink { 50% { opacity: 0.15; } }',

      '/* === Lift the composer seat clear of the bottom HUD strip === */',
      '[data-composer-seat] { margin-bottom: 34px; }',

      '/* === Composer: armored entry-plug card, glows on focus === */',
      '[data-composer-card] {',
      '  border-radius: 0 !important;',
      '  border: 1px solid var(--dsw-alias-border-l3) !important;',
      '  box-shadow: inset 0 2px 0 var(--dsw-alias-brand-primary), 0 6px 24px rgba(0, 0, 0, 0.35) !important;',
      '}',
      '[data-composer-card]:focus-within {',
      '  border-color: var(--dsw-alias-brand-primary) !important;',
      '  box-shadow: inset 0 2px 0 var(--dsw-alias-brand-primary),',
      '    0 0 0 1px var(--dsw-alias-brand-primary),',
      '    0 0 26px var(--dsw-alias-button-primary-dimmed) !important;',
      '}',
      '[data-composer-card] textarea { caret-color: var(--dsw-alias-brand-primary); }',

      '/* === Sidebar: unit accent edge + squared, marked active rows === */',
      '[data-slot=\'sidebar\'] > * {',
      '  box-shadow: inset -2px 0 0 var(--dsw-alias-brand-primary);',
      '  /* shorten the column (height:100% + border-box ignores margin-bottom)',
      '     so the foot (settings button) clears the bottom HUD strip */',
      '  height: calc(100% - 34px) !important;',
      '}',
      '[role=\'treeitem\'] { border-radius: 0 !important; }',
      '[role=\'treeitem\'][aria-selected=\'true\'] {',
      '  box-shadow: inset 3px 0 0 var(--dsw-alias-brand-primary);',
      '}',

      '/* === Session header: brand keel line === */',
      '[data-slot=\'conversation.session.header\'] header {',
      '  box-shadow: inset 0 -2px 0 var(--dsw-alias-brand-primary);',
      '}',

      '/* === User bubble: chamfered armor plate with hard offset shadow === */',
      '[data-chat-flow-kind=\'user\'] [class*=\'_bubble\'] {',
      '  border-radius: 0 !important;',
      '  clip-path: polygon(0 0, calc(100% - 12px) 0, 100% 12px, 100% 100%, 0 100%);',
      '  filter: drop-shadow(3px 3px 0 var(--dsw-alias-button-primary-dimmed));',
      '}',

      '/* === Assistant stream: left data-rail; think rows get dashed rail === */',
      '[data-chat-flow-kind=\'assistant-step\'] [data-streaming] {',
      '  border-left: 2px solid var(--dsw-alias-button-primary-dimmed);',
      '  padding-left: 12px;',
      '}',
      '[data-variant=\'think\'] {',
      '  border-left: 2px dashed var(--dsw-alias-brand-primary);',
      '  padding-left: 10px;',
      '}',

      '/* === Tool calls: combat readout rails, state-colored === */',
      '[data-tool] { border-radius: 0 !important; }',
      '[data-tool][data-state=\'running\'] {',
      '  box-shadow: inset 3px 0 0 var(--dsw-alias-brand-primary);',
      '}',
      '[data-tool][data-state=\'ok\'] {',
      '  box-shadow: inset 3px 0 0 var(--dsw-alias-state-success-primary);',
      '}',
      '[data-tool][data-state=\'error\'] {',
      '  box-shadow: inset 3px 0 0 var(--dsw-alias-state-error-primary);',
      '}',

      '/* === Code blocks: square terminal panes with brand keel === */',
      '.md-code-block, pre.shiki {',
      '  border-radius: 0 !important;',
      '  border: 1px solid var(--dsw-alias-border-l2) !important;',
      '  box-shadow: inset 0 2px 0 var(--dsw-alias-brand-primary);',
      '}',

      '/* === Everything interactive goes square (mecha panels, no rounds) === */',
      'button, [role=\'button\'], [role=\'tab\'], [role=\'menuitem\'], [role=\'option\'] {',
      '  border-radius: 0 !important;',
      '}',
      'input, textarea, select { border-radius: 0 !important; }',
      '[role=\'dialog\'] {',
      '  border-radius: 0 !important;',
      '  border: 1px solid var(--dsw-alias-border-l3) !important;',
      '  box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.6), 0 24px 64px rgba(0, 0, 0, 0.5),',
      '    inset 0 2px 0 var(--dsw-alias-brand-primary) !important;',
      '}',
    ].join('\n')

    /* ------------------------------------------------------------------ */
    /* Sidebar switcher + mecha banner (React, no JSX)                     */
    /* ------------------------------------------------------------------ */
    function EvaSwitcher(props) {
      var activeId = React.useSyncExternalStore(props.subscribe, props.getActiveId)
      var unit = props.units[activeId] || props.units[Object.keys(props.units)[0]]
      var accent = unit.palette.brand
      var dim = unit.palette.brandDim
      var label = unit.palette.labelPrimary
      var MONO = "'SF Mono','JetBrains Mono',Consolas,monospace"
      var SERIF = "Georgia,'Times New Roman','Songti SC',serif"

      if (!props.wide) {
        // Collapsed rail: three chamfered unit markers.
        return React.createElement('div', {
          'data-eva-switcher': '',
          style: {
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            gap: 6, padding: '8px 0',
          },
        }, Object.keys(props.units).map(function (id) {
          var u = props.units[id]
          var on = id === activeId
          return React.createElement('button', {
            key: id,
            'data-eva-unit': id,
            title: u.label,
            onClick: function () { props.setTheme(id) },
            style: {
              width: 16, height: 16, borderRadius: 0,
              clipPath: 'polygon(0 0, calc(100% - 5px) 0, 100% 5px, 100% 100%, 5px 100%, 0 calc(100% - 5px))',
              border: on ? '2px solid ' + u.palette.labelPrimary : '1px solid rgba(255,255,255,0.35)',
              background: u.palette.brand,
              cursor: 'pointer', padding: 0,
              opacity: on ? 1 : 0.55,
              boxShadow: on ? '0 0 8px ' + u.palette.brand : 'none',
            },
          })
        }))
      }

      return React.createElement('div', {
        'data-eva-switcher': '',
        style: {
          display: 'flex', flexDirection: 'column', gap: 8,
          padding: '8px 12px 6px',
        },
      }, [
        // EVA title block: heavy serif + NERV telemetry row
        React.createElement('div', {
          key: 'head',
          style: { display: 'flex', flexDirection: 'column', gap: 3, padding: '0 2px' },
        }, [
          React.createElement('div', {
            key: 'title',
            'data-eva-title': '',
            style: {
              fontFamily: SERIF, fontWeight: 900, fontSize: 22, lineHeight: '22px',
              letterSpacing: '0.01em', color: label,
              textShadow: '0 0 14px ' + dim,
            },
          }, 'EVANGELION'),
          React.createElement('div', {
            key: 'sub',
            style: {
              display: 'flex', alignItems: 'center', gap: 6,
              fontFamily: MONO, fontSize: 9, letterSpacing: '0.22em',
              color: unit.palette.labelTertiary,
            },
          }, [
            React.createElement('span', { key: 'dot', className: 'eva-dot' }),
            React.createElement('span', { key: 'txt' }, 'NERV // TACTICAL INTERFACE'),
          ]),
        ]),
        React.createElement('div', {
          key: 'banner',
          'data-eva-banner': '',
          style: {
            position: 'relative', overflow: 'hidden', borderRadius: 0,
            height: 118, border: '1px solid ' + accent,
            boxShadow: '0 0 14px ' + dim + ', inset 0 0 22px rgba(0, 0, 0, 0.55)',
            clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 10px), calc(100% - 10px) 100%, 0 100%)',
            background: unit.palette.layer1,
          },
        }, [
          React.createElement('img', {
            key: 'img',
            'data-eva-banner-img': '',
            src: unit.image,
            alt: unit.label,
            style: { width: '100%', height: '100%', objectFit: 'cover', display: 'block' },
          }),
          // giant serif unit number, EVA title-card style
          React.createElement('div', {
            key: 'num',
            style: {
              position: 'absolute', right: 6, top: 0,
              fontFamily: SERIF, fontWeight: 900, fontSize: 62, lineHeight: '64px',
              letterSpacing: '-0.05em', color: label,
              textShadow: '0 0 10px rgba(0, 0, 0, 0.9), 0 0 22px ' + dim,
              opacity: 0.92,
            },
          }, unit.short),
          // unit classification chip (TEST TYPE / PROTOTYPE / ...)
          React.createElement('div', {
            key: 'type',
            style: {
              position: 'absolute', left: 0, top: 8,
              padding: '2px 8px 2px 6px',
              fontFamily: MONO, fontSize: 9, letterSpacing: '0.2em',
              color: label, background: 'rgba(0, 0, 0, 0.6)',
              borderLeft: '3px solid ' + accent,
            },
          }, unit.type),
          // hazard stripe strip across the banner foot
          React.createElement('div', {
            key: 'hazard',
            style: {
              position: 'absolute', left: 0, right: 0, bottom: 0, height: 16,
              background: 'repeating-linear-gradient(45deg, ' + accent + ' 0 8px, rgba(0, 0, 0, 0.55) 8px 16px)',
              opacity: 0.9,
            },
          }),
          // unit designation, monospace
          React.createElement('div', {
            key: 'designation',
            style: {
              position: 'absolute', left: 8, bottom: 1,
              fontFamily: MONO, fontSize: 11, fontWeight: 700,
              letterSpacing: '0.14em', color: label,
              textShadow: '0 0 6px rgba(0, 0, 0, 0.9)',
            },
          }, 'UNIT-' + unit.short + ' · ' + unit.label),
        ]),
        // hazard divider above the unit buttons
        React.createElement('div', {
          key: 'tape',
          style: {
            height: 5,
            background: 'repeating-linear-gradient(-45deg, ' + accent + ' 0 8px, rgba(0, 0, 0, 0.6) 8px 16px)',
            opacity: 0.85,
          },
        }),
        React.createElement('div', {
          key: 'switcher',
          style: { display: 'flex', gap: 6 },
        }, Object.keys(props.units).map(function (id) {
          var u = props.units[id]
          var on = id === activeId
          return React.createElement('button', {
            key: id,
            'data-eva-unit': id,
            onClick: function () { props.setTheme(id) },
            title: u.label,
            style: {
              flex: 1, padding: '6px 0', borderRadius: 0,
              clipPath: 'polygon(0 0, calc(100% - 7px) 0, 100% 7px, 100% 100%, 7px 100%, 0 calc(100% - 7px))',
              border: on ? '1px solid ' + u.palette.brand : '1px solid rgba(255,255,255,0.16)',
              background: on ? u.palette.brandDim : 'transparent',
              color: on ? u.palette.labelPrimary : u.palette.labelTertiary,
              fontFamily: MONO, fontSize: 11, lineHeight: '15px', cursor: 'pointer',
              fontWeight: on ? 700 : 400, letterSpacing: '0.06em',
              boxShadow: on ? '0 0 10px ' + dim : 'none',
            },
          }, u.label)
        })),
      ])
    }

    /* ------------------------------------------------------------------ */
    /* Plugin body                                                         */
    /* ------------------------------------------------------------------ */
    function apply(ctx) {
      var disposers = []
      var unitIds = Object.keys(UNITS)

      // 1. Register the three unit themes.
      unitIds.forEach(function (id) {
        disposers.push(ctx.theme.register({
          id: id,
          colorScheme: 'dark',
          tokens: buildTokens(UNITS[id].palette),
        }))
      })

      // 2. EVA is the enforced look: the durable Appearance preference can
      //    land asynchronously AFTER this apply (settings adopt resets the
      //    active theme back to light/dark), so on every theme/change we
      //    re-assert Unit-01 whenever the active theme is not one of ours.
      var ensureEva = function () {
        if (UNITS[ctx.theme.getTheme().active.id] === undefined) {
          ctx.theme.setTheme('eva-unit01')
        }
      }

      // 3. Backdrop <style>: rewritten per active unit on theme/change.
      var style = document.createElement('style')
      style.setAttribute('data-plugin', 'dsh-eva-theme-plugin')
      style.setAttribute('data-plugin-css', 'eva-theme-backdrop')
      document.head.append(style)

      var applyBackdrop = function () {
        var unit = UNITS[ctx.theme.getTheme().active.id]
        style.textContent = unit === undefined ? '' : buildBackdropCss(unit)
      }
      // Listener is registered before any setTheme: ensureEva()'s setTheme
      // emits theme/change synchronously, which this handler paints with.
      var offTheme = ctx.on('theme/change', function () {
        applyBackdrop()
        applyHud()
        ensureEva()
      })

      // 4. Mecha chrome: static style sheet + decorative HUD elements. All
      //    colors come from the active unit's tokens, so they re-tint on
      //    theme/change with no JS work.
      var mecha = document.createElement('style')
      mecha.setAttribute('data-plugin', 'dsh-eva-theme-plugin')
      mecha.setAttribute('data-plugin-css', 'eva-theme-mecha')
      mecha.textContent = MECHA_CSS
      document.head.append(mecha)
      var chrome = document.createElement('div')
      chrome.setAttribute('data-eva-chrome', '')
      chrome.innerHTML =
        '<div class="eva-bracket eva-bracket-tl"></div>'
        + '<div class="eva-bracket eva-bracket-tr"></div>'
        + '<div class="eva-bracket eva-bracket-bl"></div>'
        + '<div class="eva-bracket eva-bracket-br"></div>'
        + '<div class="eva-scanlines"></div>'
        + '<div class="eva-sweep"></div>'
        + '<div class="eva-tape"></div>'
        + '<div class="eva-reticle"><i></i><i></i><i></i></div>'
      document.body.append(chrome)

      // 5. Unit-dependent HUD readouts: giant number watermark, vertical
      //    katakana, NERV telemetry status bar. Text is rewritten on every
      //    theme/change alongside the backdrop.
      var watermark = document.createElement('div')
      watermark.className = 'eva-watermark'
      var vertical = document.createElement('div')
      vertical.className = 'eva-vertical'
      vertical.textContent = 'エヴァンゲリオン'
      var status = document.createElement('div')
      status.className = 'eva-statusbar'
      document.body.append(watermark)
      document.body.append(vertical)
      document.body.append(status)

      function applyHud() {
        var unit = UNITS[ctx.theme.getTheme().active.id]
        if (unit === undefined) {
          return
        }
        watermark.textContent = unit.short
        status.innerHTML = '<span class="eva-dot"></span><span>NERV // EVANGELION UNIT-'
          + unit.short + ' 「' + unit.label + '」 // ' + unit.type
          + ' // <b>A.T.FIELD ACTIVE</b> // SYNC RATIO ' + unit.sync
          + ' // POWER: INTERNAL</span>'
      }

      // 5. Sidebar switcher + mecha banner (footer actions, above Settings).
      ctx.slots.inject('sidebar.footer.action', function () {
        return ctx.slots.register({
          name: 'sidebar.footer.action',
          id: 'eva-theme-switcher',
          order: 20,
          inject: function () {
            return {
              units: UNITS,
              getActiveId: function () { return ctx.theme.getTheme().active.id },
              subscribe: function (cb) { return ctx.on('theme/change', cb) },
              setTheme: function (id) { ctx.theme.setTheme(id) },
            }
          },
        }, EvaSwitcher)
      })

      // First paint: all DOM (backdrop style, HUD readouts) exists by now.
      // ensureEva()'s setTheme re-fires theme/change synchronously, which the
      // listener above repaints with — safe to call unconditionally.
      applyBackdrop()
      applyHud()
      ensureEva()

      return function dispose() {
        disposers.forEach(function (d) { d() })
        offTheme()
        style.remove()
        mecha.remove()
        chrome.remove()
        watermark.remove()
        vertical.remove()
        status.remove()
      }
    }

    exports.name = name
    exports.inject = inject
    exports.apply = apply
    return module.exports
  },
})
