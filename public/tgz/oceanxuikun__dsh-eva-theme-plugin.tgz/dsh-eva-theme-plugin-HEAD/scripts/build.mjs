/* Build: regenerate client.js from client.template.js by inlining the three
 * unit wallpapers (assets/*.webp) as base64 data URIs. Run before packing or
 * installing after replacing any image in assets/. */
import { readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const b64 = (file) => readFileSync(join(root, 'assets', file)).toString('base64')

let src = readFileSync(join(root, 'client.template.js'), 'utf8')
const replacements = [
  ['__UNIT01_B64__', 'unit01.webp'],
  ['__UNIT00_B64__', 'unit00.webp'],
  ['__UNIT02_B64__', 'unit02.webp'],
]
for (const [placeholder, file] of replacements) {
  if (!src.includes(placeholder)) {
    throw new Error(`build: placeholder ${placeholder} not found in client.template.js`)
  }
  src = src.replace(placeholder, b64(file))
}
writeFileSync(join(root, 'client.js'), src)
console.log(`dsh-eva-theme-plugin: client.js rebuilt (${(src.length / 1024).toFixed(0)} KB)`)
