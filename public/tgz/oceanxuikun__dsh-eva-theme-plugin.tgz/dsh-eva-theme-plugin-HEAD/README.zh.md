# dsh-eva-theme-plugin

[English](README.md) | 中文

一个用户级客户端插件，为 DeepSeek Harness Web GUI 提供三套《新世纪福音战士》(EVA) 机体主题——**初号機 (Unit-01)**、**零号機 (Unit-00)**、**弐号機 (Unit-02)**——每套都会重新着色**所有**页面元素，并在侧边栏展示当前机体的图片。完全以插件方式实现：**不修改任何 harness 源代码**。

## 功能

- **三套可切换主题**，均为深色系，每套都带完整的 `--dsw-*` token 集（86 个），切换时**所有**元素都会重新着色——面板、文字、按钮、状态、气泡、输入栏、侧边栏、滚动条、代码块、菜单：
  - `eva-unit01` 初号機 —— 紫色机身 (#b96bff)，霓虹绿点缀
  - `eva-unit00` 零号機 —— 蓝灰机身，黄色点缀 (#ffc233)
  - `eva-unit02` 弐号機 —— 深红机身，橙色点缀 (#ff4b3a)
- **机体壁纸背景**（每套内嵌 base64 图），靠右展示在应用后方，左侧保护渐变保证聊天区文字清晰，图片透过半透明面板隐约可见。
- **侧边栏切换器**（展开时）：当前机体的机甲横幅 + 三枚机体按钮，注入侧边栏的 `sidebar.footer.action` 插槽；收起时显示三个圆点。
- **EVA 为强制外观**：每次 `theme/change` 时，只要当前主题不是三套机体之一，插件就会重新断言为初号機（这也吸收了启动时 settings 异步 adopt 把主题重置回亮/暗色的问题）。三个机体按钮就是主题控制入口。
- **机甲风格装饰**（由 token 驱动，随机体自动换色）：
  - 视口顶部的警示条纹
  - 屏幕四角的 HUD 瞄准框
  - 微扫描线 + 暗角叠加（机甲监视器质感）
  - 背景中的蓝图网格（透过半透明面板可见）
  - 输入卡直角机甲边框 + 机体色顶边、标题栏机体色发光下划线、侧边栏机体色描边
  - 侧边栏切换器：切角按钮、等宽字体间距标签、横幅上的警示条纹 + `UNIT-0X` 编号

## 效果预览

### 初号機 (Unit-01)

![Unit-01](assets/screenshot01.png)

### 零号機 (Unit-00)

![Unit-00](assets/screenshot00.png)

### 弐号機 (Unit-02)

![Unit-02](assets/screenshot02.png)

## 文件

| 路径 | 作用 |
| --- | --- |
| `package.json` | 包标识 + `dsh.client` 声明 + exports |
| `lib/index.js` | 宿主端入口（无操作） |
| `client.js` | 浏览器插件包：主题注册 + 背景 + 侧边栏切换器 |
| `client.template.js` | 可读的插件包源码（base64 占位符） |
| `assets/unit00.webp` · `unit01.webp` · `unit02.webp` | 内嵌机体图（webp） |
| `assets/screenshot00.png` · `screenshot01.png` · `screenshot02.png` | 效果预览截图（Unit-00/01/02） |

## 安装（使用 `dsh plugin`）

本包是 profile **bundle**（声明了 `dsh.bundle.patch`），因此用标准插件命令安装即可——无需手动软链接或修改补丁文件：

```sh
# 在 harness 仓库目录下执行：
pnpm dsh plugin --profile web add https://github.com/oceanxuikun/dsh-eva-theme-plugin.git
```

该命令会在 web profile 中执行 `pnpm add`，把包链接到
`~/.dsh/profiles/web/node_modules`，并自动把 `dsh-eva-theme-plugin` 追加到
profile `package.json` 的 `dsh.profile.bundles`。之后重启 `dsh web` 并刷新页面即可。

替换图片或修改模板后需要重新构建：

```sh
pnpm run build   # 从 client.template.js + assets/ 重新生成 client.js
```

## 卸载

```sh
pnpm dsh plugin --profile web remove dsh-eva-theme-plugin
```

然后重启 `dsh web` 并刷新。

## 致谢

图片素材：wallhaven.cc 上的同人图（见上方说明），仅作本地个人 GUI 背景使用；《新世纪福音战士》© Khara / GAINAX。
