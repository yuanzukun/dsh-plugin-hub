# dsh-reply-forge v3

**Forge what the model sees.**

Edit any reply in a live DSH session — or any thinking block behind it — and from the very
next turn, **your version is the conversation history**. The model doesn't just display your
words; it *remembers* them. No restart. No refresh-and-it's-gone. No re-reading a log to
check whether it took.

> 中文说明请见 [README.md](./README.md)；完整使用手册见
> [使用说明.md](./使用说明.md)（Chinese）

[![license](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![node](https://img.shields.io/badge/node-%3E%3D18-brightgreen.svg)](package.json)
[![tests](https://img.shields.io/badge/tests-233%20%2F%2013%20suites-brightgreen.svg)](#tests)
[![platform](https://img.shields.io/badge/platform-Windows%20x64-lightgrey.svg)](https://github.com/kinggod899/dsh-reply-forge-v3)

A plugin for the DSH desktop app (DeepSeek Harness). Every assistant message gets a
**Forge** button — hover, click, rewrite the reply or the hidden chain-of-thought, write
it back. Everything after that turn reads what you wrote.

## Three generations, one idea

| | v1 | v2 | **v3** |
|---|---|---|---|
| What it edits | what's on screen | the session log on disk | **the live session object** |
| Visible to the model | no | yes, after restart | **yes, immediately** |
| Thinking chains | no | no | **yes** |
| Mechanism | localStorage overlay | rewrite `.jsonl.zstd` | message projection |

v3 keeps v2's disk rewrite as its **fallback branch**: session alive in memory → write the
live session (takes effect at once); not in memory → rewrite the log (takes effect on next
load).

The other generations live in their own repos and can coexist (separate plugin ids and
prefixes) — just never all three at once, they share one message action bar:

- **v2 (disk-only rewrite)**: https://github.com/kinggod899/dsh-reply-forge-v2
- v1 (localStorage overlay): the first take, its story is told in v2's docs

## Quick start

1. Hover any assistant reply → hit **Forge**.
2. In the editor: pick a target (any editable block in the session — including folded-away
   thinking blocks you can't click on screen) and a write mode (default: auto).
3. Rewrite, hit **Forge**. A confirmation spells out exactly what will happen; then it's
   done and visible.

Two exits: **Render locally** (Ctrl+Enter — this page only, invisible to the model,
reversible) and **Forge** (the model's copy — immediate online or on-reload via disk,
**irreversible**). Full UI reference, the write-mode table and troubleshooting are in
[使用说明.md](./使用说明.md) (Chinese docs; English docs are on the roadmap).

## Will disabling the plugin corrupt my sessions?

**Not if the markers are right** — but that "not" comes with a precondition.

`reply-forge/patch` is an event type the host doesn't know. The persistence gate
`validateStoredEvents` (`@deepseek-ai/dsh-session-persistence`) refuses the **entire
log** — session won't open — when an unknown event type arrives without `ignorable: true`
on its envelope. The projection layer (plugin present) just skips unknown types: no error,
the forge silently falls back to the original text. The host's own comment spells it out
(`known-event-types.js`):

> The persisted `SessionEvent.ignorable` marker is the compatibility mechanism.

Three cases: **markers right + cold start** → session opens fine, forges fall back
silently; **missing markers** (early writes or a torn write) → gate refuses, repair tool
fixes; **hot-unload while DSH is running** → the host throws
`session message projection "reply-forge/patch" was removed` (normal usage always
restarts DSH, which replays everything cleanly — you'll never hit this).

v3's P0 work is making "markers right" structurally true: both write paths (online and
disk) go through a shim that stamps `ignorable: true` before the host persists anything;
every real write re-verifies the session's write handle (`WRITER_NOT_ROUTED` safely falls
back to disk, `APPEND_UNSAFE` is always rejected — full failure-code table in
[PLAN.md](./PLAN.md)); the persistence loop (create → append → flush → re-read → gate
opens) is covered by tests against the real host.

**If a session is already broken**: quit DSH, double-click `修复会话.bat` for a read-only
diagnosis, then `修复会话.bat apply` to stamp the markers — backup first, only toxic lines
touched, self-read verified after write, auto-revert on failure, unreparable damage
reported plainly instead of forced.

### Acknowledgments

[dsh-chat-thinking-editor](https://github.com/yumiao-dev/dsh-chat-thinking-editor) is an
important **reference** for this plugin — the earliest explorer of thought-chain editing
in the DSH ecosystem, whose live-edit goal and unusual honesty toward users (its PR notes
flatly state that edited sessions may become unreadable after uninstall) taught us a lot.
The difference is technical: it anchors edits on `assistant/message` with `surfaceOp`,
and the host still surface-validates those events when the plugin is absent — failing
that, it throws. v3 went the other way: private event + same-type projection +
`ignorable` marker (above). No hierarchy — just different trade-offs. Standing on its
shoulders, we pushed "uninstalls cleanly" a bit further.

## Install

Prerequisites: the DSH desktop app, and **Node.js** (the four `.bat` tools edit static
config with it — they probe PATH, `C:\Program Files\nodejs`,
`%LOCALAPPDATA%\Programs\nodejs`, and **DSH's bundled node**
(`%USERPROFILE%\.dsh\dsh-runtimes\...\node\bin\node.exe` — it ships with DSH)). No Node
either? The bats print the full manual four steps (package.json, cordis.patch.yml,
junction) and you follow them by hand. The plugin itself runs inside DSH — no extra
runtime.

Double-click `安装插件.bat`, then **fully quit and restart DSH** (static config needs the
restart to load).

The script does exactly three things: create the junction, write `bundles` and
`dependencies` into `package.json`, hand-register the lockfile entry. It never runs
`pnpm install` — doing that under a running DSH wipes `node_modules`.

By default the installer drops the two earlier generations from `bundles` (they share
one message action bar). Their deps and links stay; re-enable them any time with their
own `启用插件.bat`, or keep them side by side for comparison with
`node scripts/install.mjs --keep-v2 --keep-v1`.

Other scripts:

| Script | What it does |
|---|---|
| `安装插件.bat` | first install (junction, deps, lockfile, bundles) |
| `启用插件.bat` | put the plugin back into `bundles` when disabled |
| `关闭插件.bat` | remove from `bundles` — one-click rollback when DSH misbehaves |

All three only touch static config. None of them run `pnpm`. None of them delete your
overrides. All of them need a DSH restart afterwards (see above).

## How it works

The host refuses to let `assistant/message` carry a surface replacement —
`assertSourceEventReferences` demands that a replace event cover every shadowed node with
`sourceEventSeqs`, and the very same function hard-forbids `assistant/message` from
carrying `sourceEventSeqs`. The two constraints are mutually exclusive; it always throws.
The full argument, with host source evidence, is in [PLAN.md](./PLAN.md).

The door the host *does* leave open is **message projection**: pure functions registered
per event type, deciding at fold time what the model sees for a given seq. So v3 appends
one private event, `reply-forge/patch` (pure log record, never enters the surface), and a
same-type projection rewrites the target message.

- No `surfaceOp` / `sourceEventSeqs` → no surface validation is ever triggered;
- Plugin disabled → events are skipped silently, forges fall back to the original text,
  sessions still open as long as the markers are intact;
- Forges survive restarts — session restore replays the registered projection list, and
  this plugin registers in `apply()`;
- Online writes end up in `session.v4.jsonl.zstd` just like disk writes, so both are
  equally durable. But the persistence layer validates event types — unknown types must
  carry `ignorable: true` or the whole log is refused, and `Session.append()` won't take
  that field, so v3 wraps the write handle with a shim that stamps it before the host
  persists (see "Will disabling the plugin corrupt my sessions?" above).

## Tests

```bash
node tests/projection.test.mjs   # mechanism on the real dsh-session host (SKIP if no host)
node tests/persistence.test.mjs  # P0: real-host persistence loop, create→append→flush→re-read→gate
node tests/ignorable.test.mjs    # P0: ignorable shim + per-session write-handle verification
node tests/live.test.mjs         # online layer validation and failure codes
node tests/patch.test.mjs        # patch data layer
node tests/routes.test.mjs       # routing layer
node tests/client.test.mjs       # client artifact
node tests/record.test.mjs       # staleness heuristics (root cause of the new-session stall)
node tests/session-write.test.mjs
node tests/session-log.test.mjs
node tests/session-repair.test.mjs  # damaged-session repair tool
node tests/build.test.mjs
node tests/session-anatomy.test.mjs
```

**233 assertions in 13 suites** — including P0's `ignorable` (28), the real-host
persistence loop (5) and `session-repair` (15). **21 of them** (`projection` 13 +
`persistence` 5 + `ignorable` 3) need the host package `@deepseek-ai/dsh-session`
installed; without it they SKIP (not fail), so the release zip stays green on machines
without DSH — with a host present, all 233 run. Or just run the gate:

```bash
node --test "tests/*.test.mjs"
npm test
```

After touching `.dsh-plugin/client/*.mjs` you must rebuild the artifact
(`node scripts/build-client.mjs` — a self-written inliner, zero dependencies, no JSX, no
export default); `build.test.mjs` asserts artifact and source stay byte-identical
(`npm run check`).

## CLI (offline rewriting)

Don't feel like the UI? Edit the files directly (quit DSH first):

```bash
node scripts/forge-session.mjs --session <id> --list
node scripts/forge-session.mjs --session <id> --list --kind reasoning   # list thinking blocks
node scripts/forge-session.mjs --session <id> --seq 42 --block-index 1 \
  --kind text --text "the rewritten reply" --dry-run
```

`--kind` takes `text` / `reasoning` / `both` (default `text`); `--list` filters by it —
so grab a thinking block's `seq`/`blockIndex` with `--list --kind reasoning` before
forging.

## Real-machine diagnostics

`scripts/diag-focus.mjs` — unattended reproduction of the classic "no cursor after save"
bug: boots the real host in Node (mirroring the app's boot recipe), opens the page in
headless Edge via CDP, runs "Forge → render locally", and samples `activeElement` plus
focusin/focusout trajectories the whole way. Run it with
`CODEBUDDY_SAFE_DELETE_ENABLED=0 node scripts/diag-focus.mjs` (the safe-delete shim
otherwise blocks the host's lock-file cleanup).

## Version history

- **3.1.0** — three tracks:
  - *Usability*: fixed the new-session stall ("no locatable assistant text" on every new
    session — the online empty snapshot was cached as terminal, never re-read); write mode
    is now an explicit choice (auto / online-only / disk-only).
  - *P0 safety*: `ignorable: true` now covers both write paths (the shim stamps before
    host persistence), verified by the real-host persistence loop; new per-session
    write-handle verification (`WRITER_NOT_ROUTED` falls back to disk safely,
    `APPEND_UNSAFE` always rejected); new `修复会话.bat` (diagnose first, backup, atomic
    write, self-read verify, auto-revert on failure).
  - *Focus fixes (real-machine bugs, four rounds) + a fifth*: after saving a forge, the
    host composer wouldn't take keyboard input — fixed by closing the editor (returning focus
    to the composer) before removing the message block; round two found the host
    composer is unfocusable while inert (`contenteditable=false`, `focus()` a no-op), so
    the result is reported honestly ("focus returned" / "composer not editable yet"),
    with a focus sentry and the `__dshReplyForgeV3.focus()` debug namespace; round three
    caught the async-only path (button disabled mid-write, Chromium drops focus to
    `<body>`) — snapshot before disabling, restore after success, never steal the user's
    deliberate focus moves; round four identified the Electron native `window.confirm` as
    an OS-level modal that eats window keyboard focus (all DOM focus green, no typing) —
    replaced by a two-step in-page confirmation; the fifth fixed post-restart
    `STALE_TARGET` rejections (disk reads went around the projection, so `expectText`
    compared against pre-projection text) — reads now go through the projection,
    disk rewrites of already-forged blocks are refused (`PATCHED_TARGET`, projection
    wins), and one automatic stale re-read retry remains as a backstop. Client suite: 57;
    gate: 233/13, all green, real-machine re-verified by the author.
- **3.0.0** — first release: online writes via message projection with disk fallback,
  editable thinking chains, target picker.

## Friends

- [dsh-chat-thinking-editor](https://github.com/yumiao-dev/dsh-chat-thinking-editor) —
  the ecosystem's earliest thought-chain editor, our reference (see Acknowledgments)
- [dsh-reply-forge-v2](https://github.com/kinggod899/dsh-reply-forge-v2) — the previous
  generation: disk-only rewrite (needs a restart)

## License

MIT
