import { describe, expect, it } from 'vitest'
import {
  DEFAULT_REASONING_EFFORTS,
  inferReasoningSupport,
  inferVisionSupport,
  matchModel,
  normalizeModelId,
} from '../src/matcher'
import type { NormalizedModelMeta } from '../src/types'

describe('Custom Provider Model Matcher & Capability Detector', () => {
  const sampleMetaMap = new Map<string, NormalizedModelMeta>([
    [
      'gpt-4o',
      {
        id: 'gpt-4o',
        name: 'GPT-4o',
        contextWindow: 128000,
        maxTokens: 16384,
        inputModalities: ['text', 'image'],
        supportsReasoning: false,
      },
    ],
    [
      'claude-3-5-sonnet',
      {
        id: 'claude-3-5-sonnet',
        name: 'Claude 3.5 Sonnet',
        contextWindow: 200000,
        maxTokens: 8192,
        inputModalities: ['text', 'image'],
        supportsReasoning: false,
      },
    ],
    [
      'deepseek-reasoner',
      {
        id: 'deepseek-reasoner',
        name: 'DeepSeek-R1',
        contextWindow: 64000,
        maxTokens: 8192,
        inputModalities: ['text'],
        supportsReasoning: true,
        reasoningEfforts: DEFAULT_REASONING_EFFORTS,
      },
    ],
    [
      'stealth/ox-alpha',
      {
        id: 'stealth/ox-alpha',
        name: 'Ox Alpha',
        contextWindow: 1048576,
        maxTokens: 131072,
        inputModalities: ['text', 'image'],
        supportsReasoning: true,
        reasoningEfforts: { off: null, low: 'low', high: 'high', max: 'max' },
      },
    ],
    [
      'meta/muse-spark-1.2-contributor',
      {
        id: 'meta/muse-spark-1.2-contributor',
        name: 'Meta: Muse Spark 1.2 Contributor',
        contextWindow: 1048576,
        maxTokens: 131072,
        inputModalities: ['text', 'image'],
        supportsReasoning: true,
        reasoningEfforts: { off: null, minimal: 'minimal', low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh' },
      },
    ],
  ])

  it('normalizes model id with vendor prefixes', () => {
    expect(normalizeModelId('openai/gpt-4o')).toBe('gpt-4o')
    expect(normalizeModelId('anthropic/claude-3-5-sonnet')).toBe('claude-3-5-sonnet')
    expect(normalizeModelId('meta/muse-spark-1.2-contributor')).toBe('muse-spark-1.2-contributor')
    expect(normalizeModelId('stealth/ox-alpha')).toBe('ox-alpha')
  })

  it('matches model snapshot with date suffix', () => {
    const matched = matchModel('gpt-4o-2024-11-20', sampleMetaMap)
    expect(matched).toBeDefined()
    expect(matched?.contextWindow).toBe(128000)
    expect(matched?.inputModalities).toContain('image')
  })

  it('matches OpenRouter models with -free suffix and vendor prefixes', () => {
    // 匹配 ox-alpha-free 到 stealth/ox-alpha
    const matchedOx = matchModel('ox-alpha-free', sampleMetaMap)
    expect(matchedOx).toBeDefined()
    expect(matchedOx?.contextWindow).toBe(1048576)
    expect(matchedOx?.supportsReasoning).toBe(true)
    expect(matchedOx?.inputModalities).toContain('image')

    // 匹配 muse-spark-1.2-contributor 到 meta/muse-spark-1.2-contributor
    const matchedMuse = matchModel('muse-spark-1.2-contributor', sampleMetaMap)
    expect(matchedMuse).toBeDefined()
    expect(matchedMuse?.contextWindow).toBe(1048576)
    expect(matchedMuse?.supportsReasoning).toBe(true)
    expect(matchedMuse?.inputModalities).toContain('image')
  })

  it('detects vision support by heuristic rules', () => {
    expect(inferVisionSupport('qwen2.5-vl-72b-instruct')).toBe(true)
    expect(inferVisionSupport('gpt-4o-mini')).toBe(true)
    expect(inferVisionSupport('deepseek-chat')).toBe(false)
  })

  it('detects reasoning capability by heuristic rules', () => {
    expect(inferReasoningSupport('deepseek-r1-distill-qwen-32b')).toBe(true)
    expect(inferReasoningSupport('o3-mini')).toBe(true)
    expect(inferReasoningSupport('qwq-32b')).toBe(true)
    expect(inferReasoningSupport('gpt-4o')).toBe(false)
  })
})
