import { afterEach, describe, expect, it, vi } from 'vitest'
import { discoverAndEnrichModels } from '../src/discovery'
import { ModelsDevClient } from '../src/models-dev'

describe('Discovery E2E Mock Test', () => {
  afterEach(() => {
    vi.restoreAllMocks()
    vi.unstubAllGlobals()
  })

  it('fetches endpoint models and auto-populates context and clean names', async () => {
    const mockEndpointFetch = vi.fn().mockImplementation((url: string) => {
      if (url.includes('openrouter.ai')) {
        return Promise.resolve({
          ok: true,
          json: async () => ({
            data: [
              {
                id: 'stealth/ox-alpha',
                name: 'Ox Alpha',
                context_length: 1048576,
                top_provider: { max_completion_tokens: 131072 },
                architecture: { input_modalities: ['text', 'image'] },
                reasoning: { mandatory: true, supported_efforts: ['max', 'high', 'low'] },
              },
              {
                id: 'meta/muse-spark-1.2-contributor',
                name: 'Meta: Muse Spark 1.2 Contributor',
                context_length: 1048576,
                architecture: { input_modalities: ['text', 'image'] },
                supported_parameters: ['reasoning', 'reasoning_effort'],
              },
            ],
          }),
        })
      }

      if (url.includes('litellm') || url.includes('/models.dev/')) {
        return Promise.resolve({
          ok: true,
          json: async () => ({
            'gpt-4o': {
              max_input_tokens: 128000,
              max_output_tokens: 16384,
              supports_vision: true,
            },
            'deepseek-reasoner': {
              max_input_tokens: 64000,
              max_output_tokens: 8192,
              supports_thinking: true,
            },
          }),
        })
      }

      return Promise.resolve({
        ok: true,
        json: async () => ({
          data: [
            { id: 'gpt-4o', name: '   ' }, // 模拟空字符串 name
            { id: 'deepseek-reasoner', name: '' },
            { id: 'ox-alpha-free' },
            { id: 'muse-spark-1.2-contributor' },
            { id: 'qwen2.5-vl-72b-instruct' },
          ],
        }),
      })
    })

    vi.stubGlobal('fetch', mockEndpointFetch)

    const client = new ModelsDevClient()

    const results = await discoverAndEnrichModels(
      { baseURL: 'https://api.my-gateway.com/v1', apiKey: 'sk-test' },
      client,
    )

    expect(results).toHaveLength(5)

    const ox = results.find(m => m.id === 'ox-alpha-free')
    expect(ox?.contextWindow).toBe(1048576)

    const muse = results.find(m => m.id === 'muse-spark-1.2-contributor')
    expect(muse?.contextWindow).toBe(1048576)

    const gpt4o = results.find(m => m.id === 'gpt-4o')
    expect(gpt4o?.contextWindow).toBe(128000)
    expect(gpt4o?.maxTokens).toBe(16384)
    // 确保空字符串被清洗，若有非空有效字符串则长度必然大于0（符合 Zod min(1) 校验）
    if (gpt4o?.name !== undefined) {
      expect(gpt4o.name.trim().length).toBeGreaterThan(0)
    }

    const r1 = results.find(m => m.id === 'deepseek-reasoner')
    expect(r1?.contextWindow).toBe(64000)
    if (r1?.name !== undefined) {
      expect(r1.name.trim().length).toBeGreaterThan(0)
    }

    const qwen = results.find(m => m.id === 'qwen2.5-vl-72b-instruct')
    expect(qwen?.contextWindow).toBe(131072)
    if (qwen?.name !== undefined) {
      expect(qwen.name.trim().length).toBeGreaterThan(0)
    }
  })
})
