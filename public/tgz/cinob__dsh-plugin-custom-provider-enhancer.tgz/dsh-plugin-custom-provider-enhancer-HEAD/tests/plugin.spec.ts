import { describe, expect, it, vi } from 'vitest'
import { apply } from '../src/index'

describe('Plugin Apply Hooks Integration Test', () => {
  it('enriches resolveModelInfo and settings.mutate with OpenRouter metadata', async () => {
    const mockFetch = vi.fn().mockImplementation((url: string) => {
      if (url.includes('openrouter.ai')) {
        return Promise.resolve({
          ok: true,
          json: async () => ({
            data: [
              {
                id: 'stealth/ox-alpha',
                name: 'Ox Alpha',
                context_length: 1048576,
                top_provider: { max_completion_tokens: 131072 },
                architecture: { input_modalities: ['text', 'image'] },
                reasoning: { mandatory: true, supported_efforts: ['max', 'high', 'low'] },
              },
              {
                id: 'meta/muse-spark-1.2-contributor',
                name: 'Meta: Muse Spark 1.2 Contributor',
                context_length: 1048576,
                architecture: { input_modalities: ['text', 'image'] },
                supported_parameters: ['reasoning', 'reasoning_effort'],
              },
            ],
          }),
        })
      }

      return Promise.resolve({
        ok: true,
        json: async () => ({}),
      })
    })

    vi.stubGlobal('fetch', mockFetch)

    const mockCtx: any = {
      llm: {
        resolveModelInfo: vi.fn().mockResolvedValue({
          context: { contextWindow: 0 },
          defaultMaxTokens: 4096,
          inputModalities: ['text'],
        }),
      },
      settings: {
        mutate: vi.fn().mockImplementation((ns: string, ops: any[]) => Promise.resolve(ops)),
      },
      on: vi.fn(),
    }

    apply(mockCtx)

    // 1. 测试运行时 resolveModelInfo 注入
    const oxInfo = await mockCtx.llm.resolveModelInfo('custom', 'ox-alpha-free')
    expect(oxInfo.context.contextWindow).toBe(1048576)
    expect(oxInfo.inputModalities).toContain('image')
    expect(oxInfo.reasoning).toBeDefined()
    expect(oxInfo.reasoning.efforts).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ id: 'max' }),
        expect.objectContaining({ id: 'high' }),
        expect.objectContaining({ id: 'low' }),
      ]),
    )

    const museInfo = await mockCtx.llm.resolveModelInfo('custom', 'muse-spark-1.2-contributor')
    expect(museInfo.context.contextWindow).toBe(1048576)
    expect(museInfo.inputModalities).toContain('image')
    expect(museInfo.reasoning).toBeDefined()

    // 2. 测试 settings.mutate 写入持久化时的自动注入
    const ops = [
      {
        op: 'set',
        value: {
          providers: {
            custom: {
              models: [
                { id: 'ox-alpha-free' },
                { id: 'muse-spark-1.2-contributor' },
              ],
            },
          },
        },
      },
    ]

    const mutated = await mockCtx.settings.mutate('llm', ops)
    const savedModels = mutated[0].value.providers.custom.models
    expect(savedModels[0].contextWindow).toBe(1048576)
    expect(savedModels[0].input).toEqual(['text', 'image'])
    expect(savedModels[0].reasoningEfforts).toBeDefined()

    expect(savedModels[1].contextWindow).toBe(1048576)
    expect(savedModels[1].input).toEqual(['text', 'image'])
    expect(savedModels[1].reasoningEfforts).toBeDefined()
  })
})
