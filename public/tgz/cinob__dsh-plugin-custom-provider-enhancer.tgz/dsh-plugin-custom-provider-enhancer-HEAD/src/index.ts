import type { CustomProviderEnhancerConfig, DshContext, LlmDiscoveredModel, LlmModelDiscoveryRequest, NormalizedModelMeta } from './types'
import { ModelsDevClient } from './models-dev'
import { discoverAndEnrichModels, enrichDiscoveredModels } from './discovery'
import { DEFAULT_REASONING_EFFORTS, matchModel } from './matcher'

export * from './types'
export * from './matcher'
export * from './models-dev'
export * from './discovery'

export const name = 'dsh-plugin-custom-provider-enhancer'
export const inject = ['llm', 'settings']

/**
 * 智能深度富化单个模型配置对象，自动注入 input (视觉) 和 reasoningEfforts (思考)
 */
function enrichModelConfig(model: any, catalog: Map<string, NormalizedModelMeta>, config: CustomProviderEnhancerConfig): any {
  if (!model || typeof model !== 'object' || typeof model.id !== 'string') {
    return model
  }

  const matched = matchModel(model.id, catalog)
  const enriched = { ...model }

  if (matched) {
    // 1. 上下文大小 contextWindow
    if (!enriched.contextWindow || enriched.contextWindow === 256_000 || enriched.contextWindow === 262_144) {
      enriched.contextWindow = matched.contextWindow ?? config.defaultContextWindow ?? 128_000
    }

    // 2. 最大输出 Token maxTokens
    if (!enriched.maxTokens || enriched.maxTokens === 32_000 || enriched.maxTokens === 32_768) {
      enriched.maxTokens = matched.maxTokens ?? config.defaultMaxTokens ?? 4096
    }

    // 3. 视觉模态 input: ['text', 'image']
    if (matched.inputModalities.includes('image')) {
      enriched.input = ['text', 'image']
    }

    // 4. 深度思考推理档位 reasoningEfforts
    if (matched.supportsReasoning && !enriched.reasoningEfforts) {
      enriched.reasoningEfforts = matched.reasoningEfforts ?? DEFAULT_REASONING_EFFORTS
    }
  } else {
    // 未知模型兜底保底上下文
    if (!enriched.contextWindow) {
      enriched.contextWindow = config.defaultContextWindow ?? 128_000
    }
    if (!enriched.maxTokens) {
      enriched.maxTokens = config.defaultMaxTokens ?? 4096
    }
  }

  return enriched
}

/**
 * 递归遍历并富化所有 models 数组
 */
function enrichModelsInTree(target: any, catalog: Map<string, NormalizedModelMeta>, config: CustomProviderEnhancerConfig): any {
  if (!target || typeof target !== 'object') {
    return target
  }

  if (Array.isArray(target)) {
    // 如果是 models 数组本身
    if (target.some(item => item && typeof item === 'object' && 'id' in item)) {
      return target.map(item => enrichModelConfig(item, catalog, config))
    }
    return target.map(item => enrichModelsInTree(item, catalog, config))
  }

  const result: Record<string, any> = { ...target }
  for (const [key, value] of Object.entries(result)) {
    if (key === 'models' && Array.isArray(value)) {
      result[key] = value.map(m => enrichModelConfig(m, catalog, config))
    } else if (value && typeof value === 'object') {
      result[key] = enrichModelsInTree(value, catalog, config)
    }
  }

  return result
}

/**
 * DSH 自定义提供商模型增强插件
 */
export function apply(ctx: DshContext, config: CustomProviderEnhancerConfig = {}): void {
  const client = new ModelsDevClient(config)

  // 1. 拦截并增强模型发现服务（Web GUI 点击获取可用模型时）
  if (ctx.llm && typeof (ctx.llm as any).discoverModels === 'function') {
    const originalDiscoverModels = (ctx.llm as any).discoverModels.bind(ctx.llm)

    ;(ctx.llm as any).discoverModels = async (settingsNs: string, request: LlmModelDiscoveryRequest): Promise<LlmDiscoveredModel[]> => {
      let models: readonly LlmDiscoveredModel[] = []

      try {
        models = await originalDiscoverModels(settingsNs, request)
      } catch (err) {
        if (request.baseURL) {
          models = await discoverAndEnrichModels(request, client, config)
          return models as LlmDiscoveredModel[]
        }
        throw err
      }

      try {
        const catalog = await client.getCatalog()
        return enrichDiscoveredModels(models, catalog, config)
      } catch {
        return models as LlmDiscoveredModel[]
      }
    }

    ctx.on('dispose', () => {
      ;(ctx.llm as any).discoverModels = originalDiscoverModels
    })
  }

  // 2. 拦截 Settings 写入（点击保存时，自动将 input 和 reasoningEfforts 完整持久化写入 settings.yaml）
  const settingsService = (ctx as any).settings
  if (settingsService && typeof settingsService.mutate === 'function') {
    const originalMutate = settingsService.mutate.bind(settingsService)
    const originalUpdate = typeof settingsService.update === 'function' ? settingsService.update.bind(settingsService) : undefined
    const originalReplace = typeof settingsService.replace === 'function' ? settingsService.replace.bind(settingsService) : undefined

    settingsService.mutate = async (ns: string, ops: any[], expectedRevision?: number) => {
      try {
        const catalog = await client.getCatalog()
        const enrichedOps = ops.map(op => {
          if (op && op.op === 'set' && op.value !== undefined) {
            return {
              ...op,
              value: enrichModelsInTree(op.value, catalog, config),
            }
          }
          return op
        })
        return await originalMutate(ns, enrichedOps, expectedRevision)
      } catch {
        return await originalMutate(ns, ops, expectedRevision)
      }
    }

    if (originalUpdate) {
      settingsService.update = async (ns: string, patch: any, expectedRevision?: number) => {
        try {
          const catalog = await client.getCatalog()
          const enrichedPatch = enrichModelsInTree(patch, catalog, config)
          return await originalUpdate(ns, enrichedPatch, expectedRevision)
        } catch {
          return await originalUpdate(ns, patch, expectedRevision)
        }
      }
    }

    if (originalReplace) {
      settingsService.replace = async (ns: string, section: any, expectedRevision?: number) => {
        try {
          const catalog = await client.getCatalog()
          const enrichedSection = enrichModelsInTree(section, catalog, config)
          return await originalReplace(ns, enrichedSection, expectedRevision)
        } catch {
          return await originalReplace(ns, section, expectedRevision)
        }
      }
    }

    ctx.on('dispose', () => {
      settingsService.mutate = originalMutate
      if (originalUpdate) settingsService.update = originalUpdate
      if (originalReplace) settingsService.replace = originalReplace
    })
  }

  // 3. 拦截并在运行时确保模型具备 Vision 与 Reasoning
  if (ctx.llm && typeof (ctx.llm as any).resolveModelInfo === 'function') {
    const originalResolveModelInfo = (ctx.llm as any).resolveModelInfo.bind(ctx.llm)

    ;(ctx.llm as any).resolveModelInfo = async (provider: string, model: string, signal?: AbortSignal) => {
      const info = await originalResolveModelInfo(provider, model, signal)

      try {
        const catalog = await client.getCatalog()
        const matched = matchModel(model, catalog)

        if (matched) {
          // 上下文大小兜底覆盖
          const isDefaultContext =
            !info.context ||
            info.context.contextWindow === 256_000 ||
            info.context.contextWindow === 262_144 ||
            info.context.contextWindow <= 0

          if (isDefaultContext && matched.contextWindow) {
            info.context = { contextWindow: matched.contextWindow }
          }

          // 最大输出 Token 兜底覆盖
          const isDefaultMaxTokens =
            !info.defaultMaxTokens ||
            info.defaultMaxTokens === 32_000 ||
            info.defaultMaxTokens === 32_768 ||
            info.defaultMaxTokens === 4096

          if (isDefaultMaxTokens && matched.maxTokens) {
            info.defaultMaxTokens = matched.maxTokens
          }

          // 注入视觉模态
          if (matched.inputModalities.includes('image')) {
            const current = info.inputModalities ? [...info.inputModalities] : ['text']
            if (!current.includes('image')) {
              current.push('image')
            }
            info.inputModalities = current
          }

          // 注入思考档位
          if (matched.supportsReasoning && !info.reasoning) {
            const effortsList = matched.reasoningEfforts
              ? Object.keys(matched.reasoningEfforts).map(key => ({
                  id: key,
                  name: key.charAt(0).toUpperCase() + key.slice(1),
                }))
              : [
                  { id: 'off', name: 'Off' },
                  { id: 'low', name: 'Low' },
                  { id: 'medium', name: 'Medium' },
                  { id: 'high', name: 'High' },
                  { id: 'max', name: 'Max' },
                ]

            info.reasoning = {
              efforts: effortsList,
              defaultEffort: 'high',
            }
          }
        }
      } catch {
        // 异常保持原样
      }

      return info
    }

    ctx.on('dispose', () => {
      ;(ctx.llm as any).resolveModelInfo = originalResolveModelInfo
    })
  }
}

export default { name, inject, apply }
