export type ModelInputModality = 'text' | 'image' | 'audio' | 'video'

/**
 * 思考/深度推理强度配置映射
 * 键为 DSH 规范档位，值为协议传输值（或 null 表示关）
 */
export type ReasoningEffortMap = Record<string, string | null>

/**
 * DSH 模型发现请求参数
 */
export interface LlmModelDiscoveryRequest {
  settingsNs?: string
  provider?: string
  baseURL?: string
  api?: string
  apiKey?: string
}

/**
 * DSH 发现返回的单个模型规格
 */
export interface LlmDiscoveredModel {
  id: string
  name?: string
  contextWindow?: number
  maxTokens?: number
}

/**
 * DSH / Cordis 运行时 Context 接口抽象
 */
export interface DshContext {
  llm: {
    registerModelDiscovery(
      settingsNs: string,
      discover: (request: LlmModelDiscoveryRequest) => Promise<readonly LlmDiscoveredModel[]>,
    ): () => void
  }
  on(event: 'dispose', listener: () => void): () => void
  [key: string]: unknown
}

/**
 * 插件全局配置项
 */
export interface CustomProviderEnhancerConfig {
  /** LiteLLM 元数据镜像源地址 (默认 https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json) */
  metadataUrl?: string
  /** OpenRouter 官方模型端点地址 (默认 https://openrouter.ai/api/v1/models) */
  openrouterMetadataUrl?: string
  /** 请求超时时间 (毫秒，默认 8000ms) */
  timeoutMs?: number
  /** 本地缓存过期时间 (毫秒，默认 1 小时) */
  cacheTtlMs?: number
  /** 无法匹配模型时的默认上下文保底值 (默认 128000) */
  defaultContextWindow?: number
  /** 无法匹配模型时的默认输出上限保底值 (默认 4096) */
  defaultMaxTokens?: number
  /** 是否自动检测并补齐多模态视觉能力 (默认 true) */
  autoDetectVision?: boolean
  /** 是否自动检测并注入思考推理档位 (默认 true) */
  autoDetectReasoning?: boolean
}

/** models.dev 单个模型的原始元数据定义 */
export interface ModelsDevItem {
  id: string
  name?: string
  display_name?: string
  context_length?: number
  context_window?: number
  max_context?: number
  max_output_tokens?: number
  max_tokens?: number
  modalities?: string[]
  input_modalities?: string[]
  architecture?: {
    modality?: string
    reasoning?: boolean
  }
  features?: string[]
  pricing?: {
    input?: number
    output?: number
  }
}

/** 归一化后的模型元数据与能力规格 */
export interface NormalizedModelMeta {
  id: string
  name: string
  contextWindow: number
  maxTokens?: number
  inputModalities: ModelInputModality[]
  supportsReasoning: boolean
  reasoningEfforts?: ReasoningEffortMap
}
