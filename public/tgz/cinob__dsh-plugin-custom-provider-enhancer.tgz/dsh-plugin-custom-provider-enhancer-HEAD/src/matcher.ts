import type { ModelInputModality, NormalizedModelMeta, ReasoningEffortMap } from './types'

/** 默认标准思考档位字典 */
export const DEFAULT_REASONING_EFFORTS: ReasoningEffortMap = {
  off: null,
  low: 'low',
  medium: 'medium',
  high: 'high',
  max: 'max',
}

/** 启发式判断模型是否属于已知支持视觉（Vision）的多模态模型 */
export function inferVisionSupport(modelId: string): boolean {
  const lower = modelId.toLowerCase()
  return (
    lower.includes('vision') ||
    lower.includes('-vl') ||
    lower.includes('gpt-4o') ||
    lower.includes('gpt-4-turbo') ||
    lower.includes('claude-3') ||
    lower.includes('gemini') ||
    lower.includes('qwen2.5-vl') ||
    lower.includes('qvq') ||
    lower.includes('pixtral') ||
    lower.includes('minicpm-v') ||
    lower.includes('mimo') ||
    lower.includes('llava')
  )
}

/** 启发式判断模型是否属于已知支持思考（Reasoning / Thinking）的推理模型 */
export function inferReasoningSupport(modelId: string): boolean {
  const lower = modelId.toLowerCase()
  return (
    lower.includes('reasoner') ||
    lower.includes('-r1') ||
    lower.includes('deepseek-r1') ||
    lower.includes('o1') ||
    lower.includes('o3') ||
    lower.includes('qwq') ||
    lower.includes('thinking') ||
    lower.includes('claude-3-7-sonnet')
  )
}

/**
 * 清理模型 ID 中的命名空间前缀与版本修饰符
 * 例如: "openai/gpt-4o-2024-08-06" -> "gpt-4o-2024-08-06"
 */
export function normalizeModelId(id: string): string {
  let cleaned = id.trim().toLowerCase()
  if (cleaned.includes('/')) {
    cleaned = cleaned.split('/').pop()!
  }
  return cleaned
}

/**
 * 剥离模型常见后缀（如 -free, -preview, -contributor, -latest, 日期快照等）
 */
export function stripModelModifiers(id: string): string {
  const norm = normalizeModelId(id)
  return norm
    .replace(/-(?:free|preview|latest|chat|instruct|contributor)$/i, '')
    .replace(/-\d{4,8}$/, '')
    .replace(/-\d{4}-\d{2}-\d{2}$/, '')
}

/**
 * 模糊匹配模型元数据
 * 应对带有日期快照后缀（如 -20240513）、免费后缀（如 -free）、或第三方网关前缀（如 stealth/ox-alpha）的情况
 */
export function matchModel(
  rawId: string,
  metaMap: Map<string, NormalizedModelMeta>,
): NormalizedModelMeta | undefined {
  if (!rawId) return undefined

  const rawLower = rawId.trim().toLowerCase()

  // 1. 完全精确匹配 (含原始可能带前缀的 key)
  if (metaMap.has(rawLower)) {
    return metaMap.get(rawLower)
  }

  // 2. 去除命名空间前缀匹配
  const normalized = normalizeModelId(rawLower)
  if (metaMap.has(normalized)) {
    return metaMap.get(normalized)
  }

  // 3. 去除修饰后缀（-free, -preview, 日期后缀等）匹配
  const stripped = stripModelModifiers(normalized)
  if (stripped && metaMap.has(stripped)) {
    return metaMap.get(stripped)
  }

  // 4. 遍历 catalog 尝试前缀/包含/去后缀比对
  for (const [key, meta] of metaMap.entries()) {
    const normKey = normalizeModelId(key)
    const strippedKey = stripModelModifiers(normKey)

    if (
      normalized === normKey ||
      stripped === normKey ||
      normalized === strippedKey ||
      (stripped && strippedKey && stripped === strippedKey) ||
      normalized.startsWith(normKey) ||
      normKey.startsWith(normalized)
    ) {
      return meta
    }
  }

  return undefined
}
