import { ModelsDevClient } from './models-dev'
import { matchModel } from './matcher'
import type { CustomProviderEnhancerConfig, LlmDiscoveredModel, LlmModelDiscoveryRequest, NormalizedModelMeta } from './types'

/** 提取非空有效字符串 */
function cleanString(...candidates: readonly unknown[]): string | undefined {
  for (const c of candidates) {
    if (typeof c === 'string') {
      const trimmed = c.trim()
      if (trimmed.length > 0) return trimmed
    }
  }
  return undefined
}

/** 提取合法正整数 */
function cleanInteger(...candidates: readonly unknown[]): number | undefined {
  for (const c of candidates) {
    if (typeof c === 'number' && Number.isInteger(c) && c > 0) {
      return c
    }
  }
  return undefined
}

/**
 * 将现有模型列表与 models.dev 的规格元数据进行比对，自动补齐上下文大小和输出限制
 * 保证输出严格符合 DSH RPC Schema 校验（避免 name 为空字符串引起 too_small 错误）
 */
export function enrichDiscoveredModels(
  rawList: readonly LlmDiscoveredModel[],
  catalog: Map<string, NormalizedModelMeta>,
  config: CustomProviderEnhancerConfig = {},
): LlmDiscoveredModel[] {
  const result: LlmDiscoveredModel[] = []

  for (const raw of rawList) {
    const rawId = cleanString(raw.id)
    if (!rawId) continue

    const matched = matchModel(rawId, catalog)

    // 上下文大小：优先使用已探测到的合法值，否则从 models.dev 自动补齐，最后保底
    const contextWindow = cleanInteger(
      raw.contextWindow,
      matched?.contextWindow,
      config.defaultContextWindow,
      128_000,
    )

    // 输出 Token 上限
    const maxTokens = cleanInteger(
      raw.maxTokens,
      matched?.maxTokens,
      config.defaultMaxTokens,
      4096,
    )

    // 保持模型纯净展示名称（若为空则不传递该字段，避免触发 Schema 校验失败）
    const displayName = cleanString(raw.name, matched?.name)

    result.push({
      id: rawId,
      ...displayName === undefined ? {} : { name: displayName },
      ...contextWindow === undefined ? {} : { contextWindow },
      ...maxTokens === undefined ? {} : { maxTokens },
    })
  }

  return result
}

/**
 * 直接探测自定义提供商端点并自动富化回填参数
 */
export async function discoverAndEnrichModels(
  request: LlmModelDiscoveryRequest,
  client: ModelsDevClient,
  config: CustomProviderEnhancerConfig = {},
): Promise<readonly LlmDiscoveredModel[]> {
  if (!request.baseURL) {
    throw new Error('Please specify a baseURL to discover models for custom provider')
  }

  // 1. 请求自定义网关/端点的 GET /models 接口
  const endpointUrl = `${request.baseURL.replace(/\/+$/, '')}/models`
  const headers: Record<string, string> = { Accept: 'application/json' }
  if (request.apiKey) {
    headers.Authorization = `Bearer ${request.apiKey}`
  }

  const res = await fetch(endpointUrl, { headers })
  if (!res.ok) {
    throw new Error(`Failed to probe models from custom provider at ${endpointUrl}: HTTP ${res.status}`)
  }

  const body = await res.json()
  const rawList: Array<{
    id?: string
    name?: string
    display_name?: string
    context_window?: number
    context_length?: number
    max_tokens?: number
    max_output_tokens?: number
  }> = Array.isArray(body?.data) ? body.data : []

  const formattedRaw: LlmDiscoveredModel[] = []
  for (const item of rawList) {
    const id = cleanString(item.id)
    if (!id) continue

    const name = cleanString(item.name, item.display_name)
    const contextWindow = cleanInteger(item.context_window, item.context_length)
    const maxTokens = cleanInteger(item.max_tokens, item.max_output_tokens)

    formattedRaw.push({
      id,
      ...name === undefined ? {} : { name },
      ...contextWindow === undefined ? {} : { contextWindow },
      ...maxTokens === undefined ? {} : { maxTokens },
    })
  }

  // 2. 从 models.dev 获取元数据索引
  const catalog = await client.getCatalog()

  // 3. 自动对齐并补全
  return enrichDiscoveredModels(formattedRaw, catalog, config)
}
