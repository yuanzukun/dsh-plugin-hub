import type {
  CustomProviderEnhancerConfig,
  ModelInputModality,
  NormalizedModelMeta,
  ReasoningEffortMap,
} from './types'
import {
  DEFAULT_REASONING_EFFORTS,
  inferReasoningSupport,
  inferVisionSupport,
  normalizeModelId,
  stripModelModifiers,
} from './matcher'

/** 内置知名模型保底规格库 (支持 30+ 常见主流与前沿模型) */
const BUILTIN_MODEL_SPECS: Record<string, Partial<NormalizedModelMeta>> = {
  // Gemini 家族
  'gemini-3.7-flash': { contextWindow: 1_048_576, maxTokens: 65_536, inputModalities: ['text', 'image'], supportsReasoning: true },
  'gemini-2.5-flash': { contextWindow: 1_048_576, maxTokens: 65_536, inputModalities: ['text', 'image'], supportsReasoning: true },
  'gemini-2.5-pro': { contextWindow: 2_097_152, maxTokens: 65_536, inputModalities: ['text', 'image'], supportsReasoning: true },
  'gemini-2.0-flash': { contextWindow: 1_048_576, maxTokens: 8_192, inputModalities: ['text', 'image'] },
  'gemini-1.5-pro': { contextWindow: 2_097_152, maxTokens: 8_192, inputModalities: ['text', 'image'] },
  'gemini-1.5-flash': { contextWindow: 1_048_576, maxTokens: 8_192, inputModalities: ['text', 'image'] },

  // DeepSeek 家族
  'deepseek-chat': { contextWindow: 64_000, maxTokens: 8_192, inputModalities: ['text'] },
  'deepseek-reasoner': { contextWindow: 64_000, maxTokens: 8_192, inputModalities: ['text'], supportsReasoning: true },
  'deepseek-v4-pro': { contextWindow: 1_000_000, maxTokens: 128_000, inputModalities: ['text'], supportsReasoning: true },
  'deepseek-v4-flash': { contextWindow: 1_000_000, maxTokens: 128_000, inputModalities: ['text'], supportsReasoning: true },

  // OpenAI 家族
  'gpt-4o': { contextWindow: 128_000, maxTokens: 16_384, inputModalities: ['text', 'image'] },
  'gpt-4o-mini': { contextWindow: 128_000, maxTokens: 16_384, inputModalities: ['text', 'image'] },
  'gpt-image-2': { contextWindow: 128_000, maxTokens: 16_384, inputModalities: ['text', 'image'] },
  'o1': { contextWindow: 200_000, maxTokens: 100_000, inputModalities: ['text', 'image'], supportsReasoning: true },
  'o3-mini': { contextWindow: 200_000, maxTokens: 100_000, inputModalities: ['text'], supportsReasoning: true },

  // Claude 家族
  'claude-3-7-sonnet': { contextWindow: 200_000, maxTokens: 64_000, inputModalities: ['text', 'image'], supportsReasoning: true },
  'claude-3-5-sonnet': { contextWindow: 200_000, maxTokens: 8_192, inputModalities: ['text', 'image'] },
  'claude-3-5-haiku': { contextWindow: 200_000, maxTokens: 8_192, inputModalities: ['text'] },

  // Qwen 家族
  'qwen-max': { contextWindow: 32_768, maxTokens: 8_192, inputModalities: ['text'] },
  'qwen-plus': { contextWindow: 131_072, maxTokens: 8_192, inputModalities: ['text'] },
  'qwen-turbo': { contextWindow: 131_072, maxTokens: 8_192, inputModalities: ['text'] },
  'qwen2.5-vl-72b-instruct': { contextWindow: 131_072, maxTokens: 8_192, inputModalities: ['text', 'image'] },
  'qwq-32b': { contextWindow: 131_072, maxTokens: 8_192, inputModalities: ['text'], supportsReasoning: true },

  // 小米 Mimo 家族
  'mimo-v2.5': { contextWindow: 1_000_000, maxTokens: 128_000, inputModalities: ['text', 'image'] },
  'mimo-v2.5-free': { contextWindow: 262_144, maxTokens: 16_384, inputModalities: ['text', 'image'] },
}

export class ModelsDevClient {
  private cache: Map<string, NormalizedModelMeta> = new Map()
  private lastFetchedAt = 0
  private readonly metadataUrl: string
  private readonly openrouterMetadataUrl: string
  private readonly timeoutMs: number
  private readonly cacheTtlMs: number

  constructor(config: CustomProviderEnhancerConfig = {}) {
    this.metadataUrl = config.metadataUrl ?? 'https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json'
    this.openrouterMetadataUrl = config.openrouterMetadataUrl ?? 'https://openrouter.ai/api/v1/models'
    this.timeoutMs = config.timeoutMs ?? 6000
    this.cacheTtlMs = config.cacheTtlMs ?? 1000 * 60 * 60 // 1 小时缓存
  }

  /** 获取全部模型元数据索引（聚合 OpenRouter 官方 API + LiteLLM 数据库 + 内置保底） */
  async getCatalog(): Promise<Map<string, NormalizedModelMeta>> {
    const now = Date.now()
    if (this.cache.size > 0 && now - this.lastFetchedAt < this.cacheTtlMs) {
      return this.cache
    }

    const nextMap = new Map<string, NormalizedModelMeta>()

    // 辅助函数：将模型元数据多重别名注册进 Map
    const registerMeta = (id: string, meta: NormalizedModelMeta) => {
      const lowerId = id.toLowerCase()
      nextMap.set(lowerId, meta)

      const norm = normalizeModelId(lowerId)
      if (!nextMap.has(norm)) {
        nextMap.set(norm, meta)
      }

      const stripped = stripModelModifiers(norm)
      if (stripped && !nextMap.has(stripped)) {
        nextMap.set(stripped, meta)
      }
    }

    // 1. 加载内置已知模型
    for (const [id, spec] of Object.entries(BUILTIN_MODEL_SPECS)) {
      registerMeta(id, {
        id,
        name: id,
        contextWindow: spec.contextWindow ?? 128_000,
        maxTokens: spec.maxTokens ?? 4096,
        inputModalities: spec.inputModalities ?? ['text'],
        supportsReasoning: Boolean(spec.supportsReasoning),
        reasoningEfforts: spec.supportsReasoning ? DEFAULT_REASONING_EFFORTS : undefined,
      })
    }

    // 2. 并行拉取第三方权威元数据源：OpenRouter 官方 API 与 LiteLLM 数据库
    const fetchOpenRouter = async () => {
      try {
        const controller = new AbortController()
        const timer = setTimeout(() => controller.abort(), this.timeoutMs)
        const res = await fetch(this.openrouterMetadataUrl, {
          headers: { Accept: 'application/json' },
          signal: controller.signal,
        })
        clearTimeout(timer)

        if (res.ok) {
          const body = await res.json()
          const list: any[] = Array.isArray(body?.data) ? body.data : []

          for (const item of list) {
            if (!item || typeof item.id !== 'string') continue

            const rawId = item.id
            const name = typeof item.name === 'string' && item.name.trim() ? item.name.trim() : rawId
            const contextWindow =
              typeof item.context_length === 'number' && item.context_length > 0
                ? item.context_length
                : typeof item.top_provider?.context_length === 'number' && item.top_provider.context_length > 0
                  ? item.top_provider.context_length
                  : undefined

            if (!contextWindow) continue

            const maxTokens =
              typeof item.top_provider?.max_completion_tokens === 'number' && item.top_provider.max_completion_tokens > 0
                ? item.top_provider.max_completion_tokens
                : typeof item.per_request_limits?.max_tokens === 'number' && item.per_request_limits.max_tokens > 0
                  ? item.per_request_limits.max_tokens
                  : undefined

            const inputModalities: ModelInputModality[] = Array.isArray(item.architecture?.input_modalities)
              ? item.architecture.input_modalities
              : []
            const hasVision = Boolean(
              inputModalities.includes('image') ||
              item.architecture?.modality?.includes('image') ||
              inferVisionSupport(rawId)
            )

            // 判断是否支持深度思考（Reasoning / Thinking）
            const reasoningObj = item.reasoning
            const supportedParams: string[] = Array.isArray(item.supported_parameters) ? item.supported_parameters : []
            const hasReasoning = Boolean(
              (reasoningObj && (reasoningObj.mandatory || (Array.isArray(reasoningObj.supported_efforts) && reasoningObj.supported_efforts.length > 0))) ||
              supportedParams.includes('reasoning') ||
              supportedParams.includes('reasoning_effort') ||
              supportedParams.includes('include_reasoning') ||
              inferReasoningSupport(rawId)
            )

            let reasoningEfforts: ReasoningEffortMap | undefined
            if (hasReasoning) {
              if (Array.isArray(reasoningObj?.supported_efforts) && reasoningObj.supported_efforts.length > 0) {
                reasoningEfforts = { off: null }
                for (const effort of reasoningObj.supported_efforts) {
                  if (typeof effort === 'string') {
                    reasoningEfforts[effort] = effort
                  }
                }
              } else {
                reasoningEfforts = DEFAULT_REASONING_EFFORTS
              }
            }

            registerMeta(rawId, {
              id: rawId,
              name,
              contextWindow,
              maxTokens,
              inputModalities: hasVision ? ['text', 'image'] : ['text'],
              supportsReasoning: hasReasoning,
              reasoningEfforts,
            })
          }
        }
      } catch {
        // OpenRouter 拉取失败时平滑跳过
      }
    }

    const fetchLiteLLM = async () => {
      try {
        const controller = new AbortController()
        const timer = setTimeout(() => controller.abort(), this.timeoutMs)
        const res = await fetch(this.metadataUrl, {
          headers: { Accept: 'application/json' },
          signal: controller.signal,
        })
        clearTimeout(timer)

        if (res.ok) {
          const json = await res.json()
          if (typeof json === 'object' && json !== null) {
            for (const [key, val] of Object.entries(json)) {
              const item = val as any
              if (!item || typeof item !== 'object') continue

              const modelId = key.includes('/') ? key.split('/').pop()! : key
              const contextWindow = item.max_input_tokens ?? item.max_context ?? item.context_window
              const maxTokens = item.max_output_tokens ?? item.max_tokens
              const hasVision = Boolean(item.supports_vision || item.supported_modalities?.includes('image') || inferVisionSupport(modelId))
              const hasReasoning = Boolean(item.supports_thinking || item.mode === 'reasoning' || inferReasoningSupport(modelId))

              if (typeof contextWindow === 'number' && contextWindow > 0) {
                registerMeta(modelId, {
                  id: modelId,
                  name: modelId,
                  contextWindow,
                  maxTokens: typeof maxTokens === 'number' && maxTokens > 0 ? maxTokens : undefined,
                  inputModalities: hasVision ? ['text', 'image'] : ['text'],
                  supportsReasoning: hasReasoning,
                  reasoningEfforts: hasReasoning ? DEFAULT_REASONING_EFFORTS : undefined,
                })
              }
            }
          }
        }
      } catch {
        // LiteLLM 拉取失败时平滑降级
      }
    }

    await Promise.allSettled([fetchOpenRouter(), fetchLiteLLM()])

    this.cache = nextMap
    this.lastFetchedAt = now
    return this.cache
  }
}
