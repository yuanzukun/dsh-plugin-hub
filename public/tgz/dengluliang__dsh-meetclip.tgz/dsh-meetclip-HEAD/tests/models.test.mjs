import test from 'node:test'
import { readFile } from 'node:fs/promises'
import assert from 'node:assert/strict'
import { qualifyModel } from '../src/host/models-probe.js'
import { PREFERRED_SPEECH_MODEL, PREFERRED_TEXT_MODEL, candidateOrder, modelOptions, preferModel, sortModels, splitEntries, splitModels, vendorOf, withoutHidden } from '../client-src/lib/models.js'
import { probeUsable, verdictOf } from '../src/host/models-probe.js'

test('splits gateway models into speech and text', () => {
  const { asr, text } = splitModels([
    'mimo-v2.5-asr',
    'ASR_NonStreaming',
    'gpt-transcribe',
    'whisper',
    'mimo-v2.5-tts',
    'mimo-v2.5-tts-voiceclone',
    'text-embedding-3-small',
    'bge-reranker-v2-m3',
    'PaddleOCR-VL-0.9B',
    'gpt-4o',
    'mimo-v2.6-flash',
    'gpt-image-2'
  ])
  assert.deepEqual(asr, ['mimo-v2.5-asr', 'ASR_NonStreaming', 'gpt-transcribe', 'whisper'])
  assert.deepEqual(text, ['gpt-4o', 'mimo-v2.6-flash'])
})

test('dedupes, trims and drops batch aliases', () => {
  const { asr, text } = splitModels([' gpt-4o ', 'gpt-4o', '', 'x:batch', 'mimo-v2.5-asr'])
  assert.deepEqual(text, ['gpt-4o'])
  assert.deepEqual(asr, ['mimo-v2.5-asr'])
})

test('current model stays first even when absent from the catalog', () => {
  const options = modelOptions(['demo-asr', 'gpt-4o'], 'vendor/demo-text')
  assert.equal(options[0].value, 'vendor/demo-text')
  assert.match(options[0].label, /当前/)
  assert.deepEqual(options.slice(1).map((item) => item.value), ['demo-asr', 'gpt-4o'])
})

test('sorts the configured provider family ahead of others', () => {
  // 族名来自当前配置，而不是源码里写死的厂商前缀。
  assert.deepEqual(sortModels(['gpt-4o', 'deepseek-v4-flash', 'demo-1.2-flash'], 'demo-2.0'), [
    'demo-1.2-flash', 'deepseek-v4-flash', 'gpt-4o'
  ])
  assert.deepEqual(sortModels(['gpt-4o', 'demo-1.2-flash'], 'vendor/demo-text'), [
    'demo-1.2-flash', 'gpt-4o'
  ])
  const options = modelOptions(['gpt-4o', 'mimo-v2.6-flash'], 'gpt-4o')
  assert.deepEqual(options.map((item) => item.value), ['gpt-4o', 'mimo-v2.6-flash'])
})

test('qualifyModel 按 owned_by 补供应商前缀', () => {
  assert.equal(qualifyModel('mimo-v2.5-asr', 'xiaomi'), 'xiaomi/mimo-v2.5-asr')
  assert.equal(qualifyModel('deepseek-v4-flash', 'volcengine_maas'), 'volcengine_maas/deepseek-v4-flash')
})

test('qualifyModel 不重复拼接已带供应商的名字', () => {
  assert.equal(qualifyModel('anthropic/claude-sonnet-5-5', 'ppio'), 'anthropic/claude-sonnet-5-5')
  assert.equal(qualifyModel('xiaomi/mimo-v2.6-flash', 'xiaomi'), 'xiaomi/mimo-v2.6-flash')
})

test('qualifyModel 没有供应商时保持裸名', () => {
  assert.equal(qualifyModel('gpt-4o', ''), 'gpt-4o')
  assert.equal(qualifyModel('', 'xiaomi'), '')
})

test('vendorOf 取模型名的供应商段', () => {
  assert.equal(vendorOf('xiaomi/mimo-v2.5-asr'), 'xiaomi')
  assert.equal(vendorOf('mimo-v2.5-asr'), '')
})

test('带前缀的模型也能正确分到语音与文字', () => {
  const { asr, text } = splitModels([
    'xiaomi/mimo-v2.5-asr',
    'xiaomi/mimo-v2.5-tts',
    'xiaomi/mimo-v2.6-flash',
    'deepseek/deepseek-v4-flash',
    'openai/gpt-4o',
    'openai/text-embedding-3-large'
  ])
  assert.deepEqual(asr, ['xiaomi/mimo-v2.5-asr'])
  assert.deepEqual(text, ['xiaomi/mimo-v2.6-flash', 'deepseek/deepseek-v4-flash', 'openai/gpt-4o'])
})

test('candidateOrder 当前选择最先，其次同供应商，最后其余', () => {
  const order = candidateOrder(
    ['deepseek/deepseek-v4-flash', 'xiaomi/mimo-v2.6-pro', 'xiaomi/mimo-v2.6-flash', 'openai/gpt-4o'],
    { current: 'xiaomi/mimo-v2.6-flash', vendor: 'xiaomi' }
  )
  assert.deepEqual(order, [
    'xiaomi/mimo-v2.6-flash',
    'xiaomi/mimo-v2.6-pro',
    'deepseek/deepseek-v4-flash',
    'openai/gpt-4o'
  ])
})

test('candidateOrder 没有当前选择时按供应商聚拢，不丢模型', () => {
  assert.deepEqual(candidateOrder(['a/one', 'b/two', 'c/three'], { vendor: 'c' }),
    ['c/three', 'a/one', 'b/two'])
  assert.deepEqual(candidateOrder([], {}), [])
  assert.deepEqual(candidateOrder(['m', 'm'], {}), ['m'])
})

test('verdictOf 只把「明确不可用」判成过滤', () => {
  assert.equal(verdictOf(401, ''), 'denied')
  assert.equal(verdictOf(403, '该模型不在 Key 的可用模型范围内'), 'denied')
  assert.equal(verdictOf(400, '该模型未指定供应商'), 'denied')
  assert.equal(verdictOf(502, '<html>502 Bad Gateway</html>'), 'broken')
  assert.equal(verdictOf(404, ''), 'broken')
  // 参数类 400 不下结论，保留可见。
  assert.equal(verdictOf(400, 'Param Incorrect'), 'unknown')
  assert.equal(verdictOf(0, '探测超时'), 'unknown')
  // 目录里有、网关却没部署的模型也算明确不可用。
  assert.equal(verdictOf(400, 'Not supported model nxai/claude-haiku-5-5'), 'broken')
  assert.equal(verdictOf(400, 'invalid_model'), 'broken')
})

test('withoutHidden 去掉明确不可用的模型，且不会把列表清空', () => {
  const list = ['xiaomi/a', 'xiaomi/b', 'xiaomi/c']
  assert.deepEqual(withoutHidden(list, [{ model: 'xiaomi/b', kind: 'denied' }]), ['xiaomi/a', 'xiaomi/c'])
  assert.deepEqual(withoutHidden(list, ['xiaomi/b']), ['xiaomi/a', 'xiaomi/c'])
  assert.deepEqual(withoutHidden(list, []), list)
  // 全被隐藏时保留原列表，避免下拉变空。
  assert.deepEqual(withoutHidden(list, list.map((model) => ({ model }))), list)
})

test('probeUsable 只隐藏拒绝与坏掉的模型，未知保持可见', async () => {
  const calls = []
  const replies = {
    'xiaomi/ok': { status: 200, body: '' },
    'xiaomi/denied': { status: 401, body: '{"error":{"message":"该模型不在 Key 的可用模型范围内"}}' },
    'xiaomi/broken': { status: 502, body: '<html>502 Bad Gateway</html>' },
    'xiaomi/weird': { status: 400, body: '{"error":{"message":"Param Incorrect"}}' }
  }
  const original = globalThis.fetch
  globalThis.fetch = async (url, options) => {
    const model = JSON.parse(options.body).model
    calls.push(model)
    const reply = replies[model]
    return { status: reply.status, text: async () => reply.body }
  }
  try {
    const result = await probeUsable({
      apiKey: 'sk-test-0123456789', baseUrl: 'https://gateway.example.com/v1',
      models: Object.keys(replies), concurrency: 4
    })
    assert.equal(result.ok, true)
    assert.equal(result.checked, 4)
    assert.deepEqual(result.hidden.map((row) => row.model).sort(), ['xiaomi/broken', 'xiaomi/denied'])
    assert.deepEqual(result.hidden.find((row) => row.model === 'xiaomi/denied').kind, 'denied')
    assert.deepEqual(result.hidden.find((row) => row.model === 'xiaomi/broken').kind, 'broken')
    assert.deepEqual(calls.sort(), Object.keys(replies).sort())
  } finally {
    globalThis.fetch = original
  }
})

test('preferModel 命中默认模型，带供应商前缀也算', () => {
  assert.equal(PREFERRED_SPEECH_MODEL, 'mimo-v2.5-asr')
  assert.equal(PREFERRED_TEXT_MODEL, 'mimo-v2.6-flash')
  assert.equal(preferModel(['xiaomi/ASR_NonStreaming', 'xiaomi/mimo-v2.5-asr'], 'mimo-v2.5-asr'), 'xiaomi/mimo-v2.5-asr')
  assert.equal(preferModel(['mimo-v2.5-asr'], 'mimo-v2.5-asr'), 'mimo-v2.5-asr')
  assert.equal(preferModel(['xiaomi/mimo-v2.6-flash', 'deepseek/x'], 'mimo-v2.6-flash'), 'xiaomi/mimo-v2.6-flash')
  // 换了网关没有这两个模型时返回空，交给调用方退回第一项。
  assert.equal(preferModel(['openai/gpt-4o'], 'mimo-v2.6-flash'), '')
  assert.equal(preferModel([], 'mimo-v2.5-asr'), '')
})

test('首次引导把这两个模型设成默认选择', async () => {
  const about = await readFile(new URL('../client-src/components/SetupWizard.jsx', import.meta.url), 'utf8')
  assert.match(about, /preferModel\(catalog\.asr, PREFERRED_SPEECH_MODEL\)/)
  assert.match(about, /preferModel\(catalog\.text, PREFERRED_TEXT_MODEL\)/)
})

test('splitEntries 按 model_type 分类，非对话模型不进下拉', () => {
  const { asr, text } = splitEntries([
    { id: 'mimo-v2.6-flash', wire: 'xiaomi/mimo-v2.6-flash', kind: 'llm' },
    { id: 'MiLM2.1', wire: 'xiaomi/MiLM2.1', kind: 'llm' },
    { id: 'mimo-v2.5-asr', wire: 'xiaomi/mimo-v2.5-asr', kind: 'speech2text' },
    // 名字里没有任何关键词，只按名字猜会漏进文字列表。
    { id: 'wan2.7-i2v', wire: 'tongyi/wan2.7-i2v', kind: 'video_generation' },
    { id: 'kling-3.0-turbo', wire: 'ppio/kling-3.0-turbo', kind: 'video_generation' },
    { id: 'embedding-2', wire: 'zhipuai/embedding-2', kind: 'text-embedding' },
    { id: 'mimo-v2.5-tts', wire: 'xiaomi/mimo-v2.5-tts', kind: 'tts' }
  ])
  assert.deepEqual(asr, ['xiaomi/mimo-v2.5-asr'])
  assert.deepEqual(text, ['xiaomi/mimo-v2.6-flash', 'xiaomi/MiLM2.1'])
})

test('没有 model_type 时 splitEntries 退回按名字判断', () => {
  const { asr, text } = splitEntries(['mimo-v2.5-asr', 'gpt-transcribe', 'gpt-4o', 'bge-reranker-v2'])
  assert.deepEqual(asr, ['mimo-v2.5-asr', 'gpt-transcribe'])
  assert.deepEqual(text, ['gpt-4o'])
})
