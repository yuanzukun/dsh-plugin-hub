﻿import { test } from 'node:test'
import { mock } from 'node:test'
import assert from 'node:assert/strict'
import fs, { mkdtempSync, rmSync, mkdirSync, symlinkSync } from 'node:fs'
import { syncBuiltinESMExports } from 'node:module'
import { tmpdir } from 'node:os'
import { join, sep } from 'node:path'
import { EventEmitter } from 'node:events'
import { spawn } from 'node:child_process'
import { begin, mergeTask, finishTask, listStatus, purge } from '../src/ops.js'
import { EMPTY_LEDGER, loadLedger, saveLedger, upsertRecord, withLock } from '../src/vault.js'
import { resolveToplevel } from '../src/git.js'
import { slugifyTask } from '../src/naming.js'

// ---- 假 git 执行器 ---------------------------------------------------------

class FakeGit {
  /** @type {Array<{args: string[], cwd: string | undefined}>} */
  calls
  /** @type {Map<string, any>} */
  answers

  constructor() {
    this.calls = []
    this.answers = new Map()
  }
  /**
   * @param {string[]} args
   * @param {any} result
   */
  on(args, result) {
    this.answers.set(args.join(' '), result)
    return this
  }
  /**
   * @param {string[]} args
   * @param {{cwd?: string, signal?: AbortSignal}} [opts]
  */
  async run(args, opts = {}) {
    this.calls.push({ args, cwd: opts.cwd })
    const commandIndex = args.findIndex((arg) => arg === 'commit' || arg === 'merge')
    const normalized = commandIndex === -1 ? args : args.slice(commandIndex).filter((arg) => arg !== '--commit')
    const key = normalized.join(' ')
    const a = this.answers.get(args.join(' ')) ?? this.answers.get(key)
    if (a === undefined) throw new Error(`FakeGit: 未预设答案: ${key}`)
    return typeof a === 'function' ? a({ args, cwd: opts.cwd, signal: opts.signal }) : a
  }
  /**
   * @param {string[]} args
   * @param {string | undefined} [cwd]
   */
  called(args, cwd) {
    return this.calls.some((c) => {
      const commandIndex = c.args.findIndex((arg) => arg === 'commit' || arg === 'merge')
      const normalized = commandIndex === -1 ? c.args : c.args.slice(commandIndex).filter((arg) => arg !== '--commit')
      const actual = normalized.join(' ')
      return actual === args.join(' ') && (cwd === undefined || c.cwd === cwd)
    })
  }
  /** @param {string[]} args */
  count(args) {
    return this.calls.filter((c) => {
      const commandIndex = c.args.findIndex((arg) => arg === 'commit' || arg === 'merge')
      const normalized = commandIndex === -1 ? c.args : c.args.slice(commandIndex).filter((arg) => arg !== '--commit')
      const actual = normalized.join(' ')
      return actual === args.join(' ')
    }).length
  }
}

const OK = (stdout = '', stderr = '') => ({ ok: true, code: 0, stdout, stderr })
const WORKTREES = (text = '') => OK(text.replaceAll('\n', '\0'))
const FAIL = (stderr = 'nope', code = 128) => ({ ok: false, code, stdout: '', stderr })

/** @returns {string} */
function makeTmp() {
  return mkdtempSync(join(tmpdir(), 'wtm-ops-test-'))
}

/**
 * @param {string} tmp
 * @returns {{vault: string, prefix: string, commitMessage: string, mergeMessage: string, warnings: string[]}}
 */
function baseCfg(tmp) {
  return {
    vault: join(tmp, 'vault'),
    prefix: 'wtm',
    commitMessage: 'snapshot {task}',
    mergeMessage: 'fold {task} into {base}',
    warnings: [],
  }
}

/**
 * @param {AbortController} controller
 * @param {{cleanupConfirmed?: boolean}} [opts]
 * @returns {(shell: string, args: string[], spawnOpts: object) => object}
 */
function makeAbortTriggerSpawn(controller, { cleanupConfirmed = true } = {}) {
  return (shell, args, spawnOpts) => {
    if (cleanupConfirmed && process.platform === 'linux') {
      const child = spawn(shell, args, { ...spawnOpts, cwd: process.cwd() })
      controller.abort()
      return child
    }
    const child = /** @type {any} */ (new EventEmitter())
    child.pid = 2147483001
    child.stdout = new EventEmitter()
    child.stderr = new EventEmitter()
    let fallbackClose = setTimeout(() => child.emit('close', 1, null), 250)
    child.kill = (/** @type {NodeJS.Signals} */ signal) => {
      clearTimeout(fallbackClose)
      if (cleanupConfirmed) queueMicrotask(() => child.emit('close', null, signal))
      return true
    }
    queueMicrotask(() => controller.abort())
    return child
  }
}

// ---- resolveToplevel -------------------------------------------------------

test('resolveToplevel：非 git 目录报错', async () => {
  const git = new FakeGit()
  git.on(['rev-parse', '--show-toplevel'], FAIL('not a git repository'))
  const r = await resolveToplevel(git, 'C:/nowhere', undefined)
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /git/i)
})

test('resolveToplevel：返回规范化顶层路径', async () => {
  const git = new FakeGit()
  git.on(['rev-parse', '--show-toplevel'], OK('C:/repo\n'))
  const r = await resolveToplevel(git, 'C:/repo/src', undefined)
  assert.equal(r.ok, true)
  assert.equal(r.root, 'C:/repo')
})

// ---- begin -----------------------------------------------------------------

test('begin：等待 vault 锁期间取消时返回取消错误', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const root = join(tmp, 'repo')
  let firstInside = false
  /** @type {((value?: unknown) => void) | undefined} */
  let release
  const gate = new Promise((r) => { release = r })
  const p1 = withLock(cfg.vault, async () => {
    firstInside = true
    await gate
  })
  while (!firstInside) await new Promise((r) => setTimeout(r, 5))

  const ac = new AbortController()
  const p2 = begin({ root, task: 'T', cfg, git: new FakeGit(), repo: null, signal: ac.signal })
  await new Promise((r) => setTimeout(r, 50))
  ac.abort()
  assert.ok(release, 'release 应已赋值')
  release()

  await p1
  const result = await p2
  assert.equal(result.ok, false)
  assert.match(result.error ?? '', /取消|abort/i)
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：分支与状态预检取消时返回取消结果并停止创建', async () => {
  for (const abortAt of ['branch', 'status']) {
    const tmp = makeTmp()
    const cfg = baseCfg(tmp)
    const git = new FakeGit()
    const controller = new AbortController()
    if (abortAt === 'branch') {
      git.on(['branch', '--show-current'], () => {
        controller.abort()
        return { ...FAIL('operation aborted'), aborted: true }
      })
    } else {
      git.on(['branch', '--show-current'], OK('main\n'))
      git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
      git.on(['show-ref', '--verify', 'refs/heads/wtm/t'], FAIL())
      git.on(['status', '--porcelain'], () => {
        controller.abort()
        return { ...FAIL('operation aborted'), aborted: true }
      })
    }

    try {
      const result = await begin({ root: 'C:/repo', task: 'T', cfg, git, repo: null, signal: controller.signal })
      assert.equal(result.ok, false)
      assert.equal(result.cancelled, true, `${abortAt}: ${JSON.stringify(result)}`)
      assert.match(result.error ?? '', /取消|abort/i)
      assert.equal(git.calls.some(({ args }) => args[0] === 'worktree' && args[1] === 'add'), false)
      assert.equal(loadLedger(cfg.vault).records.length, 0)
    } finally {
      rmSync(tmp, { recursive: true, force: true })
    }
  }
})

test('begin：创建前检查：任务校验、重复任务、基分支存在、分支不冲突', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', 'refs/heads/wtm/add-search'], FAIL())
  git.on(['status', '--porcelain'], OK(''))
  git.on(['worktree', 'add', join(tmp, 'vault', 'add-search'), '-b', 'wtm/add-search', 'refs/heads/main'], OK())

  // 重复任务
  const r1 = await begin({ root: 'C:/repo', task: 'Add Search', cfg, git, repo: null })
  assert.equal(r1.ok, true)
  const r2 = await begin({ root: 'C:/repo', task: 'Add Search', cfg, git, repo: null })
  assert.equal(r2.ok, false)
  assert.match(r2.error ?? '', /已存在/)

  // 分支派生与账本
  const ledger = loadLedger(cfg.vault)
  assert.equal(ledger.records.length, 1)
  assert.equal(ledger.records[0].branch, 'wtm/add-search')
  assert.equal(ledger.records[0].base, 'main')
  assert.equal(ledger.records[0].path, join(tmp, 'vault', 'add-search'))
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：vault 位于仓库工作树内时拒绝（防主工作区被弄脏）', async () => {
  const tmp = makeTmp()
  const git = new FakeGit()
  const r = await begin({ root: 'C:/repo', task: 'T', cfg: baseCfg(join('C:/repo', '.wtm-vault')), git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /vault/)
  assert.equal(git.calls.length, 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：vault 的 .. 路径别名解析到仓库内时拒绝', async () => {
  const tmp = makeTmp()
  const root = join(tmp, 'repo')
  const alias = join(tmp, 'repo-alias')
  mkdirSync(root, { recursive: true })
  mkdirSync(alias, { recursive: true })
  const git = new FakeGit()
  const cfg = { ...baseCfg(tmp), vault: `${alias}/../repo/.wtm-vault` }
  try {
    const r = await begin({ root, task: 'T', cfg, git, repo: null })
    assert.equal(r.ok, false)
    assert.match(r.error ?? '', /vault/)
    assert.equal(git.calls.length, 0)
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('begin：指向仓库内目录的 vault 符号链接时拒绝', async () => {
  const tmp = makeTmp()
  const root = join(tmp, 'repo')
  const link = join(tmp, 'vault-link')
  mkdirSync(root, { recursive: true })
  symlinkSync(root, link, process.platform === 'win32' ? 'junction' : 'dir')
  const git = new FakeGit()
  const cfg = { ...baseCfg(tmp), vault: join(link, '.wtm-vault') }
  try {
    const r = await begin({ root, task: 'T', cfg, git, repo: null })
    assert.equal(r.ok, false)
    assert.match(r.error ?? '', /vault/)
    assert.equal(git.calls.length, 0)
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('begin：普通文件符号链接后接 .. 时以 ENOTDIR 拒绝', { skip: process.platform === 'win32' }, async () => {
  const tmp = makeTmp()
  const root = join(tmp, 'repo')
  const outside = join(tmp, 'outside')
  const file = join(outside, 'regular-file')
  const link = join(root, 'link')
  const vault = join(outside, 'vault')
  const worktreePath = join(vault, 'task')
  mkdirSync(root, { recursive: true })
  mkdirSync(outside, { recursive: true })
  fs.writeFileSync(file, '')
  symlinkSync(file, link)

  const cfg = { ...baseCfg(tmp), vault: `link${sep}..${sep}vault` }
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', 'refs/heads/wtm/task'], FAIL())
  git.on(['status', '--porcelain'], OK())
  git.on(['worktree', 'add', worktreePath, '-b', 'wtm/task', 'refs/heads/main'], OK())

  try {
    const result = await begin({ root, task: 'Task', cfg, git, repo: null })
    assert.equal(result.ok, false)
    assert.match(result.error ?? '', /ENOTDIR|not a directory|不是目录/i)
    assert.equal(git.called(['worktree', 'add', worktreePath, '-b', 'wtm/task', 'refs/heads/main']), false)
    assert.equal(fs.existsSync(vault), false)
    assert.equal(fs.existsSync(worktreePath), false)
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('begin：悬空符号链接后接 .. 时以 ENOENT 拒绝', { skip: process.platform === 'win32' }, async () => {
  const tmp = makeTmp()
  const root = join(tmp, 'repo')
  const outside = join(tmp, 'outside')
  const missingTarget = join(outside, 'missing-file')
  const link = join(root, 'link')
  const vault = join(outside, 'vault')
  const worktreePath = join(vault, 'task')
  mkdirSync(root, { recursive: true })
  mkdirSync(outside, { recursive: true })
  symlinkSync(missingTarget, link)

  const cfg = { ...baseCfg(tmp), vault: `link${sep}..${sep}vault` }
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', 'refs/heads/wtm/task'], FAIL())
  git.on(['status', '--porcelain'], OK())
  git.on(['worktree', 'add', worktreePath, '-b', 'wtm/task', 'refs/heads/main'], OK())

  try {
    const result = await begin({ root, task: 'Task', cfg, git, repo: null })
    assert.equal(result.ok, false)
    assert.match(result.error ?? '', /ENOENT|no such file|not found/i)
    assert.equal(git.called(['worktree', 'add', worktreePath, '-b', 'wtm/task', 'refs/heads/main']), false)
    assert.equal(fs.existsSync(vault), false)
    assert.equal(fs.existsSync(worktreePath), false)
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('begin：相对 vault 配置保留目录符号链接与 .. 的平台语义', async () => {
  const tmp = makeTmp()
  const root = join(tmp, 'repo')
  const outside = join(tmp, 'outside')
  const link = join(root, 'link')
  const followsLinkBeforeParent = process.platform !== 'win32'
  const vault = followsLinkBeforeParent ? join(tmp, 'vault') : join(root, 'vault')
  const worktreePath = join(vault, 'task')
  mkdirSync(root, { recursive: true })
  mkdirSync(outside, { recursive: true })
  symlinkSync(outside, link, process.platform === 'win32' ? 'junction' : 'dir')

  const cfg = { ...baseCfg(tmp), vault: `link${sep}..${sep}vault` }
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', 'refs/heads/wtm/task'], FAIL())
  git.on(['status', '--porcelain'], OK())
  git.on(['worktree', 'add', worktreePath, '-b', 'wtm/task', 'refs/heads/main'], OK())

  try {
    const result = await begin({ root, task: 'Task', cfg, git, repo: null })
    if (followsLinkBeforeParent) {
      assert.equal(result.ok, true)
      assert.equal(result.path, worktreePath)
      assert.equal(git.called(['worktree', 'add', worktreePath, '-b', 'wtm/task', 'refs/heads/main']), true)
      assert.equal(fs.existsSync(join(root, 'vault')), false)
      assert.equal(loadLedger(vault).records[0].path, worktreePath)
    } else {
      assert.equal(result.ok, false)
      assert.match(result.error ?? '', /vault/)
      assert.equal(git.calls.length, 0)
      assert.equal(fs.existsSync(vault), false)
    }
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('begin：任务名非法直接报错，不执行任何 git 写操作', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const r = await begin({ root: 'C:/repo', task: '   ', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.equal(git.calls.length, 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：Windows 设备名任务在任何 git 调用前拒绝', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const r = await begin({ root: 'C:/repo', task: 'CON', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /Windows.*设备名/)
  assert.equal(git.calls.length, 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：显式分支非法报错', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const r = await begin({ root: 'C:/repo', task: 'T', branch: '-evil', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /分支/i)
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：detached HEAD 时要求显式 base', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK(''))
  const r = await begin({ root: 'C:/repo', task: 'T', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /base/i)
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：基分支不存在报错', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('develop\n'))
  git.on(['show-ref', '--verify', 'refs/heads/develop'], FAIL('unknown revision'))
  git.on(['rev-parse', '--verify', 'HEAD'], OK('abc\n')) // 仓库有提交 → 无空仓库提示
  const r = await begin({ root: 'C:/repo', task: 'T', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /develop/)
  assert.doesNotMatch(r.error ?? '', /尚无任何提交/)
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：空仓库（无提交）时报出明确提示', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], FAIL('unknown revision'))
  git.on(['rev-parse', '--verify', 'HEAD'], FAIL('unknown revision'))
  const r = await begin({ root: 'C:/repo', task: 'T', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /尚无任何提交/)
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：目标分支已存在于 git 时拒绝', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', 'refs/heads/wtm/t'], OK('abc\n'))
  const r = await begin({ root: 'C:/repo', task: 'T', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /已存在/)
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：基分支有未提交改动时产生警告但不中断', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', 'refs/heads/wtm/t'], FAIL())
  git.on(['status', '--porcelain'], OK(' M dirty.txt\n'))
  git.on(['worktree', 'add', join(tmp, 'vault', 't'), '-b', 'wtm/t', 'refs/heads/main'], OK())
  const r = await begin({ root: 'C:/repo', task: 'T', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.ok((r.warnings ?? []).some((w) => /未提交/i.test(w)))
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：主工作区 git status 失败时终止创建', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', 'refs/heads/wtm/t'], FAIL())
  git.on(['status', '--porcelain'], FAIL('fatal: index file smaller than expected'))
  git.on(['worktree', 'add', join(tmp, 'vault', 't'), '-b', 'wtm/t', 'refs/heads/main'], OK())

  const r = await begin({ root: 'C:/repo', task: 'T', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /主工作区.*状态失败/)
  assert.match(r.error ?? '', /index file smaller than expected/)
  assert.equal(git.count(['worktree', 'add', join(tmp, 'vault', 't'), '-b', 'wtm/t', 'refs/heads/main']), 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：worktree add 失败透传 stderr', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', 'refs/heads/wtm/t'], FAIL())
  git.on(['status', '--porcelain'], OK(''))
  git.on(['worktree', 'add', join(tmp, 'vault', 't'), '-b', 'wtm/t', 'refs/heads/main'], FAIL('fatal: could not create worktree'))
  const r = await begin({ root: 'C:/repo', task: 'T', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /could not create/)
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：worktree add 失败或中止后即使列表匹配也不自动清理', async () => {
  const tmp = makeTmp()
  const cases = [
    { task: 'Failed Add', aborted: false },
    { task: 'Aborted Add', aborted: true },
  ]

  for (const item of cases) {
    const cfg = baseCfg(tmp)
    const slug = slugifyTask(item.task)
    const worktreePath = join(tmp, 'vault', slug)
    const branch = `wtm/${slug}`
    const git = new FakeGit()
    const controller = new AbortController()
    git.on(['branch', '--show-current'], OK('main\n'))
    git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
    git.on(['show-ref', '--verify', `refs/heads/${branch}`], FAIL())
    git.on(['status', '--porcelain'], OK(''))
    git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES(
      `worktree ${worktreePath}\nHEAD deadbeef\nbranch refs/heads/${branch}\n`,
    ))
    git.on(['worktree', 'add', worktreePath, '-b', branch, 'refs/heads/main'], () => {
      if (item.aborted) {
        controller.abort()
        return { ok: false, code: -1, stdout: '', stderr: '', aborted: true }
      }
      return FAIL('fatal: worktree add left possible partial state')
    })

    const result = await begin({
      root: 'C:/repo', task: item.task, branch, cfg, git, repo: null,
      signal: controller.signal,
    })

    assert.equal(result.ok, false)
    assert.ok(result.warnings?.some((warning) => /手动检查/.test(warning)), JSON.stringify(result.warnings))
    assert.ok(result.warnings?.some((warning) => warning.includes(JSON.stringify(worktreePath))), JSON.stringify(result.warnings))
    assert.ok(result.warnings?.some((warning) => warning.includes(JSON.stringify(branch))), JSON.stringify(result.warnings))
    assert.equal(git.count(['worktree', 'remove', '--force', worktreePath]), 0)
    assert.equal(git.count(['branch', '-D', branch]), 0)
    if (item.aborted) assert.match(result.error ?? '', /取消|abort/i)
  }

  rmSync(tmp, { recursive: true, force: true })
})

test('begin：add 中止后 Git 已登记工作区和分支时写入恢复账本', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const task = 'T'
  const worktreePath = join(cfg.vault, 't')
  const branch = 'wtm/t'
  const controller = new AbortController()
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', `refs/heads/${branch}`], FAIL())
  git.on(['status', '--porcelain'], OK(''))
  git.on(['worktree', 'add', worktreePath, '-b', branch, 'refs/heads/main'], () => {
    mkdirSync(worktreePath, { recursive: true })
    controller.abort()
    return { ...FAIL('operation aborted'), aborted: true }
  })
  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES(
    `worktree ${worktreePath}\nHEAD ${'2'.repeat(40)}\nbranch refs/heads/${branch}\n`,
  ))

  try {
    const result = await begin({ root: 'C:/repo', task, cfg, git, repo: null, signal: controller.signal })
    assert.equal(result.ok, false)
    assert.equal(result.cancelled, true, JSON.stringify(result))
    assert.match(result.error ?? '', /取消|aborted/i)
    const records = loadLedger(cfg.vault).records
    assert.equal(records.length, 1, 'interrupted creation must retain the registered resource in the ledger')
    assert.equal(records[0].task, task)
    assert.equal(records[0].branch, branch)
    assert.equal(records[0].path, worktreePath)
    assert.ok(result.warnings?.some((warning) => /已登记|账本.*恢复/.test(warning)), JSON.stringify(result.warnings))
    assert.equal(git.count(['worktree', 'remove', '--force', worktreePath]), 0)
    assert.equal(git.count(['branch', '-D', branch]), 0)
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('begin：add 中止后工作区清单不可用时写入恢复账本', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const task = 'T'
  const worktreePath = join(cfg.vault, 't')
  const branch = 'wtm/t'
  const controller = new AbortController()
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', `refs/heads/${branch}`], FAIL())
  git.on(['status', '--porcelain'], OK(''))
  git.on(['worktree', 'add', worktreePath, '-b', branch, 'refs/heads/main'], () => {
    controller.abort()
    return { ...FAIL('operation aborted'), aborted: true }
  })
  git.on(['worktree', 'list', '--porcelain', '-z'], FAIL('cannot inspect worktree list'))

  try {
    const result = await begin({ root: 'C:/repo', task, cfg, git, repo: null, signal: controller.signal })
    assert.equal(result.ok, false)
    assert.equal(result.cancelled, true, JSON.stringify(result))
    const records = loadLedger(cfg.vault).records
    assert.equal(records.length, 1, 'unconfirmed add resources must remain recoverable in the ledger')
    assert.equal(records[0].task, task)
    assert.equal(records[0].branch, branch)
    assert.equal(records[0].path, worktreePath)
    assert.ok(result.warnings?.some((warning) => /恢复|账本/.test(warning)), JSON.stringify(result.warnings))
    assert.equal(fs.existsSync(join(cfg.vault, '.lock')), false, 'cancellation must release the vault lock')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('begin：成功 add 后发生失败时独立尝试清理并保留两项清理错误', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const worktreePath = join(tmp, 'vault', 't')
  const branch = 'wtm/t;echo'
  const indexPath = join(cfg.vault, 'index.json')
  const removeDetail = 'cannot remove "worktree"; echo unsafe\nnext line'
  const branchDetail = 'cannot delete "branch"; echo unsafe\nnext line'
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', `refs/heads/${branch}`], FAIL())
  git.on(['status', '--porcelain'], OK(''))
  git.on(['worktree', 'add', worktreePath, '-b', branch, 'refs/heads/main'], () => {
    mkdirSync(indexPath)
    return OK()
  })
  git.on(['worktree', 'remove', '--force', worktreePath], () => { throw new Error(removeDetail) })
  git.on(['branch', '-D', branch], FAIL(branchDetail))

  const result = await begin({ root: 'C:/repo', task: 'T', branch, cfg, git, repo: null })

  assert.equal(result.ok, false)
  assert.ok(git.called(['worktree', 'remove', '--force', worktreePath]))
  assert.ok(git.called(['branch', '-D', branch]), 'branch cleanup should run after worktree cleanup throws')
  assert.ok(result.warnings?.some((warning) => warning.includes(JSON.stringify(removeDetail))), JSON.stringify(result.warnings))
  assert.ok(result.warnings?.some((warning) => warning.includes(JSON.stringify(branchDetail))), JSON.stringify(result.warnings))
  assert.ok(result.warnings?.some((warning) => /工作区创建未完成，且回滚失败/.test(warning)), JSON.stringify(result.warnings))
  assert.ok(result.warnings?.some((warning) => /手动检查/.test(warning)), JSON.stringify(result.warnings))
  assert.ok(result.warnings?.every((warning) => !/git worktree remove --force|git branch -D/.test(warning)), JSON.stringify(result.warnings))

  rmSync(tmp, { recursive: true, force: true })
})

test('begin：回滚命令返回失败对象时保留失败警告', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const worktreePath = join(tmp, 'vault', 't')
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', 'refs/heads/wtm/t'], FAIL())
  git.on(['status', '--porcelain'], OK(''))
  git.on(['worktree', 'add', worktreePath, '-b', 'wtm/t', 'refs/heads/main'], OK())
  git.on(['worktree', 'remove', '--force', worktreePath], FAIL(''))
  git.on(['branch', '-D', 'wtm/t'], FAIL(''))

  const r = await begin({
    root: 'C:/repo',
    task: 'T',
    cfg,
    git,
    repo: { triggers: { on_begin: ['broken-trigger'] } },
    // 让 on_begin 在 worktree 创建后抛错，从而进入回滚路径。
    triggerSpawn: () => ({}),
  })

  assert.equal(r.ok, false)
  assert.ok((r.warnings ?? []).some((w) => /回滚失败/.test(w)), JSON.stringify(r))
  assert.ok((r.warnings ?? []).some((w) => /工作区回滚失败："命令返回失败"/.test(w)), JSON.stringify(r))
  assert.ok((r.warnings ?? []).some((w) => /分支回滚失败："命令返回失败"/.test(w)), JSON.stringify(r))
  assert.ok((r.warnings ?? []).every((w) => !/git worktree remove --force|git branch -D/.test(w)), JSON.stringify(r))
  assert.ok(!(r.warnings ?? []).some((w) => /已回滚/.test(w)), JSON.stringify(r))
  assert.ok(git.called(['branch', '-D', 'wtm/t']))
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：执行 on_begin 触发器并附带警告', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', 'refs/heads/wtm/t'], FAIL())
  git.on(['status', '--porcelain'], OK(''))
  git.on(['worktree', 'add', join(tmp, 'vault', 't'), '-b', 'wtm/t', 'refs/heads/main'], OK())
  const repo = { triggers: { on_begin: ['install.sh', 'fail.sh'] } }
  let triggerIdx = 0
  const r = await begin({
    root: 'C:/repo', task: 'T', cfg, git, repo,
    triggerSpawn: () => {
      // 第一条成功、第二条失败（通过外部状态计数，避免闭包引用未初始化的 r）
      const c = /** @type {any} */ (new EventEmitter())
      c.stdout = new EventEmitter()
      c.stderr = new EventEmitter()
      const fail = triggerIdx === 1
      triggerIdx += 1
      queueMicrotask(() => {
        if (fail) {
          c.stderr.emit('data', Buffer.from('boom'))
          c.emit('close', 3, null)
        } else {
          c.emit('close', 0, null)
        }
      })
      return c
    },
  })
  assert.equal(r.ok, true)
  assert.ok((r.warnings ?? []).some((w) => /boom/.test(w)), JSON.stringify(r.warnings))
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：on_begin 取消时只在清理确认后回滚，不确定时保留账本资源', async () => {
  for (const cleanupConfirmed of [true, false]) {
    const tmp = makeTmp()
    const cfg = baseCfg(tmp)
    const wtPath = join(tmp, 'vault', 't')
    const git = new FakeGit()
    git.on(['branch', '--show-current'], OK('main\n'))
    git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
    git.on(['show-ref', '--verify', 'refs/heads/wtm/t'], FAIL())
    git.on(['status', '--porcelain'], OK(''))
    git.on(['worktree', 'add', wtPath, '-b', 'wtm/t', 'refs/heads/main'], OK())
    git.on(['worktree', 'remove', '--force', wtPath], OK())
    git.on(['branch', '-D', 'wtm/t'], OK())
    const controller = new AbortController()

    try {
      const result = await begin({
        root: 'C:/repo', task: 'T', cfg, git,
        repo: { triggers: { on_begin: ['cancel-during-setup'] } },
        signal: controller.signal,
        triggerSpawn: makeAbortTriggerSpawn(controller, { cleanupConfirmed }),
      })

      assert.equal(result.ok, false)
      assert.equal(result.cancelled, true, JSON.stringify(result))
      assert.match(result.error ?? '', /取消|abort/i)
      const cleanupWasConfirmed = cleanupConfirmed && process.platform === 'linux'
      if (cleanupWasConfirmed) {
        assert.equal(git.count(['worktree', 'remove', '--force', wtPath]), 1, JSON.stringify(result))
        assert.equal(git.count(['branch', '-D', 'wtm/t']), 1)
        assert.equal(loadLedger(cfg.vault).records.length, 0)
        assert.ok(result.warnings?.some((warning) => /已回滚/.test(warning)), JSON.stringify(result))
      } else {
        assert.equal(git.count(['worktree', 'remove', '--force', wtPath]), 0)
        assert.equal(git.count(['branch', '-D', 'wtm/t']), 0)
        assert.equal(loadLedger(cfg.vault).records[0]?.path, wtPath)
        assert.ok(result.warnings?.some((warning) => /清理未能确认|保留.*工作区|手动检查/.test(warning)), JSON.stringify(result))
      }
      assert.equal(fs.existsSync(join(cfg.vault, '.lock')), false, 'cancellation must release the vault lock')
    } finally {
      rmSync(tmp, { recursive: true, force: true })
    }
  }
})

test('begin：on_begin 清理不确定或回滚失败时将资源写入账本', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const wtPath = join(tmp, 'vault', 't')
  const branch = 'wtm/t'
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', `refs/heads/${branch}`], FAIL())
  git.on(['status', '--porcelain'], OK(''))
  git.on(['worktree', 'add', wtPath, '-b', branch, 'refs/heads/main'], OK())
  git.on(['worktree', 'remove', '--force', wtPath], FAIL('worktree is still in use'))
  git.on(['branch', '-D', branch], FAIL('branch remains checked out'))
  const controller = new AbortController()

  try {
    const result = await begin({
      root: 'C:/repo', task: 'T', cfg, git,
      repo: { triggers: { on_begin: ['cancel-during-setup'] } },
      signal: controller.signal,
      triggerSpawn: makeAbortTriggerSpawn(controller),
    })

    assert.equal(result.ok, false)
    assert.equal(result.cancelled, true, JSON.stringify(result))
    if (process.platform === 'linux') {
      assert.equal(git.count(['worktree', 'remove', '--force', wtPath]), 1, JSON.stringify(result))
      assert.equal(git.count(['branch', '-D', branch]), 1)
      assert.equal(loadLedger(cfg.vault).records[0]?.path, wtPath, 'unremoved worktree must remain recoverable')
      assert.equal(loadLedger(cfg.vault).records[0]?.branch, branch, 'remaining branch must remain recoverable')
      assert.ok(result.warnings?.some((warning) => /回滚|恢复/.test(warning) && /写入账本/.test(warning)), JSON.stringify(result))
    } else {
      assert.equal(git.count(['worktree', 'remove', '--force', wtPath]), 0, JSON.stringify(result))
      assert.equal(git.count(['branch', '-D', branch]), 0)
      assert.equal(loadLedger(cfg.vault).records[0]?.path, wtPath, 'uncertain trigger cleanup must keep the worktree recoverable')
      assert.equal(loadLedger(cfg.vault).records[0]?.branch, branch, 'uncertain trigger cleanup must keep the branch recoverable')
      assert.ok(result.warnings?.some((warning) => /清理未能确认|保留.*工作区|手动检查/.test(warning)), JSON.stringify(result))
    }
    assert.equal(fs.existsSync(join(cfg.vault, '.lock')), false, 'cancellation must release the vault lock')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('begin：触发器正常返回后 signal 在调用方恢复前取消时保留新资源', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const wtPath = join(tmp, 'vault', 't')
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', 'refs/heads/wtm/t'], FAIL())
  git.on(['status', '--porcelain'], OK(''))
  git.on(['worktree', 'add', wtPath, '-b', 'wtm/t', 'refs/heads/main'], OK())
  // Include the begin preflight result checks, then abort on the trigger handoff check.
  /** @type {any} */
  const signal = {
    reads: 0,
    get aborted() { this.reads += 1; return this.reads >= 17 },
    addEventListener() {},
    removeEventListener() {},
  }

  try {
    const result = await begin({
      root: 'C:/repo', task: 'T', cfg, git, signal,
      repo: { triggers: { on_begin: ['completed-trigger'] } },
      triggerSpawn: () => {
        const child = /** @type {any} */ (new EventEmitter())
        child.pid = 2147483004
        child.exitCode = null
        child.signalCode = null
        child.stdout = new EventEmitter()
        child.stderr = new EventEmitter()
        child.stdin = { end() {} }
        queueMicrotask(() => child.emit('close', 0, null))
        return child
      },
    })

    assert.equal(result.ok, false, JSON.stringify({ result, reads: signal.reads }))
    assert.equal(result.cancelled, true, JSON.stringify({ result, reads: signal.reads }))
    assert.match(result.error ?? '', /触发器清理未能确认/)
    assert.equal(git.count(['worktree', 'remove', '--force', wtPath]), 0, 'unconfirmed trigger cleanup must not authorize rollback')
    assert.equal(git.count(['branch', '-D', 'wtm/t']), 0)
    assert.equal(loadLedger(cfg.vault).records[0]?.path, wtPath, JSON.stringify(result))
    assert.ok(result.warnings?.some((warning) => /清理未能确认/.test(warning)), JSON.stringify(result))
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('begin：seed 文件从主仓库复制到新工作区', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', 'refs/heads/wtm/t'], FAIL())
  git.on(['status', '--porcelain'], OK(''))
  git.on(['worktree', 'add', join(tmp, 'vault', 't'), '-b', 'wtm/t', 'refs/heads/main'], OK())
  const repo = { seed: { files: ['docs/env.txt'] } }
  const r = await begin({ root: 'C:/repo', task: 'T', cfg, git, repo })
  assert.equal(r.ok, true)
  rmSync(tmp, { recursive: true, force: true })
})

// ---- mergeTask -------------------------------------------------------------

/**
 * @param {string} tmp
 * @param {{taskDirty?: boolean, baseDirty?: boolean, taskBranch?: string}} [opts]
 */
function mergeFixture(tmp, { taskDirty = false, baseDirty = false, taskBranch = 'wtm/t' } = {}) {
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const vault = cfg.vault
  const taskPath = join(vault, 't')
  const abandonPath = join(vault, '.t.abandon-pending')
  const taskGitDir = join(tmp, 'task-gitdir')
  // 预置一条任务记录，并真实创建工作区目录（stale 判定依赖目录实存）
  const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, {
    task: 'T', branch: 'wtm/t', base: 'main',
    path: join(vault, 't'), createdAt: 'c', updatedAt: 'u',
  })
  saveLedger(vault, ledger)
  mkdirSync(join(vault, 't'), { recursive: true })
  mkdirSync(taskGitDir, { recursive: true })
  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES('worktree C:/repo\nHEAD 1'.padEnd(40, '1') + '\nbranch refs/heads/main\n\nworktree ' + join(vault, 't') + '\nHEAD 2'.padEnd(40, '2') + '\nbranch refs/heads/' + taskBranch + '\n'))
  // status 答案按 cwd 区分：任务工作区脏与否 / 基工作区脏与否
  git.on(['status', '--porcelain'], (/** @type {{cwd: string | undefined}} */ ctx) => {
    if (ctx.cwd === join(vault, 't')) return taskDirty ? OK(' M f.txt\n') : OK('')
    return baseDirty ? OK(' M base.txt\n') : OK('')
  })
  git.on(['status', '--porcelain=v2', '--branch', '--untracked-files=all'], (/** @type {{cwd: string | undefined}} */ ctx) => {
    if (ctx.cwd === taskPath || ctx.cwd === abandonPath) {
      return OK(`# branch.oid ${'2'.repeat(40)}\n# branch.head ${taskBranch}\n${taskDirty ? '? f.txt\n' : ''}`)
    }
    return OK(`# branch.oid ${'1'.repeat(40)}\n# branch.head main\n${baseDirty ? '? base.txt\n' : ''}`)
  })
  git.on(['worktree', 'move', taskPath, abandonPath], OK())
  git.on(['worktree', 'move', abandonPath, taskPath], OK())
  git.on(['rev-parse', '--absolute-git-dir'], (/** @type {{cwd: string | undefined}} */ ctx) => {
    if (ctx.cwd === taskPath || ctx.cwd === abandonPath) return OK(`${taskGitDir}\n`)
    return FAIL('unknown worktree')
  })
  git.on(['add', '-A'], OK())
  git.on(['commit', '-m', 'snapshot T'], OK('[wtm/t 9999999] snapshot T'))
  // mergeIntoBase 的新检查：主工作区当前分支 == 账本基分支；任务分支未合并
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['merge-base', '--is-ancestor', 'refs/heads/wtm/t', 'HEAD'], FAIL('not an ancestor', 1))
  git.on(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main'], OK('Merge made by the "ort" strategy.'))
  git.on(['config', '--get', 'branch.main.mergeOptions'], FAIL('', 1))
  git.on(['rev-parse', '--verify', 'refs/heads/wtm/t^{commit}'], () => OK(`${git.count(['commit', '-m', 'snapshot T']) > 0 ? '9'.repeat(40) : '2'.repeat(40)}\n`))
  git.on(['rev-parse', '--verify', 'HEAD^{commit}'], (/** @type {{cwd: string | undefined}} */ ctx) => {
    if (ctx.cwd === taskPath || ctx.cwd === abandonPath) {
      return OK(`${git.count(['commit', '-m', 'snapshot T']) > 0 ? '9'.repeat(40) : '2'.repeat(40)}\n`)
    }
    return OK(`${'1'.repeat(40)}\n`)
  })
  git.on(['rev-parse', '--verify', 'HEAD^'], (/** @type {{cwd: string | undefined}} */ ctx) => {
    if (ctx.cwd === taskPath || ctx.cwd === abandonPath) return OK(`${'2'.repeat(40)}\n`)
    return FAIL('unknown commit parent')
  })
  git.on(['merge-tree', '--write-tree', `${'1'.repeat(40)}`, `${'2'.repeat(40)}`], OK(`${'3'.repeat(40)}\n`))
  git.on(['merge-tree', '--write-tree', `${'1'.repeat(40)}`, `${'9'.repeat(40)}`], OK(`${'3'.repeat(40)}\n`))
  git.on(['rev-parse', '--git-path', 'hooks'], OK('.git/hooks\n'))
  return { cfg, git, vault, taskGitDir }
}

test('mergeTask：干净任务直接合并并更新记录', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const r = await mergeTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.equal(r.committed, false)
  assert.equal(r.merged, true)
  assert.ok(git.called(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main'], 'C:/repo'))
  const ledger = loadLedger(vault)
  assert.equal(ledger.records[0].updatedAt !== 'u', true)
  rmSync(tmp, { recursive: true, force: true })
})

test('mergeTask：祖先检查后的 Already up to date 不触发 on_merge', async () => {
  const tmp = makeTmp()
  const { cfg, git } = mergeFixture(tmp)
  git.on(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main'], OK('Already up to date.\n'))
  let triggerCalls = 0

  const r = await mergeTask({
    root: 'C:/repo',
    task: 'T',
    mode: 'commit',
    cfg,
    git,
    repo: { triggers: { on_merge: ['deploy.sh'] } },
    triggerSpawn: () => {
      triggerCalls += 1
      throw new Error('on_merge should not run when git did not create a merge')
    },
  })

  assert.equal(r.ok, true)
  assert.equal(r.merged, false)
  assert.equal(triggerCalls, 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('mergeTask：Already up to date 结果交接时取消不更新账本或报告成功', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const controller = new AbortController()
  git.on(['merge-base', '--is-ancestor', 'refs/heads/wtm/t', 'HEAD'], OK())
  let branchHeadReads = 0
  git.on(['rev-parse', '--verify', 'refs/heads/wtm/t^{commit}'], () => {
    branchHeadReads += 1
    if (branchHeadReads === 2) queueMicrotask(() => queueMicrotask(() => controller.abort()))
    return OK(`${'2'.repeat(40)}\n`)
  })

  try {
    const result = await mergeTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null, signal: controller.signal })
    assert.equal(result.ok, false)
    assert.equal(result.cancelled, true, JSON.stringify(result))
    assert.match(result.error ?? '', /取消|aborted/i)
    assert.equal(loadLedger(vault).records[0].updatedAt, 'u', 'cancelled handoff must not advance ledger bookkeeping')
    assert.equal(fs.existsSync(join(vault, 't')), true, 'the task worktree remains intact')
    assert.equal(git.called(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main'], 'C:/repo'), false)
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('mergeTask/finishTask：合并与 on_merge 取消时保留工作区和管理记录', async () => {
  for (const operation of [mergeTask, finishTask]) {
    const tmp = makeTmp()
    const { cfg, git, vault } = mergeFixture(tmp)
    const controller = new AbortController()
    const opts = {
      root: 'C:/repo', task: 'T', mode: 'commit', cfg, git,
      repo: { triggers: { on_merge: ['cancel-after-merge'] } },
      signal: controller.signal,
      triggerSpawn: makeAbortTriggerSpawn(controller),
    }

    try {
      const result = await operation(opts)
      assert.equal(result.ok, false)
      assert.equal(result.cancelled, true)
      assert.match(result.error ?? '', /取消|abort/i)
      assert.ok(git.called(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main'], 'C:/repo'))
      assert.equal(fs.existsSync(join(vault, 't')), true)
      assert.equal(loadLedger(vault).records[0]?.updatedAt, 'u')
      assert.equal(git.count(['worktree', 'remove', join(vault, 't')]), 0)
    } finally {
      rmSync(tmp, { recursive: true, force: true })
    }
  }

  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const controller = new AbortController()
  git.on(['merge-base', '--is-ancestor', 'refs/heads/wtm/t', 'HEAD'], () => {
    controller.abort()
    return { ok: false, code: -1, stdout: '', stderr: 'operation aborted', aborted: true }
  })

  try {
    const result = await mergeTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null, signal: controller.signal })
    assert.equal(result.ok, false)
    assert.equal(result.cancelled, true)
    assert.match(result.error ?? '', /取消|abort/i)
    assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
    assert.equal(fs.existsSync(join(vault, 't')), true)
    assert.equal(loadLedger(vault).records[0]?.updatedAt, 'u')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('mergeTask：merge-base 致命失败时拒绝继续合并', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  git.on(['merge-base', '--is-ancestor', 'refs/heads/wtm/t', 'HEAD'], FAIL('fatal: bad object wtm/t'))

  const r = await mergeTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /fatal: bad object wtm\/t/)
  assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
  assert.equal(loadLedger(vault).records[0].updatedAt, 'u')
  rmSync(tmp, { recursive: true, force: true })
})

test('mergeTask/finishTask：git merge 中止时返回取消结果并保留工作区记录', async () => {
  for (const operation of [mergeTask, finishTask]) {
    const tmp = makeTmp()
    const { cfg, git, vault } = mergeFixture(tmp)
    const controller = new AbortController()
    git.on(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main'], () => {
      controller.abort()
      return { ok: false, code: -1, stdout: '', stderr: 'operation aborted', aborted: true }
    })

    try {
      const result = await operation({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null, signal: controller.signal })
      assert.equal(result.ok, false)
      assert.equal(result.cancelled, true, JSON.stringify(result))
      assert.match(result.error ?? '', /取消|abort/i)
      assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 1)
      assert.equal(fs.existsSync(join(vault, 't')), true)
      assert.equal(loadLedger(vault).records[0]?.updatedAt, 'u')
    } finally {
      rmSync(tmp, { recursive: true, force: true })
    }
  }
})

test('mergeTask/finishTask：基分支预检取消被保留为取消结果', async () => {
  for (const operation of [mergeTask, finishTask]) {
    const tmp = makeTmp()
    const { cfg, git, vault } = mergeFixture(tmp)
    const controller = new AbortController()
    git.on(['branch', '--show-current'], () => {
      controller.abort()
      return { ok: false, code: -1, stdout: '', stderr: 'operation aborted', aborted: true }
    })

    try {
      const result = await operation({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null, signal: controller.signal })
      assert.equal(result.ok, false)
      assert.equal(result.cancelled, true, JSON.stringify(result))
      assert.match(result.error ?? '', /取消|abort/i)
      assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
      assert.equal(fs.existsSync(join(vault, 't')), true)
      assert.equal(loadLedger(vault).records[0]?.updatedAt, 'u')
    } finally {
      rmSync(tmp, { recursive: true, force: true })
    }
  }
})

test('mergeTask/finishTask：合并前工作区、快照与主分支预检取消均保留取消状态', async () => {
  const worktreeListArgs = ['worktree', 'list', '--porcelain', '-z']
  for (const operation of [mergeTask, finishTask]) {
    for (const abortAt of ['worktree list', 'snapshot status', 'base branch', 'base status']) {
      const tmp = makeTmp()
      const { cfg, git, vault } = mergeFixture(tmp)
      const controller = new AbortController()
      const taskPath = join(vault, 't')

      if (abortAt === 'worktree list') {
        git.on(worktreeListArgs, () => {
          controller.abort()
          return { ok: false, code: -1, stdout: '', stderr: 'operation aborted', aborted: true }
        })
      } else if (abortAt === 'snapshot status') {
        git.on(['status', '--porcelain'], (/** @type {{cwd: string | undefined}} */ ctx) => {
          if (ctx.cwd === taskPath) {
            controller.abort()
            return OK('')
          }
          return OK('')
        })
      } else if (abortAt === 'base branch') {
        git.on(['branch', '--show-current'], () => {
          controller.abort()
          return OK('main\n')
        })
      } else {
        git.on(['status', '--porcelain'], (/** @type {{cwd: string | undefined}} */ ctx) => {
          if (ctx.cwd === taskPath) return OK('')
          controller.abort()
          return OK('')
        })
      }

      try {
        const result = await operation({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null, signal: controller.signal })
        assert.equal(result.ok, false)
        assert.equal(result.cancelled, true, `${operation.name}/${abortAt}: ${JSON.stringify(result)}`)
        assert.match(result.error ?? '', /取消|abort/i)
        assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
        assert.equal(fs.existsSync(taskPath), true)
        assert.equal(loadLedger(vault).records[0]?.updatedAt, 'u')
      } finally {
        rmSync(tmp, { recursive: true, force: true })
      }
    }
  }
})

test('mergeTask/finishTask：任务分支尖端预检取消被保留为取消结果', async () => {
  const branchHeadArgs = ['rev-parse', '--verify', 'refs/heads/wtm/t^{commit}']
  for (const operation of [mergeTask, finishTask]) {
    for (const abortAt of ['initial branch head', 'already-merged branch head']) {
      const tmp = makeTmp()
      const { cfg, git, vault } = mergeFixture(tmp)
      const controller = new AbortController()
      let branchHeadReads = 0
      git.on(branchHeadArgs, () => {
        branchHeadReads += 1
        const shouldAbort = abortAt === 'initial branch head'
          ? branchHeadReads === 1
          : branchHeadReads === 2
        if (shouldAbort) {
          controller.abort()
          return { ok: false, code: -1, stdout: '', stderr: 'operation aborted', aborted: true }
        }
        return OK(`${'2'.repeat(40)}\n`)
      })
      if (abortAt === 'already-merged branch head') {
        git.on(['merge-base', '--is-ancestor', 'refs/heads/wtm/t', 'HEAD'], OK())
      }

      try {
        const result = await operation({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null, signal: controller.signal })
        assert.equal(result.ok, false)
        assert.equal(result.cancelled, true, `${operation.name}/${abortAt}: ${JSON.stringify(result)}`)
        assert.match(result.error ?? '', /取消|abort/i)
        assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
        assert.equal(fs.existsSync(join(vault, 't')), true)
        assert.equal(loadLedger(vault).records[0]?.updatedAt, 'u')
      } finally {
        rmSync(tmp, { recursive: true, force: true })
      }
    }
  }
})

test('mergeTask：脏任务在 commit 模式下先快照提交再合并', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp, { taskDirty: true })
  const r = await mergeTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.equal(r.committed, true)
  assert.ok(git.called(['add', '-A'], join(vault, 't')))
  assert.ok(git.called(['commit', '-m', 'snapshot T'], join(vault, 't')))
  rmSync(tmp, { recursive: true, force: true })
})

test('mergeTask：refuse 模式下脏任务拒绝合并', async () => {
  const tmp = makeTmp()
  const { cfg, git } = mergeFixture(tmp, { taskDirty: true })
  const r = await mergeTask({ root: 'C:/repo', task: 'T', mode: 'refuse', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /未提交/)
  assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('mergeTask：refuse 模式第二次状态检查发现改动时拒绝快照提交', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  let taskStatusChecks = 0
  git.on(['status', '--porcelain'], (/** @type {{cwd: string | undefined}} */ ctx) => {
    if (ctx.cwd === taskPath) {
      taskStatusChecks += 1
      return taskStatusChecks === 1 ? OK('') : OK(' M race.txt\n')
    }
    return OK('')
  })

  const r = await mergeTask({ root: 'C:/repo', task: 'T', mode: 'refuse', cfg, git, repo: null })

  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /未提交/)
  assert.equal(git.count(['add', '-A']), 0)
  assert.equal(git.count(['commit', '-m', 'snapshot T']), 0)
  assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('mergeTask：基分支有未提交改动时拒绝（未提交改动检测）', async () => {
  const tmp = makeTmp()
  const { cfg, git } = mergeFixture(tmp, { baseDirty: true })
  const r = await mergeTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /基分支|未提交/)
  rmSync(tmp, { recursive: true, force: true })
})

test('mergeTask：记录不存在报错；工作区已消失报错并提示 purge', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const r1 = await mergeTask({ root: 'C:/repo', task: 'nope', cfg, git, repo: null })
  assert.equal(r1.ok, false)
  assert.match(r1.error ?? '', /不存在/)

    const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T', branch: 'wtm/t', base: 'main', path: 'P', createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES('worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n'))
  const r2 = await mergeTask({ root: 'C:/repo', task: 'T', cfg, git, repo: null })
  assert.equal(r2.ok, false)
  assert.match(r2.error ?? '', /工作区|purge/i)
  rmSync(tmp, { recursive: true, force: true })
})

// ---- finishTask ------------------------------------------------------------

test('finishTask：commit 模式执行 on_merge 触发器', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  git.on(['worktree', 'remove', join(vault, 't')], OK())
  git.on(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)], OK())
  /** @type {Array<{shell: string, args: string[], opts: object}>} */
  const triggerCalls = []
  const repo = { triggers: { on_merge: ['mark-merge'] } }
  const r = await finishTask({
    root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo,
    triggerSpawn: (shell, args, opts) => {
      triggerCalls.push({ shell, args, opts })
      const child = /** @type {any} */ (new EventEmitter())
      child.stdout = new EventEmitter()
      child.stderr = new EventEmitter()
      queueMicrotask(() => child.emit('close', 0, null))
      return child
    },
  })
  assert.equal(r.ok, true)
  assert.equal(triggerCalls.length, 1)
  assert.equal(/** @type {any} */ (triggerCalls[0].opts).cwd, 'C:/repo')
  assert.equal(/** @type {any} */ (triggerCalls[0].opts).env.WTM_TASK, 'T')
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：移除工作区失败时保留 on_merge 触发器警告', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  git.on(['worktree', 'remove', join(vault, 't')], FAIL('cannot remove worktree'))

  const r = await finishTask({
    root: 'C:/repo',
    task: 'T',
    mode: 'commit',
    cfg,
    git,
    repo: { triggers: { on_merge: ['broken-merge-hook'] } },
    triggerSpawn: () => {
      const child = /** @type {any} */ (new EventEmitter())
      child.stdout = new EventEmitter()
      child.stderr = new EventEmitter()
      queueMicrotask(() => {
        child.stderr.emit('data', Buffer.from('merge hook failed'))
        child.emit('close', 1, null)
      })
      return child
    },
  })

  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /cannot remove worktree/)
  assert.ok(r.warnings?.some((w) => /broken-merge-hook/.test(w)), JSON.stringify(r))
  assert.ok(r.warnings?.some((w) => /merge hook failed/.test(w)), JSON.stringify(r))
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：任务分支已合并时跳过 on_merge 触发器', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  git.on(['merge-base', '--is-ancestor', 'refs/heads/wtm/t', 'HEAD'], OK())
  git.on(['worktree', 'remove', join(vault, 't')], OK())
  git.on(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)], OK())
  let triggerCalls = 0

  const r = await finishTask({
    root: 'C:/repo',
    task: 'T',
    mode: 'commit',
    cfg,
    git,
    repo: { triggers: { on_merge: ['deploy.sh'] } },
    triggerSpawn: () => {
      triggerCalls += 1
      throw new Error('on_merge should not run for an already-merged branch')
    },
  })

  assert.equal(r.ok, true)
  assert.equal(r.merged, false)
  assert.equal(triggerCalls, 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：commit 模式 = 提交 + 合并 + 删工作区 + 删分支 + 清记录', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp, { taskDirty: true })
  git.on(['worktree', 'remove', join(vault, 't')], OK())
  git.on(['update-ref', '-d', 'refs/heads/wtm/t', '9'.repeat(40)], OK())
  const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })
  assert.equal(r.ok, true, r.error ?? '')
  assert.equal(r.merged, true)
  assert.equal(r.committed, true)
  assert.equal(r.removed, true)
  assert.equal(r.branchDeleted, true)
  assert.ok(git.called(['worktree', 'remove', join(vault, 't')]))
  assert.ok(git.called(['update-ref', '-d', 'refs/heads/wtm/t', '9'.repeat(40)]))
  assert.equal(loadLedger(vault).records.length, 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：合并后分支尖端前进时恢复工作区并保留账本记录', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  let branchTip = '2'.repeat(40)
  let branchTipReads = 0
  git.on(['rev-parse', '--verify', 'refs/heads/wtm/t^{commit}'], () => {
    branchTipReads += 1
    if (branchTipReads === 5) {
      const readTip = branchTip
      queueMicrotask(() => { branchTip = '4'.repeat(40) })
      return OK(`${readTip}\n`)
    }
    return OK(`${branchTip}\n`)
  })
  git.on(['worktree', 'remove', taskPath], OK())
  git.on(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)], FAIL('permission denied', 1))
  git.on(['worktree', 'add', taskPath, 'wtm/t'], OK())

  const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })

  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /分支删除失败/)
  assert.equal(loadLedger(vault).records.length, 1)
  assert.ok(git.called(['worktree', 'add', taskPath, 'wtm/t']))
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：分支漂移恢复工作区期间取消仍返回取消并保留记录', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  const controller = new AbortController()
  let taskRemoved = false
  git.on(['rev-parse', '--verify', 'refs/heads/wtm/t^{commit}'], () => OK(`${taskRemoved ? '4' : '2'.repeat(40)}\n`))
  git.on(['worktree', 'remove', taskPath], () => {
    taskRemoved = true
    rmSync(taskPath, { recursive: true, force: true })
    return OK()
  })
  git.on(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)], FAIL('permission denied', 1))
  git.on(['worktree', 'add', taskPath, 'wtm/t'], () => {
    controller.abort()
    return { ...FAIL('operation aborted'), aborted: true }
  })

  try {
    const result = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null, signal: controller.signal })
    assert.equal(result.ok, false)
    assert.equal(result.cancelled, true, JSON.stringify(result))
    assert.match(result.error ?? '', /取消|aborted/i)
    assert.equal(loadLedger(vault).records.length, 1, 'keep the branch-drift recovery record')
    assert.equal(loadLedger(vault).records[0]?.path, taskPath)
    assert.equal(git.called(['worktree', 'add', taskPath, 'wtm/t']), true)
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('finishTask：on_finish 取消时仍复验删除失败的分支并保留漂移任务', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  let branchTip = '2'.repeat(40)
  git.on(['rev-parse', '--verify', 'refs/heads/wtm/t^{commit}'], () => OK(`${branchTip}\n`))
  git.on(['worktree', 'remove', taskPath], () => {
    rmSync(taskPath, { recursive: true, force: true })
    return OK()
  })
  git.on(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)], FAIL('permission denied', 1))
  git.on(['worktree', 'add', taskPath, 'wtm/t'], OK())
  const controller = new AbortController()

  try {
    const result = await finishTask({
      root: 'C:/repo', task: 'T', mode: 'commit', cfg, git,
      repo: { triggers: { on_finish: ['cancel-after-branch-delete-failure'] } },
      signal: controller.signal,
      triggerSpawn: () => {
        branchTip = '4'.repeat(40)
        const child = /** @type {any} */ (new EventEmitter())
        child.stdout = new EventEmitter()
        child.stderr = new EventEmitter()
        child.stdin = { end() {} }
        child.kill = (/** @type {NodeJS.Signals} */ signal) => {
          queueMicrotask(() => child.emit('close', null, signal))
          return true
        }
        queueMicrotask(() => controller.abort())
        return child
      },
    })

    assert.equal(result.ok, false)
    assert.equal(result.cancelled, true, JSON.stringify(result))
    assert.match(result.error ?? '', /取消|继续前进|branch.*advance/i)
    assert.equal(loadLedger(vault).records.length, 1, 'branch drift must keep its recovery record')
    assert.ok(git.called(['worktree', 'add', taskPath, 'wtm/t']), 'the task worktree should be restored')
    assert.ok(git.count(['rev-parse', '--verify', 'refs/heads/wtm/t^{commit}']) >= 3, 'the branch must be checked after on_finish')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('finishTask：on_finish 后最终 worktree 列表检查取消时恢复 abandon 路径并报告取消', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  const abandonPath = join(vault, '.t.abandon-pending')
  const controller = new AbortController()
  const worktreeList = WORKTREES(`worktree C:/repo\nHEAD ${'1'.repeat(40)}\nbranch refs/heads/main\n\nworktree ${taskPath}\nHEAD ${'2'.repeat(40)}\nbranch refs/heads/wtm/t\n`)
  let worktreeListCalls = 0
  git.on(['worktree', 'list', '--porcelain', '-z'], () => {
    worktreeListCalls += 1
    if (worktreeListCalls === 2) {
      controller.abort()
      return { ...FAIL('operation aborted'), aborted: true }
    }
    return worktreeList
  })

  try {
    const result = await finishTask({ root: 'C:/repo', task: 'T', mode: 'abandon', cfg, git, repo: null, signal: controller.signal })
    assert.equal(result.ok, false)
    assert.equal(result.cancelled, true, JSON.stringify(result))
    assert.match(result.error ?? '', /取消|aborted/i)
    assert.equal(worktreeListCalls, 2)
    assert.ok(git.called(['worktree', 'move', taskPath, abandonPath]))
    assert.ok(git.called(['worktree', 'move', abandonPath, taskPath]), 'staged abandon worktree must be restored')
    assert.equal(loadLedger(vault).records[0].path, taskPath, 'recovery ledger must point to the restored path')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('finishTask：on_finish 后任一分支尖端复验取消都保留可恢复记录', async () => {
  for (const abortAt of ['current', 'final']) {
    const tmp = makeTmp()
    const { cfg, git, vault } = mergeFixture(tmp)
    const taskPath = join(vault, 't')
    const controller = new AbortController()
    let onFinishStarted = false
    let postFinishReads = 0
    git.on(['rev-parse', '--verify', 'refs/heads/wtm/t^{commit}'], () => {
      if (onFinishStarted) {
        postFinishReads += 1
        if ((abortAt === 'current' && postFinishReads === 1) || (abortAt === 'final' && postFinishReads === 2)) {
          controller.abort()
          return { ...FAIL('operation aborted'), aborted: true }
        }
      }
      return OK(`${'2'.repeat(40)}\n`)
    })
    git.on(['worktree', 'remove', taskPath], () => {
      rmSync(taskPath, { recursive: true, force: true })
      return OK()
    })
    git.on(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)], FAIL('permission denied', 1))
    git.on(['worktree', 'add', taskPath, 'wtm/t'], () => {
      mkdirSync(taskPath, { recursive: true })
      return OK()
    })

    try {
      const result = await finishTask({
        root: 'C:/repo', task: 'T', mode: 'commit', cfg, git,
        repo: { triggers: { on_finish: ['after-cleanup'] } },
        signal: controller.signal,
        triggerSpawn: () => {
          onFinishStarted = true
          const child = /** @type {any} */ (new EventEmitter())
          child.stdout = new EventEmitter()
          child.stderr = new EventEmitter()
          child.stdin = { end() {} }
          child.kill = (/** @type {NodeJS.Signals} */ signal) => {
            queueMicrotask(() => child.emit('close', null, signal))
            return true
          }
          queueMicrotask(() => child.emit('close', 0, null))
          return child
        },
      })

      assert.equal(result.ok, false)
      assert.equal(result.cancelled, true, `${abortAt}: ${JSON.stringify(result)}`)
      assert.match(result.error ?? '', /取消|aborted/i)
      assert.ok(result.warnings?.some((warning) => /on_finish 触发器清理未能确认/.test(warning)), `${abortAt}: completed trigger cleanup must remain explicit`)
      assert.equal(loadLedger(vault).records.length, 1, `${abortAt}: failed branch deletion requires a recovery record`)
      assert.equal(loadLedger(vault).records[0].path, taskPath)
      assert.ok(git.called(['worktree', 'add', taskPath, 'wtm/t']), `${abortAt}: removed worktree must be restored`)
    } finally {
      rmSync(tmp, { recursive: true, force: true })
    }
  }
})

test('finishTask：取消中断普通工作区移除时返回取消并保留任务记录', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  const controller = new AbortController()
  git.on(['worktree', 'remove', taskPath], () => {
    controller.abort()
    return { ...FAIL('operation aborted'), aborted: true }
  })

  try {
    const result = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null, signal: controller.signal })
    assert.equal(result.ok, false)
    assert.equal(result.cancelled, true, JSON.stringify(result))
    assert.match(result.error ?? '', /取消|aborted/i)
    assert.equal(loadLedger(vault).records.length, 1, 'cancelled removal must retain a recovery record')
    assert.equal(fs.existsSync(taskPath), true, 'the fake interrupted remove leaves the worktree available')
    assert.equal(git.called(['branch', '-d', 'wtm/t']), false, 'do not continue cleanup after interrupted removal')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('finishTask：工作区移除已成功后才观察到取消时仍完成收尾记账', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  const controller = new AbortController()
  git.on(['worktree', 'remove', taskPath], () => {
    rmSync(taskPath, { recursive: true, force: true })
    controller.abort()
    return OK()
  })
  git.on(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)], FAIL('operation aborted'))
  git.on(['rev-parse', '--verify', 'refs/heads/wtm/t^{commit}'], OK(`${'2'.repeat(40)}\n`))

  try {
    const result = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null, signal: controller.signal })
    assert.equal(result.ok, false)
    assert.equal(result.cancelled, true, JSON.stringify(result))
    assert.equal(result.removed, true, JSON.stringify(result))
    assert.equal(fs.existsSync(taskPath), false, 'the successful worktree removal must remain reflected on disk')
    assert.equal(loadLedger(vault).records.length, 0, 'do not leave a stale ledger record after confirmed removal')
    assert.ok(git.called(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)]), 'continue safe finish bookkeeping after confirmed removal')
    assert.ok(git.count(['rev-parse', '--verify', 'refs/heads/wtm/t^{commit}']) >= 2, 'retain branch-tip checks for cancelled on_finish bookkeeping')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('finishTask：条件删除前分支尖端前进时保留新提交', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  let branchTip = '2'.repeat(40)
  git.on(['rev-parse', '--verify', 'refs/heads/wtm/t^{commit}'], () => OK(`${branchTip}\n`))
  git.on(['worktree', 'remove', taskPath], OK())
  git.on(['branch', '-d', 'wtm/t'], () => {
    branchTip = '4'.repeat(40)
    return OK('Deleted branch wtm/t')
  })
  git.on(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)], () => {
    branchTip = '4'.repeat(40)
    return FAIL('reference changed', 1)
  })
  git.on(['worktree', 'add', taskPath, 'wtm/t'], OK())

  const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })

  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /分支删除失败/)
  assert.equal(loadLedger(vault).records.length, 1)
  assert.ok(git.called(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)]))
  assert.ok(git.called(['worktree', 'add', taskPath, 'wtm/t']))
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：分支在其他工作区检出时不删除引用', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  let worktreeLists = 0
  git.on(['worktree', 'list', '--porcelain', '-z'], () => {
    worktreeLists += 1
    const taskWorktree = `worktree ${taskPath}\nHEAD ${'2'.repeat(40)}\nbranch refs/heads/wtm/t\n`
    const otherWorktree = `worktree C:/other\nHEAD ${'4'.repeat(40)}\nbranch refs/heads/wtm/t\n`
    return WORKTREES(`worktree C:/repo\nHEAD ${'1'.repeat(40)}\nbranch refs/heads/main\n\n${worktreeLists < 3 ? taskWorktree : otherWorktree}`)
  })
  git.on(['worktree', 'remove', taskPath], OK())
  git.on(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)], OK())

  const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })

  assert.equal(r.ok, true)
  assert.equal(r.branchDeleted, false)
  assert.ok(r.warnings?.some((warning) => /其他工作区/.test(warning)), JSON.stringify(r))
  assert.equal(git.count(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)]), 0)
  assert.equal(worktreeLists, 3)
  assert.equal(loadLedger(vault).records.length, 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：abandon 模式在最终复验发现分支漂移时拒绝删除', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  const abandonPath = join(vault, '.t.abandon-pending')
  let worktreeListCalls = 0
  git.on(['worktree', 'list', '--porcelain', '-z'], () => {
    worktreeListCalls += 1
    const path = worktreeListCalls === 1 ? taskPath : abandonPath
    const branch = worktreeListCalls === 1 ? 'wtm/t' : 'other'
    return WORKTREES(
      'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
      'worktree ' + path + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/' + branch + '\n',
    )
  })
  git.on(['worktree', 'remove', '--force', abandonPath], OK())
  git.on(['branch', '-D', 'wtm/t'], OK())

  try {
    const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'abandon', cfg, git, repo: null })
    assert.equal(r.ok, false)
    assert.match(r.error ?? '', /分支与账本记录不一致/)
    assert.equal(worktreeListCalls, 2)
    assert.equal(git.count(['worktree', 'remove', '--force', abandonPath]), 0)
    assert.equal(git.count(['branch', '-D', 'wtm/t']), 0)
    assert.ok(git.called(['worktree', 'move', abandonPath, taskPath]))
    assert.deepEqual(loadLedger(vault).records.map((rec) => [rec.branch, rec.path]), [['wtm/t', taskPath]])
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('finishTask：abandon 漂移回滚期间取消仍返回取消并记录原路径', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault, taskGitDir } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  const abandonPath = join(vault, '.t.abandon-pending')
  const headLockPath = join(taskGitDir, 'HEAD.lock')
  const controller = new AbortController()
  let worktreeListCalls = 0
  git.on(['worktree', 'list', '--porcelain', '-z'], () => {
    worktreeListCalls += 1
    const path = worktreeListCalls === 1 ? taskPath : abandonPath
    const branch = worktreeListCalls === 1 ? 'wtm/t' : 'other'
    return WORKTREES(
      'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
      'worktree ' + path + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/' + branch + '\n',
    )
  })
  git.on(['worktree', 'move', abandonPath, taskPath], () => {
    controller.abort()
    return OK()
  })

  try {
    const result = await finishTask({ root: 'C:/repo', task: 'T', mode: 'abandon', cfg, git, repo: null, signal: controller.signal })
    assert.equal(result.ok, false)
    assert.equal(result.cancelled, true, JSON.stringify(result))
    assert.match(result.error ?? '', /取消|aborted/i)
    assert.ok(git.called(['worktree', 'move', abandonPath, taskPath]))
    assert.equal(loadLedger(vault).records[0]?.path, taskPath)
    assert.equal(fs.existsSync(headLockPath), false, 'rollback must release the HEAD lock')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('finishTask：最终 NUL 复验完整保留含元数据样式换行的工作区路径', { skip: process.platform === 'win32' }, async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, `t\nHEAD ${'3'.repeat(40)}\nbranch refs/heads/path-text`)
  const ledger = loadLedger(vault)
  ledger.records[0].path = taskPath
  saveLedger(vault, ledger)
  mkdirSync(taskPath, { recursive: true })
  let worktreeListCalls = 0
  /** @param {boolean} includeTask */
  const nulListing = (includeTask) => OK([
    'worktree C:/repo',
    `HEAD ${'1'.repeat(40)}`,
    'branch refs/heads/main',
    '',
    ...(includeTask ? [
      `worktree ${taskPath}`,
      `HEAD ${'2'.repeat(40)}`,
      'branch refs/heads/wtm/t',
    ] : []),
    '',
  ].join('\0'))
  git.on(['worktree', 'list', '--porcelain', '-z'], () => {
    worktreeListCalls += 1
    return nulListing(worktreeListCalls < 3)
  })
  git.on(['worktree', 'remove', taskPath], OK())
  git.on(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)], OK())

  try {
    const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })
    assert.equal(r.ok, true, JSON.stringify(r))
    assert.equal(worktreeListCalls, 3)
    assert.equal(git.count(['worktree', 'list', '--porcelain']), 0)
    assert.ok(git.called(['worktree', 'remove', taskPath]))
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('finishTask：分支尖端未变化时保留删除警告并完成清理', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  git.on(['worktree', 'remove', taskPath], OK())
  git.on(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)], FAIL('permission denied'))

  const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })

  assert.equal(r.ok, true)
  assert.equal(r.branchDeleted, false)
  assert.ok(r.warnings?.some((warning) => /分支删除失败/.test(warning)), JSON.stringify(r))
  assert.equal(loadLedger(vault).records.length, 0)
  assert.equal(git.count(['worktree', 'add', taskPath, 'wtm/t']), 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：abandon 模式跳过提交与合并，强制删除', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp, { taskDirty: true })
  const taskPath = join(vault, 't')
  const abandonPath = join(vault, '.t.abandon-pending')
  const headLockPath = join(tmp, 'task-gitdir', 'HEAD.lock')
  let worktreeListCalls = 0
  git.on(['worktree', 'list', '--porcelain', '-z'], () => {
    worktreeListCalls += 1
    const path = worktreeListCalls === 1 ? taskPath : abandonPath
    return WORKTREES(
      'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
      'worktree ' + path + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/wtm/t\n',
    )
  })
  git.on(['worktree', 'remove', '--force', abandonPath], () => {
    assert.equal(fs.existsSync(headLockPath), true, '移除时必须继续持有分支锁')
    return OK()
  })
  git.on(['branch', '-D', 'wtm/t'], OK())
  const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'abandon', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.equal(r.merged, false)
  assert.equal(r.committed, false)
  assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
  assert.ok(git.called(['worktree', 'move', join(vault, 't'), abandonPath]))
  assert.ok(git.called(['worktree', 'remove', '--force', abandonPath]))
  assert.equal(fs.existsSync(headLockPath), false, '完成移除后必须释放分支锁')
  assert.ok(git.called(['branch', '-D', 'wtm/t']))
  assert.equal(worktreeListCalls, 2)
  assert.equal(loadLedger(vault).records.length, 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：abandon 模式发现工作区分支不一致时拒绝删除', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp, { taskBranch: 'other' })
  const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'abandon', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /分支与账本记录不一致/)
  assert.equal(git.count(['worktree', 'remove', '--force', join(vault, 't')]), 0)
  assert.equal(git.count(['branch', '-D', 'wtm/t']), 0)
  assert.deepEqual(loadLedger(vault).records.map((rec) => rec.branch), ['wtm/t'])
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：abandon 强制移除前发现分支和工作区状态漂移时保留新改动与账本', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault, taskGitDir } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  const abandonPath = join(vault, '.t.abandon-pending')
  const headLockPath = join(taskGitDir, 'HEAD.lock')
  const racePath = join(taskPath, 'race.txt')
  const statusArgs = ['status', '--porcelain=v2', '--branch', '--untracked-files=all']
  let branch = 'wtm/t'
  let statusChecks = 0
  git.on(statusArgs, (/** @type {{cwd: string | undefined}} */ ctx) => {
    statusChecks += 1
    if (statusChecks === 1) {
      assert.equal(ctx.cwd, taskPath)
      const before = `# branch.oid ${'2'.repeat(40)}\n# branch.head ${branch}\n`
      branch = 'other'
      fs.writeFileSync(racePath, 'preserve this change')
      return OK(before)
    }
    assert.equal(ctx.cwd, abandonPath)
    assert.equal(fs.existsSync(headLockPath), true, '最终状态检查期间必须阻止分支切换')
    return OK(`# branch.oid ${'4'.repeat(40)}\n# branch.head ${branch}\n? race.txt\n`)
  })
  git.on(['worktree', 'move', taskPath, abandonPath], () => {
    fs.renameSync(taskPath, abandonPath)
    return OK()
  })
  git.on(['worktree', 'move', abandonPath, taskPath], () => {
    assert.equal(fs.existsSync(headLockPath), false, '恢复路径前必须释放分支锁')
    fs.renameSync(abandonPath, taskPath)
    return OK()
  })
  git.on(['worktree', 'remove', '--force', abandonPath], () => {
    rmSync(abandonPath, { recursive: true, force: true })
    return OK()
  })
  git.on(['branch', '-D', 'wtm/t'], OK())

  try {
    const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'abandon', cfg, git, repo: null })
    assert.equal(r.ok, false)
    assert.match(r.error ?? '', /工作区.*变化|分支.*不一致/)
    assert.equal(statusChecks, 2)
    assert.equal(fs.existsSync(racePath), true, '并发新增文件必须保留')
    assert.equal(fs.existsSync(abandonPath), false, '恢复原路径后不得留下临时工作区')
    assert.equal(git.count(['worktree', 'remove', '--force', abandonPath]), 0, '漂移后不得强制移除工作区')
    assert.equal(git.count(['branch', '-D', 'wtm/t']), 0, '漂移后不得删除账本分支')
    assert.equal(fs.existsSync(headLockPath), false, '状态漂移后不得遗留分支锁')
    assert.equal(loadLedger(vault).records.length, 1, '漂移后必须保留管理记录')
    assert.equal(loadLedger(vault).records[0].path, taskPath, '账本仍须指向恢复后的工作区路径')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('finishTask：abandon 状态检查取消时恢复原工作区和账本路径', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault, taskGitDir } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  const abandonPath = join(vault, '.t.abandon-pending')
  const headLockPath = join(taskGitDir, 'HEAD.lock')
  const statusArgs = ['status', '--porcelain=v2', '--branch', '--untracked-files=all']
  const controller = new AbortController()
  let statusChecks = 0
  git.on(statusArgs, (/** @type {{cwd: string | undefined}} */ ctx) => {
    assert.equal(ctx.cwd, statusChecks === 0 ? taskPath : abandonPath)
    statusChecks += 1
    if (statusChecks === 1) return OK(`# branch.oid ${'2'.repeat(40)}\n# branch.head wtm/t\n`)
    controller.abort()
    return FAIL('operation aborted')
  })
  git.on(['worktree', 'move', taskPath, abandonPath], (/** @type {{signal?: AbortSignal}} */ ctx) => {
    assert.equal(ctx.signal, undefined, '工作区路径移动不能被取消打断')
    return OK()
  })
  git.on(['worktree', 'move', abandonPath, taskPath], (/** @type {{signal?: AbortSignal}} */ ctx) => {
    assert.equal(ctx.signal, undefined, '取消后恢复移动不能复用已中止的信号')
    return OK()
  })

  try {
    const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'abandon', cfg, git, repo: null, signal: controller.signal })
    assert.equal(r.ok, false)
    assert.match(r.error ?? '', /取消|aborted/i)
    assert.equal(statusChecks, 2)
    assert.equal(fs.existsSync(headLockPath), false)
    assert.equal(git.count(['worktree', 'remove', '--force', abandonPath]), 0)
    assert.equal(loadLedger(vault).records[0].path, taskPath)
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('finishTask：取消中断 abandon 隔离后 Git 检查时恢复原路径并报告取消', async () => {
  for (const abortAt of ['gitDir', 'stagedStatus']) {
    const tmp = makeTmp()
    const { cfg, git, vault, taskGitDir } = mergeFixture(tmp)
    const taskPath = join(vault, 't')
    const abandonPath = join(vault, '.t.abandon-pending')
    const headLockPath = join(taskGitDir, 'HEAD.lock')
    const controller = new AbortController()
    const statusArgs = ['status', '--porcelain=v2', '--branch', '--untracked-files=all']
    let statusChecks = 0
    git.on(statusArgs, (/** @type {{cwd: string | undefined}} */ ctx) => {
      statusChecks += 1
      if (abortAt === 'stagedStatus' && statusChecks === 2) {
        assert.equal(ctx.cwd, abandonPath)
        controller.abort()
        return { ...FAIL('operation aborted'), aborted: true }
      }
      return OK(`# branch.oid ${'2'.repeat(40)}\n# branch.head wtm/t\n`)
    })
    git.on(['rev-parse', '--absolute-git-dir'], () => {
      if (abortAt === 'gitDir') {
        controller.abort()
        return { ...FAIL('operation aborted'), aborted: true }
      }
      return OK(`${taskGitDir}\n`)
    })

    try {
      const result = await finishTask({ root: 'C:/repo', task: 'T', mode: 'abandon', cfg, git, repo: null, signal: controller.signal })
      assert.equal(result.ok, false)
      assert.equal(result.cancelled, true, `${abortAt}: ${JSON.stringify(result)}`)
      assert.match(result.error ?? '', /取消|aborted/i)
      assert.ok(git.called(['worktree', 'move', taskPath, abandonPath]))
      assert.ok(git.called(['worktree', 'move', abandonPath, taskPath]), `${abortAt}: staged worktree must be restored`)
      assert.equal(loadLedger(vault).records[0].path, taskPath)
      assert.equal(fs.existsSync(headLockPath), false, 'cancellation must not leave a HEAD lock')
    } finally {
      rmSync(tmp, { recursive: true, force: true })
    }
  }
})

test('finishTask：取消期间 abandon 隔离移动失败时保留原工作区并报告取消', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  const abandonPath = join(vault, '.t.abandon-pending')
  const controller = new AbortController()
  git.on(['worktree', 'move', taskPath, abandonPath], () => {
    controller.abort()
    return FAIL('move interrupted')
  })

  try {
    const result = await finishTask({ root: 'C:/repo', task: 'T', mode: 'abandon', cfg, git, repo: null, signal: controller.signal })
    assert.equal(result.ok, false)
    assert.equal(result.cancelled, true, JSON.stringify(result))
    assert.match(result.error ?? '', /取消|aborted/i)
    assert.match(result.error ?? '', /隔离任务工作区失败/)
    assert.equal(git.called(['worktree', 'move', abandonPath, taskPath]), false, 'failed move leaves the original path in place')
    assert.equal(loadLedger(vault).records[0].path, taskPath)
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('finishTask：abandon 强制移除失败与取消竞态时恢复路径并报告取消', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault, taskGitDir } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  const abandonPath = join(vault, '.t.abandon-pending')
  const headLockPath = join(taskGitDir, 'HEAD.lock')
  const controller = new AbortController()
  let worktreeListCalls = 0
  git.on(['worktree', 'list', '--porcelain', '-z'], () => {
    worktreeListCalls += 1
    const path = worktreeListCalls === 1 ? taskPath : abandonPath
    return WORKTREES(
      'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
      'worktree ' + path + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/wtm/t\n',
    )
  })
  git.on(['worktree', 'remove', '--force', abandonPath], () => {
    controller.abort()
    return { ...FAIL('operation aborted'), aborted: true }
  })

  try {
    const result = await finishTask({ root: 'C:/repo', task: 'T', mode: 'abandon', cfg, git, repo: null, signal: controller.signal })
    assert.equal(result.ok, false)
    assert.equal(result.cancelled, true, JSON.stringify(result))
    assert.match(result.error ?? '', /取消|aborted/i)
    assert.ok(git.called(['worktree', 'move', abandonPath, taskPath]), 'a failed forced remove must restore the staged worktree')
    assert.equal(loadLedger(vault).records[0]?.path, taskPath, 'the recovery ledger must point to the restored path')
    assert.equal(fs.existsSync(headLockPath), false, 'cancellation must release the HEAD lock')
    assert.equal(git.called(['branch', '-D', 'wtm/t']), false, 'do not delete the branch after failed worktree removal')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('finishTask：keep 模式仅解除管理，不触碰工作区与分支', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'keep', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.equal(git.count(['worktree', 'remove', join(vault, 't')]), 0)
  assert.equal(git.count(['branch', '-d', 'wtm/t']), 0)
  assert.equal(loadLedger(vault).records.length, 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：工作区已不存在时清记录并提示（stale 清理）', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
    const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T', branch: 'wtm/t', base: 'main', path: 'P', createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES('worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n'))
  const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.equal(loadLedger(cfg.vault).records.length, 0)
  assert.match(r.note ?? '', /已不存在/)
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：工作区路径被普通文件替换时失败并保留记录', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  rmSync(taskPath, { recursive: true, force: true })
  fs.writeFileSync(taskPath, 'not a directory')

  const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })

  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /工作区|目录/)
  assert.equal(loadLedger(vault).records.length, 1)
  assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
  assert.equal(git.count(['worktree', 'remove', taskPath]), 0)
  assert.equal(git.count(['branch', '-d', 'wtm/t']), 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：keep 模式工作区路径被普通文件替换时失败并保留记录', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  rmSync(taskPath, { recursive: true, force: true })
  fs.writeFileSync(taskPath, 'not a directory')

  const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'keep', cfg, git, repo: null })

  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /工作区|目录/)
  assert.equal(loadLedger(vault).records.length, 1)
  assert.equal(git.count(['worktree', 'remove', taskPath]), 0)
  assert.equal(git.count(['branch', '-d', 'wtm/t']), 0)
  assert.equal(git.count(['branch', '-D', 'wtm/t']), 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：记录不存在报错；非法 mode 报错', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const r1 = await finishTask({ root: 'C:/repo', task: 'nope', cfg, git, repo: null })
  assert.equal(r1.ok, false)
    const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T', branch: 'wtm/t', base: 'main', path: 'P', createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES('worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\nworktree P\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/wtm/t\n'))
  const r2 = await finishTask({ root: 'C:/repo', task: 'T', mode: 'bogus', cfg, git, repo: null })
  assert.equal(r2.ok, false)
  assert.match(r2.error ?? '', /mode/i)
  rmSync(tmp, { recursive: true, force: true })
})

// ---- listStatus ------------------------------------------------------------

test('listStatus：计算存在性、脏状态与 ahead/behind', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
    const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T1', branch: 'wtm/t1', base: 'main', path: join(cfg.vault, 't1'), createdAt: 'c', updatedAt: 'u' })
  upsertRecord(ledger, { task: 'T2', branch: 'wtm/t2', base: 'main', path: join(cfg.vault, 't2'), createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  mkdirSync(join(cfg.vault, 't1'), { recursive: true })

  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES(
    'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
    'worktree ' + join(cfg.vault, 't1') + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/wtm/t1\n',
  ))
  git.on(['status', '--porcelain'], OK(' M f.txt\n'))
  git.on(['rev-list', '--left-right', '--count', 'refs/heads/main...refs/heads/wtm/t1'], OK('1\t2'))
  git.on(['rev-list', '--left-right', '--count', 'refs/heads/main...refs/heads/wtm/t2'], FAIL())

  const r = await listStatus({ root: 'C:/repo', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.ok(r.rows, '应有 rows')
  const t1 = r.rows.find((x) => x.task === 'T1')
  const t2 = r.rows.find((x) => x.task === 'T2')
  assert.ok(t1, '应有 T1')
  assert.ok(t2, '应有 T2')
  assert.equal(t1.exists, true)
  assert.equal(t1.dirty, true)
  assert.deepEqual(t1.counts, { ahead: 2, behind: 1 })
  assert.equal(t2.exists, false)
  assert.equal(t2.counts, null)
  rmSync(tmp, { recursive: true, force: true })
})

test('listStatus：git status 失败时标记状态未知并返回警告', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T', branch: 'wtm/t', base: 'main', path: join(cfg.vault, 't'), createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  mkdirSync(join(cfg.vault, 't'), { recursive: true })

  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES(
    'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
    'worktree ' + join(cfg.vault, 't') + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/wtm/t\n',
  ))
  git.on(['status', '--porcelain'], FAIL('fatal: damaged git metadata'))
  git.on(['rev-list', '--left-right', '--count', 'refs/heads/main...refs/heads/wtm/t'], OK('0\t0'))

  const r = await listStatus({ root: 'C:/repo', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.ok(r.rows, '应有 rows')
  assert.equal(r.rows[0].dirty, null, '无法读取时 dirty 必须为未知，而不是干净')
  assert.ok(r.warnings?.some((w) => /T/.test(w) && /damaged git metadata/.test(w)), JSON.stringify(r.warnings))
  rmSync(tmp, { recursive: true, force: true })
})

test('listStatus：任务状态 Git 调用中止时返回取消结果而不继续统计', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const taskPath = join(cfg.vault, 't')
  const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T', branch: 'wtm/t', base: 'main', path: taskPath, createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  mkdirSync(taskPath, { recursive: true })

  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES(
    'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
    'worktree ' + taskPath + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/wtm/t\n',
  ))
  git.on(['status', '--porcelain'], { ok: false, code: -1, stdout: '', stderr: '', aborted: true })
  git.on(['rev-list', '--left-right', '--count', 'refs/heads/main...refs/heads/wtm/t'], OK('0\t0'))

  const r = await listStatus({ root: 'C:/repo', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /取消|abort/i)
  assert.equal(git.count(['rev-list', '--left-right', '--count', 'refs/heads/main...refs/heads/wtm/t']), 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('listStatus：最后一次 Git 调用后 signal 中止时不返回部分结果', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const taskPath = join(cfg.vault, 't')
  const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T', branch: 'wtm/t', base: 'main', path: taskPath, createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  mkdirSync(taskPath, { recursive: true })

  const ac = new AbortController()
  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES(
    'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
    'worktree ' + taskPath + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/wtm/t\n',
  ))
  git.on(['status', '--porcelain'], OK(''))
  git.on(['rev-list', '--left-right', '--count', 'refs/heads/main...refs/heads/wtm/t'], () => {
    ac.abort()
    return OK('0\t0')
  })

  const r = await listStatus({ root: 'C:/repo', cfg, git, repo: null, signal: ac.signal })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /取消|abort/i)
  rmSync(tmp, { recursive: true, force: true })
})

test('listStatus：rev-list 失败时保留未知计数并返回警告', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const taskPath = join(cfg.vault, 't')
  const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T', branch: 'wtm/t', base: 'main', path: taskPath, createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  mkdirSync(taskPath, { recursive: true })

  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES(
    'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
    'worktree ' + taskPath + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/wtm/t\n',
  ))
  git.on(['status', '--porcelain'], OK(''))
  git.on(['rev-list', '--left-right', '--count', 'refs/heads/main...refs/heads/wtm/t'], FAIL('fatal: bad object'))

  const r = await listStatus({ root: 'C:/repo', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.equal(r.rows?.[0].counts, null)
  assert.ok(r.warnings?.some((w) => /T/.test(w) && /bad object/.test(w)), JSON.stringify(r.warnings))
  rmSync(tmp, { recursive: true, force: true })
})

test('listStatus：rev-list 输出格式异常时保留未知计数并返回警告', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const taskPath = join(cfg.vault, 't')
  const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T', branch: 'wtm/t', base: 'main', path: taskPath, createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  mkdirSync(taskPath, { recursive: true })

  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES(
    'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
    'worktree ' + taskPath + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/wtm/t\n',
  ))
  git.on(['status', '--porcelain'], OK(''))
  git.on(['rev-list', '--left-right', '--count', 'refs/heads/main...refs/heads/wtm/t'], OK('not a count'))

  const r = await listStatus({ root: 'C:/repo', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.equal(r.rows?.[0].counts, null)
  assert.ok(r.warnings?.some((w) => /T/.test(w) && /格式|计数|rev-list/i.test(w)), JSON.stringify(r.warnings))
  rmSync(tmp, { recursive: true, force: true })
})

test('listStatus：工作区分支漂移时标记状态并不计算错误分支状态', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const taskPath = join(cfg.vault, 't')
  const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T', branch: 'wtm/t', base: 'main', path: taskPath, createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  mkdirSync(taskPath, { recursive: true })

  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES(
    'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
    'worktree ' + taskPath + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/other\n',
  ))
  git.on(['status', '--porcelain'], OK(' M wrong-branch.txt\n'))
  git.on(['rev-list', '--left-right', '--count', 'refs/heads/main...refs/heads/wtm/t'], OK('1\t9'))

  const r = await listStatus({ root: 'C:/repo', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.ok(r.rows, '应有 rows')
  assert.equal(r.rows[0].exists, false)
  assert.equal(r.rows[0].branchDrift, true)
  assert.equal(r.rows[0].currentBranch, 'other')
  assert.equal(r.rows[0].dirty, false)
  assert.equal(r.rows[0].counts, null)
  assert.equal(git.count(['status', '--porcelain']), 0, '分支漂移时不应读取错误工作区状态')
  assert.equal(git.count(['rev-list', '--left-right', '--count', 'refs/heads/main...refs/heads/wtm/t']), 0, '分支漂移时不应计算错误分支计数')
  rmSync(tmp, { recursive: true, force: true })
})

// ---- purge -----------------------------------------------------------------

test('purge：commit 模式执行 on_merge 触发器', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  git.on(['worktree', 'remove', join(vault, 't')], OK())
  git.on(['branch', '-d', 'wtm/t'], OK('Deleted branch wtm/t'))
  /** @type {Array<{shell: string, args: string[], opts: object}>} */
  const triggerCalls = []
  const repo = { triggers: { on_merge: ['mark-merge'] } }
  const r = await purge({
    root: 'C:/repo', tasks: ['T'], mode: 'commit', cfg, git, repo,
    triggerSpawn: (shell, args, opts) => {
      triggerCalls.push({ shell, args, opts })
      const child = /** @type {any} */ (new EventEmitter())
      child.stdout = new EventEmitter()
      child.stderr = new EventEmitter()
      queueMicrotask(() => child.emit('close', 0, null))
      return child
    },
  })
  assert.equal(r.ok, true)
  assert.equal(r.results?.[0].ok, true)
  assert.equal(triggerCalls.length, 1)
  assert.equal(/** @type {any} */ (triggerCalls[0].opts).cwd, 'C:/repo')
  assert.equal(/** @type {any} */ (triggerCalls[0].opts).env.WTM_TASK, 'T')
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：工作区移除成功后取消仍复验分支并完成账本清理', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  const controller = new AbortController()
  const listedWorktrees = WORKTREES(
    `worktree C:/repo\nHEAD ${'1'.repeat(40)}\nbranch refs/heads/main\n\nworktree ${taskPath}\nHEAD ${'2'.repeat(40)}\nbranch refs/heads/wtm/t\n`,
  )
  let removed = false
  let branchChecksAfterAbort = 0
  git.on(['worktree', 'list', '--porcelain', '-z'], (/** @type {{signal: AbortSignal | undefined}} */ ctx) =>
    ctx.signal?.aborted ? { ...FAIL('operation aborted'), aborted: true } : listedWorktrees,
  )
  git.on(['rev-parse', '--verify', 'refs/heads/wtm/t^{commit}'], (/** @type {{signal: AbortSignal | undefined}} */ ctx) => {
    if (removed && controller.signal.aborted) {
      branchChecksAfterAbort += 1
      if (ctx.signal) return { ...FAIL('operation aborted'), aborted: true }
    }
    return OK(`${'2'.repeat(40)}\n`)
  })
  git.on(['worktree', 'remove', taskPath], () => {
    rmSync(taskPath, { recursive: true, force: true })
    removed = true
    controller.abort()
    return OK()
  })
  git.on(['worktree', 'add', taskPath, 'wtm/t'], () => {
    mkdirSync(taskPath, { recursive: true })
    return OK()
  })

  try {
    const result = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null, signal: controller.signal })

    assert.equal(result.ok, false)
    assert.equal(result.cancelled, true, JSON.stringify(result))
    assert.equal(result.removed, true)
    assert.equal(loadLedger(vault).records.length, 0, 'confirmed worktree removal must finish ledger bookkeeping')
    assert.equal(fs.existsSync(taskPath), false, 'a branch-tip recheck must not recreate the removed worktree')
    assert.ok(branchChecksAfterAbort > 0, 'branch-tip validation must continue without the already-aborted signal')
    assert.equal(git.count(['worktree', 'add', taskPath, 'wtm/t']), 0)
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('on_finish 取消时完成记录清理，purge 不继续处理后续任务', async () => {
  for (const usePurge of [false, true]) {
    const tmp = makeTmp()
    const { cfg, git, vault } = mergeFixture(tmp)
    const worktreePath = join(vault, 't')
    git.on(['worktree', 'remove', worktreePath], () => {
      rmSync(worktreePath, { recursive: true, force: true })
      return OK()
    })
    git.on(['branch', '-d', 'wtm/t'], OK())
    git.on(['update-ref', '-d', 'refs/heads/wtm/t', '2'.repeat(40)], OK())
    const controller = new AbortController()
    const common = {
      root: 'C:/repo', cfg, git,
      repo: { triggers: { on_finish: ['cancel-after-cleanup'] } },
      signal: controller.signal,
      triggerSpawn: makeAbortTriggerSpawn(controller),
    }

    try {
      const result = usePurge
        ? await purge({ ...common, tasks: ['T', 'not-yet-processed'], mode: 'commit' })
        : await finishTask({ ...common, task: 'T', mode: 'commit' })

      assert.equal(result.ok, false)
      assert.equal(result.cancelled, true, JSON.stringify(result))
      assert.match(result.error ?? '', /取消|abort/i)
      assert.equal(loadLedger(vault).records.length, 0, 'finish bookkeeping must remove the completed task')
      assert.equal(fs.existsSync(worktreePath), false)
      assert.equal(git.called(['worktree', 'remove', worktreePath]), true)
      if (usePurge) {
        assert.equal(result.results?.length, 1)
        assert.equal(result.results?.[0]?.task, 'T')
        assert.equal(result.results?.[0]?.cancelled, true)
        assert.equal(result.results?.some((item) => item.task === 'not-yet-processed'), false)
      }
    } finally {
      rmSync(tmp, { recursive: true, force: true })
    }
  }
})

test('purge：保留收尾警告并报告分支删除失败', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  git.on(['worktree', 'remove', join(vault, 't')], OK())
  git.on(['branch', '-d', 'wtm/t'], FAIL('branch is not fully merged'))

  const r = await purge({ root: 'C:/repo', tasks: ['T'], mode: 'commit', cfg, git, repo: null })

  assert.equal(r.ok, true)
  const result = r.results?.[0]
  assert.ok(result, '应有 T 的收尾结果')
  assert.equal(result.branchDeleted, false)
  assert.ok(result.warnings?.some((w) => /分支删除失败/.test(w)), JSON.stringify(result))
  rmSync(tmp, { recursive: true, force: true })
})

test('purge：批量清理，逐任务报告，单个失败不中断', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
    const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T1', branch: 'wtm/t1', base: 'main', path: join(cfg.vault, 't1'), createdAt: 'c', updatedAt: 'u' })
  upsertRecord(ledger, { task: 'T2', branch: 'wtm/t2', base: 'main', path: join(cfg.vault, 't2'), createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  mkdirSync(join(cfg.vault, 't1'), { recursive: true })
  mkdirSync(join(cfg.vault, 't2'), { recursive: true })
  const wt = 'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
    'worktree ' + join(cfg.vault, 't1') + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/wtm/t1\n\n' +
    'worktree ' + join(cfg.vault, 't2') + '\nHEAD ' + '3'.repeat(40) + '\nbranch refs/heads/wtm/t2\n'
  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES(wt))
  // T1 正常，T2 的 merge 失败
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['merge-base', '--is-ancestor', 'refs/heads/wtm/t1', 'HEAD'], FAIL('not an ancestor', 1))
  git.on(['merge-base', '--is-ancestor', 'refs/heads/wtm/t2', 'HEAD'], FAIL('not an ancestor', 1))
  git.on(['status', '--porcelain'], OK(''))
  git.on(['config', '--get', 'branch.main.mergeOptions'], FAIL('', 1))
  git.on(['rev-parse', '--verify', 'refs/heads/wtm/t1^{commit}'], OK(`${'2'.repeat(40)}\n`))
  git.on(['rev-parse', '--verify', 'refs/heads/wtm/t2^{commit}'], OK(`${'3'.repeat(40)}\n`))
  git.on(['rev-parse', '--verify', 'HEAD^{commit}'], OK(`${'1'.repeat(40)}\n`))
  git.on(['merge-tree', '--write-tree', `${'1'.repeat(40)}`, `${'2'.repeat(40)}`], OK(`${'4'.repeat(40)}\n`))
  git.on(['merge-tree', '--write-tree', `${'1'.repeat(40)}`, `${'3'.repeat(40)}`], OK(`${'5'.repeat(40)}\n`))
  git.on(['rev-parse', '--git-path', 'hooks'], OK('.git/hooks\n'))
  git.on(['merge', '--no-ff', 'refs/heads/wtm/t1', '-m', 'fold T1 into main'], OK('merged'))
  git.on(['merge', '--no-ff', 'refs/heads/wtm/t2', '-m', 'fold T2 into main'], FAIL('conflict'))
  git.on(['worktree', 'remove', join(cfg.vault, 't1')], OK())
  git.on(['worktree', 'remove', join(cfg.vault, 't2')], OK())
  git.on(['branch', '-d', 'wtm/t1'], OK())
  git.on(['branch', '-d', 'wtm/t2'], OK())

  const r = await purge({ root: 'C:/repo', tasks: ['T1', 'T2'], cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.ok(r.results, '应有 results')
  assert.equal(r.results.length, 2)
  const t1 = r.results.find((x) => x.task === 'T1')
  const t2 = r.results.find((x) => x.task === 'T2')
  assert.ok(t1, '应有 T1')
  assert.ok(t2, '应有 T2')
  assert.equal(t1.ok, true)
  assert.equal(t2.ok, false)
  assert.match(t2.error ?? '', /conflict/)
  assert.equal(loadLedger(cfg.vault).records.length, 1)
  assert.equal(loadLedger(cfg.vault).records[0].task, 'T2')
  rmSync(tmp, { recursive: true, force: true })
})

test('purge：未指定 tasks 也未指定 all 时报错；未知任务单独报告', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const r1 = await purge({ root: 'C:/repo', cfg, git, repo: null })
  assert.equal(r1.ok, false)
  const r2 = await purge({ root: 'C:/repo', tasks: ['ghost'], cfg, git, repo: null })
  assert.equal(r2.ok, true)
  assert.ok(r2.results, '应有 results')
  assert.equal(r2.results[0].ok, false)
  rmSync(tmp, { recursive: true, force: true })
})

test('purge：all 模式处理全部记录', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
    const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T1', branch: 'wtm/t1', base: 'main', path: 'P1', createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  // 工作区已消失 → stale 清理分支
  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES('worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n'))
  const r = await purge({ root: 'C:/repo', all: true, cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.ok(r.results, '应有 results')
  assert.equal(r.results.length, 1)
  assert.equal(r.results[0].ok, true)
  rmSync(tmp, { recursive: true, force: true })
})

test('purge：工作区路径被普通文件替换时报告失败并保留记录', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  rmSync(taskPath, { recursive: true, force: true })
  fs.writeFileSync(taskPath, 'not a directory')

  const r = await purge({ root: 'C:/repo', tasks: ['T'], mode: 'commit', cfg, git, repo: null })

  assert.equal(r.ok, true)
  assert.equal(r.results?.[0].ok, false)
  assert.match(r.results?.[0].error ?? '', /工作区|目录/)
  assert.equal(loadLedger(vault).records.length, 1)
  assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
  assert.equal(git.count(['worktree', 'remove', taskPath]), 0)
  assert.equal(git.count(['branch', '-d', 'wtm/t']), 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('purge：keep 模式工作区路径被普通文件替换时报告失败并保留记录', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  rmSync(taskPath, { recursive: true, force: true })
  fs.writeFileSync(taskPath, 'not a directory')

  const r = await purge({ root: 'C:/repo', tasks: ['T'], mode: 'keep', cfg, git, repo: null })

  assert.equal(r.ok, true)
  assert.equal(r.results?.[0].ok, false)
  assert.match(r.results?.[0].error ?? '', /工作区|目录/)
  assert.equal(loadLedger(vault).records.length, 1)
  assert.equal(git.count(['worktree', 'remove', taskPath]), 0)
  assert.equal(git.count(['branch', '-d', 'wtm/t']), 0)
  assert.equal(git.count(['branch', '-D', 'wtm/t']), 0)
  rmSync(tmp, { recursive: true, force: true })
})

// ── 第一轮审查补充的回归测试 ────────────────────────────────────────────────

test('mergeTask：工作区分支与账本不一致时拒绝（防静默错分支提交）', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T', branch: 'wtm/t', base: 'main', path: join(cfg.vault, 't'), createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  mkdirSync(join(cfg.vault, 't'), { recursive: true })
  // 工作区在别的分支上
  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES('worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\nworktree ' + join(cfg.vault, 't') + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/other\n'))
  const r = await mergeTask({ root: 'C:/repo', task: 'T', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /不一致/)
  assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0, '不应执行合并')
  rmSync(tmp, { recursive: true, force: true })
})

test('mergeTask：主工作区不在账本基分支时拒绝（防合入错误分支）', async () => {
  const tmp = makeTmp()
  const { cfg, git } = mergeFixture(tmp)
  git.on(['branch', '--show-current'], OK('develop\n'))
  const r = await mergeTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /develop/)
  assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('mergeTask：任务分支已合并时跳过重复合并（重试不再产生空 merge 提交）', async () => {
  const tmp = makeTmp()
  const { cfg, git } = mergeFixture(tmp)
  git.on(['merge-base', '--is-ancestor', 'refs/heads/wtm/t', 'HEAD'], OK())
  const r = await mergeTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.equal(r.merged, false)
  assert.ok((r.warnings ?? []).some((w) => /已包含/.test(w)))
  assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('mergeTask：任务分支已合并时跳过 on_merge 触发器', async () => {
  const tmp = makeTmp()
  const { cfg, git } = mergeFixture(tmp)
  git.on(['merge-base', '--is-ancestor', 'refs/heads/wtm/t', 'HEAD'], OK())
  let triggerCalls = 0

  const r = await mergeTask({
    root: 'C:/repo',
    task: 'T',
    mode: 'commit',
    cfg,
    git,
    repo: { triggers: { on_merge: ['deploy.sh'] } },
    triggerSpawn: () => {
      triggerCalls += 1
      throw new Error('on_merge should not run for an already-merged branch')
    },
  })

  assert.equal(r.ok, true)
  assert.equal(r.merged, false)
  assert.equal(triggerCalls, 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('mergeTask/finishTask：缺少任务名直接报错（不出现 undefined）', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const r1 = await mergeTask({ root: 'C:/repo', cfg, git, repo: null })
  assert.equal(r1.ok, false)
  assert.match(r1.error ?? '', /task/)
  const r2 = await finishTask({ root: 'C:/repo', cfg, git, repo: null })
  assert.equal(r2.ok, false)
  assert.match(r2.error ?? '', /task/)
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：seed 路径穿越被拦截并告警（不复制仓库外文件）', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', 'refs/heads/wtm/t'], FAIL())
  git.on(['status', '--porcelain'], OK(''))
  git.on(['worktree', 'add', join(tmp, 'vault', 't'), '-b', 'wtm/t', 'refs/heads/main'], OK())
  const repo = { seed: { files: ['../evil.txt', '/abs/evil.txt'] } }
  const r = await begin({ root: 'C:/repo', task: 'T', cfg, git, repo })
  assert.equal(r.ok, true)
  const evilWarnings = (r.warnings ?? []).filter((w) => /越界/.test(w))
  assert.equal(evilWarnings.length, 2, JSON.stringify(r.warnings))
  rmSync(tmp, { recursive: true, force: true })
})

test('begin：不同任务派生同一 slug 时拒绝（工作区路径冲突）', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  // 账本中已有任务 A-B 占用同一工作区路径（a b 与 a-b 的 slug 相同）
  const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'A-B', branch: 'wtm/a-b', base: 'main', path: join(cfg.vault, 'a-b'), createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  git.on(['branch', '--show-current'], OK('main\n'))
  git.on(['show-ref', '--verify', 'refs/heads/main'], OK())
  git.on(['show-ref', '--verify', 'refs/heads/wtm/a-b'], FAIL())
  git.on(['status', '--porcelain'], OK(''))
  const r = await begin({ root: 'C:/repo', task: 'a b', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /工作区目录/)
  rmSync(tmp, { recursive: true, force: true })
})

// ── 第二轮审查补充的回归测试 ────────────────────────────────────────────────

test('finishTask：commit 模式工作区分支不一致时拒绝（收尾路径的分支漂移防护）', async () => {
  const tmp = makeTmp()
  const { cfg, git } = mergeFixture(tmp, { taskDirty: true })
  // 工作区被切到其他分支
  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES('worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\nworktree ' + join(cfg.vault, 't') + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/other\n'))
  const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /不一致/)
  assert.equal(git.count(['commit', '-m', 'snapshot T']), 0, '不应执行快照提交')
  assert.equal(git.count(['worktree', 'remove', join(cfg.vault, 't')]), 0, '不应移除工作区')
  // 账本记录应保留
  assert.equal(loadLedger(cfg.vault).records.length, 1)
  rmSync(tmp, { recursive: true, force: true })
})

test('mergeTask：工作区目录被外部删除时按 stale 报错（注册表仍列出 prunable 条目）', async () => {
  const tmp = makeTmp()
  const { cfg, git } = mergeFixture(tmp)
  // 删除目录（模拟外部 rm -rf），但 worktree list 仍列出该条目（git 未 prune）
  rmSync(join(cfg.vault, 't'), { recursive: true, force: true })
  const r = await mergeTask({ root: 'C:/repo', task: 'T', cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /已不存在/)
  assert.equal(git.count(['status', '--porcelain']), 0, '不应尝试在已删除目录上运行 git')
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：工作区目录被外部删除时清理记录（stale 清理真实可达）', async () => {
  const tmp = makeTmp()
  const { cfg, git } = mergeFixture(tmp)
  rmSync(join(cfg.vault, 't'), { recursive: true, force: true })
  const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.match(r.note ?? '', /已不存在/)
  assert.equal(loadLedger(cfg.vault).records.length, 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('finishTask：工作区暂时不可访问时失败并保留记录', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp)
  const taskPath = join(vault, 't')
  const realStatSync = fs.statSync
  const inaccessible = Object.assign(new Error('permission denied'), { code: 'EACCES' })
  mock.method(fs, 'statSync', (/** @type {string} */ target) => {
    if (target === taskPath) throw inaccessible
    return realStatSync(target)
  })
  syncBuiltinESMExports()

  try {
    const r = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })
    assert.equal(r.ok, false)
    assert.match(r.error ?? '', /工作区/)
    assert.match(r.error ?? '', /permission denied/)
    assert.equal(loadLedger(vault).records.length, 1)
    assert.equal(git.count(['commit', '-m', 'snapshot T']), 0)
    assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
    assert.equal(git.count(['worktree', 'remove', taskPath]), 0)
  } finally {
    mock.restoreAll()
    syncBuiltinESMExports()
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('listStatus：工作区目录被外部删除时 exists=false（不谎报健康）', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T', branch: 'wtm/t', base: 'main', path: join(cfg.vault, 't'), createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  // 注册表仍列出（prunable），但目录不存在
  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES('worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\nworktree ' + join(cfg.vault, 't') + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/wtm/t\n'))
  const r = await listStatus({ root: 'C:/repo', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.ok(r.rows, '应有 rows')
  assert.equal(r.rows[0].exists, false)
  assert.equal(git.count(['status', '--porcelain']), 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('listStatus：工作区路径被普通文件替换时 exists=false（不在文件上运行 git）', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const taskPath = join(cfg.vault, 't')
  const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T', branch: 'wtm/t', base: 'main', path: taskPath, createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  fs.writeFileSync(taskPath, 'not a directory')
  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES(
    'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
    'worktree ' + taskPath + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/wtm/t\n',
  ))

  const r = await listStatus({ root: 'C:/repo', cfg, git, repo: null })
  assert.equal(r.ok, true)
  assert.equal(r.rows?.[0].exists, false)
  assert.equal(r.rows?.[0].dirty, false)
  assert.equal(r.rows?.[0].counts, null)
  assert.equal(git.count(['status', '--porcelain']), 0)
  rmSync(tmp, { recursive: true, force: true })
})

test('listStatus：工作区暂时不可访问时标记未知并返回警告', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const taskPath = join(cfg.vault, 't')
  const ledger = structuredClone(EMPTY_LEDGER)
  upsertRecord(ledger, { task: 'T', branch: 'wtm/t', base: 'main', path: taskPath, createdAt: 'c', updatedAt: 'u' })
  saveLedger(cfg.vault, ledger)
  mkdirSync(taskPath, { recursive: true })
  git.on(['worktree', 'list', '--porcelain', '-z'], WORKTREES(
    'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
    'worktree ' + taskPath + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/wtm/t\n',
  ))

  const realStatSync = fs.statSync
  const inaccessible = Object.assign(new Error('I/O error'), { code: 'EIO' })
  mock.method(fs, 'statSync', (/** @type {string} */ target) => {
    if (target === taskPath) throw inaccessible
    return realStatSync(target)
  })
  syncBuiltinESMExports()

  try {
    const r = await listStatus({ root: 'C:/repo', cfg, git, repo: null })
    assert.equal(r.ok, true)
    assert.ok(r.rows, '应有 rows')
    assert.equal(r.rows[0].exists, false)
    assert.equal(r.rows[0].dirty, null)
    assert.equal(r.rows[0].counts, null)
    assert.ok(r.warnings?.some((w) => /T/.test(w) && /I\/O error/.test(w)), JSON.stringify(r.warnings))
    assert.equal(git.count(['status', '--porcelain']), 0)
  } finally {
    mock.restoreAll()
    syncBuiltinESMExports()
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('purge：all 与 tasks 同时指定时报错', async () => {
  const tmp = makeTmp()
  const cfg = baseCfg(tmp)
  const git = new FakeGit()
  const r = await purge({ root: 'C:/repo', tasks: ['T1'], all: true, cfg, git, repo: null })
  assert.equal(r.ok, false)
  assert.match(r.error ?? '', /二选一/)
  rmSync(tmp, { recursive: true, force: true })
})

test('mergeTask：脏检查后工作区分支漂移时拒绝暂存', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault, taskGitDir } = mergeFixture(tmp, { taskDirty: true })
  const taskPath = join(vault, 't')
  let taskBranch = 'wtm/t'
  git.on(['worktree', 'list', '--porcelain', '-z'], () => WORKTREES(
    'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
    'worktree ' + taskPath + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/' + taskBranch + '\n',
  ))
  git.on(['status', '--porcelain'], (/** @type {{cwd: string | undefined}} */ ctx) => {
    if (ctx.cwd !== taskPath) return OK('')
    taskBranch = 'other'
    return OK(' M f.txt\n')
  })

  try {
    const result = await mergeTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })

    assert.equal(result.ok, false)
    assert.match(result.error ?? '', /分支与账本记录不一致/)
    assert.equal(git.count(['add', '-A']), 0, 'drift before staging must not stage task changes')
    assert.equal(git.count(['commit', '-m', 'snapshot T']), 0)
    assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
    assert.equal(loadLedger(vault).records.length, 1)
    assert.equal(fs.existsSync(join(taskGitDir, 'HEAD.lock')), false, 'rejected snapshot must release HEAD.lock')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('finishTask：暂存期间工作区分支漂移时拒绝快照提交', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault, taskGitDir } = mergeFixture(tmp, { taskDirty: true })
  const taskPath = join(vault, 't')
  let taskBranch = 'wtm/t'
  git.on(['worktree', 'list', '--porcelain', '-z'], () => WORKTREES(
    'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
    'worktree ' + taskPath + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/' + taskBranch + '\n',
  ))
  git.on(['add', '-A'], () => {
    taskBranch = 'other'
    return OK()
  })

  try {
    const result = await finishTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })

    assert.equal(result.ok, false)
    assert.match(result.error ?? '', /分支与账本记录不一致/)
    assert.equal(git.count(['add', '-A']), 1)
    assert.equal(git.count(['commit', '-m', 'snapshot T']), 0, 'drift after staging must stop the commit')
    assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
    assert.equal(git.count(['worktree', 'remove', taskPath]), 0, 'failed snapshot must preserve the worktree')
    assert.equal(loadLedger(vault).records.length, 1)
    assert.equal(fs.existsSync(join(taskGitDir, 'HEAD.lock')), false, 'rejected snapshot must release HEAD.lock')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('mergeTask：git commit 前释放工作区 HEAD 锁', async () => {
  const tmp = makeTmp()
  const { cfg, git, taskGitDir } = mergeFixture(tmp, { taskDirty: true })
  const headLockPath = join(taskGitDir, 'HEAD.lock')
  let lockObservedAtCommit = false
  git.on(['commit', '-m', 'snapshot T'], () => {
    lockObservedAtCommit = fs.existsSync(headLockPath)
    return OK('[wtm/t 9999999] snapshot T')
  })

  try {
    const result = await mergeTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })

    assert.equal(result.ok, true)
    assert.equal(lockObservedAtCommit, false, 'git commit must acquire HEAD.lock itself')
    assert.equal(fs.existsSync(headLockPath), false, 'snapshot completion must release HEAD.lock')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('mergeTask：commit 期间分支切走再切回时拒绝错误快照', async () => {
  const tmp = makeTmp()
  const { cfg, git, vault } = mergeFixture(tmp, { taskDirty: true })
  const taskPath = join(vault, 't')
  let taskBranch = 'wtm/t'
  git.on(['worktree', 'list', '--porcelain', '-z'], () => WORKTREES(
    'worktree C:/repo\nHEAD ' + '1'.repeat(40) + '\nbranch refs/heads/main\n\n' +
    'worktree ' + taskPath + '\nHEAD ' + '2'.repeat(40) + '\nbranch refs/heads/' + taskBranch + '\n',
  ))
  git.on(['commit', '-m', 'snapshot T'], () => {
    taskBranch = 'other'
    taskBranch = 'wtm/t'
    return OK('[other 9999999] snapshot T')
  })
  git.on(['rev-parse', '--verify', 'HEAD^{commit}'], (/** @type {{cwd: string | undefined}} */ ctx) => (
    ctx.cwd === taskPath ? OK(`${'2'.repeat(40)}\n`) : OK(`${'1'.repeat(40)}\n`)
  ))
  git.on(['rev-parse', '--verify', 'refs/heads/wtm/t^{commit}'], OK(`${'2'.repeat(40)}\n`))
  git.on(['rev-parse', '--verify', 'HEAD^'], OK(`${'1'.repeat(40)}\n`))

  try {
    const result = await mergeTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })

    assert.equal(result.ok, false)
    assert.match(result.error ?? '', /未落在账本任务分支/)
    assert.equal(git.count(['commit', '-m', 'snapshot T']), 1)
    assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
    assert.equal(loadLedger(vault).records[0]?.updatedAt, 'u')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

test('mergeTask：HEAD 已被其他 Git 操作锁定时拒绝快照', async () => {
  const tmp = makeTmp()
  const { cfg, git, taskGitDir } = mergeFixture(tmp, { taskDirty: true })
  const headLockPath = join(taskGitDir, 'HEAD.lock')
  fs.writeFileSync(headLockPath, '')

  try {
    const result = await mergeTask({ root: 'C:/repo', task: 'T', mode: 'commit', cfg, git, repo: null })

    assert.equal(result.ok, false)
    assert.match(result.error ?? '', /锁定任务工作区分支失败/)
    assert.equal(git.count(['add', '-A']), 0)
    assert.equal(git.count(['commit', '-m', 'snapshot T']), 0)
    assert.equal(git.count(['merge', '--no-ff', 'refs/heads/wtm/t', '-m', 'fold T into main']), 0)
    assert.equal(fs.existsSync(headLockPath), true, 'snapshot must not remove another Git process\'s lock')
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})
