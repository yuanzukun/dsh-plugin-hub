/**
 * 任务名 ↔ 分支名的映射与校验。
 *
 * 设计要点：工具面向“任务”而非“分支”。用户给一个任务名，插件据此
 * 派生出稳定的分支名，并做两重防线：
 *   1. slugify 在源头保证派生分支永远合法；
 *   2. validateBranch 完整实现 git 的 ref 规则，作为显式分支参数的边界校验。
 */

const MAX_BRANCH_BYTES = 255
const MAX_SLUG_LENGTH = 60
const MIN_SLUG_UTF8_BYTES = 4
const MAX_TASK_LENGTH = 200
const WINDOWS_DEVICE_NAME_RE = /^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?$/u

/**
 * @param {string} slug
 * @returns {string}
 */
function normalizeTruncatedSlug(slug) {
  return slug
    .split('/')
    .map((seg) => seg
      .replace(/\.{2,}/g, '-')
      .replace(/\.lock$/g, '-lock')
      .replace(/^\.+/g, ''))
    .filter((seg) => seg !== '')
    .join('/')
    .replace(/-+/g, '-')
    .replace(/^[-./]+|[-./]+$/g, '')
}

/**
 * @param {string} value
 * @returns {number}
 */
function utf8ByteLength(value) {
  return Buffer.byteLength(value, 'utf8')
}

/**
 * @param {string} value
 * @param {number} maxBytes
 * @returns {string}
 */
function truncateByUtf8Bytes(value, maxBytes) {
  let result = ''
  let length = 0
  for (const ch of value) {
    const chLength = utf8ByteLength(ch)
    if (length + chLength > maxBytes) break
    result += ch
    length += chLength
  }
  return result
}

/**
 * 将任意任务名规范化为分支可用的 slug（全小写、非法字符转连字符）。
 * 允许 Unicode 字母/数字（含 CJK）、下划线、点、连字符、斜杠分段。
 * 返回的 slug 一定可以通过 validateBranch 的组件级检查
 * （段内不出现 ..、段不以 .lock 结尾、段不以 . 开头）。
 * @param {string | null | undefined} task
 * @returns {string}
 */
export function slugifyTask(task) {
  if (task === null || task === undefined) return 'task'
  const normalized = String(task).normalize('NFKC').toLowerCase()
  // 非法字符（非字母/数字/组合标记及 . _ - /）折叠为单个连字符
  const replaced = normalized.replace(/[^\p{L}\p{N}\p{M}._/-]+/gu, '-')
  // 分段处理：剔除空段、. 与 .. 段；并修正段内非法形态
  const segments = replaced
    .split('/')
    .filter((seg) => seg !== '' && seg !== '.' && seg !== '..')
    .map((seg) => seg
      // 段内连续点（如 a..b）折叠为连字符
      .replace(/\.{2,}/g, '-')
      // 段不能以 .lock 结尾
      .replace(/\.lock$/g, '-lock')
      // 段不能以 . 开头
      .replace(/^\.+/g, ''))
    .filter((seg) => seg !== '')
  let slug = segments.join('/')
  // 折叠连续连字符，剥掉首尾的 /、- 与 .
  slug = slug.replace(/-+/g, '-').replace(/^[-./]+|[-./]+$/g, '')
  if (slug.length > MAX_SLUG_LENGTH) {
    // 按 Unicode code point 截断，避免切断非 BMP 字符；同时可能把段尾切在
    // .lock / . / - 上，甚至切出一个空段（切在 / 后），
    // 导致派生分支违反 ref 规则（与“slug 必通过 validateBranch”的契约冲突）。
    // 对截断结果重新做一次段级修正。
    slug = normalizeTruncatedSlug(Array.from(slug).slice(0, MAX_SLUG_LENGTH).join(''))
  }
  if (slug === '' || slug === '.') return 'task'
  return slug
}

/**
 * 由任务名派生分支名：<prefix>/<slug>。
 * @param {string} task
 * @param {string} [prefix='wtm'] 分支前缀（必须是单段合法 ref）
 * @returns {string}
 */
export function deriveBranch(task, prefix = 'wtm') {
  const slug = slugifyTask(task)
  const maxSlugBytes = MAX_BRANCH_BYTES - utf8ByteLength(prefix) - 1
  const boundedSlug = utf8ByteLength(slug) > maxSlugBytes
    ? normalizeTruncatedSlug(truncateByUtf8Bytes(slug, maxSlugBytes))
    : slug
  return `${prefix}/${boundedSlug}`
}

/**
 * 校验分支名是否符合 git 的 ref 规则（check-ref-format 语义的纯函数版）。
 * @param {string} branch
 * @returns {{ok: true} | {ok: false, reason: string}}
 */
export function validateBranch(branch) {
  if (typeof branch !== 'string') return { ok: false, reason: '分支名必须是字符串' }
  if (branch.length === 0) return { ok: false, reason: '分支名为空' }
  if (utf8ByteLength(branch) > MAX_BRANCH_BYTES) {
    return { ok: false, reason: `分支名超过 ${MAX_BRANCH_BYTES} 字节` }
  }
  if (branch.startsWith('-')) return { ok: false, reason: '分支名不能以 - 开头' }
  if (branch.startsWith('/')) return { ok: false, reason: '分支名不能以 / 开头' }
  if (branch.endsWith('/') || branch.endsWith('.')) {
    return { ok: false, reason: '分支名不能以 / 或 . 结尾' }
  }
  if (branch.includes('//')) return { ok: false, reason: '分支名不能包含连续 /' }
  if (branch.includes('..')) return { ok: false, reason: '分支名不能包含 ..' }
  if (branch.includes('@{')) return { ok: false, reason: '分支名不能包含 @{' }
  // HEAD 是 Git 的保留伪引用，不能作为分支名
  if (branch === 'HEAD') return { ok: false, reason: '分支名不能是保留的 HEAD' }
  // 逐字符黑名单：空格、~ ^ : ? * [ \、控制字符
  for (const ch of branch) {
    if (/\s/u.test(ch)) return { ok: false, reason: `分支名不能包含空白字符: ${JSON.stringify(ch)}` }
    if ('~^:?*[\\'.includes(ch)) return { ok: false, reason: `分支名包含非法字符: ${JSON.stringify(ch)}` }
    if (/\p{C}/u.test(ch)) return { ok: false, reason: '分支名不能包含控制字符' }
  }
  // 分段规则：每段不能以 . 开头、不能以 .lock 结尾
  for (const seg of branch.split('/')) {
    if (seg.startsWith('.')) return { ok: false, reason: `分段不能以 . 开头: ${seg}` }
    if (seg.endsWith('.lock')) return { ok: false, reason: `分段不能以 .lock 结尾: ${seg}` }
  }
  return { ok: true }
}

/**
 * 校验分支前缀：必须是单段合法 ref（不能包含 /）。
 * @param {string} prefix
 * @returns {{ok: true} | {ok: false, reason: string}}
 */
export function validatePrefix(prefix) {
  const r = validateBranch(prefix)
  // HEAD is reserved only as a complete branch name, not as a prefix such as HEAD/task.
  if (!r.ok && prefix !== 'HEAD') return r
  if (prefix.includes('/')) return { ok: false, reason: '前缀必须是单段，不能包含 /' }
  if (utf8ByteLength(prefix) > MAX_BRANCH_BYTES - 1 - MIN_SLUG_UTF8_BYTES) {
    return { ok: false, reason: '前缀过长，无法为派生 slug 留出空间' }
  }
  return { ok: true }
}

/**
 * 校验任务名：非空、长度受限。
 * @param {string} task
 * @returns {{ok: true} | {ok: false, reason: string}}
 */
export function validateTask(task) {
  if (typeof task !== 'string' || task.trim() === '') {
    return { ok: false, reason: '任务名不能为空' }
  }
  if (task.length > MAX_TASK_LENGTH) {
    return { ok: false, reason: `任务名超过 ${MAX_TASK_LENGTH} 字符` }
  }
  const deviceName = slugifyTask(task)
    .split('/')
    .find((segment) => WINDOWS_DEVICE_NAME_RE.test(segment))
  if (deviceName) {
    return { ok: false, reason: `任务名会生成 Windows 保留设备名工作区目录: ${deviceName}` }
  }
  return { ok: true }
}
