window.__ModuleLoader__.load({
  id: 'dsh-model-insights',
  factory(require) {
    const React = require('react')
    const h = React.createElement

    /** Artificial Analysis snapshot, embedded at build time. */
    const AA = /*__AA_DATA__*/null

    const VARIANTS = new Set([
      'max', 'high', 'low', 'xhigh', 'medium', 'minimal', 'none',
      'default', 'fallback', 'reasoning', 'non', 'thinking', 'think',
      'preview', 'exp', 'experimental', 'turbo', 'instruct', 'chat',
      'latest', 'alpha', 'beta', 'rc', 'defaultfallback', 'hybrid',
      'highspeed', 'fast',
    ])

    const tokensOf = (text) =>
      String(text || '')
        .toLowerCase()
        .replace(/[^a-z0-9.]+/g, ' ')
        .trim()
        .split(' ')
        .filter(Boolean)
        .map((t) => t.replace(/\./g, ''))
        .filter((t) => t && !VARIANTS.has(t))

    const compactOf = (text) => tokensOf(text).join('')
    const NUMERIC = /^\d+$/

    const byKey = new Map()
    for (const row of AA.models) {
      const key = compactOf(row.n)
      if (key && !byKey.has(key)) byKey.set(key, row)
    }

    const byTokens = AA.models.map((row) => {
      const tokens = tokensOf(row.n)
      return { row, tokens, set: new Set(tokens) }
    })

    /**
     * Exact compact-name match first, then a guarded fuzzy pass: the query's
     * version numbers must all appear in the AA name, and only date-code-like
     * extras (>= 3 digits) are tolerated.
     */
    const lookup = (id, name) => {
      for (const key of [compactOf(name), compactOf(id)]) {
        if (key && byKey.has(key)) return byKey.get(key)
      }
      let best = null
      let bestScore = 0
      let bestExtra = Infinity
      for (const query of [tokensOf(name), tokensOf(id)]) {
        if (!query.length) continue
        const querySet = new Set(query)
        const queryNums = query.filter((t) => NUMERIC.test(t))
        for (const entry of byTokens) {
          if (!queryNums.every((n) => entry.set.has(n))) continue
          const extraNumbers = entry.tokens.filter((t) => NUMERIC.test(t) && !queryNums.includes(t))
          if (extraNumbers.some((n) => n.length < 3)) continue
          let shared = 0
          for (const token of querySet) if (entry.set.has(token)) shared++
          const coverage = shared / querySet.size
          const extra = entry.tokens.length - shared
          if (coverage > bestScore || (coverage === bestScore && extra < bestExtra)) {
            bestScore = coverage
            best = entry.row
            bestExtra = extra
          }
        }
      }
      return bestScore >= 0.8 ? best : null
    }

    const money = (value) => {
      if (value === null || value === undefined) return '—'
      if (value === 0) return '$0'
      return value < 0.01 ? '<$0.01' : '$' + value.toFixed(2)
    }

    /** Grade letters come from Pareto layers of the effort points. */
    const GRADE_COLOR = {
      S: 'var(--dsw-alias-state-success-primary)',
      A: 'var(--dsw-alias-brand-primary)',
      B: 'var(--dsw-alias-label-primary)',
      C: 'var(--dsw-alias-state-warn-primary)',
      D: 'var(--dsw-alias-state-error-primary)',
    }

    const pill = (children, options) =>
      h(
        'span',
        {
          title: options && options.title,
          style: {
            display: 'inline-flex',
            alignItems: 'center',
            gap: 4,
            marginInlineStart:
              options && options.marginInlineStart !== undefined ? options.marginInlineStart : 6,
            padding: '0 5px',
            height: 16,
            borderRadius: 8,
            border: '1px solid var(--dsw-alias-border-l1)',
            background: 'var(--dsw-alias-bg-layer-2)',
            color: options && options.color ? options.color : 'var(--dsw-alias-label-secondary)',
            fontSize: 10,
            lineHeight: '14px',
            fontWeight: 500,
            whiteSpace: 'nowrap',
            verticalAlign: 'middle',
            flex: 'none',
          },
        },
        children,
      )

    const readLabel = (t, key, fallback) => {
      try {
        const value = t(key)
        return value === key ? fallback : value
      } catch {
        return fallback
      }
    }

    const round = (value) => Math.round(value)
    const iqText = (row) =>
      row.iq[0] === row.iq[1] ? String(round(row.iq[1])) : `${round(row.iq[0])}–${round(row.iq[1])}`
    const gradeText = (row) => (row.gr[0] === row.gr[1] ? row.gr[0] : `${row.gr[0]}–${row.gr[1]}`)

    const effortLine = (point) =>
      [
        point.e || '—',
        'IQ ' + round(point.i),
        point.c === null || point.c === undefined ? null : money(point.c) + '/task',
        point.r || null,
      ]
        .filter(Boolean)
        .join(' · ')


    /** The last model the owner marked as selected; the menu panel reads this. */
    const selection = { row: null, name: '', listeners: new Set() }
    const publishSelection = (row, name) => {
      const changed = selection.row !== row || selection.name !== name
      selection.row = row
      selection.name = name || ''
      if (!changed) return
      for (const listener of [...selection.listeners]) listener()
    }
    const subscribeSelection = (listener) => {
      selection.listeners.add(listener)
      return () => selection.listeners.delete(listener)
    }


    /** Battery cells rendered as React nodes (model rows show no price text). */
    const batteryNode = (cost) => {
      const level = costLevel(cost)
      return h(
        'span',
        {
          key: 'battery',
          'aria-hidden': true,
          style: { display: 'inline-flex', gap: 1, alignItems: 'flex-end', flex: 'none' },
        },
        Array.from({ length: 5 }, (_, index) =>
          h('span', {
            key: index,
            style: {
              width: 3,
              height: 6 + index * 1.5,
              borderRadius: 1,
              boxSizing: 'border-box',
              background: index < level ? costTone(level) : 'transparent',
              border: index < level ? 'none' : '1px solid var(--dsw-alias-border-l2)',
            },
          }),
        ),
      )
    }

    function makeBadge(t) {
      return function ModelInsightBadge(props) {
        const model = props && props.model
        if (!model) return null
        // This slot owns the label itself: the model name has to render here.
        const name = model.name || model.displayName || model.id || ''
        const label = h(
          'span',
          {
            key: 'name',
            'data-dsh-mi-name': name,
            style: {
              minWidth: 0,
              flex: '0 1 auto',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
              color: 'inherit',
              fontSize: 'inherit',
              lineHeight: 'inherit',
              fontWeight: 'inherit',
            },
          },
          name,
        )
        const row = lookup(model.id, model.name)
        if (!row) return label
        if (props.selected) publishSelection(row, name)

        // A row that names its effort (e.g. "GPT-6.2 Astra (max)") shows that
        // single point; otherwise the badge shows the whole range.
        const suffix = /\((max|xhigh|high|medium|low)\)/i.exec(name)
        const point = suffix ? row.pts.find((p) => (p.e || '').toLowerCase() === suffix[1].toLowerCase()) : null
        const view = point
          ? { ...row, iq: [point.i, point.i], gr: [point.r, point.r], p: point.y === 1 ? 1 : 0 }
          : row

        const isTrigger = props.placement === 'trigger'
        // Collapsed composer stays clean: the numbers belong to the open menu.
        if (isTrigger) return label
        const title = [
          row.n,
          readLabel(t, 'badge.intelligence', 'Intelligence index') + ': ' + iqText(view),
          readLabel(t, 'badge.grade', 'Value grade') + ': ' + gradeText(view),
          '',
          ...row.pts.map((p) => effortLine(p)),
          '',
          AA.source + ' · ' + AA.snapshot,
        ].join('\n')

        return h(
          'span',
          {
            key: 'row',
            style: {
              display: 'flex',
              alignItems: 'center',
              minWidth: 0,
              maxWidth: '100%',
              flex: isTrigger ? '0 1 auto' : '1 1 auto',
              width: isTrigger ? 'auto' : '100%',
              gap: 6,
              color: 'inherit',
              fontSize: 'inherit',
              lineHeight: 'inherit',
            },
          },
          label,
          pill(
            [
              batteryNode(view.d ? view.d.c : null),
              h('span', { key: 'iq' }, 'IQ ' + iqText(view)),
              h('span', { key: 'sep', style: { opacity: 0.45 } }, '·'),
              h(
                'span',
                {
                  key: 'grade',
                  title: readLabel(t, 'badge.grade', 'Value grade') + ': ' + gradeText(view),
                  style: {
                    fontWeight: 700,
                    color: GRADE_COLOR[view.gr[0]] || 'inherit',
                    letterSpacing: '0.02em',
                  },
                },
                gradeText(view),
              ),
              view.p
                ? h('span', { key: 'frontier', 'aria-hidden': true, style: { opacity: 0.75 } }, '◆')
                : null,
            ],
            { title, marginInlineStart: isTrigger ? 4 : 'auto' },
          ),
        )
      }
    }

    /**
     * The native reasoning menu is owner-rendered with no extension slot, so its
     * rows are decorated in place: every effort row shows that model's AA IQ and
     * Pareto grade. Deliberately defensive — if the markup changes nothing is
     * decorated, and the model-menu panel still carries the same numbers.
     */
    const EFFORT_LABELS = new Set(['default', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'])
    const BADGE_ATTR = 'data-dsh-model-insights'
    const LEVEL_ATTR = 'data-dsh-mi-level'
    const TONE_ATTR = 'data-dsh-mi-tone'


    /** Cost shown the way a phone shows battery: five cells, log-scaled. */
    const costLevel = (cost) => {
      const bands = AA.costBands
      if (!Number.isFinite(cost) || cost <= 0) return 1
      if (!bands || bands.length !== 4) return 3
      let level = 1
      for (const band of bands) if (cost > band) level++
      return Math.min(5, level)
    }

    /** Cheap reads green, mid amber, expensive red. */
    const COST_COLOR = {
      low: 'var(--dsw-alias-state-success-primary)',
      mid: 'var(--dsw-alias-state-warn-primary)',
      high: 'var(--dsw-alias-state-error-primary)',
    }
    const costTone = (level) => (level <= 2 ? COST_COLOR.low : level === 3 ? COST_COLOR.mid : COST_COLOR.high)

    const badgeText = (point, compact) => {
      if (!point) return ''
      const parts = [point.c === null || point.c === undefined ? '\u2014' : money(point.c)]
      if (!compact) {
        parts.push('\u00b7', 'IQ ' + round(point.i))
        if (point.r) parts.push(point.r)
      }
      return parts.filter(Boolean).join(' ')
    }

    const STYLE_ID = 'dsh-model-insights-style'

    /**
     * Decorate the native reasoning menu without touching React's tree: the row
     * gets a data attribute and a stylesheet renders it as an ::after pill. Text
     * nodes are never inserted, so a re-render cannot orphan or misplace a badge
     * (which is what pushed the pill above the menu before).
     */
    const installEffortBadges = () => {
      if (typeof document === 'undefined' || typeof MutationObserver === 'undefined') return () => {}
      let frame = 0

      const cell = (index) => '3px ' + (4.5 + index * 1.5) + 'px'

      // Everything the pill needs lives in stylesheet rules keyed by attributes.
      // Inline custom properties would be wiped whenever React rewrites a row's
      // style attribute, which left the text pill behind with no bars.
      const css = [
        '[' + BADGE_ATTR + ']::after {',
        '  content: attr(' + BADGE_ATTR + ');',
        '  margin-inline-start: auto;',
        '  margin-inline-end: 4px;',
        '  padding: 0 6px 0 30px;',
        '  height: 16px;',
        '  display: inline-flex;',
        '  align-items: center;',
        '  border-radius: 8px;',
        '  background-color: var(--dsw-alias-bg-layer-2);',
        '  background-image:',
        '    linear-gradient(var(--c1, transparent), var(--c1, transparent)),',
        '    linear-gradient(var(--c2, transparent), var(--c2, transparent)),',
        '    linear-gradient(var(--c3, transparent), var(--c3, transparent)),',
        '    linear-gradient(var(--c4, transparent), var(--c4, transparent)),',
        '    linear-gradient(var(--c5, transparent), var(--c5, transparent));',
        '  background-size: ' + [0, 1, 2, 3, 4].map(cell).join(', ') + ';',
        '  background-position: 4px calc(100% - 3px), 9px calc(100% - 3px), 14px calc(100% - 3px), 19px calc(100% - 3px), 24px calc(100% - 3px);',
        '  background-repeat: no-repeat;',
        '  color: var(--fill, var(--dsw-alias-label-secondary));',
        '  font-size: 10px;',
        '  line-height: 14px;',
        '  font-weight: 600;',
        '  font-variant-numeric: tabular-nums;',
        '  white-space: nowrap;',
        '  flex: none;',
        '  pointer-events: none;',
        '}',
        '[' + BADGE_ATTR + '] {',
        '  --empty: var(--dsw-alias-border-l2);',
        '  --c1: var(--empty); --c2: var(--empty); --c3: var(--empty);',
        '  --c4: var(--empty); --c5: var(--empty);',
        '}',
        '[' + LEVEL_ATTR + '="1"] { --c1: var(--fill); }',
        '[' + LEVEL_ATTR + '="2"] { --c1: var(--fill); --c2: var(--fill); }',
        '[' + LEVEL_ATTR + '="3"] { --c1: var(--fill); --c2: var(--fill); --c3: var(--fill); }',
        '[' + LEVEL_ATTR + '="4"] { --c1: var(--fill); --c2: var(--fill); --c3: var(--fill); --c4: var(--fill); }',
        '[' + LEVEL_ATTR + '="5"] { --c1: var(--fill); --c2: var(--fill); --c3: var(--fill); --c4: var(--fill); --c5: var(--fill); }',
        '[' + TONE_ATTR + '="low"] { --fill: var(--dsw-alias-state-success-primary); }',
        '[' + TONE_ATTR + '="mid"] { --fill: var(--dsw-alias-state-warn-primary); }',
        '[' + TONE_ATTR + '="high"] { --fill: var(--dsw-alias-state-error-primary); }',
      ].join('\n')

      if (!document.getElementById(STYLE_ID)) {
        const style = document.createElement('style')
        style.setAttribute('id', STYLE_ID)
        style.textContent = css
        const host = document.head || document.body
        if (host && host.appendChild) host.appendChild(style)
      }

      const strip = () => {
        for (const node of document.querySelectorAll('[' + BADGE_ATTR + ']')) {
          node.removeAttribute(BADGE_ATTR)
          node.removeAttribute(LEVEL_ATTR)
          node.removeAttribute(TONE_ATTR)
        }
      }

      const paint = (node, point, compact) => {
        if (!node || !point || !node.setAttribute) return
        const level = Math.max(1, Math.min(5, costLevel(point.c)))
        node.setAttribute(BADGE_ATTR, badgeText(point, compact))
        node.setAttribute(LEVEL_ATTR, String(level))
        node.setAttribute(TONE_ATTR, level <= 2 ? 'low' : level === 3 ? 'mid' : 'high')
      }

      const decorate = () => {
        frame = 0
        strip()
        const row = selection.row
        if (!row) return
        const points = new Map(row.pts.map((p) => [(p.e || 'default').toLowerCase(), p]))
        const menuSelector =
          '[role="menu"], [role="listbox"], [data-radix-popper-content-wrapper], [data-state="open"]'
        const norm = (value) =>
          String(value || '')
            .replace(/[\s\u2713\u2714]/g, '')
            .toLowerCase()
        const LABELS = Array.from(EFFORT_LABELS)

        // Option rows: a row whose whole text is one effort name. Summary rows
        // such as "Reasoning level … Max ›" are left alone on purpose.
        for (const root of document.querySelectorAll(menuSelector)) {
          const items = root.querySelectorAll('[role="menuitem"], [role="menuitemradio"], [role="option"]')
          for (const node of items) {
            const label = norm(node.textContent)
            const key = LABELS.find((value) => label === value)
            if (!key) continue
            paint(node, points.get(key), false)
          }
        }

        // Collapsed composer: the effort chip beside our own model label.
        for (const anchor of document.querySelectorAll('[data-dsh-mi-name]')) {
          let scope = anchor
          for (let depth = 0; depth < 6 && scope.parentElement; depth++) scope = scope.parentElement
          for (const node of scope.querySelectorAll('*')) {
            if (node === anchor || (node.contains && node.contains(anchor))) continue
            if (node.closest && node.closest(menuSelector)) continue
            const text = (node.textContent || '').trim()
            if (!text || text.length > 12) continue
            const key = LABELS.find((value) => text.toLowerCase() === value)
            if (!key) continue
            paint(node, points.get(key), false)
            break
          }
        }
      }

      const schedule = () => {
        if (frame) return
        frame = typeof requestAnimationFrame === 'function' ? requestAnimationFrame(decorate) : setTimeout(decorate, 16)
      }

      const observer = new MutationObserver(schedule)
      observer.observe(document.body, { childList: true, subtree: true, characterData: true })
      schedule()

      return () => {
        observer.disconnect()
        if (frame && typeof cancelAnimationFrame === 'function') cancelAnimationFrame(frame)
        strip()
      }
    }
    return {
      inject: ['slots', 'locale'],
      apply(ctx) {
        const disposeEn = ctx.locale.register('model-insights', 'en', {
          'badge.intelligence': 'Intelligence index',
          'badge.grade': 'Value grade (S = Pareto frontier, then A-D)',
          'panel.title': 'Reasoning grades',
          'panel.tabGrade': 'Grade',
          'panel.tabIq': 'Intelligence',
          'panel.tabCost': 'Cost',
          'panel.hint':
            'Grades are Pareto layers over every reasoning-effort point. A range means the model crosses grades as reasoning effort changes.',
          'panel.empty': 'Pick a model above to see its reasoning grades.',
        })
        ctx.effect(() => disposeEn)

        const disposeZh = ctx.locale.register('model-insights', 'zh', {
          'badge.intelligence': '智力指数',
          'badge.grade': '性价比等级（S = 帕累托前沿）',
          'panel.title': '推理档评分',
          'panel.tabGrade': '等级',
          'panel.tabIq': '智力',
          'panel.tabCost': '成本',
          'panel.hint': '等级按每个推理档的帕累托层计算。显示为区间说明该模型随推理强度变化会跨档。',
          'panel.empty': '先在上面选一个模型，这里显示它的推理档评分。',
        })
        ctx.effect(() => disposeZh)

        const t = ctx.locale.bind('model-insights')
        const badge = makeBadge(t)

        ctx.effect(() => installEffortBadges())

        ctx.effect(() =>
          ctx.slots.inject('conversation.input.model.label', () =>
            ctx.slots.register({ name: 'conversation.input.model.label' }, badge),
          ),
        )
      },
    }
  },
})
