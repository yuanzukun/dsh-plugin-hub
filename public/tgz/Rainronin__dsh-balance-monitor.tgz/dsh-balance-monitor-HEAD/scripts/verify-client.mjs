import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import vm from 'node:vm'
import { SlotCore } from '@deepseek-ai/dsh-client-ui-slots'

// 捕获 bundle 的注册与 apply 行为
let registration
let registered
const fetchCalls = []
const window = { __ModuleLoader__: { load(value) { registration = value } } }
let echoRpcId = true

const fakeBalance = {
  ok: true,
  isAvailable: true,
  infos: [{ currency: 'CNY', totalBalance: '1', grantedBalance: '0', toppedUpBalance: '1' }],
  fetchedAt: 1,
  staleMs: 0,
  pricing: {
    phase: 'offpeak',
    observedAt: 1,
    nextChangeAt: 2,
    peakRemainingMs: 0,
    effectiveAt: 0,
  },
  pollIntervalMs: 30_000,
}

const fakeSessionCost = {
  ok: true,
  sessionId: 's1',
  cost: '0.0123',
}

// 在 VM 中执行浏览器 bundle（注册壳自注册）；callBalance 用裸 fetch，故注入全局
vm.runInNewContext(readFileSync('lib/client.js', 'utf8'), {
  window,
  AbortSignal,
  crypto: { randomUUID: () => 'verify-rpc-id' },
  fetch: async (url, init) => {
    const body = JSON.parse(String(init.body))
    fetchCalls.push({ url: String(url), body })
    const value = body.method === 'balance/sessionCost' ? fakeSessionCost : fakeBalance
    return {
      ok: true,
      async json() {
        return {
          type: 'server-response',
          rpcId: echoRpcId ? body.rpcId : 'another-rpc-id',
          result: { ok: true, value },
        }
      },
    }
  },
})
assert.equal(registration?.id, JSON.parse(readFileSync('package.json', 'utf8')).name)

// 执行 factory，拿到模块导出
const api = registration.factory((id) => {
  if (id === 'react') return { useEffect() {}, useState() { return [null, () => {}] } }
  if (id === 'react/jsx-runtime') return { jsx() {}, jsxs() {} }
  throw new Error(`测试遇到未知依赖：${id}`)
})
assert.ok(typeof api.apply === 'function', '模块应导出 apply')

// 侧边栏可能晚于插件加载：真实注册核心会拒绝尚未声明的插槽。
const slots = new SlotCore()
let mountBadge
api.apply({
  slots: {
    inject(name, callback) {
      assert.equal(name, 'sidebar.footer.action')
      mountBadge = callback
      return () => {}
    },
    register(options, component) {
      const dispose = slots.register(options, component)
      registered = { options, component }
      return dispose
    },
  },
})
assert.equal(registered, undefined, '插槽未声明时不得提前注册徽章')
assert.equal(typeof mountBadge, 'function', '应通过官方 slots.inject 等待插槽')
const disposeSidebar = slots.register({
  name: 'root',
  children: { 'sidebar.footer.action': { kind: 'list', scope: 'root' } },
}, () => null)
const disposeBadge = mountBadge()
assert.equal(slots.entriesOfSlot('sidebar.footer.action').length, 1)

assert.equal(registered?.options?.name, 'sidebar.footer.action')
assert.equal(registered?.options?.id, 'balance-monitor')
assert.ok(typeof registered?.component === 'function')

// 调 inject 面的 get：应走官方 RPC 信封直调并解出 BalanceClientWire
const injected = registered.options.inject()
const wire = await injected.get()
assert.deepEqual(wire, fakeBalance)
assert.equal(fetchCalls.length, 1)
assert.equal(fetchCalls[0].url, '/api/balance/get')
assert.equal(fetchCalls[0].body.type, 'client-request')
assert.equal(fetchCalls[0].body.rpcId, 'verify-rpc-id')
assert.equal(fetchCalls[0].body.method, 'balance/get')
assert.deepEqual(fetchCalls[0].body.payload, { args: {} })

// sessionCost：按当前会话 id 走同一官方 RPC 信封
const cost = await injected.sessionCost('s1')
assert.deepEqual(cost, fakeSessionCost)
assert.equal(fetchCalls.length, 2)
assert.equal(fetchCalls[1].url, '/api/balance/sessionCost')
assert.equal(fetchCalls[1].body.method, 'balance/sessionCost')
assert.deepEqual(fetchCalls[1].body.payload, { args: { sessionId: 's1' } })

// rpcId 回显不一致必须拒绝，防止串包
echoRpcId = false
await assert.rejects(() => injected.get(), /rpcId/)
assert.equal(fetchCalls.length, 3)

disposeBadge()
assert.equal(slots.entriesOfSlot('sidebar.footer.action').length, 0, '注销时应移除徽章')
disposeSidebar()

console.log('客户端 bundle 注册、延迟 slot 挂载及注销、RPC 直调与 rpcId 回显校验验证通过')
