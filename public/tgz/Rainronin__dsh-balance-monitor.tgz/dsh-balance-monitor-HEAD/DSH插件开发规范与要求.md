# DSH 插件开发规范与要求

> 整理自以下三份官方/社区文档：
> 1. DSH Desktop 使用手册及基础答疑（飞书）：<https://icn52ewp31d4.feishu.cn/wiki/X8fHwEE2RinDEDkj1ngcA6w4nQw>
> 2. v2.0.1 报错解决方案（飞书）：<https://icn52ewp31d4.feishu.cn/wiki/YtESwBl2sipa24kqcsXcw37OnMf>
> 3. DSH 插件生态倡议书（GitHub）：<https://github.com/anywhere-labs/deepseek-harness-desktop/blob/master/docs/plugin-ecosystem.md>

---

## 一、插件生态核心原则（来自 plugin-ecosystem.md）

DSH 插件生态的目标是：**开放、可组合、可持续**。

### 三条基本原则

1. **组合优先**
   - 通过官方 slot、service 和 patch 组合能力；
   - 不要假设或覆盖其他插件的内部实现。

2. **声明清晰**
   - 明确声明依赖的 service 和 slot；
   - 不依赖运行时巧合。

3. **兼容优先**
   - 升级保持向后兼容；
   - 不破坏已有组合。

### 桌面壳的定位

- DSH Desktop 本身就是一个普通 DSH 插件；
- 与官方、第三方插件走同一条组合路径，没有任何特权；
- “桌面”也是插件生态里平等的一员。

### 插件市场与 Community Fabric

- 插件市场目标是让符合规范的插件更容易被发现、安装和信任；
- Community Fabric 正在把愿景整理成可讨论的 Manifest、Capability、Host Descriptor 与事件 Draft；
- 当前插件仍使用现有 DSH/Cordis 接口；
- 市场目前仍在产品与安全设计阶段，收录不代表安全审核或推荐。

---

## 二、DSH Desktop 使用与插件管理要求（来自基础答疑）

### 1. 手动安装插件

- 在系统托盘（Windows 右下角 / macOS 右上角）右键应用图标，打开**专用终端**；
- 使用命令：`dsh plugin add <name>`；
- 如果插件主页给的是 `dsh plugin --profile web <name>`，需要改为 `dsh plugin --profile desktop <name>` 才能装到桌面端。

### 2. web 与 desktop 的 profile 隔离

- DSH Desktop 隔离了 **web** 和 **desktop** 的 profile（配置文件）；
- **插件是分开安装的**，但**会话数据是一致的**；
- 因此：web 端能用的插件，desktop 端不一定能用；需要在对应 profile 分别安装。

### 3. 插件市场

- 选择 1024 源并使用，等待检索即可；
- 初次加载可能较慢；
- 因数据源服务器网络问题，部分地区可能加载不出来。

### 4. 日志与诊断

- 日志位置：系统托盘右键应用图标，选择“导出诊断信息”；
- 导出的诊断包包含日志、系统信息、启动事件等。

### 5. 插件兼容性要求

- 官方更新到新版（如 rc7）后，旧插件很可能不兼容；
- 不兼容的典型表现：
  - 更新后之前的插件用不了；
  - 打开后弹出错误页面，显示 `Failed to load plugins`；
  - 安装的插件显示各种错误。
- 处理方式：卸载不兼容插件。

---

## 三、插件问题解决方案（来自 v2.0.1 报错解决方案）

### 1. “Failed to load plugins” / 插件报错

**原因**：插件不兼容官方新版（rc7）。

**处理步骤**：

- **Mac**
  1. 在屏幕右上角右键图标打开专用终端；
  2. 输入删除插件的指令（实际不要带尖括号）；
  3. 重启客户端。

- **Windows**
  1. 在屏幕右下角系统托盘处右键应用图标打开专用终端；
  2. 输入删除插件的指令（实际不要带尖括号）；
  3. 重启客户端。

> 找不到图标？macOS 27 之前可能因打开程序太多导致图标找不到，请酌情关闭其他程序。

### 2. 触发了恢复页面，无法打开专用终端

- 如果恢复页面没有直接显示某个插件的报错，而是显示内置组件报错；
- 并且你本地有其他 agent（codex、claude code 等）；
- 可以尝试手动修复。

---

## 四、对 dsh-balance-monitor 项目的自查清单

作为自己开发的 DSH 插件，建议对照以下要求检查：

- [ ] 使用官方 slot / service / patch 组合能力，不覆盖其他插件内部实现；
- [ ] 在 `package.json` 中明确声明依赖的 service / slot / peerDependencies；
- [ ] `peerDependencies` 与当前 DSH 核心版本（如 rc7 / rc8 / alpha）匹配；
- [ ] 正确声明 `dsh.client.platform`（web / desktop 等）；
- [ ] 升级时保持向后兼容，不破坏已有组合；
- [ ] 提供清晰的安装命令（`--profile web` / `--profile desktop`）；
- [ ] 提供日志/诊断信息导出支持，便于排查问题。

---

*文档整理时间：2026-08-31*
