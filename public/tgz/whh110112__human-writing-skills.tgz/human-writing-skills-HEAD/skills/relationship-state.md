# Relationship State Skill

## Aim

Keep interpersonal writing from becoming flat, generic, or episodic. A scene should
track how trust, distance, leverage, knowledge, obligation, attraction, resentment,
and boundaries move between people.

## Use When

- scenes depend on couples, friends, rivals, families, teams, or witnesses
- dialogue is frequent but the relationship does not actually change
- characters forget what was confessed, withheld, promised, refused, or misunderstood
- intimacy, conflict, betrayal, reconciliation, or temptation feels summarized instead
  of dramatized

## Relationship Ledger

Before drafting or revising a scene, name the current state:

- Known facts: what each person knows, suspects, misreads, or refuses to ask.
- Public posture: how each person behaves where others can see or judge them.
- Private pressure: what each person wants but cannot say cleanly.
- Boundary or promise: what has been allowed, forbidden, delayed, owed, or broken.
- Leverage: who can end the moment, change the terms, expose a secret, or withdraw.
- Mention policy: whose names, alliances, scandals, favors, debts, or comparisons
  are safe, risky, forbidden, or useful in this audience.
- Residue: the last line, object, gesture, message, silence, or physical distance that
  should still affect the next beat.
- Interaction debt: which pressure-bearing line or action still awaits uptake, refusal,
  consequence, or a deliberately delayed answer.

## Techniques

- Let dialogue do relationship work. Each important line should shift permission,
  trust, distance, threat, debt, embarrassment, or knowledge.
- Close or deliberately carry each important response obligation. A reply may be
  verbal, physical, silent, interrupted, or delayed, but it cannot simply disappear.
- Use questions as pressure, not decoration. A question should force a choice: answer,
  evade, joke, lie, delay, or counterattack.
- Preserve asymmetry. One character may know more, want more, risk more, or recover
  faster than the other.
- Treat dialogue as a triangle, not only a pair. Every mention of an absent person
  should fit the speaker, listener, and referenced person's relationship graph.
- Track information permissions. A secret, affair, alliance, debt, betrayal, or
  faction tie should not become common knowledge unless the scene explicitly exposes it.
- Make social breaches legible. If a character praises an enemy, names a hidden lover,
  insults an ally, or reports on a rival, show whether it is strategy, panic, ignorance,
  provocation, bargaining, or a mistake.
- Track the aftertaste of consent, refusal, apology, exposure, praise, humiliation,
  or secrecy without replaying the whole event.
- Change scene through a relationship residue: an unread message, a changed nickname,
  a door left open, a withheld reply, a touch avoided, a promise repeated too calmly.
- Keep internal thought attached to observable behavior. The reader should see the
  relationship moving before the narrator explains it.
- Let small domestic or workplace actions reveal status: who waits, cleans, pays,
  checks the phone, chooses the route, lowers their voice, or stands near the exit.

## Avoid

- resetting trust or conflict after a charged scene
- making both characters understand the scene at the same speed
- using dialogue only to explain backstory or announce emotion
- turning every silence into a neat interpretation
- replacing boundary, consequence, or cost with vague intensity
- making jealousy, desire, shame, fear, or loyalty interchangeable
- letting a character mention the wrong rival, lover, superior, ally, or enemy as if
  all relationships were socially interchangeable
- leaking hidden relationships through casual exposition
- ignoring rank, titles, honorifics, taboos, and public/private posture in dialogue

## Revision Check

For every two-person or group scene, answer:

- What does each person know or believe at the start?
- Who is present, listening, or likely to hear?
- What does each person want the other person to do, admit, miss, or remember?
- Which absent person or group is safe, risky, or forbidden to mention here?
- Which boundary, promise, secret, or leverage point changes?
- Which important line or action receives uptake, and which interaction debt remains open?
- What visible detail proves the relationship is different at the end?

If the people leave the scene with the same trust, distance, knowledge, and leverage
they brought in, the scene needs a sharper turn or should be merged.
