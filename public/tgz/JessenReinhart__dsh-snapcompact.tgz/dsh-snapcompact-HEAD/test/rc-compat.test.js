// test/rc-compat.test.js
// Forward-compatibility tests for dsh-snapcompact against the DeepSeek Harness RC.
//
// Resolution strategy: the snapcompact package ships no installed node_modules, so
// the plugin's @deepseek-ai/* imports are resolved against the RC host's
// node_modules via a node:module resolve hook. The same mechanism lets these tests
// load the real @deepseek-ai/cordis@4 Context and js-yaml without installing deps.
//
// RC facts verified against the host checkout (see delegating-task report):
//   C:\Users\LGSM228\AppData\Local\Programs\DSH Desktop\resources\app\node_modules\@deepseek-ai
// - "attachments"   <- AttachmentStore.super(ctx, "attachments")     (dsh-attachment/lib/index.js:185),
//                      provided by dsh-attachment-local (id "attachment-local").
// - "sessions"      <- SessionStore.super(ctx, "sessions")           (dsh-session/lib/index.js:1315),
//                      provided by dsh-session (id "session").
// - "tokenMeter"    <- TokenMeter.super(ctx, "tokenMeter")           (dsh-token-meter/lib/index.js:613),
//                      provided by dsh-token-meter (id "token-meter").
// - "commands"      <- CommandRuntime.super(ctx, "commands")         (dsh-commands/lib/index.js:250),
//                      provided by dsh-commands (id "commands").
// The RC's own compaction backend (dsh-compaction-basic) injects only
//   ["llm", "tokenMeter", "sessions"]  (dsh-compaction-basic/lib/index.js:761-765);
// the /compact command is a separate plugin injecting ["commands", "compaction"]
//   (dsh-command-compact/lib/index.js:8).
// snapcompact mirrors that: inject only the truly-required core services
//   ["tokenMeter", "sessions"], and guards the optional "attachments" (throws at
//   compaction time) and "commands" (guarded at registration) at use time.

import test from "node:test";
import assert from "node:assert/strict";
import { registerHooks, createRequire } from "node:module";
import { readFileSync } from "node:fs";
import { pathToFileURL, fileURLToPath } from "node:url";
import { dirname, resolve as resolvePath } from "node:path";
import { runInNewContext } from "node:vm";

const HERE = dirname(fileURLToPath(import.meta.url));
const PKG_ROOT = resolvePath(HERE, "..");

// --- RC host resolution ------------------------------------------------------
const RC_HOST =
  process.env.SNAPCOMPACT_TEST_RC ||
  "C:\\Users\\LGSM228\\AppData\\Local\\Programs\\DSH Desktop\\resources\\app";
const rcRequire = createRequire(pathToFileURL(`${RC_HOST}\\package.json`).href);

registerHooks({
  resolve(specifier, context, next) {
    if (
      specifier.startsWith("node:") ||
      specifier.startsWith("file:") ||
      specifier.startsWith("data:") ||
      specifier.startsWith(".") ||
      specifier.startsWith("/")
    ) {
      return next(specifier, context);
    }
    try {
      const resolved = rcRequire.resolve(specifier);
      return { url: pathToFileURL(resolved).href, shortCircuit: true };
    } catch {
      return next(specifier, context);
    }
  },
});

// --- Load the real plugin and real cordis through the RC resolver ------------
const plugin = await import("../lib/index.js");
const { Context } = await import("@deepseek-ai/cordis");
const cordisJson = readFileSync(
  rcRequire.resolve("@deepseek-ai/cordis/package.json"),
  "utf8",
);
const cordisVersion = JSON.parse(cordisJson).version;

// --- Tests -------------------------------------------------------------------

test("harness: real @deepseek-ai/cordis loaded from the RC host", () => {
  assert.equal(typeof Context, "function", "Context must be a class");
  assert.match(cordisVersion, /^4\.\d+\.\d+$/, "a real Cordis 4.x build must be loaded");
});

test("module exports contract: name/inject/apply/engine + default mirror", () => {
  assert.equal(plugin.name, "snapcompact", "plugin name export");
  assert.equal(typeof plugin.apply, "function", "apply must be a function");
  assert.equal(typeof plugin.SnapcompactEngine, "function", "SnapcompactEngine must be a class");

  // The loader unwraps `exports.default ?? exports` (cordis-plugin-loader
  // lib/index.js unwrapExports), so the default object must carry the contract.
  assert.equal(typeof plugin.default.apply, "function");
  assert.equal(plugin.default.name, "snapcompact");
  assert.equal(typeof plugin.default.SnapcompactEngine, "function");
  assert.deepEqual(plugin.default.inject, plugin.inject, "default.inject mirrors named inject");
});

test("inject declares every ctx service the plugin dereferences", () => {
  // cordis-plugin-loader throws "cannot get property X without inject" the
  // moment apply() reads ctx.X, so each accessed service must be declared —
  // the guard `if (ctx.commands ...)` still reads the proxied property first.
  assert.deepEqual(plugin.inject, ["attachments", "sessions", "tokenMeter", "commands"]);
  for (const svc of ["attachments", "sessions", "tokenMeter", "commands"]) {
    assert.ok(plugin.inject.includes(svc), `${svc} must be in inject`);
  }
});

test("apply() with a real Cordis Context and no commands service does not throw", () => {
  const ctx = new Context();
  // No commands / tokenMeter / sessions / attachments services are provided.
  assert.doesNotThrow(() => plugin.apply(ctx));
  assert.equal(typeof ctx.get("compaction"), "object", "compaction service registered");
});

test("apply() tolerates the absence of a command registry (guard branch)", () => {
  const ctx = new Context();
  assert.equal(ctx.commands, undefined, "no commands service on a bare context");
  assert.doesNotThrow(() => plugin.apply(ctx));
});

// --- cordis.patch.yml --------------------------------------------------------

test("cordis.patch.yml parses and carries the compaction disable + insert rows", () => {
  const yaml = rcRequire("js-yaml");
  const raw = readFileSync(resolvePath(PKG_ROOT, "cordis.patch.yml"), "utf8");
  const doc = yaml.load(raw);
  assert.ok(Array.isArray(doc), "patch document is a list of rows");

  const disable = doc.find((row) => row && row.id === "compaction-basic");
  assert.ok(disable, "disables the compaction-basic backend");
  assert.equal(disable.disabled, true, "compaction-basic marked disabled");

  const inserted = doc.flatMap((row) => (row && row.insert ? row.insert : []));
  const snapRow = inserted.find((row) => row && row.id === "snapcompact");
  assert.ok(snapRow, "inserts the snapcompact plugin row");
  assert.equal(snapRow.name, "dsh-snapcompact", "inserted row resolves the snapcompact package");
});

// --- client entry ------------------------------------------------------------

test("client entry registers a no-op module under the RC ModuleLoader contract", () => {
  const source = readFileSync(resolvePath(PKG_ROOT, "lib", "client.js"), "utf8");
  const registrations = [];
  const window = {
    __ModuleLoader__: {
      load(registration) {
        registrations.push(registration);
      },
    },
  };

  runInNewContext(source, { window, Symbol, Object }, { filename: "lib/client.js" });

  assert.equal(registrations.length, 1, "exactly one client module registered");
  const [registration] = registrations;
  assert.equal(registration.id, "dsh-snapcompact", "loader id matches package");
  assert.equal(typeof registration.factory, "function", "factory is callable");

  const requested = [];
  const exports = registration.factory((specifier) => {
    requested.push(specifier);
    return {};
  });
  assert.deepEqual(requested, [], "no host module required (no-op stub)");
  // `exports` originates in a vm realm, so avoid deepStrictEqual across realms.
  assert.ok(Array.isArray(exports.inject), "client inject is an array");
  assert.equal(exports.inject.length, 0, "client inject empty");
  assert.equal(typeof exports.apply, "function", "client apply is a no-op-safe function");
});

// --- runtime & backwards compatibility ---------------------------------------

test("package.json engines.dsh and peerDependencies are compatible with 0.1.5-rc.2 up through latest 0.2.1-rc.2+", () => {
  const pkg = JSON.parse(readFileSync(resolvePath(PKG_ROOT, "package.json"), "utf8"));
  const semver = rcRequire("semver");

  assert.ok(pkg.engines?.dsh, "engines.dsh must be specified");
  assert.ok(pkg.peerDependencies, "peerDependencies must be present");

  const versionsToTest = ["0.1.5-rc.2", "0.2.0-rc.2", "0.2.1-rc.2", "0.2.2", "0.3.0"];
  for (const v of versionsToTest) {
    assert.ok(
      semver.satisfies(v, pkg.engines.dsh, { includePrerelease: true }),
      `engines.dsh (${pkg.engines.dsh}) must satisfy DSH version ${v}`
    );
    for (const [peer, range] of Object.entries(pkg.peerDependencies)) {
      if (peer.startsWith("@deepseek-ai/dsh-")) {
        assert.ok(
          semver.satisfies(v, range, { includePrerelease: true }),
          `peerDependency ${peer}: ${range} must satisfy DSH version ${v}`
        );
      }
    }
  }
});
