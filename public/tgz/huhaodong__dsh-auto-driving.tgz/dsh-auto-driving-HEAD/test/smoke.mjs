/**
 * dsh-model-fallback host-logic smoke test.
 *
 * Stubs the small cordis surface the plugin touches (ctx.on / logger / llm /
 * inject->settings / effect) and drives real scenarios through the registered
 * `llm/stream` listener: fallback on early failure, pass-through on
 * mid-stream failure, abort pass-through, disabled / not-selected passthrough,
 * and chain exhaustion.
 */
import { apply, Config, name, __clearHealthCache } from "../lib/index.js";
import { mkdirSync, readFileSync, rmSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";

const assert = (condition, message) => {
	if (!condition) {
		console.error(`FAIL: ${message}`);
		process.exitCode = 1;
	} else {
		console.log(`ok: ${message}`);
	}
};

//#region stubs
const log = [];
const logger = {
	warn: (...args) => log.push(["warn", args.join(" ")]),
	info: (...args) => log.push(["info", args.join(" ")]),
	error: (...args) => log.push(["error", args.join(" ")]),
};

/** Fake adapter boundary: every model streams one text delta then a stop finish. */
const healthyModels = new Set(["p1/m2", "p2/m1"]);
/** Models that fail with a terminal error before any content. */
const failingModels = new Map(); // "provider/model" -> failure chunk
const adapterStreamCalls = [];

const fakeLlm = {
	listModels: async (provider) => {
		if (provider === "p1") return [{ id: "m1", name: "M1" }, { id: "m2", name: "M2" }];
		if (provider === "p2") return [{ id: "m1", name: "M1" }];
		return [];
	},
	adapterStream(options) {
		adapterStreamCalls.push(`${options.provider}/${options.model}`);
		const key = `${options.provider}/${options.model}`;
		const failure = failingModels.get(key);
		const healthy = healthyModels.has(key);
		return (async function* () {
			if (failure) {
				yield failure;
				return;
			}
			if (!healthy) {
				yield { type: "finish", reason: { kind: "error", failure: { code: "UNKNOWN_MODEL", message: `no such model ${key}` } } };
				return;
			}
			yield { type: "text-delta", text: `hello from ${key}` };
			yield { type: "finish", reason: { kind: "stop", usage: {} } };
		})();
	},
};

const registered = new Map();
const resolved = new Map([["model-fallback", { enabled: true, providers: ["p1", "p2"] }]]);
const watchers = [];
/** Fake user-questions service: mirrors the real single-provider seam. */
const fakeUQ = {
	mail: null,
	registerProvider(provider) {
		this.provider = provider;
		return () => {
			this.provider = undefined;
		};
	},
};
const approvalListeners = [];
const approvalOptions = [];
const loopListeners = [];
const ctx = {
	fiber: { state: 0 },
	logger,
	llm: fakeLlm,
	listeners: new Map(),
	get(name) {
		return name === "userQuestions" ? fakeUQ : undefined;
	},
	on(eventName, listener, options) {
		if (eventName === "approval/request") {
			approvalListeners.push(listener);
			approvalOptions.push(options);
		}
		if (eventName === "agent/request-error") loopListeners.push(listener);
		if (!this.listeners.has(eventName)) this.listeners.set(eventName, []);
		this.listeners.get(eventName).push(listener);
		return () => {};
	},
	effect(factory) {
		return typeof factory?.() === "function" ? factory() : undefined;
	},
	inject(deps, callback) {
		callback(ctx);
	},
	settings: {
		register(namespace, schema, options) {
			registered.set(namespace, { schema, options });
			return {
				get: () => resolved.get(namespace),
				watch: (callback) => {
					watchers.push(callback);
					return () => {};
				},
			};
		},
		// Mirror dsh-settings' update(): deep-merge plain-object patches into the
		// stored section so runtime arrears writes accumulate instead of clobber.
		async update(namespace, patch) {
			console.log("UPDATE CALLED:", namespace, JSON.stringify(patch));
			const section = { ...(resolved.get(namespace) ?? {}) };
			for (const [key, value] of Object.entries(patch ?? {})) {
				if (value && typeof value === "object" && !Array.isArray(value) && section[key] && typeof section[key] === "object" && !Array.isArray(section[key])) {
					section[key] = { ...section[key], ...value };
				} else {
					section[key] = value;
				}
			}
			resolved.set(namespace, section);
		},
	},
};

const streamListener = (() => {
	let captured = null;
	const originalOn = ctx.on.bind(ctx);
	ctx.on = (eventName, listener, options) => {
		if (eventName === "llm/stream") captured = listener;
		return originalOn(eventName, listener, options);
	};
	return { get: () => captured };
})();

apply(ctx, { enabled: true, providers: ["p1", "p2"] });
//#endregion

/** Drain one async generator into an array. */
async function drain(stream) {
	const chunks = [];
	for await (const chunk of stream) chunks.push(chunk);
	return chunks;
}

/** Run one request through the registered listener. */
function request(options, downstream) {
	return streamListener.get()(options, () => downstream);
}

const failChunk = (code, message) => ({ type: "finish", reason: { kind: "error", failure: { code, message } } });

//#region scenarios
// Let the catalog warm-up scheduled by apply() settle.
await new Promise((resolve) => setTimeout(resolve, 20));
assert(log.some(([, line]) => line.includes("loop-level retry listener armed")), "loop-retry armed line present at apply");

{
	// 1. protectUnselected (default on): an unselected provider's failing model
	//    cycles into the selected groups and recovers.
	const seen = [];
	const chunks = await drain(
		request({ provider: "other", model: "m1" }, (async function* () {
			seen.push("downstream");
			yield failChunk("UNKNOWN_MODEL", "nope");
		})()),
	);
	assert(seen.length === 1, "unselected provider reaches downstream exactly once");
	assert(chunks.some((chunk) => chunk.type === "text-delta" && chunk.text === "hello from p1/m2"), "unselected provider recovers through the selected groups (protectUnselected on)");
	assert(log.some(([, line]) => line.includes("engaged for other/m1")), "engagement decision logged for the unselected provider");
}

{
	// 1b. protectUnselected off: unselected providers pass through untouched.
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], protectUnselected: false });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	const seen = [];
	const chunks = await drain(
		request({ provider: "other", model: "m1" }, (async function* () {
			seen.push("downstream");
			yield failChunk("UNKNOWN_MODEL", "nope");
		})()),
	);
	assert(seen.length === 1 && chunks.length === 1 && chunks[0].reason.kind === "error", "protectUnselected off: unselected provider passes through");
	assert(log.some(([, line]) => line.includes("not engaged for other")), "skip decision logged when protection is off");
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"] });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
}

{
	// 2. fallback: p1/m1 fails early -> adapterStream retry on p1/m2 -> success.
	const downstreamCalls = [];
	const chunks = await drain(
		request({ provider: "p1", model: "m1" }, (async function* () {
			downstreamCalls.push(1);
			yield failChunk("UNKNOWN_MODEL", `unknown model p1/m1`);
		})()),
	);
	assert(downstreamCalls.length === 1, "downstream chain invoked once for attempt 0");
	assert(adapterStreamCalls.includes("p1/m2"), `retry dispatched to adapter boundary (${adapterStreamCalls.join(", ")})`);
	assert(chunks.some((chunk) => chunk.type === "text-delta" && chunk.text === "hello from p1/m2"), "fallback stream content reaches the consumer");
	assert(chunks.at(-1).reason.kind === "stop", "fallback stream ends with a stop finish");
	assert(log.some(([, line]) => line.includes("switching to p1/m2")), "switch logged");
}

{
	// 3. mid-stream failure does NOT switch: content was already produced.
	const chunks = await drain(
		request({ provider: "p1", model: "m2" }, (async function* () {
			yield { type: "text-delta", text: "partial" };
			yield failChunk("CONNECTION_CLOSED", "dropped mid-stream");
		})()),
	);
	assert(chunks.length === 2 && chunks.at(-1).reason.kind === "error", "mid-stream failure surfaces untouched");
	assert(adapterStreamCalls.filter((call) => call === "p2/m1").length === 0, "no adapter retry after visible content");
}

{
	// 4. aborted finish passes through without switching.
	const chunks = await drain(
		request({ provider: "p1", model: "m1" }, (async function* () {
			yield { type: "finish", reason: { kind: "aborted", failure: { code: "ABORTED", message: "user aborted" } } };
		})()),
	);
	assert(chunks.length === 1 && chunks[0].reason.kind === "aborted", "aborted finish passes through");
}

{
	// 5. cross-provider loop: every p1 model fails -> p2/m1 succeeds.
	failingModels.set("p1/m2", failChunk("QUOTA", "insufficient balance"));
	adapterStreamCalls.length = 0;
	const chunks = await drain(
		request({ provider: "p1", model: "m1" }, (async function* () {
			yield failChunk("UNKNOWN_MODEL", "unknown model p1/m1");
		})()),
	);
	assert(adapterStreamCalls.includes("p1/m2") && adapterStreamCalls.includes("p2/m1"), `full loop traverses both providers (${adapterStreamCalls.join(", ")})`);
	assert(chunks.at(-1).reason.kind === "stop", "cross-provider recovery ends with a stop finish");
}

{
	// 6. chain exhaustion returns the last failure.
	healthyModels.clear();
	adapterStreamCalls.length = 0;
	const chunks = await drain(
		request({ provider: "p1", model: "m1" }, (async function* () {
			yield failChunk("UNKNOWN_MODEL", "unknown model p1/m1");
		})()),
	);
	assert(chunks.length === 1 && chunks[0].reason.kind === "error", "terminal error after exhausting every candidate");
	assert(log.some(([, line]) => line.includes("exhausted")), "exhaustion logged");
	healthyModels.add("p1/m2");
	healthyModels.add("p2/m1");
}

{
	// 7. disabled via settings -> passthrough.
	resolved.set("model-fallback", { enabled: false, providers: ["p1", "p2"] });
	for (const watcher of watchers) watcher();
	const seen = [];
	await drain(
		request({ provider: "p1", model: "m1" }, (async function* () {
			seen.push(1);
			yield failChunk("UNKNOWN_MODEL", "nope");
		})()),
	);
	assert(seen.length === 1, "disabled plugin passes through");
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"] });
}

{
	// 8. settings schema basics: defaults apply.
	const section = registered.get("model-fallback");
	const value = section.schema({});
	assert(value.enabled === true && Array.isArray(value.providers) && value.providers.length === 0, "schema defaults resolve enabled=true, providers=[]");
}

	{
		// 9. task retry: chain exhausted with non-model error -> retry original model -> success.
		failingModels.clear();
		healthyModels.clear();
		adapterStreamCalls.length = 0;
		log.length = 0;
		// All chain candidates fail with NETWORK_ERROR initially.
		failingModels.set("p1/m1", failChunk("NETWORK_ERROR", "connection reset"));
		failingModels.set("p1/m2", failChunk("NETWORK_ERROR", "connection reset"));
		failingModels.set("p2/m1", failChunk("NETWORK_ERROR", "connection reset"));
		let callCount = 0;
		const origAdapterStream = fakeLlm.adapterStream;
		fakeLlm.adapterStream = function(options) {
			callCount++;
			const key = `${options.provider}/${options.model}`;
			if (key === "p1/m1" && callCount <= 2) {
				return (async function* () {
					yield failChunk("NETWORK_ERROR", "connection reset");
				})();
			}
			if (key === "p1/m1" && callCount > 2) {
				return (async function* () {
					yield { type: "text-delta", text: "hello from p1/m1" };
					yield { type: "finish", reason: { kind: "stop", usage: {} } };
				})();
			}
			return origAdapterStream.call(fakeLlm, options);
		};
		resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], retry: { enabled: true, maxRetries: 3, baseDelayMs: 10 } });
		for (const watcher of watchers) watcher();
		await new Promise((r) => setTimeout(r, 20));
		const chunks = await drain(
			request({ provider: "p1", model: "m1" }, (async function* () {
				yield failChunk("NETWORK_ERROR", "downstream network error");
			})()),
		);
		assert(chunks.some((c) => c.type === "text-delta" && c.text === "hello from p1/m1"), "retry same model recovers on NETWORK_ERROR");
		assert(log.some(([, line]) => line.includes("non-model error, retry")), "retry logged");
		fakeLlm.adapterStream = origAdapterStream;
		healthyModels.add("p1/m2");
		healthyModels.add("p2/m1");
	}

	{
		// 10. task retry disabled -> chain exhaustion returns error immediately.
		failingModels.clear();
		healthyModels.clear();
		adapterStreamCalls.length = 0;
		resolved.set("model-fallback", { enabled: true, providers: ["p1"], retry: { enabled: false, maxRetries: 3 } });
		for (const watcher of watchers) watcher();
		await new Promise((r) => setTimeout(r, 20));
		const chunks = await drain(
			request({ provider: "p1", model: "m1" }, (async function* () {
				yield failChunk("NETWORK_ERROR", "downstream network error");
			})()),
		);
		assert(chunks.length === 1 && chunks[0].reason.kind === "error", "retry disabled skips same-model retry");
		assert(adapterStreamCalls.filter((c) => c === "p1/m1").length <= 1, "no adapter retry when disabled");
		resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], retry: { enabled: true, maxRetries: 3, baseDelayMs: 500 } });
	}

	{
		// 11. model error is NOT retried (UNKNOWN_MODEL is a model error).
		failingModels.clear();
		healthyModels.clear();
		adapterStreamCalls.length = 0;
		log.length = 0;
		const chunks = await drain(
			request({ provider: "p1", model: "m1" }, (async function* () {
				yield failChunk("UNKNOWN_MODEL", "unknown model");
			})()),
		);
		assert(chunks.length === 1 && chunks[0].reason.kind === "error", "model error not retried");
		assert(!log.some(([, line]) => line.includes("non-model error, retry")), "model error does not trigger retry log");
		healthyModels.add("p1/m2");
		healthyModels.add("p2/m1");
	}

	{
		// 12. abort is never retried even with retry enabled.
		const chunks = await drain(
			request({ provider: "p1", model: "m1" }, (async function* () {
				yield { type: "finish", reason: { kind: "aborted", failure: { code: "ABORTED", message: "user aborted" } } };
			})()),
		);
		assert(chunks.length === 1 && chunks[0].reason.kind === "aborted", "abort is never retried");
	}

	{
		// 13. schema defaults include retry config.
		const section = registered.get("model-fallback");
		const value = section.schema({});
		assert(value.enabled === true, "schema defaults enabled=true");
		assert(Array.isArray(value.providers) && value.providers.length === 0, "schema defaults providers=[]");
		assert(value.retry && typeof value.retry.enabled === "boolean", "schema defaults retry.enabled");
		assert(typeof value.retry.maxRetries === "number" && value.retry.maxRetries === 3, "schema defaults retry.maxRetries=3");
		assert(typeof value.retry.baseDelayMs === "number" && value.retry.baseDelayMs === 500, "schema defaults retry.baseDelayMs=500");
		assert(Array.isArray(value.retry.retryableCodes), "schema defaults retry.retryableCodes is array");
	}

	{
	// 14. full-auto: disabled by default -> approval waterfall passes through.
	assert(approvalListeners.length === 1, "approval/request listener registered");
	let nextCalled = 0;
	const passThrough = approvalListeners[0]({ toolName: "bash", reason: "escalation" }, () => {
		nextCalled++;
		return "unavailable";
	});
	assert(nextCalled === 1 && passThrough === "unavailable", "auto mode off: approval passes to later answerers");
}

{
	// 15. full-auto: enabled -> allowed-once + workspace audit file written.
	const { mkdtempSync, writeFileSync, existsSync, readFileSync } = await import("node:fs");
	const { tmpdir } = await import("node:os");
	const { join } = await import("node:path");
	const root = mkdtempSync(join(tmpdir(), "dsh-auto-"));
	resolved.set("model-fallback-auto", { enabled: true, autoAllowPermissions: true, autoAnswerQuestions: true, autoApprovePlans: true, workspaceLog: true });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	const outcome = approvalListeners[0](
		{ agent: { session: { header: { cwd: root } } }, toolName: "bash", reason: "sandbox escalation to danger-full-access" },
		() => "unavailable",
	);
	assert(outcome === "allowed-once", "auto mode on: permission auto-allowed");
	const auditFile = join(root, "AUTO-MODE.md");
	await new Promise((r) => setTimeout(r, 60));
	assert(existsSync(auditFile), "workspace audit file created");
	const audit = readFileSync(auditFile, "utf8");
	assert(audit.includes("全自动模式操作审计"), "audit file carries the banner");
	assert(audit.includes("bash"), "audit entry names the approved tool");
	// disabled again -> passthrough
	resolved.set("model-fallback-auto", { enabled: false });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	let nextCalled2 = 0;
	const outcome2 = approvalListeners[0]({ toolName: "bash" }, () => {
		nextCalled2++;
		return "unavailable";
	});
	assert(nextCalled2 === 1 && outcome2 === "unavailable", "auto mode off again: passthrough restored");
}

{
	// 16. full-auto: user-question provider wrap answers defaults.
	assert(typeof fakeUQ.registerProvider === "function", "user-questions provider wrap armed");
	let realAsked = 0;
	const realProvider = {
		ask: async () => {
			realAsked++;
			return { answers: [{ id: "real", selected: ["REAL"], custom: undefined }] };
		},
	};
	fakeUQ.registerProvider(realProvider);
	const provider = fakeUQ.provider;
	assert(typeof provider?.ask === "function", "provider registration wrapped");
	// 16a. plan review with intent -> approve label, real provider untouched.
	const planReq = {
		questions: [{
			id: "plan-review",
			question: "Approve this plan and leave plan mode?",
			options: [{ label: "Approve (Recommended)" }, { label: "Keep planning" }],
			intent: { kind: "plan-review", approve: "Approve (Recommended)" },
		}],
	};
	resolved.set("model-fallback-auto", { enabled: true, autoAnswerQuestions: true, autoApprovePlans: true });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	const planAnswer = await provider.ask(planReq);
	assert(realAsked === 0, "plan review did not reach the real provider");
	assert(planAnswer.answers[0].id === "plan-review" && planAnswer.answers[0].selected[0] === "Approve (Recommended)", "plan review auto-approved with the intent label");
	// 16b. plain question without intent -> first option.
	const plainAnswer = await provider.ask({
		questions: [{ id: "choice", question: "Pick one", options: [{ label: "First" }, { label: "Second" }] }],
	});
	assert(plainAnswer.answers[0].selected[0] === "First", "confirmation question auto-answered with the first option");
	// 16c. free-text question -> empty selection with the auto custom text.
	const freeAnswer = await provider.ask({ questions: [{ id: "text", question: "Type something" }] });
	assert(freeAnswer.answers[0].selected.length === 0 && typeof freeAnswer.answers[0].custom === "string", "free-text question auto-answered with the fallback custom text");
	// 16d. plan gated off -> delegates to the real provider.
	resolved.set("model-fallback-auto", { enabled: true, autoApprovePlans: false });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	await provider.ask(planReq);
	assert(realAsked === 1, "plan gate off: review delegated to the real provider");
	// 16e. master off -> everything delegates.
	resolved.set("model-fallback-auto", { enabled: false });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	await provider.ask({ questions: [{ id: "choice", question: "Pick one", options: [{ label: "First" }] }] });
	assert(realAsked === 2, "master off: all questions delegate to the real provider");
}

{
	// 17. auto settings namespace registered with its own schema defaults.
	const section = registered.get("model-fallback-auto");
	assert(section !== undefined, "auto settings namespace registered");
	const value = section.schema({});
	assert(value.enabled === false, "auto defaults enabled=false (opt-in)");
	assert(value.autoAllowPermissions === true && value.autoAnswerQuestions === true && value.autoApprovePlans === true && value.workspaceLog === true, "auto sub-toggles default on");
}

{
	// 18. loop-level request recovery on agent/request-error.
	assert(loopListeners.length === 1, "agent/request-error listener registered");
	const session = { events: [], append(type, data) { this.events.push({ type, data }); } };
	const payload = (overrides = {}) => ({
		agent: { session },
		turn: 1,
		step: 1,
		provider: "p1",
		failure: { code: "NETWORK_ERROR", message: "connection reset" },
		...overrides,
	});
	const failNext = async () => undefined;

	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], retry: { enabled: true, loopRetry: true, maxRetries: 2, baseDelayMs: 5, retryableCodes: ["NETWORK_ERROR"] } });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));

	let nextCalls = 0;
	const first = await loopListeners[0](payload(), async () => {
		nextCalls++;
		return undefined;
	});
	assert(nextCalls === 1, "loop recovery consults the native chain first");
	assert(first && first.kind === "retry", "loop recovery returns retry for a retryable failure");
	const retryEvent = session.events.find((event) => event.type === "llm/retry");
	assert(retryEvent && retryEvent.data.retry === 1 && retryEvent.data.provider === "p1", "retry bookkeeping appended to the session");
	assert(session.events.some((event) => event.type === "llm/retry-started"), "retry-started appended after the backoff");

	await loopListeners[0](payload(), failNext);
	assert(session.events.filter((event) => event.type === "llm/retry").length === 2, "second failure schedules retry 2");

	const capped = await loopListeners[0](payload(), failNext);
	assert(capped === undefined && !session.events.some((event) => event.type === "llm/retry" && event.data.retry === 3), "maxRetries cap stops further loop retries");

	const model = await loopListeners[0](payload({ failure: { code: "UNKNOWN_MODEL", message: "no such model" } }), failNext);
	assert(model === undefined, "model errors are not loop-retried");

	const aborted = await loopListeners[0](payload({ failure: { code: "ABORTED", message: "user aborted" } }), failNext);
	assert(aborted === undefined, "aborted failures are never loop-retried");

	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], retry: { enabled: true, loopRetry: false, maxRetries: 2, baseDelayMs: 5 } });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	const off = await loopListeners[0](payload(), failNext);
	assert(off === undefined, "loopRetry off: failures pass through to the native chain");

	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], retry: { enabled: true, loopRetry: true, maxRetries: 2, baseDelayMs: 5 } });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	const nativeOutcome = await loopListeners[0](payload(), async () => ({ kind: "retry" }));
	assert(nativeOutcome && nativeOutcome.kind === "retry", "native retry decisions pass through untouched");
}

{
	// 19. empty catalog no longer disarms the wrapper: single-candidate chain
	//     still engages and the request-level retry runs on the same model.
	failingModels.clear();
	healthyModels.clear();
	adapterStreamCalls.length = 0;
	failingModels.set("empty/m1", failChunk("NETWORK_ERROR", "connection reset"));
	let recover = false;
	const origAdapterStream = fakeLlm.adapterStream;
	fakeLlm.adapterStream = function(options) {
		const key = `${options.provider}/${options.model}`;
		if (key === "empty/m1") {
			if (!recover) {
				recover = true;
				return (async function* () {
					yield { type: "text-delta", text: "recovered on retry" };
					yield { type: "finish", reason: { kind: "stop", usage: {} } };
				})();
			}
		}
		return origAdapterStream.call(fakeLlm, options);
	};
	resolved.set("model-fallback", { enabled: true, providers: ["empty"], retry: { enabled: true, maxRetries: 3, baseDelayMs: 5 } });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 30));
	const chunks = await drain(
		request({ provider: "empty", model: "m1" }, (async function* () {
			yield failChunk("NETWORK_ERROR", "downstream failed");
		})()),
	);
	assert(chunks.some((chunk) => chunk.type === "text-delta" && chunk.text === "recovered on retry"), "empty catalog still wraps: same-model retry recovers");
	assert(log.some(([, line]) => line.includes("engaged for empty/m1, chain=1")), "single-candidate chain engagement logged");
	fakeLlm.adapterStream = origAdapterStream;
	healthyModels.add("p1/m2");
	healthyModels.add("p2/m1");
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"] });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
}

{
	// 21. a throwing listModels does not lock the catalog for the full TTL:
	//     the errored entry re-attempts after the short error TTL.
	let boomCalls = 0;
	const origListModels = fakeLlm.listModels;
	fakeLlm.listModels = async (provider) => {
		if (provider === "boom") {
			boomCalls += 1;
			throw new Error("catalog unavailable");
		}
		return origListModels(provider);
	};
	resolved.set("model-fallback", { enabled: true, providers: ["boom", "p1"] });
	for (const watcher of watchers) watcher();
	// First engagement triggers refresh attempt #1.
	await drain(
		request({ provider: "boom", model: "m1" }, (async function* () {
			yield failChunk("UNKNOWN_MODEL", "nope");
		})()),
	);
	await new Promise((r) => setTimeout(r, 20));
	assert(boomCalls === 1, "throwing catalog attempted once");
	// The errored entry must not block the wrapper: the chain still forms from p1.
	healthyModels.clear();
	healthyModels.add("p1/m1");
	const chunks = await drain(
		request({ provider: "boom", model: "m1" }, (async function* () {
			yield failChunk("UNKNOWN_MODEL", "nope");
		})()),
	);
	assert(chunks.some((chunk) => chunk.type === "text-delta" && chunk.text === "hello from p1/m1"), "errored catalog does not disarm the wrapper: p1 candidates still serve");
	fakeLlm.listModels = origListModels;
	healthyModels.clear();
	healthyModels.add("p1/m2");
	healthyModels.add("p2/m1");
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"] });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
}

{
	// 22. arrears setting: an account marked in arrears is excluded from the
	//     fallback pool (but the originally requested model still leads).
	__clearHealthCache();
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], arrears: { p1: true } });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	failingModels.clear();
	healthyModels.clear();
	healthyModels.add("p2/m1");
	adapterStreamCalls.length = 0;
	const chunks = await drain(
		request({ provider: "p1", model: "m1" }, (async function* () {
			yield failChunk("UNKNOWN_MODEL", "unknown model p1/m1");
		})()),
	);
	assert(chunks.some((chunk) => chunk.type === "text-delta" && chunk.text === "hello from p2/m1"), "arrears: p1 account skipped, recovery uses p2");
	assert(!adapterStreamCalls.includes("p1/m2"), "arrears: p1/m2 not dispatched because the p1 account is in arrears");
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"] });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
}

{
	// 22b. a wallet-level failure (QUOTA/402) auto-marks the account in arrears
	//      and persists the marker through the settings service.
	__clearHealthCache();
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"] });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	failingModels.clear();
	healthyModels.clear();
	healthyModels.add("p2/m1");
	adapterStreamCalls.length = 0;
	const chunks = await drain(
		request({ provider: "p1", model: "m1" }, (async function* () {
			yield failChunk("QUOTA", "insufficient balance");
		})()),
	);
	assert(chunks.some((chunk) => chunk.type === "text-delta" && chunk.text === "hello from p2/m1"), "arrears auto-mark: recovery still lands on p2/m1");
	assert(!adapterStreamCalls.includes("p1/m2"), "arrears auto-mark: p1/m2 skipped after the wallet failure");
	// The arrears write is a fire-and-forget settings.update promise; poll
	// instead of sleeping a fixed 20 ms so the assertion cannot race it.
	let stored = resolved.get("model-fallback");
	for (let i = 0; i < 50 && stored?.arrears?.p1 !== true; i += 1) {
		await new Promise((r) => setTimeout(r, 20));
		stored = resolved.get("model-fallback");
	}
	assert(stored?.arrears?.p1 === true, "arrears auto-mark: the account marker persisted through settings.update");
}

{
	// 23. providerModels allow-list: only the selected model ids participate.
	__clearHealthCache();
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], providerModels: { p1: ["m2"] } });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	failingModels.clear();
	healthyModels.clear();
	healthyModels.add("p1/m2");
	adapterStreamCalls.length = 0;
	const chunks = await drain(
		request({ provider: "p1", model: "m1" }, (async function* () {
			yield failChunk("UNKNOWN_MODEL", "unknown model p1/m1");
		})()),
	);
	assert(adapterStreamCalls.includes("p1/m2"), "providerModels: p1/m2 is allowed as fallback");
	assert(chunks.some((chunk) => chunk.type === "text-delta" && chunk.text === "hello from p1/m2"), "providerModels: recovery lands on selected p1/m2");
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"] });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
}

{
	// 23b. providerModels exclusion: an UNCHECKED model is skipped even when
	//      it is healthy — unchecked models never serve as fallback candidates.
	__clearHealthCache();
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], providerModels: { p1: [] } });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	failingModels.clear();
	healthyModels.clear();
	healthyModels.add("p1/m2");
	healthyModels.add("p2/m1");
	adapterStreamCalls.length = 0;
	const chunks = await drain(
		request({ provider: "p1", model: "m1" }, (async function* () {
			yield failChunk("UNKNOWN_MODEL", "unknown model p1/m1");
		})()),
	);
	assert(!adapterStreamCalls.includes("p1/m2"), "providerModels exclusion: healthy but unchecked p1/m2 never dispatched");
	assert(chunks.some((chunk) => chunk.type === "text-delta" && chunk.text === "hello from p2/m1"), "providerModels exclusion: recovery falls through to p2/m1");
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"] });
	healthyModels.add("p1/m2");
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
}

{
	// 23c. same-model retry survives the re-check when only the MESSAGE makes
	//      the failure transient (catch-all code outside the explicit list,
	//      Chinese gateway text): the pre-fix re-check dropped the message and
	//      gave up after retry 1.
	__clearHealthCache();
	failingModels.clear();
	healthyModels.clear();
	adapterStreamCalls.length = 0;
	log.length = 0;
	const origListModels23c = fakeLlm.listModels;
	fakeLlm.listModels = async (provider) => (provider === "solo" ? [{ id: "m1", name: "M1" }] : origListModels23c(provider));
	let soloCalls = 0;
	const origAdapterStream23c = fakeLlm.adapterStream;
	fakeLlm.adapterStream = function (options) {
		if (`${options.provider}/${options.model}` === "solo/m1") {
			soloCalls += 1;
			if (soloCalls <= 2) {
				return (async function* () {
					yield failChunk("GATEWAY", "模型服务暂时不可用，请稍后重试");
				})();
			}
			return (async function* () {
				yield { type: "text-delta", text: "gateway recovered" };
				yield { type: "finish", reason: { kind: "stop", usage: {} } };
			})();
		}
		return origAdapterStream23c.call(fakeLlm, options);
	};
	resolved.set("model-fallback", { enabled: true, providers: ["solo"], retry: { enabled: true, maxRetries: 3, baseDelayMs: 5 } });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 30));
	const chunks23c = await drain(
		request({ provider: "solo", model: "m1" }, (async function* () {
			yield failChunk("GATEWAY", "模型服务暂时不可用，请稍后重试");
		})()),
	);
	assert(chunks23c.some((c) => c.type === "text-delta" && c.text === "gateway recovered"), "message-only transient (Chinese text, catch-all code) recovers across same-model retries");
	assert(soloCalls === 3, `retry re-check kept going until success (${soloCalls} dispatches)`);
	assert(!log.some(([, line]) => line.includes("giving up")), "no premature give-up on the re-check");
	fakeLlm.listModels = origListModels23c;
	fakeLlm.adapterStream = origAdapterStream23c;
	healthyModels.add("p1/m2");
	healthyModels.add("p2/m1");
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"] });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
}

{
	// 23d. a wallet failure surfacing on retry 1 stops the same-model retry and
	//      marks the account in arrears instead of burning the remaining budget.
	__clearHealthCache();
	failingModels.clear();
	healthyModels.clear();
	adapterStreamCalls.length = 0;
	log.length = 0;
	const origListModels23d = fakeLlm.listModels;
	fakeLlm.listModels = async (provider) => (provider === "solo" ? [{ id: "m1", name: "M1" }] : origListModels23d(provider));
	let soloCalls23d = 0;
	const origAdapterStream23d = fakeLlm.adapterStream;
	fakeLlm.adapterStream = function (options) {
		if (`${options.provider}/${options.model}` === "solo/m1") {
			soloCalls23d += 1;
			if (soloCalls23d === 1) {
				return (async function* () {
					yield failChunk("GATEWAY", "模型服务暂时不可用，请稍后重试");
				})();
			}
			return (async function* () {
				yield failChunk("PI_AI_ERROR", "402 status code (no body)");
			})();
		}
		return origAdapterStream23d.call(fakeLlm, options);
	};
	resolved.set("model-fallback", { enabled: true, providers: ["solo"], retry: { enabled: true, maxRetries: 3, baseDelayMs: 5 } });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 30));
	const chunks23d = await drain(
		request({ provider: "solo", model: "m1" }, (async function* () {
			yield failChunk("GATEWAY", "模型服务暂时不可用，请稍后重试");
		})()),
	);
	assert(chunks23d.length === 1 && chunks23d[0].reason.kind === "error", "wallet failure on retry terminates the same-model loop");
	assert(soloCalls23d === 2, `no retry after an account-level failure (${soloCalls23d} dispatches)`);
	let stored23d = resolved.get("model-fallback");
	for (let i = 0; i < 50 && stored23d?.arrears?.solo !== true; i += 1) {
		await new Promise((r) => setTimeout(r, 20));
		stored23d = resolved.get("model-fallback");
	}
	assert(stored23d?.arrears?.solo === true, "mid-retry wallet failure persists the arrears marker");
	fakeLlm.listModels = origListModels23d;
	fakeLlm.adapterStream = origAdapterStream23d;
	healthyModels.add("p1/m2");
	healthyModels.add("p2/m1");
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"] });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
}

{
	// 23e. turn keep-alive: a turn that died to a transient model-service
	//      failure gets a 「继续」 user message injected into the conversation.
	__clearHealthCache();
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], retry: { enabled: true, maxRetries: 1, baseDelayMs: 5, keepAlive: { enabled: true, delayMs: 10, maxDelayMs: 20 } } });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	const errorListeners = ctx.listeners.get("agent/error") ?? [];
	assert(errorListeners.length >= 1, "agent/error listener registered for keep-alive");
	const sessionEventListeners = ctx.listeners.get("session/event") ?? [];
	assert(sessionEventListeners.length >= 1, "session/event listener registered for streak reset");
	const kaListener = errorListeners.at(-1);
	const resetListener = sessionEventListeners.at(-1);
	const followups = [];
	const agent = {
		id: "agent-ka-1",
		status: "idle",
		inbox: { hasPending: false, nextTurn: [], nextStep: [] },
		followup(message) {
			followups.push(message);
		},
	};
	const deadTurnError = () => Object.assign(new Error("模型服务暂时不可用，请稍后重试"), { failure: { code: "PI_AI_ERROR", message: "模型服务暂时不可用，请稍后重试" } });
	kaListener({ agent, error: deadTurnError() });
	assert(followups.length === 0, "keep-alive waits out the backoff delay before injecting");
	await new Promise((r) => setTimeout(r, 60));
	assert(followups.length === 1, "keep-alive injects 继续 after the delay");
	assert(followups[0]?.content?.[0]?.text === "继续", "injected message says 继续");
	assert(followups[0]?.role === "user" && followups[0]?.source?.plugin === "model-fallback", "injected message is a plugin-sourced user message");
	assert(log.some(([, line]) => line.includes("auto-keepalive") && line.includes("sent 「继续」")), "keep-alive injection logged");

	// Backoff: the next failure doubles the delay; a completed turn resets the
	// streak and disarms the pending timer.
	kaListener({ agent, error: deadTurnError() });
	await new Promise((r) => setTimeout(r, 5));
	resetListener({ id: agent.id }, { type: "turn/end", data: { reason: { kind: "completed" } } });
	await new Promise((r) => setTimeout(r, 60));
	assert(followups.length === 1, "a completed turn resets the streak and cancels the pending keep-alive");
	kaListener({ agent, error: deadTurnError() });
	await new Promise((r) => setTimeout(r, 60));
	assert(followups.length === 2, "post-reset failure re-arms the keep-alive at the base delay");
}

{
	// 23f. keep-alive stop conditions: aborts, wallet failures, deterministic
	//      model errors, all-arrears pools, disabled toggles, and busy agents
	//      never receive a 继续.
	const mkAgent = (id, overrides = {}) => ({
		id,
		status: "idle",
		inbox: { hasPending: false, nextTurn: [], nextStep: [] },
		followup() {
			throw new Error("followup must not be called");
		},
		...overrides,
	});
	const kaListener23f = (ctx.listeners.get("agent/error") ?? []).at(-1);
	const transientError = Object.assign(new Error("模型服务暂时不可用，请稍后重试"), { failure: { code: "PI_AI_ERROR", message: "模型服务暂时不可用，请稍后重试" } });

	// aborted turn: surfaced, never kept alive
	kaListener23f({ agent: mkAgent("ka-abort"), error: { failure: { code: "ABORTED", message: "user aborted" } } });
	// wallet failure: the arrears machinery owns it
	kaListener23f({ agent: mkAgent("ka-402"), error: { failure: { code: "PI_AI_ERROR", message: "402 status code (no body)" } } });
	// deterministic model error: 继续 cannot fix it
	kaListener23f({ agent: mkAgent("ka-model"), error: { failure: { code: "CONTEXT_OVERFLOW", message: "prompt too long" } } });
	// coarse retryable code wrapping a deterministic message: the permanent
	// family is screened off the haystack even when the code list would retry it
	kaListener23f({ agent: mkAgent("ka-overflow-wrap"), error: { failure: { code: "PI_AI_ERROR", message: "context length exceeded, please shorten" } } });
	await new Promise((r) => setTimeout(r, 60));
	assert(log.filter(([, line]) => line.includes("sent 「继续」")).length === 2, "aborts/wallet/model errors never trigger keep-alive");
	assert(log.filter(([, line]) => line.includes("followup failed")).length === 0, "deterministic failures are never even scheduled (no followup attempt)");

	// all selected accounts in arrears: the pool itself is dead — say so and stop
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], arrears: { p1: true, p2: true }, retry: { enabled: true, keepAlive: { enabled: true, delayMs: 10, maxDelayMs: 20 } } });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	kaListener23f({ agent: mkAgent("ka-arrears"), error: transientError });
	await new Promise((r) => setTimeout(r, 60));
	assert(log.some(([, line]) => line.includes("auto-keepalive") && line.includes("all 2 selected provider account(s) are in arrears")), "all-arrears pool logs the stop reason");
	assert(log.filter(([, line]) => line.includes("sent 「继续」")).length === 2, "all-arrears pool never receives 继续");

	// keep-alive toggle off
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], retry: { enabled: true, keepAlive: { enabled: false, delayMs: 10, maxDelayMs: 20 } } });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	kaListener23f({ agent: mkAgent("ka-off"), error: transientError });
	await new Promise((r) => setTimeout(r, 60));
	assert(log.filter(([, line]) => line.includes("sent 「继续」")).length === 2, "keep-alive off never injects");

	// busy agent: the loop is already driving — no injection on top of it
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], retry: { enabled: true, keepAlive: { enabled: true, delayMs: 10, maxDelayMs: 20 } } });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	kaListener23f({ agent: mkAgent("ka-busy", { status: "running" }), error: transientError });
	await new Promise((r) => setTimeout(r, 60));
	assert(log.filter(([, line]) => line.includes("sent 「继续」")).length === 2, "busy agents are never interrupted by keep-alive");

	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"] });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
}

{
	// 23g. templated wake-up text + retryablePatterns override: `continueText`
	//      placeholders ({code}/{status}/{errorCount}) are filled from the failure
	//      facts, and a literal fragment forces a permanent-class error to count
	//      as recoverable (dsh-auto-continue's retryableErrorPatterns family).
	__clearHealthCache();
	resolved.set("model-fallback", {
		enabled: true,
		providers: ["p1", "p2"],
		retry: {
			enabled: true,
			keepAlive: {
				enabled: true,
				delayMs: 10,
				maxDelayMs: 20,
				continueText: "继续 ({code} 第{errorCount}次 HTTP{status})",
				retryablePatterns: "invalid request",
			},
		},
	});
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	const kaListener23g = (ctx.listeners.get("agent/error") ?? []).at(-1);
	const followups23g = [];
	const agent23g = {
		id: "ka-tpl",
		status: "idle",
		inbox: { hasPending: false, nextTurn: [], nextStep: [] },
		followup(message) {
			followups23g.push(message);
		},
	};
	// A permanent-class failure (invalid request) that builtin classification
	// rejects — but the configured literal fragment forces it recoverable.
	const invalidRequest = Object.assign(new Error("invalid request body"), { failure: { code: "INVALID_REQUEST", message: "invalid request body", status: 400 } });
	kaListener23g({ agent: agent23g, error: invalidRequest });
	assert(followups23g.length === 0, "templated keep-alive waits out the backoff delay");
	await new Promise((r) => setTimeout(r, 60));
	assert(followups23g.length === 1, "retryablePatterns forces the permanent-class failure to be kept alive");
	assert(followups23g[0]?.content?.[0]?.text === "继续 (INVALID_REQUEST 第1次 HTTP400)", `template placeholders fill from failure facts (${followups23g[0]?.content?.[0]?.text})`);
	assert(log.some(([, line]) => line.includes("auto-keepalive") && line.includes("sent 「继续 (INVALID_REQUEST 第1次")), "templated injection logged");

	// Same session, second failure: {errorCount} ascends with the streak.
	kaListener23g({ agent: agent23g, error: invalidRequest });
	await new Promise((r) => setTimeout(r, 60));
	assert(followups23g.length === 2, "second templated keep-alive fires");
	assert(followups23g[1]?.content?.[0]?.text === "继续 (INVALID_REQUEST 第2次 HTTP400)", "errorCount placeholder ascends per consecutive failure");
}

{
	// 23h. maxConsecutive cap: after N consecutive continues the keep-alive
	//      stands down until an error-free turn resets the budget.
	__clearHealthCache();
	resolved.set("model-fallback", {
		enabled: true,
		providers: ["p1", "p2"],
		retry: { enabled: true, keepAlive: { enabled: true, delayMs: 10, maxDelayMs: 20, maxConsecutive: 2 } },
	});
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	const kaListener23h = (ctx.listeners.get("agent/error") ?? []).at(-1);
	const resetListener23h = (ctx.listeners.get("session/event") ?? []).at(-1);
	const followups23h = [];
	const agent23h = {
		id: "ka-cap",
		status: "idle",
		inbox: { hasPending: false, nextTurn: [], nextStep: [] },
		followup(message) {
			followups23h.push(message);
		},
	};
	const transient = () => Object.assign(new Error("模型服务暂时不可用，请稍后重试"), { failure: { code: "PI_AI_ERROR", message: "模型服务暂时不可用，请稍后重试" } });
	kaListener23h({ agent: agent23h, error: transient() });
	await new Promise((r) => setTimeout(r, 60));
	assert(followups23h.length === 1, "first continue within the maxConsecutive budget");
	kaListener23h({ agent: agent23h, error: transient() });
	await new Promise((r) => setTimeout(r, 60));
	assert(followups23h.length === 2, "second continue within the budget");
	// Third failure exceeds the cap: standing down until an error-free turn.
	kaListener23h({ agent: agent23h, error: transient() });
	await new Promise((r) => setTimeout(r, 60));
	assert(followups23h.length === 2, "third failure exceeds maxConsecutive — no further continue");
	assert(log.some(([, line]) => line.includes("auto-keepalive") && line.includes("reached 2 consecutive 继续")), "cap exhaustion logged");
	// An error-free turn resets the budget; the next failure continues again.
	resetListener23h({ id: agent23h.id }, { type: "turn/end", data: { reason: { kind: "completed" } } });
	kaListener23h({ agent: agent23h, error: transient() });
	await new Promise((r) => setTimeout(r, 60));
	assert(followups23h.length === 3, "an error-free turn resets the budget and the next failure continues");
}

{
	// 23i. guardTools idempotency guard: the wake-up message steers the model
	//      based on the last tool call — unconfirmed result (pending) vs
	//      confirmed success (done) — and stays plain when guardTools is off.
	__clearHealthCache();
	resolved.set("model-fallback", {
		enabled: true,
		providers: ["p1", "p2"],
		retry: { enabled: true, keepAlive: { enabled: true, delayMs: 10, maxDelayMs: 20, guardTools: true } },
	});
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	const kaListener23i = (ctx.listeners.get("agent/error") ?? []).at(-1);
	const sessionListener23i = (ctx.listeners.get("session/event") ?? []).at(-1);
	const followups23i = [];
	const agent23i = {
		id: "ka-guard",
		status: "idle",
		inbox: { hasPending: false, nextTurn: [], nextStep: [] },
		followup(message) {
			followups23i.push(message);
		},
	};
	const transient = () => Object.assign(new Error("模型服务暂时不可用，请稍后重试"), { failure: { code: "PI_AI_ERROR", message: "模型服务暂时不可用，请稍后重试" } });
	// A tool call happened but its result never arrived (pending): the guard
	// must warn "may not have completed, verify state, do not re-run".
	sessionListener23i({ id: agent23i.id }, { type: "tool/call", data: { name: "bash", callId: "c1" } });
	kaListener23i({ agent: agent23i, error: transient() });
	await new Promise((r) => setTimeout(r, 60));
	assert(followups23i.length === 1, "guarded keep-alive fires after a pending tool call");
	assert(followups23i[0]?.content?.[0]?.text.includes("可能未完成") && followups23i[0]?.content?.[0]?.text.includes("bash"), "pending guard text names the tool and warns about unconfirmed state");
	assert(followups23i[0]?.content?.[0]?.text.includes("不要重复执行"), "pending guard tells the model not to re-run");
	assert(log.some(([, line]) => line.includes("auto-keepalive") && line.includes("sent 「继续 (上一步工具「bash」")), "guarded injection logged");

	// A tool call that completed successfully (done): guard says "already done".
	const agentDone = { id: "ka-guard-done", status: "idle", inbox: { hasPending: false, nextTurn: [], nextStep: [] }, followup(message) { followups23i.push(message); } };
	sessionListener23i({ id: agentDone.id }, { type: "tool/call", data: { name: "git", callId: "c2" } });
	sessionListener23i({ id: agentDone.id }, { type: "tool/result", data: { message: { content: [{ type: "tool-result", content: [{ type: "text", text: "pushed ok" }] }] } } });
	kaListener23i({ agent: agentDone, error: transient() });
	await new Promise((r) => setTimeout(r, 60));
	assert(followups23i.length === 2, "guarded keep-alive fires after a completed tool call");
	assert(followups23i[1]?.content?.[0]?.text.includes("已完成") && followups23i[1]?.content?.[0]?.text.includes("pushed ok"), "done guard names the tool, the result, and says not to re-run");

	// guardTools off: the message stays the plain template.
	resolved.set("model-fallback", {
		enabled: true,
		providers: ["p1", "p2"],
		retry: { enabled: true, keepAlive: { enabled: true, delayMs: 10, maxDelayMs: 20, guardTools: false } },
	});
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	const kaListener23iOff = (ctx.listeners.get("agent/error") ?? []).at(-1);
	const agentPlain = { id: "ka-guard-off", status: "idle", inbox: { hasPending: false, nextTurn: [], nextStep: [] }, followup(message) { followups23i.push(message); } };
	sessionListener23i({ id: agentPlain.id }, { type: "tool/call", data: { name: "rm", callId: "c3" } });
	kaListener23iOff({ agent: agentPlain, error: transient() });
	await new Promise((r) => setTimeout(r, 60));
	assert(followups23i[2]?.content?.[0]?.text === "继续", "guardTools off keeps the wake-up text plain");
}

{
	// 23j. max-tokens wake-up: a turn that ends at the output-token cap schedules
	//      a continue with the dedicated continueTextMaxTokens template.
	__clearHealthCache();
	resolved.set("model-fallback", {
		enabled: true,
		providers: ["p1", "p2"],
		retry: { enabled: true, keepAlive: { enabled: true, delayMs: 10, maxDelayMs: 20, continueTextMaxTokens: "继续输出，不要重复已生成的内容" } },
	});
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	const kaListener23j = (ctx.listeners.get("agent/error") ?? []).at(-1);
	const sessionListener23j = (ctx.listeners.get("session/event") ?? []).at(-1);
	const followups23j = [];
	const agent23j = {
		id: "ka-maxtok",
		status: "idle",
		inbox: { hasPending: false, nextTurn: [], nextStep: [] },
		followup(message) {
			followups23j.push(message);
		},
	};
	// The max-tokens path resolves the live agent through the agents service.
	const originalGet = ctx.get.bind(ctx);
	ctx.get = (name) => (name === "agents" ? { get: (id) => (id === agent23j.id ? agent23j : undefined) } : originalGet(name));
	try {
		sessionListener23j({ id: agent23j.id }, { type: "turn/end", data: { reason: { kind: "max-tokens" } } });
		assert(followups23j.length === 0, "max-tokens wake waits out the backoff delay");
		await new Promise((r) => setTimeout(r, 60));
		assert(followups23j.length === 1, "max-tokens turn ending schedules a continue");
		assert(followups23j[0]?.content?.[0]?.text === "继续输出，不要重复已生成的内容", "max-tokens wake uses continueTextMaxTokens");
		// A completed turn resets the streak; another max-tokens end wakes again.
		sessionListener23j({ id: agent23j.id }, { type: "turn/end", data: { reason: { kind: "completed" } } });
		sessionListener23j({ id: agent23j.id }, { type: "turn/end", data: { reason: { kind: "max-tokens" } } });
		await new Promise((r) => setTimeout(r, 60));
		assert(followups23j.length === 2, "post-reset max-tokens end re-wakes the session");
	} finally {
		ctx.get = originalGet;
	}
}

{
	// 23k. progress resets: an error-free turn (completed/aborted/blocked)
	//      disarms the pending keep-alive timer and zeroes the streak.
	__clearHealthCache();
	resolved.set("model-fallback", {
		enabled: true,
		providers: ["p1", "p2"],
		retry: { enabled: true, keepAlive: { enabled: true, delayMs: 10, maxDelayMs: 20 } },
	});
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	const kaListener23k = (ctx.listeners.get("agent/error") ?? []).at(-1);
	const resetListener23k = (ctx.listeners.get("session/event") ?? []).at(-1);
	const followups23k = [];
	const agent23k = {
		id: "ka-reset2",
		status: "idle",
		inbox: { hasPending: false, nextTurn: [], nextStep: [] },
		followup(message) {
			followups23k.push(message);
		},
	};
	const transient = () => Object.assign(new Error("模型服务暂时不可用，请稍后重试"), { failure: { code: "PI_AI_ERROR", message: "模型服务暂时不可用，请稍后重试" } });
	// Two consecutive failures -> streak 2; then a blocked turn resets the streak.
	kaListener23k({ agent: agent23k, error: transient() });
	await new Promise((r) => setTimeout(r, 60));
	kaListener23k({ agent: agent23k, error: transient() });
	await new Promise((r) => setTimeout(r, 60));
	assert(followups23k.length === 2, "two consecutive failures keep alive twice");
	kaListener23k({ agent: agent23k, error: transient() });
	await new Promise((r) => setTimeout(r, 5));
	resetListener23k({ id: agent23k.id }, { type: "turn/end", data: { reason: { kind: "blocked" } } });
	await new Promise((r) => setTimeout(r, 60));
	assert(followups23k.length === 2, "a blocked turn disarms the pending keep-alive");
	kaListener23k({ agent: agent23k, error: transient() });
	await new Promise((r) => setTimeout(r, 60));
	assert(followups23k.length === 3, "post-reset failure continues at the base delay again");
}

{
	// 24. log system: the ring buffer captures events and the /dsh-model-fallback/api/log
	//     route serves them as newest-first JSON.
	const webServerRoutes = [];
	// Faithful cordis semantics: webServer is reachable ONLY through inject —
	// the exact guard that broke the first implementation ("without inject").
	const originalInject = ctx.inject.bind(ctx);
	ctx.inject = (deps, callback) => {
		if (Array.isArray(deps) && deps.includes("webServer")) {
			callback({ ...ctx, webServer: { register(route) { webServerRoutes.push(route); return () => {}; } } });
			return;
		}
		return originalInject(deps, callback);
	};
	// Re-apply to mount the route (fresh plugin instance over the same stubs),
	// with auto-mode on so an approval allow lands in the fresh ring buffer.
	resolved.set("model-fallback-auto", { enabled: true, autoAllowPermissions: true, workspaceLog: false });
	apply(ctx, { enabled: true, providers: ["p1", "p2"] });
	await new Promise((r) => setTimeout(r, 20));
	const route = webServerRoutes.find((entry) => entry.path === "/dsh-model-fallback/api/log");
	assert(route !== undefined && route.kind === "exact", "log route registered at /dsh-model-fallback/api/log");

	// Drive a warn through the plugin (listener from the fresh apply).
	const freshApproval = approvalListeners.at(-1);
	await freshApproval({ agent: { session: { header: { cwd: undefined } } }, toolName: "bash", reason: "log e2e" }, async () => "unavailable");
	const chunks = [];
	const writeHead = (code, headers) => { chunks.push({ code, headers }); };
	const end = (body) => { chunks.push({ body }); };
	route.handler({ method: "GET" }, { writeHead, end });
	assert(chunks[0]?.code === 200 && chunks[0]?.headers?.["content-type"]?.startsWith("application/json"), "log route answers 200 JSON");
	const payload = JSON.parse(chunks[1].body);
	assert(Array.isArray(payload.events) && payload.events.length > 0, `log ring served (${payload.events.length} event(s))`);
	assert(payload.events[0].message.includes("bash"), "newest event is the auto-mode allow just driven");
	const times = payload.events.map((entry) => entry.at);
	assert(times.every((at, index) => index === 0 || times[index - 1] >= at), "events ordered newest first");
	// HEAD + method guard
	const headChunks = [];
	route.handler({ method: "HEAD" }, { writeHead: (c, h) => headChunks.push({ c, h }), end: (b) => headChunks.push({ b }) });
	assert(headChunks[0]?.c === 200 && (headChunks[1]?.b === undefined || headChunks[1]?.b === ""), "HEAD answers 200 without a body");
	const methodChunks = [];
	route.handler({ method: "POST" }, { writeHead: (c) => methodChunks.push(c), end: () => {} });
	assert(methodChunks[0] === 405, "non-GET methods answer 405");
	resolved.set("model-fallback-auto", { enabled: false });
	delete ctx.webServer;
}

{
	// 25. per-conversation toggles (会话隔离): the composer pill's overrides pin
	//     ONE conversation's modes through /api/session-state; other
	//     conversations keep following the global default, and subagent
	//     sessions inherit their root conversation's state.
	const webServerRoutes = [];
	const originalInject = ctx.inject.bind(ctx);
	ctx.inject = (deps, callback) => {
		if (Array.isArray(deps) && deps.includes("webServer")) {
			callback({ ...ctx, webServer: { register(route) { webServerRoutes.push(route); return () => {}; } } });
			return;
		}
		return originalInject(deps, callback);
	};
	// parentSession links so the override walk can resolve subagent lineage.
	const parentLinks = new Map([["sub-a1", "conv-a"], ["sub-a2", "conv-a"], ["sub-b1", "conv-b"]]);
	ctx.sessions = { get: (id) => (parentLinks.has(id) ? { header: { parentSession: parentLinks.get(id) } } : undefined) };
	apply(ctx, { enabled: true, providers: ["p1", "p2"] });
	await new Promise((r) => setTimeout(r, 20));

	const route = webServerRoutes.find((entry) => entry.path === "/dsh-model-fallback/api/session-state");
	assert(route !== undefined && route.kind === "exact", "session-state route registered at /dsh-model-fallback/api/session-state");

	const jsonChunks = () => {
		const chunks = [];
		return { chunks, response: { writeHead: (code, headers) => chunks.push({ code, headers }), end: (body) => chunks.push({ body }) } };
	};
	const makePostRequest = (raw, remote = "127.0.0.1") => {
		const listeners = { data: [], end: [], error: [] };
		const req = {
			method: "POST",
			socket: { remoteAddress: remote },
			on(event, fn) {
				listeners[event].push(fn);
				return req;
			},
		};
		queueMicrotask(() => {
			for (const fn of listeners.data) fn(raw);
			for (const fn of listeners.end) fn();
		});
		return req;
	};
	/** Drive one POST through the route and wait for its async body handling. */
	const postSessionState = async (payload, remote = "127.0.0.1") => {
		const { chunks, response } = jsonChunks();
		route.handler(makePostRequest(typeof payload === "string" ? payload : JSON.stringify(payload), remote), response);
		await new Promise((resolve) => setTimeout(resolve, 5));
		return chunks;
	};

	// GET without a sessionId -> 400.
	{
		const { chunks, response } = jsonChunks();
		route.handler({ method: "GET", url: "/dsh-model-fallback/api/session-state" }, response);
		assert(chunks[0]?.code === 400, "GET without sessionId answers 400");
	}
	// GET for an unknown conversation: no override, effective = global defaults.
	{
		const { chunks, response } = jsonChunks();
		route.handler({ method: "GET", url: "/dsh-model-fallback/api/session-state?sessionId=conv-a" }, response);
		const payload = JSON.parse(chunks[1].body);
		assert(chunks[0]?.code === 200 && payload.sessionId === "conv-a", "GET answers the conversation snapshot");
		assert(payload.modes.auto === null && payload.modes.fallback === null, "unknown conversation carries no overrides");
		assert(payload.effective.fallback === true && payload.effective.auto === false, "effective state follows the global defaults");
	}
	// POST pins conv-a's fallback OFF (loopback); validation + trust guard.
	{
		const chunks = await postSessionState({ sessionId: "conv-a", fallback: false });
		const payload = JSON.parse(chunks[1].body);
		assert(chunks[0]?.code === 200 && payload.modes.fallback === false && payload.modes.auto === null, "POST pins the conversation's fallback off");
		assert(payload.effective.fallback === false, "effective fallback follows the pin");
	}
	{
		const chunks = await postSessionState({ fallback: false });
		assert(chunks[0]?.code === 400, "POST without sessionId answers 400");
	}
	{
		const chunks = await postSessionState({ sessionId: "conv-a", fallback: "yes" });
		assert(chunks[0]?.code === 400, "POST with a non-boolean mode answers 400");
	}
	{
		const chunks = await postSessionState({ sessionId: "conv-a", fallback: true }, "10.0.0.7");
		assert(chunks[0]?.code === 403, "POST from a non-loopback address answers 403");
	}

	// Conversation-isolated gating: conv-a passes through untouched while
	// conv-b and the subagents of OTHER conversations stay wrapped.
	const failingStream = (chunksToYield) =>
		(async function* () {
			for (const chunk of chunksToYield) yield chunk;
		})();
	{
		const chunks = await drain(request({ provider: "other", model: "m1", sessionId: "conv-a" }, failingStream([failChunk("UNKNOWN_MODEL", "no such model other/m1")])));
		assert(chunks.length === 1 && chunks[0].reason.kind === "error", "fallback pinned off: the pinned conversation's request surfaces the error untouched");
		assert(log.some(([, line]) => line.includes("fallback disabled for this conversation")), "session-off decision logged");
		const chunksB = await drain(request({ provider: "other", model: "m1", sessionId: "conv-b" }, failingStream([{ type: "text-delta", text: "hello from p1/m2" }, { type: "finish", reason: { kind: "stop", usage: {} } }])));
		assert(chunksB.some((chunk) => chunk.type === "text-delta" && chunk.text === "hello from p1/m2"), "another conversation still recovers through the fallback chain");
		const chunksSubB = await drain(request({ provider: "other", model: "m1", sessionId: "sub-b1" }, failingStream([{ type: "text-delta", text: "hello from p1/m2" }, { type: "finish", reason: { kind: "stop", usage: {} } }])));
		assert(chunksSubB.some((chunk) => chunk.type === "text-delta"), "a subagent of the unpinned conversation still recovers");
	}
	// Subagent inheritance: conv-a's subagent follows conv-a's pin.
	{
		const chunks = await drain(request({ provider: "other", model: "m1", sessionId: "sub-a1" }, failingStream([failChunk("UNKNOWN_MODEL", "no such model other/m1")])));
		assert(chunks.length === 1 && chunks[0].reason.kind === "error", "a subagent of the pinned conversation inherits its override");
	}
	// Pin conv-a back on: its own and its subagent's requests recover again.
	{
		const chunks = await postSessionState({ sessionId: "conv-a", fallback: true });
		assert(chunks[0]?.code === 200 && JSON.parse(chunks[1].body).modes.fallback === true, "POST pins the conversation's fallback back on");
		const chunksRecovered = await drain(request({ provider: "other", model: "m1", sessionId: "sub-a1" }, failingStream([{ type: "text-delta", text: "hello from p1/m2" }, { type: "finish", reason: { kind: "stop", usage: {} } }])));
		assert(chunksRecovered.some((chunk) => chunk.type === "text-delta"), "clearing the pin re-arms the fallback for the conversation's subagent");
	}
	// Both-null clears the entry entirely (follow global again).
	{
		const chunks = await postSessionState({ sessionId: "conv-a", auto: null, fallback: null });
		const payload = JSON.parse(chunks[1].body);
		assert(chunks[0]?.code === 200 && payload.modes.auto === null && payload.modes.fallback === null, "nulling both modes clears the conversation's entry");
	}
	// Per-conversation full-auto under the global gate (设置界面总闸): with the
	// master switch OFF, even a pinned-on conversation stays manual — the
	// capsule half is hidden client-side and the host refuses to act on the
	// stale pin.
	{
		const chunks = await postSessionState({ sessionId: "conv-a", auto: true });
		assert(chunks[0]?.code === 200, "POST pins the conversation's autopilot on");
		const pinned = JSON.parse(chunks[1].body);
		assert(pinned.modes.auto === true && pinned.effective.auto === false, "global auto off: the pin is stored but the effective mode stays off (master gate)");
		const freshApproval = approvalListeners.at(-1);
		const outcome = await freshApproval({ agent: { session: { header: { id: "conv-a", cwd: undefined } } }, toolName: "bash" }, async () => "unavailable");
		assert(outcome === "unavailable", "global autopilot off: the pinned conversation's approval stays manual");
	}
	// With the master switch ON, the capsule isolates conversations: conv-a
	// (pinned on) auto-approves, an unpinned conversation follows the global
	// default, a pinned-off conversation stays manual, and subagents inherit
	// their root conversation's pin.
	{
		resolved.set("model-fallback-auto", { enabled: true, autoAllowPermissions: true, autoAnswerQuestions: true, autoApprovePlans: true });
		const freshApproval = approvalListeners.at(-1);
		const outcomeA = await freshApproval({ agent: { session: { header: { id: "conv-a", cwd: undefined } } }, toolName: "bash" }, async () => "unavailable");
		assert(outcomeA === "allowed-once", "global autopilot on: the pinned-on conversation auto-approves");
		const outcomeB = await freshApproval({ agent: { session: { header: { id: "conv-b", cwd: undefined } } }, toolName: "bash" }, async () => "unavailable");
		assert(outcomeB === "allowed-once", "global autopilot on: an unpinned conversation follows the global default");
		const chunks = await postSessionState({ sessionId: "conv-b", auto: false });
		assert(chunks[0]?.code === 200 && JSON.parse(chunks[1].body).effective.auto === false, "POST pins the second conversation's autopilot off");
		const outcomeBOff = await freshApproval({ agent: { session: { header: { id: "conv-b", cwd: undefined } } }, toolName: "bash" }, async () => "unavailable");
		assert(outcomeBOff === "unavailable", "the pinned-off conversation keeps manual approval");
		const outcomeSubA = await freshApproval({ agent: { session: { header: { id: "sub-a2", parentSession: "conv-a", cwd: undefined } } }, toolName: "bash" }, async () => "unavailable");
		assert(outcomeSubA === "allowed-once", "the pinned-on conversation's subagent inherits the autopilot pin");
		const outcomeSubB = await freshApproval({ agent: { session: { header: { id: "sub-b1", parentSession: "conv-b", cwd: undefined } } }, toolName: "bash" }, async () => "unavailable");
		assert(outcomeSubB === "unavailable", "the pinned-off conversation's subagent inherits the opt-out");
		resolved.set("model-fallback-auto", { enabled: false });
	}
	// Persistence: the override map reached the settings document.
	{
		const stored = resolved.get("model-fallback")?.sessionModes;
		assert(stored !== undefined && typeof stored === "object", "per-session modes persisted into the settings document");
	}
	delete ctx.sessions;
}

{
	// Approval auto-allow must pre-empt the UI/API bridge: registered head-first
	// and immune to cordis-4 context admission filtering. The harness re-applies
	// the plugin on the same context (reload scenarios) — every registration
	// must carry the preemption flags.
	assert(approvalOptions.length >= 1 && approvalOptions.every((options) => options?.prepend === true), "approval/request listener is prepended (beats the UI bridge prompt)");
	assert(approvalOptions.every((options) => options?.global === true), "approval/request listener bypasses context admission filters");
}

{
	// DSH NEXT (user-questions 0.2.x): the provider registry is gone — the
	// service's ask/askTimed methods are the single funnel and the plugin
	// must wrap them directly.
	const realAsk = [];
	const fakeUQ2 = {
		ask: async (request) => {
			realAsk.push(request);
			return { answers: [{ id: "real", selected: ["REAL"] }] };
		},
		askTimed: async (request) => {
			realAsk.push(request);
			return { answers: [{ id: "real-t", selected: ["T"] }] };
		},
	};
	const resolved2 = new Map([["model-fallback", { enabled: true, providers: ["p1"] }], ["model-fallback-auto", { enabled: true, autoAnswerQuestions: true, autoApprovePlans: true }]]);
	const watchers2 = [];
	const ctx2 = {
		fiber: { state: 0 },
		logger,
		llm: fakeLlm,
		locale: {
			register() {},
			bind: () => (key) => key,
		},
		listeners: new Map(),
		get(name) {
			return name === "userQuestions" ? fakeUQ2 : undefined;
		},
		on(eventName, listener) {
			if (!this.listeners.has(eventName)) this.listeners.set(eventName, []);
			this.listeners.get(eventName).push(listener);
			return () => {};
		},
		effect(factory) {
			return typeof factory?.() === "function" ? factory() : undefined;
		},
		inject(_deps, callback) {
			callback(ctx2);
		},
		settings: {
			register(namespace, schema, options) {
				return {
					get: () => resolved2.get(namespace),
					watch: (callback) => {
						watchers2.push(callback);
						return () => {};
					},
				};
			},
			async update() {},
		},
	};
	apply(ctx2, { enabled: true, providers: ["p1"] });
	for (const watcher of watchers2) watcher();
	await new Promise((r) => setTimeout(r, 20));

	const planReq = {
		questions: [{
			id: "plan-review",
			question: "Approve this plan and leave plan mode?",
			options: [{ label: "Approve (Recommended)" }, { label: "Keep planning" }],
			intent: { kind: "plan-review", approve: "Approve (Recommended)" },
		}],
		agent: { id: "agent-2", session: { header: { id: "s-next" } } },
	};
	const planAnswer = await fakeUQ2.ask(planReq);
	assert(realAsk.length === 0 && planAnswer.answers[0].selected[0] === "Approve (Recommended)", "0.2.x seam: plan review auto-approved through the wrapped ask()");
	const plainAnswer = await fakeUQ2.ask({ questions: [{ id: "choice", question: "Pick one", options: [{ label: "First" }, { label: "Second" }] }] });
	assert(plainAnswer.answers[0].selected[0] === "First", "0.2.x seam: confirmation auto-answered with the first option");
	const timedAnswer = await fakeUQ2.askTimed({ questions: [{ id: "plan-review", question: "Approve this plan and leave plan mode?", intent: { kind: "plan-review", approve: "Approve (Recommended)" } }] }, "call-1", 120000);
	assert(realAsk.length === 0 && timedAnswer.answers[0].selected[0] === "Approve (Recommended)", "0.2.x seam: timed ask auto-answered without a pending wait");
	resolved2.set("model-fallback-auto", { enabled: false });
	for (const watcher of watchers2) watcher();
	await new Promise((r) => setTimeout(r, 20));
	await fakeUQ2.ask({ questions: [{ id: "choice", question: "Pick one", options: [{ label: "First" }] }] });
	assert(realAsk.length === 1, "0.2.x seam: master off delegates to the real ask()");
}

{
	// DSH NEXT acceptance: the UI/API bridge installs its approval/request
	// handler BEFORE the plugin (a client stream opens early in boot) and
	// prompts a human without calling next(). The plugin's prepend+global
	// registration must still answer first — this is the exact ordering bug
	// that left 5 approvals prompting while full-auto was armed.
	const prompts = [];
	const chain = [];
	const resolved3 = new Map([["model-fallback", { enabled: true, providers: ["p1"] }], ["model-fallback-auto", { enabled: true, autoAnswerQuestions: true, autoApprovePlans: true }]]);
	const uq3 = {};
	const auditDir = join(tmpdir(), `dshmfb-audit-${process.pid}`);
	mkdirSync(auditDir, { recursive: true });
	let promptSpec = null;
	const ctx3 = {
		fiber: { state: 0 },
		logger,
		llm: fakeLlm,
		locale: { register() {}, bind: () => (key) => key },
		systemPrompt: {
			context(spec) {
				promptSpec = spec;
			},
		},
		listeners: new Map(),
		get(name) {
			return name === "userQuestions" ? uq3 : undefined;
		},
		on(eventName, listener, options) {
			if (eventName === "approval/request") chain[options?.prepend ? "unshift" : "push"](listener);
			return () => {};
		},
		effect(factory) {
			return typeof factory?.() === "function" ? factory() : undefined;
		},
		inject(_deps, callback) {
			callback(ctx3);
		},
		settings: {
			register(namespace) {
				return { get: () => resolved3.get(namespace), watch: () => () => {} };
			},
			async update() {},
		},
	};
	// The bridge registers FIRST and never calls next() (it prompts the UI).
	chain.push(async (request) => {
		prompts.push(request);
		return "prompted";
	});
	apply(ctx3, { enabled: true, providers: ["p1"], auto: { enabled: true, autoAllowPermissions: true } });
	const runWaterfall = async (request) => {
		const cbs = [...chain];
		const next = () => (cbs.shift() ?? (() => "unavailable"))(request, next);
		return next();
	};
	const outcome = await runWaterfall({ agent: { id: "agent-3", session: { header: { id: "s-bridge", cwd: auditDir } } }, toolName: "bash", reason: "escalate sandbox" });
	assert(outcome === "allowed-once", "full-auto approval preempts the earlier-registered UI bridge");
	assert(prompts.length === 0, "the UI bridge never prompted a human while full-auto is armed");
	// Channel 3: the model-facing notice follows the conversation's gate.
	assert(promptSpec?.name === "auto-mode:enabled" && promptSpec.text({ agent: { session: { header: { id: "s-bridge" } } } }).includes("Full-auto mode is ON"), "system-prompt notice announces full-auto for the gated conversation");
	// The auto-allow is audited to the conversation workspace's AUTO-MODE.md.
	await new Promise((r) => setTimeout(r, 30));
	const audit = readFileSync(join(auditDir, "AUTO-MODE.md"), "utf8");
	assert(audit.includes("权限审批") && audit.includes("已自动允许"), "auto-allowed approval written to the workspace AUTO-MODE.md audit");
	// Gates off → the bridge keeps its human prompt (manual approval intact).
	resolved3.set("model-fallback-auto", { enabled: false });
	const outcomeOff = await runWaterfall({ agent: { id: "agent-3", session: { header: { id: "s-bridge", cwd: auditDir } } }, toolName: "bash" });
	assert(outcomeOff === "prompted" && prompts.length === 1, "full-auto off: the request falls through to the UI bridge");
	assert(promptSpec.text({ agent: { session: { header: { id: "s-bridge" } } } }) === "", "system-prompt notice turns off with the gate");
	rmSync(auditDir, { recursive: true, force: true });
}

{
	// 19. Chunk-vocabulary fail-safe: an unknown future frame kind counts as
	//     visible content — after one, the wrapper must never re-stream on top
	//     of output the consumer already received (duplicate/corruption).
	adapterStreamCalls.length = 0;
	const chunks = await drain(
		request({ provider: "p1", model: "m1" }, (async function* () {
			yield { type: "future-frame", payload: { x: 1 } };
			yield failChunk("UNKNOWN_MODEL", "nope");
		})()),
	);
	assert(adapterStreamCalls.length === 0, "unknown chunk kind counts as visible content (no double stream over shown output)");
	assert(chunks.some((chunk) => chunk.type === "future-frame"), "unknown chunk passes through to the consumer untouched");

	// 20. Known control frames (official StreamChunk vocabulary) never carry
	//     visible output — a model failing after only those stays switchable.
	adapterStreamCalls.length = 0;
	const recovered = await drain(
		request({ provider: "p1", model: "m1" }, (async function* () {
			yield { type: "block-start", index: 0, blockType: "text" };
			yield { type: "usage", usage: { input: 1, output: 0 } };
			yield failChunk("UNKNOWN_MODEL", "nope");
		})()),
	);
	assert(adapterStreamCalls.length > 0, "control-only prelude keeps the request switchable");
	assert(recovered.some((chunk) => chunk.type === "text-delta" && chunk.text === "hello from p1/m2"), "switch after control frames still recovers the request");
}

{
	// 21. Host shape drift: a session object without `append` must not crash
	//     the loop-retry path (the bookkeeping rows are best-effort).
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], retry: { enabled: true, loopRetry: true, maxRetries: 2, baseDelayMs: 5 } });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
	const noAppendSession = { events: [] };
	const outcome = await loopListeners[0]({ agent: { session: noAppendSession }, turn: 1, step: 1, provider: "p1", failure: { code: "NETWORK_ERROR", message: "connection reset" } }, async () => undefined);
	assert(outcome && outcome.kind === "retry", "loop retry still engages when the session cannot append bookkeeping rows");
}

{
	// 22. Late userQuestions: a service that registers (or is rebuilt) AFTER
	//     this plugin armed must still get wrapped — ctx.inject re-arms per
	//     instance, where a one-shot ctx.get left full-auto Q&A silently dead.
	let lateService = null;
	const pendingArms = [];
	const lateCtx = {
		fiber: { state: 0 },
		logger,
		llm: fakeLlm,
		webServer: { register: () => () => {} },
		get: (serviceName) => (serviceName === "userQuestions" ? lateService : undefined),
		on: () => () => {},
		effect: (factory) => (typeof factory?.() === "function" ? factory() : undefined),
		inject(deps, callback) {
			if (deps.includes("userQuestions") && !lateService) {
				pendingArms.push(() => callback(lateCtx));
				return;
			}
			callback(lateCtx);
		},
	};
	apply(lateCtx, { enabled: true, providers: ["p1"], auto: { enabled: true, autoAllowPermissions: true, autoAnswerQuestions: true, autoApprovePlans: true } });
	assert(pendingArms.length === 1 && lateService === null, "user-question gate waits for a late service instead of giving up");
	lateService = {
		ask: async () => ({ answers: [{ id: "q1", selected: [] }] }),
		askTimed: async () => ({ answers: [{ id: "q1", selected: [] }] }),
	};
	for (const arm of pendingArms) arm();
	assert(lateService.autoModeWrapped === true, "late userQuestions instance is wrapped when it appears");
	const answer = await lateService.ask({ questions: [{ id: "q1", options: [{ label: "Yes" }] }] });
	assert(answer?.answers?.[0]?.selected?.[0] === "Yes", "late-wrapped ask auto-answers with the recommended option");
}

{
	// 23. Hostile config shapes: `providers` reaches apply() from patch layers
	//     and settings writes outside this plugin's control — a dict landed in
	//     a user's profile patch and crashed activation ("providers is not
	//     iterable"), leaving EVERY toggle inert. Any shape must degrade to
	//     "no candidates", never crash, on both the boot and runtime paths.
	const hostileEvents = new Map();
	const badCtx = {
		fiber: { state: 0 },
		logger,
		llm: fakeLlm,
		webServer: { register: () => () => {} },
		get: () => undefined,
		on: (eventName, listener) => {
			hostileEvents.set(eventName, listener);
			return () => {};
		},
		effect: (factory) => (typeof factory?.() === "function" ? factory() : undefined),
		inject: (_deps, callback) => callback(badCtx),
		settings: { describe: () => [], update: async () => {}, mutate: async () => {} },
	};
	const shapes = [{ "reth-main": ["glm-5.3-flash"] }, 5, true, "x", null, undefined, ["p1"]];
	for (const shape of shapes) {
		let crashed = null;
		try {
			apply(badCtx, { enabled: true, providers: shape });
		} catch (error) {
			crashed = error;
		}
		assert(crashed === null, `apply() survives providers=${typeof shape} (hostile shape does not kill activation)`);
	}
	try {
		hostileEvents.get("llm/adapters-updated")?.();
		assert(true, "adapters-updated survives a non-list providers value");
	} catch (error) {
		assert(false, `adapters-updated crashed: ${error.message}`);
	}
}

{
	// 24. wallet/credential classifier vocabulary — the badge contract is
	//     "欠费或鉴权失败": pi-ai catch-all codes, the ACCOUNT_QUOTA family,
	//     OpenAI-style insufficient_quota strings and credential-invalid
	//     wordings must auto-mark; a model-scoped 403 must NOT.
	const classifierCases = [
		{ code: "PI_AI_ERROR", message: "Insufficient Balance", expect: true, label: "OpenAI-style 'Insufficient Balance' via PI_AI_ERROR" },
		{ code: "ACCOUNT_QUOTA", message: "account quota exhausted", expect: true, label: "ACCOUNT_QUOTA family code" },
		{ code: "PI_AI_ERROR", message: "insufficient_quota: You exceeded your current quota", expect: true, label: "OpenAI error-type string with quota wording" },
		{ code: "AUTH", message: "invalid api key", expect: true, label: "credential-invalid wording on an AUTH class" },
		{ code: "AUTH", message: "This model is not available for this key", expect: false, label: "model-scoped 403 stays model-level (no marker)" },
		{ code: "PI_AI_ERROR", message: "模型服务暂时不可用，请稍后重试", expect: false, label: "transient gateway wording is not account-level" },
	];
	for (const testCase of classifierCases) {
		__clearHealthCache();
		resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"], arrears: {} });
		for (const watcher of watchers) watcher();
		await new Promise((r) => setTimeout(r, 20));
		failingModels.clear();
		healthyModels.clear();
		healthyModels.add("p2/m1");
		adapterStreamCalls.length = 0;
		await drain(
			request({ provider: "p1", model: "m1" }, (async function* () {
				yield failChunk(testCase.code, testCase.message);
			})()),
		);
		let stored = resolved.get("model-fallback");
		for (let i = 0; i < 50 && testCase.expect && stored?.arrears?.p1 !== true; i += 1) {
			await new Promise((r) => setTimeout(r, 20));
			stored = resolved.get("model-fallback");
		}
		assert((stored?.arrears?.p1 === true) === testCase.expect, `classifier: ${testCase.label} -> account-level=${testCase.expect}`);
	}
	resolved.set("model-fallback", { enabled: true, providers: ["p1", "p2"] });
	for (const watcher of watchers) watcher();
	await new Promise((r) => setTimeout(r, 20));
}

{
	// 25. The cordis LoggerService is a CALLABLE (typeof "function") — the
	//     plugin's logger guard must accept that shape or EVERY diagnostic
	//     line is silently swallowed (that happened and hid real failures).
	const lines = [];
	const callableLogger = Object.assign(() => {}, {
		info: (...a) => lines.push(["info", a.join(" ")]),
		warn: (...a) => lines.push(["warn", a.join(" ")]),
		error: (...a) => lines.push(["error", a.join(" ")]),
	});
	const fnCtx = {
		fiber: { state: 0 },
		logger: callableLogger,
		llm: fakeLlm,
		webServer: { register: () => () => {} },
		get: () => undefined,
		on: () => () => {},
		effect: (factory) => (typeof factory?.() === "function" ? factory() : undefined),
		inject: (_deps, callback) => callback(fnCtx),
		settings: { describe: () => [], update: async () => {}, mutate: async () => {} },
	};
	apply(fnCtx, { enabled: true, providers: ["p1"] });
	assert(typeof callableLogger === "function" && lines.some(([, text]) => text.includes("fallback loop armed")), "callable host logger (typeof function) receives the plugin's log lines");
}

assert(name === "model-fallback", "plugin name exported");
console.log(process.exitCode ? "SMOKE TEST FAILED" : "SMOKE TEST PASSED");
//#endregion
