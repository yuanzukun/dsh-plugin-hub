# dsh-grok-geo

> DeepSeek Harness (DSH) 插件：把 **GEO Brand Audit Skill**
> （[grok-geo](https://github.com/xuboboo/grok-geo)，MIT）以官方 **bundle 插件** 形态分发到 DSH 生态。

安装后，DSH 的 skill 工具即可发现并加载 `grok-geo`：对单一品牌执行可追溯的
AI 搜索/GEO 审计——AI 引擎可见性、推荐与引用、竞品对比、事实准确性、内容缺口，
支持 17+ 主流 AI 搜索引擎（8 个国际 + 9 个中文引擎）。

## 这是什么 / What is this

一个 **DSH bundle**（npm 包 + `dsh.bundle` 声明 + `cordis.patch.yml`），安装后：

- 在 `ctx.skills` 上注册一个 **bundled skill provider**（与官方
  `@deepseek-ai/dsh-skill-badge` 同款模式，rank = `BUNDLED_SKILL_RANK`）；
- 完整 skill 包（`SKILL.md`、`scripts/`（含 core/、scoring/）、`mcp/`、
  `schemas/`、`templates/`、`examples/`、`evals/`）随插件分发，
  `resourceBase` 指向打包目录，模型可按需读取并执行脚本。

插件本身不依赖 Python；skill 脚本需要 Python 3.11+（仅标准库，无需 pip 安装依赖）。

## 安装 / Install

```sh
# 从 GitHub 安装（推荐）
dsh plugin --profile web add "github:xuboboo/dsh-grok-geo"

# 或本地目录安装（开发调试）
dsh plugin --profile web add C:/path/to/dsh-grok-geo
```

重启 DSH 后生效（设置 → 插件面板可查看/卸载）。验证：

```sh
dsh --profile web --dump-config | findstr grok-geo
```

## 使用 / Usage

对话中提及 GEO 审计、AI 搜索可见性/引用分析等场景时，模型会自动调用该 skill；
也可以直接要求：

- 「对某品牌做一次 GEO 快速审计（quick 模式）」
- 「分析我们品牌在 ChatGPT/Perplexity/豆包/DeepSeek 里的可见性与引用」
- 「对比我们与竞品在 AI 引擎中的推荐表现」「做标准模式全量诊断」

Skill 的流水线：`输入收集（Inversion）→ 校验初始化 → 搜索执行 → 指标计算 →
报告渲染 → 质量审查`；web_search 不可用时自动切换 OFFLINE_IMPORT 模式。

## 运行环境 / Runtime

```sh
# 找到插件目录（profile 安装后位于 profile 的 node_modules 下）
cd "$DSH_HOME/profiles/web/node_modules/dsh-grok-geo/assets/skill"

# 校验输入（示例）
python scripts/validate_input.py --input examples/input.minimal.json --output /tmp/normalized.json
```

运行目录默认 `./geo-audit-runs`，可用环境变量 `GEO_AUDIT_RUNS_DIR` 覆盖。

## 可选：MCP 工具接入

默认形态下，模型通过 shell 直接运行 skill 脚本，无需 MCP。
若希望工具以 `mcp__grok_geo__*` 形式注册进 `ctx.tools`，见
[patches/mcp-client.example.yml](patches/mcp-client.example.yml)（需先
`dsh plugin --profile web add @deepseek-ai/dsh-mcp-client`）。

## 能力边界 / Boundaries

继承原 skill 的硬规则：绝不编造搜索结果或引用；web_search 不可用时切
OFFLINE_IMPORT；不用于普通文案、泛 SEO 关键词研究、社交媒体抓取、
保证排名或内容发布。

## 开发 / Develop

```
dsh-grok-geo/
├── package.json            # dsh.bundle → cordis.patch.yml
├── cordis.patch.yml        # 插入插件行
├── lib/index.js            # skill provider（纯 ESM，无构建步骤）
├── assets/skill/           # 完整 skill 包（来自上游仓库 skill/grok-geo/）
├── patches/                # 可选 MCP 接入示例
└── README.md
```

本地验证：

```sh
dsh plugin --profile grok-test add .              # 装进临时 profile
dsh --profile grok-test --dump-config            # 确认层已生效
```

## 上游 / Upstream

- Skill 源码：[xuboboo/grok-geo](https://github.com/xuboboo/grok-geo)
- DSH 插件开发文档：[develop/basic](https://deepseek-harness.github.io/deepseek-harness/develop/basic/)
- License: MIT
