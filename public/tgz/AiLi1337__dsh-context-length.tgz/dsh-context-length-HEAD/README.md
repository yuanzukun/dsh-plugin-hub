# dsh-context-length

DSH（DeepSeek Harness）插件：在 **设置 → 模型** 下方新增「**上下文长度**」页面，为指定渠道（提供方）的指定模型自定义上下文窗口长度。

[![npm version](https://img.shields.io/npm/v/dsh-context-length.svg)](https://www.npmjs.com/package/dsh-context-length)
[![npm downloads](https://img.shields.io/npm/dm/dsh-context-length.svg)](https://www.npmjs.com/package/dsh-context-length)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

## 特性

- 页面位置：设置面板左侧导航「模型」之下（`settings.section`，order 11）。
- 渠道列表只列出**已配置**的提供方（设置文档中存在其 profile，如 `newapi`、`火山`），未配置的内置路由不会出现。
- **现代化布局**：渠道与模型联动两列网格展示，直观紧凑。
- **容量预设与实时换算**：支持 `32K`、`64K`、`128K`、`256K`、`1M` 等一键快捷填入，并在输入时实时展示换算 token 数预览。
- **思考强度配置**：同一页面即可为模型勾选 `off / minimal / low / medium / high / xhigh / max` 七档思考强度（`reasoningEfforts`），与上下文长度共用同一保存动作一次写入。
- **推理开关自动补全**：对 `api: openai-completions` 的渠道，保存思考强度时会自动补齐缺失的 `compat.thinkingFormat` / `compat.supportsReasoningEffort`（幂等、保留已有键），确保思考强度真正随请求发送。
- **全景自定义模型列表**：底部聚合展示所有渠道已自定义的模型清单（上下文长度 + 思考档位），支持一键载入编辑或快速恢复默认。
- 只有点击「保存」才会通过 `settings.mutate` 写入设置文档并生效；不点保存不产生任何修改。
- 支持「恢复默认」：清除某个模型的 `contextWindow` 与 `reasoningEfforts` 覆盖，回到提供方默认值。

## 安装

在 DeepSeek Harness 的「插件」页面安装 Git 仓库 `https://github.com/AiLi1337/dsh-context-length`。桌面版和 Web 版是不同的 profile，需在各自使用的界面分别安装。包内的 `dsh.bundle.patch` 会让安装器自动挂载插件，无需手动修改 profile 的 `cordis.patch.yml`；安装后重启或刷新界面，在 **设置 → 上下文长度** 查看。

要测试尚未推送到 GitHub 的本地修改，可在「插件」页面选择本地目录安装，或使用 DSH 的插件命令将本地目录添加到相应 profile。GitHub 地址始终安装远端已推送的版本；npm 上原有的 `0.1.0` 没有组合包声明，不能通过桌面版插件页面安装，须发布新版本后才能通过 npm 包名安装。

此前已在 Web profile 手动添加过 `cordis.patch.yml` 挂载行的用户，改用图形安装前请移除那条手动挂载行，避免同一个插件 id 重复插入。

## 使用

1. 打开 **设置 → 上下文长度**
2. 选择 **渠道（提供方）** → 选择该渠道下的一个 **模型**
3. 填写新的上下文窗口数值（如 `131072`、`256K`、`1M`，或点预设快捷填入），显示当前值
4. 点击 **保存** 才写入生效；也可点「恢复默认」清除该模型的覆盖
5. 页面底部列出所有已自定义上下文窗口的模型，保存后自动刷新

## 架构

- `lib/index.js` —— 宿主（node）半端：最小条目，仅保证 loader 挂载。
- `cordis.patch.yml` —— 组合包的挂载补丁，由插件安装器自动加入当前 profile。
- `lib/client.js` —— 浏览器半端：设置页 UI。浏览器端的加载走官方机制：`package.json` 声明 `dsh.client`（platform: web），`client-modules` 插件自动把它纳入 `window.__DSH_BOOT__` 引导图。通过 `ctx.remote.llm`、`ctx.remote.settings.mutate` 和 `ctx.configForms.describe()` 读写，宿主始终是唯一事实源。
- `test/smoke.mjs` —— 冒烟测试：在 Node 中模拟 DSH 模块加载器环境，验证 client 半端能正确加载、注册 `settings.section`（id=`context-length`，order=11，标签「上下文长度」）。可选：设置 `DCL_TEST_REACT_ROOT` 指向一个含 `react` + `react-dom` 的 `node_modules` 目录，可额外执行 SSR 渲染检查。
- `test/bundle.mjs` —— 验证桌面版所需的组合包声明、挂载补丁和宿主入口。

## 开发

```sh
# 运行冒烟测试
node test/smoke.mjs
node test/bundle.mjs

# 发布新版本（需 npm 2FA 验证）
npm version patch && npm publish
```
