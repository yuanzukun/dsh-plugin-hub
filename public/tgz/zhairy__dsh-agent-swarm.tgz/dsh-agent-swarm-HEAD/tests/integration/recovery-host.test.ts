import { existsSync, readFileSync, writeFileSync, mkdirSync, mkdtempSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { createServer } from 'node:http'
import type { AddressInfo } from 'node:net'
import { join } from 'node:path'
import { beforeAll, describe, expect, it } from 'vitest'
import YAML from 'yaml'
import { getRoutesOverlay, type ScenarioRunInfo } from './helpers.js'
import { REPO_ROOT, DRIVER_DIR, SANDBOX_ROOT, PROFILE, ensureProfile, getTestedVersion, getSandboxDshModules, runDshAsync } from '../../scripts/sandbox.mjs'
import { MERMAID_PARSER_VERSION } from '../../src/workflow.js'

interface RecoveryRun extends ScenarioRunInfo {
  runtimeStatus?: { tasks: Array<{ runtimeGuard: { control: { status: string; reason: string } } }> }
  committedToolResults?: Array<{ isError: boolean; text: string }>
  recoveryRequests: Array<{ provider?: string; model: string; sessionId: string; at: number }>
  recoveryEvents: Array<{ type: string; data?: unknown }>
  recoveryTerminal?: string
  agentErrors?: Array<{ message?: string; code?: string }>
  adapterThrows?: number
  bridgeTools?: Array<{ model: string; tools: string[] }>
  bridgeToolExecutions?: number
  bridgeHeaders?: Array<{ provider: string; model: string }>
  bridgeSelections?: Array<{ provider: string; model: string }>
  bridgeUserMessages?: number
  planningReviewers?: Array<{ sessionId: string; model: string; tools: string[]; outputSchemaProperties: string[]; snapshotDigest: string; requestText: string; requestRevision: number; requestRefs?: Array<{ source: string; text?: string; textRef?: string }>; mermaid: string; workflow: unknown; planningScope?: { kind: string; deferred: string[] }; seesAgentResult: boolean; seesJevResult: boolean; readResult?: string; mutationResult?: string; mutationIsError?: boolean; missingContextResult?: string; missingContextIsError?: boolean }>
  planningStatus?: { tasks: Array<{ planningReview?: unknown; acceptance?: { status: string } }> }
  hostApis?: { start: boolean; startActivation: boolean }
  analysisReadResult?: string
  analysisContext?: { taskId: string; crossTaskId: string; tools: string[]; indexResult: string; indexIsError: boolean;
    readResult: string; readIsError: boolean; crossTaskResult: string; crossTaskIsError: boolean; missingResult: string; missingIsError: boolean }
  questionRequests?: number
  planningControlBefore?: unknown
  planningControlSelected?: unknown
  planningControlAfter?: unknown
  planningRunObserved?: unknown
  questionTranscript?: { questionCall: { id: string; name: string; arguments: string }; questionResult: {
    id: string; role: string; source: { kind: string; callId: string }; toolCallId: string; isError: boolean; content: Array<{ type: string; text?: string }>
  } }
}
const RECOVERY_BASE = {
  jev: { enabled: false }, planningReview: { enabled: false }, workflow: { mode: 'advisory' },
  agents: { maxRetries: 3, retryBackoffMs: 1, networkWaitMs: 0 }
}
const runRecovery = async (scenario: string, routes: Record<string, unknown>, mode: string, rootModel?: string, options: { config?: Record<string, unknown>; env?: Record<string, string> } = {}): Promise<RecoveryRun> => {
  const { home } = ensureProfile()
  mkdirSync(SANDBOX_ROOT, { recursive: true })
  const workspace = mkdtempSync(join(SANDBOX_ROOT, `recovery-ws-${scenario}-`))
  writeFileSync(join(workspace, 'README.md'), '# recovery fixture\n')
  const git = (args: string[]) => execFileSync('git', ['-c', 'user.name=recovery-test', '-c', 'user.email=recovery@test.local', ...args], { cwd: workspace, stdio: 'ignore' })
  git(['init', '-q']); git(['add', '-A']); git(['commit', '-q', '-m', 'fixture'])
  const overlay = `${workspace}.overlay.yml`
  writeFileSync(overlay, YAML.stringify([
    { id: 'swarm-core', config: { ...RECOVERY_BASE, routes, ...options.config } },
    { insert: [
      ...(scenario === 'planning-question-reply' ? [{ id: 'swarm-question-fixture-tool', name: '@deepseek-ai/dsh-tool-ask-user' }] : []),
      { id: 'swarm-recovery-test-driver', name: join(DRIVER_DIR, 'recovery-scenarios.js') }
    ] }
  ]))
  const out = `${workspace}.out.json`
  const result = await runDshAsync({ args: ['--profile', PROFILE, '--patch', overlay], cwd: workspace, timeout: 35000,
    env: { SWARM_SCENARIO: '', SWARM_RECOVERY_SCENARIO: scenario, SWARM_DRIVER_OUT: out, SWARM_RECOVERY_RETRY_MODE: mode, SWARM_ROOT_MODEL: rootModel ?? 'root', SWARM_RECOVERY_SDK_MODULES: getSandboxDshModules(), ...options.env }
  })
  if (!existsSync(out)) throw new Error(`恢复场景 ${scenario} 没有输出。\n${result.stdout}\n${result.stderr}`)
  const data = JSON.parse(readFileSync(out, 'utf8'))
  const ledgerFile = join(home, 'share', 'dsh-agent-swarm', 'ledger', `${data.sessionId ?? 'none'}.jsonl`)
  const ledgerEvents = existsSync(ledgerFile) ? readFileSync(ledgerFile, 'utf8').split('\n').filter(Boolean).map((line) => JSON.parse(line)) : []
  return { ...data, ledgerEvents, workspace, stdout: result.stdout, stderr: result.stderr } as RecoveryRun
}
const retryEvents = (run: RecoveryRun) => run.recoveryEvents.filter((event) => event.type === 'llm/retry' || event.type === 'llm/retry-started')
const failureRequests = (run: RecoveryRun) => run.recoveryRequests.filter((request) => /^fail-(?:pool|quota-[ab])$/.test(request.model))

beforeAll(() => {
  if (!existsSync(join(REPO_ROOT, 'lib', 'index.js'))) throw new Error('请先运行 npm run build')
  ensureProfile()
})

describe('真实 AgentLoop：pool exhausted 9060669ms 与终态恢复', () => {
  it.skipIf(getTestedVersion() !== '0.2.2-rc.1')('切换备用时重新解析模型条件工具，且执行只发生一次', async () => {
    const run = await runRecovery('recovery-capability-switch', getRoutesOverlay({ tian_shu: ['fail-pool', 'root'] }), 'normal', 'fail-pool')
    expect(run.status, run.error ?? run.stderr).toBe('done')
    expect(run.bridgeTools?.[0]).toMatchObject({ model: 'fail-pool' })
    expect(run.bridgeTools?.[0]?.tools).not.toContain('bridge_backup_only')
    expect(run.bridgeTools?.[1]).toMatchObject({ model: 'root' })
    expect(run.bridgeTools?.[1]?.tools).toContain('bridge_backup_only')
    expect(run.bridgeToolExecutions).toBe(1)
    expect(run.bridgeHeaders?.slice(0, 2).map((header) => header.model)).toEqual(['fail-pool', 'root'])
    expect(run.bridgeSelections).toEqual([])
    expect(run.bridgeUserMessages).toBe(1)
    expect(run.results[0]?.isError).toBe(false)
  })
  it.each(['normal', 'always'])('真实 adapter 抛出14h24m pool/429错误时立即备用而非宿主长退避：%s', async (mode) => {
    const run = await runRecovery('recovery-pool-thrown', getRoutesOverlay({ tian_shu: ['fail-pool-thrown', 'root'] }), mode, 'fail-pool-thrown')
    expect(run.status, run.error ?? run.stderr).toBe('done')
    expect(run.adapterThrows).toBe(1)
    expect(run.recoveryRequests.map(request => request.model)).toEqual(['fail-pool-thrown', 'root'])
    expect(retryEvents(run)).toEqual([])
  })
  for (const mode of ['normal', 'always']) {
    it(`${mode}：根模型池不可用立即选择备用，不生成长退避事件`, async () => {
      const run = await runRecovery('recovery-pool-backup', getRoutesOverlay({ tian_shu: ['fail-pool', 'root'] }), mode, 'fail-pool')
      expect(run.status, run.error ?? run.stderr).toBe('done')
      expect(run.recoveryRequests.map((request) => request.model)).toEqual(['fail-pool', 'root'])
      expect(retryEvents(run)).toEqual([])
      expect(run.recoveryRequests[1]!.at - run.recoveryRequests[0]!.at).toBeLessThan(5000)
      expect(run.ledgerEvents.some((event) => event.type === 'route/fallback' && event.data.scope === 'root')).toBe(true)
    })

    it(`${mode}：所有备用额度耗尽，终止原请求而不继续调用或退避`, async () => {
      const run = await runRecovery('recovery-all-quota', getRoutesOverlay({ tian_shu: ['fail-pool', 'fail-quota-a', 'fail-quota-b'] }), mode, 'fail-pool')
      expect(run.status, run.error ?? run.stderr).not.toBe('timeout')
      expect(failureRequests(run).map((request) => request.model)).toEqual(['fail-pool', 'fail-quota-a', 'fail-quota-b'])
      expect(run.recoveryTerminal).toBe('route_chain_exhausted')
      expect(retryEvents(run)).toEqual([])
      expect(run.results).toEqual([])
    })

    for (const session of ['oneshot', 'continuable']) {
      it(`${mode}/${session}：专家链耗尽不触发外层3次乘算重启`, async () => {
        const run = await runRecovery(`recovery-child-${session}`, getRoutesOverlay({ tan_wei: ['fail-pool', 'fail-quota-a', 'fail-quota-b'] }), mode)
        expect(run.status, run.error ?? run.stderr).toBe('done')
        const failures = failureRequests(run)
        expect(failures.map((request) => request.model)).toEqual(['fail-pool', 'fail-quota-a', 'fail-quota-b'])
        expect(new Set(failures.map((request) => request.sessionId)).size).toBe(1)
        expect(retryEvents(run)).toEqual([])
        expect(run.results[1]?.text).toContain('failed')
        expect(run.ledgerEvents.filter((event) => event.type === 'delegation/retry')).toEqual([])
      })
    }
  }

  it('成功备用写入一次，模型恢复不从头重做工具副作用', async () => {
    const run = await runRecovery('recovery-write-once', getRoutesOverlay({ ji_feng: ['fail-pool', 'writer-ji_feng'] }), 'always')
    expect(run.status, run.error ?? run.stderr).toBe('done')
    expect(failureRequests(run).map((request) => request.model)).toEqual(['fail-pool'])
    const requests = run.recoveryRequests.filter((request) => request.model === 'writer-ji_feng')
    expect(requests).toHaveLength(2) // 第一次真实 write，第二次 structured_output。
    expect(new Set(requests.map((request) => request.sessionId)).size).toBe(1)
    expect(readFileSync(join(run.workspace, 'hello.txt'), 'utf8')).toBe('hello swarm\n')
    expect(run.ledgerEvents.filter((event) => event.type === 'delegation/completed')).toHaveLength(1)
    expect(run.ledgerEvents.filter((event) => event.type === 'delegation/retry')).toEqual([])
    expect(retryEvents(run)).toEqual([])
  })
})

describe('真实 AgentLoop：默认规划三维审核与 enforced 执行', () => {
  it.each(['planning-model-switch', 'planning-model-switch-failure'])('%s：一次性规划审核登记实际模型；在途旧请求成功或401后新选择均真正接手', async (scenario) => {
    const failed = scenario === 'planning-model-switch-failure'
    const provider = failed ? 'swarm-selected-mock' : 'swarm-mock'
    const run = await runRecovery(scenario, getRoutesOverlay(), 'normal', undefined, {
      config: { planningReview: { enabled: true, requireJev: false }, workflow: { mode: 'enforced' }, jev: { enabled: false } }
    })
    expect(run.status, run.error ?? run.stderr).toBe('done')
    const reviewer = run.planningReviewers![0]!
    expect(run.planningControlBefore).toMatchObject({ persistent: false, phase: 'running', actual: { route: { provider: 'swarm-mock', model: 'role-yu_shi' } } })
    expect(run.planningRunObserved).toMatchObject({ route: 'swarm-mock/role-yu_shi', routeSource: 'agent-loop-attempt', actualRoute: { provider: 'swarm-mock', model: 'role-yu_shi' } })
    expect(run.planningControlSelected).toMatchObject({ persistent: false, phase: 'running', paused: false, selectedNext: { model: 'reviewer-switched' }, actual: { route: { model: 'role-yu_shi' } } })
    expect(run.recoveryRequests.filter((request) => request.sessionId === reviewer.sessionId).map((request) => [request.provider, request.model])).toEqual([
      ['swarm-mock', 'role-yu_shi'], ...Array.from({ length: failed ? 4 : 3 }, () => [provider, 'reviewer-switched'])
    ])
    expect(reviewer.readResult).toContain('recovery fixture')
    expect(reviewer.mutationIsError).toBe(true)
    expect(run.planningStatus?.tasks[0]?.planningReview).toMatchObject({ status: 'pass_with_degradation', agent: { reviewer: { agentId: reviewer.sessionId, provider, model: 'reviewer-switched', fresh: true, readOnly: true } } })
    expect(run.planningControlAfter).toMatchObject({ persistent: false, oneShotSettled: true, reason: 'one-shot-settled', actual: { route: { model: 'reviewer-switched' }, state: 'settled' } })
  })
  it('真实 ask_user_question 成功结果经 deriveMessages 进入需求来源，新审核绑定确认且重试不增长', async () => {
    const run = await runRecovery('planning-question-reply', getRoutesOverlay(), 'normal', undefined, {
      config: { planningReview: { enabled: true, requireJev: false }, workflow: { mode: 'enforced' }, jev: { enabled: false } }
    })
    expect(run.status, run.error ?? run.stderr).toBe('done')
    expect(run.questionRequests).toBe(1)
    const transcript = run.questionTranscript!
    expect(transcript.questionCall.name).toBe('ask_user_question')
    expect(transcript.questionResult).toMatchObject({ role: 'tool', isError: false, toolCallId: transcript.questionCall.id,
      source: { kind: 'tool', callId: transcript.questionCall.id } })
    expect(run.planningReviewers).toHaveLength(2)
    const first = run.planningReviewers![0]!, second = run.planningReviewers![1]!
    expect(second.requestRevision).toBe(first.requestRevision + 1)
    expect(second.requestRefs).toHaveLength(2)
    expect(second.requestRefs?.map(ref => ref.source)).toContain(transcript.questionResult.id)
    const confirmation = second.requestRefs?.find(ref => ref.source === transcript.questionResult.id)?.text
    expect(confirmation).toContain('是否允许在隔离候选中实施最小修复')
    expect(confirmation).toContain('允许隔离修复')
    expect(confirmation).toContain('未选选项不是授权')
    expect(second.snapshotDigest).not.toBe(first.snapshotDigest)
    expect(JSON.parse(run.results[3]!.text)).toMatchObject({ cached: true, requestRevision: second.requestRevision })
  })

  it.each(['planning-enforced', 'planning-phase-pass', 'planning-phase-low'])('%s：真实宿主自动规划、阶段验收与低分收敛（Jev 为本机固定响应）', async (scenario) => {
    const requests: Array<{ model: string; state: Record<string, unknown>; questions: Record<string, { type: string; criteria?: unknown[] | Record<string, unknown> }> }> = []
    const server = createServer(async (request, response) => {
      try {
        const chunks: Buffer[] = []
        for await (const chunk of request) chunks.push(Buffer.from(chunk))
        const body = JSON.parse(Buffer.concat(chunks).toString('utf8'))
        requests.push(body)
        const answers = Object.fromEntries(Object.entries(body.questions).map(([id, value]) => {
          const question = value as { type: string; criteria?: unknown[] | Record<string, unknown> }
          return [id, question.type === 'score' ? { type: 'score', score: Math.max(0, (question.criteria as unknown[])?.length - 1), confidence: 0.99 }
            : question.type === 'choice' ? { type: 'choice', choice: Object.keys(question.criteria ?? {})[0], confidence: 0.99 }
              : { type: 'noul', noul: scenario === 'planning-phase-low' && id === 'requirement_coverage' ? 0.35 : scenario === 'planning-phase-low' && id === 'execution_boundaries' ? 0.79 : 0.99 }]
        }))
        response.writeHead(200, { 'content-type': 'application/json' })
        response.end(JSON.stringify({ model: 'jev-host-planning-mock', answers, usage: { input_tokens: 20, output_tokens: 8 } }))
      } catch (error) {
        response.writeHead(500, { 'content-type': 'application/json' }); response.end(JSON.stringify({ error: String(error) }))
      }
    })
    await new Promise<void>((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve) })
    const port = (server.address() as AddressInfo).port
    try {
      const run = await runRecovery(scenario, getRoutesOverlay(), 'normal', undefined, {
        config: { workflow: { mode: 'enforced' }, planningReview: { enabled: true, requireJev: true, reviewAbove: 0.8, timeoutMs: 20000 },
          jev: { enabled: true, apiKeyEnv: 'SWARM_PLANNING_JEV_KEY', baseUrl: `http://127.0.0.1:${port}`, maxRetries: 0 } },
        env: { SWARM_PLANNING_JEV_KEY: 'planning-fixture-key' }
      })
      expect(run.status, run.error ?? run.stderr).toBe('done')
      expect(run.planningReviewers).toHaveLength(1)
      const reviewer = run.planningReviewers![0]!
      expect(reviewer.model).toBe('role-yu_shi')
      expect(reviewer.outputSchemaProperties).toEqual(expect.arrayContaining(['snapshotDigest', 'goalReview', 'designReview', 'mermaidReview', 'requirementCoverage']))
      expect(reviewer.tools).toContain('structured_output')
      expect(reviewer.tools).toContain('swarm_context_read')
      expect(reviewer.tools).not.toEqual(expect.arrayContaining(['write']))
      const governanceTools = ['swarm_task_card', 'swarm_delegate', 'swarm_accept', 'swarm_review_plan', 'swarm_status']
      expect(reviewer.tools.some((name) => ['write', 'edit', 'bash', 'pwsh', ...governanceTools].includes(name) || name.startsWith('jev_') || name.startsWith('swarm_message_'))).toBe(false)
      expect(reviewer.seesAgentResult || reviewer.seesJevResult).toBe(false)
      expect(reviewer.readResult).toContain('recovery fixture')
      expect(reviewer.missingContextIsError, reviewer.missingContextResult).toBe(false)
      const missingPlanningContext = JSON.parse(reviewer.missingContextResult!)
      expect(missingPlanningContext).toMatchObject({ ok: false, code: 'CONTEXT_REFERENCE_UNAVAILABLE',
        mayUseForImplementation: false, recovery: 'relist_current_materials' })
      expect(missingPlanningContext).not.toHaveProperty('text')
      expect(missingPlanningContext.materials.length).toBeGreaterThan(0)
      expect(missingPlanningContext.materials.every((item: { kind: string }) => !['author-reasoning', 'history', 'experience'].includes(item.kind))).toBe(true)
      expect(reviewer.mutationIsError, reviewer.mutationResult).toBe(true)
      expect(existsSync(join(run.workspace, 'planner-should-not-write.txt'))).toBe(false)
      expect(reviewer.mermaid).toContain('flowchart TD')
      if (getTestedVersion() === '0.2.1-rc.2') expect(run.hostApis).toEqual({ start: false, startActivation: true })
      if (scenario === 'planning-enforced') {
        expect(reviewer.requestText).toBe('分析 README.md 并提交有证据的结论')
        expect(run.results[1]?.isError).toBe(true)
        expect(run.results[2]?.text).toContain('blocked')
        expect(run.results[3]?.text).toContain('completed')
        expect(run.results[3]?.text).toContain('README.md')
        expect(run.results[4]?.text).toContain('accepted')
      } else {
        expect(reviewer.requestText).toContain('完整系统')
        expect(reviewer.planningScope).toMatchObject({ kind: 'phase', deferred: ['后续实施完整系统'] })
      }
      if (scenario === 'planning-phase-low') {
        expect(run.children).toEqual([])
        const committed = run.committedToolResults!
        for (const result of committed.slice(1, 4)) {
          expect(JSON.parse(result.text)).toMatchObject({ cached: true, status: 'review_required', diagnostics: [
            { dimension: 'requirement_coverage', probability: 0.35, threshold: 0.8 },
            { dimension: 'execution_boundaries', probability: 0.79, threshold: 0.8 }
          ] })
        }
        // The actual Host now stops the repeated-review trajectory before the
        // fixture can attempt delegation or ask a model to accept the task.
        expect(committed).toHaveLength(4)
        expect(run.runtimeStatus?.tasks[0]?.runtimeGuard.control).toMatchObject({ status: 'stalled', reason: expect.stringContaining('LOOP_DETECTED') })
        expect(run.planningStatus?.tasks[0]?.planningReview).toMatchObject({ status: 'review_required' })
        expect(run.planningStatus?.tasks[0]?.acceptance).toBeNull()
      } else {
        expect(run.results[0]?.text).toContain('pass')
        const expert = run.children.find((child) => child.role === 'mou_ding')
        expect(expert?.tools).toEqual(expect.arrayContaining(['swarm_context_read', 'swarm_project_files']))
        expect(expert?.tools.some((name) => governanceTools.includes(name))).toBe(false)
        // 旧 start 按角色能力过滤父工具，谋定原本允许 Jev；独立 preset
        // 的新 startActivation 路径只挂任务绑定工具，不新增全局 Jev。
        if (run.hostApis?.start === false && run.hostApis.startActivation) {
          expect(expert?.tools.some((name) => name.startsWith('jev_'))).toBe(false)
        } else {
          expect(run.hostApis?.start).toBe(true)
          expect(expert?.tools).toEqual(expect.arrayContaining(['jev_ask', 'jev_check', 'jev_classify', 'jev_health', 'jev_match', 'jev_score', 'jev_screen']))
        }
        const context = run.analysisContext!
        expect(context, run.error ?? run.stderr).toBeDefined()
        expect(context.taskId).toBe(run.taskId)
        expect(context.indexIsError, context.indexResult).toBe(false)
        expect(JSON.parse(context.indexResult)).toMatchObject({ task_id: run.taskId,
          materials: expect.arrayContaining([expect.objectContaining({ kind: 'contract', ref: expect.any(String), digest: expect.any(String) })]) })
        expect(context.readIsError, context.readResult).toBe(false)
        expect(JSON.parse(context.readResult).text).toContain('README.md')
        expect(context.missingIsError, context.missingResult).toBe(false)
        const missingExecutionContext = JSON.parse(context.missingResult)
        expect(missingExecutionContext).toMatchObject({ ok: false, code: 'CONTEXT_REFERENCE_UNAVAILABLE',
          mayUseForImplementation: false, recovery: 'relist_current_materials',
          materials: JSON.parse(context.indexResult).materials })
        expect(missingExecutionContext).not.toHaveProperty('text')
        expect(context.crossTaskId).not.toBe(run.taskId)
        expect(context.crossTaskIsError, context.crossTaskResult).toBe(true)
        // 校验任务绑定拒绝，不把“不存在任务”或“工具缺失”冒充权限隔离。
        expect(context.crossTaskResult).toContain('专家不能访问其他任务')
        expect(run.analysisReadResult).toContain('recovery fixture')
        expect(run.ledgerEvents.find((event) => event.type === 'workflow/review')?.data).toMatchObject({ status: 'pass' })
        expect(run.planningStatus?.tasks[0]?.planningReview).toMatchObject({ status: 'pass', goalReview: { verdict: 'pass' }, designReview: { verdict: 'pass' },
          mermaidReview: { parseVerdict: 'pass', projectionVerdict: 'pass', parserVersion: MERMAID_PARSER_VERSION } })
        if (scenario === 'planning-phase-pass') {
          expect(run.results[1]?.text).toContain('completed')
          expect(run.results[2]?.text).toContain('accepted')
          expect(run.results[2]?.text).toContain('整体目标尚未完成')
          expect(run.planningStatus?.tasks[0]?.acceptance?.status).toBe('accepted')
        }
      }
      const planning = requests.filter((request) => Object.hasOwn(request.questions, 'goal_alignment'))
      expect(planning).toHaveLength(1)
      expect(Object.keys(planning[0]!.questions)).toEqual(expect.arrayContaining(['goal_alignment', 'design_sufficiency', 'mermaid_expression']))
      expect(planning[0]!.state.snapshotDigest).toBe(reviewer.snapshotDigest)
      expect(Object.hasOwn(planning[0]!.state, 'agent')).toBe(false)
      expect(retryEvents(run)).toEqual([])
    } finally {
      server.closeAllConnections()
      await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()))
    }
  })
})
