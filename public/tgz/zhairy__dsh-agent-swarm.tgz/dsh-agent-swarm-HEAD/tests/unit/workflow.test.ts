import { createRequire } from 'node:module'
import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'
import { ValidateTaskCard, getRuleGates } from '../../src/policy.js'
import { MERMAID_PARSER_VERSION, ParseWorkflowMermaid, ReconcileWorkflow, ReconcileWorkflowState, getLenientWorkflow, UpdateWorkflowNode, ValidateMermaidProjection, ValidateWorkflow, WORKFLOW_LIMITS, getDefaultWorkflow, getMatchingNode, getReadyNodes, getTaskCardMarkdown, getWorkflowDigest, getWorkflowMermaid, intOfficialMermaidParser, intWorkflowState } from '../../src/workflow.js'

const card = (flags = {}, scope = ['src/a.ts']) => ValidateTaskCard({ title: '改任务', goal: '满足真实合同', acceptance: ['边界行为一致'], scope, flags }).card!

describe('有界任务 DAG', () => {
  it('流程重协不重置未变节点的真实颜色，只把变更节点保留为历史/阻塞标记', () => {
    const graph = getDefaultWorkflow(card({ changesCode: true }), getRuleGates(card({ changesCode: true })))
    const old = intWorkflowState(graph)
    old.nodes.implementation = { status: 'succeeded', attemptId: 'attempt-1', evidenceRefs: ['evidence-1'] }
    old.nodes.verification = { status: 'running', attemptId: 'attempt-2' }
    old.nodes.checkpoint = { status: 'succeeded', evidenceRefs: ['checkpoint-1'] }
    const unchanged = ReconcileWorkflowState(graph, old, graph, 0)
    expect(unchanged.nodes.implementation).toEqual(old.nodes.implementation)
    expect(unchanged.nodes.verification).toEqual(old.nodes.verification)
    const changed = structuredClone(graph)
    changed.nodes.find((node) => node.id === 'verification')!.outputContractVersion = '2'
    const reconciled = ReconcileWorkflowState(graph, old, changed, 0)
    expect(reconciled.nodes.implementation).toMatchObject({ status: 'skipped', reason: expect.stringContaining('不自动重放') })
    expect(reconciled.nodes.verification).toMatchObject({ status: 'blocked', attemptId: 'attempt-2' })
    expect(reconciled.nodes.checkpoint).toMatchObject({ status: 'skipped', reason: expect.stringContaining('不自动重放') })
  })

  it('低风险代码只有局部修改、真实复核、检查点与验收；只读任务不空跑命令', () => {
    const code = card({ changesCode: true })
    const graph = getDefaultWorkflow(code, getRuleGates(code))
    expect(graph.mode).toBe('quick')
    expect(graph.nodes.map((node) => node.id)).toEqual(['implementation', 'verification', 'checkpoint', 'accept'])
    expect(graph.nodes[1]?.gates).toEqual(['G_VERIFY'])
    expect(ValidateWorkflow(graph, code, getRuleGates(code)).errors).toEqual([])
    const read = card()
    expect(getDefaultWorkflow(read, []).nodes.filter((node) => node.role === 'fu_he' || node.role === 'ji_feng')).toHaveLength(0)
  })

  it('算法研算先于实现，所有有效门禁都有可产生证据的角色', () => {
    const algorithm = card({ changesCode: true, changesAlgorithm: true, numericPrecision: true }, [])
    const gates = getRuleGates(algorithm)
    const graph = getDefaultWorkflow(algorithm, gates)
    expect(graph.mode).toBe('algorithm')
    expect(graph.nodes.find((node) => node.id === 'implementation')?.dependsOn).toContain('math_research')
    expect(ValidateWorkflow(graph, algorithm, gates).errors).toEqual([])
    const bad = structuredClone(graph)
    bad.nodes.find((node) => node.id === 'implementation')!.dependsOn = ['tan_wei']
    expect(ValidateWorkflow(bad, algorithm, gates).errors.join()).toContain('必须依赖已完成研算')
  })

  it('只读默认节点明确交付真实目标，不停留在抽象需求分析或宣称已经完成', () => {
    const task = ValidateTaskCard({ title: '只读标记核对', goal: '读取 README.md 的 marker 并如实回报', acceptance: ['marker 与实际文件一致'], flags: {}, scope: ['README.md'] }).card!
    const graph = getDefaultWorkflow(task, [])
    expect(graph.nodes.map(({ label: _label, ...node }) => node)).toEqual([
      { id: 'analysis', operation: 'delegate', role: 'mou_ding', dependsOn: [], gates: [], outputContractVersion: '1' },
      { id: 'checkpoint', operation: 'checkpoint', dependsOn: ['analysis'], gates: [], outputContractVersion: '1' },
      { id: 'accept', operation: 'accept', dependsOn: ['checkpoint'], gates: [], outputContractVersion: '1' }
    ])
    expect(graph.nodes[0]!.label).toContain(task.goal)
    expect(graph.nodes[0]!.label).toContain('提交结果证据')
    expect(graph.nodes[0]!.label).toContain('任务卡验收')
    expect(intWorkflowState(graph).nodes.analysis?.status).toBe('ready')
    expect(ValidateWorkflow(graph, task, []).errors).toEqual([])
  })

  it('默认实施与验证节点明确目标和验收，同时保留门禁依赖', () => {
    const task = card({ changesCode: true })
    const graph = getDefaultWorkflow(task, getRuleGates(task))
    const implementation = graph.nodes.find(node => node.id === 'implementation')!
    const verification = graph.nodes.find(node => node.id === 'verification')!
    expect(implementation.label).toContain(`实现并交付：${task.goal}`)
    expect(verification.label).toContain(task.goal)
    expect(verification.label).toContain('A1 边界行为一致')
    expect(implementation.dependsOn).toEqual([])
    expect(verification.dependsOn).toEqual(['implementation'])
    expect(verification.gates).toEqual(['G_VERIFY'])
    expect(intWorkflowState(graph).nodes.verification?.status).toBe('pending')
  })

  it('长目标与验收标签有界且显式引用完整合同，不截断原始合同或 Unicode 代理对', () => {
    const task = { ...card({ changesCode: true }), goal: '验算📈'.repeat(100), acceptance: ['边界🧪'.repeat(100)] }
    const original = structuredClone(task)
    const graph = getDefaultWorkflow(task, getRuleGates(task))
    for (const node of graph.nodes.filter(node => ['implementation', 'verification'].includes(node.id))) {
      expect(node.label.length).toBeLessThanOrEqual(WORKFLOW_LIMITS.labelChars)
      expect(node.label.endsWith('…（完整目标与验收以任务卡为准）')).toBe(true)
      expect(node.label).not.toMatch(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u)
    }
    expect(task).toEqual(original)
    expect(ValidateWorkflow(graph, task, getRuleGates(task)).errors).toEqual([])
  })

  it('拒绝重复 ID、环、缺依赖、角色冒用、遗漏门禁与断开的验收路径', () => {
    const task = card({ changesCode: true })
    const gates = getRuleGates(task)
    const base = getDefaultWorkflow(task, gates)
    const mutate = (run: (graph: typeof base) => void) => { const graph = structuredClone(base); run(graph); return ValidateWorkflow(graph, task, gates).errors }
    expect(mutate((graph) => { graph.nodes[1]!.id = graph.nodes[0]!.id }).join()).toContain('重复')
    expect(mutate((graph) => { graph.nodes[0]!.dependsOn = ['accept'] }).join()).toContain('无环')
    expect(mutate((graph) => { graph.nodes[0]!.dependsOn = ['missing'] }).join()).toContain('不存在')
    expect(mutate((graph) => { graph.nodes[1]!.role = 'ji_feng' }).join()).toContain('不能由')
    expect(mutate((graph) => { graph.nodes[1]!.gates = [] }).join()).toContain('缺少必需门禁')
    expect(mutate((graph) => { graph.nodes[2]!.dependsOn = [] }).join()).toContain('没有通向验收')
  })

  it('天枢的流程草稿缺必需门禁或写错字段时由宿主补齐，不打回任务卡（B3-e 真实输入）', () => {
    const task = card({ changesCode: true, touchesFinancialLogic: true, securitySensitive: true, crossModuleArchitecture: true })
    const gates = getRuleGates(task)
    expect(gates.map((gate) => gate.gate)).toEqual(expect.arrayContaining(['G_VERIFY', 'G_REVIEW', 'G_MATH_VERIFY']))
    const draft = { schemaVersion: 1, mode: 'standard', nodes: [
      { id: 'implement', label: '铸剑：实现条件单创建', operation: 'delegate', role: 'zhu_jian', dependsOn: [], gates: [], outputContractVersion: '1' },
      { id: 'verify', label: '复核', operation: 'delegate', role: 'fu_he', dependsOn: ['implement'], gates: ['G_VERIFY', 'G_MATH_VERIFY'], outputContractVersion: '1', description: '模型多写的字段' },
      { id: 'positive', label: '谋定正方', operation: 'delegate', role: 'mou_ding', dependsOn: ['implement'], gates: [], outputContractVersion: '1' },
      { id: 'adversarial', label: '御史反方', operation: 'delegate', role: 'yu_shi', dependsOn: ['implement'], gates: ['G_REVIEW'], outputContractVersion: '1' },
      { id: 'checkpoint', label: '检查点', operation: 'checkpoint', dependsOn: ['verify', 'positive', 'adversarial'], gates: [], outputContractVersion: '1' },
      { id: 'accept', label: '验收', operation: 'accept', dependsOn: ['checkpoint'], gates: [], outputContractVersion: '1' }
    ] }
    expect(ValidateWorkflow(draft, task, gates).errors.join()).toContain('不能由 fu_he 产生门禁 G_MATH_VERIFY')
    const next = ReconcileWorkflow(getLenientWorkflow(draft, task, gates), task, gates)
    expect(next.errors).toEqual([])
    const math = next.definition.nodes.find((node) => node.gates.includes('G_MATH_VERIFY'))!
    expect(math).toMatchObject({ role: 'suan_heng', mathMode: 'verify' })
    expect(math.dependsOn).toContain('implement')
    expect(next.definition.nodes.find((node) => node.id === 'verify')!.gates).toEqual(['G_VERIFY'])
    expect(next.definition.nodes.find((node) => node.operation === 'checkpoint')!.dependsOn).toContain(math.id)
  })

  it('修补与门禁顺序冲突的草稿依赖时保留经由它的业务先后：实现 → 复核 → 修复，修复仍在分析与第一次实现之后', () => {
    const task = card({ changesCode: true })
    const gates = getRuleGates(task)
    const draft = { nodes: [
      { id: 'analysis', role: 'tan_wei', dependsOn: [] },
      { id: 'impl1', role: 'zhu_jian', dependsOn: ['analysis'] },
      { id: 'verify1', role: 'fu_he', dependsOn: ['impl1'], gates: ['G_VERIFY'] },
      { id: 'impl2', role: 'ji_feng', dependsOn: ['verify1'] }
    ] }
    const result = ReconcileWorkflow(getLenientWorkflow(draft, task, gates), task, gates)
    expect(result.errors).toEqual([])
    const node = (id: string) => result.definition.nodes.find((item) => item.id === id)!
    expect(node('impl2').dependsOn).toEqual(['impl1'])
    expect(node('verify1').dependsOn).toEqual(expect.arrayContaining(['impl1', 'impl2']))
    expect(getReadyNodes(result.definition, intWorkflowState(result.definition)).map((item) => item.id)).toEqual(['analysis'])
  })

  it('缺少门禁时不复用实现前的同角色节点（例如先复现问题的复核），而是补一个实现后的门禁节点；依赖验收节点的草稿也能修补', () => {
    const task = card({ changesCode: true })
    const gates = getRuleGates(task)
    const draft = { nodes: [
      { id: 'reproduce', role: 'fu_he', dependsOn: [] },
      { id: 'impl', role: 'ji_feng', dependsOn: ['reproduce'] },
      { id: 'accept', operation: 'accept', dependsOn: ['impl'] },
      { id: 'late', role: 'miao_bi', dependsOn: ['accept'] }
    ] }
    const result = ReconcileWorkflow(getLenientWorkflow(draft, task, gates), task, gates)
    expect(result.errors).toEqual([])
    const node = (id: string) => result.definition.nodes.find((item) => item.id === id)!
    expect(node('reproduce').gates).toEqual([])
    expect(node('impl').dependsOn).toEqual(['reproduce'])
    const verify = result.definition.nodes.find((item) => item.gates.includes('G_VERIFY'))!
    expect(verify.id).not.toBe('reproduce')
    expect(verify.dependsOn).toContain('impl')
    expect(node('late').dependsOn).toEqual(['impl'])
  })

  it.each([false, true])('最终汇合检查点保留合法控制顺序，不因节点展示反序而反转依赖（反序=%s）', (reverse) => {
    const task = card()
    const gates = getRuleGates(task)
    const draft = getLenientWorkflow({ nodes: [
      { id: 'analysis', role: 'tan_wei', dependsOn: [] },
      { id: 'checkpoint_a', operation: 'checkpoint', dependsOn: ['analysis'] },
      { id: 'checkpoint_b', operation: 'checkpoint', dependsOn: ['checkpoint_a'] },
      { id: 'accept', operation: 'accept', dependsOn: ['checkpoint_b'] }
    ] }, task, gates)
    if (reverse) draft.nodes.reverse()
    const original = structuredClone(draft)
    expect(ValidateWorkflow(draft, task, gates).errors).toEqual([])
    const result = ReconcileWorkflow(draft, task, gates)
    expect(result.errors).toEqual([])
    expect(result.definition.nodes.find((node) => node.id === 'checkpoint_a')?.dependsOn).toEqual(['analysis'])
    expect(result.definition.nodes.find((node) => node.id === 'checkpoint_b')?.dependsOn).toContain('checkpoint_a')
    expect(result.definition.nodes.find((node) => node.id === 'accept')?.dependsOn).toEqual(['checkpoint_b'])
    expect(getReadyNodes(result.definition, intWorkflowState(result.definition)).map((node) => node.id)).toEqual(['analysis'])
    expect(draft).toEqual(original)
    expect(ReconcileWorkflow(result.definition, task, gates)).toEqual({ definition: result.definition, changed: false, errors: [] })
  })

  it('验收移到末尾时绕过验收并保留实现祖先，文档必须等实现完成', () => {
    const task = card({ changesCode: true })
    const gates = getRuleGates(task)
    const draft = getLenientWorkflow({ nodes: [
      { id: 'impl', role: 'ji_feng', dependsOn: [] },
      { id: 'accept', operation: 'accept', dependsOn: ['impl'] },
      { id: 'document', role: 'miao_bi', dependsOn: ['accept'] }
    ] }, task, gates)
    const result = ReconcileWorkflow(draft, task, gates)
    expect(result.errors).toEqual([])
    expect(result.definition.nodes.find((node) => node.id === 'document')?.dependsOn).toEqual(['impl'])
    const state = intWorkflowState(result.definition)
    expect(getReadyNodes(result.definition, state).map((node) => node.id)).toEqual(['impl'])
    expect(getReadyNodes(result.definition, UpdateWorkflowNode(state, 'impl', 'succeeded')).map((node) => node.id)).toContain('document')
    expect(ReconcileWorkflow(result.definition, task, gates)).toEqual({ definition: result.definition, changed: false, errors: [] })
  })

  it.each([1, 2])('补验收节点的 ID 避开已有业务节点，重复修补仍幂等（占用数=%s）', (count) => {
    const task = card({ changesCode: true })
    const gates = getRuleGates(task)
    const nodes = Array.from({ length: count }, (_, index) => ({ id: `accept${'_final'.repeat(index)}`, operation: 'delegate', role: 'ji_feng', dependsOn: [] }))
    const draft = getLenientWorkflow({ nodes }, task, gates)
    const result = ReconcileWorkflow(draft, task, gates)
    expect(result.errors).toEqual([])
    expect(new Set(result.definition.nodes.map((node) => node.id)).size).toBe(result.definition.nodes.length)
    for (const node of nodes) expect(result.definition.nodes.find((item) => item.id === node.id)?.operation).toBe('delegate')
    expect(result.definition.nodes.filter((node) => node.operation === 'accept')).toHaveLength(1)
    expect(ReconcileWorkflow(result.definition, task, gates)).toEqual({ definition: result.definition, changed: false, errors: [] })
  })

  it('宽松读取：算衡节点按门禁推断模式、省略字段补齐、没有业务节点时退回默认流程', () => {
    const task = card({ changesCode: true, numericPrecision: true })
    const gates = getRuleGates(task)
    const lenient = getLenientWorkflow({ nodes: [{ id: 'build', role: 'ji_feng' }, { id: 'math', role: 'suan_heng', gates: ['G_MATH_VERIFY'], dependsOn: ['build'] }] }, task, gates)
    expect(lenient.nodes.find((node) => node.id === 'math')).toMatchObject({ mathMode: 'verify', gates: ['G_MATH_VERIFY'], outputContractVersion: '1' })
    const next = ReconcileWorkflow(lenient, task, gates)
    expect(next.errors).toEqual([])
    expect(next.definition.nodes.filter((node) => node.operation === 'accept')).toHaveLength(1)
    expect(getLenientWorkflow({ nodes: [] }, task, gates)).toEqual(getDefaultWorkflow(task, gates))
    expect(ReconcileWorkflow(getLenientWorkflow({ nodes: [{ id: 'x', role: '铸剑' }] }, task, gates), task, gates).errors.join()).toContain('zhu_jian')
  })

  it('新增门禁补入图并改变摘要，保留原实现 ID', () => {
    const task = card({ changesCode: true })
    const initial = getDefaultWorkflow(task, getRuleGates(task))
    const risk = card({ changesCode: true, crossModuleArchitecture: true })
    const next = ReconcileWorkflow(initial, risk, getRuleGates(risk))
    expect(next.errors).toEqual([])
    expect(next.changed).toBe(true)
    expect(next.definition.nodes.some((node) => node.id === 'implementation')).toBe(true)
    expect(next.definition.nodes.find((node) => node.gates.includes('G_REVIEW'))?.dependsOn).toContain('implementation')
    expect(getWorkflowDigest(next.definition)).not.toBe(getWorkflowDigest(initial))
  })

  it('门禁重整保留被后续业务节点依赖的中间检查点', () => {
    const task = card({ changesCode: true })
    const graph = getDefaultWorkflow(task, getRuleGates(task))
    graph.nodes.unshift({ id: 'first_check', label: '先核对范围', operation: 'checkpoint', dependsOn: [], gates: [], outputContractVersion: '1' })
    graph.nodes.find((node) => node.id === 'implementation')!.dependsOn = ['first_check']
    const next = ReconcileWorkflow(graph, task, getRuleGates(task))
    expect(next.errors).toEqual([])
    expect(next.definition.nodes.some((node) => node.id === 'first_check')).toBe(true)
  })

  it('按依赖匹配唯一 ready 节点，拒绝过期 attempt 与终态重跑', () => {
    const task = card({ changesCode: true })
    const graph = getDefaultWorkflow(task, getRuleGates(task))
    let state = intWorkflowState(graph)
    expect(getReadyNodes(graph, state).map((node) => node.id)).toEqual(['implementation'])
    expect(getMatchingNode(graph, state, { role: 'fu_he' }).reason).toBeDefined()
    state = UpdateWorkflowNode(state, 'implementation', 'running', { attemptId: 'attempt-1' })
    expect(() => UpdateWorkflowNode(state, 'implementation', 'succeeded', { attemptId: 'attempt-old' })).toThrow('过期')
    state = UpdateWorkflowNode(state, 'implementation', 'succeeded', { attemptId: 'attempt-1' })
    expect(getMatchingNode(graph, state, { role: 'fu_he', gate: 'G_VERIFY' }).node?.id).toBe('verification')
    expect(() => UpdateWorkflowNode(state, 'implementation', 'running')).toThrow('不允许')
  })

  it('同角色多个 ready 节点时要显式选择；受控调度可确定性选择首个 ready 节点绑定进度', () => {
    const graph = getDefaultWorkflow(card(), [])
    graph.nodes.push({ id: 'second_analysis', label: '第二个同角色分析', operation: 'delegate', role: 'mou_ding', dependsOn: [], gates: [], outputContractVersion: '1' })
    const state = intWorkflowState(graph)
    expect(getMatchingNode(graph, state, { role: 'mou_ding' }).reason).toContain('多个')
    expect(getMatchingNode(graph, state, { role: 'mou_ding' }, { deterministicFallback: true }).node?.id).toBe('analysis')
  })
})

describe('Mermaid 唯一派生视图', () => {
  it('解析器版本直接来自实际安装的 Mermaid 依赖', () => {
    const require = createRequire(import.meta.url)
    const installed = (JSON.parse(readFileSync(require.resolve('mermaid/package.json'), 'utf8')) as { version: string }).version
    expect(MERMAID_PARSER_VERSION).toBe(installed)
  })

  it('来自任务目标与验收的特殊字符仍按现有规范转义并可被官方 parser 解析', async () => {
    const task = { ...card({ changesCode: true }), goal: '读取 "marker" <script>\nclick bad', acceptance: ['保留 "值" & 不执行 <tag>'] }
    const graph = getDefaultWorkflow(task, getRuleGates(task))
    const source = getWorkflowMermaid(graph)
    expect(source).toContain('#34;marker#34;')
    expect(source).not.toContain('<script>')
    expect(source).not.toContain('<tag>')
    expect(source.split('\n').some(line => line.trimStart().startsWith('click'))).toBe(false)
    expect(await ParseWorkflowMermaid(graph, source)).toMatchObject({ parseVerdict: 'pass', projectionVerdict: 'pass' })
  }, 20000)
  it('可见任务说明包括合同字段、同源图和不限预算', () => {
    const task = card({ changesCode: true })
    const graph = getDefaultWorkflow(task, getRuleGates(task))
    const markdown = getTaskCardMarkdown(task, graph, { taskId: 'T1', delegationLimit: 0 })
    expect(markdown).toContain('A1：边界行为一致')
    expect(markdown).toContain('src/a.ts')
    expect(markdown).toContain('性能预算：待测')
    expect(markdown).toContain('委派预算：不限')
    expect(markdown).toContain(getWorkflowMermaid(graph))
    expect(markdown).not.toContain('最多 0')
  })
  it('节点/依赖的展示重排不改变语义摘要与生成源码', () => {
    const task = card({ changesCode: true, crossModuleArchitecture: true })
    const graph = getDefaultWorkflow(task, getRuleGates(task))
    const reordered = structuredClone(graph)
    reordered.nodes.reverse()
    for (const node of reordered.nodes) node.dependsOn.reverse()
    expect(getWorkflowDigest(reordered)).toBe(getWorkflowDigest(graph))
    expect(getWorkflowMermaid(reordered)).toBe(getWorkflowMermaid(graph))
  })
  it('稳定生成，标签不能注入指令；合法但反向的源码也拒绝', async () => {
    const task = card()
    const graph = getDefaultWorkflow(task, [])
    graph.nodes[0]!.label = '引号"\nclick a "https://bad" <script>'
    const source = getWorkflowMermaid(graph)
    expect(source).toContain('#34;')
    expect(source).not.toContain('<script>')
    expect(source.split('\n').filter((line) => line.trim().startsWith('click'))).toHaveLength(0)
    expect(ValidateMermaidProjection(graph, source.replace('n_analysis --> n_checkpoint', 'n_checkpoint --> n_analysis'))).not.toEqual([])
    const parsed = await ParseWorkflowMermaid(graph, source, async () => ({ version: 'test-parser', ok: true }))
    expect(parsed.projectionVerdict).toBe('pass')
  })

  it('实际官方 parser 解析生成的中文流程，并拒绝未闭合括号', async () => {
    const task = card({ changesCode: true, changesAlgorithm: true, numericPrecision: true })
    const graph = getDefaultWorkflow(task, getRuleGates(task))
    const parser = intOfficialMermaidParser()
    const good = await ParseWorkflowMermaid(graph, undefined, parser)
    expect(good.parseVerdict).toBe('pass')
    expect(good.parserVersion).toBe(MERMAID_PARSER_VERSION)
    const bad = await parser('flowchart TD\n A["未闭合')
    expect(bad.ok).toBe(false)
  }, 20000)
})

describe('流程草稿修补的不变量（随机化性质检验）', () => {
  const random = (seed: number) => () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648 }
  const roles = ['mou_ding', 'shu_ji', 'suan_heng', 'tan_wei', 'zhu_jian', 'ji_feng', 'xing_zhou', 'yu_shi', 'fu_he', 'miao_bi'] as const
  const gateIds = ['G_VERIFY', 'G_REVIEW', 'G_MATH_RESEARCH', 'G_MATH_VERIFY', 'G_DIFF_TEST', 'G_BENCH', 'G_VISION'] as const
  const flagKeys = ['changesCode', 'changesAlgorithm', 'touchesFinancialLogic', 'timeSeriesOrBacktest', 'stateMachine', 'numericPrecision', 'sharedStateConcurrency', 'crossModuleArchitecture', 'securitySensitive'] as const
  const ancestors = (nodes: Array<{ id: string; dependsOn: string[] }>, id: string): Set<string> => {
    const index = new Map(nodes.map((node) => [node.id, node])); const seen = new Set<string>()
    const visit = (key: string) => { for (const dep of index.get(key)?.dependsOn ?? []) if (!seen.has(dep)) { seen.add(dep); visit(dep) } }
    visit(id); return seen
  }

  it('任意草稿：修补后要么因结构错误拒绝，要么包含全部必需门禁、无环、唯一验收、验证门禁晚于全部实现', () => {
    const next = random(42)
    let accepted = 0
    for (let trial = 0; trial < 400; trial++) {
      const flags = Object.fromEntries(flagKeys.map((key) => [key, next() < 0.35]))
      const task = card(flags, next() < 0.5 ? ['src/a.ts'] : [])
      const gates = getRuleGates(task)
      const count = Math.floor(next() * 6)
      const nodes = Array.from({ length: count }, (_, index) => ({
        id: `n${index}`, role: roles[Math.floor(next() * roles.length)],
        ...(next() < 0.3 ? { mode: next() < 0.5 ? 'verify' : 'research' } : {}),
        dependsOn: index === 0 || next() < 0.4 ? [] : [`n${Math.floor(next() * index)}`],
        gates: gateIds.filter(() => next() < 0.15),
        ...(next() < 0.2 ? { description: '多余字段' } : {})
      }))
      const draft = getLenientWorkflow({ nodes }, task, gates)
      const result = ReconcileWorkflow(draft, task, gates)
      if (result.errors.length > 0) continue
      accepted += 1
      const graph = result.definition
      for (const gate of gates) expect(graph.nodes.some((node) => node.gates.includes(gate.gate))).toBe(true)
      expect(graph.nodes.filter((node) => node.operation === 'accept')).toHaveLength(1)
      for (const node of graph.nodes) expect(ancestors(graph.nodes, node.id).has(node.id)).toBe(false)
      const edits = graph.nodes.filter((node) => node.role === 'zhu_jian' || node.role === 'ji_feng').map((node) => node.id)
      for (const node of graph.nodes.filter((item) => item.gates.some((gate) => ['G_VERIFY', 'G_REVIEW', 'G_MATH_VERIFY', 'G_DIFF_TEST', 'G_BENCH'].includes(gate)))) {
        for (const edit of edits) expect(ancestors(graph.nodes, node.id).has(edit)).toBe(true)
      }
      expect(ValidateWorkflow(graph, task, gates).errors).toEqual([])
      expect(ReconcileWorkflow(graph, task, gates)).toEqual({ definition: graph, changed: false, errors: [] })
      // 修补只去掉与门禁顺序冲突的先后：实现在草稿里的其余祖先仍是祖先；改算法时研算的非实现、非门禁祖先也保留
      const postEdit = new Set(graph.nodes.filter((item) => item.gates.some((gate) => ['G_VERIFY', 'G_REVIEW', 'G_MATH_VERIFY', 'G_DIFF_TEST', 'G_BENCH'].includes(gate))).map((item) => item.id))
      for (const edit of edits) for (const id of ancestors(draft.nodes, edit)) if (!postEdit.has(id)) expect(ancestors(graph.nodes, edit).has(id)).toBe(true)
      if (task.flags.changesAlgorithm) for (const node of graph.nodes.filter((item) => item.gates.includes('G_MATH_RESEARCH'))) {
        for (const id of ancestors(draft.nodes, node.id)) if (!postEdit.has(id) && !edits.includes(id)) expect(ancestors(graph.nodes, node.id).has(id)).toBe(true)
      }
    }
    // 草稿只依赖前序节点：与门禁顺序冲突的依赖由修补消解，全部应被接受
    expect(accepted).toBe(400)
  })

  it('无门禁冲突的含验收与检查点 DAG 保留所有非验收祖先，重复修补不再改图', () => {
    const next = random(20261021)
    const task = card()
    const gates = getRuleGates(task)
    for (let trial = 0; trial < 100; trial++) {
      const count = 3 + Math.floor(next() * 6)
      const acceptAt = 1 + Math.floor(next() * (count - 1))
      const nodes = Array.from({ length: count }, (_, index) => ({
        id: `n${index}`, operation: index === acceptAt ? 'accept' : index > 0 && next() < 0.5 ? 'checkpoint' : 'delegate',
        role: 'tan_wei', dependsOn: Array.from({ length: index }, (_, parent) => `n${parent}`).filter(() => next() < 0.4)
      }))
      const draft = getLenientWorkflow({ nodes }, task, gates)
      const original = structuredClone(draft)
      const result = ReconcileWorkflow(draft, task, gates)
      expect(result.errors).toEqual([])
      for (const node of draft.nodes.filter((item) => item.operation !== 'accept')) {
        const remaining = ancestors(result.definition.nodes, node.id)
        for (const ancestor of ancestors(draft.nodes, node.id)) if (ancestor !== `n${acceptAt}`) expect(remaining.has(ancestor)).toBe(true)
      }
      expect(draft).toEqual(original)
      expect(ReconcileWorkflow(result.definition, task, gates)).toEqual({ definition: result.definition, changed: false, errors: [] })
    }
  })

  it('任意含检查点与验收节点、依赖任意前序节点（含验收）的草稿：除多个验收节点外全部被接受', () => {
    const next = random(77)
    let accepted = 0
    for (let trial = 0; trial < 400; trial++) {
      const flags = Object.fromEntries(flagKeys.map((key) => [key, next() < 0.35]))
      const task = card(flags)
      const gates = getRuleGates(task)
      const count = 1 + Math.floor(next() * 6)
      const nodes = Array.from({ length: count }, (_, index) => {
        const operation = index > 0 && next() < 0.2 ? (next() < 0.5 ? 'accept' : 'checkpoint') : 'delegate'
        return { id: `n${index}`, operation, ...(operation === 'delegate' ? { role: roles[Math.floor(next() * roles.length)] } : {}),
          dependsOn: index === 0 ? [] : [...new Set(Array.from({ length: Math.floor(next() * 3) }, () => `n${Math.floor(next() * index)}`))] }
      })
      const result = ReconcileWorkflow(getLenientWorkflow({ nodes }, task, gates), task, gates)
      const accepts = nodes.filter((node) => node.operation === 'accept').length
      if (accepts > 1) { expect(result.errors.join()).toContain('唯一验收节点'); continue }
      expect(result.errors).toEqual([])
      accepted += 1
    }
    expect(accepted).toBeGreaterThan(300)
  })
})
