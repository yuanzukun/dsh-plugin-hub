import type { LlmFailureLike, LlmLike } from './host-contract.js'
import type { RoleId, SuanHengMode } from './role-registry.js'
import { getErrorText } from './util/errors.js'
import { normalizeRouteFailure, getRouteFailure, getRouteResourcePolicy, getWireReasoningEffort, type RouteResourcePolicy } from './provider-policy.js'

export const PROVIDER_QWEN = 'qwen-token-plan-cn'
export const PROVIDER_GO = 'opencode-go'
export const PROVIDER_DSH_GO = 'dsh-opencode-go'
export const PROVIDER_OPENCODE = 'opencode'
export const PROVIDER_DS = 'deepseek-official'
/** Subscription providers exposed by dsh-plugin-subscriptions. */
export const PROVIDER_CODEX = 'codex'
export const PROVIDER_CLAUDE = 'claude'
export const PROVIDER_ANTIGRAVITY = 'antigravity'
export const PROVIDER_GROK = 'grok'
export const PROVIDER_COPILOT = 'copilot'
export const PROVIDER_JEV = 'jev'

/** 一条模型路由 */
export interface RouteInfo {
  provider: string
  model: string
  reasoningEffort?: string
  policy?: RouteResourcePolicy
}

/** 路由表的键：算衡按模式拆成两条 */
export type RouteKey = Exclude<RoleId, 'suan_heng'> | 'suan_heng:research' | 'suan_heng:verify'
export type EscalationKind = 'codex' | 'claude'
export type ModelFamily = 'deepseek' | 'qwen' | 'kimi' | 'glm' | 'minimax' | 'mimo' | 'gpt' | 'gemini' | 'grok' | 'claude' | 'hunyuan' | 'longcat' | 'muse' | 'other'

type CatalogInfo = Readonly<Record<string, { vision: boolean }>>

/** pi-ai 0.87.1 内置的 qwen-token-plan-cn 目录（DSH 0.1.7 自带 0.85.1，本机已替换为 0.87.1） */
export const QWEN_TOKEN_PLAN_MODELS: CatalogInfo = {
  'MiniMax-M2.5': { vision: false },
  'deepseek-v3.2': { vision: false },
  'deepseek-v4-flash': { vision: false },
  'deepseek-v4-flash-0731': { vision: false },
  'deepseek-v4-pro': { vision: false },
  'deepseek-v4-pro-0813': { vision: false },
  'deepseek-v4.1-flash': { vision: true },
  'glm-5': { vision: false },
  'glm-5.1': { vision: false },
  'glm-5.2': { vision: false },
  'glm-5.3': { vision: false },
  'kimi-k2.5': { vision: true },
  'kimi-k2.6': { vision: true },
  'kimi-k2.7-code': { vision: true },
  'qwen3.6-flash': { vision: true },
  'qwen3.6-plus': { vision: true },
  'qwen3.7-max': { vision: false },
  'qwen3.7-plus': { vision: true },
  'qwen3.8-flash': { vision: true },
  'qwen3.8-max': { vision: true }
}

/** pi-ai 0.87.1 内置的 opencode-go 目录 */
export const OPENCODE_GO_MODELS: CatalogInfo = {
  'minimax-m3': { vision: true },
  'minimax-m3.1-flash': { vision: true },
  'qwen3.8-flash': { vision: true },
  'deepseek-v4-flash': { vision: false },
  'deepseek-v4-flash-vision-exp': { vision: true },
  'deepseek-v4-pro': { vision: false },
  'deepseek-v4.1-flash': { vision: true },
  'glm-5.1': { vision: false },
  'glm-5.2': { vision: false },
  'glm-5.3': { vision: false },
  'glm-5.3-flash': { vision: true },
  'hy3': { vision: false },
  'hy4-preview': { vision: false },
  'kimi-k2.6': { vision: true },
  'kimi-k2.7-code': { vision: true },
  'kimi-k3': { vision: true },
  'kimi-k3.1-pro': { vision: true },
  'longcat-2.0': { vision: false },
  'mimo-v2.5': { vision: true },
  'mimo-v2.5-pro': { vision: false },
  'mimo-v2.6-flash': { vision: true },
  'mimo-v2.6-pro': { vision: false },
  'minimax-m2.7': { vision: false },
  'omen-alpha': { vision: true },
  'qwen3.6-plus': { vision: true },
  'qwen3.7-max': { vision: false },
  'qwen3.7-plus': { vision: true },
  'qwen3.8-max': { vision: true },
  'gpt-5.6-luna': { vision: true },
  'grok-4.6': { vision: true },
  'grok-4.7': { vision: true },
  'muse-spark-1.2-contributor': { vision: true },
  'muse-spark-1.3-contributor': { vision: true }
}

/** DSH 0.1.7 原生 DeepSeek 适配器目录（deepseek-flash 即 DeepSeek V4.1 Flash） */
export const DEEPSEEK_OFFICIAL_MODELS: CatalogInfo = {
  'deepseek-flash': { vision: true },
  'deepseek-v4-pro': { vision: false }
}

/** Fallback capabilities for Antigravity models; live host metadata remains authoritative. */
export const ANTIGRAVITY_MODELS: CatalogInfo = {
  'gemini-4-argon-low': { vision: true },
  'gemini-4-argon-medium': { vision: true },
  'gemini-4-argon-high': { vision: true },
  'gemini-3.8-flash-low': { vision: true },
  'gemini-3.8-flash-medium': { vision: true },
  'gemini-3.8-flash-high': { vision: true },
  'gemini-3.8-flash-tiered': { vision: true },
  'gemini-3-flash': { vision: true },
  'gemini-3.1-flash-image': { vision: true },
  'gemini-2.5-flash': { vision: true },
  'gemini-2.5-flash-lite': { vision: true },
  'gemini-2.5-flash-thinking': { vision: true },
  'gemini-2.5-pro': { vision: true },
  'claude-opus-5-5-low': { vision: true },
  'claude-opus-5-5-high': { vision: true },
  'claude-sonnet-5-5-low': { vision: true },
  'claude-sonnet-5-5-medium': { vision: true },
  'claude-sonnet-5-5-high': { vision: true },
  'gpt-oss-120b-medium': { vision: true }
}

const q = (model: string, reasoningEffort?: string): RouteInfo => ({ provider: PROVIDER_QWEN, model, ...(reasoningEffort === undefined ? {} : { reasoningEffort }) })
const g = (model: string, reasoningEffort?: string): RouteInfo => ({ provider: PROVIDER_GO, model, ...(reasoningEffort === undefined ? {} : { reasoningEffort }) })
const d = (model: string, reasoningEffort?: string): RouteInfo => ({ provider: PROVIDER_DS, model, ...(reasoningEffort === undefined ? {} : { reasoningEffort }) })
const o = (model: string, reasoningEffort?: string): RouteInfo => ({ provider: PROVIDER_CODEX, model, ...(reasoningEffort === undefined ? {} : { reasoningEffort }) })
const c = (model: string, reasoningEffort?: string): RouteInfo => ({ provider: PROVIDER_CLAUDE, model, ...(reasoningEffort === undefined ? {} : { reasoningEffort }) })

/**
 * 常用模型的路由。同一模型先消耗订阅额度：qwen-token-plan-cn → opencode-go，
 * DeepSeek 官方 API 按量计费，只作兜底；其余额与上游限速仍可能导致失败。
 */
/** 各模型的路由；推理等级按角色需要传入（每个模型支持的档位见 MODEL_REASONING_EFFORTS） */
const astra = (effort: string): RouteInfo => o('gpt-6-astra', effort)
const sol = (effort: string): RouteInfo => o('gpt-6-sol', effort)
const opus = (effort: string): RouteInfo => c('claude-opus-5-5', effort)
const sonnet = (effort: string): RouteInfo => c('claude-sonnet-5', effort)
const dsFlash = (effort: string): RouteInfo => q('deepseek-v4.1-flash', effort)
const qwenMax = (effort: string): RouteInfo => q('qwen3.8-max', effort)
const qwenFlash = (effort: string): RouteInfo => q('qwen3.8-flash', effort)
const mimoPro = (effort: string): RouteInfo => g('mimo-v2.6-pro', effort)
const mimoFlash = (effort: string): RouteInfo => g('mimo-v2.6-flash', effort)
const minimax = (effort: string): RouteInfo => g('minimax-m3', effort)
/**
 * 兜底层：DeepSeek 官方 API（deepseek-flash 即 V4.1 Flash）。
 * V4.1 Flash 的评测不低于 V4 Pro（含 0813），价格约为其 1/4，且支持图片输入，所以默认链不再使用 V4 Pro；
 * V4 Pro 仍保留在目录里，可在设置页手动选用。
 */
const lastFlash = (effort: string): RouteInfo => d('deepseek-flash', effort)

/**
 * DSH 模型目录为各模型声明的推理档位（2026-09-24 从 Web 端实时目录读取）。
 * 路由里写了目录不支持的档位，请求会被拒绝、整层被跳过，单元测试据此逐条检查默认配置。
 */
export const MODEL_REASONING_EFFORTS: Readonly<Record<string, readonly string[]>> = {
  [`${PROVIDER_CODEX}/gpt-6-astra`]: ['low', 'medium', 'high', 'xhigh', 'max', 'ultra'],
  [`${PROVIDER_CODEX}/gpt-6-sol`]: ['low', 'medium', 'high', 'xhigh', 'max', 'ultra'],
  [`${PROVIDER_CLAUDE}/claude-opus-5-5`]: ['low', 'medium', 'high', 'xhigh', 'max'],
  [`${PROVIDER_CLAUDE}/claude-sonnet-5`]: ['low', 'medium', 'high', 'xhigh', 'max'],
  [`${PROVIDER_QWEN}/deepseek-v4-pro`]: ['high', 'max'],
  [`${PROVIDER_QWEN}/deepseek-v4.1-flash`]: ['low', 'high', 'max'],
  [`${PROVIDER_QWEN}/qwen3.8-max`]: ['low', 'medium', 'xhigh'],
  [`${PROVIDER_QWEN}/qwen3.8-flash`]: ['low', 'medium', 'xhigh'],
  [`${PROVIDER_QWEN}/glm-5.3`]: ['low', 'high', 'max'],
  [`${PROVIDER_GO}/mimo-v2.6-pro`]: ['off', 'minimal', 'low', 'medium', 'high'],
  [`${PROVIDER_GO}/mimo-v2.6-flash`]: ['off', 'minimal', 'low', 'medium', 'high'],
  [`${PROVIDER_GO}/muse-spark-1.3-contributor`]: ['minimal', 'low', 'medium', 'high', 'xhigh'],
  [`${PROVIDER_GO}/minimax-m3`]: ['off', 'minimal', 'low', 'medium', 'high'],
  [`${PROVIDER_GO}/kimi-k2.7-code`]: ['off', 'minimal', 'low', 'medium', 'high'],
  [`${PROVIDER_DS}/deepseek-v4-pro`]: ['off', 'low', 'high', 'max'],
  [`${PROVIDER_DS}/deepseek-flash`]: ['off', 'low', 'high', 'max']
}

/**
 * 默认路由链（主模型 → 备用 1 → 备用 2 → 兜底），见 docs/角色.md。
 * 前三层按「角色 → 能力 → 模型」建议配置；第四层统一是 DeepSeek 官方 API 兜底。
 * 推理等级按角色分三档：判断与验证类取该模型的高档（xhigh/max），执行类取低档保速度，
 * 资料、视觉、文案取中档；同一角色在不同模型上取各自最接近的档位。
 */
export const DEFAULT_ROUTE_CHAINS: Readonly<Record<RouteKey, readonly RouteInfo[]>> = {
  tian_shu: [sol('high'), dsFlash('high'), opus('high'), lastFlash('high')],
  mou_ding: [dsFlash('high'), sol('high'), qwenMax('xhigh'), lastFlash('high')],
  shu_ji: [opus('xhigh'), sol('xhigh'), dsFlash('max'), lastFlash('max')],
  'suan_heng:research': [astra('max'), dsFlash('max'), qwenMax('xhigh'), lastFlash('max')],
  'suan_heng:verify': [opus('max'), mimoPro('high'), qwenMax('xhigh'), lastFlash('max')],
  tan_wei: [qwenFlash('low'), mimoFlash('low'), g('muse-spark-1.3-contributor', 'low'), lastFlash('low')],
  bo_wen: [qwenMax('medium'), minimax('medium'), sol('medium'), lastFlash('high')],
  guan_xiang: [qwenMax('medium'), dsFlash('high'), minimax('medium'), lastFlash('high')],
  zhu_jian: [sonnet('high'), dsFlash('high'), g('kimi-k2.7-code', 'high'), lastFlash('high')],
  xing_zhou: [dsFlash('low'), qwenFlash('low'), mimoFlash('low'), lastFlash('low')],
  ji_feng: [dsFlash('high'), mimoFlash('medium'), qwenFlash('medium'), lastFlash('high')],
  yu_shi: [sol('xhigh'), qwenMax('xhigh'), mimoPro('high'), lastFlash('max')],
  fu_he: [qwenFlash('medium'), dsFlash('high'), mimoFlash('medium'), lastFlash('high')],
  miao_bi: [qwenMax('medium'), sonnet('medium'), sol('medium'), lastFlash('low')]
}

/** 默认原生升级通道（Codex/Claude Code 原生客户端）：只在显式要求或 nativeEscalation=auto 且高风险时使用 */
export const DEFAULT_ESCALATION: Readonly<Partial<Record<RouteKey, EscalationKind>>> = {
  mou_ding: 'codex',
  shu_ji: 'claude',
  'suan_heng:research': 'codex',
  'suan_heng:verify': 'codex',
  zhu_jian: 'claude',
  yu_shi: 'codex'
}

export const getRouteKey = (role: RoleId, mode?: SuanHengMode): RouteKey =>
  role === 'suan_heng' ? `suan_heng:${mode ?? 'research'}` : role

export const getRouteLabel = (route: RouteInfo): string => `${route.provider}/${route.model}`

/** 供应商的中文名称（聊天窗口与委派结果中显示） */
export const PROVIDER_LABELS: Readonly<Record<string, string>> = {
  [PROVIDER_CODEX]: 'ChatGPT 订阅',
  [PROVIDER_CLAUDE]: 'Claude 订阅',
  [PROVIDER_ANTIGRAVITY]: 'Google Antigravity',
  [PROVIDER_QWEN]: '阿里云百炼 Token Plan',
  [PROVIDER_GO]: 'OpenCode Go',
  [PROVIDER_DSH_GO]: 'DSH OpenCode Go',
  [PROVIDER_OPENCODE]: 'OpenCode Zen',
  [PROVIDER_DS]: 'DeepSeek 官方 API',
  [PROVIDER_GROK]: 'Grok 订阅',
  [PROVIDER_COPILOT]: 'GitHub Copilot 订阅',
  [PROVIDER_JEV]: 'Jev 判断 API'
}

/**
 * 「模型 · 供应商」的显示文本，例如 `claude-opus-5-5 · Claude 订阅（claude）`
 * @param {RouteInfo} route - 路由
 * @returns {string} 显示文本
 */
export const getRouteDisplay = (route: RouteInfo): string => {
  const label = PROVIDER_LABELS[route.provider]
  const effort = route.reasoningEffort === undefined ? '' : ` · 推理 ${route.reasoningEffort}`
  return `${route.model} · ${label === undefined ? route.provider : `${label}（${route.provider}）`}${effort}`
}

export const isSameRoute = (a: RouteInfo, b: RouteInfo): boolean => a.provider === b.provider && a.model === b.model

const FAMILY_RULES: ReadonlyArray<readonly [RegExp, ModelFamily]> = [
  [/^deepseek/, 'deepseek'],
  [/^qwen/, 'qwen'],
  [/^kimi/, 'kimi'],
  [/^glm/, 'glm'],
  [/^minimax/, 'minimax'],
  [/^mimo/, 'mimo'],
  [/^gpt|codex/, 'gpt'],
  [/^gemini/, 'gemini'],
  [/^grok/, 'grok'],
  [/claude/, 'claude'],
  [/^hy\d/, 'hunyuan'],
  [/^longcat/, 'longcat'],
  [/^muse/, 'muse']
]

/**
 * 按模型 ID 判断模型家族，用于实现者与审查者的独立性检查
 * @param {string} model - 模型 ID
 * @returns {ModelFamily} 家族
 */
export const getModelFamily = (model: string): ModelFamily => {
  const lower = model.toLowerCase()
  return FAMILY_RULES.find(([pattern]) => pattern.test(lower))?.[1] ?? 'other'
}

/** Codex / Claude 订阅的主力模型（由订阅插件实时发现，这里只作视觉能力的兜底判断） */
export const CODEX_MODELS: CatalogInfo = {
  'gpt-6-astra': { vision: true },
  'gpt-6-sol': { vision: true },
  'gpt-6-luna': { vision: true }
}
export const CLAUDE_MODELS: CatalogInfo = {
  'claude-opus-5-5': { vision: true },
  'claude-sonnet-5': { vision: true }
}

const CATALOG_BY_PROVIDER: Readonly<Record<string, CatalogInfo>> = {
  [PROVIDER_QWEN]: QWEN_TOKEN_PLAN_MODELS,
  [PROVIDER_CODEX]: CODEX_MODELS,
  [PROVIDER_CLAUDE]: CLAUDE_MODELS,
  [PROVIDER_GO]: OPENCODE_GO_MODELS,
  [PROVIDER_DSH_GO]: OPENCODE_GO_MODELS,
  [PROVIDER_ANTIGRAVITY]: ANTIGRAVITY_MODELS,
  [PROVIDER_DS]: DEEPSEEK_OFFICIAL_MODELS
}

/**
 * 按内置目录判断路由是否支持图片；未知 provider 返回 undefined
 * @param {RouteInfo} route - 路由
 * @returns {boolean | undefined} 是否支持图片
 */
export const getCatalogVision = (route: RouteInfo): boolean | undefined =>
  CATALOG_BY_PROVIDER[route.provider]?.[route.model]?.vision

export type RouteProbeResult = { ok: true; vision: boolean } | { ok: false; reason: string }
export type RouteProbe = (route: RouteInfo, signal?: AbortSignal) => Promise<RouteProbeResult>

/** 路由选择结果 */
export interface RouteSelection {
  usable: RouteInfo[]
  skipped: Array<{ route: RouteInfo; reason: string }>
  independence: 'achieved' | 'not-achieved' | 'n/a'
}

/**
 * 在链上筛出可用路由：先做可用性与视觉预检，再按独立性优先不同家族
 * @param {readonly RouteInfo[]} chain - 路由链
 * @param {{ probe: RouteProbe; requireVision?: boolean; avoidFamilies?: readonly ModelFamily[] }} options - 预检函数与约束
 * @returns {Promise<RouteSelection>} 可用路由与跳过原因
 */
export const FindUsableRoutes = async (
  chain: readonly RouteInfo[],
  options: { probe: RouteProbe; requireVision?: boolean; avoidFamilies?: readonly ModelFamily[]; signal?: AbortSignal }
): Promise<RouteSelection> => {
  const skipped: RouteSelection['skipped'] = []
  const available: RouteInfo[] = []
  // 各层预检互不依赖：并行执行，按链的顺序取结果
  const results = await Promise.all(chain.map((route) => options.probe(route, options.signal)))
  for (const [index, route] of chain.entries()) {
    const result = results[index] as RouteProbeResult
    if (!result.ok) {
      skipped.push({ route, reason: result.reason })
      continue
    }
    if (options.requireVision === true && !result.vision) {
      skipped.push({ route, reason: 'vision-unsupported' })
      continue
    }
    available.push(route)
  }
  const avoid = options.avoidFamilies ?? []
  if (avoid.length === 0 || available.length === 0) return { usable: available, skipped, independence: 'n/a' }
  const independent = available.filter((route) => !avoid.includes(getModelFamily(route.model)))
  if (independent.length === 0) return { usable: available, skipped, independence: 'not-achieved' }
  const sameFamily = available.filter((route) => !independent.includes(route)).map((route) => ({ route, reason: 'same-family' }))
  return { usable: independent, skipped: [...skipped, ...sameFamily], independence: 'achieved' }
}

export type FailureClass = 'route-fatal' | 'auth' | 'transient' | 'other'

const ROUTE_FATAL_CODES = new Set(['NO_ADAPTER', 'UNKNOWN_MODEL', 'UNKNOWN_PROVIDER', 'MISSING_CREDENTIAL', 'QUOTA', 'UNSUPPORTED_OPTION', 'IMAGE_UNSUPPORTED'])
const AUTH_CODES = new Set(['INVALID_CREDENTIAL', 'UNAUTHORIZED', 'FORBIDDEN'])
const TRANSIENT_CODES = new Set(['RATE_LIMIT', 'TIMEOUT', 'NETWORK', 'TRANSPORT', 'OVERLOADED', 'SERVER_ERROR', 'SERVER', 'EMPTY_RESPONSE'])
/** 账号未开通该模型：只影响这个模型，不能按认证失败把整个 provider 跳过 */
const UNPURCHASED_MESSAGE = /Unpurchased|Access to model denied|not eligible for (using )?(this|the) model/i

/**
 * 对模型请求失败分类，决定是否换路由
 * @param {LlmFailureLike | undefined} failure - 失败信息
 * @returns {FailureClass} 分类
 */
export const getFailureClass = (failure: LlmFailureLike | undefined): FailureClass => {
  if (failure === undefined) return 'other'
  const code = String(failure.code ?? '').toUpperCase()
  const status = failure.status ?? 0
  const normalized = normalizeRouteFailure(failure, { provider: '', model: '' })
  if (normalized.kind === 'auth_invalid') return 'auth'
  if (normalized.kind === 'context_exceeded') return 'other'
  if (normalized.kind === 'capability_mismatch') return 'route-fatal'
  if (['quota_exhausted', 'pool_exhausted', 'insufficient_balance', 'model_unavailable'].includes(normalized.kind)) return 'route-fatal'
  if (UNPURCHASED_MESSAGE.test(failure.message ?? '')) return 'route-fatal'
  if (AUTH_CODES.has(code) || status === 401 || status === 403) return 'auth'
  if (ROUTE_FATAL_CODES.has(code)) return 'route-fatal'
  if (TRANSIENT_CODES.has(code) || status === 408 || status === 429 || status >= 500) return 'transient'
  if (status === 400 || status === 404 || status === 422) return 'route-fatal'
  return 'other'
}

/** 预检结果缓存：可用结果缓存较久，失败结果很快过期，故障恢复后能及时重新启用 */
export const PROBE_OK_TTL_MS = 120_000
export const PROBE_FAIL_TTL_MS = 15_000
export const PROBE_CACHE_MAX_ENTRIES = 512
export const PROBE_PENDING_WAIT_MS = 30_000

/** Cordis creates a fresh caller-context proxy per get(); identity alone uses its public original symbol. */
const getMetadataIdentity = (llm: LlmLike | undefined): object | undefined => {
  if (llm === undefined) return undefined
  const original: unknown = Reflect.get(llm, Symbol.for('cordis.original'))
  return original !== null && (typeof original === 'object' || typeof original === 'function') ? original : llm
}

type RouteFailureObserver = (route: RouteInfo, failure: LlmFailureLike) => void | Promise<void>
/** One service/health registry observes each shared metadata failure once, including durable rejection. */
export const createRouteFailureObserver = (observer: RouteFailureObserver): RouteFailureObserver => {
  const observations = new WeakMap<LlmFailureLike, Promise<void>>()
  return (route, failure) => {
    let observation = observations.get(failure)
    if (observation === undefined) {
      observation = Promise.resolve().then(() => observer(route, failure))
      observations.set(failure, observation)
    }
    return observation
  }
}

type RouteMetadataResult = RouteProbeResult & { failure?: LlmFailureLike }
export interface RouteMetadataCache {
  /** Metadata only. Callers must check their own current health/admission on every use. */
  probe: (llm: LlmLike, route: RouteInfo) => Promise<RouteMetadataResult>
}
const probeKey = (route: RouteInfo): string => {
  const resource = getRouteResourcePolicy(route)
  return JSON.stringify([route.provider, route.model, getWireReasoningEffort(route) ?? null,
    resource.accessMode ?? null, resource.quotaScope ?? null, resource.quotaDomainId ?? null, resource.poolId ?? null,
    ...(['generation', 'tools', 'vision', 'structuredOutput'] as const).map((capability) => resource.capabilities?.[capability] ?? null)])
}
const cancelledMetadata = (error: unknown): boolean => {
  const failure = getRouteFailure(error)
  return (error instanceof Error && error.name === 'AbortError')
    || ['ABORT_ERR', 'ABORTED', 'CANCELLED', 'CANCELED'].includes(String(failure.code ?? '').toUpperCase())
}

/** Share successful metadata and in-flight lookups, never owner permissions or failure isolation. */
export const createRouteMetadataCache = (options: { now?: () => number; maxEntries?: number; pendingWaitMs?: number } = {}): RouteMetadataCache => {
  const now = options.now ?? Date.now
  const maximum = options.maxEntries ?? PROBE_CACHE_MAX_ENTRIES
  const pendingWaitMs = options.pendingWaitMs ?? PROBE_PENDING_WAIT_MS
  if (!Number.isSafeInteger(maximum) || maximum < 1 || maximum > 4096) throw new Error('Invalid metadata cache capacity')
  if (!Number.isSafeInteger(pendingWaitMs) || pendingWaitMs < 1 || pendingWaitMs > PROBE_PENDING_WAIT_MS) throw new Error('Invalid metadata wait bound')
  type PendingEntry = { pending: Promise<RouteMetadataResult>; timedOut: boolean }
  type Entry = { at: number; result: RouteMetadataResult } | PendingEntry
  const entries = new Map<string, Entry>()
  let owner: object | undefined
  const resolveMetadata = async (llm: LlmLike, route: RouteInfo): Promise<RouteMetadataResult> => {
    try {
      const resource = getRouteResourcePolicy(route)
      if (resource.accessMode === 'judgment_api' || resource.capabilities?.generation === false || resource.capabilities?.tools === false) return { ok: false, reason: 'capability-incompatible: generation-tools-unavailable' }
      const info = await llm.resolveModelInfo(route.provider, route.model)
      const effort = getWireReasoningEffort(route)
      if (llm.resolveCallConfig !== undefined) await llm.resolveCallConfig({ provider: route.provider, model: route.model, ...(effort === undefined ? {} : { reasoningEffort: effort }) })
      else if (effort !== undefined && !info.reasoning?.efforts.some((item) => item.id === effort)) return { ok: false, reason: 'capability-incompatible: unsupported-reasoning-effort' }
      const observedVision = info.inputModalities === undefined ? (getCatalogVision(route) ?? false) : info.inputModalities.includes('image')
      return { ok: true, vision: observedVision && resource.capabilities?.vision !== false }
    } catch (error) {
      if (cancelledMetadata(error)) return { ok: false, reason: 'metadata-cancelled' }
      const failure = getRouteFailure(error)
      if (normalizeRouteFailure(failure, route).kind === 'capability_mismatch') return { ok: false, reason: `capability-incompatible: ${getErrorText(error)}` }
      return { ok: false, reason: `model-unavailable: ${getErrorText(error)}`, failure }
    }
  }
  return { probe: async (llm, route) => {
    const identity = getMetadataIdentity(llm)
    if (owner !== identity) { entries.clear(); owner = identity }
    const key = probeKey(route), hit = entries.get(key)
    if (hit !== undefined) {
      if ('pending' in hit) return hit.timedOut ? { ok: false, reason: 'metadata-pending-timeout' } : hit.pending
      if (now() - hit.at < PROBE_OK_TTL_MS) {
        entries.delete(key); entries.set(key, hit)
        return hit.result
      }
      entries.delete(key)
    }
    if (entries.size >= maximum) {
      let removable: string | undefined
      for (const [key, entry] of entries) if (!('pending' in entry)) { removable = key; break }
      if (removable === undefined) return { ok: false, reason: 'metadata-capacity-busy' }
      entries.delete(removable)
    }
    let entry!: PendingEntry
    let timer!: ReturnType<typeof setTimeout>
    const timeout = new Promise<RouteMetadataResult>((resolve) => {
      timer = setTimeout(() => {
        // Stop this wait, not the SDK request. Keep its slot to prevent overlapping
        // requests to a hung service; later callers can immediately try another route.
        entry.timedOut = true
        resolve({ ok: false, reason: 'metadata-pending-timeout' })
      }, pendingWaitMs)
      timer.unref?.()
    })
    const sdkResult = resolveMetadata(llm, route).then((result) => {
      clearTimeout(timer)
      // A replaced service or evicted old lookup cannot publish into the new cache.
      if (owner === identity && entries.get(key) === entry) {
        if (result.ok) entries.set(key, { at: now(), result: Object.freeze(result) })
        else entries.delete(key)
      }
      return result
    }, (error) => {
      clearTimeout(timer)
      if (entries.get(key) === entry) entries.delete(key)
      throw error
    })
    entry = { pending: Promise.race([sdkResult, timeout]), timedOut: false }
    entries.set(key, entry)
    return entry.pending
  } }
}

/** Aborting one waiter does not cancel the shared SDK lookup or other waiters. */
const waitForMetadata = (pending: Promise<RouteMetadataResult>, signal?: AbortSignal): Promise<RouteMetadataResult> => {
  if (signal === undefined) return pending
  if (signal.aborted) return Promise.resolve({ ok: false, reason: 'metadata-cancelled' })
  return new Promise((resolve, reject) => {
    const onAbort = () => { signal.removeEventListener('abort', onAbort); resolve({ ok: false, reason: 'metadata-cancelled' }) }
    signal.addEventListener('abort', onAbort, { once: true })
    pending.then((result) => { signal.removeEventListener('abort', onAbort); resolve(result) }, (error) => { signal.removeEventListener('abort', onAbort); reject(error) })
  })
}

/**
 * 基于 ctx.llm 的路由预检：provider 已注册且模型可解析。
 * 订阅类 provider 解析模型可能要访问网络（实测单次 2–3 秒），结果按路由短时缓存，并发的同一预检共用一次调用
 * @param {() => LlmLike | undefined} getLlm - 取 LLM 服务
 * @param {{ now?: () => number }} [options] - 时钟
 * @returns {RouteProbe} 预检函数
 */
export const intRouteProbe = (getLlm: () => LlmLike | undefined, options: {
  now?: () => number
  metadataCache?: RouteMetadataCache
  isRouteAvailable?: (route: RouteInfo) => boolean
  onFailure?: RouteFailureObserver
} = {}): RouteProbe => {
  const now = options.now ?? Date.now
  const metadataCache = options.metadataCache ?? createRouteMetadataCache({ now })
  // Failures stay local: a freshly created owner/manual-retry probe must perform
  // new metadata lookup rather than replay another owner's old failed result.
  const failures = new Map<string, { at: number; result: RouteProbeResult }>()
  const observeFailure = options.onFailure === undefined ? undefined : createRouteFailureObserver(options.onFailure)
  let owner: object | undefined
  return async (route, signal) => {
    if (signal?.aborted) return { ok: false, reason: 'metadata-cancelled' }
    if (options.isRouteAvailable?.(route) === false) return { ok: false, reason: 'route-isolated' }
    const llm = getLlm()
    const identity = getMetadataIdentity(llm)
    if (owner !== identity) { failures.clear(); owner = identity }
    if (llm === undefined) return { ok: false, reason: 'llm-service-unavailable' }
    if (!llm.listProviders().some((provider) => provider.id === route.provider)) return { ok: false, reason: 'provider-not-configured' }
    const key = probeKey(route), hit = failures.get(key)
    if (hit !== undefined && now() - hit.at < PROBE_FAIL_TTL_MS) return hit.result
    failures.delete(key)
    const result = await waitForMetadata(metadataCache.probe(llm, route), signal)
    if (signal?.aborted || (!result.ok && result.reason === 'metadata-cancelled')) return { ok: false, reason: 'metadata-cancelled' }
    if (getMetadataIdentity(getLlm()) !== identity) return { ok: false, reason: 'llm-service-changed' }
    if (!llm.listProviders().some((provider) => provider.id === route.provider)) return { ok: false, reason: 'provider-not-configured' }
    if (options.isRouteAvailable?.(route) === false) return { ok: false, reason: 'route-isolated' }
    if (result.ok) return { ok: true, vision: result.vision }
    if (result.failure !== undefined) await observeFailure?.(route, result.failure)
    if (signal?.aborted) return { ok: false, reason: 'metadata-cancelled' }
    if (options.isRouteAvailable?.(route) === false) return { ok: false, reason: 'route-isolated' }
    const failed = { ok: false as const, reason: result.reason }
    if (result.reason !== 'metadata-capacity-busy' && result.reason !== 'metadata-pending-timeout') {
      if (failures.size >= PROBE_CACHE_MAX_ENTRIES) failures.delete(failures.keys().next().value!)
      failures.set(key, { at: now(), result: failed })
    }
    return failed
  }
}
