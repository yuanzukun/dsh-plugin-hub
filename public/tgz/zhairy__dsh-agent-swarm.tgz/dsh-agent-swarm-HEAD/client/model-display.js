// 百工会话的模型显示（浏览器端）：聊天窗口里的「调用模型」行与会话头部的当前模型徽标。
// 本文件是 client bundle 的模块体之一：scripts/build-client.mjs 把它与设置页一起打包，
// 事件投影在 model-events.js，避免事件契约与 React 展示层互相耦合。
//
// 「调用模型」行只读取宿主已经记录的会话事件，不写入任何自定义事件：
// - assistant/message 的 source 记录了每一步实际作答的供应商与模型（含回退与容灾升级之后的模型）；
// - request/header 记录请求配置，用来补充推理强度；
// - system/message（百工 persona 含 dsh-agent-swarm）与 agent-preset/selected 用来判断是否百工会话。
// 默认每次模型调用都显示一行；「设置 → 百工 Agent」可改为只在每轮首次调用与换模型时显示（swarm-core 的 agents.modelCallDisplay）。
// 同一轮里换了模型（回退、升级、手动切换）时显示为「切换模型」并注明原模型。

const React = require('react')
const h = React.createElement
let HostModal
try { HostModal = require('@deepseek-ai/dsh-client-ui-primitives').Modal } catch { HostModal = undefined }

const {
  DISPLAY,
  NS,
  SWARM_NAMESPACE,
  KIND,
  providerLabel,
  isSwarmPreset,
  readHeaderRoute,
  readMessageRoute,
  markerDefinition,
  headerDefinition,
  modelCallDefinition
} = require('@swarm/model-events')

const zh = {
  title: '调用模型',
  switched: '切换模型',
  effort: '推理',
  from: '原为',
  badge: '最近请求模型', next: '下次选择', unknownEffort: '未报告', controls: '模型与恢复', actual: '实际调用', actualUnknown: '尚无宿主实际 attempt 观测', selectedNext: '下一次所选模型', state: '状态', refresh: '刷新状态', select: '选择模型', stop: '取消当前调用', continue: '安全继续任务', busy: '处理中…', provider: '供应商', model: '模型', effortDefault: '宿主默认', chooseProvider: '选择供应商', chooseModel: '选择模型', stopping: '已请求取消，等待宿主确认沉寂；尚未继续任务。', savedNext: '已记录下一次模型选择；只有新的实际调用才表示生效。', resumed: '继续请求已交给任务管线；执行与验收以任务状态为准。', reconcile: '我已核对取消可能留下的副作用与任务进度', reconcileHint: '此确认不会清除未知写入租约；宿主仍需完成实际工作区恢复检查。', steering: '继续说明（可选）', retryRoute: '受控重试所选路由一次', forceRetry: '提前结束插件冷却并试一次（不越过服务重置时间）', routeHint: '运行中切换会先取消旧调用；沉寂后点击安全继续，避免自动重放写入。', unavailable: '控制面暂不可用', phase_idle: '空闲', phase_running: '运行中', phase_waiting: '等待网络或重试', phase_stopping: '等待取消沉寂', phase_paused: '已暂停', 'phase_recovery-required': '需核对宿主运行状态', close: '收起'
}

const en = {
  title: 'Model call',
  switched: 'Model switched',
  effort: 'effort',
  from: 'was',
  badge: 'Last requested model', next: 'Next selection', unknownEffort: 'unreported', controls: 'Model & recovery', actual: 'Actual attempt', actualUnknown: 'No host attempt observation yet', selectedNext: 'Selected for next call', state: 'State', refresh: 'Refresh status', select: 'Select model', stop: 'Cancel current call', continue: 'Continue task safely', busy: 'Working…', provider: 'Provider', model: 'Model', effortDefault: 'Host default', chooseProvider: 'Select provider', chooseModel: 'Select model', stopping: 'Cancellation requested; waiting for host quiescence. The task has not resumed.', savedNext: 'Next model selection saved; a new observed attempt confirms it took effect.', resumed: 'Continuation admitted to the task pipeline; execution and acceptance remain separate.', reconcile: 'I checked possible side effects and current task progress', reconcileHint: 'This does not clear unknown mutation leases; the host must still perform workspace recovery checks.', steering: 'Continuation guidance (optional)', retryRoute: 'Allow one controlled retry of the selected route', forceRetry: 'Bypass plugin cooldown once, respecting the service reset time', routeHint: 'Switching during a run cancels the old call first. Continue after quiescence to avoid replaying writes.', unavailable: 'Control plane unavailable', phase_idle: 'Idle', phase_running: 'Running', phase_waiting: 'Waiting for network or retry', phase_stopping: 'Waiting for cancellation', phase_paused: 'Paused', 'phase_recovery-required': 'Host reconciliation required', close: 'Close'
}

Object.assign(zh, { stopped: '宿主已确认本轮结束；可继续未完成任务。' })
Object.assign(en, { stopped: 'The host confirmed this run ended; unfinished work can be continued.' })
Object.assign(zh, { unknownModel: '实际模型未由宿主报告' })
Object.assign(en, { unknownModel: 'Actual model not reported by the host' })
Object.assign(zh, { recoveryHint: '子智能体执行失败后，可在此切换模型并安全继续任务。', catalogLoading: '正在读取当前模型目录…', catalogUnavailable: '模型目录暂不可用，请刷新后选择。', catalogRetry: '刷新模型目录', invalidSelection: '请选择当前目录中的供应商、模型及推理强度。', catalogPartial: '部分供应商暂不可用；可选择已加载的模型，或刷新目录。' })
Object.assign(en, { recoveryHint: 'If this subagent fails, switch its model here and continue the task safely.', catalogLoading: 'Loading the current model catalog…', catalogUnavailable: 'The model catalog is unavailable. Refresh before selecting.', catalogRetry: 'Refresh model catalog', invalidSelection: 'Select a provider, model and reasoning effort from the current catalog.', catalogPartial: 'Some providers are unavailable. Choose a loaded model or refresh the catalog.' })
Object.assign(zh, { oneShotHint: '一次性审核或委派：选择只影响下一次模型请求，当前调用继续运行；若本轮已结束，需在父会话发起新审核或委派。', oneShotSettled: '一次性子会话已结束；在父会话发起新审核或委派。', inherited: '当前使用角色路由链', overridden: '已显式覆盖本子会话模型（保留角色回退链）' })
Object.assign(en, { oneShotHint: 'One-shot review or delegation: selection affects the next model request only. The current request continues; start a new review or delegation in the parent after settlement.', oneShotSettled: 'This one-shot child has ended. Start a new review or delegation in the parent.', inherited: 'Using the role routing chain', overridden: 'Explicit model override for this child (role fallbacks remain)' })

const style = {
  row: { display: 'flex', alignItems: 'center', gap: 8, padding: '2px 0', fontSize: 13, lineHeight: '22px', minWidth: 0 },
  title: { flex: 'none', color: 'var(--dsw-alias-label-secondary)' },
  switched: { flex: 'none', color: 'var(--dsw-alias-state-warn-primary, #d9480f)' },
  sep: { flex: 'none', width: 2, height: 2, borderRadius: 1, background: 'var(--dsw-alias-label-caption)' },
  summary: { flex: '1 1 auto', minWidth: 0, whiteSpace: 'normal', overflowWrap: 'anywhere', color: 'var(--dsw-alias-label-tertiary)' },
  badge: {
    display: 'inline-block', maxWidth: 260, padding: '0 8px', borderRadius: 999, fontSize: 12, lineHeight: '20px',
    overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', verticalAlign: 'middle',
    background: 'var(--dsw-alias-bg-module-platform)', color: 'var(--dsw-alias-label-primary)'
  }
}

const routeText = (t, route) =>
  `${route.model} · ${providerLabel(route.provider)}（${route.provider}） · ${t('effort')} ${route.reasoningEffort ?? t('unknownEffort')}`

/**
 * 一行「调用模型」：模型 · 供应商（路由名）· 推理强度
 * @param props - Chat 节点槽位的属性（node、t 与会话标准属性）
 */
function ModelCallRow (props) {
  const { node, t } = props
  const preset = typeof props.useProjection === 'function' ? props.useProjection('agentPreset') : undefined
  const mode = typeof props.useModelCallMode === 'function' ? props.useModelCallMode() : 'every'
  const data = node?.data
  if (data === null || typeof data !== 'object' || typeof data.provider !== 'string' || typeof data.model !== 'string') return null
  if (data.swarm !== true && !isSwarmPreset(preset)) return null
  if (data.repeat === true && mode === 'turn') return null
  const text = routeText(t, data) + (data.from === undefined ? '' : `（${t('from')} ${data.from.model} · ${providerLabel(data.from.provider)}）`)
  return h('div', { style: style.row, role: 'note', 'data-swarm-model-call': data.provider },
    h('span', { style: data.switched ? style.switched : style.title }, data.switched ? t('switched') : t('title')),
    h('span', { style: style.sep, 'aria-hidden': 'true' }),
    h('span', { style: style.summary, title: text }, text))
}

/**
 * 会话头部的当前模型徽标：只在百工会话（天枢、角色预设与委派出的专家会话）显示
 * @param props - 会话头部槽位的属性
 */
function ModelBadge (props) {
  const { t } = props
  if (typeof props.useProjection !== 'function') return null
  const preset = props.useProjection('agentPreset')
  const selection = props.useProjection('modelSelection')
  const subagent = typeof props.useSession === 'function' ? props.useSession((session) => session?.subagent) : undefined
  if (!isSwarmPreset(preset) && subagent === null) return null
  if (!isSwarmPreset(preset) && subagent === undefined) return null
  const used = selection?.lastUsed ?? selection?.next
  if (used === null || used === undefined || typeof used.provider !== 'string' || typeof used.model !== 'string') return subagent === undefined || subagent === null ? null : h('span', { style: style.badge, 'data-swarm-model-badge': 'unknown', title: t('unknownModel') }, t('unknownModel'))
  const label = selection?.lastUsed === null || selection?.lastUsed === undefined ? t('next') : t('badge')
  return h('span', { style: style.badge, title: `${label}：${routeText(t, used)}`, 'data-swarm-model-badge': used.provider },
    `${label}：${routeText(t, used)}`)
}

const inject = ['slots', 'locale', 'uiConversation', 'connection', 'remote.session']

const NO_SUBSCRIBE = () => () => undefined

/** The browser only requests changes; actual/settled state always comes back from the host. */
/** 与宿主 isResumable 一致：沉寂后暂停，或上一轮因模型错误结束的空闲持久会话可以继续 */
const canContinue = (view) => view?.phase === 'paused' || (view?.phase === 'idle' && String(view?.reason ?? '').startsWith('host-run-failed:'))

// 目录仅代表已配置候选；额度与调用准入仍由宿主在实际请求时检查。
const ValidateCatalogSelection = (state) => {
  if (state.catalogStatus !== 'ready') return false
  const group = state.groups.find((item) => item.id === state.draft.provider)
  const model = group?.models?.find((item) => item.id === state.draft.model)
  return model !== undefined && (state.draft.reasoningEffort === '' || (model.reasoning?.efforts ?? []).some((item) => item.id === state.draft.reasoningEffort))
}

const getCatalogDraft = (groups, draft) => {
  const model = groups.find((item) => item.id === draft.provider)?.models?.find((item) => item.id === draft.model)
  return model !== undefined && draft.reasoningEffort !== '' && !(model.reasoning?.efforts ?? []).some((item) => item.id === draft.reasoningEffort)
    ? { ...draft, reasoningEffort: '' } : draft
}

class AgentModelController {
  constructor (address, transport, requestTimeoutMs = 15000) {
    this.address = address
    this.transport = transport
    this.listeners = new Set()
    this.generation = 0
    this.catalogGeneration = 0
    this.pendingLoad = undefined
    this.pendingCatalog = undefined
    this.commandController = undefined
    this.requestTimeoutMs = requestTimeoutMs
    this.draftTouched = false
    this.active = false
    this.unsubscribeConnection = undefined
    this.disposed = false
    this.state = { status: 'idle', view: undefined, groups: [], catalogStatus: 'idle', busy: false, error: undefined, notice: undefined, draft: { provider: '', model: '', reasoningEffort: '' }, retryRoute: false, forceRetry: false, confirmSafeToContinue: false, steering: '' }
    this.subscribe = (listener) => { this.listeners.add(listener); return () => this.listeners.delete(listener) }
    this.getSnapshot = () => this.state
  }
  update (patch) {
    if (this.disposed) return
    this.state = { ...this.state, ...patch }
    this.listeners.forEach((listener) => listener())
  }
  dispose () {
    this.disposed = true
    this.generation += 1
    this.catalogGeneration += 1
    this.pendingLoad?.expire?.(true)
    this.pendingCatalog?.expire?.(true)
    this.pendingLoad?.controller?.abort()
    this.pendingCatalog?.controller?.abort()
    this.commandController?.abort()
    this.pendingLoad = undefined
    this.pendingCatalog = undefined
    this.commandController = undefined
    this.unsubscribeConnection?.()
    this.unsubscribeConnection = undefined
    this.listeners.clear()
  }
  activate () {
    if (this.disposed || this.active) return
    this.active = true
    this.unsubscribeConnection = this.transport.subscribeGeneration?.(() => this.resetConnection())
    void this.load()
    void this.loadCatalog()
  }
  deactivate () {
    if (!this.active) return
    this.active = false
    this.generation += 1
    this.catalogGeneration += 1
    this.pendingLoad?.expire?.(true)
    this.pendingCatalog?.expire?.(true)
    this.pendingLoad?.controller?.abort()
    this.pendingCatalog?.controller?.abort()
    this.commandController?.abort()
    this.pendingLoad = undefined
    this.pendingCatalog = undefined
    this.commandController = undefined
    this.unsubscribeConnection?.()
    this.unsubscribeConnection = undefined
    // Closing the panel advances the view generation, so the command's own
    // finally block can no longer release this latch. The host command remains
    // revision-checked and the next activation reloads authoritative state.
    this.update({ busy: false, error: undefined })
  }
  resetConnection () {
    if (this.disposed) return
    this.generation += 1
    this.catalogGeneration += 1
    this.pendingLoad?.expire?.(true)
    this.pendingCatalog?.expire?.(true)
    this.pendingLoad?.controller?.abort()
    this.pendingCatalog?.controller?.abort()
    this.commandController?.abort()
    this.pendingLoad = undefined
    this.pendingCatalog = undefined
    this.commandController = undefined
    this.update({
      status: 'idle',
      view: undefined,
      groups: [],
      catalogStatus: 'idle',
      catalogPartial: false,
      catalogError: undefined,
      busy: false,
      error: undefined,
      notice: undefined
    })
    if (this.active) {
      void this.load()
      void this.loadCatalog()
    }
  }
  getView (raw) {
    const value = raw?.control ?? raw
    if (value?.childId !== this.address.childId || value?.parentSessionId !== this.address.parentSessionId || !Number.isSafeInteger(value.revision) || value.revision < 1 || typeof value.phase !== 'string' || typeof value.persistent !== 'boolean') throw new Error('invalid host agent-control view')
    return value
  }
  async load (silent = false) {
    if (this.disposed) return
    if (this.pendingLoad?.generation === this.generation) {
      // 显式刷新碰上进行中的静默轮询：复用同一读取，但要清掉旧的失败提示。
      if (!silent && this.state.error !== undefined) this.update({ error: undefined })
      return this.pendingLoad.promise
    }
    const generation = this.generation
    const token = { generation, controller: new AbortController(), timedOut: false, expire: undefined, promise: undefined }
    // 周期轮询不得清掉用户操作刚产生的失败提示；只有显式刷新或读取失败重试才清空。
    const keepActionError = silent && this.state.status === 'ready'
    if (!keepActionError) this.update({ status: this.state.view === undefined ? 'loading' : this.state.status, error: undefined })
    const promise = (async () => {
      let timer
      const timeout = new Promise((_, reject) => {
        token.expire = (silent = false) => {
          if (token.timedOut) return
          token.timedOut = true
          token.controller.abort()
          if (this.pendingLoad === token) {
            this.pendingLoad = undefined
            if (!silent) this.update({ status: 'error', error: '模型与恢复状态读取超时；已取消本次读取，可刷新重试。' })
          }
          reject(new Error('agent view timeout'))
        }
        timer = setTimeout(() => token.expire(), this.requestTimeoutMs)
      })
      try {
        const view = this.getView(await Promise.race([this.transport.view(this.address, token.controller.signal), timeout]))
        if (token.timedOut || generation !== this.generation) return
        const selected = view.selectedNext ?? view.requestedRoute ?? view.actual?.route
        const draft = !this.draftTouched && this.state.view === undefined && selected !== undefined
          ? { provider: selected.provider, model: selected.model, reasoningEffort: selected.reasoningEffort ?? '' }
          : this.state.draft
        const notice = view.phase === 'paused' && this.state.notice === 'stopping' ? { notice: 'stopped' } : {}
        // 视图与提示都没有变化时不重复发布；按整视图比较，避免漏掉不改修订号的实时字段。
        if (this.state.status === 'ready' && this.state.view !== undefined && JSON.stringify(this.state.view) === JSON.stringify(view) && notice.notice === undefined) return
        this.update({ status: 'ready', view, draft: this.state.catalogStatus === 'ready' ? getCatalogDraft(this.state.groups, draft) : draft, ...notice })
      } catch (error) {
        if (!token.timedOut && generation === this.generation) this.update({ status: 'error', error: error instanceof Error ? error.message : String(error) })
      } finally {
        clearTimeout(timer)
        if (this.pendingLoad === token) this.pendingLoad = undefined
      }
    })()
    token.promise = promise
    this.pendingLoad = token
    try { await promise } finally { if (this.pendingLoad?.promise === promise) this.pendingLoad = undefined }
  }
  async loadCatalog () {
    if (this.disposed) return
    if (this.pendingCatalog?.generation === this.catalogGeneration) return this.pendingCatalog.promise
    const generation = this.catalogGeneration
    const token = { generation, controller: new AbortController(), timedOut: false, expire: undefined, promise: undefined }
    this.update({ catalogStatus: 'loading', catalogError: undefined })
    const promise = (async () => {
      let timer
      const timeout = new Promise((_, reject) => {
        token.expire = (silent = false) => {
          if (token.timedOut) return
          token.timedOut = true
          token.controller.abort()
          if (this.pendingCatalog === token) {
            this.pendingCatalog = undefined
            if (!silent) this.update({ catalogStatus: 'error', catalogError: '模型目录读取超时；已取消本次读取，可重试。' })
          }
          reject(new Error('model catalog timeout'))
        }
        timer = setTimeout(() => token.expire(), this.requestTimeoutMs)
      })
      try {
        const raw = await Promise.race([this.transport.catalog(token.controller.signal), timeout])
        const value = raw?.ok === true ? raw.value : raw
        if (!Array.isArray(value?.groups)) throw new Error('model catalog unavailable')
        if (!token.timedOut && generation === this.catalogGeneration) {
          const groups = value.groups.filter((group) => typeof group?.id === 'string' && Array.isArray(group.models))
          this.update({ groups, draft: getCatalogDraft(groups, this.state.draft), catalogStatus: 'ready', catalogPartial: Array.isArray(value.failures) && value.failures.length > 0 })
        }
      } catch (error) {
        if (!token.timedOut && generation === this.catalogGeneration) this.update({ catalogStatus: 'error', catalogError: '模型目录读取失败；请刷新后重试。' })
      } finally {
        clearTimeout(timer)
        if (this.pendingCatalog === token) this.pendingCatalog = undefined
      }
    })()
    token.promise = promise
    this.pendingCatalog = token
    try { await promise } finally { if (this.pendingCatalog?.promise === promise) this.pendingCatalog = undefined }
  }
  setDraft (patch) {
    const draft = { ...this.state.draft, ...patch }
    if (patch.provider !== undefined) { draft.model = ''; draft.reasoningEffort = '' }
    else if (patch.model !== undefined) draft.reasoningEffort = ''
    this.draftTouched = true
    this.update({ draft, notice: undefined })
  }
  setOptions (patch) { this.update(patch) }
  async command (action) {
    if (this.state.busy || this.state.view === undefined || this.disposed) return
    const view = this.state.view
    const input = { ...this.address, expectedRevision: view.revision, action }
    if (action === 'select') {
      const route = this.state.draft
      if (!ValidateCatalogSelection(this.state)) { this.update({ notice: 'invalidSelection' }); return }
      input.route = { provider: route.provider, model: route.model, ...(route.reasoningEffort === '' ? {} : { reasoningEffort: route.reasoningEffort }) }
      input.interruptRunning = view.persistent === true && ['running', 'waiting', 'stopping'].includes(view.phase)
      if (this.state.retryRoute) input.retryRoute = true
      if (this.state.retryRoute && this.state.forceRetry) input.forceRetry = true
    } else if (action === 'continue') {
      if (view.persistent !== true || !canContinue(view) || (view.needsSideEffectReview === true && !this.state.confirmSafeToContinue)) return
      if (this.state.confirmSafeToContinue) input.confirmSafeToContinue = true
      if (this.state.steering.trim() !== '') input.steering = this.state.steering.trim()
    }
    const generation = ++this.generation
    const controller = new AbortController()
    this.commandController = controller
    this.update({ busy: true, error: undefined, notice: undefined })
    let timer
    try {
      const result = await Promise.race([
        this.transport.command(input, controller.signal),
        new Promise((_, reject) => {
          timer = setTimeout(() => {
            controller.abort()
            reject(new Error('模型控制请求超时；已取消本次请求，请刷新状态后重试。'))
          }, this.requestTimeoutMs)
        })
      ])
      if (generation !== this.generation) return
      const returned = result?.control ?? (result?.childId === this.address.childId ? result : undefined)
      if (returned !== undefined) this.update({ view: this.getView(returned) })
      await this.load()
      if (generation !== this.generation) return
      if (this.state.status === 'ready') this.update({ notice: action === 'continue' ? 'resumed' : action === 'stop' || this.state.view?.phase === 'stopping' ? 'stopping' : 'savedNext', confirmSafeToContinue: false })
    } catch (error) {
      if (generation !== this.generation) return
      await this.load()
      if (generation === this.generation) this.update({ error: error instanceof Error ? error.message : String(error) })
    } finally {
      clearTimeout(timer)
      if (this.commandController === controller) this.commandController = undefined
      if (generation === this.generation) this.update({ busy: false })
    }
  }
}

const controlStyle = {
  panel: { position: 'relative', width: '100%', maxWidth: '100%', maxHeight: 'min(70vh, 600px)', overflowY: 'auto', boxSizing: 'border-box', padding: 10, background: 'var(--dsw-alias-bg-layer-3, white)', color: 'var(--dsw-alias-label-primary, #24344a)', fontSize: 13, lineHeight: 1.6 },
  field: { display: 'flex', flexDirection: 'column', gap: 4, minWidth: 0, marginTop: 8 },
  input: { minWidth: 0, width: '100%', boxSizing: 'border-box', padding: 6 },
  line: { overflowWrap: 'anywhere', whiteSpace: 'normal', margin: '5px 0' },
  actions: { display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 10 },
  button: { padding: '4px 8px', cursor: 'pointer' },
  recoveryButton: { padding: '5px 12px', borderRadius: 999, border: '1px solid #ca8a04', background: '#facc15', color: '#422006', fontWeight: 600, cursor: 'pointer', whiteSpace: 'nowrap' }
}

function AgentControlPanel ({ controller, t }) {
  const state = React.useSyncExternalStore(controller.subscribe, controller.getSnapshot)
  const view = state.view
  React.useEffect(() => {
    controller.activate()
    return () => controller.deactivate()
  }, [controller])
  React.useEffect(() => {
    if (view === undefined) return undefined
    const timer = setInterval(() => {
      if (globalThis.document?.visibilityState !== 'hidden' && !controller.getSnapshot().busy) controller.load(true)
    }, 2000)
    return () => clearInterval(timer)
  }, [controller, view !== undefined])
  const provider = state.groups.find((item) => item.id === state.draft.provider)
  const models = provider?.models ?? []
  const model = models.find((item) => item.id === state.draft.model)
  const efforts = model?.reasoning?.efforts ?? []
  const readonly = view !== undefined && (view.persistent !== true && (view.oneShotSettled === true || view.reason === 'one-shot-settled' || view.paused || ['stopping', 'recovery-required'].includes(view.phase)))
  const disabled = state.busy || state.status !== 'ready'
  const field = (label, element) => h('label', { style: controlStyle.field }, h('span', null, t(label)), element)
  const route = view?.actual?.route
  return h('div', { style: controlStyle.panel, 'data-swarm-agent-control': controller.address.childId, role: 'region', 'aria-label': t('controls') },
    h('p', { style: controlStyle.line }, `${t('actual')}：${route === undefined ? t('actualUnknown') : routeText(t, route)}`),
    view?.selectedNext === undefined ? null : h('p', { style: controlStyle.line }, `${t('selectedNext')}：${routeText(t, view.selectedNext)}`),
    view === undefined ? null : h('p', { style: controlStyle.line }, t(view.selectedNext === undefined ? 'inherited' : 'overridden')),
    h('p', { style: controlStyle.line, role: 'status' }, `${t('state')}：${view === undefined ? t('unavailable') : t(`phase_${view.phase}`)}`),
    state.error === undefined ? null : h('p', { role: 'alert', style: { ...controlStyle.line, color: 'var(--dsw-alias-state-error-primary, #c92a2a)' } }, state.error),
    state.catalogError === undefined ? null : h('p', { role: 'alert', style: controlStyle.line }, state.catalogError),
    state.notice === undefined ? null : h('p', { role: 'status', style: controlStyle.line }, t(state.notice)),
    readonly ? null : h(React.Fragment, null,
      canContinue(view) ? h('p', { role: 'note', style: controlStyle.line }, t('recoveryHint')) : null,
      state.catalogStatus !== 'ready' ? h('p', { role: 'status', style: controlStyle.line }, t(state.catalogStatus === 'loading' ? 'catalogLoading' : 'catalogUnavailable')) : null,
      state.catalogPartial ? h('p', { role: 'status', style: controlStyle.line }, t('catalogPartial')) : null,
      field('provider', h('select', { style: controlStyle.input, value: provider === undefined ? '' : state.draft.provider, disabled: disabled || state.catalogStatus !== 'ready', 'aria-label': t('provider'), onChange: (event) => controller.setDraft({ provider: event.target.value }) }, h('option', { value: '' }, t('chooseProvider')), ...state.groups.map((item) => h('option', { key: item.id, value: item.id }, `${item.name ?? providerLabel(item.id)}（${item.id}）`)))),
      field('model', h('select', { style: controlStyle.input, value: model === undefined ? '' : state.draft.model, disabled: disabled || state.catalogStatus !== 'ready' || provider === undefined, 'aria-label': t('model'), onChange: (event) => controller.setDraft({ model: event.target.value }) }, h('option', { value: '' }, t('chooseModel')), ...models.map((item) => h('option', { key: item.id, value: item.id }, item.name ?? item.id)))),
      field('effort', h('select', { style: controlStyle.input, value: efforts.some((item) => item.id === state.draft.reasoningEffort) ? state.draft.reasoningEffort : '', disabled: disabled || model === undefined || efforts.length === 0, 'aria-label': t('effort'), onChange: (event) => controller.setDraft({ reasoningEffort: event.target.value }) }, h('option', { value: '' }, t('effortDefault')), ...efforts.map((item) => h('option', { key: item.id, value: item.id }, item.name ?? item.id)))),
      view?.persistent !== true ? null : h('label', { style: { ...controlStyle.line, display: 'block' } }, h('input', { type: 'checkbox', checked: state.retryRoute, disabled, onChange: (event) => controller.setOptions({ retryRoute: event.target.checked, forceRetry: false }) }), t('retryRoute')),
      view?.persistent === true && state.retryRoute ? h('label', { style: { ...controlStyle.line, display: 'block' } }, h('input', { type: 'checkbox', checked: state.forceRetry, disabled, onChange: (event) => controller.setOptions({ forceRetry: event.target.checked }) }), t('forceRetry')) : null,
      view === undefined ? null : h('p', { style: controlStyle.line }, t(view.persistent === true ? 'routeHint' : 'oneShotHint'))),
    view?.oneShotSettled !== true && view?.reason !== 'one-shot-settled' ? null : h('p', { style: controlStyle.line }, t('oneShotSettled')),
    view?.persistent !== true || !canContinue(view) ? null : h(React.Fragment, null,
      view.needsSideEffectReview === true ? h('label', { style: { ...controlStyle.line, display: 'block' } }, h('input', { type: 'checkbox', checked: state.confirmSafeToContinue, disabled, onChange: (event) => controller.setOptions({ confirmSafeToContinue: event.target.checked }) }), t('reconcile'), h('p', { style: controlStyle.line }, t('reconcileHint'))) : null,
      field('steering', h('textarea', { style: controlStyle.input, value: state.steering, maxLength: 8000, disabled, 'aria-label': t('steering'), onChange: (event) => controller.setOptions({ steering: event.target.value }) }))),
    h('div', { style: controlStyle.actions },
      h('button', { type: 'button', style: controlStyle.button, disabled: state.busy, onClick: () => controller.load() }, t('refresh')),
      readonly ? null : h('button', { type: 'button', style: controlStyle.button, disabled: state.busy || state.catalogStatus === 'loading', onClick: () => controller.loadCatalog() }, t('catalogRetry')),
      readonly ? null : h('button', { type: 'button', style: controlStyle.button, disabled: disabled || !ValidateCatalogSelection(state), onClick: () => controller.command('select') }, state.busy ? t('busy') : t('select')),
      ['running', 'waiting', 'recovery-required'].includes(view?.phase) ? h('button', { type: 'button', style: controlStyle.button, disabled, onClick: () => controller.command('stop') }, t('stop')) : null,
      canContinue(view) && !readonly ? h('button', { type: 'button', style: controlStyle.button, disabled: disabled || (view.needsSideEffectReview === true && !state.confirmSafeToContinue), onClick: () => controller.command('continue') }, t('continue')) : null))
}

function AgentModelControls (props) {
  const subagent = typeof props.useSession === 'function' ? props.useSession((session) => session?.subagent) : undefined
  const address = subagent?.address
  const parentId = address?.parentSessionId
  const childId = address?.childSessionId
  const [open, setOpen] = React.useState(false)
  const controller = React.useMemo(() => parentId === undefined || childId === undefined ? undefined : new AgentModelController({ parentSessionId: parentId, childId }, props.transport), [parentId, childId, props.transport])
  React.useEffect(() => () => controller?.dispose(), [controller])
  if (controller === undefined) return null
  const panel = open ? h(AgentControlPanel, { controller, t: props.t }) : null
  return h(React.Fragment, null,
    h('button', { type: 'button', style: controlStyle.recoveryButton, title: props.t('recoveryHint'), 'data-swarm-recovery-button': true, 'aria-expanded': open, onClick: () => setOpen(!open) }, props.t(open ? 'close' : 'controls')),
    HostModal === undefined
      ? open ? h('div', { role: 'dialog', 'aria-modal': true, 'aria-label': props.t('controls'), style: { position: 'fixed', inset: 0, zIndex: 1000, display: 'grid', placeItems: 'center', background: '#0004' } }, h('div', null, h('button', { type: 'button', onClick: () => setOpen(false) }, props.t('close')), panel)) : null
      : h(HostModal, { open, onClose: () => setOpen(false), title: props.t('controls'), closeLabel: props.t('close') }, panel))
}

const getAgentControlTransport = (ctx) => {
  let generation = 0
  const resetListeners = new Set()
  const rpc = async (method, payload, signal) => {
    const connection = ctx.get('connection')
    if (typeof connection?.rpc?.call !== 'function') throw new Error('swarm control RPC unavailable')
    const result = await connection.rpc.call('/api', method, payload, signal)
    if (result?.ok !== true) throw Object.assign(new Error(`${result?.error?.message ?? 'agent control RPC failed'}${result?.error?.code === undefined ? '' : ` (${result.error.code})`}`), { code: result?.error?.code })
    return result.value
  }
  return {
    view: (address, signal) => rpc('swarm.agentView', address, signal),
    command: (input, signal) => rpc('swarm.agentControl', input, signal),
    // modelCatalog 没有业务参数；signal 属于传输层，不能作为生成式 remote 的参数发送。
    catalog: (signal) => rpc('session/modelCatalog', { args: {} }, signal),
    subscribeGeneration: (listener) => {
      resetListeners.add(listener)
      return () => resetListeners.delete(listener)
    },
    notifyConnectionReset: () => {
      generation += 1
      for (const listener of [...resetListeners]) listener()
    }
  }
}

/**
 * 读取 swarm-core 的 agents.modelCallDisplay 的 Hook；配置表单不可用时按「每次调用都显示」
 * @param ctx - 浏览器端插件上下文
 * @returns {() => 'every' | 'turn'} Hook
 */
const getModelCallModeHook = (ctx) => {
  let form
  try {
    form = ctx.get('configForms')?.get?.(SWARM_NAMESPACE)
  } catch {
    form = undefined
  }
  const read = () => {
    const value = form?.getSnapshot?.()?.value
    return value?.agents?.modelCallDisplay === 'turn' ? 'turn' : 'every'
  }
  const subscribe = typeof form?.subscribe === 'function' ? (listener) => form.subscribe(listener) : NO_SUBSCRIBE
  return () => React.useSyncExternalStore(subscribe, read)
}

/**
 * 注册会话定义、Chat 节点渲染与会话头部徽标
 * @param ctx - 浏览器端插件上下文
 */
function apply (ctx) {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'swarm-model-calls: dictionaries')
  const transport = getAgentControlTransport(ctx)
  if (typeof ctx.on === 'function') {
    ctx.effect(() => ctx.on('connection/reset', () => transport.notifyConnectionReset()), 'swarm-model-calls: connection generation')
  }
  for (const definition of [markerDefinition, headerDefinition, modelCallDefinition]) {
    ctx.effect(() => ctx.uiConversation.events.register(definition), `swarm-model-calls: ${definition.kind}`)
  }
  const useModelCallMode = getModelCallModeHook(ctx)
  ctx.slots.inject('conversation.chat.node', function * () {
    yield ctx.slots.register({ name: 'conversation.chat.node', key: KIND, locale: NS, inject: () => ({ useModelCallMode }) }, ModelCallRow)
  })
  ctx.slots.inject('conversation.session.header.actions', function * () {
    yield ctx.slots.register({ name: 'conversation.session.header.actions', id: 'swarm-model-badge', order: -4, locale: NS }, ModelBadge)
    yield ctx.slots.register({ name: 'conversation.session.header.actions', id: 'swarm-agent-model-controls', order: -3, locale: NS, inject: () => ({ transport }) }, AgentModelControls)
  })
}

exports.inject = inject
exports.apply = apply
exports.NS = NS
exports.__test__ = { markerDefinition, headerDefinition, modelCallDefinition, ModelCallRow, ModelBadge, AgentModelController, AgentControlPanel, AgentModelControls, ValidateCatalogSelection, getAgentControlTransport, readHeaderRoute, readMessageRoute, getModelCallModeHook, routeText, DISPLAY }
