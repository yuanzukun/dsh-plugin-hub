/** Public Computer Use types shared by the Service, provider, and Tool consumer. */
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { Branded } from '@deepseek-ai/dsh-brand';
import type { ToolRunContext } from '@deepseek-ai/dsh-tools';
type CallId = ToolRunContext['callId'];
/** Opaque identifier for one immutable observed UI state. */
export type ComputerObservationId = Branded<'ComputerObservationId'>;
/** Brand a generated observation identifier. */
export declare const ComputerObservationId: (value: string) => ComputerObservationId;
/** Opaque reference to one element descriptor captured inside an observation. */
export type ComputerTargetHandle = Branded<'ComputerTargetHandle'>;
/** Brand a generated target handle. */
export declare const ComputerTargetHandle: (value: string) => ComputerTargetHandle;
/** Opaque one-use grant for one confirmed sensitive action. */
export type ComputerConfirmationToken = Branded<'ComputerConfirmationToken'>;
/** Brand a generated confirmation token. */
export declare const ComputerConfirmationToken: (value: string) => ComputerConfirmationToken;
/** Rectangle in screen-global point coordinates unless a containing type states otherwise. */
export interface ComputerRect {
    x: number;
    y: number;
    width: number;
    height: number;
}
/** macOS permission state reported without attempting to grant it. */
export type ComputerPermissionState = 'granted' | 'denied' | 'not-determined' | 'unavailable';
/** Stable identity of one running user-facing application. */
export interface ComputerAppIdentity {
    bundleId: string;
    pid: number;
    name: string;
}
/** Application selector accepted from a model or caller. */
export interface ComputerAppSelector {
    bundleId?: string;
    pid?: number;
    name?: string;
}
/** Bounded application row returned by discovery. */
export interface ComputerAppSummary extends ComputerAppIdentity {
    frontmost: boolean;
    accessibility: ComputerPermissionState;
    screenRecording: ComputerPermissionState;
}
/** One model-addressable element. Its index and opaque handle belong only to the enclosing observation. */
export interface ComputerElement {
    index: number;
    targetHandle: ComputerTargetHandle;
    role: string;
    subrole?: string;
    title?: string;
    label?: string;
    value?: string;
    enabled?: boolean;
    focused?: boolean;
    selected?: boolean;
    frame?: ComputerRect;
    actions: string[];
}
/** Deterministic route used to resolve a target immediately before input. */
export type ComputerTargetResolutionMode = 'exact-locator' | 'native-identifier' | 'semantic-rebind';
/** Model-visible evidence describing how an element target was resolved. */
export interface ComputerTargetResolutionResult {
    mode: ComputerTargetResolutionMode;
    confidence: number;
    candidateCount: number;
    targetChanged: boolean;
}
/** File artifact emitted by a Computer Use observation. */
export interface ComputerArtifact {
    path: string;
    filename: string;
    mimeType: 'image/png';
    kind: 'image';
    description: string;
    sourceTool: 'computer_observe' | 'computer_action';
    previewIntent: 'image';
    bytes: number;
    width: number;
    height: number;
    /** Screenshot pixels per window point; present when a screenshot and a window frame were available. */
    pixelScale?: number;
}
/** Complete model-visible observation. */
export interface ComputerObservation {
    observationId: ComputerObservationId;
    app: ComputerAppIdentity;
    createdAt: string;
    expiresAt: string;
    frontmost: boolean;
    window?: {
        title?: string;
        frame: ComputerRect;
        id?: number;
    };
    tree: {
        mode: 'full' | 'diff';
        text: string;
        truncated: boolean;
    };
    elements: ComputerElement[];
    screenshot?: ComputerArtifact;
    permissions: {
        accessibility: ComputerPermissionState;
        screenRecording: ComputerPermissionState;
    };
}
/** Whether screenshot capture is omitted, best-effort, or required. */
export type ComputerScreenshotMode = 'none' | 'optional' | 'required';
/** Request for a fresh observation. */
export interface ComputerObserveRequest {
    app: ComputerAppSelector;
    screenshot?: ComputerScreenshotMode;
    full?: boolean;
}
/** Closed set of supported key modifiers. */
export type ComputerKeyModifier = 'command' | 'control' | 'option' | 'shift';
/** Closed set of supported mouse buttons. */
export type ComputerMouseButton = 'left' | 'right' | 'middle';
/**
 * Coordinate space accepted by coordinate-based pointer actions.
 *
 * `window` and `screen` are measured in points, the unit of Accessibility
 * frames. `screenshot` is measured in the observation screenshot's pixels, so
 * coordinates read off a Retina screenshot can be passed directly instead of
 * dividing by the screenshot's pixel scale by hand.
 */
export type ComputerCoordinateSpace = 'window' | 'screen' | 'screenshot';
/** Shared fields carried by every action against an existing observation. */
export interface ComputerActionBase {
    observationId: ComputerObservationId;
    /** True only when the Skill has classified the action as requiring just-in-time confirmation. */
    sensitive?: boolean;
    /** One-use token returned by {@link ComputerUseService.confirm}. */
    confirmationToken?: ComputerConfirmationToken;
}
/** Stable target selection fields shared by element-addressed actions. */
export interface ComputerElementTarget {
    /** Observation-local compatibility index. It does not authorize rebinding by itself. */
    elementIndex?: number;
    /** Opaque handle returned on the selected observation element. */
    targetHandle?: ComputerTargetHandle;
    /** Permit deterministic native-identifier or unique semantic rebinding. */
    allowRebind?: boolean;
}
/** Click an observed element or an observed-window coordinate. */
export interface ComputerClickAction extends ComputerActionBase, ComputerElementTarget {
    kind: 'click';
    x?: number;
    y?: number;
    /** `window` (default) resolves `x`/`y` in points inside the observed window frame; `screen` treats them as Quartz screen-global points; `screenshot` treats them as pixels in the observation screenshot. */
    coordinateSpace?: ComputerCoordinateSpace;
    button?: ComputerMouseButton;
    clickCount?: number;
    allowCoordinateFallback?: boolean;
}
/** Set the Accessibility value of an observed editable element. */
export interface ComputerSetValueAction extends ComputerActionBase, ComputerElementTarget {
    kind: 'set-value';
    value: string;
}
/** Insert Unicode into the currently focused control through Accessibility or keyboard fallback, without using the clipboard. */
export interface ComputerTypeTextAction extends ComputerActionBase {
    kind: 'type-text';
    text: string;
    /** Select keyboard upfront for editors with unreliable AXSelectedText support; host focus policy still applies. */
    method?: 'auto' | 'keyboard';
}
/** Press one validated key chord. */
export interface ComputerPressKeyAction extends ComputerActionBase {
    kind: 'press-key';
    key: string;
    modifiers?: ComputerKeyModifier[];
}
/** Scroll at an observed element or coordinate. */
export interface ComputerScrollAction extends ComputerActionBase, ComputerElementTarget {
    kind: 'scroll';
    x?: number;
    y?: number;
    coordinateSpace?: ComputerCoordinateSpace;
    direction: 'up' | 'down' | 'left' | 'right';
    pages?: number;
}
/** Drag between two points in the observed-window, screen, or screenshot coordinate space. */
export interface ComputerDragAction extends ComputerActionBase {
    kind: 'drag';
    fromX: number;
    fromY: number;
    toX: number;
    toY: number;
    coordinateSpace?: ComputerCoordinateSpace;
}
/** Perform one Accessibility action advertised by an observed element. */
export interface ComputerPerformAction extends ComputerActionBase, ComputerElementTarget {
    kind: 'perform-action';
    action: string;
}
/** Wait for a bounded UI condition without mutating state. */
export interface ComputerWaitAction extends ComputerActionBase {
    kind: 'wait';
    condition: {
        text?: string;
        elementRole?: string;
        elementTitle?: string;
    };
    timeoutMs?: number;
}
/** Every model-accessible Computer Use action. */
export type ComputerActionRequest = ComputerClickAction | ComputerSetValueAction | ComputerTypeTextAction | ComputerPressKeyAction | ComputerScrollAction | ComputerDragAction | ComputerPerformAction | ComputerWaitAction;
/** Result of a successful action followed by a fresh observation. */
export interface ComputerActionResult {
    action: ComputerActionRequest['kind'];
    channel: 'accessibility' | 'coordinates' | 'keyboard' | 'wait';
    /** Verifiable target-app foreground state transition requested by the helper for this action. */
    activation: 'not-requested' | 'already-frontmost' | 'activated';
    /** Whether the helper emitted mouse, drag, or scroll-wheel input to the target process. */
    pointerInput: boolean;
    /** Pointer-event route selected by the helper; global HID routing is not supported. */
    pointerRouting: 'none' | 'target-process';
    /** Present when the action addressed an observed element. */
    resolution?: ComputerTargetResolutionResult;
    /** Present only when the agent cursor should be on screen and is not. */
    agentCursor?: {
        visible: false;
        reason?: string;
    };
    /** What changed in the bounded post-action structural observation. */
    effect: ComputerActionEffect;
    observation: ComputerObservation;
}
/**
 * What changed in the bounded structural observation after an action.
 *
 * The comparison covers the window title, id and frame plus the Accessibility
 * element tree. It does not prove that the action caused the change, and it
 * cannot observe pixel-only, transient, remote, or otherwise external effects.
 */
export interface ComputerActionEffect {
    /** True when the post-action structural state hash differed. */
    observedStateChanged: boolean;
    /** How long the settle loop watched, in milliseconds. */
    observedForMs: number;
    /** Scope guidance when no structural change was observed. */
    note?: string;
}
/** Confirmation request binding an exact proposed action to human-readable impact. */
export interface ComputerConfirmRequest {
    action: Omit<ComputerActionRequest, 'confirmationToken'>;
    reason: string;
    target: string;
    dataSummary?: string;
}
/** One-use confirmation result. */
export interface ComputerConfirmation {
    token: ComputerConfirmationToken;
    observationId: ComputerObservationId;
    app: ComputerAppIdentity;
    expiresAt: string;
}
/** Caller context required for scoping, cancellation, approval audit, and artifact placement. */
export interface ComputerUseContext {
    agent: Agent;
    workspace: string;
    callId?: CallId;
    signal: AbortSignal;
}
/** Provider and permission diagnostics exposed to Settings. */
export interface ComputerUseStatus {
    platform: NodeJS.Platform;
    provider: 'macos-ax' | 'unsupported';
    generation: number;
    ready: boolean;
    helperPath: string;
    helperVersion?: string;
    helperSha256?: string;
    accessibility: ComputerPermissionState;
    screenRecording: ComputerPermissionState;
    lastError?: string;
}
export {};
//# sourceMappingURL=types.d.ts.map