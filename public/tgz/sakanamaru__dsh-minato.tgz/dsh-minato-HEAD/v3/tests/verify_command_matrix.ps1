﻿# ============================================================================
#  verify_command_matrix.ps1 —— 「命令 × 隔离数据根」冒烟矩阵
#  ---------------------------------------------------------------------------
#  为什么需要它（批次 E4c，来源：外部审查建议 §2.2）：
#    这个项目的门槛跑的是**编译器**与**契约测试**，而外部审查抓到的那条致命缺陷
#    （`backup-export` 因 `CopyTree` 返回值语义而**恒失败**）一路活到 3.0.6 ——
#    原因很具体：**这条命令的成功路径从来没有被任何人跑过一次** ✗
#    → 结论：发版前，每个**对外宣传的命令**都要在**隔离数据根**里真跑一次，
#      并且同时断言①**标记行**（GUI 与脚本都靠它判断）②**退出码**（`&&`/`set -e` 靠它）。
#
#  反假绿设计（写清楚，因为这个文件自己也曾是"绿但不证明任何事"的样子）：
#    · 每个用例跑在**全新的隔离 DSH_HOME** 里，并显式把 ws 指到隔离目录 ——
#      否则工作区自动探测会把仓库当工作区一起备份（真机踩过 ✓）
#    · 输出**只保留标记行**（把 PS 5.1 的 NativeCommandError 噪声剔掉 ✓）
#    · 用例**必须有终态标记**（OK 或明确 FAIL）✓ —— 静默/崩溃会判红 ✓
#    · 失败语义的退出码一并断言 ✓（拒绝时若仍是 0，脚本无法判断 ✗ —— D2 修复项 ✓）
#    · `backup-export` 是**已知缺陷的守卫位**（A1/D1，2026-10-07 恒失败）：
#      · 现在代码里它已修好 → 断言**期望成功**（BKEXPORT_OK + rc=0）✓
#      · 若在某个提交上它又失败 → 默认把它记成 [XFAIL] 并在汇总单列 ✓
#        **绝不为了让矩阵变绿去改产品代码** ✗✓
#      · 交付/CI 用 `-AllowKnownDefect:$false`（export 失败 = 硬红 ✓）
#
#  用法：
#    powershell -NoProfile -ExecutionPolicy Bypass -File v3\tests\verify_command_matrix.ps1 -Repo .
#    powershell ... -Cli <dsh-minato.exe 路径>          # 不构建时直接指定二进制（CI 里这样用）
#    powershell ... -AllowKnownDefect:$false            # 修好之后：把 export 当硬失败（CI 用它 ✓）
#  退出码：0 = 矩阵全绿；1 = 有用例红；2 = 找不到 CLI
# ============================================================================
[CmdletBinding()]
param(
    [string]$Repo = ".",
    [string]$Cli = "",
    [switch]$AllowKnownDefect = $false,
    [switch]$Keep
)

$ErrorActionPreference = "Stop"
# 与 verify_restore_apply / verify_switchover 同一手法：只在调外部命令期间放宽为 Continue，
# 否则 V3 exe 往 stderr 打的一行正常诊断（INTEGRITY_SKIPPED）会被 PS 5.1 变成终止错误 ✗
function Invoke-External([scriptblock]$sb) {
    $old = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { & $sb } finally { $ErrorActionPreference = $old }
}

$script:pass = 0
$script:fail = 0
$script:xfail = New-Object System.Collections.Generic.List[string]
$script:lastRc = $null

function Check([string]$name, [bool]$ok) {
    if ($ok) { $script:pass++; Write-Host ("  [PASS] " + $name) }
    else { $script:fail++; Write-Host ("  [FAIL] " + $name) }
}
function Section([string]$t) { Write-Host ""; Write-Host ("== " + $t) }

# 只留标记行：把原生命令的 PS 包装噪声与正常诊断剔掉 ✓（顺序保持 ✓）
function Clean([string]$s) {
    $out = @()
    if ($null -eq $s) { return "" }
    foreach ($l in ($s -split "`r?`n")) {
        if ($l -match '^\s*$') { continue }
        if ($l -match 'INTEGRITY_SKIPPED') { continue }
        if ($l -match 'CategoryInfo|FullyQualifiedErrorId|NativeCommandError') { continue }
        if ($l -match '^\s*\+') { continue }
        if ($l -match '^At ') { continue }
        if ($l -match '^所在位置') { continue }
        $out += $l.TrimEnd()
    }
    return ($out -join "`n")
}

# ★ 唯一的调用入口：rc 与文本**一定**成对返回 ✓（早期版本在调用点手写 $LASTEXITCODE，
#   处处漏赋值 → 断言形同虚设 ✗✓ 现在收成一个函数，漏不掉 ✓）
function Run-Cli([string]$exe, [string[]]$cmdArgs) {
    $raw = (Invoke-External { & $exe @cmdArgs }) | Out-String
    return @{ rc = $LASTEXITCODE; raw = $raw; out = (Clean $raw) }
}
# 合并 stderr 的变体：只给"需要断言 stderr 诚实行（SESSAGG_ROWDROP 等）"的用例用 ✓
# （Clean 已剔 ErrorRecord 包装噪声 ✓；其余用例照旧不合并 → stdout 标记面不被 stderr 稀释 ✓）
function Run-CliMerged([string]$exe, [string[]]$cmdArgs) {
    $raw = (Invoke-External { & $exe @cmdArgs 2>&1 }) | Out-String
    return @{ rc = $LASTEXITCODE; raw = $raw; out = (Clean $raw) }
}
function MarkLines([string]$clean, [string]$prefix) {
    return @(($clean -split "`n") | Where-Object { $_ -match ('^' + $prefix) })
}
function HasMarker([string]$clean, [string]$regex) {
    return (@(($clean -split "`n") | Where-Object { $_ -match $regex }).Count -gt 0)
}
# 从"最后一个 OK 标记行"取出它后面的路径 ✓（同时兼容 OK / FAIL 两种终态 ✓）
function LastMarkerPath([string]$clean, [string]$okPrefix, [string]$failPrefix) {
    $ok = @(MarkLines $clean $okPrefix)
    if ($ok.Count -gt 0) { return $ok[$ok.Count - 1].Substring($okPrefix.Length).Trim() }
    $bad = @(MarkLines $clean $failPrefix)
    if ($bad.Count -gt 0) { return $bad[$bad.Count - 1].Substring($failPrefix.Length).Trim() }
    return $null
}
# 路径的**规范化形式** ✓✓（CI 实测 run 37587237343 得到的一条纪律）：
#   PS 侧用 Join-Path 拼出来的路径 与 CLI 打印回来的路径 **可能只是字符串形式不同** ✗✓
#   → 任何"PS 侧路径 vs CLI 侧路径"的比较都必须**先规范化再做** ✓ 否则会误红 ✓
#   → 取不到就退回原样 ✓（不猜、不吞错 ✓；PS 5.1 对 `…\\…` 这类形式会抛 → 这里兜住 ✓）
function FullPathOrSelf([string]$p) {
    if ([string]::IsNullOrWhiteSpace($p)) { return "" }
    try { return [System.IO.Path]::GetFullPath($p) } catch { return $p }
}

# 造一个全新隔离夹具：数据根 + 备份根 + 工作区（三处都在隔离目录内 ✓）
function New-Fixture([string]$tag) {
    $iso = Join-Path $env:TEMP ("dsht_matrix_" + $tag + "_" + [guid]::NewGuid().ToString("N").Substring(0, 8))
    $dataRoot = Join-Path $iso "dsh"
    $bk = Join-Path $iso "bk"
    $ws = Join-Path $iso "ws"
    New-Item -ItemType Directory -Path (Join-Path $dataRoot "storages"), $bk, $ws -Force | Out-Null
    [System.IO.File]::WriteAllText((Join-Path $dataRoot "storages/a.txt"), "ALPHA`n")
    [System.IO.File]::WriteAllText((Join-Path $ws "ws-note.txt"), "WS`n")
    return @{ iso = $iso; home = $dataRoot; bk = $bk; ws = $ws }
}

# ---- 定位 CLI：优先显式 -Cli，否则用 Release 构建产物（**不自动构建**：与并行门槛抢 bin 会互相锁 ✗）----
$repoFull = (Resolve-Path -LiteralPath $Repo).Path
if ([string]::IsNullOrWhiteSpace($Cli)) {
    $cand = Join-Path $repoFull "v3\src\Dsht.Cli\bin\Release\net8.0\dsh-minato.exe"
    if (-not (Test-Path -LiteralPath $cand)) {
        $cand2 = Join-Path $repoFull "v3\src\Dsht.Cli\bin\Release\net8.0\dsh-minato"   # Linux
        if (Test-Path -LiteralPath $cand2) { $cand = $cand2 }
    }
    $Cli = $cand
}
if (-not (Test-Path -LiteralPath $Cli)) {
    Write-Host ("找不到 CLI：" + $Cli)
    Write-Host "先构建：dotnet build v3/src/Dsht.Cli/Dsht.Cli.csproj -c Release"
    exit 2
}
$Cli = (Resolve-Path -LiteralPath $Cli).Path

# 真实数据根快照：矩阵**只许**在隔离根里写 ✓ → 跑完证明真实数据根没被动过 ✓（与 gate5 同一手法 ✓）
function Get-RealRoots {
    $c = @()
    if ($env:USERPROFILE) { $c += (Join-Path $env:USERPROFILE ".dsh") }
    if ($env:APPDATA) { $c += (Join-Path $env:APPDATA ".dsh") }
    if ($env:LOCALAPPDATA) { $c += (Join-Path $env:LOCALAPPDATA ".dsh") }
    return $c
}
function Get-RootSnapshot([string]$root) {
    if (-not (Test-Path -LiteralPath $root)) { return "(absent)" }
    return ((Get-ChildItem -LiteralPath $root -Force -ErrorAction SilentlyContinue | Sort-Object Name | ForEach-Object {
                if ($_.PSIsContainer) { "D:" + $_.Name } else { "F:" + $_.Name + ":" + $_.Length } }) -join "|")
}

$realRoots = Get-RealRoots
$before = @{}
foreach ($r in $realRoots) { $before[$r] = (Get-RootSnapshot $r) }
$oldHome = $env:DSH_HOME
$script:isoList = New-Object System.Collections.Generic.List[string]

Write-Host "== 命令 × 隔离数据根 冒烟矩阵 =="
Write-Host ("  CLI : " + $Cli)
$ver = Run-Cli $Cli @("version")
Write-Host ("  版本: " + ($ver.out -replace "`n", " "))

try {
    # ------------------------------------------------------------------
    # 0) 矩阵自己的前置：**复位 CLI 的备份根选择** ✓✓
    #   为什么必须做：备份根是**粘性**的（`backup-dir --set` 把选择写进
    #     `<StateDir>/.backup-dir`，Windows 上 StateDir 就是 exe 所在目录）✗
    #   → 上一个用户 / 上一次矩阵留下的选择会让"隔离根"里冒出别人的备份包 ✗
    #     （真机实测：空 DSH_HOME 下 `backup-list` 报 `BACKUP_LIST_OK 1` ✗）
    #   → 复位后本矩阵只看得到**自己刚造的那些包** ✓ 用户照 VERIFY.md 跑也不会撞旧状态 ✓
    #   安全：这条命令只删 `<StateDir>/.backup-dir` 这一个文件 ✓ 不动数据根、不删备份包 ✓
    # ------------------------------------------------------------------
    Section "0. 前置：复位备份根选择（只影响 .backup-dir 这一个文件）"
    $f0 = New-Fixture "pre"; $script:isoList.Add($f0.iso)
    $env:DSH_HOME = $f0.home
    $rst = Run-Cli $Cli @("backup-dir", "--reset")
    Write-Host ("  -- backup-dir --reset   rc=" + $rst.rc)
    foreach ($l in (MarkLines $rst.out 'BACKUP_DIR' | Select-Object -First 2)) { Write-Host ("       " + $l) }
    Check "backup-dir --reset 成功（矩阵可重复、不受旧状态影响 ✓）" (HasMarker $rst.out '^BACKUP_DIR_(RESET|OK)')
    $bl0 = Run-Cli $Cli @("backup-list")
    Check "复位后隔离根里看不到任何旧备份（BACKUP_LIST_OK 0 ✓）" (HasMarker $bl0.out '^BACKUP_LIST_OK 0$')
    if (-not $Keep) { Remove-Item -LiteralPath $f0.iso -Recurse -Force -ErrorAction SilentlyContinue }

    # ------------------------------------------------------------------
    # 1) 只读命令面：每条都在隔离数据根下给出标记行 + 退出码
    # ------------------------------------------------------------------
    Section "1. 只读命令面（隔离数据根）"
    $f1 = New-Fixture "ro"; $script:isoList.Add($f1.iso)
    $env:DSH_HOME = $f1.home
    $cset = Run-Cli $Cli @("config-set", "ws", $f1.ws)     # 把工作区指进隔离目录 ✓
    Check "前置：config-set ws 成功（避免把仓库当工作区备份 ✗）" (HasMarker $cset.out '^CONFIGSET_OK')

    $roCases = @(
        @("version", @("version"), '^DSHT_VERSION [0-9]', '', 0),
        @("about", @("about"), '非官方|not affiliated|unofficial', '', 0),
        @("status", @("status"), '^STATUS_[A-Z]+', '', 0),
        @("sessions", @("sessions"), '^SESSIONS_(OK|FAIL)', '', 0),
        @("doctor", @("doctor"), '^DOCTOR_[A-Z]+', '', 0),
        @("config-get", @("config-get"), '^CONFIGGET_OK', '', 0),
        @("backup-list（空根）", @("backup-list"), '^BACKUP_LIST_OK [0-9]+', '', 0)
    )
    foreach ($c in $roCases) {
        $r = Run-Cli $Cli $c[1]
        Write-Host ("  -- " + $c[0] + "   rc=" + $r.rc)
        foreach ($l in (MarkLines $r.out '[A-Z]' | Select-Object -First 3)) { Write-Host ("       " + $l) }
        Check ($c[0] + " 打印标记行 /" + $c[2] + "/") (HasMarker $r.out $c[2])
        if ($c[3] -ne '') { Check ($c[0] + " 不该出现 /" + $c[3] + "/") (-not (HasMarker $r.out $c[3])) }
        if ($null -ne $c[4]) { Check ($c[0] + " 退出码 = " + $c[4]) ($r.rc -eq $c[4]) }
    }

    # ------------------------------------------------------------------
    # 1b) 看板第一批（2026-10-08 ✓✓ 规格 §11.1/§11.5 验收⑤ ✓✓）
    #   投影夹具形状 = live 写者同款（<根>\storages\session_projcache\sessions\<id>.json ✓ ver 逐键 ✓）
    #   相对时间：near = **今天本地正午**（曾经 = Now-6.5 天 → 凌晨/上午跑 -6.5 天落到今天-7 → 漂出 7 天窗口 eligible=0 ✗
    #             2026-10-09 05:20 实跑抓到 ✓ → 改为本地日正中：local day == today ⇒ 进 7/14/30 天窗口**与运行时刻无关** ✓✓）；
    #             far = 现在-40 天（只进总计档 ✓）；
    #             sessC 无 lastPromptAt → unknown_last=1 ✓ 不进窗口 ✓ 但计入 SESSAGG_TOTAL ✓
    #   断言全部是**精确整行**（数字逐个对 ✗ 不是"有标记就行" ✓✓）
    # ------------------------------------------------------------------
    Section "1b. 看板第一批：sessions --days/--level（隔离数据根 + 投影夹具）"
    $f1b = New-Fixture "board"; $script:isoList.Add($f1b.iso)
    $env:DSH_HOME = $f1b.home
    $cset1b = Run-Cli $Cli @("config-set", "ws", $f1b.ws)
    $today  = (Get-Date).Date
    $msNear = ([DateTimeOffset]$today.AddHours(12)).ToUnixTimeMilliseconds()
    $msFar  = [DateTimeOffset]::Now.AddDays(-40).ToUnixTimeMilliseconds()
    $from7  = $today.AddDays(-6).ToString('yyyy-MM-dd')
    $toDay  = $today.ToString('yyyy-MM-dd')
    $firstDay = [DateTimeOffset]::FromUnixTimeMilliseconds($msFar).LocalDateTime.ToString('yyyy-MM-dd')
    $lastDay  = [DateTimeOffset]::FromUnixTimeMilliseconds($msNear).LocalDateTime.ToString('yyyy-MM-dd')
    function Write-BoardProj([string]$root, [string]$id, [long]$createdMs, [string]$metaRows, [int]$un, [int]$cr, [int]$cw, [int]$ou, [int]$tu, [int]$st) {
        $dir = Join-Path (Join-Path (Join-Path $root "storages") "session_projcache") "sessions"
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        $json = '{"version":7,"record":{"identity":{"createdAt":' + $createdMs + ',"cwd":"D:\\w"},' +
            '"rows":{"sessionStats":{"ver":1,"seq":1,"val":{"turns":' + $tu + ',"steps":' + $st + ',"llmMs":100,"toolMs":0,"ttftMs":10,"decodeMs":100,"decodeTokens":50}},' +
            '"tokenUsage":{"ver":2,"val":{"totals":{"uncachedInputTokens":' + $un + ',"outputTokens":' + $ou + ',"cacheReadTokens":' + $cr + ',"cacheWriteTokens":' + $cw + '}}},' +
            $metaRows +
            '"title":{"ver":1,"val":"t-' + $id + '"}}}}'
        [System.IO.File]::WriteAllText((Join-Path $dir ($id + ".json")), $json, [System.Text.Encoding]::UTF8)
    }
    $metaNear = '"sessionListMetadata":{"ver":1,"val":{"blank":false,"lastPromptAt":' + $msNear + '}},' +
        '"contextBreakdown":{"ver":4,"val":{"breakdown":{"systemTokens":11,"toolsTokens":22,"messageTokens":33},"nodes":[]}},'   # ★ 第二批：ver4 实测嵌套形状 ✓ §11.6-A ✓
    $metaFar  = '"sessionListMetadata":{"ver":1,"val":{"blank":false,"lastPromptAt":' + $msFar + '}},' +
        '"contextBreakdown":{"ver":2,"val":{"systemTokens":111,"toolsTokens":222,"messageTokens":333}},'                          # ★ 第二批：ver2 实测扁平形状 ✓（51 条旧行同款 ✓）
    $metaNone = '"sessionListMetadata":{"ver":1,"val":{"blank":false}},'
    Write-BoardProj $f1b.home "aaaa0001" $msNear $metaNear 100 200 30 40 3 9
    Write-BoardProj $f1b.home "bbbb0002" $msFar  $metaFar  500 600 70 80 5 11
    Write-BoardProj $f1b.home "cccc0003" $msNear $metaNone 7 0 0 0 1 1
    # sessD：tokenUsage ver=1（与真实库 51 条旧投影同款 ✓ 验收③ 端到端 ✓）→ R5 行门丢弃 → 四桶 literal unknown
    #   + stderr SESSAGG_ROWDROP key=tokenUsage ver=1 n=1 ✓✓（turns/steps 不受影响 ✓ 门是**逐键**的 ✓）
    $jsonD = '{"version":7,"record":{"identity":{"createdAt":' + $msFar + ',"cwd":"D:\\w"},' +
        '"rows":{"sessionStats":{"ver":1,"seq":1,"val":{"turns":2,"steps":3,"llmMs":100,"toolMs":0,"ttftMs":10,"decodeMs":100,"decodeTokens":50}},' +
        '"tokenUsage":{"ver":1,"val":{"totals":{"uncachedInputTokens":9,"outputTokens":9,"cacheReadTokens":9,"cacheWriteTokens":9}}},' +
        '"sessionListMetadata":{"ver":1,"val":{"blank":false,"lastPromptAt":' + $msFar + '}},' +
        '"title":{"ver":1,"val":"t-dddd0004"}}}}'
    [System.IO.File]::WriteAllText((Join-Path (Join-Path (Join-Path (Join-Path $f1b.home "storages") "session_projcache") "sessions") "dddd0004.json"), $jsonD, [System.Text.Encoding]::UTF8)

    # -- --days 7：窗口 [今天-6, 明天) 左闭右开 → 只有 aaaa0001 eligible --
    $s7 = Run-Cli $Cli @("sessions", "--days", "7")
    Write-Host ("  -- sessions --days 7   rc=" + $s7.rc)
    foreach ($l in (MarkLines $s7.out 'SESSWIN_META|SESSAGG_' | Select-Object -First 4)) { Write-Host ("       " + $l) }
    Check "1b --days 7 退出码 = 0" ($s7.rc -eq 0)
    Check "1b --days 7 SESSIONS_OK 4（列表不过滤 ✓ 含待拒的 sessD ✓）" (HasMarker $s7.out '^SESSIONS_OK 4$')
    Check "1b --days 7 SESSWIN_META 精确整行（eligible=1 · unknown_last=1 · truth=0 ✓ 第三批尾键 lineage=none fork_sessions=unknown ✓）" `
        (HasMarker $s7.out ('^SESSWIN_META days=7 from=' + $from7 + ' to=' + $toDay + ' tz=.+ truth=0 level=global source=disk scanned=4 eligible=1 unknown_last=1 lineage=none fork_sessions=unknown$'))
    Check "1b --days 7 SESSAGG_TOTAL 精确整行（无视窗口 ✓ 三**有效**会话求和 607/800/100/120 ✓ sessD 四桶被门拒 → 不进求和 ✗ 不假装 0 ✓）" `
        (HasMarker $s7.out ('^SESSAGG_TOTAL scope=store sessions=4 nonblank=4 uncached=607 cacheRead=800 cacheWrite=100 output=120 first_day=' + $firstDay + ' last_day=' + $lastDay + ' truth=0$'))
    $aggRows7 = @(MarkLines $s7.out '^SESSAGG_SESSION ')
    Check "1b --days 7 SESSAGG_SESSION 恰 1 行且内容精确（只有近窗口会话 ✓ children/depth=unknown ✓）" `
        ($aggRows7.Count -eq 1 -and $aggRows7[0] -eq 'SESSAGG_SESSION aaaa0001 bucket=own turns=3 steps=9 uncached=100 cacheRead=200 cacheWrite=30 output=40 children=unknown depth=unknown')
    Check "1b --days 7 SESSION 明细行仍 4 条（KPI 用 ✓ 不被窗口吃掉 ✓）" (@(MarkLines $s7.out '^SESSION ').Count -eq 4)
    # ★ 看板第二批（2026-10-09 ✓✓ 规格 §11.6-B ✓）：SESSTIME_SESSION / SESSCTX_SESSION 与 SESSAGG_SESSION **同一 eligible 集** ✓
    $timeRows7 = @(MarkLines $s7.out '^SESSTIME_SESSION ')
    Check "1b --days 7 SESSTIME_SESSION 恰 1 行且内容精确（sessionStats ver=1 四件 ✓ 零值照打数字 ✓）" `
        ($timeRows7.Count -eq 1 -and $timeRows7[0] -eq 'SESSTIME_SESSION aaaa0001 llmMs=100 toolMs=0 ttftMs=10 decodeMs=100')
    $ctxRows7 = @(MarkLines $s7.out '^SESSCTX_SESSION ')
    Check "1b --days 7 SESSCTX_SESSION 恰 1 行且内容精确（ver=4 **嵌套** val.breakdown 三桶 11/22/33 ✓ §11.6-A ✓）" `
        ($ctxRows7.Count -eq 1 -and $ctxRows7[0] -eq 'SESSCTX_SESSION aaaa0001 system=11 tools=22 message=33')

    # -- 不带 --days（总计档）：days=unknown · eligible=全部 · SESSAGG_SESSION 全量（窗口卡==总计卡 ✓ 硬要求 ✓）--
    #    用合并 stderr 的入口 ✓（SESSAGG_ROWDROP 是 stderr 诚实行 ✗ 不污染 stdout 标记面 ✓ → 断言它必须合并流才看得到 ✓）
    $sAll = Run-CliMerged $Cli @("sessions")
    Check "1b 总计档 SESSWIN_META 精确整行（days=unknown · from/to=- · eligible=4 · unknown_last=1 ✓）" `
        (HasMarker $sAll.out '^SESSWIN_META days=unknown from=- to=- tz=.+ truth=0 level=global source=disk scanned=4 eligible=4 unknown_last=1 lineage=none fork_sessions=unknown$')
    $aggRowsAll = @(MarkLines $sAll.out '^SESSAGG_SESSION ')
    Check "1b 总计档 SESSAGG_SESSION 全量 4 行（含无 lastPromptAt 的 sessC ✓ 只报告不排除 ✓）" ($aggRowsAll.Count -eq 4)
    Check "1b 验收③ 端到端：sessD（tokenUsage ver=1）四桶 literal unknown · turns/steps 照读 ✓（R5 逐键行门 ✓✓）" `
        (@($aggRowsAll | Where-Object { $_ -eq 'SESSAGG_SESSION dddd0004 bucket=own turns=2 steps=3 uncached=unknown cacheRead=unknown cacheWrite=unknown output=unknown children=unknown depth=unknown' }).Count -eq 1)
    Check "1b 验收③ 端到端：stderr SESSAGG_ROWDROP key=tokenUsage ver=2 n=1（行门丢弃**可见** ✓ ver=期望版本 ✓ 规格 §11.1 ✓）" `
        (HasMarker $sAll.out '^SESSAGG_ROWDROP key=tokenUsage ver=2 n=1$')
    # ★ 看板第二批（总计档 ✓ 与 SESSAGG_SESSION 一一对应 ✓ 缺行 → literal unknown ✗ 不猜 ✓✓）
    $timeRowsAll = @(MarkLines $sAll.out '^SESSTIME_SESSION ')
    $ctxRowsAll = @(MarkLines $sAll.out '^SESSCTX_SESSION ')
    Check "1b 总计档 SESSTIME_SESSION 全量 4 行（== SESSAGG_SESSION 数 ✓ 同一 eligible 集 ✓）" ($timeRowsAll.Count -eq 4)
    Check "1b 总计档 SESSCTX_SESSION 全量 4 行（== SESSAGG_SESSION 数 ✓）" ($ctxRowsAll.Count -eq 4)
    Check "1b 总计档 SESSCTX ver=2 **扁平**形状端到端（bbbb0002 → 111/222/333 ✓ 与线上 51 条旧行同款 ✓ §11.6-A ✓）" `
        (@($ctxRowsAll | Where-Object { $_ -eq 'SESSCTX_SESSION bbbb0002 system=111 tools=222 message=333' }).Count -eq 1)
    Check "1b 总计档 SESSCTX 缺 contextBreakdown → literal unknown（cccc0003/dddd0004 ✗ 不假装 0 ✓✓）" `
        (@($ctxRowsAll | Where-Object { $_ -eq 'SESSCTX_SESSION cccc0003 system=unknown tools=unknown message=unknown' }).Count -eq 1 -and
         @($ctxRowsAll | Where-Object { $_ -eq 'SESSCTX_SESSION dddd0004 system=unknown tools=unknown message=unknown' }).Count -eq 1)
    Check "1b 总计档 SESSTIME 四件照打（dddd0004 有 sessionStats ver=1 → 数字 ✓ 门不连坐 ✓）" `
        (@($timeRowsAll | Where-Object { $_ -eq 'SESSTIME_SESSION dddd0004 llmMs=100 toolMs=0 ttftMs=10 decodeMs=100' }).Count -eq 1)

    # -- --days 14：-6.5 天仍在窗内 → eligible=1 --
    $s14 = Run-Cli $Cli @("sessions", "--days", "14")
    Check "1b --days 14 eligible=1（近会话在 · 远会话出 ✓）" (HasMarker $s14.out '^SESSWIN_META days=14 .+ eligible=1 unknown_last=1 lineage=none fork_sessions=unknown$')

    # -- 非法 --days / --level：FAIL + SESSWIN_META(source=unknown 计数全 0) 先于 SESSIONS_FAIL · rc=0（与既有 FAIL 一致 ✓）--
    $sBad = Run-Cli $Cli @("sessions", "--days", "99")
    $badMeta = @(MarkLines $sBad.out '^SESSWIN_META ')
    $badFail = @(MarkLines $sBad.out '^SESSIONS_FAIL ')
    Check "1b --days 99 → rc=0 + SESSIONS_FAIL" ($sBad.rc -eq 0 -and $badFail.Count -eq 1)
    Check "1b --days 99 SESSWIN_META(level=unknown · source=unknown · 计数全 0) 在 SESSIONS_FAIL **之前**（顺序敏感 ✓ 规格 §11.1/§11.7 ✓）" `
        ($badMeta.Count -eq 1 -and $badMeta[0] -match '^SESSWIN_META days=unknown from=- to=- tz=.+ truth=0 level=unknown source=unknown scanned=0 eligible=0 unknown_last=0 lineage=none fork_sessions=unknown$' -and $sBad.out.IndexOf($badMeta[0]) -lt $sBad.out.IndexOf($badFail[0]))
    $sLv = Run-Cli $Cli @("sessions", "--level", "parents")
    $lvMeta = @(MarkLines $sLv.out '^SESSWIN_META ')
    $lvFail = @(MarkLines $sLv.out '^SESSIONS_FAIL ')
    Check "1b --level parents（无血缘）→ rc=0 + SESSIONS_FAIL（第三批降级口径：lineage=none ⇒ 非 global 档如实拒 ✓ 规格 §11.7-D ✓）" ($sLv.rc -eq 0 -and $lvFail.Count -eq 1)
    Check "1b --level parents SESSWIN_META 打**请求档+实扫数**且先于 FAIL（血缘缺失 → 明说 ✗ 不编数字 ✓✓ 规格 §11.7-D ✓）" `
        ($lvMeta.Count -eq 1 -and $lvMeta[0] -match '^SESSWIN_META days=unknown from=- to=- tz=.+ truth=0 level=parents source=disk scanned=4 eligible=0 unknown_last=0 lineage=none fork_sessions=unknown$' -and $sLv.out.IndexOf($lvMeta[0]) -lt $sLv.out.IndexOf($lvFail[0]))

    # -- 默认口径配置键接线（sessions_default_level ✓ 第一批只认 global → 配成 parents 如实 FAIL ✓）--
    $cfg1 = Run-Cli $Cli @("config-set", "sessions_default_level", "parents")
    $sCfg = Run-Cli $Cli @("sessions")
    Check "1b sessions_default_level=parents 生效 → 默认档如实 FAIL（配置键真的接线 ✓）" ((HasMarker $cfg1.out '^CONFIGSET_OK') -and (HasMarker $sCfg.out '^SESSIONS_FAIL '))
    $cfg2 = Run-Cli $Cli @("config-set", "sessions_default_level", "global")
    $sCfg2 = Run-Cli $Cli @("sessions")
    Check "1b 恢复 global 后默认档恢复 OK（不留脏配置 ✓）" ((HasMarker $cfg2.out '^CONFIGSET_OK') -and (HasMarker $sCfg2.out '^SESSIONS_OK 4$'))

    # ------------------------------------------------------------------
    # 1c) 看板第三批（2026-10-09 ✓✓ 规格 §11.7 验收①的 CLI 面 ✓✓）：血缘口径三档 + 自定义区间
    #   夹具 = 桥快照（sessions 空数组 ⇒ 数据仍走磁盘 ✓ lineage 段被消费 ✓ §11.7-A.5 ✓ formatVersion 仍 2 ✓）
    #          + 磁盘投影三会话：根 aaaa0010 / 子代理 bbbb0010 / fork cccc0010（origin=fork ✓ §B：计入父 sub ✓ 不进父+子 ✓）
    #   sub 行闭包和：turns=3+2+1=6 · steps=6+4+1=11 · uncached=100+10+1=111 · cacheRead=56 · cacheWrite=11 · output=23 ✓
    # ------------------------------------------------------------------
    Section "1c. 看板第三批：血缘口径 + 自定义区间（隔离数据根 + 血缘快照夹具）"
    $f3 = New-Fixture "board3"; $script:isoList.Add($f3.iso)
    $env:DSH_HOME = $f3.home
    $cset3 = Run-Cli $Cli @("config-set", "ws", $f3.ws)
    Check "1c 前置：config-set ws 成功" (HasMarker $cset3.out '^CONFIGSET_OK')
    Write-BoardProj $f3.home "aaaa0010" $msNear $metaNear 100 50 10 20 3 6
    Write-BoardProj $f3.home "bbbb0010" $msNear $metaNear 10 5 1 2 2 4
    Write-BoardProj $f3.home "cccc0010" $msNear $metaNear 1 1 0 1 1 1
    $snapDir3 = Join-Path $f3.home "shio-bridge"
    New-Item -ItemType Directory -Path $snapDir3 -Force | Out-Null
    $snapJson3 = '{ "formatVersion": 2, "generatedAt": "2026-01-01T00:00:00.000Z", "intervalMs": 3000, "sessions": [], ' +
        '"lineage": { "errors": 0, "sessions": { "aaaa0010": {}, ' +
        '"bbbb0010": { "origin": "subagent", "parent": "aaaa0010", "createdAt": 1735689600000 }, ' +
        '"cccc0010": { "origin": "fork", "parent": "aaaa0010" } } } }'
    [System.IO.File]::WriteAllText((Join-Path $snapDir3 "sessions.json"), $snapJson3, [System.Text.Encoding]::UTF8)

    $sPs = Run-Cli $Cli @("sessions", "--days", "7", "--level", "parents_sub")
    Write-Host ("  -- sessions --days 7 --level parents_sub   rc=" + $sPs.rc)
    foreach ($l in (MarkLines $sPs.out 'SESSWIN_META|SESSAGG_SESSION' | Select-Object -First 5)) { Write-Host ("       " + $l) }
    Check "1c parents_sub SESSWIN_META 三新键（level=parents_sub · lineage=ok · fork_sessions=1 ✓ eligible=2 ✓）" `
        (HasMarker $sPs.out '^SESSWIN_META days=7 .+ level=parents_sub source=disk scanned=3 eligible=2 unknown_last=0 lineage=ok fork_sessions=1$')
    Check "1c parents_sub 父会话 sub 行精确整行（闭包含 fork ✓ §B ✓ members=3 ✓ children=2 ✓ depth=0 ✓）" `
        (HasMarker $sPs.out '^SESSAGG_SESSION aaaa0010 bucket=sub turns=6 steps=11 uncached=111 cacheRead=56 cacheWrite=11 output=23 children=2 depth=0 members=3 sub_unknown=0 sub_unknown_stats=0$')
    Check "1c parents_sub 叶子 B.4 自校验行（children=0 ⇒ sub 六字段与 own 逐字节相等 ✓✓）" `
        ((HasMarker $sPs.out '^SESSAGG_SESSION bbbb0010 bucket=own turns=2 steps=4 uncached=10 cacheRead=5 cacheWrite=1 output=2 children=0 depth=1$') `
        -and (HasMarker $sPs.out '^SESSAGG_SESSION bbbb0010 bucket=sub turns=2 steps=4 uncached=10 cacheRead=5 cacheWrite=1 output=2 children=0 depth=1 members=1 sub_unknown=0 sub_unknown_stats=0$'))
    Check "1c parents_sub：子代理 own 行在 ✓ fork 被排除（origin≠subagent 且非孤儿 ⇒ 不进 ✓ §B ✓）" `
        ((HasMarker $sPs.out '^SESSAGG_SESSION bbbb0010 bucket=own ') -and -not (HasMarker $sPs.out '^SESSAGG_SESSION cccc0010 '))

    $sPar = Run-Cli $Cli @("sessions", "--days", "7", "--level", "parents")
    Check "1c --level parents：只剩根（eligible=1 ✓ 子代理/fork 都排除 ✓）" `
        ((HasMarker $sPar.out '^SESSWIN_META days=7 .+ level=parents .+ eligible=1 .+ lineage=ok fork_sessions=1$') `
        -and (HasMarker $sPar.out '^SESSAGG_SESSION aaaa0010 bucket=own ') -and -not (HasMarker $sPar.out '^SESSAGG_SESSION bbbb0010 '))
    $sGlb = Run-Cli $Cli @("sessions", "--days", "7", "--level", "global")
    Check "1c --level global：三会话全进（eligible=3 ✓ fork 在全局 ✓ §B ✓）" `
        ((HasMarker $sGlb.out 'eligible=3') -and (HasMarker $sGlb.out '^SESSAGG_SESSION cccc0010 bucket=own '))

    # 降级：无血缘快照 + 非 global 档 ⇒ SESSIONS_FAIL + stderr 明说（§11.7-D ✓ GUI 照显原文 ✓）
    $f4 = New-Fixture "board3n"; $script:isoList.Add($f4.iso)
    $env:DSH_HOME = $f4.home
    Write-BoardProj $f4.home "aaaa0010" $msNear $metaNear 100 50 10 20 3 6
    $sDeg = Run-CliMerged $Cli @("sessions", "--days", "7", "--level", "parents_sub")
    Check "1c 降级：无血缘 + parents_sub ⇒ FAIL + SESSAGG_LINEAGE stderr（✗ 不拿投影冒充 ✓✓）" `
        ($sDeg.rc -eq 0 -and (HasMarker $sDeg.out '^SESSIONS_FAIL ') -and (HasMarker $sDeg.out 'SESSAGG_LINEAGE'))
    $env:DSH_HOME = $f3.home

    # D4 自定义区间：正例 + 三负例（互斥/单端/坏格式 ✓ ✗ 不猜 ✗ 不补端点 ✓）
    $sCu = Run-Cli $Cli @("sessions", "--from", $from7, "--to", $toDay)
    Check "1c --from/--to 正例：OK + days=unknown + from/to 原样回打 + eligible=3（含端点闭区间 ✓）" `
        ((HasMarker $sCu.out '^SESSIONS_OK ') `
        -and (HasMarker $sCu.out ('^SESSWIN_META days=unknown from=' + $from7 + ' to=' + $toDay + ' .+ scanned=3 eligible=3 unknown_last=0 lineage=ok fork_sessions=1$')))
    $sMx = Run-Cli $Cli @("sessions", "--days", "7", "--from", $from7, "--to", $toDay)
    Check "1c --from/--to 与 --days 互斥 ⇒ FAIL" ($sMx.rc -eq 0 -and (HasMarker $sMx.out '^SESSIONS_FAIL '))
    $sOne = Run-Cli $Cli @("sessions", "--from", $from7)
    Check "1c --from 单端（缺 --to）⇒ FAIL（✗ 不默认补端点 ✓）" ($sOne.rc -eq 0 -and (HasMarker $sOne.out '^SESSIONS_FAIL '))
    $sBad2 = Run-Cli $Cli @("sessions", "--from", "2026/10/01", "--to", $toDay)
    Check "1c --from 坏格式 ⇒ FAIL（只认 yyyy-MM-dd ✓）" ($sBad2.rc -eq 0 -and (HasMarker $sBad2.out '^SESSIONS_FAIL '))

    # ------------------------------------------------------------------
    # 1d) 成本面板 v3.2（2026-10-16 ✓✓ 规格 §3 + §3.1 ✓ 契约：scope=today|window 两块）
    #   夹具：aaaa0001（今日 · 100/200/30/40 · decodeTokens=50 ≠ output=40 · model=test-model）
    #         bbbb0002（40 天前 · 500/600/70/80）
    #         cccc0003（无 lastPromptAt ⇒ unknown_last=1 ✓ 不进任何窗口）
    #         dddd0004（今日 · tokenUsage ver=1 ⇒ 行门拒 ⇒ 四桶 unknown ⇒ cost=none 的第三种来源 ✓）
    #   手算期望（价 in=1 / cacheRead=2 / cacheWrite=3 / out=4）：100×1+200×2+30×3+40×4 = 750 → 0.000750 ✓
    #     · 按 decode 算则是 50×4 = 200 → 0.000200 ✗ 验收④：断言必须等于前者、且不等于后者 ✓
    #   ★ config-set 写的是**exe 同级 launcher.config**（StateDir ✓ 不随 DSH_HOME 隔离 ✗）
    #     ⇒ 本节的 5 个键**用完立刻复位 0** ✓（开头也先复位一次：把上次跑崩留下的值清掉 ✓）
    # ------------------------------------------------------------------
    Section "1d. 成本面板：cost（未配价 / 配价 / 窗口集合一致 / 零写入 / 预算）"
    $f1d = New-Fixture "cost"; $script:isoList.Add($f1d.iso)
    $env:DSH_HOME = $f1d.home
    $costKeys = @('sessions_price_in_per_mtok', 'sessions_price_cache_read_per_mtok', 'sessions_price_cache_write_per_mtok', 'sessions_price_out_per_mtok', 'sessions_budget_usd_per_day')
    foreach ($k in $costKeys) { Run-Cli $Cli @("config-set", $k, "0") | Out-Null }   # 先复位（自愈上次跑崩 ✓）
    function Write-CostProj([string]$root, [string]$id, [long]$created, [string]$meta, [int]$un, [int]$cr, [int]$cw, [int]$ou, [long]$decode, [string]$model) {
        $dir = Join-Path (Join-Path (Join-Path $root "storages") "session_projcache") "sessions"
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        $json = '{"version":7,"record":{"identity":{"createdAt":' + $created + ',"cwd":"D:\\w"},' +
            '"rows":{"sessionStats":{"ver":1,"seq":1,"val":{"turns":3,"steps":9,"llmMs":100,"toolMs":0,"ttftMs":10,"decodeMs":100,"decodeTokens":' + $decode + '}},' +
            '"tokenUsage":{"ver":2,"val":{"totals":{"uncachedInputTokens":' + $un + ',"outputTokens":' + $ou + ',"cacheReadTokens":' + $cr + ',"cacheWriteTokens":' + $cw + '}}},' +
            $meta + $model + '"title":{"ver":1,"val":"t-' + $id + '"}}}}'
        [System.IO.File]::WriteAllText((Join-Path $dir ($id + ".json")), $json, [System.Text.Encoding]::UTF8)
    }
    $cMetaNear = '"sessionListMetadata":{"ver":1,"val":{"blank":false,"lastPromptAt":' + $msNear + '}},'
    $cMetaFar  = '"sessionListMetadata":{"ver":1,"val":{"blank":false,"lastPromptAt":' + $msFar + '}},'
    $cMetaNone = '"sessionListMetadata":{"ver":1,"val":{"blank":false}},'
    $cModelA = '"modelSelection":{"ver":2,"seq":52,"val":{"lastUsed":{"provider":"p","model":"test-model","reasoningEffort":"max"},"pending":null}},'
    $cModelNo = '"modelSelection":{"ver":2,"seq":52,"val":{"lastUsed":null,"pending":null}},'
    Write-CostProj $f1d.home "aaaa0001" $msNear $cMetaNear 100 200 30 40 50 $cModelA
    Write-CostProj $f1d.home "bbbb0002" $msFar  $cMetaFar  500 600 70 80 50 $cModelNo   # 远：不进 7 天窗口（但进总计档 ✓）
    Write-CostProj $f1d.home "cccc0003" $msNear $cMetaNone 7 0 0 0 50 $cModelNo          # 无锚点 ⇒ 只计 unknown_last ✓
    # dddd0004：tokenUsage ver=1（旧行 ✓ 与真实库 51 条同款）→ R5 行门拒 → 四桶 literal unknown
    [System.IO.File]::WriteAllText((Join-Path (Join-Path (Join-Path (Join-Path $f1d.home "storages") "session_projcache") "sessions") "dddd0004.json"),
        ('{"version":7,"record":{"identity":{"createdAt":' + $msNear + ',"cwd":"D:\\w"},' +
         '"rows":{"sessionStats":{"ver":1,"seq":1,"val":{"turns":2,"steps":3,"decodeTokens":9}},' +
         '"tokenUsage":{"ver":1,"val":{"totals":{"uncachedInputTokens":9,"outputTokens":9,"cacheReadTokens":9,"cacheWriteTokens":9}}},' +
         $cMetaNear + $cModelNo + '"title":{"ver":1,"val":"t-dddd0004"}}}}'), [System.Text.Encoding]::UTF8)
    # 血缘段（快照 sessions 空 ✓ 只为让非 global 档可用 ⇒ 验 budget-scope-global ✓）
    # ★ 快照路径是 <根>\shio-bridge\sessions.json（WindowsSessionStatsSource.SnapshotPath ✓ ✗ 不是 storages ✗）
    $snapDir1d = Join-Path $f1d.home "shio-bridge"
    New-Item -ItemType Directory -Path $snapDir1d -Force | Out-Null
    $snapNow = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
    [System.IO.File]::WriteAllText((Join-Path $snapDir1d "sessions.json"),
        ('{ "formatVersion": 2, "generatedAt": "' + $snapNow + '", "intervalMs": 3000, "sessions": [], "lineage": { "errors": 0, "sessions": { "aaaa0001": {}, "dddd0004": {} } } }'),
        [System.Text.Encoding]::UTF8)

    # -- ① 未配价：不出现任何金额 + COST_NOTE price-missing + 两个 scope 的 META --
    $snapBefore1d = @(Get-ChildItem -Recurse -File -Force $f1d.iso | Sort-Object FullName | ForEach-Object { $_.FullName + ':' + $_.Length })
    $cUn = Run-Cli $Cli @("cost", "--days", "7", "--level", "global")
    $snapAfter1d = @(Get-ChildItem -Recurse -File -Force $f1d.iso | Sort-Object FullName | ForEach-Object { $_.FullName + ':' + $_.Length })
    Write-Host ("  -- cost --days 7（未配价）   rc=" + $cUn.rc)
    foreach ($l in (MarkLines $cUn.out '^COST_' | Select-Object -First 4)) { Write-Host ("       " + $l) }
    Check "1d 未配价 cost 退出码 = 0（只读命令 ✓）" ($cUn.rc -eq 0)
    Check "1d 未配价 COST_META scope=window 精确整行（priced=0 · unknown_last=1 · model_unknown=1 ✓）" `
        (HasMarker $cUn.out ('^COST_META scope=window days=7 from=' + $from7 + ' to=' + $toDay + ' level=global priced=0 currency=USD tz=.+ truth=0 unknown_last=1 model_unknown=1$'))
    Check "1d 未配价 COST_META scope=today 精确整行（from=to=今天 · level=global ✓）" `
        (HasMarker $cUn.out ('^COST_META scope=today days=unknown from=' + $toDay + ' to=' + $toDay + ' level=global priced=0 currency=USD tz=.+ truth=0 unknown_last=1 model_unknown=1$'))
    Check "1d 未配价 COST_TOTAL scope=window 精确整行（只有 aaaa0001 的已知 token ✓ cost=none ✓）" `
        (HasMarker $cUn.out '^COST_TOTAL scope=window uncached=100 cacheRead=200 cacheWrite=30 output=40 tokens=370 cost=none$')
    Check "1d 未配价 COST_TOTAL scope=today 与 window 同值（今日=窗口=aaaa0001 ✓）" `
        (HasMarker $cUn.out '^COST_TOTAL scope=today uncached=100 cacheRead=200 cacheWrite=30 output=40 tokens=370 cost=none$')
    Check "1d 未配价：COST_SESSION 里 model= 打出来（test-model ✓ / 无模型 ⇒ unknown ✓）" `
        ((HasMarker $cUn.out '^COST_SESSION scope=window aaaa0001 model=test-model uncached=100 cacheRead=200 cacheWrite=30 output=40 cost=none$') `
        -and (HasMarker $cUn.out '^COST_SESSION scope=window dddd0004 model=unknown uncached=unknown cacheRead=unknown cacheWrite=unknown output=unknown cost=none$'))
    Check "1d 未配价：**任何金额都不出现**（✗ 断言全输出无 cost=<数字> ✓ 验收① ✓）" `
        (-not (HasMarker $cUn.out 'cost=[0-9]'))
    Check "1d 未配价：COST_NOTE price-missing 出现（验收① ✓）" (HasMarker $cUn.out '^COST_NOTE price-missing$')
    Check "1d 未配价：COST_BUDGET limit=none spent=none over=0（未设上限 + 未配价 ⇒ 不判定 ✓）" `
        (HasMarker $cUn.out '^COST_BUDGET limit=none spent=none over=0$')
    Check "1d 零写入：隔离根前后逐字一致（验收⑤ ✓ 只读 ✓）" (($snapBefore1d -join '|') -eq ($snapAfter1d -join '|'))
    # 验收③：窗口集合与 sessions 的 SESSAGG_SESSION bucket=own **逐 id 一致**
    $sWin1d = Run-Cli $Cli @("sessions", "--days", "7", "--level", "global")
    $ownIds1d = @(MarkLines $sWin1d.out '^SESSAGG_SESSION ' | Where-Object { $_ -match ' bucket=own ' } | ForEach-Object { ($_ -split ' ')[1] } | Sort-Object)
    $costIds1d = @(MarkLines $cUn.out '^COST_SESSION scope=window ' | ForEach-Object { ($_ -split ' ')[2] } | Sort-Object)
    Check "1d 验收③ 窗口集合逐 id 一致（cost scope=window ↔ SESSAGG_SESSION bucket=own ✓ 2 个）" `
        ($ownIds1d.Count -eq 2 -and (($ownIds1d -join ',') -eq ($costIds1d -join ',')))

    # -- ② 配价：金额逐笔相等（手算 0.000750）+ decode 反例 + 预算超限 + 第三种 none 来源 --
    foreach ($kv in @(@('sessions_price_in_per_mtok', '1'), @('sessions_price_cache_read_per_mtok', '2'), @('sessions_price_cache_write_per_mtok', '3'), @('sessions_price_out_per_mtok', '4'), @('sessions_budget_usd_per_day', '0.0005'))) {
        Run-Cli $Cli @("config-set", $kv[0], $kv[1]) | Out-Null
    }
    $cPr = Run-Cli $Cli @("cost", "--days", "7", "--level", "global")
    Write-Host ("  -- cost --days 7（已配价 in=1/cr=2/cw=3/out=4）   rc=" + $cPr.rc)
    foreach ($l in (MarkLines $cPr.out '^COST_(TOTAL|BUDGET|NOTE)' | Select-Object -First 5)) { Write-Host ("       " + $l) }
    Check "1d 配价 COST_META priced=1" (HasMarker $cPr.out '^COST_META scope=window days=7 .+ priced=1 currency=USD tz=.+ truth=0 unknown_last=1 model_unknown=1$')
    Check "1d 配价 COST_TOTAL scope=window 金额手算相等（750/1e6 = 0.00075 ✓ 验收② ✓ 往返精度形态 ✓）" `
        (HasMarker $cPr.out '^COST_TOTAL scope=window uncached=100 cacheRead=200 cacheWrite=30 output=40 tokens=370 cost=0.00075$')
    Check "1d 验收④ 算钱只用 output：0.00075（**不是** 按 decodeTokens=50 的 0.0002 ✗）" `
        ((HasMarker $cPr.out 'cost=0.00075$') -and (-not (HasMarker $cPr.out 'cost=0.0002$')))
    Check "1d 配价 COST_SESSION 逐笔金额（aaaa0001 = 0.00075 · dddd0004 token 未知 ⇒ cost=none ✗ 不假装 0 ✓）" `
        ((HasMarker $cPr.out '^COST_SESSION scope=window aaaa0001 model=test-model uncached=100 cacheRead=200 cacheWrite=30 output=40 cost=0.00075$') `
        -and (HasMarker $cPr.out '^COST_SESSION scope=window dddd0004 model=unknown uncached=unknown cacheRead=unknown cacheWrite=unknown output=unknown cost=none$'))
    Check "1d 第三种 none 来源可见：COST_NOTE session-cost-unavailable n=1（配了价但有 1 笔算不了 ✓）" `
        (HasMarker $cPr.out '^COST_NOTE session-cost-unavailable n=1$')
    Check "1d 预算超限：limit=0.0005 spent=0.00075 over=1（0.00075 > 0.0005 ✓）" `
        (HasMarker $cPr.out '^COST_BUDGET limit=0.0005 spent=0.00075 over=1$')
    Check "1d 配价：price-missing **消失**（已配价 ✓）" (-not (HasMarker $cPr.out '^COST_NOTE price-missing$'))
    Check "1d 恒有两条如实说明（不对官方账单 / 模型是近似 ✓）" `
        ((HasMarker $cPr.out '^COST_NOTE official-billing-not-compared$') -and (HasMarker $cPr.out '^COST_NOTE model-approximate$'))
    # 非 global 档：预算行恒全局 ⇒ 必须自报 COST_NOTE budget-scope-global（规格 §3.1-③ ✓）
    $cPar = Run-Cli $Cli @("cost", "--days", "7", "--level", "parents")
    Check "1d 非 global 档：COST_NOTE budget-scope-global 出现 + 预算行仍是全局今日（spent 不变 ✓）" `
        ((HasMarker $cPar.out '^COST_NOTE budget-scope-global$') -and (HasMarker $cPar.out '^COST_BUDGET limit=0.0005 spent=0.00075 over=1$') `
        -and (HasMarker $cPar.out '^COST_META scope=window days=7 .+ level=parents .+$'))
    # 参数面与 sessions 同形（成对/互斥/格式 ✓ 失败只打 COST_FAIL ✗ 不打半截数字 ✓）
    $cBad = Run-Cli $Cli @("cost", "--days", "99")
    $cMx = Run-Cli $Cli @("cost", "--days", "7", "--from", $from7, "--to", $toDay)
    $cOne = Run-Cli $Cli @("cost", "--from", $from7)
    Check "1d 参数：坏 --days / 互斥 / 单端 ⇒ COST_FAIL（✗ 不打半截 COST_TOTAL ✓）" `
        ($cBad.rc -eq 0 -and (HasMarker $cBad.out '^COST_FAIL ') -and (-not (HasMarker $cBad.out '^COST_TOTAL ')) `
        -and (HasMarker $cMx.out '^COST_FAIL ') -and (HasMarker $cOne.out '^COST_FAIL '))
    # -- 复位 5 个键（✗ 别把测试价留在**共享的** exe 同级配置里 ✗）--
    foreach ($k in $costKeys) { Run-Cli $Cli @("config-set", $k, "0") | Out-Null }
    $cReset = Run-Cli $Cli @("config-get")
    $cResetLines = @(MarkLines $cReset.out '^CONFIG (sessions_price_|sessions_budget_usd_per_day)')
    Check "1d 复位：5 个键全部回 0（共享配置不残留测试价 ✓）" `
        ($cResetLines.Count -eq 5 -and -not (HasMarker $cReset.out '^CONFIG (sessions_price_|sessions_budget_usd_per_day) [1-9]'))

    # ------------------------------------------------------------------
    # 1e) 数据正确性：会话 id 归一（2026-10-16 修复 ✓ 勘察 + 复核已冻结的必测用例）
    #   夹具（冻结 ✓）：磁盘一份**裸 id** 父会话 pppp0001（父文件里带 childId=cccc0009 ✓ dsh 的真实记法）
    #                  + 磁盘一份裸 id 子会话 cccc0009 + 快照只列**父**（live ✓）+ lineage 边键=**裸** id
    #                  ⇒ 只改**快照里父 id 的形态**：带 `session-` 前缀 / 裸，各跑一遍
    #   修复前（红）：SESSION 父出现两次（3 行）· 带前缀那份 children=unknown depth=unknown（血缘查不到）
    #                 · SESSION_CHILD 的父 id 与快照行 id 对不上（联表失败）· COST_SESSION 也重复
    #   修复后（绿）：1 行 · children=1 depth=0 · 联表命中 · 两种形态输出**完全一致**（方向正确性证据 ✓）
    #   ★ 活库会漂 ⇒ 断言一律用**不变量**（归一后集合 == 原始集合）✗ 不写死 308/29 ✗
    # ------------------------------------------------------------------
    Section "1e. 数据正确性：会话 id 归一（快照 session- 前缀 vs 磁盘去前缀）"
    function Write-IdNormProj([string]$dir, [string]$id, [string]$extraKey, [int]$un, [int]$cr, [int]$cw, [int]$ou, [string]$statsKey) {
        $msIso = $msNear
        $json = '{"version":7,"record":{"identity":{"createdAt":' + $msIso + ',"cwd":"D:\\w"},' +
            '"rows":{' + $statsKey +
            '"tokenUsage":{"ver":2,"val":{"totals":{"uncachedInputTokens":' + $un + ',"outputTokens":' + $ou + ',"cacheReadTokens":' + $cr + ',"cacheWriteTokens":' + $cw + '}}},' +
            '"sessionListMetadata":{"ver":1,"val":{"blank":false,"lastPromptAt":' + $msIso + '}},' +
            $extraKey + '"title":{"ver":1,"val":"t-' + $id + '"}}}}'
        [System.IO.File]::WriteAllText((Join-Path $dir ($id + ".json")), $json, [System.Text.Encoding]::UTF8)
    }
    function New-IdNormCase([string]$tag, [string]$snapParentId) {
        $iso = Join-Path $env:TEMP ("dsht_matrix_idnorm_" + $tag + "_" + [guid]::NewGuid().ToString("N").Substring(0, 8))
        $dHome = Join-Path $iso "dsh"
        $projDir = Join-Path (Join-Path (Join-Path $dHome "storages") "session_projcache") "sessions"
        $snapDir = Join-Path $dHome "shio-bridge"
        New-Item -ItemType Directory -Path $projDir, $snapDir -Force | Out-Null
        # ★ 父会话的**磁盘副本故意不带 sessionStats**（区分符 ✓）：这样"哪一份赢了"在 SESSAGG/SESSION 行里看得见
        #   —— 快照那份 turns=3 steps=9 ✓ 磁盘那份 turns=unknown ✓（修复前磁盘那份会顶替活数据 ⇒ 断言抓得住 ✓）
        $statsNone = ''
        $statsChild = '"sessionStats":{"ver":1,"seq":1,"val":{"turns":3,"steps":9}},'
        Write-IdNormProj $projDir "pppp0001" '"childId":"cccc0009",' 100 200 30 40 $statsNone
        Write-IdNormProj $projDir "cccc0009" '' 10 20 3 4 $statsChild
        $nowIso = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')   # 只用于 generatedAt（新鲜度 ✓ 不进比对 ✓）
        # ★ 快照里的 createdAt/lastPromptAt 用**固定**时刻（= 磁盘侧同一个 $msNear ✓）：
        #   若用"现在"，两次夹具相差一两秒 ⇒ SESSION 行的 created=/last= 必然不同 ⇒ 对照断言假红 ✗（实测踩过 ✓）
        $fixedIso = ([DateTimeOffset]::FromUnixTimeMilliseconds($msNear)).UtcDateTime.ToString('yyyy-MM-ddTHH:mm:ss.fffZ', [System.Globalization.CultureInfo]::InvariantCulture)
        $snap = '{ "formatVersion": 2, "generatedAt": "' + $nowIso + '", "intervalMs": 3000, "sessions": [ ' +
            '{ "id": "' + $snapParentId + '", "live": true, "title": "parent", "createdAt": "' + $fixedIso + '", "lastPromptAt": "' + $fixedIso +
            '", "turns": 3, "steps": 9, "uncachedInputTokens": 100, "outputTokens": 40, "cacheReadTokens": 200, "cacheWriteTokens": 30 } ], ' +
            '"lineage": { "errors": 0, "sessions": { "pppp0001": {}, "cccc0009": { "parent": "pppp0001" } } } }'
        [System.IO.File]::WriteAllText((Join-Path $snapDir "sessions.json"), $snap, [System.Text.Encoding]::UTF8)
        return @{ iso = $iso; home = $dHome }
    }
    function Get-IdSet([string]$clean, [string]$prefix, [int]$field) {
        return @(MarkLines $clean $prefix | ForEach-Object { ($_ -split ' ')[$field] } | Sort-Object)
    }
    # -- 反例：快照父 id 带前缀（修复前会重复 + 联不上 + 血缘 unknown）--
    $f1eA = New-IdNormCase "prefixed" "session-pppp0001"; $script:isoList.Add($f1eA.iso)
    $env:DSH_HOME = $f1eA.home
    $env:DSH_MINATO_BACKUP_DIR = $null
    $a1e = Run-Cli $Cli @("sessions", "--days", "7")
    $ap1e = Run-Cli $Cli @("sessions", "--days", "7", "--level", "parents_sub")
    $idsA = Get-IdSet $a1e.out '^SESSION ' 1
    Write-Host ("  -- sessions --days 7（快照父 id 带前缀）   rc=" + $a1e.rc)
    foreach ($l in (MarkLines $a1e.out '^SESSION |^SESSAGG_SESSION |^SESSION_CHILD ')) { Write-Host ("       " + $l) }
    Check "1e 去重：SESSION 行数 == 归一后不同 id 数（不变量 ✓ 修复前 3 vs 2 ✗）" `
        ($idsA.Count -eq 2 -and (($idsA | Sort-Object -Unique).Count -eq $idsA.Count))
    Check "1e 去重：输出 id 已是规范形态（不带 session- 前缀 ✓）" (-not (HasMarker $a1e.out '^SESSION session-'))
    Check "1e 联表：SESSION_CHILD 的父 id 能在 SESSION 行里找到（修复前靠磁盘那份侥幸命中 ✗）" `
        ((HasMarker $a1e.out '^SESSION_CHILD pppp0001 cccc0009$') -and ($idsA -contains 'pppp0001'))
    Check "1e 活数据：pppp0001 的 SESSION 行是**快照那份**（turns=3 live=1 ✓ 修复前磁盘那份 turns=unknown live=0 ✗）" `
        (HasMarker $a1e.out '^SESSION pppp0001 .* turns=3 steps=9 in=300 out=40 .* live=1 ')
    Check "1e 血缘：pppp0001 children=1 depth=0（修复前带前缀那份 only unknown ✗ 磁盘那份顶替 ⇒ turns 也对不上 ✗）" `
        (HasMarker $a1e.out '^SESSAGG_SESSION pppp0001 bucket=own turns=3 steps=9 uncached=100 cacheRead=200 cacheWrite=30 output=40 children=1 depth=0$')
    Check "1e 非 global 档：活会话在聚合里**不被静默排除**（own 行=快照那份 · sub members=2 ✓）" `
        ((HasMarker $ap1e.out '^SESSAGG_SESSION pppp0001 bucket=own turns=3 steps=9 .* children=1 depth=0$') `
        -and (HasMarker $ap1e.out '^SESSAGG_SESSION pppp0001 bucket=sub .* members=2 sub_unknown=0 sub_unknown_stats=0$'))
    # -- 配价后 cost 的 id 集合也必须与 SESSION 集合逐个一致（费用的重复计入同源 ✓）--
    Run-Cli $Cli @("config-set", "sessions_price_in_per_mtok", "1") | Out-Null
    $c1eA = Run-Cli $Cli @("cost", "--days", "7")
    $cIdsA = Get-IdSet $c1eA.out '^COST_SESSION scope=window ' 2
    Check "1e 成本：COST_SESSION 恰 2 条且集合 == SESSION 集合（修复前 3 条 ⇒ 重复计入 ✗）" `
        ($cIdsA.Count -eq 2 -and $idsA.Count -eq 2 -and (($cIdsA -join ',') -eq ($idsA -join ',')))
    Check "1e 成本：金额为数字（parent 10/20/3/4 已配价 ⇒ cost=0.0000xx ✓）" (HasMarker $c1eA.out '^COST_TOTAL scope=window .* cost=[0-9]')
    # -- 对照：快照父 id 直接给裸 → 必须与上面**完全一致**（修复方向正确的独立证据 ✓ 冻结要求）--
    $f1eB = New-IdNormCase "bare" "pppp0001"; $script:isoList.Add($f1eB.iso)
    $env:DSH_HOME = $f1eB.home
    $a1eB = Run-Cli $Cli @("sessions", "--days", "7")
    $ap1eB = Run-Cli $Cli @("sessions", "--days", "7", "--level", "parents_sub")
    $c1eB = Run-Cli $Cli @("cost", "--days", "7")
    $segA = @(MarkLines $a1e.out '^SESSION |^SESSAGG_SESSION |^SESSION_CHILD ') -join "|"
    $segB = @(MarkLines $a1eB.out '^SESSION |^SESSAGG_SESSION |^SESSION_CHILD ') -join "|"
    $costA = @(MarkLines $c1eA.out '^COST_SESSION |^COST_TOTAL ') -join "|"
    $costB = @(MarkLines $c1eB.out '^COST_SESSION |^COST_TOTAL ') -join "|"
    Check "1e 对照：快照 id 带前缀 与 裸 id 的 sessions 段**逐字相同**（修复后两种形态等价 ✓）" ($segA -eq $segB -and $segA.Length -gt 0)
    Check "1e 对照：两种形态的 COST 段也逐字相同" ($costA -eq $costB)
    Check "1e 对照：非 global 档同样等价" (((@(MarkLines $ap1e.out '^SESSAGG_SESSION ')) -join '|') -eq ((@(MarkLines $ap1eB.out '^SESSAGG_SESSION ')) -join '|'))
    Run-Cli $Cli @("config-set", "sessions_price_in_per_mtok", "0") | Out-Null   # 复位共享配置 ✓
    $cfg1e = Run-Cli $Cli @("config-get")
    Check "1e 复位：单价回 0（不把测试价留在共享配置里 ✓）" (-not (HasMarker $cfg1e.out '^CONFIG sessions_price_in_per_mtok [1-9]'))

    # ------------------------------------------------------------------
    # 1f) 金额精度：**极小非零**永不渲染成 0 / 0.000000（2026-10-16 修正 ✓ Lead 裁定 ✓）
    #   夹具：1 个会话 · 只填输出单价 0.001（USD/百万）· output=118 token
    #   ⇒ 期望金额 = 118 × 0.001 ÷ 1e6 = 1.18e-7 USD（往返精度形态 = `1.18E-07` ✓）
    #   ★ 反例（改回固定 6 位/舍入）：会写成 `0` 或 `0.000000` ⇒ 本节的 ①② 必须红 ✓
    #   ★ GUI 侧用 `decimal.TryParse(NumberStyles.Float)` 解析 ⇒ 科学计数与定点都认 ✓（本节点③ 复刻同一调用 ✓）
    # ------------------------------------------------------------------
    Section "1f. 金额精度：极小非零（往返精度 · 非零永不渲染成 0）"
    $f1f = New-Fixture "tiny"; $script:isoList.Add($f1f.iso)
    $env:DSH_HOME = $f1f.home
    Write-BoardProj $f1f.home "tiny0001" $msNear $metaNear 0 0 0 118 1 2
    Run-Cli $Cli @("config-set", "sessions_price_out_per_mtok", "0.001") | Out-Null
    $cTiny = Run-Cli $Cli @("cost", "--days", "7")
    Write-Host ("  -- cost --days 7（output=118 · 单价 0.001）   rc=" + $cTiny.rc)
    foreach ($l in (MarkLines $cTiny.out '^COST_(TOTAL|BUDGET)')) { Write-Host ("       " + $l) }
    $tinyTotal = @(MarkLines $cTiny.out '^COST_TOTAL scope=window ')
    Check "1f ① 端到端极小非零：COST_TOTAL 精确整行（118×0.001÷1e6 = 1.18E-07 ✓）" `
        ($tinyTotal.Count -eq 1 -and $tinyTotal[0] -eq 'COST_TOTAL scope=window uncached=0 cacheRead=0 cacheWrite=0 output=118 tokens=118 cost=1.18E-07')
    Check "1f ② cost= 不是 `0` 也不是 `0.000000`（✗ 把「很小」说成「没有」就是不诚实 ✓）" `
        ((HasMarker $cTiny.out 'cost=1\.18E-07$') -and (-not (HasMarker $cTiny.out 'cost=0$')) -and (-not (HasMarker $cTiny.out 'cost=0\.0+$')))
    $tinyText = ($tinyTotal[0] -split 'cost=')[1]
    $tinyVal = [decimal]0
    $tinyParsed = [decimal]::TryParse($tinyText, [System.Globalization.NumberStyles]::Float, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$tinyVal)
    Check "1f ③ GUI 解析路径可达（复刻 GUI 的 decimal.TryParse(NumberStyles.Float) ⇒ 成功且 > 0 ✓）" `
        ($tinyParsed -and $tinyVal -gt [decimal]0)
    $tinySess = @(MarkLines $cTiny.out '^COST_SESSION scope=window tiny0001 ')
    Check "1f ① 会话级同样非零（COST_SESSION … cost=1.18E-07 ✓）" `
        ($tinySess.Count -eq 1 -and $tinySess[0] -eq 'COST_SESSION scope=window tiny0001 model=unknown uncached=0 cacheRead=0 cacheWrite=0 output=118 cost=1.18E-07')
    Check "1f ④ 守卫：任一 cost= 都不许是零值写法（钉住「舍入回 6 位」这种回退 ✓）" `
        (-not (HasMarker $cTiny.out 'cost=0(\.0+)?$'))
    Run-Cli $Cli @("config-set", "sessions_price_out_per_mtok", "0") | Out-Null   # 复位共享配置 ✓

    Section "2. 写路径（隔离数据根 + 隔离备份根）"
    $f2 = New-Fixture "wr"; $script:isoList.Add($f2.iso)
    $env:DSH_HOME = $f2.home
    $cset2 = Run-Cli $Cli @("config-set", "ws", $f2.ws)

    $b = Run-Cli $Cli @("backup", "--to", $f2.bk)
    Write-Host ("  -- backup --to <隔离备份根>   rc=" + $b.rc)
    foreach ($l in (MarkLines $b.out 'BACKUP_' | Select-Object -First 3)) { Write-Host ("       " + $l) }
    Check "backup 打印 BACKUP_OK" (HasMarker $b.out '^BACKUP_OK ')
    Check "backup 退出码 = 0" ($b.rc -eq 0)
    $pkg = LastMarkerPath $b.out 'BACKUP_OK ' 'BACKUP_FAIL '
    # ★★★ **CI 断言缺陷修复（2026-10-07，run 37587237343 / job v3-smoke-matrix）** ✓✓
    #   ✗ 这条原来做的是**字面前缀**比较（PS 侧拼出的 $f2.bk vs CLI 打印的包路径）✗
    #     → 在干净 runner 上判红，而**同一份 CI 日志**里：
    #         `BACKUP_TO <--to 目录>` ✓ 与 `BACKUP_OK <--to 目录>\dsh-data-…` ✓ 都指向 --to
    #     → 结论：**`--to` 是生效的** ✓（产品语义正确 ✓ 读码复核 Program.cs 的 Backup()：
    #        把 --to 写进 `<StateDir>/.backup-dir` 并**校验 effective == 给定目录**，
    #        不一致就 `BACKUP_FAIL … 指定的目录没有生效` 退出 1 ✓ —— 也就是说"粘性根吃掉 --to"
    #        这种情况根本过不去 ✓）→ 所以判红是**断言**的问题（同一路径的两种字符串形式 ✗），
    #        **不是产品缺陷** ✓ 也**不是**"粘性根与 --to 冲突" ✓（本矩阵 §0 已先 --reset 复位粘性根 ✓）
    #   ✓ 现在：两侧都先规范化（FullPathOrSelf ✓）再比，并要求**严格的目录包含**
    #     （多一个分隔符边界：`…\bk` 不再被 `…\bk2` 误判为包含 ✓）
    #   ⚠ 这**不是**永真断言 ✗：`--to` 真被忽略（包落到粘性根/默认根）时，这一条照样红 ✓✓
    $pkgFull = FullPathOrSelf $pkg
    $bkFull = (FullPathOrSelf $f2.bk).TrimEnd('\', '/')
    $inTo = ($pkgFull.Length -gt 0) -and $pkgFull.StartsWith(($bkFull + [string][System.IO.Path]::DirectorySeparatorChar), [StringComparison]::OrdinalIgnoreCase)
    if (-not $inTo) {
        # 失败时**把两个值打出来** ✓ —— 下一次这种红自己能说明原因（对照 CI 日志即可判定是断言还是产品 ✓）
        Write-Host ("       包 = " + $pkgFull)
        Write-Host ("       --to = " + $bkFull)
    }
    Check "备份目录落在 --to 指定的目录内" $inTo
    Check "完成标记写在包同级（<包>.manifest）" ($pkg -ne $null -and (Test-Path -LiteralPath ($pkg + ".manifest")))
    $marker = ""
    if ($pkg -and (Test-Path -LiteralPath ($pkg + ".manifest"))) { $marker = [System.IO.File]::ReadAllText($pkg + ".manifest") }
    Check "标记含 files= / failed= / sha256=" (($marker -match 'files=\d+') -and ($marker -match 'failed=\d+') -and ($marker -match 'sha256=[0-9a-f]{16,}'))

    $v = Run-Cli $Cli @("backup-list", "--verify")
    Write-Host ("  -- backup-list --verify   rc=" + $v.rc)
    foreach ($l in (MarkLines $v.out 'BACKUP_VERIFY' | Select-Object -First 3)) { Write-Host ("       " + $l) }
    Check "backup-list --verify 打印 BACKUP_VERIFY_TOTAL" (HasMarker $v.out '^BACKUP_VERIFY_TOTAL ')
    Check "backup-list --verify 对新鲜包报 complete" (HasMarker $v.out '^BACKUP_VERIFY .* complete ')
    Check "backup-list --verify 无 mismatch" (-not (HasMarker $v.out '^BACKUP_VERIFY .* mismatch'))
    Check "backup-list --verify 退出码 = 0" ($v.rc -eq 0)

    # ---- backup-export（成功路径 ✓ —— 这正是 D1 活到今天的直接原因 ✗）----
    $expDir = Join-Path $f2.iso "exp"
    $e = Run-Cli $Cli @("backup-export", "--path", $pkg, "--to", $expDir, "--yes")
    Write-Host ("  -- backup-export --path <包> --to <隔离目标> --yes   rc=" + $e.rc)
    foreach ($l in (MarkLines $e.out 'BKEXPORT_' | Select-Object -First 2)) { Write-Host ("       " + $l) }
    $eOk = HasMarker $e.out '^BKEXPORT_OK '
    $eFail = HasMarker $e.out '^BKEXPORT_FAIL '
    if ($eOk) {
        Check "backup-export 成功路径打印 BKEXPORT_OK" $true
        Check "backup-export 退出码 = 0" ($e.rc -eq 0)
        $expPkg = LastMarkerPath $e.out 'BKEXPORT_OK ' 'BKEXPORT_FAIL '
        Check "导出副本带完成标记（<副本>.manifest —— 否则异地无法核对 ✗）" ($expPkg -ne $null -and (Test-Path -LiteralPath ($expPkg + ".manifest")))
    } elseif ($eFail -and $AllowKnownDefect) {
        # ★ 已知缺陷（A1/D1）：不掩盖、也不拖垮矩阵 —— 记 XFAIL 并单列 ✓
        $script:xfail.Add("backup-export 成功路径（已知缺陷 A1/D1：BKEXPORT_OK 未出现，该命令当前不可用；rc=" + $e.rc + "）")
        Write-Host ("  [XFAIL] backup-export 成功路径：BKEXPORT_OK 未出现（已知缺陷 A1/D1，另批修复中）")
        Check "backup-export 至少给出了明确 FAIL（不许静默 ✗）" $true
    } else {
        Check "backup-export 打印 BKEXPORT_OK（成功路径）" $eOk
        Check "backup-export 退出码 = 0（成功路径）" ($e.rc -eq 0)
        Check "backup-export 失败时必须打印 BKEXPORT_FAIL 而非静默" ($eOk -or $eFail)
    }

    # ---- restore --dry-run：只读预览，**绝不写盘** ----
    $d = Run-Cli $Cli @("restore", "--dry-run")
    Write-Host ("  -- restore --dry-run   rc=" + $d.rc)
    foreach ($l in (MarkLines $d.out 'DRYRUN_|RESTORE_' | Select-Object -First 4)) { Write-Host ("       " + $l) }
    Check "restore --dry-run 给出明确结论（DRYRUN_OK / DRYRUN_FAIL / 明确拒绝）" ((HasMarker $d.out '^DRYRUN_(OK|FAIL)') -or (HasMarker $d.out '^RESTORE_FAIL '))
    Check "restore --dry-run 未报告真实写盘（无 RESTORE_OK / APPLY_ROOT / APPLY_ACK）" (-not (HasMarker $d.out '^RESTORE_(OK|APPLY_ROOT|APPLY_ACK)'))
    Check "restore --dry-run 退出码 = 0（只读命令）" ($d.rc -eq 0)
    Check "restore --dry-run 带出来源包路径（DRYRUN_SRC）" (HasMarker $d.out '^DRYRUN_SRC ')

    # ------------------------------------------------------------------
    # 3) 承诺的行为：`..` 逃逸 · wipe 只打印 · uninstall 不删数据
    # ------------------------------------------------------------------
    Section "3. 承诺的行为（越界 / wipe / uninstall）"
    $f3 = New-Fixture "bh"; $script:isoList.Add($f3.iso)
    $env:DSH_HOME = $f3.home
    $cset3 = Run-Cli $Cli @("config-set", "ws", $f3.ws)

    # 3a) `..` 逃逸：目标不在备份根内 → 必须拒绝，且**不许**建出目录 ✓
    $escape = Join-Path $f3.bk "..\..\dsh"
    $x = Run-Cli $Cli @("backup-export", "--path", $escape, "--to", (Join-Path $f3.iso "esc"), "--yes")
    Write-Host ("  -- backup-export --path <备份根>\..\..\dsh   rc=" + $x.rc)
    foreach ($l in (MarkLines $x.out 'BKEXPORT_' | Select-Object -First 2)) { Write-Host ("       " + $l) }
    Check "`..` 逃逸被拒（BKEXPORT_FAIL outside）" (HasMarker $x.out '^BKEXPORT_FAIL ')
    Check "逃逸路径退出码非 0" ($x.rc -ne 0)
    Check "逃逸失败后没有建出导出目录" (-not (Test-Path -LiteralPath (Join-Path $f3.iso "esc")))

    # 3b) wipe：只打印路径、**不删**（about 里的承诺 ✓ 这里做行为断言 ✓）
    $w = Run-Cli $Cli @("wipe")
    Write-Host ("  -- wipe   rc=" + $w.rc)
    foreach ($l in (MarkLines $w.out 'WIPE_' | Select-Object -First 3)) { Write-Host ("       " + $l) }
    Check "wipe 打印 WIPE_PLAN / WIPE_MANUAL 路径" ((HasMarker $w.out '^WIPE_PLAN ') -or (HasMarker $w.out '^WIPE_MANUAL '))
    Check "wipe 之后数据**原样还在**（不删 ✓）" (Test-Path -LiteralPath (Join-Path $f3.home "storages/a.txt"))

    # 3c) uninstall 计划：不带 --yes 绝不执行；且**不碰**数据根 ✓（"卸载不删数据"承诺 ✓）
    # ★★★ **CI 断言缺陷修复（2026-10-07，run 37587237343 / job v3-smoke-matrix）** ✓✓
    #   ✗ 这条原来**只认** `UNINSTALL_PLAN` / `UNINSTALL_DRYRUN` ✗
    #     → 干净 runner 上**没有全局 npm 包** → 产品如实打印
    #         `UNINSTALL_SKIP 没有观测到已安装的 dsh` + `UNINSTALL_OBSERVED not-installed` ✓
    #     → 这时**不该**有 PLAN/DRYRUN ✓（没有可卸载的东西，硬打一个计划反而是假信息 ✗）
    #     → 判红是断言不成立，**不是产品缺陷** ✓（读码复核 Program.App.cs 的 UninstallCmd：
    #         WhichDsh/DshVersion 都取不到 → 打 SKIP 并 return 0 ✓）
    #   ✓ 现在：**显式 SKIP + 打印原因** ✓，并且**照旧计入总数**（不静默跳过 ✗ —— 否则总数悄悄
    #     变少、EXPECTED_MIN 失效 ✗；与 `v3/tools/verify_failure_paths.sh` 的项数下限同一手法 ✓）
    #   ⚠ SKIP 分支本身也是一条真断言 ✓：必须打印 `UNINSTALL_OBSERVED not-installed`（不静默 ✗）
    $u = Run-Cli $Cli @("uninstall")
    Write-Host ("  -- uninstall（不带 --yes）   rc=" + $u.rc)
    foreach ($l in (MarkLines $u.out 'UNINSTALL_' | Select-Object -First 3)) { Write-Host ("       " + $l) }
    $uPlan = (HasMarker $u.out '^UNINSTALL_PLAN ') -or (HasMarker $u.out '^UNINSTALL_DRYRUN ')
    $uSkip = HasMarker $u.out '^UNINSTALL_SKIP '
    if ($uPlan) {
        Check "uninstall 先打印计划（UNINSTALL_PLAN / DRYRUN）" $true
    } elseif ($uSkip) {
        Write-Host "  [SKIP] uninstall 计划：本机没有已安装的全局 dsh（UNINSTALL_SKIP ✓）"
        Write-Host "         原因：干净环境里没有 npm 全局包 → 没有计划可打印（产品如实报 SKIP ✓ 不是缺陷 ✓）"
        Write-Host "         该项**计入总数**（项数不变 → EXPECTED_MIN 仍有效 ✓ 不静默跳过 ✗）"
        Check "uninstall 无全局 dsh 时如实报 SKIP（不静默 ✗；UNINSTALL_OBSERVED not-installed ✓）" (HasMarker $u.out '^UNINSTALL_OBSERVED not-installed')
    } else {
        Check "uninstall 先打印计划（UNINSTALL_PLAN / DRYRUN）" $false
    }
    Check "uninstall 未确认时没有执行（无 UNINSTALL_OK）" (-not (HasMarker $u.out '^UNINSTALL_OK'))
    Check "uninstall 之后数据根**原样还在**（不删数据 ✓）" (Test-Path -LiteralPath (Join-Path $f3.home "storages/a.txt"))

    # ------------------------------------------------------------------
    # 4) 越界证明：真实数据根未被触碰（矩阵自己也要自证 ✓）
    # ------------------------------------------------------------------
    Section "4. 越界证明"
    foreach ($r in $realRoots) {
        $after = Get-RootSnapshot $r
        Check ("真实数据根未变: " + $r) ($after -eq $before[$r])
    }
} finally {
    if ($null -ne $oldHome) { $env:DSH_HOME = $oldHome } else { Remove-Item Env:\DSH_HOME -ErrorAction SilentlyContinue }
    if (-not $Keep) { foreach ($p in $script:isoList) { Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction SilentlyContinue } }
    else { foreach ($p in $script:isoList) { Write-Host ("隔离目录保留: " + $p) } }
}

Write-Host ""
if ($script:xfail.Count -gt 0) {
    Write-Host "== 已知缺陷（XFAIL，另批修复中，不计入失败 ✓）=="
    foreach ($x in $script:xfail) { Write-Host ("  [XFAIL] " + $x) }
}
$total = $script:pass + $script:fail
Write-Host ("== 矩阵：" + $script:pass + "/" + $total + " passed, " + $script:fail + " failed（XFAIL " + $script:xfail.Count + "）==")
# 项数下限：删掉用例（或整段被截断）时 PASS 变少而 FAIL 仍为 0 ✗ → 这里必须红 ✓
$EXPECTED_MIN = 16
if ($script:pass -lt $EXPECTED_MIN) {
    Write-Host ("  [FAIL] 项数不足：实跑 " + $script:pass + " < 声明 " + $EXPECTED_MIN)
    $script:fail++
}
if ($script:fail -ne 0) { exit 1 }
exit 0
