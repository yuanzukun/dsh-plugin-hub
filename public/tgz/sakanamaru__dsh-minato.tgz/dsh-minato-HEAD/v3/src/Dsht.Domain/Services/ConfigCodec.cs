using System;
using System.Text;
using Dsht.Domain.Model;

namespace Dsht.Domain.Services
{
    /// <summary>launcher.config 的解析与序列化（纯函数）。逐条对齐 v2.x 的 LoadConfig / SaveConfig：
    ///   · 每行 key=value；未知键忽略
    ///   · lang ∈ {zh,en,auto}；host ∈ {localhost,127.0.0.1}；keep_backups 数字且夹到 ≥3
    ///   · check_update / check_dsh_update / auto_start：任意非空值 → 关掉除非值为 "off"
    ///   · update_channel："rc" 否则 stable；close_action ∈ {ask,tray,exit} 否则空
    ///   · ws：交给注入的 canonicalize 委托（平台侧用真实路径规范化，失败则视为无效）
    /// 序列化固定键顺序 + CRLF，与 v2.x 一致（便于比对）。</summary>
    public static class ConfigCodec
    {
        /// <summary>★ 悬边灯样式的三个**语义取值**（唯一白名单 ✓ 语义化 · ✗ 不是 a/b/c 位置代号 ✗）：
        /// <c>line</c> = A 极简细条 · <c>dot</c> = B 圆点 + 轻环 · <c>capsule</c> = C 双端胶囊。
        /// ★ 与 GUI 的 <c>DesignTokens.LampStyleKeys</c> 必须逐字一致（两边各有断言盯着 ✓）。</summary>
        public static readonly string[] OverlayLightStyles = { "line", "dot", "capsule" };

        /// <summary>悬边灯样式的**默认值** = <c>dot</c>（B 圆点 + 轻环 ✓ 2026-10-28 维护者拍板）。
        /// ★ 与 GUI 的 <c>DesignTokens.DefaultLampStyleKey</c> 是同一款（✗ 不是两套默认 ✗）。</summary>
        public const string DefaultOverlayLightStyle = "dot";

        /// <summary>这个值是不是合法的悬边灯样式（trim + 忽略大小写 ✓；非法一律 false ✗ 不猜 ✗）。</summary>
        public static bool IsOverlayLightStyle(string raw)
        {
            if (raw == null) return false;
            string v = raw.Trim().ToLowerInvariant();
            for (int i = 0; i < OverlayLightStyles.Length; i++) if (OverlayLightStyles[i] == v) return true;
            return false;
        }

        public static ToolkitConfig Parse(string text, Func<string, string> canonicalizePath)
        {
            ToolkitConfig c = new ToolkitConfig();
            if (string.IsNullOrEmpty(text)) return c;
            string[] lines = text.Replace("\r\n", "\n").Replace("\r", "\n").Split('\n');
            for (int i = 0; i < lines.Length; i++)
            {
                string t = (lines[i] ?? "").Trim();
                if (t.Length == 0) continue;
                if (t.StartsWith("lang=", StringComparison.Ordinal))
                {
                    string v = t.Substring(5).Trim().ToLowerInvariant();
                    c.Lang = (v == "zh" || v == "en") ? v : "auto";
                }
                else if (t.StartsWith("host=", StringComparison.Ordinal))
                {
                    string v = t.Substring(5).Trim().ToLowerInvariant();
                    if (v == "localhost" || v == "127.0.0.1") c.Host = v;
                }
                else if (t.StartsWith("ws=", StringComparison.Ordinal))
                {
                    string v = t.Substring(3).Trim().Trim('"');
                    if (v.Length > 0) c.Workspace = Canon(canonicalizePath, v);
                }
                else if (t.StartsWith("keep_backups=", StringComparison.Ordinal))
                {
                    int n;
                    if (int.TryParse(t.Substring(13).Trim(), out n)) c.KeepBackups = n < 3 ? 3 : n;
                }
                else if (t.StartsWith("check_update=", StringComparison.Ordinal))
                {
                    string v = t.Substring(13).Trim().ToLowerInvariant();
                    if (v.Length > 0) c.CheckUpdate = v != "off";
                }
                else if (t.StartsWith("check_dsh_update=", StringComparison.Ordinal))
                {
                    string v = t.Substring(17).Trim().ToLowerInvariant();
                    if (v.Length > 0) c.CheckDshUpdate = v != "off";
                }
                else if (t.StartsWith("dsh_versions=", StringComparison.Ordinal))
                {
                    string v = t.Substring(13).Trim();
                    if (v.Length > 0) c.DshVersions = v;
                }
                else if (t.StartsWith("update_channel=", StringComparison.Ordinal))
                {
                    string v = t.Substring(15).Trim().ToLowerInvariant();
                    c.UpdateChannel = v == "rc" ? "rc" : "stable";
                }
                else if (t.StartsWith("close_action=", StringComparison.Ordinal))
                {
                    string v = t.Substring(13).Trim().ToLowerInvariant();
                    c.CloseAction = (v == "tray" || v == "exit") ? v : (v == "ask" ? "ask" : "");
                }
                else if (t.StartsWith("auto_start=", StringComparison.Ordinal))
                {
                    string v = t.Substring(11).Trim().ToLowerInvariant();
                    if (v.Length > 0) c.AutoStart = v != "off";
                }
            // ✗ 上次写成 auto_start= 分支的 else → 只有 auto_start= 为空时才读 ✗ 永远读不到 ✓（CLI 的回读校验抓到 ✓✓）
            else if (t.StartsWith("auto_start_target=", StringComparison.Ordinal)) c.AutoStartTarget = t.Substring("auto_start_target=".Length).Trim();
            else if (t.StartsWith("browser_mode=", StringComparison.Ordinal)) c.BrowserMode = t.Substring("browser_mode=".Length).Trim();
            else if (t.StartsWith("ui_parallel=", StringComparison.Ordinal)) c.UiParallel = t.Substring("ui_parallel=".Length).Trim() != "off";
            else if (t.StartsWith("scan_children=", StringComparison.Ordinal)) c.ScanChildren = t.Substring("scan_children=".Length).Trim() != "off";
            else if (t.StartsWith("gui_start_page=", StringComparison.Ordinal))
            {
                // 与白名单同一条规则 ✓：0..9 之外不认（保持默认 ✓ 不猜 ✗）——旧配置文件没有这行 → 默认 1 ✓
                int n;
                if (int.TryParse(t.Substring("gui_start_page=".Length).Trim(), out n) && n >= 0 && n <= 9) c.GuiStartPage = n;
            }
            else if (t.StartsWith("gui_auto_refresh=", StringComparison.Ordinal))
            {
                // 与白名单同一条规则 ✓：off / 空 = 暂停 ✓；0.5–3600 秒之外不认（保持默认 off ✓）
                string v2 = t.Substring("gui_auto_refresh=".Length).Trim();
                double sec2;
                if (v2.Length == 0 || v2 == "off") c.GuiAutoRefresh = "off";
                else if (double.TryParse(v2, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out sec2) && sec2 >= 0.5 && sec2 <= 3600) c.GuiAutoRefresh = v2;
            }
            else if (t.StartsWith("gui_shell=", StringComparison.Ordinal))
            {
                // 与白名单同一条规则 ✓：0..4 之外不认（保持默认 ✓ 不猜 ✗）
                int n;
                if (int.TryParse(t.Substring("gui_shell=".Length).Trim(), out n) && n >= 0 && n <= 4) c.GuiShell = n;
            }
            else if (t.StartsWith("gui_style=", StringComparison.Ordinal))
            {
                int n;
                if (int.TryParse(t.Substring("gui_style=".Length).Trim(), out n) && n >= 0 && n <= 3) c.GuiStyle = n;
            }
            else if (t.StartsWith("balance_key=", StringComparison.Ordinal)) c.BalanceKey = t.Substring("balance_key=".Length).Trim();
            else if (t.StartsWith("sessions_default_level=", StringComparison.Ordinal))
            {
                // 与 config-set 白名单同一条规则 ✓：三口径之外不认 → 保持默认 global ✗ 不猜 ✗
                string lv = t.Substring("sessions_default_level=".Length).Trim().ToLowerInvariant();
                if (lv == "global" || lv == "parents" || lv == "parents_sub") c.SessionsDefaultLevel = lv;
            }
            else if (t.StartsWith("sessions_price_in_per_mtok=", StringComparison.Ordinal)) c.SessionsPriceInPerMTok = ParsePrice(t.Substring("sessions_price_in_per_mtok=".Length));
            else if (t.StartsWith("sessions_price_cache_read_per_mtok=", StringComparison.Ordinal)) c.SessionsPriceCacheReadPerMTok = ParsePrice(t.Substring("sessions_price_cache_read_per_mtok=".Length));
            else if (t.StartsWith("sessions_price_cache_write_per_mtok=", StringComparison.Ordinal)) c.SessionsPriceCacheWritePerMTok = ParsePrice(t.Substring("sessions_price_cache_write_per_mtok=".Length));
            else if (t.StartsWith("sessions_price_out_per_mtok=", StringComparison.Ordinal)) c.SessionsPriceOutPerMTok = ParsePrice(t.Substring("sessions_price_out_per_mtok=".Length));
            // ★ 成本面板 v3.2（2026-10-16 ✓ 维护者已确认键名 ✓）：每日预算上限，同样 ≥0 的十进制、同样的 0 = 未设语义 ✓
            else if (t.StartsWith("sessions_budget_usd_per_day=", StringComparison.Ordinal)) c.SessionsBudgetUsdPerDay = ParsePrice(t.Substring("sessions_budget_usd_per_day=".Length));
            // ——— 悬边状态灯悬浮窗（2026-10-26 · 提案 §11 ✓）：六个纯 GUI 偏好键 ✓ 规则与既有键同款（越界保持默认 ✗ 不猜 ✓）———
            else if (t.StartsWith("overlay_enabled=", StringComparison.Ordinal))
            {
                string v = t.Substring("overlay_enabled=".Length).Trim().ToLowerInvariant();
                if (v.Length > 0) c.OverlayEnabled = v != "off";
            }
            else if (t.StartsWith("overlay_light_style=", StringComparison.Ordinal))
            {
                // ★ 三个语义值之外**不认** ⇒ 保持默认 dot ✓（✗ 不猜 ✗）。
                //   这里的"回落"不是静默：`config-get` 会读**原始文本**发现非法值 ⇒ 打一行 CONFIGWARN 明说 ✓
                //   （✗ 不崩 ✗ 不把非法值当合法存下去 ✓）
                string v = t.Substring("overlay_light_style=".Length).Trim().ToLowerInvariant();
                if (IsOverlayLightStyle(v)) c.OverlayLightStyle = v;
            }
            else if (t.StartsWith("overlay_edge=", StringComparison.Ordinal))
            {
                string v = t.Substring("overlay_edge=".Length).Trim().ToLowerInvariant();
                if (v == "left" || v == "right" || v == "top" || v == "bottom") c.OverlayEdge = v;
            }
            else if (t.StartsWith("overlay_offset=", StringComparison.Ordinal))
            {
                // 与白名单同一条规则 ✓：0~1 之外不认（保持默认 0.5 ✓ 不猜 ✗）
                decimal off;
                if (decimal.TryParse(t.Substring("overlay_offset=".Length).Trim(), System.Globalization.NumberStyles.Number, System.Globalization.CultureInfo.InvariantCulture, out off) && off >= 0m && off <= 1m) c.OverlayOffset = off;
            }
            else if (t.StartsWith("overlay_scale=", StringComparison.Ordinal))
            {
                int n;
                if (int.TryParse(t.Substring("overlay_scale=".Length).Trim(), out n) && n >= 0 && n <= 2) c.OverlayScale = n;
            }
            else if (t.StartsWith("overlay_screen=", StringComparison.Ordinal)) c.OverlayScreen = t.Substring("overlay_screen=".Length).Trim();
            else if (t.StartsWith("overlay_show_title=", StringComparison.Ordinal))
            {
                string v = t.Substring("overlay_show_title=".Length).Trim().ToLowerInvariant();
                if (v.Length > 0) c.OverlayShowTitle = v != "off";
            }
            }
            return c;
        }

        /// <summary>单价解析：≥0 的十进制才接受（InvariantCulture ✓ 与 config-set 白名单同规则 ✓）；不认 → 0（未填 ✓ 不猜 ✗）。</summary>
        private static decimal ParsePrice(string raw)
        {
            decimal d;
            if (decimal.TryParse((raw ?? "").Trim(), System.Globalization.NumberStyles.Number, System.Globalization.CultureInfo.InvariantCulture, out d) && d >= 0m) return d;
            return 0m;
        }

        public static string Serialize(ToolkitConfig c)
        {
            if (c == null) c = new ToolkitConfig();
            StringBuilder sb = new StringBuilder();
            sb.Append("lang=").Append(c.Lang).Append("\r\n");
            sb.Append("host=").Append(c.Host).Append("\r\n");
            sb.Append("ws=").Append(c.Workspace == null ? "" : c.Workspace).Append("\r\n");
            sb.Append("keep_backups=").Append(c.KeepBackups).Append("\r\n");
            sb.Append("check_update=").Append(c.CheckUpdate ? "on" : "off").Append("\r\n");
            sb.Append("check_dsh_update=").Append(c.CheckDshUpdate ? "on" : "off").Append("\r\n");
            sb.Append("dsh_versions=").Append(c.DshVersions).Append("\r\n");
            sb.Append("update_channel=").Append(c.UpdateChannel).Append("\r\n");
            sb.Append("close_action=").Append(c.CloseAction).Append("\r\n");
            sb.Append("auto_start=").Append(c.AutoStart ? "on" : "off").Append("\r\n");
            sb.Append("auto_start_target=").Append(c.AutoStartTarget).Append("\r\n");
            sb.Append("browser_mode=").Append(c.BrowserMode).Append("\r\n");
            sb.Append("ui_parallel=").Append(c.UiParallel ? "on" : "off").Append("\r\n");
            sb.Append("scan_children=").Append(c.ScanChildren ? "on" : "off").Append("\r\n");
            sb.Append("gui_start_page=").Append(c.GuiStartPage).Append("\r\n");
            sb.Append("gui_auto_refresh=").Append(c.GuiAutoRefresh).Append("\r\n");
            sb.Append("gui_shell=").Append(c.GuiShell).Append("\r\n");
            sb.Append("gui_style=").Append(c.GuiStyle).Append("\r\n");
            sb.Append("balance_key=").Append(c.BalanceKey == null ? "" : c.BalanceKey).Append("\r\n");
            sb.Append("sessions_default_level=").Append(c.SessionsDefaultLevel).Append("\r\n");
            sb.Append("sessions_price_in_per_mtok=").Append(c.SessionsPriceInPerMTok.ToString(System.Globalization.CultureInfo.InvariantCulture)).Append("\r\n");
            sb.Append("sessions_price_cache_read_per_mtok=").Append(c.SessionsPriceCacheReadPerMTok.ToString(System.Globalization.CultureInfo.InvariantCulture)).Append("\r\n");
            sb.Append("sessions_price_cache_write_per_mtok=").Append(c.SessionsPriceCacheWritePerMTok.ToString(System.Globalization.CultureInfo.InvariantCulture)).Append("\r\n");
            sb.Append("sessions_price_out_per_mtok=").Append(c.SessionsPriceOutPerMTok.ToString(System.Globalization.CultureInfo.InvariantCulture)).Append("\r\n");
            sb.Append("sessions_budget_usd_per_day=").Append(c.SessionsBudgetUsdPerDay.ToString(System.Globalization.CultureInfo.InvariantCulture)).Append("\r\n");
            // —— 悬边状态灯悬浮窗（2026-10-26 · 提案 §11 ✓）——
            sb.Append("overlay_enabled=").Append(c.OverlayEnabled ? "on" : "off").Append("\r\n");
            sb.Append("overlay_light_style=").Append(string.IsNullOrEmpty(c.OverlayLightStyle) ? DefaultOverlayLightStyle : c.OverlayLightStyle).Append("\r\n");
            sb.Append("overlay_edge=").Append(c.OverlayEdge).Append("\r\n");
            sb.Append("overlay_offset=").Append(c.OverlayOffset.ToString(System.Globalization.CultureInfo.InvariantCulture)).Append("\r\n");
            sb.Append("overlay_scale=").Append(c.OverlayScale).Append("\r\n");
            sb.Append("overlay_screen=").Append(c.OverlayScreen == null ? "" : c.OverlayScreen).Append("\r\n");
            sb.Append("overlay_show_title=").Append(c.OverlayShowTitle ? "on" : "off").Append("\r\n");
            return sb.ToString();
        }

        private static string Canon(Func<string, string> f, string v)
        {
            if (f == null) return v;
            try { return f(v); } catch { return null; }
        }
    }
}