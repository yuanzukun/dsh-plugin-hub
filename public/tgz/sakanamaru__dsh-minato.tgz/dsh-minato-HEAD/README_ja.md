# DeepSeek Harness Toolkit — `dsh-minato`

**DeepSeek Harness（dsh）のための導入・監視・バックアップ・修復ツールボックス。ターミナル不要、ダブルクリックで使えます。**
Windows と Linux に対応。すべて手元のマシン内で完結します：テレメトリなし、アカウントなし、アップロードなし。

> ⚠️ **非公式ツールです。** 本プロジェクトは DeepSeek 公式とは無関係で、承認や提携もありません。
> すでにお使いの `dsh` コマンドラインを操作するだけの第三者ツールです。
>
> **日本語** · [English](README.md) · [简体中文](README_zh-CN.md)

---

<p align="center">
  <img src="logo.png" alt="dsh-minato" width="180">
</p>

## スクリーンショット

以下はすべて実物の画面で、**フィクスチャのデータディレクトリ**に対して撮影したものです ——
実在のセッション・パス・数値は写っていません。

| ダッシュボード | セッションと Token | バックアップ |
|---|---|---|
| ![ダッシュボード](docs/screenshots/gui-kanban.png) | ![セッション](docs/screenshots/gui-sessions.png) | ![バックアップ](docs/screenshots/gui-backup.png) |

| ヘルスチェック | 設定 | 更新 |
|---|---|---|
| ![ヘルスチェック](docs/screenshots/gui-doctor.png) | ![設定](docs/screenshots/gui-settings.png) | ![更新](docs/screenshots/gui-update.png) |

<details>
<summary>残りのページ（概要 / プラグイン / このツールについて / ログ）と CLI</summary>

| 概要 | プラグイン | このツールについて | ログ |
|---|---|---|---|
| ![概要](docs/screenshots/gui-overview.png) | ![プラグイン](docs/screenshots/gui-plugins.png) | ![について](docs/screenshots/gui-about.png) | ![ログ](docs/screenshots/gui-logs.png) |

| CLI メニュー | CLI 状態 |
|---|---|
| ![CLI メニュー](docs/screenshots/cli-menu.png) | ![CLI 状態](docs/screenshots/cli-status.png) |

</details>

---

## なぜ作ったか

`dsh` はコマンドラインツールです。導入・起動・バックアップ・そして「起動しない理由」の調査はすべてターミナル作業で、
Web UI 側にはその入口がありません。

このツールボックスは、その作業をダブルクリックできるウィンドウの中に移します：

- **ターミナル不要** —— 導入・起動・停止・更新・アンインストールを GUI から。
- **信頼できるバックアップ** —— 各パッケージには完了マーカーとファイル単位の内容ハッシュが付き、
  途中で切れたパッケージや改変されたパッケージは**復元せずに拒否**します。
- **壊れたら、どこが壊れたかを言う** —— ヘルスチェックが該当項目を名指しし、直すための 1 行を提示します。

## できること

| | |
|---|---|
| **dsh の導入** | ダブルクリックで完了。ターミナルも Node.js の知識も不要です。CLI を導入し、PATH とスタートメニューを整え、導入先にアンインストーラを残します。 |
| **起動 / 停止 / 監視** | Web UI をボタン一つで起停。リアルタイムの状態行と開くべき URL 付き。 |
| **バックアップと復元** | セッション・設定・資格情報を 1 つのパッケージに。完了マーカーと内容ハッシュにより、切れた／改変されたパッケージは拒否されます。 |
| **バックアップ管理** | 触る前に、そのパッケージの中身を正確に確認できます。 |
| **別の PC への移行** | パッケージを書き出し、新しいマシンで読み込みます。 |
| **アップデートセンター** | web UI・公式デスクトップアプリ・本ツール・導入済みプラグインを 1 ページで。 |
| **ヘルスチェック** | 「どこが壊れているのか」—— 失敗している項目を名指しし、直す 1 行を示します。 |
| **アンインストール** | **既定ではデータを一切削除しません。** インストールに見えないディレクトリは削除を拒否します。 |

---

## インストール

### Windows

[Releases](../../releases) から `dsh-minato-<版>-win-x64-setup.exe` を取得して実行します。

- Windows の成果物は**デジタル署名されていません。** 初回に SmartScreen の「不明な発行元」が出ることがあります。
  実行前に、公開されている `.sha256` と GPG 署名付きの `hashes.txt` で照合してください。
- 展開して使いたい場合は `dsh-minato-win-x64.zip` を解凍し、`gui\dsht-gui.exe` を実行します。

### Linux

`dsh-minato-linux-x64.tar.gz` を取得して：

```bash
tar -xzf dsh-minato-linux-x64.tar.gz
cd dsh-minato-linux-x64
./install.sh            # 現在のユーザーに導入。--prefix <dir> で場所を指定
```

アンインストールは `./install.sh --uninstall`（自分で導入先を移動した場合のみ `--force` を追加）。

---

## クイックスタート

1. 上記の手順で導入し、**dsh-minato** を開きます。
2. ダッシュボードに現在の状態が出ます。`dsh` が未導入ならヘルスチェックがそう告げ、導線を示します。
3. **起動** を押し、表示された Web UI の URL を開きます。
4. 何かを変更する前に、まず **バックアップ** を押します。

---

## グラフィカル界面

左のナビゲーションに 10 ページ：

| ページ | 用途 |
|---|---|
| **概要** | 1 画面で全体：何が入っていて、何が動いていて、何が古いか。 |
| **ダッシュボード** | 主要な数字 —— セッション数、キャッシュヒット率、token —— とワンクリック起停。 |
| **セッションと Token** | セッションごとの内訳、親子のグループ化、並べ替え可能。 |
| **プロファイルとプラグイン** | 各 profile が持つプラグイン、無効化されたもの、起動を壊すもの。 |
| **バックアップ** | 作成・確認・検証・復元・書き出し・削除。 |
| **ヘルスチェック** | 「どこが壊れたか」の報告と処方。**ボタンを押したときだけ実行されます（自動では走りません）。** |
| **設定** | 言語・ポート・挙動 —— YAML を手で編集せずに。 |
| **このツールについて** | バージョン・謝辞、そして本ツールが**意図的にやらないこと**。 |
| **更新** | dsh・デスクトップアプリ・本ツール・プラグインの更新。 |
| **ログ** | ランチャーログの絞り込み・検索・書き出し。 |

---

## コマンドライン

GUI が動かしているのは同じ CLI で、単体でも使えます：

```text
dsh-minato status [--detail]      何が入っているか / 動いているか / 待ち受けているか
dsh-minato start | stop           dsh Web UI の起動・停止
dsh-minato install | update       dsh（と本ツール）の導入・更新
dsh-minato uninstall              本ツールの削除（データには触れません）
dsh-minato sessions               セッションごとの token とキャッシュの数字
dsh-minato backup [--to <dir>]    バックアップパッケージを作成
dsh-minato backup-list [--verify] パッケージ一覧と内容の検証
dsh-minato backup-dir [--set <d>] バックアップの書き出し先
dsh-minato restore --path <pkg> [--apply] [--yes]
dsh-minato backup-export | backup-delete
dsh-minato doctor                 総合ヘルスチェックと処方
dsh-minato profiles | profilecheck | profilepatch | bridge-install
dsh-minato bootdiag               dsh が起動しない理由は？
dsh-minato verify-install         ダウンロードしたファイルの照合
dsh-minato balance                DeepSeek の残高（設定に key が必要）
dsh-minato log | config-get | config-set | autostart | shortcut
dsh-minato version | about | selftest
```

各コマンドは機械可読なマーカー行（`STATUS_OK`、`BACKUP_OK`、`RESTORE_FAIL` など）を出力します。
スクリプトも GUI も、文章から推測するのではなくそれを解析します。

---

## 安全とプライバシー —— 実際にコードがしていること

この節はコードの挙動だけを述べます。ここに書いてあることをコードがしていなければ、それはバグです。

- **ローカルのみ。** ツールは自分のマシンを読み書きするだけです。ネットワークに接続するのは
  `check`、`update-info`、`update-center`、`doctor`、`install`、`update`、`verify-install --url`、
  および `balance`（**`balance_key` を設定している場合のみ**）です。
  それ以外（status、sessions、backup、restore、ログ）は**接続しません**。
- **テレメトリなし、アカウントなし、アップロードなし。**
- **アンインストールでデータは消えません。** 削除するのはツール自身のファイルだけです。データの削除は別の明示的な操作です。
- **バックアップの完全性は検証されるもので、仮定されるものではありません。** パッケージには最後に書かれる完了マーカーと
  ファイル単位のハッシュが付き、中断されたものや内容が変わったものは拒否されます。
- **CLI・インストーラ・ランチャー・dsh プラグインは第三者ランタイム依存ゼロ。** 例外は GUI が使う
  Avalonia（UI フレームワーク）だけです。
- **API key を設定した場合**、それはローカルの設定ファイルに**平文**で保存され、`balance` コマンドが
  DeepSeek の API エンドポイントへ送る以外に使われません。空のままなら何も保存されません。

---

## 既知の制限

- **サイズ**：Windows の自己完結パッケージは約 50 MB（.NET ランタイムを内包するため、別途の導入は不要です）。
- **デジタル署名はありません**：証明書ではなく、公開されている `.sha256` と GPG 署名で照合してください。
- **ブリッジプラグインには pnpm が必要**（`npm i -g pnpm`）。`dsh` は代わりに導入してくれません。
- **`desktop` profile は公式デスクトップアプリが管理します** —— そのプラグインはアプリ側のダイアログから追加します。

---

## オプションのブリッジプラグイン

`dsh` だけが知っている事実が 1 つあります：**どのセッションが生きているか**。これはディスクに書かれないため、
プラグインなしではその列は `unknown` になります。

| | プラグインなし | プラグインあり |
|---|---|---|
| セッション一覧・token・キャッシュヒット率・速度 | ✅（ディスク上の投影を読む） | ✅ |
| **「実行中 / 待機中」マーカー** | `unknown` | ✅ **プロセス内のリアルタイム情報** |

読み取り専用です：モデル呼び出しなし、dsh の状態への書き込みなし、会話本文の読み取りなし、ネットワークなし、
そして dsh を決してブロックしません。導入は：

```bash
dsh-minato bridge-install --profile web --yes
# または、リポジトリの URL をデスクトップアプリの「プラグイン追加」に貼り付け
```

これがなくても、ツールボックスの他の機能はすべて動きます。

---

## ライセンスと謝辞

- [MIT License](LICENSE)。**コードは MIT ですが、アイコンはそうではありません** —— 出典と許諾は `docs/ASSETS.md` を参照。
- [DeepSeek Harness (dsh)](https://www.npmjs.com/package/@deepseek-ai/dsh)
- **AI 支援について、率直に**：v1 スクリプトは SOGR-Momono Dango（QwenPaw）の支援、v2 の書き直しとパッケージングは
  DeepSeek DSH の支援によるものです。v3 とこの文書は主に AI コーディングエージェントが書き、すべての変更を
  メンテナが確認・判断・受諾しています。ロゴは生成 AI の出力（ツール：Kimi）で、プロンプトはメンテナが作成しました。
- これは「AI が書いたから信用できない」でも「AI が書いたから問題ない」でもありません。判断の根拠は
  **自分で検証できるかどうか**であるべきです：全成果物に SHA-256 が付き、CLI・インストーラ・ランチャーは
  すべて読めるソースです。
- GitHub：[@sakanamaru](https://github.com/sakanamaru)
