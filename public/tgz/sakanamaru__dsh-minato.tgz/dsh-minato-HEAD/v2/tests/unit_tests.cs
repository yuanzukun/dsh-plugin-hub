﻿// DeepSeek Harness Toolkit - 单元测试（与生产源码同程序集编译）
// 构建: csc /nologo /target:exe /define:UNIT /out:unittests.exe dsh_v2.cs tests\unit_tests.cs
// 运行: unittests.exe   （退出码 0=全过，1=有失败）
// 说明: 生产文件 dsh_v2.cs 中 Main 被 #if !UNIT 包裹，本文件提供测试入口；
//       所有被测方法为 dsh_v2.cs 内的内部 static 方法，同程序集直接访问，无第三方依赖。
using System;
using System.IO;
using System.Text;

public static class UnitTests
{
    static int fails = 0;
    static int total = 0;

    static void Check(bool ok, string name)
    {
        total++;
        if (ok) { Console.WriteLine("  [PASS] " + name); }
        else { fails++; Console.WriteLine("  [FAIL] " + name); }
    }

    static bool BytesEq(byte[] a, byte[] b)
    {
        if (a == null || b == null || a.Length != b.Length) return false;
        for (int i = 0; i < a.Length; i++) if (a[i] != b[i]) return false;
        return true;
    }

    public static void Main()
    {
        try { AppContext.SetSwitch("Switch.System.IO.UseLegacyPathHandling", false); } catch { }
        try { AppContext.SetSwitch("Switch.System.IO.BlockLongPaths", false); } catch { }
        Console.OutputEncoding = new System.Text.UTF8Encoding(false);
        Console.WriteLine("== DeepSeek Harness Toolkit unit tests ==");

        // ---- P / TrimP 往返（UNC / 中文空格 / 深路径 / 盘根） ----
        Console.WriteLine("[1] P/TrimP roundtrip");
        string[] paths = {
            @"\\nas\share\team",
            @"C:\x\y",
            @"C:\x",
            @"D:\work\recovery\sub",
            @"\\server\deep\dir with space",
            @"D:\work\中文 目录\node_modules\.bin",
            @"C:\Program Files (x86)\Node"
        };
        foreach (string c in paths)
        {
            string t = Program.Test.PathP(c);
            string back = Program.Test.PathTrim(t);
            Check(back.Equals(c, StringComparison.OrdinalIgnoreCase), "roundtrip " + c);
        }
        Check(Program.Test.PathTrim(Program.Test.PathP(@"D:\work\中文 目录\node_modules\.bin")).Equals(@"D:\work\中文 目录\node_modules\.bin", StringComparison.OrdinalIgnoreCase), "deep roundtrip (unsafe->safe->unsafe)");

        // ---- v2.7.3 修复：P() 必须先把相对路径转绝对 ----
        // 症状：`restore --dry-run --path .\backup\...` 在 v2.7.2 里谎报 DRYRUN_NEW 0
        //（\\?\.\backup 不是合法 Win32 路径 → 遍历抛异常 → PlanMergeCore 的 catch 静默吞掉）
        Console.WriteLine("[1b] P() on relative paths (v2.7.3 fix)");
        string relP = Program.Test.PathP(@"backup\dsh-data-20260101-000000");
        Check(relP.IndexOf(@"\\?\.", StringComparison.Ordinal) < 0, "relative -> not the invalid \\?\\.\\ form");
        Check(relP.EndsWith(@"backup\dsh-data-20260101-000000", StringComparison.OrdinalIgnoreCase), "relative -> tail preserved");
        string relBack = Program.Test.PathTrim(relP);
        Check(relBack.Length >= 3 && relBack[1] == ':', "relative -> resolved to a rooted absolute path");
        Check(Program.Test.PathP(@"C:\x\y") == @"\\?\C:\x\y", "absolute unchanged");
        Check(Program.Test.PathP(@"\\nas\share\team") == @"\\?\UNC\nas\share\team", "UNC unchanged");
        Check(Program.Test.PathP(@"\\?\C:\x") == @"\\?\C:\x", "already-prefixed unchanged");
        {
            string oldCwd = Environment.CurrentDirectory;
            string relRoot = Path.Combine(Path.GetTempPath(), "dsht_relpath_" + Guid.NewGuid().ToString("N"));
            try
            {
                string bkDir = Path.Combine(relRoot, "bk", "dsh-data-20260101-000000");
                Directory.CreateDirectory(bkDir);
                File.WriteAllText(Path.Combine(bkDir, "settings.yaml"), "x");
                File.WriteAllText(Path.Combine(bkDir, "sessions"), "x");
                string dstDir = Path.Combine(relRoot, "data");
                Directory.CreateDirectory(dstDir);
                Environment.CurrentDirectory = relRoot;
                long[] relPlan = Program.Test.PlanMergeT(@".\bk\dsh-data-20260101-000000", dstDir, "_workspace", null);
                Check(relPlan[0] == 2 && relPlan[1] == 0 && relPlan[2] == 0, "relative --path dry-run plan sees both files (was 0 before the fix)");
            }
            finally
            {
                Environment.CurrentDirectory = oldCwd;
                try { Directory.Delete(relRoot, true); } catch { }
            }
        }

        // ---- LooksLikeWorkspace 黑名单 ----
        Console.WriteLine("[2] LooksLikeWorkspace blacklist");
        string home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        string[] bad = {
            home, home + @"\Public", home + @"\Documents\myproj", @"C:\Program Files",
            @"C:\Program Files (x86)", @"C:\ProgramData", @"C:\PerfLogs", @"C:\Inetpub",
            @"C:\Recovery", @"C:\$Recycle.Bin", @"C:\System Volume Information",
            home + @"\Desktop", @"D:\", @"C:\", @"E:\", @"D:\windows.old",
            @"C:\$winreagent", home + @"\AppData", home + @"\.dsh"
        };
        foreach (string b in bad)
            Check(!Program.Test.WorkspaceOk(b), "reject " + b);
        string[] good = { @"D:\work\recovery\sub", @"\\nas\share\team", @"D:\dev\proj-a" };
        foreach (string g in good)
            Check(Program.Test.WorkspaceOk(g), "allow " + g);

        // ---- LooksLikeDshData ----
        Console.WriteLine("[3] LooksLikeDshData markers");
        string td = Path.Combine(Path.GetTempPath(), "ulldd_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(td);
        Check(!Program.Test.DshData(td), "empty dir -> false");
        File.WriteAllText(Path.Combine(td, "settings.yaml"), "x");
        Check(Program.Test.DshData(td), "settings.yaml -> true");
        File.Delete(Path.Combine(td, "settings.yaml"));
        Directory.CreateDirectory(Path.Combine(td, "sessions"));
        Check(Program.Test.DshData(td), "sessions dir -> true");
        Directory.Delete(Path.Combine(td, "sessions"));
        Check(!Program.Test.DshData(Path.Combine(td, "no-such-dir")), "missing dir -> false");
        try { Directory.Delete(td); } catch { }

        // ---- IsPortOpen（环境自适应 + 恒否） ----
        Console.WriteLine("[4] IsPortOpen");
        bool live3080 = IO.Port3080Open();
        Check(Program.Test.PortOpen(3080, 500) == live3080, "3080 matches live state (" + live3080 + ")");
        Check(!Program.Test.PortOpen(59999, 400), "59999 (unused) -> false");

        // ---- v2.1 F: 日志轮转 ----
        Console.WriteLine("[5] log rotation");
        string lr = Path.Combine(Path.GetTempPath(), "ulrot_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(lr);
        string lf = Path.Combine(lr, "launcher.log");
        Check(!Program.Test.RotateLog(lf, 100), "no file -> no rotation");
        File.WriteAllText(lf, new string('a', 5000));
        Check(Program.Test.RotateLog(lf, 100), "over limit -> rotated");
        Check(File.Exists(lf + ".1") && File.Exists(lf), "archive + new file exist");
        Check(!Program.Test.RotateLog(lf, 1000000), "under limit -> no rotation");
        File.WriteAllText(lf + ".1", "old");
        File.WriteAllText(lf, new string('b', 99));
        Check(Program.Test.RotateLog(lf, 50) && File.ReadAllText(lf + ".1") == new string('b', 99), "over limit rotates and overwrites old .1");
        try { Directory.Delete(lr, true); } catch { }

        // ---- v2.1 G: 备份命名规则 ----
        Console.WriteLine("[6] backup naming (kind suffix)");
        Check(Program.Test.BkSuffix(Program.BackupKind.Manual) == "", "manual -> no suffix");
        Check(Program.Test.BkSuffix(Program.BackupKind.Auto) == "-auto", "auto -> -auto");
        Check(Program.Test.BkSuffix(Program.BackupKind.PreRestore) == "-pre-restore", "pre-restore suffix");
        Check(Program.Test.BkSuffix(Program.BackupKind.PreImport) == "-pre-import", "pre-import suffix");
        Check(Program.Test.BkSuffix(Program.BackupKind.PreWipe) == "-pre-wipe", "pre-wipe suffix");
        Check(!Program.Test.IsAutoName("dsh-data-20260101-000001"), "manual name -> not auto");
        Check(Program.Test.IsAutoName("dsh-data-20260101-000001-") == false, "bare dash -> not auto");
        Check(Program.Test.IsAutoName("dsh-data-20260101-000001-auto") && Program.Test.IsAutoName("dsh-data-20260101-000001-pre-restore"), "auto/pre names -> auto");
        Check(Program.Test.IsAutoName("dsh-data-20260101-000001-pre-wipe") && Program.Test.IsAutoName("dsh-data-20260101-000001-pre-import"), "pre-wipe/pre-import -> auto");

        // ---- v2.1 G: 保留策略（只清自动类 / 保底 / 手动永久） ----
        Console.WriteLine("[7] backup retention");
        // Retention() 扫描 StateDir\backup = 本 exe 运行目录；单测进程不跑生产 Main，需注入 StateDir
        string runDir = AppDomain.CurrentDomain.BaseDirectory;
        Program.Test.SetStateDir(runDir);
        string rb = Path.Combine(runDir, "backup");
        if (Directory.Exists(rb)) Directory.Delete(rb, true);
        Directory.CreateDirectory(rb);
        // 手动 2 份（无后缀）
        Directory.CreateDirectory(Path.Combine(rb, "dsh-data-20260101-000001"));
        Directory.CreateDirectory(Path.Combine(rb, "dsh-data-20260101-000002"));
        // 自动类 5 份（pre-restore）
        for (int i = 1; i <= 5; i++)
            Directory.CreateDirectory(Path.Combine(rb, "dsh-data-20260101-00000" + i + "-pre-restore"));
        Program.Test.SetKeep(4);
        var rm = Program.Test.Retention();
        Check(rm.Count == 1 && rm[0] == "dsh-data-20260101-000001-pre-restore", "5 auto with keep=4 -> removed only oldest auto");
        Check(!Directory.Exists(Path.Combine(rb, "dsh-data-20260101-000001-pre-restore")), "oldest auto gone");
        Check(Directory.Exists(Path.Combine(rb, "dsh-data-20260101-000005-pre-restore")), "newest auto kept");
        Check(Directory.Exists(Path.Combine(rb, "dsh-data-20260101-000001")) && Directory.Exists(Path.Combine(rb, "dsh-data-20260101-000002")), "manual backups never removed");
        // 保底 3：keep<3 时按 3 处理
        for (int i = 1; i <= 5; i++)
            Directory.CreateDirectory(Path.Combine(rb, "dsh-data-20260102-00000" + i + "-pre-import"));
        Program.Test.SetKeep(2);
        var rm2 = Program.Test.Retention();
        int autoLeft = 0;
        foreach (string d in Directory.GetDirectories(rb))
            if (Program.Test.IsAutoName(Path.GetFileName(d))) autoLeft++;
        Check(rm2.Count == 6 && autoLeft == 3, "keep=2 clamps to 3 (floor); oldest 6 across all auto kinds removed, 3 kept");
        try { Directory.Delete(rb, true); } catch { }
        Program.Test.SetKeep(10);

        // ---- v2.1 B: 服务状态三态判定 ----
        Console.WriteLine("[8] service state judge");
        Check(Program.Test.JudgeState(false, false) == Program.ServiceState.Down, "port closed -> Down");
        Check(Program.Test.JudgeState(false, true) == Program.ServiceState.Down, "port closed (+http) -> Down");
        Check(Program.Test.JudgeState(true, false) == Program.ServiceState.Listening, "port open, http not ready -> Listening");
        Check(Program.Test.JudgeState(true, true) == Program.ServiceState.Ready, "port + http ready -> Ready");

        // ---- v2.4.2: 就绪判定的监听进程兜底（dsh 0.1.5+ 未授权请求统一 401） ----
        Console.WriteLine("[8b] service state judge (listener fallback)");
        Check(Program.Test.JudgeState3(false, false, () => true) == Program.ServiceState.Down, "v2.4.2 port closed -> Down even if listener claims dsh");
        Check(Program.Test.JudgeState3(false, true, () => true) == Program.ServiceState.Down, "v2.4.2 port closed (+http) -> Down");
        Check(Program.Test.JudgeState3(true, false, () => false) == Program.ServiceState.Listening, "v2.4.2 port open, no http, not dsh -> Listening");
        Check(Program.Test.JudgeState3(true, false, () => true) == Program.ServiceState.Ready, "v2.4.2 port open + listener is dsh -> Ready (401 case)");
        Check(Program.Test.JudgeState3(true, true, () => false) == Program.ServiceState.Ready, "v2.4.2 port + http ready -> Ready (listener irrelevant)");
        Check(Program.Test.JudgeState3(true, false, null) == Program.ServiceState.Listening, "v2.4.2 null listener delegate -> Listening");
        Check(Program.Test.JudgeState3(true, false, () => { throw new Exception("probe blew up"); }) == Program.ServiceState.Listening, "v2.4.2 listener probe throws -> Listening (never Ready)");
        bool listenerCalled = false;
        Program.Test.JudgeState3(true, true, () => { listenerCalled = true; return true; });
        Check(!listenerCalled, "v2.4.2 listener check skipped when http already ready (lazy)");

        // ---- v2.1 A: 版本比较 / 更新解析 / 更新探测（注入假网络） ----
        Console.WriteLine("[9] update check");
        Check(Program.Test.CmpVer("2.0.0", "2.1.0") < 0, "2.0.0 < 2.1.0");
        Check(Program.Test.CmpVer("2.1.0", "2.1.0") == 0, "equal");
        Check(Program.Test.CmpVer("2.2.0", "2.1.0") > 0, "2.2.0 > 2.1.0");
        Check(Program.Test.CmpVer("2.10.0", "2.9.9") > 0, "2.10.0 > 2.9.9 (numeric, not lexicographic)");
        Check(Program.Test.CmpVer("2.1", "2.1.0") == 0, "2.1 == 2.1.0 (missing segment = 0)");
        Check(Program.Test.ParseTag("{ \"tag_name\": \"v2.1.0\" }") == "2.1.0", "parse tag with v prefix");
        Check(Program.Test.ParseTag("{ \"something\": 1 }") == null, "no tag_name -> null");
        Check(Program.Test.ParseTag("not json") == null, "garbage -> null");
        Program.Test.SetHttpGet(delegate(string u, int ms) { return "{ \"tag_name\": \"v9.9.9\" }"; });
        string cur2 = Program.Test.CurVer();
        Check(Program.Test.Latest() == "9.9.9", "newer release detected (" + cur2 + " -> 9.9.9)");
        Program.Test.SetHttpGet(delegate(string u, int ms) { return "{ \"tag_name\": \"v" + cur2 + "\" }"; });
        Check(Program.Test.Latest() == null, "same version -> no update");
        Program.Test.SetHttpGet(delegate(string u, int ms) { return null; });
        Check(Program.Test.Latest() == null, "network failure -> silent null");
        Program.Test.SetHttpGet(null);

        Console.WriteLine("[10] dsh update management");
        // BackupKind.PreUpdate 后缀 + 自动类识别
        Check(Program.Test.BkSuffix(Program.BackupKind.PreUpdate) == "-pre-update", "pre-update suffix");
        Check(Program.Test.IsAutoName("dsh-data-20260101-000001-pre-update"), "pre-update -> auto");
        // 版本输出解析（单行数组 + JSON 多行 + 空）
        string[] p1 = Program.Test.ParseVersions("[ '0.1.0', '1.0.0', '2.0.0' ]");
        Check(p1.Length == 3 && p1[1] == "1.0.0", "parse single-line array");
        string[] p2 = Program.Test.ParseVersions("[\n  \"1.0.0\",\n  \"2.0.0\"\n]");
        Check(p2.Length == 2 && p2[0] == "1.0.0", "parse JSON multiline");
        Check(Program.Test.ParseVersions(null).Length == 0 && Program.Test.ParseVersions("").Length == 0, "empty -> empty");
        // 干净版本判断
        Check(Program.Test.CleanVer("2.1.0") && Program.Test.CleanVer("1.0") && !Program.Test.CleanVer("2.1.0-beta.1") && !Program.Test.CleanVer("abc") && !Program.Test.CleanVer("1.2.3.4"), "clean version filter");
        // 版本过滤：保留 pre-release（核心段干净即可）、排序、取最近 N 倒序
        string[] f1 = Program.Test.FilterVers(new string[] { "1.0.0", "2.0.0", "0.9.0", "2.1.0-beta.1", "garbage", "1.5.0" }, 3);
        Check(f1.Length == 3 && f1[0] == "2.1.0-beta.1" && f1[1] == "2.0.0" && f1[2] == "1.5.0", "filter keeps pre-release, sorts desc, takes N");
        string[] f2 = Program.Test.FilterVers(new string[] { "1.0.0", "2.0.0" }, 10);
        Check(f2.Length == 2 && f2[0] == "2.0.0", "N > count keeps all, newest first");
        // v2.1.2 回归修复：pre-release（rc）版本支持——dsh 正式发布均为 rc
        Check(Program.Test.SanitizeLatest("0.1.1-rc.2") == "0.1.1-rc.2" && Program.Test.SanitizeLatest("v2.1.0") == "2.1.0", "sanitize accepts rc / v-prefix");
        Check(Program.Test.SanitizeLatest("garbage") == null && Program.Test.SanitizeLatest("latest") == null && Program.Test.SanitizeLatest("") == null && Program.Test.SanitizeLatest(null) == null, "sanitize rejects garbage");
        Check(Program.Test.CmpVer("0.1.1", "0.1.1") == 0 && Program.Test.CmpVer("0.1.1-rc.2", "0.1.1") < 0 && Program.Test.CmpVer("0.1.1-rc.2", "0.2.0") < 0 && Program.Test.CmpVer("2.1.0-beta.1", "2.1.0") < 0 && Program.Test.CmpVer("2.1.0-rc.1", "2.1.0-rc.2") < 0 && Program.Test.CmpVer("2.1.0-rc.2", "2.1.0-rc.10") < 0 && Program.Test.CmpVer("2.1.0-rc.10", "2.1.0-rc.2") > 0 && Program.Test.CmpVer("2.1.0-alpha", "2.1.0-beta") < 0 && Program.Test.CmpVer("2.1.0-rc.1", "2.1.0-rc.1") == 0, "CompareVersions: release > rc; rc.1 < rc.2 < rc.10; alpha < beta; equal rc equal");
        // v2.1.2 安全加固：严格整串白名单——拒绝任何命令注入字符（空格/&/;/|/>/</引号/反引号等），含预发布段
        Check(Program.Test.SanitizeLatest("1.2.3&calc") == null && Program.Test.SanitizeLatest("1.2.3; calc.exe") == null && Program.Test.SanitizeLatest("1.2.3|cmd") == null && Program.Test.SanitizeLatest("1.2.3>nul") == null && Program.Test.SanitizeLatest("1.2.3<in") == null && Program.Test.SanitizeLatest("1.2.3-rc.2 & echo pwned") == null && Program.Test.SanitizeLatest("1.2.3-rc.2\" & whoami") == null, "sanitize rejects injection characters");
        Check(Program.Test.SanitizeLatest("1.2.3-rc.2-beta.3") == null && Program.Test.SanitizeLatest("1.2.3-") == null, "sanitize rejects double dash / trailing dash");
        Check(Program.Test.SanitizeLatest("v1.2.3") == "1.2.3" && Program.Test.SanitizeLatest("1.2.3") == "1.2.3" && Program.Test.SanitizeLatest("0.1.1-rc.2") == "0.1.1-rc.2" && Program.Test.SanitizeLatest("1.2.3-alpha") == "1.2.3-alpha", "sanitize keeps valid versions");
        string[] fi = Program.Test.FilterVers(new string[] { "1.0.0", "1.2.3&calc", "2.0.0-rc.1;x", "3.0.0-beta.2" }, 10);
        Check(fi.Length == 2 && fi[0] == "3.0.0-beta.2" && fi[1] == "1.0.0", "filter drops injection strings");
        // 历史版本记忆：去重、最新在前、截断 10
        Program.Test.ResetVersions();
        Program.Test.RecordVer("v2.0.0");
        Program.Test.RecordVer("2.1.0");
        Program.Test.RecordVer("2.0.0");   // 重复 -> 去重并提到最前
        Check(Program.Test.DshVersions() == "2.0.0,2.1.0", "record dedupes, newest first");
        for (int i = 0; i < 12; i++) Program.Test.RecordVer("1." + i + ".0");
        string[] hv = Program.Test.DshVersions().Split(',');
        Check(hv.Length == 10 && hv[0] == "1.11.0", "history truncated to 10, newest first");
        Program.Test.ResetVersions();
        // P1 修复契约：备份源不存在 -> null（UpdateDsh 据此跳过 pre-update 备份而非中止）
        Check(Program.Test.DoBackup(Path.Combine(Path.GetTempPath(), "dsht-no-such-" + Guid.NewGuid().ToString("N"))) == null, "DoBackup missing source -> null");

        Console.WriteLine("[11] protection backup strictness (v2.1.2)");
        // Pre*（保护性）备份遇到被锁文件 -> 整体失败(null)；手动备份 best-effort 成功且跳过被锁文件
        string sdir = Path.Combine(Path.GetTempPath(), "dsht-strict-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(sdir);
        File.WriteAllText(Path.Combine(sdir, "ok.txt"), "1");
        string lockF = Path.Combine(sdir, "locked.bin");
        File.WriteAllText(lockF, "x");
        var lockStream = new FileStream(lockF, FileMode.Open, FileAccess.ReadWrite, FileShare.None);   // 独占锁定：复制必然失败
        try
        {
            Check(Program.Test.DoBackupKind(sdir, Program.BackupKind.PreRestore) == null, "Pre* backup fails when a file is locked (strict)");
            Check(Program.Test.DoBackupKind(sdir, Program.BackupKind.Manual) != null, "Manual backup skips locked file (best-effort)");
        }
        finally { lockStream.Dispose(); }
        try { Directory.Delete(sdir, true); } catch { }
        try { Directory.Delete(Path.Combine(runDir, "backup"), true); } catch { }   // 清掉本块产生的备份目录

        Console.WriteLine("[12] wipe root-marker strictness (pre-review)");
        string mdir = Path.Combine(Path.GetTempPath(), "dsht-marker-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(mdir);
        Check(!Program.Test.RootMarker(mdir), "no marker -> invalid");
        File.WriteAllText(Path.Combine(mdir, ".dsh_launcher_root"), "", new UTF8Encoding(false));
        Check(!Program.Test.RootMarker(mdir), "empty marker -> invalid (forged empty file rejected)");
        File.WriteAllText(Path.Combine(mdir, ".dsh_launcher_root"), "garbage\n", new UTF8Encoding(false));
        Check(!Program.Test.RootMarker(mdir), "garbage marker -> invalid");
        File.WriteAllText(Path.Combine(mdir, ".dsh_launcher_root"), "DeepSeek Harness Toolkit V2.1.2\n", new UTF8Encoding(false));
        Check(Program.Test.RootMarker(mdir), "product-name marker -> valid");
        File.WriteAllText(Path.Combine(mdir, ".dsh_launcher_root"), "deepseek harness toolkit V9.9.9\n", new UTF8Encoding(false));
        Check(Program.Test.RootMarker(mdir), "version-agnostic marker -> valid");
        try { Directory.Delete(mdir, true); } catch { }

        Console.WriteLine("[13] backup dir validation (pre-review)");
        string bdir = Path.Combine(Path.GetTempPath(), "dsht-bkval-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(bdir);
        // 名字不对 -> 无效
        string bad1 = Path.Combine(bdir, "backup-folder"); Directory.CreateDirectory(bad1);
        File.WriteAllText(Path.Combine(bad1, "settings.yaml"), "x");
        Check(!Program.Test.ValidBackup(bad1), "name without dsh-data- prefix -> invalid");
        // 名字对但内容空 -> 无效
        string empty = Path.Combine(bdir, "dsh-data-20260101-000001"); Directory.CreateDirectory(empty);
        Check(!Program.Test.ValidBackup(empty), "dsh-data-* but empty -> invalid");
        // 名字对 + 数据特征 -> 有效
        File.WriteAllText(Path.Combine(empty, "settings.yaml"), "x");
        Check(Program.Test.ValidBackup(empty), "dsh-data-* + settings.yaml -> valid");
        // 名字对 + 只有 _workspace -> 有效（纯工作区备份）
        string wsOnly = Path.Combine(bdir, "dsh-data-20260101-000002"); Directory.CreateDirectory(wsOnly);
        Directory.CreateDirectory(Path.Combine(wsOnly, "_workspace", "proj"));
        Check(Program.Test.ValidBackup(wsOnly), "dsh-data-* + _workspace only -> valid");
        // 目录不存在 -> 无效
        Check(!Program.Test.ValidBackup(Path.Combine(bdir, "dsh-data-nope")), "missing dir -> invalid");
        // ResolveBackupDir：直接给备份目录 -> 原样返回；给仅含一个备份的父目录 -> 下探定位
        Check(Program.Test.ResolveBackup(empty) == empty, "resolve: backup dir itself -> same");
        string parent = Path.Combine(bdir, "parent"); Directory.CreateDirectory(parent);
        Check(Program.Test.ResolveBackup(parent) == null, "resolve: empty parent -> null");
        Directory.CreateDirectory(Path.Combine(parent, "dsh-data-20260101-000003"));
        File.WriteAllText(Path.Combine(parent, "dsh-data-20260101-000003", "credentials.yaml"), "x");
        Check(Program.Test.ResolveBackup(parent) != null && Path.GetFileName(Program.Test.ResolveBackup(parent)).StartsWith("dsh-data-"), "resolve: parent with one dsh-data-* -> descends");
        try { Directory.Delete(bdir, true); } catch { }

        // ---- 桌面快捷方式 ----
        Console.WriteLine("[Z] desktop shortcut");
        string sd = Path.Combine(Path.GetTempPath(), "dsh_ut_shortcut_" + Guid.NewGuid().ToString("N"));
        try { Directory.Delete(sd, true); } catch { }
        // DSH_TEST_DESKTOP 隔离生效
        Check(Program.Test.Desktop(sd) == sd, "env DSH_TEST_DESKTOP overrides desktop");
        // 创建前不存在 -> 监控页应显示 I
        Check(!Program.Test.ShortcutExists(sd), "shortcut not exists -> show I option");
        // 创建快捷方式（临时目录，不碰真实桌面）
        string err = Program.Test.Shortcut(sd);
        Check(err == null, "shortcut created (err=" + (err ?? "(null)") + ")");
        Check(File.Exists(Path.Combine(sd, "DeepSeek Harness Toolkit.lnk")), "shortcut file exists");
        // 创建后已存在 -> 监控页应隐藏 I
        Check(Program.Test.ShortcutExists(sd), "shortcut exists -> hide I option");
        // 不存在目录也自动创建
        string sd2 = Path.Combine(Path.GetTempPath(), "dsh_ut_shortcut_missing_" + Guid.NewGuid().ToString("N"));
        string err2 = Program.Test.Shortcut(sd2);
        Check(err2 == null && File.Exists(Path.Combine(sd2, "DeepSeek Harness Toolkit.lnk")), "shortcut auto-creates missing dir");
        // ---- v2.7：目标/基名可指定（GUI 要建"指向 GUI 自己"的快捷方式，而不是 CLI 的）----
        Console.WriteLine("[Z2] desktop shortcut target/name");
        string sd3 = Path.Combine(Path.GetTempPath(), "dsh_ut_shortcut_gui_" + Guid.NewGuid().ToString("N"));
        string selfExe = System.Reflection.Assembly.GetExecutingAssembly().Location;
        string err3 = Program.Test.ShortcutT(sd3, selfExe, "DeepSeek Harness Toolkit GUI", "DeepSeek Harness Toolkit GUI");
        Check(err3 == null, "custom target/name shortcut created (err=" + (err3 ?? "(null)") + ")");
        Check(File.Exists(Path.Combine(sd3, "DeepSeek Harness Toolkit GUI.lnk")), "GUI shortcut keeps its own file name");
        Check(!File.Exists(Path.Combine(sd3, "DeepSeek Harness Toolkit.lnk")), "GUI action does NOT create the CLI shortcut");
        Check(Program.Test.ShortcutNameT(@"..\..\evil") == "evil", "shortcut name strips directories (no traversal), got " + Program.Test.ShortcutNameT(@"..\..\evil"));
        Check(Program.Test.ShortcutNameT("a/b:c*d?e") == "bcde", "shortcut name strips invalid chars, got " + Program.Test.ShortcutNameT("a/b:c*d?e"));
        Check(Program.Test.ShortcutNameT("   ") == "", "blank shortcut name rejected");
        string err4 = Program.Test.ShortcutT(sd3, @"C:\nope\missing.exe", "x", null);
        Check(err4 != null && !File.Exists(Path.Combine(sd3, "x.lnk")), "missing target exe rejected (err=" + (err4 ?? "(null)") + ")");
        try { Directory.Delete(sd3, true); } catch { }
        try { Directory.Delete(sd, true); } catch { }
        try { Directory.Delete(sd2, true); } catch { }

        // ---- netstat 端口 PID 解析（非交互 stop 依赖） ----
        Console.WriteLine("[NIRESTORE] netstat ParsePortPid");
        Check(Program.Test.ParsePort("  TCP    127.0.0.1:3080    0.0.0.0:0    LISTENING    1234\r\n", 3080) == 1234, "parse 127.0.0.1:3080 LISTENING pid");
        Check(Program.Test.ParsePort("  TCP    0.0.0.0:3080      0.0.0.0:0    LISTENING    999\r\n", 3080) == 999, "parse 0.0.0.0:3080");
        Check(Program.Test.ParsePort("  TCP    [::]:3080          [::]:0       LISTENING    7\r\n", 3080) == 7, "parse IPv6 [::]:3080");
        Check(Program.Test.ParsePort("  TCP    127.0.0.1:3080    x  ESTABLISHED  55\r\n", 3080) == 0, "ESTABLISHED ignored");
        Check(Program.Test.ParsePort("  TCP    127.0.0.1:30801   x  LISTENING  66\r\n", 3080) == 0, "port 30801 != 3080 (suffix boundary)");
        Check(Program.Test.ParsePort("", 3080) == 0, "empty -> 0");
        Check(Program.Test.ParsePort("  TCP    127.0.0.1:3090    0.0.0.0:0  LISTENING  77\r\n", 3080) == 0, "different port -> 0");

        // ---- restore --path 路径校验（GUI 选择框推路径的安全闸） ----
        Console.WriteLine("[NIRESTORE] restore --path validation");
        string rpRoot = Path.Combine(Path.GetTempPath(), "dsh_ut_rp_" + Guid.NewGuid().ToString("N"));
        string rpBk = Path.Combine(rpRoot, "backup", "dsh-data-20260901-120000000");
        string rpOutBk = Path.Combine(Path.GetTempPath(), "dsh_ut_rp_out_" + Guid.NewGuid().ToString("N"));
        string rpBadName = Path.Combine(rpRoot, "backup", "not-a-backup");
        string rpEmptyBk = Path.Combine(rpRoot, "backup", "dsh-data-20260901-120000001");
        try
        {
            Directory.CreateDirectory(rpBk);
            File.WriteAllText(Path.Combine(rpBk, "settings.yaml"), "ws: test");
            Directory.CreateDirectory(rpOutBk);
            Directory.CreateDirectory(rpBadName);
            Directory.CreateDirectory(rpEmptyBk);
            string bkRoot = Path.Combine(rpRoot, "backup");
            Check(Program.Test.NIValidateRestorePath(rpBk, bkRoot) == null, "valid in-root backup passes");
            Check(Program.Test.NIValidateRestorePath("\"" + rpBk + "\"", bkRoot) == null, "quoted path passes");
            Check(Program.Test.NIValidateRestorePath("  " + rpBk + "  ", bkRoot) == null, "whitespace-padded path passes");
            Check(Program.Test.NIValidateRestorePath("", bkRoot) == "no-path", "empty rejected as no-path");
            Check(Program.Test.NIValidateRestorePath("   ", bkRoot) == "no-path", "whitespace-only rejected as no-path");
            Check(Program.Test.NIValidateRestorePath("\"\"", bkRoot) == "no-path", "empty quotes rejected as no-path");
            Check(Program.Test.NIValidateRestorePath(rpOutBk, bkRoot) == "outside", "sibling dir outside root rejected");
            Check(Program.Test.NIValidateRestorePath(@"C:\Windows\System32", bkRoot) == "outside", "system dir outside rejected");
            Check(Program.Test.NIValidateRestorePath(rpBadName, bkRoot) == "invalid", "non-dsh-data name rejected");
            Check(Program.Test.NIValidateRestorePath(rpEmptyBk, bkRoot) == "invalid", "empty dsh-data dir (no data signature) rejected");
            Check(Program.Test.NIValidateRestorePath(Path.Combine(rpRoot, "backup"), bkRoot) == "invalid", "backups root itself rejected");
        }
        finally
        {
            try { Directory.Delete(rpRoot, true); } catch { }
            try { Directory.Delete(rpOutBk, true); } catch { }
        }

        // ---- stop 前进程归属校验（防误杀占 3080 的其他程序） ----
        Console.WriteLine("[STOP] IsDshCommandLine");
        Check(Program.Test.IsDshCmd(@"C:\Users\me\AppData\Roaming\npm\node_modules\@deepseek-ai\dsh\dist\cli.js web"), "global npm dsh chain passes");
        Check(Program.Test.IsDshCmd(@"""C:\Program Files\nodejs\node.exe""  C:\Users\me\AppData\Roaming\npm\dsh.cmd web"), "dsh.cmd chain passes");
        Check(Program.Test.IsDshCmd(@"node  D:\somewhere\dsh-web\server.js"), "local dsh dir passes");
        Check(Program.Test.IsDshCmd("DSH web"), "uppercase DSH passes");
        Check(!Program.Test.IsDshCmd(@"node server.js"), "plain node server rejected");
        Check(!Program.Test.IsDshCmd(@"python -m http.server 3080"), "python http server rejected");
        Check(!Program.Test.IsDshCmd(@"C:\dev\myapp\server.exe --port 3080"), "unrelated exe rejected");
        Check(!Program.Test.IsDshCmd(""), "empty rejected");
        Check(!Program.Test.IsDshCmd(null), "null rejected");
        Check(!Program.Test.IsDshCmd("   "), "whitespace rejected");
        Check(!Program.Test.IsDshCmd("nothing here"), "no keyword rejected");

        // ---- v2.5 doctor：脱敏 / 汇总 / 大小 ----
        Console.WriteLine("[DOCTOR] SanitizeForReport");
        Check(Program.Test.Sand(@"http://127.0.0.1:3080/?token=abc123&x=1").Contains("token=[REDACTED]"), "url query token redacted");
        Check(!Program.Test.Sand(@"http://127.0.0.1:3080/?token=abc123&x=1").Contains("abc123"), "token value gone");
        Check(Program.Test.Sand("&token=xyz&more=1").Contains("token=[REDACTED]"), "amp query token redacted");
        Check(Program.Test.Sand("api_key=sk-live-9999").Contains("api_key=[REDACTED]"), "api_key redacted");
        Check(!Program.Test.Sand("api_key=sk-live-9999").Contains("sk-live-9999"), "api_key value gone");
        Check(Program.Test.Sand("password: hunter2").Contains("password=[REDACTED]"), "password colon redacted");
        Check(Program.Test.Sand("cookie=abc; lang=zh").Contains("lang=zh"), "cookie value only, lang kept");
        Check(Program.Test.Sand("A2F67D170B5BE4845612642C240979232B4E4CE4").Contains("[REDACTED]"), "40-hex redacted");
        Check(Program.Test.Sand("服务运行正常，无敏感信息") == "服务运行正常，无敏感信息", "plain text unchanged");
        Check(Program.Test.Sand("token=abc") == "token=[REDACTED]", "bare token= value redacted");
        Check(Program.Test.Sand("") == "", "empty unchanged");
        Check(Program.Test.Sand(null) == null, "null unchanged");

        Console.WriteLine("[DOCTOR] DoctorSummary");
        Check(Program.Test.DocSum(new System.Collections.Generic.List<Program.DocItem>()) == "DOCTOR_OK 0", "empty -> OK");
        var allOk = new System.Collections.Generic.List<Program.DocItem>();
        allOk.Add(Program.Test.DI("System", 0, "a")); allOk.Add(Program.Test.DI("Service", 0, "b"));
        Check(Program.Test.DocSum(allOk) == "DOCTOR_OK 0", "all ok -> OK");
        var oneWarn = new System.Collections.Generic.List<Program.DocItem>();
        oneWarn.Add(Program.Test.DI("Backup", 1, "no recent"));
        Check(Program.Test.DocSum(oneWarn) == "DOCTOR_WARN 1", "one warn -> WARN 1");
        var threeWarn = new System.Collections.Generic.List<Program.DocItem>();
        threeWarn.Add(Program.Test.DI("A", 1, "x")); threeWarn.Add(Program.Test.DI("B", 1, "y")); threeWarn.Add(Program.Test.DI("C", 1, "z"));
        Check(Program.Test.DocSum(threeWarn) == "DOCTOR_WARN 3", "three warns -> WARN 3");
        var errWins = new System.Collections.Generic.List<Program.DocItem>();
        errWins.Add(Program.Test.DI("A", 1, "w1")); errWins.Add(Program.Test.DI("B", 1, "w2")); errWins.Add(Program.Test.DI("C", 2, "e1"));
        Check(Program.Test.DocSum(errWins) == "DOCTOR_ERROR 1", "error beats warns -> ERROR 1");
        var twoErr = new System.Collections.Generic.List<Program.DocItem>();
        twoErr.Add(Program.Test.DI("A", 2, "e1")); twoErr.Add(Program.Test.DI("B", 2, "e2")); twoErr.Add(Program.Test.DI("C", 1, "w1"));
        Check(Program.Test.DocSum(twoErr) == "DOCTOR_ERROR 2", "two errors -> ERROR 2");
        Check(Program.Test.DocLvl(0) == "OK" && Program.Test.DocLvl(1) == "WARN" && Program.Test.DocLvl(2) == "ERROR", "level labels");

        Console.WriteLine("[DOCTOR] DirSize / HumanSize");
        string tdDoc = Path.Combine(Path.GetTempPath(), "dsh_ut_doctor_" + System.Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(tdDoc);
            Directory.CreateDirectory(Path.Combine(tdDoc, "sub"));
            File.WriteAllBytes(Path.Combine(tdDoc, "a.bin"), new byte[100]);
            File.WriteAllBytes(Path.Combine(tdDoc, "b.bin"), new byte[200]);
            File.WriteAllBytes(Path.Combine(tdDoc, "sub", "c.bin"), new byte[300]);
            Check(Program.Test.DirSizeOf(tdDoc) == 600, "dir size sums nested files");
            Check(Program.Test.DirSizeOf(Path.Combine(tdDoc, "sub")) == 300, "subdir size");
            Check(Program.Test.HumanOf(0) == "0 B", "human 0 B");
            Check(Program.Test.HumanOf(2048) == "2.0 KB", "human KB");
            Check(Program.Test.HumanOf(3L * 1024 * 1024) == "3.0 MB", "human MB");
            Check(Program.Test.HumanOf(2L * 1024 * 1024 * 1024) == "2.00 GB", "human GB");
        }
        finally { try { Directory.Delete(tdDoc, true); } catch { } }
        Check(Program.Test.DirSizeOf(Path.Combine(Path.GetTempPath(), "dsh_no_such_dir_xyz")) == 0, "missing dir -> 0");

        // ---- v2.5 安全批：自身完整性 manifest 解析 ----
        Console.WriteLine("[SEC] ParseManifestHash");
        string man = "# comment\r\n" +
                     "aaaa1111bbbb2222cccc3333dddd4444eeee5555ffff6666aaaa1111bbbb2222  DeepSeek Harness Toolkit.exe\r\n" +
                     "1111222233334444555566667777888899990000aaaabbbbccccddddeeeeffff  Toolkit GUI.exe\r\n";
        Check(Program.Test.ManHash(man, "DeepSeek Harness Toolkit.exe") == "aaaa1111bbbb2222cccc3333dddd4444eeee5555ffff6666aaaa1111bbbb2222", "manifest hash parsed");
        Check(Program.Test.ManHash(man, "toolkit gui.exe") == "1111222233334444555566667777888899990000aaaabbbbccccddddeeeeffff", "name case-insensitive");
        Check(Program.Test.ManHash(man, "missing.exe") == null, "missing name -> null");
        Check(Program.Test.ManHash(man, "") == null, "empty name -> null");
        Check(Program.Test.ManHash(null, "x.exe") == null, "null manifest -> null");
        Check(Program.Test.ManHash("# only comment\r\n", "x.exe") == null, "comment-only -> null");
        Check(Program.Test.ManHash("zzzz1111bbbb2222cccc3333dddd4444eeee5555ffff6666aaaa1111bbbb2222  x.exe", "x.exe") == null, "non-hex -> null");
        Check(Program.Test.ManHash("abcd  x.exe", "x.exe") == null, "short hash -> null");
        Check(Program.Test.ManHash("", "x.exe") == null, "empty manifest -> null");
        Check(Program.Test.ManHash("no-space-line\r\n", "x.exe") == null, "line without separator -> null");
        Check(Program.Test.SelfInteg() == null, "test env: no hashes.txt beside unittests.exe -> null (no block)");

        // ---- v2.6 Dry-Run 计划 / 备份类型 ----
        Console.WriteLine("[V26] PlanMerge / PlanDelete / KindName");
        string pmSrc = Path.Combine(Path.GetTempPath(), "dsh_ut_pm_src_" + Guid.NewGuid().ToString("N"));
        string pmDst = Path.Combine(Path.GetTempPath(), "dsh_ut_pm_dst_" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(Path.Combine(pmSrc, "sessions"));
            Directory.CreateDirectory(Path.Combine(pmSrc, "sessions", "node_modules"));
            File.WriteAllText(Path.Combine(pmSrc, "sessions", "a.json"), "12345");      // 覆盖（dst 同名）
            File.WriteAllText(Path.Combine(pmSrc, "sessions", "b.json"), "12");        // 新增
            File.WriteAllText(Path.Combine(pmSrc, "settings.yaml"), "x");              // 新增顶层文件
            File.WriteAllText(Path.Combine(pmSrc, "sessions", "node_modules", "skip.me"), "9999"); // 嵌套跳过规则
            Directory.CreateDirectory(Path.Combine(pmDst, "sessions"));
            File.WriteAllText(Path.Combine(pmDst, "sessions", "a.json"), "1");         // 被覆盖目标
            File.WriteAllText(Path.Combine(pmDst, "sessions", "keep.json"), "kk");     // 保留
            long[] plan = Program.Test.PlanMergeT(pmSrc, pmDst, "_workspace", null);
            Check(plan[0] == 2, "plan new = 2 (b.json + settings.yaml) got " + plan[0]);
            Check(plan[1] == 1, "plan overwrite = 1 (a.json) got " + plan[1]);
            Check(plan[2] == 1, "plan keep = 1 (keep.json) got " + plan[2]);
            Check(plan[3] == 8, "plan bytes = 8 (nested node_modules skipped) got " + plan[3]);
            // 顶层 node_modules：恢复侧 RestoreFromSource 逐个顶层目录 CopyTree，该层名字规则不生效 → 必须计入（预测忠实于执行）
            Directory.CreateDirectory(Path.Combine(pmSrc, "node_modules"));
            File.WriteAllText(Path.Combine(pmSrc, "node_modules", "top.me"), "1234567");
            long[] planTop = Program.Test.PlanMergeT(pmSrc, pmDst, "_workspace", null);
            Check(planTop[0] == 3, "plan counts top-level node_modules (restore fidelity) got " + planTop[0]);
            Check(planTop[3] == 15, "plan bytes includes top-level node_modules got " + planTop[3]);
            // 旧格式工作区：恢复侧 CopyTree(wsSrc,target) 单次调用 → 顶层跳过规则生效
            long[] planLegacy = Program.Test.PlanMergeLegacyT(pmSrc, pmDst);
            Check(planLegacy[0] == 2, "planLegacy skips top-level node_modules got " + planLegacy[0]);
            Check(planLegacy[3] == 8, "planLegacy bytes = 8 got " + planLegacy[3]);
            long[] del = Program.Test.PlanDeleteT(pmDst);
            Check(del[0] == 2 && del[1] == 2, "planDelete files=2 dirs=2 got " + del[0] + "/" + del[1]);
            long[] delSrc = Program.Test.PlanDeleteT(pmSrc);
            Check(delSrc[0] == 5, "planDelete counts node_modules files (wipe deletes all) got " + delSrc[0]);
        }
        finally { try { Directory.Delete(pmSrc, true); } catch { } try { Directory.Delete(pmDst, true); } catch { } }
        Check(Program.Test.KindName("dsh-data-20260914-101010") == "Manual", "kind manual");
        Check(Program.Test.KindName("dsh-data-20260914-101010-auto") == "Auto", "kind auto");
        Check(Program.Test.KindName("dsh-data-20260914-101010-pre-update") == "PreUpdate", "kind pre-update");
        Check(Program.Test.KindName("dsh-data-20260914-101010-pre-restore") == "PreRestore", "kind pre-restore");
        Check(Program.Test.KindName("dsh-data-20260914-101010-pre-wipe") == "PreWipe", "kind pre-wipe");
        Check(Program.Test.KindName("dsh-data-20260914-101010-pre-import") == "PreImport", "kind pre-import");

        // ---- v2.6 export / delete 校验 ----
        Console.WriteLine("[V26] NIValidateExport / NIValidateBackupDelete");
        string vr = Path.Combine(Path.GetTempPath(), "dsh_ut_vr_" + Guid.NewGuid().ToString("N"));
        string vbk = Path.Combine(vr, "dsh-data-20260914-120000");
        string vout = Path.Combine(Path.GetTempPath(), "dsh_ut_vo_" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(vbk);
            Directory.CreateDirectory(vout);
            Check(Program.Test.ValExport(vbk, vout, vr) == null, "export valid -> null");
            Check(Program.Test.ValExport("", vout, vr) == "no-path", "export no-path");
            Check(Program.Test.ValExport(vbk, "", vr) == "no-to", "export no-to");
            Check(Program.Test.ValExport(vout, vout, vr) == "outside", "export outside root");
            Check(Program.Test.ValExport(vbk, vbk, vr) == "nested", "export into itself -> nested");
            Check(Program.Test.ValExport(Path.Combine(vr, "nope"), vout, vr) == "not-found", "export not-found");
            Check(Program.Test.ValBkDel(vbk, vr) == null, "bkdel valid -> null");
            Check(Program.Test.ValBkDel("", vr) == "no-path", "bkdel no-path");
            Check(Program.Test.ValBkDel(vout, vr) == "outside", "bkdel outside");
            Check(Program.Test.ValBkDel(Path.Combine(vr, "random-dir"), vr) == "not-backup", "bkdel not-backup");
            Check(Program.Test.ValBkDel(Path.Combine(vr, "dsh-data-20200101-000000"), vr) == "not-found", "bkdel not-found");
        }
        finally { try { Directory.Delete(vr, true); } catch { } try { Directory.Delete(vout, true); } catch { } }

        // ---- v2.7 回滚候选 / 通道备份查询 ----
        Console.WriteLine("[V27] LatestBackupWithSuffix / CountValidBackups");
        string ur = Path.Combine(Path.GetTempPath(), "dsh_ut_ur_" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(Path.Combine(ur, "backup"));
            string b1 = Path.Combine(ur, "backup", "dsh-data-20260901-100000-pre-update");
            string b2 = Path.Combine(ur, "backup", "dsh-data-20260902-100000");
            string b3 = Path.Combine(ur, "backup", "dsh-data-20260903-100000-pre-update");
            string b4 = Path.Combine(ur, "backup", "dsh-data-20260904-100000-auto");
            Directory.CreateDirectory(b1); Directory.CreateDirectory(b2); Directory.CreateDirectory(b3); Directory.CreateDirectory(b4);
            File.WriteAllText(Path.Combine(b1, "settings.yaml"), "x");
            File.WriteAllText(Path.Combine(b2, "settings.yaml"), "x");
            File.WriteAllText(Path.Combine(b4, "settings.yaml"), "x");   // b3 无标记=无效
            Program.Test.SetStateDir(ur);
            Check(Program.Test.CountBk() == 3, "count valid = 3 got " + Program.Test.CountBk());
            string latestPre = Program.Test.LatestBk("-pre-update");
            Check(latestPre != null && latestPre.EndsWith("dsh-data-20260901-100000-pre-update"), "latest pre-update skips invalid b3, got " + latestPre);
            Check(Program.Test.LatestBk("-pre-restore") == null, "latest pre-restore = null");
        }
        finally { try { Directory.Delete(ur, true); } catch { } }

        // ---- v2.8 config-set 白名单校验 ----
        Console.WriteLine("[V28] NIValidateConfigSet");
        Check(Program.Test.ValCfg("lang", "zh") == null, "lang zh ok");
        Check(Program.Test.ValCfg("lang", "fr") == "bad-value", "lang fr rejected");
        Check(Program.Test.ValCfg("host", "localhost") == null, "host localhost ok");
        Check(Program.Test.ValCfg("host", "0.0.0.0") == "bad-value", "host 0.0.0.0 rejected");
        Check(Program.Test.ValCfg("keep_backups", "10") == null, "keep_backups 10 ok");
        Check(Program.Test.ValCfg("keep_backups", "2") == "bad-value", "keep_backups 2 rejected (<3)");
        Check(Program.Test.ValCfg("keep_backups", "abc") == "bad-value", "keep_backups abc rejected");
        Check(Program.Test.ValCfg("check_update", "off") == null, "check_update off ok");
        Check(Program.Test.ValCfg("update_channel", "rc") == null, "channel rc ok");
        Check(Program.Test.ValCfg("update_channel", "beta") == "bad-value", "channel beta rejected");
        Check(Program.Test.ValCfg("nope", "x") == "unknown-key", "unknown key rejected");
        Check(Program.Test.ValCfg("", "x") == "no-key", "empty key rejected");

        // ---- v2.7 状态栏运行时长格式化 ----
        Console.WriteLine("[V27] FormatUptime");
        Check(Program.Test.UptimeT(0) == "0 秒", "0s got " + Program.Test.UptimeT(0));
        Check(Program.Test.UptimeT(59) == "59 秒", "59s got " + Program.Test.UptimeT(59));
        Check(Program.Test.UptimeT(60) == "1 分", "60s got " + Program.Test.UptimeT(60));
        Check(Program.Test.UptimeT(3599) == "59 分", "3599s got " + Program.Test.UptimeT(3599));
        Check(Program.Test.UptimeT(3600) == "1 小时 0 分", "3600s got " + Program.Test.UptimeT(3600));
        Check(Program.Test.UptimeT(86399) == "23 小时 59 分", "86399s got " + Program.Test.UptimeT(86399));
        Check(Program.Test.UptimeT(86400) == "1 天 0 小时", "86400s got " + Program.Test.UptimeT(86400));
        Check(Program.Test.UptimeT(200000) == "2 天 7 小时", "200000s got " + Program.Test.UptimeT(200000));
        Check(Program.Test.UptimeT(-5) == "0 秒", "negative clamped got " + Program.Test.UptimeT(-5));

        // ---- v2.7 close_action / auto_start 配置键（GUI 关闭行为 + CLI 倒计时开关）----
        Console.WriteLine("[V27] close_action / auto_start 配置键");
        Check(Program.Test.ValCfg("close_action", "ask") == null, "close_action ask ok");
        Check(Program.Test.ValCfg("close_action", "tray") == null, "close_action tray ok");
        Check(Program.Test.ValCfg("close_action", "exit") == null, "close_action exit ok");
        Check(Program.Test.ValCfg("close_action", "") == null, "close_action empty（清除记忆）ok");
        Check(Program.Test.ValCfg("close_action", "minimize") == "bad-value", "close_action minimize rejected");
        Check(Program.Test.ValCfg("CLOSE_ACTION", "tray") == null, "close_action 键名大小写不敏感");
        Check(Program.Test.ValCfg("auto_start", "on") == null, "auto_start on ok");
        Check(Program.Test.ValCfg("auto_start", "off") == null, "auto_start off ok");
        Check(Program.Test.ValCfg("auto_start", "") == "bad-value", "auto_start empty rejected");
        Check(Program.Test.ValCfg("auto_start", "yes") == "bad-value", "auto_start yes rejected");

        // ---- v2.7 profile 诊断与修复（profilecheck / bootdiag / profilepatch）----
        Console.WriteLine("[V27] profilecheck / bootdiag / profilepatch");
        // 布局自适应（2026-10 迁移）：v2 树可能在仓库根，也可能在 v2\tests →
        // 逐个候选探测，避免"相对 CWD 的固定路径"在搬家后静默读到空文件（曾让 24 项 CI 用例红）。
        string fixDir = null;
        foreach (string cand in new string[] {
            Path.Combine("tests", "fixtures"),
            Path.Combine("v2", "tests", "fixtures"),
            Path.Combine("..", "tests", "fixtures"),
            Path.Combine("..", "v2", "tests", "fixtures") })
        {
            if (File.Exists(Path.Combine(cand, "profile_broken.yaml"))) { fixDir = cand; break; }
        }
        if (fixDir == null) { fixDir = Path.Combine("tests", "fixtures"); }
        string fBroken = Path.Combine(fixDir, "profile_broken.yaml");
        string fFixed = Path.Combine(fixDir, "profile_fixed.yaml");
        Check(File.Exists(fBroken) && File.Exists(fFixed), "fixtures present (" + fixDir + "/*.yaml)");
        string tBroken = File.Exists(fBroken) ? File.ReadAllText(fBroken, new UTF8Encoding(false)) : "";
        string tFixed = File.Exists(fFixed) ? File.ReadAllText(fFixed, new UTF8Encoding(false)) : "";

        // 1) fixed → 0 警告；broken → 1 警告且定位到条目
        string[] wFix = Program.Test.ProfChkT(tFixed);
        string[] wBrk = Program.Test.ProfChkT(tBroken);
        Check(wFix.Length == 0, "profilecheck(fixed) = 0 warnings, got " + wFix.Length);
        Check(wBrk.Length == 2, "profilecheck(broken) = 2 warnings (maxDepth + mcp command), got " + wBrk.Length + " [" + string.Join(",", wBrk) + "]");
        Check(wBrk.Length >= 1 && wBrk[0].EndsWith("|subagent-acp-kimi|maxDepth"), "broken warning names entry+key, got " + (wBrk.Length >= 1 ? wBrk[0] : ""));
        Check(wBrk.Length >= 2 && wBrk[1].EndsWith("|mcp-kimicu|command"), "broken fixture also flags mcp command (report-only), got " + (wBrk.Length >= 2 ? wBrk[1] : ""));
        Check(wFix.Length == 0, "mcp entry with existing command: no warning");

        // 2) 块边界：块内更深的 `- id:`（嵌套列表）不得被当成新条目
        string nested = "- insert:\n    - id: outer\n      name: '@deepseek-ai/dsh-tool-subagent'\n      config:\n        list:\n          - id: inner\n            x: 1\n        maxDepth: 'provider-managed'\n";
        Check(Program.Test.ProfChkT(nested).Length == 0, "nested '- id:' is not a separate entry");

        // 3) mcp-client：failOnStartupError=true 且 command 指向不存在的文件 → 只报不修
        string mcpText = "- insert:\n    - id: m1\n      name: '@deepseek-ai/dsh-mcp-client'\n      config:\n        command: 'C:\\nope\\nope.exe'\n        failOnStartupError: true\n";
        string[] wMcp = Program.Test.ProfChkT(mcpText);
        Check(wMcp.Length == 1 && wMcp[0].EndsWith("|m1|command"), "mcp missing command reported, got " + (wMcp.Length > 0 ? wMcp[0] : "(none)"));

        // 4) 标量清洗：引号 / 引号内 # / 行尾注释
        Check(Program.Test.CleanScalarT("'provider-managed' # note") == "provider-managed", "scalar: quotes + trailing comment");
        Check(Program.Test.CleanScalarT("\"a#b\"") == "a#b", "scalar: '#' inside quotes kept");
        Check(Program.Test.CleanScalarT("'@deepseek-ai/dsh-tool-subagent'") == "@deepseek-ai/dsh-tool-subagent", "scalar: package name unquoted");

        // 5) file:/// URL → 本地路径 + 条目片段
        string[] fu = Program.Test.FileUrlT("file:///C:/Users/x/.dsh/profiles/web/#tool-subagent-kimi");
        Check(fu[0] == "C:\\Users\\x\\.dsh\\profiles\\web\\", "FileUrlToPath path, got " + fu[0]);
        Check(fu[1] == "tool-subagent-kimi", "FileUrlToPath fragment, got " + fu[1]);

        // 6) bootdiag：真实堆栈（外层 include 包裹 → 必须取最内层病灶）
        string stack = "Error: dsh: plugin tree failed to load: failed to apply loader entry include (cordis:include): " +
                       "failed to apply loader entry tool-subagent-kimi (@deepseek-ai/dsh-tool-subagent): " +
                       "tool-subagent: provider \"kimi\" cannot enforce maxDepth (no depthLimit capability)\n" +
                       "    - set maxDepth: 'provider-managed' to leave the recursion budget to the provider\n" +
                       "    at file:///C:/Users/x/.dsh/profiles/web/#tool-subagent-kimi\n";
        string[] bd = Program.Test.BootDiagT(stack);
        Check(bd[0] == "OK" && bd[1] == "maxDepth-missing", "bootdiag kind, got " + bd[0] + "/" + bd[1]);
        Check(bd[2] == "@deepseek-ai/dsh-tool-subagent", "bootdiag plugin = innermost package, got " + bd[2]);
        Check(bd[3] == "tool-subagent-kimi", "bootdiag entry, got " + bd[3]);
        Check(bd[6] == "set maxDepth: 'provider-managed'", "bootdiag hint, got " + bd[6]);
        string[] bd2 = Program.Test.BootDiagT("Error: listen EADDRINUSE: address already in use 127.0.0.1:3080\n    at x\n");
        Check(bd2[0] == "FAIL" && bd2[1] == "unknown" && bd2[7].StartsWith("Error: listen EADDRINUSE"), "bootdiag unknown + first error line, got " + bd2[1]);
        string[] bd3 = Program.Test.BootDiagT("");
        Check(bd3[0] == "FAIL" && bd3[1] == "unknown", "bootdiag empty input: no false positive");

        // 7) patch 计划：幂等 / 缩进 / 仅新增一行 / 拒绝未知条目
        string[] pNoop = Program.Test.PatchT(tFixed, "subagent-acp-kimi", "maxDepth", "provider-managed");
        Check(pNoop[0] == "NOOP", "patch idempotent on fixed fixture, got " + pNoop[0]);
        string[] pPlan = Program.Test.PatchT(tBroken, "subagent-acp-kimi", "maxDepth", "provider-managed");
        Check(pPlan[0] == "PLAN", "patch plan on broken fixture, got " + pPlan[0]);
        Check(pPlan[2] == "        ", "patch indent = 8 spaces (sibling level), got [" + pPlan[2] + "]");
        string[] nt = pPlan[3].Split('\n');
        string[] ot = tBroken.Split('\n');
        Check(nt.Length == ot.Length + 1, "patch: exactly one line added (" + ot.Length + " -> " + nt.Length + ")");
        int insLine = 0; int.TryParse(pPlan[1], out insLine);
        string rejoined = "";
        for (int i = 0; i < nt.Length; i++) { if (i == insLine - 1) continue; rejoined += nt[i]; if (i < nt.Length - 1) rejoined += "\n"; }
        Check(rejoined == tBroken, "patch: all other lines byte-identical");
        string[] pMiss = Program.Test.PatchT(tBroken, "no-such-entry", "maxDepth", "provider-managed");
        Check(pMiss[0] == "FAIL:entry-not-found", "patch: unknown id rejected, got " + pMiss[0]);
        string noCfg = "- insert:\n    - id: x1\n      name: '@deepseek-ai/dsh-tool-subagent'\n";
        Check(Program.Test.PatchT(noCfg, "x1", "maxDepth", "provider-managed")[0] == "FAIL:no-config-block", "patch: entry without config: block refused");

        // 9) v2.7.2 第二条处方：手动隔离该插件（末尾追加 - id / disabled: true；只增不改）
        string[] dPlan = Program.Test.PatchDisableT(tBroken, "subagent-acp-kimi");
        Check(dPlan[0] == "PLAN", "disable: plan ok, got " + dPlan[0]);
        Check(dPlan[2].StartsWith(tBroken), "disable: append-only (existing text untouched)");
        Check(dPlan[2].EndsWith("- id: subagent-acp-kimi\n  disabled: true\n") || dPlan[2].EndsWith("- id: subagent-acp-kimi\r\n  disabled: true\r\n"), "disable: appended the expected patch item");
        Check(Program.Test.PatchHasDisabledT(dPlan[2], "subagent-acp-kimi"), "disable: detectable after append");
        Check(Program.Test.PatchDisableT(dPlan[2], "subagent-acp-kimi")[0] == "NOOP", "disable: idempotent NOOP");
        Check(Program.Test.PatchDisableT(tBroken, "no-such-id")[0] == "FAIL:entry-not-found", "disable: unknown id refused");
        Check(Program.Test.PatchDisableT(tBroken, "x\n  disabled: false")[0] == "FAIL:bad-id", "disable: YAML injection via id refused");
        Check(Program.Test.SafePatchIdT("tool-subagent-kimi") && !Program.Test.SafePatchIdT("a b") && !Program.Test.SafePatchIdT("a:b"), "disable: id charset guard");
        // ---- v2.8 平台接缝契约（接口 + Windows 实现必须与旧静态方法逐项一致）----
        Console.WriteLine("[V28] platform seams contract");
        Check(Program.Test.SeamActivePaths() == "WindowsPathService", "Windows 上应选中 WindowsPathService，实际=" + Program.Test.SeamActivePaths());
        Check(Program.Test.SeamNormalize(@"C:\x\y") == Program.Test.PathP(@"C:\x\y"), "seam Normalize == 旧 P");
        Check(Program.Test.SeamTrim(@"D:\") == Program.Test.PathTrim(@"D:\"), "seam TrimTrailingSep == 旧 TrimP（盘根语义保持）");
        Check(Program.Test.SeamDataRoot() == Program.Test.DataRootT(), "seam DataRoot == 旧 DataRoot");
        Check(Program.Test.SeamBackupsRoot() == Program.Test.BackupsRootT(), "seam BackupsRoot == 旧 BackupsRoot");
        string seamCap = Program.Test.SeamCapture("cmd.exe", "/c echo seam-probe");
        Check(seamCap != null && seamCap.Trim() == "seam-probe", "seam Shell.Capture 可用，实际=[" + (seamCap == null ? "" : seamCap.Trim()) + "]");
        Check(!Program.Test.SeamPortOpen(1, 300), "seam Probe.PortOpen(1) 为 false");
        string seamDir = Path.Combine(Path.GetTempPath(), "dsh_ut_seam_" + Guid.NewGuid().ToString("N"));
        string seamErr = Program.Test.SeamShortcut(seamDir, @"C:\nope\missing.exe", "x", null);
        Check(seamErr != null && !File.Exists(Path.Combine(seamDir, "x.lnk")), "seam Shortcut 拒绝不存在的目标");
        // ---- v2.8 阶段 3：Linux 实现契约（在 Windows 上用环境变量驱动，验证其路径/校验逻辑）----
        Console.WriteLine("[V28] linux platform implementation contract");
        string oldDshHome = Environment.GetEnvironmentVariable("DSH_HOME");
        string oldXdgDesk = Environment.GetEnvironmentVariable("XDG_DESKTOP_DIR");
        try
        {
            Environment.SetEnvironmentVariable("DSH_HOME", @"C:\tmp\dsh-home-probe");
            Check(Program.Test.LinuxDataRootT() == @"C:\tmp\dsh-home-probe", "Linux DataRoot 优先取 DSH_HOME，实际=" + Program.Test.LinuxDataRootT());
            Environment.SetEnvironmentVariable("DSH_HOME", null);
            string ldr = Program.Test.LinuxDataRootT();
            Check(ldr != null && ldr.EndsWith(".dsh"), "Linux DataRoot 回退到 <home>/.dsh，实际=" + ldr);
            Environment.SetEnvironmentVariable("XDG_DESKTOP_DIR", @"C:\tmp\xdg-desktop");
            Check(Program.Test.LinuxDesktopDirT() == @"C:\tmp\xdg-desktop", "Linux DesktopDir 优先取 XDG_DESKTOP_DIR");
            Environment.SetEnvironmentVariable("XDG_DESKTOP_DIR", null);
            Check(Program.Test.LinuxWorkspaceRootT() == null, "Linux WorkspaceRoot 故意返回 null（不猜）");
            Check(Program.Test.LinuxNormalizeT(@"C:\x\y") == Program.Test.PathP(@"C:\x\y"), "Linux seam Normalize 委托给共用规范化");
            string lerr = Program.Test.LinuxShortcutCreateT(Path.GetTempPath(), @"C:\nope\missing", "x", null);
            Check(lerr != null, "Linux 启动器写入器拒绝不存在的目标（不落文件）");
        }
        finally
        {
            Environment.SetEnvironmentVariable("DSH_HOME", oldDshHome);
            Environment.SetEnvironmentVariable("XDG_DESKTOP_DIR", oldXdgDesk);
        }
        try { Directory.Delete(seamDir, true); } catch { }

        // 8) 完整流程：备份→写入→复扫；验证失败回滚；BOM 保持
        string ppTd = Path.Combine(Path.GetTempPath(), "dsh_ut_pp_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(ppTd);
        Program.Test.SetStateDir(ppTd);
        try
        {
            string ppF1 = Path.Combine(ppTd, "broken.yaml");
            File.WriteAllText(ppF1, tBroken, new UTF8Encoding(false));
            byte[] orig = File.ReadAllBytes(ppF1);
            string bk;
            string rRoll = Program.Test.PatchApplyT(ppF1, "subagent-acp-kimi", true, out bk);
            Check(rRoll.StartsWith("PROFILEPATCH_ROLLBACK"), "patch: rollback on verify failure, got " + rRoll);
            Check(BytesEq(File.ReadAllBytes(ppF1), orig), "patch: restored byte-identical after rollback");
            Check(!string.IsNullOrEmpty(bk) && File.Exists(bk), "patch: backup taken before write");
            string rOk = Program.Test.PatchApplyT(ppF1, "subagent-acp-kimi", false, out bk);
            Check(rOk.StartsWith("PROFILEPATCH_OK"), "patch: apply ok, got " + rOk);
            string[] afterW = Program.Test.ProfChkT(File.ReadAllText(ppF1, new UTF8Encoding(false)));
            bool acpStill = false;
            foreach (string w in afterW) if (w.EndsWith("|subagent-acp-kimi|maxDepth")) acpStill = true;
            Check(!acpStill, "patch: no maxDepth warning for the patched entry after apply (remaining warnings: " + afterW.Length + ")");
            Check(Program.Test.PatchApplyT(ppF1, "subagent-acp-kimi", false, out bk) == "PROFILEPATCH_NOOP", "patch: second apply is NOOP");

            // v2.7.2：隔离处方的写入 + 回滚（第二条处方，同样手动/可回滚）
            string ppDj = Path.Combine(ppTd, "disable.yaml");
            File.WriteAllText(ppDj, tBroken, new UTF8Encoding(false));
            byte[] orig2 = File.ReadAllBytes(ppDj);
            string bk2;
            string dr = Program.Test.PatchDisableApplyT(ppDj, "subagent-acp-kimi", true, out bk2);
            Check(dr.StartsWith("PROFILEPATCH_ROLLBACK"), "disable: rollback on verify failure, got " + dr);
            Check(BytesEq(File.ReadAllBytes(ppDj), orig2), "disable: restored byte-identical after rollback");
            string dOk = Program.Test.PatchDisableApplyT(ppDj, "subagent-acp-kimi", false, out bk2);
            Check(dOk.StartsWith("PROFILEPATCH_OK"), "disable: apply ok, got " + dOk);
            Check(Program.Test.PatchHasDisabledT(File.ReadAllText(ppDj, new UTF8Encoding(false)), "subagent-acp-kimi"), "disable: present on disk after apply");
            Check(Program.Test.PatchDisableApplyT(ppDj, "subagent-acp-kimi", false, out bk2) == "PROFILEPATCH_NOOP", "disable: second apply NOOP");
            string ppF2 = Path.Combine(ppTd, "bom.yaml");
            byte[] body = new UTF8Encoding(false).GetBytes(tBroken);
            byte[] withBom = new byte[body.Length + 3];
            withBom[0] = 0xEF; withBom[1] = 0xBB; withBom[2] = 0xBF;
            Array.Copy(body, 0, withBom, 3, body.Length);
            File.WriteAllBytes(ppF2, withBom);
            string rBom = Program.Test.PatchApplyT(ppF2, "subagent-acp-kimi", false, out bk);
            byte[] afterBom = File.ReadAllBytes(ppF2);
            Check(rBom.StartsWith("PROFILEPATCH_OK") && afterBom.Length >= 3 && afterBom[0] == 0xEF && afterBom[1] == 0xBB && afterBom[2] == 0xBF, "patch: BOM preserved");
        }
        finally { try { Directory.Delete(ppTd, true); } catch { } }

        Console.WriteLine("");
        Console.WriteLine("== " + (total - fails) + "/" + total + " passed, " + fails + " failed ==");
        Environment.Exit(fails == 0 ? 0 : 1);
    }
}

// 仅用于 3080 自适应的辅助（与生产逻辑无关的独立端口探测）
public static class IO
{
    public static bool Port3080Open()
    {
        try
        {
            var c = new System.Net.Sockets.TcpClient();
            var t = c.ConnectAsync("127.0.0.1", 3080);
            bool ok = t.Wait(600);
            if (ok && c.Connected) { c.Close(); return true; }
            c.Close(); return false;
        }
        catch { return false; }
    }
}