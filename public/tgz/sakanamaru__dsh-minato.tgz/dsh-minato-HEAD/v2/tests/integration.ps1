﻿# DeepSeek Harness Toolkit - 集成测试（端到端打桩矩阵）
# 用法:  pwsh -NoProfile -File v2\tests\integration.ps1 [-RepoRoot <仓库根或 v2 根>]
#        默认取脚本上级目录，并自动识别两种布局（v2 树在仓库根 / 在 v2\ 子目录）
# 退出码: 0=全过（SKIP 不计失败）, 1=有失败, 2=环境/锚点错误
# 说明: ① 只碰打桩数据目录 ~/.dsh_test，绝不接触真实 ~/.dsh；
#       ② 变体 A=端口打桩（菜单/卸载流程全可测）；变体 C=真实端口（仅测"运行中"路径，3080 未开时相关用例标 SKIP）；
#       ③ 锚点断言保证本脚本与生产源码同步，源码改动导致锚点漂移时立即报错。
#       ④ 建议用 pwsh 7 运行；文件为 UTF-8 with BOM，PowerShell 5.1 亦可。
param([string]$RepoRoot = "")
$ErrorActionPreference = 'Stop'
if (-not $RepoRoot) { $RepoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path }
# 布局自适应（2026-10 迁移）：v2 树既可能在仓库根，也可能在 v2\ 子目录 → 两种都能跑
if (-not (Test-Path -LiteralPath (Join-Path $RepoRoot 'dsh_v2.cs'))) {
    $alt = Join-Path $RepoRoot 'v2'
    if (Test-Path -LiteralPath (Join-Path $alt 'dsh_v2.cs')) { $RepoRoot = $alt }
}
$src = Join-Path $RepoRoot 'dsh_v2.cs'
if (-not (Test-Path -LiteralPath $src)) { Write-Error "找不到 $src"; exit 2 }
$csc = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if (-not (Test-Path -LiteralPath $csc)) { Write-Error "找不到 csc：$csc（需 Windows + .NET Framework 4.x）"; exit 2 }

$results = New-Object System.Collections.Generic.List[string]
function TC($name, $ok, $extra = '') {
    $results.Add(("{0,-28} {1} {2}" -f $name, $(if ($ok) { 'PASS' } else { 'FAIL' }), $extra))
}
function NewDir($p) { if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Recurse -Force }; New-Item -ItemType Directory -Path $p -Force | Out-Null }

$repoRoot = Split-Path -Parent $src
function Get-SrcFiles { return @($src) + (Get-ChildItem (Join-Path $repoRoot 'src') -Recurse -Filter *.cs -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notmatch '\\obj\\|\\bin\\' } | ForEach-Object FullName) }

function Build-Variant($variant, $outExe) {
    # v2.8：源码已拆成多层，锚点可能落在任意一个文件里 —— 逐文件查找并替换，再整体编译
    $files = Get-SrcFiles
    $map = @{}
    foreach ($f in $files) { $map[$f] = [IO.File]::ReadAllText($f, [Text.UTF8Encoding]::new($false)) }
    $pats = @(
        @{ o = 'const string DATA_DIR     = ".dsh";';                                                   n = 'const string DATA_DIR     = ".dsh_test";' },
        @{ o = '"DeepSeek-Harness-Toolkit-single"';                                                        n = '"DSH-Toolkit-TEST-single"' },
        @{ o = '"DSH-Toolkit-V2.0.0-single"';                                                           n = '"DSH-Toolkit-TEST-legacy"' },
        @{ o = 'string choice = countdown ? CountdownInput("  > ", def) : ReadChoice("  > ");'; n = 'string choice = ReadLineTrim(); // TEST line-driven' },
        @{ o = 'int code = Platform.Shell.NpmInstallGlobal(pkg, registries[i]);'; n = 'int code = 0; // TEST install no-op' },
        @{ o = 'int code = Platform.Shell.NpmUninstallGlobal();';            n = 'int code = 0; // TEST npm no-op' }
    )
    if ($variant -eq 'A') {
        $pats += @{ o = 'if (ProbeService() == ServiceState.Ready)'; n = 'if (false && ProbeService() == ServiceState.Ready)' }
        $pats += @{ o = 'if (IsPortOpen(WEB_PORT, 600))'; n = 'if (false && IsPortOpen(WEB_PORT, 600))' }
        $pats += @{ o = 'return JudgeState3(IsPortOpen(WEB_PORT, 800), HttpReady(WebUrl(), 800), ListenerIsDsh);'; n = 'return JudgeState(false, false); // TEST stub' }
    }
    foreach ($p in $pats) {
        $done = $false
        foreach ($f in $files) { if ($map[$f].Contains($p.o)) { $map[$f] = $map[$f].Replace($p.o, $p.n); $done = $true; break } }
        if (-not $done) { Write-Error ("锚点漂移（请同步 integration.ps1）: " + $p.o.Substring(0, 50)); exit 2 }
    }
    $vd = Join-Path $env:TEMP ("t_dsh_" + $variant + "_" + [guid]::NewGuid().ToString('N'))
    if (Test-Path -LiteralPath $vd) { Remove-Item -LiteralPath $vd -Recurse -Force }
    New-Item -ItemType Directory -Path $vd -Force | Out-Null
    $srcOut = New-Object System.Collections.Generic.List[string]
    foreach ($f in $files) {
        $rel = $f.Substring($repoRoot.Length).TrimStart('\')
        $dest = Join-Path $vd $rel
        $dd = Split-Path -Parent $dest
        if (-not (Test-Path -LiteralPath $dd)) { New-Item -ItemType Directory -Path $dd -Force | Out-Null }
        [IO.File]::WriteAllText($dest, $map[$f], [Text.UTF8Encoding]::new($false))
        $srcOut.Add($dest)
    }
    & $csc /nologo /optimize+ /target:exe ("/out:" + $outExe) $srcOut /warn:4 | Out-Null
    if ($LASTEXITCODE -ne 0) { Write-Error ("变体" + $variant + " 编译失败"); exit 2 }
    Remove-Item -LiteralPath $vd -Recurse -Force
}
$T = Join-Path $env:TEMP ("tkint_" + [guid]::NewGuid().ToString('N'))
NewDir $T
$tA = Join-Path $T 'tA.exe'; $tC = Join-Path $T 'tC.exe'
Build-Variant 'A' $tA
Build-Variant 'C' $tC
# 交互用例统一关闭启动更新检查（避免每次启动连 GitHub 的随机耗时/超时）
[IO.File]::WriteAllText((Join-Path $T 'launcher.config'), ('lang=zh' + [Environment]::NewLine + 'check_update=off' + [Environment]::NewLine))
$allowLive = ($env:DSH_TOOLKIT_INTEGRATION_ALLOW_LIVE -eq '1')   # 活体 dsh 保护：默认不碰真实 3080
# 存活探测：用原生 netstat（约束语言模式下 New-Object/Test-NetConnection 都不可靠）
$portLive = [bool](& netstat -ano 2>$null | Select-String -Pattern ':3080\s+\S+\s+LISTENING')
$date = Get-Date -Format 'yyyyMMdd'
$dt = Join-Path $env:USERPROFILE '.dsh_test'
function Seed-DT { Remove-Item -LiteralPath $dt -Recurse -Force -ErrorAction SilentlyContinue; New-Item -ItemType File -Path (Join-Path $dt 'settings.yaml') -Force | Out-Null }

Write-Output ("环境: 3080=" + $(if ($portLive -and $allowLive) { '运行中' } else { '未运行' }) + "  仓库根=" + $RepoRoot)

# 1-5 基础 / CLI
& $tA selftest *> $null;   TC '1 selftest' ($LASTEXITCODE -eq 0)
$o = (& $tA help 2>&1 | Out-String);    TC '2 help' ($o.Contains('install') -and $o.Contains('start') -and $o.Contains('uninstall') -and $o.Contains('update') -and $o.Contains('backup') -and $o.Contains('restore') -and $o.Contains('status') -and $o.Contains('stop'))
$ver = [regex]::Match([IO.File]::ReadAllText($src, [Text.UTF8Encoding]::new($false)), 'DeepSeek Harness Toolkit V\d+\.\d+\.\d+').Value
$o = (& $tA about 2>&1 | Out-String);   TC '3 about' (($o.Contains($ver)) -and ($o.Contains('sakanamaru')))
$o = (& $tA check 2>&1 | Out-String);   TC '4 check CLI' ($o.Contains('dsh'))
$sw = [Diagnostics.Stopwatch]::StartNew(); $o = ("0`n" | & $tA 2>&1 | Out-String); $sw.Stop()
TC '5 menu exit 0' ($sw.ElapsedMilliseconds -lt 2000) ($sw.ElapsedMilliseconds.ToString() + 'ms')

# 23 单实例锁：双锁任一被占（新锁 / v2.0 旧锁）→ 第二个实例拒绝（轮询 holder 就绪，避免冷启动竞态）
$hcs = Join-Path $T 'holder.cs'
[IO.File]::WriteAllText($hcs, 'using System; using System.Threading; class H { [STAThread] static void Main(string[] a) { string n = (a != null && a.Length > 0) ? a[0] : "x"; var m = new Mutex(false, n); bool g = false; try { g = m.WaitOne(0); } catch (AbandonedMutexException) { g = true; } if (g) { Console.WriteLine("OK"); Thread.Sleep(30000); } } }', [Text.Encoding]::ASCII)
$holderExe = Join-Path $T 'holder.exe'
& "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe" /nologo ("/out:"+$holderExe) $hcs 2>&1 | Out-Null
function Start-Holder([string]$lockName, [string]$outFile) {
    $hp = Start-Process -FilePath $holderExe -ArgumentList $lockName -RedirectStandardOutput $outFile -PassThru
    $deadline = (Get-Date).AddSeconds(6)
    while ((Get-Date) -lt $deadline) {
        if ((Test-Path $outFile) -and ((Get-Content $outFile -ErrorAction SilentlyContinue) -contains 'OK')) { return $hp }
        if ($hp.HasExited) { return $hp }
        Start-Sleep -Milliseconds 200
    }
    return $hp
}
$h1 = Start-Holder 'DSH-Toolkit-TEST-single' (Join-Path $T 'h1.txt')
$o23a = ("0`n" | & $tA 2>&1 | Out-String)
TC '23a second instance refused (new lock held)' ($o23a.Contains('已在运行') -or $o23a.Contains('already running'))
Stop-Process -Id $h1.Id -Force -ErrorAction SilentlyContinue
$h2 = Start-Holder 'DSH-Toolkit-TEST-legacy' (Join-Path $T 'h2.txt')
$o23b = ("0`n" | & $tA 2>&1 | Out-String)
TC '23b second instance refused (legacy v2.0 lock held)' ($o23b.Contains('已在运行') -or $o23b.Contains('already running'))
Stop-Process -Id $h2.Id -Force -ErrorAction SilentlyContinue

# 6-9 配置 / 安装源
$d = Join-Path $T 'lang'; NewDir $d; Copy-Item $tA (Join-Path $d 't.exe')
$o = ("4`n2`n0`n" | & (Join-Path $d 't.exe') 2>&1 | Out-String); $c1 = [IO.File]::ReadAllText((Join-Path $d 'launcher.config'))
$o = ("4`n3`n0`n" | & (Join-Path $d 't.exe') 2>&1 | Out-String); $c2 = [IO.File]::ReadAllText((Join-Path $d 'launcher.config'))
TC '6 lang persist' ($c1.Contains('lang=zh') -and $c2.Contains('lang=en'))
$o = ("7`n2`n0`n" | & (Join-Path $d 't.exe') 2>&1 | Out-String); $h1 = [IO.File]::ReadAllText((Join-Path $d 'launcher.config'))
$o = ("7`n1`n7`n3`n`n0`n" | & (Join-Path $d 't.exe') 2>&1 | Out-String); $h2 = [IO.File]::ReadAllText((Join-Path $d 'launcher.config'))
TC '7 entry+ws clear' ($h1.Contains('host=localhost') -and $h2.Contains('host=127.0.0.1') -and -not ($h2 -match 'ws=\S'))
$o = ("1`n1`n`n0`n" | & (Join-Path $d 't.exe') 2>&1 | Out-String); TC '8 install src official' ($o.Contains('registry.npmjs'))
$o = ("1`n2`n`n0`n" | & (Join-Path $d 't.exe') 2>&1 | Out-String); TC '9 install src mirror' ($o.Contains('npmmirror'))

# 10-12 卸载守卫
$d = Join-Path $T 'stray'; NewDir $d; Copy-Item $tA (Join-Path $d 't.exe'); Seed-DT
$o = ("6`ny`ny`n$date`nyes`n0`n" | & (Join-Path $d 't.exe') 2>&1 | Out-String)
TC '10 stray uninstall refused' (($o.Contains('未检测到完整安装') -or $o.Contains('does not look like a full installation')) -and (Test-Path (Join-Path $dt 'settings.yaml')))
# 10b stray exe + 2 个配套文件（伪造"像安装目录"）+ 无 marker -> 必须拒绝（防 LooksLikeFullInstall 绕过回归）
$d = Join-Path $T 'strayCmp'; NewDir $d; Copy-Item $tA (Join-Path $d 't.exe')
[IO.File]::WriteAllText((Join-Path $d 'dsh_v2.cs'), 'x'); [IO.File]::WriteAllText((Join-Path $d 'build_exe.cmd'), '@echo off')
$o = ("6`ny`ny`n$date`nyes`n0`n" | & (Join-Path $d 't.exe') 2>&1 | Out-String)
TC '10b stray+companion refused' ($o.Contains('未检测到完整安装') -or $o.Contains('does not look like a full installation'))
$d = Join-Path $T 'full'; NewDir $d; Copy-Item $tA (Join-Path $d 't.exe')
[IO.File]::WriteAllText((Join-Path $d '.dsh_launcher_root'), 'DeepSeek Harness Toolkit' + [Environment]::NewLine)
$o = ("6`ny`ny`n$date`nyes`n0`n" | & (Join-Path $d 't.exe') 2>&1 | Out-String)
TC '11 full uninstall wiped' (($o.Contains('数据已清除') -or $o.Contains('Data wiped')) -and (-not (Test-Path (Join-Path $dt 'settings.yaml'))))
$d = Join-Path $T 'cli'; NewDir $d; Copy-Item $tA (Join-Path $d 't.exe'); Seed-DT
$o = ("y`ny`n$date`nyes`n0`n" | & (Join-Path $d 't.exe') uninstall 2>&1 | Out-String)
TC '12 cli uninstall refused' ($o.Contains('未检测到完整安装') -or $o.Contains('does not look like a full installation'))

# 13-14,19 真实端口（3080 未开则 SKIP）
if ($portLive -and $allowLive) {
    $pn0 = (Get-Process node -ErrorAction SilentlyContinue | Measure-Object).Count
    $o = ("2`n0`n" | & $tC 2>&1 | Out-String); $pn1 = (Get-Process node -ErrorAction SilentlyContinue | Measure-Object).Count
    TC '13 running->monitor' (($o.Contains('运行中') -or $o.Contains('RUNNING')) -and ($pn1 -le $pn0 + 1)) ('node:' + $pn0 + '->' + $pn1)
    $o = (& $tC check 2>&1 | Out-String); TC '14 check live' ($o.Contains('已在运行') -or $o.Contains('running'))
    $d = Join-Path $T 'fullC'; NewDir $d; Copy-Item $tC (Join-Path $d 't.exe')
    [IO.File]::WriteAllText((Join-Path $d 'launcher.config'), ('lang=zh' + [Environment]::NewLine + 'check_update=off' + [Environment]::NewLine))
    [IO.File]::WriteAllText((Join-Path $d '.dsh_launcher_root'), 'DeepSeek Harness Toolkit' + [Environment]::NewLine)
    $o = ("6`ny`ny`n$date`nyes`n0`n" | & (Join-Path $d 't.exe') 2>&1 | Out-String)
    TC '19 uninstall blocked while running' ($o.Contains('请先关闭') -or $o.Contains('Close the dsh web window first'))
} else {
    $o = (& $tC check 2>&1 | Out-String); if ($portLive) { $results.Add('14 check stopped(needs free 3080)  SKIP') } else { TC '14 check stopped' ($o.Contains('未启动') -or $o.Contains('not started')) }
    $results.Add('13 monitor(needs 3080)              SKIP')
    $results.Add('19 uninstall-block(needs 3080)      SKIP')
}

# 27/28 监控页 I 选项条件显示（变体 C 真实端口；DSH_TEST_DESKTOP 隔离，不碰真实桌面）
if ($portLive -and $allowLive) {
    # 27：快捷方式不存在 -> 显示 I 行
    $desk27 = Join-Path $T 'desk27'; NewDir $desk27
    $env:DSH_TEST_DESKTOP = $desk27
    $o27 = ("2`n0`n" | & $tC 2>&1 | Out-String)
    Remove-Item Env:DSH_TEST_DESKTOP -ErrorAction SilentlyContinue
    TC '27 monitor shows I when no shortcut' (($o27.Contains('I)')) -and ($o27.Contains('打开 WebUI') -or $o27.Contains('Open Web UI')))
    # 28：快捷方式已存在 -> 隐藏 I 行
    $desk28 = Join-Path $T 'desk28'; NewDir $desk28
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut((Join-Path $desk28 'DeepSeek Harness Toolkit.lnk'))
    $sc.TargetPath = "$env:WINDIR\System32\notepad.exe"
    $sc.Save()
    $env:DSH_TEST_DESKTOP = $desk28
    $o28 = ("2`n0`n" | & $tC 2>&1 | Out-String)
    Remove-Item Env:DSH_TEST_DESKTOP -ErrorAction SilentlyContinue
    TC '28 monitor hides I when shortcut exists' (($o28.Contains('打开 WebUI') -or $o28.Contains('Open Web UI')) -and (-not $o28.Contains('I)')))
} else {
    $results.Add('27/28 monitor-I(needs 3080)        SKIP')
}

# 15-18 备份/恢复/导入/嵌套
$d = Join-Path $T 'bk'; NewDir $d; Copy-Item $tA (Join-Path $d 't.exe'); Seed-DT
$wsdir = Join-Path $T 'ws_data'; NewDir $wsdir; [IO.File]::WriteAllText((Join-Path $wsdir 'report.txt'), 'ws placeholder')
# M-7：$T 位于 UserProfile 子树，命中工作区黑名单 → 需输入 yes 显式确认后仍可备份（顺带覆盖 M-7 二次确认路径）
$o = ("5`n1`n$wsdir`nyes`n`n0`n" | & (Join-Path $d 't.exe') 2>&1 | Out-String)
$bkdir = Join-Path $d 'backup'
$B = Get-ChildItem -LiteralPath $bkdir -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'dsh-data-*' } | Select-Object -First 1
$ok15 = $false
if ($B) { $ok15 = (Test-Path -LiteralPath (Join-Path $B.FullName '_workspace')) -and (Test-Path -LiteralPath (Join-Path $B.FullName 'settings.yaml')) }
TC '15 backup e2e' $ok15
$wr = Join-Path $T 'restore_ws'; NewDir $wr
$o = ("5`n2`n1`ny`n$wr`ny`n0`n" | & (Join-Path $d 't.exe') 2>&1 | Out-String)
# 注意：恢复前预备份与主备份可能落在同一秒（dest 同名合并），故不按"备份数+1"断言，改用文案+文件
TC '16 restore e2e (+pre-backup)' (($o.Contains('恢复前自动备份当前数据') -or $o.Contains('Auto-backing up current data before restore')) -and ($o.Contains('恢复完成') -or $o.Contains('Restore done')) -and (Test-Path (Join-Path $wr 'report.txt')) -and (Test-Path (Join-Path $dt 'settings.yaml')))
$foreign = Join-Path $T 'foreign'; NewDir $foreign
if ($B) { Copy-Item -LiteralPath $B.FullName -Destination (Join-Path $foreign $B.Name) -Recurse -Force }
$o = ("5`n3`n$foreign`ny`n0`n" | & (Join-Path $d 't.exe') 2>&1 | Out-String)
$bk2 = @(Get-ChildItem -LiteralPath $bkdir -Directory -ErrorAction SilentlyContinue).Count
TC '17 import e2e' (($o.Contains('导入前自动备份当前数据') -or $o.Contains('Auto-backing up current data before import')) -and ($o.Contains('恢复完成') -or $o.Contains('Restore done')) -and ($bk2 -ge 1))
$wsdir2 = Join-Path $T 'ws_nested'; NewDir $wsdir2; NewDir (Join-Path $wsdir2 'dsh-data-20250101-000000')
[IO.File]::WriteAllText((Join-Path $wsdir2 'dsh-data-20250101-000000\x.txt'), 'fake')
# M-7：同样位于 UserProfile 子树，需 yes 确认后才真正进入备份，验证 CopyTree 跳过嵌套 dsh-data-*
$o = ("5`n1`n$wsdir2`nyes`n`n0`n" | & (Join-Path $d 't.exe') 2>&1 | Out-String)
$dummy = @(Get-ChildItem -LiteralPath $bkdir -Recurse -Filter 'x.txt' -ErrorAction SilentlyContinue).Count
TC '18 nested backup skipped' ((($o -join ' ').Contains('跳过') -or ($o -join ' ').Contains('skipping') -or ($o -join ' ').Contains('skipped')) -and ($dummy -eq 0))

# 20 保留策略（v2.1）：只清自动类（超 keep_backups 删最旧），手动备份永久保留
$d20 = Join-Path $T 'ret'; NewDir $d20; Copy-Item $tA (Join-Path $d20 't.exe')
[IO.File]::WriteAllText((Join-Path $d20 'launcher.config'), ('lang=zh' + [Environment]::NewLine + 'keep_backups=4' + [Environment]::NewLine))
$bk20 = Join-Path $d20 'backup'; NewDir $bk20
foreach ($n in @('01', '02')) { NewDir (Join-Path $bk20 ('dsh-data-20260101-0000' + $n)) }               # 手动 2 份（无后缀）
foreach ($n in @('01', '02', '03', '04', '05')) { NewDir (Join-Path $bk20 ('dsh-data-20260101-000' + $n + '-pre-restore')) }   # 自动类 5 份
$o = ("5`n1`n`n0`n" | & (Join-Path $d20 't.exe') 2>&1 | Out-String)   # 手动备份触发保留策略
$preCnt = @(Get-ChildItem -LiteralPath $bk20 -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '*pre-restore' }).Count
$man1 = Test-Path (Join-Path $bk20 'dsh-data-20260101-000001')
$man2 = Test-Path (Join-Path $bk20 'dsh-data-20260101-000002')
$oldestGone = -not (Test-Path (Join-Path $bk20 'dsh-data-20260101-000001-pre-restore'))
$retMsg = (($o -join ' ').Contains('保留策略') -or ($o -join ' ').Contains('Retention'))
TC '20 retention auto-only' (($preCnt -eq 4) -and $man1 -and $man2 -and $oldestGone -and $retMsg)

# 21/22 运行中拒绝（v2.1 🔴2：Restore/Import 在 dsh 运行中禁止；变体 C 真实端口）
if ($portLive -and $allowLive) {
    $d21 = Join-Path $T 'fullC21'; NewDir $d21; Copy-Item $tC (Join-Path $d21 't.exe')
    [IO.File]::WriteAllText((Join-Path $d21 'launcher.config'), ('lang=zh' + [Environment]::NewLine + 'check_update=off' + [Environment]::NewLine))
    NewDir (Join-Path $d21 'backup\dsh-data-20260101-000001')
    [IO.File]::WriteAllText((Join-Path $d21 'backup\dsh-data-20260101-000001\settings.yaml'), 'x')
    $o21 = ("5`n2`n1`ny`n0`n" | & (Join-Path $d21 't.exe') 2>&1 | Out-String)
    TC '21 restore blocked while running' ($o21.Contains('请先关闭') -or $o21.Contains('Close the dsh web window first'))
    $foreign21 = Join-Path $T 'foreign21'; NewDir $foreign21
    if ($B) { Copy-Item -LiteralPath $B.FullName -Destination (Join-Path $foreign21 $B.Name) -Recurse -Force }
    $o22 = ("5`n3`n$foreign21`ny`n0`n" | & (Join-Path $d21 't.exe') 2>&1 | Out-String)
    TC '22 import blocked while running' ($o22.Contains('请先关闭') -or $o22.Contains('Close the dsh web window first'))
} else {
    $results.Add('21 restore-block(needs 3080)        SKIP')
    $results.Add('22 import-block(needs 3080)         SKIP')
}

# 25 更新运行中拒绝（UpdateDsh 守卫，变体 C 真实端口，CLI update）
if ($portLive -and $allowLive) {
    $d25 = Join-Path $T 'updC'; NewDir $d25; Copy-Item $tC (Join-Path $d25 't.exe')
    [IO.File]::WriteAllText((Join-Path $d25 'launcher.config'), ('lang=zh' + [Environment]::NewLine + 'check_update=off' + [Environment]::NewLine))
    $o25 = ("" | & (Join-Path $d25 't.exe') update 2>&1 | Out-String)
    TC '25 update blocked while running' ($o25.Contains('正在运行') -or $o25.Contains('is running'))
} else {
    $results.Add('25 update-block(needs 3080)        SKIP')
}

# 26 桌面快捷方式 CLI（DSH_TEST_DESKTOP 隔离到临时目录，不碰真实桌面）
$d26 = Join-Path $T 'short'; NewDir $d26; Copy-Item $tA (Join-Path $d26 't.exe')
$desk26 = Join-Path $T 'desktop'; NewDir $desk26
$env:DSH_TEST_DESKTOP = $desk26
$o26 = (& (Join-Path $d26 't.exe') shortcut 2>&1 | Out-String)
Remove-Item Env:DSH_TEST_DESKTOP -ErrorAction SilentlyContinue
$lnk26 = Test-Path (Join-Path $desk26 'DeepSeek Harness Toolkit.lnk')
TC '26 shortcut CLI' (($o26.Contains('SHORTCUT_OK')) -and $lnk26)

# 29-31 非交互 CLI（GUI 地基）：status / stop / backup / restore（变体 A 端口打桩 Down，不碰真实 3080）
$d29 = Join-Path $T 'nicli'; NewDir $d29; Copy-Item $tA (Join-Path $d29 't.exe')
[IO.File]::WriteAllText((Join-Path $d29 'launcher.config'), ('lang=zh' + [Environment]::NewLine + 'check_update=off' + [Environment]::NewLine))
# 29 status -> STATUS_DOWN（变体 A 打桩）
$o29 = (& (Join-Path $d29 't.exe') status 2>&1 | Out-String)
TC '29 status CLI (down)' ($o29.Contains('STATUS_DOWN'))
# 30 stop -> STOP_OK（已停止幂等；变体 A 打桩 Down，绝不触碰真实 3080/harness）
$o30 = (& (Join-Path $d29 't.exe') stop 2>&1 | Out-String)
TC '30 stop CLI (idempotent down)' ($o30.Contains('STOP_OK'))
# 31 backup/restore 非交互（.dsh_test 打桩数据）
Seed-DT
$o31a = (& (Join-Path $d29 't.exe') backup 2>&1 | Out-String)
$bk31 = @(Get-ChildItem -LiteralPath (Join-Path $d29 'backup') -Directory -ErrorAction SilentlyContinue).Count
$o31b = (& (Join-Path $d29 't.exe') restore 2>&1 | Out-String)
TC '31 backup+restore CLI' (($o31a.Contains('BACKUP_OK')) -and ($bk31 -ge 1) -and ($o31b.Contains('RESTORE_OK')) -and (Test-Path (Join-Path $dt 'settings.yaml')))

# 32 start --bg / status up（变体 C 真实端口：3080 运行时 START_OK 幂等，不真启动；未开则 SKIP）
if ($portLive -and $allowLive) {
    $d32 = Join-Path $T 'bgC'; NewDir $d32; Copy-Item $tC (Join-Path $d32 't.exe')
    [IO.File]::WriteAllText((Join-Path $d32 'launcher.config'), ('lang=zh' + [Environment]::NewLine + 'check_update=off' + [Environment]::NewLine))
    $o32a = (& (Join-Path $d32 't.exe') status 2>&1 | Out-String)
    $o32b = (& (Join-Path $d32 't.exe') start --bg 2>&1 | Out-String)
    TC '32 status up + start --bg idempotent' (($o32a.Contains('STATUS_UP')) -and ($o32b.Contains('START_OK')))

# v2.8 阶段 2 守卫：csproj 的编译清单必须与实际源码集合一致（防止"加了文件忘了加进工程"）
$csprojPath = Join-Path $RepoRoot 'DeepSeekHarnessToolkit.Core.csproj'
$csprojOk = $false; $csprojDetail = 'csproj 缺失'
if (Test-Path -LiteralPath $csprojPath) {
    $xml = [xml](Get-Content -LiteralPath $csprojPath -Raw)
    $incs = @($xml.Project.ItemGroup.Compile | Where-Object { $_.Include } | ForEach-Object { $_.Include })
    $expect = @('dsh_v2.cs', 'src\Core\**\*.cs', 'src\Platform\**\*.cs', 'src\Cli\**\*.cs')
    $csprojOk = ($incs.Count -eq $expect.Count)
    foreach ($e in $expect) { if ($incs -notcontains $e) { $csprojOk = $false } }
    $all = @('dsh_v2.cs') + (Get-ChildItem (Join-Path $RepoRoot 'src') -Recurse -Filter *.cs | Where-Object { $_.FullName -notmatch '\\obj\\|\\bin\\' } | ForEach-Object { $_.FullName.Substring($RepoRoot.Length).TrimStart('\') })
    $uncovered = @($all | Where-Object { $_ -ne 'dsh_v2.cs' -and $_ -notlike 'src\Core\*' -and $_ -notlike 'src\Platform\*' -and $_ -notlike 'src\Cli\*' })
    if ($uncovered.Count -gt 0) { $csprojOk = $false; $csprojDetail = '未覆盖: ' + ($uncovered -join ',') }
    else { $csprojDetail = 'glob 覆盖 ' + $all.Count + ' 个源文件' }
}
TC '33 csproj source set matches' $csprojOk $csprojDetail

# v2.8 守卫：只搬不改（以 v2.7.2 的原始 dsh_v2.cs 为基线，断言 0 行丢失）
$moScript = Join-Path $RepoRoot 'tests\verify_move_only.ps1'
$moRc = 2; $moDetail = 'SKIP(no baseline)'
if (Test-Path -LiteralPath $moScript) {
    $moOut = & powershell -ExecutionPolicy Bypass -File $moScript -Repo $RepoRoot 2>&1 | Out-String
    $moRc = $LASTEXITCODE
    if ($moRc -eq 0) { $moDetail = (($moOut -split "`n") | Where-Object { $_ -match '基线有效行' }) -join '' }
    elseif ($moRc -eq 1) { $moDetail = '有行丢失' }
}
TC '34 move-only guard' ($moRc -eq 0 -or $moRc -eq 2) $moDetail

# v2.8 守卫：核心平台中立（零 Windows-only 编译期 API；Windows 实现只能在 src/Platform/Windows/**）
$cpScript = Join-Path $RepoRoot 'tests\verify_core_portable.ps1'
$cpRc = 1; $cpDetail = 'script missing'
if (Test-Path -LiteralPath $cpScript) {
    $cpOut = & powershell -ExecutionPolicy Bypass -File $cpScript -Repo $RepoRoot 2>&1 | Out-String
    $cpRc = $LASTEXITCODE
    $cpDetail = (($cpOut -split "`n") | Where-Object { $_ -match '扫描核心源文件' }) -join ''
    if ($cpRc -ne 0) { $cpDetail = (($cpOut -split "`n") | Where-Object { $_ -match 'Windows-only' } | Select-Object -First 1) }
}
TC '35 core stays portable' ($cpRc -eq 0) $cpDetail
} else {
    $results.Add('32 status/start-bg(needs 3080)    SKIP')
}

Write-Output ""; Write-Output "=== integration results ==="
$results | ForEach-Object { Write-Output $_ }
$fail = ($results | Where-Object { $_ -match ' FAIL ' }).Count
$pass = ($results | Where-Object { $_ -match ' PASS ' }).Count
$skip = @($results | Where-Object { $_ -match ' SKIP ' }).Count
Write-Output ("PASS " + $pass + "  FAIL " + $fail + "  SKIP " + $skip)
Remove-Item -LiteralPath $T -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $dt -Recurse -Force -ErrorAction SilentlyContinue
exit $(if ($fail -eq 0) { 0 } else { 1 })