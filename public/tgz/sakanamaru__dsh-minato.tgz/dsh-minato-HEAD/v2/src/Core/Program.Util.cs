using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

partial class Program
{

    static string T(string zh, string en) { return IsZh ? zh : en; }

    // ---------------- 彩色输出 ----------------


    static void Info(string s)    { C(ConsoleColor.Cyan, "  " + s + Environment.NewLine); }

    static void Success(string s) { C(ConsoleColor.Green, "  ✓ " + s + Environment.NewLine); }

    static void Warn(string s)    { C(ConsoleColor.Yellow, "  [!] " + s + Environment.NewLine); }

    static void Error(string s)   { C(ConsoleColor.Red, "  [x] " + s + Environment.NewLine); LogErr(s); }

    // ---------------- 错误日志 ----------------


    /// <summary>加 \\?\ 前缀绕过 260 字符限制（配合 Main 里的长路径开关，兼容无注册表策略的机器）。</summary>
    static string P(string p)   // 统一转 \\?\ 前缀（UNC 走 \\?\UNC\，否则 System.IO 对长路径会失败）
    {
        if (string.IsNullOrEmpty(p)) return p;
        if (p.StartsWith(@"\\?\")) return p;
        // 相对路径/驱动器相对路径（.\x、backup\x、C:x）必须先转绝对：\\?\.\x 不是合法 Win32 路径，
        // System.IO 会抛异常，而调用方（如 PlanMergeCore）把异常静默吞掉 →
        // `restore --dry-run --path .\backup\...` 会谎报"0 个文件"（v2.7.3 修复）。
        if (!IsFullyQualified(p)) { try { p = Path.GetFullPath(p); } catch { } }
        if (p.StartsWith(@"\\")) return @"\\?\UNC\" + p.Substring(2);   // \\server\share → \\?\UNC\server\share
        return @"\\?\" + p;
    }


    /// <summary>是否已是"完全限定"路径（X:\... 或 \\server\share...）。驱动器相对路径（C:x）与根相对路径（\x）都算否。</summary>
    static bool IsFullyQualified(string p)
    {
        if (string.IsNullOrEmpty(p)) return false;
        if (p.StartsWith(@"\\")) return true;                                    // UNC 或 \\?\
        return p.Length >= 3 && p[1] == ':' && (p[2] == '\\' || p[2] == '/');     // X:\ 或 X:/
    }


    static string TrimP(string p)   // \\?\ 前缀还原（UNC 还原为 \\server\share）
    {
        if (string.IsNullOrEmpty(p)) return p;
        if (p.StartsWith(@"\\?\UNC")) return @"\\" + p.Substring(8);
        if (p.StartsWith(@"\\?\")) return p.Substring(4);
        return p;
    }


    static string ReadLineTrim()
    {
        if (inputEof) return "";
        string s = null;
        try { s = Console.ReadLine(); } catch { }
        if (s == null) { inputEof = true; return ""; }
        return s.Trim();
    }

    // ---------------- 桌面快捷方式 ----------------


    /// <summary>快捷方式基名净化：只取文件名部分、剔除非法字符（含路径分隔符，防目录穿越），最长 80 字符。
    /// 纯函数，可单测。返回空串表示名字非法（调用方应拒绝创建，而不是写一个怪名字）。</summary>
    static string SafeShortcutName(string raw)
    {
        string s = (raw ?? "").Trim();
        if (s.Length == 0) return "";
        // 手工取最后一段，避免 Path.GetFileName 对非法字符抛异常
        int cut = s.LastIndexOfAny(new char[] { '\\', '/' });
        if (cut >= 0 && cut + 1 < s.Length) s = s.Substring(cut + 1);
        StringBuilder sb = new StringBuilder();
        foreach (char c in s)
        {
            if (c < 32) continue;
            if ("\\/:*?\"<>|".IndexOf(c) >= 0) continue;
            sb.Append(c);
        }
        string n = sb.ToString().Trim().Trim('.');
        return n.Length > 80 ? n.Substring(0, 80) : n;
    }


    /// <summary>运行时长格式化（单测覆盖）：&lt;60 秒报秒；&lt;60 分报分；&lt;24 小时报"时 分"；再长报"天 时"。</summary>
    static string FormatUptime(TimeSpan t)
    {
        if (t < TimeSpan.Zero) t = TimeSpan.Zero;                       // 时钟回拨保护：不显示负数时长
        if (t.TotalSeconds < 60) return ((int)t.TotalSeconds) + " 秒";
        if (t.TotalMinutes < 60) return ((int)t.TotalMinutes) + " 分";
        if (t.TotalHours < 24) return ((int)t.TotalHours) + " 小时 " + t.Minutes + " 分";
        return ((int)t.TotalDays) + " 天 " + (t.Hours) + " 小时";
    }

    // ---------------- dsh 更新管理 ----------------


    /// <summary>递归收集 相对路径→大小。copyRules=true 复现 CopyTree 跳过规则（node_modules/backup/dsh-data-*）；
    /// reparse point 一律跳过且不进入（与备份/恢复执行侧一致）。</summary>
    static bool IsReparse(string path) { try { return (File.GetAttributes(P(path)) & FileAttributes.ReparsePoint) != 0; } catch { return false; } }


    /// <summary>剪切过长文本（诊断输出用）。</summary>
    static string ClipText(string s, int n)
    {
        if (string.IsNullOrEmpty(s)) return "";
        return s.Length <= n ? s : s.Substring(0, n) + "…";
    }


    static void Pause()
    {
        Console.WriteLine();
        C(ConsoleColor.DarkGray, T("  按任意键继续...", "  Press any key to continue..."));
        try { Console.ReadKey(true); } catch { }
        Console.WriteLine();
    }


    /// <summary>把字符串变成安全的文件夹名（去掉 Windows 非法字符）。</summary>
    static string SanitizeName(string s)
    {
        if (s == null) return "";
        char[] bad = new char[] { '<', '>', ':', '"', '/', '\\', '|', '?', '*' };
        foreach (char c in bad) s = s.Replace(c.ToString(), "_");
        return s.Trim().Trim('.');
    }




    /// <summary>判断 child 是否位于 parent 子树内（含相等）；大小写不敏感。用于 wipe 前校验备份/状态目录不被误删。</summary>
    static bool IsSubPath(string parent, string child)
    {
        if (string.IsNullOrEmpty(parent) || string.IsNullOrEmpty(child)) return false;
        string a = TrimTrailingSep(parent).ToLowerInvariant();
        string b = TrimTrailingSep(child).ToLowerInvariant();
        return b == a || b.StartsWith(a + "\\");
    }




    /// <summary>去掉结尾分隔符，但保留盘根语义（D:\ 不会变成 D:，UNC 共享根不会丢失尾部斜杠）。</summary>
    static string TrimTrailingSep(string p)
    {
        if (string.IsNullOrEmpty(p)) return p;
        string root = null;
        try { root = Path.GetPathRoot(p); } catch { root = null; }
        p = p.TrimEnd('\\');
        if (root != null && p.Length < root.Length) return root;   // 盘根被 trim 掉时还原
        return p;
    }




    /// <summary>配置摘要：launcher.config 的非注释行。</summary>
    static string ConfigSummary()
    {
        try
        {
            if (!File.Exists(ConfigPath())) return "(无配置文件)";
            var kept = new List<string>();
            foreach (string l in File.ReadAllLines(ConfigPath()))
            {
                string t = l.Trim();
                if (t.Length == 0 || t.StartsWith("#")) continue;
                kept.Add(t);
            }
            return kept.Count == 0 ? "(空配置)" : string.Join(" ; ", kept.ToArray());
        }
        catch (Exception ex) { return "读取失败: " + ex.Message; }
    }




    static bool HasFlag(string[] args, string f) { foreach (string a in args) if (string.Equals(a, f, StringComparison.OrdinalIgnoreCase)) return true; return false; }



    static string FlagValue(string[] args, string f) { for (int i = 1; i < args.Length - 1; i++) if (string.Equals(args[i], f, StringComparison.OrdinalIgnoreCase)) return args[i + 1]; return null; }



}
