/** Privacy-preserving root-session projection for fresh Shadow runs. @module @whutzefengxie-ops/dsh-shadow-mind/trajectory */

import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
import type {} from '@deepseek-ai/dsh-compaction'
import { estimateTextTokens } from './model-context.ts'
import type { ShadowDefinition, ShadowMindSettings } from './types.ts'

/** One projected transcript plus the exact durable anchors visible in it. */
export interface ProjectedTrajectory {
  /** Model-visible trajectory text. */
  readonly text: string
  /** Sequence numbers rendered into the text. */
  readonly seqs: ReadonlySet<number>
}

/** Count text characters recursively without retaining content. */
function contentChars(blocks: readonly ContentBlock[]): number {
  let count = 0
  for (const block of blocks) {
    if (block.type === 'text' || block.type === 'reasoning') count += block.text.length
    else if (block.type === 'tool-result') count += contentChars(block.content)
  }
  return count
}

/** Collect model-visible plain text while excluding reasoning and tool payloads. */
function visibleText(blocks: readonly ContentBlock[]): string {
  const parts: string[] = []
  for (const block of blocks) {
    if (block.type === 'text') parts.push(block.text)
    else if (block.type === 'image') parts.push('[image omitted]')
  }
  return parts.join('\n').trim()
}

/** Count non-empty lines in all nested text blocks. */
function contentLines(blocks: readonly ContentBlock[]): number {
  let count = 0
  for (const block of blocks) {
    if (block.type === 'text') count += block.text.split(/\r?\n/gu).filter(line => line.trim() !== '').length
    else if (block.type === 'tool-result') count += contentLines(block.content)
  }
  return count
}

/** Stable type counts for an unknown tool result. */
function contentKinds(blocks: readonly ContentBlock[], counts = new Map<string, number>()): Map<string, number> {
  for (const block of blocks) {
    counts.set(block.type, (counts.get(block.type) ?? 0) + 1)
    if (block.type === 'tool-result') contentKinds(block.content, counts)
  }
  return counts
}

/** Read semantic line counts from the filesystem tool's durable result metadata. */
function readMetaCounts(meta: unknown): { readonly lines: number; readonly chars: number } | undefined {
  if (meta === null || typeof meta !== 'object' || Array.isArray(meta)) return undefined
  const lines = (meta as Record<string, unknown>)['lines']
  if (!Array.isArray(lines)) return undefined
  let nonEmpty = 0
  let chars = 0
  for (const line of lines) {
    if (line === null || typeof line !== 'object' || Array.isArray(line)) return undefined
    const text = (line as Record<string, unknown>)['text']
    if (typeof text !== 'string') return undefined
    if (text.trim() !== '') nonEmpty += 1
    chars += text.length
  }
  return { lines: nonEmpty, chars }
}

/**
 * Summarize a tool result without disclosing its text.
 * @param toolName Tool name paired from the durable call event.
 * @param content Model-facing result content.
 * @param failed Whether the result carries a tool error.
 * @param meta Optional durable result metadata used only when its known fields validate.
 * @returns Deterministic compact summary.
 */
export function summarizeToolResult(
  toolName: string,
  content: readonly ContentBlock[],
  failed: boolean,
  meta?: unknown,
): string {
  const outcome = failed ? 'error' : 'success'
  const chars = contentChars(content)
  if (toolName === 'read') {
    const counts = readMetaCounts(meta) ?? { lines: contentLines(content), chars }
    return `read ${outcome}: ${String(counts.lines)} non-empty lines, ${String(counts.chars)} text characters`
  }
  if (toolName === 'grep') return `grep ${outcome}: ${String(contentLines(content))} result lines, ${String(chars)} text characters`
  if (toolName === 'glob') return `glob ${outcome}: ${String(contentLines(content))} paths, ${String(chars)} text characters`
  const kinds = [...contentKinds(content)].sort(([left], [right]) => left.localeCompare(right))
    .map(([kind, count]) => `${kind}=${String(count)}`).join(', ')
  return `${toolName} ${outcome}: ${String(chars)} text characters; blocks ${kinds === '' ? 'none' : kinds}`
}

/**
 * Project a session prefix into a stable, reasoning-free text transcript.
 * @param events Complete root session events.
 * @param capturedThroughSeq Inclusive event sequence watermark.
 * @param argumentDisclosure Tool argument policy.
 * @param capture Root trajectory window policy.
 * @returns Plain-text trajectory.
 */
export function projectTrajectoryWithAnchors(
  events: readonly SessionEvent[],
  capturedThroughSeq: number,
  argumentDisclosure: ShadowMindSettings['argumentDisclosure'],
  capture: ShadowDefinition['capture'] = 'full',
): ProjectedTrajectory {
  const lines: string[] = []
  const seqs = new Set<number>()
  const calls = new Map<string, string>()
  const boundary = capture === 'since-compaction'
    ? events.findLast(event => event.seq <= capturedThroughSeq
      && event.type === 'compaction/end'
      && event.data.error === undefined)?.seq
    : undefined
  for (const event of events) {
    if (event.seq > capturedThroughSeq) break
    if (boundary !== undefined && event.seq < boundary && event.type !== 'compaction/summary') continue
    const lineCount = lines.length
    switch (event.type) {
      case 'user/message': {
        const text = visibleText(event.data.content)
        if (text !== '') lines.push(`[seq=${String(event.seq)} user:${event.data.source.kind}]\n${text}`)
        break
      }
      case 'assistant/message': {
        const text = visibleText(event.data.message.content)
        if (text !== '') lines.push(`[seq=${String(event.seq)} assistant]\n${text}`)
        break
      }
      case 'compaction/summary': {
        const text = visibleText(event.data.summary)
        if (text !== '') lines.push(`[seq=${String(event.seq)} compaction summary]\n${text}`)
        break
      }
      case 'tool/call':
        calls.set(String(event.data.callId), event.data.name)
        lines.push(`[seq=${String(event.seq)} tool call] ${event.data.name} arguments=${argumentDisclosure === 'full' ? event.data.arguments : '[redacted]'}`)
        break
      case 'tool/result': {
        const message = event.data.message
        const legacy = message.content[0]
        const toolCallId = 'toolCallId' in message ? message.toolCallId : legacy !== undefined && legacy.type === 'tool-result' ? legacy.toolCallId : undefined
        const content = legacy !== undefined && legacy.type === 'tool-result' ? legacy.content : message.content
        const failed = ('isError' in message && message.isError === true)
          || (legacy !== undefined && legacy.type === 'tool-result' && legacy.isError === true)
          || event.data.error !== undefined
        const toolName = toolCallId === undefined ? 'unknown-tool' : calls.get(String(toolCallId)) ?? 'unknown-tool'
        lines.push(`[seq=${String(event.seq)} tool result] ${summarizeToolResult(
          toolName,
          content,
          failed,
          event.data.meta,
        )}`)
        break
      }
      default:
        break
    }
    if (lines.length > lineCount) seqs.add(event.seq)
  }
  return { text: lines.join('\n\n'), seqs }
}

/**
 * Project a session prefix into a stable, reasoning-free text transcript.
 * @param events Complete root session events.
 * @param capturedThroughSeq Inclusive event sequence watermark.
 * @param argumentDisclosure Tool argument policy.
 * @param capture Root-log range to project.
 * @returns Plain-text trajectory.
 */
export function projectTrajectory(
  events: readonly SessionEvent[],
  capturedThroughSeq: number,
  argumentDisclosure: ShadowMindSettings['argumentDisclosure'],
  capture: ShadowDefinition['capture'] = 'full',
): string {
  return projectTrajectoryWithAnchors(events, capturedThroughSeq, argumentDisclosure, capture).text
}

/** Marker prepended when the oldest trajectory events were trimmed to fit the prompt bound. */
const TRAJECTORY_TRIM_MARKER = '[earlier trajectory events trimmed to fit the prompt bound]'

/**
 * Keep the newest trajectory events so the remainder (plus the trim marker)
 * satisfies both the character budget and the estimated-token budget.
 * Availability first: this never throws, and an absurdly small budget degrades
 * to the marker alone.
 * @param trajectory Projected trajectory text.
 * @param charBudget Characters available for the trimmed body plus marker; `Infinity` disables the bound.
 * @param tokenBudget Estimated tokens available for the trimmed body plus marker; `Infinity` disables the bound.
 * @returns The trimmed trajectory.
 */
function trimTrajectoryToBudget(trajectory: string, charBudget: number, tokenBudget: number): string {
  const markerTokens = estimateTextTokens(TRAJECTORY_TRIM_MARKER) + estimateTextTokens('\n\n')
  const contentCharBudget = charBudget - TRAJECTORY_TRIM_MARKER.length - 2
  const contentTokenBudget = tokenBudget - markerTokens
  if (contentCharBudget <= 0 || contentTokenBudget <= 0) {
    return TRAJECTORY_TRIM_MARKER.slice(0, Math.max(0, Math.min(charBudget, Number.MAX_SAFE_INTEGER)))
  }
  const parts = trajectory.split('\n\n')
  // Suffix character and token totals per start index, so the trimmer drops
  // whole oldest events without rebuilding the string on every step.
  const suffixChars = new Array<number>(parts.length)
  const suffixTokens = new Array<number>(parts.length)
  let chars = 0
  let tokens = 0
  for (let index = parts.length - 1; index >= 0; index--) {
    // The loop fills every index in range; the assertions are the invariant.
    chars += parts[index]!.length
    tokens += estimateTextTokens(parts[index]!)
    const joiners = parts.length - 1 - index
    suffixChars[index] = chars + joiners * 2
    suffixTokens[index] = tokens + joiners * estimateTextTokens('\n\n')
  }
  let start = 0
  while (start < parts.length - 1
    && (suffixChars[start]! > contentCharBudget || suffixTokens[start]! > contentTokenBudget)) {
    start += 1
  }
  let kept = parts.slice(start).join('\n\n')
  if (kept.length > contentCharBudget) kept = kept.slice(0, contentCharBudget)
  if (estimateTextTokens(kept) > contentTokenBudget) {
    // A single event can still dominate the token budget; cutting it to the
    // budget in characters always keeps the estimate within the budget,
    // because the estimate never exceeds the character count.
    kept = kept.slice(0, contentTokenBudget)
  }
  return `${TRAJECTORY_TRIM_MARKER}\n\n${kept}`
}

/**
 * Build the complete fresh-child prompt. When the prompt exceeds either the
 * configured character bound or the model-derived token budget, the oldest
 * trajectory events are trimmed away so the prompt fits the configured bounds;
 * a bound of zero (or less) disables that limit. This builder never throws: an
 * over-budget prompt degrades to a trimmed (or omitted) trajectory instead of
 * failing the Shadow run.
 * @param definition Selected Shadow definition.
 * @param trajectory Projected root trajectory.
 * @param capturedThroughSeq Inclusive root sequence watermark.
 * @param maxPromptChars Complete prompt soft character bound; 0 = unlimited.
 * @param maxPromptTokens Complete prompt soft estimated-token bound (model context window minus headroom); 0 = unlimited.
 * @returns Framed Shadow task.
 */
export function buildShadowPrompt(
  definition: ShadowDefinition,
  trajectory: string,
  capturedThroughSeq: number,
  maxPromptChars: number,
  maxPromptTokens = 0,
): string {
  const header = [
    `You are the independent Shadow \"${definition.name}\" (${definition.id}).`,
    'Review the captured root-agent trajectory. Do not assume access to hidden reasoning or omitted tool output.',
    'Return status "not_relevant" when your specialty does not apply, "silent" when it applies but adds nothing actionable, or "report" with a concise self-contained finding.',
    'For "not_relevant" and "silent", content must be an empty string; only a "report" carries body text.',
    'Every report must set verdict to "challenge", "gap", "confirm", or "uncertain"; refs is an ascending unique list of at most eight rendered seq values, and optional severity is from 0 through 1.',
    'A report must help the root agent decide or act; do not narrate that you reviewed the trajectory.',
    ...definition.thinkFirst
      ? ['Before using tools, write a numbered plan naming the rendered seq values you intend to challenge or verify.']
      : [],
    '',
    '## Shadow instructions',
    definition.prompt,
    '',
    `## Root trajectory (captured through session seq ${String(capturedThroughSeq)})`,
  ].join('\n')
  const headerTokens = estimateTextTokens(header)
  let body = trajectory === '' ? '[no model-visible trajectory content]' : trajectory
  const charBudget = maxPromptChars > 0 ? maxPromptChars - header.length - 1 : Number.POSITIVE_INFINITY
  const tokenBudget = maxPromptTokens > 0 ? maxPromptTokens - headerTokens : Number.POSITIVE_INFINITY
  if (body.length > charBudget || estimateTextTokens(body) > tokenBudget) {
    body = charBudget <= 0 || tokenBudget <= 0
      ? '[no model-visible trajectory content]'
      : trimTrajectoryToBudget(body, charBudget, tokenBudget)
  }
  return `${header}\n${body}`
}
