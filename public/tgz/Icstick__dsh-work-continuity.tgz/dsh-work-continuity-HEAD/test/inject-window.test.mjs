// test/inject-window.test.mjs — 2026-10-11 注入窗口修正 + cwd 属性路径修正的回归测试
//
// 两个 bug 都在 A 机 2026-10-11 实测复现：
//   ① decisions / unresolved 是只追加的日志，注入却 slice(0, N) 取最旧的 N 条
//      → A 机 decisions 223 条时，index 2..222 共 221 条永不进入上下文，
//        而注入进去的 index 1 早在 index 23 就被订正推翻过。
//   ② cwd 读在 session.cwd 上，实际在 session.header.cwd 上 → ws:<hash> 分支成死代码。
// 本文件锁住这两条，防止回退。
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { renderWorkStateBrief, cwdOfSession, cwdFromCtx, scopeIdForCwd } from '../src/index.mjs'

// 零填充：避免 'decision-10'.includes('decision-1') 这种子串碰撞把断言搞成假通过/假失败
const dec = (n) => Array.from({ length: n }, (_, i) => ({ text: 'decision-' + String(i + 1).padStart(2, '0'), evidenceIds: [] }))

// ---------- ① 注入窗口：日志类取尾部 ----------

test('decisions 取最新 N 条，不取最旧 N 条（223 条场景的缩小版）', () => {
  const st = { goal: 'g', status: 'active', decisions: dec(10), nextSteps: [], unresolved: [] }
  const out = renderWorkStateBrief(st)
  assert.ok(out.includes('decision-10'), '应包含最后一条')
  assert.ok(out.includes('decision-09'), '应包含倒数第二条')
  assert.ok(!out.includes('decision-01'), '不应包含最旧那条')
  assert.ok(!out.includes('decision-02'), '不应包含次旧那条')
})

test('unresolved 取最新 N 条，不取最旧 N 条', () => {
  const st = { goal: 'g', status: 'active', decisions: [], nextSteps: [], unresolved: ['u1', 'u2', 'u3', 'u4', 'u5'] }
  const out = renderWorkStateBrief(st)
  assert.ok(out.includes('u5') && out.includes('u4'))
  assert.ok(!out.includes('u1') && !out.includes('u2'))
})

test('next_steps 仍取最前 N 条 —— 它是队列（next 追加 / done 移除），队首才是「下一个该做的」', () => {
  const st = { goal: 'g', status: 'active', decisions: [], unresolved: [], nextSteps: ['n1', 'n2', 'n3', 'n4', 'n5'] }
  const out = renderWorkStateBrief(st)
  assert.ok(out.includes('n1') && out.includes('n2') && out.includes('n3'))
  assert.ok(!out.includes('n4') && !out.includes('n5'))
})

test('数组不足窗口大小时不越界、不重复', () => {
  const st = { goal: 'g', status: 'active', decisions: dec(1), nextSteps: ['only'], unresolved: ['solo'] }
  const out = renderWorkStateBrief(st)
  assert.ok(out.includes('decision-01'))
  assert.equal(out.match(/decision-01/g).length, 1)
  assert.ok(out.includes('only') && out.includes('solo'))
})

test('空数组不产生 decided / open 行', () => {
  const out = renderWorkStateBrief({ goal: 'g', status: 'active', decisions: [], nextSteps: [], unresolved: [] })
  assert.ok(!out.includes('decided:'))
  assert.ok(!out.includes('open:'))
})

// ---------- ② cwd 属性路径 ----------

test('cwdOfSession 读 header.cwd（正确路径）', () => {
  assert.equal(cwdOfSession({ id: 's1', header: { cwd: 'D:\\ws\\proj-a' } }), 'D:\\ws\\proj-a')
})

test('cwdOfSession 对「cwd 挂在顶层」的旧错误形状返回 undefined —— 不再静默读到顶层的假值', () => {
  assert.equal(cwdOfSession({ id: 's1', cwd: 'D:\\ws\\wrong' }), undefined)
})

test('cwdOfSession 对空/异常输入返回 undefined 而不抛', () => {
  assert.equal(cwdOfSession(undefined), undefined)
  assert.equal(cwdOfSession(null), undefined)
  assert.equal(cwdOfSession({}), undefined)
  assert.equal(cwdOfSession({ header: {} }), undefined)
  assert.equal(cwdOfSession({ header: { cwd: 42 } }), undefined)
})

test('header 与顶层同时存在时，以 header 为准', () => {
  assert.equal(cwdOfSession({ cwd: 'X', header: { cwd: 'Y' } }), 'Y')
})

test('cwdFromCtx 经 ctx.get("session") 取 header.cwd', () => {
  const ctx = { get: (k) => (k === 'session' ? { header: { cwd: 'D:\\ws\\from-ctx' } } : undefined) }
  assert.equal(cwdFromCtx(ctx), 'D:\\ws\\from-ctx')
})

test('cwdFromCtx：settings 服务缺失 / get 抛错 时返回 undefined，不炸', () => {
  assert.equal(cwdFromCtx({}), undefined)
  assert.equal(cwdFromCtx({ get: () => { throw new Error('boom') } }), undefined)
  assert.equal(cwdFromCtx(undefined), undefined)
})

test('scopeIdForCwd：有 cwd → ws:<hash>；无 cwd → user-global（行为未变）', () => {
  const a = scopeIdForCwd('D:\\DSH_workspace')
  assert.match(a, /^ws:[0-9a-f]{12}$/)
  assert.equal(a, 'ws:cc3f97d9a2f5', 'D:\\DSH_workspace 的 scope id 应与 A 机库里那条僵尸行一致')
  assert.equal(scopeIdForCwd(undefined), 'user-global')
  assert.equal(scopeIdForCwd(''), 'user-global')
  assert.equal(scopeIdForCwd(123), 'user-global')
})

test('端到端：修好路径后，带 header.cwd 的会话不会再落 user-global 桶', () => {
  const session = { id: 's', header: { cwd: 'D:\\ws\\proj-a' } }
  const sid = scopeIdForCwd(cwdOfSession(session))
  assert.notEqual(sid, 'user-global')
  assert.equal(sid, scopeIdForCwd('D:\\ws\\proj-a'))
})

// ---------- ③ pre-step 决策改写必须 spread（DSH 0.2.x 契约）----------
// 0.2.0-rc.1 的 cordis-plugin-development/references/practices.md「Stability」明写：
//   rewriting an agent/pre-step decision **must spread it** so fields such as
//   startsRequestSeries survive。构造新对象会静默丢字段。
// 这条锁住源码形状：src/index.mjs 里两处改写都必须带 spread。
test('pre-step 改写决策处必须 spread（源码形状回归）', async () => {
  const fs = await import('node:fs')
  const src = fs.readFileSync(new URL('../src/index.mjs', import.meta.url), 'utf8')
  const bad = src.match(/return \{ kind: 'enter', messages: \[\.\.\.decision\.messages/g) || []
  assert.equal(bad.length, 0, '发现未 spread 的决策改写（0.2.x 会丢字段）: ' + bad.length + ' 处')
  const good = src.match(/return \{ \.\.\.decision, messages: \[\.\.\.decision\.messages/g) || []
  assert.ok(good.length >= 2, '应至少有 2 处 spread 改写，实际 ' + good.length)
})


// ---------- ④ 空 scope 行不得吞掉回落链（2026-10-11 实测事故）----------
// 事故形状：ws:<hash> 有一行「存在但为空」的记录，而真正的内容在 user-global。
// 老实现 if (fresh) return fresh 一命中就返回空壳 → renderWorkStateBrief 渲染空串 → 整块注入消失。
test('isEmptyWorkState：空行判据与 renderWorkStateBrief 的短路条件一致', async () => {
  const { isEmptyWorkState } = await import('../src/index.mjs')
  assert.equal(isEmptyWorkState(null), true)
  assert.equal(isEmptyWorkState({}), true)
  assert.equal(isEmptyWorkState({ goal: '', focus: '', nextSteps: [], decisions: [], unresolved: [], handoff: null }), true)
  assert.equal(isEmptyWorkState({ goal: '   ' }), true)
  assert.equal(isEmptyWorkState({ nextSteps: ['x'] }), false)
  assert.equal(isEmptyWorkState({ decisions: [{ text: 'd' }] }), false)
  assert.equal(isEmptyWorkState({ unresolved: ['u'] }), false)
  assert.equal(isEmptyWorkState({ focus: 'f' }), false)
  assert.equal(isEmptyWorkState({ goal: 'g' }), false)
  assert.equal(isEmptyWorkState({ handoff: { summary: 'h' } }), false)
  assert.equal(isEmptyWorkState({ handoff: { deadends: [1] } }), true, '只有 deadends 不算可注入内容')
})

test('空 scope 行的渲染结果是空串 —— 所以它绝不能算「命中」', () => {
  const emptyRow = { scopeId: 'ws:cc3f97d9a2f5', goal: '', status: 'planned', focus: null, nextSteps: [], decisions: [], unresolved: [], handoff: null }
  assert.equal(renderWorkStateBrief(emptyRow), '', '空行渲染为空串 —— 若拿它当命中，注入就整块消失')
  const realRow = { scopeId: 'user-global', goal: '全局目标仍在', status: 'active', focus: null, nextSteps: ['下一步'], decisions: [], unresolved: [], handoff: null }
  assert.ok(renderWorkStateBrief(realRow).includes('全局目标仍在'), '回落目标必须能渲染出内容')
})