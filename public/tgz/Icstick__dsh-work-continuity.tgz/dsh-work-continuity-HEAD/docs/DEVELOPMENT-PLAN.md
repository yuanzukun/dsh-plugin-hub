# dsh-work-continuity — 开发计划与问题登记（Backlog）

> 仓库级 backlog：进行中/待办/已收口的工作条目与已知问题。
> 当前消息来源：工作摘要采用 `plugin:dsh-work-continuity`，满足 Session v4 生产者归属要求。
> 维护规则：条目完成即更新状态并注明提交/日期；新发现先登记再动手（规划先行）。
> 本文件初版登记来源：D:\DSH_workspace\docs\audits\plugin-code-review-2026-09-07.md（2026-09-07 全面审查）

## 版本线

| 版本 | 收口提交 | 内容 |
|---|---|---|
| 0.2.0 | a295924 | 权威事件自动捕获 P1-5、work_state 工具与 pre-step 注入 P1-6、注入调度器接线、设置顶层 section、deadline/deliverable meta、golden regression |
| 0.2.1 | 01f0a42 | T4 M4.5：注入摘要 deadline 渲染 + 逾期标记 |
| 0.3.0 | ca179a5 | 0.2.1 未单独发版，随 0.3.0 发行：T4 M4.5 deadline 渲染（c54c22c）+ 2026-09-07 审查修复（P1-1/P1-2、B1-B6/B8）与 backlog 收口；版本决议不变：修复集不单独 bump，随特性里程碑收口 |
| 0.4.0 | 0e76ddd | 完成权分离（模型→in_review，人类 /checkpoint status done）+ 乐观并发（WC_STALE_VERSION）+ handoff/deadend 能力与渲染 + 压缩后重锚（compaction/summary 后补注一次）+ form 事故修复 |

## 待办（Backlog）

| ID | 级别 | 问题 | 解决方式 | 状态 |
|---|---|---|---|---|
| WC-B1 | P2 | 仓库内运行时残留未删（实际位置：嵌套 dsh-work-continuity/dsh-work-continuity/，db 28KB + shm/wal，空库 0 行，无实例引用） | 删除三件套 + 空目录（.gitignore 已兜底） | ✅ 2026-09-08 删除（e8c26d8 批次清理） |
| WC-B2 | P3 | COMMAND_DESCRIPTION.zh 定义未使用（index.mjs:59-66），注册只取 .en（:527-528）——半成品 i18n | 描述扁平化为中文（与 ACP 命令及 work_state 工具一致；宿主无 per-locale 机制） | ✅ 2026-09-08 6a7fc55 |
| WC-B3 | P3 | CONTRACTS.md 跨仓库注释引用 ×3（index.mjs:3、store.mjs:3/49）指向 acp-docs/CONTRACTS.md 无链接 | 注释补定位（独立文档库 my-plugins/acp-docs/） | ✅ 2026-09-08 6a7fc55 |
| WC-B4 | P3 | README 设计取舍节"work_audit 审计回溯"表述偏高：实际无明细查询命令（仅 /checkpoint stats 聚合 + 落库留痕） | README 改"全部写入 work_audit 留痕（/checkpoint stats 聚合可见）"；若需明细查询面另排 | ✅ 2026-09-08 6a7fc55 |
| WC-B5 | P3 | lint warnings 14 个（0 error）：src/index.mjs:522 未用参数、client/index.js:133/137 unicorn spread fallback、test 9 个未用 t 参数（实查） | 一次 lint-clean 提交（`pnpm lint` 归零；42/42 测试绿） | ✅ 2026-09-08 6a7fc55 |
| WC-B6 | P3 | git 残留分支 ×2（已并入 master）：docs/pr-template、feat/scheduler-metering | git-guardrails 流程：本地 branch -d + push origin --delete（均已合并，无强删） | ✅ 2026-09-08（本地+远端已删） |
| WC-B7 | 计划 | work_audit 明细查询面（可选）：按 scope/op 查审计明细 | 命令面 `/checkpoint audit [--scope <id>] [--op <op>] [--limit n]`（读 work_audit 的 ts/op/scope_id/detail；分页 + 空态提示）；模型侧可选 `work_state` action=audit（只读） | **已排期**：WC 0.5.0 候选——随 S2 观察期结束（2026-09-22）+ 下个特性批评估；期间若出现真实审计需求（注入异常/写入排查）则提前（2026-09-12 排期） |
| WC-B8 | P3 | S2 迁移影响：运行时零依赖 memento/ACP；2 条历史注释（index.mjs:7、withService 处）措辞中性化 | 随 WC-B3 注释批次一并处理 | ✅ 2026-09-08 6a7fc55 |
| WC-B9 | 计划 | 候选催办：把 ACP 的待审 candidate 带进 next_steps（4.3 / ACP-B18 的 WC 侧） | 新增 scripts/acp-candidate-pull.mjs：读 ACP 只读导出的 JSONL → 按 [acp:<id>] 前缀判重 → **只追加**写 next_steps；走 openWorkStore（不裸写 SQL）、带 expectedVersion（冲突不覆盖）、默认 dry-run。绑定设计见工作区 docs/plans/sync-boundary-protocol-20260922.md §7 | ✅ 2026-09-24 3af98f0（实测 8 条入 next_steps；重复拉取 8→8 条不变，即 §7 验收前半） |

## 已收口（近期）

- **form 事故（2026-09-10）**：注入消息声明自造值 `form:'work-state'` → session-format v2→v3 迁移拒收整条会话（本机 25 条历史会话受影响）✅ f6f5715（删自造值 + 回归断言 `source.form === undefined`；maid `form:'pin'`、ACP `form:'consolidation'` 同类问题同日修复，ACP `form:'recall'` 属官方词表合法值）

- P1-1（done <n> 不同步 next_meta）✅ 0d5057b —— golden W9
- P1-2（/checkpoint clear 不全量重置）✅ 0d5057b —— golden W10
- P2-2（store 落库位置：DSH_HOME 缺失不落 cwd）✅ 2026-09-07 —— openWorkStore 兜底 $DSH_HOME → ~/.dsh；回归测试 work.test.mjs:326
- README/test-README 同步（审计 §五差异 1-4）✅ c212b46
- T4 M4.5（deadline 渲染 + 逾期标记）✅ c54c22c（W11/W12）
