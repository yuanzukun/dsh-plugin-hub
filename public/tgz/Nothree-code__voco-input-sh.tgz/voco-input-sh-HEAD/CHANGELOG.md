# Changelog

本插件的所有重要变更都记录在此文件。

格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，
版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [0.2.2] - 2026-09-13

### 修复（关键）

- **麦克风按钮完全不显示**。

  客户端的 `apply(ctx)` 依赖 `ctx.get('slots')`，但插件对象**只导出了 `apply`，没有声明 `inject`**。
  cordis 因此不会等待服务就绪就调用 `apply`，而此时 `slots` 尚未注册，`ctx.get('slots')` 返回
  `undefined`；旧代码写的是 `if (slots === undefined) return;` —— **静默返回**。结果是
  **按钮不出现、控制台也没有任何报错**，极难自查。

  修复：

  - `exports.inject = ['slots', 'timer']`，让 cordis 等到这两个服务就绪后再调用 `apply`；
  - 兜底分支由静默 `return` 改为 `console.error('[voco] slots service unavailable…')`，契约再变时会出声；
  - 两处 slot 注册补上 `label`，`order` 由 `10` 调整为 `12`（让开 `dsh-prompt-enhancer` 已占用的 10/11）。

### 更正

- v0.2.1 曾判断「无需改动代码即可兼容 dsh 0.1.5-rc.2」。该结论**只对 host 端成立**——路由层契约
  确实没变，实测 `/dsh-voco-token`、`/dsh-voco-baseline` 均返回 200。但**客户端并不成立**：上面这个
  `inject` 缺失，正是被新版客户端加载时序暴露出来的真实缺陷。换言之，**v0.2.1 的按钮在
  dsh 0.1.5-rc.2 上是不可见的**，请升级到 v0.2.2。

### 验证

- `node --check` 通过。
- vm 沙箱执行 bundle：`exports` 键为 `['inject','apply']`，`slots.register` 命中 2 次
  （`conversation.input.right#vocotype-paste`、`conversation.input.dock#vocotype-panel`），按钮组件可产出 `button` 元素。
- 真机验证（无头 Chrome + CDP，连运行中的 dsh 0.1.5-rc.2 实例）：
  `document.querySelectorAll('.voco-mic-btn').length` **由 0 变为 1**，页面无 console 报错。

## [0.2.1] - 2026-09-12

### 适配

- **验证 DSH 0.1.5-rc.2 兼容性**，结论是**无需改动代码即可工作**。逐项核对结果：

  | 依赖面 | 0.1.5-rc.2 现状 | 结论 |
  | --- | --- | --- |
  | `dsh.client` 清单契约 | 仍要求 `platform: "web"` + `exports["./client"]` | 一致 |
  | 客户端 bundle 入口 | 仍是 `window.__ModuleLoader__.load({ id, factory })` | 一致 |
  | 插槽 `conversation.input.right` | 仍存在 | 一致 |
  | 插槽 `conversation.input.dock` | 仍存在，owner 仍是 `InputZone` | 一致 |
  | 插槽 props 契约 | `InputZone = { session, input }`、`InputState.draft`、`inputActions.setDraft(text)` | 一致 |
  | Host 路由注册 | 仍是 `webServer.register({ kind: 'exact', path, handler })` | 一致 |

  运行时实证：在当前 dsh 0.1.5-rc.2 实例上，`/dsh-voco-token` 与 `/dsh-voco-baseline` 均返回 HTTP 200。

### 修复

- **VocoType 重启或日志轮转后，语音不再插入输入框**。
  日志条目数一旦回退，客户端持有的 `after` 游标就越过了文件末尾，`/dsh-voco-poll` 会一直返回「无新内容」，
  表现为「点了麦克风、说了话，却再也没有文字插入」，必须重新点一次麦克风才能恢复。
  现在 host 端会比较相邻两次读取的条目数，检测到回退时返回 `rotated: true` 并清空增量，
  客户端收到后把游标重设到当前末尾，后续识别继续正常插入。（`lib/index.js`、`lib/client.js`）

### 文档

- README 新增「DSH 兼容性」章节，记录已验证的宿主版本、依赖的 API 契约与已知行为边界。
- 新增本 CHANGELOG。

## [0.2.0] - 2026-08-15

### 新增

- 加入 `dsh.bundle` 清单（`cordis.patch.yml`），支持通过 `dsh plugin add` 标准安装。

### 修复

- `sync.ps1` 的同步文件列表补入 `cordis.patch.yml`（原先遗漏，导致清单改动不生效）。

## [0.1.1] - 2026-08-15

### 安全

- **部署操作改为 POST + 每进程 anti-CSRF token**：`/dsh-voco-ensure` 从 GET 改为 POST，
  必须携带 `/dsh-voco-token` 下发的令牌，封堵跨站 `<img>` 触发「下载 + 静默安装」。
- **供应链加固**：下载链路移除 `--ssl-no-revoke`；安装包固定 SHA-256
  （`5629de8a…02c5c2`），下载后先校验、不匹配即删除并中止。
- 全部路由加 Origin / Sec-Fetch-Site 守卫，拒绝跨站请求。
- 移除硬编码用户路径，日志路径完全基于 `%LOCALAPPDATA%`（回退 `homedir/AppData/Local`）。
- **GBK 日志回退**：UTF-8 解码失败时改用 GBK，中文识别不再乱码。
- **执行超时**：PowerShell 调用加 180s 超时，客户端 ensure 请求加 120s 超时。

## [0.1.0] - 2026-08-15

### 新增

- 首个版本：输入框工具行的麦克风按钮 + 输入框上方的录音面板。
- 读取 VocoType 识别日志、去重后自动写入输入框草稿。
- 自动检测 / 启动 / 部署 VocoType（含安装包下载与静默安装）。

[0.2.2]: https://github.com/Nothree-code/voco-input-sh/compare/v0.2.1...v0.2.2
[0.2.1]: https://github.com/Nothree-code/voco-input-sh/compare/8ffb189...v0.2.1
[0.2.0]: https://github.com/Nothree-code/voco-input-sh/compare/v0.1.1...v0.2.0
[0.1.1]: https://github.com/Nothree-code/voco-input-sh/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/Nothree-code/voco-input-sh/releases/tag/v0.1.0
