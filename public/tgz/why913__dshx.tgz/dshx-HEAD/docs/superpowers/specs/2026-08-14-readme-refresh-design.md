# dshx README Refresh Design

Date: 2026-08-14
Status: Approved direction (A)

## Goal

Rewrite the Chinese and English READMEs so a new DeepSeek Harness user can understand dshx from one concrete story: they found an MCP server, give dshx its documented command or URL, and dshx verifies the connection before writing the DSH configuration.

The README should feel like it was written by the developer who built and tested the project, not like a feature inventory or marketing page.

## Audience and message

Primary audience: a DSH user who has found an MCP server but does not know how to translate its `npx` command or remote URL into `cordis.patch.yml` safely.

Core message:

> dshx does not replace npm, the MCP server, or DSH. It starts and checks the server, performs the MCP handshake and `tools/list`, and writes the configuration only when that check succeeds.

The copy must distinguish three cases:

- `npx`-based local servers: `npx` downloads/runs the missing package; dshx validates and configures it.
- Remote HTTP servers: no local MCP package is required; dshx validates the endpoint and writes its URL/headers.
- Servers requiring a separate binary or manual build: dshx does not install that prerequisite; the preflight test fails and nothing is written by default.

## Chosen narrative and layout

Use direction A: direct developer narrative with technical proof. Do not use the three-panel comic in the final README.

The Chinese README structure is:

1. Project name, language switcher, one-sentence description.
2. Hero image and a short scenario: "you found an MCP; DSH configuration is the awkward part."
3. Minimal installation and `dshx mcp add` quick start, including representative successful output.
4. "What dshx is responsible for" explanation followed by the technical MCP validation flow image.
5. MCP migration from Claude Code/Codex with a copyable terminal result block; keep the existing 12 discovered / 10 imported / 2 rejected test clearly labeled as one real local test, not a universal benchmark.
6. Three capability groups: MCP, Skill, and Memory.
7. CLI installation, optional DSH plugin installation, Skill installation, and the complete command reference.
8. Safety/design guarantees, limitations, compatibility, roadmap, and license.

The English README follows the same information architecture but uses idiomatic English rather than a sentence-by-sentence translation.

## Visual assets

Final assets live under `assets/` and are referenced with relative paths from both READMEs.

- `assets/dshx-hero.webp`: selected existing hero image that introduces the project and the "connect first, write second" idea.
- `assets/dshx-mcp-flow.webp`: selected A technical diagram showing command/URL -> MCP -> dshx handshake and `tools/list` -> valid MCP enters DSH, while a 403/broken server is rejected.

Source previews:

- Hero: `.superpowers/brainstorm/277-1786674694/content/hero-current.png`
- Flow: `.superpowers/brainstorm/277-1786674694/content/middle-a.png`

Convert both selected sources to WebP with visually lossless/readable settings to reduce GitHub and npm README weight. Keep text and icons legible at typical README width. The generated B comic remains a brainstorming artifact and is not copied into `assets/`.

Each image gets useful alt text. The terminal migration result remains a Markdown code block instead of a screenshot so it is accurate, selectable, searchable, and easy to update.

Add `assets/` to the npm `files` allowlist so images render in the npm package README. Add `.superpowers/` to `.gitignore`; visual brainstorming previews are local design artifacts, not release assets.

## Accuracy constraints

- Do not say dshx discovers and installs arbitrary MCP software automatically.
- Do not imply that dshx itself downloads npm packages; attribute that behavior to `npx`.
- Do not claim that configuration changes always hot-reload. Use the existing behavior: restart DSH or reload the target profile after a write.
- Describe `/mcp` only as currently implemented: a human-facing status/connection-test command. Do not document `/mcp add`, `/mcp remove`, or `/mcp import` unless those commands are implemented and tested later.
- The DSH plugin exposes the existing model tools `mcp_list`, `mcp_add`, `mcp_remove`, `mcp_test`, and `mcp_import`.
- Explain that `$VAR` references avoid writing a literal secret when supplied that way, while imported source configuration may already contain literal values.
- Keep the documented Node and DSH compatibility versions aligned with `package.json` and the actually tested local DSH version.
- Preserve the current distinction between preview and write operations: imports preview by default and require `--yes` to write.

## Files in scope

- `README.md`
- `README.zh.md`
- `assets/dshx-hero.webp` (new)
- `assets/dshx-mcp-flow.webp` (new)
- `package.json` (`files` allowlist only)
- `.gitignore` (ignore `.superpowers/` only)

No CLI, plugin, MCP, Skill, or Memory behavior changes are part of this README refresh.

## Validation

- Cross-check every documented command and flag against `bin/dshx.js` and every documented plugin tool/command against `index.js` and `lib/mcp-command.js`.
- Run the existing `npm test` suite.
- Run `npm pack --dry-run` and confirm both WebP files are included.
- Decode/inspect both final WebP files and verify their dimensions, legibility, and reasonable file sizes.
- Check all relative README links and image paths from both language files.
- Review both READMEs for unsupported claims, accidental secret examples, mojibake, and stale command names.
