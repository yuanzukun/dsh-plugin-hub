# Claude Code-style `/mcp` for dshx

## Goal

Add a human-facing `/mcp` command to DeepSeek Harness. Its default behavior
matches the useful core of Claude Code's command: show every configured MCP
server, its current reachability, latency, and exposed tool count.

## User interface

- `/mcp` checks all dshx-managed servers concurrently and prints one compact
  status row per server.
- `/mcp <server>` checks one server and includes its tool names.
- `/mcp help` explains the two forms and points configuration changes to the
  existing `dshx mcp add|rm|import` CLI.
- The command never sends a prompt to the model.

## Architecture

The command is a thin adapter over the existing core:

- `listServers(scope)` remains the source of configured servers.
- `testServer(server)` remains the only connection and tool-discovery path.
- Existing plugin tools and the CLI remain unchanged.
- Command registration uses DSH's public `ctx.commands.register()` service via
  optional `ctx.inject(['commands'], ...)`, so headless compositions without
  human commands can still load the plugin.

## Deliberate boundary

DSH 0.1.0-rc.6 does not expose the live connection, reconnect, or OAuth state
of `@deepseek-ai/dsh-mcp-client` to third-party plugins. dshx therefore reports
a fresh diagnostic connection instead of pretending to control DSH's internal
connection. OAuth is not offered until DSH exposes a supported API.

The shipped `headless` CLI is a one-shot model runner, not an interactive
command surface: it forwards its entire positional task through
`agent.followup()`. A real invocation of `dsh --profile headless "/plan"`
therefore reached the model instead of `commands.execute()`, and the official
repository's current `master` uses the same path. Terminal users keep using
`dshx mcp ...`; the slash command is mounted by DSH Web's command pipeline.

## Verification

1. Plugin tool schemas compile under DSH's supported JSON Schema subset.
2. `/mcp` reports connected, empty-tool, and failed servers.
3. `/mcp <server>` reports tool names and rejects unknown servers.
4. The packaged plugin loads in the Web profile.
5. Entering `/mcp` in DSH Web renders the status result without invoking the
   model.
