import test from 'node:test'
import assert from 'node:assert/strict'
import { join } from 'node:path'
import { tmpdir } from 'node:os'

import { apply } from '../index.js'

function fakeContext() {
  const tools = []
  const commands = []
  return {
    tools,
    commands,
    ctx: {
      tools: { register(tool) { tools.push(tool) } },
      inject(services, callback) {
        if (services.includes('commands')) {
          callback({ commands: { register(command) { commands.push(command) } } })
        }
      },
    },
  }
}

function registeredTools() {
  const { ctx, tools } = fakeContext()
  apply(ctx, { profile: 'web' })
  return Object.fromEntries(tools.map((tool) => [tool.name, tool]))
}

test('plugin exposes the schemas dsh compiles them into', () => {
  const tools = registeredTools()

  assert.deepEqual(Object.keys(tools), ['mcp_list', 'mcp_add', 'mcp_remove', 'mcp_test', 'mcp_import'])
  for (const tool of Object.values(tools)) {
    assert.equal(tool.parameters.type, 'object')
    assert.equal(tool.output.schema.type, 'string')
    for (const property of Object.values(tool.parameters.properties)) {
      assert.equal(Object.hasOwn(property, 'required'), false)
    }
    // dsh deliberately leaves the top-level parameter object open — it does not
    // emit `additionalProperties`, so stray keys from the model are tolerated.
    assert.equal(Object.hasOwn(tool.parameters, 'additionalProperties'), false)
  }
  assert.deepEqual(tools.mcp_add.parameters.required, ['serverName', 'transport'])
  assert.deepEqual(tools.mcp_remove.parameters.required, ['serverName'])
  assert.deepEqual(tools.mcp_test.parameters.required, ['serverName'])
})

test('every plugin tool rejects arguments outside its declared schema', async (t) => {
  const tools = registeredTools()
  const invalidCalls = [
    ['mcp_list rejects non-object arguments', tools.mcp_list, []],
    ['mcp_add rejects missing required properties', tools.mcp_add, { transport: 'invalid', skipTest: true }],
    ['mcp_add rejects wrong primitive types', tools.mcp_add, { serverName: 1, transport: 'invalid', skipTest: true }],
    ['mcp_add rejects wrong array types', tools.mcp_add, { serverName: 'demo', transport: 'invalid', skipTest: true, args: {} }],
    ['mcp_add validates array item types', tools.mcp_add, { serverName: 'demo', transport: 'invalid', skipTest: true, args: [1] }],
    ['mcp_add rejects wrong object types', tools.mcp_add, { serverName: 'demo', transport: 'invalid', skipTest: true, env: [] }],
    ['mcp_add rejects wrong boolean types', tools.mcp_add, { serverName: 'demo', transport: 'invalid', skipTest: 'yes' }],
    ['mcp_remove rejects missing required properties', tools.mcp_remove, {}],
    ['mcp_import rejects non-object arguments', tools.mcp_import, null],
  ]

  for (const [name, tool, args] of invalidCalls) {
    await t.test(name, async () => {
      await assert.rejects(
        tool.execute(args),
        (error) => error?.name === 'ToolArgsError' && /invalid arguments/i.test(error.message),
      )
    })
  }
})

test('env and headers accept arbitrary key/value maps', async () => {
  const tools = registeredTools()

  // additionalProperties: true — validation must let these through and fail
  // later, on the unknown transport, inside the implementation.
  await assert.rejects(
    tools.mcp_add.execute({
      serverName: 'demo',
      transport: 'invalid',
      skipTest: true,
      env: { TOKEN: 'literal', REF: '$SOME_VAR' },
      headers: { Authorization: '$SOME_TOKEN' },
    }),
    (error) => error?.name !== 'ToolArgsError' && /transport/.test(error.message),
  )
})

test('schema-valid arguments still reach the plugin implementations', async () => {
  const tools = registeredTools()
  const previousDshHome = process.env.DSH_HOME
  process.env.DSH_HOME = join(tmpdir(), `dshx-plugin-load-${process.pid}-${Date.now()}`)

  try {
    assert.match(await tools.mcp_list.execute({}), /no managed servers/)
    assert.match(await tools.mcp_test.execute({ serverName: 'demo' }), /unknown server "demo"/)
    await assert.rejects(
      tools.mcp_add.execute({ serverName: 'demo', transport: 'invalid', skipTest: true }),
      (error) => error?.name !== 'ToolArgsError' && /transport/.test(error.message),
    )
    await assert.rejects(
      tools.mcp_remove.execute({ serverName: 'demo' }),
      (error) => error?.name !== 'ToolArgsError' && /cordis\.patch\.yml/.test(error.message),
    )
    assert.equal(typeof await tools.mcp_import.execute({ write: false }), 'string')
  } finally {
    if (previousDshHome === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = previousDshHome
  }
})

test('plugin registers a human-facing /mcp command', () => {
  const { ctx, commands } = fakeContext()

  apply(ctx, { profile: 'web' })

  assert.equal(commands.length, 1)
  assert.equal(commands[0].name, 'mcp')
})
