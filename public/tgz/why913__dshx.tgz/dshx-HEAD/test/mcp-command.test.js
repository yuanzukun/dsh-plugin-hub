import test from 'node:test'
import assert from 'node:assert/strict'

import { createMcpCommandDefinition } from '../lib/mcp-command.js'

const servers = [
  { serverName: 'github', transport: 'streamable-http', url: 'https://example.test/mcp' },
  { serverName: 'empty', transport: 'stdio', command: 'empty-server', args: [] },
  { serverName: 'broken', transport: 'stdio', command: 'broken-server', args: [] },
]

function dependencies() {
  return {
    listServers: async () => ({ file: 'cordis.patch.yml', servers }),
    testServer: async (server) => {
      if (server.serverName === 'github') return { ok: true, elapsedMs: 42, tools: ['issues_list', 'pulls_get'] }
      if (server.serverName === 'empty') return { ok: true, elapsedMs: 7, tools: [] }
      return { ok: false, elapsedMs: 19, error: 'spawn ENOENT' }
    },
  }
}

test('bare /mcp reports every server status and tool count', async () => {
  const command = createMcpCommandDefinition({ profile: 'web' }, dependencies())

  const result = await command.handler({ rawInput: '', signal: AbortSignal.timeout(1000) })

  assert.equal(result.kind, 'success')
  assert.match(result.text, /github.*connected.*2 tools/i)
  assert.match(result.text, /empty.*connected.*0 tools/i)
  assert.match(result.text, /broken.*failed.*spawn ENOENT/i)
})

test('/mcp <server> reports the server tools', async () => {
  const command = createMcpCommandDefinition({ profile: 'web' }, dependencies())

  const result = await command.handler({ rawInput: 'github', signal: AbortSignal.timeout(1000) })

  assert.equal(result.kind, 'success')
  assert.match(result.text, /github.*connected/i)
  assert.match(result.text, /issues_list/)
  assert.match(result.text, /pulls_get/)
})

test('/mcp <unknown> returns a command error', async () => {
  const command = createMcpCommandDefinition({ profile: 'web' }, dependencies())

  const result = await command.handler({ rawInput: 'missing', signal: AbortSignal.timeout(1000) })

  assert.equal(result.kind, 'error')
  assert.match(result.text, /unknown MCP server "missing"/i)
})

test('/mcp <unknown> remains an unknown-server error when no servers are configured', async () => {
  const command = createMcpCommandDefinition({ profile: 'web' }, {
    ...dependencies(),
    listServers: async () => ({ file: 'cordis.patch.yml', servers: [] }),
  })

  const result = await command.handler({ rawInput: 'missing', signal: AbortSignal.timeout(1000) })

  assert.equal(result.kind, 'error')
  assert.match(result.text, /unknown MCP server "missing"/i)
})

test('bare /mcp isolates one rejected diagnostic and reports every server', async () => {
  const command = createMcpCommandDefinition({ profile: 'web' }, {
    listServers: async () => ({
      file: 'cordis.patch.yml',
      servers: [servers[0], servers[2]],
    }),
    testServer: async (server) => {
      if (server.serverName === 'broken') throw new Error('diagnostic exploded')
      return { ok: true, elapsedMs: 42, tools: ['issues_list'] }
    },
  })

  const result = await command.handler({ rawInput: '', signal: AbortSignal.timeout(1000) })

  assert.equal(result.kind, 'success')
  assert.match(result.text, /github.*connected/i)
  assert.match(result.text, /broken.*failed.*diagnostic exploded/i)
  assert.match(result.text, /1\/2 connected/i)
})

test('/mcp help documents both the slash subcommands and the CLI', async () => {
  const command = createMcpCommandDefinition({ profile: 'web' }, dependencies())

  const result = await command.handler({ rawInput: 'help', signal: AbortSignal.timeout(1000) })

  assert.equal(result.kind, 'success')
  assert.match(result.text, /\/mcp import/)
  assert.match(result.text, /dshx mcp add/)
})

// --- /mcp import -----------------------------------------------------------
// `servers` above already manages github, so it is the already-managed row.

const discovered = [
  { serverName: 'github', transport: 'streamable-http', url: 'https://example.test/mcp', source: 'claude-user' },
  { serverName: 'slack', transport: 'stdio', command: 'npx', args: ['-y', 'slack-mcp'], source: 'claude-user' },
  { serverName: 'obsidian', transport: 'stdio', command: 'uvx', args: ['mcp-obsidian'], source: 'codex' },
]

/** Import deps plus the list of serverNames that reached addServer. */
function importDependencies(overrides = {}) {
  const written = []
  return {
    written,
    deps: {
      listServers: async () => ({ file: 'cordis.patch.yml', servers }),
      testServer: async (server) => (server.serverName === 'slack'
        ? { ok: false, elapsedMs: 19, error: 'spawn ENOENT' }
        : { ok: true, elapsedMs: 42, tools: ['do_thing'] }),
      importAll: async () => ({ merged: discovered }),
      addServer: async (server) => { written.push(server.serverName) },
      ...overrides,
    },
  }
}

test('/mcp import previews candidates and marks the already-managed ones', async () => {
  const { deps, written } = importDependencies()
  const command = createMcpCommandDefinition({ profile: 'web' }, deps)

  const result = await command.handler({ rawInput: 'import' })

  assert.equal(result.kind, 'success')
  assert.match(result.text, /MCP import · 2 available · 1 already managed/)
  assert.match(result.text, /\+ slack — claude-user · stdio · npx -y slack-mcp/)
  assert.match(result.text, /\+ obsidian — codex · stdio · uvx mcp-obsidian/)
  assert.match(result.text, /= github — already managed/)
  assert.deepEqual(written, [], 'a preview must not write anything')
})

test('/mcp import <server> connection-tests it and then writes it', async () => {
  const { deps, written } = importDependencies()
  const command = createMcpCommandDefinition({ profile: 'web' }, deps)

  const result = await command.handler({ rawInput: 'import obsidian' })

  assert.equal(result.kind, 'success')
  assert.match(result.text, /MCP import · 1 written · 0 skipped/)
  assert.match(result.text, /✓ obsidian — connected · 1 tool · 42ms/)
  assert.match(result.text, /^! /m, 'a write must carry the reload note')
  assert.deepEqual(written, ['obsidian'])
})

test('/mcp import <server> refuses to write an unreachable server', async () => {
  const { deps, written } = importDependencies()
  const command = createMcpCommandDefinition({ profile: 'web' }, deps)

  const result = await command.handler({ rawInput: 'import slack' })

  assert.equal(result.kind, 'error')
  assert.match(result.text, /MCP import · 0 written · 1 skipped/)
  assert.match(result.text, /✗ slack — failed · 19ms · spawn ENOENT/)
  assert.doesNotMatch(result.text, /^! /m, 'nothing was written, so no reload note')
  assert.deepEqual(written, [])
})

test('/mcp import all writes the reachable candidates and reports the skips', async () => {
  const { deps, written } = importDependencies()
  const command = createMcpCommandDefinition({ profile: 'web' }, deps)

  const result = await command.handler({ rawInput: 'import all' })

  assert.equal(result.kind, 'success')
  assert.match(result.text, /MCP import · 1 written · 1 skipped/)
  assert.deepEqual(written, ['obsidian'], 'github is already managed and slack is unreachable')
})

test('/mcp import reports a failed write without claiming success', async () => {
  const { deps, written } = importDependencies({
    addServer: async () => { throw new Error('serverName "obsidian" 已存在') },
  })
  const command = createMcpCommandDefinition({ profile: 'web' }, deps)

  const result = await command.handler({ rawInput: 'import obsidian' })

  assert.equal(result.kind, 'error')
  assert.match(result.text, /0 written · 1 skipped/)
  assert.match(result.text, /✗ obsidian — failed · 42ms · serverName "obsidian" 已存在/)
  assert.deepEqual(written, [])
})

test('/mcp import <managed> and <unknown> are refused before any test runs', async () => {
  const { deps } = importDependencies()
  const command = createMcpCommandDefinition({ profile: 'web' }, deps)

  const managed = await command.handler({ rawInput: 'import github' })
  const unknown = await command.handler({ rawInput: 'import nope' })

  assert.equal(managed.kind, 'error')
  assert.match(managed.text, /already managed/)
  assert.equal(unknown.kind, 'error')
  assert.match(unknown.text, /Unknown importable server "nope"/)
})

test('/mcp import rejects extra arguments instead of guessing', async () => {
  const { deps } = importDependencies()
  const command = createMcpCommandDefinition({ profile: 'web' }, deps)

  const result = await command.handler({ rawInput: 'import obsidian slack' })

  assert.equal(result.kind, 'error')
  assert.match(result.text, /Unexpected input after import/)
})
