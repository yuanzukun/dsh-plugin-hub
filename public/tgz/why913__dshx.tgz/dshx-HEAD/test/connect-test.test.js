import test from 'node:test'
import assert from 'node:assert/strict'
import { execFile } from 'node:child_process'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { createServer } from 'node:http'
import { getEventListeners } from 'node:events'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { performance } from 'node:perf_hooks'

import { testServer } from '../lib/connect-test.js'

function runTaskkill(pid) {
  return new Promise((resolve) => {
    execFile(
      'taskkill.exe',
      ['/PID', String(pid), '/T', '/F'],
      { windowsHide: true },
      () => resolve(),
    )
  })
}

function isProcessRunning(pid) {
  try {
    process.kill(pid, 0)
    return true
  } catch {
    return false
  }
}

async function waitFor(check, timeoutMs = 2000) {
  const deadline = performance.now() + timeoutMs
  while (performance.now() < deadline) {
    if (await check()) return true
    await new Promise((resolve) => setTimeout(resolve, 20))
  }
  return false
}

async function createHangingServer(t) {
  let markRequestReceived
  let requestCount = 0
  const requestReceived = new Promise((resolve) => { markRequestReceived = resolve })
  const server = createServer((request) => {
    requestCount++
    request.resume()
    markRequestReceived()
    // Intentionally never respond: the client must cancel the request.
  })
  await new Promise((resolve, reject) => {
    server.once('error', reject)
    server.listen(0, '127.0.0.1', resolve)
  })
  t.after(async () => {
    server.closeAllConnections()
    await new Promise((resolve) => server.close(resolve))
  })
  const { port } = server.address()
  return { requestReceived, requestCount: () => requestCount, url: `http://127.0.0.1:${port}/mcp` }
}

test('testServer aborts a hanging HTTP diagnostic promptly', async (t) => {
  const hanging = await createHangingServer(t)
  const controller = new AbortController()
  const pending = testServer(
    { transport: 'streamable-http', url: hanging.url },
    { timeoutMs: 1000, signal: controller.signal },
  )

  await hanging.requestReceived
  const abortedAt = performance.now()
  controller.abort(new Error('diagnostic cancelled'))
  const result = await pending

  assert.equal(result.ok, false)
  assert.match(result.error, /diagnostic cancelled/)
  assert.ok(performance.now() - abortedAt < 300, 'abort should not wait for the timeout')
  assert.equal(getEventListeners(controller.signal, 'abort').length, 0)
})

test('testServer terminates a hanging stdio diagnostic promptly on abort', async () => {
  const controller = new AbortController()
  const pending = testServer(
    {
      transport: 'stdio',
      command: process.execPath,
      args: ['-e', 'process.stdin.resume(); setInterval(() => {}, 1000)'],
    },
    { timeoutMs: 30000, signal: controller.signal },
  )

  await new Promise((resolve) => setTimeout(resolve, 100))
  const abortedAt = performance.now()
  controller.abort(new Error('stdio diagnostic cancelled'))
  const result = await pending

  assert.equal(result.ok, false)
  assert.match(result.error, /stdio diagnostic cancelled/)
  // testServer waits for the process tree to be reaped before returning, and
  // spawning taskkill.exe costs a few hundred ms — same budget as the tree test.
  assert.ok(performance.now() - abortedAt < 1500, 'abort should not wait for the timeout')
  assert.equal(getEventListeners(controller.signal, 'abort').length, 0)
})

test('testServer abort terminates a Windows stdio wrapper and its descendant', {
  skip: process.platform !== 'win32',
}, async (t) => {
  const directory = await mkdtemp(join(tmpdir(), 'dshx-process-tree-'))
  const pidFile = join(directory, 'pids.json')
  let pids
  t.after(async () => {
    if (pids) {
      await runTaskkill(pids.wrapper)
      await runTaskkill(pids.descendant)
    }
    await rm(directory, { recursive: true, force: true })
  })

  const wrapperScript = [
    "const { spawn } = require('node:child_process')",
    "const { writeFileSync } = require('node:fs')",
    "const descendant = spawn(process.execPath, ['-e', 'setInterval(() => {}, 1000)'], { detached: true, stdio: 'ignore', windowsHide: true })",
    `writeFileSync(${JSON.stringify(pidFile)}, JSON.stringify({ wrapper: process.pid, descendant: descendant.pid }))`,
    'process.stdin.on(\'end\', () => process.exit(0))',
    'process.stdin.resume()',
    'setInterval(() => {}, 1000)',
  ].join(';')
  const controller = new AbortController()
  const pending = testServer(
    { transport: 'stdio', command: process.execPath, args: ['-e', wrapperScript] },
    { timeoutMs: 3000, signal: controller.signal },
  )

  assert.equal(await waitFor(async () => {
    try {
      pids = JSON.parse(await readFile(pidFile, 'utf8'))
      return isProcessRunning(pids.wrapper) && isProcessRunning(pids.descendant)
    } catch {
      return false
    }
  }), true, 'wrapper and descendant should both start')

  const abortedAt = performance.now()
  controller.abort(new Error('process tree cancelled'))
  const result = await pending
  const abortElapsedMs = performance.now() - abortedAt
  const treeStopped = await waitFor(
    () => !isProcessRunning(pids.wrapper) && !isProcessRunning(pids.descendant),
    1000,
  )

  assert.equal(result.ok, false)
  assert.match(result.error, /process tree cancelled/)
  assert.ok(abortElapsedMs < 1500, 'abort cleanup should remain prompt')
  assert.equal(treeStopped, true, 'wrapper and descendant should both be terminated')
})

test('testServer does not start a diagnostic for an already-aborted signal', async (t) => {
  const hanging = await createHangingServer(t)
  const signal = AbortSignal.abort(new Error('already cancelled'))

  const result = await testServer(
    { transport: 'streamable-http', url: hanging.url },
    { timeoutMs: 1000, signal },
  )
  await new Promise((resolve) => setTimeout(resolve, 50))

  assert.equal(result.ok, false)
  assert.match(result.error, /already cancelled/)
  assert.equal(hanging.requestCount(), 0)
})

test('testServer retains timeout failures for a hanging HTTP diagnostic', async (t) => {
  const hanging = await createHangingServer(t)

  const result = await testServer(
    { transport: 'streamable-http', url: hanging.url },
    { timeoutMs: 50 },
  )

  assert.equal(result.ok, false)
  assert.match(result.error, /50ms/)
})

test('testServer returns a structured failure when transport construction fails', async () => {
  const result = await testServer({ transport: 'streamable-http', url: 'not a URL' })

  assert.equal(result.ok, false)
  assert.equal(typeof result.elapsedMs, 'number')
  assert.match(result.error, /invalid url/i)
})

test('stdio diagnostics can launch a Windows cmd-shim command', {
  skip: process.platform !== 'win32',
}, async () => {
  // `npm` exists only as npm.cmd; the SDK spawns through cross-spawn, which
  // resolves it. So this must fail on the MCP handshake, never on the spawn.
  const result = await testServer(
    { transport: 'stdio', command: 'npm', args: ['-v'] },
    { timeoutMs: 2000 },
  )

  assert.equal(result.ok, false)
  assert.doesNotMatch(result.error, /ENOENT|EINVAL/)
})
