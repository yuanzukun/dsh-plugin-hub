import test from 'node:test'
import assert from 'node:assert/strict'

import { createMcpCommandDefinition } from '../lib/mcp-command.js'

/**
 * Executing the bundle must only REGISTER a factory. The ESM loader caches the
 * import, so capture that registration once and re-materialize the factory per
 * test — materialization is the part that must stay repeatable.
 */
let cachedDefinition
async function bundleDefinition() {
  if (cachedDefinition !== undefined) return cachedDefinition
  let registered
  globalThis.window = { __ModuleLoader__: { load: (definition) => { registered = definition } } }
  await import(new URL('../lib/client.js', import.meta.url).href)
  delete globalThis.window

  assert.equal(registered?.id, '@why913/dshx', 'bundle must register under the package id')
  assert.equal(typeof registered.factory, 'function')
  cachedDefinition = registered
  return registered
}

/**
 * Materialize the shipped client bundle through the module loader's contract:
 * the factory receives `require` and returns the plugin's exports. Loading it
 * this way tests the real artifact, wrapper included, not a copy of its innards.
 */
async function loadClient() {
  const definition = await bundleDefinition()
  const React = {
    createElement: (type, props, ...children) => ({ type, props: props ?? {}, children: children.flat() }),
    useState: (initial) => [initial, () => {}],
  }
  const require = (specifier) => {
    if (specifier === 'react') return React
    throw new Error(`unexpected require(${specifier})`)
  }
  return definition.factory(require)
}

/** The registered command-row component, wired to a recording remote. */
async function loadCard() {
  const client = await loadClient()
  let component
  const executed = []
  client.apply({
    slots: { inject: (_name, run) => run(), register: (_spec, view) => { component = view } },
    remote: { commands: { execute: (sessionId, line) => { executed.push(line); return { ok: true } } } },
  })
  return { ...client, component, executed }
}

/** Flatten a stub element tree into its rendered strings. */
function textOf(node) {
  if (node === null || node === undefined || typeof node === 'boolean') return []
  if (typeof node !== 'object') return [String(node)]
  return node.children.flatMap(textOf)
}

/** Collect every element whose type is `type`. */
function findAll(node, type) {
  if (node === null || typeof node !== 'object') return []
  const here = node.type === type ? [node] : []
  return [...here, ...node.children.flatMap((child) => findAll(child, type))]
}

/** Run the real /mcp handler so the parser is fed the real text format. */
async function runCommand(rawInput, dependencies) {
  const definition = createMcpCommandDefinition({ profile: 'web' }, dependencies)
  return definition.handler({ rawInput })
}

const TWO_SERVERS = [
  { serverName: 'codex', transport: 'stdio' },
  { serverName: 'node_repl', transport: 'stdio' },
]
const statusDeps = (servers, results) => ({
  listServers: async () => ({ servers }),
  testServer: async (server) => results[server.serverName],
})
const TWO_RESULTS = {
  codex: { ok: true, elapsedMs: 342, tools: ['read', 'write'] },
  node_repl: { ok: false, elapsedMs: 60, error: 'MCP error -32000: Connection closed' },
}
const status = (rawInput, servers = TWO_SERVERS, results = TWO_RESULTS) =>
  runCommand(rawInput, statusDeps(servers, results)).then((result) => result.text)

const DISCOVERED = [
  { serverName: 'github', transport: 'streamable-http', url: 'https://example.test/mcp', source: 'claude-user' },
  { serverName: 'slack', transport: 'stdio', command: 'npx', args: ['-y', 'slack-mcp'], source: 'claude-user' },
]
const importDeps = () => ({
  listServers: async () => ({ servers: [{ serverName: 'github', transport: 'streamable-http' }] }),
  testServer: async () => ({ ok: true, elapsedMs: 88, tools: ['post_message'] }),
  importAll: async () => ({ merged: DISCOVERED }),
  addServer: async () => {},
})

test('client parses the all-servers text the command actually writes', async () => {
  const { parseReport } = await loadClient()

  const parsed = parseReport(await status(''))

  assert.equal(parsed.header.label, 'MCP 服务器 · 1/2 连通')
  assert.deepEqual(parsed.header.action, { label: '全部重测', line: '/mcp' })
  assert.deepEqual(parsed.items, [
    { glyph: '✓', name: 'codex', meta: '2 tools · 342ms', action: { label: '重测', line: '/mcp codex' } },
    {
      glyph: '✗',
      name: 'node_repl',
      meta: '连接失败 · 60ms',
      error: 'MCP error -32000: Connection closed',
      action: { label: '重测', line: '/mcp node_repl' },
    },
  ])
  assert.deepEqual(parsed.tools, [])
  assert.equal(parsed.note, null)
})

test('client parses the single-server text and its tool names', async () => {
  const { parseReport } = await loadClient()
  const servers = [{ serverName: 'codegraph', transport: 'stdio' }]
  const results = { codegraph: { ok: true, elapsedMs: 275, tools: ['codegraph_explore'] } }

  const parsed = parseReport(await status('codegraph', servers, results))

  assert.deepEqual(parsed.items, [
    { glyph: '✓', name: 'codegraph', meta: '1 tool · 275ms', action: { label: '重测', line: '/mcp codegraph' } },
  ])
  assert.deepEqual(parsed.tools, ['codegraph_explore'])
  assert.equal(parsed.header, null)
})

test('client flags an empty-tool server without calling it a failure', async () => {
  const { parseReport } = await loadClient()
  const servers = [{ serverName: 'empty', transport: 'stdio' }]
  const results = { empty: { ok: true, elapsedMs: 12, tools: [] } }

  const parsed = parseReport(await status('', servers, results))

  assert.equal(parsed.items[0].glyph, '⚠')
  assert.equal(parsed.items[0].meta, '0 tools · 12ms')
})

test('client declines to parse help output', async () => {
  const { parseReport } = await loadClient()

  const help = await status('help')

  assert.equal(parseReport(help), null, 'help text must fall through to verbatim rendering')
})

test('client registers the mcp command-row seat and names its services', async () => {
  const { inject } = await loadClient()
  assert.deepEqual(inject, ['slots', 'remote', 'remote.commands'])

  const client = await loadClient()
  const registered = []
  const executed = []
  client.apply({
    slots: {
      inject: (_name, run) => run(),
      register: (spec, component) => registered.push({ spec, component }),
    },
    remote: { commands: { execute: (sessionId, line) => { executed.push({ sessionId, line }); return { ok: true } } } },
  })

  assert.equal(registered.length, 1)
  assert.equal(registered[0].spec.name, 'conversation.chat.commandview')
  assert.equal(registered[0].spec.key, 'mcp')

  // The injected face is the component's only route to the host.
  registered[0].spec.inject('session-1').rerun('/mcp codex')
  assert.deepEqual(executed, [{ sessionId: 'session-1', line: '/mcp codex' }])
})

test('command row renders a button per server plus a recheck-all button', async () => {
  const { component } = await loadCard()

  const tree = component({ node: { outcome: { kind: 'success', text: await status('') } } })
  const rendered = textOf(tree).join(' ')
  const buttons = findAll(tree, 'button')

  assert.match(rendered, /MCP 服务器 · 1\/2 连通/)
  assert.match(rendered, /Connection closed/)
  assert.deepEqual(buttons.map((button) => textOf(button).join('')), ['全部重测', '重测', '重测'])
  assert.ok(buttons.every((button) => button.props.disabled === false))
})

test('command row shows progress while the command is still running', async () => {
  const { component } = await loadCard()

  assert.deepEqual(textOf(component({ node: { outcome: null } })), ['执行中…'])
})

test('command row draws the card for a one-server check that failed', async () => {
  const { component } = await loadCard()

  // A failing single-server check settles as kind 'error', but its text is a
  // row — the row a user clicking 重测 on a broken server most wants drawn.
  const servers = [{ serverName: 'node_repl', transport: 'stdio' }]
  const results = { node_repl: { ok: false, elapsedMs: 35, error: 'MCP error -32000: Connection closed' } }
  const text = await status('node_repl', servers, results)
  const tree = component({ node: { outcome: { kind: 'error', text } } })

  assert.equal(tree.props.className, 'dshx_card', 'must render the card, not verbatim text')
  assert.match(textOf(tree).join(' '), /连接失败 · 35ms/)
  assert.deepEqual(findAll(tree, 'button').map((button) => textOf(button).join('')), ['重测'])
})

test('command row renders a failed outcome verbatim', async () => {
  const { component } = await loadCard()

  const node = { outcome: { kind: 'error', text: 'Unknown MCP server "nope".' } }

  assert.deepEqual(textOf(component({ node })), ['Unknown MCP server "nope".'])
})

test('client parses the import preview into candidate rows', async () => {
  const { parseReport } = await loadClient()

  const preview = await runCommand('import', importDeps())
  const parsed = parseReport(preview.text)

  assert.equal(parsed.header.label, '可迁移 1 个 · 已管理 1 个')
  assert.deepEqual(parsed.header.action, { label: '全部迁移', line: '/mcp import all' })
  assert.deepEqual(parsed.items, [
    {
      glyph: '+',
      name: 'slack',
      meta: 'claude-user · stdio · npx -y slack-mcp',
      action: { label: '迁移', line: '/mcp import slack' },
    },
    { glyph: '=', name: 'github', meta: '已管理' },
  ])
})

test('import card offers a migrate button per candidate and none for managed rows', async () => {
  const { component } = await loadCard()

  const preview = await runCommand('import', importDeps())
  const tree = component({ node: { outcome: { kind: 'success', text: preview.text } } })
  const rendered = textOf(tree).join(' ')

  assert.match(rendered, /可迁移 1 个 · 已管理 1 个/)
  assert.match(rendered, /npx -y slack-mcp/)
  assert.match(rendered, /已管理/)
  assert.deepEqual(findAll(tree, 'button').map((button) => textOf(button).join('')), ['全部迁移', '迁移'])
})

test('client parses an import result and keeps its reload note', async () => {
  const { parseReport } = await loadClient()

  const written = await runCommand('import slack', importDeps())
  const parsed = parseReport(written.text)

  assert.equal(parsed.header.label, '已写入 1 个 · 跳过 0 个')
  assert.equal(parsed.header.action, null, 'a settled write offers no all-button')
  assert.deepEqual(parsed.items, [
    { glyph: '✓', name: 'slack', meta: '1 tool · 88ms', action: { label: '重测', line: '/mcp slack' } },
  ])
  assert.match(parsed.note, /重启 dsh/)
})

test('import result card surfaces the reload note to the reader', async () => {
  const { component } = await loadCard()

  const written = await runCommand('import slack', importDeps())
  const tree = component({ node: { outcome: { kind: 'success', text: written.text } } })

  assert.match(textOf(tree).join(' '), /重启 dsh 或重载 profile 后生效/)
})

test('import preview with nothing left to migrate drops the all-button', async () => {
  const { parseReport } = await loadClient()

  const preview = await runCommand('import', {
    ...importDeps(),
    listServers: async () => ({ servers: DISCOVERED.map((s) => ({ serverName: s.serverName })) }),
  })
  const parsed = parseReport(preview.text)

  assert.equal(parsed.header.label, '可迁移 0 个 · 已管理 2 个')
  assert.equal(parsed.header.action, null)
  assert.ok(parsed.items.every((item) => item.action === undefined), 'managed rows carry no button')
})
