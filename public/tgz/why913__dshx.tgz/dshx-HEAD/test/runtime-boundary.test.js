import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

const projectRoot = new URL('../', import.meta.url)

test('dsh-tools is a peer dependency, never bundled into the profile', async () => {
  const packageJson = JSON.parse(await readFile(new URL('package.json', projectRoot), 'utf8'))
  const entrySource = await readFile(new URL('index.js', projectRoot), 'utf8')

  // dsh-tools keys its registry and scheduler off unique Symbol(...)s, so a
  // second copy installed under the profile would be invisible to the host.
  // Peer-declaring it is how dsh's own plugins (dsh-agent, dsh-llm, ...) do it.
  assert.equal(
    packageJson.dependencies?.['@deepseek-ai/dsh-tools'],
    undefined,
    '@deepseek-ai/dsh-tools must be supplied by the dsh host, not installed inside the profile',
  )
  assert.equal(packageJson.peerDependencies?.['@deepseek-ai/dsh-tools'], '^0.1.0-rc.6')
  assert.match(entrySource, /from\s+['"]@deepseek-ai\/dsh-tools['"]/)
})

test('stdio diagnostics do not pass the SDK an ignored shell option', async () => {
  const source = await readFile(new URL('lib/connect-test.js', projectRoot), 'utf8')

  assert.doesNotMatch(source, /\bshell\s*:/)
})
