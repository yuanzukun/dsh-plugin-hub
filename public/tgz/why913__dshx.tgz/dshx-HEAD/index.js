/**
 * dsh-mcp as a dsh plugin: model-facing tools so the agent itself can manage
 * MCP servers on request ("帮我接一下 xxx") — with the same dry-run test and
 * idempotency as the CLI. Config changes take effect on the next dsh reload;
 * the tools say so in their results instead of restarting anything.
 *
 * dsh-tools is a peerDependency, never a dependency: it keys its tool registry
 * and scheduler off unique `Symbol(...)`s, so a second copy installed inside a
 * profile would hand the agent loop symbols the host does not recognise.
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import Schema from '@deepseek-ai/schemastery'
import { addServer, listServers, removeServer } from './lib/core.js'
import { testServer } from './lib/connect-test.js'
import { importAll } from './lib/import.js'
import { createMcpCommandDefinition } from './lib/mcp-command.js'

export const name = 'dshx'
export const inject = ['tools']

export const Config = Schema.object({
  profile: Schema.string().default('web').description('Profile whose cordis.patch.yml the tools write to'),
  global: Schema.boolean().default(false).description('Write to $DSH_HOME/cordis.patch.yml instead of a profile'),
})

export function apply(ctx, config) {
  const scope = { profile: config?.profile ?? 'web', global: config?.global ?? false }
  const note = '配置已写入；重启 dsh 或重载 profile 后生效。'

  const text = (value) => [{ type: 'text', text: value }]

  // Human-facing slash command. Keep `commands` optional so compositions that
  // only expose model tools can still load the plugin.
  ctx.inject(['commands'], (commandCtx) => {
    commandCtx.commands.register(createMcpCommandDefinition(scope))
  })

  ctx.tools.register(defineTool({
    name: 'mcp_list',
    description: 'List MCP servers currently managed in the dsh patch config.',
    parameters: {},
    output: { schema: { type: 'string' }, render: (_a, v) => text(v) },
    async execute() {
      const { file, servers } = await listServers(scope)
      if (!servers.length) return `no managed servers in ${file}`
      return servers.map((s) => `${s.serverName} (${s.transport}) ${s.transport === 'stdio' ? [s.command, ...(s.args ?? [])].join(' ') : s.url}`).join('\n')
    },
  }))

  ctx.tools.register(defineTool({
    name: 'mcp_add',
    description: 'Add an MCP server to dsh config. Performs a dry-run connection test first and refuses to write when the server is unreachable. Env/header values of the form "$VARNAME" are stored as environment-variable references, never as literal secrets.',
    parameters: {
      serverName: { type: 'string', required: true, description: 'Namespace for tool names, [A-Za-z0-9_-]{1,32}' },
      transport: { type: 'string', required: true, description: '"stdio" or "streamable-http"' },
      command: { type: 'string', description: 'stdio only: executable to spawn' },
      args: { type: 'array', items: { type: 'string' }, description: 'stdio only: arguments' },
      url: { type: 'string', description: 'streamable-http only: server URL' },
      env: { type: 'object', additionalProperties: true, description: 'stdio env vars; "$VARNAME" values become process.env references' },
      headers: { type: 'object', additionalProperties: true, description: 'http headers; "$VARNAME" values become process.env references' },
      force: { type: 'boolean', description: 'Replace an existing server of the same name' },
      skipTest: { type: 'boolean', description: 'Write without the dry-run connection test' },
    },
    output: { schema: { type: 'string' }, render: (_a, v) => text(v) },
    async execute(args) {
      const { force, skipTest, ...server } = args
      if (!skipTest) {
        const t = await testServer(server)
        if (!t.ok) return `NOT written — connection test failed: ${t.error}`
      }
      const r = await addServer(server, { force, ...scope })
      return `${r.replaced ? 'updated' : 'added'} ${r.id} in ${r.file}. ${note}`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'mcp_remove',
    description: 'Remove a dsh-mcp-managed MCP server from dsh config by serverName.',
    parameters: {
      serverName: { type: 'string', required: true },
    },
    output: { schema: { type: 'string' }, render: (_a, v) => text(v) },
    async execute({ serverName }) {
      const r = await removeServer(serverName, scope)
      return `removed ${r.id} from ${r.file}. ${note}`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'mcp_test',
    description: 'Dry-run connection test against a managed MCP server (or an ad-hoc definition passed inline). Reports reachable tools without changing any config.',
    parameters: {
      serverName: { type: 'string', required: true, description: 'A managed server name' },
    },
    output: { schema: { type: 'string' }, render: (_a, v) => text(v) },
    async execute({ serverName }) {
      const { servers } = await listServers(scope)
      const server = servers.find((s) => s.serverName === serverName)
      if (!server) return `unknown server "${serverName}" — call mcp_list first`
      const t = await testServer(server)
      return t.ok ? `ok (${t.elapsedMs}ms): ${t.tools.length} tools — ${t.tools.join(', ')}` : `failed (${t.elapsedMs}ms): ${t.error}`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'mcp_import',
    description: 'Discover MCP servers configured for Claude Code (~/.claude.json, ./.mcp.json) and Codex (~/.codex/config.toml). With write=false (default) only reports what was found; with write=true, connection-tests each server and writes the reachable ones into dsh config.',
    parameters: {
      write: { type: 'boolean', description: 'Actually write the discovered servers (default false: report only)' },
    },
    output: { schema: { type: 'string' }, render: (_a, v) => text(v) },
    async execute({ write }) {
      const { merged } = await importAll()
      if (!merged.length) return 'no importable MCP configs found'
      if (!write) {
        return merged.map((s) => `[${s.source}] ${s.serverName} (${s.transport})`).join('\n')
          + '\n\ncall again with write=true to migrate (each server is connection-tested first)'
      }
      const lines = []
      for (const s of merged) {
        const t = await testServer(s)
        if (!t.ok) { lines.push(`${s.serverName}: skipped (${t.error})`); continue }
        try {
          const r = await addServer(s, scope)
          lines.push(`${s.serverName}: ${r.replaced ? 'updated' : 'added'}`)
        } catch (e) {
          lines.push(`${s.serverName}: skipped (${e.message})`)
        }
      }
      return lines.join('\n') + `\n${note}`
    },
  }))
}
