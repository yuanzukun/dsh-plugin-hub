---
name: dshx
description: Companion CLI for DeepSeek Harness. Manage MCP servers (add/list/remove/test with dry-run connection checks), manage skills (install from GitHub with update tracking), and migrate MCP servers, skills, and global memory from the user's Claude Code / Codex setup. Use when the user asks to add, remove, inspect, migrate, or debug MCP servers/tools, install or update skills, or bring their Claude Code / Codex configuration over to dsh.
---

# dshx — the companion CLI for dsh

dshx safely edits dsh's config surfaces (comment-preserving, idempotent,
secret-safe) so you never hand-edit YAML or copy directories around. Prefer it
over editing config files directly.

Run it through the shell tool:

```sh
dshx <group> <verb> ...
# if not on PATH, try: npx -y @why913/dshx <group> <verb> ...
```

## MCP servers

| Command | What it does |
|---|---|
| `dshx mcp list` | List managed MCP servers in the current profile |
| `dshx mcp add <name> -- <cmd> [args...]` | Add a local stdio server; **connection-tested before writing** — if unreachable, nothing is written |
| `dshx mcp add --transport http <name> <url> [--header 'K: V']` | Add a remote streamable-http server |
| `dshx mcp rm <name>` | Remove a managed server |
| `dshx mcp test <name>` | Dry-run handshake + tool listing, no config change |
| `dshx mcp import [--yes]` | Discover servers in Claude Code / Codex configs and migrate the reachable ones |

## Skills

| Command | What it does |
|---|---|
| `dshx skill list` | List skills in `~/.dsh/skills` with validity checks and provenance |
| `dshx skill add <owner/repo[/subdir] \| local path>` | Install a SKILL.md package (validated first; source + commit recorded) |
| `dshx skill rm <name>` | Remove a dshx-installed skill |
| `dshx skill update <name>` | Re-fetch from the recorded source when upstream moved |
| `dshx skill import [--yes]` | Migrate skills from `~/.claude/skills` / `./.claude/skills` |

The skills directory is hot-watched by dsh — installs take effect immediately,
no restart.

## Memory

| Command | What it does |
|---|---|
| `dshx memory import [--yes]` | Migrate `~/.claude/CLAUDE.md` and `~/.codex/AGENTS.md` into `$DSH_HOME/AGENTS.md`, inside labelled marker blocks (idempotent; re-running updates only its own blocks) |

Project-level CLAUDE.md needs no migration — dsh reads it natively.

## Rules

- Secrets: pass env/header values as `$VARNAME` (e.g. `--env KEY=$MY_KEY`);
  dshx writes them as `!!js process.env.VARNAME` references so no secret lands
  in the config file. Never inline a literal API key unless the user insists.
- MCP changes take effect after dsh restarts or reloads the profile; skills
  take effect immediately. Say which after acting; do not restart anything.
- A failed `add` connection test means the server itself is broken or
  unreachable — report the error instead of retrying with `--no-test`, unless
  the user explicitly wants it written anyway.
- Verify with `dshx mcp list` / `dshx skill list`, or
  `npx @deepseek-ai/dsh --profile <name> --dump-config` for the full composition.
