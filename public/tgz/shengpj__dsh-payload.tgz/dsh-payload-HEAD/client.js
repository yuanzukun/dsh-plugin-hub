/**
 * Payload Inspector — a Client-half plugin that adds one icon button to the
 * per-message action row under every finalized assistant reply (next to the
 * shipped copy / good / bad actions), and shows the full request payload the
 * model call that produced that reply was built from:
 *
 *   { model, provider, <call controls>, messages: [...], tools: [...] }
 *
 * Everything is read from the session event log that the Web GUI already holds
 * (`request/header` carries the epoch config + tool schemas, surface events carry
 * the messages). Nothing is re-sent and nothing is folded eagerly: the read
 * happens once, on the click, and is cached for the lifetime of that dialog.
 */

window.__ModuleLoader__.load({
  id: 'dsh-payload',
  factory(require) {
    const React = require('react');
    const h = React.createElement;

    /* Shown in the dialog header and logged on load. "Did the new build actually
       load, or is the browser still running last week's bundle?" has cost real
       rounds of debugging, so the answer is on screen. Keep in sync with
       package.json. */
    const VERSION = '1.10.3';

    /** Surface event type -> the role that event contributes to the model request. */
    const SURFACE_ROLES = {
      'system/message': 'system',
      'developer/message': 'developer',
      'user/message': 'user',
      'assistant/message': 'assistant',
      'tool/result': 'tool',
    };

    const ZH = typeof navigator !== 'undefined' && /^zh/i.test(navigator.language || '');
    const TEXT = ZH
      ? {
          show: '查看请求 / 响应',
          copy: '复制',
          copied: '已复制',
          loading: '正在读取本轮请求…',
          /* No live seconds: the read and the rebuild hold the main thread, so a
             printed number can only stand still while the app is busy — and a number
             that stands still is read as a bug. Liveness comes from the spinner. */
          readingHistory: '正在读取这段对话的历史…',
          rebuilding: '历史已读入，正在重建这一轮…',
          rebuildingProgress: (done, total) => '历史已读入，正在重建这一轮（' + done + '/' + total + ' 次调用）…',
          empty: '这一轮没有记录到模型调用。',
          error: '读取失败：',
          title: '本轮这次调用的请求与回复',
          messages: '条消息',
          tools: '个工具',
          copyAll: '复制全部调用',
          usageInput: '输入',
          usageCache: '缓存',
          usageOutput: '输出',
          usageTotal: '合计',
          turnTotal: '本轮合计',
          usageNone: '未记录到用量',
          usageInputTitle:
            '未命中前缀缓存的 prompt tokens。真正的 prompt 总量 = 输入 + 缓存，不是这份 JSON 的字节数。',
          usageCacheTitle:
            '命中前缀缓存、无需重新计费的 prompt tokens（括号内是命中率）。与「输入」相加才是完整 prompt。',
          usageOutputTitle: '模型本次生成的 tokens。',
          usageTotalTitle: '本次调用 tokens 合计 = 输入 + 缓存 + 输出，按这个数计费。',
          turnTotalTitle: '本轮（Turn）所有调用累加，含每一次工具往返。',
          bytesLabel: '请求体',
          bytesTitle:
            '这份重建结果 JSON.stringify 后的字节数。字节 ≠ token（中文约 1 token ≈ 1–2 字节），也不等于模型实际收到的量。',
          messagesTitle:
            '会话日志里这次请求携带的历史条数。实际发出的内容会先经上下文压缩，故条数通常大于模型真正读到的量。',
          compressNote:
            '条数与「请求体」来自会话日志；实际发出的内容会先经上下文压缩折叠，token 用量以「输入 + 缓存」为准。',
          history: '历史',
          currentTurn: '本轮',
          historyGroup: '历史消息',
          folded: '已折叠',
          historyTitle:
            '这些消息产生于更早的轮次，默认折叠；展开后仍是数组里的真实下标。',
          currentTitle: '本轮对话（含本轮注入的上下文与工具往返）新产生的消息。',
          callPrefix: '第 ',
          callSuffix: ' 次调用',
          callsShort: '次调用',
          reasonLabel: '触发原因',
          jump: '对话',
          jumpTitle: '跳到这条消息在对话里的位置',
    /* Tool round-trips: status badge on a `tool_calls` row, and the labels
       inside its unfolded body. */
    toolOk: '成功',
    toolError: '失败',
    toolMissing: '未返回',
    toolBadgeTitle: '点击展开这次工具调用的参数和返回',
    toolArguments: '参数',
    toolResult: '结果',
    toolNoResult: '（这一轮里没有找到对应的返回记录）',
          expandAll: '展开全部',
          collapseAll: '折叠全部',
          expand: '展开这一条',
          collapse: '折叠这一条',
          toTop: '顶部',
          toEnd: '末尾',
          railTitle: '拖动滚动条可直达任意位置',
          close: '关闭',
          sourceTitle:
            '这份请求由什么组成：你输入的话、harness 自动注入的上下文、模型回复、工具往返。占比是"消息字节"占比，非 token。',
          sourceFamilyPrompt: '你的输入',
          sourceFamilyInjected: '自动注入',
          sourceFamilyModel: '模型回复',
          sourceFamilyTool: '工具往返',
          sourceFamilyOther: '其他',
          sourceFresh: '本轮新增',
          sourceFreshTitle: '其中由本轮写进请求的部分（其余是历史携带）。',
          sourceKindUser: '用户消息',
          sourceKindApproval: '审批交互',
          sourceKindTimeContext: '时间上下文',
          sourceKindRuntimeContext: '运行时上下文',
          sourceKindSkillCatalog: '技能目录',
          sourceKindModelSelection: '模型选择',
          sourceKindSystemPrompt: '系统提示词',
          sourceKindToolRegistry: '工具登记',
          sourceKindModel: '模型回复',
          sourceKindTool: '工具结果',
          sourceKindJobReport: '后台任务回报',
          sourceKindOther: '未标注来源',
          diffAdded: '新增',
          diffRemoved: '消失',
          diffRewritten: '原地改写',
          diffChanged: '参数变化',
          diffBoundary: '上一次调用已有',
          diffBoundaryTail: '以下为本次新增',
          diffTools: '个工具',
          timelineTitle: '本轮各步',
          timelineHint: '每段是一步，宽度按该步消耗的 token；点一段切到那次调用',
          timelineSelected: '当前',
          stepWord: 'step',
          tokens: 'token',
          noUsage: '无用量',
          /* 响应侧：这一屏回答"模型回了什么"，与请求侧一一对应。 */
          viewRequest: '请求',
          viewResponse: '响应',
          responseNone: '日志里没有这次调用的回复记录（可能被中断或仍在流式返回）。',
          finishLabel: '结束原因',
          finishStop: '正常结束',
          finishToolCalls: '要求调用工具',
          finishLength: '达到输出上限',
          finishAborted: '被中断',
          finishError: '失败',
          finishUnknown: '未知',
          finishTitle: '模型为什么停下：日志里 finish 分块记录的 reason。',
          responseFirst: '首字节',
          responseFirstTitle:
            '从这一步开始，到收到第一个响应分块的耗时。含准备请求的时间，不等于网络往返。',
          responseSpan: '总时长',
          responseSpanTitle: '第一个响应分块到最后一个响应分块之间的耗时。',
          responseOutChars: '输出字符',
          responseOutCharsTitle: '回复正文的字符数（不含工具参数与推理）。',
          responseReasoning: '推理字符',
          responseReasoningTitle: '推理内容（reasoning）的字符数。',
          responseBytesLabel: '响应体',
          attemptsLabel: '重试',
          attemptsTitle: '同一步里失败的尝试；每一次都以一个 finish 分块结束，成功的那次不算在内。',
          attemptNo: '尝试 ',
          responseShapeTitle: '这一屏按 OpenAI chat-completion 的形态重建了响应，方便直接复制。',
        }
      : {
          show: 'Request / response',
          copy: 'Copy',
          copied: 'Copied',
          loading: 'Reading this turn’s request…',
          /* No live seconds: see the Chinese note — a number cannot be repainted
             while the work it is counting blocks the thread. */
          readingHistory: 'Reading this conversation’s history…',
          rebuilding: 'History loaded — rebuilding this turn…',
          rebuildingProgress: (done, total) =>
            'History loaded — rebuilding this turn (' + done + '/' + total + ' calls)…',
          empty: 'No model call recorded for this turn.',
          error: 'Read failed: ',
          title: 'Request and reply for this call',
          messages: 'messages',
          tools: 'tools',
          copyAll: 'Copy all calls',
          usageInput: 'input',
          usageCache: 'cached',
          usageOutput: 'output',
          usageTotal: 'total',
          turnTotal: 'turn total',
          usageNone: 'no usage recorded',
          usageInputTitle:
            'Prompt tokens that missed the prefix cache. The full prompt is input + cached; it is not the byte size of this JSON.',
          usageCacheTitle:
            'Prompt tokens served from the prefix cache (share in brackets). input + cached is the full prompt.',
          usageOutputTitle: 'Tokens generated by the model for this call.',
          usageTotalTitle: 'Call total = input + cached + output; this is what gets billed.',
          turnTotalTitle: 'Sum over every call of this turn, tool round-trips included.',
          bytesLabel: 'body',
          bytesTitle:
            'Bytes of this rebuilt JSON. Bytes are not tokens (roughly 1 token ≈ 1–2 bytes of Chinese), and this is not what the model actually received.',
          messagesTitle:
            'History entries this request carried in the session log. The request is compressed before it is sent, so this is usually larger than what the model read.',
          compressNote:
            'Counts and body size come from the session log; the payload is compressed before sending, so trust input + cached for tokens.',
          history: 'history',
          currentTurn: 'this turn',
          historyGroup: 'earlier messages',
          folded: 'folded',
          historyTitle:
            'Produced in earlier turns, folded by default; expanding keeps the real array indices.',
          currentTitle: 'Messages produced in this turn (injected context and tool round-trips included).',
          callPrefix: 'Call ',
          callSuffix: '',
          callsShort: 'calls',
          reasonLabel: 'reason',
          jump: 'Chat',
          jumpTitle: 'Jump to where this message sits in the conversation',
    toolOk: 'ok',
    toolError: 'error',
    toolMissing: 'no result',
    toolBadgeTitle: 'Expand this call’s arguments and result',
    toolArguments: 'arguments',
    toolResult: 'result',
    toolNoResult: '(no matching result recorded in this Turn)',
          expandAll: 'Expand all',
          collapseAll: 'Collapse all',
          expand: 'Expand this message',
          collapse: 'Collapse this message',
          toTop: 'Top',
          toEnd: 'End',
          railTitle: 'Drag the rail to jump anywhere in the payload',
          close: 'Close',
          sourceTitle:
            'What this request is made of: your prompt, context the Harness injected, model replies, tool round-trips. Shares are message bytes, not tokens.',
          sourceFamilyPrompt: 'your prompt',
          sourceFamilyInjected: 'injected',
          sourceFamilyModel: 'model replies',
          sourceFamilyTool: 'tool round-trips',
          sourceFamilyOther: 'other',
          sourceFresh: 'new this turn',
          sourceFreshTitle: 'The part this Turn wrote into the request; the rest is carried history.',
          sourceKindUser: 'user message',
          sourceKindApproval: 'approval',
          sourceKindTimeContext: 'time context',
          sourceKindRuntimeContext: 'runtime context',
          sourceKindSkillCatalog: 'skill catalog',
          sourceKindModelSelection: 'model selection',
          sourceKindSystemPrompt: 'system prompt',
          sourceKindToolRegistry: 'tool registry',
          sourceKindModel: 'model reply',
          sourceKindTool: 'tool result',
          sourceKindJobReport: 'job report',
          sourceKindOther: 'unlabelled',
          diffAdded: 'new',
          diffRemoved: 'gone',
          diffRewritten: 'rewritten in place',
          diffChanged: 'params changed',
          diffBoundary: 'the previous call already had',
          diffBoundaryTail: 'new in this call',
          diffTools: 'tools',
          timelineTitle: 'This Turn’s steps',
          timelineHint: 'One segment per step, width by the tokens it spent; click to switch',
          timelineSelected: 'selected',
          stepWord: 'step',
          tokens: 'tokens',
          noUsage: 'no usage',
          viewRequest: 'Request',
          viewResponse: 'Response',
          responseNone: 'No reply recorded for this call in the log (interrupted, or still streaming).',
          finishLabel: 'finish',
          finishStop: 'stopped',
          finishToolCalls: 'tool calls',
          finishLength: 'output limit',
          finishAborted: 'aborted',
          finishError: 'failed',
          finishUnknown: 'unknown',
          finishTitle: 'Why the model stopped: the finish chunk’s reason in the log.',
          responseFirst: 'first byte',
          responseFirstTitle:
            'From the start of this step to the first response chunk. Includes request preparation, so it is not a network round-trip.',
          responseSpan: 'stream time',
          responseSpanTitle: 'Between the first and the last response chunk.',
          responseOutChars: 'output chars',
          responseOutCharsTitle: 'Characters of reply text (tool arguments and reasoning excluded).',
          responseReasoning: 'reasoning chars',
          responseReasoningTitle: 'Characters of reasoning content.',
          responseBytesLabel: 'response',
          attemptsLabel: 'retries',
          attemptsTitle:
            'Failed attempts in this step; each ends with a finish chunk. The successful one is not counted.',
          attemptNo: 'attempt ',
          responseShapeTitle: 'This view rebuilds the reply in OpenAI chat-completion shape so it can be copied.',
        };

    /* Chrome text inherits the app font, so the dialog sits in the same typographic
       world as the rest of the Harness; only the payload switches to mono.

       Everything visual goes through T below. The dialog used to carry its own
       sizes (10.5 / 11 / 11.5 / 12 / 12.5 / 14 and six radii), which is exactly what
       made it read as a window from another product: the Harness ships four type
       steps, three semantic radii and hairline borders, and a neighbour speaking
       five sub-pixel sizes has no rhythm next to it. */
    const FONT_MONO =
      'ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace';

    const T = {
      /* 13/18 controls, 14/22 body, 12/18 captions, 11 micro. Nothing in between:
         half-pixel sizes blur at fractional device pixel ratios. */
      font: { micro: '11px', caption: '12px', control: '13px', body: '14px' },
      /* The design system's semantic radii, plus pills for meters and count badges.
         `xs` is only for the segments inside a pill-shaped meter. */
      radius: {
        xs: '4px',
        sm: 'var(--dsw-radius-sm, 8px)',
        lg: 'var(--dsw-radius-lg, 12px)',
        panel: 'var(--dsw-radius-panel, 16px)',
        pill: '999px',
      },
      /* Hairline chrome: the shipped dialogs and chips draw 0.5px at border-l4. A
         1px line at border-l1 is what made every control look greyed out. The nested
         fallbacks keep older themes (which publish only l1) legible. */
      hair: '0.5px solid var(--dsw-alias-border-l4, var(--dsw-alias-border-l1, rgba(127,127,127,0.28)))',
      hairDashed:
        '0.5px dashed var(--dsw-alias-border-l4, var(--dsw-alias-border-l1, rgba(127,127,127,0.28)))',
      /* Focus ring: the same token pair the shipped chips use, so the keyboard state
         follows the theme instead of a hardcoded brand blue. */
      focus:
        'var(--dsw-focus-ring-width, 2px) solid var(--dsw-focus-ring-color, var(--dsw-alias-state-business-primary, #2f6fed))',
      /* 28px is the shipped chip height; nothing interactive goes below it. */
      hit: { sm: '28px' },
    };

    const STYLE = {
      smallButton: {
        font: 'inherit',
        fontSize: T.font.control,
        lineHeight: '18px',
        fontWeight: 500,
        height: T.hit.sm,
        padding: '0 12px',
        boxSizing: 'border-box',
        borderRadius: T.radius.sm,
        cursor: 'pointer',
        border: T.hair,
        background: 'transparent',
        color: 'inherit',
        whiteSpace: 'nowrap',
        transition: 'background-color .12s ease, border-color .12s ease',
      },
      note: {
        padding: '12px 16px',
        fontSize: T.font.caption,
        lineHeight: '18px',
        color: 'var(--dsw-alias-label-secondary, #5b6472)',
      },
      /* Same voice as `note`, but a row: spinner beside the text, so the loading
         state has something that keeps moving even when text cannot be painted. */
      loadingRow: {
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        padding: '12px 16px',
        fontSize: T.font.caption,
        lineHeight: '18px',
        color: 'var(--dsw-alias-label-secondary, #5b6472)',
      },

      /* ---- modal (rendered into shell.overlay, above every column) ---- */
      backdrop: {
        position: 'fixed',
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
        zIndex: 2147483000,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '24px',
        boxSizing: 'border-box',
        background: 'rgba(0,0,0,0.28)',
        /* shell.overlay is click-through by design; the dialog opts back in. */
        pointerEvents: 'auto',
      },
      dialog: {
        display: 'flex',
        flexDirection: 'column',
        width: 'min(1040px, 96vw)',
        height: '88vh',
        maxHeight: '88vh',
        boxSizing: 'border-box',
        borderRadius: T.radius.panel,
        border: T.hair,
        background: 'var(--dsw-alias-bg-overlay, #ffffff)',
        color: 'var(--dsw-alias-label-primary, #1a1a1a)',
        boxShadow: '0 16px 48px rgba(0,0,0,0.28), 0 2px 8px rgba(0,0,0,0.12)',
        font: 'inherit',
        WebkitFontSmoothing: 'antialiased',
        overflow: 'hidden',
      },
      dialogHeader: {
        flex: '0 0 auto',
        display: 'flex',
        flexDirection: 'column',
        gap: '10px',
        padding: '12px 16px',
        borderBottom: T.hair,
      },
      headerRow: {
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        flexWrap: 'nowrap',
      },
      headerActions: {
        display: 'flex',
        alignItems: 'center',
        gap: '6px',
        marginLeft: 'auto',
        flex: '0 0 auto',
      },
      dialogTitle: {
        flex: '1 1 auto',
        minWidth: 0,
        fontSize: T.font.body,
        lineHeight: '22px',
        fontWeight: 600,
        letterSpacing: '-0.005em',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
      },
      /* The build that is actually running. Small and muted, but present: "is this
         the new bundle?" should never again be a question answered by guessing. */
      versionTag: {
        flex: '0 0 auto',
        alignSelf: 'baseline',
        fontSize: T.font.caption,
        lineHeight: '18px',
        fontWeight: 400,
        color: 'var(--dsw-alias-label-tertiary, #8b94a3)',
        fontVariantNumeric: 'tabular-nums',
      },
      chips: {
        display: 'flex',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '6px',
      },
      chip: {
        display: 'inline-flex',
        alignItems: 'baseline',
        gap: '5px',
        fontSize: T.font.caption,
        lineHeight: '18px',
        padding: '0 10px',
        borderRadius: T.radius.sm,
        border: T.hair,
        background: 'var(--dsw-alias-bg-layer-2, rgba(127,127,127,0.06))',
        color: 'var(--dsw-alias-label-secondary, #5b6472)',
        whiteSpace: 'nowrap',
      },
      chipLabel: { color: 'var(--dsw-alias-label-secondary, #5b6472)' },
      chipValue: {
        color: 'var(--dsw-alias-label-primary, #1a1a1a)',
        fontSize: T.font.caption,
        fontWeight: 600,
        fontVariantNumeric: 'tabular-nums',
      },
      chipAccent: {
        border: '0.5px solid var(--dsw-alias-brand-primary, rgba(90,140,255,0.9))',
        background: 'transparent',
      },
      chipAccentValue: { color: 'var(--dsw-alias-brand-primary, #2f6feb)' },
      chipWarn: {
        border: '0.5px solid var(--dsw-alias-warn, rgba(212,140,0,0.75))',
        background: 'transparent',
      },
      chipWarnValue: { color: 'var(--dsw-alias-warn, #9a6700)' },
      chipError: {
        border: '0.5px solid var(--dsw-alias-danger, rgba(207,34,46,0.75))',
        background: 'transparent',
      },
      chipErrorValue: { color: 'var(--dsw-alias-danger, #b42318)' },

      /* ---- the JSON pane: one bar on top-right, then the scrolling body ---- */
      pane: {
        display: 'flex',
        flexDirection: 'column',
        flex: '1 1 auto',
        minWidth: 0,
        minHeight: 0,
      },
      paneBar: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        gap: '4px',
        flex: '0 0 auto',
        padding: '0 0 8px',
      },
      sides: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: '2px',
        flex: '0 0 auto',
      },
      sideBtn: {
        font: 'inherit',
        fontSize: T.font.caption,
        lineHeight: '18px',
        fontWeight: '600',
        height: T.hit.sm,
        padding: '0 10px',
        border: T.hair,
        borderRadius: T.radius.sm,
        background: 'transparent',
        color: 'var(--dsw-alias-label-tertiary, #81858c)',
        cursor: 'pointer',
        boxSizing: 'border-box',
        whiteSpace: 'nowrap',
      },
      sideBtnOff: {
        /* A step whose call never got a reply: the side exists but is empty. */
        opacity: 0.55,
      },
      sideBtnActive: {
        borderColor: 'var(--dsw-alias-brand-primary, rgba(90,140,255,0.9))',
        background: 'var(--dsw-alias-bg-overlay, #ffffff)',
        color: 'var(--dsw-alias-brand-primary, #2f6fed)',
      },

      stepHit: {
        font: 'inherit',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'flex-start',
        gap: '1px',
        flex: '1 1 auto',
        minWidth: 0,
        padding: 0,
        border: 'none',
        background: 'transparent',
        color: 'inherit',
        textAlign: 'left',
        cursor: 'pointer',
      },

      /* ---- response side: the retry list sits above the rebuilt body ---- */
      attemptList: {
        display: 'flex',
        flexDirection: 'column',
        gap: '2px',
        marginBottom: '8px',
        padding: '8px 10px',
        borderRadius: T.radius.sm,
        border: T.hair,
        background: 'var(--dsw-alias-bg-layer-2, rgba(127,127,127,0.05))',
      },
      attemptRow: {
        display: 'flex',
        alignItems: 'baseline',
        flexWrap: 'wrap',
        gap: '8px',
        fontSize: T.font.caption,
        lineHeight: '18px',
        color: 'var(--dsw-alias-label-secondary, #5b6472)',
      },
      attemptText: {
        fontFamily: FONT_MONO,
        fontSize: T.font.caption,
        color: 'var(--dsw-alias-label-primary, #1a1a1a)',
        wordBreak: 'break-word',
      },

      /* ---- timeline: one bar per step, proportional to the tokens it spent ---- */
      timeline: {
        display: 'flex',
        flexDirection: 'column',
        gap: '6px',
      },
      timelineHead: {
        display: 'flex',
        alignItems: 'baseline',
        justifyContent: 'space-between',
        gap: '8px',
        fontSize: T.font.caption,
        color: 'var(--dsw-alias-label-secondary, #5b6472)',
      },
      timelineTrack: {
        display: 'flex',
        alignItems: 'stretch',
        gap: '2px',
        height: '10px',
        borderRadius: T.radius.pill,
        overflow: 'hidden',
      },
      timelineSeg: {
        minWidth: '2px',
        borderRadius: '2px',
        cursor: 'pointer',
        border: 'none',
        padding: '0',
      },

      /* ---- source breakdown: one stacked bar, then the legend ---- */
      sourceBar: {
        display: 'flex',
        height: '8px',
        borderRadius: T.radius.pill,
        overflow: 'hidden',
        background: 'var(--dsw-alias-bg-layer-2, rgba(127,127,127,0.10))',
      },
      sourceSeg: { height: '100%', minWidth: '2px' },
      sourceLegend: {
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        gap: '4px 14px',
        marginTop: '7px',
        fontSize: T.font.caption,
        lineHeight: '18px',
        color: 'var(--dsw-alias-label-secondary, #5b6472)',
      },
      /* Each family is a chip that opens its kinds; collapsed by default so the
         panel is one readable row above the JSON. */
      sourceChip: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: '5px',
        whiteSpace: 'nowrap',
        padding: '2px 7px',
        borderRadius: T.radius.sm,
        border: T.hair,
        background: 'transparent',
        color: 'inherit',
        font: 'inherit',
        cursor: 'pointer',
        lineHeight: '18px',
      },
      sourceDetailRow: {
        display: 'flex',
        flexWrap: 'wrap',
        gap: '4px 12px',
        marginTop: '6px',
        paddingTop: '6px',
        borderTop: T.hairDashed,
        fontSize: T.font.caption,
        lineHeight: '18px',
        color: 'var(--dsw-alias-label-secondary, #5b6472)',
      },
      sourceDetail: { display: 'inline-flex', alignItems: 'center', gap: '5px', whiteSpace: 'nowrap' },
      sourceDot: { width: '8px', height: '8px', borderRadius: '2px', flex: '0 0 auto' },
      sourceNum: {
        color: 'var(--dsw-alias-label-primary, #1a1a1a)',
        fontWeight: 600,
        fontVariantNumeric: 'tabular-nums',
      },
      sourceMuted: { color: 'var(--dsw-alias-label-secondary, #5b6472)' },
      dialogBody: {
        flex: '1 1 auto',
        minHeight: 0,
        minWidth: 0,
        overflow: 'auto',
        overscrollBehavior: 'contain',
        padding: '12px 16px 16px',
        fontFamily: FONT_MONO,
        fontSize: T.font.caption,
        lineHeight: '18px',
        tabSize: 2,
      },
      dialogFoot: {
        flex: '0 0 auto',
        padding: '8px 16px 10px',
        borderTop: T.hair,
        fontSize: T.font.caption,
        lineHeight: '18px',
        color: 'var(--dsw-alias-label-secondary, #5b6472)',
      },


      /* ---- collapsible JSON tree ---- */
      jsonLine: { whiteSpace: 'pre-wrap', wordBreak: 'break-word', cursor: 'default' },
      jsonClickable: { cursor: 'pointer' },
      jsonNode: { display: 'block' },
      jsonGuide: {
        borderLeft: T.hair,
        marginLeft: '6px',
        paddingLeft: '10px',
      },
      /* Messages produced in the inspected turn: the array's own guide line turns
         into an accent rail for them, continuous across consecutive messages.
         The negative margin + matching padding keep the text on the same x, so
         current rows stay aligned with the folded history block above. */
      jsonCurrent: {
        borderLeft: '2px solid transparent',
        marginLeft: '-10px',
        paddingLeft: '10px',
      },
      /* The same rail, dashed, for the messages this call appended on top of the
         previous one — "what is new here" read off the tree itself instead of a
         second panel listing the same messages. */
      jsonFresh: {
        borderLeft: '2px dashed transparent',
        marginLeft: '-10px',
        paddingLeft: '10px',
      },
      /* The rule drawn where the previous call's payload ends. */
      jsonFreshSep: {
        display: 'flex',
        alignItems: 'center',
        margin: '5px 0 4px',
        paddingTop: '5px',
        borderTop: T.hairDashed,
        fontFamily: FONT_MONO,
        fontSize: T.font.micro,
        letterSpacing: '0.02em',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
      },
      /* The "1838 items · history 1814 · this turn 24" summary on the array head. */
      jsonBadge: {
        display: 'inline-block',
        marginLeft: '8px',
        padding: '0 6px',
        border: '1px solid transparent',
        borderRadius: T.radius.pill,
        fontSize: T.font.caption,
        lineHeight: '16px',
        fontVariantNumeric: 'tabular-nums',
      },
      jsonBadgeMuted: {
        display: 'inline-block',
        marginLeft: '6px',
        fontSize: T.font.caption,
        fontVariantNumeric: 'tabular-nums',
      },
      /* Folded history header: reads as a label, never as a JSON element. */
      jsonFoldedHead: {
        margin: '3px 0',
        padding: '2px 6px',
        borderRadius: T.radius.xs,
        background: 'var(--dsw-alias-bg-layer-2, rgba(127,127,127,0.07))',
      },
      /* "→ 对话" jump affordance on one message row. Hidden until the row is
         hovered so the JSON stays the thing you read; the CSS rule lives in
         ACTION_CSS with the other class-based styling. */
      jsonJump: { marginLeft: '8px', verticalAlign: 'middle' },
      /* The one row the dialog was opened from: a soft accent band that fades,
         so "this is the message you clicked" reads at a glance. */
      jsonFocus: {
        borderRadius: T.radius.xs,
        outline: '2px solid var(--dsw-alias-brand-primary, #2f6fed)',
        outlineOffset: '1px',
      },
      /* Result badge on a `tool_calls` entry: ok / error / missing, plus the
         round-trip time. Deliberately tiny and monospaced so a row with three
         tool calls still reads as JSON. */
      jsonToolBadge: {
        display: 'inline-block',
        marginLeft: '6px',
        padding: '0 5px',
        border: '1px solid transparent',
        borderRadius: T.radius.xs,
        fontSize: T.font.micro,
        lineHeight: '16px',
        fontVariantNumeric: 'tabular-nums',
        verticalAlign: 'middle',
        cursor: 'pointer',
      },
      /* An opened tool call in the JSON tree: its arguments, then its result. */
      jsonToolBody: {
        marginLeft: '6px',
        paddingLeft: '10px',
        borderLeft: T.hairDashed,
      },
      jsonToolLabel: {
        fontSize: T.font.micro,
        lineHeight: '16px',
        textTransform: 'uppercase',
        letterSpacing: '0.04em',
      },

      /* Every call of a Turn gets a row in the left column, however few there are:
         one shape for one call and for forty. The column scrolls on its own, the
         JSON pane keeps the rest of the width. */
      split: {
        flex: '1 1 auto',
        minHeight: 0,
        display: 'flex',
        alignItems: 'stretch',
      },
      stepList: {
        flex: '0 0 auto',
        width: '236px',
        minWidth: '180px',
        boxSizing: 'border-box',
        display: 'flex',
        flexDirection: 'column',
        gap: '2px',
        padding: '8px',
        overflowY: 'auto',
        overscrollBehavior: 'contain',
        borderRight: T.hair,
        background: 'var(--dsw-alias-bg-layer-2, rgba(127,127,127,0.04))',
      },
      stepRow: {
        font: 'inherit',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'stretch',
        gap: '1px',
        textAlign: 'left',
        padding: '5px 8px',
        borderRadius: T.radius.sm,
        border: '0',
        borderLeft: '2px solid transparent',
        background: 'transparent',
        color: 'inherit',
        cursor: 'pointer',
        transition: 'background-color .12s ease',
      },
      stepRowActive: {
        background: 'var(--dsw-alias-bg-overlay, #ffffff)',
        borderLeft: '2px solid var(--dsw-alias-brand-primary, #2f6fed)',
        boxShadow: 'inset 0 0 0 0.5px var(--dsw-alias-border-l4, var(--dsw-alias-border-l1, rgba(127,127,127,0.25)))',
      },
      stepRowTop: {
        display: 'flex',
        alignItems: 'baseline',
        justifyContent: 'space-between',
        gap: '8px',
      },
      stepNo: {
        fontSize: T.font.control,
        lineHeight: '18px',
        fontWeight: 600,
        fontVariantNumeric: 'tabular-nums',
      },
      stepAside: {
        fontSize: T.font.caption,
        lineHeight: '16px',
        color: 'var(--dsw-alias-label-secondary, #5b6472)',
        fontVariantNumeric: 'tabular-nums',
        whiteSpace: 'nowrap',
      },
      stepSub: {
        fontSize: T.font.caption,
        lineHeight: '16px',
        color: 'var(--dsw-alias-label-secondary, #5b6472)',
        fontVariantNumeric: 'tabular-nums',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
      },
    };

    // ---------------------------------------------------------------- log helpers

    function seqOf(event) {
      if (!event) return -1;
      if (typeof event.seq === 'number') return event.seq;
      if (typeof event.eventSeq === 'number') return event.eventSeq;
      if (typeof event.offset === 'number') return event.offset;
      return -1;
    }

    function typeOf(event) {
      if (!event) return '';
      if (typeof event.type === 'string') return event.type;
      return '';
    }

    function dataOf(event) {
      if (!event) return {};
      if (event.data && typeof event.data === 'object') return event.data;
      if (event.payload && typeof event.payload === 'object') return event.payload;
      return {};
    }

    /*
     * Why a message is in the request — the question a reader actually asks in
     * front of a 1078-message payload. The session log already records it: every
     * message-shaped event carries `data.source.kind` (or `data.message.source`
     * for assistant/tool messages), so this table only names those kinds.
     *
     * The families are what matter, not the individual kinds: a prompt is
     * mostly "history", plus injections this Turn needed, plus tool traffic.
     */
    const SOURCE_KINDS = {
      user: { key: 'prompt', family: 'prompt' },
      'user-approval': { key: 'approval', family: 'prompt' },
      /* Background-job completion reports arrive as `user` messages, but they are
         the harness talking, not the person: counting them as "your input" made
         a Turn with 1 real prompt report 54. Kept in their own kind so both the
         count and the wording stay honest. */
      'tool-jobs': { key: 'jobReport', family: 'injected' },
      'time-context': { key: 'timeContext', family: 'injected' },
      'runtime-context': { key: 'runtimeContext', family: 'injected' },
      'skill-catalog': { key: 'skillCatalog', family: 'injected' },
      'model-selection': { key: 'modelSelection', family: 'injected' },
      'system-prompt': { key: 'systemPrompt', family: 'injected' },
      'tool-registry': { key: 'toolRegistry', family: 'injected' },
      model: { key: 'model', family: 'model' },
      tool: { key: 'tool', family: 'tool' },
    };

    /** The source kind of one log event, or '' when the log does not say. */
    function sourceKindOf(type, data) {
      const message = data && data.message && typeof data.message === 'object' ? data.message : null;
      const source = (message && message.source) || (data && data.source) || null;
      if (source && typeof source.kind === 'string') return source.kind;
      return '';
    }

    /*
     * Conversation cross-link keys.
     *
     * The chat plugin publishes every rendered row under
     * `conversationContextKey(kind, id)` = `${kind.length}:${kind}${id}` and puts
     * it on the DOM as `data-chat-node-key` (plus `data-chat-turn` on the owning
     * Turn). Mirroring that formula here is what lets a message inside the JSON
     * jump to its own bubble, so the three kinds that a request is made of are
     * reproduced verbatim:
     *   assistant-step  id `${turn}:${step}`   (one step = one model call)
     *   input-message   id String(event.data.id)  (user / developer / system rows)
     *   tool-call       id String(callId)
     * Anything else (a record the conversation does not render as its own row)
     * gets no key and simply offers no jump.
     */
    function conversationNodeKey(kind, id) {
      return kind.length + ':' + kind + id;
    }

    /** The cross-link target of one log event, or null when it has no row. */
    function messageLinkOf(type, data, role, raw) {
      if (role === 'assistant') {
        const turn = data && data.turn;
        const step = data && data.step;
        if (typeof turn === 'number' && typeof step === 'number') {
          return { key: conversationNodeKey('assistant-step', turn + ':' + step), turn: turn };
        }
        return null;
      }
      if (role === 'tool') {
        const callId =
          raw && raw.toolCallId !== undefined
            ? raw.toolCallId
            : raw && raw.tool_call_id !== undefined
              ? raw.tool_call_id
              : undefined;
        if (callId !== undefined) return { key: conversationNodeKey('tool-call', String(callId)), turn: null };
        return null;
      }
      const message = data && data.message && typeof data.message === 'object' ? data.message : null;
      const id = (message && message.id !== undefined ? message.id : data && data.id) ?? undefined;
      if (id !== undefined) {
        const turn = data && typeof data.turn === 'number' ? data.turn : null;
        return { key: conversationNodeKey('input-message', String(id)), turn: turn };
      }
      return null;
    }

    /** Which family a source kind belongs to; unknown kinds are 'other'. */
    function familyOf(kind) {
      const known = SOURCE_KINDS[kind];
      return known ? known.family : 'other';
    }

    /*
     * Byte size without building the string: the payload is megabytes, and this
     * runs once per call of a Turn.
     */
    function byteLength(value) {
      if (value === null || value === undefined) return 4;
      if (typeof value === 'string') return utf8Length(value) + 2;
      if (typeof value === 'number') return isFinite(value) ? String(value).length : 4;
      if (typeof value === 'boolean') return value ? 4 : 5;
      if (Array.isArray(value)) {
        let total = 2;
        for (let i = 0; i < value.length; i += 1) total += byteLength(value[i]) + 1;
        return total;
      }
      if (typeof value === 'object') {
        const keys = Object.keys(value);
        let total = 2;
        for (let i = 0; i < keys.length; i += 1) {
          total += utf8Length('"' + keys[i] + '":') + byteLength(value[keys[i]]) + 1;
        }
        return total;
      }
      return 0;
    }

    function utf8Length(text) {
      let bytes = 0;
      for (let i = 0; i < text.length; i += 1) {
        const code = text.charCodeAt(i);
        if (code < 0x80) bytes += 1;
        else if (code < 0x800) bytes += 2;
        else if (code >= 0xd800 && code <= 0xdbff) {
          bytes += 4;
          i += 1;
        } else bytes += 3;
      }
      return bytes;
    }

    /*
     * Size of a whole body (one rebuilt request, one reply), computed at most
     * once per object.
     *
     * The chips that show it are rebuilt on EVERY render of the dialog — a step
     * switch, a 请求|响应 switch, a fold, a copied-flash all re-run them — and the
     * body is megabytes: measuring it took ~40 ms per render on a 6 500-message
     * request, which is visible as lag on every click, not just on open. The
     * built calls are cached (`builtCache`), so their request objects survive and
     * the number is measured once per call for the life of the tab.
     */
    const BODY_BYTES = typeof WeakMap === 'function' ? new WeakMap() : null;

    function bytesOfBody(value) {
      if (!value || typeof value !== 'object') return 0;
      if (BODY_BYTES) {
        const cached = BODY_BYTES.get(value);
        if (cached !== undefined) return cached;
      }
      let bytes = 0;
      try {
        bytes = byteLength(value);
      } catch (error) {
        bytes = 0;
      }
      if (BODY_BYTES) BODY_BYTES.set(value, bytes);
      return bytes;
    }

    /**
     * Wait long enough for the browser to actually paint.
     *
     * The loading dialog is worthless if the frame that would show it never gets
     * committed: opening one request means reading every page of the session and
     * then rebuilding the Turn, all of it queued behind whatever the app is
     * already rendering, so a note published just before that work can stay
     * invisible until the work is over. One animation frame plus a macrotask is
     * the shortest wait that guarantees a paint in between — a bare
     * `setTimeout(0)` can be drained before the frame is drawn, and a bare
     * `requestAnimationFrame` fires before it.
     */
    function nextPaint() {
      return new Promise((resolve) => {
        const macrotask = () => {
          if (typeof setTimeout === 'function') setTimeout(resolve, 0);
          else resolve();
        };
        if (typeof requestAnimationFrame === 'function') requestAnimationFrame(macrotask);
        else macrotask();
      });
    }

    /** `performance.now()` where it exists: the load timer must not jump on a clock change. */
    function monotonicNow() {
      try {
        if (typeof performance !== 'undefined' && performance && typeof performance.now === 'function') {
          return performance.now();
        }
      } catch (err) {
        /* fall through */
      }
      return Date.now();
    }

    /**
     * Group the messages of one rebuild by source, so the viewer can answer
     * "why is this request 1078 messages long".
     *
     * `items` is the seq-tagged list `buildMessages` folded, filtered down to the
     * messages it actually kept: an incremental empty record contributes nothing,
     * so counting it would overstate a family.
     */
    function summarizeSources(items) {
      const families = { prompt: 0, injected: 0, model: 0, tool: 0, other: 0 };
      const kinds = {};
      const order = [];
      for (let i = 0; i < items.length; i += 1) {
        const entry = items[i];
        const kind = entry.kind || '';
        const known = SOURCE_KINDS[kind];
        const family = known ? known.family : 'other';
        families[family] += 1;
        const key = known ? known.key : 'other';
        if (!kinds[key]) {
          kinds[key] = { key: key, kind: kind, family: family, count: 0 };
          order.push(key);
        }
        kinds[key].count += 1;
      }
      return {
        counts: families,
        kinds: order.map((key) => kinds[key]),
      };
    }

    /**
     * Running version of `summarizeSources` for a sequence that only ever grows.
     *
     * Within one Turn every request carries the previous request's messages as a
     * prefix, so the source histogram of call k is call k−1's histogram plus the
     * handful of new messages. Recomputing it from the whole track per call made
     * this the single biggest cost after the O(n²) fold was fixed.
     */
    function newSourceAcc() {
      return {
        n: 0,
        counts: { prompt: 0, injected: 0, model: 0, tool: 0, other: 0 },
        kinds: {},
        order: [],
        snapshot: null,
        snapshotN: -1,
      };
    }

    function foldSourceInto(acc, entry) {
      const kind = (entry && entry.kind) || '';
      const known = SOURCE_KINDS[kind];
      const family = known ? known.family : 'other';
      acc.counts[family] += 1;
      const key = known ? known.key : 'other';
      if (!acc.kinds[key]) {
        acc.kinds[key] = { key: key, kind: kind, family: family, count: 0 };
        acc.order.push(key);
      }
      acc.kinds[key].count += 1;
    }

    function snapshotSourceAcc(acc) {
      if (acc.snapshotN === acc.n) return acc.snapshot;
      acc.snapshot = {
        counts: {
          prompt: acc.counts.prompt,
          injected: acc.counts.injected,
          model: acc.counts.model,
          tool: acc.counts.tool,
          other: acc.counts.other,
        },
        kinds: acc.order.map(function (key) {
          return {
            key: acc.kinds[key].key,
            kind: acc.kinds[key].kind,
            family: acc.kinds[key].family,
            count: acc.kinds[key].count,
          };
        }),
      };
      acc.snapshotN = acc.n;
      return acc.snapshot;
    }

    /** Summary of every message folded so far (the whole carried history). */
    function accSources(acc, track) {
      for (; acc.n < track.length; acc.n += 1) foldSourceInto(acc, firstRecord(track[acc.n]));
      return snapshotSourceAcc(acc);
    }

    /** Summary of only the messages this Turn wrote, from `historyEnd` onward. */
    function accFreshSources(acc, track, historyEnd, turnStartSeq) {
      if (acc.fromIndex !== historyEnd) {
        /* historyEnd is fixed once the Turn boundary is crossed, so this branch
           runs at most twice per Turn: reset when it first becomes known. */
        acc.fromIndex = historyEnd;
        acc.n = 0;
        acc.counts = { prompt: 0, injected: 0, model: 0, tool: 0, other: 0 };
        acc.kinds = {};
        acc.order = [];
        acc.snapshot = null;
        acc.snapshotN = -1;
      }
      for (; acc.n + historyEnd < track.length; acc.n += 1) {
        foldSourceInto(acc, firstRecord(track[acc.n + historyEnd], turnStartSeq));
      }
      return snapshotSourceAcc(acc);
    }

    /** Flatten a window entry list into a seq-ordered array of real (non-transient) events. */
    function collectEvents(entries) {
      const out = [];
      const list = Array.isArray(entries) ? entries : [];
      for (let i = 0; i < list.length; i += 1) {
        const entry = list[i];
        if (!entry) continue;
        if (entry.type === 'transient') continue;
        const event = entry.event || entry;
        if (event && typeof event === 'object' && typeof event.type === 'string') out.push(event);
      }
      out.sort((a, b) => seqOf(a) - seqOf(b));
      return out;
    }

    /** Render a logged content value the way a chat request carries it: plain text. */
    function flattenContent(content) {
      if (content === null || content === undefined) return null;
      if (typeof content === 'string') return content;
      if (Array.isArray(content)) {
        const parts = [];
        for (let i = 0; i < content.length; i += 1) {
          const block = content[i];
          if (block === null || block === undefined) continue;
          if (typeof block === 'string') {
            parts.push(block);
            continue;
          }
          const kind = typeof block.type === 'string' ? block.type : '';
          if (kind === 'image' || kind === 'image-url' || kind === 'image_url' || kind === 'file') {
            parts.push('[image]');
            continue;
          }
          if (typeof block.text === 'string') {
            parts.push(block.text);
            continue;
          }
          if (typeof block.content === 'string') {
            parts.push(block.content);
            continue;
          }
          try {
            parts.push(JSON.stringify(block));
          } catch (err) {
            parts.push('[block]');
          }
        }
        return parts.join('\n');
      }
      if (typeof content === 'object') {
        if (typeof content.text === 'string') return content.text;
        try {
          return JSON.stringify(content);
        } catch (err) {
          return String(content);
        }
      }
      return String(content);
    }

    /** Drop the surface messages that a compaction `replace` op rewrote away. */
    function applyReplace(items, op) {
      if (!op || typeof op !== 'object' || op.op !== 'replace') return false;
      const start = typeof op.startSeq === 'number' ? op.startSeq : null;
      const end = typeof op.endSeq === 'number' ? op.endSeq : null;
      if (start === null || end === null) return false;
      for (let i = items.length - 1; i >= 0; i -= 1) {
        const seq = items[i].seq;
        if (seq >= start && seq <= end) items.splice(i, 1);
      }
      return true;
    }

    /**
     * Fold the surface log up to `cutSeq` into the message array of one request.
     *
     * `turnStartSeq` is the seq that opened the Turn being inspected: everything
     * at or after it was produced by this Turn (the user message, the context
     * injected for it, and every assistant/tool message so far), everything
     * before it is history the request merely carried along. The returned
     * `historyEnd` is the index where that boundary falls in `messages`, which is
     * what lets the viewer fold the older block away by default.
     *
     * Each kept message also carries `track`, the seq-ordered list of its source
     * records ({seq, kind, family, byte}), so the viewer can say where every
     * message came from without rebuilding anything.
     */
    /**
     * The fold state for one request. `buildMessages` exists as a thin wrapper so
     * the harness can still ask for a single snapshot, but the viewer's hot path
     * (`buildTurnCalls`) drives this class directly: it appends each record ONCE
     * and slides the cut forward, instead of re-scanning the whole window per
     * step (was 169 full folds = 11 s on a 13 k-record session).
     */
    function FoldState(turnStartSeq) {
      this.items = [];
      this.lastAssistant = null;
      this.boundary = typeof turnStartSeq === 'number' && turnStartSeq >= 0 ? turnStartSeq : -1;
      /* Every tool call the fold has consumed, keyed by callId, paired with its
         result as soon as the result record shows up. Shared across the whole
         window: a request carries the tool calls of earlier Turns, and the JSON
         view wants their name/summary/result too. Grows by one entry per call,
         never rescanned. */
      this.toolDetails = {};
      /* callId -> pending detail, so a result can find its call without a scan. */
      this.toolCallIndex = {};
      /* Every kept message, and the three parallel arrays, are append-only from
         the perspective of a cut that only moves forward — which is exactly how
         one Turn calls the model. A snapshot is therefore a prefix. */
      this.snapshot = { messages: [], historyEnd: 0, track: [], links: [], historyEndFixed: false };
    }

    /** Absorb one log record if it contributes to the request payload. */
    FoldState.prototype.consume = function consume(event) {
      const seq = seqOf(event);
      const type = typeOf(event);
      const data = dataOf(event);
      const at = typeof event.time === 'number' ? event.time : null;
      const items = this.items;

      /* Tool traffic is tracked for the JSON view even when the record does not
         contribute a message (a result is folded as a `tool` message, but a call
         is an attribute of its assistant message). Recording both here keeps the
         window-wide index complete and costs one object per record. */
      if (type === 'tool/result') {
        const message = data.message && typeof data.message === 'object' ? data.message : {};
        const callId =
          message.toolCallId !== undefined
            ? message.toolCallId
            : message.source && message.source.callId !== undefined
              ? message.source.callId
              : undefined;
        if (callId !== undefined) {
          const text = flattenContent(message.content);
          const detail = this.toolDetails[String(callId)];
          if (detail) {
            detail.status = message.isError === true ? 'error' : 'ok';
            detail.durationMs = typeof detail.time === 'number' && typeof at === 'number' ? Math.max(0, at - detail.time) : null;
            detail.result = { text: text, bytes: byteLength(text), isError: message.isError === true, seq: seq };
          }
        }
      }

      if (type === 'tool/call') {
        const callId = data.callId !== undefined ? data.callId : data.toolCallId;
        if (callId !== undefined) {
          this.toolDetails[String(callId)] = makeToolDetail(callId, data.name, data.arguments, seq, at);
        }
        const lastAssistant = this.lastAssistant;
        if (lastAssistant && Array.isArray(lastAssistant.tool_calls)) {
          lastAssistant.tool_calls.push({
            id: callId,
            type: 'function',
            function: {
              name: data.name,
              arguments:
                typeof data.arguments === 'string'
                  ? data.arguments
                  : JSON.stringify(data.arguments === undefined ? {} : data.arguments),
            },
          });
          /* The call belongs to the assistant message it hangs off, so it adds
             to that message's size rather than becoming one of its own. */
          const owner = items[items.length - 1];
          if (owner) {
            owner.track.push({
              seq: seq,
              kind: 'model',
              family: 'model',
              byte: byteLength(data.arguments),
            });
          }
        }
        return;
      }

      const role = SURFACE_ROLES[type];
      if (!role) return;

      if (applyReplace(items, data.surfaceOp)) this.lastAssistant = null;

      const raw =
        role === 'user' && typeof data.role === 'string'
          ? data
          : data.message && typeof data.message === 'object'
            ? data.message
            : data;

      const message = { role: role, content: flattenContent(raw.content) };
      /* Non-enumerable so it never reaches JSON.stringify or the copied
         payload, but the viewer/harness can still tell which turn+step
         produced this message — that is what its bubble is keyed by. */
      Object.defineProperty(message, '__origin', {
        value: {
          turn: typeof (data && data.turn) === 'number' ? data.turn : null,
          step: typeof (data && data.step) === 'number' ? data.step : null,
        },
        enumerable: false,
        writable: true,
        configurable: true,
      });

      if (role === 'tool') {
        const callId = raw.toolCallId !== undefined ? raw.toolCallId : raw.tool_call_id;
        if (callId !== undefined) message.tool_call_id = callId;
        if (raw.isError === true) message.is_error = true;
        if (typeof raw.name === 'string') message.name = raw.name;
      }

      if (role === 'assistant') {
        message.tool_calls = [];
        this.lastAssistant = message;
      } else {
        this.lastAssistant = null;
      }

      const kind = sourceKindOf(type, data);
      const bytes = byteLength(message.content);
      items.push({
        seq: seq,
        kind: kind,
        byte: bytes,
        message: message,
        /* Where this message is rendered in the conversation, so the viewer
           can jump from a JSON row to its bubble. Computed once here, from
           the same record the message was built from. */
        link: messageLinkOf(type, data, role, raw),
        track: [{ seq: seq, kind: kind, family: familyOf(kind), byte: bytes }],
      });
    };

    /**
     * Turn the records folded so far into the arrays one request needs.
     *
     * `historyEnd` (the index where this Turn's own messages start) is resolved
     * once, at the first record at or past the Turn boundary, and then stays
     * fixed — the boundary never moves, so recomputing it per snapshot would
     * only burn time.
     */
    FoldState.prototype.view = function view() {
      const snap = this.snapshot;
      if (snap.stale) {
        const items = this.items;
        const messages = [];
        const track = [];
        const links = [];
        const boundary = this.boundary;
        let historyEnd = boundary < 0 ? 0 : null;
        for (let i = 0; i < items.length; i += 1) {
          const message = items[i].message;
          if (message.role === 'assistant' && Array.isArray(message.tool_calls) && message.tool_calls.length === 0) {
            delete message.tool_calls;
          }
          /* `system/message` and `user/message` are INCREMENTAL records: an empty
             one means "nothing new for this epoch", not "send an empty message".
             Carrying it would put a message the model never saw into the payload. */
          if (!message.tool_calls) {
            const text = message.content;
            if (typeof text !== 'string' || text.trim() === '') continue;
          }
          if (historyEnd === null && items[i].seq >= boundary) historyEnd = messages.length;
          messages.push(message);
          track.push(items[i].track);
          links.push(items[i].link || null);
        }
        snap.messages = messages;
        snap.track = track;
        snap.links = links;
        snap.historyEnd = historyEnd === null ? messages.length : historyEnd;
        snap.stale = false;
      }
      return {
        messages: snap.messages,
        historyEnd: snap.historyEnd,
        /* Per-message provenance, aligned with `messages`. */
        track: snap.track,
        /* Per-message conversation target, aligned with `messages`. */
        links: snap.links,
      };
    };

    /**
     * Convenience wrapper: fold the whole window up to `cutSeq` and return one
     * snapshot. Used by the harness and by anything that needs a one-off answer;
     * `buildTurnCalls` uses `FoldState` directly so a Turn folds the window once.
     */
    function buildMessages(events, cutSeq, turnStartSeq) {
      const state = new FoldState(turnStartSeq);
      for (let i = 0; i < events.length; i += 1) {
        if (seqOf(events[i]) >= cutSeq) break;
        state.consume(events[i]);
      }
      state.snapshot.stale = true;
      return state.view();
    }

    /**
     * Open a rebuild of every model call of one Turn, one step at a time.
     *
     * One step is exactly one request to the model, so `step/start` is the
     * anchor. `request/header` is NOT emitted per call — the Harness records it
     * only when the call configuration changes — so the effective header is
     * carried forward from the nearest earlier record, including ones that sit
     * in previous Turns.
     *
     * Returns null when the Turn has no steps, or a job whose `step()` builds one
     * call and whose `finish()` closes the fold and returns `{turn, calls}`.
     * The scans that collect the Turn's steps and replies happen here, up front:
     * they are one pass over the window and there is nothing to interleave them
     * with.
     */
    function makeTurnBuild(events, turnNumber, turnSeq, turnStartHint) {
      let turnStartSeq = typeof turnStartHint === 'number' ? turnStartHint : -1;
      if (!(turnStartSeq >= 0) && turnNumber !== undefined) {
        for (let i = 0; i < events.length; i += 1) {
          if (typeOf(events[i]) !== 'turn/start') continue;
          if (dataOf(events[i]).turn === turnNumber) turnStartSeq = seqOf(events[i]);
        }
      }

      if (!(turnStartSeq >= 0) && turnNumber !== undefined) return null;

      /* Prefer the Turn's own end marker (or the next Turn's start) as the upper
         bound; the slot's `seq` is only a fallback when no marker is visible. */
      let turnEndSeq = typeof turnSeq === 'number' ? turnSeq : -1;
      if (turnStartSeq >= 0) {
        let nextStart = -1;
        let endSeq = -1;
        for (let i = 0; i < events.length; i += 1) {
          const event = events[i];
          const seq = seqOf(event);
          if (seq <= turnStartSeq) continue;
          const type = typeOf(event);
          if (type === 'turn/end' && dataOf(event).turn === turnNumber) {
            endSeq = seq;
            break;
          }
          if (type === 'turn/start') {
            nextStart = seq;
            break;
          }
        }
        if (endSeq >= 0) turnEndSeq = endSeq;
        else if (nextStart >= 0) turnEndSeq = nextStart - 1;
      }

      /* One pass over the window collects everything the Turn needs: the sparse
         headers (the one governing a step may sit in an earlier Turn), the steps
         it ran, each step's response/usage/source, and its tool traffic. These
         used to be four full scans; on a 13 k-record window that alone cost
         more than the fold. */
      const headers = [];
      const steps = [];
      const responseByStep = {};
      const toolsByStep = {};
      const orphans = [];
      let headerCursor = 0;

      for (let i = 0; i < events.length; i += 1) {
        const event = events[i];
        const seq = seqOf(event);
        const type = typeOf(event);
        const data = dataOf(event);
        /* Wall clock lives on the record, not inside `data`; tool round-trip
           duration is the only thing it is used for here. */
        const at = typeof event.time === 'number' ? event.time : null;

        if (type === 'request/header') {
          headers.push({
            seq: seq,
            reason: data.reason,
            startsSeries: data.startsSeries === true,
            epoch: data.header && typeof data.header === 'object' ? data.header : {},
          });
          continue;
        }

        if (type === 'step/start') {
          if (seq < turnStartSeq) continue;
          if (turnEndSeq >= 0 && seq > turnEndSeq) continue;
          if (
            turnNumber !== undefined &&
            data.turn !== undefined &&
            data.turn !== null &&
            data.turn !== turnNumber
          ) {
            continue;
          }
          steps.push({
            step: typeof data.step === 'number' ? data.step : steps.length + 1,
            seq: seq,
            /* When the step opened. The reply's first chunk minus this is the only
               honest "time to first byte" the log allows: it includes prompt
               assembly, so the panel labels it accordingly. */
            time: at,
          });
          continue;
        }

        if (turnNumber !== undefined && data.turn !== turnNumber) continue;
        if (data.step === undefined || data.step === null) continue;
        const key = String(data.step);

        if (type === 'assistant/message' || type === 'assistant/attempt') {
          const entry =
            responseByStep[key] ||
            (responseByStep[key] = {
              cutSeq: undefined,
              source: null,
              usage: null,
              endSeq: undefined,
              /* The reply itself, plus everything needed to describe *what came
                 back*: the raw stream (timing + finish), and every failed attempt
                 that preceded it. */
              message: null,
              stream: null,
              finish: null,
              attempts: [],
            });
          if (entry.cutSeq === undefined) entry.cutSeq = seq;
          /* The response is not the only thing a step writes: tool calls and tool
             results follow it before the next step starts. The timeline needs the
             whole span, so it closes at the last record carrying this step. */
          entry.endSeq = seq;
          if (type === 'assistant/message') {
            entry.message = data.message && typeof data.message === 'object' ? data.message : null;
            entry.stream = Array.isArray(data.stream) ? data.stream : null;
            entry.finish = finishOfStream(entry.stream);
            if (data.usage && typeof data.usage === 'object') {
              entry.usage = data.usage;
            }
            const message = entry.message;
            const source = message && typeof message.source === 'object' ? message.source : null;
            if (!entry.source && source) entry.source = source;
          } else {
            /* A failed attempt leaves no message — only its finish chunk says what
               went wrong, and keeping every attempt is what makes a retry legible. */
            entry.attempts.push({
              seq: seq,
              time: at,
              finish: finishOfStream(Array.isArray(data.stream) ? data.stream : null),
            });
          }
        } else if (type === 'tool/call' || type === 'tool/result') {
          const entry = toolsByStep[key] || (toolsByStep[key] = { calls: 0, results: 0, names: [], details: [] });
          if (type === 'tool/call') {
            entry.calls += 1;
            const response = responseByStep[key];
            if (response) response.endSeq = Math.max(response.endSeq || 0, seq);
            if (typeof data.name === 'string' && entry.names.indexOf(data.name) < 0) entry.names.push(data.name);
            entry.details.push({
              callId: data.callId !== undefined ? data.callId : data.toolCallId,
              name: typeof data.name === 'string' ? data.name : '',
              arguments: data.arguments,
              seq: seq,
              time: at,
              /* Filled in when the matching tool/result shows up. */
              result: null,
            });
          } else {
            entry.results += 1;
            /* Pair by callId, which both sides carry. A result whose call sits in
               an earlier step or earlier Turn is still the truth about that call,
               so pairing scans the whole Turn's accumulated log, not this step. */
            const message = data.message && typeof data.message === 'object' ? data.message : {};
            const callId =
              message.toolCallId !== undefined
                ? message.toolCallId
                : message.source && message.source.callId !== undefined
                  ? message.source.callId
                  : undefined;
            const owner = callId === undefined ? null : findToolCall(toolsByStep, callId);
            const text = flattenContent(message.content);
            const filled = {
              isError: message.isError === true,
              text: text,
              bytes: byteLength(text),
              seq: seq,
              time: at,
            };
            if (owner) owner.result = filled;
            else orphans.push({ step: key, callId: callId === undefined ? null : callId, result: filled });
          }
        }
      }

      if (!steps.length) return null;

      /* A step without tool traffic still needs an entry, so the timeline can
         say "0 工具" instead of treating it as missing data. */
      for (let i = 0; i < steps.length; i += 1) {
        const key = String(steps[i].step);
        if (!toolsByStep[key]) toolsByStep[key] = { calls: 0, results: 0, names: [], details: [] };
      }

      /* Fold the window ONCE. Each step's cut only moves forward, so the fold
         state is advanced to the cut and its arrays snapshotted — a prefix of the
         previous step's arrays, never a re-scan of the whole window. */
      const fold = new FoldState(turnStartSeq);
      let cursor = 0;

      /* Source summaries are prefix aggregates too: call k's summary is call k−1's
         plus whatever the new messages add, so they are accumulated as the fold
         grows instead of being recomputed from the whole track 169 times. */
      const sourceAll = newSourceAcc();
      const sourceFresh = newSourceAcc();

      /* Every tool call the fold has seen so far, keyed by callId.
       *
       * This deliberately spans the whole WINDOW, not just this Turn: a request
       * carries the `tool_calls` of every earlier Turn as well, and those rows
       * deserve the same name/summary/result treatment. It is built as the fold
       * advances (`FoldState` records each call as it consumes the log), so the
       * cost is one entry per tool call in the window — not a rescan.
       */
      const turnDetailsById = fold.toolDetails;

      const calls = [];
      let stepCursor = 0;

      /* One step's worth of work, as a function instead of a loop body: the click
         path runs this same code in slices with a painted frame between them (see
         `buildTurnCallsChunked`). A Turn of a long conversation can carry a
         hundred calls and take ~190 ms, and a task that long holds the thread
         through the whole rebuild — no spinner, no progress, nothing. */
      const buildNextCall = () => {
        const i = stepCursor;
        stepCursor += 1;
        const stepInfo = steps[i];
        const nextSeq =
          i + 1 < steps.length
            ? steps[i + 1].seq
            : turnEndSeq >= 0
              ? turnEndSeq + 1
              : Number.MAX_SAFE_INTEGER;

        const response = responseByStep[String(stepInfo.step)] || null;
        /* Messages are composed before the call, then recorded. Cut where this
           step's own response starts, so its response and tool results stay
           out of its own request. */
        const cutSeq =
          response && typeof response.cutSeq === 'number'
            ? response.cutSeq
            : nextSeq > stepInfo.seq
              ? nextSeq - 1
              : stepInfo.seq + 1;
        const headerBound = nextSeq - 1;

        /* Advance the fold up to (but not including) this step's cut. Cuts are
           non-decreasing within a Turn, so `cursor` never rewinds. */
        while (cursor < events.length && seqOf(events[cursor]) < cutSeq) {
          fold.consume(events[cursor]);
          cursor += 1;
        }
        /* Anything folded past the cut cannot exist (cuts are non-decreasing),
           but guard the invariant so a malformed log can never silently ship a
           request with messages it never sent. */
        fold.snapshot.stale = true;
        const built = fold.view();

        while (headerCursor < headers.length && headers[headerCursor].seq <= headerBound) headerCursor += 1;
        const header = headerCursor > 0 ? headers[headerCursor - 1] : null;
        const epoch = header && header.epoch && typeof header.epoch === 'object' ? header.epoch : {};
        const config = epoch.config && typeof epoch.config === 'object' ? epoch.config : {};
        const source = response && response.source ? response.source : null;

        const model =
          source && typeof source.model === 'string' ? source.model : config.model;
        const provider =
          source && typeof source.provider === 'string' ? source.provider : config.provider;

        const request = {};
        if (model !== undefined) request.model = model;
        if (provider !== undefined) request.provider = provider;
        const configKeys = Object.keys(config);
        for (let j = 0; j < configKeys.length; j += 1) {
          const key = configKeys[j];
          if (key === 'model' || key === 'provider') continue;
          request[key] = config[key];
        }

        request.messages = built.messages;
        const tools = Array.isArray(epoch.tools) ? epoch.tools : [];
        request.tools = tools;

        /* A step's request contains every earlier request of the same Turn as a
           prefix, so the useful question is "what changed since the previous
           call": the messages appended after it, and anything that got rewritten
           in place (compaction). Compared against the previous call of the SAME
           Turn — a Turn boundary is a different conversation, not a diff. */
        const prev = calls.length ? calls[calls.length - 1] : null;
        const diff = prev ? diffRequests(prev.request, request) : null;

        /* The other half of the exchange: what came back. Everything here is
           derived from the step's own response records, so the panel can show a
           reply without re-reading the log. */
        const callUsage = response && response.usage ? normalizeUsage(response.usage) : null;
        const attemptList = response && Array.isArray(response.attempts) ? response.attempts : [];
        const replyStreamTiming = response ? timingOfStream(response.stream) : null;
        const replyFinish =
          response && response.message
            ? response.finish
            : /* A step can die without ever writing a message: attempts only. The
                 last attempt is usually the informative one, but an attempt whose
                 stream ended without a finish chunk would hide the real reason, so
                 take the last attempt that actually reported one. */
              lastFinishOf(attemptList);
        const reply = response
          ? {
              finish: replyFinish,
              /* Failed attempts only: the one that produced a reply is the reply. */
              attempts: attemptList.map(function (item) {
                return { seq: item.seq, finish: item.finish };
              }),
              timing: replyStreamTiming
                ? {
                    /* Measured from the step's opening record, so it includes
                       prompt assembly — longer than a network round-trip, and
                       labelled as such in the title. */
                    ttfbMs:
                      typeof stepInfo.time === 'number' ? replyStreamTiming.first - stepInfo.time : null,
                    spanMs: replyStreamTiming.spanMs,
                    records: replyStreamTiming.records,
                    deltas: replyStreamTiming.deltas,
                  }
                : null,
              stats: response.message ? contentStatsOf(response.message) : null,
              body: response.message ? responseBodyOf(response.message, callUsage, model, replyFinish) : null,
            }
          : null;

        calls.push({
          index: i + 1,
          request: request,
          meta: {
            turn: turnNumber,
            seq: cutSeq,
            step: stepInfo.step,
            /* The seqs that frame this step in the log. startSeq is where it
               opened, endSeq is the last record it wrote; kept only so the
               timeline can describe a step's extent, never as a measure of cost. */
            startSeq: stepInfo.seq,
            endSeq: response && typeof response.endSeq === 'number' ? response.endSeq : stepInfo.seq,
            reason: header ? header.reason : null,
            startsSeries: header ? header.startsSeries : false,
            model: model,
            provider: provider,
            messages: request.messages.length,
            /* How heavy this step was: tool calls, tool round-trips (a call with
               its result) and the distinct tool names it used. */
            toolCalls: toolsByStep[String(stepInfo.step)].calls,
            toolResults: toolsByStep[String(stepInfo.step)].results,
            toolNames: toolsByStep[String(stepInfo.step)].names,
            /* One entry per tool call this step made, paired with its result:
               name, argument summary, ok/error/missing, duration and result
               size. The viewer's JSON rows and the 工具往返 panel both read this,
               so neither has to re-scan the log. */
            toolCallDetails: toolCallDetailsOf(toolsByStep[String(stepInfo.step)].details),
            /* Same entries, keyed by callId, so a `tool_calls` array in the JSON
               can look up each call even when it was made by an earlier step. */
            toolDetailsByCallId: turnDetailsById,
            /* Results whose call record sits outside this Turn (rare, e.g. a
               result delivered after the Turn closed). Kept so nothing is
               silently dropped from the panel. */
            orphanToolResults: orphans.filter(function (item) {
              return item.step === String(stepInfo.step);
            }).map(function (item) {
              return { callId: item.callId, result: item.result };
            }),
            /* Index where this Turn's own messages start; the viewer folds
               everything before it. Kept on `meta`, never inside `request`, so
               the payload itself stays byte-for-byte what was sent. */
            historyEnd: built.historyEnd,
            /* Parallel to `request.messages`: each entry names the conversation
               row (or null) a message is rendered as, so the viewer can link the
               two sides without re-deriving anything. */
            messageLinks: built.links,
            /* Why the messages are there, and which of them are new this Turn. */
            sources: accSources(sourceAll, built.track),
            freshSources: accFreshSources(sourceFresh, built.track, built.historyEnd, turnStartSeq),
            freshBytes: freshBytes(built.track, turnStartSeq, built.historyEnd),
            tools: tools.length,
            usage: callUsage,
            diff: diff,
            /* The reply side of this call. Kept on `meta` so `request` stays
               byte-for-byte what was sent. */
            response: reply,
          },
        });
      };

      /* The trailing fold — the last step's tool calls and results — and the
         result, kept together so a caller can run the whole thing at once
         (`buildTurnCalls`) or one step at a time (`buildTurnCallsChunked`). */
      const finish = () => {
        /* Steps are laid out by their request cut, so the fold stops at the last
           step's cut — but that step's own tool calls and their results come after
           it. Consuming the rest of the Turn completes the shared detail index,
           which is what lets the 响应 tab show a reply's `tool_calls` with its
           result instead of a `missing` badge. Cuts never rewind, so this is the
           same pass continuing, not a second scan. */
        const tailLimit = turnEndSeq >= 0 ? turnEndSeq : Number.MAX_SAFE_INTEGER;
        while (cursor < events.length && seqOf(events[cursor]) <= tailLimit) {
          fold.consume(events[cursor]);
          cursor += 1;
        }

        return { turn: turnNumber, calls: calls };
      };

      return {
        total: steps.length,
        built: () => stepCursor,
        done: () => stepCursor >= steps.length,
        step: buildNextCall,
        finish: finish,
      };
    }

    /**
     * Rebuild a whole Turn in one synchronous pass.
     *
     * This is the shape every test and the whole-Turn harness use; the Web UI
     * opens the dialog through `buildTurnCallsChunked` instead.
     */
    function buildTurnCalls(events, turnNumber, turnSeq, turnStartHint) {
      const job = makeTurnBuild(events, turnNumber, turnSeq, turnStartHint);
      if (!job) return null;
      while (!job.done()) job.step();
      return job.finish();
    }

    /* How much work one slice of a chunked rebuild may do before it hands the
       thread back. Twelve milliseconds is under one 60 Hz frame, so a painted
       frame still fits inside the slice budget instead of being starved by it. */
    const BUILD_SLICE_MS = 12;

    /**
     * The same rebuild, spread over frames.
     *
     * `onProgress(done, total)` runs between slices, which is the whole point:
     * between two slices the browser *can* paint, so the spinner keeps turning
     * and the "which call is it on" line keeps moving — the two things a single
     * 190 ms task makes impossible. `options.abandoned()` is polled at the same
     * boundaries, so closing the dialog stops the work instead of finishing a
     * rebuild nobody is waiting for.
     *
     * Returns the same object as `buildTurnCalls`, or null when there is nothing
     * to build (or the caller walked away). `options.sliceMs` exists so a test can
     * force a yield after every step instead of waiting for a real 12 ms of work.
     */
    async function buildTurnCallsChunked(events, turnNumber, turnSeq, turnStartHint, options) {
      const settings = options && typeof options === 'object' ? options : {};
      const sliceBudget = typeof settings.sliceMs === 'number' ? settings.sliceMs : BUILD_SLICE_MS;
      const job = makeTurnBuild(events, turnNumber, turnSeq, turnStartHint);
      if (!job) return null;
      let sliceStartedAt = monotonicNow();
      while (!job.done()) {
        job.step();
        if (job.done()) break;
        if (monotonicNow() - sliceStartedAt < sliceBudget) continue;
        if (typeof settings.abandoned === 'function') {
          let gone = false;
          try {
            gone = settings.abandoned() === true;
          } catch (error) {
            gone = false;
          }
          if (gone) return null;
        }
        if (typeof settings.onProgress === 'function') {
          try {
            settings.onProgress(job.built(), job.total);
          } catch (error) {
            /* a broken listener must not strand the rebuild */
          }
        }
        await nextPaint();
        sliceStartedAt = monotonicNow();
      }
      return job.finish();
    }

    /**
     * The `finish` chunk of one response stream.
     *
     * The log stores a stream as an array of records: single `chunk` records and
     * batched `<kind>-chunks` records that carry `dt[]` deltas. Only the single
     * chunks matter here — exactly one of them is the finish, and it is the only
     * place that says *why* the model stopped, including the failure that ended
     * an attempt before a reply was ever produced.
     */
    function finishOfStream(stream) {
      if (!Array.isArray(stream)) return null;
      for (let i = stream.length - 1; i >= 0; i -= 1) {
        const record = stream[i];
        if (!record || record.type !== 'chunk') continue;
        const chunk = record.chunk;
        if (!chunk || chunk.type !== 'finish') continue;
        const reason = chunk.reason && typeof chunk.reason === 'object' ? chunk.reason : {};
        const failure = reason.failure && typeof reason.failure === 'object' ? reason.failure : null;
        return {
          kind: typeof reason.kind === 'string' ? reason.kind : 'unknown',
          failure: failure
            ? {
                message: typeof failure.message === 'string' ? failure.message : '',
                code: typeof failure.code === 'string' ? failure.code : '',
                status: typeof failure.status === 'number' ? failure.status : null,
              }
            : null,
        };
      }
      return null;
    }

    /**
     * The reason a reply-less step stopped.
     *
     * A step with no message is a step that failed; its attempts are the only
     * evidence. Walk backwards for the last attempt that reported a finish, so a
     * trailing attempt whose stream merely went quiet cannot mask the earlier
     * failure that actually killed the step.
     */
    function lastFinishOf(attempts) {
      if (!Array.isArray(attempts)) return null;
      for (let i = attempts.length - 1; i >= 0; i -= 1) {
        const attempt = attempts[i];
        if (attempt && attempt.finish) return attempt.finish;
      }
      return null;
    }

    /**
     * Wall-clock shape of one response stream.
     *
     * Records carry either an absolute `time` (single chunk) or a `time0` plus
     * `dt[]` deltas (batched chunks), so the first and last moments the server
     * spoke are both recoverable — and therefore the gap between them. Nothing is
     * extrapolated: `spanMs` is last − first, and the delta count is reported so
     * the panel can say how many pieces the reply arrived in.
     */
    function timingOfStream(stream) {
      if (!Array.isArray(stream)) return null;
      let first = null;
      let last = null;
      let batched = 0;
      let deltas = 0;
      for (let i = 0; i < stream.length; i += 1) {
        const record = stream[i];
        if (!record || typeof record !== 'object') continue;
        let at = typeof record.time === 'number' ? record.time : null;
        if (at === null && typeof record.time0 === 'number') {
          at = record.time0;
          batched += 1;
          if (Array.isArray(record.dt)) deltas += record.dt.length;
        }
        if (at === null) continue;
        if (first === null || at < first) first = at;
        if (last === null || at > last) last = at;
      }
      if (first === null) return null;
      return {
        first: first,
        last: last,
        spanMs: Math.max(0, last - first),
        records: stream.length,
        batched: batched,
        deltas: deltas,
      };
    }

    /** A reply's text/reasoning/tool-call blocks, counted. */
    function contentStatsOf(message) {
      const blocks = message && Array.isArray(message.content) ? message.content : [];
      let textChars = 0;
      let reasoningChars = 0;
      let toolCalls = 0;
      for (let i = 0; i < blocks.length; i += 1) {
        const block = blocks[i];
        if (!block || typeof block !== 'object') continue;
        if (block.type === 'text') {
          if (typeof block.text === 'string') textChars += block.text.length;
        } else if (block.type === 'reasoning') {
          if (typeof block.text === 'string') reasoningChars += block.text.length;
          else if (typeof block.reasoning === 'string') reasoningChars += block.reasoning.length;
        } else if (block.type === 'tool-call') {
          toolCalls += 1;
        }
      }
      return { blocks: blocks.length, textChars: textChars, reasoningChars: reasoningChars, toolCalls: toolCalls };
    }

    /** The reply as the wire form a chat-completion caller would have received. */
    function responseBodyOf(message, usage, model, finish) {
      const blocks = message && Array.isArray(message.content) ? message.content : [];
      let text = '';
      let reasoning = '';
      const toolCalls = [];
      for (let i = 0; i < blocks.length; i += 1) {
        const block = blocks[i];
        if (!block || typeof block !== 'object') continue;
        if (block.type === 'text' && typeof block.text === 'string') {
          text += block.text;
        } else if (block.type === 'reasoning') {
          if (typeof block.text === 'string') reasoning += block.text;
          else if (typeof block.reasoning === 'string') reasoning += block.reasoning;
        } else if (block.type === 'tool-call') {
          toolCalls.push({
            id: block.id,
            type: 'function',
            function: {
              name: typeof block.name === 'string' ? block.name : '',
              arguments: typeof block.arguments === 'string' ? block.arguments : JSON.stringify(block.arguments),
            },
          });
        }
      }

      /* The log's vocabulary ("tool-calls", "max-tokens") is not the wire's
         ("tool_calls", "length"); translate so a copied body is usable as-is. */
      const finishMap = {
        stop: 'stop',
        'tool-calls': 'tool_calls',
        'max-tokens': 'length',
        length: 'length',
        aborted: 'aborted',
        interrupted: 'aborted',
      };
      const finishReason = finish && finish.kind ? finishMap[finish.kind] || finish.kind : null;

      const assistant = { role: 'assistant', content: text === '' ? null : text };
      if (reasoning !== '') assistant.reasoning_content = reasoning;
      if (toolCalls.length) assistant.tool_calls = toolCalls;

      const body = {};
      if (message && message.id !== undefined) body.id = message.id;
      body.object = 'chat.completion';
      body.model = model === undefined ? null : model;
      body.choices = [{ index: 0, message: assistant, finish_reason: finishReason }];
      if (usage) {
        body.usage = {
          prompt_tokens: usage.input + usage.cache,
          completion_tokens: usage.output,
          total_tokens: usage.total,
          prompt_tokens_details: { cached_tokens: usage.cache },
        };
      }
      if (finish && finish.failure) body.error = finish.failure;
      return body;
    }

    /** Milliseconds as "1.2s" / "340ms". */
    function formatMs(ms) {
      if (typeof ms !== 'number' || !Number.isFinite(ms)) return '—';
      if (ms < 1000) return Math.round(ms) + 'ms';
      if (ms < 60000) return (ms / 1000).toFixed(1) + 's';
      return (ms / 60000).toFixed(1) + 'min';
    }

    /** The Chinese label for one `finish.reason.kind`. */
    function finishLabelOf(kind) {
      if (kind === 'stop') return TEXT.finishStop;
      if (kind === 'tool-calls') return TEXT.finishToolCalls;
      if (kind === 'max-tokens' || kind === 'length') return TEXT.finishLength;
      if (kind === 'aborted' || kind === 'interrupted') return TEXT.finishAborted;
      if (kind === 'error') return TEXT.finishError;
      return TEXT.finishUnknown;
    }

    /**
     * Find the `tool/call` record that a `tool/result` answers.
     *
     * The result frequently lands in the SAME step as its call, but a Turn can
     * also carry results for calls made in an earlier step, so the lookup walks
     * every step's list rather than only the current one. Tool lists are short
     * (tens per Turn), and each result is paired exactly once.
     */
    function findToolCall(toolsByStep, callId) {
      const keys = Object.keys(toolsByStep);
      for (let i = 0; i < keys.length; i += 1) {
        const details = toolsByStep[keys[i]].details || [];
        for (let j = 0; j < details.length; j += 1) {
          if (details[j].callId === callId && !details[j].result) return details[j];
        }
      }
      return null;
    }

    /**
     * One display-ready tool call, before its result is known.
     *
     * `arguments` in the log is a JSON *string*; parsing it here lets the viewer
     * show a one-line summary (the interesting fields) instead of a quoted blob,
     * while keeping the raw string for the "full" view. A parse failure is normal
     * (a truncated streaming argument) and falls back to the raw text.
     */
    function makeToolDetail(callId, name, raw, seq, time) {
      let parsed;
      let parsedOk = false;
      if (raw && typeof raw === 'object') {
        parsed = raw;
        parsedOk = true;
      } else if (typeof raw === 'string' && raw.trim() !== '') {
        try {
          parsed = JSON.parse(raw);
          parsedOk = true;
        } catch (err) {
          parsed = undefined;
        }
      }
      return {
        callId: callId === undefined ? null : callId,
        name: typeof name === 'string' ? name : '',
        /* `arguments` exactly as the model emitted them (a string). */
        argumentsText: typeof raw === 'string' ? raw : raw === undefined ? undefined : JSON.stringify(raw),
        argumentsJson: parsedOk ? parsed : undefined,
        argumentsOk: parsedOk,
        summary: summaryOfCall(name, parsedOk ? parsed : undefined, raw),
        argumentsBytes: byteLength(typeof raw === 'string' ? raw : JSON.stringify(raw === undefined ? null : raw)),
        status: 'missing',
        durationMs: null,
        result: null,
        seq: seq,
        time: typeof time === 'number' ? time : null,
      };
    }

    /**
     * Compact, display-ready form of one step's tool traffic.
     *
     * `arguments` in the log is a JSON *string*; parsing it here lets the viewer
     * show a one-line summary (the interesting fields) instead of a quoted blob,
     * while keeping the raw string for the "full" view. A parse failure is normal
     * (truncated streaming arguments) and falls back to the raw text.
     */
    function toolCallDetailsOf(details) {
      const out = [];
      for (let i = 0; i < details.length; i += 1) {
        const call = details[i];
        const raw = call.arguments;
        let parsed;
        let parsedOk = false;
        if (raw && typeof raw === 'object') {
          parsed = raw;
          parsedOk = true;
        } else if (typeof raw === 'string' && raw.trim() !== '') {
          try {
            parsed = JSON.parse(raw);
            parsedOk = true;
          } catch (err) {
            parsed = undefined;
          }
        }
        const result = call.result;
        out.push({
          callId: call.callId === undefined ? null : call.callId,
          name: call.name,
          /* `arguments` exactly as the model emitted them (a string), so the
             panel can show the payload verbatim when asked. */
          argumentsText: typeof raw === 'string' ? raw : raw === undefined ? undefined : JSON.stringify(raw),
          argumentsJson: parsedOk ? parsed : undefined,
          argumentsOk: parsedOk,
          /* A one-line shape hint: `name(arg=value, …)` with long values cut. */
          summary: summaryOfCall(call.name, parsedOk ? parsed : undefined, raw),
          argumentsBytes: byteLength(typeof raw === 'string' ? raw : JSON.stringify(raw === undefined ? null : raw)),
          status: result ? (result.isError ? 'error' : 'ok') : 'missing',
          durationMs:
            result && typeof call.time === 'number' && typeof result.time === 'number'
              ? Math.max(0, result.time - call.time)
              : null,
          result: result
            ? {
                text: result.text,
                bytes: result.bytes,
                isError: result.isError,
                seq: result.seq,
              }
            : null,
          seq: call.seq,
        });
      }
      return out;
    }

    /** `read(path=client.js)` — the arguments' shape in one short line. */
    function summaryOfCall(name, parsed, raw) {
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        if (typeof raw === 'string' && raw.trim() !== '') return shorten(flattenContent(raw), 80);
        return '';
      }
      const keys = Object.keys(parsed);
      if (!keys.length) return '';
      const parts = [];
      for (let i = 0; i < keys.length && i < 3; i += 1) {
        const value = parsed[keys[i]];
        const shown =
          typeof value === 'string' ? shorten(value, 42) : shorten(JSON.stringify(value), 42);
        parts.push(keys[i] + '=' + shown);
      }
      if (keys.length > 3) parts.push('…');
      return parts.join(', ');
    }

    function shorten(text, limit) {
      const value = String(text === undefined || text === null ? '' : text).replace(/\s+/gu, ' ');
      return value.length > limit ? value.slice(0, limit - 1) + '…' : value;
    }

    /**
     * One message can be assembled from several records (an assistant reply plus
     * the `tool/call` entries hanging off it). For the source summary the first
     * record decides the family, and `onlyFrom` narrows it to the records written
     * by the current Turn.
     */
    function firstRecord(items, onlyFrom) {
      if (!Array.isArray(items) || !items.length) return { kind: '', family: 'other', byte: 0, seq: -1 };
      const usable =
        typeof onlyFrom === 'number'
          ? items.filter(function (item) {
              return item.seq >= onlyFrom;
            })
          : items;
      return usable.length ? usable[0] : { kind: '', family: 'other', byte: 0, seq: -1 };
    }

    /**
     * Bytes this Turn wrote into the request (the rest is carried history).
     *
     * `fromIndex` is `historyEnd`: messages before it are carried history, so the
     * scan starts there instead of walking (and filtering) the whole track. The
     * seq test stays as a safety net for a message whose first record predates the
     * Turn boundary but which the fold kept (an assistant reply completed later).
     */
    function freshBytes(track, onlyFrom, fromIndex) {
      let total = 0;
      const start = typeof fromIndex === 'number' && fromIndex > 0 ? fromIndex : 0;
      for (let i = start; i < track.length; i += 1) {
        const items = track[i];
        for (let j = 0; j < items.length; j += 1) {
          if (typeof onlyFrom === 'number' && items[j].seq < onlyFrom) continue;
          total += items[j].byte || 0;
        }
      }
      return total;
    }

    /**
     * What changed between two consecutive requests of the same Turn.
     *
     * Within a Turn the payload only ever grows at the tail: the Harness appends
     * the model's reply and the tool results, then calls again. So the cheap and
     * exact answer is the longest common prefix — everything after it is new, and
     * if the previous request is not a prefix of this one, something was rewritten
     * in place (compaction, a pruned tool result) which the viewer must say out
     * loud rather than silently mislabel as "appended".
     */
    function diffRequests(prev, next) {
      const before = Array.isArray(prev && prev.messages) ? prev.messages : [];
      const after = Array.isArray(next && next.messages) ? next.messages : [];
      const limit = Math.min(before.length, after.length);

      /* Within a Turn both requests were snapshotted from the SAME fold, so the
         previous one is a reference prefix of this one: identity (`===`) settles
         the common prefix without stringifying a single message. Falls back to
         structural equality for any pair that did not share a fold (e.g. the
         harness comparing requests rebuilt independently). */
      let common = 0;
      while (common < limit && before[common] === after[common]) common += 1;
      while (common < limit && sameMessage(before[common], after[common])) common += 1;

      /* Text fields outside `messages` (model, sampling controls, tools) — a
         changed model or a different tool list is the interesting case. The tool
         list is a large array shared by reference between steps of a Turn, so the
         identity check short-circuits it; only a genuinely different array is
         stringified. */
      const changed = [];
      const keys = Object.keys(next || {});
      for (let i = 0; i < keys.length; i += 1) {
        const key = keys[i];
        if (key === 'messages') continue;
        const a = prev ? prev[key] : undefined;
        const b = next[key];
        if (a === b) continue;
        if (stableJSON(a) !== stableJSON(b)) changed.push(key);
      }

      /* Anything the previous request had that this one does not, or that sits
         before the prefix break, was rewritten rather than appended. Cheap case
         first: when the previous fold is a reference prefix nothing was removed. */
      let removed = 0;
      if (common < before.length) {
        for (let i = common; i < before.length; i += 1) {
          if (before[i] !== after[i] && !sameMessage(before[i], after[i])) removed += 1;
        }
      }

      return {
        /* The index where the new tail starts in THIS request — the JSON view
           bands every message from here on, so this is the only number the
           presentation needs. */
        prefix: common,
        /* How many messages were appended since the previous call. */
        added: after.length - common,
        removed: removed,
        rewritten: common < limit && before[common] !== after[common] && !sameMessage(before[common], after[common]),
        changed: changed,
        prevMessages: before.length,
      };
    }

    function stableJSON(value) {
      try {
        return JSON.stringify(value === undefined ? null : value);
      } catch (error) {
        return null;
      }
    }

    function sameMessage(a, b) {
      if (a === b) return true;
      if (!a || !b || a.role !== b.role) return false;
      return (
        stableJSON(a.content) === stableJSON(b.content) &&
        stableJSON(a.tool_calls) === stableJSON(b.tool_calls) &&
        a.tool_call_id === b.tool_call_id
      );
    }

    /* ------------------------------------------------------------------
     * Diff row summaries.
     *
     * Flattening `content` and taking its first 96 characters produced rows that
     * all began with the same envelope:
     *
     *   {"type":"tool-call","id":"call_00_avGlXSgIoblMAYhTaOC52649","name":"pwsh","arguments":"{\"comman…
     *
     * 56 characters of boilerplate, then the useful part cut off. These helpers
     * pull out what the row is actually about: which tools were called and with
     * what arguments, what a tool result said, or the user's own words.
     * ------------------------------------------------------------------ */

    /** Text of a message's content, whether it is a string or content blocks. */
    function messageText(message) {
      let text = message && message.content;
      if (Array.isArray(text)) {
        const parts = [];
        for (let i = 0; i < text.length; i += 1) {
          const part = text[i];
          if (!part || typeof part !== 'object') continue;
          if (typeof part.text === 'string') parts.push(part.text);
          else if (part.type === 'tool-call' && part.name) parts.push(part.name);
          else if (typeof part.type === 'string') parts.push('[' + part.type + ']');
        }
        text = parts.join(' ');
      }
      if (typeof text !== 'string') text = '';
      return text.replace(/\s+/g, ' ').trim();
    }

    /** `{"command":"git status","description":"…"}` -> `git status`. */
    function argumentHint(raw) {
      let parsed = raw;
      if (typeof raw === 'string') {
        try { parsed = JSON.parse(raw); } catch (error) { parsed = null; }
      }
      if (!parsed || typeof parsed !== 'object') return '';
      const order = [
        'command', 'file_path', 'path', 'pattern', 'query', 'glob', 'url',
        'description', 'prompt', 'name', 'action', 'session_id', 'target',
      ];
      for (let i = 0; i < order.length; i += 1) {
        const value = parsed[order[i]];
        if (typeof value === 'string' && value.trim()) {
          const flat = value.replace(/\s+/g, ' ').trim();
          return flat.length > 70 ? flat.slice(0, 70) + '…' : flat;
        }
      }
      /* None of the well-known keys: fall back to the first non-empty string. */
      const keys = Object.keys(parsed);
      for (let i = 0; i < keys.length; i += 1) {
        const value = parsed[keys[i]];
        if (typeof value === 'string' && value.trim()) {
          const flat = value.replace(/\s+/g, ' ').trim();
          return flat.length > 70 ? flat.slice(0, 70) + '…' : flat;
        }
      }
      return '';
    }

    /** A message's `tool_calls`, from either the OpenAI shape or content blocks. */
    function toolCallsOf(message) {
      const calls = [];
      const seen = new Set();
      const push = (name, args) => {
        /* Both representations carry the same call (the content block is a copy
           of the structured one), so dedupe — otherwise "1 tool call" reads as 2. */
        const key = String(name || '?') + '\u0000' + stableJSON(args);
        if (seen.has(key)) return;
        seen.add(key);
        calls.push({ name: name || '?', args: args });
      };
      const direct = message && message.tool_calls;
      if (Array.isArray(direct)) {
        for (let i = 0; i < direct.length; i += 1) {
          const call = direct[i] || {};
          const fn = call.function || call;
          push(fn.name, fn.arguments !== undefined ? fn.arguments : fn.input);
        }
      }
      const content = message && message.content;
      if (Array.isArray(content)) {
        for (let i = 0; i < content.length; i += 1) {
          const part = content[i];
          if (part && part.type === 'tool-call') {
            push(part.name, part.arguments !== undefined ? part.arguments : part.input);
          }
        }
      } else if (typeof content === 'string' && content.indexOf('"type":"tool-call"') !== -1) {
        try {
          const parsed = JSON.parse(content);
          const list = Array.isArray(parsed) ? parsed : [parsed];
          for (let i = 0; i < list.length; i += 1) {
            const part = list[i];
            if (part && part.type === 'tool-call') {
              push(part.name, part.arguments !== undefined ? part.arguments : part.input);
            }
          }
        } catch (error) { /* not JSON, just text that mentions tool-call */ }
      }
      return calls;
    }

    function clip(text, max) {
      if (typeof text !== 'string') return '';
      return text.length > max ? text.slice(0, max) + '…' : text;
    }

    /**
     * One-line description of a message: "pwsh · git status", "read · client.js",
     * "edit → updated successfully". Falls back to the flattened text.
     */
    function describeMessage(message) {
      const role = message && message.role;
      const calls = toolCallsOf(message);
      if (calls.length === 1) {
        const args = argumentHint(calls[0].args);
        return calls[0].name + (args ? ' · ' + args : '');
      }
      if (calls.length > 1) {
        const names = calls.map((call) => call.name);
        const unique = names.filter((name, index) => names.indexOf(name) === index);
        const shown = unique.slice(0, 3).join(', ') + (unique.length > 3 ? '…' : '');
        return calls.length + ' ' + TEXT.diffTools + ': ' + shown;
      }
      const text = messageText(message);
      if (role === 'user') {
        /* Drop the harness's own prompt scaffolding so the user's words lead. */
        return clip(text.replace(/^(Time sampled while preparing|Current runtime context|The following skills).*/s, '').trim() || text, 160) || '（空）';
      }
      if (role === 'tool') return clip(text, 160) || '（空）';
      if (role === 'assistant' || role === 'system' || role === 'developer') return clip(text, 160) || '（空）';
      return clip(text, 160) || '（空）';
    }

    /** First line of a message's text, for the "what got appended" list. */
    function headOf(message) {
      return describeMessage(message);
    }

    /**
     * The seq span a Turn occupies: `[start, end]`, with `end` the Turn's own end
     * marker or the seq just before the next Turn starts.
     *
     * Used as the cache key, because a Turn's requests can only be built from the
     * events inside that span (plus the headers before it). Keying on the whole
     * window's last seq instead meant every new event anywhere in the session
     * invalidated every cached Turn: in a 93-Turn session the rebuild cache was
     * cold every single time, so re-opening a Turn you just looked at re-walked
     * and re-folded the entire conversation.
     */
    function turnBounds(events, turnNumber) {
      let start = -1;
      let end = -1;
      for (let i = 0; i < events.length; i += 1) {
        const event = events[i];
        if (typeOf(event) !== 'turn/start') continue;
        if (dataOf(event).turn !== turnNumber) continue;
        start = seqOf(event);
        break;
      }
      if (start < 0) return null;
      for (let i = 0; i < events.length; i += 1) {
        const event = events[i];
        const seq = seqOf(event);
        if (seq <= start) continue;
        const type = typeOf(event);
        if (type === 'turn/end' && dataOf(event).turn === turnNumber) {
          end = seq;
          break;
        }
        if (type === 'turn/start') {
          end = seq - 1;
          break;
        }
      }
      return { start: start, end: end };
    }

    /**
     * Page the whole Client event window in, then flatten it to records.
     *
     * Takes `binding` (`{ session, eventSource }`) rather than a session id, so a
     * Node test can drive real paging shapes without a live Host.
     *
     * Two verbs exist for walking backwards:
     *   `loadOlder()`    — one Host-selected page, published immediately.
     *   `loadThrough(n)` — a jump: keeps paging privately, uses larger pages, and
     *                      publishes ONE ordered prepend once the window covers
     *                      seq n (repeats share one in-flight jump).
     *
     * The reader is waiting for a dialog, not for the transcript, so the jump is
     * the right verb: target 0 means "the whole conversation", which turns a
     * 40-page publish storm — 40 re-renders of the conversation behind the dialog —
     * into a single update. `loadOlder()` stays as the completion pass and as the
     * fallback for a jump that gave up on a page with no progress.
     */
    async function loadFullWindow(binding) {
      if (!binding) throw new Error('session is not bound');
      const session = binding.session;
      const source = binding.eventSource;
      const snapshotOf = () =>
        source && typeof source.getSnapshot === 'function' ? source.getSnapshot() : null;
      const entriesOf = (snapshot) => (snapshot && Array.isArray(snapshot.entries) ? snapshot.entries : []);

      let snapshot = snapshotOf();

      if (snapshot && snapshot.hasMore === true && session && typeof session.loadThrough === 'function') {
        try {
          await session.loadThrough(0);
        } catch (error) {
          /* A failed or refused jump keeps whatever it already published; the loop
             below finishes the walk instead of failing the whole open. */
        }
        snapshot = snapshotOf() || snapshot;
      }

      let guard = 0;
      while (
        snapshot &&
        snapshot.hasMore === true &&
        guard < 200 &&
        session &&
        typeof session.loadOlder === 'function'
      ) {
        guard += 1;
        const before = entriesOf(snapshot).length;
        await session.loadOlder();
        snapshot = snapshotOf();
        if (!snapshot) break;
        if (entriesOf(snapshot).length <= before) break;
      }

      return collectEvents(entriesOf(snapshot));
    }

    /** Locate the assistant message an action row belongs to. */
    function locateMessage(events, messageId) {
      for (let i = events.length - 1; i >= 0; i -= 1) {
        const event = events[i];
        if (typeOf(event) !== 'assistant/message') continue;
        const data = dataOf(event);
        if (!data.message || data.message.id !== messageId) continue;
        return { turn: data.turn, step: data.step };
      }
      return null;
    }

    /** The call a step produced — one model call per step. */
    function callIndexForStep(built, step) {
      if (!built || !Array.isArray(built.calls)) return 0;
      for (let i = 0; i < built.calls.length; i += 1) {
        const item = built.calls[i];
        if (item && item.meta && item.meta.step === step) return i;
      }
      return 0;
    }

    /* Test hook: lets a Node harness drive the request pipeline against a real
       session log. Inert in the Web UI, where the global is never set. */
    if (typeof globalThis !== 'undefined' && globalThis.__DSH_PAYLOAD_TEST__ === true) {
      globalThis.__DSH_PAYLOAD_INTERNALS__ = {
        collectEvents: collectEvents,
        buildMessages: buildMessages,
        buildTurnCalls: buildTurnCalls,
        buildTurnCallsChunked: buildTurnCallsChunked,
        builtWeight: builtWeight,
        cacheStats: cacheStats,
        rememberBuilt: rememberBuilt,
        diffRequests: diffRequests,
        summarizeSources: summarizeSources,
        byteLength: byteLength,
        locateMessage: locateMessage,
        loadFullWindow: loadFullWindow,
        turnBounds: turnBounds,
        callIndexForStep: callIndexForStep,
        describeMessage: describeMessage,
        DialogBody: DialogBody,
        revealTop: revealTop,
        /* The boundary is declared after this hook (it needs the classes above),
           so hand out a thunk instead of touching the class early. */
        boundary: function boundary() {
          return DialogBoundary;
        },
        Timeline: Timeline,
        ResponsePanel: ResponsePanel,
        finishOfStream: finishOfStream,
        timingOfStream: timingOfStream,
        contentStatsOf: contentStatsOf,
        responseBodyOf: responseBodyOf,
        publishDialog: publishDialog,
      };
    }

    // ---------------------------------------------------------------- the plugin

    /**
     * ONE dialog for every button.
     *
     * A button publishes a payload here and the `shell.overlay` entry renders
     * it. That is deliberate: the overlay lives at frame level, outside every
     * column and scroll container, so the modal cannot inherit a clipping or
     * stacking context from the conversation it was opened from.
     */
    let dialogPayload = null;
    let dialogSerial = 0;
    /* Identifies one open attempt, so a read that lands after the user closed the
       dialog (or opened a different message) cannot republish itself. */
    let dialogToken = 0;
    const dialogListeners = new Set();
    function publishDialog(next) {
      dialogPayload = next ? Object.assign({ id: (dialogSerial += 1) }, next) : null;
      dialogListeners.forEach(function (listener) {
        try {
          listener();
        } catch (err) {
          /* one broken listener must not strand the dialog */
        }
      });
    }

    function subscribeDialog(listener) {
      dialogListeners.add(listener);
      return function () {
        dialogListeners.delete(listener);
      };
    }

    /**
     * Scroll the conversation to one message's bubble.
     *
     * The chat plugin publishes each rendered row under `data-chat-node-key`
     * (the same string `messageLinkOf` builds) and every Turn root under
     * `data-chat-turn`. A row inside a collapsed Turn is not in the DOM, so the
     * precise key is tried first and the Turn is the honest fallback; if neither
     * is mounted the click is simply a no-op.
     */
    function scrollConversationTo(link) {
      if (!link || typeof link.key !== 'string') return;
      if (typeof document === 'undefined' || !document) return;
      const find = (selector) => {
        try {
          return document.querySelector(selector);
        } catch (err) {
          return null;
        }
      };
      let row = find('[data-chat-node-key="' + link.key.replace(/"/g, '\\"') + '"]');
      if (!row && typeof link.turn === 'number') row = find('[data-chat-turn="' + link.turn + '"]');
      if (!row) return;
      try {
        row.scrollIntoView({ block: 'center', behavior: 'smooth' });
      } catch (err) {
        /* older engines: fall back to a plain jump */
        try {
          row.scrollIntoView();
        } catch (err2) {
          /* nothing else to do */
        }
      }
    }

    /**
     * Where the payload pane's scrollTop should land to reveal `target`.
     *
     * Pure arithmetic, kept out of the effect that uses it so it can be asserted
     * without a browser: 24 px of air is right in a short pane and far too little
     * in a tall one, a quarter of the viewport is right in a tall pane and too
     * much in a short one, and the result never goes negative.
     */
    function revealTop(node, target) {
      const height = node && typeof node.clientHeight === 'number' ? node.clientHeight : 0;
      const air = Math.max(24, height * 0.25);
      const base = node && typeof node.scrollTop === 'number' ? node.scrollTop : 0;
      /* Measure both boxes in one pass: a difference of client rects does not care
         which ancestor happens to be positioned, while `offsetTop` would silently
         be relative to whichever one is. */
      let delta = null;
      if (
        node &&
        target &&
        typeof node.getBoundingClientRect === 'function' &&
        typeof target.getBoundingClientRect === 'function'
      ) {
        delta = target.getBoundingClientRect().top - node.getBoundingClientRect().top;
      } else if (node && target && typeof target.offsetTop === 'number' && typeof node.offsetTop === 'number') {
        delta = target.offsetTop - node.offsetTop;
      }
      const top = delta === null ? 0 : base + delta - air;
      return top > 0 ? top : 0;
    }

    /** Rebuilding a payload walks the whole window, so keep it per (session, turn, window end). */
    const builtCache = new Map();
    /*
     * Two caps, because until now there was one and it was blind: a rebuilt Turn
     * of a long conversation keeps every message of the window alive (measured
     * ~18.5 MB per Turn on a 21 k-record window; the widest Turn, 6 780 messages
     * across 117 calls, costs ~32 MB), so "40 entries" can mean three quarters of
     * a gigabyte of retained heap — enough for the browser to start collecting
     * while the reader is scrolling what was just opened.
     *   - entries: still bounded, so a session full of tiny Turns cannot pile up
     *     thousands of map entries;
     *   - bytes: the cap that matters. The oldest entries go until the cache
     *     fits its budget.
     */
    const BUILT_CACHE_LIMIT = 40;
    const BUILT_CACHE_BYTES = 200 * 1024 * 1024;
    let builtCacheBytes = 0;

    /**
     * Roughly how many bytes one rebuilt Turn keeps alive.
     *
     * Not a measurement — a cheap estimate, and a deliberately pessimistic one.
     * The strings and message objects are SHARED between calls (each call's
     * `messages` is a prefix of the next), so only the widest array is walked and
     * what stays per-call is its own array and request wrapper. Counting payload
     * at two bytes per UTF-16 code unit over-states ASCII, and the 1.2 factor on
     * top covers the bookkeeping this walk does not visit (per-message `track`
     * and `links` arrays, each call's source accumulators).
     *
     * Calibrated against the real thing: on a 21 k-record session the estimate
     * landed at 1.03–1.65× the heap a Turn actually retained, so the budget errs
     * towards evicting early rather than too late.
     */
    function builtWeight(built) {
      const calls = built && Array.isArray(built.calls) ? built.calls : [];
      let slots = 0;
      let widest = null;
      for (let i = 0; i < calls.length; i += 1) {
        const request = calls[i] && calls[i].request ? calls[i].request : null;
        const messages = request && Array.isArray(request.messages) ? request.messages : [];
        slots += messages.length;
        if (!widest || messages.length > widest.length) widest = messages;
      }
      let bytes = slots * 8 + calls.length * 1024;
      if (widest) {
        for (let i = 0; i < widest.length; i += 1) {
          const message = widest[i];
          if (!message || typeof message !== 'object') continue;
          bytes += 160;
          const content = message.content;
          if (typeof content === 'string') bytes += content.length * 2;
          else if (Array.isArray(content)) {
            for (let j = 0; j < content.length; j += 1) {
              const part = content[j];
              if (part && typeof part.text === 'string') bytes += part.text.length * 2;
            }
          }
          if (Array.isArray(message.tool_calls)) bytes += message.tool_calls.length * 256;
        }
      }
      return Math.round(bytes * 1.2);
    }

    /** What the cache currently holds, so a test can assert the budget instead of trusting it. */
    function cacheStats() {
      return { entries: builtCache.size, bytes: builtCacheBytes, budget: BUILT_CACHE_BYTES };
    }

    /*
     * Cache a rebuild, keyed so a Turn that is still growing cannot serve stale
     * calls.
     *
     * Eviction is least-recently-used under both caps above, not "clear all 40".
     * A rebuilt Turn holds every message of the conversation, so a wipe is a real
     * re-read of the whole window; flipping between two Turns in a long session
     * used to be able to throw away everything and rebuild from scratch.
     * Re-inserting refreshes recency, so a Turn opened twice in a row stays warm.
     * The cache always keeps the entry just inserted, even when that single Turn
     * is over budget — dropping it would make every open of that Turn a rebuild.
     */
    function rememberBuilt(key, built) {
      const known = builtCache.get(key);
      if (known) {
        builtCacheBytes -= known.weight;
        builtCache.delete(key);
      }
      const weight = builtWeight(built);
      builtCache.set(key, { built: built, weight: weight });
      builtCacheBytes += weight;
      while (
        builtCache.size > 1 &&
        (builtCache.size > BUILT_CACHE_LIMIT || builtCacheBytes > BUILT_CACHE_BYTES)
      ) {
        const oldest = builtCache.keys().next();
        if (oldest.done) break;
        const entry = builtCache.get(oldest.value);
        builtCache.delete(oldest.value);
        builtCacheBytes -= entry && typeof entry.weight === 'number' ? entry.weight : 0;
      }
    }

    /* The trigger copies the shipped per-message action buttons exactly — 28px hit
       area, `radius-sm`, `label-tertiary` at rest, `interactive-bg-hover` on hover —
       and its label is a bubble with the same tokens as the design system's own
       tooltip (`alias-tooltip-bg` + `neutral-bluish-00`, 13/20) so it does not read
       as a foreign widget. */
    const ACTION_STYLE_ID = 'dsh-payload-action-css';
    const ACTION_CSS = [
      '.dsh-pl-action{position:relative;display:inline-flex;align-items:center;justify-content:center;',
      'width:28px;height:28px;margin:0;padding:6px;box-sizing:border-box;border:0;',
      'border-radius:var(--dsw-radius-sm,8px);background:transparent;',
      'color:var(--dsw-alias-label-tertiary,#81858c);cursor:pointer;',
      'transition:background-color .12s ease,color .12s ease}',
      '.dsh-pl-action:hover{background:var(--dsw-alias-interactive-bg-hover,#2631480f);',
      'color:var(--dsw-alias-label-secondary,#5b6472)}',
      '.dsh-pl-action:focus-visible{outline:var(--dsw-focus-ring-width,2px) solid ',
      'var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary,#2f6fed));outline-offset:2px}',
      '.dsh-pl-icon{display:block;width:15px;height:15px}',
      /* Fixed, not absolute: the label must survive the message scroller clipping it. */
      '.dsh-pl-tip{position:fixed;z-index:1100;display:inline-flex;align-items:center;',
      'width:max-content;max-width:min(50vw,calc(100vw - 24px));box-sizing:border-box;',
      'padding:3px 7px;border-radius:var(--dsw-radius-sm,8px);',
      'background:var(--dsw-alias-tooltip-bg,#2c2c2e);color:var(--dsw-static-neutral-bluish-00,#ffffff);',
      'font-family:inherit;font-size:13px;line-height:20px;font-weight:400;',
      'white-space:nowrap;pointer-events:none;animation:dsh-pl-tip-in .15s ease-out}',
      '@keyframes dsh-pl-tip-in{0%{opacity:0}100%{opacity:1}}',
      /* Hover affordances for the dialog chrome: inline styles cannot express them,
         and a modal whose controls do not react on hover reads as a foreign window. */
      '.dsh-pl-btn:hover{background:var(--dsw-alias-interactive-bg-hover,#2631480f);',
      'border-color:var(--dsw-alias-border-l2,rgba(127,127,127,.5))}',
      '.dsh-pl-btn:active{background:var(--dsw-alias-interactive-bg-hover,#2631480f)}',
      '.dsh-pl-btn:focus-visible{outline:var(--dsw-focus-ring-width,2px) solid ',
      'var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary,#2f6fed));outline-offset:2px}',
      '.dsh-pl-step:not(.dsh-pl-step-on):hover{background:var(--dsw-alias-interactive-bg-hover,#2631480f)}',
      '.dsh-pl-step:focus-visible{outline:var(--dsw-focus-ring-width,2px) solid ',
      'var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary,#2f6fed));outline-offset:-2px}',
      /* The 请求 / 响应 pair inside a step row: only the half that is not already
         selected needs a hover affordance. */
      '.dsh-pl-side:not(.dsh-pl-side-on):hover{background:var(--dsw-alias-interactive-bg-hover,#2631480f);',
      'color:var(--dsw-alias-label-primary,#111827)}',
      '.dsh-pl-side:focus-visible{outline:var(--dsw-focus-ring-width,2px) solid ',
      'var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary,#2f6fed));outline-offset:2px}',
      /* A side with nothing behind it (the call never got a reply) reads as muted. */
      '.dsh-pl-side-off{opacity:.55}',
      /* The card/row body is itself a button; it must not paint its own frame. */
      '.dsh-pl-stephit:focus-visible{outline:var(--dsw-focus-ring-width,2px) solid ',
      'var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary,#2f6fed));',
      'outline-offset:2px;border-radius:var(--dsw-radius-sm,8px)}',
      /* The source legend's family chips are navigation pills, not list rows:
         they borrow the hover rules but must not be counted as step-list rows. */
      '.dsh-pl-pill{border-radius:var(--dsw-radius-sm,8px)}',
      '.dsh-pl-pill:not(.dsh-pl-pill-on):hover{background:var(--dsw-alias-interactive-bg-hover,#2631480f)}',
      '.dsh-pl-pill:focus-visible{outline:var(--dsw-focus-ring-width,2px) solid ',
      'var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary,#2f6fed));outline-offset:2px}',
      /* A 100k-line payload needs a scrollbar that never fades out, but it should
         not look like a 2005 IDE either: 10px, no painted track, a neutral thumb
         that only darkens on hover. Colours come from the dialog's own palette
         through custom properties (see PALETTES), never from a raw hex. */
      '.dsh-pl-scroll{scrollbar-gutter:stable;scrollbar-width:thin;',
      'scrollbar-color:var(--dsh-pl-sb-thumb,rgba(127,127,127,.30)) transparent}',
      '.dsh-pl-scroll::-webkit-scrollbar{width:10px;height:10px}',
      '.dsh-pl-scroll::-webkit-scrollbar-track{background:transparent}',
      '.dsh-pl-scroll::-webkit-scrollbar-thumb{',
      'border:2px solid transparent;background-clip:padding-box;border-radius:var(--dsw-radius-sm,8px);',
      'background-color:var(--dsh-pl-sb-thumb,rgba(127,127,127,.30));',
      'transition:background-color .12s ease}',
      '.dsh-pl-scroll::-webkit-scrollbar-thumb:hover{',
      'background-color:var(--dsh-pl-sb-thumb-hover,rgba(127,127,127,.46));',
      'border:2px solid transparent;background-clip:padding-box}',
      '.dsh-pl-scroll::-webkit-scrollbar-thumb:active{',
      'background-color:var(--dsh-pl-sb-thumb-active,rgba(127,127,127,.34));',
      'border:2px solid transparent;background-clip:padding-box}',
      '.dsh-pl-scroll::-webkit-scrollbar-corner{background:transparent}',
      /* Loading spinner. A transform animation is handed to the compositor, so it
         keeps turning while the main thread is blocked — which is precisely the
         moment the seconds counter cannot repaint and the dialog looks hung.
         Declared before the reduced-motion block below, so that block's override
         wins on source order (a media query adds no specificity). */
      '.dsh-pl-spin{display:inline-block;flex:none;width:11px;height:11px;box-sizing:border-box;',
      'border:2px solid currentColor;border-top-color:transparent;border-radius:50%;',
      'animation:dsh-pl-spin .8s linear infinite}',
      '@keyframes dsh-pl-spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}',
      /* The shipped surfaces drop their transitions when the OS asks for it. */
      '@media (prefers-reduced-motion:reduce){',
      '.dsh-pl-scroll::-webkit-scrollbar-thumb,.dsh-pl-action,.dsh-pl-btn,.dsh-pl-pill,',
      '.dsh-pl-side,.dsh-pl-step,.dsh-pl-jump{transition:none}',
      '.dsh-pl-tip{animation:none}',
      '.dsh-pl-spin{animation:dsh-pl-pulse 1.6s ease-in-out infinite}',
      '@keyframes dsh-pl-pulse{0%,100%{opacity:.4}50%{opacity:.95}}}',

      /* Jump-to-conversation chip: always in flow, so a row never shifts on hover. */
      '.dsh-pl-jump{display:inline-flex;align-items:center;gap:3px;margin-left:8px;padding:0 8px;',
      'height:20px;box-sizing:border-box;',
      'border:0.5px solid var(--dsw-alias-border-l4,var(--dsw-alias-border-l1,rgba(127,127,127,.35)));',
      'border-radius:var(--dsw-radius-sm,8px);background:var(--dsw-alias-bg-overlay,rgba(255,255,255,.6));',
      'color:var(--dsw-alias-label-secondary,#5b6472);font-family:inherit;font-size:12px;',
      'line-height:16px;cursor:pointer;vertical-align:middle}',
      '.dsh-pl-jump:hover{color:var(--dsw-alias-brand-primary,#2f6fed);',
      'border-color:var(--dsw-alias-brand-primary,#2f6fed)}',
    ].join('');

    /** Install the trigger stylesheet once; failure only costs cosmetics. */
    function ensureActionStyle() {
      try {
        if (typeof document === 'undefined' || !document) return;
        if (document.getElementById(ACTION_STYLE_ID)) return;
        const style = document.createElement('style');
        style.id = ACTION_STYLE_ID;
        style.textContent = ACTION_CSS;
        (document.head || document.documentElement).appendChild(style);
      } catch (err) {
        /* cosmetic only */
      }
    }

    const MAX_STRING_CHARS = 320;
    const EXPAND_ALL_DEPTH = 6;

    /* How much of a tool result to show inline before truncating with a byte note.
       The full text stays in the copied JSON, so this only bounds one screen. */
    const TOOL_RESULT_PREVIEW = 2000;
    /* Label above a tool call's result block, keyed by the pairing status. */
    const DETAIL_RESULT_LABEL = { ok: '结果', error: '错误', missing: '没有结果记录' };

    /*
     * JSON syntax colours are the one place the alias-token set is too coarse
     * (it has a single accent), so the tree carries its own small palette per
     * colour scheme. GitHub-ish, deliberately not "black keys + green strings".
     */
    const PALETTES = {
      light: {
        key: '#8250df',
        string: '#1163c7',
        number: '#a3541b',
        bool: '#bf3989',
        nil: '#6e7781',
        punct: '#8c959f',
        toggle: '#8250df',
        /* Scrollbar: alpha over the pane background, so contrast never depends on
           which alias token happens to be near the surface colour. */
        scTrack: 'transparent',
        scThumb: 'rgba(15,23,42,0.30)',
        scThumbHover: 'rgba(15,23,42,0.46)',
        scThumbActive: 'rgba(15,23,42,0.34)',
        /* Accent for messages produced in the turn being inspected, so the eye
           finds them without reading a single role name. */
        currentBorder: '#2f6fed',
        currentBg: 'rgba(47,111,237,0.07)',
        /* Messages this call appended on top of the previous one: green reads as
           "added" (the convention every diff view uses) and stays clear of the
           blue turn rail and of the tool-status colours. */
        freshBorder: '#1a7f37',
        freshBg: 'rgba(26,127,55,0.06)',
        /* Source families, in the order the bar stacks them. */
        famPrompt: '#2f6fed',
        famInjected: '#b26a00',
        famModel: '#8250df',
        famTool: '#1a7f37',
        famOther: '#8c959f',
        /* Tool round-trip status: success / failure / no result recorded. */
        toolOk: '#1a7f37',
        toolOkBg: 'rgba(26,127,55,0.10)',
        toolErr: '#cf222e',
        toolErrBg: 'rgba(207,34,46,0.10)',
        toolMiss: '#8c959f',
        toolMissBg: 'rgba(140,149,159,0.12)',
      },
      dark: {
        key: '#d2a8ff',
        string: '#79c0ff',
        number: '#ffa657',
        bool: '#ff9bce',
        nil: '#8b949e',
        punct: '#6e7681',
        toggle: '#d2a8ff',
        scTrack: 'transparent',
        scThumb: 'rgba(255,255,255,0.28)',
        scThumbHover: 'rgba(255,255,255,0.44)',
        scThumbActive: 'rgba(255,255,255,0.32)',
        currentBorder: '#5a8cff',
        currentBg: 'rgba(90,140,255,0.13)',
        freshBorder: '#3fb950',
        freshBg: 'rgba(63,185,80,0.12)',
        famPrompt: '#5a8cff',
        famInjected: '#d29922',
        famModel: '#d2a8ff',
        famTool: '#3fb950',
        famOther: '#6e7681',
        toolOk: '#3fb950',
        toolOkBg: 'rgba(63,185,80,0.14)',
        toolErr: '#f85149',
        toolErrBg: 'rgba(248,81,73,0.14)',
        toolMiss: '#6e7681',
        toolMissBg: 'rgba(110,118,129,0.18)',
      },
    };

    /* Compact form for tab strips: 80285 -> "80.3k". */
    function formatTokens(value) {
      if (typeof value !== 'number' || !isFinite(value)) return '-';
      if (value >= 1e6) return (value / 1e6).toFixed(2) + 'M';
      if (value >= 1e4) return (value / 1e3).toFixed(1) + 'k';
      return String(Math.round(value));
    }

    /* Byte size of a rebuilt payload: 4123456 -> "3.9 MB". Never tokens. */
    function formatBytes(value) {
      if (typeof value !== 'number' || !isFinite(value) || value <= 0) return '-';
      if (value >= 1024 * 1024) return (value / (1024 * 1024)).toFixed(1) + ' MB';
      if (value >= 1024) return (value / 1024).toFixed(0) + ' KB';
      return value + ' B';
    }

    /* Round-trip time of one tool call: 21 -> "21ms", 1281 -> "1.3s". */
    function formatDuration(ms) {
      if (typeof ms !== 'number' || !isFinite(ms) || ms < 0) return '-';
      if (ms < 1000) return Math.round(ms) + 'ms';
      if (ms < 60000) return (ms / 1000).toFixed(1) + 's';
      return Math.floor(ms / 60000) + 'm' + Math.round((ms % 60000) / 1000) + 's';
    }

    /* Result text is shown inline while unfolded; keep one row from turning into
       a multi-megabyte paste. The full text is still in the copyable JSON. */
    function clampText(text) {
      const value = typeof text === 'string' ? text : text === undefined || text === null ? '' : String(text);
      if (value.length <= TOOL_RESULT_PREVIEW) return value;
      return value.slice(0, TOOL_RESULT_PREVIEW) + '\n… (' + formatBytes(byteLength(value) - TOOL_RESULT_PREVIEW) + ' more)';
    }

    /* Exact form for the detail line: 80285 -> "80,285". */    function formatExact(value) {
      if (typeof value !== 'number' || !isFinite(value)) return '-';
      const rounded = Math.round(value);
      const text = String(rounded);
      let out = '';
      for (let i = 0; i < text.length; i += 1) {
        const fromEnd = text.length - i;
        out += text[i];
        if (fromEnd > 1 && fromEnd % 3 === 1) out += ',';
      }
      return out;
    }

    /*
     * The provider reports the usage of the call it answered, so this is the
     * billed/consumed figure, not an estimate from the prompt text:
     *   inputTokens       prompt tokens actually sent (non-cached part)
     *   cacheReadTokens   prompt tokens served from the prompt cache
     *   outputTokens      tokens generated by the model
     *   totalTokens       the provider's total (input + cacheRead + output)
     */
    function normalizeUsage(raw) {
      if (!raw || typeof raw !== 'object') return null;
      const input = typeof raw.inputTokens === 'number' ? raw.inputTokens : 0;
      const cacheRead = typeof raw.cacheReadTokens === 'number' ? raw.cacheReadTokens : 0;
      const output = typeof raw.outputTokens === 'number' ? raw.outputTokens : 0;
      const total =
        typeof raw.totalTokens === 'number'
          ? raw.totalTokens
          : (typeof raw.inputTokens === 'number' ? input : 0) +
            (typeof raw.outputTokens === 'number' ? output : 0) +
            (typeof raw.cacheReadTokens === 'number' ? cacheRead : 0);
      const promptTokens = input + cacheRead;
      return {
        input: input,
        cache: cacheRead,
        output: output,
        total: total,
        hitRate: promptTokens > 0 ? cacheRead / promptTokens : null,
      };
    }

    function copyText(value, done) {
      const nav = typeof navigator !== 'undefined' ? navigator : undefined;
      if (!value || !nav || !nav.clipboard || typeof nav.clipboard.writeText !== 'function') return;
      nav.clipboard.writeText(value).then(done, function () {});
    }

    // ------------------------------------------------------------ JSON tree

    /** The red-rimmed pill used for "this payload is not a plain append". */
    function warnPill(pal) {
      return Object.assign({}, STYLE.jsonBadge, {
        color: pal.toolErr,
        borderColor: pal.toolErr,
        background: pal.toolErrBg,
      });
    }

    function valueStyle(value, pal) {
      if (typeof value === 'string') return { color: pal.string };
      if (typeof value === 'number') return { color: pal.number };
      if (typeof value === 'boolean') return { color: pal.bool, fontWeight: 600 };
      return { color: pal.nil, fontStyle: 'italic' };
    }

    function literalOf(value) {
      if (typeof value === 'string') {
        const clipped =
          value.length > MAX_STRING_CHARS
            ? value.slice(0, MAX_STRING_CHARS) + '… (＋' + (value.length - MAX_STRING_CHARS) + ' chars)'
            : value;
        return JSON.stringify(clipped);
      }
      return String(value);
    }

    /**
     * The older part of a `messages` array, folded into one line. Folding is pure
     * presentation: the children keep their real array indices, so expanding the
     * group — or copying the payload — never changes what was actually sent.
     */
    function JsonHistoryGroup(props) {
      const depth = props.depth;
      const items = props.items;
      const offset = props.offset || 0;
      const pal = props.pal || PALETTES.light;
      const mode = props.mode;
      const links = Array.isArray(props.links) ? props.links : null;
      const onJump = props.onJump;
      const indentation = { paddingLeft: depth * 14 + 'px' };
      const [open, setOpen] = React.useState(mode === 'all');

      const head = h(
        'div',
        {
          style: Object.assign({}, STYLE.jsonLine, STYLE.jsonClickable, STYLE.jsonFoldedHead, indentation),
          onClick: () => setOpen(!open),
          title: TEXT.historyTitle,
        },
        h(
          'span',
          { key: 't', style: { display: 'inline-block', width: '14px', color: pal.toggle, fontWeight: 700 } },
          open ? '▾' : '▸',
        ),
        h('span', { key: 'l', style: { color: pal.key, fontWeight: 600 } }, TEXT.historyGroup),
        h('span', { key: 'n', style: { color: pal.punct } }, ' (' + items.length + ')'),
        open
          ? null
          : h('span', { key: 'f', style: { marginLeft: '6px', color: pal.nil, fontSize: T.font.caption } }, TEXT.folded),
      );

      if (!open) return head;

      return h(
        'div',
        { style: STYLE.jsonNode },
        head,
        h(
          'div',
          { key: 'c', style: STYLE.jsonGuide },
          items.map((item, index) =>
            h(JsonNode, {
              key: offset + index,
              name: String(offset + index),
              value: item,
              depth: depth + 1,
              mode: mode,
              pal: pal,
              jump: links ? links[index] || null : null,
              onJump: onJump,
            }),
          ),
        ),
      );
    }

    /**
     * Order one `tool_calls` array's entries against the Turn's detail index.
     *
     * The JSON keeps the array in the order the model emitted it, so the rows do
     * too. An entry whose call has no record in the index (should not happen for
     * a request that was actually sent, but a rebuilt prefix can outrun the log)
     * still renders, as a `missing` call built from the entry itself.
     */
    function detailRowsFor(entries, byCallId) {
      const rows = [];
      for (let i = 0; i < entries.length; i += 1) {
        const entry = entries[i];
        const id = entry && entry.id !== undefined ? entry.id : null;
        const detail = id === null ? null : byCallId[String(id)];
        if (detail) {
          rows.push(detail);
          continue;
        }
        const fn = entry && entry.function && typeof entry.function === 'object' ? entry.function : {};
        const rawArgs = fn.arguments;
        rows.push({
          callId: id,
          name: typeof fn.name === 'string' ? fn.name : '',
          argumentsText: typeof rawArgs === 'string' ? rawArgs : rawArgs === undefined ? undefined : JSON.stringify(rawArgs),
          argumentsJson: undefined,
          argumentsOk: false,
          summary: typeof rawArgs === 'string' ? shorten(rawArgs.replace(/\s+/gu, ' '), 80) : '',
          argumentsBytes: byteLength(typeof rawArgs === 'string' ? rawArgs : JSON.stringify(rawArgs === undefined ? null : rawArgs)),
          status: 'missing',
          durationMs: null,
          result: null,
          seq: -1,
        });
      }
      return rows;
    }

    /**
     * A `tool_calls` array, rendered from the step's paired call/result details.
     *
     * Each row is one call: the tool name, a one-line argument summary, and a
     * status badge (`ok` / `error` / `missing`) carrying the round-trip time.
     * Clicking a row unfolds the call's arguments and its result text, so the
     * JSON never loses information — it just stops making you read Base64-shaped
     * argument blobs to find them.
     */
    function ToolCallsNode(props) {
      const details = props.details;
      const pal = props.pal || PALETTES.light;
      const indentation = props.indentation;
      const [openIdx, setOpenIdx] = React.useState(-1);

      const rows = [];
      for (let i = 0; i < details.length; i += 1) {
        const detail = details[i];
        const open = openIdx === i;
        const statusColor = detail.status === 'ok' ? pal.toolOk : detail.status === 'error' ? pal.toolErr : pal.toolMiss;
        const statusBg =
          detail.status === 'ok' ? pal.toolOkBg : detail.status === 'error' ? pal.toolErrBg : pal.toolMissBg;

        rows.push(
          h(
            'div',
            {
              key: 'r' + i,
              style: STYLE.jsonLine,
              title: detail.argumentsText === undefined ? detail.name : detail.argumentsText,
            },
            h('span', { key: 't', style: { display: 'inline-block', width: '14px', color: pal.toggle, fontWeight: 700 } }, open ? '▾' : '▸'),
            h('span', { key: 'i', style: { color: pal.number } }, String(i)),
            h('span', { key: 'c', style: { color: pal.punct } }, ': { '),
            h('span', { key: 'n', style: { color: pal.key, fontWeight: 600 } }, detail.name || '(unnamed)'),
            h('span', { key: 'p', style: { color: pal.punct } }, '('),
            h('span', { key: 's', style: { color: pal.string } }, detail.summary || ''),
            h('span', { key: 'q', style: { color: pal.punct } }, ') '),
            h(
              'span',
              {
                key: 'b',
                className: 'dsh-pl-toolbadge',
                style: Object.assign({}, STYLE.jsonToolBadge, { color: statusColor, background: statusBg, borderColor: statusBg }),
                onClick: (event) => {
                  if (event && typeof event.stopPropagation === 'function') event.stopPropagation();
                  setOpenIdx(open ? -1 : i);
                },
                title: TEXT.toolBadgeTitle,
              },
              detail.status === 'ok' ? TEXT.toolOk : detail.status === 'error' ? TEXT.toolError : TEXT.toolMissing,
              detail.durationMs === null ? '' : ' · ' + formatDuration(detail.durationMs),
            ),
            h('span', { key: 'z', style: { color: pal.punct } }, ' }'),
          ),
        );

        if (!open) continue;

        rows.push(
          h(
            'div',
            { key: 'd' + i, style: Object.assign({}, STYLE.jsonToolBody, indentation) },
            h('div', { key: 'al', style: Object.assign({}, STYLE.jsonToolLabel, { color: pal.punct }) }, TEXT.toolArguments),
            h(
              'div',
              { key: 'a', style: STYLE.jsonLine },
              h('span', { style: { color: pal.string } }, detail.argumentsText === undefined ? '(none)' : detail.argumentsText),
              h('span', { style: { color: pal.nil } }, '  ' + formatBytes(detail.argumentsBytes)),
            ),
            h(
              'div',
              { key: 'rl', style: Object.assign({}, STYLE.jsonToolLabel, { color: pal.punct, marginTop: '4px' }) },
              DETAIL_RESULT_LABEL[detail.status] || TEXT.toolResult,
              detail.result ? h('span', { style: { color: pal.nil, textTransform: 'none', letterSpacing: '0' } }, '  ' + formatBytes(detail.result.bytes)) : null,
            ),
            detail.result
              ? h(
                  'div',
                  {
                    key: 'r',
                    style: Object.assign({}, STYLE.jsonLine, {
                      color: detail.result.isError ? pal.toolErr : undefined,
                      whiteSpace: 'pre-wrap',
                    }),
                  },
                  clampText(detail.result.text),
                )
              : h('div', { key: 'r', style: Object.assign({}, STYLE.jsonLine, { color: pal.nil, fontStyle: 'italic' }) }, TEXT.toolNoResult),
          ),
        );
      }

      return h(
        'div',
        { style: STYLE.jsonNode },
        h(
          'div',
          { style: Object.assign({}, STYLE.jsonLine, indentation), id: props.focusId },
          props.label,
          h('span', { key: 'c', style: { color: pal.punct } }, ': ['),
          h('span', { key: 'n', style: { color: pal.punct, fontStyle: 'italic' } }, ' ' + details.length + ' calls '),
          h('span', { key: 'e', style: { color: pal.punct } }, ']'),
        ),
        h('div', { key: 'c', style: STYLE.jsonGuide }, rows),
        h(
          'div',
          { key: 'f', style: Object.assign({}, STYLE.jsonLine, indentation) },
          h('span', { style: { color: pal.punct } }, ']'),
        ),
      );
    }

    /**
     * A collapsible JSON node. Children are only created while the node is
     * open, which is what keeps a 500-message `messages` array cheap: the array
     * renders one collapsed line per message, not the whole tree.
     *
     * When a `messages` array is told where this Turn begins
     * (`messagesHistoryEnd`), the older messages collapse into one
     * `JsonHistoryGroup` line and the messages this turn produced keep their
     * real indices but sit on a tinted rail, so current content is visible
     * without unfolding anything.
     */
    function JsonNode(props) {
      const name = props.name;
      const value = props.value;
      const depth = props.depth;
      const mode = props.mode;
      const pal = props.pal || PALETTES.light;
      const isArray = Array.isArray(value);
      const isContainer = value !== null && typeof value === 'object';
      const indentation = { paddingLeft: depth * 14 + 'px' };
      /* `messages` is the one array the pane knows how to annotate: where the
         Turn's own messages start, and where the previous call's payload ended.
         The two marks are independent — a request whose Turn boundary is unknown
         can still say what this call appended. */
      const messagesArray = isArray && name === 'messages';
      const split = messagesArray && typeof props.messagesHistoryEnd === 'number';
      const historyEnd = split ? Math.max(0, Math.min(props.messagesHistoryEnd, value.length)) : 0;
      /* "New since the previous call" is drawn HERE, on the array itself: the
         previous request is a prefix of this one, so everything from `prefix` on
         was appended by this step. A separate panel listing those messages meant
         reading the same lines twice and scrolling between two scroll boxes. */
      const diffInfo = messagesArray && props.messagesDiff && typeof props.messagesDiff === 'object' ? props.messagesDiff : null;
      const freshStart =
        diffInfo && typeof diffInfo.prefix === 'number' ? Math.max(0, Math.min(diffInfo.prefix, value.length)) : -1;
      const freshCount = freshStart >= 0 ? value.length - freshStart : 0;
      const band =
        props.fresh === true
          ? Object.assign({}, STYLE.jsonFresh, {
              borderLeftColor: pal.freshBorder,
              background: pal.freshBg,
            })
          : props.current === true
            ? Object.assign({}, STYLE.jsonCurrent, {
                borderLeftColor: pal.currentBorder,
                background: pal.currentBg,
              })
            : null;
      /* The message this dialog was opened from: banded so it is findable, and
         tagged with a DOM id so DialogBody can scroll the body to it. */
      const focusBand = props.focus === true ? STYLE.jsonFocus : null;
      const wrapStyle = props.focus === true ? Object.assign({}, band, focusBand) : band;
      const wrap = (style, node) => (style ? h('div', { style: style }, node) : node);
      /* A DOM id on one row per document, so DialogBody can put the pane on it
         after a step switch. Focus wins: the dialog may also be opened from a
         specific message, and that message is the more precise destination. */
      const focusId =
        props.focus === true ? 'dsh-pl-focus' : typeof props.anchorId === 'string' ? props.anchorId : undefined;
      /* Forwarded down to the `messages` array, which lives one level below the
         request root. */
      const childProps = {};
      if (typeof props.messagesHistoryEnd === 'number') childProps.messagesHistoryEnd = props.messagesHistoryEnd;
      if (props.messagesDiff && typeof props.messagesDiff === 'object') childProps.messagesDiff = props.messagesDiff;
      if (Array.isArray(props.messageLinks)) childProps.messageLinks = props.messageLinks;
      if (typeof props.onJump === 'function') childProps.onJump = props.onJump;
      if (typeof props.focusKey === 'string') childProps.focusKey = props.focusKey;
      if (Array.isArray(props.toolDetailsByCallId) || (props.toolDetailsByCallId && typeof props.toolDetailsByCallId === 'object')) {
        childProps.toolDetailsByCallId = props.toolDetailsByCallId;
      }
      const forwarded = Object.keys(childProps).length ? childProps : null;

      const [open, setOpen] = React.useState(
        isContainer ? (mode === 'all' ? depth <= EXPAND_ALL_DEPTH : mode === 'none' ? false : depth < 2) : false,
      );

      const label = name === null || name === undefined ? null : h('span', { key: 'k', style: { color: pal.key, fontWeight: 600 } }, name);
      const colon = label ? h('span', { key: 'c', style: { color: pal.punct } }, ': ') : null;

      if (!isContainer) {
        return wrap(
          wrapStyle,
          h(
            'div',
            { style: Object.assign({}, STYLE.jsonLine, indentation), id: focusId },
            label,
            colon,
            h('span', { key: 'v', style: valueStyle(value, pal) }, literalOf(value)),
          ),
        );
      }

      const size = isArray ? value.length : Object.keys(value).length;

      /* A `tool_calls` array: each entry is one tool call, and the details for
         every call of the Turn (name, arguments, result, duration) are already
         computed in `meta.toolDetailsByCallId`. Resolving each entry through its
         `id` turns a wall of `{"id":"call_…","function":{…,"arguments":"{…}"}}`
         into `read(path=…)  ✓ 21ms`, with the full result one click away. The
         lookup is by id, not by position, because a request carries the tool
         calls of earlier steps too. */
      const toolDetails =
        isArray && name === 'tool_calls' && props.toolDetailsByCallId
          ? detailRowsFor(value, props.toolDetailsByCallId)
          : null;
      if (toolDetails) {
        return wrap(
          wrapStyle,
          h(ToolCallsNode, {
            key: 'tc',
            details: toolDetails,
            pal: pal,
            indentation: indentation,
            label: label,
            focusId: focusId,
          }),
        );
      }

      const head = h(
        'div',
        {
          key: 'h',
          id: focusId,
          style: Object.assign({}, STYLE.jsonLine, STYLE.jsonClickable, indentation, props.focus === true ? focusBand : null),
          onClick: () => setOpen(!open),
        },
        h('span', { key: 't', style: { display: 'inline-block', width: '14px', color: pal.toggle, fontWeight: 700 } }, open ? '▾' : '▸'),
        label,
        colon,
        h('span', { key: 'b', style: { color: pal.punct } }, isArray ? '[' : '{'),
        open ? null : h('span', { key: 'n', style: { color: pal.punct, fontStyle: 'italic' } }, ' ' + size + (isArray ? ' items' : ' keys') + ' '),
        split
          ? h(
              'span',
              {
                key: 'cur',
                style: Object.assign({}, STYLE.jsonBadge, {
                  color: pal.currentBorder,
                  borderColor: pal.currentBorder,
                  background: pal.currentBg,
                }),
              },
              TEXT.currentTurn + ' ' + (value.length - historyEnd),
            )
          : null,
        split && historyEnd > 0
          ? h('span', { key: 'his', style: Object.assign({}, STYLE.jsonBadgeMuted, { color: pal.punct }) }, TEXT.history + ' ' + historyEnd)
          : null,
        messagesArray && freshCount > 0
          ? h(
              'span',
              {
                key: 'fresh',
                style: Object.assign({}, STYLE.jsonBadge, {
                  color: pal.freshBorder,
                  borderColor: pal.freshBorder,
                  background: pal.freshBg,
                }),
              },
              '+' + freshCount + ' ' + TEXT.diffAdded,
            )
          : null,
        /* Anything that is not a plain append gets said out loud: a compacted
           payload is shorter than the previous one, and a changed sampling
           parameter changes every message's meaning without changing one of
           them. Both are one chip, not a paragraph. */
        messagesArray && diffInfo && diffInfo.removed > 0
          ? h('span', { key: 'gone', style: warnPill(pal) }, '−' + diffInfo.removed + ' ' + TEXT.diffRemoved)
          : null,
        messagesArray && diffInfo && diffInfo.rewritten === true
          ? h('span', { key: 'rw', style: warnPill(pal) }, TEXT.diffRewritten)
          : null,
        messagesArray && diffInfo && Array.isArray(diffInfo.changed) && diffInfo.changed.length
          ? h(
              'span',
              { key: 'chg', style: warnPill(pal) },
              TEXT.diffChanged + ': ' + diffInfo.changed.join(', '),
            )
          : null,
        props.jump && !isArray
          ? h(
              'span',
              {
                key: 'jump',
                className: 'dsh-pl-jump',
                style: STYLE.jsonJump,
                title: TEXT.jumpTitle,
                onClick: (event) => {
                  if (event && typeof event.stopPropagation === 'function') event.stopPropagation();
                  const handler = props.onJump;
                  if (typeof handler === 'function') handler(props.jump);
                },
              },
              TEXT.jump + ' ↗',
            )
          : null,
        open ? null : h('span', { key: 'e', style: { color: pal.punct } }, isArray ? ']' : '}'),
      );

      if (!open) return wrap(wrapStyle, head);

      let children;
      const links = isArray && name === 'messages' && Array.isArray(props.messageLinks) ? props.messageLinks : null;
      const onJump = props.onJump;
      const focusKey = props.focusKey;
      const markFocus = (link) => (focusKey && link && link.key === focusKey ? true : false);
      if (messagesArray && (split || diffInfo)) {
        /* Where this step's own additions begin — the line the pane lands on when
           the reader picks another step, because that boundary is the reason to
           click a step at all. A later call's addition starts at the diff prefix;
           the first call of a Turn has no diff, so its "new" content starts where
           the Turn's own messages do. */
        const sepIndex = freshStart >= 0 && freshStart >= historyEnd ? freshStart : -1;
        /* No diff and no Turn boundary means the whole array is this Turn's own
           content, so the top of the pane already is the right place. */
        const rowAnchorIndex = sepIndex >= 0 ? -1 : historyEnd > 0 && historyEnd < value.length ? historyEnd : -1;
        const tail = [];
        for (let index = historyEnd; index < value.length; index += 1) {
          const link = links ? links[index] || null : null;
          const fresh = freshStart >= 0 && index >= freshStart;
          if (fresh && index === freshStart && freshStart >= historyEnd) {
            tail.push(
              h(
                'div',
                {
                  key: 'fresh-sep',
                  id: 'dsh-pl-diff',
                  style: Object.assign({}, STYLE.jsonFreshSep, { color: pal.freshBorder }),
                },
                /* The boundary the reader came for: everything above came from the
                   previous call, everything below was appended by this one. */
                TEXT.diffBoundary +
                  ' ' +
                  formatExact(freshStart) +
                  ' ' +
                  TEXT.messages +
                  '  ↓  ' +
                  TEXT.diffBoundaryTail +
                  ' ' +
                  formatExact(freshCount),
              ),
            );
          }
          tail.push(
            h(
              JsonNode,
              Object.assign(
                {
                  key: index,
                  name: String(index),
                  value: value[index],
                  depth: depth + 1,
                  mode: mode,
                  pal: pal,
                  current: !fresh,
                  fresh: fresh,
                  anchorId: index === rowAnchorIndex ? 'dsh-pl-diff' : undefined,
                  jump: link,
                  onJump: onJump,
                  focus: markFocus(link),
                },
                forwarded,
              ),
            ),
          );
        }
        children =
          historyEnd > 0
            ? [
                h(JsonHistoryGroup, {
                  key: 'history',
                  items: value.slice(0, historyEnd),
                  offset: 0,
                  depth: depth + 1,
                  mode: mode,
                  pal: pal,
                  links: links ? links.slice(0, historyEnd) : null,
                  onJump: onJump,
                  focusKey: focusKey,
                }),
              ].concat(tail)
            : tail;
      } else if (isArray) {
        children = value.map((item, index) =>
          h(
            JsonNode,
            Object.assign({ key: index, name: String(index), value: item, depth: depth + 1, mode: mode, pal: pal, jump: links ? links[index] || null : null, onJump: onJump, focus: markFocus(links ? links[index] : null) }, forwarded),
          ),
        );
      } else {
        children = Object.keys(value).map((key) =>
          h(
            JsonNode,
            Object.assign({ key: key, name: key, value: value[key], depth: depth + 1, mode: mode, pal: pal, onJump: onJump, focusKey: focusKey }, forwarded),
          ),
        );
      }

      return wrap(
        wrapStyle,
        h(
          'div',
          { style: STYLE.jsonNode },
          head,
          h('div', { key: 'c', style: STYLE.jsonGuide }, children),
          h(
            'div',
            { key: 'f', style: Object.assign({}, STYLE.jsonLine, indentation) },
            h('span', { style: { color: pal.punct } }, isArray ? ']' : '}'),
          ),
        ),
      );
    }

    /**
     * The whole Turn at a glance: one segment per model call.
     *
     * Sized by the tokens that call consumed (input + cache + output), which is
     * the only per-step cost the log records and the provider actually reports —
     * the log has no timestamps, and record counts barely move between a plain
     * reply and a tool round-trip. Under the bar each step states what it did:
     * how many tools it called, how many round-trips that took, and its tokens.
     *
     * Clicking a segment selects that call, so the strip doubles as navigation
     * for a Turn too long for tabs.
     */
    function Timeline(props) {
      const calls = Array.isArray(props.calls) ? props.calls : [];
      const onSelect = props.onSelect;
      const pal = props.pal || PALETTES.light;
      if (calls.length < 2) return null;

      const weights = calls.map((item) => {
        const usage = item.meta && item.meta.usage;
        const total = usage && typeof usage.total === 'number' ? usage.total : 0;
        return total > 0 ? total : 1;
      });
      const totalTokens = weights.reduce((acc, value) => acc + (value > 1 ? value : 0), 0);

      /* On a pill there is room for two facts and no more. Which step it is wins
         (what the reader is scanning for); the tool traffic moves into the hover
         tooltip, which already carries it, so nothing is lost. */
      /* "1 工具 · 1 往返" on every segment is the same two numbers N times over —
         a Turn is normally one tool call per step, so it never distinguishes
         anything. The tooltip answers "where did the tokens go": which step, how
         many tokens. No tool names either — they describe what the step PRODUCED,
         while the number here addresses the request snapshot, and reading the two
         together looks like a mismatch. */
      const segments = calls.map((item, position) => {
        const meta = item.meta || {};
        const chosen = position === props.selected;
        const usage = meta.usage || null;
        const parts = ['#' + (item.index || position + 1)];
        if (meta.step !== undefined) parts.push(TEXT.stepWord + ' ' + meta.step);
        parts.push(usage && usage.total ? formatTokens(usage.total) + ' ' + TEXT.tokens : TEXT.noUsage);
        if (chosen) parts.push(TEXT.timelineSelected);

        return h('button', {
          key: 'seg-' + position,
          type: 'button',
          style: Object.assign({}, STYLE.timelineSeg, {
            flex: String(weights[position]) + ' 1 0',
            background: chosen ? pal.famPrompt : pal.punct,
            opacity: chosen ? 1 : 0.55,
          }),
          title: parts.join(' · '),
          onClick: onSelect ? () => onSelect(position) : undefined,
        });
      });

      /* The bar answers one question the tabs cannot: how the Turn's tokens are
         spread across its steps. The heaviest-step pills that used to sit under
         it said `#k · step n · tokens` — exactly what the tab strip and the step
         list already print — so they are gone; the bar itself is the navigation
         (a segment is one step, and one step is one call). */
      return h(
        'div',
        { key: 'timeline', style: STYLE.timeline },
        h(
          'div',
          { key: 'head', style: STYLE.timelineHead },
          h('span', { key: 't', style: STYLE.chipValue }, TEXT.timelineTitle),
          h('span', { key: 'n', style: STYLE.sourceMuted }, calls.length + ' ' + TEXT.callsShort),
          h(
            'span',
            { key: 'r', style: Object.assign({}, STYLE.sourceMuted, { marginLeft: 'auto' }) },
            formatTokens(totalTokens),
          ),
        ),
        h('div', { key: 'track', style: STYLE.timelineTrack, title: TEXT.timelineHint }, segments),
      );
    }

    /**
     * The header's diff slot: the first call of a Turn has nothing to compare
     * against, and saying so is better than showing an empty panel.
     */
    /**
     * "Why is this request this long?" — one stacked bar plus a legend.
     *
     * Shares are message bytes rather than tokens: the log records text, the
     * provider reports tokens, and mapping one to the other would be a guess. The
     * bar answers "what is taking up room" honestly; the token chips next to it
     * remain the authoritative cost.
     */
    function SourcePanel(props) {
      const sources = props.sources;
      const fresh = props.fresh;
      const freshBytes = props.freshBytes;
      const pal = props.pal || PALETTES.light;

      if (!sources || !sources.counts) return null;

      const totalCount =
        sources.counts.prompt + sources.counts.injected + sources.counts.model + sources.counts.tool + sources.counts.other;
      if (!totalCount) return null;

      const label = {
        prompt: TEXT.sourceFamilyPrompt,
        injected: TEXT.sourceFamilyInjected,
        model: TEXT.sourceFamilyModel,
        tool: TEXT.sourceFamilyTool,
        other: TEXT.sourceFamilyOther,
      };
      const colour = {
        prompt: pal.famPrompt,
        injected: pal.famInjected,
        model: pal.famModel,
        tool: pal.famTool,
        other: pal.famOther,
      };
      /* Per-kind wording, so the legend can say "时间上下文 33" instead of the
         coarser family name once the bar is narrowed to one family. */
      const kindText = {
        user: TEXT.sourceKindUser,
        approval: TEXT.sourceKindApproval,
        timeContext: TEXT.sourceKindTimeContext,
        runtimeContext: TEXT.sourceKindRuntimeContext,
        skillCatalog: TEXT.sourceKindSkillCatalog,
        modelSelection: TEXT.sourceKindModelSelection,
        systemPrompt: TEXT.sourceKindSystemPrompt,
        toolRegistry: TEXT.sourceKindToolRegistry,
        jobReport: TEXT.sourceKindJobReport,
        model: TEXT.sourceKindModel,
        tool: TEXT.sourceKindTool,
        other: TEXT.sourceKindOther,
      };
      const order = ['prompt', 'injected', 'model', 'tool', 'other'];

      const segments = order
        .filter((key) => sources.counts[key] > 0)
        .map((key) =>
          h('div', {
            key: key,
            style: Object.assign({}, STYLE.sourceSeg, {
              flex: String(sources.counts[key]) + ' 1 0',
              background: colour[key],
            }),
            title: label[key] + ' · ' + sources.counts[key],
          }),
        );

      /* Collapsed by default: a five-family legend with every kind spelled out was
         five lines of text above the JSON, answering a question most visits do not
         ask. The compact row states the families; the kinds appear on demand. */
      const [openFamily, setOpenFamily] = React.useState('');

      const families = order.filter((key) => sources.counts[key] > 0);

      const chips = families.map((key) => {
        const members = (sources.kinds || [])
          .filter((item) => item.family === key)
          .map((item) => ({
            text: kindText[item.key] || kindText.other,
            count: item.count,
          }));
        const open = openFamily === key;
        const title = members.map((item) => item.text + ' ' + item.count).join(' · ');
        return h(
          'button',
          {
            key: key,
            type: 'button',
            className: 'dsh-pl-pill' + (open ? ' dsh-pl-pill-on' : ''),
            style: STYLE.sourceChip,
            title: title || undefined,
            'aria-expanded': open ? 'true' : 'false',
            onClick: () => setOpenFamily(open ? '' : key),
          },
          h('span', { key: 'd', style: Object.assign({}, STYLE.sourceDot, { background: colour[key] }) }),
          h('span', { key: 'l' }, label[key]),
          h('span', { key: 'n', style: STYLE.sourceNum }, formatExact(sources.counts[key])),
          h(
            'span',
            { key: 'p', style: STYLE.sourceMuted },
            Math.round((sources.counts[key] / totalCount) * 100) + '%',
          ),
          members.length > 1 ? h('span', { key: 'c', style: STYLE.sourceMuted }, open ? '▾' : '▸') : null,
        );
      });

      /* The one detail worth showing without a click: which kinds the selected
         family is made of, with their counts. */
      const openMembers =
        openFamily && openFamily !== ''
          ? (sources.kinds || [])
              .filter((item) => item.family === openFamily)
              .map((item) =>
                h(
                  'span',
                  { key: 'm-' + item.key, style: STYLE.sourceDetail },
                  h('span', { key: 't' }, kindText[item.key] || kindText.other),
                  h('span', { key: 'n', style: STYLE.sourceNum }, formatExact(item.count)),
                ),
              )
          : null;

      /* What this Turn itself wrote: the number that makes a growing context
         legible (a Turn that adds 150 messages explains itself instantly). */
      const freshCount =
        typeof fresh === 'number'
          ? fresh
          : fresh && fresh.counts
            ? fresh.counts.prompt + fresh.counts.injected + fresh.counts.model + fresh.counts.tool + fresh.counts.other
            : 0;
      if (freshCount > 0) {
        chips.push(
          h(
            'span',
            { key: 'fresh', style: Object.assign({}, STYLE.sourceChip, { marginLeft: 'auto', cursor: 'default' }), title: TEXT.sourceFreshTitle },
            h('span', { key: 'l' }, TEXT.sourceFresh),
            h('span', { key: 'n', style: Object.assign({}, STYLE.sourceNum, { color: pal.famPrompt }) }, formatExact(freshCount)),
            typeof freshBytes === 'number' && freshBytes > 0
              ? h('span', { key: 'b', style: STYLE.sourceMuted }, formatBytes(freshBytes))
              : null,
          ),
        );
      }

      return h(
        'div',
        { className: 'dsh-pl-sources', title: TEXT.sourceTitle },
        h('div', { key: 'bar', style: STYLE.sourceBar }, segments),
        h('div', { key: 'legend', style: STYLE.sourceLegend }, chips),
        openMembers && openMembers.length
          ? h('div', { key: 'detail', style: STYLE.sourceDetailRow }, openMembers)
          : null,
      );
    }

    // ------------------------------------------------------------ dialog body

    /**
     * The reply side of one call.
     *
     * Two things make a reply worth reading separately from its request: *why* it
     * stopped, and what it actually said. A failed attempt explains why the
     * successful one exists, so the retry list comes first; the body then goes
     * through the same JSON tree the request uses, which means a reply's
     * `tool_calls` inherit the status badges and the result text of the tool
     * round-trip panel instead of being a wall of argument blobs.
     */
    function ResponsePanel(props) {
      const pal = props.pal || PALETTES.light;
      const response = props.response;
      if (!response) return h('div', { style: STYLE.note }, TEXT.responseNone);

      const attempts = Array.isArray(response.attempts) ? response.attempts : [];
      const rows = [];
      for (let i = 0; i < attempts.length; i += 1) {
        const attempt = attempts[i] || {};
        const failure = attempt.finish && attempt.finish.failure ? attempt.finish.failure : null;
        const detail = failure
          ? (failure.code || 'ERROR') +
            (failure.status === null || failure.status === undefined ? '' : ' ' + failure.status) +
            (failure.message ? ' · ' + failure.message : '')
          : finishLabelOf(attempt.finish && attempt.finish.kind);
        rows.push(
          h(
            'div',
            { key: 'attempt-' + i, style: STYLE.attemptRow },
            h('span', { key: 'n' }, TEXT.attemptNo + (i + 1)),
            h('span', { key: 'd', style: STYLE.attemptText }, detail),
          ),
        );
      }

      return h(
        'div',
        null,
        rows.length ? h('div', { key: 'attempts', style: STYLE.attemptList }, rows) : null,
        response.body
          ? h(JsonNode, {
              key: 'body',
              name: null,
              value: response.body,
              depth: 0,
              mode: props.mode,
              pal: pal,
              /* The reply's own `tool_calls` are the calls this step made, so the
                 same index that serves the request tab resolves their results. */
              toolDetailsByCallId: props.toolDetailsByCallId,
            })
          : h('div', { key: 'none', style: STYLE.note }, TEXT.responseNone),
      );
    }

    function DialogBody(props) {
      const payload = props.payload;
      const calls = payload.data && Array.isArray(payload.data.calls) ? payload.data.calls : [];
      const [selected, setSelected] = React.useState(
        typeof payload.selectedIndex === 'number' && payload.selectedIndex >= 0 ? payload.selectedIndex : 0,
      );
      const [mode, setMode] = React.useState('default');
      const [flash, setFlash] = React.useState('');
      /* One dialog, two halves of the exchange: the request that was sent, and
         the reply it got. The side belongs to the selected step — each step row
         carries its own 请求/响应 pair — so switching step and switching side are
         the same gesture, and no step is ever picked twice for two halves. */
      const [side, setSide] = React.useState('request');
      const bodyRef = React.useRef(null);

      /* The payload is far taller than the viewport, so both a draggable scrollbar
         (see the .dsh-pl-scroll rules) and one-click ends are needed. */
      const jump = (where) => () => {
        const node = bodyRef.current;
        if (!node) return;
        node.scrollTop = where === 'end' ? node.scrollHeight : 0;
      };

      /* Message → conversation. Close the dialog first, then scroll the chat to
         the row this message was rendered as. The precise row is only mounted
         when its group is expanded, so the owning Turn is the fallback. */
      const jumpToMessage = (link) => {
        publishDialog(null);
        scrollConversationTo(link);
      };

      const index = calls.length ? Math.min(Math.max(selected, 0), calls.length - 1) : 0;
      const call = calls.length ? calls[index] : null;
      const meta = (call && call.meta) || {};
      const callCount = calls.length;
      const pal = PALETTES[payload.scheme === 'dark' ? 'dark' : 'light'];

      const totals = { total: 0, input: 0, cache: 0, output: 0 };
      for (let i = 0; i < calls.length; i += 1) {
        const itemUsage = calls[i].meta && calls[i].meta.usage;
        if (!itemUsage) continue;
        totals.total += itemUsage.total || 0;
        totals.input += itemUsage.input || 0;
        totals.cache += itemUsage.cache || 0;
        totals.output += itemUsage.output || 0;
      }

      /* Put one line in view with a little air above it, without yanking the
         whole pane: the closest scrollable ancestor is the body itself. */
      const reveal = (node, target) => {
        node.scrollTop = revealTop(node, target);
      };

      /* A new call or a different expand mode is a different document: land on
         the line the reader came for. Two candidates, in order: the message this
         dialog was opened from (most precise), then the boundary where the
         selected step's own additions start — clicking a step is a question about
         what that step added, so answering it at the top of a 6 700-message array
         would be answering a different question. Without either mark, start at
         the top. */
      React.useEffect(
        () => {
          const node = bodyRef.current;
          if (!node) return;
          const canLook = typeof document !== 'undefined' && Boolean(document);
          if (canLook && typeof payload.focusKey === 'string') {
            const target = document.getElementById('dsh-pl-focus');
            if (target) return reveal(node, target);
          }
          if (canLook) {
            const target = document.getElementById('dsh-pl-diff');
            if (target) return reveal(node, target);
          }
          node.scrollTop = 0;
        },
        [index, mode, side],
      );

      const flashDone = (label) => () => {
        setFlash(label);
        setTimeout(() => setFlash(''), 1200);
      };

      const copyCurrent = () => {
        if (!call) return;
        let text = '';
        try {
          /* Copy what is on screen: the request when the request tab is open, the
             rebuilt response when the response tab is. */
          text = JSON.stringify(side === 'response' && meta.response ? meta.response.body : call.request, null, 2);
        } catch (err) {
          text = String(err);
        }
        copyText(text, flashDone('copy'));
      };

      const copyAll = () => {
        if (!callCount) return;
        let text = '';
        try {
          text = JSON.stringify(
            calls.map((item) => {
              if (side !== 'response') return item.request;
              const itemResponse = item.meta && item.meta.response;
              return itemResponse ? itemResponse.body : null;
            }),
            null,
            2,
          );
        } catch (err) {
          text = String(err);
        }
        copyText(text, flashDone('all'));
      };

      const chip = (key, label, value, accent, title, variant) => {
        const shell =
          variant === 'error'
            ? Object.assign({}, STYLE.chip, STYLE.chipError)
            : variant === 'warn'
              ? Object.assign({}, STYLE.chip, STYLE.chipWarn)
              : accent
                ? Object.assign({}, STYLE.chip, STYLE.chipAccent)
                : STYLE.chip;
        const valueStyle =
          variant === 'error'
            ? Object.assign({}, STYLE.chipValue, STYLE.chipErrorValue)
            : variant === 'warn'
              ? Object.assign({}, STYLE.chipValue, STYLE.chipWarnValue)
              : accent
                ? Object.assign({}, STYLE.chipValue, STYLE.chipAccentValue)
                : STYLE.chipValue;
        return h(
          'span',
          { key: key, title: title || undefined, style: shell },
          label ? h('span', { key: 'l', style: STYLE.chipLabel }, label) : null,
          h('span', { key: 'v', style: valueStyle }, value),
        );
      };

      const metaChips = [];
      if (callCount > 1) metaChips.push(chip('call', null, '#' + (index + 1) + ' / ' + callCount));
      if (meta.model) metaChips.push(chip('model', null, String(meta.model)));
      if (typeof meta.messages === 'number')
        metaChips.push(chip('msgs', null, meta.messages + ' ' + TEXT.messages, false, TEXT.messagesTitle));
      if (typeof meta.historyEnd === 'number' && typeof meta.messages === 'number')
        metaChips.push(
          chip('current', TEXT.currentTurn, String(meta.messages - meta.historyEnd), true, TEXT.currentTitle),
        );
      if (typeof meta.tools === 'number') metaChips.push(chip('tools', null, meta.tools + ' ' + TEXT.tools));
      if (meta.reason) metaChips.push(chip('reason', TEXT.reasonLabel, meta.reason));
      const bodyBytes = call ? bytesOfBody(call.request) : 0;
      if (bodyBytes > 0)
        metaChips.push(chip('bytes', TEXT.bytesLabel, formatBytes(bodyBytes), false, TEXT.bytesTitle));

      const usageChips = [];
      const currentUsage = meta.usage || null;      if (currentUsage) {
        usageChips.push(chip('in', TEXT.usageInput, formatExact(currentUsage.input), false, TEXT.usageInputTitle));
        usageChips.push(
          chip(
            'cache',
            TEXT.usageCache,
            formatExact(currentUsage.cache) +
              (currentUsage.hitRate === null ? '' : ' · ' + Math.round(currentUsage.hitRate * 100) + '%'),
            false,
            TEXT.usageCacheTitle,
          ),
        );
        usageChips.push(chip('out', TEXT.usageOutput, formatExact(currentUsage.output), false, TEXT.usageOutputTitle));
        usageChips.push(
          chip('total', TEXT.usageTotal, formatExact(currentUsage.total), true, TEXT.usageTotalTitle),
        );
        if (callCount > 1)
          usageChips.push(chip('turn', TEXT.turnTotal, formatExact(totals.total), true, TEXT.turnTotalTitle));
      } else {
        usageChips.push(chip('none', null, TEXT.usageNone));
      }

      /* The reply side: why it stopped, how fast it streamed, how much it wrote. */
      const response = meta.response || null;
      const respChips = [];
      if (response) {
        const finishKind = response.finish && response.finish.kind ? response.finish.kind : null;
        const failure = response.finish && response.finish.failure ? response.finish.failure : null;
        respChips.push(
          chip(
            'finish',
            TEXT.finishLabel,
            finishLabelOf(finishKind),
            !failure && finishKind === 'tool-calls',
            TEXT.finishTitle,
            failure ? 'error' : null,
          ),
        );
        if (failure) {
          respChips.push(
            chip(
              'code',
              null,
              (failure.code || 'ERROR') + (failure.status === null ? '' : ' ' + failure.status),
              false,
              failure.message,
              'error',
            ),
          );
        }
        if (response.timing && typeof response.timing.ttfbMs === 'number') {
          respChips.push(
            chip('ttfb', TEXT.responseFirst, formatMs(response.timing.ttfbMs), false, TEXT.responseFirstTitle),
          );
        }
        if (response.timing && typeof response.timing.spanMs === 'number') {
          respChips.push(
            chip('span', TEXT.responseSpan, formatMs(response.timing.spanMs), false, TEXT.responseSpanTitle),
          );
        }
        if (response.stats) {
          respChips.push(
            chip(
              'chars',
              null,
              formatExact(response.stats.textChars) + ' ' + TEXT.responseOutChars,
              false,
              TEXT.responseOutCharsTitle,
            ),
          );
          if (response.stats.reasoningChars > 0) {
            respChips.push(
              chip(
                'rchars',
                null,
                formatExact(response.stats.reasoningChars) + ' ' + TEXT.responseReasoning,
                false,
                TEXT.responseReasoningTitle,
              ),
            );
          }
        }
        if (response.attempts.length) {
          respChips.push(
            chip(
              'retry',
              TEXT.attemptsLabel,
              String(response.attempts.length),
              false,
              TEXT.attemptsTitle,
              'warn',
            ),
          );
        }
        const responseBytes = response.body ? bytesOfBody(response.body) : 0;
        if (responseBytes > 0) {
          respChips.push(
            chip('rbytes', TEXT.responseBytesLabel, formatBytes(responseBytes), false, TEXT.responseShapeTitle),
          );
        }
      } else {
        respChips.push(chip('none', null, TEXT.responseNone));
      }

      const header = h(
        'div',
        { key: 'header', style: STYLE.dialogHeader },
        h(
          'div',
          { key: 'row-top', style: STYLE.headerRow },
          h('span', { key: 'title', style: STYLE.dialogTitle }, payload.title),
          h('span', { key: 'version', style: STYLE.versionTag, title: 'dsh-payload ' + VERSION }, VERSION),
          h(
            'div',
            { key: 'actions', style: STYLE.headerActions },
            [
                  h(
                    'button',
                    {
                      key: 'to-top',
                      type: 'button',
                      className: 'dsh-pl-btn',
                      onClick: jump('start'),
                      style: STYLE.smallButton,
                      title: TEXT.toTop,
                      'aria-label': TEXT.toTop,
                    },
                    '↑',
                  ),
                  h(
                    'button',
                    {
                      key: 'to-end',
                      type: 'button',
                      className: 'dsh-pl-btn',
                      onClick: jump('end'),
                      style: STYLE.smallButton,
                      title: TEXT.toEnd,
                      'aria-label': TEXT.toEnd,
                    },
                    '↓',
                  ),
                  h(
                    'button',
                    {
                      key: 'copy',
                      type: 'button',
                      className: 'dsh-pl-btn',
                      onClick: copyCurrent,
                      style: STYLE.smallButton,
                    },
                    flash === 'copy' ? TEXT.copied : TEXT.copy,
                  ),
                  callCount > 1
                    ? h(
                        'button',
                        {
                          key: 'copy-all',
                          type: 'button',
                          className: 'dsh-pl-btn',
                          onClick: copyAll,
                          style: STYLE.smallButton,
                        },
                        flash === 'all' ? TEXT.copied : TEXT.copyAll,
                      )
                    : null,
                  h(
                    'button',
                    {
                      key: 'expand',
                      type: 'button',
                      className: 'dsh-pl-btn',
                      onClick: () => setMode(mode === 'all' ? 'default' : 'all'),
                      style: STYLE.smallButton,
                    },
                    mode === 'all' ? TEXT.collapseAll : TEXT.expandAll,
                  ),
                ],
            h(
              'button',
              {
                key: 'close',
                type: 'button',
                className: 'dsh-pl-btn',
                onClick: () => publishDialog(null),
                style: STYLE.smallButton,
                title: TEXT.close,
                'aria-label': TEXT.close,
              },
              '✕',
            ),
          ),
        ),
        h('div', { key: 'row-usage', style: STYLE.chips }, usageChips),
        /* The source breakdown always describes the selected step's request,
           including while its response is shown. Keep it mounted across switches. */
        callCount > 1
          ? h(Timeline, {
              key: 'row-timeline',
              calls: calls,
              selected: index,
              onSelect: setSelected,
              pal: pal,
            })
          : null,
        call
          ? h(SourcePanel, {
              key: 'row-sources',
              sources: meta.sources,
              fresh: meta.messages - meta.historyEnd,
              freshBytes: meta.freshBytes,
              pal: pal,
            })
          : null,
      );

      /* The 请求 / 响应 pair sits in the JSON pane's own top-right corner: the step
         is chosen in the left column, the side
         is chosen where the content appears, so neither control has to be repeated
         per row and no row has to be scanned twice. */
      const renderPaneSides = () => {
        const itemMeta = meta || {};
        const hasReply = Boolean(itemMeta.response);
        const requestOn = side === 'request';
        const responseOn = side === 'response';
        return h(
          'span',
          { key: 'sides', style: STYLE.sides },
          h(
            'button',
            {
              key: 'req',
              type: 'button',
              'aria-pressed': requestOn ? 'true' : 'false',
              className: requestOn ? 'dsh-pl-side dsh-pl-side-on' : 'dsh-pl-side',
              onClick: () => setSide('request'),
              style: Object.assign({}, STYLE.sideBtn, requestOn ? STYLE.sideBtnActive : null),
            },
            TEXT.viewRequest,
          ),
          h(
            'button',
            {
              key: 'res',
              type: 'button',
              'aria-pressed': responseOn ? 'true' : 'false',
              title: hasReply ? TEXT.viewResponse : TEXT.responseNone,
              className: responseOn
                ? 'dsh-pl-side dsh-pl-side-on'
                : hasReply
                  ? 'dsh-pl-side'
                  : 'dsh-pl-side dsh-pl-side-off',
              onClick: () => setSide('response'),
              style: Object.assign(
                {},
                STYLE.sideBtn,
                hasReply ? null : STYLE.sideBtnOff,
                responseOn ? STYLE.sideBtnActive : null,
              ),
            },
            TEXT.viewResponse,
          ),
        );
      };

      const stepTitle = (position, itemMeta) =>
        TEXT.callPrefix +
        (position + 1) +
        '/' +
        callCount +
        TEXT.callSuffix +
        ' · step ' +
        (itemMeta.step !== undefined ? itemMeta.step : position + 1) +
        (itemMeta.model ? ' · ' + itemMeta.model : '') +
        (typeof itemMeta.messages === 'number' ? ' · ' + itemMeta.messages + ' ' + TEXT.messages : '') +
        (typeof itemMeta.tools === 'number' ? ' · ' + itemMeta.tools + ' ' + TEXT.tools : '');

      const stepRefs = React.useRef([]);

      React.useEffect(
        () => {
          const node = stepRefs.current[index];
          if (node && typeof node.scrollIntoView === 'function') node.scrollIntoView({ block: 'nearest' });
        },
        [index],
      );

      const onStepsKeyDown = (event) => {
        const key = event && event.key;
        if (key !== 'ArrowDown' && key !== 'ArrowUp' && key !== 'Home' && key !== 'End') return;
        event.preventDefault();
        const next =
          key === 'ArrowDown'
            ? Math.min(callCount - 1, index + 1)
            : key === 'ArrowUp'
              ? Math.max(0, index - 1)
              : key === 'Home'
                ? 0
                : callCount - 1;
        if (next === index) return;
        setSelected(next);
        const node = stepRefs.current[next];
        if (node && typeof node.focus === 'function') node.focus();
      };

      let stepList = null;
      if (callCount > 0) {
        stepList = h(
          'div',
          {
            key: 'steps',
            className: 'dsh-pl-scroll',
            style: STYLE.stepList,
            role: 'listbox',
            'aria-label': TEXT.title,
            onKeyDown: onStepsKeyDown,
          },
          calls.map((item, position) => {
            const itemMeta = item.meta || {};
            const stepLabel = itemMeta.step !== undefined ? itemMeta.step : position + 1;
            const active = position === index;
            return h(
              'div',
              {
                key: 'step-' + (item.index || position + 1),
                role: 'option',
                'aria-selected': active ? 'true' : 'false',
                className: active ? 'dsh-pl-step dsh-pl-step-on' : 'dsh-pl-step',
                style: Object.assign({}, STYLE.stepRow, active ? STYLE.stepRowActive : null),
              },
              h(
                'button',
                {
                  key: 'hit',
                  ref: (node) => {
                    stepRefs.current[position] = node;
                  },
                  type: 'button',
                  className: 'dsh-pl-stephit',
                  onClick: () => setSelected(position),
                  style: STYLE.stepHit,
                  title: stepTitle(position, itemMeta),
                },
                h(
                  'span',
                  { key: 'top', style: STYLE.stepRowTop },
                  h('span', { key: 'no', style: STYLE.stepNo }, '#' + (item.index || position + 1)),
                  itemMeta.usage && typeof itemMeta.usage.total === 'number'
                    ? h('span', { key: 'tk', style: STYLE.stepAside }, formatTokens(itemMeta.usage.total))
                    : null,
                ),
                h(
                  'span',
                  { key: 'sub', style: STYLE.stepSub },
                  'step ' + stepLabel + ' · ' + (itemMeta.messages || 0) + ' ' + TEXT.messages +
                    (typeof itemMeta.historyEnd === 'number'
                      ? ' · ' + TEXT.currentTurn + ' ' + ((itemMeta.messages || 0) - itemMeta.historyEnd)
                      : ''),
                ),
              ),
            );
          }),
        );
      }

      const body = h(
        'div',
        { key: 'body', ref: bodyRef, className: 'dsh-pl-scroll', style: STYLE.dialogBody, title: TEXT.railTitle },
        call && side === 'response'
          ? h(ResponsePanel, {
              key: 'resp:' + mode + ':' + index,
              response: response,
              mode: mode,
              pal: pal,
              toolDetailsByCallId: meta.toolDetailsByCallId,
            })
          : call
          ? h(JsonNode, {
              key: mode + ':' + index,
              name: null,
              value: call.request,
              depth: 0,
              mode: mode,
              pal: pal,
              /* Where this Turn's own messages start inside request.messages. */
              messagesHistoryEnd: meta.historyEnd,
              /* And where the previous call's payload ended: everything after it
                 is banded as new. Null on a Turn's first call — there is nothing
                 to compare against, so nothing is marked. */
              messagesDiff: meta.diff || null,
              /* One conversation-row target per message, so a row can jump. */
              messageLinks: meta.messageLinks,
              /* One display-ready entry per tool call this step made, paired with
                 its result; a `tool_calls` array renders through it. */
              toolCallDetails: meta.toolCallDetails,
              toolDetailsByCallId: meta.toolDetailsByCallId,
              onJump: jumpToMessage,
              /* The message this dialog was opened from: banded + scrolled to. */
              focusKey: payload.focusKey,
            })
          : h('div', { style: STYLE.note }, TEXT.empty),
      );

      const pane = h('div', { key: 'pane', style: STYLE.pane }, h(
        'div',
        { key: 'pane-bar', style: STYLE.paneBar },
        call ? renderPaneSides() : null,
      ), call ? h('div', { key: 'row-meta', className: 'dsh-pl-pane-meta', style: STYLE.chips },
        side === 'response' ? respChips : metaChips,
      ) : null, body);

      /* Only worth saying when the log carries far more than the model reads — and
         only on the request tab, which is what the note is about. */
      const foot =
        call && side === 'request' && typeof meta.messages === 'number' && meta.messages > 200
          ? h('div', { key: 'foot', style: STYLE.dialogFoot }, TEXT.compressNote)
          : null;

      /* The rail reads its colours from these custom properties, so the same
         stylesheet serves both colour schemes without a scheme class. */
      const dialogStyle = Object.assign({}, STYLE.dialog, {
        '--dsh-pl-sb-track': pal.scTrack,
        '--dsh-pl-sb-thumb': pal.scThumb,
        '--dsh-pl-sb-thumb-hover': pal.scThumbHover,
        '--dsh-pl-sb-thumb-active': pal.scThumbActive,
      });

      return h(
        'div',
        { style: dialogStyle, onClick: (event) => event.stopPropagation() },
        header,
        stepList ? h('div', { key: 'split', style: STYLE.split }, stepList, pane) : pane,
        foot,
      );
    }

    /** The `shell.overlay` entry: renders nothing until a button publishes. */
    function PayloadOverlay() {
      const [, bump] = React.useReducer((value) => value + 1, 0);
      React.useEffect(() => subscribeDialog(bump), []);

      const payload = dialogPayload;

      React.useEffect(
        () => {
          if (!payload) return undefined;
          if (typeof document === 'undefined' || typeof document.addEventListener !== 'function') return undefined;
          const onKeyDown = (event) => {
            if (event && event.key === 'Escape') publishDialog(null);
          };
          document.addEventListener('keydown', onKeyDown);
          return () => document.removeEventListener('keydown', onKeyDown);
        },
        /* Keyed on "a dialog is open", not on its id: the loading dialog
           republishes every 250 ms to count the seconds, and rebinding the
           listener on each tick is pure churn. */
        [payload ? 1 : 0],
      );

      if (!payload) return null;

      let inner;
      if (payload.status === 'ready' && payload.data) {
        inner = h(DialogBody, { key: payload.id, payload });
      } else {
        /* `note` is the load in progress, counted in seconds: the reader said
           "first open of a long conversation hangs", and a still line cannot be
           told apart from a hang. */
        /* `note` is the work in progress: while reading it counts seconds, and the
           reader said a still line "looks stuck". A spinner is added because the
           text cannot be repainted while the main thread is busy — the spinner is
           composited and keeps turning, so a frozen number is not mistaken for a
           dead dialog. */
        const message = payload.note
          ? payload.note
          : payload.status === 'error'
            ? TEXT.error + payload.message
            : payload.status === 'empty'
              ? TEXT.empty
              : TEXT.loading;
        const busy = payload.status === 'loading';
        inner = h(
          'div',
          { style: Object.assign({}, STYLE.dialog, { height: 'auto', maxHeight: '40vh' }), onClick: (event) => event.stopPropagation() },
          h(
            'div',
            { style: STYLE.dialogHeader },
            h('span', { style: STYLE.dialogTitle }, payload.title),
            h(
              'button',
              {
                type: 'button',
                className: 'dsh-pl-btn',
                onClick: () => publishDialog(null),
                style: STYLE.smallButton,
                title: TEXT.close,
              },
              '✕',
            ),
          ),
          h(
            'div',
            { style: STYLE.dialogBody },
            h(
              'div',
              { style: STYLE.loadingRow },
              busy ? h('span', { className: 'dsh-pl-spin', 'aria-hidden': 'true' }) : null,
              h('span', { style: Object.assign({}, STYLE.note, { padding: 0, flex: '1 1 auto', minWidth: 0 }) }, message),
            ),
            h(
              'div',
              { style: Object.assign({}, STYLE.versionTag, { padding: '0 16px 10px', textAlign: 'right' }) },
              VERSION,
            ),
          ),
        );
      }

      return h(
        DialogBoundary,
        null,
        h('div', { style: STYLE.backdrop, onClick: () => publishDialog(null) }, inner),
      );
    }

    /**
     * Last line of defence. A thrown error inside the dialog used to take the
     * whole overlay down with no explanation, which reads as "the plugin
     * crashed". Catching it here keeps the frame alive and shows the message,
     * so the next report can name the actual failure.
     */
    class DialogBoundary extends React.Component {
      constructor(props) {
        super(props);
        this.state = { failure: null };
      }

      static getDerivedStateFromError(error) {
        return { failure: String((error && error.message) || error) };
      }

      componentDidCatch(error, info) {
        /* Console is the only channel the Client has; keep it one line. */
        try {
          if (typeof console !== 'undefined' && console.error) {
            console.error('[dsh-payload] render failed', error, info && info.componentStack);
          }
        } catch (err) {
          /* nothing to do */
        }
      }

      render() {
        if (this.state.failure === null) return this.props.children;
        return h(
          'div',
          {
            style: Object.assign({}, STYLE.dialog, { height: 'auto', maxHeight: '40vh' }),
            onClick: (event) => event.stopPropagation(),
          },
          h(
            'div',
            { style: STYLE.dialogHeader },
            h('span', { style: STYLE.dialogTitle }, TEXT.error),
            h(
              'button',
              { type: 'button', className: 'dsh-pl-btn', onClick: () => publishDialog(null), style: STYLE.smallButton },
              '✕',
            ),
          ),
          h(
            'div',
            { style: STYLE.dialogBody },
            h('div', { style: STYLE.note }, this.state.failure),
          ),
        );
      }
    }

    // ------------------------------------------------------------ the plugin

    return {
      inject: ['slots'],
      apply(ctx) {
        /** Resolve the Client sessions service lazily, so a missing service cannot break a render. */
        const sessionsOf = () => {
          try {
            return ctx.get('sessions');
          } catch (err) {
            return undefined;
          }
        };

        /**
         * Load the whole Client event window for one bound session.
         *
         * The prefix matters: a request carries the ENTIRE conversation so far, so
         * rebuilding one call from a partial window would silently drop messages.
         * A full walk also guarantees the Turn boundaries (`turn/start`) are
         * present before `buildTurnCalls` runs.
         *
         * HOW the walk happens matters just as much, and it is the whole reason the
         * first open of a long conversation felt slow. A page holds about two Turns
         * (the Host stops at the first Turn start past ~50 messages), so a long
         * session is 40+ pages; `loadOlder()` publishes every single page, which
         * re-renders the transcript 40+ times while the user waits, and a plain
         * loop awaits each round trip in turn. That work happened in `loadFullWindow`
         * below — see its comment for the jump loader that replaces it.
         */
        /** Per-session prefetch state; see `ensurePrefetch` below. */
        const PREFETCH = new Map();

        const readWindow = async (sessionId) => {
          const sessions = sessionsOf();
          if (!sessions || typeof sessions.binding !== 'function') throw new Error('sessions service unavailable');
          const binding = sessions.binding(sessionId);
          if (!binding) throw new Error('session is not bound');
          /* A read already on its way (the prefetch) is not repeated: wait for it,
             then fall through — it left the window complete. */
          const inFlight = PREFETCH.get(sessionId);
          if (inFlight && inFlight.status === 'pending') {
            try {
              await inFlight.promise;
            } catch (error) {
              /* a failed prefetch is not a failed read: walk the window below */
            }
          }
          return loadFullWindow(binding);
        };

        /**
         * Read the window BEFORE it is asked for.
         *
         * Opening a dialog on a long conversation waits for two things: the Host
         * walking the session back (round trips, ~1 s) and then the app rendering
         * the pages it just received. Both are unavoidable at SOME point — a
         * request carries the whole conversation — but neither has to happen while
         * a reader stares at a modal. `loadThrough` grows the shared Client window,
         * so once the read has happened every later `readWindow` finds the window
         * already complete and only re-collects it (milliseconds).
         *
         * Triggered a moment after an action button first appears for a session,
         * i.e. once the reader is looking at that conversation, and once per
         * session either way: a button that is never pointed at costs nothing.
         */
        const ensurePrefetch = (sessionId) => {
          if (!sessionId) return;
          const known = PREFETCH.get(sessionId);
          if (known) return known.promise;
          const entry = { status: 'pending', ms: 0 };
          PREFETCH.set(sessionId, entry);
          const startedAt = monotonicNow();
          entry.promise = Promise.resolve()
            .then(() => {
              const sessions = sessionsOf();
              if (!sessions || typeof sessions.binding !== 'function') return null;
              const binding = sessions.binding(sessionId);
              if (!binding) return null;
              return loadFullWindow(binding);
            })
            .then((events) => {
              entry.status = events ? 'done' : 'skipped';
              entry.ms = monotonicNow() - startedAt;
              if (typeof console !== 'undefined' && console && typeof console.debug === 'function') {
                console.debug(
                  '[dsh-payload] prefetch ' +
                    (events ? events.length + ' events' : 'skipped') +
                    ' in ' +
                    entry.ms.toFixed(0) +
                    ' ms',
                );
              }
              return events;
            })
            .catch((error) => {
              entry.status = 'failed';
              entry.ms = monotonicNow() - startedAt;
              if (typeof console !== 'undefined' && console && typeof console.debug === 'function') {
                console.debug('[dsh-payload] prefetch failed: ' + String((error && error.message) || error));
              }
              return null;
            });
          return entry.promise;
        };

        /**
         * The action row hands us a durable message id, so resolve that message to
         * its Turn and step first, then rebuild the whole Turn and pre-select the
         * call that produced it.
         *
         * `hooks` is how the caller stays in the loop while that happens:
         * `onPhase()` once the window is in and the rebuild is about to start,
         * `onProgress(done, total)` between rebuild slices, and `isGone()` for
         * "the reader closed the dialog, stop working".
         */
        const buildTurnForMessage = async (sessionId, messageId, hooks) => {
          const settings = hooks && typeof hooks === 'object' ? hooks : {};
          const onPhase = settings.onPhase;
          try {
            if (!messageId) throw new Error('no message id');
            const readStarted = monotonicNow();
            const events = await readWindow(sessionId);
            const readMs = monotonicNow() - readStarted;

            /* Everything below is one long task: locate, rebuild, and then the
               first render of a JSON tree that can be megabytes wide. The caller
               cannot repaint the seconds counter once that starts, so announce the
               phase first and give the browser a frame to paint it — a wait that
               says what it is doing reads as progress, a frozen counter reads as
               a hang. */
            if (typeof onPhase === 'function') {
              try {
                onPhase(events.length);
              } catch (error) {
                /* a broken listener must not break the read */
              }
              await nextPaint();
            }

            const spot = locateMessage(events, messageId);
            if (!spot) return { status: 'empty' };

            /* Key on the Turn's own span plus the window's first seq (a header
               that only becomes visible when older pages arrive can change a
               rebuild). A closed Turn is immutable, so its entry stays valid
               while the rest of the session keeps growing. */
            let lastSeq = 0;
            let firstSeq = 0;
            for (let i = 0; i < events.length; i += 1) {
              const seq = seqOf(events[i]);
              if (seq > lastSeq) lastSeq = seq;
              if (i === 0) firstSeq = seq;
            }
            const bounds = turnBounds(events, spot.turn);
            const spanEnd = bounds && bounds.end >= 0 ? bounds.end : lastSeq;
            const cacheKey =
              String(sessionId) +
              ':' +
              String(spot.turn) +
              ':' +
              String(spanEnd) +
              ':' +
              String(firstSeq);
            const cached = builtCache.get(cacheKey);
            let built = cached ? cached.built : null;
            const cacheHit = Boolean(built);
            const buildStarted = monotonicNow();
            if (!built) {
              /* Sliced, not one long task: a Turn of a long conversation can take
                 ~190 ms to rebuild, and a task that long cannot paint the spinner
                 or the progress line it is being watched through. Between slices
                 the browser gets a frame; `isGone` stops the work if the reader
                 closed the dialog meanwhile. */
              built = await buildTurnCallsChunked(events, spot.turn, undefined, undefined, {
                onProgress: settings.onProgress,
                abandoned: settings.isGone,
              });
            }
            const buildMs = cacheHit ? 0 : monotonicNow() - buildStarted;
            /* One line per open, so the next "it is slow" report can say WHICH part
               was slow: reading the window, rebuilding the Turn, or (by subtraction
               from the total the caller logs) the first render. */
            if (typeof console !== 'undefined' && console && typeof console.debug === 'function') {
              console.debug(
                '[dsh-payload] window ' +
                  events.length +
                  ' events in ' +
                  readMs.toFixed(0) +
                  ' ms · rebuild ' +
                  (cacheHit ? 'cached' : buildMs.toFixed(0) + ' ms'),
              );
            }
            /* Re-insert on a hit too: that is what makes the eviction order the
               reuse order, so the Turn being read right now is the last to go. */
            if (built) rememberBuilt(cacheKey, built);
            if (!built || !Array.isArray(built.calls) || !built.calls.length) return { status: 'empty' };

            return {
              status: 'ready',
              data: built,
              selectedIndex: callIndexForStep(built, spot.step),
              step: spot.step,
              /* The row this dialog was opened FROM, so the JSON can open already
                 scrolled to (and highlighting) that message's own line. */
              focusKey: conversationNodeKey('assistant-step', spot.turn + ':' + spot.step),
            };
          } catch (err) {
            return { status: 'error', message: String((err && err.message) || err) };
          }
        };

        function PayloadButton(props) {
          const messageId = props.messageId;
          const sessionId = props.sessionId;

          const readScheme = () => {
            try {
              const theme = ctx.get('theme');
              const snapshot = theme && typeof theme.getTheme === 'function' ? theme.getTheme() : null;
              const active = snapshot && snapshot.active ? snapshot.active.colorScheme : null;
              if (active === 'dark' || active === 'light') return active;
            } catch (err) {
              /* fall through to the media query */
            }
            try {
              if (typeof window !== 'undefined' && typeof window.matchMedia === 'function') {
                return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
              }
            } catch (err) {
              /* default below */
            }
            return 'light';
          };

          /* The label is positioned from the trigger's own rect: the shipped tooltips
             are portalled for exactly this reason, and a bubble inside the message
             flow would be clipped by the scroller near the bottom of the page. */
          const triggerRef = React.useRef(null);
          const [tip, setTip] = React.useState(null);

          /* Read the window before anyone asks for it: the first open of a long
             conversation has to walk the whole session back, and doing that while a
             modal says "reading… 1 s" is the slow part. The button appears as soon
             as the reader is looking at this conversation, so a short delay is
             enough of an intent signal; `ensurePrefetch` keeps it to one read per
             session and logs what it cost. */
          React.useEffect(() => {
            if (!sessionId || typeof setTimeout !== 'function') return undefined;
            const timer = setTimeout(() => {
              ensurePrefetch(sessionId);
            }, 300);
            return () => {
              if (typeof clearTimeout === 'function') clearTimeout(timer);
            };
          }, [sessionId]);

          const showTip = () => {
            /* Pointing at the button is the strongest available intent signal, and
               it arrives before the click does — so the read gets a head start
               instead of starting on the click and freezing the dialog. */
            ensurePrefetch(sessionId);
            const node = triggerRef.current;
            if (!node || typeof window === 'undefined') return;
            const rect = node.getBoundingClientRect();
            const below = rect.bottom + 6;
            /* Below, like the rest of the row — unless there is no room left. */
            const side = window.innerHeight - below >= 30 ? 'bottom' : 'top';
            setTip({
              side: side,
              left: rect.left + rect.width / 2,
              top: side === 'bottom' ? below : rect.top - 6,
            });
          };

          const hideTip = () => setTip(null);

          const openDialog = () => {
            hideTip();
            const scheme = readScheme();
            const token = (dialogToken += 1);
            /* Nothing here is incremental — one request carries the whole
               conversation, so the read is all-or-nothing — which is why this line
               does not print a number. The read and the rebuild hold the main
               thread, so a printed number can only stand still while the work it
               counts runs, and two readers in a row read a standing number as a
               broken counter. Liveness is the composited spinner's job; the
               measurements go to the console, where arriving late costs nothing. */
            const showLoading = (note) =>
              publishDialog({ status: 'loading', title: TEXT.title, scheme: scheme, note: note, token: token });
            showLoading(TEXT.readingHistory);

            const startedAt = monotonicNow();
            /* Still watch the frame clock — not to print anything, but to record
               how long the thread was gone. A frame interval above half a second is
               the app rendering the window it just published, and it is the one
               number that explains an open that "felt stuck". */
            let watching = true;
            let frame = null;
            if (typeof requestAnimationFrame === 'function') {
              let lastFrameAt = startedAt;
              const step = () => {
                if (!watching) return;
                frame = requestAnimationFrame(step);
                const nowAt = monotonicNow();
                const gap = nowAt - lastFrameAt;
                lastFrameAt = nowAt;
                if (gap > 500 && typeof console !== 'undefined' && console && typeof console.debug === 'function') {
                  console.debug('[dsh-payload] no frame drawn for ' + gap.toFixed(0) + ' ms (main thread busy)');
                }
              };
              frame = requestAnimationFrame(step);
            }
            const stopTicker = () => {
              watching = false;
              if (frame !== null && typeof cancelAnimationFrame === 'function') cancelAnimationFrame(frame);
              frame = null;
            };
            const stillMine = () => Boolean(dialogPayload) && dialogPayload.token === token;

            /* The read is done and the rebuild starts. The rebuild is sliced, so
               the line below can actually be repainted between slices: the count
               moves because the browser is painting frames now, not because we
               asked it to while it could not. */
            const onPhase = () => {
              if (!stillMine()) return;
              stopTicker();
              showLoading(TEXT.rebuilding);
            };
            const onProgress = (done, total) => {
              if (!stillMine()) return;
              showLoading(TEXT.rebuildingProgress(done, total));
            };

            buildTurnForMessage(sessionId, messageId, {
              onPhase: onPhase,
              onProgress: onProgress,
              isGone: function isGone() {
                return !stillMine();
              },
            }).then(
              function (result) {
                stopTicker();
                /* Closed or replaced while reading: a late result must not pop the
                   dialog back open. */
                if (!stillMine()) return;
                if (typeof console !== 'undefined' && console && typeof console.debug === 'function') {
                  console.debug(
                    '[dsh-payload] ' + result.status + ' in ' + (monotonicNow() - startedAt).toFixed(0) + ' ms',
                  );
                }
                const built = result.status === 'ready' && result.data ? result.data : null;
                const title = built
                  ? TEXT.title +
                    ' · Turn ' +
                    built.turn +
                    (typeof result.step === 'number' ? ' · step ' + result.step : '')
                  : TEXT.title;
                publishDialog(Object.assign({ title: title, scheme: scheme, token: token }, result));
              },
              function (error) {
                stopTicker();
                if (!stillMine()) return;
                publishDialog({
                  status: 'error',
                  message: String((error && error.message) || error),
                  title: TEXT.title,
                  scheme: scheme,
                  token: token,
                });
              },
            );
          };

          /* Icon first, name on hover: the shipped row is icon-only, and a text
             button there would break its rhythm. */
          return h(
            'button',
            {
              type: 'button',
              ref: triggerRef,
              className: 'dsh-pl-action',
              'aria-label': TEXT.show,
              onClick: openDialog,
              onMouseEnter: showTip,
              onMouseLeave: hideTip,
              onFocus: showTip,
              onBlur: hideTip,
            },
            h(
              'svg',
              {
                className: 'dsh-pl-icon',
                viewBox: '0 0 16 16',
                fill: 'none',
                stroke: 'currentColor',
                strokeWidth: 1.4,
                strokeLinecap: 'round',
                strokeLinejoin: 'round',
                'aria-hidden': 'true',
              },
              h('path', {
                d:
                  'M6.2 2.5H5.4C4.3 2.5 3.6 3.2 3.6 4.3V5.9C3.6 6.9 3.1 7.6 2.2 7.8V8.2' +
                  'C3.1 8.4 3.6 9.1 3.6 10.1V11.7C3.6 12.8 4.3 13.5 5.4 13.5H6.2',
              }),
              h('path', {
                d:
                  'M9.8 2.5H10.6C11.7 2.5 12.4 3.2 12.4 4.3V5.9C12.4 6.9 12.9 7.6 13.8 7.8V8.2' +
                  'C12.9 8.4 12.4 9.1 12.4 10.1V11.7C12.4 12.8 11.7 13.5 10.6 13.5H9.8',
              }),
            ),
            tip
              ? h(
                  'span',
                  {
                    key: 'tip',
                    role: 'tooltip',
                    className: 'dsh-pl-tip',
                    style: {
                      left: tip.left + 'px',
                      top: tip.top + 'px',
                      transform:
                        tip.side === 'bottom' ? 'translate(-50%,0)' : 'translate(-50%,-100%)',
                    },
                  },
                  TEXT.show,
                )
              : null,
          );
        }

        /* Sit beside the shipped per-message actions (copy, good/bad answer),
           matching the durable assistant message they belong to. */
        ensureActionStyle();
        if (typeof console !== 'undefined' && console && typeof console.debug === 'function') {
          console.debug('[dsh-payload] ' + VERSION + ' loaded');
        }
        ctx.slots.inject('conversation.chat.assistant-actions', () =>
          ctx.slots.register(
            {
              name: 'conversation.chat.assistant-actions',
              id: 'payload',
              order: 15,
              label: () => TEXT.show,
            },
            PayloadButton,
          ),
        );

        ctx.slots.inject('shell.overlay', () =>
          ctx.slots.register(
            {
              name: 'shell.overlay',
              id: 'payload.dialog',
              order: 900,
            },
            PayloadOverlay,
          ),
        );
      },
    };
  },
});


