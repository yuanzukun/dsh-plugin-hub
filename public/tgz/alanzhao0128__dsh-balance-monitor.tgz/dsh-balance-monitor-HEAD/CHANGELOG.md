# Changelog

All notable changes to this project are documented here. The format is based on
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.8.2] — 2026-10-17

### Added

- **DSH 0.2.1-rc.2 规范与兼容性一等公民声明**：
  - 在 `package.json` 的 `engines` 中正式添加 `"dsh": ">=0.1.2-rc.1"`，对齐 DSH 0.2.1 优先读取 `engines.dsh` 的最新插件判定机制。
- **Claude Pro 渠道设置页说明**：
  - 在设置页的渠道凭证列表中新增 Claude Pro 专属说明卡片（中英双语），阐明其自动复用 `network.cpaBaseUrl` 与 Nginx 配额缓存端点的工作机制。

### Improved

- **Claude Pro 配额查询健壮性与优雅降级**：
  - Host 端增加基于 `network.cacheMs` 的进程内内存缓存，杜绝客户端多标签高频轮询触发 VPS Nginx 限流；
  - 增加网络抖动优雅降级机制（Graceful Fallback），在上游临时瞬断或超时时自动复用最后一次成功快照并标记 `stale: true`，消除界面闪烁；
  - 自动穿透检测并支持 `CPA_BASIC_AUTH` 请求头。

## [0.8.1] — 2026-10-14

### Fixed

- **修复 Claude Pro 官方配额重置倒计时显示 `NaNh NaNm` 的问题**：
  - 根因：服务端 `/v0/claude/quota` 响应中的 `resetAt` 为 ISO-8601 字符串格式，前端 `fmtReset` 计算时间差时产生 `NaN`；
  - 修复：Host 端与 Client 端双重解析，确保 `resetAt` 统一规范化为毫秒时间戳（`number`），正常呈现剩余小时和分钟倒计时。

## [0.8.0] — 2026-10-14

### Added

- **支持 Claude Pro 官方订阅用量监控（`claude-official` 渠道）**：
  - 渠道表（`CHANNELS`）正式注册 `claude-official` 映射至 `claude-plan` 卡片；
  - 服务端统一架构支持：Host 端自动复用 `network.cpaBaseUrl` 请求 CPA 部署的 `/v0/claude/quota` 端点，免在本地配置敏感 Token；
  - 侧边栏卡片精准呈现官方 5 小时滑动窗口（`5h`）与 7 天周度窗口（`weekly`）使用率百分比与官方精确重置时间（`resetAt`）；
  - 折叠态与展开态完整支持，支持预警阈值色变及过期间隔自动标记。

## [0.7.11] — 2026-09-30

### Added

- **支持官方 Desktop 桌面端账号登录（`deepseek-account` 渠道）**：
  - 渠道表（`CHANNELS`）正式注册 `deepseek-account` 映射至 `balance` 卡片；
  - 后端 `/balance` 处理器支持从系统凭证库自动嗅探 Desktop 账号登录记录（`deepseek-account-platform/default`），免配置 API Key 与平台 Token，自动通过官方 `get_user_summary`（充值钱包 + 赠金钱包）与 `usage/cost`（今日/7日/30日花费）接口拉取最新实时数据；
  - 保持与原有的 `deepseek-official`（API Key）模式无缝双轨兼容。

## [0.7.10] — 2026-09-29

### Fixed

- **0.1.7 下插件无法激活：`ValidationError: invalid config`**。0.7.8 引入的
  volatile 标记同时打在了**容器对象**（`ui` / `network` / `credentials`）和
  **叶子字段**上。schemastery 从 3.18.4 起禁止 volatile 嵌套 volatile
  （`volatile fields require a fixed object path without an enclosing volatile
  field`），宿主在解析配置阶段直接拒绝，启动时报
  `balance-monitor (@alanzhao/dsh-balance-monitor): ValidationError: invalid
  config: $.ui.showCard …`，整个条目**不激活**（卡片与设置页都不出现）。
  0.7.9 的本地测试没能暴露它，因为仓库内解析到 schemastery 3.18.2（尚无该校验），
  而 profile 里是 3.18.4。
  现改为**只标记叶子字段**：设置表单仍能看到全部字段（`volatileForm` 会递归
  普通对象并收集叶子），每个字段的写入路径仍是 volatile（写入不被拒）。
  同时把本地 schemastery 提到 3.18.4，并新增回归断言（配置解析无 issues +
  表单字段完整 + 写入路径合法），避免「本地绿、profile 挂」再次发生。

## [0.7.9] — 2026-09-29

### Fixed

- **0.1.7 下侧边栏卡片完全不显示**。根因是会话列表快照的结构变更：
  `sessions.list.getSnapshot()` 在 dsh ≤ 0.1.5 上带 `current`（当前会话 id），
  而 **0.1.7 删除了该字段**，改为逐行持有保留计数
  （`byId[id].retainedBy.mainView`，主视图正在显示的会话计数为正）。
  卡片原先只读 `current`，在 0.1.7 上永远拿到 `undefined` → 判定「无会话」
  → `return null`，于是**不报错、不渲染**，看起来就像插件没装上。
  现改为 `activeSessionId()` 双形态解析：优先 `current`（0.1.5），
  缺失时在 `byId` 中找 `retainedBy.mainView > 0` 的行（0.1.7），
  并保留调用方已在跟随且仍被主视图持有的会话 id。
  0.1.8/未来版本若再改结构，最坏情况是回退到「无会话」而不会抛错。

## [0.7.8] — 2026-09-29

### Changed

- **DSH 0.1.7+ 双轨兼容适配**：全面适配 DSH 0.1.7 架构重构（Settings Provider 废弃与前端 `settingsScope` 移除），同时保持对 DSH 0.1.5 的完整向下兼容。
  - **前端解死锁**：从静态 `inject` 依赖数组中移除了已在 0.1.7 废弃的 `'settingsScope'` 服务，彻底解决在 0.1.7 下 Cordis 插件生命周期被挂起导致侧边栏卡片无法渲染的问题。
  - **双栈设置控制器 (`resolveScope`)**：运行时动态探测设置服务：在 DSH >= 0.1.7 下优先接入 `configForms`（按 `balance-monitor` 条目 ID 寻址），在 DSH <= 0.1.5 下平滑回退到 `settingsScope`（按 `dsh-balance-monitor` 命名空间寻址）。
  - **后端 Config 导出与 Volatile 声明**：`lib/index.js` 导出 `Config` schema，并在字段上标记 `volatile`，支持 0.1.7 SettingsForms 的表单内省与在线保存写回 `cordis.patch.yml`；调用 `settings.configure({ auto: false })` 关闭自动生成的简陋表单，保留定制设置页。
  - **双轨安装适配 (`installSettingsCompat`)**：后端在 `installSection` 可用时走 0.1.5 传统注册，在 SettingsForms 下监听 `app-boot/config-reload` 实现配置热更新。

## [0.7.7] — 2026-09-26

### Added

- **CPA 快照过期自愈**：`antigravity-priority` 的后台定时调度由它自己的运行时
  开关 `auto_apply` 控制，而该开关**默认关闭** —— 关闭时插件只在被显式要求时
  才探测一次。于是照 README 搭好、但没开 `auto_apply` 的部署，快照会永远停在
  最后一次探测的数字上：卡片不报错、也有数，但**几小时都不动**（0.7.6 及以前
  本插件只在快照**为空**时才补探测，对"有数据但过期"无能为力）。
  现在 host 端把「过期」与「为空」同等对待：快照超过 `network.cpaStaleMs`
  即补一次探测，且**只探测、不写回凭证优先级**，不改变 CPA 侧的账号调度行为。
  补探测是 fire-and-forget（探测会逐个凭证打到 Google、可能耗时数分钟，而卡片
  每 60 秒轮询一次，RPC 绝不能等它），本次先返回旧数据并标 `stale: true`
  （卡片渲染成半透明），下次轮询自然拿到新数据；两次补探测之间有 5 分钟节流，
  避免探测持续失败时把 Google 配额接口打爆。
- 新增设置项 `network.cpaStaleMs`（默认 `1200` 秒），设置面板 →「网络」可调，
  建议大于 CPA 侧的定时探测周期（插件默认 15 分钟）。
- README（中英）在搭建指南里明确写出 `auto_apply` 这个坑：默认关闭会导致卡片
  冻住，给出两条解法（开启插件原生调度 / 依赖本插件兜底），并附排查方法
  （看 `diagnostics` 的 `management_api.auto_apply` 与 `run_history`）。

### Fixed

- **README 的 nginx 示例缺 `client_max_body_size`，照着搭会撞 413**。nginx 在
  `location /v1/` 的内置默认上限只有 **1m**，而 0.5M token 的上下文光文本就
  ≥2MB —— 超限时请求在反代就被拒（响应体是 nginx 的 HTML 错误页，形如
  `413 Request Entity Too Large`），CPA 与模型都收不到，也与模型自身的 token
  上限无关。示例的 `/v1/` 现补上 `client_max_body_size 128m;` 与
  `proxy_request_buffering off;`（大 body 直传上游，不先落盘缓冲），并在踩坑
  清单新增两条：413 的判定与「该指令不会从兄弟 location 继承」，以及大上下文的
  真正瓶颈是**客户端上行带宽**（实测反代侧 3MB ≈ 15s）。

## [0.7.6] — 2026-09-25

### Changed

- **`network.cpaBaseUrl` 默认值改为空**。此前它硬编码了本项目维护者自己的
  CLIProxyAPI 部署地址，这既把一个人的私有主机名发布给了所有使用者，也会让
  其他使用者的配额请求打到陌生人的服务器上。现在该字段默认留空，cliproxy 渠道
  在填写前保持休眠（host 端返回 `unconfigured`，不发任何网络请求）。
  **升级后需要手动填写**：升级前依赖旧默认值的安装请在设置面板 →「网络 → CPA 地址」
  填回自己的地址，否则卡片会提示「未配置 CPA 地址」。
- 设置面板的 CPA 地址提示改为占位示例 `https://cpa.example.com`；空值输入会自动
  去掉首尾空格与结尾 `/`（`https://host/` 也能用）。

### Added

- **卡片空状态**：CPA 地址未配置 / 凭证被拒时，卡片显示对应的说明文字
  （「未配置 CPA 地址」/「CPA 凭证未配置或被拒绝」）而不是一张空卡片；
  折叠态与 tooltip 同步显示原因。
- **README 新增「Google AI Pro（CLIProxyAPI）渠道搭建」完整指南**（中英双语）：
  这条链路无法复用现成接口（Google 侧没有配额 API，CPA 自身也不暴露配额，必须
  由配额插件探测），因此补上可复现的全流程 —— 链路图、CPA `config.yaml`
  （`allow-remote` / `remote-management.secret-key` / `plugins` / `trusted-proxies`）、
  容器只监听回环、nginx 反代示例（限流 + `/v1/` 直通 + `/v0/` Basic +
  `Authorization` 头改写 + 其余 404）、插件侧三个字段怎么填、三步 curl 自检，
  以及踩坑清单（501 与空快照、认证头冲突、**连续失败封源 IP 约 30 分钟**、
  nginx 1.24 的 `http2 on;` 不支持、必须 TLS、推理与管理是两套密钥）。
  文档中所有主机名均为 `cpa.example.com` 占位。

## [0.7.5] — 2026-09-25

### Changed

- **Google AI Pro 卡片的用量语义回归与火山方舟 / Command Code 一致**：数字改为
  **已用百分比**（`100 - 剩余`），进度条按已用比例填充、配色按已用分档
  （≥ danger 红、≥ warn 黄、否则绿），与两张同类的套餐额度卡完全同款。
  0.7.4 曾把该卡单独改成"剩余"语义，虽然卡内自洽，但与既有的两张卡读法不同，
  同一块侧边栏里出现两种口径反而更难扫读。
- 折叠态同样改为显示已用%（优先取当前活跃模型组的 5h 窗口，其次任意 5h，最后
  取用量最高的窗口），与方舟折叠态的选择逻辑一致。

## [0.7.4] — 2026-09-25

### Fixed

- **Google AI Pro 卡片：`Gemini 5h` 被截断成 `Gemini ...`**。组标签列宽
  52px 装不下 `Gemini` + 窗口名，现已加宽到 64px（进度条相应由 72px 收到
  62px，整行宽度不变）。

### Changed

- **Google AI Pro 卡片的进度条改为按「剩余额度」填充**，颜色也改为按剩余分档
  （剩余 ≤ 30% 红、≤ 70% 黄、否则绿）。此前数字显示的是剩余百分比，而进度条
  与配色沿用了 Ark / Command Code 的「已用」语义，导致「剩余 100%」渲染成一条
  空进度条，容易被误读成额度已用尽。现在数字、填充比例、颜色三者语义一致：
  满条 + 绿色 = 额度充足。

## [0.7.3] — 2026-09-25

### Added

- **Google AI Pro 渠道卡片（cliproxy / CPA 反代）**：会话使用 `cliproxy`
  provider（Google Antigravity 经 CLIProxyAPI 反代）时，侧边栏显示该渠道的
  5 小时 / 每周剩余配额，按 `gemini` 与 `claude_gpt` 两个模型组分行，带重置
  倒计时；折叠态显示 5h 窗口剩余比例。卡片沿用 Ark / Command Code 的进度条
  语义（按已用比例着色），CPA 上报的是剩余量，卡内取 `100 - 剩余`。
- 新增 host RPC `cpa-quota/snapshot`（走 0.7.2 起的 `/api` 精确路由）：
  经 `network.cpaBaseUrl`（默认**留空**，见 0.7.6）读取 CPA 管理接口
  上 `antigravity-priority` 插件探测到的配额快照；若快照为空（CPA/插件刚重启）
  自动触发一次 `?mode=probe` 再读。沿用 40s 缓存 + 上游失败回退上次数据
  （`stale: true`）的既有模式。
- 新增两条可写渠道凭证（设置页 →「渠道凭证 → Google AI Pro（CPA 反代）」）：
  `CPA_BASIC_AUTH`（nginx Basic，`user:pass`）与 `CPA_MANAGEMENT_KEY`
  （CPA 管理密钥）。两者都会出现在 `/credential-status` 的状态列表里。
- 新增设置项 `network.cpaBaseUrl`。

### Changed

- 管理接口请求同时携带两层独立凭据：`Authorization: Basic ...`（由 nginx 校验）
  与 `X-CPA-Key: <management key>`（由 nginx 改写成上游
  `Authorization: Bearer ...`）。二者不能共用一个 `Authorization` 头，这是该
  头设计的由来。

## [0.7.2] — 2026-09-10

### Changed

- **Adapted to dsh 0.1.5-rc.1**: `connection.rpc.handle` is unusable upstream
  (the connection plugin no longer injects `webServer`, so any plugin
  registering a channel through it aborts boot with
  `cannot get property "webServer" without inject` —
  deepseek-ai/deepseek-harness discussion #5926). Official plugin RPC now
  rides the shared `/api` channel as exact Fetch routes:
  - Host: the five RPC channels (`/balance`, `/ark-quota`, `/cmdcode-quota`,
    `/credential-status`, `/session-provider`) register via
    `connection.fetch.register` as `/api/<channel>/snapshot` exact routes,
    behind a `rpcHandle(ctx, channel, endpoint, handler)` shim that keeps the
    old call shape (handler signatures unchanged). The `client-request` →
    `server-response` envelope protocol is unchanged, including the official
    `415` content-type and `400` bad-envelope branches; unexpected handler
    throws answer `200 + { ok: false, error: { code: 'gateway/internal' } }`
    so the browser client never leaves its graceful `{ ok: false }` path.
  - Client: `connection.rpc.call('/api', '<channel>/snapshot', payload)`
    replaces `connection.rpc.call('<channel>', 'snapshot', payload)` at all
    five call sites; response parsing (`result.ok` / `result.value`) is
    unchanged.

## [0.7.1] — 2026-09-07

### Fixed

- **The card did not follow the model channel when switching between sessions
  that use different channels** (in-session switches worked, cross-session did
  not). The `/session-provider` RPC now resolves the *active session's* model
  selection via `ctx.sessionController.resolveAgent(sessionId)` and the
  session-scoped `modelSelection` projection (`pending ?? lastUsed`), falling
  back to `agentDefaultModel.currentSelection()` when the session is
  unresolvable. The client passes the active `sessionId` as the RPC payload.

## [0.7.0] — 2026-09-07

### Changed

- **Adapted to dsh 0.1.2-rc.1** (breaking platform upgrade; requires the
  0.1.2-rc.1 host — the old 0.1.1-rc.2 host does not provide the new APIs):
  - Host: settings registration moved from the removed
    `installSettingsSection(ctx, settingsNamespace(...))` to
    `settings.installSection(ctx, 'dsh-balance-monitor', ...)` via a lazy
    `ctx.inject(['settings'])` (absent settings service is a silent no-op).
  - Host: `rpc.handle` calls dropped the removed third `{ authority }`
    argument.
  - Host: new `/session-provider` RPC resolves the card's channel from
    `ctx.agentDefaultModel.currentSelection()` (with a display name from the
    LLM registry), replacing the removed browser `connection.api.sessions.models`
    aggregate. DSH keeps the default in sync with session model switches, so
    the card still follows the session channel.
  - Client: settings saves go through the bound `scope.mutate(ops, revision)`
    (replaces `connection.api.settings.mutate`); credential writes go through
    `remote.credentials.set(ref, value)` (replaces
    `connection.api.credentials.set`); the inject list adds `remote`,
    `remote.credentials`.
  - Packaging: `dsh.client.inject` no longer names the removed
    `@deepseek-ai/dsh-client-runtime`; depends on `@deepseek-ai/schemastery`
    only (dsh-settings no longer imported at runtime).

## [0.6.5] — 2026-08-28

### Fixed

- **Browser bundle registered the unscoped id**: `lib/client.js` called
  `__ModuleLoader__.load({ id: 'dsh-balance-monitor' })`, but the loader
  expects the entry id to match the (scoped) package name, so the client
  bundle failed to register with
  `loaded without registering "@alanzhao/dsh-balance-monitor"`. The client now
  registers as `@alanzhao/dsh-balance-monitor`.

## [0.6.4] — 2026-08-28

### Fixed

- **npm install broke the profile boot**: the bundle patch's entry `name` was
  the unscoped `dsh-balance-monitor`, but the package is published as the scoped
  `@alanzhao/dsh-balance-monitor`. Cordis's loader imports the entry by that
  name, so a fresh npm install failed with
  `ERR_MODULE_NOT_FOUND: Cannot find package 'dsh-balance-monitor'`. The patch
  now uses `@alanzhao/dsh-balance-monitor`.

## [0.6.3] — 2026-08-28

### Changed

- **Merged the two upstream timeouts into one**: `network.platformTimeoutMs`
  (DeepSeek official usage) is gone; all quota/usage fetches (Volcano Ark,
  Command Code, DeepSeek platform) now share `network.timeoutMs` (default 20 s).
  The settings panel shows a single 上游超时 / Upstream timeout field.

## [0.6.2] — 2026-08-28

### Fixed

- **Channel-credential panel still showed all "not configured"** (and region
  `—`) even after the host fix: the client's `/credential-status` fetch
  destructured `{ result }` from `connection.rpc.call(...)`, but `rpc.call`
  resolves to `{ ok, value }` directly (the `{ result }` wrapper only applies
  to `connection.api.*` calls). The fetch threw → `credStatus` stayed null.
  Now reads `result.ok` / `result.value` directly, matching the other cards.

## [0.6.1] — 2026-08-28

### Fixed

- **Channel-credential status showed everything as "not configured"** after
  the 0.6.0 upgrade: the host plugin's `inject` array declared only
  `connection`, so cordis did not guarantee the `credentials`/`settings`/`llm`
  services were ready at `apply()` time — `ctx.get()` failed (silently
  swallowed) and `/credential-status` fell back to the no-service path
  (all `configured: false, managedByDsh: false`).
  - Declared `credentials`, `settings`, `llm` in the host `inject` array.
  - Services are now resolved lazily: `refreshServices()` runs at `apply()`
    and on every RPC entry, and only replaces a cached reference when the
    service resolves non-null (an early miss can't clobber a later success).
  - `readCredential()` continues to fall back to env + direct file parsing
    when the seam is absent, so balance/usage lookups were never affected.

## [0.6.0] — 2026-08-28

### Added

- **Channel credentials group** in the settings panel: shows every credential
  each channel needs and its status, split by ownership:
  - Read-only rows (referenced by the DSH model configuration, decided via
    `ctx.llm.listConfigurableProviders()` + `ctx.settings.describe()`):
    `DEEPSEEK_API_KEY`, `COMMANDCODE_API_KEY`.
  - Writable password boxes (plugin-specific): `DEEPSEEK_PLATFORM_TOKEN`
    (existing, moved into the group, with the three-part explainer),
    `ARK_ACCESS_KEY_ID`, `ARK_SECRET_ACCESS_KEY` — saved through the official
    `credentials.set` seam, never written by the plugin.
- New host RPC `/credential-status` (loopback): per-ref configured/writable/
  source + `managedByDsh` flag, plus the resolved Ark region.

### Changed

- **Sidebar card follows the current session's provider again** (reverts the
  0.5.1 fixed multi-card model): one card for the active channel (DeepSeek /
  Volcano Ark / Command Code), unsupported placeholder otherwise, nothing
  without a session. The `channels.enabled` setting and its checkboxes are
  removed entirely.
- **Ark region follows the DSH model configuration**: `fetchArkQuota` now
  resolves the region from the huoshan provider's `baseURL`
  (`ark.<region>.volces.com`), falling back to `cn-beijing`; no manual
  selection needed.
- `providerConfig()` resolves a configurable provider's config via its
  declared `settingsPath`, covering both the top-level shape
  (`dsh-llm-deepseek`, `settingsPath: []`) and the nested shape
  (`dsh-llm-pi-ai`, `settingsPath: ["providers", "<id>"]`).

## [0.5.2] — 2026-08-28

### Fixed

- **Sidebar cards vanished** after upgrading to 0.5.1: schemastery fills an
  absent `channels.enabled` array with `[]` (not `undefined`), so the client's
  settings reader saw an empty list and rendered no cards. The schema now
  declares `.default(CHANNEL_DEFAULT)` and the client falls back to all
  channels on an empty list — the cards can never silently disappear.
- **Channel checkboxes were unclickable** in the settings panel: the
  channel-toggle handler called an undefined `onChange` (should have been
  `setField`), throwing on every click. Fixed.

## [0.5.1] — 2026-08-28

### Added

- **Channel display configuration** (`channels.enabled`): the settings panel
  gained a 渠道 group with one checkbox per provider (DeepSeek official /
  Volcano Ark / Command Code). Checked channels now render **fixed cards** in
  the sidebar — all at once, stacked, independent of the current session —
  instead of following the session's provider. An empty list falls back to
  all channels so the widget can never silently disappear.

### Changed

- **Seconds instead of milliseconds** in the settings panel: `ui.pollMs`,
  `network.cacheMs`, `network.timeoutMs`, `network.platformTimeoutMs` are
  edited as seconds (e.g. 60, 40, 20, 15) and converted to ms on save — the
  document still stores ms, so existing values stay valid. Removed
  `ui.providerPollMs` (provider detection is gone with the fixed-card model).
- The `DEEPSEEK_PLATFORM_TOKEN` box now carries a three-part explainer:
  what it is (web-session token — the API key only queries balance, spend
  needs this), how to get it (platform.deepseek.com → DevTools Console →
  `JSON.parse(localStorage.getItem('userToken')).value`), and what it does
  (real official usage instead of a balance-delta estimate).

## [0.5.0] — 2026-08-27

### Added

- **Settings page** (Settings → 余额监控 / Balance Monitor): a `settings.section`
  slot editing the `dsh-balance-monitor` namespace, persisted to
  `~/.dsh/settings.yaml` via the official settings service — no more editing
  `cordis.patch.yml` to tune the card.
  - Display: `ui.showCard` (hide the sidebar card and stop provider
    detection), `ui.warnThreshold` / `ui.dangerThreshold` (bar colour cutoffs).
  - Refresh: `ui.pollMs` (card poll interval, default 60000),
    `ui.providerPollMs` (provider detection, default 1000).
  - Network: `network.cacheMs` (host quota cache, default 40000),
    `network.timeoutMs` (Ark / Command Code upstream timeout, default 20000),
    `network.platformTimeoutMs` (DeepSeek platform usage timeout, default 15000).
  - Credentials: `credentials.file` (document filename relative to DSH home,
    default `.credentials.yaml`).
- **Platform token box** in the credentials group: a password field that
  writes `DEEPSEEK_PLATFORM_TOKEN` through the official
  `ctx.credentials` seam (`credentials.set`) — lands in
  `~/.dsh/.credentials.yaml` under `refs:` with lock + atomic write, no file
  editing. Shows configured / not-configured state and writability.
- **Token-expired banner** on the DeepSeek card: when the platform usage API
  answers 40002/40003 the host marks `platformTokenExpired` and the card shows
  a red hint pointing at the settings page, instead of silently falling back
  to the balance estimate.

### Changed

- Credentials are now read through the official `ctx.credentials` seam
  (process env → managed document → `.env` fallbacks) instead of hand-rolled
  regex parsing of `.credentials.yaml` — future credential-format changes are
  absorbed by the seam, not the plugin.
- All previous module constants (cache/timeout/poll) became settings-managed
  defaults; behaviour is unchanged until a user edits the panel.

## [0.4.1] — 2026-08-27

### Fixed

- Command Code monthly window reset time showed `—`: `currentPeriodEnd` is an
  ISO string, but the parser used `Number(isoString)` (NaN) instead of
  `new Date(isoString).getTime()`. Fixed to parse ISO strings (numeric
  epoch-ms still works).

## [0.4.0] — 2026-08-27

### Added

- **Command Code channel**: when the session's provider is `commandcode`, the
  sidebar card shows 5h / weekly / monthly used % with reset countdowns and the
  plan name (GOAT / Pro / Max).
- New host RPC `/cmdcode-quota`: Bearer-auths `api.commandcode.ai/alpha/billing/credits`,
  `/alpha/usage/summary`, and `/alpha/billing/subscriptions`, normalising the
  three windows into the same shape as the Ark card; cached for 40s.
  - Monthly is derived as `totalMonthlyCredits / (totalMonthlyCredits +
    monthlyCredits)` because Command Code's API exposes the monthly quota as a
    *remaining* balance, not a used/cap window.
- Credential `COMMANDCODE_API_KEY` read from `.credentials.yaml` (indented-safe).

## [0.3.5] — 2026-08-21

### Fixed

- Credentials no longer resolve after DSH upgraded to 0.1.1-rc.1, which
  migrated `$DSH_HOME/.credentials.yaml` to an indented `refs:` structure
  (`  KEY: value`). The host half's regexes anchored the key at line start
  (`^KEY:`), so every credential read failed and both `/balance` and
  `/ark-quota` returned "not found". Anchors relaxed to `^\s*KEY:` — both the
  legacy flat format and the new indented format are parsed.

## [0.3.4] — 2026-08-18

### Changed

- Volcano Ark quota numbers now show **used %** on the wide card and the
  collapsed rail, matching the progress-bar fill and color (previously the
  label showed remaining % while the bar filled by used %).

## [0.3.3] — 2026-08-18

### Fixed

- Collapsed rail on the Volcano Ark card now shows the **5h** window's
  remaining percent (previously the most-used window, which could be weekly or
  monthly). Falls back to the most-used window only if 5h is absent.

## [0.3.2] — 2026-08-18

### Changed

- Ark card: progress bars widened (56px → 84px); reset countdown now
  right-aligned within each row and zero-padded to `04h 52m` / `00h 05m`
  (day prefix kept when > 0: `5d 09h 50m`).
- Ark quota refresh timing fixed: host cache reduced from 60s to 40s so it is
  strictly below the browser's 60s poll — a 60s cache + 60s poll could skip a
  refresh at the cache boundary and leave data ~2 minutes stale.

## [0.3.1] — 2026-08-18

### Changed

- Ark quota refresh now matches the DeepSeek cadence: host cache reduced from
  5 minutes to 60s.
- Ark card: removed the "N 个窗口" header counter; shortened the progress bars
  to a fixed width; added a reset countdown after the percentage
  (`2d 3h 15m`, days/hours omitted when zero, `已重置` after expiry).

## [0.3.0] — 2026-08-17

### Added

- **Volcano Ark Agent Plan channel**: `huoshan` provider renders quota bars for
  the 5h / weekly / monthly windows, colored by usage (green → amber → red).
- New host RPC `/ark-quota`: signs the `GetAFPUsage` control-plane OpenAPI with
  AK/SK (Volcengine SigV4 variant) and caches the response for 5 minutes.
- New `lib/signature.js`: pure, unit-testable Volcengine SigV4 signing
  (port of the algorithm from dsh-ark-quota, MIT).
- Credentials `ARK_ACCESS_KEY_ID` / `ARK_SECRET_ACCESS_KEY` read from
  `$DSH_HOME/.credentials.yaml` (env overrides).

### Changed

- `CHANNELS` registry entries are now objects `{ type }`: `balance` and
  `ark-plan` card variants; the ChannelCard shell dispatches on `type`.
- Docs: README (zh + en) cover the Ark channel, credentials, and layout.

## [0.2.0] — 2026-08-17

### Added

- **Channel-aware card**: the sidebar card now follows the current session's
  model provider (`session.models`). `deepseek-official` renders the balance /
  spend card; any other provider (e.g. OpenCode Go, DashScope) renders a
  minimal "channel not supported" placeholder showing the channel name; no
  current session renders nothing.
- Provider tracking combines three signals: `sessions.list` subscription
  (instant on session switch), a 1s light poll of the local `session.models`
  RPC (in-session model switches), and the `llm/adapters-updated` remote
  event (channel-catalog changes).
- Channel registry skeleton (`CHANNELS` map in `lib/client.js`) so future
  channels are one-line additions.

### Changed

- The host half (`lib/index.js`) is untouched by the channel logic: on
  non-official channels the client never calls `/balance`, so no balance or
  usage-API requests are made.

## [0.1.2] — 2026-08-14 (upstream)

- Spend ledger survives refills; refill re-fills the ratio bar.
- Collapse-rail balance format never overstates.

## [0.1.0] — 2026-08-14 (upstream)

- Initial release: DeepSeek account balance, remaining-ratio bar, and today's
  spend in the dsh sidebar footer.

[0.7.10]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.7.9...0.7.10
[0.7.9]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.7.8...0.7.9
[0.7.8]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.7.7...0.7.8
[0.7.7]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.7.6...0.7.7
[0.7.6]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.7.5...0.7.6
[0.7.5]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.7.4...0.7.5
[0.7.4]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.7.3...0.7.4
[0.7.3]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.7.2...0.7.3
[0.7.2]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.7.1...0.7.2
[0.7.1]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.7.0...0.7.1
[0.7.0]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.6.5...0.7.0
[0.6.5]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.6.4...0.6.5
[0.6.4]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.6.3...0.6.4
[0.6.3]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.6.2...0.6.3
[0.6.2]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.6.1...0.6.2
[0.6.1]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.6.0...0.6.1
[0.6.0]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.5.2...0.6.0
[0.5.2]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.5.1...0.5.2
[0.5.1]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.5.0...0.5.1
[0.5.0]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.4.1...0.5.0
[0.4.1]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.4.0...0.4.1
[0.4.0]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.3.5...0.4.0
[0.3.5]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.3.4...0.3.5
[0.3.4]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.3.3...0.3.4
[0.3.2]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.3.1...0.3.2
[0.3.1]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.3.0...0.3.1
[0.3.0]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.2.0...0.3.0
[0.2.0]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.1.2...0.2.0
[0.1.2]: https://github.com/alanzhao0128/dsh-balance-monitor/compare/0.1.0...0.1.2
[0.1.0]: https://github.com/alanzhao0128/dsh-balance-monitor/releases/tag/0.1.0
