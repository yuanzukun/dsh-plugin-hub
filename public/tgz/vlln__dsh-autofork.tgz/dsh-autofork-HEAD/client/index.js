/**
 * dsh-autofork browser half —— 分叉关系 UI + 焦点跟随。
 *
 * ## 为什么自己造 UI，而不复用 subagent 视图
 *
 * 最初的想法是把旧的 driver「归为 subagent」，直接复用官方 subagent 卡片。核实后
 * 发现这条路要被 subagent 的身份模型挡住：
 *
 *  - `history.ts` 要求被寻址的 subagent 满足 `header.origin === 'subagent' ∧
 *    header.parentSession === P`；
 *  - 而 session header 是**不可变**的。
 *
 * 于是"把一个既有 session 登记为另一 session 的 catalog 子项"在寻址路径上必被拒。
 * 但**目标不是复用那个视图**，而是"让用户在同一个视图容器里有一致的体验"。所以这里
 * 自造一个分叉关系 UI —— 也更贴合后续专门的 branch 关系 UI 方向。
 *
 * ## 它做什么
 *
 * 注册 `conversation.view` 里一个「分叉」页签（与「对话」「轨迹」并列），画本会话所在的
 * 分叉家族：每条会话一行（名字 / 状态 / 触发指令 / 分叉时刻），点一行跳到那条会话。
 *
 * 状态来自对 `/api/dsh-autofork/health` 的轮询（同一个轮询顺带完成焦点交付）。
 * 组件不依赖槽位 props（从本模块的 store 读），把契约风险压到最小。
 *
 * 本文档是**手写产物**：不需要构建步骤，`exports["./client"]` 直接指向它。
 * 契约由 `window.__ModuleLoader__.load({id, factory})` 定义——不调用它，
 * client-modules 会报 "loaded without registering"。
 */
window.__ModuleLoader__.load({
  id: '@vlln/dsh-autofork',
  factory: function (require) {
    var module = { exports: {} }
    var exports = module.exports

    /** Cordis 客户端插件名。 */
    exports.name = 'dsh-autofork-client'

    /**
     * 需要的客户端服务：
     *  · `sessions` —— 列表快照（`list`）、子会话地址（`subagentAddress`）、投影刷新
     *    （`refreshProjections`）与列表刷新（`refresh`）；
     *  · `uiWorkspace` —— **切换当前会话的唯一入口**（`openSession(target)`，见下）；
     *  · `slots` —— 注册「分叉」页签。
     *
     * `uiWorkspace` 必须声明：0.2.0 起 `sessions` 服务只负责"目录与引用"，会话选择属于
     * 视图所有者（`dsh-client-ui-workspace` 的 UiWorkspaceService），导航动作在
     * `openSession`。服务缺席时本插件做不到"把用户切到分叉上"，与其静默失效不如让
     * 严格注入规则把整个客户端条目拦住（web 组合里 ui-workspace 恒在）。
     */
    exports.inject = ['sessions', 'uiWorkspace', 'slots']

    var React = require('react')

    /**
     * 可选的同伴模块。**必须容错**：`require` 抛出会让整个 bundle 的工厂失败，浏览器报
     * "loaded without registering" —— 整条客户端插件（含「分叉」页签与焦点交付）一起消失。
     * 所以拿不到就降级，绝不因为一个可选控件让主体功能不可用。
     *
     * `react-dom` 在 0.2.0 的种子表里（`createPortal` 用它把「分叉」按钮挂进队列行）；
     * primitives 也在种子里，用它的图标与控件让观感与官方一致。
     */
    var reactDom = tryRequire('react-dom')
    var primitives = tryRequire('@deepseek-ai/dsh-client-ui-primitives') || {}

    /**
     * 取一个可选模块，拿不到返回 undefined。
     * @param {string} name 模块名。
     * @returns {any} 模块命名空间，或 undefined。
     */
    function tryRequire(name) {
      try {
        return require(name)
      } catch (error) {
        return undefined
      }
    }

    /** 本插件 Node half 的 health 路由。 */
    var HEALTH_PATH = '/api/dsh-autofork/health'

    /* ============================ 界面文案字典 ============================
     *
     * 客户端 UI 的**唯一**文案来源（官方 `verify-client-ui-i18n` 的同一条纪律：译文只住在
     * 字典里，展示代码只拿 `t(key, params)`；键一律点分小写、至少两段）。本 bundle 是手写
     * 单文件产物（无构建步骤、浏览器只加载这一个脚本），所以字典就地内联，而不是官方那种
     * `locales/` 目录。
     *
     * 注册走官方的 `ctx.locale.register(NS, {zh, en})`（见 apply）；`t` 由 `ctx.locale.bind(NS)`
     * 绑定，**每次调用现取当前语言**（官方实现保证返回的引用稳定且活跃），所以在语言切换后
     * 无需重挂载。`locale` 服务缺席时（非 web 组合）降级成"没有 locale 就用中文"——
     * 本插件的历史行为，界面不会变成一串键名。
     *
     * 参数用官方的 `{name}` 占位符（`Translate` 内置插值），拼句子一律整句入字典，
     * 不要在代码里拼词序（中英语序相反：`3 分钟前` vs `3 min ago`）。
     */
    var NS = 'autofork'

    var DICTS = {
      zh: {
        /* 页签 */
        'view.tab.branch': '分叉',
        'view.branch.title': '分叉家族',
        'view.branch.summary.sessions': '{count} 条会话',
        'view.branch.summary.running': '{count} 条在跑',
        'view.branch.loading': '正在读取分叉关系…',
        /* 状态与胶囊 */
        'state.running': '运行中',
        'state.idle': '空闲',
        'state.suffix.here': '（你在这里）',
        'state.suffix.driver': '（现在回答你的是它）',
        'chip.here': '你在这里',
        'chip.answeringYou': '在回答你',
        /* 相对时间 */
        'time.justNow': '刚刚',
        'time.minutesAgo': '{count} 分钟前',
        'time.hoursAgo': '{count} 小时前',
        'time.daysAgo': '{count} 天前',
        /* 树卡 */
        'card.badge.root': '根',
        'card.name.fallback': '会话 {id}',
        'card.trigger': '触发：{trigger}',
        'mute.switchLabel': '自动回注',
        /* 卡片详情纯文本（aria-label / 非 web 的原生 title） */
        'detail.session': '会话：',
        'detail.state': '状态：',
        'detail.trigger': '触发指令：',
        'detail.takeover': '接管：已接手原会话 {id}',
        'detail.mute': '自动回注：',
        'detail.mute.off': '关（它跑完不再自动把结果投给它派生出的会话）',
        'detail.mute.on': '开（它跑完会把最后一条结果自动投给它派生出的会话）',
        'detail.forkedAt': '分叉于：',
        'detail.familyRoot': '（家族根）',
        'detail.relativeWrap': '（{rel}）',
        /* 空值占位 */
        'placeholder.none': '—',
        'placeholder.noneFamilyRoot': '—（家族根）',
        /* hover 详情面板的行标签 */
        'panel.session': '会话',
        'panel.takeover': '接管',
        'panel.takeover.value': '已接手原会话 {id}',
        'panel.trigger': '触发指令',
        'panel.forkedAt': '分叉于',
        /* 接管 */
        'takeover.action': '接手原会话',
        'takeover.state.pending': '接管中…',
        'takeover.state.confirmed': '接管已确认',
        'takeover.state.active': '已接手原会话',
        'takeover.aria': '{label}：{name} 接手 {parentId}',
        'takeover.confirm.body': '确认由 B：{child}\n接手 A：{parent}？\n\nA 不会被中止，仍继续运行；之后的指令交给 B。\nA 的自动回传目标改为 B，仍受 A 的「自动回注」开关控制。\n这是接管原会话，不是切换自动回注开关。',
        'takeover.error.noConfirm': '当前环境无法显示确认，请在浏览器中重试',
        'takeover.error.receiptMismatch': '接管回执不匹配，请刷新确认状态',
        'takeover.error.failed': '{name} 接管失败：{error}',
        /* 手动分叉：队列行按钮 */
        'fork.button.idle': '分叉',
        'fork.button.busy': '分叉中…',
        'fork.button.failed': '分叉失败，可再点一次',
        'fork.button.aria': '分叉这条排队中的指令：{preview}',
        /* 消息卡 */
        'card.title.notice': '分叉通知',
        'card.title.digest': '在飞进度',
        'card.title.reply': '后台会话回复',
        'card.title.steer': '会话消息',
        'card.title.fallback': '消息',
        'card.awaitReply': '等待回复',
        'card.sender.inline': '来自 {id}',
        'card.sender.body': '来自会话 {id}',
        /* 通用 */
        'common.unknown': '未知',
        'common.sessionName': '会话（{id}）',
        'common.sessionLabel': '{name}（{id}）',
        /* 设置卡片（Plugins 页「分叉方式」） */
        'settings.title': '分叉方式',
        'settings.summary.unavailable': '设置不可用',
        'settings.summary.current': '当前：{mode}',
        'settings.unavailable.note': '读不到宿主提供的 dsh-autofork 配置项 —— 通常发生在插件于运行中被安装/卸载/更新之后（宿主半边仍是旧进程里的那一份）。重启 dsh 后这里恢复。',
        'settings.readonly': '只读',
        'settings.intro': 'agent 忙时，你的新指令是立刻换一条会话回答，还是先排队等你决定。',
        'settings.failed': '改动未被接受，已回读当前值。',
        'settings.mode.auto.label': '自动分叉',
        'settings.mode.auto.tagline': '触发即分叉',
        'settings.mode.auto.hint': '指令立刻在新会话里开始执行。',
        'settings.mode.manual.label': '手动分叉',
        'settings.mode.manual.tagline': '分不分由你点',
        'settings.mode.manual.hint': '指令先排队；在队列那一行点「分叉」才分叉。',
      },
      en: {
        /* Tab */
        'view.tab.branch': 'Forks',
        'view.branch.title': 'Fork family',
        'view.branch.summary.sessions': '{count} sessions',
        'view.branch.summary.running': '{count} running',
        'view.branch.loading': 'Loading fork relationships…',
        /* State and chips */
        'state.running': 'Running',
        'state.idle': 'Idle',
        'state.suffix.here': ' (you are here)',
        'state.suffix.driver': ' (this one is answering you)',
        'chip.here': 'You are here',
        'chip.answeringYou': 'Answering you',
        /* Relative time */
        'time.justNow': 'just now',
        'time.minutesAgo': '{count} min ago',
        'time.hoursAgo': '{count} h ago',
        'time.daysAgo': '{count} d ago',
        /* Family-tree card */
        'card.badge.root': 'root',
        'card.name.fallback': 'Session {id}',
        'card.trigger': 'Trigger: {trigger}',
        'mute.switchLabel': 'Auto-report',
        /* Card detail plain text (aria-label / native title outside web) */
        'detail.session': 'Session: ',
        'detail.state': 'State: ',
        'detail.trigger': 'Trigger: ',
        'detail.takeover': 'Takeover: took over {id}',
        'detail.mute': 'Auto-report: ',
        'detail.mute.off': 'off (its result is no longer sent to the sessions it created, once it finishes)',
        'detail.mute.on': 'on (its last result is sent to the sessions it created, once it finishes)',
        'detail.forkedAt': 'Forked at: ',
        'detail.familyRoot': '(family root)',
        'detail.relativeWrap': '({rel})',
        /* Empty-value placeholders */
        'placeholder.none': '—',
        'placeholder.noneFamilyRoot': '— (family root)',
        /* Hover detail panel row labels */
        'panel.session': 'Session',
        'panel.takeover': 'Takeover',
        'panel.takeover.value': 'Took over {id}',
        'panel.trigger': 'Trigger',
        'panel.forkedAt': 'Forked at',
        /* Takeover */
        'takeover.action': 'Take over',
        'takeover.state.pending': 'Taking over…',
        'takeover.state.confirmed': 'Takeover confirmed',
        'takeover.state.active': 'Took over',
        'takeover.aria': '{label}: {name} takes over {parentId}',
        'takeover.confirm.body': 'Confirm B: {child}\ntakes over A: {parent}?\n\nA is not stopped and keeps running; later instructions go to B.\nA reports back to B instead, still governed by A\'s "Auto-report" switch.\nThis takes over the original session; it does not toggle the auto-report switch.',
        'takeover.error.noConfirm': 'This environment cannot show a confirmation dialog; retry in a browser',
        'takeover.error.receiptMismatch': 'Takeover receipt did not match; refresh to confirm the state',
        'takeover.error.failed': '{name}: takeover failed: {error}',
        /* Manual fork: queue-row button */
        'fork.button.idle': 'Fork',
        'fork.button.busy': 'Forking…',
        'fork.button.failed': 'Fork failed; you can click again',
        'fork.button.aria': 'Fork this queued instruction: {preview}',
        /* Message cards */
        'card.title.notice': 'Fork notice',
        'card.title.digest': 'In-flight progress',
        'card.title.reply': 'Background session reply',
        'card.title.steer': 'Session message',
        'card.title.fallback': 'Message',
        'card.awaitReply': 'Awaiting reply',
        'card.sender.inline': 'from {id}',
        'card.sender.body': 'From session {id}',
        /* Shared */
        'common.unknown': 'unknown',
        'common.sessionName': 'Session ({id})',
        'common.sessionLabel': '{name} ({id})',
        /* Settings card (Plugins page "Fork mode") */
        'settings.title': 'Fork mode',
        'settings.summary.unavailable': 'Settings unavailable',
        'settings.summary.current': 'Current: {mode}',
        'settings.unavailable.note': 'Cannot read the dsh-autofork configuration provided by the host — usually because the plugin was installed, removed, or updated while running (the host half is still the copy from the old process). Restart dsh to recover.',
        'settings.readonly': 'Read-only',
        'settings.intro': 'When the agent is busy, should your new instruction be answered right away in another session, or queue up until you decide?',
        'settings.failed': 'The change was not accepted; the current value was re-read.',
        'settings.mode.auto.label': 'Autofork',
        'settings.mode.auto.tagline': 'Fork on trigger',
        'settings.mode.auto.hint': 'The instruction starts running in a new session right away.',
        'settings.mode.manual.label': 'Manual fork',
        'settings.mode.manual.tagline': 'You decide',
        'settings.mode.manual.hint': 'The instruction queues first; it forks only when you click "Fork" on the queue row.',
      },
    }

    /** 当前生效语言（回传给 Node half 用；`locale` 缺席时按中文）。 */
    var activeLang = 'zh'

    /**
     * 翻译：默认走内联中文（`locale` 服务缺席时的降级），`apply` 里换成官方的活跃绑定。
     * @param {string} key 字典键。
     * @param {object} [params] `{name}` 占位符的值。
     * @returns {string} 文案；键不存在时返回键本身（可见但不崩）。
     */
    var t = function (key, params) {
      var template = DICTS[activeLang]?.[key] ?? DICTS.zh[key] ?? key
      if (params === undefined) return template
      return template.replace(/\{(\w+)\}/g, function (match, name) {
        return Object.prototype.hasOwnProperty.call(params, name) ? String(params[name]) : match
      })
    }

    /**
     * 手动分叉的动作路由（Node half 注册）。**必须带 `FORK_HEADER`**：自定义头让跨站
     * 请求需要 CORS 预检，而服务端不回应预检 ⇒ 任何网页都无法对本地端口发起本动作
     * （无自定义头的"简单 JSON 请求"本来可以绕过同源策略）。
     */
    var FORK_PATH = '/api/dsh-autofork/fork'

    /** 会话级动作路由：改"要不要自动回注"（与 `FORK_PATH` 同形：POST + 自定义头）。 */
    var MUTE_PATH = '/api/dsh-autofork/mute'
    var TAKEOVER_PATH = '/api/dsh-autofork/takeover'

    // 按目标 id 保留动作状态；health 轮询和页签卸载都不能覆盖另一条请求。
    var takeoverRequests = new Map()
    function takeoverChanged() {
      publish(Object.assign({}, snapshot, { takeoverRevision: (snapshot.takeoverRevision || 0) + 1 }))
    }
    function sessionName(node, id) {
      var name = node && (node.label || node.title)
      return name ? t('common.sessionLabel', { name: name, id: id }) : t('common.sessionName', { id: id })
    }
    async function requestTakeover(sessionId) {
      var node = snapshot.nodes.find(function (item) { return item.sessionId === sessionId })
      var prior = takeoverRequests.get(sessionId)
      if (!node || node.kind !== 'fork' || node.canTakeover !== true || node.takeoverActive === true
        || prior?.pending || prior?.success) return
      var parent = snapshot.nodes.find(function (item) { return item.sessionId === node.parentId })
      var childName = sessionName(node, sessionId)
      var parentName = sessionName(parent, node.parentId)
      var message = t('takeover.confirm.body', { child: childName, parent: parentName })
      try {
        if (typeof window.confirm !== 'function') throw new Error(t('takeover.error.noConfirm'))
        if (window.confirm(message) !== true) return
        takeoverRequests.set(sessionId, { pending: true })
        takeoverChanged()
        var response = await fetch(TAKEOVER_PATH, {
          method: 'POST',
          headers: { 'content-type': 'application/json', [FORK_HEADER]: '1' },
          body: JSON.stringify({ sessionId: sessionId, confirmed: true }),
        })
        var body = await response.json()
        if (response.ok !== true || body?.ok !== true) throw new Error(body?.error || 'http-' + response.status)
        if (body.sessionId !== sessionId || body.parentId !== node.parentId) throw new Error(t('takeover.error.receiptMismatch'))
        takeoverRequests.set(sessionId, { success: true })
      } catch (error) {
        takeoverRequests.set(sessionId, { error: t('takeover.error.failed', { name: childName, error: String(error.message || error) }) })
      }
      takeoverChanged()
    }

    /** 动作路由要求的自定义请求头（与 Node half 的 `FORK_HEADER` 必须一字不差）。 */
    var FORK_HEADER = 'x-dsh-autofork'

    /** 设置命名空间 = Node half 的**条目 id**（`cordis.patch.yml` 的 `insert.id`），不是包名。 */
    var SETTINGS_NS = 'dsh-autofork'

    /** `plugins.bundle.config` 是 **keyed 槽**：key = bundle **包名**（与命名空间不同）。 */
    var BUNDLE_PKG = '@vlln/dsh-autofork'

    /** 队列行上「分叉」按钮的 DOM 属性（样式表也按它选）。 */
    var FORK_ATTR = 'data-dsh-autofork-fork'

    /**
     * 本插件卡片（分叉通知 / 在飞摘要 / 后台回传）的**节点 kind**。
     *
     * 为什么不直接用官方的 turn-trigger 卡片：官方判据是
     * `nextTurn.currentClaimed.has(id) || idleSteer`，而 `ReactLoopInbox.claim` 的粒度是
     * **next-turn 每轮只认领 1 条**。于是"两条卡 + 用户那条指令 + 只跑一次模型请求"在官方路径下
     * 不可能成立：卡片 = 本轮开场触发，一轮只能有一张，多一张就多一轮（= 多一次请求，用户实测报过）。
     * 通知与摘要走 next-step，与用户指令同批进入 inbox；本模块为未被官方触发卡接管的消息渲染卡片。
     */
    var CARD_KIND = 'autofork-message'

    /** 卡片根节点的 DOM 属性（样式按它选）。 */
    var CARD_ATTR = 'data-dsh-autofork-card'

    /**
     * 「分叉」页签根元素的 DOM 属性（样式表按它选，含"藏掉官方的宽度手柄"那条规则）。
     * 与 {@link CARD_ATTR} 同理：插件拿不到官方 CSS module 的哈希类名，只能锚稳定的 data 属性。
     */
    var VIEW_ATTR = 'data-dsh-autofork-view'

    /** 标记 → 卡片标题的**字典键**（`source.autofork`，宿主 half 与这里的标记必须一字不差）。
     * 键而不是文案：标题在渲染时经 `t()` 现取，所以切语言后台上的卡片标题跟着变。
     * 门禁 4 校验标记集合与这里的键一一对应，并检查每个键在两种语言里都有值。 */
    var CARD_TITLES = {
      notice: 'card.title.notice',
      digest: 'card.title.digest',
      reply: 'card.title.reply',
      // `steer`（跨会话消息，工具名 `fork_send`）：家族里**任意两条**都能互发，所以标题用中性的
      // 「会话消息」，不用"指令/控制"那套词（用户 2026-10：这条通道已经不是上游对下游的控制了）。
      steer: 'card.title.steer',
    }

    /** 回退条容器的 DOM 属性。 */
    var FORKBAR_ATTR = 'data-dsh-autofork-forkbar'

    /**
     * 把一句回报发回 Node half 的决策日志。
     *
     * 客户端 half 跑在浏览器里，没有这条通道时它的任何失败都是纯黑盒——这是本插件从第一版
     * 起就有的诊断面。定义在模块级（而不是 `apply` 内）是为了让子组件也能用。
     * @param {string} note 回报内容。
     * @returns {void}
     */
    function postNote(note) {
      try {
        fetch(HEALTH_PATH + '?client=1&note=' + encodeURIComponent(note), {
          headers: { accept: 'application/json' },
        }).catch(function () { /* 回报失败本身不必再报 */ })
      } catch (error) { /* fetch 不可用时静默：诊断面不得反过来弄坏主体 */ }
    }

    /**
     * 回传给 Node half 的界面语言（`lang` 查询参数）。Node half 的用户可见文案靠它选词：
     * 语言偏好只在浏览器侧最终确定（用户没显式选过时按浏览器语言），宿主读设置文档只能
     * 看到**显式选择**，所以"客户端在场就由客户端说了算"。
     * 轮询是常驻的（1s），所以这里只改一个变量，下一次 tick 自然带上。
     */
    var relayedLang = 'zh'

    /**
     * 语言切换时的重注册钩子（由「分叉」页签那段注册；null = 此刻没注册）。
     * 页签的 `label` 是官方在重算 tab 列表时调用的，而重算只在**槽变更**时发生
     * ⇒ 语言变了要主动重注册一次，否则页签标题会停在旧语言。
     * @type {null | (() => void)}
     */
    var onLocaleChanged = null

    /**
     * 记下界面语言；只有白名单（zh/en）改变它。
     * @param {string} lang `ctx.locale` 快照的 active。
     * @returns {void}
     */
    function relayLanguage(lang) {
      relayedLang = lang === 'en' ? 'en' : 'zh'
    }

    /**
     * 轮询间隔。
     *
     * 1000ms 而不是 2000ms：这条轮询同时承担**交付新 driver**（`handoff`）。用户发出消息后
     * 要"立刻"落到新会话上——2 秒的迟滞会让"打破同步交互"这个承诺打折扣（用户会先看到旧
     * 会话又转了一下）。请求很轻（一条 JSON），1 秒是延迟与代价的折中。
     */
    var POLL_MS = 1000

    /* ------------------------------ 模块级 store ------------------------------ */

    /** UI 快照；轮询写入，React 组件订阅。 */
    var snapshot = { current: undefined, nodes: [], driver: null, mode: 'auto', marks: {}, mark: '' }

    /** 订阅者集合（组件用）。 */
    var listeners = new Set()

    /**
     * 只在内容真变了才通知——否则每次轮询会让组件无谓重渲染。
     * @param {object} next 新快照。
     */
    function publish(next) {
      ;(next.nodes || []).forEach(function (node) {
        if (node.takeoverActive === true && takeoverRequests.get(node.sessionId)?.success) {
          takeoverRequests.delete(node.sessionId)
        }
      })
      var before = JSON.stringify(snapshot)
      var after = JSON.stringify(next)
      if (before === after) return
      snapshot = next
      listeners.forEach(function (fn) { fn() })
    }

    /**
     * @param {Function} fn 订阅回调。
     * @returns {Function} 退订。
     */
    function subscribe(fn) {
      listeners.add(fn)
      return function () { listeners.delete(fn) }
    }

    /** @returns {object} 当前快照。 */
    function getSnapshot() { return snapshot }

    /**
     * 本会话所在的**家族里有没有分叉关系**（= 要不要给「分叉」页签）。
     *
     * 判据就是快照里的家族节点数：服务端的 `familyNodes()` 给的是"本会话所在的那棵树"，
     * 一条既没分叉、也不是谁的分叉的孤立会话只有它自己（长度 1）——那时页签没有可讲的东西
     * （用户 2026-10："当 session 没有 fork 时，应该隐藏「分叉」页签"）。
     * 还没解析出当前会话时快照的 `nodes` 是空表（长度 0），同样按"没有"处理。
     *
     * @param {object} state store 快照。
     * @returns {boolean} 是否显示「分叉」页签。
     */
    function familyHasForks(state) {
      var nodes = state === undefined || state === null ? undefined : state.nodes
      return Array.isArray(nodes) && nodes.length > 1
    }

    /* ------------------------------ 展示辅助 ------------------------------ */

    /** session id 太长（session-<uuid>），只显示尾部 6 位。 */
    function shortId(id) {
      if (typeof id !== 'string') return '?'
      return id.length <= 6 ? id : id.slice(-6)
    }

    /**
     * 主题令牌。用原生变量才能跟随明暗主题（`--dsw-alias-*` 是会话视图自己在用的那一套）；
     * 变量取不到时退回后面的中性值，绝不因为主题令牌改名就渲染出透明文字。
     */
    var TOKEN = {
      labelPrimary: 'var(--dsw-alias-label-primary, #1a1a1a)',
      labelSecondary: 'var(--dsw-alias-label-secondary, #4d4d4d)',
      labelTertiary: 'var(--dsw-alias-label-tertiary, #808080)',
      caption: 'var(--dsw-alias-label-caption, #9a9a9a)',
      hover: 'var(--dsw-alias-interactive-bg-hover, rgba(127, 127, 127, 0.10))',
      accent: 'var(--dsw-alias-state-business-primary, #0b6bcb)',
    }

    /**
     * 头部与说明文字的宽度约束：**仍然与「对话」转写同宽居中**（一行行的文字铺满整个内容区
     * 会看着散）。**树画布不走这条**——用户 2026-10 要求"画布宽度放宽，最好是无边界画布"，
     * 树按家族实际尺寸铺开，超出可用宽就横向滚动。
     */
    var COLUMN_STYLE = {
      width: '100%',
      maxWidth: 'var(--dsh-chat-content-width, 760px)',
      margin: '0 auto',
    }

    /** 空态/加载态的说明文字样式。 */
    var HINT_STYLE = {
      color: TOKEN.labelTertiary,
      fontSize: '12px',
      lineHeight: '20px',
      maxWidth: '560px',
    }

    /**
     * 状态 → 文案 / 颜色 / 底色。**三态互斥**，与服务端的 `state` 一一对应。
     *
     * 三态是"agent 此刻在干什么"这一个事实的三种取值；曾经服务端并排给过"agent 还在不在"
     * 与"忙不忙"两个字段，于是"活着但空闲"的会话同时显示成运行中与已停（用户实测报的
     * 自相矛盾）。这里把它压成一个标签，颜色只用一种语义。
     */
    var STATE_META = {
      // 文案是**键**（渲染时经 `t()` 现取，切语言即时生效）；颜色与底色与语言无关。
      running: { text: 'state.running', color: TOKEN.accent, tint: 'rgba(11, 107, 203, 0.12)' },
      idle: { text: 'state.idle', color: TOKEN.labelSecondary, tint: 'rgba(127, 127, 127, 0.14)' },
      // 没有 finished：它不该被渲染（`showState` 只在 live 时为真）。
    }

    /**
     * 相对时间（页签要回答"这次分叉是多久之前发生的"，而 `1789149220103` 对人没有意义）。
     *
     * 只做**粗粒度**：它是渲染时算的，每 30 秒重渲染一次，粒度细了会看到数字乱跳。
     * @param {number} at epoch ms。
     * @param {number} now 当前时刻。
     * @returns {string} `刚刚` / `N 分钟前` / `N 小时前` / `N 天前`；没有时刻则空串。
     */
    function relTime(at, now) {
      if (typeof at !== 'number' || at <= 0) return ''
      var diff = Math.max(0, now - at)
      var minutes = Math.floor(diff / 60000)
      if (minutes < 1) return t('time.justNow')
      if (minutes < 60) return t('time.minutesAgo', { count: minutes })
      var hours = Math.floor(minutes / 60)
      if (hours < 24) return t('time.hoursAgo', { count: hours })
      return t('time.daysAgo', { count: Math.floor(hours / 24) })
    }

    /**
     * 绝对时刻 `HH:MM` —— 放进悬停提示里，需要精确时可读。
     * @param {number} at epoch ms。
     * @returns {string} 时刻文本；没有则空串。
     */
    function clockOf(at) {
      if (typeof at !== 'number' || at <= 0) return ''
      var date = new Date(at)
      var hh = String(date.getHours())
      var mm = String(date.getMinutes())
      return (hh.length < 2 ? '0' + hh : hh) + ':' + (mm.length < 2 ? '0' + mm : mm)
    }

    /**
     * 一枚小胶囊（状态 / `你在这里` / `现在回答你的是它`）。
     * @param {string} key React key。
     * @param {string} text 文案。
     * @param {string} color 文字与底色都用它派生（底色是同色低透明度，不硬编码主题色）。
     * @param {string} tint 底色。
     * @returns {object} React 元素。
     */
    function chip(key, text, color, tint) {
      return React.createElement('span', {
        key: key,
        style: {
          flex: 'none',
          padding: '2px 8px',
          borderRadius: '999px',
          background: tint,
          color: color,
          fontSize: '12px',
          lineHeight: '18px',
          whiteSpace: 'nowrap',
        },
      }, text)
    }

    /* ------------------------------ 「分叉」页签的树状图 ------------------------------ */

    /**
     * 树状图的度量。**布局与卡片共用这一份**——两处各写一份，连线端点就会飘。
     */
    var TREE = {
      cardW: 216,
      cardH: 104,
      gapX: 16,
      /** 层高 = 卡高 + 连线通道：父卡底边到子卡顶边留出 S 曲线的余地（同 dsh-context 的 `LEVEL_H`）。 */
      levelH: 148,
      padX: 6,
      padY: 4,
    }

    /**
     * 把服务端的**平铺节点表**折成一棵可画的树（整洁树布局 / tidy tree）。
     *
     * ⚠️ 服务端给的是 **BFS 顺序**（根 → 它的孩子们 → 再下一层），所以这里**不能**把数组
     * 顺序当 DFS 用，必须自己按 `parentId` 重建父子关系——否则兄弟顺序看起来对、层级却错。
     *
     * 布局规则照 `dsh-context` 的 subagent 树：**叶子按顺序各占一个槽，父节点居中于它的
     * 孩子们**。于是同层任意两张卡的水平距离 ≥ 一个槽距（不会叠），而"谁从谁分出来"一眼
     * 看得出——这正是把层次列表换成树状图要买到的东西。
     *
     * 认不出父的节点（父不在表里、或自指）一律当根画出来：宁可多一个根，也不能"数据在
     * 表里却不显示"。
     * @param {Array<any>} nodes 服务端 `familyNodes()` 的平铺节点（BFS 序）。
     * @returns {{width: number, height: number, points: Array<any>, links: Array<any>}} 画布尺寸、节点坐标、连线。
     */
    function layoutFamily(nodes) {
      var byId = new Map()
      var index = 0
      for (index = 0; index < nodes.length; index += 1) byId.set(nodes[index].sessionId, nodes[index])

      var childrenOf = new Map()
      var roots = []
      for (index = 0; index < nodes.length; index += 1) {
        var node = nodes[index]
        var parent = node.parentId
        if (parent !== null && parent !== undefined && parent !== node.sessionId && byId.has(parent)) {
          var kids = childrenOf.get(parent)
          if (kids === undefined) childrenOf.set(parent, [node])
          else kids.push(node)
        } else {
          roots.push(node)
        }
      }

      var slotOf = new Map()
      var depthOf = new Map()
      var visited = new Set()
      var leaves = 0
      var place = function (item, depth) {
        visited.add(item.sessionId)
        depthOf.set(item.sessionId, depth)
        var children = (childrenOf.get(item.sessionId) || []).filter(function (child) {
          return !visited.has(child.sessionId)
        })
        var slot = -1
        if (children.length === 0) {
          slot = leaves
          leaves += 1
        } else {
          var first = -1
          var last = -1
          for (var k = 0; k < children.length; k += 1) {
            var placed = place(children[k], depth + 1)
            if (placed < 0) continue
            if (first < 0) first = placed
            last = placed
          }
          if (first < 0) { slot = leaves; leaves += 1 } else { slot = (first + last) / 2 }
        }
        slotOf.set(item.sessionId, slot)
        return slot
      }
      // 先画根们，再兜一圈处理"谁都认不出的孤点"，保证每个节点都有槽位。
      for (index = 0; index < roots.length; index += 1) {
        if (!visited.has(roots[index].sessionId)) place(roots[index], 0)
      }
      for (index = 0; index < nodes.length; index += 1) {
        if (!visited.has(nodes[index].sessionId)) place(nodes[index], 0)
      }

      var pitch = TREE.cardW + TREE.gapX
      var points = []
      var pointById = new Map()
      var maxDepth = 0
      for (index = 0; index < nodes.length; index += 1) {
        var current = nodes[index]
        if (!slotOf.has(current.sessionId)) continue
        var depth = depthOf.get(current.sessionId) || 0
        if (depth > maxDepth) maxDepth = depth
        var point = {
          node: current,
          depth: depth,
          x: TREE.padX + slotOf.get(current.sessionId) * pitch,
          y: TREE.padY + depth * TREE.levelH,
        }
        points.push(point)
        pointById.set(current.sessionId, point)
      }

      var links = []
      for (index = 0; index < points.length; index += 1) {
        var child = points[index]
        var parentId = child.node.parentId
        var from = parentId === null || parentId === undefined ? undefined : pointById.get(parentId)
        if (from === undefined) continue
        links.push({
          to: child.node.sessionId,
          running: child.node.state === 'running',
          x1: from.x + TREE.cardW / 2,
          y1: from.y + TREE.cardH,
          x2: child.x + TREE.cardW / 2,
          y2: child.y,
        })
      }

      return {
        width: Math.max(1, leaves) * pitch - TREE.gapX + TREE.padX * 2,
        height: maxDepth * TREE.levelH + TREE.cardH + TREE.padY * 2,
        points: points,
        links: links,
      }
    }

    /**
     * 连线的 S 曲线：两端**垂直**切入卡片边（父卡底边 → 子卡顶边），曲率随落差增长并夹在
     * [24, 96]（同 `dsh-context` 的 `linkPath`）。多层树里斜直线会读成"斜穿"，切线才对得上。
     * @param {number} x1 父卡底边中点 x。
     * @param {number} y1 父卡底边 y。
     * @param {number} x2 子卡顶边中点 x。
     * @param {number} y2 子卡顶边 y。
     * @returns {string} SVG path 的 `d`。
     */
    function linkPath(x1, y1, x2, y2) {
      var k = Math.min(96, Math.max(24, (y2 - y1) * 0.5))
      return 'M ' + String(x1) + ' ' + String(y1)
        + ' C ' + String(x1) + ' ' + String(y1 + k)
        + ', ' + String(x2) + ' ' + String(y2 - k)
        + ', ' + String(x2) + ' ' + String(y2)
    }

    /**
     * 悬停一张卡时要点亮的**血统**：它的祖先链 + 它自己的整棵子树（其余淡出）。
     *
     * 这是树状图相对层次列表真正多出来的可读性——一眼看清"它从谁分出来"与"谁又是它的后代"。
     * @param {Array<any>} nodes 平铺节点。
     * @param {string|null} id 悬停的会话 id。
     * @returns {Set<string>} 要点亮的会话 id。
     */
    function lineageOf(nodes, id) {
      var byId = new Map()
      var index = 0
      for (index = 0; index < nodes.length; index += 1) byId.set(nodes[index].sessionId, nodes[index])
      var lit = new Set()
      var cursor = byId.get(id)
      while (cursor !== undefined && !lit.has(cursor.sessionId)) {
        lit.add(cursor.sessionId)
        cursor = cursor.parentId === null || cursor.parentId === undefined
          ? undefined
          : byId.get(cursor.parentId)
      }
      var queue = [id]
      for (index = 0; index < queue.length; index += 1) {
        for (var j = 0; j < nodes.length; j += 1) {
          var child = nodes[j]
          if (child.parentId === queue[index] && !lit.has(child.sessionId)) {
            lit.add(child.sessionId)
            queue.push(child.sessionId)
          }
        }
      }
      return lit
    }

    /**
     * 一张卡的**事实**：卡片本体、`aria-label` 与 hover 面板**共用这一份派生**。
     *
     * 抽出来的理由：名字/状态/触发指令/时间以前在卡片与 tooltip 里各算一遍，两处口径容易漂；
     * 现在派生一次，三种呈现（卡上版式 / 纯文本 / 面板版式）都从它读。
     * @param {any} node 服务端节点。
     * @param {any} driver 当前回答用户的会话。
     * @param {number} now 渲染时刻（相对时间用）。
     * @returns {any} 派生事实。
     */
    function cardFacts(node, driver, now) {
      var isRoot = node.kind === 'root' || (node.kind === undefined && (node.parentId === null || node.parentId === undefined))
      // 名字优先用服务端给的 `label`（**已经去掉** `<标记><序号> ` 前缀，因为徽章就是它），
      // 退回完整 `title`，再退回会话短 id。
      var label = typeof node.label === 'string' && node.label !== ''
        ? node.label
        : (typeof node.title === 'string' && node.title !== ''
          ? node.title
          : t('card.name.fallback', { id: shortId(node.sessionId) }))
      var ordinal = typeof node.ordinal === 'number' && node.ordinal > 0 ? node.ordinal : 0
      return {
        isRoot: isRoot,
        isCurrent: node.current === true,
        isDriver: driver !== null && driver !== undefined && driver.sessionId === node.sessionId,
        /**
         * **有没有"实时状态"可报**——只有活着（`running`/`idle`）才有。
         *
         * ⚠️ 用户 2026-10："不需要有任何区分'未运行'，因为这对于用户是无意义的信息"。
         * 所以"不在本进程"这件事**不呈现**：不挂胶囊、**也不给卡片降级观感**（那等于把一条实现
         * 细节画成了状态）。它只作为内部判据存在（宿主 `stateOf`），对外一视同仁。
         */
        live: node.state === 'running' || node.state === 'idle',
        meta: STATE_META[node.state] === undefined
          ? { text: String(node.state), color: TOKEN.labelTertiary, tint: 'transparent', raw: true }
          : STATE_META[node.state],
        label: label,
        badge: node.kind === 'fork' ? '⑂' : (isRoot ? t('card.badge.root') : '⑂' + String(ordinal)),
        takeoverActive: node.takeoverActive === true,
        trigger: typeof node.trigger === 'string' ? node.trigger : '',
        /** **这条会话自己**的自动回注开关（宿主按会话下发；见 `sessionMuted`）。 */
        muted: node.muted === true,
        rel: relTime(node.at, now),
        clock: clockOf(node.at),
      }
    }

    /**
     * 状态那一格的完整说法（含"你在这里 / 现在回答你的是它"），卡片、aria、面板共用。
     * @param {any} facts {@link cardFacts} 的返回值。
     * @returns {string} 例如 `空闲（你在这里）`。
     */
    function stateLine(facts) {
      // `meta.text` 来自 STATE_META 时是**字典键**；未知状态那条是服务端原样值（`raw`），不翻译。
      var state = facts.meta.raw === true ? facts.meta.text : t(facts.meta.text)
      return state
        + (facts.isCurrent ? t('state.suffix.here') : (facts.isDriver ? t('state.suffix.driver') : ''))
    }

    /**
     * 卡片的**纯文本**详情（`aria-label` 用；非 web 组合下也直接当原生 tooltip）。
     * @param {any} node 服务端节点。
     * @param {any} facts {@link cardFacts} 的返回值。
     * @returns {string} 多行纯文本。
     */
    function detailText(node, facts) {
      var none = t('placeholder.none')
      return [
        facts.badge + '　' + facts.label,
        t('detail.session') + node.sessionId,
        // 只有"活着"才报状态；不在本进程时**整行不出现**（不是写成"未运行"——那是噪声）。
        ...(facts.live === true ? [t('detail.state') + stateLine(facts)] : []),
        t('detail.trigger') + (facts.trigger === ''
          ? none + (facts.isRoot ? t('detail.familyRoot') : '')
          : facts.trigger),
        ...(facts.takeoverActive ? [t('detail.takeover', { id: node.parentId })] : []),
        t('detail.mute') + (facts.muted ? t('detail.mute.off') : t('detail.mute.on')),
        t('detail.forkedAt') + (node.at === null || node.at === undefined
          ? none
          : (facts.clock === '' ? '' : facts.clock)
            + (facts.rel === '' ? '' : t('detail.relativeWrap', { rel: facts.rel }))),
      ].join('\n')
    }

    /** hover 面板的度量与落点参数（宽固定、高按内容有界，定位时用它夹在视口内）。 */
    var HOVER = { width: 340, gap: 12, pad: 8, estH: 200 }

    /**
     * 面板里的一行「标签 + 值」。**层次就来自这条对齐**——标签列定宽、值列吃满，
     * 而不是把 `会话：xxx` 这种整串堆在一行里（用户 2026-10 报的"信息都堆在一起"）。
     * @param {string} label 标签（会话 / 触发指令 / 分叉于…）。
     * @param {string} value 值。
     * @param {{quote?: boolean}} [options] `quote` 时值是**引用块**（左侧一条强调竖线）。
     * @returns {any} React 元素。
     */
    function detailRow(label, value, options) {
      var opts = options === undefined ? {} : options
      return React.createElement('div', {
        key: label,
        style: { display: 'flex', alignItems: 'flex-start', gap: '10px', minWidth: '0' },
      }, [
        React.createElement('span', {
          key: 'k',
          style: {
            flex: 'none',
            width: '56px',
            fontSize: '11.5px',
            lineHeight: '18px',
            color: TOKEN.labelTertiary,
          },
        }, label),
        React.createElement('span', {
          key: 'v',
          style: opts.quote === true
            ? {
              flex: '1 1 auto',
              minWidth: '0',
              fontSize: '12px',
              lineHeight: '18px',
              color: TOKEN.labelSecondary,
              overflowWrap: 'anywhere',
              // 引用块：左侧一条强调竖线 + 缩进，一眼看出"这是别人说的那句指令"。
              borderLeft: '2px solid ' + TOKEN.accent,
              paddingLeft: '8px',
            }
            : {
              flex: '1 1 auto',
              minWidth: '0',
              fontSize: '12px',
              lineHeight: '18px',
              color: TOKEN.labelPrimary,
              overflowWrap: 'anywhere',
            },
        }, value),
      ])
    }

    /**
     * 面板落点：默认贴在卡的**右侧**，右边放不下就翻到**左侧**；纵向夹在视口内。
     *
     * 用卡片的 `getBoundingClientRect()` 现测，而面板挂 `position: fixed`（经 portal 到 body）——
     * 于是既不被画布的滚动容器裁掉，也不受横向滚动影响。
     * @param {any} rect 卡片的视口矩形。
     * @returns {{left: number, top: number}} 面板的 fixed 落点。
     */
    function hoverPlacement(rect) {
      /* v8 ignore next 1 -- 只在浏览器里被调用（stub 没有 hover） */
      var viewW = typeof window === 'undefined' ? 1440 : window.innerWidth
      /* v8 ignore next 1 -- 同上 */
      var viewH = typeof window === 'undefined' ? 900 : window.innerHeight
      var left = rect.right + HOVER.gap
      if (left + HOVER.width + HOVER.pad > viewW) {
        left = Math.max(HOVER.pad, rect.left - HOVER.gap - HOVER.width)
      }
      var top = rect.top
      if (top + HOVER.estH + HOVER.pad > viewH) top = Math.max(HOVER.pad, viewH - HOVER.estH - HOVER.pad)
      return { left: left, top: top }
    }

    /**
     * hover 详情**面板**：分三层呈现，替代原来"一段无格式文本"的原生 tooltip
     * （用户 2026-10："hover 出现的信息没有层次，所有信息都堆在了一起"）：
     *
     * ① **标题行**：徽章 + 名字 + 状态胶囊（一眼是"哪条会话、什么状态"）；
     * ② **键值行**：会话 id / 触发指令（引用块）/ 分叉时刻（绝对 · 相对）；标签列定宽对齐。
     *    只放**卡上放不下的详情**——卡上已有的（状态胶囊、"你在这里"、"在回答你"）不再重复。
     * @param {any} props 渲染输入。
     * @returns {any} React 元素。
     */
    function HoverDetail(props) {
      var node = props.node
      var facts = cardFacts(node, props.driver, props.now)
      return React.createElement('div', {
        'data-dsh-autofork-hover': '',
        style: {
          position: 'fixed',
          left: String(props.place.left) + 'px',
          top: String(props.place.top) + 'px',
          width: String(HOVER.width) + 'px',
          boxSizing: 'border-box',
          padding: '10px 12px',
          display: 'flex',
          flexDirection: 'column',
          gap: '8px',
          // 浮层**不吃指针**：它只负责"看"，鼠标仍然归卡片（否则移进面板它就消失了）。
          pointerEvents: 'none',
          zIndex: '80',
          background: 'var(--dsw-alias-bg-layer-2, rgba(30, 30, 30, 0.97))',
          border: '1px solid var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.35))',
          borderRadius: '12px',
          boxShadow: '0 8px 24px rgba(0, 0, 0, 0.22)',
          color: TOKEN.labelPrimary,
        },
      }, [
        React.createElement('div', {
          key: 'head',
          style: { display: 'flex', alignItems: 'center', gap: '8px', minWidth: '0' },
        }, [
          React.createElement('span', {
            key: 'badge',
            style: {
              flex: 'none',
              padding: '0 6px',
              height: '20px',
              display: 'flex',
              alignItems: 'center',
              borderRadius: '5px',
              background: facts.isRoot ? 'rgba(127, 127, 127, 0.14)' : 'rgba(11, 107, 203, 0.14)',
              color: facts.isRoot ? TOKEN.labelSecondary : TOKEN.accent,
              fontSize: '12px',
              fontWeight: '600',
            },
          }, facts.badge),
          React.createElement('span', {
            key: 'label',
            style: {
              flex: '1 1 auto',
              minWidth: '0',
              fontSize: '13px',
              fontWeight: '600',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            },
          }, facts.label),
          facts.live ? chip('state', facts.meta.raw === true ? facts.meta.text : t(facts.meta.text), facts.meta.color, facts.meta.tint) : null,
        ]),
        React.createElement('div', {
          key: 'sep',
          style: { height: '1px', background: 'var(--dsw-alias-border-l1, rgba(127, 127, 127, 0.22))' },
        }),
        React.createElement('div', {
          key: 'rows',
          style: { display: 'flex', flexDirection: 'column', gap: '6px', minWidth: '0' },
        }, [
          detailRow(t('panel.session'), node.sessionId),
          facts.takeoverActive ? detailRow(t('panel.takeover'), t('panel.takeover.value', { id: node.parentId })) : null,
          detailRow(t('panel.trigger'), facts.trigger === ''
            ? (facts.isRoot ? t('placeholder.noneFamilyRoot') : t('placeholder.none'))
            : facts.trigger, {
            quote: facts.trigger !== '',
          }),
          detailRow(t('panel.forkedAt'), node.at === null || node.at === undefined
            ? t('placeholder.none')
            : (facts.clock + (facts.rel === '' ? '' : ' · ' + facts.rel))),
          // `位置` 那行**已删**（用户 2026-10：卡片上已经写了「你在这里」/「在回答你」两枚胶囊，
          // 详情里再说一遍是重复）。注意 `aria-label` 里的 `（你在这里）` **保留**——屏幕阅读器
          // 只念 aria-label、不念卡内芯片，删掉就真的丢了。
        ]),
        // 页脚那行动作提示**已删**（用户 2026-10）：`点击切过去` 是操作提示、不是这一层的详情，
        // 而当前卡那半句 `当前会话` 又与键值行里的 `位置：你在这里` 重复。可点性由指针形状与
        // 悬停抬升表达，不需要再用文字说一遍。
      ])
    }

    /**
     * 卡片**正文**的呈现文本：剥掉插件自己写进模型正文的那段已知前缀。
     *
     * 前缀形状由宿主 half 的 `senderPrefixed()` 决定（`分叉会话 <id> 发来消息（它在等你回复）：`），
     * 而卡片**已经**在标题行写了发送方与「等待回复」胶囊 ⇒ 正文里再来一遍是重复（用户 2026-10）。
     *
     * 只按宿主给出的有效偏移切片，不猜测前缀语法；缺失或越界时原样显示。
     * @param {string} text 模型可见正文。
     * @returns {string} 呈现用正文。
     */
    function cardBody(text, offset, body) {
      // **正文优先用宿主单独给的 `body`**：宿主的前缀文案是**可翻译的**（跟界面语言走），
      // 所以"前缀长度"这个偏移量在语言切换后会变——拿它切正文会切错（静默改变卡片内容）。
      // `bodyOffset` 只作为**旧消息**的兼容路径保留（升级前写下的那些 `source` 里只有偏移量），
      // 那种消息带着前缀显示是历史痕迹，不做模糊猜测。
      if (typeof body === 'string' && body !== '') return body
      return typeof offset === 'number' && offset > 0 && offset < text.length ? text.slice(offset) : text
    }

    /**
     * 树状图上的一张节点卡。
     *
     * 一张卡回答三件事（与列表版一致，只是换了载体）：**这是哪条会话**（徽章 + 名字）、
     * **它此刻在干什么**（只有活着才挂状态胶囊；"不在本进程"**不呈现**）、**为什么分叉、多久之前**
     * （触发指令 + 右侧相对时间）。
     *
     * **hover 契约**：整张卡只有**一个** tooltip（挂在卡根上），内容是完整会话 id、状态、
     * 触发指令全文、分叉时刻（绝对 + 相对）与动作提示；卡内任何元素都不再自带 title——
     * 否则鼠标在卡内移动会看到信息跳变（用户 2026-10 报的"不同位置 hover 有不同信息"）。
     */
    function FamilyNodeCard(props) {
      var node = props.node
      var driver = props.driver
      var now = props.now
      var facts = cardFacts(node, driver, now)
      var toggle = function (value) {
        if (typeof props.onToggleMute === 'function') props.onToggleMute(node.sessionId, value)
      }
      var isCurrent = facts.isCurrent
      var isDriver = facts.isDriver
      var isRoot = facts.isRoot
      var hover = props.hovered === true
      var meta = facts.meta
      var label = facts.label
      var trigger = facts.trigger
      var rel = facts.rel
      var showState = facts.live === true
      var takeover = takeoverRequests.get(node.sessionId) || {}
      var takeoverControl = node.kind === 'fork' && (node.canTakeover === true || facts.takeoverActive || takeover.success || takeover.pending)
      var takeoverLabel = facts.takeoverActive ? t('takeover.state.active')
        : (takeover.success ? t('takeover.state.confirmed')
          : (takeover.pending ? t('takeover.state.pending') : t('takeover.action')))

      var navigate = function () { if (!isCurrent) navTo(node.sessionId) }
      return React.createElement('div', {
        role: 'button',
        tabIndex: 0,
        // 稳定的 DOM 锚：渲染自证按它认卡，浏览器里排障（或 CDP 检查）也按它查。
        'data-session-id': node.sessionId,
        'aria-current': isCurrent ? 'true' : undefined,
        // **整张卡一个详情**（用户 2026-10 要求）：卡内任何元素都不再自带 info，鼠标在卡内
        // 移动不会换信息。有 `react-dom` 时详情是**分层面板**（`HoverDetail`，见上），
        // 所以这里只留 `aria-label`（纯文本，屏幕阅读器用）；没有 react-dom 的组合退回
        // 原生多行 `title`，保证非 web 场景也有详情可看。
        'aria-label': detailText(node, facts),
        title: reactDom === undefined ? detailText(node, facts) : undefined,
        onClick: navigate,
        onKeyDown: function (event) {
          if (event.target !== event.currentTarget) return
          if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault()
            navigate()
          }
        },
        onMouseEnter: function (event) { props.onHover(node.sessionId, event.currentTarget) },
        onMouseLeave: function () { props.onHover(null) },
        // 键盘走查也出同一张面板（`title` 在焦点上本来就不显示，这里顺手补上）。
        onFocus: function (event) { props.onHover(node.sessionId, event.currentTarget) },
        onBlur: function () { props.onHover(null) },
        style: {
          position: 'absolute',
          left: String(props.point.x) + 'px',
          top: String(props.point.y) + 'px',
          width: String(TREE.cardW) + 'px',
          height: String(TREE.cardH) + 'px',
          boxSizing: 'border-box',
          padding: '10px 12px',
          display: 'flex',
          flexDirection: 'column',
          gap: '5px',
          overflow: 'hidden',
          borderRadius: '12px',
          background: isCurrent
            ? TOKEN.hover
            : 'var(--dsw-alias-bg-layer-2, rgba(127, 127, 127, 0.04))',
          border: '1px solid ' + (isCurrent
            ? TOKEN.accent
            : 'var(--dsw-alias-border-l1, rgba(127, 127, 127, 0.22))'),
          // 悬停抬升 + 阴影；当前那条不动（它就在你眼前，不需要再"抬"）。
          boxShadow: hover && !isCurrent ? '0 2px 10px rgba(127, 127, 127, 0.24)' : 'none',
          transform: hover && !isCurrent ? 'translateY(-1px)' : 'none',
          cursor: isCurrent ? 'default' : 'pointer',
          // 血统聚焦：与悬停那张卡无关的卡淡出（与连线的淡出同一套）。
          opacity: props.dimmed === true ? 0.42 : 1,
          transition: 'opacity 120ms ease, box-shadow 120ms ease, transform 120ms ease',
          color: isCurrent ? TOKEN.labelPrimary : TOKEN.labelSecondary,
        },
      }, [
        React.createElement('div', {
          key: 'top',
          style: { display: 'flex', alignItems: 'flex-start', gap: '6px', minWidth: '0' },
        }, [
          React.createElement('span', {
            key: 'badge',
            style: {
              flex: 'none',
              marginTop: '2px',
              width: '32px',
              height: '21px',
              borderRadius: '5px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              background: isRoot ? 'rgba(127, 127, 127, 0.12)' : 'rgba(11, 107, 203, 0.12)',
              color: isRoot ? TOKEN.labelSecondary : TOKEN.accent,
              fontSize: '12px',
              fontWeight: '600',
            },
          }, facts.badge),
          React.createElement('div', {
            key: 'label',
            style: {
              flex: '1 1 auto',
              minWidth: '0',
              fontSize: '13px',
              lineHeight: '16px',
              fontWeight: isCurrent ? '600' : '400',
              color: TOKEN.labelPrimary,
              // 两行封顶：卡高固定，标题换行不该把下面的状态行挤出卡片。
              display: '-webkit-box',
              WebkitBoxOrient: 'vertical',
              WebkitLineClamp: '2',
              overflow: 'hidden',
              overflowWrap: 'anywhere',
            },
          }, label),
          // **这条会话自己的「自动回注」开关**（0.9.0 起按会话独立）。
          //
          // 形态：19×11 的**迷你开关**（轨道 + 圆钮），不是文字药丸 —— 原先写成「回注开」的
          // 药丸，与状态胶囊、「你在这里」挤在同一行，一排三个 pill（用户 2026-10："太丑了"）。
          // 开关放在**卡片右上角**：它是一条 per-card 的控制，不是状态；含义写在整卡详情里
          // （统一 hover 契约：卡内元素都不自带 title），`aria-label` + `aria-checked` 供读屏。
          React.createElement('span', {
            key: 'mute',
            role: 'switch',
            tabIndex: 0,
            'data-mute-toggle': node.sessionId,
            'aria-checked': facts.muted ? 'false' : 'true',
            'aria-label': t('mute.switchLabel'),
            onClick: function (event) {
              if (event !== undefined && typeof event.stopPropagation === 'function') event.stopPropagation()
              toggle(!facts.muted)
            },
            onKeyDown: function (event) {
              if (event.key !== 'Enter' && event.key !== ' ') return
              event.preventDefault()
              if (typeof event.stopPropagation === 'function') event.stopPropagation()
              toggle(!facts.muted)
            },
            style: {
              flex: 'none',
              position: 'relative',
              width: '19px',
              height: '11px',
              marginTop: '5px',
              borderRadius: '999px',
              cursor: 'pointer',
              transition: 'background 120ms ease',
              background: facts.muted
                ? 'var(--dsw-alias-interactive-bg-hover, rgba(127, 127, 127, 0.22))'
                : TOKEN.accent,
            },
          }, React.createElement('span', {
            key: 'knob',
            // 稳定锚：测试/排障按它认圆钮（状态从**位置**读，见上面的注释）。
            'data-mute-knob': '1',
            style: {
              position: 'absolute',
              top: '1.5px',
              left: facts.muted ? '1.5px' : '9.5px',
              width: '8px',
              height: '8px',
              borderRadius: '999px',
              background: '#fff',
              transition: 'left 120ms ease',
              boxShadow: '0 0 0 0.5px rgba(0, 0, 0, 0.08)',
            },
          })),
        ]),
        // 第二行：触发指令（可能是"这次分叉为什么发生"的唯一线索）+ 右对齐的相对时间。
        (trigger !== '' || rel !== '') ? React.createElement('div', {
          key: 'meta',
          style: { display: 'flex', alignItems: 'baseline', gap: '6px', minWidth: '0' },
        }, [
          React.createElement('span', {
            key: 'trigger',
            style: {
              flex: '1 1 auto',
              minWidth: '0',
              fontSize: '11.5px',
              lineHeight: '15px',
              color: TOKEN.labelTertiary,
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            },
          }, trigger === '' ? '' : t('card.trigger', { trigger: trigger })),
          React.createElement('span', {
            key: 'at',
            style: { flex: 'none', fontSize: '11.5px', lineHeight: '15px', color: TOKEN.caption },
          }, rel),
        ]) : null,
        React.createElement('div', {
          key: 'foot',
          style: { marginTop: 'auto', display: 'flex', alignItems: 'center', gap: '6px', minWidth: '0' },
        }, [
          showState ? chip('state', meta.raw === true ? meta.text : t(meta.text), meta.color, meta.tint) : null,
          isCurrent && !takeoverControl ? chip('here', t('chip.here'), TOKEN.accent, 'rgba(11, 107, 203, 0.12)') : null,
          takeoverControl ? (facts.takeoverActive || takeover.success
            ? React.createElement('span', {
              key: 'takeover', role: 'status', 'data-takeover-state': node.sessionId,
              style: { marginLeft: 'auto', fontSize: '11px', whiteSpace: 'nowrap', color: TOKEN.labelSecondary },
            }, takeoverLabel)
            : React.createElement('button', {
              key: 'takeover', type: 'button', 'data-takeover': node.sessionId,
              disabled: takeover.pending === true,
              'aria-busy': takeover.pending === true,
              'aria-label': t('takeover.aria', { label: takeoverLabel, name: sessionName(node, node.sessionId), parentId: node.parentId }),
              onClick: function (event) {
                event.stopPropagation()
                requestTakeover(node.sessionId)
              },
              // 原生按钮由浏览器处理 Enter/Space；只拦冒泡，不手工再提交一次。
              onKeyDown: function (event) { event.stopPropagation() },
              style: { marginLeft: 'auto', padding: '2px 0', border: 'none', background: 'transparent',
                color: TOKEN.accent, font: 'inherit', fontSize: '11px', whiteSpace: 'nowrap',
                cursor: takeover.pending ? 'default' : 'pointer', opacity: takeover.pending ? 0.55 : 1 },
            }, takeoverLabel)) : null,

          // 卡片宽度有限，所以这里用紧凑写法；完整含义留在 tooltip 上。
          (isDriver && !isCurrent && !takeoverControl)
            ? React.createElement('span', {
              key: 'driver',
              style: { flex: 'none', fontSize: '11.5px', lineHeight: '17px', color: TOKEN.labelSecondary },
            }, t('chip.answeringYou'))
            : null,
        ]),
      ])
    }

    /* ------------------------------ 手动分叉：队列那一行 ------------------------------ */

    /**
     * 一条消息内容的一行预览（队列行上认人的那一眼）。
     * @param {any} content 消息 content（ContentBlock 数组）。
     * @returns {string} 折叠空白后的有界文本，没有文本部分时为空串。
     */
    function previewOf(content) {
      if (!Array.isArray(content)) return ''
      for (var index = 0; index < content.length; index += 1) {
        var part = content[index]
        if (part !== null && part !== undefined && part.type === 'text' && typeof part.text === 'string') {
          var text = part.text.replace(/\s+/gu, ' ').trim()
          if (text === '') continue
          return text.length > 60 ? text.slice(0, 59) + '…' : text
        }
      }
      return ''
    }

    /**
     * 队列里**可被分叉**的那些条目（手动模式下每一条都要有「分叉」入口）。
     *
     * 过滤规则**逐条复刻** `ui-conversation` 的 `QueueDock`（否则按钮会挂错行）：
     * 取 `inbox['next-turn']`，剔除已经在聊天转写里出现的本地回声（`placement === 'transcript'`），
     * 而**只在等宿主接纳**的本地回声（`placement === 'queued'`）没有宿主消息 id，无法作为
     * 分叉对象，故不进本表——它的「分叉」按钮要等宿主那一行回来才出现（通常几十毫秒）。
     * @param {any} inbox `useProjection('inbox')` 的值。
     * @param {any} pendingSubmissions `useSession(s => s.pendingSubmissions)` 的值。
     * @returns {Array<{id: string, preview: string}>} 按队列顺序的可分叉条目。
     */
    function queuedForkables(inbox, pendingSubmissions) {
      var rows = inbox !== null && inbox !== undefined && Array.isArray(inbox['next-turn'])
        ? inbox['next-turn']
        : []
      var submissions = Array.isArray(pendingSubmissions) ? pendingSubmissions : []

      var inTranscript = {}
      var transcriptCount = 0
      for (var index = 0; index < submissions.length; index += 1) {
        if (submissions[index]?.placement !== 'transcript') continue
        inTranscript[submissions[index].requestId] = true
        transcriptCount += 1
      }

      var queue = rows
      if (transcriptCount > 0) {
        queue = rows.filter(function (row) {
          var source = row?.source
          if (source === undefined || source === null || source.kind !== 'user') return true
          if (!Object.prototype.hasOwnProperty.call(source, 'rpcId')) return true
          return inTranscript[source.rpcId] !== true
        })
      }

      return queue
        .filter(function (row) { return typeof row?.id === 'string' && row.id !== '' })
        .map(function (row) { return { id: row.id, preview: previewOf(row.content) } })
    }

    /**
     * 队列 dock 每一行的 DOM 挂载点。
     *
     * `QueueDock` 的根节点带 `data-queue-dock` 属性、每行是一个 `<li>`——这是**非公开 DOM
     * 契约**（官方没有给"往队列行里加按钮"的槽）。因此这里**只读不写别人的结构**：取不到
     * 就返回空数组，调用方退回自己画一条回退条——绝不猜、不乱插。
     * @param {any} root 查询根（浏览器里是 `document`）。
     * @param {number} count 需要几行的挂载点。
     * @returns {Array<any>} 长度为 count 的数组，缺失位置是 null。
     */
    function queueRowTargets(root, count) {
      var nodes = root !== null && root !== undefined && typeof root.querySelectorAll === 'function'
        ? root.querySelectorAll('[data-queue-dock] li')
        : []
      var targets = []
      for (var index = 0; index < count; index += 1) {
        targets.push(nodes[index] === undefined ? null : nodes[index])
      }
      return targets
    }

    /**
     * 这个节点在队列 dock 的子树里吗（含自身）。
     * @param {any} node DOM 节点。
     * @returns {boolean} 是否属于队列 dock。
     */
    function insideQueueDock(node) {
      var current = node
      for (var depth = 0; depth < 32 && current !== null && current !== undefined; depth += 1) {
        if (current.nodeType === 1 && typeof current.hasAttribute === 'function'
          && current.hasAttribute('data-queue-dock')) {
          return true
        }
        current = current.parentNode
      }
      return false
    }

    /**
     * 这批 DOM 变动碰到队列 dock 了吗。
     *
     * 用途：`MutationObserver` 挂在 `document.body` 上（队列 dock 可能还没挂载），但**只在
     * 队列那一块动了才重渲染**——否则流式输出每帧都会让本组件跟着重画一次。
     * @param {any[]} mutations MutationRecord 数组。
     * @returns {boolean} 是否需要重渲染。
     */
    function touchesQueueDock(mutations) {
      for (var index = 0; index < mutations.length; index += 1) {
        var mutation = mutations[index]
        if (insideQueueDock(mutation?.target)) return true
        var added = mutation?.addedNodes
        for (var position = 0; added !== undefined && position < added.length; position += 1) {
          if (insideQueueDock(added[position])) return true
        }
      }
      return false
    }

    /**
     * 发一次手动分叉请求。
     * @param {string} sessionId 目标会话。
     * @param {string} messageId 队列里那条消息的 id。
     * @returns {Promise<{ok: boolean, sessionId?: string, error?: string}>} 服务端结论。
     */
    function forkRequest(sessionId, messageId) {
      var headers = { 'content-type': 'application/json' }
      headers[FORK_HEADER] = '1'
      return fetch(FORK_PATH, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify({ sessionId: sessionId, messageId: messageId }),
      }).then(function (response) {
        return response.json().catch(function () { return undefined }).then(function (body) {
          if (body !== undefined && body !== null && typeof body === 'object') return body
          return { ok: false, error: 'http-' + String(response.status) }
        })
      })
    }

    /**
     * 给一个控件挂上官方悬停提示（拿不到 primitives 时退回原生 `title`）。
     * @param {string} label 提示文案。
     * @param {object} element 控件元素。
     * @returns {object} 可能被包了一层的元素。
     */
    function withTooltip(label, element) {
      if (typeof primitives.Tooltip !== 'function') return element
      return React.createElement(primitives.Tooltip, {
        portal: true,
        label: label,
        side: 'bottom',
        delayMs: 500,
      }, element)
    }

    /**
     * 队列行右侧那枚「分叉」按钮（点它才分叉这条排队中的指令）。
     *
     * **观感必须与旁边的官方按钮一模一样**（编辑 / 删除 / 转向）：官方那几个是
     * **图标按钮**——28×28 圆形、14px 图标、无文字、悬停提示在 Tooltip 里
     * （`QueueDock.module.css` 的 `.action`）。所以这里也只放图标：
     * 文字版会比旁边宽一倍、圆角形状也不同，一眼就看得出是外挂的。
     *
     * 状态只体现在**颜色与提示文案**上，几何形状不变：
     * idle 三级文字色 / busy 半透明（`:disabled` 的 .45）/ failed 错误色 + 提示说明可再点一次。
     *
     * 单击即发请求；服务端是唯一权威——它只认"这条消息此刻仍在那个 agent 的队列里"，
     * 抢不到就回 409，本按钮转成失败态并把原因回报进决策日志（`client.note`）。
     * 不自动重试：同一条消息点第二次是用户的决定，不是我们的。
     * @param {object} props `{ sessionId, messageId, preview }`。
     * @returns {object} React 元素。
     */
    function ForkButton(props) {
      var pair = React.useState('idle')
      var phase = pair[0]
      var setPhase = pair[1]

      var submit = function () {
        if (phase === 'busy') return
        setPhase('busy')
        forkRequest(props.sessionId, props.messageId)
          .then(function (result) {
            if (result.ok === true) {
              setPhase('idle')
              postNote('fork.button.ok: ' + props.messageId + ' -> ' + String(result.sessionId))
              return
            }
            setPhase('failed')
            postNote('fork.button.refused: ' + props.messageId + ' ' + String(result.error))
          })
          .catch(function (error) {
            setPhase('failed')
            postNote('fork.button.failed: ' + props.messageId + ' ' + String(error))
          })
      }

      // 提示文案：官方同级按钮是「编辑 / 删除 / 转向」这种一个词，所以常态也只给「分叉」；
      // 这条指令本身是什么，交给 aria-label（读屏能听全，视觉上不占位）。
      var tooltip = phase === 'busy' ? t('fork.button.busy')
        : (phase === 'failed' ? t('fork.button.failed') : t('fork.button.idle'))
      var icon = typeof primitives.IconBranchOutlineRegular === 'function'
        ? React.createElement(primitives.IconBranchOutlineRegular, { size: 14 })
        // 拿不到官方图标时用分支符号顶上：字号与图标同量级，几何形状不受影响。
        : React.createElement('span', { style: { fontSize: '14px', lineHeight: 1 } }, '⑂')

      var attributes = {
        type: 'button',
        className: 'dsh-autofork-fork',
        'aria-label': t('fork.button.aria', { preview: props.preview }),
        disabled: phase === 'busy',
        onClick: submit,
      }
      attributes[FORK_ATTR] = ''
      if (phase === 'failed') attributes['data-tone'] = 'error'
      // 有官方 Tooltip 时不要再挂原生 `title`（会与它叠成两个提示）；没有时 title 是唯一的说明面。
      if (typeof primitives.Tooltip !== 'function') attributes.title = tooltip

      return withTooltip(tooltip, React.createElement('button', attributes, [icon]))
    }

    /**
     * 队列行内的「分叉」按钮注入点（`conversation.input.dock` 的 list 槽条目）。
     *
     * ## 为什么是 DOM 注入而不是槽
     *
     * 队列行右侧那几个按钮（编辑 / 删除 / 转向）写死在官方 `QueueDock` 里，`QueueAction`
     * 也是 `edit | remove | steer` 的封闭联合——插件层**没有**"往一条队列行加动作"的槽，
     * 也没法接管或包裹别人已注册的槽条目（注册绑在各自 fiber 上）。所以这里用官方留的
     * `conversation.input.dock` 槽**只做一件事**：用 `createPortal` 把自己的按钮挂进那一行。
     *
     * ## 契约与失败模式（都是"不出现"，不是"做错事"）
     *
     *  · 只认 `[data-queue-dock] li` 这个非公开 DOM 契约；结构变了 → 挂载点取不到 →
     *    本组件退回画一条右对齐的回退条（每条排队指令一个按钮），功能仍在；
     *  · 队列面板**收起**（多于一条时行整体不在 DOM 里）→ 同上走回退条；
     *  · 没有 `react-dom`（非 web 组合）→ 只走回退条；
     *  · 模式不是手动（`mode !== 'manual'`）→ 整条不渲染。
     * @param {object} props 槽运行时 props（session 作用域：`sessionId` / `useProjection` / `useSession`）。
     * @returns {any} 门户数组、回退条，或 null。
     */
    function ForkDock(props) {
      var pair = React.useState(getSnapshot())
      var setSnapshot = pair[1]
      React.useEffect(function () {
        return subscribe(function () { setSnapshot(getSnapshot()) })
      }, [])

      var sessionId = props.sessionId
      var inbox = typeof props.useProjection === 'function' ? props.useProjection('inbox') : undefined
      var pending = typeof props.useSession === 'function'
        ? props.useSession(function (state) { return state.pendingSubmissions })
        : undefined
      var forkables = queuedForkables(inbox, pending)

      var snap = pair[0]
      // 以**服务端**为准：只有宿主此刻真的按手动模式行事时，按钮才出现。
      var manual = snap.mode === 'manual' && snap.current === sessionId

      var bumpPair = React.useState(0)
      var bump = bumpPair[1]
      var signature = forkables.map(function (row) { return row.id }).join('\u0000')

      // 队列面板从"收起"变"展开"时行才进 DOM，而队列长度没变——所以还得听 DOM 变化。
      // 只在**队列 dock 子树**变动时重渲染：整页 DOM 变化（流式输出）不该让本组件跟着重画。
      React.useEffect(function () {
        if (!manual || forkables.length === 0 || reactDom === undefined) return undefined
        if (typeof MutationObserver !== 'function' || typeof document === 'undefined') return undefined
        var observer = new MutationObserver(function (mutations) {
          if (!touchesQueueDock(mutations)) return
          bump(function (value) { return value + 1 })
        })
        observer.observe(document.body, { childList: true, subtree: true })
        return function () { observer.disconnect() }
      }, [signature, manual, sessionId])

      if (!manual || forkables.length === 0) return null

      // 挂载点**在渲染期直接解析**：DOM 已提交，读到的就是这一刻的队列行。读不到（结构变了 /
      // 面板收起 / 没有 react-dom）就退回下面那条回退条——"不出现"是唯一的失败模式。
      var targets = reactDom === undefined
        ? []
        : queueRowTargets(typeof document === 'undefined' ? undefined : document, forkables.length)

      var portals = []
      if (reactDom !== undefined && typeof reactDom.createPortal === 'function') {
        for (var index = 0; index < forkables.length; index += 1) {
          var node = targets[index]
          if (node === undefined || node === null) continue
          portals.push(reactDom.createPortal(
            React.createElement(ForkButton, {
              sessionId: sessionId,
              messageId: forkables[index].id,
              preview: forkables[index].preview,
            }),
            node,
            forkables[index].id,
          ))
        }
      }
      if (portals.length > 0) return portals

      // 回退条：行不在 DOM 里（面板收起）或拿不到 react-dom 时，每条排队指令仍各有一个入口。
      // 间距与官方 `.actions` 的 10px 对齐（按钮本身样式同 `.action`，见 installForkStyles）。
      var barProps = {
        style: { display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: '10px', flexWrap: 'wrap' },
      }
      barProps[FORKBAR_ATTR] = ''
      return React.createElement('div', barProps,
        forkables.map(function (row) {
          return React.createElement(ForkButton, {
            key: row.id,
            sessionId: sessionId,
            messageId: row.id,
            preview: row.preview,
          })
        }))
    }

    /* ------------------------------ 手动分叉：开关在哪 ------------------------------ */

    /**
     * 把「分叉方式」写进设置文档，并按宿主回读值确认真的落库了。
     *
     * 不自己传 `expectedRevision`：官方 `ConfigFormController` 自己按 `pendingRevision`
     * 串行排队并给后继写定栅栏；自己传快照 revision 会绕过那道栅栏，同一 RTT 内的连续改动
     * 会被宿主按 CAS 拒（第一次其实已落库），结果是误报"未被接受"。
     * @param {any} scope `configForms.get(SETTINGS_NS)` 的 ConfigFormController。
     * @param {string} value 目标取值（`'auto'` / `'manual'`）。
     * @returns {Promise<void>} 未被接受时抛错（卡片据此提示并回读宿主值）。
     */
    function writeForkMode(scope, value) {
      return Promise.resolve(scope.mutate([{ op: 'set', path: ['forkMode'], value: value }]))
        .then(function (accepted) {
          var committed = scope.getSnapshot()?.value
          var landed = committed === null || committed === undefined ? undefined : committed.forkMode
          if (accepted !== true || landed !== value) {
            throw new Error('dsh-autofork: 设置写入未被接受（forkMode=' + value + '）')
          }
        })
    }

    /**
     * 两种方式的**选项卡文案键**：每个选项三行——名字（`自动分叉`）、短标签（`触发即分叉`）、
     * 一句话说明。短标签与说明分层给：前者用来"一眼看出区别"，后者用来"搞清细节"。
     * 存**键**而不是文案：概览行（`当前：…`）与卡片都在渲染时经 `t()` 现取，切语言即时生效。
     */
    var MODE_CARDS = [
      {
        value: 'auto',
        label: 'settings.mode.auto.label',
        tagline: 'settings.mode.auto.tagline',
        hint: 'settings.mode.auto.hint',
      },
      {
        value: 'manual',
        label: 'settings.mode.manual.label',
        tagline: 'settings.mode.manual.tagline',
        hint: 'settings.mode.manual.hint',
      },
    ]

    /**
     * 一个分叉方式**选项卡**（`role="radio"`）。
     *
     * 选中态由**三处同时**表达（描边品牌色 + 淡品牌底 + 圆点填充），未选中只留 1px 中性描边——
     * 与树卡的选中药同一种语言（不靠"多一个边框"这种单点差异，色觉差异也能看出来）。
     */
    function ModeOption(props) {
      var option = props.option
      var selected = props.selected === true
      var disabled = props.disabled === true
      var hoverPair = React.useState(false)
      var hover = hoverPair[0]
      var setHover = hoverPair[1]
      var choose = function () { if (!disabled && !selected) props.onChoose(option.value) }
      return React.createElement('div', {
        role: 'radio',
        'aria-checked': selected ? 'true' : 'false',
        'aria-disabled': disabled ? 'true' : undefined,
        // 稳定锚：渲染自证与浏览器排障都按它认这一个选项（同树卡的 `data-session-id`）。
        'data-mode': option.value,
        tabIndex: disabled ? undefined : 0,
        onClick: choose,
        onKeyDown: function (event) {
          if (event.key !== 'Enter' && event.key !== ' ') return
          event.preventDefault()
          choose()
        },
        onMouseEnter: function () { setHover(true) },
        onMouseLeave: function () { setHover(false) },
        style: {
          display: 'flex',
          alignItems: 'flex-start',
          gap: '10px',
          padding: '12px 14px',
          boxSizing: 'border-box',
          borderRadius: '10px',
          cursor: disabled ? 'not-allowed' : (selected ? 'default' : 'pointer'),
          border: '1px solid ' + (selected
            ? TOKEN.accent
            : 'var(--dsw-alias-border-l1, rgba(127, 127, 127, 0.25))'),
          background: selected
            ? 'rgba(11, 107, 203, 0.08)'
            : (hover && !disabled ? TOKEN.hover : 'transparent'),
          opacity: disabled ? 0.55 : 1,
          transition: 'border-color 120ms ease, background 120ms ease',
        },
      }, [
        React.createElement('span', {
          key: 'dot',
          style: {
            flex: 'none',
            width: '14px',
            height: '14px',
            marginTop: '2px',
            borderRadius: '999px',
            display: 'grid',
            placeItems: 'center',
            border: '1.5px solid ' + (selected
              ? TOKEN.accent
              : 'var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.45))'),
          },
        }, selected ? React.createElement('span', {
          key: 'fill',
          style: { width: '6px', height: '6px', borderRadius: '999px', background: TOKEN.accent },
        }) : null),
        React.createElement('div', {
          key: 'body',
          style: { display: 'flex', flexDirection: 'column', gap: '4px', minWidth: '0' },
        }, [
          React.createElement('div', {
            key: 'top',
            style: { display: 'flex', alignItems: 'baseline', gap: '8px', minWidth: '0', flexWrap: 'wrap' },
          }, [
            React.createElement('span', {
              key: 'label',
              style: {
                fontSize: '13px',
                fontWeight: selected ? '600' : '500',
                lineHeight: '18px',
                color: TOKEN.labelPrimary,
              },
            }, t(option.label)),
            React.createElement('span', {
              key: 'tagline',
              style: {
                fontSize: '11.5px',
                lineHeight: '18px',
                color: selected ? TOKEN.accent : TOKEN.labelTertiary,
              },
            }, t(option.tagline)),
            // 「当前」那枚胶囊已删（用户 2026-10：冗余——选中态已由描边 + 淡品牌底 + 圆点三处
            // 同时表达，再挂一枚同样的字只是重复）。
          ]),
          React.createElement('div', {
            key: 'hint',
            style: { fontSize: '12px', lineHeight: '18px', color: TOKEN.labelSecondary },
          }, t(option.hint)),
        ]),
      ])
    }

    /**
     * Plugins 页上本插件的设置卡片（`plugins.bundle.config` keyed 槽，key = bundle 包名）。
     *
     * 与官方通用设置页同一种保存语义：**改动即时写入**，没有保存按钮——官方设置页的开关与
     * 选项都是"改即落库"，只有部分页面用页脚保存。
     * @param {object} props 槽 props（`view` / `t`）加注入面（`useForkSettings` / `writeForkMode`）。
     * @returns {any} 一行描述（`summary` 视图）、设置区、"设置不可用"那一行（命名空间不被宿主
     *   服务时——**不出空壳也不出空白**），或 null（快照还没到）。
     */
    function ForkSettingsCard(props) {
      var state = props.useForkSettings(function (value) { return value })
      var pair = React.useState(false)
      var failed = pair[0]
      var setFailed = pair[1]

      if (state === null || state === undefined) return null

      /**
       * `status === 'unavailable'` = 宿主的设置文档里**没有这个命名空间**
       * （`ui-settings` 的 `ConfigFormController.derive()`：mirror 的 view 已到，但
       * `view.namespaces` 里找不到 `dsh-autofork`）。
       *
       * ⚠️ **这一态必须留下可见线索，不能像以前那样 `return null`**（用户 2026-10 实测报的
       * "原本存在的设置选项不见了"）：插件在运行中被装/卸/更新时，宿主半边可能仍是旧进程里的
       * 那一份，于是命名空间在设置文档里缺席，而卡片**整块消失**——用户看到的是"设置没了"，
       * 却拿不到任何提示。留一行字，至少把"去哪恢复"说清楚。
       *
       * 只对**已定态**的 unavailable 出字：`idle` / `loading`（mirror 还没到）仍然照常渲染，
       * 免得刷新页面时先闪一行错误。
       */
      var unavailable = state.status === 'unavailable'

      var current = state.value !== null && state.value !== undefined && state.value.forkMode === 'manual'
        ? 'manual'
        : 'auto'
      // `summary` 视图：官方包页那行摘要——直接报**当前值**，比罗列两个选项名有用。
      if (props.view === 'summary') {
        if (unavailable) return t('settings.summary.unavailable')
        return t('settings.summary.current', { mode: t(current === 'manual' ? 'settings.mode.manual.label' : 'settings.mode.auto.label') })
      }

      if (unavailable) {
        return React.createElement('div', {
          'data-dsh-autofork-settings-missing': '',
          role: 'status',
          style: {
            display: 'flex',
            flexDirection: 'column',
            gap: '6px',
            maxWidth: '720px',
            padding: '14px 16px',
            boxSizing: 'border-box',
            border: '1px solid var(--dsw-alias-border-l1, rgba(127, 127, 127, 0.25))',
            borderRadius: '12px',
            background: 'var(--dsw-alias-bg-layer-2, transparent)',
          },
        }, [
          React.createElement('span', {
            key: 'title',
            style: { fontSize: '13px', fontWeight: '600', lineHeight: '20px', color: TOKEN.labelPrimary },
          }, t('settings.title')),
          React.createElement('span', {
            key: 'note',
            style: { fontSize: '12px', lineHeight: '18px', color: TOKEN.labelSecondary },
          }, t('settings.unavailable.note')),
        ])
      }

      var disabled = state.writable !== true

      var choose = function (value) {
        if (disabled || value === current) return
        setFailed(false)
        Promise.resolve(props.writeForkMode(value)).catch(function (error) {
          setFailed(true)
          postNote('settings.write-refused: ' + String(error))
        })
      }

      return React.createElement('div', {
        'data-dsh-autofork-settings': '',
        style: {
          display: 'flex',
          flexDirection: 'column',
          gap: '12px',
          // 与「分叉」页签的卡片同一套语言：1px 中性描边 + 12px 圆角 + 一层抬升的表面。
          // 限一下宽：两列选项卡在超宽屏上拉成两条长行会很难读。
          maxWidth: '720px',
          padding: '14px 16px',
          boxSizing: 'border-box',
          border: '1px solid var(--dsw-alias-border-l1, rgba(127, 127, 127, 0.25))',
          borderRadius: '12px',
          background: 'var(--dsw-alias-bg-layer-2, transparent)',
        },
      }, [
        // ① 头部：标题（**只在不可写时**右侧出现 `只读` 胶囊——异常态才占版面）
        React.createElement('div', {
          key: 'head',
          style: { display: 'flex', alignItems: 'center', gap: '8px', minWidth: '0' },
        }, [
          React.createElement('span', {
            key: 'title',
            style: { fontSize: '13px', fontWeight: '600', lineHeight: '20px', color: TOKEN.labelPrimary },
          }, t('settings.title')),
          React.createElement('span', { key: 'spacer', style: { flex: '1 1 auto' } }),
          // 「即时生效」那枚胶囊已删（用户 2026-10：与交互本身重复——点一下就看到选中态变了，
          // 不需要再用文字说一遍）。**「只读」保留**：那是异常态，也是"为什么点不动"的唯一线索。
          disabled ? chip('save', t('settings.readonly'), TOKEN.labelSecondary, 'rgba(127, 127, 127, 0.14)') : null,
        ]),
        // ② 导语：这一节到底在决定什么
        React.createElement('div', {
          key: 'intro',
          style: { fontSize: '12px', lineHeight: '18px', color: TOKEN.labelSecondary },
        }, t('settings.intro')),
        // ③ 选项卡：两列（窄了自动折成一列）
        React.createElement('div', {
          key: 'options',
          role: 'radiogroup',
          'aria-label': t('settings.title'),
          style: {
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
            gap: '10px',
          },
        }, MODE_CARDS.map(function (option) {
          return React.createElement(ModeOption, {
            key: option.value,
            option: option,
            selected: current === option.value,
            disabled: disabled,
            onChoose: choose,
          })
        })),
        // 页脚那条（"写进 profile 的 cordis.patch.yml、重启后仍在、没有保存按钮"）**已删**：
        // 用户 2026-10 判定它是噪声——落盘位置属于**文档**，不该占设置界面的版面。
        // 同一轮里头部那枚"即时生效"胶囊也被删掉（与交互本身重复：点一下就看到选中态变了）。
        // ⑤ 写入被拒：与触发指令的引用块同一种"左侧竖线"记号，错误态也用同一套
        failed ? React.createElement('div', {
          key: 'failed',
          role: 'status',
          style: {
            fontSize: '12px',
            lineHeight: '18px',
            color: 'var(--dsw-alias-state-error-primary, #c62828)',
            borderLeft: '2px solid var(--dsw-alias-state-error-primary, #c62828)',
            paddingLeft: '8px',
          },
        }, t('settings.failed')) : null,
      ])
    }

    /**
     * 注册设置卡片。
     *
     * 走**嵌套** `ctx.inject(['configForms'])` 而不是顶层 `inject`：`ui-settings` 缺席的
     * 组合里整条客户端插件仍要能用（顶层缺服务会让 apply 直接抛，插件的其他功能一起消失）。
     *
     * 注册**不**经 `configForms.whileServed()`（官方页面的写法）：本卡片只出现在**本插件自己的
     * 包页**上，而 `plugins.bundle.config` 的 keyed 槽本身就是渲染条件——服务缺席时卡片自己
     * 渲染成空，比"整个槽位时有时无"更少一种只在浏览器里才暴露的失败模式。
     * @param {any} ctx 客户端插件上下文。
     * @param {any} slots 槽服务。
     * @returns {void}
     */
    function registerForkSettings(ctx, slots) {
      // 整段**包在 try 里**：设置卡片是可选能力，而这条路径（嵌套 inject + configForms 的形状）
      // 只在浏览器里才能真验。任何一步不如预期都必须是"卡片不出现"，绝不能把 apply 抛掉——
      // 那会连带「分叉」页签与焦点交付一起消失（比少一个设置项严重得多）。
      try {
        if (typeof ctx.inject !== 'function') {
          postNote('settings.no-inject: 客户端 ctx 没有 inject，设置卡片未注册')
          return
        }
        ctx.inject(['configForms'], function (formCtx) {
          var forms = formCtx.configForms
          if (forms === undefined || forms === null || typeof forms.get !== 'function') {
            postNote('settings.no-config-forms: configForms 服务形状不符，设置卡片未注册')
            return
          }
          var scope = forms.get(SETTINGS_NS)
          slots.inject('plugins.bundle.config', function () {
            return slots.register({
              name: 'plugins.bundle.config',
              key: BUNDLE_PKG,
              inject: function () {
                return {
                  hooks: {
                    forkSettings: {
                      getSnapshot: function () { return scope.getSnapshot() },
                      subscribe: function (listener) { return scope.subscribe(listener) },
                    },
                  },
                  writeForkMode: function (value) { return writeForkMode(scope, value) },
                }
              },
            }, ForkSettingsCard)
          })
        })
      } catch (error) {
        postNote('settings.register-failed: ' + String(error))
      }
    }

    /* ------------------------- 卡片（消息卡，照抄官方 trigger 观感） ------------------------- */

    /**
     * 消息卡的样式：**逐条照抄官方 `TurnTriggerNodeView.module.css`**（插件拿不到那个 CSS module
     * 的哈希类名，只能复刻声明），只把类名前缀换成我们自己的属性选择器。这样这三张卡片与官方
     * 「收到任务消息」卡片在边框、圆角、留白、字号、折叠行为上完全一致。
     * @returns {() => void} 卸载函数。
     */
    function installCardStyles() {
      if (typeof document === 'undefined' || document.head === null || document.head === undefined) {
        return function () {}
      }
      var element = document.createElement('style')
      element.id = 'dsh-autofork-card-styles'
      element.textContent = [
        '[data-dsh-autofork-card]{border:.5px solid var(--dsw-alias-border-l1);',
        'border-radius:var(--dsw-radius-xl);',
        'background:var(--dsw-alias-turn-trigger-bg,var(--dsw-alias-markdown-code-block));',
        'min-width:0;transition:background-color .1s}',
        '[data-dsh-autofork-card]:hover{background:var(--dsw-alias-turn-trigger-bg-hover,',
        'var(--dsw-alias-interactive-bg-hover))}',
        '[data-dsh-autofork-card] > button{width:100%;color:var(--dsw-alias-label-tertiary);font:inherit;',
        'text-align:left;cursor:pointer;background:0 0;border:0;align-items:center;gap:10px;',
        'padding:12px 16px;transition:color .1s;display:flex}',
        '[data-dsh-autofork-card] > button:hover{color:var(--dsw-alias-label-secondary)}',
        '[data-dsh-autofork-card] [data-part=icon]{color:inherit;flex:none;display:inline-flex}',
        '[data-dsh-autofork-card] [data-part=title]{font-size:var(--dsh-content-font-size,14px);flex:none}',
        '[data-dsh-autofork-card] [data-part=time]{color:inherit;font:var(--dsw-font-xxs-12);flex:none;',
        'margin-left:auto}',
        // 折叠标题行上的发送方（只有 `steer` 用）：比标题低一档、比时间略高一点，
        // 用 tabular 数字让不同卡的会话短 id 竖直对齐。
        '[data-dsh-autofork-card] [data-part=sender-inline]{color:var(--dsw-alias-label-caption);',
        'font:var(--dsw-font-xxs-12);flex:none;font-variant-numeric:tabular-nums}',
        '[data-dsh-autofork-card] [data-part=chevron]{color:inherit;flex:none}',
        '[data-dsh-autofork-card][data-open] [data-part=chevron]{transform:rotate(180deg)}',
        '[data-dsh-autofork-card] [data-part=body]{padding:0 16px 12px 40px}',
        '[data-dsh-autofork-card] [data-part=sender]{color:var(--dsw-alias-label-caption);',
        'overflow-wrap:anywhere;margin:0 0 6px}',
        '[data-dsh-autofork-card] [data-part=content]{white-space:pre-wrap;overflow-wrap:anywhere;',
        'max-height:240px;font:var(--dsw-font-xxs-12);overflow:auto}',
        '@media (prefers-reduced-motion:reduce){[data-dsh-autofork-card],[data-dsh-autofork-card] > button',
        '{transition:none}}',
      ].join('')
      document.head.appendChild(element)
      return function () {
        if (element.parentNode !== null && element.parentNode !== undefined) element.parentNode.removeChild(element)
      }
    }

    /**
     * 消息卡视图：图标 + 标题 + 时间 + 可展开正文（结构照抄官方 `TurnTriggerNodeView`）。
     * @param {any} props 槽位注入的 props（`node` 是本模块定义产出的节点）。
     * @returns {any} React 元素。
     */
    /**
     * **原则（用户 2026-10 定下，改动这张卡前先读）**：卡片正文**只能是模型看到的内容**——
     * 至多剥掉"插件自己写进正文、而卡片标题行已经表达过"的前缀（{@link cardBody}）；
     * **绝不在呈现层发明模型看不到的句子**（例如"这条通知触发了本轮回复。"这类解释性文案：
     * 对使用者是噪声，对模型不存在，两边都不讨好）。要让人看见的信息，要么进模型正文
     * （像 `block` 的"它在等你回复"），要么是**数据派生**的标签（标题 / 发送方 / 时间 / 状态）。
     * @param {any} props 渲染输入。
     * @returns {any} React 元素。
     */
    function AutoforkCardView(props) {
      var node = props?.node
      var data = node?.data ?? {}
      var [open, setOpen] = React.useState(false)
      var Icon = primitives.IconPaperPlaneOutlineRegular ?? primitives.IconBranchOutlineRegular
      var Chevron = primitives.IconChevronDownOutlineRegular
      var title = t(CARD_TITLES[data.marker] ?? 'card.title.fallback')
      var sender = typeof data.sender === 'string' ? data.sender : ''
      var clock = ''
      try {
        clock = new Date(data.time).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })
      } catch (error) {
        clock = ''
      }
      var head = React.createElement('button', {
        type: 'button',
        'aria-expanded': open,
        onClick: function () { setOpen(!open) },
      },
      Icon === undefined ? null : React.createElement('span', { 'data-part': 'icon', 'aria-hidden': true },
        React.createElement(Icon, { size: 14 })),
      React.createElement('span', { 'data-part': 'title' }, title),
      // 「等待回复」：`warn` 色（比中性色更醒目，但明确不是错误），描述这条消息的属性——
      // 发送方是以 `block:true` 发的；它超时放弃后胶囊仍在（这是历史属性，不是实时状态）。
      data.awaitReply === true
        ? chip('await', t('card.awaitReply'), 'var(--dsw-alias-state-warn-primary, #b8860b)', 'rgba(184, 134, 11, 0.12)')
        : null,
      // `steer` 的**发送方是会变的**（家族里任意一条都可能发来），所以折叠行就带出来；另外三种卡
      // 的发送方恒定（就是分叉出来的那条），展开后正文里有 `来自会话 …`，不必再占标题行。
      data.marker === 'steer' && sender !== ''
        ? React.createElement('span', { 'data-part': 'sender-inline' }, t('card.sender.inline', { id: shortId(sender) }))
        : null,
      clock === '' ? null : React.createElement('time', { 'data-part': 'time' }, clock),
      Chevron === undefined ? null : React.createElement(Chevron, { 'data-part': 'chevron', size: 12 }))
      var body = open === false ? null : React.createElement('div', { 'data-part': 'body' },
        React.createElement('p', { 'data-part': 'sender' }, t('card.sender.body', { id: data.sender === '' ? t('common.unknown') : data.sender })),
        // 正文 = 模型可见文本（剥掉卡片已表达过的前缀，见 `cardBody` 与上面的原则）。
        React.createElement('div', { 'data-part': 'content' },
          cardBody(typeof data.text === 'string' ? data.text : '', data.bodyOffset, data.body)))
      return React.createElement('section', {
        [CARD_ATTR]: data.marker,
        'data-open': open ? '' : undefined,
      }, head, body)
    }

    /**
     * 注册"这三条消息长成卡片"的客户端节点定义 + 视图。
     *
     * 契约来自官方 `ui-goal`（它用同一套 API 画 `/goal` 指令卡片）：
     *  · `ctx.uiConversation.events.register({kind, target:'chat', match, start, update, buildViewNode})`
     *    定义一种**新的会话节点**；
     *  · `slots.register({name:'conversation.chat.node', key:<kind>}, View)` 把该 kind 的渲染交给
     *    我们的组件（ui-chat 的每个 flow item 里都有 `[data-slot="conversation.chat.node"]`）。
     *
     * 走**嵌套** `ctx.inject(['uiConversation'])`：这两个服务缺席（比如非 web 组合）时只丢卡片，
     * 不能把整条客户端插件（页签 / 焦点交付 / 分叉按钮）一起拖下水。
     * @param {any} ctx 客户端根上下文。
     * @param {any} slots slots 服务。
     * @returns {() => void} 卸载函数。
     */
    function registerAutoforkCards(ctx, slots) {
      if (typeof ctx.inject !== 'function' || slots === undefined) return function () {}
      var disposeStyles = installCardStyles()
      var disposeEvents = function () {}
      try {
        ctx.inject(['uiConversation'], function (conversationCtx) {
          var definition = {
            kind: CARD_KIND,
            target: 'chat',
            match: function (event) {
              // 只认本插件自己写的三条（宿主在 source 上打了 `autofork` 标记）——
              // 别人的 agent 消息照旧走官方渲染，我们不去抢。
              if (event?.type !== 'user/message') return null
              var marker = event.data?.source?.autofork
              if (typeof marker !== 'string') return null
              return { id: String(event.data.id), role: 'start' }
            },
            start: function (context, match, reader) {
              var event = match.event
              // 这条消息若是**本轮 turn 的开场触发**（被 next-turn 认领），官方 `input-message`
              // 会把它渲染成 turn-trigger 卡片（后台回传走 `followup` 时就是这种情况）——
              // 我们不再画第二张，否则同一个事件上会出现两张卡。判定与官方同源：
              //   waking = reader.previous('inbox-next-turn')?.state.currentClaimed.has(id) === true || idleSteer
              // `idleSteer` 那条我们不复制：它的三个前置（开场 step / claimSeq 关系 / 批里没有人类
              // 消息）在本插件这三条消息上都不成立——通知与摘要走 next-step 与用户指令**同批**
              // （claimedHuman=true），回传的两条路要么命中 next-turn，要么落进人类开场的轮里。
              var nextTurn = reader?.previous?.('inbox-next-turn')?.state
              if (nextTurn?.currentClaimed?.has(String(event.data.id)) === true) return undefined
              return {
                id: match.id,
                seq: event.seq,
                time: event.time,
                marker: event.data.source.autofork,
                sender: typeof event.data.source.senderSessionId === 'string' ? event.data.source.senderSessionId : '',
                // 发送方在等回复（`fork_send(block:true)`）⇒ 标题行挂「等待回复」胶囊，
                // 免得收方会话"收下但不回"（用户 2026-10）。
                awaitReply: event.data.source.awaitReply === true,
                /** 正文里发送方前缀的长度（宿主给；**旧消息的兼容路径**，见 `cardBody`）。 */
                bodyOffset: typeof event.data.source.bodyOffset === 'number' ? event.data.source.bodyOffset : 0,
                /** 纯正文（不含发送方前缀）：宿主单独给，语言无关。 */
                body: typeof event.data.source.bodyText === 'string' ? event.data.source.bodyText : '',
                text: (event.data.content ?? [])
                  .filter(function (part) { return part?.type === 'text' })
                  .map(function (part) { return part.text })
                  .join(''),
              }
            },
            update: function (context) { return context.state },
            buildViewNode: function (context) {
              if (context.state === undefined) return null
              return {
                key: context.key,
                kind: CARD_KIND,
                id: context.id,
                target: 'chat',
                anchorSeq: context.state.seq,
                // ⚠️ **必须显式 unresolved**：客户端把"落在 turn 内、且 kind 不在
                // `TURN_PROCESS_INDEPENDENT_KINDS` 里"的节点当成 turn 的**过程成员**，
                // 折进那个可折叠的 "Completed in …" 分组里（真 GUI 实测：卡片被折叠、文字都取不到）。
                // 标成 unresolved 后它就是独立的一行，显示位置仍由 anchorSeq（= 事件 seq）决定，
                // 所以顺序依旧是"通知 → 摘要 → 用户那条指令"。
                location: { kind: 'unresolved' },
                visibility: 'visible',
                data: context.state,
              }
            },
          }
          disposeEvents = conversationCtx.uiConversation.events.register(definition) ?? function () {}
          postNote('card.registered')
        })
        // ⚠️ **必须**包在 `slots.inject('conversation.chat.node', …)` 里（官方 ui-goal 就是这么写的）。
        // 直接 `slots.register({name, key}, View)` 不会生效：宿主按 kind 查这个 keyed 子槽时查不到，
        // 于是退回它自带的 fallback（真 GUI 实测：渲染成一行 "Unknown surface event: autofork-message"）。
        slots.inject('conversation.chat.node', function () {
          // `register` 正常返回卸载函数；拿不到也不能让整块崩掉（卡片是可选能力）。
          return slots.register({ name: 'conversation.chat.node', key: CARD_KIND }, AutoforkCardView) ?? function () {}
        })
      } catch (error) {
        // 卡片是可选能力（页签 / 按钮 / 焦点交付才是主体）：任何一步失败都只降级成
        // "消息以原生方式呈现"，不能让整个客户端条目挂掉。
        postNote('card.failed: ' + String(error))
      }
      return function () {
        disposeEvents()
        disposeStyles()
      }
    }

    function installForkStyles() {
      if (typeof document === 'undefined' || document.head === null || document.head === undefined) {
        return function () {}
      }
      var existing = document.getElementById('dsh-autofork-styles')
      var element = existing
      if (element === null || element === undefined) {
        element = document.createElement('style')
        element.id = 'dsh-autofork-styles'
        // 逐条照抄官方 `QueueDock.module.css` 的 `.action`（旁边编辑 / 删除 / 转向那三个按钮
        // 用的就是它）——插件拿不到那个 CSS module 的哈希类名，只能复刻声明：
        //
        //   .action{corner-shape:round;width:28px;height:28px;color:var(--dsw-alias-label-tertiary);
        //           cursor:pointer;background:0 0;border:none;border-radius:999px;flex:none;
        //           place-items:center;padding:0;display:grid}
        //   .action:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}
        //   .action:focus-visible{outline:var(--dsw-focus-ring-width) solid
        //           var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:-2px}
        //   .action:disabled{cursor:default;opacity:.45}
        //
        // `corner-shape:round` 不能省：主题层默认把按钮渲染成超椭圆（squircle），少了它这个
        // 圆形按钮会变成圆角方块（whale-girl 在官方 Switch 上踩过同一条）。
        // 唯一与官方不同的地方是失败态的颜色（官方没有这个状态）——几何形状仍然一致。
        element.textContent = [
          '[data-dsh-autofork-fork]{corner-shape:round;width:28px;height:28px;',
          'color:var(--dsw-alias-label-tertiary,#9a9a9a);cursor:pointer;background:0 0;border:none;',
          'border-radius:999px;flex:none;place-items:center;padding:0;display:grid}',
          '[data-dsh-autofork-fork]:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}',
          '[data-dsh-autofork-fork]:focus-visible{outline:var(--dsw-focus-ring-width) solid ',
          'var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:-2px}',
          '[data-dsh-autofork-fork]:disabled{cursor:default;opacity:.45}',
          '[data-dsh-autofork-fork][data-tone=error]{color:var(--dsw-alias-state-error-primary,#c62828)}',
          // 藏掉官方的左右拖动宽度手柄：它挂在**各页签共享**的会话内容区上，本来只服务
          // 「对话」页签（调转写内容宽度）。官方自己也有同款写法（`ConversationRoot` 的
          // `.widthHandle{display:none}` 那条用 `:has()`），我们照抄这个思路，锚点用稳定
          // 的 `[data-width-handle]`（官方 CSS module 类名是哈希，插件拿不到）。
          // 切页签时另一个视图会被卸载（实测），所以本选择器不会在「对话」页签上误伤。
          // 不能写 `:has(> [data-dsh-autofork-view])`：本视图挂在 `[data-conversation-scroll]`
          // 里面，是那个内容区的**孙节点**，`>` 匹配不上（实测 display 仍是 block）。
          ':has([data-dsh-autofork-view]) [data-width-handle]{display:none}',
        ].join('')
        document.head.appendChild(element)
      }
      return function () {
        // 只回收本次真正插进去的那一个；别把别人（或上一次 apply）的样式带走。
        if (existing === null || existing === undefined) {
          if (element.parentNode !== null && element.parentNode !== undefined) element.parentNode.removeChild(element)
        }
      }
    }

    /**
     * 「分叉」页签：本会话所在家族的完整家族树，点任意一行切过去。
     *
     * 它取代了原先会话头部右上角那个胶囊下拉（用户 2026-09 决定）：那个位置太窄，
     * 只能显示"现在是谁在回答你"这一个事实；而这条家族树要回答的是一组事实——
     * 家族里有哪几条会话、各自**此刻在干什么**、**分别为什么会分叉出来**（触发指令 + 时间）、
     * 以及**我现在在哪一格**。
     *
     * tab 本身就是原生槽位（`conversation.view` 是个 list 槽，`ui-conversation` 直接遍历
     * 它的条目造 tab 按钮），所以观感与「对话」「轨迹」完全一致，不需要自己造导航。
     * @returns {object} React 元素。
     */
    function BranchView() {
      var pair = React.useState(getSnapshot())
      var setLocal = pair[1]
      React.useEffect(function () {
        return subscribe(function () { setLocal(getSnapshot()) })
      }, [])

      // 相对时间（"3 分钟前"）会随时间变旧，而 store 只在**数据**变化时才通知。
      // 所以自己每 30 秒推一次重渲染：粒度粗到不会看到数字乱跳，也够用来看"这条还在跑多久了"。
      var tickPair = React.useState(0)
      var setTick = tickPair[1]
      // 悬停/聚焦在哪张卡上（`{id, rect}`；null = 没有）。它驱动三件事：那张卡的抬升、
      // **血统聚焦**（祖先链 + 子树高亮，其余淡出）、以及右上角那张**分层详情面板**的定位。
      var hoverPair = React.useState(null)
      var hover = hoverPair[0]
      var setHover = hoverPair[1]

      /**
       * 切换**某一条会话**的自动回注（0.9.0 起按会话独立，不再是家族级）。
       *
       * 乐观更新（点一下立刻反映），失败则回滚并写诊断通道——设置类动作不该让用户盯着
       * "点了没反应"。权威仍是宿主：下一次轮询会带回真实值。
       * @param {string} sessionId 目标会话。
       * @param {boolean} value 目标值。
       */
      var setMuted = function (sessionId, value) {
        var snap = getSnapshot()
        setLocal(Object.assign({}, snap, {
          nodes: (snap.nodes ?? []).map(function (node) {
            return node.sessionId === sessionId ? Object.assign({}, node, { muted: value }) : node
          }),
        }))
      }
      var toggleMute = function (sessionId) {
        var before = (getSnapshot().nodes ?? []).find(function (node) {
          return node.sessionId === sessionId
        })
        var next = !(before !== undefined && before.muted === true)
        setMuted(sessionId, next)
        Promise.resolve(fetch(MUTE_PATH, {
          method: 'POST',
          headers: { 'content-type': 'application/json', [FORK_HEADER]: '1' },
          body: JSON.stringify({ sessionId: sessionId, muted: next }),
        })).then(function (response) {
          if (response === undefined || response.ok !== true) {
            throw new Error('mute-http-' + String(response?.status))
          }
          postNote('mute.set: ' + sessionId + '=' + String(next))
        }).catch(function (error) {
          setMuted(sessionId, !next)
          postNote('mute.failed: ' + String(error))
        })
      }
      /**
       * 卡片上报 hover/focus：连**视口矩形**一起收下——面板是 `position: fixed` 的浮层，
       * 有矩形才能贴在卡的旁边（而不是靠猜画布坐标，滚动/缩放时也不必重算）。
       * @param {string|null} id 会话 id；null = 离开。
       * @param {any} element 触发事件的卡片元素。
       */
      var onHoverCard = function (id, element) {
        if (id === null || element === null || element === undefined
          || typeof element.getBoundingClientRect !== 'function') {
          setHover(null)
          return
        }
        setHover({ id: id, rect: element.getBoundingClientRect() })
      }
      React.useEffect(function () {
        var timer = setInterval(function () { setTick(function (value) { return value + 1 }) }, 30000)
        return function () { clearInterval(timer) }
      }, [])
      var now = Date.now()

      var snap = pair[0]
      var nodes = Array.isArray(snap.nodes) ? snap.nodes : []
      var driver = snap.driver === undefined ? null : snap.driver

      var children = []
      // 错误不塞进 216×104 卡片，也不只写 debug；按节点显示，切页后仍可回来查看。
      nodes.forEach(function (node) {
        var action = takeoverRequests.get(node.sessionId)
        if (action?.error) children.push(React.createElement('div', {
          key: 'takeover-error-' + node.sessionId, role: 'alert',
          style: Object.assign({ fontSize: '12px', overflowWrap: 'anywhere',
            color: 'var(--dsw-alias-state-danger-primary, #c33)' }, COLUMN_STYLE),
        }, action.error))
      })
      if (nodes.length === 0) {
        // 只在"快照此刻没有家族数据"的那一帧出现（切换会话 / 首次轮询未回）。页签本身
        // 只在家族里真有分叉时才注册（见 `familyHasForks`），所以空态不是常态。
        children.push(React.createElement('div', { key: 'loading', style: HINT_STYLE }, t('view.branch.loading')))
      } else {
        var running = nodes.filter(function (node) { return node.state === 'running' }).length
        // 一行说完：几条会话、几条还在跑。原来那句"点任意一行切到那条会话；缩进表示它是从哪条
        // 分出去的"是纯操作说明（用户反馈"文字太多"）——行本身就是按钮、缩进也看得出来，所以
        // 删掉；`还没有分叉` 那句也随页签显隐一起去掉（用户 2026-10：没有分叉时页签根本不出现，
        // 留着的唯一效果是在"切到一条孤立会话"的那一帧里说一句与当前会话不符的话）。
        var summary = [t('view.branch.summary.sessions', { count: nodes.length })]
        if (running > 0) summary.push(t('view.branch.summary.running', { count: running }))
        children.push(React.createElement('div', {
          key: 'summary',
          style: Object.assign({
            display: 'flex',
            alignItems: 'baseline',
            gap: '8px',
            marginBottom: '6px',
          }, COLUMN_STYLE),
        }, [
          React.createElement('div', {
            key: 'a',
            style: { fontWeight: '600', fontSize: '13px', color: TOKEN.labelPrimary },
          }, t('view.branch.title')),
          React.createElement('div', {
            key: 'b',
            style: { color: TOKEN.labelTertiary, fontSize: '12px' },
          }, summary.join(' · ')),
        ]))
        // 树状图：**连线层（SVG）+ 卡片层（绝对定位）**，与 dsh-context 的 subagent 树同一套语法。
        // 连线的端点落在卡片的边中点上，所以布局与卡片必须共用 `TREE` 的度量（改一处就得改另一处）。
        var tree = layoutFamily(nodes)
        var hoverId = hover === null || hover === undefined ? null : hover.id
        var lit = hoverId === null ? null : lineageOf(nodes, hoverId)
        var cards = tree.points.map(function (point) {
          return React.createElement(FamilyNodeCard, {
            key: point.node.sessionId,
            node: point.node,
            point: point,
            driver: driver,
            now: now,
            hovered: hoverId === point.node.sessionId,
            dimmed: lit !== null && !lit.has(point.node.sessionId),
            onToggleMute: toggleMute,
            onHover: onHoverCard,
          })
        })
        // 连线层先建好，再套进画布——层级压平，阅读与改动都不容易数错括号。
        var links = React.createElement('svg', {
          key: 'links',
          width: String(tree.width),
          height: String(tree.height),
          viewBox: '0 0 ' + String(tree.width) + ' ' + String(tree.height),
          // 连线层**永远不吃指针**：卡片在它上面，点卡才是切会话。
          style: { position: 'absolute', inset: '0', pointerEvents: 'none', overflow: 'visible' },
        }, tree.links.map(function (link) {
          var on = lit === null ? true : lit.has(link.to)
          return React.createElement('path', {
            key: link.to,
            d: linkPath(link.x1, link.y1, link.x2, link.y2),
            fill: 'none',
            stroke: link.running
              ? TOKEN.accent
              : 'var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.38))',
            strokeWidth: link.running ? 1.6 : 1.2,
            strokeOpacity: on ? (link.running ? 0.9 : 0.5) : 0.12,
            style: { transition: 'stroke-opacity 120ms ease' },
          })
        }))
        var canvas = React.createElement('div', {
          key: 'canvas',
          style: {
            position: 'relative',
            width: String(tree.width) + 'px',
            height: String(tree.height) + 'px',
            margin: '0 auto',
          },
        }, [links].concat(cards))
        // 悬停那张卡的**分层详情面板**：portal 到 `body`，于是不会被画布的滚动容器裁掉，
        // 横向滚动时也不会跟着画布漂。没有 `react-dom`（非 web 组合）时不出面板——
        // 那时卡片自带原生 `title` 兜底（见 `FamilyNodeCard`）。
        var hoveredNode = null
        if (hoverId !== null) {
          for (var hi = 0; hi < nodes.length; hi += 1) {
            if (nodes[hi].sessionId === hoverId) hoveredNode = nodes[hi]
          }
        }
        if (hoveredNode !== null && reactDom !== undefined
          && typeof reactDom.createPortal === 'function' && typeof document !== 'undefined') {
          children.push(reactDom.createPortal(React.createElement(HoverDetail, {
            key: 'hover-detail',
            node: hoveredNode,
            driver: driver,
            now: now,
            place: hoverPlacement(hover.rect),
          }), document.body))
        }
        children.push(React.createElement('div', {
          key: 'tree',
          // 家族宽了就横向滚动，而不是把卡片压扁 —— 树形要看得清"谁挂在谁下面"，
          // 压缩到看不清从属关系就白换了。
          style: { marginTop: '8px', overflowX: 'auto', overscrollBehaviorX: 'contain' },
        }, canvas))
        // 空态引导**已删**（用户 2026-10：明显是噪声）。它既不是模型可见内容、也不是数据派生标签
        // （同 0.6.2 那条"卡片正文原则"）——这类"解释插件怎么工作"的文案一律不占界面：
        // 摘要行那句 `还没有分叉` 已经把状态说完。
      }

      return React.createElement('div', {
        // **本页签的稳定标记**。`conversation.view` 的各页签共用同一个"会话内容区"，
        // 而官方的**左右拖动宽度手柄**（`[data-width-handle]`）挂在那块共享区域上、
        // 不属于任何一个视图——于是它会跟着出现在本页签上（那根竖线是「对话」页签用来
        // 调内容宽度的，在这里没有任何意义）。官方的处理方式也是 `:has()` 选择器
        // （见 ConversationRoot 的 `.widthHandle{display:none}` 那条），所以这里也用它：
        // 只要本视图还挂载着，就把手柄藏掉。**前提已经实测**：切页签时另一个视图会被
        // 卸载（在「分叉」页签上 `[data-chat-node-key]` 数量为 0），所以这个选择器不会误伤。
        [VIEW_ATTR]: '',
        style: {
          display: 'flex',
          flex: '1 1 auto',
          flexDirection: 'column',
          minHeight: '0',
          overflowY: 'auto',
          // **视图根不再限宽**：树画布要能占满可用宽（见 `COLUMN_STYLE` 的说明），
          // 宽度约束只留给头部与说明文字。
          width: '100%',
          boxSizing: 'border-box',
          padding: '18px 24px 28px',
          fontSize: 'var(--dsw-font-xs-13, 13px)',
          lineHeight: '20px',
          color: TOKEN.labelPrimary,
        },
      }, children)
    }

    /**
     * 切到目标 session（经既有客户端服务；由 apply 注入实现）。
     * @param {string} sessionId 目标。
     */
    var navTo = function () { /* 由 apply 覆盖 */ }

    /* ------------------------------ 插件入口 ------------------------------ */

    /**
     * @param {object} ctx 客户端根上下文。
     */
    exports.apply = function (ctx) {
      var sessions = ctx.get('sessions')
      var slots = ctx.get('slots')
      var uiWorkspace = ctx.get('uiWorkspace')
      if (sessions === undefined) return

      // 界面文案：注册字典并把 `t` 换成官方的活跃绑定（每次调用现取当前语言 ⇒ 切语言
      // 无需重挂载）。走**嵌套** inject：`locale` 缺席的组合里界面保持中文降级，
      // 而不是把整条客户端插件拦掉（严格注入两个方向都会出事，见 SKILL.md Step 2）。
      ctx.inject(['locale'], function (localeCtx) {
        var locale = localeCtx.get('locale')
        if (locale === undefined || typeof locale.bind !== 'function') return
        localeCtx.effect(function () {
          return locale.register(NS, DICTS)
        }, 'dsh-autofork: dictionaries')
        t = locale.bind(NS)
        // 把界面语言回传给 Node half（它的用户可见文案用它选词，见 src/locale.mjs）。
        // 语言切换时立刻重发一次，不等下一次轮询。
        localeCtx.effect(function () {
          var push = function () {
            var snapshot = typeof locale.getSnapshot === 'function' ? locale.getSnapshot() : undefined
            var lang = snapshot && typeof snapshot.active === 'string' ? snapshot.active : 'zh'
            var changed = lang !== activeLang
            activeLang = lang
            relayLanguage(lang)
            // 语言真的变了：让页签重注册一次，官方随即重算 tab 列表（label 每次调用现取）。
            if (changed && typeof onLocaleChanged === 'function') onLocaleChanged()
          }
          push()
          return typeof locale.subscribe === 'function' ? locale.subscribe(push) : undefined
        }, 'dsh-autofork: locale relay')
      })

      /**
       * 切到另一条会话。**唯一入口是 `ctx.uiWorkspace.openSession(target)`。**
       *
       * 0.2.0 起 `ctx.sessions` 只剩"目录 + 引用"（`ISessions` 的文档原话：*Host catalog and
       * local reference-source counts; navigation belongs to view owners*）——`open` /
       * `openSubagent` / `refreshSubagents` 都已不存在。会话选择归视图所有者
       * （`dsh-client-ui-workspace` 的 `UiWorkspaceService`），导航动作是
       * `openSession(target: SessionTarget)`，`target` 是 session id **或** durable 子会话地址
       * （`SessionId | SubagentAddress`）；官方 `ui-subagent` 跳子会话也是这么调的。
       *
       * 在调用点读服务（不在 apply 时把方法抓成闭包变量）：服务可能在 apply 之后才挂上。
       */
      function openSession(target) {
        if (uiWorkspace === undefined || typeof uiWorkspace.openSession !== 'function') {
          report('nav.no-service: uiWorkspace.openSession 不可用')
          return
        }
        uiWorkspace.openSession(target)
      }

      /**
       * 当前**正在显示的**会话 id。
       *
       * 0.2.0 的列表快照里没有 `current` 字段了（`SessionListState` = `{ids, byId, phase,
       * projectionsBySession}`）。"主视图选中了谁"由引用计数表达：`ui-workspace` 用
       * `sessions.retain(target, { source: 'mainView' })` 持有当前会话，于是那一行的
       * `retainedBy.mainView > 0`——这正是官方 `ui-session` 内部判 `isMain()` 的写法：
       * `list.getSnapshot().byId[sessionId]?.retainedBy.mainView > 0`。
       *
       * @returns {string|undefined} 当前会话 id。
       */
      /** 侧栏行元素的锚（官方源码里的 `data-row-key`，值形如 `session:<id>`）。 */
      var ROW_KEY_ATTR = 'data-row-key'

      /** 我们自己插的徽标（只碰带这个属性的节点，从不改官方 DOM 的其它内容）。 */
      var MARK_ATTR = 'data-autofork-mark'

      /**
       * 把「分叉标记」画成侧栏行上的**徽标** —— 用户 2026-10："把'⑂n'作为一个标记，
       * 不属于 session name 字符串的一部分"。
       *
       * 官方**没有**常驻徽标插槽（`sidebar.workspaces.session.row.action` 是悬停才出现的动作区），
       * 所以走**自造缝**（同队列行上的分叉按钮）：按 `[data-row-key="session:<id>"]` 找行，
       * 在**标题之前**插一枚 `⑂n`。三条自我约束：
       *
       *  ① **失败一律是"不出现"**：没有 document / 找不到行 / 结构变了 ⇒ 什么都不做，
       *     绝不动官方 DOM 的其它部分（原因只写进诊断通道）；
       *  ② 只增删**我们自己插的**节点（`data-autofork-mark`），可幂等重复调用；
       *  ③ 旧会话的标题里**已经带** `⑂n ` ⇒ 那种行不插徽标（否则会读成 `⑂1 ⑂1 名字`）。
       * @param {Record<string, number>} marks 会话 id → 序号。
       * @param {string} mark 标记字形（服务端下发；客户端不硬编字形）。
       */
      function syncRowMarks(marks, mark) {
        if (typeof document === 'undefined' || typeof document.querySelectorAll !== 'function') return
        mark = typeof mark === 'string' ? mark : ''
        var wanted = marks !== null && marks !== undefined && typeof marks === 'object' ? marks : {}
        var rows
        try {
          rows = document.querySelectorAll('[' + ROW_KEY_ATTR + ']')
        } catch (error) {
          postNote('mark.query-failed: ' + String(error))
          return
        }
        for (var index = 0; index < rows.length; index += 1) {
          try {
            syncRowMark(rows[index], wanted, mark)
          } catch (error) {
            postNote('mark.row-failed: ' + String(error))
          }
        }
      }

      /**
       * 同步**一行**的徽标（见 {@link syncRowMarks} 的三条约束）。
       * @param {any} row 行元素。
       * @param {Record<string, number>} wanted 会话 id → 序号。
       * @param {string} mark 标记字形。
       */
      function syncRowMark(row, wanted, mark) {
        if (row === null || row === undefined) return
        var key = typeof row.getAttribute === 'function' ? String(row.getAttribute(ROW_KEY_ATTR) ?? '') : ''
        var existing = typeof row.querySelector === 'function' ? row.querySelector('[' + MARK_ATTR + ']') : null
        var sessionId = key.indexOf('session:') === 0 ? key.slice('session:'.length) : ''
        var ordinal = wanted[sessionId]
        var active = sessionId !== '' && mark !== '' && Number.isInteger(ordinal) && ordinal >= 0
        var text = mark + (ordinal === 0 ? '' : String(ordinal))
        // 官方行结构是 `slot / title / time / rowActions` ⇒ 无徽标时标题 = `children[1]`。
        //
        // ⚠️ 有徽标时它**就在 index 1**（我们总插在标题前面）⇒ 标题顺延到 `children[2]`。
        // 踩过的坑：不区分这一步，下一次同步会把**自己的徽标**当成标题读（于是以为"标题已带标记"
        // ⇒ 删掉徽标 ⇒ 插/删来回抖动）。
        var kids = row.children !== undefined && row.children !== null ? row.children : undefined
        var title = kids !== undefined ? kids[1] : undefined
        if (existing !== null && existing !== undefined && title === existing) title = kids[2]
        var titleText = title !== undefined && title !== null ? String(title.textContent ?? '') : ''
        if (active && (titleText === text || titleText.indexOf(text + ' ') === 0)) {
          // 旧会话的标题自带标记 ⇒ 不插徽标（否则重复）。
          if (existing !== null && existing !== undefined) existing.remove()
          return
        }
        if (!active) {
          if (existing !== null && existing !== undefined) existing.remove()
          return
        }
        if (title === undefined || title === null) {
          if (existing !== null && existing !== undefined) existing.remove()
          return
        }
        if (existing !== null && existing !== undefined) {
          if (existing.textContent !== text) existing.textContent = text
          return
        }
        if (typeof document.createElement !== 'function') return
        var badge = document.createElement('span')
        badge.setAttribute(MARK_ATTR, sessionId)
        badge.setAttribute('aria-hidden', 'true')
        badge.textContent = text
        if (badge.style !== undefined && badge.style !== null) {
          Object.assign(badge.style, {
            flex: 'none',
            marginRight: '6px',
            padding: '0 5px',
            height: '18px',
            lineHeight: '18px',
            borderRadius: '5px',
            fontSize: '11.5px',
            fontWeight: '600',
            background: 'rgba(11, 107, 203, 0.12)',
            color: TOKEN.accent,
            userSelect: 'none',
          })
        }
        if (typeof row.insertBefore === 'function') row.insertBefore(badge, title ?? null)
      }

      function currentSessionId() {
        // 唯一的**可达**来源：`sessions.list` 的 `retainedBy.mainView`。
        //
        // 曾经想换成"工作区的 selection 存储"，那是错的：`selection` 是
        // `dsh-client-ui-workspace` 里的**模块级变量**，不在服务面上
        // （`ctx.get('uiWorkspace')` 的 own keys 只有 `ctx|name|directoryPicker|workspaces|
        // sessions|connecting`）⇒ 读不到，页签会整个空掉（实测踩过）。
        //
        // 那条"引用计数窗口里会选到旧会话"的担心也不成立：工作区 `replaceMain` 里的
        // `retain(新)` → `selection.set` → `release(旧)` 是**同一个同步块**，而 JS 单线程
        // ⇒ 外部的异步轮询**观察不到中间态**，稳定的不变量是"**最多一条**会话的
        // `mainView > 0`"。所以这里只是读它；万一不变量被破（宿主改了实现），
        // 通过诊断通道报一行 `current.multiple`，而不是自己发明一个猜法。
        var snap = sessions.list.getSnapshot()
        var rows = snap === undefined || snap === null ? undefined : snap.byId
        if (rows === undefined || rows === null) return undefined
        var ids = Object.keys(rows)
        var visible = []
        for (var index = 0; index < ids.length; index += 1) {
          var row = rows[ids[index]]
          var retained = row === undefined || row === null ? undefined : row.retainedBy
          if (retained !== undefined && retained !== null && (retained.mainView ?? 0) > 0) visible.push(ids[index])
        }
        if (visible.length > 1) postNote('current.multiple: ' + visible.join(','))
        return visible.length === 0 ? undefined : visible[0]
      }

      /**
       * 一条子会话的 durable 父地址（形状 `{parentSessionId, childSessionId, mode}`）。
       *
       * 数据源是 `sessions.subagentAddress(childId)`：它先看客户端**已保留/已解析**的地址，
       * 再扫各会话已加载的 `subagentCatalog` 投影。投影没加载时返回 undefined——所以调用方
       * 先 `refreshProjections(parentId)`（见 `openAddressed`）。
       *
       * @param {string} childId 子会话 id。
       * @returns {object|undefined} 地址，或 undefined（不是子会话 / catalog 还没加载）。
       */
      function subagentAddressOf(childId) {
        try {
          if (typeof sessions.subagentAddress !== 'function') return undefined
          var address = sessions.subagentAddress(childId)
          return address === undefined || address === null ? undefined : address
        } catch (error) {
          report('nav.address-threw: ' + String(error))
          return undefined
        }
      }

      /**
       * 打开一条会话，**按它的寻址方式**打开。
       *
       * subagent 会话（容器模式下的分叉会话）不能用普通 session 地址打开——宿主
       * `validateAddress()` 对 `address.kind === 'session'` 且 `header.origin === 'subagent'`
       * 直接抛 `session/agent-busy`。所以先 `refreshProjections(parentSessionId)` 把父会话的
       * 投影（含 `subagentCatalog`）拉进客户端，再 `subagentAddress(childId)` 派生地址；
       * 派生得到就把**地址**交给 `openSession`（`SessionTarget` 允许地址），否则按普通
       * 顶层会话开。扁平分叉（默认）的 head 本来就是普通会话，走的就是后者。
       *
       * @param {string} sessionId 目标会话。
       * @param {string|undefined} parentSessionId 已知的直接父会话（分叉交付时服务端会给）。
       * @returns {Promise<void>} 打开完成。
       */
      function openAddressed(sessionId, parentSessionId) {
        var anchor = parentSessionId !== undefined ? parentSessionId : currentSessionId()
        var loadProjections = anchor === undefined || typeof sessions.refreshProjections !== 'function'
          ? Promise.resolve()
          : Promise.resolve(sessions.refreshProjections(anchor)).catch(function (error) {
            report('catalog.refresh-failed: ' + String(error))
          })
        return loadProjections.then(function () {
          var address = subagentAddressOf(sessionId)
          if (address !== undefined) {
            openSession(address)
            report('nav.subagent: ' + sessionId + ' via ' + String(address.parentSessionId)
              + ' mode=' + String(address.mode))
            return
          }
          openSession(sessionId)
          report('nav.plain: ' + sessionId + ' (no subagent address)')
        })
      }


      /**
       * 报告某个对象的实际形状——取不到方法时用它一次定位，不必再猜。
       * @param {string} label 标记。
       * @param {any} value 被检查的对象。
       * @returns {string} 形状描述。
       */
      function shapeOf(label, value) {
        try {
          var own = Object.keys(value === null || value === undefined ? {} : value)
          var proto = value === null || value === undefined
            ? []
            : Object.getOwnPropertyNames(Object.getPrototypeOf(value)).slice(0, 24)
          return label + ': type=' + typeof value
            + ' own=[' + own.slice(0, 12).join('|') + ']'
            + ' proto=[' + proto.join('|') + ']'
        } catch (error) {
          return label + ': shape-failed ' + String(error)
        }
      }

      var timer = null
      var stopped = false
      /** 本插件注入的样式表卸载函数（见 installForkStyles）。 */
      var styles = null
      var cardStyles = null

      navTo = function (sessionId) {
        if (typeof sessionId !== 'string' || sessionId === '') return
        // 与交付路径同样要先 refresh：目标 session 可能还没进客户端列表
        Promise.resolve()
          .then(function () { return sessions.refresh() })
          .catch(function (error) { report('nav.refresh-failed: ' + String(error)) })
          .then(function () { return openAddressed(sessionId, undefined) })
          .then(function () { report('nav.ok: ' + sessionId) })
          .catch(function (error) {
            report('nav.threw: ' + String(error) + ' || ' + shapeOf('sessions', sessions))
          })
      }

      /** 停掉轮询。 */
      function stopPolling() {
        if (timer === null) return
        clearInterval(timer)
        timer = null
      }

      /**
       * 向服务端回报一句（落进决策日志）。客户端 half 跑在浏览器里，
       * 没有这条通道时它的任何失败都是纯黑盒。
       * @param {string} note 回报内容。
       */
      function report(note) {
        postNote(note)
      }

      /**
       * 交付一条分叉：先刷新列表，再切焦点，**验证真的切过去了**才 ack。
       *
       * 验证读的是"当前显示的是哪条会话"（`retainedBy.mainView`，见 `currentSessionId`）——
       * `uiWorkspace.openSession` 是同步发起、异步打开的，只有这一读能确认它落地了。
       * 没切成就不 ack，下次轮询服务端会再提供同一条，自动重试。
       * @param {string} branchId 目标分叉 session id。
       */
      function deliver(branchId, parentSessionId) {
        Promise.resolve()
          .then(function () { return sessions.refresh() })
          .catch(function (error) { report('refresh.failed: ' + String(error)) })
          .then(function () {
            return openAddressed(branchId, parentSessionId)
          })
          .catch(function (error) {
            report('openSession.threw: ' + String(error) + ' || ' + shapeOf('sessions', sessions))
          })
          .then(function () {
            var current = currentSessionId()
            if (current === branchId) {
              report('handoff.delivered: ' + branchId)
              fetch(HEALTH_PATH + '?client=1&ack=' + encodeURIComponent(branchId), {
                headers: { accept: 'application/json' },
              }).catch(function () {})
              // **不停轮询**：ack 已让服务端不再重复提供这条交付，而分叉关系 UI
              // 还需要持续的状态。停止轮询只会让 UI 冻结。
            } else {
              // 没切成：**不 ack**，下次轮询服务端会再提供同一条，自动重试
              report('handoff.pending: want=' + branchId + ' current=' + String(current))
            }
          })
      }

      /**
       * 问一次服务端：分叉关系 + 待交付的分叉。
       * @param {string} sessionId 当前打开的 session。
       */
      function poll(sessionId) {
        if (stopped) return
        var url = HEALTH_PATH + '?client=1&consume=1&lang=' + relayedLang + '&sessionId=' + encodeURIComponent(sessionId)
        fetch(url, { headers: { accept: 'application/json' } })
          .then(function (response) { return response.ok ? response.json() : undefined })
          .then(function (body) {
            if (stopped || body === undefined || body.ok !== true) return
            syncRowMarks(body.marks, body.mark)
            // 每次轮询顺带同步一次侧栏徽标：publish 只在**数据变化**时通知，
            // 而"新滚出来的行"没有任何事件 ⇒ 必须按 tick 兜一次（一次 querySelectorAll，很轻）。
            publish({
              current: sessionId,
              // 服务端算好的家族**链条**（根 → 最新，含本会话自己）：`title` / `state` /
              // `depth` / `current` / `parentId`。`state` 是互斥三态（running|idle|finished）
              // ——不再是"agent 在不在"和"忙不忙"两个含义不同的字段并排。
              nodes: Array.isArray(body.nodes) ? body.nodes : [],
              // 服务端算好的"当前 driver"（链上最新的 head，没有下游就是本会话）。
              driver: body.driver === undefined ? null : body.driver,
              // 服务端**此刻生效**的分叉方式：手动模式下队列行才有「分叉」按钮。
              // 以服务端为准（而不是读设置文档），所以按钮不会出现在宿主不照它行事的时候。
              mode: body.mode === 'manual' ? 'manual' : 'auto',
              /**
               * **分叉标记表**（`{会话 id: 序号}`）与字形：用来把标记画成侧栏行上的**徽标**，
               * 而不是塞进 session name 字符串（用户 2026-10）。
               */
              marks: body.marks !== null && typeof body.marks === 'object' ? body.marks : {},
              mark: typeof body.mark === 'string' ? body.mark : '',
            })
            var handoff = body.handoff
            // 字段名必须与服务端一致：链式模型重写时服务端改成了 `sessionId`
            // （headId），客户端没跟着改 → 上一版在这里静默 early return，
            // 于是"分叉成功但不切焦点"（实测踩到，决策日志里 handoff 一直在返回
            // 却没有任何 handoff.delivered / openSession.threw 回报）。
            if (handoff === null || handoff === undefined) return
            var headId = typeof handoff.sessionId === 'string' ? handoff.sessionId : undefined
            if (headId === undefined) {
              report('handoff.unknown-shape: ' + JSON.stringify(handoff))
              return
            }
            // `parentSessionId` 是服务端给的**直接父会话**：子会话的寻址地址要从它的
            // subagent catalog 派生，见 openAddressed()。
            var parentId = typeof handoff.parentSessionId === 'string'
              ? handoff.parentSessionId
              : undefined
            deliver(headId, parentId)
          })
          .catch(function (error) { report('poll.failed: ' + String(error)) })
      }

      /** 按当前会话取一次数据。 */
      function tick() {
        if (stopped) return
        var current = currentSessionId()
        if (current === undefined || current === null) {
          publish({ current: undefined, nodes: [], driver: null, mode: 'auto' })
          return
        }
        poll(current)
      }

      // **不把启动押在订阅上**。实测：页面在"尚无当前会话"时加载，之后选中会话
      // 并没有触发 `sessions.list.subscribe` 的回调，于是轮询一次都没跑
      // （决策日志里 `slot.mounted` 有、`health.request` 为 0）。改成无条件定时
      // tick，每次重新读 current——少一个无法验证的契约。
      timer = setInterval(tick, POLL_MS)
      tick()

      // 「分叉」页签：`conversation.view` 是 **list 槽**，`ui-conversation` 直接遍历它的
      // 条目造 tab 按钮（`{id, label}`，`order` 决定左右位置），官方「轨迹」就是这么注册的
      // （`id:'trajectory', order:10`）。所以这里注册出来的 tab 与「对话」「轨迹」完全同族，
      // 不需要自己造导航，也不碰任何我无法在服务端验证的私有契约。
      //
      // **家族里没有分叉就不注册这一条**（用户 2026-10："当 session 没有 fork 时，应该隐藏
      // 「分叉」页签"）。一条孤立会话没有家族可讲，常驻一个空页签只是噪声。做法是让**这一条
      // list 条目**跟着快照注册 / 注销：官方自己订阅 `conversation.view` 的变更重算 tab 列表
      // （`ui-conversation` 的 `refreshViews`），所以显隐不需要碰任何官方 DOM，也不必在这边
      // 维护第二套"可见性"状态。代价是切换会话后最多晚一个轮询周期（≤1s）才收起页签。
      //
      // 组件的状态全部来自本模块的 store（轮询写入），**不读槽位 props**：少依赖一个契约，
      // 就少一处只能在浏览器里才暴露的失败模式。
      if (slots !== undefined) {
        slots.inject('conversation.view', function () {
          /** 已注册条目的卸载函数；null = 此刻没有页签。 */
          var disposeEntry = null
          /**
           * 让页签存在与否跟上快照。只在**真的翻转**时动槽（注册会触发官方重算整张 tab 列表）。
           */
          var sync = function () {
            var want = familyHasForks(getSnapshot())
            if (want === (disposeEntry !== null)) return
            if (want) {
              disposeEntry = slots.register({
                name: 'conversation.view',
                id: 'branch',
                order: 20,
                label: function () { return t('view.tab.branch') },
                inject: function () { return {} },
              }, BranchView)
              report('view.shown')
            } else {
              disposeEntry()
              disposeEntry = null
              report('view.hidden')
            }
          }
          // 语言切换 → 重注册一次该条目（官方只认槽变更才会重算 tab 列表，见 onLocaleChanged）。
          onLocaleChanged = function () {
            if (disposeEntry === null) return
            disposeEntry()
            disposeEntry = null
            sync()
          }
          var unsubscribe = subscribe(sync)
          sync()
          return function () {
            onLocaleChanged = null
            unsubscribe()
            if (disposeEntry !== null) {
              disposeEntry()
              disposeEntry = null
            }
          }
        })

        // 手动分叉的「分叉」按钮：注册进 `conversation.input.dock`（list 槽，与官方队列条 /
        // 任务条同一列），但组件本身**不画在这一列里**——它把按钮用 portal 挂进队列那一行
        // 右侧（见 ForkDock 的注释：队列行的动作区是官方写死的，插件没有那个槽）。
        slots.inject('conversation.input.dock', function () {
          report('forkdock.mounted')
          return slots.register({
            name: 'conversation.input.dock',
            id: 'fork',
            order: 21,
            inject: function () { return {} },
          }, ForkDock)
        })

        // 消息卡：分叉通知 / 在飞摘要 / 后台回传三条长成官方那种卡片。
        // inbox 消息未被官方触发卡接管时，由本模块渲染，见 CARD_KIND。
        cardStyles = registerAutoforkCards(ctx, slots)

        // Plugins 页上本插件的设置卡片（分叉方式）。走嵌套 inject，见 registerForkSettings。
        registerForkSettings(ctx, slots)
      }

      // 队列行上那个按钮要 `:hover`，内联样式表达不了——注入一小段样式，卸载时收回。
      styles = installForkStyles()

      /* ------------------- 从头部胶囊改为页签（2026-09，用户决定） ------------------- */

      // 之前这里注册的是 `conversation.session.header.utilities` 里的一个胶囊下拉
      // （「driver：分叉 xxxx」/「容器：本会话 · 后台 N 条」）。用户实测后的结论是
      // **取消右上角那个 UI**：那个位置只能承载一个事实，而真正要回答的是一组事实
      // （有哪些会话、各自什么状态、我在哪一格）。现在由上面的「分叉」页签承载。
      //
      // 顺带说明为什么**不**用原生血脉槽位 `conversation.session.header.lineage` 来完成
      // 这件事：它是 **single** 槽，已被 `ui-subagent` 占用，第二次注册会直接抛
      // `single slot "…" already has a registration`（在 ui-slots 源码里核过）。
      //
      // 另外记一笔（免得后人重走）：`conversation.view` 上曾经挂过一个探路用的「容器」页签，
      // 目标是"在一条会话的视图里渲染另一条会话的原生转写"。那条路已实证走不通
      // （`dsh-client-ui-chat/client` 不导出转写渲染器、`ConversationViewRegistry` 没有
      // 跨 session 派发的 API、`page`/`follow` 两个 RPC 都是 session-addressed）。
      // 现在的「分叉」页签**不渲染别的会话的转写**，只画关系 + 负责跳转，所以不受那条结论影响。
      // 原生转写不可跨会话内嵌；此处只展示关系并跳转。

      ctx.effect(function () {
        return function () {
          stopped = true
          stopPolling()
          syncRowMarks({}, '')
          if (styles !== null) {
            styles()
            styles = null
          }
          if (cardStyles !== null) {
            cardStyles()
            cardStyles = null
          }
        }
      }, 'dsh-autofork: 分叉关系 UI 与交付轮询')
    }

    return exports
  },
})
