/**
 * prompt-seed 单元测试
 * 运行：npm test
 */

import assert from "node:assert/strict";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { Readable } from "node:stream";
import { test } from "node:test";
import { fileURLToPath } from "node:url";

import {
  DEFAULT_DEADLINE_MS,
  ERROR_CODES,
  assessInflation,
  collectStream,
  createOptimizerMessage,
  isSubstantivelyUnchanged,
  looksOpenEnded,
  isContentFree,
  isPreciseInstruction,
  preservesAnchors,
  looksSeedish,
  optimizePromptText,
  parseAuditVerdict,
  resolveRoute,
} from "../src/host-core.js";
import {
  AUDIT_SYSTEM_TEMPLATE,
  DEPTH_DEEP_SUFFIX,
  DEPTH_LIGHT_SUFFIX,
  DEPTH_STANDARD_SUFFIX,
  MAX_TEXT_LENGTH,
  PRECISE_SUFFIX,
  REPAIR_SUFFIX,
  SYSTEM_SUFFIX,
  SYSTEM_TEMPLATE,
  USER_TEMPLATE,
  buildSystemPrompt,
  buildSystemPromptFor,
  depthSuffix,
  detectScript,
  normalizeResult,
  renderAuditUserPrompt,
  renderContextBlock,
  renderUserPrompt,
  setTemplateOverrides,
  stripCodeFence,
  stripLeadingLabel,
  stripWrappingQuotes,
  validateInput,
} from "../src/prompt-templates.js";
import { extractRecentContext, needsContext } from "../src/session-context.js";
import { appendSample, resolveSamplePath } from "../src/sample-log.js";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");

/** 构造一个按脚本吐 chunk 的假 llm 服务。 */
function fakeLlm(chunks) {
  const seen = [];
  return {
    seen,
    stream(options) {
      seen.push(options);
      return (async function* generate() {
        for (const chunk of chunks) yield chunk;
      })();
    },
  };
}

/** 把一段文本包装成一次成功的模型响应。 */
function textChunks(text) {
  return [{ type: "text-delta", index: 0, text }, { type: "finish", reason: { kind: "stop" } }];
}

/**
 * 按调用次序回放不同响应的假 llm：responses[i] 是第 i+1 次调用的 chunk 序列，
 * 用尽后重复最后一组。保真闸门会连续发起改写/审判/重跑多次调用，需要这种脚本。
 */
function scriptedLlm(responses) {
  const seen = [];
  return {
    seen,
    stream(options) {
      seen.push(options);
      const chunks = responses[Math.min(seen.length - 1, responses.length - 1)];
      return (async function* generate() {
        for (const chunk of chunks) yield chunk;
      })();
    },
  };
}

const ROUTE = { provider: "test", model: "test-model" };

// --------------------------------------------------------------------------
// prompt-templates
// --------------------------------------------------------------------------

test("stripWrappingQuotes 去掉成对的首尾引号", () => {
  assert.equal(stripWrappingQuotes('"hello world"'), "hello world");
  assert.equal(stripWrappingQuotes("“你好”"), "你好");
  assert.equal(stripWrappingQuotes("'quoted'"), "quoted");
  assert.equal(stripWrappingQuotes("「引用」"), "引用");
});

test("stripWrappingQuotes 不动不成对或内部引号", () => {
  assert.equal(stripWrappingQuotes('he said "hi" loudly'), 'he said "hi" loudly');
  assert.equal(stripWrappingQuotes('"unbalanced'), '"unbalanced');
  assert.equal(stripWrappingQuotes(""), "");
});

test("stripCodeFence 去掉 markdown 围栏", () => {
  assert.equal(stripCodeFence("```\ninner\n```"), "inner");
  assert.equal(stripCodeFence("```text\ninner\n```"), "inner");
  assert.equal(stripCodeFence("no fence"), "no fence");
});

test("stripLeadingLabel 去掉模型自加的前缀", () => {
  assert.equal(stripLeadingLabel("Enhanced prompt: do X"), "do X");
  assert.equal(stripLeadingLabel("优化后的提示词：做 X"), "做 X");
  assert.equal(stripLeadingLabel("普通文本"), "普通文本");
});

test("normalizeResult 组合清洗：围栏 + 引号 + 标签", () => {
  const raw = '```\nEnhanced prompt: "帮我写一个单元测试"\n```';
  assert.equal(normalizeResult(raw), "帮我写一个单元测试");
});

test("validateInput 覆盖空、超长、正常", () => {
  assert.equal(validateInput(""), "empty_input");
  assert.equal(validateInput("   "), "empty_input");
  assert.equal(validateInput(undefined), "empty_input");
  assert.equal(validateInput(42), "empty_input");
  assert.equal(validateInput("x".repeat(MAX_TEXT_LENGTH + 1)), "input_too_long");
  assert.equal(validateInput("正常输入"), null);
});

test("detectScript 区分中英混排", () => {
  assert.equal(detectScript("帮我看看这段代码"), "cjk");
  assert.equal(detectScript("explain this code"), "latin");
  assert.equal(detectScript("这段代码有 bug，can you help"), "mixed");
  assert.equal(detectScript("   "), "unknown");
  assert.equal(detectScript("12345 !!!"), "unknown");
});

test("renderUserPrompt 正确插值且保留模板主体", () => {
  const rendered = renderUserPrompt("帮我看看这个登录接口有没有问题");
  assert.ok(rendered.includes("帮我看看这个登录接口有没有问题"));
  assert.ok(rendered.includes("Language. This outranks everything else on this page."));
  assert.ok(!rendered.includes("{input}"));
  // 无上下文时不出现 CONTEXT 段
  assert.ok(!rendered.includes("CONTEXT"));
});

test("renderContextBlock：上下文块渲染与防御", () => {
  const context = [
    { role: "user", text: "登录接口有时候 500" },
    { role: "assistant", text: "看起来是 token 校验的边界情况" },
  ];
  const withContext = renderUserPrompt("帮我修一下这个", context);
  assert.ok(withContext.includes("CONTEXT (recent conversation; use ONLY to resolve what the request refers to):"));
  assert.ok(withContext.includes("[user] 登录接口有时候 500"));
  assert.ok(withContext.includes("[assistant] 看起来是 token 校验的边界情况"));
  assert.ok(withContext.includes("帮我修一下这个"));
  // CONTEXT 在 REQUEST 之前（先指代来源，后请求本体）
  assert.ok(withContext.indexOf("CONTEXT") < withContext.indexOf("REQUEST:"));
  // 审判 prompt 同样携带上下文（蕴含判定需要知情指代来源）
  assert.ok(renderAuditUserPrompt("a", "b", context).includes("[user] 登录接口有时候 500"));
  // 非法形状静默降级为空
  assert.equal(renderContextBlock(undefined), "");
  assert.equal(renderContextBlock([]), "");
  assert.equal(renderContextBlock([{ role: "user", text: "   " }]), "");
});

test("两条模板各自独立声明语言一致性（设计原则 ①）", () => {
  // 中英混排产品里模型极易把中文输入改写成英文；单处声明压不住，必须各写一次。
  assert.ok(SYSTEM_TEMPLATE.includes("This rule outranks every other instruction"));
  assert.ok(USER_TEMPLATE.includes("This outranks everything else on this page"));
  assert.ok(USER_TEMPLATE.includes("Never name the language"));
});

test("混排语言规则不自相矛盾", () => {
  // 回归守卫：早期版本写着"不要翻译任何部分"，但模型对混排输入会把连接语句
  // 归并到主导语言——这是更好的行为，矛盾在规则不在模型。规则已改为
  // "保留术语 + 连接语句用主导语言"，此处锁死，避免回退。
  assert.ok(!USER_TEMPLATE.includes("Do not translate any part of it"));
  assert.ok(!SYSTEM_TEMPLATE.includes("Do not flatten it into one language"));
  assert.ok(USER_TEMPLATE.includes("do not move it into a different single language"));
  assert.ok(SYSTEM_TEMPLATE.includes("do not move the request into a different single language"));
  // 混排示例必须保留用户用的术语
  assert.ok(USER_TEMPLATE.includes("这个函数有 bug"));
});

test("模板禁止一切 meta 内容与作答（设计原则 ②③）", () => {
  assert.ok(SYSTEM_TEMPLATE.includes("You never carry out the request itself"));
  assert.ok(SYSTEM_TEMPLATE.includes("Answer the request, even partially"));
  assert.ok(USER_TEMPLATE.includes("Contain answers. When REQUEST asks a question, return a better question"));
  assert.ok(USER_TEMPLATE.includes("no code fence, no surrounding quotation marks"));
  assert.ok(SYSTEM_SUFFIX.includes("never an answer"));
});

test("补全契约：补全中间细节是产品本体，曲解才是红线（设计原则 ④）", () => {
  // v0.6 核心界线
  assert.ok(SYSTEM_TEMPLATE.includes("ELABORATE, NEVER DISTORT"));
  assert.ok(SYSTEM_TEMPLATE.includes("this is the product, not a risk"));
  assert.ok(SYSTEM_TEMPLATE.includes("KEEP EXACTLY AS THEY MEANT IT"));
  assert.ok(SYSTEM_TEMPLATE.includes("NEVER (each of these distorts the request)"));
  // 补全深度跟随"用户没说多少"
  assert.ok(SYSTEM_TEMPLATE.includes("Depth scales with what was left unsaid"));
  assert.ok(SYSTEM_TEMPLATE.includes("A bare seed grows a lot"));
  // 两侧旧病都不得回退
  assert.ok(!SYSTEM_TEMPLATE.includes("ENTAILMENT vs INVENTION"), "v0.3 蕴含契约已被补全契约取代");
  assert.ok(
    !SYSTEM_TEMPLATE.includes("Do not introduce a language, framework, library, or tool the user did not mention"),
    "禁止新增技术栈的旧红线已废除：为开放选择给具体默认值属于补全",
  );
  assert.ok(!SYSTEM_TEMPLATE.includes("IF IN DOUBT, CHANGE LESS"), "无条件少改指令已废除");
  assert.ok(!SYSTEM_TEMPLATE.includes("roughly 800 characters"), "长度配额已废除");
});

test("用户已做的选择不得被覆盖（新红线）", () => {
  assert.ok(SYSTEM_TEMPLATE.includes("Never override, replace, or drop one"));
  assert.ok(USER_TEMPLATE.includes("Contradict a choice the user made"));
  assert.ok(AUDIT_SYSTEM_TEMPLATE.includes("CONTRADICTED"));
});

test("语气是契约的一部分（新红线）", () => {
  assert.ok(SYSTEM_TEMPLATE.includes("Their voice. A casual message stays casual"));
  assert.ok(SYSTEM_SUFFIX.includes("Keep the user's voice"));
  assert.ok(AUDIT_SYSTEM_TEMPLATE.includes("TONE_SHIFTED"));
});

test("范围开放的保护写进了模板（设计原则 ⑥）", () => {
  // 不得替用户选类别 / 不得闭合开放范围
  assert.ok(SYSTEM_TEMPLATE.includes('must not become "security problems"'));
  assert.ok(USER_TEMPLATE.includes('"Any problems?" stays open across all kinds of problems'));
  assert.ok(USER_TEMPLATE.includes("Keep the breadth REQUEST set"));
});

test("示例区是三段对照：TOO PASSIVE / RIGHT / WRONG 同时画两条边界（设计原则 ⑦）", () => {
  // 下边界：原样返回是失职（v0.3–v0.5 的病），必须作为反例教学
  assert.ok(USER_TEMPLATE.includes("TOO PASSIVE - fails the user"));
  assert.ok(USER_TEMPLATE.includes("the seed came back"));
  // 上边界：曲解（v0.1 的病），必须以反例身份出现并解释为什么错
  assert.ok(USER_TEMPLATE.includes("WRONG - distorts the request"));
  assert.ok(USER_TEMPLATE.includes("a different and much bigger product"));
  assert.ok(USER_TEMPLATE.includes("rank them by expected impact"));
  // RIGHT 侧：补全到细节的正例（而不是旧的"展开蕴含为止"正例）
  assert.ok(USER_TEMPLATE.includes("帮我做一个导出报表功能："));
  assert.ok(USER_TEMPLATE.includes("near-unchanged is CORRECT"));
  // 已明确指令的"加戏"必须作为反例出现（v0.6.0 线上实测病征）
  assert.ok(USER_TEMPLATE.includes("WRONG - over-elaboration"));
  assert.ok(USER_TEMPLATE.includes("the added procedure and failure clause are padding, not help"));
  // meta 泄漏反例保留（旧守卫）
  assert.ok(USER_TEMPLATE.includes("WRONG - this leaks meta text"));
  assert.ok(USER_TEMPLATE.includes("RIGHT:"));
  assert.ok(USER_TEMPLATE.includes("Input:"));
});

test("长度约束：长度跟随补全，不设配额也不压缩", () => {
  assert.ok(SYSTEM_TEMPLATE.includes("Length follows the elaboration"));
  assert.ok(!SYSTEM_TEMPLATE.includes("Length follows the entailment"), "旧的蕴含长度规则已废除");
  // 两侧旧病都不得回退
  assert.ok(!SYSTEM_TEMPLATE.includes("Stay close to the input's own length"), "v0.2 压缩指令已废除");
  assert.ok(!USER_TEMPLATE.includes("Stay close to REQUEST's own length"), "v0.2 压缩指令已废除");
});

test("buildSystemPromptFor 只在有脚本信息时追加语言提示", () => {
  assert.ok(buildSystemPromptFor("explain this code").includes("predominantly Latin script"));
  assert.ok(buildSystemPromptFor("解释这段代码").includes("predominantly CJK"));
  assert.ok(!buildSystemPromptFor("1234").includes("Language check"));
});

// --------------------------------------------------------------------------
// session-context
// --------------------------------------------------------------------------

test("extractRecentContext：只取真实用户话轮，跳过注入与噪声", () => {
  const surface = {
    events: [
      { type: "turn/start" },
      { type: "user/message", data: { role: "user", source: { kind: "user" }, content: [{ type: "text", text: "现有的项目包是有一些问题的" }] } },
      // 注入快照（runtime-context）：source.kind 区分，绝不能进入上下文
      { type: "user/message", data: { role: "user", source: { kind: "runtime-context" }, content: [{ type: "text", text: "Current runtime context. This snapshot supersedes..." }] } },
      { type: "user/message", data: { role: "user", source: { kind: "time-context" }, content: [{ type: "text", text: "Time sampled while preparing turn..." }] } },
      // agent 会话尾部的典型噪声：assistant 步骤消息与工具结果
      { type: "assistant/message", data: { message: { role: "assistant", content: [{ type: "text", text: "会话 id 格式正确。" }] } } },
      { type: "tool/result", data: { message: { role: "tool", content: [] } } },
      { type: "user/message", data: { role: "user", source: { kind: "user" }, content: [{ type: "text", text: "没问题，act。" }] } },
    ],
  };
  const context = extractRecentContext(surface);
  // 只取真实用户话轮，最近 2 条，时间正序
  assert.deepEqual(context, [
    { role: "user", text: "现有的项目包是有一些问题的" },
    { role: "user", text: "没问题，act。" },
  ]);
  // 注入快照与 assistant 步骤绝不出现
  const joined = JSON.stringify(context);
  assert.ok(!joined.includes("runtime context"), "注入快照不得进入上下文");
  assert.ok(!joined.includes("会话 id"), "assistant 步骤噪声不得进入上下文");

  // 超长话轮截断
  const long = "x".repeat(500);
  const truncated = extractRecentContext({
    events: [{ type: "user/message", data: { role: "user", source: { kind: "user" }, content: [{ type: "text", text: long }] } }],
  });
  assert.equal(truncated[0].text.length, 301);
  assert.ok(truncated[0].text.endsWith("…"));

  // 旧形状兼容：无 source 字段的真实消息仍可提取（kind === undefined 不视为注入）
  assert.deepEqual(
    extractRecentContext({ events: [{ type: "user/message", data: { role: "user", content: "纯文本输入" } }] }),
    [{ role: "user", text: "纯文本输入" }],
  );

  // 防御降级：形状漂移、空事件、非对象一律 undefined
  assert.equal(extractRecentContext(undefined), undefined);
  assert.equal(extractRecentContext(null), undefined);
  assert.equal(extractRecentContext({}), undefined);
  assert.equal(extractRecentContext({ events: [] }), undefined);
  assert.equal(extractRecentContext({ events: [{ type: "user/message", data: null }] }), undefined);
  // 只剩注入消息时等于无上下文
  assert.equal(
    extractRecentContext({ events: [{ type: "user/message", data: { role: "user", source: { kind: "time-context" }, content: [{ type: "text", text: "Time sampled..." }] } }] }),
    undefined,
  );
});

// --------------------------------------------------------------------------
// 拒绝样本落盘
// --------------------------------------------------------------------------

test("resolveSamplePath：默认落 DSH_HOME，字符串自定义，false 关闭", () => {
  const previous = process.env.DSH_HOME;
  try {
    process.env.DSH_HOME = "/tmp/dsh-home-test";
    assert.equal(resolveSamplePath(undefined), "/tmp/dsh-home-test/prompt-seed/samples.jsonl");
    assert.equal(resolveSamplePath("/tmp/custom.jsonl"), "/tmp/custom.jsonl");
    assert.equal(resolveSamplePath(false), null, "samples:false 完全关闭采样");
  } finally {
    if (previous === undefined) delete process.env.DSH_HOME;
    else process.env.DSH_HOME = previous;
  }
});

test("appendSample：写入 JSONL 并截断超长输入，失败静默", async () => {
  const dir = await mkdtemp(join(tmpdir(), "po-samples-"));
  const file = join(dir, "nested", "samples.jsonl");
  try {
    const long = "x".repeat(5000);
    assert.equal(await appendSample(file, { time: "t", code: "fidelity_rejected", input: long, added: ["a"] }), true);
    const lines = (await readFile(file, "utf8")).trim().split("\n");
    assert.equal(lines.length, 1);
    const record = JSON.parse(lines[0]);
    assert.equal(record.input.length, 4000, "超长输入必须截断");
    assert.deepEqual(record.added, ["a"]);

    // 再追加一条：JSONL 是追加语义
    await appendSample(file, { time: "t2", code: "fidelity_rejected", input: "短", added: [] });
    assert.equal((await readFile(file, "utf8")).trim().split("\n").length, 2);

    // 非法路径：返回 false，不抛
    assert.equal(await appendSample("", { input: "x" }), false);
    assert.equal(await appendSample(null, { input: "x" }), false);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

// --------------------------------------------------------------------------
// host-core
// --------------------------------------------------------------------------

test("collectStream 拼接 text-delta 并识别终止失败", async () => {
  const ok = await collectStream(
    (async function* g() {
      yield { type: "block-start", index: 0, blockType: "text" };
      yield { type: "text-delta", index: 0, text: "abc" };
      yield { type: "text-delta", index: 0, text: "def" };
      yield { type: "finish", reason: { kind: "stop" } };
    })(),
  );
  assert.equal(ok.text, "abcdef");
  assert.equal(ok.failure, null);
  assert.equal(ok.finish, "stop");

  const failed = await collectStream(
    (async function* g() {
      yield { type: "text-delta", index: 0, text: "partial" };
      yield { type: "finish", reason: { kind: "error", failure: { code: "rate_limit", message: "429" } } };
    })(),
  );
  assert.equal(failed.text, "partial");
  assert.equal(failed.failure.message, "429");
});

test("createOptimizerMessage 形状满足 Message 契约", () => {
  const message = createOptimizerMessage("hello");
  assert.equal(message.role, "user");
  assert.equal(message.source.kind, "plugin");
  assert.equal(message.content[0].type, "text");
  assert.ok(typeof message.id === "string" && message.id.length > 0);
});

test("resolveRoute 读取 provider/model 并忽略空 reasoningEffort", () => {
  assert.deepEqual(resolveRoute({ currentSelection: () => ({ provider: "p", model: "m" }) }), {
    provider: "p",
    model: "m",
  });
  assert.deepEqual(resolveRoute({ currentSelection: () => ({ provider: "p", model: "m", reasoningEffort: "high" }) }), {
    provider: "p",
    model: "m",
    reasoningEffort: "high",
  });
  assert.equal(resolveRoute({ currentSelection: () => ({ provider: "p", model: "m", reasoningEffort: "  " }) }).reasoningEffort, undefined);
  assert.equal(resolveRoute(undefined), undefined);
  assert.equal(resolveRoute({ currentSelection: () => ({ provider: "p" }) }), undefined);
  assert.equal(resolveRoute({ currentSelection: () => { throw new Error("boom"); } }), undefined);
});

test("optimizePromptText 成功路径：清洗后返回", async () => {
  const llm = fakeLlm([
    { type: "text-delta", index: 0, text: '```\nEnhanced prompt: "' },
    { type: "text-delta", index: 0, text: "请解释这段代码的功能" },
    { type: "text-delta", index: 0, text: '"\n```' },
    { type: "finish", reason: { kind: "stop" } },
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "解释代码" });
  assert.deepEqual(result, { ok: true, text: "请解释这段代码的功能", tier: "full", mode: "seed", classificationSource: "adaptive-seed", gate: { verdict: "ok", repairs: 0, rechecked: false, violations: [] }, detail: "" });

  // 请求参数契约
  const sent = llm.seen[0];
  assert.equal(sent.provider, "test");
  assert.equal(sent.model, "test-model");
  assert.ok(sent.system.includes("You rewrite the user's draft for a coding assistant"), "统一走自适应契约");
  assert.equal(sent.messages.length, 1);
  assert.ok(sent.messages[0].content[0].text.includes("解释代码"));
});

test("optimizePromptText 不透传 reasoningEffort 但传递 signal", async () => {
  const llm = fakeLlm([{ type: "text-delta", index: 0, text: "ok" }, { type: "finish", reason: { kind: "stop" } }]);
  const controller = new AbortController();
  await optimizePromptText({
    llm,
    route: { ...ROUTE, reasoningEffort: "high" },
    text: "帮我看看这段代码",
    signal: controller.signal,
  });
  // 改写是轻任务：透传 max 档推理实测会让输出在"展开/原样"间发散（方差来源），不透传
  assert.equal(llm.seen[0].reasoningEffort, undefined, "改写调用不透传 reasoningEffort");
  assert.equal(llm.seen[0].signal, controller.signal);
});

test("optimizePromptText 错误分支全覆盖", async () => {
  const happy = fakeLlm([{ type: "text-delta", index: 0, text: "ok" }, { type: "finish", reason: { kind: "stop" } }]);

  assert.equal((await optimizePromptText({ llm: happy, route: ROUTE, text: "  " })).code, ERROR_CODES.EMPTY_INPUT);
  assert.equal(
    (await optimizePromptText({ llm: happy, route: ROUTE, text: "x".repeat(MAX_TEXT_LENGTH + 1) })).code,
    ERROR_CODES.INPUT_TOO_LONG,
  );
  assert.equal((await optimizePromptText({ llm: undefined, route: ROUTE, text: "帮我看看这段代码" })).code, ERROR_CODES.LLM_UNAVAILABLE);
  assert.equal((await optimizePromptText({ llm: happy, route: undefined, text: "帮我看看这段代码" })).code, ERROR_CODES.MODEL_UNAVAILABLE);

  const erroring = fakeLlm([{ type: "finish", reason: { kind: "error", failure: { code: "boom", message: "kaboom" } } }]);
  const errored = await optimizePromptText({ llm: erroring, route: ROUTE, text: "帮我看看这段代码" });
  assert.equal(errored.code, ERROR_CODES.LLM_ERROR);
  assert.equal(errored.error, "kaboom");

  const throwing = { stream() { throw new Error("network down"); } };
  const thrown = await optimizePromptText({ llm: throwing, route: ROUTE, text: "帮我看看这段代码" });
  assert.equal(thrown.code, ERROR_CODES.LLM_ERROR);
  assert.equal(thrown.error, "network down");

  const empty = fakeLlm([{ type: "text-delta", index: 0, text: '  ""  ' }, { type: "finish", reason: { kind: "stop" } }]);
  assert.equal((await optimizePromptText({ llm: empty, route: ROUTE, text: "帮我看看这段代码" })).code, ERROR_CODES.EMPTY_RESULT);
});

test("finish=max-tokens 一律拒绝，即使已经产出正文", async () => {
  // 依据：真实模型实测——被截断的 prompt 写进输入框比报错更危险。
  const partial = fakeLlm([
    { type: "text-delta", index: 0, text: "请检查这段代码是否存在语法错误、逻辑缺陷、边界情况，" },
    { type: "finish", reason: { kind: "max-tokens" } },
  ]);
  const result = await optimizePromptText({ llm: partial, route: ROUTE, text: "看看代码" });
  assert.equal(result.ok, false);
  assert.equal(result.code, ERROR_CODES.TRUNCATED);
  assert.equal(result.text, undefined, "截断结果绝不能回填输入框");
  assert.equal(result.error, "结果被截断，请缩短输入后重试");

  // 空正文 + max-tokens 同样走 truncated，而不是落到含义模糊的 empty_result
  const nothing = fakeLlm([{ type: "finish", reason: { kind: "max-tokens" } }]);
  assert.equal((await optimizePromptText({ llm: nothing, route: ROUTE, text: "帮我看看这段代码" })).code, ERROR_CODES.TRUNCATED);
});

test("optimizePromptText 失败时绝不清空调用方输入", async () => {
  const throwing = { stream() { throw new Error("x"); } };
  const result = await optimizePromptText({ llm: throwing, route: ROUTE, text: "keep me" });
  assert.equal(result.ok, false);
  assert.equal(result.text, undefined);
  assert.ok(typeof result.error === "string");
});

// --------------------------------------------------------------------------
// 保真闸门：粗筛、审判归一、处置矩阵
// --------------------------------------------------------------------------

test("assessInflation 粗筛：发明式膨胀命中，蕴含展开不误杀", () => {
  // 短输入 + 发明式膨胀比（>3）→ bloated
  const bloated = assessInflation("看看代码", "x".repeat(100));
  assert.equal(bloated.bloated, true);
  assert.equal(bloated.suspicious, true);
  assert.ok(bloated.ratio > 20);

  // 蕴含展开的正常区间（1.2–2.5×）不得命中（v0.2 的 2.0 阈值会误杀这类展开）
  const unfolded = assessInflation("帮我看看这个登录接口有没有问题", "请检查这个登录接口是否存在问题；如有，指出具体是什么问题、出现在哪里。");
  assert.ok(unfolded.ratio > 1.5 && unfolded.ratio <= 2.5, `ratio 应落在蕴含区间，实际 ${unfolded.ratio.toFixed(2)}`);
  assert.equal(unfolded.bloated, false, "蕴含展开不应被标记为膨胀");
  assert.equal(unfolded.suspicious, false);

  // 开放式输入 + 改写含发明交付物 → openEndedClosed
  const closed = assessInflation("帮我看看这个接口有没有问题", "请审查该接口的安全问题，并输出对比表格与选型建议");
  assert.equal(closed.openEndedClosed, true);
  assert.equal(closed.suspicious, true);

  // 开放式输入 + 蕴含展开 → 不命中
  const fine = assessInflation("帮我看看这个接口有没有问题", "请检查这个接口是否存在问题");
  assert.equal(fine.openEndedClosed, false);
  assert.equal(fine.bloated, false);
  assert.equal(fine.suspicious, false);

  // 长输入的正常展开（≥200 字符）不因比率触发（阈值只在短输入上生效）
  const longInput = "请修复 src/a.js 中 render 函数的空指针问题：当 config 为 undefined 时第 42 行的 config.theme 会抛出 TypeError，堆栈指向 render(src/a.js:42)，先在本地复现，再修复并补充回归测试覆盖 config 缺失的分支场景";
  const longOut = longInput + "，验证通过后说明改动点。";
  const longCase = assessInflation(longInput, longOut);
  assert.equal(longCase.bloated, false);
});

test("isSubstantivelyUnchanged：标点/敬语/大小写/近义替换级微调算未变，蕴含展开算已变", () => {
  const input = "帮我看看这个登录接口有没有问题";
  // 只加问号/句号/请 → 未变（v0.3.1 实测的平庸输出形态）
  assert.equal(isSubstantivelyUnchanged(input, "帮我看看这个登录接口有没有问题？"), true);
  assert.equal(isSubstantivelyUnchanged(input, "请帮我看看这个登录接口有没有问题。"), true);
  // 大小写 + 句号微调 → 未变（v0.3.3 英文案例逃逸形态）
  assert.equal(isSubstantivelyUnchanged("make the dashboard faster", "Make the dashboard faster."), true);
  // 近义替换（怎么→如何）→ 未变（v0.3.3 中文案例逃逸形态）
  assert.equal(isSubstantivelyUnchanged("调研一下这个功能该怎么开发", "请调研一下这个功能该如何开发。"), true);
  // 蕴含展开 → 已变
  assert.equal(isSubstantivelyUnchanged(input, "帮我看看这个登录接口有没有问题；如果有，指出是什么问题。"), false);
  assert.equal(isSubstantivelyUnchanged("make the dashboard faster", "Find what makes the dashboard slow and fix it."), false);
  assert.equal(isSubstantivelyUnchanged("", "anything"), false);
});

test("looksOpenEnded：开放式、问句与短祈使式命中，明确指令不命中", () => {
  assert.equal(looksOpenEnded("帮我看看这个登录接口有没有问题"), true, "开放式动词");
  assert.equal(looksOpenEnded("调研一下这个功能该怎么开发"), true, "调研");
  assert.equal(looksOpenEnded("这个函数有 bug，can you help fix it?"), true, "问句");
  assert.equal(looksOpenEnded("make the dashboard faster"), true, "短祈使式无锚定（v0.3.2 实测漏网形态）");
  assert.equal(looksOpenEnded("删除 src/utils/legacy.js 里未被引用的 export，跑一遍测试确认没破坏"), false, "已明确指令");
  assert.equal(looksOpenEnded("修复 render 函数第 42 行的空指针异常"), false, "含行号锚定的明确指令");
});

test("补全闸：种子输入的第一稿实质未变时，补全重跑并回填补全版", async () => {
  const input = "帮我看看这个登录接口有没有问题";
  const llm = scriptedLlm([
    textChunks("帮我看看这个登录接口有没有问题？"),  // 第一稿：标点级微调（未变）
    textChunks("请检查这个登录接口是否存在问题；如有，指出是什么问题、出现在哪里。"), // 补全重跑
    textChunks("OK"), // 审判
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.deepEqual(result, {
    ok: true,
    text: "请检查这个登录接口是否存在问题；如有，指出是什么问题、出现在哪里。",
    tier: "full",
    mode: "seed",
    classificationSource: "adaptive-seed",
    gate: { verdict: "ok", repairs: 0, rechecked: false, violations: [] },
    detail: "",
  });
  assert.equal(llm.seen.length, 3, "重跑脱离平庸即停，不再二次重试");
  assert.ok(llm.seen[1].system.includes("ELABORATION MODE"), "重跑必须带补全模式约束");
  assert.ok(llm.seen[1].messages[0].content[0].text.includes("too thin"), "重跑必须说明失败原因并要求补全");
  assert.equal(llm.seen[1].temperature, 0.4, "首次重试温度 0.4");
});

test("补全闸：两次重试温度递增，全部平庸时回填最后一次", async () => {
  const input = "调研一下这个功能该怎么开发";
  const llm = scriptedLlm([
    textChunks("调研一下这个功能该怎么开发。"), // 第一稿：未变
    textChunks("请调研一下这个功能该怎么开发。"), // 重试一：仍未变
    textChunks("请调研一下这个功能该如何开发。"), // 重试二：仍未变
    textChunks("OK"), // 审判
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true);
  assert.equal(result.text, "请调研一下这个功能该如何开发。");
  assert.equal(result.tier, "full");
  assert.equal(llm.seen.length, 4, "两连重试 + 审判");
  assert.equal(llm.seen[1].temperature, 0.4);
  assert.equal(llm.seen[2].temperature, 0.7, "第二次重试升温扰动");
});

test("补全闸：已明确输入的第一稿未变时不触发重跑", async () => {
  const input = "删除 src/utils/legacy.js 里未被引用的 export，跑一遍测试确认没破坏";
  const llm = scriptedLlm([
    textChunks("MODE: precise\n删除 src/utils/legacy.js 中未被引用的 export，然后跑一遍测试确认没有破坏。"),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true);
  assert.equal(result.tier, "full");
  // 精确模式 + 近原样 → 连审判一起省掉（P1-5）：只花 1 次调用
  assert.equal(llm.seen.length, 1, "精确输入近原样时跳过审判");
  assert.ok(llm.seen[0].system.includes("You rewrite the user's draft for a coding assistant"), "模式由模型声明，契约统一");
});

test("looksSeedish：短种子/开放式命中，带锚定的明确指令不命中", () => {
  assert.equal(looksSeedish("帮我做个图片压缩的功能"), true, "短种子");
  assert.equal(looksSeedish("帮我看看这个登录接口有没有问题"), true, "开放式");
  assert.equal(looksSeedish("这玩意儿咋老崩啊"), true, "短句无锚定");
  assert.equal(
    looksSeedish("删除 src/utils/legacy.js 里未被引用的 export，跑一遍测试确认没破坏"),
    false,
    "带路径锚定的明确指令",
  );
  assert.equal(looksSeedish(""), false);
});

test("isContentFree：纯招呼/纯标点命中，极短但有内容的输入不误杀", () => {
  // 实测病征：hi 空转 5.4s、你好 被拒 8.5s（v0.6.1 线上）
  assert.equal(isContentFree("hi"), true);
  assert.equal(isContentFree("HI"), true);
  assert.equal(isContentFree("你好"), true);
  assert.equal(isContentFree("谢谢"), true);
  assert.equal(isContentFree("?"), true);
  assert.equal(isContentFree("。。"), true);
  assert.equal(isContentFree("   "), true);
  assert.equal(isContentFree(""), true);
  assert.equal(isContentFree("👍"), true);
  // 阈值必须极低：登录（2 字）实测能补出高质量方案
  assert.equal(isContentFree("登录"), false);
  assert.equal(isContentFree("修一下"), false);
  assert.equal(isContentFree("帮我看看这个接口"), false);
});

test("无内容输入直接短路：零模型调用，返回中性错误码", async () => {
  const llm = scriptedLlm([textChunks("不该被调用")]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "hi" });
  assert.equal(result.ok, false);
  assert.equal(result.code, ERROR_CODES.NOTHING_TO_OPTIMIZE);
  assert.equal(result.error, "内容太短，没有可优化的信息");
  assert.equal(llm.seen.length, 0, "内容下限不花任何模型调用");
});

test("精确模式近原样时跳过审判：只花一次调用", async () => {
  const input = "把 src/utils/legacy.js 里的 formatDate 改成用 dayjs 实现";
  const same = "把 src/utils/legacy.js 里的 formatDate 改成用 dayjs 实现";
  const llm = scriptedLlm([textChunks("MODE: precise\n" + same), textChunks("OK")]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.deepEqual(result, { ok: true, text: same, tier: "full", mode: "precise", classificationSource: "adaptive-precise", gate: { verdict: "unverified", repairs: 0, rechecked: false, violations: [] }, detail: "" });
  assert.equal(llm.seen.length, 1, "近原样 → 不发起审判");
});

test("精确模式但改写动了实质：审判照常执行（短路不得放走真改动）", async () => {
  const input = "把 src/utils/legacy.js 里的 formatDate 改成用 dayjs 实现";
  const swapped = "把 src/utils/legacy.js 里的 formatDate 改成用 moment 实现";
  const llm = scriptedLlm([
    textChunks(swapped),
    textChunks("CONTRADICTED: 把 dayjs 换成了 moment"),
    textChunks("把 src/utils/legacy.js 里的 formatDate 改成用 dayjs 实现"),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(llm.seen.length, 4, "实质改动必须过审判，并由定向修复拉回");
  assert.equal(result.ok, true);
  assert.equal(result.tier, "repaired");
  assert.equal(result.text, "把 src/utils/legacy.js 里的 formatDate 改成用 dayjs 实现");
});

test("isPreciseInstruction：点名目标+动作的完整指令命中，种子与问句不命中", () => {
  // 命中：锚定事实（路径/扩展名/数字）+ 明确动作 + 不是问句
  assert.equal(
    isPreciseInstruction("删除 src/utils/legacy.js 里未被引用的 export，跑一遍测试确认没破坏"),
    true,
    "v0.6.0 线上实测的过度发散病征输入",
  );
  assert.equal(isPreciseInstruction("把 src/utils/legacy.js 里的 formatDate 改成用 dayjs 实现"), true);
  assert.equal(isPreciseInstruction("修复 render 函数第 42 行的空指针异常"), true);
  // 不命中：种子/普通请求（无锚定）
  assert.equal(isPreciseInstruction("帮我做个导出报表的功能"), false);
  assert.equal(isPreciseInstruction("给设置页加个深色模式开关"), false);
  // 不命中：开放意图（问句/调研/看看）
  assert.equal(isPreciseInstruction("帮我看看这个登录接口有没有问题"), false);
  assert.equal(isPreciseInstruction("调研一下 src/api 下这个模块该怎么开发"), false);
  // 不命中：太短（信息量不足以称为完整指令）
  assert.equal(isPreciseInstruction("改 src/a.js"), false);
  assert.equal(isPreciseInstruction(""), false);
});

test("精确输入走精确模式：契约整段切换，输出接近原样", async () => {
  const input = "删除 src/utils/legacy.js 里未被引用的 export，跑一遍测试确认没破坏";
  const polished = "删除 src/utils/legacy.js 里未被引用的 export，然后跑一遍测试确认没有破坏现有功能。";
  const llm = scriptedLlm([textChunks("MODE: precise\n" + polished), textChunks("OK")]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });

  assert.deepEqual(result, { ok: true, text: polished, tier: "full", mode: "precise", classificationSource: "adaptive-precise", gate: { verdict: "ok", repairs: 0, rechecked: false, violations: [] }, detail: "" });
  assert.equal(llm.seen.length, 2, "精确输入不触发补全闸");
  assert.ok(llm.seen[0].system.includes("You rewrite the user's draft for a coding assistant"), "统一入口：自适应契约");
  assert.ok(llm.seen[0].system.includes("near-verbatim"), "自适应契约保留近原样通道（MODE: precise）");
  const userPrompt = llm.seen[0].messages[0].content[0].text;
  assert.ok(userPrompt.includes(input), "user 侧携带原始草稿，模式选择在 system 侧完成");
});

test("种子输入不得走精确模式（否则会压住该有的补全）", async () => {
  const input = "帮我做个导出报表的功能";
  const fat = "帮我做一个导出报表功能：可以选择导出的时间范围和统计维度，支持导出 CSV 和 Excel，数据量大时显示进度。";
  const llm = scriptedLlm([textChunks("MODE: seed\n" + fat), textChunks("OK")]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });

  assert.equal(result.ok, true);
  assert.ok(llm.seen[0].system.includes("MODE: seed"), "契约必须定义种子通道（补全）");
  assert.ok(llm.seen[0].system.includes("Unfold"), "种子通道保留补全语义");
});

test("审判报 PADDED：精确输入被加戏时定向修复，绝不回填加戏稿", async () => {
  const input = "删除 src/utils/legacy.js 里未被引用的 export，跑一遍测试确认没破坏";
  const padded = "删除 src/utils/legacy.js 里未被引用的 export：先在全仓库搜索每个 export 的引用，确认没有动态引用后再删；删完跑测试，失败就回退并说明原因。";
  const fixed = "删除 src/utils/legacy.js 里未被引用的 export，然后跑一遍测试确认没有破坏现有功能。";
  const llm = scriptedLlm([
    textChunks("MODE: precise\n" + padded),
    textChunks("PADDED: 加了搜索引用的步骤\nPADDED: 加了失败回退条款"),
    textChunks(fixed),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });

  assert.deepEqual(result, {
    ok: true,
    text: fixed,
    tier: "repaired",
    mode: "precise",
    classificationSource: "adaptive-precise",
    gate: {
      verdict: "repaired",
      repairs: 1,
      rechecked: true,
      violations: [
        { kind: "padded", text: "加了搜索引用的步骤" },
        { kind: "padded", text: "加了失败回退条款" },
      ],
    },
    detail: "",
  });
  assert.equal(llm.seen.length, 4, "修复后一律复核：4 次调用");
  assert.equal(result.gate.rechecked, true, "复核过必须标注");
  assert.ok(llm.seen[2].system.includes("PRECISE-INPUT MODE"), "修复稿仍须遵守精确模式");
  assert.ok(llm.seen[2].system.includes("REPAIR MODE"));
  assert.ok(llm.seen[2].messages[0].content[0].text.includes("加了搜索引用的步骤"), "修复 prompt 必须点名加戏内容");
});

test("PADDED 判决归一为 padded 违规", () => {
  assert.deepEqual(parseAuditVerdict("PADDED: 加了操作步骤"), {
    status: "issues",
    violations: [{ kind: "padded", text: "加了操作步骤" }],
    thin: false, detail: "" });
});

test("精确模式与 PADDED 规则写进了模板", () => {
  assert.ok(PRECISE_SUFFIX.includes("PRECISE-INPUT MODE"));
  assert.ok(PRECISE_SUFFIX.includes("adding less is the correct answer"));
  assert.ok(AUDIT_SYSTEM_TEMPLATE.includes("PADDED"));
  assert.ok(AUDIT_SYSTEM_TEMPLATE.includes("For an ALREADY-PRECISE original they are PADDED"));
});

test("症状报告蕴含修复请求：改写侧与审判侧必须同步声明（实测漏掉导致红三角误拒）", () => {
  // 用户输入"按钮就是个禁止符号，啥都没有"——描述坏掉的现象蕴含"查清并修好"。
  // 缺这条时审判把"请排查原因"判成失真，功能表现为红三角 + 原文不动（真实故障）。
  assert.ok(SYSTEM_TEMPLATE.includes("A SYMPTOM REPORT is a request"), "改写侧缺少症状蕴含");
  assert.ok(AUDIT_SYSTEM_TEMPLATE.includes("A SYMPTOM REPORT is a request"), "审判侧缺少症状蕴含（不同步会继续误拒）");
  assert.ok(USER_TEMPLATE.includes("a symptom report"), "user prompt 缺少症状蕴含示例");
  // 展开必须有界：不能从症状跳到交付物清单
  assert.ok(AUDIT_SYSTEM_TEMPLATE.includes("root-cause reports, option lists, and acceptance criteria are not"));
});

test("parseAuditVerdict 归一 OK / 四类失真 / THIN / 无法解析", () => {
  const ok = { status: "ok", violations: [], thin: false, detail: "" };
  assert.deepEqual(parseAuditVerdict("OK"), ok);
  assert.deepEqual(parseAuditVerdict("OK."), ok);
  assert.deepEqual(parseAuditVerdict("ok\n"), ok);
  assert.deepEqual(parseAuditVerdict("DISTORTED: 把调研改成了实现"), {
    status: "issues",
    violations: [{ kind: "distorted", text: "把调研改成了实现" }],
    thin: false, detail: "" });
  assert.deepEqual(parseAuditVerdict("SCOPE_ADDED: 对比表格\nTONE_SHIFTED: 变成规格书"), {
    status: "issues",
    violations: [
      { kind: "scope_added", text: "对比表格" },
      { kind: "tone_shifted", text: "变成规格书" },
    ],
    thin: false, detail: "" });
  // 历史别名 ADDED 仍归一为 scope_added（旧样本日志里可能出现）
  assert.deepEqual(parseAuditVerdict("ADDED: 修复建议"), {
    status: "issues",
    violations: [{ kind: "scope_added", text: "修复建议" }],
    thin: false, detail: "" });
  // THIN 是"失职"不是"失真"：不带 violations，单独标记
  assert.deepEqual(parseAuditVerdict("THIN: 只改了措辞"), { status: "ok", violations: [], thin: true, detail: "" });
  assert.deepEqual(parseAuditVerdict("THIN: 只改了措辞\nDISTORTED: 换了目标"), {
    status: "issues",
    violations: [{ kind: "distorted", text: "换了目标" }],
    thin: true, detail: "" });
  // KIND 行不带说明时仍算抓到把柄（宁可多修一次，不可漏放）
  assert.deepEqual(parseAuditVerdict("DISTORTED:"), {
    status: "issues",
    violations: [{ kind: "distorted", text: "改变了原始目标" }],
    thin: false, detail: "" });
  // 夹杂的自然语言行被忽略，协议行仍生效
  assert.deepEqual(parseAuditVerdict("我检查了一下\nSCOPE_ADDED: 实施计划"), {
    status: "issues",
    violations: [{ kind: "scope_added", text: "实施计划" }],
    thin: false, detail: "" });
  // 审判输出被围栏/引号包裹时要先清洗
  assert.deepEqual(parseAuditVerdict('```\n"OK"\n```'), ok);
  // 空 / 越界输出 → unparsable，调用方 fail-open
  const unparsable = { status: "unparsable", violations: [], thin: false, detail: "" };
  assert.deepEqual(parseAuditVerdict(""), unparsable);
  assert.deepEqual(parseAuditVerdict("我觉得改写得不错"), unparsable);
});

test("审判通过：正常回填，改写与审计调用均轻量", async () => {
  const llm = scriptedLlm([
    textChunks("请检查这个接口是否存在问题"),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: { ...ROUTE, reasoningEffort: "high" }, text: "帮我看看这个接口有没有问题" });
  assert.deepEqual(result, { ok: true, text: "请检查这个接口是否存在问题", tier: "full", mode: "seed", classificationSource: "adaptive-seed", gate: { verdict: "ok", repairs: 0, rechecked: false, violations: [] }, detail: "" });

  assert.equal(llm.seen.length, 2, "改写 + 审判恰好两次调用");
  const [rewriteCall, auditCall] = llm.seen;
  assert.ok(rewriteCall.system.includes("You rewrite the user's draft for a coding assistant"), "自适应契约");
  assert.equal(rewriteCall.reasoningEffort, undefined, "改写不透传 reasoningEffort（max 推理是方差源）");
  assert.ok(auditCall.system.includes("strict auditor"));
  assert.equal(auditCall.reasoningEffort, undefined, "审判不透传 reasoningEffort，保持轻量");
  assert.equal(auditCall.temperature, 0);
  assert.ok(auditCall.messages[0].content[0].text.includes("ORIGINAL:"));
  assert.ok(auditCall.messages[0].content[0].text.includes("REWRITE:"));
});

test("审判报失真：定向修复保留已补细节，只摘越线处，二次审判通过", async () => {
  const input = "帮我看看这个登录接口有没有问题";
  const invented = "请审查这个登录接口的安全问题与逻辑缺陷，说明每处问题的影响范围和触发条件，并给出具体的修复建议。";
  const llm = scriptedLlm([
    textChunks(invented),            // 第一稿：曲解式展开（v0.1 病灶输出）
    textChunks("DISTORTED: 把审查范围收窄成安全问题类别\nSCOPE_ADDED: 修复建议"), // 审判：抓到把柄
    textChunks("请检查这个登录接口是否存在问题；如有，指出是什么问题、出现在哪里。"), // 修复稿
    textChunks("OK"),                // 二次审判：通过
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.deepEqual(result, {
    ok: true,
    text: "请检查这个登录接口是否存在问题；如有，指出是什么问题、出现在哪里。",
    tier: "repaired",
    mode: "seed",
    classificationSource: "adaptive-seed",
    gate: {
      verdict: "repaired",
      repairs: 1,
      rechecked: true,
      violations: [
        { kind: "distorted", text: "把审查范围收窄成安全问题类别" },
        { kind: "scope_added", text: "修复建议" },
      ],
    },
    detail: "",
  });

  assert.equal(llm.seen.length, 4);
  const repairCall = llm.seen[2];
  assert.ok(repairCall.system.includes("REPAIR MODE"), "重跑必须带定向修复约束");
  assert.equal(result.gate.rechecked, true, "语义型越线（distorted）必须复核修复稿");
  assert.equal(llm.seen.length, 4, "语义型越线保持 4 次调用");
  assert.ok(repairCall.system.includes("KEEP the detail that was NOT flagged"), "修复不得退回原样（补全是产品本体）");
  assert.ok(repairCall.messages[0].content[0].text.includes("安全问题类别"), "修复 prompt 必须点名具体问题");
});

test("二次审判仍失真：fidelity_rejected，绝不回填，且携带可解释 added 清单", async () => {
  const input = "调研一下这个功能该怎么开发";
  const invented1 = "请调研该功能的主流实现方案，输出对比表格，评估优缺点与风险，给出选型建议和实施计划。";
  const invented2 = "请调研该功能并整理成对比表格，同时给出选型建议与实施排期。";
  const llm = scriptedLlm([
    textChunks(invented1),
    textChunks("DISTORTED: 把调研改成了直接实施\nSCOPE_ADDED: 对比表格"),
    textChunks(invented2),
    textChunks("DISTORTED: 仍然把调研当成实施任务"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });

  assert.equal(result.ok, false);
  assert.equal(result.code, ERROR_CODES.FIDELITY_REJECTED);
  assert.equal(result.error, "优化会改变原意，已保留原文");
  assert.equal(result.text, undefined, "失真拒绝时绝不能带 text 字段（不变量 I1）");
  assert.deepEqual(result.added, ["仍然把调研当成实施任务"], "可解释拒绝：携带审判抓到的问题");
  assert.equal(result.rejected, invented2, "被拒版本随结果回传，供用户显式查看（不变量 I1 不变）");
  assert.equal(llm.seen.length, 4);
});

test("optimizePromptText 把会话上下文传给改写与审判调用", async () => {
  const context = [
    { role: "user", text: "登录接口有时候 500" },
    { role: "assistant", text: "看起来是 token 校验的边界情况" },
  ];
  const llm = scriptedLlm([
    textChunks("请修复登录接口的 token 校验问题"),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({
    llm,
    route: ROUTE,
    text: "帮我修一下这个",
    context,
  });
  assert.equal(result.ok, true);
  // 改写与审判的 user prompt 都携带 CONTEXT 段（审判需要知情指代来源）
  assert.ok(llm.seen[0].messages[0].content[0].text.includes("[user] 登录接口有时候 500"));
  assert.ok(llm.seen[1].messages[0].content[0].text.includes("[assistant] 看起来是 token 校验的边界情况"));
});

test("宽容带已废除：审判报失真一律定向修复，长度比不再参与放行", async () => {
  // 旧的 2.5× 宽容带会把"开放式 + 轻微新增"直接放行；补全契约下长度比不再指示
  // 越线（种子长成一段细节是正常的），真伪只由审判的语义标尺判定。
  const open = "帮我看看这个接口有没有问题";
  const distorted = "请审查这个接口的安全问题，并输出对比表格。";
  const llm = scriptedLlm([
    textChunks(distorted),
    textChunks("SCOPE_ADDED: 安全问题\nSCOPE_ADDED: 对比表格"),
    textChunks("请检查这个接口是否存在问题；如有，指出是什么问题、出现在哪里。"),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: open });
  assert.equal(result.ok, true);
  assert.equal(result.tier, "repaired");
  assert.equal(llm.seen.length, 4, "失真一律走完整修复+复核流程");
});

test("审判报 THIN：种子输入补全一次并重新审判，补全稿通过即回填", async () => {
  const input = "帮我做个图片压缩的功能";
  const thin = "请帮我实现图片压缩，把图片压小一点。";
  const fat = "帮我做一个图片压缩功能：上传图片后按目标尺寸或质量压缩，压缩前显示原图大小，压缩后显示压缩比，支持单张和批量，结果可下载，覆盖 jpg/png/webp，压缩失败时说明原因。";
  const llm = scriptedLlm([
    textChunks(thin),
    textChunks("THIN: 只改了措辞，没有补出实现细节"),
    textChunks(fat),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.deepEqual(result, { ok: true, text: fat, tier: "elaborated", mode: "seed", classificationSource: "adaptive-seed", gate: { verdict: "ok", repairs: 0, rechecked: true, violations: [] }, detail: "" });
  assert.equal(llm.seen.length, 4);
  assert.equal(llm.seen[2].temperature, 0.5, "补全重试带温度扰动（零温度重跑只会再薄一次）");
  assert.ok(llm.seen[2].system.includes("ELABORATION MODE"));
});

test("THIN 补全后引入失真：回退薄但忠实的第一稿，绝不回填失真稿", async () => {
  const input = "帮我做个图片压缩的功能";
  const thin = "请帮我实现图片压缩，把图片压小一点。";
  const distorted = "请实现一个基于 WebAssembly 的高性能图片压缩服务，包含断点续传、CDN 分发与压缩率报表。";
  const llm = scriptedLlm([
    textChunks(thin),
    textChunks("THIN: 没有补出细节"),
    textChunks(distorted),
    textChunks("SCOPE_ADDED: CDN 分发\nSCOPE_ADDED: 压缩率报表"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.deepEqual(result, { ok: true, text: thin, tier: "thin", mode: "seed", classificationSource: "adaptive-seed", gate: { verdict: "thin", repairs: 0, rechecked: false, violations: [] }, detail: "" }, "宁可薄而忠实，不可厚而曲解");
  assert.equal(llm.seen.length, 4);
});

test("审判报 THIN 但输入已明确：不补全（误报不得把明确指令堆胖）", async () => {
  const input = "删除 src/utils/legacy.js 里未被引用的 export，跑一遍测试确认没破坏";
  // 故意写长，避开"精确 + 近原样 → 跳过审判"的短路，确保审判真的会执行
  const rewrite = "删除 src/utils/legacy.js 中未被任何地方引用的导出，然后运行完整测试套件，确认现有功能没有被破坏。";
  const llm = scriptedLlm([
    textChunks(rewrite),
    textChunks("THIN: 没有补充细节"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.deepEqual(result, { ok: true, text: rewrite, tier: "full", mode: "seed", classificationSource: "adaptive-seed", gate: { verdict: "ok", repairs: 0, rechecked: false, violations: [] }, detail: "" });
  assert.equal(llm.seen.length, 2, "已明确输入不因 THIN 误报而重跑");
});

test("审判调用失败：fail-open 接受改写（闸门是纵深防御而非唯一机制）", async () => {
  const llm = scriptedLlm([
    textChunks("请检查这个接口是否存在问题"),
    [{ type: "finish", reason: { kind: "error", failure: { code: "boom", message: "audit down" } } }],
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "帮我看看这个接口有没有问题" });
  assert.deepEqual(result, { ok: true, text: "请检查这个接口是否存在问题", tier: "full", mode: "seed", classificationSource: "adaptive-seed", gate: { verdict: "ok", repairs: 0, rechecked: false, violations: [] }, detail: "" });
});

test("审判输出无法解析：fail-open 接受改写", async () => {
  const llm = scriptedLlm([
    textChunks("请检查这个接口是否存在问题"),
    textChunks("这段改写保持了一致性，整体质量不错"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "帮我看看这个接口有没有问题" });
  assert.deepEqual(result, { ok: true, text: "请检查这个接口是否存在问题", tier: "full", mode: "seed", classificationSource: "adaptive-seed", gate: { verdict: "ok", repairs: 0, rechecked: false, violations: [] }, detail: "" });
});

test("审判误报失真：定向修复稿被采纳，绝不因为一次误报就拒绝", async () => {
  // 短输入 + 高膨胀比但改写其实没曲解 → 审判误报也应走修复；修复稿只要过审就回填，
  // 用户的等待不能白费（旧流程在这里会退化成保守重跑甚至拒绝）。
  const input = "看看代码";
  const expanded = "请查看这段代码，检查其中是否存在任何问题。";
  const llm = scriptedLlm([
    textChunks(expanded),
    textChunks("DISTORTED: 加了检查问题的要求"),
    textChunks("请查看这段代码，检查其中是否存在任何问题。"),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true);
  assert.equal(result.text, expanded);
  assert.equal(result.tier, "repaired");
  assert.equal(llm.seen.length, 4);
});

// --------------------------------------------------------------------------
// 构建产物一致性

// --------------------------------------------------------------------------
// 构建产物：bundle 形态的清单、Host 半区路由、浏览器半区模块
// --------------------------------------------------------------------------

/** 读取 package.json。 */
async function readPackage() {
  return JSON.parse(await readFile(join(root, "package.json"), "utf8"));
}

/** 假装成一个 webServer 服务，收集注册的路由。 */
function makeWebServer() {
  const routes = [];
  return {
    routes,
    register(route) {
      routes.push(route);
      return () => {};
    },
  };
}

/** 造一个可读的假请求。 */
function makeRequest(options = {}) {
  const method = options.method ?? "POST";
  const host = options.host ?? "127.0.0.1:3080";
  const remoteAddress = options.remoteAddress ?? "127.0.0.1";
  const body = options.body ?? "";
  // `chunks` 允许按分片投递：溢出路径要区分"单块就超限"与"持续推流超过硬上限"，
  // 后者只有多分片才到得了。
  const parts = Array.isArray(options.chunks)
    ? options.chunks.map((chunk) => Buffer.from(chunk, "utf8"))
    : body === ""
      ? []
      : [Buffer.from(body, "utf8")];
  // `autoDestroy: false`：Readable 默认在 'end' 之后自己调一次 destroy()，
  // 那会被下面的计数器算成"路由拆了 socket"。这里只统计**路由显式调用**的那一次。
  const req = Readable.from(parts, { autoDestroy: false });
  req.method = method;
  // `headers` 可逐项覆盖：Host / Origin / content-type 都是这条路由的判定输入。
  req.headers = { host, ...(options.headers ?? {}) };
  req.socket = { remoteAddress };
  // 忠实记录 destroy 调用，而不是让它变成空操作（旧实现是 `req.destroy = () => {}`）：
  // 这条路径上真实发生过的故障正是"socket 先于响应被拆掉，客户端拿到 ECONNRESET"，
  // 而空实现把这个现象抹平了——测试因此断言 400 通过，真实 socket 上却一个字节的
  // 错误响应都送不到（实测复现并修掉之后才补上这条断言）。
  req.destroyCalls = 0;
  req.destroy = () => {
    req.destroyCalls += 1;
  };
  return req;
}

/** 造一个记录响应的假 res。 */
function makeResponse() {
  return {
    statusCode: null,
    headers: null,
    body: "",
    writeHead(status, headers) {
      this.statusCode = status;
      this.headers = headers;
    },
    end(chunk) {
      this.body = chunk ?? "";
    },
  };
}

/** 造一个带 llm 与默认模型的假 ctx。 */
function makeHostContext(webServer, options = {}) {
  const responses = options.responses ?? [
    [
      { type: "text-delta", index: 0, text: '```\nEnhanced prompt: "改写结果"\n```' },
      { type: "finish", reason: { kind: "stop" } },
    ],
    textChunks("OK"),
  ];
  const llm = options.llm === undefined ? scriptedLlm(responses) : options.llm;
  const sessionQuery =
    options.sessionQuery === undefined
      ? undefined
      : options.sessionQuery;
  return {
    webServer,
    // Cordis fiber 生命周期：effect 的返回值即 disposer（路由注册必须挂靠，
    // 否则 fiber 销毁后路由残留，热升级撞 duplicate route——实测修过的 bug）。
    effect(fn) {
      return fn();
    },
    get(name) {
      if (name === "llm") return llm;
      if (name === "sessionQuery") return sessionQuery;
      if (name === "agentDefaultModel") {
        return options.model === undefined ? { currentSelection: () => ({ provider: "p", model: "m" }) } : options.model;
      }
      return undefined;
    },
  };
}

test("package.json 是合法的 bundle 清单，且每个入口都真的存在", async () => {
  const pkg = await readPackage();
  assert.equal(pkg.dsh.bundle.patch, "./cordis.patch.yml");
  assert.equal(pkg.dsh.client.platform, "web");
  assert.equal(pkg.exports["./client"], "./lib/client.js");

  // 入口文件必须真实存在，否则 npm pack 出来的包在用户侧装载即失败
  for (const rel of [pkg.main, pkg.exports["./client"], pkg.dsh.bundle.patch]) {
    await readFile(join(root, rel), "utf8");
  }

  // files 白名单必须覆盖 lib 与 patch：漏掉任何一个都会让已发布的包缺文件
  assert.ok(pkg.files.includes("lib"));
  assert.ok(pkg.files.includes("cordis.patch.yml"));
});

test("cordis.patch.yml 以包名引用本包，而不是相对路径", async () => {
  const pkg = await readPackage();
  const patch = await readFile(join(root, "cordis.patch.yml"), "utf8");
  // 行必须按包名引用，Node 的模块解析才能找到已安装的代码
  assert.ok(patch.includes(`name: ${pkg.name}`));
  assert.ok(patch.includes("id: prompt-seed"));
  assert.ok(patch.includes("- insert:"));
});

test("lib/index.js 导出标准 Cordis 插件形状", async () => {
  const host = await import("../lib/index.js");
  assert.equal(host.name, "prompt-seed");
  assert.deepEqual(host.inject, ["webServer"]);
  assert.equal(typeof host.apply, "function");
  assert.equal(host.DEFAULT_ROUTE, "/api/prompt-seed/optimize");
});

test("Host 路由：回环放行、非法来源拒绝、方法与非 JSON 体各自归一", async () => {
  const host = await import("../lib/index.js");
  const webServer = makeWebServer();
  host.apply(makeHostContext(webServer), { samples: false });

  assert.equal(webServer.routes.length, 1);
  const route = webServer.routes[0];
  assert.equal(route.kind, "exact");
  assert.equal(route.path, host.DEFAULT_ROUTE);

  // 正常路径：清洗后返回 ok
  const ok = makeResponse();
  await route.handler(makeRequest({ body: JSON.stringify({ text: "解释代码" }) }), ok);
  assert.equal(ok.statusCode, 200);
  assert.deepEqual(JSON.parse(ok.body), { ok: true, text: "改写结果", tier: "full", mode: "seed", classificationSource: "adaptive-seed", gate: { verdict: "ok", repairs: 0, rechecked: false, violations: [] }, detail: "" });

  // 空输入仍然 200，但带业务错误码
  const empty = makeResponse();
  await route.handler(makeRequest({ body: JSON.stringify({ text: "   " }) }), empty);
  assert.equal(empty.statusCode, 200);
  assert.equal(JSON.parse(empty.body).code, "empty_input");

  const wrongMethod = makeResponse();
  await route.handler(makeRequest({ method: "GET" }), wrongMethod);
  assert.equal(wrongMethod.statusCode, 405);

  const badJson = makeResponse();
  await route.handler(makeRequest({ body: "{not json" }), badJson);
  assert.equal(badJson.statusCode, 400);

  // 超长请求体必须被拒绝，而不是无限缓冲。413 而不是 400：这是传输层事实、
  // 不是业务结果（"内容太大"该精简，"JSON 写坏了"该修语法，客户端要能区分）。
  const tooLarge = makeRequest({ body: JSON.stringify({ text: "x".repeat(70000) }) });
  const tooLargeRes = makeResponse();
  await route.handler(tooLarge, tooLargeRes);
  assert.equal(tooLargeRes.statusCode, 413);
  assert.equal(JSON.parse(tooLargeRes.body).code, "payload_too_large");
  // 关键回归：溢出本身不得拆掉 socket。拆了就写不回上面这个响应——真实 socket 上
  // 客户端拿到的是 ECONNRESET / "Empty reply from server"，连错误码都看不到。
  assert.equal(tooLarge.destroyCalls, 0, "溢出但未失控时不得 destroy socket");
});

test("回环防护同时校验 peer 地址与 Host 头", async () => {
  const host = await import("../lib/index.js");
  const webServer = makeWebServer();
  host.apply(makeHostContext(webServer), { samples: false });
  const route = webServer.routes[0];
  const payload = JSON.stringify({ text: "帮我看看这段代码" });

  // 远端 peer：直接 403
  const remotePeer = makeResponse();
  await route.handler(makeRequest({ remoteAddress: "10.0.0.7", body: payload }), remotePeer);
  assert.equal(remotePeer.statusCode, 403);
  assert.equal(JSON.parse(remotePeer.body).code, "forbidden");

  // peer 合法但 Host 头撒谎（DNS rebinding）：同样 403
  const reboundHost = makeResponse();
  await route.handler(makeRequest({ host: "evil.example.com", body: payload }), reboundHost);
  assert.equal(reboundHost.statusCode, 403);

  // ::ffff:127.0.0.1 与 localhost 都要放行
  for (const options of [
    { remoteAddress: "::ffff:127.0.0.1", host: "localhost:3080" },
    { remoteAddress: "::1", host: "[::1]:3080" },
  ]) {
    const res = makeResponse();
    await route.handler(makeRequest({ ...options, body: payload }), res);
    assert.equal(res.statusCode, 200, JSON.stringify(options));
  }
});

test("Origin 必须是回环来源：跨站页面（含免预检的简单请求）一律 403", async () => {
  const host = await import("../lib/index.js");
  const webServer = makeWebServer();
  host.apply(makeHostContext(webServer), { samples: false });
  const route = webServer.routes[0];
  const payload = JSON.stringify({ text: "帮我看看这段代码" });

  // 回环校验只能证明"请求来自这台机器"，而浏览器就在这台机器上。text/plain 属于
  // CORS 简单请求、不触发预检，本路由又从不校验 content-type —— 没有这道检查时，
  // 任意网页都能这样盲打它（实测：200 且真的花掉一次模型调用）。
  const crossSite = makeResponse();
  await route.handler(
    makeRequest({
      body: payload,
      headers: { "content-type": "text/plain", origin: "https://evil.example", "sec-fetch-site": "cross-site" },
    }),
    crossSite,
  );
  assert.equal(crossSite.statusCode, 403);
  assert.equal(JSON.parse(crossSite.body).code, "forbidden");

  // 解析不出的来源（沙箱 iframe / file:// 的 "null"）无法确认，同样不放行
  const opaque = makeResponse();
  await route.handler(makeRequest({ body: payload, headers: { origin: "null" } }), opaque);
  assert.equal(opaque.statusCode, 403);

  // 但本机页面与不带 Origin 的脚本调用必须继续放行——修一处绕过不能顺手把正常路径关掉
  for (const headers of [{ origin: "http://127.0.0.1:3080" }, { origin: "http://localhost:3080" }, {}]) {
    const res = makeResponse();
    await route.handler(makeRequest({ body: payload, headers }), res);
    assert.equal(res.statusCode, 200, JSON.stringify(headers));
  }
});

test("回环 Host 按完整形状判定：127.0.0.1.evil.example 不得放行", async () => {
  const host = await import("../lib/index.js");
  const webServer = makeWebServer();
  host.apply(makeHostContext(webServer), { samples: false });
  const route = webServer.routes[0];
  const payload = JSON.stringify({ text: "帮我看看这段代码" });

  // 前缀判据 `startsWith("127.")` 会放行它：一个 A 记录指向 127.0.0.1 的域名
  // 同时骗过 peer 校验（确实连到了本机）与前缀匹配（Host 是可控文本）。实测确认过。
  const rebound = makeResponse();
  await route.handler(makeRequest({ body: payload, headers: { host: "127.0.0.1.evil.example" } }), rebound);
  assert.equal(rebound.statusCode, 403);

  // 127.0.0.0/8 之内的真实回环地址仍然放行
  const loopbackRange = makeResponse();
  await route.handler(makeRequest({ body: payload, headers: { host: "127.0.0.53:3080" } }), loopbackRange);
  assert.equal(loopbackRange.statusCode, 200);
});

test("请求体溢出：未失控时回 413 且不拆 socket；持续推流越过硬上限才切断", async () => {
  const host = await import("../lib/index.js");
  const webServer = makeWebServer();
  host.apply(makeHostContext(webServer), { samples: false });
  const route = webServer.routes[0];
  const limit = 64 * 1024;

  // 单块超限、总量仍在硬上限（8×）内：必须给出完整错误响应，socket 保留。
  // 早先的实现先 reject 再 req.destroy()，真实 socket 上响应根本没机会写出去。
  const once = makeRequest({ chunks: ["x".repeat(limit + 1024)] });
  const onceRes = makeResponse();
  await route.handler(once, onceRes);
  assert.equal(onceRes.statusCode, 413);
  assert.equal(JSON.parse(onceRes.body).code, "payload_too_large");
  assert.equal(once.destroyCalls, 0, "溢出但未失控时不得 destroy socket");

  // 持续推流越过硬上限：这时响应已无意义，切断才是对的
  const flood = makeRequest({ chunks: Array.from({ length: 12 }, () => "x".repeat(limit)) });
  const floodRes = makeResponse();
  await route.handler(flood, floodRes);
  assert.ok(flood.destroyCalls > 0, "远超上限的推流必须被切断");
});

test("事件日志的 mode 只登记真实档位：没走到选档的失败路径写 null，绝不编造", async () => {
  const host = await import("../lib/index.js");
  const dir = await mkdtemp(join(tmpdir(), "po-mode-"));
  const file = join(dir, "samples.jsonl");
  try {
    const webServer = makeWebServer();
    host.apply(makeHostContext(webServer), { samples: file });
    const route = webServer.routes[0];
    // 三条都在"选档"之前就结束的失败路径：空输入 / 纯招呼 / 超长
    for (const text of ["", "hi", "x".repeat(MAX_TEXT_LENGTH + 1)]) {
      await route.handler(makeRequest({ body: JSON.stringify({ text }) }), makeResponse());
    }
    const records = (await readFile(file, "utf8")).trim().split("\n").map((line) => JSON.parse(line));
    assert.equal(records.length, 3);
    for (const record of records) {
      assert.notEqual(record.code, "ok");
      assert.equal(record.mode, null, `${record.code} 没有走到选档，mode 必须是 null 而不是猜出来的档位`);
    }
    // 早先的实现会把这三条全部记成 "elaborate"——一个本管线从未运行过的档位，
    // 而这份日志的全部用途正是按档位归因。
    assert.ok(!records.some((record) => record.mode === "elaborate"), "elaborate 不是本管线的档位");
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test("事件日志带 codeVersion 与 runId：跨版本样本可归因，反馈与优化可精确配对", async () => {
  const host = await import("../lib/index.js");
  const dir = await mkdtemp(join(tmpdir(), "po-runid-"));
  const file = join(dir, "samples.jsonl");
  try {
    const webServer = makeWebServer();
    host.apply(makeHostContext(webServer), { samples: file });
    const route = webServer.routes[0];
    await route.handler(
      makeRequest({ body: JSON.stringify({ text: "解释代码", runId: "run-42", sessionId: "s-1" }) }),
      makeResponse(),
    );
    await route.handler(
      makeRequest({ body: JSON.stringify({ feedback: { kind: "applied", tier: "full" }, runId: "run-42" }) }),
      makeResponse(),
    );
    const records = (await readFile(file, "utf8")).trim().split("\n").map((line) => JSON.parse(line));
    const optimize = records.find((record) => record.event === "optimize");
    const feedback = records.find((record) => record.event === "feedback");
    for (const record of [optimize, feedback]) {
      // 没有 codeVersion 时，"这条样本是哪版代码产生的"只能靠时间戳考古——
      // 实测为了判断一次拒绝是否已被新版本修掉，正是这么绕的。
      assert.equal(record.codeVersion, host.codeVersion());
      assert.equal(record.runId, "run-42");
    }
    // 关联 id 让"哪次输入被立刻撤销"成为可 join 的记录，而不是靠时间戳相邻去猜
    assert.equal(optimize.runId, feedback.runId);

    // 外部可控字符串进本地日志，必须截断
    const longBody = JSON.stringify({ text: "解释代码", runId: "r".repeat(200) });
    await route.handler(makeRequest({ body: longBody }), makeResponse());
    const last = (await readFile(file, "utf8")).trim().split("\n").map((line) => JSON.parse(line)).pop();
    assert.equal(last.runId.length, 64);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test("动作词表覆盖『换/换成』：与『替换』等价，不再漏判精确指令", () => {
  // 线上实测：同一句指令写成"换成"就判不出精确，写成"替换为"才判得出——
  // 这个差别决定是否预读会话、以及遥测怎么标注。
  assert.equal(
    isPreciseInstruction("把 src/host-core.js 第 934 行的 precise 短路判据换成 preservesAnchors 版本"),
    true,
  );
  assert.equal(
    isPreciseInstruction("把 src/host-core.js 第 934 行的 precise 短路判据替换为 preservesAnchors 版本"),
    true,
  );
  // 放宽一个词不得误伤：无事实锚定的同形表达仍按种子处理
  assert.equal(isPreciseInstruction("把这个模块里的那段逻辑换个更容易懂的说法吧"), false);
});

test("审判可单独路由：auditProvider/auditModel 只改审判调用，改写仍走主路由", async () => {
  const llm = scriptedLlm([
    textChunks("MODE: seed\n先读一遍这个模块的导出结构，看看有没有循环依赖，再给出整理方案。"),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({
    llm,
    route: ROUTE,
    auditRoute: { provider: "cheap", model: "cheap-model" },
    text: "看看代码",
  });
  assert.equal(result.ok, true);
  assert.equal(llm.seen.length, 2);
  assert.equal(llm.seen[0].provider, ROUTE.provider, "改写仍走主路由");
  assert.equal(llm.seen[1].provider, "cheap", "审判走审判路由");
  assert.equal(llm.seen[1].model, "cheap-model");
});

test("行 config 把审判路由接到路由处理器上", async () => {
  const host = await import("../lib/index.js");
  const webServer = makeWebServer();
  const ctx = makeHostContext(webServer);
  host.apply(ctx, { samples: false, auditProvider: "audit-p", auditModel: "audit-m" });
  await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "解释代码" }) }), makeResponse());
  const seen = ctx.get("llm").seen;
  assert.equal(seen.length, 2);
  assert.equal(seen[0].model, "m", "改写用 agentDefaultModel");
  assert.equal(seen[1].provider, "audit-p");
  assert.equal(seen[1].model, "audit-m");
});

test("可选调用预算：超时后跳过修复，结论与『修复后仍失真』完全同构", async () => {
  const input = "把 src/app.js 里的 login 换成 session 版本";
  /**
   * 每次调用都先等一会儿的假 llm：让"预算用尽"成为确定性事件，而不是碰运气。
   * @param {Array} responses 各次调用的 chunk 序列。
   * @param {number} delayMs 每次调用的耗时。
   * @returns {object} 假 llm。
   */
  const slowLlm = (responses, delayMs) => {
    const seen = [];
    return {
      seen,
      stream(options) {
        seen.push(options);
        const chunks = responses[Math.min(seen.length - 1, responses.length - 1)];
        return (async function* generate() {
          await new Promise((done) => setTimeout(done, delayMs));
          for (const chunk of chunks) yield chunk;
        })();
      },
    };
  };
  const script = [
    textChunks("MODE: precise\n把 src/app.js 里的 login 换成 session 版本，并保持行为等价、其余引用不动。"),
    textChunks("PADDED: 给已明确的指令补了多余步骤"),
    textChunks("把 src/app.js 里的 login 换成 session 版本。"),
    textChunks("PADDED: 给已明确的指令补了多余步骤"),
  ];

  // 预算 30ms，两次调用各 20ms → 第三次（修复）之前必然已超时
  const bounded = slowLlm(script, 20);
  const fast = await optimizePromptText({ llm: bounded, route: ROUTE, text: input, deadlineMs: 30 });
  assert.equal(fast.ok, false);
  assert.equal(fast.code, ERROR_CODES.FIDELITY_REJECTED);
  assert.equal(bounded.seen.length, 2, "超时后不得再发起修复与复审两次调用");
  assert.equal(fast.deadlineExceeded, true);
  assert.equal(fast.mode, "precise", "跳过修复不等于放弃档位归因");
  assert.ok(typeof fast.rejected === "string" && fast.rejected !== "", "被拒草稿仍要回传给『查看被拒版本』");

  // 同样的脚本、足够的预算 → 走满四次调用，结论在用户可见层面完全一致
  const full = await optimizePromptText({ llm: slowLlm(script, 20), route: ROUTE, text: input, deadlineMs: 60000 });
  assert.equal(full.ok, false);
  assert.equal(full.code, ERROR_CODES.FIDELITY_REJECTED);
  for (const key of ["code", "error", "mode"]) {
    assert.deepEqual(fast[key], full[key], `超时路径与修复后仍失真路径的 ${key} 必须一致`);
  }
  assert.deepEqual(
    fast.violations.map((item) => item.kind),
    full.violations.map((item) => item.kind),
  );
  assert.ok(typeof full.rejected === "string" && full.rejected !== "");

  // 默认值必须与 README / FEATURES 里写的一致：它同时是"不会误伤正常耗时"的承诺
  assert.equal(DEFAULT_DEADLINE_MS, 20000, "改默认预算必须同改 README 与 docs/FEATURES.md");

  // 非法预算一律回落默认值。0 / 负数绝不能被当成"立即超时"——
  // 那等于把定向修复整体关掉，而用户以为自己只是设了个预算。
  const bogus = slowLlm(script, 20);
  const invalidBudget = await optimizePromptText({ llm: bogus, route: ROUTE, text: input, deadlineMs: 0 });
  assert.equal(invalidBudget.ok, false);
  assert.equal(bogus.seen.length, 4, "0/负数预算不得被当作立即超时");
});

test("回环判定三处共用同一套归一：IPv4-mapped IPv6 与尾点拼法不得一处放行一处拒绝", async () => {
  const host = await import("../lib/index.js");
  const webServer = makeWebServer();
  host.apply(makeHostContext(webServer), { samples: false });
  const route = webServer.routes[0];
  const payload = JSON.stringify({ text: "帮我看看这段代码" });

  // 对抗性复核实测的分歧：peer 一处解包了 ::ffff:，Host/Origin 两处没有，于是同一台
  // 机器的两种写法一处放行、一处 403（旧代码放行、新代码拒绝，是本次引入的误拒）。
  // 归一后三处必须给出同一个答案。
  for (const headers of [
    { host: "127.0.0.1:3080", origin: "http://[::ffff:127.0.0.1]:3080" },
    { host: "127.0.0.1:3080", origin: "http://[::ffff:7f00:1]:3080" }, // URL 规范化后的写法
    { host: "127.0.0.1:3080", origin: "http://localhost.:3080" },
    { host: "[::ffff:127.0.0.1]:3080" },
    { host: "localhost.:3080" },
    { host: "127.0.0.1.:3080" },
    { host: "LOCALHOST:3080" }, // Host 大小写不敏感（RFC），浏览器一律发小写
  ]) {
    const res = makeResponse();
    await route.handler(makeRequest({ body: payload, headers }), res);
    assert.equal(res.statusCode, 200, `${JSON.stringify(headers)} 是货真价实的本机拼法，不该被拒`);
  }

  // 越界段值不是地址：正则放它过去只是"看着像"
  for (const bad of ["127.0.0.256:3080", "127.999.999.999:3080", "127.0.0.1.5:3080"]) {
    const res = makeResponse();
    await route.handler(makeRequest({ body: payload, headers: { host: bad } }), res);
    assert.equal(res.statusCode, 403, `${bad} 不是合法回环地址`);
  }

  // peer 侧同样走归一：v4-mapped 的十六进制写法是 127.0.0.1，0a00:1 是 10.0.0.1
  for (const [peer, expected] of [
    ["::ffff:127.0.0.1", 200],
    ["::ffff:7f00:1", 200],
    ["::ffff:0a00:1", 403],
  ]) {
    const res = makeResponse();
    await route.handler(makeRequest({ body: payload, remoteAddress: peer }), res);
    assert.equal(res.statusCode, expected, `peer ${peer}`);
  }
});

test("Host 路由在 llm 或默认模型缺席时返回结构化错误码", async () => {
  const host = await import("../lib/index.js");

  const noLlm = makeWebServer();
  host.apply(makeHostContext(noLlm, { llm: null }), { samples: false });
  const first = makeResponse();
  await noLlm.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这段代码" }) }), first);
  assert.equal(JSON.parse(first.body).code, "llm_unavailable");

  const noModel = makeWebServer();
  host.apply(makeHostContext(noModel, { model: null }), { samples: false });
  const second = makeResponse();
  await noModel.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这段代码" }) }), second);
  assert.equal(JSON.parse(second.body).code, "model_unavailable");
});

test("Host 路由支持自定义 path，且忽略不以 / 开头的非法值", async () => {
  const host = await import("../lib/index.js");

  const custom = makeWebServer();
  host.apply(makeHostContext(custom), { route: "/api/custom/optimize", samples: false });
  assert.equal(custom.routes[0].path, "/api/custom/optimize");

  const invalid = makeWebServer();
  host.apply(makeHostContext(invalid), { route: "no-leading-slash", samples: false });
  assert.equal(invalid.routes[0].path, host.DEFAULT_ROUTE);
});

test("行 config 覆盖模型路由：provider+model 成对生效", async () => {
  const host = await import("../lib/index.js");

  const overridden = makeWebServer();
  const ctx = makeHostContext(overridden);
  host.apply(ctx, { provider: "zai", model: "glm-flash", samples: false });
  const res = makeResponse();
  await overridden.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这段代码" }) }), res);
  assert.equal(res.statusCode, 200);
  const llm = ctx.get("llm");
  assert.equal(llm.seen[0].provider, "zai", "provider 覆盖生效");
  assert.equal(llm.seen[0].model, "glm-flash", "model 覆盖生效");

  // 只给 provider 不给 model：忽略覆盖，回落默认模型
  const half = makeWebServer();
  const ctxHalf = makeHostContext(half);
  host.apply(ctxHalf, { provider: "zai", samples: false });
  const resHalf = makeResponse();
  await half.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这段代码" }) }), resHalf);
  assert.equal(ctxHalf.get("llm").seen[0].provider, "p", "残缺覆盖回落 agentDefaultModel");
});

test("请求带 sessionId 时读取会话上下文并注入改写调用", async () => {
  const host = await import("../lib/index.js");

  const webServer = makeWebServer();
  const readCalls = [];
  const ctx = makeHostContext(webServer, {
    sessionQuery: {
      readSurface(sessionId) {
        readCalls.push(sessionId);
        return Promise.resolve({
          events: [
            { type: "user/message", data: { role: "user", source: { kind: "user" }, content: [{ type: "text", text: "登录接口有时候 500" }] } },
          ],
        });
      },
    },
  });
  host.apply(ctx, { samples: false });
  const res = makeResponse();
  await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我修一下这个", sessionId: "s-1" }) }), res);

  assert.deepEqual(readCalls, ["s-1"]);
  const userPrompt = ctx.get("llm").seen[0].messages[0].content[0].text;
  assert.ok(userPrompt.includes("[user] 登录接口有时候 500"), "上下文进入了改写 prompt");

  // 不带 sessionId：不读会话
  const res2 = makeResponse();
  await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这段代码" }) }), res2);
  assert.equal(readCalls.length, 1, "无 sessionId 不触发 readSurface");

  // sessionQuery 缺席：静默降级，优化照常
  const bare = makeWebServer();
  host.apply(makeHostContext(bare), { samples: false });
  const res3 = makeResponse();
  await bare.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这段代码", sessionId: "s-2" }) }), res3);
  assert.equal(JSON.parse(res3.body).ok, true);

  // context: false 配置：即使有 sessionId 也不读
  const off = makeWebServer();
  const offCalls = [];
  host.apply(makeHostContext(off, {
    sessionQuery: { readSurface(id) { offCalls.push(id); return Promise.resolve({ events: [] }); } },
  }), { context: false, samples: false });
  const res4 = makeResponse();
  await off.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这段代码", sessionId: "s-3" }) }), res4);
  assert.deepEqual(offCalls, [], "context:false 完全关闭会话读取");
});

test("readSurface 抛错时静默降级为无上下文", async () => {
  const host = await import("../lib/index.js");
  const webServer = makeWebServer();
  host.apply(makeHostContext(webServer, {
    sessionQuery: {
      readSurface() { return Promise.reject(new Error("corrupt log")); },
    },
  }), { samples: false });
  const res = makeResponse();
  await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这段代码", sessionId: "s-x" }) }), res);
  assert.equal(JSON.parse(res.body).ok, true, "上下文失败不阻塞优化");
});

test("preservesAnchors：标识符/路径/数字一个都不能少", () => {
  const input = "把 src/utils/legacy.js 里的 formatDate 改成用 dayjs 实现";
  assert.equal(preservesAnchors(input, "把 src/utils/legacy.js 里的 formatDate 改成用 dayjs 实现。"), true);
  assert.equal(preservesAnchors(input, "请把 src/utils/legacy.js 中的 formatDate 改用 dayjs。"), true);
  // 内容词替换必须被发现（实测编辑距离容差放走过这一例）
  assert.equal(preservesAnchors(input, "把 src/utils/legacy.js 里的 formatDate 改成用 moment 实现"), false);
  assert.equal(preservesAnchors(input, "把 src/utils/legacy.js 里的 formatDate 改掉"), false, "丢掉 dayjs");
  // 数字同样算锚定
  assert.equal(preservesAnchors("修复 render 函数第 42 行的空指针", "修复 render 函数第 43 行的空指针"), false);
  assert.equal(preservesAnchors("修复 render 函数第 42 行的空指针", "修复 render 函数第 42 行的空指针异常。"), true);
});

test("反馈通道：同一条路由收隐式信号，落盘且不花模型调用", async () => {
  const host = await import("../lib/index.js");
  const dir = await mkdtemp(join(tmpdir(), "po-feedback-"));
  const file = join(dir, "samples.jsonl");
  try {
    const webServer = makeWebServer();
    const ctx = makeHostContext(webServer, { responses: [textChunks("不该被调用")] });
    host.apply(ctx, { samples: file });

    const res = makeResponse();
    await webServer.routes[0].handler(
      makeRequest({ body: JSON.stringify({ feedback: { kind: "reverted", tier: "full", charsDelta: 120, elapsedMs: 4200 } }) }),
      res,
    );
    assert.equal(res.statusCode, 200);
    assert.deepEqual(JSON.parse(res.body), { ok: true });
    assert.equal(ctx.get("llm").seen.length, 0, "反馈不触发任何模型调用");

    const record = JSON.parse((await readFile(file, "utf8")).trim().split("\n")[0]);
    assert.equal(record.event, "feedback");
    assert.equal(record.kind, "reverted");
    assert.equal(record.tier, "full");
    assert.equal(record.charsDelta, 120);
    assert.equal(record.elapsedMs, 4200);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test("每次优化都落盘：不只记拒绝，带 tier/mode/长度/耗时", async () => {
  const host = await import("../lib/index.js");
  const dir = await mkdtemp(join(tmpdir(), "po-events-"));
  const file = join(dir, "samples.jsonl");
  try {
    const webServer = makeWebServer();
    host.apply(
      makeHostContext(webServer, {
        responses: [textChunks("MODE: precise\n删除 src/utils/legacy.js 中未被引用的 export，然后跑测试确认没有破坏。"), textChunks("OK")],
      }),
      { samples: file },
    );
    const res = makeResponse();
    await webServer.routes[0].handler(
      makeRequest({ body: JSON.stringify({ text: "删除 src/utils/legacy.js 里未被引用的 export，跑一遍测试确认没破坏" }) }),
      res,
    );
    assert.equal(JSON.parse(res.body).ok, true);

    const record = JSON.parse((await readFile(file, "utf8")).trim().split("\n")[0]);
    assert.equal(record.event, "optimize");
    assert.equal(record.code, "ok");
    assert.equal(record.tier, "full");
    assert.equal(record.mode, "precise", "该输入命中精确模式");
    assert.ok(record.inputChars > 0 && record.outputChars > 0);
    assert.ok(typeof record.ms === "number");
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test("引用标记守恒规则写进了模板", () => {
  assert.ok(SYSTEM_SUFFIX.includes("@src/a.js"));
  assert.ok(SYSTEM_SUFFIX.includes("Never drop, translate, or reword one"));
});

test("路由在保真拒绝时把样本落盘（误拒的唯一证据来源）", async () => {
  const host = await import("../lib/index.js");
  const dir = await mkdtemp(join(tmpdir(), "po-route-samples-"));
  const file = join(dir, "samples.jsonl");
  try {
    const webServer = makeWebServer();
    // 审判两次都判 ADDED → 走到 fidelity_rejected
    host.apply(
      makeHostContext(webServer, {
        responses: [
          textChunks("请审查这个接口的安全问题，并给出修复建议。"),
          textChunks("DISTORTED: 把检查变成了安全审查"),
          textChunks("请审查这个接口的安全问题，并给出修复建议。"),
          textChunks("DISTORTED: 仍然把检查变成了安全审查"),
        ],
      }),
      { samples: file },
    );
    const res = makeResponse();
    await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这个接口有没有问题" }) }), res);
    const body = JSON.parse(res.body);
    assert.equal(body.code, "fidelity_rejected");

    const lines = (await readFile(file, "utf8")).trim().split("\n");
    assert.equal(lines.length, 1, "每次拒绝写一条");
    const record = JSON.parse(lines[0]);
    assert.equal(record.code, "fidelity_rejected");
    assert.equal(record.input, "帮我看看这个接口有没有问题");
    assert.ok(Array.isArray(record.added) && record.added.length > 0, "必须带审判抓到的条目");

    // samples:false 时不写
    const dir2 = await mkdtemp(join(tmpdir(), "po-route-samples-off-"));
    const file2 = join(dir2, "samples.jsonl");
    const webServer2 = makeWebServer();
    host.apply(makeHostContext(webServer2, {
      responses: [
        textChunks("请审查这个接口的安全问题，并给出修复建议。"),
        textChunks("DISTORTED: 把检查变成了安全审查"),
        textChunks("请审查这个接口的安全问题，并给出修复建议。"),
        textChunks("DISTORTED: 仍然把检查变成了安全审查"),
      ],
    }), { samples: false });
    const res2 = makeResponse();
    await webServer2.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这个接口有没有问题" }) }), res2);
    assert.equal(JSON.parse(res2.body).code, "fidelity_rejected");
    await assert.rejects(readFile(file2, "utf8"), "samples:false 时不得创建样本文件");
    await rm(dir2, { recursive: true, force: true });
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test("客户端半区带隐式反馈与引用守恒逻辑", async () => {
  const bundle = await readFile(join(root, "lib", "client.js"), "utf8");
  // 三档隐式信号 + applied（客户端存活性证据）
  for (const kind of ["applied", "reverted", "retried", "submitted"]) {
    assert.ok(bundle.includes(`'${kind}'`), `缺少反馈信号 ${kind}`);
  }
  assert.ok(bundle.includes("FEEDBACK_WINDOW_MS"), "缺少反馈窗口常量");
  assert.ok(bundle.includes("丢失引用标记"), "缺少引用守恒校验");
  assert.ok(bundle.includes("nothing_to_optimize"), "内容下限必须走中性提示而不是红色故障");
});

test("lib/client.js 是合法的 __ModuleLoader__ 模块，id 与包名一致", async () => {
  const pkg = await readPackage();
  const source = await readFile(join(root, "lib/client.js"), "utf8");

  let entry;
  // eslint-disable-next-line no-new-func
  new Function("window", source)({ __ModuleLoader__: { load: (value) => { entry = value; } } });

  assert.ok(entry, "bundle 必须通过 window.__ModuleLoader__.load 注册");
  assert.equal(entry.id, pkg.name, "模块 id 必须是包名，否则 client-modules 的图对不上");
  assert.equal(typeof entry.factory, "function");
  // factory 只注册不执行：副作用必须留在 materialize 之后
  assert.ok(!/document\./.test(source.split("factory")[0]));
});

test("lib/client.js materialize 后导出可用的客户端插件，并注册按钮与样式", async () => {
  const source = await readFile(join(root, "lib/client.js"), "utf8");
  let entry;
  // eslint-disable-next-line no-new-func
  new Function("window", source)({ __ModuleLoader__: { load: (value) => { entry = value; } } });

  const fakeReact = { createElement: () => null, useState: (v) => [v, () => {}], useEffect: () => {}, useRef: () => ({}) };
  const required = [];
  const exported = entry.factory((name) => {
    required.push(name);
    return fakeReact;
  });

  assert.deepEqual(required, ["react"], "react 是 shell 提供的 seed 模块，不需要声明为 external");
  assert.equal(exported.name, "prompt-seed");
  assert.deepEqual(exported.inject, ["slots"]);
  assert.equal(typeof exported.apply, "function");

  // 只注册一个槽位：输入框右侧的按钮。状态行（conversation.input.dock）在 0.8.4 试过，
  // 0.8.6 撤掉——全宽横幅为一行字占满整行，且它对"正在优化"这类瞬时状态毫无信息量。
  const slotNames = [];
  const fakeSlots = {
    inject(name, cb) { slotNames.push(name); cb(); },
    register() { return {}; },
  };
  const previousWindowForSlots = globalThis.window;
  globalThis.window = { localStorage: { getItem: () => null, setItem() {} } };
  try {
    exported.apply({ slots: fakeSlots, effect() {} });
  } finally {
    if (previousWindowForSlots === undefined) delete globalThis.window;
    else globalThis.window = previousWindowForSlots;
  }
  assert.deepEqual(slotNames, ["conversation.input.right"], "只挂按钮，不再挂状态行");

  const previousDocument = globalThis.document;
  const styleNodes = [];
  globalThis.document = {
    createElement() {
      return {
        attrs: {},
        textContent: "",
        setAttribute(key, value) {
          this.attrs[key] = value;
        },
        remove() {
          this.removed = true;
        },
      };
    },
    head: {
      appendChild(node) {
        styleNodes.push(node);
      },
    },
  };

  try {
    const injections = [];
    const registrations = [];
    const effects = [];
    const ctx = {
      slots: {
        inject(key, callback) {
          injections.push(key);
          callback();
        },
        register(options, render) {
          registrations.push(options);
          assert.equal(typeof render, "function");
          return () => {};
        },
      },
      effect(callback, label) {
        effects.push(label);
        return callback();
      },
    };

    exported.apply(ctx);

    assert.deepEqual(injections, ["conversation.input.right"]);
    assert.deepEqual(registrations, [{ name: "conversation.input.right", id: "prompt-seed", order: -10 }]);
    assert.deepEqual(effects, ["prompt-seed:styles"]);
    assert.equal(styleNodes.length, 1);
    assert.equal(styleNodes[0].attrs["data-dsh-plugin"], "prompt-seed");
    assert.ok(styleNodes[0].textContent.includes(".dsh-seed-btn"));
    assert.ok(styleNodes[0].textContent.includes("--dsw-alias-brand-primary"), "样式必须使用主题变量");
    // 拒绝态必须是中性色（红三角让人以为"功能坏了"，实测教训）
    assert.ok(styleNodes[0].textContent.includes('[data-mode="declined"]{color:var(--dsw-alias-label-secondary)'), "拒绝态必须中性");
    assert.ok(styleNodes[0].textContent.includes('[data-mode="error"]{color:var(--dsw-alias-state-error-primary)'), "红色只留给真错误");
  } finally {
    if (previousDocument === undefined) delete globalThis.document;
    else globalThis.document = previousDocument;
  }
});

test("浏览器半区请求的路由与 Host 半区的默认路由一致", async () => {
  const host = await import("../lib/index.js");
  const client = await readFile(join(root, "lib/client.js"), "utf8");
  // 两份产物分别编译，路由漂移会让按钮永远报错——这里锁死
  assert.ok(client.includes(host.DEFAULT_ROUTE), `客户端必须请求 ${host.DEFAULT_ROUTE}`);
});


// ---------------------------------------------------------------------------
// A–F 项新增能力
// ---------------------------------------------------------------------------

test("A 闸门凭证：审判的 DETAIL 行被解析成摘要，且不计入违规", () => {
  assert.deepEqual(parseAuditVerdict("OK\nDETAIL: 边界情况、失败处理"), {
    status: "ok",
    violations: [],
    thin: false,
    detail: "边界情况、失败处理",
  });
  // 摘要与违规可以共存
  const both = parseAuditVerdict("PADDED: 加了操作步骤\nDETAIL: 失败处理");
  assert.equal(both.status, "issues");
  assert.equal(both.detail, "失败处理");
  assert.equal(both.violations.length, 1);
  // "no change" 不当作摘要
  assert.equal(parseAuditVerdict("OK\nDETAIL: no change").detail, "");
  // 裸 OK 仍然必须被识别（曾因重写解析器丢失，测试锁死）
  assert.equal(parseAuditVerdict("OK").status, "ok");
  assert.equal(parseAuditVerdict("OK.").status, "ok");
});

test("A 闸门凭证：摘要随成功结果回传", async () => {
  const llm = scriptedLlm([
    textChunks("请检查这个登录接口是否存在问题，并说明出现在哪里。"),
    textChunks("OK\nDETAIL: 出错位置与复现条件"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "帮我看看这个登录接口有没有问题" });
  assert.equal(result.ok, true);
  assert.equal(result.detail, "出错位置与复现条件");
  assert.equal(result.gate.verdict, "ok");
});

test("修复稿一律复核：scope_added（过度发散）不得免检直接交付", async () => {
  // 回归守卫。0.8.0 曾对结构型越线跳过复核以省一次调用，实测代价是线上一次
  // scope_added 的修复稿未经复核就交付——而旧版本会复核、仍越线则拒绝并保留原文。
  // 省下的那次调用恰好省在唯一拦住"越修越发散"的环节上。
  const input = "帮我看看这个登录接口有没有问题";
  const llm = scriptedLlm([
    textChunks("请审查这个登录接口的安全问题，并给出修复建议与实施排期。"),
    textChunks("SCOPE_ADDED: 实施排期"),
    textChunks("请检查这个登录接口是否存在问题，并说明出现在哪里。"),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(llm.seen.length, 4, "修复后必须复核：4 次调用");
  assert.equal(result.ok, true);
  assert.equal(result.tier, "repaired");
  assert.equal(result.gate.rechecked, true, "复核过就必须标注 rechecked=true");
  assert.deepEqual(result.gate.violations, [{ kind: "scope_added", text: "实施排期" }]);
});

test("修复稿复核仍越线：拒绝并保留原文（发散控制不得被延迟优化吃掉）", async () => {
  const input = "帮我做个图片压缩的功能";
  const llm = scriptedLlm([
    textChunks("请实现一个图片压缩服务：支持上传压缩、断点续传、CDN 分发，并提供压缩率报表。"),
    textChunks("SCOPE_ADDED: CDN 分发"),
    textChunks("请实现图片压缩并分发到 CDN。"),
    textChunks("SCOPE_ADDED: CDN 分发"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, false);
  assert.equal(result.code, ERROR_CODES.FIDELITY_REJECTED);
  assert.equal(result.text, undefined, "拒绝时绝不带 text");
  assert.ok(typeof result.rejected === "string" && result.rejected !== "");
});

test("D/E 深度档位：标准档为空（等于基线），轻/深度档才偏离", () => {
  assert.ok(DEPTH_LIGHT_SUFFIX.includes("DEPTH - LIGHT"));
  assert.ok(DEPTH_DEEP_SUFFIX.includes("DEPTH - DEEP"));
  assert.ok(!DEPTH_LIGHT_SUFFIX.includes("DEPTH - DEEP"));
  // 标准档不加任何后缀：默认路径的 prompt 必须与引入深度档位之前逐字节相同。
  // 这是"回到之前那版效果"唯一可靠的实现方式——任何附加说明都是对模型的又一次干预。
  assert.equal(DEPTH_STANDARD_SUFFIX, "", "标准档必须为空");
  assert.equal(depthSuffix("standard"), "");
  assert.equal(depthSuffix(undefined), "");
  assert.equal(depthSuffix("deep"), DEPTH_DEEP_SUFFIX);
  assert.equal(depthSuffix("light"), DEPTH_LIGHT_SUFFIX);
  assert.equal(depthSuffix(undefined), depthSuffix("standard"));
  assert.equal(depthSuffix("garbage"), depthSuffix("standard"));
});

test("D 深度档位随请求下发到 system prompt", async () => {
  const llm = scriptedLlm([
    textChunks("帮我做一个导出报表功能：支持选择时间范围与统计维度，导出 CSV 与 Excel。"),
    textChunks("OK"),
  ]);
  await optimizePromptText({ llm, route: ROUTE, text: "帮我做个导出报表的功能", depth: "deep" });
  assert.ok(llm.seen[0].system.includes("DEPTH - DEEP"));
  assert.ok(!llm.seen[0].system.includes("DEPTH - LIGHT"));
});

test("F 模板覆盖层：覆盖后立即生效，清除后回落内置", () => {
  const llm = scriptedLlm([textChunks("改写结果文本"), textChunks("OK")]);
  setTemplateOverrides({ system: "CUSTOM SYSTEM CONTRACT" });
  assert.ok(buildSystemPrompt().startsWith("CUSTOM SYSTEM CONTRACT"));
  assert.ok(buildSystemPrompt().includes(SYSTEM_SUFFIX), "部署级追加约束必须保留");
  setTemplateOverrides(null);
  assert.ok(buildSystemPrompt().startsWith(SYSTEM_TEMPLATE));
  assert.equal(buildSystemPrompt(), SYSTEM_TEMPLATE + SYSTEM_SUFFIX);
  assert.equal(llm.seen.length, 0);
});

test("F 模板覆盖层可覆盖 user 模板且保留 {input} 占位", () => {
  setTemplateOverrides({ user: "自定义前缀\n{input}" });
  const rendered = renderUserPrompt("原始草稿", undefined);
  assert.ok(rendered.includes("自定义前缀"));
  assert.ok(rendered.includes("原始草稿"));
  setTemplateOverrides(null);
  assert.ok(renderUserPrompt("原始草稿", undefined).includes("原始草稿"));
});

test("E 按需上下文：短草稿与指代才需要会话，自足描述不需要", () => {
  assert.equal(needsContext("帮我看看这个"), true, "短草稿必然依赖上文");
  assert.equal(needsContext("把那个接口改一下"), true, "指代词命中");
  assert.equal(needsContext("fix that bug in the parser"), true, "英文指代同样命中");
  assert.equal(
    needsContext("在 src/utils/format.js 里新增一个 formatBytes 函数，输入字节数返回可读字符串，并补单元测试"),
    false,
    "自足描述不该白读会话",
  );
  assert.equal(needsContext(""), false);
});

test("E 精确指令一律视为自足：不读会话（省一次 readSurface）", async () => {
  const host = await import("../lib/index.js");
  const webServer = makeWebServer();
  const readCalls = [];
  host.apply(
    makeHostContext(webServer, {
      sessionQuery: {
        readSurface(id) { readCalls.push(id); return Promise.resolve({ events: [] }); },
      },
    }),
    { samples: false },
  );
  const res = makeResponse();
  await webServer.routes[0].handler(
    makeRequest({ body: JSON.stringify({ text: "删除 src/utils/legacy.js 里未被引用的 export，跑一遍测试确认没破坏", sessionId: "s-1" }) }),
    res,
  );
  assert.deepEqual(readCalls, [], "精确指令指名道姓，不需要上文");
});

test("E 指代草稿仍然读会话（按需注入不能把有用的上下文一起砍掉）", async () => {
  const host = await import("../lib/index.js");
  const webServer = makeWebServer();
  const readCalls = [];
  host.apply(
    makeHostContext(webServer, {
      sessionQuery: {
        readSurface(id) { readCalls.push(id); return Promise.resolve({ events: [] }); },
      },
    }),
    { samples: false },
  );
  const res = makeResponse();
  await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "把那个接口加上限流", sessionId: "s-2" }) }), res);
  assert.deepEqual(readCalls, ["s-2"]);
});

test("F 模板覆盖：从 $DSH_HOME 读取，改完立刻生效（不必重启）", async () => {
  const host = await import("../lib/index.js");
  const dir = await mkdtemp(join(tmpdir(), "po-templates-"));
  const previous = process.env.DSH_HOME;
  process.env.DSH_HOME = dir;
  try {
    const prompts = join(dir, "prompt-seed", "prompts");
    await mkdir(prompts, { recursive: true });
    await writeFile(join(prompts, "system.md"), "OVERRIDDEN CONTRACT", "utf8");

    const llm = scriptedLlm([
      textChunks("请检查这段代码是否存在问题，并说明出现在哪里。"),
      textChunks("OK"),
    ]);
    const webServer = makeWebServer();
    host.apply(makeHostContext(webServer, { llm }), { samples: false });

    const res = makeResponse();
    await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这段代码" }) }), res);
    assert.equal(res.statusCode, 200);
    assert.ok(llm.seen[0].system.startsWith("OVERRIDDEN CONTRACT"), "覆盖文件必须真的进入 system prompt");
    assert.ok(llm.seen[0].system.includes("Never drop, translate, or reword one"), "部署级追加约束仍在");

    // 改完立刻生效：不重启、不重新 apply
    await writeFile(join(prompts, "system.md"), "SECOND CONTRACT", "utf8");
    llm.seen.length = 0;
    const res2 = makeResponse();
    await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这段代码" }) }), res2);
    assert.ok(llm.seen[0].system.startsWith("SECOND CONTRACT"), "每次请求重读模板，改完下一次点击即生效");

    // 删除覆盖文件 → 回落内置模板
    await rm(join(prompts, "system.md"));
    llm.seen.length = 0;
    const res3 = makeResponse();
    await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这段代码" }) }), res3);
    assert.ok(llm.seen[0].system.includes("You rewrite the user's draft for a coding assistant"), "文件缺失即回落内置（0.9.4 起内置主契约为自适应契约）");
    setTemplateOverrides(null);
  } finally {
    if (previous === undefined) delete process.env.DSH_HOME;
    else process.env.DSH_HOME = previous;
    await rm(dir, { recursive: true, force: true });
  }
});

test("F 模板覆盖可用 templates:false 整体关闭", async () => {
  const host = await import("../lib/index.js");
  const dir = await mkdtemp(join(tmpdir(), "po-templates-off-"));
  const previous = process.env.DSH_HOME;
  process.env.DSH_HOME = dir;
  try {
    const prompts = join(dir, "prompt-seed", "prompts");
    await mkdir(prompts, { recursive: true });
    await writeFile(join(prompts, "system.md"), "SHOULD NOT APPLY", "utf8");
    const llm = scriptedLlm([
      textChunks("请检查这段代码是否存在问题，并说明出现在哪里。"),
      textChunks("OK"),
    ]);
    const webServer = makeWebServer();
    host.apply(makeHostContext(webServer, { llm }), { samples: false, templates: false });
    const res = makeResponse();
    await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这段代码" }) }), res);
    assert.ok(!llm.seen[0].system.includes("SHOULD NOT APPLY"));
    setTemplateOverrides(null);
  } finally {
    if (previous === undefined) delete process.env.DSH_HOME;
    else process.env.DSH_HOME = previous;
    await rm(dir, { recursive: true, force: true });
  }
});

test("F 被拒版本随结果回传，且绝不占用 text 字段（不变量 I1）", async () => {
  const input = "调研一下这个功能该怎么开发";
  const invented1 = "请调研该功能的主流实现方案，输出对比表格，评估优缺点与风险。";
  const invented2 = "请调研该功能并整理成对比表格，同时给出选型建议。";
  const llm = scriptedLlm([
    textChunks(invented1),
    textChunks("DISTORTED: 把调研改成了实施"),
    textChunks(invented2),
    textChunks("DISTORTED: 仍然把调研当成实施任务"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, false);
  assert.equal(result.text, undefined, "拒绝时绝不能带 text（客户端可能误写回）");
  assert.equal(result.rejected, invented2, "被拒版本走独立字段，只在用户显式查看时才用");
});

test("D 深度档位非法值安全降级为标准档（旧客户端兼容）", async () => {
  const llm = scriptedLlm([
    textChunks("帮我做一个导出报表功能：支持选择时间范围与统计维度，导出 CSV 与 Excel。"),
    textChunks("OK"),
  ]);
  await optimizePromptText({ llm, route: ROUTE, text: "帮我做个导出报表的功能", depth: "ultra" });
  // 非法值 → 标准档 → 无后缀：system prompt 里不该出现任何 DEPTH 块
  assert.ok(!llm.seen[0].system.includes("DEPTH - "), "非法值必须降级到不加后缀的基线");
  assert.equal(llm.seen[0].system, buildAdaptiveSystemPrompt("帮我做个导出报表的功能"), "非法深度降级 = 自适应基线不加后缀");
});

test("codeVersion 报的是本进程加载的代码版本，不是磁盘上的 package.json", async () => {
  const host = await import("../lib/index.js");
  const pkg = await readPackage();
  // 模块加载时冻结：文件内容改变不影响已加载实例的报告值（这正是它的用途——
  // 区分"装上了新版"和"跑的是新版"）。
  const loaded = host.codeVersion();
  assert.equal(loaded, pkg.version);

  // 决定性回归：模块已加载后改写磁盘上的 package.json，报告值必须不变。
  // 旧实现每次现读磁盘 → 装了新版但跑着旧代码时会报新版本号，把排查带进沟里。
  const file = join(root, "package.json");
  const original = await readFile(file, "utf8");
  try {
    await writeFile(file, original.replace(/"version": "[^"]+"/, '"version": "99.99.99"'), "utf8");
    assert.equal(host.codeVersion(), loaded, "codeVersion 必须在模块加载时冻结，不得现读磁盘");
    assert.notEqual(host.codeVersion(), "99.99.99");
  } finally {
    await writeFile(file, original, "utf8");
  }
  assert.equal(JSON.parse(await readFile(file, "utf8")).version, pkg.version, "package.json 必须复原");
});

test("客户端按钮真的渲染出正确形态（空会话不渲染、有上下文时空输入给预测按钮）", async () => {
  const source = await readFile(join(root, "lib", "client.js"), "utf8");
  let entry;
  // eslint-disable-next-line no-new-func
  new Function("window", source)({ __ModuleLoader__: { load: (value) => { entry = value; } } });

  // 极简 React 替身：只记录元素树，不做调和。
  const React = {
    createElement(type, props, children) {
      // 函数组件必须真的被调用（槽位注册的 render 是包了一层的函数，不会自动执行）。
      if (typeof type === "function") return type(props || {});
      return { type, props: props || {}, children: children === undefined ? [] : [].concat(children) };
    },
    useState(initial) { return [typeof initial === "function" ? initial() : initial, () => {}]; },
    useRef(value) { return { current: value }; },
    useEffect() {},
  };
  const exported = entry.factory(() => React);

  const registered = [];
  const slots = {
    inject(name, cb) { registered.push({ name, value: cb() }); },
    register(meta, render) { return { meta, render }; },
  };
  // locale 服务（P1-7）：options.locale 提供时模拟 dsh-client-locale 的形状。
  exported.apply({
    slots,
    effect() {},
    get(name) { return name === "locale" && options.locale !== undefined ? { id: options.locale } : undefined; },
  });
  assert.equal(registered.length, 1, "只注册一个槽位");
  const render = registered[0].value.render;

  const previousWindow = globalThis.window;
  globalThis.window = { localStorage: { getItem: () => null, setItem() {} } };
  try {
    const makeProps = (draft, session) => ({
      useInput(selector) { return selector({ draft, draftRev: 1, phase: "plain", occurrences: [] }); },
      inputActions: { setDraft() {}, addAttachments() {}, removeAttachment() {}, pruneAttachments() {} },
      session,
      t: (key) => key,
    });
    // 夹具用**运行时真实形状**的会话面（14 个字段，无 nodes / turnEnds）：
    // 0.9.6 首版按 ConversationSnapshot 的 nodes 找 assistant 节点，于是在真实宿主上
    // 永远判 false、图标一次都不出现。夹具必须是真形状，这种 bug 才拦得住。
    const FACE = {
      sessionId: "s-1",
      blank: false,
      running: false,
      awaitingFirstTurn: false,
      promptAttempted: true,
      pendingSubmissions: [],
      subagent: null,
      removed: false,
      openState: "ready",
      openError: null,
      hasMore: false,
      loadingOlder: false,
      promptError: null,
      lastAgentError: null,
    };
    const BLANK = { ...FACE, blank: true, promptAttempted: false };
    const READY = FACE;

    // 空会话（没有任何对话内容）+ 空草稿：整块不渲染（0.9.6 的产品决定：
    // 这时候不显示任何图标——旧实现是"常驻 + 半透明"，它换来的位置稳定
    // 现在由预测图标在"有上下文"之后承担）。
    assert.equal(render(makeProps("", BLANK)), null, "空会话里不得显示任何图标");
    assert.equal(
      render(makeProps("", { ...FACE, running: true })),
      null,
      "助手还在回复（没有来有回）时不给预测入口——那时只能瞎猜",
    );
    assert.equal(
      render(makeProps("", { ...FACE, awaitingFirstTurn: true })),
      null,
      "第一轮还没走完（awaitingFirstTurn）同样不给入口",
    );

    // 空会话 + 有草稿：仍是正常的星标（优化提示词），微光开启
    const blankTyped = render(makeProps("帮我做个导出报表的功能", BLANK));
    assert.equal(blankTyped.type, "button");
    assert.equal(blankTyped.props["data-testid"], "prompt-seed-button");
    assert.equal(blankTyped.props["data-glow"], "1", "有内容且空闲时给呼吸微光");

    // 有上下文 + 空草稿：同一个位置换成预测按钮，且不挂任何属于"优化"的凭证
    const predict = render(makeProps("", READY));
    assert.equal(predict.props["data-testid"], "prompt-seed-predict-button");
    assert.equal(predict.props["data-predict"], "1");
    assert.equal(predict.props["data-gate"], undefined, "预测态不得挂上属于优化的闸门凭证");
    assert.ok(String(predict.props.title).includes("预测"), "tooltip 必须说明这是预测");

    // 有上下文 + 有草稿：交回星标，深度档位照旧可切换
    const idle = render(makeProps("帮我做个导出报表的功能", READY));
    assert.equal(idle.type, "button", "空闲态只有一个主按钮");
    assert.equal(idle.props["data-testid"], "prompt-seed-button");
    assert.equal(idle.props["data-glow"], "1", "有内容且空闲时给呼吸微光");
    assert.ok(String(idle.props.title).includes("深度："), "tooltip 必须报出当前深度档位");
    assert.ok(String(idle.props.title).includes("右键切换"), "深度切换入口必须在 tooltip 里说明");
  } finally {
    if (previousWindow === undefined) delete globalThis.window;
    else globalThis.window = previousWindow;
  }
});

test("客户端半区包含 B/D/F 三项的界面与状态逻辑（防误删守卫）", async () => {
  const bundle = await readFile(join(root, "lib", "client.js"), "utf8");
  for (const marker of [
    "dsh-opt-secondary",
    "prompt-seed-regenerate",
    "prompt-seed-previous",
    "prompt-seed-view-rejected",
    "HISTORY_MAX",
    "resolveDepth",
    "storedDepthMode",
    "autoDepth",
    "onContextMenu",
    "dsh-opt-gate",
    "CrystalBallIcon",
    "hasConversationContext",
    "runPredict",
    "prompt-seed-predict-button",
    "prompt-seed-hint",
    "dsh-opt-hint",
  ]) {
    assert.ok(bundle.includes(marker), `客户端半区缺少 ${marker}`);
  }
  // 请求必须真的下发深度档位，否则 D 项只是死代码
  assert.ok(bundle.includes("depth:"), "请求体必须带 depth");
  // 0.9.6：空会话整块不渲染（不得退回"常驻半透明"），有上下文时空草稿交给预测
  assert.ok(bundle.includes("if (showNothing) return null"), "空会话必须整块不渲染");
  assert.ok(bundle.includes("mode: 'predict'"), "预测请求必须真的带 mode=predict");
  assert.ok(bundle.includes("cannot_predict"), "推不出来的中性拒绝必须被客户端识别");
});


// ---------------------------------------------------------------------------
// 开源准备：能力探测 + 优雅自禁用
// ---------------------------------------------------------------------------

test("宿主缺 webServer 接缝时自禁用，绝不抛异常拖垮宿主启动", async () => {
  const host = await import("../lib/index.js");
  const logged = [];
  const previousError = console.error;
  console.error = (...args) => logged.push(args);
  const ctx = {
    // 旧宿主：没有 webServer 服务
    get: () => undefined,
    effect: (fn) => fn(),
    on: () => {},
  };
  try {
    assert.doesNotThrow(() => host.apply(ctx, { samples: false }), "宿主启动是 all-or-nothing，插件绝不能抛");
  } finally {
    console.error = previousError;
  }
  assert.ok(logged.length > 0, "自禁用必须留下可读原因，而不是静默什么都不做");
  assert.ok(JSON.stringify(logged).includes("webServer"), "原因里必须点名缺的是哪个接缝");
  assert.ok(JSON.stringify(logged).includes("0.2.0-rc.1"), "原因里必须带上宿主要求，便于用户自查版本");
});

test("宿主缺 ctx.effect 时拒绝注册无法回收的路由", async () => {
  const host = await import("../lib/index.js");
  const routes = [];
  const logged = [];
  const previousError = console.error;
  console.error = (...args) => logged.push(args);
  const ctx = {
    webServer: { register: (r) => { routes.push(r); return () => {}; } },
    get: () => undefined,
    // 没有 effect：注册出来的路由无法随 fiber 回收，宁可不禁用也不能留下幽灵路由
  };
  try {
    assert.doesNotThrow(() => host.apply(ctx, { samples: false }));
  } finally {
    console.error = previousError;
  }
  assert.equal(routes.length, 0, "不得注册无法回收的路由");
  assert.ok(JSON.stringify(logged).includes("effect"));
});

test("正常宿主仍然完整注册（自禁用不得误伤）", async () => {
  const host = await import("../lib/index.js");
  const webServer = makeWebServer();
  host.apply(makeHostContext(webServer), { samples: false });
  assert.equal(webServer.routes.length, 1);
  assert.equal(webServer.routes[0].path, "/api/prompt-seed/optimize");
});

test("客户端半区缺 slots 服务时警告并退出，不抛异常", async () => {
  const source = await readFile(join(root, "lib", "client.js"), "utf8");
  let entry;
  // eslint-disable-next-line no-new-func
  new Function("window", source)({ __ModuleLoader__: { load: (value) => { entry = value; } } });
  const React = { createElement: () => null, useState: (v) => [v, () => {}], useEffect: () => {}, useRef: () => ({}) };
  const exported = entry.factory(() => React);
  const warnings = [];
  const previousWarn = console.warn;
  console.warn = (...args) => warnings.push(args);
  try {
    assert.doesNotThrow(() => exported.apply({ effect() {} }), "缺 slots 时不得抛");
    assert.ok(warnings.length > 0, "必须说明按钮为什么没挂上");
    assert.ok(JSON.stringify(warnings).includes("slots"));
  } finally {
    console.warn = previousWarn;
  }
});


test("修复契约含保守兜底：修不动就给轻润色稿，而不是赌第二次拒绝", () => {
  assert.ok(REPAIR_SUFFIX.includes("lightly polished version of the user's original request"));
  assert.ok(REPAIR_SUFFIX.includes("Do not gamble on keeping the flagged material"));
  // 兜底不能与"保留已补细节"的主指令冲突到自相矛盾：主指令仍在
  assert.ok(REPAIR_SUFFIX.includes("KEEP the detail that was NOT flagged"));
});




test("拒绝时样本日志记录越线类别（诊断一次真实拒绝时最需要的字段）", async () => {
  const host = await import("../lib/index.js");
  const dir = await mkdtemp(join(tmpdir(), "po-reject-log-"));
  const file = join(dir, "samples.jsonl");
  try {
    const webServer = makeWebServer();
    host.apply(
      makeHostContext(webServer, {
        responses: [
          textChunks("请审查这个接口的安全问题，并给出修复建议与实施排期。"),
          textChunks("SCOPE_ADDED: 实施排期"),
          textChunks("请审查这个接口的安全问题，并给出修复建议。"),
          textChunks("SCOPE_ADDED: 实施排期"),
        ],
      }),
      { samples: file },
    );
    const res = makeResponse();
    await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这个接口有没有问题" }) }), res);
    const body = JSON.parse(res.body);
    assert.equal(body.code, "fidelity_rejected");
    assert.deepEqual(body.violations.map((v) => v.kind), ["scope_added"], "响应带结构化违规");
    assert.equal(body.violations[0].label, "增加了原本没有的要求", "客户端直接用中文类别渲染");

    const record = JSON.parse((await readFile(file, "utf8")).trim().split("\n")[0]);
    assert.equal(record.code, "fidelity_rejected");
    assert.deepEqual(record.violations, ["scope_added"], "日志必须记下类别，而不是空数组");
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});


test("样本记录区分界面调用与脚本探针（否则验证脚本会淹没真实使用分布）", async () => {
  const host = await import("../lib/index.js");
  const dir = await mkdtemp(join(tmpdir(), "po-from-"));
  const file = join(dir, "samples.jsonl");
  try {
    const webServer = makeWebServer();
    host.apply(makeHostContext(webServer), { samples: file });
    // 带 sessionId = 界面点击
    const uiRes = makeResponse();
    await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这段代码", sessionId: "s-9" }) }), uiRes);
    // 不带 sessionId = 脚本直接打路由
    const scriptRes = makeResponse();
    await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "帮我看看这段代码" }) }), scriptRes);

    const lines = (await readFile(file, "utf8")).trim().split("\n").map((l) => JSON.parse(l));
    assert.equal(lines.length, 2);
    assert.equal(lines[0].from, "ui", "带 sessionId 记为界面调用");
    assert.equal(lines[1].from, "script", "不带 sessionId 记为脚本探针");
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

// --------------------------------------------------------------------------
// 信号与短指令推断（0.9.0）
// --------------------------------------------------------------------------

import {
  DEICTIC_FALLBACK_MARKER,
  SIGNAL_FALLBACK_MARKER,
  classifySignalInput,
  checkDeicticDegree,
  checkSignalOutput,
  describeMode,
  extractAssistantTail,
  inferPendingItem,
  parseOptions,
} from "../src/signal-inference.js";

test("classifySignalInput 分类纯数字/信号词/短指令/其他", () => {
  assert.equal(classifySignalInput("42").kind, "number");
  assert.equal(classifySignalInput("1").kind, "number");
  assert.equal(classifySignalInput("3.14").kind, "number");
  assert.equal(classifySignalInput("继续").kind, "signal");
  assert.equal(classifySignalInput("ok").kind, "signal");
  assert.equal(classifySignalInput("改一下").kind, "deictic");
  assert.equal(classifySignalInput("不对").kind, "deictic");
  assert.equal(classifySignalInput("换一个").kind, "deictic");
  // 不该命中的：普通种子、带锚定的精确指令、问句、长句
  assert.equal(classifySignalInput("帮我做个图片压缩").kind, "none");
  assert.equal(classifySignalInput("删除 src/utils/legacy.js 的导出").kind, "none");
  assert.equal(classifySignalInput("这样对吗").kind, "none");
  assert.equal(classifySignalInput("把整个导出报表模块重写成异步队列").kind, "none");
  assert.equal(describeMode("42"), "signal");
  assert.equal(describeMode("改一下"), "deictic");
  assert.equal(describeMode("帮我做个功能"), null);
});

test("parseOptions 解析行内与圈号选项，切在下一个选项标记处", () => {
  const map = parseOptions("要不要继续？1. 继续梳理剩余功能 2. 先停下来");
  assert.equal(map.get("1"), "继续梳理剩余功能");
  assert.equal(map.get("2"), "先停下来");
  const circled = parseOptions("选一个：①本地缓存 ②服务端缓存");
  assert.equal(circled.get("1"), "本地缓存");
  assert.equal(circled.get("2"), "服务端缓存");
});

test("纯数字无上下文 → cannot_infer，零模型调用", async () => {
  const llm = fakeLlm([]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "42" });
  assert.equal(result.ok, false);
  assert.equal(result.code, ERROR_CODES.CANNOT_INFER);
  assert.equal(llm.seen.length, 0, "无上下文时不得发起任何模型调用");
});

test("数字对不上任何选项 → cannot_infer，绝不硬猜", async () => {
  const llm = fakeLlm([]);
  const assistantTail = { role: "assistant", text: "要不要继续？1. 继续梳理剩余功能 2. 先停下来" };
  const result = await optimizePromptText({ llm, route: ROUTE, text: "42", assistantTail });
  assert.equal(result.ok, false);
  assert.equal(result.code, ERROR_CODES.CANNOT_INFER);
  assert.equal(llm.seen.length, 0, "42 对应不上选项是确定性判定，不应花调用");
});

test("数字命中选项 → 展开为选中项，锚定校验通过", async () => {
  const llm = fakeLlm(textChunks("继续，把剩下的功能梳理完。"));
  const assistantTail = { role: "assistant", text: "要不要继续？1. 继续梳理剩余功能 2. 先停下来" };
  const result = await optimizePromptText({ llm, route: ROUTE, text: "1", assistantTail });
  assert.equal(result.ok, true);
  assert.equal(result.mode, "signal");
  assert.equal(result.tier, "signal");
  assert.equal(llm.seen.length, 1);
  assert.ok(result.text.includes("梳理"), "输出必须锚定在选项文本上");
});

test("模型回执 [无法推断] → 转为 cannot_infer", async () => {
  const llm = fakeLlm(textChunks(SIGNAL_FALLBACK_MARKER));
  const assistantTail = { role: "assistant", text: "要不要继续？1. 继续梳理 2. 先停" };
  const result = await optimizePromptText({ llm, route: ROUTE, text: "1", assistantTail });
  assert.equal(result.ok, false);
  assert.equal(result.code, ERROR_CODES.CANNOT_INFER);
});

test("信号输出未锚定上下文 → cannot_infer", async () => {
  const llm = fakeLlm(textChunks("帮我重新部署服务器并检查全部日志。"));
  const assistantTail = { role: "assistant", text: "要不要继续？1. 继续梳理剩余功能 2. 先停下来" };
  const result = await optimizePromptText({ llm, route: ROUTE, text: "1", assistantTail });
  assert.equal(result.ok, false);
  assert.equal(result.code, ERROR_CANNOT_INFER_REF(), "无锚点的输出宁可拒绝");
});

function ERROR_CANNOT_INFER_REF() {
  return ERROR_CODES.CANNOT_INFER;
}

test("信号词 继续 + 助手待续提议 → 展开为放行动作", async () => {
  const llm = fakeLlm(textChunks("继续，按刚才说的把插件发到 npm。"));
  const assistantTail = { role: "assistant", text: "已经打包好了，要不要继续发布到 npm？" };
  const result = await optimizePromptText({ llm, route: ROUTE, text: "继续", assistantTail });
  assert.equal(result.ok, true);
  assert.equal(result.mode, "signal");
  assert.ok(result.text.includes("npm"));
});

test("短指令无上下文 → cannot_infer，零模型调用", async () => {
  const llm = fakeLlm([]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "改一下" });
  assert.equal(result.ok, false);
  assert.equal(result.code, ERROR_CODES.CANNOT_INFER);
  assert.equal(llm.seen.length, 0);
});

test("短指令 + 上下文 → 有度展开，动词逐字保留", async () => {
  const llm = fakeLlm(textChunks("把刚才那个按钮的红色再改一下，先给我两三个候选颜色。"));
  const context = [{ role: "user", text: "刚才把按钮颜色改成了红色" }];
  const result = await optimizePromptText({ llm, route: ROUTE, text: "改一下", context });
  assert.equal(result.ok, true);
  assert.equal(result.mode, "deictic");
  assert.ok(result.text.includes("改"), "动词必须逐字保留");
  assert.ok(result.text.length <= 180);
  assert.equal(llm.seen.length, 1);
});

test("短指令发散越界 → 一次收紧重试，成功则带 repairs=1", async () => {
  const overlong = "把按钮改成 #2F6FED，同步更新 hover 态、禁用态、加载态的配色，把全站色彩统一到新的设计规范，重做图标体系，调整间距与圆角，补充完整的变更说明文档，并把这次改动写进里程碑计划、通知设计团队评审、安排灰度发布与回滚预案，同时把导航栏和侧边栏也一起重构，输出迁移计划与风险清单，顺便把首页的营销位、活动页和落地页也按同一套视觉重新排版，拉齐埋点口径与数据看板，最后组织一次全员设计走查确认无遗漏再上线。";
  assert.ok(overlong.length > 180, "测试前提：越界文本必须真的超过 180 字上限（实际 " + overlong.length + "）");
  const llm = scriptedLlm([
    textChunks(overlong),
    textChunks("把刚才那个按钮的颜色再改一下，先给我几个候选。"),
  ]);
  const context = [{ role: "user", text: "刚才把按钮颜色改成了红色" }];
  const result = await optimizePromptText({ llm, route: ROUTE, text: "改一下", context });
  assert.equal(result.ok, true);
  assert.equal(result.gate.repairs, 1);
  assert.equal(result.gate.rechecked, true);
  assert.equal(llm.seen.length, 2);
});

test("短指令两次越界 → fidelity_rejected", async () => {
  const overlong = "把按钮改成 #2F6FED，同步更新 hover 态、禁用态、加载态的配色，把全站色彩统一到新的设计规范，重做图标体系，调整间距与圆角，补充完整的变更说明文档，并把这次改动写进里程碑计划、通知设计团队评审、安排灰度发布与回滚预案，同时把导航栏和侧边栏也一起重构，输出迁移计划与风险清单，并把页脚、弹窗、下拉菜单、表格、表单控件全部对齐同一套设计 token，生成前后对比截图。";
  assert.ok(overlong.length > 180, "测试前提：越界文本必须真的超过 180 字上限");
  const llm = scriptedLlm([textChunks(overlong), textChunks(overlong)]);
  const context = [{ role: "user", text: "刚才把按钮颜色改成了红色" }];
  const result = await optimizePromptText({ llm, route: ROUTE, text: "改一下", context });
  assert.equal(result.ok, false);
  assert.equal(result.code, ERROR_CODES.FIDELITY_REJECTED);
});

test("短指令指代消解失败回执 → cannot_infer", async () => {
  const llm = fakeLlm(textChunks(DEICTIC_FALLBACK_MARKER));
  const context = [{ role: "user", text: "随便一段无关上下文" }];
  const result = await optimizePromptText({ llm, route: ROUTE, text: "改一下", context });
  assert.equal(result.ok, false);
  assert.equal(result.code, ERROR_CODES.CANNOT_INFER);
});

test("extractAssistantTail 提取最近助手文本话轮并跳过空内容", () => {
  const surface = {
    events: [
      { type: "user/message", data: { role: "user", content: "帮我看看" } },
      { type: "assistant/message", data: { role: "assistant", content: [{ type: "text", text: "" }] } },
      { type: "assistant/message", data: { role: "assistant", content: [{ type: "text", text: "要不要继续？1. 继续 2. 停" }] } },
    ],
  };
  const tail = extractAssistantTail(surface);
  assert.equal(tail?.role, "assistant");
  assert.ok(tail.text.includes("要不要继续"));
  assert.equal(extractAssistantTail(null), undefined);
  assert.equal(extractAssistantTail({ events: [] }), undefined);
});

test("inferPendingItem 优先级：选项 > 助手问题 > 用户未答问题", () => {
  const assistantTail = { role: "assistant", text: "要继续吗？1. 打包 2. 先停" };
  assert.equal(inferPendingItem({ kind: "number", token: "1" }, undefined, assistantTail).mode, "choice");
  const question = { role: "assistant", text: "这个月几号发布？" };
  assert.equal(inferPendingItem({ kind: "number", token: "15" }, undefined, question).mode, "answer");
  const userQ = [{ role: "user", text: "这个插件叫什么名字？" }];
  assert.equal(inferPendingItem({ kind: "number", token: "42" }, userQ, undefined).mode, "continue");
  assert.equal(inferPendingItem({ kind: "deictic", token: "改一下" }, undefined, undefined).mode, "none");
});

test("checkDeicticDegree 的动词守恒与上限独立可测", () => {
  assert.equal(checkDeicticDegree("把红色再改一下，给我候选色。", "改一下").ok, true);
  assert.equal(checkDeicticDegree("调整一下样式。", "改一下").reason, "verb_missing");
  assert.equal(checkDeicticDegree("x".repeat(200), "改一下").reason, "overlong");
  assert.equal(checkSignalOutput("继续梳理。", "1", "继续梳理剩余功能", "choice").ok, true);
  assert.equal(checkSignalOutput("十五号。", "15", "几号发布？", "answer").reason, "token_missing");
});

// --------------------------------------------------------------------------
// 会话消息分支（0.9.1）
// --------------------------------------------------------------------------

import { isConversationalMessage } from "../src/signal-inference.js";

test("isConversationalMessage 识别真实病灶输入", () => {
  // 真实事故样本（日志原句）
  assert.equal(isConversationalMessage("还有一些问题，刚才我想问你的准确的是如何进行开源？是直接把仓库上传到GitHub上吗？"), true);
  assert.equal(isConversationalMessage("但是我为什么觉得实际优化效果好像还不如之前的？这是怎么回事？"), true);
  assert.equal(isConversationalMessage("你继续看一下这个项目，梳理一下现在的进度和代码结构，然后告诉我该怎么继续推进。"), true);
  assert.equal(isConversationalMessage("我觉得深度模式的输出还是太长了"), true);
  assert.equal(isConversationalMessage("这个方案该不该现在就定下来？"), true);
});

test("isConversationalMessage 不吞种子和精确指令", () => {
  assert.equal(isConversationalMessage("帮我做个图片压缩的功能"), false);
  assert.equal(isConversationalMessage("给设置页加个深色模式开关"), false);
  assert.equal(isConversationalMessage("怎么做一个图片压缩功能？"), false, "带任务动词的问句是种子");
  assert.equal(isConversationalMessage("删除 src/utils/legacy.js 里未被引用的 export，跑一遍测试确认没破坏"), false);
  assert.equal(isConversationalMessage("登录"), false);
});

test("describeMode 覆盖 conversational", () => {
  assert.equal(describeMode("这是怎么回事？"), "conversational");
  assert.equal(describeMode("帮我做个功能"), null);
});

test("会话消息模型原样返回 → 未改动，单次调用", async () => {
  const input = "还有一些问题，刚才我想问你的准确的是如何进行开源？";
  const llm = fakeLlm(textChunks(input));
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true);
  assert.equal(result.mode, "conversational");
  assert.equal(result.text, input);
  assert.ok(result.detail.includes("未改动"));
  assert.equal(llm.seen.length, 1);
});

test("会话消息轻润色在限度内 → 采纳润色稿", async () => {
  const input = "还有一些问题，刚才我想问你的准确的是如何进行开源？";
  const polished = "还有一个问题：刚才我想问你的准确的是如何进行开源？";
  const llm = fakeLlm(textChunks(polished));
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true);
  assert.equal(result.text, polished);
  assert.ok(result.text.length <= Math.ceil(input.length * 1.35) + 6);
});

test("会话消息被模型改写成任务书 → 越限两次 → 兜底返回原文（永不拒绝）", async () => {
  const input = "刚才我想问的准确的是如何进行开源？";
  const taskSpec = "请评估开源流程：第一步在 GitHub 创建公开仓库并推送 main 分支；第二步执行 npm publish --access public 发布安装包；第三步向 awesome-dsh-plugin 提交收录 PR，并附上一句话英文描述与安装验证命令，确保 dsh plugin add 可直接安装；第四步在 README 中补齐双语说明与徽章。";
  const llm = scriptedLlm([textChunks(taskSpec), textChunks(taskSpec)]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true, "会话消息分支永不拒绝");
  assert.equal(result.text, input, "改不好就还原文");
  assert.equal(llm.seen.length, 2, "一次收紧重试后兜底");
});

test("会话消息越限后收敛 → 采纳收敛稿并记 repairs=1", async () => {
  const input = "刚才我想问的准确的是如何进行开源？";
  const overlong = "请评估开源流程：第一步在 GitHub 创建公开仓库并推送 main 分支；第二步执行 npm publish --access public 发布安装包；第三步向 awesome-dsh-plugin 提交收录 PR，并补齐双语 README 与徽章，确保 dsh plugin add 可直接安装；第四步通知社区目录站抓取。";
  const tightened = "刚才我想问的准确的是：该如何进行开源？";
  const llm = scriptedLlm([textChunks(overlong), textChunks(tightened)]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true);
  assert.equal(result.text, tightened);
  assert.equal(result.gate.repairs, 1);
});

// --------------------------------------------------------------------------
// 共享消息文本转换（T001 去重）
// --------------------------------------------------------------------------

import { messageTextOf } from "../src/message-text.js";

test("messageTextOf 处理字符串 / 块数组 / 形状漂移", () => {
  assert.equal(messageTextOf("hello"), "hello");
  assert.equal(messageTextOf([{ type: "text", text: "a" }, { type: "text", text: "b" }]), "a b");
  assert.equal(messageTextOf([{ type: "tool", text: "x" }, { type: "text", text: "keep" }]), "keep");
  assert.equal(messageTextOf([{ type: "text", text: 42 }]), "", "非字符串 text 必须丢弃");
  assert.equal(messageTextOf(null), "");
  assert.equal(messageTextOf(undefined), "");
  assert.equal(messageTextOf({ type: "text", text: "x" }), "", "非数组对象不是合法消息内容");
  assert.equal(messageTextOf([null, "raw", { type: "text", text: "y" }]), "y");
});

test("两个话轮提取器共用同一份文本转换（去重回归守卫）", () => {
  const content = [{ type: "text", text: "共享实现" }, { type: "tool", text: "ignored" }];
  const userSurface = { events: [{ type: "user/message", data: { role: "user", content } }] };
  const assistantSurface = { events: [{ type: "assistant/message", data: { role: "assistant", content } }] };
  assert.equal(extractRecentContext(userSurface)?.[0]?.text, "共享实现");
  assert.equal(extractAssistantTail(assistantSurface)?.text, "共享实现");
});

// --------------------------------------------------------------------------
// T002：信号/短指令/会话三个契约的覆盖入口（此前不可达：键被读取但文件从不加载）
// --------------------------------------------------------------------------

import {
  buildConversationalSystemPrompt,
  buildDeicticSystemPrompt,
  buildSignalSystemPrompt,
} from "../src/prompt-templates.js";

test("三个新契约的构建器读取各自的覆盖键", () => {
  setTemplateOverrides({
    signalSystem: "SIGNAL OVERRIDE",
    deicticSystem: "DEICTIC OVERRIDE",
    conversationalSystem: "CONVERSATIONAL OVERRIDE",
  });
  assert.ok(buildSignalSystemPrompt().startsWith("SIGNAL OVERRIDE"));
  assert.ok(buildDeicticSystemPrompt().startsWith("DEICTIC OVERRIDE"));
  assert.ok(buildDeicticSystemPrompt({ tightened: true }).startsWith("DEICTIC OVERRIDE"), "收紧后缀叠加在覆盖文本之后");
  assert.ok(buildConversationalSystemPrompt().startsWith("CONVERSATIONAL OVERRIDE"));
  assert.ok(buildConversationalSystemPrompt({ tightened: true }).startsWith("CONVERSATIONAL OVERRIDE"));
  setTemplateOverrides(null);
  assert.ok(buildSignalSystemPrompt().includes("You turn a bare signal"), "归还后回落内置");
  assert.ok(buildConversationalSystemPrompt().includes("You tidy up a conversational message"));
});

test("T002 会话契约覆盖文件真的进入 system prompt（此前放文件完全无效）", async () => {
  const host = await import("../lib/index.js");
  const dir = await mkdtemp(join(tmpdir(), "po-conv-override-"));
  const previous = process.env.DSH_HOME;
  process.env.DSH_HOME = dir;
  try {
    const prompts = join(dir, "prompt-seed", "prompts");
    await mkdir(prompts, { recursive: true });
    await writeFile(join(prompts, "conversational.md"), "CONVERSATIONAL OVERRIDE CONTRACT", "utf8");
    const llm = scriptedLlm([textChunks("这是怎么回事？")]);
    const webServer = makeWebServer();
    host.apply(makeHostContext(webServer, { llm }), { samples: false });
    const res = makeResponse();
    await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "这是怎么回事？" }) }), res);
    assert.equal(res.statusCode, 200);
    assert.equal(llm.seen.length, 1, "会话分支应产生一次调用");
    assert.ok(llm.seen[0].system.startsWith("CONVERSATIONAL OVERRIDE CONTRACT"), "覆盖文件必须进入 system prompt");
    setTemplateOverrides(null);
  } finally {
    if (previous === undefined) delete process.env.DSH_HOME;
    else process.env.DSH_HOME = previous;
    await rm(dir, { recursive: true, force: true });
  }
});

// --------------------------------------------------------------------------
// T004：sample-log 未覆盖边界
// --------------------------------------------------------------------------

test("T004 sample-log 边界：非字符串 input、不可写目标", async () => {
  const dir = await mkdtemp(join(tmpdir(), "po-samples-edge-"));
  try {
    const file = join(dir, "nested", "s.jsonl");
    // 缺 input 字段：仍要写成功，input 落空串，其余字段原样保留
    assert.equal(await appendSample(file, { time: "t", code: "ok" }), true);
    let record = JSON.parse((await readFile(file, "utf8")).trim());
    assert.equal(record.input, "", "缺 input 字段时落空串");
    assert.equal(record.code, "ok", "其余字段不能被丢");

    // number 型 input：同样落空串而不是抛
    assert.equal(await appendSample(file, { input: 42 }), true);
    const last = JSON.parse((await readFile(file, "utf8")).trim().split("\n").pop());
    assert.equal(last.input, "", "number 型 input 落空串");

    // 目标是已存在的目录：写入必然失败，必须静默返回 false
    const asDir = join(dir, "adir");
    await mkdir(asDir, { recursive: true });
    assert.equal(await appendSample(asDir, { input: "x" }), false, "目标是目录时静默失败");
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test("T004 resolveSamplePath 退化：空白 DSH_HOME 回落 homedir，非路径值走默认", () => {
  const previous = process.env.DSH_HOME;
  try {
    process.env.DSH_HOME = "   ";
    const fallback = resolveSamplePath(undefined);
    assert.ok(fallback.endsWith(join(".dsh", "prompt-seed", "samples.jsonl")), "空白 DSH_HOME 必须回落 homedir");
    assert.equal(resolveSamplePath(true), fallback, "true 不是自定义路径");
    assert.equal(resolveSamplePath(""), fallback, "空串不是自定义路径");
    assert.equal(resolveSamplePath("  "), fallback, "空白串不是自定义路径");
    assert.equal(resolveSamplePath("/x/y.jsonl"), "/x/y.jsonl", "自定义路径原样返回");
  } finally {
    if (previous === undefined) delete process.env.DSH_HOME;
    else process.env.DSH_HOME = previous;
  }
});

// --------------------------------------------------------------------------
// T005：session-context 形状漂移与取序边界
// --------------------------------------------------------------------------

test("T005 session-context 形状漂移：任何非法结构都降级为无上下文", () => {
  assert.equal(extractRecentContext({ events: "nope" }), undefined, "events 非数组");
  assert.equal(extractRecentContext({ events: { 0: {} } }), undefined, "events 是对象不是数组");
  assert.equal(
    extractRecentContext({ events: [null, 42, "x", {}, { type: "user/message" }, { type: "user/message", data: null }] }),
    undefined,
    "垃圾节点与半截节点必须全部跳过",
  );
  assert.equal(
    extractRecentContext({ events: [{ type: "user/message", data: { role: "assistant", content: "x" } }] }),
    undefined,
    "角色不是 user 的消息不是用户话轮",
  );
  assert.equal(
    extractRecentContext({ events: [{ type: "user/message", data: { role: "user", content: [] } }] }),
    undefined,
    "空内容不算话轮",
  );
  assert.equal(
    extractRecentContext({ events: [{ type: "user/message", data: { role: "user", content: [{ type: "tool", text: "x" }] } }] }),
    undefined,
    "只有非 text 块时文本为空",
  );
  assert.equal(
    extractRecentContext({ events: [{ type: "user/message", data: { role: "user", content: "   \n  " } }] }),
    undefined,
    "纯空白话轮不入上下文",
  );
});

test("T005 只保留最近两条真实话轮；source 缺失按真实话轮处理", () => {
  const mk = (t, kind) => ({
    type: "user/message",
    data: { role: "user", ...(kind === "none" ? {} : { source: { kind } }), content: [{ type: "text", text: t }] },
  });
  const surface = { events: [mk("第一条", "user"), mk("第二条", "user"), mk("第三条", "user")] };
  assert.deepEqual(
    extractRecentContext(surface).map((m) => m.text),
    ["第二条", "第三条"],
    "只取最近两条，且按时间正序返回",
  );
  const noSource = { events: [mk("没有 source 字段", "none")] };
  assert.deepEqual(
    extractRecentContext(noSource).map((m) => m.text),
    ["没有 source 字段"],
    "source.kind 缺失时按真实用户话轮处理（只有显式非 user 才跳过）",
  );
});

// --------------------------------------------------------------------------
// T006：cannot_infer 的前端呈现（设计内的中性拒绝，不是故障）
// --------------------------------------------------------------------------

test("T006 cannot_infer 在客户端走 declined 中性态，不是红色错误态", async () => {
  const source = await readFile(join(root, "lib", "client.js"), "utf8");
  assert.ok(source.includes("cannot_infer"), "客户端必须认识这个码，否则会当未知错误处理");
  // 分支内部必须是 setDeclined（中性盾），不能是 setError（红色 ⚠）——
  // 拒绝硬猜是系统按设计工作，报成故障会让用户以为插件坏了。
  assert.ok(/cannot_infer[\s\S]{0,220}setDeclined/.test(source), "cannot_infer 必须走 declined");
  assert.ok(!/cannot_infer[\s\S]{0,220}setError/.test(source), "cannot_infer 不能走 error");
  // 兜底仍在：未知码必须还能报错，而不是静默吞掉
  assert.ok(source.includes("setError((res && res.error) || tr('err_fallback'))"), "未知码兜底必须保留");
});

// --------------------------------------------------------------------------
// T009：目录就绪缓存（性能）与其失效路径
// --------------------------------------------------------------------------

test("T009 目录缓存：目录被外部删除后，下一次写入必须自愈", async () => {
  const parent = await mkdtemp(join(tmpdir(), "po-dircache-"));
  const dir = join(parent, "nested");
  const file = join(dir, "s.jsonl");
  try {
    assert.equal(await appendSample(file, { input: "第一次" }), true, "首次写入须自建目录");
    // 目录被外部删除（进程内缓存仍记着它已就绪）
    await rm(dir, { recursive: true, force: true });
    assert.equal(await appendSample(file, { input: "第二次" }), true, "缓存失效后必须重建目录并写入");
    const lines = (await readFile(file, "utf8")).trim().split("\n");
    assert.equal(lines.length, 1, "旧目录已删，只剩重建后的这一条");
    assert.equal(JSON.parse(lines[0]).input, "第二次");
  } finally {
    await rm(parent, { recursive: true, force: true });
  }
});

// --------------------------------------------------------------------------
// T010：会话分支与 depth/上下文的交互矩阵
// --------------------------------------------------------------------------

test("T010 会话分支：depth 不改变契约，上下文刻意不注入", async () => {
  const llm = fakeLlm(textChunks("这是怎么回事？"));
  const res = await optimizePromptText({
    llm,
    route: ROUTE,
    text: "这是怎么回事？",
    depth: "deep",
    context: [{ role: "user", text: "刚才说的是打包脚本的问题" }],
  });
  assert.equal(res.ok, true);
  assert.equal(res.mode, "conversational", "提问走会话分支");
  assert.equal(llm.seen.length, 1, "会话分支只调用一次");
  const system = llm.seen[0].system;
  assert.ok(system.includes("conversational message"), "必须是轻润色契约");
  assert.ok(!system.includes("You expand prompts"), "绝不能进入补全契约");
  assert.ok(!/depth|深度/i.test(system), "depth 后缀不得进入会话契约");
  const user = llm.seen[0].messages[0].content;
  assert.ok(!user.includes("刚才说的是打包脚本的问题"), "会话分支刻意不携带上下文，堵死\"用上下文补内容\"的路径");
});

test("T010 提问里带路径与标识符，仍走会话分支（有意的前置优先级）", async () => {
  const text = "src/utils/format.js 里的 formatBytes 为什么返回了负数？";
  const llm = fakeLlm(textChunks(text));
  const res = await optimizePromptText({ llm, route: ROUTE, text });
  assert.equal(res.mode, "conversational");
  assert.ok(llm.seen[0].system.includes("conversational message"), "提问就是提问，不因为提到文件而变成待补全的种子");
  assert.equal(res.text, text, "原样返回（本例模型回显输入）");
});

// --------------------------------------------------------------------------
// T012：错误码与用户文案的完备性
// --------------------------------------------------------------------------

import { ERROR_MESSAGES } from "../src/host-core.js";

test("T012 每个错误码都有面向用户的中文文案，且没有孤儿文案", () => {
  const codes = Object.values(ERROR_CODES);
  for (const code of codes) {
    const message = ERROR_MESSAGES[code];
    assert.equal(typeof message, "string", `错误码 ${code} 缺文案（界面会显示原始 code）`);
    assert.ok(message.trim().length > 0, `错误码 ${code} 的文案为空`);
    assert.ok(/[\u4e00-\u9fff]/.test(message), `错误码 ${code} 的文案应面向用户（中文），当前为：${message}`);
  }
  for (const key of Object.keys(ERROR_MESSAGES)) {
    assert.ok(codes.includes(key), `文案 ${key} 没有对应的错误码（孤儿条目）`);
  }
  assert.ok(codes.length >= 10, "错误码数量骤降说明有码被误删（10 = 现存全部，stale/unknown 已作为死码移除）");
});

// --------------------------------------------------------------------------
// T013：debug 路由字段与不变量
// --------------------------------------------------------------------------

test("T013 ?debug=1 附带形状而非上下文原文；开关关闭时不出现", async () => {
  const host = await import("../lib/index.js");
  const pkg = JSON.parse(await readFile(join(root, "package.json"), "utf8"));
  const webServer = makeWebServer();
  const surfaceText = "上一轮说的是把接口的限流参数调大";
  const llm = scriptedLlm([textChunks("请把那个接口的限流参数调整一下。"), textChunks("OK")]);
  host.apply(
    makeHostContext(webServer, {
      llm,
      sessionQuery: {
        readSurface: () =>
          Promise.resolve({
            events: [
              { type: "user/message", data: { role: "user", source: { kind: "user" }, content: [{ type: "text", text: surfaceText }] } },
            ],
          }),
      },
    }),
    { samples: false },
  );
  const route = webServer.routes[0];

  const req = makeRequest({ body: JSON.stringify({ text: "把那个接口改一下", sessionId: "s-dbg" }) });
  req.url = "/?debug=1";
  const res = makeResponse();
  await route.handler(req, res);
  assert.equal(res.statusCode, 200);
  const body = JSON.parse(res.body);
  assert.ok(body._debug, "?debug=1 必须附带 _debug");
  assert.equal(body._debug.codeVersion, pkg.version, "codeVersion 必须等于当前包版本（排障第一证据）");
  assert.equal(body._debug.sessionId, "s-dbg");
  assert.equal(body._debug.contextMessages, 1, "上下文条数按形状统计");
  assert.equal(body._debug.contextChars, surfaceText.length, "上下文字符数按形状统计");
  assert.equal(body._debug.provider, "p");
  assert.equal(body._debug.model, "m");
  assert.equal(body._debug.samplePath, null, "samples:false 时路径为空");
  assert.ok(
    !JSON.stringify(body._debug).includes(surfaceText),
    "调试字段只带形状，绝不带上下文原文（回环限定也不等于可以泄露草稿内容）",
  );

  const req2 = makeRequest({ body: JSON.stringify({ text: "把那个接口改一下", sessionId: "s-dbg" }) });
  const res2 = makeResponse();
  await route.handler(req2, res2);
  assert.equal(JSON.parse(res2.body)._debug, undefined, "未开开关时不得出现调试字段");
});

// --------------------------------------------------------------------------
// T015：五状态的优先级链与呈现约束
//
// 说明：客户端组件内部状态由异步响应驱动，而渲染测试用的是极简 React 替身
// （useState 不产生更新），因此这里断言**产物级不变量**——优先级链、每态的
// 颜色与动画、条件入口——而不是逐态的真实迁移。链的顺序本身即语义：
// 调换顺序会让一种状态永久遮住另一种。
// --------------------------------------------------------------------------

test("T015 五状态优先级链与各态呈现约束", async () => {
  const source = await readFile(join(root, "lib", "client.js"), "utf8");
  assert.ok(
    /busy \? 'busy' : isRevertMode \? 'revert' : declined !== '' \? 'declined' : error !== '' \? 'error' : 'idle'/.test(source),
    "优先级链必须是 busy > revert > declined > error > idle",
  );
  assert.ok(
    source.includes('.dsh-seed-btn[data-mode="declined"]{color:var(--dsw-alias-label-secondary);}'),
    "拒绝态必须中性（不是红色——拒绝硬猜是设计内行为）",
  );
  assert.ok(
    source.includes('.dsh-seed-btn[data-mode="error"]{color:var(--dsw-alias-state-error-primary);}'),
    "错误态必须用 error 色",
  );
  assert.ok(
    /\.dsh-seed-btn\[data-mode="revert"\]\{[^}]*color:var\(--dsw-alias-brand-primary\);[^}]*\}/.test(source),
    "可恢复态必须用品牌色",
  );
  assert.ok(
    /data-mode="busy"\][^{]*\{animation:/.test(source),
    "busy 必须有旋转动画（唯一的持续视觉信号）",
  );
  assert.ok(
    source.includes("if (mode === 'declined' && rejected !== '')"),
    "查看被拒稿的入口只在拒绝态且确有被拒稿时出现",
  );
  assert.ok(
    source.includes("'data-glow': mode === 'idle' && hasContent ? '1' : '0'"),
    "微光只在 idle 且有内容时出现",
  );
});

// --------------------------------------------------------------------------
// T017：审计 fail-open 与 THIN 分支的组合矩阵
// --------------------------------------------------------------------------

test("T017 审计无法解析 → fail-open 接受改写稿（不因解析失败而拒绝）", async () => {
  const llm = scriptedLlm([
    textChunks("请检查这段代码是否存在问题，并说明出现在哪里。"),
    textChunks("这段话说得不太清楚，我重新讲一遍……"), // 既非 OK 也非任何 KIND 行
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "帮我看看这段代码" });
  assert.equal(result.ok, true, "审判解析失败必须 fail-open");
  assert.equal(result.text, "请检查这段代码是否存在问题，并说明出现在哪里。");
  assert.equal(llm.seen.length, 2, "只发改写 + 审判两次调用（不因 fail-open 多跑）");
  assert.equal(result.tier, "full");
});

test("T017 THIN 只对种子再补一次：非种子输入被报 THIN 时不追加调用", async () => {
  const draft = "删除 src/utils/legacy.js 中未被引用的导出，然后运行一遍测试，确认没有破坏任何功能。";
  const llm = scriptedLlm([textChunks(draft), textChunks("THIN: 只改了措辞")]);
  const result = await optimizePromptText({
    llm,
    route: ROUTE,
    text: "删除 src/utils/legacy.js 里未被引用的 export，跑一遍测试确认没破坏",
  });
  assert.equal(result.ok, true);
  assert.equal(llm.seen.length, 2, "带路径锚定的输入被报 THIN 不值得再花调用（审判误报居多）");
  assert.equal(result.text, draft);
});

test("T017 THIN → 补全 → 二次审判失真：回退薄但忠实的第一稿", async () => {
  const first = "请检查这段代码是否存在问题，并说明出现在哪里。";
  const elaborated = "请检查这段代码是否存在问题，说明出现在哪里，并顺带评估整个项目的测试覆盖率和发布计划。";
  const llm = scriptedLlm([
    textChunks(first),
    textChunks("THIN: 只改了措辞"),
    textChunks(elaborated),
    textChunks("SCOPE_ADDED: 追加了测试覆盖率与发布计划"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "帮我看看这段代码" });
  assert.equal(result.ok, true, "薄但忠实优于直接拒绝");
  assert.equal(result.text, first, "补全越线时必须回退第一稿");
  assert.equal(result.tier, "thin");
  assert.equal(result.gate.verdict, "thin");
  assert.equal(llm.seen.length, 4, "改写 + 审判 + 补全 + 二次审判");
});

test("T017 两道审判的 fail-open 方向相反：第一道放行，第二道保守回退", async () => {
  // 这是**有意的不对称**，且此前没有测试钉住它：
  //   第一道审判解析失败 → fail-open，接受改写稿（闸门是纵深防御，不是唯一机制）；
  //   第二道审判解析失败 → 保守，回退薄但忠实的第一稿。
  // 理由：第二道审判存在的唯一目的就是验证"补全没有越线"。它无法解析时，
  // 补全稿就是**未经验证**的；而本产品的前提正是"闸门让补全安全"。宁可薄，
  // 不可把未验证的加料交付出去。
  const first = "请检查这段代码是否存在问题，并说明出现在哪里。";
  const elaborated = "请检查这段代码是否存在问题，说明出现在哪里，并指出你判断的依据。";
  const llm = scriptedLlm([
    textChunks(first),
    textChunks("THIN: 只改了措辞"),
    textChunks(elaborated),
    textChunks("嗯，我觉得这版还行吧。"), // 解析不出任何 KIND 行
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "帮我看看这段代码" });
  assert.equal(result.ok, true, "仍然交付（不拒绝）");
  assert.equal(result.text, first, "第二道审判无法解析时必须回退第一稿");
  assert.equal(result.tier, "thin");
  assert.equal(result.gate.rechecked, false);
  assert.equal(llm.seen.length, 4);
});

// --------------------------------------------------------------------------
// T022：带重渲染能力的 React 替身 —— 驱动真实的响应路径
// --------------------------------------------------------------------------

test("T022 驱动完整响应：cannot_infer 必须渲染成 declined 中性态而不是 error", async () => {
  // 与 T006 的产物断言不同，harness 会真的走完 onClick → fetch → setState → 重渲染。
  const CANNOT_INFER_MESSAGE = "上下文不足以推断这个输入的含义，请直接写出想说的内容";
  const h = await makeClientHarness({
    draft: "42",
    fetchImpl: () => Promise.resolve({ json: () => Promise.resolve({ ok: false, code: "cannot_infer", error: CANNOT_INFER_MESSAGE }) }),
  });
  try {
    assert.equal(h.tree.props["data-mode"], "idle", "初始应为 idle");
    assert.equal(typeof h.tree.props.onClick, "function", "主按钮必须可点击");
    h.tree.props.onClick();
    await h.settle();
    assert.equal(h.tree.props["data-mode"], "declined", "cannot_infer 必须落到中性盾态");
    const title = String(h.tree.props.title || "");
    assert.ok(title.includes("无法推断") || title.includes("上下文不足"), "tooltip 必须给出可读原因，当前：" + title);
    assert.deepEqual(h.writes, [], "拒绝路径绝不能写回草稿");
  } finally {
    h.restore();
  }
});
// --------------------------------------------------------------------------
// T023：三个启发式在共享边界输入上的一致性
// --------------------------------------------------------------------------

test("T023 looksOpenEnded / looksSeedish 的边界与超集关系", () => {
  const zh = (n) => "帮".repeat(n);
  const cases = [
    { text: "", openEnded: false, seedish: false, note: "空输入两者皆假" },
    { text: "登录", openEnded: true, seedish: true, note: "2 字无锚定：下限刻意极低" },
    { text: zh(40), openEnded: true, seedish: true, note: "40 字整：仍在短句阈值内" },
    { text: zh(41), openEnded: false, seedish: true, note: "41 字：超出开放式阈值，但仍在种子阈值（60）内" },
    { text: zh(60), openEnded: false, seedish: true, note: "60 字整：种子的上界" },
    { text: zh(61), openEnded: false, seedish: false, note: "61 字无锚定：不再是种子" },
    { text: "为什么这么说？", openEnded: true, seedish: true, note: "问句形态无视长度" },
    { text: "把 src/a.js 改一下，跑一遍测试确认没破坏", openEnded: false, seedish: false, note: "带路径与扩展名：事实锚定即非种子" },
    { text: "这个月 15 号之前能不能给个版本？", openEnded: true, seedish: true, note: "问句形态优先于数字锚定" },
  ];
  for (const c of cases) {
    assert.equal(looksOpenEnded(c.text), c.openEnded, `looksOpenEnded(${JSON.stringify(c.text.slice(0, 12))}…) — ${c.note}`);
    assert.equal(looksSeedish(c.text), c.seedish, `looksSeedish(${JSON.stringify(c.text.slice(0, 12))}…) — ${c.note}`);
    if (looksOpenEnded(c.text)) {
      assert.ok(looksSeedish(c.text), "开放式必须是种子的子集：开放 ⟹ 种子（否则 THIN 重试与补全闸会各判一套）");
    }
  }
});

test("T023 assessInflation 的边界：空输入不抛且比值有限；形态指标只告警不判定", () => {
  assert.equal(assessInflation("", "").ratio, 0);
  const long = assessInflation("", "x".repeat(10));
  assert.ok(Number.isFinite(long.ratio) && long.ratio === 10, "空输入按长度 1 兜底，比值仍有限");
  assert.equal(long.bloated, true, "空输入被算作膨胀——但管线在更早的确定性闸门就拦下了空输入，此处仅记录语义");
  // 长输入不再算膨胀（阈值保护：长草稿本来就会更长大）
  const big = "字".repeat(250);
  assert.equal(assessInflation(big, big + "字".repeat(1000)).bloated, false, "超过 200 字的输入不参与膨胀告警");
  // 开放式被闭合：判的是 OPEN_ENDED_PATTERN 与 DELIVERABLE_PATTERN 的**交集**，
  // 不是 looksOpenEnded（后者还含问句形态）——用问句样本会得到 false，这个口径差异值得写明。
  const closed = assessInflation("帮我看看这个模块的性能", "请检查该模块的性能，并输出一份性能对比表格与优化实施计划。");
  assert.equal(closed.openEndedClosed, true, "开放式被闭合必须被标出（历史上的跑偏形态）");
  assert.equal(closed.suspicious, true);
  const questionOnly = assessInflation("这个能优化吗？", "请检查该模块并输出一份性能对比表格。");
  assert.equal(questionOnly.openEndedClosed, false, "问句形态不在 OPEN_ENDED_PATTERN 内，故不触发闭合告警（判定口径与 looksOpenEnded 不同）");
});

// --------------------------------------------------------------------------
// T025：客户端行为测试 harness（自 T022 抽取）+ 网络失败路径
// --------------------------------------------------------------------------

/**
 * 客户端行为 harness：可重渲染的 React 替身 + slot 注册 + 可注入 fetch。
 *
 * 抽取原因：每加一条行为测试就复制一份桩，很快会出现"某个测试的桩修了、
 * 其它测试的没修"——而桩本身正是这些测试的可信度来源。
 *
 * 两条关键规则（缺一条就无限递归，实测踩过）：
 *   ① setState 只在微任务里重渲染；② effect 在渲染之后执行。
 * @param {{fetchImpl?: Function, draft?: string}} [options] 注入点。
 * @returns {Promise<object>} harness 句柄（tree/render/settle/writes/restore…）。
 */
/**
 * 运行时真实的"会话面"形状（client-probe 实测回传的 14 个字段）。
 *
 * 关键：它**没有** nodes / turnEnds —— 0.9.6 首版按 ConversationSnapshot 的
 * assistant 节点判断"有来有回"，在真实宿主上永远为 false，图标一次都没出现。
 * 夹具用真形状，避免测试替身把一个真实的形状错误掩盖成绿的。
 */
const SESSION_FACE = {
  sessionId: "s-test",
  pendingSubmissions: [],
  running: false,
  subagent: null,
  removed: false,
  openState: "ready",
  openError: null,
  hasMore: false,
  loadingOlder: false,
  promptError: null,
  blank: false,
  lastAgentError: null,
  promptAttempted: true,
  awaitingFirstTurn: false,
};

async function makeClientHarness(options = {}) {
  const source = await readFile(join(root, "lib", "client.js"), "utf8");
  // 注意：bundle 由 `new Function("window", source)` 注入，模块里的 window 指的是**传入的
  // 那个对象**，不是 globalThis.window。localStorage 必须挂在同一个对象上，否则模块内
  // 读到的永远是 undefined（readStored 静默回落 fallback）——这会悄悄让所有依赖本地
  // 状态的断言退化到默认路径。
  const storage = options.storage ?? {};
  const fakeWindow = {
    localStorage: {
      getItem: (key) => (key in storage ? JSON.stringify(storage[key]) : null),
      setItem(key, value) { storage[key] = JSON.parse(value); },
    },
  };
  let entry;
  new Function("window", source)(Object.assign(fakeWindow, { __ModuleLoader__: { load: (v) => { entry = v; } } }));

  const store = { hooks: [] };
  let cursor = 0;
  // effect 槽：真实 React 会按依赖数组决定是否重跑，桩必须同样处理——否则像
  // "草稿发散就丢弃撤销备份"这类依赖 [draft] 的 effect 永远只跑一次，
  // 组件会停在早就该失效的状态里，测试于是断言到一个不存在的世界。
  const effectSlots = new Map();
  let pendingEffects = [];
  let scheduled = false;
  let tree = null;
  let rerender = () => {};
  const scheduleRerender = () => {
    if (scheduled) return;
    scheduled = true;
    queueMicrotask(() => { scheduled = false; rerender(); });
  };
  const React = {
    createElement(type, props, children) {
      if (typeof type === "function") return type(props || {});
      return { type, props: props || {}, children: children === undefined ? [] : [].concat(children) };
    },
    useState(initial) {
      const i = cursor++;
      if (!(i in store.hooks)) store.hooks[i] = typeof initial === "function" ? initial() : initial;
      return [
        store.hooks[i],
        (value) => {
          store.hooks[i] = typeof value === "function" ? value(store.hooks[i]) : value;
          scheduleRerender();
        },
      ];
    },
    useRef(value) { const i = cursor++; if (!(i in store.hooks)) store.hooks[i] = { current: value }; return store.hooks[i]; },
    useEffect(fn, deps) { const i = cursor++; pendingEffects.push({ i, fn, deps }); },
    useCallback(fn) { return fn; },
    useMemo(fn) { return fn(); },
  };
  const exported = entry.factory(() => React);

  const previousFetch = globalThis.fetch;
  const previousWindow = globalThis.window;
  globalThis.window = fakeWindow;
  globalThis.fetch = options.fetchImpl ?? (() => Promise.reject(new Error("harness: no fetch stub")));

  const client = { draft: options.draft ?? "", draftRev: 1, phase: "plain", occurrences: options.occurrences ?? [] };
  const writes = [];
  const props = {
    useInput: (selector) => selector(client),
    inputActions: {
      setDraft(text) { writes.push(text); client.draft = text; },
      addAttachments() {},
      removeAttachment() {},
      pruneAttachments() {},
    },
    t: (key) => key,
    // 会话面的两条来源，都要覆盖：
    //   ① 真实宿主走 standard kit 的 useSession（探针实测：槽位**不下发** session prop，
    //      所以这条才是主线，options.session 在这里经 useSession 下发）；
    //   ② session prop 走 options.sessionProp（形状回归用，当前宿主并不提供）。
    session: options.sessionProp,
    useSession: options.session === undefined ? undefined : (selector) => selector(options.session),
  };

  const registered = [];
  const slots = {
    inject(name, cb) { registered.push({ name, value: cb() }); },
    register(meta, render) { return { meta, render }; },
  };
  // locale 服务（P1-7）：options.locale 提供时模拟 dsh-client-locale 的形状。
  exported.apply({
    slots,
    effect() {},
    get(name) { return name === "locale" && options.locale !== undefined ? { id: options.locale } : undefined; },
  });
  const component = registered[0].value.render;

  const render = () => {
    cursor = 0;
    pendingEffects = [];
    tree = component(props);
    for (const item of pendingEffects) {
      const previous = effectSlots.get(item.i);
      const sameDeps =
        previous !== undefined &&
        Array.isArray(item.deps) &&
        Array.isArray(previous.deps) &&
        item.deps.length === previous.deps.length &&
        item.deps.every((value, index) => Object.is(value, previous.deps[index]));
      // 无依赖数组 = 每次渲染都跑；有依赖 = 依赖变了才跑（Object.is 逐项比较）
      const shouldRun = previous === undefined || !Array.isArray(item.deps) || !sameDeps;
      if (!shouldRun) continue;
      if (typeof previous?.cleanup === "function") previous.cleanup();
      effectSlots.set(item.i, { deps: item.deps, cleanup: item.fn() });
    }
    return tree;
  };
  rerender = render;
  render();

  /** 深度优先按 data-testid 查找（revert 态下根节点不再是主按钮）。 */
  const findByTestId = (node, id) => {
    if (node === null || typeof node !== "object") return null;
    if (node.props && node.props["data-testid"] === id) return node;
    const children = [];
    if (Array.isArray(node.children)) children.push(...node.children);
    if (Array.isArray(node.props?.children)) children.push(...node.props.children);
    for (const child of children) {
      const found = findByTestId(child, id);
      if (found !== null) return found;
    }
    return null;
  };
  const visibleLabelText = (node) => {
    if (node === null || typeof node !== "object") return null;
    if (node.props?.className === "dsh-opt-label") {
      return Array.isArray(node.children)
        ? node.children.filter((child) => typeof child === "string").join("")
        : "";
    }
    const children = [];
    if (Array.isArray(node.children)) children.push(...node.children);
    if (Array.isArray(node.props?.children)) children.push(...node.props.children);
    for (const child of children) {
      const found = visibleLabelText(child);
      if (found !== null) return found;
    }
    return null;
  };
  const describe = () => {
    const seen = [];
    const walk = (node, depth) => {
      if (node === null || typeof node !== "object" || depth > 3) return;
      seen.push({ type: typeof node.type === "string" ? node.type : "fn", id: node.props?.["data-testid"] ?? null, mode: node.props?.["data-mode"] ?? null });
      const children = [];
      if (Array.isArray(node.children)) children.push(...node.children);
      if (Array.isArray(node.props?.children)) children.push(...node.props.children);
      for (const child of children) walk(child, depth + 1);
    };
    walk(tree, 0);
    return seen;
  };

  return {
    get tree() { return tree; },
    /** 主按钮：revert 态下也用它，而不是假设根节点就是按钮。 */
    primary() { return findByTestId(tree, "prompt-seed-button"); },
    /** 预测按钮（空输入框 + 有上下文的会话时它取代星标占用同一个位置）。 */
    predict() { return findByTestId(tree, "prompt-seed-predict-button"); },
    /** 图标旁的小字提示（失败 / 推不出来时才存在）。 */
    hint() { return findByTestId(tree, "prompt-seed-hint"); },
    byTestId(id) { return findByTestId(tree, id); },
    visibleLabel(node) { return visibleLabelText(node); },
    describe,
    render,
    client,
    writes,
    /** 模拟用户在等待期间改动草稿（draftRev 递增，触发 CAS 失效）。 */
    editDraft(text) { client.draft = text; client.draftRev += 1; },
    /** 让 fetch 的 then 链与排队中的重渲染跑完。 */
    async settle() {
      for (let i = 0; i < 8; i += 1) await Promise.resolve();
      await new Promise((resolve) => setTimeout(resolve, 8));
    },
    restore() {
      globalThis.fetch = previousFetch;
      if (previousWindow === undefined) delete globalThis.window;
      else globalThis.window = previousWindow;
    },
  };
}

test("T025 网络失败：fetch reject → error 态，草稿一个字符都不写回", async () => {
  const h = await makeClientHarness({
    draft: "帮我把这个模块的导出整理一下",
    fetchImpl: () => Promise.reject(new Error("network down")),
  });
  try {
    assert.equal(h.tree.props["data-mode"], "idle");
    h.tree.props.onClick();
    await h.settle();
    assert.equal(h.tree.props["data-mode"], "error", "网络失败必须落到 error 态");
    assert.ok(String(h.tree.props.title || "").includes("network down"), "必须把失败原因带到界面");
    assert.deepEqual(h.writes, [], "失败时绝不写回草稿（不变量 I1）");
  } finally {
    h.restore();
  }
});

test("T026 陈旧响应必须被丢弃：等待期间用户改过草稿（不变量 I2）", async () => {
  let release;
  const pending = new Promise((resolve) => { release = resolve; });
  const h = await makeClientHarness({
    draft: "帮我改一下这个模块",
    fetchImpl: () =>
      pending.then(() => ({
        json: () => Promise.resolve({ ok: true, text: "请检查该模块的导出结构，并给出整理方案。" }),
      })),
  });
  try {
    h.tree.props.onClick();
    await h.settle();
    assert.equal(h.tree.props["data-mode"], "busy", "等待期间必须是 busy");

    // 用户在等待期间自己动手改了草稿：draftRev 递增，旧请求的结果就此作废。
    h.editDraft("我自己重新写过的内容");
    h.render();
    release();
    await h.settle();

    assert.deepEqual(h.writes, [], "陈旧响应绝不能写回（否则会覆盖用户刚打的字）");
    assert.equal(h.tree.props["data-mode"], "idle", "丢弃后回到 idle，而不是进入 revert 态");
  } finally {
    h.restore();
  }
});

test("T027 引用守恒：改写丢掉引用标签 → declined 且不写回（不变量 I1）", async () => {
  const h = await makeClientHarness({
    draft: "@src/index.js 帮我看看这个文件",
    occurrences: [{ label: "@src/index.js" }],
    // 改写把 @ 去掉，变成纯文本路径——引用结构被静默降级
    fetchImpl: () =>
      Promise.resolve({ json: () => Promise.resolve({ ok: true, text: "请检查 src/index.js 的实现，并给出改进建议。" }) }),
  });
  try {
    h.tree.props.onClick();
    await h.settle();
    assert.equal(h.tree.props["data-mode"], "declined", "丢引用必须走拒绝态，而不是照常写回");
    assert.ok(String(h.tree.props.title || "").includes("引用"), "必须说明原因与引用有关，当前：" + String(h.tree.props.title || ""));
    assert.deepEqual(h.writes, [], "拒绝时绝不能写回，原文保留（I1）");
  } finally {
    h.restore();
  }
});

test("T027 引用守恒的正例：标签原样保留时正常写回一次", async () => {
  const h = await makeClientHarness({
    draft: "@src/index.js 帮我看看这个文件",
    occurrences: [{ label: "@src/index.js" }],
    fetchImpl: () =>
      Promise.resolve({
        json: () => Promise.resolve({ ok: true, text: "@src/index.js 请检查该文件的导出结构，并给出改进建议。" }),
      }),
  });
  try {
    h.tree.props.onClick();
    await h.settle();
    assert.equal(h.writes.length, 1, "标签保留时必须写回且只写一次");
    assert.ok(h.writes[0].includes("@src/index.js"), "引用标签必须原样出现在写回内容里");
  } finally {
    h.restore();
  }
});

test("T028 路由挂靠 fiber 生命周期：dispose 后不残留，重复 apply 不叠加", async () => {
  const host = await import("../lib/index.js");

  // 默认 helper 的 register 返回空函数，测不出"残留"——这里返回真正的摘除器。
  const makeServer = () => {
    const routes = [];
    return {
      routes,
      register(route) {
        routes.push(route);
        return () => {
          const i = routes.indexOf(route);
          if (i >= 0) routes.splice(i, 1);
        };
      },
    };
  };

  const webServer = makeServer();
  const disposers = [];
  const ctx = makeHostContext(webServer, {});
  ctx.effect = (fn) => { const disposer = fn(); disposers.push(disposer); return disposer; };

  host.apply(ctx, { samples: false });
  assert.equal(webServer.routes.length, 1, "apply 必须注册恰好一条路由");
  assert.equal(webServer.routes[0].path, "/api/prompt-seed/optimize");
  assert.equal(typeof disposers[0], "function", "effect 必须返回 disposer，否则热升级会撞 duplicate route");

  // 模拟 disable → enable：先回收，再挂一次
  disposers[0]();
  assert.equal(webServer.routes.length, 0, "dispose 后不得残留路由");
  host.apply(ctx, { samples: false });
  assert.equal(webServer.routes.length, 1, "重新 apply 后恰好一条，不叠加");
  disposers[1]();
  assert.equal(webServer.routes.length, 0, "再次回收仍然干净");
});

test("T030 反馈分支的退化输入：字段缺失、非对象、非数值都不得崩", async () => {
  const host = await import("../lib/index.js");
  const dir = await mkdtemp(join(tmpdir(), "po-feedback-edge-"));
  const file = join(dir, "nested", "samples.jsonl");
  try {
    const webServer = makeWebServer();
    const ctx = makeHostContext(webServer, { responses: [textChunks("不该被调用")] });
    host.apply(ctx, { samples: file });
    const route = webServer.routes[0];

    // 1) 字段全缺：kind 落 unknown，其余落 null（而不是 undefined / NaN）
    const res1 = makeResponse();
    await route.handler(makeRequest({ body: JSON.stringify({ feedback: {} }) }), res1);
    assert.equal(res1.statusCode, 200);
    assert.deepEqual(JSON.parse(res1.body), { ok: true });
    const first = JSON.parse((await readFile(file, "utf8")).trim().split("\n")[0]);
    assert.equal(first.kind, "unknown");
    assert.equal(first.tier, null);
    assert.equal(first.charsDelta, null);
    assert.equal(first.elapsedMs, null);

    // 2) feedback 不是对象：按"没有反馈"处理，继续走正常流程（无 text → 确定性拒绝）
    const res2 = makeResponse();
    await route.handler(makeRequest({ body: JSON.stringify({ feedback: "reverted" }) }), res2);
    assert.equal(res2.statusCode, 200);
    assert.equal(JSON.parse(res2.body).ok, false, "非对象 feedback 不得被当成反馈通道");
    assert.equal(ctx.get("llm").seen.length, 0, "确定性拒绝不花模型调用");

    // 3) 数值字段给了非数字：落 null（而不是让 NaN 经 JSON 变成 null 还被当成合法值）
    const res3 = makeResponse();
    await route.handler(makeRequest({ body: JSON.stringify({ feedback: { kind: "retried", charsDelta: "很多", elapsedMs: null } }) }), res3);
    assert.equal(res3.statusCode, 200);
    const lines = (await readFile(file, "utf8")).trim().split("\n");
    const third = JSON.parse(lines[lines.length - 1]);
    assert.equal(third.kind, "retried");
    assert.equal(third.charsDelta, null);
    assert.equal(third.elapsedMs, null);

    // 4) 采样关闭：反馈仍然返回成功（采样是旁路，不是前置条件）
    const webServer2 = makeWebServer();
    const ctx2 = makeHostContext(webServer2, { responses: [textChunks("不该被调用")] });
    host.apply(ctx2, { samples: false });
    const res4 = makeResponse();
    await webServer2.routes[0].handler(makeRequest({ body: JSON.stringify({ feedback: { kind: "submitted" } }) }), res4);
    assert.equal(res4.statusCode, 200);
    assert.deepEqual(JSON.parse(res4.body), { ok: true });
    assert.equal(ctx2.get("llm").seen.length, 0);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test("T031 busy 期间再点一次 = 取消：不发第二次请求，旧响应被丢弃", async () => {
  let release;
  const pending = new Promise((resolve) => { release = resolve; });
  let calls = 0;
  const h = await makeClientHarness({
    draft: "帮我改一下这个模块",
    fetchImpl: () => {
      calls += 1;
      return pending.then(() => ({
        json: () => Promise.resolve({ ok: true, text: "请检查该模块的导出结构，并给出整理方案。" }),
      }));
    },
  });
  try {
    h.tree.props.onClick();
    await h.settle();
    assert.equal(h.tree.props["data-mode"], "busy", "第一次点击进入 busy");

    // 第二次点击是"取消"，不是"再发一次"
    h.tree.props.onClick();
    await h.settle();
    assert.equal(h.tree.props["data-mode"], "idle", "取消后立刻回到 idle（用户看得到反馈）");
    assert.equal(calls, 1, "取消不得再发一次请求——否则就是两次扣费");

    release();
    await h.settle();
    assert.deepEqual(h.writes, [], "被取消的响应绝不能写回");
    assert.equal(h.tree.props["data-mode"], "idle", "旧响应到达后也不得把状态拉回 busy/revert");
  } finally {
    h.restore();
  }
});

test("T032 自适应深度：统计驱动的档位必须在渲染层可见", async () => {
  const SIGNAL_KEY = "dsh-prompt-seed/signals";
  const DEPTH_KEY = "dsh-prompt-seed/depth";
  const titleFor = async (storage) => {
    const h = await makeClientHarness({ draft: "帮我改一下这个模块", storage });
    try {
      return String(h.tree.props.title || "");
    } finally {
      h.restore();
    }
  };

  // 补少了（retried 多于 reverted）→ 升档到深度
  const deepTitle = await titleFor({ [SIGNAL_KEY]: { retried: 3, reverted: 0, submitted: 1 } });
  assert.ok(deepTitle.includes("当前深度档"), "retried 占优应升到深度档，当前标题：" + deepTitle);
  // 补多了（reverted 多于 submitted）→ 降档到轻
  assert.ok((await titleFor({ [SIGNAL_KEY]: { reverted: 3, submitted: 0, retried: 0 } })).includes("当前轻档"), "reverted 占优应降到轻档");
  // 冷启动保护：只点过一两次不得改变档位
  assert.ok((await titleFor({ [SIGNAL_KEY]: { retried: 1, reverted: 0, submitted: 0 } })).includes("当前标准档"), "冷启动必须是标准档");
  assert.ok((await titleFor({ [SIGNAL_KEY]: { reverted: 1, submitted: 0, retried: 0 } })).includes("当前标准档"), "冷启动的降档方向同样要拦住");
  assert.ok((await titleFor({})).includes("当前标准档"), "没有任何统计时是标准档");

  // 手动档位优先于统计（用户显式选过就不再自作主张）
  const manual = await titleFor({ [DEPTH_KEY]: { mode: "light" }, [SIGNAL_KEY]: { retried: 9, reverted: 0, submitted: 0 } });
  assert.ok(manual.includes("深度：轻"), "手动档位必须压过统计，当前：" + manual);
  assert.ok(!manual.includes("自动"), "手动档位下不该再显示自动");

  // 非法持久化值回落 auto（而不是把脏数据当档位用）
  const dirty = await titleFor({ [DEPTH_KEY]: { mode: "超级深度" }, [SIGNAL_KEY]: { retried: 3, reverted: 0, submitted: 0 } });
  assert.ok(dirty.includes("自动"), "非法档位必须回落 auto，当前：" + dirty);
});

  const makeFetch = (bodies) => (url, init) => {
    const body = JSON.parse(init.body);
    bodies.push(body);
    if (body.feedback) return Promise.resolve({ json: () => Promise.resolve({ ok: true }) });
    return Promise.resolve({ json: () => Promise.resolve({ ok: true, text: "请检查该模块的导出结构，并给出整理方案。" }) });
  };
  const kindsOf = (bodies) => bodies.filter((b) => b.feedback).map((b) => b.feedback.kind);

test("T033 撤销路径：写回回传 applied，撤销回传 reverted 并写回原文", async () => {
  const bodies = [];
  const h = await makeClientHarness({ draft: "帮我改一下这个模块", fetchImpl: makeFetch(bodies) });
  try {
    h.primary().props.onClick();
    await h.settle();
    assert.equal(h.writes.length, 1, "改写已写回");
    assert.equal(h.primary().props["data-mode"], "revert", "成功后进入 revert 态");
    assert.equal(h.visibleLabel(h.primary()), "原文", "恢复动作必须有移动端可见的“原文”文字，不能只靠 title");
    assert.ok(h.byTestId("prompt-seed-regenerate"), "第一次优化后必须出现“再来”动作");
    assert.equal(h.visibleLabel(h.byTestId("prompt-seed-regenerate")), "再来", "“再来”必须直接可见，不能只靠 hover");
    assert.equal(h.byTestId("prompt-seed-previous"), null, "第一次优化没有上一版，不应显示回退动作");

    // 生成第二版后才出现“上一版”，保持原来的渐进逻辑。
    h.byTestId("prompt-seed-regenerate").props.onClick();
    await h.settle();
    assert.ok(h.byTestId("prompt-seed-previous"), "第二版生成后才应出现“上一版”");
    assert.equal(h.visibleLabel(h.byTestId("prompt-seed-previous")), "上一版", "回退动作必须直接可见");
    h.byTestId("prompt-seed-previous").props.onClick();
    await h.settle();
    assert.equal(h.byTestId("prompt-seed-previous"), null, "退回第一版后不再有上一版");

    // 主按钮仍恢复原文。
    h.primary().props.onClick();
    await h.settle();
    // 顺序即语义：写回成功 = applied（采纳），撤销 = reverted（补多了）。记反会让自适应深度调错方向。
    assert.deepEqual(kindsOf(bodies), ["applied", "applied", "reverted"], "实际：" + JSON.stringify(kindsOf(bodies)));
    const reverted = bodies.filter((b) => b.feedback && b.feedback.kind === "reverted")[0].feedback;
    assert.ok(Number.isFinite(reverted.charsDelta), "charsDelta 必须是数字");
    assert.ok(Number.isFinite(reverted.elapsedMs), "elapsedMs 必须是数字");
    assert.equal(h.writes.length, 4, "第一版、第二版、回上一版、恢复原文都必须真实写回");
    assert.equal(h.writes[3], "帮我改一下这个模块", "最后写回的必须是原文");
    assert.equal(h.primary().props["data-mode"], "idle", "撤销后回到 idle");
  } finally {
    h.restore();
  }
});

test("T033 改后再点路径：回传 retried 并真的发起新一次优化", async () => {
  // 注意与撤销路径的区别：运行记录会被**第一次**反馈消费掉（消费即置空），
  // 所以在撤销之后再点不会回传 retried。retried 的真实条件是：上一稿仍在窗口内且未被消费。
  const bodies = [];
  const h = await makeClientHarness({ draft: "帮我改一下这个模块", fetchImpl: makeFetch(bodies) });
  try {
    h.primary().props.onClick();
    await h.settle();
    h.editDraft("换个方向：帮我看看性能");
    h.render();
    // 编辑后必须等一次微任务：发散检测（依赖 [draft] 的 effect）在渲染后执行并把
    // 重渲染排进微任务，撤销备份是在那一次渲染里被丢掉的。真实用户点击的是重渲染
    // 之后的按钮；拿着旧树点击会点到"撤销"，那不是用户会经历的时序。
    await h.settle();
    assert.notEqual(h.primary().props["data-mode"], "revert", "草稿一旦改动，撤销入口必须消失");
    h.primary().props.onClick();
    await h.settle();
    assert.deepEqual(kindsOf(bodies), ["applied", "retried", "applied"], "实际：" + JSON.stringify(kindsOf(bodies)));
    const optimizeCalls = bodies.filter((b) => !b.feedback);
    assert.equal(optimizeCalls.length, 2, "retried 之后确实发起了新一次优化");
    assert.equal(optimizeCalls[1].text, "换个方向：帮我看看性能", "新请求带的是用户改后的草稿");
  } finally {
    h.restore();
  }
});
test("T034 事件日志字段与 FEATURES 声明一致（文档抽查转常驻守卫）", async () => {
  const host = await import("../lib/index.js");
  const dir = await mkdtemp(join(tmpdir(), "po-fields-"));
  const file = join(dir, "samples.jsonl");
  try {
    const webServer = makeWebServer();
    const ctx = makeHostContext(webServer, {
      responses: [textChunks("请检查该模块的导出结构，并给出整理方案。"), textChunks("OK")],
    });
    host.apply(ctx, { samples: file });
    const res = makeResponse();
    // 用超长输入，顺带钉住 input 字段的截断长度
    const long = "帮我把这个模块的导出结构梳理一遍，" + "补充说明。".repeat(100); // 517 字，必定触发 400 字截断
    await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ text: long }) }), res);
    assert.equal(res.statusCode, 200);
    const record = JSON.parse((await readFile(file, "utf8")).trim().split("\n")[0]);

    // 这份清单逐字来自 docs/FEATURES.md 模块 8 的"事件日志"行；改其一必须同改另一处。
    const documented = [
      "time", "event", "code", "tier", "mode", "depth", "gate", "repairs", "rechecked",
      "violations", "inputChars", "outputChars", "ms", "input", "added", "provider", "model", "from",
      "codeVersion", "runId",
    ];
    for (const key of documented) {
      assert.ok(key in record, `FEATURES 声明的字段 ${key} 没有落盘（文档与实现已经不一致）`);
    }
    assert.equal(record.input.length, 400, "input 必须是前 400 字（SAMPLE_INPUT_PREVIEW）");
    assert.ok(record.inputChars > 400, "inputChars 记录的是完整长度，不是截断后的长度");
    assert.equal(record.event, "optimize");
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test("T035 submitted 信号的两条触发路径：草稿被清空 / 离开 plain 阶段", async () => {
  const bodies = [];
  const h = await makeClientHarness({
    draft: "帮我改一下这个模块",
    fetchImpl: (url, init) => {
      const body = JSON.parse(init.body);
      bodies.push(body);
      if (body.feedback) return Promise.resolve({ json: () => Promise.resolve({ ok: true }) });
      return Promise.resolve({ json: () => Promise.resolve({ ok: true, text: "请检查该模块的导出结构，并给出整理方案。" }) });
    },
  });
  try {
    h.primary().props.onClick();
    await h.settle();
    assert.deepEqual(bodies.filter((b) => b.feedback).map((b) => b.feedback.kind), ["applied"]);

    // 路径一：草稿被清空（用户把结果发出去了）→ 最强正信号
    h.editDraft("");
    h.render();
    await h.settle();
    assert.deepEqual(
      bodies.filter((b) => b.feedback).map((b) => b.feedback.kind),
      ["applied", "submitted"],
      "草稿清空必须回传 submitted",
    );

    // 路径二：会话离开 plain 阶段（提交/切换）→ 同样是最强正信号
    const h2 = await makeClientHarness({
      draft: "帮我改一下这个模块",
      fetchImpl: (url, init) => {
        const body = JSON.parse(init.body);
        bodies.push(body);
        if (body.feedback) return Promise.resolve({ json: () => Promise.resolve({ ok: true }) });
        return Promise.resolve({ json: () => Promise.resolve({ ok: true, text: "请检查该模块的导出结构，并给出整理方案。" }) });
      },
    });
    const kindsBefore = bodies.filter((b) => b.feedback).length;
    h2.primary().props.onClick();
    await h2.settle();
    h2.client.phase = "submitting";
    h2.render();
    await h2.settle();
    const kinds = bodies.filter((b) => b.feedback).map((b) => b.feedback.kind);
    assert.equal(kinds[kinds.length - 1], "submitted", "离开 plain 阶段必须回传 submitted，实际：" + JSON.stringify(kinds.slice(kindsBefore)));
    h2.restore();
  } finally {
    h.restore();
  }
});

test("确定性守卫必须走中性盾态：input_too_long / empty_input 不是故障", async () => {
  const drive = async (code, message) => {
    const h = await makeClientHarness({
      draft: "帮我把这个模块整理一下",
      fetchImpl: () => Promise.resolve({ json: () => Promise.resolve({ ok: false, code, error: message }) }),
    });
    try {
      h.primary().props.onClick();
      await h.settle();
      return { mode: h.primary().props["data-mode"], title: String(h.primary().props.title || ""), writes: h.writes.slice() };
    } finally {
      h.restore();
    }
  };

  const tooLong = await drive("input_too_long", "内容过长，请精简后再优化");
  assert.equal(tooLong.mode, "declined", "内容过长是守卫不是故障，必须是中性盾态");
  assert.ok(tooLong.title.includes("过长"), "tooltip 必须给出可读原因，当前：" + tooLong.title);
  assert.deepEqual(tooLong.writes, [], "守卫拒绝时绝不写回（不变量 I1）");

  const empty = await drive("empty_input", "请先输入内容");
  assert.equal(empty.mode, "declined", "空输入（curl/脚本路径可达）同样是守卫");
  assert.deepEqual(empty.writes, []);
});

test("查看被拒版本：显式点击才写回，且写回后可一键撤销", async () => {
  const original = "帮我把这个模块的导出整理一下";
  const rejectedText = "请检查该模块的导出结构，重构全部公共接口并补一套基准测试。";
  const h = await makeClientHarness({
    draft: original,
    fetchImpl: () =>
      Promise.resolve({
        json: () =>
          Promise.resolve({
            ok: false,
            code: "fidelity_rejected",
            error: "优化会改变原意，已保留原文",
            violations: [{ kind: "SCOPE_ADDED", label: "增加了原本没有的要求", text: "重构全部公共接口" }],
            rejected: rejectedText,
          }),
      }),
  });
  try {
    h.primary().props.onClick();
    await h.settle();
    assert.equal(h.primary().props["data-mode"], "declined", "被拒后进入中性盾态");
    assert.deepEqual(h.writes, [], "拒绝路径绝不自动写回（不变量 I1）");

    const eye = h.byTestId("prompt-seed-view-rejected");
    assert.ok(eye, "declined 且确有被拒稿时必须露出查看入口");
    eye.props.onClick();
    await h.settle();

    assert.equal(h.writes.length, 1, "显式点击才写回一次");
    assert.equal(h.writes[0], rejectedText, "写回的必须是被拒稿原文");
    assert.equal(h.primary().props["data-mode"], "revert", "查看被拒稿同样可撤销：进入 revert 态");

    h.primary().props.onClick();
    await h.settle();
    assert.equal(h.writes.length, 2, "一键撤销写回");
    assert.equal(h.writes[1], original, "撤销恢复的是查看前的原稿");
  } finally {
    h.restore();
  }
});

// --------------------------------------------------------------------------
// 自适应契约（0.9.4）：一次点击，插件自己选操作（seed / clarify / precise）
// --------------------------------------------------------------------------

import { buildAdaptiveSystemPrompt, parseAdaptiveResult } from "../src/prompt-templates.js";

test("parseAdaptiveResult：MODE 声明解析、缺失回落 seed", () => {
  assert.deepEqual(parseAdaptiveResult("MODE: clarify\n已重启完成。下一步做什么？"), { op: "clarify", text: "已重启完成。下一步做什么？", declared: true });
  assert.deepEqual(parseAdaptiveResult("MODE: Precise\n原文"), { op: "precise", text: "原文", declared: true }, "大小写不敏感");
  assert.deepEqual(parseAdaptiveResult("没有声明"), { op: "seed", text: "没有声明", declared: false });
  // 0.9.7（T-debug-M3）：非法声明的 MODE 头也要剥掉——协议行不是用户内容，
  // 原样保留会把 "MODE: 自由发挥" 整行漏进输入框（实测三种形态全部 ok 透传）。
  assert.deepEqual(parseAdaptiveResult("MODE: 自由发挥\n随意"), { op: "seed", text: "随意", declared: false }, "非法声明剥头、正文保留、不按声明档位走");
});

test("自适应·澄清：完整但含混的输入得到梳理而不是扩写（真实回归输入）", async () => {
  // 来自 samples.jsonl 的真实形态：完整意图 + 指代含混（非问句形——问句形已由
  // 会话分支接走，见上）。旧契约会把这类输入扩成 4~8×。
  const input = "帮我看看那个东西能不能用，就是昨天说的那个导出";
  const llm = scriptedLlm([
    textChunks("MODE: clarify\n看看昨天说的那个导出功能现在能不能用。"),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true);
  assert.equal(result.mode, "clarify");
  assert.equal(result.tier, "full");
  assert.ok(result.text.length <= Math.ceil(input.length * 1.3), "澄清不得显著变长");
  // 0.10.0 起带内澄清稿走确定性短路：1.5× 预算 + 锚定词守恒 + 0.7× 下限全过
  // → 不再花审判调用（实测省约四成延迟），凭证如实标 unverified。
  assert.equal(llm.seen.length, 1, "带内澄清稿确定性短路，只有改写一次调用");
  assert.equal(result.gate.verdict, "unverified");
  assert.ok(llm.seen[0].system.includes("You rewrite the user's draft"), "走自适应契约");
});

test("自适应·澄清超度：收紧重试仍超限 → 会话兜底，绝不空手而归", async () => {
  const input = "帮我看看那个东西能不能用，就是昨天说的那个导出";
  const bloated = "请检查昨天讨论的那个导出功能当前是否可用：先确认入口有没有上线，再分别试小数据量和大数据量两种导出，核对文件内容与格式是否正确，失败时记录报错信息并汇总成一份可用性结论。";
  const llm = scriptedLlm([
    textChunks("MODE: clarify\n" + bloated),
    textChunks("MODE: clarify\n" + bloated), // 收紧重试仍超限
    textChunks("帮我看看那个东西（昨天说的导出）现在能不能用。"), // 会话兜底稿
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true, "硬拒绝会把用户晾在原地——真实数据里两条祈使消息撞进过这条路");
  assert.equal(result.mode, "conversational", "兜底走会话分支");
  assert.ok(result.text.length <= Math.ceil(input.length * 1.35) + 6, "兜底遵守轻润色上限");
  assert.equal(llm.seen.length, 3, "改写 + 收紧重试 + 会话兜底");
  assert.ok(llm.seen[1].system.includes("at most 1.3x"), "重试必须带收紧指令");
});

test("自适应·澄清丢锚定词：会话兜底（原文为底，锚定词天然保全）", async () => {
  const input = "把 src/utils/legacy.js 里的导出删掉，跑测试确认没破坏";
  const llm = scriptedLlm([
    textChunks("MODE: clarify\n删除 src/utils/legacy.ts 中的导出，然后运行测试确认无破坏。"), // 路径被改写
    textChunks("把 src/utils/legacy.js 里的导出删掉，然后跑测试确认没破坏。"), // 会话兜底稿
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true);
  assert.equal(result.mode, "conversational");
  assert.ok(result.text.includes("src/utils/legacy.js"), "兜底稿保全锚定词");
  assert.equal(llm.seen.length, 2);
});

test("自适应·缺失 MODE 声明：回落 seed，行为与旧补全路径等价", async () => {
  const llm = scriptedLlm([
    textChunks("请检查这个登录接口是否存在问题；如有，指出是什么问题。"),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "帮我看看这个登录接口有没有问题" });
  assert.equal(result.ok, true);
  assert.equal(result.mode, "seed", "未声明时回落 seed（旧默认行为）");
  assert.equal(result.tier, "full");
});

test("自适应·system.md 覆盖继续作用于主改写路径", async () => {
  setTemplateOverrides({ system: "ADAPTIVE OVERRIDE MARKER" });
  try {
    const llm = scriptedLlm([textChunks("MODE: seed\n覆盖下的补全稿。"), textChunks("OK")]);
    const result = await optimizePromptText({ llm, route: ROUTE, text: "帮我做个导出功能" });
    assert.equal(result.ok, true);
    assert.ok(llm.seen[0].system.startsWith("ADAPTIVE OVERRIDE MARKER"), "覆盖文件替换自适应契约正文");
    assert.ok(llm.seen[0].system.includes("ADDITIONAL HARD RULES FOR THIS DEPLOYMENT"), "覆盖不能冲掉部署级硬规则");
  } finally {
    setTemplateOverrides(null);
  }
  assert.ok(buildAdaptiveSystemPrompt().includes("You rewrite the user's draft"), "归还后回落内置");
});

test("问句形短消息路由到会话分支：1.0× 轻润色，绝不扩成清单（真实回归）", async () => {
  // 真实数据：glm-5.2 对「已重启了，然后需要我做什么」在扩展契约下扩成 7~8×，
  // 自适应契约下仍执意 seed（连专用澄清契约都拦不住 130 字清单）——这类
  // 「发给助手的消息」本就该由会话分支接走，界由代码划。
  const input = "已重启了，然后需要我做什么";
  const llm = scriptedLlm([textChunks("已重启了，然后我需要做什么？")]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true);
  assert.equal(result.mode, "conversational", "问句形短消息 → 会话分支");
  assert.ok(result.text.length <= Math.ceil(input.length * 1.35) + 6, "轻润色上限");
  assert.equal(llm.seen.length, 1, "单次调用，无审判无重试");
  assert.ok(llm.seen[0].system.includes("conversational message"), "走会话契约");
});

test("自适应·问句否决不误伤：无问号的任务种子仍走补全", async () => {
  const input = "帮我做个导出报表的功能"; // 无问号、无锚定：种子，不受否决影响
  const llm = scriptedLlm([
    textChunks("MODE: seed\n帮我做一个导出报表功能：可选时间范围与统计维度，导出 CSV 与 Excel，数据量大时显示进度。"),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true);
  assert.equal(result.mode, "seed", "无问号种子不受问句否决影响");
});

test("seed 收紧带：≥15 字输入超出 3.5× 触发收紧，取更短者（真实回归）", async () => {
  // 真实数据：同一条 153 字输入两次运行 5.46×/2.27×，用户手动重跑纠正——
  // 收紧带让这个纠正发生在管线内部。
  const input = "帮我做一个支持断点续传的大文件上传功能"; // 20 字真种子（非检查型、非问句）
  const fat = "MODE: seed\n帮我做一个大文件上传功能：支持断点续传，分片上传并在中断后从上次位置继续，上传中显示进度与已传大小，失败自动重试三次，全部完成后校验文件完整性，超时自动暂停并支持手动恢复，多文件并发上传时排队管理。";
  const tight = "MODE: seed\n做大文件上传：分片断点续传，中断后从上次位置继续；显示进度；失败自动重试；完成后校验完整性。";
  const llm = scriptedLlm([
    textChunks(fat),
    textChunks(tight),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true);
  assert.equal(result.mode, "seed");
  assert.ok(result.text.length <= input.length * 3.5, "收紧后必须落在带内");
  assert.equal(llm.seen.length, 3, "改写 + 收紧 + 审判");
  assert.ok(llm.seen[1].system.includes("compress an overlong prompt-unfold"), "收紧用专用压缩契约");
  assert.ok(llm.seen[1].messages[0].content[0].text.includes("FAT UNFOLD TO COMPRESS"), "收紧压缩的是胖稿本身，不是重新展开原文");
});

test("seed 收紧带不误伤：微种子（<15 字）大幅展开是设计行为", async () => {
  const input = "帮我做个导出功能"; // 9 字：真微种子
  const fat = "MODE: seed\n帮我做一个导出功能：可选时间范围与统计维度，导出 CSV 与 Excel，数据量大时显示进度，空结果给提示，文件名带类型与时间。"; // ~5x
  const llm = scriptedLlm([
    textChunks(fat),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true);
  assert.equal(llm.seen.length, 2, "微种子不触发收紧（展开正是产品价值）");
  assert.ok(result.text.length > input.length * 3, "微种子的展开不被压制");
});

test("检查型请求划界：看看X能不能用 → 按 clarify 校验，拿到的永远是短稿（真实回归）", async () => {
  // 真实数据：glm-5.2 对「帮我看看那个东西能不能用，就是昨天说的那个导出」连判
  // seed（5.70×/5.26×），收紧后仍有 3.43×——语义上这是完整诉求，要的是澄清。
  const input = "帮我看看那个东西能不能用，就是昨天说的那个导出";
  const fat = "MODE: seed\n请检查昨天讨论的那个导出功能当前是否可用：先确认入口已上线，再分别用小数据量和大数据量各导出一次，核对内容与格式，检查响应时间，失败时记录报错并整理结论。";
  const tight = "看看昨天说的那个导出功能现在能不能用，不能用的话说明原因。";
  const llm = scriptedLlm([
    textChunks(fat),        // 模型执意 seed + 超度
    textChunks(tight),      // 澄清专用契约重试听劝
    textChunks("OK"),       // 审判
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true);
  assert.equal(result.mode, "clarify", "检查型请求强制按 clarify 校验");
  assert.ok(result.text.length <= Math.ceil(input.length * 1.5), "必须落在澄清预算内");
  // 0.10.0：收紧后的带内稿走确定性短路，不再花第三次审判调用。
  assert.equal(llm.seen.length, 2, "改写（超度）+ 澄清收紧重试，短路免审");
});

test("检查型划界不误伤：短于 15 字的能不能疑问走原有路径", async () => {
  // ≤14 字的能不能输入不该被硬掰成 clarify（例如口语种子）
  const input = "这个能不能优化"; // 7 字
  const llm = scriptedLlm([
    textChunks("MODE: seed\n把这个功能优化一下：明确优化目标与衡量标准。"),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input });
  assert.equal(result.ok, true);
  assert.equal(result.mode, "seed", "短输入不触发检查型划界");
});

test("客户端为每次运行生成 runId，并在隐式反馈里回传同一个 id", async () => {
  // 宿主侧把 runId 写进两条记录只是一半；这条覆盖的是另一半——浏览器半区真的把它
  // 发出来了。少了任何一半，日志里那 57 条隐式反馈仍然只能靠时间戳相邻去猜。
  const bodies = [];
  const h = await makeClientHarness({
    draft: "帮我改一下这个模块",
    fetchImpl: (url, init) => {
      const body = JSON.parse(init.body);
      bodies.push(body);
      if (body.feedback) return Promise.resolve({ json: () => Promise.resolve({ ok: true }) });
      return Promise.resolve({
        json: () => Promise.resolve({ ok: true, text: "请检查该模块的导出结构，并给出整理方案。" }),
      });
    },
  });
  try {
    h.primary().props.onClick();
    await h.settle();

    const runs = bodies.filter((body) => !body.feedback);
    assert.equal(runs.length, 1);
    assert.ok(typeof runs[0].runId === "string" && runs[0].runId !== "", "优化请求必须带 runId");

    const applied = bodies.find((body) => body.feedback && body.feedback.kind === "applied");
    assert.equal(applied.runId, runs[0].runId, "隐式反馈必须回传同一次运行的 runId");

    // 换一段草稿再点一次 = 全新一次运行，必须是**新的** id：
    // 两次运行共用一个 id 会把它们合并成一条记录，比没有 id 更糟。
    h.editDraft("帮我改一下这个模块，再补充一点约束");
    h.render();
    await h.settle();
    h.primary().props.onClick();
    await h.settle();

    const secondRuns = bodies.filter((body) => !body.feedback);
    assert.equal(secondRuns.length, 2);
    assert.notEqual(secondRuns[0].runId, secondRuns[1].runId, "每次运行必须是独立的 runId");

    // 重试信号标的是**上一稿**，所以它带的必须是上一稿的 id，而不是新一稿的
    const retried = bodies.find((body) => body.feedback && body.feedback.kind === "retried");
    assert.equal(retried.runId, secondRuns[0].runId, "重试信号必须指向被重试的那一稿");
  } finally {
    h.restore();
  }
});

// ---------------------------------------------------------------------------
// 0.9.6 · 下一步输入预测
//
// 这一组测试守四件事，每件都对应一个具体的失败方式：
//   ① 分型判定必须来自**会话的事实**（编号选项 / 待答提问 / 待续提议 / 失败尾 /
//      工具活动），而不是任何一种"随便猜一句"——猜错的分型会产出用户不会发的话；
//   ② 输出必须落在分型的字数预算里（超了先收紧重试、再确定性收尾），因为预测的
//      价值全在"可以直接回车发出"；
//   ③ 推不出来时**中性拒绝**：一次模型调用都不花、一个字符都不写回；
//   ④ 客户端在空会话里什么都不显示、有上下文时空草稿给预测、失败时真的把提示
//      渲染到图标旁边（不静默）。
// ---------------------------------------------------------------------------

import {
  PREDICT_BUDGETS,
  PREDICT_FALLBACK_MARKER,
  checkPredictionOutput,
  classifyPredictionAnchor,
  sharesAnchor,
  trimPredictionToBudget,
} from "../src/prediction.js";
import { extractPredictionWindow } from "../src/session-context.js";
import { predictNextPrompt } from "../src/host-core.js";
import { buildPredictSystemPrompt, renderPredictUserPrompt } from "../src/prompt-templates.js";

test("预测分型：锚点类型由会话事实判定（选项 / 待续 / 提问 / 失败 / 交付）", () => {
  const choiceTail = "已改完登录流程，拆成了三个模块。\n1. 继续把测试补上\n2. 先到这里\n你想先做哪个？";
  const choice = classifyPredictionAnchor({ assistantTail: choiceTail });
  assert.equal(choice.kind, "choice");
  assert.equal(choice.options[0], "继续把测试补上");
  // 选项文本切到行内边界为止：选项 2 之后的追问句会并进同一条（parseOptions 的既有行为，
  // 对 choice 分型只用于"复述哪个选项"，不改变判据）。
  assert.ok(choice.options[1].startsWith("先到这里"));

  assert.equal(classifyPredictionAnchor({ assistantTail: "要不要我继续把测试补上？" }).kind, "continue");
  assert.equal(classifyPredictionAnchor({ assistantTail: "你希望用哪一种方案？" }).kind, "answer");
  assert.equal(classifyPredictionAnchor({ assistantTail: "安装失败了：ENOENT，找不到那个目录。" }).kind, "repair");

  // 工具活动是 next-step 唯一客观的证据：助手只是陈述了一段话时，下一句可以是任何东西。
  assert.equal(
    classifyPredictionAnchor({ assistantTail: "这个过程涉及三个步骤。", sawToolActivity: true }).kind,
    "next-step",
  );
  assert.equal(classifyPredictionAnchor({ assistantTail: "已经改好了登录流程。" }).kind, "next-step");
  assert.equal(classifyPredictionAnchor({ assistantTail: "这个过程涉及三个步骤。" }).kind, "none");
  assert.equal(classifyPredictionAnchor({ assistantTail: "这个过程涉及三个步骤。" }).reason, "no_anchor");
  assert.equal(classifyPredictionAnchor({ assistantTail: "" }).kind, "none");
  assert.equal(classifyPredictionAnchor(undefined).kind, "none");
});

test("预测输出校验：超预算 / 清单 / 裸序号 / 选项不落地 都被拦下", () => {
  assert.equal(checkPredictionOutput("继续，把测试补上。", "continue").ok, true);
  assert.equal(checkPredictionOutput("", "continue").reason, "empty");
  assert.equal(checkPredictionOutput(PREDICT_FALLBACK_MARKER, "continue").reason, "model_fallback");
  assert.equal(checkPredictionOutput("2", "choice", ["继续补测试", "先停下"]).reason, "bare_number");
  assert.equal(checkPredictionOutput("好的".repeat(40), "continue").reason, "overlong");
  assert.equal(checkPredictionOutput("1. 先补测试\n2. 再更新文档", "next-step").reason, "list_shape");
  // choice 分型必须复述一个**真实存在**的选项，否则用户会发出去一个助手没提过的东西
  assert.equal(
    checkPredictionOutput("先把回归跑一遍", "choice", ["继续把测试补上", "先到这里"]).reason,
    "option_missing",
  );
  assert.equal(checkPredictionOutput("继续把测试补上。", "choice", ["继续把测试补上", "先到这里"]).ok, true);

  // 分型预算表本身要健全：每个分型都有预算，且都在全局硬上限之下
  for (const kind of ["choice", "answer", "continue", "next-step", "repair"]) {
    assert.equal(typeof PREDICT_BUDGETS[kind], "number", "分型缺少预算：" + kind);
    assert.ok(PREDICT_BUDGETS[kind] <= 80);
  }
});

test("预测收尾：超预算切到最后一个句读边界，而不是硬切半句", () => {
  const long = "先把这一轮的测试补上并且跑通回归，然后再更新文档。";
  const trimmed = trimPredictionToBudget(long, "choice");
  assert.ok(trimmed.length <= PREDICT_BUDGETS.choice, "收尾必须落在预算内：" + trimmed);
  assert.ok(trimmed.startsWith("先把这一轮的测试补上"), "必须保留开头的完整语义：" + trimmed);
  assert.ok(!/[，,、]$/.test(trimmed), "末尾不得留下悬空的逗号：" + trimmed);
  // 接地校验：中文按字重叠、拉丁按词重叠
  assert.equal(sharesAnchor("继续把测试补上", "要不要我继续把测试补上？"), true);
  assert.equal(sharesAnchor("好的", "要不要我继续把测试补上？"), false);
});

test("预测契约：模板必须带 [NO PREDICTION] 回退标记与逐型预算（防漂移）", () => {
  // 标记常量在 prediction.js，字面量在模板里——两处必须同步，否则"推不出来"就
  // 变成"模型随便写一句"，中性拒绝的整条链路会静默失效。
  for (const kind of ["choice", "answer", "continue", "next-step", "repair"]) {
    const system = buildPredictSystemPrompt(kind);
    assert.ok(system.includes(PREDICT_FALLBACK_MARKER), "模板缺少回退标记：" + kind);
    assert.ok(system.includes("BUDGET"), "模板缺少字数预算：" + kind);
  }
  const tightened = buildPredictSystemPrompt("answer", { tightened: true });
  assert.ok(tightened.includes("TIGHTENING"), "收紧重试必须带上收紧后缀");
  const user = renderPredictUserPrompt("answer", "要不要我继续？", [
    { role: "user", text: "重构登录" },
    { role: "assistant", text: "已改完。要不要我继续？" },
  ]);
  assert.ok(user.includes("[user] 重构登录"));
  assert.ok(user.includes("[assistant] 已改完。要不要我继续？"));
  assert.ok(user.includes("要不要我继续？"));
});

test("预测窗口：助手消息取尾部（锚点在结尾），并带回本轮工具活动", () => {
  const longAssistant = "铺垫".repeat(500) + "\n1. 继续补测试\n2. 先停下\n你选哪个？";
  const surface = {
    events: [
      { type: "user/message", data: { role: "user", source: { kind: "user" }, content: [{ type: "text", text: "重构登录流程" }] } },
      { type: "runtime-context", data: { role: "user", source: { kind: "runtime-context" }, content: [{ type: "text", text: "注入快照不该进预测窗口" }] } },
      { type: "tool/call", data: {} },
      { type: "tool/result", data: {} },
      // 真实形状：助手事件的消息嵌在 data.message 下（用户事件是平铺的）。
      // 早先按平铺读助手事件，assistantTail 永远为空且静默——实测从会话日志确认。
      { type: "assistant/message", data: { turn: 1, step: 2, message: { role: "assistant", content: [{ type: "reasoning", text: "内部推理不该被当正文" }, { type: "text", text: longAssistant }] } } },
    ],
  };
  const win = extractPredictionWindow(surface);
  assert.ok(win.assistantTail.endsWith("你选哪个？"), "助手消息必须保留尾部：锚点全在结尾");
  assert.equal(win.sawToolActivity, true, "最后一轮用户话轮之后的 tool/* 才算这轮干了活");
  assert.equal(win.turns.length, 2, "注入快照不得进入窗口");
  assert.equal(classifyPredictionAnchor({ assistantTail: win.assistantTail, sawToolActivity: win.sawToolActivity }).kind, "choice");
});


test("事件形状：助手用 data.message 嵌套、用户用平铺，两种都必须认（0.9.6 回归）", () => {
  const nested = {
    events: [
      { type: "user/message", data: { role: "user", source: { kind: "user" }, content: [{ type: "text", text: "把登录流程重构一下" }] } },
      { type: "assistant/message", data: { turn: 1, step: 1, message: { role: "assistant", content: [{ type: "reasoning", text: "先看代码" }, { type: "text", text: "已改完。要不要我继续把测试补上？" }] } } },
    ],
  };
  const win = extractPredictionWindow(nested);
  assert.equal(win.assistantTail, "已改完。要不要我继续把测试补上？", "嵌套形状必须能读出助手正文");
  assert.equal(extractAssistantTail(nested).text, "已改完。要不要我继续把测试补上？", "信号分支的助手尾部同样必须读得到");
  assert.equal(classifyPredictionAnchor({ assistantTail: win.assistantTail }).kind, "continue");

  // 平铺形状（旧会话 / 测试替身）继续兼容
  const flat = {
    events: [{ type: "assistant/message", data: { role: "assistant", content: [{ type: "text", text: "要不要继续？" }] } }],
  };
  assert.equal(extractAssistantTail(flat).text, "要不要继续？");
  assert.equal(extractPredictionWindow(flat).assistantTail, "要不要继续？");

  // 只有推理块（没有 text 块）不算正文：中间步骤不该被当成助手说过的话
  const reasoningOnly = {
    events: [{ type: "assistant/message", data: { message: { role: "assistant", content: [{ type: "reasoning", text: "想了一会儿" }] } } }],
  };
  assert.equal(extractPredictionWindow(reasoningOnly), undefined);
});

test("助手尾部取结尾而不是开头：锚点（问句 / 选项 / 待续提议）都在结尾", () => {
  const longText = "铺垫".repeat(400) + "\n1. 继续补测试\n2. 先停下\n你选哪个？";
  const surface = {
    events: [{ type: "assistant/message", data: { message: { role: "assistant", content: [{ type: "text", text: longText }] } } }],
  };
  const tail = extractAssistantTail(surface).text;
  assert.ok(tail.startsWith("…"), "超长助手消息必须保留尾部并标记截断");
  assert.ok(tail.endsWith("你选哪个？"), "锚点必须留在锚文本里");
});

test("预测编排：模型回 [NO PREDICTION] 或输出不合格 → cannot_predict（中性拒绝）", async () => {
  const fallback = scriptedLlm([textChunks(PREDICT_FALLBACK_MARKER)]);
  const res1 = await predictNextPrompt({ llm: fallback, route: ROUTE, kind: "answer", anchor: "今天天气如何" });
  assert.equal(res1.ok, false);
  assert.equal(res1.code, ERROR_CODES.CANNOT_PREDICT);
  assert.equal(res1.mode, "predict");

  // 清单形状（模型把"一句话"写成了步骤）同样走中性拒绝，而不是塞给用户
  const listed = scriptedLlm([textChunks("1. 先补测试\n2. 再更新文档")]);
  const res2 = await predictNextPrompt({ llm: listed, route: ROUTE, kind: "next-step", anchor: "已改完。" });
  assert.equal(res2.ok, false);
  assert.equal(res2.code, ERROR_CODES.CANNOT_PREDICT);
});

test("预测编排：一次调用成功 → 一句话，且不借用任何闸门凭证", async () => {
  const llm = scriptedLlm([textChunks("继续，把测试补上。")]);
  const res = await predictNextPrompt({ llm, route: ROUTE, kind: "continue", anchor: "要不要我继续把测试补上？" });
  assert.equal(res.ok, true);
  assert.equal(res.text, "继续，把测试补上。");
  assert.equal(res.mode, "predict");
  assert.equal(res.kind, "continue");
  assert.equal(res.tier, "predict");
  assert.equal(res.gate, null, "预测没有可审判的原文，不得借用一次没跑过的闸门凭证");
  assert.ok(res.detail.includes("确认继续"));
});

test("预测编排：超预算先收紧重试一次，仍超则确定性收尾（不报错）", async () => {
  const long = "好的，我明白了，那我们接下来继续把剩余的测试补上，然后顺便把文档也更新一下。";
  const llm = scriptedLlm([textChunks(long), textChunks(long)]);
  const res = await predictNextPrompt({ llm, route: ROUTE, kind: "continue", anchor: "要不要继续？" });
  assert.equal(llm.seen.length, 2, "超预算必须真的收紧重试一次");
  assert.equal(res.ok, true, "两次都超预算时应收尾交付，而不是报一个用户看不懂的错");
  assert.ok(res.text.length <= PREDICT_BUDGETS.continue);
});

test("预测路由：没有锚点的会话 → cannot_predict 且零模型调用", async () => {
  const host = await import("../lib/index.js");
  const llm = scriptedLlm([textChunks("不该被调用")]);
  const webServer = makeWebServer();
  const surface = {
    events: [
      { type: "user/message", data: { role: "user", source: { kind: "user" }, content: [{ type: "text", text: "你好" }] } },
      { type: "assistant/message", data: { turn: 1, step: 1, message: { role: "assistant", content: [{ type: "text", text: "这个过程涉及三个步骤。" }] } } },
    ],
  };
  host.apply(makeHostContext(webServer, { llm, sessionQuery: { readSurface: async () => surface } }), { samples: false });
  const res = makeResponse();
  await webServer.routes[0].handler(makeRequest({ body: JSON.stringify({ mode: "predict", sessionId: "s-1" }) }), res);
  const payload = JSON.parse(res.body);
  assert.equal(res.statusCode, 200);
  assert.equal(payload.ok, false);
  assert.equal(payload.code, "cannot_predict");
  assert.equal(llm.seen.length, 0, "推不出来时一次模型调用都不该花");
});

test("预测路由：有锚点 → 一次调用 + 落 predict 日志（可归因）", async () => {
  const host = await import("../lib/index.js");
  const dir = await mkdtemp(join(tmpdir(), "po-predict-"));
  const samples = join(dir, "samples.jsonl");
  const llm = scriptedLlm([textChunks("继续，把测试补上。")]);
  const surface = {
    events: [
      { type: "user/message", data: { role: "user", source: { kind: "user" }, content: [{ type: "text", text: "重构登录流程" }] } },
      { type: "tool/result", data: {} },
      { type: "assistant/message", data: { turn: 1, step: 2, message: { role: "assistant", content: [{ type: "text", text: "已改完。要不要我继续把测试补上？" }] } } },
    ],
  };
  try {
    const webServer = makeWebServer();
    host.apply(makeHostContext(webServer, { llm, sessionQuery: { readSurface: async () => surface } }), { samples });
    const res = makeResponse();
    await webServer.routes[0].handler(
      makeRequest({ body: JSON.stringify({ mode: "predict", sessionId: "s-1", runId: "p-run" }) }),
      res,
    );
    const payload = JSON.parse(res.body);
    assert.equal(payload.ok, true);
    assert.equal(payload.text, "继续，把测试补上。");
    assert.equal(payload.kind, "continue");
    assert.equal(llm.seen.length, 1, "预测只该花一次调用");
    // 提示词必须真的带上会话尾部，否则模型无从预测
    const predictUserPrompt = llm.seen[0].messages[0].content[0].text;
    assert.ok(predictUserPrompt.includes("已改完"), "user prompt 必须带上助手尾部");
    assert.ok(predictUserPrompt.includes("ANCHOR (continue)"), "user prompt 必须点名锚点分型");
    assert.ok(llm.seen[0].system.includes("ANCHOR KIND: continue"), "system 必须带上分型预算");

    const record = (await readFile(samples, "utf8"))
      .trim()
      .split("\n")
      .map((line) => JSON.parse(line))
      .find((item) => item.event === "predict");
    assert.equal(record.code, "ok");
    assert.equal(record.kind, "continue");
    assert.equal(record.mode, "predict");
    assert.equal(record.runId, "p-run");
    assert.equal(record.from, "ui");
    assert.equal(record.sawToolActivity, true);
    assert.equal(record.anchorSource, "assistant-offer");
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test("客户端预测：空会话不渲染任何图标，有上下文时空输入换成预测按钮", async () => {
  const blank = await makeClientHarness({ session: { ...SESSION_FACE, blank: true, promptAttempted: false } });
  try {
    assert.equal(blank.tree, null, "空会话里不得显示任何图标（星标也去掉）");
  } finally {
    blank.restore();
  }

  const mid = await makeClientHarness({ session: { ...SESSION_FACE, running: true } });
  try {
    assert.equal(mid.tree, null, "助手还在回复时不给预测入口（那时只能瞎猜）");
  } finally {
    mid.restore();
  }

  const ready = await makeClientHarness({ session: { ...SESSION_FACE } });
  try {
    const button = ready.predict();
    assert.ok(button !== null, "有上下文且空输入时必须显示预测按钮");
    assert.equal(button.props["data-predict"], "1");
    assert.equal(ready.primary(), null, "同一个位置不该同时挂着星标");
  } finally {
    ready.restore();
  }

  const typed = await makeClientHarness({
    draft: "帮我做个导出报表的功能",
    session: { ...SESSION_FACE },
  });
  try {
    assert.ok(typed.primary() !== null, "有草稿时交回星标（优化提示词）");
    assert.equal(typed.predict(), null, "有草稿时预测让位给星标");
  } finally {
    typed.restore();
  }
});

test("客户端预测：填入草稿、请求带 mode=predict 且不带 text", async () => {
  const bodies = [];
  const h = await makeClientHarness({
    session: { ...SESSION_FACE },
    fetchImpl: async (url, init) => {
      bodies.push(JSON.parse(init.body));
      return { json: async () => ({ ok: true, text: "继续，把测试补上。" }) };
    },
  });
  try {
    h.predict().props.onClick();
    await h.settle();
    assert.deepEqual(h.writes, ["继续，把测试补上。"], "预测结果必须写进输入框");
    // 诊断信标（TEMP-DIAG）也走同一条路由，按有无 feedback 字段把真正的预测请求挑出来。
    const predictBodies = bodies.filter((body) => !body.feedback);
    assert.equal(predictBodies.length, 1);
    assert.equal(predictBodies[0].mode, "predict");
    assert.equal(predictBodies[0].text, undefined, "预测请求不该带草稿文本（那时输入框是空的）");
    // 填入之后草稿非空 → 位置交回星标（产品选择：换一版入口由"清空再点"承担）
    assert.ok(h.primary() !== null, "填入后应回到星标态");
  } finally {
    h.restore();
  }
});

test("客户端预测：失败在图标旁给出可见提示，推不出来用中性态（都不写回）", async () => {
  const fail = await makeClientHarness({
    session: { ...SESSION_FACE },
    fetchImpl: async () => ({ json: async () => ({ ok: false, code: "llm_error", error: "模型调用失败" }) }),
  });
  try {
    fail.predict().props.onClick();
    await fail.settle();
    assert.deepEqual(fail.writes, [], "失败时绝不写回（不变量 I1）");
    assert.equal(fail.predict().props["data-mode"], "error", "真故障落到警示态");
    const hint = fail.hint();
    assert.ok(hint !== null, "失败提示必须真的渲染到图标旁（用户要求不静默失败）");
    assert.ok(String(hint.children.join("")).includes("点击重试"), "提示要说明可以再点一次");
    assert.equal(fail.predict().props["data-hint"], "1");
  } finally {
    fail.restore();
  }

  const refused = await makeClientHarness({
    session: { ...SESSION_FACE },
    fetchImpl: async () => ({
      json: async () => ({ ok: false, code: "cannot_predict", error: "这段上下文里没有可预测的下一步" }),
    }),
  });
  try {
    refused.predict().props.onClick();
    await refused.settle();
    assert.deepEqual(refused.writes, [], "推不出来时一个字符都不写");
    assert.equal(refused.predict().props["data-mode"], "declined", "推不出来是中性结果，不是故障");
    assert.ok(String(refused.hint().children.join("")).includes("没有可预测"));
  } finally {
    refused.restore();
  }
});

test("客户端预测：等待期间用户开始打字 → 结果丢弃，绝不覆盖（不变量 I2）", async () => {
  let release;
  const pending = new Promise((resolve) => { release = resolve; });
  const h = await makeClientHarness({
    session: { ...SESSION_FACE },
    fetchImpl: () => pending.then(() => ({ json: async () => ({ ok: true, text: "继续，把测试补上。" }) })),
  });
  try {
    h.predict().props.onClick();
    await h.settle();
    assert.equal(h.predict().props["data-mode"], "busy", "等待期间必须是加载态");

    h.editDraft("我自己开始写了");
    h.render();
    release();
    await h.settle();
    assert.deepEqual(h.writes, [], "用户已经开始打字，预测结果必须被丢弃");
    assert.ok(h.primary() !== null, "丢弃后回到星标态（草稿里有用户自己的字）");
  } finally {
    h.restore();
  }
});


// --------------------------------------------------------------------------
// 0.9.7 调试回归（团队排查：静态 F1–F7 + 运行时 M1–M5，逐项可复现）
// --------------------------------------------------------------------------

import { safeSlice } from "../src/message-text.js";

test("T-debug-F1：改写骨架为空绝不判“实质未变”（掏空稿必须过闸门）", () => {
  // 旧缺陷：只有输入侧受保护，"登录"→"。"落在编辑距离容差内被判“未变”，
  // 精确跳审把单个标点回填给用户。
  assert.equal(isSubstantivelyUnchanged("登录", "。"), false);
  assert.equal(isSubstantivelyUnchanged("ab", ""), false);
  // 正常近原样改写不受影响
  assert.equal(isSubstantivelyUnchanged("登录", "登录！"), true);
});

test("T-debug-F1 端到端：precise 输入收到掏空稿 → 审判必须真的跑（不再跳审放行）", async () => {
  const llm = scriptedLlm([
    textChunks("MODE: precise\n。"),            // 第一稿：声明 precise，正文只有一个句号
    textChunks("DISTORTED: 改写删光了全部内容"), // 审判必须被调用（旧代码在这里跳审）
    textChunks(""),                              // 修复稿为空 → 拒绝并保留原文
  ]);
  const result = await optimizePromptText({
    llm,
    route: ROUTE,
    text: "把 src/index.js 里的 login 函数改成支持超时重试",
  });
  assert.equal(result.ok, false);
  assert.equal(result.code, "fidelity_rejected");
  assert.ok(llm.seen.length >= 2, "审判调用必须发生（旧代码一次调用就放行）");
});

test("T-debug-F2：context:false 不再连带禁用预测；predict:false 单独关闭", async () => {
  const host = await import("../lib/index.js");
  const surface = {
    events: [
      { type: "user/message", data: { role: "user", source: { kind: "user" }, content: [{ type: "text", text: "重构登录流程" }] } },
      { type: "assistant/message", data: { turn: 1, step: 2, message: { role: "assistant", content: [{ type: "text", text: "已改完。要不要我继续把测试补上？" }] } } },
    ],
  };
  // context:false + 预测默认开启 → 预测可用（旧代码：cannot_predict 死按钮）
  const webServer = makeWebServer();
  host.apply(
    makeHostContext(webServer, {
      llm: scriptedLlm([textChunks("继续，把测试补上。")]),
      sessionQuery: { readSurface: async () => surface },
    }),
    { samples: false, context: false },
  );
  const res = makeResponse();
  await webServer.routes[0].handler(
    makeRequest({ body: JSON.stringify({ mode: "predict", sessionId: "s-f2" }) }),
    res,
  );
  const payload = JSON.parse(res.body);
  assert.equal(payload.ok, true, JSON.stringify(payload));
  assert.equal(payload.kind, "continue");

  // predict:false → 明确关闭，中性拒绝
  const webServer2 = makeWebServer();
  host.apply(
    makeHostContext(webServer2, {
      llm: scriptedLlm([textChunks("继续，把测试补上。")]),
      sessionQuery: { readSurface: async () => surface },
    }),
    { samples: false, predict: false },
  );
  const res2 = makeResponse();
  await webServer2.routes[0].handler(
    makeRequest({ body: JSON.stringify({ mode: "predict", sessionId: "s-f2" }) }),
    res2,
  );
  const payload2 = JSON.parse(res2.body);
  assert.equal(payload2.ok, false);
  assert.equal(payload2.code, "cannot_predict");
});

test("T-debug-F3：短指令的指代锚点也认助手尾部（不再只看用户话轮）", async () => {
  const llm = scriptedLlm([textChunks("把刚才那个按钮的红色再改一下，先给我两三个候选颜色")]);
  const result = await optimizePromptText({
    llm,
    route: ROUTE,
    text: "改一下",
    context: undefined,
    assistantTail: { role: "assistant", text: "刚才把按钮颜色改成了红色" },
  });
  assert.equal(result.ok, true, JSON.stringify(result));
  assert.equal(result.mode, "deictic");
  // user prompt 必须真的带上助手尾部，否则模型无从消解指代
  assert.ok(llm.seen[0].messages[0].content[0].text.includes("按钮颜色"));
  // 旧回归：有用户话轮时仍然工作
  const llm2 = scriptedLlm([textChunks("把刚才那个按钮的红色再改一下")]);
  const r2 = await optimizePromptText({
    llm: llm2,
    route: ROUTE,
    text: "改一下",
    context: [{ role: "user", text: "把按钮换个颜色" }],
  });
  assert.equal(r2.ok, true);
});

test("T-debug-F4：无空白分隔的编号选项不再互相吞并", () => {
  const map = parseOptions("你要选哪个？（1）方案A（2）方案B");
  assert.equal(map.get("1"), "方案A");
  assert.equal(map.get("2"), "方案B");
  // 旧格式不回归
  const legacy = parseOptions("1. 方案一 2. 方案二");
  assert.equal(legacy.get("1"), "方案一");
  assert.equal(legacy.get("2"), "方案二");
});

test("T-debug-M3：值不合法的 MODE 头也剥离，不漏进输入框", () => {
  const r = parseAdaptiveResult("MODE: expand\n请帮我实现登录页面");
  assert.equal(r.text, "请帮我实现登录页面");
  assert.equal(r.declared, false);
  assert.equal(parseAdaptiveResult("MODE:\n正文").text, "正文");
  assert.equal(parseAdaptiveResult("MODE: Seed:\n正文").text, "正文");
  // 合法声明保持原行为
  const okParsed = parseAdaptiveResult("MODE: clarify\n正文");
  assert.equal(okParsed.op, "clarify");
  assert.equal(okParsed.declared, true);
});

test("T-debug-F5：会话兜底与补全重试的输出同样剥协议行", async () => {
  // 会话兜底（轻润色）：模型带 MODE 头返回润色稿
  const llm = scriptedLlm([textChunks("MODE: clarify\n我觉得这个方案还是不太对")]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "我觉得这个方案还是不太对？" });
  assert.equal(result.ok, true, JSON.stringify(result));
  assert.equal(result.text, "我觉得这个方案还是不太对");

  // 补全重试（unfold retry）：首稿实质未变，重试稿带 MODE 头
  const llm2 = scriptedLlm([
    textChunks("MODE: seed\n登录"),
    textChunks("MODE: seed\n登录页面要支持账号密码与手机验证码两种方式"),
    textChunks("OK"),
  ]);
  const r2 = await optimizePromptText({ llm: llm2, route: ROUTE, text: "登录" });
  assert.equal(r2.ok, true, JSON.stringify(r2));
  assert.ok(!r2.text.includes("MODE"), "协议行不得漏进写回文本");
  assert.ok(r2.text.includes("登录"));
});

test("T-debug-F6：截断代理对安全，不再产出孤立代理", () => {
  assert.equal(safeSlice("a😀b", 0, 2), "a");
  assert.equal(safeSlice("xa😀b", -2), "b");
  // 预算收尾切在 emoji 上时丢弃半个代理
  const trimmed = trimPredictionToBudget("好的，继续把测试补上😀😀😀😀", "continue");
  assert.ok(!/[\ud800-\udbff]$|^[\udc00-\udfff]/.test(trimmed));
  // 上下文提取的定长截断同样安全
  const ctx = extractRecentContext({
    events: [
      { type: "user/message", data: { role: "user", source: { kind: "user" }, content: "x".repeat(299) + "😀".repeat(200) } },
    ],
  });
  assert.ok(!/[\ud800-\udbff]$/.test(ctx[0].text), "上下文尾部不得是孤立高位代理");
});

test("T-debug-F7：带尾标点的信号词与 5 位数字不再漏进自适应管线", () => {
  assert.equal(classifySignalInput("继续。").kind, "signal");
  assert.equal(classifySignalInput("ok!").kind, "signal");
  assert.equal(classifySignalInput("10000").kind, "number");
  // 普通短种子不受影响
  assert.equal(classifySignalInput("做一个登录页").kind, "none");
});

test("T-debug-M1：短指令含指示词时，正确消解指代不再被判失真", () => {
  // 旧缺陷：度校验要求“这/那”逐字保留，而模板契约要求消解指代——模型做对反被拒
  const check = checkDeicticDegree("把刚才那个按钮的红色再改一下，先给我两三个候选颜色", "改一下这个");
  assert.equal(check.ok, true, JSON.stringify(check));
  // 动词逐字保留的底线不动摇
  assert.equal(checkDeicticDegree("把按钮换成蓝色的", "修一下这个").ok, false);
});

test("T-debug-M1 端到端：“改一下这个”在指代可消解时被采纳", async () => {
  const llm = scriptedLlm([textChunks("把刚才那个按钮的红色再改一下，先给我两三个候选颜色")]);
  const result = await optimizePromptText({
    llm,
    route: ROUTE,
    text: "改一下这个",
    context: [{ role: "user", text: "把按钮换个颜色" }],
  });
  assert.equal(result.ok, true, JSON.stringify(result));
  assert.equal(result.mode, "deictic");
});

test("T-debug-M2：“要不要继续？1.… 2.…”形态的锚点被识别", () => {
  const tail = "已梳理三个功能。要不要继续？1. 继续梳理剩余功能 2. 先停下来";
  // 预测分型：提议 + 编号选项 = 用户下一句是挑一个
  assert.equal(classifyPredictionAnchor({ assistantTail: tail }).kind, "choice");
  // 词信号：继续 = 放行该提议
  const item = inferPendingItem({ kind: "signal", token: "继续" }, undefined, { role: "assistant", text: tail });
  assert.equal(item.mode, "continue");
  // 旧格式不回归：纯问句尾部、纯提议尾部
  assert.equal(classifyPredictionAnchor({ assistantTail: "已改完。要不要我继续把测试补上？" }).kind, "continue");
});

test("T-debug-M4：provider 挂起时路由在硬超时内返回结构化错误，不再无限挂起", async () => {
  const host = await import("../lib/index.js");
  const llm = {
    seen: [],
    stream() {
      return (async function* generate() {
        await new Promise(() => {}); // 永不产出、永不结束的失控 provider
      })();
    },
  };
  const webServer = makeWebServer();
  host.apply(makeHostContext(webServer, { llm }), { samples: false, requestTimeoutMs: 60 });
  const res = makeResponse();
  const startedAt = Date.now();
  await webServer.routes[0].handler(
    makeRequest({ body: JSON.stringify({ text: "帮我做一个登录页面，支持手机号验证码" }) }),
    res,
  );
  const payload = JSON.parse(res.body);
  assert.equal(payload.ok, false);
  assert.equal(payload.code, "request_timeout");
  assert.ok(Date.now() - startedAt < 5000, "必须秒级返回，而不是挂到客户端超时");
});

test("T-debug-L5：超大体量输出被确定性拒绝，不再透传进输入框", async () => {
  const llm = scriptedLlm([textChunks("好".repeat(40000))]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "帮我写一个登录页面的需求描述" });
  assert.equal(result.ok, false);
  assert.equal(result.code, "output_too_large");
});

// --------------------------------------------------------------------------
// 0.10.0 优化回归（真实 samples.jsonl 驱动：撤销样本 → 分类修复；延迟 → 短路）
// --------------------------------------------------------------------------

test("T-opt-A：多选数字（1，2 / 1、2 / 1 2 / 1,2,3）归信号分支，不再当种子展开", () => {
  // 真实撤销样本：「1，2」被 seed 展开两次（35×/19×），用户连续撤销。
  assert.equal(classifySignalInput("1，2").kind, "number");
  assert.equal(classifySignalInput("1，2").token, "1、2");
  assert.equal(classifySignalInput("1、2").kind, "number");
  assert.equal(classifySignalInput("1 2").kind, "number");
  assert.equal(classifySignalInput("1,2,3").token, "1、2、3");
  // 边界：小数混合、带文字的数字不误判
  assert.equal(classifySignalInput("1.5，2").kind, "none");
  assert.equal(classifySignalInput("做1个页面").kind !== "number", true);
});

test("T-opt-A：多选推断——全对上选项才算 choice，部分对上拒绝硬猜", () => {
  const tail = "两个方案：1. 用Redis缓存 2. 直接查库加索引";
  const hit = inferPendingItem({ kind: "number", token: "1、2" }, undefined, { role: "assistant", text: tail });
  assert.equal(hit.mode, "choice");
  assert.ok(hit.anchor.includes("Redis") && hit.anchor.includes("查库"), "锚点必须带齐两个选项");
  const miss = inferPendingItem({ kind: "number", token: "1、5" }, undefined, { role: "assistant", text: tail });
  assert.equal(miss.mode, "none");
});

test("T-opt-A 端到端：会话里点「1，2」→ 信号展开而不是 seed 扩写", async () => {
  const llm = scriptedLlm([textChunks("继续做第一项和第二项：先加 Redis 缓存，再给查询库加索引。")]);
  const result = await optimizePromptText({
    llm,
    route: ROUTE,
    text: "1，2",
    assistantTail: { role: "assistant", text: "两个方案：1. 用Redis缓存 2. 直接查库加索引" },
  });
  assert.equal(result.ok, true, JSON.stringify(result));
  assert.equal(result.mode, "signal", "多选数字必须走信号分支");
  assert.equal(result.tier, "signal");
  assert.ok(result.text.length <= 120 * 1.6, "信号展开受短上限约束");
});

test("T-opt-B：确认-放行消息归会话分支（真实撤销样本全覆盖）", () => {
  // 样本原句：展开 18×/27× 被撤销
  assert.equal(isConversationalMessage("好，按照这个路线继续。"), true);
  assert.equal(isConversationalMessage("可以，你按这个去做吧。"), true);
  assert.equal(isConversationalMessage("好的，就这么办。"), true);
  assert.equal(isConversationalMessage("嗯，继续。"), true);
  assert.equal(isConversationalMessage("行，按这个来。"), true);
  assert.equal(isConversationalMessage("对，就这样做。"), true);
  // 不误伤：确认词开头的新任务仍是种子
  assert.equal(isConversationalMessage("好，帮我做一个登录页面"), false);
  assert.equal(isConversationalMessage("可以，现在把 README 的安装一节翻成英文"), false);
});

test("T-opt-B 端到端：「好，按照这个路线继续。」轻润色 1.0×，绝不展开", async () => {
  const llm = scriptedLlm([textChunks("好，按照这个路线继续。")]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "好，按照这个路线继续。" });
  assert.equal(result.ok, true, JSON.stringify(result));
  assert.equal(result.mode, "conversational");
  assert.equal(llm.seen.length, 1, "会话分支只花一次调用");
  assert.ok(result.text.length <= Math.ceil(11 * 1.35) + 6, "遵守轻润色上限");
});

test("T-opt-C：澄清丢内容（低于 0.7×）不走短路，审判照跑并拦下", async () => {
  const llm = scriptedLlm([
    textChunks("MODE: clarify\n看看那个导出。"),                      // 丢了"能不能用"的检查意图
    textChunks("DISTORTED: 丢失了可用性检查的意图"),                   // 审判必须真的跑
    textChunks(""),                                                   // 修复失败 → 拒绝保留原文
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "帮我看看那个东西能不能用，就是昨天说的那个导出" });
  assert.equal(result.ok, false);
  assert.equal(result.code, "fidelity_rejected");
  assert.ok(llm.seen.length >= 2, "带外澄清稿必须进审判");
});

test("T-opt-C：seed 分支不受短路影响，审判照跑", async () => {
  const llm = scriptedLlm([
    textChunks("MODE: seed\n做一个登录页面，支持账号密码与验证码两种方式，失败时提示并可重试。"),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "做一个登录页面" });
  assert.equal(result.ok, true);
  assert.equal(result.gate.verdict, "ok", "seed 稿仍要语义审判");
  assert.equal(llm.seen.length, 2);
});

test("T-opt-R：共享句子/字符集工具与旧实现逐字等价（去重不改变行为）", async () => {
  const mt = await import("../src/message-text.js");
  assert.equal(mt.lastSentenceOf("已梳理。要不要继续？1. A 2. B"), "1. A 2. B");
  assert.equal(mt.lastSentenceOf("无边界整段"), "无边界整段");
  assert.equal(mt.lastMatchingSentenceOf("先说A。要不要继续？1. A 2. B", /要不要/), "要不要继续？", "从后往前扫到倒数第二句");
  assert.equal(mt.lastMatchingSentenceOf("没有命中", /要不要/), undefined);
  assert.equal(mt.cjkCharSet("abc你好def").size, 2);
  assert.equal([...mt.latinWordSet("The the THE")].length, 1, "小写化去重");
  assert.equal(mt.latinWordSet("The the THE").has("the"), true);
});

// --------------------------------------------------------------------------
// 0.10.1 迭代回归（P0-2 归因 / P1-4 effort / P1-6 英文规则 / P1-7 locale）
// --------------------------------------------------------------------------

import { conversationalRuleOf } from "../src/signal-inference.js";

test("T-iter-P0：classificationSource 落盘——会话分支带规则名，自适应带档位", async () => {
  const host = await import("../lib/index.js");
  const dir = await mkdtemp(join(tmpdir(), "po-iter-src-"));
  const samples = join(dir, "samples.jsonl");
  try {
    // 会话消息（opinion 规则）
    const webServer = makeWebServer();
    host.apply(makeHostContext(webServer, { llm: scriptedLlm([textChunks("我觉得这个方案还是不太对")]) }), { samples });
    const res = makeResponse();
    await webServer.routes[0].handler(
      makeRequest({ body: JSON.stringify({ text: "我觉得这个方案还是不太对？" }) }),
      res,
    );
    assert.equal(JSON.parse(res.body).ok, true);
    // 自适应种子
    const webServer2 = makeWebServer();
    host.apply(
      makeHostContext(webServer2, {
        llm: scriptedLlm([
          textChunks("MODE: seed\n做一个登录页面，支持账号密码与验证码两种方式，失败提示重试。"),
          textChunks("OK"),
        ]),
      }),
      { samples },
    );
    const res2 = makeResponse();
    await webServer2.routes[0].handler(
      makeRequest({ body: JSON.stringify({ text: "做一个登录页面" }) }),
      res2,
    );
    assert.equal(JSON.parse(res2.body).ok, true);

    const rows = (await readFile(samples, "utf8")).trim().split("\n").map((line) => JSON.parse(line));
    const sources = rows.map((r) => r.classificationSource);
    assert.ok(sources.includes("conversational-opinion"), "会话分支必须落规则名：", JSON.stringify(sources));
    assert.ok(sources.includes("adaptive-seed"), "自适应必须落档位：", JSON.stringify(sources));
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test("T-iter-P1e：英文输入走对分支（信号/会话/确认放行），种子不误伤", async () => {
  // 信号词
  assert.equal(classifySignalInput("keep going").kind, "signal");
  assert.equal(classifySignalInput("proceed.").kind, "signal");
  assert.equal(classifySignalInput("undo").kind, "deictic");
  // 会话消息
  assert.equal(conversationalRuleOf("I think the result is worse than before"), "opinion");
  assert.equal(conversationalRuleOf("Why is this happening?"), "question");
  assert.equal(conversationalRuleOf("My question is about the config"), "meta");
  assert.equal(conversationalRuleOf("Is it worth the effort?"), "question");
  assert.equal(conversationalRuleOf("Keep checking this"), "continuation");
  // 确认-放行
  assert.equal(conversationalRuleOf("OK, continue as planned."), "go-ahead");
  assert.equal(conversationalRuleOf("Sure, go ahead and do it."), "go-ahead");
  // 种子不误伤（SEED_VERB 守卫）
  assert.equal(conversationalRuleOf("Help me build a login page"), null);
  assert.equal(conversationalRuleOf("Should I fix the parser bug?"), null, "含任务动词按设计放行给自适应");
  // 中文行为不回归
  assert.equal(conversationalRuleOf("我觉得不对"), "opinion");
  assert.equal(classifySignalInput("继续。").kind, "signal");
});

test("T-iter-P1e：助手问句划界的英文措辞也被认出", async () => {
  const llm = scriptedLlm([textChunks("Restarted. What should I do next?")]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "Restarted, what should I do next" });
  assert.equal(result.ok, true, JSON.stringify(result));
  assert.equal(result.mode, "conversational", "英文下一步类问句走会话分支，不再被 seed 展开");
  assert.equal(result.classificationSource, "conversational-question", "英文问句由 CHOICE_QUESTION 规则接住（与 assistant-question 同分支同结果）");
});

test("T-iter-P1m：rewriteReasoningEffort=inherit 时改写跟随路由 effort，审判与缺省不受影响", async () => {
  const host = await import("../lib/index.js");
  const model = { currentSelection: () => ({ provider: "p", model: "m", reasoningEffort: "high" }) };
  const draft = textChunks("MODE: seed\n做一个登录页面，支持账号密码与验证码两种方式，失败提示重试。");
  const makeCtx = (llm) => makeHostContext(makeWebServer(), { llm, model });

  // inherit：改写带 high，审判不带
  const llm1 = scriptedLlm([draft, textChunks("OK")]);
  const ws1 = makeWebServer();
  host.apply({ ...makeCtx(llm1), webServer: ws1 }, { samples: false, rewriteReasoningEffort: "inherit" });
  const res1 = makeResponse();
  await ws1.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "做一个登录页面" }) }), res1);
  assert.equal(JSON.parse(res1.body).ok, true);
  assert.equal(llm1.seen[0].reasoningEffort, "high", "改写调用必须透传 effort");
  assert.ok(!("reasoningEffort" in llm1.seen[1]), "审判调用永远不带 effort");

  // 缺省：不透传（旧行为）
  const llm2 = scriptedLlm([draft, textChunks("OK")]);
  const ws2 = makeWebServer();
  host.apply({ ...makeCtx(llm2), webServer: ws2 }, { samples: false });
  const res2 = makeResponse();
  await ws2.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "做一个登录页面" }) }), res2);
  assert.ok(!("reasoningEffort" in llm2.seen[0]), "缺省不透传 effort");
});

test("T-iter-P7：locale 服务给 en 时界面切英文，缺省中文", async () => {
  const hEn = await makeClientHarness({ draft: "帮我做个登录功能", locale: "en-US" });
  try {
    assert.equal(hEn.primary().props.title.indexOf("Optimize prompt"), 0, "英文环境 tooltip 必须是英文");
    assert.equal(hEn.primary().props["aria-label"], hEn.primary().props.title);
  } finally {
    hEn.restore();
  }
  const hZh = await makeClientHarness({ draft: "帮我做个登录功能" });
  try {
    assert.equal(hZh.primary().props.title.indexOf("优化提示词"), 0, "缺省（无 locale 服务、非浏览器）必须是中文");
  } finally {
    hZh.restore();
  }
});

// --------------------------------------------------------------------------
// 0.12.0 统一管线（改写+自审+修正单次调用；约束力四层）
// --------------------------------------------------------------------------

test("T-uni 解析：行式 / 单行 / 缺段各归其位", async () => {
  const { parseUnifiedResult } = await import("../src/prompt-templates.js");
  const multi = parseUnifiedResult("MODE: seed\nDRAFT: 做登录页。\nAUDIT: OK\nFINAL: 做登录页。");
  assert.equal(multi.malformed, false);
  assert.equal(multi.audit.status, "ok");
  // 实测漂移形态：四段挤一行
  const single = parseUnifiedResult("MODE: seed DRAFT: 做登录页。 AUDIT: OK FINAL: 做登录页。");
  assert.equal(single.malformed, false, "单行协议必须认");
  assert.equal(single.final, "做登录页。");
  // 缺段降级
  assert.equal(parseUnifiedResult("MODE: seed\nDRAFT: 只有草稿没有后续").malformed, true);
  assert.equal(parseUnifiedResult("MODE: seed\nDRAFT: x\nAUDIT: OK\nFINAL:  ").malformed, true, "FINAL 空段 = malformed");
  // 违规归一化与独立审判同源
  const issues = parseUnifiedResult("MODE: seed\nDRAFT: x\nAUDIT: SCOPE_ADDED: 加了支付\nFINAL: y");
  assert.deepEqual(issues.audit.violations, [{ kind: "scope_added", text: "加了支付" }]);
});

test("T-uni 自审 OK：一次调用直达，省掉独立审判", async () => {
  const llm = scriptedLlm([textChunks("MODE: seed\nDRAFT: 做一个登录页，支持账号密码。\nAUDIT: OK\nFINAL: 做一个登录页，支持账号密码。")]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "做一个登录页", pipeline: "unified" });
  assert.equal(result.ok, true);
  assert.equal(llm.seen.length, 1, "统一管线快乐路径只有一次调用");
  assert.equal(result.classificationSource, "unified-seed");
  assert.ok(llm.seen[0].system.includes("SELF-AUDIT CONTRACT"), "system 必须带自审契约");
});

test("T-uni 自审违规+真修：一次调用交付修复稿，凭证标 repaired", async () => {
  const llm = scriptedLlm([textChunks("MODE: seed\nDRAFT: 做登录页并接入支付。\nAUDIT: SCOPE_ADDED: 加了支付\nFINAL: 做登录页。")]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "做一个登录页", pipeline: "unified" });
  assert.equal(result.ok, true);
  assert.equal(result.tier, "repaired");
  assert.equal(result.gate.verdict, "repaired");
  assert.equal(llm.seen.length, 1, "自审修复不再花第二次调用");
});

test("T-uni 绑定力：报了违规但 FINAL 逐字没修 → 按自报违规拒绝", async () => {
  const llm = scriptedLlm([textChunks("MODE: seed\nDRAFT: 做登录页并接入支付。\nAUDIT: SCOPE_ADDED: 加了支付\nFINAL: 做登录页并接入支付。")]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "做一个登录页", pipeline: "unified" });
  assert.equal(result.ok, false);
  assert.equal(result.code, "fidelity_rejected");
  assert.equal(result.violations.length, 1);
  assert.equal(llm.seen.length, 1);
});

test("T-uni 假修判据是逐字而非骨架：小稿删从句的真修不被误杀", async () => {
  const llm = scriptedLlm([textChunks("MODE: seed\nDRAFT: 做登录页，支持验证码，并生成周报邮件。\nAUDIT: SCOPE_ADDED: 周报邮件\nFINAL: 做登录页，支持验证码。")]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "做一个登录页", pipeline: "unified" });
  assert.equal(result.ok, true, "删一个从句（5字/21字，在骨架容差内）是真修，必须采纳");
  assert.equal(result.tier, "repaired");
});

test("T-uni precise 例外：非近原样不信任自审，照走独立审判", async () => {
  const input = "删除 src/a.js 里未被引用的 parse 函数，跑一遍测试确认没破坏";
  const fat = "把 src/a.js 里的 parse 函数删除并跑测试，同时补充单元测试覆盖所有分支确保回归安全。";
  const fixed = "删除 src/a.js 里未被引用的 parse 函数，然后跑一遍测试确认没破坏。";
  const llm = scriptedLlm([
    textChunks(`MODE: precise\nDRAFT: ${fat}\nAUDIT: OK\nFINAL: ${fat}`), // 自审放水
    textChunks("PADDED: 加了补测试要求"),                                  // 独立审判抓到
    textChunks(fixed),                                                     // 修复
    textChunks("OK"),                                                      // 复核
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: input, pipeline: "unified" });
  assert.equal(result.ok, true);
  assert.equal(result.tier, "repaired", "precise 的越线必须由独立审判拦下");
  assert.ok(llm.seen.length >= 3, "必须真的跑了独立审判");
});

test("T-uni 协议残缺：自动降级 split 语义（独立审判接管同段文本）", async () => {
  const llm = scriptedLlm([
    textChunks("MODE: seed\n做一个登录页，支持账号密码与验证码，失败提示重试。"), // 无 DRAFT/AUDIT/FINAL
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "做一个登录页", pipeline: "unified" });
  assert.equal(result.ok, true);
  assert.equal(result.classificationSource, "adaptive-seed", "降级路径归因回 adaptive");
  assert.equal(llm.seen.length, 2, "降级 = split 的两次调用");
});

test("T-uni 自审 THIN：走既有补全链，补全稿仍过独立审判", async () => {
  const llm = scriptedLlm([
    textChunks("MODE: seed\nDRAFT: 登录\nAUDIT: THIN: 没有展开\nFINAL: 登录"),
    textChunks("做一个登录页面：支持账号密码与验证码两种方式，失败时提示并可重试。"),
    textChunks("OK"),
  ]);
  const result = await optimizePromptText({ llm, route: ROUTE, text: "登录", pipeline: "unified" });
  assert.equal(result.ok, true);
  assert.equal(result.tier, "elaborated", "THIN 补全链照常工作");
  assert.equal(llm.seen.length, 3);
});

test("T-uni 路由：pipeline 行配置与 body 覆盖（A/B 排障用）", async () => {
  const host = await import("../lib/index.js");
  const draft = textChunks("MODE: seed\n做一个登录页，支持验证码与失败重试。");
  // 行配置 split → 双调用
  const llm1 = scriptedLlm([draft, textChunks("OK")]);
  const ws1 = makeWebServer();
  host.apply(makeHostContext(ws1, { llm: llm1 }), { samples: false, pipeline: "split" });
  const res1 = makeResponse();
  await ws1.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "做一个登录页" }) }), res1);
  assert.equal(llm1.seen.length, 2, "split 配置维持两次调用");
  assert.ok(!llm1.seen[0].system.includes("SELF-AUDIT CONTRACT"));
  // 缺省 unified + body 覆盖 split
  const llm2 = scriptedLlm([draft, textChunks("OK")]);
  const ws2 = makeWebServer();
  host.apply(makeHostContext(ws2, { llm: llm2 }), { samples: false });
  const res2 = makeResponse();
  await ws2.routes[0].handler(makeRequest({ body: JSON.stringify({ text: "做一个登录页", pipeline: "split" }) }), res2);
  assert.ok(!llm2.seen[0].system.includes("SELF-AUDIT CONTRACT"), "body.pipeline=split 必须覆盖缺省");
});
