# 🚀 DeepSeek Harness GUI - Instalação Windows (dsh-h-v1)

Instalação da camada personalizada do DeepSeek Harness no Windows 10/11,
**sincronizada por git** — esta máquina recebe sempre a última versão
publicada no repositório **e também publica** as suas edições (mão dupla).

> ⚠️ Caminhos como `installer\install.bat` e `tools\...` são **relativos à raiz
> do repositório** (a pasta do clone), não a esta pasta de documentação.
>
> Leia também o manual de sincronização: [`SYNC.md`](SYNC.md) (PT) ·
> [`SYNC.en.md`](SYNC.en.md) (EN) · versão EN deste guia: [`WINDOWS.md`](WINDOWS.md)

---

## 📋 Pré-requisitos

| Requisito | Detalhe |
|---|---|
| Sistema Operacional | Windows 10 ou 11 (64-bit recomendado) |
| Node.js | v20+ LTS (recomendado) |
| Git | com autenticação GitHub (`gh auth login` ou credential helper) |

---

## 🔧 Instalação

### ✅ Opção 1: Instalador automático (`installer/install.bat`)

1. Clone o repositório:
   ```cmd
   git clone https://github.com/marcosmmjr2023/dsh-h-v1.git %USERPROFILE%\dsh-h-v1
   ```
2. Execute `installer\install.bat` (ele instala o core via npm, aplica o
   overlay em `%USERPROFILE%\.dsh` e cria o `start-dsh-gui.bat`).

### ✅ Opção 2: PowerShell (`installer/install.ps1`)

Clique com o botão direito → "Executar com PowerShell".
Em caso de restrição de execução:
```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

### ✅ Opção 3: Manual

```cmd
npm install -g @deepseek-ai/dsh
powershell -ExecutionPolicy Bypass -File tools\sync-pull.ps1
```

---

## ▶️ Como Executar

- Dê dois cliques no `start-dsh-gui.bat` (gerado pelo instalador) — ele já
  roda o sync de **mão dupla** (`auto-sync.ps1`: recebe + publica) antes de
  abrir a GUI.
- Ou manualmente, dentro da pasta de instalação do harness:
  ```cmd
  dsh web --port 3080
  ```
- Abra o navegador: [http://127.0.0.1:3080](http://127.0.0.1:3080)

---

## 🔄 Sincronizar (mão dupla)

| Ação | Comando (PowerShell) |
|---|---|
| Ciclo completo: recebe + publica | `powershell -ExecutionPolicy Bypass -File "%USERPROFILE%\dsh-h-v1\tools\auto-sync.ps1"` |
| Receber a última versão | `powershell -ExecutionPolicy Bypass -File "%USERPROFILE%\dsh-h-v1\tools\sync-pull.ps1"` |
| Publicar edições locais | `powershell -ExecutionPolicy Bypass -File "%USERPROFILE%\dsh-h-v1\tools\sync-push.ps1" "o que mudou"` |
| Ver versão do core | `powershell -ExecutionPolicy Bypass -File "%USERPROFILE%\dsh-h-v1\tools\check-core.ps1"` |
| Listar versões p/ voltar | `powershell -ExecutionPolicy Bypass -File "%USERPROFILE%\dsh-h-v1\tools\rollback.ps1" list` |

> Cada publicação automática sobe uma versão `vX.Y.Z`, uma entrada no
> `CHANGELOG.md` e uma tag (âncora de rollback) — só o que está na sua
> **config viva** (`%USERPROFILE%\.dsh`) é publicado, nunca credenciais/sessões/logs.
> Se uma atualização quebrar algo, clique no botão **↩** do badge de versão
> (painel) ou rode `rollback.ps1` para voltar — o auto-update é desligado e a
> GUI reinicia.

---

## 🗂️ Estrutura do Pacote

```
dsh-h-v1/
├── overlay/                → Config viva (%USERPROFILE%\.dsh)
├── tools/                  → Scripts de sync + guard
├── installer/              → install.bat, install.ps1, start-dsh-gui.bat
├── manifest.json           → Versão do core pinada
└── docs/                   → SYNC.md / SYNC.en.md / WINDOWS-PT.md / WINDOWS.md
```

## 🧰 Solução de Problemas Comuns

| Erro | Solução |
|---|---|
| `node is not recognized` | Instale o Node.js e reinicie o CMD/PowerShell |
| `git` não reconhecido | Instale o Git for Windows |
| Não abre a página no navegador | Aguarde e recarregue a aba |
| Porta 3080 em uso | `netstat -ano \| findstr 3080` e encerre o processo |

---

## 🧪 Checklist de teste manual (Windows)

Após instalar/clonar numa máquina Windows nova, confira (validação manual —
o CI cobre sintaxe/estática, mas não executa Windows real):

1. `installer\install.bat` conclui sem erro e cria o atalho na Área de Trabalho.
2. Abrir o atalho: roda o `auto-sync` (recebe + publica) e a GUI abre em http://127.0.0.1:3080.
3. `%USERPROFILE%\.dsh\cordis.patch.yml` existe e aponta para `C:\Users\...` (não
   contém `__DSH_HOME__` nem `/home/deploy`).
4. Badges do FreeLLMAPI e o painel lateral (layout) aparecem no dashboard.
5. Edite um plugin/setting → `tools\sync-push.ps1 "teste"` publica; outra máquina
   recebe com `sync-pull`.
6. `tools\rollback.ps1 list` mostra snapshots/tags; um `rollback` restaura.

## 📝 Notas Finais

- Credenciais vivem em `%USERPROFILE%\.dsh\.credentials.yaml` (nunca
  sincronizada nem commitada — variáveis de ambiente também funcionam).
- A versão do core do harness é instalada pelo npm e **não** vem deste repo.
