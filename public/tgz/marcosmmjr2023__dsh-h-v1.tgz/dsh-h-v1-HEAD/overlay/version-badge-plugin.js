/**
 * Version Badge — badge de versão + chave de auto-atualização + ROLLBACK no painel.
 *
 * Server-side (via ctx.get("webServer")):
 *   GET  /api/dsh-version → { ok, version, commit, updatedAt, autoUpdate }
 *     .dsh-version.json  é GERADO pelo sync (tools/stamp-version.sh/.ps1).
 *     autoUpdate = true quando NÃO existe <config viva>/.dsh-autoupdate.off.
 *   POST /api/dsh-version {"autoUpdate": bool} → cria/remove o flag
 *     .dsh-autoupdate.off (o agendador local de auto-update consulta esse
 *     flag antes de sincronizar). Arquivo é LOCAL da máquina.
 *
 *   GET  /api/dsh-rollback → { ok, current, tags[], snapshots[], previous, autoUpdate }
 *     Lista as versões publicadas (tags vX.Y.Z) e os snapshots locais
 *     (~/.dsh-snapshots) disponíveis para voltar.
 *   POST /api/dsh-rollback {"target": "v0.2.0" | "snap-20260906-..."}
 *     → roda tools/rollback.sh <target> (snapshot automático do estado atual),
 *       DESLIGA o auto-update (flag .dsh-autoupdate.off) e reinicia o harness
 *       sozinho quando ele roda sob pm2 (senão orienta reiniciar manualmente).
 *
 *   POST /api/dsh-sync {"action":"start"} → roda tools/sync-pull.ps1/.sh
 *     em BACKGROUND (git pull + overlay + stamp) e devolve {id} para polling;
 *   GET  /api/dsh-sync?progress=1&id=… → progresso do sync.
 *     É o botão ⬆ do badge: atualiza sem esperar o agendado. Ao concluir,
 *     reinicie a GUI para recarregar os plugins (botão Reiniciar agora).
 *
 * Client-side: badge "v<versão> · <atualizado>" + botão "🔄 auto" (ON/OFF)
 * + botão "↩" que abre o painel de rollback (voltar para uma versão anterior
 * se uma atualização quebrar o sistema). Recolhidos pelo LayoutPanel na
 * coluna direita (.dlp-badges).
 *
 * Localização dos arquivos: o diretório deste plugin quando ele É a config viva
 * (overlay copiado para ~/.dsh); instalado como BUNDLE (`dsh plugin add`, código
 * dentro de node_modules) o estado vai para DSH_HOME / ~/.dsh, nunca para o pacote.
 * Clone do repo: env DSH_CLONE ou ~/projects/dsh/dsh-h-v1 (canônico) / legado ~/dsh-v2;
 * sem clone, as ferramentas são procuradas dentro do próprio pacote.
 */
"use strict";

const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { execFile, execFileSync, execSync, spawn } = require("node:child_process");

const IS_WIN = process.platform === "win32";

const HOME = os.homedir();

/**
 * Diretorio onde mora o ESTADO da config viva (.dsh-version.json, flags,
 * caches, historico). No fluxo do overlay este arquivo e copiado para a
 * propria config viva, entao __dirname ja e o lugar certo; instalado como
 * BUNDLE (dsh plugin add) o plugin roda de dentro de node_modules/freedsh e o
 * estado precisa continuar indo para a config viva do usuario.
 */
function liveDir() {
  const aqui = (typeof __dirname === "string" && __dirname) ? __dirname : "";
  const dentroDoPacote = /[\\/]node_modules[\\/]/.test(aqui);
  const temCarimbo = (d) => { try { return fs.existsSync(path.join(d, ".dsh-version.json")); } catch { return false; } };
  // 1) overlay copiado para a config viva: o carimbo de versão está ao lado do plugin
  if (aqui && !dentroDoPacote && temCarimbo(aqui)) return aqui;
  // 2) config viva declarada explicitamente (instância isolada, HOME alternativo)
  if (process.env.DSH_HOME) return process.env.DSH_HOME;
  // 3) overlay copiado, ainda sem carimbo (primeira execução)
  if (aqui && !dentroDoPacote) return aqui;
  // 4) instalado como pacote (npm/git): o estado vai para a config viva padrão
  return path.join(HOME, ".dsh");
}
const LIVE = liveDir();

const VERSION_FILE = path.join(LIVE, ".dsh-version.json");
const AUTO_UPDATE_OFF = path.join(LIVE, ".dsh-autoupdate.off");

/**
 * Le um JSON tolerando o BOM UTF-8.
 * O Windows PowerShell 5.1 grava `Set-Content -Encoding UTF8` COM BOM
 * (EF BB BF) e o JSON.parse lanca excecao nesse caso — era o que fazia o badge
 * de versao mostrar "local" em vez da versao real no Windows.
 */
function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8").replace(/^\uFEFF/, ""));
}

function autoUpdateEnabled() {
  return !fs.existsSync(AUTO_UPDATE_OFF);
}

function cloneDir() {
  if (process.env.DSH_CLONE) return process.env.DSH_CLONE;
  const pacote = path.resolve(__dirname, ".."); // instalado como bundle?
  const candidates = [
    path.join(HOME, "projects", "dsh", "dsh-h-v1"), // canônico nesta máquina
    path.join(HOME, "dsh-v2"),                       // legado
    path.join(HOME, "dsh-h-v1"),
    pacote,                                          // bundle: tools/ vem no pacote
  ];
  for (const c of candidates) {
    try {
      const temFerramentas = fs.existsSync(path.join(c, "tools", "rollback.sh"))
        || fs.existsSync(path.join(c, "tools", "rollback.ps1"));
      // o pacote instalado não traz .git; os demais candidatos precisam ser um clone
      if (temFerramentas && (c === pacote || fs.existsSync(path.join(c, ".git")))) return c;
    } catch { /* tenta o próximo */ }
  }
  return candidates[0];
}

function snapRoot() {
  return process.env.DSH_SNAP_ROOT || path.join(HOME, ".dsh-snapshots");
}

function versionPayload() {
  let data = { ok: false, version: "local", commit: "", updatedAt: "" };
  try {
    data = readJson(VERSION_FILE);
  } catch { /* sem arquivo (ou arquivo ilegivel): cai no fallback abaixo */ }
  // Fallback: sem o carimbo do sync, a versao do overlay e a tag do clone.
  // Assim o badge nunca fica em "local" so porque o arquivo faltou/veio
  // corrompido (era o sintoma no Windows, onde o launcher gravava com BOM).
  if (data.version === "local") {
    try {
      const clone = cloneDir();
      const tag = String(execFileSync("git", ["-C", clone, "describe", "--tags", "--abbrev=0"], {
        encoding: "utf8", timeout: 8000, windowsHide: true,
      }) || "").trim();
      const sha = String(execFileSync("git", ["-C", clone, "rev-parse", "--short", "HEAD"], {
        encoding: "utf8", timeout: 8000, windowsHide: true,
      }) || "").trim();
      if (tag) data = { version: tag, commit: sha, updatedAt: "" };
    } catch { /* sem git/clone: tenta a versão do pacote (instalação por bundle) */ }
    // Sem clone com .git (instalação por BUNDLE) o fallback passa a ser a versão
    // do próprio pacote, para o badge não exibir "local" nesse caminho.
    if (data.version === "local") {
      try {
        const pkg = JSON.parse(fs.readFileSync(path.resolve(__dirname, "..", "package.json"), "utf8"));
        if (pkg && pkg.name === "freedsh" && pkg.version) {
          data = { version: "v" + String(pkg.version), commit: "", updatedAt: "" };
        }
      } catch { /* mantém "local" */ }
    }
  }
  return {
    ok: true,
    version: String(data.version ?? "?"),
    commit: String(data.commit ?? ""),
    updatedAt: String(data.updatedAt ?? ""),
    autoUpdate: autoUpdateEnabled(),
  };
}

function setAutoUpdate(enabled) {
  try {
    if (enabled) {
      if (fs.existsSync(AUTO_UPDATE_OFF)) fs.unlinkSync(AUTO_UPDATE_OFF);
    } else {
      fs.writeFileSync(AUTO_UPDATE_OFF, "off\n");
    }
    return { ok: true, autoUpdate: autoUpdateEnabled() };
  } catch (e) {
    return { ok: false, error: String(e.message || e) };
  }
}

function git(args, cb) {
  execFile("git", ["-C", cloneDir()].concat(args), { timeout: 15000 }, (err, stdout, stderr) => {
    if (err) return cb(null, err.message || String(err));
    cb(String(stdout || "").trim());
  });
}

function listSnapshots() {
  const root = snapRoot();
  try {
    return fs.readdirSync(root, { withFileTypes: true })
      .filter((d) => d.isDirectory() && /^snap-/.test(d.name))
      .map((d) => d.name)
      .sort()
      .reverse()
      .slice(0, 8);
  } catch {
    return [];
  }
}

function rollbackList(cb) {
  const current = versionPayload();
  git(["tag", "--list", "v[0-9]*", "--sort=-version:refname", "--format=%(refname:short) %(creatordate:short)"], (tagsText) => {
    const tags = [];
    let names = [];
    if (tagsText) {
      tagsText.split("\n").forEach((line) => {
        const m = /^(\S+)\s+(.*)$/.exec(line);
        if (m) { tags.push({ name: m[1], date: m[2] }); names.push(m[1]); }
      });
    }
    let previous = null;
    const cur = String(current.version || "");
    const idx = names.indexOf(cur);
    if (idx === -1) previous = names.length ? names[0] : null;
    else if (idx + 1 < names.length) previous = names[idx + 1];
    cb({
      ok: true,
      current: { version: cur, commit: current.commit, updatedAt: current.updatedAt },
      tags,
      snapshots: listSnapshots(),
      previous,
      autoUpdate: autoUpdateEnabled(),
      clone: cloneDir(),
    });
  });
}

function doRollback(target, cb) {
  const clone = cloneDir();
  const toolName = IS_WIN ? "rollback.ps1" : "rollback.sh";
  const rollbackTool = path.join(clone, "tools", toolName);
  if (!fs.existsSync(rollbackTool)) {
    cb({ ok: false, error: "tools/" + toolName + " não encontrado no clone: " + clone });
    return;
  }
  const isSnapshot = /^snap-/.test(target);
  const env = Object.assign({}, process.env, {
    DSH_CLONE: clone,
    DSH_LIVE: LIVE,
    DSH_SNAP_ROOT: snapRoot(),
  });
  // No Windows os parametros do .ps1 sao nomeados (-Cmd/-Arg): passar "--snapshot"
  // cru e erro fatal de binding; e o host (pwsh 7+/5.1) e resolvido em runtime.
  const file = IS_WIN ? psHost() : rollbackTool;
  if (IS_WIN && !file) { cb({ ok: false, error: "PowerShell não encontrado nesta máquina (nem pwsh, nem powershell.exe)" }); return; }
  const args = IS_WIN
    ? psFileArgs(rollbackTool, isSnapshot ? ["-Cmd", "--snapshot", "-Arg", target] : ["-Cmd", target])
    : (isSnapshot ? ["--snapshot", target] : [target]);
  execFile(file, args, { env, timeout: 180000, maxBuffer: 8 * 1024 * 1024, windowsHide: true }, (err, stdout, stderr) => {
    const output = String(stdout || "") + (stderr ? "\n[stderr]\n" + stderr : "");
    if (err) {
      cb({ ok: false, error: "rollback falhou (exit " + (err.code ?? "?") + ")", output });
      return;
    }
    const auto = setAutoUpdate(false); // desliga o auto-update: não reaplica a versão que quebrou
    cb({ ok: true, output, autoUpdate: auto.ok ? false : true, rollbackedTo: target });
  });
}

// Descobre o nome do processo pm2 atual (para reiniciar sozinho após rollback)
function pm2NameOfCurrent(cb) {
  if (!process.env.PM2_HOME) return cb(null);
  execFile("pm2", ["jlist"], { timeout: 8000 }, (err, stdout) => {
    if (err) return cb(null);
    try {
      const list = JSON.parse(String(stdout));
      const me = list.find((p) => String(p.pid) === String(process.pid));
      cb(me ? String(me.name) : null);
    } catch {
      cb(null);
    }
  });
}

function scheduleRestart(delayMs) {
  pm2NameOfCurrent((name) => {
    if (!name) {
      console.log("[VersionBadge] rollback ok — reinicie o harness manualmente (sem pm2).");
      return;
    }
    console.log("[VersionBadge] reiniciando " + name + " em " + delayMs + "ms (rollback aplicado)…");
    setTimeout(() => {
      const child = spawn("pm2", ["restart", name], {
        detached: true,
        stdio: "ignore",
        windowsHide: true,
        env: process.env,
      });
      child.unref();
    }, delayMs);
  });
}

// ══ CORE (kernel-like): status + atualização/rollback MANUAL via sudo ══
// Caminhos fixos do Linux ficam como fallback; nesta maquina (ou em qualquer
// outra) a versao REAL do nucleo e resolvida a partir do proprio nucleo em uso:
// DSH_CLI_LIB (launcher), argv/require.main (<core>/lib/bin.js), a instalacao
// global do npm (%APPDATA%\npm\node_modules) e 'npm root -g'.
const CORE_CANDIDATES = [
  "/opt/dsh-tui/node/lib/node_modules/@deepseek-ai/dsh/package.json",
  "/usr/lib/node_modules/@deepseek-ai/dsh/package.json",
];
const CORE_CHECK_CACHE = path.join(LIVE, ".dsh-core-check.json");
const CORE_HISTORY = path.join(LIVE, ".dsh-core-history.json");

let corePathsCache = null;
/** Caminhos candidatos do package.json do nucleo, do mais confiavel ao fixo. */
function corePackageJsonPaths() {
  if (corePathsCache) return corePathsCache;
  const out = [];
  const push = (p) => { if (p && !out.includes(p)) out.push(p); };
  // pasta lib/ do nucleo em uso (run-gui/dsh-cli exportam DSH_CLI_LIB)
  if (process.env.DSH_CLI_LIB) push(path.join(process.env.DSH_CLI_LIB, "..", "package.json"));
  // o proprio processo que roda a GUI: <core>/lib/bin.js
  try { if (process.argv[1]) push(path.resolve(path.dirname(process.argv[1]), "..", "package.json")); } catch { /* ok */ }
  try { if (require.main && require.main.filename) { push(path.resolve(path.dirname(require.main.filename), "..", "package.json")); } } catch { /* ok */ }
  // instalacao global do npm no Windows: %APPDATA%\npm\node_modules
  if (process.env.APPDATA) push(path.join(process.env.APPDATA, "npm", "node_modules", "@deepseek-ai", "dsh", "package.json"));
  // 'npm root -g' (cobre prefixos fora do padrao); uma vez so, na primeira consulta
  try {
    const root = (execSync("npm root -g", { encoding: "utf8", shell: true, timeout: 20000, windowsHide: true }) || "").trim();
    if (root) push(path.join(root, "@deepseek-ai", "dsh", "package.json"));
  } catch { /* sem npm no PATH */ }
  for (const c of CORE_CANDIDATES) push(c);
  corePathsCache = out;
  return out;
}

/** Diretorio do nucleo instalado (para marcadores/cache), ou null. */
function coreDir() {
  for (const f of corePackageJsonPaths()) {
    try { if (fs.existsSync(f)) return path.dirname(f); } catch { /* proximo */ }
  }
  return null;
}

function coreInstalledVersion() {
  if (process.env.DSH_CORE_VERSION) return process.env.DSH_CORE_VERSION; // ambiente paralelo (core-env)
  for (const f of corePackageJsonPaths()) {
    try {
      const j = readJson(f);
      // Confere o NOME: argv/require.main de outro launcher poderia apontar para
      // um package.json que nao e o nucleo (ha 2 clones e 3 GUIs nesta maquina).
      if (j && j.name === "@deepseek-ai/dsh" && j.version) return String(j.version);
    } catch { /* tenta próximo */ }
  }
  return "?";
}
function corePinned() {
  const clone = cloneDir();
  try {
    const m = readJson(path.join(clone, "manifest.json"));
    return { pkg: m.core && m.core.package, pinned: m.core && m.core.pinned };
  } catch { return { pkg: "@deepseek-ai/dsh", pinned: "" }; }
}
/**
 * Comando do `npm view` sem depender do shell: no Windows `npm` e um `.cmd`
 * (execFile direto -> ENOENT) e usar o proprio node com o npm-cli.js evita o
 * shell e o aviso de deprecacao do Node (DEP0190) por passar args com shell:true.
 */
function npmViewCommand() {
  const args = ["view", "@deepseek-ai/dsh", "version"];
  try {
    const cli = path.join(path.dirname(process.execPath), "node_modules", "npm", "bin", "npm-cli.js");
    if (IS_WIN && fs.existsSync(cli)) return { file: process.execPath, args: [cli].concat(args), shell: false };
  } catch { /* sem npm-cli.js adjacente */ }
  return { file: IS_WIN ? "npm.cmd" : "npm", args, shell: IS_WIN };
}

// ── Host do PowerShell ────────────────────────────────────────────────────────
// O sistema NAO pode exigir uma versao especifica de PowerShell: cada maquina
// Windows pode ter so o 5.1 (que acompanha o Windows), so o 7.x (pwsh) ou os
// dois. Resolvemos em tempo de execucao o host que existir (pwsh tem preferencia)
// e usamos SEMPRE a mesma forma de chamada, aceita pelas duas familias.
let psHostCache;
function psHost() {
  if (psHostCache !== undefined) return psHostCache;
  const probe = ["-NoProfile", "-NonInteractive", "-Command", "$PSVersionTable.PSVersion.Major"];
  for (const exe of ["pwsh", "pwsh.exe", "powershell.exe", "powershell"]) {
    try {
      const major = parseInt(String(execFileSync(exe, probe, { encoding: "utf8", timeout: 25000, windowsHide: true }) || "").trim(), 10);
      if (major >= 5) {
        psHostCache = exe;
        console.log("[VersionBadge] host PowerShell: " + exe + " (" + major + ".x)");
        return exe;
      }
    } catch { /* tenta o proximo host */ }
  }
  psHostCache = null;
  console.error("[VersionBadge] nenhum PowerShell encontrado (nem pwsh, nem powershell.exe) — acoes do nucleo/sync indisponiveis.");
  return null;
}
/** Args padrao para rodar um .ps1 do repo nos dois hosts (5.1 e 7+). */
function psFileArgs(script, args) {
  return ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", script].concat(args || []);
}
function coreLatest(force, cb) {
  let cached = null;
  try { cached = readJson(CORE_CHECK_CACHE); } catch { /* sem cache */ }
  const fresh = cached && cached.latest && (Date.now() - (cached.at || 0)) < 60 * 60 * 1000;
  if (fresh && !force) { cb(cached.latest, cached.at); return; }
  const cmd = npmViewCommand();
  execFile(cmd.file, cmd.args, { timeout: 30000, shell: !!cmd.shell, windowsHide: true }, (err, stdout) => {
    const latest = err ? "" : String(stdout || "").trim().split("\n").pop() || "";
    if (latest) {
      try { fs.writeFileSync(CORE_CHECK_CACHE, JSON.stringify({ latest, at: Date.now() })); } catch { /* ok */ }
    } else if (cached && cached.latest) { cb(cached.latest, cached.at); return; }
    cb(latest, latest ? Date.now() : 0);
  });
}
function corePatchesOk(installed) {
  // ambiente paralelo (core-env): pt aplicado por pt-ride — confere o arquivo real
  if (process.env.DSH_CORE_VERSION || process.env.DSH_ENV_NAME || (process.env.DSH_HOME || "").includes(".dsh-envs")) {
    // Layout das dependencias de uma instancia paralela: a fonte autoritativa e o
    // campo coreRoot do meta.json (core-env.ps1 instala com npm --prefix <env>\core,
    // ou seja <env>\core\node_modules). Os outros dois sao fallback de plataforma.
    const envDeps = (envName) => {
      const out = [];
      try {
        const m = readJson(path.join(HOME, ".dsh-envs", envName, "meta.json"));
        if (m && m.coreRoot) out.push(path.join(m.coreRoot, "@deepseek-ai", "dsh", "node_modules", "@deepseek-ai"));
      } catch { /* sem meta.json */ }
      out.push(path.join(HOME, ".dsh-envs", envName, "core", "node_modules", "@deepseek-ai", "dsh", "node_modules", "@deepseek-ai"));
      out.push(path.join(HOME, ".dsh-envs", envName, "core", "lib", "node_modules", "@deepseek-ai", "dsh", "node_modules", "@deepseek-ai"));
      return out;
    };
    const roots = [];
    if (process.env.DSH_ENV_NAME) roots.push(...envDeps(process.env.DSH_ENV_NAME));
    try {
      const base = path.join(HOME, ".dsh-envs");
      for (const e of fs.readdirSync(base)) roots.push(...envDeps(e));
    } catch { /* sem envs */ }
    for (const dep of roots) {
      try {
        const text = fs.readFileSync(path.join(dep, "dsh-client-locale", "lib", "client.js"), "utf8");
        if (text.includes("Português") && text.includes('"pt"')) return { ok: true, note: "pt-BR (pt-ride)" };
      } catch { /* não existe */ }
    }
    return { ok: false, note: "sem pt-BR no ambiente (pt-ride)" };
  }
  // núcleo canônico: marcador do apply-pt-core (gravado em <core>/node_modules)
  const roots = [];
  const dir = coreDir();
  if (dir) roots.push(path.join(dir, "node_modules"));
  roots.push(
    "/opt/dsh-tui/node/lib/node_modules/@deepseek-ai/dsh/node_modules",
    "/usr/lib/node_modules/@deepseek-ai/dsh/node_modules"
  );
  for (const r of roots) {
    try {
      const marker = fs.readFileSync(path.join(r, ".dsh-core-pt-applied"), "utf8");
      if (marker.includes("core=" + installed)) return { ok: true, note: "pt-BR aplicado" };
    } catch { /* sem marcador */ }
  }
  // sem marcador: confere se o cliente do nucleo ja esta traduzido (pt-ride)
  if (dir) {
    try {
      const text = fs.readFileSync(path.join(dir, "node_modules", "@deepseek-ai", "dsh-client-locale", "lib", "client.js"), "utf8");
      if (text.includes("Português") && text.includes('"pt"')) return { ok: true, note: "pt-BR (pt-ride)" };
    } catch { /* nucleo sem cliente traduzido */ }
  }
  return { ok: false, note: IS_WIN ? "sem pt-BR (reaplicar: core-i18n-pt\\tools\\pt-ride.mjs)" : "sem pt-BR (reaplicar: apply-pt-core.sh --force)" };
}
function coreHistory() {
  // O nome canonico e ".dsh-core-history.json" (core-update.sh/.ps1); aceita
  // tambem o nome legado sem ponto, que a versao Windows gravava antes.
  for (const f of [CORE_HISTORY, path.join(LIVE, "core-history.json")]) {
    try {
      const h = readJson(f);
      if (Array.isArray(h)) return h.slice(0, 5);
    } catch { /* tenta o proximo nome */ }
  }
  return [];
}
function sudoersOk(cb) {
  execFile("sudo", ["-n", "-l"], { timeout: 8000 }, (err) => cb(!err));
}
function coreStatus(forceCheck, cb) {
  const installed = coreInstalledVersion();
  const pinned = corePinned();
  const patches = corePatchesOk(installed);
  coreLatest(forceCheck, (latest, at) => {
    cb({
      ok: true,
      installed,
      package: pinned.pkg,
      pinned: pinned.pinned,
      latest: latest || "?",
      hasUpdate: !!(latest && latest !== installed),
      checkedAt: at || Date.now(),
      patches,
      history: coreHistory(),
      envName: process.env.DSH_ENV_NAME || null,
    });
  });
}
// executa a ação do core; NUNCA reinicia sozinho (você aplica com o botão)
function runCoreAction(action, version, json, res) {
  coreAction(action, version, (r) => {
    if (!r.ok) { json(500, r, res); return; }
    if (action !== "update") r.needRestart = true; // rollback canônico: reinicia p/ aplicar
    json(200, r, res);
  });
}
// "Atualizar" do chip = criar uma SEGUNDA instância isolada (core-env), sem tocar na GUI atual.
// Criação da instância roda em BACKGROUND (o painel acompanha por polling).
const CREATE_PROGRESS = new Map();
function toolExt(name) { return IS_WIN ? name + ".ps1" : name + ".sh"; }
function toolFull(name) { return path.join(cloneDir(), "core-i18n-pt", "tools", toolExt(name)); }
function spawnTool(name, args, opts) {
  const t = toolFull(name);
  const base = Object.assign({ windowsHide: true }, opts);
  if (IS_WIN) return spawn(psHost() || "powershell.exe", psFileArgs(t, args), base);
  return spawn(t, args, base);
}
function execToolAsync(name, args, timeout, cb) {
  // `spawn` IGNORA a opcao timeout (so exec/execFile honram): sem isto, um
  // PowerShell travado (ex.: npm instalando e pedindo input) nunca morreria.
  const child = spawnTool(name, args, { env: Object.assign({}, process.env, { HOME }) });
  let acc = "";
  let done = false;
  const finish = (r) => { if (!done) { done = true; clearTimeout(timer); cb(r); } };
  const timer = timeout ? setTimeout(() => {
    try { child.kill(); } catch { /* ja morreu */ }
    finish({ err: new Error("timeout de " + timeout + "ms"), code: -1, out: acc });
  }, timeout) : null;
  child.stdout.on("data", (d) => { acc += d; });
  child.stderr.on("data", (d) => { acc += d; });
  child.on("error", (err) => finish({ err, code: -1, out: acc }));
  child.on("close", (code) => finish({ err: null, code, out: acc }));
  return child;
}

function coreEnvCreate(version, cb) {
  const tool = toolFull("core-env");
  if (!fs.existsSync(tool)) { cb({ ok: false, error: "ferramenta de ambiente não encontrada" }); return; }
  if (!/^[0-9A-Za-z._-]+$/.test(String(version || ""))) { cb({ ok: false, error: "versão inválida" }); return; }
  // GUARDA DE REENTRANCIA: uma criacao leva minutos (npm install + pt-BR). Um
  // SEGUNDO clique no badge nesse periodo criava uma instancia extra que, como
  // a porta da primeira ainda nao estava reservada nem registrada, escolhia a
  // MESMA porta: a nova morria com "listen EADDRINUSE", o log nao trazia a URL
  // com token e o painel acabava abrindo http://127.0.0.1:<porta> sem token —
  // que responde 401 ("dsh web authentication required") para sempre. Uma
  // criacao por vez resolve na raiz.
  for (const [emAndamento, s] of CREATE_PROGRESS) {
    if (s && s.running) {
      cb({ ok: false, error: "já existe uma criação em andamento (" + emAndamento + ") — aguarde terminar e clique em “Abrir instância nova”. Uma instância leva alguns minutos (npm install + pt-BR)." });
      return;
    }
  }
  const base = String(version).replace(/[^A-Za-z0-9]+/g, "").slice(0, 14) || "nova";
  let name = "nova-" + base;
  let i = 2;
  // Checa o DIRETORIO (nao o meta.json): um diretorio parcial de uma tentativa
  // que falhou tambem bloqueia o create ("instancia ja existe").
  while (fs.existsSync(path.join(HOME, ".dsh-envs", name))) name = "nova-" + base + "-" + (i++);
  const store = { running: true, done: false, ok: false, error: "", lines: [], output: "", url: "", envName: name };
  CREATE_PROGRESS.set(name, store);
  const child = spawnTool("core-env", ["create", name, "--core", version], { env: Object.assign({}, process.env, { HOME }) });
  let acc = "";
  const push = (chunk) => { acc += chunk; store.lines = acc.split(/\r?\n/); if (store.lines.length > 400) store.lines = store.lines.slice(-400); };
  child.stdout.on("data", push);
  child.stderr.on("data", push);
  child.on("error", (err) => { store.running = false; store.done = true; store.ok = false; store.error = err.message; store.output = acc; });
  child.on("close", (code) => {
    store.running = false; store.done = true; store.ok = code === 0;
    store.output = acc;
    const url = (acc.match(/http:\/\/127\.0\.0\.1:\d+[^\s]*/) || [])[0] || "";
    // So aceita como URL de abertura a que traz o token: sem token a GUI do
    // core 0.1.5+ responde 401, entao e melhor nao oferecer "abrir" do que
    // mandar o usuario para uma tela de erro.
    store.url = /[?&]token=/.test(url) ? url : "";
    // O script pode sair 0 sem ter concluido (ex.: criacao abortada no meio):
    // so existe sucesso quando o meta.json da instancia foi gravado.
    let temMeta = false;
    try { temMeta = fs.existsSync(path.join(HOME, ".dsh-envs", name, "meta.json")); } catch { /* ok */ }
    if (store.ok && !temMeta) {
      store.ok = false;
      store.error = "a criação não concluiu (meta.json da instância não foi gravado)";
    }
    if (!store.ok && !store.error) store.error = "falha ao criar a instância (exit " + code + ")";
  });
  cb({ ok: true, started: true, name });
}
function coreProgress(name, cb) {
  const store = CREATE_PROGRESS.get(name);
  if (!store) { cb({ ok: true, done: true, found: false }); return; }
  cb({
    ok: true,
    running: store.running,
    done: store.done,
    success: store.ok,
    error: store.error,
    url: store.url,
    envName: store.envName,
    output: store.output,
    lines: store.lines.slice(-40),
  });
}
// ══ SYNC MANUAL do overlay (badge ⬆): git pull + aplica overlay + stamp ══
// Roda tools/sync-pull.ps1 (Windows) ou tools/sync-pull.sh (Linux) em
// BACKGROUND, com progresso por polling — mesmo padrão do coreEnvCreate.
// Ao concluir, a GUI precisa reiniciar para recarregar os plugins
// (o painel oferece "Reiniciar agora"; sem pm2, orienta `dsh up` manual).
const SYNC_PROGRESS = new Map();
function syncNowStart(cb) {
  const tool = path.join(cloneDir(), "tools", IS_WIN ? "sync-pull.ps1" : "sync-pull.sh");
  if (!fs.existsSync(tool)) { cb({ ok: false, error: "ferramenta de sync não encontrada: " + tool }); return; }
  const id = "sync-" + Date.now().toString(36);
  const before = versionPayload();
  const store = { running: true, done: false, ok: false, error: "", lines: [], output: "", before, after: null };
  SYNC_PROGRESS.set(id, store);
  const env = Object.assign({}, process.env, { HOME, DSH_CLONE: cloneDir(), DSH_LIVE: LIVE });
  const child = IS_WIN
    ? spawn(psHost() || "powershell.exe", psFileArgs(tool), { env, windowsHide: true })
    : spawn(tool, [], { env });
  let acc = "";
  const push = (chunk) => { acc += chunk; store.lines = acc.split(/\r?\n/); if (store.lines.length > 400) store.lines = store.lines.slice(-400); };
  child.stdout.on("data", push);
  child.stderr.on("data", push);
  child.on("error", (err) => { store.running = false; store.done = true; store.ok = false; store.error = String((err && err.message) || err); store.output = acc; });
  child.on("close", (code) => {
    store.running = false; store.done = true; store.ok = code === 0;
    store.output = acc; store.after = versionPayload();
    if (!store.ok) store.error = "sync falhou (exit " + code + ") — veja a saída abaixo";
  });
  cb({ ok: true, started: true, id });
}
function syncProgress(id, cb) {
  const store = SYNC_PROGRESS.get(id);
  if (!store) { cb({ ok: true, done: true, found: false }); return; }
  cb({
    ok: true, running: store.running, done: store.done, success: store.ok,
    error: store.error, output: store.output, lines: store.lines.slice(-40),
    before: store.before, after: store.after,
  });
}
// ↩ = rollback MANUAL do core instalado (canônico) — só para emergências.
function coreRollback(version, cb) {
  if (!/^[0-9A-Za-z._-]+$/.test(String(version || ""))) { cb({ ok: false, error: "versão inválida" }); return; }
  if (IS_WIN) {
    // Windows: sem sudo — core-update.ps1 instala a versão pedida no prefixo
    // global do usuario e reaplica o pt-BR via pt-ride (funcao Reapply-Pt).
    const toolWin = path.join(cloneDir(), "core-i18n-pt", "tools", "core-update.ps1");
    if (!fs.existsSync(toolWin)) { cb({ ok: false, error: "core-update.ps1 não encontrado no repo" }); return; }
    const host = psHost();
    if (!host) { cb({ ok: false, error: "PowerShell não encontrado nesta máquina (nem pwsh, nem powershell.exe)" }); return; }
    // Parametros NOMEADOS: em `-File` um "--flag" que nao bate com nenhum
    // parametro e erro fatal de binding (o core-update.ps1 nao tem -Live).
    execFile(host, psFileArgs(toolWin, ["-Cmd", "--rollback", "-Ver", String(version)]),
      { timeout: 600000, maxBuffer: 16 * 1024 * 1024, windowsHide: true }, (err, stdout, stderr) => {
        const output = String(stdout || "") + (stderr ? "\n" + stderr : "");
        if (err) { cb({ ok: false, error: "falha ao reverter (npm install -g?)", output }); return; }
        cb({ ok: true, output });
      });
    return;
  }
  const tool = path.join(cloneDir(), "core-i18n-pt", "tools", "core-update.sh");
  if (!fs.existsSync(tool)) { cb({ ok: false, error: "core-update.sh não encontrado no repo" }); return; }
  const args = ["-n", tool, "--live", LIVE, "--rollback", version];
  execFile("sudo", args, { timeout: 300000, maxBuffer: 16 * 1024 * 1024 }, (err, stdout, stderr) => {
    const output = String(stdout || "") + (stderr ? "\n" + stderr : "");
    if (err) { cb({ ok: false, error: "falha (sudo?)", needSudo: true, output }); return; }
    cb({ ok: true, output });
  });
}
function coreAction(action, version, cb) {
  if (action === "update") { coreEnvCreate(version, cb); return; }
  if (action === "rollback") { coreRollback(version, cb); return; }
  cb({ ok: false, error: "ação desconhecida" });
}

const CORE_UI_JS = [
  "(function () {",
  "  if (document.getElementById('dsh-core-badge')) return;",
  "  var s2 = document.createElement('style');",
  "  s2.textContent = [",
  "    '#dsh-core-badge{position:fixed;right:16px;bottom:34px;z-index:2147483646;display:inline-flex;align-items:center;gap:6px;background:#0d1117;border:1px solid #30363d;border-radius:999px;padding:2px 10px;font:10px/1.6 system-ui,sans-serif;color:#8b949e;cursor:pointer;box-shadow:0 2px 10px rgba(0,0,0,.4);}',",
  "    '#dsh-core-badge .cb-new{color:#f0883e;font-weight:600;}',",
  "    '#dsh-core-badge .cb-old{color:#3fb950;}',",
  "    '#dsh-core-panel{position:fixed;right:16px;bottom:74px;z-index:2147483647;width:340px;max-width:calc(100vw - 24px);background:#0d1117;border:1px solid #30363d;border-radius:10px;padding:10px 12px;font:11px/1.5 system-ui,sans-serif;color:#e6edf3;box-shadow:0 8px 30px rgba(0,0,0,.6);}',",
  "    '#dsh-core-panel h4{margin:0 0 6px;font-size:11px;color:#f0883e;}',",
  "    '#dsh-core-panel .cb-row{display:flex;justify-content:space-between;gap:8px;padding:3px 0;border-top:1px solid #21262d;}',",
  "    '#dsh-core-panel .cb-row:first-of-type{border-top:0;}',",
  "    '#dsh-core-panel button{margin:4px 6px 4px 0;padding:3px 10px;border:0;border-radius:999px;background:#21262d;color:#e6edf3;font:10.5px/1.4 system-ui,sans-serif;cursor:pointer;}',",
  "    '#dsh-core-panel button:hover{background:#30363d;}',",
  "    '#dsh-core-panel .cb-warn{color:#f85149;}',",
  "    '#dsh-core-panel .cb-note{color:#8b949e;font-size:10px;white-space:pre-wrap;max-height:150px;overflow:auto;}'",
  "  ].join('\\n');",
  "  document.head.appendChild(s2);",
  "  var chip = document.createElement('div');",
  "  chip.id = 'dsh-core-badge';",
  "  chip.title = 'Núcleo do DeepSeek Harness — clique para ver/atualizar';",
  "  document.body.appendChild(chip);",
  "  var panel = document.createElement('div');",
  "  panel.id = 'dsh-core-panel';",
  "  panel.style.display = 'none';",
  "  document.body.appendChild(panel);",
  "  var esc = function (v) { return String(v == null ? '' : v).replace(/[&<>\"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '\"': '&quot;', \"'\": '&#39;' }[c]; }); };",
  "  var refresh = function () {",
  "    fetch('/api/dsh-core', { method: 'GET' }).then(function (r) { return r.json(); }).then(function (d) {",
  "      if (!d || !d.ok) return;",
  "      var label = 'core c' + esc(d.installed);",
  "      var cls = '';",
  "      if (d.hasUpdate) { label += ' · nova ' + esc(d.latest); cls = 'cb-new'; }",
  "      else if (!d.patches.ok) { label += ' · sem pt'; cls = 'cb-warn'; }",
  "      chip.innerHTML = '<span class=\"' + (cls || 'cb-old') + '\">' + label + '</span>';",
  "      panel.dataset.status = JSON.stringify(d);",
  "    }).catch(function () {});",
  "  };",
  "  var creating = false;",
  "  var act = function (action, version, label) {",
  "    if (action === 'import') { actImport(); return; }",
  "    if (action === 'update' && creating) {",
  "      panel.style.display = 'block';",
  "      panel.innerHTML = '<h4>Nucleo</h4><div class=\"cb-note\">Ja existe uma criacao em andamento — aguarde terminar. O botao \"Abrir instancia nova\" aparece no fim.</div>';",
  "      return;",
  "    }",
  "    var cmsg = (action === 'update' ? 'Criar instancia isolada com o core ' + label + '? O sistema atual nao e tocado: sera criada uma 2a versao funcional (pt-BR e FreeLLMAPI).' : 'Reverter o core instalado para ' + label + '? Estado atual e salvo; depois clique em Reiniciar agora para aplicar.');",
  "    if (!window.confirm(cmsg)) return;",
  "    if (action === 'update') creating = true;",
  "    panel.innerHTML = '<h4>Nucleo</h4><div class=\"cb-note\">' + (action === 'update' ? 'Iniciando a criacao da instancia...' : 'Revertendo o core...') + '</div>';",
  "    fetch('/api/dsh-core', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action: action, version: version }) })",
  "      .then(function (r) { return r.json(); }).then(function (res) {",
  "        if (!res.ok) {",
  "          if (action === 'update') creating = false;",
  "          panel.innerHTML = '<h4>Nucleo</h4><div class=\"cb-warn\">' + esc(res.error || 'falhou') + '</div><div class=\"cb-note\">' + esc(res.output || (res.needSudo ? 'Rode no terminal: sudo core-i18n-pt/tools/core-update.sh' : '')) + '</div>';",
  "          return;",
  "        }",
  "        if (action === 'update') {",
  "          if (res.started && res.name) { pollCreate(res.name, 0); }",
  "          else if (res.envName) { showCreated(res.envName, res.url, res.output); }",
  "          return;",
  "        }",
  "        panel.innerHTML = '<h4>Nucleo</h4><div class=\"cb-note\">' + esc(res.output || 'ok') + '</div><div class=\"cb-note\">A GUI nao foi reiniciada. Quando quiser aplicar, clique abaixo.</div><div><button id=\"cb-restart\">Reiniciar agora (aplicar)</button></div>';",
  "        var rb = document.getElementById('cb-restart');",
  "        if (rb) rb.addEventListener('click', function () {",
  "          fetch('/api/dsh-core', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action: 'restart' }) })",
  "            .then(function () { panel.innerHTML = '<h4>Nucleo</h4><div class=\"cb-note\">Reiniciando a GUI... recarregue (F5).</div>'; });",
  "        });",
  "        refresh();",
  "      }).catch(function () {",
  "        panel.innerHTML = '<h4>Nucleo</h4><div class=\"cb-note\">Operacao concluida? Recarregue a pagina (F5) e confira o chip do core.</div>';",
  "      });",
  "  };",
  "  var showCreated = function (nm, url, outp) {",
  "    creating = false;",
  "    var temToken = /[?&]token=/.test(url || '');",
  "    panel.innerHTML = '<h4>Nucleo</h4><div class=\"cb-note\">✔ Instancia <b>' + esc(nm) + '</b> criada — o sistema atual nao foi tocado.</div>' + (temToken ? '<div><button id=\"cb-open\">Abrir instancia nova</button></div>' : '<div class=\"cb-warn\">A instancia nao devolveu a URL com token: abra pelo atalho do menu. O endereco puro (sem ?token=) responde 401.</div>') + '<div class=\"cb-note\">' + esc((outp || '').slice(-500)) + '</div>';",
  "    var ob = document.getElementById('cb-open');",
  "    if (ob) ob.addEventListener('click', function () { window.open(url, '_blank'); });",
  "    refresh();",
  "  };",
  "  var pollCreate = function (nm, tick) {",
  "    if (tick > 700) { creating = false; panel.innerHTML = '<h4>Nucleo</h4><div class=\"cb-warn\">Tempo esgotado ao consultar o progresso — recarregue (F5) e confira o chip.</div>'; return; }",
  "    fetch('/api/dsh-core?progress=1&name=' + encodeURIComponent(nm))",
  "      .then(function (r) { return r.json(); }).then(function (p) {",
  "        var linesA = (p && p.lines) || [];",
  "        var tail = linesA.slice(-16).join('\\n');",
  "        var spin = ['|', '/', '-', '\\\\'][tick % 4];",
  "        panel.innerHTML = '<h4>Nucleo</h4><div class=\"cb-note\">' + spin + ' Instalando o core e criando a instancia <b>' + esc(nm) + '</b>... aguarde, pode levar alguns minutos.</div><div style=\"max-height:220px;overflow:auto;white-space:pre-wrap;font-size:10px;color:#8b949e;\">' + esc(tail) + '</div>';",
  "        if (p && p.done) {",
  "          creating = false;",
  "          if (p.ok && p.envName) { showCreated(p.envName, p.url, p.output); return; }",
  "          panel.innerHTML = '<h4>Nucleo</h4><div class=\"cb-warn\">Falha ao criar a instancia</div><div class=\"cb-note\">' + esc(p.error || '') + '</div><div class=\"cb-note\">' + esc((p.output || '').slice(-900)) + '</div>';",
  "          return;",
  "        }",
  "        setTimeout(function () { pollCreate(nm, tick + 1); }, 1600);",
  "      }).catch(function () { setTimeout(function () { pollCreate(nm, tick + 1); }, 1600); });",
  "  };",
  "  var actImport = function () {",
  "    if (!window.confirm('Importar historico/conversas + configs (credenciais FreeLLMAPI etc.) da instancia anterior para esta? (mescla com o que ja existe; nada e apagado — depois recarregue com F5).')) return;",
  "    panel.innerHTML = '<h4>Núcleo</h4><div class=\"cb-note\">Importando historico/configs da instancia anterior\u2026</div>';",
  "    fetch('/api/dsh-core', {",
  "      method: 'POST',",
  "      headers: { 'content-type': 'application/json' },",
  "      body: JSON.stringify({ action: 'import' })",
  "    }).then(function (r) { return r.json(); }).then(function (res) {",
  "      if (!res.ok) {",
  "        panel.innerHTML = '<h4>Núcleo</h4><div class=\"cb-warn\">' + esc(res.error || 'falhou') + '</div><div class=\"cb-note\">' + esc(res.output || '') + '</div>';",
  "        return;",
  "      }",
  "      panel.innerHTML = '<h4>Núcleo</h4><div class=\"cb-note\">' + esc(res.output || '') + '</div><div class=\"cb-note\">\u2714 Importado. Recarregue a pagina (F5) para ver o historico e as configs.</div>';",
  "      refresh();",
  "    }).catch(function () {",
  "      panel.innerHTML = '<h4>Núcleo</h4><div class=\"cb-note\">Importando\u2026 recarregue a pagina (F5) e confira.</div>';",
  "    });",
  "  };",
  "  var open = function () {",
  "    if (panel.style.display !== 'none') { panel.style.display = 'none'; return; }",
  "    panel.style.display = 'block';",
  "    panel.innerHTML = '<h4>Núcleo (kernel)</h4><div class=\"cb-note\">Carregando…</div>';",
  "    fetch('/api/dsh-core', { method: 'GET' }).then(function (r) { return r.json(); }).then(function (d) {",
  "      var h = ['<h4>Núcleo do DeepSeek Harness</h4>'];",
  "      h.push('<div class=\"cb-note\">Atualização sempre MANUAL (nada automático) — semelhante a um kernel. A checagem de versão nova é automática.</div>');",
  "      h.push('<div class=\"cb-note\">🔒 Seus dados nunca são tocados: sessões, histórico, chaves e config vivem na sua pasta .dsh — só os arquivos do núcleo (npm) mudam, e dá para voltar (botão ↩ abaixo) se algo falhar.</div>');",
  "      h.push('<div class=\"cb-row\"><span>Instalado</span><b>' + esc(d.installed) + '</b></div>');",
  "      h.push('<div class=\"cb-row\"><span>Pinado no repo</span><b>' + esc(d.pinned || '—') + '</b></div>');",
  "      h.push('<div class=\"cb-row\"><span>Disponível</span><b>' + esc(d.latest) + (d.hasUpdate ? ' ⚠' : '') + '</b></div>');",
  "      h.push('<div class=\"cb-row\"><span>pt-BR (patch)</span><b>' + (d.patches && d.patches.ok ? 'aplicado' : '<span class=\"cb-warn\">pendente</span>') + '</b></div>');",
  "      if (d.hasUpdate) {",
  "        h.push('<div><button data-a=\"update\" data-v=\"' + esc(d.latest) + '\" data-l=\"' + esc(d.latest) + '\">➕ Criar instância com core ' + esc(d.latest) + '</button></div>');",
  "      }",
  "      var rb = (d.pinned && d.pinned !== d.installed) ? d.pinned : ((d.history && d.history[0] && d.history[0].from) || '');",
  "      if (rb && rb !== d.installed) {",
  "        h.push('<div><button data-a=\"rollback\" data-v=\"' + esc(rb) + '\" data-l=\"' + esc(rb) + '\">↩ Voltar p/ ' + esc(rb) + '</button><span class=\"cb-note\"> (última que funcionava)</span></div>');",
  "      }",
  "      if (d.history && d.history.length) {",
  "        h.push('<div class=\"cb-note\">Histórico: ' + d.history.map(function (x) { return x.version + (x.patchesOk ? '' : ' (sem pt)'); }).join(' → ') + '</div>');",
  "      }",
  "      if (d.envName) {",
  "        h.push('<div class=\"cb-row\"><span>Instância</span><b>' + esc(d.envName) + '</b></div>');",
  "        h.push('<div><button data-a=\"import\" data-l=\"da instância anterior\">⇄ Importar histórico/configs da anterior</button></div>');",
  "      }",
  "      panel.innerHTML = h.join('');",
  "      Array.prototype.forEach.call(panel.querySelectorAll('button[data-a]'), function (b) {",
  "        b.addEventListener('click', function () { act(b.getAttribute('data-a'), b.getAttribute('data-v'), b.getAttribute('data-l')); });",
  "      });",
  "    }).catch(function () { panel.innerHTML = '<h4>Núcleo</h4><div class=\"cb-warn\">Falha ao consultar o core.</div>'; });",
  "  };",
  "  chip.addEventListener('click', open);",
  "  refresh();",
  "  setInterval(refresh, 120000);",
  "  function ensureX(p) {",
  "    if (!p || p.querySelector('[data-x]')) return;",
  "    var x = document.createElement('button');",
  "    x.type='button'; x.setAttribute('data-x','1'); x.textContent='✕';",
  "    x.setAttribute('aria-label','Fechar');",
  "    x.style.cssText='position:absolute;top:4px;right:6px;background:transparent;border:0;color:#8b949e;font-size:13px;cursor:pointer;padding:2px 5px;';",
  "    x.onclick=function(){ p.style.display='none'; };",
  "    p.appendChild(x);",
  "  }",
  "  setInterval(function(){ var pp=document.getElementById('dsh-core-panel'); if (pp && pp.style.display !== 'none') ensureX(pp); }, 350);",
  "})();",
].join("\n");

const BADGE_JS = [
  "(function () {",
  "  if (document.getElementById('dsh-version-badge')) return;",
  "  var css = document.createElement('style');",
  "  css.textContent = [",
  "    '#dsh-version-badge{position:fixed;right:16px;bottom:8px;z-index:2147483646;display:inline-flex;align-items:center;gap:8px;background:#0d1117;border:1px solid #30363d;border-radius:999px;padding:2px 6px 2px 10px;font:10.5px/1.6 system-ui,sans-serif;white-space:nowrap;box-shadow:0 2px 10px rgba(0,0,0,.4);}',",
  "    '#dsh-version-badge .v-ver{color:#79c0ff;font-weight:600;cursor:pointer;}',",
  "    '#dsh-version-badge .v-upd{color:#8b949e;}',",
  "    '#dsh-version-badge button{margin:0;padding:2px 8px;border:0;border-radius:999px;background:#21262d;color:#8b949e;font:10px/1.4 system-ui,sans-serif;cursor:pointer;}',",
  "    '#dsh-version-badge button:hover{background:#30363d;color:#e6edf3;}',",
  "    '#dsh-version-badge .v-toggle.on{color:#3fb950;}',",
  "    '#dsh-version-badge .v-toggle.off{color:#f85149;}',",
  "    '#dsh-version-badge .v-rollback{color:#d29922;}',",
  "    '#dsh-version-badge .v-sync{color:#79c0ff;}',",
  "    '#dsh-rollback-panel{position:fixed;right:16px;bottom:44px;z-index:2147483647;width:320px;max-width:calc(100vw - 24px);max-height:60vh;overflow:auto;background:#0d1117;border:1px solid #30363d;border-radius:10px;padding:10px 12px;font:11px/1.5 system-ui,sans-serif;color:#e6edf3;box-shadow:0 8px 30px rgba(0,0,0,.6);}',",
  "    '#dsh-rollback-panel h4{margin:0 0 6px;font-size:11px;color:#79c0ff;}',",
  "    '#dsh-rollback-panel .rb-row{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:4px 2px;border-top:1px solid #21262d;}',",
  "    '#dsh-rollback-panel .rb-row:first-of-type{border-top:0;}',",
  "    '#dsh-rollback-panel .rb-name{font-weight:600;color:#e6edf3;}',",
  "    '#dsh-rollback-panel .rb-date{color:#8b949e;font-size:10px;}',",
  "    '#dsh-rollback-panel .rb-cur{color:#3fb950;font-size:10px;}',",
  "    '#dsh-rollback-panel .rb-btn{flex:0 0 auto;}',",
  "    '#dsh-rollback-panel .rb-note{color:#8b949e;margin-top:8px;padding-top:6px;border-top:1px solid #21262d;font-size:10px;}',",
  "    '#dsh-rollback-panel .rb-err{color:#f85149;white-space:pre-wrap;}',",
  "    '#dsh-rollback-panel .rb-ok{color:#3fb950;white-space:pre-wrap;max-height:120px;overflow:auto;}'",
  "  ].join('\\n');",
  "  document.head.appendChild(css);",
  "",
  "  var b = document.createElement('div');",
  "  b.id = 'dsh-version-badge';",
  "  document.body.appendChild(b);",
  "  var panel = document.createElement('div');",
  "  panel.id = 'dsh-rollback-panel';",
  "  panel.style.display = 'none';",
  "  document.body.appendChild(panel);",
  "",
  "  var state = { autoUpdate: true };",
  "  var esc = function (s) {",
  "    return String(s == null ? '' : s).replace(/[&<>\"']/g, function (c) {",
  "      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '\"': '&quot;', \"'\": '&#39;' }[c];",
  "    });",
  "  };",
  "  var verLabel = function (v) {",
  "    v = String(v == null ? '?' : v);",
  "    return (v.charAt(0) === 'v' || v.charAt(0) === 'V') ? v : 'v' + v;",
  "  };",
  "  var ask = function (msg) { try { return window.confirm(msg); } catch (e) { return true; } };",
  "",
  "  var doRollback = function (target, label) {",
  "    if (!ask('Voltar para ' + label + '?\\n\\n• O estado atual será salvo num snapshot antes\\n• O auto-update será DESLIGADO (para não reaplicar a versão que quebrou)\\n• O harness será reiniciado\\n\\nContinuar?')) return;",
  "    panel.innerHTML = '<h4>↩ Rollback</h4><div class=\"rb-note\">Voltando para <b>' + esc(label) + '</b>… snapshot + restauração podem levar alguns segundos.</div>';",
  "    fetch('/api/dsh-rollback', {",
  "      method: 'POST',",
  "      headers: { 'content-type': 'application/json' },",
  "      body: JSON.stringify({ target: target })",
  "    }).then(function (r) { return r.json(); }).then(function (res) {",
  "      if (!res.ok) {",
  "        panel.innerHTML = '<h4>↩ Rollback</h4><div class=\"rb-err\">' + esc(res.error || 'falhou') + '</div><div class=\"rb-note\">Veja o terminal/log para detalhes.</div>';",
  "        return;",
  "      }",
  "      panel.innerHTML = '<h4>↩ Rollback</h4><div class=\"rb-ok\">' + esc(res.output || '') + '</div><div class=\"rb-note\"><b>Auto-update DESLIGADO.</b> Reiniciando o harness… a página vai recarregar; se não recarregar sozinha, atualize (F5).</div>';",
  "    }).catch(function () {",
  "      // servidor reiniciou no meio — sinal de sucesso",
  "      panel.innerHTML = '<h4>↩ Rollback</h4><div class=\"rb-note\">Reiniciando o harness… recarregue a página (F5) para ver a versão anterior.</div>';",
  "    });",
  "  };",
  "",
  "  var openRollback = function () {",
  "    if (panel.style.display !== 'none') { panel.style.display = 'none'; return; }",
  "    panel.style.display = 'block';",
  "    panel.innerHTML = '<h4>↩ Rollback de versão</h4><div class=\"rb-note\">Carregando…</div>';",
  "    fetch('/api/dsh-rollback', { method: 'GET' }).then(function (r) { return r.json(); }).then(function (d) {",
  "      var html = ['<h4>↩ Rollback de versão</h4>'];",
  "      html.push('<div class=\"rb-row\"><span class=\"rb-name\">Atual: ' + esc(d.current.version) + '</span><span class=\"rb-cur\">instalado</span></div>');",
  "      if (d.previous) {",
  "        html.push('<div class=\"rb-row\"><span><span class=\"rb-name\">' + esc(d.previous) + '</span> <span class=\"rb-date\">(anterior)</span></span><span class=\"rb-btn\"><button class=\"rb-voltar\" data-t=\"' + esc(d.previous) + '\" data-l=\"' + esc(d.previous) + '\">↩ Voltar</button></span></div>');",
  "      } else {",
  "        html.push('<div class=\"rb-note\">Sem versão anterior publicada (a atual é a mais antiga ou não tem tag). Use um snapshot abaixo, ou no terminal: tools/rollback.sh list</div>');",
  "      }",
  "      var tagRows = (d.tags || []).filter(function (t) { return t.name !== d.previous && t.name !== d.current.version; }).map(function (t) {",
  "        return '<div class=\"rb-row\"><span><span class=\"rb-name\">' + esc(t.name) + '</span> <span class=\"rb-date\">' + esc(t.date || '') + '</span></span><span class=\"rb-btn\"><button data-t=\"' + esc(t.name) + '\" data-l=\"' + esc(t.name) + '\">↩ Voltar</button></span></div>';",
  "      });",
  "      if (tagRows.length) {",
  "        html.push('<div class=\"rb-note\" style=\"margin-top:6px;\">Versões publicadas (tags):</div>');",
  "        html.push.apply(html, tagRows);",
  "      }",
  "      if (d.snapshots && d.snapshots.length) {",
  "        html.push('<div class=\"rb-note\" style=\"margin-top:6px;\">Snapshots locais (estado exato desta máquina):</div>');",
  "        d.snapshots.forEach(function (s) {",
  "          html.push('<div class=\"rb-row\"><span class=\"rb-name\" style=\"font-weight:400;\">' + esc(s) + '</span><span class=\"rb-btn\"><button data-t=\"' + esc(s) + '\" data-l=\"' + esc(s) + '\">↩ Voltar</button></span></div>');",
  "        });",
  "      }",
  "      html.push('<div class=\"rb-note\">Ao voltar: o auto-update é desligado e o harness reinicia. Para religar depois de testar, clique em 🔄 auto: OFF.</div>');",
  "      panel.innerHTML = html.join('');",
  "      Array.prototype.forEach.call(panel.querySelectorAll('button[data-t]'), function (btn) {",
  "        btn.addEventListener('click', function () { doRollback(btn.getAttribute('data-t'), btn.getAttribute('data-l')); });",
  "      });",
  "    }).catch(function () {",
  "      panel.innerHTML = '<h4>↩ Rollback</h4><div class=\"rb-err\">Não foi possível listar versões.</div>';",
  "    });",
  "  };",
  "",
  "  var openSync = function () {",
  "    if (panel.style.display !== 'none') { panel.style.display = 'none'; return; }",
  "    panel.style.display = 'block';",
  "    panel.innerHTML = '<h4>⬆ Atualizar agora</h4><div class=\"rb-note\">Sincroniza com o GitHub agora (git pull + overlay + versão), sem esperar o agendado. Depois será preciso reiniciar a GUI.</div><div><button id=\"sy-go\">Atualizar agora</button></div>';",
  "    var go = document.getElementById('sy-go');",
  "    if (go) go.addEventListener('click', function () {",
  "      if (!ask('Rodar o sync agora?\\n\\n• Puxa as novidades do GitHub\\n• Aplica o overlay e carimba a versão\\n• Depois será preciso reiniciar a GUI\\n\\nContinuar?')) return;",
  "      panel.innerHTML = '<h4>⬆ Atualizando…</h4><div class=\"rb-note\">Iniciando…</div>';",
  "      fetch('/api/dsh-sync', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action: 'start' }) })",
  "        .then(function (r) { return r.json(); }).then(function (res) {",
  "          if (!res.ok || !res.id) { panel.innerHTML = '<h4>⬆ Atualizar</h4><div class=\"rb-err\">' + esc(res.error || 'falhou ao iniciar') + '</div>'; return; }",
  "          pollSync(res.id, 0);",
  "        }).catch(function () { panel.innerHTML = '<h4>⬆ Atualizar</h4><div class=\"rb-err\">Falha de rede ao iniciar o sync.</div>'; });",
  "    });",
  "  };",
  "  var pollSync = function (id, tick) {",
  "    if (tick > 900) { panel.innerHTML = '<h4>⬆ Atualizar</h4><div class=\"rb-err\">Tempo esgotado — recarregue (F5) e confira a versão no badge.</div>'; return; }",
  "    fetch('/api/dsh-sync?progress=1&id=' + encodeURIComponent(id))",
  "      .then(function (r) { return r.json(); }).then(function (p) {",
  "        var tail = ((p && p.lines) || []).slice(-14).join('\\n');",
  "        var spin = ['|', '/', '-', '\\\\'][tick % 4];",
  "        panel.innerHTML = '<h4>⬆ Atualizando…</h4><div class=\"rb-note\">' + spin + ' Sincronizando com o GitHub… (pode levar 1-2 min)</div><div style=\"max-height:200px;overflow:auto;white-space:pre-wrap;font-size:10px;color:#8b949e;\">' + esc(tail) + '</div>';",
  "        if (p && p.done) {",
  "          if (p.success) {",
  "            var bv = (p.before && p.before.version) || '?';",
  "            var av = (p.after && p.after.version) || '?';",
  "            panel.innerHTML = '<h4>⬆ Atualizado</h4><div class=\"rb-ok\">✔ Sync concluído: ' + esc(bv) + ' → ' + esc(av) + '</div><div class=\"rb-note\">Reinicie a GUI para recarregar os plugins com a nova versão.</div><div><button id=\"sy-restart\">Reiniciar agora</button></div><div class=\"rb-note\">Sem pm2 (Windows): se a página não voltar em ~15s, feche a janela e rode <b>dsh up</b>.</div>';",
  "            var rb2 = document.getElementById('sy-restart');",
  "            if (rb2) rb2.addEventListener('click', function () {",
  "              fetch('/api/dsh-core', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action: 'restart' }) })",
  "                .then(function () { panel.innerHTML = '<h4>⬆ Atualizado</h4><div class=\"rb-note\">Reiniciando… recarregue (F5). No Windows sem pm2: feche e rode <b>dsh up</b>.</div>'; });",
  "            });",
  "            return;",
  "          }",
  "          panel.innerHTML = '<h4>⬆ Atualizar</h4><div class=\"rb-err\">Falhou: ' + esc(p.error || '') + '</div><div class=\"rb-note\">' + esc((p.output || '').slice(-900)) + '</div>';",
  "          return;",
  "        }",
  "        setTimeout(function () { pollSync(id, tick + 1); }, 1600);",
  "      }).catch(function () { setTimeout(function () { pollSync(id, tick + 1); }, 1600); });",
  "  };",
  "  var refresh = function () {",
  "    fetch('/api/dsh-version', { method: 'GET' }).then(function (r) { return r.json(); }).then(function (d) {",
  "      state = d || state;",
  "      var upd = '';",
  "      try { if (d.updatedAt) upd = new Date(d.updatedAt).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); } catch (e) {}",
  "      b.title = 'overlay ' + verLabel(d.version) + (d.commit ? ' (' + d.commit + ')' : '') + ' · atualizado ' + (d.updatedAt || '?') + '\\nClique na versão para abrir o rollback.';",
  "      var btn = document.createElement('button');",
  "      btn.className = 'v-toggle ' + (d.autoUpdate ? 'on' : 'off');",
  "      btn.type = 'button';",
  "      btn.title = 'Atualização automática (sync + reinício quando houver versão nova). Clique para ' + (d.autoUpdate ? 'DESLIGAR' : 'LIGAR');",
  "      btn.textContent = '🔄 ' + (d.autoUpdate ? 'auto: ON' : 'auto: OFF');",
  "      btn.onclick = function (ev) {",
  "        ev.stopPropagation();",
  "        fetch('/api/dsh-version', {",
  "          method: 'POST',",
  "          headers: { 'content-type': 'application/json' },",
  "          body: JSON.stringify({ autoUpdate: !d.autoUpdate })",
  "        }).then(function (r) { return r.json(); }).then(function (res) {",
  "          state.autoUpdate = res.autoUpdate;",
  "          refresh();",
  "        }).catch(function () {});",
  "      };",
  "      var rb = document.createElement('button');",
  "      rb.className = 'v-rollback';",
  "      rb.type = 'button';",
  "      rb.title = 'Rollback de versão — voltar se uma atualização quebrou o sistema';",
  "      rb.textContent = '↩';",
  "      rb.onclick = function (ev) { ev.stopPropagation(); openRollback(); };",
  "      b.innerHTML = '';",
  "      var span = document.createElement('span');",
  "      span.className = 'v-ver';",
  "      span.title = b.title;",
  "      span.textContent = verLabel(d.version);",
  "      span.onclick = function () { openRollback(); };",
  "      b.appendChild(span);",
  "      if (upd) { var u = document.createElement('span'); u.className = 'v-upd'; u.textContent = '· ' + upd; b.appendChild(u); }",
  "      var sy = document.createElement('button');",
  "      sy.className = 'v-sync';",
  "      sy.type = 'button';",
  "      sy.title = 'Atualizar agora: sync com o GitHub sem esperar o agendado';",
  "      sy.textContent = '⬆';",
  "      sy.onclick = function (ev) { ev.stopPropagation(); openSync(); };",
  "      b.appendChild(sy);",
  "      b.appendChild(btn);",
  "      b.appendChild(rb);",
  "    }).catch(function () {",
  "      b.innerHTML = '<span class=\"v-ver\">v?</span>';",
  "    });",
  "  };",
  "  refresh();",
  "  setInterval(refresh, 60000);",
  "  function ensureX(p) {",
  "    if (!p || p.querySelector('[data-x]')) return;",
  "    var x = document.createElement('button');",
  "    x.type='button'; x.setAttribute('data-x','1'); x.textContent='✕';",
  "    x.setAttribute('aria-label','Fechar');",
  "    x.style.cssText='position:absolute;top:4px;right:6px;background:transparent;border:0;color:#8b949e;font-size:13px;cursor:pointer;padding:2px 5px;';",
  "    x.onclick=function(){ p.style.display='none'; };",
  "    p.appendChild(x);",
  "  }",
  "  setInterval(function(){ var pp=document.getElementById('dsh-rollback-panel'); if (pp && pp.style.display !== 'none') ensureX(pp); }, 350);",
  "})();",
].join("\n");

module.exports = function versionBadgePlugin(ctx) {
  // O host webserver pode ativar DEPOIS do apply deste plugin — espera ficar
  // disponível antes de registrar (mesmo padrão do LayoutPanel).
  let tries = 0;
  const waitForWebServer = () => {
    const webServer = ctx.get("webServer");
    if (webServer) {
      ctx.effect(() => {
        const json = (code, obj, res) => {
          res.writeHead(code, { "content-type": "application/json; charset=utf-8" });
          res.end(JSON.stringify(obj));
        };
        const readBody = (req, done) => {
          let body = "";
          req.on("data", (c) => { body += c; });
          req.on("end", () => done(body));
        };
        const registerVersion = webServer.register({
          kind: "exact",
          path: "/api/dsh-version",
          handler: (req, res) => {
            if (req.method === "GET") { json(200, versionPayload(), res); return; }
            if (req.method === "POST") {
              readBody(req, (body) => {
                let enable = null;
                try { enable = JSON.parse(body || "{}").autoUpdate; } catch { /* inválido */ }
                if (typeof enable !== "boolean") { json(400, { ok: false, error: "autoUpdate deve ser boolean" }, res); return; }
                json(200, setAutoUpdate(enable), res);
              });
              return;
            }
            json(405, { ok: false, error: "método não suportado" }, res);
          },
        });
        const registerRollback = webServer.register({
          kind: "exact",
          path: "/api/dsh-rollback",
          handler: (req, res) => {
            if (req.method === "GET") {
              rollbackList((payload) => json(200, payload, res));
              return;
            }
            if (req.method === "POST") {
              readBody(req, (body) => {
                let target = "";
                try { target = String(JSON.parse(body || "{}").target || "").trim(); } catch { /* inválido */ }
                if (!/^[A-Za-z0-9._-]+$/.test(target)) {
                  json(400, { ok: false, error: "target inválido (ex.: v0.2.0 ou snap-20260906-...) — use o painel ou tools/rollback.sh" }, res);
                  return;
                }
                doRollback(target, (result) => {
                  json(result.ok ? 200 : 500, result, res);
                  if (result.ok) scheduleRestart(1800);
                });
              });
              return;
            }
            json(405, { ok: false, error: "método não suportado" }, res);
          },
        });
        const registerCore = webServer.register({
          kind: "exact",
          path: "/api/dsh-core",
          handler: (req, res) => {
            if (req.method === "GET") {
              const mprog = /[?&]progress=1&name=([A-Za-z0-9._-]+)/.exec(req.url || "");
              if (mprog) { coreProgress(mprog[1], (payload) => json(200, payload, res)); return; }
              const force = /[?&]force=1/.test(req.url || "");
              coreStatus(!!force, (payload) => json(200, payload, res));
              return;
            }
            if (req.method === "POST") {
              readBody(req, (body) => {
                let action = "", version = "";
                try { const p = JSON.parse(body || "{}"); action = String(p.action || ""); version = String(p.version || ""); } catch { /* inválido */ }
                if (action === "restart") {
                  json(200, { ok: true, restarting: true });
                  scheduleRestart(1600); // ação explícita do usuário
                  return;
                }
                if (action === "import") {
                  const envName = process.env.DSH_ENV_NAME;
                  if (!envName) { json(400, { ok: false, error: "use dentro de uma instância nova" }, res); return; }
                  const tool = toolFull("core-env");
                  if (!fs.existsSync(tool)) { json(500, { ok: false, error: "ferramenta não encontrada" }, res); return; }
                  execToolAsync("core-env", ["import", envName], 300000, (r) => {
                    const output = String(r.out || "");
                    if (r.err || r.code !== 0) { json(500, { ok: false, error: "import falhou (veja saída)", output }, res); return; }
                    json(200, { ok: true, imported: true, output }, res);
                  });
                  return;
                }
                if (action === "uninstall") {
                  const envName = process.env.DSH_ENV_NAME;
                  if (!envName) { json(400, { ok: false, error: "use dentro de uma instância" }, res); return; }
                  const tool = toolFull("core-env");
                  if (!fs.existsSync(tool)) { json(500, { ok: false, error: "ferramenta não encontrada" }, res); return; }
                  json(200, { ok: true, uninstalling: true, envName }, res);
                  setTimeout(() => {
                    const c = spawnTool("core-env", ["remove", envName], { env: Object.assign({}, process.env, { HOME }), detached: true, stdio: "ignore" });
                    // sem listener de 'error' um ENOENT aqui derrubaria o processo da GUI
                    c.on("error", (err) => console.error("[VersionBadge] core-env remove falhou: " + (err && err.message ? err.message : err)));
                    c.unref();
                  }, 1500);
                  return;
                }
                if (action !== "update" && action !== "rollback") {
                  json(400, { ok: false, error: "action deve ser update|rollback|restart|import|uninstall" }, res);
                  return;
                }
                if (!version) {
                  if (action === "update") {
                    coreStatus(false, (st) => { if (st.latest && st.latest !== "?") { runCoreAction(action, st.latest, json, res); } else json(400, { ok: false, error: "sem versão nova conhecida" }, res); });
                    return;
                  }
                  json(400, { ok: false, error: "informe a versão p/ rollback" }, res);
                  return;
                }
                runCoreAction(action, version, json, res);
              });
              return;
            }
            json(405, { ok: false, error: "método não suportado" }, res);
          },
        });
        const registerSync = webServer.register({
          kind: "exact",
          path: "/api/dsh-sync",
          handler: (req, res) => {
            if (req.method === "GET") {
              const m = /[?&]progress=1&id=([A-Za-z0-9._-]+)/.exec(req.url || "");
              if (!m) { json(400, { ok: false, error: "use ?progress=1&id=..." }, res); return; }
              syncProgress(m[1], (payload) => json(200, payload, res));
              return;
            }
            if (req.method === "POST") {
              readBody(req, (body) => {
                let action = "";
                try { action = String(JSON.parse(body || "{}").action || ""); } catch { /* inválido */ }
                if (action !== "start") { json(400, { ok: false, error: "action deve ser start" }, res); return; }
                syncNowStart((r) => json(r.ok ? 200 : 500, r, res));
              });
              return;
            }
            json(405, { ok: false, error: "método não suportado" }, res);
          },
        });
        const disposeAll = () => {
          try { if (typeof registerSync === "function") registerSync(); } catch { /* já removido */ }
          try { if (typeof registerVersion === "function") registerVersion(); } catch { /* já removido */ }
          try { if (typeof registerRollback === "function") registerRollback(); } catch { /* já removido */ }
          try { if (typeof registerCore === "function") registerCore(); } catch { /* já removido */ }
        };
        console.log("[VersionBadge] rotas /api/dsh-version, /api/dsh-rollback e /api/dsh-core registradas (GET + POST)");
        return disposeAll;
      }, "version-badge: api");
      return;
    }
    if (++tries > 60) {
      console.log("[VersionBadge] webServer não ficou disponível — rotas não registradas");
      return;
    }
    setTimeout(waitForWebServer, 250);
  };
  waitForWebServer();

  ctx.on("webserver/index-inject", (table) => {
    table.push({ kind: "script", placement: "body", text: BADGE_JS });
    table.push({ kind: "script", placement: "body", text: CORE_UI_JS });
  });

  console.log("[VersionBadge] badge de versão + chave de auto-update + rollback ativos");
};

module.exports.default = module.exports;
