/**
 * Layout Panel — coluna de informações à direita
 * Versão: 1.1 (multi-dir + junctions) no DeepSeek Harness
 *
 * Cria uma coluna fixa à direita do dashboard para abrigar os badges
 * flutuantes (FreeLLMAPI, ⚡ Roteador, Modelos, consumo...) e outras
 * informações úteis (últimos arquivos modificados, status do gateway).
 *
 * Como funciona:
 *  - Server-side: registra GET /api/layout-info (via ctx.get("webServer")),
 *    que lista os arquivos mais recentemente modificados do diretório
 *    monitorado (LAYOUT_PANEL_DIR, default /home/deploy/projects) e o status
 *    básico do sistema. Nenhuma credencial é exposta.
 *  - Client-side (inject): injeta a coluna (position:fixed à direita),
 *    aplica padding-right no frame do app (a sessão "desliza" para a
 *    esquerda, sem sobreposição) e move para dentro da coluna todos os
 *    elementos com position:fixed no canto inferior direito (badges), com
 *    CSS !important neutralizando o posicionamento inline deles.
 *
 * Configuração (ambiente do processo dsh-web):
 *   LAYOUT_PANEL_DIR   diretório monitorado (default: /home/deploy/projects)
 *   LAYOUT_PANEL_WIDTH largura da coluna em px (default: 300)
 *
 * O estado (coluna aberta/recolhida) é lembrado em localStorage.
 */

"use strict";

const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");

// Assets do editor (CodeMirror 5 + marked.js) servidos localmente, sem CDN.
// ATENÇÃO: o webServer faz match de prefix com `${prefix}/` — por isso o path
// NÃO pode terminar com "/" (senão vira "//" e nunca matcheia).
const EDITOR_ASSETS_DIR = path.join(__dirname, "editor-assets");
const EDITOR_ASSETS_URL = "/dlp-editor";

// content-type por extensão para servir os assets do editor
const MIME = {
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".map": "application/json; charset=utf-8",
};

// Diretórios monitorados (LAYOUT_PANEL_DIRS ou LAYOUT_PANEL_DIR) — ver monitoredDirs().
const PANEL_WIDTH = Math.min(Math.max(parseInt(process.env.LAYOUT_PANEL_WIDTH || "300", 10) || 300, 220), 420);

// diretórios/arquivos que nunca aparecem na lista de recentes
const IGNORED_DIRS = new Set([
  "node_modules", ".git", "dist", "build", ".venv", "venv", "__pycache__",
  ".dsh", ".cache", ".next", ".nuxt", "coverage", ".idea", ".vscode",
  "server/data", "data", "logs", ".pm2"
]);
const IGNORED_EXT = new Set([".db", ".sqlite", ".lock", ".log", ".env", ".pid", ".map"]);
const MAX_DEPTH = 5;
const MAX_FILES = 100; // lista com rolagem propria: mostra os 100 mais recentes

/**
 * Diretórios monitorados. Aceita LAYOUT_PANEL_DIRS (lista separada por ";" —
 * prioridade) ou LAYOUT_PANEL_DIR (um único diretório). Default:
 * /home/deploy/projects (Linux) ou %USERPROFILE%\projects (Windows).
 */
function monitoredDirs() {
  const multi = process.env.LAYOUT_PANEL_DIRS || "";
  if (multi.trim()) {
    return multi.split(";").map((s) => s.trim()).filter(Boolean);
  }
  const single = process.env.LAYOUT_PANEL_DIR;
  if (single && single.trim()) return [single.trim()];
  return [process.platform === "win32" ? path.join(os.homedir(), "projects") : "/home/deploy/projects"];
}

/** Comparação segura de caminhos (Windows não diferencia maiúsculas/minúsculas). */
function comparablePath(value) {
  const resolved = path.resolve(value);
  return process.platform === "win32" ? resolved.toLowerCase() : resolved;
}

function samePath(a, b) {
  return comparablePath(a) === comparablePath(b);
}

/** `candidate` está lexicalmente dentro de `root`? */
function pathInside(root, candidate) {
  const r = comparablePath(root);
  const c = comparablePath(candidate);
  return c === r || c.startsWith(r + path.sep);
}

/** Varre um diretório (profundidade limitada) e devolve arquivos com mtime. */
function walkFiles(root, depth, out) {
  if (depth > MAX_DEPTH) return;
  let entries;
  try {
    entries = fs.readdirSync(root, { withFileTypes: true });
  } catch {
    return;
  }
  for (const ent of entries) {
    if (IGNORED_DIRS.has(ent.name)) continue;
    const full = path.join(root, ent.name);
    let st;
    try {
      // statSync segue junctions/symlinks: um junction apontando para outro
      // diretorio e tratado como diretorio (isDirectory() do dirent sozinho
      // retorna false para junction no Windows).
      st = fs.statSync(full);
    } catch {
      continue;
    }
    if (st.isDirectory()) {
      walkFiles(full, depth + 1, out);
    } else if (st.isFile()) {
      const ext = path.extname(ent.name).toLowerCase();
      if (IGNORED_EXT.has(ext)) continue;
      out.push({
        path: full,
        name: ent.name,
        mtimeMs: st.mtimeMs,
        size: st.size,
      });
    }
  }
}

function layoutInfoPayload() {
  const dirs = monitoredDirs();
  const files = [];
  for (const dir of dirs) {
    try {
      walkFiles(dir, 0, files);
    } catch (e) {
      /* sem acesso: lista vazia */
    }
  }
  files.sort((a, b) => b.mtimeMs - a.mtimeMs);
  const top = files.slice(0, MAX_FILES).map((f) => {
    // `root` identifica de qual diretório monitorado o arquivo veio. Isso é
    // essencial no Windows, onde o painel monitora vários roots/junctions e o
    // mesmo caminho relativo pode existir em mais de um deles.
    const owned = dirs.find((d) => pathInside(d, f.path)) || dirs[0] || "";
    return {
      path: f.path,
      root: owned,
      rel: path.relative(owned, f.path),
      name: f.name,
      mtimeMs: f.mtimeMs,
      size: f.size,
    };
  });
  return {
    ok: true,
    dir: dirs.join(" ; "),
    dirs: dirs,
    hostname: os.hostname(),
    uptimeSec: Math.round(process.uptime()),
    files: top,
  };
}

const MAX_EDIT_SIZE = 1024 * 1024; // 1MB — acima disso recusa abrir no editor

/**
 * Resolve um caminho relativo dentro dos diretórios monitorados
 * (anti path-traversal). Quando `root` é informado, resolve SOMENTE naquele
 * diretório. Sem isso, no Windows, um arquivo do 2º root podia abrir o arquivo
 * homônimo do 1º root — daí o editor mostrar conteúdo errado (ex.: "import …").
 */
function resolveInside(rel, root) {
  if (typeof rel !== "string" || rel.length === 0) return null;
  const dirs = monitoredDirs();
  let candidates = dirs;
  if (typeof root === "string" && root.trim()) {
    const selected = dirs.find((d) => samePath(d, root));
    if (!selected) return null;
    candidates = [selected];
  }
  for (const dir of candidates) {
    const resolved = path.resolve(dir, rel);
    if (!pathInside(dir, resolved)) continue;
    return resolved;
  }
  return null;
}

/** Lê um arquivo de texto com limite de tamanho; rejeita binários. */
function readTextFile(rel, root) {
  const full = resolveInside(rel, root);
  if (!full) return { error: "caminho fora do diretório monitorado" };
  let st, buf;
  try {
    st = fs.statSync(full);
    buf = fs.readFileSync(full);
  } catch (e) {
    return { error: `não foi possível ler: ${e.code ?? e.message}` };
  }
  if (!st.isFile()) return { error: "não é um arquivo" };
  if (st.size > MAX_EDIT_SIZE) return { error: `arquivo grande demais (${(st.size / 1048576).toFixed(1)}MB, máx 1MB)` };
  // binário? procura byte nulo nos primeiros 8KB
  const probe = buf.subarray(0, 8192);
  if (probe.includes(0)) return { error: "arquivo binário — não pode ser aberto no editor" };
  return { ok: true, path: full, content: buf.toString("utf8"), size: st.size, mtimeMs: st.mtimeMs };
}

/** Grava um arquivo de texto com limite de tamanho. */
function writeTextFile(rel, root, content) {
  const full = resolveInside(rel, root);
  if (!full) return { error: "caminho fora do diretório monitorado" };
  if (typeof content !== "string") return { error: "conteúdo inválido" };
  if (Buffer.byteLength(content, "utf8") > MAX_EDIT_SIZE) return { error: "conteúdo grande demais (máx 1MB)" };
  try {
    fs.writeFileSync(full, content, "utf8");
    const st = fs.statSync(full);
    return { ok: true, path: full, mtimeMs: st.mtimeMs };
  } catch (e) {
    return { error: `não foi possível salvar: ${e.code ?? e.message}` };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// CLIENT: CSS da coluna (injetado no <head>)
// ═══════════════════════════════════════════════════════════════════════════

const PANEL_CSS = `
#dsh-layout-panel{position:fixed;top:0;right:0;bottom:0;width:${PANEL_WIDTH}px;z-index:2147483646;
  background:#0d1117;border-left:1px solid #30363d;
  display:flex;flex-direction:column;font:12px/1.5 system-ui,sans-serif;color:#e6edf3;
  box-shadow:-8px 0 24px rgba(0,0,0,.35);transition:transform .25s ease;}
#dsh-layout-panel.dlp-closed{transform:translateX(100%);}
#dsh-layout-panel .dlp-head{display:flex;align-items:center;justify-content:space-between;gap:8px;
  padding:10px 12px;border-bottom:1px solid #21262d;flex:none;}
#dsh-layout-panel .dlp-title{font-weight:700;font-size:12px;letter-spacing:.04em;text-transform:uppercase;color:#8b949e;}
#dsh-layout-panel .dlp-toggle{background:transparent;border:0;color:#8b949e;
  cursor:pointer;font:13px/1 system-ui,sans-serif;padding:4px 8px;border-radius:6px;}
#dsh-layout-panel .dlp-toggle:hover{background:#21262d;color:#fff;}
#dsh-layout-panel .dlp-body{flex:1;display:flex;flex-direction:column;min-height:0;}
#dsh-layout-panel .dlp-section{margin-bottom:14px;}
#dsh-layout-panel .dlp-section h3{margin:0 0 6px;font-size:10px;font-weight:700;letter-spacing:.05em;
  text-transform:uppercase;color:#8b949e;}
/* Zona superior FIXA (badges/atalhos) */
#dsh-layout-panel .dlp-top{flex:none;padding:10px 12px 4px;border-bottom:1px solid #21262d;}
/* Zona do MEIO: lista de arquivos com rolagem propria */
#dsh-layout-panel .dlp-files-zone{flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden;}
#dsh-layout-panel .dlp-files-zone .dlp-files-head{flex:none;padding:10px 12px 2px;}
#dsh-layout-panel .dlp-files-scroll{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;padding:4px 12px 8px;}
/* Zona inferior FIXA (gateway + sistema) */
#dsh-layout-panel .dlp-bottom{flex:none;padding:8px 12px 12px;border-top:1px solid #21262d;}
#dsh-layout-panel .dlp-bottom .dlp-section{margin-bottom:8px;}
#dsh-layout-panel .dlp-bottom .dlp-section:last-child{margin-bottom:0;}
#dsh-layout-panel .dlp-badges{display:flex;flex-direction:column;gap:6px;margin-bottom:2px;}
#dsh-layout-panel .dlp-badges > *{position:static !important;right:auto !important;bottom:auto !important;
  left:auto !important;top:auto !important;z-index:auto !important;transform:none !important;
  margin:0 !important;width:100% !important;box-sizing:border-box;}
#dsh-layout-panel ul.dlp-files{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:2px;}
#dsh-layout-panel .dlp-file{display:flex;flex-direction:column;gap:1px;padding:5px 8px;border-radius:6px;
  cursor:pointer;border:1px solid transparent;}
#dsh-layout-panel .dlp-file:hover{background:#161b22;border-color:#21262d;}
#dsh-layout-panel .dlp-file .fl-dir{font:10px/1.4 ui-monospace,SFMono-Regular,Menlo,monospace;color:#8b949e;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
#dsh-layout-panel .dlp-file .fl-name{font:11px/1.4 ui-monospace,SFMono-Regular,Menlo,monospace;color:#e6edf3;
  font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
#dsh-layout-panel .dlp-file .fl-meta{display:flex;justify-content:space-between;gap:8px;font-size:10px;color:#8b949e;}
#dsh-layout-panel .dlp-sys{display:grid;grid-template-columns:1fr 1fr;gap:4px 10px;font-size:11px;}
#dsh-layout-panel .dlp-sys b{color:#8b949e;font-weight:600;}
#dsh-layout-panel .dlp-empty{color:#8b949e;font-size:11px;padding:4px 2px;}
#dsh-layout-panel .dlp-status{display:inline-flex;align-items:center;gap:6px;font-size:11px;}
#dsh-layout-panel .dlp-dot{width:7px;height:7px;border-radius:50%;background:#d29922;flex:none;display:inline-block;}
#dsh-layout-panel .dlp-dot.ok{background:#3fb950;}
#dsh-layout-panel .dlp-dot.bad{background:#f85149;}
#dlp-open-btn{position:fixed;right:0;top:50%;transform:translateY(-50%);z-index:2147483646;
  background:#0d1117;border:1px solid #30363d;border-right:0;
  color:#8b949e;cursor:pointer;font:12px/1 system-ui,sans-serif;
  padding:10px 6px;border-radius:8px 0 0 8px;box-shadow:-4px 0 12px rgba(0,0,0,.3);}
#dlp-open-btn:hover{color:#fff;}
#dlp-editor-modal{position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.6);
  display:flex;align-items:center;justify-content:center;}
#dlp-editor-modal .ed-win{width:min(1200px,96vw);height:min(820px,94vh);background:#0d1117;
  border:1px solid #30363d;border-radius:10px;overflow:hidden;display:flex;flex-direction:column;
  box-shadow:0 14px 56px rgba(0,0,0,.65);}
#dlp-editor-modal .ed-head{display:flex;align-items:center;gap:10px;padding:8px 12px;
  border-bottom:1px solid #21262d;font:12px/1.4 system-ui,sans-serif;color:#9ecbff;flex:none;}
#dlp-editor-modal .ed-file{font:12px/1.4 ui-monospace,SFMono-Regular,Menlo,monospace;color:#e6edf3;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;}
#dlp-editor-modal .ed-path{color:#8b949e;font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:35%;}
#dlp-editor-modal .ed-tabs{display:inline-flex;gap:2px;background:#161b22;border:1px solid #21262d;border-radius:6px;padding:2px;flex:none;}
#dlp-editor-modal .ed-tab{background:transparent;border:0;color:#8b949e;border-radius:4px;cursor:pointer;
  padding:4px 12px;font:12px/1 system-ui,sans-serif;}
#dlp-editor-modal .ed-tab.active{background:#30363d;color:#fff;}
#dlp-editor-modal .ed-btn{background:#21262d;border:1px solid #30363d;color:#e6edf3;border-radius:6px;
  cursor:pointer;padding:5px 12px;font:12px/1 system-ui,sans-serif;flex:none;}
#dlp-editor-modal .ed-btn:hover{background:#30363d;}
#dlp-editor-modal .ed-btn.save{background:#238636;border-color:#238636;color:#fff;}
#dlp-editor-modal .ed-btn.save:hover{filter:brightness(1.15);}
#dlp-editor-modal .ed-btn.close{background:transparent;border:0;color:#8b949e;font:15px/1 system-ui,sans-serif;padding:5px 9px;}
#dlp-editor-modal .ed-btn.close:hover{background:#21262d;color:#fff;}
#dlp-editor-modal .ed-wrap{flex:1;display:flex;min-height:0;background:#0d1117;position:relative;}
#dlp-editor-modal .ed-area-cm{flex:1;min-width:0;position:relative;}
#dlp-editor-modal .ed-preview{flex:1;min-width:0;overflow:hidden;padding:0;background:#fff;display:none;position:relative;}
#dlp-editor-modal .ed-preview.active{display:block;}
#dlp-editor-modal .ed-preview iframe{display:block;width:100%;height:100%;border:0;background:#fff;}
#dlp-editor-modal .ed-preview h1,#dlp-editor-modal .ed-preview h2,#dlp-editor-modal .ed-preview h3{color:#9ecbff;margin:14px 0 8px;}
#dlp-editor-modal .ed-preview h1{font-size:20px;border-bottom:1px solid #21262d;padding-bottom:6px;}
#dlp-editor-modal .ed-preview h2{font-size:17px;}
#dlp-editor-modal .ed-preview h3{font-size:14px;}
#dlp-editor-modal .ed-preview p{margin:8px 0;}
#dlp-editor-modal .ed-preview code{background:#161b22;border:1px solid #21262d;border-radius:4px;padding:1px 5px;font:12px ui-monospace,monospace;}
#dlp-editor-modal .ed-preview pre{background:#161b22;border:1px solid #21262d;border-radius:6px;padding:10px 12px;overflow:auto;}
#dlp-editor-modal .ed-preview pre code{background:transparent;border:0;padding:0;}
#dlp-editor-modal .ed-preview a{color:#4d9fff;}
#dlp-editor-modal .ed-preview table{border-collapse:collapse;margin:10px 0;}
#dlp-editor-modal .ed-preview th,#dlp-editor-modal .ed-preview td{border:1px solid #30363d;padding:5px 10px;}
#dlp-editor-modal .ed-preview blockquote{border-left:3px solid #30363d;margin:8px 0;padding:2px 12px;color:#8b949e;}
#dlp-editor-modal .ed-preview ul,#dlp-editor-modal .ed-preview ol{padding-left:22px;margin:8px 0;}
#dlp-editor-modal .ed-preview hr{border:0;border-top:1px solid #21262d;margin:14px 0;}
#dlp-editor-modal .ed-status{flex:none;padding:5px 12px;border-top:1px solid #21262d;font:11px/1.5 system-ui,sans-serif;
  color:#8b949e;display:flex;justify-content:space-between;gap:10px;}
#dlp-editor-modal .ed-status.ok{color:#3fb950;}
#dlp-editor-modal .ed-status.err{color:#f85149;}
#dlp-editor-modal .ed-status .ed-ln{color:#484f58;}
/* Fallback sem CodeMirror: textarea ocupa 100% (modo texto simples) */
#dlp-editor-modal .ed-area-cm{display:flex;flex-direction:column;}
#dlp-editor-modal .ed-area-cm textarea{display:block;flex:1 1 auto;min-height:0;width:100%;height:auto;box-sizing:border-box;
  background:#0d1117;color:#e6edf3;border:0;outline:none;resize:none;margin:0;padding:4px 8px;
  font:13px/1.55 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;white-space:pre;overflow:auto;tab-size:2;}
#dlp-editor-modal .ed-area-cm .CodeMirror{height:auto;flex:1 1 auto;min-height:0;}
/* CodeMirror — escuro, compacto, sem bordas internas */
#dlp-editor-modal .CodeMirror{height:100%;background:#0d1117;color:#e6edf3;font:13px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace;}
#dlp-editor-modal .CodeMirror-gutters{background:#161b22;border-right:1px solid #21262d;}
#dlp-editor-modal .CodeMirror-linenumber{color:#484f58;}
#dlp-editor-modal .CodeMirror-cursor{border-left:1px solid #e6edf3;}
#dlp-editor-modal .CodeMirror-selected{background:#264f78;}
#dlp-editor-modal .CodeMirror-activeline-background{background:#161b22;}
#dlp-editor-modal .CodeMirror-matchingbracket{color:#3fb950 !important;outline:1px solid #3fb950;}
`;

// ═══════════════════════════════════════════════════════════════════════════
// CLIENT: JS da coluna (injetado no <body>)
// ═══════════════════════════════════════════════════════════════════════════

function dshEnvFlmUrl() {
  const env = process.env.DSH_ENV_NAME;
  if (env) {
    try {
      const fs = require("node:fs");
      const m = JSON.parse(fs.readFileSync(process.env.HOME + "/.dsh-envs/" + env + "/meta.json", "utf8"));
      if (m && m.freellmapiPort) return "http://127.0.0.1:" + m.freellmapiPort;
    } catch (e) { /* segue global */ }
  }
  return "http://127.0.0.1:3002";
}

/**
 * Helpers de preview (markdown). São definidos AQUI (código Node normal, sem
 * double-escape) e injetados no PANEL_JS via toString(), para não depender de
 * marked e para não sofrer com escapes de template literal.
 */
function mdInlineBrowser(src) {
  var s = esc(src);
  s = s.replace(/`([^`]+)`/g, "<code>$1</code>");
  s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  s = s.replace(/__([^_]+)__/g, "<strong>$1</strong>");
  s = s.replace(/(^|[\s(])\*([^*\n]+)\*/g, "$1<em>$2</em>");
  s = s.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  return s;
}
function mdToHtmlBrowser(src) {
  var out = [];
  var lines = String(src || "").replace(/\r\n?/g, "\n").split("\n");
  var i = 0;
  function block(html) { out.push(html); }
  while (i < lines.length) {
    var L = lines[i];
    var m;
    if (/^\s*```/.test(L)) {
      i++;
      var code = [];
      while (i < lines.length && !/^\s*```/.test(lines[i])) { code.push(esc(lines[i])); i++; }
      i++;
      block("<pre><code>" + code.join("\n") + "</code></pre>");
      continue;
    }
    if ((m = L.match(/^(#{1,6})\s+(.*)$/))) {
      var lvl = Math.min(m[1].length, 6);
      block("<h" + lvl + ">" + mdInlineBrowser(m[2]) + "</h" + lvl + ">");
      i++;
      continue;
    }
    if (/^\s*(?:---+|___+|\*\*\*+)\s*$/.test(L)) { block("<hr>"); i++; continue; }
    m = L.match(/^\s*(?:[-*+]|\d+\.)\s+(.*)$/);
    if (m) {
      var tag = /^\s*\d/.test(L) ? "ol" : "ul";
      var items = [];
      while (i < lines.length) {
        var lm = lines[i].match(/^\s*(?:[-*+]|\d+\.)\s+(.*)$/);
        if (!lm) break;
        items.push("<li>" + mdInlineBrowser(lm[1]) + "</li>");
        i++;
      }
      block("<" + tag + ">" + items.join("") + "</" + tag + ">");
      continue;
    }
    if (/^\s*$/.test(L)) { i++; continue; }
    block("<p>" + mdInlineBrowser(L) + "</p>");
    i++;
  }
  return out.join("");
}

const PANEL_JS = `(function () {
  var DSH_INSTANCE = ${JSON.stringify(process.env.DSH_ENV_NAME || "")};
  "use strict";
  var PANEL_DIRS = ${JSON.stringify((() => { try { return monitoredDirs(); } catch (e) { return [process.platform === "win32" ? (os.homedir() + "\\projects") : "/home/deploy/projects"]; } })())};
  var API = "/api/layout-info";
  var API_FILE = "/api/layout-file";
  var FREELMAPI = ${JSON.stringify(dshEnvFlmUrl())};
  var LS_KEY = "dlp-collapsed-v1";

  function esc(s) { var d = document.createElement("div"); d.textContent = s == null ? "" : String(s); return d.innerHTML; }
  function fmtAgo(ms) {
    var s = Math.max(1, Math.floor((Date.now() - ms) / 1000));
    if (s < 60) return s + "s";
    if (s < 3600) return Math.floor(s / 60) + "min";
    if (s < 86400) return Math.floor(s / 3600) + "h";
    return Math.floor(s / 86400) + "d";
  }
  function fmtSize(n) {
    if (n < 1024) return n + "B";
    if (n < 1048576) return (n / 1024).toFixed(1) + "KB";
    return (n / 1048576).toFixed(1) + "MB";
  }

  var panel = null;
  var openBtn = null;

  function build() {
    if (document.getElementById("dsh-layout-panel")) return;
    panel = document.createElement("aside");
    panel.id = "dsh-layout-panel";
    panel.innerHTML =
      '<div class="dlp-head"><span class="dlp-title">Painel</span>' +
      '<button class="dlp-toggle" id="dlp-collapse" title="Recolher painel">»</button></div>' +
      '<div class="dlp-body">' +
        // Zona superior FIXA: atalhos/badges
        '<div class="dlp-top">' +
          '<div class="dlp-section"><h3>Atalhos</h3><div class="dlp-badges" id="dlp-badges"></div></div>' +
        '</div>' +
        // Zona do meio: lista de arquivos COM ROLAGEM propria (100 recentes)
        '<div class="dlp-files-zone">' +
          '<div class="dlp-files-head"><div class="dlp-section" style="margin-bottom:0"><h3>Últimos arquivos modificados</h3></div></div>' +
          '<div class="dlp-files-scroll"><ul class="dlp-files" id="dlp-files"><li class="dlp-empty">carregando…</li></ul></div>' +
        '</div>' +
        // Zona inferior FIXA: gateway + sistema
        '<div class="dlp-bottom">' +
          '<div class="dlp-section"><h3>Gateway FreeLLMAPI</h3>' +
            '<div class="dlp-status"><span class="dlp-dot" id="dlp-fl-dot"></span><span id="dlp-fl-txt">verificando…</span></div></div>' +
          '<div class="dlp-section"><h3>Sistema</h3><div class="dlp-sys" id="dlp-sys">…</div></div>' +
        '</div>' +
      '</div>';
    document.body.appendChild(panel);
    document.getElementById("dlp-collapse").onclick = function () { setClosed(true); };
    if (localStorage.getItem(LS_KEY) === "1") setClosed(true);
    refreshFiles();
    refreshGateway();
    setInterval(refreshFiles, 10000);
    setInterval(refreshGateway, 4000);
  }

  function setClosed(closed) {
    if (!panel) return;
    panel.classList.toggle("dlp-closed", closed);
    try { localStorage.setItem(LS_KEY, closed ? "1" : "0"); } catch (e) {}
    applyShift();
    if (closed && !openBtn) {
      openBtn = document.createElement("button");
      openBtn.id = "dlp-open-btn";
      openBtn.type = "button";
      openBtn.title = "Abrir painel";
      openBtn.textContent = "«";
      openBtn.onclick = function () { setClosed(false); };
      document.body.appendChild(openBtn);
    }
    if (!closed && openBtn) { openBtn.remove(); openBtn = null; }
  }

  /** Desloca o frame do app para a esquerda (padding-right) quando aberto. */
  function applyShift() {
    var frame = document.querySelector('div[style*="grid-template-columns"]');
    if (!frame) return;
    var closed = panel && panel.classList.contains("dlp-closed");
    if (closed) frame.style.paddingRight = "";
    else frame.style.paddingRight = ${PANEL_WIDTH} + "px";
  }

  /**
   * Move badges flutuantes do canto inferior direito para a coluna.
   *
   * BADGES_CONHECIDOS: badge NOSSO e adotado por ID, sem passar pelo filtro
   * geometrico. Esse filtro existe para nao arrastar elementos alheios, mas
   * deixava o badge para tras quando ele ficava mais largo que ~324px — e um
   * badge nao adotado fica ATRAS desta coluna (mesmo z-index, e o painel vem
   * depois no DOM), ou seja, some da tela. Caso real: a versao virou
   * "v0.2.116-1-ge651022", o badge de versao foi de ~265px para 333px e nunca
   * mais foi adotado (invisivel atras da coluna).
   */
  var BADGES_CONHECIDOS = ["dsh-version-badge", "dsh-core-badge", "freellmapi-badge"];
  function collectBadges() {
    var host = document.getElementById("dlp-badges");
    if (!panel || !host) return;
    var nodes = document.querySelectorAll("body *");
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (!el || el.id === "dsh-layout-panel" || el.id === "dlp-open-btn") continue;
      if (el.closest && el.closest("#dsh-layout-panel")) continue;
      if (el.closest && el.closest("#freellmapi-modal")) continue;
      if (host.contains(el)) continue;
      var cs;
      try { cs = window.getComputedStyle(el); } catch (e) { continue; }
      if (cs.position !== "fixed") continue;
      if (cs.display === "none" || cs.visibility === "hidden") continue;
      var conhecido = !!(el.id && BADGES_CONHECIDOS.indexOf(el.id) !== -1) ||
        !!(el.classList && el.classList.contains("freellmapi-badge"));
      var r = el.getBoundingClientRect();
      if (conhecido) {
        if (r.width < 1 || r.height < 1) continue;   // nao adota elemento vazio
      } else {
        if (r.width < 20 || r.width > 420 || r.height < 16 || r.height > 120) continue;
        // badges do canto direito: mesmo que o freellmapi-shortcut os tenha
        // empurrado para fora da viewport (top negativo), ainda captura se a
        // borda direita estiver na faixa do canto.
        if (r.right < window.innerWidth - 260) continue;
        if (r.left < window.innerWidth - 340) continue;
        if (r.top > window.innerHeight - 40 && r.bottom > window.innerHeight) continue;
      }
      // Badge do FreeLLMAPI sempre no TOPO da lista de atalhos.
      if (el.classList && el.classList.contains("freellmapi-badge")) {
        host.insertBefore(el, host.firstChild);
      } else {
        host.appendChild(el);
      }
    }
    // Garante que o FreeLLMAPI fique em primeiro, mesmo se ja estiver na lista
    // e outro badge for adicionado depois (re-insere no topo).
    var first = host.firstElementChild;
    if (first && !first.classList.contains("freellmapi-badge")) {
      var fl = host.querySelector(".freellmapi-badge");
      if (fl) host.insertBefore(fl, host.firstChild);
    }
  }

  function refreshFiles() {
    var ul = document.getElementById("dlp-files");
    if (!ul) return;
    fetch(API, { method: "GET" })
      .then(function (r) { if (!r.ok) throw new Error("http " + r.status); return r.json(); })
      .then(function (data) {
        var files = (data && data.files) || [];
        if (files.length === 0) {
          ul.innerHTML = '<li class="dlp-empty">nenhum arquivo encontrado em ' + esc(PANEL_DIRS.join(" ; ")) + "</li>";
        } else {
          ul.innerHTML = "";
          files.forEach(function (f) {
            var li = document.createElement("li");
            li.className = "dlp-file";
            li.title = f.path + " (" + new Date(f.mtimeMs).toLocaleString() + ")";
            // Divide o caminho relativo em diretorio (linha de cima, cinza,
            // truncado) e nome do arquivo (linha de baixo, em destaque), para
            // que o nome do arquivo seja visivel mesmo com caminho longo.
            var relStr = String(f.rel || "");
            var dirStr = "";
            var nameStr = String(f.name || relStr);
            var idx = Math.max(relStr.lastIndexOf("\\\\"), relStr.lastIndexOf("/"));
            if (idx >= 0) {
              dirStr = relStr.slice(0, idx);
              if (relStr.slice(idx + 1) === nameStr) { /* nome ja separado */ }
            }
            li.innerHTML =
              '<span class="fl-dir">' + esc(dirStr || ".") + "</span>" +
              '<span class="fl-name">' + esc(nameStr) + "</span>" +
              '<span class="fl-meta"><span>' + fmtAgo(f.mtimeMs) + "</span><span>" + fmtSize(f.size) + "</span></span>";
            li.onclick = function () { openEditor(f); };
            ul.appendChild(li);
          });
        }
        var sys = document.getElementById("dlp-sys");
        if (sys && data) {
          sys.innerHTML =
            "<span><b>Host:</b> " + esc(data.hostname || "-") + "</span>" +
            "<span><b>Uptime:</b> " + fmtAgo(Date.now() - (data.uptimeSec || 0) * 1000) + "</span>" +
            "<span style='grid-column:1/-1'><b>Dir:</b> " + esc(data.dir || PANEL_DIRS.join(" ; ")) + "</span>";
        }
      })
      .catch(function () {
        ul.innerHTML = '<li class="dlp-empty">erro ao listar arquivos</li>';
      });
  }

  // ── Editor de arquivos (estilo IDE com CodeMirror) ────────────────────────
  var edState = null; // { rel, dirty, saved, cm, mode }
  var cmLoaded = false; // assets do CodeMirror já carregados nesta página
  var ASSET = "/dlp-editor/";

  // Inclui o root de origem para não confundir arquivos homônimos quando o
  // Windows monitora vários diretórios/junctions.
  function fileApiUrl(rel, root) {
    var url = API_FILE + "?rel=" + encodeURIComponent(rel || "");
    if (root) url += "&root=" + encodeURIComponent(root);
    return url;
  }

  // modo CodeMirror por extensão de arquivo
  var CM_MODES = {
    js: "javascript", mjs: "javascript", cjs: "javascript", ts: "javascript", tsx: "javascript",
    jsx: "javascript", json: { name: "javascript", json: true },
    py: "python", yaml: "yaml", yml: "yaml",
    md: "markdown", markdown: "markdown",
    html: "htmlmixed", htm: "htmlmixed", vue: "htmlmixed", xml: "xml", svg: "xml",
    sh: "shell", bash: "shell", zsh: "shell",
    sql: "sql", css: "css", scss: "css",
    c: "clike", h: "clike", cpp: "clike", hpp: "clike", java: "clike", cs: "clike",
    rb: "ruby", php: "php", go: "go", rs: "rust",
    txt: null, text: null, log: null, conf: null, ini: null, env: null, toml: null
  };
  // arquivos de mode a carregar sob demanda (nome no disco == chave em CM_MODES)
  function cmModeFor(rel) {
    var dot = rel.lastIndexOf(".");
    var ext = dot >= 0 ? rel.slice(dot + 1).toLowerCase() : "";
    return CM_MODES[ext] ?? null;
  }

  // carrega um script/CSS uma única vez; resolve quando pronto
  function loadAsset(tag, src) {
    return new Promise(function (resolve, reject) {
      if (tag === "link") {
        if (document.querySelector('link[href="' + src + '"]')) { resolve(); return; }
        var l = document.createElement("link");
        l.rel = "stylesheet"; l.href = src;
        l.onload = resolve; l.onerror = function () { reject(new Error("css " + src)); };
        document.head.appendChild(l);
        return;
      }
      if (document.querySelector('script[src="' + src + '"]')) { resolve(); return; }
      var s = document.createElement("script");
      s.src = src;
      // async=false preserva a ORDEM de execução: os modos dependem do core
      // (codemirror.min.js) já ter definido CodeMirror antes de rodar.
      s.async = false;
      s.onload = resolve; s.onerror = function () { reject(new Error("js " + src)); };
      document.head.appendChild(s);
    });
  }

  // carrega o core do CodeMirror + tema + marked (uma vez por página)
  function ensureCmLoaded(mode) {
    var tasks = [
      loadAsset("link", ASSET + "codemirror.min.css"),
      loadAsset("link", ASSET + "theme-dracula.css"),
      loadAsset("script", ASSET + "codemirror.min.js"),
      loadAsset("script", ASSET + "marked.min.js")
    ];
    if (mode && mode !== "markdown") tasks.push(loadAsset("script", ASSET + "modes/" + mode + ".min.js"));
    return Promise.all(tasks).then(function () { cmLoaded = true; });
  }

  function edStatus(cls, text) {
    var st = document.getElementById("dlp-ed-status");
    if (!st) return;
    st.className = "ed-status" + (cls ? " " + cls : "");
    st.innerHTML = "<span>" + esc(text) + "</span><span class='ed-ln' id='dlp-ed-ln'>1:1</span>";
  }

  function edUpdateLine() {
    var cm = edState && edState.cm;
    var ln = document.getElementById("dlp-ed-ln");
    if (!cm || !ln) return;
    var cur = cm.getCursor();
    ln.textContent = (cur.line + 1) + ":" + (cur.ch + 1);
  }

  // ── Preview (markdown/html) — funciona mesmo sem CodeMirror ──
  // mdInline/mdToHtml são injetados aqui via toString() (definidos fora do
  // template, sem problemas de escape de barra invertida/crase).
  ${mdInlineBrowser.toString()}
  ${mdToHtmlBrowser.toString()}
  function edRenderPreview() {
    var pv = document.getElementById("dlp-ed-preview");
    if (!pv) return;
    var val = edGetValue() || "";
    var isHtml = edState && edState.previewHtml;
    var bodyHtml;
    if (isHtml) {
      bodyHtml = val;
    } else if (typeof marked !== "undefined") {
      try { bodyHtml = marked.parse(val); } catch (e) { bodyHtml = mdToHtmlBrowser(val); }
    } else {
      bodyHtml = mdToHtmlBrowser(val);
    }
    var css = "body{font:14px/1.65 -apple-system,'Segoe UI',Roboto,sans-serif;color:#1f2328;margin:18px 24px;max-width:920px}" +
      "h1,h2,h3{line-height:1.3;margin:18px 0 8px}h1{font-size:22px;border-bottom:1px solid #eaeef2;padding-bottom:6px}" +
      "h2{font-size:18px;border-bottom:1px solid #eaeef2;padding-bottom:4px}h3{font-size:15px}" +
      "pre{background:#f6f8fa;border:1px solid #eaeef2;border-radius:6px;padding:12px;overflow:auto;line-height:1.45}" +
      "code{background:#f6f8fa;border-radius:4px;padding:2px 5px;font:13px Consolas,'Courier New',monospace}" +
      "pre code{background:transparent;padding:0;border:0}" +
      "a{color:#0969da}img{max-width:100%}" +
      "table{border-collapse:collapse;margin:10px 0}th,td{border:1px solid #d0d7de;padding:5px 12px}th{background:#f6f8fa}" +
      "blockquote{border-left:4px solid #d0d7de;color:#57606a;margin:10px 0;padding:2px 14px}" +
      "hr{border:0;border-top:1px solid #eaeef2;margin:18px 0}" +
      "ul,ol{padding-left:26px}li{margin:3px 0}";
    var doc = '<!doctype html><html><head><meta charset="utf-8"><style>' + css + "</style></head><body>" + bodyHtml + "</body></html>";
    pv.innerHTML = '<iframe sandbox="allow-popups" title="preview"></iframe>';
    var f = pv.querySelector("iframe");
    try { f.srcdoc = doc; } catch (e) { f.setAttribute("srcdoc", doc); }
  }

  function edShowTab(which) {
    var cmEl = document.getElementById("dlp-ed-cm");
    var pv = document.getElementById("dlp-ed-preview");
    var tabs = document.querySelectorAll("#dlp-editor-modal .ed-tab");
    if (!cmEl || !pv) return;
    var isEdit = which === "edit";
    cmEl.style.display = isEdit ? "block" : "none";
    pv.classList.toggle("active", !isEdit);
    for (var i = 0; i < tabs.length; i++) tabs[i].classList.toggle("active", tabs[i].dataset.tab === which);
    if (!isEdit) edRenderPreview();
    else if (edState && edState.cm) edState.cm.refresh();
  }

  function edGetValue() {
    if (edState && edState.cm) return edState.cm.getValue();
    var area = document.getElementById("dlp-ed-area");
    return area ? area.value : "";
  }

  function edSave() {
    if (!edState) return;
    edStatus("", "salvando…");
    fetch(fileApiUrl(edState.rel, edState.root), {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ content: edGetValue() })
    })
      .then(function (r) { return r.json().then(function (d) { return { status: r.status, d: d }; }); })
      .then(function (res) {
        if (res.d && res.d.ok) {
          edState.dirty = false;
          edState.saved = Date.now();
          edStatus("ok", "salvo ✓ " + new Date(res.d.mtimeMs).toLocaleTimeString());
        } else {
          edStatus("err", "erro: " + (res.d && res.d.error ? res.d.error : "desconhecido"));
        }
      })
      .catch(function () { edStatus("err", "erro de rede ao salvar"); });
  }

  function edClose() {
    var m = document.getElementById("dlp-editor-modal");
    if (m) m.remove();
    edState = null;
    document.removeEventListener("keydown", edKey);
  }

  function edKey(e) {
    if (e.key === "Escape") { edClose(); return; }
    if ((e.ctrlKey || e.metaKey) && (e.key === "s" || e.key === "S")) {
      e.preventDefault();
      edSave();
    }
  }

  function openEditor(f) {
    if (edState) edClose();
    edState = { rel: f.rel, root: f.root || "", dirty: false, saved: null, cm: null };
    var mode = cmModeFor(f.rel);
    edState.mode = mode;
    var isMd = mode === "markdown";
    var isHtml = mode === "htmlmixed" || mode === "html";
    edState.previewHtml = isHtml;
    var hasPreview = isMd || isHtml;

    var m = document.createElement("div");
    m.id = "dlp-editor-modal";
    m.innerHTML =
      '<div class="ed-win">' +
        '<div class="ed-head">' +
          '<span class="ed-file">' + esc(f.rel) + "</span>" +
          '<span class="ed-path">' + esc(f.path) + "</span>" +
          '<div class="ed-tabs">' +
            '<button class="ed-tab active" data-tab="edit">Editar</button>' +
            (hasPreview ? '<button class="ed-tab" data-tab="preview">Preview</button>' : "") +
          "</div>" +
          '<button class="ed-btn" id="dlp-ed-copy" title="Copiar caminho">📋</button>' +
          '<button class="ed-btn save" id="dlp-ed-save">💾 Salvar (Ctrl+S)</button>' +
          '<button class="ed-btn close" id="dlp-ed-close" title="Fechar (Esc)">✕</button>' +
        "</div>" +
        '<div class="ed-wrap">' +
          '<div class="ed-area-cm" id="dlp-ed-cm"><textarea id="dlp-ed-area" spellcheck="false"></textarea></div>' +
          '<div class="ed-preview" id="dlp-ed-preview"></div>' +
        "</div>" +
        '<div class="ed-status" id="dlp-ed-status"><span>carregando…</span><span class="ed-ln" id="dlp-ed-ln">1:1</span></div>' +
      "</div>";
    document.body.appendChild(m);
    document.getElementById("dlp-ed-close").onclick = edClose;
    document.getElementById("dlp-ed-save").onclick = edSave;
    document.getElementById("dlp-ed-copy").onclick = function () {
      try { navigator.clipboard.writeText(f.path); } catch (e) {}
      edStatus("ok", "caminho copiado: " + f.path);
    };
    var tabs = m.querySelectorAll(".ed-tab");
    for (var t = 0; t < tabs.length; t++) {
      tabs[t].onclick = function () { edShowTab(this.dataset.tab); };
    }
    m.addEventListener("click", function (e) { if (e.target === m) edClose(); });
    document.addEventListener("keydown", edKey);

    edStatus("", "carregando conteúdo…");
    // Estratégia em camadas (funciona mesmo se o CodeMirror falhar no Windows):
    //  1) o texto é carregado e mostrado IMEDIATAMENTE num <textarea> de tela
    //     cheia (com rolagem própria) — nunca fica preso à primeira linha;
    //  2) quando/SE os assets do CodeMirror carregarem, o textarea é "elevado"
    //     a editor com gutter/cores, copiando o valor que já está visível.
    var contentReady = false;
    var cmReady = false;
    var contentOk = false;

    function showPlain(msg) {
      edState.plain = true;
      edStatus("", msg || "pronto · " + fmtSize(edState.size || 0) + " · UTF-8 (texto)");
    }

    function upgradeToCM() {
      if (!contentOk || !cmReady || edState.cm) return;
      if (typeof CodeMirror === "undefined") { cmReady = false; return; }
      var ta = document.getElementById("dlp-ed-area");
      if (!ta) return;
      try {
        var cm = CodeMirror.fromTextArea(ta, {
          mode: edState.mode ? (typeof edState.mode === "object" ? edState.mode : edState.mode) : "",
          theme: "dracula",
          lineNumbers: true,
          matchBrackets: true,
          autoCloseBrackets: true,
          styleActiveLine: true,
          indentUnit: 2,
          tabSize: 2,
          indentWithTabs: false,
          lineWrapping: false
        });
        edState.cm = cm;
        edState.plain = false;
        cm.scrollTo(0, 0);
        cm.setCursor({ line: 0, ch: 0 });
        cm.on("change", function () { edState.dirty = true; });
        cm.on("cursorActivity", edUpdateLine);
        edUpdateLine();
        edStatus("", "pronto · " + fmtSize(edState.size || 0) + " · UTF-8 · " + (edState.mode || "texto"));
        // Re-mede a viewport algumas vezes: se o modal ainda não tinha layout
        // pronto (flex acabou de montar), a 1ª medição pode vir truncada.
        var t = 0;
        (function reRefresh() {
          if (!edState || edState.cm !== cm) return;
          cm.refresh();
          cm.scrollTo(0, 0);
          cm.setCursor({ line: 0, ch: 0 });
          edUpdateLine();
          if (++t < 4) setTimeout(reRefresh, 160);
        })();
      } catch (e) {
        // qualquer falha do CodeMirror mantém o modo texto simples
        console.warn("[LayoutPanel] CodeMirror falhou ao ativar:", e);
        showPlain();
      }
    }

    function maybeUpgrade() { if (contentReady && cmReady) upgradeToCM(); }

    // carrega o conteúdo em paralelo com os assets do editor
    fetch(fileApiUrl(f.rel, f.root), { method: "GET" })
      .then(function (r) { return r.json().then(function (d) { return { status: r.status, d: d }; }); })
      .then(function (res) {
        if (!res || !res.d) return;
        var area = document.getElementById("dlp-ed-area");
        if (!area) return;
        if (!res.d.ok) {
          area.disabled = true;
          edStatus("err", "não foi possível abrir: " + (res.d.error || "erro"));
          return;
        }
        area.value = res.d.content;
        area.disabled = false;
        edState.size = res.d.size;
        contentOk = true;
        contentReady = true;
        showPlain();
        maybeUpgrade();
      })
      .catch(function () {
        var area = document.getElementById("dlp-ed-area");
        if (area) { area.disabled = true; }
        edStatus("err", "erro de rede ao abrir arquivo");
      });

    ensureCmLoaded(mode).then(function () {
      cmReady = true;
      maybeUpgrade();
    }, function (err) {
      // assets do CodeMirror indisponíveis (ex.: Windows) — modo texto segue útil
      cmReady = true;
      console.warn("[LayoutPanel] CodeMirror indisponível, usando modo texto:", err && err.message ? err.message : err);
    });
  }

  function refreshGateway() {
    var dot = document.getElementById("dlp-fl-dot");
    var txt = document.getElementById("dlp-fl-txt");
    if (!dot || !txt) return;
    fetch(FREELMAPI + "/api/last-request", { method: "GET" })
      .then(function (r) { if (!r.ok) throw new Error("http " + r.status); return r.json(); })
      .then(function (data) {
        var lr = data && data.lastRequest;
        dot.className = "dlp-dot ok";
        txt.textContent = lr ? ("online · " + lr.platform + "/" + (lr.servedModel || lr.modelId)) : "online · sem requisições";
      })
      .catch(function () {
        dot.className = "dlp-dot bad";
        txt.textContent = "offline";
      });
  }

  function boot() {
    if (!document.body) { setTimeout(boot, 250); return; }
    var style = document.createElement("style");
    style.id = "dlp-style";
    style.textContent = ${JSON.stringify(PANEL_CSS)};
    document.head.appendChild(style);
    build();
    applyShift();
    collectBadges();
    setInterval(collectBadges, 2000);
    setInterval(applyShift, 2000);
    window.addEventListener("resize", applyShift);
    new MutationObserver(function () { applyShift(); }).observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  // ── Rodapé: desinstalar a instância (somente quando rodar numa instância) ──
  function envLabel() { return DSH_INSTANCE || 'esta instância'; }
  function runUninstall() {
    if (!window.confirm('Desinstalar a instância ' + envLabel() + '? Ela sera encerrada, a janela fechada, e os atalhos/pasta/perfil removidos. O sistema principal nao e afetado.')) return;
    function setState(t) { var el = document.getElementById('dsh-uninstall-bar-btn'); if (el) el.textContent = t; }
    setState('Desinstalando...')
    fetch('/api/dsh-core', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action: 'uninstall' }) })
      .then(function () { setState('Desinstalando...'); try { window.close(); } catch (e) {} })
      .catch(function () { setState('Erro ao desinstalar (veja logs)'); });
  }
  function ensureUninstallUI() {
    if (!DSH_INSTANCE) return;
    var panel = document.getElementById('dsh-layout-panel');
    if (!panel || document.getElementById('dsh-uninstall-bar')) return;
    var bar = document.createElement('div');
    bar.id = 'dsh-uninstall-bar';
    bar.style.cssText = 'flex:0 0 auto;padding:5px 8px 8px;border-top:1px solid #30363d;';
    var b = document.createElement('button');
    b.type = 'button'; b.id = 'dsh-uninstall-bar-btn';
    b.textContent = '🗑 Desinstalar a instância ' + DSH_INSTANCE + ' (e os atalhos)';
    b.title = 'Desinstala SOMENTE esta instância: ' + DSH_INSTANCE + '.';
    b.style.cssText = 'width:100%;padding:4px 6px;border:0;border-radius:6px;background:#2d1418;color:#ff9580;font:10px/1.4 system-ui,sans-serif;cursor:pointer;text-align:center;';
    b.onclick = runUninstall;
    bar.appendChild(b);
    panel.appendChild(bar);
  }
  setInterval(ensureUninstallUI, 2000);
  setInterval(ensureUninstallUI, 2500);
  setInterval(maybeAddUninstall, 3000);
  })();`;

// ═══════════════════════════════════════════════════════════════════════════
// CORDIS PLUGIN
// ═══════════════════════════════════════════════════════════════════════════

const layoutPanelPlugin = {
  name: "dsh-layout-panel",

  apply(ctx) {
    // API: últimos arquivos modificados + status (sem credenciais).
    // O host webserver pode ativar DEPOIS do apply deste plugin (que não
    // declara inject) — espera o serviço ficar disponível antes de registrar.
    let tries = 0;
    const waitForWebServer = () => {
      const webServer = ctx.get("webServer");
      if (webServer) {
        ctx.effect(() => {
          const disposers = [
            webServer.register({
              kind: "exact",
              path: "/api/layout-info",
              handler: (_req, res) => {
                res.writeHead(200, { "content-type": "application/json; charset=utf-8" });
                res.end(JSON.stringify(layoutInfoPayload()));
              }
            }),
            // GET /api/layout-file?rel=... → conteúdo do arquivo
            // POST /api/layout-file?rel=... (body JSON {content}) → salva
            webServer.register({
              kind: "exact",
              path: "/api/layout-file",
              handler: (req, res) => {
                const url = new URL(req.url ?? "/", "http://127.0.0.1");
                const rel = url.searchParams.get("rel") ?? "";
                const root = url.searchParams.get("root") ?? "";
                const json = (code, obj) => {
                  res.writeHead(code, { "content-type": "application/json; charset=utf-8" });
                  res.end(JSON.stringify(obj));
                };
                if (req.method === "GET") {
                  const out = readTextFile(rel, root);
                  json(out.ok ? 200 : 400, out);
                  return;
                }
                if (req.method === "POST") {
                  let body = "";
                  req.on("data", (chunk) => { body += chunk; });
                  req.on("end", () => {
                    let content = "";
                    try { content = JSON.parse(body || "{}").content ?? ""; } catch { content = ""; }
                    const out = writeTextFile(rel, root, content);
                    json(out.ok ? 200 : 400, out);
                  });
                  return;
                }
                json(405, { error: "método não suportado" });
              }
            }),
            // Assets estáticos do editor (CodeMirror + marked) — prefix route
            webServer.register({
              kind: "exact",
              path: "/dlp-editor-test",
              handler: (_req, res) => {
                res.writeHead(200, { "content-type": "text/plain" });
                res.end("dlp-editor-test ok");
              }
            }),
            webServer.register({
              kind: "prefix",
              path: EDITOR_ASSETS_URL,
              handler: (req, res) => {
                const url = new URL(req.url ?? "/", "http://127.0.0.1");
                const rel = decodeURIComponent(url.pathname.slice(EDITOR_ASSETS_URL.length + 1));
                const full = path.resolve(EDITOR_ASSETS_DIR, rel);
                if (!full.startsWith(EDITOR_ASSETS_DIR + path.sep)) {
                  res.writeHead(403, { "content-type": "text/plain" });
                  res.end("forbidden");
                  return;
                }
                fs.readFile(full, (err, data) => {
                  if (err) {
                    res.writeHead(404, { "content-type": "text/plain" });
                    res.end("not found");
                    return;
                  }
                  res.writeHead(200, { "content-type": MIME[path.extname(full)] ?? "application/octet-stream" });
                  res.end(data);
                });
              }
            })
          ];
          console.log("[LayoutPanel] rotas /api/layout-info, /api/layout-file e /dlp-editor/ registradas");
          return () => { for (const d of disposers) d(); };
        }, "layout-panel: api");
        return;
      }
      if (++tries > 60) {
        console.log("[LayoutPanel] webServer nao ficou disponivel — rota nao registrada");
        return;
      }
      setTimeout(waitForWebServer, 250);
    };
    waitForWebServer();

    // coluna à direita + shift da sessão
    ctx.on("webserver/index-inject", (table) => {
      table.push({ kind: "script", placement: "body", text: PANEL_JS });
    });

    console.log(`[LayoutPanel] coluna direita (${PANEL_WIDTH}px) monitorando ${monitoredDirs().join(" ; ")}`);
  }
};

module.exports = layoutPanelPlugin;
module.exports.default = layoutPanelPlugin;
// touched 20260901-222745

// hmr-probe 1788313221185
