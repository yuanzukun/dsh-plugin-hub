/**
 * OpenRouter Enhanced — granulometria fina na escolha de modelos OpenRouter.
 *
 * Registra dois provedores extras no seletor de modelos do Harness:
 *
 *   - openrouter-free  ("OpenRouter Free"): somente modelos gratuitos
 *     (pricing prompt/completion = 0), direto da API do OpenRouter.
 *
 *   - openrouter-pro   ("OpenRouter Pro"): modelos populares com uma entrada
 *     por provedor disponivel (ex.: "Claude 3.5 Haiku — via Anthropic",
 *     "… — via Amazon Bedrock"). Cada variante injeta
 *     `provider: { order: [<provedor>] }` na request do OpenRouter, que e o
 *     mecanismo oficial de roteamento por provedor.
 *
 * Implementacao: subclasse de PiAiAdapter (do dsh-llm-pi-ai) com override de
 * `modelOf` — o ponto unico por onde o model id selecionado vira o objeto de
 * modelo pi-ai usado na request. Para ids de variante ("modelo@provedor"),
 * devolve o modelo real com compat.openRouterRouting, que o pi-ai ja traduz
 * para o campo `provider` do corpo da request.
 *
 * Dados estaticos em openrouter-enhanced-data.json (gerados da API do
 * OpenRouter: /models + /models/{id}/endpoints). Regeneraveis a qualquer
 * momento.
 */
"use strict";
const fs = require("node:fs");
const path = require("node:path");
const { createRequire } = require("node:module");
const { pathToFileURL } = require("node:url");

// resolve os pacotes do CLI instalado (mesmo padrao do smart-router)
const CANDIDATE_LIBS = [
  process.env.DSH_CLI_LIB,
  (function () {
    try {
      var nr = (require("node:child_process").execSync("npm root -g", { encoding: "utf8", shell: true }) || "").trim();
      if (nr) return require("node:path").join(nr, "@deepseek-ai", "dsh", "lib");
    } catch (e) { /* sem npm */ }
    return null;
  })(),
  require.main && require("node:path").dirname(require.main.filename),
  "/opt/dsh-tui/node/lib/node_modules/@deepseek-ai/dsh/lib/",
  "/usr/lib/node_modules/@deepseek-ai/dsh/lib/"
].filter(Boolean);

let requireCli = null;
let cliLib = null;
// Diagnostico: registra por que cada candidato falhou (vai para o web.log;
// essencial quando um plugin nao ativa no Windows).
const resolveDiag = [];
// createRequire() por si so NUNCA falha: so o resolve() prova que aquele lib/
// enxerga os pacotes do CLI. Sem essa checagem, um DSH_CLI_LIB errado (ou um
// 'npm root -g' estranho) escolhia o primeiro candidato e o plugin morria no
// apply() em vez de cair para o proximo. Resolver caminho nao avalia modulo
// nenhum — seguro durante o boot.
const NEEDED_PKGS = ["@deepseek-ai/dsh-llm-pi-ai", "@deepseek-ai/dsh-llm"];
for (const lib of CANDIDATE_LIBS) {
  try {
    const rq = createRequire(path.join(lib, "index.js"));
    for (const name of NEEDED_PKGS) rq.resolve(name);
    requireCli = rq;
    cliLib = lib;
    break;
  } catch (e) { resolveDiag.push(lib + " :: " + (e && e.message ? e.message : e)); }
}

// Diretorio do data file: o proprio plugin quando ele E a config viva (overlay em
// ~/.dsh); instalado como BUNDLE (dsh plugin add) o codigo roda dentro de
// node_modules, entao o estado vai para a config viva. __dirname nao existe se o
// loader usar ESM: nesse caso cai para DSH_HOME/~/.dsh (nunca o cwd).
const HERE = (function () {
  const aqui = typeof __dirname === "string" ? __dirname : "";
  const dentroDoPacote = /[\\/]node_modules[\\/]/.test(aqui);
  if (process.env.DSH_HOME) return process.env.DSH_HOME;  // config viva declarada
  if (aqui && !dentroDoPacote) return aqui;               // overlay copiado na config viva
  return path.join(require("node:os").homedir(), ".dsh");
})();
const DATA_FILE = path.join(HERE, "openrouter-enhanced-data.json");
// Instalado como BUNDLE (`dsh plugin add`) o repositório traz um catálogo padrão
// dentro do pacote: copie-o para a config viva na primeira execução, senão o
// plugin se desativaria por falta do data file em uma instalação nova.
(function seedDataFile() {
  try {
    if (fs.existsSync(DATA_FILE)) return;
    const src = path.join(__dirname, "openrouter-enhanced-data.json");
    if (src === DATA_FILE || !fs.existsSync(src)) return;
    fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    fs.copyFileSync(src, DATA_FILE);
  } catch { /* segue sem o catálogo padrão */ }
})();

const FREE = "openrouter-free";
const PRO = "openrouter-pro";
const BASE_URL = "https://openrouter.ai/api/v1";
const API_KEY_ENV = "OPENROUTER_API_KEY";

function piAiDist() {
  return path.join(path.dirname(cliLib), "node_modules", "@earendil-works", "pi-ai", "dist");
}

const plugin = {
  name: "openrouter-enhanced",
  inject: ["llm"],

  async apply(ctx) {
    // Fail-soft: NUNCA derruba o boot do harness por causa de resolucao — se o
    // CLI/dados nao estiverem disponiveis, o plugin desativa sozinho (sem
    // provedores extras, mas com a GUI funcionando) e deixa o motivo no log.
    if (!requireCli) {
      console.error("[openrouter-enhanced] desativado: nao foi possivel localizar o CLI instalado.");
      for (const d of resolveDiag) console.error("[openrouter-enhanced]   tentativa: " + d);
      console.error("[openrouter-enhanced] dicas: defina DSH_CLI_LIB=<npm-root>/@deepseek-ai/dsh/lib ou NODE_PATH=<npm-root>/@deepseek-ai/dsh/node_modules");
      return;
    }
    // Leitura do catalogo no apply() (nao no load do modulo): arquivo ausente
    // ou ilegivel desativa o plugin em vez de derrubar a arvore de plugins.
    let data;
    try {
      data = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    } catch (e) {
      console.error("[openrouter-enhanced] desativado: " + DATA_FILE + " ilegivel (" + (e && e.message ? e.message : e) + ")");
      return;
    }

    // import() dinamico e sequencial: evita a corrida entre o require sincrono
    // (CJS) e o carregamento ESM paralelo do mesmo modulo pelo boot.
    const resolvePkg = (name) => requireCli.resolve(name);
    const { PiAiAdapter } = await import(pathToFileURL(resolvePkg("@deepseek-ai/dsh-llm-pi-ai")).href);
    const { LlmError, assertUsableApiKey } = await import(pathToFileURL(resolvePkg("@deepseek-ai/dsh-llm")).href);
    const pi = await import(pathToFileURL(path.join(piAiDist(), "index.js")).href);
    const { openAICompletionsApi } = await import(pathToFileURL(path.join(piAiDist(), "api", "openai-completions.lazy.js")).href);
    const { createProvider, InMemoryCredentialStore, envApiKeyAuth } = pi;

    /** Mesma convencao do llm-pi-ai: resolve a chave pelo apiKeyEnv do perfil. */
    const resolveApiKey = async (provider, profile) => {
      const ref = profile.apiKeyEnv;
      if (ref === void 0) return void 0;
      const credentials = ctx.get("credentials");
      const hit = credentials !== void 0 ? (await credentials.resolve(ref))?.value : void 0;
      if (hit !== void 0 && hit.length > 0) return assertUsableApiKey(hit, "openrouter-enhanced", ref);
      throw new LlmError(
        `openrouter-enhanced: no credential for provider route "${provider}"; its profile resolves ${ref}, which is not set — store ${ref} through the web Models page (OpenRouter)`,
        "MISSING_CREDENTIAL"
      );
    };

    /**
     * Subclasse que traduz ids de variante ("modelo@provedor") no modelo real
     * com o roteamento de provedor que o pi-ai envia como `provider` no corpo
     * da request (compat.openRouterRouting).
     */
    class OpenRouterAdapter extends PiAiAdapter {
      modelOf(snapshot, provider, model) {
        if (provider === PRO) {
          const variant = data.variantMap[model];
          if (variant !== void 0) {
            const base = variant.base;
            return {
              ...base,
              id: variant.realId,
              name: variant.name,
              compat: { ...(base.compat ?? {}), openRouterRouting: variant.routing }
            };
          }
        }
        return super.modelOf(snapshot, provider, model);
      }

      /**
      * Inclui a descricao (preco/latencia/throughput/uptime) no catalogo que o
      * seletor de modelos renderiza como segunda linha de cada opcao.
      */
      listModels(provider) {
        return Promise.resolve().then(() => {
          const snapshot = this.current();
          this.profileOf(snapshot, provider);
          return snapshot.models.getModels(provider).map((model) => ({
            provider,
            id: model.id,
            name: model.name,
            inputModalities: [...model.input],
            ...model.description === void 0 ? {} : { description: model.description }
          }));
        });
      }
    }

    const makeProvider = (id, displayName, models) => createProvider({
      id,
      name: displayName,
      baseUrl: BASE_URL,
      auth: { apiKey: envApiKeyAuth("OpenRouter API key", [API_KEY_ENV]) },
      models,
      api: openAICompletionsApi()
    });

    const profileFor = (id, displayName, models) => ({
      provider: id,
      displayName,
      apiKeyEnv: API_KEY_ENV,
      retryPolicy: void 0,
      reasoning: void 0,
      streamIdleTimeoutMs: 300000,
      maxRequestImageBytes: 20 * 1024 * 1024,
      requestImagePixelBudget: 2048 * 2048,
      requestImageMaxBytes: 1024 * 1024,
      configuredMaxTokens: new Map(),
      headers: void 0,
      piProvider: makeProvider(id, displayName, models)
    });

    const profiles = new Map([
      [FREE, profileFor(FREE, "OpenRouter Free", data.freeModels)],
      [PRO, profileFor(PRO, "OpenRouter Pro", data.proModels)]
    ]);

    const adapter = new OpenRouterAdapter({
      profiles: () => profiles,
      resolveApiKey,
      auth: { credentials: new InMemoryCredentialStore() },
      resolveAttachments: () => ctx.get("attachments"),
      onReplayDegrade: ({ provider, model, reason }) => {
        ctx.logger.warn(`openrouter-enhanced: unusable replay state on "${provider}/${model}"; sending as provider-neutral content (${reason})`);
      }
    });

    ctx.llm.registerAdapter([FREE, PRO], adapter);
    ctx.logger.info(`openrouter-enhanced: registrados ${FREE} (${data.freeModels.length} modelos) e ${PRO} (${data.proModels.length} modelos)`);
  }
};

module.exports = plugin;
module.exports.default = plugin;
