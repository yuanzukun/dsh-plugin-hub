# Changelog

本项目的所有值得注意的变更都会记录在此文件中。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，
版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [0.2.1] - 2026-08-28

### 修复

- CI 失败：`lib/bridge.js` 引入的 `@deepseek-ai/dsh-tools` 未在 `package.json` 声明（加入 `peerDependencies` 与 `devDependencies`）。
- 测试同步：`resolveConfig` 的默认值断言更新为 0.2.0 的新默认（`maxProgressMessages` 为 0、`processingNotice` 为 true、`turnTimeoutMs` 为 15 分钟）。

## [0.2.0] - 2026-08-18

### 新增

- 飞书控制命令：`/workspace`（切项目目录）、`/mode`（= `/permission`，切工作模式）、`/model`（切模型）、`/effort`（切推理强度）、`/stop`（停止任务，别名 `/cancel`、`/halt`）、`/help`（命令列表）。
- 透传 DSH 原生命令：`/feedback`、`/goal`、`/plan`；`/export` 给出网页端操作提示。
- `/session`：列出 DSH 未归档会话（带标题、工作目录、时间），按编号或完整 ID 切换到指定会话（live 复用 / 磁盘恢复）。
- 即时回执：收到普通消息先回“正在处理 / 排队中”（`processingNotice`）。
- 单轮超时：单个 turn 超过 `turnTimeoutMs`（默认 15 分钟）自动取消并提示。
- DSH 自主轮次的结果主动推回飞书（目标轮询 / 定时任务 / 后台任务唤醒场景）。
- 转发工具之间的中间回复（`💬`），执行过程完整可见。
- `ask_user_question` 选项问答可在飞书交互：问题与选项以 `❓` 列表发到飞书，回复编号、选项文字或自由文本即可命中；非法回复（单选多号、编号越界）提示重答。
- 新增配置项：`reasoningEffort`、`processingNotice`、`turnTimeoutMs`。

### 修复

- `/reset` 后旧对话不再从 DSH 侧边栏消失（原来 dispose 导致“删除/归档”观感）。
- 渠道模型不再丢弃 `reasoningEffort`（原来回落为 high，思考量暴增）。
- 过程消息不再被飞书发送频控静默丢弃（新增全局节流队列，每条间隔 1 秒）。
- 归档会话不再可被 `/session` 接入；已接入的会话被归档后自动断开并开新对话。

### 变更

- `maxProgressMessages` 默认 `10` → `0`（不限制，有多少转多少；设正数才限条数）。
- 配置中新增 `reasoningEffort`（默认继承 Harness 默认模型的推理档）。

## [0.1.0] - 2026-08-16

### 新增

- 飞书 WebSocket 长连接桥接到 DeepSeek Harness Agent：单聊 / 群聊 @机器人，回复关联原消息，话题内回复留在原话题。
- 执行过程提示（`🔧 调用工具`）回传飞书。
- `/reset`、`/compact` 命令。
