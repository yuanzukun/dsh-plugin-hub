/**
 * 最小单元测试：lib/config.js 的配置解析纯函数（不依赖任何 DSH 服务、不连网）。
 */
import test from "node:test";
import assert from "node:assert/strict";
import { Config, resolveConfig } from "../lib/config.js";

test("resolveConfig fills documented defaults", () => {
  const out = resolveConfig({ appId: "cli_abc", appSecretEnv: "FEISHU_APP_SECRET" });
  assert.equal(out.domain, "feishu");
  assert.equal(out.dmMode, "open");
  assert.equal(out.requireMention, true);
  assert.equal(out.streamProgress, true);
  assert.equal(out.maxProgressMessages, 0);
  assert.equal(out.processingNotice, true);
  assert.equal(out.turnTimeoutMs, 15 * 60 * 1000);
  assert.equal(out.resetCommand, "/reset");
  assert.equal(out.compactCommand, "/compact");
  assert.equal(out.requireAdminForGroupReset, true);
  assert.equal(out.appId, "cli_abc");
});

test("resolveConfig rejects a blank appId", () => {
  assert.throws(() => resolveConfig({ appId: "   " }), /appId is required/);
});

test("resolveConfig rejects an errorMessage over 500 chars", () => {
  assert.throws(
    () => resolveConfig({ appId: "cli_abc", errorMessage: "x".repeat(501) }),
    /must not exceed 500/,
  );
});

test("resolveConfig keeps optional fields and drops undefined ones", () => {
  const out = resolveConfig({ appId: "cli_abc", model: "deepseek-v4-pro", botOpenId: undefined });
  assert.equal(out.model, "deepseek-v4-pro");
  assert.ok(!("botOpenId" in out));
});

test("Config schema accepts a valid minimal config", () => {
  const parsed = Config({ appId: "cli_abc" });
  assert.equal(parsed.domain, "feishu");
  assert.equal(parsed.dmMode, "open");
});

test("Config schema rejects an invalid domain", () => {
  assert.throws(() => Config({ appId: "cli_abc", domain: "example" }));
});
