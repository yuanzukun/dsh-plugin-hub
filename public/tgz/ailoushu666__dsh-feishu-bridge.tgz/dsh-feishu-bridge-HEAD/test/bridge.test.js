/**
 * 最小单元测试：lib/bridge.js 的会话映射 / Session ID 派生 / turn 汇总纯函数。
 * 只导入模块（peer 依赖以 devDependencies 安装），不创建 Agent、不连网。
 */
import test from "node:test";
import assert from "node:assert/strict";
import { conversationKey, toSessionId, summarizeTurn } from "../lib/bridge.js";

test("conversationKey: chats vs threads", () => {
  assert.equal(conversationKey({ chatId: "oc_1" }), "chat:oc_1");
  assert.equal(conversationKey({ chatId: "oc_1", threadId: "ot_9" }), "thread:oc_1:ot_9");
});

test("toSessionId: stable prefix, unique nonce, no raw chat id", () => {
  const a = toSessionId("feishu", "chat:oc_1");
  const b = toSessionId("feishu", "chat:oc_1");
  assert.equal(typeof a, "string");
  assert.ok(a.startsWith("feishu-"));
  assert.match(a, /^feishu-[0-9a-f]{24}-[0-9a-f]{12}$/);
  assert.notEqual(a, b); // 随机 nonce：每次“新建会话”都得到全新 ID
  assert.ok(!a.includes("oc_1")); // 原始 chat_id 不进 ID
});

test("toSessionId: different keys and domains digest differently", () => {
  const a = toSessionId("feishu", "chat:oc_1");
  const b = toSessionId("feishu", "chat:oc_2");
  const c = toSessionId("lark", "chat:oc_1");
  const digest = (id) => id.slice("feishu-".length, "feishu-".length + 24);
  assert.notEqual(digest(a), digest(b));
  assert.notEqual(digest(a), digest(c));
});

test("summarizeTurn picks the last non-empty assistant text after firstSeq", () => {
  const events = [
    { seq: 1, type: "user/message" },
    { seq: 2, type: "assistant/message", data: { message: { content: [{ type: "text", text: "first" }] } } },
    { seq: 3, type: "tool/call", data: {} },
    { seq: 4, type: "assistant/message", data: { message: { content: [{ type: "text", text: "final" }] } } },
    { seq: 5, type: "turn/end", data: { reason: { kind: "completed" } } },
  ];
  const out = summarizeTurn(events, 2);
  assert.equal(out.text, "final");
  assert.equal(out.reason.kind, "completed");
});

test("summarizeTurn ignores events before firstSeq", () => {
  const events = [
    { seq: 1, type: "assistant/message", data: { message: { content: [{ type: "text", text: "old" }] } } },
  ];
  const out = summarizeTurn(events, 2);
  assert.equal(out.text, "");
  assert.equal(out.reason, undefined);
});

test("summarizeTurn skips empty text blocks", () => {
  const events = [
    { seq: 1, type: "assistant/message", data: { message: { content: [{ type: "text", text: "" }] } } },
    { seq: 2, type: "assistant/message", data: { message: { content: [{ type: "text", text: "real" }] } } },
  ];
  assert.equal(summarizeTurn(events, 1).text, "real");
});
