/**
 * 最小单元测试：lib/feishu.js 的 parseInbound 入站消息解析（纯函数，不建连接、不连网）。
 */
import test from "node:test";
import assert from "node:assert/strict";
import { parseInbound } from "../lib/feishu.js";

const base = { dmMode: "open", groupAllowlist: [], dmAllowlist: [], requireMention: true };

function p2p(text, extra = {}) {
  return {
    sender: { sender_id: { open_id: "ou_1" } },
    message: {
      message_id: "om_1",
      chat_id: "oc_1",
      chat_type: "p2p",
      message_type: "text",
      content: JSON.stringify({ text }),
      mentions: [],
      ...extra,
    },
  };
}

test("parses a plain p2p text message", () => {
  const inbound = parseInbound(p2p("你好"), base);
  assert.equal(inbound.content, "你好");
  assert.equal(inbound.chatId, "oc_1");
  assert.equal(inbound.chatType, "p2p");
  assert.equal(inbound.threadId, undefined);
});

test("preserves threadId only for real (non-empty) threads", () => {
  assert.equal(parseInbound(p2p("hi", { thread_id: "ot_1" }), base).threadId, "ot_1");
  assert.equal(parseInbound(p2p("hi", { thread_id: null }), base).threadId, undefined);
  assert.equal(parseInbound(p2p("hi", { thread_id: "" }), base).threadId, undefined);
});

test("strips @mention placeholders from group messages", () => {
  const data = {
    sender: {},
    message: {
      message_id: "om_2",
      chat_id: "oc_2",
      chat_type: "group",
      message_type: "text",
      content: JSON.stringify({ text: "@_user_1 帮我写个脚本" }),
      mentions: [{ key: "@_user_1" }],
    },
  };
  const inbound = parseInbound(data, base);
  assert.equal(inbound.content, "帮我写个脚本");
});

test("group message without a mention is ignored when requireMention is on", () => {
  const data = {
    sender: {},
    message: {
      message_id: "om_3",
      chat_id: "oc_3",
      chat_type: "group",
      message_type: "text",
      content: JSON.stringify({ text: "hi" }),
      mentions: [],
    },
  };
  assert.equal(parseInbound(data, base), null);
});

test("non-text messages are ignored", () => {
  const data = {
    message: {
      message_id: "om_4",
      chat_id: "oc_4",
      chat_type: "p2p",
      message_type: "image",
      content: "{}",
    },
  };
  assert.equal(parseInbound(data, base), null);
});

test("dmMode disabled blocks p2p", () => {
  assert.equal(parseInbound(p2p("hi"), { ...base, dmMode: "disabled" }), null);
});

test("dmMode allowlist only admits listed open_ids", () => {
  const cfg = { ...base, dmMode: "allowlist", dmAllowlist: ["ou_other"] };
  assert.equal(parseInbound(p2p("hi"), cfg), null);
  assert.ok(parseInbound(p2p("hi"), { ...cfg, dmAllowlist: ["ou_1"] }));
});

test("groupAllowlist filters non-listed chats", () => {
  const data = {
    sender: {},
    message: {
      message_id: "om_6",
      chat_id: "oc_6",
      chat_type: "group",
      message_type: "text",
      content: JSON.stringify({ text: "hi" }),
      mentions: [{ key: "@_user_1" }],
    },
  };
  assert.equal(parseInbound(data, { ...base, groupAllowlist: ["oc_other"] }), null);
  assert.ok(parseInbound(data, { ...base, groupAllowlist: ["oc_6"] }));
});

test("malformed content JSON is ignored", () => {
  const data = {
    message: {
      message_id: "om_7",
      chat_id: "oc_7",
      chat_type: "p2p",
      message_type: "text",
      content: "not-json",
    },
  };
  assert.equal(parseInbound(data, base), null);
});
