import test from 'node:test'
import assert from 'node:assert/strict'
import { carryPerCall, computeCost, createPricer, mergeManualPriceModels, normalizeManualPeak, normalizeManualPriceModels, retimeManualPriceModels, SOURCE_MANUAL, toPerCallOnlyModels } from '../pricing.js'

test('normalizeManualPriceModels 生成可计价的模型表并标记 manual', () => {
  const models = normalizeManualPriceModels({
    'demo-model': { input: 2, output: 8, cacheRead: 0.04 },
    'usd-model': { input: 1, output: 2 },
  })
  assert.equal(models['demo-model'].origin, 'manual')
  assert.equal(models['demo-model'].periods[0].rate.output, 8)
  assert.equal(models['usd-model'].currency, 'CNY')
})

test('人工导入价格会被 pricer 识别为 manual，而不是 models.dev', () => {
  const models = normalizeManualPriceModels({ 'demo-model': { input: 2, output: 8 } })
  const pricer = createPricer({ providers: { demo: { models, currency: 'CNY' } } })
  const rule = pricer.resolve('demo', 'demo-model')
  assert.equal(rule.source, SOURCE_MANUAL)
  assert.equal(rule.periods[0].rate.input, 2)
  assert.equal(pricer.priceFor('demo', 'demo-model', Date.now()).rate.output, 8)
})

test('人工导入的精确模型 ID 优先于目录别名', () => {
  const models = normalizeManualPriceModels({ alias: { input: 99, output: 199 } })
  const pricer = createPricer({
    providers: {
      demo: {
        models: { ...models, real: { periods: [{ ranges: [[0, 24]], rate: { input: 1, output: 2 } }] } },
        aliases: { alias: 'real' },
      },
    },
  })
  assert.equal(pricer.resolve('demo', 'alias').periods[0].rate.input, 99)
})

test('normalizeManualPriceModels 拒绝全 0 与空表', () => {
  assert.throws(() => normalizeManualPriceModels({ m: { input: 0, output: 0 } }), /没有有效价格/)
  assert.throws(() => normalizeManualPriceModels({}), /没有可导入/)
})

test('mergeManualPriceModels 只覆盖填写的模型，保留未填写的旧价', () => {
  const old = normalizeManualPriceModels({
    keep: { input: 1, output: 2 },
    change: { input: 3, output: 4 },
  })
  const next = normalizeManualPriceModels({ change: { input: 9, output: 10 } })
  const merged = mergeManualPriceModels(old, next)
  assert.deepEqual(Object.keys(merged).sort(), ['change', 'keep'])
  assert.equal(merged.keep.periods[0].rate.input, 1)
  assert.equal(merged.change.periods[0].rate.input, 9)
})

test('人工峰时价按工作日时段命中，基础价覆盖其余时段', () => {
  const peak = normalizeManualPeak({ ranges: [[9, 12], [14, 18]], days: [1, 2, 3, 4, 5] })
  const models = normalizeManualPriceModels(
    { m: { input: 1, output: 2, peakInput: 3, peakOutput: 4 } },
    { peak },
  )
  assert.equal(models.m.periods.length, 2)
  assert.match(models.m.periods[0].label, /峰时/)
  assert.deepEqual(models.m.periods[0].ranges, [[9, 12], [14, 18]])
  const pricer = createPricer({ providers: { p: { models, currency: 'CNY' } } })
  const monday10 = Date.UTC(2026, 10, 2, 2) // 北京时间周一 10:00
  const monday8 = Date.UTC(2026, 10, 2, 0) // 北京时间周一 08:00
  assert.equal(pricer.priceFor('p', 'm', monday10).rate.input, 3)
  assert.equal(pricer.priceFor('p', 'm', monday10).peak, true)
  assert.equal(pricer.priceFor('p', 'm', monday8).rate.input, 1)
  assert.equal(pricer.priceFor('p', 'm', monday8).peak, false)
})

test('retimeManualPriceModels 把旧峰时价搬到新时段', () => {
  const models = normalizeManualPriceModels(
    { m: { input: 1, output: 2, peakInput: 3, peakOutput: 4 } },
    { peak: { ranges: [[9, 12]] } },
  )
  const moved = retimeManualPriceModels(models, { ranges: [[14, 18]], days: [1, 2, 3, 4, 5] })
  assert.deepEqual(moved.m.periods[0].ranges, [[14, 18]])
  assert.equal(moved.m.periods[0].rate.input, 3)
  assert.equal(moved.m.periods[1].rate.input, 1)
  const cleared = retimeManualPriceModels(models, null)
  assert.equal(cleared.m.periods.length, 1)
  assert.equal(cleared.m.periods[0].rate.input, 1)
})

test('normalizeManualPeak 拒绝越界时段，峰时价没有基础价时报错', () => {
  assert.throws(() => normalizeManualPeak({ ranges: [[12, 9]] }), /峰时时段/)
  assert.throws(() => normalizeManualPeak({ ranges: [[9, 25]] }), /峰时时段/)
  assert.throws(
    () => normalizeManualPriceModels({ m: { peakInput: 3 } }, { peak: { ranges: [[9, 12]] } }),
    /基础价为 0/,
  )
  assert.throws(
    () => normalizeManualPriceModels({ m: { input: 1, peakInput: 3 } }),
    /没有设置峰时时段/,
  )
})

test('carryPerCall：界面保存只有 token 单价时，旧按次价不被清零', () => {
  const old = normalizeManualPriceModels({ m: { perCall: 0.005 } }, { currency: 'USD' })
  const seeded = carryPerCall(old, { m: { input: 0, output: 0 } })
  assert.equal(seeded.m.perCall, 0.005)
  const models = normalizeManualPriceModels(seeded, { currency: 'USD' })
  assert.equal(models.m.periods[0].rate.perCall, 0.005)
  const pricer = createPricer({ providers: { p: { models, currency: 'USD' } }, usdToCny: 7.1 })
  const priced = pricer.priceFor('p', 'm', Date.now())
  assert.ok(Math.abs(priced.rate.perCall - 0.0355) < 1e-12)
})

test('carryPerCall：显式改价与全新模型不受影响', () => {
  const old = normalizeManualPriceModels({ a: { perCall: 0.005 }, b: { perCall: 0.002 } }, { currency: 'USD' })
  const seeded = carryPerCall(old, {
    a: { perCall: 0.01 },
    b: { input: 3 },
    c: { input: 1, output: 2 },
  })
  assert.equal(seeded.a.perCall, 0.01)
  assert.equal(seeded.b.perCall, 0.002)
  const models = normalizeManualPriceModels(seeded, { currency: 'USD' })
  assert.equal(models.a.periods[0].rate.perCall, 0.01)
  assert.equal(models.b.periods[0].rate.perCall, 0.002)
  assert.equal(models.b.periods[0].rate.input, 3)
  assert.equal(models.c.periods[0].rate.perCall, 0)
})

test('纯按次：只填 perCall 也能导入，并按时段后的单一价格计费', () => {
  const models = normalizeManualPriceModels({ relay: { perCall: 0.5 } })
  assert.equal(models.relay.origin, 'manual')
  assert.equal(models.relay.periods.length, 1)
  assert.equal(models.relay.periods[0].rate.perCall, 0.5)
  assert.equal(models.relay.periods[0].rate.input, 0)
  const pricer = createPricer({ providers: { relay: { models, currency: 'CNY' } } })
  const priced = pricer.priceFor('relay', 'relay', Date.now())
  // 没有 token 单价时，一次空 usage 调用就只花一次按次费。
  assert.equal(computeCost({}, priced.rate), 0.5)
  assert.equal(computeCost({ inputTokens: 1_000_000, outputTokens: 1_000_000 }, priced.rate), 0.5)
})

test('toPerCallOnlyModels：从 token 单价切到纯按次时清掉旧 token 价', () => {
  const models = normalizeManualPriceModels(
    { m: { input: 2, output: 8, perCall: 0.5, peakInput: 4, peakOutput: 16 } },
    { peak: { ranges: [[9, 12]], days: [1, 2, 3, 4, 5] } },
  )
  assert.equal(models.m.periods.length, 2)
  const stripped = toPerCallOnlyModels(models)
  assert.equal(stripped.m.periods.length, 2)
  for (const period of stripped.m.periods) {
    assert.equal(period.rate.input, 0)
    assert.equal(period.rate.output, 0)
    assert.equal(period.rate.cacheRead, 0)
    assert.equal(period.rate.cacheWrite, 0)
    // 旧记录只有基础时段填了按次价，转换后要铺到所有时段，否则峰时会按 0 元算。
    assert.equal(period.rate.perCall, 0.5)
  }
  const pricer = createPricer({ providers: { p: { models: stripped, currency: 'CNY' } } })
  const monday10 = Date.UTC(2026, 10, 2, 2) // 北京时间周一 10:00，落在峰时
  assert.equal(computeCost({ inputTokens: 1_000_000 }, pricer.priceFor('p', 'm', monday10).rate), 0.5)
  assert.equal(computeCost({ inputTokens: 1_000_000 }, pricer.priceFor('p', 'm', Date.UTC(2026, 10, 2, 0)).rate), 0.5)
})
