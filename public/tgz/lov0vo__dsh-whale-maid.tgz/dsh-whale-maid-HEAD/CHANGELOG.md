## 2.3.0 — 2026-10-27

五种显示形态，以及一轮无障碍补全。

### 新增

- **显示形态（五种）**：设置面板「鲸鱼女仆」新增「显示形态」选择器。
  - `悬浮`（默认）：原来的自由摆放，可拖动、会自己散步。
  - `底栏`：贴在你的输入框上方、靠右对齐，尺寸 96px。
  - `侧边`：挂在聊天栏右缘、略高于中线，尺寸 72px。
  - `迷你`：56px 的小号版，菜单按钮同步缩小，仍然可拖动。
  - `自动`：有输入框时按「底栏」摆放，没有输入框（例如设置页）时回到悬浮。
- 形态通过 `options.mode` 持久化，`window.dshWhaleMaid.setOptions({ mode: 'bar' })` 也能改；新增只读的 `window.dshWhaleMaid.modes()` 暴露形态清单与几何计算函数，便于在无 DOM 的测试里断言。
- **键盘摸头**：宠物现在是可 Tab 聚焦的按钮（带可见焦点环），聚焦后按数字键 **1–9** 分别摸「呆毛 / 耳朵 / 脸 / 头 / 腰 / 手 / 肚子 / 尾巴 / 脚」——此前九个部位只能用鼠标点。

### 变更

- 底栏与侧边形态下**不响应拖动、也不会自己散步**：它们锚在宿主元素上，拖动会在下一个测量周期被拉回，散步则会脱离锚点。点击、喂食、玩耍、分区反应照常。
- 底栏/侧边的锚点每 800ms 以及窗口 resize / 滚动时重新测量；**锚点消失时回落到悬浮**，而不是像参考插件那样把宠物 `display:none` 掉（那种"宠物突然不见了"是它最常见的使用反馈）。
- 尺寸改为按形态生效：显式设置的 `size` 仍然优先于形态默认值。

### 测试

- 新增 3 个用例：形态选项校验与非法值回落、`auto` 的解析与尺寸优先级、底栏/侧边的几何计算与出屏夹取。测试数 34 → 37。

## 2.2.0 — 2026-10-27

一致性修复：把「部分动作和设计稿不一致、部分热区点不到、播放时尺寸跳、动作幅度过大、CI 一直失败」这五个问题一次处理掉。

### 美术一致性

- **三张姿势表的袜子画错**：`poses/workSlack` 画成深蓝袜、`poses/waiting` 画成近白袜、`poses/angry` 第 3 帧干脆是裸腿，与设计帧（`idle.png` 第 0 帧，浅蓝白过膝袜 RGB≈151,153,169）不符。三张表共 9 帧全部从设计帧重新生成，提示词里把袜子颜色写成硬约束并列出禁止项（不许深蓝、不许纯白、不许裸腿）。
- **尺寸抖动**：同一张表内各帧高度不一致会让循环播放时角色呼吸。按「表内最高帧」统一（只做 ≤20% 的缩放，超过则判定需要重画而不是拉伸）：`play` 222/224/216 → 222/224/222、`sleep` 201/193 → 201/199、`walk` 221/224/221 → 222/224/222、`waiting` 225/194/225 → 225/225/225。差值 ≤2px 的表一律不动，那点弹动是原版手绘的味道。
- **帧序**：三帧表按「循环 IoU」选最优排列（含首尾衔接），没有明确改进就保持原序，避免无意义的抖动。

### 点击热区

- `DWM_HIT_REG` 按当前美术逐帧重算，**88 行**（此前 33 行且缺 `wink#1`/`wink#2`，那两帧只能走恒等映射，耳朵和尾巴边缘的点击会漏）。配准量取自 alpha 质心而非包围盒——`walk` 的包围盒左缘会移动 27px（尾巴收进去了），身体其实只动 2px。
- 未命中时的兜底从固定 `belly` 改成**几何最近的矩形**，点在尾巴外侧一点也算尾巴，不再一律算摸肚子。

### 动作幅度

- `drag` 帧率 5 → 2，并去掉 `motion: tilt`（拖拽本身已经有跟随指针的 3D 倾斜，再叠一层摆动会晃）。
- `play` 4 → 3、`wink` 2 → 1.5、立绘循环 `dwm-pose-cycle` 0.9s → 1.4s。

### CI

- 根因：提交进仓库的 `client.js` 里 `var STYLESHEET = "…"` 带 **CRLF**，而 Linux runner 重新构建出 **LF**，于是「构建产物必须与源码一致」这一步永远 diff 非零。`build.mjs` 现在读取源文件时统一 `\r\n?` → `\n`，写盘前再校验产物不含 CR；本次提交的 bundle 已是纯 LF（`client.js` 内 CR 计数 0）。
- `ci.yml` 的测试步骤补 `--test-force-exit`（桌宠持有定时器，测试进程不会自己退出）。

### 测试

- 34 项全部通过。`hit zones follow the artwork layout` 按新表与「最近矩形」语义更新（角点现在归 `feet`，尾巴下缘归 `tail`）。
## 2.1.1 — 2026-10-27

美术资源全量审计后的收尾修复（13 张动作表 + 19 张姿势表逐帧检查几何、基线、绿边、帧独立性）。

### 修复

- **`poses/afk.png` 第 0 帧尺寸跳变**：该帧角色高 240px，而第 1、2 帧是 225px，CSS 帧循环每轮第一帧都会把角色放大 6.7%。已按脚底锚点重采样到 225px。
- **残留键控绿像素**：`poses/abstract.png` f0 3 个、`poses/celebrate.png` f0 1 个、`poses/sweep.png` f0 1 个，已清除。
- **1px 基线偏差**：`poses/workPat.png`、`poses/workRam.png` 的 f0 底边在 y=255，已下移 1px 对齐 y=256。

### 未改动（有意保留）

- `eat` / `joy` / `play` / `wake` 的第 1–2 帧脚底比 y=256 高 1–2px：这是**上游原版美术**的跳跃/弹动感，不是缺陷；在 110px 显示尺寸下相当于 0.4–0.9 CSS px，不可见。重采样会损失原图锐度，故保持原样。

### 审计工具

- 新增仓库外的 `_tmp/whale-gen/audit_assets.py`：逐帧输出 bbox / 高度 / 底边 / 绿边像素数，并交叉校验 `src/pet.js` 的 `ANIM` 与 `src/pose-map.js` 引用的图片是否都存在（本次结果：13 个动作表、19 个姿势表全部存在，0 缺失）。
## 2.1.0 — 2026-10-27

**全部动作态与全部姿势都用真正独立绘制的帧**（不再有「同一张图加缩放/位移/旋转」的伪帧）。

### 动作态（13 张精灵表）

- `drag` / `think` / `work` / `sad` / `wink` 各补 2 帧真实重绘（原为单帧 + 程序化微动或三格伪帧），现全部 3 帧。
- 帧间轮廓 IoU 实测 0.49–0.93（伪帧会接近 1.0），构建产物内每帧内容独立。
- `sleep` / `joy` / `eat` / `play` / `welcome` / `wake` / `walk` 保持原始帧数不变（它们是随插件发布的原版美术，未重采样）。

### 姿势立绘（19 张，768×256 三格）

- 19 个姿势全部换成 3 帧独立绘制，帧间为真实相位变化（例如 `sweep` 站立→弯腰扫地→直身擦汗、`workRam` 手搭键盘→抬手→砸下、`night` 打哈欠→低头→抱枕入睡）。
- 逐帧做基线校验：帧高偏离同表中位数超过 12px 的离群帧按表内中位数重采样对齐（只修了 `drag` f1、`sad` f1、`night` f2），`sleep` 这类本来就矮的蜷睡姿态不做拉伸。
- 播放仍由 CSS `dwm-pose-cycle` 步进背景位置（0.9s 循环），叠加 `dwm-portrait-float` 浮动；减弱动效下钉在第 0 帧。

### 工程

- `build.mjs` 的 `SHEETS` 与 `src/pet.js` 的 `ANIM` 同步：`wink` 帧数 1 → 3。
- 生成管线脚本留在仓库外的 `_tmp/whale-gen/`（`gen_pose_frames.py`、`gen_action_frames.py`、`key_pose.py`、`compose_frames.py`、`conform_sheets.py`、`verify_frames.py`、`contact_sheet.py`），不进发布包。
## 2.0.1 — 2026-10-26

修掉 2.0.0 里三个能看见的问题，并补上 2.0.0 缺失的发布流程。

### 修复

- **点击部位漂移**：分区矩形是按 `idle` 第 0 帧量的，但每个姿势都在重画角色（刚性配准包络 `s 0.860–1.040 / dx −2..16 / dy −12.5..22` px），实测点击期望部位只有 **68.5%** 落到正确分区，`sleep` 上脸下半截会掉进 `belly` 兜底。现在 `dwmHitZone` 先用 33 行 `DWM_HIT_REG`（`状态#帧 → [s, dx, dy]`，按质心配准，`idle#0` 恰为恒等）把点击点映射回参考帧，再比对矩形；`feet` 矩形加宽到 `x 0.100–0.900`（y ≥ 0.900 无其它矩形，零歧义）。
- **松手压缩看不见**：`.dwm-3d.is-squash` 用 `animation` 简写覆盖了 sway 的 `transform`，压缩期间整只鲸鱼被拍平成 2D 且结束时跳帧。现在 squash 改动画独立 `scale` 属性，与 sway 的 `transform` 合成；`prefers-reduced-motion` 下压缩不再运行。
- **装饰层抢指针**：立绘本体 `.dwm-sprite` 原本是 `pointer-events: auto`，气泡被光晕盖住。现在装饰层全部 `none`、`.dwm-pop` 加 `z-index: 2`，立绘的减弱动效规则改用属性选择器（原兄弟选择器永不匹配，因为立绘挂在 `body` 上）。

### 工程

- 新增 `scripts/push.mjs`（`npm run push`）：构建 → 测试 → 同步两处安装目录 → 提交 → 带退避重试推送 main 与 tag → **用 `ls-remote` 回读校验远端 SHA 与 tag**，校验失败直接非零退出。
- 仓库级 git 配置 `http.version=HTTP/1.1`、`postBuffer=524288000`、`lowSpeedLimit/lowSpeedTime`，绕开本机到 github.com 的 HTTP/2 连接重置（`TLS connect error: … unexpected eof while reading`）。
- README 增加「推送排障（GitHub TLS）」一节。
# 变更记录

本项目遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## 2.0.0 — 2026-10-26

### 新增

- **按部位区分的互动台词**：可点击区由 3 个扩到 **9 个**（`horn` 呆毛 / `ear` 鳍耳 / `face` 脸 / `head` 头与头发 / `waist` 腰 / `hand` 手 / `belly` 围裙与腹 / `feet` 脚 / `tail` 鲸尾），一个矩形都没命中时回落到 `belly`。每个区用自己的新库**加上**原有的 `patHead` / `patBelly` / `patTail`，原有台词一句没删。新库在 `src/lines-parts.js`（`DWM_LINES_PARTS`，9 个库，每库 14 条中文 + 6 条英文，共 **180 条**）；区 → 库映射是 `src/zones.js` 的 `DWM_ZONE_BANK`，值改为数组，由 `dwmPickLineFrom` 合并抽取。
- **19 张姿势立绘改为 3 帧循环**：`src/sprites/poses/` 下的文件由单张 256×256 改为 **768×256** 三格横排，用与 `drag` / `think` / `work` / `sad` 相同的伪帧配方从原图生成（缩放 1.00 → 1.02、纵向偏移 0 → −2px、旋转 −1° → +1°，锚点脚底中心）。播放走 CSS `@keyframes dwm-pose-cycle`（`background-size: 300% 100%`，0.9 s 一轮），不占 JS 定时器；`prefers-reduced-motion` 下钉在第 0 帧。`dwmPortraitShow` 相应改为建 `div[data-dwm-portrait]` 背景图层，不再是 `<img>`。
- **动作与姿势预览画廊**（`src/preview.js`）：设置页里一格一个按钮的网格，动作状态点一下播 3 秒、姿势立绘播 4 秒，不必等对应场景出现。

### 修复

- **轻放不再甩出**：松手速度低于 `DRAG_LIGHT_SPEED` 时只播压扁，不位移。
- **压扁不再卡住、也不再压扁角色**：`.is-squash` 改由 `squash` 状态唯一写入、由 `SQUASH_MS`（320 ms）定时清除；压扁改走独立的 `scale` 属性，不再和 `dwm-sway` 争 `transform`。
- **第二次 `pointerdown` 不再抢拖动**：拖动进行中直接返回，不替换当前拖动、也不抢走 pointer capture。
- **立绘模式不再吃掉状态切换**：状态指令、点击、再次按下都会先 `restoreSprite()` 把舞台交还给精灵，新帧不会播在隐藏的 `.dwm-3d` 后面。
- **设置页合并成一个入口**：原本两个几乎同名的 `settings.section` 行合并为 `WhaleSettingsSection`，基础选项、陪伴面板、预览画廊上下排列。
- **分区命中矩形按立绘重新量过**：此前裙子一带会被判成尾巴。

## 1.9.0 — 2026-10-26

### 变更

- **资源改由 HTTP 路由提供**：精灵表与 19 张姿势立绘不再内联为 base64，改由 host 半边注册的 `/api/dsh-whale-maid/assets` 前缀路由提供（含路径穿越防护、MIME 表、`Cache-Control: max-age=3600`、弱 ETag + 304、仅 GET/HEAD）。`client.js` 从 **4.89 MB 降到 264 KB（−94.5%）**。
- **界面文案走翻译系统**：新增 `src/locale-table.js`（`dwmT` / `dwmFill` / `dwmLocaleLanguage`），`locale/zh.json` 与 `locale/en.json` 扩到 **81 个键**（19 个 `settings.*` + 60 个 `panel.*` + 2 个 `meta.*`）。原中英文作为回落参数保留，渲染结果逐节点一致。
- **气泡优先级**：`dwmSpeak(message, tone, priority)` 支持 `normal < state < important` 三级，高优先级未过期时不被低优先级打断。
- **工作状态判定更稳**：轮询由 1.5 s 放宽到 3 s，新增 `visibilitychange` 立即重扫；「运行标记消失但文档隐藏或设置页挂载」判为**保持**而非结束，`workHold` 仍是最终兜底。
- **场合→姿势映射**：新增 `src/pose-map.js`（36 条规则 + 15 条回落表），工作相位与关怀时刻改用对应立绘，无图时回落原动作态，既有转场不变。

### 新增

- `scripts/release.mjs`：一条命令完成 bump → build → test → 同步两处安装目录 → commit → tag。
- `assets/` 目录（构建产物，随包发布）。

### 修复

- 拖拽松手的甩出与压扁回弹此前只有算法没有接线（`.is-squash` 从未被添加、`.dwm` 变换缺 `--dwm-drag-angle`），现已接通。
- 设置页每 5 s 重读本地存储 → 改为 30 s 并在切回标签页时立即刷新。
- 松手回弹的定时器不再累积。
- 羁绊动作与称号取消等级门槛，默认全部可用，称号常显于面板首屏。

## 1.4.0 — 2026-10-26

工程与体感批次：把「四批计划」里所有不需要新美术的项做完，并加上存档导出/导入。

### 新增

- `engines.dsh: ">=0.2.1-rc.1"` 声明；`.github/workflows/ci.yml`（Node 20/22/24 构建 + 产物一致性 + 测试）。
- 无障碍：`Tab` 聚焦、`Enter`/`Space` 打招呼、`Alt+方向键` 16px 微调并持久化、`:focus-visible` 描边。
- 心情分层 2 → 5 档（`moodLow/Mid/LowMid/HighMid/High`），`moodTier()` 返回 0–4；新增 `src/lines-mood.js`（每语言 5 档 × 5 条）。
- 成就 41 → 55 条。
- 工作相位呼吸光晕 `.dwm-glow`（reduced-motion 下关闭）。
- 台词 546 → 600 条/语言。
- 唤回入口：`hidden` 开关 + 右下角 🐋 按钮。
- `locale/zh.json`、`locale/en.json` 改为 gettext 风格（43 条），设置面板文案可翻译。
- `src/portable.js`：`exportSave()` / `importSave()` / `clearSave()`，`schema = "dsh-whale-maid/save"`、`version = 1`，导入做 schema/version/键白名单校验。
- 测试：结构快照（`test/snapshots/pet-tree.txt`）、`dwm-` 类与 CSS 规则一致性检查、存档往返、心情档位、`hidden` 可逆、1.4.0 API 存在性。测试 28 → 34。

### 变更

- `scripts.test` 改用 `node --test --test-force-exit`（宠物自身持有定时器，进程不会自然退出）。
- `src/pet.css` 补上 `.dwm-panel-quest-text`、`.dwm-ach-name` 两条缺失规则。

### 暂缓（等美术 / 等口径）

- 19 张姿态立绘已生成并归一化到 `src/sprites/poses/`，**未接进状态机**——需要先定「场合 → 姿态」映射（待补充）。
- 五种形态切换、拖拽惯性物理、羁绊 Lv 解锁动作：等授权。
- 节日表、小游戏范围、TTS 播报细节、区县级天气精度：等口径。

## 1.3.0 — 2026-10-26

### 新增

- **天气陪伴**：Open-Meteo 免 key 接口，启动 / 每 30 分钟 / 跨天 / 窗口重新可见 / 手动按钮五种触发；缓存 + 6 小时过期降级；失败按 1→5→15 分钟指数退避重试（最多 3 次）。
- **天气 → 姿态 / 台词 / 粒子**：晴 `joy`、多云雾 `think`、雨雪雷 `sad`；7 个中文台词库共 63 条（含「雨夜」优先）；雨雪复用粒子层，晴天撒星屑；天气变化主动播报一次。
- **城市双路径**：系统定位（8 秒超时）失败后回退到设置里的城市名（默认北京），面板可随时改。
- 设置面板「鲸鱼女仆 · 成长」新增 **天气陪伴** 区块：城市 · 天气 · 温度 + 城市输入框 + 刷新按钮。
- 新配置项 `city`；新 API `weather()` / `refreshWeather()` / `setCity()`。
- 新增 `src/weather.js`、`src/lines-weather.js`，测试 22 → **28** 个。

### 变更

- `drag` / `think` / `work` / `sad` 由单帧改为 **3 帧伪帧**（缩放 1.00→1.02、上下 2px、旋转 ±1°，锚点脚底中心），十二个动作全部有逐帧动画；未新增任何美术。
- `client.js` 体积 2,401,140 → **3,161,926 B**（四张表各变三帧，精灵数据 1.66 → 2.22 MB）。

### 暂缓（等美术）

- 撑伞 / 缩脖子 / 发抖 / 流汗四种天气专属姿态；19 个新姿态立绘（已生成 `success`、`celebrate`，尚未接入）。

## 1.2.2 — 2026-10-26

修掉 1.2.1 里的致命回归：**点击宠物后整个桌宠消失**。

### 修复

- **点击即崩溃**（`ReferenceError: useState is not defined`）：1.2.1 新增的打字机气泡组件 `Bubble` 在模块作用域，但 React hook 别名 `var useState = React_.useState` 等声明在 `WhaleGirl()` 函数体内，作用域不可见 → 渲染气泡时抛错，`shell.overlay` 槽位整棵子树被卸载，桌宠消失（重载后复现）。现在 hook 别名提升到模块作用域。
- **气泡被挤成窄列**：`.dwm-pop` 是 110px 根节点里的 shrink-to-fit 绝对定位元素，长句会折成两行。现在按内容宽度布局，上限 250px（仍受视口宽度约束）。

### 测试

- 新增静态回归测试「hook aliases are hoisted above every component」：断言别名存在且声明位置在 `function Bubble` 之前。测试数 21 → 22。
## 1.2.1 — 2026-10-26

三个体验修复 + 一个气泡效果。**只增量**：包名、cordis row id、存储键、事件名、公开 API、`.dwm-*` 前缀、十状态精灵动画全部未改。

### 修复

- **走动被打断后会卡在走动帧里不再移动**：`stopWalk()` 此前只取消动画帧，姿态仍停在 `walk`，于是画面一直播走动帧、位置却不再变化。工作状态检测每 1.5 s 会主动中止散步（避免工作时乱走），正是最常见的触发路径。现在 `stopWalk()` 会把状态恢复成 `idle`。
- **点击时同时冒出两个气泡**：分区点击反应（头/肚子/尾巴）原来占用状态胶囊 `.dwm-chip`，和点击问候的对话气泡同时出现。现在分区反应改走对话气泡，且同一次点击里若分区已发声，就不再叠加随机问候——一次点击只说一句话。
- **原地踏帧的退化散步**：起点离边界过近时距离可能为 0，会闪一下走动帧。现在距离小于 8 px 直接放弃这次散步。

### 新增

- **气泡打字机效果**（`typewriter`，默认开启）：文字逐字显示并带闪烁光标；设置面板可关闭，`prefers-reduced-motion` 下自动整句显示。
## 1.2.0 — 2026-10-26

新增两张专属姿态，替掉 1.1.0 里的「借图」。**纯增量**：原有十张精灵表、十状态语义、四种播放模式、包名、cordis row id、`dsh-whale-maid:*` 存储键与事件名、`window.dshWhaleMaid` 既有方法、`.dwm-*` 前缀与 `--dwm-*` 变量全部未改。

### 新增

- **`work` 姿态**（`src/sprites/work.png`，1 帧，`loop + float`）：双手敲半透明浅蓝全息面板，头微低、眉心微蹙。工具 `preparing` / `running` 相位显示，不再借 `play`。
- **`sad` 姿态**（`src/sprites/sad.png`，1 帧，`loop`）：垂肩、双手身前交叠、上眼睑下垂、眉心内侧上挑、嘴角下撇、太阳穴一滴汗。工具报错 / 任务失败 / 心情触底显示，不再借 `drag`。
- **`dwmPlaySequence(steps)`**（`src/signals.js`）：姿态序列播放的统一入口，优先 `DWM_RUNTIME.api.runSequence`，宠物未挂载时回退 `dwmForceState` 并仍广播 `dsh-whale-maid:state`。

### 变更

- `src/signals.js`：`dwmWorkPose` 映射改为 `tool → work`、`failure → sad`；会话结束分支由 `[['drag', 2000]]` 改为 `[['sad', 2000]]`，成功分支改走 `dwmPlaySequence([['joy', 1500]])`。
- `src/pet.js`：`ANIM` 增 `work` / `sad` 两项（十状态 → 十二状态，索引与语义不变）。
- `build.mjs`：`SHEETS` 增 `work: 1`、`sad: 1`，构建时照旧校验每张表 `width === frames × 256`、`height === 256`。

### 体积

- `client.js` 由 2,189,669 B 增至 **2,361,079 B**（两张新图共 128,050 B，base64 内联后 +171,410 B）。

### 测试

- `test/companion.test.mjs` 增 2 个用例：运行中的工具切 `work`、新错误切 `sad`，并断言不再出现 `play` / `drag`。合计 **20 个用例全部通过**。

## 1.1.0 — 2026-10-25

新增陪伴层。**纯增量**：包名、cordis row id、`dsh-whale-maid:*` 存储键与事件名、`window.dshWhaleMaid` 既有方法、`.dwm-*` 类前缀、`dwm-*` 关键帧、`--dwm-*` 变量、十状态 `ANIM` 表与四种播放模式语义全部未改；关掉全部新开关后行为与 1.0.0 一致。

### 新增

- **工作状态联动**（`src/signals.js`）：观察宿主 DOM（`[data-chat-running]` / `[data-tool][data-state]` / `[data-variant="think"]`），判定 `thinking → tool → success/failure`，自动切 `think` 姿态、在宠物左侧冒状态小标签、工作期按话痨/安静两档说话、收尾欢呼或安慰；用 `workHold` 宽限期兜住「切到设置页导致信号消失」；用计数基线区分「新错误」与「历史错误卡残留」。
- **成长系统**（`src/growth.js`）：心情 / 饱食 / 好感 / 等级 / 陪伴时长 / 连续签到 / 每日任务 3 槽 / 41 项成就 / 成长日记，全部只写本机 `localStorage['dsh-whale-maid:growth']`。
- **台词与话题**（`src/lines.js`）：中英各约 260 句原创台词（问候、闲聊、工作态、关怀、分区点击、情绪分层），13 组关键词反应，13 类话题分类。
- **主动关怀**（`src/care.js`）：久坐 25 分钟、卡住 8 分钟、深夜 23:00–5:59、饿了、离开后回来，最小间隔 15 分钟；另有 5–8 分钟一次主动闲聊。
- **分区点击**（`src/zones.js`）：头顶 / 肚子 / 尾巴三个归一化命中区，各自台词与粒子；1.2 秒内三连击触发庆祝。不 `preventDefault`、不 `stopPropagation`，原有点击/拖动/菜单逻辑一行未动。
- **状态小标签与粒子层**（`src/fx.js`）：`.dwm-chip` 与 `.dwm-fx` 两个独立图层，四类粒子（heart / star / sparkle / note）。
- **设置页「鲸鱼女仆 · 成长」分区**（`src/panel.js`，`order: 61`）：等级与羁绊称号、三条进度条、每日任务领取、本周签到、成就墙、成长日记、九个陪伴开关、四个试玩按钮。原「鲸鱼女仆」分区完全未改。
- **公开 API 追加**（均为新增键，旧键签名不变）：`companion` / `setCompanion` / `growth` / `signin` / `claimQuest` / `resetGrowth` / `work` / `scanNow` / `diagnose` / `zoneAt` / `probe` / `chip` / `fx` / `pose`；`forget()` 现在也会清 `:growth` 与 `:companion`。
- **测试**：`test/companion.test.mjs`，18 个 `node:test` 用例，把真实 `client.js` 载进 stub DOM 跑真实 `apply(ctx)`。`npm test` 即 `node --test test/companion.test.mjs`。

### 变更

- `client.js` 体积 2 090 695 B → 2 189 669 B（新增陪伴层代码，精灵图未变）。
- `package.json` 版本 1.0.0 → 1.1.0，新增 `scripts.test`。

### 未纳入

参考实现里的五种形态切换、拖拽惯性物理、TTS 播报、天气陪伴、三个小游戏、跨端存档迁移、唤回入口按钮——原因见 README「未纳入的功能」：前两项需要改既有行为，其余与「零依赖 / 零网络 / 只写本机」的口径冲突。

## 1.0.0 — 2026-10-25

首个发布版本。

- 从 DeepSeek 插件市场页面提取鲸鱼女仆桌宠，1:1 移植十状态精灵动画状态机：
  `idle`（随机眨眼）、`joy`、`eat`、`play`、`welcome`、`drag`（摇摆）、`think`（浮动）、
  `sleep`、`wake`、`walk`（乒乓漫步）
- 交互：单击问候并展开菜单、拖动换位（6px 判定阈值）、喂食、玩耍、爱心飘出、`Esc`/点空白关闭菜单
- 自动行为：空闲思考、随机漫步、60 秒无交互入睡、点击唤醒
- 位置、投喂数、已问候标记持久化到 `localStorage`
- 设置页「鲸鱼女仆」分区：尺寸、动画速度、气泡停留时长、气泡语言、问候/漫步/睡眠开关
- 公开 API：`window.dshWhaleMaid`（`getOptions` / `setOptions` / `say` / `resetPosition` / `feeds` / `forget`）
- 样式变量桥接到 DSH 主题 token（`--dsw-alias-*`），深色/浅色主题自适应
- 高光层改用当前精灵帧做 `mask-image`，修复深色主题下角色背后出现浅色圆角方块的问题
- 所有选择器作用域提升到 `.dwm-root`，避免被宿主 `button[attr]` 规则覆盖
- 精灵图 base64 内联进 `client.js`，无静态资源路由、无网络请求、无第三方依赖
- 支持 `prefers-reduced-motion`
