/**
 * dsh_tui commands module CORE: the messaging/input chains and the module
 * wiring that every command file shares — send / followup / input routing /
 * model switching / @-completion / the nvim-notification + host-event
 * registrations / the tui_command agent tool. Command DEFINITIONS live in
 * commands/*.ts (one file per command, self-registering); the module index
 * (index.ts) only assembles.
 *
 * @module dsh-nvim-tui/commands
 */
import { appendFileSync, readdirSync } from 'node:fs'
import { randomUUID } from 'node:crypto'
import { isAbsolute, join } from 'node:path'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { locale, t, tf } from '../kernel/i18n.js'
import { settlePrompt } from '../kernel/prompt.js'
import { runOfficialCommand } from './commands/official-commands.js'
import { matchIntent } from './nlcmd.js'
import { activeSessionCwd, type ApprovalRecord } from '../kernel/app.js'
import { appendApproval, APPROVAL_HISTORY_MAX, ensureApprovalHistory } from '../kernel/approval-log.js'
import { routeDifficultyForTurn } from '../kernel/difficulty.js'
import { findVisionModel, effortSupported } from '../kernel/vision.js'
import { readClipboardImage, splitImageDataUrls, parseImageDataUrl } from '../feed/images.js'
import { queueSubagentPromptKey } from '../kernel/types.js'
import type { ApprovalRequest, FileAttachmentRef, InboxLike, LlmService, MessageContent, SaveImageAttachment } from '../kernel/types.js'
import type { AppSlices, WritableSlice } from '../kernel/app.js'
import { registerHostHandler } from '../kernel/host-events.js'
import { registerNvimNotification } from '../kernel/rpc.js'
const W = (d: AppSlices['agent']) => d as WritableSlice<AppSlices['agent']>
import type { App, ModelRef, SessionRec } from '../kernel/app.js'
import { skillsCommand } from './commands/skills.js'

/**
 * Send a user message with optional image attachments.
 * `images` entries are SaveImageAttachment-shaped (`{data, mediaType, name}`)
 * — read from a local file (/image) or parsed from pasted data URLs. They
 * are durably committed through the harness `attachments` service so the
 * message content carries only stable image refs; the LLM adapter resolves
 * them into data URLs at request time.
 * agent.followup() ENQUEUES a next-turn message and wakes the driver: a
 * running turn is never interrupted — the input is processed as a later
 * turn of the same drain.
 */
export const followup = async (app: App, rec: SessionRec, text: string, images?: Array<SaveImageAttachment | Extract<MessageContent, { type: 'image' }> | string>, files?: FileAttachmentRef[]) => {
  if (app.slices.runtime.disposed || rec === undefined) return
  if ((text ?? '').trim() === '' && (images === undefined || images.length === 0) && (files === undefined || files.length === 0)) return
  // Surface the queueing so the message doesn't look lost. (Use /btw to
  // fork a side session instead.)
  if (rec.status !== undefined && rec.status.startsWith('● running')) {
    app.slices.ui.activeFeed()?.appendNotice(t('已排队：当前回合结束后处理'))
  }
  // 难度路由（M1-M3）：发送前按难度切换本会话模型，回合结束自动切回。
  // 内部兜底，失败不阻断发送。
  if (rec.difficulty !== undefined && rec.modelRef !== undefined) {
    await routeDifficultyForTurn(app, rec, text, (images?.length ?? 0) > 0)
  }
  if (images !== undefined && images.length > 0 && (text ?? '').trim() === '') {
    text = t('📎 图片消息')
  }
  if (files !== undefined && files.length > 0 && (text ?? '').trim() === '') {
    text = t('📎 文件消息')
  }
  const content: MessageContent[] = [{ type: 'text', text }]
  for (const file of files ?? []) content.push({ type: 'file', attachment: file })
  if (images !== undefined && images.length > 0) {
    const attachments = app.svc('attachments')
    if (attachments === undefined) {
      app.notice(t('图片发送需要 attachments 服务（attachment-local 未装配）'))
      return
    }
    // 官方识图路径：当前模型声明 image 输入 → 直接发送；否则临时切换到
    // 官方识图模型（0.1.5 默认目录里的 deepseek-flash / deepseek-v4-flash-
    // vision-exp，以及自定义目录里任意声明 image 的模型），回合结束自动
    // 切回原模型（boot.ts 的 turn/end 恢复）。目录里没有任何带 image
    // 模态的模型时 fail fast——不要让回合死在适配器里（UNSUPPORTED_CONTENT）。
    const llm = app.runtimeCtx.get('llm') as LlmService | undefined
    // The model THIS turn will actually run is the session's active selection
    // (difficulty routing may have switched it away from the global default).
    const sel = { ...(rec.modelRef.current ?? app.slices.agent.currentSelection()) }
    const curInfo = await llm?.resolveModelInfo(sel.provider, sel.model).catch(() => undefined)
    if (curInfo?.inputModalities?.includes('image') !== true) {
      const visionModel = await findVisionModel(app, sel.provider)
      if (visionModel === undefined) {
        app.notice(t('没有可用的官方识图模型（settings.yaml 的 llm-deepseek.models 需包含声明 image 模态的模型，如 deepseek-flash 或 deepseek-v4-flash-vision-exp）'))
        return
      }
      // The vision model may not accept the current reasoning effort — the
      // host throws UNSUPPORTED_REASONING_EFFORT before the adapter even sees
      // the image, so drop an unsupported effort for this turn.
      const vInfo = await llm?.resolveModelInfo(sel.provider, visionModel).catch(() => undefined)
      const keepEffort = effortSupported(vInfo as { reasoning?: { efforts?: ReadonlyArray<{ id?: string }> } } | undefined, sel.reasoningEffort)
      rec.modelRef.current = keepEffort ? { ...sel, model: visionModel } : { provider: sel.provider, model: visionModel }
      rec.visionTmp = { prev: sel, switchAt: Date.now() }
      // An active difficulty switch must survive past THIS image turn too:
      // its turn/end restore would otherwise clobber the vision switch and
      // the image turn would run on the restored text model.
      if (rec.difficulty !== undefined && rec.difficulty.tmp !== null) {
        rec.difficulty.tmp.switchAt = Date.now()
      }
      app.notice(`📎 图片消息: 临时切换官方识图模型 ${sel.provider}/${visionModel}${keepEffort ? '' : `（该模型不支持 ◎${sel.reasoningEffort}，本回合按模型默认）`}（回合结束自动切回 ${sel.provider}/${sel.model}）`)
      app.slices.ui.updateStatusline()
    } else if (rec.visionTmp !== null) {
      // Another image message queued while an image turn is still pending:
      // extend the switch window so the restore happens after THIS turn too
      // (otherwise the second image turn runs on the restored text model).
      rec.visionTmp.switchAt = Date.now()
    }
    const max = attachments.imageLimits?.maxImagesPerMessage ?? 4
    if (images.length > max) {
      app.notice(tf('最多附带 {0} 张图片，已截断', [max]))
      images = images.slice(0, max)
    }
    try {
      for (const img of images) {
        // Already-durable attachment refs (queued via /attach) pass through;
        // raw images (clipboard / parsed data URLs) are saved here.
        const existing = (img as { attachment?: unknown } | undefined)?.attachment
        if (existing !== undefined) {
          content.push({ type: 'image', attachment: existing })
          continue
        }
        const saved = await attachments.saveImage(img as SaveImageAttachment)
        content.push({ type: 'image', attachment: saved })
      }
    } catch (err) {
      // Roll the temporary vision switch back so a failed attach never
      // leaves the session parked on the vision model.
      if (rec.visionTmp !== null) {
        const prev = rec.visionTmp.prev
        rec.modelRef.current = prev
        rec.model = prev.model
        rec.visionTmp = null
        app.slices.ui.updateStatusline()
      }
      app.notice(tf('图片附加失败: {0}', [(err as Error).message]))
      return
    }
  }
  try {
    rec.handle.agent.followup(createUserMessage({
      content: content as never,
      source: { kind: 'user' },
    }))
  } catch (err) {
    app.notice(tf('发送失败: {0}', [(err as Error).message]))
  }
}

/**
 * Queue one human prompt to a continuable child through the official
 * symbol-keyed host prompt queue (Symbol.for('dsh.subagent.queuePrompt')).
 * The dsh-subagent service exposes NO public followup method — this face
 * is the host-only queue: (parent, childId, content, source, signal) →
 * inbox MessageId. Running children admit it as their next turn after the
 * current one converges; settled children cold-resume.
 */
export const queueSubagentPrompt = async (app: App, parentAgent: unknown, childId: string, text: string) => {
  const subagentsSvc = app.svc('subagents')
  // 0.1.5 public face: `subagents.prompt({requestId, parentSessionId,
  // childSessionId, mode:'continuable', delivery:'queue', content}, signal)`.
  if (typeof subagentsSvc?.prompt === 'function') {
    await subagentsSvc.prompt({
      requestId: randomUUID(),
      parentSessionId: (parentAgent as { session?: { id?: string } } | undefined)?.session?.id ?? '',
      childSessionId: childId,
      mode: 'continuable',
      delivery: 'queue',
      content: [{ type: 'text', text }],
    }, AbortSignal.timeout(30000))
    return
  }
  // pre-0.1.5 face: the symbol-keyed queue method on the service instance.
  const fn = subagentsSvc?.[queueSubagentPromptKey]
  if (typeof fn !== 'function') {
    throw new Error(t('子代理续聊不可用（subagents 服务未装配）'))
  }
  // The symbol-keyed method reads `this` internally (requireContinuations,
  // etc.) — invoke it BOUND to the service instance, never as a detached
  // function (an unbound call crashes with "Cannot read properties of
  // undefined (reading 'requireContinuations')").
  await (fn as (...args: unknown[]) => Promise<unknown>).call(
    subagentsSvc,
    parentAgent,
    childId,
    [{ type: 'text', text }],
    { kind: 'user' },
    AbortSignal.timeout(30000),
  )
}

export const send = (app: App, text: string) => {
  if (app.slices.runtime.disposed) return
  const rec = app.slices.sessions.activeId === null ? undefined : app.slices.sessions.live.get(app.slices.sessions.activeId)
  if (!rec) {
    app.slices.agent.pendingInput.push(text)
    return
  }
  // /subagents → 继续对话: this input line goes to the continuable child
  // through the official host prompt queue (parent-authority check
  // built in) instead of the main agent.
  if (app.slices.agent.pendingSubagentFollowup !== null) {
    const target = app.slices.agent.pendingSubagentFollowup
    W(app.slices.agent).pendingSubagentFollowup = null
    void (async () => {
      try {
        await queueSubagentPrompt(app, rec.handle.agent, target.childId, text)
        app.notice(tf('已发送给子代理 {0}: {1}', [target.label, text.slice(0, 60)]))
      } catch (err) {
        app.notice(tf('子代理续聊失败: {0}', [(err as Error).message]))
      }
    })()
    return
  }
  // Pasted data URLs become image attachments; the URL text is stripped.
  // URLs are parsed into the SaveImageAttachment contract ({data,mediaType})
  // BEFORE followup — the attachments service receives bytes, never strings.
  const { text: clean, images } = splitImageDataUrls(text)
  const parsed: Array<SaveImageAttachment> = []
  for (const url of images) {
    const p = parseImageDataUrl(url)
    if (p !== null) parsed.push(p)
  }
  // Clipboard images queued via <C-v> ride along with the submitted text.
  const all = [...parsed, ...app.slices.agent.pendingImages]
  const files = [...app.slices.agent.pendingFiles]
  W(app.slices.agent).pendingImages = []
  W(app.slices.agent).pendingFiles = []
  void followup(app, rec, clean, all, files)
}

/** <C-v> handler: queue the macOS clipboard image for the next submit. */
export const pasteClipboardImage = (app: App) => {
  const rec = app.slices.sessions.activeId === null ? undefined : app.slices.sessions.live.get(app.slices.sessions.activeId)
  if (!rec) {
    app.notice(t('无活跃会话'))
    return
  }
  if (process.platform !== 'darwin') {
    app.notice(t('剪贴板读图仅支持 macOS（请用 /image <路径>）'))
    return
  }
  // pbpaste -Prefer public.png/tiff: plain pbpaste only returns the
  // clipboard TEXT, which is empty for an image copied with Cmd+C.
  const image = readClipboardImage()
  if (image === null) {
    app.notice(t('剪贴板里没有图片（截图/复制图片后按 C-v）'))
    return
  }
  app.slices.agent.pendingImages.push(image)
  app.notice(tf('📎 已附加剪贴板图片（共 {0} 张，回车随消息发送；/image clear 清空）', [app.slices.agent.pendingImages.length]))
}

/** /stop — abort the active turn (agent.cancel with a user cause). */
export const stopCommand = (app: App) => {
  const rec = app.slices.sessions.activeId === null ? undefined : app.slices.sessions.live.get(app.slices.sessions.activeId)
  if (!rec) {
    app.notice(t('无活跃会话'))
    return
  }
  if (rec.status !== '● running') {
    app.notice(t('没有运行中的回合'))
    return
  }
  try {
    rec.handle.agent.cancel({ kind: 'user' })
    rec.feed.appendNotice(t('⏹ 已请求停止当前回合'))
  } catch (err) {
    app.notice(tf('停止失败: {0}', [(err as Error).message]))
  }
}

/** Directory picker promise (Lua navigable float → 'dsh-dir-selected'). */
export const openDirPicker = (app: App, startPath: string): Promise<string | null> => new Promise((resolve) => {
  if (app.slices.agent.dirSettle !== null) app.slices.agent.resolveDirPicker(null)
  W(app.slices.agent).dirSettle = resolve
  void app.luaCall('require("dsh_tui").show_dir_picker(...)', [startPath ?? process.cwd()])
    .catch(() => { W(app.slices.agent).dirSettle = null; resolve(null) })
})

/** Format an @-mention: quote paths containing whitespace. */
export const formatMention = (path: string): string => (/\s/.test(path) ? `@"${path}"` : `@${path}`)

/** Local fs candidates (fallback when the fileReferences service is
 *  absent): immediate children of the query's dir matching its prefix. */
export const localFileCandidates = async (cwd: string, query: string): Promise<Array<{ path: string; mention: string }>> => {
  const q = (query ?? '').replace(/^["']/, '')
  const slash = q.lastIndexOf('/')
  const dirPart = slash >= 0 ? q.slice(0, slash + 1) : ''
  const namePart = slash >= 0 ? q.slice(slash + 1) : q
  const base = isAbsolute(q) ? '' : cwd
  const dirPath = join(base, dirPart || '.')
  const out = []
  try {
    for (const name of readdirSync(dirPath, { withFileTypes: true })) {
      if (namePart !== '' && !name.name.startsWith(namePart)) continue
      const rel = (dirPart + name.name + (name.isDirectory() ? '/' : ''))
      out.push({ path: rel, mention: formatMention(rel) })
    }
  } catch {}
  out.sort((x, y) => x.path < y.path ? -1 : 1)
  return out.slice(0, 50)
}

/** @-completion query from the input line (dsh-at-query notify).
 *  Files first, then @session references (the official client's unified
 *  `@file`/`@session` source, in the same deterministic order). */
export const atQuery = async (app: App, query: string, start = 0): Promise<void> => {
  const rec = app.slices.sessions.activeId === null ? undefined : app.slices.sessions.live.get(app.slices.sessions.activeId)
  const agent = rec?.handle.agent
  let items: Array<{ path: string; mention: string }> = []
  const atSignal = AbortSignal.timeout(4000)
  try {
    const fr = app.svc('fileReferences')
    if (typeof fr?.list === 'function' && agent) {
      const cands = await fr.list(agent, query, atSignal)
      items = (cands ?? []).map((c) => ({ path: c.path, mention: formatMention(c.path) }))
    }
  } catch (err) {
    // A THROWING service (index still building, permissions, host error) used
    // to leave the menu silently empty while a MISSING service degraded to
    // the local scan — same symptom, opposite handling. Diagnose, then fall
    // through to the scan below.
    app.exitDiag('at-query-service', (err as Error).message)
  }
  if (items.length === 0) {
    try {
      items = await localFileCandidates(activeSessionCwd(app), query)
    } catch (err) {
      app.exitDiag('at-query-local-scan', (err as Error).message)
    }
  }
  const sessionRef = app.svc('sessionReferenceResolver')
  if (agent !== undefined && typeof sessionRef?.listCandidates === 'function') {
    try {
      const cands = await sessionRef.listCandidates(agent, query, 8, atSignal)
      for (const c of cands) {
        // Canonical mention: @[label](dsh-session:<base64url(JSON id)>).
        const uri = 'dsh-session:' + Buffer.from(JSON.stringify(c.sessionId), 'utf8').toString('base64url')
        const label = (c.label ?? c.sessionId).replace(/[\[\]]/g, '\\$&')
        items.push({
          path: `💬 ${label}${c.cwd !== undefined && c.cwd !== '' ? ` · ${c.cwd}` : ''}`,
          mention: `@[${label}](${uri})`,
        })
      }
    } catch {}
  }
  await app.luaCall('require("dsh_tui").set_at_menu(...)', [items, start]).catch(() => {})
}

export const onInput = (app: App, text: string): void => {
  // Queue edit flow: the next submitted line REPLACES the queued message
  // (official client's per-row edit action).
  if (app.slices.agent.pendingQueueEdit !== null) {
    const target = app.slices.agent.pendingQueueEdit
    W(app.slices.agent).pendingQueueEdit = null
    const rec = app.slices.sessions.activeId === null ? undefined : app.slices.sessions.live.get(app.slices.sessions.activeId)
    const inbox = rec?.handle.agent.inbox as InboxLike | undefined
    const text0 = text.trim()
    if (text0 === '' || typeof inbox?.replace !== 'function') {
      app.notice(t('已取消编辑（空输入或 inbox 不可用）'))
      return
    }
    try {
      const replaced = inbox.replace(target.messageId, createUserMessage({
        content: [{ type: 'text', text: text0 }],
        source: { kind: 'user' },
      }))
      app.notice(replaced === true ? t('排队消息已更新') : t('该消息已被处理，无法再编辑'))
    } catch (err) {
      app.notice(tf('编辑排队消息失败: {0}', [(err as Error).message]))
    }
    return
  }
  // Row-action rename flow: the next submitted line IS the new name
  // (the terminal counterpart of the web's rename dialog).
  if (app.slices.agent.pendingRename !== null) {
    const target = app.slices.agent.pendingRename
    W(app.slices.agent).pendingRename = null
    const name = text.trim()
    if (name === '') {
      app.notice(t('已取消重命名（空输入）'))
      // A background-resumed session (rename row action) must not linger.
      if (target.kind === 'session' && target.background === true) void app.slices.sessions.disposeLiveSession(target.id)
      return
    }
    void (async () => {
      try {
        if (target.kind === 'workspace') {
          const ws = app.svc('workspaceRegistry')
          const ent = ws?.list?.().find((w) => w.id === target.id)
          if (ent?.setTitle === undefined) { app.notice(t('工作区重命名不可用（workspaceRegistry 服务未装配）')); return }
          await ent.setTitle(name)
          app.notice(tf('工作区已重命名: {0}', [name]))
        } else {
          const sessionTitle = app.svc('sessionTitle')
          if (sessionTitle === undefined) { app.notice(t('session-title 服务未装配')); return }
          const live = app.liveSessions.get(target.id)
          if (live === undefined) { app.notice(t('会话已不在线（可能已退出或未成功恢复），无法重命名')); return }
          sessionTitle.rename(live, name)
          app.notice(t('会话标题已更新'))
          // Release the temporary live session the row action resumed.
          if (target.background === true) void app.slices.sessions.disposeLiveSession(target.id)
        }
      } catch (err) {
        app.notice(tf('重命名失败: {0}', [(err as Error).message]))
        if (target.kind === 'session' && target.background === true) void app.slices.sessions.disposeLiveSession(target.id)
      }
    })()
    return
  }
  const trimmed = text.trim()
  if (!trimmed) return
  // Natural-language command routing: plain lines that clearly match a
  // slash-command intent run that command (echoed into the feed); '>'
  // prefixes force chat, questions always go to the agent.
  const nl = matchIntent(trimmed)
  if (nl !== null) {
    if (nl.loose === true) {
      // AMBIGUOUS noun match: the agent decides — the message carries a
      // routing hint and the tui_command tool executes the command when
      // the user really wanted one. Instant routing stays for slash
      // commands, patterns and exact phrases.
      const nlRec = app.slices.sessions.activeId === null ? undefined : app.slices.sessions.live.get(app.slices.sessions.activeId)
      if (nlRec === undefined) { send(app, trimmed); return }
      const candidate = `/${nl.name}${nl.arg !== undefined ? ` ${nl.arg}` : ''}`
      const hint = tf('（TUI 操作判定：这句话可能是想执行命令 {0}。若确实如此，请调用 tui_command 工具；若只是聊天提问，请正常回答，不要调用工具。）\\n{1}', [candidate, trimmed])
      nlRec.feed.pushUser(hint, [])
      const q = app.slices.ui.pendingEchoes.get(app.slices.sessions.activeId as string) ?? []
      q.push(hint)
      if (q.length > 16) q.shift()
      app.slices.ui.pendingEchoes.set(app.slices.sessions.activeId as string, q)
      void followup(app, nlRec, hint)
      return
    }
    const nlRec = app.slices.sessions.activeId === null ? undefined : app.slices.sessions.live.get(app.slices.sessions.activeId)
    nlRec?.feed.appendNotice(`→ 命令: /${nl.name}${nl.arg !== undefined ? ` ${nl.arg}` : ''}`)
    onCommand(app, `/${nl.name}${nl.arg !== undefined ? ` ${nl.arg}` : ''}`)
    return
  }
  const echoRec = app.slices.sessions.activeId === null ? undefined : app.slices.sessions.live.get(app.slices.sessions.activeId)
  const split = splitImageDataUrls(trimmed)
  if (echoRec !== undefined && app.slices.agent.pendingImages.length === 0 && app.slices.agent.pendingFiles.length === 0 &&
    split.images.length === 0) {
    // Echo the CLEANED text — the EXACT string the host will store and
    // replay. Echoing the pre-collapse draft desyncs the dedupe queue on
    // any run of spaces/tabs (indented multi-line fullscreen drafts) and
    // the replay renders a second, slightly different bubble.
    echoRec.feed.pushUser(split.text, [])
    const q = app.slices.ui.pendingEchoes.get(app.slices.sessions.activeId as string) ?? []
    q.push(split.text)
    if (q.length > 16) q.shift()
    app.slices.ui.pendingEchoes.set(app.slices.sessions.activeId as string, q)
  }
  send(app, trimmed)
}

export const applyModelSelection = async (app: App, next: ModelRef['current']): Promise<void> => {
  const rec = app.slices.sessions.activeId === null ? undefined : app.slices.sessions.live.get(app.slices.sessions.activeId)
  if (rec?.modelRef) rec.modelRef.current = next // hot for the active session
  if (rec) {
    rec.model = next.model
    // 手动 /model = 明确意图：暂停该会话的自动难度路由（/difficulty auto 恢复）。
    if (rec.difficulty !== undefined) {
      rec.difficulty.enabled = false
      rec.difficulty.pinned = null
      rec.difficulty.pending = null
      rec.difficulty.tmp = null
      rec.difficulty.tier = null
      rec.difficulty.source = null
    }
    // 识图回合挂起时手动换模型：清掉恢复标记，避免回合结束用旧 prev
    // 覆盖手动选择。
    rec.visionTmp = null
  }
  await app.runtimeCtx.agentDefaultModel.saveSelection(next) // persist default
  app.notice(`模型已切换: ${next.provider}/${next.model}${next.reasoningEffort ? ` (${next.reasoningEffort})` : ''}${rec?.difficulty !== undefined ? t('（已暂停自动难度路由，/difficulty auto 恢复）') : ''}`)
  app.slices.ui.updateStatusline()
}

/**
 * Append one settled approval to the bounded decision log.
 *
 * Best-effort on purpose: the history is a nicety, and it runs inside the
 * approval settle path — a throw here would strand the host waiting for a
 * decision that was in fact already made.
 */
const recordApproval = (app: App, request: { toolName?: string; reason?: string; agent?: { session?: { id?: string } } }, outcome: string): void => {
  try {
    const rec: ApprovalRecord = {
      at: Date.now(),
      toolName: request?.toolName ?? '?',
      reason: request?.reason ?? '',
      outcome,
      sessionId: request?.agent?.session?.id,
    }
    // Keyed by the REQUEST's session, not the active one: a background/child
    // agent can ask for approval while another session is in the foreground, and
    // that decision belongs to the session that asked.
    const sid = rec.sessionId
    const hist = ensureApprovalHistory(app.slices.agent, sid) as ApprovalRecord[]
    hist.push(rec)
    // Bounded: a long session asks hundreds of times, and this array is read
    // only by /approvals — never let it grow without limit.
    if (hist.length > APPROVAL_HISTORY_MAX) hist.splice(0, hist.length - APPROVAL_HISTORY_MAX)
    // …and persist it. The in-memory array dies with the process, which is
    // precisely when "why did I allow that?" gets asked — `/approvals` used to
    // come back empty after every restart.
    appendApproval(sid, rec)
  } catch { /* cosmetic */ }
}

export const onCommand = (app: App, line: string): void => {
  if (line.startsWith('/skills:')) {
    void skillsCommand(app, line.slice('/skills:'.length).trim())
    return
  }
  const m = line.match(/^(\S+)(?:\s+(.*))?$/)
  const name = m?.[1] ?? ''
  const rest = m?.[2] ?? ''
  const spec = app.commandSpecs.find((s) => s.name === name)
  if (spec) {
    // Command fns are async (pickers, session resume, model switch…):
    // a rejection here must surface as a notice + log line — in alpha.4
    // the host's fail-loud turns ANY unhandledRejection into a hard
    // process.exit, which is exactly how "选择会话 → dsh 整个退掉" 表现.
    void Promise.resolve()
      .then(() => spec.fn(rest))
      .catch((err: unknown) => {
        const e = err as Error | undefined
        try {
          appendFileSync(app.errorLogPath,
            `${new Date().toISOString()} 命令 ${name}: ${e?.stack ?? String(err)}\n`)
        } catch {}
        app.notice(tf('⚠ {0} 失败: {1}', [name, e?.message ?? String(err)]))
      })
  } else {
    // Not one of OURS — but it may be registered in the OFFICIAL registry by a
    // plugin (`ctx.commands`, e.g. dsh-knowledge-base's `/kb`). Discovery alone
    // was not enough: `/commands` could list it while typing it still said
    // "unknown command", because this path never asked the registry.
    void (async () => {
      const rec = app.slices.sessions.activeId === null
        ? undefined
        : app.slices.sessions.live.get(app.slices.sessions.activeId)
      if (rec !== undefined) {
        const accepted = await runOfficialCommand(app, rec.handle.agent, line)
        if (accepted) return
      }
      app.notice(tf('未知命令 {0}（/help 查看可用命令）', [name || line]))
    })().catch((err: unknown) => {
      app.notice(tf('⚠ {0} 失败: {1}', [name, (err as Error).message]))
    })
  }
}

export const TUI_COMMAND_WHITELIST = new Set([
  '/help', '/sessions', '/subagents', '/panel', '/plugins', '/todo',
  '/goal', '/status', '/context', '/cost', '/queue',
  '/deliverables', '/workflow', '/locale', '/whale', '/skills',
  '/dir', '/lines', '/history', '/btw', '/model', '/effort', '/plan',
  '/tasks',
  // NOT whitelisted: /settings (agent could rewrite settings.yaml via
  // `/settings set <ns> <key> <value>`), /memory (agent could delete
  // project memory via `/memory delete <id>`) — the tool contract says
  // destructive actions stay out of reach.
])

/** Register the agent-side tui_command routing tool (whitelisted UI/safe
 *  commands only — quit/fork/rewind/archive and destructive actions stay
 *  out of reach). */
export function registerTool(app: App): void {
  const toolsSvc = app.ctx.get('tools') as { register?: (tool: unknown) => unknown } | undefined
  if (typeof toolsSvc?.register === 'function') {
    try {
      const safeSpecs = app.commandSpecs.filter((sp) => TUI_COMMAND_WHITELIST.has(sp.name))
      void Promise.resolve(toolsSvc.register(defineTool({
        name: 'tui_command',
        description: [
          'Execute a TUI (terminal UI) command for the user.',
          'Call this ONLY when the user\'s message is a request to operate the TUI itself',
          '(open a panel, list sessions/subagents/plugins, view goal/memory/status/context/cost,',
          'manage the todo list, switch model/effort/plan/locale, browse directories…) —',
          'never for coding questions, file edits, or general conversation.',
          'Commands: ' + safeSpecs.map((sp) => sp.name + (sp.desc ? ' — ' + sp.desc : '')).join('; '),
        ].join(' '),
        parameters: {
          command: {
            type: 'string',
            required: true,
            description: 'command name (WITHOUT the leading slash), one of: ' + safeSpecs.map((sp) => sp.name.slice(1)).join(', '),
          },
          args: {
            type: 'string',
            description: 'optional command argument (e.g. a model id for /model, task text for /todo)',
          },
        },
        output: {
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              executed: { type: 'boolean', required: true },
              command: { type: 'string', required: true },
            },
          },
          render: (_args, value: { executed?: boolean; command?: string }) => [{
            type: 'text',
            text: value.executed === true
              ? `TUI command /${value.command ?? ''} executed.`
              : `TUI command /${value.command ?? ''} NOT executed (not whitelisted).`,
          }],
        },
        async execute(args: { command?: unknown; args?: unknown }) {
          const name = String(args.command ?? '').trim()
          const arg = typeof args.args === 'string' ? args.args.trim() : ''
          if (name === '' || !TUI_COMMAND_WHITELIST.has('/' + name)) {
            return { executed: false, command: name }
          }
          try {
            onCommand(app, '/' + name + (arg !== '' ? ' ' + arg : ''))
            return { executed: true, command: name }
          } catch {
            return { executed: false, command: name }
          }
        },
      }))).catch(() => {
        // registration rejected asynchronously: keyword routing still works
      })
    } catch {
      // tools service absent / registration rejected: keyword routing still works
    }
  }
}

/** nvim notifications this module owns (dispatched by boot via rpc.ts). */
export function registerNotifications(): void {
  // -- nvim notifications this module owns (dispatched by boot via rpc.ts) --
  registerNvimNotification('dsh-input', t('输入处理'), (app, args) => {
    const raw = String(args?.[0] ?? '')
    // Card INPUT actions claim the next input: it belongs to the card,
    // not the agent (interception sits BEFORE the tui:input broadcast,
    // so ext subscribers never see card inputs as chat input).
    if (app.slices.ext.pendingCardInput !== null) {
      const pending = app.slices.ext.pendingCardInput
      app.slices.ext.setPendingCardInput(null)
      const text = raw.trim()
      if (text === '') {
        app.notice(t('已取消卡片输入'))
        return
      }
      const feed = app.slices.ui.activeFeed()
      const r = feed === undefined ? null : feed.resolveCardAction(pending.mark, pending.actionIdx)
      if (r === null || r.action === undefined) {
        app.notice(t('⚠ 卡片已失效，输入已取消'))
        return
      }
      try {
        feed!.fireCardAction(r.cardId, text)
      } catch (err) {
        app.notice(tf('⚠ 卡片操作失败: {0}', [(err as Error).message]))
      }
      return
    }
    app.slices.ext.extFire('tui:input', { text: raw })
    try { app.slices.agent.onInput(raw) } catch (err) { app.notice(tf('⚠ 输入处理失败: {0}', [(err as Error).message])) }
  })
  registerNvimNotification('dsh-command', t('命令'), (app, args) => {
    // A pending card INPUT claims the next submission even when it starts
    // with '/' (the Lua side routes slash-lines to dsh-command) — route it
    // through the same interception as dsh-input instead of executing it.
    if (app.slices.ext.pendingCardInput !== null) {
      try { app.slices.agent.onInput(String(args?.[0] ?? '')) } catch { /* handled inside */ }
      return
    }
    try { app.slices.agent.onCommand(String(args?.[0] ?? '')) } catch (err) { app.notice(tf('⚠ 命令失败: {0}', [(err as Error).message])) }
  })
  registerNvimNotification('dsh-abort', t('中止'), (app) => {
    // <C-c> in the input box: same path as /stop.
    app.slices.agent.stopCommand()
  })
  registerNvimNotification('dsh-approval-decided', t('审批'), (app, args) => {
    const raw = String(args?.[0] ?? 'n')
    if (raw === 'always') {
      // dsh has no allow-always grant (one-shot vocabulary only), so
      // "always" switches the session to AUTOMATIC mode: approval
      // policy 'never' — stop prompting, auto-decide from now on
      // (the harness fails closed: such requests are auto-rejected).
      // This request is the last one decided interactively.
      const sid = app.slices.agent.approvalReq?.agent?.session?.id
      if (sid !== undefined) {
        const rec = app.slices.sessions.live.get(sid)
        if (rec) {
          try {
            rec.handle.agent.session.append('approval/policy', { policy: 'never' })
            rec.policy = 'never'
            app.slices.ui.updateStatusline()
            rec.feed.appendNotice(t('已切换自动审批模式（never）：不再弹窗询问，需要审批的操作将自动拒绝（/yolo off 恢复逐项询问）'))
          } catch { /* policy switch is best-effort */ }
        }
      }
      app.slices.agent.settleApproval('allowed-once')
    } else {
      app.slices.agent.settleApproval(raw === 'y' ? 'allowed-once' : 'rejected')
    }
    // NOTE: settleApproval already clears the head and advanceApproval()
    // promotes the next queued entry — an unconditional setApproval(null,
    // null) here used to WIPE the freshly-promoted settle, hanging every
    // concurrent (parent + subagent) approval after the first.
  })
  registerNvimNotification('dsh-questions-answered', t('提问'), (app, args) => {
    const answers = (args?.[0] ?? []) as unknown[]
    // settleQuestions resolves the head AND advanceQuestions() promotes the
    // next queued entry — the old inline resolve + setQuestions(null) left
    // concurrent questions stuck forever.
    app.slices.agent.settleQuestions(answers)
  })
  registerNvimNotification('dsh-questions-cancelled', t('提问'), (app) => {
    app.slices.agent.rejectQuestions('cancelled by user')
  })
  registerNvimNotification('dsh-prompt-result', t('输入'), (app, args) => {
    const payload = (args?.[0] ?? {}) as { id?: unknown; value?: unknown }
    const id = typeof payload.id === 'string' ? payload.id : ''
    if (id === '') return
    settlePrompt(app, id, typeof payload.value === 'string' ? payload.value : null)
  })
  registerNvimNotification('dsh-picker-selected', t('选择'), (app, args) => {
    app.slices.agent.settlePicker((args?.[0] ?? null) as string | null)
  })
  registerNvimNotification('dsh-picker-cancelled', t('选择'), (app) => {
    app.slices.agent.settlePicker(null)
  })
  registerNvimNotification('dsh-dir-selected', t('目录选择'), (app, args) => {
    const picked = args?.[0] as string | null | undefined
    // resolveDirPicker self-clears the slot — no follow-up setDirSettle needed.
    app.slices.agent.resolveDirPicker(picked ?? null)
  })
  registerNvimNotification('dsh-at-query', t('文件引用补全'), (app, args) => {
    const payload = (args?.[0] ?? {}) as { query?: unknown; start?: unknown }
    const query = String(payload.query ?? '')
    const start = Number(payload.start ?? 0)
    return app.slices.agent.atQuery(query, start)
  })
  registerNvimNotification('dsh-paste-image', t('图片粘贴'), (app) => {
    app.slices.agent.pasteClipboardImage()
  })
  registerNvimNotification('dsh-open-failed', t('打开文件'), (app, args) => {
    // nvim-side open_file_tab (tabedit) failed: /dir、/deliverables、/settings
    // all open files in a fresh tab — surface the failure instead of
    // silently ignoring the notification (previously unhandled).
    const path = String(args?.[0] ?? '')
    app.notice(tf('⚠ 打开文件失败: {0}', [path]))
  })
}

/** host events this module owns (wired by boot via host-events.ts). */
export function registerHostEventHandlers(): void {
  // -- host events this module owns (wired by boot via host-events.ts) ----
  // Approval requests: show the floating window and decide.
  registerHostHandler('approval/request', (app, req, next) => {
    const request = req as ApprovalRequest
    const proceed = next as () => unknown
    if (app.slices.runtime.disposed) return proceed()
    return new Promise((resolve) => {
      let settled = false
      // Queue-aware entry: concurrent requests (parent + subagents) wait in
      // order — the runner shows ONE float at a time and advances on settle.
      const signal = request.signal
      const onAbort = (): void => app.slices.agent.abortApproval(entry)
      const entry = {
        req: request,
        settle: (outcome: string) => {
          if (settled) return
          settled = true
          // Detach: `{ once: true }` only removes the listener when the abort
          // FIRES, so every normally-answered request used to leave one
          // closure (holding the entry and the app) attached to the turn's
          // signal for its whole lifetime.
          try { signal?.removeEventListener('abort', onAbort) } catch {}
          // Record BEFORE resolving: the float and its notice are transient, so
          // this log is the only way to answer "why did I allow that?" later.
          recordApproval(app, request, outcome)
          resolve(outcome)
        },
      }
      signal?.addEventListener('abort', onAbort, { once: true })
      app.slices.agent.enqueueApproval(entry)
      const sid = request.agent?.session?.id
      const rec = sid === undefined ? undefined : app.slices.sessions.live.get(sid)
      const localized = request.displayReason?.[locale()] ?? request.displayReason?.['en']
      const shown = localized ?? request.reason ?? ''
      rec?.feed.appendNotice(`⚠ 审批请求: ${request.toolName ?? '?'}${shown ? ` — ${shown}` : ''}`)
      // Approval bell / desktop notification: REMOVED (same reason as turn-end
      // in session-events: the plugin's nvim has no tty on stdout, so any raw
      // escape corrupts the terminal instead of notifying).
    })
  })
  // User questions: claim the host's `user-questions/request` waterfall
  // as the interactive answerer (dsh 0.1.2-alpha.2: registerProvider was
  // removed in favor of the scoped cordis waterfall).
  registerHostHandler('user-questions/request', (app, request, next) => {
    const req = request as { questions?: unknown[]; signal?: AbortSignal }
    const proceed = next as () => unknown
    if (app.slices.runtime.disposed) return proceed()
    return new Promise((resolve, reject) => {
      // Queue-aware entry (same head/tail semantics as approvals).
      const signal = req.signal
      const detach = (): void => { try { signal?.removeEventListener('abort', onAbort) } catch {} }
      const onAbort = (): void => app.slices.agent.abortQuestions(entry)
      const entry = {
        questions: req.questions ?? [],
        resolve: (value: unknown) => { detach(); resolve(value) },
        reject: (err: unknown) => { detach(); reject(err) },
      }
      signal?.addEventListener('abort', onAbort, { once: true })
      app.slices.agent.enqueueQuestions(entry)
    })
  })
}

/** Boot-phase drain (moved out of boot): input that arrived before the
 *  first agent was ready. */
export function drainPendingInput(app: App): void {
  if (app.slices.agent.pendingInput.length > 0) {
    const queued = app.slices.agent.pendingInput.splice(0)
    for (const text of queued) app.slices.agent.send(text)
  }
}
