/** dsh_tui command: /locale — one command per file (self-registering,
 *  wired by the commands module index). */
import { t, tf } from '../../kernel/i18n.js'
import { locale, setLocale } from '../../kernel/i18n.js'
import type { App } from '../../kernel/app.js'


/** /locale [zh|en] — switch runner UI language (official client's
 *  locale preference; Lua-side hints stay Chinese for now). */
export const localeCommand = (app: App, a: string | undefined): void => {
  const want = (a ?? '').trim()
  if (want === '') {
    app.notice(tf('语言: {0}（/locale zh|en 切换）', [locale() === 'en' ? 'en' : 'zh']))
    return
  }
  if (want !== 'zh' && want !== 'en') {
    app.notice(t('用法: /locale zh|en'))
    return
  }
  setLocale(want)
  app.slices.sessions.refreshList()
  void app.refreshCommandCatalog()
  app.slices.ui.updateStatusline()
  app.notice(tf('语言已切换: {0}', [want]))
}

export function installLocaleCommand(app: App): void {
  app.registerCommands([{ name: '/locale', desc: t('语言 (zh/en)'), usage: t('[zh|en]'), group: t('系统'), fn: (a) => localeCommand(app, a) }])
}
