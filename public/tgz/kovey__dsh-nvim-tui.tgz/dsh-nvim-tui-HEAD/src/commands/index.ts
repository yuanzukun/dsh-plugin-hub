/**
 * dsh_tui commands module — messaging + input routing + the slash-command
 * system. One file per command under commands/ (each self-registers via
 * its installXxxCommand(app)); this index assembles the agent-domain ops,
 * defaults, core service slots and the full command list.
 *
 * @module dsh-nvim-tui/commands
 */
import type { AppSlices, WritableSlice, QuestionsEntry } from '../kernel/app.js'
import type { ApprovalRequest } from '../kernel/types.js'
import { locale } from '../kernel/i18n.js'
import { drainPrompts } from '../kernel/prompt.js'
const W = (d: AppSlices['agent']) => d as WritableSlice<AppSlices['agent']>
import type { App } from '../kernel/app.js'
import {
  followup, send, pasteClipboardImage, stopCommand, openDirPicker, atQuery,
  applyModelSelection, onInput, onCommand, queueSubagentPrompt,
  registerTool, registerNotifications, registerHostEventHandlers,
} from './core.js'
import { helpCommand } from './commands/help.js'
import { restartCommand } from './commands/restart.js'
import { pickModel } from './commands/model.js'
import { installExitCommand } from './commands/exit.js'
import { installQuitCommand } from './commands/quit.js'
import { installRestartCommand } from './commands/restart.js'
import { installHelpCommand } from './commands/help.js'
import { installPanelCommand } from './commands/panel.js'
import { installStopCommand } from './commands/stop.js'
import { installSteerCommand } from './commands/steer.js'
import { installModelCommand } from './commands/model.js'
import { installEffortCommand } from './commands/effort.js'
import { installPresetCommand } from './commands/preset.js'
import { installYoloCommand } from './commands/yolo.js'
import { installThemeCommand } from './commands/theme.js'
import { installConfigCommand } from './commands/config.js'
import { installStatusCommand } from './commands/status.js'
import { installContextCommand } from './commands/context.js'
import { installModelsCommand } from './commands/models.js'
import { installDoctorCommand } from './commands/doctor.js'
import { installRememberCommand } from './commands/remember.js'
import { installMemoryCommand } from './commands/memory.js'
import { installImageCommand } from './commands/image.js'
import { installCompactCommand } from './commands/compact.js'
import { installCwdCommand } from './commands/cwd.js'
import { installGoalCommand } from './commands/goal.js'
import { installTodoCommand } from './commands/todo.js'
import { installPlanCommand } from './commands/plan.js'
import { installSearchCommand } from './commands/search.js'
import { installTasksCommand } from './commands/tasks.js'
import { installSkillsCommand } from './commands/skills.js'
import { installMcpCommand } from './commands/mcp.js'
import { installPluginsCommand } from './commands/plugins.js'
import { installCordisCommand } from './commands/cordis.js'
import { installQuoteCommand } from './commands/quote.js'
import { installCopyCommand } from './commands/copy.js'
import { installLocaleCommand } from './commands/locale.js'
import { installFbCommand } from './commands/fb.js'
import { installFeedbackCommand } from './commands/feedback.js'
import { installWorkflowCommand } from './commands/workflow.js'
import { installPermissionCommand } from './commands/permission.js'
import { installAttachCommand } from './commands/attach.js'
import { installUploadCommand } from './commands/upload.js'
import { installFilesCommand } from './commands/files.js'
import { installPreviewCommand } from './commands/preview.js'
import { installDirCommand } from './commands/dir.js'
import { installLinesCommand } from './commands/lines.js'
import { installHistoryCommand } from './commands/history.js'
import { installDeliverablesCommand } from './commands/deliverables.js'
import { installDiffCommand } from './commands/diff.js'
import { installChangesCommand } from './commands/changes.js'
import { installOfficialCommandsCommand } from './commands/official-commands.js'
import { installSettingsCommand } from './commands/settings.js'
import { installAccountCommand } from './commands/account.js'
import { installScheduleCommand } from './commands/schedule.js'
import { installTerminalCommand } from './commands/terminal.js'
import { installApprovalsCommand } from './commands/approvals.js'
import { installDifficultyCommand } from './commands/difficulty.js'

/** Fill the commands module's App slots and register its commands. */
export { drainPendingInput } from './core.js'

/** Fill the commands module's App slots and register its commands. */
export function installCommands(app: App): void {
  // -- agent domain ops (cross-domain consumers mutate agent state ONLY
  //    through these; owner keeps the writable view) --
  const A = W(app.slices.agent)
  A.setApproval = (entry, settle) => { A.approvalReq = entry; A.approvalSettle = settle }

  // ---- queue-aware approval/questions (parent + subagents can ask
  //   CONCURRENTLY — a second request must queue, never overwrite the
  //   first settle) ----
  /** Build the approval float payload: localized reason plus the exact tool
   *  call arguments when the asker supplied `callId` (dsh-user-approval's
   *  documented presentation hook). Without this the user decides a sandbox
   *  escalation from a one-line reason and never sees the command. */
  const approvalDisplay = (req: ApprovalRequest): {
    toolName: string
    reason: string
    callId: string
    args: string
  } => {
    const sid = req.agent?.session?.id
    const rec = sid === undefined ? undefined : app.slices.sessions.live.get(sid)
    const call = req.callId === undefined ? undefined : rec?.feed.calls.get(req.callId)
    const localized = req.displayReason?.[locale()] ?? req.displayReason?.['en']
    return {
      toolName: req.toolName ?? '',
      reason: localized ?? req.reason ?? '',
      callId: req.callId ?? '',
      args: call?.args ?? '',
    }
  }
  const showApprovalFloat = (req: ApprovalRequest): void => {
    if (app.slices.runtime.disposed) return
    void app.luaCall('require("dsh_tui").show_approval(...)', [approvalDisplay(req)]).catch(() => {
      // Float failed to open for THIS head: settle it rejected and move on.
      if (A.approvalReq === req) A.settleApproval('rejected')
    })
  }
  const advanceApproval = (): void => {
    while (A.approvalQueue.length > 0) {
      const next = A.approvalQueue.shift()!
      if (next.cancelled === true) continue
      A.approvalReq = next.req
      A.approvalSettle = next.settle
      showApprovalFloat(next.req)
      return
    }
  }
  A.settleApproval = (outcome) => {
    const fn = A.approvalSettle
    A.approvalSettle = null
    A.approvalReq = null
    fn?.(outcome)
    advanceApproval()
  }
  A.enqueueApproval = (e) => {
    if (A.approvalReq === null && A.approvalQueue.length === 0) {
      A.approvalReq = e.req
      A.approvalSettle = e.settle
      showApprovalFloat(e.req)
    } else {
      A.approvalQueue.push(e)
    }
  }
  A.abortApproval = (e) => {
    e.cancelled = true
    e.settle('cancelled')
    if (A.approvalReq === e.req) {
      A.approvalReq = null
      A.approvalSettle = null
      advanceApproval()
    }
  }
  A.drainApprovals = (outcome) => {
    A.approvalSettle?.(outcome)
    A.approvalSettle = null
    A.approvalReq = null
    for (const e of A.approvalQueue) e.settle(outcome)
    A.approvalQueue.length = 0
  }
  A.setPickerSettle = (fn) => { A.pickerSettle = fn }
  A.settlePicker = (value) => { const fn = A.pickerSettle; A.pickerSettle = null; fn?.(value) }
  A.setQuestions = (r) => { A.questionsResolve = r }
  const showQuestionsFloat = (e: QuestionsEntry): void => {
    if (app.slices.runtime.disposed) return
    void app.luaCall('require("dsh_tui").show_questions(...)', [e.questions]).catch(() => {
      if (A.questionsResolve?.resolve === e.resolve) {
        A.questionsResolve = null
        e.reject(new Error('no UI'))
        advanceQuestions()
      }
    })
  }
  const advanceQuestions = (): void => {
    while (A.questionsQueue.length > 0) {
      const next = A.questionsQueue.shift()!
      if (next.cancelled === true) continue
      A.questionsResolve = { resolve: next.resolve, reject: next.reject }
      showQuestionsFloat(next)
      return
    }
  }
  A.settleQuestions = (answers) => {
    const r = A.questionsResolve
    A.questionsResolve = null
    r?.resolve({ answers })
    advanceQuestions()
  }
  A.rejectQuestions = (reason = 'UI torn down') => {
    const r = A.questionsResolve
    A.questionsResolve = null
    r?.reject(new Error(reason))
    advanceQuestions()
  }
  A.enqueueQuestions = (e) => {
    if (A.questionsResolve === null && A.questionsQueue.length === 0) {
      A.questionsResolve = { resolve: e.resolve, reject: e.reject }
      showQuestionsFloat(e)
    } else {
      A.questionsQueue.push(e)
    }
  }
  A.abortQuestions = (e) => {
    e.cancelled = true
    e.reject(new Error('cancelled by caller'))
    if (A.questionsResolve?.resolve === e.resolve) {
      A.questionsResolve = null
      advanceQuestions()
    }
  }
  A.drainQuestions = () => {
    A.questionsResolve?.reject(new Error('UI torn down'))
    A.questionsResolve = null
    for (const e of A.questionsQueue) e.reject(new Error('UI torn down'))
    A.questionsQueue.length = 0
  }
  A.setDirSettle = (fn) => { A.dirSettle = fn }
  A.resolveDirPicker = (picked) => { const fn = A.dirSettle; A.dirSettle = null; fn?.(picked) }
  /** Release the temporary background live session a rename target owns.
   *  Its only other release point is onInput CONSUMING the rename — a
   *  replaced/cleared target used to strand an agent handle + nvim buffers
   *  forever (pre-review: "accumulated forever"). */
  const releaseRenameTarget = (target: typeof A.pendingRename): void => {
    if (target !== null && target.kind === 'session' && target.background === true) {
      void app.slices.sessions.disposeLiveSession(target.id)
    }
  }
  A.setPendingRename = (v) => {
    if (A.pendingRename !== v) releaseRenameTarget(A.pendingRename)
    A.pendingRename = v
  }
  A.setLivePopup = (v) => { A.livePopup = v }
  A.setPendingQueueEdit = (v) => { A.pendingQueueEdit = v }
  A.clearPendings = () => {
    // A modal prompt (feedback/schedule wizard) must not outlive the session
    // it was opened for; resolve it as cancelled so its command unwinds.
    drainPrompts(app)
    releaseRenameTarget(A.pendingRename)
    A.pendingRename = null
    A.pendingQueueEdit = null
    A.pendingImages = []
    W(app.slices.agent).pendingFiles = []
    A.pendingSubagentFollowup = null
  }

  Object.assign(app.slices.agent, {
    approvalQueue: [],
    // Empty until a session is known: `ensureApprovalHistory` fills it from the
    // durable log on first use / on session switch. Seeding here would have to
    // guess the session (there may be none yet).
    approvalHistory: [],
    approvalHistoryFor: null,
    questionsQueue: [],
    // Seeded null, NEVER undefined: statusline reads pop.kind with a
    // null-guard — an unseeded undefined crashes foldEvent/refreshBgJobs
    // (the auto-resume 'reading kind' outage family).
    livePopup: null,
    followup: async () => {},
    queueSubagentPrompt: async () => {},
    send: () => {},
    pasteClipboardImage: () => {},
    applyModelSelection: async () => {},
    pickModel: async () => {},
    stopCommand: () => {},
    onInput: () => {},
    onCommand: () => {},
    helpCommand: async () => {},
    restartCommand: () => {},
    openDirPicker: async () => null,
    atQuery: async () => {},
    currentSelection: () => app.runtimeCtx.agentDefaultModel.currentSelection(),
    pendingInput: [],
    pendingImages: [],
    pendingFiles: [],
    pendingRename: null,
    pendingQueueEdit: null,
    approvalSettle: null,
    approvalReq: null,
    questionsResolve: null,
    pickerSettle: null,
    dirSettle: null,
  })

  // -- core services this module owns (moved out of createApp, I1) --
  // -- core services this module owns (moved out of createApp, I1) --

  app.slices.agent.followup = (rec, text, images) => followup(app, rec, text, images)
  app.slices.agent.queueSubagentPrompt = (parentAgent, childId, text) => queueSubagentPrompt(app, parentAgent, childId, text)
  app.slices.agent.send = (text) => send(app, text)
  app.slices.agent.pasteClipboardImage = () => pasteClipboardImage(app)
  app.slices.agent.stopCommand = () => stopCommand(app)
  app.slices.agent.openDirPicker = (startPath) => openDirPicker(app, startPath)
  app.slices.agent.atQuery = (query, start) => atQuery(app, query, start)
  app.slices.agent.applyModelSelection = (next) => applyModelSelection(app, next)
  app.slices.agent.pickModel = (arg) => pickModel(app, arg)
  app.slices.agent.onInput = (text) => onInput(app, text)
  app.slices.agent.onCommand = (line) => onCommand(app, line)
  app.slices.agent.helpCommand = () => helpCommand(app)
  app.slices.agent.restartCommand = () => restartCommand(app)

  // -- the 40 slash commands, one file each (self-registering) --
  installExitCommand(app)
  installQuitCommand(app)
  installRestartCommand(app)
  installHelpCommand(app)
  installPanelCommand(app)
  installStopCommand(app)
  installSteerCommand(app)
  installModelCommand(app)
  installEffortCommand(app)
  installPresetCommand(app)
  installYoloCommand(app)
  installThemeCommand(app)
  installConfigCommand(app)
  installStatusCommand(app)
  installContextCommand(app)
  installModelsCommand(app)
  installCwdCommand(app)
  installDoctorCommand(app)
  installRememberCommand(app)
  installMemoryCommand(app)
  installImageCommand(app)
  installCompactCommand(app)
  installGoalCommand(app)
  installTodoCommand(app)
  installPlanCommand(app)
  installSearchCommand(app)
  installTasksCommand(app)
  installSkillsCommand(app)
  installMcpCommand(app)
  installPluginsCommand(app)
  installCordisCommand(app)
  installQuoteCommand(app)
  installCopyCommand(app)
  installLocaleCommand(app)
  installFbCommand(app)
  installFeedbackCommand(app)
  installWorkflowCommand(app)
  installPermissionCommand(app)
  installAttachCommand(app)
  installUploadCommand(app)
  installFilesCommand(app)
  installPreviewCommand(app)
  installDirCommand(app)
  installLinesCommand(app)
  installHistoryCommand(app)
  installDeliverablesCommand(app)
  installDiffCommand(app)
  installChangesCommand(app)
  installOfficialCommandsCommand(app)
  installSettingsCommand(app)
  installAccountCommand(app)
  installScheduleCommand(app)
  installTerminalCommand(app)
  installApprovalsCommand(app)
  installDifficultyCommand(app)

  registerTool(app)
  registerNotifications()
  registerHostEventHandlers()
}
