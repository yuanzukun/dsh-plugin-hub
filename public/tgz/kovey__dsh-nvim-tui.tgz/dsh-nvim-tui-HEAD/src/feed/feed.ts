/**
 * FeedRenderer: maps DSH session/event transcript events into the nvim chat
 * buffer. Pure presentation — keeps a line model in memory and syncs it to
 * the buffer, throttled.
 *
 * Model:
 *  - `base`: committed RAW lines (markup included; parsed at flush)
 *  - `tail`: the currently streaming assistant text (rewritten in place, so a
 *    full `assistant/message` naturally replaces the streamed prefix)
 *  - `calls`: tool/call records paired with their tool/result (elapsed, error)
 *
 * Rendering:
 *  - Incremental `nvim_buf_set_lines`: the view is diffed against the last
 *    flushed view and only changed rows are rewritten.
 *  - Role highlights (user/notice/tool/error/subagent/workflow) are derived
 *    from line prefixes; inline `**bold**` / `` `code` `` / ```fences``` are
 *    stripped in the buffer and rendered as extmark spans; markdown tables
 *    become aligned box-drawing tables (lib/table.js). The whole highlight
 *    pass for a flush runs as ONE Lua RPC.
 *
 * Concurrency contract:
 *  - `nvim_buf_set_lines` is the only blocking step of a flush.
 *  - Cursor moves and statusline writes are fire-and-forget: a wedged RPC must
 *    never block the feed.
 *  - Events arriving during a flush set `dirty`; the flush chains a follow-up.
 */
import { NeovimClient } from 'neovim'
import { whaleFrames, whaleRowsIndented } from './whale.js'

import { transformTables, renderTable, isTableRow, isSeparator } from './table.js'
import { fileLabel, imageLabel } from './images.js'
import { formatElapsed, formatTokens } from './stats.js'
import { t, tf } from '../kernel/i18n.js'
import type { ChatMessage, FileAttachmentRef, ImageAttachmentRef, MessageContent, MessageSourceLike, SessionEvent } from '../kernel/types.js'

const INLINE_RE = /(\*\*[^*]+\*\*|`[^`\n]+`|\[[^\]\n]+\]\([^)\n]+\))/g
/** Exact ✎ diff header: ✎ (新增|修改|删除) <path> (+N −M) — the ONLY line
 *  that may open a diff region (random '✎ …' content stays plain). */
const DIFF_HEADER_RE = /^✎ \S+ (.+) \(\+\d+ −\d+\)$/
const FENCE_RE = /^\s*```/
const HEADING_RE = /^(#{1,6})\s+/
const QUOTE_RE = /^>\s?/

/** UTF-8 byte length — nvim highlight columns are byte-indexed. */
const utf8Len = (s: string): number => Buffer.byteLength(s, 'utf8')

/** Inline highlight span (byte offsets into the rendered line). */
export interface Span {
  s: number
  e: number
  group: string
}

/** One parsed view row (markup stripped, spans byte-indexed). */
export interface ParsedLine {
  text: string
  spans: Span[]
  code: boolean
  fenceToggled: boolean
  /** Undefined is meaningful (no group) — the producer passes it explicitly. */
  group?: string | null | undefined
}

const ROLE_BY_PREFIX: Array<[RegExp, string]> = [
  [/^> /, 'DshTuiUser'],
  [/^➤ /, 'DshTuiUser'],
  [/^· /, 'DshTuiNotice'],
  [/^·· /, 'DshTuiReasoning'],
  [/^── /, 'DshTuiDivider'],
  [/^⚠ /, 'DshTuiError'],
  [/^🔧 /, 'DshTuiTool'],
  [/^✓ /, 'DshTuiTool'],
  [/^✗ /, 'DshTuiTool'],
  [/^◇ /, 'DshTuiSubagent'],
  [/^◈ /, 'DshTuiWorkflow'],
  [/^▣ /, 'DshTuiExt'],
]

export type StepsMode = 'all' | 'final'

export interface FeedOptions {
  flushDelayMs?: number
  idsProvider?: (() => Promise<unknown>) | null
  activeChecker?: (() => boolean) | null
  reasoningBuf?: number | null
  reasoningView?: (() => { open: boolean; win: number | null } | null) | null
  inlineReasoning?: boolean
  /** Blue whale wallpaper/watermark (default off; the runner enables it). */
  whale?: boolean
  /** Work-step visibility: 'final' hides tool/subagent/workflow cards. */
  stepsMode?: StepsMode
  /** Empty-state welcome block: lines ABOVE the whale (big banner + title)
   *  and lines BELOW it (usage hints); rows may carry a highlight group. */
  welcome?: () => { above?: WelcomeLine[]; below?: WelcomeLine[] }
}

export interface WelcomeLine {
  text: string
  group?: string
}

/** One card action. kind 'plain' (default) fires immediately; 'confirm'
 *  gates behind a picker; 'input' collects a typed value via the input box
 *  (headless degrades both to plain). */
export interface ExtCardAction {
  label: string
  value: string
  /** Optional fields accept an EXPLICIT undefined (extension callers forward
   *  their own optionals verbatim — exactOptionalPropertyTypes). */
  kind?: 'plain' | 'confirm' | 'input' | undefined
  confirmText?: string | undefined
  inputPrompt?: string | undefined
  inputDefault?: string | undefined
}

/** Ext-card render options (the P1 extension API's ui.card). Optionals accept
 *  an explicit undefined: extension callers forward their own optionals
 *  verbatim (exactOptionalPropertyTypes). */
export interface ExtCardOpts {
  /** Extension name shown in the card header. */
  plugin: string
  title: string
  body: string
  actions?: ExtCardAction[] | undefined
  /** Interactive activation (P4-③): invoked with the action's value when
   *  the user activates the card in the chat (1-9 / Enter). plain/confirm
   *  actions pass action.value; input actions pass the TYPED text. */
  onAction?: ((value: string) => void) | undefined
}

/** Handle returned by pushExtCard: update/dismiss the block in place. */
export interface ExtCardHandle {
  id: string
  update(next: Partial<ExtCardOpts>): void
  dismiss(): void
}

interface ToolCallRecord {
  name: string
  startedAt: number
  /** Raw model-supplied JSON arguments, kept so the approval float can show
   *  the exact command/path being approved (dsh-user-approval callId). */
  args?: string
}

/** Prefix for a quota failure, or '' for anything else.
 *
 * Pure and exported so the mapping is asserted directly: the two codes mean
 * different things and a wrong mapping sends the user to top up the wrong
 * account — which is exactly the mistake the codes exist to prevent. */
/**
 * How a FAILED tool result must be presented.
 *
 * `unknown` is the case that matters: the call may already have taken effect
 * (a run, a write, a network side effect), so showing it as a plain `✗` invites
 * a blind retry of something that already happened. dsh 0.2.0 spells this out in
 * its repair docs ("cause-specific retry guidance") and the code is emitted by
 * our own tail repair as well. Pure, so the mapping is asserted directly.
 */
export const failureMark = (code: string | undefined): 'unknown' | 'failed' =>
  code === 'TOOL_OUTCOME_UNKNOWN' ? 'unknown' : 'failed'

export const quotaAdvice = (code: string | undefined): string => {
  if (code === 'ACCOUNT_QUOTA') return t('⚠ 账号额度已用尽 —— 在账号计费页补充额度（不是 API Key 的余额）\n')
  if (code === 'QUOTA') return t('⚠ API Key 余额不足 —— 请为该 Key 充值\n')
  return ''
}

export class FeedRenderer {
  nvim: NeovimClient
  bufId: number
  winId: number
  flushDelayMs: number
  idsProvider: (() => Promise<unknown>) | null
  // Only the ACTIVE session may move the shared chat window's cursor.
  activeChecker: () => boolean
  // Activity panel: reasoning stream + tool records go to this buffer; the
  // chat only shows ONE compact progress line. reasoningView() -> {open, win}.
  reasoningBuf: number | null
  reasoningView: () => { open: boolean; win: number | null } | null
  // Read-only replays without a panel (subagent view): reasoning blocks
  // render INLINE in the chat stream instead of only a record line.
  inlineReasoning: boolean
  panelLines: string[] // committed panel content (reasoning blocks + tools)
  panelFlushed: number // rows already written (complete lines)
  panelVersion: number
  lastPanelVersion: number
  toolActivity: { name: string; startedAt: number } | null // while a tool is running
  /** Consecutive reasoning-panel write failures (self-heal trigger). */
  reasoningFailures = 0
  /** Card extmark failures (diagnostics only — one bad card must not stop the batch). */
  cardFailures = 0
  base: string[]
  tail: string
  // Reasoning (model thinking) stream: rendered dim between base and tail
  // while open, committed to base when the first answer text / tool arrives.
  reasoningTail: string
  reasoningStartedAt: number | null
  // "The model is working" placeholder: turn started but nothing rendered yet.
  turnStartedAt: number | null
  turnMarkerBase: number | null
  calls: Map<string, ToolCallRecord> // callId -> { name, startedAt }
  ptcCalls: Map<string, ToolCallRecord> // PTC subCallId -> { name, startedAt }
  subagents: Map<string, { provider: string; startedAt: number }> // runId -> …
  timer: ReturnType<typeof setTimeout> | null
  flushing: Promise<void> | null
  tokenNs: number | null // treesitter highlight marks (feed ns + separate)
  lastActivityCount: number // transient activity rows in the previous view
  dirty: boolean
  ns: number | null // extmark namespace, created on first flush
  lastView: string[] // last flushed buffer text, diffed per flush
  dense: boolean // /density: compact tool cards (title line only)
  stepsMode: StepsMode // /steps final: hide work-step cards
  /** Ext cards (P1 extension API): card id → tracked base range, so
   *  update()/dismiss() splice the block in place (flush rebuilds the full
   *  view from base, so deletions propagate). */
  extCards: Map<string, { start: number; length: number; merged: ExtCardOpts }>
  extCardSeq: number
  /** Interactive cards (P4-③): cardId → action surface. */
  cardHandlers: Map<string, { actions: ExtCardAction[]; onAction?: ((value: string) => void) | undefined }>
  /** cardId → rendered extmark range (markId + buffer rows). */
  cardRanges: Map<string, { markId: number; startRow: number; endRow: number }>
  cardNs: number | null
  /** Pinned todo panel (todo/write): while ANY visible item is incomplete
   *  the standing list renders at the BOTTOM of the view (above the
   *  thinking row, never displaced by streaming content); once every item
   *  is ✓ the block COMMITS into base (ordinary chat content) and stays
   *  pinned across turns like the jobs board. */
  todoLiveRows: string[]
  /** Todo items already FLUSHED into a committed all-✓ board (by content).
   *  The host's todo_write re-sends the COMPLETE standing list every time —
   *  without this set every later board/commit re-lists the old completed
   *  items and the lists grow without bound. Re-opened items (any
   *  non-completed status) leave the set and come back. */
  committedTodos: Set<string>
  /** Pinned jobs board (setJobsBoard): same bottom-pinned slot — updates
   *  replace live; commitJobsBoard lands the FINAL state (all jobs
   *  terminal) into base. */
  jobsLiveRows: string[]
  jobsLiveKey: string
  /** Key of the board already committed to `base` (idempotence guard). */
  committedJobsKey = ''
  /** Cached viewport width: the cap renderTable wraps overwide tables
   *  against (refreshed by winSize, throttled once per 2s per flush). */
  lastWinW: number
  lastWinAt: number
  /** Cached reasoning-panel width for the panel table cap (throttled the
   *  same way — a per-flush width RPC would tax the streaming path). */
  lastPanelW: number
  lastPanelAt: number
  whale: boolean // blue whale wallpaper (empty) + watermark (content)
  welcome: (() => { above?: WelcomeLine[]; below?: WelcomeLine[] }) | null // empty-state hero block
  whaleFrame: number // animation frame index (wallpaper only)
  whaleTicker: ReturnType<typeof setInterval> | null
  ticker: ReturnType<typeof setTimeout> | null
  eventTime: number

  constructor(nvim: NeovimClient, bufId: number, winId: number, {
    flushDelayMs = 40,
    idsProvider = null,
    activeChecker = null,
    reasoningBuf = null,
    reasoningView = null,
    inlineReasoning = false,
    whale = false,
    stepsMode = 'all',
    welcome,
  }: FeedOptions = {}) {
    this.nvim = nvim
    this.bufId = bufId
    this.winId = winId
    this.flushDelayMs = flushDelayMs
    this.idsProvider = idsProvider
    this.activeChecker = activeChecker ?? (() => true)
    this.whale = whale
    this.stepsMode = stepsMode
    this.welcome = welcome ?? null
    this.whaleFrame = 0
    this.whaleTicker = null
    this.reasoningBuf = reasoningBuf
    this.reasoningView = reasoningView ?? (() => null)
    this.inlineReasoning = inlineReasoning
    this.panelLines = []
    this.panelFlushed = 0
    this.panelVersion = 0
    this.lastPanelVersion = -1
    this.toolActivity = null
    this.base = []
    this.tail = ''
    this.reasoningTail = ''
    this.reasoningStartedAt = null
    this.turnStartedAt = null
    this.turnMarkerBase = null
    this.calls = new Map()
    this.ptcCalls = new Map()
    this.subagents = new Map()
    this.timer = null
    this.flushing = null
    this.tokenNs = null
    this.lastActivityCount = 0
    this.dirty = false
    this.ns = null
    this.lastView = []
    this.dense = false
    this.extCards = new Map()
    this.extCardSeq = 0
    this.cardHandlers = new Map()
    this.cardRanges = new Map()
    this.todoLiveRows = []
    this.committedTodos = new Set()
    this.jobsLiveRows = []
    this.jobsLiveKey = ''
    this.cardNs = null
    this.lastWinW = 100
    this.lastWinAt = 0
    this.lastPanelW = 52
    this.lastPanelAt = 0
    this.ticker = null
    this.eventTime = 0
  }

  /** Clear the transcript (the /clear command). */
  clear(): void {
    this.base = []
    this.tail = ''
    this.reasoningTail = ''
    this.reasoningStartedAt = null
    this.turnStartedAt = null
    this.turnMarkerBase = null
    this.calls.clear()
    this.subagents.clear()
    this.eventTime = 0
    this.cardRanges.clear()
    this.toolActivity = null
    this.extCards.clear()
    this.cardHandlers.clear()
    this.todoLiveRows = []
    this.committedTodos = new Set()
    this.jobsLiveRows = []
    this.jobsLiveKey = ''
    if (this.ticker !== null) clearTimeout(this.ticker)
    if (this.reasoningBuf !== null) {
      this.panelLines = []
      this.panelFlushed = 0
      this.panelVersion++
    }
    this.schedule()
  }

  /** Notice line (runner lifecycle, status). Multi-line text (e.g. an error
   *  message with a stack trace) is collapsed to ONE line: a string with
   *  embedded newlines fed to nvim_buf_set_lines throws E5108 and kills the
   *  whole flush — the /subagents E95 failure notice was invisible this way
   *  and every later render that included it silently failed. */
  appendNotice(text: unknown): void {
    const clean = String(text).replace(/\s+/g, ' ').trim()
    this.base.push(`· ${clean}`)
    this.schedule()
  }

  pushBlock(role: string, text: string): void {
    this.base.push('')
    if (role === 'user') {
      for (const line of text.split('\n')) this.base.push(`> ${line}`)
    } else if (role === 'steer') {
      for (const line of text.split('\n')) this.base.push(`➤ ${line}`)
    } else {
      for (const line of text.split('\n')) this.base.push(line)
    }
    this.schedule()
  }

  /** User bubble with image attachment labels (📎 lines under the text). */
  pushUser(text: string, imageLabels: string[]): void {
    this.base.push('')
    if (text) {
      // User echoes stay verbatim EXCEPT markdown tables, which get the same
      // bordered-table beautification as assistant content (rows keep the
      // `> ` quote prefix).
      for (const entry of transformTables(FeedRenderer.compactQuote(text).split('\n'), false, 0, this.lastWinW)) {
        this.base.push(`> ${entry.table ? entry.text : entry.raw}`)
      }
    }
    for (const label of imageLabels ?? []) this.base.push(`> ${label}`)
    this.schedule()
  }

  /** Rebuild the visible transcript under a new work-step mode. */
  setStepsMode(mode: StepsMode, events?: readonly SessionEvent[]): void {
    this.stepsMode = mode
    if (events === undefined) return
    this.clear()
    this.stepsMode = mode
    for (const event of events) this.applyEvent(event, { history: true })
    void this.flush()
  }

  /** Collapse a long Markdown quote in the user echo; the stored message is
   *  untouched, so the model still receives the complete quoted text. */
  static compactQuote(text: string, maxLines = 3, maxChars = 240): string {
    const lines = text.split('\n')
    const quoteCount = lines.filter((line) => line.startsWith('> ')).length
    if (quoteCount <= maxLines) return text
    const kept: string[] = []
    let seen = 0
    for (const line of lines) {
      if (line.startsWith('> ')) {
        if (seen < maxLines) kept.push(line)
        seen++
      } else {
        kept.push(line)
      }
    }
    kept.push(`> …（还有 ${String(quoteCount - maxLines)} 行引用）`)
    const joined = kept.join('\n')
    return joined.length <= maxChars ? joined : joined.slice(0, Math.max(0, maxChars - 1)) + '…'
  }

  pushTool(line: string): void {
    if (this.stepsMode === 'final') return
    this.base.push('', line)
    this.schedule()
  }

  /** File-change diff block (✎ header + `+ `/`- `/context lines). ALWAYS
   *  renders in the chat — the panel stays the compact activity log (the
   *  tool ✓ line still routes there when it is open), while the diff is the
   *  content the user wants to read in the conversation. Lines are rendered
   *  verbatim — no markdown stripping inside code content. */
  pushDiff(header: string, lines: string[]): void {
    if (this.stepsMode === 'final' || lines.length === 0) return
    this.base.push('', header, ...lines)
    this.schedule()
  }

  pushSubagent(line: string): void {
    if (this.stepsMode === 'final') return
    this.base.push('', line)
    this.schedule()
  }

  pushWorkflow(line: string): void {
    if (this.stepsMode === 'final') return
    this.base.push('', line)
    this.schedule()
  }

  /** Visible standing-todo items for one todo/write payload: completed
   *  items that were already FLUSHED into a committed board are hidden —
   *  the host re-sends the whole standing list on every write, and without
   *  the flush every later board/commit would re-list them (unbounded
   *  growth). Non-completed items always show. */
  todoVisibleItems(todos: Array<{ content: string; status: string }>): Array<{ content: string; status: string }> {
    return todos.filter((td) => td.status !== 'completed' || !this.committedTodos.has(td.content))
  }

  /** Pinned jobs board (the /tasks counterpart in the chat): while ANY
   *  job is running/stopping the board renders at the BOTTOM of the view
   *  (above the thinking row); identical content is a no-op. */
  setJobsBoard(rows: string[]): void {
    const key = rows.join('\n')
    if (key === this.jobsLiveKey) return
    this.jobsLiveKey = key
    this.jobsLiveRows = rows
    this.schedule()
  }

  /** All jobs terminal: the FINAL board state lands in base (ordinary chat
   *  content) and the pinned slot clears. */
  /** Commit the FINAL jobs board. `batchKey` identifies the batch (ids +
   *  statuses — the caller's identity, NOT the rendered text: two different
   *  batches can render identically). Re-committing the same batch is a
   *  no-op, so a heartbeat racing the terminal state cannot duplicate the
   *  board in the transcript. */
  commitJobsBoard(rows: string[], batchKey?: string): void {
    if (batchKey !== undefined && batchKey !== '' && batchKey === this.committedJobsKey) {
      this.jobsLiveRows = []
      this.jobsLiveKey = ''
      this.schedule()
      return
    }
    if (rows.length > 0) this.base.push(...rows)
    if (batchKey !== undefined && batchKey !== '') this.committedJobsKey = batchKey
    this.jobsLiveRows = []
    this.jobsLiveKey = ''
    this.schedule()
  }

  /** Ext card (P1 extension API): a `▣ plugin · title` header block with an
   *  indented body and optional action hints. Returns a handle that updates
   *  or dismisses the block IN PLACE (tracked base range). With `onAction`
   *  set, the chat buffer gains activation: cursor on the card + 1-9 fires
   *  the action directly, Enter opens the action picker. */
  pushExtCard(opts: ExtCardOpts, cardId?: string): ExtCardHandle {
    const id = cardId ?? `ext-${opts.plugin}-${++this.extCardSeq}`
    const lines = this.extCardLines(opts)
    const start = this.base.length
    this.base.push(...lines)
    this.extCards.set(id, { start, length: lines.length, merged: opts })
    this.cardHandlers.set(id, { actions: opts.actions ?? [], onAction: opts.onAction })
    this.schedule()
    return {
      id,
      update: (next: Partial<ExtCardOpts>) => {
        const rec = this.extCards.get(id)
        if (rec === undefined) return
        // Merge against the LAST merged state, not the creation-time opts:
        // update({title}) then update({body}) must stack, not silently drop
        // the title (pre-review behavior re-merged from the initial opts).
        const merged: ExtCardOpts = { ...rec.merged, ...next }
        rec.merged = merged
        const nextLines = this.extCardLines(merged)
        this.base.splice(rec.start, rec.length, ...nextLines)
        this.shiftExtCards(rec.start, nextLines.length - rec.length)
        rec.length = nextLines.length
        this.cardHandlers.set(id, { actions: merged.actions ?? [], onAction: merged.onAction })
        this.schedule()
      },
      dismiss: () => {
        const rec = this.extCards.get(id)
        if (rec === undefined) return
        this.base.splice(rec.start, rec.length)
        this.extCards.delete(id)
        this.cardHandlers.delete(id)
        this.shiftExtCards(rec.start, -rec.length)
        this.schedule()
      },
    }
  }

  /** Card block lines: blank separator + header + indented body + hints. */
  private extCardLines(opts: ExtCardOpts): string[] {
    const lines: string[] = ['', `▣ ${FeedRenderer.truncate(`${opts.plugin} · ${opts.title}`, 96)}`]
    for (const l of String(opts.body ?? '').split('\n')) lines.push(`  ${l}`)
    const actions = opts.actions ?? []
    if (actions.length > 0) {
      lines.push(`  ${actions.slice(0, 4).map((a, i) => `[${i + 1}] ${a.label}`).join('  ')}`)
    }
    return lines
  }

  /** After a splice at `afterStart`, adjust every later card's base offset. */
  private shiftExtCards(afterStart: number, delta: number): void {
    if (delta === 0) return
    for (const rec of this.extCards.values()) {
      if (rec.start > afterStart) rec.start += delta
    }
  }

  /** Sync the interactive-card extmark ranges (P4-③): one block mark per
   *  card covering its RENDERED rows (post markdown-transform). Marks are
   *  re-placed only when a card's range changed; dismissed cards' marks
   *  are deleted. */
  private async syncCardMarks(newRows: Map<string, { startRow: number; endRow: number }>): Promise<void> {
    if (this.cardNs === null) {
      this.cardNs = await this.nvim.request('nvim_create_namespace', ['dsh_tui_extcards']) as number
    }
    const ns = this.cardNs
    for (const [cardId, range] of newRows) {
      const prev = this.cardRanges.get(cardId)
      if (prev !== undefined && prev.startRow === range.startRow && prev.endRow === range.endRow) continue
      if (prev !== undefined) {
        await this.nvim.request('nvim_buf_del_extmark', [this.bufId, ns, prev.markId]).catch(() => {})
      }
      let markId: number
      try {
        markId = await this.nvim.request('nvim_buf_set_extmark', [
          this.bufId, ns, range.startRow, 0,
          // end_row is EXCLUSIVE: +1 so the card's LAST row (the action-hint
          // line) is inside the mark — activating a card with the cursor on
          // that row used to fail (api.lua checks `row < end_row`).
          { end_row: range.endRow + 1, end_col: 0, priority: 1 },
        ]) as number
      } catch (err) {
        // One bad card (externally modified buffer, stale namespace, wiped
        // buffer) must not abort the WHOLE batch: that used to leave every
        // later card's mark missing (non-interactive) AND skip the stale-mark
        // cleanup below, with no diagnostic at all.
        this.cardFailures++
        if (this.cardFailures === 1) {
          try { console.error('[dsh-nvim-tui] card extmark failed:', (err as Error).message) } catch {}
        }
        continue
      }
      this.cardRanges.set(cardId, { markId, startRow: range.startRow, endRow: range.endRow })
    }
    for (const [cardId, prev] of this.cardRanges) {
      if (newRows.has(cardId)) continue
      try {
        await this.nvim.request('nvim_buf_del_extmark', [this.bufId, ns, prev.markId])
      } catch {}
      this.cardRanges.delete(cardId)
    }
  }

  /** Resolve the interactive card under an extmark (P4-③). actionIdx null
   *  → returns the action list for the picker (items carry their kind);
   *  a number → { cardId, action } for the dispatcher (plain/confirm/input
   *  routing lives in boot.ts). Null when no interactive card owns the mark
   *  (action-less cards stay display-only). */
  activateCard(markId: number, actionIdx: number | null): ExtCardAction[] | { cardId: string; action: ExtCardAction } | null {
    const r = this.resolveCardAction(markId, actionIdx)
    if (r === null) return null
    if (actionIdx === null) return r.actions
    if (r.action === undefined) return null
    return { cardId: r.cardId, action: r.action }
  }

  /** Look up a card by mark id: returns the handler surface. */
  resolveCardAction(markId: number, actionIdx: number | null): { cardId: string; actions: ExtCardAction[]; action?: ExtCardAction } | null {
    let cardId: string | null = null
    for (const [id, r] of this.cardRanges) {
      if (r.markId === markId) {
        cardId = id
        break
      }
    }
    if (cardId === null) return null
    const entry = this.cardHandlers.get(cardId)
    if (entry === undefined || typeof entry.onAction !== 'function' || entry.actions.length === 0) return null
    if (actionIdx === null) return { cardId, actions: entry.actions }
    const act = entry.actions[actionIdx - 1]
    if (act === undefined) return null
    return { cardId, actions: entry.actions, action: act }
  }

  /** Fire a resolved card action with the FINAL value (plain/confirm pass
   *  action.value; input passes the typed text). Returns false when the
   *  card vanished since resolution. */
  fireCardAction(cardId: string, value: string): boolean {
    const entry = this.cardHandlers.get(cardId)
    if (entry === undefined || typeof entry.onAction !== 'function') return false
    // Exceptions propagate to boot.ts's guard (feed notice), never into nvim.
    entry.onAction(value)
    return true
  }

  pushError(text: unknown): void {
    // Collapse newlines like appendNotice — the same E5108 hazard.
    this.base.push('', `⚠ ${String(text).replace(/\s+/g, ' ').trim()}`)
    this.schedule()
  }

  /** Extract plain text from a message (content blocks or raw text). */
  static messageText(message: ChatMessage | undefined): string {
    const content = message?.content
    if (Array.isArray(content)) {
      return content
        .filter((b): b is Extract<MessageContent, { type: 'text' }> => b?.type === 'text' && typeof (b as { text?: unknown }).text === 'string')
        .map((b) => b.text)
        .join('\n')
    }
    if (typeof message?.text === 'string') return message.text
    return ''
  }

  /** Display labels for a message's image blocks (durable attachment refs). */
  static messageImages(message: ChatMessage | undefined): string[] {
    const content = message?.content
    if (!Array.isArray(content)) return []
    return content
      .filter((b): b is Extract<MessageContent, { type: 'image' }> => b?.type === 'image' && (b as { attachment?: ImageAttachmentRef }).attachment !== undefined)
      .map((b) => imageLabel(b.attachment))
  }

  /** Display labels for a message's durable file-upload blocks. */
  static messageFiles(message: ChatMessage | undefined): string[] {
    const content = message?.content
    if (!Array.isArray(content)) return []
    return content
      .filter((b): b is Extract<MessageContent, { type: 'file' }> => b?.type === 'file' && (b as { attachment?: FileAttachmentRef }).attachment !== undefined)
      .map((b) => fileLabel(b.attachment))
  }

  /** Extract reasoning (thinking) text from a message's content blocks. */
  static messageReasoning(message: ChatMessage | undefined): string {
    const content = message?.content
    if (!Array.isArray(content)) return ''
    return content
      .filter((b): b is Extract<MessageContent, { type: 'reasoning' }> => b?.type === 'reasoning' && typeof (b as { text?: unknown }).text === 'string')
      .map((b) => b.text)
      .join('\n')
  }

  /** Close the open thinking block. The compact chat line is TRANSIENT — it
   *  lives only in the activity region while thinking, so nothing is pushed
   *  to the chat base (details are in the panel). Fallback without a panel:
   *  keep the line in chat so there is some record; with `inlineReasoning`
   *  (read-only replays like the subagent view) the full thinking text is
   *  inlined as a dim block instead. */
  commitReasoning(): void {
    if (this.reasoningTail === '') return
    const elapsedMs = this.reasoningStartedAt !== null
      ? (this.eventTime || Date.now()) - this.reasoningStartedAt
      : null
    if (this.reasoningBuf !== null) {
      this.panelLines.push(
        '·· thinking',
        ...this.reasoningTail.split('\n'),
        `── thinking end${elapsedMs !== null ? ` · ${(elapsedMs / 1000).toFixed(1)}s` : ''} ──`,
      )
      this.panelVersion++
    } else {
      this.base.push('')
      this.base.push(`·· thinking${elapsedMs !== null ? ` · ${(elapsedMs / 1000).toFixed(1)}s` : ''}`)
      if (this.inlineReasoning) this.base.push(...this.reasoningTail.split('\n'))
    }
    this.reasoningTail = ''
    this.reasoningStartedAt = null
  }

  /**
   * Structured tool results (web_search hits, grep/glob matches, …): a JSON
   * array of objects itemizes into compact rows instead of one truncated
   * blob — the terminal's counterpart of the web's per-tool cards. Returns
   * null when the text is not a usable JSON array.
   */
  static structuredHits(text: string): string[] | null {
    if (!text || (!text.trimStart().startsWith('[') && !text.trimStart().startsWith('{'))) return null
    let parsed: unknown
    try { parsed = JSON.parse(text) } catch { return null }
    const items = Array.isArray(parsed)
      ? parsed
      : (parsed as { results?: unknown; hits?: unknown } | null)?.results ?? (parsed as { results?: unknown; hits?: unknown } | null)?.hits
    if (!Array.isArray(items) || items.length === 0) return null
    const rows: string[] = []
    for (const it of items.slice(0, 8)) {
      if (typeof it !== 'object' || it === null) { rows.push(FeedRenderer.truncate(it)); continue }
      const o = it as { title?: unknown; url?: unknown; snippet?: unknown; path?: unknown; name?: unknown }
      const title = String(o.title ?? o.name ?? o.path ?? '').replace(/\s+/g, ' ').trim()
      const url = String(o.url ?? '').trim()
      const snippet = String(o.snippet ?? '').replace(/\s+/g, ' ').trim()
      const parts = [title, url, snippet].filter((x) => x !== '')
      if (parts.length === 0) { rows.push(FeedRenderer.truncate(it)); continue }
      rows.push(FeedRenderer.truncate(parts.join(' · '), 100))
    }
    return rows.length > 0 ? rows : null
  }

  /** One-line preview of raw model JSON arguments. */
  static argsPreview(argumentsText: string | undefined): string {
    if (typeof argumentsText !== 'string' || argumentsText.trim() === '') return '{}'
    try {
      const parsed = JSON.parse(argumentsText)
      return JSON.stringify(parsed).slice(0, 60) + (JSON.stringify(parsed).length > 60 ? '…' : '')
    } catch {
      return argumentsText.replace(/\s+/g, ' ').slice(0, 60)
    }
  }

  static truncate(text: unknown, max = 80): string {
    const oneLine = String(text).replace(/\s+/g, ' ').trim()
    return oneLine.length > max ? oneLine.slice(0, max) + '…' : oneLine
  }

  applyEvent(event: SessionEvent, { history = false }: { history?: boolean } = {}): void {
    this.eventTime = event.time ?? this.eventTime
    switch (event.type) {
      case 'user/message': {
        // Harness variants: data IS the message, or data.message wraps it.
        const data = event.data as { message?: ChatMessage } | ChatMessage | undefined
        const msg = (data as { message?: ChatMessage } | undefined)?.message ??
          (data as ChatMessage | undefined)
        const source = (msg as (ChatMessage & { source?: MessageSourceLike }) | undefined)?.source
        // Only kind 'user' (or a source-less legacy event) is human input.
        // The harness's MessageSource kind union is merge-extensible — plugins
        // add their own ('plugin' snapshots, 'skill-catalog', 'subagent-report',
        // 'subagent-settled', …) — so the test must be positive on 'user', not
        // a negative list of known producers.
        if (source !== undefined && source.kind !== 'user') {
          // Host-injected context (runtime snapshots, catalogs, relays,
          // goal continuations…): NOT a human bubble — it must never
          // masquerade as user input. Render as dim notice rows: a `notice`
          // form collapses to its one-line summary; other forms render the
          // content dimmed under a small header.
          const text = FeedRenderer.messageText(msg)
          // Child→parent traffic (alpha.4 bidirectional messaging) keeps its
          // subagent identity: a `◇` header row in the subagent color plus
          // dim content rows — visible, but never mistaken for user input.
          // Content rows use the `· ` prefix (fence-safe: unlike a bare
          // whitespace prefix it can never match FENCE_RE and leak the
          // code color below the block).
          if (source.kind === 'subagent-settled' || source.kind === 'agent-message'
            || source.kind === 'subagent-report' || source.kind === 'coordinator') {
            if (source.form === 'notice' && typeof source.summary === 'string' && source.summary !== '') {
              this.base.push('', `◇ 子代理已结束 · ${source.summary}`)
              // The notice's content repeats the summary as its first line
              // (the harness frames the closing message after it) — drop the
              // duplicate and keep the child's closing message dimmed.
              const lines = text.split('\n')
              const rest = lines.length > 0 && lines[0] === source.summary ? lines.slice(1) : lines
              for (const line of rest) this.base.push(`· ${line}`)
            } else {
              const sender = typeof source['senderSessionId'] === 'string'
                ? source['senderSessionId'].slice(0, 8)
                : '?'
              this.base.push('', `◇ 子代理 ${sender} → 本会话`)
              for (const line of text.split('\n')) this.base.push(`· ${line}`)
            }
            this.schedule()
            break
          }
          if (source.form === 'notice' && typeof source.summary === 'string' && source.summary !== '') {
            this.base.push('', `· ${source.summary}`)
          } else if (text) {
            this.base.push('', t('· 注入上下文'))
            for (const line of text.split('\n')) this.base.push(`· ${line}`)
          }
          this.schedule()
          break
        }
        const text = FeedRenderer.messageText(msg)
        const labels = [...FeedRenderer.messageImages(msg), ...FeedRenderer.messageFiles(msg)]
        if (text || labels.length > 0) this.pushUser(text, labels)
        break
      }
      case 'assistant/message': {
        // data = { turn, step, message }; the full message replaces the
        // streamed tail (assistant/chunk deltas covered it already).
        const message = event.data?.message
        // Providers that never streamed reasoning deltas still carry the
        // thinking text in the final message — show it once.
        if (this.reasoningTail === '' && !this.reasoningStartedAt) {
          const reasoning = FeedRenderer.messageReasoning(message)
          if (reasoning) {
            this.reasoningTail = reasoning
            this.reasoningStartedAt = this.eventTime
          }
        }
        this.commitReasoning()
        this.tail = FeedRenderer.messageText(message)
        // An aborted turn commits the prefix it produced before the stop:
        // mark it so the truncated content never reads as a complete answer.
        if (event.data?.interrupted === true) {
          this.tail += (this.tail === '' ? '' : '\n') + '⚠ 回合被中断'
        }
        this.schedule()
        break
      }
      case 'assistant/chunk': {
        const chunk = event.data?.chunk
        if (chunk?.type === 'reasoning-delta' && typeof chunk.text === 'string') {
          // The model is THINKING: full text goes to the reasoning panel,
          // the chat shows only a compact progress line. Streaming deltas
          // must NOT bump panelVersion — it tracks COMMITTED panel structure;
          // the live tail is synced by the streaming-only fast path.
          if (this.reasoningStartedAt === null) {
            this.reasoningStartedAt = this.eventTime
          }
          this.reasoningTail += chunk.text
          this.schedule()
        } else if (chunk?.type === 'text-delta' && typeof chunk.text === 'string') {
          if (this.reasoningTail !== '') this.commitReasoning()
          this.tail += chunk.text
          this.schedule()
        } else if (chunk?.type === 'finish' && chunk.reason?.kind === 'error') {
          // A turn that dies (missing credential, gateway, …) must be visible.
          this.commitReasoning()
          this.commitTail()
          const failure = chunk.reason.failure
          const base = failure?.message
            ?? chunk.reason.error?.message
            ?? JSON.stringify(chunk.reason)
          // A quota failure is actionable, and the ACTION DIFFERS by code: an
          // account quota is replenished on the billing page, while a plain
          // `QUOTA` is the API key's own balance. dsh 0.1.7-rc.2 introduced
          // `ACCOUNT_QUOTA` precisely to tell them apart — the Web UI warns
          // against topping up the wrong one, and dropping the code here would
          // put the TUI back to a message the user cannot act on.
          // `failure` arrives as a loosely typed event payload (not the host's
          // own type at this boundary), so the code is read defensively.
          const fcode = (failure as { code?: unknown } | undefined)?.['code']
          this.pushError(quotaAdvice(typeof fcode === 'string' ? fcode : undefined) + base)
        }
        break
      }
      case 'tool/call': {
        this.commitReasoning()
        const data = event.data
        if (data === undefined || this.stepsMode === 'final') break
        const { callId, name, arguments: args } = data
        this.calls.set(callId ?? '', { name: name ?? 'tool', startedAt: this.eventTime, ...(typeof args === 'string' ? { args } : {}) })
        const callLine = `🔧 ${name ?? 'tool'}(${FeedRenderer.argsPreview(args)})`
        if (this.reasoningBuf !== null) {
          this.panelLines.push('', callLine)
          this.panelVersion++
        } else {
          this.pushTool(callLine)
        }
        this.toolActivity = { name: name ?? 'tool', startedAt: Date.now() }
        this.schedule()
        break
      }
      case 'tool/ptc-dispatch-start': {
        // PTC mode: a tool dispatched from inside run_code. Log-only events;
        // render a nested line so the user sees what the program is doing.
        const data = event.data
        if (data === undefined || this.stepsMode === 'final') break
        const name = data.name ?? 'tool'
        let argsText = ''
        try { argsText = typeof data.arguments === 'string' ? data.arguments : JSON.stringify(data.arguments ?? {}) } catch { argsText = '{}' }
        const subId = data.subCallId ?? ''
        if (subId !== '') this.ptcCalls.set(subId, { name, startedAt: this.eventTime })
        const line = `  ↳ 🔧 ${name}(${FeedRenderer.argsPreview(argsText)})`
        if (this.reasoningBuf !== null) {
          this.panelLines.push(line)
          this.panelVersion++
        } else {
          this.pushTool(line)
        }
        this.schedule()
        break
      }
      case 'tool/ptc-dispatch': {
        const data = event.data
        if (data === undefined || this.stepsMode === 'final') break
        const subId = data.subCallId ?? ''
        const started = subId !== '' ? this.ptcCalls.get(subId) : undefined
        const name = data.name ?? started?.name ?? 'tool'
        const elapsed = started ? Math.max(0, (this.eventTime || Date.now()) - (started.startedAt ?? this.eventTime)) : null
        const text = FeedRenderer.messageText({ content: Array.isArray(data.content) ? data.content as MessageContent[] : [] })
        const preview = text !== '' ? ' · ' + FeedRenderer.truncate(text) : ''
        const line = `  ↳ ${data.isError === true ? '✗' : '✓'} ${name}${elapsed === null ? '' : ' · ' + formatElapsed(elapsed)}${preview}`
        if (subId !== '') this.ptcCalls.delete(subId)
        if (this.reasoningBuf !== null) {
          this.panelLines.push(line)
          this.panelVersion++
        } else {
          this.pushTool(line)
        }
        this.schedule()
        break
      }
      case 'image/offload': {
        const data = event.data
        const targets = Array.isArray(data?.targets) ? data.targets : []
        let count = 0
        for (const target of targets) count += Array.isArray(target.imageIndexes) ? target.imageIndexes.length : 0
        this.appendNotice(tf('🖼 已省略 {0} 张图片：模型侧改为占位符，原始附件仍保留在会话日志', [String(count)]))
        break
      }
      case 'tool/result': {
        const data = event.data
        if (data === undefined) break
        const source = data.message?.source
        const call = source?.callId ? this.calls.get(source.callId) : undefined
        const name = call?.name ?? 'tool'
        const elapsed = call ? Math.max(0, (this.eventTime || Date.now()) - (call.startedAt ?? this.eventTime)) : null
        const failed = data.error !== undefined && data.error !== null
        const resultText = FeedRenderer.messageText(data.message)
        const structured = failed ? null : FeedRenderer.structuredHits(resultText)
        const preview = FeedRenderer.truncate(resultText)
        const elapsedText = elapsed === null ? '' : ` · ${formatElapsed(elapsed)}`
        const previewPart = !this.dense && structured === null && preview ? ` · ${preview}` : ''
        let line: string
        if (failed) {
          const err = data.error
          const code = (err as { code?: unknown } | undefined)?.['code']
          // A tool whose OUTCOME IS UNKNOWN is not a plain failure: the call may
          // have taken effect (# run / write / network side effects). Marking it
          // ✗ invites a blind retry of an operation that already happened, so it
          // gets its own shape and an explicit "verify first" line.
          // dsh 0.2.0 states this in its own repair docs ("cause-specific retry
          // guidance") and the code is emitted by our own tail repair too.
          if (failureMark(typeof code === 'string' ? code : undefined) === 'unknown') {
            line = `⚠ ${name}${elapsedText} · ${t('结果未知')}${previewPart}`
          } else {
            line = `✗ ${name}${elapsedText} · ${err?.code ?? err?.name ?? 'failed'}${previewPart}`
          }
        } else {
          line = `✓ ${name}${elapsedText}${previewPart}`
        }
        const errCode = (data.error as { code?: unknown } | undefined)?.['code']
        const unknownOutcome = failed
          && failureMark(typeof errCode === 'string' ? errCode : undefined) === 'unknown'
        const outLines = structured === null || this.dense ? [line] : [line, ...structured.map((h) => `  · ${h}`)]
        if (unknownOutcome) {
          outLines.push(`  ${t('· 该操作可能已生效：先核实副作用再重试，不要盲目重跑')}`)
        }
        for (const l of outLines) {
          if (this.reasoningBuf !== null) {
            this.panelLines.push(l)
            this.panelVersion++
          } else {
            this.pushTool(l)
          }
        }
        this.toolActivity = null
        this.schedule()
        break
      }
      case 'turn/start':
        this.base.push('', '── turn ──')
        this.turnStartedAt = Date.now()
        this.turnMarkerBase = this.base.length
        if (!history && this.reasoningBuf !== null) {
          // The panel is a per-turn activity log (live turns only).
          this.panelLines = []
          this.panelFlushed = 0
          this.panelVersion++
        }
        this.toolActivity = null
        this.schedule()
        break
      case 'turn/end':
        // The incomplete todo panel STAYS pinned across turns (standing
        // board, same slot as the jobs board): content can never push it
        // into the transcript, and the next todo/write updates it in place.
        this.commitReasoning()
        this.commitTail()
        this.base.push('── turn end ──')
        this.turnStartedAt = null
        this.turnMarkerBase = null
        // A tool/result that never arrived (scheduler crash, interrupted
        // turn) must not leave the "🔧 running" activity row pinned forever:
        // the flush tail then keeps re-scheduling every 500ms. Same for a
        // subagent whose end event never came.
        this.toolActivity = null
        this.subagents.clear()
        this.schedule()
        break
      case 'todo/write': {
        // Standing todo list (todo_write): while ANY visible item is
        // incomplete the block is PINNED at the bottom of the view (the
        // thinking row stays the bottom-most line below it) — across turns,
        // like the jobs board; once every visible item is ✓ the block
        // COMMITS into base as ordinary chat content. Empty todos clear the
        // pinned slot without committing.
        const todos = event.data?.todos ?? []
        // Re-opened items leave the flushed set: a re-planned task shows
        // again and its completion commits again.
        for (const td of todos) {
          if (td.status !== 'completed') this.committedTodos.delete(td.content)
        }
        const visible = this.todoVisibleItems(todos)
        const rows: string[] = []
        if (visible.length > 0) {
          const count = (st: string) => visible.filter((td) => td.status === st).length
          const done = count('completed')
          const doing = count('in_progress')
          const pending = count('pending')
          rows.push('', `${t('📋 待办')} ${visible.length} ${t('项')} · ${done} ${t('完成')} · ${doing} ${t('进行中')} · ${pending} ${t('待办')}`)
          for (const td of visible) {
            const mark = td.status === 'completed' ? '✓' : td.status === 'in_progress' ? '…' : '·'
            rows.push(`  ${mark} ${td.content}`)
          }
        }
        const allDone = visible.length > 0 && visible.every((td) => td.status === 'completed')
        if (allDone) {
          // The board lands in the transcript, then the list is FLUSHED:
          // later whole-list re-sends skip these completed items (an
          // identical re-emission yields an empty visible list → the
          // pinned slot clears without a duplicate commit).
          this.base.push(...rows)
          for (const td of visible) this.committedTodos.add(td.content)
          this.todoLiveRows = []
        } else {
          this.todoLiveRows = rows
        }
        this.schedule()
        break
      }
      case 'compaction/start':
        this.base.push('', t('⋯ 正在压缩上下文…'))
        this.schedule()
        break
      case 'compaction/summary': {
        // Checkpoint row (web: one collapsed disclosure): replaced-item and
        // estimated-token counts, summary block folded underneath. dsh
        // 0.1.1-rc.2 carries `summary` as ContentBlock[]; older hosts used a
        // plain string — accept both.
        const d = event.data
        const rows = d?.shadowedSeqs?.length
        const tokens = d?.shadowedTokenCount
        this.base.push('', `${t('⋯ 上下文压缩')} · ${rows ?? '?'} ${t('条历史')}${typeof tokens === 'number' ? ` · ≈${formatTokens(tokens)} tokens` : ''}`)
        const raw = d?.summary
        if (typeof raw === 'string' && raw !== '') {
          this.base.push(`  ${t('摘要')}：`)
          for (const line of raw.split('\n').slice(0, 12)) this.base.push(`    ${line}`)
        } else if (Array.isArray(raw) && raw.length > 0) {
          this.base.push(`  ${t('摘要')}：`)
          for (const block of raw.slice(0, 12)) {
            const b = block as { type?: string; text?: string }
            const text = typeof b?.text === 'string' ? b.text : (b?.type !== undefined ? `[${b.type}]` : '')
            for (const line of text.split('\n')) this.base.push(`    ${line}`)
          }
        }
        this.schedule()
        break
      }
      case 'compaction/end':
        break
      case 'llm/retry': {
        // Muted retry status row (web keeps ONE row per chain; the buffer
        // model is append-only, so each attempt lands its own row).
        const d = event.data
        const delayText = typeof d?.delayMs === 'number' ? formatElapsed(d.delayMs) : '?'
        const fail = d?.failure?.message ?? d?.failure?.code
        const cap = d?.mode === 'always' ? '∞' : (d?.maxRetries !== undefined ? `/${d.maxRetries}` : '')
        this.base.push('', `${t('↻ 重试 #')}${d?.retry ?? '?'}${cap} · ${delayText} ${t('后重试')}${fail ? ` · ${FeedRenderer.truncate(fail)}` : ''}`)
        this.schedule()
        break
      }
      case 'llm/retry-started':
        this.base.push('', `${t('↻ 重试 #')}${event.data?.retry ?? '?'} ${t('已发起')}`)
        this.schedule()
        break
      case 'tool-workflow/run-start':
        this.pushWorkflow(`◈ workflow ${FeedRenderer.truncate(String(event.data?.name ?? event.data?.runId ?? ''), 60)}`)
        break
      case 'tool-workflow/agent-start': {
        const d = event.data
        this.pushSubagent(tf('  ◇ #{seq} {label}{phase}', { seq: d?.seq ?? '?', label: d?.label ?? 'subagent', phase: d?.phase ? ` · ${d.phase}` : '' }))
        break
      }
      case 'tool-workflow/agent-end': {
        const d = event.data
        this.pushSubagent(tf('  ◇ #{seq} · {outcome}', { seq: d?.seq ?? '?', outcome: d?.outcome ?? 'settled' }))
        break
      }
      case 'tool-workflow/run-end':
        this.pushWorkflow(`◈ workflow · ${event.data?.stopReason ?? 'ended'}`)
        break
      default:
        break
    }
  }

  // -- subagent / workflow cards (host events routed by the runner) ---------

  subagentStart(info: { runId?: string; provider?: string; id?: string }): void {
    const now = Date.now()
    this.subagents.set(FeedRenderer.subagentKey(info), { provider: info.provider ?? '?', startedAt: now })
    this.pushSubagent(tf('◇ subagent {provider} · {id}', { provider: info.provider ?? '?', id: FeedRenderer.truncate(String(info.id ?? ''), 16) }))
  }

  subagentEnd(info: { runId?: string; provider?: string; id?: string; stopReason?: string }): void {
    // start/end MUST agree on the key: a missing runId used to store under
    // '?' and delete under '' → the entry leaked forever and kept the 500ms
    // activity ticker alive with a ghost "◇ provider · Ns" row.
    const key = FeedRenderer.subagentKey(info)
    const run = this.subagents.get(key)
    const elapsed = run ? Date.now() - run.startedAt : null
    this.subagents.delete(key)
    this.pushSubagent(tf('◇ subagent {provider} · {reason}{elapsed}', { provider: info.provider ?? '?', reason: info.stopReason ?? 'settled', elapsed: elapsed === null ? '' : ` · ${formatElapsed(elapsed)}` }))
  }

  /** One identity for a subagent run across start/end/elapsed lookups. */
  static subagentKey(info: { runId?: string; id?: string } | undefined): string {
    return info?.runId ?? info?.id ?? '?'
  }

  workflowStart(info: { id?: string; meta?: { name?: string } }): void {
    this.pushWorkflow(`◈ workflow ${FeedRenderer.truncate(String(info.meta?.name ?? info.id ?? ''), 60)}`)
  }

  workflowPhase(_info: unknown, title: string): void {
    this.pushWorkflow(`◈ ─ ${title}`)
  }

  workflowEnd(_info: unknown, result: { stopReason?: string; error?: string }): void {
    const err = result?.error
    this.pushWorkflow(`◈ workflow · ${result?.stopReason ?? 'ended'}${err ? ` · ${err}` : ''}`)
  }

  /** Move the streaming tail into committed base lines. */
  commitTail(): void {
    if (this.tail === '') return
    if (this.base.length > 0 && this.base[this.base.length - 1] !== '') this.base.push('')
    this.base.push(...this.tail.split('\n'))
    this.tail = ''
  }

  // -- markup ----------------------------------------------------------------

  /**
   * Parse one raw line into buffer text + inline highlight spans.
   * Fences (```) toggle whole-line code highlighting. With `quoteAware`
   * (assistant lines only — user lines keep their own `> ` prefix), markdown
   * blockquotes strip the prefix and get the dim-italic quote group.
   * `#{1,6} ` headings keep their text and get the heading group.
   */
  static parseLine(raw: string, fenceOpen: boolean, quoteAware = false): ParsedLine {
    if (FENCE_RE.test(raw)) {
      return { text: raw, spans: [], code: true, fenceToggled: true }
    }
    if (fenceOpen) {
      return { text: raw, spans: [], code: true, fenceToggled: false }
    }
    let line = raw
    let group: string | undefined
    if (quoteAware && QUOTE_RE.test(line)) {
      line = line.replace(QUOTE_RE, '')
      group = 'DshTuiQuote'
    } else if (HEADING_RE.test(line)) {
      line = line.replace(HEADING_RE, '')
      group = 'DshTuiHeading'
    }
    const spans: Span[] = []
    let text = ''
    let cursor = 0
    for (const m of line.matchAll(INLINE_RE)) {
      text += line.slice(cursor, m.index)
      const token = m[0]
      if (token.startsWith('**')) {
        const inner = token.slice(2, -2)
        spans.push({ s: utf8Len(text), e: utf8Len(text) + utf8Len(inner), group: 'DshTuiBold' })
        text += inner
      } else if (token.startsWith('`')) {
        const inner = token.slice(1, -1)
        spans.push({ s: utf8Len(text), e: utf8Len(text) + utf8Len(inner), group: 'DshTuiCode' })
        text += inner
      } else {
        const link = token.match(/^\[([^\]\n]+)\]\(([^)\n]+)\)$/)
        const inner = link?.[1] ?? token
        spans.push({ s: utf8Len(text), e: utf8Len(text) + utf8Len(inner), group: 'DshTuiLink' })
        text += inner
      }
      cursor = (m.index ?? 0) + token.length
    }
    text += line.slice(cursor)
    return { text, spans, code: false, fenceToggled: false, group }
  }

  /** Toggle the whale art and re-render (the /whale command). */
  setWhale(on: boolean): void {
    this.whale = on
    if (!on) this.stopWhaleTicker()
    this.schedule()
  }

  /** Animate the wallpaper: advance one frame and re-render (empty only). */
  private ensureWhaleTicker(): void {
    if (this.whaleTicker !== null) return
    this.whaleTicker = setInterval(() => {
      if (!this.whale) {
        this.stopWhaleTicker()
        return
      }
      this.whaleFrame = (this.whaleFrame + 1) % 4
      // Skip hidden buffers (inactive sessions) — the frame still advances so
      // the animation is fresh whenever the feed becomes visible again.
      if (this.activeChecker()) void this.flush().catch(() => {})
    }, 450)
  }

  private stopWhaleTicker(): void {
    if (this.whaleTicker !== null) {
      clearInterval(this.whaleTicker)
      this.whaleTicker = null
    }
  }

  /** Current window size via the ids provider (fallback 40×100). Success
   *  updates the table width cache (lastWinW) that renderTable caps
   *  overflow against. */
  private async winSize(): Promise<{ h: number; w: number }> {
    try {
      const ids = (await this.idsProvider?.()) as { win?: number } | null
      if (ids !== null && ids !== undefined && typeof ids.win === 'number') {
        const [h, w] = await Promise.all([
          this.nvim.request('nvim_win_get_height', [ids.win]) as Promise<number>,
          this.nvim.request('nvim_win_get_width', [ids.win]) as Promise<number>,
        ])
        this.lastWinW = w
        return { h, w }
      }
    } catch {}
    return { h: 40, w: this.lastWinW }
  }

  schedule(): void {
    if (this.timer !== null) return
    this.timer = setTimeout(() => {
      this.timer = null
      this.flush().catch((err: unknown) => {
        console.error('[dsh-nvim-tui] render flush failed:', err)
      })
    }, this.flushDelayMs)
  }

  async flush(): Promise<void> {
    if (this.flushing) {
      // A flush is in flight; remember that newer content arrived.
      this.dirty = true
      return
    }
    // Reserve the slot IMMEDIATELY: the parsing + whale winSize() below
    // contain RPC awaits — a second flush scheduled during that window
    // must not run concurrently (interleaved set_lines writes would
    // corrupt the buffer ordering). The real task replaces this placeholder
    // right before the writes; the finally below always clears it.
    this.flushing = Promise.resolve()
    // Keep the table width cap fresh (throttled: one probe per 2s — the
    // cap only matters when an overwide table renders, and the hot
    // streaming path must not pay an RPC roundtrip per flush).
    if (Date.now() - this.lastWinAt > 2000) {
      this.lastWinAt = Date.now()
      void this.winSize().catch(() => {})
    }
    const tailLines = this.tail === '' ? [] : this.tail.split('\n')
    // Task step-progress block: a TRAILING run of `- ✅/⏳/⬜ …` lines (with
    // its optional unmarked header line above). While ANY step is incomplete
    // it renders as a dynamic region ABOVE the thinking line (live updates
    // as the model re-emits the block); once every step is ✅ it falls back
    // into the ordinary tail and commits with the message — persisted for
    // replays.
    const STEP_MARK_RE = /^\s*[-*•]?\s*[✅⏳⬜]/
    let progressLines: string[] = []
    let restTail = tailLines
    if (tailLines.length > 0) {
      let i = tailLines.length - 1
      while (i >= 0 && STEP_MARK_RE.test(tailLines[i]!)) i--
      const stepStart = i + 1
      if (stepStart < tailLines.length && stepStart > 0) {
        const headerRow = tailLines[stepStart - 1]!
        const headerIsHeader = headerRow.trim() !== '' && !STEP_MARK_RE.test(headerRow)
        const incomplete = tailLines.slice(stepStart).some((l) => /⏳|⬜/.test(l))
        if (incomplete && headerIsHeader) {
          progressLines = [headerRow, ...tailLines.slice(stepStart)]
          restTail = tailLines.slice(0, stepStart - 1)
        }
      }
    }
    // The chat shows at most ONE activity line: thinking progress, the
    // running tool, or the silent-turn placeholder. Details live in the panel.
    // It renders at the VERY BOTTOM of the view — below the streaming tail —
    // so growing content can never displace it (the indicator stays pinned
    // above the statusline while the answer streams above it).
    let activityLines: string[] = []
    if (this.reasoningTail !== '') {
      const elapsed = this.reasoningStartedAt !== null
        ? ((this.eventTime || Date.now()) - this.reasoningStartedAt) / 1000
        : 0
      const header = `·· thinking · ${elapsed.toFixed(1)}s`
      // Read-only inline replays (the subagent view has no reasoning panel)
      // stream the thinking text into the buffer AS it arrives. Previously
      // only the compact header rendered during streaming and the whole block
      // landed in one shot when thinking closed (commitReasoning).
      activityLines = this.reasoningBuf === null && this.inlineReasoning
        ? [header, ...this.reasoningTail.split('\n')]
        : [header]
    } else if (this.toolActivity !== null) {
      // Wall clock on BOTH ends: while a long tool runs (foreground subagent,
      // slow build) no session events flow, so eventTime stays frozen at the
      // tool/call moment and an eventTime-based elapsed would sit at 0.0s the
      // whole run. The ticker re-renders this line every ~0.5s.
      const elapsed = (Date.now() - this.toolActivity.startedAt) / 1000
      activityLines = [`🔧 ${this.toolActivity.name} · ${elapsed.toFixed(1)}s`]
    } else if (this.subagents.size > 0) {
      // Running subagents while the main agent is quiet: ONE compact line in
      // the thinking slot — oldest child + elapsed, (+N for the rest). Same
      // transient logic as the thinking line: never committed. Wall clock:
      // subagentStart carries no event time, startedAt is Date.now().
      let oldest: { provider: string; startedAt: number } | null = null
      for (const s of this.subagents.values()) {
        if (oldest === null || s.startedAt < oldest.startedAt) oldest = s
      }
      const elapsed = oldest === null ? 0 : (Date.now() - oldest.startedAt) / 1000
      const extra = this.subagents.size > 1 ? ` +${this.subagents.size - 1}` : ''
      activityLines = [`◇ ${oldest?.provider ?? 'subagent'} · ${elapsed.toFixed(1)}s${extra}`]
    } else {
      const idleMs = this.turnStartedAt !== null &&
        this.base.length === this.turnMarkerBase && this.tail === ''
        ? Date.now() - this.turnStartedAt
        : 0
      if (idleMs >= 800) activityLines = [`·· thinking… ${Math.floor(idleMs / 1000)}s`]
    }
    // Pinned panels (todo + jobs): bottom of the view, DIRECTLY above the
    // activity row — streaming content can never push them into the chat
    // middle, and they never cover the thinking line.
    const panelLines = [...this.jobsLiveRows, ...this.todoLiveRows]
    // restTail is the text BEFORE the promoted progress block: emitting
    // progressLines first inverted every message's block order for the
    // whole time any step was incomplete.
    const raw = [...this.base, ...restTail, ...progressLines, ...panelLines, ...activityLines]
    // Raw-line → rendered-row mapping (interactive cards need their
    // POST-transform rows: tables expand, fences collapse — base offsets
    // alone cannot be trusted).
    const rowStartOfRaw: number[] = new Array(raw.length).fill(0)

    // Parse the full view (cheap string ops) so every flush's buffer content
    // is the stripped text with consistent spans. Markdown tables become
    // bordered, aligned blocks (Claude-TUI style).
    const parsed: Array<{ text: string; spans: Span[]; group?: string | null | undefined }> = []
    // Syntax-highlight sources: fenced code (```lang) and diff blocks (lang
    // inferred from the ✎ header path). Rows = final buffer rows (0-based).
    // Diff rows keep their tokens: the row group carries ONLY the background
    // tint (see applyDimPalette), so token colors never fight a row fg.
    const codeBlocks: Array<{ lang: string; row: number; col: number; lines: string[] }> = []
    let fenceOpen = false
    let fenceLang = ''
    let fenceRow = -1
    let fenceCode: string[] = []
    let lastDiffPath = ''
    let diffRegion = false // a ✎ header opened a diff block (styling gate)
    let diffRow = -1
    let diffCode: string[] = []
    let diffHasChange = false // a real +/- line was collected (stripped code
    // rarely starts with +/-, so the code itself cannot be the signal)
    const closeDiffBlock = (): void => {
      if (diffRow >= 0 && diffHasChange) {
        const lang = lastDiffPath.match(/\.([A-Za-z0-9_+-]+)$/)?.[1] ?? ''
        if (lang !== '' && diffCode.length <= 200 &&
          diffCode.reduce((n, l) => n + l.length, 0) <= 20000) {
          codeBlocks.push({ lang, row: diffRow, col: 2, lines: diffCode })
        }
      }
      diffRow = -1
      diffCode = []
      diffHasChange = false
      diffRegion = false
    }
    // streamOpen: the last line may still grow — the answer tail, or the
    // inline reasoning tail in read-only replays (an open table block there
    // must keep its bottom border off until the stream closes). The trailing
    // activity rows are transparent to the open-table check: a table that
    // ends right before them is still the "last" content block.
    const streamOpen = this.tail !== '' ||
      (this.reasoningBuf === null && this.inlineReasoning && this.reasoningTail !== '')
    // Index loop over the raw view (not a transformTables pre-pass): table
    // detection shares THIS loop's fence/diff state machine. A pre-pass
    // desyncs on fence markers inside verbatim diff rows — one odd ` ```
    // ` inside a diff card left the transform's fenceOpen stuck, and every
    // markdown table below it rendered raw.
    const trailingStatic = activityLines.length
    for (let i = 0; i < raw.length; i++) {
      rowStartOfRaw[i] = parsed.length
      const line = raw[i] ?? ''
      // File-change diff lines: verbatim text (file content IS code — no
      // markdown stripping) with a whole-line add/del/tool color group.
      // Diff styling applies ONLY inside a real diff region — one opened by
      // the ✎ header and still active. A stray '- ' bullet or '+ ' line in
      // ordinary content (markdown lists, git log output…) must render as
      // plain text, never as a red/green filled diff row.
      if (diffRegion && (line.startsWith('+ ') || line.startsWith('- '))) {
        if (diffRow === -1) diffRow = parsed.length
        diffHasChange = true
        diffCode.push(line.slice(2))
        parsed.push({ text: line, spans: [], group: line.startsWith('+ ') ? 'DshTuiDiffAdd' : 'DshTuiDiffDel' })
        continue
      }
      if (DIFF_HEADER_RE.test(line)) {
        closeDiffBlock()
        diffRegion = true
        lastDiffPath = DIFF_HEADER_RE.exec(line)?.[1] ?? ''
        parsed.push({ text: line, spans: [], group: 'DshTuiTool' })
        continue
      }
      if (diffRegion) {
        if (line.startsWith('  ')) {
          // Context rows collect into the syntax block too — the block's
          // START must anchor at the FIRST collected row (context before the
          // first +/− line included), or every token lands shifted down by
          // the leading-context count.
          if (diffRow === -1) diffRow = parsed.length
          diffCode.push(line.slice(2))
          // Context rows are diff content and render VERBATIM like the +/−
          // rows: they must never reach the markdown parser or the table
          // detector below. A context line holding a fence marker (e.g.
          // `  ``` ` from a code block inside an edited README) would
          // otherwise match FENCE_RE and toggle the view's fence state —
          // turning EVERYTHING below the diff card sky-blue DshTuiCode
          // until the missing fence partner; a context row shaped like a
          // table row (`  | a | b |` from an edited markdown table) would
          // be re-rendered as a border table while the diff state machine
          // missed it.
          parsed.push({ text: line, spans: [], group: 'DshTuiAssistant' })
          continue
        } else {
          // The first non-context line CLOSES the region, then falls
          // through and is re-evaluated as an ordinary line — including the
          // table detector below (a markdown table right after a diff card
          // still renders bordered).
          closeDiffBlock()
        }
      }
      // Table block: only outside code fences AND outside diff regions (the
      // diff branch above closed the region before we get here, and context
      // rows continued — their `| a | b |` shapes render verbatim by design).
      if (!fenceOpen && isTableRow(line)) {
        let j = i
        while (j < raw.length && isTableRow(raw[j] ?? '')) j++
        const block = raw.slice(i, j)
        if (block.length >= 2 && isSeparator(block[1] ?? '')) {
          const closed = j < raw.length - trailingStatic || !streamOpen
          for (const r of renderTable(block, closed, this.lastWinW)) {
            parsed.push({ text: r.text, spans: r.spans, group: r.group })
          }
          i = j - 1
          continue
        }
      }
      // Role from the RAW line (markup stripping must not erase the prefix);
      // assistant-only lines are quote-aware (blockquote `> ` → DshTuiQuote).
      const role = ROLE_BY_PREFIX.find(([re]) => re.test(line))?.[1]
      const p = FeedRenderer.parseLine(line, fenceOpen, role === undefined)
      if (p.fenceToggled) {
        if (!fenceOpen) {
          fenceLang = /^```(\S*)/.exec(line)?.[1] ?? ''
          fenceRow = parsed.length + 1 // the code starts on the NEXT row
          fenceCode = []
          // Raw ``` markers never reach the chat: the opening fence renders
          // as a dim language chip, the closing one as a blank row
          // (Claude-style) — the code itself stays a verbatim highlighted
          // block between them.
          parsed.push({ text: fenceLang !== '' ? `▸ ${fenceLang}` : '', spans: [], group: 'DshTuiNotice' })
        } else {
          if (fenceLang !== '' && fenceCode.length > 0 &&
            fenceCode.length <= 200 &&
            fenceCode.reduce((n, l) => n + l.length, 0) <= 20000) {
            codeBlocks.push({ lang: fenceLang, row: fenceRow, col: 0, lines: fenceCode })
          }
          parsed.push({ text: '', spans: [], group: undefined })
        }
        fenceOpen = !fenceOpen
        continue
      }
      if (fenceOpen) {
        fenceCode.push(line)
      }
      p.group = p.code
        ? 'DshTuiCode'
        : (p.group ?? role ?? 'DshTuiAssistant')
      parsed.push(p)
    }
    closeDiffBlock()
    // LAST-LINE-OF-DEFENSE: nvim's nvim_buf_set_lines/nvim_buf_set_text reject
    // any line containing "\n" ("replacement string item contains newlines"),
    // which kills the WHOLE render pipeline (E5108) until the next clean
    // flush. Host/model-provided text (workflow phase titles, stopReason,
    // error details, ext-card action labels) is only folded at SOME entry
    // points, so sanitize every final row here.
    const lines = parsed.map((p) => p.text.replace(/\r?\n/g, ' '))

    // Blue whale pixel art: the empty state is a hero block — big banner +
    // title ABOVE, the animated whale (wink / bubbles / bob cycle) in the
    // MIDDLE, usage hints BELOW — vertically centered as one unit. Once
    // content exists there is NO watermark; the statusline running badge
    // carries the emoji animation instead (its own timer). Each half-block
    // glyph carries a per-span color group (fg/bg pixel pair).
    if (this.whale) {
      // A feed holding ONLY notice lines (the boot banner, "session X"
      // notices, /clear) is still EMPTY: the hero + whale render and the
      // notices ride below the block. Any real content (user/assistant
      // lines) hides them.
      const nonEmpty = lines.filter((l) => l.trim() !== '')
      const contentLines = nonEmpty.filter((l) => !l.startsWith('· '))
      if (contentLines.length === 0) {
        const { h, w } = await this.winSize()
        const hero = this.welcome?.() ?? {}
        const above = hero.above ?? []
        const below = hero.below ?? []
        // Animate at the width tier the hero will actually render.
        const art = whaleRowsIndented(w, whaleFrames(w)[this.whaleFrame] ?? [])
        const whaleRows = art ?? []
        const block: Array<{ text: string; spans: Span[]; group?: string | undefined }> = []
        for (const l of above) block.push({ text: l.text, spans: [], group: l.group })
        if (above.length > 0 && whaleRows.length > 0) block.push({ text: '', spans: [], group: undefined })
        for (const r of whaleRows) block.push({ text: r.text, spans: r.spans, group: undefined })
        if (below.length > 0 && (above.length > 0 || whaleRows.length > 0)) block.push({ text: '', spans: [], group: undefined })
        for (const l of below) block.push({ text: l.text, spans: [], group: 'DshTuiNotice' })
        // Vertical centering of the whole block (whale sits mid-screen).
        const topPad = Math.max(0, Math.floor((h - block.length) / 2))
        lines.length = 0
        parsed.length = 0
        for (let i = 0; i < topPad; i++) {
          lines.push('')
          parsed.push({ text: '', spans: [], group: undefined })
        }
        for (const b of block) {
          lines.push(b.text)
          parsed.push({ text: b.text, spans: b.spans, group: b.group })
        }
        // The banner/notices stay visible at the bottom of the hero.
        for (const l of nonEmpty) {
          lines.push(l)
          parsed.push({ text: l, spans: [], group: 'DshTuiNotice' })
        }
        this.ensureWhaleTicker()
      } else {
        this.stopWhaleTicker()
      }
    } else {
      this.stopWhaleTicker()
    }

    // Ext-card rendered rows (computed BEFORE the diff — the hero path can
    // rewrite `parsed`, but cards are content and exclude the hero anyway).
    const newCardRows = new Map<string, { startRow: number; endRow: number }>()
    for (const [cardId, rec] of this.extCards) {
      if (rec.length <= 0) continue
      const first = rowStartOfRaw[rec.start] ?? 0
      const afterEnd = rec.start + rec.length
      const endRow = (afterEnd < raw.length ? (rowStartOfRaw[afterEnd] ?? parsed.length) : parsed.length) - 1
      if (endRow >= first) newCardRows.set(cardId, { startRow: first, endRow })
    }

    // Diff against the last flushed view: tables expand blocks (3 raw lines
    // → 5 bordered lines), so row positions cannot be tracked by base length.
    const lastView = this.lastView ?? []
    // The previous activity rows (·· thinking… / 🔧 running tool) were
    // TRANSIENT — the diff must only consider the COMMITTED prefix. Without
    // this, any content change under them (an echoed user bubble, a notice)
    // rewrites them as real buffer rows and the next tick stacks ANOTHER
    // thinking line into the chat.
    const prevActivity = this.lastActivityCount ?? 0
    const committedEnd = Math.max(0, lastView.length - prevActivity)
    let startRow = 0
    while (startRow < lines.length && startRow < committedEnd &&
      lines[startRow] === lastView[startRow]) {
      startRow++
    }
    this.lastActivityCount = activityLines.length
    // Nothing changed at all? Only the panel may still need a sync (its
    // streaming tail can keep growing while the chat line is unchanged).
    const unchanged = startRow === lines.length && lines.length === lastView.length
    // Exactly ONE changed row at the tail (the streaming answer / the ticking
    // "thinking…" activity line) → rewrite it IN PLACE: no delete+insert row
    // churn and no clear+readd highlight pass, which is what made the line
    // flicker during thinking.
    const inPlaceRow = !unchanged && startRow === lines.length - 1 &&
      lines.length === lastView.length && lines.length > 0
      ? startRow
      : -1
    this.lastView = lines

    this.flushing = (async () => {
      if (this.ns === null) {
        this.ns = await this.nvim.request('nvim_create_namespace', ['dsh-tui-feed']) as number
      }
      if (unchanged) {
        await this.flushReasoningBuffer()
        return
      }
      if (inPlaceRow >= 0) {
        await this.nvim.request('nvim_buf_set_text',
          [this.bufId, inPlaceRow, 0, inPlaceRow, -1, [lines[inPlaceRow]]])
        await this.flushReasoningBuffer()
        // Refresh only this row's highlights (its inline spans may shift as
        // the text grows). One Lua RPC, no row churn.
        const p = parsed[inPlaceRow]
        await this.nvim.lua(`
          local buf, ns, row, group, spans = ...
          vim.api.nvim_buf_clear_namespace(buf, ns, row, row + 1)
          if type(group) == 'string' and group ~= '' then
            local line = vim.api.nvim_buf_get_lines(buf, row, row + 1, false)[1] or ''
            vim.api.nvim_buf_set_extmark(buf, ns, row, 0,
              { end_row = row, end_col = #line, hl_group = group, priority = 4096 })
          end
          for _, sp in ipairs(spans or {}) do
            if type(sp.group) == 'string' then
              vim.api.nvim_buf_set_extmark(buf, ns, row, sp.s,
                { end_row = row, end_col = sp.e, hl_group = sp.group, priority = 4096 })
            end
          end
        `, [this.bufId, this.ns, inPlaceRow, p?.group ?? '', p?.spans ?? []])
        // (No token pass here: a code block's tokens are registered when its
        //  CLOSING fence arrives, so the single-row rewrite can never own a
        //  block — the old `filter(b => b.row === inPlaceRow)` was dead. The
        //  next full pass applies the syntax tokens.)
        // The line count did not change — no cursor move, nothing else to do.
        return
      }

      await this.nvim.request('nvim_buf_set_lines', [this.bufId, startRow, -1, false, lines.slice(startRow)])
      await this.flushReasoningBuffer()

      // One Lua RPC for the whole highlight pass over the changed rows.
      // (group: '' not null — msgpack turns null into truthy vim.NIL userdata.)
      // Row groups are EXPLICIT same-row ranges (end_col = line byte length):
      // nvim 0.12's real TUI does NOT draw `hl_eol` marks (zero-width end),
      // which made every chat line render in plain Normal (white) after the
      // in-place update work. nvim_buf_add_highlight ranges extend into the
      // next row and get wiped by the next clear_namespace (range
      // intersection), so same-row ranges are the one geometry that both
      // renders and survives clearing.
      if (startRow < lines.length) {
        // OVERLAP (not b.row >= startRow): a code block registered when its
        // closing fence arrives STARTED above the changed window, so a
        // start-row filter never matched it and streamed code stayed
        // unhighlighted forever.
        const tokenBlocks = codeBlocks.filter((b) => b.row + b.lines.length >= startRow && b.row <= lines.length)
        const rows = parsed.slice(startRow).map((p) => ({
          group: p.group ?? '',
          spans: p.spans,
        }))
        await this.nvim.lua(`
          local buf, ns, start, rows = ...
          vim.api.nvim_buf_clear_namespace(buf, ns, start, -1)
          for i, r in ipairs(rows) do
            local row = start + i - 1
            if type(r.group) == 'string' and r.group ~= '' then
              local line = vim.api.nvim_buf_get_lines(buf, row, row + 1, false)[1] or ''
              vim.api.nvim_buf_set_extmark(buf, ns, row, 0,
                { end_row = row, end_col = #line, hl_group = r.group, priority = 4096 })
            end
            for _, sp in ipairs(r.spans or {}) do
              if type(sp.group) == 'string' then
                vim.api.nvim_buf_set_extmark(buf, ns, row, sp.s,
                  { end_row = row, end_col = sp.e, hl_group = sp.group, priority = 4096 })
              end
            end
          end
        `, [this.bufId, this.ns, startRow, rows])
        if (tokenBlocks.length > 0) {
          if (this.tokenNs === null) {
            this.tokenNs = await this.nvim.request('nvim_create_namespace', ['dsh-tui-feed-ts']) as number
          }
          await this.nvim.lua(`
            local buf, ns, start, blocks = ...
            vim.api.nvim_buf_clear_namespace(buf, ns, start, -1)
            require("dsh_tui").highlight_syntax(buf, ns, blocks)
          `, [this.bufId, this.tokenNs, startRow, tokenBlocks])
        }
      }

      if (this.activeChecker()) {
        // Fire-and-forget: a wedged cursor RPC must never block the feed.
        void this.moveCursor(lines.length)
      }
      // Interactive-card marks (P4-③): one block extmark per card covering
      // its RENDERED rows, so the chat keymaps can resolve cursor → card.
      await this.syncCardMarks(newCardRows).catch(() => {})
    })()
    try {
      await this.flushing
    } catch (err) {
      // A failed RPC leaves the buffer stale while lastView claims the new
      // content — reset it so the next flush rewrites in full (self-healing).
      this.lastView = []
      throw err
    } finally {
      this.flushing = null
      if (this.dirty) {
        this.dirty = false
        void this.flush()
      } else if (this.reasoningTail !== '' || this.toolActivity !== null ||
        this.subagents.size > 0 ||
        (this.turnStartedAt !== null &&
          this.base.length === this.turnMarkerBase &&
          this.tail === '')) {
        // The turn is silent — keep the "thinking…" placeholder ticking; a
        // running subagent keeps its activity line ticking too.
        this.ticker = setTimeout(() => {
          this.ticker = null
          this.schedule()
        }, 500)
      }
    }
  }

  /** Sync the activity panel (reasoning + tools) for this session.
   *  A wiped panel buffer (external :bwipe etc.) must never kill the chat
   *  flush — the panel is auxiliary, the transcript is not. */
  async flushReasoningBuffer(): Promise<void> {
    if (this.reasoningBuf === null) return
    try {
      await this.flushReasoningBufferInner()
      this.reasoningFailures = 0
    } catch {
      // The reasoning buffer can be wiped/rebuilt underneath us (Lua
      // ensure_reasoning mints a new buffer for a dead id). Swallowing this
      // left the panel permanently stale with `panelFlushed` stuck at an old
      // watermark and no diagnostic — re-resolve the id and force a full
      // repaint instead, and surface a one-time notice if it stays broken.
      this.reasoningFailures++
      if (this.reasoningFailures <= 2) {
        try {
          const ids = await this.idsProvider?.() as { reasoningBuf?: unknown } | null | undefined
          const next = ids?.reasoningBuf
          if (typeof next === 'number' && next !== this.reasoningBuf) {
            this.reasoningBuf = next
            this.panelFlushed = 0
            this.panelVersion++
          }
        } catch {}
      } else if (this.reasoningFailures === 3) {
        this.base.push('', t('⚠ 推理面板已失效（缓冲被重建）——后续内容只在对话区显示'))
        this.schedule()
      }
    }
  }

  async flushReasoningBufferInner(): Promise<void> {
    const buf = this.reasoningBuf as number
    const ns = this.ns as number
    const streaming = this.reasoningTail === ''
      ? []
      : ['·· thinking', ...this.reasoningTail.split('\n')]
    const full = [...this.panelLines, ...streaming]
    const committed = this.panelLines.length
    // Markdown tables in the reasoning panel: transform the whole view (the
    // chat path already does this). Table blocks EXPAND to bordered rows,
    // which breaks the incremental paths' one-raw-line = one-buffer-row
    // assumption — their presence switches this flush to a full rewrite.
    // The width cap = the panel window's real width (its clamp is 30..52),
    // so overwide tables wrap inside the panel instead of soft-wrapping
    // against its edge. Throttled probe: a per-flush width RPC would tax
    // the streaming path.
    if (Date.now() - this.lastPanelAt > 2000) {
      this.lastPanelAt = Date.now()
      const view0 = this.reasoningView?.()
      if (view0?.win != null && typeof view0.win === 'number') {
        void this.nvim.request('nvim_win_get_width', [view0.win])
          .then((w: number) => { this.lastPanelW = w })
          .catch(() => {})
      }
    }
    const entries = transformTables(full, this.reasoningTail !== '', 0, this.lastPanelW)
    if (entries.some((e) => e.table)) {
      const rows = entries.map((e) => (e.table ? e.text : e.raw))
      const groups = entries.map((e) =>
        e.table
          ? (e.group ?? 'DshTuiBold')
          : (ROLE_BY_PREFIX.find(([re]) => re.test(e.raw))?.[1] ?? 'DshTuiAssistant'))
      await this.nvim.request('nvim_buf_set_lines', [buf, 0, -1, false, rows])
      this.panelFlushed = rows.length
      this.lastPanelVersion = this.panelVersion
      await this.nvim.lua(`
        local buf, ns, groups = ...
        vim.api.nvim_buf_clear_namespace(buf, ns, 0, -1)
        for i, g in ipairs(groups) do
          if type(g) == 'string' and g ~= '' then
            local line = vim.api.nvim_buf_get_lines(buf, i - 1, i, false)[1] or ''
            vim.api.nvim_buf_set_extmark(buf, ns, i - 1, 0,
              { end_row = i - 1, end_col = #line, hl_group = g, priority = 4096 })
          end
        end
      `, [buf, ns, groups])
      // Auto-scroll while the panel is open and this session is the active one.
      const view = this.reasoningView()
      if (view?.open && Number.isInteger(view.win) && this.activeChecker() && this.panelFlushed > 0) {
        void this.nvim.request('nvim_win_set_cursor', [view.win, [this.panelFlushed, 0]]).catch(() => {})
      }
      return
    }
    // Streaming-only flush: everything committed is already in the buffer and
    // only the live tail grows. Rewrite the tail rows IN PLACE (the last
    // flushed row may still be growing) + append genuinely new rows, then
    // refresh ONLY those rows' dim group marks. Two failure modes fixed here:
    //  - a delta with an embedded newline grows the previous last row AND
    //    appends rows, so appending full.slice(panelFlushed) alone left the
    //    grown row's text stale in the buffer;
    //  - extmark end_cols are frozen once set (the end mark is left-gravity),
    //    so an in-place rewrite must re-apply the group over the FULL new
    //    line — otherwise the freshly streamed tail renders unhighlighted,
    //    i.e. pure white on the theme's Normal instead of dim.
    if (streaming.length > 0 && this.panelFlushed >= committed &&
      this.panelVersion === this.lastPanelVersion) {
      const startRow = this.panelFlushed > 0 ? this.panelFlushed - 1 : 0
      const rows = full.slice(startRow)
      const groups = rows.map((l) =>
        ROLE_BY_PREFIX.find(([re]) => re.test(l))?.[1] ?? 'DshTuiAssistant')
      await this.nvim.lua(`
        local buf, ns, start, rows, groups = ...
        local lineCount = vim.api.nvim_buf_line_count(buf)
        -- Overlapping rows are rewritten in place (no row churn); the rest
        -- are appended. set_lines pads if the panel buffer was re-created.
        local overlap = math.max(0, math.min(#rows, lineCount - start))
        for i = 1, overlap do
          vim.api.nvim_buf_set_text(buf, start + i - 1, 0, start + i - 1, -1, { rows[i] })
        end
        if #rows > overlap then
          local rest = {}
          for i = overlap + 1, #rows do rest[#rest + 1] = rows[i] end
          vim.api.nvim_buf_set_lines(buf, start + overlap, -1, false, rest)
        end
        -- Row-scoped highlight refresh over the FULL new lines. Marks above
        -- 'start' are untouched (clear_namespace intersects by line range).
        vim.api.nvim_buf_clear_namespace(buf, ns, start, -1)
        for i, r in ipairs(rows) do
          local group = groups[i]
          if type(group) == 'string' and group ~= '' then
            vim.api.nvim_buf_set_extmark(buf, ns, start + i - 1, 0,
              { end_row = start + i - 1, end_col = #r, hl_group = group, priority = 4096 })
          end
        end
      `, [buf, ns, startRow, rows, groups])
      this.panelFlushed = full.length
      // Auto-scroll while the panel is open and this session is the active one.
      const view = this.reasoningView()
      if (view?.open && Number.isInteger(view.win) && this.activeChecker() && this.panelFlushed > 0) {
        void this.nvim.request('nvim_win_set_cursor', [view.win, [this.panelFlushed, 0]]).catch(() => {})
      }
      return
    }
    // Structural change (turn boundary, committed block, first write…):
    // rewrite from ONE row before the flushed watermark — the last flushed
    // row may still be growing (streaming continuation) — append-only would
    // freeze truncated fragments.
    const startRow = this.panelFlushed > 0 ? this.panelFlushed - 1 : 0
    if (full.length > this.panelFlushed || startRow === 0 || this.panelVersion !== this.lastPanelVersion) {
      if (full.length >= startRow || startRow === 0) {
        await this.nvim.request('nvim_buf_set_lines', [buf, startRow, -1, false,
          full.slice(startRow)])
        this.panelFlushed = full.length
        this.lastPanelVersion = this.panelVersion
      }
      // Dim headers/footers in the panel (one Lua RPC).
      const rows = full.slice(startRow).map((l) => ({
        group: ROLE_BY_PREFIX.find(([re]) => re.test(l))?.[1] ?? 'DshTuiAssistant',
        spans: [],
      }))
      await this.nvim.lua(`
        local buf, ns, start, rows = ...
        vim.api.nvim_buf_clear_namespace(buf, ns, start, -1)
        for i, r in ipairs(rows) do
          if type(r.group) == 'string' and r.group ~= '' then
            local row = start + i - 1
            local line = vim.api.nvim_buf_get_lines(buf, row, row + 1, false)[1] or ''
            vim.api.nvim_buf_set_extmark(buf, ns, row, 0,
              { end_row = row, end_col = #line, hl_group = r.group, priority = 4096 })
          end
        end
      `, [buf, ns, startRow, rows])
    }
    // Auto-scroll while the panel is open and this session is the active one.
    const view = this.reasoningView()
    if (view?.open && Number.isInteger(view.win) && this.activeChecker() && this.panelFlushed > 0) {
      void this.nvim.request('nvim_win_set_cursor', [view.win, [this.panelFlushed, 0]]).catch(() => {})
    }
  }

  async moveCursor(lineCount: number): Promise<void> {
    try {
      await this.nvim.request('nvim_win_set_cursor', [this.winId, [lineCount, 0]])
    } catch {
      // The Lua side may have re-claimed its layout (window ids changed);
      // refresh ids once and retry.
      if (this.idsProvider) {
        try {
          const ids = await this.idsProvider() as { chatWin?: number } | null | undefined
          if (ids?.chatWin) {
            this.winId = ids.chatWin
            await this.nvim.request('nvim_win_set_cursor', [this.winId, [lineCount, 0]])
          }
        } catch {}
      }
    }
  }
}
