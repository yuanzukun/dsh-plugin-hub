/** dsh_tui sessions module SERVICES: session lifecycle + fork (shared by
 *  the command files, the slots and the boot sequence). */
import { randomUUID } from 'node:crypto'
import { resolve } from 'node:path'
import { installModelSelection } from '@deepseek-ai/dsh-agent'
import { installTodoGuard } from '../kernel/todo-guard.js'
import { uiPref } from './prefs.js'
import { FeedRenderer } from '../feed/feed.js'
import { statSync } from 'node:fs'
import { t, tf } from '../kernel/i18n.js'
import { BUILD_STAMP, BUILD_VERSION } from '../kernel/app.js'
import type { AgentHandle, SessionEvent } from '../kernel/types.js'
import type { App, AppSlices, ModelRef, WritableSlice } from '../kernel/app.js'
const WSS = (d: AppSlices['sessions']) => d as WritableSlice<AppSlices['sessions']>

/** /todo 清单纪律守卫开关（默认开；config.todoGuard=false 或 DSH_NVIM_TUI_TODO_GUARD=0 关闭）。 */
const todoGuardEnabled = (app: App): { enabled: boolean; onError: (stage: string, err: unknown) => void } => ({
  enabled: app.config.todoGuard !== false && process.env['DSH_NVIM_TUI_TODO_GUARD'] !== '0',
  // A silently-failing guard registration would remove the whole feature.
  onError: (stage, err) => app.exitDiag(`todo-guard-${stage}`, err instanceof Error ? err.message : String(err)),
})

export const attachSession = async (app: App, handle: AgentHandle, modelRef: ModelRef, opts?: { background?: boolean }) => {
  const id = handle.agent.session.id
  const ids = await app.lua.ensureChat(id)
  // Background resume (row actions like rename) must NOT touch the global
  // view state — the active session owns the visible chat/reasoning
  // pointers; writing them here used to point the active view at the
  // background session's buffers.
  if (opts?.background !== true) {
    app.slices.runtime.setChatWin(ids.chatWin)
  }
  const rids = await app.lua.ensureReasoning(id)
  if (opts?.background !== true) {
    app.slices.runtime.setReasoning(rids?.reasoningOpen === true, (rids?.reasoningWin ?? null) as number | null)
  }
  const feed = new FeedRenderer(app.slices.runtime.nvim!, ids.chatBuf, ids.chatWin, {
    idsProvider: () => app.luaCall('return require("dsh_tui").ensure_chat(...)', [id]),
    activeChecker: () => id === app.slices.sessions.activeId,
    reasoningBuf: rids?.reasoningBuf ?? null,
    reasoningView: () => ({ open: app.slices.runtime.reasoningOpen, win: app.slices.runtime.reasoningWinId }),
    whale: app.config['whaleArt'] !== 'off',
    welcome: welcomeLines,
  })
  app.slices.sessions.live.set(id, {
    id, handle, feed, title: undefined, status: undefined, modelRef,
    model: modelRef?.current ? modelRef.current.model : undefined,
    createdAt: handle.agent.session.header?.createdAt ?? Date.now(),
    usage: undefined,
    contextWindow: undefined,
    mode: undefined,
    policy: undefined,
    provider: undefined,
    cacheReported: false,
    lastAssistantMessageId: null,
    goal: null,
    planActive: false,
    imagePoisonWarned: false,
    deliverables: { turn: undefined, paths: [] },
    todos: null,
    todosItems: [],
    jobsCache: new Map(),
    committedJobsKey: '',
    committedJobKeys: new Set(),
    pendingToolCalls: new Map(),
    visionTmp: null,
    difficulty: { tier: null, pinned: null, enabled: true, tmp: null, pending: null, source: null, syncedRoutesKey: null },
    toolErrors: 0,
    lastTurnStartAt: 0,
    bgJobs: 0,
  })
  // Restore the persisted /density preference for the new feed.
  try {
    if (uiPref<boolean>(app, 'dense') === true) feed.dense = true
  } catch {}
  // Notices buffered during the startup window (no active session yet) land
  // here, ahead of the banner, so real failures are never lost.
  app.flushPendingNotices(feed)
  // Boot banner: version + build stamp + channel (proves which code runs).
  feed.appendNotice(`dsh-nvim-tui ${BUILD_VERSION} (build ${BUILD_STAMP}) · channel ${app.slices.runtime.channelIdValue}`)
  // Heal a poisoned session (a scheduler crash left a tool/call with no
  // tool/result → the DeepSeek API rejects every later request with
  // "insufficient tool messages following tool_calls message"): synthesize
  // the missing error results once at open so the history re-pairs.
  try {
    const rec = app.slices.sessions.live.get(id)
    if (rec !== undefined) {
      const repaired = app.slices.trans.repairOrphanToolCalls(rec)
      if (repaired > 0) {
        feed.appendNotice(`♻ ${t('已修复')} ${repaired} ${t('处损坏的工具调用记录——会话此前因 "insufficient tool messages" 被 400 拒绝的问题已解除')}`)
      }
    }
  } catch {}
  return id
}

/** Empty-state hero: big DSH·TUI banner + title ABOVE the whale, usage
 *  hints BELOW it (the feed centers the whole block). */

export const createSession = async (app: App, cwdPath?: string) => {
  const selection = app.slices.agent.currentSelection()
  const modelRef = { current: selection, assembled: void 0 }
  let cwd = process.cwd()
  if (cwdPath) {
    const abs = resolve(cwdPath)
    try {
      if (!statSync(abs).isDirectory()) throw new Error(t('不是目录'))
      cwd = abs
    } catch (err) {
      app.notice(tf('无效目录 {0}: {1}', [cwdPath, (err as Error).message]))
      return
    }
  }
  const handle = await app.runtimeCtx.agents.create({
    sessionId: `session-${randomUUID()}`,
    meta: { cwd },
    agentOptions: {
      provider: selection.provider,
      model: selection.model,
    },
    setup: (agentCtx) => {
      installModelSelection(agentCtx, modelRef as unknown as Parameters<typeof installModelSelection>[1])
      installTodoGuard(agentCtx, todoGuardEnabled(app))
    },
  })
  let id: string
  try {
    id = await attachSession(app, handle, modelRef)
  } catch (err) {
    // A half-mounted attach must not leak the freshly created agent.
    await rollbackAttach(app, handle.agent.session.id, handle)
    throw err
  }
  await switchTo(app, id)
  app.slices.sessions.refreshList()
  void app.refreshCommandCatalog()
  app.notice(`session ${id} (${selection.provider}/${selection.model}${cwdPath ? ` · ${cwd}` : ''})`)
  return id
}

/** Resume a persisted session, replay its history into the chat. */
/** Resume a persisted session WITHOUT switching the active view — used by
 *  row actions (e.g. rename) that need a live session but must not move the
 *  user away from the current chat. Returns the live id, or undefined. */

/** In-flight resume dedupe: a concurrent second caller for the same id must
 *  await the SAME resume instead of racing a second agents.resume past the
 *  live.has check (pre-review: double live records, a leaked first
 *  AgentHandle, and two FeedRenderers writing the same buffers). */
const resuming = new Map<string, Promise<string | undefined>>()

/** In-flight disposes: `agents.resume` on an id whose AgentHandle is still
 *  being disposed hits the host's `session "…" already exists` guard, so a
 *  reopen must WAIT for the dispose instead of racing it. */
const disposing = new Map<string, Promise<void>>()

export const ensureLiveSession = async (app: App, id: string): Promise<string | undefined> => {
  // Wait out an in-flight dispose of the same id BEFORE the live check —
  // the record is deleted only once its handle is really gone.
  const pendingDispose = disposing.get(id)
  if (pendingDispose !== undefined) {
    try { await pendingDispose } catch {}
  }
  if (app.slices.sessions.live.has(id)) return id
  const inflight = resuming.get(id)
  if (inflight !== undefined) return inflight
  const p = doResumeSession(app, id).finally(() => {
    if (resuming.get(id) === p) resuming.delete(id)
  })
  resuming.set(id, p)
  return p
}

const doResumeSession = async (app: App, id: string): Promise<string | undefined> => {
  const selection = app.slices.agent.currentSelection()
  const modelRef = { current: selection, assembled: void 0 }
  const handle = await app.runtimeCtx.agents.resume({
    resumeSessionId: id,
    agentOptions: {
      provider: selection.provider,
      model: selection.model,
    },
    setup: (agentCtx) => {
      installModelSelection(agentCtx, modelRef as unknown as Parameters<typeof installModelSelection>[1])
      installTodoGuard(agentCtx, todoGuardEnabled(app))
    },
  })
  const sid = await attachSession(app, handle, modelRef, { background: true })
  const rec = app.slices.sessions.live.get(sid)!
  try {
    const events = app.slices.trans.sessionEvents(handle.agent.session)
    rec.feed.appendNotice(`history replay: ${events.length} events`)
    for (const event of events) {
      // The replay path bypasses boot/session-events' hook table, so replay
      // the hooks the UI depends on for RESTORED state — the title is a log
      // event in 0.1.5 (session/title) and used to be lost on resume.
      if (event.type === 'session/title') {
        const d = event.data as { title?: unknown } | undefined
        if (typeof d?.title === 'string' && d.title !== '') rec.title = d.title
      }
      app.slices.ui.foldEvent(rec, event)
      rec.feed.applyEvent(event, { history: true })
      app.slices.ui.maybePushFileDiff(rec.feed, event)
    }
  } catch (err) {
    // A failed replay used to leave a HALF-MOUNTED record behind: `live` kept
    // the broken session, `ensureLiveSession`'s early return then handed it
    // back forever (the session could never be opened again), and the agent
    // handle leaked. Roll the whole attach back and rethrow for the caller's
    // fallback path.
    app.exitDiag('resume-replay-failed', (err as Error).message)
    await rollbackAttach(app, sid, handle)
    throw err
  }
  app.slices.sessions.refreshList()
  return sid
}

/** Undo a half-mounted attach: drop the live record, dispose the handle and
 *  reclaim the nvim chat buffer. Best-effort — never throws. */
const rollbackAttach = async (app: App, sid: string, handle: { dispose: () => Promise<unknown> }): Promise<void> => {
  try { app.slices.sessions.live.delete(sid) } catch {}
  try { await handle.dispose() } catch (err) { app.exitDiag('rollback-dispose-failed', (err as Error).message) }
  void app.luaCall('return require("dsh_tui").close_chat(...)', [sid]).catch(() => {})
}

/** Dispose one live session that is NOT the active view (background-resumed
 *  sessions must not accumulate forever — each holds an agent handle, a feed
 *  and nvim chat/reasoning buffers). */
export const disposeLiveSession = async (app: App, id: string): Promise<void> => {
  if (id === app.slices.sessions.activeId) return
  const rec = app.slices.sessions.live.get(id)
  if (rec === undefined) return
  const p = (async (): Promise<void> => {
    // DISPOSE FIRST, delete after: deleting the record up front exposed a
    // window where a reopen resumed the still-registered session and hit the
    // host's `session "…" already exists` guard (plus two FeedRenderers on
    // one buffer).
    try {
      await rec.handle.dispose()
    } catch (err) {
      app.exitDiag('disposeLiveSession', (err as Error).message)
    }
    app.slices.sessions.live.delete(id)
    // Reclaim the chat buffer on the nvim side (runner-side LRU close_chat).
    void app.luaCall('return require("dsh_tui").close_chat(...)', [id]).catch(() => {})
    app.slices.sessions.refreshList()
  })()
  disposing.set(id, p)
  try {
    await p
  } finally {
    if (disposing.get(id) === p) disposing.delete(id)
  }
}


export const resumeSession = async (app: App, id: string) => {
  const sid = await ensureLiveSession(app, id)
  if (sid === undefined) return
  await switchTo(app, sid)
  app.notice(tf('已恢复 {0}', [sid]))
  return sid
}

/** Terminal title: active session title + model (OSC 2 via nvim). */

export const switchTo = async (app: App, id: string) => {
  // Transient input-flow state is session-scoped: switching mid-flow must
  // not leak it into the new session (queued edits / rename prompts /
  // pending images / card inputs / subagent followups).
  const hadPending = app.slices.agent.pendingImages.length > 0 ||
    app.slices.agent.pendingRename !== null ||
    app.slices.agent.pendingQueueEdit !== null ||
    app.slices.agent.pendingSubagentFollowup !== null ||
    app.slices.ext.pendingCardInput !== null
  if (hadPending) app.notice(t('已切换会话（未完成的输入操作已取消）'))
  app.slices.agent.clearPendings()
  app.slices.ext.setPendingCardInput(null)
  const previous = app.slices.sessions.activeId
  WSS(app.slices.sessions).activeId = id
  // The boot-time catalog push runs before any session exists and therefore has
  // to skip the OFFICIAL commands (measured). Now that an agent IS active, pay
  // that debt — a no-op once it has been paid.
  app.retryOfficialCatalog()
  try {
    await app.lua.setActive(id)
  } catch (err) {
    // The Lua view never switched: keep the runner side consistent with what
    // the user actually sees instead of desyncing activeId from the buffer.
    app.exitDiag('switch-active-failed', (err as Error).message)
    WSS(app.slices.sessions).activeId = previous
    app.notice(tf('切换会话失败: {0}', [(err as Error).message]))
    return
  }
  // The jobs cache/badge/board belong to the ACTIVE session: without this the
  // statusline kept showing the previous session's jobs for up to 30s (the
  // idle heartbeat interval).
  app.slices.ui.refreshBgJobs()
  app.slices.ui.ensureSpinner()
  app.slices.ui.updateStatusline()
  // Sync the runtime's GLOBAL view pointers with the Lua side. The resume
  // path attaches with background:true (S6 — row actions must not move the
  // visible view), so setChatWin/setReasoning never ran for it; without this
  // sync updateStatusline early-returns (chatWinId === null) and the stats
  // bar stays blank for the whole resumed session. chatWin is the SHARED
  // chat window and reasoningWin the global panel state, so ids() (not
  // ensure_chat) is the accurate source right after set_active.
  try {
    const ids = await app.luaCall('return require("dsh_tui").ids()', []) as {
      chatWin?: unknown; reasoningOpen?: unknown; reasoningWin?: unknown
    } | null | undefined
    if (ids !== null && ids !== undefined && typeof ids === 'object') {
      if (Number.isInteger(ids.chatWin)) {
        app.slices.runtime.setChatWin(ids.chatWin as number)
      }
      app.slices.runtime.setReasoning(
        ids.reasoningOpen === true,
        Number.isInteger(ids.reasoningWin) ? (ids.reasoningWin as number) : null)
    }
  } catch { /* best-effort: the next session event re-syncs the view */ }
  app.slices.ui.ensureSpinner()
  app.slices.ui.updateStatusline()
  updateTitle(app)
  app.slices.ext.extFire('tui:active-session', { id })
  void app.slices.sessions.seedRunningSubagents(id)
  if (app.slices.sessions.live.has(id)) app.slices.sessions.recordState(id)
}


export const selectSession = async (app: App, id: string) => {
  if (app.slices.runtime.disposed) return
  if (app.slices.sessions.live.has(id)) {
    await switchTo(app, id)
    app.slices.sessions.refreshList()
  } else if (app.slices.sessions.historyHeaders.some((h) => h.id === id) || app.slices.sessions.historyById.has(id)) {
    // Any persisted project session is openable — not just the current
    // cwd's (the workspace browser lists sessions from every workspace).
    await resumeSession(app, id)
  } else {
    app.notice(tf('未知会话 {0}', [id]))
  }
}

/** /fork [directive]: child session seeded with the active history;
 *  an optional directive is sent as its first message. */

export const forkSession = async (app: App, directive: string | undefined): Promise<string | undefined> => {
  if (app.slices.sessions.activeId === null) {
    app.notice(t('没有活跃会话可分叉'))
    return
  }
  try {
    // alpha.4 fork contract (mirrors the official api-session-controller):
    // a FRESH child id + agents.create carrying a balanced completed-turn
    // seed (seed + inheritedEventCount + meta.isSeeded). The old path
    // (sessions.fork → child.events → agents.create with meta.seedLength)
    // cannot work in alpha.4: fork() enters a live child that create()
    // then collides on, and Session.events / meta.seedLength are gone.
    const parent = app.liveSessions.get(app.slices.sessions.activeId)
    const events = parent === undefined ? [] : app.slices.trans.sessionEvents(parent)
    let lastEnd: SessionEvent | undefined
    for (let i = events.length - 1; i >= 0; i--) {
      if (events[i]?.type === 'turn/end') { lastEnd = events[i]; break }
    }
    if (lastEnd === undefined) {
      app.notice(t('没有已完成的回合可分叉（请先让当前回合跑完）'))
      return
    }
    let cut = (lastEnd.seq ?? 0) + 1
    while (cut < events.length && events[cut]?.type !== 'turn/start') cut++
    const selection = app.slices.agent.currentSelection()
    const modelRef = { current: selection, assembled: void 0 }
    const handle = await app.runtimeCtx.agents.create({
      sessionId: `session-${randomUUID()}`,
      seed: events.slice(0, cut),
      inheritedEventCount: cut,
      meta: {
        cwd: parent?.header?.cwd ?? process.cwd(),
        parentSession: app.slices.sessions.activeId,
        isSeeded: true,
      },
      agentOptions: { provider: selection.provider, model: selection.model },
      setup: (agentCtx) => {
        installModelSelection(agentCtx, modelRef as unknown as Parameters<typeof installModelSelection>[1])
        installTodoGuard(agentCtx, todoGuardEnabled(app))
      },
    })
    let id: string
    try {
      id = await attachSession(app, handle, modelRef)
    } catch (err) {
      await rollbackAttach(app, handle.agent.session.id, handle)
      throw err
    }
    await switchTo(app, id)
    app.slices.sessions.refreshList()
    app.notice(tf('已分叉到 {0}（继承 {1} 条历史事件）', [id, cut]))
    if (directive && directive.trim()) app.slices.agent.send(directive.trim())
    return id
  } catch (err) {
    app.notice(tf('分叉失败: {0}', [(err as Error).message]))
    return undefined
  }
}

export const welcomeLines = (): { above: Array<{ text: string; group?: string }>; below: Array<{ text: string; group?: string }> } => {
  // 4×6 block font — bigger than the old 3×5, with real letter spacing.
  const font: Record<string, string[]> = {
    D: ['███▌', '█  █', '█  █', '█  █', '█  █', '███▌'],
    S: ['▄███▄', '███▀ ', '▀███▄', '▀  █', '▀  █', '▄███▀'],
    H: ['█  █', '█  █', '████', '█  █', '█  █', '█  █'],
    N: ['█  █', '██ █', '█ ██', '█  █', '█  █', '█  █'],
    V: ['█  █', '█  █', '█  █', '█  █', ' ██ ', ' ██ '],
    I: [' ██ ', ' ██ ', ' ██ ', ' ██ ', ' ██ ', ' ██ '],
    M: ['█▌ ▐█', '██ ██', '█ █ █', '█ █ █', '█   █', '█   █'],
    T: ['████', ' ██ ', ' ██ ', ' ██ ', ' ██ ', ' ██ '],
    U: ['█  █', '█  █', '█  █', '█  █', '█  █', '▀███▀'],
    ' ': ['  ', '  ', '  ', '  ', '  ', '  '],
  }
  const word = 'DSH NVIM TUI'
  const banner: string[] = ['', '', '', '', '', '']
  for (const ch of word) {
    const glyph = font[ch] ?? font[' '] ?? []
    for (let i = 0; i < 6; i++) {
      const g = glyph[i] ?? ''
      const cur = banner[i]
      if (cur !== undefined) banner[i] = cur + (cur === '' ? '' : ' ') + g
    }
  }
  const BLUE = 'DshTuiWhaleB-'
  const TITLE = 'DshTuiUser'
  return {
    above: [
      ...banner.map((text) => ({ text, group: BLUE })),
      { text: '' },
      { text: `${t('Neovim 风格的 DeepSeek Harness 终端客户端')} · v${BUILD_VERSION}`, group: TITLE },
      { text: '' },
    ],
    below: [
      { text: t('直接输入问题开始对话，命令以 / 开头，自然语言也可以') },
      { text: '' },
      { text: `  /help ${t('全部命令')} · /new ${t('新建会话')} · /sessions ${t('切换会话')} · /market ${t('插件市场')}` },
      { text: '' },
      { text: `  /skills ${t('技能')} · /model ${t('切换模型')} · /whale off ${t('关闭背景鲸鱼')}` },
      { text: '' },
      { text: `  @${t('文件')} ${t('引用文件')} · Ctrl+O ${t('思考面板')} · Ctrl+P ${t('历史输入')} · Ctrl+C ${t('停止')}` },
    ],
  }
}

export const updateTitle = (app: App) => {
  if (app.slices.runtime.nvim === null || app.slices.runtime.disposed) return
  const rec = app.slices.sessions.activeId === null ? undefined : app.slices.sessions.live.get(app.slices.sessions.activeId)
  const title = rec?.title ?? 'dsh'
  void app.luaCall('require("dsh_tui").set_title(...)', [title]).catch(() => {})
}
