import type { Context } from '@deepseek-ai/cordis';
/**
 * Shared type layer for the dsh-nvim-tui runner.
 *
 * Session events, host event payloads, and the structural service
 * interfaces this bundle consumes from the harness runtime. Everything is
 * declared LOCALLY (structural) on purpose: the services are assembled by
 * the host profile at runtime and are not package dependencies of this
 * bundle, so the emitted .d.ts must not reference packages consumers may
 * not have installed (the exception: peer/eco packages like cordis are
 * always present in a dsh host).
 *
 * @module dsh-nvim-tui/types
 */
/** One TokenUsage record (disjoint counters, folded per session). */
export interface TokenUsage {
    inputTokens?: number;
    outputTokens?: number;
    cacheReadTokens?: number;
    cacheWriteTokens?: number;
}
/** Session usage accumulator (stats.js). */
export interface Usage {
    input: number;
    output: number;
    cacheRead: number;
    cacheWrite: number;
}
/** Durable image attachment reference (dsh-attachment). */
export interface ImageAttachmentRef {
    mediaType: string;
    bytes?: number;
    width?: number;
    height?: number;
    /** Host attachment metadata is forward-compatible: the harness may add
     *  fields this bundle does not know yet, so unlisted keys are allowed and
     *  read explicitly (`rec[...]`). NOT a licence to add our own untyped
     *  fields — everything this bundle WRITES is declared above. */
    [hostField: string]: unknown;
}
/** One message content block. */
export interface FileAttachmentRef {
    attachmentId: string;
    name: string;
    bytes: number;
    [hostField: string]: unknown;
}
export type MessageContent = {
    type: 'text';
    text: string;
} | {
    type: 'reasoning';
    text: string;
} | {
    type: 'image';
    attachment: ImageAttachmentRef;
} | {
    type: 'file';
    attachment: FileAttachmentRef;
} | {
    type: string;
    [key: string]: unknown;
};
/**
 * Producer attribution for a message (dsh-llm MessageSource, structural).
 * `kind` answers WHO produced it ('user' human / 'plugin' host-injected /
 * 'model' / 'tool'); `form` answers WHAT KIND of thing it is (instructions /
 * catalog / snapshot / notice / relay / recall — semantic, never visual).
 * A `notice` form collapses to its one-line `summary`.
 */
export interface MessageSourceLike {
    kind?: string;
    form?: string;
    summary?: string;
    plugin?: string;
    /** Forward-compatible host payload (see the note on the attachment ref). */
    [hostField: string]: unknown;
}
/** A chat message (assistant messages carry id/usage; results carry source). */
export interface ChatMessage {
    id?: string;
    content?: MessageContent[];
    text?: string;
    usage?: TokenUsage;
    source?: {
        callId?: string;
        [key: string]: unknown;
    };
    [key: string]: unknown;
}
/** Streaming chunk from the LLM adapter. */
export type AssistantChunk = {
    type: 'reasoning-delta';
    text: string;
} | {
    type: 'text-delta';
    text: string;
} | {
    type: 'finish';
    reason: {
        kind: string;
        failure?: {
            message?: string;
            [key: string]: unknown;
        };
        error?: {
            message?: string;
            [key: string]: unknown;
        };
        [key: string]: unknown;
    };
};
/** One session-log event. `data` IS the message for user/message variants.
 *  Only the event kinds this bundle consumes are members — the union doubles
 *  as the discriminator for switch/=== narrowing (no catch-all member, which
 *  would defeat narrowing). Unknown kinds arrive as `unknown` and are
 *  dropped by the default branch. */
type SessionEventBase = {
    time?: number;
    seq?: number;
};
export type SessionEvent = (SessionEventBase & {
    type: 'turn/start';
    data?: {
        turn?: number;
        [key: string]: unknown;
    };
}) | (SessionEventBase & {
    type: 'step/start';
    data?: {
        turn?: number;
        step?: number;
    };
}) | (SessionEventBase & {
    type: 'step/end';
    data?: {
        turn?: number;
        step?: number;
    };
}) | (SessionEventBase & {
    type: 'turn/end';
    data?: Record<string, unknown>;
}) | (SessionEventBase & {
    type: 'user/message';
    data?: ChatMessage | {
        message?: ChatMessage;
    };
}) | (SessionEventBase & {
    type: 'assistant/message';
    data?: {
        turn?: number;
        step?: number;
        message?: ChatMessage;
        usage?: TokenUsage;
        interrupted?: true;
    };
}) | (SessionEventBase & {
    type: 'assistant/chunk';
    data?: {
        turn?: number;
        step?: number;
        chunk?: AssistantChunk;
    };
}) | (SessionEventBase & {
    type: 'tool/call';
    data?: {
        turn?: number;
        step?: number;
        callId?: string;
        name?: string;
        arguments?: string;
    };
}) | (SessionEventBase & {
    type: 'tool/result';
    data?: {
        turn?: number;
        step?: number;
        message?: ChatMessage;
        error?: {
            code?: string;
            name?: string;
            [key: string]: unknown;
        } | null;
    };
}) | (SessionEventBase & {
    type: 'session/title';
    data?: {
        title?: string;
    };
}) | (SessionEventBase & {
    type: 'agent/status';
    data?: {
        status?: string;
    };
}) | (SessionEventBase & {
    type: 'request/context';
    data?: {
        contextWindow?: number;
        provider?: string;
    };
}) | (SessionEventBase & {
    type: 'sandbox/mode';
    data?: {
        mode?: string;
    };
}) | (SessionEventBase & {
    type: 'approval/policy';
    data?: {
        policy?: string;
    };
}) | (SessionEventBase & {
    type: 'plan/mode';
    data?: {
        active?: boolean;
    };
}) | (SessionEventBase & {
    type: 'goal/change';
    data?: {
        goal?: unknown;
    };
}) | (SessionEventBase & {
    type: 'todo/write';
    data?: {
        todos?: Array<{
            content: string;
            status: string;
        }>;
    };
}) | (SessionEventBase & {
    type: 'compaction/start';
    data?: {
        compactionId?: string;
        sourceCommandId?: string;
    };
}) | (SessionEventBase & {
    type: 'compaction/summary';
    data?: {
        compactionId?: string;
        sourceCommandId?: string;
        summary?: string | Array<{
            type?: string;
            text?: string;
        }>;
        shadowedSeqs?: number[];
        shadowedTokenCount?: number;
    };
}) | (SessionEventBase & {
    type: 'compaction/end';
    data?: {
        compactionId?: string;
    };
}) | (SessionEventBase & {
    type: 'llm/retry';
    data?: {
        retryId?: string;
        retry?: number;
        maxRetries?: number;
        mode?: string;
        delayMs?: number;
        failure?: {
            message?: string;
            code?: string;
            [k: string]: unknown;
        };
    };
}) | (SessionEventBase & {
    type: 'llm/retry-started';
    data?: {
        retryId?: string;
        retry?: number;
    };
}) | (SessionEventBase & {
    type: 'tool-workflow/run-start';
    data?: {
        runId?: string;
        name?: string;
    };
}) | (SessionEventBase & {
    type: 'tool-workflow/agent-start';
    data?: {
        runId?: string;
        seq?: number;
        label?: string;
        phase?: string;
        childId?: string;
    };
}) | (SessionEventBase & {
    type: 'tool-workflow/agent-end';
    data?: {
        runId?: string;
        seq?: number;
        outcome?: string;
    };
}) | (SessionEventBase & {
    type: 'tool-workflow/run-end';
    data?: {
        runId?: string;
        stopReason?: string;
    };
}) | (SessionEventBase & {
    type: 'deliverables/presented';
    data?: {
        turn?: number;
        callId?: string;
        files?: PresentedFile[];
    };
}) | (SessionEventBase & {
    type: 'tool/ptc-dispatch-start';
    data?: {
        rootCallId?: string;
        parentCallId?: string;
        subCallId?: string;
        name?: string;
        arguments?: unknown;
    };
}) | (SessionEventBase & {
    type: 'tool/ptc-dispatch';
    data?: {
        rootCallId?: string;
        parentCallId?: string;
        subCallId?: string;
        name?: string;
        arguments?: unknown;
        isError?: boolean;
        content?: unknown;
        error?: {
            code?: string;
            name?: string;
        };
    };
}) | (SessionEventBase & {
    type: 'image/offload';
    data?: {
        targets?: Array<{
            seq?: number;
            imageIndexes?: number[];
        }>;
    };
}) | (SessionEventBase & {
    type: 'workspace/changes';
    data?: {
        turn?: number;
    };
});
/** subagent/start / subagent/end payload. */
export interface SubagentInfo {
    runId?: string;
    provider?: string;
    id?: string;
    stopReason?: string;
}
/** approval/request payload. */
export interface ApprovalRequest {
    toolName?: string;
    reason?: string;
    /** Exact tool call being decided, when the asker has one. The feed records
     *  its arguments under this id, so the approval float can show WHAT the
     *  user is approving instead of a one-line reason. */
    callId?: string;
    /** Localized presentation-only reason (dsh-user-approval). Never persisted
     *  in approval audit events; the raw `reason` remains the durable text. */
    displayReason?: Record<string, string>;
    agent?: {
        session?: {
            id?: string;
        };
    };
    /** Live request signal (the host's own type — Node's global AbortSignal). */
    signal?: AbortSignal;
}
/** `deliverables/presented` payload (dsh-tool-present): files the model
 *  explicitly declared for delivery. Authoritative over the mutation-tool
 *  argument heuristic in session-events.ts. */
export interface PresentedFile {
    /** Absolute, or relative to the Session working directory. */
    path: string;
    description?: string;
}
/** Per-turn deliverables: explicit declarations + heuristic mutation paths. */
export interface DeliverablesState {
    turn: number | undefined;
    /** Mutation-tool paths (write/edit/…) — a fallback for tools that do not
     *  emit deliverables/presented. */
    paths: string[];
    /** Explicit `present` declarations; may include files produced by bash. */
    presented: PresentedFile[];
}
/** One changed file in a host `workspace/changes` summary. */
export interface WorkspaceChangedFile {
    path: string;
    display: string;
    added: number;
    deleted: number;
    binary?: true;
    oversized?: true;
}
/** Host per-turn workspace change summary (dsh-workspace-changes). */
export interface WorkspaceChangesSummary {
    turn: number;
    cwd: string;
    files: WorkspaceChangedFile[];
    total: number;
    added: number;
    deleted: number;
    snapshot?: {
        before: string;
        after: string;
    };
}
/** One unified-diff hunk from a host workspace comparison. */
export interface WorkspaceDiffHunk {
    oldStart: number;
    oldLines: number;
    newStart: number;
    newLines: number;
    lines: string[];
}
/** Host comparison of one file's turn-start/turn-end contents. */
export type WorkspaceFileDiff = {
    kind: 'text';
    path: string;
    display: string;
    before: boolean;
    after: boolean;
    hunks: WorkspaceDiffHunk[];
    coarse: boolean;
} | {
    kind: 'binary';
    path: string;
    display: string;
} | {
    kind: 'oversized';
    path: string;
    display: string;
};
/** dsh-command-feedback categories (durable log vocabulary). */
export declare const FEEDBACK_CATEGORIES: readonly ['task-result', 'instruction-following', 'product-interaction', 'service-stability', 'resource-cost', 'security-privacy-permission', 'other'];
export type FeedbackCategory = (typeof FEEDBACK_CATEGORIES)[number];
/** `sessionFeedback.record` request/result (dsh-command-feedback). */
export interface SessionFeedbackRecordRequest {
    sessionId: string;
    text?: string;
    category?: FeedbackCategory;
}
export type SessionFeedbackRecordResult = {
    ok: true;
    value: {
        recorded: true;
    };
} | {
    ok: false;
    error: {
        code: string;
        [key: string]: unknown;
    };
};
/** Host service recording session-level feedback (`/feedback`). */
export interface SessionFeedbackService {
    record(request: SessionFeedbackRecordRequest): Promise<SessionFeedbackRecordResult>;
}
/** Account UI metadata (dsh-deepseek-account). Kept structural: the TUI only
 *  reads safe views and never touches credentials. */
export interface AccountClientMetadata {
    version: string;
    locale: string;
    timezoneOffsetSeconds: number;
}
export interface AccountViewLike {
    status?: string;
    links?: {
        usageUrl?: string;
        topUpUrl?: string;
    };
    attempt?: {
        id?: string;
        phase?: string;
        authorizeUrl?: string;
        expiresAt?: number;
        errorCode?: string;
    } | null;
}
export interface AccountProfileLike {
    status?: string;
    value?: {
        name?: string | null;
        contact?: string | null;
        id?: string | null;
    };
}
export interface AccountBalanceLike {
    status?: string;
    value?: Array<{
        currency?: string;
        balance?: string;
    }>;
    bonusWallets?: Array<{
        currency?: string;
        balance?: string;
    }>;
}
/** Host account service (base mounts dsh-deepseek-account-platform). */
export interface AccountService {
    getState?: () => Promise<AccountViewLike>;
    getProfile?: (client: AccountClientMetadata) => Promise<AccountProfileLike | null>;
    getBalance?: (client: AccountClientMetadata) => Promise<AccountBalanceLike | null>;
    startSignIn?: (client: AccountClientMetadata, callbackOrigin: string, loginSource: 'web' | 'desktop') => Promise<AccountViewLike>;
    cancelSignIn?: (id: string) => Promise<AccountViewLike>;
    signOut?: (client: AccountClientMetadata) => Promise<AccountViewLike>;
}
/** One durable Schedule record (dsh-schedule). Structural subset the TUI
 *  renders; host-only fields stay untyped. */
export interface ScheduleRecordLike {
    id: string;
    kind: 'after' | 'at' | 'every' | 'daily' | 'weekly' | 'cron';
    title: string;
    prompt: string;
    scheduledAt: string;
    afterSeconds?: number;
    everySeconds?: number;
    time?: string;
    timeZone?: string;
    weekdays?: number[];
    expression?: string;
    [key: string]: unknown;
}
export interface ScheduleCreateRequestLike {
    prompt: string;
    title: string;
    after_seconds?: number;
    at?: string;
    every_seconds?: number;
    daily?: {
        time: string;
        time_zone: string;
    };
    weekly?: {
        time: string;
        time_zone: string;
        weekdays: number[];
    };
    cron?: {
        expression: string;
        time_zone: string;
    };
}
export interface ScheduleCatalogEntryLike {
    sessionId?: string;
    record?: ScheduleRecordLike;
    [key: string]: unknown;
}
export interface ScheduleHistoryLike {
    items?: Array<{
        scheduledAt?: string;
        deliveredAt?: string;
        prompt?: string;
    }>;
    [key: string]: unknown;
}
/** Host schedule service (dsh-schedule; optional row in the TUI profile). */
export interface ScheduleService {
    create?: (sessionId: string, request: ScheduleCreateRequestLike, signal?: AbortSignal) => Promise<ScheduleRecordLike>;
    list?: (request: {
        sessionId: string;
    }) => Promise<ScheduleRecordLike[]>;
    catalog?: () => Promise<ScheduleCatalogEntryLike[]>;
    delete?: (request: {
        sessionId: string;
        id: string;
    }, signal?: AbortSignal) => Promise<unknown>;
    update?: (request: {
        sessionId: string;
        id: string;
        expected: ScheduleRecordLike;
        title?: string;
        prompt?: string;
    }, signal?: AbortSignal) => Promise<unknown>;
    history?: (request: {
        sessionId: string;
        id: string;
        limit: number;
    }) => Promise<ScheduleHistoryLike>;
}
/** Host PTY service (dsh-terminal). */
export interface TerminalSessionSnapshotLike {
    sessionId: string;
    name?: string;
    type: string;
    pid?: number;
    status?: {
        kind?: string;
        exitCode?: number | null;
        signal?: string | null;
    };
}
export interface TerminalService {
    listBackends?: () => string[];
    spawn?: (owner: unknown, request: {
        type: string;
        name?: string;
        cwd?: string;
    }, signal?: AbortSignal) => Promise<TerminalSessionSnapshotLike & {
        motd?: string;
    }>;
    list?: (owner: unknown) => TerminalSessionSnapshotLike[];
    read?: (owner: unknown, id: string, request?: {
        offset?: number;
        count?: number;
    }) => {
        text: string;
        totalLines: number;
        lineBegin: number;
        lineEnd: number;
        truncated: boolean;
    };
    startSend?: (owner: unknown, id: string, request: {
        text: string;
        submit: boolean;
        signal?: AbortSignal;
    }) => {
        done: Promise<{
            viewport: string;
            waitReason: string;
            sessionStatus: unknown;
            truncated: boolean;
        }>;
        readOutput: () => {
            delta: string;
            truncated: boolean;
        };
        cancel: () => boolean;
    };
    signal?: (owner: unknown, id: string, signal: 'SIGINT' | 'SIGTERM' | 'SIGKILL' | 'SIGTSTP' | 'SIGHUP') => Promise<unknown>;
    kill?: (owner: unknown, id: string, reason?: string) => Promise<boolean>;
}
/** Dynamic Cordis runner (dsh-cordis-host-runner): read-only inspection
 *  surface the TUI exposes; define/run stays with the model tool. */
export interface DynamicCordisService {
    inventory?: () => unknown[];
    snapshot?: (agent: unknown) => Array<{
        pluginId?: string;
        packages?: Array<{
            packageId?: string;
            name?: string;
            purpose?: string;
            hasHostHalf?: boolean;
            hasClientHalf?: boolean;
        }>;
        activeRun?: {
            pluginRunId?: string;
            handlers?: string[];
        };
    }>;
    inspectPlugin?: (agent: unknown, pluginId: string) => unknown;
}
/** Host service serving `workspace/changes` summaries and comparisons. */
export interface WorkspaceChangesService {
    summary(sessionId: string, seq: number): WorkspaceChangesSummary | undefined;
    diff(sessionId: string, seq: number, index: number, signal: AbortSignal): Promise<WorkspaceFileDiff | undefined>;
}
/** One user question (userQuestions service). */
export interface UserQuestion {
    id: string;
    question: string;
    detail?: string;
    header?: string;
    multiSelect?: boolean;
    options?: Array<{
        label: string;
        description?: string;
    }>;
}
/** Symbol-keyed host prompt queue on the dsh-subagent service instance
 *  (Symbol.for('dsh.subagent.queuePrompt')): pre-0.1.5 face — queue one
 *  human prompt as a distinct child turn. Signature:
 *  (parentAgent, childId, content, source, signal) → inbox MessageId.
 *  0.1.5 replaced it with the public `subagents.prompt` method. */
export declare const queueSubagentPromptKey: symbol;
/** One 0.1.5 subagent prompt request (public `subagents.prompt`). */
export interface SubagentPromptRequest {
    requestId: string;
    parentSessionId: string;
    childSessionId: string;
    mode: 'continuable';
    delivery: 'queue' | 'steer';
    content: Array<{
        type: 'text';
        text: string;
    }>;
}
/** dsh-subagent directory service. */
export interface SubagentsService {
    listChildren?: (parentSessionId: string, signal?: AbortSignal) => Promise<Array<{
        kind?: string;
        id: string;
        label?: string;
        activity?: string;
        mode?: string;
        reason?: string;
        hasChildren?: boolean;
    }>>;
    /** 0.1.5: queue/steer one human prompt to a continuable child. */
    prompt?: (request: SubagentPromptRequest, signal: AbortSignal) => Promise<{
        messageId?: unknown;
    } | void>;
    /** Host prompt queue + other symbol-keyed runtime faces. */
    [key: symbol]: unknown;
}
/** Minimal persisted-session header fields the TUI consumes. */
export interface SessionHeaderLike {
    id: string;
    cwd?: string;
    origin?: string;
    parentSession?: string;
    createdAt?: number | undefined;
    title?: string;
    /** Log offset of seeded history (projection-cache reads need it). */
    inheritedEventCount?: number;
    [key: string]: unknown;
}
/** dsh-session-persistence: history list + read-only inspection. */
export interface SessionPersistenceService {
    /** 0.1.5: snapshot list (header keyed); pre-0.1.5: header list. */
    list?: () => Promise<Array<SessionHeaderLike | {
        header: SessionHeaderLike;
    }> | Array<SessionHeaderLike | {
        header: SessionHeaderLike;
    }>>;
    /** pre-0.1.5 hosts: read-only inspection ({events, meta}). */
    inspect?: (id: string) => Promise<{
        events?: unknown[];
        meta?: {
            id?: string;
            cwd?: string;
        };
    } | undefined>;
    /** 0.1.5: open a stored session handle (read access). */
    open?: (id: string, access: 'read' | 'write', options?: {
        signal?: AbortSignal;
    }) => Promise<{
        read?: (offset?: number, length?: number, options?: unknown) => Promise<{
            events?: SessionEvent[];
        } | undefined>;
        close?: () => void | Promise<unknown>;
    } | undefined>;
    /** Raw physical artifact access (pre-0.1.5 backend encodes its own). */
    supportsRawArtifacts?: boolean;
    readRaw?: (id: string) => Promise<{
        filename?: string;
        content?: string;
    } | undefined>;
    locate?: (meta: unknown) => {
        kind?: string;
        path?: string;
    } | undefined;
}
/** dsh-attachment durable image save. */
export interface AttachmentsService {
    saveImage: (img: SaveImageAttachment) => Promise<ImageAttachmentRef>;
    /** Durable verbatim file upload (`/upload`); absent on stores without files. */
    saveFile?: (input: {
        data: Uint8Array;
        name?: string;
    }) => Promise<FileAttachmentRef>;
    imageLimits?: {
        maxImagesPerMessage?: number;
    };
}
/** Input-side image shape (bytes + type + optional name). */
export interface SaveImageAttachment {
    data: Uint8Array;
    mediaType: string;
    name?: string;
}
/** dsh-compaction service (compactNow is called with the live agent). */
export interface CompactionService {
    compactNow: (agent: unknown, signal: AbortSignal, sourceCommandId?: string) => Promise<{
        shadowedSeqs: unknown[];
        shadowedTokenCount: number;
    } | null>;
}
/** dsh-working-directory service (0.2.1+): per-Session working directory.
 *  `get` reads the committed dir without filesystem I/O; `set` changes it. */
export interface WorkingDirectoryService {
    get: (session: unknown) => string;
    ensure?: (agent: unknown, signal?: AbortSignal) => Promise<string>;
    set: (agent: unknown, path: string, signal?: AbortSignal) => Promise<string>;
}
/** dsh-goal service. */
export interface GoalState {
    id: string;
    revision: number;
    objective: string;
    phase: string;
    blockedReason?: {
        message: string;
    };
    roundsStarted: number;
    maxGoalRounds: number;
    activation: string;
}
export interface GoalsService {
    get: (agent: unknown) => GoalState | undefined;
    create: (agent: unknown, opts: {
        objective: string;
    }) => void;
    pause: (agent: unknown, ref?: {
        id: string;
        revision: number;
    }) => void;
    resume: (agent: unknown, ref?: {
        id: string;
        revision: number;
    }) => void;
    complete: (agent: unknown, ref?: {
        id: string;
        revision: number;
    }) => void;
    clear: (agent: unknown, ref?: {
        id: string;
        revision: number;
    }) => void;
}
/** dsh-plan-mode service. */
export interface PlanModeService {
    get: (agent: unknown) => {
        active: boolean;
        pending?: boolean;
    };
    set: (agent: unknown, on: boolean) => string;
}
/**
 * The OFFICIAL slash-command registry (`@deepseek-ai/dsh-commands`, wired by
 * `dsh-base`). Plugins register commands here; a command's `name` carries NO
 * leading slash.
 *
 * The TUI keeps its OWN registry for its 60-odd interface commands (pickers,
 * floats, session browsing) — the official one is an ADDITIONAL source, not a
 * replacement: it cannot express the TUI's UI, and it holds only a handful of
 * in-session commands. What it buys is that any plugin using the official API
 * becomes reachable from the TUI without that plugin knowing about the TUI.
 */
export interface CommandsService {
    /** Effective descriptors for one agent, name-sorted, after scoped shadowing. */
    list: (agent: unknown) => ReadonlyArray<{
        /** Lowercase name WITHOUT the leading slash. */
        readonly name: string;
        readonly description: string;
        readonly input?: {
            readonly hint?: string;
        } | undefined;
    }>;
    /** Find one effective definition, or undefined when the name is unknown. */
    find?: (agent: unknown, name: string) => unknown;
    /**
     * Parse and execute a known command without sending it to the model.
     *
     * Returns undefined for an ADMISSION MISS (syntax or unknown name) — that is
     * not an error, so callers must not treat it as one.
     */
    execute: (agent: unknown, line: string, attachments: readonly unknown[], signal: AbortSignal) => Promise<{
        readonly result: {
            readonly kind: 'success';
            readonly text?: string;
        } | {
            readonly kind: 'error';
            readonly text: string;
        };
    } | undefined>;
}
/** dsh-jobs service (workflow/job registry). */
export interface JobsService {
    kill: (jobId: string, agent: unknown, reason: string) => string;
    list: (agent: unknown) => Array<{
        id: string;
        label?: string;
        status: string;
        startedAt?: number;
    }>;
    /** Effect-scoped observer: fires after every visible-set commit. */
    onJobsChanged?: (listener: (owner: unknown) => void) => () => void;
    /** Effect-scoped completion listener: terminal snapshot + exact owner. */
    onJobDone?: (listener: (snap: {
        label?: string;
        status?: string;
    }, owner: unknown) => void) => () => void;
}
/** dsh-skill service. */
export interface SkillsService {
    get: (name: string, scope: {
        scope: unknown;
    }) => Promise<SkillDef | undefined>;
    list: (scope: {
        scope: unknown;
    }) => Promise<SkillDef[]>;
}
export interface SkillDef {
    name: string;
    description?: string;
    whenToUse?: string;
    content?: string;
}
/** dsh-permission-presets service. */
export interface PermissionPresetsService {
    names: Iterable<string>;
    set: (session: unknown, name: string) => void;
    current: (session: unknown) => string;
    optionOf: (name: string) => {
        value?: string;
        name?: string;
        description?: string;
    } | undefined;
}
/** The cordis loader service (in-process entry listing). */
export interface LoaderService {
    entries?: () => Array<{
        id: string;
        options?: {
            name?: string;
            group?: string;
        };
        disabled?: boolean;
    }>;
}
/** dsh-host-plugin-inventory (read-only loader entry projection).
 *  0.1.2-alpha.2: list() is async. */
export interface PluginInventoryService {
    list?: () => Promise<{
        entries?: Array<{
            entryId: string;
            moduleName: string;
            enabled: boolean;
            fiberPhase: string;
        }>;
        agentPresets?: unknown;
    }>;
}
/** dsh-session-projection registry (whole-log projection reads). */
export interface SessionProjectionsService {
    stateOf?: (session: unknown, key: string) => unknown;
    snapshot?: (session: unknown, keys?: readonly string[]) => {
        values?: Record<string, unknown>;
        asOfSeq?: number;
    } | undefined;
    /** Persisted projection-cache read by session header (zero log I/O). */
    cachedSnapshot?: (meta: unknown, keys?: string[]) => {
        values?: Record<string, unknown>;
    } | undefined;
}
/** dsh-workspace registry (workspace grouping + session archive). */
export interface WorkspaceEntityLike {
    id: string;
    path: string;
    title: string;
    sessionIds: readonly string[];
    setTitle?: (title: string) => Promise<void>;
    /** Explicitly account a session to this workspace (official registry
     *  validates the session's canonical cwd against the workspace path). */
    attachSession?: (sessionId: string) => Promise<void>;
    /** Remove a session from this workspace's accounting (keeps the log). */
    detachSession?: (sessionId: string) => Promise<void>;
}
export interface WorkspacesService {
    list: () => WorkspaceEntityLike[];
    create?: (path: string, title?: string) => Promise<{
        id: string;
    }>;
    delete?: (id: string) => Promise<boolean>;
    archiveSession?: (sessionId: string) => Promise<void>;
    archivedSessionIds?: readonly string[];
}
/** dsh-session-reference resolver (in-process candidate listing). */
export interface SessionReferenceService {
    listCandidates?: (agent: unknown, query?: string, limit?: number, signal?: AbortSignal) => Promise<Array<{
        sessionId: string;
        label: string;
        cwd?: string;
        createdAt: number;
        sameWorkspace?: boolean;
    }>>;
}
/** dsh-file-reference service. */
export interface FileReferencesService {
    list?: (agent: unknown, query: string, signal: AbortSignal) => Promise<Array<{
        path: string;
    }>>;
}
/** dsh-settings service. */
export interface SettingsService {
    update?: (ns: string, patch: Record<string, unknown>, expectedRevision?: number) => Promise<void>;
    prepareDocument?: () => Promise<string | undefined>;
    describe?: (opts?: {
        redactSecrets?: boolean;
    }) => Array<{
        ns?: string;
        schema?: unknown;
        value?: unknown;
        user?: unknown;
        revision?: unknown;
        applies?: unknown;
        secrets?: Array<{
            path?: unknown[];
            set?: boolean;
        }>;
        [k: string]: unknown;
    }>;
    documentPath?: string;
    writable?: boolean;
}
/** dsh-tools (MCP) service. */
export interface ToolsService {
    schemas: (agent: unknown) => Array<{
        name: string;
    }>;
}
/** dsh-session-query service. */
export interface SessionQueryService {
    searchSessions: (opts: {
        query: string;
        eventFilters?: unknown[];
        limit: number;
    }) => Promise<{
        items?: Array<{
            header?: {
                id?: string;
                [key: string]: unknown;
            };
            live?: boolean;
            persisted?: boolean;
            bestMatch?: {
                snippet?: string;
            };
        }>;
    }>;
}
/** dsh-session-title service. */
export interface SessionTitleService {
    rename: (session: unknown, title: string) => void;
}
/** dsh-message-feedback service. */
export interface MessageFeedbackService {
    list: (opts: {
        sessionId: string;
    }) => Promise<{
        ok: true;
        value: {
            items: Array<{
                messageId: string;
                version?: unknown;
            }>;
        };
    } | {
        ok: false;
        error?: {
            code?: string;
        };
    }>;
    delete: (opts: {
        sessionId: string;
        messageId: string;
        ifVersion: unknown;
    }) => Promise<unknown>;
    put: (opts: {
        sessionId: string;
        messageId: string;
        rating: string;
        note?: string;
        ifVersion: unknown;
    }) => Promise<{
        ok: boolean;
        error?: {
            code?: string;
        };
    }>;
}
/** dsh-agent-presets service. */
export interface AgentPresetsService {
    list?: () => Promise<Array<{
        id: string;
        name?: string;
    }>>;
    recompose?: (agentCtx: unknown, presetId: string) => Promise<{
        id: string;
    }>;
}
/** A live session record from the harness store. */
export interface HarnessSession {
    id: string;
    header?: {
        parentSession?: string;
        origin?: string;
        createdAt?: number | undefined;
        cwd?: string;
        [key: string]: unknown;
    };
    /** alpha.4+: the full immutable event log (replaced the removed `events`). */
    snapshotEvents?: () => SessionEvent[];
    /** pre-alpha.4 hosts: public `events` property (removed by the alpha.4
     *  SessionSeq 品牌化重构). */
    events?: SessionEvent[];
    append: (type: string, data: unknown, opts?: {
        surfaceOp?: 'append' | {
            op: 'replace';
            startSeq: number;
            endSeq: number;
        };
        sourceEventSeqs?: number[];
    }) => unknown;
    [key: string]: unknown;
}
/** The live-session store seam. dsh 0.1.5 removed the `sessions` service —
 *  the TUI builds this adapter over `ctx.agents.get/list` (`Agent.session`). */
export interface SessionStore {
    get: (id: string) => HarnessSession | undefined;
    list: () => HarnessSession[];
}
/** The agent inbox projection (queued next-turn / next-step messages). */
export interface InboxLike {
    nextTurn?: readonly unknown[];
    nextStep?: readonly unknown[];
    remove?: (messageId: string) => boolean;
    replace?: (messageId: string, newMessage: unknown) => boolean;
    clear?: () => void;
}
/** An owned live agent handle. */
export interface AgentHandle {
    agent: {
        session: HarnessSession;
        status?: string;
        cancel: (cause: unknown) => void;
        followup: (message: unknown) => void;
        steer: (directive: unknown) => void;
        inbox?: InboxLike;
        /** dsh 0.2.2+: durable Agent-owned model selection. */
        model?: {
            current: () => {
                provider: string;
                model: string;
                reasoningEffort?: string | undefined;
            } | undefined;
            select: (selection: {
                provider: string;
                model: string;
                reasoningEffort?: string | undefined;
            }) => void;
        };
        [key: string]: unknown;
    };
    dispose: () => Promise<unknown>;
}
/** The harness agents service (0.1.5 AgentRegistry). */
export interface AgentsService {
    create: (options: {
        sessionId: string;
        meta?: Record<string, unknown>;
        agentOptions?: Record<string, unknown>;
        seed?: unknown[];
        /** alpha.4+: exact fork-inherited prefix length (pairs with meta.isSeeded). */
        inheritedEventCount?: number;
        setup?: (agentCtx: Context) => void;
    }) => Promise<AgentHandle>;
    resume: (options: {
        resumeSessionId: string;
        agentOptions?: Record<string, unknown>;
        setup?: (agentCtx: Context) => void;
    }) => Promise<AgentHandle>;
    /** 0.1.5: live-agent registry lookups (the sessions-store adapter source). */
    get?: (id: string) => {
        session?: unknown;
    } | undefined;
    list?: () => Array<{
        session?: unknown;
    }>;
}
/** dsh-agent-default-model selection. */
export interface ModelSelection {
    currentSelection: () => {
        provider: string;
        model: string;
        reasoningEffort?: string | undefined;
        [key: string]: unknown;
    };
    saveSelection: (next: unknown) => Promise<unknown>;
}
/** LLM service (model info / providers). */
export interface LlmService {
    resolveModelInfo: (provider: string, model: string) => Promise<{
        inputModalities?: string[];
        /** Supported reasoning efforts; ABSENT means the model rejects any effort. */
        reasoning?: {
            efforts?: ReadonlyArray<{
                id?: string;
            }>;
        };
    } | undefined>;
    listProviders: () => Array<{
        id?: string;
        name?: string;
        provider?: string;
    }>;
    listConfigurableProviders?: () => Array<{
        provider?: string;
        displayName?: string;
        settingsNs?: string;
    }>;
    /** 0.1.5: full model catalog for one provider (vision-candidate fallback). */
    listModels?: (provider: string) => Promise<Array<{
        id?: string;
        inputModalities?: string[];
    }>>;
}
/**
 * The harness runtime context as consumed by this bundle: the cordis context
 * narrowed to the injected services (sessions/agents/agentDefaultModel) plus
 * the loosely-typed service registry and event bus.
 */
export interface RuntimeCtx {
    get(name: string): unknown;
    on(name: string, cb: (...args: any[]) => unknown): () => void;
    agents: AgentsService;
    agentDefaultModel: ModelSelection;
    llm?: LlmService;
}
/** Runner configuration (cordis.patch.yml `config:` block / RunnerConfig row).
 *  Also accepts arbitrary extra keys (forwarded to module configs). */
export interface RunnerConfig {
    /** User-authored YAML (cordis.patch.yml `config:`) — unknown keys are
     *  allowed by design so a newer config never fails to load. Known keys are
     *  declared below and read via property access. */
    headless?: boolean;
    watchdogMs?: number;
    dumpPath?: string;
    theme?: Record<string, unknown> | null;
    loadUserConfig?: boolean;
    resumeSessionId?: string;
    resumeLatest?: boolean;
    prompt?: string;
    /** 按任务难度自动选择模型（/difficulty，详见 kernel/difficulty.ts）。 */
    difficultyRouting?: DifficultyRoutingConfig;
    /** /todo 清单纪律守卫（逐项更新硬性约束；默认开，false 关闭）。 */
    todoGuard?: boolean;
    [key: string]: unknown;
}
/** Difficulty tier for the model router. */
export type DifficultyTier = 'easy' | 'medium' | 'hard';
/** One tier's model route (provider omitted = inherit the current one). */
export interface TierRoute {
    provider?: string;
    model: string;
    /** reasoning effort applied while the tier model is active. */
    effort?: 'off' | 'high' | 'max' | 'auto';
}
/** /difficulty routing configuration (runner config block, HMR). */
export interface DifficultyRoutingConfig {
    /** auto = route per turn; off = never route (default: auto). */
    mode?: 'auto' | 'off';
    /** Per-tier model routes; a tier without a route falls back to the
     *  current default model (no switch). */
    tiers?: Partial<Record<DifficultyTier, TierRoute>>;
    /** LLM difficulty classifier (opt-in; falls back to rules on any error). */
    classifier?: {
        enabled?: boolean;
        provider?: string;
        model?: string;
        timeoutMs?: number;
    };
    /** Sync the official `subagent-model-selection` gate so child agents may
     *  pick among the tier routes (off = leave the user's own setting). */
    subagentPolicy?: boolean;
}
/** Per-session difficulty routing state (SessionRec.difficulty). */
export interface DifficultyState {
    /** Tier of the model currently active via a temporary switch. */
    tier: DifficultyTier | null;
    /** Manual pin (/difficulty easy|medium|hard); null = auto estimation. */
    pinned: DifficultyTier | null;
    /** Routing enabled for this session (mode auto; /model disables). */
    enabled: boolean;
    /** Active temporary switch: previous selection + switch instant. */
    tmp: {
        prev: ReturnType<ModelSelection['currentSelection']>;
        switchAt: number;
        tier: DifficultyTier;
    } | null;
    /** Estimate parked while a turn was running (applied at turn/end for the
     *  queued turn — modelRef must never change mid-turn). */
    pending: {
        tier: DifficultyTier;
        source: 'pin' | 'rules' | 'classifier';
    } | null;
    /** Where the active tier came from (pin / rules / classifier). */
    source: 'pin' | 'rules' | 'classifier' | null;
    /** Last subagent-policy routes key synced (dedupe settings writes). */
    syncedRoutesKey: string | null;
}
export {};
