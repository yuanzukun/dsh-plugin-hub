/**
 * dsh_tui App: the shared runner state + service surface on the Node side —
 * the analogue of nvim/lua/dsh_tui/state.lua. EVERY behavior module reads
 * state and services through this ONE object; modules never reach into each
 * other's closures. index.ts composes the modules over it (the analogue of
 * nvim/lua/dsh_tui/init.lua's facade).
 *
 * Composition contract:
 *  - `createApp(ctx, config)` builds the state + core services + no-op slots.
 *  - Each module's `install(app)` fills the slots it owns and registers its
 *    slash commands via `app.registerCommands([...])` (late binding: install
 *    order never matters, runtime calls always see the real implementations).
 *  - `boot(app)` (boot.ts) runs the main body LAST, after every install.
 *
 * @module dsh-nvim-tui/app
 */
import type { WorkingDirectoryService } from './types.js';
import type { Context } from '@deepseek-ai/cordis';
import type { NeovimClient } from 'neovim';
import type { FeedRenderer } from '../feed/feed.js';
import type { FileChange } from './change-ledger.js';
import type { ExtEventName, ExtSessionEventFilter, TuiExtApi } from './ext-types.js';
import type { RunnerConfig } from './types.js';
import type { AccountService, AgentHandle, AgentPresetsService, ApprovalRequest, AttachmentsService, CompactionService, CommandsService, DeliverablesState, DifficultyState, DynamicCordisService, FileAttachmentRef, FileReferencesService, GoalsService, GoalState, HarnessSession, JobsService, LlmService, MessageContent, MessageFeedbackService, ModelSelection, PermissionPresetsService, PlanModeService, RuntimeCtx, SaveImageAttachment, ScheduleService, SessionEvent, SessionStore, TerminalService, LoaderService, PluginInventoryService, SessionPersistenceService, SessionProjectionsService, SessionQueryService, SessionReferenceService, SessionFeedbackService, SessionTitleService, SettingsService, SkillsService, SubagentInfo, SubagentsService, ToolsService, Usage, WorkspaceChangesService, WorkspacesService } from './types.js';
/** Version + build stamp shown in the boot banner (proof of which code runs). */
/** The active session's working directory (falls back to the process cwd
 *  when no session is attached) — local-file commands must resolve against
 *  THIS, not process.cwd(): /search can resume a session from another
 *  project directory while the shell cwd stays put. */
export declare const activeSessionCwd: (app: App) => string;
/** dsh 0.1.5 persistence.list() returns snapshots ({header, revision, …});
 *  pre-0.1.5 hosts returned the header directly. Normalize either shape. */
export declare const persistedHeader: (item: {
    header?: unknown;
    id?: string;
} | null | undefined) => {
    id?: string;
    [key: string]: unknown;
} | null;
export declare const BUILD_VERSION = "0.5.2";
export declare const BUILD_STAMP: string;
export interface ServiceMap {
    appExit: (code?: number) => void;
    attachments: AttachmentsService;
    subagents: SubagentsService;
    compaction: CompactionService;
    goals: GoalsService;
    planMode: PlanModeService;
    jobs: JobsService;
    /** The OFFICIAL command registry (dsh-commands, wired by dsh-base). Plugins
     *  register slash commands here; the TUI can discover and run them. */
    commands: CommandsService;
    skills: SkillsService;
    permissionPresets: PermissionPresetsService;
    fileReferences: FileReferencesService;
    settings: SettingsService;
    tools: ToolsService;
    sessionQuery: SessionQueryService;
    sessionProjections: SessionProjectionsService;
    sessionProjectionCache: SessionProjectionsService;
    pluginInventory: PluginInventoryService;
    loader: LoaderService;
    llm: LlmService;
    sessionReferenceResolver: SessionReferenceService;
    sessionTitle: SessionTitleService;
    messageFeedback: MessageFeedbackService;
    sessionPersistence: SessionPersistenceService;
    agentPresets: AgentPresetsService;
    workspaceRegistry: WorkspacesService;
    /** Credential-reference seam: resolve(envRefName) → { value } | undefined
     *  (provider-owned key storage; the official Models page writes it). */
    credentials: {
        resolve?: (ref: string) => Promise<{
            value?: unknown;
        } | undefined>;
    };
    /** Per-Session working directory (dsh 0.2.1+; assembled by dsh-base). Absent
     *  on older hosts, so every use is optional-chained. */
    workingDirectory: WorkingDirectoryService;
    /** Host per-turn workspace change summaries (web/desktop composition). */
    workspaceChanges: WorkspaceChangesService;
    sessionFeedback: SessionFeedbackService;
    deepseekAccount: AccountService;
    schedule: ScheduleService;
    terminals: TerminalService;
    dynamicCordisRunner: DynamicCordisService;
}
/**
 * Positional-argument grammar of a slash command, for completion + hints.
 *
 * The input box must answer "what do I type next?" without reading /help.
 *
 * It is a TREE, not a flat list, because a flat list cannot express that a
 * subcommand changes what follows: `/plugin list` takes NO further arguments,
 * while `/plugin install` takes a spec and an optional flag. A flat list made
 * `list` keep asking for arguments — actively misleading, and measured on a
 * real run.
 */
export type CommandArg = 
/** Fixed alternatives — offered in the menu. `byValue` gives an alternative
 *  its OWN argument list; an alternative ABSENT from `byValue` terminates the
 *  command, so neither the menu nor the hint may ask for anything after it.
 *  (Measured: `/plugin list` took no arguments, yet a flat list kept asking
 *  for them — actively misleading.) */
{
    kind: 'oneof';
    values: string[];
    hint?: string;
    byValue?: Record<string, CommandArg[]>;
}
/** Free text with a label, e.g. `<spec>`: hints only, never completed. */
 | {
    kind: 'free';
    label: string;
    hint?: string;
}
/** A filesystem path — hints only (path completion is a separate feature). */
 | {
    kind: 'file';
    label: string;
    hint?: string;
}
/** An optional switch, e.g. `--latest`; offered but never required. */
 | {
    kind: 'flag';
    value: string;
    hint?: string;
};
/** One slash command: metadata for /help + the completion catalog, plus the
 *  handler. Modules register their own commands with registerCommands(). */
export interface CommandSpec {
    name: string;
    desc: string;
    usage: string;
    group: string;
    fn: (arg: string) => unknown;
    /** Optional positional arguments; drives <Tab> completion and the input hint.
     *  Commands that omit this behave exactly as before. */
    args?: CommandArg[];
}
export interface ModelRef {
    current: ReturnType<ModelSelection['currentSelection']>;
    assembled?: unknown;
}
export interface SessionRec {
    id: string;
    handle: AgentHandle;
    feed: FeedRenderer;
    title: string | undefined;
    status: string | undefined;
    modelRef: ModelRef;
    model: string | undefined;
    createdAt: number;
    usage: Usage | undefined;
    contextWindow: number | undefined;
    mode: string | undefined;
    policy: string | undefined;
    provider: string | undefined;
    cacheReported: boolean;
    /** Reset to undefined on /rewind replay (explicit undefined allowed). */
    lastUsage?: Usage | undefined;
    lastAssistantMessageId: string | null;
    goal: GoalState | null;
    planActive: boolean;
    imagePoisonWarned: boolean;
    deliverables: DeliverablesState;
    /** Latest `workspace/changes` event (summary stays on the host). */
    workspaceChangesEvent: {
        turn: number;
        seq: number;
    } | null;
    /** Image turn in flight: previous selection to restore + switch instant. */
    visionTmp: {
        prev: ReturnType<ModelSelection['currentSelection']>;
        switchAt: number;
    } | null;
    /** 难度路由状态（kernel/difficulty.ts）。 */
    difficulty: DifficultyState;
    /** 本回合工具失败次数（难度信号，turn/start 清零）。 */
    toolErrors: number;
    /** Instant the most recent turn STARTED (vision restore ordering). */
    lastTurnStartAt: number;
    /** Live background jobs of this session (running + stopping). */
    bgJobs: number;
    todos: {
        completed: number;
        inProgress: number;
        pending: number;
    } | null;
    todosItems: Array<{
        content: string;
        status: string;
    }>;
    /** Jobs board cache: id → last known state (fed by jobs.list + onJobDone;
     *  terminal states survive the live-list drop so the FINAL board can
     *  commit with ✓/✗/⚠ marks). */
    jobsCache: Map<string, {
        label?: string | undefined;
        status: string;
        startedAt?: number | undefined;
    }>;
    /** Committed batch identity (id:status 排序拼接)：终态板提交一次后，30s
     *  心跳重新拉到的同一批终态任务不得再次提交。 */
    committedJobsKey: string;
    /** id:status of every job already committed to the chat flow — the merge
     *  skips them so a LATER batch finishing cannot re-commit the old board
     *  (pre-review: cache.delete was undone by the next heartbeat's merge). */
    committedJobKeys: Set<string>;
    runningSince?: number | null;
    /** tool/call events whose tool/result has not arrived yet (live-turn
     *  orphan detection for the duplicate-dsh-tools scheduler crash). */
    pendingToolCalls: Map<string, {
        seq: number;
        turn: unknown;
        step: unknown;
    }>;
}
export interface WorkflowRun {
    id: string;
    /** Session that drove the run (runs are per-session, not global state). */
    sessionId?: string | undefined;
    name: string;
    startedAt: number;
    /** Bounded: a long run must not grow without limit. */
    phases: Array<{
        title: string;
        startedAt: number;
    }>;
    agents: Array<{
        seq: number;
        label: string;
        outcome?: string | undefined;
    }>;
    logs: string[];
    running: boolean;
    stopReason: string | undefined;
}
/** One queued approval request (head renders the float; the rest wait in
 *  order — parent + subagents can ask CONCURRENTLY). */
export interface ApprovalEntry {
    req: ApprovalRequest;
    settle: (outcome: string) => void;
    cancelled?: boolean;
}
/** One queued user-question waterfall. */
export interface QuestionsEntry {
    questions: unknown[];
    resolve: (v: {
        answers: unknown[];
    }) => void;
    reject: (e: Error) => void;
    cancelled?: boolean;
}
/** Domain slices: the shared runner state, regrouped by domain. The root
 *  App keeps ONLY the kernel primitives; every other piece of state lives
 *  here and modules read/write it through `app.slices.<domain>.<field>`.
 *  New state MUST land in a slice — scripts/check-arch.mjs enforces it.
 */
/**
 * One settled approval, kept only for display. `outcome` is the host's own
 * vocabulary (allow/allow-always/reject), so the history never invents states.
 */
export interface ApprovalRecord {
    at: number;
    toolName: string;
    reason: string;
    outcome: string;
    sessionId: string | undefined;
}
export interface AppSlices {
    /** nvim process / window lifecycle + boot entry. */
    runtime: {
        readonly nvim: NeovimClient | null;
        readonly child: ReturnType<typeof import('node:child_process')['spawn']> | null;
        readonly channelIdValue: number | null;
        readonly disposed: boolean;
        readonly quitting: boolean;
        readonly chatWinId: number | null;
        readonly reasoningOpen: boolean;
        readonly reasoningWinId: number | null;
        readonly feedDisposer: (() => void) | null;
        readonly hostDisposers: Array<() => void>;
        readonly spinnerTimer: ReturnType<typeof setInterval> | null;
        readonly spinnerIndex: number;
        readonly idleRefreshTimer: ReturnType<typeof setInterval> | null;
        /** /restart requested: the successor spawns in quit() AFTER the old
         *  nvim fully released the terminal and the session logs flushed. */
        readonly restartPending: boolean;
        /** Child exit observed while boot is still connecting (startup config
         *  error): recorded so boot's catch exits non-zero instead of 0. */
        readonly childExitDuringBoot: {
            code: number | null;
            signal: string | null;
        } | null;
        boot: () => Promise<void>;
        /** Owner ops: cross-domain consumers mutate runtime state ONLY here. */
        setChatWin: (id: number | null) => void;
        setReasoning: (open: boolean, win: number | null) => void;
        spinnerSet: (timer: ReturnType<typeof setInterval> | null) => void;
        spinnerStep: (mod: number) => void;
        setRestartPending: (v: boolean) => void;
    };
    /** Sessions, history, active-session state + subagent registry. */
    sessions: {
        readonly live: Map<string, SessionRec>;
        readonly activeId: string | null;
        readonly historyHeaders: Array<{
            id: string;
            cwd?: string | undefined;
            createdAt?: number | undefined;
            title?: string | undefined;
            origin?: string | undefined;
            inheritedEventCount?: number | undefined;
        }>;
        readonly historyById: Map<string, {
            id: string;
            cwd?: string | undefined;
            createdAt?: number | undefined;
            title?: string | undefined;
            origin?: string | undefined;
            inheritedEventCount?: number | undefined;
        }>;
        readonly sessionEntries: Array<{
            id: string;
            title: string;
            active: boolean;
            kind: string;
        }>;
        readonly runningSubagents: Map<string, {
            parentId: string;
            label: string;
            startedAt: number;
        }>;
        readonly childParent: Map<string, {
            parentId: string;
            label: string;
        }>;
        refreshHistory: () => Promise<void>;
        refreshList: () => void;
        disposeLiveSession: (id: string) => Promise<void>;
        readState: () => unknown;
        recordState: (id: string) => void;
        /** Persist one UI preference (`dense`, …) next to the resume pointer. */
        saveUiPref: (key: string, value: unknown) => void;
        /** Read one persisted UI preference. */
        uiPref: <T>(key: string) => T | undefined;
        createSession: (cwdPath?: string) => Promise<void>;
        resumeSession: (id: string) => Promise<void>;
        updateTitle: () => void;
        switchTo: (id: string) => Promise<void>;
        selectSession: (id: string) => Promise<void>;
        forkSession: (directive: string | undefined) => Promise<string | undefined>;
        listSubagentChildren: (parentId: string) => Promise<Array<{
            id: string;
            label: string;
            running: boolean;
            mode: string | undefined;
            createdAt?: number | undefined;
        }>>;
        seedRunningSubagents: (parentId: string) => Promise<void>;
        cleanSubagentChain: (parentId: string, childId: string) => Promise<boolean>;
        runningSubagentsOf: (parentId: string | null) => Array<{
            parentId: string;
            label: string;
            startedAt: number;
        }>;
    };
    /** Feed rendering / window surface helpers. */
    ui: {
        activeFeed: () => FeedRenderer | undefined;
        feedForSubagent: (info: SubagentInfo) => SessionRec | undefined;
        welcomeLines: () => {
            above: Array<{
                text: string;
                group?: string;
            }>;
            below: Array<{
                text: string;
                group?: string;
            }>;
        };
        ensureSpinner: () => void;
        updateStatusline: () => void;
        refreshBgJobs: () => void;
        foldEvent: (rec: SessionRec, event: SessionEvent) => void;
        maybePushFileDiff: (feed: FeedRenderer, event: SessionEvent, labelPrefix?: string) => void;
        readFileSnapshot: (p: string) => Promise<string | null>;
        /** Pre-edit snapshots by callId. `owner` scopes the turn/end cleanup to
         *  the session that produced the call — an unconditional clear wiped
         *  ANOTHER session's in-flight snapshots and silently dropped its ✎ diffs. */
        readonly pendingFileSnaps: Map<string, {
            display: string;
            before: string | null;
            owner?: string | undefined;
        }>;
        readonly renderedDiffCalls: WeakMap<FeedRenderer, Set<string>>;
        /** Most recent render-intent diff per path — the data a side-by-side review
         *  needs. The feed renders a UNIFIED diff inline and then discards both
         *  sides; keeping them here is what makes `/diff` possible WITHOUT re-reading
         *  the files, which may have changed since the turn that produced the diff. */
        readonly recentDiffs: Map<string, {
            oldText: string | null;
            newText: string | null;
            at: number;
        }>;
        /** Session-wide ledger of every touched path (`/changes`), keyed by feed so
         *  one session's history cannot leak into another's. Metadata only — never
         *  file contents — so a long session cannot grow it into a second repo. */
        readonly changeLedger: WeakMap<FeedRenderer, Map<string, FileChange>>;
        readonly pendingEchoes: Map<string, string[]>;
        /** Notices emitted before the first session attached (flushed on attach). */
        readonly pendingNotices: unknown[];
    };
    /** Extension surface (ext-api.ts owns; installs run before boot). */
    ext: {
        extApi: TuiExtApi;
        readonly extReadyResolve: (() => void) | null;
        extFire: (event: ExtEventName, payload: unknown) => void;
        readonly extSessionSubs: Array<{
            filter: ExtSessionEventFilter;
            cb: (sid: string, ev: SessionEvent) => void;
        }>;
        extDispatchSessionEvent: (sessionId: string, event: SessionEvent) => void;
        readonly extLuaSubs: Map<string, Set<string> | 'all'>;
        extNodeCleanup: (() => void | Promise<void>) | null;
        readonly pendingCardInput: {
            mark: number;
            actionIdx: number;
            prompt: string;
        } | null;
        readonly extNodeHandlers: Map<string, {
            handler: (method: string, args: unknown[]) => unknown | Promise<unknown>;
            timeoutMs: number;
            token?: symbol;
        }>;
        readonly extStatusSegments: Map<string, {
            text: string;
            priority: number;
        }>;
        /** Owner ops: cross-domain consumers mutate ext state ONLY here. */
        setPendingCardInput: (v: {
            mark: number;
            actionIdx: number;
            prompt: string;
        } | null) => void;
        fireExtReady: () => boolean;
    };
    /** Transcript / event-stream reconstruction. */
    trans: {
        sessionEvents: (session: HarnessSession) => SessionEvent[];
        synthesizeToolResult: (rec: SessionRec, callId: string, seq: number | undefined, turn: unknown, step: unknown) => void;
        surfaceReplace: (session: HarnessSession, type: string, seq: number, data: unknown) => void;
        repairOrphanToolCalls: (rec: SessionRec) => number;
        readonly workflowRuns: Map<string, WorkflowRun>;
    };
    /** Agent interaction: commands, input routing, pending UI, subagent chat. */
    agent: {
        followup: (rec: SessionRec, text: string, images?: Array<SaveImageAttachment | Extract<MessageContent, {
            type: 'image';
        }> | string>) => Promise<void>;
        queueSubagentPrompt: (parentAgent: unknown, childId: string, text: string) => Promise<void>;
        send: (text: string) => void;
        pasteClipboardImage: () => void;
        applyModelSelection: (next: ModelRef['current']) => Promise<void>;
        pickModel: (arg: string | undefined) => Promise<void>;
        stopCommand: () => void;
        onInput: (text: string) => void;
        onCommand: (line: string) => void;
        helpCommand: () => Promise<void>;
        restartCommand: () => void;
        openDirPicker: (startPath: string) => Promise<string | null>;
        atQuery: (query: string, start?: number) => Promise<void>;
        currentSelection: () => ReturnType<ModelSelection['currentSelection']>;
        commandSpecs: CommandSpec[];
        /** Set when the catalog push found no active agent and therefore skipped the
         *  OFFICIAL commands. Cleared once a push with an agent succeeds — the retry
         *  hook reads it to avoid re-pushing on every session switch. */
        officialCatalogPending: boolean;
        readonly pendingInput: string[];
        readonly pendingImages: Array<SaveImageAttachment | Extract<MessageContent, {
            type: 'image';
        }>>;
        /** Durable file uploads queued for the next submit. */
        readonly pendingFiles: FileAttachmentRef[];
        readonly pendingRename: {
            kind: 'workspace';
            id: string;
        } | {
            kind: 'session';
            id: string;
            background?: boolean;
        } | null;
        readonly pendingQueueEdit: {
            list: 'nextTurn' | 'nextStep';
            messageId: string;
        } | null;
        readonly approvalSettle: ((outcome: string) => void) | null;
        readonly approvalReq: ApprovalRequest | null;
        /** Queue for CONCURRENT approval requests (parent + subagents can both
         *  ask): the head renders the float; the rest wait in order. */
        readonly approvalQueue: ApprovalEntry[];
        /** Bounded decision log (newest last) for the ACTIVE session. Approvals are
         *  the one gate where the user answers "why did I allow that?" much later —
         *  without a record the question is unanswerable, since the float and its
         *  notice are gone. Reloaded from disk when the active session changes. */
        readonly approvalHistory: ApprovalRecord[];
        /** Session whose decisions `approvalHistory` currently holds (null = not
         *  loaded yet). Guards the reload so switching sessions does not leak one
         *  conversation's decisions into another's `/approvals`. */
        readonly approvalHistoryFor: string | null;
        readonly questionsResolve: {
            resolve: (v: {
                answers: unknown[];
            }) => void;
            reject: (e: Error) => void;
        } | null;
        /** Queue for CONCURRENT user-question waterfalls (same head/tail split). */
        readonly questionsQueue: QuestionsEntry[];
        enqueueApproval: (e: ApprovalEntry) => void;
        abortApproval: (e: ApprovalEntry) => void;
        drainApprovals: (outcome: string) => void;
        enqueueQuestions: (e: QuestionsEntry) => void;
        abortQuestions: (e: QuestionsEntry) => void;
        drainQuestions: () => void;
        readonly pickerSettle: ((value: string | null) => void) | null;
        readonly dirSettle: ((picked: string | null) => void) | null;
        readonly subagentView: {
            childId: string;
            feed: FeedRenderer;
        } | null;
        readonly subagentChat: {
            childId: string;
            parentId: string;
            label: string;
            feed: FeedRenderer;
        } | null;
        readonly pendingSubagentFollowup: {
            childId: string;
            label: string;
        } | null;
        openSubagentView: (childId: string, label: string) => Promise<void>;
        openSubagentChat: (childId: string, label: string) => Promise<void>;
        sendToSubagent: (text: string) => void;
        /** Owner ops: cross-domain consumers mutate agent state ONLY here. */
        setApproval: (entry: ApprovalRequest | null, settle: ((outcome: string) => void) | null) => void;
        settleApproval: (outcome: string) => void;
        setPickerSettle: (fn: ((value: string | null) => void) | null) => void;
        settlePicker: (value: string | null) => void;
        setQuestions: (r: {
            resolve: (v: {
                answers: unknown[];
            }) => void;
            reject: (e: Error) => void;
        } | null) => void;
        settleQuestions: (answers: unknown[]) => void;
        rejectQuestions: (reason?: string) => void;
        setDirSettle: (fn: ((picked: string | null) => void) | null) => void;
        resolveDirPicker: (picked: string | null) => void;
        setPendingRename: (v: {
            kind: 'workspace';
            id: string;
        } | {
            kind: 'session';
            id: string;
            background?: boolean;
        } | null) => void;
        setPendingQueueEdit: (v: {
            list: 'nextTurn' | 'nextStep';
            messageId: string;
        } | null) => void;
        setSubagentView: (v: {
            childId: string;
            feed: FeedRenderer;
        } | null) => void;
        setSubagentChat: (v: {
            childId: string;
            parentId: string;
            label: string;
            feed: FeedRenderer;
        } | null) => void;
        readonly livePopup: {
            kind: 'jobs' | 'todo';
            update: (items: Array<{
                label: string;
                value: string;
            }>) => void;
        } | null;
        setLivePopup: (v: {
            kind: 'jobs' | 'todo';
            update: (items: Array<{
                label: string;
                value: string;
            }>) => void;
        } | null) => void;
        /** Clear the transient input-flow state (rename/queue-edit prompts,
         *  pending images, subagent followup) — session switches use it so a
         *  half-finished flow never leaks into the next session. */
        clearPendings: () => void;
    };
}
/** Writable view of one slice — owners cast to it inside their own
 *  files; every other file sees readonly state and must go through the
 *  domain ops. */
export type WritableSlice<T> = {
    -readonly [K in keyof T]: T[K];
};
/** The complete cross-module surface: kernel primitives + the domain
 *  slices. Nothing else may live on the root (check-arch.mjs guards). */
export interface App {
    ctx: Context;
    runtimeCtx: RuntimeCtx;
    config: RunnerConfig;
    headless: boolean;
    watchdogMs: number;
    dumpPath: string;
    errorLogPath: string;
    /** Live-session store: dsh 0.1.5 removed the `sessions` service — this
     *  adapter reads the agents registry (`Agent.session`). Never assign to
     *  the cordis context (property set = service registration semantics). */
    liveSessions: SessionStore;
    svc: <K extends keyof ServiceMap>(name: K) => ServiceMap[K] | undefined;
    luaCall: (code: string, args?: unknown[]) => Promise<any>;
    lua: {
        ensureChat: (id: string) => Promise<any>;
        ensureReasoning: (id: string) => Promise<any>;
        setActive: (id: string) => Promise<any>;
    };
    requestExit: (code?: number) => void;
    /** Drain notices buffered before any session was active into `feed`. */
    flushPendingNotices: (feed: {
        appendNotice: (t: unknown) => void;
    }) => void;
    notice: (text: unknown) => void;
    openPicker: (title: string, items: Array<{
        label: string;
        value: string;
        active?: boolean;
    }>) => Promise<string | null>;
    /** Live picker: same float, but `update` re-renders the OPEN popup in
     *  place (jobs/todo lists refresh their statuses without closing). */
    openLivePicker: (title: string, items: Array<{
        label: string;
        value: string;
    }>) => {
        pick: Promise<string | null>;
        update: (items: Array<{
            label: string;
            value: string;
        }>) => void;
    };
    guard: (label: string, fn: (...args: any[]) => Promise<unknown>) => (...args: any[]) => Promise<void>;
    sleep: (ms: number) => Promise<void>;
    exitDiag: (kind: string, ...detail: unknown[]) => void;
    quit: (code?: number) => Promise<void>;
    teardown: () => Promise<void>;
    /** Close the nvim window; resolves TRUE only when the child is dead. */
    closeNvimWindow: () => Promise<boolean>;
    /** Command registry (kernel bootstrap facility: every module registers
     *  its specs at install time, so the mechanism exists from t=0). */
    registerCommands: (specs: CommandSpec[]) => CommandSpec[];
    commandCatalog: () => Array<{
        name: string;
        desc: string;
        args?: CommandArg[];
    }>;
    refreshCommandCatalog: () => Promise<void>;
    /** Re-push the catalog IF an earlier push had to skip the official commands
     *  for lack of an active agent. Safe to call on every session switch: it is a
     *  no-op once the merge has succeeded. */
    retryOfficialCatalog: () => void;
    /** Registered command specs — the kernel registry's storage (modules
     *  register at install time, so it must live from t=0). */
    commandSpecs: CommandSpec[];
    /** Set when a catalog push found no active agent and had to skip the OFFICIAL
     *  commands; cleared once a push with an agent succeeds. MEASURED need: the
     *  boot-time push runs BEFORE the session exists, so without this flag the
     *  official commands never reached the completion menu at all. */
    officialCatalogPending: boolean;
    /** The domain slices (the physical state home). */
    slices: AppSlices;
}
/** Build the App object. All state and core services live here; module-owned
 *  functions start as no-ops and are installed afterwards. `ctx` is the
 *  cordis plugin context (inject/effect); `runtimeCtx` is the injected
 *  runtime with the agent/session services. */
/**
 * Merge OFFICIAL registry descriptors into the completion catalog, in place.
 *
 * WHY MERGING (and not a separate list): the input box completes from ONE
 * catalog. Offering official commands through a separate `/commands` command
 * meant you could LIST `/kb` and still not complete it on a leading `/`.
 *
 * Three rules, each asserted:
 *   · a name WE already own is never overwritten — a plugin must not be able to
 *     take over `/sessions` in the menu;
 *   · a descriptor with no `input.hint` contributes NO argument — inventing one
 *     would put a placeholder on screen that nobody declared;
 *   · the official side advertises free-form input as a HINT only, so it maps to
 *     a `free` argument (hinted, never completed) rather than a fabricated
 *     choice list.
 */
export declare const mergeOfficial: (entries: Array<{
    name: string;
    desc: string;
    args?: CommandArg[];
}>, listed: ReadonlyArray<{
    name: string;
    description: string;
    input?: {
        hint?: string;
    } | undefined;
}>) => number;
export declare function createApp(ctx: Context, runtimeCtx: RuntimeCtx, config: RunnerConfig): App;
