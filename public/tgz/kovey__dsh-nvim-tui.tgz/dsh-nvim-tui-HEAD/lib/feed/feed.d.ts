/**
 * FeedRenderer: maps DSH session/event transcript events into the nvim chat
 * buffer. Pure presentation — keeps a line model in memory and syncs it to
 * the buffer, throttled.
 *
 * Model:
 *  - `base`: committed RAW lines (markup included; parsed at flush)
 *  - `tail`: the currently streaming assistant text (rewritten in place, so a
 *    full `assistant/message` naturally replaces the streamed prefix)
 *  - `calls`: tool/call records paired with their tool/result (elapsed, error)
 *
 * Rendering:
 *  - Incremental `nvim_buf_set_lines`: the view is diffed against the last
 *    flushed view and only changed rows are rewritten.
 *  - Role highlights (user/notice/tool/error/subagent/workflow) are derived
 *    from line prefixes; inline `**bold**` / `` `code` `` / ```fences``` are
 *    stripped in the buffer and rendered as extmark spans; markdown tables
 *    become aligned box-drawing tables (lib/table.js). The whole highlight
 *    pass for a flush runs as ONE Lua RPC.
 *
 * Concurrency contract:
 *  - `nvim_buf_set_lines` is the only blocking step of a flush.
 *  - Cursor moves and statusline writes are fire-and-forget: a wedged RPC must
 *    never block the feed.
 *  - Events arriving during a flush set `dirty`; the flush chains a follow-up.
 */
import { NeovimClient } from 'neovim';
import type { ChatMessage, SessionEvent } from '../kernel/types.js';
/** Inline highlight span (byte offsets into the rendered line). */
export interface Span {
    s: number;
    e: number;
    group: string;
}
/** One parsed view row (markup stripped, spans byte-indexed). */
export interface ParsedLine {
    text: string;
    spans: Span[];
    code: boolean;
    fenceToggled: boolean;
    /** Undefined is meaningful (no group) — the producer passes it explicitly. */
    group?: string | null | undefined;
}
export interface FeedOptions {
    flushDelayMs?: number;
    idsProvider?: (() => Promise<unknown>) | null;
    activeChecker?: (() => boolean) | null;
    reasoningBuf?: number | null;
    reasoningView?: (() => {
        open: boolean;
        win: number | null;
    } | null) | null;
    inlineReasoning?: boolean;
    /** Blue whale wallpaper/watermark (default off; the runner enables it). */
    whale?: boolean;
    /** Empty-state welcome block: lines ABOVE the whale (big banner + title)
     *  and lines BELOW it (usage hints); rows may carry a highlight group. */
    welcome?: () => {
        above?: WelcomeLine[];
        below?: WelcomeLine[];
    };
}
export interface WelcomeLine {
    text: string;
    group?: string;
}
/** One card action. kind 'plain' (default) fires immediately; 'confirm'
 *  gates behind a picker; 'input' collects a typed value via the input box
 *  (headless degrades both to plain). */
export interface ExtCardAction {
    label: string;
    value: string;
    /** Optional fields accept an EXPLICIT undefined (extension callers forward
     *  their own optionals verbatim — exactOptionalPropertyTypes). */
    kind?: 'plain' | 'confirm' | 'input' | undefined;
    confirmText?: string | undefined;
    inputPrompt?: string | undefined;
    inputDefault?: string | undefined;
}
/** Ext-card render options (the P1 extension API's ui.card). Optionals accept
 *  an explicit undefined: extension callers forward their own optionals
 *  verbatim (exactOptionalPropertyTypes). */
export interface ExtCardOpts {
    /** Extension name shown in the card header. */
    plugin: string;
    title: string;
    body: string;
    actions?: ExtCardAction[] | undefined;
    /** Interactive activation (P4-③): invoked with the action's value when
     *  the user activates the card in the chat (1-9 / Enter). plain/confirm
     *  actions pass action.value; input actions pass the TYPED text. */
    onAction?: ((value: string) => void) | undefined;
}
/** Handle returned by pushExtCard: update/dismiss the block in place. */
export interface ExtCardHandle {
    id: string;
    update(next: Partial<ExtCardOpts>): void;
    dismiss(): void;
}
interface ToolCallRecord {
    name: string;
    startedAt: number;
    /** Raw model-supplied JSON arguments, kept so the approval float can show
     *  the exact command/path being approved (dsh-user-approval callId). */
    args?: string;
}
/** Prefix for a quota failure, or '' for anything else.
 *
 * Pure and exported so the mapping is asserted directly: the two codes mean
 * different things and a wrong mapping sends the user to top up the wrong
 * account — which is exactly the mistake the codes exist to prevent. */
/**
 * How a FAILED tool result must be presented.
 *
 * `unknown` is the case that matters: the call may already have taken effect
 * (a run, a write, a network side effect), so showing it as a plain `✗` invites
 * a blind retry of something that already happened. dsh 0.2.0 spells this out in
 * its repair docs ("cause-specific retry guidance") and the code is emitted by
 * our own tail repair as well. Pure, so the mapping is asserted directly.
 */
export declare const failureMark: (code: string | undefined) => 'unknown' | 'failed';
export declare const quotaAdvice: (code: string | undefined) => string;
export declare class FeedRenderer {
    nvim: NeovimClient;
    bufId: number;
    winId: number;
    flushDelayMs: number;
    idsProvider: (() => Promise<unknown>) | null;
    activeChecker: () => boolean;
    reasoningBuf: number | null;
    reasoningView: () => {
        open: boolean;
        win: number | null;
    } | null;
    inlineReasoning: boolean;
    panelLines: string[];
    panelFlushed: number;
    panelVersion: number;
    lastPanelVersion: number;
    toolActivity: {
        name: string;
        startedAt: number;
    } | null;
    /** Consecutive reasoning-panel write failures (self-heal trigger). */
    reasoningFailures: number;
    /** Card extmark failures (diagnostics only — one bad card must not stop the batch). */
    cardFailures: number;
    base: string[];
    tail: string;
    reasoningTail: string;
    reasoningStartedAt: number | null;
    turnStartedAt: number | null;
    turnMarkerBase: number | null;
    calls: Map<string, ToolCallRecord>;
    ptcCalls: Map<string, ToolCallRecord>;
    subagents: Map<string, {
        provider: string;
        startedAt: number;
    }>;
    timer: ReturnType<typeof setTimeout> | null;
    flushing: Promise<void> | null;
    tokenNs: number | null;
    lastActivityCount: number;
    dirty: boolean;
    ns: number | null;
    lastView: string[];
    dense: boolean;
    /** Ext cards (P1 extension API): card id → tracked base range, so
     *  update()/dismiss() splice the block in place (flush rebuilds the full
     *  view from base, so deletions propagate). */
    extCards: Map<string, {
        start: number;
        length: number;
        merged: ExtCardOpts;
    }>;
    extCardSeq: number;
    /** Interactive cards (P4-③): cardId → action surface. */
    cardHandlers: Map<string, {
        actions: ExtCardAction[];
        onAction?: ((value: string) => void) | undefined;
    }>;
    /** cardId → rendered extmark range (markId + buffer rows). */
    cardRanges: Map<string, {
        markId: number;
        startRow: number;
        endRow: number;
    }>;
    cardNs: number | null;
    /** Pinned todo panel (todo/write): while ANY visible item is incomplete
     *  the standing list renders at the BOTTOM of the view (above the
     *  thinking row, never displaced by streaming content); once every item
     *  is ✓ the block COMMITS into base (ordinary chat content) and stays
     *  pinned across turns like the jobs board. */
    todoLiveRows: string[];
    /** Todo items already FLUSHED into a committed all-✓ board (by content).
     *  The host's todo_write re-sends the COMPLETE standing list every time —
     *  without this set every later board/commit re-lists the old completed
     *  items and the lists grow without bound. Re-opened items (any
     *  non-completed status) leave the set and come back. */
    committedTodos: Set<string>;
    /** Pinned jobs board (setJobsBoard): same bottom-pinned slot — updates
     *  replace live; commitJobsBoard lands the FINAL state (all jobs
     *  terminal) into base. */
    jobsLiveRows: string[];
    jobsLiveKey: string;
    /** Key of the board already committed to `base` (idempotence guard). */
    committedJobsKey: string;
    /** Cached viewport width: the cap renderTable wraps overwide tables
     *  against (refreshed by winSize, throttled once per 2s per flush). */
    lastWinW: number;
    lastWinAt: number;
    /** Cached reasoning-panel width for the panel table cap (throttled the
     *  same way — a per-flush width RPC would tax the streaming path). */
    lastPanelW: number;
    lastPanelAt: number;
    whale: boolean;
    welcome: (() => {
        above?: WelcomeLine[];
        below?: WelcomeLine[];
    }) | null;
    whaleFrame: number;
    whaleTicker: ReturnType<typeof setInterval> | null;
    ticker: ReturnType<typeof setTimeout> | null;
    eventTime: number;
    constructor(nvim: NeovimClient, bufId: number, winId: number, { flushDelayMs, idsProvider, activeChecker, reasoningBuf, reasoningView, inlineReasoning, whale, welcome, }?: FeedOptions);
    /** Clear the transcript (the /clear command). */
    clear(): void;
    /** Notice line (runner lifecycle, status). Multi-line text (e.g. an error
     *  message with a stack trace) is collapsed to ONE line: a string with
     *  embedded newlines fed to nvim_buf_set_lines throws E5108 and kills the
     *  whole flush — the /subagents E95 failure notice was invisible this way
     *  and every later render that included it silently failed. */
    appendNotice(text: unknown): void;
    pushBlock(role: string, text: string): void;
    /** User bubble with image attachment labels (📎 lines under the text). */
    pushUser(text: string, imageLabels: string[]): void;
    pushTool(line: string): void;
    /** File-change diff block (✎ header + `+ `/`- `/context lines). ALWAYS
     *  renders in the chat — the panel stays the compact activity log (the
     *  tool ✓ line still routes there when it is open), while the diff is the
     *  content the user wants to read in the conversation. Lines are rendered
     *  verbatim — no markdown stripping inside code content. */
    pushDiff(header: string, lines: string[]): void;
    pushSubagent(line: string): void;
    pushWorkflow(line: string): void;
    /** Visible standing-todo items for one todo/write payload: completed
     *  items that were already FLUSHED into a committed board are hidden —
     *  the host re-sends the whole standing list on every write, and without
     *  the flush every later board/commit would re-list them (unbounded
     *  growth). Non-completed items always show. */
    todoVisibleItems(todos: Array<{
        content: string;
        status: string;
    }>): Array<{
        content: string;
        status: string;
    }>;
    /** Pinned jobs board (the /tasks counterpart in the chat): while ANY
     *  job is running/stopping the board renders at the BOTTOM of the view
     *  (above the thinking row); identical content is a no-op. */
    setJobsBoard(rows: string[]): void;
    /** All jobs terminal: the FINAL board state lands in base (ordinary chat
     *  content) and the pinned slot clears. */
    /** Commit the FINAL jobs board. `batchKey` identifies the batch (ids +
     *  statuses — the caller's identity, NOT the rendered text: two different
     *  batches can render identically). Re-committing the same batch is a
     *  no-op, so a heartbeat racing the terminal state cannot duplicate the
     *  board in the transcript. */
    commitJobsBoard(rows: string[], batchKey?: string): void;
    /** Ext card (P1 extension API): a `▣ plugin · title` header block with an
     *  indented body and optional action hints. Returns a handle that updates
     *  or dismisses the block IN PLACE (tracked base range). With `onAction`
     *  set, the chat buffer gains activation: cursor on the card + 1-9 fires
     *  the action directly, Enter opens the action picker. */
    pushExtCard(opts: ExtCardOpts, cardId?: string): ExtCardHandle;
    /** Card block lines: blank separator + header + indented body + hints. */
    private extCardLines;
    /** After a splice at `afterStart`, adjust every later card's base offset. */
    private shiftExtCards;
    /** Sync the interactive-card extmark ranges (P4-③): one block mark per
     *  card covering its RENDERED rows (post markdown-transform). Marks are
     *  re-placed only when a card's range changed; dismissed cards' marks
     *  are deleted. */
    private syncCardMarks;
    /** Resolve the interactive card under an extmark (P4-③). actionIdx null
     *  → returns the action list for the picker (items carry their kind);
     *  a number → { cardId, action } for the dispatcher (plain/confirm/input
     *  routing lives in boot.ts). Null when no interactive card owns the mark
     *  (action-less cards stay display-only). */
    activateCard(markId: number, actionIdx: number | null): ExtCardAction[] | {
        cardId: string;
        action: ExtCardAction;
    } | null;
    /** Look up a card by mark id: returns the handler surface. */
    resolveCardAction(markId: number, actionIdx: number | null): {
        cardId: string;
        actions: ExtCardAction[];
        action?: ExtCardAction;
    } | null;
    /** Fire a resolved card action with the FINAL value (plain/confirm pass
     *  action.value; input passes the typed text). Returns false when the
     *  card vanished since resolution. */
    fireCardAction(cardId: string, value: string): boolean;
    pushError(text: unknown): void;
    /** Extract plain text from a message (content blocks or raw text). */
    static messageText(message: ChatMessage | undefined): string;
    /** Display labels for a message's image blocks (durable attachment refs). */
    static messageImages(message: ChatMessage | undefined): string[];
    /** Display labels for a message's durable file-upload blocks. */
    static messageFiles(message: ChatMessage | undefined): string[];
    /** Extract reasoning (thinking) text from a message's content blocks. */
    static messageReasoning(message: ChatMessage | undefined): string;
    /** Close the open thinking block. The compact chat line is TRANSIENT — it
     *  lives only in the activity region while thinking, so nothing is pushed
     *  to the chat base (details are in the panel). Fallback without a panel:
     *  keep the line in chat so there is some record; with `inlineReasoning`
     *  (read-only replays like the subagent view) the full thinking text is
     *  inlined as a dim block instead. */
    commitReasoning(): void;
    /**
     * Structured tool results (web_search hits, grep/glob matches, …): a JSON
     * array of objects itemizes into compact rows instead of one truncated
     * blob — the terminal's counterpart of the web's per-tool cards. Returns
     * null when the text is not a usable JSON array.
     */
    static structuredHits(text: string): string[] | null;
    /** One-line preview of raw model JSON arguments. */
    static argsPreview(argumentsText: string | undefined): string;
    static truncate(text: unknown, max?: number): string;
    applyEvent(event: SessionEvent, { history }?: {
        history?: boolean;
    }): void;
    subagentStart(info: {
        runId?: string;
        provider?: string;
        id?: string;
    }): void;
    subagentEnd(info: {
        runId?: string;
        provider?: string;
        id?: string;
        stopReason?: string;
    }): void;
    /** One identity for a subagent run across start/end/elapsed lookups. */
    static subagentKey(info: {
        runId?: string;
        id?: string;
    } | undefined): string;
    workflowStart(info: {
        id?: string;
        meta?: {
            name?: string;
        };
    }): void;
    workflowPhase(_info: unknown, title: string): void;
    workflowEnd(_info: unknown, result: {
        stopReason?: string;
        error?: string;
    }): void;
    /** Move the streaming tail into committed base lines. */
    commitTail(): void;
    /**
     * Parse one raw line into buffer text + inline highlight spans.
     * Fences (```) toggle whole-line code highlighting. With `quoteAware`
     * (assistant lines only — user lines keep their own `> ` prefix), markdown
     * blockquotes strip the prefix and get the dim-italic quote group.
     * `#{1,6} ` headings keep their text and get the heading group.
     */
    static parseLine(raw: string, fenceOpen: boolean, quoteAware?: boolean): ParsedLine;
    /** Toggle the whale art and re-render (the /whale command). */
    setWhale(on: boolean): void;
    /** Animate the wallpaper: advance one frame and re-render (empty only). */
    private ensureWhaleTicker;
    private stopWhaleTicker;
    /** Current window size via the ids provider (fallback 40×100). Success
     *  updates the table width cache (lastWinW) that renderTable caps
     *  overflow against. */
    private winSize;
    schedule(): void;
    flush(): Promise<void>;
    /** Sync the activity panel (reasoning + tools) for this session.
     *  A wiped panel buffer (external :bwipe etc.) must never kill the chat
     *  flush — the panel is auxiliary, the transcript is not. */
    flushReasoningBuffer(): Promise<void>;
    flushReasoningBufferInner(): Promise<void>;
    moveCursor(lineCount: number): Promise<void>;
}
export {};
