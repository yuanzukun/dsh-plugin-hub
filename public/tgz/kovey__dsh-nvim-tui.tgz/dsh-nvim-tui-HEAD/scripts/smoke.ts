// Headless smoke test: spawn nvim --headless with the dsh_tui plugin, connect
// over the socket, and verify the full RPC roundtrip without a DSH host:
//   Node → nvim (lua, buf_set_lines)              ✓
//   nvim → Node (rpcnotify notification)          ✓
//   FeedRenderer transcript → chat buffer lines    ✓
//   chat buffer undo disabled (undolevels = -1)   ✓
//   multi-session: ensure_chat / set_sessions / set_active  ✓
//   require survives rtp resets (package.preload) ✓
// Run: npm run smoke

import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { spawnNvim, connectNvim } from '../lib/kernel/bridge.js'
import { FeedRenderer } from '../lib/feed/feed.js'
import { WHALE_RENDER_ROWS, whaleFrames, WHALE_EMOJI_FRAMES, layoutWhaleRows, WHALE_ROWS } from '../lib/feed/whale.js'
import { foldUsage, billedInput, cacheHitRate, estimateCost, formatTokens, formatElapsed, modeLabel, escapeStatusline } from '../lib/feed/stats.js'
import { sniffMediaType, parseImageDataUrl, splitImageDataUrls, imageLabel } from '../lib/feed/images.js'
import { diffTexts, fileDiffsFromMeta } from '../lib/feed/diff.js'
import { t, setLocale, locale } from '../lib/kernel/i18n.js'
import { matchIntent } from '../lib/commands/nlcmd.js'
import { ageLabel, isExpired, orderSubagentChildren } from '../lib/kernel/subagent-clean.js'
import { runningBadge } from '../lib/statusline/index.js'
import stringWidth from 'string-width'
import { matchSessionEventFilter } from '../lib/ext-api/index.js'
import { readPatchRowIds, packageExists } from '../lib/deps/index.js'
import { installRootCandidates } from '../lib/deps/services.js'
import { checkSessionLog } from '../lib/kernel/session-health.js'
import { sessionHealthLines } from '../lib/commands/commands/doctor.js'
import { approvalHistoryLines } from '../lib/commands/commands/approvals.js'
import { appendApproval, loadApprovalHistory, approvalLogPath, parseApprovalLines, APPROVAL_LOG_MAX, ensureApprovalHistory } from '../lib/kernel/approval-log.js'
import { installPluginCommand, parsePluginArgs, gitSpecRef } from '../lib/market/commands/plugin.js'
import { COMMAND_ARGS } from '../lib/kernel/command-args.js'
import { resolve as resolvePath } from 'node:path'
import { mergeOfficial } from '../lib/kernel/app.js'
import { togglePluginEntry } from '../lib/kernel/plugin-toggle.js'
import { archiveVisible, nextArchiveMode, parseArchiveMode } from '../lib/sessions/archive-filter.js'
import { changeStatus, ledgerRows, ledgerTotals, recordChange, summarize } from '../lib/kernel/change-ledger.js'
import { systemOpenArgv, systemRevealArgv } from '../lib/commands/commands/deliverables.js'
import { deliverablePaths, emptyDeliverables, mergePresentedFiles, resolveDeliverablePath } from '../lib/kernel/deliverables.js'
import { parseFeedbackArgs } from '../lib/commands/commands/feedback.js'
import { parseSettingValue } from '../lib/commands/commands/settings.js'
import { appArgv, parseTuiArgs } from '../lib/kernel/cli.js'
import { turnOutlineRows } from '../lib/transcript/commands/outline.js'
import { installSessionController } from '../lib/sessions/session-controller.js'
import { serializeSessionLog } from '../lib/kernel/session-log.js'
import { installChangesCommand } from '../lib/commands/commands/changes.js'
import { installDiffCommand } from '../lib/commands/commands/diff.js'
import { officialRows, runOfficialCommand } from '../lib/commands/commands/official-commands.js'
import { failureMark, quotaAdvice } from '../lib/feed/feed.js'
import { judgeDump, frameTurn } from './e2e-judge.ts'
import { estimateByRules } from '../lib/kernel/difficulty.js'
import { latestTodos, todoGuardReminder, MAX_NUDGES_PER_TURN, installTodoGuard } from '../lib/kernel/todo-guard.js'
import { encodeSessionLog, encodeHeaderOnlyLog } from '../lib/kernel/subagent-clean.js'
import { zstdCompressSync, zstdDecompressSync } from 'node:zlib'
import os from 'node:os'
import {
  parseStars, buildCatalog, searchCatalog, parsePluginYaml,
  setDisabledRows, readDisabledIds, isNpmName, depMatchesEntry, repoRoot, installSpec,
  classifyPnpmError, firstErrorLine, profileDir,
} from '../lib/market/progress.js'

// console.* is async and its output can be swallowed by non-TTY capture
// environments once the nvim child shares the pipe; write synchronously.
const log = (...a: unknown[]) => fs.writeSync(1, a.join(' ') + '\n')

const { child, sockPath } = await spawnNvim({
  // A "user config" VimEnter autocmd registered AFTER the TUI's own (like
  // the nvim-tree auto-open template): it reads the startup buffer the way
  // such plugins do — the buffer must still be VALID inside the batch.
  extraArgs: [
    '--headless',
    '--cmd',
    'lua vim.api.nvim_create_autocmd("VimEnter", { callback = function() vim.g.smokeStartupBufValid = vim.api.nvim_buf_is_valid(1) end })',
  ],
  loadUserConfig: false,
  isolateXdg: true,
})
const nvim = await connectNvim(sockPath)

/** msgpack-RPC boundary: nvim.lua results are structurally unknown by nature. */
const lua = (code: string, args: unknown[] = []): Promise<any> => nvim.lua(code, args as never[])

// Popup operation hints: nvim >= 0.10 embeds them INTO the popup's bottom
// border (native `footer` config, like the title in the top border); older
// nvim gets the legacy detached 1-row bar below the window (M._footer.win).
const footerState = () => lua(`local f = require("dsh_tui")._footer
  local mcfg = vim.api.nvim_win_get_config(f.mainWin)
  if vim.fn.has('nvim-0.10') == 1 then
    -- footer normalizes to [text, hl] tuples: flatten to the text
    local parts = {}
    if type(mcfg.footer) == 'string' then
      parts = { mcfg.footer }
    elseif type(mcfg.footer) == 'table' then
      for _, t in ipairs(mcfg.footer) do
        table.insert(parts, type(t) == 'table' and t[1] or tostring(t))
      end
    end
    return {
      embedded = true,
      valid = vim.api.nvim_win_is_valid(f.mainWin),
      text = table.concat(parts),
      fpos = mcfg.footer_pos,
      detWin = f.win,
      mheight = mcfg.height,
    }
  end
  local fcfg = vim.api.nvim_win_get_config(f.win)
  return {
    embedded = false,
    valid = vim.api.nvim_win_is_valid(f.win),
    text = vim.api.nvim_buf_get_lines(f.buf, 0, -1, false)[1],
    frow = fcfg.row, fcol = fcfg.col, fwidth = fcfg.width, fheight = fcfg.height,
    mrow = mcfg.row, mheight = mcfg.height, mwidth = mcfg.width,
    winhighlight = vim.wo[f.win].winhighlight or "",
  }`, [])
const assertFooter = async (hintPart: string, label: string) => {
  const fs = await footerState()
  assert.ok(fs.valid, `${label}: footer attached to the popup`)
  assert.ok(String(fs.text).includes(hintPart), `${label}: footer carries the operation hints`)
  if (fs.embedded) {
    assert.equal(fs.fpos, 'left', `${label}: hints sit at the left of the bottom border`)
    assert.equal(fs.detWin ?? null, null, `${label}: no detached footer window`)
    return
  }
  assert.equal(fs.fheight, 1, `${label}: footer is one row tall`)
  assert.equal(fs.fwidth, fs.mwidth, `${label}: footer spans the main window width`)
  assert.equal(fs.frow, fs.mrow + fs.mheight + 2, `${label}: footer sits directly under the main window`)
  assert.ok(String(fs.winhighlight).includes('DshTuiStatus'), `${label}: footer uses the statusline highlight`)
}
// Every popup opens centered on the editor: row = (lines - height) / 2 - 2,
// col = (columns - width) / 2, both clamped at the top-left.
const assertCentered = async (winLua: string, label: string) => {
  const cfg = await lua(`return vim.api.nvim_win_get_config(${winLua})`, [])
  const lines = await lua('return vim.o.lines', [])
  const cols = await lua('return vim.o.columns', [])
  assert.equal(cfg.row, Math.max(0, Math.floor((lines - cfg.height) / 2) - 2), `${label}: popup vertically centered`)
  assert.equal(cfg.col, Math.max(0, Math.floor((cols - cfg.width) / 2)), `${label}: popup horizontally centered`)
}
const assertModeN = async (label: string) => {
  for (let i = 0; i < 40; i++) {
    if ((await nvim.request('nvim_get_mode', [])).mode === 'n') return
    await new Promise((r) => setTimeout(r, 25))
  }
  assert.fail(label + ': mode stayed out of normal')
}

try {
  // 1. channel id + Lua attach
  const channelId = await nvim.channelId
  log('channelId:', channelId)

  await lua('require("dsh_tui").attach(...)', [channelId])
  assert.equal(await lua('return require("dsh_tui").channel()', []), channelId)

  // VimEnter may not have fired yet (start() mounts the UI there) — poll.
  let ids!: { inputBuf?: number; chatWin?: number; inputWin?: number; reasoningOpen?: boolean; sessionsBuf?: number }
  for (let i = 0; i < 50; i++) {
    ids = await lua('return require("dsh_tui").ids()', [])
    if (Number.isInteger(ids?.inputBuf) && Number.isInteger(ids?.chatWin)) break
    await new Promise((r) => setTimeout(r, 100))
  }
  log('ids:', JSON.stringify(ids))
  assert.ok(Number.isInteger(ids.inputBuf) && Number.isInteger(ids.chatWin))
  assert.equal(ids.sessionsBuf, undefined, 'no resident sessions window anymore')

  // 1b. startup-buffer cooperation (issue #4): user VimEnter callbacks that
  // read the startup buffer (nvim-tree auto-open template) must see it VALID
  // inside the batch — takeover() defers the wipe until after the batch.
  assert.equal(await lua('return vim.g.smokeStartupBufValid', []), true,
    'startup buffer stays valid during other VimEnter callbacks (no mid-batch E5111)')
  // …and the scratch buffer IS wiped right after the batch (no leak).
  const scratchPath = path.join(path.dirname(sockPath), 'scratch')
  let scratchGone = false
  for (let i = 0; i < 30; i++) {
    if ((await lua('return vim.fn.bufexists(...)', [scratchPath])) === 0) {
      scratchGone = true
      break
    }
    await new Promise((r) => setTimeout(r, 50))
  }
  assert.ok(scratchGone, 'startup scratch buffer wiped after the VimEnter batch')

  // 2. multi-session: two chat buffers, /sessions float with FULL ids,
  // active switching.
  const chatA = await lua('return require("dsh_tui").ensure_chat(...)', ['session-aaaa'])
  const chatB = await lua('return require("dsh_tui").ensure_chat(...)', ['session-bbbb'])
  assert.notEqual(chatA.chatBuf, chatB.chatBuf, 'per-session chat buffers')

  await lua('require("dsh_tui").show_session_list(...)', [[
    { id: 'session-aaaa', title: '会话甲', active: true, kind: 'live' },
    { id: 'session-bbbb', title: '会话乙', active: false, kind: 'live' },
    { id: 'session-hist', title: '旧会话', active: false, kind: 'history' },
  ]])
  await assertModeN('session list opens in normal mode')
  let sessF = await lua('return require("dsh_tui")._sessBuf', [])
  const listLines = await nvim.request('nvim_buf_get_lines', [sessF, 0, -1, false])
  log('session list float:', JSON.stringify(listLines))
  assert.ok(listLines.some((l: string) => l.includes('会话甲') && l.includes('session-aaaa')), 'full session id shown')
  assert.ok(listLines.some((l: string) => l.includes('旧会话') && l.includes('session-hist') && l.includes('历史')), 'history kind shown')
  assert.equal(await lua('return vim.api.nvim_win_get_height(require("dsh_tui")._sessWin)', []), listLines.length, 'session window exactly fits content')
  await assertFooter('[Enter]', 'session list')
  await assertCentered('require("dsh_tui")._sessWin', 'session list')
  await lua('require("dsh_tui").close_session_list()', [])
  assert.equal(await lua('return require("dsh_tui")._sessWin', []), null, 'session list closed')
  assert.equal((await lua('return require("dsh_tui")._footer.win', [])) ?? null, null, 'footer closes with the session list')

  // active session's buffer shown in the chat window
  await lua('require("dsh_tui").set_active(...)', ['session-bbbb'])
  assert.equal(await lua('return vim.api.nvim_win_get_buf(...)', [ids.chatWin]), chatB.chatBuf)

  // 3. chat buffer must not be undoable
  assert.equal(await nvim.request('nvim_buf_get_option', [chatA.chatBuf, 'undolevels']), -1)
  // tabline hygiene: hidden unless multiple tabs; chat buffers carry names.
  assert.equal(await lua('return vim.o.showtabline', []), 0, 'tabline always hidden in the TUI')
  assert.equal(await lua('return vim.o.laststatus', []), 2, 'statuslines stay on (chat stats + input hints)')
  assert.equal(await lua('return vim.o.titlestring', []), 'dsh', 'terminal title pinned to dsh from the first frame (no scratch/[No Name] flash)')
  // Mouse hygiene: the TUI is keyboard-first — no mouse means no focus-drag
  // of the insert state into popups.
  assert.equal(await lua('return vim.o.mouse', []), '', 'mouse disabled in the TUI (insert state cannot be dragged by clicks)')
  await lua('vim.o.mouse = "a"', [])
  await new Promise((r) => setTimeout(r, 80))
  assert.equal(await lua('return vim.o.mouse', []), '', 'mouse re-enabling is neutralized (lazy plugins cannot flip it back)')

  // 3c. window ownership: a plugin (nvim-tree select / :edit) opening a file
  // into the chat or input window gets the buffer RELOCATED into a new tab
  // (focus follows) and the TUI window is restored — plugins stay isolated.
  const fileBuf = await lua(`local b = vim.api.nvim_create_buf(true, false)
    vim.api.nvim_buf_set_lines(b, 0, -1, false, { 'line1', 'line2' })
    return b`, [])
  const tabsBefore = await lua('return vim.fn.tabpagenr("$")', [])
  await lua('vim.api.nvim_win_set_buf(require("dsh_tui").ids().inputWin, ...)', [fileBuf])
  await new Promise((r) => setTimeout(r, 300))
  const afterInput = await lua(`return {
    tabs = vim.fn.tabpagenr('$'),
    curTabBuf = vim.api.nvim_win_get_buf(0),
    inputBuf = vim.api.nvim_win_get_buf(require("dsh_tui").ids().inputWin),
  }`, [])
  assert.equal(afterInput.tabs, tabsBefore + 1, 'input hijack opens a new tab for the file')
  assert.equal(afterInput.curTabBuf, fileBuf, 'focus follows the file into the new tab')
  assert.equal(afterInput.inputBuf, ids.inputBuf, 'input window restored to the input buffer')
  await lua('vim.cmd("tabclose")', [])
  await new Promise((r) => setTimeout(r, 200))
  await lua('vim.api.nvim_win_set_buf(require("dsh_tui").ids().chatWin, ...)', [fileBuf])
  await new Promise((r) => setTimeout(r, 300))
  const afterChat = await lua(`return {
    tabs = vim.fn.tabpagenr('$'),
    curTabBuf = vim.api.nvim_win_get_buf(0),
    chatBuf = vim.api.nvim_win_get_buf(require("dsh_tui").ids().chatWin),
  }`, [])
  assert.equal(afterChat.tabs, tabsBefore + 1, 'chat hijack opens a new tab for the file')
  assert.equal(afterChat.curTabBuf, fileBuf, 'focus follows the file into the new tab (chat case)')
  assert.equal(afterChat.chatBuf, await lua('return require("dsh_tui").ids().chatBuf', []),
    'chat window restored to the active chat buffer')
  await lua('vim.cmd("tabclose")', [])
  await new Promise((r) => setTimeout(r, 200))
  // 3d. input self-heal: a wiped submit keymap is re-asserted on WinEnter.
  await lua('vim.api.nvim_buf_del_keymap(require("dsh_tui").ids().inputBuf, "i", "<CR>")', [])
  await lua('vim.api.nvim_set_current_win(require("dsh_tui").ids().chatWin)', [])
  await lua('vim.api.nvim_set_current_win(require("dsh_tui").ids().inputWin)', [])
  await new Promise((r) => setTimeout(r, 200))
  const crMap = await lua(`for _, m in ipairs(vim.api.nvim_buf_get_keymap(require("dsh_tui").ids().inputBuf, "i")) do
    if m.lhs == '<CR>' then return true end end
    return false`, [])
  assert.equal(crMap, true, 'input submit keymap self-heals on WinEnter')
  // 3e. input IDENTITY takeover: `:edit file` while the input is empty
  // renames the input buffer IN PLACE and loads the file into it (the id
  // never changes) — the guard must restore the input surface and open the
  // file in a fresh tab.
  const editTarget = path.join(process.cwd(), 'package.json')
  await lua('vim.api.nvim_set_current_win(require("dsh_tui").ids().inputWin)', [])
  await lua(`local b = require("dsh_tui").ids().inputBuf
    vim.api.nvim_buf_set_lines(b, 0, -1, false, { '' })
    vim.bo[b].modified = false`, [])
  await lua('vim.cmd("edit " .. vim.fn.fnameescape(...))', [editTarget])
  await new Promise((r) => setTimeout(r, 400))
  const afterTake = await lua(`local ids = require('dsh_tui').ids()
    return {
      tabs = vim.fn.tabpagenr('$'),
      curName = vim.api.nvim_buf_get_name(vim.api.nvim_get_current_buf()),
      inputName = vim.api.nvim_buf_get_name(ids.inputBuf),
      inputType = vim.bo[ids.inputBuf].buftype,
      winBuf = vim.api.nvim_win_get_buf(ids.inputWin),
    }`, [])
  assert.equal(afterTake.tabs, tabsBefore + 1, ':edit takeover opens the file in a new tab')
  assert.ok(afterTake.inputName === '' && afterTake.inputType === 'nofile',
    'input buffer identity restored after the takeover')
  assert.equal(afterTake.winBuf, ids.inputBuf, 'input window shows the restored input buffer')
  assert.ok(String(afterTake.curName).includes('package.json'), 'focus follows the file into the new tab')
  await lua('vim.cmd("tabclose")', [])
  await new Promise((r) => setTimeout(r, 200))
  // OptionSet guard: even a plugin forcing showtabline=2 gets snapped back.
  await lua('vim.o.showtabline = 2', [])
  assert.equal(await lua('return vim.o.showtabline', []), 0, 'showtabline changes are neutralized instantly (no flash)')
  assert.ok(String(await lua('return vim.api.nvim_buf_get_name(...)', [chatA.chatBuf])).endsWith('dsh-chat-session-aaaa'), 'chat buffer named (no [No Name] tab)')

  // 4. FeedRenderer transcript → chat buffer; inactive feed must not move cursor
  let active = 'session-aaaa'
  const feedA = new FeedRenderer(nvim, chatA.chatBuf, chatA.chatWin, {
    activeChecker: () => active === 'session-aaaa',
  })
  const reasonB = await lua('return require("dsh_tui").ensure_reasoning(...)', ['session-bbbb'])
  const feedB = new FeedRenderer(nvim, chatB.chatBuf, chatB.chatWin, {
    activeChecker: () => active === 'session-bbbb',
    reasoningBuf: reasonB.reasoningBuf,
    reasoningView: () => ({ open: false, win: null }),
  })
  feedA.appendNotice('connected')
  feedA.applyEvent({ type: 'user/message', data: { content: [{ type: 'text', text: '你好' }] } })
  feedA.applyEvent({ type: 'turn/start', data: {} })
  feedA.applyEvent({ type: 'assistant/chunk', data: { chunk: { type: 'text-delta', text: 'Hello from ' } } })
  feedA.applyEvent({ type: 'assistant/chunk', data: { chunk: { type: 'text-delta', text: 'nvim' } } })
  feedA.applyEvent({ type: 'assistant/message', data: { turn: 1, step: 1, message: { content: [{ type: 'text', text: 'Hello from nvim (full) with **bold** and `code`' }] } } })
  feedA.applyEvent({ type: 'tool/call', time: 1000, data: { turn: 1, step: 1, callId: 'call-1', name: 'bash', arguments: '{"cmd":"ls"}' } })
  feedA.applyEvent({ type: 'tool/result', time: 1234, data: { turn: 1, step: 1, message: { content: [{ type: 'text', text: 'README.md' }], source: { callId: 'call-1' } } } })
  feedA.applyEvent({ type: 'tool/call', time: 2000, data: { turn: 1, step: 1, callId: 'call-2', name: 'web_search', arguments: '{"q":"x"}' } })
  feedA.applyEvent({ type: 'tool/result', time: 2999, data: { turn: 1, step: 1, message: { content: [{ type: 'text', text: 'boom' }], source: { callId: 'call-2' } }, error: { name: 'TimeoutError', code: 'TIMEOUT' } } })
  feedA.subagentStart({ runId: 'r1', provider: 'deepseek-code', id: 'uuid-child-1' })
  feedA.subagentEnd({ runId: 'r1', provider: 'deepseek-code', id: 'uuid-child-1', stopReason: 'completed' })
  feedA.workflowStart({ id: 'wf-1', meta: { name: '审计' } })
  feedA.workflowPhase({ id: 'wf-1', meta: {} }, '阶段一')
  feedA.workflowEnd({ id: 'wf-1', meta: {} }, { stopReason: 'completed' })
  feedA.applyEvent({ type: 'tool/ptc-dispatch-start', time: 3200, data: { rootCallId: 'rc-1', parentCallId: 'rc-1', subCallId: 'rc-1:ptc:1', name: 'read', arguments: { file_path: 'a.md' } } })
  feedA.applyEvent({ type: 'tool/ptc-dispatch', time: 3300, data: { rootCallId: 'rc-1', parentCallId: 'rc-1', subCallId: 'rc-1:ptc:1', name: 'read', arguments: { file_path: 'a.md' }, isError: false, content: [{ type: 'text', text: 'file body' }] } })
  feedA.applyEvent({ type: 'image/offload', data: { targets: [{ seq: 1, imageIndexes: [0, 1] }] } })
  feedB.appendNotice('b-notice')
  await new Promise((r) => setTimeout(r, 150)) // let the 40ms throttle flush

  // 3b. running subagents: ONE compact activity line in the thinking slot
  // (same transient logic — never committed), cleared when the run ends.
  feedA.subagentStart({ runId: 'run-x', provider: 'deepseek-code', id: 'uuid-x' })
  await new Promise((r) => setTimeout(r, 150))
  let subLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  assert.ok(subLines.some((l: string) => /^◇ deepseek-code · \d+\.\d+s$/.test(l)),
    'subagent activity line renders in the thinking slot')
  assert.ok(subLines.some((l: string) => l.includes('↳ 🔧 read(')), 'PTC sub-call start renders a nested tool line')
  assert.ok(subLines.some((l: string) => l.includes('↳ ✓ read')), 'PTC sub-call result renders a nested result line')
  assert.ok(subLines.some((l: string) => l.includes('已省略 2 张图片')), 'image offload renders a notice')
  feedA.subagentEnd({ runId: 'run-x', provider: 'deepseek-code', id: 'uuid-x', stopReason: 'completed' })
  await new Promise((r) => setTimeout(r, 150))
  subLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  assert.ok(!subLines.some((l: string) => /^◇ deepseek-code · \d+\.\d+s$/.test(l)),
    'subagent activity line vanishes after the run ends (start/end cards stay)')

  const linesA = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  log('chat A lines:', JSON.stringify(linesA))
  assert.ok(linesA.includes('> 你好'), 'user message rendered')
  assert.ok(linesA.some((l: string) => l.includes('Hello from nvim (full) with bold and code')), 'markup stripped in buffer')
  // Chat output is display-only: edit keys are Nop'd (i must not enter
  // insert mode, x/dd/J must not delete or join rows) — the renderer still
  // writes through the API.
  const chatKeys = await lua(`local out = {}
    for _, m in ipairs(vim.api.nvim_buf_get_keymap(${chatA.chatBuf}, "n")) do
      table.insert(out, { lhs = m.lhs, rhs = m.rhs or "" })
    end
    return out`, [])
  const chatKey = (k: string) => chatKeys.find((m: any) => m.lhs === k)
  assert.ok(chatKey('i') && chatKey('i').rhs !== 'i', 'chat i is Nop (no insert mode)')
  assert.ok(chatKey('d') && chatKey('x') && chatKey('J'), 'chat edit/join keys Nop')
  const chatLinesBefore = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  await lua('vim.api.nvim_set_current_win(...)', [ids.chatWin])
  await nvim.input('<Esc>') // hand over from the input window's insert mode
  assert.equal((await nvim.request('nvim_get_mode', [])).mode, 'n', 'chat window starts in normal mode')
  await nvim.input('i')
  assert.equal((await nvim.request('nvim_get_mode', [])).mode, 'n', 'chat buffer never enters insert mode')
  await nvim.input('xddJ~')
  assert.deepEqual(await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false]), chatLinesBefore, 'chat content cannot be deleted/joined')
  assert.ok(linesA.some((l: string) => l.startsWith('🔧 bash({"cmd":"ls"})')), 'tool/call card')
  assert.ok(linesA.some((l: string) => l.startsWith('✓ bash · 234ms')), 'tool/result card with elapsed')
  assert.ok(linesA.some((l: string) => l.startsWith('✗ web_search') && l.includes('TIMEOUT')), 'failed tool card')
  assert.ok(linesA.some((l: string) => l.includes('◇ subagent deepseek-code')), 'subagent start card')
  assert.ok(linesA.some((l: string) => l.includes('◇ subagent deepseek-code · completed')), 'subagent end card')

  // 3c. Todo pinned panel: EVERY todo/write updates in place mid-turn —
  // regression guard for "全部完成才一次性更新" (batch-at-the-end).
  feedA.applyEvent({ type: 'turn/start', data: { turn: 9 } })
  feedA.applyEvent({ type: 'assistant/chunk', data: { chunk: { type: 'text-delta', text: 'streaming…' } } })
  feedA.applyEvent({ type: 'todo/write', data: { todos: [
    { content: '任务一', status: 'pending' },
    { content: '任务二', status: 'pending' },
    { content: '任务三', status: 'pending' },
  ] } })
  await new Promise((r) => setTimeout(r, 150))
  let todoLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  assert.ok(todoLines.some((l: string) => l.includes('📋 待办 3 项 · 0 完成 · 0 进行中 · 3 待办')), 'todo panel pins with the initial list')
  assert.ok(todoLines.some((l: string) => l.includes('· 任务一')), 'pending mark renders per item')
  feedA.applyEvent({ type: 'todo/write', data: { todos: [
    { content: '任务一', status: 'completed' },
    { content: '任务二', status: 'in_progress' },
    { content: '任务三', status: 'pending' },
  ] } })
  await new Promise((r) => setTimeout(r, 150))
  todoLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  assert.ok(todoLines.some((l: string) => l.includes('📋 待办 3 项 · 1 完成 · 1 进行中 · 1 待办')), 'intermediate write updates the panel in place')
  assert.ok(todoLines.some((l: string) => l.includes('✓ 任务一')), 'completed mark renders immediately')
  assert.ok(todoLines.some((l: string) => l.includes('… 任务二')), 'in-progress mark renders immediately')
  feedA.applyEvent({ type: 'todo/write', data: { todos: [
    { content: '任务一', status: 'completed' },
    { content: '任务二', status: 'completed' },
    { content: '任务三', status: 'completed' },
  ] } })
  await new Promise((r) => setTimeout(r, 150))
  todoLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  assert.ok(todoLines.some((l: string) => l.includes('📋 待办 3 项 · 3 完成 · 0 进行中 · 0 待办')), 'all-done board commits into the transcript')
  // 落盘之后「钉住槽清空」+「徽标清零」必须同时发生：面板与徽标共用同一份
  // 「已落盘过滤」视图，若只清其一，用户会看到清单结束了但徽标仍停在 3✓。
  {
    const visAfterCommit = feedA.todoVisibleItems([
      { content: '任务一', status: 'completed' },
      { content: '任务二', status: 'completed' },
      { content: '任务三', status: 'completed' },
    ])
    assert.equal(visAfterCommit.length, 0, 'committed items leave the visible set (badge + panel both key off it)')
    // 重新打开某一项时要能再次出现（re-plan 场景），否则徽标会永久消失。
    // 注意只断言「该项回来了」：同批里已落盘的其他项本就该继续隐藏。
    const reopened = feedA.todoVisibleItems([
      { content: '任务一', status: 'in_progress' },
      { content: '任务二', status: 'completed' },
    ])
    assert.deepEqual(reopened.map((t) => t.content), ['任务一'], 'a reopened item becomes visible again while committed siblings stay hidden')
  }
  feedA.applyEvent({ type: 'turn/end', data: {} })
  assert.ok(linesA.some((l: string) => l.includes('◈ workflow 审计')), 'workflow start card')
  assert.ok(linesA.some((l: string) => l.includes('◈ ─ 阶段一')), 'workflow phase card')

  // extmark spans: bold + code groups present
  const marks = await nvim.request('nvim_buf_get_extmarks', [chatA.chatBuf, -1, 0, -1, { details: true }])
  const groups = new Set(marks.map((m: any) => m[3]?.hl_group))
  assert.ok(groups.has('DshTuiBold'), 'bold span highlighted')
  assert.ok(groups.has('DshTuiCode'), 'code span highlighted')
  assert.ok(groups.has('DshTuiTool'), 'tool role highlighted')
  assert.ok(groups.has('DshTuiAssistant'), 'assistant output dimmed (own group)')
  // Row groups must be EXPLICIT same-row ranges (end_col = byte length) —
  // nvim 0.12's real TUI does not draw hl_eol marks, which rendered every
  // chat line plain white in production.
  const rowGroupMarks = marks.filter((m: any) => m[3]?.hl_group === 'DshTuiAssistant')
  assert.ok(rowGroupMarks.length > 0, 'assistant row-group marks exist')
  const chatLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  for (const m of rowGroupMarks) {
    assert.equal(m[3]?.hl_eol, false, 'row groups are not hl_eol marks')
    if ((chatLines[m[1]] ?? '').length > 0) {
      assert.ok(m[3]?.end_col > 0, 'row groups carry an explicit end_col (non-empty line)')
    }
  }
  const linesB = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.deepEqual(linesB, ['· b-notice'], 'inactive session got its own feed')

  // history replay skips agent/status chatter
  feedA.applyEvent({ type: 'agent/status', data: { status: 'working' } }, { history: true })
  // finish-error chunks must surface (turn died → user must see why)
  feedA.applyEvent({ type: 'assistant/chunk', data: { turn: 2, step: 1, chunk: { type: 'finish', reason: { kind: 'error', failure: { message: 'no API key' } } } } })
  await new Promise((r) => setTimeout(r, 100))
  const linesA2 = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  log('chat A lines after finish:', JSON.stringify(linesA2))
  assert.ok(!linesA2.some((l: string) => l.includes('agent working')), 'history replay skips status')
  assert.ok(linesA2.some((l: string) => l.includes('no API key')), 'finish-error chunk rendered')

  // 3c. bottom-pinned indicator: while a subagent runs AND the main answer
  // streams, the ◇ activity line stays the LAST buffer row — content streams
  // ABOVE it, never pushing the indicator into the middle of the chat window.
  feedA.applyEvent({ type: 'turn/start', time: 4000, data: {} })
  feedA.subagentStart({ runId: 'run-y', provider: 'deepseek-code', id: 'uuid-y' })
  feedA.applyEvent({ type: 'assistant/chunk', time: 4100, data: { chunk: { type: 'text-delta', text: '主线一\n主线二\n主线三' } } })
  await new Promise((r) => setTimeout(r, 250))
  let pinnedLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  const actIdx = pinnedLines.findIndex((l: string) => /^◇ deepseek-code · \d+\.\d+s$/.test(l))
  assert.ok(actIdx >= 0, 'subagent indicator present while the main answer streams')
  assert.equal(actIdx, pinnedLines.length - 1, 'subagent indicator pinned at the bottom of the chat view')
  feedA.subagentEnd({ runId: 'run-y', provider: 'deepseek-code', id: 'uuid-y', stopReason: 'completed' })
  feedA.applyEvent({ type: 'assistant/message', time: 4200, data: { message: { content: [{ type: 'text', text: '主线一\n主线二\n主线三' }] } } })
  feedA.applyEvent({ type: 'turn/end', time: 4300, data: {} })
  await new Promise((r) => setTimeout(r, 250))
  pinnedLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  assert.ok(!pinnedLines.some((l: string) => /^◇ deepseek-code · \d+\.\d+s$/.test(l)),
    'indicator gone after the run ends')

  // 4b. official-client parity rendering (batch 1): todo strip, compaction
  // checkpoint, retry rows, workflow-in-transcript, structured tool results.
  feedA.applyEvent({ type: 'todo/write', time: 1500, data: { todos: [
    { content: '设计 API', status: 'completed' },
    { content: '实现渲染', status: 'in_progress' },
    { content: '写测试', status: 'pending' },
  ] } })
  feedA.applyEvent({ type: 'compaction/start', time: 1600, data: { compactionId: 'c1' } })
  feedA.applyEvent({ type: 'compaction/summary', time: 1650, data: { compactionId: 'c1', shadowedSeqs: [1, 2, 3], shadowedTokenCount: 12000, summary: '前半段是环境搭建' } })
  // dsh 0.1.1-rc.2 shape: summary is ContentBlock[] (regression: the old
  // renderer called .split on it and crashed).
  feedA.applyEvent({ type: 'compaction/summary', time: 1660, data: { compactionId: 'c1b', shadowedSeqs: [4, 5], shadowedTokenCount: 3000, summary: [{ type: 'text', text: '第二段压缩摘要' }] } })
  feedA.applyEvent({ type: 'llm/retry', time: 1700, data: { retryId: 'r1', retry: 2, maxRetries: 5, mode: 'normal', delayMs: 3000, failure: { message: '429 rate limited' } } })
  feedA.applyEvent({ type: 'llm/retry-started', time: 1730, data: { retryId: 'r1', retry: 2 } })
  feedA.applyEvent({ type: 'tool-workflow/run-start', time: 1800, data: { runId: 'wf-9', name: '审计' } })
  feedA.applyEvent({ type: 'tool-workflow/agent-start', time: 1810, data: { runId: 'wf-9', seq: 1, label: 'audit-a', phase: '扫描' } })
  feedA.applyEvent({ type: 'tool-workflow/agent-end', time: 1820, data: { runId: 'wf-9', seq: 1, outcome: 'completed' } })
  feedA.applyEvent({ type: 'tool-workflow/run-end', time: 1830, data: { runId: 'wf-9', stopReason: 'completed' } })
  feedA.applyEvent({ type: 'tool/call', time: 1900, data: { callId: 'c-9', name: 'web_search', arguments: '{"query":"dsh"}' } })
  feedA.applyEvent({ type: 'tool/result', time: 1950, data: { message: { content: [{ type: 'text', text: JSON.stringify([{ title: 'dsh 官网', url: 'https://example.com', snippet: 'DeepSeek Harness' }]) }], source: { callId: 'c-9' } } } })
  await new Promise((r) => setTimeout(r, 150))
  const linesA3 = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  log('parity batch1:', JSON.stringify(linesA3.slice(-16)))
  assert.ok(linesA3.includes('📋 待办 3 项 · 1 完成 · 1 进行中 · 1 待办'), 'todo strip header')
  assert.ok(linesA3.includes('  ✓ 设计 API') && linesA3.includes('  … 实现渲染') && linesA3.includes('  · 写测试'), 'todo items with status marks')
  assert.ok(linesA3.some((l: string) => l.includes('⋯ 上下文压缩 · 3 条历史 · ≈12.0k tokens')), 'compaction checkpoint row')
  assert.ok(linesA3.includes('    前半段是环境搭建'), 'compaction summary folded')
  assert.ok(linesA3.includes('    第二段压缩摘要'), 'compaction ContentBlock[] summary folded (0.1.1-rc.2 shape)')
  assert.ok(linesA3.some((l: string) => l.includes('↻ 重试 #2/5') && l.includes('3s 后重试') && l.includes('429 rate limited')), 'retry status row')
  assert.ok(linesA3.includes('↻ 重试 #2 已发起'), 'retry started row')
  assert.ok(linesA3.some((l: string) => l.startsWith('◈ workflow 审计')), 'workflow run row in transcript')
  assert.ok(linesA3.includes('  ◇ #1 audit-a · 扫描') && linesA3.includes('  ◇ #1 · completed'), 'workflow member rows')
  assert.ok(linesA3.includes('  · dsh 官网 · https://example.com · DeepSeek Harness'), 'structured tool result itemized')

  // 4c. i18n: en dictionary switches user-facing strings; unknown keys fall
  // back to the zh literal.
  setLocale('en')
  assert.equal(t('无活跃会话'), 'no active session', 'core notice translated to en')
  assert.equal(t('📋 待办'), '📋 Todo', 'todo label translated')
  assert.equal(t('未被收录的字符串'), '未被收录的字符串', 'unknown key falls back to zh literal')
  setLocale('zh')
  assert.equal(t('无活跃会话'), '无活跃会话', 'zh locale returns the literal')
  assert.equal(locale(), 'zh', 'locale() reports the current locale')

  // 4d. market data layer (pure helpers, offline fixtures).
  const yamlA = `url: https://github.com/A/b-plugin
name: A/b-plugin
category: ui
description:
  en: Rotates status labels.
  zh: 轮换状态标签。
tarball: https://github.com/A/b-plugin/releases/latest/download/b.tgz`
  const yamlB = `url: https://github.com/C/d-plugin
name: C/d-plugin
category: memory
description:
  zh: "项目记忆插件。"
  en: "Project memory plugin."`
  const pA = parsePluginYaml(yamlA, 'A__b-plugin.yml')
  assert.equal(pA.name, 'A/b-plugin', 'yaml name normalized')
  assert.equal(pA.category, 'ui', 'yaml category')
  assert.equal(pA.descZh, '轮换状态标签。', 'yaml zh description')
  assert.equal(pA.descEn, 'Rotates status labels.', 'yaml en description')
  assert.equal(pA.tarball, 'https://github.com/A/b-plugin/releases/latest/download/b.tgz', 'yaml tarball kept')
  const pB = parsePluginYaml(yamlB, 'C__d-plugin.yml')
  assert.equal(pB.descZh, '项目记忆插件。', 'quoted zh description unquoted')
  const stars = parseStars(JSON.stringify({
    'https://github.com/A/b-plugin': { stars: 42, checkedAt: '2026-08-19' },
    'https://github.com/B/c-plugin': { stars: 7, checkedAt: '2026-08-19' },
  }))
  assert.equal(stars.get('https://github.com/A/b-plugin'), 42, 'stars parsed')
  const cat = buildCatalog(stars, [pA, pB, { name: 'B/c-plugin', url: 'https://github.com/B/c-plugin' }])
  assert.equal(cat[0]?.name, 'A/b-plugin', 'sorted by stars desc first')
  assert.equal(cat[0]?.stars, 42, 'top entry carries stars')
  assert.ok(cat.some((e) => e.name === 'C/d-plugin' && e.stars === 0), 'yaml-only entry joins at 0 stars')
  assert.deepEqual(searchCatalog(cat, 'rotates').map((e) => e.name), ['A/b-plugin'], 'en description search')
  assert.deepEqual(searchCatalog(cat, '记忆').map((e) => e.name), ['C/d-plugin'], 'zh description search')
  assert.deepEqual(searchCatalog(cat, 'MEMORY').map((e) => e.name), ['C/d-plugin'], 'category search case-insensitive')
  // phase-2 helpers: hot-toggle patch rows, npm-name detection, dep matching
  let patch = '- id: keep-me\n  config: { a: 1 }\n'
  patch = setDisabledRows(patch, [{ id: 'keep-me', disabled: true }])
  assert.ok(patch.includes('- id: keep-me\n  config: { a: 1 }\n  disabled: true'), 'toggle row appended WITH its config preserved (disable must not destroy credentials)')
  assert.ok(patch.includes('config: { a: 1 }'), 'the row body (config) survives the disable toggle')
  assert.deepEqual([...readDisabledIds(patch)], ['keep-me'], 'disabled ids parsed')
  patch = setDisabledRows(patch, [{ id: 'keep-me', disabled: false }])
  assert.ok(patch.includes('disabled: false'), 'enable row written')
  assert.deepEqual([...readDisabledIds(patch)], [], 'enabled id leaves the disabled set')
  assert.ok(!patch.includes('disabled: true'), 'stale disable row removed idempotently')
  assert.equal(isNpmName('dsh-market'), true, 'plain npm name detected')
  assert.equal(isNpmName('@scope/pkg'), true, 'scoped npm name detected')
  assert.equal(isNpmName('link:./x'), false, 'link spec rejected')
  assert.equal(isNpmName('https://github.com/a/b'), false, 'url spec rejected')
  assert.equal(depMatchesEntry('dshmarket', { name: 'dsh-market/dsh-market', url: 'https://github.com/dsh-market/dsh-market', stars: 1, category: 'm', descZh: '', descEn: '' }), false, 'no false positive by suffix alone')
  assert.equal(depMatchesEntry('https://github.com/dsh-market/dsh-market', { name: 'dsh-market/dsh-market', url: 'https://github.com/dsh-market/dsh-market', stars: 1, category: 'm', descZh: '', descEn: '' }), true, 'url spec matches entry')
  const treeEntry = { name: 'volcengine/OpenViking', url: 'https://github.com/volcengine/OpenViking/tree/main/examples/dsh-memory-plugin', stars: 1, category: 'm', descZh: '', descEn: '', tarball: 'https://github.com/volcengine/OpenViking/releases/latest/download/x.tgz' }
  assert.equal(repoRoot(treeEntry.url), 'https://github.com/volcengine/OpenViking', 'tree subpath stripped to repo root')
  assert.equal(depMatchesEntry('https://github.com/volcengine/OpenViking', treeEntry), true, 'repo-root dep matches tree-path entry')
  assert.equal(installSpec(treeEntry), treeEntry.tarball, 'tarball wins as the install spec')
  assert.equal(installSpec({ ...treeEntry, tarball: undefined as string | undefined }), 'https://github.com/volcengine/OpenViking', 'repo root used when no tarball')
  // phase-3: failure classification drives the automatic remedy chains
  assert.equal(classifyPnpmError('ERR_PNPM_FETCH_404 GET https://registry.npmjs.org/x: 404 Not Found').kind, 'notfound', '404 classified as notfound')
  assert.equal(classifyPnpmError('ERR_PNPM_NO_MATCHING_VERSION No matching version found for x@9.9.9').kind, 'notfound', 'no-matching-version classified as notfound')
  assert.equal(classifyPnpmError('ERR_PNPM_OUTDATED_LOCKFILE Cannot install with "frozen-lockfile" because pnpm-lock.yaml is not up to date').kind, 'lockfile', 'outdated lockfile classified')
  assert.equal(classifyPnpmError(' ERR_PNPM_FETCH_501  GET https://registry.npmjs.org/x: ETIMEDOUT').kind, 'network', 'timeout classified as network')
  assert.equal(classifyPnpmError('ERR_PNPM_FETCH_501 EAI_AGAIN registry.npmjs.org').kind, 'network', 'dns failure classified as network')
  assert.equal(classifyPnpmError('EPERM: operation not permitted, unlink /root/.npm/_cacache').kind, 'cache', 'EPERM on cache classified as cache')
  assert.equal(classifyPnpmError('EINTEGRITY: sha512 integrity check failed for x').kind, 'cache', 'integrity failure classified as cache')
  assert.equal(classifyPnpmError('ERROR: Repository not found. fatal: could not read from remote repository.').kind, 'git', 'missing repo classified as git')
  assert.equal(classifyPnpmError('git@github.com: Permission denied (publickey).').kind, 'git', 'git auth failure classified')
  assert.equal(classifyPnpmError('some totally weird output').kind, 'other', 'unknown output classified as other')
  assert.equal(firstErrorLine('\n\n  ERR something \nnext\n'), 'ERR something', 'first non-empty line extracted')
  assert.ok(profileDir('nvim-tui').endsWith('/profiles/nvim-tui'), 'profileDir resolves under DSH_HOME/.dsh')
  // phase-4: natural-language command router
  assert.deepEqual(matchIntent('会话列表'), { name: 'sessions', arg: undefined }, 'exact zh alias routes')
  assert.deepEqual(matchIntent('添加任务 写单元测试'), { name: 'todo', arg: '写单元测试' }, 'add-task phrasing routes to /todo')
  assert.equal(matchIntent('状态栏不见了'), null, 'sentence containing 状态栏 goes to the agent, not /status')
  assert.equal(matchIntent('状态栏'), null, 'bare 状态栏 is chat, not /status')
  assert.deepEqual(matchIntent('状态'), { name: 'status', arg: undefined }, 'exact 状态 still routes to /status')
  assert.deepEqual(matchIntent('会话状态'), { name: 'status', arg: undefined }, 'exact 会话状态 still routes')
  assert.deepEqual(matchIntent('打开帮助面板'), { name: 'help', arg: undefined }, 'noun-phrase routing unchanged')
  assert.deepEqual(matchIntent('关于主题'), { name: 'theme', loose: true }, 'ambiguous noun match flags loose for the agent')
  assert.deepEqual(matchIntent('主题'), { name: 'theme', arg: undefined }, 'exact phrase stays instant (no loose flag)')
  assert.deepEqual(matchIntent('切换主题 深色'), { name: 'theme', arg: '深色' }, 'pattern stays instant')
  assert.deepEqual(matchIntent('待办'), { name: 'todo', arg: undefined }, '待办 routes to /todo')
  assert.deepEqual(matchIntent('任务列表'), { name: 'tasks', arg: undefined }, '任务列表 still routes to /tasks (jobs)')
  assert.deepEqual(matchIntent('help'), { name: 'help', arg: undefined }, 'exact en alias routes')
  assert.deepEqual(matchIntent('切换模型 deepseek-chat'), { name: 'model', arg: 'deepseek-chat' }, 'model pattern captures arg')
  // 「用 <id>」曾误路由到 /model（'用 bash' 这类聊天句会持久化损坏默认
  // 模型）——该模式已删除，裸 id 必须回落聊天。
  assert.equal(matchIntent('用 deepseek-chat'), null, 'bare 用 + id no longer hijacks into /model')
  assert.equal(matchIntent('用中文回复我'), null, 'bare 用 + sentence is chat, not a model switch')
  assert.deepEqual(matchIntent('主题换成 vivid'), { name: 'theme', arg: 'vivid' }, 'theme alternation picks the longest prefix')
  assert.deepEqual(matchIntent('语言 英文'), { name: 'locale', arg: 'en' }, 'locale arg mapped')
  assert.deepEqual(matchIntent('中文'), { name: 'locale', arg: 'zh' }, 'bare 中文 switches language')
  assert.deepEqual(matchIntent('删除工作区 abc123'), { name: 'workspace', arg: 'delete abc123' }, 'workspace delete composed')
  assert.deepEqual(matchIntent('添加工作区'), { name: 'workspace', arg: undefined }, 'bare workspace add opens the popup')
  assert.deepEqual(matchIntent('记住 明天九点开会'), { name: 'remember', arg: '明天九点开会' }, 'remember arg captured')
  assert.deepEqual(matchIntent('状态栏显示 tokens'), { name: 'glance', arg: 'tokens' }, 'glance arg captured')
  assert.deepEqual(matchIntent('反馈 up 很好用'), { name: 'fb', arg: 'up 很好用' }, 'fb composed')
  assert.deepEqual(matchIntent('侧问 这个设计怎么样'), { name: 'btw', arg: '这个设计怎么样' }, 'btw arg captured')
  assert.equal(matchIntent('怎么清空会话？'), null, 'questions always go to the agent')
  assert.equal(matchIntent('> 会话列表'), null, '> forces chat')
  assert.equal(matchIntent('这是一条很长很长的普通消息，超过六十个字符就应该直接发给智能体而不是被识别成命令，因为自然语言命令匹配必须保持克制避免误拦截。'), null, 'long input stays chat')
  assert.equal(matchIntent('清屏')?.name, 'clear', 'destructive exact phrase works')
  // subagent thought-chain TTL helpers
  const NOW = 1_800_000_000_000
  assert.equal(ageLabel(NOW - 5_000, NOW), '刚刚', 'age under a minute')
  assert.equal(ageLabel(NOW - 300_000, NOW), '5m前', 'age in minutes')
  assert.equal(ageLabel(NOW - 7_200_000, NOW), '2h前', 'age in hours')
  assert.equal(ageLabel(NOW - 3 * 86_400_000, NOW), '3d前', 'age in days')
  assert.equal(ageLabel(undefined, NOW), '', 'unknown age renders empty')
  assert.equal(isExpired(NOW - 100 * 3600 * 1000, 72, NOW), true, 'older than TTL is expired')
  assert.equal(isExpired(NOW - 3600 * 1000, 72, NOW), false, 'younger than TTL survives')
  assert.equal(isExpired(undefined, 72, NOW), false, 'unknown createdAt never expires')
  assert.equal(isExpired(NOW - 999_999_999, 0, NOW), false, 'ttl 0 disables cleanup')
  assert.equal(matchIntent('帮我清屏')?.name, 'clear', 'lead-in stripping keeps the explicit destructive command')
  // conversational variants: verbs/nouns stripped across three match levels
  assert.equal(matchIntent('打开帮助面板')?.name, 'help', '打开帮助面板 → /help')
  assert.equal(matchIntent('查看会话列表')?.name, 'sessions', '查看会话列表 → /sessions')
  assert.equal(matchIntent('显示消息队列')?.name, 'queue', '显示消息队列 → /queue')
  assert.equal(matchIntent('打开插件市场')?.name, 'market', '打开插件市场 → /market')
  assert.equal(matchIntent('请打开设置')?.name, 'settings', '请打开设置 → /settings')
  assert.equal(matchIntent('帮我切换模型 deepseek-chat')?.arg, 'deepseek-chat', '帮我切换模型 x → /model x')
  assert.equal(matchIntent('切换到 deepseek-chat 模型')?.arg, 'deepseek-chat', '切换到 x 模型 → /model x')
  assert.equal(matchIntent('open help panel')?.name, 'help', 'english lead-in + noun stripped')
  assert.equal(matchIntent('我要看下我的记忆')?.name, 'memory', '我要看下我的记忆 → /memory')
  assert.equal(matchIntent('打开设置面板改主题')?.name, 'panel', 'noun-led sentence matches the panel intent (面板 keyword)')

  // 5. /clear empties the active feed
  active = 'session-bbbb'
  feedB.clear()
  await new Promise((r) => setTimeout(r, 100))
  const cleared = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.deepEqual(cleared, [''], 'clear() emptied the chat buffer')

  // 6. thinking visibility: reasoning stream renders dim, closes with elapsed,
  // and a silent turn shows a ticking placeholder.
  feedB.applyEvent({ type: 'turn/start', time: 5000, data: {} })
  feedB.applyEvent({ type: 'assistant/chunk', time: 5100, data: { chunk: { type: 'reasoning-delta', text: '让我想想' } } })
  feedB.applyEvent({ type: 'assistant/chunk', time: 5200, data: { chunk: { type: 'reasoning-delta', text: '再想想' } } })
  await new Promise((r) => setTimeout(r, 120))
  let linesB2 = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  log('chat during reasoning:', JSON.stringify(linesB2))
  assert.ok(linesB2.some((l: string) => /^·· thinking · \d+\.\d+s$/.test(l)), 'compact progress line in chat')
  assert.ok(!linesB2.includes('让我想想再想想'), 'reasoning text NOT in chat')
  let reasonLines = await nvim.request('nvim_buf_get_lines', [reasonB.reasoningBuf, 0, -1, false])
  log('reasoning panel:', JSON.stringify(reasonLines))
  assert.ok(reasonLines.includes('让我想想再想想'), 'reasoning stream in panel buffer')
  // A delta with an embedded newline grows the previous last row AND appends
  // a new one — the fast path must rewrite both correctly.
  feedB.applyEvent({ type: 'assistant/chunk', time: 5250, data: { chunk: { type: 'reasoning-delta', text: '\n第三行来了' } } })
  await new Promise((r) => setTimeout(r, 120))
  reasonLines = await nvim.request('nvim_buf_get_lines', [reasonB.reasoningBuf, 0, -1, false])
  log('reasoning panel (multi-line):', JSON.stringify(reasonLines))
  assert.ok(reasonLines.includes('让我想想再想想'), 'grown row kept in panel')
  assert.ok(reasonLines.includes('第三行来了'), 'new row appended in panel')
  // Every non-empty panel row must be FULLY covered by its dim group mark:
  // extmark end_cols are frozen once set, so an in-place rewrite that skips
  // the refresh leaves the freshly streamed tail unhighlighted — pure white
  // on the theme's Normal instead of the dim panel color.
  const reasonMarks = await nvim.request('nvim_buf_get_extmarks', [reasonB.reasoningBuf, -1, 0, -1, { details: true }])
  for (let i = 0; i < reasonLines.length; i++) {
    const line = reasonLines[i] ?? ''
    if (line.length === 0) continue
    const cover = reasonMarks.some((m: any) => m[1] === i && m[3]?.end_row === i &&
      m[3]?.end_col === Buffer.byteLength(line, 'utf8') && typeof m[3]?.hl_group === 'string')
    assert.ok(cover, `panel row ${i} fully highlighted (${JSON.stringify(line)})`)
  }
  // Markdown tables inside reasoning render as the bordered, aligned table
  // (the chat view's own beautifier): a GFM block in the stream tail expands
  // to box-drawing rows in the panel buffer.
  feedB.applyEvent({ type: 'assistant/chunk', time: 5260, data: { chunk: { type: 'reasoning-delta', text: '\n| 阶段 | 内容 |\n|---|---|\n| P1 | 方案 |' } } })
  await new Promise((r) => setTimeout(r, 120))
  reasonLines = await nvim.request('nvim_buf_get_lines', [reasonB.reasoningBuf, 0, -1, false])
  log('reasoning panel (markdown table):', JSON.stringify(reasonLines))
  assert.ok(reasonLines.some((l: string) => l.startsWith('┌──')), 'table top border in panel')
  assert.ok(reasonLines.some((l: string) => /^│ 阶段 │ 内容/.test(l)), 'table header row aligned')
  assert.ok(reasonLines.some((l: string) => /^│ P1\s+│ 方案/.test(l)), 'table body row aligned')
  assert.ok(!reasonLines.includes('|---|'), 'raw separator line replaced by borders')
  feedB.applyEvent({ type: 'assistant/chunk', time: 5300, data: { chunk: { type: 'text-delta', text: '答案是 42' } } })
  await new Promise((r) => setTimeout(r, 120))
  linesB2 = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.ok(!linesB2.some((l: string) => l.includes('·· thinking')), 'thinking line vanishes from chat after close')
  assert.ok(linesB2.includes('答案是 42'), 'answer follows the transient line')
  reasonLines = await nvim.request('nvim_buf_get_lines', [reasonB.reasoningBuf, 0, -1, false])
  assert.ok(reasonLines.some((l: string) => l.startsWith('── thinking end')), 'panel footer on close')

  // 6g. reasoning panel toggle guard + popup jumplist Nop: <C-o> works from
  // the TUI's own windows (chat/input), but inside any float a REAL keypress
  // must neither open the panel nor swap the popup into another buffer (the
  // float inherits the jumplist — a bare <C-o> used to jump the popup to the
  // input buffer: content gone, popup keys dead, second <C-o> opens the
  // panel via the input buffer's mapping).
  await lua('vim.api.nvim_set_current_win(require("dsh_tui").ids().chatWin)', [])
  await lua('require("dsh_tui").toggle_reasoning()', [])
  assert.equal(await lua('return require("dsh_tui")._reasoningOpen', []), true, 'toggle from the chat window opens the panel')
  await lua('require("dsh_tui").toggle_reasoning()', [])
  assert.equal(await lua('return require("dsh_tui")._reasoningOpen', []), false, 'toggle from the chat window closes the panel')
  // Inside a picker float (focused): inert, focus stays, float survives.
  await lua('require("dsh_tui").show_picker(...)', ['浮窗守卫', [{ label: '选项A', value: 'a' }]])
  await new Promise((r) => setTimeout(r, 100))
  const pickerWin = await lua('return require("dsh_tui")._float.win', [])
  assert.ok(Number.isInteger(pickerWin), 'picker float open with focus')
  await lua('vim.api.nvim_set_current_win(require("dsh_tui")._float.win)', [])
  await lua('require("dsh_tui").toggle_reasoning()', [])
  assert.equal(await lua('return require("dsh_tui")._reasoningOpen', []), false, 'toggle is a NO-OP inside a picker float')
  assert.equal(await lua('return vim.api.nvim_win_is_valid(require("dsh_tui")._float.win)', []), true, 'picker stays open (no focus steal)')
  assert.equal(await lua('return vim.api.nvim_get_current_win()', []), pickerWin, 'focus stays in the picker float')
  // REAL keypress: <C-o>/<C-i>/<C-^> must not swap the popup's buffer.
  const guardPickerBuf = await lua('return vim.api.nvim_win_get_buf(require("dsh_tui")._float.win)', [])
  await nvim.request('nvim_input', ['<C-o>'])
  await nvim.request('nvim_input', ['<C-i>'])
  await nvim.request('nvim_input', ['<C-^>'])
  await new Promise((r) => setTimeout(r, 150))
  assert.equal(await lua('return vim.api.nvim_win_get_buf(require("dsh_tui")._float.win)', []), guardPickerBuf, 'jumplist keys cannot swap the popup buffer')
  assert.equal(await lua('return require("dsh_tui")._reasoningOpen', []), false, 'real <C-o> keypress does not open the panel in a popup')
  assert.equal(await lua('return vim.api.nvim_get_current_win()', []), pickerWin, 'focus still in the popup after the keypresses')
  const guardPickerLines = await nvim.request('nvim_buf_get_lines', [guardPickerBuf, 0, -1, false])
  assert.ok(guardPickerLines.some((l: string) => l.includes('选项A')), 'popup content intact after jumplist keys')
  await lua('require("dsh_tui").picker_cancel()', [])
  await new Promise((r) => setTimeout(r, 100))

  // The user-reported case: the /sessions list float with REAL keypresses.
  await lua('require("dsh_tui").show_session_list(...)', [[
    { id: 'session-aaaa', title: '会话甲', active: true, kind: 'live' },
    { id: 'session-bbbb', title: '会话乙', active: false, kind: 'live' },
  ]])
  await new Promise((r) => setTimeout(r, 150))
  const sessBuf6 = await lua('return require("dsh_tui")._sessBuf', [])
  await nvim.request('nvim_input', ['<C-o>'])
  await nvim.request('nvim_input', ['<C-i>'])
  await new Promise((r) => setTimeout(r, 150))
  assert.equal(await lua('return vim.api.nvim_win_get_buf(require("dsh_tui")._sessWin)', []), sessBuf6, '<C-o>/<C-i> cannot swap the session list buffer')
  assert.equal(await lua('return require("dsh_tui")._reasoningOpen', []), false, 'session list: <C-o> does not open the panel')
  const sessLines6 = await nvim.request('nvim_buf_get_lines', [sessBuf6, 0, -1, false])
  assert.ok(sessLines6.some((l: string) => l.includes('会话甲')), 'session list content intact after jumplist keys')
  await lua('require("dsh_tui").close_session_list()', [])
  await new Promise((r) => setTimeout(r, 100))

  // Fullscreen editor: normal-mode jumplist keys must not swap the draft.
  await lua('require("dsh_tui").full_input_toggle()', [])
  await new Promise((r) => setTimeout(r, 150))
  const fiBuf6 = await lua('return require("dsh_tui")._fullInput.buf', [])
  await lua('vim.cmd("stopinsert")', []) // normal mode inside the editor
  await nvim.request('nvim_input', ['<C-o>'])
  await nvim.request('nvim_input', ['<C-i>'])
  await new Promise((r) => setTimeout(r, 150))
  assert.equal(await lua('return vim.api.nvim_win_get_buf(require("dsh_tui")._fullInput.win)', []), fiBuf6, 'fullscreen editor buffer survives jumplist keys')
  assert.equal(await lua('return require("dsh_tui")._reasoningOpen', []), false, 'fullscreen editor: <C-o> does not open the panel')
  await lua('require("dsh_tui").full_input_close()', [])
  await new Promise((r) => setTimeout(r, 100))

  // tool records go to the panel too; chat shows only the live activity line
  feedB.applyEvent({ type: 'tool/call', time: 5600, data: { turn: 1, step: 1, callId: 'c-1', name: 'bash', arguments: '{"cmd":"ls"}' } })
  await new Promise((r) => setTimeout(r, 100))
  let chatDuring = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.ok(chatDuring.some((l: string) => /^🔧 bash · \d+\.\d+s$/.test(l)), 'chat shows live tool activity line')
  assert.ok(!chatDuring.some((l: string) => l.includes('{"cmd":"ls"}')), 'tool card NOT in chat')
  feedB.applyEvent({ type: 'tool/result', time: 5800, data: { turn: 1, step: 1, message: { content: [{ type: 'text', text: 'README.md' }], source: { callId: 'c-1' } } } })
  await new Promise((r) => setTimeout(r, 100))
  reasonLines = await nvim.request('nvim_buf_get_lines', [reasonB.reasoningBuf, 0, -1, false])
  log('panel with tools:', JSON.stringify(reasonLines))
  assert.ok(reasonLines.some((l: string) => l.startsWith('🔧 bash(')), 'tool call in panel')
  assert.ok(reasonLines.some((l: string) => l.startsWith('✓ bash · 200ms')), 'tool result in panel')
  chatDuring = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.ok(!chatDuring.some((l: string) => /^🔧 bash ·/.test(l)), 'activity line gone after result')
  feedB.applyEvent({ type: 'turn/end', time: 5500, data: {} })

  // placeholder while a turn is silent
  feedB.applyEvent({ type: 'turn/start', time: 6000, data: {} })
  await new Promise((r) => setTimeout(r, 1400)) // 800ms threshold + ticker flush
  const linesB3 = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  log('placeholder lines:', JSON.stringify(linesB3))
  assert.ok(linesB3.some((l: string) => /^·· thinking… \d+s$/.test(l)), 'silent turn shows thinking placeholder')
  feedB.applyEvent({ type: 'turn/end', time: 6500, data: {} })

  // 6a2. todo pinned panel: incomplete → pinned at the BOTTOM (above the
  // thinking row, never displaced by content); all-✓ → commits into base.
  feedB.applyEvent({ type: 'todo/write', time: 7000, data: { todos: [
    { content: '功能实现', status: 'in_progress' }, { content: '补测试', status: 'pending' } ] } })
  feedB.applyEvent({ type: 'assistant/message', time: 7010, data: { turn: 2, step: 1, message: { content: [{ type: 'text', text: '中间内容行A' }] } } })
  feedB.applyEvent({ type: 'assistant/chunk', time: 7020, data: { chunk: { type: 'reasoning-delta', text: '想一下' } } })
  await new Promise((r) => setTimeout(r, 250))
  let tLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  const tHeader = tLines.findIndex((l: string) => l.startsWith('📋 待办'))
  const tThink = tLines.findIndex((l: string) => l.startsWith('·· thinking'))
  assert.ok(tHeader >= 0 && tThink >= 0, 'todo panel + thinking line both render')
  assert.equal(tHeader, tLines.length - 4, 'incomplete todo pinned directly above the thinking row (2 items)')
  assert.equal(tThink, tLines.length - 1, 'thinking row stays the bottom-most line (never covered)')
  // re-emission updates IN the pinned slot (no stacking, no flow copies)
  feedB.applyEvent({ type: 'todo/write', time: 7030, data: { todos: [
    { content: '功能实现', status: 'completed' }, { content: '补测试', status: 'in_progress' } ] } })
  await new Promise((r) => setTimeout(r, 250))
  tLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.equal(tLines.filter((l: string) => l.startsWith('📋 待办')).length, 1, 're-emission replaces the pinned block')
  assert.ok(tLines.some((l: string) => l.includes('✓ 功能实现')), 'pinned status updates in place')
  assert.ok(!tLines.some((l: string) => l.includes('… 功能实现')), 'stale pinned row gone')
  // all-✓ re-emission dedupe: identical completed list within the turn
  // commits ONCE (models repeat the whole list).
  feedB.applyEvent({ type: 'todo/write', time: 7040, data: { todos: [
    { content: '功能实现', status: 'completed' }, { content: '补测试', status: 'completed' } ] } })
  feedB.applyEvent({ type: 'todo/write', time: 7041, data: { todos: [
    { content: '功能实现', status: 'completed' }, { content: '补测试', status: 'completed' } ] } })
  await new Promise((r) => setTimeout(r, 250))
  tLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.equal(tLines.filter((l: string) => l.startsWith('📋 待办')).length, 1, 'identical all-✓ re-emission commits once')

  // all-✓ → COMMITS into base as ordinary chat content
  feedB.applyEvent({ type: 'todo/write', time: 7040, data: { todos: [
    { content: '功能实现', status: 'completed' }, { content: '补测试', status: 'completed' } ] } })
  await new Promise((r) => setTimeout(r, 250))
  tLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  const tHeader2 = tLines.findIndex((l: string) => l.startsWith('📋 待办'))
  const tThink2 = tLines.findIndex((l: string) => l.startsWith('·· thinking'))
  assert.ok(tHeader2 >= 0 && tHeader2 < tThink2, 'completed todo committed into the chat flow (above the tail/thinking)')
  assert.ok(tHeader2 < tLines.length - 2, 'committed block no longer occupies the pinned slot')
  // turn/end with an incomplete todo → STAYS pinned (standing board, the
  // jobs-board pattern): content can never push it into the transcript.
  feedB.applyEvent({ type: 'todo/write', time: 7050, data: { todos: [
    { content: '收尾', status: 'in_progress' } ] } })
  feedB.applyEvent({ type: 'turn/end', time: 7060, data: {} })
  await new Promise((r) => setTimeout(r, 250))
  tLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.equal(tLines.filter((l: string) => l.startsWith('📋 待办')).length, 2, 'one committed all-✓ block in history + one pinned standing board')
  assert.ok(tLines[tLines.length - 2]?.startsWith('📋 待办'), 'incomplete todo keeps the bottom pinned slot after turn end')

  // 6a2b. jobs pinned board: live updates in the bottom slot, all-terminal
  // commits the final state into base.
  feedB.applyEvent({ type: 'turn/start', time: 7070, data: { turn: 3 } })
  await new Promise((r) => setTimeout(r, 250))
  tLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.ok(tLines[tLines.length - 2]?.startsWith('📋 待办'), 'standing todo board survives turn/start (cross-turn pinning)')
  // Empty todos clear the pinned slot without committing.
  feedB.applyEvent({ type: 'todo/write', time: 7071, data: { todos: [] } })
  await new Promise((r) => setTimeout(r, 250))
  tLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.equal(tLines.filter((l: string) => l.startsWith('📋 待办')).length, 1, 'empty todo/write clears the pinned slot (only the committed block remains)')

  // 6a2c. FLUSHED todos: a later whole-list re-send that still carries the
  // committed completed items must not re-pin/re-commit them — the board
  // shows only the new item (lists stay bounded after the commit).
  feedB.applyEvent({ type: 'todo/write', time: 7072, data: { todos: [
    { content: '功能实现', status: 'completed' },
    { content: '补测试', status: 'completed' },
    { content: '新任务', status: 'in_progress' },
  ] } })
  await new Promise((r) => setTimeout(r, 250))
  tLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.equal(tLines[tLines.length - 2], '📋 待办 1 项 · 0 完成 · 1 进行中 · 0 待办', 'flushed completed items stay out of the pinned board')
  assert.equal(tLines[tLines.length - 1], '  … 新任务', 'pinned board shows only the new item')
  // Completing it commits ONLY the new item — the flushed ones never repeat.
  feedB.applyEvent({ type: 'todo/write', time: 7073, data: { todos: [
    { content: '功能实现', status: 'completed' },
    { content: '补测试', status: 'completed' },
    { content: '新任务', status: 'completed' },
  ] } })
  await new Promise((r) => setTimeout(r, 250))
  tLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.equal(tLines.filter((l: string) => l === '📋 待办 1 项 · 1 完成 · 0 进行中 · 0 待办').length, 1, 'second completion commits only the new item')
  assert.equal(tLines.filter((l: string) => l === '  ✓ 功能实现').length, 1, 'flushed items are never re-committed')
  assert.equal(tLines.filter((l: string) => l === '  ✓ 新任务').length, 1, 'the new item commits exactly once')
  assert.ok(!tLines[tLines.length - 1]?.startsWith('📋'), 'pinned slot cleared after the all-✓ commit')
  const jobsRows1 = ['', '⚙ 任务 2 项 · 1 运行中', '  ⏳ lint', '  · test']
  feedB.setJobsBoard(jobsRows1)
  feedB.applyEvent({ type: 'assistant/chunk', time: 7080, data: { chunk: { type: 'reasoning-delta', text: '任务跑着' } } })
  await new Promise((r) => setTimeout(r, 250))
  let jLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  const jHeader = jLines.findIndex((l: string) => l.startsWith('⚙ 任务'))
  const jThink = jLines.findIndex((l: string) => l.startsWith('·· thinking'))
  assert.ok(jHeader >= 0 && jThink >= 0, 'jobs board + thinking line both render')
  assert.equal(jHeader, jLines.length - 4, 'jobs board pinned directly above the thinking row (2 jobs)')
  assert.equal(jThink, jLines.length - 1, 'thinking stays bottom-most with the board pinned above')
  feedB.setJobsBoard(jobsRows1) // identical → no churn
  await new Promise((r) => setTimeout(r, 250))
  jLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.equal(jLines.filter((l: string) => l.startsWith('⚙ 任务')).length, 1, 'identical board is a no-op')
  // all terminal → commit
  feedB.commitJobsBoard(['', '⚙ 任务 2 项 · 0 运行中', '  ✓ lint', '  ✗ test'])
  await new Promise((r) => setTimeout(r, 250))
  jLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  const jHeader2 = jLines.findIndex((l: string) => l.startsWith('⚙ 任务'))
  const jThink2 = jLines.findIndex((l: string) => l.startsWith('·· thinking'))
  assert.ok(jHeader2 >= 0 && jHeader2 < jThink2 - 1, 'terminal board committed into the flow')
  feedB.applyEvent({ type: 'turn/end', time: 7090, data: {} })

  // 6b. task step-progress block: while ANY step is incomplete the trailing
  // `- ✅/⏳/⬜ …` block renders ABOVE the thinking line (dynamic — each new
  // message replaces the live version); once every step is ✅ it falls back
  // into the ordinary tail and commits on turn end (persisted for replays).
  feedB.applyEvent({ type: 'turn/start', time: 7000, data: {} })
  feedB.applyEvent({ type: 'assistant/message', time: 7100, data: { turn: 2, step: 1, message: { content: [{ type: 'text', text: '任务全链进度（回调通知需求）:\n- ✅ 功能实现\n- ⏳ code-review\n- ⬜ 补测试' }] } } })
  feedB.applyEvent({ type: 'assistant/chunk', time: 7150, data: { chunk: { type: 'reasoning-delta', text: '推进任务' } } })
  await new Promise((r) => setTimeout(r, 250))
  let stepLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  const idxOf = (re: RegExp) => stepLines.findIndex((l: string) => re.test(l))
  let pHeader = idxOf(/^任务全链进度/)
  let pStep = idxOf(/^- ⏳ code-review/)
  let pThink = idxOf(/^·· thinking/)
  assert.ok(pHeader >= 0 && pStep >= 0 && pThink >= 0, 'progress block + thinking line both render')
  assert.ok(pHeader < pThink && pStep < pThink, 'incomplete progress block renders ABOVE the thinking line')
  // a later step re-emits the block, still incomplete → stays lifted
  feedB.applyEvent({ type: 'assistant/message', time: 7200, data: { turn: 2, step: 2, message: { content: [{ type: 'text', text: '任务全链进度（回调通知需求）:\n- ✅ 功能实现\n- ✅ code-review\n- ⏳ 补测试' }] } } })
  feedB.applyEvent({ type: 'assistant/chunk', time: 7250, data: { chunk: { type: 'reasoning-delta', text: '收尾' } } })
  await new Promise((r) => setTimeout(r, 250))
  stepLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  pHeader = idxOf(/^任务全链进度/)
  pStep = idxOf(/^- ⏳ 补测试/)
  pThink = idxOf(/^·· thinking/)
  assert.ok(pHeader >= 0 && pStep >= 0 && pThink >= 0, 'updated block + thinking line both render')
  assert.ok(pHeader < pThink, 'updated incomplete block stays ABOVE the thinking line')
  // all ✅ → ordinary tail (ABOVE the bottom-pinned indicator), committed on turn end
  feedB.applyEvent({ type: 'assistant/message', time: 7300, data: { turn: 2, step: 3, message: { content: [{ type: 'text', text: '任务全链进度（回调通知需求）:\n- ✅ 功能实现\n- ✅ code-review\n- ✅ 补测试' }] } } })
  feedB.applyEvent({ type: 'assistant/chunk', time: 7350, data: { chunk: { type: 'reasoning-delta', text: '完成' } } })
  await new Promise((r) => setTimeout(r, 250))
  stepLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  const cHeader = idxOf(/^任务全链进度/)
  const cThink = idxOf(/^·· thinking/)
  assert.ok(cHeader >= 0 && cThink >= 0, 'completed block + thinking line both render')
  assert.ok(cHeader < cThink, 'completed block sits in the normal tail (above the bottom-pinned indicator)')
  // the transient indicator is the LAST buffer row — content streams above it
  // and can never displace it into the middle of the chat window
  assert.equal(cThink, stepLines.length - 1, 'activity indicator pinned at the bottom of the chat view')
  feedB.applyEvent({ type: 'turn/end', time: 7400, data: {} })
  await new Promise((r) => setTimeout(r, 250))
  const persisted = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.ok(persisted.some((l: string) => l.includes('任务全链进度'))
    && persisted.some((l: string) => l.includes('✅ 补测试')),
    'completed block commits to the chat (persisted for replays)')
  assert.ok(!persisted.some((l: string) => /⏳|⬜/.test(l)),
    'intermediate incomplete versions never land in the chat')

  // 7. <C-o> reasoning panel toggle
  // Chat width BEFORE the panel opens — the pre-review assertion captured it
  // AFTER the open and compared the window with itself (always true).
  const chatWBefore = await lua('return vim.api.nvim_win_get_width(require("dsh_tui").ids().chatWin)', [])
  const opened = await lua('return require("dsh_tui").toggle_reasoning()', [])
  assert.equal(opened, true, 'panel opens')
  let idsT = await lua('return require("dsh_tui").ids()', [])
  assert.ok(Number.isInteger(idsT.reasoningWin), 'reasoning window exists')
  assert.equal(idsT.reasoningOpen, true)
  assert.equal(await lua('return vim.api.nvim_win_get_buf(...)', [idsT.reasoningWin]), reasonB.reasoningBuf,
    'panel shows active session reasoning')
  // popup panel: editor-relative float hugging the RIGHT edge (chat keeps
  // its full width), below menus/approvals in z-order
  const panelCfg = await nvim.request('nvim_win_get_config', [idsT.reasoningWin])
  assert.equal(panelCfg.relative, 'editor', 'reasoning panel is a float')
  assert.equal(panelCfg.anchor, 'NE', 'panel anchors to the top-right')
  assert.equal(panelCfg.col, (await lua('return vim.o.columns', [])) - 1, 'panel right edge sits at the screen edge')
  assert.ok(panelCfg.width >= 30 && panelCfg.width <= 52, 'panel width clamped')
  assert.ok(panelCfg.zindex < 50, 'panel sits below menus/approvals')
  assert.ok(String(panelCfg.title).includes('思考'), 'panel carries a title')
  if (await lua('return vim.fn.has("nvim-0.10") == 1', [])) {
    assert.ok(JSON.stringify(panelCfg.footer).includes('C-o'), 'panel bottom border carries the operation hints')
  }
  assert.equal(await lua('return vim.api.nvim_win_get_width(require("dsh_tui").ids().chatWin)', []), chatWBefore,
    'chat keeps its full width while the panel is open')
  // the panel spans 3/4 of the screen height (a panel, not a full column)
  const lines0 = await lua('return vim.o.lines', [])
  assert.equal(panelCfg.height, Math.max(3, Math.floor(lines0 * 0.75)), 'panel spans 3/4 of the screen height')
  const closed = await lua('return require("dsh_tui").toggle_reasoning()', [])
  assert.equal(closed, false, 'panel closes')
  idsT = await lua('return require("dsh_tui").ids()', [])
  assert.equal(idsT.reasoningOpen, false)

  // 8. markdown table → aligned box-drawing table (Claude-TUI style)
  const tableText = [
    '| 日期 | AQI | 等级 | 主要污染物 |',
    '|------|-----|------|-----------|',
    '| **今天** 8/19 | 29 | 🟢 优 | 无（O₃ 78 稍高） |',
    '| 明天 8/20 | 50 | 🟢 优 | `无` |',
  ].join('\n')
  feedB.applyEvent({ type: 'assistant/message', time: 7000, data: { turn: 2, step: 1, message: { content: [{ type: 'text', text: tableText }] } } })
  await new Promise((r) => setTimeout(r, 120))
  let linesT = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  log('table streaming:', JSON.stringify(linesT.slice(-7)))
  assert.ok(linesT.some((l: string) => l.startsWith('┌')), 'table top border')
  assert.ok(linesT.some((l: string) => l.startsWith('├')), 'table header separator')
  assert.ok(linesT.some((l: string) => l.includes('日期') && l.includes('AQI')), 'table header rendered')
  assert.ok(linesT.includes('│ 今天 8/19 │  29 │ 🟢 优 │ 无（O₃ 78 稍高） │'), 'aligned row (display-width padded)')
  assert.ok(linesT.some((l: string) => l.includes('│ 明天 8/20 │  50 │ 🟢 优 │ 无')), 'backtick cell markup stripped')
  assert.ok(!linesT.some((l: string) => l.includes('**') || l.includes('`')), 'no literal markdown markers in table cells')
  assert.ok(!linesT.some((l: string) => l.startsWith('└')), 'no bottom border while streaming')
  // close the stream → bottom border appears
  feedB.applyEvent({ type: 'turn/end', time: 7200, data: {} })
  await new Promise((r) => setTimeout(r, 120))
  linesT = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  log('table closed:', JSON.stringify(linesT.slice(-6)))
  log('table closed FULL:', JSON.stringify(linesT))
  assert.ok(linesT.some((l: string) => l.startsWith('└')), 'bottom border after stream closes')
  // per-row dividers: EVERY data row carries its own ├…┤; the last one
  // closes as the bottom border
  const todayIdx = linesT.findIndex((l: string) => l.includes('今天 8/19'))
  const tomorrowIdx = linesT.findIndex((l: string) => l.includes('明天 8/20'))
  assert.ok(todayIdx >= 0 && tomorrowIdx >= 0, 'table data rows present')
  assert.ok((linesT[todayIdx + 1] ?? '').startsWith('├'), 'data row followed by its own divider')
  assert.ok((linesT[tomorrowIdx + 1] ?? '').startsWith('└'), 'last data row closes with the bottom border')
  assert.ok((linesT[todayIdx - 1] ?? '').startsWith('├'), 'header divider kept above the first data row')

  // The WHOLE table renders bold (uniform stroke weight): every table row —
  // top border, header, separator, body, bottom border — carries one
  // full-row DshTuiBold group from column 0 to the row's byte length, so
  // cells, '│' separators, '─' strokes and corners all match. (Regression:
  // borders used to be dim DshTuiDivider and separators unbolded, which
  // made '─'/corners render thinner than '│' — a half-bold frame.)
  // (nvim 0.12 bug: nvim_buf_get_extmarks with ns=-1 rejects a bounded end
  //  row, so query the full buffer and filter by row here.)
  const tableRowIdxs = [
    linesT.findIndex((l: string) => l.startsWith('┌')),
    linesT.findIndex((l: string) => l.includes('日期') && l.includes('AQI')),
    linesT.findIndex((l: string) => l.startsWith('├')),
    linesT.findIndex((l: string) => l.includes('今天 8/19')),
    linesT.findIndex((l: string) => l.includes('明天 8/20')),
    linesT.findIndex((l: string) => l.startsWith('└')),
  ]
  const tableMarks = await nvim.request('nvim_buf_get_extmarks', [chatB.chatBuf, -1, 0, -1, { details: true }])
  for (const rowIdx of tableRowIdxs) {
    assert.ok(rowIdx >= 0, 'table row present')
    const rowByteLen = Buffer.byteLength(linesT[rowIdx], 'utf8')
    const fullBold = tableMarks.some((m: any) => m[1] === rowIdx && m[3]?.hl_group === 'DshTuiBold' &&
      m[3]?.end_row === rowIdx && m[2] === 0 && m[3]?.end_col === rowByteLen)
    assert.ok(fullBold, `row ${rowIdx}: whole-row bold group covers cells + separators`)
    assert.ok(!tableMarks.some((m: any) => m[1] === rowIdx && m[3]?.hl_group === 'DshTuiDivider'),
      `row ${rowIdx}: table rows no longer dim (DshTuiDivider)`)
  }

  // chat-view markdown table: an assistant message carrying a GFM table
  // (the roadmap shape reported raw) must render as the bordered table.
  feedB.applyEvent({ type: 'turn/start', time: 7350, data: {} })
  feedB.applyEvent({ type: 'assistant/message', time: 7400, data: { turn: 4, step: 1, message: { content: [{ type: 'text', text: '分期路线：\n| 阶段 | 内容 | 规模 |\n|---|---|---|\n| P1 | ctx.tui 门面 + 文档 + 示例插件 | 小、稳 |\n| P2 | block renderer + Lua api | 中 |' }] } } })
  await new Promise((r) => setTimeout(r, 120))
  const chatTable = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  log('chat markdown table:', JSON.stringify(chatTable.slice(-12)))
  assert.ok(chatTable.some((l: string) => l.startsWith('┌──')), 'chat table top border')
  assert.ok(chatTable.some((l: string) => /^│ P1\s+│ ctx\.tui/.test(l)), 'chat table P1 row aligned')
  assert.ok(!chatTable.includes('|---|---|---|'), 'chat raw separator replaced')
  feedB.applyEvent({ type: 'turn/end', time: 7450, data: {} })
  // The REAL event text (bold/code-markup cells, heading above): replay it
  // the way a resumed session does and the table must still transform.
  feedB.applyEvent({ type: 'turn/start', time: 7460, data: {} })
  feedB.applyEvent({ type: 'assistant/message', time: 7470, data: { turn: 5, step: 1, message: { content: [{ type: 'text', text: '## 8. 分期路线\n\n| 阶段 | 内容 | 规模 |\n|---|---|---|\n| **P1** | `ctx.tui` 门面（读 + notify/picker/command/send + `tui/*` 事件）+ PLUGINS.md + 公开 d.ts + 1 个示例插件 | 小、稳 |\n| **P2** | block renderer 注册 + Lua api/autocmds + luaPlugins 装载 | 中 |\n| **P3** | input veto/transform、状态栏段、分屏辅助 | 按反馈 |' }] } } })
  await new Promise((r) => setTimeout(r, 120))
  const chatRealTable = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  log('chat real event table:', JSON.stringify(chatRealTable.slice(-12)))
  assert.ok(chatRealTable.some((l: string) => l.startsWith('┌──')), 'real event table top border')
  assert.ok(chatRealTable.some((l: string) => /^│ P1\s+│ ctx\.tui/.test(l)), 'real event table P1 row aligned')
  assert.ok(!chatRealTable.some((l: string) => l === '|---|---|---|'), 'real event raw separator replaced')
  feedB.applyEvent({ type: 'turn/end', time: 7490, data: {} })
  // history replay flag: a resumed session re-applies the same events with
  // {history:true} — the table must still transform.
  feedB.applyEvent({ type: 'turn/start', time: 7500, data: {} }, { history: true })
  feedB.applyEvent({ type: 'assistant/message', time: 7510, data: { turn: 6, step: 1, message: { content: [{ type: 'text', text: '## 8. 分期路线\n\n| 阶段 | 内容 | 规模 |\n|---|---|---|\n| **P1** | `ctx.tui` 门面（读 + notify/picker/command/send + `tui/*` 事件）+ PLUGINS.md + 公开 d.ts + 1 个示例插件 | 小、稳 |' }] } } }, { history: true })
  await new Promise((r) => setTimeout(r, 120))
  const chatHistTable = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  log('chat history-flag table:', JSON.stringify(chatHistTable.slice(-10)))
  assert.ok(chatHistTable.some((l: string) => l.startsWith('┌──')), 'history-flag table top border')
  assert.ok(!chatHistTable.some((l: string) => l === '|---|---|---|'), 'history-flag raw separator replaced')
  feedB.applyEvent({ type: 'turn/end', time: 7530, data: {} }, { history: true })
  // Regression: a diff card whose verbatim rows contain an ODD fence marker
  // must not desync the fence state — a markdown table right after it still
  // renders bordered (the old pre-pass left it raw forever).
  feedB.applyEvent({ type: 'turn/start', time: 7540, data: {} })
  feedB.pushDiff('✎ 修改 README.md (+1 −0)', ['+ ```', '+ const x = 1'])
  feedB.applyEvent({ type: 'assistant/message', time: 7550, data: { turn: 7, step: 1, message: { content: [{ type: 'text', text: '| 列A | 列B |\n|---|---|\n| a | b |' }] } } })
  await new Promise((r) => setTimeout(r, 120))
  const chatAfterDiff = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  log('chat table after diff fence:', JSON.stringify(chatAfterDiff.slice(-10)))
  assert.ok(chatAfterDiff.some((l: string) => l.includes('+ ```')), 'diff verbatim row kept')
  assert.ok(chatAfterDiff.some((l: string) => l.startsWith('┌──')), 'table after diff fence still bordered')
  assert.ok(chatAfterDiff.some((l: string) => /^│ 列A │ 列B/.test(l)), 'table after diff fence header aligned')
  assert.ok(!chatAfterDiff.some((l: string) => l === '|---|---|'), 'table after diff fence raw separator replaced')
  feedB.applyEvent({ type: 'turn/end', time: 7570, data: {} })

  // overwide tables wrap INSIDE the frame: columns shrink (widest first)
  // and cell content flows into continuation lines, EVERY one bordered —
  // nvim's soft-wrap used to bend the box out of shape (continuation rows
  // lost their │ and the corners no longer lined up).
  const longCell = '很长很长的单元格内容'.repeat(12)
  feedB.applyEvent({ type: 'assistant/message', time: 7580, data: { turn: 8, step: 1, message: { content: [{ type: 'text', text: `| 阶段 | 说明 |\n|---|---|\n| P1 | ${longCell} |` }] } } })
  await new Promise((r) => setTimeout(r, 150))
  const wrapLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  log('wrapped table:', JSON.stringify(wrapLines.slice(-14)))
  const wrapStart = wrapLines.findIndex((l: string) => l.includes('阶段') && l.includes('说明'))
  assert.ok(wrapStart >= 0, 'wrapped table header present')
  const wrapBlock = wrapLines.slice(wrapStart)
  const wrapData = wrapBlock.filter((l: string) => l.startsWith('│'))
  assert.ok(wrapData.length >= 4, `long cell wrapped into continuation lines (got ${wrapData.length})`)
  for (const l of wrapData) {
    assert.ok(l.endsWith('│'), 'every continuation line keeps the right border')
    assert.equal(l.split('│').length, 4, 'every line keeps the internal separators')
  }
  const wrapJoined = wrapData.map((l: string) => l.replace(/│/g, '')).join('')
  assert.ok(wrapJoined.includes('很长很长的单元格内容很长很长的单元格内容'), 'wrapped content preserved in order')
  const wrapWidths = wrapBlock.map((l: string) => stringWidth(l))
  assert.ok(Math.max(...wrapWidths) <= 101, 'wrapped table stays within the viewport width (no soft-wrap)')
  feedB.applyEvent({ type: 'turn/end', time: 7590, data: {} })

  // inline spans are byte-indexed: CJK bold must cover exactly the text bytes
  feedB.applyEvent({ type: 'assistant/message', time: 7300, data: { turn: 3, step: 1, message: { content: [{ type: 'text', text: '前缀 **中文加粗** 后缀' }] } } })
  await new Promise((r) => setTimeout(r, 120))
  const cjkLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  const cjkIdx = cjkLines.findIndex((l: string) => l.includes('中文加粗'))
  assert.ok(cjkIdx >= 0, 'cjk bold line present')
  const cjkMarks = await nvim.request('nvim_buf_get_extmarks', [chatB.chatBuf, -1, 0, -1, { details: true }])
  const cjkBold = cjkMarks.filter((m: any) => m[1] === cjkIdx && m[3]?.hl_group === 'DshTuiBold')
  assert.equal(cjkBold.length, 1, 'one bold span on the cjk line')
  assert.equal(cjkBold[0][2], Buffer.byteLength('前缀 ', 'utf8'), 'bold span starts after the prefix (byte offset)')
  assert.equal(cjkBold[0][3].end_col - cjkBold[0][2], Buffer.byteLength('中文加粗', 'utf8'), 'bold span covers exactly the CJK text bytes')

  // image attachments render as 📎 label lines inside the user bubble
  feedB.applyEvent({ type: 'user/message', time: 7400, data: { message: { content: [
    { type: 'text', text: '看这张图' },
    { type: 'image', attachment: { mediaType: 'image/png', bytes: 1234, width: 640, height: 480 } },
  ] } } })
  await new Promise((r) => setTimeout(r, 120))
  const imgLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.ok(imgLines.includes('> 看这张图'), 'image message text rendered')
  assert.ok(imgLines.includes('> 📎 图片 (image/png · 640×480 · 1.2KB)'), 'image attachment label rendered')

  // user-pasted markdown tables beautify too (rows keep the > quote prefix)
  feedB.applyEvent({ type: 'user/message', time: 7410, data: { message: { content: [{ type: 'text', text: '看这个：\n| 阶段 | 内容 |\n|---|---|\n| P1 | 方案 |' }] } } })
  await new Promise((r) => setTimeout(r, 120))
  const userTable = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  log('user table echo:', JSON.stringify(userTable.slice(-8)))
  assert.ok(userTable.includes('> 看这个：'), 'plain user line kept verbatim')
  assert.ok(userTable.some((l: string) => l.startsWith('> ┌──')), 'user table top border quoted')
  assert.ok(userTable.some((l: string) => /^> │ P1\s+│ 方案/.test(l)), 'user table row aligned + quoted')
  assert.ok(!userTable.includes('> |---|'), 'user table raw separator replaced')

  // steer lines render with the ➤ marker
  feedB.pushBlock('steer', '换个方案试试')
  await new Promise((r) => setTimeout(r, 120))
  const steerLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.ok(steerLines.includes('➤ 换个方案试试'), 'steer directive rendered with marker')

  // skill-detail float opens and closes
  const baseWins = (await lua('return vim.api.nvim_list_wins()', [])).length
  await lua(`require("dsh_tui").show_skill({ name = "demo", description = "演示技能", whenToUse = "测试", content = "正文" })`, [])
  let skillWins = (await lua('return vim.api.nvim_list_wins()', [])).length
  const footerEmbedded = await lua('return vim.fn.has("nvim-0.10") == 1', [])
  assert.equal(skillWins, baseWins + (footerEmbedded ? 1 : 2), 'skill float opened (footer embedded in border on nvim 0.10+)')
  const skillBuf = await lua('return vim.api.nvim_win_get_buf(require("dsh_tui")._skillWin)', [])
  const skillLines = await nvim.request('nvim_buf_get_lines', [skillBuf, 0, -1, false])
  assert.equal(await lua('return vim.api.nvim_win_get_height(require("dsh_tui")._skillWin)', []), skillLines.length, 'skill window exactly fits content')
  await assertFooter('[q]', 'skill')
  await assertCentered('require("dsh_tui")._skillWin', 'skill')
  await lua('require("dsh_tui").close_skill()', [])
  skillWins = (await lua('return vim.api.nvim_list_wins()', [])).length
  assert.equal(skillWins, baseWins, 'skill float closed')

  // 9. M4 interactions: input submit/history/completion, approval, questions,
  // picker (all via the Lua API; the Node wiring is exercised in e2e).
  const notes: Array<{ method: string; args: unknown[] }> = []
  const onNote = (method: string, args: unknown[]): void => { notes.push({ method, args }) }
  nvim.on('notification', onNote)
  // Popup hints are pinned as the LAST row of the popup window (visible
  // regardless of scroll); each popup carries a function title.
  const floatTitle = (win: number) => nvim.request('nvim_win_get_config', [win]).then((c: any) => c.title ?? '')

  const waitNote = async (method: string, timeoutMs = 2000) => {
    const deadline = Date.now() + timeoutMs
    while (Date.now() < deadline) {
      const idx = notes.findIndex((n) => n.method === method)
      if (idx >= 0) return notes.splice(idx, 1)[0]
      await new Promise((r) => setTimeout(r, 20))
    }
    return null
  }
  const drainNotes = (method: string) => {
    for (let i = notes.length - 1; i >= 0; i--) {
      if (notes[i]?.method === method) notes.splice(i, 1)
    }
  }

  // 9a. input submit + history
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "你好世界" })`, [])
  await lua('require("dsh_tui").submit()', [])
  let hit = await waitNote('dsh-input')
  assert.equal(hit?.args?.[0], '你好世界', 'submit routes dsh-input')
  const inputAfter = await lua('return vim.api.nvim_buf_get_lines(require("dsh_tui").ids().inputBuf, 0, -1, false)', [])
  assert.deepEqual(inputAfter, [''], 'input reset after submit')
  await lua('require("dsh_tui").history_move(-1)', [])
  let txt = await lua('return table.concat(vim.api.nvim_buf_get_lines(require("dsh_tui").ids().inputBuf, 0, -1, false), "\\n")', [])
  assert.equal(txt, '你好世界', 'history up restores last input')

  // 9a2. /sessions float interactions: j/k + <CR> select (full id), <C-n> new.
  await lua('require("dsh_tui").show_session_list(...)', [[
    { id: 'session-aaaa', title: '会话甲', active: true, kind: 'live' },
    { id: 'session-bbbb', title: '会话乙', active: false, kind: 'live' },
  ]])
  await lua('require("dsh_tui").session_list_move(1)', [])
  await lua('require("dsh_tui").session_list_select()', [])
  hit = await waitNote('dsh-session-select')
  assert.equal(hit?.args?.[0], 'session-bbbb', 'session selection routes the full id')
  await lua('require("dsh_tui").show_session_list(...)', [[
    { id: 'session-aaaa', title: '会话甲', active: true, kind: 'live' },
  ]])
  await lua('require("dsh_tui").session_list_new()', [])
  hit = await waitNote('dsh-session-new')
  assert.ok(hit, 'new-session request routes from the float')

  // 9b. slash-command completion menu: fallback catalog (before the runner
  // pushes set_commands), auto-open on '/', live filtering, Tab/C-p cycling.
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "/" })`, [])
  await lua('require("dsh_tui").update_cmd_menu()', [])
  let menuSt = await lua('return require("dsh_tui").cmd_menu_state()', [])
  assert.equal(menuSt.open, true, 'menu opens on "/"')
  assert.equal(menuSt.selected, '/exit', 'first fallback command selected')
  assert.ok(menuSt.names.includes('/help') && menuSt.names.includes('/model'), 'fallback catalog lists commands')
  // 46: /bell was removed with the notification feature (its toggle had no effect left).
  assert.equal(menuSt.names.length, 46, 'all 46 fallback commands listed')

  // the runner's catalog (name + description) replaces the fallback
  await lua(`require("dsh_tui").set_commands({
    { name = "/exit", desc = "退出 dsh" },
    { name = "/export", desc = "导出转录 md" },
    { name = "/effort", desc = "推理等级" },
    { name = "/model", desc = "选择/切换模型" },
    { name = "/memory", desc = "浏览/删除项目记忆" },
  })`, [])
  await lua('require("dsh_tui").update_cmd_menu()', [])
  menuSt = await lua('return require("dsh_tui").cmd_menu_state()', [])
  assert.deepEqual(menuSt.names, ['/exit', '/export', '/effort', '/model', '/memory'], 'catalog listed in order')

  // live filtering narrows the menu to the prefix
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "/mo" })`, [])
  await lua('require("dsh_tui").update_cmd_menu()', [])
  menuSt = await lua('return require("dsh_tui").cmd_menu_state()', [])
  assert.deepEqual(menuSt.names, ['/model'], 'prefix filter narrows the menu')

  // Tab cycles the selection, C-p wraps back, a full name selects itself
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "/e" })`, [])
  await lua('require("dsh_tui").update_cmd_menu()', [])
  await lua('require("dsh_tui").cmd_next()', [])
  menuSt = await lua('return require("dsh_tui").cmd_menu_state()', [])
  assert.equal(menuSt.selected, '/export', 'Tab advances to the next match')
  await lua('require("dsh_tui").cmd_prev()', [])
  menuSt = await lua('return require("dsh_tui").cmd_menu_state()', [])
  assert.equal(menuSt.selected, '/exit', 'C-p moves back')
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "/effort" })`, [])
  await lua('require("dsh_tui").update_cmd_menu()', [])
  menuSt = await lua('return require("dsh_tui").cmd_menu_state()', [])
  assert.equal(menuSt.selected, '/effort', 'fully typed name selects itself')

  // the menu closes once arguments (a space) are typed
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "/model 42" })`, [])
  await lua('require("dsh_tui").update_cmd_menu()', [])
  menuSt = await lua('return require("dsh_tui").cmd_menu_state()', [])
  assert.equal(menuSt.open, false, 'menu closes once arguments are typed')

  // <CR> on a bare prefix fills the selected command (a second <CR> executes)
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "/mo" })`, [])
  await lua('require("dsh_tui").update_cmd_menu()', [])
  await lua('require("dsh_tui").submit()', [])
  txt = await lua('return table.concat(vim.api.nvim_buf_get_lines(require("dsh_tui").ids().inputBuf, 0, -1, false), "\\n")', [])
  assert.equal(txt, '/model ', 'CR completes the selected command')
  menuSt = await lua('return require("dsh_tui").cmd_menu_state()', [])
  assert.equal(menuSt.open, false, 'menu closed after completing')

  // <CR> with the full name typed executes the command directly
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "/model" })`, [])
  await lua('require("dsh_tui").update_cmd_menu()', [])
  await lua('require("dsh_tui").submit()', [])
  hit = await waitNote('dsh-command')
  assert.equal(hit?.args?.[0], '/model', 'fully typed command executes directly')
  // plain text never opens the menu
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "plain" })`, [])
  await lua('require("dsh_tui").update_cmd_menu()', [])
  menuSt = await lua('return require("dsh_tui").cmd_menu_state()', [])
  assert.equal(menuSt.open, false, 'no menu for plain text')

  // 9c. completion-menu keymaps exist on the input buffer
  const imaps = await lua(`local out = {}
    for _, m in ipairs(vim.api.nvim_buf_get_keymap(require("dsh_tui").ids().inputBuf, "i")) do
      table.insert(out, { lhs = m.lhs })
    end
    return out`, [])
  for (const key of ['<C-N>', '<C-P>', '<Tab>', '<S-Tab>', '<Esc>', '<C-V>', '<C-C>']) {
    assert.ok(imaps.some((m: any) => m.lhs === key), key + ' mapped on the input buffer')
  }

  // 9d. approval window — including a long wrapped reason: the key-hint row
  // must stay inside the window (previously the fixed height clipped it).
  const winsBefore = (await lua('return vim.api.nvim_list_wins()', [])).length
  await lua('require("dsh_tui").show_approval(...)', [{ toolName: 'bash', reason: '执行命令 ' + 'x'.repeat(120), args: JSON.stringify({ command: 'rm -rf /tmp/approval-probe', justification: 'need to clean temp' }) }])
  let wins = await lua('return vim.api.nvim_list_wins()', [])
  assert.ok(wins.length > winsBefore, 'approval float window opened')
  let approvalF = await lua('return require("dsh_tui")._float', [])
  let approvalFCfg = await nvim.request('nvim_win_get_config', [approvalF.win])
  const approvalFLines = await nvim.request('nvim_buf_get_lines', [approvalF.buf, 0, -1, false])
  const approvalFVisual = approvalFLines.reduce((h: number, l: string) => h + Math.max(1, Math.ceil([...l].reduce((w, ch) => w + (/[\u2E80-\uA4CF\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFFEF\u3000-\u303F]/u.test(ch) ? 2 : 1), 0) / approvalFCfg.width)), 0)
  log('approval cfg:', JSON.stringify(approvalFCfg), 'visual rows:', approvalFVisual)
  assert.ok(approvalFCfg.height >= approvalFVisual, 'approval window height covers wrapped content')
  assert.ok(approvalFCfg.height >= 4, 'long reason grows the approval window')
  assert.ok(String(await floatTitle(approvalF.win)).includes('审批请求'), 'approval float carries a function title')
  assert.ok(approvalFLines.some((l: string) => l.includes('参数:')), 'approval float shows the tool arguments section')
  assert.ok(approvalFLines.some((l: string) => l.includes('rm -rf /tmp/approval-probe')), 'approval float shows the exact command')
  await assertFooter('[y]', 'approval')
  await assertCentered('require("dsh_tui")._float.win', 'approval')
  assert.equal(await lua('return vim.bo[require("dsh_tui")._float.buf].modifiable', []), false, 'approval buffer is read-only')
  await lua('require("dsh_tui").approval_decide("y")', [])
  hit = await waitNote('dsh-approval-decided')
  assert.equal(hit?.args?.[0], 'y', 'approval decision routed')
  // file-change diff block renders in the chat with whole-line groups
  feedA.pushDiff('✎ 修改 src/x.ts (+1 −1)', ['- old line', '+ new line', '  ctx'])
  await new Promise((r) => setTimeout(r, 200))
  const diffLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  assert.ok(diffLines.includes('✎ 修改 src/x.ts (+1 −1)'), 'diff header rendered in chat')
  assert.ok(diffLines.includes('+ new line'), 'diff added line rendered')
  assert.ok(diffLines.includes('- old line'), 'diff removed line rendered')
  const diffMarks: any[] = await nvim.request('nvim_buf_get_extmarks', [chatA.chatBuf, -1, 0, -1, { details: true }])
  const diffGroups = new Set(diffMarks.map((m) => m[3]?.hl_group))
  assert.ok(diffGroups.has('DshTuiDiffAdd') && diffGroups.has('DshTuiDiffDel'),
    'diff lines carry add/del highlight groups')
  // regression: a diff CONTEXT line holding a fence marker (`  ```` from a code
  // block inside an edited file) must NOT toggle the view's fence state —
  // everything after the card stays plain, never sky-blue DshTuiCode
  feedA.pushDiff('✎ 修改 README.md (+1 −1)', ['+ new line', '  ```', '- old line'])
  feedA.applyEvent({ type: 'assistant/chunk', data: { chunk: { type: 'text-delta', text: '围栏之后的普通文本\n' } } })
  await new Promise((r) => setTimeout(r, 250))
  const afterFenceLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  const afterFenceRow = afterFenceLines.indexOf('围栏之后的普通文本')
  assert.ok(afterFenceRow >= 0, 'text after a fence-marker context line renders')
  const afterFenceMarks: any[] = await nvim.request('nvim_buf_get_extmarks', [chatA.chatBuf, -1, 0, -1, { details: true }])
  const codeOnRow = afterFenceMarks.filter((m) => m[1] === afterFenceRow && m[3]?.hl_group === 'DshTuiCode')
  assert.equal(codeOnRow.length, 0, 'fence marker inside diff context must not leak code color below the card')
  // transient activity rows never commit: an echo under a live '·· thinking…'
  // line must not stack a second thinking row into the chat
  feedA.applyEvent({ type: 'turn/start', data: {} })
  await new Promise((r) => setTimeout(r, 950))
  feedA.pushUser('正在思考时发的新问题', []) // the optimistic echo
  await new Promise((r) => setTimeout(r, 200))
  feedA.applyEvent({ type: 'turn/end', data: {} })
  await new Promise((r) => setTimeout(r, 250))
  const echoLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  const thinkingCount = echoLines.filter((l: string) => l.startsWith('·· thinking')).length
  assert.ok(thinkingCount <= 1, 'no stacked thinking rows after an echo under a live turn')
  assert.ok(echoLines.includes('> 正在思考时发的新问题'), 'echoed bubble rendered')
  const userMarks: any[] = await nvim.request('nvim_buf_get_extmarks', [chatA.chatBuf, -1, 0, -1, { details: true }])
  const userRow = echoLines.indexOf('> 正在思考时发的新问题')
  const userRowHl = userMarks.find((m) => m[1] === userRow && m[3]?.hl_group === 'DshTuiUser')
  assert.ok(userRowHl !== undefined, 'echoed user bubble carries the DshTuiUser color group')
  // host-injected context (non-'user' source) must NOT masquerade as user
  // input: notice form collapses to a dim one-liner, other forms render
  // dimmed — and the kind union is merge-extensible (skill-catalog etc.)
  feedA.applyEvent({ type: 'user/message', data: { content: [{ type: 'text', text: '短通知内容' }], source: { kind: 'plugin', form: 'notice', summary: '策略快照已更新' } } })
  feedA.applyEvent({ type: 'user/message', data: { content: [{ type: 'text', text: 'runtime context line1\nruntime context line2' }], source: { kind: 'plugin', form: 'snapshot' } } })
  feedA.applyEvent({ type: 'user/message', data: { content: [{ type: 'text', text: 'skills catalog body' }], source: { kind: 'skill-catalog', form: 'catalog' } } })
  await new Promise((r) => setTimeout(r, 250))
  const injectedLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  assert.ok(injectedLines.includes('· 策略快照已更新'), 'plugin notice form renders as a collapsed dim summary')
  assert.ok(injectedLines.includes('· 注入上下文'), 'plugin snapshot form renders under a context header')
  assert.ok(injectedLines.includes('· runtime context line1'), 'plugin snapshot content renders dimmed')
  assert.ok(injectedLines.includes('· skills catalog body'), 'merge-extensible kinds (skill-catalog) render dimmed too')
  assert.ok(!injectedLines.includes('> runtime context line1'), 'injected context never renders as a user bubble')
  assert.ok(!injectedLines.includes('> 策略快照已更新'), 'injected notice never renders as a user bubble')
  const injectedMarks: any[] = await nvim.request('nvim_buf_get_extmarks', [chatA.chatBuf, -1, 0, -1, { details: true }])
  const ctxRow = injectedLines.indexOf('· runtime context line1')
  const userOnCtx = injectedMarks.filter((m) => m[1] === ctxRow && m[3]?.hl_group === 'DshTuiUser')
  assert.equal(userOnCtx.length, 0, 'injected context rows carry no DshTuiUser color')
  // child→parent traffic (alpha.4 bidirectional messaging): subagent sources
  // keep their identity — a ◇ header in the subagent color + dim content rows
  feedA.applyEvent({ type: 'user/message', data: { content: [{ type: 'text', text: '我改好了 src/x.ts，加了一个函数' }], source: { kind: 'agent-message', senderSessionId: 'child-session-12345678' } } })
  feedA.applyEvent({ type: 'user/message', data: { content: [{ type: 'text', text: 'Background subagent child-1 finished.\nIts closing message:\n已完成修改' }], source: { kind: 'subagent-settled', form: 'notice', summary: 'Background subagent child-1 finished.', senderSessionId: 'child-1' } } })
  // fence safety: a child message carrying a fence marker must be prefix-
  // neutralized ('· ```') — it can never toggle the view fence state
  feedA.applyEvent({ type: 'user/message', data: { content: [{ type: 'text', text: '看这段：\n```\n不会被当成围栏\n' }], source: { kind: 'agent-message', senderSessionId: 'child-fence' } } })
  feedA.applyEvent({ type: 'assistant/chunk', data: { chunk: { type: 'text-delta', text: '围栏之后仍是普通文本\n' } } })
  await new Promise((r) => setTimeout(r, 250))
  const childLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  assert.ok(childLines.includes('◇ 子代理 child-se → 本会话'), 'child agent-message renders a subagent header')
  assert.ok(childLines.includes('· 我改好了 src/x.ts，加了一个函数'), 'child message content renders dimmed under the header')
  assert.ok(childLines.includes('◇ 子代理已结束 · Background subagent child-1 finished.'), 'settlement notice renders a subagent summary row')
  assert.ok(childLines.includes('· 已完成修改'), 'settlement closing message renders dimmed (summary first line deduped)')
  assert.equal(childLines.filter((l: string) => l === '· Background subagent child-1 finished.').length, 0, 'settlement summary renders once (no duplicated content line)')
  assert.ok(childLines.includes('· 不会被当成围栏'), 'child fence line renders as dim content, never a fence marker')
  assert.ok(childLines.includes('· ```'), 'child fence marker keeps its visible but neutralized form')
  const childMarks: any[] = await nvim.request('nvim_buf_get_extmarks', [chatA.chatBuf, -1, 0, -1, { details: true }])
  const childHeaderRow = childLines.indexOf('◇ 子代理 child-se → 本会话')
  const subOnHeader = childMarks.filter((m) => m[1] === childHeaderRow && m[3]?.hl_group === 'DshTuiSubagent')
  assert.ok(subOnHeader.length > 0, 'child message header carries the DshTuiSubagent highlight')
  const userOnChild = childMarks.filter((m) => m[1] === childHeaderRow && m[3]?.hl_group === 'DshTuiUser')
  assert.equal(userOnChild.length, 0, 'child message rows never carry DshTuiUser')
  const afterFenceTextRow = childLines.indexOf('围栏之后仍是普通文本')
  const codeOnAfter = childMarks.filter((m) => m[1] === afterFenceTextRow && m[3]?.hl_group === 'DshTuiCode')
  assert.equal(codeOnAfter.length, 0, 'child fence line must not leak code color below the block')
  // an interrupted turn commits its prefix + a visible marker
  feedA.applyEvent({ type: 'assistant/message', data: { turn: 1, step: 1, message: { content: [{ type: 'text', text: '被打断的前缀' }] }, interrupted: true } })
  await new Promise((r) => setTimeout(r, 250))
  const interruptedLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  assert.ok(interruptedLines.includes('⚠ 回合被中断'), 'interrupted turn renders a visible marker')
  // stray '- ' bullets in ordinary content must NOT render as diff rows
  const bulletStart = await nvim.request('nvim_buf_line_count', [chatA.chatBuf])
  feedA.applyEvent({ type: 'assistant/chunk', data: { chunk: { type: 'text-delta', text: '要点如下：\n- 第一点\n- 第二点\n+ 并不是 diff 的行\n' } } })
  await new Promise((r) => setTimeout(r, 250))
  const bulletMarks: any[] = await nvim.request('nvim_buf_get_extmarks', [chatA.chatBuf, -1, 0, -1, { details: true }])
  const diffStyled = bulletMarks.filter((m) => m[1] >= bulletStart - 1 &&
    (m[3]?.hl_group === 'DshTuiDiffAdd' || m[3]?.hl_group === 'DshTuiDiffDel'))
  assert.equal(diffStyled.length, 0, 'plain +/- bullets outside a diff region get no diff styling')
  // diff blocks always render in the CHAT — even when the session has a
  // reasoning panel buffer (the panel stays the compact activity log)
  const rbuf = await lua('return require("dsh_tui").ensure_reasoning(...)', ['session-aaaa'])
  const freshChatBuf = await lua('return vim.api.nvim_create_buf(false, true)', [])
  const panelFeed = new FeedRenderer(nvim, freshChatBuf, chatA.chatWin, { reasoningBuf: rbuf.reasoningBuf })
  panelFeed.pushDiff('✎ 修改 src/y.ts (+1 −0)', ['+ only added'])
  await new Promise((r) => setTimeout(r, 300))
  const chatAfterPanel = await nvim.request('nvim_buf_get_lines', [freshChatBuf, 0, -1, false])
  assert.ok(chatAfterPanel.includes('✎ 修改 src/y.ts (+1 −0)'), 'diff renders into the chat even with a panel buffer')
  const panelAfterPanel = await nvim.request('nvim_buf_get_lines', [rbuf.reasoningBuf, 0, -1, false])
  assert.ok(!panelAfterPanel.includes('✎ 修改 src/y.ts (+1 −0)'), 'diff stays out of the reasoning panel')
  // [a] 总是（自动模式）: routes 'always' (the runner then allows this once
  // and switches the session approval policy to 'never').
  await lua('require("dsh_tui").show_approval(...)', [{ toolName: 'bash', reason: 'again' }])
  const approvalMaps = await lua(`local out = {}
    for _, m in ipairs(vim.api.nvim_buf_get_keymap(require("dsh_tui")._float.buf, "n")) do
      table.insert(out, m.lhs)
    end
    return out`, [])
  assert.ok(approvalMaps.includes('a'), 'approval popup maps the always key')
  await lua('require("dsh_tui").approval_decide("always")', [])
  const alwaysDeadline = Date.now() + 2000
  let alwaysHit: { args?: unknown[] } | null = null
  while (Date.now() < alwaysDeadline) {
    const decisions = notes.filter((n) => n.method === 'dsh-approval-decided')
    const last = decisions[decisions.length - 1]
    if (last?.args?.[0] === 'always') { alwaysHit = last; break }
    await new Promise((r) => setTimeout(r, 20))
  }
  assert.ok(alwaysHit !== null, 'always decision routed for the automatic-mode switch')

  // 9d. questions flow (two questions, second multi-select) — the float must
  // grow to the real content height, or the option list and the key-hint
  // footer stay clipped (window was created with a 1-line placeholder).
  await lua(`require("dsh_tui").show_questions({
    { id = "q1", question = "方向？", options = { { label = "A", description = "方案A" }, { label = "B" } } },
    { id = "q2", question = "特性？", multiSelect = true, options = { { label = "x" }, { label = "y" } } },
  })`, [])
  let qfloat = await lua('return require("dsh_tui")._float', [])
  let qcfg = await nvim.request('nvim_win_get_config', [qfloat.win])
  let qlines = await nvim.request('nvim_buf_get_lines', [qfloat.buf, 0, -1, false])
  log('questions cfg:', JSON.stringify(qcfg), 'lines:', qlines.length)
  assert.ok(qcfg.height >= qlines.length, 'questions window fits all rows incl. key hints')
  await assertFooter('[Enter]', 'questions')
  await assertCentered('require("dsh_tui")._float.win', 'questions')
  await lua('require("dsh_tui").question_move(1)', []) // q1 → option B
  await lua('require("dsh_tui").question_advance()', []) // q1 done → q2
  await lua('require("dsh_tui").question_toggle()', []) // q2 toggle x
  await lua('require("dsh_tui")._float.state.custom["q2"] = "自定义反馈"', [])
  await lua('require("dsh_tui").redraw_questions()', [])
  qlines = await nvim.request('nvim_buf_get_lines', [qfloat.buf, 0, -1, false])
  assert.ok(qlines.some((l: string) => l.includes('自定义: 自定义反馈')), 'custom answer is visible in the question float')
  await assertFooter('[C-e]', 'questions')
  await lua('require("dsh_tui").question_advance()', []) // confirm
  hit = await waitNote('dsh-questions-answered')
  const answers = (hit?.args?.[0] ?? []) as Array<{ selected?: string[]; custom?: string }>
  log('answers:', JSON.stringify(answers))
  assert.equal(answers[0]?.selected?.[0], 'B', 'single-select answer')
  assert.deepEqual(answers[1]?.selected, ['x'], 'multi-select answer')
  assert.equal(answers[1]?.custom, '自定义反馈', 'custom free-text answer is included')

  // 9e. picker
  await lua(`require("dsh_tui").show_picker("选择", { { label = "m1", value = "model-a" }, { label = "m2", value = "model-b" } })`, [])
  // Hints live in a footer bar OUTSIDE and below the window (always visible
  // while scrolling), the function title rides the border title, and the
  // width adapts to the longest row instead of a fixed 72.
  let pickerBuf = await lua('return require("dsh_tui")._float.buf', [])
  const pickerLines = await nvim.request('nvim_buf_get_lines', [pickerBuf, 0, -1, false])
  assert.deepEqual(pickerLines, ['m1', 'm2'], 'picker buffer holds the items only')
  assert.equal(await lua('return vim.api.nvim_win_get_height(require("dsh_tui")._float.win)', []), pickerLines.length, 'picker window exactly fits content (no gap below)')
  assert.ok(String(await floatTitle(await lua('return require("dsh_tui")._float.win', []))).includes('选择'), 'picker float carries a function title')
  await assertFooter('[j/k]', 'picker')
  await assertCentered('require("dsh_tui")._float.win', 'picker')
  // LIVE picker: update_picker re-renders the open float in place
  await lua(`require("dsh_tui").update_picker({ { label = "m1", value = "model-a" }, { label = "m2", value = "model-b" }, { label = "m3", value = "model-c" } })`, [])
  const pickerLines2 = await nvim.request('nvim_buf_get_lines', [pickerBuf, 0, -1, false])
  assert.deepEqual(pickerLines2, ['m1', 'm2', 'm3'], 'update_picker replaces the open picker rows')
  assert.equal(await lua('return vim.api.nvim_win_get_height(require("dsh_tui")._float.win)', []), 3, 'picker window resizes to the new row count')
  assert.ok(await lua('return vim.api.nvim_win_is_valid(require("dsh_tui")._float.win)', []), 'float stays open across the update')
  // shrink below the cursor row → cursor clamps
  await lua('vim.api.nvim_win_set_cursor(require("dsh_tui")._float.win, { 3, 0 })', [])
  await lua(`require("dsh_tui").update_picker({ { label = "m1", value = "model-a" } })`, [])
  assert.equal(await lua('return vim.api.nvim_win_get_cursor(require("dsh_tui")._float.win)[1]', []), 1, 'cursor clamps when the list shrinks')
  // confirm returns the NEW value mapping (rpcnotify dsh-picker-selected);
  // consume the note so the later routing assertion sees its own
  await lua(`require("dsh_tui").picker_confirm()`, [])
  assert.equal(await lua('return require("dsh_tui")._float.win', []), null, 'confirm closes the live picker')
  const liveHit = await waitNote('dsh-picker-selected')
  assert.equal(liveHit?.args?.[0], 'model-a', 'live picker settles with the updated value')
  // no-op when no picker is open
  await lua(`require("dsh_tui").update_picker({ { label = "x", value = "y" } })`, [])
  // reopen the original picker so the following read-only-lock/keymap
  // assertions still have a live float
  await lua('require("dsh_tui").show_picker(...)', ['选择', [{ label: 'm1', value: 'model-a' }, { label: 'm2', value: 'model-b' }]])
  pickerBuf = await lua('return require("dsh_tui")._float.buf', [])

  // Read-only lock: i must not enter insert mode, x/dd must not delete.
  const pickerMaps = await lua(`local out = {}
    for _, m in ipairs(vim.api.nvim_buf_get_keymap(require("dsh_tui")._float.buf, "n")) do
      table.insert(out, { lhs = m.lhs, rhs = m.rhs or "" })
    end
    return out`, [])
  const pickerKey = (k: string) => pickerMaps.find((m: any) => m.lhs === k)
  assert.ok(pickerKey('i') && pickerKey('i').rhs !== 'i', 'picker i is Nop (no insert mode)')
  assert.ok(pickerKey('d') && pickerKey('x') && pickerKey(':'), 'picker edit keys Nop')
  assert.equal(await lua('return vim.bo[require("dsh_tui")._float.buf].modifiable', []), false, 'picker buffer is not modifiable')
  await nvim.input('i')
  assert.equal((await nvim.request('nvim_get_mode', [])).mode, 'n', 'i does not enter insert mode in the picker')
  await nvim.input('xdd')
  assert.deepEqual(await nvim.request('nvim_buf_get_lines', [pickerBuf, 0, -1, false]), pickerLines, 'x/dd cannot delete picker content')
  // Plain buffer: every entry is a real line, so nvim's own navigation keys
  // work — G must reach the LAST ENTRY, and the window caps at 22 rows on a
  // tall editor.
  await lua('require("dsh_tui").picker_cancel()', [])
  const uiClient = await connectNvim(sockPath)
  await uiClient.uiAttach(80, 50, {})
  await new Promise((r) => setTimeout(r, 50))
  const many = Array.from({ length: 30 }, (_, i) => ({ label: 'item-' + i, value: 'v' + i }))
  await lua('require("dsh_tui").show_picker(...)', ['长列表', many])
  const pickerCfg = await nvim.request('nvim_win_get_config', [(await lua('return require("dsh_tui")._float.win', []))])
  assert.ok(pickerCfg.width >= 72, 'picker width at least the default')
  pickerBuf = await lua('return require("dsh_tui")._float.buf', [])
  const longLines = await nvim.request('nvim_buf_get_lines', [pickerBuf, 0, -1, false])
  assert.equal(longLines.length, 30, 'all 30 entries are real buffer lines')
  assert.equal(await lua('return vim.api.nvim_win_get_height(require("dsh_tui")._float.win)', []), 22, 'long picker window caps at the slice cap')
  await assertFooter('[j/k]', 'long picker')
  // shift+G (nvim's own jump-to-bottom) must land on the last entry.
  await nvim.input('G')
  let pickerCursor = await lua('return vim.api.nvim_win_get_cursor(require("dsh_tui")._float.win)', [])
  assert.deepEqual(pickerCursor, [30, 0], 'G jumps to the last entry')
  await assertFooter('[j/k]', 'long picker after G')
  await nvim.input('gg')
  pickerCursor = await lua('return vim.api.nvim_win_get_cursor(require("dsh_tui")._float.win)', [])
  assert.deepEqual(pickerCursor, [1, 0], 'gg jumps to the first entry')
  for (let i = 0; i < 30; i++) await lua('require("dsh_tui").picker_move(1)', [])
  pickerCursor = await lua('return vim.api.nvim_win_get_cursor(require("dsh_tui")._float.win)', [])
  assert.deepEqual(pickerCursor, [30, 0], 'cursor clamps at the last entry')
  await uiClient.uiTryResize(80, 24)
  await lua('require("dsh_tui").picker_cancel()', [])
  await lua('require("dsh_tui").show_picker(...)', ['宽', [{ label: 'x'.repeat(100), value: 'long' }]])
  const longCfg = await nvim.request('nvim_win_get_config', [(await lua('return require("dsh_tui")._float.win', []))])
  const cols = await lua('return vim.o.columns', [])
  assert.ok(longCfg.width === Math.min(Math.max(72, 102), Math.max(40, cols - 4)), 'picker width adapts to the longest row (clamped to the editor)')
  await lua('require("dsh_tui").picker_cancel()', [])
  await lua(`require("dsh_tui").show_picker("选择", { { label = "m1", value = "model-a" }, { label = "m2", value = "model-b" } })`, [])
  // Interactive floats must hand over in NORMAL mode (the input window is in
  // insert mode when the command fires): <CR> selects, it must not type a
  // newline into the picker buffer.
  await assertModeN('picker opens in normal mode')
  await lua('require("dsh_tui").picker_move(1)', [])
  await lua('require("dsh_tui").picker_confirm()', [])
  hit = await waitNote('dsh-picker-selected')
  assert.equal(hit?.args?.[0], 'model-b', 'picker selection routed')

  // 9f. subagent transcript view: read-only float + FeedRenderer replay
  // (方案 B: /subagents → child log replay, reasoning inline and dim).
  const svIds = await lua('return require("dsh_tui").open_subagent_view(...)', ['deepseek-code'])
  assert.ok(Number.isInteger(svIds.buf) && Number.isInteger(svIds.win), 'subagent view opens with buf+win')
  await assertModeN('subagent view opens in normal mode')
  // Same popup logic as /sessions: footer hint bar below the window,
  // G/gg jumps, content-fitted height that grows with the replay.
  await assertFooter('[q]', 'subagent view')
  await assertCentered('require("dsh_tui")._subagentView.win', 'subagent view')
  const svMaps = await lua(`local out = {}
    for _, m in ipairs(vim.api.nvim_buf_get_keymap(${svIds.buf}, "n")) do
      table.insert(out, { lhs = m.lhs, rhs = m.rhs or "" })
    end
    return out`, [])
  const svKey = (k: string) => svMaps.find((m: any) => m.lhs === k)
  assert.ok(svKey('q'), 'q closes the subagent view')
  assert.ok(svKey('<Esc>'), 'Esc closes the subagent view')
  assert.ok(svKey('G') && svKey('gg'), 'G/gg jump keys mapped like sessions')
  // <Nop> maps are stored with an empty rhs.
  assert.ok(svKey('i') && svKey('i').rhs === '', 'insert key Nop (read-only)')
  assert.ok(svKey(':') && svKey(':').rhs === '', 'colon Nop (read-only)')
  const subFeed = new FeedRenderer(nvim, svIds.buf, svIds.win, {
    idsProvider: async () => lua('return require("dsh_tui").subagent_view_ids()', []),
    activeChecker: () => true,
    reasoningBuf: null,
    reasoningView: () => null,
    inlineReasoning: true,
  })
  subFeed.applyEvent({ type: 'turn/start', time: 1000, data: {} })
  subFeed.applyEvent({ type: 'assistant/chunk', time: 1100, data: { chunk: { type: 'reasoning-delta', text: '子代理思考：先查目录' } } })
  // The thinking text must stream inline WHILE it is being generated
  // (regression: only the compact header rendered during streaming and the
  // whole block landed in one shot when thinking closed).
  await subFeed.flush()
  const svLive = await nvim.request('nvim_buf_get_lines', [svIds.buf, 0, -1, false])
  log('subagent view live thinking:', JSON.stringify(svLive))
  assert.ok(svLive.some((l: string) => l.includes('子代理思考：先查目录')), 'reasoning text streams inline while thinking')
  assert.ok(svLive.some((l: string) => /^·· thinking · \d+\.\d+s$/.test(l)), 'thinking header renders during streaming')
  subFeed.applyEvent({ type: 'assistant/chunk', time: 1150, data: { chunk: { type: 'reasoning-delta', text: '\n再查一下配置' } } })
  await subFeed.flush()
  const svLive2 = await nvim.request('nvim_buf_get_lines', [svIds.buf, 0, -1, false])
  assert.ok(svLive2.includes('再查一下配置'), 'growing reasoning tail keeps streaming inline')
  subFeed.applyEvent({ type: 'tool/call', time: 1200, data: { callId: 'sc-1', name: 'bash', arguments: '{"cmd":"ls"}' } })
  subFeed.applyEvent({ type: 'tool/result', time: 1300, data: { message: { content: [{ type: 'text', text: 'a.txt' }], source: { callId: 'sc-1' } } } })
  subFeed.applyEvent({ type: 'assistant/chunk', time: 1400, data: { chunk: { type: 'text-delta', text: '子代理结论 OK' } } })
  subFeed.applyEvent({ type: 'turn/end', time: 1500, data: {} })
  await subFeed.flush()
  const svLines = await nvim.request('nvim_buf_get_lines', [svIds.buf, 0, -1, false])
  log('subagent view lines:', JSON.stringify(svLines))
  assert.ok(svLines.some((l: string) => l.includes('子代理思考：先查目录')), 'reasoning rendered inline in subagent view')
  assert.ok(svLines.some((l: string) => l.startsWith('·· thinking')), 'thinking header rendered inline')
  assert.ok(svLines.some((l: string) => l.startsWith('🔧 bash(')), 'tool card rendered')
  assert.ok(svLines.some((l: string) => l.startsWith('✓ bash')), 'tool result rendered')
  assert.ok(svLines.some((l: string) => l.includes('子代理结论 OK')), 'assistant text rendered')
  // The window grew with the replay (deferred resize via on_lines): height
  // equals the transcript line count and the footer stays anchored below.
  await new Promise((r) => setTimeout(r, 120))
  assert.equal(await lua('return vim.api.nvim_win_get_height(require("dsh_tui")._subagentView.win)', []), svLines.length, 'subagent view height fits the replayed content')
  await assertFooter('[q]', 'subagent view after replay')
  const svReasoningMark = (await nvim.request('nvim_buf_get_extmarks', [svIds.buf, -1, 0, -1, { details: true }]))
    .filter((m: any) => m[3]?.hl_group === 'DshTuiReasoning')
  assert.ok(svReasoningMark.length > 0, 'reasoning header dim-marked in view')
  // Settled replays land on the first thinking block (not the transcript tail).
  const gotoRow = await lua('return require("dsh_tui").subagent_view_goto_thinking()', [])
  const svCursor = await nvim.request('nvim_win_get_cursor', [svIds.win])
  assert.equal(svCursor[0], gotoRow, 'view cursor lands on the thinking block')
  assert.ok((svLines[gotoRow - 1] ?? '').startsWith('·· thinking'), 'landing row is the thinking header')
  const idsBeforeClose = await lua('return require("dsh_tui").subagent_view_ids()', [])
  assert.ok(idsBeforeClose && idsBeforeClose.buf === svIds.buf, 'subagent_view_ids reports open view')
  await lua('require("dsh_tui").close_subagent_view()', [])
  hit = await waitNote('dsh-subagent-view-closed')
  assert.ok(hit, 'close notifies the runner (dsh-subagent-view-closed)')
  const idsAfterClose = await lua('return require("dsh_tui").subagent_view_ids()', [])
  assert.equal(idsAfterClose, null, 'view ids cleared after close')
  // Re-open after close must work (regression: the first view's buffer
  // survived the close and the second open collided on the buffer name →
  // E95, leaving the picker Enter with no visible effect).
  const svIds2 = await lua('return require("dsh_tui").open_subagent_view(...)', ['deepseek-code'])
  assert.ok(Number.isInteger(svIds2.buf) && Number.isInteger(svIds2.win), 'subagent view re-opens after close')
  assert.notEqual(svIds2.buf, svIds.buf, 're-open gets a fresh buffer')
  assert.equal(await lua('return vim.api.nvim_buf_is_valid(...)', [svIds.buf]), false, 'old view buffer wiped on close')
  await lua('require("dsh_tui").close_subagent_view()', [])
  await waitNote('dsh-subagent-view-closed')

  // 9f3. subagent CHAT window: transcript float + editable input row — the
  // user chats with a continuable child like with the main agent (Enter
  // sends through 'dsh-subagent-send', the transcript streams into the
  // upper feed).
  const scIds = await lua('return require("dsh_tui").open_subagent_chat(...)', ['audit-child'])
  assert.ok(Number.isInteger(scIds.buf) && Number.isInteger(scIds.win) &&
    Number.isInteger(scIds.inputBuf) && Number.isInteger(scIds.inputWin),
  'chat opens with transcript + input ids')
  // The chat input lands in insert mode; window/autocmd settling may take a
  // tick or two in headless (WinEnter/InsertEnter handlers), so poll briefly.
  let chatMode = (await nvim.request('nvim_get_mode', [])).mode
  for (let i = 0; i < 20 && chatMode !== 'i'; i++) {
    await new Promise((r) => setTimeout(r, 50))
    chatMode = (await nvim.request('nvim_get_mode', [])).mode
  }
  assert.equal(chatMode, 'i', 'chat input opens in insert mode')
  // The input float sits directly under the transcript float (same col/width),
  // carries its own rounded border (one continuous framed chat box), and the
  // operation hints live in the INPUT's bottom border.
  const scCfg = await nvim.request('nvim_win_get_config', [scIds.win])
  const scICfg = await nvim.request('nvim_win_get_config', [scIds.inputWin])
  assert.equal(scICfg.row, scCfg.row + scCfg.height + 2, 'input float sits right below the transcript')
  assert.equal(scICfg.col, scCfg.col, 'input float aligns with the transcript column')
  assert.equal(scICfg.width, scCfg.width, 'input float spans the transcript width')
  assert.notEqual(scICfg.border, 'none', 'input float carries a rounded border')
  assert.notEqual(scCfg.border, 'none', 'transcript float carries a rounded border')
  if (await lua('return vim.fn.has("nvim-0.10") == 1', [])) {
    assert.ok(String(scICfg.footer).includes('Enter'), 'input bottom border carries the send hints')
  }
  const scInputMaps = await lua(`local out = {}
    for _, m in ipairs(vim.api.nvim_buf_get_keymap(${scIds.inputBuf}, "i")) do
      table.insert(out, { lhs = m.lhs, rhs = m.rhs or "" })
    end
    return out`, [])
  const scKey = (k: string) => scInputMaps.find((m: any) => m.lhs === k)
  assert.ok(scKey('<CR>') && String(scKey('<CR>').rhs).includes('subagent_chat_submit'), 'Enter submits the chat input')
  assert.ok(scKey('<Esc>') && String(scKey('<Esc>').rhs).includes('close_subagent_chat'), 'Esc closes the chat window')
  assert.ok(scKey('<C-CR>'), 'C-CR inserts a literal newline')
  assert.ok(scKey('<Up>') && scKey('<Down>'), 'Up/Down history keys mapped')
  // The runner's FeedRenderer writes the child transcript into the upper buf.
  const scFeed = new FeedRenderer(nvim, scIds.buf, scIds.win, {
    idsProvider: async () => lua('return require("dsh_tui").subagent_chat_ids()', []),
    activeChecker: () => true,
    reasoningBuf: null,
    reasoningView: () => null,
    inlineReasoning: true,
  })
  scFeed.applyEvent({ type: 'turn/start', time: 2000, data: {} })
  scFeed.applyEvent({ type: 'assistant/chunk', time: 2100, data: { chunk: { type: 'text-delta', text: '子代理回复内容' } } })
  scFeed.applyEvent({ type: 'turn/end', time: 2200, data: {} })
  await scFeed.flush()
  const scLines = await nvim.request('nvim_buf_get_lines', [scIds.buf, 0, -1, false])
  assert.ok(scLines.some((l: string) => l.includes('子代理回复内容')), 'child transcript renders into the chat window')
  const scIdsLive = await lua('return require("dsh_tui").subagent_chat_ids()', [])
  assert.ok(scIdsLive && scIdsLive.buf === scIds.buf, 'subagent_chat_ids reports the open window')
  // Submit routes the text to the runner as 'dsh-subagent-send'.
  await lua('vim.api.nvim_buf_set_lines(...)', [scIds.inputBuf, 0, -1, false, ['帮我再检查一遍']])
  await lua('require("dsh_tui").subagent_chat_submit()', [])
  hit = await waitNote('dsh-subagent-send')
  assert.equal(hit?.args?.[0], '帮我再检查一遍', 'submit routes the text to the runner')
  assert.deepEqual(await nvim.request('nvim_buf_get_lines', [scIds.inputBuf, 0, -1, false]), [''], 'chat input resets after submit')
  // Multi-line input grows the input float and shrinks the transcript so
  // the composite block keeps one constant footprint.
  const chatH1 = await lua('return vim.api.nvim_win_get_height(require("dsh_tui")._subagentChat.win)', [])
  await lua('vim.api.nvim_buf_set_lines(...)', [scIds.inputBuf, 0, -1, false, ['第一行', '第二行', '第三行']])
  await lua('require("dsh_tui").subagent_chat_resize()', [])
  assert.equal(await lua('return vim.api.nvim_win_get_height(require("dsh_tui")._subagentChat.inputWin)', []), 3, 'input float grows to 3 rows')
  const chatH3 = await lua('return vim.api.nvim_win_get_height(require("dsh_tui")._subagentChat.win)', [])
  assert.equal(chatH3 + 3, chatH1 + 1, 'composite footprint stays constant (transcript shrinks by the input growth)')
  // Close: windows close, buffers wipe, the runner is notified.
  await lua('require("dsh_tui").close_subagent_chat()', [])
  hit = await waitNote('dsh-subagent-chat-closed')
  assert.ok(hit, 'close notifies the runner (dsh-subagent-chat-closed)')
  assert.equal(await lua('return require("dsh_tui").subagent_chat_ids()', []), null, 'chat ids cleared after close')
  assert.equal(await lua('return vim.api.nvim_buf_is_valid(...)', [scIds.buf]), false, 'transcript buffer wiped on close')
  assert.equal(await lua('return vim.api.nvim_buf_is_valid(...)', [scIds.inputBuf]), false, 'input buffer wiped on close')
  // Mutual exclusion with the read-only view (one float family at a time).
  await lua('require("dsh_tui").open_subagent_chat(...)', ['audit-child'])
  await lua('require("dsh_tui").open_subagent_view(...)', ['deepseek-code'])
  assert.equal(await lua('return require("dsh_tui").subagent_chat_ids()', []), null, 'opening the view closes the chat window')
  await lua('require("dsh_tui").open_subagent_chat(...)', ['audit-child'])
  assert.equal(await lua('return require("dsh_tui").subagent_view_ids()', []), null, 'opening the chat closes the view')
  await lua('require("dsh_tui").close_subagent_chat()', [])
  await waitNote('dsh-subagent-chat-closed')

  // Multi-line notices must collapse to one line (an embedded newline in a
  // buffer "line" makes nvim_buf_set_lines throw E5108, which silently
  // killed the flush — regression from the E95 failure notice).
  feedB.appendNotice('第一行\n第二行\n\tstack trace')
  await new Promise((r) => setTimeout(r, 120))
  const noticeLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.ok(noticeLines.includes('· 第一行 第二行 stack trace'), 'multi-line notice collapsed to one line')
  feedB.appendNotice('still renders after')
  await new Promise((r) => setTimeout(r, 120))
  const noticeLines2 = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.ok(noticeLines2.includes('· still renders after'), 'feed keeps rendering after the collapsed notice')

  // 9g. markdown structure: headings/quotes/links parse into groups/spans;
  // user lines keep their `> ` prefix (not treated as blockquotes).
  // Duration formatting: raw milliseconds become human-readable units.
  assert.equal(formatElapsed(102510), '1m 42s', '102510ms → 1m 42s')
  assert.equal(formatElapsed(234), '234ms', 'sub-second stays in ms')
  assert.equal(formatElapsed(65000), '1m 5s', '65s → 1m 5s')
  assert.equal(formatElapsed(3600000 + 30000), '1h 0m', 'hours form')

  // 9g0. settled-chain cleanup encoder: the backend's physical format is
  // frame-per-record zstd (header line first, one JSON event per line);
  // unpacked expanded events are valid storage records.
  const hdrLine = JSON.stringify({ session: true, id: 'session-clean-test' })
  const oneFrame = zstdDecompressSync(encodeHeaderOnlyLog(hdrLine))
  assert.equal(oneFrame.toString('utf8'), hdrLine + '\n', 'header-only log re-encodes as one valid zstd frame')
  const ev = [{ seq: 0, type: 'turn/start', data: { turn: 1 } }, { seq: 1, type: 'turn/end', data: { turn: 1 } }]
  // Node's one-shot zstd decodes only the FIRST frame of a concatenated
  // stream — the host ships its own multi-frame decoder. Walk the frame
  // headers (magic + descriptor + block headers, same geometry the jsonl
  // backend's scanner uses) and decode each frame individually.
  const scanZstdFrames = (buf: Buffer): Array<[number, number]> => {
    const frames: Array<[number, number]> = []
    let offset = 0
    while (offset < buf.length) {
      const start = offset
      if (buf.readUInt32LE(offset) !== 0xfd2fb528) break
      offset += 4
      const descriptor = buf.readUInt8(offset); offset += 1
      const contentSizeFlag = descriptor >>> 6
      const singleSegment = (descriptor & 32) !== 0
      const checksum = (descriptor & 4) !== 0
      const dictionaryFlag = descriptor & 3
      offset += (dictionaryFlag === 3 ? 4 : dictionaryFlag)
      offset += contentSizeFlag === 0 ? (singleSegment ? 1 : 0) : (1 << contentSizeFlag)
      for (;;) {
        const bh = buf.readUIntLE(offset, 3); offset += 3
        const blockSize = (bh >> 3) & 0x1fffff
        offset += blockSize
        if ((bh & 1) !== 0) break // last block
      }
      if (checksum) offset += 4
      frames.push([start, offset])
    }
    return frames
  }
  const full = encodeSessionLog(hdrLine, ev)
  const zFrames = scanZstdFrames(full)
  assert.equal(zFrames.length, 3, 'header + 2 events = 3 zstd frames')
  const decoded = zFrames.map(([s, e]) => zstdDecompressSync(full.subarray(s, e)).toString('utf8'))
  assert.equal(decoded.join(''), hdrLine + '\n' + JSON.stringify(ev[0]) + '\n' + JSON.stringify(ev[1]) + '\n',
    'every frame round-trips (frame-per-record layout)')

  // 9g1. running badge: background jobs keep a live-looking statusline
  // when the agent is idle (a bare '○ idle' made users think the task died).
  assert.equal(runningBadge(true, 0, 0), '● running', 'main turn badge')
  assert.equal(runningBadge(false, 2, 0), '● running ◇2', 'subagents badge')
  assert.equal(runningBadge(false, 0, 3), '🔧 后台 3', 'background jobs keep a running badge')
  assert.equal(runningBadge(false, 0, 0), null, 'nothing running → idle')

  // 9g2. /deps helpers: patch-row parsing (comments ignored) + package probe.
  const depsPatch = path.join(os.tmpdir(), `deps-patch-${process.pid}.yml`)
  fs.writeFileSync(depsPatch, [
    '# 注释里的 id: feishu 行不能算结构行',
    '- insert:',
    '    - id: agent-presets',
    "      name: '@deepseek-ai/dsh-agent-presets'",
    '# - id: commented-out',
    '- id: session-query-sqlite',
    '  config:',
    '    openAt: first-search',
    '',
  ].join('\n'))
  const patchIds = readPatchRowIds(depsPatch)
  assert.ok(patchIds.has('agent-presets'), 'insert row id parsed')
  assert.ok(patchIds.has('session-query-sqlite'), 'override row id parsed')
  assert.ok(!patchIds.has('feishu'), 'comment mentions are not rows')
  assert.ok(!patchIds.has('commented-out'), 'commented rows are not rows')
  fs.unlinkSync(depsPatch)
  // Regression (audit F1): the old probe injected DSH_NVIM_TUI_INSTALL_ROOT,
  // i.e. it replaced the very logic under test — which is why the real
  // "every host plugin looks absent" failure shipped. Probe WITHOUT any env
  // injection, through the shared profile store (`$DSH_HOME/profiles`), the
  // root that actually holds the host plugins.
  const storeRoot = path.join(process.env['DSH_HOME'] ?? path.join(os.homedir(), '.dsh'), 'profiles')
  const hostPlugins = [
    'dsh-agent-presets',
    'dsh-workspace',
    'dsh-host-plugin-inventory',
    'dsh-message-feedback',
    'dsh-session-reference',
    'dsh-session-stats',
    'dsh-code-runtime-worker-thread',
    'dsh-tool-subagent',
    'dsh-session-query-sqlite',
  ]
  const inStore = hostPlugins.filter((p) =>
    fs.existsSync(path.join(storeRoot, 'node_modules', '@deepseek-ai', p, 'package.json')))
  if (inStore.length > 0) {
    const savedRoot = process.env['DSH_NVIM_TUI_INSTALL_ROOT']
    delete process.env['DSH_NVIM_TUI_INSTALL_ROOT']
    for (const p of inStore) {
      assert.equal(
        packageExists(`@deepseek-ai/${p}`, 'package.json'),
        true,
        `store package detected without env injection: ${p}`,
      )
    }
    assert.equal(packageExists('@deepseek-ai/dsh-not-a-real-package', 'package.json'), false, 'absent package rejected')
    if (savedRoot !== undefined) process.env['DSH_NVIM_TUI_INSTALL_ROOT'] = savedRoot
    log(`packageExists probes (no env injection): ${inStore.length}/${hostPlugins.length} store packages detected`)
  } else {
    log('skip packageExists probes (no profile store found)')
  }

  // 9f3b. 安装根候选集：dsh 自带 store 必须在内。曾经的 `dirname(dirname(dshDir))`
  // 落到 `…/lib/node_modules`，join 后成为 `…/node_modules/node_modules/…`，
  // 永远不命中；当时只因 `$DSH_HOME/profiles` store 恰好在场才蒙对。
  {
    const fakeDsh = path.join(path.sep, 'opt', 'lib', 'node_modules', '@deepseek-ai', 'dsh')
    const roots = installRootCandidates(fakeDsh)
    assert.ok(roots.includes(fakeDsh), 'dsh package dir is an install-root candidate')
    assert.ok(roots.includes(path.join(path.sep, 'opt', 'lib', 'node_modules')), '…/lib/node_modules candidate kept')
    assert.ok(roots.includes(path.join(os.homedir(), '.dsh', 'profiles')) || roots.some((r) => r.endsWith('profiles')), 'shared store candidate present')
    // 双 node_modules 是那个 off-by-one 的签名：任何候选根 join 后都不得出现。
    for (const r of roots) {
      assert.ok(!r.includes(`node_modules${path.sep}node_modules`), `no double node_modules root: ${r}`)
    }
    assert.equal(new Set(roots).size, roots.length, 'candidate roots are de-duplicated')
    log(`install root candidates: ${roots.length} distinct, dsh own store included`)
  }

  // 9g7. 会话日志健康（缺口1）。真实事故：某会话带 invalid persisted inbox
  // splice 故障，每次投影都抛，而 /sessions 只报错 —— 用户无法判断「日志完好、
  // 单条信封坏了」还是「这个会话废了」。这里把它分开，并点名是哪个会话。
  {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-health-'))
    // ok: 可解压的日志
    const okDir = path.join(tmp, 'sess-ok')
    fs.mkdirSync(okDir)
    fs.writeFileSync(path.join(okDir, 'session.v3.jsonl.zstd'), zstdCompressSync(Buffer.from('{"a":1}\n')))
    // faulted: 日志完好但旁边有 host 留下的 .corrupt-backup —— 唯一的事故痕迹
    const faultDir = path.join(tmp, 'sess-fault')
    fs.mkdirSync(faultDir)
    fs.writeFileSync(path.join(faultDir, 'session.v3.jsonl.zstd'), zstdCompressSync(Buffer.from('{"b":2}\n')))
    fs.writeFileSync(path.join(faultDir, 'session.jsonl.zstd.corrupt-backup'), Buffer.from('x'))
    // torn: 只有魔数、解压不出来的写坏文件
    const tornDir = path.join(tmp, 'sess-torn')
    fs.mkdirSync(tornDir)
    fs.writeFileSync(path.join(tornDir, 'session.v3.jsonl.zstd'), Buffer.from([0x28, 0xb5, 0x2f, 0xfd, 0x00, 0x01]))

    const hOk = checkSessionLog(okDir)
    assert.equal(hOk.status, 'ok', 'readable log → ok')
    assert.equal(hOk.hadFault, false, 'no backup sibling → no fault flag')
    const hFault = checkSessionLog(faultDir)
    assert.equal(hFault.status, 'ok', "a faulted session's log still decompresses")
    assert.equal(hFault.hadFault, true, 'the .corrupt-backup sibling is what flags the fault')
    // 实测：截断的帧带有效魔数，解压**返回空**而不是抛错 —— 所以 torn 落成
    // `empty`。这正是「只查魔数会误判为正常」的原因。
    assert.equal(checkSessionLog(tornDir).status, 'empty', 'torn write keeps a valid header; decompression yields empty and is reported as such')
    assert.equal(checkSessionLog(path.join(tmp, 'missing')).status, 'unreadable', 'missing dir → unreadable (never throws)')

    const lines = sessionHealthLines([okDir, faultDir, tornDir], 10).join('\n')
    assert.ok(lines.includes('已检查 3 / 3 个会话目录'), 'scan summary present')
    assert.ok(lines.includes('sess-torn'), 'unreadable session is named')
    assert.ok(lines.includes('sess-fault'), 'faulted session is named')
    assert.ok(lines.includes('invalid persisted inbox splice'), 'repair guidance names the real error')
    assert.doesNotThrow(() => sessionHealthLines([], 10), 'empty session list does not throw')
    fs.rmSync(tmp, { recursive: true, force: true })
  }

  // 9g8. 审批历史「落盘」回归（真 bug）：approvalHistory 原先只在内存里，
  // 重启后 /approvals 空白 —— 而"我当时为什么允许了那个操作"恰恰多是事后问的。
  // 作用域是**单会话**：/approvals 回答的是"这次对话放行了什么"，混入别的会话
  // 的决定会误导（别处的拒绝说明不了这里）。
  {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-approvals-'))
    const prevHome = process.env['DSH_HOME']
    process.env['DSH_HOME'] = tmp
    const rec = (over: Record<string, unknown>) => ({ at: Date.now(), toolName: 'bash', reason: '', outcome: 'allow', sessionId: 's', ...over })

    assert.equal(approvalLogPath('sess-a'), path.join(tmp, 'approvals', 'sess-a.jsonl'), 'one file per session under DSH_HOME')
    assert.equal(approvalLogPath(undefined), '', 'no session → no path (never writes)')
    assert.deepEqual(loadApprovalHistory('sess-a'), [], 'no file yet → empty history (never throws)')

    appendApproval('sess-a', rec({ outcome: 'allow', toolName: 'read' }))
    appendApproval('sess-a', rec({ outcome: 'reject', toolName: 'write', reason: '改系统文件' }))
    // 关键断言：模拟"重启" —— 新建的读取者必须看到刚才写下的记录。
    const afterRestart = loadApprovalHistory('sess-a')
    assert.equal(afterRestart.length, 2, 'decisions survive a restart (read back from disk)')
    assert.equal(afterRestart[1]?.outcome, 'reject', 'newest decision is last')
    assert.equal(afterRestart[1]?.reason, '改系统文件', 'reason persisted')

    // 会话隔离：另一个会话看不到这里的决定。
    appendApproval('sess-b', rec({ outcome: 'allow', toolName: 'other' }))
    assert.equal(loadApprovalHistory('sess-a').length, 2, 'session A is not polluted by session B')
    assert.equal(loadApprovalHistory('sess-b').length, 1, 'session B sees only its own')

    // 切换会话时的惰性重载（读写两条路径都走 ensure）。
    const slices = { approvalHistory: [] as ReturnType<typeof loadApprovalHistory>, approvalHistoryFor: null as string | null }
    assert.equal(ensureApprovalHistory(slices, 'sess-a').length, 2, 'ensure loads the active session')
    assert.equal(ensureApprovalHistory(slices, 'sess-b').length, 1, 'ensure swaps when the session changes')
    assert.equal(slices.approvalHistoryFor, 'sess-b', 'marker tracks which session is loaded')
    assert.equal(ensureApprovalHistory(slices, 'sess-b').length, 1, 'same session → no reload')
    assert.equal(ensureApprovalHistory(slices, null).length, 0, 'no active session → empty, not stale')

    // JSONL 必须紧凑：一行一条，多行会破坏逐行语义。
    const body = fs.readFileSync(approvalLogPath('sess-a'), 'utf8')
    assert.equal(body.split('\n').filter((l) => l !== '').length, 2, 'one compact JSON object per line')
    assert.ok(!body.includes('\n  '), 'never pretty-printed')

    // 容错：半行（进程在 append 途中死掉）不得让整份历史读不出来。
    fs.appendFileSync(approvalLogPath('sess-a'), '{"at":123,"outcome":"all')
    assert.equal(loadApprovalHistory('sess-a').length, 2, 'a torn last line is skipped, the rest survives')
    assert.equal(parseApprovalLines('not json\n{"at":1,"outcome":"allow"}\n').length, 1, 'garbage lines dropped')

    // 有界：超过上限后压实到上限以内。
    for (let i = 0; i < APPROVAL_LOG_MAX + 20; i++) appendApproval('sess-a', rec({ outcome: 'allow', toolName: `t${i}` }))
    const lines = fs.readFileSync(approvalLogPath('sess-a'), 'utf8').split('\n').filter((l) => l !== '').length
    assert.ok(lines <= APPROVAL_LOG_MAX, `log is compacted (${lines} <= ${APPROVAL_LOG_MAX})`)

    if (prevHome === undefined) delete process.env['DSH_HOME']
    else process.env['DSH_HOME'] = prevHome
    fs.rmSync(tmp, { recursive: true, force: true })
  }

  // 9g6. 从转录行跳转到文件（缺口4）。解析要认识 TUI 自己的行形态，且不能把
  // 行文里的普通词当成路径；纯函数，故可穷举边界。
  {
    // NOTE: no pcall inside the probe — lua() already unwraps the return value,
    // so `pcall` would hand back the status BOOLEAN and every compare would be
    // against `true`. A refusal is just a nil return.
    const p = async (line: string): Promise<unknown> => await lua('return require("dsh_tui.goto_file").path_from_line(...)', [line])
    assert.equal(await p('✎ 修改 README.md (+1 −0)'), 'README.md', 'change card → path')
    assert.equal(await p('🔧 read({"file_path":"src/feed/feed.ts"})'), 'src/feed/feed.ts', 'tool card → nested path')
    assert.equal(await p('  ✓ edit · src/kernel/app.ts'), null, '✓ rows are the todo list → skipped (documented limit)')
    assert.equal(await p('这个改动影响 a/b/c.lua 的行为'), 'a/b/c.lua', 'path embedded in prose')
    assert.equal(await p('> 为什么改了 README.md'), null, 'user echo is chrome → ignored')
    assert.equal(await p('· 注入上下文 src/x.ts'), null, 'injected context is chrome → ignored')
    assert.equal(await p('── turn ──'), null, 'turn rule → ignored')
    assert.equal(await p('没有文件的普通一句话'), null, 'no extension → ignored')
    assert.equal(await p('看到 https://example.com 但那是网址'), null, 'bare host without path → ignored')
    assert.equal(await p('引用了 ../../etc/passwd 这种越界路径'), null, 'parent traversal → refused')
    const l = async (line: string): Promise<unknown> => await lua('return require("dsh_tui.goto_file").line_from_line(...)', [line])
    assert.equal(await l('src/a.ts:42'), 42, ':LINE hint parsed')
    assert.equal(await l('src/a.ts:42:7'), 42, ':LINE:COL hint parsed')
    assert.equal(await l('src/a.ts'), null, 'no hint → nil')
  }

  // 9g5. 审批历史（缺口6）：审批浮窗与转录通知都是瞬时的，事后无从回答
  // 「我当时为什么允许了那个操作」—— 这份有界日志是唯一的记录。
  {
    const rec = (over: Partial<{ at: number; toolName: string; reason: string; outcome: string }>) => ({
      at: Date.parse('2026-09-16T10:20:30'), toolName: 'bash', reason: '', outcome: 'allow', sessionId: 's', ...over,
    })
    const lines = approvalHistoryLines([
      rec({ outcome: 'allow' }),
      rec({ outcome: 'reject', toolName: 'write', reason: '改系统文件' }),
    ], 50)
    const body = lines.join('\n')
    assert.ok(body.includes('✓ 10:20:30  bash'), 'allowed decision renders with ✓, time and tool')
    assert.ok(body.includes('✗ 10:20:30  write — 改系统文件'), 'rejected decision renders with reason')
    // 最新在前：刚做的决定最可能是你要查的那条。
    const iReject = body.indexOf('write')
    const iAllow = body.indexOf('bash')
    assert.ok(iReject >= 0 && iAllow > iReject, 'newest decision is listed first')
    assert.ok(body.includes('共 2 条'), 'count line present')
    // 空历史由命令层处理（notice），格式化函数本身不该崩。
    assert.doesNotThrow(() => approvalHistoryLines([], 50), 'empty history does not throw')
  }

  // 9f4. /plugin 参数解析（市场目录之外的直装入口）。纯函数：装/卸/列表/错误分支。
  {
    assert.deepEqual(parsePluginArgs(undefined), { kind: 'usage' }, '/plugin with no args shows usage')
    assert.deepEqual(parsePluginArgs('   '), { kind: 'usage' }, 'blank arg shows usage')
    assert.deepEqual(parsePluginArgs('help'), { kind: 'usage' }, '/plugin help shows usage')
    assert.deepEqual(parsePluginArgs('list'), { kind: 'list' }, '/plugin list lists installed')
    assert.deepEqual(parsePluginArgs('ls'), { kind: 'list' }, '/plugin ls alias')
    // update：安装的对称操作。此前只有 add/remove —— 目录外的插件在 TUI 里
    // 根本没有更新入口（/market 只覆盖目录内插件）。
    for (const verb of ['update', 'upgrade']) {
      assert.deepEqual(parsePluginArgs(`${verb} dsh-context`), { kind: 'update', spec: 'dsh-context', latest: false, ref: undefined }, `${verb} <npm name>`)
      assert.deepEqual(parsePluginArgs(`${verb} owner/repo`), { kind: 'update', spec: 'owner/repo', latest: false, ref: undefined }, `${verb} owner/repo`)
    }
    // git 依赖不带 --latest 会停在原 tag（UPGRADE.md 已有此结论），故必须能透传。
    assert.deepEqual(
      parsePluginArgs('update kovey/dsh-chat-interaction --latest'),
      { kind: 'update', spec: 'kovey/dsh-chat-interaction', latest: true, ref: undefined },
      '--latest 透传（位置在 spec 之后）')
    assert.deepEqual(
      parsePluginArgs('update --latest kovey/dsh-chat-interaction'),
      { kind: 'update', spec: 'kovey/dsh-chat-interaction', latest: true, ref: undefined },
      '--latest 透传（位置在 spec 之前）')
    // 只有 --latest 没有包名 → 缺包名，而不是把 flag 当包名。
    assert.deepEqual(parsePluginArgs('update --latest'), { kind: 'missing-spec', sub: 'update' }, 'only --latest → missing spec')
    assert.deepEqual(parsePluginArgs('update'), { kind: 'missing-spec', sub: 'update' }, 'update without spec')
    // 可见性/卸载词不误伤
    assert.deepEqual(parsePluginArgs('upgrade-all'), { kind: 'usage' }, 'unknown verb still shows usage')
    // 实测（隔离 profile）：`pnpm update --latest` **不会**推进
    // `github:owner/repo#tag` —— --latest 只重写 npm semver 范围，不改 git ref。
    // 唯一能推进的是用 add 带新 ref，故解析必须能识别出 ref。
    assert.equal(gitSpecRef('github:kovey/x#v1.2.3'), 'v1.2.3', 'git ref extracted')
    assert.equal(gitSpecRef('github:kovey/x'), undefined, 'git spec without ref → no target')
    assert.equal(gitSpecRef('dsh-context'), undefined, 'npm spec has no ref')
    assert.deepEqual(
      parsePluginArgs('update kovey/dsh-nvim-tui#v0.4.2'),
      { kind: 'update', spec: 'kovey/dsh-nvim-tui#v0.4.2', latest: false, ref: 'v0.4.2' },
      'git spec carries its target ref (update routes through add)')
    // install / add (and the CLI's own verb) all map to add.
    for (const verb of ['install', 'add']) {
      assert.deepEqual(parsePluginArgs(`${verb} dsh-context`), { kind: 'add', spec: 'dsh-context' }, `${verb} <npm name>`)
      assert.deepEqual(parsePluginArgs(`${verb} owner/repo`), { kind: 'add', spec: 'owner/repo' }, `${verb} owner/repo`)
      assert.deepEqual(
        parsePluginArgs(`${verb} git+https://example.com/a.git`),
        { kind: 'add', spec: 'git+https://example.com/a.git' },
        `${verb} git URL`,
      )
    }
    for (const verb of ['remove', 'uninstall', 'rm']) {
      assert.deepEqual(parsePluginArgs(`${verb} dsh-context`), { kind: 'remove', spec: 'dsh-context' }, `${verb} <spec>`)
    }
    // A spec may contain spaces (local path) and is passed through verbatim.
    assert.deepEqual(
      parsePluginArgs('install /Users/me/my plugin'),
      { kind: 'add', spec: '/Users/me/my plugin' },
      'spec with spaces preserved',
    )
    // Verb casing + surrounding whitespace are tolerated.
    assert.deepEqual(parsePluginArgs('  INSTALL   dsh-context  '), { kind: 'add', spec: 'dsh-context' }, 'casing/space tolerant')
    // Errors: unknown verb → usage; missing spec; a leading '-' would be
    // parsed by the CLI as a flag, so it must be rejected by the parser.
    assert.deepEqual(parsePluginArgs('frobnicate x'), { kind: 'usage' }, 'unknown verb falls back to usage')
    assert.deepEqual(parsePluginArgs('install'), { kind: 'missing-spec', sub: 'install' }, 'missing spec reported')
    assert.deepEqual(parsePluginArgs('remove'), { kind: 'missing-spec', sub: 'remove' }, 'missing spec reported (remove)')
    assert.deepEqual(parsePluginArgs('install --frozen'), { kind: 'bad-spec', spec: '--frozen' }, 'leading dash rejected')
    log('plugin arg parser: verbs/aliases/spec-passthrough/error branches ok')
  }

  // 9f5. e2e dump 判定（scripts/e2e-judge.ts）。此前该规则内联在 e2e.ts 里、
  // 无任何测试，两个启发式 bug（读裸 '·'、过滤面过宽）都是真机跑歪才发现。
  {
    const pass = (label: string, lines: string[]): void =>
      assert.equal(judgeDump(frameTurn(lines)), null, `e2e judge accepts: ${label}`)
    const fail = (label: string, lines: string[]): void =>
      assert.notEqual(judgeDump(frameTurn(lines)), null, `e2e judge rejects: ${label}`)
    // 真实渲染形态不得误杀（假阴性会打断正常 e2e 工作流）。
    pass('plain answer', ['收到'])
    pass('multi-line answer', ['第一行', '第二行'])
    pass('markdown table', ['┌──┬──┐', '│ a │ b │', '└──┴──┘'])
    pass('tool cards', ['🔧 bash({})', '✓ bash · 234ms'])
    pass('subagent rows', ['◇ subagent x · completed · 0ms'])
    pass('workflow rows', ['◈ workflow 审计'])
    pass('todo list', ['📋 待办 3 项', '  ✓ 任务一'])
    pass('injected context + answer', ['> 你好', '· 注入上下文', '· Current x', '·', '· Approval y', '收到'])
    // 回归：纯 '· ' 项目符号回答曾被整段误判为「无助手内容」。
    pass('regression: pure bullet answer', ['· 第一点', '· 第二点'])
    // 反例：无凭证时必须 FAIL —— 注入块（含渲染为裸 '·' 的空续行）与用户回显
    // 都不算助手内容。
    fail('regression: no-key with blank injected lines', ['> probe', '· 注入上下文', '· Current x', '·', '· Approval y'])
    fail('no-key, injected only', ['> probe', '· 注入上下文', '· Current x'])
    fail('prompt echo only', ['> probe'])
    fail('error marker in turn', ['⚠ 回合被中断'])
    // 收尾定界符是 '── turn ──' 的子串，未锚定整行会取错分界点。
    assert.notEqual(judgeDump('no markers at all'), null, 'dump without a turn is rejected')
    log('e2e dump judge: real render shapes accepted, echo/injection/error rejected')
  }

  // 9g3. /difficulty 难度路由（M2 规则定档：纯函数）。
  const rules = estimateByRules
  assert.equal(rules('你好', { planActive: false, goal: false, toolErrors: 0, hasImages: false }), 'easy', '短闲聊 → easy')
  assert.equal(rules('收到', { planActive: false, goal: false, toolErrors: 0, hasImages: false }), 'easy', '确认语 → easy')
  assert.equal(rules('帮我把这个函数重构一下，加缓存', { planActive: false, goal: false, toolErrors: 0, hasImages: false }), 'hard', '重构关键词 → hard')
  assert.equal(rules('please debug the race condition', { planActive: false, goal: false, toolErrors: 0, hasImages: false }), 'hard', '英文 debug/race → hard')
  assert.equal(rules('这段代码什么意思？', { planActive: false, goal: false, toolErrors: 0, hasImages: false }), 'medium', '普通问题 → medium')
  assert.equal(rules('嗯', { planActive: true, goal: false, toolErrors: 0, hasImages: false }), 'hard', '计划模式优先 → hard')
  assert.equal(rules('嗯', { planActive: false, goal: true, toolErrors: 0, hasImages: false }), 'hard', '活跃目标优先 → hard')
  assert.equal(rules('嗯', { planActive: false, goal: false, toolErrors: 2, hasImages: false }), 'hard', '工具失败优先 → hard')
  assert.equal(rules('嗯', { planActive: false, goal: false, toolErrors: 0, hasImages: true }), 'medium', '图片消息不降级 → medium')
  assert.equal(rules('这是一条非常长的任务描述' + 'x'.repeat(600), { planActive: false, goal: false, toolErrors: 0, hasImages: false }), 'hard', '超长任务 → hard')

  // 9g4. 待办清单纪律守卫（纯函数：逐项更新硬性约束）
  const gTodos = (statuses: string[]) => statuses.map((s, i) => ({ content: `任务${i + 1}`, status: s }))
  assert.equal(
    latestTodos([{ type: 'todo/write', data: { todos: gTodos(['pending', 'in_progress']) } }])?.[1]?.content,
    '任务2', 'latestTodos 读取最后一次写入')
  assert.equal(latestTodos([{ type: 'turn/start' }]), null, '没有 todo/write → null')
  assert.ok(
    (todoGuardReminder({ sawTodoWrite: false, toolCalls: 2 }, gTodos(['in_progress', 'pending']), 0) ?? '').includes('任务1'),
    '有未完成项 + 工具活动 + 未写清单 → 提醒并列出未完成项')
  assert.equal(todoGuardReminder({ sawTodoWrite: true, toolCalls: 2 }, gTodos(['in_progress']), 0), null, '该步写过清单 → 不提醒')
  assert.equal(todoGuardReminder({ sawTodoWrite: false, toolCalls: 0 }, gTodos(['in_progress']), 0), null, '无工具活动 → 不提醒')
  assert.equal(todoGuardReminder({ sawTodoWrite: false, toolCalls: 3 }, gTodos(['completed']), 0), null, '全部完成 → 不提醒')
  assert.equal(todoGuardReminder({ sawTodoWrite: false, toolCalls: 1 }, gTodos(['pending']), MAX_NUDGES_PER_TURN), null, '提醒预算用尽 → 不提醒')
  assert.equal(todoGuardReminder({ sawTodoWrite: false, toolCalls: 1 }, null, 0), null, '无清单 → 不提醒')

  // 9g4b. 守卫的**注册面**：纯函数断言覆盖不到「挂了哪些事件、收尾时做了什么」，
  // 而「回合收尾无闸」这个缺口正是从这里溜进来的（实测：4 项只完成 1 项，剩余项
  // 随回合 idle 一起留存，既不催办也不落盘）。装到 mock ctx 上按真实事件驱动。
  {
    const withSnapshot = (todos: Array<{ content: string; status: string }>) => {
      const events: Array<Record<string, unknown>> = [
        { type: 'turn/start' },
        { type: 'todo/write', data: { todos } },
        { type: 'tool/call', data: {} },
      ]
      return { snapshotEvents: () => events }
    }
    const handlers = new Map<string, (...a: unknown[]) => unknown>()
    const steered: string[] = []
    const guardErrs: string[] = []
    const agentMock = {
      session: withSnapshot(gTodos(['completed', 'in_progress', 'pending'])),
      steer: (m: { content: Array<{ text?: string }> }) => {
        steered.push(m?.content?.[0]?.text ?? '')
      },
    }
    installTodoGuard({
      systemPrompt: { section: () => () => {} },
      on: (name: string, h: (...a: unknown[]) => unknown) => { handlers.set(name, h); return () => {} },
    }, { onError: (stage, err) => guardErrs.push(`${stage}: ${String(err)}`) })
    assert.deepEqual([...handlers.keys()].sort(), ['agent/pre-step', 'agent/turn-stopping'], 'guard registers BOTH the per-step nudge and the turn-end gate')
    assert.deepEqual(guardErrs, [], 'guard registration reports no errors')

    // Baseline call: the guard treats the first call as its starting point.
    await handlers.get('agent/pre-step')!({ agent: agentMock, signal: { aborted: false } }, async () => ({ messages: [] }))

    // Turn is about to close with items still open → the gate must steer.
    await handlers.get('agent/turn-stopping')!({ agent: agentMock, turn: 1, signal: { aborted: false } })
    assert.equal(steered.length, 1, 'turn-end gate steers once when items remain open')
    assert.ok(steered[0]!.includes('任务2'), 'steer message lists the open items')

    // Bounded: a second stop must NOT steer again (no infinite turn loop).
    await handlers.get('agent/turn-stopping')!({ agent: agentMock, turn: 1, signal: { aborted: false } })
    assert.equal(steered.length, 1, 'turn-end gate is bounded per turn')

    // Aborted turn: never steer (the user asked to stop).
    const steered2: string[] = []
    const abortAgent = { session: withSnapshot(gTodos(['pending'])), steer: () => steered2.push('x') }
    const h2 = new Map<string, (...a: unknown[]) => unknown>()
    installTodoGuard({
      systemPrompt: { section: () => () => {} },
      on: (n: string, h: (...a: unknown[]) => unknown) => { h2.set(n, h); return () => {} },
    })
    await h2.get('agent/turn-stopping')!({ agent: abortAgent, turn: 1, signal: { aborted: true } })
    assert.equal(steered2.length, 0, 'aborted turn is never steered')

    // Clean list: nothing open → no steer.
    const steered3: string[] = []
    const cleanAgent = { session: withSnapshot(gTodos(['completed'])), steer: () => steered3.push('x') }
    const h3 = new Map<string, (...a: unknown[]) => unknown>()
    installTodoGuard({
      systemPrompt: { section: () => () => {} },
      on: (n: string, h: (...a: unknown[]) => unknown) => { h3.set(n, h); return () => {} },
    })
    await h3.get('agent/turn-stopping')!({ agent: cleanAgent, turn: 1, signal: { aborted: false } })
    assert.equal(steered3.length, 0, 'all-completed list is never steered at turn end')
  }
  const mdHead = FeedRenderer.parseLine('## 标题行', false, true)
  assert.equal(mdHead.text, '标题行', 'heading markers stripped')
  assert.equal(mdHead.group, 'DshTuiHeading', 'heading group')
  const mdQuote = FeedRenderer.parseLine('> 引用的内容', false, true)
  assert.equal(mdQuote.text, '引用的内容', 'blockquote marker stripped')
  assert.equal(mdQuote.group, 'DshTuiQuote', 'blockquote group')
  const mdUser = FeedRenderer.parseLine('> 用户说的话', false, false)
  assert.equal(mdUser.text, '> 用户说的话', 'user line keeps its prefix')
  assert.equal(mdUser.group, undefined, 'user line has no quote group')
  const mdLink = FeedRenderer.parseLine('见 [文档](docs/x.md) 说明', false, true)
  assert.ok(mdLink.spans.some((s) => s.group === 'DshTuiLink'), 'link span rendered')
  assert.ok(!mdLink.text.includes('(docs/x.md)'), 'link URL stripped')
  assert.ok(mdLink.text.includes('文档'), 'link text kept')

  // 9g2. file-change diff blocks: LCS hunks, add/del-only, caps, i18n labels
  const editDiff = diffTexts('a\nb\nc\nd', 'a\nB\nc\nd')
  assert.equal(editDiff.stats.added, 1, 'diff counts the added line')
  // Tail-of-file edits (regression: the old DP indexing was off by one row
  // AND column — last-row/last-column cells read out of bounds as NaN and
  // tail deletions collapsed into whole-file replaces).
  const tailEdit = diffTexts('a\nb\nc', 'a\nb')
  assert.equal(tailEdit.stats.removed, 1, 'tail deletion counts 1 removed line')
  assert.equal(tailEdit.stats.added, 0, 'tail deletion adds nothing')
  assert.ok(tailEdit.lines.includes('- c'), 'tail deletion renders the removed line')
  const swapEdit = diffTexts('x\ny', 'y\nx')
  assert.equal(swapEdit.stats.removed + swapEdit.stats.added, 2, 'two-line swap counts 1+1')

  assert.equal(editDiff.stats.removed, 1, 'diff counts the removed line')
  assert.ok(editDiff.lines.includes('- b'), 'removed line rendered with −')
  assert.ok(editDiff.lines.includes('+ B'), 'added line rendered with +')
  assert.ok(editDiff.lines.includes('  a'), 'context line kept above the change')
  const addDiff = diffTexts(null, 'x\ny')
  assert.equal(addDiff.stats.added, 2, 'new file = all additions')
  assert.ok(addDiff.lines.includes('+ y'), 'new-file lines rendered')
  const delDiff = diffTexts('x\ny', null)
  assert.equal(delDiff.stats.removed, 2, 'deleted file = all removals')
  assert.equal(diffTexts('x', 'x').lines.length, 0, 'identical content renders nothing')
  const bigDiff = diffTexts(null, Array.from({ length: 100 }, (_, i) => 'line' + i).join('\n'))
  assert.ok(bigDiff.truncated, 'oversized block truncates')
  assert.ok(bigDiff.lines.some((l: string) => l.includes('省略')), 'truncation notice shown')
  const metaDiffs = fileDiffsFromMeta({ diffs: [{ path: 'src/a.ts', oldText: 'x', newText: 'y' }, { path: 'src/b.ts', oldText: 'z', newText: 'z' }, { bogus: true }] })
  assert.equal(metaDiffs?.length, 2, 'meta diffs parsed (unchanged + malformed dropped)')
  assert.equal(metaDiffs?.[0]?.path, 'src/a.ts', 'meta diff carries the path')
  assert.equal(fileDiffsFromMeta(undefined), null, 'no meta → null')
  assert.equal(fileDiffsFromMeta({ diffs: [] }), null, 'empty diffs → null')
  const midEdit = diffTexts(Array.from({ length: 50 }, (_, i) => 'l' + i).join('\n'),
    Array.from({ length: 50 }, (_, i) => (i === 25 ? 'changed' : 'l' + i)).join('\n'))
  assert.ok(midEdit.lines.includes('+ changed'), 'middle-of-file edit found')
  assert.ok(midEdit.lines.length < 50, 'distant context trimmed (no whole-file echo)')
  // A single hunk LARGER than the cap must still render its head with real
  // stats — an empty +0 −0 block gets the whole card dropped by the runner
  // (the hidden bug that made some diffs disappear entirely).
  const giantEdit = diffTexts(
    Array.from({ length: 60 }, (_, i) => 'old' + i).join('\n'),
    Array.from({ length: 60 }, (_, i) => 'new' + i).join('\n'))
  assert.ok(giantEdit.truncated, 'giant single-hunk diff truncates')
  assert.ok(giantEdit.lines.length >= 4, 'giant hunk still renders its head')
  assert.ok(giantEdit.stats.added + giantEdit.stats.removed > 0,
    'giant hunk reports real stats (never +0 −0 with content)')
  assert.ok(giantEdit.lines.some((l: string) => l.startsWith('- old')), 'giant hunk head keeps − rows')
  assert.ok(giantEdit.lines.some((l: string) => l.includes('省略')), 'giant hunk shows the omission notice')
  const prev = locale()
  setLocale('en')
  assert.equal(t('修改'), 'Modified', 'diff action label translated')
  setLocale(prev)
  // /subagents ordering: running children first, then newest-first
  const ordered = orderSubagentChildren([
    { id: 'old1', running: false, createdAt: 100 },
    { id: 'run2', running: true, createdAt: 200 },
    { id: 'run1', running: true, createdAt: 100 },
    { id: 'new1', running: false, createdAt: 300 },
  ])
  assert.deepEqual(ordered.map((c) => c.id), ['run2', 'run1', 'new1', 'old1'],
    'running subagents first, newest-first within groups')

  // 9h. @-file-reference menu: accept replaces the token in the input line.
  // Detection must fire at the line START too (首位 @) — the %A guard had no
  // preceding character to match there and the menu never opened.
  drainNotes('dsh-at-query')
  await nvim.request('nvim_win_set_cursor', [ids.inputWin, [1, 3]])
  await nvim.request('nvim_buf_set_lines', [ids.inputBuf, 0, -1, false, ['@fi']])
  await lua('require("dsh_tui").update_at_menu()', [])
  hit = await waitNote('dsh-at-query')
  assert.equal((hit?.args?.[0] as { query?: string })?.query, 'fi', 'line-start @token detected')
  assert.equal((hit?.args?.[0] as { start?: number })?.start, 0, 'line-start @token offset is 0')
  drainNotes('dsh-at-query')
  await nvim.request('nvim_win_set_cursor', [ids.inputWin, [1, 10]])
  await nvim.request('nvim_buf_set_lines', [ids.inputBuf, 0, -1, false, ['请读 @fi']])
  await nvim.request('nvim_win_set_cursor', [ids.inputWin, [1, 10]])
  await lua('require("dsh_tui").update_at_menu()', [])
  hit = await waitNote('dsh-at-query')
  assert.equal((hit?.args?.[0] as { query?: string })?.query, 'fi', 'mid-line @token detected')
  assert.equal((hit?.args?.[0] as { start?: number })?.start, 7, 'mid-line @token offset is the @ byte column')
  await lua('require("dsh_tui").set_at_menu(...)', [[{ path: 'src/a.txt', mention: '@src/a.txt' }, { path: 'src/b.md', mention: '@src/b.md' }], 7])
  assert.ok(await lua('return require("dsh_tui").at_menu_open()', []), 'at-menu opens')
  await lua('require("dsh_tui").at_next()', [])
  await lua('require("dsh_tui").at_accept()', [])
  const atLines = await nvim.request('nvim_buf_get_lines', [ids.inputBuf, 0, -1, false])
  assert.equal(atLines[0], '请读 @src/b.md', 'at-mention accepted into input')
  // navigation keys route to the OPEN at-menu (C-n / C-p / Up / Down) — the
  // same menu-first claim as the /-command menu; without it the keys fall
  // into history cycling and the menu can never change its selection
  await nvim.request('nvim_buf_set_lines', [ids.inputBuf, 0, -1, false, ['@']])
  await nvim.request('nvim_win_set_cursor', [ids.inputWin, [1, 1]])
  // start = the '@' BYTE OFFSET (the same convention the dsh-at-query echo
  // asserts above: line-start token → offset 0). The stale-response guard
  // in AM.set verifies the input still has '@' at this offset.
  await lua('require("dsh_tui").set_at_menu(...)', [[{ path: 'src/a.txt', mention: '@src/a.txt' }, { path: 'src/b.md', mention: '@src/b.md' }, { path: 'src/c.ts', mention: '@src/c.ts' }], 0])
  await lua(`vim.api.nvim_set_current_win(require("dsh_tui").ids().inputWin); vim.cmd('startinsert')`, [])
  await nvim.input('<C-n>')
  await new Promise((r) => setTimeout(r, 120))
  assert.equal(await lua('return require("dsh_tui")._atIdx', []), 2, '<C-n> advances the at-menu selection')
  await nvim.input('<Down>')
  await new Promise((r) => setTimeout(r, 120))
  assert.equal(await lua('return require("dsh_tui")._atIdx', []), 3, '<Down> advances the at-menu selection')
  await nvim.input('<Up>')
  await new Promise((r) => setTimeout(r, 120))
  assert.equal(await lua('return require("dsh_tui")._atIdx', []), 2, '<Up> moves the at-menu selection back')
  await nvim.input('<C-p>')
  await new Promise((r) => setTimeout(r, 120))
  assert.equal(await lua('return require("dsh_tui")._atIdx', []), 1, '<C-p> moves the at-menu selection back')
  assert.ok(await lua('return require("dsh_tui").at_menu_open()', []), 'at-menu stays open through navigation')
  await lua('require("dsh_tui").close_at_menu()', [])
  await nvim.request('nvim_buf_set_lines', [ids.inputBuf, 0, -1, false, ['']])

  // 9i. directory picker: navigate to a file → dsh-dir-selected notify.
  await lua('return require("dsh_tui").show_dir_picker(...)', [process.cwd()])
  await assertModeN('dir picker opens in normal mode')
  const dirState = await lua(`local M = require("dsh_tui")
    for i, e in ipairs(M._dirRows) do
      if not e.dir and e.name == "package.json" then return { idx = i } end
    end
    return { idx = 0 }`, [])
  assert.ok(dirState.idx > 0, 'package.json visible in dir picker')
  const dirBuf = await lua('return require("dsh_tui")._dirBuf', [])
  const dirLines = await nvim.request('nvim_buf_get_lines', [dirBuf, 0, -1, false])
  assert.equal(await lua('return vim.api.nvim_win_get_height(require("dsh_tui")._dirWin)', []), Math.min(14, dirLines.length), 'dir window height fits content up to its cap')
  await assertFooter('[Enter]', 'dir picker')
  await assertCentered('require("dsh_tui")._dirWin', 'dir picker')
  // Enter derives the entry from the cursor row (native j/k/G navigation).
  await lua(`local M = require("dsh_tui") vim.api.nvim_win_set_cursor(M._dirWin, { ${dirState.idx} + 2, 0 }) M.dir_enter()`, [])
  hit = await waitNote('dsh-dir-selected')
  assert.ok(String(hit?.args?.[0] ?? '').endsWith('/package.json'), 'dir picker selects a file path')

  // 9j. generic lines float (workflow/settings/trajectory renderer).
  const lf = await lua('return require("dsh_tui").show_lines_float(...)', ['工作流运行', ['◈ audit · 运行中', '  ─ 阶段一']])
  const lfLines = await nvim.request('nvim_buf_get_lines', [lf.buf, 0, -1, false])
  assert.deepEqual(lfLines, ['◈ audit · 运行中', '  ─ 阶段一'], 'lines float renders rows')
  assert.equal(await lua('return vim.api.nvim_win_get_height(require("dsh_tui")._linesWin)', []), lfLines.length, 'lines float window exactly fits content (no gap below)')
  await assertFooter('[q]', 'lines float')
  await assertCentered('require("dsh_tui")._linesWin', 'lines float')
  // Without an editPath, i/o are Nop'd (read-only float must not answer an
  // edit attempt with a raw E21); with an editPath they open the file tab.
  const lfMaps = await lua(`local out = {}
    for _, m in ipairs(vim.api.nvim_buf_get_keymap(${lf.buf}, "n")) do
      -- msgpack cannot carry a Lua callback back to the client — report a flag.
      table.insert(out, { lhs = m.lhs, rhs = m.rhs or "", hasCallback = type(m.callback) == 'function' })
    end
    return out`, [])
  const lfI = lfMaps.find((m: any) => m.lhs === 'i')
  assert.ok(lfI && lfI.rhs === '' && !lfI.hasCallback, 'lines float i is Nop without editPath')
  await lua('require("dsh_tui").close_lines_float()', [])
  const lf2 = await lua('return require("dsh_tui").show_lines_float(...)', ['设置', ['▸ agent-default-model'], '/tmp/settings.yaml'])
  const lf2Maps = await lua(`local out = {}
    for _, m in ipairs(vim.api.nvim_buf_get_keymap(${lf2.buf}, "n")) do
      table.insert(out, { lhs = m.lhs, hasCallback = type(m.callback) == 'function' })
    end
    return out`, [])
  const lf2I = lf2Maps.find((m: any) => m.lhs === 'i')
  assert.ok(lf2I && lf2I.hasCallback, 'lines float i opens the edit file when editPath is given')
  await lua('require("dsh_tui").close_lines_float()', [])

  // 9k2. install progress float: live log tail + bottom bar row (marketplace
  // install streams into it so pnpm runs never look stuck).
  const prog = await lua('return require("dsh_tui").show_progress(...)', ['安装 demo-plugin', ['① 解析安装源…']])
  assert.ok(Number.isInteger(prog.buf) && Number.isInteger(prog.win), 'progress float opens')
  await assertCentered('require("dsh_tui")._progress.win', 'progress')
  await lua('require("dsh_tui").progress_update(...)', [['① 解析安装源…', '· 使用 npm 发布版: x@1.0.0', '② 安装依赖…', '✓ 命令成功'], '▸ 60% 安装依赖…'])
  const progLines = await nvim.request('nvim_buf_get_lines', [prog.buf, 0, -1, false])
  assert.ok(String(progLines[progLines.length - 1]).startsWith('▸ 60%'), 'progress bar row is the last row')
  assert.ok(progLines.slice(0, -1).includes('✓ 命令成功'), 'progress window shows install log lines')
  await lua('require("dsh_tui").progress_update(...)', [Array.from({ length: 40 }, (_, i) => 'log-' + i), 'bar-end'])
  const progLines2 = await nvim.request('nvim_buf_get_lines', [prog.buf, 0, -1, false])
  assert.ok(String(progLines2[progLines2.length - 1]).startsWith('bar-end'), 'bar stays the last row after a log flood')
  assert.ok(progLines2.includes('log-39'), 'latest log line visible (tailed view)')
  assert.equal(await lua('return vim.api.nvim_win_get_height(require("dsh_tui")._progress.win)', []), progLines2.length, 'progress window holds exactly the visible tail')
  await lua('require("dsh_tui").close_progress()', [])
  assert.equal(await lua('return require("dsh_tui")._progress.win', []), null, 'progress float closes')

  // 9k3. fill_input: /help popup's Enter logic — write the command into the
  // input box and hand back in insert mode (second Enter executes it).
  await lua('require("dsh_tui").fill_input(...)', ['/sessions '])
  assert.equal(await lua('return vim.api.nvim_buf_get_lines(require("dsh_tui").ids().inputBuf, 0, -1, false)[1]', []), '/sessions ', 'fill_input writes the picked command')
  let fillMode = ''
  for (let i = 0; i < 40; i++) {
    fillMode = (await nvim.request('nvim_get_mode', [])).mode
    if (fillMode === 'i') break
    await new Promise((r) => setTimeout(r, 25))
  }
  assert.equal(fillMode, 'i', 'fill_input hands back in insert mode')
  await lua('require("dsh_tui").fill_input(...)', [''])

  // 9k4. blue whale art (A+B): centered wallpaper while empty, bottom
  // watermark once content exists; /whale toggle removes it.
  // The art is now DERIVED from the official mark (scripts/whale-gen.ts) rather
  // than hand-drawn, so the assertions check the derivation's invariants: the
  // silhouette keeps the official aspect ratio at every tier, and the frames
  // move the whale instead of shearing it.
  assert.ok(WHALE_RENDER_ROWS.length >= 6, 'whale art has text rows')
  assert.ok(WHALE_RENDER_ROWS.some((r) => r.text.includes('▀') && r.spans.length > 0), 'whale art renders half-block glyphs with color spans')
  // Every span must name one of the three silhouette groups — the official mark
  // is a single-colour silhouette, so an invented group would mean a stale grid.
  const whaleSpanGroups = new Set(['DshTuiWhaleBB', 'DshTuiWhaleB-', 'DshTuiWhale-B'])
  assert.ok(
    WHALE_RENDER_ROWS.every((r) => r.spans.every((sp) => whaleSpanGroups.has(sp.group))),
    'whale spans use only the silhouette palette groups',
  )
  // Spans must be gap-free and in order, or the extmark pass colours nothing.
  for (const r of WHALE_RENDER_ROWS) {
    for (let i = 1; i < r.spans.length; i++) {
      assert.ok(r.spans[i]!.s >= r.spans[i - 1]!.e, 'whale spans are ordered and non-overlapping')
    }
  }

  const frames = whaleFrames()
  assert.equal(frames.length, 4, 'whale animation has a 4-frame cycle')
  assert.ok(frames.every((f) => f.length === WHALE_RENDER_ROWS.length), 'every animation frame renders the same row count')
  assert.notDeepEqual(frames[0], frames[1], 'frame 1 differs (bubble rises)')
  assert.notDeepEqual(frames[1], frames[2], 'frame 2 differs (whale bobs)')
  // Rigid bob: the bobbed frames must keep the silhouette's lit-pixel count
  // within a small delta. The old animation duplicated rows via g[y]=g[y-1],
  // which changed the shape; a rigid shift cannot.
  const litCount = (f: typeof frames[number]): number =>
    f.reduce((a, r) => a + r.spans.reduce((b, sp) => b + (sp.e - sp.s) / 3, 0), 0)
  const baseLit = litCount(frames[0]!)
  for (const f of frames) {
    assert.ok(Math.abs(litCount(f) - baseLit) <= baseLit * 0.12, 'bob keeps the silhouette mass (no shear)')
  }
  assert.equal(WHALE_EMOJI_FRAMES.length, 2, 'emoji watermark cycles the spouting whale + bubble')
  assert.ok(WHALE_EMOJI_FRAMES.every((f) => f.endsWith('🐳')), 'every frame carries the spouting whale emoji')
  assert.ok(WHALE_EMOJI_FRAMES.some((f) => f.includes('🫧')), 'bubble frame leads the cycle')
  const laid = layoutWhaleRows(30, 100)
  assert.ok(laid !== null && laid.length === WHALE_ROWS + Math.floor((30 - WHALE_ROWS) / 2), 'whale layout pads the top for vertical centering')
  assert.equal(laid?.[0]?.text, '', 'vertical centering pads the top')
  assert.equal(layoutWhaleRows(3, 20), null, 'tiny window skips the art')
  const whaleBuf = await nvim.request('nvim_create_buf', [false, true])
  const whaleFeed = new FeedRenderer(nvim, whaleBuf, ids.chatWin!, {
    idsProvider: async () => ({ win: ids.chatWin }),
    activeChecker: () => true,
    whale: true,
  })
  await whaleFeed.flush()
  let heroLines = await nvim.request('nvim_buf_get_lines', [whaleBuf, 0, -1, false])
  assert.ok(heroLines.some((l: string) => l.includes('▀')), 'empty state shows the whale wallpaper (half-block body)')
  assert.ok(heroLines.some((l: string) => l.includes('█')), 'whale body rendered')
  const whaleMarks = await nvim.request('nvim_buf_get_extmarks', [whaleBuf, -1, 0, -1, { details: true }])
  const whaleGroups = new Set((whaleMarks as any[]).map((m) => (Array.isArray(m) ? (m[3]?.hl_group ?? m[4]?.hl_group) : undefined)).filter(Boolean))
  assert.ok([...whaleGroups].some((g) => String(g).startsWith('DshTuiWhale')), 'whale glyphs carry per-pixel color groups')
  // Animation: while the wallpaper is up, the ticker advances frames and the
  // buffer changes on its own (wink/bubble/bob cycle).
  const whaleSnapshot = await nvim.request('nvim_buf_get_lines', [whaleBuf, 0, -1, false])
  await new Promise((r) => setTimeout(r, 1100))
  const whaleAnimated = await nvim.request('nvim_buf_get_lines', [whaleBuf, 0, -1, false])
  assert.notDeepEqual(whaleAnimated, whaleSnapshot, 'wallpaper animates (ticker advances frames)')
  whaleFeed.applyEvent({ type: 'user/message', time: 1, data: { content: [{ type: 'text', text: 'hi' }], source: { kind: 'user' } } })
  await whaleFeed.flush()
  heroLines = await nvim.request('nvim_buf_get_lines', [whaleBuf, 0, -1, false])
  assert.ok(heroLines.some((l: string) => l.includes('> hi')), 'content renders above the whale')
  assert.ok(!heroLines.some((l: string) => l.includes('🐳') || l.includes('🫧')), 'no emoji watermark once content exists')
  whaleFeed.setWhale(false)
  await new Promise((r) => setTimeout(r, 80))
  await whaleFeed.flush()
  heroLines = await nvim.request('nvim_buf_get_lines', [whaleBuf, 0, -1, false])
  assert.ok(!heroLines.some((l: string) => l.includes('▀')), 'whale off removes the art')
  // Welcome lines (project intro + usage) render under the whale while empty.
  const welcomeBuf = await nvim.request('nvim_create_buf', [false, true])
  const welcomeFeed = new FeedRenderer(nvim, welcomeBuf, ids.chatWin!, {
    idsProvider: async () => ({ win: ids.chatWin }),
    activeChecker: () => false,
    whale: true,
    welcome: () => ({
      above: [{ text: '███▌', group: 'DshTuiWhaleB-' }, { text: 'Neovim 风格的终端客户端 · v0.2.2', group: 'DshTuiUser' }],
      below: [{ text: '直接输入问题开始对话' }, { text: '  /help 全部命令 · /new 新建会话' }],
    }),
  })
  await welcomeFeed.flush()
  const welcomeLines0 = await nvim.request('nvim_buf_get_lines', [welcomeBuf, 0, -1, false])
  assert.ok(welcomeLines0.some((l: string) => l.includes('▀')), 'welcome state still shows the whale wallpaper')
  assert.ok(welcomeLines0.some((l: string) => l.includes('███▌')), 'welcome shows the big banner letters')
  assert.ok(welcomeLines0.some((l: string) => l.includes('Neovim 风格的终端客户端')), 'welcome shows the project title')
  assert.ok(welcomeLines0.some((l: string) => l.includes('/help 全部命令')), 'welcome shows usage commands')
  welcomeFeed.applyEvent({ type: 'user/message', time: 1, data: { content: [{ type: 'text', text: 'hi' }], source: { kind: 'user' } } })
  await welcomeFeed.flush()
  const welcomeLines1 = await nvim.request('nvim_buf_get_lines', [welcomeBuf, 0, -1, false])
  assert.ok(!welcomeLines1.some((l: string) => l.includes('/help')), 'welcome hides once content arrives')
  await nvim.request('nvim_buf_delete', [welcomeBuf, { force: true }])
  await nvim.request('nvim_buf_delete', [whaleBuf, { force: true }])

  // 9k. layout presets: panel opens the reasoning panel, default closes it
  // (no resident sessions window anymore).
  await lua('require("dsh_tui").apply_layout(...)', ['panel'])
  assert.equal((await lua('return require("dsh_tui").ids()', [])).reasoningOpen, true, 'panel layout opens reasoning panel')
  await lua('require("dsh_tui").apply_layout(...)', ['default'])
  assert.equal((await lua('return require("dsh_tui").ids()', [])).reasoningOpen, false, 'default layout closes reasoning panel')

  // Command argument completion: `/plugin` must carry positional metadata so
  // the input box can answer "what do I type next?" (<Tab> candidates + hint).
  // Driven through the REAL registration path (installPluginCommand) with a stub
  // App, so dropping `args` from the spec fails here instead of silently
  // degrading to "no hints".
  {
    const specs: Array<{
      name: string
      args?: Array<{ kind: string; values?: string[]; byValue?: Record<string, Array<{ kind: string }>> }>
    }> = []
    const stub = {
      registerCommands: (list: unknown[]) => { specs.push(...(list as typeof specs)) },
    } as unknown as Parameters<typeof installPluginCommand>[0]
    installPluginCommand(stub)
    const pluginSpec = specs.find((sp) => sp.name === '/plugin')
    assert.ok(pluginSpec !== undefined, '/plugin registers a spec')
    assert.ok(Array.isArray(pluginSpec.args), '/plugin carries args metadata (Tab completion + hints)')
    assert.equal(pluginSpec.args?.length, 1, '/plugin has ONE argument: the subcommand choice')
    assert.equal(pluginSpec.args?.[0]?.kind, 'oneof', '/plugin arg is the subcommand choice')
    assert.deepEqual(pluginSpec.args?.[0]?.values, ['install', 'update', 'remove', 'list'],
      'the four /plugin subcommands are offered')
    // The grammar is a TREE: each subcommand carries its OWN arguments, and an
    // empty list marks a terminal one. A flat list could not express `list`
    // taking nothing, and the UI kept asking for arguments after it.
    const byValue = pluginSpec.args?.[0]?.byValue ?? {}
    assert.deepEqual(Object.keys(byValue).sort(), ['install', 'list', 'remove', 'update'],
      'every subcommand names its own branch')
    assert.deepEqual(byValue['list'], [], '`list` is explicitly terminal (takes no arguments)')
    assert.deepEqual(byValue['install']?.map((a: { kind: string }) => a.kind), ['free', 'flag'],
      '`install` takes a spec then an optional flag')
  }
  // The Lua side must expose the two surfaces the input box drives.
  assert.equal(await lua('return type(require("dsh_tui.cmd_menu").suggest)', []), 'function', 'CM.suggest exists')
  assert.equal(await lua('return type(require("dsh_tui.cmd_menu").hint)', []), 'function', 'CM.hint exists')

  // The catalog builder must stay ONE definition. It used to be written twice
  // (commandCatalog() and refreshCommandCatalog()) and the refresh path dropped
  // `args`, so argument completion died right after boot when the refresh push
  // overwrote the good catalog. Measured on a real instance.
  {
    const appSrc = fs.readFileSync(path.join(process.cwd(), 'src/kernel/app.ts'), 'utf8')
    assert.equal((appSrc.match(/args === undefined \? \{\} : \{ args \}/g) ?? []).length, 0,
      'the inline-only mapping is gone (grammar now resolved in one place)')
    assert.equal((appSrc.match(/const grammar = args \?\? COMMAND_ARGS\[name\]/g) ?? []).length, 1,
      'the catalog resolves the grammar exactly once (inline wins, else the table)')
    assert.ok(/const catalogEntries = \(\) =>/.test(appSrc), 'catalogEntries() exists')
    assert.equal((appSrc.match(/catalogEntries\(\)/g) ?? []).length >= 2, true,
      'both catalog pushes go through catalogEntries()')
  }

  // The central grammar table must stay in SYMMETRY with the real command set.
  // The failure that matters: a command that takes arguments but has NO entry —
  // the input box then stays dumb for it (silent degradation). The opposite (a
  // table key for a command that no longer exists) is dead data. Both are caught
  // by scanning the real registrations: `usage` is the author's own statement of
  // whether the command takes arguments, so a usage line with a placeholder or
  // an enumeration must be covered by the table (or declare `args` inline).
  {
    const walk = (dir: string): string[] =>
      fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
        const full = path.join(dir, e.name)
        if (e.isDirectory()) return walk(full)
        return e.isFile() && e.name.endsWith('.ts') && !e.name.endsWith('.d.ts') ? [full] : []
      })
    const registered = new Map<string, { usage: string; inline: boolean }>()
    for (const file of walk(path.join(process.cwd(), 'src'))) {
      const src = fs.readFileSync(file, 'utf8')
      // NOTE: `matchAll` yields ARRAYS (with `index`), not RegExpExecArray — no
      // `.group()` method. Destructuring is the correct access.
      for (const [full, cmdName] of src.matchAll(/name:\s*'(\/[^']+)'/g)) {
        if (cmdName === undefined) continue
        const at = src.indexOf(full)
        const seg = src.slice(at, at + 600)
        const u = /usage:\s*t\('([^']*)'\)/.exec(seg)
        registered.set(cmdName, {
          usage: u?.[1] ?? '',
          inline: /args:\s*\[/.test(seg),
        })
      }
    }
    const tableKeys = Object.keys(COMMAND_ARGS)
    const catalogNames = new Set(registered.keys())
    const strays = tableKeys.filter((n) => !catalogNames.has(n))
    assert.deepEqual(strays, [], 'every COMMAND_ARGS key names a real registered command')

    // A usage line mentioning a placeholder/enumeration means the command takes
    // arguments; it must then have a grammar (table or inline).
    const needsGrammar = [...registered.entries()].filter(([, v]) =>
      !v.inline && /[<[\]|]/.test(v.usage))
    const uncovered = needsGrammar.map(([n]) => n).filter((n) => COMMAND_ARGS[n] === undefined)
    assert.deepEqual(uncovered, [],
      'every command whose usage declares arguments has a grammar entry')
    assert.ok(tableKeys.length >= 25, `the table is populated (${tableKeys.length} commands)`)

    // Spot-check the shapes that the tree exists for. `byValue` only exists on
    // the `oneof` arm, so the arm is narrowed rather than cast away.
    const fb = COMMAND_ARGS['/fb']?.[0]
    assert.ok(fb?.kind === 'oneof', '/fb starts with a choice')
    assert.deepEqual(fb.kind === 'oneof' ? fb.values : undefined, ['up', 'down', 'clear'],
      '/fb offers every accepted operation (its usage omits `clear`)')
    const goal = COMMAND_ARGS['/goal']?.[0]
    assert.ok(goal?.kind === 'oneof', '/goal starts with a choice')
    if (goal?.kind === 'oneof') {
      assert.equal(goal.byValue?.['clear']?.length, 0, '/goal clear is terminal')
      assert.ok((goal.byValue?.['new']?.length ?? 0) > 0, '/goal new takes a description')
    }
  }

  // OS opener mapping is pure and platform-parameterised, so it is asserted
  // directly instead of pretending to run on another OS. A wrong argv would
  // silently do nothing when the user presses the key.
  {
    assert.deepEqual(systemOpenArgv('/tmp/x.pdf', 'darwin'), ['open', '/tmp/x.pdf'],
      'macOS opens with `open`')
    assert.deepEqual(systemOpenArgv('/tmp/x.pdf', 'linux'), ['xdg-open', '/tmp/x.pdf'],
      'linux opens with `xdg-open`')
    assert.equal(systemOpenArgv('/tmp/x.pdf', 'win32'), undefined,
      'an unknown platform offers NO action rather than a broken one')
    assert.deepEqual(systemRevealArgv('/tmp/x.pdf', 'darwin'), ['open', '-R', '/tmp/x.pdf'],
      'macOS reveals with `open -R`')
    assert.equal(systemRevealArgv('/tmp/x.pdf', 'linux'), undefined,
      'reveal is macOS-only (no portable spelling)')
  }

  // Deliverables: explicit `present` declarations are authoritative and must
  // survive de-duplication against the mutation-tool path heuristic. Pure
  // folding, so the rule is asserted without a live session.
  {
    const turn = emptyDeliverables(3)
    const merged = mergePresentedFiles(turn, 3, [
      { path: 'docs/a.md', description: 'API guide' },
      { path: 'out/report.csv' },
      { path: 'docs/a.md', description: 'duplicate' },
    ])
    assert.equal(merged.presented.length, 2, 'presented files de-duplicate by path')
    assert.equal(merged.presented[0]?.description, 'API guide', 'description is kept')
    merged.paths.push('src/x.ts', 'docs/a.md')
    assert.deepEqual(deliverablePaths(merged), ['docs/a.md', 'out/report.csv', 'src/x.ts'],
      'declared files come first; heuristic duplicates are dropped')
    assert.equal(resolveDeliverablePath('/repo', 'docs/a.md'), '/repo/docs/a.md', 'relative paths resolve against the session cwd')
    assert.equal(resolveDeliverablePath('/repo', '/tmp/x'), '/tmp/x', 'absolute paths are untouched')
  }

  // App arguments: `dsh --profile tui --resume <id>` must reach the TUI, and
  // a missing/unknown flag must fail loudly instead of starting a different
  // session. Pure grammar, so no boot is needed.
  {
    assert.deepEqual(appArgv(['--profile', 'tui', '--resume', 'abc'], false), ['--resume', 'abc'])
    assert.deepEqual(appArgv(['--profile=tui', '--continue'], false), ['--continue'])
    assert.deepEqual(appArgv(['tui', '--model', 'x/y'], false), ['--model', 'x/y'])
    assert.deepEqual(appArgv(['tui', '--patch', 'extra.yml'], false), [], 'launcher --patch is not an app arg')
    assert.deepEqual(appArgv(['--profile', 'tui', '--dump-config'], false), [], 'launcher dump flag is not an app arg')
    assert.deepEqual(parseTuiArgs(['--profile', 'tui', '--patch', 'extra.yml', '--resume', 'abc']).resumeId, 'abc')
    const a = parseTuiArgs(['--profile', 'tui', '--resume', 'abc', '--model', 'deepseek/x', '--permission', 'read-only', '--continue'])
    assert.equal(a.resumeId, 'abc')
    assert.equal(a.model, 'deepseek/x')
    assert.equal(a.permission, 'read-only')
    assert.equal(a.resumeLatest, true)
    assert.equal(parseTuiArgs(['--profile', 'tui', '--help']).help, true)
    assert.equal(parseTuiArgs(['--profile', 'tui', '--version']).version, true)
    assert.deepEqual(parseTuiArgs(['--profile', 'tui', '--resume']).unknown, ['--resume'], 'missing value is reported')
    assert.deepEqual(parseTuiArgs(['--profile', 'tui', '--nope']).unknown, ['--nope'], 'unknown flag is reported')
  }

  // Settings form value typing: booleans/null/numbers/JSON literals are typed;
  // everything else stays a string (a model id must not become a number).
  {
    assert.equal(parseSettingValue('true'), true)
    assert.equal(parseSettingValue('false'), false)
    assert.equal(parseSettingValue('null'), null)
    assert.equal(parseSettingValue('42'), 42)
    assert.equal(parseSettingValue('-1.5'), -1.5)
    assert.deepEqual(parseSettingValue('{"provider":"x"}'), { provider: 'x' })
    assert.equal(parseSettingValue('deepseek-flash'), 'deepseek-flash')
    assert.equal(parseSettingValue('not json {'), 'not json {')
  }

  // Schedule bridge: dsh-schedule injects `sessionController` even though the
  // TUI profile has no web controller. The adapter must expose exactly
  // resolveAgent and resolve a live session without touching the UI.
  {
    const agent = { followup: () => {}, session: { id: 'session-live' } }
    const live = new Map([['session-live', { handle: { agent } }]])
    const fakeApp = { slices: { sessions: { live } } }
    let provided: { name: string; value: { resolveAgent: (id: string) => Promise<unknown> } } | undefined
    const fakeCtx = {
      get: () => undefined,
      provide: (name: string, value: { resolveAgent: (id: string) => Promise<unknown> }) => { provided = { name, value } },
    }
    installSessionController(fakeApp as never, fakeCtx as never)
    assert.equal(provided?.name, 'sessionController')
    const resolved = await provided?.value.resolveAgent('session-live') as { agent?: unknown }
    assert.equal(resolved.agent, agent, 'live session resolves to its agent')
  }

  // Turn outline: one row per turn, first human prompt, step/tool counts and
  // the end reason. Pure fold, so the navigation index is asserted directly.
  {
    const rows = turnOutlineRows([
      { type: 'turn/start', seq: 1, time: 1, data: { turn: 1 } } as never,
      { type: 'user/message', seq: 2, time: 2, data: { content: [{ type: 'text', text: '修一下 bug' }] } } as never,
      { type: 'step/start', seq: 3, time: 3, data: { turn: 1, step: 1 } } as never,
      { type: 'tool/call', seq: 4, time: 4, data: { turn: 1, step: 1, name: 'bash', callId: 'c1', arguments: '{}' } } as never,
      { type: 'turn/end', seq: 5, time: 5, data: { turn: 1, reason: 'completed' } } as never,
    ])
    assert.equal(rows.length, 1, 'one outline row per turn')
    assert.equal(rows[0]?.user, '修一下 bug')
    assert.equal(rows[0]?.steps, 1)
    assert.equal(rows[0]?.tools, 1)
    assert.equal(rows[0]?.reason, 'completed')
  }

  // /export log shape: one canonical header line then one event per line. The
  // file must be parseable JSONL, because support tooling reads it directly.
  {
    const text = serializeSessionLog(
      { id: 'session-x', createdAt: 123, cwd: '/repo', isSeeded: false },
      [{ type: 'turn/start', seq: 1, time: 456, data: { turn: 1 } } as never],
      { id: 'fallback', createdAt: 0 },
    )
    const lines = text.trim().split('\n').map((l) => JSON.parse(l) as Record<string, unknown>)
    assert.equal(lines.length, 2, 'header + one event line')
    assert.equal(lines[0]?.['type'], 'session', 'canonical header line')
    assert.equal(lines[0]?.['version'], 4, 'missing version falls back to the current format')
    assert.equal(lines[0]?.['cwd'], '/repo', 'cwd is preserved')
    assert.equal(lines[1]?.['type'], 'turn/start', 'event line is verbatim')
    assert.equal(lines[1]?.['seq'], 1, 'event seq is preserved')
  }

  // /feedback argument grammar: only an exact durable category id becomes a
  // category; everything else is free text (a typo must not silently drop it).
  {
    assert.deepEqual(parseFeedbackArgs('task-result login failed'), { category: 'task-result', text: 'login failed' })
    assert.deepEqual(parseFeedbackArgs('task-result'), { category: 'task-result', text: '' })
    assert.deepEqual(parseFeedbackArgs('not-a-category hello'), { text: 'not-a-category hello' })
    assert.deepEqual(parseFeedbackArgs(undefined), { text: '' })
  }

  // Plugin enable/disable edits exactly ONE line of a user-authored YAML, so the
  // line-finding rule matters more than the IO: a loose match would clobber an
  // unrelated line in someone's profile. `togglePluginEntry` is pure and is
  // asserted directly.
  {
    const doc = [
      '- insert:',
      '    - id: alpha',
      "      name: '@x/alpha'",
      '    - id: beta',
      "      name: '@x/beta'",
      '',
    ].join('\n')
    const off = togglePluginEntry(doc, 'beta', false)
    assert.equal(off.kind, 'changed', 'disabling a present entry reports a change')
    assert.equal(off.line, 4, 'the touched line is the entry id line (1-based)')
    assert.ok(off.text.includes('#disabled# ') && off.text.includes('- id: beta'),
      'disable COMMENTS the line (stays valid YAML, reason visible)')
    assert.ok(off.text.includes('- id: alpha'), 'unrelated entries untouched')
    // Idempotent: disabling an already-disabled entry writes nothing.
    assert.equal(togglePluginEntry(off.text, 'beta', false).kind, 'unchanged',
      'disabling twice is a no-op (no empty diff)')
    // Round trip.
    assert.equal(togglePluginEntry(off.text, 'beta', true).text, doc, 'enable restores it verbatim')
    // A MISSING id must not touch anything.
    assert.equal(togglePluginEntry(doc, 'nope', false).kind, 'unchanged', 'an unknown id is a no-op')
    // A substring that merely CONTAINS the id must not match the id line.
    const tricky = ['- insert:', '    - id: beta2', "      name: '@x/beta'"].join('\n')
    assert.equal(togglePluginEntry(tricky, 'beta', false).kind, 'unchanged',
      'a name containing the id is not mistaken for the id line')
  }

  // `/diff` opens a side-by-side review. Asserted by RUNNING it in the harness
  // nvim: two `diff` windows in a new tab, both non-modifiable, both scroll-
  // bound. A shape-only assertion would pass even if the split never opened.
  assert.equal(await lua('return type(require("dsh_tui").show_diff_split)', []), 'function',
    'the side-by-side viewer is exported')
  // The review must open as a FLOAT in the CURRENT tab. Measured why: the TUI
  // pins `showtabline=0`, so a tab-based review opened with no visible cue — the
  // user pressed Enter and reported "no response" while the diff sat in an
  // invisible tab. Asserted on the real window tree, not on a return value.
  // Field-by-field rather than comparing an `inspect` string: the values are the
  // contract, the Lua pretty-printer is not.
  assert.equal(await lua(`local tabs = vim.fn.tabpagenr('$')
    require("dsh_tui").show_diff_split('t', '/tmp/x.lua', 'a\\nb\\nc', 'a\\nB\\nc')
    local st = require("dsh_tui.state").diffSplit
    if st == nil then return 'missing' end
    local same = vim.fn.tabpagenr('$') == tabs
    -- TWO separate floats: a float cannot be vsplit (measured: it split the tab
    -- underneath into a 136x2 sliver), so side-by-side means two floats.
    local floats = 0
    for _, w in ipairs(vim.api.nvim_tabpage_list_wins(0)) do
      if vim.api.nvim_win_get_config(w).relative ~= '' then floats = floats + 1 end
    end
    local lc = vim.api.nvim_win_get_config(st.left)
    local rc = vim.api.nvim_win_get_config(st.right)
    -- Same row/height and the left one starts before the right one: that is what
    -- "side by side" means, and it is exactly what the vsplit version broke.
    local side = lc.row == rc.row and vim.api.nvim_win_get_height(st.left) == vim.api.nvim_win_get_height(st.right)
      and lc.col < rc.col
    local diff = 0
    for _, w in ipairs({ st.left, st.right }) do
      if vim.api.nvim_win_call(w, function() return vim.wo.diff end) then diff = diff + 1 end
    end
    return table.concat({ tostring(same), tostring(floats), tostring(side), tostring(diff) }, ',')`, []),
    'true,2,true,2',
    'the review opens TWO side-by-side FLOATS in the current tab')
  assert.equal(await lua(`require("dsh_tui").close_diff_split()
    return tostring(require("dsh_tui.state").diffSplit == nil)`, []),
    'true', 'the review closes and clears its state')
  // Opening the review must hand over in NORMAL mode with focus on the left
  // side. It is reached from the input box, which is in insert mode, and a new
  // float inherits it — so h/j/k/l were typed as text instead of moving (and the
  // edit keys are Nop'd, so the pane looked broken). The repo already documents
  // that `:stopinsert` can silently no-op after a focus switch, hence a real
  // <Esc>; this asserts the OBSERVABLE end state, which is what matters.
  assert.equal(await lua(`require("dsh_tui").show_diff_split('t', '/tmp/m.lua', 'a\\nb', 'a\\nB')
    local st = require("dsh_tui.state").diffSplit
    local out = {
      mode = vim.api.nvim_get_mode().mode,
      focusLeft = vim.api.nvim_get_current_win() == st.left,
    }
    require("dsh_tui").close_diff_split()
    return out.mode .. ',' .. tostring(out.focusLeft)`, []),
    'n,true', 'the review opens in NORMAL mode with focus on the left pane')

  // The review is READ-ONLY, like every other popup: `lock_popup_buffer` sets
  // 'nomodifiable' and Nops the edit + jumplist keys. Asserted by BEHAVIOUR, not
  // by reading the source — a diff side the user can type into would silently
  // turn a review into an edit.
  assert.equal(await lua(`require("dsh_tui").show_diff_split('t', '/tmp/z.lua', 'a\\nb', 'a\\nB')
    local st = require("dsh_tui.state").diffSplit
    local function nop(buf, k)
      for _, x in ipairs(vim.api.nvim_buf_get_keymap(buf, 'n')) do
        if x.lhs == k then return (x.rhs == nil or x.rhs == '') and 'nop' or (x.rhs or 'fn') end
      end
      return 'none'
    end
    local out = {
      nomod = (not vim.bo[st.lbuf].modifiable) and (not vim.bo[st.rbuf].modifiable),
      i = nop(st.lbuf, 'i') == 'nop',
      x = nop(st.lbuf, 'x') == 'nop',
      p = nop(st.rbuf, 'p') == 'nop',
      q = nop(st.lbuf, 'q') ~= 'nop',
    }
    -- A direct write must be refused outright.
    local ok = pcall(vim.api.nvim_buf_set_lines, st.lbuf, 0, 0, false, { 'X' })
    out.writeRefused = not ok
    require("dsh_tui").close_diff_split()
    return table.concat({ tostring(out.nomod), tostring(out.i), tostring(out.x), tostring(out.p), tostring(out.q), tostring(out.writeRefused) }, ',')`, []),
    'true,true,true,true,true,true',
    'both panes are read-only (nomodifiable + edit keys Nop) while close keys survive')
  // A deleted / brand-new side still yields both panes (nil is meaningful).
  assert.equal(await lua(`require("dsh_tui").show_diff_split('t', '/tmp/y', nil, 'new')
    local st = require("dsh_tui.state").diffSplit
    local n = 0
    for _, w in ipairs({ st.left, st.right }) do if vim.api.nvim_win_is_valid(w) then n = n + 1 end end
    require("dsh_tui").close_diff_split()
    return n`, []),
    2, 'a brand-new file (nil old side) still opens both panes')

  // Quota advice: the two codes mean DIFFERENT things, and a wrong mapping sends
  // the user to top up the wrong account — the exact mistake these codes exist to
  // prevent (`ACCOUNT_QUOTA` is added in 0.1.7-rc.2 for the account billing page;
  // plain `QUOTA` is the API key's own balance). Asserted directly because
  // dropping the code yields a message the user cannot act on.
  {
    assert.ok(quotaAdvice('ACCOUNT_QUOTA').includes('账号'), 'ACCOUNT_QUOTA points at the account')
    assert.ok(quotaAdvice('ACCOUNT_QUOTA').includes('不是 API Key'),
      'ACCOUNT_QUOTA explicitly rules OUT the API key (that is the whole point)')
    assert.ok(quotaAdvice('QUOTA').includes('API Key'), 'plain QUOTA points at the API key')
    assert.equal(quotaAdvice('ACCOUNT_QUOTA'), quotaAdvice('ACCOUNT_QUOTA'), 'mapping is stable')
    assert.equal(quotaAdvice(undefined), '', 'no code → no advice (never guess)')
    assert.equal(quotaAdvice('SOMETHING_ELSE'), '', 'an unknown code adds nothing')
  }

  // A tool whose outcome is UNKNOWN must not be shown as a plain failure: the
  // call may already have taken effect, and `✗` invites a blind retry of work
  // that already happened. dsh 0.2.0 gives this its own code and its repair docs
  // prescribe cause-specific retry guidance; our own tail repair emits it too.
  {
    assert.equal(failureMark('TOOL_OUTCOME_UNKNOWN'), 'unknown',
      'an unknown outcome is NOT rendered as a plain failure')
    assert.equal(failureMark('TOOL_NOT_STARTED'), 'failed',
      'a call that never started IS a plain failure (safe to retry)')
    assert.equal(failureMark(undefined), 'failed', 'no code → plain failure')
    assert.equal(failureMark('SOMETHING_ELSE'), 'failed', 'an unknown code is not special-cased')
  }

  // EVERY archive filter site must go through the predicate. A site left as a
  // bare `archived.has(…)` skip would still hide sessions in `all` mode — a
  // silent hole that no behavioural assertion above can see (the pure mapping
  // is correct either way). Measured: the browser has FIVE such sites.
  {
    const src = fs.readFileSync(path.join(process.cwd(), 'src/sessions/commands/sessions.ts'), 'utf8')
    const routed = (src.match(/archiveVisible\(archived\.has\(/g) ?? []).length
    // Every remaining `archived.has(` must be the argument of a routed call.
    const all = (src.match(/archived\.has\(/g) ?? []).length
    assert.equal(routed, all,
      'no archive filter site bypasses archiveVisible (a bare skip hides sessions in `all` mode)')
    assert.equal(routed, 5, 'all five filter sites are routed (update this if sites are added)')
  }

  // Archive visibility, three states. The subtle one is `only`: expressing it
  // by REMOVING ids from the archived set would leave live sessions listed, so
  // an "archived only" view would silently show the wrong thing. The mapping is
  // asserted for both input states in every mode.
  {
    for (const mode of ['hide', 'all', 'only'] as const) {
      const archivedVisible = archiveVisible(true, mode)
      const liveVisible = archiveVisible(false, mode)
      if (mode === 'hide') {
        assert.equal(archivedVisible, false, 'hide: archived sessions are hidden')
        assert.equal(liveVisible, true, 'hide: live sessions are shown')
      } else if (mode === 'all') {
        assert.equal(archivedVisible, true, 'all: archived sessions are shown')
        assert.equal(liveVisible, true, 'all: live sessions are shown')
      } else {
        assert.equal(archivedVisible, true, 'only: archived sessions are shown')
        assert.equal(liveVisible, false, 'only: LIVE sessions are hidden (the whole point)')
      }
    }
    // The cycle must visit all three and return home.
    let m = parseArchiveMode(undefined)
    assert.equal(m, 'hide', 'no argument keeps the historical default')
    const seen = new Set<string>([m])
    for (let i = 0; i < 3; i += 1) {
      m = nextArchiveMode(m)
      seen.add(m)
    }
    assert.deepEqual([...seen].sort(), ['all', 'hide', 'only'], 'the filter cycles through all three states')
    assert.equal(m, 'hide', 'the cycle returns to its start after three steps')
    // Argument parsing: words work, typos must not break the browser.
    assert.equal(parseArchiveMode('all'), 'all', '`all` selects every conversation')
    assert.equal(parseArchiveMode('ONLY'), 'only', 'parsing is case-insensitive')
    assert.equal(parseArchiveMode('nonsense'), 'hide', 'an unknown word falls back to the default (no error)')
  }

  // The change LEDGER accumulates; `recentDiffs` overwrites. That difference is
  // the feature, and it is exactly what a naive implementation gets wrong: a file
  // edited three times must count three edits and sum its line deltas, not show
  // the last shape three times over.
  {
    let led = new Map<string, ReturnType<typeof ledgerRows>[number]>()
    const at = 1000
    // Same path, three diffs.
    led = recordChange(led, { path: '/a.ts', oldText: 'x', newText: 'x\ny', added: 1, removed: 0, at })
    led = recordChange(led, { path: '/a.ts', oldText: 'x\ny', newText: 'x\ny\nz', added: 1, removed: 0, at: at + 1 })
    led = recordChange(led, { path: '/a.ts', oldText: 'x\ny\nz', newText: 'x', added: 0, removed: 2, at: at + 2 })
    // A different path, created.
    led = recordChange(led, { path: '/b.ts', oldText: undefined, newText: 'new', added: 1, removed: 0, at: at + 3 })

    const rows = ledgerRows(led)
    assert.equal(rows.length, 2, 'one ROW per path (three edits to /a.ts are one row)')
    const a = rows.find((r) => r.path === '/a.ts')
    assert.equal(a?.edits, 3, 'every touch is counted (recentDiffs would say 1)')
    assert.equal(a?.added, 2, 'added lines are SUMMED across diffs')
    assert.equal(a?.removed, 2, 'removed lines are summed too')
    assert.equal(a?.firstAt, at, 'firstAt is the FIRST touch')
    assert.equal(a?.lastAt, at + 2, 'lastAt is the LAST touch')
    assert.equal(a?.status, 'modified', 'an existing file stays `modified`')
    assert.equal(rows[0]?.path, '/b.ts', 'rows are newest-first (the order a review wants)')
    assert.equal(rows.find((r) => r.path === '/b.ts')?.status, 'added',
      'a file that did not exist before is `added`')

    // Summarisation rule, including the case a ternary chain got wrong: created
    // here and still here MUST read as `added`, not `modified`.
    assert.equal(summarize('added', 'modified'), 'added', 'created-then-edited is still `added`')
    assert.equal(summarize('added', 'added'), 'added', 'created once is `added`')
    assert.equal(summarize('modified', 'deleted'), 'deleted', 'gone now wins over modified')
    assert.equal(summarize('added', 'deleted'), 'deleted', 'created then removed reads `deleted`')
    assert.equal(summarize('modified', 'modified'), 'modified', 'plain edit is `modified`')

    // `null` and `undefined` both mean "that side was absent" — a missing key
    // must not be read as an empty file.
    assert.equal(changeStatus(undefined, 'x'), 'added', 'a missing old side means added')
    assert.equal(changeStatus(null, 'x'), 'added', 'a null old side means added too')
    assert.equal(changeStatus('x', undefined), 'deleted', 'a missing new side means deleted')
    assert.equal(changeStatus('x', 'y'), 'modified', 'both sides present means modified')

    // Totals.
    const tot = ledgerTotals(led)
    assert.equal(tot.files, 2, 'totals count paths, not edits')
    assert.equal(tot.added, 3, 'totals sum added lines')
    assert.equal(tot.removed, 2, 'totals sum removed lines')
  }

  // /changes hands off to /diff, so that command must EXIST under the name the
  // dispatcher looks up. Asserted through the real registration path, not a
  // fixture: a rename of either command would otherwise break the hand-off.
  {
    const specs: Array<{ name: string }> = []
    const stub = { registerCommands: (l: unknown[]) => { specs.push(...(l as typeof specs)) } } as never
    installChangesCommand(stub)
    installDiffCommand(stub)
    const names = specs.map((x) => x.name)
    assert.ok(names.includes('/changes'), '/changes registers its spec')
    assert.ok(names.includes('/diff'), '/diff registers its spec (the hand-off target)')
  }

  // Cross-command dispatch must match the REGISTERED name shape. Specs carry a
  // leading slash (`/diff`), and /changes used to call its dispatcher with a
  // bare `'diff …'` — the lookup returned undefined and the function returned
  // silently, so Enter in the changes list did nothing at all. Asserted at the
  // source level because the failure produced NO output to observe.
  {
    const src = fs.readFileSync(path.join(process.cwd(), 'src/commands/commands/changes.ts'), 'utf8')
    // Every dispatch target must be written WITH the slash.
    const bare = [...src.matchAll(/runSlash\(app, '([^']*)'/g)].map((m) => m[1] ?? '')
    assert.ok(bare.length > 0, '/changes dispatches to another command')
    const missingSlash = bare.filter((l) => !l.startsWith('/'))
    assert.deepEqual(missingSlash, [],
      'every dispatched command name starts with `/` (specs are registered that way)')
    // …and the dispatcher must not swallow a miss.
    assert.ok(/找不到命令/.test(src) || /no such command/.test(src),
      'a failed lookup is REPORTED, not silently returned')
  }

  // The OFFICIAL command registry is a second source, and the collision rule is
  // the whole safety property: a plugin registering `/sessions` must NOT take
  // over the TUI's own command. Asserted on the pure normaliser, both directions.
  {
    const listed = [
      { name: 'compact', description: 'compact the context' },
      { name: 'goal', description: 'manage the goal', input: { hint: '<text>' } },
      { name: 'sessions', description: 'a plugin trying to shadow ours' },
    ]
    const own = new Set(['/sessions', '/goal', '/exit'])
    const rows = officialRows(listed, own)
    assert.deepEqual(rows.map((r) => r.name), ['compact', 'goal', 'sessions'],
      'rows are name-sorted')
    assert.equal(rows.find((r) => r.name === 'sessions')?.shadowed, true,
      'a name the TUI owns is marked SHADOWED (the TUI keeps it)')
    assert.equal(rows.find((r) => r.name === 'goal')?.shadowed, true, 'the reverse also holds for a shared name')
    assert.equal(rows.find((r) => r.name === 'compact')?.shadowed, false,
      'a name the TUI does not own is NOT shadowed (it is reachable)')
    // A leading slash in the descriptor is normalised away — the registry
    // documents bare names, but tolerating the slash costs nothing.
    assert.equal(officialRows([{ name: '/dashed', description: 'd' }], new Set()).at(0)?.name, 'dashed',
      'a leading slash in a descriptor is normalised away')
    // An empty hint must not emit an `hint` key (it would render as a stray gap).
    assert.equal('hint' in (officialRows([{ name: 'x', description: 'd', input: { hint: '' } }], new Set()).at(0) ?? {}),
      false, 'an empty hint is omitted, not carried as an empty string')
    assert.equal(officialRows([{ name: 'y', description: 'd' }], new Set()).length, 1,
      'a descriptor without input still yields a row')
  }

  // The official runner must pass the line WITH its leading slash: the registry
  // parses the line itself (`parseCommand(line)`), so a bare name is an
  // admission miss. That miss is reported as such, never as a failure — and the
  // submit path must actually ASK the registry before saying "unknown command".
  {
    const stubApp = {
      svc: () => ({
        execute: (_a: unknown, line: string) => {
          seen.push(line)
          return Promise.resolve({ result: { kind: 'success', text: 'ok' } })
        },
      }),
      notice: () => {},
    } as never
    const seen: string[] = []
    assert.equal(await runOfficialCommand(stubApp, {}, '/kb'), true,
      'a slash-prefixed line is accepted')
    assert.deepEqual(seen, ['/kb'], 'the registry receives the line WITH its slash')
    seen.length = 0
    assert.equal(await runOfficialCommand(stubApp, {}, 'kb'), true,
      'a bare name is normalised rather than silently missing')
    assert.deepEqual(seen, ['/kb'], 'the normalised line carries the slash')
    // An admission miss is NOT a failure: the caller decides what to say.
    const declining = { svc: () => ({ execute: () => Promise.resolve(undefined) }), notice: () => {} } as never
    assert.equal(await runOfficialCommand(declining, {}, '/nope'), false,
      'a declined line reports false (not an error)')
    // No service → false, so the caller keeps its own "unknown command" notice.
    const bare = { svc: () => undefined, notice: () => {} } as never
    assert.equal(await runOfficialCommand(bare, {}, '/kb'), false,
      'without the registry the caller falls back to its own notice')
  }

  // Official commands MERGE into the same completion catalog — that is what makes
  // them complete on a leading `/`. Listing them in a separate command was not
  // enough: `/kb` could be listed and still not completed. Three rules are
  // asserted, because each one is a way this can silently go wrong.
  {
    const own = [
      { name: '/exit', desc: 'quit' },
      { name: '/sessions', desc: 'ours' },
    ]
    const listed = [
      { name: 'kb', description: 'knowledge base', input: { hint: 'index | search <词> | status' } },
      { name: 'sessions', description: 'a plugin trying to take over ours' },
      { name: 'bare', description: 'no hint declared' },
    ]
    const added = mergeOfficial(own, listed)
    assert.equal(added, 2, 'the colliding name is not added')
    const names = own.map((e) => e.name)
    assert.ok(names.includes('/kb'), 'an official command joins the catalog (so `/` completes it)')
    assert.equal(own.find((e) => e.name === '/sessions')?.desc, 'ours',
      'a name we already own is NOT overwritten — a plugin must not hijack the menu')
    // The hint becomes a `free` argument: shown, never completed. The official
    // side has no structured grammar, so fabricating choices would be a lie.
    const kb = own.find((e) => e.name === '/kb') as { args?: Array<{ kind: string; label?: string }> }
    assert.equal(kb.args?.at(0)?.kind, 'free', 'the official hint maps to a free-form argument')
    assert.equal(kb.args?.at(0)?.label, 'index | search <词> | status',
      'the declared hint becomes the argument label (what to type)')
    // No hint declared → NO argument invented.
    const bare = own.find((e) => e.name === '/bare') as { args?: unknown }
    assert.equal('args' in bare, false, 'a descriptor with no hint contributes no argument')
    // A leading slash in a descriptor is normalised, not doubled.
    const dashed: Array<{ name: string; desc: string }> = []
    mergeOfficial(dashed, [{ name: '/dashed', description: 'd' }])
    assert.deepEqual(dashed.map((e) => e.name), ['/dashed'], 'a descriptor slash is not doubled')
  }

  // /cwd — the session working directory (dsh 0.2.1's working_directory seam).
  // Three things can silently go wrong and all three look the same to the user:
  // the command not registering, a RELATIVE path not resolving against the
  // session dir (it must behave like `cd`), and a host WITHOUT the service being
  // reported as a failure instead of "unsupported".
  {
    // Registered? Assert on the WIRING, not on a running App: a command file that
    // exists but is never installed is exactly the failure this catches.
    const idx = fs.readFileSync('src/commands/index.ts', 'utf8')
    assert.ok(/installCwdCommand\(app\)/.test(idx), '/cwd is installed by the commands index')
    // The published grammar must NOT claim enumerable choices: a directory list
    // would be a lie, and completing it would fight the filesystem.
    const spec = COMMAND_ARGS['/cwd']
    assert.equal(spec?.[0]?.kind, 'free', 'a path argument is free text, never an enumeration')
    // A relative path resolves against the CURRENT dir — `cd` semantics.
    assert.equal(resolvePath('/a/b', 'c'), '/a/b/c', 'relative path resolves against the session dir')
    assert.equal(resolvePath('/a/b', '/x'), '/x', 'an absolute path is taken as-is')
    // Absent service (pre-0.2.1 host) is "unsupported", NOT a failure.
    const src = fs.readFileSync('src/commands/commands/cwd.ts', 'utf8')
    assert.ok(/没有 working_directory 服务/.test(src),
      'a host lacking the service is reported as unsupported, not as a failure')
  }

  // Command argument completion — the Lua side. Pushed through the SAME
  // set_commands path the runner uses, then asked what it would offer. A
  // regression here means the input box silently stops hinting.
  await lua(`require("dsh_tui").set_commands({
    { name = '/plugin', desc = 'x', args = {
        { kind = 'oneof', values = { 'install', 'update', 'remove', 'list' }, hint = 'h',
          byValue = {
            install = {
              { kind = 'free', label = '<spec>', hint = 'spec hint' },
              { kind = 'flag', value = '--latest', hint = 'f' },
            },
            update = {
              { kind = 'free', label = '<spec>', hint = 'spec hint' },
              { kind = 'flag', value = '--latest', hint = 'f' },
            },
            remove = {
              { kind = 'free', label = '<spec>', hint = 'spec hint' },
              { kind = 'flag', value = '--latest', hint = 'f' },
            },
            list = {},
          } },
    } },
    { name = '/nometa', desc = 'y' },
  })`, [])
  assert.equal(await lua('return type(require("dsh_tui.cmd_menu").suggest)', []), 'function', 'CM.suggest exists')
  assert.equal(await lua('return type(require("dsh_tui.cmd_menu").hint)', []), 'function', 'CM.hint exists')
  // After the command name + space the subcommands are offered.
  assert.equal(await lua('local s = require("dsh_tui.cmd_menu").suggest("/plugin ") return s and #s.values or -1', []),
    4, 'a bare /plugin offers its four subcommands')
  // Narrowing by prefix.
  assert.equal(await lua('local s = require("dsh_tui.cmd_menu").suggest("/plugin re") return s and s.values[1] or "nil"', []),
    'remove', 'prefix narrows the candidates')
  // The next argument is free-form: hinted, never completed.
  assert.equal(await lua('local s = require("dsh_tui.cmd_menu").suggest("/plugin install ") return s and #s.values or -1', []),
    0, 'a free-form argument offers no candidates')
  assert.equal(await lua('return require("dsh_tui.cmd_menu").hint("/plugin install ")', []),
    '<spec>   spec hint', 'the free-form argument shows its label + hint')
  // Flags are position-INDEPENDENT: `--latest` is typed after the spec, i.e. one
  // slot past where it is declared. Measured requirement.
  assert.equal(await lua('local s = require("dsh_tui.cmd_menu").suggest("/plugin install foo --") return s and s.values[1] or "nil"', []),
    '--latest', 'a flag is offered even one argument slot later')
  // A TERMINAL subcommand must go quiet: `list` takes no arguments, so neither
  // the menu nor the hint may ask for more. (Measured misfire: the flat version
  // kept offering the four subcommands and repeating the usage line here.)
  assert.equal(await lua('local s = require("dsh_tui.cmd_menu").suggest("/plugin list ") return s and #s.values or -1', []),
    0, 'a terminal subcommand offers no candidates')
  assert.equal(await lua('return tostring(require("dsh_tui.cmd_menu").hint("/plugin list "))', []),
    'nil', 'a terminal subcommand shows no hint (no misleading "type more")')
  // …and it must not leak the subcommand menu either.
  assert.equal(await lua(`local I = require("dsh_tui.input")
    I.set_text('/plugin list ')
    require("dsh_tui.cmd_menu").update('/plugin list ')
    return require("dsh_tui.cmd_menu").state().open`, []),
    false, 'a terminal subcommand closes the menu')
  // The branch's OWN first argument is what applies after a subcommand.
  assert.equal(await lua('return require("dsh_tui.cmd_menu").hint("/plugin install ")', []),
    '<spec>   spec hint', 'after install the SPEC is what applies (not the flag)')

  // Commands without metadata must not be touched at all.
  assert.equal(await lua('return tostring(require("dsh_tui.cmd_menu").hint("/nometa "))', []),
    'nil', 'a command without args metadata produces no hint')
  // Argument mode must reuse the MENU (the user asked for the same popup as
  // command completion, not just a hint line). `CM.update` past the command
  // name is what the input box calls on every keystroke.
  assert.equal(await lua(`require("dsh_tui").set_commands({
    { name = '/plugin', desc = 'x', args = {
        { kind = 'oneof', values = { 'install', 'update', 'remove', 'list' }, hint = 'h' },
        { kind = 'free', label = '<spec>', hint = 'spec hint' },
    } },
  })` + ' return true', []), true, 'argument catalog pushed')
  assert.equal(await lua(`local I = require("dsh_tui.input")
    I.set_text('/plugin ')
    require("dsh_tui.cmd_menu").update('/plugin ')
    local st = require("dsh_tui.cmd_menu").state()
    return st.open and #require("dsh_tui.state").cmdMatches or 0`, []),
    4, 'a space after the command name opens the subcommand menu')
  assert.equal(await lua(`local I = require("dsh_tui.input")
    I.set_text('/plugin in')
    require("dsh_tui.cmd_menu").update('/plugin in')
    local S = require("dsh_tui.state")
    return tostring(S.cmdArgMode) .. '/' .. tostring(#S.cmdMatches)`, []),
    'true/1', 'typing a prefix narrows the subcommand menu (argument mode on)')
  // A free-form argument has no candidates: the menu must CLOSE rather than show
  // an empty box.
  assert.equal(await lua(`local I = require("dsh_tui.input")
    I.set_text('/plugin install ')
    require("dsh_tui.cmd_menu").update('/plugin install ')
    return require("dsh_tui.cmd_menu").state().open`, []),
    false, 'a free-form argument closes the menu (hint-only)')
  await lua(`require("dsh_tui").set_commands({ { name = '/exit', desc = 'exit' } })`, [])


  // 9l. bell + file tab + append_input helpers.
  // The terminal bell / OSC notification feature was REMOVED: the plugin's nvim
  // runs `--embed`, so its stdout is the RPC socket — no escape written from
  // Lua can reach the terminal, and attempting it destroyed the display.
  // NOTE: in Lua `nil == nil` is TRUE, so comparing the field to nil asserts
  // nothing — ask for its TYPE instead (absence reads as "nil").
  assert.equal(await lua('return type(require("dsh_tui").bell)', []), 'nil', 'bell() is gone (removed, not merely guarded)')
  assert.equal(await lua('return type(require("dsh_tui.rpc").notify)', []), 'nil', 'R.notify is gone')
  assert.equal(await lua('return type(require("dsh_tui.rpc").notify_capability)', []), 'nil', 'R.notify_capability is gone')
  // …and nothing else in rpc.lua may write raw bytes to stdout again.
  const rpcLua = fs.readFileSync(path.join(process.cwd(), 'nvim/lua/dsh_tui/rpc.lua'), 'utf8')
  assert.ok(!/io\.stdout:write/.test(rpcLua), 'rpc.lua no longer writes escapes to stdout')
  const tabCountBefore = await lua('return vim.fn.tabpagenr("$")', [])
  const okTab = await lua('return require("dsh_tui").open_file_tab(...)', [process.cwd() + '/package.json'])
  assert.equal(okTab, true, 'file tab opens')
  assert.equal(await lua('return vim.fn.tabpagenr("$")', []), tabCountBefore + 1, 'new tabpage created')
  await nvim.request('nvim_command', ['tabclose'])
  await nvim.request('nvim_buf_set_lines', [ids.inputBuf, 0, -1, false, ['hi']])
  // insert-mode cursor accepts the end position (col 2 = after 'i'); the
  // test drives the @-accept path, which always runs with insert active
  await lua(`local ids = require("dsh_tui").ids(); vim.api.nvim_set_current_win(ids.inputWin); vim.cmd('startinsert')`, [])
  await nvim.request('nvim_win_set_cursor', [ids.inputWin, [1, 2]])
  await lua('require("dsh_tui").append_input(...)', ['@note '])
  const appended = await nvim.request('nvim_buf_get_lines', [ids.inputBuf, 0, -1, false])
  assert.equal(appended[0], 'hi@note ', 'append_input inserts at cursor')
  await nvim.request('nvim_buf_set_lines', [ids.inputBuf, 0, -1, false, ['']])

  // 9m. empty-state hero + whale: a feed holding ONLY notice lines (boot
  // banner, "session X" notices) is still empty — the hero renders, the
  // notices ride below it; any real content hides the hero.
  const whaleChat = await nvim.lua('return require("dsh_tui").ensure_chat(...)', ['session-whale']) as { chatBuf: number; chatWin: number }
  const heroStateFeed = new FeedRenderer(nvim, whaleChat.chatBuf, whaleChat.chatWin, {
    activeChecker: () => true,
    whale: true,
    welcome: () => ({
      above: [{ text: '▄███▄ HERO-BANNER' }],
      below: [{ text: 'usage hint line' }],
    }),
  })
  heroStateFeed.appendNotice('boot banner notice')
  await heroStateFeed.flush()
  let heroStateLines = await nvim.request('nvim_buf_get_lines', [whaleChat.chatBuf, 0, -1, false])
  log('whale empty-state:', JSON.stringify(heroStateLines.filter((l: string) => l.trim() !== '').slice(0, 8)))
  assert.ok(heroStateLines.some((l: string) => l.includes('HERO-BANNER')), 'hero renders with only a banner notice')
  assert.ok(heroStateLines.some((l: string) => l.includes('boot banner notice')), 'banner notice stays visible below the hero')
  assert.ok(heroStateLines.some((l: string) => l.includes('usage hint line')), 'usage hints render')
  heroStateFeed.pushUser('你好', [])
  await heroStateFeed.flush()
  heroStateLines = await nvim.request('nvim_buf_get_lines', [whaleChat.chatBuf, 0, -1, false])
  assert.ok(!heroStateLines.some((l: string) => l.includes('HERO-BANNER')), 'hero hides once real content exists')
  heroStateFeed.setWhale(false) // stop the animation interval
  await heroStateFeed.flush()

  nvim.off('notification', onNote)

  // 10. statusline/completion opt-outs (user plugins must not take over)
  await lua('require("dsh_tui").disable_external_completion()', [])
  const opt = await lua(`local ib = require("dsh_tui").ids().inputBuf
    return vim.api.nvim_buf_call(ib, function()
      return {
        ministatusline_disable = vim.b.ministatusline_disable,
        complete = vim.bo.completefunc,
        omni = vim.bo.omnifunc,
      }
    end)`, [])
  log('after disable:', JSON.stringify(opt))
  assert.equal(opt.ministatusline_disable, true, 'input buffer opts out of mini.statusline')
  assert.equal(opt.complete, '', 'completefunc cleared')
  assert.equal(opt.omni, '', 'omnifunc cleared')

  // 11. statusline ownership: survives plugin clobbering on window switches
  await lua('require("dsh_tui").set_statusline(...)', ['%#DshTuiStatus# TEST-LEFT %= TEST-RIGHT '])
  let sl = await lua('return vim.api.nvim_win_get_option(require("dsh_tui").ids().chatWin, "statusline")', [])
  assert.ok(sl.includes('TEST-LEFT'), 'statusline applied to chat window')
  // simulate a statusline plugin rewriting the option on WinEnter
  await lua('vim.api.nvim_win_set_option(require("dsh_tui").ids().chatWin, "statusline", "")', [])
  await lua('require("dsh_tui").reschedule_statusline()', [])
  await new Promise((r) => setTimeout(r, 80))
  sl = await lua('return vim.api.nvim_win_get_option(require("dsh_tui").ids().chatWin, "statusline")', [])
  assert.ok(sl.includes('TEST-LEFT'), 'statusline restored after plugin clobber')
  // global mini.statusline opt-out for the TUI instance
  const g = await lua('return vim.g.ministatusline_disable', [])
  assert.equal(g, true, 'global mini.statusline disable set')

  // 12. window statuslines: input framed, reasoning seamless
  const ids12 = await lua('return require("dsh_tui").ids()', [])
  const slInput = await lua('return vim.api.nvim_win_get_option(require("dsh_tui").ids().inputWin, "statusline")', [])
  assert.ok(slInput.includes('Enter 发送'), 'input window has a styled helper bar')
  assert.ok(!slInput.includes('❯'), 'prompt moved OUT of the input statusline')
  assert.ok(!slInput.includes('StatusLineNC'), 'no raw StatusLineNC block')
  // input FRAME: the hint bar doubles as the bottom edge — ╰ corner first
  // (hints stay left-aligned with the input box), ─╯ at the far right.
  assert.ok(slInput.startsWith('%#DshTuiBorder#╰─%#DshTuiStatus# Enter 发送'), 'hint bar opens the frame bottom edge (╰─ connects to the hints)')
  assert.ok(slInput.includes('%#DshTuiStatus# Enter 发送'), 'hints are left-aligned (aligned with the input box)')
  assert.ok(slInput.includes('%#DshTuiBorder#%=─╯'), 'frame bottom-right corner sits at the far right edge')
  const inputFill = await lua('return vim.wo[require("dsh_tui").ids().inputWin].fillchars', [])
  assert.ok(String(inputFill).includes('stl:─'), 'bottom edge fills the gap with ─ (continuous border)')
  // The '❯' prompt lives in the status COLUMN: visual only, never part of
  // the submitted text, never deletable. The column also carries the frame's
  // LEFT edge (│), and the winbar draws the TOP edge (╭─╮).
  const promptCol = await lua('return vim.wo[require("dsh_tui").ids().inputWin].statuscolumn', [])
  assert.ok(promptCol.includes('❯'), 'input status column carries the ❯ prompt')
  assert.ok(promptCol.includes('│'), 'input status column carries the frame left edge')
  const winbar = await lua('return vim.api.nvim_win_get_option(require("dsh_tui").ids().inputWin, "winbar")', [])
  assert.ok(winbar.includes('╭') && winbar.includes('╮'), 'input winbar draws the frame top edge')
  assert.equal(ids12.sessionsWin, undefined, 'no sessions window in ids (float only)')
  // Plain-content groups FOLLOW the theme's Comment (the pre-regression dim
  // tone); a bright Comment triggers the blend fallback instead.
  const dims = await lua(`local out = {}
    for _, g in ipairs({ 'DshTuiAssistant', 'DshTuiReasoning', 'DshTuiNotice', 'DshTuiDivider', 'DshTuiCmdDesc' }) do
      local hl = vim.api.nvim_get_hl(0, { name = g })
      out[g] = { fg = hl.fg, link = hl.link }
    end
    return out`, [])
  for (const g of ['DshTuiAssistant', 'DshTuiReasoning', 'DshTuiNotice', 'DshTuiDivider', 'DshTuiCmdDesc']) {
    assert.equal(dims[g].link, 'Comment', g + ' follows the theme Comment link')
  }
  const ffHl = await lua('return vim.api.nvim_get_hl(0, { name = "FloatFooter" })', [])
  assert.equal(ffHl.link, 'DshTuiStatus', 'embedded popup footer keeps the statusline look')
  const popupBg = await lua(`local hex = function(c) return type(c) == 'number' and c or nil end
    return {
      ref = hex(vim.api.nvim_get_hl(0, { name = 'DshTuiBorder', link = false }).bg), -- = editor bg (with fallback)
      nf = hex(vim.api.nvim_get_hl(0, { name = 'NormalFloat', link = false }).bg),
      fb = hex(vim.api.nvim_get_hl(0, { name = 'FloatBorder', link = false }).bg),
    }`, [])
  assert.ok(popupBg.nf != null, 'popup surface gets an explicit background')
  assert.equal(popupBg.nf, popupBg.ref, 'popup surface matches the editor background')
  assert.equal(popupBg.fb, popupBg.ref, 'popup border background matches the editor background')
  // syntax highlighting helpers: fence-language → filetype normalization +
  // no-crash without treesitter (headless smoke env has no user config)
  const ftMap = await lua(`local M = require("dsh_tui")
    return {
      py = M.syntax_ft('py'), js = M.syntax_ft('js'), ts = M.syntax_ft('ts'),
      yml = M.syntax_ft('yml'), sh = M.syntax_ft('bash'), md = M.syntax_ft('markdown'),
      empty = M.syntax_ft(''), junk = M.syntax_ft('zzz-nope'),
    }`, [])
  assert.equal(ftMap.py, 'python', 'py fence → python')
  assert.equal(ftMap.js, 'javascript', 'js fence → javascript')
  assert.equal(ftMap.ts, 'typescript', 'ts fence → typescript')
  assert.equal(ftMap.yml, 'yaml', 'yml fence → yaml')
  assert.equal(ftMap.sh, 'sh', 'bash fence → sh')
  assert.equal(ftMap.md, 'markdown', 'markdown fence → markdown')
  assert.equal(await lua('return require("dsh_tui").syntax_ft("python")', []), 'python', 'full python name maps')
  assert.equal(await lua('return require("dsh_tui").syntax_ft("typescript")', []), 'typescript', 'full typescript name maps')
  assert.equal(await lua('return require("dsh_tui").syntax_ft("php")', []), 'php_only', 'php maps to the code grammar (php = phpdoc)')
  assert.ok(ftMap.empty == null, 'empty lang → nil')
  assert.ok(ftMap.junk == null, 'unknown lang without parser → nil')
  // fenced blocks render markdown-style: no raw ``` markers in the chat, the
  // opening fence becomes a dim language chip
  feedA.applyEvent({ type: 'assistant/chunk', data: { chunk: { type: 'text-delta', text: '\nsee:\n```ts\nconst x: number = 1\n```\n' } } })
  await new Promise((r) => setTimeout(r, 700))
  const fencedLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  assert.ok(!fencedLines.includes('```ts') && !fencedLines.includes('```'), 'raw fence markers stripped from the chat')
  assert.ok(fencedLines.includes('▸ ts'), 'opening fence renders as a language chip')
  assert.ok(fencedLines.includes('const x: number = 1'), 'fenced code content kept')
  const hlOk = await lua(`local ok, err = pcall(require("dsh_tui").highlight_syntax,
    vim.api.nvim_get_current_buf(), vim.api.nvim_create_namespace('smoke-ts'),
    {{ lang = 'python', row = 0, col = 0, lines = { 'def f():' } }})
    return { ok = ok, err = tostring(err) }`, [])
  assert.equal(hlOk.ok, true, 'highlight_syntax never throws (no treesitter → flat fallback)')
  const diffHl = await lua('return { add = vim.api.nvim_get_hl(0, { name = "DshTuiDiffAdd" }), del = vim.api.nvim_get_hl(0, { name = "DshTuiDiffDel" }) }', [])
  assert.equal(diffHl.add.fg, undefined, 'diff add group carries NO fg (text color belongs to syntax tokens)')
  assert.equal(diffHl.del.fg, undefined, 'diff del group carries NO fg (text color belongs to syntax tokens)')
  assert.equal(typeof diffHl.add.bg, 'number', 'diff add row carries a background fill')
  assert.equal(typeof diffHl.del.bg, 'number', 'diff del row carries a background fill')
  const inputWinhl = await lua('return vim.wo[require("dsh_tui").ids().inputWin].winhl', [])
  assert.ok(inputWinhl.includes('Normal:DshTuiDim'), 'input window dims typed text')
  // terminal title: nvim owns the terminal and emits the OSC 2 title itself
  await lua('require("dsh_tui").set_title("测试会话")', [])
  const title = await lua('return { t = vim.o.title, ts = vim.o.titlestring }', [])
  assert.equal(title.t, true, 'nvim emits the terminal title')
  assert.ok(title.ts.includes('测试会话'), 'titlestring carries the session title')
  // layout: no dead rows — the cmdline is reclaimed and the chat sits flush
  // against the input (exactly the statusline row between them), even after
  // an input grow/shrink round-trip.
  const layoutProbe = () => lua(`local ids = require('dsh_tui').ids()
    return {
      cmdheight = vim.o.cmdheight,
      chatEnd = vim.api.nvim_win_get_position(ids.chatWin)[1] + vim.api.nvim_win_get_height(ids.chatWin),
      inputTop = vim.api.nvim_win_get_position(ids.inputWin)[1],
      inputH = vim.api.nvim_win_get_height(ids.inputWin),
    }`, [])
  const layoutBefore = await layoutProbe()
  assert.equal(layoutBefore.cmdheight, 0, 'cmdline row reclaimed')
  assert.equal(layoutBefore.inputTop - layoutBefore.chatEnd, 1, 'chat flush above the input (statusline only)')
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "a", "b", "c" }); require("dsh_tui").resize_input()`, [])
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "" }); require("dsh_tui").resize_input()`, [])
  const layoutAfter = await layoutProbe()
  assert.equal(layoutAfter.inputTop - layoutAfter.chatEnd, 1, 'no dead row after input grow/shrink round-trip')
  assert.equal(layoutAfter.inputH, 2, 'input back to one text row after round-trip (winbar + text)')
  // frame RIGHT edge: one right-aligned │ mark per input row, re-synced on
  // row changes (multi-line input grows the frame, not the gutter).
  const frameMarks = () => lua(`return vim.api.nvim_buf_get_extmarks(require("dsh_tui").ids().inputBuf, require("dsh_tui")._frameNs, 0, -1, { details = false })`, [])
  let fm = await frameMarks()
  assert.equal(fm.length, 1, 'one right-edge frame mark per input row')
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "a", "b" }); require("dsh_tui").resize_input()`, [])
  fm = await frameMarks()
  assert.equal(fm.length, 2, 'frame marks follow multi-line input')
  // viewport: after a grow, the topline snaps back to 1 — the new row must
  // render inside the frame, not as a leftover `~` beyond-EOF row without │❯
  const w0 = await lua(`local ids = require('dsh_tui').ids()
    return vim.api.nvim_win_call(ids.inputWin, function() return vim.fn.line('w0') end)`, [])
  assert.equal(w0, 1, 'input viewport snaps to the first line after a grow')
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "" }); require("dsh_tui").resize_input()`, [])
  // tabline flash regression: a plugin flipping showtabline=2 mid-startup
  // (bufferline) used to redistribute a row into the input window — the
  // extra blank row that vanished on the first keystroke — and the old
  // OptionSet guard blanked the input's winbar (the frame's top edge).
  await lua('vim.o.showtabline = 2', [])
  await new Promise((r) => setTimeout(r, 150))
  const flashProbe = await lua(`local ids = require('dsh_tui').ids()
    local ip = vim.api.nvim_win_get_position(ids.inputWin)
    return {
      showtabline = vim.o.showtabline,
      inputH = vim.api.nvim_win_get_height(ids.inputWin),
      winbar = vim.api.nvim_win_get_option(ids.inputWin, 'winbar'),
      slack = vim.o.lines - vim.o.cmdheight - (ip[1] + vim.api.nvim_win_get_height(ids.inputWin) + 1),
      winfixheight = vim.wo[ids.inputWin].winfixheight,
    }`, [])
  assert.equal(flashProbe.showtabline, 0, 'tabline flash snapped back to hidden')
  assert.equal(flashProbe.inputH, 2, 'input keeps its rows through a tabline flash')
  assert.ok(String(flashProbe.winbar).includes('╭'), 'input winbar survives a tabline flash')
  assert.equal(flashProbe.slack, 0, 'no stray rows below the input after a tabline flash')
  assert.equal(flashProbe.winfixheight, true, 'input window height is fixed')
  // empty-Enter regression: the <Cmd> mapping's hidden cmdline clears the
  // last screen row (the helper bar, cmdheight=0) — submit() must leave the
  // window chrome intact (the scheduled redraw re-paints it)
  await lua('require("dsh_tui").submit()', [])
  await new Promise((r) => setTimeout(r, 80))
  const slAfterEmptySubmit = await lua('return vim.api.nvim_win_get_option(require("dsh_tui").ids().inputWin, "statusline")', [])
  assert.ok(String(slAfterEmptySubmit).includes('Enter 发送'), 'empty submit keeps the helper bar option')

  // 12b. input-window hardening: ZZ inert, no clones, mode preserved, auto-restore
  await lua(`local ids = require("dsh_tui").ids()
    vim.api.nvim_set_current_win(ids.inputWin)
    vim.cmd('startinsert')`, [])
  await new Promise((r) => setTimeout(r, 80))
  log('12b-EARLY INSERT MODE:', await lua('return vim.api.nvim_get_mode().mode .. " insertmode=" .. tostring(vim.o.insertmode)', []))
  const zzMap = await lua(`local out = {}
    for _, m in ipairs(vim.api.nvim_buf_get_keymap(require("dsh_tui").ids().inputBuf, "n")) do
      out[m.lhs] = m.rhs
    end
    return out`, [])
  assert.ok(zzMap.ZZ !== undefined && zzMap.ZZ === '', 'ZZ is inert on the input buffer')
  assert.ok(zzMap.ZQ !== undefined && zzMap.ZQ === '', 'ZQ is inert on the input buffer')
  // window navigation preserves the mode (no forced insert on WinEnter)
  await lua(`vim.api.nvim_set_current_win(require("dsh_tui").ids().inputWin)
    vim.cmd('stopinsert')
    vim.api.nvim_set_current_win(require("dsh_tui").ids().chatWin)
    vim.api.nvim_set_current_win(require("dsh_tui").ids().inputWin)`, [])
  await new Promise((r) => setTimeout(r, 80))
  assert.equal((await lua('return vim.api.nvim_get_mode().mode', [])), 'n',
    'switching back to the input keeps normal mode')
  await lua(`vim.api.nvim_set_current_win(require("dsh_tui").ids().inputWin); vim.cmd('startinsert')`, [])
  await new Promise((r) => setTimeout(r, 80))
  log('BISECT after-mode-test:', await lua('return vim.api.nvim_get_mode().mode', []))
  await lua(`vim.cmd('stopinsert')`, [])
  // :sp from the input must not create a synced clone
  const winsBeforeSp = (await lua('return vim.api.nvim_list_wins()', [])).length
  await lua(`vim.api.nvim_set_current_win(require("dsh_tui").ids().inputWin); vim.cmd('sp')`, [])
  await new Promise((r) => setTimeout(r, 120))
  const clones = await lua(`local ids = require("dsh_tui").ids()
    local n = 0
    for _, w in ipairs(vim.api.nvim_list_wins()) do
      if w ~= ids.inputWin and vim.api.nvim_win_get_buf(w) == ids.inputBuf then n = n + 1 end
    end
    return n`, [])
  assert.equal(clones, 0, ':sp from the input leaves no buffer clone')
  assert.equal((await lua('return vim.api.nvim_list_wins()', [])).length, winsBeforeSp, 'no stray window after :sp')
  await lua(`vim.api.nvim_set_current_win(require("dsh_tui").ids().inputWin); vim.cmd('startinsert')`, [])
  await new Promise((r) => setTimeout(r, 80))
  log('BISECT after-sp:', await lua('return vim.api.nvim_get_mode().mode', []))
  await lua(`vim.cmd('stopinsert')`, [])
  // closing the input window (ZZ path's worst case) auto-restores it
  const oldInputWin = await lua('return require("dsh_tui").ids().inputWin', [])
  await lua('vim.api.nvim_win_close(...)', [oldInputWin, true])
  await new Promise((r) => setTimeout(r, 700))
  const restored = await lua(`local ids = require("dsh_tui").ids()
    return {
      valid = vim.api.nvim_win_is_valid(ids.inputWin),
      buf = vim.api.nvim_win_get_buf(ids.inputWin),
      inputBuf = ids.inputBuf,
      mode = vim.api.nvim_get_mode().mode,
    }`, [])
  assert.equal(restored.valid, true, 'closed input window auto-restores')
  assert.equal(restored.buf, restored.inputBuf, 'restored window shows the input buffer')
  assert.equal(restored.mode, 'i', 'restored input starts in insert mode')
  // ModeChanged enforcement: statusline plugins rewrite on mode flips
  // (pressing i in the input used to wipe the frame + hint bar)
  await lua(`vim.api.nvim_win_set_option(require("dsh_tui").ids().inputWin, "statusline", "")`, [])
  await lua(`vim.cmd('doautocmd ModeChanged n:i')`, [])
  await new Promise((r) => setTimeout(r, 80))
  const slAfterMode = await lua('return vim.api.nvim_win_get_option(require("dsh_tui").ids().inputWin, "statusline")', [])
  assert.ok(String(slAfterMode).includes('Enter 发送'), 'ModeChanged re-asserts the hint bar')
  // display buffers never stay in insert mode (mouse click drags the state)
  await lua(`vim.api.nvim_set_current_win(require("dsh_tui").ids().chatWin)`, [])
  await lua('vim.api.nvim_input("i")', [])
  await new Promise((r) => setTimeout(r, 120))
  assert.equal((await lua('return vim.api.nvim_get_mode().mode', [])), 'n',
    'chat buffer snaps back to normal mode')
  await lua(`vim.api.nvim_set_current_win(require("dsh_tui").ids().inputWin)`, [])
  const dimHl = await lua('return vim.api.nvim_get_hl(0, { name = "DshTuiDim" })', [])
  assert.equal(dimHl.link, 'Comment', 'DshTuiDim follows the theme Comment')
  // popup surfaces sit flat on the editor background: title included — some
  // themes give FloatTitle a literal black bg (a dark block behind titles)
  const flatHl = await lua(`return {
    nf = vim.api.nvim_get_hl(0, { name = "NormalFloat", link = false }).bg,
    fb = vim.api.nvim_get_hl(0, { name = "FloatBorder", link = false }).bg,
    ft = vim.api.nvim_get_hl(0, { name = "FloatTitle", link = false }).bg,
  }`, [])
  assert.equal(flatHl.fb, flatHl.nf, 'popup border background follows the float surface')
  assert.equal(flatHl.ft, flatHl.nf, 'popup title background follows the float surface (no black block)')
  // a colorscheme (re)applied late must not wash the palette back to white
  await lua('vim.cmd("colorscheme default")', [])
  await new Promise((r) => setTimeout(r, 100))
  const asstAfter = await lua('return vim.api.nvim_get_hl(0, { name = "DshTuiAssistant" })', [])
  assert.equal(asstAfter.link, 'Comment', 'palette survives colorscheme re-application')
  // the WHOLE highlight set (role links included) restores after a wipe —
  // lazy colorschemes run `hi clear` late and used to turn everything white
  await lua('vim.cmd("highlight clear"); require("dsh_tui").applyHighlights()', [])
  const afterWipe = await lua(`return {
    user = vim.api.nvim_get_hl(0, { name = "DshTuiUser" }),
    asst = vim.api.nvim_get_hl(0, { name = "DshTuiAssistant" }),
    tool = vim.api.nvim_get_hl(0, { name = "DshTuiTool" }),
  }`, [])
  assert.equal(afterWipe.user.link, 'MoreMsg', 'user-message link restored after wipe')
  assert.equal(afterWipe.tool.link, 'Special', 'tool link restored after wipe')
  assert.equal(afterWipe.asst.link, 'Comment', 'assistant dim link restored after wipe')
  // a BRIGHT Comment (white-Comment themes) falls back to the blended gray
  await lua(`vim.api.nvim_set_hl(0, 'Comment', { fg = 0xffffff })
    require("dsh_tui").applyDimPalette()`, [])
  const fallbackAsst = await lua('return vim.api.nvim_get_hl(0, { name = "DshTuiAssistant" })', [])
  assert.equal(typeof fallbackAsst.fg, 'number', 'bright Comment falls back to blended dim fg')
  assert.equal(fallbackAsst.link, undefined, 'fallback clears the Comment link')
  await lua('vim.cmd("colorscheme default")', [])
  await new Promise((r) => setTimeout(r, 100))
  // DshTuiStatus must carry an explicit background (equal to Normal's) —
  // a bold-only group would fall back to the theme's StatusLine bg (white bar).
  const st = await lua(`local n = vim.api.nvim_get_hl(0, { name = 'Normal' })
    local sl = vim.api.nvim_get_hl(0, { name = 'StatusLine' })
    local s = vim.api.nvim_get_hl(0, { name = 'DshTuiStatus' })
    return { status_bg = s.bg, normal_bg = n.bg, fg = s.fg, statusline_fg = sl.fg, bold = s.bold }`, [])
  assert.equal(st.status_bg, st.normal_bg, 'DshTuiStatus bg matches Normal bg')
  const fills = await lua(`local n = vim.api.nvim_get_hl(0, { name = 'Normal' })
    local a = vim.api.nvim_get_hl(0, { name = 'StatusLine' })
    local i = vim.api.nvim_get_hl(0, { name = 'StatusLineNC' })
    return { active = a.bg, inactive = i.bg, normal = n.bg }`, [])
  assert.equal(fills.active, fills.normal, 'StatusLine (active) fill = editor bg')
  assert.equal(fills.inactive, fills.normal, 'StatusLineNC (inactive) fill = editor bg')
  assert.equal(typeof st.fg, 'number', 'DshTuiStatus fg is a color')
  assert.equal(st.bold, true, 'DshTuiStatus keeps bold')

  // 13. theme overrides (M5)
  await lua(`require("dsh_tui").apply_theme({
    DshTuiUser = { fg = "#ff0000", bold = true },
    DshTuiTool = { link = "WarningMsg" },
  })`, [])
  const userHl = await lua('return vim.api.nvim_get_hl(0, { name = "DshTuiUser" })', [])
  assert.equal(userHl.fg, 16711680, 'theme fg applied') // 0xff0000
  assert.equal(userHl.bold, true, 'theme bold applied')
  const toolHl = await lua('return vim.api.nvim_get_hl(0, { name = "DshTuiTool" })', [])
  assert.equal(typeof toolHl.link, 'string', 'theme link applied')

  // 10a. P2: CJK typed input via nvim_input (IME path) + large-message
  // flush performance sanity.
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "" })
    vim.api.nvim_set_current_win(require("dsh_tui").ids().inputWin); vim.cmd("startinsert")`, [])
  await nvim.request('nvim_input', ['中文输入测试 ime-check'])
  await new Promise((r) => setTimeout(r, 120))
  const typed = await lua('return table.concat(vim.api.nvim_buf_get_lines(require("dsh_tui").ids().inputBuf, 0, -1, false), "\\n")', [])
  assert.ok(typed.includes('中文输入测试 ime-check'), 'CJK text typed through nvim_input lands in the input buffer')
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "" })`, [])

  const bigText = Array.from({ length: 400 }, (_, i) => `第 ${i} 行 · 性能压测内容 performance sanity check`).join('\n')
  const t0 = Date.now()
  feedB.applyEvent({ type: 'assistant/message', time: 7500, data: { turn: 4, step: 1, message: { content: [{ type: 'text', text: bigText }] } } })
  for (let i = 0; i < 100; i++) {
    const lines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
    if (lines.some((l: string) => l.includes('第 399 行'))) break
    await new Promise((r) => setTimeout(r, 40))
  }
  const elapsed = Date.now() - t0
  assert.ok(elapsed < 2500, `400-line message flushed in ${elapsed}ms (< 2500ms)`)
  const bigLines = await nvim.request('nvim_buf_get_lines', [chatB.chatBuf, 0, -1, false])
  assert.ok(bigLines.some((l: string) => l.includes('第 399 行')), 'large message fully rendered')

  // 10b. image helpers (multimodal input path)
  assert.equal(sniffMediaType(new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a])), 'image/png', 'png sniffed')
  assert.equal(sniffMediaType(new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 0x00])), 'image/jpeg', 'jpeg sniffed')
  assert.equal(sniffMediaType(new Uint8Array([0x47, 0x49, 0x46, 0x38, 0x39, 0x61])), 'image/gif', 'gif sniffed')
  assert.equal(sniffMediaType(new Uint8Array([0x52, 0x49, 0x46, 0x46, 0x24, 0x00, 0x00, 0x00, 0x57, 0x45, 0x42, 0x50])), 'image/webp', 'webp sniffed')
  assert.equal(sniffMediaType(new Uint8Array([0x00, 0x01, 0x02])), null, 'unknown format rejected')
  const pngBytes = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])
  const parsed = parseImageDataUrl(`data:image/png;base64,${pngBytes.toString('base64')}`)
  assert.equal(parsed?.mediaType, 'image/png', 'data url parsed')
  assert.deepEqual([...parsed.data], [...pngBytes], 'data url decoded to bytes')
  assert.equal(parseImageDataUrl('data:image/svg+xml;base64,AAAA'), null, 'unsupported media type rejected')
  assert.equal(parseImageDataUrl('not-a-data-url'), null, 'plain text rejected')
  // Sticky-regex regression: the /g flag once leaked lastIndex across calls
  // — a second parse of the SAME url returned null, and a short url parsed
  // after a long one was dropped.
  const url1 = `data:image/png;base64,${pngBytes.toString('base64')}`
  assert.ok(parseImageDataUrl(url1) !== null, 'first parse ok')
  assert.ok(parseImageDataUrl(url1) !== null, 'second parse of the same url still ok (no sticky lastIndex)')
  assert.ok(parseImageDataUrl(`data:image/png;base64,${pngBytes.toString('base64')}`) !== null, 'short url after long url parses')

  const split = splitImageDataUrls(`你好 data:image/png;base64,${pngBytes.toString('base64')} 再见`)
  assert.equal(split.text, '你好 再见', 'data url stripped from prompt text')
  assert.equal(split.images.length, 1, 'one image extracted from paste')
  assert.equal(imageLabel({ mediaType: 'image/png', bytes: 1024, width: 640, height: 480 }), '📎 图片 (image/png · 640×480 · 1.0KB)', 'image label formatting')

  // 11. stats: token/cost/cache/format helpers (M5 statusline)
  let u = foldUsage({ input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
    { inputTokens: 500000, outputTokens: 12600, cacheReadTokens: 100000, cacheWriteTokens: 0 })
  assert.equal(billedInput(u), 600000, 'billed input includes cache reads')
  assert.equal(cacheHitRate(u, true), 100000 / 600000, 'cache hit rate')
  assert.equal(estimateCost('deepseek-v4-pro', u)!.toFixed(2), '0.32', 'cost estimate')
  assert.equal(formatTokens(512600), '512.6k', 'token formatting k')
  assert.equal(formatTokens(1000000), '1.00M', 'token formatting M')
  assert.equal(formatElapsed(555000), '9m 15s', 'elapsed formatting')
  assert.equal(formatElapsed(95000), '1m 35s', 'elapsed formatting minutes')
  assert.equal(modeLabel('workspace-write'), 'normal', 'mode label mapping')
  assert.equal(escapeStatusline('缓存 100%'), '缓存 100%%', 'percent escaped for statusline')
  assert.equal(modeLabel('danger-full-access'), 'full-access', 'mode label full access')
  assert.equal(cacheHitRate(u, false), null, 'no cache fields → no rate')

  // 13. extension API surface (P0-P3): registry + ownership, managed
  // floats with guard exemption, the panel slot, the dsh-ext bus (both
  // directions), submit hooks, Lua-side commands, the session-event mirror,
  // ext cards.
  assert.equal(matchSessionEventFilter({}, 's1', 'turn/end'), true, 'empty filter matches all')
  assert.equal(matchSessionEventFilter({ sessionId: 's1' }, 's2', 'turn/end'), false, 'session filter excludes others')
  assert.equal(matchSessionEventFilter({ type: 'turn/end' }, 's1', 'turn/start'), false, 'type filter excludes other kinds')
  assert.equal(matchSessionEventFilter({ type: ['turn/end', 'tool/result'] }, 's1', 'tool/result'), true, 'type array matches')

  // 13a. register + duplicate rejection + ownership helpers
  assert.ok(await lua(`return require("dsh_tui.api").register({ id = "smoke-ext", name = "SmokeExt", events = { "turn/end" } }) ~= nil`, []), 'api.register succeeds')
  assert.equal(await lua('return require("dsh_tui.api").registered("smoke-ext")', []), true, 'registered() true')
  assert.ok(String(await lua(`local ok, err = require("dsh_tui.api").register({ id = "smoke-ext" }); return err`, [])).includes('already registered'), 'duplicate register rejected')
  assert.ok(String(await lua(`local ok, err = require("dsh_tui.api").register({ id = "__node_x" }); return err`, [])).includes('reserved'), '__node prefix is reserved (slot machinery)')
  // events normalization: omitted / empty / 'all' (string or list member) = every kind
  await lua(`require("dsh_tui.api").register({ id = "smoke-all", events = { "turn/start", "all" } })`, [])
  assert.equal(await lua(`return require("dsh_tui.state").extReg["smoke-all"].eventKinds`, []), null,
    "'all' inside the events list normalizes to nil (every kind)")
  await lua(`require("dsh_tui.api").register({ id = "smoke-all2", events = "all" })`, [])
  assert.equal(await lua(`return require("dsh_tui.state").extReg["smoke-all2"].eventKinds`, []), null,
    "the literal 'all' string normalizes to nil too")
  // boot handshake: major-version agreement
  assert.equal((await lua(`return require("dsh_tui.api").handshake("0.1.0")`, [])).ok, true, 'handshake ok on matching major')
  assert.equal((await lua(`return require("dsh_tui.api").handshake("9.0.0")`, [])).ok, false, 'handshake fails on major mismatch')
  // late-load replay: on_ready/on_active_session fire synchronously when
  // the TUI already booted; api.snapshot() carries the initial state
  await lua(`require("dsh_tui.api").register({
    id = "smoke-late",
    on_ready = function(reg, p) vim.g.smokeLateReady = p.ready == true and p.runnerVersion end,
    on_active_session = function(reg, p) vim.g.smokeLateActive = p.id end,
  })`, [])
  assert.equal(await lua(`return vim.g.smokeLateReady`, []), '0.1.0', 'on_ready fires synchronously for a late registration')
  assert.ok(String(await lua(`return vim.g.smokeLateActive`, [])).startsWith('session-'), 'on_active_session fires synchronously for a late registration')
  const snap = await lua(`return require("dsh_tui.api").snapshot()`, [])
  assert.equal(snap.started, true, 'snapshot reports started')
  assert.equal(snap.attached, true, 'snapshot reports attached')
  assert.equal(snap.activeSession, await lua(`return require("dsh_tui.state").activeId`, []), 'snapshot carries the active session')
  assert.equal(snap.runnerVersion, '0.1.0', 'snapshot carries the handshaked runner version')

  // 13b. managed float + boot-guard exemption (an unregistered window still
  // gets swept while the registered float survives)
  const extFloat = await lua(`return require("dsh_tui.api").float_open("smoke-ext", { lines = { "l1", "l2" }, title = "Ext 浮窗" })`, []) as { win: number; buf: number }
  assert.ok(Number.isInteger(extFloat.win) && Number.isInteger(extFloat.buf), 'float_open returns win+buf')
  await lua(`local S = require("dsh_tui.state"); S.bootGuardUntil = vim.uv.now() + 4000; S.mainTab = vim.api.nvim_get_current_tabpage()`, [])
  await lua(`vim.api.nvim_set_current_win(require("dsh_tui").ids().inputWin); vim.cmd('vnew')`, [])
  await new Promise((r) => setTimeout(r, 400))
  const guardProbe = await lua(`return {
    extAlive = vim.api.nvim_win_is_valid(${extFloat.win}),
    wins = #vim.api.nvim_list_wins(),
  }`, [])
  assert.equal(guardProbe.extAlive, true, 'registered float survives the boot guard')
  assert.equal(guardProbe.wins, 3, 'unregistered vnew window swept by the boot guard (chat+input+ext float left)')
  await lua(`require("dsh_tui.api").float_close("smoke-ext", ${extFloat.win})`, [])
  assert.equal(await lua(`return vim.api.nvim_win_is_valid(${extFloat.win})`, []), false, 'float_close closes the window')
  assert.equal(await lua(`return vim.api.nvim_buf_is_valid(${extFloat.buf})`, []), false, 'float_close wipes the buffer')

  // 13c. the panel column: per-ext panels stack, geometry, release
  const extPanel = await lua(`return require("dsh_tui.api").panel_claim("smoke-ext", { title = "Ext 面板", lines = { "a" } })`, []) as { win: number; buf: number }
  assert.ok(Number.isInteger(extPanel.win), 'panel_claim opens a panel')
  assert.ok(String((await lua(`return require("dsh_tui.api").panel_claim("smoke-ext", {})`, [])).err).includes('already holds'), 'same ext cannot claim twice')
  const extPanelCfg = await nvim.request('nvim_win_get_config', [extPanel.win])
  assert.equal(extPanelCfg.relative, 'editor', 'ext panel is editor-relative')
  assert.equal(extPanelCfg.anchor, 'NE', 'ext panel anchors top-right')
  const panelMaps = await lua(`local out = {}
    for _, m in ipairs(vim.api.nvim_buf_get_keymap(${extPanel.buf}, "n")) do table.insert(out, m.lhs) end
    return out`, [])
  assert.ok(panelMaps.includes('q') && panelMaps.includes('<Esc>'), 'ext panel binds q/Esc to release the slot')
  // multi-panel: a DIFFERENT ext claims a second panel; the column stacks
  // it right below the first (claim order), left side supported too
  const panel2 = await lua(`return require("dsh_tui.api").panel_claim("smoke-all", { title = "第二块", height = 5, side = "right" })`, []) as { win: number; buf: number }
  assert.ok(Number.isInteger(panel2.win), 'second extension claims a panel concurrently')
  const cfg1 = await nvim.request('nvim_win_get_config', [extPanel.win])
  const cfg2 = await nvim.request('nvim_win_get_config', [panel2.win])
  assert.equal(cfg2.row, cfg1.height, 'second panel stacks below the first (claim order)')
  assert.equal(cfg2.height, 5, 'explicit height honored')
  const handlesPanels = await lua(`return require("dsh_tui.api").handles().panels`, [])
  assert.ok(handlesPanels['smoke-ext'] != null && handlesPanels['smoke-all'] != null, 'handles().panels lists both panels')
  assert.equal(await lua(`return require("dsh_tui.api").panel_release("smoke-all")`, []), true, 'second panel releases')
  assert.equal((await nvim.request('nvim_win_get_config', [extPanel.win])).height, cfg1.height + 5,
    'weighted panel absorbs the freed rows after the second releases (reflow)')
  assert.equal(await lua(`return require("dsh_tui.api").panel_release("smoke-ext")`, []), true, 'panel_release frees the panel')
  assert.equal(await lua(`return vim.api.nvim_win_is_valid(${extPanel.win})`, []), false, 'released panel window closed')
  assert.equal(await lua(`return vim.api.nvim_win_is_valid(${panel2.win})`, []), false, 'second panel window closed too')
  // re-claim race: a panel closed EXTERNALLY leaves its stack entry until
  // the scheduled prune — an immediate re-claim must not stack the id twice
  const p3 = await lua(`return require("dsh_tui.api").panel_claim("smoke-ext", { height = 4 })`, []) as { win: number }
  await lua(`vim.api.nvim_win_close(${p3.win}, true)`, []) // external close (no panel_release)
  const p3b = await lua(`return require("dsh_tui.api").panel_claim("smoke-ext", { height = 4 })`, []) as { win: number }
  assert.equal(await lua(`local n = 0 for _, id in ipairs(require("dsh_tui.state").panelStack) do if id == "smoke-ext" then n = n + 1 end end return n`, []), 1,
    're-claim after an external close leaves ONE stack entry (de-dupe)')
  const p3bCfg = await nvim.request('nvim_win_get_config', [p3b.win])
  assert.equal(p3bCfg.row, 0, 're-claimed panel laid out once from the top')
  await lua(`require("dsh_tui.api").panel_release("smoke-ext")`, [])
  // mixed sides: left and right columns stack INDEPENDENTLY
  const pl = await lua(`return require("dsh_tui.api").panel_claim("smoke-ext", { side = "left", height = 3 })`, []) as { win: number }
  const pr = await lua(`return require("dsh_tui.api").panel_claim("smoke-all", { side = "right", height = 5 })`, []) as { win: number }
  const cfgL = await nvim.request('nvim_win_get_config', [pl.win])
  const cfgR = await nvim.request('nvim_win_get_config', [pr.win])
  assert.equal(cfgL.row, 0, 'left panel starts its own column at the top')
  assert.equal(cfgR.row, 0, 'right panel starts its own column at the top')
  assert.equal(cfgL.anchor, 'NW', 'left panel anchors NW')
  assert.equal(cfgL.col, 0, 'left panel hugs the left edge')
  await lua(`require("dsh_tui.api").panel_release("smoke-ext")`, [])
  await lua(`require("dsh_tui.api").panel_release("smoke-all")`, [])

  // 13d. the dsh-ext bus: Lua → Node rpcrequest + Node → Lua dispatch
  nvim.on('request', (method: string, args: unknown[], resp: { send: (r: unknown) => void }) => {
    void (async () => {
      if (method !== 'dsh-ext') { resp.send({ ok: false, error: 'unsupported' }); return }
      const p = (args?.[0] ?? {}) as { id?: string; method?: string; args?: unknown[] }
      if (p.id !== 'smoke-ext') { resp.send({ ok: false, error: 'no handler: ' + String(p.id) }); return }
      try {
        if (p.method === 'add') {
          resp.send({ ok: true, value: { sum: Number(p.args?.[0]) + Number(p.args?.[1]) } })
          return
        }
        if (p.method === 'nested') {
          // Nested nvim call from INSIDE a dsh-ext handler: nvim keeps
          // processing events while blocked in rpcrequest, so this must
          // round-trip (regression: a former "deadlock guard" wrongly
          // rejected exactly this shape).
          const v = await nvim.request('nvim_eval', ['2+2'])
          resp.send({ ok: true, value: { nested: v } })
          return
        }
        resp.send({ ok: false, error: 'boom-' + String(p.method) })
      } catch (e) {
        resp.send({ ok: false, error: (e as Error).message })
      }
    })()
  })
  const addRes = await lua(`return require("dsh_tui.api").rpc_call("smoke-ext", "add", { 2, 3 })`, [])
  assert.deepEqual(addRes, { sum: 5 }, 'lua rpc_call round-trips through the node handler')
  assert.deepEqual(await lua(`return require("dsh_tui.api").rpc_call("smoke-ext", "nested", {})`, []),
    { nested: 4 }, 'nested nvim call from inside a dsh-ext handler round-trips')
  assert.ok(String(await lua(`local v, e = require("dsh_tui.api").rpc_call("smoke-ext", "nope", {}); return e`, [])).includes('boom-nope'), 'handler errors surface to the lua caller')
  await lua(`require("dsh_tui.api").rpc_register("smoke-ext", "greet", function(args) return "hello " .. args.name end)`, [])
  assert.deepEqual(await lua(`return require("dsh_tui.api").rpc_dispatch("smoke-ext", "greet", { name = "dsh" })`, []),
    { ok: true, value: 'hello dsh' }, 'rpc_dispatch routes to the lua handler')
  assert.equal((await lua(`return require("dsh_tui.api").rpc_dispatch("smoke-ext", "missing", {})`, [])).ok, false, 'unknown method reports ok=false')

  // 13e. before_submit hooks: rewrite + veto (draft kept)
  await lua(`require("dsh_tui.api").before_submit("smoke-ext", function(text)
    if text == "veto-me" then return nil end
    if text == "rewrite-me" then return "rewritten" end
    return text
  end)`, [])
  const submitNotes: string[] = []
  const onSubmitNote = (m: string, a: unknown[]): void => { if (m === 'dsh-input') submitNotes.push(String(a[0])) }
  nvim.on('notification', onSubmitNote)
  await lua(`require("dsh_tui").fill_input(...)`, ['rewrite-me'])
  await lua(`require("dsh_tui").submit()`, [])
  await new Promise((r) => setTimeout(r, 120))
  assert.deepEqual(submitNotes, ['rewritten'], 'before_submit rewrites the submission')
  await lua(`require("dsh_tui").fill_input(...)`, ['veto-me'])
  await lua(`require("dsh_tui").submit()`, [])
  await new Promise((r) => setTimeout(r, 120))
  assert.equal(submitNotes.length, 1, 'vetoed submission never reaches the runner')
  assert.equal(await lua(`return require("dsh_tui.api").input_get()`, []), 'veto-me', 'vetoed draft stays in the input box')
  nvim.off('notification', onSubmitNote)
  await lua(`require("dsh_tui").fill_input(...)`, [''])

  // 13f. Lua-side commands: catalog merge survives runner refreshes, local
  // execution (never routed to the runner)
  await lua(`require("dsh_tui.api").register_command("smoke-ext", "extping", "扩展命令", function(arg) vim.g.smokeExtArg = arg or "" end)`, [])
  await lua(`require("dsh_tui").set_commands(...)`, [[{ name: '/exit', desc: '退出 dsh' }]])
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "/extp" })`, [])
  await lua(`require("dsh_tui").update_cmd_menu()`, [])
  let extMenu = await lua(`return require("dsh_tui").cmd_menu_state()`, [])
  assert.deepEqual(extMenu.names, ['/extping'], 'ext command merged into the catalog')
  const cmdNotes: string[] = []
  const onCmdNote = (m: string, a: unknown[]): void => { if (m === 'dsh-command') cmdNotes.push(String(a[0])) }
  nvim.on('notification', onCmdNote)
  await lua(`require("dsh_tui").fill_input(...)`, ['/extping 42'])
  await lua(`require("dsh_tui").submit()`, [])
  await new Promise((r) => setTimeout(r, 120))
  assert.equal(await lua(`return vim.g.smokeExtArg`, []), '42', 'ext command executes locally with its argument')
  assert.equal(cmdNotes.length, 0, 'ext command never routed to the runner')
  nvim.off('notification', onCmdNote)
  await lua(`require("dsh_tui.api").unregister_command("smoke-ext", "extping")`, [])
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "/extp" })`, [])
  await lua(`require("dsh_tui").update_cmd_menu()`, [])
  extMenu = await lua(`return require("dsh_tui").cmd_menu_state()`, [])
  assert.equal(extMenu.open, false, 'unregistered ext command leaves the catalog')

  // 13g. session-event mirror: lua callback + User autocmd + last_event
  await lua(`vim.g.smokeSeenKind = nil
    vim.g.smokeUserFired = nil
    vim.api.nvim_create_autocmd("User", { pattern = "DshTuiSessionEvent", callback = function() vim.g.smokeUserFired = require("dsh_tui.api").last_event().ids[1] end })
    require("dsh_tui.api").on_session_event("smoke-ext", function(ev) vim.g.smokeSeenKind = ev.type end)`, [])
  await lua(`require("dsh_tui.api").session_event({ "smoke-ext" }, { type = "turn/end", data = {} })`, [])
  assert.equal(await lua(`return vim.g.smokeSeenKind`, []), 'turn/end', 'session_event reaches the lua callback')
  assert.equal(await lua(`return vim.g.smokeUserFired`, []), 'smoke-ext', 'DshTuiSessionEvent fires with the payload')
  assert.equal((await lua(`return require("dsh_tui.api").last_event()`, [])).ids[0], 'smoke-ext', 'last_event carries the payload')

  // 13h. DshTuiActiveSession fires on set_active
  await lua(`vim.g.smokeActive = nil
    vim.api.nvim_create_autocmd("User", { pattern = "DshTuiActiveSession", callback = function() vim.g.smokeActive = require("dsh_tui.api").last_event().id end })`, [])
  await lua(`require("dsh_tui").set_active(...)`, ['session-aaaa'])
  assert.equal(await lua(`return vim.g.smokeActive`, []), 'session-aaaa', 'ActiveSession user event fires on switch')

  // 13i. ext cards: render / update / dismiss in place + DshTuiExt group
  const extHl = await lua(`return vim.api.nvim_get_hl(0, { name = "DshTuiExt" })`, [])
  assert.equal(extHl.link, 'Structure', 'ext card highlight group defined')
  const extCard = feedA.pushExtCard({ plugin: 'smoke', title: '卡片标题', body: '第一行\n第二行', actions: [{ label: '确认', value: 'yes' }] })
  await new Promise((r) => setTimeout(r, 200))
  let extCardLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  assert.ok(extCardLines.some((l: string) => l.includes('▣ smoke · 卡片标题')), 'ext card header renders')
  assert.ok(extCardLines.includes('  第一行') && extCardLines.includes('  第二行'), 'ext card body indented')
  assert.ok(extCardLines.includes('  [1] 确认'), 'ext card action hints render')
  extCard.update({ body: '更新后' })
  await new Promise((r) => setTimeout(r, 200))
  extCardLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  assert.ok(extCardLines.includes('  更新后'), 'ext card update replaces the body')
  assert.ok(!extCardLines.includes('  第一行'), 'ext card old body gone after update')
  extCard.dismiss()
  await new Promise((r) => setTimeout(r, 200))
  extCardLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  assert.ok(!extCardLines.some((l: string) => l.includes('▣ smoke')), 'ext card dismissed')
  const cardMarks: any[] = await nvim.request('nvim_buf_get_extmarks', [chatA.chatBuf, -1, 0, -1, { details: true }])
  const extHeaderRow = extCardLines.findIndex((l: string) => l.includes('▣'))
  if (extHeaderRow >= 0) {
    assert.equal(cardMarks.filter((m) => m[1] === extHeaderRow && m[3]?.hl_group === 'DshTuiExt').length, 0,
      'no ext group mark left after dismiss')
  }

  // 13i2. interactive cards: rendered-row extmarks, activation (direct +
  // picker list), update range tracking, dismiss cleanup, chat keymaps
  const cardNs = await lua(`return vim.api.nvim_create_namespace('dsh_tui_extcards')`, []) as number
  let firedActions: string[] = []
  const intCard = feedA.pushExtCard({
    plugin: 'smoke', title: '交互卡片', body: '选择一项',
    actions: [{ label: '甲', value: 'a' }, { label: '乙', value: 'b' }],
    onAction: (v: string) => { firedActions.push(v) },
  })
  await new Promise((r) => setTimeout(r, 250))
  let intMarks: any[] = await nvim.request('nvim_buf_get_extmarks', [chatA.chatBuf, cardNs, 0, -1, { details: true }])
  assert.equal(intMarks.length, 1, 'one interactive-card mark placed')
  const intLines0 = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  const intHeaderRow = intLines0.findIndex((l: string) => l.includes('交互卡片'))
  assert.ok(intMarks[0][1] <= intHeaderRow && intMarks[0][3].end_row >= intHeaderRow,
    'card mark spans the rendered card block')
  // activation: picker-list form + resolve/fire split + out-of-range + unknown
  const intMarkId = intMarks[0][0] as number
  assert.deepEqual(feedA.activateCard(intMarkId, null),
    [{ label: '甲', value: 'a' }, { label: '乙', value: 'b' }], 'activateCard(null) returns the action list')
  const resolved2 = feedA.activateCard(intMarkId, 2) as { cardId: string; action: { label: string; value: string; kind?: string } }
  assert.equal(resolved2.action.value, 'b', 'activateCard(2) resolves the action record')
  assert.equal(feedA.fireCardAction(resolved2.cardId, 'b'), true, 'fireCardAction invokes the handler')
  assert.deepEqual(firedActions, ['b'], 'action 2 fired with its value')
  assert.equal(feedA.activateCard(intMarkId, 9), null, 'out-of-range action resolves to null')
  assert.equal(feedA.activateCard(999_999, 1), null, 'unknown mark resolves to null')
  // confirm / input kinds resolve with their metadata (dispatch lives in the
  // runner — the feed-level contract is resolve + fire with the final value)
  const kindCard = feedA.pushExtCard({
    plugin: 'smoke', title: '交互卡片2', body: '三种形态',
    actions: [
      { label: '直接', value: 'plain-v' },
      { label: '危险操作', value: 'confirm-v', kind: 'confirm', confirmText: '确认执行？' },
      { label: '重命名', value: 'input-v', kind: 'input', inputPrompt: '新名字', inputDefault: '默认名' },
    ],
    onAction: (v: string) => { firedActions.push('kind:' + v) },
  })
  await new Promise((r) => setTimeout(r, 250))
  const kindMarks: any[] = await nvim.request('nvim_buf_get_extmarks', [chatA.chatBuf, cardNs, 0, -1, { details: true }])
  assert.equal(kindMarks.length, 2, 'second interactive card mark placed')
  const kindMarkId = kindMarks[1][0] as number
  assert.ok(Number.isInteger(kindMarkId), 'kind card mark resolvable')
  const kindList = feedA.activateCard(kindMarkId, null) as Array<{ kind?: string; value: string }>
  assert.equal(kindList[1]?.kind, 'confirm', 'confirm kind carried in the picker list')
  assert.equal(kindList[2]?.kind, 'input', 'input kind carried in the picker list')
  const resolvedConfirm = feedA.activateCard(kindMarkId, 2) as { cardId: string; action: { kind?: string; confirmText?: string } }
  assert.equal(resolvedConfirm.action.kind, 'confirm', 'confirm action resolves with its kind')
  assert.equal(resolvedConfirm.action.confirmText, '确认执行？', 'confirmText carried')
  // plain fire + confirm-style fire (runner passes action.value) + input fire
  // (runner passes the TYPED text)
  feedA.fireCardAction(resolvedConfirm.cardId, 'confirm-v')
  const resolvedInput = feedA.activateCard(kindMarkId, 3) as { cardId: string; action: { kind?: string; inputDefault?: string } }
  assert.equal(resolvedInput.action.kind, 'input', 'input action resolves with its kind')
  assert.equal(resolvedInput.action.inputDefault, '默认名', 'inputDefault carried')
  feedA.fireCardAction(resolvedInput.cardId, '用户输入的内容')
  assert.deepEqual(firedActions, ['b', 'kind:confirm-v', 'kind:用户输入的内容'], 'all three kinds fired with their final values')
  kindCard.dismiss()
  // update() grows the block → the mark range follows the rendered rows
  const beforeRows = intMarks[0][3].end_row - intMarks[0][1]
  intCard.update({ body: '选择一项\n多了两行\n第三行' })
  await new Promise((r) => setTimeout(r, 250))
  intMarks = await nvim.request('nvim_buf_get_extmarks', [chatA.chatBuf, cardNs, 0, -1, { details: true }])
  assert.equal(intMarks.length, 1, 'card mark survives the update')
  assert.equal(intMarks[0][3].end_row - intMarks[0][1], beforeRows + 2, 'mark range grows with the card body')
  // dismiss removes the mark
  intCard.dismiss()
  await new Promise((r) => setTimeout(r, 250))
  intMarks = await nvim.request('nvim_buf_get_extmarks', [chatA.chatBuf, cardNs, 0, -1, { details: true }])
  assert.equal(intMarks.length, 0, 'dismissed interactive card mark removed')
  // chat keymaps: Enter + digits route to api.card_activate
  const chatMaps = await lua(`local out = {}
    for _, m in ipairs(vim.api.nvim_buf_get_keymap(${chatA.chatBuf}, "n")) do out[m.lhs] = m.rhs or "" end
    return out`, [])
  assert.ok(String(chatMaps['<CR>'] ?? chatMaps['<Enter>']).includes('card_activate'), 'Enter maps to card activation')
  for (const d of ['1', '2', '3']) {
    assert.ok(String(chatMaps[d]).includes('card_activate'), d + ' maps to card activation')
  }
  // cursor on a card row → rpcnotify with the mark id; elsewhere → silent
  const actNotes: unknown[] = []
  const onActNote = (m: string, a: unknown[]): void => { if (m === 'dsh-ext-card-activate') actNotes.push(a[0]) }
  nvim.on('notification', onActNote)
  const cursorCard = feedA.pushExtCard({
    plugin: 'smoke', title: '光标卡片', body: '正文', actions: [{ label: 'x', value: 'v' }], onAction: () => {},
  })
  await new Promise((r) => setTimeout(r, 250))
  const curLines = await nvim.request('nvim_buf_get_lines', [chatA.chatBuf, 0, -1, false])
  const curRow = curLines.findIndex((l: string) => l.includes('光标卡片'))
  await nvim.request('nvim_win_set_cursor', [chatA.chatWin, [curRow + 1, 0]])
  assert.equal(await lua(`return require("dsh_tui.api").card_activate(1)`, []), true, 'card_activate hits the card under the cursor')
  await new Promise((r) => setTimeout(r, 120))
  assert.equal(actNotes.length, 1, 'activation routed to the runner')
  assert.equal((actNotes[0] as { mark?: unknown; action?: unknown }).action, 1, 'activation carries the action index')
  await nvim.request('nvim_win_set_cursor', [chatA.chatWin, [1, 0]])
  await lua(`require("dsh_tui.api").card_activate()`, [])
  await new Promise((r) => setTimeout(r, 120))
  assert.equal(actNotes.length, 1, 'no card under the cursor → no notification')
  nvim.off('notification', onActNote)
  cursorCard.dismiss()

  // 13j. unregister closes extension windows, cleans up the extension's
  // slash commands, and drops the entry
  const f2 = await lua(`return require("dsh_tui.api").float_open("smoke-ext", { lines = { "x" } })`, []) as { win: number }
  await lua(`require("dsh_tui.api").register_command("smoke-ext", "extping2", "临时命令", function() end)`, [])
  assert.equal(await lua(`return require("dsh_tui.api").unregister("smoke-ext")`, []), true, 'unregister succeeds')
  assert.equal(await lua(`return vim.api.nvim_win_is_valid(${f2.win})`, []), false, 'unregister closes ext windows')
  assert.equal(await lua(`return require("dsh_tui.api").registered("smoke-ext")`, []), false, 'entry dropped after unregister')
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "/extping2" })`, [])
  await lua(`require("dsh_tui").update_cmd_menu()`, [])
  assert.equal((await lua(`return require("dsh_tui").cmd_menu_state()`, [])).open, false,
    'unregister removes the ext slash command from the catalog')
  await lua(`vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "" })`, [])

  // 13k. /history 输入历史浮窗：与其他命令浮窗统一的样式（''+条目内容、
  // footer 提示条、lock_popup_buffer、居中几何），最新在前、多行 ↵ 折叠、
  // Enter 回填原文
  await lua(`local S = require("dsh_tui.state")
    S.history = { "第一条", "第二条\\n多行", "第三条" }`, [])
  await lua(`require("dsh_tui").show_input_history()`, [])
  const histWin = await lua(`return require("dsh_tui")._histWin`, [])
  const histBuf = await lua(`return require("dsh_tui")._histBuf`, [])
  assert.ok(Number.isInteger(histWin), 'history float opens')
  await assertFooter('[Enter]', 'input history')
  await assertCentered('require("dsh_tui")._histWin', 'input history')
  const histLines = await nvim.request('nvim_buf_get_lines', [histBuf, 0, -1, false])
  assert.equal(histLines[0], '', 'unified blank first row (cursor derives index from row-1)')
  assert.equal(histLines[1], '  第三条', 'newest entry listed first')
  assert.ok(histLines.includes('  第二条↵多行'), 'multi-line entry collapsed with ↵ for display')
  await lua(`require("dsh_tui").input_history_select()`, [])
  assert.equal(await lua(`return table.concat(vim.api.nvim_buf_get_lines(require("dsh_tui").ids().inputBuf, 0, -1, false), "\\n")`, []),
    '第三条', 'Enter refills the input with the selected entry (default = newest)')
  await lua(`require("dsh_tui").show_input_history()`, [])
  await lua(`vim.api.nvim_win_set_cursor(require("dsh_tui")._histWin, { 3, 0 })`, [])
  await lua(`require("dsh_tui").input_history_select()`, [])
  assert.equal(await lua(`return table.concat(vim.api.nvim_buf_get_lines(require("dsh_tui").ids().inputBuf, 0, -1, false), "\\n")`, []),
    '第二条\n多行', 'multi-line entry refills INTACT (no ↵ loss)')
  // G jump → oldest entry (row 4), then select
  await lua(`require("dsh_tui").show_input_history()`, [])
  await lua(`require("dsh_tui").input_history_jump("last")`, [])
  assert.equal(await lua(`return vim.api.nvim_win_get_cursor(require("dsh_tui")._histWin)[1]`, []), 4,
    'G lands on the oldest entry (row 4 = 第一条)')
  await lua(`require("dsh_tui").input_history_select()`, [])
  assert.equal(await lua(`return table.concat(vim.api.nvim_buf_get_lines(require("dsh_tui").ids().inputBuf, 0, -1, false), "\\n")`, []),
    '第一条', 'jump + select refills the oldest entry')
  await lua(`require("dsh_tui").show_input_history()`, [])
  const histMaps = await lua(`local out = {}
    for _, m in ipairs(vim.api.nvim_buf_get_keymap(require("dsh_tui")._histBuf, "n")) do table.insert(out, m.lhs) end
    return out`, [])
  assert.ok(histMaps.includes('q') && histMaps.includes('<Esc>') && histMaps.includes('<CR>'),
    'history float binds q/Esc/Enter')
  await lua(`require("dsh_tui").close_input_history()`, [])
  assert.equal(await lua(`return require("dsh_tui")._histWin`, []), null, 'history float closes')
  assert.equal(await lua(`return require("dsh_tui")._footer.win`, []), null, 'history footer closes with the float')
  await lua(`require("dsh_tui").fill_input(...)`, [''])

  // 13l. region docks: 四边停靠槽（仅浮动窗口，chat/input 几何不变）
  await lua(`require("dsh_tui.api").register({ id = "smoke-ext", name = "SmokeExt" })`, []) // 13j 注销过
  const chatGeoBefore = await lua(`local w = require("dsh_tui").ids().chatWin
    return { h = vim.api.nvim_win_get_height(w), wid = vim.api.nvim_win_get_width(w),
      ih = vim.api.nvim_win_get_height(require("dsh_tui").ids().inputWin) }`, [])
  // top: two exts stack left→right (explicit width wins, weighted share)
  const top1 = await lua(`return require("dsh_tui.api").region_claim("smoke-all", { side = "top", size = 3, width = 30 })`, []) as { win: number; buf: number }
  const top2 = await lua(`return require("dsh_tui.api").region_claim("smoke-all2", { side = "top", size = 3 })`, []) as { win: number; buf: number }
  assert.ok(Number.isInteger(top1.win) && Number.isInteger(top2.win), 'top regions claim concurrently')
  const cfgTop1 = await nvim.request('nvim_win_get_config', [top1.win])
  const cfgTop2 = await nvim.request('nvim_win_get_config', [top2.win])
  assert.equal(cfgTop1.row, 0, 'top region hugs the top edge')
  assert.equal(cfgTop1.height, 3, 'top region honors explicit size rows')
  assert.equal(cfgTop1.col, 0, 'first top region starts at the left edge')
  assert.equal(cfgTop2.col, cfgTop1.width, 'second top region stacks right of the first')
  assert.ok(cfgTop2.width <= Math.floor((await lua(`return vim.o.columns`, [])) * 0.9) + 1, 'top row stays within the width budget')
  // bottom: sits ABOVE the input box (never covers typing)
  const bot1 = await lua(`return require("dsh_tui.api").region_claim("smoke-ext", { side = "bottom", size = 4, width = 40 })`, []) as { win: number }
  const cfgBot1 = await nvim.request('nvim_win_get_config', [bot1.win])
  const inputTopRow = await lua(`return vim.api.nvim_win_get_position(require("dsh_tui").ids().inputWin)[1]`, [])
  // SW anchor: the float's BOTTOM-LEFT sits at (row, col) and it grows
  // upward — flush above the input box means row = inputTopRow - 1.
  assert.equal(cfgBot1.row, inputTopRow - 1, 'bottom region sits directly above the input box (SW anchor semantics)')
  // SW geometry: the float spans [row - height + 1, row] (bottom edge AT
  // row). Never overlapping the input box means bottom edge < inputTopRow.
  assert.ok(cfgBot1.row < inputTopRow, 'bottom region never overlaps the input box')
  assert.equal(cfgBot1.anchor, 'SW', 'bottom region anchors SW')
  // duplicate side rejected; other side fine (per-ext per-side)
  assert.ok(String((await lua(`return require("dsh_tui.api").region_claim("smoke-ext", { side = "bottom" })`, [])).err).includes('already holds'),
    'same ext same side rejected')
  const rightRegion = await lua(`return require("dsh_tui.api").region_claim("smoke-ext", { side = "right", height = 5 })`, []) as { win: number }
  assert.ok(Number.isInteger(rightRegion.win), 'same ext can hold a DIFFERENT side concurrently')
  // chat/input geometry untouched
  const chatGeoAfter = await lua(`local w = require("dsh_tui").ids().chatWin
    return { h = vim.api.nvim_win_get_height(w), wid = vim.api.nvim_win_get_width(w),
      ih = vim.api.nvim_win_get_height(require("dsh_tui").ids().inputWin) }`, [])
  assert.deepEqual(chatGeoAfter, chatGeoBefore, 'chat/input layout unchanged by regions (floats only)')
  // panel alias: panel_claim IS region_claim('right') — same registry entry
  assert.equal(await lua(`local r = require("dsh_tui.api").panel_claim("smoke-ext", {}) return r.err`, []), 'smoke-ext already holds a right region',
    'panel_claim is the right-side alias (duplicate check shared)')
  // handles().regions
  const handlesRegions = await lua(`return require("dsh_tui.api").handles().regions`, [])
  assert.ok(handlesRegions['smoke-ext'] != null && handlesRegions['smoke-ext'].side == 'right', 'handles().regions lists the right region (last claim per ext)')
  // external close → prune removes the stack entry + reflows
  await lua(`vim.api.nvim_win_close(${top1.win}, true)`, [])
  await new Promise((r) => setTimeout(r, 300))
  assert.equal(await lua(`local n = 0 for _, id in ipairs(require("dsh_tui.state").regionStacks.top) do if id == "smoke-all" then n = n + 1 end end return n`, []), 0,
    'externally closed region leaves the stack (prune)')
  const cfgTop2b = await nvim.request('nvim_win_get_config', [top2.win])
  assert.equal(cfgTop2b.col, 0, 'remaining top region reclaims the left edge after prune')
  // release everything
  for (const cmd of [
    `require("dsh_tui.api").region_release("smoke-all", "top")`,
    `require("dsh_tui.api").region_release("smoke-all2", "top")`,
    `require("dsh_tui.api").region_release("smoke-ext", "bottom")`,
    `require("dsh_tui.api").region_release("smoke-ext", "right")`,
  ]) {
    await lua(cmd, [])
  }
  assert.equal(await lua(`return #require("dsh_tui.state").regionStacks.top + #require("dsh_tui.state").regionStacks.bottom`, []), 0, 'all regions released')

  // 12. require() must survive rtp resets (lazy.nvim rebuilds runtimepath and
  // enables vim.loader — package.preload keeps dsh_tui resolvable).
  await lua(
    'pcall(vim.loader.enable); vim.opt.rtp = { "/tmp/nonexistent" }; return require("dsh_tui").ids()',
    [],
  )
  log('require survives rtp reset: ok')

  // 12b. the state module is a reload-safe singleton: clearing
  // package.loaded (vim.loader.enable / rtp rebuilds) re-runs the module
  // file, which must return the SAME pinned table — otherwise modules that
  // captured state at load time split the registry.
  const pinProbe = await lua(`local s1 = require("dsh_tui.state")
    package.loaded["dsh_tui.state"] = nil
    local s2 = require("dsh_tui.state")
    return { same = (s1 == s2), extRegKept = (s2.extReg ~= nil) }`, [])
  assert.equal(pinProbe.same, true, 'state module is a reload-safe singleton')
  assert.equal(pinProbe.extRegKept, true, 'reloaded state keeps the ext registry table')
  // 7. nvim → Node notification
  const notified = new Promise((resolve) => {
    nvim.on('notification', (method, args) => {
      if (method === 'dsh-test') resolve(args[0])
    })
  })
  await lua(
    'vim.rpcnotify(require("dsh_tui").channel(), "dsh-test", 42)',
    [],
  )
  const got = await notified
  assert.equal(got, 42, 'rpcnotify roundtrip')
  log('rpcnotify roundtrip ok:', got)

  // 12c. fullscreen input editor (<C-e>): opens a valid near-fullscreen
  // float prefilled with the draft, normal-mode keys exist, q discards and
  // the input box keeps its content (submit path reuses M.submit — tested
  // through the regular dsh-input assertions above).
  await lua('vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "草稿行1", "草稿行2" })', [])
  await lua('require("dsh_tui").resize_input()', [])
  const fiOpened = await lua('require("dsh_tui").full_input_open(); return vim.api.nvim_win_is_valid(require("dsh_tui.state").fullInput.win)', [])
  assert.equal(fiOpened, true, 'fullscreen input opens a valid float')
  const fiPrefill = await lua('return vim.api.nvim_buf_get_lines(require("dsh_tui.state").fullInput.buf, 0, -1, false)', [])
  assert.deepEqual(fiPrefill, ['草稿行1', '草稿行2'], 'fullscreen input prefills the draft')
  const fiKeys = await lua('local b = require("dsh_tui.state").fullInput.buf; local ks = vim.api.nvim_buf_get_keymap(b, "n"); local has = {}; for _, m in ipairs(ks) do if m.lhs == "<CR>" then has.cr = true end; if m.lhs == "q" then has.q = true end end; return has', [])
  assert.equal(fiKeys.cr, true, 'normal-mode <CR> bound (send)')
  assert.equal(fiKeys.q, true, 'normal-mode q bound (discard)')
  await lua('require("dsh_tui").full_input_close()', [])
  const fiClosed = await lua('return require("dsh_tui.state").fullInput.win == nil', [])
  assert.equal(fiClosed, true, 'discard closes the float')
  const fiDraftKept = await lua('return require("dsh_tui.buffer").input_text()', [])

  assert.equal(fiDraftKept, '草稿行1\n草稿行2', 'discard keeps the input-box draft')
  await lua('vim.api.nvim_buf_set_lines(require("dsh_tui").ids().inputBuf, 0, -1, false, { "" }); require("dsh_tui").resize_input()', [])
  log('fullscreen input editor: open/prefill/discard ok')

  // 9d2. host-PTY console view: renders scrollback, binds line/SIGINT/kill/close
  // keys, and closes its own tab without touching the chat layout.
  {
    const tabBefore = await lua('return vim.api.nvim_get_current_tabpage()', [])
    const winBefore = await lua('return vim.api.nvim_get_current_win()', [])
    await lua('require("dsh_tui.input").focus()', [])
    const tids = await lua('local r = require("dsh_tui").terminal_open("t1", "demo"); return { buf = r.buf, win = r.win }', [])
    const tbuf = tids.buf
    await lua('require("dsh_tui").terminal_update("t1", "hello\\nworld", "运行中")', [])
    const tlines = await nvim.request('nvim_buf_get_lines', [tbuf, 0, -1, false])
    assert.deepEqual(tlines, ['hello', 'world'], 'terminal scrollback renders')
    const tmaps = await lua(`return vim.api.nvim_buf_get_keymap(${tbuf}, "n")`, [])
    for (const key of ['<CR>', '<C-C>', 'K', 'q']) {
      assert.ok(tmaps.some((m: any) => m.lhs === key), key + ' mapped in the terminal view')
    }
    assert.ok(String(await lua('return vim.wo.winbar', [])).includes('TERMINAL'), 'terminal view shows its key bar')
    assert.equal(await lua('return vim.b.dsh_terminal_id', []), 't1', 'terminal buffer carries its session id')
    await lua('require("dsh_tui").terminal_close("t1")', [])
    assert.equal(await lua('return vim.api.nvim_get_current_tabpage()', []), tabBefore, 'closing the view restores the chat tab')
    await lua(`vim.api.nvim_set_current_win(${winBefore})`, [])
    await lua('pcall(vim.cmd, "stopinsert")', [])
    await new Promise((r) => setTimeout(r, 100))
  }

  log('SMOKE PASS')
} finally {
  // Graceful close — the TUI's /exit path relies on ':qa!' so nvim never
  // prints "Nvim: Caught deadly signal 'SIGTERM'". The exit listener is
  // registered BEFORE the qa! — nvim can exit before the RPC roundtrip ends.
  const exited = new Promise<{ code: number | null; signal: string | null }>((resolve) =>
    child.once('exit', (code: number | null, signal: string | null) => resolve({ code, signal })))
  try {
    await Promise.race([
      nvim.command('qa!').catch(() => {}),
      new Promise((r) => setTimeout(r, 300)),
    ])
  } catch {}
  const exitInfo = await Promise.race<{ code: number | null; signal: string | null } | null>([
    exited,
    new Promise<null>((resolve) => setTimeout(() => resolve(null), 3000)),
  ])
  if (exitInfo === null) {
    // A hang here IS a regression: the winbar OptionSet re-assert used to
    // fight nvim's quit-time option reset forever (nvim stayed responsive
    // but never finished exiting) — QuitPre now sets S.quitting and the
    // re-assert stands down. Pre-review this kill path passed SILENTLY.
    child.kill()
    await new Promise((r) => setTimeout(r, 200))
    throw new Error('nvim did not exit gracefully after :qa! (killed with SIGTERM) — winbar/OptionSet quit regression?')
  } else {
    assert.equal(exitInfo.code, 0, 'graceful :qa! exits with code 0')
    assert.equal(exitInfo.signal, null, 'no signal on graceful exit')
    log('graceful exit: ok')
  }
  // Let the process exit naturally — process.exit() truncates async stdout
  // writes on pipes and would swallow the logs above.
  await new Promise((r) => setTimeout(r, 200))
}
