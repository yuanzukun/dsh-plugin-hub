import { describe, expect, it } from "vitest";
import {
  parseMemoryCommand,
  renderMemoryHelp,
  renderMemoryStatus
} from "../src/command.js";

describe("memory command", () => {
  it("parses the documented subcommands", () => {
    expect(parseMemoryCommand("")).toEqual({ kind: "help" });
    expect(parseMemoryCommand(" help ")).toEqual({ kind: "help" });
    expect(parseMemoryCommand(" status ")).toEqual({ kind: "status" });
    expect(parseMemoryCommand("setup")).toEqual({
      kind: "unknown",
      input: "setup"
    });
  });

  it("renders honest pre-alpha status", () => {
    const status = renderMemoryStatus({
      plugin: "dsh-git-memory",
      version: "test",
      phase: "compatibility-spike",
      contextMode: "dynamic-runtime-snapshot",
      eventsSeen: 0,
      turnEndsSeen: 0,
      startedAt: "2026-08-15T00:00:00.000Z",
      lastEventAt: null,
      storesUserContent: false
    });

    expect(status).toContain("stores user content: no");
    expect(status).toContain("last event at: none");
    expect(renderMemoryHelp()).toContain("/memory status");
  });
});
