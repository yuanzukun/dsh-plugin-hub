import { describe, expect, it } from "vitest";
import { SPIKE_CONTEXT } from "../src/context.js";

describe("dynamic context", () => {
  it("is stable and does not claim that memory storage exists", () => {
    expect(SPIKE_CONTEXT).toContain("compatibility-spike mode");
    expect(SPIKE_CONTEXT).toContain("No long-term user memory is stored");
    expect(SPIKE_CONTEXT).not.toMatch(/[A-Z]:\\/);
  });
});
