import { describe, expect, it } from "vitest";
import { RuntimeState } from "../src/runtime-state.js";

describe("RuntimeState", () => {
  it("records event metadata without retaining user content", () => {
    const state = new RuntimeState(
      () => new Date("2026-08-15T00:00:00.000Z")
    );

    state.record({
      type: "user/message",
      time: Date.parse("2026-08-15T00:01:00.000Z")
    });
    state.record({
      type: "turn/end",
      time: Date.parse("2026-08-15T00:02:00.000Z")
    });

    expect(state.snapshot("test")).toEqual({
      plugin: "dsh-git-memory",
      version: "test",
      phase: "compatibility-spike",
      contextMode: "dynamic-runtime-snapshot",
      eventsSeen: 2,
      turnEndsSeen: 1,
      startedAt: "2026-08-15T00:00:00.000Z",
      lastEventAt: "2026-08-15T00:02:00.000Z",
      storesUserContent: false
    });
  });
});
