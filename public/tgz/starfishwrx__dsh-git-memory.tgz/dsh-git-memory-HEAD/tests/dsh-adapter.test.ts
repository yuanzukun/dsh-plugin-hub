import type { Context } from "@deepseek-ai/cordis";
import type {
  CommandDefinition,
  CommandInvocation
} from "@deepseek-ai/dsh-commands";
import type {
  Session,
  SessionEvent
} from "@deepseek-ai/dsh-session";
import type { PromptContext } from "@deepseek-ai/dsh-system-prompt";
import type {
  ToolDefinition,
  ToolRunContext
} from "@deepseek-ai/dsh-tools";
import { describe, expect, it } from "vitest";
import { VERSION, apply } from "../src/dsh-adapter.js";

describe("DSH adapter", () => {
  it("registers context, capture, command, and tool surfaces", async () => {
    let context: PromptContext | undefined;
    let command: CommandDefinition | undefined;
    let tool: ToolDefinition | undefined;
    let sessionListener:
      | ((session: Session, event: SessionEvent) => void)
      | undefined;

    const fakeContext = {
      systemPrompt: {
        context(value: PromptContext) {
          context = value;
          return () => undefined;
        }
      },
      on(
        eventName: string,
        listener: (session: Session, event: SessionEvent) => void
      ) {
        expect(eventName).toBe("session/event");
        sessionListener = listener;
        return () => undefined;
      },
      commands: {
        register(value: CommandDefinition) {
          command = value;
          return () => undefined;
        }
      },
      tools: {
        register(value: ToolDefinition) {
          tool = value;
          return () => undefined;
        }
      }
    } as unknown as Context;

    apply(fakeContext);

    expect(context?.name).toBe("dsh-git-memory:status");
    expect(command?.name).toBe("memory");
    expect(tool?.name).toBe("memory_status");

    sessionListener?.(
      {} as Session,
      {
        type: "turn/end",
        seq: 1,
        time: Date.parse("2026-08-15T00:00:00.000Z"),
        data: { turn: 1, reason: "completed" }
      } as SessionEvent
    );

    const commandResult = await command?.handler({
      rawInput: " status",
      signal: new AbortController().signal
    } as CommandInvocation);
    expect(commandResult).toMatchObject({ kind: "success" });
    if (commandResult?.kind === "success") {
      expect(commandResult.text).toContain("turn ends seen: 1");
    }

    const toolValue = await tool?.execute(
      {},
      {} as ToolRunContext
    );
    expect(toolValue).toMatchObject({
      version: VERSION,
      turnEndsSeen: 1,
      storesUserContent: false
    });
  });
});
