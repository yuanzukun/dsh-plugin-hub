export {
  VERSION,
  apply,
  inject,
  name
} from "./dsh-adapter.js";
