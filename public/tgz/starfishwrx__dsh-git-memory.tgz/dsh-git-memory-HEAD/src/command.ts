import type { RuntimeSnapshot } from "./runtime-state.js";

export type MemoryCommand =
  | { kind: "help" }
  | { kind: "status" }
  | { kind: "unknown"; input: string };

export function parseMemoryCommand(rawInput: string): MemoryCommand {
  const input = rawInput.trim();
  if (input === "" || input === "help") {
    return { kind: "help" };
  }
  if (input === "status") {
    return { kind: "status" };
  }
  return { kind: "unknown", input };
}

export function renderMemoryHelp(): string {
  return [
    "DSH Git Memory compatibility spike",
    "",
    "Available commands:",
    "  /memory status  Show integration health",
    "  /memory help    Show this help",
    "",
    "This pre-alpha release does not store user memory yet."
  ].join("\n");
}

export function renderMemoryStatus(snapshot: RuntimeSnapshot): string {
  return [
    "DSH Git Memory status",
    "version: " + snapshot.version,
    "phase: " + snapshot.phase,
    "context: " + snapshot.contextMode,
    "events seen: " + String(snapshot.eventsSeen),
    "turn ends seen: " + String(snapshot.turnEndsSeen),
    "stores user content: no",
    "started at: " + snapshot.startedAt,
    "last event at: " + (snapshot.lastEventAt ?? "none")
  ].join("\n");
}
