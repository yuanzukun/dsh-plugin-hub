import type { Context } from "@deepseek-ai/cordis";
import type { CommandInvocation } from "@deepseek-ai/dsh-commands";
import type { Session, SessionEvent } from "@deepseek-ai/dsh-session";
import type { PromptContext } from "@deepseek-ai/dsh-system-prompt";
import { defineTool } from "@deepseek-ai/dsh-tools";
import {
  parseMemoryCommand,
  renderMemoryHelp,
  renderMemoryStatus
} from "./command.js";
import { SPIKE_CONTEXT } from "./context.js";
import { RuntimeState } from "./runtime-state.js";

export const name = "dsh-git-memory";
export const inject = ["commands", "sessions", "systemPrompt", "tools"];
export const VERSION = "0.1.0-alpha.0";

const statusOutputSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    plugin: { type: "string", required: true },
    version: { type: "string", required: true },
    phase: { type: "string", required: true },
    contextMode: { type: "string", required: true },
    eventsSeen: { type: "integer", required: true },
    turnEndsSeen: { type: "integer", required: true },
    startedAt: { type: "string", required: true },
    lastEventAt: {
      oneOf: [{ type: "string" }, { type: "null" }],
      required: true
    },
    storesUserContent: { type: "boolean", required: true }
  }
} as const;

export function apply(ctx: Context): void {
  const state = new RuntimeState();

  const context: PromptContext = {
    name: "dsh-git-memory:status",
    order: 50,
    text: SPIKE_CONTEXT
  };
  ctx.systemPrompt.context(context);

  ctx.on(
    "session/event",
    (_session: Session, event: SessionEvent) => {
      state.record(event);
    }
  );

  ctx.commands.register({
    name: "memory",
    description: "Inspect the DSH Git Memory plugin.",
    input: { hint: "status | help" },
    handler: (invocation: CommandInvocation) => {
      const command = parseMemoryCommand(invocation.rawInput);
      if (command.kind === "help") {
        return { kind: "success", text: renderMemoryHelp() };
      }
      if (command.kind === "status") {
        return {
          kind: "success",
          text: renderMemoryStatus(state.snapshot(VERSION))
        };
      }
      return {
        kind: "error",
        text: "Unknown /memory subcommand: " + command.input
      };
    }
  });

  ctx.tools.register(
    defineTool({
      name: "memory_status",
      description:
        "Inspect the installed DSH Git Memory compatibility spike. This tool is read-only.",
      parameters: {},
      output: {
        schema: statusOutputSchema,
        render: (_args, value) => [
          { type: "text", text: JSON.stringify(value, null, 2) }
        ]
      },
      isConcurrencySafe: () => true,
      async execute() {
        return state.snapshot(VERSION);
      }
    })
  );
}
