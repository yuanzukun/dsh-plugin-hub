import type { SessionEvent } from "@deepseek-ai/dsh-session";

export interface RuntimeSnapshot {
  plugin: "dsh-git-memory";
  version: string;
  phase: "compatibility-spike";
  contextMode: "dynamic-runtime-snapshot";
  eventsSeen: number;
  turnEndsSeen: number;
  startedAt: string;
  lastEventAt: string | null;
  storesUserContent: false;
}

type Clock = () => Date;

export class RuntimeState {
  readonly startedAt: string;
  #eventsSeen = 0;
  #turnEndsSeen = 0;
  #lastEventAt: string | null = null;

  constructor(clock: Clock = () => new Date()) {
    this.startedAt = clock().toISOString();
  }

  record(event: Pick<SessionEvent, "type" | "time">): void {
    this.#eventsSeen += 1;
    if (event.type === "turn/end") {
      this.#turnEndsSeen += 1;
    }
    this.#lastEventAt = new Date(event.time).toISOString();
  }

  snapshot(version: string): RuntimeSnapshot {
    return {
      plugin: "dsh-git-memory",
      version,
      phase: "compatibility-spike",
      contextMode: "dynamic-runtime-snapshot",
      eventsSeen: this.#eventsSeen,
      turnEndsSeen: this.#turnEndsSeen,
      startedAt: this.startedAt,
      lastEventAt: this.#lastEventAt,
      storesUserContent: false
    };
  }
}
