export const SPIKE_CONTEXT = [
  "[DSH GIT MEMORY]",
  "The Git-backed memory plugin is active in compatibility-spike mode.",
  "No long-term user memory is stored by this release.",
  "Use memory_status to inspect integration health."
].join("\n");
