import {
  mkdir,
  mkdtemp,
  rm,
  writeFile
} from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const nodeMajor = Number.parseInt(process.versions.node.split(".")[0] ?? "0", 10);
if (nodeMajor < 24) {
  throw new Error(
    "DSH 0.1.0-rc.6 smoke testing requires Node.js 24 or newer."
  );
}
const configuredDshBin = process.env.DSH_BIN;
if (!configuredDshBin) {
  throw new Error(
    "Set DSH_BIN to the absolute path of @deepseek-ai/dsh/lib/bin.js."
  );
}
const dshBin = resolve(configuredDshBin);
const smokeRoot = await mkdtemp(
  resolve(tmpdir(), "dsh-git-memory-smoke-")
);
const profileRoot = resolve(smokeRoot, "profiles", "web");
const environment = {
  ...process.env,
  DSH_HOME: smokeRoot,
  DSH_TELEMETRY_MODE: "DISABLED"
};

let server;

function runDsh(args, timeoutMs = 120_000) {
  return new Promise((resolvePromise, rejectPromise) => {
    const child = spawn(process.execPath, [dshBin, ...args], {
      cwd: projectRoot,
      env: environment,
      windowsHide: true
    });
    let stdout = "";
    let stderr = "";
    let settled = false;

    const timeout = setTimeout(() => {
      if (!settled) {
        child.kill();
        settled = true;
        rejectPromise(
          new Error("DSH command timed out: " + args.join(" "))
        );
      }
    }, timeoutMs);

    child.stdout.on("data", (chunk) => {
      stdout += String(chunk);
    });
    child.stderr.on("data", (chunk) => {
      stderr += String(chunk);
    });
    child.on("error", (error) => {
      if (!settled) {
        clearTimeout(timeout);
        settled = true;
        rejectPromise(error);
      }
    });
    child.on("close", (code) => {
      if (settled) {
        return;
      }
      clearTimeout(timeout);
      settled = true;
      if (code === 0) {
        resolvePromise({ stdout, stderr });
      } else {
        rejectPromise(
          new Error(
            "DSH command failed with exit code " +
              String(code) +
              "\nSTDOUT:\n" +
              stdout +
              "\nSTDERR:\n" +
              stderr
          )
        );
      }
    });
  });
}

async function stopServer() {
  if (!server || server.exitCode !== null) {
    return;
  }
  server.kill();
  await Promise.race([
    new Promise((resolvePromise) => {
      server.once("close", resolvePromise);
    }),
    new Promise((resolvePromise) => {
      setTimeout(resolvePromise, 5_000);
    })
  ]);
  if (server.exitCode === null) {
    server.kill("SIGKILL");
  }
}

async function bootAndProbe() {
  return new Promise((resolvePromise, rejectPromise) => {
    server = spawn(
      process.execPath,
      [dshBin, "--profile", "web", "--port", "0"],
      {
        cwd: projectRoot,
        env: environment,
        windowsHide: true
      }
    );

    let output = "";
    let settled = false;
    const timeout = setTimeout(() => {
      if (!settled) {
        settled = true;
        rejectPromise(
          new Error("DSH Web server did not become ready.\n" + output)
        );
      }
    }, 30_000);

    const inspect = (chunk) => {
      output += String(chunk);
      const match = output.match(/dsh web:\s+(http:\/\/[^\s]+)/);
      if (match && !settled) {
        clearTimeout(timeout);
        settled = true;
        resolvePromise(match[1]);
      }
    };

    server.stdout.on("data", inspect);
    server.stderr.on("data", inspect);
    server.on("error", (error) => {
      if (!settled) {
        clearTimeout(timeout);
        settled = true;
        rejectPromise(error);
      }
    });
    server.on("close", (code) => {
      if (!settled) {
        clearTimeout(timeout);
        settled = true;
        rejectPromise(
          new Error(
            "DSH Web server exited before readiness with code " +
              String(code) +
              ".\n" +
              output
          )
        );
      }
    });
  });
}

try {
  await mkdir(profileRoot, { recursive: true });
  await writeFile(
    resolve(profileRoot, "package.json"),
    JSON.stringify(
      {
        name: "dsh-profile-web",
        private: true,
        dependencies: {},
        dsh: {
          profile: {
            bundles: [
              "@deepseek-ai/dsh-base",
              "@deepseek-ai/dsh-web-app"
            ]
          }
        }
      },
      null,
      2
    ) + "\n",
    "utf8"
  );
  await writeFile(
    resolve(profileRoot, "cordis.patch.yml"),
    "[]\n",
    "utf8"
  );

  await runDsh([
    "plugin",
    "--profile",
    "web",
    "add",
    projectRoot
  ]);

  const dump = await runDsh([
    "--profile",
    "web",
    "--dump-config"
  ]);
  if (!dump.stdout.includes("# == @starfishwrx/dsh-git-memory")) {
    throw new Error("Bundle layer is missing from the composed DSH config.");
  }
  if (!dump.stdout.includes("name: '@starfishwrx/dsh-git-memory'")) {
    throw new Error("Plugin entry is missing from the composed DSH config.");
  }

  const url = await bootAndProbe();
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(
      "DSH Web probe returned HTTP " + String(response.status) + "."
    );
  }

  console.log("DSH bundle layer: present");
  console.log("DSH plugin boot: successful");
  console.log("DSH Web probe: HTTP " + String(response.status));
} finally {
  await stopServer();
  const resolvedRoot = resolve(smokeRoot);
  const resolvedTemp = resolve(tmpdir()) + sep;
  if (!resolvedRoot.startsWith(resolvedTemp)) {
    throw new Error("Refusing to clean a smoke directory outside the OS temp root.");
  }
  await rm(resolvedRoot, {
    recursive: true,
    force: true,
    maxRetries: 5,
    retryDelay: 100
  });
}
