# Threat model

## Assets

- confirmed user preferences and boundaries;
- workspace-specific decisions and procedures;
- source references and revision history;
- the integrity of user source repositories;
- local credentials and private session content.

## Trust boundaries

- model-produced tool arguments are untrusted;
- workspace files and fetched content are untrusted;
- model-inferred memories are untrusted proposals;
- human-confirmed onboarding and review actions are authoritative only within
  their declared scope;
- a configured Git remote is an external disclosure boundary.

## Primary threats and required mitigations

### Path escape

Threats include traversal, absolute paths, symlinks, junctions, reparse points,
case-folding bypasses, UNC paths, and Windows alternate data streams.

Mitigation: resolve canonical roots and existing ancestors, reject escapes and
reparse traversal, normalize before policy evaluation, and keep model tools
path-free.

### Secret persistence

Threat: a prompt, file, or tool result contains a credential that reaches Git
history.

Mitigation: hard-deny sensitive paths and patterns, limit source material,
classify before commit, show review previews, and test negative controls.

### Prompt injection becoming policy

Threat: untrusted content is stored as a global instruction.

Mitigation: preserve `authority`; only direct human confirmation may create
global boundaries or preferences. Workspace evidence remains informational.

### Git code execution

Threat: repository hooks or shell interpolation execute attacker-controlled
commands.

Mitigation: invoke Git with argument arrays, disable hooks in managed
repositories, sanitize commit summaries, and never use a shell command string.

### Concurrent or interrupted writes

Threat: two DSH processes or a crash leave mixed records, catalog drift, or an
unknown dirty state.

Mitigation: repository-level exclusive lock, transaction journal, atomic file
replacement, explicit staging, staged-diff validation, and fail-closed recovery.

### Unsafe rollback

Threat: revert touches non-plugin data or conflicts silently.

Mitigation: accept plugin-owned commits only, require a clean managed
repository, use `git revert --no-edit`, abort conflicts, and return
`needs_attention`.

### Remote disclosure

Threat: personal memory is pushed to a public or unintended remote.

Mitigation: no remote or push by default. Remote configuration is human-only,
requires an explicit warning, and remains outside model-callable tools.
