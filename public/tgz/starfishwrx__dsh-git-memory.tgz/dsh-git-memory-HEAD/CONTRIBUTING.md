# Contributing

Thank you for helping build a transparent memory layer for DeepSeek Harness.

## Before opening a pull request

```bash
pnpm install
pnpm verify
```

Keep changes focused and include tests for behavioral claims.

## Privacy rules

Fixtures and examples must be synthetic. Never commit:

- real conversation text;
- personal context;
- credentials or tokens;
- private keys;
- cookies;
- private absolute paths;
- exported user memory repositories.

Run `git diff --check` and inspect `git diff --cached` before committing.

## Design rules

- Service-layer policy is authoritative; prompts are not a security boundary.
- Model tools stay thin and do not accept arbitrary target paths.
- User source repositories are never automatic commit targets.
- Unknown, dirty, conflicted, or partially recovered state fails closed.
- `partial`, `failure`, `rejected`, and `needs_attention` outcomes remain
  visible.
- Do not add a vector database, cloud service, telemetry, or remote sync without
  a separate design discussion.

## Commit style

Use a concise imperative summary. Do not include user content or machine paths
in commit messages.
