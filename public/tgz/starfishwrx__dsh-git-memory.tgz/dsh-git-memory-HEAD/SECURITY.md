# Security policy

## Supported versions

This project is pre-alpha. Only the latest commit on `main` is currently
eligible for security fixes.

## Reporting a vulnerability

Do not open a public issue for a vulnerability that exposes private data,
credentials, path escapes, arbitrary command execution, or destructive Git
behavior.

Use GitHub private vulnerability reporting for this repository. Include:

- affected commit;
- operating system and DSH version;
- minimal synthetic reproduction;
- expected and observed behavior;
- whether any sensitive data was actually written or disclosed.

Do not attach real credentials, transcripts, or private repositories.

## Security-sensitive areas

Changes to path policy, transaction locking, Git invocation, secret detection,
authority promotion, rollback, remote configuration, and source capture require
focused negative tests and explicit review.
