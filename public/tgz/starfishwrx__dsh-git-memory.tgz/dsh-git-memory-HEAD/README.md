# DSH Git Memory

[![CI](https://github.com/starfishwrx/dsh-git-memory/actions/workflows/ci.yml/badge.svg)](https://github.com/starfishwrx/dsh-git-memory/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

Git-backed, reviewable long-term context for DeepSeek Harness.

> Status: compatibility spike / pre-alpha. The current release proves the DSH
> integration seams and deliberately does **not** store user memory yet.

## Product direction

DSH Git Memory is being built around one trust invariant:

> One controlled memory transaction equals one Git commit.

The intended product gives DeepSeek Harness useful context on day one, then
accumulates source-backed memory during normal use. Accepted memory stays local,
diffable, reviewable, and revertible.

## What works today

- Installable DSH bundle with a `dsh.bundle` manifest.
- Stable dynamic context registered through `ctx.systemPrompt.context()`.
- Metadata-only observation of `session/event`.
- A direct human command: `/memory status`.
- A read-only model tool: `memory_status`.
- Windows and Ubuntu CI.
- No transcript persistence, no background model calls, and no memory writes.

The spike records only aggregate event counts and timestamps in process memory.
It never retains message or tool-result content.

## Quick start from source

Prerequisites:

- Node.js 24 or newer.
- pnpm 11.
- DeepSeek Harness `0.1.0-rc.6`.

```bash
git clone https://github.com/starfishwrx/dsh-git-memory.git
cd dsh-git-memory
pnpm install
pnpm verify
dsh plugin --profile web add .
dsh --profile web --dump-config
```

Start the Web profile, then run:

```text
/memory status
```

The model can also call:

```text
memory_status
```

This package has not been published to npm yet. GitHub dependency installs run
the package's `prepare` build and therefore require explicit pnpm
`allowBuilds` permission. Pin a commit when testing a source install.

## Planned user experience

1. `/memory setup` gathers basic profile, project, goal, preference, boundary,
   and consent information.
2. A confirmed onboarding draft becomes an auditable baseline commit.
3. Normal DSH sessions generate bounded, redacted memory candidates.
4. Review mode lets the user approve, edit, or reject candidates.
5. Conservative automation can be enabled only after an initial trust period.
6. DSH receives a bounded dynamic context snapshot; detailed recall uses
   `memory_search`.

See [the roadmap](docs/ROADMAP.md) and
[architecture](docs/ARCHITECTURE.md) for the delivery plan.

## Safety posture

- Managed repositories will live under `$DSH_HOME/git-memory`, not inside a
  user's source repository.
- Memory tools will not accept arbitrary filesystem destinations.
- Sensitive values such as credentials, private keys, cookies, and tokens are
  hard-denied.
- Raw session transcripts are not copied into the memory Git history.
- Git remotes, pushing, and writes outside managed repositories are disabled by
  default.
- Model-inferred observations can never silently become global user policy.

Read [PRIVACY.md](PRIVACY.md), [THREAT_MODEL.md](THREAT_MODEL.md), and
[the target data model](docs/DATA_MODEL.md) before contributing storage code.

## Development

```bash
pnpm install
pnpm typecheck
pnpm test
pnpm build
```

`pnpm verify` runs the stable CI checks. Maintainers with DSH installed can
set `DSH_BIN` to the absolute path of DSH's `lib/bin.js` and run
`pnpm smoke:dsh`. The smoke script installs the built bundle into a disposable
profile, boots DSH on an ephemeral port, checks the Web response, and cleans up.

The only module allowed to depend directly on unstable DSH APIs in future
releases is the DSH adapter layer. The compatibility spike is intentionally
small while that boundary is proven.

## Compatibility

The current tested line is DeepSeek Harness `0.1.0-rc.6` on Node.js 24.
DSH is evolving quickly, so plugin and Harness versions are deliberately pinned. See
[COMPATIBILITY.md](COMPATIBILITY.md).

## Contributing

Issues and focused pull requests are welcome. Please read
[CONTRIBUTING.md](CONTRIBUTING.md). Never use real transcripts, credentials,
personal paths, or private user context in fixtures.

## License

MIT. See [LICENSE](LICENSE).
