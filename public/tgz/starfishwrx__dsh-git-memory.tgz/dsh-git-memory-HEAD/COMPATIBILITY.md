# Compatibility

## Tested baseline

| Component | Version |
| --- | --- |
| DeepSeek Harness | `0.1.0-rc.6` |
| Node.js | `24.x` |
| pnpm | `11.x` |
| TypeScript | `5.9.3` |
| Operating systems | Windows latest, Ubuntu latest |

The peer dependency range is intentionally exact while DeepSeek Harness is in
an RC line.

Node.js 20 is a known unsupported runtime for DSH `0.1.0-rc.6`: the Harness
currently imports platform APIs that are available in the tested Node.js 24
line. The plugin therefore fails installation early through its package engine
constraint instead of advertising a combination that cannot boot DSH.

## Policy

- A DSH version is supported only after the bundle loads and the integration
  smoke test passes on Windows and Ubuntu.
- DSH-facing code will be isolated behind `src/dsh-adapter.ts` as the product
  grows.
- A DSH breaking change receives a plugin patch release and a compatibility
  table update.
- Unsupported combinations fail visibly instead of silently disabling memory
  policy.

## Current limitations

- No memory persistence or onboarding yet.
- No npm release yet.
- No dedicated headless setup flow.
- No compatibility claim beyond `0.1.0-rc.6`.
