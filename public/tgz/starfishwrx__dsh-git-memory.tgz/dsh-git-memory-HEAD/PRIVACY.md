# Privacy

DSH Git Memory is local-first.

## Current compatibility spike

The current code:

- does not create a memory repository;
- does not write user content;
- does not retain messages or tool results;
- records only aggregate event counts and timestamps in process memory;
- performs no telemetry or remote network call.

Normal package-manager and Git operations used by the developer are outside the
runtime plugin.

## Target product

The planned memory store will live under `$DSH_HOME/git-memory`. By default:

- raw session transcripts are not copied into memory Git history;
- absolute workspace paths remain outside Git;
- global and workspace memory are isolated;
- Git remotes are absent;
- automatic push is disabled;
- cloud synchronization is not provided;
- sensitive candidates are rejected before commit.

Users should treat a configured Git remote as publication. Deleting a current
file does not erase it from Git history.

## Telemetry

No external telemetry is planned by default. Product-quality metrics such as
candidate acceptance and rejection counts should remain local unless a user
explicitly exports them.

## Test data

All repository fixtures must be synthetic. Do not contribute:

- real session text;
- credentials or credential-shaped examples;
- private keys;
- cookies;
- personal email addresses;
- account identifiers;
- private absolute paths;
- private project context.
