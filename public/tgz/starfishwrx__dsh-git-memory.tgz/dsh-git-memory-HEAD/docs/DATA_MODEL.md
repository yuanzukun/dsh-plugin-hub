# Target data model

This document describes the planned 0.1 record format. The compatibility spike
does not write these records yet.

Each memory is one Markdown file with strict frontmatter:

```yaml
---
schema_version: 1
id: 01K00000000000000000000000
kind: decision
scope: workspace
status: observation
authority: user_declared
confidence: high
privacy: workspace
review_state: approved
created_at: 2026-08-15T00:00:00.000Z
updated_at: 2026-08-15T00:00:00.000Z
expires_at: null
tags:
  - example
sources:
  - type: dsh_session
    session_id: synthetic-session
    event_seq_start: 10
    event_seq_end: 12
    content_digest: sha256:synthetic
evidence: []
supersedes: []
---

# Prefer deterministic local tests

Use deterministic local tests before relying on model-output plausibility.
```

## Stable enums

`kind`:

- `preference`
- `decision`
- `fact`
- `procedure`
- `lesson`
- `project_state`
- `constraint`
- `goal`

`scope`:

- `global`
- `workspace`

`status`:

- `observation`
- `promoted`
- `retired`

`authority`:

- `user_declared`
- `workspace_evidence`
- `model_inferred`

## Source policy

The Git record stores source references, bounded redacted excerpts when
explicitly allowed, and content digests. It does not duplicate raw session
transcripts by default.

Secrets and credentials are invalid record content. `privacy: sensitive` is a
classification that causes rejection or human attention; it is not permission
to commit a secret.

## Identity and lifecycle

The ULID remains unchanged when a record moves from `observations/` to
`promoted/` or `retired/`. The slug is display-only. Promotion, retirement,
and supersession preserve provenance through Git history and structured fields.
