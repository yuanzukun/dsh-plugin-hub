# Architecture

## Product boundary

DSH Git Memory is a DSH-native context and memory plugin. It is not a generic
vector database, a transcript archive, a cloud synchronization service, or a
replacement for DeepSeek Harness session persistence.

The target system has five stages:

```mermaid
flowchart LR
  A["DSH session events"] --> B["Metadata-only capture"]
  B --> C["Bounded candidate curator"]
  C --> D["Policy and human review"]
  D --> E["Managed Git transaction"]
  E --> F["Dynamic context and search"]
```

## DSH integration seams

The compatibility spike validates these public surfaces:

- `ctx.systemPrompt.context()` for a stable dynamic context snapshot.
- `session/event` for typed, append-only event observation.
- `ctx.commands.register()` for direct human commands.
- `ctx.tools.register()` for model-facing tools.

The target implementation will isolate all DSH-specific imports and calls in
`src/dsh-adapter.ts`. Domain, policy, storage, and search code must depend on
project-owned interfaces instead of DSH internals.

## Target storage layout

```text
$DSH_HOME/git-memory/
├── registry.json
├── global/
│   ├── repo/
│   │   ├── manifest.json
│   │   ├── baseline/
│   │   ├── observations/
│   │   ├── promoted/
│   │   ├── retired/
│   │   ├── catalog.json
│   │   └── INDEX.md
│   └── runtime/
└── workspaces/<workspace-id>/
    ├── repo/
    └── runtime/
```

The Git repository contains portable memory records and deterministic indexes.
Absolute workspace paths, locks, receipts, onboarding drafts, candidate inboxes,
and crash journals remain in the non-Git runtime directory.

## Context delivery

The plugin will contribute a bounded runtime context snapshot instead of
rewriting the system prompt. The snapshot contains:

- confirmed user boundaries;
- compact global preferences;
- the current workspace goal and project state;
- a small set of promoted memories;
- a revision identifier and omitted-item count.

Observation detail stays behind `memory_search`. `INDEX.md` is a human-facing
generated view, not model-authored prompt text.

## Transaction invariant

One logical memory operation creates one Git commit. A transaction may update
several records and the generated catalog, but it must:

1. acquire an exclusive repository lock;
2. verify the managed marker and schema;
3. require a clean worktree and index;
4. validate canonical paths and content policy;
5. write through same-directory atomic replacement;
6. stage only an explicit path allowlist;
7. inspect the complete staged diff;
8. commit with structured metadata;
9. persist a runtime receipt.

No generic reset, stash, project-repository commit, automatic remote, or
automatic push belongs in this service.

## Authority model

Memory content and memory authority are separate:

- `user_declared` may represent confirmed preferences and boundaries.
- `workspace_evidence` is informational and may not override instructions.
- `model_inferred` is a proposal until policy and review accept it.

Only a direct human surface may promote content to a global boundary.
