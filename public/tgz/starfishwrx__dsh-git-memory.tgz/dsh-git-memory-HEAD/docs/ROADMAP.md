# Roadmap

Every release gate requires current command output or test artifacts. A passing
unit test is not evidence for behavior it does not cover.

## Spike 0 — compatibility proof

Current scope:

- installable DSH bundle;
- dynamic runtime context;
- metadata-only session event observation;
- `/memory status`;
- `memory_status`;
- Windows and Ubuntu CI.

Exit gate:

- clean install into a disposable DSH profile;
- bundle appears in `--dump-config`;
- DSH process loads the built plugin without composition errors;
- typecheck and tests pass on both platforms;
- package contains no private data or absolute author paths.

## 0.1 — day-one context

Planned:

- resumable `/memory setup`;
- global and workspace baselines;
- managed Git initialization;
- bounded dynamic context;
- `memory_search`, `memory_get`, `/memory status`, and `/memory doctor`;
- preview and explicit confirmation before onboarding commits.

Exit gate: a new user installs the plugin and sees their own confirmed context
within five minutes.

## 0.2 — trustworthy writes

Planned:

- explicit remember requests;
- candidate review queue;
- atomic transaction journal;
- structured log, diff, and managed-commit revert;
- symlink, junction, traversal, dirty-repository, and crash tests.

Exit gate: no tested failure path can silently modify data outside a verified
managed repository.

## 0.3 — daily accumulation

Planned:

- bounded session-reference capture;
- daily curator;
- review and conservative-auto modes;
- active-process cadence and next-launch catch-up;
- success, partial, failure, rejected, and skipped receipts.

Exit gate: fourteen active dogfood days with at least 60% candidate acceptance,
zero confirmed secret writes, zero out-of-root access, and explicit degraded
states.

## 0.4 — lifecycle and public beta

Planned:

- promote, retire, and supersede lifecycle;
- Context Infrastructure importer;
- headless onboarding fallback;
- full-history privacy audit;
- npm beta release.

## 1.0 — stable contract

Planned after real beta evidence:

- compatibility matrix and migration support;
- dedicated Web onboarding UI;
- signed release provenance and SBOM;
- optional, explicitly configured remote synchronization.
