# Changelog

All notable changes will be documented in this file.

## 0.1.0-alpha.0 — Unreleased

### Added

- Initial DSH bundle manifest.
- Stable dynamic runtime-context contribution.
- Metadata-only `session/event` observation.
- `/memory status` human command.
- Read-only `memory_status` model tool.
- Unit tests and Windows/Ubuntu CI.
- Public privacy, threat-model, data-model, roadmap, compatibility, and security
  documentation.

### Explicitly not included

- Long-term memory persistence.
- Onboarding.
- Git memory transactions.
- Session-content capture.
- Daily curation.
