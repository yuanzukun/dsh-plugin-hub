window.__ModuleLoader__.load({ id: "dsh-restart-fab", factory: (require) => {
var module = { exports: {} }; var exports = module.exports;
'use strict'

/**
 * dsh-restart-fab client: a floating restart button pinned to the
 * bottom-right corner of the shell (shell.overlay slot). First click arms a
 * confirmation; the second click POSTs /dsh-restart-fab/restart and shows a
 * full-screen "restarting" overlay. The page polls /dsh-restart-fab/ping
 * every second; as soon as the host boot id changes (the new dsh web is up) it
 * reloads itself onto the new host — no manual refresh, no second tab.
 * Hand-authored CJS bundle (no build step); the only external is the loader
 * module table's `react`.
 */

const React = require('react')
const h = React.createElement
const { useState, useEffect, useRef } = React

const NS = 'dsh-restart-fab'
const POLL_MS = 1000
const STUCK_AFTER_MS = 60000

const zh = {
  btn: '重启 DSH',
  armed: '再点一次确认',
  restarting: '正在重启 DeepSeek Harness',
  pleaseWait: '请稍候，重启完成后页面将自动刷新',
  seconds: 's',
  stuck: '重启耗时有点久，服务可能未正常启动。你可以点下面的按钮手动刷新，或检查控制台窗口。',
  refresh: '手动刷新',
  hint: '重启 DeepSeek Harness：停止当前 dsh 进程并以相同命令重新启动，会话会自动恢复',
}

const en = {
  btn: 'Restart DSH',
  armed: 'Click again to confirm',
  restarting: 'Restarting DeepSeek Harness',
  pleaseWait: 'Please wait — the page will refresh automatically once it is back up',
  seconds: 's',
  stuck: 'The restart is taking a while; the service may not have started. Click below to refresh manually, or check the console window.',
  refresh: 'Refresh now',
  hint: 'Restart DeepSeek Harness: stop the current dsh process and start it again with the same command; sessions resume automatically',
}

const CSS = `
.drb-root{position:fixed;right:22px;bottom:22px;z-index:3000;pointer-events:auto;display:flex;flex-direction:column;align-items:flex-end;gap:8px}
.drb-btn{width:46px;height:46px;border-radius:99px;border:1px solid var(--dsw-alias-border-l1,#e5e7eb);background:var(--dsw-alias-bg-layer-1,#fff);color:var(--dsw-alias-label-secondary,#6b7280);font-size:20px;line-height:1;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.14);display:grid;place-items:center;transition:all .15s ease;font-family:inherit;padding:0}
.drb-btn:hover{color:var(--dsw-alias-brand-primary,#4f6ef7);border-color:var(--dsw-alias-border-l2,#d0d5dd);transform:translateY(-1px)}
.drb-btn.armed{width:auto;padding:0 16px;border-radius:12px;background:var(--dsw-alias-state-error-primary,#dc2626);border-color:var(--dsw-alias-state-error-primary,#dc2626);color:#fff;font-size:13px;font-weight:600}
.drb-mask{position:fixed;inset:0;z-index:9000;background:rgba(10,12,18,.55);display:flex;align-items:center;justify-content:center;pointer-events:auto}
.drb-card{width:min(340px,86vw);background:var(--dsw-alias-bg-layer-1,#fff);border:1px solid var(--dsw-alias-border-l1,#e5e7eb);border-radius:16px;padding:28px 24px;box-shadow:0 24px 70px rgba(0,0,0,.3);display:flex;flex-direction:column;align-items:center;gap:14px;text-align:center;color:var(--dsw-alias-label-primary,#1f2328)}
.drb-spin{width:34px;height:34px;border:3px solid var(--dsw-alias-border-l1,#e5e7eb);border-top-color:var(--dsw-alias-brand-primary,#4f6ef7);border-radius:99px;animation:drb-sp .8s linear infinite}
@keyframes drb-sp{to{transform:rotate(360deg)}}
.drb-title{font-size:15px;font-weight:700;margin:0}
.drb-sub{font-size:12px;color:var(--dsw-alias-label-secondary,#6b7280);margin:0;line-height:1.6}
.drb-elapsed{font-size:12px;font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-secondary,#6b7280)}
.drb-stuck{font-size:12px;color:var(--dsw-alias-state-warn-primary,#b45309);line-height:1.6;margin:0}
.drb-refresh{border:none;border-radius:8px;padding:8px 18px;font:inherit;font-size:13px;font-weight:600;cursor:pointer;background:var(--dsw-alias-button-primary-fill,#4f6ef7);color:var(--dsw-alias-label-primary-foreground,#fff)}
`

function injectStyles() {
  if (document.querySelector('style[data-plugin-css="dsh-restart-fab"]') !== null) return
  const tag = document.createElement('style')
  tag.dataset.plugin = 'dsh-restart-fab'
  tag.dataset.pluginCss = 'dsh-restart-fab'
  tag.textContent = CSS
  document.head.appendChild(tag)
}

function RestartButton({ t }) {
  const [armed, setArmed] = useState(false)
  const [restarting, setRestarting] = useState(false)
  const [stuck, setStuck] = useState(false)
  const [elapsed, setElapsed] = useState(0)
  const oldBoot = useRef(null)

  // Auto-disarm the confirmation after a few seconds.
  useEffect(() => {
    if (!armed) return
    const timer = setTimeout(() => setArmed(false), 5000)
    return () => clearTimeout(timer)
  }, [armed])

  // While restarting: show an elapsed counter and poll the host until the boot
  // id changes, then reload onto the new host.
  useEffect(() => {
    if (!restarting) return
    let alive = true
    const startedAt = Date.now()
    const clock = setInterval(() => {
      if (alive) setElapsed(Math.round((Date.now() - startedAt) / 1000))
    }, 1000)
    const poll = setInterval(async () => {
      try {
        const res = await fetch('/dsh-restart-fab/ping', { cache: 'no-store' })
        if (!res.ok) return
        const body = await res.json()
        if (typeof body.boot === 'string' && body.boot !== oldBoot.current) {
          alive = false
          clearInterval(clock)
          clearInterval(poll)
          location.reload()
        }
      } catch {
        // Host is down mid-restart — keep polling.
      }
    }, POLL_MS)
    const deadline = setTimeout(() => {
      if (!alive) return
      setStuck(true)
    }, STUCK_AFTER_MS)
    return () => {
      alive = false
      clearInterval(clock)
      clearInterval(poll)
      clearTimeout(deadline)
    }
  }, [restarting])

  const onRestart = async () => {
    if (restarting) return
    if (!armed) { setArmed(true); return }
    setArmed(false)
    setStuck(false)
    setElapsed(0)
    // Remember the current host boot id before asking for the restart.
    try {
      const res = await fetch('/dsh-restart-fab/ping', { cache: 'no-store' })
      if (res.ok) oldBoot.current = (await res.json()).boot
    } catch { /* old server unreachable — poll with null oldBoot */ }
    setRestarting(true)
    try {
      await fetch('/dsh-restart-fab/restart', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: '{}',
      })
    } catch { /* the response may be lost when the host dies right after */ }
  }

  useEffect(() => { injectStyles() }, [])

  if (restarting) {
    return h('div', { className: 'drb-mask' },
      h('div', { className: 'drb-card' },
        h('span', { className: 'drb-spin' }),
        h('p', { className: 'drb-title' }, t('restarting') + '…'),
        h('p', { className: 'drb-sub' }, t('pleaseWait')),
        h('div', { className: 'drb-elapsed' }, elapsed + ' ' + t('seconds')),
        stuck && h('p', { className: 'drb-stuck' }, t('stuck')),
        stuck && h('button', { className: 'drb-refresh', onClick: () => location.reload() }, t('refresh'))))
  }

  return h('div', { className: 'drb-root' },
    h('button', {
      className: 'drb-btn' + (armed ? ' armed' : ''),
      onClick: onRestart,
      title: t('hint'),
    }, armed ? t('armed') : '↻'))
}

exports.name = 'dsh-restart-fab'
exports.inject = ['slots', 'locale']
exports.apply = function apply(ctx) {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-restart-fab: dictionaries')
  const t = ctx.locale.bind(NS)
  ctx.slots.inject('shell.overlay', () => ctx.slots.register({
    name: 'shell.overlay',
    id: 'dsh-restart-fab',
    order: 2000,
    label: () => 'Restart DSH',
  }, () => h(RestartButton, { t })))
}

return module.exports; } });
