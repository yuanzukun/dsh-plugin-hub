# 项目规范（Contributing Guidelines）

> dsh-auth-gate — DSH Web UI 认证门禁插件
> 本文档记录本项目的开发与协作规范，参与开发前请先阅读。

## 1. Git 提交规范

### 1.1 提交信息一律使用中文

本项目所有 commit message **必须使用中文**（历史提交为英文，自本规范起统一改为中文）。
这是本项目最重要的一条约定。

### 1.2 格式

```
<type>: <简短中文描述>

[可选的正文：说明改动动机、影响范围、注意事项]
```

- 冒号使用半角 `:`，后跟一个空格。
- 描述用祈使句、简洁明了，控制在 50 字以内，不写句号。
- 正文可选，需要解释"为什么"或列出破坏性变更时使用。

### 1.3 类型（type）一览

| type      | 用途                                             | 示例 |
|-----------|--------------------------------------------------|------|
| feat      | 新功能                                           | `feat: 新增按账号锁定功能` |
| fix       | 修复缺陷                                         | `fix: 修复验证码过期未正确计数的问题` |
| docs      | 文档变更（README、docs/、注释）                  | `docs: 补充 Nginx 配置示例` |
| refactor  | 重构（不改变外部行为）                           | `refactor: 拆分会话管理模块` |
| perf      | 性能优化                                         | `perf: 减少验证码生成的 CPU 开销` |
| test      | 测试相关                                         | `test: 增加会话绑定 IP 的用例` |
| build     | 构建、依赖、脚本变更                             | `build: 升级 typescript 到 5.6` |
| chore     | 杂项（配置、格式化、工具链等）                   | `chore: 更新 .gitignore` |
| style     | 不影响逻辑的格式调整                             | `style: 统一引号风格` |
| revert    | 回滚提交                                         | `revert: 回滚按账号锁定改动` |

### 1.4 其他约定

- **一个提交只做一件事**：功能、修复、文档、格式化分开提交，便于回滚与审查。
- **不提交构建产物**：`lib/`、`node_modules/` 已被 .gitignore 忽略，不要手动 `git add -f` 加入。
- 提交前先跑 `npm run typecheck`；涉及认证逻辑的改动必须跑 `npm test`。

## 2. 分支与发布

- 主干分支为 `master`，日常开发直接提交到 `master`。
- 版本号遵循 [SemVer](https://semver.org/lang/zh-CN/)：`主版本.次版本.修订号`。
- 发布流程：
  1. 更新 `package.json` 版本号并提交（`chore: 发布 vX.Y.Z`）
  2. 本地执行 `npm run build` 与 `npm test` 确认无误
  3. 打 tag：`git tag vX.Y.Z` 并推送
  4. 发布 npm 包（`prepublishOnly` 会自动执行构建）

## 3. 代码风格

- **TypeScript strict 模式**（两个 tsconfig 均开启 `strict: true`），禁止使用 `any` 绕过类型检查。
- 目标 ES2022；Host 端使用 NodeNext 模块解析，Client 端使用 ESNext + Bundler。
- 风格与现有代码保持一致：
  - 语句**不加分号**，字符串使用**单引号**；
  - 导入顺序：类型导入 → 外部依赖 → Node 内置模块（`node:*`）→ 本地相对路径；
  - 注释语言与所在文件保持一致（当前源码注释以英文为主，新增代码请沿用）；面向用户的文档（README、docs/）使用中文。
- 新增文件遵循既有目录约定（见下节），不要随意新建目录。

## 4. 目录结构

```
src/host/      服务端插件：/auth/* 路由、会话、验证码、限流与锁定逻辑
src/client/    Web 登录页（React + CSS），通过 DSH Slot 机制挂载
src/shared/    Host 与 Client 共享的类型定义
bin/           CLI 工具（dsh-auth-passwd：创建/重置密码）
scripts/       构建脚本（build-client.mjs：esbuild 打包 Client）
test/          集成测试（node 直接运行，无需测试框架）
docs/          部署文档（Nginx 配置示例等）
lib/           构建产物（git 忽略，不入库）
```

## 5. 常用命令

| 命令                     | 说明 |
|--------------------------|------|
| `npm run build`         | 完整构建：Host（tsc）+ Client（esbuild） |
| `npm run build:host`    | 仅构建 Host 端 TypeScript |
| `npm run build:client`  | 仅构建 Client 端（esbuild 打包） |
| `npm run typecheck`     | 双端类型检查（不产出文件） |
| `npm test`              | 构建 Host 后运行集成测试 |
| `node bin/dsh-auth-passwd.mjs set <用户>` | 创建/重置密码（交互式） |

## 6. 安全约定

本插件是安全认证组件，任何改动都必须遵守：

- **密码绝不明文存储**：密码文件为 `用户名:bcrypt_hash` 格式，权限 0600；日志、错误信息中不得出现密码原文或哈希。
- **审计日志**：登录成功/失败（含锁定、验证码错误、凭据错误）必须记录 IP 与用户名。
- **改动认证、会话、限流相关逻辑后，必须运行 `npm test` 验证**，并在提交正文中说明安全影响。
- 新增配置项需在 README 配置表中补充说明，并遵循默认值"安全优先"原则。
