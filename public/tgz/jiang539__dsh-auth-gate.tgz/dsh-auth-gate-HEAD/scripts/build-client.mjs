// Builds the client bundle in the exact shape the DSH client module system
// serves: a classic script that registers one factory under the package id via
// window.__ModuleLoader__.load({ id, factory }). The factory receives the
// loader's `require`, so platform-seed words (react, react/jsx-runtime) stay
// external and resolve from the shell's frozen module table at runtime.
import { build } from "esbuild";
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const scriptDir = dirname(fileURLToPath(import.meta.url));
const root = dirname(scriptDir);

const result = await build({
  entryPoints: [join(root, "src/client/index.tsx")],
  bundle: true,
  format: "cjs",
  platform: "browser",
  target: "es2020",
  jsx: "automatic",
  loader: { ".css": "text" },
  external: ["react", "react/jsx-runtime", "react-dom", "react-dom/client"],
  minify: true,
  write: false,
  logLevel: "info"
});

const code = result.outputFiles[0].text;
const wrapped = [
  "window.__ModuleLoader__.load({",
  '  id: "dsh-auth-gate",',
  "  factory: (require) => {",
  "    var module = { exports: {} };",
  "    var exports = module.exports;",
  '    Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });',
  code,
  "    return module.exports;",
  "  }",
  "});",
  ""
].join("\n");

mkdirSync(join(root, "lib/client"), { recursive: true });
writeFileSync(join(root, "lib/client.js"), wrapped);
console.log("lib/client.js written (" + wrapped.length + " bytes)");
