// Shared wire types between the host auth service and the client login gate.
// Keep this file dependency-free: the client bundle cannot import node modules,
// and both tsconfigs typecheck it.

/** Response of GET /auth/captcha */
export interface CaptchaResponse {
  svg: string
  uuid: string
}

/** Request body of POST /auth/login */
export interface LoginRequest {
  username: string
  password: string
  captcha: string
  uuid: string
}

/** Response of a successful POST /auth/login */
export interface LoginResponse {
  token: string
  username: string
  expiresIn: number
  /**
   * True when this login invalidated an older session of the same account
   * (single-session policy, singleSessionPerUser). The previously logged-in
   * client keeps its token locally but every /auth/verify from now on fails
   * with 401 — it is kicked at the next enforcement point.
   */
  kickedPrevious?: boolean
  /**
   * True when the account is still using the configured default password
   * (initial auto-provisioned account, or one deliberately reset to it).
   * The client must force a password change before releasing the UI; the
   * flag is cleared by the change-password flow and re-evaluated on every
   * login, so a changed account never sees it again.
   */
  mustChangePassword?: boolean
  /**
   * True when the account name is still the reserved default admin user
   * (e.g. the auto-provisioned `admin`). The client must force a rename
   * before releasing the UI so the public default name stops working; the
   * rename flow clears the flag and renaming back to defaultAdminUser is
   * rejected server-side.
   */
  mustChangeUsername?: boolean
}

/** Error body returned by every failed auth endpoint */
export interface AuthError {
  error: string
  blockedUntil?: number
}

/** Response of POST /auth/logout */
export interface LogoutResponse {
  ok: true
}

/** Request body of POST /auth/password (change own password) */
export interface ChangePasswordRequest {
  oldPassword: string
  newPassword: string
}

/** Response of a successful POST /auth/password */
export interface PasswordChangeResponse {
  ok: true
}

/** Request body of POST /auth/username (rename own account) */
export interface UsernameChangeRequest {
  newUsername: string
}

/** Response of a successful POST /auth/username */
export interface UsernameChangeResponse {
  ok: true
  username: string
}

/** Runtime-managed security settings plus live status, served by GET /auth/security */
export interface SecurityStatus {
  /** Session lifetime in seconds; the /auth/verify window slides on use. */
  sessionTimeout: number
  /** Captcha lifetime in seconds. */
  captchaExpires: number
  /** Consecutive failed attempts from one IP before it is blocked. */
  maxLoginAttempts: number
  /** Consecutive credential failures for one account (any IP) before it is locked. */
  accountMaxLoginAttempts: number
  /** Block duration in seconds after maxLoginAttempts. */
  blockDuration: number
  /** Trust X-Forwarded-For from the same-host reverse proxy. */
  trustProxy: boolean
  /** Whether sessions are bound to the client IP they were minted from. */
  bindSessionToIp: boolean
  /**
   * Single-session policy: a successful login destroys every other session of
   * the same account, so the account is only logged in at one place at a time
   * (the older client is kicked at its next enforcement point).
   */
  singleSessionPerUser: boolean
  /** DEV/VERIFICATION ONLY: whether captcha answers are echoed to clients. */
  devCaptchaText: boolean
  /** Resolved password file path. */
  passwordFile: string
  /** Hard-coded request-body byte limit enforced by every /auth endpoint. */
  bodyLimitBytes: number
  /** Live count of valid session tokens. */
  activeSessions: number
  /** Live count of IPs currently locked out by the brute-force protection. */
  blockedIps: number
  /** Epoch ms of the last runtime update via POST /auth/security; null = never. */
  updatedAt: number | null
}

/**
 * Request body of POST /auth/security. Only the keys present are changed
 * (each is validated server-side against its safe bounds); empty is an error.
 */
export interface SecurityUpdateRequest {
  sessionTimeout?: number
  captchaExpires?: number
  maxLoginAttempts?: number
  blockDuration?: number
  trustProxy?: boolean
  singleSessionPerUser?: boolean
}

/** Response of POST /auth/security — the full new status. */
export type SecurityUpdateResponse = SecurityStatus

/** Storage key of the session token in localStorage */
export const AUTH_TOKEN_KEY = "dsh_auth_token";
/** Storage key of the logged-in username in localStorage */
export const AUTH_USER_KEY = "dsh_auth_username";
/**
 * Storage key of the username remembered by the login page (「记住用户名」).
 * Kept in its own key on purpose: AUTH_USER_KEY is cleared on logout and
 * reflects the *logged-in* name, while this one survives logout and only
 * holds a name the user explicitly opted to remember. Presence of the key is
 * the "remember" flag; it is removed when the user unchecks the box.
 */
export const AUTH_REMEMBER_USERNAME_KEY = "dsh_auth_remembered_username";