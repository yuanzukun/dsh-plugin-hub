// dsh-auth-gate host half: the /auth/* HTTP service.
//
// - GET  /auth/captcha → { svg, uuid }                       (one-time SVG captcha)
// - POST /auth/login    → { token, username, expiresIn, kickedPrevious? }  (captcha + password;
//                         single-session: a new login kills every older session of the account)
// - GET  /auth/verify   → 200 + X-Auth-User | 401            (Nginx auth_request)
// - POST /auth/logout   → { ok: true }                       (destroys the session)
// - POST /auth/username → { ok: true, username }             (renames the account)
// - POST /auth/password → { ok: true }                       (changes the password)
// - GET  /auth/security  → { ...SecurityStatus }             (settings + live status, 需登录)
// - POST /auth/security  → { ...SecurityStatus }             (更新设置并持久化, 需登录)
//
// State (sessions, captchas, per-IP failure counters) is in-memory by design;
// see the README for the Redis-backed production direction. The password file
// is `username:bcrypt_hash` per line, mode 0600.
import type { Context } from '@deepseek-ai/cordis'
// Type-only: brings the webServer service type + its Context augmentation.
import type { WebServer } from '@deepseek-ai/dsh-host-webserver'
import z from '@deepseek-ai/schemastery'
import * as crypto from 'node:crypto'
import * as fs from 'node:fs/promises'
import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import * as path from 'node:path'
import { homedir } from 'node:os'
import type { IncomingMessage, ServerResponse } from 'node:http'
import svgCaptcha from 'svg-captcha'
import bcrypt from 'bcryptjs'
import type { CaptchaResponse, LoginResponse, AuthError, LogoutResponse, PasswordChangeResponse, UsernameChangeResponse, SecurityStatus, SecurityUpdateRequest } from '../shared/types.js'

export const name = 'dsh-auth-gate'

/** Services required before the gate mounts. */
export const inject = ['webServer']

export interface Config {
  /** Password file path (supports a leading `~` for the OS home). */
  passwordFile: string
  /** Session lifetime in seconds; the verify window slides on use. */
  sessionTimeout: number
  /** Captcha lifetime in seconds. */
  captchaExpires: number
  /** Consecutive failed attempts from one IP before it is blocked. */
  maxLoginAttempts: number
  /**
   * Consecutive CREDENTIAL failures for one account (any IP) before the
   * account itself is locked for blockDuration. Defends against IP-rotating
   * brute force that per-IP counters cannot see. Captcha failures are NOT
   * counted here (they are per-IP already, and counting them would let an
   * attacker lock a victim's account by spamming wrong captchas).
   */
  accountMaxLoginAttempts: number
  /** Block duration in seconds after maxLoginAttempts. */
  blockDuration: number
  /**
   * Bind every session to the client IP it was created from. A token used
   * from any other IP is rejected (and the session destroyed) — a token
   * stolen via XSS/logs becomes useless off the victim's machine. IP changes
   * (NAT re-assignment, VPN on/off) will force a fresh login. Defaults to
   * false because deployed client IPs are not stable; set to true only where
   * the client IP is fixed.
   */
  bindSessionToIp: boolean
  /**
   * Single-session policy: a successful login destroys every other session of
   * the same account, so the account is only ever logged in at one place at a
   * time. The older client is kicked at the enforcement point — its token
   * stops validating (/auth/verify → 401) on its very next request.
   */
  singleSessionPerUser: boolean
  /**
   * Trust X-Forwarded-For from a reverse proxy. For the spoofing to be
   * impossible the direct peer must be the loopback address (DSH only binds
   * 127.0.0.1, so a same-host Nginx is the only realistic proxy) — see
   * getClientIp(). Defaults to false so a misconfigured direct deployment
   * cannot be lockout-bypassed by forging the header.
   */
  trustProxy: boolean
  /**
   * DEV/VERIFICATION ONLY: when true, /auth/captcha also returns the captcha
   * text so login can be exercised with curl. Never enable in production.
   */
  devCaptchaText: boolean
  /**
   * Fixed default credentials for a fresh install. When the gate starts and
   * the password file contains NO accounts at all, the initial account
   * defaultAdminUser is created with defaultPassword (bcrypt, mode 0600)
   * so the installer can log in out of the box: the default credentials are
   * a PUBLIC value documented in the README and printed once in the startup
   * log, and the login response flags the account with mustChangePassword
   * so the client forces a password change on first login. Disable the
   * auto-provisioning entirely with autoProvisionAdmin: false; existing
   * password files (any account present) are never touched.
   */
  defaultAdminUser: string
  defaultPassword: string
  autoProvisionAdmin: boolean
}

export const Config = z.object({
  passwordFile: z.string().default('~/.dsh/auth.passwd'),
  sessionTimeout: z.number().default(3600),
  captchaExpires: z.number().default(300),
  maxLoginAttempts: z.number().default(5),
  accountMaxLoginAttempts: z.number().default(10),
  blockDuration: z.number().default(300),
  bindSessionToIp: z.boolean().default(false),
  singleSessionPerUser: z.boolean().default(true),
  trustProxy: z.boolean().default(false),
  devCaptchaText: z.boolean().default(false),
  defaultAdminUser: z.string().min(1).max(32).pattern(/^[^\s:]+$/u).default('admin'),
  defaultPassword: z.string().min(8).default('admin123'),
  autoProvisionAdmin: z.boolean().default(true),
})

interface Session { username: string; expires: number; ip: string; mustChangePassword: boolean; mustChangeUsername: boolean }
interface CaptchaRecord { text: string; expires: number }
interface FailureRecord {
  attempts: number
  /** When this record was created / last reset (unused once blocked). */
  firstAttempt: number
  /** Epoch ms until which the IP is locked; 0 = not blocked. */
  blockedUntil: number
  /** Epoch ms of the most recent failure — window for "consecutive". */
  lastAttempt: number
}

/** token → session */
const sessions = new Map<string, Session>()
/** captcha uuid → record (single-use) */
const captchaStore = new Map<string, CaptchaRecord>()
/** client IP → failure counter */
const failureStore = new Map<string, FailureRecord>()
/** account (username) → credential-failure counter, all IPs combined */
const accountFailureStore = new Map<string, FailureRecord>()
/** client IP → captcha fetch window counter (see CAPTCHA_FETCH_LIMIT) */
const captchaFetchStore = new Map<string, { count: number; windowStart: number }>()

// ── runtime-managed security settings ────────────────────────────────────────
// sessionTimeout / captchaExpires / maxLoginAttempts / blockDuration /
// trustProxy can be changed at runtime by a logged-in user through
// POST /auth/security (exposed in the 个人配置 → 安全设置 panel). The new
// values apply to the running process immediately and are persisted to a JSON
// override file NEXT TO the password file so they survive restarts; the static
// cordis.patch.yml keeps its defaults as the base layer. The overrides file is
// parsed defensively (a hand-edited or corrupt file can only fall back to the
// static config, never crash the gate or escape the bounds below).

/** Safe bounds for the runtime-managed numeric settings (seconds / count). */
const SECURITY_LIMITS = {
  sessionTimeout: { min: 60, max: 86400 },
  captchaExpires: { min: 30, max: 3600 },
  maxLoginAttempts: { min: 1, max: 100 },
  blockDuration: { min: 30, max: 86400 },
} as const

/** Filename of the runtime override file, placed in the password file's directory. */
const SECURITY_FILE_NAME = 'auth-gate.security.json'

/** Byte limit enforced on every /auth request body (see parseBody). */
const REQUEST_BODY_LIMIT_BYTES = 64 * 1024

/** Per-IP captcha-fetch limit inside CAPTCHA_FETCH_WINDOW_MS (plugin-level throttle). */
const CAPTCHA_FETCH_LIMIT = 60
const CAPTCHA_FETCH_WINDOW_MS = 60_000
/** Hard cap on live captcha records; bounds memory even under a many-IP flood. */
const CAPTCHA_STORE_CAP = 5000

/** Epoch ms of the last runtime update via POST /auth/security; null = never. */
let securityUpdatedAt: number | null = null

export function apply(ctx: Context, config: Config) {
  const logger = ctx.logger(name)
  const passwdPath = expandHome(config.passwordFile)
  // Runtime-managed settings: static config first, override file on top. The
  // override object is SHARED (mutated by POST /auth/security), so every
  // handler and the sweep timer see changes immediately, without touching the
  // Cordis-owned config tree.
  const securityFile = path.join(path.dirname(passwdPath), SECURITY_FILE_NAME)
  const overrides = loadSecurityOverrides(securityFile)
  const effective: Config = { ...config, ...overrides }

  ctx.effect(() => {
    const disposers: Array<() => void> = []
    try {
      // Fresh-install bootstrap: when the password file has no accounts at
      // all, provision the documented default account so the installer can
      // log in out of the box (the login then forces a password change).
      // Runs BEFORE the routes are registered, so a first request can never
      // race the provisioning. Existing files are never touched.
      provisionInitialAccount(passwdPath, effective, logger)
      disposers.push(ctx.webServer.register({
        kind: 'prefix',
        path: '/auth',
        handler: (req, res) => handleAuthRequest(req, res, effective, passwdPath, securityFile, logger),
      }))
      const sweepTimer = setInterval(() => sweep(effective), 60_000)
      disposers.push(() => clearInterval(sweepTimer))
    } catch (error) {
      for (const dispose of disposers.reverse()) dispose()
      throw error
    }
    logger.info('dsh-auth-gate mounted: passwordFile=%s sessionTimeout=%ds captchaExpires=%ds maxLoginAttempts=%d blockDuration=%ds trustProxy=%s', passwdPath, effective.sessionTimeout, effective.captchaExpires, effective.maxLoginAttempts, effective.blockDuration, String(effective.trustProxy))
    const overrideKeys = Object.keys(overrides)
    if (overrideKeys.length > 0) logger.info('dsh-auth-gate: runtime security overrides loaded from %s (%d keys)', securityFile, overrideKeys.length)
    if (effective.devCaptchaText) logger.warn('dsh-auth-gate: devCaptchaText is enabled — captcha answers are echoed to clients; never enable this in production')
    if (effective.trustProxy) logger.warn('dsh-auth-gate: trustProxy is enabled — X-Forwarded-For is honored from loopback peers; verify a same-host reverse proxy actually fronts this service, otherwise any direct client can forge the header to bypass the per-IP lockout')
    return () => {
      for (const dispose of disposers.reverse()) dispose()
      // Drop all in-memory state on teardown: a hot-reload must not inherit
      // stale sessions, captchas or failure counters (in-memory by design).
      sessions.clear()
      captchaStore.clear()
      failureStore.clear()
      accountFailureStore.clear()
      captchaFetchStore.clear()
      securityUpdatedAt = null
    }
  }, 'dsh-auth-gate: routes + sweep')
}

// ── router ──────────────────────────────────────────────────────────────────

async function handleAuthRequest(
  req: IncomingMessage,
  res: ServerResponse,
  config: Config,
  passwdPath: string,
  securityFile: string,
  logger: ReturnType<Context['logger']>,
): Promise<void> {
  const pathname = new URL(req.url ?? '/', 'http://localhost').pathname
  const clientIp = getClientIp(req, config.trustProxy)
  try {
    if (pathname === '/auth/captcha' && req.method === 'GET') {
      handleCaptcha(res, config, clientIp)
      return
    }
    if (pathname === '/auth/login' && req.method === 'POST') {
      await handleLogin(req, res, config, passwdPath, clientIp, logger)
      return
    }
    if (pathname === '/auth/verify' && req.method === 'GET') {
      handleVerify(req, res, config)
      return
    }
    if (pathname === '/auth/logout' && req.method === 'POST') {
      handleLogout(req, res)
      return
    }
    if (pathname === '/auth/password' && req.method === 'POST') {
      await handleChangePassword(req, res, config, passwdPath, clientIp, logger)
      return
    }
    if (pathname === '/auth/username' && req.method === 'POST') {
      await handleChangeUsername(req, res, config, passwdPath, logger)
      return
    }
    if (pathname === '/auth/security' && req.method === 'GET') {
      handleSecurityStatus(req, res, config)
      return
    }
    if (pathname === '/auth/security' && req.method === 'POST') {
      await handleSecurityUpdate(req, res, config, securityFile)
      return
    }
    if (pathname === '/auth' || pathname.startsWith('/auth/')) {
      json(res, 404, { error: 'Not Found' } satisfies AuthError)
      return
    }
    // Paths outside /auth are not ours; the webserver fallback answers them.
    res.writeHead(404)
    res.end()
  } catch (error) {
    if (error instanceof BodyTooLargeError) {
      // Clean 413 (no connection reset) while still draining the body so
      // keep-alive sockets can be reused.
      if (!res.headersSent) {
        json(res, 413, { error: '请求体过大' } satisfies AuthError)
      } else {
        res.destroy()
      }
      return
    }
    if (error instanceof InvalidContentTypeError) {
      if (!res.headersSent) {
        json(res, 415, { error: '请求体必须是 application/json' } satisfies AuthError)
      } else {
        res.destroy()
      }
      return
    }
    logger.warn('auth handler failed: %s', error instanceof Error ? error.message : String(error))
    if (!res.headersSent) {
      json(res, 500, { error: 'Internal Server Error' } satisfies AuthError)
    } else {
      res.destroy()
    }
  }
}

// ── endpoints ───────────────────────────────────────────────────────────────

function handleCaptcha(res: ServerResponse, config: Config, clientIp: string): void {
  // Plugin-level per-IP throttle: without Nginx in front, /auth/captcha would
  // accept unlimited fetches (unbounded captchaStore growth, unlimited OCR
  // harvesting for automated solving). Nginx limit_req is the coarse layer;
  // this bound works even on a direct deployment.
  const now = Date.now()
  const window = captchaFetchStore.get(clientIp)
  if (window === undefined || now - window.windowStart >= CAPTCHA_FETCH_WINDOW_MS) {
    captchaFetchStore.set(clientIp, { count: 1, windowStart: now })
  } else if (window.count >= CAPTCHA_FETCH_LIMIT) {
    json(res, 429, { error: '验证码获取过于频繁，请稍后再试' } satisfies AuthError)
    return
  } else {
    window.count += 1
  }
  // Bounded store: drop expired records inline before deciding, so a many-IP
  // flood cannot grow captchaStore without limit.
  if (captchaStore.size >= CAPTCHA_STORE_CAP) {
    for (const [uuid, record] of captchaStore) if (record.expires < now) captchaStore.delete(uuid)
    if (captchaStore.size >= CAPTCHA_STORE_CAP) {
      json(res, 503, { error: '验证码服务繁忙，请稍后再试' } satisfies AuthError)
      return
    }
  }
  const captcha = svgCaptcha.create({
    size: 4,
    ignoreChars: '0o1i',
    noise: 3,
    color: true,
    background: '#f0f2f5',
  })
  const uuid = crypto.randomUUID()
  captchaStore.set(uuid, {
    text: captcha.text.toLowerCase(),
    expires: now + config.captchaExpires * 1000,
  })
  if (config.devCaptchaText) {
    json(res, 200, { svg: captcha.data, uuid, text: captcha.text } satisfies CaptchaResponse & { text: string })
    return
  }
  json(res, 200, { svg: captcha.data, uuid } satisfies CaptchaResponse)
}

async function handleLogin(
  req: IncomingMessage,
  res: ServerResponse,
  config: Config,
  passwdPath: string,
  clientIp: string,
  logger: ReturnType<Context['logger']>,
): Promise<void> {
  const body = await parseBody(req)
  const username = typeof body.username === 'string' ? body.username : ''
  const password = typeof body.password === 'string' ? body.password : ''
  const captcha = typeof body.captcha === 'string' ? body.captcha.trim().toLowerCase() : ''
  const uuid = typeof body.uuid === 'string' ? body.uuid : ''

  const now = Date.now()

  // 1. Blocked? (per-IP first, then per-account)
  const failure = failureStore.get(clientIp)
  if (failure !== undefined && failure.blockedUntil > now) {
    const remaining = Math.ceil((failure.blockedUntil - now) / 1000)
    logger.warn('auth: login blocked for ip=%s (lockout, %ds remaining)', clientIp, remaining)
    json(res, 429, { error: '请求过于频繁，请 ' + String(remaining) + ' 秒后重试', blockedUntil: failure.blockedUntil } satisfies AuthError)
    return
  }
  if (username.length > 0 && isAccountBlocked(username, config)) {
    const accountFailure = accountFailureStore.get(username)
    const remaining = accountFailure === undefined ? 0 : Math.ceil((accountFailure.blockedUntil - now) / 1000)
    logger.warn('auth: login blocked for user=%s (account lockout, %ds remaining)', username, remaining)
    json(res, 429, { error: '该账号尝试过于频繁，请 ' + String(remaining) + ' 秒后重试', blockedUntil: accountFailure?.blockedUntil } satisfies AuthError)
    return
  }

  // 2. Captcha (single use). Unknown, expired AND wrong captchas all count as
  // failed attempts: without this an attacker could hammer /auth/login with
  // garbage uuids forever without ever advancing the per-IP lockout.
  const stored = uuid.length > 0 ? captchaStore.get(uuid) : undefined
  if (stored === undefined || stored.expires < now) {
    if (stored !== undefined) captchaStore.delete(uuid)
    recordFailure(clientIp, config)
    logger.warn('auth: login failed for ip=%s username=%s reason=captcha-expired-or-unknown', clientIp, username)
    json(res, 400, { error: '验证码已过期，请重新获取' } satisfies AuthError)
    return
  }
  if (captcha.length === 0 || stored.text !== captcha) {
    captchaStore.delete(uuid)
    recordFailure(clientIp, config)
    logger.warn('auth: login failed for ip=%s username=%s reason=captcha-wrong', clientIp, username)
    json(res, 400, { error: '验证码错误' } satisfies AuthError)
    return
  }
  captchaStore.delete(uuid)

  // 3. Credentials
  if (username.length === 0 || password.length === 0) {
    recordFailure(clientIp, config)
    logger.warn('auth: login failed for ip=%s reason=empty-credentials', clientIp)
    json(res, 400, { error: '用户名和密码不能为空' } satisfies AuthError)
    return
  }
  const storedHash = await verifyPassword(passwdPath, username, password)
  if (storedHash === null) {
    recordFailure(clientIp, config)
    recordAccountFailure(username, config)
    logger.warn('auth: login failed for ip=%s username=%s reason=credentials', clientIp, username)
    json(res, 401, { error: '用户名或密码错误' } satisfies AuthError)
    return
  }
  // The account is still on the fixed default password (fresh install or an
  // admin reset to it): flag the login so the client forces a change before
  // releasing the UI. Once the password is changed the hash no longer
  // matches, so the flag disappears on the next login.
  const mustChangePassword = await bcrypt.compare(config.defaultPassword, storedHash)
  // The account name is still the reserved default admin user: force a
  // rename so the public default name stops working. Re-evaluated on every
  // login; renaming back to defaultAdminUser is rejected by the rename API.
  const mustChangeUsername = username === config.defaultAdminUser

  // 4. Success: clear failures, then apply the single-session policy — every
  // previously issued session for this account is destroyed, so the account is
  // logged in at exactly one place. The old client keeps its token locally but
  // its next /auth/verify (or any guarded API call) fails with 401: it is
  // kicked at the enforcement point. The new token is minted AFTER the sweep
  // so it can never be swept by its own login.
  failureStore.delete(clientIp)
  accountFailureStore.delete(username)
  let kickedPrevious = false
  if (config.singleSessionPerUser) {
    for (const [t, s] of sessions) {
      if (s.username === username) {
        sessions.delete(t)
        kickedPrevious = true
      }
    }
  }
  const token = crypto.randomBytes(32).toString('hex')
  sessions.set(token, { username, expires: now + config.sessionTimeout * 1000, ip: clientIp, mustChangePassword, mustChangeUsername })
  const forced = mustChangePassword || mustChangeUsername
  logger.info('auth: login ok for ip=%s username=%s%s%s', clientIp, username, kickedPrevious ? ' (previous session kicked)' : '', forced ? ' (default credentials — change required)' : '')
  json(res, 200, {
    token,
    username,
    expiresIn: config.sessionTimeout,
    ...(kickedPrevious ? { kickedPrevious: true } : {}),
    ...(mustChangePassword ? { mustChangePassword: true } : {}),
    ...(mustChangeUsername ? { mustChangeUsername: true } : {}),
  } satisfies LoginResponse)
}

function handleVerify(req: IncomingMessage, res: ServerResponse, config: Config): void {
  const token = bearerToken(req)
  const now = Date.now()
  if (token.length === 0) {
    res.writeHead(401, { 'www-authenticate': 'Bearer', 'content-type': 'text/plain; charset=utf-8' })
    res.end('Unauthorized')
    return
  }
  const session = sessions.get(token)
  if (session === undefined || session.expires < now) {
    if (session !== undefined) sessions.delete(token)
    res.writeHead(401, { 'content-type': 'text/plain; charset=utf-8' })
    res.end('Session expired')
    return
  }
  if (config.bindSessionToIp && session.ip !== getClientIp(req, config.trustProxy)) {
    // Token used from a different IP than it was minted for: destroy it.
    sessions.delete(token)
    res.writeHead(401, { 'content-type': 'text/plain; charset=utf-8' })
    res.end('Session expired')
    return
  }
  // Sliding window
  session.expires = now + config.sessionTimeout * 1000
  res.writeHead(200, {
    'x-auth-user': session.username,
    // Lets the client re-enter the forced-change screens after a page
    // reload (the must-change state lives on the session, so it survives
    // verify without a password-file read on every request).
    ...(session.mustChangePassword ? { 'x-auth-must-change': '1' } : {}),
    ...(session.mustChangeUsername ? { 'x-auth-must-change-name': '1' } : {}),
  })
  res.end('OK')
}

function handleLogout(req: IncomingMessage, res: ServerResponse): void {
  const token = bearerToken(req)
  if (token.length > 0) sessions.delete(token)
  json(res, 200, { ok: true } satisfies LogoutResponse)
}

// ── change password ─────────────────────────────────────────────────────────

/** bcrypt cost used for new hashes written by the change-password flow. */
const BCRYPT_ROUNDS = 12
/**
 * Pre-computed hash of a throwaway phrase. Compared against when the username
 * does not exist so login latency cannot leak whether an account is valid.
 */
const DUMMY_HASH = bcrypt.hashSync('dsh-auth-gate dummy comparison', BCRYPT_ROUNDS)
/** Serialize password-file read-verify-write so concurrent requests cannot interleave. */
let passwordWriteQueue: Promise<void> = Promise.resolve()

async function handleChangePassword(
  req: IncomingMessage,
  res: ServerResponse,
  config: Config,
  passwdPath: string,
  clientIp: string,
  logger: ReturnType<Context['logger']>,
): Promise<void> {
  const now = Date.now()

  // 1. Authenticated session required
  const session = requireSession(req, config)
  if (session === undefined) {
    res.writeHead(401, { 'content-type': 'text/plain; charset=utf-8' })
    res.end('Unauthorized')
    return
  }

  // 2. Same per-IP lockout as login
  const failure = failureStore.get(clientIp)
  if (failure !== undefined && failure.blockedUntil > now) {
    const remaining = Math.ceil((failure.blockedUntil - now) / 1000)
    json(res, 429, { error: '请求过于频繁，请 ' + String(remaining) + ' 秒后重试', blockedUntil: failure.blockedUntil } satisfies AuthError)
    return
  }

  // 3. Validate input (bcrypt only reads the first 72 bytes; enforce a sane floor)
  const body = await parseBody(req)
  const oldPassword = typeof body.oldPassword === 'string' ? body.oldPassword : ''
  const newPassword = typeof body.newPassword === 'string' ? body.newPassword : ''
  if (newPassword.length < 8) {
    json(res, 400, { error: '新密码至少 8 个字符' } satisfies AuthError)
    return
  }
  if (Buffer.byteLength(newPassword, 'utf8') > 72) {
    json(res, 400, { error: '新密码过长（最多 72 字节）' } satisfies AuthError)
    return
  }
  if (oldPassword === newPassword) {
    json(res, 400, { error: '新密码不能与旧密码相同' } satisfies AuthError)
    return
  }

  // 4+5. Verify the old password and rewrite the file inside ONE serialized
  // task: no concurrent change-password request can interleave a write between
  // the read and the write (TOCTOU). The CLI is outside this queue, but it is
  // an admin-only tool; the in-plugin race is closed.
  const outcome = await enqueuePasswordWrite(async () => {
    const storedHash = await verifyPassword(passwdPath, session.username, oldPassword)
    if (storedHash === null) return { status: 403, error: '旧密码错误' } as const
    const hash = await bcrypt.hash(newPassword, BCRYPT_ROUNDS)
    try {
      await updatePasswordFile(passwdPath, session.username, hash)
    } catch (error) {
      logger.error('password file update failed: %s', error instanceof Error ? error.message : String(error))
      return { status: 500, error: '密码文件写入失败，请稍后重试' } as const
    }
    return { status: 200 } as const
  })
  if (outcome.status !== 200) {
    if (outcome.status === 403) {
      recordFailure(clientIp, config)
      recordAccountFailure(session.username, config)
      logger.warn('auth: password change failed for user=%s ip=%s reason=wrong-old-password', session.username, clientIp)
    }
    json(res, outcome.status, { error: outcome.error } satisfies AuthError)
    return
  }

  // 6. Success: clear failures, invalidate the user's other sessions (this
  // one keeps working; the request's own token is no longer in scope here),
  // and clear the forced password-change flag: the account no longer uses
  // the default password, so this session is allowed past the gate.
  failureStore.delete(clientIp)
  accountFailureStore.delete(session.username)
  session.mustChangePassword = false
  const currentToken = bearerToken(req)
  for (const [t, s] of sessions) {
    if (t !== currentToken && s.username === session.username) sessions.delete(t)
  }
  json(res, 200, { ok: true } satisfies PasswordChangeResponse)
}

/** Run a task after every previously queued password-file task, keeping failures isolated. */
function enqueuePasswordWrite<T>(task: () => Promise<T>): Promise<T> {
  const run = passwordWriteQueue.then(task, task)
  passwordWriteQueue = run.then(() => {}, () => {})
  return run
}

/**
 * Atomic read-modify-write of one user's line in the password file.
 * MUST be called inside enqueuePasswordWrite() so the read and the write
 * cannot interleave with another mutation.
 */
async function updatePasswordFile(passwdPath: string, username: string, newHash: string): Promise<void> {
  const content = await fs.readFile(passwdPath, 'utf-8')
  const lines = content.split(/\r?\n/)
  let replaced = false
  const out: string[] = []
  for (const line of lines) {
    const trimmed = line.trim()
    if (trimmed.length === 0 || trimmed.startsWith('#')) {
      out.push(line)
      continue
    }
    const sep = trimmed.indexOf(':')
    const user = sep === -1 ? trimmed : trimmed.slice(0, sep)
    out.push(user === username ? username + ':' + newHash : line)
    if (user === username) replaced = true
  }
  if (!replaced) out.push(username + ':' + newHash)
  await fs.mkdir(path.dirname(passwdPath), { recursive: true })
  const tmp = passwdPath + '.tmp'
  await fs.writeFile(tmp, out.join('\n').replace(/\n+$/, '') + '\n', { mode: 0o600 })
  await fs.rename(tmp, passwdPath)
}

// ── change username ─────────────────────────────────────────────────────────

/**
 * Rename the authenticated account inside the same serialized password-file
 * queue as change-password, so a concurrent password change can never
 * interleave between the read and the write. All of the user's sessions (this
 * one included) keep working and report the new name afterwards.
 */
async function handleChangeUsername(
  req: IncomingMessage,
  res: ServerResponse,
  config: Config,
  passwdPath: string,
  logger: ReturnType<Context['logger']>,
): Promise<void> {
  // 1. Authenticated session required
  const session = requireSession(req, config)
  if (session === undefined) {
    res.writeHead(401, { 'content-type': 'text/plain; charset=utf-8' })
    res.end('Unauthorized')
    return
  }

  // 2. Validate the new name. The password file is 'user:hash' per line, so
  // colons and whitespace (incl. embedded newlines) must stay out.
  const body = await parseBody(req)
  const newUsername = typeof body.newUsername === 'string' ? body.newUsername.trim() : ''
  if (newUsername.length < 1 || newUsername.length > 32) {
    json(res, 400, { error: '账号名称长度需为 1-32 个字符' } satisfies AuthError)
    return
  }
  if (/[\s:]/u.test(newUsername)) {
    json(res, 400, { error: '账号名称不能包含空格或冒号' } satisfies AuthError)
    return
  }
  if (newUsername === session.username) {
    json(res, 400, { error: '新名称与当前名称相同' } satisfies AuthError)
    return
  }
  // The default admin user name is reserved: once the initial account is
  // renamed away from it (or any other account tries to claim it), the
  // public default name must stay unusable — nobody can rename TO it.
  if (newUsername === config.defaultAdminUser) {
    json(res, 400, { error: '该账号名称已被保留，不能使用' } satisfies AuthError)
    return
  }

  // 3. Atomic rename inside the serialized write queue.
  const outcome = await enqueuePasswordWrite(async () => {
    try {
      return await renameUserInPasswordFile(passwdPath, session.username, newUsername)
    } catch (error) {
      logger.error('password file rename failed: %s', error instanceof Error ? error.message : String(error))
      return 'write-error' as const
    }
  })
  if (outcome !== 'renamed') {
    if (outcome === 'not-found') json(res, 404, { error: '账号不存在' } satisfies AuthError)
    else if (outcome === 'taken') json(res, 400, { error: '账号名称已存在' } satisfies AuthError)
    else json(res, 500, { error: '密码文件写入失败，请稍后重试' } satisfies AuthError)
    return
  }

  // 4. Success: every live session of this user follows the rename, so
  // /auth/verify keeps answering with the new X-Auth-User. The old name is
  // captured up front: the first match is session itself, and mutating it
  // inside the loop must not shift the comparison for the other sessions.
  // Renaming away from the reserved default name clears the forced-rename
  // flag on this session (the other sessions are re-keyed above).
  const oldUsername = session.username
  accountFailureStore.delete(oldUsername)
  if (oldUsername === config.defaultAdminUser) session.mustChangeUsername = false
  for (const [, s] of sessions) {
    if (s.username === oldUsername) s.username = newUsername
  }
  json(res, 200, { ok: true, username: newUsername } satisfies UsernameChangeResponse)
}

/**
 * Rewrite one user's line in the password file under the new name.
 * MUST be called inside enqueuePasswordWrite() so the read and the write
 * cannot interleave with another mutation.
 *
 * @returns 'renamed' | 'not-found' (old name has no line) | 'taken' (new name already in use)
 */
async function renameUserInPasswordFile(
  passwdPath: string,
  oldUsername: string,
  newUsername: string,
): Promise<'renamed' | 'not-found' | 'taken'> {
  const content = await fs.readFile(passwdPath, 'utf-8')
  const lines = content.split(/\r?\n/)
  let found = false
  let taken = false
  const out: string[] = []
  for (const line of lines) {
    const trimmed = line.trim()
    if (trimmed.length === 0 || trimmed.startsWith('#')) {
      out.push(line)
      continue
    }
    const sep = trimmed.indexOf(':')
    const user = sep === -1 ? trimmed : trimmed.slice(0, sep)
    if (user === oldUsername) {
      found = true
      // Keep the original hash (and anything else after the separator) intact.
      out.push(sep === -1 ? newUsername : newUsername + trimmed.slice(sep))
    } else {
      if (user === newUsername) taken = true
      out.push(line)
    }
  }
  if (!found) return 'not-found'
  if (taken) return 'taken'
  await fs.mkdir(path.dirname(passwdPath), { recursive: true })
  const tmp = passwdPath + '.tmp'
  await fs.writeFile(tmp, out.join('\n').replace(/\n+$/, '') + '\n', { mode: 0o600 })
  await fs.rename(tmp, passwdPath)
  return 'renamed'
}

// ── security settings (runtime-managed) ────────────────────────────────────

/**
 * GET /auth/security — current effective settings plus live status.
 * Requires a valid session; returns SecurityStatus.
 */
function handleSecurityStatus(req: IncomingMessage, res: ServerResponse, config: Config): void {
  const session = requireSession(req, config)
  if (session === undefined) {
    res.writeHead(401, { 'content-type': 'text/plain; charset=utf-8' })
    res.end('Unauthorized')
    return
  }
  json(res, 200, buildSecurityStatus(config))
}

/**
 * POST /auth/security — update the runtime-managed settings. Requires a valid
 * session. Only the keys present in the body change; each value is validated
 * against SECURITY_LIMITS, and the change is persisted atomically (tmp +
 * rename, mode 0600) next to the password file BEFORE it is applied to the
 * shared config, so a write failure never leaves the process half-updated.
 */
async function handleSecurityUpdate(
  req: IncomingMessage,
  res: ServerResponse,
  config: Config,
  securityFile: string,
): Promise<void> {
  const session = requireSession(req, config)
  if (session === undefined) {
    res.writeHead(401, { 'content-type': 'text/plain; charset=utf-8' })
    res.end('Unauthorized')
    return
  }

  const body = await parseBody(req)
  const patch: Pick<Config, 'sessionTimeout' | 'captchaExpires' | 'maxLoginAttempts' | 'blockDuration' | 'trustProxy' | 'singleSessionPerUser'> = {} as Pick<Config, 'sessionTimeout' | 'captchaExpires' | 'maxLoginAttempts' | 'blockDuration' | 'trustProxy' | 'singleSessionPerUser'>
  const errors: string[] = []

  for (const key of ['sessionTimeout', 'captchaExpires', 'maxLoginAttempts', 'blockDuration'] as const) {
    if (!(key in body)) continue
    const value = body[key]
    if (typeof value !== 'number' || !Number.isFinite(value)) {
      errors.push(key + ' 必须是数字')
      continue
    }
    const limit = SECURITY_LIMITS[key]
    const clamped = Math.round(value)
    if (clamped < limit.min || clamped > limit.max) {
      errors.push(key + ' 需在 ' + limit.min + '–' + limit.max + ' 之间')
      continue
    }
    patch[key] = clamped
  }
  if ('trustProxy' in body) {
    if (typeof body.trustProxy !== 'boolean') errors.push('trustProxy 必须是布尔值')
    else patch.trustProxy = body.trustProxy
  }
  if ('singleSessionPerUser' in body) {
    if (typeof body.singleSessionPerUser !== 'boolean') errors.push('singleSessionPerUser 必须是布尔值')
    else patch.singleSessionPerUser = body.singleSessionPerUser
  }

  if (errors.length > 0) {
    json(res, 400, { error: '参数无效：' + errors.join('；') } satisfies AuthError)
    return
  }
  if (Object.keys(patch).length === 0) {
    json(res, 400, { error: '没有可更新的设置' } satisfies AuthError)
    return
  }

  try {
    await writeSecurityOverrides(securityFile, patch)
  } catch {
    json(res, 500, { error: '安全设置写入失败，请稍后重试' } satisfies AuthError)
    return
  }
  // Apply to the shared config object: every handler and the sweep timer read
  // through it, so the change takes effect immediately.
  Object.assign(config, patch)
  securityUpdatedAt = Date.now()
  json(res, 200, buildSecurityStatus(config))
}

/** Require a live session (with the IP binding when enabled); undefined → 401 (caller writes it). */
function requireSession(req: IncomingMessage, config: Config): Session | undefined {
  const token = bearerToken(req)
  const now = Date.now()
  const session = token.length > 0 ? sessions.get(token) : undefined
  if (session === undefined || session.expires < now) {
    if (session !== undefined) sessions.delete(token)
    return undefined
  }
  if (config.bindSessionToIp && session.ip !== getClientIp(req, config.trustProxy)) {
    sessions.delete(token)
    return undefined
  }
  return session
}

/** Compose the SecurityStatus payload from the effective config + live state. */
function buildSecurityStatus(config: Config): SecurityStatus {
  const now = Date.now()
  let blockedIps = 0
  for (const failure of failureStore.values()) if (failure.blockedUntil > now) blockedIps += 1
  return {
    sessionTimeout: config.sessionTimeout,
    captchaExpires: config.captchaExpires,
    maxLoginAttempts: config.maxLoginAttempts,
    accountMaxLoginAttempts: config.accountMaxLoginAttempts,
    blockDuration: config.blockDuration,
    trustProxy: config.trustProxy,
    bindSessionToIp: config.bindSessionToIp,
    singleSessionPerUser: config.singleSessionPerUser,
    devCaptchaText: config.devCaptchaText,
    passwordFile: expandHome(config.passwordFile),
    bodyLimitBytes: REQUEST_BODY_LIMIT_BYTES,
    activeSessions: sessions.size,
    blockedIps,
    updatedAt: securityUpdatedAt,
  }
}

/**
 * Read the runtime override file once at startup. Defensive: a missing,
 * corrupt or out-of-bounds entry simply falls back to the static config —
 * the override layer can never crash the gate or escape the safe bounds.
 */
function loadSecurityOverrides(securityFile: string): Partial<Config> {
  let raw: string
  try {
    raw = readFileSync(securityFile, 'utf-8')
  } catch {
    return {} // missing or unreadable → static config only
  }
  let parsed: unknown
  try {
    parsed = JSON.parse(raw)
  } catch {
    return {}
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) return {}
  const record = parsed as Record<string, unknown>
  const out: Partial<Config> = {}
  for (const key of ['sessionTimeout', 'captchaExpires', 'maxLoginAttempts', 'blockDuration'] as const) {
    const value = record[key]
    if (typeof value !== 'number' || !Number.isFinite(value)) continue
    const limit = SECURITY_LIMITS[key]
    out[key] = Math.min(limit.max, Math.max(limit.min, Math.round(value)))
  }
  if (typeof record.trustProxy === 'boolean') out.trustProxy = record.trustProxy
  if (typeof record.singleSessionPerUser === 'boolean') out.singleSessionPerUser = record.singleSessionPerUser
  return out
}

/**
 * Atomic read-merge-write of the override file (tmp + rename, mode 0600), so
 * concurrent updates cannot corrupt it and a crash cannot leave a partial
 * file. Only the runtime-managed keys are ever written back.
 */
async function writeSecurityOverrides(
  securityFile: string,
  patch: Pick<Config, 'sessionTimeout' | 'captchaExpires' | 'maxLoginAttempts' | 'blockDuration' | 'trustProxy' | 'singleSessionPerUser'>,
): Promise<void> {
  let merged: Record<string, unknown> = {}
  try {
    const existing = await fs.readFile(securityFile, 'utf-8')
    const parsed: unknown = JSON.parse(existing)
    if (parsed !== null && typeof parsed === 'object' && !Array.isArray(parsed)) {
      merged = { ...(parsed as Record<string, unknown>) }
    }
  } catch {
    // missing or corrupt file → start from an empty override
  }
  Object.assign(merged, patch)
  const tmp = securityFile + '.tmp'
  await fs.writeFile(tmp, JSON.stringify(merged, null, 2) + "\n", { mode: 0o600 })
  await fs.rename(tmp, securityFile)
}

// ── helpers ─────────────────────────────────────────────────────────────────

function bearerToken(req: IncomingMessage): string {
  const header = req.headers['authorization']
  return typeof header === 'string' ? header.replace(/^Bearer\s+/i, '').trim() : ''
}

function recordFailure(ip: string, config: Config): void {
  const now = Date.now()
  const existing = failureStore.get(ip)
  // Only failures inside one rolling blockDuration window count as "consecutive":
  // a fresh window (or a fresh IP) restarts at 1, so an occasional typo long ago
  // cannot push a user into a lockout together with a recent slip.
  if (existing === undefined || now - existing.lastAttempt > config.blockDuration * 1000) {
    // A threshold of 1 must lock on the very first failure.
    failureStore.set(ip, {
      attempts: 1,
      firstAttempt: now,
      blockedUntil: 1 >= config.maxLoginAttempts ? now + config.blockDuration * 1000 : 0,
      lastAttempt: now,
    })
    return
  }
  existing.attempts += 1
  existing.lastAttempt = now
  if (existing.attempts >= config.maxLoginAttempts) {
    existing.blockedUntil = now + config.blockDuration * 1000
  }
}

/**
 * Count a credential failure (wrong password / unknown user) against the
 * ACCOUNT, across all IPs. Captcha failures deliberately do NOT touch this
 * counter: they are already per-IP, and counting them here would let an
 * attacker lock a victim's account by spamming wrong captchas.
 */
function recordAccountFailure(username: string, config: Config): void {
  const now = Date.now()
  const existing = accountFailureStore.get(username)
  // Same rolling-window semantics as recordFailure.
  if (existing === undefined || now - existing.lastAttempt > config.blockDuration * 1000) {
    accountFailureStore.set(username, {
      attempts: 1,
      firstAttempt: now,
      blockedUntil: 1 >= config.accountMaxLoginAttempts ? now + config.blockDuration * 1000 : 0,
      lastAttempt: now,
    })
    return
  }
  existing.attempts += 1
  existing.lastAttempt = now
  if (existing.attempts >= config.accountMaxLoginAttempts) {
    existing.blockedUntil = now + config.blockDuration * 1000
  }
}

function isAccountBlocked(username: string, config: Config): boolean {
  const record = accountFailureStore.get(username)
  return record !== undefined && record.blockedUntil > Date.now()
}

/**
 * Verify credentials against the password file.
 * @returns the stored bcrypt hash on success, or null when the credentials
 * are wrong / the account does not exist (a dummy comparison keeps the
 * response time from leaking whether the username exists).
 */
async function verifyPassword(passwdPath: string, username: string, password: string): Promise<string | null> {
  let content: string
  try {
    content = await fs.readFile(passwdPath, 'utf-8')
  } catch {
    return null // missing/unreadable password file denies everything
  }
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim()
    if (line.length === 0 || line.startsWith('#')) continue
    const sep = line.indexOf(':')
    if (sep === -1) continue
    const storedUser = line.slice(0, sep)
    const hash = line.slice(sep + 1).trim()
    if (storedUser === username && hash.length > 0) {
      try {
        return (await bcrypt.compare(password, hash)) ? hash : null
      } catch {
        return null // malformed hash denies
      }
    }
  }
  // Unknown user (or empty hash): run one dummy comparison so the response
  // time does not reveal whether the username exists (timing side channel).
  await bcrypt.compare(password, DUMMY_HASH)
  return null
}

/**
 * Fresh-install bootstrap: if the password file contains NO valid account
 * line, create the documented default account (defaultAdminUser with the
 * defaultPassword, bcrypt, mode 0600) so the installer can log in out of the
 * box. The default password is PUBLIC (README + this startup log); the login
 * flow flags the account with mustChangePassword so the client forces a
 * password change on first login. Existing password files are never touched;
 * the whole mechanism can be switched off with autoProvisionAdmin: false.
 */
function provisionInitialAccount(passwdPath: string, config: Config, logger: ReturnType<Context['logger']>): void {
  if (!config.autoProvisionAdmin) return
  if (countValidAccounts(passwdPath) > 0) return
  const hash = bcrypt.hashSync(config.defaultPassword, BCRYPT_ROUNDS)
  try {
    mkdirSync(path.dirname(passwdPath), { recursive: true })
    const tmp = passwdPath + '.tmp'
    writeFileSync(tmp, config.defaultAdminUser + ':' + hash + '\n', { mode: 0o600 })
    renameSync(tmp, passwdPath)
  } catch (error) {
    logger.warn('dsh-auth-gate: failed to provision the initial account: %s', error instanceof Error ? error.message : String(error))
    return
  }
  logger.warn('dsh-auth-gate: 密码文件中没有任何账号，已自动创建初始账号 %s（默认密码 %s）。默认凭据是公开值，首次登录必须修改账号名与密码后才能进入系统。', config.defaultAdminUser, config.defaultPassword)
}

/** Count non-comment `user:hash` lines; a missing file counts as zero. */
function countValidAccounts(passwdPath: string): number {
  let content: string
  try {
    content = readFileSync(passwdPath, 'utf-8')
  } catch {
    return 0
  }
  let count = 0
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim()
    if (line.length === 0 || line.startsWith('#')) continue
    if (line.indexOf(':') !== -1) count += 1
  }
  return count
}

/** Thrown when a request body exceeds the configured byte limit. */
class BodyTooLargeError extends Error {}

/** Thrown when a body-carrying request is not application/json. */
class InvalidContentTypeError extends Error {}

function parseBody(req: IncomingMessage, limitBytes = REQUEST_BODY_LIMIT_BYTES): Promise<Record<string, unknown>> {
  return new Promise((resolve, reject) => {
    // Reject non-JSON bodies up front: the endpoints only ever consume JSON,
    // and requiring the explicit content-type keeps cross-origin HTML form
    // posts (which cannot set application/json) from reaching the parser.
    const contentType = (req.headers['content-type'] ?? '').split(';')[0].trim().toLowerCase()
    if (contentType !== 'application/json') {
      reject(new InvalidContentTypeError('expected application/json'))
      req.resume() // drain so the connection can be reused
      return
    }
    let data = ''
    let bytes = 0
    let tooLarge = false
    req.on('data', (chunk: Buffer) => {
      if (tooLarge) return // drain the rest of the body, it is already rejected
      bytes += chunk.length // Buffer#length is the byte count, unlike string#length
      if (bytes > limitBytes) {
        tooLarge = true
        reject(new BodyTooLargeError('request body too large'))
        req.resume() // keep consuming so the connection can be reused
        return
      }
      data += chunk.toString('utf-8')
    })
    req.on('end', () => {
      if (tooLarge) return
      try {
        resolve(data.length === 0 ? {} : JSON.parse(data))
      } catch {
        resolve({})
      }
    })
    req.on('error', reject)
  })
}

function getClientIp(req: IncomingMessage, trustProxy: boolean): string {
  if (trustProxy) {
    // Only trust the header when the DIRECT peer is the loopback address.
    // DSH intentionally binds 127.0.0.1 only, so any reverse proxy must live
    // on the same host — a remote client can never be the direct peer, which
    // makes the forwarded header impossible to forge from outside.
    const peer = req.socket.remoteAddress ?? ''
    if (isLoopback(peer)) {
      const forwarded = req.headers['x-forwarded-for']
      if (typeof forwarded === 'string' && forwarded.length > 0) {
        // Take the LAST entry: the documented Nginx setup appends the real
        // $remote_addr via $proxy_add_x_forwarded_for, while earlier entries
        // may have been supplied by the client itself.
        const parts = forwarded.split(',')
        const last = parts[parts.length - 1].trim()
        if (last.length > 0) return last
      }
    }
  }
  return req.socket.remoteAddress ?? '0.0.0.0'
}

function isLoopback(addr: string): boolean {
  return addr === '127.0.0.1' || addr === '::1' || addr === '::ffff:127.0.0.1'
}

function expandHome(p: string): string {
  if (p === '~') return homedir()
  if (p.startsWith('~/') || p.startsWith('~\\')) return path.join(homedir(), p.slice(2))
  return p
}

function sweep(config: Config): void {
  const now = Date.now()
  for (const [token, session] of sessions) if (session.expires < now) sessions.delete(token)
  for (const [uuid, captcha] of captchaStore) if (captcha.expires < now) captchaStore.delete(uuid)
  for (const [ip, failure] of failureStore) {
    if (failure.blockedUntil !== 0) {
      // Lock expired — drop the record so the next failure starts a fresh window.
      if (failure.blockedUntil < now) failureStore.delete(ip)
    } else if (now - failure.lastAttempt > config.blockDuration * 1000) {
      // Never reached the lock threshold and idle past the window: a stale
      // counter must not accumulate forever (bounded memory, honest "consecutive").
      failureStore.delete(ip)
    }
  }
  for (const [ip, window] of captchaFetchStore) {
    if (now - window.windowStart > CAPTCHA_FETCH_WINDOW_MS) captchaFetchStore.delete(ip)
  }
  for (const [user, record] of accountFailureStore) {
    if (record.blockedUntil !== 0) {
      if (record.blockedUntil < now) accountFailureStore.delete(user)
    } else if (now - record.lastAttempt > config.blockDuration * 1000) {
      accountFailureStore.delete(user)
    }
  }
}

function json(res: ServerResponse, status: number, data: unknown): void {
  const body = JSON.stringify(data)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
  })
  res.end(body)
}