// Minimal ambient types for the CJS svg-captcha package (no @types on npm).
declare module 'svg-captcha' {
  interface CaptchaOptions {
    size?: number
    ignoreChars?: string
    noise?: number
    color?: boolean
    background?: string
    width?: number
    height?: number
    fontSize?: number
    charPreset?: string
  }
  interface CaptchaResult {
    /** SVG markup string */
    data: string
    /** The captcha text the image encodes */
    text: string
  }
  const svgCaptcha: {
    create(options?: CaptchaOptions): CaptchaResult
    randomText(size?: number): string
    mathExpr(size?: number): CaptchaResult
  }
  export default svgCaptcha
}
