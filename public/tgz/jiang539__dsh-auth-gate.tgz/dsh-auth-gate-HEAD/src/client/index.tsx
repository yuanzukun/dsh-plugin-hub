// dsh-auth-gate client half: the login gate rendered in front of the DSH
// shell. The client-modules node half serves this bundle at
// /plugins/dsh-auth-gate/client.js and lists it in window.__DSH_BOOT__ as soon
// as the host entry (same package) is active in the composition.
//
// Gating model: the shell renders the root slot winner. The layout plugin
// registers into 'root' at priority 0; this gate registers at priority -1 and
// therefore wins while it is mounted. While the session token is missing or
// invalid we mount the gate (the whole UI is shadowed by the login page); on a
// successful login we dispose the registration and the shell re-renders onto
// the layout without a page reload.
//
// While authenticated the plugin registers 「个人配置」 into the shell's
// settings panel (settings.section list slot, above General): account
// self-service for rename / password / logout, styled with the shell's
// --dsw-* design tokens so it follows the active theme.
import { useCallback, useEffect, useState } from 'react'
import type { FormEvent } from 'react'
import type { AuthError, CaptchaResponse, ChangePasswordRequest, LoginRequest, LoginResponse, PasswordChangeResponse, UsernameChangeRequest, UsernameChangeResponse, SecurityStatus, SecurityUpdateRequest } from '../shared/types.js'
import { AUTH_TOKEN_KEY, AUTH_REMEMBER_USERNAME_KEY, AUTH_USER_KEY } from '../shared/types.js'
import loginCss from './login.css'

export const name = 'dsh-auth-gate-client'
export const inject = ['slots']

// Minimal structural typing of the client context: only the seams this plugin
// uses (slots registration + effect scoping). No runtime dependency on the
// client-runtime package is introduced.
interface SlotsRegisterOptions {
  name: string
  /** Required by list slots (e.g. settings.section): the entry's cell key. */
  id?: string
  priority?: number
  /** List-slot ordering among entries, ascending (default 0). */
  order?: number
  /** List-slot display text where the owner projects one. */
  label?: string | (() => string)
  locale?: string
  inject?: () => Record<string, unknown>
}
interface ClientCtx {
  effect(fn: () => (() => void) | void, label?: string): () => void
  slots: {
    register(options: SlotsRegisterOptions, component: (props: { onAuthenticated: () => void }) => JSX.Element): () => void
    /** Run the callback once a slot is declared; dispose when it collapses. */
    inject(key: string, callback: () => (() => void) | void): () => void
  }
}

const VERIFY_TIMEOUT_MS = 5000
const CSS_TAG = 'dsh-auth-gate/login.css'

/**
 * Boot the gate. Returning the promise keeps the shell on its loading page
 * until the token verdict lands, so the real UI never flashes before the gate.
 */
export async function apply(ctx: ClientCtx): Promise<void> {
  injectLoginStyles()

  const token = localStorage.getItem(AUTH_TOKEN_KEY)
  if (token === null) {
    mountGate(ctx)
    return
  }

  const verdict = await verifyToken(token)
  if (verdict.status === 'invalid') {
    localStorage.removeItem(AUTH_TOKEN_KEY)
    localStorage.removeItem(AUTH_USER_KEY)
    mountGate(ctx)
    return
  }
  // 'ok' → normal path; also refresh the cached username from X-Auth-User so
  // the personal config section shows the authoritative name (it may have
  // been renamed in another session). 'network' → we could not reach the
  // server (transient outage, restart window): keep the token and proceed
  // optimistically instead of logging the user out over one flaky request —
  // the Nginx auth_request layer still guards every real API call.
  if (verdict.status === 'ok' && verdict.username !== undefined) {
    localStorage.setItem(AUTH_USER_KEY, verdict.username)
  }
  // The account still carries a forced-change flag (default password and/or
  // reserved default name): re-enter the forced-change screens (survives a
  // page reload — see x-auth-must-change / x-auth-must-change-name).
  if (verdict.status === 'ok' && (verdict.mustChange === true || verdict.mustChangeName === true)) {
    mountGate(ctx, { forceChangePassword: verdict.mustChange === true, forceChangeUsername: verdict.mustChangeName === true })
    return
  }
  mountPersonalConfigSection(ctx)
}

/**
 * @returns 'ok' + username + mustChange/mustChangeName, 'invalid', or
 * 'network' (fetch threw or timed out). mustChange is true while the account
 * still uses the default password; mustChangeName while it still carries the
 * reserved default name (surfaced as x-auth-must-change / x-auth-must-change-name).
 */
async function verifyToken(token: string): Promise<{ status: 'ok' | 'invalid' | 'network'; username?: string; mustChange?: boolean; mustChangeName?: boolean }> {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), VERIFY_TIMEOUT_MS)
  try {
    const res = await fetch('/auth/verify', {
      headers: { authorization: 'Bearer ' + token },
      signal: ctrl.signal,
    })
    if (!res.ok) return { status: 'invalid' }
    const username = res.headers.get('x-auth-user')
    const mustChange = res.headers.get('x-auth-must-change') === '1'
    const mustChangeName = res.headers.get('x-auth-must-change-name') === '1'
    return { status: 'ok', username: username ?? undefined, mustChange, mustChangeName }
  } catch {
    return { status: 'network' }
  } finally {
    clearTimeout(timer)
  }
}

/**
 * While authenticated, register 「个人配置」 as a settings panel section
 * (declared by ui-settings-general via its sidebar.settings occupant, so it
 * only appears once the real UI — and with it the sidebar settings trigger —
 * is up, exactly the logged-in state).
 *
 * settings.section is a LIST slot: the entry needs a unique options.id (the
 * nav key). order -10 places it ABOVE 通用设置 (order 0) in the settings nav,
 * which sorts ascending; the label is the registrant-owned nav text.
 */
function mountPersonalConfigSection(ctx: ClientCtx): void {
  ctx.slots.inject('settings.section', () =>
    ctx.slots.register(
      { name: 'settings.section', id: 'personal', order: -10, label: () => '个人配置' },
      PersonalConfigSection,
    ),
  )
}

/**
 * Register the login page as the root slot winner (priority -1 < layout's 0).
 * opts.forceChangePassword / forceChangeUsername start the gate directly on
 * the corresponding forced-change screens (used when a valid session still
 * sits on the default credentials — e.g. after a page reload), with
 * initialOldPassword prefilled from the login form when known.
 */
function mountGate(ctx: ClientCtx, opts: { forceChangePassword?: boolean; forceChangeUsername?: boolean; initialOldPassword?: string } = {}): void {
  const gate = ctx.slots.register({
    name: 'root',
    priority: -1,
    inject: () => ({
      onAuthenticated: () => {
        // Drop the registration: the root outlet re-renders onto the layout.
        gate()
        // Now that the real UI is up, mount the personal config settings
        // section. Without this the section only appeared after a page
        // reload following a fresh login.
        mountPersonalConfigSection(ctx)
      },
    }),
  }, (props) => (<LoginPage {...props} forceChangePassword={opts.forceChangePassword ?? false} forceChangeUsername={opts.forceChangeUsername ?? false} initialOldPassword={opts.initialOldPassword ?? ''} />))
}

// ── login page ──────────────────────────────────────────────────────────────

function LoginPage({ onAuthenticated, forceChangePassword = false, forceChangeUsername = false, initialOldPassword = '' }: {
  onAuthenticated: () => void
  /** Start on the forced password-change screen (valid session still on the default password). */
  forceChangePassword?: boolean
  /** Start on the forced rename screen (valid session still on the reserved default name). */
  forceChangeUsername?: boolean
  /** Password used to log in; prefilled as the old password of the forced change. */
  initialOldPassword?: string
}): JSX.Element {
  // 「记住用户名」: the username field starts from the remembered value when
  // the user opted in before; the remember checkbox mirrors key presence so
  // unchecking clears the stored name (privacy) and unchecks on the next visit.
  const [username, setUsername] = useState(() => localStorage.getItem(AUTH_REMEMBER_USERNAME_KEY) ?? '')
  // A stored empty string counts as "not remembered": the key only carries a
  // real name, so the box starts unchecked unless a name is actually stored.
  const [rememberUsername, setRememberUsername] = useState(() => {
    const remembered = localStorage.getItem(AUTH_REMEMBER_USERNAME_KEY)
    return remembered !== null && remembered.length > 0
  })
  const [password, setPassword] = useState('')
  const [captcha, setCaptcha] = useState('')
  const [captchaSvg, setCaptchaSvg] = useState('')
  const [captchaUuid, setCaptchaUuid] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  // Forced-change state: armed by a login response carrying mustChangePassword
  // / mustChangeUsername (or pre-set by mountGate after a reload verdict),
  // cleared per section as each completes; the gate releases once none remain.
  const [mustChangePw, setMustChangePw] = useState(forceChangePassword)
  const [mustChangeName, setMustChangeName] = useState(forceChangeUsername)
  const [changeOldPassword, setChangeOldPassword] = useState(initialOldPassword)

  const refreshCaptcha = useCallback(async () => {
    try {
      const res = await fetch('/auth/captcha')
      const data = (await res.json()) as CaptchaResponse
      setCaptchaSvg(data.svg)
      setCaptchaUuid(data.uuid)
      setCaptcha('')
    } catch {
      setError('获取验证码失败，请重试')
    }
  }, [])

  useEffect(() => {
    void refreshCaptcha()
  }, [refreshCaptcha])

  const handleSubmit = useCallback(async (e: FormEvent) => {
    e.preventDefault()
    if (loading) return
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/auth/login', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ username, password, captcha, uuid: captchaUuid } satisfies LoginRequest),
      })
      const data = (await res.json()) as LoginResponse | AuthError
      if (res.ok && 'token' in data) {
        localStorage.setItem(AUTH_TOKEN_KEY, data.token)
        localStorage.setItem(AUTH_USER_KEY, data.username)
        if (rememberUsername) localStorage.setItem(AUTH_REMEMBER_USERNAME_KEY, data.username)
        if (data.kickedPrevious === true) {
          // Single-session policy: an older session of this account was
          // signed out by this login; it is kicked at its next verify.
          console.info('[dsh-auth-gate] previous session of this account was signed out by this login (single-session policy)')
        }
        if (data.mustChangePassword === true || data.mustChangeUsername === true) {
          // First login on the default credentials: hold the gate on the
          // forced-change screens (rename + password) instead of releasing
          // the UI. The password just used becomes the old password of the
          // password change.
          setChangeOldPassword(password)
          setMustChangePw(data.mustChangePassword === true)
          setMustChangeName(data.mustChangeUsername === true)
          return
        }
        onAuthenticated()
      } else {
        setError((data as AuthError).error ?? '登录失败')
        void refreshCaptcha()
      }
    } catch {
      setError('网络错误，请重试')
    } finally {
      setLoading(false)
    }
  }, [loading, username, password, captcha, captchaUuid, rememberUsername, onAuthenticated, refreshCaptcha])

  const handleForceLogout = useCallback(() => {
    // Leave the forced-change screen without changing the password: sign out
    // locally (the server-side session expires on its own timeout).
    localStorage.removeItem(AUTH_TOKEN_KEY)
    localStorage.removeItem(AUTH_USER_KEY)
    window.location.reload()
  }, [])

  return (
    <div className="dsh-auth-gate">
      {(mustChangePw || mustChangeName) ? (
        <ForceChangeForm forceName={mustChangeName} forcePassword={mustChangePw} initialOldPassword={changeOldPassword} onDone={onAuthenticated} onLogout={handleForceLogout} />
      ) : (
      <form className="dsh-auth-gate__card" onSubmit={handleSubmit}>
        <div className="dsh-auth-gate__brand">
          <span className="dsh-auth-gate__brand-mark">🔐</span>
          DSH 安全登录
        </div>
        <p className="dsh-auth-gate__subtitle">登录以继续使用 DeepSeek Harness</p>

        {error.length > 0 && <p className="dsh-auth-gate__error" role="alert">{error}</p>}

        <div className="dsh-auth-gate__field">
          <label className="dsh-auth-gate__label" htmlFor="auth-username">用户名</label>
          <input
            id="auth-username"
            className="dsh-auth-gate__input"
            type="text"
            autoComplete="username"
            autoCapitalize="none"
            spellCheck={false}
            enterKeyHint="next"
            placeholder="用户名"
            value={username}
            onChange={(e) => {
              const value = e.target.value
              setUsername(value)
              // With 「记住用户名」 on, persist on every keystroke so the name
              // survives even a closed tab before the form is submitted. An
              // empty field has nothing to remember: drop the stored name so
              // the box never shows checked with no name on the next visit.
              if (rememberUsername) {
                if (value.length > 0) localStorage.setItem(AUTH_REMEMBER_USERNAME_KEY, value)
                else localStorage.removeItem(AUTH_REMEMBER_USERNAME_KEY)
              }
            }}
            disabled={loading}
            autoFocus
          />
        </div>

        <div className="dsh-auth-gate__field">
          <label className="dsh-auth-gate__label" htmlFor="auth-password">密码</label>
          <input
            id="auth-password"
            className="dsh-auth-gate__input"
            type="password"
            autoComplete="current-password"
            enterKeyHint="done"
            placeholder="密码"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            disabled={loading}
          />
        </div>

        <div className="dsh-auth-gate__field">
          <label className="dsh-auth-gate__label" htmlFor="auth-captcha">验证码</label>
          <div className="dsh-auth-gate__captcha-row">
            <input
              id="auth-captcha"
              className="dsh-auth-gate__input"
              type="text"
              autoComplete="off"
              autoCapitalize="none"
              spellCheck={false}
              enterKeyHint="done"
              placeholder="验证码"
              value={captcha}
              onChange={(e) => setCaptcha(e.target.value)}
              disabled={loading}
            />
            <div
              className="dsh-auth-gate__captcha-image"
              title="点击刷新验证码"
              onClick={() => void refreshCaptcha()}
              // The captcha SVG is generated server-side and contains no scripts.
              dangerouslySetInnerHTML={{ __html: captchaSvg }}
            />
          </div>
          <div className="dsh-auth-gate__captcha-hint">看不清？点击图片刷新</div>
        </div>

        {/* 「记住用户名」 — the whole row is a <label> so clicking the box, the
            text, or anywhere on the row toggles the (visually hidden) checkbox. */}
        <label className="dsh-auth-gate__remember">
          <input
            id="auth-remember-username"
            className="dsh-auth-gate__remember-input"
            type="checkbox"
            checked={rememberUsername}
            onChange={(e) => {
              const checked = e.target.checked
              setRememberUsername(checked)
              if (checked) {
                // Remember the name currently in the field (even before submit);
                // an empty field has nothing to remember, so skip persisting.
                if (username.length > 0) localStorage.setItem(AUTH_REMEMBER_USERNAME_KEY, username)
              } else {
                // Opting out clears the stored name — nothing lingers.
                localStorage.removeItem(AUTH_REMEMBER_USERNAME_KEY)
              }
            }}
            disabled={loading}
          />
          <span className="dsh-auth-gate__remember-box" aria-hidden="true" />
          <span className="dsh-auth-gate__remember-label">记住用户名</span>
        </label>

        <button className="dsh-auth-gate__submit" type="submit" disabled={loading}>
          {loading ? '登录中…' : '登 录'}
        </button>

        <div className="dsh-auth-gate__footer">DeepSeek Harness · dsh-auth-gate</div>
        <p className="dsh-auth-gate__default-hint">初始安装：默认账号与默认密码见安装文档（README），首次登录必须修改账号名与密码后才能进入系统。</p>
      </form>
      )}
    </div>
  )
}

// ── forced change on first login (default credentials) ─────────────────────

/**
 * Shown instead of the login form while the account still carries default
 * credentials: the session is valid (token stored) but the UI must not
 * release until the account is renamed away from the reserved default name
 * AND the default password is changed. Sections render independently per the
 * flags; the pending actions run in order (rename first, then password) and
 * each marks its section done on success, so a partial failure leaves the
 * completed part finished on the next submit. Reuses POST /auth/username and
 * POST /auth/password — the old password is the default one just used to log
 * in (prefilled when known).
 */
function ForceChangeForm({ forceName, forcePassword, initialOldPassword, onDone, onLogout }: {
  forceName: boolean
  forcePassword: boolean
  initialOldPassword: string
  onDone: () => void
  onLogout: () => void
}): JSX.Element {
  const [mustChangeName, setMustChangeName] = useState(forceName)
  const [mustChangePw, setMustChangePw] = useState(forcePassword)
  const [newUsername, setNewUsername] = useState('')
  const [oldPassword, setOldPassword] = useState(initialOldPassword)
  const [newPassword, setNewPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = useCallback(async (e: FormEvent) => {
    e.preventDefault()
    if (loading) return
    if (mustChangeName) {
      const name = newUsername.trim()
      if (name.length < 1 || name.length > 32) {
        setError('新账号名长度需为 1-32 个字符')
        return
      }
      if (/[\s:]/.test(name)) {
        setError('新账号名不能包含空格或冒号')
        return
      }
    }
    if (mustChangePw && newPassword !== confirm) {
      setError('两次输入的新密码不一致')
      return
    }
    setLoading(true)
    setError('')
    const token = localStorage.getItem(AUTH_TOKEN_KEY)
    try {
      // 1. rename away from the reserved default name
      if (mustChangeName) {
        const rn = await fetch('/auth/username', {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            authorization: 'Bearer ' + (token ?? ''),
          },
          body: JSON.stringify({ newUsername: newUsername.trim() } satisfies UsernameChangeRequest),
        })
        const rnData = (await rn.json()) as UsernameChangeResponse | AuthError
        if (rn.status === 401) {
          // Session expired mid-change: drop the token and let the gate take over.
          localStorage.removeItem(AUTH_TOKEN_KEY)
          localStorage.removeItem(AUTH_USER_KEY)
          window.location.reload()
          return
        }
        if (!rn.ok || !('username' in rnData)) {
          setError((rnData as AuthError).error ?? '账号名修改失败，请重试')
          return
        }
        localStorage.setItem(AUTH_USER_KEY, rnData.username)
        setMustChangeName(false)
      }
      // 2. replace the default password
      if (mustChangePw) {
        const cp = await fetch('/auth/password', {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            authorization: 'Bearer ' + (token ?? ''),
          },
          body: JSON.stringify({ oldPassword, newPassword } satisfies ChangePasswordRequest),
        })
        const cpData = (await cp.json()) as PasswordChangeResponse | AuthError
        if (cp.status === 401) {
          // Session expired mid-change: drop the token and let the gate take over.
          localStorage.removeItem(AUTH_TOKEN_KEY)
          localStorage.removeItem(AUTH_USER_KEY)
          window.location.reload()
          return
        }
        if (!cp.ok) {
          setError((cpData as AuthError).error ?? '密码修改失败，请重试')
          return
        }
        setMustChangePw(false)
      }
      // Every pending action completed: the server cleared the forced-change
      // flags on this session, so the gate can release straight into the shell.
      onDone()
    } catch {
      setError('网络错误，请重试')
    } finally {
      setLoading(false)
    }
  }, [loading, mustChangeName, mustChangePw, newUsername, oldPassword, newPassword, confirm, onDone])

  const title = mustChangeName && mustChangePw ? '首次登录安全设置'
    : mustChangeName ? '首次登录：请修改账号名'
    : '首次登录：请修改密码'
  const subtitle = mustChangeName && mustChangePw
    ? '当前账号仍在使用公开的默认账号名与默认密码，必须先修改两者才能进入系统。'
    : mustChangeName
    ? '当前账号仍在使用保留的默认账号名，必须修改后才能进入系统。'
    : '当前账号仍在使用默认密码，必须先设置新密码才能进入系统。'

  return (
    <form className="dsh-auth-gate__card" onSubmit={handleSubmit}>
      <div className="dsh-auth-gate__brand">
        <span className="dsh-auth-gate__brand-mark">🔐</span>
        {title}
      </div>
      <p className="dsh-auth-gate__subtitle">{subtitle}</p>

      {error.length > 0 && <p className="dsh-auth-gate__error" role="alert">{error}</p>}

      {mustChangeName && (
        <div className="dsh-auth-gate__field">
          <label className="dsh-auth-gate__label" htmlFor="force-new-username">新账号名（1-32 个字符，不含空格和冒号；不能使用保留名）</label>
          <input
            id="force-new-username"
            className="dsh-auth-gate__input"
            type="text"
            autoComplete="username"
            autoCapitalize="none"
            spellCheck={false}
            enterKeyHint="next"
            placeholder="新账号名"
            value={newUsername}
            onChange={(e) => setNewUsername(e.target.value)}
            disabled={loading}
            autoFocus
          />
        </div>
      )}

      {mustChangePw && (
        <div className="dsh-auth-gate__field">
          <label className="dsh-auth-gate__label" htmlFor="force-old-password">旧密码（默认密码）</label>
          <input
            id="force-old-password"
            className="dsh-auth-gate__input"
            type="password"
            autoComplete="current-password"
            enterKeyHint="next"
            placeholder="默认密码"
            value={oldPassword}
            onChange={(e) => setOldPassword(e.target.value)}
            disabled={loading}
          />
        </div>
      )}

      {mustChangePw && (
        <div className="dsh-auth-gate__field">
          <label className="dsh-auth-gate__label" htmlFor="force-new-password">新密码（至少 8 个字符）</label>
          <input
            id="force-new-password"
            className="dsh-auth-gate__input"
            type="password"
            autoComplete="new-password"
            enterKeyHint="next"
            placeholder="新密码"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            disabled={loading}
          />
        </div>
      )}

      {mustChangePw && (
        <div className="dsh-auth-gate__field">
          <label className="dsh-auth-gate__label" htmlFor="force-confirm-password">确认新密码</label>
          <input
            id="force-confirm-password"
            className="dsh-auth-gate__input"
            type="password"
            autoComplete="new-password"
            enterKeyHint="done"
            placeholder="再次输入新密码"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            disabled={loading}
          />
        </div>
      )}

      <button className="dsh-auth-gate__submit" type="submit" disabled={loading}>
        {loading ? '保存中…' : '保存并进入'}
      </button>

      <div className="dsh-auth-gate__force-actions">
        <button type="button" className="dsh-auth-gate__force-logout" onClick={onLogout} disabled={loading}>
          退出登录
        </button>
      </div>

      <div className="dsh-auth-gate__footer">DeepSeek Harness · dsh-auth-gate</div>
    </form>
  )
}

/** Inject the stylesheet once per page load (mirrors the shipped client bundles). */
function injectLoginStyles(): void {
  if (typeof document === 'undefined') return
  if (document.querySelector('style[data-plugin-css=' + JSON.stringify(CSS_TAG) + ']') !== null) return
  const tag = document.createElement('style')
  tag.dataset.plugin = 'dsh-auth-gate'
  tag.dataset.pluginCss = CSS_TAG
  tag.textContent = loginCss
  document.head.appendChild(tag)
}

// ── personal config settings section (个人配置) ──────────────────────────────

/**
 * 「个人配置」settings section: account self-service rendered inside the DSH
 * settings panel (above 通用设置). Three stacked cards — 修改用户名 /
 * 修改密码 / 退出登录 — styled with the shell's --dsw-* tokens so the page
 * follows the active light/dark theme. No avatar: the account identity is a
 * plain text row in the section header.
 */
function PersonalConfigSection(): JSX.Element {
  const [username, setUsername] = useState(() => localStorage.getItem(AUTH_USER_KEY) ?? '')

  // rename
  const [newName, setNewName] = useState('')
  const [renaming, setRenaming] = useState(false)
  const [renameError, setRenameError] = useState('')
  const [renameNotice, setRenameNotice] = useState('')

  // password
  const [oldPassword, setOldPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [pwLoading, setPwLoading] = useState(false)
  const [pwError, setPwError] = useState('')
  const [pwNotice, setPwNotice] = useState('')

  // logout (two-step confirm: click once to arm, again to execute)
  const [confirmingLogout, setConfirmingLogout] = useState(false)
  const [loggingOut, setLoggingOut] = useState(false)

  const handleRename = useCallback(async () => {
    if (renaming) return
    const name = newName.trim()
    if (name.length < 1 || name.length > 32) {
      setRenameError('用户名长度需为 1-32 个字符')
      return
    }
    if (/[\s:]/.test(name)) {
      setRenameError('用户名不能包含空格或冒号')
      return
    }
    setRenaming(true)
    setRenameError('')
    setRenameNotice('')
    try {
      const token = localStorage.getItem(AUTH_TOKEN_KEY)
      const res = await fetch('/auth/username', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: 'Bearer ' + (token ?? ''),
        },
        body: JSON.stringify({ newUsername: name } satisfies UsernameChangeRequest),
      })
      const data = (await res.json()) as UsernameChangeResponse | AuthError
      if (res.ok && 'username' in data) {
        localStorage.setItem(AUTH_USER_KEY, data.username)
        setUsername(data.username)
        setNewName('')
        setRenameNotice('用户名已修改为「' + data.username + '」，请使用新名称登录')
      } else if (res.status === 401) {
        // Session expired mid-use: drop the token and let the gate take over.
        localStorage.removeItem(AUTH_TOKEN_KEY)
        localStorage.removeItem(AUTH_USER_KEY)
        window.location.reload()
      } else {
        setRenameError((data as AuthError).error ?? '修改失败，请重试')
      }
    } catch {
      setRenameError('网络错误，请重试')
    } finally {
      setRenaming(false)
    }
  }, [renaming, newName])

  const handlePassword = useCallback(async () => {
    if (pwLoading) return
    if (newPassword !== confirm) {
      setPwError('两次输入的新密码不一致')
      return
    }
    setPwLoading(true)
    setPwError('')
    setPwNotice('')
    try {
      const token = localStorage.getItem(AUTH_TOKEN_KEY)
      const res = await fetch('/auth/password', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: 'Bearer ' + (token ?? ''),
        },
        body: JSON.stringify({ oldPassword, newPassword } satisfies ChangePasswordRequest),
      })
      const data = (await res.json()) as PasswordChangeResponse | AuthError
      if (res.ok) {
        setPwNotice('密码已修改，其他登录会话已失效')
        setOldPassword('')
        setNewPassword('')
        setConfirm('')
      } else if (res.status === 401) {
        // Session expired mid-use: drop the token and let the gate take over.
        localStorage.removeItem(AUTH_TOKEN_KEY)
        localStorage.removeItem(AUTH_USER_KEY)
        window.location.reload()
      } else {
        setPwError((data as AuthError).error ?? '修改失败，请重试')
      }
    } catch {
      setPwError('网络错误，请重试')
    } finally {
      setPwLoading(false)
    }
  }, [pwLoading, oldPassword, newPassword, confirm])

  const handleLogout = useCallback(async () => {
    if (loggingOut) return
    if (!confirmingLogout) {
      setConfirmingLogout(true)
      return
    }
    setLoggingOut(true)
    // Best-effort server-side session destruction; local sign-out always
    // proceeds even if the request fails (offline, already expired).
    try {
      const token = localStorage.getItem(AUTH_TOKEN_KEY)
      await fetch('/auth/logout', {
        method: 'POST',
        headers: { authorization: 'Bearer ' + (token ?? '') },
      })
    } catch {
      // ignore — local sign-out below is the source of truth
    }
    localStorage.removeItem(AUTH_TOKEN_KEY)
    localStorage.removeItem(AUTH_USER_KEY)
    window.location.reload()
  }, [confirmingLogout, loggingOut])

  return (
    <div className="dsh-auth-gate__personal">
      <header className="dsh-auth-gate__personal-header">
        <div className="dsh-auth-gate__personal-title">个人配置</div>
        <p className="dsh-auth-gate__personal-account">当前账号名称：{username.length > 0 ? username : '未知用户'}</p>
      </header>

      <section className="dsh-auth-gate__personal-card">
        <h3 className="dsh-auth-gate__personal-card-title">修改用户名</h3>
        {renameError.length > 0 && (
          <p className="dsh-auth-gate__personal-message dsh-auth-gate__personal-message--error" role="alert">{renameError}</p>
        )}
        {renameNotice.length > 0 && (
          <p className="dsh-auth-gate__personal-message dsh-auth-gate__personal-message--success" role="status">{renameNotice}</p>
        )}
        <div className="dsh-auth-gate__personal-field">
          <label className="dsh-auth-gate__personal-label" htmlFor="auth-settings-new-name">新用户名（1-32 个字符，不含空格和冒号）</label>
          <input
            id="auth-settings-new-name"
            className="dsh-auth-gate__personal-input"
            type="text"
            autoComplete="username"
            autoCapitalize="none"
            spellCheck={false}
            placeholder="新用户名"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            disabled={renaming}
          />
        </div>
        <div className="dsh-auth-gate__personal-actions">
          <button
            type="button"
            className="dsh-auth-gate__personal-btn dsh-auth-gate__personal-btn--primary"
            onClick={() => void handleRename()}
            disabled={renaming}
          >
            {renaming ? '保存中…' : '保存'}
          </button>
        </div>
      </section>

      <section className="dsh-auth-gate__personal-card">
        <h3 className="dsh-auth-gate__personal-card-title">修改密码</h3>
        {pwError.length > 0 && (
          <p className="dsh-auth-gate__personal-message dsh-auth-gate__personal-message--error" role="alert">{pwError}</p>
        )}
        {pwNotice.length > 0 && (
          <p className="dsh-auth-gate__personal-message dsh-auth-gate__personal-message--success" role="status">{pwNotice}</p>
        )}
        <div className="dsh-auth-gate__personal-field">
          <label className="dsh-auth-gate__personal-label" htmlFor="auth-settings-old-password">旧密码</label>
          <input
            id="auth-settings-old-password"
            className="dsh-auth-gate__personal-input"
            type="password"
            autoComplete="current-password"
            value={oldPassword}
            onChange={(e) => setOldPassword(e.target.value)}
            disabled={pwLoading}
          />
        </div>
        <div className="dsh-auth-gate__personal-field">
          <label className="dsh-auth-gate__personal-label" htmlFor="auth-settings-new-password">新密码（至少 8 个字符）</label>
          <input
            id="auth-settings-new-password"
            className="dsh-auth-gate__personal-input"
            type="password"
            autoComplete="new-password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            disabled={pwLoading}
          />
        </div>
        <div className="dsh-auth-gate__personal-field">
          <label className="dsh-auth-gate__personal-label" htmlFor="auth-settings-confirm-password">确认新密码</label>
          <input
            id="auth-settings-confirm-password"
            className="dsh-auth-gate__personal-input"
            type="password"
            autoComplete="new-password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            disabled={pwLoading}
          />
        </div>
        <div className="dsh-auth-gate__personal-actions">
          <button
            type="button"
            className="dsh-auth-gate__personal-btn dsh-auth-gate__personal-btn--primary"
            onClick={() => void handlePassword()}
            disabled={pwLoading}
          >
            {pwLoading ? '保存中…' : '保存'}
          </button>
        </div>
      </section>

      <SecuritySettingsCard />

      <section className="dsh-auth-gate__personal-card dsh-auth-gate__personal-card--danger">
        <h3 className="dsh-auth-gate__personal-card-title">退出登录</h3>
        <p className="dsh-auth-gate__personal-hint">退出登录不会中断正在执行的任务（子代理、后台作业等会继续运行）；重新登录后即可继续使用 DSH。</p>
        <div className="dsh-auth-gate__personal-actions">
          <button
            type="button"
            className={
              'dsh-auth-gate__personal-btn dsh-auth-gate__personal-btn--danger' +
              (confirmingLogout ? ' is-confirming' : '')
            }
            onClick={() => void handleLogout()}
            disabled={loggingOut}
          >
            {loggingOut ? '退出中…' : confirmingLogout ? '确认退出' : '退出登录'}
          </button>
        </div>
      </section>
    </div>
  )
}
// ── security settings card (安全设置) ────────────────────────────────────────

/** Client-side mirror of the host's safe bounds; the server re-validates. */
const SECURITY_BOUNDS = {
  sessionTimeout: { min: 60, max: 86400 },
  captchaExpires: { min: 30, max: 3600 },
  maxLoginAttempts: { min: 1, max: 100 },
  blockDuration: { min: 30, max: 86400 },
} as const

/**
 * 「安全设置」card inside 个人配置: status overview of every security measure
 * plus the runtime-managed parameters (session / captcha / brute-force /
 * trust-proxy). Changes go through POST /auth/security, take effect on the
 * running server immediately and survive restarts (override file stored next
 * to the password file).
 */
function SecuritySettingsCard(): JSX.Element {
  const [status, setStatus] = useState<SecurityStatus | null>(null)
  const [loadError, setLoadError] = useState('')
  const [sessionTimeout, setSessionTimeout] = useState('')
  const [captchaExpires, setCaptchaExpires] = useState('')
  const [maxLoginAttempts, setMaxLoginAttempts] = useState('')
  const [blockDuration, setBlockDuration] = useState('')
  const [trustProxy, setTrustProxy] = useState(false)
  const [singleSessionPerUser, setSingleSessionPerUser] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  const loadStatus = useCallback(async () => {
    try {
      const token = localStorage.getItem(AUTH_TOKEN_KEY)
      const res = await fetch('/auth/security', { headers: { authorization: 'Bearer ' + (token ?? '') } })
      if (res.status === 401) {
        // Session expired mid-use: drop the token and let the gate take over.
        localStorage.removeItem(AUTH_TOKEN_KEY)
        localStorage.removeItem(AUTH_USER_KEY)
        window.location.reload()
        return
      }
      if (!res.ok) {
        setLoadError('无法读取安全设置（HTTP ' + res.status + '）')
        return
      }
      const data = (await res.json()) as SecurityStatus
      setStatus(data)
      setSessionTimeout(String(data.sessionTimeout))
      setCaptchaExpires(String(data.captchaExpires))
      setMaxLoginAttempts(String(data.maxLoginAttempts))
      setBlockDuration(String(data.blockDuration))
      setTrustProxy(data.trustProxy)
      setSingleSessionPerUser(data.singleSessionPerUser)
      setLoadError('')
    } catch {
      setLoadError('网络错误，无法读取安全设置')
    }
  }, [])

  useEffect(() => {
    void loadStatus()
  }, [loadStatus])

  const handleSave = useCallback(async () => {
    if (saving) return
    setSaving(true)
    setError('')
    setNotice('')
    const parseNum = (raw: string, key: keyof typeof SECURITY_BOUNDS): number | null => {
      const value = Number(raw)
      if (!Number.isFinite(value)) return null
      const bounds = SECURITY_BOUNDS[key]
      const clamped = Math.round(value)
      return clamped >= bounds.min && clamped <= bounds.max ? clamped : null
    }
    const s = parseNum(sessionTimeout, 'sessionTimeout')
    const c = parseNum(captchaExpires, 'captchaExpires')
    const a = parseNum(maxLoginAttempts, 'maxLoginAttempts')
    const b = parseNum(blockDuration, 'blockDuration')
    if (s === null || c === null || a === null || b === null) {
      setError('参数需为有效数字：会话超时 60–86400 秒、验证码有效期 30–3600 秒、失败阈值 1–100 次、锁定时长 30–86400 秒')
      setSaving(false)
      return
    }
    try {
      const token = localStorage.getItem(AUTH_TOKEN_KEY)
      const res = await fetch('/auth/security', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: 'Bearer ' + (token ?? ''),
        },
        body: JSON.stringify({
          sessionTimeout: s,
          captchaExpires: c,
          maxLoginAttempts: a,
          blockDuration: b,
          trustProxy,
          singleSessionPerUser,
        } satisfies SecurityUpdateRequest),
      })
      const data = (await res.json()) as SecurityStatus | AuthError
      if (res.ok && 'sessionTimeout' in data) {
        setStatus(data)
        setSessionTimeout(String(data.sessionTimeout))
        setCaptchaExpires(String(data.captchaExpires))
        setMaxLoginAttempts(String(data.maxLoginAttempts))
        setBlockDuration(String(data.blockDuration))
        setTrustProxy(data.trustProxy)
        setSingleSessionPerUser(data.singleSessionPerUser)
        setNotice('安全设置已保存并立即生效（重启后仍然有效）')
      } else if (res.status === 401) {
        localStorage.removeItem(AUTH_TOKEN_KEY)
        localStorage.removeItem(AUTH_USER_KEY)
        window.location.reload()
      } else {
        setError((data as AuthError).error ?? '保存失败，请重试')
      }
    } catch {
      setError('网络错误，请重试')
    } finally {
      setSaving(false)
    }
  }, [saving, sessionTimeout, captchaExpires, maxLoginAttempts, blockDuration, trustProxy, singleSessionPerUser])

  return (
    <section className="dsh-auth-gate__personal-card">
      <h3 className="dsh-auth-gate__personal-card-title">安全设置</h3>
      <p className="dsh-auth-gate__personal-hint">以下防护措施的状态与参数修改后立即生效，并保存到密码文件同目录的 auth-gate.security.json，重启后仍然有效。</p>

      {loadError.length > 0 && (
        <p className="dsh-auth-gate__personal-message dsh-auth-gate__personal-message--error" role="alert">{loadError}</p>
      )}
      {error.length > 0 && (
        <p className="dsh-auth-gate__personal-message dsh-auth-gate__personal-message--error" role="alert">{error}</p>
      )}
      {notice.length > 0 && (
        <p className="dsh-auth-gate__personal-message dsh-auth-gate__personal-message--success" role="status">{notice}</p>
      )}

      {status !== null && (
        <div className="dsh-auth-gate__personal-status">
          <div className="dsh-auth-gate__personal-measure">
            <span className="dsh-auth-gate__personal-measure-name">图形验证码</span>
            <span className="dsh-auth-gate__personal-measure-value">有效期 {status.captchaExpires} 秒</span>
            <span className="dsh-auth-gate__personal-badge dsh-auth-gate__personal-badge--on">启用</span>
          </div>
          <div className="dsh-auth-gate__personal-measure">
            <span className="dsh-auth-gate__personal-measure-name">防暴力破解（按 IP）</span>
            <span className="dsh-auth-gate__personal-measure-value">连续失败 {status.maxLoginAttempts} 次锁定 {status.blockDuration} 秒</span>
            <span className="dsh-auth-gate__personal-badge dsh-auth-gate__personal-badge--on">启用</span>
          </div>
          <div className="dsh-auth-gate__personal-measure">
            <span className="dsh-auth-gate__personal-measure-name">防暴力破解（按账号）</span>
            <span className="dsh-auth-gate__personal-measure-value">任一账号凭据连续失败 {status.accountMaxLoginAttempts} 次锁定 {status.blockDuration} 秒（防 IP 轮换）</span>
            <span className="dsh-auth-gate__personal-badge dsh-auth-gate__personal-badge--on">启用</span>
          </div>
          <div className="dsh-auth-gate__personal-measure">
            <span className="dsh-auth-gate__personal-measure-name">会话管理</span>
            <span className="dsh-auth-gate__personal-measure-value">滑动超时 {status.sessionTimeout} 秒</span>
            <span className="dsh-auth-gate__personal-badge dsh-auth-gate__personal-badge--on">启用</span>
          </div>
          <div className="dsh-auth-gate__personal-measure">
            <span className="dsh-auth-gate__personal-measure-name">单点登录</span>
            <span className="dsh-auth-gate__personal-measure-value">同一账号只允许一个登录位置，新登录会使旧会话立即失效</span>
            <span className={
              'dsh-auth-gate__personal-badge' +
              (status.singleSessionPerUser ? ' dsh-auth-gate__personal-badge--on' : ' dsh-auth-gate__personal-badge--off')
            }>{status.singleSessionPerUser ? '启用' : '未启用'}</span>
          </div>
          <div className="dsh-auth-gate__personal-measure">
            <span className="dsh-auth-gate__personal-measure-name">信任代理（X-Forwarded-For）</span>
            <span className="dsh-auth-gate__personal-measure-value">仅当直接对端为回环地址时信任，取最后一项</span>
            <span className={
              'dsh-auth-gate__personal-badge' +
              (status.trustProxy ? ' dsh-auth-gate__personal-badge--on' : ' dsh-auth-gate__personal-badge--off')
            }>{status.trustProxy ? '启用' : '未启用'}</span>
          </div>
          <div className="dsh-auth-gate__personal-measure">
            <span className="dsh-auth-gate__personal-measure-name">请求体限制</span>
            <span className="dsh-auth-gate__personal-measure-value">{Math.round(status.bodyLimitBytes / 1024)} KB（内置，不可调）</span>
            <span className="dsh-auth-gate__personal-badge dsh-auth-gate__personal-badge--on">启用</span>
          </div>
          <div className="dsh-auth-gate__personal-meta">实时状态：在线会话 {status.activeSessions} · 当前锁定 IP {status.blockedIps}</div>
        </div>
      )}

      <div className="dsh-auth-gate__personal-field dsh-auth-gate__personal-field--inline">
        <label className="dsh-auth-gate__personal-label" htmlFor="auth-settings-session-timeout">会话超时（秒，60–86400）</label>
        <input
          id="auth-settings-session-timeout"
          className="dsh-auth-gate__personal-input dsh-auth-gate__personal-input--number"
          type="number"
          min={SECURITY_BOUNDS.sessionTimeout.min}
          max={SECURITY_BOUNDS.sessionTimeout.max}
          step={1}
          value={sessionTimeout}
          onChange={(e) => setSessionTimeout(e.target.value)}
          disabled={saving}
        />
      </div>
      <div className="dsh-auth-gate__personal-field dsh-auth-gate__personal-field--inline">
        <label className="dsh-auth-gate__personal-label" htmlFor="auth-settings-captcha-expires">验证码有效期（秒，30–3600）</label>
        <input
          id="auth-settings-captcha-expires"
          className="dsh-auth-gate__personal-input dsh-auth-gate__personal-input--number"
          type="number"
          min={SECURITY_BOUNDS.captchaExpires.min}
          max={SECURITY_BOUNDS.captchaExpires.max}
          step={1}
          value={captchaExpires}
          onChange={(e) => setCaptchaExpires(e.target.value)}
          disabled={saving}
        />
      </div>
      <div className="dsh-auth-gate__personal-field dsh-auth-gate__personal-field--inline">
        <label className="dsh-auth-gate__personal-label" htmlFor="auth-settings-max-attempts">连续失败锁定阈值（次，1–100）</label>
        <input
          id="auth-settings-max-attempts"
          className="dsh-auth-gate__personal-input dsh-auth-gate__personal-input--number"
          type="number"
          min={SECURITY_BOUNDS.maxLoginAttempts.min}
          max={SECURITY_BOUNDS.maxLoginAttempts.max}
          step={1}
          value={maxLoginAttempts}
          onChange={(e) => setMaxLoginAttempts(e.target.value)}
          disabled={saving}
        />
      </div>
      <div className="dsh-auth-gate__personal-field dsh-auth-gate__personal-field--inline">
        <label className="dsh-auth-gate__personal-label" htmlFor="auth-settings-block-duration">锁定时长（秒，30–86400）</label>
        <input
          id="auth-settings-block-duration"
          className="dsh-auth-gate__personal-input dsh-auth-gate__personal-input--number"
          type="number"
          min={SECURITY_BOUNDS.blockDuration.min}
          max={SECURITY_BOUNDS.blockDuration.max}
          step={1}
          value={blockDuration}
          onChange={(e) => setBlockDuration(e.target.value)}
          disabled={saving}
        />
      </div>
      <div className="dsh-auth-gate__personal-field dsh-auth-gate__personal-field--inline dsh-auth-gate__personal-field--switch">
        <label className="dsh-auth-gate__personal-label" htmlFor="auth-settings-trust-proxy">信任 X-Forwarded-For（同机 Nginx 反代时启用）</label>
        <input
          id="auth-settings-trust-proxy"
          className="dsh-auth-gate__personal-switch"
          type="checkbox"
          checked={trustProxy}
          onChange={(e) => setTrustProxy(e.target.checked)}
          disabled={saving}
        />
      </div>
      <div className="dsh-auth-gate__personal-field dsh-auth-gate__personal-field--inline dsh-auth-gate__personal-field--switch">
        <label className="dsh-auth-gate__personal-label" htmlFor="auth-settings-single-session">单点登录（同一账号再次登录会使其他位置的会话立即下线）</label>
        <input
          id="auth-settings-single-session"
          className="dsh-auth-gate__personal-switch"
          type="checkbox"
          checked={singleSessionPerUser}
          onChange={(e) => setSingleSessionPerUser(e.target.checked)}
          disabled={saving}
        />
      </div>

      <div className="dsh-auth-gate__personal-actions">
        <button
          type="button"
          className="dsh-auth-gate__personal-btn dsh-auth-gate__personal-btn--primary"
          onClick={() => void handleSave()}
          disabled={saving || status === null}
        >
          {saving ? '保存中…' : '保存'}
        </button>
      </div>
    </section>
  )
}

