// Self-executing integration tests for the dsh-auth-gate host half.
//
// Runs without a test-runner subprocess so it works in sandboxed/restricted
// environments: `npm test` just executes this file with plain node.
//
// Strategy: apply() the plugin against a mock Cordis context that captures
// the registered /auth handler, serve that handler from a real node:http
// server, and exercise it over HTTP.
import assert from 'node:assert/strict'
import http from 'node:http'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import bcrypt from 'bcryptjs'
import { apply } from '../lib/host/index.js'

const DEFAULTS = {
  sessionTimeout: 3600,
  captchaExpires: 300,
  maxLoginAttempts: 5,
  accountMaxLoginAttempts: 10,
  blockDuration: 300,
  bindSessionToIp: true,
  singleSessionPerUser: true, // the single-session policy is ON by default
  trustProxy: false,
  devCaptchaText: true, // tests read the echoed answer instead of OCR-ing the SVG
  // Fresh-install default credentials: DISABLED by default in tests so the
  // existing suite keeps its exact semantics (a missing file stays empty);
  // the provisioning tests below opt in explicitly.
  autoProvisionAdmin: false,
  defaultAdminUser: 'admin',
  defaultPassword: 'admin123',
}

/** Boot the plugin against a mock ctx and serve its handler over real HTTP. */
function makeServer(overrides = {}) {
  // When a passwordFile is supplied, reuse its directory (so the runtime
  // security override file can be observed across "restarts"); otherwise
  // create a fresh temp dir per server.
  const dir = overrides.passwordFile ? path.dirname(overrides.passwordFile) : fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-auth-gate-test-'))
  const passwdFile = overrides.passwordFile ?? path.join(dir, 'auth.passwd')
  const config = { ...DEFAULTS, passwordFile: passwdFile, ...overrides }
  let handler = null
  const disposers = []
  const ctx = {
    // Cordis loggers are callable: ctx.logger(name) -> logger object.
    logger: () => ({ info() {}, warn() {}, error() {} }),
    effect(fn) {
      const dispose = fn()
      if (typeof dispose === 'function') disposers.push(dispose)
      return () => {}
    },
    webServer: {
      register(opts) {
        handler = opts.handler
        return () => { handler = null }
      },
    },
  }
  apply(ctx, config)
  const server = http.createServer((req, res) => {
    if (!handler) { res.writeHead(503); res.end(); return }
    handler(req, res)
  })
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({
        base: `http://127.0.0.1:${server.address().port}`,
        passwdFile,
        dir,
        close() {
          for (const d of disposers.reverse()) d()
          server.closeAllConnections?.()
          server.close()
        },
      })
    })
  })
}

/** Boot a server, run fn(s), always tear it down (incl. on assertion failure). */
async function withServer(overrides, fn) {
  const s = await makeServer(overrides)
  try {
    await fn(s)
  } finally {
    s.close()
  }
}

async function getCaptcha(base) {
  const res = await fetch(base + '/auth/captcha')
  assert.equal(res.status, 200)
  return res.json()
}

async function login(base, { username, password, captcha, uuid }, headers = {}) {
  const res = await fetch(base + '/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...headers },
    body: JSON.stringify({ username, password, captcha, uuid }),
  })
  return { status: res.status, body: await res.json() }
}

/** Fetch a fresh captcha and attempt a login, optionally spoofing XFF. */
async function newLogin(base, username, password, xff) {
  const c = await getCaptcha(base)
  const headers = {}
  if (xff !== undefined) headers['x-forwarded-for'] = xff
  return login(base, { username, password, captcha: c.text, uuid: c.uuid }, headers)
}

function addUser(file, username, password) {
  fs.appendFileSync(file, `${username}:${bcrypt.hashSync(password, 10)}\n`, { mode: 0o600 })
}

const tests = [
  {
    name: 'captcha is single-use; login succeeds and replays are rejected',
    fn: () => withServer({}, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      const c = await getCaptcha(s.base)
      assert.ok(typeof c.svg === 'string' && c.svg.length > 0)
      assert.ok(typeof c.uuid === 'string' && c.uuid.length > 0)
      const ok = await login(s.base, { username: 'admin', password: 'secret123', captcha: c.text, uuid: c.uuid })
      assert.equal(ok.status, 200)
      assert.ok(typeof ok.body.token === 'string' && ok.body.token.length >= 64)
      assert.equal(ok.body.username, 'admin')
      const replay = await login(s.base, { username: 'admin', password: 'secret123', captcha: c.text, uuid: c.uuid })
      assert.equal(replay.status, 400)
    }),
  },
  {
    name: 'failures lock the IP after maxLoginAttempts, even for correct credentials',
    fn: () => withServer({ maxLoginAttempts: 2, blockDuration: 60 }, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      const r1 = await newLogin(s.base, 'admin', 'wrongpass')
      assert.equal(r1.status, 401)
      const r2 = await newLogin(s.base, 'admin', 'wrongpass')
      assert.equal(r2.status, 401)
      const r3 = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(r3.status, 429)
      assert.ok(typeof r3.body.blockedUntil === 'number')
    }),
  },
  {
    name: 'maxLoginAttempts=1 locks the IP on the very first failure',
    fn: () => withServer({ maxLoginAttempts: 1, blockDuration: 60 }, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      const r1 = await newLogin(s.base, 'admin', 'wrongpass')
      assert.equal(r1.status, 401)
      const r2 = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(r2.status, 429)
      assert.ok(typeof r2.body.blockedUntil === 'number')
    }),
  },
  {
    name: 'unknown user and wrong password produce identical 401 bodies (no enumeration)',
    fn: () => withServer({}, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      const wrong = await newLogin(s.base, 'admin', 'bad')
      const ghost = await newLogin(s.base, 'ghost', 'bad')
      assert.equal(wrong.status, 401)
      assert.equal(ghost.status, 401)
      assert.deepEqual(wrong.body, ghost.body)
    }),
  },
  {
    name: 'verify: valid token 200 with X-Auth-User; missing/invalid 401',
    fn: () => withServer({}, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      const l = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(l.status, 200)
      const ok = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + l.body.token } })
      assert.equal(ok.status, 200)
      assert.equal(ok.headers.get('x-auth-user'), 'admin')
      const missing = await fetch(s.base + '/auth/verify')
      assert.equal(missing.status, 401)
      const invalid = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer deadbeef' } })
      assert.equal(invalid.status, 401)
    }),
  },
  {
    name: 'missing password file denies every login',
    fn: () => withServer({}, async (s) => {
      // passwdFile deliberately does not exist
      const r = await newLogin(s.base, 'admin', 'whatever')
      assert.equal(r.status, 401)
    }),
  },
  {
    name: 'oversized body returns a clean 413 and the server stays healthy',
    fn: () => withServer({}, async (s) => {
      const big = JSON.stringify({ username: 'a'.repeat(200), password: 'x'.repeat(70_000), captcha: 'a', uuid: 'b' })
      const res = await fetch(s.base + '/auth/login', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: big,
      })
      assert.equal(res.status, 413)
      const cap = await getCaptcha(s.base) // same server still answers
      assert.ok(cap.uuid)
    }),
  },
  {
    name: 'change password: own session survives, others die, new password works',
    // two concurrent sessions are needed here, so the single-session kick is
    // disabled; the password change itself must invalidate the OTHER session.
    fn: () => withServer({ singleSessionPerUser: false }, async (s) => {
      await addUser(s.passwdFile, 'admin', 'oldpass1')
      const a = await newLogin(s.base, 'admin', 'oldpass1')
      const b = await newLogin(s.base, 'admin', 'oldpass1')
      assert.equal(a.status, 200)
      assert.equal(b.status, 200)
      const cp = await fetch(s.base + '/auth/password', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + a.body.token },
        body: JSON.stringify({ oldPassword: 'oldpass1', newPassword: 'newpass1' }),
      })
      assert.equal(cp.status, 200)
      const v1 = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + a.body.token } })
      assert.equal(v1.status, 200)
      const v2 = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + b.body.token } })
      assert.equal(v2.status, 401)
      const n1 = await newLogin(s.base, 'admin', 'newpass1')
      assert.equal(n1.status, 200)
      const n0 = await newLogin(s.base, 'admin', 'oldpass1')
      assert.equal(n0.status, 401)
    }),
  },
  {
    name: 'change password with wrong old password → 403, then lockout applies',
    fn: () => withServer({ maxLoginAttempts: 2 }, async (s) => {
      await addUser(s.passwdFile, 'admin', 'oldpass1')
      const l = await newLogin(s.base, 'admin', 'oldpass1')
      assert.equal(l.status, 200)
      const cp = await fetch(s.base + '/auth/password', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + l.body.token },
        body: JSON.stringify({ oldPassword: 'nope', newPassword: 'newpass1' }),
      })
      assert.equal(cp.status, 403)
      // 2nd wrong old-password: attempt counter hits maxLoginAttempts, but this
      // request still returns 403 (same semantics as the login flow — the
      // failure that triggers the block is reported as the failure).
      const cp2 = await fetch(s.base + '/auth/password', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + l.body.token },
        body: JSON.stringify({ oldPassword: 'nope2', newPassword: 'newpass1' }),
      })
      assert.equal(cp2.status, 403)
      // 3rd request: the IP is now locked out → 429
      const cp3 = await fetch(s.base + '/auth/password', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + l.body.token },
        body: JSON.stringify({ oldPassword: 'nope3', newPassword: 'newpass1' }),
      })
      assert.equal(cp3.status, 429)
    }),
  },
  {
    name: 'trustProxy=false: forged X-Forwarded-For cannot dodge the lockout',
    fn: () => withServer({ trustProxy: false, maxLoginAttempts: 2 }, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      // every request forges a different IP; with trustProxy off the plugin
      // keys on the socket address (127.0.0.1 for all of these), so the
      // lockout still triggers.
      const r1 = await newLogin(s.base, 'admin', 'bad1', '1.1.1.1')
      assert.equal(r1.status, 401)
      const r2 = await newLogin(s.base, 'admin', 'bad2', '2.2.2.2')
      assert.equal(r2.status, 401)
      const r3 = await newLogin(s.base, 'admin', 'secret123', '3.3.3.3')
      assert.equal(r3.status, 429)
    }),
  },
  {
    name: 'trustProxy=true: the LAST XFF entry (proxy-appended) is the trusted IP',
    fn: () => withServer({ trustProxy: true, maxLoginAttempts: 2 }, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      // Nginx appends the real $remote_addr as the last entry; earlier
      // entries may be client-supplied and must be ignored.
      const r1 = await newLogin(s.base, 'admin', 'bad1', '6.6.6.6, 10.0.0.9')
      assert.equal(r1.status, 401)
      const r2 = await newLogin(s.base, 'admin', 'bad2', '7.7.7.7, 10.0.0.9')
      assert.equal(r2.status, 401)
      const r3 = await newLogin(s.base, 'admin', 'secret123', '8.8.8.8, 10.0.0.9')
      assert.equal(r3.status, 429)
      const r4 = await newLogin(s.base, 'admin', 'secret123', '9.9.9.9')
      assert.equal(r4.status, 200)
    }),
  },
  {
    name: 'concurrent password changes do not corrupt the file',
    fn: () => withServer({}, async (s) => {
      await addUser(s.passwdFile, 'alice', 'alicepass1')
      await addUser(s.passwdFile, 'bob', 'bobpass1')
      const alice = await newLogin(s.base, 'alice', 'alicepass1')
      const bob = await newLogin(s.base, 'bob', 'bobpass1')
      assert.equal(alice.status, 200)
      assert.equal(bob.status, 200)
      const change = (token, oldPw, newPw) => fetch(s.base + '/auth/password', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + token },
        body: JSON.stringify({ oldPassword: oldPw, newPassword: newPw }),
      })
      const [ra, rb] = await Promise.all([
        change(alice.body.token, 'alicepass1', 'alicepass2'),
        change(bob.body.token, 'bobpass1', 'bobpass2'),
      ])
      assert.equal(ra.status, 200)
      assert.equal(rb.status, 200)
      const na = await newLogin(s.base, 'alice', 'alicepass2')
      const nb = await newLogin(s.base, 'bob', 'bobpass2')
      assert.equal(na.status, 200)
      assert.equal(nb.status, 200)
      const content = fs.readFileSync(s.passwdFile, 'utf-8')
      assert.match(content, /^alice:\$2/m)
      assert.match(content, /^bob:\$2/m)
    }),
  },
  {
    name: 'rename: session survives, X-Auth-User and file update, old name dies',
    // two concurrent sessions are needed here too (both must follow the rename)
    fn: () => withServer({ singleSessionPerUser: false }, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      const a = await newLogin(s.base, 'admin', 'secret123')
      const b = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(a.status, 200)
      assert.equal(b.status, 200)
      const rn = await fetch(s.base + '/auth/username', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + a.body.token },
        body: JSON.stringify({ newUsername: 'root' }),
      })
      assert.equal(rn.status, 200)
      assert.deepEqual(await rn.json(), { ok: true, username: 'root' })
      // every live session of the user follows the rename
      const v1 = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + a.body.token } })
      assert.equal(v1.status, 200)
      assert.equal(v1.headers.get('x-auth-user'), 'root')
      const v2 = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + b.body.token } })
      assert.equal(v2.status, 200)
      assert.equal(v2.headers.get('x-auth-user'), 'root')
      // the old name can no longer log in, the new name can
      const old = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(old.status, 401)
      const nw = await newLogin(s.base, 'root', 'secret123')
      assert.equal(nw.status, 200)
      const content = fs.readFileSync(s.passwdFile, 'utf-8')
      assert.match(content, /^root:\$2/m)
      assert.ok(!/^admin:/.test(content))
    }),
  },
  {
    name: 'rename: requires auth and validates the new name',
    fn: () => withServer({}, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      await addUser(s.passwdFile, 'bob', 'bobpass1')
      const anon = await fetch(s.base + '/auth/username', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ newUsername: 'root' }),
      })
      assert.equal(anon.status, 401)
      const l = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(l.status, 200)
      const call = (newUsername) => fetch(s.base + '/auth/username', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + l.body.token },
        body: JSON.stringify({ newUsername }),
      })
      assert.equal((await call('')).status, 400)            // empty
      assert.equal((await call('a b')).status, 400)         // whitespace
      assert.equal((await call('a:b')).status, 400)         // colon (file format)
      assert.equal((await call('admin')).status, 400)       // same as current
      assert.equal((await call('bob')).status, 400)         // already taken
      assert.equal((await call('x'.repeat(33))).status, 400) // too long
      // the account is still intact after all rejected attempts
      const ok = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(ok.status, 200)
    }),
  },
  {
    name: 'rename: the reserved default admin name cannot be claimed by any account',
    fn: () => withServer({}, async (s) => {
      await addUser(s.passwdFile, 'alice', 'alicepass1')
      const l = await newLogin(s.base, 'alice', 'alicepass1')
      assert.equal(l.status, 200)
      assert.equal(l.body.mustChangeUsername, undefined) // non-default name: not forced
      const call = (newUsername) => fetch(s.base + '/auth/username', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + l.body.token },
        body: JSON.stringify({ newUsername }),
      })
      assert.equal((await call('admin')).status, 400) // reserved default name
      // the account is still intact after the rejected rename
      const ok = await newLogin(s.base, 'alice', 'alicepass1')
      assert.equal(ok.status, 200)
    }),
  },
  {
    name: 'security status requires login and reports defaults + live counts',
    fn: () => withServer({}, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      const anon = await fetch(s.base + '/auth/security')
      assert.equal(anon.status, 401)
      const l = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(l.status, 200)
      const st = await fetch(s.base + '/auth/security', { headers: { authorization: 'Bearer ' + l.body.token } })
      assert.equal(st.status, 200)
      const body = await st.json()
      assert.equal(body.sessionTimeout, 3600)
      assert.equal(body.captchaExpires, 300)
      assert.equal(body.maxLoginAttempts, 5)
      assert.equal(body.blockDuration, 300)
      assert.equal(body.trustProxy, false)
      assert.equal(body.singleSessionPerUser, true) // DEFAULTS enable the single-session policy
      assert.equal(body.devCaptchaText, true) // DEFAULTS echo the captcha text for tests
      assert.equal(body.bodyLimitBytes, 64 * 1024)
      assert.equal(body.activeSessions, 1)
      assert.equal(body.blockedIps, 0)
      assert.ok(typeof body.passwordFile === 'string' && body.passwordFile.length > 0)
      assert.ok(body.updatedAt === null)
    }),
  },
  {
    name: 'security update: requires auth, validates bounds and types, rejects empty',
    fn: () => withServer({}, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      const anon = await fetch(s.base + '/auth/security', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ sessionTimeout: 120 }),
      })
      assert.equal(anon.status, 401)
      const l = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(l.status, 200)
      const auth = { 'content-type': 'application/json', authorization: 'Bearer ' + l.body.token }
      const call = (body) => fetch(s.base + '/auth/security', { method: 'POST', headers: auth, body: JSON.stringify(body) })
      assert.equal((await call({})).status, 400)                      // nothing to update
      assert.equal((await call({ sessionTimeout: 5 })).status, 400)   // below min
      assert.equal((await call({ sessionTimeout: 999999 })).status, 400) // above max
      assert.equal((await call({ maxLoginAttempts: 'x' })).status, 400)  // wrong type
      assert.equal((await call({ trustProxy: 'yes' })).status, 400)      // wrong type
      assert.equal((await call({ singleSessionPerUser: 'yes' })).status, 400) // wrong type
      assert.equal((await call({ captchaExpires: 1.5 })).status, 400)    // rounds to 2, still below min
      // a rejected update must not change the running settings
      const st = await fetch(s.base + '/auth/security', { headers: { authorization: 'Bearer ' + l.body.token } })
      const body = await st.json()
      assert.equal(body.sessionTimeout, 3600)
    }),
  },
  {
    name: 'security update: applies at runtime and persists across restarts',
    fn: async () => {
      const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-auth-gate-sec-'))
      const passwdFile = path.join(dir, 'auth.passwd')
      try {
        await addUser(passwdFile, 'admin', 'secret123')
        const s1 = await makeServer({ passwordFile: passwdFile })
        try {
          const l = await newLogin(s1.base, 'admin', 'secret123')
          assert.equal(l.status, 200)
          const up = await fetch(s1.base + '/auth/security', {
            method: 'POST',
            headers: { 'content-type': 'application/json', authorization: 'Bearer ' + l.body.token },
            body: JSON.stringify({ maxLoginAttempts: 1, sessionTimeout: 120, blockDuration: 600, captchaExpires: 60, trustProxy: true, singleSessionPerUser: false }),
          })
          assert.equal(up.status, 200)
          const body = await up.json()
          assert.equal(body.maxLoginAttempts, 1)
          assert.equal(body.sessionTimeout, 120)
          assert.equal(body.trustProxy, true)
          assert.equal(body.singleSessionPerUser, false)
          assert.ok(typeof body.updatedAt === 'number')
          // runtime effect: with single-session OFF, a second login does NOT
          // kick the first one — both sessions stay alive.
          const l2 = await newLogin(s1.base, 'admin', 'secret123')
          assert.equal(l2.status, 200)
          const va = await fetch(s1.base + '/auth/verify', { headers: { authorization: 'Bearer ' + l.body.token } })
          assert.equal(va.status, 200)
          const vb = await fetch(s1.base + '/auth/verify', { headers: { authorization: 'Bearer ' + l2.body.token } })
          assert.equal(vb.status, 200)
          // runtime effect: with maxLoginAttempts=1 one bad login locks the IP
          const bad = await newLogin(s1.base, 'admin', 'wrong')
          assert.equal(bad.status, 401) // the triggering failure is reported as itself
          const good = await newLogin(s1.base, 'admin', 'secret123')
          assert.equal(good.status, 429) // now locked out
          // the override file is written next to the password file
          const file = path.join(dir, 'auth-gate.security.json')
          const written = JSON.parse(fs.readFileSync(file, 'utf-8'))
          assert.equal(written.maxLoginAttempts, 1)
          assert.equal(written.sessionTimeout, 120)
          assert.equal(written.singleSessionPerUser, false)
        } finally {
          s1.close()
        }
        // second boot in the same directory: persisted values are active
        const s2 = await makeServer({ passwordFile: passwdFile })
        try {
          const l2 = await newLogin(s2.base, 'admin', 'secret123')
          assert.equal(l2.status, 200)
          const st = await fetch(s2.base + '/auth/security', { headers: { authorization: 'Bearer ' + l2.body.token } })
          assert.equal(st.status, 200)
          const body = await st.json()
          assert.equal(body.maxLoginAttempts, 1)
          assert.equal(body.sessionTimeout, 120)
          assert.equal(body.blockDuration, 600)
          assert.equal(body.captchaExpires, 60)
          assert.equal(body.trustProxy, true)
          assert.equal(body.singleSessionPerUser, false) // persisted across restart
        } finally {
          s2.close()
        }
      } finally {
        fs.rmSync(dir, { recursive: true, force: true })
      }
    },
  },
  {
    name: 'corrupt or out-of-bounds override file falls back to safe values',
    fn: async () => {
      const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-auth-gate-sec-'))
      const passwdFile = path.join(dir, 'auth.passwd')
      try {
        await addUser(passwdFile, 'admin', 'secret123')
        // not JSON at all
        fs.writeFileSync(path.join(dir, 'auth-gate.security.json'), '{not json!!')
        const s0 = await makeServer({ passwordFile: passwdFile })
        try {
          const l = await newLogin(s0.base, 'admin', 'secret123')
          assert.equal(l.status, 200)
          const st = await fetch(s0.base + '/auth/security', { headers: { authorization: 'Bearer ' + l.body.token } })
          const body = await st.json()
          assert.equal(body.sessionTimeout, 3600) // static defaults win
          assert.equal(body.maxLoginAttempts, 5)
        } finally {
          s0.close()
        }
        // valid JSON but out-of-bounds / wrong types → clamped or ignored
        fs.writeFileSync(path.join(dir, 'auth-gate.security.json'), JSON.stringify({ sessionTimeout: 999999, maxLoginAttempts: 0, trustProxy: 'x' }))
        const s1 = await makeServer({ passwordFile: passwdFile })
        try {
          const l = await newLogin(s1.base, 'admin', 'secret123')
          assert.equal(l.status, 200)
          const st = await fetch(s1.base + '/auth/security', { headers: { authorization: 'Bearer ' + l.body.token } })
          const body = await st.json()
          assert.equal(body.sessionTimeout, 86400) // clamped to max
          assert.equal(body.maxLoginAttempts, 1)   // clamped to min
          assert.equal(body.trustProxy, false)     // wrong type ignored → static default
        } finally {
          s1.close()
        }
      } finally {
        fs.rmSync(dir, { recursive: true, force: true })
      }
    },
  },
  {
    name: 'unknown/expired captcha uuid counts toward the per-IP lockout',
    fn: () => withServer({ maxLoginAttempts: 5, blockDuration: 60 }, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      // 5 garbage-uuid attempts must lock the IP exactly like 5 wrong captchas,
      // otherwise /auth/login could be hammered forever without a counter.
      for (let i = 0; i < 5; i++) {
        const r = await login(s.base, { username: 'admin', password: 'wrong', captcha: 'x', uuid: 'garbage-' + i })
        assert.equal(r.status, 400)
      }
      const c = await getCaptcha(s.base)
      const after = await login(s.base, { username: 'admin', password: 'secret123', captcha: c.text, uuid: c.uuid })
      assert.equal(after.status, 429) // the correct credentials cannot log in: IP locked
    }),
  },
  {
    name: 'captcha endpoint is throttled per IP at the plugin level',
    fn: () => withServer({}, async (s) => {
      // The limit is 60 fetches per 60s window per IP; a burst beyond it must
      // start returning 429 even with no Nginx in front.
      await addUser(s.passwdFile, 'admin', 'secret123')
      const c = await getCaptcha(s.base) // fetch the login captcha BEFORE the burst
      let ok = 0
      let throttled = 0
      for (let i = 0; i < 66; i++) {
        const res = await fetch(s.base + '/auth/captcha')
        if (res.status === 200) ok += 1
        else if (res.status === 429) throttled += 1
        else throw new Error('unexpected captcha status ' + res.status)
      }
      assert.equal(ok + throttled, 66)
      assert.ok(throttled > 0, 'the burst must eventually be throttled') // 60-fetch window exceeded
      // login with the pre-fetched captcha still works (the throttle never
      // blocks authentication itself, only captcha issuance)
      const l = await login(s.base, { username: 'admin', password: 'secret123', captcha: c.text, uuid: c.uuid })
      assert.equal(l.status, 200)
    }),
  },
  {
    name: 'account throttle: IP-rotating credential failures still lock the account',
    fn: () => withServer({ trustProxy: true, maxLoginAttempts: 50, accountMaxLoginAttempts: 2, blockDuration: 60 }, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      // Every attempt forges a different IP: the per-IP counter never trips,
      // but the ACCOUNT counter (2 failures) must still lock the account.
      const r1 = await newLogin(s.base, 'admin', 'wrong1', '10.0.0.1')
      assert.equal(r1.status, 401)
      const r2 = await newLogin(s.base, 'admin', 'wrong2', '10.0.0.2')
      assert.equal(r2.status, 401)
      // Correct credentials from yet another IP: account is locked → 429.
      const r3 = await newLogin(s.base, 'admin', 'secret123', '10.0.0.3')
      assert.equal(r3.status, 429)
      assert.ok(typeof r3.body.blockedUntil === 'number')
    }),
  },
  {
    name: 'account throttle: captcha failures never poison the account lock',
    fn: () => withServer({ accountMaxLoginAttempts: 2, maxLoginAttempts: 50, blockDuration: 60 }, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      // Three WRONG CAPTCHA attempts (valid uuid, garbage answer): they count
      // per-IP only — the account counter must stay untouched, so a correct
      // login still succeeds afterwards.
      for (let i = 0; i < 3; i++) {
        const c = await getCaptcha(s.base)
        const r = await login(s.base, { username: 'admin', password: 'secret123', captcha: 'zzzz', uuid: c.uuid })
        assert.equal(r.status, 400)
      }
      const c = await getCaptcha(s.base)
      const good = await login(s.base, { username: 'admin', password: 'secret123', captcha: c.text, uuid: c.uuid })
      assert.equal(good.status, 200)
    }),
  },
  {
    name: 'wrong old-password attempts feed the account lockout too',
    fn: () => withServer({ maxLoginAttempts: 50, accountMaxLoginAttempts: 2, blockDuration: 60 }, async (s) => {
      await addUser(s.passwdFile, 'admin', 'oldpass1')
      const l = await newLogin(s.base, 'admin', 'oldpass1')
      assert.equal(l.status, 200)
      const cp = (oldPw) => fetch(s.base + '/auth/password', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + l.body.token },
        body: JSON.stringify({ oldPassword: oldPw, newPassword: 'newpass1' }),
      })
      assert.equal((await cp('nope1')).status, 403)
      assert.equal((await cp('nope2')).status, 403)
      // The account is now locked for LOGIN even with correct credentials.
      const blocked = await newLogin(s.base, 'admin', 'oldpass1')
      assert.equal(blocked.status, 429)
    }),
  },
  {
    name: 'session is bound to the client IP; reuse from another IP destroys it',
    fn: () => withServer({ trustProxy: true }, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      const l = await newLogin(s.base, 'admin', 'secret123', '1.1.1.1')
      assert.equal(l.status, 200)
      const same = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + l.body.token, 'x-forwarded-for': '1.1.1.1' } })
      assert.equal(same.status, 200)
      const other = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + l.body.token, 'x-forwarded-for': '2.2.2.2' } })
      assert.equal(other.status, 401)
      // The mismatched use destroyed the session: even back on the original IP it is gone.
      const after = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + l.body.token, 'x-forwarded-for': '1.1.1.1' } })
      assert.equal(after.status, 401)
    }),
  },
  {
    name: 'bindSessionToIp=false allows cross-IP token use',
    fn: () => withServer({ trustProxy: true, bindSessionToIp: false }, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      const l = await newLogin(s.base, 'admin', 'secret123', '1.1.1.1')
      assert.equal(l.status, 200)
      const other = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + l.body.token, 'x-forwarded-for': '2.2.2.2' } })
      assert.equal(other.status, 200)
    }),
  },
  {
    name: 'single-session: a new login kicks the previous session of the same account',
    fn: () => withServer({}, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      const a = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(a.status, 200)
      assert.equal(a.body.kickedPrevious, undefined) // first login kicks nothing
      const v1 = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + a.body.token } })
      assert.equal(v1.status, 200)
      const b = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(b.status, 200)
      assert.equal(b.body.kickedPrevious, true) // this login signed out session a
      // the old token is dead at the enforcement point: /auth/verify → 401
      const v2 = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + a.body.token } })
      assert.equal(v2.status, 401)
      // the new token works
      const v3 = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + b.body.token } })
      assert.equal(v3.status, 200)
      // kicking again on the next login is still reported
      const c = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(c.status, 200)
      assert.equal(c.body.kickedPrevious, true)
      const v4 = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + b.body.token } })
      assert.equal(v4.status, 401)
    }),
  },
  {
    name: 'singleSessionPerUser=false keeps multiple concurrent sessions alive',
    fn: () => withServer({ singleSessionPerUser: false }, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      const a = await newLogin(s.base, 'admin', 'secret123')
      const b = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(a.status, 200)
      assert.equal(b.status, 200)
      assert.equal(a.body.kickedPrevious, undefined)
      assert.equal(b.body.kickedPrevious, undefined)
      const va = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + a.body.token } })
      assert.equal(va.status, 200)
      const vb = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + b.body.token } })
      assert.equal(vb.status, 200)
    }),
  },
  {
    name: 'single-session: different accounts never affect each other',
    fn: () => withServer({}, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      await addUser(s.passwdFile, 'bob', 'bobpass1')
      const admin = await newLogin(s.base, 'admin', 'secret123')
      const bob = await newLogin(s.base, 'bob', 'bobpass1')
      assert.equal(admin.status, 200)
      assert.equal(bob.status, 200)
      assert.equal(admin.body.kickedPrevious, undefined)
      assert.equal(bob.body.kickedPrevious, undefined)
      const va = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + admin.body.token } })
      assert.equal(va.status, 200)
      const vb = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + bob.body.token } })
      assert.equal(vb.status, 200)
      // admin logging in again only kicks admin's older session, never bob's
      const admin2 = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(admin2.status, 200)
      assert.equal(admin2.body.kickedPrevious, true)
      const va1 = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + admin.body.token } })
      assert.equal(va1.status, 401)
      const vb2 = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + bob.body.token } })
      assert.equal(vb2.status, 200)
    }),
  },
  {
    name: 'single-session: the kicked session cannot be revived by logout or reuse',
    fn: () => withServer({}, async (s) => {
      await addUser(s.passwdFile, 'admin', 'secret123')
      const a = await newLogin(s.base, 'admin', 'secret123')
      const b = await newLogin(s.base, 'admin', 'secret123')
      assert.equal(b.body.kickedPrevious, true)
      // logging out the NEW session must not resurrect the old token
      await fetch(s.base + '/auth/logout', {
        method: 'POST',
        headers: { authorization: 'Bearer ' + b.body.token },
      })
      const va = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + a.body.token } })
      assert.equal(va.status, 401)
    }),
  },
  {
    name: 'non-JSON content-type is rejected with 415',
    fn: () => withServer({}, async (s) => {
      const res = await fetch(s.base + '/auth/login', {
        method: 'POST',
        headers: { 'content-type': 'text/plain' },
        body: 'username=admin&password=x',
      })
      assert.equal(res.status, 415)
      // missing content-type is rejected too
      const res2 = await fetch(s.base + '/auth/login', { method: 'POST', body: '{}' })
      assert.equal(res2.status, 415)
    }),
  },
  {
    name: 'auto-provision: first login must rename the admin account and change the default password',
    fn: () => withServer({ autoProvisionAdmin: true }, async (s) => {
      // the initial account was created at boot (bcrypt, mode 0600)
      assert.ok(fs.existsSync(s.passwdFile), 'password file must be provisioned')
      const content = fs.readFileSync(s.passwdFile, 'utf-8')
      assert.match(content, /^admin:\$2/m)

      // logging in with the documented default credentials succeeds and flags
      // BOTH forced changes (account name + password)
      const l = await newLogin(s.base, 'admin', 'admin123')
      assert.equal(l.status, 200)
      assert.equal(l.body.mustChangePassword, true)
      assert.equal(l.body.mustChangeUsername, true)

      // the flags survive on the session: /auth/verify exposes them, so a
      // page reload cannot bypass the forced changes
      const v = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + l.body.token } })
      assert.equal(v.status, 200)
      assert.equal(v.headers.get('x-auth-must-change'), '1')
      assert.equal(v.headers.get('x-auth-must-change-name'), '1')

      // renaming away from admin clears the NAME flag (and the session
      // follows the rename: X-Auth-User reports the new name)
      const rn = await fetch(s.base + '/auth/username', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + l.body.token },
        body: JSON.stringify({ newUsername: 'boss' }),
      })
      assert.equal(rn.status, 200)
      const v3 = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + l.body.token } })
      assert.equal(v3.status, 200)
      assert.equal(v3.headers.get('x-auth-user'), 'boss')
      assert.equal(v3.headers.get('x-auth-must-change-name'), null)
      assert.equal(v3.headers.get('x-auth-must-change'), '1') // password still pending

      // changing the password (old = default) clears the PASSWORD flag
      const cp = await fetch(s.base + '/auth/password', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + l.body.token },
        body: JSON.stringify({ oldPassword: 'admin123', newPassword: 'newpass1' }),
      })
      assert.equal(cp.status, 200)
      const v4 = await fetch(s.base + '/auth/verify', { headers: { authorization: 'Bearer ' + l.body.token } })
      assert.equal(v4.status, 200)
      assert.equal(v4.headers.get('x-auth-must-change'), null)
      assert.equal(v4.headers.get('x-auth-must-change-name'), null)

      // the new account logs in unflagged; the OLD default name is gone and
      // the default password no longer works
      const n = await newLogin(s.base, 'boss', 'newpass1')
      assert.equal(n.status, 200)
      assert.equal(n.body.mustChangePassword, undefined)
      assert.equal(n.body.mustChangeUsername, undefined)
      const oldName = await newLogin(s.base, 'admin', 'newpass1')
      assert.equal(oldName.status, 401)
      const oldPw = await newLogin(s.base, 'boss', 'admin123')
      assert.equal(oldPw.status, 401)

      // renaming back to the reserved default name is rejected
      const back = await fetch(s.base + '/auth/username', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + n.body.token },
        body: JSON.stringify({ newUsername: 'admin' }),
      })
      assert.equal(back.status, 400)
    }),
  },
  {
    name: 'auto-provision: disabled via config leaves an empty password file untouched',
    fn: () => withServer({ autoProvisionAdmin: false }, async (s) => {
      assert.ok(!fs.existsSync(s.passwdFile), 'no file must be created')
      const r = await newLogin(s.base, 'admin', 'admin123')
      assert.equal(r.status, 401)
    }),
  },
  {
    name: 'auto-provision: an existing account prevents the initial account creation',
    fn: async () => {
      const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-auth-gate-prov-'))
      const passwdFile = path.join(dir, 'auth.passwd')
      try {
        // 'bob' is written BEFORE the server boots, so the bootstrap must
        // leave the file alone: no admin line appears.
        await addUser(passwdFile, 'bob', 'bobpass1')
        const s = await makeServer({ passwordFile: passwdFile, autoProvisionAdmin: true })
        try {
          const content = fs.readFileSync(passwdFile, 'utf-8')
          assert.match(content, /^bob:\$2/m)
          assert.ok(!/^admin:/.test(content), 'no admin line may be injected')
          const ok = await newLogin(s.base, 'bob', 'bobpass1')
          assert.equal(ok.status, 200)
          const ghost = await newLogin(s.base, 'admin', 'admin123')
          assert.equal(ghost.status, 401)
        } finally {
          s.close()
        }
      } finally {
        fs.rmSync(dir, { recursive: true, force: true })
      }
    },
  },
]

let failed = 0
for (const t of tests) {
  const start = Date.now()
  try {
    await t.fn()
    console.log(`✔ ${t.name} (${Date.now() - start}ms)`)
  } catch (error) {
    failed += 1
    console.error(`✖ ${t.name}`)
    console.error(error && error.stack ? error.stack : String(error))
  }
}
console.log(`\n${tests.length - failed}/${tests.length} tests passed`)
if (failed > 0) process.exitCode = 1