# 素材来源与署名（NOTICE）

> ⚠️ **免责声明**
>
> 本插件使用的芙宁娜图片素材均系发布者**从网络公开资源收集而来**
> （原神维基 Genshin Impact Wiki 等社区站点，具体来源与链接见下文），
> 发布者**无法逐一核实其原始版权归属**。
>
> - 本项目**不涉及任何商业行为**，仅用于个人学习、界面美化与同好分享。
> - 角色“芙宁娜”（Furina）出自游戏《原神》（Genshin Impact），
>   其角色设计、形象及相关官方素材版权归 **© miHoYo / COGNOSPHERE / HoYoverse** 所有。
> - **如相关素材存在任何侵权，请联系发布者（在 GitHub 仓库提交 Issue
>   或联系仓库维护者），发布者收到通知后将第一时间删除相关内容。**

## 版权归属说明

角色“芙宁娜”（Furina）出自游戏《原神》（Genshin Impact），
角色设计、形象及相关官方素材版权归
**© miHoYo / COGNOSPHERE / HoYoverse** 所有。

## 使用到的图片素材

| 文件 | 内容 | 来源 | 链接 |
| --- | --- | --- | --- |
| `assets/source/furina-happy.webp` | 芙宁娜 chibi 开心表情（340×340，透明背景） | 原神中文维基（Genshin Impact Wiki）社区文件 `File:Furina_happy.webp` | https://genshin-impact.fandom.com/wiki/File:Furina_happy.webp |
| `assets/source/furina-shocked.webp` | 芙宁娜 chibi 惊讶表情（340×340，透明背景） | 原神中文维基（Genshin Impact Wiki）社区文件 `File:Furina_shocked.webp` | https://genshin-impact.fandom.com/wiki/File:Furina_shocked.webp |

两张素材在构建时以 data URI 形式内联进 `lib/client.js`，运行时不请求任何
远程图片。

## 权利声明与侵权处理

- 本项目的**代码**以 MIT License 开源（见 `LICENSE`）。
- 上述图片素材系网络公开资源，其原始权利属于各自作者与原版权方
  （含 HoYoverse 的角色版权）；发布者无法保证每项素材的授权状态。
- 本插件**仅用于个人、学习、非商业用途的分享**，不产生任何商业收益。
- **若任何权利方认为本素材构成侵权，请通过 GitHub Issue 或仓库维护者
  联系方式联系发布者；发布者将在收到通知后第一时间删除相关素材
  及其历史版本，并保留追究造成误用的权利。**
