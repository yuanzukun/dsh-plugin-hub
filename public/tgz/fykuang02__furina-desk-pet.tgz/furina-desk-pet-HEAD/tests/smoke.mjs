/**
 * 冒烟测试：在 Node 中用极简 DOM shim 加载构建产物 lib/client.js，
 * 验证桌宠的挂载、点击涨好感度、粒子特效、拖拽、升级、菜单、
 * 持久化与销毁行为。
 *
 * 运行：node tests/smoke.mjs（会先自动执行一次构建）
 */
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import vm from "node:vm";
import { installShim, findByClass, findAllByClass } from "./dom-shim.mjs";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const PKG = JSON.parse(readFileSync(resolve(ROOT, "package.json"), "utf8"));
const STORE_KEY = "dsh-furina-desk-pet.v1";

await import(pathToFileURL(resolve(ROOT, "build/build.mjs")).href);
const bundleCode = readFileSync(resolve(ROOT, "lib/client.js"), "utf8");

/* 从 bundle 中提取内联的表情 data URI（happy 在前，shocked 在后） */
const dataUris = [...bundleCode.matchAll(/data:image\/webp;base64,[A-Za-z0-9+/=]+/g)].map((m) => m[0]);
const SHOCKED_URI = dataUris[1];

let passed = 0;
const failures = [];
function assert(condition, message) {
  if (condition) {
    passed += 1;
  } else {
    failures.push(message);
    console.error("  ✗ " + message);
  }
}

/** 在给定的 shim 环境里加载 bundle 并激活插件，返回句柄。 */
function boot({ storage } = {}) {
  const shim = installShim({ storage });
  globalThis.window = shim.window;
  globalThis.document = shim.document;
  globalThis.localStorage = shim.localStorage;
  const handoffs = [];
  shim.window.__ModuleLoader__ = { load: (handoff) => handoffs.push(handoff) };
  vm.runInThisContext(bundleCode, { filename: "lib/client.js" });
  assert(handoffs.length === 1, "bundle 注册了 1 个模块 handoff");
  assert(handoffs[0]?.id === PKG.name, "handoff id 与包名一致");
  const exports = handoffs[0].factory(() => {
    throw new Error("测试中不应出现 require 调用");
  });
  const disposers = [];
  const fakeCtx = { effect: (register) => disposers.push(register()) };
  exports.apply(fakeCtx);
  return { shim, exports, disposers };
}

function rootOf(shim) {
  return shim.document.body.childNodes.find((node) => node.className === "fp-root");
}

function petOf(shim) {
  return rootOf(shim).childNodes[0]; // .fp-wrap
}

function barOf(wrap) {
  return wrap.childNodes.find((node) => node.classList.contains("fp-bar"));
}

function labelOf(wrap) {
  return barOf(wrap).childNodes.find((node) => node.classList.contains("fp-label"));
}

function menuOf(wrap) {
  return wrap.childNodes.find((node) => node.classList.contains("fp-menu"));
}

function clickPet(shim, x = 320, y = 420) {
  const wrap = petOf(shim);
  const pet = findByClass(wrap, "fp-pet");
  pet.dispatch("pointerdown", { button: 0, pointerId: 1, clientX: x, clientY: y });
  shim.window.dispatch("pointerup", { button: 0, pointerId: 1, clientX: x, clientY: y });
}

function clearGlobals() {
  globalThis.window = undefined;
  globalThis.document = undefined;
  globalThis.localStorage = undefined;
}

console.log("— 场景 1：挂载与初始状态");
{
  const { shim, disposers } = boot();
  const root = rootOf(shim);
  assert(!!root, "body 下挂载了 .fp-root");
  assert(root.dataset.plugin === PKG.name, "root 带插件标识 data-plugin");
  const style = shim.document.head.childNodes.find((node) => node.tagName === "STYLE");
  assert(!!style && style.textContent.includes("fp-root"), "样式注入 head");
  assert(style.dataset.plugin === PKG.name, "style 带插件标识");
  const wrap = root.childNodes[0];
  assert(wrap.classList.contains("fp-wrap"), ".fp-wrap 存在");
  const img = findByClass(wrap, "fp-img");
  assert(!!img && img.src.startsWith("data:image/webp;base64,"), "表情图以内联 data URI 提供");
  assert(labelOf(wrap).textContent === "0 · 初识", "初始好感度 0 · 初识");
  const stored = JSON.parse(shim.localStorage.getItem(STORE_KEY));
  assert(stored.affection === 0, "初始状态已持久化");
  assert(stored.x === null && stored.y === null, "默认位置不持久化（未拖拽过）");
  assert(disposers.length === 1, "apply 注册了 1 个 effect 销毁器");

  console.log("— 场景 2：点击芙宁娜涨好感度 + 粒子特效");
  const stableRandom = Math.random;
  Math.random = () => 0.99; // 0.99：不暴击、不触发惊讶表情，保证确定性
  clickPet(shim);
  Math.random = stableRandom;
  assert(labelOf(wrap).textContent === "1 · 初识", "点击后好感度 +1");
  const particles = root.childNodes.find((node) => node.classList.contains("fp-particles"));
  assert(findAllByClass(particles, "fp-heart-p").length > 0, "出现爱心粒子");
  assert(findAllByClass(particles, "fp-float-p").length === 1, "出现 +1 飘字");
  assert(JSON.parse(shim.localStorage.getItem(STORE_KEY)).affection === 1, "好感度写入 localStorage");

  console.log("— 场景 3：暴击（crit）");
  await new Promise((resolve) => setTimeout(resolve, 320)); // 跨过粒子特效的 250ms 节流
  const originalRandom = Math.random;
  Math.random = () => 0.01; // 0.01 < 0.08 → 必暴击
  clickPet(shim);
  assert(JSON.parse(shim.localStorage.getItem(STORE_KEY)).affection === 4, "暴击 +3");
  assert(findAllByClass(particles, "fp-gold").length > 0, "暴击金色爱心");
  Math.random = originalRandom;

  console.log("— 场景 4：拖拽移动 + 拖拽期间惊讶表情");
  const bar = barOf(wrap);
  const leftBefore = wrap.style.left;
  const affectionBefore = JSON.parse(shim.localStorage.getItem(STORE_KEY)).affection;
  bar.dispatch("pointerdown", { button: 0, pointerId: 2, clientX: 100, clientY: 100 });
  shim.window.dispatch("pointermove", { pointerId: 2, clientX: 170, clientY: 130 });
  const imgNow = findByClass(wrap, "fp-img");
  assert(imgNow.src === SHOCKED_URI, "拖拽期间切换惊讶表情");
  assert(leftBefore !== wrap.style.left, "拖拽改变 left");
  shim.window.dispatch("pointerup", { pointerId: 2, clientX: 170, clientY: 130 });
  assert(JSON.parse(shim.localStorage.getItem(STORE_KEY)).affection === affectionBefore, "拖拽不涨好感度");
  const stored2 = JSON.parse(shim.localStorage.getItem(STORE_KEY));
  assert(typeof stored2.x === "number" && typeof stored2.y === "number", "拖拽后位置持久化");

  console.log("— 场景 5：右键菜单（重置 / 收起 / 隐藏）");
  wrap.dispatch("contextmenu", {});
  const menu = menuOf(wrap);
  assert(menu.hidden === false, "右键打开菜单");
  const resetBtn = menu.childNodes[0];
  const compactBtn = menu.childNodes[1];
  const hideBtn = menu.childNodes[2];
  resetBtn.dispatch("click");
  resetBtn.dispatch("click");
  assert(labelOf(wrap).textContent === "0 · 初识", "两次点击重置好感度");
  wrap.dispatch("contextmenu", {});
  compactBtn.dispatch("click");
  assert(wrap.classList.contains("fp-compact"), "收起好感条生效");
  assert(JSON.parse(shim.localStorage.getItem(STORE_KEY)).compact === true, "紧凑模式持久化");
  wrap.dispatch("contextmenu", {});
  hideBtn.dispatch("click");
  assert(wrap.style.display === "none", "隐藏桌宠");
  const restore = root.childNodes.find((node) => node.classList.contains("fp-restore"));
  assert(restore && restore.hidden === false, "出现恢复按钮");
  restore.dispatch("click");
  assert(wrap.style.display === "", "恢复按钮唤回桌宠");

  console.log("— 场景 6：销毁清理");
  disposers[0]();
  assert(!root.parentNode, "销毁后 root 从 DOM 移除");
  assert(shim.document.head.childNodes.length === 0, "销毁后 style 移除");
  clearGlobals();
}

console.log("— 场景 7：刷新页面后状态恢复（localStorage 共享）");
{
  const storage = (() => {
    const { shim, disposers } = boot();
    const wrap = petOf(shim);
    wrap.dispatch("contextmenu", {});
    menuOf(wrap).childNodes[1].dispatch("click"); // 收起好感条
    const stableRandom = Math.random;
    Math.random = () => 0.99; // 三次点击均不暴击，结果恒为 3
    clickPet(shim);
    clickPet(shim);
    clickPet(shim);
    Math.random = stableRandom;
    disposers[0]();
    clearGlobals();
    return shim.localStorage;
  })();
  const { shim } = boot({ storage });
  const wrap = petOf(shim);
  assert(labelOf(wrap).textContent.startsWith("3 ·"), "刷新后好感度恢复为 3");
  assert(wrap.classList.contains("fp-compact"), "刷新后紧凑模式恢复");
  clearGlobals();
}

console.log("");
console.log("通过 " + passed + " 项断言，失败 " + failures.length + " 项");
if (failures.length > 0) {
  process.exitCode = 1;
}
