/**
 * 极简 DOM shim：仅覆盖桌宠代码用到的 API，供 Node 环境冒烟测试。
 * 这不是完整的 DOM 实现，也不用于浏览器。
 */

class ShimEvent {
  constructor(type, init = {}) {
    this.type = type;
    this.clientX = init.clientX ?? 0;
    this.clientY = init.clientY ?? 0;
    this.button = init.button ?? 0;
    this.pointerId = init.pointerId ?? 1;
    this.pointerType = init.pointerType ?? "mouse";
    this.key = init.key ?? "";
    this.target = null;
  }
  preventDefault() {}
  stopPropagation() {}
}

class ShimClassList {
  constructor(element) {
    this.element = element;
    this.classes = new Set();
  }
  _sync() {
    this.element.className = [...this.classes].join(" ");
  }
  add(...names) {
    for (const name of names) this.classes.add(name);
    this._sync();
  }
  remove(...names) {
    for (const name of names) this.classes.delete(name);
    this._sync();
  }
  toggle(name, force) {
    const next = force === undefined ? !this.classes.has(name) : !!force;
    if (next) this.classes.add(name);
    else this.classes.delete(name);
    this._sync();
    return next;
  }
  contains(name) {
    return this.classes.has(name);
  }
}

class ShimStyle {
  setProperty(key, value) {
    this[key] = value;
  }
}

class ShimElement {
  constructor(tagName) {
    this.tagName = String(tagName).toUpperCase();
    this.childNodes = [];
    this.parentNode = null;
    this.classList = new ShimClassList(this);
    Object.defineProperty(this, "className", {
      get() {
        return [...this.classList.classes].join(" ");
      },
      set(value) {
        this.classList.classes = new Set(String(value).split(/\s+/).filter(Boolean));
      },
      configurable: true,
    });
    this.style = new ShimStyle();
    this.dataset = {};
    this.listeners = {};
    this.attributes = {};
    this.textContent = "";
    this.title = "";
    this.hidden = false;
    this.src = "";
    this.alt = "";
    this.draggable = false;
    this.tabIndex = -1;
    this.type = "";
    this.offsetWidth = 0;
    this.offsetHeight = 0;
  }
  get firstChild() {
    return this.childNodes[0] ?? null;
  }
  setAttribute(name, value) {
    this.attributes[name] = String(value);
  }
  getAttribute(name) {
    return Object.prototype.hasOwnProperty.call(this.attributes, name) ? this.attributes[name] : null;
  }
  appendChild(node) {
    if (node.parentNode) node.parentNode.removeChild(node);
    node.parentNode = this;
    this.childNodes.push(node);
    return node;
  }
  removeChild(node) {
    const index = this.childNodes.indexOf(node);
    if (index !== -1) this.childNodes.splice(index, 1);
    node.parentNode = null;
    return node;
  }
  append(...nodes) {
    for (const node of nodes) this.appendChild(node);
  }
  remove() {
    if (this.parentNode) this.parentNode.removeChild(this);
  }
  contains(node) {
    let current = node;
    while (current) {
      if (current === this) return true;
      current = current.parentNode;
    }
    return false;
  }
  addEventListener(type, listener) {
    (this.listeners[type] ||= []).push(listener);
  }
  removeEventListener(type, listener) {
    const list = this.listeners[type];
    if (!list) return;
    const index = list.indexOf(listener);
    if (index !== -1) list.splice(index, 1);
  }
  dispatch(type, init = {}) {
    const event = new ShimEvent(type, init);
    event.target = this;
    /* 冒泡：从目标元素沿 parentNode 链向上触发同名监听器（与真实 DOM 一致） */
    let node = this;
    while (node) {
      for (const listener of [...(node.listeners[type] ?? [])]) listener(event);
      node = node.parentNode;
    }
    return event;
  }
}

class ShimDocument {
  constructor() {
    this.head = new ShimElement("head");
    this.body = new ShimElement("body");
  }
  createElement(tagName) {
    return new ShimElement(tagName);
  }
}

class ShimWindow {
  constructor(document) {
    this.document = document;
    this.listeners = {};
    this.innerWidth = 1280;
    this.innerHeight = 800;
  }
  addEventListener(type, listener) {
    (this.listeners[type] ||= []).push(listener);
  }
  removeEventListener(type, listener) {
    const list = this.listeners[type];
    if (!list) return;
    const index = list.indexOf(listener);
    if (index !== -1) list.splice(index, 1);
  }
  dispatch(type, init = {}) {
    const event = new ShimEvent(type, init);
    event.target = this;
    for (const listener of [...(this.listeners[type] ?? [])]) listener(event);
    return event;
  }
}

class ShimStorage {
  constructor() {
    this.map = new Map();
  }
  getItem(key) {
    return this.map.has(key) ? this.map.get(key) : null;
  }
  setItem(key, value) {
    this.map.set(key, String(value));
  }
  removeItem(key) {
    this.map.delete(key);
  }
}

/** 安装一套互相连通的 shim，返回句柄。 */
export function installShim({ storage } = {}) {
  const document = new ShimDocument();
  const window = new ShimWindow(document);
  const localStorage = storage ?? new ShimStorage();
  window.document = document;
  return { window, document, localStorage };
}

/** 按 className 递归查找第一个匹配元素（测试断言用）。 */
export function findByClass(root, className) {
  const stack = [root];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node && node.classList && node.classList.contains(className)) return node;
    if (node && node.childNodes) stack.push(...node.childNodes);
  }
  return null;
}

/** 收集所有匹配 className 的元素。 */
export function findAllByClass(root, className) {
  const found = [];
  const stack = [root];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node && node.classList && node.classList.contains(className)) found.push(node);
    if (node && node.childNodes) stack.push(...node.childNodes);
  }
  return found;
}
