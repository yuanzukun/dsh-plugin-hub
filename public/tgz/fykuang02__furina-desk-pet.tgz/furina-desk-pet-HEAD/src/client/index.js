/**
 * 芙宁娜卡通大头桌宠（Furina desk pet）— DeepSeek Harness 客户端插件入口。
 *
 * 纯原生 JS、零运行时依赖：在页面上挂载一只可拖拽的芙宁娜大头桌宠，
 * 提供点击特效（爱心粒子 / 暴击 / +1 飘字 / 台词气泡）、好感度系统
 * （localStorage 持久化、等级成长、升级庆祝）与右键菜单
 * （重置好感度 / 收起好感条 / 暂时隐藏）。
 *
 * 构建脚本 build/build.mjs 会把 assets/source 下两张透明 chibi 表情以
 * data URI 形式内联到本文件（__FURINA_HAPPY_DATAURI__ /
 * __FURINA_SHOCKED_DATAURI__ 占位符），因此产物不依赖任何外部资源。
 */

/* eslint-disable no-restricted-globals */

const PLUGIN_ID = "@dsh-external/dsh-client-ui-furina-desk-pet";

const ART_HAPPY = __FURINA_HAPPY_DATAURI__;
const ART_SHOCKED = __FURINA_SHOCKED_DATAURI__;

const STORE_KEY = "dsh-furina-desk-pet.v1";
const WRAP_W = 150;
const WRAP_H = 150;
const MARGIN = 16;
const MAX_AFFECTION = 9999;
const MAX_BAR = 250; // 进度条拉满对应的好感度数值

const LEVELS = [
  { min: 0, name: "初识" },
  { min: 10, name: "相识" },
  { min: 30, name: "熟悉" },
  { min: 60, name: "亲密" },
  { min: 100, name: "挚友" },
  { min: 200, name: "水神的宠儿" },
];

const IDLE_LINES = [
  "今天也要好好努力哦~",
  "芙宁娜在看着你！",
  "累了就摸摸芙芙的头吧。",
  "水，会记住所有的故事。",
  "本小姐的演出，随时为你开场！",
  "要不要来一杯下午茶？",
  "工作再忙，也要记得休息哦。",
];

const CLICK_LINES = [
  "嗯？被摸头了~",
  "嘿嘿，再多摸摸嘛！",
  "芙芙心情变好了！",
  "你的手好温暖。",
  "这是……给我的掌声吗？",
  "哼哼，芙宁娜大人允许你继续。",
];

const CRIT_LINES = [
  "哇，是金色的心！",
  "水神大人的祝福！",
  "这是……命运的暴击！",
];

const LEVEL_UP_LINES = [
  "羁绊加深了！",
  "芙芙越来越喜欢你了~",
  "我们的故事又翻过一页。",
  "水神的目光注视着你。",
];

/* ---------- 工具函数 ---------- */

function rand(min, max) {
  return min + Math.random() * (max - min);
}

function pick(list) {
  return list[Math.floor(Math.random() * list.length)];
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function levelIndex(affection) {
  let index = 0;
  for (let i = 0; i < LEVELS.length; i += 1) {
    if (affection >= LEVELS[i].min) index = i;
  }
  return index;
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object") return parsed;
  } catch (_error) {
    /* 隐私模式等场景下 localStorage 可能不可用 */
  }
  return null;
}

function saveState(state) {
  try {
    localStorage.setItem(
      STORE_KEY,
      JSON.stringify({
        affection: state.affection,
        x: state.x,
        y: state.y,
        compact: state.compact,
      }),
    );
  } catch (_error) {
    /* 忽略持久化失败：好感度仍在本页生效 */
  }
}

/* ---------- 样式 ---------- */

const CSS_TEXT = `
.fp-root {
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 2147483000;
  font-family: system-ui, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
}
.fp-root * { box-sizing: border-box; }
.fp-wrap {
  position: absolute;
  width: ${WRAP_W}px;
  height: ${WRAP_H}px;
  pointer-events: auto;
  cursor: grab;
  user-select: none;
  -webkit-user-select: none;
  touch-action: none;
}
.fp-wrap:active { cursor: grabbing; }
.fp-wrap:focus-visible { outline: 2px solid #8ecfff; outline-offset: 3px; border-radius: 999px; }
.fp-pet {
  position: absolute;
  top: 0;
  left: 15px;
  width: 120px;
  height: 120px;
  border-radius: 50%;
  overflow: hidden;
  background: radial-gradient(circle at 50% 38%, #eaf6ff 0%, #cfe8ff 52%, #a9cff2 100%);
  box-shadow: 0 6px 18px rgba(30, 60, 120, 0.35), inset 0 0 0 2px rgba(255, 255, 255, 0.55);
  animation: fp-bob 3.4s ease-in-out infinite;
}
.fp-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  pointer-events: none;
  -webkit-user-drag: none;
}
.fp-wrap.fp-pop { animation: fp-pop 0.3s ease; }
.fp-wrap.fp-hop { animation: fp-hop 0.6s ease; }
.fp-wrap.fp-wiggle { animation: fp-wiggle 0.7s ease; }
.fp-pet.fp-surprise { animation: fp-surprise 0.5s ease infinite; }
.fp-bubble {
  position: absolute;
  bottom: 100%;
  left: 50%;
  transform: translateX(-50%);
  margin-bottom: 8px;
  max-width: 230px;
  min-width: 84px;
  padding: 8px 12px;
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.97);
  color: #24406b;
  font-size: 12px;
  line-height: 1.5;
  text-align: center;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.28);
  animation: fp-bubble-in 0.25s ease;
}
.fp-bubble::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  transform: translateX(-50%);
  border: 6px solid transparent;
  border-top-color: rgba(255, 255, 255, 0.97);
}
.fp-bubble[hidden] { display: none; }
.fp-bar {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 5px 8px;
  border-radius: 999px;
  background: rgba(21, 32, 64, 0.66);
  border: 1px solid rgba(255, 255, 255, 0.28);
  backdrop-filter: blur(6px);
  color: #ffffff;
  font-size: 11px;
  line-height: 1;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25);
}
.fp-compact .fp-bar { display: none; }
.fp-heart { color: #ff7fa8; font-size: 12px; text-shadow: 0 0 6px rgba(255, 127, 168, 0.9); }
.fp-track {
  flex: 1;
  height: 8px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.22);
  overflow: hidden;
}
.fp-fill {
  height: 100%;
  width: 0%;
  border-radius: inherit;
  background: linear-gradient(90deg, #7cc7ff, #ff9ad5);
  transition: width 0.5s cubic-bezier(0.22, 1, 0.36, 1);
  box-shadow: 0 0 8px rgba(140, 200, 255, 0.7);
}
.fp-max .fp-fill { background: linear-gradient(90deg, #ffd76e, #ff9ad5); }
.fp-label { font-weight: 600; color: #eaf3ff; white-space: nowrap; }
.fp-menu {
  position: absolute;
  bottom: calc(100% + 8px);
  right: 0;
  min-width: 132px;
  padding: 6px;
  border-radius: 12px;
  background: rgba(16, 26, 52, 0.92);
  border: 1px solid rgba(255, 255, 255, 0.25);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
  display: flex;
  flex-direction: column;
  gap: 2px;
  backdrop-filter: blur(8px);
  pointer-events: auto;
}
.fp-menu[hidden] { display: none; }
.fp-menu-btn {
  appearance: none;
  border: 0;
  background: transparent;
  color: #eaf3ff;
  font: inherit;
  font-size: 12px;
  text-align: left;
  padding: 7px 10px;
  border-radius: 8px;
  cursor: pointer;
}
.fp-menu-btn:hover { background: rgba(255, 255, 255, 0.14); }
.fp-menu-btn.fp-danger { color: #ffb3c1; }
.fp-particles { position: fixed; inset: 0; pointer-events: none; overflow: hidden; }
.fp-heart-p,
.fp-float-p {
  position: absolute;
  pointer-events: none;
  animation: fp-rise 1.25s ease-out forwards;
  will-change: transform, opacity;
}
.fp-heart-p { font-size: 16px; color: #ff7fa8; text-shadow: 0 1px 3px rgba(0, 0, 0, 0.2); }
.fp-heart-p.fp-gold { color: #ffc94d; }
.fp-float-p {
  font-weight: 800;
  font-size: 14px;
  color: #ffd76e;
  text-shadow: 0 1px 4px rgba(90, 60, 0, 0.45);
}
.fp-restore {
  position: fixed;
  right: 16px;
  bottom: 16px;
  width: 46px;
  height: 46px;
  border-radius: 50%;
  border: 1px solid rgba(255, 255, 255, 0.4);
  background: linear-gradient(160deg, #8ecfff, #6f8dff);
  color: #ffffff;
  font-size: 20px;
  font-weight: 700;
  cursor: pointer;
  box-shadow: 0 4px 14px rgba(60, 90, 200, 0.45);
  pointer-events: auto;
  animation: fp-bubble-in 0.25s ease;
}
.fp-restore[hidden] { display: none; }
@keyframes fp-bob {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-5px); }
}
@keyframes fp-pop {
  0% { transform: scale(1); }
  35% { transform: scale(1.08, 0.9); }
  60% { transform: scale(0.95, 1.05); }
  100% { transform: scale(1); }
}
@keyframes fp-hop {
  0%, 100% { transform: translateY(0); }
  30% { transform: translateY(-16px) scale(1.02, 0.96); }
  55% { transform: translateY(0) scale(0.98, 1.04); }
  75% { transform: translateY(-6px); }
}
@keyframes fp-wiggle {
  0%, 100% { transform: rotate(0); }
  25% { transform: rotate(-6deg); }
  75% { transform: rotate(6deg); }
}
@keyframes fp-surprise {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.05); }
}
@keyframes fp-bubble-in {
  from { opacity: 0; transform: translateX(-50%) translateY(4px) scale(0.9); }
  to { opacity: 1; transform: translateX(-50%) translateY(0) scale(1); }
}
@keyframes fp-rise {
  0% { transform: translate(-50%, -50%) scale(0.5); opacity: 0; }
  12% { transform: translate(-50%, -50%) scale(1.15); opacity: 1; }
  100% {
    transform: translate(calc(-50% + var(--dx)), calc(-50% + var(--dy))) scale(0.55);
    opacity: 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .fp-pet, .fp-wrap, .fp-heart-p, .fp-float-p, .fp-bubble { animation: none !important; }
}
`;

/* ---------- 桌宠引擎 ---------- */

class FurinaPet {
  constructor(root) {
    this.root = root;
    this.state = Object.assign(
      { affection: 0, x: null, y: null, compact: false },
      loadState() || {},
    );
    this.timers = new Set();
    this.disposed = false;
    this.drag = null;
    this.dragFace = false;
    this.lastPetAt = 0;
    this.menuOpen = false;
    this.resetArmed = false;
    this.resetArmTimer = null;
    this.bubbleTimer = null;
    this.shockTimer = null;
    this.buildDom();
  }

  buildDom() {
    this.wrap = document.createElement("div");
    this.wrap.className = "fp-wrap";
    this.wrap.setAttribute("role", "button");
    this.wrap.setAttribute("aria-label", "芙宁娜桌宠：点击摸摸她，拖动可以移动");
    this.wrap.tabIndex = 0;

    this.bubbleEl = document.createElement("div");
    this.bubbleEl.className = "fp-bubble";
    this.bubbleEl.hidden = true;
    this.bubbleText = document.createElement("span");
    this.bubbleText.textContent = "";
    this.bubbleEl.appendChild(this.bubbleText);

    this.petEl = document.createElement("div");
    this.petEl.className = "fp-pet";
    this.img = document.createElement("img");
    this.img.className = "fp-img";
    this.img.src = ART_HAPPY;
    this.img.alt = "芙宁娜（卡通大头）";
    this.img.draggable = false;
    this.petEl.appendChild(this.img);

    this.barEl = document.createElement("div");
    this.barEl.className = "fp-bar";
    this.heartEl = document.createElement("span");
    this.heartEl.className = "fp-heart";
    this.heartEl.textContent = "♥";
    this.trackEl = document.createElement("div");
    this.trackEl.className = "fp-track";
    this.fillEl = document.createElement("div");
    this.fillEl.className = "fp-fill";
    this.trackEl.appendChild(this.fillEl);
    this.labelEl = document.createElement("span");
    this.labelEl.className = "fp-label";
    this.labelEl.textContent = "";
    this.barEl.append(this.heartEl, this.trackEl, this.labelEl);

    this.menuEl = document.createElement("div");
    this.menuEl.className = "fp-menu";
    this.menuEl.hidden = true;
    this.menuEl.setAttribute("role", "menu");
    this.resetBtn = this.makeMenuButton("重置好感度", "fp-danger");
    this.compactBtn = this.makeMenuButton("收起好感条");
    this.hideBtn = this.makeMenuButton("暂时隐藏");
    this.menuEl.append(this.resetBtn, this.compactBtn, this.hideBtn);

    this.particlesEl = document.createElement("div");
    this.particlesEl.className = "fp-particles";

    this.restoreEl = document.createElement("button");
    this.restoreEl.className = "fp-restore";
    this.restoreEl.hidden = true;
    this.restoreEl.textContent = "芙";
    this.restoreEl.title = "叫芙宁娜回来";

    this.wrap.append(this.bubbleEl, this.petEl, this.barEl, this.menuEl);
    this.root.append(this.wrap, this.particlesEl, this.restoreEl);

    if (this.state.compact) this.wrap.classList.add("fp-compact");

    /* 事件绑定（在 start 中统一解绑） */
    this.onPointerDown = (event) => this.handlePointerDown(event);
    this.onPointerMove = (event) => this.handlePointerMove(event);
    this.onPointerUp = (event) => this.handlePointerUp(event);
    this.onContextMenu = (event) => this.handleContextMenu(event);
    this.onKeyDown = (event) => this.handleKeyDown(event);
    this.onWindowDown = (event) => this.handleWindowDown(event);
    this.onResize = () => this.clampPosition();
    this.onStorage = (event) => this.handleStorage(event);

    this.wrap.addEventListener("pointerdown", this.onPointerDown);
    this.wrap.addEventListener("contextmenu", this.onContextMenu);
    this.wrap.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("pointermove", this.onPointerMove);
    window.addEventListener("pointerup", this.onPointerUp);
    window.addEventListener("pointercancel", this.onPointerUp);
    window.addEventListener("pointerdown", this.onWindowDown);
    window.addEventListener("resize", this.onResize);
    window.addEventListener("storage", this.onStorage);

    this.onResetClick = () => this.handleReset();
    this.onCompactClick = () => this.handleCompactToggle();
    this.onHideClick = () => this.hide();
    this.onRestoreClick = () => this.show();
    this.resetBtn.addEventListener("click", this.onResetClick);
    this.compactBtn.addEventListener("click", this.onCompactClick);
    this.hideBtn.addEventListener("click", this.onHideClick);
    this.restoreEl.addEventListener("click", this.onRestoreClick);
  }

  makeMenuButton(text, extraClass) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "fp-menu-btn" + (extraClass ? " " + extraClass : "");
    btn.textContent = text;
    return btn;
  }

  start() {
    this.renderBar();
    this.applyPosition();
    saveState(this.state);
    this.scheduleIdleMotion();
    this.scheduleIdleLine();
  }

  stop() {
    this.disposed = true;
    for (const timer of this.timers) clearTimeout(timer);
    this.timers.clear();
    this.wrap.removeEventListener("pointerdown", this.onPointerDown);
    this.wrap.removeEventListener("contextmenu", this.onContextMenu);
    this.wrap.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("pointermove", this.onPointerMove);
    window.removeEventListener("pointerup", this.onPointerUp);
    window.removeEventListener("pointercancel", this.onPointerUp);
    window.removeEventListener("pointerdown", this.onWindowDown);
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("storage", this.onStorage);
    this.resetBtn.removeEventListener("click", this.onResetClick);
    this.compactBtn.removeEventListener("click", this.onCompactClick);
    this.hideBtn.removeEventListener("click", this.onHideClick);
    this.restoreEl.removeEventListener("click", this.onRestoreClick);
  }

  later(ms, fn) {
    if (this.disposed) return null;
    let timer;
    timer = setTimeout(() => {
      this.timers.delete(timer);
      if (!this.disposed) fn();
    }, ms);
    this.timers.add(timer);
    return timer;
  }

  /* ---------- 定位 ---------- */

  applyPosition() {
    const width = window.innerWidth || 1280;
    const height = window.innerHeight || 800;
    let left;
    let top;
    if (typeof this.state.x === "number" && typeof this.state.y === "number") {
      left = this.state.x * width;
      top = this.state.y * height;
    } else {
      left = width - WRAP_W - MARGIN;
      top = height - WRAP_H - MARGIN;
    }
    left = clamp(left, 0, Math.max(0, width - WRAP_W));
    top = clamp(top, 0, Math.max(0, height - WRAP_H));
    this.wrap.style.left = left + "px";
    this.wrap.style.top = top + "px";
  }

  currentLeft() {
    const parsed = parseFloat(this.wrap.style.left);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  currentTop() {
    const parsed = parseFloat(this.wrap.style.top);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  clampPosition() {
    const width = window.innerWidth || 1280;
    const height = window.innerHeight || 800;
    const left = clamp(this.currentLeft(), 0, Math.max(0, width - WRAP_W));
    const top = clamp(this.currentTop(), 0, Math.max(0, height - WRAP_H));
    this.wrap.style.left = left + "px";
    this.wrap.style.top = top + "px";
  }

  persistPosition() {
    const width = window.innerWidth || 1280;
    const height = window.innerHeight || 800;
    this.state.x = this.currentLeft() / width;
    this.state.y = this.currentTop() / height;
    saveState(this.state);
  }

  /* ---------- 交互 ---------- */

  handlePointerDown(event) {
    if (event.button !== 0 && event.button !== undefined) return;
    const target = event.target;
    if (target && this.menuEl.contains(target)) return;
    if (target && this.bubbleEl.contains(target)) return;
    this.closeMenu();
    event.preventDefault && event.preventDefault();
    this.drag = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      baseLeft: this.currentLeft(),
      baseTop: this.currentTop(),
      moved: false,
      petHit: !!target && (target === this.petEl || this.petEl.contains(target)),
    };
  }

  handlePointerMove(event) {
    if (!this.drag || event.pointerId !== this.drag.pointerId) return;
    const dx = event.clientX - this.drag.startX;
    const dy = event.clientY - this.drag.startY;
    if (!this.drag.moved && (Math.abs(dx) > 4 || Math.abs(dy) > 4)) {
      this.drag.moved = true;
    }
    if (this.drag.moved && !this.dragFace) {
      this.dragFace = true;
      this.setFace("shocked");
    }
    if (this.drag.moved) {
      const width = window.innerWidth || 1280;
      const height = window.innerHeight || 800;
      this.wrap.style.left = clamp(this.drag.baseLeft + dx, 0, Math.max(0, width - WRAP_W)) + "px";
      this.wrap.style.top = clamp(this.drag.baseTop + dy, 0, Math.max(0, height - WRAP_H)) + "px";
    }
  }

  handlePointerUp(event) {
    if (!this.drag || event.pointerId !== this.drag.pointerId) return;
    const wasClick = !this.drag.moved && this.drag.petHit;
    this.drag = null;
    if (this.dragFace) {
      this.dragFace = false;
      if (!this.shockTimer) this.setFace("happy");
    }
    if (wasClick) this.pet(event.clientX, event.clientY);
    else if (event.clientX !== undefined) this.persistPosition();
  }

  handleContextMenu(event) {
    event.preventDefault && event.preventDefault();
    this.toggleMenu();
  }

  handleKeyDown(event) {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault && event.preventDefault();
      this.pet();
    } else if (event.key === "Escape") {
      this.closeMenu();
    }
  }

  handleWindowDown(event) {
    if (!this.menuOpen) return;
    const target = event.target;
    if (target && (this.wrap.contains(target) || this.menuEl.contains(target))) return;
    this.closeMenu();
  }

  handleStorage(event) {
    if (event.key !== STORE_KEY || !event.newValue) return;
    try {
      const next = JSON.parse(event.newValue);
      if (next && typeof next === "object") {
        if (typeof next.affection === "number") {
          this.state.affection = next.affection;
          this.renderBar();
        }
        if (typeof next.compact === "boolean") this.setCompact(next.compact);
      }
    } catch (_error) {
      /* 忽略解析失败 */
    }
  }

  pet(x, y) {
    /* 每次点击都涨好感度；粒子/气泡等表现按节流，避免连点刷屏 */
    const crit = Math.random() < 0.08;
    const delta = crit ? 3 : 1;
    this.addAffection(delta);
    const now = Date.now();
    if (now - this.lastPetAt < 250) return;
    this.lastPetAt = now;
    this.pop();
    this.spawnParticles(x, y, crit, delta);
    this.say(crit ? pick(CRIT_LINES) : pick(CLICK_LINES), 2800);
    if (!crit && Math.random() < 0.2) this.flashShocked(1300);
  }

  /* ---------- 好感度 ---------- */

  addAffection(delta) {
    const before = levelIndex(this.state.affection);
    this.state.affection = Math.min(MAX_AFFECTION, this.state.affection + delta);
    saveState(this.state);
    this.renderBar();
    const after = levelIndex(this.state.affection);
    if (after > before) this.celebrate(after);
  }

  renderBar() {
    const level = LEVELS[levelIndex(this.state.affection)];
    const percent = Math.min(100, (this.state.affection / MAX_BAR) * 100);
    this.fillEl.style.width = percent.toFixed(2) + "%";
    this.labelEl.textContent = this.state.affection + " · " + level.name;
    this.barEl.title = "好感度 " + this.state.affection + " / " + MAX_AFFECTION;
    const isMax = levelIndex(this.state.affection) === LEVELS.length - 1;
    this.barEl.classList.toggle("fp-max", isMax);
  }

  celebrate(levelIndexValue) {
    const level = LEVELS[levelIndexValue];
    const centerX = this.currentLeft() + WRAP_W / 2;
    const centerY = this.currentTop() + 56;
    this.burst(centerX, centerY, 16, true);
    this.flashShocked(1600);
    this.say(level.name + "！" + pick(LEVEL_UP_LINES), 5200);
    this.pop();
  }

  /* ---------- 表现 ---------- */

  setFace(face) {
    this.img.src = face === "shocked" ? ART_SHOCKED : ART_HAPPY;
    this.petEl.classList.toggle("fp-surprise", face === "shocked");
  }

  flashShocked(ms) {
    this.setFace("shocked");
    if (this.shockTimer) clearTimeout(this.shockTimer);
    this.shockTimer = this.later(ms, () => {
      this.shockTimer = null;
      if (!this.dragFace) this.setFace("happy");
    });
  }

  pop() {
    this.wrap.classList.remove("fp-pop");
    void this.wrap.offsetWidth; /* 重启动画 */
    this.wrap.classList.add("fp-pop");
  }

  say(text, ms) {
    if (this.bubbleTimer) clearTimeout(this.bubbleTimer);
    this.bubbleText.textContent = text;
    this.bubbleEl.hidden = false;
    this.bubbleTimer = this.later(ms, () => {
      this.bubbleTimer = null;
      this.bubbleEl.hidden = true;
    });
  }

  spawnParticles(x, y, crit, delta) {
    const count = crit ? 12 : 7;
    for (let i = 0; i < count; i += 1) {
      const heart = document.createElement("span");
      heart.className = crit ? "fp-heart-p fp-gold" : "fp-heart-p";
      heart.textContent = Math.random() < 0.3 ? "★" : "♥";
      heart.style.left = (x === undefined ? this.currentLeft() + WRAP_W / 2 : x) + "px";
      heart.style.top = (y === undefined ? this.currentTop() + 56 : y) + "px";
      heart.style.setProperty("--dx", Math.round(rand(-70, 70)) + "px");
      heart.style.setProperty("--dy", Math.round(rand(-130, -30)) + "px");
      heart.style.fontSize = Math.round(rand(12, crit ? 22 : 18)) + "px";
      heart.style.animationDuration = rand(0.9, 1.4).toFixed(2) + "s";
      heart.style.animationDelay = rand(0, 0.12).toFixed(2) + "s";
      this.particlesEl.appendChild(heart);
      this.later(1600, () => heart.remove());
    }
    const float = document.createElement("span");
    float.className = "fp-float-p";
    float.textContent = "+" + delta;
    float.style.left = (x === undefined ? this.currentLeft() + WRAP_W / 2 : x) + "px";
    float.style.top = (y === undefined ? this.currentTop() + 40 : y - 10) + "px";
    float.style.setProperty("--dx", "0px");
    float.style.setProperty("--dy", "-46px");
    this.particlesEl.appendChild(float);
    this.later(1400, () => float.remove());
  }

  burst(x, y, count, gold) {
    for (let i = 0; i < count; i += 1) {
      const heart = document.createElement("span");
      heart.className = gold ? "fp-heart-p fp-gold" : "fp-heart-p";
      heart.textContent = "♥";
      const angle = rand(0, Math.PI * 2);
      const distance = rand(46, 110);
      heart.style.left = x + "px";
      heart.style.top = y + "px";
      heart.style.setProperty("--dx", Math.round(Math.cos(angle) * distance) + "px");
      heart.style.setProperty("--dy", Math.round(Math.sin(angle) * distance - 46) + "px");
      heart.style.fontSize = Math.round(rand(13, 20)) + "px";
      heart.style.animationDuration = rand(0.9, 1.5).toFixed(2) + "s";
      heart.style.animationDelay = rand(0, 0.2).toFixed(2) + "s";
      this.particlesEl.appendChild(heart);
      this.later(1800, () => heart.remove());
    }
  }

  scheduleIdleMotion() {
    this.later(rand(9000, 19000), () => {
      const roll = Math.random();
      if (roll < 0.35) {
        this.wrap.classList.add("fp-hop");
        this.later(650, () => this.wrap.classList.remove("fp-hop"));
      } else if (roll < 0.6) {
        this.wrap.classList.add("fp-wiggle");
        this.later(750, () => this.wrap.classList.remove("fp-wiggle"));
      } else {
        this.flashShocked(950);
      }
      this.scheduleIdleMotion();
    });
  }

  scheduleIdleLine() {
    this.later(rand(26000, 46000), () => {
      if (Date.now() - this.lastPetAt > 9000 && !this.menuOpen && this.wrap.style.display !== "none") {
        this.say(pick(IDLE_LINES), 4500);
      }
      this.scheduleIdleLine();
    });
  }

  /* ---------- 菜单 ---------- */

  toggleMenu() {
    if (this.menuOpen) this.closeMenu();
    else this.openMenu();
  }

  openMenu() {
    this.menuOpen = true;
    this.menuEl.hidden = false;
    this.compactBtn.textContent = this.state.compact ? "展开好感条" : "收起好感条";
    if (this.bubbleTimer) clearTimeout(this.bubbleTimer);
    this.bubbleEl.hidden = true;
  }

  closeMenu() {
    this.menuOpen = false;
    this.menuEl.hidden = true;
  }

  handleReset() {
    if (!this.resetArmed) {
      this.resetArmed = true;
      this.say("要清零和芙芙的羁绊吗？再点一次「重置」确认（10 秒内有效）", 6000);
      if (this.resetArmTimer) clearTimeout(this.resetArmTimer);
      this.resetArmTimer = this.later(10000, () => {
        this.resetArmed = false;
        this.resetArmTimer = null;
      });
      return;
    }
    this.resetArmed = false;
    if (this.resetArmTimer) clearTimeout(this.resetArmTimer);
    this.resetArmTimer = null;
    this.state.affection = 0;
    saveState(this.state);
    this.renderBar();
    this.closeMenu();
    this.say("好感度已重置。让我们重新认识一次吧~", 4200);
  }

  handleCompactToggle() {
    this.setCompact(!this.state.compact);
    this.closeMenu();
  }

  setCompact(compact) {
    this.state.compact = !!compact;
    this.wrap.classList.toggle("fp-compact", this.state.compact);
    saveState(this.state);
  }

  hide() {
    this.closeMenu();
    this.wrap.style.display = "none";
    this.restoreEl.hidden = false;
  }

  show() {
    this.wrap.style.display = "";
    this.restoreEl.hidden = true;
  }
}

/* ---------- 插件入口 ---------- */

function makeStyle() {
  const style = document.createElement("style");
  style.dataset.plugin = PLUGIN_ID;
  style.textContent = CSS_TEXT;
  return style;
}

function apply(ctx) {
  const style = makeStyle();
  document.head.appendChild(style);
  const root = document.createElement("div");
  root.className = "fp-root";
  root.dataset.plugin = PLUGIN_ID;
  document.body.appendChild(root);
  const pet = new FurinaPet(root);
  pet.start();
  ctx.effect(() => () => {
    pet.stop();
    root.remove();
    style.remove();
  });
}

/* 构建脚本（build/build.mjs）会把本文件包装进 window.__ModuleLoader__.load，
 * 并在末尾追加：exports.apply = apply; return module.exports; */
