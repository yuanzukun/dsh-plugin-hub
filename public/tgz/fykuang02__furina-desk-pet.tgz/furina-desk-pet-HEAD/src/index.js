/**
 * Host half of the Furina desk pet plugin. Browser-only: provides no
 * host-side behavior. Built to lib/index.js by build/build.mjs.
 */
export function apply() {}
