import type { LevelDraft } from './types'

export interface OpenRouterRecord {
  id: string
  name: string
  contextWindow?: number
  maxTokens?: number
  modalities?: string[]
  efforts?: string[]
  defaultEffort?: string
  mandatory: boolean
  tokens: string[]
  version?: string
  created: number
}
export interface MatchResult {
  model: OpenRouterRecord
  score: number
  hits: string[]
  confidence: '精确' | '高' | '中' | '低'
  auto: boolean
}
export interface EffortMapping { levels: LevelDraft[]; unknown: string[]; conflicts: string[] }
export const OPENROUTER_URL = 'https://openrouter.ai/api/v1/models'
const CACHE = 'dshModelCapabilities.openrouter.v3'
const TTL = 6 * 60 * 60 * 1000

// 保留原始 token 顺序。版本号仅合并数字间的点或短横线，不把四位日期当小版本。
export function tokenize(value: string): string[] {
  const normalized = value.toLowerCase().replace(/(\d+)-(\d{1,2})(?!\d)/g, '$1.$2')
  return [...new Set(normalized.match(/[a-z]+|\d+(?:\.\d+)?/g) ?? [])]
}
function versionOf(tokens: readonly string[]): string | undefined {
  return tokens.find(token => /^\d+(\.\d+)?$/.test(token) && (token.includes('.') || token.length < 4))
}
function positive(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isSafeInteger(value) && value > 0 ? value : undefined
}
function object(value: unknown): Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {}
}
function strings(value: unknown): string[] | undefined {
  return Array.isArray(value) ? [...new Set(value.filter((item): item is string => typeof item === 'string' && item.trim() !== '').map(item => item.trim()))] : undefined
}
export function prepareModels(raw: unknown): OpenRouterRecord[] {
  if (!Array.isArray(raw)) throw new Error('OpenRouter 返回的目录格式无效')
  return raw.flatMap(value => {
    const item = object(value)
    const id = typeof item.id === 'string' ? item.id : ''
    if (!id) return []
    const reasoning = object(item.reasoning)
    const architecture = object(item.architecture)
    const provider = object(item.top_provider)
    const tokens = tokenize(id.split('/').at(-1) ?? id)
    return [{
      id, name: typeof item.name === 'string' ? item.name : id,
      contextWindow: positive(item.context_length), maxTokens: positive(provider.max_completion_tokens),
      modalities: strings(architecture.input_modalities), efforts: strings(reasoning.supported_efforts),
      defaultEffort: typeof reasoning.default_effort === 'string' ? reasoning.default_effort : undefined,
      mandatory: reasoning.mandatory === true, tokens, version: versionOf(tokens),
      created: typeof item.created === 'number' ? item.created : 0,
    }]
  })
}
export interface CatalogResult { models: OpenRouterRecord[]; cached: boolean; stale?: boolean; updatedAt: number }
let inFlight: Promise<CatalogResult> | undefined
async function fetchCatalog(force: boolean): Promise<CatalogResult> {
  let cached: { at: number; models: OpenRouterRecord[] } | undefined
  try {
    const value = JSON.parse(localStorage.getItem(CACHE) ?? 'null')
    if (typeof value?.at === 'number') cached = { at: value.at, models: prepareModels(value.data) }
  } catch { /* 损坏或禁用的浏览器缓存不影响联网获取。 */ }
  if (!force && cached && Date.now() - cached.at >= 0 && Date.now() - cached.at < TTL) {
    return { models: cached.models, updatedAt: cached.at, cached: true }
  }
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 15000)
  try {
    // 只读取公开目录，不携带路由密钥、Cookie，也不发送本地模型名称。
    const response = await fetch(OPENROUTER_URL, { credentials: 'omit', signal: controller.signal, headers: { Accept: 'application/json' } })
    if (!response.ok) throw new Error(`目录请求失败（HTTP ${response.status}）`)
    const body = object(await response.json())
    const models = prepareModels(body.data)
    if (!models.length) throw new Error('OpenRouter 返回空目录')
    const updatedAt = Date.now()
    try { localStorage.setItem(CACHE, JSON.stringify({ at: updatedAt, data: body.data })) } catch { /* 配额不足时继续使用内存目录。 */ }
    return { models, updatedAt, cached: false }
  } catch (error) {
    if (cached?.models.length) return { models: cached.models, updatedAt: cached.at, cached: true, stale: true }
    throw error
  } finally { clearTimeout(timeout) }
}
export function loadOpenRouter(force = false): Promise<CatalogResult> {
  // 一次整目录请求供所有模型复用，避免批量匹配重复请求。
  if (!inFlight) inFlight = fetchCatalog(force).finally(() => { inFlight = undefined })
  return inFlight
}
function matchToken(query: string, model: OpenRouterRecord): number {
  if (/^\d/.test(query)) {
    if (model.tokens.includes(query)) return 1
    if (model.version?.split('.')[0] === query.split('.')[0]) return 0.3
    return 0
  }
  return model.tokens.includes(query) ? 1 : 0
}
function sameTokens(a: readonly string[], b: readonly string[]): boolean {
  return a.length === b.length && a.every(token => b.includes(token))
}
const GENERIC = new Set(['model', 'models', 'latest', 'preview', 'auto', 'router', 'v', 'it', 'pro', 'mini', 'flash', 'image', 'text', 'thinking', 'high', 'low', 'max', 'code'])
export function searchOpenRouter(models: readonly OpenRouterRecord[], query: string): MatchResult[] {
  if (!query.trim()) return []
  const queryTokens = tokenize(query)
  const queryVersion = versionOf(queryTokens)
  const df = new Map(queryTokens.map(token => [token, models.reduce((count, model) => count + (matchToken(token, model) === 1 ? 1 : 0), 0)]))
  // 生僻前缀仍然消音，但不能只靠 v1 / preview 等通用词自动认领一个模型。
  const known = queryTokens.filter(token => df.get(token))
  const ranked = models.flatMap(model => {
    const exactID = model.id.toLowerCase() === query.trim().toLowerCase()
    const exactSlug = (model.id.split('/').at(-1) ?? '').toLowerCase() === query.trim().toLowerCase()
    if (model.id.includes(':') && !exactID && !exactSlug) return []
    let score = 0
    const hits: string[] = []
    for (const token of queryTokens) {
      const frequency = df.get(token) ?? 0
      if (!frequency) continue
      const weight = matchToken(token, model)
      if (weight > 0) { score += Math.log((models.length + 1) / frequency) * weight; hits.push(token) }
    }
    const exact = exactID || exactSlug
    if (!exact && queryTokens.length > 1 && hits.length < 2) return []
    if (!exact && !hits.some(token => /^[a-z]+$/.test(token) && !GENERIC.has(token))) return []
    if (!exact && score <= 0) return []
    const versionOK = !queryVersion || model.version === queryVersion
    const tokenExact = sameTokens(known, model.tokens)
    const safe = exact || (versionOK && tokenExact && hits.length >= 2)
    const confidence: MatchResult['confidence'] = exact ? '精确' : safe ? '高' : score >= 2.5 ? '中' : '低'
    return [{ model, score, hits, confidence, auto: safe, exact: exactID ? 2 : exactSlug ? 1 : 0 }]
  })
  ranked.sort((a, b) => b.exact - a.exact || Number(b.auto) - Number(a.auto) || b.hits.length - a.hits.length || b.score - a.score || b.model.created - a.model.created || a.model.id.localeCompare(b.model.id))
  // 同一别名指向多个厂商或版本时，不凭较新的发布日期替用户拍板。
  if (ranked.length > 1 && ranked[0].exact !== 2 && ranked[1].auto && ranked[0].exact === ranked[1].exact) {
    ranked[0].auto = false
  }
  return ranked.slice(0, 6)
}

const KNOWN_LEVELS = new Set(['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'])
export function mapEfforts(efforts: readonly string[], mandatory: boolean): EffortMapping {
  const levels: LevelDraft[] = [], unknown: string[] = [], conflicts: string[] = []
  for (const raw of efforts) {
    const wire = raw.trim()
    const id = wire.toLowerCase()
    // 仅处理已明确约定的 UI 别名，绝不靠数组位置或“ultra 看起来很强”推断。
    const level = id === 'none' ? 'off' : id === 'extra' ? 'xhigh' : id
    if (!KNOWN_LEVELS.has(level)) { unknown.push(wire); continue }
    if (mandatory && level === 'off') { conflicts.push(wire); continue }
    const exists = levels.find(item => item.level === level)
    if (exists && exists.wire !== wire) { conflicts.push(wire); continue }
    if (!exists) levels.push({ level, wire })
  }
  return { levels, unknown, conflicts }
}
