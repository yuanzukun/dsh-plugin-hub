import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react'
import type { ModelDraft } from './types'
import { buildBatchOps, buildRows, changedFields, draftFrom, messageOf, type ModelRow } from './model'
import { loadOpenRouter, searchOpenRouter, type MatchResult, type OpenRouterRecord } from './openrouter'
import { applyFields, fillMissing, makeAutoDraft, metadataSuggestion, rebaseDraft, type DraftRecord } from './suggestions'
import type { CapabilityStore } from './store'

const AUTO_HISTORY = 'dshModelCapabilities.autoSeen.v1'
const BULK_HISTORY = 'dshModelCapabilities.bulkApplied.v1'
function readBulkHistory(): Set<string> {
  try {
    const value = JSON.parse(localStorage.getItem(BULK_HISTORY) ?? '[]')
    return new Set(Array.isArray(value) ? value.filter(item => typeof item === 'string') : [])
  } catch { return new Set() }
}
function rememberBulkHistory(seen: Set<string>): void {
  try { localStorage.setItem(BULK_HISTORY, JSON.stringify([...seen])) } catch { /* 存储挂了也至少在本次会话记得。 */ }
}
function readAutoHistory(): Set<string> {
  try {
    const value = JSON.parse(localStorage.getItem(AUTO_HISTORY) ?? '[]')
    return new Set(Array.isArray(value) ? value.filter(item => typeof item === 'string') : [])
  } catch { return new Set() }
}
function rememberAutoHistory(seen: Set<string>): void {
  try { localStorage.setItem(AUTO_HISTORY, JSON.stringify([...seen])) } catch { /* 浏览器禁用存储时仅在本次页面内记忆。 */ }
}
interface CatalogState {
  status: 'loading' | 'ready' | 'error'
  models: OpenRouterRecord[]
  stale: boolean
  updatedAt?: number
  error?: string
}
export function useCatalog() {
  const [catalog, setCatalog] = useState<CatalogState>({ status: 'loading', models: [], stale: false })
  const sequence = useRef(0)
  const load = useCallback(async (force: boolean) => {
    const current = ++sequence.current
    setCatalog(previous => ({ ...previous, status: 'loading', error: undefined }))
    try {
      const result = await loadOpenRouter(force)
      if (sequence.current === current) setCatalog({ status: 'ready', models: result.models, stale: result.stale === true, updatedAt: result.updatedAt })
    } catch (error) {
      if (sequence.current === current) setCatalog(previous => ({ ...previous, status: 'error', error: messageOf(error) }))
    }
  }, [])
  useEffect(() => { void load(false); return () => { ++sequence.current } }, [load])
  return { catalog, refreshCatalog: () => void load(true) }
}

interface DraftState { revision: number | null; records: Record<string, DraftRecord> }

export function useWorkspace(store: CapabilityStore, catalog: CatalogState) {
  const snapshot = useSyncExternalStore(store.subscribe, store.getSnapshot)
  const rows = useMemo(() => buildRows(snapshot), [snapshot])
  const [state, setState] = useState<DraftState>({ revision: null, records: {} })
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null)
  /** 一键预设进行中：防止重复触发，跑完自动解锁。 */
  const [bulkApplying, setBulkApplying] = useState(false)
  /** 已经批量应用过的 key 集：跳过它们，避免二次覆盖用户在详情页手调过的成果。 */
  const bulkSeen = useRef<Set<string>>(readBulkHistory())
  const mounted = useRef(true)
  const saving = useRef(false)
  const autoHandled = useRef<Set<string>>(readAutoHistory())
  useEffect(() => {
    mounted.current = true
    return () => { mounted.current = false }
  }, [])
  useEffect(() => { if (snapshot.status === 'idle') void store.load() }, [snapshot.status, store])

  // 目录只在「快速预设」里用于搜索；自动填一次只在进入新模型详情时发生，避免后台批量改动。
  const lookup = useCallback((query: string): MatchResult[] => searchOpenRouter(catalog.models, query), [catalog.models])

  const records = state.records
  const pending = Object.values(records).filter(record => changedFields(record.draft, record.row.baseline).length > 0)
  const orphaned = pending.filter(record => !rows.some(row => row.key === record.row.key))
  const conflict = pending.length > 0 && (state.revision !== snapshot.revision || orphaned.length > 0)

  useEffect(() => {
    if (!pending.length) return
    const warn = (event: BeforeUnloadEvent) => { event.preventDefault(); event.returnValue = '' }
    window.addEventListener('beforeunload', warn)
    return () => window.removeEventListener('beforeunload', warn)
  }, [pending.length])

  const getDraft = useCallback((key: string): DraftRecord | undefined => records[key], [records])

  const setDraft = useCallback((row: ModelRow, draft: ModelDraft, matchedModel?: string) => {
    autoHandled.current.add(row.key)
    rememberAutoHistory(autoHandled.current)
    setState(previous => {
      const records = { ...previous.records }
      const originalRow = records[row.key]?.row ?? row
      if (changedFields(draft, originalRow.baseline).length === 0) delete records[row.key]
      else records[row.key] = { row: originalRow, draft, source: 'manual', matchedModel: matchedModel ?? records[row.key]?.matchedModel }
      return { revision: Object.keys(records).length ? previous.revision ?? snapshot.revision : null, records }
    })
  }, [snapshot.revision])

  /**
   * 进入详情页：只在「这个模型还没有已保存的任何能力字段」、且本次会话没碰过它时，自动填一次初始值。
   *
   * 「没保存过能力」按模型的实际 baseline / configured 是否为空判断：
   * 不看 row.overridden——它表达的是「整条路由有没有手写列表」，
   * 跟「这个模型有没有人改过它的能力」是两回事。
   */
  const ensureDraft = useCallback((row: ModelRow): DraftRecord | undefined => {
    const held = records[row.key]
    if (held) return held
    if (catalog.status !== 'ready' || autoHandled.current.has(row.key)) return undefined
    const saved = row.baseline ?? row.configured
    if (saved && (saved.contextWindow !== undefined || saved.maxTokens !== undefined || saved.input !== undefined || saved.reasoningEfforts !== undefined)) {
      // 任何一种能力字段已经保存过，这个模型就是「老模型」，别再替它填。
      return undefined
    }
    const result = lookup(row.model.id)?.[0]
    if (!result?.auto) return undefined
    autoHandled.current.add(row.key)
    rememberAutoHistory(autoHandled.current)
    const record = makeAutoDraft(row, result.model)
    if (!record) return undefined
    setState(previous => ({ revision: previous.revision ?? snapshot.revision, records: { ...previous.records, [row.key]: record } }))
    return record
  }, [records, catalog.status, lookup, snapshot.revision])

  /**
   * 快速预设：手动从目录里挑一个模型，把它的全部可映射字段套用到当前草稿。
   *
   * 采纳是覆盖语义：用户专门搜过这个模型、点了「采纳」，就是要把目录里这套
   * 上下文 / 最大输出 / 输入类型 / 思考映射全用过来。notice 只说发生了什么、
   * 用户接下来一步要干嘛；建议层的警告（尚未映射、字段冲突等）用户无能修改，
   * 不写进 UI，避免给人看他们管不了的事。
   */
  const applyPreset = useCallback((row: ModelRow, result: MatchResult) => {
    const held = records[row.key]
    const originalRow = held?.row ?? row
    const current = held?.draft ?? draftFrom(row.baseline)
    const suggestion = metadataSuggestion(result.model, row.supportedLevels)
    if (suggestion.warnings.length) console.debug('[dsh-model-capabilities] preset warnings', suggestion.warnings)
    const next = applyFields(current, suggestion.values)
    setDraft(originalRow, next, result.model.id)
    setNotice({ kind: 'ok', text: `已把「${result.model.id}」的预设值填进草稿。` })
  }, [records, setDraft])

  const discard = useCallback((key: string) => {
    setState(previous => {
      const records = { ...previous.records }
      delete records[key]
      return { revision: Object.keys(records).length ? previous.revision : null, records }
    })
    setNotice(null)
  }, [])

  const reload = useCallback(async () => {
    if (saving.current) return
    saving.current = true
    setBusy(true)
    try {
      await store.load()
      const latest = store.getSnapshot()
      if (latest.error) throw new Error(latest.error)
      const latestRows = new Map(buildRows(latest).map(row => [row.key, row]))
      if (!mounted.current) return
      setState(previous => ({
        revision: latest.revision,
        records: Object.fromEntries(Object.entries(previous.records).map(([key, record]) => [key, latestRows.has(key) ? rebaseDraft(record, latestRows.get(key)!) : record])),
      }))
      setNotice({ kind: 'ok', text: '已加载最新设置，未保存的草稿按字段保留。' })
    } catch (error) { if (mounted.current) setNotice({ kind: 'error', text: messageOf(error) }) }
    finally { saving.current = false; if (mounted.current) setBusy(false) }
  }, [store])

  /**
   * 一键预设：把所有"继承上游"的模型一次性配好。
   *
   * 范围限定得很死：
   * - 只动 `hasOverride === false` 的行  → 用户在详情页手调过的（已写成 override）不碰
   * - 只动 `bulkSeen.current` 里没记过的行 → 以前点过一次一键的不能再被覆盖
   * - 只动 `row.auto.matched === true` 的行 → 目录里有信心能匹配上才写，没匹配到就跳过
   *
   * 每次 patch 前都先 `await store.load()`：多头操作期间 revision 会被反复更新，
   * 用上一次的 revision 直接喂下一次 patch 会 409。
   */
  const applyPresetToAll = useCallback(async () => {
    if (catalog.status !== 'ready' || bulkApplying) return
    if (!snapshot.writable) {
      setNotice({ kind: 'error', text: '设置只读，无法批量应用预设' })
      return
    }
    setBulkApplying(true)
    setNotice(null)
    try {
      // 拽最新：让 store.snapshot.revision 跟服务端同步
      await store.load()
      const latest = store.getSnapshot()
      const latestRows = buildRows(latest)
      const applied: Array<{ rowKey: string; displayName: string }> = []
      const skipped: Array<{ rowKey: string; displayName: string; reason: string }> = []

      for (const row of latestRows) {
        if (row.overridden) { continue }
        if (!row.baseline) { continue }
        if (bulkSeen.current.has(row.key)) { continue }
        const match = lookup(row.model.id)?.[0]
        if (!match?.auto) {
          skipped.push({ rowKey: row.key, displayName: row.displayName || row.model.id, reason: 'OpenRouter 目录里没有明确对应条目' })
          continue
        }
        // 跟单个「采纳」走同一覆盖语义：把 baseline 覆盖成 OpenRouter 数据。
        // metadataSuggestion 的 values 是 partial——只塞有把握的字段；reasoning 在
        // unknown wire/冲突时不给 values.reasoning，由后续的 changedFields 判断是否
        // 不动 baseline 里的 reasoning。
        const suggestion = metadataSuggestion(match.model, row.supportedLevels)
        if (suggestion.warnings.length) console.debug(`[bulk-preset] ${row.model.id}:`, suggestion.warnings)
        const next = applyFields(draftFrom(row.baseline), suggestion.values)
        const pseudoRecord = { row, draft: next }
        const ops = buildBatchOps([pseudoRecord])
        if (!ops.length) {
          skipped.push({ rowKey: row.key, displayName: row.displayName || row.model.id, reason: '目录数据生成不了任何能力变化' })
          continue
        }
        try {
          // 每个 patch 用上一次 patch 拿到的新 revision（store.set 在 save 里已经同步到 snapshot）
          await store.save(ops, store.getSnapshot().revision)
          applied.push({ rowKey: row.key, displayName: row.displayName || row.model.id })
          bulkSeen.current.add(row.key)
        } catch (error) {
          skipped.push({ rowKey: row.key, displayName: row.displayName || row.model.id, reason: messageOf(error) })
        }
      }
      rememberBulkHistory(bulkSeen.current)

      // 把所有还没保存的本地草稿废弃掉，避免 UI  retained 的 draft 跟新写下的覆盖冲突
      setState(previous => ({ revision: store.getSnapshot().revision, records: {} }))
      setNotice({
        kind: skipped.length ? 'error' : 'ok',
        text: `预设写入完成：成功 ${applied.length} 个` + (skipped.length ? `，跳过 ${skipped.length} 个（${skipped.slice(0, 3).map(s => s.displayName).join('、')}${skipped.length > 3 ? ` 等 ${skipped.length} 个` : ''}）` : ''),
      })
    } catch (error) {
      setNotice({ kind: 'error', text: messageOf(error) })
    } finally {
      setBulkApplying(false)
    }
  }, [catalog.status, bulkApplying, lookup, snapshot.writable, store])

  const save = useCallback(async (key: string): Promise<boolean> => {
    if (saving.current || !snapshot.writable) return false
    const record = records[key]
    if (!record || !changedFields(record.draft, record.row.baseline).length) return false
    if (conflict || state.revision === null) {
      setNotice({ kind: 'error', text: '配置已被其他窗口修改或模型已移除。请加载最新设置，核对草稿后重试。' })
      return false
    }
    saving.current = true
    setBusy(true)
    setNotice(null)
    try {
      const ops = buildBatchOps([{ row: record.row, draft: record.draft }])
      await store.save(ops, state.revision)
      if (!mounted.current) return false
      const latest = store.getSnapshot()
      const latestRows = new Map(buildRows(latest).map(row => [row.key, row]))
      setState(previous => ({
        revision: latest.revision,
        records: Object.fromEntries(Object.entries(previous.records).filter(([recordKey]) => recordKey !== key).map(([recordKey, other]) => [recordKey, latestRows.has(recordKey) ? rebaseDraft(other, latestRows.get(recordKey)!) : other])),
      }))
      setNotice({ kind: 'ok', text: `已保存「${record.row.model.name ?? record.row.model.id}」。` })
      void store.load()
      return true
    } catch (error) {
      if (mounted.current) setNotice({ kind: 'error', text: messageOf(error) })
      return false
    } finally { saving.current = false; if (mounted.current) setBusy(false) }
  }, [conflict, records, snapshot.writable, state.revision, store])

  return { snapshot, rows, pending, orphaned, conflict, busy, notice, getDraft, setDraft, ensureDraft, applyPreset, applyPresetToAll, bulkApplying, discard, reload, save, lookup }
}
