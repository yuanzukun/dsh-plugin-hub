import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react'
import type { ModelDraft } from './types'
import { buildBatchOps, buildRows, changedFields, draftFrom, messageOf, type ModelRow } from './model'
import { loadOpenRouter, searchOpenRouter, type MatchResult, type OpenRouterRecord } from './openrouter'
import { applyFields, fillMissing, makeAutoDraft, metadataSuggestion, rebaseDraft, type DraftRecord } from './suggestions'
import type { CapabilityStore } from './store'

const AUTO_HISTORY = 'dshModelCapabilities.autoSeen.v1'
function readAutoHistory(): Set<string> {
  try {
    const value = JSON.parse(localStorage.getItem(AUTO_HISTORY) ?? '[]')
    return new Set(Array.isArray(value) ? value.filter(item => typeof item === 'string') : [])
  } catch { return new Set() }
}
function rememberAutoHistory(seen: Set<string>): void {
  try { localStorage.setItem(AUTO_HISTORY, JSON.stringify([...seen])) } catch { /* 浏览器禁用存储时仅在本次页面内记忆。 */ }
}
interface CatalogState {
  status: 'loading' | 'ready' | 'error'
  models: OpenRouterRecord[]
  stale: boolean
  updatedAt?: number
  error?: string
}
export function useCatalog() {
  const [catalog, setCatalog] = useState<CatalogState>({ status: 'loading', models: [], stale: false })
  const sequence = useRef(0)
  const load = useCallback(async (force: boolean) => {
    const current = ++sequence.current
    setCatalog(previous => ({ ...previous, status: 'loading', error: undefined }))
    try {
      const result = await loadOpenRouter(force)
      if (sequence.current === current) setCatalog({ status: 'ready', models: result.models, stale: result.stale === true, updatedAt: result.updatedAt })
    } catch (error) {
      if (sequence.current === current) setCatalog(previous => ({ ...previous, status: 'error', error: messageOf(error) }))
    }
  }, [])
  useEffect(() => { void load(false); return () => { ++sequence.current } }, [load])
  return { catalog, refreshCatalog: () => void load(true) }
}
interface DraftState { revision: number | null; records: Record<string, DraftRecord> }
export function useWorkspace(store: CapabilityStore, catalog: CatalogState) {
  const snapshot = useSyncExternalStore(store.subscribe, store.getSnapshot)
  const rows = useMemo(() => buildRows(snapshot), [snapshot])
  const [state, setState] = useState<DraftState>({ revision: null, records: {} })
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null)
  const mounted = useRef(true)
  const saving = useRef(false)
  const autoHandled = useRef<Set<string> | null>(null)
  if (autoHandled.current === null) autoHandled.current = readAutoHistory()
  useEffect(() => {
    mounted.current = true
    return () => { mounted.current = false }
  }, [])
  useEffect(() => { if (snapshot.status === 'idle') void store.load() }, [snapshot.status, store])
  const matches = useMemo(() => Object.fromEntries(rows.map(row => [row.key, searchOpenRouter(catalog.models, row.model.id)])), [rows, catalog.models])
  const pending = Object.values(state.records).filter(record => changedFields(record.draft, record.row.baseline).length > 0)
  useEffect(() => {
    if (!pending.length) return
    const warn = (event: BeforeUnloadEvent) => { event.preventDefault(); event.returnValue = '' }
    window.addEventListener('beforeunload', warn)
    return () => window.removeEventListener('beforeunload', warn)
  }, [pending.length])
  const orphaned = pending.filter(record => !rows.some(row => row.key === record.row.key))
  const conflict = pending.length > 0 && (state.revision !== snapshot.revision || orphaned.length > 0)

  useEffect(() => {
    if (snapshot.status !== 'ready' || !snapshot.writable || snapshot.error || catalog.status !== 'ready' || busy || conflict) return
    const generated: Record<string, DraftRecord> = {}
    for (const row of rows) {
      if (autoHandled.current!.has(row.key) || state.records[row.key]) continue
      const result = matches[row.key]?.[0]
      if (!result?.auto) continue
      autoHandled.current!.add(row.key)
      const record = makeAutoDraft(row, result.model)
      if (record) generated[row.key] = record
    }
    rememberAutoHistory(autoHandled.current!)
    if (Object.keys(generated).length) setState(previous => ({ revision: pending.length ? previous.revision ?? snapshot.revision : snapshot.revision, records: { ...generated, ...previous.records } }))
  }, [rows, matches, state.records, snapshot, catalog.status, busy, conflict])

  const setDraft = (row: ModelRow, draft: ModelDraft, matchedModel?: string) => {
    autoHandled.current!.add(row.key)
    rememberAutoHistory(autoHandled.current!)
    setState(previous => {
      const records = { ...previous.records }
      const originalRow = records[row.key]?.row ?? row
      if (changedFields(draft, originalRow.baseline).length === 0) delete records[row.key]
      else records[row.key] = { row: originalRow, draft, source: 'manual', matchedModel: matchedModel ?? records[row.key]?.matchedModel }
      return { revision: Object.keys(records).length ? pending.length ? previous.revision ?? snapshot.revision : snapshot.revision : null, records }
    })
  }
  const applyMatch = (row: ModelRow, result: MatchResult, replace: boolean) => {
    const held = state.records[row.key]
    const originalRow = held?.row ?? row
    const current = held?.draft ?? draftFrom(row.baseline)
    if (replace && !window.confirm('用这份目录元数据替换当前草稿中已提供的字段？原来的手动值会被替换，仍需点击保存才生效。')) return
    const suggestion = metadataSuggestion(result.model, row.supportedLevels)
    const next = replace ? applyFields(current, suggestion.values) : fillMissing(originalRow, current, suggestion)
    setDraft(originalRow, next, result.model.id)
    setNotice({ kind: 'ok', text: `${replace ? '已替换' : '已补齐'}草稿。目录未提供或需要确认的思考值保持原设置；检查后再保存。` })
  }
  const fillVisible = (visible: readonly ModelRow[]) => {
    const generated: Record<string, DraftRecord> = {}
    for (const row of visible) {
      if (state.records[row.key]) continue
      const result = matches[row.key]?.[0]
      if (!result?.auto) continue
      const record = makeAutoDraft(row, result.model)
      if (record) { generated[row.key] = record; autoHandled.current!.add(row.key) }
    }
    const count = Object.keys(generated).length
    rememberAutoHistory(autoHandled.current!)
    if (count) setState(previous => ({ revision: pending.length ? previous.revision ?? snapshot.revision : snapshot.revision, records: { ...previous.records, ...generated } }))
    setNotice({ kind: 'ok', text: count ? `已生成 ${count} 份草稿；已有配置和草稿不覆盖。` : '没有新的可信空白项可补齐；已有草稿保持不变。' })
  }
  const discard = (key?: string) => {
    setState(previous => {
      const records = { ...previous.records }
      if (key) delete records[key]
      else for (const recordKey of Object.keys(records)) delete records[recordKey]
      return { revision: Object.keys(records).length ? previous.revision : null, records }
    })
    setNotice(null)
  }
  const reload = async () => {
    if (saving.current) return
    if (pending.length && !window.confirm('加载最新配置并保留草稿修改？发生重叠时保留草稿中的字段；保存前请重新核对。')) return
    saving.current = true
    setBusy(true)
    try {
      await store.load()
      const latest = store.getSnapshot()
      if (latest.error) throw new Error(latest.error)
      const latestRows = new Map(buildRows(latest).map(row => [row.key, row]))
      if (!mounted.current) return
      setState(previous => ({ revision: latest.revision, records: Object.fromEntries(Object.entries(previous.records).map(([key, record]) => [key, latestRows.has(key) ? rebaseDraft(record, latestRows.get(key)!) : record])) }))
      setNotice({ kind: 'ok', text: '已加载最新设置并按字段保留草稿。请核对后再保存。' })
    } catch (error) { if (mounted.current) setNotice({ kind: 'error', text: messageOf(error) }) }
    finally { saving.current = false; if (mounted.current) setBusy(false) }
  }
  const save = async (key?: string) => {
    if (saving.current || !snapshot.writable) return
    const selected = key ? pending.filter(record => record.row.key === key) : pending
    if (!selected.length) return
    if (conflict || state.revision === null) { setNotice({ kind: 'error', text: '配置已变更或模型已移除。请加载最新设置，核对草稿后重试。' }); return }
    saving.current = true
    setBusy(true)
    setNotice(null)
    try {
      const ops = buildBatchOps(selected.map(record => ({ row: record.row, draft: record.draft })))
      await store.save(ops, state.revision)
      if (!mounted.current) return
      const savedKeys = new Set(selected.map(record => record.row.key))
      const latest = store.getSnapshot()
      const latestRows = new Map(buildRows(latest).map(row => [row.key, row]))
      setState(previous => ({
        revision: latest.revision,
        records: Object.fromEntries(Object.entries(previous.records).filter(([recordKey]) => !savedKeys.has(recordKey)).map(([recordKey, record]) => [recordKey, latestRows.has(recordKey) ? rebaseDraft(record, latestRows.get(recordKey)!) : record])),
      }))
      setNotice({ kind: 'ok', text: `已保存 ${selected.length} 个模型。其他字段和模型列表保持不变。` })
      void store.load()
    } catch (error) { if (mounted.current) setNotice({ kind: 'error', text: messageOf(error) }) }
    finally { saving.current = false; if (mounted.current) setBusy(false) }
  }
  return { snapshot, rows, matches, records: state.records, pending, orphaned, conflict, busy, notice, setDraft, applyMatch, fillVisible, discard, reload, save }
}
