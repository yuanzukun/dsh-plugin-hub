import type { CapabilitySnapshot, ConfigurableProviderView, ModelDraft, ModelEntry, SettingsNamespaceView, SettingsPathOpView } from './types'

export const DEFAULT_LEVELS = ['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'] as const
export const FIELDS = ['reasoning', 'input', 'contextWindow', 'maxTokens'] as const
export type DraftField = typeof FIELDS[number]
export const FIELD_NAMES: Record<DraftField, string> = { reasoning: '思考强度', input: '输入类型', contextWindow: '上下文窗口', maxTokens: '最大输出 token 数' }

export function keyOf(route: string, id: string): string { return JSON.stringify([route, id]) }
export function messageOf(error: unknown): string { return error instanceof Error ? error.message : String(error) }

export function readPath(value: unknown, path: readonly string[]): unknown {
  let current = value
  for (const key of path) {
    if (current === null || typeof current !== 'object') return undefined
    current = (current as Record<string, unknown>)[key]
  }
  return current
}
function profileAt(value: unknown, path: readonly string[]): Record<string, unknown> {
  const profile = readPath(value, path)
  return profile && typeof profile === 'object' && !Array.isArray(profile) ? profile as Record<string, unknown> : {}
}
export function orderedLevelIds(...sources: readonly string[][]): string[] {
  return [...new Set<string>([...DEFAULT_LEVELS, ...sources.flat()])]
}

export function draftFrom(entry?: ModelEntry): ModelDraft {
  const efforts = entry?.reasoningEfforts
  return {
    reasoning: efforts === undefined ? { mode: 'inherit' } : efforts === false ? { mode: 'none' } : {
      mode: 'custom', levels: orderedLevelIds(Object.keys(efforts)).filter(level => Object.hasOwn(efforts, level)).map(level => ({ level, wire: efforts[level] ?? '' })),
    },
    input: !entry?.input?.length
      ? { inherit: true, text: false, image: false, extra: [] }
      : {
        inherit: false,
        text: entry.input.includes('text'),
        image: entry.input.includes('image'),
        // 保留上游目录里 text / image 之外的模态，编辑时只在末尾保留，不让它们被静默清空。
        extra: entry.input.filter(modality => modality !== 'text' && modality !== 'image'),
      },
    contextWindow: entry?.contextWindow === undefined ? '' : String(entry.contextWindow),
    maxTokens: entry?.maxTokens === undefined ? '' : String(entry.maxTokens),
  }
}

// 空白表示继承；k/m 仅是输入快捷写法，持久化始终为正整数。
export function parseTokens(raw: string): number | undefined {
  const text = raw.trim()
  if (!text) return undefined
  const match = /^(\d+(?:\.\d+)?)\s*([km]?)$/i.exec(text)
  if (!match) throw new Error('请输入正整数，或 128k / 1m（k = 1024）')
  const value = Number(match[1]) * ({ k: 1024, m: 1048576 }[match[2].toLowerCase()] ?? 1)
  if (!Number.isSafeInteger(value) || value <= 0) throw new Error('Token 数必须是安全范围内的正整数')
  return value
}
export function formatTokens(value?: number): string {
  return value === undefined ? '未提供' : value.toLocaleString()
}
export function changedFields(draft: ModelDraft, baseline?: ModelEntry): DraftField[] {
  const original = draftFrom(baseline)
  return FIELDS.filter(field => {
    if (field === 'contextWindow' || field === 'maxTokens') {
      try { return parseTokens(draft[field]) !== parseTokens(original[field]) } catch { return true }
    }
    return JSON.stringify(draft[field]) !== JSON.stringify(original[field])
  })
}
export function validateDraft(draft: ModelDraft, supported: readonly string[] = DEFAULT_LEVELS, baseline?: ModelEntry): string | null {
  for (const field of ['contextWindow', 'maxTokens'] as const) {
    try { parseTokens(draft[field]) } catch (error) { return `${FIELD_NAMES[field]}：${messageOf(error)}` }
  }
  // 不继承时至少要有一种模态；上游认识的 audio / video 等通过 extra 原样保留，
  // 也计入「非空」的兜底——避免把原本只支持 audio 的模型在本页编辑后被静默清空。
  if (!draft.input.inherit && !draft.input.text && !draft.input.image && !draft.input.extra.length) return `${FIELD_NAMES.input}：至少勾选一个，或选择继承上游目录`
  // 只验证变更的推理字段，避免改输入类型时阻断旧配置的未来扩展值。
  if (draft.reasoning.mode === 'custom' && changedFields(draft, baseline).includes('reasoning')) {
    const levels = draft.reasoning.levels
    if (!levels.some(entry => entry.level !== 'off')) return '至少选择一个非 off 选项，或者选择“不支持推理”'
    if (new Set(levels.map(entry => entry.level)).size !== levels.length) return '界面选项不能重复'
    if (levels.some(entry => !supported.includes(entry.level))) return '包含当前宿主未声明的界面选项，请将实际发送值放到支持的选项右侧'
    if (levels.some(entry => entry.level !== 'off' && !entry.wire.trim())) return '非 off 选项必须填写实际发送值；留空不代表同名发送'
  }
  return null
}
function levelsToDict(draft: ModelDraft): Record<string, string | null> | false | undefined {
  if (draft.reasoning.mode === 'inherit') return undefined
  if (draft.reasoning.mode === 'none') return false
  // 保留模型真实拼写，不按强弱猜测、不改名；仅 off 允许 null。
  return Object.fromEntries(draft.reasoning.levels.map(entry => [entry.level, entry.wire.trim() || null]))
}
function fieldValue(field: DraftField, draft: ModelDraft): unknown {
  if (field === 'reasoning') return levelsToDict(draft)
  if (field === 'input') {
    if (draft.input.inherit) return undefined
    // 全不勾选视为非法，validateDraft 已拦截；这里只按勾选还原为模态列表。
    // 上游目录里我们不认识的模态（audio、video 等）原样保留在末尾。
    const owned = [draft.input.text ? 'text' : null, draft.input.image ? 'image' : null].filter((m): m is string => m !== null)
    return [...owned, ...draft.input.extra]
  }
  return parseTokens(draft[field])
}
function storedField(field: DraftField): string { return field === 'reasoning' ? 'reasoningEfforts' : field }

export interface ModelRow {
  key: string
  route: string
  displayName: string
  settingsPath: readonly string[]
  model: ModelEntry
  baseline?: ModelEntry
  listModels: ModelEntry[] | null
  overridden: boolean
  supportedLevels: readonly string[]
  configured?: ModelEntry
  catalogEfforts: readonly string[]
}

// 优先使用宿主 schema 声明的 key，未知结构退回当前已验证的七个 key。
export function schemaLevels(namespace: SettingsNamespaceView | null): string[] {
  let found: string[] | undefined
  const visit = (value: unknown): void => {
    if (found || !value || typeof value !== 'object') return
    const node = value as Record<string, unknown>
    if (node.reasoningEfforts) {
      const literals: string[] = []
      const collect = (v: unknown): void => {
        if (!v || typeof v !== 'object') return
        const n = v as Record<string, unknown>
        if (typeof n.value === 'string' && (n.type === 'const' || n.type === 'literal')) literals.push(n.value)
        for (const child of Object.values(n)) collect(child)
      }
      collect(node.reasoningEfforts)
      if (literals.includes('low') && literals.includes('high')) found = [...new Set(literals)]
    }
    for (const child of Object.values(node)) visit(child)
  }
  visit(namespace?.schema)
  return found ?? [...DEFAULT_LEVELS]
}

export function buildRows(snapshot: CapabilitySnapshot): ModelRow[] {
  const supportedLevels = schemaLevels(snapshot.namespace)
  return snapshot.providers.flatMap(provider => {
    const userProfile = profileAt(snapshot.namespace?.user, provider.settingsPath)
    const profile = profileAt(snapshot.namespace?.value, provider.settingsPath)
    const userModels = Array.isArray(userProfile.models) ? userProfile.models as ModelEntry[] : null
    const inherited = Array.isArray(profile.models) && profile.models.length ? profile.models as ModelEntry[] : null
    const listModels = userModels ?? inherited
    const group = snapshot.groups.find(group => group.id === provider.provider)
    const resolvedOverrides = (profile.modelOverrides ?? {}) as Record<string, ModelEntry>
    const userOverrides = (userProfile.modelOverrides ?? {}) as Record<string, ModelEntry>
    const models = listModels ?? (group?.models ?? []).map(model => ({ id: model.id, name: model.name }))
    return models.map(entry => {
      const userOverride = userOverrides[entry.id]
      const baseline = listModels !== null ? entry : userOverride
      const configured = listModels !== null ? entry : resolvedOverrides[entry.id]
      const effective = { ...entry, ...configured, ...baseline }
      const catalog = group?.models.find(model => model.id === entry.id)
      return {
        key: keyOf(provider.provider, entry.id), route: provider.provider, displayName: provider.displayName,
        settingsPath: provider.settingsPath, model: effective, baseline, listModels, supportedLevels, configured,
        catalogEfforts: catalog?.reasoning?.efforts.map(effort => effort.id) ?? [],
        overridden: listModels !== null ? userModels !== null : userOverride !== undefined,
      }
    })
  })
}

export interface PendingEdit { row: ModelRow; draft: ModelDraft }
export function buildBatchOps(edits: readonly PendingEdit[]): SettingsPathOpView[] {
  const ops: SettingsPathOpView[] = []
  const lists = new Map<string, { path: string[]; models: ModelEntry[] }>()
  for (const { row, draft } of edits) {
    const changed = changedFields(draft, row.baseline)
    if (!changed.length) continue
    const failure = validateDraft(draft, row.supportedLevels, row.baseline)
    if (failure) throw new Error(`${row.model.id}：${failure}`)
    if (row.listModels !== null) {
      let list = lists.get(row.route)
      if (!list) {
        list = { path: [...row.settingsPath, 'models'], models: row.listModels.map(model => ({ ...model })) }
        lists.set(row.route, list)
      }
      const entry = list.models.find(model => model.id === row.model.id)
      if (!entry) throw new Error(`模型 ${row.model.id} 已不在自定义列表中，请刷新`)
      for (const field of changed) {
        const key = storedField(field), value = fieldValue(field, draft)
        if (value === undefined) delete (entry as unknown as Record<string, unknown>)[key]
        else (entry as unknown as Record<string, unknown>)[key] = value
      }
    } else {
      for (const field of changed) {
        const path = [...row.settingsPath, 'modelOverrides', row.model.id, storedField(field)]
        const value = fieldValue(field, draft)
        ops.push(value === undefined ? { op: 'unset', path } : { op: 'set', path, value })
      }
    }
  }
  for (const list of lists.values()) ops.push({ op: 'set', path: list.path, value: list.models })
  return ops
}

export function joinProviderDirectory(registered: readonly { id: string; name: string }[], directory: readonly ConfigurableProviderView[]): ConfigurableProviderView[] {
  const active = new Set(registered.map(provider => provider.id))
  return directory.filter(provider => provider.settingsNs === 'llm-pi-ai').map(provider => ({ ...provider, active: active.has(provider.provider) }))
}
