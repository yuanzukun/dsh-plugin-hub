import { useMemo, useState } from 'react'
import type { ModelDraft, ReasoningDraft } from './types'
import { draftFrom, formatTokens, orderedLevelIds, parseTokens, validateDraft, type ModelRow } from './model'
import { mapEfforts, searchOpenRouter, type MatchResult, type OpenRouterRecord } from './openrouter'
import { metadataSuggestion } from './suggestions'

function Segmented<T extends string>({ value, options, disabled, onChange }: {
  value: T
  options: readonly { value: T; label: string }[]
  disabled: boolean
  onChange: (value: T) => void
}) {
  return <div className="mc-seg" role="group">
    {options.map(option => <button key={option.value} type="button"
      className={`mc-seg-item${value === option.value ? ' is-on' : ''}`}
      aria-pressed={value === option.value} disabled={disabled}
      onClick={() => onChange(option.value)}>{option.label}</button>)}
  </div>
}

function tokenError(value: string): string | undefined {
  try { parseTokens(value); return undefined } catch (error) { return (error as Error).message }
}

export function MetadataMatcher({ row, catalog, disabled, onApply }: {
  row: ModelRow
  catalog: readonly OpenRouterRecord[]
  disabled: boolean
  onApply: (match: MatchResult, replace: boolean) => void
}) {
  const [query, setQuery] = useState(row.model.id)
  const [picked, setPicked] = useState('')
  const results = useMemo(() => searchOpenRouter(catalog, query), [catalog, query])
  const selected = results.find(result => result.model.id === picked) ?? results[0]
  const suggestion = selected ? metadataSuggestion(selected.model, row.supportedLevels) : undefined
  const mapping = selected ? mapEfforts(selected.model.efforts ?? [], selected.model.mandatory) : undefined
  return <section className="mc-section mc-recommendation" aria-label="OpenRouter 元数据匹配">
    <div className="mc-section-title"><span>匹配模型元数据</span><small>OpenRouter 公开目录</small></div>
    <label className="mc-field">
      <span className="mc-label">用模型 ID 或关键词搜索</span>
      <input className="mc-input" type="search" value={query}
        placeholder="例如 anthropic/claude-opus-4.6"
        onChange={event => { setQuery(event.currentTarget.value); setPicked('') }} />
    </label>
    {!results.length ? <p className="mc-hint">没有足够的匹配证据。可以补充模型家族与版本，或手动填写。</p> : <>
      <div className="mc-candidates" style={{ marginTop: 10 }}>
        {results.map(result => <button key={result.model.id} type="button"
          className={`mc-candidate${result.model.id === selected?.model.id ? ' is-top' : ''}`}
          aria-pressed={result.model.id === selected?.model.id} onClick={() => setPicked(result.model.id)}>
          <span className={`mc-confidence${result.auto ? ' high' : ''}`}>{result.confidence}</span>
          <span className="mc-candidate-main"><span className="mc-candidate-id">{result.model.id}</span>
            <span className="mc-candidate-info">{formatTokens(result.model.contextWindow)} 上下文 · {formatTokens(result.model.maxTokens)} 输出</span>
          </span>
        </button>)}
      </div>
      {selected ? <>
        <div className="mc-recommendation-grid">
          <div><strong>{formatTokens(selected.model.contextWindow)}</strong><span>上下文窗口 · token</span></div>
          <div><strong>{formatTokens(selected.model.maxTokens)}</strong><span>最大输出 · token</span></div>
          <div><strong>{selected.model.modalities?.join(' + ') || '未提供'}</strong><span>输入模态</span></div>
          <div><strong>{selected.model.defaultEffort ?? '未提供'}</strong><span>目录默认思考值 · 仅供参考</span></div>
        </div>
        <div className="mc-hint">目录原始思考值</div>
        <div className="mc-raw-values">{selected.model.efforts?.length
          ? selected.model.efforts.map(value => <code key={value}>{value}</code>)
          : <span className="mc-hint">未提供，保留原思考配置，不猜测 low / medium / high。</span>}</div>
        {mapping?.levels.length ? <p className="mc-hint">界面选项 → 发送值：{mapping.levels.map(entry => `${entry.level} → ${entry.wire}`).join(' · ')}</p> : null}
        {selected.model.mandatory ? <p className="mc-hint">目录标记为强制思考；推荐不会生成 off 选项。</p> : null}
        {suggestion?.warnings.map(warning => <div className="mc-alert" key={warning}>{warning}</div>)}
        {!selected.auto ? <p className="mc-hint">此候选需要确认，不会自动填入。置信标记是名称匹配结果，不是官方正确率。</p> : null}
        <div className="mc-detail-actions">
          <button className="mc-button primary small" type="button" disabled={disabled}
            onClick={() => onApply(selected, false)}>补齐空白项</button>
          <button className="mc-button small" type="button" disabled={disabled}
            onClick={() => onApply(selected, true)}>替换为这份元数据</button>
        </div>
        <p className="mc-hint">聚合目录可能与当前接入线路的原生值不同。保存前可以将 xhigh 的发送值修正为 extra；不会按模型家族擅自改名。</p>
      </> : null}
    </>}
  </section>
}

export function ModelEditor({ row, draft, disabled, onChange }: {
  row: ModelRow
  draft: ModelDraft
  disabled: boolean
  onChange: (next: ModelDraft) => void
}) {
  const reasoning = draft.reasoning
  const custom = reasoning.mode === 'custom' ? reasoning.levels : []
  const levels = orderedLevelIds([...row.supportedLevels], custom.map(entry => entry.level))
  const setMode = (mode: ReasoningDraft['mode']) => {
    if (mode !== 'custom') onChange({ ...draft, reasoning: { mode } })
    else {
      const effective = draftFrom(row.model).reasoning
      onChange({ ...draft, reasoning: effective.mode === 'custom' ? effective : { mode: 'custom', levels: [] } })
    }
  }
  const toggle = (level: string) => {
    if (reasoning.mode !== 'custom') return
    const next = custom.some(entry => entry.level === level)
      ? custom.filter(entry => entry.level !== level)
      : [...custom, { level, wire: level === 'off' ? '' : level }]
    onChange({ ...draft, reasoning: { mode: 'custom', levels: next } })
  }
  const setWire = (level: string, wire: string) => {
    if (reasoning.mode !== 'custom') return
    onChange({ ...draft, reasoning: { mode: 'custom', levels: custom.map(entry => entry.level === level ? { ...entry, wire } : entry) } })
  }
  const validation = validateDraft(draft, row.supportedLevels, row.baseline)
  return <>
    <section className="mc-section">
      <div className="mc-section-title"><span>上下文与输出</span><small>保存为正整数</small></div>
      <div className="mc-input-pair">
        {(['contextWindow', 'maxTokens'] as const).map(field => <label className="mc-field" key={field}>
          <span className="mc-label">{field === 'contextWindow' ? '上下文窗口' : '最大输出 token'}</span>
          <input className="mc-input" inputMode="decimal" aria-label={field === 'contextWindow' ? '上下文窗口' : '最大输出 token'} value={draft[field]} disabled={disabled}
            aria-invalid={!!tokenError(draft[field])}
            placeholder={`继承：${formatTokens(row.model[field])}`}
            onChange={event => onChange({ ...draft, [field]: event.currentTarget.value })} />
          {tokenError(draft[field]) ? <span className="mc-inline-error">{tokenError(draft[field])}</span> : null}
        </label>)}
      </div>
      <p className="mc-hint">可输入 128k、1m 或完整数字，k = 1024。留空表示继承；清空已覆盖值后保存会删除该覆盖。</p>
    </section>
    <section className="mc-section">
      <div className="mc-section-title"><span>思考真实值</span><small>reasoningEfforts</small></div>
      <Segmented value={reasoning.mode} disabled={disabled} onChange={setMode} options={[
        { value: 'inherit', label: '继承默认' }, { value: 'none', label: '不支持推理' }, { value: 'custom', label: '自定义真实值' },
      ]} />
      {reasoning.mode === 'custom' ? <>
        <p className="mc-hint">左侧是 DSH 滑块选项，右侧是实际发送值。选中 off 后可填 none；选中 xhigh 后可填 extra。非 off 项不可留空。</p>
        <div className="mc-levels">
          {levels.filter(level => row.supportedLevels.includes(level) || custom.some(entry => entry.level === level)).map(level => {
            const entry = custom.find(item => item.level === level)
            return <div className="mc-level-row" key={level}>
              <label className="mc-level-label"><input type="checkbox" checked={!!entry} disabled={disabled}
                onChange={() => toggle(level)} />{level}</label>
              <input className="mc-wire-input" aria-label={`${level} 实际发送值`} value={entry?.wire ?? ''}
                disabled={disabled || !entry} placeholder={level === 'off' ? '留空 = 不发送参数；可填 none' : '实际发送值，不能留空'}
                onChange={event => setWire(level, event.currentTarget.value)} />
            </div>
          })}
        </div>
      </> : <p className="mc-hint">{reasoning.mode === 'inherit'
        ? `使用宿主默认映射${row.catalogEfforts.length ? `。当前目录选项：${row.catalogEfforts.join('、')}` : '，插件不推测未公开的发送值'}。`
        : '声明模型不支持推理，滑块不再提供思考选项。此项不是 off → none 的同义词。'}</p>}
    </section>
    <section className="mc-section">
      <div className="mc-section-title"><span>图像输入</span><small>保留继承与显式声明</small></div>
      <Segmented value={draft.vision} disabled={disabled} onChange={vision => onChange({ ...draft, vision })} options={[
        { value: 'inherit', label: '继承默认' }, { value: 'yes', label: '支持图像' }, { value: 'no', label: '仅文本' },
      ]} />
      <p className="mc-hint">修改其他字段时，原有 audio / video 等模态保持不变。显式选择支持图像或仅文本时才替换 input。</p>
    </section>
    {validation ? <div className="mc-error" role="alert">{validation}</div> : null}
  </>
}
