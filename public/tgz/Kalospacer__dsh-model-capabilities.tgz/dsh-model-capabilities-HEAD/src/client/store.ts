import type { CapabilitySnapshot, RemoteApi, SettingsPathOpView } from './types'
import { joinProviderDirectory, messageOf } from './model'

export class CapabilityStore {
  private snapshot: CapabilitySnapshot = { status: 'idle', error: null, writable: false, revision: 0, namespace: null, providers: [], groups: [] }
  private readonly listeners = new Set<() => void>()
  private loadSequence = 0
  constructor(private readonly remote: RemoteApi) {}
  getSnapshot = (): CapabilitySnapshot => this.snapshot
  subscribe = (listener: () => void): (() => void) => { this.listeners.add(listener); return () => { this.listeners.delete(listener) } }
  private set(partial: Partial<CapabilitySnapshot>): void {
    this.snapshot = { ...this.snapshot, ...partial }
    for (const listener of this.listeners) listener()
  }
  async load(): Promise<void> {
    const sequence = ++this.loadSequence
    if (this.snapshot.status !== 'ready') this.set({ status: 'loading', error: null })
    try {
      const [settings, registered, declared, catalog] = await Promise.all([
        this.remote.settings.describe(), this.remote.llm.listProviders(),
        this.remote.llm.listConfigurableProviders(), this.remote.session.modelCatalog(),
      ])
      if (sequence !== this.loadSequence) return
      if (!settings.ok) throw new Error(settings.error.message)
      if (!registered.ok) throw new Error(registered.error.message)
      if (!declared.ok) throw new Error(declared.error.message)
      if (!catalog.ok) throw new Error(catalog.error.message)
      const namespace = settings.value.namespaces.find(ns => ns.ns === 'llm-pi-ai') ?? null
      this.set({ status: 'ready', error: null, writable: settings.value.writable && namespace !== null,
        revision: namespace?.revision ?? 0, namespace,
        providers: joinProviderDirectory(registered.value, declared.value), groups: catalog.value.groups })
    } catch (error) {
      if (sequence === this.loadSequence) this.set({ status: this.snapshot.namespace ? 'ready' : 'error', error: messageOf(error) })
    }
  }
  async save(ops: SettingsPathOpView[], expectedRevision: number): Promise<void> {
    if (!this.snapshot.writable) throw new Error('当前设置只读，无法保存')
    // 使用草稿建立时的版本，不使用被推送更新替换后的版本。
    if (expectedRevision !== this.snapshot.revision) throw new Error('设置已被其他窗口修改。草稿已保留，请刷新核对后重试')
    const response = await this.remote.settings.mutate('llm-pi-ai', ops, expectedRevision)
    if (!response.ok) throw new Error(response.error.code === 'settings/conflict'
      ? '设置已被其他窗口修改。草稿已保留，请刷新核对后重试' : response.error.message)
    ++this.loadSequence
    // 保存完成时若已收到更高版本推送，不把宿主快照回滚到较旧回复。
    if (response.value.revision >= this.snapshot.revision) this.set({ revision: response.value.revision, namespace: response.value, error: null })
  }
}
