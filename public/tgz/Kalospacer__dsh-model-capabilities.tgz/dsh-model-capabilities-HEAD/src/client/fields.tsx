import type { ChangeEvent } from 'react'
import type { InputDraft, LevelDraft } from './types'
import { DEFAULT_LEVELS } from './model'

/** 数值输入框：接受纯数字或 128k / 1m 快捷写法，不写格式校验，保存前统一由 parseTokens 把关。 */
export function TokenField(props: {
  label: string
  hint?: string
  /** 展示在原 hint 之下的第二行小字（如自动压缩阈值估算）。 */
  hintBelow?: string | null
  value: string
  disabled?: boolean
  onChange: (value: string) => void
}) {
  return <label className="mc-field">
    <span className="mc-field-label">{props.label}</span>
    <input
      className="mc-input"
      type="text"
      inputMode="numeric"
      placeholder="留空继承上游目录"
      data-field={props.label}
      value={props.value}
      disabled={props.disabled}
      onChange={(event: ChangeEvent<HTMLInputElement>) => props.onChange(event.currentTarget.value)}
    />
    {props.hint ? <span className="mc-field-hint">{props.hint}</span> : null}
    {props.hintBelow ? <span className="mc-field-hint">{props.hintBelow}</span> : null}
  </label>
}

/** 灰色整行只读参考框：摆一个不让改的数字（如上游标称最大输出），给用户对照用。 */
export function ReferenceField(props: {
  label: string
  value: string
}) {
  return <div className="mc-field mc-ref-field">
    <span className="mc-field-label">{props.label}</span>
    <span className="mc-input mc-ref-value">{props.value}</span>
  </div>
}

/** 输入类型：继承复选 + 文本/图片两个模态复选。勾选继承时模态组禁用。 */
export function InputTypeField(props: {
  value: InputDraft
  disabled?: boolean
  onChange: (value: InputDraft) => void
}) {
  const set = (patch: Partial<InputDraft>) => props.onChange({ ...props.value, ...patch })
  return <fieldset className="mc-field mc-fieldset">
    <legend className="mc-field-label">输入类型</legend>
    <label className="mc-check">
      <input
        type="checkbox"
        checked={!props.value.inherit}
        disabled={props.disabled}
        onChange={event => set({ inherit: !event.currentTarget.checked })}
      />
      <span>自定义此模型的输入模态（不勾选则继承上游目录）</span>
    </label>
    <div className="mc-check-group" aria-disabled={props.value.inherit}>
      <label className="mc-check">
        <input
          type="checkbox"
          aria-label="文本"
          checked={props.value.text}
          disabled={props.disabled || props.value.inherit}
          onChange={event => set({ text: event.currentTarget.checked })}
        />
        <span>文本</span>
      </label>
      <label className="mc-check">
        <input
          type="checkbox"
          aria-label="图片"
          checked={props.value.image}
          disabled={props.disabled || props.value.inherit}
          onChange={event => set({ image: event.currentTarget.checked })}
        />
        <span>图片</span>
      </label>
    </div>
    <span className="mc-field-hint">至少需要勾选一个模态，或者留下「自定义」不勾选。</span>
  </fieldset>
}

/** 单行思考映射：DSH 档位 → 实际发送的 wire 值。off 档允许留空（表示不发参数）。 */
function LevelRow(props: {
  level: string
  value: LevelDraft | undefined
  disabled?: boolean
  onChange: (wire: string) => void
  onToggle: (enabled: boolean) => void
}) {
  const { level, value } = props
  const enabled = value !== undefined
  return <div className="mc-level-row" data-level={level}>
    <label className="mc-check mc-level-check">
      <input
        type="checkbox"
        checked={enabled}
        disabled={props.disabled}
        onChange={event => props.onToggle(event.currentTarget.checked)}
      />
      <span className="mc-level-name">{level}</span>
    </label>
    <input
      className="mc-input mc-level-wire"
      type="text"
      placeholder={level === 'off' ? '留空 = 关闭思考（不发参数）' : '填写实际发送值'}
      value={value?.wire ?? ''}
      disabled={props.disabled || !enabled}
      onChange={event => props.onChange(event.currentTarget.value)}
    />
  </div>
}

/** 思考强度区：inherit / none / custom 三种模式 + custom 时的逐档映射。 */
export function ReasoningSection(props: {
  value: { mode: 'inherit' } | { mode: 'none' } | { mode: 'custom'; levels: readonly LevelDraft[] }
  supported: readonly string[]
  disabled?: boolean
  onChange: (value: { mode: 'inherit' } | { mode: 'none' } | { mode: 'custom'; levels: readonly LevelDraft[] }) => void
}) {
  const { value } = props
  const levels = value.mode === 'custom' ? value.levels : []
  const byLevel = new Map(levels.map(item => [item.level, item]))

  const setMode = (mode: 'inherit' | 'none' | 'custom') => {
    if (mode === value.mode) return
    if (mode === 'custom') {
      // 切到自定义时给一个最小可用的空表，避免用户面对零行发呆。
      props.onChange({ mode: 'custom', levels: [{ level: 'medium', wire: '' }] })
    } else props.onChange({ mode })
  }
  const setLevels = (next: readonly LevelDraft[]) => props.onChange({ mode: 'custom', levels: next })
  const toggle = (level: string, enabled: boolean) => {
    if (enabled) setLevels([...levels, { level, wire: level === 'off' ? '' : level }])
    else setLevels(levels.filter(item => item.level !== level))
  }
  const setWire = (level: string, wire: string) => {
    setLevels(levels.map(item => item.level === level ? { ...item, wire } : item))
  }

  return <fieldset className="mc-field mc-fieldset">
    <legend className="mc-field-label">思考强度</legend>
    <div className="mc-segment" role="radiogroup" aria-label="思考强度模式">
      {([
        ['inherit', '继承上游目录'],
        ['none', '不支持思考'],
        ['custom', '自定义映射'],
      ] as const).map(([mode, label]) => <label key={mode} className="mc-segment-item">
        <input
          type="radio"
          name="mc-reasoning-mode"
          checked={value.mode === mode}
          disabled={props.disabled}
          onChange={() => setMode(mode)}
        />
        <span>{label}</span>
      </label>)}
    </div>
    {value.mode === 'custom' ? <div className="mc-levels">
      {(props.supported.length ? props.supported : DEFAULT_LEVELS).map(level => <LevelRow
        key={level}
        level={level}
        value={byLevel.get(level)}
        disabled={props.disabled}
        onToggle={enabled => toggle(level, enabled)}
        onChange={wire => setWire(level, wire)}
      />)}
      <span className="mc-field-hint">勾选哪一档就发送哪一档；off 留空表示完全关闭，其余档位必须填实际发送值。</span>
    </div> : null}
  </fieldset>
}
