import { useEffect, useMemo } from 'react'
import type { ModelDraft } from './types'
import type { ModelRow } from './model'
import { changedFields, draftFrom, formatTokens, parseTokens, validateDraft } from './model'
import { applyFields, type DraftRecord } from './suggestions'
import { estimateCompactionThreshold } from './compaction'
import type { MatchResult, OpenRouterRecord } from './openrouter'
import { QuickPreset } from './preset'
import { InputTypeField, ReasoningSection, ReferenceField, TokenField } from './fields'

/** 边填边算的「自动压缩阈值」只读提示；输入非法时交给 validateDraft 报错，这里直接不显示。 */
function compactionHint(draft: ModelDraft, effectiveContextWindow?: number): string | null {
  // 窗口留空表示继承：用宿主实际生效的窗口估算，跟 DSH 运行时拿到的一致。
  let contextWindow = effectiveContextWindow, maxTokens: number | undefined
  try {
    if (draft.contextWindow.trim()) contextWindow = parseTokens(draft.contextWindow)
    maxTokens = parseTokens(draft.maxTokens)
  } catch { return null }
  if (contextWindow === undefined) return null
  // maxTokens 留空表示继承/不设上限，DSH 按没有预留计算阈值。
  const threshold = estimateCompactionThreshold(contextWindow, maxTokens)
  if (threshold <= 0) return `⚠ 输出上限超过这个窗口能容纳的量，DSH 会直接报错`
  return `自动压缩阈值 ≈ ${formatTokens(threshold)} token：会话里的话攒到这么多，就会被自动压缩`
}

interface CatalogState {
  status: 'loading' | 'ready' | 'error'
  models: OpenRouterRecord[]
  stale: boolean
}

export function ModelDetail(props: {
  row: ModelRow
  record: DraftRecord | undefined
  catalog: CatalogState
  disabled: boolean
  onBack: () => void
  onChange: (draft: ModelDraft) => void
  onApplyPreset: (result: MatchResult) => void
  onSave: () => void
  onDiscard: () => void
  ensureDraft: () => DraftRecord | undefined
  searchPresets: (query: string) => MatchResult[]
}) {
  const { row, record } = props
  const baselineDraft = useMemo(() => draftFrom(row.baseline), [row.baseline])
  const draft = record?.draft ?? baselineDraft
  const dirty = record ? changedFields(record.draft, record.row.baseline).length > 0 : false
  const error = dirty ? validateDraft(draft, row.supportedLevels, record!.row.baseline) : null
  const hint = compactionHint(draft, row.model.contextWindow)
  // 上游理论最大输出：只精确匹配，匹配不到就干脆不摆参考框。
  const referenceMaxTokens = useMemo(() => {
    if (props.catalog.status !== 'ready') return undefined
    const top = props.searchPresets(row.model.id)[0]
    return top?.auto ? top.model.maxTokens : undefined
  }, [props.catalog.status, row.model.id, props.searchPresets])

  // 首次进入新模型详情且还没草稿时，自动填一次初始值。
  // 目录可能还没加载好，所以把 catalog.status 拉进依赖：
  // record 不存在就重试，直到目录 ready、ensureDraft 真正产生草稿、或确认此模型不该填。
  useEffect(() => {
    if (!record) props.ensureDraft()
  }, [row.key, props.catalog.status, record])

  const patch = (values: Partial<ModelDraft>) => props.onChange(applyFields(draft, values))

  return <div className="mc-detail-page">
    <header className="mc-detail-head">
      <div className="mc-detail-head-row">
        <div className="mc-detail-head-text">
          <button type="button" className="mc-back" onClick={props.onBack}>‹ 返回列表</button>
          <h2 className="mc-title">{row.model.name ?? row.model.id}</h2>
          <p className="mc-subtitle">{row.model.id}{row.displayName ? ` · ${row.displayName}` : ''}</p>
        </div>
        {/* 顶部操作区：采纳完预设不用滚到页尾，就地保存或放弃。 */}
        <div className="mc-detail-head-actions">
          <button type="button" className="mc-button" disabled={props.disabled || !dirty} onClick={props.onDiscard}>放弃</button>
          <button type="button" className="mc-button primary" disabled={props.disabled || !dirty || !!error} onClick={props.onSave}>保存</button>
        </div>
      </div>
    </header>

    <QuickPreset
      models={props.catalog.models}
      status={props.catalog.status}
      stale={!!props.catalog.stale}
      disabled={props.disabled}
      // 预填当前模型的 id，让用户进门就能看到目录里有没有对应的预设。
      initialQuery={row.model.id}
      onApply={props.onApplyPreset}
      search={props.searchPresets}
    />

    <div className="mc-form-row">
      <TokenField
        label="上下文窗口"
        hint="token 数，可写 128k / 1m；留空使用上游目录值。"
        value={draft.contextWindow}
        disabled={props.disabled}
        onChange={value => patch({ contextWindow: value })}
      />
      <TokenField
        label="最大输出 token 数"
        hint="token 数，可写 128k / 1m；留空使用上游目录值。"
        hintBelow={hint}
        value={draft.maxTokens}
        disabled={props.disabled}
        onChange={value => patch({ maxTokens: value })}
      />
    </div>

    {referenceMaxTokens !== undefined ? <div className="mc-form-row">
      <ReferenceField label="标称最大输出" value={`${formatTokens(referenceMaxTokens)} token`} />
    </div> : null}

    <div className="mc-form-row">
      <InputTypeField
        value={draft.input}
        disabled={props.disabled}
        onChange={value => patch({ input: value })}
      />
    </div>

    <div className="mc-form-row">
      <ReasoningSection
        value={draft.reasoning}
        supported={row.supportedLevels}
        disabled={props.disabled}
        onChange={value => patch({ reasoning: value })}
      />
    </div>

    {error ? <div className="mc-form-error" role="alert">{error}</div> : null}

    <footer className="mc-detail-actions">
      <button type="button" className="mc-button" disabled={props.disabled || !dirty} onClick={props.onDiscard}>放弃更改</button>
      <button type="button" className="mc-button primary" disabled={props.disabled || !dirty || !!error} onClick={props.onSave}>保存</button>
    </footer>
  </div>
}
