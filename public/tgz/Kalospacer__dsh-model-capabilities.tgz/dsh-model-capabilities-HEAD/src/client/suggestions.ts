import type { ModelDraft } from './types'
import { changedFields, draftFrom, FIELDS, type ModelRow } from './model'
import { mapEfforts, type OpenRouterRecord } from './openrouter'

type DraftValues = { -readonly [K in keyof ModelDraft]?: ModelDraft[K] }

export interface Suggestion {
  values: DraftValues
  warnings: string[]
}

export function metadataSuggestion(model: OpenRouterRecord, supportedLevels: readonly string[]): Suggestion {
  const values: DraftValues = {}, warnings: string[] = []
  if (model.contextWindow !== undefined) values.contextWindow = String(model.contextWindow)
  if (model.maxTokens !== undefined) values.maxTokens = String(model.maxTokens)
  if (model.modalities?.includes('image')) values.vision = 'yes'
  else if (model.modalities?.includes('text')) values.vision = 'no'
  const mapping = mapEfforts(model.efforts ?? [], model.mandatory)
  if (mapping.unknown.length) warnings.push(`尚未映射的真实值：${mapping.unknown.join('、')}。请在右侧选择一个 DSH 选项并填写原值。`)
  if (mapping.conflicts.length) warnings.push(`思考值存在冲突：${mapping.conflicts.join('、')}。请核对源目录与当前接入线路。`)
  const unsupported = mapping.levels.filter(entry => !supportedLevels.includes(entry.level))
  if (unsupported.length) warnings.push(`当前 DSH 未声明这些界面选项：${unsupported.map(entry => entry.level).join('、')}。`)
  if (model.efforts?.length && !mapping.levels.some(entry => entry.level !== 'off')) warnings.push('目录没有提供可用的非关闭思考值，保持原思考设置。')
  if (mapping.levels.some(entry => entry.level !== 'off') && !mapping.unknown.length && !mapping.conflicts.length && !unsupported.length) {
    values.reasoning = { mode: 'custom', levels: mapping.levels }
  }
  return { values, warnings }
}

// 默认补空值，不覆盖手工声明、基础层配置或已经编辑的草稿。
export function fillMissing(row: ModelRow, current: ModelDraft, suggestion: Suggestion): ModelDraft {
  const values: DraftValues = {}
  const configured = row.configured
  if (!configured?.contextWindow && current.contextWindow === '') values.contextWindow = suggestion.values.contextWindow
  if (!configured?.maxTokens && current.maxTokens === '') values.maxTokens = suggestion.values.maxTokens
  if (configured?.input === undefined && current.vision === 'inherit') values.vision = suggestion.values.vision
  if (configured?.reasoningEfforts === undefined && current.reasoning.mode === 'inherit') values.reasoning = suggestion.values.reasoning
  return applyFields(current, values)
}
export function applyFields(draft: ModelDraft, values: DraftValues): ModelDraft {
  const next = { ...draft }
  for (const field of FIELDS) if (values[field] !== undefined) Object.assign(next, { [field]: values[field] })
  return next
}
export interface DraftRecord {
  row: ModelRow
  draft: ModelDraft
  source: 'manual' | 'auto'
  matchedModel?: string
}
export function makeAutoDraft(row: ModelRow, model: OpenRouterRecord): DraftRecord | undefined {
  const suggestion = metadataSuggestion(model, row.supportedLevels)
  const draft = fillMissing(row, draftFrom(row.baseline), suggestion)
  return changedFields(draft, row.baseline).length ? { row, draft, source: 'auto', matchedModel: model.id } : undefined
}

// 显式确认后按字段重放草稿；不会把其他窗口修改过的无关字段覆盖回旧值。
export function rebaseDraft(record: DraftRecord, row: ModelRow): DraftRecord {
  const changed = changedFields(record.draft, record.row.baseline)
  const values: DraftValues = {}
  for (const field of changed) Object.assign(values, { [field]: record.draft[field] })
  return { ...record, row, draft: applyFields(draftFrom(row.baseline), values) }
}
