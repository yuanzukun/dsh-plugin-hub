import { useEffect, useMemo, useState } from 'react'
import type { MatchResult, OpenRouterRecord } from './openrouter'

function describe(model: OpenRouterRecord): string {
  const parts: string[] = []
  if (model.contextWindow) parts.push(`上下文 ${model.contextWindow.toLocaleString()}`)
  if (model.maxTokens) parts.push(`最大输出 ${model.maxTokens.toLocaleString()}`)
  if (model.modalities?.length) parts.push(model.modalities.join(' / '))
  if (model.efforts?.length) parts.push(`${model.efforts.length} 个思考档位`)
  return parts.join(' · ')
}

export function QuickPreset(props: {
  models: readonly OpenRouterRecord[]
  status: 'loading' | 'ready' | 'error'
  stale: boolean
  disabled?: boolean
  /** 进入面板时预填的搜索词（通常是当前模型的 id）。 */
  initialQuery?: string
  onApply: (result: MatchResult) => void
  search: (query: string) => MatchResult[]
}) {
  const [query, setQuery] = useState(props.initialQuery ?? '')
  const [selectedId, setSelectedId] = useState<string | null>(null)

  // 进入这个详情页 / 切到另一个模型时重置搜索词，让用户面对的永远是「当前这个模型」。
  useEffect(() => {
    setQuery(props.initialQuery ?? '')
    setSelectedId(null)
  }, [props.initialQuery])

  const results = useMemo(() => {
    const trimmed = query.trim()
    return trimmed ? props.search(trimmed) : []
  }, [props, query])

  const selected = results.find(item => item.model.id === selectedId) ?? null
  const candidate = selected ?? (results.length === 1 ? results[0] : null)

  return <section className="mc-preset" aria-label="快速预设">
    <h3 className="mc-preset-title">快速预设</h3>
    <p className="mc-preset-desc">从 OpenRouter 公开目录里挑一个模型，把它的能力值整套填进草稿。</p>
    <div className="mc-preset-bar">
      <input
        className="mc-input mc-preset-search"
        type="search"
        placeholder="输入模型名，例如 deepseek-chat 或 glm-4.6…"
        value={query}
        disabled={props.disabled || props.status !== 'ready'}
        onChange={event => { setQuery(event.currentTarget.value); setSelectedId(null) }}
      />
      <button
        type="button"
        className="mc-button"
        disabled={props.disabled || !candidate}
        onClick={() => { if (candidate) props.onApply(candidate) }}
      >采纳此预设</button>
    </div>
    {props.status === 'loading' ? <p className="mc-hint">正在载入 OpenRouter 目录…</p> : null}
    {props.status === 'error' ? <p className="mc-hint">目录不可用，快速预设暂时用不了；手动填写不受影响。</p> : null}
    {props.status === 'ready' && props.stale ? <p className="mc-hint">当前用的是离线缓存，数据可能不是最新。</p> : null}
    {query.trim() && props.status === 'ready' ? <div className="mc-preset-results" role="listbox">
      {results.length ? results.map(item => {
        const active = candidate?.model.id === item.model.id
        return <button
          key={item.model.id}
          type="button"
          role="option"
          aria-selected={active}
          className={`mc-preset-item${active ? ' is-selected' : ''}`}
          onClick={() => setSelectedId(item.model.id)}
        >
          <span className="mc-preset-item-head">
            <strong>{item.model.name}</strong>
            <code>{item.model.id}</code>
          </span>
          <span className="mc-preset-item-desc">{describe(item.model)}</span>
        </button>
      }) : <p className="mc-hint">没有匹配的目录模型。换个更具体的关键词试试。</p>}
    </div> : null}
    {candidate ? <p className="mc-preset-picked">将采纳：<strong>{candidate.model.id}</strong>{candidate.confidence === '精确' || candidate.confidence === '高' ? '' : `（${candidate.confidence}置信度，请确认）`}</p> : null}
  </section>
}
