import { useMemo, useRef, useState } from 'react'
import type { CapabilityStore } from './store'
import type { ModelDraft } from './types'
import { changedFields, draftFrom, FIELD_NAMES, formatTokens, validateDraft, type ModelRow } from './model'
import { MetadataMatcher, ModelEditor } from './editor'
import { useCatalog, useWorkspace } from './workspace'

function draftSummary(row: ModelRow, draft?: ModelDraft): string {
  const reasoning = draft?.reasoning ?? draftFrom(row.model).reasoning
  if (reasoning.mode === 'none') return '不支持推理'
  if (reasoning.mode === 'inherit') return row.catalogEfforts.length ? `目录：${row.catalogEfforts.join(' / ')}` : '思考继承'
  return reasoning.levels.map(entry => `${entry.level} → ${entry.wire || '不发送参数'}`).join(' · ')
}
export function ModelCapabilitiesSection({ store }: { store: CapabilityStore }) {
  const { catalog, refreshCatalog } = useCatalog()
  const work = useWorkspace(store, catalog)
  const [query, setQuery] = useState('')
  const [route, setRoute] = useState('')
  const [selected, setSelected] = useState('')
  const detailRef = useRef<HTMLElement | null>(null)
  const [filter, setFilter] = useState<'all' | 'pending' | 'configured'>('all')
  const routes = useMemo(() => {
    const directory = new Map<string, { id: string; name: string; count: number }>()
    for (const row of work.rows) {
      const held = directory.get(row.route)
      if (held) held.count++
      else directory.set(row.route, { id: row.route, name: row.displayName, count: 1 })
    }
    return [...directory.values()]
  }, [work.rows])
  const visible = work.rows.filter(row => {
    if (route && row.route !== route) return false
    if (query.trim() && !`${row.model.id} ${row.model.name ?? ''} ${row.displayName}`.toLowerCase().includes(query.trim().toLowerCase())) return false
    const record = work.records[row.key]
    if (filter === 'pending') return !!record && changedFields(record.draft, record.row.baseline).length > 0
    if (filter === 'configured') return row.overridden
    return true
  })
  const current = visible.find(row => row.key === selected) ?? visible[0]
  const record = current ? work.records[current.key] : undefined
  const editingRow = record?.row ?? current
  const draft = current ? record?.draft ?? draftFrom(current.baseline) : undefined
  const disabled = !work.snapshot.writable || work.busy
  const invalid = work.pending.some(item => validateDraft(item.draft, item.row.supportedLevels, item.row.baseline) !== null)
  const currentDirty = record && changedFields(record.draft, record.row.baseline).length > 0

  if (work.snapshot.status === 'idle' || work.snapshot.status === 'loading') return <div className="mc-page">
    <div className="mc-loading" role="status">正在加载模型能力配置…<div className="mc-skeleton" /><div className="mc-skeleton" /></div>
  </div>
  if (work.snapshot.status === 'error') return <div className="mc-page">
    <div className="mc-error" role="alert">{work.snapshot.error ?? '模型设置加载失败'}</div>
    <button type="button" className="mc-button" onClick={() => void work.reload()}>重新加载设置</button>
  </div>
  return <div className="mc-page"><div className="mc-shell">
    <header className="mc-hero">
      <div><div className="mc-kicker">模型参数工作区</div><h1 className="mc-title">模型能力</h1>
        <div className="mc-subtitle">新模型可信匹配后自动补齐空白草稿。核对真实发送值，保存后才生效。</div></div>
      <div className="mc-stats">
        <div className="mc-stat"><strong>{work.rows.length}</strong><span>可配置模型</span></div>
        <div className="mc-stat"><strong>{work.pending.length}</strong><span>待保存</span></div>
        <div className="mc-stat"><strong>{catalog.models.length || '—'}</strong><span>目录模型</span></div>
      </div>
    </header>
    <div className="mc-toolbar">
      <input className="mc-search" type="search" aria-label="搜索当前模型" value={query}
        placeholder="搜索名称、ID 或路由…" onChange={event => setQuery(event.currentTarget.value)} />
      <select className="mc-select" aria-label="模型状态筛选" value={filter}
        onChange={event => setFilter(event.currentTarget.value as typeof filter)}>
        <option value="all">全部模型</option><option value="pending">待保存</option><option value="configured">已配置</option>
      </select>
      <button className="mc-button" type="button" disabled={work.busy} onClick={() => void work.reload()}>加载最新设置</button>
      <button className="mc-button" type="button" disabled={catalog.status === 'loading'} onClick={refreshCatalog}>刷新目录</button>
      <button className="mc-button primary" type="button" disabled={disabled || work.conflict || catalog.status !== 'ready'}
        onClick={() => work.fillVisible(visible)}>补齐当前列表空白项</button>
    </div>
    <div className={`mc-catalog-status${catalog.status === 'error' ? ' is-error' : ''}`} role="status">
      {catalog.status === 'loading' ? '正在读取 OpenRouter 公开目录…' : catalog.status === 'error'
        ? `目录不可用：${catalog.error}。手动配置与保存不受影响。`
        : `${catalog.stale ? '正在使用过期缓存，联网失败后仍可参考' : 'OpenRouter 目录已就绪'} · ${catalog.models.length} 个模型 · 缓存 6 小时`}
    </div>
    {!work.snapshot.writable ? <div className="mc-alert">当前设置只读，或没有可编辑的 llm-pi-ai 命名空间。</div> : null}
    {work.snapshot.error ? <div className="mc-error">{work.snapshot.error}。当前显示上次成功读取的配置。</div> : null}
    {work.conflict ? <div className="mc-error" role="alert">
      设置版本已变化，草稿仍然保留。点击“加载最新设置”核对并重新应用草稿，或放弃更改。
      {work.orphaned.length ? ` 其中 ${work.orphaned.length} 个模型已被移除，不能继续保存。` : ''}
    </div> : null}
    <div className="mc-layout">
      <aside className="mc-sidebar" aria-label="配置路由">
        <div className="mc-sidebar-head"><h2>配置路由</h2><p>每条线路独立保存模型能力</p></div>
        <button type="button" className={`mc-route-button${route === '' ? ' is-selected' : ''}`} aria-pressed={route === ''}
          onClick={() => setRoute('')}><span className="mc-route-name">全部路由</span><span className="mc-route-count">{work.rows.length} 个模型</span></button>
        {routes.map(item => <button key={item.id} type="button" className={`mc-route-button${route === item.id ? ' is-selected' : ''}`}
          aria-pressed={route === item.id} onClick={() => setRoute(item.id)}>
          <span className="mc-route-name" title={item.name}>{item.name}</span><span className="mc-route-count">{item.count} 个模型</span>
        </button>)}
      </aside>
      <section className="mc-list" aria-label="模型列表">
        <div className="mc-list-head"><h2>{routes.find(item => item.id === route)?.name ?? '全部模型'}</h2><p>{visible.length} 个模型 · 点击查看发送值与元数据</p></div>
        <div className="mc-model-list">
          {visible.map(row => {
            const held = work.records[row.key]
            const dirty = held && changedFields(held.draft, held.row.baseline).length > 0
            return <div className="mc-model-row" key={row.key}>
              <button className={`mc-model-head${current?.key === row.key ? ' is-selected' : ''}`} type="button"
                aria-pressed={current?.key === row.key} onClick={() => {
                  setSelected(row.key)
                  if (window.innerWidth <= 680) detailRef.current?.scrollIntoView({ block: 'start', behavior: window.matchMedia('(prefers-reduced-motion:reduce)').matches ? 'auto' : 'smooth' })
                }}>
                <span className="mc-model-name"><span>{row.model.name ?? row.model.id}</span><span className="mc-model-id">{row.model.id}</span></span>
                <span className="mc-model-meta">
                  {dirty ? <span className="mc-tag is-dirty">{held?.source === 'auto' ? '自动草稿' : '未保存'}</span>
                    : row.overridden ? <span className="mc-tag is-active">已配置</span> : <span className="mc-tag">继承</span>}
                </span>
              </button>
              <div className="mc-model-summary" title={draftSummary(row, held?.draft)}>
                {draftSummary(row, held?.draft)}
              </div>
            </div>
          })}
          {!visible.length ? <div className="mc-empty">{work.rows.length ? '没有匹配的模型，试试清空搜索或切换筛选。' : '没有可编辑的模型。先在 DSH 的模型设置里添加一条 pi-ai 线路。'}</div> : null}
        </div>
      </section>
      <section ref={detailRef} className="mc-detail" aria-label="模型能力编辑">
        {current && editingRow && draft ? <>
          <div className="mc-detail-head"><h2>{current.model.name ?? current.model.id}</h2><p>{current.model.id} · {current.displayName}</p>
            {record?.matchedModel ? <p className="mc-saved-note">草稿来源：{record.matchedModel} · 可手动修正</p> : null}
            <div className="mc-detail-actions">
              <button className="mc-button small" type="button" disabled={disabled || !currentDirty || work.conflict || !!validateDraft(draft, editingRow.supportedLevels, editingRow.baseline)}
                onClick={() => void work.save(current.key)}>保存此模型</button>
              <button className="mc-button small" type="button" disabled={disabled}
                onClick={() => { if (window.confirm('删除该模型的四项能力覆盖，恢复继承？其他字段保持不变，仍需保存才生效。')) work.setDraft(editingRow, draftFrom()) }}>恢复继承</button>
              <button className="mc-button small" type="button" disabled={work.busy || !record}
                onClick={() => work.discard(current.key)}>撤销此模型草稿</button>
            </div>
          </div>
          <div className="mc-detail-body">
            {catalog.models.length ? <MetadataMatcher key={current.key} row={current} catalog={catalog.models}
              disabled={disabled} onApply={(result, replace) => work.applyMatch(editingRow, result, replace)} />
              : <p className="mc-hint">{catalog.status === 'loading' ? '目录加载后会列出可能的模型与默认值。' : '可以继续手动配置，也可以稍后刷新在线目录。'}</p>}
            <ModelEditor key={current.key} row={editingRow} draft={draft} disabled={disabled}
              onChange={next => work.setDraft(editingRow, next)} />
            <div className="mc-current">当前保存值：上下文 {formatTokens(current.model.contextWindow)} · 输出 {formatTokens(current.model.maxTokens)} · {current.model.input?.includes('image') ? '支持图像' : current.model.input?.length ? '仅文本或其他输入模态' : '模态继承'}</div>
          </div>
        </> : <div className="mc-empty">选择一个模型开始配置。</div>}
      </section>
    </div>
    {work.notice ? <div className={work.notice.kind === 'error' ? 'mc-error' : 'mc-alert'} role="status" aria-live="polite">{work.notice.text}</div> : null}
    {work.pending.length ? <footer className="mc-savebar">
      <span><strong>{work.pending.length}</strong> 个模型待保存 · {work.pending.reduce((total, item) => total + changedFields(item.draft, item.row.baseline).length, 0)} 项字段变更</span>
      <details><summary>查看修改</summary>{work.pending.map(item => <p key={item.row.key}>{item.row.model.id}：{changedFields(item.draft, item.row.baseline).map(field => FIELD_NAMES[field]).join('、')}</p>)}</details>
      <button className="mc-button" type="button" disabled={work.busy} onClick={() => { if (window.confirm('放弃所有未保存草稿？已保存配置不会改变。')) work.discard() }}>放弃更改</button>
      <button className="mc-button primary" type="button" disabled={disabled || work.conflict || invalid} onClick={() => work.save()}>{work.busy ? '保存中…' : '保存全部'}</button>
    </footer> : null}
  </div></div>
}
