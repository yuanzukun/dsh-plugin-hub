import { useState } from 'react'
import { CSS } from './styles'
import type { CapabilityStore } from './store'
import { useCatalog, useWorkspace } from './workspace'
import { ModelList } from './list'
import { ModelDetail } from './detail'
import type { ModelRow } from './model'

export function ModelCapabilitiesSection({ store }: { store: CapabilityStore }) {
  const { catalog, refreshCatalog } = useCatalog()
  const work = useWorkspace(store, catalog)
  const [selectedKey, setSelectedKey] = useState<string | null>(null)
  const [query, setQuery] = useState('')

  const row: ModelRow | null = work.rows.find(item => item.key === selectedKey) ?? null
  const record = row ? work.getDraft(row.key) : undefined
  // disabled 只反映「设置了只读」「正在保存」这类真正阻止编辑的事；不让它兼任加载文案。
  const disabled = !work.snapshot.writable || work.busy

  if (work.snapshot.status === 'idle' || work.snapshot.status === 'loading') {
    return <div className="mc-page"><style>{CSS}</style><div className="mc-loading" role="status">正在加载模型配置…</div></div>
  }
  if (work.snapshot.status === 'error') {
    return <div className="mc-page"><style>{CSS}</style>
      <div className="mc-error" role="alert">{work.snapshot.error ?? '加载失败'}</div>
      <button type="button" className="mc-button" onClick={() => void work.reload()}>重试</button>
    </div>
  }

  if (row) {
    return <div className="mc-page"><style>{CSS}</style>
      <ModelDetail
        row={row}
        record={record}
        catalog={catalog}
        disabled={disabled}
        onBack={() => setSelectedKey(null)}
        onChange={draft => work.setDraft(row, draft)}
        onApplyPreset={result => work.applyPreset(row, result)}
        onSave={() => {
          // 保存成功才跳回列表；revision 冲突或其他失败时留在当前详情页，让用户看到错误提示。
          void work.save(row.key).then(saved => { if (saved) setSelectedKey(null) })
        }}
        onDiscard={() => work.discard(row.key)}
        ensureDraft={() => work.ensureDraft(row)}
        searchPresets={work.lookup}
      />
      {work.notice ? <div className={work.notice.kind === 'error' ? 'mc-error' : 'mc-notice'} role="status">{work.notice.text}</div> : null}
    </div>
  }

  return <div className="mc-page"><style>{CSS}</style>
    <ModelList
      rows={work.rows}
      records={work.rows.reduce<Record<string, NonNullable<ReturnType<typeof work.getDraft>>>>((acc, item) => {
        const draft = work.getDraft(item.key)
        if (draft) acc[item.key] = draft
        return acc
      }, {})}
      query={query}
      onQuery={setQuery}
      onOpen={setSelectedKey}
      onReload={() => void work.reload()}
      onBulkApply={() => void work.applyPresetToAll()}
      bulkApplying={work.bulkApplying}
      catalogReady={catalog.status === 'ready'}
    />
    <footer className="mc-footers">
      {catalog.status === 'loading' ? <p className="mc-footnote">正在后台载入快速预设目录…</p>
        : catalog.status === 'error' ? <p className="mc-footnote">快速预设目录不可用，不影响手动配置。</p>
        : catalog.stale ? <p className="mc-footnote">快速预设当前是离线缓存。<button type="button" className="mc-link" onClick={refreshCatalog}>刷新</button></p>
        : null}
      {work.notice ? <div className={work.notice.kind === 'error' ? 'mc-error' : 'mc-notice'} role="status">{work.notice.text}</div> : null}
      {work.conflict ? <div className="mc-error" role="alert">
        配置在其他地方被改过，未保存的草稿还留着。
        <button type="button" className="mc-link" onClick={() => void work.reload()}>加载最新设置</button>
        {work.orphaned.length ? `（${work.orphaned.length} 个模型已不存在）` : ''}
      </div> : null}
    </footer>
  </div>
}
