// Settings is a native DSH slot: use the live host theme tokens rather than
// obsolete aliases with light-only fallbacks that conflict with dark text colors.
export const CSS = `
.mc-page {
  --mc-bg: var(--dsw-alias-bg-base);
  --mc-panel: var(--dsw-alias-bg-layer-1);
  --mc-ink: var(--dsw-alias-label-primary);
  --mc-muted: var(--dsw-alias-label-secondary);
  --mc-line: var(--dsw-alias-border-l1);
  --mc-focus: var(--dsw-alias-brand-primary);
  --mc-danger: var(--dsw-alias-state-error-primary);
  color: var(--mc-ink);
  background: transparent;
  font: inherit;
  font-size: 13px;
  line-height: 1.5;
  min-height: 100%;
  padding: 20px 24px 56px;
  box-sizing: border-box;
}
.mc-page *, .mc-page *::before, .mc-page *::after { box-sizing: inherit; }
.mc-loading, .mc-error, .mc-notice, .mc-footnote { max-width: 640px; margin: 18px auto; }
.mc-error { color: var(--mc-danger); padding: 10px 12px; border: 1px solid color-mix(in srgb, var(--mc-danger) 28%, transparent); border-radius: 8px; background: color-mix(in srgb, var(--mc-danger) 5%, var(--mc-panel)); }
.mc-notice { color: var(--mc-ink); padding: 10px 12px; border: 1px solid var(--mc-line); border-radius: 8px; background: var(--mc-panel); }
.mc-footnote { color: var(--mc-muted); font-size: 12px; margin-top: 24px; }
.mc-link { background: none; border: none; color: var(--mc-focus); cursor: pointer; padding: 0; font: inherit; text-decoration: underline; }

/* 标题与副标题 */
.mc-title { margin: 0 0 4px; font-size: 20px; font-weight: 600; line-height: 1.25; letter-spacing: -0.01em; }
.mc-subtitle { margin: 0; color: var(--mc-muted); font-size: 13px; }
.mc-back { background: none; border: none; color: var(--mc-focus); cursor: pointer; padding: 0 0 8px; font: inherit; font-size: 13px; }
.mc-back:hover { text-decoration: underline; }

/* 列表页 */
.mc-list-page { max-width: 640px; margin: 0 auto; }
.mc-list-head { margin-bottom: 18px; }
.mc-list-head .mc-list-actions { display: flex; gap: 8px; margin-top: 12px; }
.mc-search { flex: 1; }
.mc-list { list-style: none; margin: 0; padding: 0; border: 1px solid var(--mc-line); border-radius: 10px; background: var(--mc-panel); overflow: hidden; }
.mc-row + .mc-row { border-top: 1px solid var(--mc-line); }
.mc-row.is-dirty { background: color-mix(in srgb, var(--mc-focus) 4%, var(--mc-panel)); }
.mc-row-button {
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
  width: 100%; padding: 12px 16px; background: none; border: none; color: inherit;
  text-align: left; cursor: pointer; font: inherit;
}
.mc-row-button:hover { background: color-mix(in srgb, var(--mc-focus) 3%, var(--mc-panel)); }
.mc-row-main { min-width: 0; flex: 1; }
.mc-row-name { display: block; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.mc-row-summary { display: block; color: var(--mc-muted); font-size: 12px; margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.mc-row-chevron { color: var(--mc-muted); font-size: 20px; line-height: 1; }
.mc-empty { padding: 32px 16px; text-align: center; color: var(--mc-muted); }

/* 详情页骨架 */
.mc-detail-page { max-width: 640px; margin: 0 auto; }
.mc-detail-head { margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid var(--mc-line); }
.mc-detail-head-row { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; }
.mc-detail-head-text { min-width: 0; flex: 1; }
.mc-detail-head-actions { display: flex; gap: 8px; align-items: center; padding-top: 4px; flex-shrink: 0; }
.mc-form-row { margin-bottom: 18px; display: grid; gap: 14px; }
.mc-detail-actions {
  display: flex; justify-content: flex-end; gap: 8px;
  margin-top: 28px; padding-top: 16px; border-top: 1px solid var(--mc-line);
}
.mc-form-error { color: var(--mc-danger); margin: 12px 0; font-size: 12px; }

/* 通用控件 */
.mc-input {
  width: 100%; height: 34px; padding: 0 10px;
  border: 1px solid var(--mc-line); border-radius: 7px;
  background: var(--mc-panel); color: var(--mc-ink);
  font: inherit; outline: none; transition: border-color .15s, box-shadow .15s;
}
.mc-input:focus { border-color: var(--mc-focus); box-shadow: 0 0 0 3px color-mix(in srgb, var(--mc-focus) 15%, transparent); }
.mc-input:disabled { background: color-mix(in srgb, var(--mc-bg) 60%, var(--mc-panel)); cursor: not-allowed; }
.mc-button {
  height: 34px; padding: 0 14px; border: 1px solid var(--mc-line); border-radius: 7px;
  background: var(--mc-panel); color: var(--mc-ink);
  font: inherit; cursor: pointer; transition: border-color .15s, background .15s;
}
.mc-button:hover:not(:disabled) { border-color: var(--mc-focus); }
.mc-button:disabled { opacity: .55; cursor: not-allowed; }
.mc-button.primary { border-color: var(--mc-focus); background: color-mix(in srgb, var(--mc-focus) 16%, var(--mc-panel)); color: var(--mc-ink); }
.mc-button.primary:hover:not(:disabled) { background: color-mix(in srgb, var(--mc-focus) 26%, var(--mc-panel)); }
.mc-page button:focus-visible { outline: 2px solid var(--mc-focus); outline-offset: 2px; }
.mc-page input[type="checkbox"], .mc-page input[type="radio"] { accent-color: var(--mc-focus); }
.mc-search, .mc-preset-search { min-width: 0; }
.mc-field { display: block; }
.mc-field-label { display: block; margin-bottom: 6px; font-weight: 500; }
.mc-field-hint { display: block; margin-top: 5px; color: var(--mc-muted); font-size: 12px; }
.mc-fieldset { border: none; margin: 0; padding: 0; }
/* 灰色整行只读参考框：长得跟输入框一致，但明确是「看看就好」的展示位。 */
.mc-ref-value {
  display: inline-flex; align-items: center; height: 34px; padding: 0 10px;
  background: color-mix(in srgb, var(--mc-bg) 60%, var(--mc-panel));
  color: var(--mc-muted); cursor: default; user-select: text;
}
.mc-fieldset legend.mc-field-label { margin-bottom: 8px; padding: 0; }
.mc-check { display: flex; align-items: center; gap: 8px; cursor: pointer; }
.mc-check + .mc-check { margin-top: 6px; }
.mc-check-group { margin: 8px 0 0 24px; padding-left: 12px; border-left: 2px solid var(--mc-line); }
.mc-segment { display: flex; gap: 16px; margin-bottom: 8px; }
.mc-segment-item { display: flex; align-items: center; gap: 6px; cursor: pointer; }

/* 快速预设 */
.mc-preset {
  margin-bottom: 22px; padding: 14px 16px;
  border: 1px solid var(--mc-line); border-radius: 10px;
  background: var(--mc-panel);
}
.mc-preset-title { margin: 0 0 4px; font-size: 13px; font-weight: 600; }
.mc-preset-desc { margin: 0 0 12px; color: var(--mc-muted); font-size: 12px; }
.mc-preset-bar { display: flex; gap: 8px; }
.mc-preset-search { flex: 1; }
.mc-preset-results {
  margin-top: 10px; max-height: 240px; overflow-y: auto;
  border: 1px solid var(--mc-line); border-radius: 8px;
  background: color-mix(in srgb, var(--mc-bg) 40%, var(--mc-panel));
}
.mc-preset-item {
  display: block; width: 100%; padding: 10px 12px; border: none; background: none;
  text-align: left; cursor: pointer; font: inherit; color: inherit;
  border-bottom: 1px solid var(--mc-line);
}
.mc-preset-item:last-child { border-bottom: none; }
.mc-preset-item:hover { background: color-mix(in srgb, var(--mc-focus) 4%, transparent); }
.mc-preset-item.is-selected { background: color-mix(in srgb, var(--mc-focus) 8%, transparent); }
.mc-preset-item-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.mc-preset-item-head strong { font-weight: 500; }
.mc-preset-item-head code { color: var(--mc-muted); font-size: 12px; }
.mc-preset-item-desc { display: block; margin-top: 3px; color: var(--mc-muted); font-size: 12px; }
.mc-preset-picked { margin: 8px 0 0; font-size: 12px; }

/* 思考强度映射区 */
.mc-levels { margin-top: 10px; }
.mc-level-row { display: grid; grid-template-columns: 160px 1fr; gap: 10px; align-items: center; margin-bottom: 8px; }
.mc-level-check { display: flex; align-items: center; gap: 8px; }
.mc-level-name { font-family: ui-monospace, "Cascadia Mono", Consolas, monospace; font-size: 12px; }
.mc-level-wire:disabled { background: color-mix(in srgb, var(--mc-bg) 70%, var(--mc-panel)); }
.mc-footers { max-width: 640px; margin: 0 auto; }
.mc-footnote + .mc-error, .mc-footnote + .mc-notice { margin-top: 12px; }

/* 窄窗口：不让小窗里的双列表单挤爆，顶部操作按钮也跟着换行。 */
@media (max-width: 560px) {
  .mc-form-row { grid-template-columns: 1fr; }
  .mc-level-row { grid-template-columns: 1fr; gap: 4px; }
  .mc-preset-bar { flex-direction: column; }
  .mc-detail-actions { flex-direction: column-reverse; }
  .mc-detail-head-row { flex-direction: column; gap: 10px; }
  .mc-detail-head-actions { align-self: stretch; justify-content: flex-end; padding-top: 0; }
}
`
