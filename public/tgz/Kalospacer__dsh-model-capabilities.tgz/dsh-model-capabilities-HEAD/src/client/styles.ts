export const CSS = `
.mc-page { --mc-bg:var(--dsw-alias-bg-elevated,#f5f7f8); --mc-panel:var(--dsw-alias-bg-elevated,#fff); --mc-ink:var(--dsw-alias-label-primary,#182127); --mc-muted:var(--dsw-alias-label-secondary,#68747a); --mc-line:var(--dsw-alias-stroke-secondary,#dfe5e7); --mc-soft:#edf2f2; --mc-accent:#087f78; --mc-accent-soft:#e0f2ef; --mc-warn:#a66016; --mc-warn-soft:#fff3df; --mc-danger:#b33e4d; }
.mc-page { color:var(--mc-ink); background:var(--mc-bg); min-height:100%; padding:20px; font:13px/1.5 ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei","PingFang SC",sans-serif; }
.mc-shell { max-width:1460px; margin:0 auto; container-type:inline-size; }
.mc-hero { display:flex; justify-content:space-between; gap:24px; align-items:flex-end; padding:6px 0 22px; border-bottom:1px solid var(--mc-line); }
.mc-kicker { color:var(--mc-accent); font-size:11px; font-weight:800; letter-spacing:.14em; text-transform:uppercase; }
.mc-title { margin:5px 0 3px; font-size:25px; letter-spacing:-.04em; line-height:1.1; }
.mc-subtitle { color:var(--mc-muted); max-width:720px; }
.mc-stats { display:flex; gap:8px; flex-wrap:wrap; justify-content:flex-end; }
.mc-stat { min-width:92px; padding:9px 11px; border:1px solid var(--mc-line); background:var(--mc-panel); border-radius:10px; }
.mc-stat strong { display:block; font-size:18px; letter-spacing:-.03em; }
.mc-stat span { color:var(--mc-muted); font-size:11px; }
.mc-toolbar { display:flex; gap:9px; align-items:center; flex-wrap:wrap; padding:15px 0; }
.mc-search { flex:1 1 280px; min-width:180px; height:38px; padding:0 12px; border:1px solid var(--mc-line); border-radius:9px; background:var(--mc-panel); color:var(--mc-ink); outline:none; }
.mc-search:focus,.mc-input:focus,.mc-wire-input:focus { border-color:var(--mc-accent); outline:3px solid color-mix(in srgb,var(--mc-accent) 18%,transparent); }
.mc-select,.mc-toolbar-button,.mc-button { height:36px; border:1px solid var(--mc-line); border-radius:8px; background:var(--mc-panel); color:var(--mc-ink); padding:0 12px; cursor:pointer; }
.mc-toolbar-button:hover,.mc-button:hover { border-color:var(--mc-accent); }
.mc-toolbar-button.primary,.mc-button.primary { border-color:var(--mc-accent); background:var(--mc-accent); color:#fff; }
.mc-toolbar-button:disabled,.mc-button:disabled { opacity:.5; cursor:not-allowed; }
.mc-catalog-status { color:var(--mc-muted); font-size:12px; margin-left:auto; }
.mc-catalog-status.is-error { color:var(--mc-danger); }
.mc-layout { display:grid; min-width:0; grid-template-columns:170px minmax(235px,1fr) minmax(360px,1.3fr); gap:12px; align-items:start; }
.mc-sidebar,.mc-list,.mc-detail { border:1px solid var(--mc-line); background:var(--mc-panel); border-radius:12px; overflow:hidden; }
.mc-sidebar { position:sticky; top:12px; }
.mc-sidebar-head,.mc-list-head,.mc-detail-head { padding:14px; border-bottom:1px solid var(--mc-line); }
.mc-sidebar-head h2,.mc-list-head h2,.mc-detail-head h2 { margin:0; font-size:13px; }
.mc-sidebar-head p,.mc-list-head p,.mc-detail-head p { margin:3px 0 0; color:var(--mc-muted); font-size:11px; }
.mc-route-button { display:block; width:100%; border:0; border-left:3px solid transparent; background:transparent; color:var(--mc-ink); padding:11px 13px; text-align:left; cursor:pointer; }
.mc-route-button:hover { background:var(--mc-soft); }
.mc-route-button.is-selected { border-left-color:var(--mc-accent); background:var(--mc-accent-soft); }
.mc-route-name { display:block; font-weight:700; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.mc-route-count { color:var(--mc-muted); font-size:11px; }
.mc-model-list { max-height:calc(100vh - 240px); overflow:auto; }
.mc-model-row { border-bottom:1px solid var(--mc-line); }
.mc-model-row:last-child { border-bottom:0; }
.mc-model-head { display:flex; gap:10px; align-items:center; width:100%; border:0; background:transparent; text-align:left; padding:13px 14px; cursor:pointer; color:var(--mc-ink); }
.mc-model-head:hover,.mc-model-head.is-selected { background:#f0f7f6; }
.mc-model-name { min-width:0; flex:1; font-weight:750; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.mc-model-id { display:block; color:var(--mc-muted); font-size:11px; font-family:ui-monospace,SFMono-Regular,Consolas,monospace; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.mc-model-meta { display:flex; max-width:44%; flex-wrap:wrap; gap:4px; justify-content:flex-end; }
.mc-tag { display:inline-flex; align-items:center; max-width:190px; padding:2px 7px; border-radius:999px; background:var(--mc-soft); color:var(--mc-muted); font-size:11px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.mc-tag.is-active { background:var(--mc-accent-soft); color:var(--mc-accent); }
.mc-tag.is-warn { background:var(--mc-warn-soft); color:var(--mc-warn); }
.mc-tag.is-dirty { background:#ffe5cb; color:#935114; }
.mc-arrow { color:var(--mc-muted); font-size:12px; }
.mc-detail { position:sticky; top:12px; max-height:calc(100vh - 24px); overflow:auto; }
.mc-detail-body { padding:14px; display:grid; gap:14px; }
.mc-section { border:1px solid var(--mc-line); border-radius:10px; padding:12px; background:var(--mc-panel); }
.mc-section-title { display:flex; justify-content:space-between; gap:12px; align-items:center; margin-bottom:9px; font-weight:800; }
.mc-section-title small { color:var(--mc-muted); font-weight:400; }
.mc-field { display:grid; gap:6px; margin-top:11px; }
.mc-field:first-child { margin-top:0; }
.mc-label { display:flex; justify-content:space-between; gap:10px; color:var(--mc-muted); font-size:12px; }
.mc-label em { color:var(--mc-accent); font-style:normal; }
.mc-input { width:100%; min-width:0; height:35px; border:1px solid var(--mc-line); border-radius:8px; padding:0 10px; color:var(--mc-ink); background:var(--mc-panel); box-sizing:border-box; }
.mc-input-pair { display:grid; grid-template-columns:1fr 1fr; gap:8px; }
.mc-hint { color:var(--mc-muted); font-size:11px; }
.mc-seg { display:flex; flex-wrap:wrap; gap:4px; padding:3px; border-radius:8px; background:var(--mc-soft); width:max-content; max-width:100%; }
.mc-seg-item { border:0; border-radius:6px; padding:6px 10px; background:transparent; color:var(--mc-muted); cursor:pointer; }
.mc-seg-item.is-on { background:var(--mc-panel); color:var(--mc-ink); box-shadow:0 1px 3px #1425221c; font-weight:750; }
.mc-seg-item:disabled { cursor:not-allowed; opacity:.5; }
.mc-levels { display:grid; gap:6px; }
.mc-level-row { display:grid; grid-template-columns:78px minmax(0,1fr); gap:8px; align-items:center; }
.mc-level-label { font-family:ui-monospace,SFMono-Regular,Consolas,monospace; font-size:12px; font-weight:700; }
.mc-level-label.off { color:var(--mc-muted); }
.mc-wire-input { height:31px; width:100%; min-width:0; box-sizing:border-box; border:1px solid var(--mc-line); border-radius:7px; padding:0 8px; background:var(--mc-panel); }
.mc-recommendation { background:#f7fbfa; border-color:#b8ddd8; }
.mc-recommendation-head { display:flex; justify-content:space-between; gap:8px; align-items:flex-start; }
.mc-recommendation-title { font-weight:800; }
.mc-recommendation-id { margin-top:2px; color:var(--mc-muted); font:11px ui-monospace,SFMono-Regular,Consolas,monospace; }
.mc-recommendation-grid { display:grid; grid-template-columns:1fr 1fr; gap:7px; margin:11px 0; }
.mc-recommendation-grid div { padding:7px; border-radius:7px; background:var(--mc-panel); border:1px solid #dcece9; }
.mc-recommendation-grid strong { display:block; font-size:12px; }
.mc-recommendation-grid span { color:var(--mc-muted); font-size:11px; }
.mc-candidates { display:grid; gap:7px; }
.mc-candidate { display:grid; grid-template-columns:auto minmax(0,1fr) auto; gap:8px; align-items:center; padding:8px; border:1px solid var(--mc-line); border-radius:8px; background:var(--mc-panel); }
.mc-candidate.is-top { border-color:#a9d6d1; }
.mc-candidate-main { min-width:0; }
.mc-candidate-id { display:block; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font:12px ui-monospace,SFMono-Regular,Consolas,monospace; }
.mc-candidate-info { color:var(--mc-muted); font-size:11px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.mc-confidence { padding:2px 6px; border-radius:999px; background:var(--mc-soft); color:var(--mc-muted); font-size:10px; }
.mc-confidence.high,.mc-confidence.medium { color:var(--mc-accent); background:var(--mc-accent-soft); }
.mc-button.small { height:29px; padding:0 8px; font-size:11px; }
.mc-alert { padding:9px 10px; border-radius:8px; background:var(--mc-warn-soft); color:var(--mc-warn); font-size:12px; }
.mc-error { padding:9px 10px; border-radius:8px; background:#fff0f1; color:var(--mc-danger); font-size:12px; }
.mc-empty { padding:28px 16px; color:var(--mc-muted); text-align:center; }
.mc-savebar { position:sticky; bottom:12px; z-index:4; display:flex; gap:10px; align-items:center; margin-top:14px; padding:10px 12px; border:1px solid var(--mc-line); border-radius:10px; background:var(--mc-panel); box-shadow:0 8px 24px #13231d14; }
.mc-savebar span { flex:1; }
.mc-savebar strong { color:var(--mc-accent); }
.mc-check { display:flex; gap:6px; align-items:center; color:var(--mc-muted); font-size:12px; }
.mc-loading { padding:28px; color:var(--mc-muted); }
@media (max-width:950px) { .mc-layout { grid-template-columns:190px minmax(320px,1fr); } .mc-detail { grid-column:1 / -1; position:static; max-height:none; } }
@media (max-width:680px) { .mc-page { padding:12px; } .mc-hero { display:block; } .mc-stats { justify-content:flex-start; margin-top:12px; } .mc-layout { display:block; } .mc-sidebar,.mc-list,.mc-detail { margin-bottom:10px; position:static; } .mc-model-meta { display:none; } .mc-input-pair { grid-template-columns:1fr; } .mc-savebar { flex-wrap:wrap; } .mc-savebar span { flex-basis:100%; } }
@media (prefers-reduced-motion:reduce) { .mc-page *,.mc-page *::before,.mc-page *::after { scroll-behavior:auto !important; transition:none !important; animation:none !important; } }

.mc-page * { box-sizing:border-box; }
.mc-page button,.mc-page input,.mc-page select { font:inherit; }
.mc-page button:focus-visible { outline:2px solid var(--mc-accent); outline-offset:2px; }
.mc-page button:active:not(:disabled) { transform:scale(.98); }
.mc-page button { transition:background-color .15s,transform .15s; }
.mc-section,.mc-sidebar,.mc-list,.mc-detail { min-width:0; }
.mc-level-label { display:flex; align-items:center; gap:6px; }
.mc-levels { margin-top:12px; }
.mc-detail-head p,.mc-recommendation-id { overflow-wrap:anywhere; }
.mc-detail-actions { display:flex; flex-wrap:wrap; gap:8px; margin-top:10px; }
.mc-current { margin:8px 0; font-size:11px; color:var(--mc-muted); }
.mc-inline-error { color:var(--mc-danger); font-size:11px; }
.mc-raw-values { display:flex; flex-wrap:wrap; gap:5px; margin:8px 0; }
.mc-raw-values code { padding:2px 6px; border-radius:5px; background:var(--mc-soft); }
.mc-candidate-id { white-space:normal; overflow-wrap:anywhere; }
.mc-model-summary { padding:0 14px 10px 35px; color:var(--mc-muted); font-size:11px; }
.mc-model-head { align-items:flex-start; }
.mc-model-meta { max-width:none; flex:none; }
.mc-recommendation-grid strong { overflow-wrap:anywhere; }
.mc-saved-note { color:var(--mc-accent); font-size:11px; }
.mc-savebar { flex-wrap:wrap; }
.mc-skeleton { height:12px; margin:12px 0; border-radius:6px; background:var(--mc-soft); }
.mc-skeleton:nth-child(2) { width:70%; }
.mc-page .mc-compact-heading { margin:0; font-size:12px; }
.mc-page .mc-alert,.mc-page .mc-error { margin:8px 0; overflow-wrap:anywhere; }
@media (prefers-color-scheme:dark) {
  .mc-page { --mc-soft:#293638; --mc-accent:#63c5b6; --mc-accent-soft:#1e3d39; --mc-warn:#edc17e; --mc-warn-soft:#3c3020; --mc-danger:#ed8a93; }
  .mc-model-head:hover,.mc-model-head.is-selected,.mc-recommendation { background:var(--mc-accent-soft); }
  .mc-error { background:#44282c; }
}
@media (max-width:680px) { .mc-page .mc-model-meta { display:flex; } .mc-page .mc-toolbar { gap:8px; } }

@container (max-width:950px) {
  .mc-layout { grid-template-columns:170px minmax(0,1fr); }
  .mc-detail { grid-column:1 / -1; position:static; max-height:none; }
}
@container (max-width:620px) {
  .mc-layout { display:block; }
  .mc-sidebar,.mc-list,.mc-detail { position:static; margin-bottom:10px; }
  .mc-hero { display:block; }
  .mc-stats { justify-content:flex-start; margin-top:12px; }
  .mc-input-pair { grid-template-columns:1fr; }
}

.mc-candidate { color:var(--mc-ink); text-align:left; }
.mc-wire-input,.mc-page input,.mc-page select { color:var(--mc-ink); }
.mc-recommendation-grid div { border-color:var(--mc-line); }
.mc-page details { max-width:100%; overflow-wrap:anywhere; }
`
