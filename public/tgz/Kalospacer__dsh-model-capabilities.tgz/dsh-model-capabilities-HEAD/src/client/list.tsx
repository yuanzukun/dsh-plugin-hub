import type { ModelRow } from './model'
import { changedFields } from './model'
import type { DraftRecord } from './suggestions'

function reasoningLabel(row: ModelRow, record?: DraftRecord): string {
  const reasoning = record?.draft.reasoning
  if (reasoning?.mode === 'none') return '不支持思考'
  if (reasoning?.mode === 'custom') return `思考 ${reasoning.levels.length} 档`
  return row.catalogEfforts.length ? `源自带 ${row.catalogEfforts.length} 档` : '继承上游'
}

function summary(row: ModelRow, record?: DraftRecord): string {
  const parts: string[] = [reasoningLabel(row, record)]
  if (row.displayName) parts.push(row.displayName)
  return parts.join(' · ')
}

export function ModelList(props: {
  rows: readonly ModelRow[]
  records: Record<string, DraftRecord>
  query: string
  onQuery: (value: string) => void
  onOpen: (key: string) => void
  onReload: () => void
  /** 一键预设：批量给「继承上游」的模型写入 OpenRouter 数据 */
  onBulkApply: () => void
  /** 一键预设进行中：禁用按钮防止重复触发 */
  bulkApplying: boolean
  /** OpenRouter 目录还没准备好：不能批量应用 */
  catalogReady: boolean
}) {
  const visible = props.rows.filter(row => {
    if (!props.query.trim()) return true
    const hay = `${row.model.id} ${row.model.name ?? ''} ${row.displayName}`.toLowerCase()
    return hay.includes(props.query.trim().toLowerCase())
  })

  return <div className="mc-list-page">
    <header className="mc-list-head">
      <div>
        <h2 className="mc-title">模型能力</h2>
        <p className="mc-subtitle">共 {props.rows.length} 个模型，点一个进去改它的上下文、输出上限、输入类型和思考映射。</p>
      </div>
      <div className="mc-list-actions">
        <input
          className="mc-input mc-search"
          type="search"
          placeholder="搜索模型名 / ID / 线路…"
          value={props.query}
          onChange={event => props.onQuery(event.currentTarget.value)}
        />
        <button
          type="button"
          className="mc-button mc-button-bulk"
          disabled={!props.catalogReady || props.bulkApplying}
          title={props.catalogReady ? '把所有还继承上游的模型按 OpenRouter 目录批量配好' : 'OpenRouter 目录还在加载，稍等…'}
          onClick={props.onBulkApply}
        >
          {props.bulkApplying ? '⏳ 应用中…' : '⚡ 一键预设'}
        </button>
        <button type="button" className="mc-button" onClick={props.onReload}>重新加载</button>
      </div>
    </header>
    <ul className="mc-list">
      {visible.map(row => {
        const record = props.records[row.key]
        const dirty = record ? changedFields(record.draft, record.row.baseline).length > 0 : false
        return <li key={row.key} className={`mc-row${dirty ? ' is-dirty' : ''}`}>
          <button type="button" className="mc-row-button" onClick={() => props.onOpen(row.key)}>
            <span className="mc-row-main">
              <span className="mc-row-name">{row.model.name ?? row.model.id}</span>
              <span className="mc-row-summary">{summary(row, record)}</span>
            </span>
            <span className="mc-row-chevron" aria-hidden="true">›</span>
          </button>
        </li>
      })}
      {!visible.length ? <li className="mc-empty">没有匹配的模型。</li> : null}
    </ul>
  </div>
}
