import type { ClientContext, RemoteApi, RemoteEvents } from './types'
import { CapabilityStore } from './store'
import { ModelCapabilitiesSection } from './section'

// Cordis 要求逐个声明调用的远端接口，不能只注入 remote。
export const inject = ['slots', 'connection', 'remote', 'remote.settings', 'remote.llm', 'remote.session']

export function apply(ctx: ClientContext): void {
  const remote = ctx.remote as RemoteApi & RemoteEvents
  const store = new CapabilityStore(remote)
  ctx.effect(() => {
    const disposers = [
      remote.$on('settings/document-updated', () => { void store.load() }),
      remote.$on('llm/adapters-updated', () => { void store.load() }),
      ctx.on('connection/reset', () => { void store.load() }),
    ]
    return () => { for (const dispose of disposers) dispose() }
  }, 'model-capabilities: pushed invalidations')
  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section', id: 'model-capabilities', order: 11,
    label: () => '模型能力', inject: () => ({ store }),
  }, ModelCapabilitiesSection))
}
