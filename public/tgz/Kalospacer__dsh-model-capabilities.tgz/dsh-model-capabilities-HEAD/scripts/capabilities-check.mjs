import assert from 'node:assert/strict'
import { build } from 'esbuild'

const result = await build({
  stdin: { contents: `export * from './src/client/model'; export * from './src/client/openrouter'; export * from './src/client/suggestions'; export * from './src/client/store';`, resolveDir: process.cwd(), loader: 'ts' },
  platform: 'node', format: 'esm', bundle: true, write: false,
})
const api = await import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].text).toString('base64')}`)
const { parseTokens, draftFrom, buildBatchOps, buildRows, validateDraft, changedFields, mapEfforts, prepareModels, searchOpenRouter, metadataSuggestion, makeAutoDraft, rebaseDraft, CapabilityStore } = api

assert.equal(parseTokens('1m'), 1048576)
assert.equal(parseTokens('128K'), 131072)
assert.equal(parseTokens('262144'), 262144)
assert.equal(parseTokens(''), undefined)
for (const value of ['0', '-1', '1m context', '1.2', 'Infinity', '999999999999999999999']) assert.throws(() => parseTokens(value))
assert.deepEqual(mapEfforts(['none', 'low', 'high', 'extra'], false), {
  levels: [{ level: 'off', wire: 'none' }, { level: 'low', wire: 'low' }, { level: 'high', wire: 'high' }, { level: 'xhigh', wire: 'extra' }], unknown: [], conflicts: [],
})
assert.equal(mapEfforts(['High'], false).levels[0].wire, 'High')
assert.equal(mapEfforts(['off', 'low'], false).levels[0].wire, 'off')
assert.deepEqual(mapEfforts(['ultra', 'superhigh'], false).unknown, ['ultra', 'superhigh'])
assert.deepEqual(mapEfforts(['none', 'low'], true).conflicts, ['none'])
assert.deepEqual(mapEfforts(['xhigh', 'extra'], false).conflicts, ['extra'])

const raw = [
  { id: 'vendor/glm-5.3', name: 'GLM', context_length: 131072, top_provider: { max_completion_tokens: 32768 }, architecture: { input_modalities: ['text', 'image'] }, reasoning: { supported_efforts: ['none', 'low', 'extra'] } },
  { id: 'vendor/glm-5.3:free', context_length: 65536 },
  { id: 'vendor/glm-5.2' }, { id: 'vendor/gemini-2.5-pro' }, { id: 'amazon/nova-premier-v1' },
  { id: 'unrelated/preview-1' }, { id: 'vendor/no-efforts', context_length: 64000 },
]
const catalog = prepareModels(raw)
assert.equal(searchOpenRouter(catalog, 'KFC/GLM-5.3')[0].model.id, 'vendor/glm-5.3')
assert.equal(searchOpenRouter(catalog, 'KFC/GLM-5.3')[0].auto, true)
assert.equal(searchOpenRouter(catalog, 'vendor/glm-5.3:free')[0].model.id, 'vendor/glm-5.3:free')
assert.equal(searchOpenRouter(catalog, 'vendor/glm-5.3:free')[0].auto, true)
assert.ok(searchOpenRouter(catalog, 'glm-5.9').every(result => !result.auto), '未知版本不能自动匹配其他版本')
assert.deepEqual(searchOpenRouter(catalog, 'step-router-v1'), [])
assert.deepEqual(searchOpenRouter(catalog, 'zzz-no-such-model-123'), [])
assert.deepEqual(searchOpenRouter(catalog, ''), [])
const ambiguous = prepareModels([...raw, { ...raw[0], id: 'other/glm-5.3' }])
assert.equal(searchOpenRouter(ambiguous, 'glm-5.3')[0].auto, false)
assert.equal(searchOpenRouter(ambiguous, 'vendor/glm-5.3')[0].auto, true)

const path = ['future', 'routes', 'route']
function snapshot(models, overrides = {}) {
  const profile = models === null ? { modelOverrides: overrides } : { models }
  return { status: 'ready', writable: true, revision: 0, namespace: { ns: 'llm-pi-ai', revision: 0, schema: {}, value: { future: { routes: { route: profile } } }, user: { future: { routes: { route: profile } } } }, providers: [{ provider: 'route', displayName: 'Route', settingsNs: 'llm-pi-ai', settingsPath: path }], groups: [{ id: 'route', models: [{ id: 'glm-5.3', name: 'GLM', reasoning: { efforts: [{ id: 'low' }] } }] }] }
}
const row = buildRows(snapshot(null))[0]
assert.equal(row.model.reasoningEfforts, undefined, '宿主目录 id 不能被伪造为实际 wire 值')
const auto = makeAutoDraft(row, catalog[0])
assert.ok(auto)
assert.deepEqual(buildBatchOps([{ row, draft: auto.draft }]), [
  { op: 'set', path: [...path, 'modelOverrides', 'glm-5.3', 'reasoningEfforts'], value: { off: 'none', low: 'low', xhigh: 'extra' } },
  { op: 'set', path: [...path, 'modelOverrides', 'glm-5.3', 'input'], value: ['text', 'image'] },
  { op: 'set', path: [...path, 'modelOverrides', 'glm-5.3', 'contextWindow'], value: 131072 },
  { op: 'set', path: [...path, 'modelOverrides', 'glm-5.3', 'maxTokens'], value: 32768 },
])
assert.equal(validateDraft(auto.draft, row.supportedLevels), null)
assert.match(validateDraft({ ...draftFrom(), reasoning: { mode: 'custom', levels: [{ level: 'low', wire: '' }] } }), /发送值/)
const uncertain = metadataSuggestion({ ...catalog[0], efforts: ['low', 'ultra'] }, row.supportedLevels)
assert.equal(uncertain.values.reasoning, undefined)
assert.ok(uncertain.warnings.length)
assert.equal(metadataSuggestion(catalog.at(-1), row.supportedLevels).values.reasoning, undefined)
assert.equal(metadataSuggestion({ ...catalog[0], maxTokens: undefined }, row.supportedLevels).values.maxTokens, undefined)

const existing = { id: 'glm-5.3', reasoningEfforts: { off: null, high: 'gateway-High' }, input: ['audio', 'image'], contextWindow: 262144, maxTokens: 4096, compat: { custom: true } }
const configured = buildRows(snapshot(null, { 'glm-5.3': existing }))[0]
assert.equal(makeAutoDraft(configured, catalog[0]), undefined, '自动回填不能改动已有值')
const scalar = { ...draftFrom(existing), contextWindow: '1m' }
assert.deepEqual(buildBatchOps([{ row: configured, draft: scalar }]), [{ op: 'set', path: [...path, 'modelOverrides', 'glm-5.3', 'contextWindow'], value: 1048576 }])
const list = [existing, { id: 'neighbor', input: ['text'], maxTokens: 2048 }]
const listRows = buildRows(snapshot(list))
const ops = buildBatchOps([
  { row: listRows[0], draft: scalar },
  { row: listRows[1], draft: { ...draftFrom(list[1]), maxTokens: '4k' } },
])
assert.equal(ops.length, 1, '同一路由只能合并成一次数组写入')
assert.deepEqual(ops[0], { op: 'set', path: [...path, 'models'], value: [{ ...existing, contextWindow: 1048576 }, { ...list[1], maxTokens: 4096 }] })
assert.equal(list[0].contextWindow, 262144, '不得原地修改原数组')
const reset = buildBatchOps([{ row: configured, draft: draftFrom() }])
assert.ok(reset.every(op => op.op === 'unset'))
assert.equal(reset.length, 4)
const future = { id: 'glm-5.3', reasoningEfforts: { ultra: 'gateway-ultra' }, input: ['audio'] }
const futureRow = buildRows(snapshot([future]))[0]
assert.deepEqual(buildBatchOps([{ row: futureRow, draft: { ...draftFrom(future), maxTokens: '8k' } }])[0].value, [{ ...future, maxTokens: 8192 }])
const empty = snapshot([])
assert.deepEqual(buildRows(empty), [], '显式空列表不能复活 catalog 模型')
const revised = buildRows(snapshot(null, { 'glm-5.3': { ...existing, maxTokens: 999 } }))[0]
const rebased = rebaseDraft({ row: configured, draft: scalar, source: 'manual' }, revised)
assert.equal(rebased.draft.maxTokens, '999', '重载保留其他窗口改动的无关字段')
assert.equal(rebased.draft.contextWindow, '1m')
assert.deepEqual(changedFields(rebased.draft, revised.baseline), ['contextWindow'])

let revision = 0, writes = 0
const remote = {
  settings: {
    describe: async () => ({ ok: true, value: { writable: true, namespaces: [{ ...snapshot(null).namespace, revision }] } }),
    mutate: async (_ns, _ops, expected) => { writes++; assert.equal(expected, revision); revision++; return { ok: true, value: { ...snapshot(null).namespace, revision } } },
  },
  llm: { listProviders: async () => ({ ok: true, value: [{ id: 'route', name: 'Route' }] }), listConfigurableProviders: async () => ({ ok: true, value: snapshot(null).providers }) },
  session: { modelCatalog: async () => ({ ok: true, value: { groups: snapshot(null).groups } }) },
}
const store = new CapabilityStore(remote)
await store.load()
revision++
await store.load()
await assert.rejects(store.save([{ op: 'set', path: ['x'], value: 1 }], 0), /其他窗口/)
assert.equal(writes, 0, '过期草稿不能发出 mutation')
await store.save([{ op: 'set', path: ['x'], value: 1 }], 1)
assert.equal(writes, 1)
assert.equal(store.getSnapshot().revision, 2)
const memory = new Map()
const previousFetch = globalThis.fetch, previousStorage = globalThis.localStorage
let requests = 0
try {
  globalThis.localStorage = { getItem: key => memory.get(key) ?? null, setItem: (key, value) => memory.set(key, value) }
  globalThis.fetch = async (_url, options) => {
    requests++
    assert.equal(options.credentials, 'omit')
    assert.equal(options.headers.Authorization, undefined, '公开目录请求不得携带线路密钥')
    return { ok: true, json: async () => ({ data: raw }) }
  }
  assert.equal((await api.loadOpenRouter(true)).cached, false)
  assert.equal((await api.loadOpenRouter()).cached, true)
  assert.equal(requests, 1, '缓存期内不能重复联网')
  globalThis.fetch = async () => { throw new Error('offline') }
  assert.equal((await api.loadOpenRouter(true)).stale, true, '离线时可保留过期缓存')
  memory.clear()
  await assert.rejects(api.loadOpenRouter(true), /offline/)
} finally {
  globalThis.fetch = previousFetch
  if (previousStorage === undefined) delete globalThis.localStorage
  else globalThis.localStorage = previousStorage
}
console.log('Capabilities checks passed: real wire values, conservative matching, four metadata fields, protected defaults, list/catalog writes, inheritance, and revision conflicts.')
