// 冒烟目标：验证从「列出模型 → 点进详情 → 修改 → 保存」这条主路径，
// 落实的 settings.mutate ops 形状与宿主期望一致。
// 浏览器端 e2e 在 scripts/browser-smoke.mjs 里；本文件用最小 React 垫片作快速回归。
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { runInNewContext } from 'node:vm'
import { build } from 'esbuild'

// 垫一个真的 CapabilityStore：Plugin apply 里 new 出来的实例只在闭包里用到，
// 而插件系统往 section 传的 props.store 形状与实例同构，所以垫片必须真。
const storeApi = await (async () => {
  const result = await build({
    stdin: { contents: 'export * from "./src/client/store";', resolveDir: process.cwd(), loader: 'ts' },
    platform: 'node', format: 'esm', bundle: true, write: false,
  })
  return import('data:text/javascript;base64,' + Buffer.from(result.outputFiles[0].text).toString('base64'))
})()

const hooks = new Map()
let currentHooks
let hookIndex = 0
const react = {
  useState(initial) {
    const held = currentHooks
    const index = hookIndex++
    if (!(index in held)) held[index] = typeof initial === 'function' ? initial() : initial
    return [held[index], (next) => {
      held[index] = typeof next === 'function' ? next(held[index]) : next
    }]
  },
  useRef(initial) {
    const held = currentHooks
    const index = hookIndex++
    if (!(index in held)) held[index] = { current: initial }
    return held[index]
  },
  useEffect() { /* 冒烟不跑副作用 */ },
  useMemo(create) { return create() },
  useCallback(callback) { return callback },
  useSyncExternalStore(_subscribe, getSnapshot) { return getSnapshot() },
}
const jsx = (type, props, key) => ({ type, props: props ?? {}, key })

function render(node, path = 'root') {
  if (Array.isArray(node)) return node.flatMap((entry, index) => render(entry, `${path}/${index}`))
  if (node === null || node === undefined || typeof node !== 'object') return [node]
  if (typeof node.type === 'function') {
    currentHooks = hooks.get(path) ?? []
    hooks.set(path, currentHooks)
    hookIndex = 0
    return render(node.type(node.props), path)
  }
  return [{ ...node, children: render(node.props.children, `${path}/${node.key ?? node.type}`) }]
}

function find(nodes, predicate) {
  for (const node of nodes) {
    if (node && typeof node === 'object') {
      if (predicate(node)) return node
      const child = find(node.children ?? [], predicate)
      if (child) return child
    }
  }
  return undefined
}
function textOf(nodes) {
  return nodes.map((node) => node && typeof node === 'object'
    ? textOf(node.children ?? [])
    : String(node ?? '')).join('')
}

const bundled = await readFile(resolve('lib/client/index.js'), 'utf8')
let factory
const window = { __ModuleLoader__: { load(entry) { factory = entry.factory } }, setTimeout() {} }
runInNewContext(bundled, { window })
assert.equal(typeof factory, 'function')
const plugin = factory((name) => {
  if (name === 'react') return react
  if (name === 'react/jsx-runtime') return { jsx, jsxs: jsx, Fragment: 'fragment' }
  throw new Error(`unexpected import: ${name}`)
})

async function editFirstModel({ profile, user, catalog, toggle = ['image', true] }) {
  hooks.clear()
  const writes = []
  const view = { ns: 'llm-pi-ai', schema: {}, value: profile, user, revision: 0 }
  const remote = {
    settings: {
      describe: async () => ({ ok: true, value: { writable: true, namespaces: [view] } }),
      mutate: async (ns, ops, revision) => {
        writes.push({ ns, ops, revision })
        return { ok: true, value: { ...view, revision: revision + 1 } }
      },
    },
    llm: {
      listProviders: async () => ({ ok: true, value: [{ id: 'route', name: 'Route' }] }),
      listConfigurableProviders: async () => ({ ok: true, value: [{ provider: 'route', displayName: 'Route', settingsNs: 'llm-pi-ai', settingsPath: ['pi-ai'] }] }),
    },
    session: { modelCatalog: async () => ({ ok: true, value: { groups: [{ id: 'route', name: 'Route', models: catalog }] } }) },
    $on() { return () => {} },
  }
  let section
  let sectionSpec
  const ctx = {
    remote,
    slots: {
      inject(_name, mount) { mount() },
      register(spec, component) { sectionSpec = spec; section = component; return () => {} },
    },
    effect() { return () => {} },
    on() { return () => {} },
  }
  plugin.apply(ctx)
  assert.equal(typeof section, 'function')

  const store = new storeApi.CapabilityStore(remote)
  await store.load()
  const draw = () => render(jsx(section, { store }), 'section')
  let tree = draw()

  // 列表页：点第一行
  const row = find(tree, (node) => node.props.className === 'mc-row-button')
  assert.ok(row, '列表页必须至少有一行模型')
  row.props.onClick()
  tree = draw()

  // 详情页：找到「图片」勾选框并切到目标状态
  const checkbox = find(tree, (node) =>
    node.type === 'input'
    && node.props.type === 'checkbox'
    && node.props['aria-label'] === '图片')
  assert.ok(checkbox, '详情页必须有「图片」复选框')
  if ((checkbox.props.checked ?? false) !== toggle[1]) checkbox.props.onChange({ currentTarget: { checked: toggle[1] } })
  // 垫片 setState 是同步的，必须重新 draw 拿到带新草稿的最新树。
  tree = draw()

  // 点「保存」；注意节点必须在最新树上找，旧树的 onClick 绑的是旧草稿。
  const save = find(tree, (node) => node.type === 'button' && textOf(node.children) === '保存')
  assert.ok(save, '详情页必须有保存按钮')
  assert.ok(!save.props.disabled, '保存按钮应处于可点状态')
  await save.props.onClick()
  assert.equal(writes.length, 1, '保存后必须发一次 mutate')
  return JSON.parse(JSON.stringify(writes[0].ops))
}

// 覆盖宿主模型列表：把第一个模型切到「文本+图片」，audio 这种页面不认识的模态原样保留在末尾。
const base = [
  { id: 'base-model', name: 'Base', input: ['text', 'audio'], maxTokens: 2048 },
  { id: 'neighbor', name: 'Neighbor' },
]
const ops = await editFirstModel({
  profile: { 'pi-ai': { models: base } },
  user: {},
  catalog: base,
  toggle: ['image', true],
})
assert.deepEqual(ops, [{
  op: 'set',
  path: ['pi-ai', 'models'],
  value: [
    { id: 'base-model', name: 'Base', input: ['text', 'image', 'audio'], maxTokens: 2048 },
    { id: 'neighbor', name: 'Neighbor' },
  ],
}], 'audio 模态必须原样保留，text/image 由勾选框控制')

// 覆盖 modelOverrides 路径：同一个修改走单字段 set。
const overrideOps = await editFirstModel({
  profile: { 'pi-ai': { modelOverrides: { 'catalog-model': { input: ['text'], maxTokens: 4096 } } } },
  user: { 'pi-ai': { modelOverrides: { 'catalog-model': { input: ['text'], maxTokens: 4096 } } } },
  catalog: [{ id: 'catalog-model', name: 'Catalog' }],
  toggle: ['image', true],
})
assert.deepEqual(overrideOps, [{
  op: 'set',
  path: ['pi-ai', 'modelOverrides', 'catalog-model', 'input'],
  value: ['text', 'image'],
}])

// 把「图片」关掉：宿主原来有 image，本页把勾选去掉后数组里只剩 extra + text。
const offOps = await editFirstModel({
  profile: { 'pi-ai': { models: [{ id: 'base-model', input: ['text', 'image'] }] } },
  user: {},
  catalog: [{ id: 'base-model' }],
  toggle: ['image', false],
})
assert.deepEqual(offOps, [{
  op: 'set',
  path: ['pi-ai', 'models'],
  value: [{ id: 'base-model', input: ['text'] }],
}])

console.log('Compat smoke passed: list→detail→save path for models[] and modelOverrides, extra modalities preserved.')
