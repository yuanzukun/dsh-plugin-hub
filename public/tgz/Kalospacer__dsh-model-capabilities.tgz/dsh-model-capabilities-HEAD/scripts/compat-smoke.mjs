import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { runInNewContext } from 'node:vm'

const hooks = new Map()
let currentHooks
let hookIndex = 0
const react = {
  useState(initial) {
    const held = currentHooks
    const index = hookIndex++
    if (!(index in held)) held[index] = typeof initial === 'function' ? initial() : initial
    return [held[index], (next) => {
      held[index] = typeof next === 'function' ? next(held[index]) : next
    }]
  },
  useRef(initial) {
    const held = currentHooks
    const index = hookIndex++
    if (!(index in held)) held[index] = { current: initial }
    return held[index]
  },
  useEffect() {},
  useMemo(create) { return create() },
  useCallback(callback) { return callback },
  useSyncExternalStore(_subscribe, getSnapshot) { return getSnapshot() },
}
const jsx = (type, props, key) => ({ type, props: props ?? {}, key })

function render(node, path = 'root') {
  if (Array.isArray(node)) return node.flatMap((entry, index) => render(entry, `${path}/${index}`))
  if (node === null || node === undefined || typeof node !== 'object') return [node]
  if (typeof node.type === 'function') {
    currentHooks = hooks.get(path) ?? []
    hooks.set(path, currentHooks)
    hookIndex = 0
    return render(node.type(node.props), path)
  }
  return [{ ...node, children: render(node.props.children, `${path}/${node.key ?? node.type}`) }]
}

function find(nodes, predicate) {
  for (const node of nodes) {
    if (node && typeof node === 'object') {
      if (predicate(node)) return node
      const child = find(node.children ?? [], predicate)
      if (child) return child
    }
  }
  return undefined
}

function textOf(nodes) {
  return nodes.map((node) => node && typeof node === 'object'
    ? textOf(node.children ?? [])
    : String(node ?? '')).join('')
}

const bundled = await readFile(resolve('lib/client/index.js'), 'utf8')
let factory
const window = {
  __ModuleLoader__: { load(entry) { factory = entry.factory } },
  setTimeout() {},
}
runInNewContext(bundled, { window })
assert.equal(typeof factory, 'function')
const plugin = factory((name) => {
  if (name === 'react') return react
  if (name === 'react/jsx-runtime') return { jsx, jsxs: jsx, Fragment: 'fragment' }
  throw new Error(`unexpected import: ${name}`)
})

async function editCapability({ path, profile, user, catalog, change = 'vision' }) {
  hooks.clear()
  const writes = []
  const view = {
    ns: 'llm-pi-ai',
    schema: {},
    value: profile,
    user,
    revision: 0,
  }
  const remote = {
    settings: {
      describe: async () => ({ ok: true, value: { writable: true, namespaces: [view] } }),
      mutate: async (ns, ops, revision) => {
        writes.push({ ns, ops, revision })
        return { ok: true, value: { ...view, revision: revision + 1 } }
      },
    },
    llm: {
      listProviders: async () => ({ ok: true, value: [{ id: 'route', name: 'Route' }] }),
      listConfigurableProviders: async () => ({
        ok: true,
        value: [{ provider: 'route', displayName: 'Route', settingsNs: 'llm-pi-ai', settingsPath: path }],
      }),
    },
    session: {
      modelCatalog: async () => ({ ok: true, value: { groups: [
        { id: 'route', name: 'Route', models: catalog },
      ] } }),
    },
    $on() { return () => {} },
  }
  let section
  let sectionSpec
  const ctx = {
    remote,
    slots: {
      inject(_name, mount) { mount() },
      register(spec, component) {
        sectionSpec = spec
        section = component
        return () => {}
      },
    },
    effect() { return () => {} },
    on() { return () => {} },
  }
  plugin.apply(ctx)
  assert.equal(typeof section, 'function')
  const store = sectionSpec.inject().store
  await store.load()
  const draw = () => render(jsx(section, { store }), 'section')
  let tree = draw()
  const modelHead = find(tree, (node) => node.props.className?.startsWith('mc-model-head'))
  assert.ok(modelHead, 'model row is visible')
  modelHead.props.onClick()
  tree = draw()
  const label = change === 'vision' ? '支持图像' : '不支持推理'
  const control = find(tree, (node) => node.type === 'button' && textOf(node.children) === label)
  assert.ok(control, `${label} control is visible`)
  control.props.onClick()
  tree = draw()
  const save = find(tree, (node) => node.type === 'button' && textOf(node.children) === '保存全部')
  assert.ok(save, 'save control is visible')
  await save.props.onClick()
  assert.equal(writes.length, 1)
  assert.equal(writes[0].ns, 'llm-pi-ai')
  assert.equal(writes[0].revision, 0)
  return JSON.parse(JSON.stringify(writes[0].ops))
}

const path = ['future', 'routes', 'route']
const catalogOps = await editCapability({
  path,
  profile: { future: { routes: { route: {} } } },
  user: {},
  catalog: [{ id: 'catalog-model', name: 'Catalog model' }],
})
assert.deepEqual(catalogOps, [
  { op: 'set', path: [...path, 'modelOverrides', 'catalog-model', 'input'], value: ['text', 'image'] },
])

const baseModels = [
  { id: 'base-model', name: 'Base model' },
  { id: 'neighbor', name: 'Neighbor', input: ['text'] },
]
const listOps = await editCapability({
  path,
  profile: { future: { routes: { route: { models: baseModels } } } },
  user: {},
  catalog: baseModels,
})
assert.deepEqual(listOps, [{
  op: 'set',
  path: [...path, 'models'],
  value: [{ ...baseModels[0], input: ['text', 'image'] }, baseModels[1]],
}])

const futureEffort = { ultra: 'gateway-ultra' }
const futureOps = await editCapability({
  path,
  profile: { future: { routes: { route: { modelOverrides: { 'catalog-model': { reasoningEfforts: futureEffort } } } } } },
  user: { future: { routes: { route: { modelOverrides: { 'catalog-model': { reasoningEfforts: futureEffort } } } } } },
  catalog: [{ id: 'catalog-model', name: 'Catalog model' }],
})
assert.deepEqual(futureOps, [
  { op: 'set', path: [...path, 'modelOverrides', 'catalog-model', 'input'], value: ['text', 'image'] },
])

for (const input of [['image'], []]) {
  const list = [{ id: 'base-model', input }]
  const ops = await editCapability({
    path,
    profile: { future: { routes: { route: { models: list } } } },
    user: {},
    catalog: list,
    change: 'reasoning',
  })
  assert.deepEqual(ops, [{
    op: 'set',
    path: [...path, 'models'],
    value: [{ id: 'base-model', input, reasoningEfforts: false }],
  }])
}

console.log('Client smoke test passed for route paths, base lists, future effort ids, and input preservation.')
