// 浏览器端 e2e：把构建产物装进真实 Chromium，用模拟 remote 走完整条
// 「列表 → 详情 → 修改 → 保存」、「快速预设手动采纳」、「外部变更重载」、
// 「只读拒绝」、「离线可保存」场景。截图存 .client-build/artifacts/。
import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { build } from 'esbuild'

const tools = resolve('.client-build/browser-tools/node_modules')
const { chromium } = await import(pathToFileURL(resolve(tools, 'playwright/index.mjs')).href)
const fixture = await build({
  entryPoints: ['scripts/browser-fixture.jsx'], bundle: true, format: 'iife', platform: 'browser', write: false,
  jsx: 'automatic', alias: { react: resolve(tools, 'react'), 'react-dom': resolve(tools, 'react-dom') },
})
const bundle = await readFile('lib/client/index.js', 'utf8')
const html = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>模型能力 · 浏览器验证</title><style>
body{margin:0;background:#f5f7f8}#root{--dsw-alias-bg-elevated:#fff;--dsw-alias-label-primary:#182127;--dsw-alias-label-secondary:#68747a;--dsw-alias-stroke-secondary:#dfe5e7}
@media(prefers-color-scheme:dark){body{background:#172026}#root{--dsw-alias-bg-elevated:#202b31;--dsw-alias-label-primary:#e2ebeb;--dsw-alias-label-secondary:#b0bec0;--dsw-alias-stroke-secondary:#39484c}}
</style></head><body><div id="root"></div><script src="/fixture.js"></script><script src="/plugin.js"></script></body></html>`
const server = createServer((req, res) => {
  if (req.url === '/fixture.js') { res.setHeader('Content-Type', 'text/javascript'); res.end(fixture.outputFiles[0].text) }
  else if (req.url === '/plugin.js') { res.setHeader('Content-Type', 'text/javascript'); res.end(bundle) }
  else { res.setHeader('Content-Type', 'text/html; charset=utf-8'); res.end(html) }
})
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
const url = `http://127.0.0.1:${server.address().port}`
const browser = await chromium.launch({ headless: true, executablePath: process.env.DSH_TEST_CHROME ?? 'C:\\Users\\Kalo\\AppData\\Local\\ms-playwright\\chromium-1228\\chrome-win64\\chrome.exe' })
const source = { data: [
  { id: 'z-ai/glm-5.3', name: 'GLM 5.3 · 新发现', context_length: 131072, top_provider: { max_completion_tokens: 32768 }, architecture: { input_modalities: ['text', 'image'] }, reasoning: { supported_efforts: ['none', 'low', 'high', 'extra'], default_effort: 'high' } },
  { id: 'vendor/native-gpt', name: 'Native GPT', context_length: 262144, top_provider: { max_completion_tokens: 8192 }, architecture: { input_modalities: ['text'] }, reasoning: { supported_efforts: ['none', 'low', 'high'] } },
  { id: 'google/gemini-2.5-pro', context_length: 1048576, top_provider: { max_completion_tokens: 65536 }, architecture: { input_modalities: ['text', 'image'] }, reasoning: { supported_efforts: ['low', 'high', 'supra'] } },
  { id: 'amazon/nova-v1' }, { id: 'other/glm-4' },
] }
await mkdir('.client-build/artifacts', { recursive: true })
const errors = []
let activePage
async function newPage(options = {}, offline = false) {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, ...options })
  const page = await context.newPage()
  activePage = page
  page.on('pageerror', error => errors.push(error.message))
  page.on('dialog', dialog => dialog.accept())
  await page.route('https://openrouter.ai/api/v1/models', route => offline ? route.abort('failed') : route.fulfill({ json: source }))
  await page.goto(url)
  await page.getByRole('heading', { name: '模型能力', exact: true }).waitFor()
  return { page, context }
}

try {
  const { page, context } = await newPage()

  // 列表页：至少能列出两个模型，分为 gateway 与 official 两组。
  await page.getByRole('button', { name: /GLM 5\.3/ }).waitFor()
  await page.getByRole('button', { name: /Catalog 模型/ }).waitFor()
  assert.equal((await page.evaluate(() => window.fixture.state())).writes.length, 0, '进入页面不能自动写盘')
  await page.screenshot({ path: '.client-build/artifacts/v2-list.png', fullPage: true })

  // 详情页：点击第一行进入。
  await page.getByRole('button', { name: /GLM 5\.3/ }).click()
  await page.getByRole('heading', { name: 'GLM 5.3 · 新发现', exact: true }).waitFor()
  await page.screenshot({ path: '.client-build/artifacts/v2-detail.png', fullPage: true })

  // 首次进入此模型时「快速预设」面板应自动填一次：contextWindow 是 131072。
  const contextWindow = page.getByRole('textbox', { name: /^上下文窗口/ })
  await contextWindow.waitFor()
  // ensureDraft 在 useEffect 里跑，是 mounted 后异步触发；等到值被填进去。
  await page.waitForFunction(() => {
    const el = document.querySelector('input[data-field="上下文窗口"]')
    return el instanceof HTMLInputElement && el.value === '131072'
  }, { timeout: 8000 })
  assert.equal(await contextWindow.inputValue(), '131072', '首次进入新模型时自动填一次初始值')
  assert.equal((await page.evaluate(() => window.fixture.state())).writes.length, 0, '自动填仍然只在内存草稿，不写盘')

  // 最大输出 token 数也应自动填（32768），且 off 档的 wire 是 none。
  const maxTokens = page.getByRole('textbox', { name: /^最大输出 token 数/ })
  assert.equal(await maxTokens.inputValue(), '32768')
  const offWire = page.locator('.mc-level-row[data-level="off"]').locator('.mc-level-wire')
  assert.equal(await offWire.inputValue(), 'none')

  // 快速预设手动采纳：搜「gemini-2.5-pro」，点采纳，自动填的 contextWindow 应该被覆盖成 1048576。
  await page.getByPlaceholder(/输入模型名/).fill('gemini-2.5-pro')
  await page.getByRole('option', { name: /gemini-2\.5-pro/ }).click()
  await page.getByRole('button', { name: '采纳此预设' }).click()
  await page.getByText(/已把「google\/gemini-2\.5-pro」的预设值填进草稿/).waitFor()
  assert.equal(await page.getByRole('textbox', { name: /^上下文窗口/ }).inputValue(), '1048576', '快速预设采纳后应覆盖自动填过的字段')
  assert.equal(await page.getByRole('textbox', { name: /^最大输出 token 数/ }).inputValue(), '65536')

  // 思考区：自动映射 off → none、 high → high、 xhigh 该由 extra 映射，
  // 但 google/gemini-2.5-pro 的 efforts 是 low/high/supra，没有 extra，
  // 所以采纳后思考区仍保持原草稿的映射（low、high、xhigh=extra 来自 glm-5.3 的 auto）。
  // 先清掉 high，再手写 low →「real-low」。
  await page.locator('.mc-level-row[data-level="high"]').locator('.mc-level-wire').fill('supra')
  assert.equal(await page.locator('.mc-level-row[data-level="high"]').locator('.mc-level-wire').inputValue(), 'supra')

  // 输入类型：把「图片」勾上（gemini 自带 image）。
  await page.getByRole('checkbox', { name: '图片' }).check()
  assert.equal(await page.getByRole('checkbox', { name: '图片' }).isChecked(), true)

  // 保存：发一次 mutate，走 models[] 整列表写回。
  await page.getByRole('button', { name: '保存', exact: true }).first().click()
  await page.waitForFunction(() => window.fixture.state().writes.length === 1)
  await page.waitForFunction(() => !document.querySelector('.mc-back'))
  let state = await page.evaluate(() => window.fixture.state())
  assert.equal(state.writes[0].ops[0].path.at(-1), 'models', 'gateway 是手写路由，应整列表写入')
  const glmRow = state.user.profiles.gateway.models[0]
  assert.equal(glmRow.contextWindow, 1048576)
  assert.equal(glmRow.maxTokens, 65536)
  assert.deepEqual(glmRow.input, ['text', 'image'])
  assert.equal(glmRow.reasoningEfforts.off, 'none')
  assert.equal(glmRow.reasoningEfforts.low, 'low')
  assert.equal(glmRow.reasoningEfforts.high, 'supra')
  assert.equal(glmRow.reasoningEfforts.xhigh, 'extra')

  // 保存成功后页面自动回列表，接着点 neighbor。
  await page.getByRole('button', { name: /已配置模型/ }).click()
  await page.getByRole('heading', { name: '已配置模型', exact: true }).waitFor()
  // neighbor 已有 override，不该再自动填，输入框应以已保存值为准。
  await page.getByRole('textbox', { name: /^最大输出 token 数/ }).fill('4k')
  await page.getByRole('button', { name: '保存', exact: true }).first().click()
  await page.waitForFunction(() => window.fixture.state().writes.length === 2)
  await page.waitForFunction(() => !document.querySelector('.mc-back'))
  state = await page.evaluate(() => window.fixture.state())
  assert.equal(state.user.profiles.gateway.models[1].maxTokens, 4096)
  assert.deepEqual(state.user.profiles.gateway.models[1].compat, { supportsTemperature: true }, '无关字段不能被覆盖')

  // official 线路的 modelOverrides 路径：保存应发 set ops，而不是 list 写。
  await page.getByRole('button', { name: /Catalog 模型/ }).click()
  await page.getByRole('heading', { name: 'Catalog 模型', exact: true }).waitFor()
  // official 没有 override，首次进入会自动填一次。
  await page.getByRole('textbox', { name: /^上下文窗口/ }).waitFor()
  assert.equal(await page.getByRole('textbox', { name: /^上下文窗口/ }).inputValue(), '262144', 'official 新模型首次进入也自动填一次')
  await page.getByRole('button', { name: '保存', exact: true }).first().click()
  await page.waitForFunction(() => window.fixture.state().writes.length === 3)
  // 保存成功后 section 会 setSelectedKey(null) 回列表；等返回按钮消失再点下一行。
  await page.waitForFunction(() => !document.querySelector('.mc-back'))
  state = await page.evaluate(() => window.fixture.state())
  assert.ok(state.writes[2].ops.every(op => op.path.includes('modelOverrides')), 'official 是 catalog 路由，应写 modelOverrides')
  assert.equal(state.user.profiles.official.modelOverrides['native-gpt'].contextWindow, 262144)
  assert.equal(state.user.profiles.official.modelOverrides['native-gpt'].reasoningEfforts.off, 'none')

  // 外部变更 + 自浏览器还没重新加载时，从「已配置模型」的详情页再发起保存：
  // store 内有 revision 防护，保存必须失败、且不写入。
  await page.getByRole('button', { name: /已配置模型/ }).click()
  await page.getByRole('heading', { name: '已配置模型', exact: true }).waitFor()
  await page.getByRole('textbox', { name: /^最大输出 token 数/ }).fill('6k')
  const writesBefore = (await page.evaluate(() => window.fixture.state())).writes.length
  await page.evaluate(() => window.fixture.externalChange())
  // 轻易一点：直接点保存。store.save 会拒绝（revision 过期），UI 应显示错误提示、writes 不增。
  await page.getByRole('button', { name: '保存', exact: true }).first().click()
  await page.getByText(/已被其他窗口修改/, { exact: false }).waitFor()
  const writesAfter = (await page.evaluate(() => window.fixture.state())).writes.length
  assert.equal(writesAfter, writesBefore, 'revision 过期时保存必须被拒绝')
  await page.screenshot({ path: '.client-build/artifacts/v2-conflict.png', fullPage: true })
  // 恢复：放弃此模型草稿，重新加载最新设置。
  await page.getByRole('button', { name: '放弃更改', exact: true }).first().click()
  await page.getByRole('button', { name: /返回列表/ }).click()
  await page.getByRole('button', { name: '重新加载', exact: true }).click()
  await page.waitForTimeout(200)

  // 只读模式：切到只读，输入框应禁用。
  await page.evaluate(() => window.fixture.readOnly())
  await page.getByRole('button', { name: /已配置模型/ }).click()
  await page.getByRole('heading', { name: '已配置模型', exact: true }).waitFor()
  assert.equal(await page.getByRole('textbox', { name: /^上下文窗口/ }).isDisabled(), true, '只读时输入框必须禁用')
  assert.equal(await page.getByRole('button', { name: '保存', exact: true }).first().isDisabled(), true)
  await context.close()

  // 移动端（窄窗口）：不应出现水平溢出。
  const mobile = await newPage({ viewport: { width: 390, height: 844 } })
  await mobile.page.getByRole('button', { name: /GLM 5\.3/ }).waitFor()
  assert.ok(await mobile.page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), '移动端不得水平溢出')
  await mobile.page.getByRole('button', { name: /GLM 5\.3/ }).click()
  await mobile.page.getByRole('heading', { name: 'GLM 5.3 · 新发现', exact: true }).waitFor()
  await mobile.page.screenshot({ path: '.client-build/artifacts/v2-mobile-detail.png', fullPage: true })
  await mobile.context.close()

  // 离线：目录请求被 abort，但手动编辑与保存不受阻。
  const offline = await newPage({}, true)
  await offline.page.getByRole('button', { name: /GLM 5\.3/ }).click()
  await offline.page.getByRole('textbox', { name: /^上下文窗口/ }).fill('512k')
  await offline.page.getByRole('button', { name: '保存', exact: true }).first().click()
  await offline.page.waitForFunction(() => window.fixture.state().writes.length === 1)
  assert.equal((await offline.page.evaluate(() => window.fixture.state())).user.profiles.gateway.models[0].contextWindow, 524288)
  await offline.context.close()

  // 暗色模式：界面应跟随 host 的 prefers-color-scheme。
  const dark = await newPage({ colorScheme: 'dark' })
  await dark.page.getByRole('button', { name: /GLM 5\.3/ }).click()
  await dark.page.screenshot({ path: '.client-build/artifacts/v2-dark-detail.png', fullPage: true })
  await dark.context.close()

  assert.deepEqual(errors, [], '浏览器不应有 React 或运行时错误')
  console.log('Browser smoke passed: v2 two-level nav, auto-fill-once, quick preset manual apply, models[] and modelOverrides writes, conflict handling, read-only, offline, mobile, and dark mode.')
} catch (error) {
  if (activePage && !activePage.isClosed()) {
    await activePage.screenshot({ path: '.client-build/artifacts/v2-failure.png', fullPage: true })
    await writeFile('.client-build/artifacts/v2-failure.html', await activePage.content())
  }
  throw error
} finally {
  await browser.close()
  await new Promise(resolve => server.close(resolve))
}
