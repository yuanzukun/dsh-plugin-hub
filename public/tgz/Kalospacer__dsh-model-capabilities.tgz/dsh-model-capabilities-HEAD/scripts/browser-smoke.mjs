import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { build } from 'esbuild'

// 仅用于开发验证：可在 .client-build/browser-tools 中安装 ReactDOM 与 Playwright。
const tools = resolve('.client-build/browser-tools/node_modules')
const { chromium } = await import(pathToFileURL(resolve(tools, 'playwright/index.mjs')).href)
const fixture = await build({
  entryPoints: ['scripts/browser-fixture.jsx'], bundle: true, format: 'iife', platform: 'browser', write: false,
  jsx: 'automatic', alias: { react: resolve(tools, 'react'), 'react-dom': resolve(tools, 'react-dom') },
})
const bundle = await readFile('lib/client/index.js', 'utf8')
const html = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>模型能力 · 浏览器验证</title><style>
body{margin:0;background:#f5f7f8}#root{--dsw-alias-bg-elevated:#fff;--dsw-alias-label-primary:#182127;--dsw-alias-label-secondary:#68747a;--dsw-alias-stroke-secondary:#dfe5e7}
@media(prefers-color-scheme:dark){body{background:#172026}#root{--dsw-alias-bg-elevated:#202b31;--dsw-alias-label-primary:#e2ebeb;--dsw-alias-label-secondary:#b0bec0;--dsw-alias-stroke-secondary:#39484c}}
</style></head><body><div id="root"></div><script src="/fixture.js"></script><script src="/plugin.js"></script></body></html>`
const server = createServer((req, res) => {
  if (req.url === '/fixture.js') { res.setHeader('Content-Type', 'text/javascript'); res.end(fixture.outputFiles[0].text) }
  else if (req.url === '/plugin.js') { res.setHeader('Content-Type', 'text/javascript'); res.end(bundle) }
  else { res.setHeader('Content-Type', 'text/html; charset=utf-8'); res.end(html) }
})
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
const url = `http://127.0.0.1:${server.address().port}`
const browser = await chromium.launch({ headless: true, executablePath: process.env.DSH_TEST_CHROME ?? 'C:\\Users\\Kalo\\AppData\\Local\\ms-playwright\\chromium-1228\\chrome-win64\\chrome.exe' })
const source = { data: [
  { id: 'z-ai/glm-5.3', name: 'GLM 5.3', context_length: 131072, top_provider: { max_completion_tokens: 32768 }, architecture: { input_modalities: ['text', 'image'] }, reasoning: { supported_efforts: ['none', 'low', 'high', 'extra'], default_effort: 'high' } },
  { id: 'vendor/native-gpt', name: 'Native GPT', context_length: 262144, top_provider: { max_completion_tokens: 8192 }, architecture: { input_modalities: ['text'] }, reasoning: { supported_efforts: ['none', 'low', 'high'] } },
  { id: 'google/gemini-2.5-pro', context_length: 1048576, top_provider: { max_completion_tokens: 65536 }, architecture: { input_modalities: ['text', 'image'] }, reasoning: { supported_efforts: ['low', 'high', 'supra'] } },
  { id: 'amazon/nova-v1' }, { id: 'other/glm-4' },
] }
await mkdir('.client-build/artifacts', { recursive: true })
const errors = []
let activePage
async function newPage(options = {}, offline = false) {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, ...options })
  const page = await context.newPage()
  activePage = page
  page.on('pageerror', error => errors.push(error.message))
  page.on('dialog', dialog => dialog.accept())
  await page.route('https://openrouter.ai/api/v1/models', route => offline ? route.abort('failed') : route.fulfill({ json: source }))
  await page.goto(url)
  await page.getByRole('heading', { name: '模型能力', exact: true }).waitFor()
  return { page, context }
}
try {
  const { page, context } = await newPage()
  await page.getByText('2 个模型待保存', { exact: false }).waitFor()
  assert.equal((await page.evaluate(() => window.fixture.state())).writes.length, 0, '自动预填不能静默写入')
  const contextInput = page.getByRole('textbox', { name: '上下文窗口', exact: true })
  await contextInput.waitFor()
  assert.equal(await contextInput.inputValue(), '131072')
  assert.equal(await page.getByRole('textbox', { name: 'off 实际发送值' }).inputValue(), 'none')
  assert.equal(await page.getByRole('textbox', { name: 'xhigh 实际发送值' }).inputValue(), 'extra')
  await page.screenshot({ path: '.client-build/artifacts/settings-desktop.png', fullPage: true })
  await contextInput.fill('1m')
  await page.getByRole('textbox', { name: 'xhigh 实际发送值' }).fill('GatewayExtra')
  await page.getByRole('button', { name: '保存此模型', exact: true }).click()
  await page.getByText('已保存 1 个模型。', { exact: false }).waitFor()
  let state = await page.evaluate(() => window.fixture.state())
  assert.equal(state.writes[0].ops[0].path.at(-1), 'models', '手写路由应合并数组写入')
  assert.equal(state.user.profiles.gateway.models[0].contextWindow, 1048576)
  assert.equal(state.user.profiles.gateway.models[0].reasoningEfforts.xhigh, 'GatewayExtra')
  assert.equal(state.user.profiles.gateway.models[1].reasoningEfforts.high, 'gateway-High')
  assert.deepEqual(state.user.profiles.gateway.models[1].compat, { supportsTemperature: true })
  await page.getByRole('button', { name: '补齐空白项', exact: true }).click()
  assert.equal(await page.getByRole('textbox', { name: '上下文窗口', exact: true }).inputValue(), '1048576')
  assert.equal(await page.getByRole('textbox', { name: 'xhigh 实际发送值' }).inputValue(), 'GatewayExtra', '补空白按钮不能覆盖已保存修正')
  await page.getByRole('button', { name: '保存全部', exact: true }).click()
  await page.getByText('已保存 1 个模型。', { exact: false }).waitFor()
  await page.waitForFunction(() => window.fixture.state().writes.length === 2)
  state = await page.evaluate(() => window.fixture.state())
  assert.ok(state.writes[1].ops.every(op => op.path.includes('modelOverrides')))
  assert.equal(state.user.profiles.official.modelOverrides['native-gpt'].reasoningEfforts.off, 'none')

  await page.getByRole('button', { name: /已配置模型/ }).click()
  await page.getByRole('textbox', { name: '最大输出 token', exact: true }).fill('4k')
  await page.evaluate(() => window.fixture.externalChange())
  await page.getByText('设置版本已变化，草稿仍然保留。', { exact: false }).waitFor()
  assert.equal(await page.getByRole('button', { name: '保存全部', exact: true }).isDisabled(), true)
  await page.getByRole('button', { name: '加载最新设置', exact: true }).click()
  await page.getByText('已加载最新设置并按字段保留草稿。', { exact: false }).waitFor()
  await page.getByRole('button', { name: '保存全部', exact: true }).click()
  await page.waitForFunction(() => window.fixture.state().writes.length === 3)
  assert.equal((await page.evaluate(() => window.fixture.state())).user.profiles.gateway.models[1].maxTokens, 4096)

  await page.evaluate(() => window.fixture.addModel())
  await page.getByRole('button', { name: /新增 Gemini/ }).waitFor()
  await page.getByRole('button', { name: /新增 Gemini/ }).click()
  await page.getByText('尚未映射的真实值：supra。', { exact: false }).waitFor()
  assert.equal(await page.getByRole('textbox', { name: '上下文窗口', exact: true }).inputValue(), '1048576')
  assert.equal(await page.getByRole('button', { name: '继承默认', exact: true }).first().getAttribute('aria-pressed'), 'true', '未知真实值不能猜成档位')
  await page.getByRole('textbox', { name: '最大输出 token', exact: true }).fill('garbage')
  assert.equal(await page.getByRole('button', { name: '保存全部', exact: true }).isDisabled(), true)
  await page.getByRole('textbox', { name: '最大输出 token', exact: true }).fill('64k')
  await page.getByRole('button', { name: '自定义真实值', exact: true }).click()
  await page.getByRole('checkbox', { name: 'high', exact: true }).check()
  await page.getByRole('textbox', { name: 'high 实际发送值', exact: true }).fill('supra')
  await page.getByRole('button', { name: '保存此模型', exact: true }).click()
  await page.waitForFunction(() => window.fixture.state().writes.length === 4)
  assert.equal((await page.evaluate(() => window.fixture.state())).user.profiles.gateway.models[2].reasoningEfforts.high, 'supra')

  await page.getByRole('button', { name: /GLM 5.3 · 新发现/ }).click()
  await page.getByRole('button', { name: '恢复继承', exact: true }).click()
  await page.getByRole('button', { name: '保存此模型', exact: true }).click()
  await page.waitForFunction(() => window.fixture.state().writes.length === 5)
  state = await page.evaluate(() => window.fixture.state())
  assert.deepEqual(Object.keys(state.user.profiles.gateway.models[0]).sort(), ['id', 'name'])
  const seen = await page.evaluate(() => localStorage.getItem('dshModelCapabilities.autoSeen.v1'))
  await page.reload()
  await page.getByRole('heading', { name: '模型能力', exact: true }).waitFor()
  await page.waitForTimeout(100)
  assert.equal(await page.locator('.mc-savebar').count(), 0, '恢复继承后刷新不能反复填回')
  assert.ok(seen)
  await page.getByRole('button', { name: /已配置模型/ }).click()
  const outputField = page.getByRole('textbox', { name: '最大输出 token', exact: true })
  const savedOutput = await outputField.inputValue()
  await outputField.fill('8888')
  await outputField.fill(savedOutput)
  assert.equal(await page.locator('.mc-savebar').count(), 0, '改回原值后应清除空草稿')
  await page.evaluate(() => window.fixture.externalChange())
  await page.waitForFunction(() => document.querySelector('input[aria-label="最大输出 token"]')?.value === '777')
  await page.getByRole('textbox', { name: '上下文窗口', exact: true }).fill('128k')
  await page.getByRole('button', { name: '保存此模型', exact: true }).click()
  await page.waitForFunction(() => window.fixture.state().writes.length === 1)
  assert.equal((await page.evaluate(() => window.fixture.state())).user.profiles.gateway.models[1].maxTokens, 777, '空草稿不能携带旧列表覆盖较新的配置')
  await page.evaluate(() => window.fixture.readOnly())
  await page.getByText('当前设置只读', { exact: false }).waitFor()
  assert.equal(await page.getByRole('textbox', { name: '上下文窗口', exact: true }).isDisabled(), true)
  await context.close()

  const mobile = await newPage({ viewport: { width: 390, height: 844 } })
  await mobile.page.getByText('2 个模型待保存', { exact: false }).waitFor()
  assert.ok(await mobile.page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), '移动端不得水平溢出')
  await mobile.page.screenshot({ path: '.client-build/artifacts/settings-mobile.png', fullPage: true })
  await mobile.context.close()
  const offline = await newPage({}, true)
  await offline.page.getByText('手动配置与保存不受影响。', { exact: false }).waitFor()
  await offline.page.getByRole('textbox', { name: '上下文窗口', exact: true }).fill('128k')
  await offline.page.getByRole('button', { name: '保存此模型', exact: true }).click()
  await offline.page.waitForFunction(() => window.fixture.state().writes.length === 1)
  assert.equal((await offline.page.evaluate(() => window.fixture.state())).user.profiles.gateway.models[0].contextWindow, 131072)
  await offline.context.close()
  const dark = await newPage({ colorScheme: 'dark' })
  await dark.page.getByText('2 个模型待保存', { exact: false }).waitFor()
  await dark.page.screenshot({ path: '.client-build/artifacts/settings-dark.png', fullPage: true })
  await dark.context.close()
  assert.deepEqual(errors, [], '浏览器不应有 React 或运行时错误')
  console.log('Browser smoke passed: actual published bundle + React + Chromium; auto defaults, custom wire values, both save paths, conflicts, new-model updates, inheritance, read-only, offline, mobile, and dark mode.')
} catch (error) {
  if (activePage && !activePage.isClosed()) {
    await activePage.screenshot({ path: '.client-build/artifacts/failure.png', fullPage: true })
    await writeFile('.client-build/artifacts/failure.html', await activePage.content())
  }
  throw error
} finally {
  await browser.close()
  await new Promise(resolve => server.close(resolve))
}
