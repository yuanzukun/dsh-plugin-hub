import React from 'react'
import { createRoot } from 'react-dom/client'
import * as runtime from 'react/jsx-runtime'

const saved = JSON.parse(localStorage.getItem('fixtureSettings') ?? 'null')
let revision = saved?.revision ?? 0
let writable = true
const events = new Map()
const writes = []
const user = saved?.user ?? { profiles: {
  gateway: { models: [
    { id: 'KFC/GLM-5.3', name: 'GLM 5.3 · 新发现' },
    { id: 'neighbor', name: '已配置模型', reasoningEfforts: { high: 'gateway-High' }, input: ['text'], contextWindow: 64000, maxTokens: 2048, compat: { supportsTemperature: true } },
  ] },
  official: {},
} }
function view() { return { ns: 'llm-pi-ai', schema: {}, value: structuredClone(user), user: structuredClone(user), revision } }
function notify() { for (const listener of events.get('settings/document-updated') ?? []) listener() }
function modify(op) {
  let node = user
  for (const key of op.path.slice(0, -1)) { node[key] ??= {}; node = node[key] }
  const key = op.path.at(-1)
  if (op.op === 'unset') delete node[key]
  else node[key] = structuredClone(op.value)
}
const remote = {
  settings: {
    describe: async () => ({ ok: true, value: { writable, namespaces: [view()] } }),
    mutate: async (ns, ops, expectedRevision) => {
      if (expectedRevision !== revision) return { ok: false, error: { code: 'settings/conflict', message: 'revision conflict' } }
      writes.push({ ns, ops: structuredClone(ops), expectedRevision })
      for (const op of ops) modify(op)
      revision++
      localStorage.setItem('fixtureSettings', JSON.stringify({ revision, user }))
      return { ok: true, value: view() }
    },
  },
  llm: {
    listProviders: async () => ({ ok: true, value: [{ id: 'gateway', name: '自定义网关' }, { id: 'official', name: 'Catalog 线路' }] }),
    listConfigurableProviders: async () => ({ ok: true, value: [
      { provider: 'gateway', displayName: '自定义网关', settingsNs: 'llm-pi-ai', settingsPath: ['profiles', 'gateway'] },
      { provider: 'official', displayName: 'Catalog 线路', settingsNs: 'llm-pi-ai', settingsPath: ['profiles', 'official'] },
    ] }),
  },
  session: {
    modelCatalog: async () => ({ ok: true, value: { groups: [
      { id: 'gateway', models: user.profiles.gateway.models.map(model => ({ id: model.id, name: model.name })) },
      { id: 'official', models: [{ id: 'native-gpt', name: 'Catalog 模型' }] },
    ] } }),
  },
  $on(name, listener) {
    const held = events.get(name) ?? new Set()
    held.add(listener); events.set(name, held)
    return () => held.delete(listener)
  },
}
window.fixture = {
  state: () => ({ revision, writable, writes: structuredClone(writes), user: structuredClone(user) }),
  externalChange: () => { user.profiles.gateway.models[1].maxTokens = 777; revision++; notify() },
  addModel: () => { user.profiles.gateway.models.push({ id: 'gemini-2.5-pro', name: '新增 Gemini' }); revision++; notify() },
  readOnly: () => { writable = false; notify() },
}
window.__ModuleLoader__ = {
  load(entry) {
    const plugin = entry.factory(name => {
      if (name === 'react') return React
      if (name === 'react/jsx-runtime') return runtime
      throw new Error(`Unexpected external ${name}`)
    })
    const root = createRoot(document.getElementById('root'))
    const disposers = []
    plugin.apply({
      remote,
      slots: {
        inject(_name, mount) { disposers.push(mount()) },
        register(spec, Component) { root.render(<Component {...spec.inject()} />); return () => root.unmount() },
      },
      effect(setup) { const dispose = setup(); disposers.push(dispose); return dispose },
      on() { return () => {} },
    })
    window.addEventListener('beforeunload', () => { for (const dispose of disposers) dispose?.() })
  },
}
