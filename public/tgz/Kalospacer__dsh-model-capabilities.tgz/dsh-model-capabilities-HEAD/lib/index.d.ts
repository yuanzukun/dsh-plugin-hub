/**
 * Host loader entry for the browser implementation exported from `./client`.
 *
 * This plugin is client-only: the capability editor lives in the settings
 * surface and writes through `ctx.remote.settings`, so the Host half has
 * no behavior. Keeping this file makes the package a valid Cordis plugin row.
 *
 * @module dsh-model-capabilities
 */
export declare function apply(): void;
