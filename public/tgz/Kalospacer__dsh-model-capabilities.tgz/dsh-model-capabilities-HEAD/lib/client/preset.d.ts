import type { MatchResult, OpenRouterRecord } from './openrouter';
export declare function QuickPreset(props: {
    models: readonly OpenRouterRecord[];
    status: 'loading' | 'ready' | 'error';
    stale: boolean;
    disabled?: boolean;
    /** 进入面板时预填的搜索词（通常是当前模型的 id）。 */
    initialQuery?: string;
    onApply: (result: MatchResult) => void;
    search: (query: string) => MatchResult[];
}): import("react").JSX.Element;
