import type { ModelRow } from './model';
import type { DraftRecord } from './suggestions';
export declare function ModelList(props: {
    rows: readonly ModelRow[];
    records: Record<string, DraftRecord>;
    query: string;
    onQuery: (value: string) => void;
    onOpen: (key: string) => void;
    onReload: () => void;
    /** 一键预设：批量给「继承上游」的模型写入 OpenRouter 数据 */
    onBulkApply: () => void;
    /** 一键预设进行中：禁用按钮防止重复触发 */
    bulkApplying: boolean;
    /** OpenRouter 目录还没准备好：不能批量应用 */
    catalogReady: boolean;
}): import("react").JSX.Element;
