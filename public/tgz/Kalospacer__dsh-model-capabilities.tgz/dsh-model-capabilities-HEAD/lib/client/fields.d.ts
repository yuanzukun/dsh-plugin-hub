import type { InputDraft, LevelDraft } from './types';
/** 数值输入框：接受纯数字或 128k / 1m 快捷写法，不写格式校验，保存前统一由 parseTokens 把关。 */
export declare function TokenField(props: {
    label: string;
    hint?: string;
    /** 展示在原 hint 之下的第二行小字（如自动压缩阈值估算）。 */
    hintBelow?: string | null;
    value: string;
    disabled?: boolean;
    onChange: (value: string) => void;
}): import("react").JSX.Element;
/** 灰色整行只读参考框：摆一个不让改的数字（如上游标称最大输出），给用户对照用。 */
export declare function ReferenceField(props: {
    label: string;
    value: string;
}): import("react").JSX.Element;
/** 输入类型：继承复选 + 文本/图片两个模态复选。勾选继承时模态组禁用。 */
export declare function InputTypeField(props: {
    value: InputDraft;
    disabled?: boolean;
    onChange: (value: InputDraft) => void;
}): import("react").JSX.Element;
/** 思考强度区：inherit / none / custom 三种模式 + custom 时的逐档映射。 */
export declare function ReasoningSection(props: {
    value: {
        mode: 'inherit';
    } | {
        mode: 'none';
    } | {
        mode: 'custom';
        levels: readonly LevelDraft[];
    };
    supported: readonly string[];
    disabled?: boolean;
    onChange: (value: {
        mode: 'inherit';
    } | {
        mode: 'none';
    } | {
        mode: 'custom';
        levels: readonly LevelDraft[];
    }) => void;
}): import("react").JSX.Element;
