import type { ReactNode } from 'react';
export interface ClientContext {
    readonly remote: unknown;
    readonly slots: {
        inject(name: string, mount: () => (() => void) | void): void;
        register(spec: {
            name: string;
            id: string;
            order?: number;
            label?: () => string;
            inject?: () => Record<string, unknown>;
        }, component: (props: any) => ReactNode): () => void;
    };
    effect(setup: () => (() => void) | void, label?: string): () => void;
    on(event: string, listener: (...args: any[]) => void): () => void;
}
/**
 * Wire shapes this page reads, declared locally.
 *
 * The Harness client packages that used to export them (`dsh-client-runtime`,
 * `dsh-client-ui-slots`) were merged away, and the surviving ones publish
 * versions older than the Host this plugin runs against. Declaring the handful
 * of fields the page actually touches keeps the build resolvable against
 * whatever is installed, and every one of these is `import type`-only anyway:
 * nothing here survives compilation.
 */
/** Selectable reasoning metadata the Host advertises for one exact model. */
export interface ModelReasoning {
    readonly efforts: readonly {
        readonly id: string;
        readonly name: string;
        readonly description?: string;
    }[];
    readonly defaultEffort?: string;
}
/** One entry of a provider's effective model catalog. */
export interface ModelCatalogModel {
    readonly id: string;
    readonly name: string;
    readonly description?: string;
    readonly reasoning?: ModelReasoning;
}
/** One provider route and its successfully loaded catalog. */
export interface ModelProviderGroup {
    readonly id: string;
    readonly name: string;
    readonly models: readonly ModelCatalogModel[];
}
/** A configurable provider route joined with its settings location. */
export interface ConfigurableProviderView {
    readonly provider: string;
    readonly displayName: string;
    readonly settingsNs: string;
    readonly settingsPath: readonly string[];
    readonly active?: boolean;
}
/** One registered settings namespace as the Host describes it. */
export interface SettingsNamespaceView {
    readonly ns: string;
    readonly schema: unknown;
    readonly value: unknown;
    readonly base?: unknown;
    readonly user?: unknown;
    readonly revision: number;
}
/** One path-addressed settings edit. */
export type SettingsPathOpView = {
    op: 'set';
    path: string[];
    value: unknown;
} | {
    op: 'unset';
    path: string[];
};
/** The flat result envelope every remote call returns. */
export type RemoteResult<T> = {
    readonly ok: true;
    readonly value: T;
} | {
    readonly ok: false;
    readonly error: {
        readonly code: string;
        readonly message: string;
    };
};
/** The `ctx.remote` faces this page calls. */
export interface RemoteApi {
    readonly settings: {
        describe(): Promise<RemoteResult<{
            writable: boolean;
            namespaces: SettingsNamespaceView[];
        }>>;
        mutate(ns: string, ops: readonly SettingsPathOpView[], expectedRevision: number): Promise<RemoteResult<SettingsNamespaceView>>;
    };
    readonly llm: {
        listProviders(): Promise<RemoteResult<readonly {
            id: string;
            name: string;
        }[]>>;
        listConfigurableProviders(): Promise<RemoteResult<readonly ConfigurableProviderView[]>>;
    };
    readonly session: {
        modelCatalog(): Promise<RemoteResult<{
            groups: readonly ModelProviderGroup[];
        }>>;
    };
}
export interface ModelEntry {
    id: string;
    name?: string;
    contextWindow?: number;
    maxTokens?: number;
    input?: string[];
    reasoningEfforts?: false | Record<string, string | null>;
    compat?: unknown;
}
export type ReasoningDraft = {
    readonly mode: 'inherit';
} | {
    readonly mode: 'none';
} | {
    readonly mode: 'custom';
    readonly levels: readonly LevelDraft[];
};
export interface LevelDraft {
    readonly level: string;
    readonly wire: string;
}
export type VisionDraft = 'inherit' | 'yes' | 'no';
export interface ModelDraft {
    readonly reasoning: ReasoningDraft;
    readonly vision: VisionDraft;
    readonly contextWindow: string;
    readonly maxTokens: string;
}
export interface CapabilitySnapshot {
    status: 'idle' | 'loading' | 'ready' | 'error';
    error: string | null;
    writable: boolean;
    revision: number;
    namespace: SettingsNamespaceView | null;
    providers: readonly ConfigurableProviderView[];
    groups: readonly ModelProviderGroup[];
}
export interface RemoteEvents {
    $on(event: string, listener: (...args: any[]) => void): () => void;
}
