import type { ReactNode } from 'react';
export interface ClientContext {
    readonly remote: unknown;
    readonly slots: {
        inject(name: string, mount: () => (() => void) | void): void;
        register(spec: {
            name: string;
            id: string;
            order?: number;
            label?: () => string;
            inject?: () => Record<string, unknown>;
        }, component: (props: any) => ReactNode): () => void;
    };
    effect(setup: () => (() => void) | void, label?: string): () => void;
    on(event: string, listener: (...args: any[]) => void): () => void;
}
/**
 * Wire shapes this page reads, declared locally.
 *
 * The Harness client packages that used to export them (`dsh-client-runtime`,
 * `dsh-client-ui-slots`) were merged away, and the surviving ones publish
 * versions older than the Host this plugin runs against. Declaring the handful
 * of fields the page actually touches keeps the build resolvable against
 * whatever is installed, and every one of these is `import type`-only anyway:
 * nothing here survives compilation.
 */
/** Selectable reasoning metadata the Host advertises for one exact model. */
export interface ModelReasoning {
    readonly efforts: readonly {
        readonly id: string;
        readonly name: string;
        readonly description?: string;
    }[];
    readonly defaultEffort?: string;
}
/** One entry of a provider's effective model catalog. */
export interface ModelCatalogModel {
    readonly id: string;
    readonly name: string;
    readonly description?: string;
    readonly reasoning?: ModelReasoning;
}
/** One provider route and its successfully loaded catalog. */
export interface ModelProviderGroup {
    readonly id: string;
    readonly name: string;
    readonly models: readonly ModelCatalogModel[];
}
/** A configurable provider route joined with its settings location. */
export interface ConfigurableProviderView {
    readonly provider: string;
    readonly displayName: string;
    readonly settingsNs: string;
    readonly settingsPath: readonly string[];
    readonly active?: boolean;
}
/** One registered settings namespace as the Host describes it. */
export interface SettingsNamespaceView {
    readonly ns: string;
    readonly schema: unknown;
    readonly value: unknown;
    readonly base?: unknown;
    readonly user?: unknown;
    readonly revision: number;
}
/** One path-addressed settings edit. */
export type SettingsPathOpView = {
    op: 'set';
    path: string[];
    value: unknown;
} | {
    op: 'unset';
    path: string[];
};
/** The flat result envelope every remote call returns. */
export type RemoteResult<T> = {
    readonly ok: true;
    readonly value: T;
} | {
    readonly ok: false;
    readonly error: {
        readonly code: string;
        readonly message: string;
    };
};
/** The `ctx.remote` faces this page calls. */
export interface RemoteApi {
    readonly settings: {
        describe(): Promise<RemoteResult<{
            writable: boolean;
            namespaces: SettingsNamespaceView[];
        }>>;
        mutate(ns: string, ops: readonly SettingsPathOpView[], expectedRevision: number): Promise<RemoteResult<SettingsNamespaceView>>;
    };
    readonly llm: {
        listProviders(): Promise<RemoteResult<readonly {
            id: string;
            name: string;
        }[]>>;
        listConfigurableProviders(): Promise<RemoteResult<readonly ConfigurableProviderView[]>>;
    };
    readonly session: {
        modelCatalog(): Promise<RemoteResult<{
            groups: readonly ModelProviderGroup[];
        }>>;
    };
}
export interface ModelEntry {
    id: string;
    name?: string;
    contextWindow?: number;
    maxTokens?: number;
    input?: string[];
    reasoningEfforts?: false | Record<string, string | null>;
    compat?: unknown;
}
export type ReasoningDraft = {
    readonly mode: 'inherit';
} | {
    readonly mode: 'none';
} | {
    readonly mode: 'custom';
    readonly levels: readonly LevelDraft[];
};
export interface LevelDraft {
    readonly level: string;
    readonly wire: string;
}
/**
 * 输入类型草稿：文本与图片两个勾选框 + 一组我们不认识的原始模态。
 *
 * inherit 为 true 时两个勾选值被忽略，落盘时整段删除 input 字段，
 * 让模型重新继承上游目录的模态声明。
 * extra 保留宿主目录里 text / image 之外的模态（audio、video 等），
 * 编辑本页时只切换 text / image，其余原模态原样保留，绝不含混覆盖。
 */
export interface InputDraft {
    readonly inherit: boolean;
    readonly text: boolean;
    readonly image: boolean;
    readonly extra: readonly string[];
}
export interface ModelDraft {
    readonly reasoning: ReasoningDraft;
    readonly input: InputDraft;
    readonly contextWindow: string;
    readonly maxTokens: string;
}
export interface CapabilitySnapshot {
    status: 'idle' | 'loading' | 'ready' | 'error';
    error: string | null;
    writable: boolean;
    revision: number;
    namespace: SettingsNamespaceView | null;
    providers: readonly ConfigurableProviderView[];
    groups: readonly ModelProviderGroup[];
}
export interface RemoteEvents {
    $on(event: string, listener: (...args: any[]) => void): () => void;
}
