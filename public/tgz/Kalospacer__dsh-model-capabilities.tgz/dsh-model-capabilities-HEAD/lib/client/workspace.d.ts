import type { ModelDraft } from './types';
import { type ModelRow } from './model';
import { type MatchResult, type OpenRouterRecord } from './openrouter';
import { type DraftRecord } from './suggestions';
import type { CapabilityStore } from './store';
interface CatalogState {
    status: 'loading' | 'ready' | 'error';
    models: OpenRouterRecord[];
    stale: boolean;
    updatedAt?: number;
    error?: string;
}
export declare function useCatalog(): {
    catalog: CatalogState;
    refreshCatalog: () => undefined;
};
export declare function useWorkspace(store: CapabilityStore, catalog: CatalogState): {
    snapshot: import("./types").CapabilitySnapshot;
    rows: ModelRow[];
    pending: DraftRecord[];
    orphaned: DraftRecord[];
    conflict: boolean;
    busy: boolean;
    notice: {
        kind: "ok" | "error";
        text: string;
    } | null;
    getDraft: (key: string) => DraftRecord | undefined;
    setDraft: (row: ModelRow, draft: ModelDraft, matchedModel?: string) => void;
    ensureDraft: (row: ModelRow) => DraftRecord | undefined;
    applyPreset: (row: ModelRow, result: MatchResult) => void;
    applyPresetToAll: () => Promise<void>;
    bulkApplying: boolean;
    discard: (key: string) => void;
    reload: () => Promise<void>;
    save: (key: string) => Promise<boolean>;
    lookup: (query: string) => MatchResult[];
};
export {};
