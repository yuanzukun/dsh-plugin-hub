import type { ModelDraft } from './types';
import { type ModelRow } from './model';
import { type MatchResult, type OpenRouterRecord } from './openrouter';
import { type DraftRecord } from './suggestions';
import type { CapabilityStore } from './store';
interface CatalogState {
    status: 'loading' | 'ready' | 'error';
    models: OpenRouterRecord[];
    stale: boolean;
    updatedAt?: number;
    error?: string;
}
export declare function useCatalog(): {
    catalog: CatalogState;
    refreshCatalog: () => undefined;
};
export declare function useWorkspace(store: CapabilityStore, catalog: CatalogState): {
    snapshot: import("./types").CapabilitySnapshot;
    rows: ModelRow[];
    matches: {
        [k: string]: MatchResult[];
    };
    records: Record<string, DraftRecord>;
    pending: DraftRecord[];
    orphaned: DraftRecord[];
    conflict: boolean;
    busy: boolean;
    notice: {
        kind: "ok" | "error";
        text: string;
    } | null;
    setDraft: (row: ModelRow, draft: ModelDraft, matchedModel?: string) => void;
    applyMatch: (row: ModelRow, result: MatchResult, replace: boolean) => void;
    fillVisible: (visible: readonly ModelRow[]) => void;
    discard: (key?: string) => void;
    reload: () => Promise<void>;
    save: (key?: string) => Promise<void>;
};
export {};
