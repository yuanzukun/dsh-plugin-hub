import type { ModelDraft } from './types';
import type { ModelRow } from './model';
import { type DraftRecord } from './suggestions';
import type { MatchResult, OpenRouterRecord } from './openrouter';
interface CatalogState {
    status: 'loading' | 'ready' | 'error';
    models: OpenRouterRecord[];
    stale: boolean;
}
export declare function ModelDetail(props: {
    row: ModelRow;
    record: DraftRecord | undefined;
    catalog: CatalogState;
    disabled: boolean;
    onBack: () => void;
    onChange: (draft: ModelDraft) => void;
    onApplyPreset: (result: MatchResult) => void;
    onSave: () => void;
    onDiscard: () => void;
    ensureDraft: () => DraftRecord | undefined;
    searchPresets: (query: string) => MatchResult[];
}): import("react").JSX.Element;
export {};
