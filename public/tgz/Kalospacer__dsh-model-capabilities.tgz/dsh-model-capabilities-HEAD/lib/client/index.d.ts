import type { ClientContext } from './types';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
