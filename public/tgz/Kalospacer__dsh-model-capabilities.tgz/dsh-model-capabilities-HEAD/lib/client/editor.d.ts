import type { ModelDraft } from './types';
import { type ModelRow } from './model';
import { type MatchResult, type OpenRouterRecord } from './openrouter';
export declare function MetadataMatcher({ row, catalog, disabled, onApply }: {
    row: ModelRow;
    catalog: readonly OpenRouterRecord[];
    disabled: boolean;
    onApply: (match: MatchResult, replace: boolean) => void;
}): import("react").JSX.Element;
export declare function ModelEditor({ row, draft, disabled, onChange }: {
    row: ModelRow;
    draft: ModelDraft;
    disabled: boolean;
    onChange: (next: ModelDraft) => void;
}): import("react").JSX.Element;
