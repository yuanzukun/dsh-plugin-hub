import type { ModelDraft } from './types';
import { type ModelRow } from './model';
import { type OpenRouterRecord } from './openrouter';
type DraftValues = {
    -readonly [K in keyof ModelDraft]?: ModelDraft[K];
};
export interface Suggestion {
    values: DraftValues;
    warnings: string[];
}
export declare function metadataSuggestion(model: OpenRouterRecord, supportedLevels: readonly string[]): Suggestion;
export declare function fillMissing(row: ModelRow, current: ModelDraft, suggestion: Suggestion): ModelDraft;
export declare function applyFields(draft: ModelDraft, values: DraftValues): ModelDraft;
export interface DraftRecord {
    row: ModelRow;
    draft: ModelDraft;
    source: 'manual' | 'auto';
    matchedModel?: string;
}
export declare function makeAutoDraft(row: ModelRow, model: OpenRouterRecord): DraftRecord | undefined;
export declare function rebaseDraft(record: DraftRecord, row: ModelRow): DraftRecord;
export {};
