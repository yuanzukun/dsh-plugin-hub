import type { CapabilitySnapshot, ConfigurableProviderView, ModelDraft, ModelEntry, SettingsNamespaceView, SettingsPathOpView } from './types';
export declare const DEFAULT_LEVELS: readonly ["off", "minimal", "low", "medium", "high", "xhigh", "max"];
export declare const FIELDS: readonly ["reasoning", "vision", "contextWindow", "maxTokens"];
export type DraftField = typeof FIELDS[number];
export declare const FIELD_NAMES: Record<DraftField, string>;
export declare function keyOf(route: string, id: string): string;
export declare function messageOf(error: unknown): string;
export declare function readPath(value: unknown, path: readonly string[]): unknown;
export declare function orderedLevelIds(...sources: readonly string[][]): string[];
export declare function draftFrom(entry?: ModelEntry): ModelDraft;
export declare function parseTokens(raw: string): number | undefined;
export declare function formatTokens(value?: number): string;
export declare function changedFields(draft: ModelDraft, baseline?: ModelEntry): DraftField[];
export declare function validateDraft(draft: ModelDraft, supported?: readonly string[], baseline?: ModelEntry): string | null;
export interface ModelRow {
    key: string;
    route: string;
    displayName: string;
    settingsPath: readonly string[];
    model: ModelEntry;
    baseline?: ModelEntry;
    listModels: ModelEntry[] | null;
    overridden: boolean;
    supportedLevels: readonly string[];
    configured?: ModelEntry;
    catalogEfforts: readonly string[];
}
export declare function schemaLevels(namespace: SettingsNamespaceView | null): string[];
export declare function buildRows(snapshot: CapabilitySnapshot): ModelRow[];
export interface PendingEdit {
    row: ModelRow;
    draft: ModelDraft;
}
export declare function buildBatchOps(edits: readonly PendingEdit[]): SettingsPathOpView[];
export declare function joinProviderDirectory(registered: readonly {
    id: string;
    name: string;
}[], directory: readonly ConfigurableProviderView[]): ConfigurableProviderView[];
