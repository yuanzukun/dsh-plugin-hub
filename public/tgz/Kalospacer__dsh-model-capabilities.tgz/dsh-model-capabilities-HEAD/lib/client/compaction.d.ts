/**
 * 详情页「自动压缩阈值」估算。
 *
 * DSH 的压缩插件 compaction-basic 在每次回复前量一遍会话 token，超过阈值就自动压缩，
 * 它的公式（packages/compaction/compaction-basic/src/config.ts resolveCompactSpec）：
 *
 *   消息预算 = 上下文窗口 − 预留输出
 *   阈值     = min(窗口 × 0.8, 消息预算 − 65_536)
 *
 * 其中「预留输出」取会话生效的 maxTokens，没设就用模型能力页写下的 maxTokens。
 * 所以能力页把 maxTokens 写得越大，阈值被压得越低，聊不了几句就被压缩——
 * 这一行的作用就是在用户填数时把这个后果直接算给他看。
 */
/**
 * 按 DSH 默认压缩配置估算触发阈值。
 *
 * @param contextWindow - 模型上下文窗口，必填且必须为正整数。
 * @param maxTokens - 预留的输出上限；留空按 0 计（DSH 此时也认为没有预留）。
 * @returns 触发自动压缩的会话 token 数；结果 ≤ 0 表示 DSH 会直接报配置错误。
 */
export declare function estimateCompactionThreshold(contextWindow: number, maxTokens?: number): number;
