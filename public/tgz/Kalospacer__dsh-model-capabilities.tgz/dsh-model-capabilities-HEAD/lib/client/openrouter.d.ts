import type { LevelDraft } from './types';
export interface OpenRouterRecord {
    id: string;
    name: string;
    contextWindow?: number;
    maxTokens?: number;
    modalities?: string[];
    efforts?: string[];
    defaultEffort?: string;
    mandatory: boolean;
    tokens: string[];
    version?: string;
    created: number;
}
export interface MatchResult {
    model: OpenRouterRecord;
    score: number;
    hits: string[];
    confidence: '精确' | '高' | '中' | '低';
    auto: boolean;
}
export interface EffortMapping {
    levels: LevelDraft[];
    unknown: string[];
    conflicts: string[];
}
export declare const OPENROUTER_URL = "https://openrouter.ai/api/v1/models";
export declare function tokenize(value: string): string[];
export declare function prepareModels(raw: unknown): OpenRouterRecord[];
export interface CatalogResult {
    models: OpenRouterRecord[];
    cached: boolean;
    stale?: boolean;
    updatedAt: number;
}
export declare function loadOpenRouter(force?: boolean): Promise<CatalogResult>;
export declare function searchOpenRouter(models: readonly OpenRouterRecord[], query: string): MatchResult[];
export declare function mapEfforts(efforts: readonly string[], mandatory: boolean): EffortMapping;
