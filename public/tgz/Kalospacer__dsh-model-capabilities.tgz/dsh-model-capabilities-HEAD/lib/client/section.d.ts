import type { CapabilityStore } from './store';
export declare function ModelCapabilitiesSection({ store }: {
    store: CapabilityStore;
}): import("react").JSX.Element;
