import type { CapabilitySnapshot, RemoteApi, SettingsPathOpView } from './types';
export declare class CapabilityStore {
    private readonly remote;
    private snapshot;
    private readonly listeners;
    private loadSequence;
    constructor(remote: RemoteApi);
    getSnapshot: () => CapabilitySnapshot;
    subscribe: (listener: () => void) => (() => void);
    private set;
    load(): Promise<void>;
    save(ops: SettingsPathOpView[], expectedRevision: number): Promise<void>;
}
