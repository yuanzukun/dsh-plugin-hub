# dsh-model-capabilities 设置页 v2 重构计划

> 本文档是唯一执行依据。执行者可以是一个没有任何历史上下文的独立 agent，
> 所以背景、需求、约束、验收标准全部写死在这里，不允许自由发挥。
> 「建议实现」一节只是建议，执行者有更好的方案可以按自己的来，
> 但改完后必须在汇报里说明：为什么自己的方案更好、为什么这样改。

## 一、背景

插件安装在 DSH（cordis 插件体系）里，通过 `settings.section` 插槽注册一个设置页，
操作的数据来自 `llm-pi-ai` 设置命名空间，通过 `ctx.remote.settings.describe/mutate`
读取和写回（**不是展示型页面，是正经的配置编辑器**）。

当前版本（commit 374140b）的设置页是三栏大工作区布局，被用户否决：

- 塞不进 DSH 设置窗口
- 语义不明、不专业
- 与 DSH 原生设置页风格完全脱节

本次重构把前端推倒重做，目标是：**长得就像 DSH 自带的设置页**（参考用户截图：
模型条目下竖排表单，字段为「上下文窗口 / 最大输出 token 数 / 输入类型（文本·图片勾选）」）。

### 已经存在的可复用资产（全部保留，尽量不动）

| 文件 | 作用 |
|---|---|
| `src/client/types.ts` | 全套 wire 类型（ModelEntry、ModelDraft、CapabilitySnapshot、RemoteApi 等） |
| `src/client/model.ts` | DEFAULT_LEVELS、keyOf、parseTokens（支持 128k/1m，k=1024）、draftFrom、changedFields、validateDraft、buildRows、**buildBatchOps**（list 数组单写 vs modelOverrides 字段级写入，含 revision 冲突处理） |
| `src/client/openrouter.ts` | prepareModels、tokenize、searchOpenRouter（保守匹配）、mapEfforts（none→off、extra→xhigh，未知值不猜） |
| `src/client/suggestions.ts` | metadataSuggestion、fillMissing、makeAutoDraft、rebaseDraft |
| `src/client/store.ts` | CapabilityStore（loadSequence、revision 冲突保护） |
| `src/client/workspace.ts` | useCatalog（6h localStorage TTL）、useWorkspace |
| `scripts/capabilities-check.mjs` | 纯逻辑测试 |
| `scripts/compat-smoke.mjs` | 行为兼容冒烟 |
| `scripts/browser-fixture.jsx` / `scripts/browser-smoke.mjs` | 真 Chromium 端到端 |

**本次重构只重写 UI 层**（`editor.tsx`、`section.tsx`、`styles.ts`，以及 `workspace.ts`
中纯服务于旧三栏 UI 的部分）。model / store / openrouter / suggestions 的逻辑层
只有在 UI 确实需要新能力时才动手，且改动必须同步更新对应测试。

## 二、需求定稿（与用户逐条确认过，不允许再改语义）

### 2.1 两级导航

- **列表页**：一排模型，每行只显示「模型名 + 一行小摘要」。**没有状态标签、
  没有「已配置/未配置」区分**（用户明确否决）。点哪行进哪个详情。
- **详情页**：单个模型的编辑表单。提供返回列表的入口。

### 2.2 详情页排版（用户逐行锁定，顺序与布局不许动）

从上到下：

1. **顶部：模型名 + 模型别名**。（原先的一句状态摘要已砍掉）
2. **第一行：「快速预设」面板**。
   - **永远显示**，不依赖任何自动匹配结果。
   - 名字就叫「快速预设」（或「内置预设」这类名字），**不许叫「OpenRouter 建议横幅」**。
   - 内容：一个可搜索的模型列表，数据源是 OpenRouter 公开目录
     （沿用 `useCatalog` 的 6h localStorage 缓存策略）。
   - 用户在搜索框里输入、从列表里手动挑一个模型，点「采纳」。
   - 采纳语义：**全量套用**——把预设的上下文窗口、最大输出 token 数、输入类型
     覆盖到当前草稿（即使这些字段已被用户手填过）。**思考强度映射不动**。
   - 为什么：用户原话「有时候模型名字搜不到，但我希望用某个模型的预设值手动填进去」。
     这是手动工具，不是自动建议。
3. **第二行：上下文窗口、最大输出 token 数，左右并排**。
   - 单个数字输入框，支持 `k`/`m` 后缀（沿用 parseTokens），存整数。
   - 留空 = 用默认值。
   - 标签用专业名词：「上下文窗口」「最大输出 token 数」。
4. **第三行：输入类型**——「文本」「图片」两个勾选框。
5. **第四行：思考强度区**。表单形式逐行列出七个基础档位的映射：
   - 档位固定为 DSH 基础档：`off / minimal / low / medium / high / xhigh / max`。
   - 每档一个输入框，填**实际发送的 wire 值**（字符串）。
   - `off` 档特殊：值为 null 表示「不发 reasoning 参数」；这是唯一允许 null 的档。
   - 非 off 档留空 = 该模型不支持此档。**非 off 档写空值是非法的**（沿用 validateDraft）。
   - 模型完全不支持思考时整组显示为「不支持思考」（reasoningEfforts: false）。
6. **底部：保存 / 放弃 两个按钮**。
   - 保存 = 只写回本次真正改动的字段（沿用 changedFields + buildBatchOps），
     走 `settings.mutate` 真正落配置，带 revision，冲突时按 store 现有逻辑处理。
   - 放弃 = 丢弃草稿，回到已保存状态。

### 2.3 自动填充规则（用户最终澄清版，推翻早前「保险丝」表述）

- 自动填充只是「**新模型第一次出现时填一次初始值**」。
- 「新模型」定义：profile 配置里**没有**该模型已保存 override 的条目。
- 填完即交棒：之后用户手动改、手动采纳快速预设，都是用户的自由，
  **不存在「人工已接管」隐藏状态，不存在任何永久锁定**。
- 没有「清空配置」按钮（用户明确否决：想清就把字段删空再保存）。

### 2.4 风格

- 视觉与交互对齐 DSH 原生设置页：朴素的标签 + 输入控件竖排表单，
  不搞卡片堆叠、不搞大色块、不搞花哨动效。
- 文案用专业名词（上下文窗口、最大输出 token 数、输入类型、思考强度）。
- 全部界面文案为简体中文。

## 三、建议实现

### 3.1 文件拆分（不许把几千行堆进一个文件）

- `src/client/section.tsx`：插槽注册 + 顶层路由（列表页 ↔ 详情页）。
- `src/client/list.tsx`（新）：列表页。
- `src/client/detail.tsx`（新）：详情页骨架（顶部模型名+别名、五个区块、底部按钮）。
- `src/client/preset.tsx`（新）：「快速预设」面板（搜索框 + 列表 + 采纳）。
- `src/client/fields.tsx`（新）：数值输入（k/m 后缀）、输入类型勾选组、思考映射行组。
- `src/client/styles.ts`：全部样式重写，对齐 DSH 原生设置页气质。
- `src/client/editor.tsx`：**删除**（职责被 detail/fields/preset 拆走）。
- `src/client/workspace.ts`：删掉只服务旧三栏 UI 的状态（如多列选中态），
  保留 fillVisible / save / discard / reload；「自动填一次」放在首次进入详情页
  且该模型无已保存 override 时触发（makeAutoDraft 已存在，直接复用）。

### 3.2 数据流

draft 仍由 CapabilityStore 管理；详情页编辑的是单个模型的 ModelDraft；
快速预设采纳 = 把目录模型的 metadataSuggestion 结果覆盖进 draft 的
contextWindow/maxTokens/inputs 三个字段，标记为 dirty，由用户点保存才落盘。

### 3.3 测试

- `scripts/capabilities-check.mjs`：如逻辑层有改动则同步更新。
- `scripts/compat-smoke.mjs`：适配新入口导出，行为断言保持原意。
- `scripts/browser-smoke.mjs`：fixture 改成两级导航场景，
  断言：列表点入详情、五个区块齐全、快速预设搜索→采纳→字段被覆盖、
  保存后 mutate 收到正确的 ops。截图存 `.client-build/artifacts/`。

## 四、验收标准

1. `pnpm -r typecheck` 与构建全绿。
2. `node scripts/capabilities-check.mjs`、`node scripts/compat-smoke.mjs` 全绿。
3. 真 Chromium e2e 全绿，截图人工确认：页面塞得进 DSH 设置窗口，长得不违和。
4. 保存动作确实产生 `settings.mutate` 调用且 ops 正确（e2e 断言覆盖）。
5. 思考映射：off=null 合法、非 off 空值被拒绝（逻辑测试覆盖）。

## 五、过程约束（硬性）

- 执行者只做：文件编写、测试编写、文档维护、跑简单测试。
- **不叫任何子代理审查、不做复杂测试**——那是主会话的事。
- 代码注释用简体中文。
- 写完做一份简单汇报：改了哪些文件、测试结果、与建议实现有出入的地方及理由。
- 不 commit、不 push。
