# dsh-model-capabilities

给 DSH 的设置里加一页 **模型能力**：为 pi-ai 路由编辑上下文窗口、最大输出 token、图像输入和真实思考值。

## 安装与使用

```powershell
dsh plugin --profile web add github:Kalospacer/dsh-model-capabilities#main
```

安装后重启 DSH Web Host，打开 **设置 → 模型能力**。

页面分为路由筛选、模型列表和能力编辑三个区域。窄屏会转为上下排列；手机上点击模型会滚动到编辑区域。

1. 在线目录加载后，为新出现、尚未处理的模型寻找可信匹配，并自动生成空白字段的默认草稿。
2. 检查候选来源和实际发送值，必要时搜索另一个模型、切换候选或手动修正。
3. 点击 **保存此模型** 或 **保存全部**。自动预填和套用都不会静默写入设置。

仅在模型能力页打开时扫描当前模型与宿主推送的新模型；不修改 DSH 自己的模型发现流程，也不在后台探测或发送聊天请求。

## 四项能力

| 设置 | DSH 字段 | 说明 |
| --- | --- | --- |
| 上下文窗口 | `contextWindow` | 正整数；支持 `128k`、`1m` 输入，k = 1024 |
| 最大输出 token | `maxTokens` | 正整数；目录未提供时不填 0、不编造默认值 |
| 图像输入 | `input` | 继承默认 / 支持图像 / 仅文本 |
| 思考真实值 | `reasoningEfforts` | 继承默认 / 不支持推理 / 自定义界面选项到实际值的映射 |

数字字段留空表示继承；清空已保存的覆盖值后保存，会删除这个字段的覆盖。

## 思考值不是通用档位名

左侧是 DSH 的界面选项，右侧是模型或当前线路实际接受的字符串。两者不一定同名：

```yaml
reasoningEfforts:
  off: none
  low: low
  high: high
  xhigh: extra
```

- 选择 `off` 时，发送 `none`，而不是擅自改成 `off`。
- 选择 `xhigh` 时，可以发送 `extra`；也可以手动填写当前网关要求的其他值。
- 非 `off` 选项必须有实际发送值。`low: null` **不是**“默认发送 low”，会被当前宿主拒绝。
- `off: null` 是特例，表示关闭选项不发送思考参数。
- `reasoningEfforts: false` 表示不支持推理，不等同于 `off → none`。

自动映射仅处理明确的界面别名（`none → off`、`extra → xhigh`），右侧原值保留大小写。不会按数组位置映射，也不猜测 `ultra`、`supra` 等未知值的强弱；遇到未知值或冲突时显示提示，思考设置保持原状，允许手动修正。

## OpenRouter 匹配与默认值

数据源：`https://openrouter.ai/api/v1/models`。

- `context_length` → 上下文窗口。
- `top_provider.max_completion_tokens` → 最大输出 token。
- `architecture.input_modalities` → 图像/文本能力。
- `reasoning.supported_efforts` → 思考真实值。
- `reasoning.default_effort` 仅展示参考，不写入宿主未声明的字段。

名称搜索采用 token 边界与稀有词加权的匹配方式。不存在于目录中的自拟前缀可以忽略；只有版本与有效名称完整吻合，或 ID/slug 精确吻合且没有歧义时才自动补齐。模糊结果仍能手动选取，但不会自动认领成某个模型。置信标签表示名称匹配质量，不是官方正确率。

**OpenRouter 是聚合目录，不保证其发送值等同于每条接入线路的原生 API。** 保存前应核对线路实际接受的值；插件不会因为模型叫 Claude 就把所有 `xhigh` 擅自改成 `extra`。目录没有思考枚举时，也不会补一套猜测的 `low / medium / high`。

## 不覆盖已有修正

- 自动生成与 **补齐空白项** 只补未声明的字段，不覆盖基础层配置、保存值或正在编辑的草稿。
- **替换为这份元数据** 会先确认，再替换目录确实提供的字段；仍需保存才生效。
- 当前列表可一次补齐所有可信的空白项；已有草稿保持不变。
- **恢复继承** 清除这四项能力覆盖，其他字段不动；**撤销此模型草稿** 只取消未保存的修改。
- 浏览器记忆已经处理过的模型，避免撤销或恢复继承后，每次刷新又自动塞回草稿。需要再次填充时，可显式使用补齐按钮。浏览器存储禁用时只在当前页面记忆。
- 未保存的修改保留在当前页面内，离开或刷新时浏览器会提示；草稿不是持久化设置。

目录在浏览器缓存 6 小时，共享一次请求。联网失败时可以保留旧缓存并标记；没有缓存时仍可完整使用手动配置。公开目录请求不携带线路密钥、Cookie，也不会把本地模型名称发送到 OpenRouter；搜索在本地完成。

## 保留原有保存模式

- 手写模型路由编辑自己的 `models` 数组；同一路由的多模型修改合并为一次数组写入，不丢失邻居条目。
- Catalog 路由只写 `modelOverrides.<modelId>.<field>`，不把整个官方目录替换成手写列表。
- 修改其他字段时，原有 `compat`、audio/video 等输入模态、扩展思考值都保持不变。
- 保存使用草稿建立时的 revision。其他窗口更新后不会默默换用新 revision 强行覆盖；草稿保留，显式加载最新设置并按字段重新核对。

只对 `llm-pi-ai` 的配置路由生效。实际能力写入 DSH 自己的设置，卸载插件后已保存配置仍在；插件不使用 CPA，也不读写 CPA 配置。

## 开发与验证

```powershell
pnpm install
pnpm run check
```

`check` 包含类型检查、发布 bundle 构建、原有宿主兼容性冒烟和新增能力检查。新增检查覆盖真实 wire 值、保守匹配、四项元数据、继承、双保存路径、revision 冲突和目录缓存。

可选的真实浏览器验证（不增加插件运行时依赖）：

```powershell
npm install --prefix .client-build/browser-tools --ignore-scripts --no-audit --no-fund react@18.3.1 react-dom@18.3.1 playwright@1.58.2
$env:DSH_TEST_CHROME = 'C:\path\to\chrome.exe'
node scripts/browser-smoke.mjs
```

浏览器验证运行实际 `lib/client/index.js`、React 与 Chromium，宿主 RPC 使用隔离 fixture，不修改正在使用的 DSH 配置。涵盖自动回填、手动修正、两种保存路径、新模型推送、冲突重试、继承、只读、离线、移动端与深色模式。截图保存在 `.client-build/artifacts/`。

源码按宿主类型、设置存储、模型草稿、OpenRouter、推荐转换、页面工作区和编辑组件拆分，发布入口仍为 `lib/client/index.js`。

MIT
