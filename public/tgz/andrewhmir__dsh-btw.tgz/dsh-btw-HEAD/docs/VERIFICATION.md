# Verification — @andrewhmir/dsh-btw

Evidence for the community release. Every row below was produced by running the
named script against a home created from scratch; none of it is inferred from
reading the code.

## What "clean room" means here

The home is built by `test/e2e/clean-room.ps1` from nothing: the profile declares
only `@deepseek-ai/dsh-base`, `@deepseek-ai/dsh-web-app`, and this plugin. No
company profile, no mirror copy, and no other third-party plugin is present. That
is what a community user gets, so it is the only install this evidence trusts.

The script also closes the two first-run differences such a home exposes:

1. a fresh profile has no workspace, so the GUI opens on "Choose workspace" — the
   script seeds `storages/workspace.json` with one workspace, as the onboarding
   would;
2. the GUI then shows a "Preview Notice" modal whose `<h2>` holds focus, which
   makes `editor.focus()` a no-op and every synthetic keystroke go to the dialog.
   `test/e2e/first-run.mjs` clicks its primary button and proves the composer then
   accepts text.

## Environment

| | |
|---|---|
| Harness | `@deepseek-ai/dsh` **0.2.1-rc.2** (npm `next`), scratch install |
| Install prefix | `.harness-check/prefix-021` |
| Home | `.harness-check/home-clean-1b` (created by `clean-room.ps1`) |
| Plugin spec | local package directory (junction-linked) |
| Composed bundles | `@deepseek-ai/dsh-base`, `@deepseek-ai/dsh-web-app`, `@andrewhmir/dsh-btw` |
| Composed tree | 198 packages, all `@deepseek-ai/*`; zero matches for any company plugin or MCP row |
| Browser | Chrome 155.0.8059.80, headless, DevTools protocol on port 9222, fresh profile |
| Tree under test | `2c8f062` (rename `de8c373`, tooling `ee0bd60`, syntax fix `2c8f062`) |

## Results — DSH 0.2.1-rc.2

| Assertion | Command | Observed |
|---|---|---|
| Composition | `clean-room.ps1` | exit 0, 1232 lines; `- id: btw` resolves to `@andrewhmir/dsh-btw`; zero `not found` / `unknown key` / `cannot resolve` / `did not activate` lines |
| Host route registered | `clean-room.ps1` | `GET /btw/ask → 405` |
| First run unblocked | `first-run.mjs` | `{"dialogFound": true, "dialogDismissed": true, "composerAcceptsText": true}` |
| First run is idempotent | `first-run.mjs` again | `{"dialogFound": false, "dialogDismissed": true, "composerAcceptsText": true}` |
| Side question answers | `cdp-e2e.mjs --mode probe` | `sideQuestion.status: "done"`, 184-character answer |
| Full suite of UI assertions | `cdp-e2e.mjs --mode full` | `firstStatus: "done"`, `upperCaseWorks: true`, `markdownRendered: true`, `secondStatus: "done"`, `cacheReadTokens: 1664`, `pageErrors: []` |
| Dismissal by key | `cdp-e2e.mjs --mode dismiss-keys` | `Escape`, `Space`, `Enter` all `dismissed` |
| Works during a streaming main turn | `cdp-e2e.mjs --mode mid-stream` | `sawMainTurnRunning: true`; **4/4** attempts `done`; `sideAnswerChars: 384`; main turn finished; no overlay left open |
| Unit suite | `node --test "test/*.test.mjs"` | 66/66 pass |
| Client bundle current | `node tools/build-client.mjs --check` | `client.js is up to date` |

## Results — DSH 0.2.0-rc.2 (npm `latest`)

The floor in `package.json` is whatever this run measured. It is the tag most
users install, so the plugin is only listed as compatible with `latest` because
the same assertions pass there.

| | |
|---|---|
| Harness | `@deepseek-ai/dsh` **0.2.0-rc.2**, scratch install `.harness-check/prefix-020` |
| Home | `.harness-check/home-clean-020` (`clean-room.ps1`, created from nothing) |
| Composed bundles | `@deepseek-ai/dsh-base`, `@deepseek-ai/dsh-web-app`, `@andrewhmir/dsh-btw` |
| Composed tree | 188 packages, all `@deepseek-ai/*`; zero company plugins; `- id: btw` resolves to `@andrewhmir/dsh-btw` |

| Assertion | Observed |
|---|---|
| Composition | exit 0, 1262 lines, zero loader complaints |
| Host route registered | `GET /btw/ask → 405` |
| First run unblocked | `{"dialogFound": true, "dialogDismissed": true, "composerAcceptsText": true}` |
| Side question answers | `probe`: `status: "done"`, real answer rendered in the overlay |
| Full suite of UI assertions | `firstStatus: "done"`, `upperCaseWorks: true`, `markdownRendered: true`, `secondStatus: "done"`, `cacheReadTokens: 1664` |
| Dismissal by key | `Escape`, `Space`, `Enter` all `dismissed` |

Result: the measured floor is `engines.dsh: ">=0.2.0-rc.2"`, and `package.json`
declares exactly that.

## Ephemerality

The load-bearing property is that a `/btw` exchange never reaches the session
log. `test/e2e/ephemerality-check.mjs` decodes every zstd session log in the home
and classifies each marker hit by event type: an **answer** excerpt fails in any
event type, and a **question** marker fails only in `user/message`,
`command/run`, or `command/done`.

Four scans over all 3 session logs written by this run (`--since 0`, the whole
home): the `full` exchange with its real 60-character answer excerpt, plus
marker-only scans for the `probe`, `dismiss-keys`, and `mid-stream` exchanges.
**All four: PASS — zero failures, zero marker hits of any kind.**

A scan that cannot see persisted text proves nothing, so the same scanner was run
as a control against text the main turn legitimately persisted:

| Control | Expected | Observed |
|---|---|---|
| `Start-Sleep` (mid-stream user prompt) | detected | 1 `user/message` hit (seq 8) |
| `third planet` (warm-up user prompt) | detected | 1 `user/message` hit (seq 8) |
| `NEVER-PERSISTED-STRING-XYZ` | not found | no hits |

## Defect found during this verification

The rename exposed a gap: `cdp-e2e.mjs` interpolated the package name with
backticks *inside* an existing template literal, so the file stopped parsing —
and the unit suite stayed green because nothing parsed the E2E scripts. Fixed in
`2c8f062`, with `test/e2e-syntax.test.mjs` added so the suite now `node --check`s
every script under `test/e2e/`.

## Release artifacts

| Artifact | Value |
|---|---|
| Repository | <https://github.com/andrewhmir/dsh-btw> (public, MIT, default branch `main`) |
| Published commit | `b48894f` — 25 commits, 46 files, package at repository root |
| Topics | `dsh-plugin`, `deepseek-harness`, `dsh`, `side-questions` |
| CI | GitHub Actions `CI` on `b48894f`: **success** (bundle current, `node --check client.js`, 67/67 tests, `npm pack --dry-run`) |
| npm package | not yet published at the time this section was written — see the npm section below |

## How to reproduce

```powershell
# 1. Build a fresh home containing only the official bundles plus the plugin.
powershell -NoProfile -ExecutionPolicy Bypass -File dsh-btw\test\e2e\clean-room.ps1 `
  -PackageSpec C:\path\to\dsh-btw `
  -HomeDir C:\path\to\fresh-home `
  -CliPrefix C:\path\to\scratch-prefix `
  -Port 3166 -KeepRunning

# 2. Start headless Chrome with a DevTools port (fresh profile to see first run).
Start-Process 'C:\Program Files\Google\Chrome\Application\chrome.exe' -ArgumentList @(
  '--headless=new', '--remote-debugging-port=9222',
  '--user-data-dir=C:\path\to\chrome-profile', '--no-first-run', 'about:blank')

# 3. Dismiss the first-run notice and prove the composer takes text.
node dsh-btw\test\e2e\first-run.mjs --port 9222 --url "<URL printed by step 1>"

# 4. Run the UI assertions.
node dsh-btw\test\e2e\cdp-e2e.mjs --port 9222 --url "<URL>" --mode probe
node dsh-btw\test\e2e\cdp-e2e.mjs --port 9222 --url "<URL>" --mode full --question-marker BTW-REL-FULL-1019
node dsh-btw\test\e2e\cdp-e2e.mjs --port 9222 --url "<URL>" --mode dismiss-keys
node dsh-btw\test\e2e\cdp-e2e.mjs --port 9222 --url "<URL>" --mode mid-stream --question-marker BTW-REL-MID-1019

# 5. Assert ephemerality (exit 0 = PASS), then the sensitivity control.
node dsh-btw\test\e2e\ephemerality-check.mjs --home <fresh-home> --since 0 `
  --question-marker BTW-REL-FULL-1019 --answer-excerpt "<60 chars of the real answer>"
node dsh-btw\test\e2e\ephemerality-check.mjs --home <fresh-home> --since 0 `
  --question-marker Start-Sleep --answer-excerpt "NEVER-PERSISTED-STRING-XYZ"
# expect the second command to FAIL: it proves the scanner sees persisted prompts
```

## Windows sandbox notes

These are properties of a confined DSH session on Windows, not of the plugin.
Each one was hit while producing the evidence above:

- **Chrome cannot be spawned from the confined sandbox** (`spawn EPERM`), so the
  browser steps need an unconfined session.
- **`node --test` spawns a child process per test file** and fails with `spawn
  EPERM` under the same confinement; run the suite unconfined.
- **The shell tool fails with `SetNamedSecurityInfoW (Win32 5)`** when the server
  itself runs confined, so the `mid-stream` mode (whose main turn runs a shell
  command) needs an unconfined server.
- **`Get-NetTCPConnection` cannot see listeners owned by another job**, so
  readiness is always an HTTP probe, never a socket-table check.

## 0.2.0 — long answers truncated or blank (2026-10-22)

### Diagnosis

Two independent defects, both reproduced against the plugin's own route + client
transport + store with scripted models (no provider call, no browser):

1. **The output budget was shared with thinking.** `maxTokens` defaulted to 1200
   and is passed as the wire `max_tokens` of the routed Messages protocol, which
   counts reasoning tokens against the same budget. The session route
   (`deepseek-account` / `deepseek-flash`, `reasoningEffort: high`) therefore
   spent the answer's budget while thinking: a long answer stopped at
   `finish: max-tokens`, and a thinking-heavy one produced **zero text deltas**
   (reproduced: 0-character answer, `finish: max-tokens`).
2. **An abort discarded the visible partial answer.** The route aborted at a hard
   120 s wall clock, and the client rendered the error *instead of* the
   accumulated answer (reproduced: 36 characters streamed, the card showed only
   "the request was aborted").

A third gap appeared while reproducing: a response body that ends without a
terminal frame left the card unsettled with no error.

### Fix (0.2.0)

| area | change |
|---|---|
| budget | default 8192, additionally capped by the session's composed output cap |
| thinking | inherited by default; when the budget is spent before any text, one retry runs with thinking off |
| truncation | the partial answer is appended as an assistant turn and continued (`continuations`, default 2; continuation rounds run without thinking, and the override is withdrawn once if the route rejects that level) |
| aborts | stall watchdog (no chunk for `stallTimeoutMs`, default 60 s) + `deadlineMs` ceiling (default 10 min), reported as `STALLED` / `DEADLINE` |
| presentation | non-modal floating card: no backdrop, no `data-shortcut-modal`, Space/Enter never captured, × or focused Escape dismisses |
| failures | partial text survives an error and is rendered together with it; a terminal-frame-less stream settles as `STREAM_ENDED` |
| activity | throttled `progress` frames show reasoning progress as "Thinking… 1.5k" |

### Evidence in this tree

- Unit suite: **89 tests, 88 pass** (`node --test --test-isolation=none "test/*.test.mjs"`).
  The one failure is `every e2e script parses`, whose `node --check` child
  process is blocked by the confined Windows sandbox; every E2E script was
  verified individually with `node --check` instead (all pass).
- `node tools/build-client.mjs --check` → `client.js is up to date`.
- Behaviour demo against the real route + transport + store (scripted models):
  thinking-only budget → answer delivered after a thinking-off retry; truncated
  answer → continued to a complete `finish: stop`; stalled stream → partial text
  kept plus `STALLED`; presentation → `.dsh-btw-dock`, `role="region"`, no
  backdrop, no `data-shortcut-modal`, no `aria-modal`.
- Browser CLI (`cdp-e2e.mjs` `full` / `dismiss-keys`) was **updated** for the
  non-modal contract but **not re-run** for 0.2.0: headless Chrome cannot be
  spawned from the confined session that made this change. Treat the browser
  assertions as pending until the clean-room run in
  [`test/e2e/README.md`](../test/e2e/README.md) is executed unconfined.

### Client bundle note

The card is client-side, so an already-running GUI hot-swaps it from the rebuilt
`client.js`; the host half (budget, continuation, watchdogs) needs a
`dsh web` restart before the 0.2.0 behaviour is live.
