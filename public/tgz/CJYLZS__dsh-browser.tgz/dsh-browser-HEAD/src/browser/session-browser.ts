/**
 * One conversation's view of the browser it drives.
 *
 * A conversation's tools, and the pane the user watches it through, address the
 * browser belonging to that conversation's session. What "belonging" means
 * depends on the profile mode: `session` and `temp` give each conversation a
 * process of its own, while `workspace` gives every conversation of one project
 * the same process — because the point of that mode is a sign-in shared across
 * a project's conversations.
 *
 * So this class is the *conversation* half of a browser, and
 * [`SharedBrowser`](./shared-browser.ts) is the process half. What is here is
 * everything that is true of one conversation:
 *
 * - the page its tools act on (`this.page`), which is why two conversations on
 *   one browser cannot steal each other's active page;
 * - the refs its snapshots handed out (`this.labels`), because a ref belongs to
 *   the document one conversation read;
 * - its viewport cache, and the dialogs it is waiting on;
 * - the pages it created (`ownedTargets`), which are the only ones its tab list
 *   shows and the only ones its tools may name.
 *
 * Everything else — the context, the port, the profile, the page registry, the
 * mirrors, the lifecycle — is the host's, and is read through the accessors
 * below. The ones that look like plain fields are deliberate: the logic in this
 * file is long and measured, and rewriting it around a different shape would
 * spend the measurement to buy nothing.
 *
 * Launch is lazy and single-flight per process: the first viewer or tool call
 * starts it, and concurrent callers join the same start. Frame production
 * follows the viewer count — `Page.startScreencast` is repaint-driven and costs
 * the renderer every frame, so a mirror nobody watches keeps the browser alive
 * but stops streaming.
 */
import type { CDPSession, Dialog, Page } from 'playwright-core'
import type { BrowserConfig } from '../config.ts'
import { listOf } from '../config.ts'
import type { BrowserSession } from './launch.ts'
import { SharedBrowser, START_MIRROR_MS, until, type BrowserState, type Logger, type PageMirror, type SessionParticipant } from './shared-browser.ts'

import {
  focusedInTree,
  formatAxTree,
  parseQuery,
  RefLabels,
  refTargetOf,
  centerOfQuad,
  type AxNode,
  type AxSnapshot,
  type Box,
  type RefTarget,
  type SnapshotOptions,
  type SnapshotTarget,
} from './aria.ts'
import { mergeFrameTrees, type FrameTree } from './frame-trees.ts'
import { pageInfoFromMetrics, type PageInfo } from './page-info.ts'
import {
  entryInTree,
  locateAmbiguousError,
  locateInTree,
  locateMissError,
  locatorIsTreeShaped,
  type Locator,
  type Located,
} from './locate.ts'
import { startScreencast, type MirrorFrame } from './screencast.ts'
import { dispatchInput, scaleToViewport, type InputMessage, type MouseButton } from './input.ts'

/** One page the browser holds open, as a tool or a viewer describes it. */
export interface TabSummary {
  /** Position in the browser's own page list. */
  readonly index: number
  /** Address the page reports. */
  readonly url: string
  /** Whether this is the page the tools and the mirror act on. */
  readonly active: boolean
  /**
   * The page's CDP target id — its stable identity, the same one external
   * DevTools and Playwright see. Absent only in the moment between a page
   * existing and its session answering `Target.getTargetInfo`; the sidebar can
   * mirror only pages it can name.
   */
  readonly targetId?: string
  /** What the page last said its title was, when that is known. */
  readonly title?: string
}

/** Everything a viewer needs to say what it is looking at. */
export interface BrowserStatus {
  /** The session this browser belongs to. */
  readonly sessionId: string
  /**
   * Which browser process serves this session.
   *
   * Several sessions share one when the profile mode is `workspace`; the id is
   * the pool key, so two rows that report the same one are two conversations on
   * one process and one CDP port.
   */
  readonly browserId: string
  readonly state: BrowserState
  /** External CDP port once the browser runs, else `undefined`. */
  readonly debugPort: number | undefined
  /** Browser version string reported by the CDP listener. */
  readonly version: string | undefined
  /** Address shown in the active page, when one is loaded. */
  readonly url: string | undefined
  /**
   * Window mode the running instance was started with, or `undefined` while
   * none runs. Read from the launch rather than from the current configuration,
   * so a pending restart never reports the mode of a browser that is not up.
   */
  readonly mode: string | undefined
  /** Open pages this session owns, in the browser's own order. */
  readonly tabs: readonly TabSummary[]
  /**
   * How many pages this session owns.
   *
   * The tab list is this same set; the count is here because the settings page
   * shows it as a number, and counting a list it already has is the kind of
   * arithmetic a report should not make its reader repeat.
   */
  readonly ownedPages: number
  /** Why the browser is unusable, when it is. */
  readonly error: string | undefined
}

/** Receives every mirrored frame while subscribed. */
export type FrameListener = (frame: MirrorFrame) => void

/** What a conversation's browser is built from. */
export interface SessionBrowserDeps {
  /** The process this conversation drives, shared or private. */
  readonly host: SharedBrowser
  /** Where launch outcomes are reported. */
  readonly logger: Logger
}

/** How long a measured viewport is trusted before it is read again, in milliseconds. */
const VIEWPORT_TTL_MS = 1_000

/**
 * How long a page must stay still before an action is called settled.
 *
 * Short enough not to tax a page that is already done, long enough that a
 * client-rendered menu or a filtered list has drawn by the time the result is
 * written. This is Playwright MCP's default settle window, for the same reason.
 */
const SETTLE_QUIET_MS = 500

/**
 * How many of the changes one action caused are itemised, and how long anything
 * one of them says may be.
 *
 * An action result is read on every call, so its detail is bounded the way a
 * snapshot's is: the first few changes answer "what did my click do", and the
 * count of what was left out says whether there is more to look at. The same
 * bound is applied again on this side, because the summary arrives from the page
 * and a page is not the authority on how long a tool result may be.
 */
const CHANGE_LIMIT = 5
const CHANGE_TEXT_MAX = 60

/**
 * How many things one page may have said before the oldest are dropped.
 *
 * A page that logs in a loop — a progress ticker, a React warning per render —
 * would otherwise grow this buffer for as long as the tab is open, and this runs
 * on a page nobody is watching. The count of dropped entries is reported, so a
 * caller sees a filled buffer as a filled buffer rather than as a quiet page.
 */
const CONSOLE_LIMIT = 200

/** Longest one console message may be before it is clipped, in characters. */
const CONSOLE_TEXT_MAX = 500

/** Longest an action waits for a page to stop changing. */
const SETTLE_MAX_MS = 3_000

/**
 * How long one attempt to stop a cancelled call's page is given.
 *
 * A page that is answering stops its load or terminates its script within a
 * frame. One that has not answered by now is not going to, and waiting longer
 * only holds up the call that has already given up.
 */
const INTERRUPT_QUIET_MS = 1_000

/** Why a browser that did not answer a cancelled call is dropped. */
const UNREACHABLE_REASON = 'the browser did not answer after the call that was cancelled'

/** How long an action waits for a navigation it triggered to reach the document. */
const SETTLE_NAVIGATION_MS = 2_000

/**
 * How long an action gives the browser to say that a tab it just opened exists,
 * and the shape of the world the report has to describe.
 *
 * Measured 2026-09-29: a click whose `window.open` takes effect is adopted
 * after the protocol call returns, and two of three such clicks reported the
 * page they left behind — the tab list a result carries exists to prevent
 * exactly that. The beat is paid once per action; a page set that holds still
 * through it is the answer either way.
 */
const ADOPTION_GRACE_MS = 100

/**
 * How long a status read waits for the browser's own target list.
 *
 * The list never touches a renderer, so a page that is busy cannot hold it;
 * the budget is for a browser process that has stopped answering at all.
 */
const TARGET_TITLES_MS = 1_000

/**
 * Where an armed settle probe parks its promise on the page.
 *
 * A slot per action rather than one fixed name: two actions in flight on the
 * same page would otherwise read each other's record.
 */
const SETTLE_SLOT = '__dshSettle'

/**
 * How long a page gets to run a short timer before it is judged unable to run
 * script at all, and the timer it is asked to run.
 *
 * A page answering its own event loop resolves that timer in single-digit
 * milliseconds; the budget is generous by two orders of magnitude so that a
 * merely slow page is never mistaken for one that cannot run at all. The cost is
 * paid once per document: the verdict is remembered against the document's own
 * `performance.timeOrigin`, so nothing that stayed healthy pays it twice.
 */
const SCRIPT_PROBE_MS = 250
const SCRIPT_PROBE_TIMER = 10

/**
 * The expression that asks a page whether it runs its own event loop.
 *
 * Every page mechanism a settle probe could wait on was measured on the document
 * that first exposed this (2026-11-02, raw.githubusercontent): `setTimeout`,
 * `queueMicrotask`, `requestAnimationFrame` and `MessageChannel` never run
 * there, in the page's own world and in an isolated one alike, while synchronous
 * evaluation answers in a millisecond. The cause is the response's
 * `Content-Security-Policy: …; sandbox` without `allow-scripts`, which suspends
 * script for the whole document. So the question "does a timer run" is the
 * question "may a probe wait on anything at all", and one timer answers it.
 * @returns the expression to evaluate, resolving to whether the timer ran.
 */
function scriptProbe(): string {
  return `new Promise((done) => {
    let ran = false
    setTimeout(() => { ran = true; done(true) }, ${String(SCRIPT_PROBE_TIMER)})
  })`
}

/** A settle probe installed before an action, and where to read what it saw. */
interface SettleWatch {
  /** The page the action began on. */
  readonly page: Page | undefined
  /** The session the probe was installed on. */
  readonly cdp: CDPSession
  /** The global the probe resolves into. */
  readonly slot: string
}

/** What a page looked like, for deciding whether an action changed it. */
interface PageState {
  /** Address shown in the active page. */
  readonly url: string
  /** Document title at the time. */
  readonly title: string
  /**
   * When this document started, from `performance.timeOrigin`.
   *
   * Two reads of one document answer the same number, and no two documents
   * share one, so "the document this read describes" is a fact a comparison can
   * use: a click that replaced the document reads a different origin even when
   * the address and the title it replaced are identical — which is exactly the
   * shape a form POST that answers with the same page has.
   */
  readonly origin: number
  /**
   * Whether the document runs script of its own, when that has been measured.
   *
   * `false` is a document whose event loop is suspended — a response carrying
   * `Content-Security-Policy: …; sandbox` without `allow-scripts` — and it is
   * the fact every wait has to know about, because a promise left in such a page
   * never settles: measured 2026-11-02, a raw file page hung `browser_navigate`
   * for the whole of its 45 s budget while the browser itself stayed answerable.
   * Absent means not measured, which is not the same as "yes".
   */
  readonly liveScript?: boolean
}

/** The element an action landed on, as the snapshot described it. */
export interface ElementRef {
  /** The element's role. */
  readonly role: string
  /** The element's accessible name. */
  readonly name: string
}

/**
 * One JavaScript dialog a page opened, and what this plugin answered it with.
 *
 * A dialog is invisible to everything else the plugin does: it is not in the
 * accessibility tree, `Runtime.evaluate` cannot see it, and a page waiting for
 * an answer runs no script at all. Reporting it is therefore the only way the
 * model can learn that one appeared — and a dismissed `confirm` that reads as
 * "the page did not change" is a wrong answer rather than a missing one.
 */
export interface DialogReport {
  /** `alert`, `confirm`, `prompt`, or `beforeunload`. */
  readonly type: string
  /** What the page asks. */
  readonly message: string
  /** What a prompt offers as its default answer, empty for the other kinds. */
  readonly defaultValue: string
  /** Which way the dialog was answered. */
  readonly handled: 'accepted' | 'dismissed'
  /** The text a prompt was answered with, once it has been. */
  readonly answer?: string
  /**
   * Whether the dialog was already open when the call reporting it began.
   *
   * A dialog the pane's own user opened is answered by the default policy the
   * moment it appears, so it sits in the buffer before any tool call has run,
   * and the next call would otherwise report it as the dialog *it* met
   * (measured 2026-09-29: a dialog the user opened in the sidebar turned up in
   * the result of an unrelated `browser_evaluate`). Absent means the call met
   * it while it was running.
   */
  readonly earlier?: boolean
}

/**
 * How one call answers a dialog that opens while it runs.
 *
 * The answer has to be declared before the action rather than chosen after it:
 * a dialog blocks the page until it is answered, so there is no moment at which
 * a call could look at one and decide. Dismissing is the default because it is
 * the answer that changes nothing.
 */
export interface DialogPolicy {
  /** Whether to accept the dialog or dismiss it. */
  readonly action: 'accept' | 'dismiss'
  /** What to answer a prompt with; a prompt accepted without text takes its default. */
  readonly text?: string
}

/**
 * How often a wait asks the page whether the condition holds yet.
 *
 * Every ask of a tree-shaped condition is a whole accessibility tree, so this is
 * a compromise rather than a poll rate: a quarter of a second costs a handful of
 * reads over a realistic wait and still lands well inside the time a person
 * would call "as soon as it appeared".
 */
const WAIT_POLL_MS = 250

/** A condition one call waits for instead of acting immediately. */
export interface WaitCondition {
  /** Wait until an element this locator names is on the page. */
  readonly locator?: Locator
  /** Wait until the element this locator names can actually take a press. */
  readonly enabled?: boolean
  /** Wait until the address the page shows contains this text, without regard to case. */
  readonly url?: string
  /** Wait this long with nothing to observe: the last resort, for a page that cannot be asked yet. */
  readonly timeMs?: number
}

/**
 * What a wait found, whether or not the condition held.
 *
 * A condition that has not held yet is an answer, not a failure: the caller
 * learns how long it waited, where the page is now, and what the page did in the
 * meantime — which together are what "judge an action by whether its expected
 * effect appeared" needs in order to decide the next step. Reporting it as an
 * error would make the ordinary "not yet" indistinguishable from a call that
 * broke, and inside a PTC program an uncaught error ends the whole program.
 */
export interface WaitReport {
  /** Whether the condition held before the deadline. */
  readonly matched: boolean
  /** How long the call waited, in milliseconds. */
  readonly waitedMs: number
  /** Address the active page shows when the wait ended. */
  readonly url: string
  /** Title the active page shows when the wait ended. */
  readonly title: string
  /** The element that satisfied an element condition, when one did. */
  readonly element?: ElementRef
  /** How many elements an element condition matched when the wait ended. */
  readonly matches?: number
  /**
   * How many of the matched elements the page says are disabled, when the
   * condition asked for one that can take a press and none could.
   *
   * This is the difference the whole result exists for: "the element is there
   * and the page has not enabled it yet" is a different next step from "nothing
   * by that name has appeared".
   */
  readonly disabled?: number
  /** What the page changed while the wait ran, the first few of them. */
  readonly changes?: readonly DomChange[]
  /** How many further changes were seen and are not itemised here. */
  readonly changesOmitted?: number
}

/**
 * One thing the page or the browser said about itself.
 *
 * A page that fails without touching the document — a handler that threw, a
 * request that never arrived, a resource the deployment blocked — leaves nothing
 * in the accessibility tree and nothing in a change list, so the only trace is
 * what it said. The shape is the reference runtime's (`tab.dev.logs`): a level,
 * the rendered message, when it happened, and where it came from.
 *
 * The message is the browser's own rendering of the arguments, which means an
 * argument that is a plain object arrives as `Object`: the protocol describes a
 * logged value but does not serialize it, and reading it would cost a protocol
 * round trip per argument. A page that wants detail in its log has to put it in
 * the message, and a caller that wants a value has `browser_evaluate`.
 */
export interface ConsoleEntry {
  /** How loud it was, in the browser's own vocabulary, normalized. */
  readonly level: 'debug' | 'info' | 'log' | 'warn' | 'error'
  /** The rendered message. */
  readonly message: string
  /** When the browser recorded it, as an ISO 8601 instant. */
  readonly timestamp: string
  /** Where it came from, with the line when the browser knows one. */
  readonly url?: string
}

/**
 * What the page has said since the current document loaded.
 *
 * `total` and `dropped` are what make the list trustworthy: a page that logs in
 * a loop fills any buffer, and a caller told only the surviving entries would
 * read a truncated history as the whole one.
 */
export interface ConsoleReport {
  /** The entries, oldest first, after the caller's filters. */
  readonly entries: readonly ConsoleEntry[]
  /** How many entries survived this call's filters. */
  readonly matched: number
  /** How many entries the buffer held before this call's filters. */
  readonly total: number
  /** How many entries the buffer dropped because it was full. */
  readonly dropped: number
  /** Address of the page the entries came from. */
  readonly url: string
  /** Title of the page the entries came from. */
  readonly title: string
}

/**
 * One change the page made while an action settled.
 *
 * "The page changed" is not something a model can act on, and under PTC it is
 * not something a program can branch on usefully either: a click that made a
 * toast appear and a click that only re-rendered a spinner both report `dom`.
 * These are the first few facts behind that word, in the words the *page* used —
 * the element's own tag, the role it declares, and a short piece of what it says
 * (Codex's `ElementInfo` splits tag, role, and visible text the same way, and for
 * the same reason: they are three different facts and they disagree often
 * enough to matter).
 *
 * What is deliberately absent is Chrome's *computed* accessible role and name.
 * Reading those for a node that changed means asking the protocol again per
 * change, and the snapshot is where a page's roles and names belong; this says
 * where to look, and `browser_snapshot` says what the element is.
 */
export interface DomChange {
  /** What happened: the element appeared, went away, or says something new. */
  readonly kind: 'added' | 'removed' | 'attribute' | 'text'
  /** The element's tag name, lowercased. */
  readonly tag?: string
  /** The role the element declares in an attribute, when it declares one. */
  readonly role?: string
  /** A short piece of what the element says: its label, its text, or its value. */
  readonly preview?: string
  /** The attribute that changed, for an `attribute` change. */
  readonly attribute?: string
  /** What it said before; absent when there was nothing there before. */
  readonly from?: string
  /** What it says now; absent when it is gone. */
  readonly to?: string
}

/**
 * What an action did, as a tool result reports it.
 *
 * A tool that returned only its arguments left the model to guess what happened;
 * these are the facts the page can be asked for afterwards — where it ended up,
 * what the element was, and whether anything moved while it settled.
 */
export interface ActionReport {
  /** Address the active page shows after the action. */
  readonly url: string
  /** Title the active page shows after the action. */
  readonly title: string
  /** Which of `url`, `title`, `dom`, and `dialog` changed: the page either moved or it did not. */
  readonly changed: readonly string[]
  /** Mutation records observed while the page settled. */
  readonly mutations: number
  /** Whether the page stopped changing inside the settle budget. */
  readonly settled: boolean
  /** The first few things the page changed, when it changed anything. */
  readonly changes?: readonly DomChange[]
  /** How many further changes were seen and are not itemised here. */
  readonly changesOmitted?: number
  /** The element acted on, when the action named one. */
  readonly element?: ElementRef
  /** Whether an element that had been replaced was found again by role and name. */
  readonly recovered?: boolean
  /**
   * Where the focus is after a call that could move it, when the call named no
   * element to say it with.
   *
   * A bare key press is the shape this exists for: `Shift+Tab` walks the focus
   * somewhere the caller cannot see, and "on whatever the page has focused" told
   * it nothing about where the next `Enter` would land. Read from the tree, so
   * it is named the way a snapshot names an element.
   */
  readonly focused?: ElementRef
  /**
   * What was over the point a click used, when it was not the element itself.
   *
   * A click goes to coordinates, so an open menu's backdrop or a sticky header
   * takes it instead and the page answers that nothing changed; without this a
   * model can only conclude that the element does nothing.
   */
  readonly obstructed?: ElementRef
  /** Dialogs the pages opened during this call, and what was answered. */
  readonly dialogs?: readonly DialogReport[]
  /**
   * The visible labels of the options a selection chose.
   *
   * A native `<select>` is set rather than pressed (see `select`), so this is
   * the page's answer to which of the requested values its options held — the
   * fact a caller needs to know whether the words it asked for were the words
   * the page uses.
   */
  readonly selected?: readonly string[]
  /** The state a checkbox or radio holds once a `check` call is done. */
  readonly checked?: boolean
  /**
   * Whether the page is a document that runs no script of its own.
   *
   * A response carrying `Content-Security-Policy: …; sandbox` without
   * `allow-scripts` — a raw file from GitHub's content host is the case that
   * found this — is rendered and readable, but nothing in it can run: no timer,
   * no event handler, no page script. Reported because it changes what the rest
   * of the result means: "the page did not change" is not evidence about an
   * action there, and `settled` cannot be observed at all.
   */
  readonly staticDocument?: boolean
}

/** A snapshot plus where in the page it was taken. */
export interface PageSnapshot extends AxSnapshot {
  /** Viewport and scroll position at the time. */
  readonly info: PageInfo
}

/**
 * How one call names the element it acts on.
 *
 * A ref is an answer a snapshot gave about one document, so it is cheap to
 * check and goes stale when the page re-renders or navigates. A locator is the
 * question that answer came from, asked again at the moment of the action, so
 * it survives both — at the price of having to resolve, which is why an
 * ambiguous one refuses rather than picks.
 */
export type ElementTarget = string | Locator

/** One `DOM.describeNode` result, as far as this plugin reads it. */
interface DomNode {
  readonly backendNodeId?: number
  readonly children?: readonly DomNode[]
}

/**
 * Fields a running browser was launched from; changing one requires a new browser.
 *
 * The port window is deliberately absent. What a browser listens on is the port
 * the allocator handed it, not a configuration value, so moving the window only
 * decides where the *next* browser may listen — a settings tweak that should not
 * close browsers someone is watching. The ports already handed out stay held
 * until their browsers close.
 */
const LAUNCH_FIELDS = [
  'channel', 'executablePath', 'headless', 'userDataDir',
  'viewportWidth', 'viewportHeight', 'startupUrl', 'stealth',
] as const

/** Whether two configurations would start the same browser. */
export function sameLaunch(left: BrowserConfig, right: BrowserConfig): boolean {
  return LAUNCH_FIELDS.every(field => left[field] === right[field])
    && left.extraArgs.join('\u0000') === right.extraArgs.join('\u0000')
}

/** Whether two configurations encode frames the same way. */
export function sameEncoding(left: BrowserConfig, right: BrowserConfig): boolean {
  return left.quality === right.quality
    && left.maxWidth === right.maxWidth
    && left.maxHeight === right.maxHeight
    && left.everyNthFrame === right.everyNthFrame
}

/**
 * Pause for a moment, for the loops that have to keep asking a page something.
 *
 * There is no timer to clear: the longest anyone waits is one poll interval or
 * the remainder of a budget, and both are bounded by the call's own deadline —
 * a cancelled call stops waiting because the whole call is raced against the
 * caller's signal, not because this is interruptible on its own.
 * @param ms - how long to pause, in milliseconds.
 * @returns a promise that resolves after the pause.
 */
async function sleep(ms: number): Promise<void> {
  await new Promise(resolve => setTimeout(resolve, ms))
}

/**
 * Whether a CDP failure means the element behind a ref is no longer in the DOM.
 *
 * Chrome answers a call about a removed node in a few different ways depending
 * on the call, and each of them is worth one attempt to find the element again;
 * anything else — a page that threw, a browser that went away — is the caller's
 * error and is reported as it is.
 * @param error - what the protocol call rejected with.
 * @returns whether the element itself is gone.
 */
function elementGone(error: unknown): boolean {
  const message = error instanceof Error ? error.message : String(error)
  return /no node with given id|node with given id|no node found|could not find node|detached|not attached/iu.test(message)
}

/**
 * Chrome's own words from a protocol failure.
 *
 * A transport wraps every protocol error as `cdpSession.send: Protocol error
 * (DOM.focus): Element is not focusable`, and only the last part is the browser
 * speaking. Quoting the wrapper at a model gives it a sentence about this
 * plugin's plumbing where the page's own reason belongs.
 * @param error - what the protocol call rejected with.
 * @returns the reason, without the transport's framing.
 */
function protocolReason(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error)
  const said = /Protocol error \([^)]*\):\s*([\s\S]+)$/u.exec(message)
  return said?.[1]?.trim() ?? message
}

/**
 * The in-page expression an action settles with.
 *
 * It reports how many mutation records the page produced while the observer was
 * installed, whether the page went quiet inside the budget, and a bounded
 * summary of what actually changed — which is what turns "the click returned"
 * into "the page stopped moving, and this is what appeared".
 *
 * The summary is written here rather than on this side because this is where the
 * changed nodes are: a mutation record hands over live nodes, and a node is gone
 * (or has already been re-rendered again) by the time anything outside the page
 * could ask about it. What it may say about a node is therefore limited to what
 * the DOM itself answers — the tag, a `role` attribute, and a short piece of
 * text — and the result is read as a *page's* description of itself: the
 * snapshot is still the authority on accessible roles and names.
 *
 * Everything in here is written defensively, because a page is arbitrary code:
 * a node that throws when read is skipped rather than allowed to end the
 * summary, and the promise resolves either way.
 * @returns the expression to evaluate in the page.
 */
export function settleProbe(): string {
  return `new Promise((resolve) => {
    const LIMIT = ${String(CHANGE_LIMIT)}
    const TEXT_MAX = ${String(CHANGE_TEXT_MAX)}
    // Elements that draw nothing. A stylesheet or a script landing in the page
    // is not something a reader of the page can see or act on, and CSS-in-JS
    // libraries rewrite one on nearly every render — left in, they would fill
    // the summary with the machinery instead of the page.
    const UNSEEN = ['script', 'style', 'link', 'meta', 'title', 'template', 'noscript', 'base']
    let mutations = 0
    let items = 0
    let quiet = 0
    let cap = 0
    const changes = []
    const seen = new Map()
    const clip = (value) => {
      const one = String(value === undefined || value === null ? '' : value).replace(/\\s+/gu, ' ').trim()
      return one.length > TEXT_MAX ? one.slice(0, TEXT_MAX) + '…' : one
    }
    const attributeOf = (element, name) => {
      try { return element.getAttribute === undefined ? null : element.getAttribute(name) } catch { return null }
    }
    const where = (node, fallback) => {
      const element = node !== null && node.nodeType === 1 ? node : (node !== null && node.parentElement) || fallback
      if (element === null || element === undefined) return {}
      const tag = String(element.tagName === undefined ? '' : element.tagName).toLowerCase()
      const change = tag === '' ? {} : { tag }
      const role = attributeOf(element, 'role')
      if (role) change.role = clip(role)
      return change
    }
    // What one node says for itself. A text node says its own text; an element
    // says the label the page gave it, then what it holds — and a container is
    // never asked on another node's behalf, because the container's whole text is
    // not what the change said.
    const saidBy = (node) => {
      let says = ''
      if (node !== null && node.nodeType === 1) {
        says = attributeOf(node, 'aria-label') || attributeOf(node, 'placeholder')
          || (node.textContent === undefined || node.textContent === null ? '' : node.textContent)
          || (node.value === undefined || node.value === null ? '' : node.value)
      } else if (node !== null && node.nodeType === 3 && node.data !== undefined) {
        says = node.data
      }
      const preview = clip(says)
      return preview === '' ? {} : { preview }
    }
    const unseen = (change) => UNSEEN.indexOf(change.tag === undefined ? '' : change.tag) !== -1
    const once = (node, key) => {
      let keys = seen.get(node)
      if (keys === undefined) { keys = new Set(); seen.set(node, keys) }
      if (keys.has(key)) return false
      keys.add(key)
      return true
    }
    const note = (kind, node, fallback, rest) => {
      const change = { kind, ...where(node, fallback), ...rest }
      if (unseen(change)) return
      items += 1
      if (changes.length < LIMIT) changes.push(change)
    }
    const finish = (settled) => {
      observer.disconnect()
      clearTimeout(quiet)
      clearTimeout(cap)
      resolve({ mutations, settled, changes, omitted: items - changes.length })
    }
    const observer = new MutationObserver((records) => {
      for (const record of records) {
        mutations += 1
        try {
          if (record.type === 'attributes') {
            const name = record.attributeName
            if (name && once(record.target, 'a:' + name)) {
              const now = attributeOf(record.target, name)
              note('attribute', record.target, undefined, {
                ...saidBy(record.target),
                attribute: name,
                ...record.oldValue === null || record.oldValue === undefined ? {} : { from: clip(record.oldValue) },
                ...now === null || now === undefined ? {} : { to: clip(now) },
              })
            }
          } else if (record.type === 'characterData') {
            if (once(record.target, 't')) {
              const now = record.target.data
              note('text', record.target, undefined, {
                ...record.oldValue === null || record.oldValue === undefined ? {} : { from: clip(record.oldValue) },
                ...now === null || now === undefined ? {} : { to: clip(now) },
              })
            }
          } else {
            // A record that only added or only removed children leaves the other
            // list out, and a page is free to hand over anything else besides.
            const added = record.addedNodes || []
            const removed = record.removedNodes || []
            // One text node replaced by another under the same parent is how the
            // browser reports an assignment to textContent, which is how most
            // pages rewrite a run of text. Read literally it is a node going and a
            // node arriving, and a page that changed "24.1k" to "24.2k" would
            // spend two of the few reported changes saying so twice.
            if (added.length === 1 && removed.length === 1
              && added[0].nodeType === 3 && removed[0].nodeType === 3) {
              if (once(record.target, 'text')) {
                note('text', record.target, undefined, {
                  from: clip(removed[0].data),
                  to: clip(added[0].data),
                })
              }
            } else {
              // A removed node has no parent left to be described by, so the
              // element that lost it is what the change is reported against —
              // and what it said is the node's own text, not the container's.
              for (const node of removed) {
                if (once(node, 'removed')) note('removed', node, record.target, saidBy(node))
              }
              for (const node of added) {
                if (once(node, 'added')) note('added', node, record.target, saidBy(node))
              }
            }
          }
        } catch {
          // A node this cannot read is not a reason to stop watching the page.
        }
      }
      clearTimeout(quiet)
      quiet = setTimeout(() => { finish(true) }, ${String(SETTLE_QUIET_MS)})
    })
    observer.observe(globalThis.document.documentElement ?? globalThis.document, {
      subtree: true, childList: true, attributes: true, characterData: true,
      attributeOldValue: true, characterDataOldValue: true,
    })
    quiet = setTimeout(() => { finish(true) }, ${String(SETTLE_QUIET_MS)})
    cap = setTimeout(() => { finish(false) }, ${String(SETTLE_MAX_MS)})
  })`
}

/**
 * One change a page reported, as far as a result may carry it.
 *
 * The record arrives from the page, so this is a boundary and not a cast: a
 * field of the wrong type is dropped rather than passed on, an entry with a kind
 * this result does not declare is dropped with it, and anything said at greater
 * length than a result may be is cut at the same bound the page was given.
 * @param entry - one entry of the record a settle probe resolved with.
 * @returns the change, or `undefined` when the page did not describe one.
 */
function readChange(entry: unknown): DomChange | undefined {
  if (typeof entry !== 'object' || entry === null) return undefined
  const reported = entry as Record<string, unknown>
  const kind = reported['kind']
  if (kind !== 'added' && kind !== 'removed' && kind !== 'attribute' && kind !== 'text') return undefined
  /** One field, when the page said it as a string worth printing. */
  const said = (field: string): string | undefined => {
    const value = reported[field]
    if (typeof value !== 'string') return undefined
    // An empty string is dropped from every field except the two that compare
    // before and after: a boolean attribute is spelled `disabled=""`, so "the
    // attribute was there and empty" is a real value and the only thing that
    // tells an addition from a removal. Measured 2026-09-29 on a real button:
    // without this, `disabled` being added and being removed both printed as
    // `(none) → (none)`.
    if (value === '' && field !== 'from' && field !== 'to') return undefined
    return value.length > CHANGE_TEXT_MAX ? `${value.slice(0, CHANGE_TEXT_MAX)}…` : value
  }
  const fields = Object.fromEntries(
    (['tag', 'role', 'preview', 'attribute', 'from', 'to'] as const)
      .map(field => [field, said(field)] as const)
      .filter(([, value]) => value !== undefined),
  ) as Pick<DomChange, 'tag' | 'role' | 'preview' | 'attribute' | 'from' | 'to'>
  return { kind, ...fields }
}

/**
 * Where a thing the browser reported came from.
 *
 * A line only when the protocol gave one: the same field carries a resource URL
 * for a failed request, where a line number would be invented.
 * @param url - the source the protocol named.
 * @param line - the zero-based line, when the protocol named one.
 * @returns the source with its line, or `undefined` when there is no source.
 */
function whereFrom(url: unknown, line: unknown): string | undefined {
  if (typeof url !== 'string' || url === '') return undefined
  return typeof line === 'number' && Number.isFinite(line) && line >= 0
    ? `${url}:${String(Math.floor(line) + 1)}`
    : url
}

/**
 * When the browser recorded something.
 *
 * The timestamp is the browser's, not this process's, so the two differ when the
 * renderer is on another machine; the protocol's own instant is the one that
 * orders correctly against the events around it.
 * @param timestamp - the protocol's timestamp in milliseconds since the epoch.
 * @returns an ISO 8601 instant.
 */
function instantOf(timestamp: unknown): string {
  const ms = typeof timestamp === 'number' && Number.isFinite(timestamp) ? timestamp : Date.now()
  return new Date(ms).toISOString()
}

/**
 * One page argument as the browser rendered it.
 *
 * `value` is what a primitive logged as; `description` is all an object gets,
 * and it names the shape rather than the contents ("Object", "Array(3)",
 * "div#app"); `unserializableValue` is `NaN`, `Infinity`, or `-0`, which no JSON
 * form can carry. The object *preview* the protocol attaches is used when it is
 * there, which is what turns a logged `{a: 1}` into something worth reading.
 * @param arg - one `Runtime.RemoteObject` from a console call.
 * @returns the argument as text.
 */
function argumentText(arg: unknown): string {
  if (arg === null || typeof arg !== 'object') return String(arg)
  const remote = arg as {
    value?: unknown
    unserializableValue?: unknown
    description?: unknown
    type?: unknown
    preview?: unknown
  }
  if (remote.value !== undefined) {
    return typeof remote.value === 'string' ? remote.value : JSON.stringify(remote.value) ?? String(remote.value)
  }
  if (typeof remote.unserializableValue === 'string') return remote.unserializableValue
  const preview = previewText(remote.preview)
  if (preview !== undefined) return preview
  if (typeof remote.description === 'string') return remote.description
  return typeof remote.type === 'string' ? remote.type : '?'
}

/**
 * A logged object as far as the protocol's preview describes it.
 * @param preview - one `Runtime.ObjectPreview`, when the protocol sent one.
 * @returns the object in braces, or `undefined` when there is nothing to read.
 */
function previewText(preview: unknown): string | undefined {
  if (preview === null || typeof preview !== 'object') return undefined
  const record = preview as { description?: unknown; overflow?: unknown; properties?: unknown }
  if (!Array.isArray(record.properties)) return undefined
  const shown = record.properties.slice(0, 5)
  const parts = shown.map((property) => {
    const item = property as { name?: unknown; type?: unknown; value?: unknown }
    const name = typeof item.name === 'string' ? item.name : '?'
    if (item.type === 'string' && typeof item.value === 'string') return `${name}: ${JSON.stringify(item.value)}`
    if (item.value !== undefined) return `${name}: ${String(item.value)}`
    return `${name}: ${typeof item.type === 'string' ? item.type : '?'}`
  })
  if (record.overflow === true || record.properties.length > shown.length) parts.push('…')
  // "Object {…}" says the same thing twice; every other description names a shape
  // the braces cannot (`Array(3)`, `div#app`, `Map(2)`).
  const said = typeof record.description === 'string' && record.description !== 'Object'
    ? `${record.description} `
    : ''
  return `${said}{${parts.join(', ')}}`
}

/**
 * The level a console call's own kind maps to.
 *
 * The protocol says `warning` where the console says `warn`, and it has kinds
 * this plugin does not have levels for (`dir`, `table`, `count`); those are
 * ordinary output and read as `log`.
 * @param kind - the protocol's `type`.
 * @returns the normalized level.
 */
function consoleLevelOf(kind: unknown): ConsoleEntry['level'] {
  if (kind === 'debug') return 'debug'
  if (kind === 'info') return 'info'
  if (kind === 'warning' || kind === 'warn') return 'warn'
  if (kind === 'error' || kind === 'assert') return 'error'
  return 'log'
}

/** Clip one message to the length a console result may carry. */
function clipped(message: string): string {
  return message.length > CONSOLE_TEXT_MAX ? `${message.slice(0, CONSOLE_TEXT_MAX)}…` : message
}

/**
 * Read one `Runtime.consoleAPICalled` event.
 * @param event - the event payload.
 * @returns the entry, or `undefined` when the event carries nothing readable.
 */
function readConsoleCall(event: unknown): ConsoleEntry | undefined {
  if (event === null || typeof event !== 'object') return undefined
  const record = event as { type?: unknown; args?: unknown; timestamp?: unknown; stackTrace?: unknown }
  const args = Array.isArray(record.args) ? record.args : []
  const message = clipped(args.map(argumentText).join(' '))
  if (message === '') return undefined
  const frames = (record.stackTrace as { callFrames?: unknown } | undefined)?.callFrames
  const frame = Array.isArray(frames) ? frames[0] as { url?: unknown; lineNumber?: unknown } | undefined : undefined
  const url = whereFrom(frame?.url, frame?.lineNumber)
  return {
    level: consoleLevelOf(record.type),
    message,
    timestamp: instantOf(record.timestamp),
    ...url === undefined ? {} : { url },
  }
}

/**
 * Read one `Runtime.exceptionThrown` event.
 * @param event - the event payload.
 * @returns the entry, or `undefined` when the event carries nothing readable.
 */
function readExceptionThrown(event: unknown): ConsoleEntry | undefined {
  if (event === null || typeof event !== 'object') return undefined
  const record = event as { timestamp?: unknown; exceptionDetails?: unknown }
  const details = record.exceptionDetails as {
    text?: unknown
    url?: unknown
    lineNumber?: unknown
    exception?: { description?: unknown }
  } | undefined
  if (details === null || typeof details !== 'object') return undefined
  const described = details.exception?.description
  const message = typeof described === 'string' && described !== ''
    ? described
    : typeof details.text === 'string' ? details.text : 'an uncaught error'
  const url = whereFrom(details.url, details.lineNumber)
  return {
    level: 'error',
    message: clipped(message),
    timestamp: instantOf(record.timestamp),
    ...url === undefined ? {} : { url },
  }
}

/**
 * Read one `Log.entryAdded` event: what the browser itself reported, which is
 * where a failed request or a blocked resource shows up.
 * @param event - the event payload.
 * @returns the entry, or `undefined` when the event carries nothing readable.
 */
function readLogEntry(event: unknown): ConsoleEntry | undefined {
  if (event === null || typeof event !== 'object') return undefined
  const entry = (event as { entry?: unknown }).entry as {
    level?: unknown
    text?: unknown
    timestamp?: unknown
    url?: unknown
    lineNumber?: unknown
  } | undefined
  if (entry === null || typeof entry !== 'object') return undefined
  if (typeof entry.text !== 'string' || entry.text === '') return undefined
  const url = whereFrom(entry.url, entry.lineNumber)
  return {
    // The browser log has one level this plugin has no word for: `verbose` is
    // everything the network layer says when nothing is wrong.
    level: entry.level === 'verbose' ? 'debug' : consoleLevelOf(entry.level),
    message: clipped(entry.text),
    timestamp: instantOf(entry.timestamp),
    ...url === undefined ? {} : { url },
  }
}

/**
 * Where a press on a ref's element would land, as the page itself reports it.
 *
 * `moved` says the box was still changing while the page's next two frames were
 * waited for; the coordinates are from the later reading either way. `outside`
 * says the page put the point outside the viewport a press can be dispatched in,
 * which is a refusal rather than a press at nothing.
 */
interface PressPoint {
  /** X in the pixels input is dispatched in, in the top frame. */
  readonly x: number
  /** Y in the pixels input is dispatched in, in the top frame. */
  readonly y: number
  /** Whether the box moved while the next two frames were awaited. */
  readonly moved: boolean
  /** Whether the point is outside the outermost viewport this plugin can see. */
  readonly outside: boolean
  /** Whether the page says the element cannot take a press at all. */
  readonly disabled: boolean
  /** What the page says is at the point, when it is not the element. */
  readonly over?: ElementRef
}

/**
 * The in-page question "would the page take a press on this element".
 *
 * One string because two callers ask it: a press, before it is dispatched, and a
 * wait that was asked for an element that can actually be acted on. The
 * `:disabled` pseudo-class is the question rather than the `disabled` property,
 * because the pseudo-class is what a disabled fieldset, optgroup, or datalist
 * propagates through, and the walk up is what catches an element inside a
 * disabled control — a press on the span inside a disabled button reaches
 * nothing. It is a snippet rather than a whole probe so the two cannot drift.
 */
const REFUSES_A_PRESS_JS = `const refuses = (node) => {
      let current = node
      for (let hop = 0; current !== null && hop < 32; hop += 1) {
        try {
          if (typeof current.matches === 'function' && current.matches(':disabled')) return true
        } catch {
          // A node this cannot be asked about is not disabled by that fact.
        }
        if (current.getAttribute !== undefined && current.getAttribute('aria-disabled') === 'true') return true
        current = current.parentElement
      }
      return false
    }`

/**
 * The in-page question a wait asks about the element it matched.
 *
 * The same question a press asks, so a wait for "an element I can act on" cannot
 * disagree with the press that follows it.
 * @returns the function to call on the element a condition matched.
 */
function enabledProbe(): string {
  return `function () {
    ${REFUSES_A_PRESS_JS}
    return { dis: refuses(this.nodeType === 1 ? this : this.parentElement) }
  }`
}

/**
 * The page's own verdict on whether an element can take a press.
 *
 * A page that says nothing usable does not block a wait: this is a question the
 * page answers, not a requirement it has to satisfy, and the same shape of
 * answer — a node CDP has already replaced — leaves the element counting as one
 * the caller can act on rather than as a refusal invented here.
 * @param cdp - session attached to the active page.
 * @param backendNodeId - the element to ask about.
 * @returns whether the page says the element is disabled.
 */
async function refusesPress(cdp: CDPSession, backendNodeId: number): Promise<boolean> {
  const resolved = await cdp.send('DOM.resolveNode', { backendNodeId })
    .catch(() => undefined) as { object?: { objectId?: string } } | undefined
  const objectId = resolved?.object?.objectId
  if (objectId === undefined) return false
  const answer = await cdp.send('Runtime.callFunctionOn', {
    objectId,
    functionDeclaration: enabledProbe(),
    returnByValue: true,
  }).catch(() => undefined) as { result?: { value?: unknown } } | undefined
  const value = answer?.result?.value
  if (typeof value !== 'object' || value === null) return false
  return (value as Record<string, unknown>)['dis'] === true
}

/**
 * The in-page question "what does this document say it is".
 *
 * Asked of the document rather than read through the protocol's convenience,
 * because the convenience invents an answer when the page cannot give one:
 * measured 2026-09-29, a form POST that answers with the same page made
 * `page.title()` return `Loading <url>` — its own placeholder for "the
 * evaluation could not run" — and the report printed a title the page never
 * had. Waiting for the document to be readable is the wait the old read
 * skipped, and `performance.timeOrigin` comes back with it, so a comparison can
 * tell a replaced document from a twice-read one.
 * @returns the function to evaluate in the page.
 */
function documentProbe(): string {
  return `async function () {
    if (document.readyState === 'loading') {
      await new Promise((done) => document.addEventListener('DOMContentLoaded', done, { once: true }))
    }
    return { url: location.href, title: document.title, origin: performance.timeOrigin }
  }`
}

/** The page-side slot a selector's matches wait in, one call at a time. */
const MATCH_SLOT = '__dshMatches'

/**
 * The in-page question "what does this selector match, everywhere on the page".
 *
 * The DOM agent's own query selector is asked first, inside the probe, because
 * a selector the page cannot parse is a question that was never asked — and
 * reporting that as "no element matches" would send the caller looking for
 * another element instead of at its own typo. The walk then goes where the
 * agent's traversal cannot follow: an open shadow root through its host, and a
 * frame through its content document, same-origin only, which is the same
 * scope the accessibility tree splices. Measured 2026-09-29 on the browser
 * this plugin runs: the agent's query selector and `DOM.performSearch` both
 * answered zero for `#shadow-host .box` and `iframe[name=iframe1] button`,
 * although both elements exist.
 *
 * The matches are left in the page's slot and counted, rather than returned,
 * because a value that crosses the protocol boundary as a handle is what the
 * per-match node id needs.
 * @param selector - what the caller wrote.
 * @param slot - the page-side slot to leave the matches in.
 * @returns the expression to evaluate in the page.
 */
function selectorProbe(selector: string, slot: string): string {
  return `(() => {
    const selector = ${JSON.stringify(selector)}
    document.createDocumentFragment().querySelector(selector)
    const found = []
    const walk = (parent) => {
      for (const element of parent.children) {
        try {
          if (element.matches(selector)) found.push(element)
        } catch {
          // A node this cannot ask is not a match by that fact.
        }
        if (element.shadowRoot !== null) walk(element.shadowRoot)
        walk(element)
      }
    }
    const visit = (document, hops) => {
      if (hops > 8) return
      walk(document)
      for (const frame of document.querySelectorAll('iframe, frame')) {
        const inner = frame.contentDocument
        if (inner !== null) visit(inner, hops + 1)
      }
    }
    visit(globalThis.document, 0)
    globalThis.${slot} = found
    return found.length
  })()`
}

/** How many child frames one snapshot splices in, counting nested ones. */
const FRAME_TREES_MAX = 12

/**
 * The frame tree as `Page.getFrameTree` answers it: a frame and its children.
 *
 * The identifier is `id`. It is not `frameId`: measured 2026-09-29 against a
 * live Chrome, the keys of a `Page.Frame` are `["id","loaderId","url",…]` and
 * `frame.frameId` is `undefined`, so reading the wrong name silently returned
 * no frames at all and every page's iframe content stayed out of the snapshot.
 */
interface FrameTreePayload {
  readonly frame?: { readonly id?: string }
  readonly childFrames?: readonly FrameTreePayload[]
}

/**
 * The frame ids of every child frame in the tree, parents before children.
 *
 * The order matters: a nested frame's owner lives inside its parent frame's
 * content, so the parent has to be spliced in before the child can find where
 * it hangs.
 * @param tree - the payload `Page.getFrameTree` answered with.
 * @returns the child frame ids, deepest last.
 */
function childFrameIds(tree: FrameTreePayload | undefined): string[] {
  const ids: string[] = []
  const walk = (node: FrameTreePayload | undefined): void => {
    if (node === undefined) return
    for (const child of node.childFrames ?? []) {
      const id = child.frame?.id
      if (id !== undefined) ids.push(id)
      walk(child)
    }
  }
  walk(tree)
  return ids
}

/**
 * The in-page question a press asks about itself.
 *
 * The page is the authority on both halves: `getBoundingClientRect` is already
 * in the pixels input is dispatched in, and `elementFromPoint` is the same
 * question a real press asks. A shadow host is followed into its own tree so it
 * cannot be mistaken for something lying over the target, a `StaticText` ref is
 * answered by the element around it, and the box is read twice so an element
 * that is still moving is not pressed where it used to be.
 * @returns the function to call on the element a click is about to press.
 */
function pressProbe(): string {
  return `async function () {
    const element = this.nodeType === 1 ? this : this.parentElement
    if (element === null || typeof element.getBoundingClientRect !== 'function') return { ok: false }
    const box = () => element.getBoundingClientRect()
    const view = element.ownerDocument.defaultView
    const first = box()
    await new Promise((done) => {
      let waited = false
      const finish = () => { if (!waited) { waited = true; done() } }
      if (view !== null && typeof view.requestAnimationFrame === 'function') {
        view.requestAnimationFrame(() => view.requestAnimationFrame(finish))
      }
      // A page that never paints — a background tab — must not hold the press up.
      if (view !== null && typeof view.setTimeout === 'function') view.setTimeout(finish, 50)
    })
    const settled = box()
    const moved = Math.abs(settled.left - first.left) > 1 || Math.abs(settled.top - first.top) > 1
    if (settled.width === 0 && settled.height === 0) return { ok: false }
    const localX = settled.left + settled.width / 2
    const localY = settled.top + settled.height / 2
    // A press is dispatched in the top frame's pixels, so the point walks out of
    // every frame this element sits in.
    let x = localX
    let y = localY
    let outer = view
    let frame = view === null ? null : view.frameElement
    for (let hop = 0; frame !== null && hop < 32; hop += 1) {
      const frameBox = frame.getBoundingClientRect()
      x += frameBox.left
      y += frameBox.top
      const parent = frame.ownerDocument.defaultView
      outer = parent
      frame = parent === null ? null : parent.frameElement
    }
    const inView = outer !== null && x >= 0 && y >= 0 && x < outer.innerWidth && y < outer.innerHeight
    ${REFUSES_A_PRESS_JS}
    const disabled = refuses(element)
    if (!inView) return { ok: true, x, y, moved, inView, dis: disabled, mine: false, over: null }
    // What the page says is at the point, and whether that is the element or
    // something inside it: a press on either one reaches the element.
    const within = (node) => {
      let current = node
      for (let hop = 0; current !== null && hop < 64; hop += 1) {
        if (current === element) return true
        const parent = current.parentNode
        const root = typeof current.getRootNode === 'function' ? current.getRootNode() : null
        current = parent !== null ? parent : (root !== null && root.host !== undefined ? root.host : null)
      }
      return false
    }
    let top = element.ownerDocument.elementFromPoint(localX, localY)
    while (top !== null && top.shadowRoot !== null) {
      const inner = top.shadowRoot.elementFromPoint(localX, localY)
      if (inner === null || inner === top) break
      top = inner
    }
    const mine = top !== null && (top === element || element.contains(top) || within(top))
    if (mine || top === null) return { ok: true, x, y, moved, inView, dis: disabled, mine, over: null }
    const name = top.getAttribute('aria-label') ?? top.textContent ?? ''
    return {
      ok: true, x, y, moved, inView, dis: disabled, mine,
      over: {
        role: top.getAttribute('role') ?? top.tagName.toLowerCase(),
        name: String(name).replace(/\\s+/g, ' ').trim().slice(0, 80),
      },
    }
  }`
}

/**
 * Read what a page answered about a press.
 *
 * The answer is another program's output, so every field is checked before it is
 * believed; `'boxless'` is the page saying the element has no box at all, and
 * `undefined` is the page saying nothing this code can use.
 * @param value - the value `Runtime.callFunctionOn` returned.
 * @returns the point, `'boxless'`, or `undefined` when there was no usable answer.
 */
function readPress(value: unknown): PressPoint | 'boxless' | undefined {
  if (typeof value !== 'object' || value === null) return undefined
  const said = value as Record<string, unknown>
  if (said['ok'] === false) return 'boxless'
  if (said['ok'] !== true) return undefined
  const x = said['x']
  const y = said['y']
  if (typeof x !== 'number' || typeof y !== 'number') return undefined
  const over = said['over']
  const described = typeof over === 'object' && over !== null ? over as Record<string, unknown> : undefined
  const role = described?.['role']
  const name = described?.['name']
  return {
    x,
    y,
    moved: said['moved'] === true,
    outside: said['inView'] === false,
    disabled: said['dis'] === true,
    ...typeof role === 'string'
      ? { over: { role, name: typeof name === 'string' ? name : '' } }
      : {},
  }
}

/**
 * An element as an error names it.
 *
 * A nameless element is named by its role alone rather than as `svg ""`: the
 * quoted empty string reads as a bug in the message and tells the caller
 * nothing, and the role is the only fact there is to go on.
 * @param element - the role and name of an element.
 * @returns the role, followed by the quoted name when it has one.
 */
function elementName(element: { readonly role: string; readonly name: string }): string {
  return element.name === '' ? element.role : `${element.role} ${JSON.stringify(element.name)}`
}

/**
 * The error a ref gets when its element has no box to press.
 * @param target - the element the ref names.
 * @returns the error to throw.
 */
function boxlessError(target: { readonly role: string; readonly name: string }): Error {
  return new Error(`dsh-browser: ${elementName(target)} has no visible box in the page; take a new snapshot and try again`)
}

/**
 * What the page says about typing into the element a ref names.
 *
 * `accepts` is the answer; `why` is the page's own reason when it is no.
 */
interface TypedAnswer {
  /** Whether the focused control will take the text. */
  readonly accepts: boolean
  /** Why it will not, when it will not. */
  readonly why?: string
}

/**
 * The in-page question asked after a focus and before any text.
 *
 * `DOM.focus` succeeding is not the same as the characters landing in the
 * element: measured 2026-09-24 in real Chrome, `Input.insertText` into a
 * read-only input inserted nothing while the report still said the text had been
 * typed. Only the page knows whether the control it focused can hold text, so it
 * is asked — and asked about its own `activeElement`, because a focus that
 * landed somewhere else is the other way text goes missing.
 * @returns the function to call on the element a type is about to write into.
 */
function typedProbe(): string {
  return `function () {
    const element = this.nodeType === 1 ? this : this.parentElement
    if (element === null) return { accepts: false, why: 'it is not an element' }
    const active = element.ownerDocument.activeElement
    const focused = active !== null && (active === element || element.contains(active))
    // What would take the text is the control the page focused; when the focus
    // never landed, the element itself is all there is to ask, and its own state
    // is why the focus was refused — a disabled control rejects the focus before
    // any question about typing can be answered.
    const target = focused ? active : element
    if (target.disabled === true) return { accepts: false, why: 'it is disabled' }
    if (target.readOnly === true) return { accepts: false, why: 'it is read-only' }
    const tag = String(target.tagName === undefined ? '' : target.tagName).toLowerCase()
    const type = String(target.type === undefined ? '' : target.type).toLowerCase()
    const textless = ['button', 'checkbox', 'color', 'file', 'hidden', 'image', 'radio', 'range', 'reset', 'submit']
    const takes = tag === 'textarea'
      || (tag === 'input' && textless.indexOf(type) === -1)
      || target.isContentEditable === true
    if (!takes) return { accepts: false, why: 'it takes no typed text' }
    if (!focused) return { accepts: false, why: 'the page did not focus it' }
    return { accepts: true }
  }`
}

/**
 * Read what a page answered about typing.
 * @param value - the value `Runtime.callFunctionOn` returned.
 * @returns the answer, or `undefined` when the page said nothing this code can use.
 */
function readTyped(value: unknown): TypedAnswer | undefined {
  if (typeof value !== 'object' || value === null) return undefined
  const said = value as Record<string, unknown>
  if (said['accepts'] === true) return { accepts: true }
  if (said['accepts'] !== false) return undefined
  const why = said['why']
  return { accepts: false, why: typeof why === 'string' ? why : 'the page would not take it' }
}

/**
 * The error a ref gets when the page says the text would not land in it.
 * @param target - the element the ref names.
 * @param why - the page's reason.
 * @returns the error to throw.
 */
function untypableError(target: { readonly role: string; readonly name: string }, why: string): Error {
  return new Error(
    `dsh-browser: ${elementName(target)} would not take the text because ${why}; nothing was typed, `
    + 'so take a new snapshot and check the element',
  )
}

/** What a page answered about choosing options on a `<select>`. */
interface SelectAnswer {
  /** What the page did about it. */
  readonly kind: 'selected' | 'not-select' | 'disabled' | 'missing' | 'unreadable'
  /** The visible labels of the options that were chosen. */
  readonly selected?: readonly string[]
  /** The requested values that match no option. */
  readonly missed?: readonly string[]
  /** The option labels the control offers, for a refusal that can name one. */
  readonly choices?: readonly string[]
}

/**
 * The in-page question "take these options on the select this element belongs to".
 *
 * A native `<select>`'s popup is browser-process UI: a press opens it, but the
 * options have no box in the page, so a click on one has nowhere to land —
 * measured 2026-09-29, where a click reported `Clicked combobox` and the option
 * was refused for having no visible box, with advice that could never succeed.
 * Setting the selection and dispatching the page's own `input`/`change` events is
 * what the reference runtime's `select(ref, values)` does; each value matches an
 * option by its `value` or by its visible label.
 * @param values - the option values or visible labels to choose.
 * @returns the function to call on the element the caller named.
 */
function selectProbe(values: readonly string[]): string {
  return `function () {
    const named = this.nodeType === 1 ? this : this.parentElement
    if (named === null) return { kind: 'not-select' }
    const tag = String(named.tagName === undefined ? '' : named.tagName).toLowerCase()
    // Naming an <option> means the selection its <select> would take, which is
    // the shape a caller reaches for after a click on the option was refused.
    const control = tag === 'option' && typeof named.closest === 'function'
      ? named.closest('select')
      : named
    if (control === null || String(control.tagName === undefined ? '' : control.tagName).toLowerCase() !== 'select') {
      return { kind: 'not-select' }
    }
    ${REFUSES_A_PRESS_JS}
    if (refuses(control)) return { kind: 'disabled' }
    const wanted = ${JSON.stringify(values)}
    const options = Array.prototype.slice.call(control.options === undefined ? [] : control.options)
    const labelOf = (option) => {
      const label = option.label === undefined || option.label === null ? '' : String(option.label)
      const text = label !== '' ? label : String(option.textContent === undefined || option.textContent === null ? '' : option.textContent)
      const fallback = String(option.value === undefined || option.value === null ? '' : option.value)
      return (text === '' ? fallback : text).replace(/\s+/g, ' ').trim()
    }
    const chosen = []
    const missed = []
    const choices = []
    for (const option of options) choices.push(labelOf(option))
    for (const want of wanted) {
      const text = String(want)
      let found = null
      for (const option of options) {
        if (String(option.value === undefined ? '' : option.value) === text || labelOf(option) === text) { found = option; break }
      }
      if (found === null) missed.push(text)
      else chosen.push(found)
    }
    if (missed.length > 0) return { kind: 'missing', missed, choices: choices.slice(0, 40) }
    if (control.multiple !== true) for (const option of options) option.selected = false
    for (const option of chosen) option.selected = true
    control.dispatchEvent(new Event('input', { bubbles: true }))
    control.dispatchEvent(new Event('change', { bubbles: true }))
    return { kind: 'selected', selected: chosen.map(labelOf) }
  }`
}

/** One list of strings a page answered with, or `undefined` when it is not one. */
function readStrings(value: unknown): string[] | undefined {
  if (!Array.isArray(value)) return undefined
  const out: string[] = []
  for (const entry of value) {
    if (typeof entry !== 'string') return undefined
    out.push(entry.slice(0, 80))
  }
  return out
}

/**
 * Read what a page answered about a selection.
 * @param value - the value `Runtime.callFunctionOn` returned.
 * @returns the answer; `unreadable` is the page saying something this cannot use.
 */
function readSelect(value: unknown): SelectAnswer {
  if (typeof value !== 'object' || value === null) return { kind: 'unreadable' }
  const said = value as Record<string, unknown>
  const kind = said['kind']
  if (kind === 'not-select' || kind === 'disabled') return { kind }
  if (kind === 'selected') {
    const selected = readStrings(said['selected'])
    return selected === undefined ? { kind: 'unreadable' } : { kind: 'selected', selected }
  }
  if (kind === 'missing') {
    return {
      kind: 'missing',
      missed: readStrings(said['missed']) ?? [],
      choices: readStrings(said['choices']) ?? [],
    }
  }
  return { kind: 'unreadable' }
}

/** What a page answered about setting a checkbox or radio's state. */
interface CheckAnswer {
  /** What the page did about it. */
  readonly kind: 'set' | 'not-checkable' | 'disabled' | 'unreadable'
  /** The state the control is in once the call is done. */
  readonly checked?: boolean
  /** The element's tag, for a refusal that says what it is instead. */
  readonly tag?: string
  /** The element's type, for the same. */
  readonly type?: string
}

/**
 * The in-page question "set this checkbox or radio to that state".
 *
 * A press is the wrong tool for a control whose meaning is a state: a checkbox
 * that does not reflect its `checked` into an attribute changes no DOM, so a
 * click on it reports "the page did not change" and the caller cannot tell a
 * switch it flipped from one the page ignored. Setting the state and dispatching
 * the page's own events is what the reference runtime's `check(ref, checked)`
 * does; the answer is the state the control ended in.
 * @param wanted - the state to set.
 * @returns the function to call on the element the caller named.
 */
function checkProbe(wanted: boolean): string {
  return `function () {
    const element = this.nodeType === 1 ? this : this.parentElement
    if (element === null) return { kind: 'not-checkable' }
    const tag = String(element.tagName === undefined ? '' : element.tagName).toLowerCase()
    const type = String(element.type === undefined ? '' : element.type).toLowerCase()
    if (tag !== 'input' || (type !== 'checkbox' && type !== 'radio')) {
      return { kind: 'not-checkable', tag, type }
    }
    ${REFUSES_A_PRESS_JS}
    if (refuses(element)) return { kind: 'disabled', tag, type }
    const wanted = ${wanted ? 'true' : 'false'}
    if (element.checked !== wanted) {
      element.checked = wanted
      element.dispatchEvent(new Event('input', { bubbles: true }))
      element.dispatchEvent(new Event('change', { bubbles: true }))
    }
    return { kind: 'set', checked: element.checked === true, tag, type }
  }`
}

/**
 * Read what a page answered about setting a checked state.
 * @param value - the value `Runtime.callFunctionOn` returned.
 * @returns the answer; `unreadable` is the page saying something this cannot use.
 */
function readCheck(value: unknown): CheckAnswer {
  if (typeof value !== 'object' || value === null) return { kind: 'unreadable' }
  const said = value as Record<string, unknown>
  const kind = said['kind']
  const tag = typeof said['tag'] === 'string' ? said['tag'].slice(0, 40) : undefined
  const type = typeof said['type'] === 'string' ? said['type'].slice(0, 40) : undefined
  if (kind === 'not-checkable') {
    return { kind, ...tag === undefined ? {} : { tag }, ...type === undefined ? {} : { type } }
  }
  if (kind === 'disabled') {
    return { kind, ...tag === undefined ? {} : { tag }, ...type === undefined ? {} : { type } }
  }
  if (kind === 'set' && typeof said['checked'] === 'boolean') {
    return { kind, checked: said['checked'], ...tag === undefined ? {} : { tag }, ...type === undefined ? {} : { type } }
  }
  return { kind: 'unreadable' }
}

/**
 * One call's source, wrapped so its declarations belong to that call.
 *
 * The page's global scope keeps what an earlier call declared: a `const` or
 * `class` of the same name is a syntax error before anything runs. A block is
 * enough to give the source a scope of its own, and the block's completion value
 * is what the call would have produced unwrapped.
 * @param expression - the caller's source.
 * @returns the source as one block statement.
 */
function scopedBlock(expression: string): string {
  return `{\n${expression}\n}`
}

/**
 * One call's source, as the body of an async function.
 *
 * `return` is a statement, not an expression, so a caller that ends its code
 * with one gets a compile error from the page instead of a value — even though
 * "run this and give me what it returns" is exactly what the tool promises, and
 * exactly what the reference runtime's program form allows. The body of an
 * async function is where that statement belongs, and it is the same scope the
 * `await` retry already needs, so the two are one change rather than two.
 * @param expression - the caller's source.
 * @returns the source as an immediately-invoked async function's body.
 */
function asyncBody(expression: string): string {
  return `(async () => {\n${expression}\n})()`
}

/**
 * The box a content quad describes.
 *
 * The quad's corners are averaged into nothing here: a box is the smallest
 * upright rectangle around every corner, which is what a reader comparing two
 * elements' positions wants, while the click path uses the corners themselves
 * so that a rotated element is still pressed inside itself.
 * @param quad - eight numbers, `x1 y1 x2 y2 x3 y3 x4 y4`, in CSS pixels.
 * @returns the box, or `undefined` when there was no usable quad.
 */
function boundingBoxOf(quad: readonly number[] | undefined): Box | undefined {
  if (quad === undefined) return undefined
  const xs: number[] = []
  const ys: number[] = []
  for (let index = 0; index + 1 < quad.length; index += 2) {
    xs.push(quad[index] ?? 0)
    ys.push(quad[index + 1] ?? 0)
  }
  if (xs.length === 0) return undefined
  const left = Math.min(...xs)
  const top = Math.min(...ys)
  return {
    x: Math.round(left),
    y: Math.round(top),
    width: Math.round(Math.max(...xs) - left),
    height: Math.round(Math.max(...ys) - top),
  }
}

/** One captured page image. */
export interface Screenshot {
  /** Encoded JPEG bytes. */
  readonly jpeg: Buffer
  /** Page width at capture time, in CSS pixels. */
  readonly width: number
  /** Page height at capture time, in CSS pixels. */
  readonly height: number
  /** The element captured, when the caller named one. */
  readonly element?: ElementRef
}

/** A rectangle in the page's own CSS pixels, which is what a capture clip takes. */
interface PageBox {
  readonly x: number
  readonly y: number
  readonly width: number
  readonly height: number
}

/**
 * The in-page question a screenshot asks about an element.
 *
 * `Page.captureScreenshot`'s clip is in page pixels, not viewport pixels —
 * measured 2026-09-29 in `.prove/clip-space-probe.mjs`: with
 * `captureBeyondViewport: true` a clip at page y=1200 captured a striped block
 * that sat below a 400 px viewport, identically at scroll 0 and at scroll 900,
 * while the same rectangle read as viewport coordinates captured blank paper.
 * That is why nothing here scrolls the element into view: the coordinates are
 * the page's, so an element below the fold is captured where it is rather than
 * after the page has been moved — and moving the page is itself a change the
 * page can react to.
 *
 * A frame is walked out the same way a press walks one, adding each frame
 * element's own offset, so an embedded element is captured where the top
 * document shows it.
 * @returns the function to call on the element a screenshot is about to capture.
 */
function clipProbe(): string {
  return `function () {
    const element = this.nodeType === 1 ? this : this.parentElement
    if (element === null || typeof element.getBoundingClientRect !== 'function') return { ok: false }
    const box = element.getBoundingClientRect()
    const view = element.ownerDocument.defaultView
    if (box.width <= 0 || box.height <= 0) return { ok: false }
    let x = box.left + (view === null ? 0 : view.scrollX)
    let y = box.top + (view === null ? 0 : view.scrollY)
    let inner = view
    let frame = view === null ? null : view.frameElement
    for (let hop = 0; frame !== null && hop < 32; hop += 1) {
      const outer = frame.ownerDocument.defaultView
      const frameBox = frame.getBoundingClientRect()
      x += frameBox.left + (outer === null ? 0 : outer.scrollX)
      y += frameBox.top + (outer === null ? 0 : outer.scrollY)
      inner = outer
      frame = outer === null ? null : outer.frameElement
    }
    return { ok: true, x, y, width: box.width, height: box.height }
  }`
}

/**
 * Read the rectangle the page says an element occupies.
 * @param answer - what the page answered the clip probe with.
 * @returns the rectangle, or `undefined` when the page named no box.
 */
function readClip(answer: unknown): PageBox | undefined {
  if (answer === null || typeof answer !== 'object') return undefined
  const said = answer as { ok?: unknown; x?: unknown; y?: unknown; width?: unknown; height?: unknown }
  if (said.ok !== true) return undefined
  const numbers = [said.x, said.y, said.width, said.height]
  if (!numbers.every(value => typeof value === 'number' && Number.isFinite(value))) return undefined
  return {
    x: Math.floor(said.x as number),
    y: Math.floor(said.y as number),
    width: Math.max(1, Math.ceil(said.width as number)),
    height: Math.max(1, Math.ceil(said.height as number)),
  }
}

/**
 * Replace the user agent a headless build reports with the one its headful
 * build reports.
 *
 * Headless Chrome spells itself `HeadlessChrome/…`; the rest of the string is
 * byte-for-byte what the same build sends with a window, so the reported value
 * is edited rather than composed — no build number is guessed. `Network`'s
 * override is what makes the change reach requests; editing `navigator` alone
 * would leave the header intact.
 * @param cdp - session attached to the page.
 * @param page - page whose user agent is being replaced.
 */
async function hideHeadlessUserAgent(cdp: CDPSession, page: Page): Promise<void> {
  const reported = await page.evaluate(() => navigator.userAgent).catch(() => '')
  if (!reported.includes('Headless')) return
  await cdp.send('Network.setUserAgentOverride', { userAgent: reported.replace('Headless', '') })
}

/**
 * One conversation's browser, from its first use to its disposal.
 *
 * Several of these may point at one process; see the module comment for the
 * split. Everything reached through {@link host} is the process's, and
 * everything held here is this conversation's.
 */
export class SessionBrowser implements SessionParticipant {
  /** Pages watching this conversation's active page. */
  private readonly viewers = new Set<FrameListener>()
  private readonly watchers = new Set<(status: BrowserStatus) => void>()
  /** This conversation's session id. */
  readonly sessionId: string
  private readonly logger: Logger
  /**
   * The process serving this conversation, shared or private.
   *
   * Deliberately reachable from the pool and the tools, which need the process
   * half to key browsers by it rather than by session.
   */
  readonly host: SharedBrowser
  /** The page this conversation's tools and un-named mirror act on. */
  private page: Page | undefined
  /** The CDP session attached to {@link page}. */
  private cdp: CDPSession | undefined
  private stream: (() => Promise<void>) | undefined
  /**
   * The CSS viewport each page reported last, keyed by how it is driven: a
   * target id for a named page, `active` for the un-named one.
   *
   * Cached so a pointer move is not a round trip; a navigation replaces the
   * document and the viewport with it, and an adoption replaces which page
   * `active` means. It is this conversation's cache: two conversations on one
   * page need not share it, and a page this conversation never measured has no
   * entry to invalidate.
   */
  private readonly viewports = new Map<string, { at: number; size: { width: number; height: number } }>()
  /**
   * Labels this conversation's snapshots have handed out, by ref.
   *
   * It belongs to the page rather than to a snapshot: a ref taken before a menu
   * opened still names the element it named then, and re-printing the page does
   * not renumber the ones already handed out. A page that goes away takes its
   * labels with it, because a backend node id means nothing on another page.
   *
   * A registry per conversation, rather than one per browser: two conversations
   * on one browser read the same page with their own refs, and a shared registry
   * would have the second snapshot silently renumber the first one's `e1`.
   */
  private labels = new RefLabels()
  /**
   * The page a viewer's ask for a new page already produced, by the asking
   * record's id.
   *
   * The Sidebar tab that asks is the record: the same tab asking again — a pane
   * remounted by a tab switch, a Session change, or a client reload — is one ask
   * that has already been answered, not a second page. The answer is the page's
   * target id, so a page that is gone makes the next ask an open again.
   */
  private readonly openRequests = new Map<string, string>()
  /** How many settle probes this conversation has armed, for a slot no two share. */
  private settleSeq = 0
  /**
   * Dialogs answered since a tool last read them.
   *
   * Held until a result can carry them: a dialog cannot be in a snapshot or in
   * the accessibility tree, so a tool result is the only place the model ever
   * learns that one appeared.
   */
  private dialogs: DialogReport[] = []
  /** Dialogs that were already answered when the call in flight began. */
  private dialogsEarlier: DialogReport[] = []
  /**
   * What the current document has said about itself, oldest first.
   *
   * Filled by the page's own CDP session from the moment this class attaches to
   * it, because the failures worth explaining happen before a tool could ask:
   * a script that throws while loading has already thrown by the time anybody
   * thinks to listen. Cleared when the document is replaced — a message belongs
   * to the document that produced it, the same way a ref does.
   */
  private said: ConsoleEntry[] = []
  /** How many console entries were dropped because the buffer was full. */
  private dropped = 0
  /**
   * The dialog policies of the calls in flight, newest last.
   *
   * A dialog belongs to the call whose input caused it, and the newest call is
   * that call: two calls in flight on one page can only have arrived in the
   * order they are stacked. A dialog nobody announced is answered by the
   * default, which is to dismiss it.
   */
  private readonly policies: DialogPolicy[] = []
  /** The adoption running right now, if one is; resolved when none is. */
  private adoption: Promise<void> = Promise.resolve()
  /** The page that adoption is for; cleared when the browser lets its pages go. */
  private adoptingPage: Page | undefined
  /**
   * Whether the document on the active page runs script, by document.
   *
   * Keyed by `performance.timeOrigin`, which is what tells one document from the
   * next: a navigation replaces the entry rather than inheriting a verdict about
   * the document it replaced. Only a `false` measured on the document now loaded
   * is ever read, so the one stale case — a new document that happens to answer
   * the same origin — is settled by the measurement being repeated for it.
   */
  private liveScript: { readonly origin: number; readonly runs: boolean } | undefined

  /**
   * @param sessionId - the conversation this view serves.
   * @param deps - the process it drives, and where outcomes are reported.
   */
  constructor(sessionId: string, deps: SessionBrowserDeps) {
    this.sessionId = sessionId
    this.host = deps.host
    this.logger = deps.logger
    this.host.join(this)
  }

  // ---- The process half, as this conversation reads it -------------------
  //
  // These are the fields whose owner moved to `SharedBrowser`. They stay spelled
  // as fields because the logic below is long and measured, and rewriting it
  // around a different shape would spend the measurements to buy nothing.

  /** The browser's context, once one is running. */
  private get session(): BrowserSession | undefined {
    return this.host.session
  }

  private set session(next: BrowserSession | undefined) {
    this.host.session = next
  }

  /** The lifecycle state, which every conversation on this browser shares. */
  private get state(): BrowserState {
    return this.host.state
  }

  private get reason(): string | undefined {
    return this.host.reason
  }

  private set reason(next: string | undefined) {
    this.host.reason = next
  }

  /** The external CDP port the running browser listens on. */
  private get port(): number | undefined {
    return this.host.port
  }

  /** Whether the running browser has a window. */
  private get launchedHeadless(): boolean | undefined {
    return this.host.launchedHeadless
  }

  /**
   * Set while the user has stopped this browser and nothing has asked for one
   * since. A viewer is not a request, so the pane checks this before subscribing.
   */
  private get userClosed(): boolean {
    return this.host.userClosed
  }

  private set userClosed(next: boolean) {
    this.host.userClosed = next
  }

  /** Pages the browser holds, by their CDP target id. */
  private get pageIds(): Map<Page, string> {
    return this.host.pageIds
  }

  /** What each page last said its title was, by target id. */
  private get titles(): Map<string, string> {
    return this.host.titles
  }

  /** One mirror per page someone is watching, by target id. */
  private get mirrors(): Map<string, PageMirror> {
    return this.host.mirrors
  }

  /** The configuration in force for the browser serving this conversation. */
  private get config(): BrowserConfig {
    return this.host.activeConfig
  }

  /**
   * Adopt a new configuration.
   *
   * The process decides whether anything it was launched from changed, and
   * closes if so; this side then re-attaches the mirrors, because an encoding
   * change is a stream's own and every subscribed pane has to be re-attached.
   * @param next - the newly resolved configuration.
   * @returns after the browser has been restarted, when it had to be.
   */
  async reconfigure(next: BrowserConfig): Promise<void> {
    const previous = this.config
    const restarting = await this.host.reconfigure(next)
    if (restarting) {
      await this.openStreamForViewers()
      return
    }
    await this.restartStreams(next, previous)
  }

  /**
   * Re-attach this conversation's mirrors after an encoding change.
   *
   * Separate from {@link reconfigure} because a shared browser is reconfigured
   * once by whichever conversation asks first, while every conversation on it has
   * its own streams to restart. The encoding that changed is the configuration's,
   * so the caller passes the pair it knows about.
   * @param next - the new configuration.
   * @param previous - what the streams were running with.
   * @returns after the streams have been restarted.
   */
  async reconfigureMirrors(next: BrowserConfig, previous: BrowserConfig): Promise<void> {
    await this.restartStreams(next, previous)
  }

  /** The encoding half of a reconfiguration, for one conversation's streams. */
  private async restartStreams(next: BrowserConfig, previous: BrowserConfig): Promise<void> {
    if (this.state !== 'ready' && this.state !== 'starting') return
    if (sameEncoding(previous, next)) return
    if (this.viewers.size > 0) {
      await this.closeStream()
      await this.openStream()
    }
    // A named mirror keeps its own stream; an encoding change is its to apply
    // too, and a page that went away while it held a stream is dropped.
    for (const [targetId, mirror] of [...this.mirrors]) {
      if (mirror.viewers.size === 0) continue
      if (!this.host.owns(this.sessionId, targetId)) continue
      await this.attachMirrorStream(targetId, mirror).catch((error: unknown) => {
        this.logger.warn(error instanceof Error ? error : new Error(String(error)))
        this.dropMirror(targetId)
      })
    }
  }


  /**
   * The current status snapshot.
   *
   * The tab list is the pages this conversation owns and no others — the same
   * list the Sidebar's tabs are built from, and the same one a tool result
   * carries, so what the user sees and what the model is told are one list. On a
   * shared browser that is the whole of what keeps one conversation's pages out
   * of another's view; the process is common, the tab list is not.
   */
  status(): BrowserStatus {
    return {
      sessionId: this.sessionId,
      browserId: this.host.key,
      state: this.state,
      debugPort: this.port,
      version: this.session?.version,
      url: this.page?.url(),
      mode: this.launchedHeadless === undefined
        ? undefined
        : this.launchedHeadless ? 'headless' : 'headful',
      tabs: this.namedPages(),
      ownedPages: this.host.ownedBy(this.sessionId).length,
      error: this.reason,
    }
  }

  /**
   * The status snapshot with the titles the pages carry now.
   *
   * The title a page reported when it was adopted is a memory; this read asks
   * the browser's own target list — one call that never touches a renderer, so
   * a busy page cannot hold it — and falls back to the memory when the list
   * cannot be asked.
   * @returns the status, with a tab list as fresh as the browser can answer.
   */
  async statusAsync(): Promise<BrowserStatus> {
    return { ...this.status(), tabs: await this.pageTabs() }
  }

  /**
   * The pages this browser holds, each named by its CDP target id.
   *
   * Pages the browser no longer holds are left out, and so is a page this class
   * could not name: the sidebar can mirror only pages it can name, and a list
   * that counted an unnameable page would promise a tab that cannot exist.
   * @returns one entry per nameable page, in the browser's own order.
   */
  async pageTabs(): Promise<TabSummary[]> {
    const named = this.namedPages()
    if (named.length === 0) return []
    const fresh = await this.targetTitles()
    return named.map(tab => ({ ...tab, title: fresh.get(tab.targetId ?? '') ?? tab.title ?? '' }))
  }

  /**
   * The pages this conversation owns, in the browser's own page order.
   *
   * Ownership is what makes a shared browser usable: two conversations hold
   * different pages of one process, and each one's tab list is the pages it
   * created. A page whose target id is not known yet is left out, because a
   * Sidebar tab is addressed by that id, so a page without one is a page no tab
   * can open. The position an entry carries is the page's place in the browser's
   * whole list, which is what the browser's own tab order means.
   * @returns one entry per nameable page this conversation owns.
   */
  private namedPages(): TabSummary[] {
    const pages = this.host.pages()
    const named: TabSummary[] = []
    for (const [index, page] of pages.entries()) {
      const tab = this.summaryOf(page, index)
      if (tab !== undefined) named.push(tab)
    }
    return named
  }

  /**
   * One page as this conversation's tab list describes it.
   * @param page - the page.
   * @param index - its place in the browser's whole page list.
   * @returns the entry, or `undefined` for a page this conversation does not own.
   */
  private summaryOf(page: Page, index: number): TabSummary | undefined {
    const targetId = this.pageIds.get(page)
    if (targetId === undefined) return undefined
    // A page another conversation opened is not this one's to list, name, or
    // act on. That is the whole visible difference between a shared browser and
    // a private one, as far as a conversation can tell.
    if (!this.host.owns(this.sessionId, targetId)) return undefined
    return {
      index,
      url: page.url(),
      active: page === this.page,
      targetId,
      title: this.titles.get(targetId) ?? '',
    }
  }

  /**
   * One page's entry, positioned by the browser's own list.
   * @param page - the page, which the browser must hold.
   * @returns the entry, or `undefined` for a page this conversation does not own.
   */
  private summaryOfPage(page: Page): TabSummary | undefined {
    return this.summaryOf(page, this.host.pages().indexOf(page))
  }

  /**
   * Every page's current title, from one browser-level `Target.getTargets`.
   * @returns titles by target id; empty when the list cannot be asked.
   */
  private async targetTitles(): Promise<Map<string, string>> {
    return await this.host.targetTitles(TARGET_TITLES_MS)
  }

  /**
   * Observe status changes.
   * @param listener - called on every change, not on subscription.
   * @returns unsubscribe callback.
   */
  watch(listener: (status: BrowserStatus) => void): () => void {
    this.watchers.add(listener)
    return () => { this.watchers.delete(listener) }
  }

  /** Whether anyone is watching this browser's frames. */
  hasViewers(): boolean {
    return this.viewers.size > 0
  }

  /**
   * Start the browser if it is not running, joining an in-flight start.
   *
   * A browser that died or failed is started again here, which is what makes
   * any later request — a tool call, a viewer reconnecting, the pane's restart —
   * recover without reloading the plugin.
   * @returns after the browser is ready.
   * @throws {Error} when the browser cannot start, including when the profile
   * mode needs a workspace and this deployment cannot resolve one.
   */
  async ensure(): Promise<void> {
    const wasReady = this.host.state === 'ready'
    await this.host.ensure()
    await this.adoptIfUnset()
    // A viewer that stayed subscribed while the browser was being replaced is
    // still watching, and the screen cast died with the old process: it belongs
    // to the CDP session that went away. Nothing else re-attaches it — a viewer
    // only starts one when it arrives — so a pane that was open across a restart
    // or a crash would sit on its last frame forever.
    if (!wasReady && this.host.state === 'ready' && this.viewers.size > 0) {
      const mirror = await until(this.openStream(), START_MIRROR_MS)
      if (!mirror.settled) {
        this.logger.warn(new Error(
          `dsh-browser: session ${this.sessionId}'s page did not answer the mirror request; `
          + 'the browser is ready without it',
        ))
      }
    }
  }

  /**
   * Give this conversation an active page when it has none.
   *
   * A conversation that joins a browser another one started has no page of its
   * own: the page the browser came up on belongs to whoever asked for it. It
   * gets a page the first time it asks to do something, which is also the first
   * moment the page can be attributed to it.
   */
  private async adoptIfUnset(): Promise<void> {
    if (this.page !== undefined) return
    const running = this.host.pages()
    const mine = running.find(page => {
      const targetId = this.pageIds.get(page)
      return targetId !== undefined && this.host.owns(this.sessionId, targetId)
    })
    if (mine !== undefined) {
      await this.adopt(mine)
      return
    }
    // Nobody has a claim on the page the browser started with — not even the
    // conversation that started it, which claims it in `start`. Taking it here is
    // what makes the first conversation to ask work on a page that exists.
    const unclaimed = running.find(page => {
      const targetId = this.pageIds.get(page)
      return targetId === undefined || this.host.ownerOf(targetId) === undefined
    })
    if (unclaimed !== undefined) await this.adopt(unclaimed)
  }

  /**
   * Stop what the page is doing, for a call that was cancelled.
   *
   * A navigation still in flight is stopped and a script still executing is
   * terminated, because the call that started them has given up: left alone,
   * the page stays busy and the next call inherits work nobody is waiting for.
   * A browser that answers neither is not one the next call can use either, so
   * it is dropped and the call after it starts a fresh one — the alternative is
   * a browser that hangs every call from here on, which is what closing the
   * window by hand was the only way out of.
   * @returns after the browser has been told to stop, or has been dropped.
   */
  async interrupt(): Promise<void> {
    const cdp = this.cdp
    if (cdp === undefined) return
    const [loading, script] = await Promise.all([
      until(cdp.send('Page.stopLoading'), INTERRUPT_QUIET_MS),
      until(cdp.send('Runtime.terminateExecution'), INTERRUPT_QUIET_MS),
    ])
    if (loading.settled || script.settled) return
    this.logger.warn(new Error(
      `dsh-browser: session ${this.sessionId}'s browser did not answer after a cancelled call; dropping it`,
    ))
    // The browser is the shared thing, so a wedged process is dropped for every
    // conversation on it rather than left behind as a trap for the next one.
    await this.host.close()
    this.reason = UNREACHABLE_REASON
    this.setState('closed')
  }

  /**
   * Subscribe a viewer to the active page. The first subscriber starts the
   * stream, the last one leaving stops it.
   *
   * This is the un-named subscription: a viewer that names no page watches what
   * the tools act on, which is what the pane did before tabs named their page.
   * A pane that names one subscribes with {@link addPageViewer} instead.
   * @param listener - receives every frame while subscribed.
   * @returns unsubscribe callback.
   */
  addViewer(listener: FrameListener): () => void {
    this.viewers.add(listener)
    if (this.viewers.size === 1) void this.openStreamForViewers()
    return () => {
      this.viewers.delete(listener)
      if (this.viewers.size === 0) void this.closeStream()
    }
  }

  /**
   * Subscribe a viewer to one page, named by its CDP target id.
   *
   * The page must already exist — a viewer names a page the tab list reported,
   * and nothing here starts a browser to go looking for one. Two viewers of the
   * same page share one screen cast; the first one in starts it, the last one
   * out stops it and drops the session the mirror attached on.
   * @param listener - receives every frame of this page while subscribed.
   * @param targetId - the page's CDP target id, as the tab list reports it.
   * @returns unsubscribe callback.
   * @throws {Error} when no page by that id exists.
   */
  async addPageViewer(listener: FrameListener, targetId: string): Promise<() => void> {
    const existing = this.mirrors.get(targetId)
    if (existing !== undefined) {
      existing.viewers.add(listener)
      return this.pageViewerDisposer(existing, targetId, listener)
    }
    const mirror: PageMirror = {
      cdp: undefined as unknown as CDPSession,
      stop: async () => {},
      viewers: new Set<FrameListener>([listener]),
    }
    this.mirrors.set(targetId, mirror)
    try {
      await this.attachMirrorStream(targetId, mirror)
    } catch (error) {
      this.mirrors.delete(targetId)
      throw error
    }
    return this.pageViewerDisposer(mirror, targetId, listener)
  }

  /** The unsubscribe callback of one page viewer: last out closes the mirror. */
  private pageViewerDisposer(mirror: PageMirror, targetId: string, listener: FrameListener): () => void {
    return () => {
      mirror.viewers.delete(listener)
      if (mirror.viewers.size === 0 && this.mirrors.get(targetId) === mirror) {
        void this.closeMirror(targetId)
      }
    }
  }

  /** Attach a mirror's CDP session and screen cast, replacing any stream it had. */
  private async attachMirrorStream(targetId: string, mirror: PageMirror): Promise<void> {
    const page = this.pageByTargetId(targetId)
    if (page === undefined) {
      throw new Error(`dsh-browser: session ${this.sessionId} has no page ${targetId}`)
    }
    const context = this.session?.context
    if (context === undefined) throw new Error(this.unusable())
    const cdp = await context.newCDPSession(page)
    mirror.cdp = cdp
    await mirror.stop().catch(() => {})
    mirror.stop = await startScreencast(
      cdp,
      {
        quality: this.config.quality,
        maxWidth: this.config.maxWidth,
        maxHeight: this.config.maxHeight,
        everyNthFrame: this.config.everyNthFrame,
      },
      frame => { for (const viewer of mirror.viewers) viewer(frame) },
      (error: unknown) => {
        // A refused acknowledgement is the one failure that silently ends the
        // stream; nothing else observes it, so it is reported here.
        this.logger.warn(error instanceof Error ? error : new Error(String(error)))
      },
    )
  }

  /** Close one page's mirror: its last viewer left, or the page went away. */
  private async closeMirror(targetId: string): Promise<void> {
    const mirror = this.mirrors.get(targetId)
    if (mirror === undefined) return
    this.mirrors.delete(targetId)
    await mirror.stop().catch(() => {})
    await mirror.cdp.detach().catch(() => {})
  }

  /** Drop one page's mirror without ceremony: the page it watched is gone. */
  private dropMirror(targetId: string | undefined): void {
    if (targetId === undefined) return
    const mirror = this.mirrors.get(targetId)
    if (mirror === undefined) return
    this.mirrors.delete(targetId)
    void mirror.stop().catch(() => {})
  }

  /**
   * The page that answers to a CDP target id, if this conversation owns it.
   *
   * Ownership is enforced here rather than at each caller: on a shared browser a
   * target id is only unique inside the process, so every path that turns an id
   * into a page — a tool's `targetId`, a pane's page address, a close — has to
   * ask the same question. A page another conversation opened is a page this one
   * cannot see, name, or act on.
   * @param targetId - the page's CDP target id.
   * @returns the page, or `undefined` when this conversation does not own it.
   */
  private pageByTargetId(targetId: string): Page | undefined {
    const page = this.host.pageById(targetId)
    if (page === undefined) return undefined
    if (!this.host.owns(this.sessionId, targetId)) return undefined
    return page
  }

  /**
   * Answer a dialog a page opened, and remember what it asked.
   *
   * Nothing is left open. A page waiting on an answer runs no script, renders
   * nothing, and answers no protocol call that needs its main thread, so an
   * unanswered dialog is a browser that looks wedged for every call behind it —
   * which is why Playwright dismisses unhandled dialogs on its own, silently.
   * This does the same thing, in the open: the answer is the one the call
   * declared when it declared one, the answer that changes nothing otherwise,
   * and either way the result says a dialog appeared.
   * @param dialog - the dialog the page opened.
   */
  private answerDialog(dialog: Dialog): void {
    const policy = this.policies.at(-1)
    const accepted = policy?.action === 'accept'
    const opening = {
      type: dialog.type(),
      message: dialog.message(),
      defaultValue: dialog.defaultValue(),
    }
    const answer = accepted ? policy?.text ?? opening.defaultValue : ''
    // The page is blocked until this lands, and it is the page's to receive
    // rather than this code's to wait for: a rejection here is the dialog
    // having been taken away by something else, which the report still names.
    void (accepted ? dialog.accept(policy?.text) : dialog.dismiss()).catch(() => {})
    this.dialogs.push({
      ...opening,
      handled: accepted ? 'accepted' : 'dismissed',
      // Only a prompt is answered *with* something; an accepted alert or
      // confirm carries no text, and printing one would invent it.
      ...accepted && opening.type === 'prompt' ? { answer } : {},
    })
  }

  /**
   * Mark where one tool call begins, for the dialogs that may already be open.
   *
   * A dialog is answered the instant it appears, so one the pane's own user
   * opened is in the buffer before any tool call has run; without this the next
   * call reports it as the dialog *it* met. Moving the buffer aside at the
   * call's start is what lets the result say "this one was already open".
   *
   * Called by every path that later drains the buffer — the acting calls
   * through `underPolicy`, and the reading calls that report dialogs of their
   * own. A call that never drains leaves the buffer alone, which is harmless:
   * the next call that drains marks it then.
   */
  private beginCall(): void {
    if (this.dialogs.length === 0) return
    this.dialogsEarlier.push(...this.dialogs.map(dialog => ({ ...dialog, earlier: true })))
    this.dialogs = []
  }

  /**
   * The dialogs the pages have answered since this was last called.
   * @returns what each page asked and how it was answered, earliest first, with
   * the ones that were already open when the call began marked as such.
   */
  takeDialogs(): readonly DialogReport[] {
    const taken = [...this.dialogsEarlier, ...this.dialogs]
    this.dialogsEarlier = []
    this.dialogs = []
    return taken
  }

  /**
   * What the current document has said about itself.
   *
   * The reading half of the console listener: the entries were already collected
   * as they happened, so this is a filter and a page identity rather than a
   * protocol call — and it never starts a browser, because the question is about
   * a page that exists.
   *
   * The newest entries are the ones kept when a caller asks for fewer than
   * matched, because the last thing a page said before it went quiet is what
   * explains the quiet.
   * @param options - which levels to keep, a substring to match, and how many entries to return.
   * @returns the entries, how much of the buffer they are, and which page they came from.
   * @throws {Error} when nothing is open to read.
   */
  async pageConsole(options: {
    levels?: readonly string[]
    filter?: string
    limit?: number
  } = {}): Promise<ConsoleReport> {
    const page = this.page
    if (page === undefined) {
      throw new Error(
        'dsh-browser: nothing is open to read a console from; open an address with browser_navigate first',
      )
    }
    const wanted = options.levels === undefined || options.levels.length === 0
      ? undefined
      : new Set(options.levels.map(level => level.toLowerCase()))
    const needle = options.filter === undefined ? undefined : options.filter.toLowerCase()
    const matched = this.said.filter((entry) => {
      if (wanted !== undefined && !wanted.has(entry.level)) return false
      return needle === undefined || entry.message.toLowerCase().includes(needle)
    })
    const limit = Math.max(1, Math.floor(options.limit ?? CONSOLE_LIMIT))
    const state = await this.stateOf(page)
    return {
      entries: matched.slice(-limit),
      matched: matched.length,
      total: this.said.length,
      dropped: this.dropped,
      url: state.url,
      title: state.title,
    }
  }

  /**
   * Start collecting what the page says about itself.
   *
   * Subscribed rather than asked: these events have to be caught as they happen,
   * because the failure worth explaining is the one that leaves no other trace —
   * a script that throws while the document loads has already thrown by the time
   * any tool could ask about it. The protocol only sends them to a client that
   * enabled the domains first, so both enables happen here, at attach time.
   *
   * Neither enable is awaited into the caller's path: a page that does not answer
   * one is a page with an empty console, which is exactly what a page that said
   * nothing looks like.
   * @param cdp - the session attached to the page.
   */
  private async listenToConsole(cdp: CDPSession): Promise<void> {
    this.forgetSaid()
    cdp.on('Runtime.consoleAPICalled', (event: unknown) => { this.keep(readConsoleCall(event)) })
    cdp.on('Runtime.exceptionThrown', (event: unknown) => { this.keep(readExceptionThrown(event)) })
    cdp.on('Log.entryAdded', (event: unknown) => { this.keep(readLogEntry(event)) })
    await Promise.all([
      cdp.send('Runtime.enable').catch(() => undefined),
      cdp.send('Log.enable').catch(() => undefined),
    ])
  }

  /** Forget what the page said: a new document has its own console. */
  private forgetSaid(): void {
    this.said = []
    this.dropped = 0
  }

  /**
   * Keep one entry, and count what the buffer could not hold.
   * @param entry - the entry to keep, or `undefined` when the event said nothing readable.
   */
  private keep(entry: ConsoleEntry | undefined): void {
    if (entry === undefined) return
    this.said.push(entry)
    if (this.said.length <= CONSOLE_LIMIT) return
    this.said.shift()
    this.dropped += 1
  }

  /**
   * Run one call under the dialog policy it declared.
   * @param policy - the answer to give a dialog that opens while the call runs.
   * @param work - the call itself, from its first protocol call to its report.
   * @returns what the call produced.
   */
  private async underPolicy<T>(policy: DialogPolicy | undefined, work: () => Promise<T>): Promise<T> {
    // The dialogs already in the buffer are not this call's to claim.
    this.beginCall()
    this.policies.push(policy ?? { action: 'dismiss' })
    // A page that appears while this call runs is this conversation's: the
    // protocol says nothing about who opened a page, so the action in flight is
    // the whole of the attribution.
    this.host.beginAction(this.sessionId)
    try {
      return await work()
    } finally {
      this.policies.pop()
      this.host.endAction(this.sessionId)
    }
  }

  /**
   * Open an address in the active page and report what the page became.
   * @param url - absolute address to load.
   * @param options - how to answer a dialog the navigation opens, such as the
   * `beforeunload` a page about to be left shows.
   * @returns where the page landed, and what changed to get there.
   */
  async navigate(url: string, options: { dialog?: DialogPolicy } = {}): Promise<ActionReport> {
    return await this.underPolicy(options.dialog, async () => {
      await this.ensure()
      const before = await this.stateOf()
      const page = this.requirePage()
      this.invalidateViewport(page)
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30_000 })
      this.publish()
      return await this.settle(before, {})
    })
  }

  /** Reload the active page. */
  async reload(): Promise<void> {
    await this.ensure()
    const page = this.requirePage()
    this.invalidateViewport(page)
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 30_000 })
    this.publish()
  }

  /**
   * Capture the active page, the whole of it, or one element.
   *
   * A viewport capture is what a person looking at the window sees. `fullPage`
   * is the document, which is what a page taller than the window needs — the
   * reference runtime offers the same option (`screenshot({ fullPage })`), and
   * for the same reason: judging a layout from the part of it that happens to be
   * on screen is guesswork. A `target` captures the element itself, addressed
   * the same way an action addresses one, which is the feature its own
   * coordinate-only element capture lacks.
   *
   * Every capture is a page-space clip with `captureBeyondViewport`, because
   * that is what the protocol needs to reach anything below the fold and it does
   * so without scrolling: measured 2026-09-29, the clip is in page pixels and is
   * taken at the same bytes whatever the current scroll is.
   * @param options - the whole document instead of the viewport, or one element.
   * @returns the encoded image, the size it was taken at, and the element when one was named.
   * @throws {Error} when a target names no element or several, or has no box.
   */
  async screenshot(options: { fullPage?: boolean; target?: ElementTarget } = {}): Promise<Screenshot> {
    // This call reports dialogs of its own (the tool drains them), so where it
    // begins is where the ones already in the buffer stop being its.
    this.beginCall()
    await this.ensure()
    const cdp = this.cdpSession()
    if (options.target !== undefined) {
      const found = await this.resolveElement(options.target)
      const box = await this.boxOf(cdp, found)
      const jpeg = await this.capture(cdp, box)
      return {
        jpeg,
        width: box.width,
        height: box.height,
        element: { role: found.role, name: found.name },
      }
    }
    const metrics = await cdp.send('Page.getLayoutMetrics') as {
      cssVisualViewport?: { clientWidth?: number; clientHeight?: number }
      cssContentSize?: { width?: number; height?: number }
    }
    if (options.fullPage === true) {
      const size = {
        x: 0,
        y: 0,
        width: Math.max(1, Math.ceil(metrics.cssContentSize?.width ?? 0)),
        height: Math.max(1, Math.ceil(metrics.cssContentSize?.height ?? 0)),
      }
      return { jpeg: await this.capture(cdp, size), width: size.width, height: size.height }
    }
    const view = {
      width: metrics.cssVisualViewport?.clientWidth ?? 0,
      height: metrics.cssVisualViewport?.clientHeight ?? 0,
    }
    const captured = await cdp.send('Page.captureScreenshot', {
      format: 'jpeg',
      quality: this.config.quality,
    }) as { data: string }
    return { jpeg: Buffer.from(captured.data, 'base64'), width: view.width, height: view.height }
  }

  /**
   * Capture one rectangle of the page.
   * @param cdp - session attached to the active page.
   * @param clip - the rectangle, in the page's own CSS pixels.
   * @returns the encoded image.
   */
  private async capture(cdp: CDPSession, clip: PageBox): Promise<Buffer> {
    const captured = await cdp.send('Page.captureScreenshot', {
      format: 'jpeg',
      quality: this.config.quality,
      clip: { ...clip, scale: 1 },
      captureBeyondViewport: true,
    }) as { data: string }
    return Buffer.from(captured.data, 'base64')
  }

  /**
   * The rectangle the page says an element occupies.
   * @param cdp - session attached to the active page.
   * @param target - the element to measure.
   * @returns the rectangle in page pixels.
   * @throws {Error} when the element has no box in the page.
   */
  private async boxOf(cdp: CDPSession, target: RefTarget): Promise<PageBox> {
    const resolved = await cdp.send('DOM.resolveNode', { backendNodeId: target.backendNodeId })
      .catch(() => undefined) as { object?: { objectId?: string } } | undefined
    const objectId = resolved?.object?.objectId
    if (objectId === undefined) throw boxlessError(target)
    const answer = await cdp.send('Runtime.callFunctionOn', {
      objectId,
      functionDeclaration: clipProbe(),
      returnByValue: true,
    }).catch(() => undefined) as { result?: { value?: unknown } } | undefined
    const box = readClip(answer?.result?.value)
    if (box === undefined) throw boxlessError(target)
    return box
  }

  /**
   * Evaluate an expression in the active page and return its value.
   * @param expression - JavaScript source evaluated as an expression.
   * @param options - how to answer a dialog the expression opens, which a
   * script that clicks a button on `confirm`-guarded page does.
   * @returns the value, decoded when it is JSON-representable.
   * @throws {Error} when the page throws or the value cannot be decoded.
   */
  async evaluate(expression: string, options: { dialog?: DialogPolicy } = {}): Promise<unknown> {
    return await this.underPolicy(options.dialog, async () => {
      await this.ensure()
      return await this.evaluateIn(this.cdpSession(), expression)
    })
  }

  /**
   * Wait for the page to reach a state, then report whether it did.
   *
   * A page that is starting an engine, connecting a socket, or loading a
   * scenario takes seconds to become ready, and nothing about that is a
   * mutation of the document the caller just touched — so this asks the page the
   * same question repeatedly instead of guessing a length of time. Each ask is
   * the locator resolution an action uses, which is why the words are the same:
   * what a wait can match is what a click can name.
   *
   * The page is watched from before the first ask, so the changes a wait reports
   * are the page's own answer to "what happened while I waited".
   * @param condition - an element to appear, an address to contain something, or
   * plainly a length of time.
   * @param options - the budget, how often to ask, and how to answer a dialog the
   * page opens while waiting.
   * @returns whether the condition held, and what the page looked like either way.
   * @throws {Error} when nothing is open to wait on, or the page refuses a selector.
   */
  async wait(
    condition: WaitCondition,
    options: { timeoutMs: number; pollMs?: number; dialog?: DialogPolicy },
  ): Promise<WaitReport> {
    return await this.underPolicy(options.dialog, async () => {
      const page = this.page
      if (page === undefined) {
        throw new Error(
          'dsh-browser: nothing is open to wait on; open an address with browser_navigate first',
        )
      }
      const pollMs = Math.max(1, options.pollMs ?? WAIT_POLL_MS)
      const started = Date.now()
      const watch = this.cdp === undefined ? undefined : await this.armSettle(this.cdp, page)
      let matched = false
      let element: ElementRef | undefined
      let matches: number | undefined
      let disabled: number | undefined
      if (condition.timeMs !== undefined) {
        await sleep(Math.min(condition.timeMs, options.timeoutMs))
        matched = true
      } else {
        const deadline = started + options.timeoutMs
        for (;;) {
          const answered = await this.conditionHolds(condition)
          matches = answered.matches
          disabled = answered.disabled
          if (answered.held) {
            matched = true
            element = answered.element
            break
          }
          // The condition is asked before the deadline is read, so one that
          // becomes true at the last moment is still reported as matched.
          if (Date.now() >= deadline) break
          await sleep(Math.min(pollMs, Math.max(1, deadline - Date.now())))
        }
      }
      const record = watch === undefined ? undefined : await this.readSettle(watch)
      const after = await this.stateOf(page)
      const changes = record?.changes ?? []
      const omitted = record?.omitted ?? 0
      return {
        matched,
        waitedMs: Date.now() - started,
        url: after.url,
        title: after.title,
        ...element === undefined ? {} : { element },
        ...matches === undefined ? {} : { matches },
        // Only when it did not hold: with the wait over, the count is what says
        // the element the caller waited for is there and merely unusable.
        ...matched || disabled === undefined || disabled === 0 ? {} : { disabled },
        ...changes.length === 0 ? {} : { changes },
        ...omitted === 0 ? {} : { changesOmitted: omitted },
      }
    })
  }

  /**
   * Whether a wait's condition holds right now.
   * @param condition - an element to appear or to become one that can be acted
   * on, or an address to contain something.
   * @returns whether it holds, the element that satisfied it, how many did, and
   * how many of those the page says are disabled.
   * @throws {Error} when the page refuses a selector.
   */
  private async conditionHolds(
    condition: WaitCondition,
  ): Promise<{ held: boolean; element?: ElementRef; matches?: number; disabled?: number }> {
    if (condition.url !== undefined) {
      const url = this.requirePage().url()
      return { held: url.toLowerCase().includes(condition.url.toLowerCase()) }
    }
    // A condition with neither an address nor a locator is a fixed wait, which
    // the caller never reaches here.
    if (condition.locator === undefined) return { held: true }
    const candidates = await this.locate(condition.locator)
    if (condition.enabled !== true) {
      const first = candidates[0]
      return {
        held: candidates.length > 0,
        matches: candidates.length,
        ...first === undefined ? {} : { element: { role: first.role, name: first.name } },
      }
    }
    // "On the page" and "usable" are different questions, and only the page can
    // answer the second one. A candidate the page says is disabled is not what
    // was waited for; how many there were is carried back so a timeout can say
    // "it is there, it is just not usable yet" instead of "nothing matched".
    const cdp = this.cdpSession()
    let disabled = 0
    for (const candidate of candidates) {
      if (await refusesPress(cdp, candidate.backendNodeId)) {
        disabled += 1
        continue
      }
      return {
        held: true,
        matches: candidates.length,
        element: { role: candidate.role, name: candidate.name },
      }
    }
    return {
      held: false,
      matches: candidates.length,
      ...disabled === 0 ? {} : { disabled },
    }
  }

  /**
   * Read the active page as an accessibility tree.
   *
   * Refs keep whatever label the page already gave them, so a ref from an
   * earlier snapshot of this page still names the same element; only a page that
   * goes away clears them. The budget, the depth limit, and a target subtree are
   * what keep a large page from spending the conversation's context on itself,
   * and a query is the sharper form of the same thing: printing the paths to the
   * lines that answer a question instead of the whole page.
   * @param options - a subtree to print, how deep to print it, a query to keep
   * only what answers it, and whether to print each element's box.
   * @returns the tree as text, the refs it used, and the page geometry.
   * @throws {Error} when a target names nothing on the page, or a query is not
   * a usable expression.
   */
  async snapshot(options: {
    target?: string
    depth?: number
    find?: string
    boxes?: boolean
  } = {}): Promise<PageSnapshot> {
    // The tool that calls this reports the dialogs the page answered, so this
    // is where the ones already open stop being this call's.
    this.beginCall()
    await this.ensure()
    const cdp = this.cdpSession()
    const ignore = await this.ignoredNodes(cdp)
    const target: SnapshotTarget | undefined = options.target === undefined
      ? undefined
      : await this.resolveTarget(cdp, options.target)
    const nodes = await this.fullTree(cdp)
    const attributes = listOf(this.config.snapshotAttributes)
    const query = options.find === undefined ? undefined : parseQuery(options.find)
    const shared: SnapshotOptions = {
      ...attributes.length === 0 ? {} : { attributes },
      ...target === undefined ? {} : { target },
      ...options.depth === undefined ? {} : { depth: options.depth },
      ...ignore.size === 0 ? {} : { ignore },
      ...query === undefined ? {} : { find: query },
    }
    const boxes = options.boxes === true ? await this.boxesFor(cdp, nodes, shared) : undefined
    const snapshot = formatAxTree(nodes, {
      maxNodes: this.config.snapshotNodes,
      labels: this.labels,
      ...shared,
      ...boxes === undefined ? {} : { boxes },
    })
    const metrics = await cdp.send('Page.getLayoutMetrics')
    return { ...snapshot, info: pageInfoFromMetrics(metrics) }
  }

  /**
   * Where the elements a snapshot will print sit in the viewport.
   *
   * Which elements print is decided by the same rules as the text is, so it is
   * asked of the formatter rather than guessed again here — with a throwaway
   * label registry, because a question about geometry must not spend the page's
   * refs on itself. The box comes from `DOM.getContentQuads`, the call the click
   * path measured as returning the frame's viewport pixels, so a line's numbers
   * and a click's point are in the same space.
   * @param cdp - session attached to the active page.
   * @param nodes - the accessibility tree the snapshot will print.
   * @param plan - the rest of the options the snapshot was asked for.
   * @returns a box per DOM node that reported one.
   */
  private async boxesFor(
    cdp: CDPSession,
    nodes: readonly AxNode[],
    plan: SnapshotOptions,
  ): Promise<ReadonlyMap<number, Box>> {
    const planned = formatAxTree(nodes, { ...plan, labels: new RefLabels() })
    const boxes = new Map<number, Box>()
    await Promise.all([...new Set(planned.refs.values())].map(async (backendNodeId) => {
      const answer = await cdp.send('DOM.getContentQuads', { backendNodeId })
        .catch(() => undefined) as { quads?: readonly (readonly number[])[] } | undefined
      const box = boundingBoxOf(answer?.quads?.[0])
      if (box !== undefined) boxes.set(backendNodeId, box)
    }))
    return boxes
  }

  /**
   * The elements the page asked to keep out of a snapshot.
   *
   * A site can mark what is decoration, or what the plugin should never print,
   * with a selector the configuration names; those DOM nodes are resolved to the
   * accessibility nodes behind them once per snapshot, which costs two protocol
   * calls when nothing matches and one per match when something does.
   * @param cdp - session attached to the active page.
   * @returns the backend node ids to drop.
   */
  private async ignoredNodes(cdp: CDPSession): Promise<ReadonlySet<number>> {
    const ignored = new Set<number>()
    const selectors = listOf(this.config.snapshotIgnore)
    if (selectors.length === 0) return ignored
    for (const selector of selectors) {
      for (const objectId of await this.matchesInPage(cdp, selector)) {
        // The formatter drops a marked node together with everything below it,
        // so this walk only has to name the marked element itself; `pierce`
        // collects the rest of its subtree anyway, which is the same statement
        // the drop makes and cannot drift from it.
        const described = await cdp.send('DOM.describeNode', { objectId, depth: -1, pierce: true })
          .catch(() => undefined) as { node?: DomNode } | undefined
        const walk = (node: DomNode | undefined): void => {
          if (node === undefined) return
          if (node.backendNodeId !== undefined) ignored.add(node.backendNodeId)
          for (const child of node.children ?? []) walk(child)
        }
        walk(described?.node)
      }
    }
    return ignored
  }

  /**
   * Resolve what a snapshot's `target` names.
   * @param cdp - session attached to the active page.
   * @param target - a ref this page handed out, or a CSS selector.
   * @returns the DOM node to print from.
   * @throws {Error} when the ref is unknown or the selector matches nothing.
   */
  private async resolveTarget(cdp: CDPSession, target: string): Promise<SnapshotTarget> {
    const known = this.labels.targetOf(target)
    if (known !== undefined) return { backendNodeId: known.backendNodeId, described: target }
    // A ref-shaped name that this page never handed out is a stale ref, not a
    // selector; saying so is more use than "no element matches e9".
    if (/^e\d+$/.test(target)) {
      throw new Error(
        `dsh-browser: ${target} is not a ref from a snapshot of the current page; `
        + 'call browser_snapshot and use a ref from its result',
      )
    }
    // The page's own walk, the same one a click's selector uses, so a target
    // reaches an open shadow root and a same-origin frame — both of which the
    // tree this narrows already prints. Several names one rather than refusing:
    // a CSS selector means the first match everywhere else in the platform, and
    // reading a subtree is not an act on the wrong element.
    const [first] = await this.matchesInPage(cdp, target)
    const described = first === undefined
      ? undefined
      : await cdp.send('DOM.describeNode', { objectId: first }).catch(() => undefined) as
        { node?: DomNode } | undefined
    if (described?.node?.backendNodeId === undefined) {
      throw new Error(`dsh-browser: no element matches ${target}; check the selector, or take a full snapshot and use a ref`)
    }
    return { backendNodeId: described.node.backendNodeId, described: target }
  }

  /**
   * Click the element a ref names, with real mouse events.
   *
   * The events are dispatched through the same input channel a viewer's clicks
   * use, which is what makes them trusted: a site that ignores a synthetic
   * `element.click()` accepts these. The page is asked where the element is and
   * what a press there would reach, and a press the page says would be received
   * by something else is refused rather than sent — a click that lands on an
   * overlay changes nothing and used to be reported as a success.
   * @param target - a ref from a snapshot of the current page, or a locator to
   * resolve now.
   * @param options - `force` presses even when the page says something else
   * would receive it; `button` picks which button presses; `double` sends the
   * two press-release pairs a page reads as one double click; `dialog` answers
   * a dialog the click opens.
   * @returns the element that was clicked, where the page ended up, and what changed.
   * @throws {Error} when the target names no element or several, the element has
   * nothing to click, the page says the element is disabled, or (without `force`)
   * the press would be received by something other than the element.
   */
  async click(
    target: ElementTarget,
    options: { force?: boolean; button?: MouseButton; double?: boolean; dialog?: DialogPolicy } = {},
  ): Promise<ActionReport> {
    return await this.underPolicy(options.dialog, async () => {
      await this.ensure()
      const started = this.page
      const before = await this.stateOf(started)
      const cdp = this.cdpSession()
      const { target: resolved, recovered, result } = await this.actOn(target, async (found) => {
        const point = await this.pressPoint(cdp, found)
        // Asked before anything is dispatched, and not something `force` can turn
        // off: the page drops the press whatever the caller's intent is, so a
        // "Clicked" here would be the success-shaped lie this whole layer exists
        // to avoid (2026-09-29: a disabled button answered `Clicked button …`,
        // while the sibling refusal for typing has named "it is disabled" since
        // the previous round).
        if (point.disabled) {
          throw new Error(
            `dsh-browser: ${elementName(found)} is disabled, so the page would ignore a press on it and `
            + 'nothing was clicked; wait for the page to enable it, or take a new snapshot and act on an '
            + 'element that can take the press (force does not bypass this, because the press would be '
            + 'dropped either way)',
          )
        }
        if (point.outside) {
          throw new Error(
            `dsh-browser: ${elementName(found)} is outside the viewport even after scrolling it into view, `
            + 'so the click has nowhere to land; take a new snapshot and try again',
          )
        }
        if (point.over !== undefined && options.force !== true) {
          throw new Error(
            `dsh-browser: the click would be received by ${elementName(point.over)}, not ${elementName(found)}; `
            + 'pass force: true to click anyway, or take a new snapshot of what is over it',
          )
        }
        // Armed after the point is known and before the events are dispatched:
        // a page that reacts inside its handler has nothing left to do by the
        // time the protocol call returns.
        const watch = await this.armSettle(cdp, started)
        const button = options.button ?? 'left'
        // A double click is not two clicks: the second pair carries click count
        // 2, which is the only thing that tells the page the two are one gesture.
        const presses = options.double === true ? 2 : 1
        await dispatchInput(cdp, { type: 'mouse', action: 'move', x: point.x, y: point.y })
        for (let count = 1; count <= presses; count += 1) {
          await dispatchInput(cdp, { type: 'mouse', action: 'down', x: point.x, y: point.y, button, clickCount: count })
          await dispatchInput(cdp, { type: 'mouse', action: 'up', x: point.x, y: point.y, button, clickCount: count })
        }
        return { watch, obstructed: point.over }
      })
      return await this.settle(before, {
        element: { role: resolved.role, name: resolved.name },
        recovered,
        ...result.obstructed === undefined ? {} : { obstructed: result.obstructed },
      }, result.watch)
    })
  }

  /**
   * Press a key on whatever the page has focused.
   *
   * This is the keyboard gesture that is not typing: Escape closing a menu that
   * is not in the snapshot, a shortcut a site only answers to by keyboard, Tab
   * walking the focus. Naming no element is the point — moving the focus to type
   * would change which element the page considers active, and that is exactly
   * what the caller is not asking for.
   * @param key - a key name or a chord such as `Escape`, `Tab`, or `Control+A`.
   * @param options - how to answer a dialog the key opens.
   * @returns where the page ended up and what changed.
   * @throws {Error} when the key has no dispatch mapping.
   */
  async press(key: string, options: { dialog?: DialogPolicy } = {}): Promise<ActionReport> {
    return await this.type(undefined, '', { key, ...options })
  }

  /**
   * Type into the element a ref names, or into whatever the page has focused.
   *
   * Text arrives through `Input.insertText`, so it is inserted as characters
   * rather than replayed as keystrokes — which is what makes non-Latin input
   * work. A key is pressed afterwards for fields whose meaning is the Enter
   * that follows. The page is asked after the focus and before the first
   * character whether it will take the text at all, because a control that
   * cannot hold it takes nothing while the report used to say it had been typed.
   *
   * A call with no target types where the focus already is and replaces nothing:
   * there is no element to select the old value of, and guessing one from the
   * document's `activeElement` would be a claim about which element the caller
   * meant.
   * @param target - a ref from a snapshot of the current page, a locator to
   * resolve now, or `undefined` to leave the focus where it is.
   * @param value - the text to insert; empty inserts none.
   * @param options - whether to replace the current content, a key to press
   * after, and how to answer a dialog either one opens.
   * @returns the element that was typed into, where the page ended up, and what changed.
   * @throws {Error} when the target names no element or several, or the page says
   * the text would not land in it.
   */
  async type(
    target: ElementTarget | undefined,
    value: string,
    options: { clear?: boolean; key?: string; dialog?: DialogPolicy } = {},
  ): Promise<ActionReport> {
    return await this.underPolicy(options.dialog, async () => {
      await this.ensure()
      const started = this.page
      const before = await this.stateOf(started)
      const cdp = this.cdpSession()
      /**
       * Write the text and press the key, watching the page from before either.
       * @returns where to read what the page did about it.
       */
      const write = async (): Promise<SettleWatch> => {
        // Watching starts before the text does: a field that reacts by rewriting
        // itself — a filter redrawing its list — does it in the input event.
        const watch = await this.armSettle(cdp, started)
        if (value !== '') await dispatchInput(cdp, { type: 'text', text: value })
        if (options.key !== undefined) await dispatchInput(cdp, { type: 'key', key: options.key })
        return watch
      }
      if (target === undefined) {
        const report = await this.settle(before, {}, await write())
        // A call that names no element is the one whose whole effect can be
        // "the focus moved": the caller cannot see where a bare Shift+Tab
        // sent it, and the next Enter lands wherever that was.
        const focused = await this.readFocus()
        return focused === undefined ? report : { ...report, focused }
      }
      const { target: resolved, recovered, result } = await this.actOn(target, async (found) => {
        await cdp.send('DOM.scrollIntoViewIfNeeded', { backendNodeId: found.backendNodeId }).catch(() => {})
        // The focus is not taken on trust: a control that cannot be focused —
        // measured 2026-09-29, a disabled input — makes `DOM.focus` itself
        // reject, which is a protocol failure the page has a reason for. The
        // page is asked anyway, so the refusal names the element and the reason
        // rather than the transport's framing of the call.
        const refused = await cdp.send('DOM.focus', { backendNodeId: found.backendNodeId })
          .then(() => undefined, (error: unknown) => error)
        const answer = await this.assertTyped(cdp, found)
        if (refused !== undefined && answer?.accepts !== false) {
          throw new Error(
            `dsh-browser: the page would not focus ${elementName(found)} (${protocolReason(refused)}); `
            + 'nothing was typed, so take a new snapshot and check the element',
          )
        }
        if (options.clear !== false) {
          // Selection is the one part of this that is not a trusted event: what
          // follows is the insertion, which is.
          await this.evaluateIn(cdp, 'globalThis.document.activeElement?.select?.()').catch(() => {})
        }
        return await write()
      })
      return await this.settle(before, {
        element: { role: resolved.role, name: resolved.name },
        recovered,
      }, result)
    })
  }

  /**
   * Choose options on a native `<select>`, and say which ones were chosen.
   *
   * A `<select>`'s popup belongs to the browser process, not the page: a press
   * opens it, but the options have no box, so a click on one has nowhere to land
   * (measured 2026-09-29: `Clicked combobox`, then a refusal for the option
   * having no visible box, whose advice could never come true). The selection is
   * set on the element and the page's own `input`/`change` events are dispatched,
   * which is the shape the reference runtime's `select(ref, values)` has.
   * @param target - a ref from a snapshot of the current page, or a locator to
   * resolve now.
   * @param values - the option values or visible labels to choose.
   * @param options - how to answer a dialog the selection opens.
   * @returns the element, where the page ended up, and which options it chose.
   * @throws {Error} when the target names no element or several, is not a
   * `<select>`, is disabled, or none of the values is one of its options.
   */
  async select(
    target: ElementTarget,
    values: readonly string[],
    options: { dialog?: DialogPolicy } = {},
  ): Promise<ActionReport> {
    return await this.underPolicy(options.dialog, async () => {
      await this.ensure()
      const started = this.page
      const before = await this.stateOf(started)
      const cdp = this.cdpSession()
      const { target: resolved, recovered, result } = await this.actOn(target, async (found) => {
        // Armed before the events go out: a page that reacts inside its own
        // change handler has finished by the time the protocol call returns.
        const watch = await this.armSettle(cdp, started)
        const chosen = await this.chooseOptions(cdp, found, values)
        return { watch, chosen }
      })
      const report = await this.settle(before, {
        element: { role: resolved.role, name: resolved.name },
        recovered,
      }, result.watch)
      return { ...report, selected: [...result.chosen] }
    })
  }

  /**
   * Set a checkbox or radio's state, and say what it ended in.
   *
   * The reference runtime's `check(ref, checked)`. A click is the wrong tool for
   * a control whose meaning is a state: one that does not reflect `checked` into
   * an attribute changes no DOM, so the report says "did not change" and the
   * caller cannot tell a switch it flipped from one the page ignored.
   * @param target - a ref from a snapshot, or a locator to resolve now.
   * @param checked - the state to set.
   * @param options - how to answer a dialog the change opens.
   * @returns the element, where the page ended up, and the state it holds.
   * @throws {Error} when the target names no element or several, is not a
   * checkbox or radio, or is disabled.
   */
  async check(
    target: ElementTarget,
    checked: boolean,
    options: { dialog?: DialogPolicy } = {},
  ): Promise<ActionReport> {
    return await this.underPolicy(options.dialog, async () => {
      await this.ensure()
      const started = this.page
      const before = await this.stateOf(started)
      const cdp = this.cdpSession()
      const { target: resolved, recovered, result } = await this.actOn(target, async (found) => {
        const watch = await this.armSettle(cdp, started)
        const state = await this.setChecked(cdp, found, checked)
        return { watch, state }
      })
      const report = await this.settle(before, {
        element: { role: resolved.role, name: resolved.name },
        recovered,
      }, result.watch)
      return { ...report, checked: result.state }
    })
  }

  /**
   * Resolve the element a caller named and ask it one in-page question.
   *
   * The sharing this exists for is the protocol half every in-page question has:
   * the node is resolved from its backend id, and the page answers with a value.
   * @param cdp - session attached to the active page.
   * @param target - the element the ref names.
   * @param question - what to ask the element.
   * @returns what the page answered, or `undefined` when it answered nothing.
   */
  private async askElement(cdp: CDPSession, target: RefTarget, question: string): Promise<unknown> {
    const resolved = await cdp.send('DOM.resolveNode', { backendNodeId: target.backendNodeId })
      .catch(() => undefined) as { object?: { objectId?: string } } | undefined
    const objectId = resolved?.object?.objectId
    if (objectId === undefined) return undefined
    const answer = await cdp.send('Runtime.callFunctionOn', {
      objectId,
      functionDeclaration: question,
      awaitPromise: true,
      returnByValue: true,
    }).catch(() => undefined) as { result?: { value?: unknown } } | undefined
    return answer?.result?.value
  }

  /**
   * Choose options on the `<select>` the element belongs to.
   * @param cdp - session attached to the active page.
   * @param target - the element the ref names.
   * @param values - the option values or visible labels to choose.
   * @returns the labels that were chosen.
   * @throws {Error} when the element is not a select, is disabled, or none of the values matches.
   */
  private async chooseOptions(
    cdp: CDPSession,
    target: RefTarget,
    values: readonly string[],
  ): Promise<readonly string[]> {
    const said = readSelect(await this.askElement(cdp, target, selectProbe(values)))
    if (said.kind === 'not-select') {
      throw new Error(
        `dsh-browser: ${elementName(target)} is not a <select>, so there are no options to choose; `
        + 'if the page draws its own list, click the control and then the option, or set the value '
        + 'with browser_evaluate',
      )
    }
    if (said.kind === 'disabled') {
      throw new Error(
        `dsh-browser: ${elementName(target)} is disabled, so the page would ignore a selection and `
        + 'nothing was selected; wait for the page to enable it',
      )
    }
    if (said.kind === 'missing') {
      const missed = (said.missed ?? []).map(value => JSON.stringify(value)).join(', ')
      const choices = (said.choices ?? []).map(value => JSON.stringify(value)).join(', ')
      const shown = choices === '' ? '(none)' : choices
      throw new Error(
        `dsh-browser: ${missed} is not an option of ${elementName(target)}, and nothing was selected; `
        + `its options are ${shown}`,
      )
    }
    if (said.kind !== 'selected' || said.selected === undefined) {
      throw new Error(
        `dsh-browser: the page did not say whether ${elementName(target)} took the selection; nothing `
        + 'was selected, so take a new snapshot and check the element',
      )
    }
    return said.selected
  }

  /**
   * Set the checked state of a checkbox or radio.
   * @param cdp - session attached to the active page.
   * @param target - the element the ref names.
   * @param checked - the state to set.
   * @returns the state the control ended in.
   * @throws {Error} when the element is not checkable or is disabled.
   */
  private async setChecked(cdp: CDPSession, target: RefTarget, checked: boolean): Promise<boolean> {
    const said = readCheck(await this.askElement(cdp, target, checkProbe(checked)))
    if (said.kind === 'not-checkable') {
      const tag = said.tag === undefined || said.tag === '' ? 'the element' : said.tag
      const type = said.type === undefined || said.type === '' ? '' : '[type=' + said.type + ']'
      throw new Error(
        `dsh-browser: ${elementName(target)} is a ${tag}${type}, not a checkbox or radio, so its `
        + 'checked state cannot be set; if the page draws its own switch, click it instead',
      )
    }
    if (said.kind === 'disabled') {
      throw new Error(
        `dsh-browser: ${elementName(target)} is disabled, so the page would ignore the change and `
        + 'nothing was changed; wait for the page to enable it',
      )
    }
    if (said.kind !== 'set' || said.checked === undefined) {
      throw new Error(
        `dsh-browser: the page did not say whether ${elementName(target)} took the change; nothing was `
        + 'changed, so take a new snapshot and check the element',
      )
    }
    return said.checked
  }

  /**
   * Act on a ref, finding the element again if the DOM replaced it.
   *
   * A single-page app re-renders an element by removing the old node and
   * inserting a new one, which leaves the ref pointing at nothing while the
   * element the model asked for is still on the page. The role and name the
   * snapshot recorded are enough to find it again, and a failed action is only
   * retried when exactly one element matches, so a retry can never land
   * somewhere the model did not name.
   * @param target - a ref from a snapshot, or a locator to resolve now.
   * @param run - the action, given the element it should act on.
   * @returns what the action acted on, whether it had to be found again, and
   * whatever the action itself produced.
   * @throws {Error} when the target names no element, names several, or when the
   * action fails for a reason other than the element having gone.
   */
  private async actOn<T>(
    target: ElementTarget,
    run: (found: RefTarget) => Promise<T>,
  ): Promise<{ target: RefTarget; recovered: boolean; result: T }> {
    const resolved = await this.resolveElement(target)
    try {
      return { target: resolved, recovered: false, result: await run(resolved) }
    } catch (error) {
      if (!elementGone(error)) throw error
      const healed = await this.healTarget(target, resolved)
      if (healed === undefined) throw error
      return { target: healed, recovered: true, result: await run(healed) }
    }
  }

  /**
   * The one element a target names, or a refusal naming the others.
   *
   * A ref is looked up in the registry the snapshot filled. A locator is asked
   * of the page as it is now, and an answer of zero or several elements is an
   * error rather than a guess: acting on the first of several would press an
   * element the caller did not name, and reporting none would describe a page
   * that is not empty as empty.
   * @param target - a ref from a snapshot, or a locator.
   * @returns the element to act on.
   * @throws {Error} when the ref is unknown, or the locator is not exactly one element.
   */
  private async resolveElement(target: ElementTarget): Promise<RefTarget> {
    if (typeof target === 'string') return this.nodeFor(target)
    const candidates = await this.locate(target)
    const only = candidates.length === 1 ? candidates[0] : undefined
    if (only !== undefined) return only
    throw candidates.length === 0
      ? locateMissError(target)
      // Each candidate is named by its ref when the page has one: the refusal
      // has to tell the caller which of the two identically named controls is
      // which, and a ref is the only handle an action can be aimed at.
      : locateAmbiguousError(target, candidates, candidate =>
        this.labels.labelFor(candidate.backendNodeId, candidate.role, candidate.name).label)
  }

  /**
   * Every element the page currently answers a locator with.
   *
   * A selector is resolved against the document and mapped back by node id, so
   * a caller can reach an element the accessibility tree does not describe —
   * `role`/`name`/`text` read the tree, because that is where a name lives. A
   * locator that says both is narrowed by both, which is what a caller writing
   * both would expect; the tool layer does not offer that combination.
   * @param locator - what the caller asked for.
   * @returns the candidates, in tree order.
   * @throws {Error} when the page refuses the selector itself.
   */
  private async locate(locator: Locator): Promise<Located[]> {
    const nodes = await this.fullTree(this.cdpSession()).catch(() => [] as AxNode[])
    if (locator.selector === undefined) return locateInTree(nodes, locator)
    const bySelector = await this.locateBySelector(locator.selector, nodes)
    if (!locatorIsTreeShaped(locator)) return bySelector
    const allowed = new Set(bySelector.map(candidate => candidate.backendNodeId))
    return locateInTree(nodes, locator).filter(candidate => allowed.has(candidate.backendNodeId))
  }

  /**
   * The page's own matches for a CSS selector, as handles to ask about.
   *
   * The walk is the page's (see `selectorProbe`), so a match can be inside an
   * open shadow root or a same-origin frame — the scope the accessibility tree
   * splices and the DOM agent's query selectors cannot follow. A selector the
   * page cannot parse is refused by name here, once for every caller: reported
   * as "no element matches" it would send the caller looking for another
   * element instead of at its own typo.
   * @param cdp - session attached to the active page.
   * @param selector - what the caller wrote.
   * @returns one object id per match, in the page's own order.
   * @throws {Error} when the page refuses the selector.
   */
  private async matchesInPage(cdp: CDPSession, selector: string): Promise<string[]> {
    let count = 0
    try {
      const answer = await cdp.send('Runtime.evaluate', {
        expression: selectorProbe(selector, MATCH_SLOT),
        returnByValue: true,
      }) as {
        result?: { value?: unknown }
        exceptionDetails?: { exception?: { description?: string } }
      }
      if (answer.exceptionDetails !== undefined) {
        throw new Error(answer.exceptionDetails.exception?.description ?? 'the page refused it')
      }
      if (typeof answer.result?.value === 'number') count = answer.result.value
    } catch (error) {
      throw new Error(
        `dsh-browser: the page refused the selector ${JSON.stringify(selector)}: `
        + `${error instanceof Error ? error.message : String(error)}`,
      )
    }
    const handles: string[] = []
    for (let index = 0; index < count; index += 1) {
      const handle = await cdp.send('Runtime.evaluate', {
        expression: `globalThis.${MATCH_SLOT}[${String(index)}]`,
        returnByValue: false,
      }).catch(() => undefined) as { result?: { objectId?: string } } | undefined
      const objectId = handle?.result?.objectId
      if (objectId !== undefined) handles.push(objectId)
    }
    return handles
  }

  /**
   * The elements a CSS selector matches, read through the page.
   *
   * The walk is the page's own (see `selectorProbe`), so a match carries the
   * role and name the accessibility tree gives it — including the content of
   * shadow roots and same-origin frames, which the agent's query selector
   * cannot follow. An element the tree does not describe is reported by its
   * tag, which is a worse name than a role and a much better one than nothing
   * at all.
   * @param selector - the CSS selector.
   * @param nodes - the accessibility tree, for naming what was matched.
   * @returns the candidates.
   * @throws {Error} when the page refuses the selector.
   */
  private async locateBySelector(selector: string, nodes: readonly AxNode[]): Promise<Located[]> {
    const cdp = this.cdpSession()
    const found: Located[] = []
    for (const objectId of await this.matchesInPage(cdp, selector)) {
      const described = await cdp.send('DOM.describeNode', { objectId, depth: 0 }).catch(() => undefined) as { node?: { backendNodeId?: number; nodeName?: string } } | undefined
      const backendNodeId = described?.node?.backendNodeId
      if (backendNodeId === undefined) continue
      // The tree names the match when it describes it, which is what a refusal
      // lists; when it does not, the element stays described by nothing, and the
      // absence of a trail is reported as exactly that rather than as an answer.
      found.push(entryInTree(nodes, backendNodeId) ?? {
        backendNodeId,
        role: (described?.node?.nodeName ?? 'element').toLowerCase(),
        name: '',
      })
    }
    return found
  }

  /**
   * Find the element a target named, after the DOM node behind it went away.
   * @param target - the target to re-point.
   * @param stale - what the target named when it was resolved.
   * @returns the element's new DOM node, or `undefined` when the page no longer
   * answers the target with exactly one element.
   */
  private async healTarget(target: ElementTarget, stale: RefTarget): Promise<RefTarget | undefined> {
    if (typeof target === 'string') return await this.findAgain(target, stale)
    const candidates = await this.locate(target).catch(() => [])
    // Only a single answer is safe to retry on: acting on the first of several
    // would land somewhere the caller did not name, which is the trade the
    // refusal in `resolveElement` already made.
    return candidates.length === 1 ? candidates[0] : undefined
  }

  /**
   * Find the element a ref named, after the DOM node behind it went away.
   * @param ref - the ref to re-point.
   * @param stale - what the ref named when the snapshot recorded it.
   * @returns the element's new DOM node, or `undefined` when the page has no
   * single element matching it.
   */
  private async findAgain(ref: string, stale: RefTarget): Promise<RefTarget | undefined> {
    const nodes = await this.fullTree(this.cdpSession()).catch(() => [] as AxNode[])
    const matches: RefTarget[] = []
    for (const node of nodes) {
      const candidate = refTargetOf(node)
      if (candidate !== undefined && candidate.role === stale.role && candidate.name === stale.name) {
        matches.push(candidate)
      }
    }
    const found = matches.length === 1 ? matches[0] : undefined
    if (found === undefined) return undefined
    this.labels.rebind(ref, found)
    return found
  }

  /**
   * The page's accessibility tree with same-process child frames spliced in.
   *
   * Chrome answers the page-level tree with every iframe element carrying no
   * children, because each frame's tree is a separate answer (measured
   * 2026-09-29 on a same-origin pair). The frames' trees are fetched per frame
   * and spliced in at the element that owns each one; a frame in another
   * process cannot be reached by this connection and is left out rather than
   * guessed at, as is a frame whose owner the page's own tree does not
   * describe.
   * @param cdp - session attached to the active page.
   * @returns the page's nodes, with the frames' nodes under their owners.
   */
  private async fullTree(cdp: CDPSession): Promise<readonly AxNode[]> {
    const root = await cdp.send('Accessibility.getFullAXTree') as { nodes?: readonly AxNode[] }
    const nodes = root.nodes ?? []
    const payload = await cdp.send('Page.getFrameTree').catch(() => undefined) as { frameTree?: FrameTreePayload } | undefined
    const frameIds = childFrameIds(payload?.frameTree).slice(0, FRAME_TREES_MAX)
    if (frameIds.length === 0) return nodes
    const frames: FrameTree[] = []
    for (const frameId of frameIds) {
      const [tree, owner] = await Promise.all([
        cdp.send('Accessibility.getFullAXTree', { frameId })
          .catch(() => undefined) as { nodes?: readonly AxNode[] } | undefined,
        cdp.send('DOM.getFrameOwner', { frameId })
          .catch(() => undefined) as { backendNodeId?: number } | undefined,
      ])
      const frameNodes = tree?.nodes
      const ownerBackendNodeId = owner?.backendNodeId
      if (frameNodes === undefined || frameNodes.length === 0 || ownerBackendNodeId === undefined) continue
      frames.push({ ownerBackendNodeId, nodes: frameNodes })
    }
    return mergeFrameTrees(nodes, frames)
  }

  /**
   * What the active page shows right now.
   *
   * Read from the document once the document can answer: a page in the middle
   * of replacing itself has no title to give, and the protocol's convenience
   * for that case invents one (see `documentProbe`). A page that never answers
   * inside the budget still reports the protocol's own address, and the title
   * is left empty rather than invented.
   * @param page - the page to read; the active one unless said otherwise.
   * @returns the address, title, the instant that document started, and whether it runs script.
   */
  private async stateOf(page: Page | undefined = this.page): Promise<PageState> {
    if (page === undefined) return { url: '', title: '', origin: 0 }
    if (page !== this.page) {
      // A page this session is not attached to has no probe of its own here;
      // the protocol's read is the honest one for it.
      return { url: page.url(), title: await page.title().catch(() => ''), origin: 0 }
    }
    const deadline = Date.now() + SETTLE_NAVIGATION_MS
    for (;;) {
      const said = await (async (): Promise<PageState | undefined> => {
        try {
          const value = await this.evaluateIn(this.cdpSession(), `(${documentProbe()})()`)
          if (typeof value !== 'object' || value === null) return undefined
          const read = value as Record<string, unknown>
          if (typeof read['url'] !== 'string' || typeof read['title'] !== 'string'
            || typeof read['origin'] !== 'number') return undefined
          return { url: read['url'], title: read['title'], origin: read['origin'] }
        } catch {
          // A page that cannot answer yet — one that is being replaced — is
          // asked again until the budget runs out, not believed to have none.
          return undefined
        }
      })()
      if (said !== undefined) return { ...said, ...await this.scriptVerdict(said.origin) }
      if (Date.now() >= deadline) break
      await sleep(50)
    }
    return { url: page.url(), title: '', origin: 0 }
  }

  /**
   * Whether the document that started at `origin` runs script of its own.
   *
   * Asked at all because a document whose script is suspended can never settle
   * the promises this plugin leaves in it. The signal is the one that was
   * measured: a timer question that comes back at all means the event loop
   * answered, and one that never comes back means nothing in that document will
   * ever come back.
   *
   * A timer that misses its budget is not yet a verdict, because a page's main
   * thread can be busy — a document that is still booting looks exactly like a
   * suspended one for as long as its script takes to yield. The two are told
   * apart by synchronous evaluation, which is also what the original measurement
   * found: a suspended document answers `1+1` in 0–1 ms (nothing runs, so the
   * protocol call still completes), while a busy page answers neither. So a
   * missed timer followed by a missed synchronous evaluation is a busy page, and
   * busy is not cached: the next action asks again, and a later one gets a real
   * answer. Only "timer missed and synchronous evaluation answered" is the
   * suspended-document verdict worth remembering.
   * @param origin - `performance.timeOrigin` of the document being asked about.
   * @returns the verdict for that document; `undefined` while it is too busy to say.
   */
  private async scriptVerdict(origin: number): Promise<{ liveScript?: boolean }> {
    if (origin === 0) return {}
    const measured = this.liveScript
    if (measured !== undefined && measured.origin === origin) return { liveScript: measured.runs }
    // Not awaited through `evaluateIn`: that path is the one this exists to
    // bound, so the answer is taken from a race, and a race is exactly what a
    // page that runs no script gives no answer to.
    const probed = await until(
      this.cdpSession().send('Runtime.evaluate', {
        expression: scriptProbe(),
        awaitPromise: true,
        returnByValue: true,
      }),
      SCRIPT_PROBE_MS,
    )
    if (probed.settled) {
      this.liveScript = { origin, runs: true }
      return { liveScript: true }
    }
    // The timer never answered. Either nothing in this document runs, or its
    // main thread is busy with something that has not yielded yet — and only the
    // first is a property of the document worth remembering.
    const synchronous = await until(this.cdpSession().send('Runtime.evaluate', {
      expression: '1 + 1',
      returnByValue: true,
    }), SCRIPT_PROBE_MS)
    if (!synchronous.settled) return {}
    this.liveScript = { origin, runs: false }
    return { liveScript: false }
  }

  /**
   * Where the keyboard focus is now, named the way a snapshot names an element.
   *
   * Read from the accessibility tree rather than from the page's own
   * activeElement, because a role and a name are what the caller needs and the
   * tree is where names live; the reference runtime reports the same fact on its
   * computer-use side as focus_changed plus the focused element's title. A page
   * that cannot be asked — one that is being replaced — answers nothing, and
   * nothing is reported rather than a guess.
   * @returns the focused element, or undefined when none is or the page would not say.
   */
  private async readFocus(): Promise<ElementRef | undefined> {
    try {
      return focusedInTree(await this.fullTree(this.cdpSession()))
    } catch {
      return undefined
    }
  }

  /**
   * Wait for a page to stop changing, then describe what it became.
   *
   * A click on a client-rendered control returns from the protocol before the
   * page has drawn the result, and a click on a link returns before the next
   * document exists. Waiting for the document and then for a quiet moment is
   * what makes the reported address and title the ones the model will act on.
   * @param before - the page state the action started from.
   * @param detail - the element acted on, whether it had to be found again, and
   * what was over the point it was clicked at.
   * @param armed - the probe a caller installed before dispatching its input.
   * @returns the report a tool result is rendered from.
   */
  private async settle(
    before: PageState,
    detail: { element?: ElementRef; recovered?: boolean; obstructed?: ElementRef },
    armed?: SettleWatch,
  ): Promise<ActionReport> {
    const started = armed?.page ?? this.page
    if (started !== undefined) {
      await started.waitForLoadState('domcontentloaded', { timeout: SETTLE_NAVIGATION_MS }).catch(() => {})
    }
    // Whether the document that is loaded now runs script, asked before anything
    // waits on it. A navigation is exactly the case a probe armed beforehand
    // cannot cover: it was installed in the document the action left behind, and
    // the document it arrived at may be one that runs no script at all — the
    // measured hang of 2026-11-02, where the read waited on a promise the page
    // could never settle. Knowing first turns that wait into no wait.
    const measured = this.page === undefined ? undefined : await this.stateOf(this.page)
    const frozen = measured?.liveScript === false
    // An action that armed a probe before its input is watched by that probe,
    // as long as it stayed on the page it began on. An action that moved to
    // another page — a link that opened a tab — has its own document, and that
    // document is what gets watched instead; so does a caller that dispatched
    // no input at all, which has nothing to watch for but the navigation.
    const watch = frozen
      ? undefined
      : armed !== undefined && armed.page === this.page
        ? armed
        : this.cdp === undefined || this.page === undefined ? undefined : await this.armSettle(this.cdp, this.page)
    let mutations = 0
    let settled = true
    let changes: readonly DomChange[] = []
    let omitted = 0
    if (watch !== undefined) {
      const record = await this.readSettle(watch)
      mutations = record.mutations
      settled = record.settled
      changes = record.changes
      omitted = record.omitted
    }
    // One bounded beat before the state is read: the browser says a tab it just
    // opened exists a moment after the press returns, and an adoption that is
    // already running has to finish before this report can describe the world
    // the caller's next call will land in (measured 2026-09-29: two of three
    // `window.open` clicks reported the page they left behind).
    await sleep(ADOPTION_GRACE_MS)
    await Promise.race([this.adoption.catch(() => {}), sleep(SETTLE_NAVIGATION_MS)])
    const after = await this.stateOf(this.page ?? started)
    const changed: string[] = []
    if (after.url !== before.url) changed.push('url')
    if (after.title !== before.title) changed.push('title')
    // The document this read describes and the one the action began on are
    // different documents whenever their instants differ — a form POST that
    // answers with the same page replaces the document and changes neither the
    // address nor the title, and "the page did not change" is the one answer a
    // model cannot act on correctly there.
    if (before.origin !== 0 && after.origin !== 0 && after.origin !== before.origin) changed.push('document')
    if (mutations > 0) changed.push('dom')
    // A dialog is a change of its own: the page may have drawn nothing at all
    // while it asked its question, and "the page did not change" would then be
    // the report for a click that a site stopped to confirm.
    const dialogs = this.takeDialogs()
    if (dialogs.length > 0) changed.push('dialog')
    return {
      url: after.url,
      title: after.title,
      changed,
      mutations,
      settled,
      ...after.liveScript === false ? { staticDocument: true } : {},
      ...changes.length === 0 ? {} : { changes },
      ...omitted === 0 ? {} : { changesOmitted: omitted },
      ...detail.element === undefined ? {} : { element: detail.element },
      ...detail.recovered === undefined ? {} : { recovered: detail.recovered },
      ...detail.obstructed === undefined ? {} : { obstructed: detail.obstructed },
      ...dialogs.length === 0 ? {} : { dialogs },
    }
  }

  /**
   * Start watching a page for changes, before the action that causes them.
   *
   * The observer has to be installed first. A page that reacts inside its own
   * handler — a `<details>` opening, a class toggled by a script — has finished
   * by the time the protocol call returns, and a probe started after that sees
   * a page that never moved: measured 2026-09-25 on github.com/trending, where
   * clicking a disclosure reported "did not change" while its menu opened. Only
   * a reaction that is deferred to a later task was ever seen.
   *
   * A document that does not run script is not armed at all. The probe resolves
   * through a timer, and a suspended event loop never runs one: measured
   * 2026-11-02, a raw file page (served with `Content-Security-Policy: …;
   * sandbox`) held `browser_navigate` for the whole of its budget waiting for a
   * promise that could never settle. The observer still works there — DOM
   * callbacks are not script the document has to run — but nothing else about a
   * probe does, so a document already measured as one that runs no script is
   * reported as unchanged rather than waited on.
   * @param cdp - session attached to the page being acted on.
   * @param page - the page the action is about to act on.
   * @returns where to read what the probe saw; its slot is empty when nothing was armed.
   */
  private async armSettle(cdp: CDPSession, page: Page | undefined): Promise<SettleWatch> {
    // The verdict is read for the document that is loaded now, not for whichever
    // document was measured last: this is called before an action's input, and
    // the page may have navigated since. The measurement itself is cached per
    // document (see `scriptVerdict`), so what this costs per action is the one
    // read of what the document is.
    const current = page === this.page ? await this.stateOf(page) : undefined
    if (current?.liveScript === false) return { page, cdp, slot: '' }
    this.settleSeq += 1
    const slot = `${SETTLE_SLOT}${String(this.settleSeq)}`
    // The comma expression installs the promise without awaiting it, which is
    // the whole point: the observer has to be running before the events go out.
    await this.evaluateIn(cdp, `(globalThis.${slot} = ${settleProbe()}, 0)`).catch(() => {})
    return { page, cdp, slot }
  }

  /**
   * Read what an armed probe saw, and let the page drop it.
   *
   * The record comes from the page, so it is read as data rather than trusted:
   * an entry is kept only when it is one of the kinds a result declares and its
   * fields are the types it declares, each field is cut at the bound the page was
   * given as well, and the cap is applied on this side too — a page that ignores
   * the limit it was handed cannot make a tool result grow.
   *
   * The read itself is bounded, and it is the only place in this file where a
   * plain `await` is not enough: the promise it waits on lives in the page, and a
   * page that stops running script — mid-action, by navigating into a sandboxed
   * document — never settles it. Measured 2026-11-02: an unbounded await here
   * held `browser_navigate` for its whole 45 s budget. Falling back is honest,
   * because the address and title the caller also gets are what carry the change.
   * @param watch - the page and slot the probe was installed with.
   * @returns what the page made, and what it changed while it settled.
   */
  private async readSettle(watch: SettleWatch): Promise<{
    mutations: number
    settled: boolean
    changes: readonly DomChange[]
    omitted: number
  }> {
    const none = { mutations: 0, settled: true, changes: [], omitted: 0 }
    // Nothing was armed: the document was already known to run no script, and a
    // probe installed there would only be one more promise that never settles.
    if (watch.slot === '') return none
    // A page that navigated during the action has no slot to read, and one that
    // answered with something else is a page this cannot be read from; either
    // way the address and title are what carry the change.
    const read = `(async () => { const record = await globalThis.${watch.slot}; globalThis.${watch.slot} = undefined; return record })()`
    const probed = await until(
      this.evaluateIn(watch.cdp, read).catch(() => undefined),
      SETTLE_MAX_MS + INTERRUPT_QUIET_MS,
    )
    const observed = probed.settled ? probed.value : undefined
    if (typeof observed !== 'object' || observed === null) return none
    const record = observed as { mutations?: unknown; settled?: unknown; changes?: unknown; omitted?: unknown }
    const reported: readonly unknown[] = Array.isArray(record.changes) ? record.changes : []
    const changes: DomChange[] = []
    let beyond = 0
    for (const entry of reported) {
      const change = readChange(entry)
      if (change === undefined) continue
      if (changes.length < CHANGE_LIMIT) changes.push(change)
      else beyond += 1
    }
    const said = typeof record.omitted === 'number' && Number.isFinite(record.omitted)
      ? Math.max(0, Math.floor(record.omitted))
      : 0
    return {
      mutations: typeof record.mutations === 'number' ? record.mutations : 0,
      settled: typeof record.settled === 'boolean' ? record.settled : true,
      changes,
      omitted: said + beyond,
    }
  }

  /**
   * Where a press on a ref's element would land, and what the page says about it.
   *
   * The page is asked rather than the protocol, because the protocol's answer has
   * to be interpreted: measured 2026-09-24 on a scrolled Google result page,
   * `DOM.getContentQuads` returned the frame's viewport pixels (433 for a box
   * 2471 px down the document), so translating them by
   * `cssLayoutViewport.pageY` — as this used to — put the press at y = -1589,
   * outside the viewport, where it reached nothing while the report still called
   * the click a success. `getBoundingClientRect` needs no interpretation and
   * answers for nested scroll containers too.
   * @param cdp - session attached to the active page.
   * @param target - the element a ref names.
   * @returns the point to press, and what would receive it when that is not the element.
   * @throws {Error} when the element has no box in the page.
   */
  private async pressPoint(cdp: CDPSession, target: RefTarget): Promise<PressPoint> {
    await cdp.send('DOM.scrollIntoViewIfNeeded', { backendNodeId: target.backendNodeId }).catch(() => {})
    const resolved = await cdp.send('DOM.resolveNode', { backendNodeId: target.backendNodeId })
      .catch(() => undefined) as { object?: { objectId?: string } } | undefined
    const objectId = resolved?.object?.objectId
    if (objectId !== undefined) {
      // An element still moving gets one more reading rather than a press on a
      // box it has already left. Bounded at two: the second answer is used as it
      // comes, and the hit test it carries is what says whether it is right.
      for (let attempt = 0; attempt < 2; attempt += 1) {
        const answer = await cdp.send('Runtime.callFunctionOn', {
          objectId,
          functionDeclaration: pressProbe(),
          awaitPromise: true,
          returnByValue: true,
        }).catch(() => undefined) as { result?: { value?: unknown } } | undefined
        const said = readPress(answer?.result?.value)
        if (said === 'boxless') throw boxlessError(target)
        if (said === undefined) break
        if (!said.moved || attempt === 1) return said
      }
    }
    // The page would not describe the point at all — a node it has already
    // replaced, or a document this plugin cannot run in. The box CDP reports is
    // still an answer, and it is already in the pixels input is dispatched in,
    // so it is used exactly as it comes; what is lost with it is the hit test.
    const { quads } = await cdp.send('DOM.getContentQuads', { backendNodeId: target.backendNodeId }) as { quads?: number[][] }
    const quad = quads?.[0]
    if (quad === undefined) throw boxlessError(target)
    const centre = centerOfQuad(quad)
    // The page would not answer the question about itself, so the page's own
    // verdict on the element being disabled is missing too: a press at the box
    // is the fallback, and it is not turned into a refusal on a guess.
    return { x: centre.x, y: centre.y, moved: false, outside: false, disabled: false }
  }

  /**
   * Ask the page whether the element it just focused will take typed text.
   *
   * Called before the old value is selected and before any character is
   * inserted, so a control that cannot hold text is refused instead of reported
   * as typed into. A page that says nothing this code can read does not block
   * the text: this is a question the page answers, not a requirement it has to
   * satisfy, and the same shape of answer — a node CDP has already replaced —
   * leaves the old behaviour in place.
   * @param cdp - session attached to the active page.
   * @param target - the element a ref names.
   * @returns the page's answer, or `undefined` when the page said nothing usable.
   * @throws {Error} when the page says the text would not land in the element.
   */
  private async assertTyped(cdp: CDPSession, target: RefTarget): Promise<TypedAnswer | undefined> {
    const resolved = await cdp.send('DOM.resolveNode', { backendNodeId: target.backendNodeId })
      .catch(() => undefined) as { object?: { objectId?: string } } | undefined
    const objectId = resolved?.object?.objectId
    if (objectId === undefined) return undefined
    const answer = await cdp.send('Runtime.callFunctionOn', {
      objectId,
      functionDeclaration: typedProbe(),
      awaitPromise: true,
      returnByValue: true,
    }).catch(() => undefined) as { result?: { value?: unknown } } | undefined
    const said = readTyped(answer?.result?.value)
    if (said !== undefined && !said.accepts) {
      throw untypableError(target, said.why ?? 'the page would not take it')
    }
    return said
  }

  /**
   * The DOM node a ref names, and what it was when the snapshot labelled it.
   * @param ref - a ref from a snapshot of the current page.
   * @returns the element the ref names.
   * @throws {Error} when this page never handed out that ref.
   */
  private nodeFor(ref: string): RefTarget {
    const target = this.labels.targetOf(ref)
    if (target === undefined) {
      throw new Error(
        `dsh-browser: ${ref} is not a ref from a snapshot of the current page; `
        + 'call browser_snapshot and use a ref from its result',
      )
    }
    return target
  }

  /**
   * Evaluate an expression over one CDP session.
   *
   * A top-level `await` is a syntax error in the plain form and a valid REPL
   * expression in the other, so the REPL form is the retry rather than the
   * default: measured 2026-09-24, `replMode` also stops `awaitPromise` from
   * unwrapping a returned promise, which would turn `fetch(...)` into `{}`.
   *
   * A declaration the page already has is the second thing worth retrying. The
   * page keeps what an earlier call declared, so a caller that edits one snippet
   * and runs it again is told `Identifier 'el' has already been declared` —
   * a syntax error about the page's scope, not about the snippet. Retried inside
   * a block, the declaration belongs to that call, and everything else about the
   * source behaves the same.
   *
   * The third is a top-level `return`: the same snippet, as a function body,
   * produces the value the caller was asking for.
   * @param cdp - session to evaluate on.
   * @param expression - JavaScript source.
   * @param repl - whether to use the REPL form that accepts top-level await.
   * @param scoped - whether the source is already wrapped in a block of its own.
   * @param bodied - whether the source is already wrapped in a function body.
   * @returns the value, decoded when it is JSON-representable.
   * @throws {Error} when the page throws.
   */
  private async evaluateIn(
    cdp: CDPSession,
    expression: string,
    repl = false,
    scoped = false,
    bodied = false,
  ): Promise<unknown> {
    /** Whether the failure is the plain form rejecting a top-level await. */
    const retryable = (message: string): boolean => !repl && expression.includes('await')
      && /await is only valid|Unexpected (?:token|reserved word) '?await/iu.test(message)
    /** Whether the page refused the source because its scope already has the name. */
    const redeclared = (message: string): boolean => !scoped && /has already been declared/u.test(message)
    /** Whether the page refused a `return` that was not inside a function. */
    const returned = (message: string): boolean => !bodied && /Illegal return statement/u.test(message)
    let outcome: {
      result?: { value?: unknown; unserializableValue?: string; type?: string; objectId?: string }
      exceptionDetails?: { text?: string; exception?: { description?: string } }
    }
    try {
      outcome = await cdp.send('Runtime.evaluate', {
        expression,
        awaitPromise: true,
        returnByValue: true,
        ...repl ? { replMode: true } : {},
      }) as typeof outcome
    } catch (error) {
      // A compile error reaches the caller either as a protocol error or as an
      // exception detail, depending on where Chrome noticed it.
      const message = error instanceof Error ? error.message : String(error)
      if (redeclared(message)) return await this.evaluateIn(cdp, scopedBlock(expression), repl, true)
      if (returned(message)) return await this.evaluateIn(cdp, asyncBody(expression), repl, scoped, true)
      if (retryable(message)) return await this.evaluateIn(cdp, expression, true, scoped)
      throw error
    }
    if (outcome.exceptionDetails !== undefined) {
      const detail = outcome.exceptionDetails.exception?.description ?? outcome.exceptionDetails.text ?? 'evaluation failed'
      if (redeclared(detail)) return await this.evaluateIn(cdp, scopedBlock(expression), repl, true)
      if (returned(detail)) return await this.evaluateIn(cdp, asyncBody(expression), repl, scoped, true)
      if (retryable(detail)) return await this.evaluateIn(cdp, expression, true, scoped)
      throw new Error(detail)
    }
    const result = outcome.result
    if (result?.type === 'function') return await this.callResult(cdp, expression, result, repl, scoped, bodied)
    return result?.value ?? result?.unserializableValue
  }

  /**
   * Call a function the caller's expression produced.
   *
   * `() => 1` is a function, not a call, and a function has no value to send
   * back: it arrives as `{}`, which reads as an empty object and hides the fact
   * that nothing ran — including from a model that wrote `history.back()` and
   * was told the page returned nothing.
   * @param cdp - session the expression was evaluated on.
   * @param expression - the source that produced the function.
   * @param result - the remote object the evaluation answered with.
   * @param repl - whether the answer came from the REPL form.
   * @param scoped - whether the source was wrapped in a block of its own.
   * @param bodied - whether the source was wrapped in a function body.
   * @returns whatever calling the function produced.
   * @throws {Error} when the call throws.
   */
  private async callResult(
    cdp: CDPSession,
    expression: string,
    result: { objectId?: string },
    repl: boolean,
    scoped: boolean,
    bodied: boolean,
  ): Promise<unknown> {
    // A handle on the function is the shortest way to it, and the only one that
    // cannot run the caller's expression a second time.
    if (result.objectId !== undefined) {
      const called = await cdp.send('Runtime.callFunctionOn', {
        objectId: result.objectId,
        functionDeclaration: 'function () { return this() }',
        awaitPromise: true,
        returnByValue: true,
      }) as {
        result?: { value?: unknown; unserializableValue?: string }
        exceptionDetails?: { text?: string; exception?: { description?: string } }
      }
      if (called.exceptionDetails !== undefined) {
        throw new Error(
          called.exceptionDetails.exception?.description ?? called.exceptionDetails.text ?? 'evaluation failed',
        )
      }
      return called.result?.value ?? called.result?.unserializableValue
    }
    // No handle: the expression is the only way back to the function. Writing
    // it as a call is safe here because the expression already evaluated to a
    // function, which is a value the page handed over rather than an action.
    return await this.evaluateIn(cdp, `(${expression})()`, repl, scoped, bodied)
  }

  /**
   * Apply viewer input to the active page, or to the page a viewer names.
   *
   * A viewer that names a page drives that page whether or not it is the one
   * the tools act on: a pane mirrors its page, and its clicks belong there.
   * Nothing here starts a browser — the page's existence is the proof one is
   * running, and a pane on a page that is gone must not raise one over it.
   * @param message - the decoded viewer message.
   * @param targetId - the page's CDP target id, when the viewer names one.
   * @throws {Error} when a named page does not exist.
   */
  async input(message: InputMessage, targetId?: string): Promise<void> {
    if (targetId === undefined) {
      await this.ensure()
      const cdp = this.cdpSession()
      const size = await this.viewportSize(cdp)
      await dispatchInput(cdp, scaleToViewport(message, size))
      return
    }
    const { cdp, release } = await this.sessionForPage(targetId)
    try {
      const size = await this.viewportSize(cdp, targetId)
      await dispatchInput(cdp, scaleToViewport(message, size))
    } finally {
      await release()
    }
  }

  /**
   * The page's CSS viewport, cached briefly so a pointer move is not a round trip.
   * @param cdp - session attached to the page.
   * @param key - which page's viewport this is: a target id, or `active` for the un-named one.
   * @returns the viewport in CSS pixels.
   */
  async viewportSize(cdp: CDPSession, key = 'active'): Promise<{ width: number; height: number }> {
    const now = Date.now()
    const cached = this.viewports.get(key)
    if (cached !== undefined && now - cached.at < VIEWPORT_TTL_MS) return cached.size
    const metrics = await cdp.send('Page.getLayoutMetrics') as {
      cssVisualViewport?: { clientWidth?: number; clientHeight?: number }
    }
    const size = {
      width: metrics.cssVisualViewport?.clientWidth ?? 0,
      height: metrics.cssVisualViewport?.clientHeight ?? 0,
    }
    this.viewports.set(key, { at: now, size })
    return size
  }

  /** Forget the viewport a page reported, after the document it came from is gone. */
  private invalidateViewport(page: Page | undefined): void {
    this.viewports.delete('active')
    const targetId = page === undefined ? undefined : this.pageIds.get(page)
    if (targetId !== undefined) this.viewports.delete(targetId)
  }

  /**
   * The CDP session to drive one named page with: its mirror's, or a temporary
   * one that is released after use.
   *
   * A mirror exists while someone watches the page, and its session is already
   * attached to it; a page nobody watches still answers input, through a
   * session that lives for the call.
   * @param targetId - the page's CDP target id.
   */
  private async sessionForPage(targetId: string): Promise<{
    cdp: CDPSession
    release: () => Promise<void>
  }> {
    const mirror = this.mirrors.get(targetId)
    if (mirror !== undefined) return { cdp: mirror.cdp, release: async () => {} }
    const page = this.pageByTargetId(targetId)
    if (page === undefined) {
      throw new Error(`dsh-browser: session ${this.sessionId} has no page ${targetId}`)
    }
    const context = this.session?.context
    if (context === undefined) throw new Error(this.unusable())
    const cdp = await context.newCDPSession(page)
    return { cdp, release: () => cdp.detach().catch(() => {}) }
  }

  /**
   * The text the page has selected, for the pane's own clipboard.
   *
   * A copy or a cut is a trusted keystroke in the browser the *user* is in — the
   * mirrored page never receives one, so the pane cannot let the page do the
   * copying. The selection, however, lives in the mirrored page, and this is what
   * asks it for the text.
   *
   * The focused control's own selection comes first: in a text field the
   * document selection is usually collapsed, and the field's range is what a
   * copy would take there.
   * @param targetId - the page's CDP target id, when the viewer names one.
   * @returns the selected text, empty when nothing is selected.
   */
  async selectionText(targetId?: string): Promise<string> {
    if (targetId !== undefined) {
      const { cdp, release } = await this.sessionForPage(targetId)
      try {
        return await this.selectionOf(cdp)
      } finally {
        await release()
      }
    }
    await this.ensure()
    return await this.selectionOf(this.cdpSession())
  }

  /** Read the selection on one page's session. */
  private async selectionOf(cdp: CDPSession): Promise<string> {
    const text = await this.evaluateIn(cdp, `(() => {
      const active = document.activeElement
      if (active !== null && typeof active.selectionStart === 'number'
        && active.selectionStart !== active.selectionEnd) {
        return String(active.value).slice(active.selectionStart, active.selectionEnd)
      }
      return window.getSelection()?.toString() ?? ''
    })()`)
    return typeof text === 'string' ? text : ''
  }

  /**
   * Close one page of this browser, by the CDP target id a sidebar tab names.
   *
   * Closing the last page is closing the browser: Chrome exits when its last
   * tab goes, so the close is the deliberate stop — a viewer coming back must
   * not start a new one over it — and not a page close that a fresh blank page
   * would paper over. A page that is already gone has nothing to close, and in
   * particular this is not a reason to stop a browser that may outlive it.
   * @param targetId - the page's CDP target id, as the tab list reports it.
   */
  async closePage(targetId: string): Promise<void> {
    const page = this.pageByTargetId(targetId)
    if (page === undefined) return
    const remaining = this.session?.context.pages() ?? []
    if (remaining.length <= 1) {
      await this.stop()
      return
    }
    await page.close().catch((error: unknown) => {
      this.logger.warn(error instanceof Error ? error : new Error(String(error)))
    })
    this.publish()
  }

  /**
   * Open a page and make it the one tools act on.
   *
   * A browser that is not running is started, and the page it comes up on is
   * the page this returns: a browser and a first page are one answer, not two.
   * A browser that is already running gets a new blank page beside the others.
   * This is what the Sidebar's browser entry asks for, so each ask is a tab of
   * its own rather than the tab that is already there.
   *
   * `request` names the record that asked, so the same record asking again — a
   * pane remounted by a tab switch, a Session change, or a client reload — gets
   * the page it already opened instead of a second one. A page that is gone
   * makes the next ask from that record an open again.
   * @param options - the address to load in the new page, and the asking record.
   * @returns the page as the tab list describes it, or `undefined` when the
   *   browser did not name it — a page no tab can carry.
   * @throws {Error} when the browser cannot be started.
   */
  async openPage(options: { url?: string; request?: string } = {}): Promise<TabSummary | undefined> {
    const { request } = options
    if (request !== undefined) {
      const remembered = this.openRequests.get(request)
      if (remembered !== undefined) {
        const held = this.pageByTargetId(remembered)
        if (held !== undefined) return this.summaryOfPage(held)
        this.openRequests.delete(request)
      }
    }
    const running = this.state === 'ready'
    await this.ensure()
    const context = this.session?.context
    if (context === undefined) throw new Error(this.unusable())
    // A browser this call started already has the page it came up on: asking for
    // a browser and for a page at the same moment is that page, not an extra
    // blank beside it.
    const page = running ? await context.newPage() : this.requirePage()
    await this.adopt(page)
    if (options.url !== undefined) await this.navigate(options.url)
    const summary = this.summaryOfPage(page)
    if (request !== undefined && summary?.targetId !== undefined) {
      this.openRequests.set(request, summary.targetId)
    }
    return summary
  }

  /**
   * Make one named page the page tools act on.
   *
   * A pane's mirror does not decide this: a tab watches the page it names, and
   * the tools address the page that was selected here. Selecting the page
   * already selected changes nothing, so what that page said about itself
   * survives a selection that moves nothing.
   * @param targetId - the page's CDP target id, as the tab list reports it.
   * @returns the page as the tab list describes it.
   * @throws {Error} when no page by that id exists.
   */
  async selectPage(targetId: string): Promise<TabSummary> {
    const page = this.pageByTargetId(targetId)
    if (page === undefined) {
      throw new Error(`dsh-browser: session ${this.sessionId} has no page ${targetId}`)
    }
    if (page !== this.page) await this.adopt(page)
    const summary = this.summaryOfPage(page)
    if (summary === undefined) {
      throw new Error(`dsh-browser: session ${this.sessionId} no longer names page ${targetId}`)
    }
    return summary
  }

  /**
   * Open an address in one named page — the pane's own address bar, which acts
   * on the page it mirrors, not on whichever page the tools act on.
   * @param targetId - the page's CDP target id.
   * @param url - absolute address to load.
   * @throws {Error} when no page by that id exists.
   */
  async navigatePage(targetId: string, url: string): Promise<void> {
    const page = this.pageByTargetId(targetId)
    if (page === undefined) {
      throw new Error(`dsh-browser: session ${this.sessionId} has no page ${targetId}`)
    }
    this.invalidateViewport(page)
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30_000 })
    this.publish()
  }

  /**
   * Reload one named page, the same way: the pane's own control, on its own page.
   * @param targetId - the page's CDP target id.
   * @throws {Error} when no page by that id exists.
   */
  async reloadPage(targetId: string): Promise<void> {
    const page = this.pageByTargetId(targetId)
    if (page === undefined) {
      throw new Error(`dsh-browser: session ${this.sessionId} has no page ${targetId}`)
    }
    this.invalidateViewport(page)
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 30_000 })
    this.publish()
  }

  /**
   * Forget this conversation's own state: a browser it was watching is gone.
   *
   * The mirror and the page pointer are this side's; the process, the port, and
   * the page registry died with the browser and are the host's to forget. What
   * survives is the labels' numbering — deliberately, so a ref this conversation
   * handed out before the browser died can never be mistaken for one a later
   * snapshot of a new page hands out under the same name.
   */
  private forgetOwnState(): void {
    void this.closeStream()
    this.openRequests.clear()
    this.adoptingPage = undefined
    this.page = undefined
    this.cdp = undefined
    this.liveScript = undefined
    this.labels.forgetPage()
  }

  /**
   * Stop this conversation's use of the browser.
   *
   * On a shared browser this is what "close this conversation's browser" means:
   * its own pages go, and the process stays up for everyone else. The reference
   * count decides whether the process itself closes, which the pool owns.
   * @returns after this conversation has let go of the browser.
   */
  async close(): Promise<void> {
    await this.closeStream()
    this.forgetOwnState()
    this.setState('closed')
  }

  /**
   * Stop the browser because the user asked, and keep it stopped.
   *
   * The pane's own close control lands here rather than on {@link close},
   * because the two differ in what happens next: this one makes the close stand
   * until something genuinely needs a browser, so a viewer that comes back finds
   * a stopped browser instead of a fresh blank page — and on a shared browser it
   * stops the process for everyone on it, which is what the user asked for.
   * @returns after the browser has stopped.
   */
  async stop(): Promise<void> {
    this.userClosed = true
    await this.host.stop()
  }

  /**
   * Replace the browser with a freshly started one.
   * @returns after the new browser is ready.
   * @throws {Error} when the new browser cannot start.
   */
  async restart(): Promise<void> {
    await this.host.close()
    await this.ensure()
  }

  /**
   * Follow the browser's own lifecycle.
   *
   * Both of the events that matter — the context closing, and a page appearing —
   * are observed by the process, which is where they happen; this class learns
   * about them through the {@link SessionParticipant} callbacks at the bottom.
   * The method is kept as the one place a conversation says what a page's arrival
   * means to it, because that is the conversation's decision and not the
   * process's.
   * @param page - the page to offer to this conversation.
   */
  private offer(page: Page): void {
    this.logger.info(`dsh-browser: session ${this.sessionId} opened a new tab`)
    void this.adopt(page).catch((error: unknown) => {
      this.logger.warn(error instanceof Error ? error : new Error(String(error)))
    })
  }

  /**
   * Take one page of the shared browser as this conversation's own.
   *
   * A page carries its own CDP session, so following one means attaching to it
   * and restarting this conversation's mirror from the new attachment; the old
   * attachment is detached afterwards, once nothing is reading it. The page is
   * claimed here, which is what makes it appear in this conversation's tab list
   * and in nobody else's.
   *
   * A page another conversation already owns is refused by the caller rather
   * than adopted: the process is shared, but the pages are not.
   * @param page - the page to adopt.
   * @returns when the page is the one tools and mirror act on.
   */
  private adopt(page: Page): Promise<void> {
    // A caller that opens a page and the context's own announcement of it are
    // one adoption: both arrive here with the same page, and the second joins
    // the first rather than attaching a second CDP session to it.
    if (this.adoptingPage === page) return this.adoption
    this.adoptingPage = page
    const running = this.adopting(page)
    this.adoption = running
    return running
  }

  /** Do the work of `adopt`, which keeps it as this conversation's adoption. */
  private async adopting(page: Page): Promise<void> {
    const previous = this.cdp
    this.page = page
    // A ref names a DOM node on one page; the next page may have neither the
    // node nor the same ones, so nothing from the last page's refs survives —
    // and the labels do not start over, so the ones just forgotten cannot be
    // taken for the new page's own.
    this.labels.forgetPage()
    page.on('framenavigated', (frame) => {
      this.labels.forgetPage()
      // A new document has its own console: keeping the old one would report the
      // previous page's failures as if this one had made them. Only the main
      // frame counts — a page that embeds an iframe which navigates on its own
      // has not replaced the document the caller is reading.
      if (frame === page.mainFrame()) this.forgetSaid()
      this.publish()
    })
    // Only this conversation's own pages get the dialog listener: a dialog
    // belongs to the conversation whose input caused it, and answering another
    // one's would be answering a question nobody here was asked.
    page.on('dialog', (dialog) => {
      if (!this.ownsPage(page)) return
      this.answerDialog(dialog)
    })
    page.on('close', () => {
      const targetId = this.host.forgetPage(page)
      this.viewports.delete(targetId ?? 'active')
      if (this.page !== page) { this.publish(); return }
      void this.moveToSurvivingPage()
    })
    const cdp = await this.host.cdpFor(page)
    if (cdp === undefined) return
    // `active` names a different page from here on, so what the old one
    // reported about its own size is not this page's answer.
    this.viewports.delete('active')
    this.cdp = cdp
    await this.namePage(cdp, page)
    await this.listenToConsole(cdp)
    if (this.config.stealth) await hideHeadlessUserAgent(cdp, page)
    if (this.stream !== undefined) {
      await this.closeStream()
      await this.openStream()
    }
    if (previous !== undefined && previous !== cdp) await previous.detach().catch(() => {})
    this.publish()
  }

  /** Whether a page is one this conversation owns. */
  private ownsPage(page: Page): boolean {
    const targetId = this.pageIds.get(page)
    return targetId !== undefined && this.host.owns(this.sessionId, targetId)
  }

  /**
   * Move this conversation to a page that still exists after its active one
   * closed, or to none when it owns nothing else.
   *
   * On a shared browser the survivor is the conversation's own page, not
   * whatever page the browser happens to hold: adopting somebody else's page
   * would hand this conversation another conversation's tab.
   */
  private async moveToSurvivingPage(): Promise<void> {
    const own = this.host.pages().find(page => this.ownsPage(page))
    if (own === undefined) {
      this.page = undefined
      this.cdp = undefined
      this.publish()
      return
    }
    try {
      await this.adopt(own)
    } catch (error) {
      this.logger.warn(error instanceof Error ? error : new Error(String(error)))
    }
  }

  /**
   * Learn a page's CDP target id — and with it the title it reported — from its
   * own session, and take it as this conversation's page.
   *
   * One call, on the session this class just attached: `Target.getTargetInfo`
   * with no argument answers the target that session is attached to, so the id
   * cannot be confused with another page's even when two pages sit on the same
   * address. A page that answers nothing is reported without an id, and the
   * sidebar can only mirror pages it can name.
   * @param cdp - the page's own CDP session.
   * @param page - the page being named.
   */
  private async namePage(cdp: CDPSession, page: Page): Promise<void> {
    try {
      const answer = await cdp.send('Target.getTargetInfo') as {
        targetInfo?: { targetId?: unknown; title?: unknown }
      }
      const targetId = answer.targetInfo?.targetId
      if (typeof targetId !== 'string' || targetId === '') return
      const title = answer.targetInfo?.title
      this.host.remember(page, targetId, typeof title === 'string' ? title : undefined)
      this.host.claim(this.sessionId, targetId)
      this.publish()
    } catch {
      // A refused identity call is not an adoption failure: the page works, it
      // just cannot be named yet, and the next publish carries what is known.
    }
  }

  /** Attach the screencast for the current viewers, starting the browser if needed. */
  private async openStreamForViewers(): Promise<void> {
    // A viewer arriving is not a request for a browser: the pane that
    // re-subscribes here shows the closed state, with the restart control it
    // already draws for one. Measured on 2026-09-24: a viewer that re-subscribed
    // after the pane's own close button started a browser nobody asked for.
    if (this.userClosed) return
    try {
      await this.ensure()
    } catch (error) {
      this.logger.warn(error instanceof Error ? error : new Error(String(error)))
      return
    }
    // Viewers may have left while the browser was starting.
    await this.openStream()
  }

  /** Attach the screencast to the active page's CDP session. */
  private async openStream(): Promise<void> {
    if (this.viewers.size === 0 || this.stream !== undefined || this.cdp === undefined) return
    this.stream = await startScreencast(
      this.cdp,
      {
        quality: this.config.quality,
        maxWidth: this.config.maxWidth,
        maxHeight: this.config.maxHeight,
        everyNthFrame: this.config.everyNthFrame,
      },
      frame => { for (const viewer of this.viewers) viewer(frame) },
      (error: unknown) => {
        // A refused acknowledgement is the one failure that silently ends the
        // stream; nothing else observes it, so it is reported here.
        this.logger.warn(error instanceof Error ? error : new Error(String(error)))
      },
    )
  }

  /** Detach the screencast. */
  private async closeStream(): Promise<void> {
    const stop = this.stream
    this.stream = undefined
    if (stop !== undefined) await stop().catch(() => {})
  }

  /** The CDP session, or a failure naming the browser state. */
  private cdpSession(): CDPSession {
    if (this.cdp === undefined) throw new Error(this.unusable())
    return this.cdp
  }

  /** The active page, or a failure naming the browser state. */
  private requirePage(): Page {
    if (this.page === undefined) throw new Error(this.unusable())
    return this.page
  }

  /** Why there is nothing to act on, naming the state and its cause. */
  private unusable(): string {
    return `dsh-browser: session ${this.sessionId}'s browser is ${this.state}`
      + `${this.reason === undefined ? '' : ` (${this.reason})`}`
  }

  /** Record a state change and tell the watchers. */
  private setState(state: BrowserState): void {
    this.host.state = state
    this.publish()
  }

  /** Tell the watchers the status moved. */
  private publish(): void {
    const status = this.status()
    for (const watcher of this.watchers) watcher(status)
  }

  // ---- What the browser process tells this conversation -------------------

  /** The process started, or its state changed. */
  hostChanged(): void {
    this.publish()
  }

  /** The process went away, taking this conversation's pages with it. */
  hostGone(_reason: string): void {
    this.forgetOwnState()
    this.publish()
  }

  /**
   * A page the browser opened while this conversation was acting.
   *
   * This is the only moment the page can be attributed: the protocol carries no
   * "who opened this", and `openerId` exists only for the `window.open` path, so
   * the attribution is the *action* that was running. A page that appeared while
   * this conversation's call was in flight is its own; nothing else is.
   * @param page - the new page, before anything has adopted it.
   */
  hostPage(page: Page): void {
    this.offer(page)
  }
}
