/**
 * The 浏览器 settings section.
 *
 * Values arrive from the plugin's settings namespace — the composition entry
 * with the user's overrides resolved over it — and every control writes one
 * field back through the bound scope, so the page never holds a draft that can
 * disagree with what the browser was launched from.
 *
 * The profile settings are two questions, not one asked twice: the mode decides
 * who shares a sign-in and whether anything is kept, and the directory only
 * decides where. A blank directory is a legitimate answer in every mode — it
 * means "this mode's own default" — which is why the field is never a switch.
 *
 * One row can be absent: the directory row is not rendered in `temp` mode,
 * because that mode keeps nothing and therefore has no directory to name.
 * `settings-layout.ts` owns which modes that is, so the rule is testable.
 *
 * Which fields exist, where they sit, and what they are called all come from
 * `settings-layout.ts`: this file only turns each placement into a control. That
 * split is what keeps a new configuration field from slipping onto the page
 * unlabelled or missing entirely, and it is what the tests can reach.
 *
 * Styles are inline: this plugin builds its client bundle outside the
 * repository's stylesheet pipeline, so a CSS import would have no owner.
 */
import { useCallback, useEffect, useRef, useState, useSyncExternalStore, type CSSProperties, type ReactElement, type ReactNode } from 'react'
import type { ConfigForm, SettingsSectionOwnerProps } from '@deepseek-ai/dsh-client-ui-settings/client'
import type { DshBrowserKey } from './locales.ts'
import { browserStatus, closeBrowserRequest, type ClientBrowserReport } from './api.ts'
import {
  ADVANCED_GROUPS,
  FIELD_COPY,
  GROUP_COPY,
  advancedSummary,
  foldedPlacements,
  instanceLine,
  overriddenCount,
  placementsIn,
  profileDirHint,
  profileDirPlaceholder,
  profileDirVisible,
  sharedCounts,
  statusLine,
  type BrowserSettingsView,
  type FieldPlacement,
} from './settings-layout.ts'

/** Injected face bound in the plugin's apply closure. */
export interface BrowserSettingsInjected {
  /** The namespace form this page reads and writes. */
  readonly form: ConfigForm<BrowserSettingsView>
  /** Copy for this namespace. */
  readonly t: (key: DshBrowserKey) => string
}

/**
 * Every value here is a `--dsw-*` token from ui-theme: the page is read in both
 * palettes, and a name the theme does not define falls back to nothing at all
 * rather than to a colour that happens to suit one of them. The materials are the
 * shared settings ones, so this page sits beside the harness's own cards: a
 * control is `bg-layer-3` inside a `border-l4` hairline at `radius-md`, a label
 * is 13px primary, a hint is 12px tertiary, and a card is `radius-xl` over the
 * settings-card fill and stroke.
 */
const styles: Readonly<Record<string, CSSProperties>> = {
  page: { display: 'flex', flexDirection: 'column', gap: '14px', maxWidth: '720px' },
  intro: { margin: 0, fontSize: '12px', lineHeight: 1.6, color: 'var(--dsw-alias-label-tertiary)' },
  group: { display: 'flex', flexDirection: 'column', gap: '4px', borderTop: '0.5px solid var(--dsw-alias-border-l2)', paddingTop: '6px' },
  row: { display: 'flex', gap: '12px', alignItems: 'flex-start', justifyContent: 'space-between', padding: '10px 0' },
  label: { display: 'flex', flexDirection: 'column', gap: '2px', flex: '1 1 auto', minWidth: 0 },
  name: { fontSize: '13px', fontWeight: 500, lineHeight: 1.5, color: 'var(--dsw-alias-label-primary)' },
  hint: { fontSize: '12px', lineHeight: 1.5, color: 'var(--dsw-alias-label-tertiary)' },
  control: { display: 'flex', gap: '8px', alignItems: 'center', flex: '0 0 auto' },
  input: {
    boxSizing: 'border-box', padding: '6px 12px', width: '240px', font: 'inherit', fontSize: '13px', lineHeight: 1.5,
    border: '0.5px solid var(--dsw-alias-border-l4)', borderRadius: 'var(--dsw-radius-md)',
    background: 'var(--dsw-alias-bg-layer-3)', color: 'var(--dsw-alias-label-primary)',
  },
  number: {
    boxSizing: 'border-box', padding: '6px 12px', width: '84px', font: 'inherit', fontSize: '13px', lineHeight: 1.5,
    border: '0.5px solid var(--dsw-alias-border-l4)', borderRadius: 'var(--dsw-radius-md)',
    background: 'var(--dsw-alias-bg-layer-3)', color: 'var(--dsw-alias-label-primary)',
  },
  select: {
    boxSizing: 'border-box', padding: '6px 12px', font: 'inherit', fontSize: '13px', lineHeight: 1.5,
    border: '0.5px solid var(--dsw-alias-border-l4)', borderRadius: 'var(--dsw-radius-md)',
    background: 'var(--dsw-alias-bg-layer-3)', color: 'var(--dsw-alias-label-primary)',
  },
  reset: {
    border: 'none', background: 'none', padding: 0, font: 'inherit',
    fontSize: '12px', lineHeight: 1.5, color: 'var(--dsw-alias-label-secondary)', cursor: 'pointer',
  },
  note: { margin: 0, fontSize: '12px', lineHeight: 1.5, color: 'var(--dsw-alias-label-tertiary)' },
  status: {
    display: 'flex', gap: '10px', alignItems: 'center', justifyContent: 'space-between',
    padding: '10px 12px', fontSize: '12px', lineHeight: 1.5, borderRadius: 'var(--dsw-radius-xl)',
    border: '0.5px solid var(--dsw-alias-settings-card-stroke)', background: 'var(--dsw-alias-settings-card-fill)',
    color: 'var(--dsw-alias-label-secondary)',
  },
  statusText: { display: 'flex', flexDirection: 'column', gap: '2px', minWidth: 0 },
  statusDetail: { fontSize: '12px', lineHeight: 1.5, color: 'var(--dsw-alias-label-tertiary)', wordBreak: 'break-word', display: 'block' },
  statusRow: { display: 'flex', gap: '8px', alignItems: 'baseline', justifyContent: 'space-between' },
  statusSummary: { fontSize: '12px', lineHeight: 1.5, color: 'var(--dsw-alias-label-tertiary)', cursor: 'pointer' },
  statusFailed: { color: 'var(--dsw-alias-state-error-primary)' },
  fold: { display: 'flex', flexDirection: 'column', gap: '10px', borderTop: '0.5px solid var(--dsw-alias-border-l2)', paddingTop: '12px' },
  foldSummary: { cursor: 'pointer', fontSize: '13px', fontWeight: 500, lineHeight: 1.5, color: 'var(--dsw-alias-label-primary)' },
  block: { display: 'flex', flexDirection: 'column', gap: '10px' },
  blockDivided: {
    display: 'flex', flexDirection: 'column', gap: '10px',
    borderTop: '0.5px solid var(--dsw-alias-border-l2)', paddingTop: '12px',
  },
  blockTitle: { margin: 0, fontSize: '13px', fontWeight: 500, lineHeight: 1.5, color: 'var(--dsw-alias-label-primary)' },
  blockHint: { margin: 0, fontSize: '12px', lineHeight: 1.5, color: 'var(--dsw-alias-label-tertiary)' },
  save: { margin: 0, fontSize: '12px', lineHeight: 1.5, color: 'var(--dsw-alias-label-tertiary)', minHeight: '18px' },
  saveFailed: { margin: 0, fontSize: '12px', lineHeight: 1.5, color: 'var(--dsw-alias-state-error-primary)', minHeight: '18px' },
}

/**
 * A control is missing.
 *
 * This only compiles while the caller's switch covers every field of
 * {@link BrowserSettingsView}, so adding a configuration field fails the build
 * here until it gets a control — the runtime throw is a backstop that never
 * runs in a build that passed.
 * @param field - the field nothing renders.
 * @returns never.
 */
function unreachableField(field: never): ReactElement {
  throw new Error(`no control for ${String(field)}`)
}

/** One labelled control, with a reset affordance once the user layer holds the field. */
function Row(props: {
  readonly label: string
  readonly hint: string | undefined
  readonly overridden: boolean
  readonly resetLabel: string
  readonly onReset: () => void
  readonly children: ReactNode
}): ReactElement {
  return (
    <div style={styles.row}>
      <div style={styles.label}>
        <span style={styles.name}>{props.label}</span>
        {props.hint === undefined ? null : <span style={styles.hint}>{props.hint}</span>}
      </div>
      <div style={styles.control}>
        {props.children}
        {props.overridden
          ? <button type="button" style={styles.reset} onClick={props.onReset}>{props.resetLabel}</button>
          : null}
      </div>
    </div>
  )
}

/** One block inside the fold: what it covers, then its rows. */
function Block(props: {
  readonly title: string
  readonly hint: string
  readonly divided: boolean
  readonly children: ReactNode
}): ReactElement {
  // A labelled region rather than a heading: the settings page this renders into
  // has no document outline of its own, so a heading level here would be an
  // invented one. The label is what a screen reader announces on entry.
  return (
    <section aria-label={props.title} style={props.divided ? styles.blockDivided : styles.block}>
      <div style={styles.blockTitle}>{props.title}</div>
      <p style={styles.blockHint}>{props.hint}</p>
      {props.children}
    </section>
  )
}

/**
 * The 浏览器 settings page.
 * @param props - section owner props plus the bound namespace scope.
 * @returns the section element.
 */
export function BrowserSettingsSection(
  props: SettingsSectionOwnerProps & BrowserSettingsInjected,
): ReactElement {
  const { form, t } = props
  const subscribe = useCallback((listener: () => void) => form.subscribe(listener), [form])
  const snapshot = useSyncExternalStore(subscribe, () => form.getSnapshot())
  // Held above the early returns so the hook order never changes between the
  // loading, unavailable, and ready renders.
  const [status, setStatus] = useState<ClientBrowserReport | undefined>(undefined)
  const [statusError, setStatusError] = useState<string | undefined>(undefined)
  const [saveError, setSaveError] = useState<string | undefined>(undefined)
  const [saved, setSaved] = useState(false)
  /** The session whose browser is being stopped right now, if one is. */
  const [closing, setClosing] = useState<string | undefined>(undefined)
  const [closeError, setCloseError] = useState<string | undefined>(undefined)
  const timers = useRef<number[]>([])

  /** Read the host's live state; the page cannot see the browser any other way. */
  const refresh = useCallback((): void => {
    void browserStatus().then((next) => {
      setStatus(next)
      setStatusError(undefined)
    }).catch((error: unknown) => {
      setStatusError(error instanceof Error ? error.message : String(error))
    })
  }, [])

  useEffect(() => {
    refresh()
    const pending = timers.current
    return () => {
      for (const id of pending) window.clearTimeout(id)
      pending.length = 0
    }
  }, [refresh])

  /**
   * Stop one session's browser and re-read the report it should leave.
   *
   * The button belongs to a session rather than to the process: what it asks is
   * "this conversation does not want a browser", and the host decides whether
   * that stops a process. The row goes away when the ask answers, because the
   * report lists the browsers that exist and not the ones that did.
   * @param sessionId - the session whose browser should stop.
   */
  const closeBrowser = useCallback((sessionId: string): void => {
    setClosing(sessionId)
    setCloseError(undefined)
    void closeBrowserRequest(sessionId).then(() => {
      refresh()
    }).catch((error: unknown) => {
      setCloseError(error instanceof Error ? error.message : String(error))
    }).finally(() => {
      setClosing(undefined)
    })
  }, [refresh])

  /**
   * Report one settings write, then re-read the browser it may have restarted.
   * A launch field closes the running browser and the next frame request starts
   * a new one, so the later reads are what catch the restarted instance rather
   * than the one that is on its way out. Resetting a field is a write like any
   * other and goes through here too — otherwise the banner keeps reporting the
   * browser the user just replaced.
   * @param operation - the form write to track.
   */
  const commit = (operation: Promise<unknown>): void => {
    setSaved(false)
    setSaveError(undefined)
    void operation.then(() => {
      setSaved(true)
      for (const delay of [1_500, 4_000, 8_000]) {
        timers.current.push(window.setTimeout(refresh, delay))
      }
    }).catch((error: unknown) => {
      setSaveError(error instanceof Error ? error.message : String(error))
    })
  }

  /**
   * Write one field and report both the write and the browser it may restart.
   * @param field - the configuration field.
   * @param next - its new value.
   */
  const write = (field: keyof BrowserSettingsView, next: unknown): void => {
    commit(form.set(field, next))
  }

  if (snapshot.status === 'loading') return <p style={styles.intro}>{t('settingsLoading')}</p>
  const value = snapshot.value
  if (value === undefined) return <p style={styles.intro}>{t('settingsUnavailable')}</p>

  const user = (typeof snapshot.user === 'object' && snapshot.user !== null ? snapshot.user : {}) as Record<string, unknown>
  /** A field the user layer holds, so clearing it restores the composed value. */
  const owns = (field: keyof BrowserSettingsView): boolean => Object.hasOwn(user, field)
  /** A field is overridden once the user layer holds it. */
  const row = (
    label: string,
    field: keyof BrowserSettingsView,
    control: ReactNode,
    hint?: string,
  ): ReactElement => (
    <Row
      label={label}
      hint={hint}
      overridden={owns(field)}
      resetLabel={t('settingsReset')}
      onReset={() => { commit(form.unset(field)) }}
    >
      {control}
    </Row>
  )

  /** The control one placed field renders. */
  const control = (field: keyof BrowserSettingsView): ReactElement => {
    switch (field) {
      case 'headless':
        return (
          <select
            style={styles.select}
            value={value.headless ? 'headless' : 'headful'}
            onChange={(event) => { write('headless', event.target.value === 'headless') }}
          >
            <option value="headless">{t('settingsHeadless')}</option>
            <option value="headful">{t('settingsHeadful')}</option>
          </select>
        )
      case 'channel':
        return (
          <select
            style={styles.select}
            value={value.channel}
            onChange={(event) => { write('channel', event.target.value) }}
          >
            <option value="chrome">{t('settingsChannelChrome')}</option>
            <option value="msedge">{t('settingsChannelEdge')}</option>
          </select>
        )
      case 'profileMode':
        return (
          <select
            style={styles.select}
            value={value.profileMode}
            onChange={(event) => {
              const next = event.target.value as BrowserSettingsView['profileMode']
              write('profileMode', next)
            }}
          >
            <option value="temp">{t('settingsProfileModeTemp')}</option>
            <option value="session">{t('settingsProfileModeSession')}</option>
            <option value="workspace">{t('settingsProfileModeWorkspace')}</option>
          </select>
        )
      case 'userDataDir':
        // A location, not a persistence switch: the mode above already answered
        // "is anything kept", so this only asks where.
        return (
          <input
            style={styles.input}
            value={value.userDataDir}
            spellCheck={false}
            placeholder={t(profileDirPlaceholder(value.profileMode))}
            onChange={(event) => { write('userDataDir', event.target.value) }}
          />
        )
      case 'stealth':
        return (
          <select
            style={styles.select}
            value={value.stealth ? 'on' : 'off'}
            onChange={(event) => { write('stealth', event.target.value === 'on') }}
          >
            <option value="on">{t('settingsStealthOn')}</option>
            <option value="off">{t('settingsStealthOff')}</option>
          </select>
        )
      case 'executablePath':
        return (
          <input
            style={styles.input}
            value={value.executablePath}
            spellCheck={false}
            onChange={(event) => { write('executablePath', event.target.value) }}
          />
        )
      case 'debugPortMin':
        return (
          <input
            style={styles.number}
            type="number"
            min={1}
            max={65535}
            value={value.debugPortMin}
            onChange={(event) => { write('debugPortMin', Number(event.target.value)) }}
          />
        )
      case 'debugPortMax':
        return (
          <input
            style={styles.number}
            type="number"
            min={1}
            max={65535}
            value={value.debugPortMax}
            onChange={(event) => { write('debugPortMax', Number(event.target.value)) }}
          />
        )
      case 'viewportWidth':
        return (
          <input
            style={styles.number}
            type="number"
            min={320}
            max={3840}
            value={value.viewportWidth}
            onChange={(event) => { write('viewportWidth', Number(event.target.value)) }}
          />
        )
      case 'viewportHeight':
        return (
          <input
            style={styles.number}
            type="number"
            min={240}
            max={2160}
            value={value.viewportHeight}
            onChange={(event) => { write('viewportHeight', Number(event.target.value)) }}
          />
        )
      case 'quality':
        return (
          <input
            style={styles.number}
            type="number"
            min={1}
            max={100}
            value={value.quality}
            onChange={(event) => { write('quality', Number(event.target.value)) }}
          />
        )
      case 'snapshotAttributes':
        return (
          <input
            style={styles.input}
            value={value.snapshotAttributes}
            spellCheck={false}
            onChange={(event) => { write('snapshotAttributes', event.target.value) }}
          />
        )
      case 'snapshotIgnore':
        return (
          <input
            style={styles.input}
            value={value.snapshotIgnore}
            spellCheck={false}
            onChange={(event) => { write('snapshotIgnore', event.target.value) }}
          />
        )
    }
    return unreachableField(field)
  }

  /** One placed field as a labelled row. */
  const placedRow = (placement: FieldPlacement): ReactElement => {
    const copy = FIELD_COPY[placement.field]
    // The directory row is the one field whose meaning — and therefore whose
    // explanation — changes with another field's value.
    const hint = placement.field === 'userDataDir'
      ? profileDirHint(value.profileMode)
      : copy.hint
    return row(
      t(copy.label),
      placement.field,
      control(placement.field),
      hint === undefined ? undefined : t(hint),
    )
  }

  const hiddenChanges = overriddenCount(user, foldedPlacements())
  const shared = sharedCounts(status?.instances ?? [])

  return (
    <div style={styles.page}>
      <p style={styles.intro}>{t('settingsIntro')}</p>

      <div style={styles.status}>
        <div style={styles.statusText}>
          <span style={statusError !== undefined ? styles.statusFailed : undefined}>
            {statusError !== undefined
              ? t('settingsStatusUnknown').replace('{error}', statusError)
              : statusLine(status, t)}
          </span>
          {(status?.instances.length ?? 0) === 0 ? null : (
            <details>
              <summary style={styles.statusSummary}>
                {t('settingsSessionsCount').replace('{count}', String(status?.instances.length ?? 0))}
              </summary>
              {status?.instances.map(instance => (
                <div key={instance.sessionId} style={styles.statusRow}>
                  <span style={styles.statusDetail} title={instance.sessionId}>
                    {instanceLine(instance, t, shared.get(instance.sessionId) ?? 1)}
                  </span>
                  <button
                    type="button"
                    style={styles.reset}
                    disabled={closing === instance.sessionId}
                    title={t('settingsSessionClose')}
                    onClick={() => { closeBrowser(instance.sessionId) }}
                  >
                    {closing === instance.sessionId ? t('settingsSessionClosing') : t('settingsSessionClose')}
                  </button>
                </div>
              ))}
              {closeError === undefined
                ? null
                : <span style={styles.statusFailed}>{t('settingsSessionCloseFailed').replace('{error}', closeError)}</span>}
            </details>
          )}
        </div>
        <button type="button" style={styles.reset} onClick={refresh}>{t('settingsRefresh')}</button>
      </div>

      {saveError !== undefined
        ? <p style={styles.saveFailed}>{t('settingsSaveFailed').replace('{error}', saveError)}</p>
        : <p style={styles.save}>{saved ? t('settingsSaved') : ''}</p>}

      <div style={styles.group}>
        {placementsIn('everyday').map(placement =>
          // The directory row is the one placed field that can be absent: in
          // `temp` mode there is no directory to name.
          placement.field === 'userDataDir' && !profileDirVisible(value.profileMode) ? null : placedRow(placement))}
      </div>

      <details style={styles.fold}>
        <summary style={styles.foldSummary}>{advancedSummary(t, hiddenChanges)}</summary>
        <p style={styles.note}>{t('settingsAdvancedHint')}</p>
        {ADVANCED_GROUPS.map((group, index) => (
          <Block
            key={group}
            title={t(GROUP_COPY[group].title)}
            hint={t(GROUP_COPY[group].hint)}
            divided={index > 0}
          >
            {placementsIn(group).map(placement => placedRow(placement))}
          </Block>
        ))}
      </details>

      <p style={styles.note}>{t('settingsApplied')}</p>
    </div>
  )
}
