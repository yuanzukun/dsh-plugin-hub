/**
 * The mirror's viewer: a canvas fed by the plugin's WebSocket, and the few
 * controls that act on the browser behind it.
 *
 * Input leaves as fractions of the frame rather than pixels, so the host never
 * needs to know the viewer's size and resizing the Sidebar cannot shift a
 * click. Which message a keystroke becomes — text, a chord, or nothing — is
 * decided in `keys.ts`, against the same key table the host dispatches from.
 *
 * Styles are inline: this plugin builds its client bundle outside the
 * repository's stylesheet pipeline, so a CSS import would have no owner.
 */
import { useCallback, useEffect, useRef, useState, type CSSProperties, type ReactElement, type ReactNode } from 'react'
import type { SidebarRightTabInfo, UseSidebarRightTabInfo } from '@deepseek-ai/dsh-client-ui-sidebar-right/client'
import { openPageRequest } from './api.ts'
import { clipboardChord, clipboardReply, pasteMessage, type ReadingChord } from './clipboard.ts'
import { AddressGlobe } from './glyph.ts'
import { keyMessage } from './keys.ts'
import { targetIdOf } from './pages.ts'
import { streamUrl } from './stream-url.ts'
import { en, type DshBrowserKey } from './locales.ts'

/** Absolute path the host serves the mirror on. */
const STREAM_PATH = '/dsh-browser/stream'

/** Milliseconds between forwarded pointer moves, so a drag does not flood the socket. */
const MOVE_INTERVAL_MS = 33

/** What the viewer knows about the browser it mirrors. */
interface MirrorStatus {
  readonly state: 'idle' | 'starting' | 'ready' | 'failed' | 'closed'
  readonly debugPort?: number | undefined
  readonly url?: string | undefined
  readonly error?: string | undefined
}

/** Composed slot props for this body. */
export interface BrowserBodyProps {
  /**
   * The session this pane belongs to.
   *
   * It is what the viewer names on the socket, and therefore the only thing
   * that decides which browser is mirrored here: two conversations open the
   * same pane and see two different browsers.
   */
  readonly sessionId: string
  /** Copy for this namespace; without it the built-in English dictionary is used. */
  readonly t?: (key: DshBrowserKey) => string
  /**
   * The tab this body is mounted in.
   *
   * Supplied by the Sidebar's own seat alongside whatever `inject` names. A tab
   * names the page it mirrors — its address is built from the page's CDP target
   * id — and that is what decides which page is mirrored here and driven from
   * here: one tab, one page. A tab that names no page (the guide entry's, while
   * the browser is starting) mirrors the page the tools act on.
   */
  readonly useTabInfo?: UseSidebarRightTabInfo | undefined
}

/** Translate one key, falling back to the bundled dictionary at this dynamic boundary. */
function copyOf(t: BrowserBodyProps['t']): (key: DshBrowserKey) => string {
  return key => t === undefined ? en[key] : t(key)
}

/**
 * Where a pointer event landed, as a fraction of the frame.
 *
 * The canvas fits the frame into its box with `object-fit: contain`, so the
 * drawn image is smaller than the box on one axis and centred in it. Measuring
 * against the box would offset every click wherever the two aspect ratios
 * differ, which is exactly the case for a wide page in a narrow Sidebar.
 * @param element - the canvas the event arrived on.
 * @param clientX - pointer x in viewport coordinates.
 * @param clientY - pointer y in viewport coordinates.
 * @returns the position in `0..1` of the frame, clamped to the frame.
 */
function fractionOf(element: HTMLCanvasElement, clientX: number, clientY: number): { x: number; y: number } {
  const rect = element.getBoundingClientRect()
  if (rect.width === 0 || rect.height === 0 || element.width === 0 || element.height === 0) return { x: 0, y: 0 }
  const scale = Math.min(rect.width / element.width, rect.height / element.height)
  const drawnWidth = element.width * scale
  const drawnHeight = element.height * scale
  const x = (clientX - rect.left - (rect.width - drawnWidth) / 2) / drawnWidth
  const y = (clientY - rect.top - (rect.height - drawnHeight) / 2) / drawnHeight
  return { x: Math.min(1, Math.max(0, x)), y: Math.min(1, Math.max(0, y)) }
}

/**
 * Name a DOM button number the way the host's input messages spell it.
 * @param button - the event's button number.
 * @returns the matching button name.
 */
function buttonOf(button: number): 'left' | 'middle' | 'right' {
  if (button === 1) return 'middle'
  if (button === 2) return 'right'
  return 'left'
}

/**
 * Put text on the system clipboard from the page the user is looking at.
 *
 * The async API is the first choice; a browser that refuses it outside its own
 * idea of a gesture still honours the older hidden-textarea route, which is the
 * fallback VS Code's web clipboard keeps as well. Focus is restored either way:
 * the temporary field is a document-wide side effect, and the user's next
 * keystroke belongs wherever it was going.
 * @param text - the text to place on the clipboard.
 */
async function writeClipboard(text: string): Promise<void> {
  try {
    await navigator.clipboard.writeText(text)
    return
  } catch {
    // The async API is refused here; the route below is why this function exists.
  }
  const previous = document.activeElement
  const field = document.createElement('textarea')
  field.setAttribute('aria-hidden', 'true')
  field.style.cssText = 'position:absolute;left:-9999px;top:0;width:1px;height:1px'
  field.value = text
  document.body.appendChild(field)
  field.select()
  try {
    document.execCommand('copy')
  } finally {
    field.remove()
    if (previous instanceof HTMLElement) previous.focus()
  }
}

/** Height of the address bar, which its pill radius is derived from. */
const OMNIBOX_HEIGHT = 30

/**
 * The design tokens the address bar borrows, so it matches the app in either
 * theme. `--dsw-alias-*` are the theme's own aliases: a layer for the field, a
 * border for its edge, and label colours for the text and the icons.
 */
const style: Readonly<Record<string, CSSProperties>> = {
  // Both of these state a height and then add padding or a border to it, so they
  // size to the border box: without that the pane is 12px taller than the box it
  // is given and cuts off its own last row, and the address bar is 2px taller
  // than the radius drawn on it.
  root: {
    boxSizing: 'border-box', display: 'flex', flexDirection: 'column',
    height: '100%', minHeight: 0, gap: '6px', padding: '6px',
  },
  omnibox: {
    boxSizing: 'border-box', display: 'flex', alignItems: 'center', gap: '2px', flex: '0 0 auto',
    height: `${String(OMNIBOX_HEIGHT)}px`, padding: '0 3px 0 9px',
    borderRadius: `${String(OMNIBOX_HEIGHT / 2)}px`,
    background: 'var(--dsw-alias-bg-layer-3)',
    border: '0.5px solid var(--dsw-alias-border-l4)',
  },
  omniboxFocused: { borderColor: 'var(--dsw-alias-state-business-primary)' },
  scheme: { display: 'flex', alignItems: 'center', flex: '0 0 auto', color: 'var(--dsw-alias-label-tertiary)' },
  schemeInsecure: { color: 'var(--dsw-alias-state-warn-label)' },
  address: {
    flex: '1 1 auto', minWidth: 0, height: '100%', padding: '0 4px',
    border: 'none', outline: 'none', background: 'transparent',
    color: 'var(--dsw-alias-label-primary)', font: 'inherit', fontSize: '12px',
  },
  iconButton: {
    display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto',
    width: `${String(OMNIBOX_HEIGHT - 6)}px`, height: `${String(OMNIBOX_HEIGHT - 6)}px`,
    padding: 0, border: 'none', borderRadius: '50%', cursor: 'pointer',
    background: 'transparent', color: 'var(--dsw-alias-label-secondary)',
  },
  iconButtonHovered: {
    background: 'var(--dsw-alias-interactive-bg-hover)',
    color: 'var(--dsw-alias-label-primary)',
  },
  stage: { position: 'relative', flex: '1 1 auto', minHeight: 0, overflow: 'hidden', background: '#101418' },
  canvas: { display: 'block', width: '100%', height: '100%', objectFit: 'contain', outline: 'none' },
  // The paste sink stays in the document but out of the way: a browser pastes
  // into whatever is focused, and for the length of a Ctrl+V this is it.
  pasteSink: {
    position: 'absolute', left: '-9999px', top: 0, width: '1px', height: '1px',
    padding: 0, border: 'none', opacity: 0, resize: 'none',
  },
  note: {
    position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', gap: '8px',
    alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: '12px',
    fontSize: '12px', color: '#93a1b0', pointerEvents: 'none',
  },
  // The canvas is the page, so the overlay sits on whatever colour that page
  // happens to be: without its own background it disappears on a white one.
  noteCard: {
    display: 'flex', flexDirection: 'column', gap: '8px', alignItems: 'center',
    maxWidth: '90%', padding: '10px 14px', borderRadius: '8px',
    background: 'rgba(16, 20, 24, 0.88)', color: '#d7dee6', lineHeight: 1.5,
  },
  // The overlay ignores pointer events so a click reaches the page beneath it;
  // its button has to opt back in.
  noteButton: {
    padding: '4px 8px', fontSize: '12px', cursor: 'pointer', pointerEvents: 'auto',
    background: 'var(--dsw-alias-button-primary-fill)', color: 'var(--dsw-alias-label-primary-foreground)',
    border: 'none', borderRadius: 'var(--dsw-radius-sm)',
  },
  status: {
    flex: '0 0 auto', display: 'flex', gap: '6px', alignItems: 'center',
    fontSize: '11px', color: 'var(--dsw-alias-label-tertiary)',
  },
  statusText: { flex: '1 1 auto', minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  statusButton: {
    flex: '0 0 auto', padding: '2px 8px', fontSize: '11px', cursor: 'pointer', borderRadius: 'var(--dsw-radius-sm)',
    border: '0.5px solid var(--dsw-alias-border-l2)', background: 'transparent',
    color: 'var(--dsw-alias-label-secondary)',
  },
}

/** The lock a secure address shows, drawn at the size the bar's icons share. */
const LOCK_ICON = (
  <>
    <rect x="3.5" y="7" width="9" height="6.5" rx="2" />
    <path d="M5.75 7V5.25a2.25 2.25 0 0 1 4.5 0V7" />
  </>
)

/** The circular arrow a page that needs no navigation shows. */
const RELOAD_ICON = (
  <>
    <path d="M12.75 8a4.75 4.75 0 1 1-1.4-3.36" />
    <path d="M12.9 2.6v3.1h-3.1" />
  </>
)

/** The arrow an edited address shows, which submits it. */
const GO_ICON = (
  <>
    <path d="M3 8h9.5" />
    <path d="M9 4.5 12.5 8 9 11.5" />
  </>
)

/**
 * One icon control inside the address bar.
 *
 * Hover is tracked in state rather than by a stylesheet: this plugin's client
 * bundle has no stylesheet of its own, so every appearance here is an inline
 * style, and a pseudo-class is not one.
 * @param props - the icon, its accessible name, and what it does.
 * @returns the button.
 */
function IconButton(props: {
  readonly label: string
  readonly icon: ReactNode
  readonly onClick: () => void
  readonly submit?: boolean
}): ReactElement {
  const [hovered, setHovered] = useState(false)
  return (
    <button
      type={props.submit === true ? 'submit' : 'button'}
      aria-label={props.label}
      title={props.label}
      onClick={props.onClick}
      onMouseEnter={() => { setHovered(true) }}
      onMouseLeave={() => { setHovered(false) }}
      style={{ ...style.iconButton, ...hovered ? style.iconButtonHovered : {} }}
    >
      <svg
        width="14"
        height="14"
        viewBox="0 0 16 16"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
      >
        {props.icon}
      </svg>
    </button>
  )
}

/**
 * The mirror's body: canvas, address bar, and the browser's own status.
 * @param props - composed slot props.
 * @returns the viewer.
 */
export function BrowserBody({ sessionId, t, useTabInfo }: BrowserBodyProps): ReactNode {
  const copy = copyOf(t)
  // Read once per render, the way a hook is read: it is what says which page
  // this pane is on.
  const tab: SidebarRightTabInfo | undefined = useTabInfo?.()
  const pageId = tab === undefined ? undefined : targetIdOf(tab.tab.contentId)
  /**
   * The tab's own id, which is what a pane with no page asks under: the ask is
   * the tab's, so the same tab asking again — remounted by a tab switch, a
   * Session change, or a client reload — opens nothing new.
   */
  const tabId = tab === undefined ? undefined : tab.tab.id
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const socketRef = useRef<WebSocket | undefined>(undefined)
  const lastMoveRef = useRef(0)
  const pasteSinkRef = useRef<HTMLTextAreaElement | null>(null)
  /**
   * What to do with the selection the mirror is about to report.
   *
   * The copy is armed here, on the keystroke, and spent when the answer arrives:
   * the answer is a round trip away, and the chord is what says whether there is
   * anything to write at all.
   */
  const clipboardRef = useRef<((text: string) => void) | undefined>(undefined)
  const [address, setAddress] = useState('')
  const [status, setStatus] = useState<MirrorStatus | undefined>(undefined)
  const [connected, setConnected] = useState(false)
  const [painted, setPainted] = useState(false)
  const [failure, setFailure] = useState<string | undefined>(undefined)
  const [focused, setFocused] = useState(false)

  /**
   * Draw one received frame.
   * @param buffer - the JPEG bytes of the frame.
   */
  const drawFrame = useCallback(async (buffer: ArrayBuffer): Promise<void> => {
    const canvas = canvasRef.current
    if (canvas === null) return
    const bitmap = await createImageBitmap(new Blob([buffer], { type: 'image/jpeg' }))
    if (canvas.width !== bitmap.width) canvas.width = bitmap.width
    if (canvas.height !== bitmap.height) canvas.height = bitmap.height
    canvas.getContext('2d')?.drawImage(bitmap, 0, 0)
    bitmap.close()
    setPainted(true)
  }, [])

  useEffect(() => {
    const query: Record<string, string> = { session: sessionId }
    // A tab names its page; the socket is bound to that page, so its frames,
    // its input, and its address bar are the page's whether or not the tools
    // act on it right now.
    if (pageId !== undefined) query.page = pageId
    // A pane with no page is the browser entry's own: it exists to hold the page
    // this ask produces, so it asks for one. This is the only thing that opens a
    // page on the user's behalf — a browser already running gets a tab of its
    // own here rather than the one that is already there.
    if (pageId === undefined && tabId !== undefined) {
      void openPageRequest(sessionId, tabId).catch(() => {})
    }
    const socket = new WebSocket(streamUrl(STREAM_PATH, query))
    socket.binaryType = 'arraybuffer'
    socket.onopen = () => { setConnected(true) }
    socket.onclose = () => { setConnected(false) }
    socket.onerror = () => { setConnected(false) }
    socket.onmessage = (event: MessageEvent<string | ArrayBuffer>) => {
      if (typeof event.data !== 'string') {
        void drawFrame(event.data)
        return
      }
      const parsed = JSON.parse(event.data) as { type?: string; status?: MirrorStatus; message?: unknown; text?: unknown }
      if (parsed.type === 'status' && parsed.status !== undefined) {
        setStatus(parsed.status)
        setFailure(undefined)
        return
      }
      // A refused action is otherwise invisible: the status the viewer holds is
      // unchanged, so the failure is what explains why nothing moved.
      if (parsed.type === 'error') setFailure(String(parsed.message))
      // The mirror's selection, on its way back from the host. It is spent at
      // once and can only be spent once: it belongs to the chord that asked.
      if (parsed.type === 'clipboard') {
        const settle = clipboardRef.current
        clipboardRef.current = undefined
        settle?.(String(parsed.text ?? ''))
      }
    }
    socketRef.current = socket
    return () => {
      socketRef.current = undefined
      socket.close()
    }
  }, [drawFrame, sessionId, pageId, tabId])

  // The agent drives the same browser, so the address bar follows the page
  // rather than owning it.
  const browserUrl = status?.url
  useEffect(() => {
    if (browserUrl !== undefined && browserUrl !== '' && browserUrl !== 'about:blank') setAddress(browserUrl)
  }, [browserUrl])

  /**
   * Send one viewer message.
   * @param payload - the message to encode.
   */
  const send = useCallback((payload: unknown): void => {
    const socket = socketRef.current
    if (socket !== undefined && socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(payload))
  }, [])

  /**
   * Send one input message.
   * @param message - the host's input message.
   */
  const sendInput = useCallback((message: unknown): void => {
    send({ type: 'input', message })
  }, [send])

  /**
   * Arm the clipboard for the chord just pressed.
   *
   * A copy with nothing selected must leave the clipboard alone, and only the
   * mirror knows what is selected, so the write waits for its answer:
   * {@link clipboardReply} is the decision, and this is only where it lands.
   * @param chord - the reading chord that was pressed.
   */
  const armClipboard = useCallback((chord: ReadingChord): void => {
    clipboardRef.current = (text: string): void => {
      const reply = clipboardReply(chord, text)
      if (reply.write !== undefined) void writeClipboard(reply.write)
      if (reply.after !== undefined) sendInput(reply.after)
    }
  }, [sendInput])

  /**
   * Navigate to what the address bar holds.
   *
   * Both Enter and the arrow button land here, because an implicit form
   * submission is not the only way this pane is asked to navigate and the two
   * must not drift apart.
   */
  const submit = useCallback((): void => {
    const target = address.trim()
    if (target !== '') send({ type: 'navigate', url: target })
  }, [address, send])

  const state = status?.state
  const shownUrl = status?.url ?? ''
  /** Whether the address bar holds something the browser is not on. */
  const dirty = address.trim() !== '' && address !== shownUrl
  const secure = shownUrl.startsWith('https://')
  const note = failure !== undefined
    ? failure
    : !connected
      ? copy('connecting')
      : painted && state !== 'failed' && state !== 'closed'
        ? undefined
        : state === 'failed'
          ? `${copy('failed')} ${status?.error ?? ''}`.trim()
          : state === 'starting'
            ? copy('starting')
            : state === 'ready'
              ? copy('waiting')
              : state === 'closed'
                ? `${copy('closed')} ${status?.error ?? ''}`.trim()
                : copy('idle')
  // A browser that is gone or broken cannot be recovered by waiting: the pane
  // offers the one action that does recover it, which is starting a new one.
  const recoverable = failure !== undefined || state === 'failed' || state === 'closed'

  return (
    <div style={style.root}>
      <form
        style={{ ...style.omnibox, ...focused ? style.omniboxFocused : {} }}
        onSubmit={(event) => {
          event.preventDefault()
          submit()
        }}
      >
        <span
          style={{ ...style.scheme, ...secure ? {} : style.schemeInsecure }}
          title={secure ? copy('secure') : copy('insecure')}
        >
          {secure
            ? (
              <svg
                width="14"
                height="14"
                viewBox="0 0 16 16"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.3"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                {LOCK_ICON}
              </svg>
            )
            : <AddressGlobe size={14} />}
        </span>
        <input
          style={style.address}
          value={address}
          placeholder={copy('address')}
          spellCheck={false}
          autoComplete="off"
          aria-label={copy('address')}
          onFocus={(event) => {
            setFocused(true)
            // A browser hands you the whole address to replace, not a caret in it.
            event.currentTarget.select()
          }}
          onBlur={() => { setFocused(false) }}
          onChange={(event) => { setAddress(event.target.value) }}
          onKeyDown={(event) => {
            if (event.key === 'Enter') {
              event.preventDefault()
              submit()
            }
          }}
        />
        {dirty
          ? <IconButton label={copy('go')} icon={GO_ICON} onClick={submit} submit />
          : <IconButton label={copy('reload')} icon={RELOAD_ICON} onClick={() => { send({ type: 'reload' }) }} />}
      </form>
      <div style={style.stage}>
        <canvas
          ref={canvasRef}
          tabIndex={0}
          style={style.canvas}
          onContextMenu={(event) => { event.preventDefault() }}
          onMouseDown={(event) => {
            const at = fractionOf(event.currentTarget, event.clientX, event.clientY)
            sendInput({ type: 'mouse', action: 'down', x: at.x, y: at.y, button: buttonOf(event.button), clickCount: 1 })
          }}
          onMouseUp={(event) => {
            const at = fractionOf(event.currentTarget, event.clientX, event.clientY)
            sendInput({ type: 'mouse', action: 'up', x: at.x, y: at.y, button: buttonOf(event.button), clickCount: 1 })
          }}
          onMouseMove={(event) => {
            const now = Date.now()
            if (now - lastMoveRef.current < MOVE_INTERVAL_MS) return
            lastMoveRef.current = now
            const at = fractionOf(event.currentTarget, event.clientX, event.clientY)
            sendInput({ type: 'mouse', action: 'move', x: at.x, y: at.y })
          }}
          onWheel={(event) => {
            const at = fractionOf(event.currentTarget, event.clientX, event.clientY)
            sendInput({ type: 'wheel', x: at.x, y: at.y, deltaX: event.deltaX, deltaY: event.deltaY })
          }}
          onKeyDown={(event) => {
            // The clipboard shortcuts are the pane's, not the mirror's: the page
            // cannot receive them at all, and the system clipboard belongs to the
            // browser the user is in. `clipboard.ts` says why, and which chords.
            const chord = clipboardChord(event)
            if (chord === 'paste') {
              // The browser pastes into whatever is focused when this handler
              // returns, so hand it the sink; the sink's own `paste` event is
              // where the text is read. No permission is involved: the user's
              // keystroke is what lets the browser part with the clipboard.
              pasteSinkRef.current?.focus()
              return
            }
            if (chord !== undefined) {
              event.preventDefault()
              armClipboard(chord)
              send({ type: 'selection' })
              return
            }
            // Text, a chord, or nothing: the decision, and the reasons it is
            // shaped that way, are in `keys.ts` with tests of their own.
            const message = keyMessage(event)
            if (message === undefined) return
            sendInput(message)
            event.preventDefault()
          }}
        />
        {/* The paste sink: the browser's own paste needs something editable to
            land in, and this is where the pane reads it from. Kept out of the
            way and out of the tab order — it is a clipboard pipe, not a field. */}
        <textarea
          ref={pasteSinkRef}
          aria-hidden="true"
          tabIndex={-1}
          value=""
          style={style.pasteSink}
          onChange={() => {}}
          onPaste={(event) => {
            const text = event.clipboardData.getData('text')
            event.preventDefault()
            canvasRef.current?.focus()
            const message = pasteMessage(text)
            if (message !== undefined) sendInput(message)
          }}
        />
        {note === undefined ? null : (
          <div style={style.note}>
            <div style={style.noteCard}>
              <span>{note}</span>
              {recoverable
                ? (
                  <button type="button" style={style.noteButton} onClick={() => { send({ type: 'restart' }) }}>
                    {copy('restart')}
                  </button>
                )
                : null}
            </div>
          </div>
        )}
      </div>
      <div style={style.status}>
        {/* The address bar carries the page; this row carries what the address
            bar cannot — which browser is behind it. A page is closed from its
            tab, not from inside the pane: the tab is what names it. */}
        <span style={style.statusText}>
          {status?.debugPort === undefined ? '' : `${copy('endpoint')} 127.0.0.1:${status.debugPort}`}
        </span>
      </div>
    </div>
  )
}
