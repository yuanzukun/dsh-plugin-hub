/**
 * Local-stack manager for dsh-fetch-search.
 *
 * Two levels of self-healing for a local Crawl4AI deployment:
 *
 * - CONTAINER: while the routing references a local Crawl4AI endpoint — a
 *   `crawl4ai`-adapter custom entry pointing at the loopback API server
 *   (direct, no wrapper), or a contract-v1 `custom` entry (whose wrapper needs
 *   the same container) — the manager (best-effort) ensures the container is
 *   up, and the watchdog re-checks it continuously, so a container that dies
 *   mid-run (Docker restart, crash) is restarted without a dsh restart.
 * - WRAPPER: only a contract-v1 `custom` entry additionally gets the wrapper
 *   process (scripts/crawl4ai-wrapper.mjs) on 127.0.0.1:8787, restarted by
 *   the same watchdog when it dies.
 *
 * The wrapper is spawned with a sanitized env (no HTTP(S)_PROXY), because it
 * only ever talks to the local container. On dispose / when the trigger no
 * longer holds, the watchdog is cleared and the wrapper child is killed.
 * @module dsh-fetch-search/local-stack
 */

import { execFile, spawn, type ChildProcess } from 'node:child_process'
import { existsSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import type { Section } from './settings.ts'

/** The wrapper's local port (matches the wrapper's WRAPPER_PORT default). */
const WRAPPER_PORT = 8787
/** The Crawl4AI container's published local port. */
const CRAWL4AI_PORT = 11235
const CONTAINER_NAME = 'crawl4ai'
const CONTAINER_IMAGE = 'unclecode/crawl4ai:latest'
/** Token used to create/start the container and authenticate the wrapper. */
const DEFAULT_TOKEN = 'dev-crawl4ai-token'
/** How often the watchdog re-checks the wrapper after it started. */
const WATCHDOG_MS = 20_000
/** Rate-limit repeated docker attempts when the container stays down. */
const CONTAINER_COOLDOWN_MS = 60_000

/**
 * Whether a crawl4ai entry's loopback endpoint targets the managed container's
 * published port (empty = URL default), so the manager only adopts entries it
 * can actually heal. Entries on other ports own their lifecycle.
 */
function containerPortOf(baseURL: string): boolean {
  try {
    const port = new URL(baseURL).port
    return port === '' || port === String(CRAWL4AI_PORT)
  } catch {
    return false
  }
}

/** Whether a URL points at the loopback interface. */
export function isLoopbackURL(url: string): boolean {
  try {
    // WHATWG URL keeps IPv6 brackets in hostname ('[::1]'); strip them so the
    // bracketed form counts as loopback too (a loopback custom endpoint with a
    // bracketed IPv6 would otherwise get the proxy applied and break).
    let host = new URL(url).hostname.toLowerCase()
    if (host.startsWith('[') && host.endsWith(']')) host = host.slice(1, -1)
    return host === '127.0.0.1' || host === 'localhost' || host === '::1'
  } catch {
    return false
  }
}

/** The package root (…/fetch) from the built lib/index.js location. */
function packageRoot(): string {
  const here = fileURLToPath(import.meta.url)
  return path.resolve(path.dirname(here), '..')
}

/** The token: environment wins, otherwise the documented default. */
function resolveToken(): string {
  const fromEnv = process.env.CRAWL4AI_API_TOKEN?.trim()
  return fromEnv && fromEnv.length > 0 ? fromEnv : DEFAULT_TOKEN
}

/** Whether something is listening on 127.0.0.1:port (any HTTP response counts). */
async function isPortUp(port: number): Promise<boolean> {
  try {
    await fetch('http://127.0.0.1:' + port + '/', { signal: AbortSignal.timeout(1200) })
    return true
  } catch {
    return false
  }
}

/** Poll until a port answers or the timeout elapses. */
async function waitForPort(port: number, timeoutMs: number): Promise<boolean> {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (await isPortUp(port)) return true
    await new Promise((resolve) => setTimeout(resolve, 1500))
  }
  return isPortUp(port)
}

/** Run a docker CLI command (best-effort). */
function docker(args: string[]): Promise<void> {
  return new Promise((resolve, reject) => {
    execFile('docker', args, { timeout: 90_000 }, (error, _stdout, stderr) => {
      if (error) reject(new Error((stderr || error.message).trim()))
      else resolve()
    })
  })
}

/** The stack manager: owns the wrapper child process and its watchdog. */
export class LocalStackManager {
  private child: ChildProcess | null = null
  private timer: ReturnType<typeof setInterval> | null = null
  private syncing = false
  private starting = false
  private active = false
  private lastContainerAttempt = 0

  constructor(private readonly config: () => Section) {}

  /**
   * Provider names the current routing actually references.
   * Mirrors provider.ts `effectiveChain`: an explicit fallbackChain wins over
   * the adapter+fallback pair, so a provider placed ONLY in the chain still
   * triggers the stack (previously it silently never started).
   */
  private routedNames(config: Section): string[] {
    return config.fallbackChain.length > 0
      ? [...config.fallbackChain]
      : [config.adapter, config.fallback].filter((name) => name.length > 0)
  }

  /** The routing entry behind one provider name, when it is user-registered. */
  private entryOf(config: Section, name: string) {
    return config.customProviders.find((provider) => provider.name === name)
  }

  /**
   * Whether the Crawl4AI CONTAINER should be kept alive: the routing
   * references a crawl4ai-adapter entry at the loopback API server's port, or
   * a contract-v1 custom entry (whose wrapper talks to the same container).
   */
  needsContainer(config: Section = this.config()): boolean {
    return this.routedNames(config).some((name) => {
      const entry = this.entryOf(config, name)
      if (entry === undefined || !isLoopbackURL(entry.baseURL)) return false
      if ((entry.adapter || 'custom') === 'custom') return true
      return entry.adapter === 'crawl4ai' && containerPortOf(entry.baseURL)
    })
  }

  /**
   * Whether the contract-v1 WRAPPER should be kept alive: only a `custom`
   * (contract v1) entry speaks the wrapper's protocol; a native `crawl4ai`
   * entry talks to the container directly and needs no wrapper process.
   */
  needsWrapper(config: Section = this.config()): boolean {
    return this.routedNames(config).some((name) => {
      const entry = this.entryOf(config, name)
      return entry !== undefined && (entry.adapter || 'custom') === 'custom' && isLoopbackURL(entry.baseURL)
    })
  }

  /** Whether any part of the local stack is needed (container or wrapper). */
  needsLocal(config: Section = this.config()): boolean {
    return this.needsContainer(config) || this.needsWrapper(config)
  }

  /** Start the stack when needed, stop it when not. */
  async sync(): Promise<void> {
    if (this.syncing) return
    this.syncing = true
    try {
      const config = this.config()
      if (this.needsContainer(config) || this.needsWrapper(config)) {
        this.active = true
        await this.ensureContainer().catch((error) => {
          console.warn(
            '[dsh-fetch-search] Crawl4AI container ensure failed (fetch will fall back):',
            error instanceof Error ? error.message : error,
          )
        })
        if (this.needsWrapper(config)) await this.ensureWrapper()
        this.armWatchdog()
      } else {
        this.active = false
        this.shutdown()
      }
    } finally {
      this.syncing = false
    }
  }

  /** Start the periodic watchdog once (cleared in shutdown). */
  private armWatchdog(): void {
    if (this.timer !== null) return
    this.timer = setInterval(() => { void this.checkStack() }, WATCHDOG_MS)
    // Do not keep the host process alive just for the watchdog.
    this.timer.unref()
  }

  /**
   * Real-time recovery: re-ensure the container while it is needed (a wrapper
   * being alive says nothing about the container — the watchdog watches the
   * container itself, so a Docker restart mid-run self-heals), and restart the
   * wrapper when it died but is still needed. Both paths are idempotent and
   * rate-limited; docker attempts back off while the container stays down.
   */
  private async checkStack(): Promise<void> {
    if (!this.active || this.syncing) return
    const config = this.config()
    if (this.needsContainer(config)) {
      await this.ensureContainer().catch((error) => {
        console.warn(
          '[dsh-fetch-search] Crawl4AI container ensure failed (fetch will fall back):',
          error instanceof Error ? error.message : error,
        )
      })
    }
    if (this.needsWrapper(config)) await this.ensureWrapper()
  }

  /** Ensure the Crawl4AI container answers on its local port. */
  private async ensureContainer(): Promise<void> {
    if (await isPortUp(CRAWL4AI_PORT)) {
      this.lastContainerAttempt = 0
      return
    }
    // Rate-limit repeated docker attempts while the container stays down.
    const now = Date.now()
    if (now - this.lastContainerAttempt < CONTAINER_COOLDOWN_MS) return
    this.lastContainerAttempt = now
    const token = resolveToken()
    try {
      await docker(['start', CONTAINER_NAME])
    } catch {
      await docker([
        'run', '-d',
        '-p', '127.0.0.1:' + CRAWL4AI_PORT + ':' + CRAWL4AI_PORT,
        '--name', CONTAINER_NAME, '--shm-size=1g',
        '-e', 'CRAWL4AI_API_TOKEN=' + token,
        CONTAINER_IMAGE,
      ])
    }
    await waitForPort(CRAWL4AI_PORT, 60_000)
  }

  /** Ensure the contract-v1 wrapper answers on 127.0.0.1:8787. */
  private async ensureWrapper(): Promise<void> {
    if (this.child !== null || this.starting) return
    if (await isPortUp(WRAPPER_PORT)) return // already serving (user- or previous-started)
    this.starting = true
    try {
      const script = path.join(packageRoot(), 'scripts', 'crawl4ai-wrapper.mjs')
      if (!existsSync(script)) {
        console.warn('[dsh-fetch-search] wrapper script missing: ' + script)
        return
      }
      const child = spawn(process.execPath, [script], {
        env: {
          ...process.env,
          CRAWL4AI_API_TOKEN: resolveToken(),
          WRAPPER_PORT: String(WRAPPER_PORT),
          // The wrapper only talks to the local container: never proxy loopback.
          HTTP_PROXY: '',
          HTTPS_PROXY: '',
          NODE_USE_ENV_PROXY: '0',
          NO_PROXY: '*',
        },
        stdio: 'ignore',
        windowsHide: true,
      })
      child.on('exit', () => {
        if (this.child === child) this.child = null
        // Fast recovery after an unexpected exit (shutdown sets active=false first).
        setTimeout(() => { void this.checkStack() }, 1000)
      })
      this.child = child
      // Give it a moment to bind; failures surface on the next fetch.
      await waitForPort(WRAPPER_PORT, 15_000)
    } finally {
      this.starting = false
    }
  }

  /** Stop the watchdog and kill the wrapper child (if this manager spawned it). */
  shutdown(): void {
    this.active = false
    if (this.timer !== null) {
      clearInterval(this.timer)
      this.timer = null
    }
    if (this.child !== null) {
      const child = this.child
      this.child = null
      try { child.kill() } catch { /* already gone */ }
    }
  }
}
