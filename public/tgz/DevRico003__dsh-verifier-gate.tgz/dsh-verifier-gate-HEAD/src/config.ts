/**
 * Plugin configuration: the composition entry (cordis.patch.yml `config:`)
 * is the base of the hot-reloadable `verifier:` settings section.
 */

import z from '@deepseek-ai/schemastery'
import { CRITERIA_SET_NAMES } from './core/prompts.js'

export interface BackendConfig {
  /** OpenAI-compatible chat-completions base URL; the endpoint must return `logprobs`. */
  baseURL: string
  /** Model id sent to the endpoint. */
  model: string
  /** Environment variable / credential reference holding the API key; empty = no Authorization header. */
  apiKeyEnv: string
  /** Sent as `reasoning_effort` on every verifier call (gate and tools). `high` is the reference setting; `low` is about three times faster with close verdicts; `none` is a one-shot reading; empty sends nothing. */
  reasoningEffort: string
  /** Hard cap per verifier call. Generous on purpose: thinking is never cut short, the idle timer catches a dead stream. */
  timeoutMs: number
  /** Abort a call when the stream delivers nothing for this long. */
  idleTimeoutMs: number
  /** Output cap per verifier call (analysis + score tags). */
  maxTokens: number
  /** Sampling temperature (the reference uses 1.0 so the logprob distribution is informative). */
  temperature: number
  /** `top_logprobs` requested (20 = one alternative per scale letter; the OpenAI API cap). */
  topLogprobs: number
  /** Concurrent verifier calls. */
  concurrency: number
  /** Re-ask when a verifier reply has no parseable score or the call failed; unscored verdicts never count as 0.5. */
  retriesOnFallback: number
  /** Run the first call of a shared prompt prefix to completion before fanning out the rest, so a prefix-caching server serves the trajectory from cache. Saves prefill work at the price of doubling wall-clock; on a local vLLM with fast prefill leave it off. */
  warmPrefix: boolean
}

export interface GateConfig {
  /** Verify every turn at `agent/turn-stopping`. */
  enabled: boolean
  /** Minimum mean reward (0..1) for a turn to pass. */
  threshold: number
  /** Forced continuations per turn before the verifier lets the turn close. */
  maxRounds: number
  /** Repeated evaluations per criterion (K); also the default K of `verifier_assess`. */
  evaluations: number
  /** Criteria set: `auto` picks `coding` when the turn used tools and `general` otherwise; or a set name (general | coding | terminal). */
  criteria: string
  /** Skip turns whose final message asks the user a question (forcing continuation would answer on the user's behalf). */
  skipWhenAskingUser: boolean
  /** A turn opened only by a relay (subagent report, plugin notice), not by the user or a goal round, is gated only when it made at least this many tool calls. */
  minToolCallsWithoutOwnTask: number
  /** Skip child agents (subagents / agent-team members); the parent's turn is verified instead. */
  skipSubagents: boolean
  /** Tool names that mark a turn as deliberately handed back to the user; such turns are never forced on. */
  handoffTools: string[]
  /** Maximum characters of verifier analysis quoted back to the agent. */
  feedbackMaxChars: number
  /** Whole-gate deadline; on expiry the turn closes unverified. */
  timeoutMs: number
}

export interface SelectConfig {
  /** K for `verifier_select` and `verifier_compare`. */
  evaluations: number
  /** Pivot count k for the tournament. */
  pivots: number
  /** Tournament seed (ring order). */
  seed: number
  /** Default criteria set for the pairwise tools. */
  criteria: string
}

export interface TrajectoryConfig {
  /** Cap per tool output / message excerpt. */
  maxStepChars: number
  /** Cap for the whole serialized turn; over it the middle is elided, the opening and the most recent steps stay. */
  maxTotalChars: number
  /** Earlier turns prepended when a turn is a continuation ("Continue."). */
  continuationTurns: number
}

export interface SnapshotConfig {
  /** Register the `ui_snapshot` tool (headless Playwright screenshots for visual evidence). */
  enabled: boolean
  /** Browser channels tried in order: `chrome` = installed Google Chrome, `chromium` = Playwright's own build. */
  channels: string[]
  /** Headless launch; keep true so nothing opens on the user's screen. */
  headless: boolean
  /** Default viewports as WIDTHxHEIGHT. */
  viewports: string[]
  /** Extra wait after load before the shot. */
  settleMs: number
  /** Navigation timeout per page. */
  navigationTimeoutMs: number
  /** Output root; empty = `$DSH_HOME/verifier/snapshots`. */
  dir: string
}

export interface Config {
  /** Master switch. */
  enabled: boolean
  backend: BackendConfig
  gate: GateConfig
  select: SelectConfig
  trajectory: TrajectoryConfig
  snapshot: SnapshotConfig
  /** Register the `verifier_*` tools. */
  tools: boolean
  /** Log every verifier call at info level. */
  verbose: boolean
}

export const BackendConfig: z<BackendConfig> = z.object({
  baseURL: z.string().default('http://127.0.0.1:8000/v1'),
  model: z.string().default('default'),
  apiKeyEnv: z.string().default(''),
  reasoningEffort: z.string().default('high'),
  timeoutMs: z.number().default(3_600_000),
  idleTimeoutMs: z.number().default(900_000),
  maxTokens: z.number().default(65_536),
  temperature: z.number().default(1.0),
  topLogprobs: z.number().default(20),
  concurrency: z.number().default(8),
  retriesOnFallback: z.number().default(1),
  warmPrefix: z.boolean().default(false),
})

export const GateConfig: z<GateConfig> = z.object({
  enabled: z.boolean().default(true),
  threshold: z.number().default(0.6),
  maxRounds: z.number().default(1),
  evaluations: z.number().default(1),
  criteria: z.string().default('auto'),
  skipWhenAskingUser: z.boolean().default(true),
  minToolCallsWithoutOwnTask: z.number().default(8),
  skipSubagents: z.boolean().default(true),
  handoffTools: z.array(z.string()).default(['ask_user', 'ask_user_question', 'AskUserQuestion']),
  feedbackMaxChars: z.number().default(2500),
  timeoutMs: z.number().default(4_200_000),
})

export const SelectConfig: z<SelectConfig> = z.object({
  evaluations: z.number().default(1),
  pivots: z.number().default(1),
  seed: z.number().default(0),
  criteria: z.string().default('general'),
})

export const TrajectoryConfig: z<TrajectoryConfig> = z.object({
  maxStepChars: z.number().default(6000),
  maxTotalChars: z.number().default(300_000),
  continuationTurns: z.number().default(1),
})

export const SnapshotConfig: z<SnapshotConfig> = z.object({
  enabled: z.boolean().default(true),
  channels: z.array(z.string()).default(['chrome', 'chromium']),
  headless: z.boolean().default(true),
  viewports: z.array(z.string()).default(['1440x900', '390x844']),
  settleMs: z.number().default(500),
  navigationTimeoutMs: z.number().default(30_000),
  dir: z.string().default(''),
})

export const Config: z<Config> = z.object({
  enabled: z.boolean().default(true),
  backend: BackendConfig.default({} as BackendConfig),
  gate: GateConfig.default({} as GateConfig),
  select: SelectConfig.default({} as SelectConfig),
  trajectory: TrajectoryConfig.default({} as TrajectoryConfig),
  snapshot: SnapshotConfig.default({} as SnapshotConfig),
  tools: z.boolean().default(true),
  verbose: z.boolean().default(false),
})

/** Fail-loud checks beyond what the schema expresses. */
export function validateConfig(config: Config): void {
  const { backend, gate, select } = config
  if (gate.threshold < 0 || gate.threshold > 1) throw new Error(`dsh-verifier-gate: gate.threshold must be within [0, 1], got ${gate.threshold}`)
  if (!Number.isInteger(gate.maxRounds) || gate.maxRounds < 0) throw new Error(`dsh-verifier-gate: gate.maxRounds must be an integer >= 0, got ${gate.maxRounds}`)
  if (!Number.isInteger(gate.evaluations) || gate.evaluations < 1) throw new Error(`dsh-verifier-gate: gate.evaluations must be an integer >= 1`)
  if (gate.criteria !== 'auto' && !CRITERIA_SET_NAMES.includes(gate.criteria)) throw new Error(`dsh-verifier-gate: gate.criteria must be auto or one of ${CRITERIA_SET_NAMES.join(', ')}, got "${gate.criteria}"`)
  if (!CRITERIA_SET_NAMES.includes(select.criteria)) throw new Error(`dsh-verifier-gate: select.criteria must be one of ${CRITERIA_SET_NAMES.join(', ')}, got "${select.criteria}"`)
  if (!Number.isInteger(select.evaluations) || select.evaluations < 1) throw new Error(`dsh-verifier-gate: select.evaluations must be an integer >= 1`)
  if (!Number.isInteger(select.pivots) || select.pivots < 1) throw new Error(`dsh-verifier-gate: select.pivots must be an integer >= 1`)
  if (!Number.isInteger(backend.topLogprobs) || backend.topLogprobs < 1 || backend.topLogprobs > 20) throw new Error(`dsh-verifier-gate: backend.topLogprobs must be an integer in [1, 20]`)
  if (!Number.isInteger(backend.concurrency) || backend.concurrency < 1) throw new Error(`dsh-verifier-gate: backend.concurrency must be an integer >= 1`)
  if (!/^https?:\/\//.test(backend.baseURL)) throw new Error(`dsh-verifier-gate: backend.baseURL must be an http(s) URL, got "${backend.baseURL}"`)
}
