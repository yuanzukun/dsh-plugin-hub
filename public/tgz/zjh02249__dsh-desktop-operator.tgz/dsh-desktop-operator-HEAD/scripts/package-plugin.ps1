[CmdletBinding()]
param(
    [string]$GoExecutable = "",

    [string]$OutputDirectory = "artifacts\package"
)

$ErrorActionPreference = "Stop"
$pluginRoot = Split-Path -Parent $PSScriptRoot
$buildScript = Join-Path $PSScriptRoot "build-runtime.ps1"
$signingScript = Join-Path $PSScriptRoot "sign-windows-artifacts.ps1"
$sbomScript = Join-Path $PSScriptRoot "generate-sbom.ps1"
$package = Get-Content -Raw -LiteralPath (Join-Path $pluginRoot "package.json") | ConvertFrom-Json
$architectures = @("amd64", "arm64")
$buildArguments = @{ Architecture = $architectures }

function Get-Sha256([string]$Path) {
    $stream = [System.IO.File]::OpenRead($Path)
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    try {
        return (($sha256.ComputeHash($stream) | ForEach-Object { $_.ToString("X2") }) -join "")
    } finally {
        $sha256.Dispose()
        $stream.Dispose()
    }
}
if (-not [string]::IsNullOrWhiteSpace($GoExecutable)) {
    $buildArguments.GoExecutable = $GoExecutable
}

& $buildScript @buildArguments
if ($LASTEXITCODE -ne 0) { throw "Runtime build failed with exit code $LASTEXITCODE." }

$runtimeManifestPath = Join-Path $pluginRoot "runtime\bin\runtime-manifest.json"
$runtimeFiles = @(
    (Join-Path $pluginRoot "runtime\bin\win32-x64\open-computer-use.exe"),
    (Join-Path $pluginRoot "runtime\bin\win32-arm64\open-computer-use.exe")
)
$requireSigning = [string]$env:WINDOWS_SIGNING_REQUIRED -match "^(1|true|yes)$"
$signingOutput = (& $signingScript `
    -Files $runtimeFiles `
    -ReportPath "artifacts\security\windows-signing-report.json" `
    -RuntimeManifestPath $runtimeManifestPath `
    -RequireSigning:$requireSigning | Out-String)
$signingReport = $signingOutput | ConvertFrom-Json
$sbomOutput = (& $sbomScript | Out-String)
$sbomReport = $sbomOutput | ConvertFrom-Json

Push-Location $pluginRoot
try {
    & node --test
    if ($LASTEXITCODE -ne 0) { throw "Plugin tests failed with exit code $LASTEXITCODE." }

    $pnpm = @(Get-Command pnpm -CommandType Application -ErrorAction SilentlyContinue) | Select-Object -First 1
    if ($null -eq $pnpm) { throw "pnpm was not found." }
    $tar = @(Get-Command tar -CommandType Application -ErrorAction SilentlyContinue) | Select-Object -First 1
    if ($null -eq $tar) { throw "tar was not found; it is required to verify the plugin archive." }

    $outputPath = if ([System.IO.Path]::IsPathRooted($OutputDirectory)) {
        [System.IO.Path]::GetFullPath($OutputDirectory)
    } else {
        [System.IO.Path]::GetFullPath((Join-Path $pluginRoot $OutputDirectory))
    }
    New-Item -ItemType Directory -Path $outputPath -Force | Out-Null

    & $pnpm.Source pack --pack-destination $outputPath
    if ($LASTEXITCODE -ne 0) { throw "pnpm pack failed with exit code $LASTEXITCODE." }

    $archive = Get-ChildItem -LiteralPath $outputPath -Filter "*.tgz" -File |
        Sort-Object LastWriteTimeUtc -Descending |
        Select-Object -First 1
    if ($null -eq $archive) { throw "pnpm pack produced no .tgz archive in $outputPath." }

    $entries = @(& $tar.Source -tf $archive.FullName)
    if ($LASTEXITCODE -ne 0) { throw "Could not inspect package archive $($archive.FullName)." }
    $requiredEntries = @(
        "package/lib/index.js",
        "package/README.en.md",
        "package/CHANGELOG.md",
        "package/quality/windows-app-matrix.json",
        "package/scripts/generate-sbom.ps1",
        "package/scripts/sign-windows-artifacts.ps1",
        "package/scripts/verify-dsh-upgrade-rollback.ps1",
        "package/scripts/verify-windows-host.ps1",
        "package/runtime/bin/runtime-manifest.json",
        "package/runtime/bin/win32-x64/open-computer-use.exe",
        "package/runtime/bin/win32-arm64/open-computer-use.exe",
        "package/runtime/windows/main.go",
        "package/runtime/windows/journal.go",
        "package/runtime/windows/journal_windows.go",
        "package/runtime/windows/capture_helper.cs",
        "package/runtime/windows/indicator.ps1",
        "package/runtime/windows/runtime.ps1",
        "package/runtime/windows/scripts/run-windows-action-smoke.ps1",
        "package/runtime/windows/scripts/run-windows-capture-smoke.ps1",
        "package/runtime/windows/scripts/run-windows-messaging-smoke.ps1",
        "package/runtime/windows/scripts/run-windows-modal-smoke.ps1",
        "package/runtime/windows/scripts/run-windows-quality-matrix.ps1",
        "package/runtime/windows/scripts/run-windows-reliability-smoke.ps1",
        "package/runtime/windows/scripts/run-windows-window-smoke.ps1",
        "package/runtime/LICENSE.open-computer-use",
        "package/runtime/THIRD_PARTY_NOTICES.open-computer-use.md"
    )
    $missing = @($requiredEntries | Where-Object { $_ -notin $entries })
    if ($missing.Count -gt 0) {
        throw "Plugin archive is incomplete. Missing: $($missing -join ', ')"
    }

    $verificationRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("dsh-computer-use-package-" + [guid]::NewGuid().ToString("N"))
    try {
        New-Item -ItemType Directory -Path $verificationRoot | Out-Null
        & $tar.Source -xf $archive.FullName -C $verificationRoot
        if ($LASTEXITCODE -ne 0) { throw "Could not extract package archive for runtime verification." }

        $packagedManifest = Get-Content -Raw -LiteralPath (Join-Path $verificationRoot "package\package.json") | ConvertFrom-Json
        if ($null -ne $packagedManifest.dependencies.'open-computer-use') {
            throw "Packaged plugin still depends on the external open-computer-use package."
        }

        $packagedRuntime = Join-Path $verificationRoot "package\runtime\bin\win32-x64\open-computer-use.exe"
        $runtimeVersion = [string](& $packagedRuntime --version)
        if ($LASTEXITCODE -ne 0 -or $runtimeVersion.Trim() -ne [string]$package.version) {
            throw "Packaged runtime version mismatch. Expected $($package.version), received '$runtimeVersion'."
        }

        $mcpInfoJson = [string](& $packagedRuntime mcp-info)
        if ($LASTEXITCODE -ne 0) {
            throw "Packaged MCP runtime metadata probe failed with exit code $LASTEXITCODE."
        }
        try {
            $mcpInfo = $mcpInfoJson | ConvertFrom-Json -ErrorAction Stop
        } catch {
            throw "Packaged MCP runtime returned invalid metadata JSON: $mcpInfoJson"
        }
        if ($mcpInfo.protocolVersion -ne "2025-03-26") {
            throw "Packaged MCP runtime returned unexpected protocol version '$($mcpInfo.protocolVersion)'."
        }
        if ($mcpInfo.serverInfo.version -ne [string]$package.version) {
            throw "Packaged MCP metadata version mismatch. Expected $($package.version), received '$($mcpInfo.serverInfo.version)'."
        }
        $coordinateSelfTestJson = [string](& $packagedRuntime coordinate-self-test)
        if ($LASTEXITCODE -ne 0) {
            throw "Packaged coordinate mapping self-test failed with exit code $LASTEXITCODE."
        }
        try {
            $coordinateSelfTest = $coordinateSelfTestJson | ConvertFrom-Json -ErrorAction Stop
        } catch {
            throw "Packaged coordinate mapping self-test returned invalid JSON: $coordinateSelfTestJson"
        }
        if ($coordinateSelfTest.status -ne "passed" -or -not $coordinateSelfTest.outOfBoundsRejected -or $coordinateSelfTest.negativeTopLeft.x -ne -1920) {
            throw "Packaged coordinate mapping self-test returned unexpected evidence: $coordinateSelfTestJson"
        }
        $toolNames = @($mcpInfo.tools | ForEach-Object { $_.name })
        $requiredTools = @("list_windows", "get_window", "activate_window", "get_window_state", "find_elements", "click", "type_text", "press_key", "set_value")
        $missingTools = @($requiredTools | Where-Object { $_ -notin $toolNames })
        if ($missingTools.Count -gt 0) {
            throw "Packaged MCP runtime is missing required tools: $($missingTools -join ', ')"
        }
    } finally {
        if (Test-Path -LiteralPath $verificationRoot) {
            for ($attempt = 1; $attempt -le 10; $attempt++) {
                try {
                    Remove-Item -LiteralPath $verificationRoot -Recurse -Force -ErrorAction Stop
                    break
                } catch {
                    if ($attempt -eq 10) { throw }
                    Start-Sleep -Milliseconds 100
                }
            }
        }
    }

    [ordered]@{
        status = "passed"
        package = $archive.FullName
        size = $archive.Length
        sha256 = Get-Sha256 $archive.FullName
        runtimeTargets = @("win32-x64", "win32-arm64")
        runtimeVersion = $runtimeVersion.Trim()
        mcpToolCount = $toolNames.Count
        coordinateSelfTest = $coordinateSelfTest
        signing = [ordered]@{
            status = [string]$signingReport.status
            report = [System.IO.Path]::GetFullPath((Join-Path $pluginRoot "artifacts\security\windows-signing-report.json"))
        }
        sbom = [ordered]@{
            format = [string]$sbomReport.format
            specVersion = [string]$sbomReport.specVersion
            path = [string]$sbomReport.path
            sha256 = [string]$sbomReport.sha256
            componentCount = [int]$sbomReport.componentCount
        }
    } | ConvertTo-Json -Depth 4
} finally {
    Pop-Location
}
