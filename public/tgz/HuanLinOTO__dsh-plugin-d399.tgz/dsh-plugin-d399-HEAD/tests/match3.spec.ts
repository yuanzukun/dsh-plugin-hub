import { describe, expect, it } from 'vitest'
import {
  GRID_SIZE,
  areAdjacent,
  cloneBoard,
  findMatches,
  clearMatches,
  applyGravity,
  generateBoard,
  trySwap,
  resolveCascades,
  emptyBoard,
  type Board,
} from '../src/client/games/match3/logic.ts'

describe('generateBoard', () => {
  it('produces a size×size grid', () => {
    const b = generateBoard()
    expect(b.length).toBe(GRID_SIZE)
    for (const row of b) expect(row.length).toBe(GRID_SIZE)
  })

  it('has no pre-existing matches', () => {
    for (let i = 0; i < 50; i++) {
      expect(findMatches(generateBoard()).size).toBe(0)
    }
  })

  it('fills every cell with a non-zero color', () => {
    const b = generateBoard()
    for (const row of b) for (const t of row) expect(t).toBeGreaterThan(0)
  })
})

describe('areAdjacent', () => {
  it('true for orthogonal neighbors', () => {
    expect(areAdjacent(0, 0, 0, 1)).toBe(true)
    expect(areAdjacent(0, 0, 1, 0)).toBe(true)
  })
  it('false for diagonal and far cells', () => {
    expect(areAdjacent(0, 0, 1, 1)).toBe(false)
    expect(areAdjacent(0, 0, 2, 2)).toBe(false)
  })
})

describe('findMatches', () => {
  it('finds a horizontal run of 3', () => {
    const b: Board = [
      [1, 1, 1, 2, 3, 4, 5, 6],
      ...emptyBoard().slice(1),
    ]
    const m = findMatches(b)
    expect(m.has('0,0')).toBe(true)
    expect(m.has('0,1')).toBe(true)
    expect(m.has('0,2')).toBe(true)
    expect(m.size).toBe(3)
  })

  it('finds a vertical run of 4', () => {
    const b = emptyBoard()
    b[0]![0] = 3
    b[1]![0] = 3
    b[2]![0] = 3
    b[3]![0] = 3
    const m = findMatches(b)
    expect(m.size).toBe(4)
    expect(m.has('0,0')).toBe(true)
    expect(m.has('3,0')).toBe(true)
  })

  it('finds no matches in a clean board', () => {
    const b: Board = [
      [1, 2, 3, 4, 5, 6, 1, 2],
      [2, 3, 4, 5, 6, 1, 2, 3],
      [3, 4, 5, 6, 1, 2, 3, 4],
      [4, 5, 6, 1, 2, 3, 4, 5],
      [5, 6, 1, 2, 3, 4, 5, 6],
      [6, 1, 2, 3, 4, 5, 6, 1],
      [1, 2, 3, 4, 5, 6, 1, 2],
      [2, 3, 4, 5, 6, 1, 2, 3],
    ]
    expect(findMatches(b).size).toBe(0)
  })

  it('finds L-shaped and T-shaped overlaps', () => {
    const b = emptyBoard()
    // Horizontal: row 0 cols 0-2 = 1
    b[0]![0] = 1; b[0]![1] = 1; b[0]![2] = 1
    // Vertical: col 0 rows 0-2 = 1 (shares 0,0)
    b[1]![0] = 1; b[2]![0] = 1
    const m = findMatches(b)
    expect(m.has('0,0')).toBe(true)
    expect(m.has('0,1')).toBe(true)
    expect(m.has('0,2')).toBe(true)
    expect(m.has('1,0')).toBe(true)
    expect(m.has('2,0')).toBe(true)
    expect(m.size).toBe(5)
  })
})

describe('clearMatches', () => {
  it('zeros matched cells and returns the count', () => {
    const b: Board = [
      [1, 1, 1, 2, 3, 4, 5, 6],
      ...emptyBoard().slice(1),
    ]
    const matched = findMatches(b)
    const count = clearMatches(b, matched)
    expect(count).toBe(3)
    expect(b[0]![0]).toBe(0)
    expect(b[0]![1]).toBe(0)
    expect(b[0]![2]).toBe(0)
  })
})

describe('applyGravity', () => {
  it('drops tiles into gaps below', () => {
    const b = emptyBoard(4)
    // Row 0 has tiles, rows 1-2 empty, row 3 empty.
    b[0]![0] = 5
    // After gravity, the 5 should fall to the bottom of column 0.
    applyGravity(b, 4)
    expect(b[3]![0]).toBe(5)
    expect(b[0]![0]).not.toBe(0) // refilled with a new tile
  })
})

describe('resolveCascades', () => {
  it('stops when the board has no matches', () => {
    const b = generateBoard()
    expect(resolveCascades(b)).toBe(0)
  })
})

describe('trySwap', () => {
  it('reverts the swap when no match results', () => {
    const b = generateBoard()
    const snapshot = cloneBoard(b)
    const result = trySwap(b, 0, 0, 'right')
    if (!result.matched) {
      expect(result.board).toBe(b) // same ref (unchanged)
      expect(cloneBoard(b)).toEqual(snapshot)
    }
  })

  it('produces a match when swapping creates a 3-run', () => {
    // 4×4 board. Row 0: [2, 1, 2, 2]. Swap (0,0) right → [1, 2, 2, 2] = 3-run.
    const size = 4
    const b = emptyBoard(size)
    b[0]![0] = 2
    b[0]![1] = 1
    b[0]![2] = 2
    b[0]![3] = 2
    // Fill remaining rows with a non-matching pattern (values 3-6 cycling).
    b[1]![0] = 3; b[1]![1] = 4; b[1]![2] = 5; b[1]![3] = 6
    b[2]![0] = 4; b[2]![1] = 5; b[2]![2] = 6; b[2]![3] = 3
    b[3]![0] = 5; b[3]![1] = 6; b[3]![2] = 3; b[3]![3] = 4
    // Verify no pre-existing matches.
    expect(findMatches(b, size).size).toBe(0)
    const result = trySwap(b, 0, 0, 'right', size)
    expect(result.matched).toBe(true)
    expect(result.cleared).toBeGreaterThanOrEqual(3)
    expect(result.board).not.toBe(b)
  })
})

describe('cloneBoard', () => {
  it('produces a deep copy', () => {
    const a = generateBoard()
    const b = cloneBoard(a)
    expect(b).toEqual(a)
    b[0]![0] = -1
    expect(a[0]![0]).not.toBe(-1)
  })
})

describe('emptyBoard', () => {
  it('creates an all-zero grid', () => {
    const b = emptyBoard(4)
    expect(b.length).toBe(4)
    for (const row of b) for (const t of row) expect(t).toBe(0)
  })
})
