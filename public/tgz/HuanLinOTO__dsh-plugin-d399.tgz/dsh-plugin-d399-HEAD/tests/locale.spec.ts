import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'
import { en, zh, NS, type D399Key } from '../src/client/locales.ts'
import { dicts } from '../src/client/dictionaries.ts'

/** The full key set (en is the authority; zh carries the same union by type). */
const KEYS = Object.keys(en)

describe('d399 locale dictionaries', () => {
  it('zh carries the exact same key set as en', () => {
    expect(Object.keys(zh).sort()).toEqual(KEYS.sort())
  })

  it('NS matches the cordis.patch.yml plugin id', () => {
    const yml = readFileSync(new URL('../cordis.patch.yml', import.meta.url), 'utf8')
    const idLine = yml.split('\n').find(line => /^\s*-?\s*id:\s*\S+/.test(line))
    expect(idLine).toBeDefined()
    const id = idLine!.replace(/^\s*-?\s*id:\s*/, '').trim()
    expect(NS).toBe(id)
  })

  it('covers the 19 better-locale override languages exactly', () => {
    const expected = [
      'ja', 'de', 'fr', 'pt', 'ko', 'ar', 'hi', 'id', 'tr', 'vi', 'th',
      'ru', 'it', 'nl', 'sv', 'pl', 'zh-HK', 'zh-TW', 'zh-MO',
    ]
    expect(Object.keys(dicts).sort()).toEqual(expected.sort())
  })

  it('every language dict carries the exact same key set as en', () => {
    for (const [lang, dic] of Object.entries(dicts)) {
      expect(Object.keys(dic).sort(), lang).toEqual(KEYS.sort())
    }
  })

  it('every key is part of the D399Key union', () => {
    const unionCheck: Record<D399Key, string> = Object.fromEntries(KEYS.map(k => [k, k])) as Record<D399Key, string>
    expect(Object.keys(unionCheck).length).toBe(KEYS.length)
  })

  it('every dict value preserves the {placeholder} tokens of its key', () => {
    const tokensOf = (s: string): string[] => [...s.matchAll(/\{(\w+)\}/g)].map(m => m[1]!).sort()
    for (const lang of Object.keys(dicts)) {
      const dic = dicts[lang]!
      for (const key of KEYS) {
        const tokens = tokensOf(en[key]!)
        const translatedTokens = tokensOf(dic[key]!)
        // The translated string must not drop or invent placeholder tokens.
        expect(translatedTokens, `${lang} ${key}`).toEqual(tokens)
      }
    }
  })
})