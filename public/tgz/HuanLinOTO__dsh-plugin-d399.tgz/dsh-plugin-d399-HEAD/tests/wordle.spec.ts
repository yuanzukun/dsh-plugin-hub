import { describe, expect, it } from 'vitest'
import { evaluateGuess, computeStatus, validateGuess, pickAnswer, type LetterState } from '../src/client/games/wordle/logic.ts'
import { ANSWER_WORDS, ACCEPTED_WORDS } from '../src/client/games/wordle/words.ts'

describe('evaluateGuess', () => {
  it('marks all correct when guess equals answer', () => {
    const r = evaluateGuess('APPLE', 'APPLE')
    expect(r.every(x => x.state === 'correct')).toBe(true)
  })

  it('marks all absent when no letters match', () => {
    const r = evaluateGuess('BBBBB', 'APPLE')
    expect(r.every(x => x.state === 'absent')).toBe(true)
  })

  it('marks present for wrong-position letters', () => {
    // A is in APPLE but at position 0; guess A at position 1 → present
    const r = evaluateGuess('BAPLE', 'APPLE')
    // B absent, A present, P correct (pos 2), L correct, E correct
    expect(r.map(x => x.state)).toEqual(['absent', 'present', 'correct', 'correct', 'correct'])
  })

  it('handles duplicate letters correctly (one correct, one absent)', () => {
    // Answer APPLE has one P at index 2. Guess PPEEE: first P present, second P correct.
    const r = evaluateGuess('PPEEE', 'APPLE')
    expect(r[0]!.state).toBe('present')
    expect(r[1]!.state).toBe('correct')
  })

  it('does not double-count a letter beyond its occurrences', () => {
    // Answer has one E; guess with two E's: only one can be present/correct.
    const r = evaluateGuess('EEBBB', 'APPLE')
    const eStates = r.filter(x => x.letter === 'E').map(x => x.state)
    // First E is at position 0 — answer has E at position 4, so present.
    // Second E is at position 1 — no E left in pool, so absent.
    expect(eStates).toContain('present')
    expect(eStates).toContain('absent')
  })
})

describe('computeStatus', () => {
  it('returns won when guess matches answer', () => {
    expect(computeStatus('APPLE', 'APPLE', 3, 6)).toBe('won')
  })

  it('returns lost when out of guesses and not matching', () => {
    expect(computeStatus('BBBBB', 'APPLE', 6, 6)).toBe('lost')
  })

  it('returns playing when guesses remain and no match', () => {
    expect(computeStatus('BBBBB', 'APPLE', 3, 6)).toBe('playing')
  })
})

describe('validateGuess', () => {
  it('accepts a valid 5-letter uppercase word', () => {
    expect(validateGuess('APPLE', 5)).toBe('APPLE')
  })

  it('lowercases input is uppercased', () => {
    expect(validateGuess('apple', 5)).toBe('APPLE')
  })

  it('rejects wrong length', () => {
    expect(validateGuess('APP', 5)).toBeNull()
    expect(validateGuess('APPLES', 5)).toBeNull()
  })

  it('rejects non-letters', () => {
    expect(validateGuess('AP1LE', 5)).toBeNull()
    expect(validateGuess('AP LE', 5)).toBeNull()
  })
})

describe('pickAnswer', () => {
  it('returns a word from the answer list', () => {
    const w = pickAnswer([...ANSWER_WORDS])
    expect(ANSWER_WORDS.includes(w)).toBe(true)
  })

  it('throws on empty list', () => {
    expect(() => pickAnswer([])).toThrow()
  })
})

describe('word list integrity', () => {
  it('every answer word is in the accepted list', () => {
    for (const w of ANSWER_WORDS) {
      expect(ACCEPTED_WORDS.includes(w)).toBe(true)
    }
  })

  it('every word is exactly 5 letters', () => {
    for (const w of ANSWER_WORDS) expect(w.length).toBe(5)
    for (const w of ACCEPTED_WORDS) expect(w.length).toBe(5)
  })
})
