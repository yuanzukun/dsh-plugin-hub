import { describe, expect, it } from 'vitest'
import { createGameRegistry } from '../src/client/registry.ts'
import { registerBuiltinGames } from '../src/client/games/index.ts'
import { MINI_CATALOG, GROUP_RULES, WATER_PUZZLES, applyGroupRule } from '../src/client/games/mini/catalog.ts'
import { registerMiniGames } from '../src/client/games/mini/index.ts'
import { canSolveWater } from '../src/client/games/mini/shared.ts'

describe('mini-game catalog', () => {
  it('contains at least 100 games', () => {
    expect(MINI_CATALOG.length).toBeGreaterThanOrEqual(100)
  })

  it('every entry has a unique id', () => {
    const ids = MINI_CATALOG.map(g => g.id)
    const set = new Set(ids)
    expect(set.size).toBe(ids.length)
  })

  it('every entry has a non-empty name and Component', () => {
    for (const g of MINI_CATALOG) {
      expect(typeof g.name).toBe('string')
      expect(g.name.length).toBeGreaterThan(0)
      expect(typeof g.Component).toBe('function')
    }
  })

  it('ids only use lowercase letters, digits, and hyphens', () => {
    for (const g of MINI_CATALOG) {
      expect(g.id).toMatch(/^[a-z0-9-]+$/)
    }
  })

  it('includes the codebase quiz games', () => {
    const ids = MINI_CATALOG.map(g => g.id)
    expect(ids).toContain('codebase-trivia')
    expect(ids).toContain('codebase-fillblank')
  })
})

describe('water pouring', () => {
  /** BFS over states, mirroring the engine's fill / empty / pour actions. */
  const bfsSolvable = (caps: readonly number[], target: number): boolean => {
    const n = caps.length
    const key = (s: number[]): string => s.join(',')
    const seen = new Set<string>([key(caps.map(() => 0))])
    const queue: number[][] = [caps.map(() => 0)]
    while (queue.length > 0) {
      const s = queue.shift()!
      if (s.some(v => v === target)) return true
      const push = (next: number[]): void => {
        const k = key(next)
        if (seen.has(k)) return
        seen.add(k); queue.push(next)
      }
      for (let i = 0; i < n; i++) {
        if (s[i]! < caps[i]!) { const t = [...s]; t[i] = caps[i]!; push(t) }
        if (s[i]! > 0) { const t = [...s]; t[i] = 0; push(t) }
        for (let j = 0; j < n; j++) {
          if (i === j || s[i]! === 0) continue
          const space = caps[j]! - s[j]!
          if (space <= 0) continue
          const amount = Math.min(s[i]!, space)
          const t = [...s]
          t[i] = s[i]! - amount
          t[j] = s[j]! + amount
          push(t)
        }
      }
    }
    return false
  }

  it('every puzzle passes the gcd feasibility check', () => {
    for (const p of WATER_PUZZLES) {
      expect(canSolveWater(p.caps, p.target), p.id).toBe(true)
    }
  })

  it('every puzzle is actually solvable (BFS over fill/empty/pour)', () => {
    for (const p of WATER_PUZZLES) {
      expect(bfsSolvable(p.caps, p.target), p.id).toBe(true)
    }
  })

  it('every water catalog entry maps to a defined puzzle', () => {
    const defined = WATER_PUZZLES.map(p => p.id).sort()
    const catalogued = MINI_CATALOG.filter(g => g.id.startsWith('water-')).map(g => g.id).sort()
    expect(catalogued).toEqual(defined)
  })

  it('an unwinnable configuration is rejected', () => {
    expect(canSolveWater([3, 3], 1)).toBe(false)
    expect(canSolveWater([5, 5, 5], 4)).toBe(false)
  })
})

describe('group rules', () => {
  it('every catalog entry resolves to a fold group', () => {
    for (const g of MINI_CATALOG) {
      expect(applyGroupRule(g.id), `id ${g.id}`).not.toBeNull()
    }
  })

  it('group ids are unique', () => {
    const ids = GROUP_RULES.map(r => r.group.id)
    expect(new Set(ids).size).toBe(ids.length)
  })

  it('multi-variant families collapse into one group', () => {
    const byGroup = new Map<string, number>()
    for (const g of MINI_CATALOG) {
      const group = applyGroupRule(g.id)!
      byGroup.set(group.id, (byGroup.get(group.id) ?? 0) + 1)
    }
    const counts = [...byGroup.values()]
    expect(counts.length).toBeLessThan(MINI_CATALOG.length / 2)
    expect(counts.some(c => c >= 3)).toBe(true)
  })

  it('fold groups keep an even distribution of member counts', () => {
    const byGroup = new Map<string, number>()
    for (const g of MINI_CATALOG) {
      const group = applyGroupRule(g.id)!
      byGroup.set(group.id, (byGroup.get(group.id) ?? 0) + 1)
    }
    const counts = [...byGroup.values()]
    const min = Math.min(...counts)
    const max = Math.max(...counts)
    expect(min).toBeGreaterThan(0)
    expect(max).toBeLessThanOrEqual(14)
  })
})

describe('registerBuiltinGames with mini catalog', () => {
  it('registers wordle + match3 + 100+ mini games (190+ total)', () => {
    const r = createGameRegistry()
    const dispose = registerBuiltinGames(r)
    try {
      const ids = r.list().map(g => g.id)
      expect(ids).toContain('wordle')
      expect(ids).toContain('match3')
      // 2 built-in (wordle + match3) plus the mini catalog.
      expect(r.list().length).toBe(MINI_CATALOG.length + 2)
    } finally {
      dispose()
    }
  })

  it('disposes all entries on teardown', () => {
    const r = createGameRegistry()
    const dispose = registerBuiltinGames(r)
    expect(r.list().length).toBeGreaterThan(100)
    dispose()
    expect(r.list().length).toBe(0)
  })

  it('does not collide with wordle / match3 ids', () => {
    const ids = MINI_CATALOG.map(g => g.id)
    expect(ids).not.toContain('wordle')
    expect(ids).not.toContain('match3')
  })

  it('mini registrations carry fold group metadata', () => {
    const r = createGameRegistry()
    const dispose = registerMiniGames(r)
    try {
      const grouped = r.list().filter(g => g.group !== undefined)
      // All catalog games resolve a group (riddles/blackjack/highlow are
      // standalone per rules but still matched by rule in this catalog).
      expect(grouped.length).toBe(MINI_CATALOG.length)
      // Fold-group ids are unique across the whole registry.
      const groupIds = new Set(grouped.map(g => g.group!.id))
      expect(groupIds.size).toBe(new Set(GROUP_RULES.map(r => r.group.id)).size)
      // Codebase quiz pair shares one group.
      const codebase = grouped.filter(g => g.group!.id === 'grp-codebase')
      expect(codebase.length).toBe(2)
    } finally {
      dispose()
    }
  })
})
