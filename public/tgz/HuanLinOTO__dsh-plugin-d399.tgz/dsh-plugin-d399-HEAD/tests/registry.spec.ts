import { describe, expect, it, vi } from 'vitest'
import { createGameRegistry, type Game } from '../src/client/registry.ts'

function makeGame(id: string, name: string = id): Game {
  return { id, name, Component: (() => null) as never }
}

describe('createGameRegistry', () => {
  it('starts empty', () => {
    const r = createGameRegistry()
    expect(r.list()).toEqual([])
  })

  it('register adds a game to the list', () => {
    const r = createGameRegistry()
    const dispose = r.register(makeGame('wordle'))
    expect(r.list().map(g => g.id)).toEqual(['wordle'])
    dispose()
    expect(r.list()).toEqual([])
  })

  it('multiple games keep insertion order', () => {
    const r = createGameRegistry()
    const d1 = r.register(makeGame('wordle'))
    const d2 = r.register(makeGame('match3'))
    const d3 = r.register(makeGame('snake'))
    expect(r.list().map(g => g.id)).toEqual(['wordle', 'match3', 'snake'])
    d2()
    expect(r.list().map(g => g.id)).toEqual(['wordle', 'snake'])
    d1(); d3()
    expect(r.list()).toEqual([])
  })

  it('re-registering the same id replaces the entry', () => {
    const r = createGameRegistry()
    const g1 = makeGame('wordle', 'Wordle v1')
    const g2 = makeGame('wordle', 'Wordle v2')
    r.register(g1)
    r.register(g2)
    expect(r.list().length).toBe(1)
    expect(r.list()[0]!.name).toBe('Wordle v2')
  })

  it('dispose of a replaced entry does not remove the current one', () => {
    const r = createGameRegistry()
    const d1 = r.register(makeGame('wordle', 'v1'))
    r.register(makeGame('wordle', 'v2'))
    d1() // should be a no-op (g1 is no longer registered)
    expect(r.list().length).toBe(1)
    expect(r.list()[0]!.name).toBe('v2')
  })

  it('subscribe fires on register and on dispose', () => {
    const r = createGameRegistry()
    const fn = vi.fn()
    const unsub = r.subscribe(fn)
    expect(fn).not.toHaveBeenCalled()
    const d = r.register(makeGame('a'))
    expect(fn).toHaveBeenCalledTimes(1)
    d()
    expect(fn).toHaveBeenCalledTimes(2)
    unsub()
    // After unsubscribe, mutations do not fire.
    r.register(makeGame('b'))
    expect(fn).toHaveBeenCalledTimes(2)
  })

  it('list snapshot is referentially stable until a change', () => {
    const r = createGameRegistry()
    r.register(makeGame('a'))
    const s1 = r.list()
    const s2 = r.list()
    expect(s1).toBe(s2) // same reference (cached)
    r.register(makeGame('b'))
    const s3 = r.list()
    expect(s3).not.toBe(s1) // new reference after change
  })
})
