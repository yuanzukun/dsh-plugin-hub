/**
 * Pure helpers and shared static data for the mini-game engines. No React,
 * no DOM — safe to unit-test and to import from any engine file.
 *
 * @module @huanlin/dsh-plugin-d399/client/games/mini/shared
 */

/** Inclusive random integer in [min, max]. */
export function randInt(min: number, max: number): number {
  return min + Math.floor(Math.random() * (max - min + 1))
}

/** Pick a random element from a non-empty array. */
export function pick<T>(arr: readonly T[]): T {
  if (arr.length === 0) throw new Error('pick: empty array')
  return arr[Math.floor(Math.random() * arr.length)]!
}

/** Fisher–Yates shuffle; returns a new array. */
export function shuffle<T>(arr: readonly T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    const tmp = a[i]!
    a[i] = a[j]!
    a[j] = tmp
  }
  return a
}

/** Range [0, n) as a number array. */
export function range(n: number): number[] {
  return Array.from({ length: n }, (_, i) => i)
}

/** Clamp v into [min, max]. */
export function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v))
}

/** Format a millisecond duration as `N.NNs`. */
export function fmtMs(ms: number): string {
  return `${(ms / 1000).toFixed(2)}s`
}

/** Format a count and total as `n / total`. */
export function fmtCount(n: number, total: number): string {
  return `${n} / ${total}`
}

/** Subset sum: pick operators between numbers to reach a target (24-game). */
export function solve24(nums: readonly number[], target: number = 24): boolean {
  if (nums.length === 1) return Math.abs(nums[0]! - target) < 1e-6
  for (let i = 0; i < nums.length; i++) {
    for (let j = 0; j < nums.length; j++) {
      if (i === j) continue
      const rest = nums.filter((_, k) => k !== i && k !== j)
      const a = nums[i]!
      const b = nums[j]!
      const cands = [a + b, a - b, a * b]
      if (Math.abs(b) > 1e-6) cands.push(a / b)
      for (const c of cands) {
        if (solve24([...rest, c], target)) return true
      }
    }
  }
  return false
}

/** Greatest common divisor of two integers (non-negative result). */
export function gcd(a: number, b: number): number {
  a = Math.abs(a); b = Math.abs(b)
  while (b !== 0) {
    const t = a % b
    a = b
    b = t
  }
  return a
}

/**
 * Whether the classic water-jug puzzle — jug capacities `caps`, unlimited
 * source/sink, actions fill / empty / pour — can measure `target` exactly.
 *
 * Necessary and sufficient: `target` must be a positive integer ≤ the largest
 * jug and a multiple of gcd(caps).
 */
export function canSolveWater(caps: readonly number[], target: number): boolean {
  if (!Number.isInteger(target) || target <= 0 || caps.length === 0) return false
  if (target > Math.max(...caps)) return false
  let g = 0
  for (const c of caps) g = gcd(g, c)
  return target % g === 0
}

/** Animal words for hangman / scramble. */
export const WORDS_ANIMALS: readonly string[] = [
  'CAT', 'DOG', 'ELEPHANT', 'TIGER', 'PANDA', 'GIRAFFE', 'PENGUIN', 'KANGAROO',
  'DOLPHIN', 'OCTOPUS', 'BUTTERFLY', 'CROCODILE', 'HEDGEHOG', 'PEACOCK', 'OWL',
  'RABBIT', 'SQUIRREL', 'HAMSTER', 'CHEETAH', 'LEOPARD', 'ZEBRA', 'KOALA',
]

/** Country names for hangman / scramble. */
export const WORDS_COUNTRIES: readonly string[] = [
  'CHINA', 'JAPAN', 'BRAZIL', 'CANADA', 'FRANCE', 'GERMANY', 'INDIA', 'ITALY',
  'MEXICO', 'NORWAY', 'PORTUGAL', 'RUSSIA', 'SPAIN', 'SWEDEN', 'TURKEY',
  'EGYPT', 'GREECE', 'KENYA', 'ARGENTINA', 'AUSTRALIA', 'VIETNAM', 'KOREA',
]

/** Food words for hangman / scramble. */
export const WORDS_FOOD: readonly string[] = [
  'PIZZA', 'BURGER', 'SUSHI', 'PASTA', 'SALAD', 'BREAD', 'CHEESE', 'NOODLE',
  'DUMPLING', 'PANCAKE', 'SANDWICH', 'CHOCOLATE', 'POPCORN', 'COOKIE',
  'BISCUIT', 'MUFFIN', 'CROISSANT', 'WAFFLE', 'TACO', 'BURRITO', 'RAMEN',
]

/** Movie / pop-culture words for hangman / scramble. */
export const WORDS_MOVIES: readonly string[] = [
  'AVATAR', 'TITANIC', 'MATRIX', 'INCEPTION', 'GLADIATOR', 'JOKER',
  'INTERSTELLAR', 'PARASITE', 'OPPENHEIMER', 'DUNE', 'BARBIE', 'FROZEN',
  'MOANA', 'ENCANTO', 'AVENGERS', 'HARRY POTTER', 'STAR WARS', 'BATMAN',
]

/** Tech words for hangman / scramble. */
export const WORDS_TECH: readonly string[] = [
  'JAVASCRIPT', 'TYPESCRIPT', 'PYTHON', 'KEYBOARD', 'MONITOR', 'INTERNET',
  'ALGORITHM', 'DATABASE', 'COMPILER', 'BROWSER', 'FUNCTION', 'VARIABLE',
  'REACT', 'WEBPACK', 'DOCKER', 'LINUX', 'KERNEL', 'BANDWIDTH', 'PIXEL',
]

/** Pangrams and typing-test phrases. */
export const TYPING_PHRASES_SHORT: readonly string[] = [
  'the quick brown fox jumps',
  'pack my box with five dozen',
  'how vexingly quick daft zebras',
  'sphinx of black quartz judge',
  'two driven jocks help fax my',
]

/** Longer typing passages. */
export const TYPING_PHRASES_LONG: readonly string[] = [
  'the quick brown fox jumps over the lazy dog while a thousand stars glitter above the quiet village',
  'pack my box with five dozen liquor jugs and then we can have a wonderful party under the bright moon',
  'sphinx of black quartz, judge my vow, for I have traveled far to seek the wisdom of the ancient oracle',
]

/** Single-word pangrams (each letter of the alphabet at least once). */
export const TYPING_PANGRAMS: readonly string[] = [
  'Cwm fjord bank glyphs vext quiz',
  'Glib jocks quiz nymph to vex dwarf',
  'Jackdaws love my big sphinx of quartz',
]

/** Trivia: history. Each entry: {q, options[4], answer index}. */
export const TRIVIA_HISTORY: ReadonlyArray<{ q: string; options: readonly string[]; answer: number }> = [
  { q: '哪一年人类首次登月？', options: ['1965', '1969', '1972', '1958'], answer: 1 },
  { q: '丝绸之路始于哪个朝代？', options: ['秦', '汉', '唐', '宋'], answer: 1 },
  { q: '法国大革命爆发于哪一年？', options: ['1776', '1789', '1804', '1815'], answer: 1 },
  { q: '罗马帝国分裂为东西两部分发生在哪一年？', options: ['公元285年', '公元395年', '公元476年', '公元330年'], answer: 1 },
  { q: '哥伦布首次到达美洲是在哪一年？', options: ['1488', '1492', '1500', '1498'], answer: 1 },
  { q: '一战爆发于哪一年？', options: ['1912', '1914', '1916', '1918'], answer: 1 },
]

/** Trivia: science. */
export const TRIVIA_SCIENCE: ReadonlyArray<{ q: string; options: readonly string[]; answer: number }> = [
  { q: '水的化学式是？', options: ['CO2', 'H2O', 'O2', 'NaCl'], answer: 1 },
  { q: '光速约为每秒多少公里？', options: ['30万', '15万', '50万', '10万'], answer: 0 },
  { q: '元素周期表中第一个元素是？', options: ['氧', '氢', '氦', '碳'], answer: 1 },
  { q: 'DNA是几种碱基组成？', options: ['2', '3', '4', '5'], answer: 2 },
  { q: '人体最大的器官是？', options: ['肝脏', '皮肤', '肺', '大脑'], answer: 1 },
  { q: '地球绕太阳一周约多少天？', options: ['365.25', '360', '366', '350'], answer: 0 },
]

/** Trivia: geography. */
export const TRIVIA_GEOGRAPHY: ReadonlyArray<{ q: string; options: readonly string[]; answer: number }> = [
  { q: '世界上最长的河流是？', options: ['亚马逊河', '尼罗河', '长江', '密西西比河'], answer: 1 },
  { q: '世界最高峰是？', options: ['乔戈里峰', '珠穆朗玛峰', '干城章嘉峰', '马卡鲁峰'], answer: 1 },
  { q: '撒哈拉沙漠位于哪个大洲？', options: ['亚洲', '非洲', '澳洲', '美洲'], answer: 1 },
  { q: '世界最大洋是？', options: ['大西洋', '印度洋', '太平洋', '北冰洋'], answer: 2 },
  { q: '加拿大首都是？', options: ['多伦多', '温哥华', '蒙特利尔', '渥太华'], answer: 3 },
  { q: '里海是？', options: ['海', '湖', '海湾', '河流'], answer: 1 },
]

/** Trivia: sports. */
export const TRIVIA_SPORTS: ReadonlyArray<{ q: string; options: readonly string[]; answer: number }> = [
  { q: '一支足球队在场上的球员数量？', options: ['9', '10', '11', '12'], answer: 2 },
  { q: '马拉松全程距离约为多少公里？', options: ['42.195', '40', '45', '38'], answer: 0 },
  { q: 'NBA一场比赛每节多少分钟？', options: ['10', '12', '15', '8'], answer: 1 },
  { q: '奥运会多少年举办一次？', options: ['2', '3', '4', '5'], answer: 2 },
  { q: '网球大满贯不包括以下哪项？', options: ['澳网', '法网', '迪拜公开赛', '美网'], answer: 2 },
  { q: '国际象棋棋盘共多少格？', options: ['64', '81', '49', '100'], answer: 0 },
]

/** Trivia: movies. */
export const TRIVIA_MOVIES: ReadonlyArray<{ q: string; options: readonly string[]; answer: number }> = [
  { q: '《泰坦尼克号》的导演是？', options: ['斯皮尔伯格', '詹姆斯·卡梅隆', '诺兰', '李安'], answer: 1 },
  { q: '《指环王》原著作者是？', options: ['J.K.罗琳', '托尔金', 'C.S.刘易斯', '马丁'], answer: 1 },
  { q: '《千与千寻》的导演是？', options: ['宫崎骏', '新海诚', '今敏', '押井守'], answer: 0 },
  { q: '《阿凡达》主要故事发生在哪颗星球？', options: ['火星', '潘多拉', '塔图因', '厄拉科斯'], answer: 1 },
  { q: '《盗梦空间》主角的工作是？', options: ['间谍', '盗梦者', '警察', '黑客'], answer: 1 },
  { q: '《星球大战》中"愿原力与你同在"英文是？', options: ['May the force be with you', 'Live long and prosper', 'Hakuna matata', 'To infinity and beyond'], answer: 0 },
]

/** Trivia: literature. */
export const TRIVIA_LITERATURE: ReadonlyArray<{ q: string; options: readonly string[]; answer: number }> = [
  { q: '《红楼梦》的作者是？', options: ['曹雪芹', '施耐庵', '罗贯中', '吴承恩'], answer: 0 },
  { q: '《百年孤独》的作者是？', options: ['马尔克斯', '博尔赫斯', '聂鲁达', '略萨'], answer: 0 },
  { q: '莎士比亚不是以下哪部作品的作者？', options: ['哈姆雷特', '麦克白', '战争与和平', '李尔王'], answer: 2 },
  { q: '《1984》的作者是？', options: ['奥威尔', '赫胥黎', '扎米亚京', '布拉德伯里'], answer: 0 },
  { q: '《三体》的作者是？', options: ['刘慈欣', '王晋康', '韩松', '郝景芳'], answer: 0 },
  { q: '《老人与海》的作者是？', options: ['海明威', '福克纳', '菲茨杰拉德', '斯坦贝克'], answer: 0 },
]

/** Classic riddles. Each: {q, a}. */
export const RIDDLES_CLASSIC: ReadonlyArray<{ q: string; a: string }> = [
  { q: '什么东西早上四条腿，中午两条腿，晚上三条腿？', a: '人' },
  { q: '什么话全世界都能听懂？', a: '音乐' },
  { q: '越洗越脏的是什么？', a: '水' },
  { q: '什么东西越分享越多？', a: '快乐' },
  { q: '什么门永远关不上？', a: '球门' },
  { q: '什么东西有头无脚却能说话？', a: '录音机' },
  { q: '一年有几个月有28天？', a: '12' },
  { q: '什么船从来不下水？', a: '宇宙飞船' },
]

/** Trivia: this codebase (dsh-d399). */
export const TRIVIA_CODEBASE: ReadonlyArray<{ q: string; options: readonly string[]; answer: number }> = [
  { q: 'd399 游戏注册表服务叫什么？', options: ['d399Games', 'games', 'miniGames', 'arcade'], answer: 0 },
  { q: '游戏组件必须接收什么 props？', options: ['onClose', 'onStart', 'ctx', 'session'], answer: 0 },
  { q: 'mini 游戏如何绑定参数生成变体？', options: ['bind(Engine, props)', 'clone(Engine)', 'spread(Engine)', 'mixin(Engine)'], answer: 0 },
  { q: '内置游戏注册入口函数叫什么？', options: ['registerBuiltinGames', 'registerGames', 'loadGames', 'initGames'], answer: 0 },
  { q: '消消乐的棋盘尺寸是多少？', options: ['8×8', '6×6', '10×10', '4×4'], answer: 0 },
  { q: 'Wordle 默认有几次猜词机会？', options: ['4', '5', '6', '7'], answer: 2 },
  { q: '客户端 bundle 用什么工具构建？', options: ['tsdown', 'webpack', 'rollup', 'esbuild'], answer: 0 },
  { q: '组件样式使用什么格式？', options: ['CSS Modules', 'Tailwind', 'styled-components', '内联样式'], answer: 0 },
  { q: 'overlay 挂载到哪个 DOM 节点？', options: ['document.body', '#root', '.app', '#sidebar'], answer: 0 },
  { q: '第三方插件如何注册新游戏？', options: ['inject [d399Games] 后 ctx.d399Games.register', '改 package.json', '提交 PR 合入', '写 CSS 样式'], answer: 0 },
  { q: 'mini 引擎分散在几个文件里？', options: ['3', '1', '2', '4'], answer: 0 },
  { q: '游戏菜单展示的数据来自哪里？', options: ['注册表快照', '硬编码列表', 'localStorage', '服务端接口'], answer: 0 },
  { q: 'teaser 在什么时机弹出？', options: ['running false→true', 'running true→false', '页面加载时', '点击按钮时'], answer: 0 },
  { q: 'mini catalog 共有多少款游戏？', options: ['190', '100', '150', '250'], answer: 0 },
  { q: '本插件的 npm 包名是？', options: ['@huanlin/dsh-plugin-d399', '@deepseek/d399', 'dsh-d399', '@d399/blue-whale'], answer: 0 },
  { q: 'Wordle 中 present 表示什么？', options: ['字母对但位置错', '字母完全错误', '位置对字母对', '未使用该字母'], answer: 0 },
  { q: '自定义网页书签存在哪里？', options: ['localStorage', 'indexedDB', 'cookies', 'sessionStorage'], answer: 0 },
  { q: '插件的 host half（Node 侧）是什么？', options: ['空 apply', '定时任务', '数据库服务', 'SSR 渲染'], answer: 0 },
  { q: '同类型游戏变体按什么字段折叠？', options: ['group', 'category', 'tag', 'kind'], answer: 0 },
  { q: 'teaser 弹窗的默认按钮文字是？', options: ['来♂', '开始', '进入', '来玩'], answer: 0 },
]

/** Fill-in-the-blank quiz about this codebase. */
export const QUIZ_CODEBASE: ReadonlyArray<{ q: string; a: string }> = [
  { q: '游戏注册表服务叫什么？', a: 'd399games' },
  { q: '游戏组件必需接收的 props 名？', a: 'onclose' },
  { q: '把引擎绑定到参数生成变体的函数名？', a: 'bind' },
  { q: '内置游戏注册入口函数名？', a: 'registerbuiltingames' },
  { q: '消消乐网格的边长数字？', a: '8' },
  { q: 'Wordle 允许的猜测次数？', a: '6' },
  { q: '客户端 bundle 的构建工具名？', a: 'tsdown' },
  { q: '组件样式文件的扩展名格式？（module + 样式语言）', a: 'module.css' },
  { q: '游戏菜单里同类型变体折叠所依据的字段名？', a: 'group' },
  { q: '自定义网页书签的存储 API 名？', a: 'localstorage' },
  { q: '插件的 npm 组织前缀？', a: 'huanlin' },
  { q: 'mini catalog 中的游戏总数？', a: '190' },
  { q: '本插件包的短名（dsh- 开头）？', a: 'dsh-d399' },
  { q: 'Wordle 答案词表的导出常量名？', a: 'answer_words' },
  { q: 'teaser 弹窗的默认按钮文案？', a: '来♂' },
]

/** Stable color palette used by many engines. */
export const PALETTE: ReadonlyArray<string> = [
  '#e74c3c', '#3498db', '#2ecc71', '#f39c12', '#9b59b6', '#1abc9c',
  '#e67e22', '#34495e', '#16a085', '#f1c40f', '#e84393', '#00b894',
]
