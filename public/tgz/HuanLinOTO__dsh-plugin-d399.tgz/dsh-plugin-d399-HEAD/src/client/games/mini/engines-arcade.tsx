/**
 * Arcade/action mini-game engines — snake, breakout, flappy, asteroids,
 * dodge, runner, etc. Canvas + interval-based.
 *
 * All user-visible copy runs through the `t` prop (`ctx.locale.bind(NS)`).
 *
 * @module @huanlin/dsh-plugin-d399/client/games/mini/engines-arcade
 */
import {
  useEffect,
  useRef,
  useState,
} from 'react'
import type { GameProps } from '../types.ts'
import type { Translate } from '../../locales.ts'
import css from './mini.module.css'
import { PALETTE, clamp, pick, randInt, range } from './shared.ts'

function Header({ title, onClose, t, children }: { title: string; onClose: () => void; t: Translate; children?: React.ReactNode }) {
  return (
    <div className={css.header}>
      <h2 className={css.title}>{title}</h2>
      {children}
      <button type="button" className={css.closeBtn} onClick={onClose} aria-label={t('common.close')}>✕</button>
    </div>
  )
}

function Banner({ kind, text }: { kind: 'win' | 'lose' | 'info'; text: string }) {
  return <div className={`${css.banner} ${css[kind]}`}>{text}</div>
}

// ─── Snake ─────────────────────────────────────────────────
export interface SnakeProps { size: number; speedMs: number }
/** Classic snake on a grid. */
export function Snake({ size, speedMs, onClose, t }: GameProps & SnakeProps) {
  const [body, setBody] = useState<[number, number][]>(() => [[Math.floor(size / 2), Math.floor(size / 2)]])
  const [food, setFood] = useState<[number, number]>(() => [randInt(0, size - 1), randInt(0, size - 1)])
  const [dir, setDir] = useState<[number, number]>([0, 1])
  const [score, setScore] = useState(0)
  const [over, setOver] = useState(false)
  const [running, setRunning] = useState(false)
  const dirRef = useRef(dir)
  const bodyRef = useRef(body)
  const foodRef = useRef(food)
  dirRef.current = dir; bodyRef.current = body; foodRef.current = food

  useEffect(() => {
    const h = (e: KeyboardEvent): void => {
      if (!running) return
      const k = e.key
      const d = dirRef.current
      if (k === 'ArrowUp' && d[1] !== 0) setDir([-1, 0])
      else if (k === 'ArrowDown' && d[1] !== 0) setDir([1, 0])
      else if (k === 'ArrowLeft' && d[0] !== 0) setDir([0, -1])
      else if (k === 'ArrowRight' && d[0] !== 0) setDir([0, 1])
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [running])

  useEffect(() => {
    if (!running || over) return
    const id = window.setInterval(() => {
      const b = bodyRef.current; const d = dirRef.current; const f = foodRef.current
      const head = b[0]!
      const nh: [number, number] = [head[0] + d[0], head[1] + d[1]]
      if (nh[0] < 0 || nh[0] >= size || nh[1] < 0 || nh[1] >= size) { setOver(true); setRunning(false); return }
      if (b.some(p => p[0] === nh[0] && p[1] === nh[1])) { setOver(true); setRunning(false); return }
      const ate = nh[0] === f[0] && nh[1] === f[1]
      const nb = [nh, ...b]
      if (!ate) nb.pop()
      else {
        setScore(s => s + 1)
        let nf: [number, number]
        do { nf = [randInt(0, size - 1), randInt(0, size - 1)] } while (nb.some(p => p[0] === nf[0] && p[1] === nf[1]))
        setFood(nf)
      }
      setBody(nb)
    }, speedMs)
    return () => window.clearInterval(id)
  }, [running, over, size, speedMs])

  const turn = (nd: [number, number]): void => {
    const d = dirRef.current
    if (nd[0] === -d[0] && nd[1] === -d[1]) return
    setDir(nd)
  }
  const start = (): void => {
    if (over) {
      setBody([[Math.floor(size / 2), Math.floor(size / 2)]]); setFood([randInt(0, size - 1), randInt(0, size - 1)]); setDir([0, 1]); setScore(0); setOver(false)
    }
    setRunning(true)
  }
  const reset = (): void => {
    setBody([[Math.floor(size / 2), Math.floor(size / 2)]]); setFood([randInt(0, size - 1), randInt(0, size - 1)]); setDir([0, 1]); setScore(0); setOver(false); setRunning(false)
  }

  return (
    <div className={css.wrap}>
      <Header title={t('snake.title', { size })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.score')}: <b>{score}</b></span></div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: 'min(280px, 75vw)', aspectRatio: '1' }}>
        {range(size * size).map(i => {
          const r = Math.floor(i / size); const c = i % size
          const isHead = body[0]![0] === r && body[0]![1] === c
          const isBody = body.some(p => p[0] === r && p[1] === c)
          const isFood = food[0] === r && food[1] === c
          return (
            <div
              key={i}
              className={css.cell}
              style={{
                background: isHead ? '#4a9eff' : isBody ? '#3a8eef' : isFood ? '#e74c3c' : '#1a1d24',
                border: 'none', borderRadius: '2px', cursor: 'default',
              }}
            />
          )
        })}
      </div>
      {over && <Banner kind="lose" text={t('snake.over', { score })} />}
      <div className={css.row}>
        {!running && !over && <button type="button" className={css.btn} onClick={start}>{t('common.start')}</button>}
        {running && <button type="button" className={`${css.btn} ${css.secondary}`} onClick={() => setRunning(false)}>{t('common.pause')}</button>}
        {!running && over && <button type="button" className={css.btn} onClick={start}>{t('common.replay')}</button>}
        <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
      </div>
      {!over && (
        <div className={css.col}>
          <button type="button" className={css.btn} style={{ minWidth: '50px' }} onClick={() => turn([-1, 0])}>↑</button>
          <div className={css.row}>
            <button type="button" className={css.btn} style={{ minWidth: '50px' }} onClick={() => turn([0, -1])}>←</button>
            <button type="button" className={css.btn} style={{ minWidth: '50px' }} onClick={() => turn([1, 0])}>↓</button>
            <button type="button" className={css.btn} style={{ minWidth: '50px' }} onClick={() => turn([0, 1])}>→</button>
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Breakout ──────────────────────────────────────────────
export interface BreakoutProps { rows: number; cols: number; lives: number }
/** Breakout on canvas. */
export function Breakout({ rows, cols, lives, onClose, t }: GameProps & BreakoutProps) {
  const W = 320; const H = 360
  const brickW = (W - 20) / cols; const brickH = 14
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const [score, setScore] = useState(0)
  const [life, setLife] = useState(lives)
  const [state, setState] = useState<'idle' | 'playing' | 'over' | 'won'>('idle')
  const stateRef = useRef(state); stateRef.current = state
  const lifeRef = useRef(life); lifeRef.current = life

  useEffect(() => {
    const canvas = canvasRef.current
    if (canvas === null) return
    const ctx = canvas.getContext('2d')
    if (ctx === null) return

    let bricks: boolean[] = new Array(rows * cols).fill(true)
    let ball = { x: W / 2, y: H - 30, vx: 2, vy: -2 }
    let paddle = W / 2
    let raf = 0
    const keys = { left: false, right: false }

    const reset = (): void => {
      bricks = new Array(rows * cols).fill(true)
      ball = { x: W / 2, y: H - 30, vx: 2 * (Math.random() < 0.5 ? -1 : 1), vy: -2 }
      paddle = W / 2
    }
    reset()

    const onKeyDown = (e: KeyboardEvent): void => {
      if (e.key === 'ArrowLeft') keys.left = true
      if (e.key === 'ArrowRight') keys.right = true
    }
    const onKeyUp = (e: KeyboardEvent): void => {
      if (e.key === 'ArrowLeft') keys.left = false
      if (e.key === 'ArrowRight') keys.right = false
    }
    const onMove = (e: MouseEvent): void => {
      const rect = canvas.getBoundingClientRect()
      paddle = clamp((e.clientX - rect.left) * (W / rect.width), 30, W - 30)
    }
    canvas.addEventListener('mousemove', onMove)
    window.addEventListener('keydown', onKeyDown)
    window.addEventListener('keyup', onKeyUp)

    const loop = (): void => {
      if (stateRef.current !== 'playing') { raf = window.requestAnimationFrame(loop); return }
      if (keys.left) paddle = Math.max(30, paddle - 4)
      if (keys.right) paddle = Math.min(W - 30, paddle + 4)
      ball.x += ball.vx; ball.y += ball.vy
      if (ball.x < 6 || ball.x > W - 6) ball.vx = -ball.vx
      if (ball.y < 6) ball.vy = -ball.vy
      if (ball.y > H - 14 && Math.abs(ball.x - paddle) < 30) {
        ball.vy = -Math.abs(ball.vy)
        ball.vx = (ball.x - paddle) * 0.1
      }
      if (ball.y > H) {
        const nl = lifeRef.current - 1
        setLife(nl)
        if (nl <= 0) { setState('over'); reset() }
        else { ball = { x: W / 2, y: H - 30, vx: 2 * (Math.random() < 0.5 ? -1 : 1), vy: -2 } }
      }
      // Brick collision
      for (let i = 0; i < bricks.length; i++) {
        if (!bricks[i]) continue
        const r = Math.floor(i / cols); const c = i % cols
        const bx = 10 + c * brickW; const by = 30 + r * brickH
        if (ball.x > bx && ball.x < bx + brickW && ball.y > by && ball.y < by + brickH) {
          bricks[i] = false; ball.vy = -ball.vy; setScore(s => s + 1)
          if (bricks.every(b => !b)) { setState('won') }
        }
      }
      // Draw
      ctx.fillStyle = '#0f1117'; ctx.fillRect(0, 0, W, H)
      ctx.fillStyle = '#4a9eff'; ctx.fillRect(paddle - 30, H - 8, 60, 6)
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(ball.x, ball.y, 4, 0, Math.PI * 2); ctx.fill()
      for (let i = 0; i < bricks.length; i++) {
        if (!bricks[i]) continue
        const r = Math.floor(i / cols); const c = i % cols
        const bx = 10 + c * brickW; const by = 30 + r * brickH
        ctx.fillStyle = PALETTE[r % PALETTE.length]!
        ctx.fillRect(bx + 1, by + 1, brickW - 2, brickH - 2)
      }
      raf = window.requestAnimationFrame(loop)
    }
    raf = window.requestAnimationFrame(loop)

    return () => {
      window.cancelAnimationFrame(raf)
      canvas.removeEventListener('mousemove', onMove)
      window.removeEventListener('keydown', onKeyDown)
      window.removeEventListener('keyup', onKeyUp)
    }
  }, [rows, cols])

  const start = (): void => {
    if (state === 'over' || state === 'won') { setScore(0); setLife(lives) }
    setState('playing')
  }
  const reset = (): void => { setState('idle'); setScore(0); setLife(lives) }

  return (
    <div className={css.wrap}>
      <Header title={t('breakout.title')} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.score')}: <b>{score}</b></span><span>{t('breakout.livesLabel')}: <b>{life}</b></span></div>
      <div className={css.canvasWrap}>
        <canvas ref={canvasRef} className={css.canvas} width={W} height={H} style={{ width: 'min(320px, 80vw)', aspectRatio: `${W}/${H}` }} />
      </div>
      {state === 'over' && <Banner kind="lose" text={t('breakout.over', { score })} />}
      {state === 'won' && <Banner kind="win" text={t('breakout.won', { score })} />}
      <div className={css.row}>
        {state !== 'playing' && <button type="button" className={css.btn} onClick={start}>{state === 'idle' ? t('common.start') : t('common.replay')}</button>}
        {state === 'playing' && <button type="button" className={`${css.btn} ${css.secondary}`} onClick={() => setState('idle')}>{t('common.pause')}</button>}
        <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
      </div>
      <div className={css.hint}>{t('breakout.hint')}</div>
    </div>
  )
}

// ─── Pong (solo) ───────────────────────────────────────────
export interface PongProps { speedMs: number }
/** Solo Pong vs wall: keep ball alive. */
export function Pong({ speedMs, onClose, t }: GameProps & PongProps) {
  const W = 320; const H = 240
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const [score, setScore] = useState(0)
  const [best, setBest] = useState(0)
  const [state, setState] = useState<'idle' | 'playing' | 'over'>('idle')
  const stateRef = useRef(state); stateRef.current = state
  const scoreRef = useRef(score); scoreRef.current = score
  const bestRef = useRef(best); bestRef.current = best

  useEffect(() => {
    const canvas = canvasRef.current
    if (canvas === null) return
    const ctx = canvas.getContext('2d')
    if (ctx === null) return
    let ball = { x: W / 2, y: H / 2, vx: 3, vy: 2 }
    let paddle = W / 2
    let raf = 0
    let interval = 0
    const onMove = (e: MouseEvent): void => {
      const rect = canvas.getBoundingClientRect()
      paddle = clamp((e.clientX - rect.left) * (W / rect.width), 30, W - 30)
    }
    canvas.addEventListener('mousemove', onMove)
    const draw = (): void => {
      ctx.fillStyle = '#0f1117'; ctx.fillRect(0, 0, W, H)
      ctx.fillStyle = '#4a9eff'; ctx.fillRect(paddle - 30, H - 8, 60, 6)
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(ball.x, ball.y, 4, 0, Math.PI * 2); ctx.fill()
      raf = window.requestAnimationFrame(draw)
    }
    raf = window.requestAnimationFrame(draw)
    interval = window.setInterval(() => {
      if (stateRef.current !== 'playing') return
      ball.x += ball.vx; ball.y += ball.vy
      if (ball.x < 6 || ball.x > W - 6) ball.vx = -ball.vx
      if (ball.y < 6) ball.vy = -ball.vy
      if (ball.y > H - 14 && Math.abs(ball.x - paddle) < 30) {
        ball.vy = -Math.abs(ball.vy)
        ball.vx = (ball.x - paddle) * 0.1
        setScore(s => s + 1)
      }
      if (ball.y > H) {
        const sb = scoreRef.current
        if (sb > bestRef.current) setBest(sb)
        setState('over')
        ball = { x: W / 2, y: H / 2, vx: 3 * (Math.random() < 0.5 ? -1 : 1), vy: 2 }
      }
    }, speedMs)
    return () => {
      window.cancelAnimationFrame(raf)
      window.clearInterval(interval)
      canvas.removeEventListener('mousemove', onMove)
    }
  }, [speedMs])

  const start = (): void => { if (state === 'over') setScore(0); setState('playing') }
  const reset = (): void => { setState('idle'); setScore(0) }

  return (
    <div className={css.wrap}>
      <Header title={t('pong.title')} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.score')}: <b>{score}</b></span><span>{t('arcade.best')}: <b>{best}</b></span></div>
      <div className={css.canvasWrap}>
        <canvas ref={canvasRef} className={css.canvas} width={W} height={H} style={{ width: 'min(320px, 80vw)', aspectRatio: `${W}/${H}` }} />
      </div>
      {state === 'over' && <Banner kind="lose" text={t('pong.done', { score })} />}
      <div className={css.row}>
        {state !== 'playing' && <button type="button" className={css.btn} onClick={start}>{state === 'idle' ? t('common.start') : t('common.replay')}</button>}
        {state === 'playing' && <button type="button" className={`${css.btn} ${css.secondary}`} onClick={() => setState('idle')}>{t('common.pause')}</button>}
        <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
      </div>
    </div>
  )
}

// ─── Flappy ────────────────────────────────────────────────
export interface FlappyProps { gap: number; speed: number }
/** Flappy-style tap to fly. */
export function Flappy({ gap, speed, onClose, t }: GameProps & FlappyProps) {
  const W = 320; const H = 360
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const [score, setScore] = useState(0)
  const [best, setBest] = useState(0)
  const [state, setState] = useState<'idle' | 'playing' | 'over'>('idle')
  const stateRef = useRef(state); stateRef.current = state
  const scoreRef = useRef(score); scoreRef.current = score
  const bestRef = useRef(best); bestRef.current = best

  useEffect(() => {
    const canvas = canvasRef.current
    if (canvas === null) return
    const ctx = canvas.getContext('2d')
    if (ctx === null) return
    let y = H / 2; let vy = 0
    let pipes: { x: number; gapY: number; scored: boolean }[] = []
    let frame = 0
    let raf = 0
    const reset = (): void => { y = H / 2; vy = 0; pipes = []; frame = 0 }
    const tap = (): void => {
      if (stateRef.current === 'idle') { setState('playing'); reset() }
      if (stateRef.current === 'playing') vy = -5
      else if (stateRef.current === 'over') { setScore(0); setState('playing'); reset() }
    }
    const onClick = (): void => tap()
    const onKey = (e: KeyboardEvent): void => { if (e.key === ' ' || e.key === 'ArrowUp') { e.preventDefault(); tap() } }
    canvas.addEventListener('click', onClick)
    window.addEventListener('keydown', onKey)
    const draw = (): void => {
      frame++
      if (stateRef.current === 'playing') {
        vy += 0.25
        y += vy
        if (frame % 90 === 0) pipes.push({ x: W, gapY: randInt(60, H - 60 - gap), scored: false })
        pipes.forEach(p => { p.x -= speed })
        pipes = pipes.filter(p => p.x > -40)
        for (const p of pipes) {
          if (p.x < 30 && p.x > 10 && (y < p.gapY || y > p.gapY + gap)) {
            if (scoreRef.current > bestRef.current) setBest(scoreRef.current)
            setState('over')
          }
          if (!p.scored && p.x < 20) { p.scored = true; setScore(s => s + 1) }
        }
        if (y < 0 || y > H) {
          if (scoreRef.current > bestRef.current) setBest(scoreRef.current)
          setState('over')
        }
      }
      ctx.fillStyle = '#0f1117'; ctx.fillRect(0, 0, W, H)
      ctx.fillStyle = '#2ecc71'
      pipes.forEach(p => {
        ctx.fillRect(p.x, 0, 30, p.gapY)
        ctx.fillRect(p.x, p.gapY + gap, 30, H - p.gapY - gap)
      })
      ctx.fillStyle = '#f1c40f'; ctx.beginPath(); ctx.arc(20, y, 8, 0, Math.PI * 2); ctx.fill()
      raf = window.requestAnimationFrame(draw)
    }
    raf = window.requestAnimationFrame(draw)
    return () => {
      window.cancelAnimationFrame(raf)
      canvas.removeEventListener('click', onClick)
      window.removeEventListener('keydown', onKey)
    }
  }, [gap, speed])

  return (
    <div className={css.wrap}>
      <Header title={t('flappy.title')} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.score')}: <b>{score}</b></span><span>{t('arcade.best')}: <b>{best}</b></span></div>
      <div className={css.canvasWrap}>
        <canvas ref={canvasRef} className={css.canvas} width={W} height={H} style={{ width: 'min(320px, 80vw)', aspectRatio: `${W}/${H}` }} />
      </div>
      {state === 'over' && <Banner kind="lose" text={t('arcade.crashed', { score })} />}
      <div className={css.hint}>{t('flappy.hint')}</div>
    </div>
  )
}

// ─── Dodge ─────────────────────────────────────────────────
export interface DodgeProps { size: number; obstacles: number; speedMs: number }
/** Dodge falling obstacles on a grid. */
export function Dodge({ size, obstacles, speedMs, onClose, t }: GameProps & DodgeProps) {
  const [player, setPlayer] = useState<number>(Math.floor(size / 2))
  const [obstacleRows, setObstacleRows] = useState<number[][]>([])
  const [score, setScore] = useState(0)
  const [over, setOver] = useState(false)
  const [running, setRunning] = useState(false)
  const playerRef = useRef(player); playerRef.current = player
  const obsRef = useRef(obstacleRows); obsRef.current = obstacleRows

  useEffect(() => {
    if (!running || over) return
    const id = window.setInterval(() => {
      const cols = new Set<number>()
      while (cols.size < obstacles) cols.add(randInt(0, size - 1))
      const newRow = [...cols]
      const newRows = [newRow, ...obsRef.current]
      if (newRows.length > size + 1) newRows.pop()
      // After shift, is the player's cell on the bottom row blocked?
      // We model: rows index 0 = top, last index = bottom.
      // After unshift, row at index = size-1 (= player row) might contain player's column.
      const playerRowObs = newRows[size - 1] ?? []
      if (playerRowObs.includes(playerRef.current)) { setOver(true); setRunning(false); return }
      // If we just popped a row off the bottom (i.e. a row "passed" the player), increment score.
      if (obsRef.current.length >= size) setScore(s => s + 1)
      setObstacleRows(newRows)
    }, speedMs)
    return () => window.clearInterval(id)
  }, [running, over, size, obstacles, speedMs])

  const move = (d: number): void => { setPlayer(p => clamp(p + d, 0, size - 1)) }
  const start = (): void => {
    if (over) { setPlayer(Math.floor(size / 2)); setObstacleRows([]); setScore(0); setOver(false) }
    setRunning(true)
  }
  const reset = (): void => {
    setPlayer(Math.floor(size / 2)); setObstacleRows([]); setScore(0); setOver(false); setRunning(false)
  }

  useEffect(() => {
    const h = (e: KeyboardEvent): void => {
      if (e.key === 'ArrowLeft') move(-1)
      else if (e.key === 'ArrowRight') move(1)
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  })

  return (
    <div className={css.wrap}>
      <Header title={t('dodge.title', { size })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.score')}: <b>{score}</b></span></div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: 'min(280px, 75vw)' }}>
        {range(size * size).map(i => {
          const r = Math.floor(i / size); const c = i % size
          const isPlayer = r === size - 1 && c === player
          const isObstacle = obstacleRows[r]?.includes(c) ?? false
          return (
            <div
              key={i}
              className={css.cell}
              style={{ background: isPlayer ? '#4a9eff' : isObstacle ? '#e74c3c' : '#1a1d24', border: 'none', borderRadius: '2px' }}
            />
          )
        })}
      </div>
      {over && <Banner kind="lose" text={t('dodge.over', { score })} />}
      <div className={css.row}>
        {!running && <button type="button" className={css.btn} onClick={start}>{over ? t('common.replay') : t('common.start')}</button>}
        {running && <button type="button" className={`${css.btn} ${css.secondary}`} onClick={() => setRunning(false)}>{t('common.pause')}</button>}
        <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
      </div>
      <div className={css.row}>
        <button type="button" className={css.btn} onClick={() => move(-1)}>←</button>
        <button type="button" className={css.btn} onClick={() => move(1)}>→</button>
      </div>
    </div>
  )
}

// ─── Dino Run ──────────────────────────────────────────────
export interface DinoProps { speed: number }
/** Side-scrolling dino-style jump. */
export function Dino({ speed, onClose, t }: GameProps & DinoProps) {
  const W = 320; const H = 180
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const [score, setScore] = useState(0)
  const [best, setBest] = useState(0)
  const [state, setState] = useState<'idle' | 'playing' | 'over'>('idle')
  const stateRef = useRef(state); stateRef.current = state
  const scoreRef = useRef(score); scoreRef.current = score
  const bestRef = useRef(best); bestRef.current = best

  useEffect(() => {
    const canvas = canvasRef.current
    if (canvas === null) return
    const ctx = canvas.getContext('2d')
    if (ctx === null) return
    let y = H - 30; let vy = 0
    let obs: { x: number; w: number; h: number }[] = []
    let frame = 0
    let raf = 0
    const ground = H - 20
    const jump = (): void => {
      if (stateRef.current === 'idle') { setState('playing'); y = ground; vy = 0; obs = []; frame = 0 }
      if (stateRef.current === 'playing' && y >= ground) vy = -8
      if (stateRef.current === 'over') { setScore(0); setState('playing'); y = ground; vy = 0; obs = []; frame = 0 }
    }
    const onKey = (e: KeyboardEvent): void => { if (e.key === ' ' || e.key === 'ArrowUp') { e.preventDefault(); jump() } }
    const onClick = (): void => jump()
    canvas.addEventListener('click', onClick)
    window.addEventListener('keydown', onKey)
    const draw = (): void => {
      frame++
      if (stateRef.current === 'playing') {
        vy += 0.4
        y += vy
        if (y > ground) y = ground
        if (frame % 70 === 0) obs.push({ x: W, w: randInt(10, 20), h: randInt(15, 30) })
        obs.forEach(o => { o.x -= speed })
        obs = obs.filter(o => o.x > -30)
        for (const o of obs) {
          if (o.x < 30 && o.x + o.w > 15 && y + 15 > ground - o.h) {
            if (scoreRef.current > bestRef.current) setBest(scoreRef.current)
            setState('over')
          }
        }
        if (frame % 6 === 0) setScore(s => s + 1)
      }
      ctx.fillStyle = '#0f1117'; ctx.fillRect(0, 0, W, H)
      ctx.fillStyle = '#2a2d36'; ctx.fillRect(0, ground + 5, W, 2)
      ctx.fillStyle = '#2ecc71'; ctx.fillRect(15, y - 15, 18, 15)
      ctx.fillStyle = '#e74c3c'
      obs.forEach(o => ctx.fillRect(o.x, ground - o.h, o.w, o.h))
      raf = window.requestAnimationFrame(draw)
    }
    raf = window.requestAnimationFrame(draw)
    return () => {
      window.cancelAnimationFrame(raf)
      canvas.removeEventListener('click', onClick)
      window.removeEventListener('keydown', onKey)
    }
  }, [speed])

  return (
    <div className={css.wrap}>
      <Header title={t('dino.title')} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.score')}: <b>{score}</b></span><span>{t('arcade.best')}: <b>{best}</b></span></div>
      <div className={css.canvasWrap}>
        <canvas ref={canvasRef} className={css.canvas} width={W} height={H} style={{ width: 'min(320px, 80vw)', aspectRatio: `${W}/${H}` }} />
      </div>
      {state === 'over' && <Banner kind="lose" text={t('arcade.crashed', { score })} />}
      <div className={css.hint}>{t('dino.hint')}</div>
    </div>
  )
}

// ─── Asteroids (simplified) ────────────────────────────────
export interface AsteroidsProps { count: number }
/** Survival: avoid N asteroids for as long as possible. */
export function Asteroids({ count, onClose, t }: GameProps & AsteroidsProps) {
  const W = 320; const H = 320
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const [time, setTime] = useState(0)
  const [best, setBest] = useState(0)
  const [state, setState] = useState<'idle' | 'playing' | 'over'>('idle')
  const stateRef = useRef(state); stateRef.current = state
  const bestRef = useRef(best); bestRef.current = best

  useEffect(() => {
    const canvas = canvasRef.current
    if (canvas === null) return
    const ctx = canvas.getContext('2d')
    if (ctx === null) return
    let ship = { x: W / 2, y: H / 2 }
    let rocks = Array.from({ length: count }, () => ({
      x: Math.random() * W, y: Math.random() * H,
      vx: (Math.random() - 0.5) * 2, vy: (Math.random() - 0.5) * 2,
      r: randInt(8, 16),
    }))
    let keys = { up: false, left: false, right: false }
    let angle = 0
    let vx = 0; let vy = 0
    let frame = 0
    let raf = 0
    const start = (): void => {
      ship = { x: W / 2, y: H / 2 }; rocks = Array.from({ length: count }, () => ({
        x: Math.random() * W, y: Math.random() * H,
        vx: (Math.random() - 0.5) * 3, vy: (Math.random() - 0.5) * 3,
        r: randInt(8, 16),
      }))
      angle = 0; vx = 0; vy = 0; setState('playing'); frame = 0
    }
    const onKey = (e: KeyboardEvent, down: boolean): void => {
      if (e.key === 'ArrowUp') keys.up = down
      if (e.key === 'ArrowLeft') keys.left = down
      if (e.key === 'ArrowRight') keys.right = down
      if (down && (e.key === ' ' || e.key === 'Enter')) { if (stateRef.current !== 'playing') start() }
    }
    const kd = (e: KeyboardEvent): void => onKey(e, true)
    const ku = (e: KeyboardEvent): void => onKey(e, false)
    window.addEventListener('keydown', kd)
    window.addEventListener('keyup', ku)
    const draw = (): void => {
      frame++
      if (stateRef.current === 'playing') {
        if (keys.left) angle -= 0.07
        if (keys.right) angle += 0.07
        if (keys.up) { vx += Math.cos(angle - Math.PI / 2) * 0.1; vy += Math.sin(angle - Math.PI / 2) * 0.1 }
        vx *= 0.99; vy *= 0.99
        ship.x = (ship.x + vx + W) % W; ship.y = (ship.y + vy + H) % H
        rocks.forEach(r => { r.x = (r.x + r.vx + W) % W; r.y = (r.y + r.vy + H) % H })
        for (const r of rocks) {
          const dx = r.x - ship.x; const dy = r.y - ship.y
          if (Math.sqrt(dx * dx + dy * dy) < r.r + 6) {
            if (frame > bestRef.current) setBest(frame)
            setState('over')
          }
        }
        if (frame % 6 === 0) setTime(Math.floor(frame / 6))
      }
      ctx.fillStyle = '#0f1117'; ctx.fillRect(0, 0, W, H)
      ctx.save()
      ctx.translate(ship.x, ship.y); ctx.rotate(angle)
      ctx.fillStyle = '#4a9eff'; ctx.beginPath(); ctx.moveTo(0, -8); ctx.lineTo(-5, 5); ctx.lineTo(5, 5); ctx.closePath(); ctx.fill()
      ctx.restore()
      ctx.fillStyle = '#888'
      rocks.forEach(r => { ctx.beginPath(); ctx.arc(r.x, r.y, r.r, 0, Math.PI * 2); ctx.fill() })
      raf = window.requestAnimationFrame(draw)
    }
    raf = window.requestAnimationFrame(draw)
    return () => {
      window.cancelAnimationFrame(raf)
      window.removeEventListener('keydown', kd)
      window.removeEventListener('keyup', ku)
    }
  }, [count])

  return (
    <div className={css.wrap}>
      <Header title={t('asteroids.title')} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('asteroids.timeLabel')}: <b>{time}</b>s</span><span>{t('common.best')}: <b>{best}</b>s</span></div>
      <div className={css.canvasWrap}>
        <canvas ref={canvasRef} className={css.canvas} width={W} height={H} style={{ width: 'min(280px, 75vw)', aspectRatio: '1' }} />
      </div>
      {state === 'over' && <Banner kind="lose" text={t('asteroids.survived', { time })} />}
      <div className={css.hint}>{t('asteroids.hint')}</div>
    </div>
  )
}

// ─── Maze Runner ───────────────────────────────────────────
export interface MazeProps { size: number }
/** Randomly generated maze; reach the exit. */
export function Maze({ size, onClose, t }: GameProps & MazeProps) {
  type Cell = { walls: { n: boolean; s: boolean; e: boolean; w: boolean }; visited: boolean }
  const make = (): Cell[] => {
    const grid: Cell[] = range(size * size).map(() => ({ walls: { n: true, s: true, e: true, w: true }, visited: false }))
    const stack: number[] = [0]
    grid[0]!.visited = true
    while (stack.length > 0) {
      const cur = stack[stack.length - 1]!
      const r = Math.floor(cur / size); const c = cur % size
      const neighbors: number[] = []
      if (r > 0 && !grid[(r - 1) * size + c]!.visited) neighbors.push((r - 1) * size + c)
      if (r < size - 1 && !grid[(r + 1) * size + c]!.visited) neighbors.push((r + 1) * size + c)
      if (c > 0 && !grid[r * size + c - 1]!.visited) neighbors.push(r * size + c - 1)
      if (c < size - 1 && !grid[r * size + c + 1]!.visited) neighbors.push(r * size + c + 1)
      if (neighbors.length === 0) { stack.pop(); continue }
      const next = pick(neighbors)
      const nr = Math.floor(next / size); const nc = next % size
      if (nr < r) { grid[cur]!.walls.n = false; grid[next]!.walls.s = false }
      if (nr > r) { grid[cur]!.walls.s = false; grid[next]!.walls.n = false }
      if (nc < c) { grid[cur]!.walls.w = false; grid[next]!.walls.e = false }
      if (nc > c) { grid[cur]!.walls.e = false; grid[next]!.walls.w = false }
      grid[next]!.visited = true
      stack.push(next)
    }
    return grid
  }
  const [grid, setGrid] = useState<Cell[]>(make)
  const [pos, setPos] = useState(0)
  const [moves, setMoves] = useState(0)
  const won = pos === size * size - 1
  const cellSize = Math.max(8, Math.min(20, 200 / size))

  const move = (dir: 'n' | 's' | 'e' | 'w'): void => {
    if (won) return
    const cell = grid[pos]!
    if (cell.walls[dir]) return
    const r = Math.floor(pos / size); const c = pos % size
    let np = pos
    if (dir === 'n') np = (r - 1) * size + c
    if (dir === 's') np = (r + 1) * size + c
    if (dir === 'e') np = r * size + c + 1
    if (dir === 'w') np = r * size + c - 1
    setPos(np); setMoves(m => m + 1)
  }
  const reset = (): void => { setGrid(make()); setPos(0); setMoves(0) }

  useEffect(() => {
    const h = (e: KeyboardEvent): void => {
      if (e.key === 'ArrowUp') move('n')
      else if (e.key === 'ArrowDown') move('s')
      else if (e.key === 'ArrowLeft') move('w')
      else if (e.key === 'ArrowRight') move('e')
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  })

  return (
    <div className={css.wrap}>
      <Header title={t('maze.title', { size })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.moves')}: <b>{moves}</b></span></div>
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <div style={{ position: 'relative', width: size * cellSize, height: size * cellSize, background: '#1a1d24' }}>
          {grid.map((cell, i) => {
            const r = Math.floor(i / size); const c = i % size
            return (
              <div
                key={i}
                style={{
                  position: 'absolute',
                  left: c * cellSize, top: r * cellSize,
                  width: cellSize, height: cellSize,
                  boxSizing: 'border-box',
                  borderTop: cell.walls.n ? '1px solid #4a9eff' : 'none',
                  borderBottom: cell.walls.s ? '1px solid #4a9eff' : 'none',
                  borderLeft: cell.walls.w ? '1px solid #4a9eff' : 'none',
                  borderRight: cell.walls.e ? '1px solid #4a9eff' : 'none',
                  background: i === pos ? '#4a9eff' : i === size * size - 1 ? '#2ecc71' : 'transparent',
                }}
              />
            )
          })}
        </div>
      </div>
      {won ? (
        <>
          <Banner kind="win" text={t('maze.done', { n: moves })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <>
          <div className={css.col}>
            <button type="button" className={css.btn} style={{ minWidth: '50px' }} onClick={() => move('n')}>↑</button>
            <div className={css.row}>
              <button type="button" className={css.btn} style={{ minWidth: '50px' }} onClick={() => move('w')}>←</button>
              <button type="button" className={css.btn} style={{ minWidth: '50px' }} onClick={() => move('s')}>↓</button>
              <button type="button" className={css.btn} style={{ minWidth: '50px' }} onClick={() => move('e')}>→</button>
            </div>
          </div>
          <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
        </>
      )}
    </div>
  )
}

// ─── Tap Color Sequence (Light Memory) ─────────────────────
export interface ColorSeqProps { length: number }
/** Memorize a sequence of colors then tap them back. */
export function ColorSeq({ length, onClose, t }: GameProps & ColorSeqProps) {
  const [seq] = useState<number[]>(() => Array.from({ length }, () => randInt(0, 3)))
  const [idx, setIdx] = useState(0)
  const [phase, setPhase] = useState<'show' | 'input' | 'done'>('show')
  const [active, setActive] = useState<number | null>(null)
  const [showIdx, setShowIdx] = useState(0)
  const COLORS = ['#e74c3c', '#2ecc71', '#3498db', '#f1c40f']

  useEffect(() => {
    if (phase !== 'show') return
    if (showIdx >= seq.length) { setPhase('input'); return }
    const t1 = window.setTimeout(() => {
      setActive(seq[showIdx]!)
      window.setTimeout(() => {
        setActive(null)
        setShowIdx(s => s + 1)
      }, 500)
    }, 300)
    return () => window.clearTimeout(t1)
  }, [phase, showIdx, seq])

  const tap = (c: number): void => {
    if (phase !== 'input') return
    if (seq[idx] !== c) { setPhase('done'); return }
    if (idx + 1 >= seq.length) { setPhase('done'); return }
    setIdx(idx + 1)
  }
  const reset = (): void => { setIdx(0); setShowIdx(0); setPhase('show'); setActive(null) }
  const failed = idx + 1 > seq.length

  return (
    <div className={css.wrap}>
      <Header title={t('colorseq.title', { length })} onClose={onClose} t={t} />
      <div className={css.stats}>{phase === 'show' ? t('colorseq.memorize') : phase === 'input' ? t('colorseq.input', { n: idx + 1, total: seq.length }) : failed ? t('colorseq.failed') : t('common.done')}</div>
      <div className={css.row}>
        {COLORS.map((c, i) => (
          <button
            key={i}
            type="button"
            onClick={() => tap(i)}
            disabled={phase !== 'input'}
            style={{
              width: '60px', height: '60px', borderRadius: '8px', background: c,
              opacity: active === i ? 1 : 0.4, border: 'none', cursor: 'pointer', transition: 'opacity 0.1s',
            }}
          />
        ))}
      </div>
      {phase === 'done' && (
        <>
          <Banner kind={failed ? 'lose' : 'win'} text={failed ? t('colorseq.wrong') : t('colorseq.passed')} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      )}
    </div>
  )
}

// ─── Catch Falling ─────────────────────────────────────────
export interface CatchProps { size: number; good: string; bad: string; durationSec: number }
/** Catch falling good items, avoid bad ones. */
export function Catch({ size, good, bad, durationSec, onClose, t }: GameProps & CatchProps) {
  const [basket, setBasket] = useState<number>(Math.floor(size / 2))
  const [items, setItems] = useState<Array<{ r: number; c: number; good: boolean }>>([])
  const [score, setScore] = useState(0)
  const [time, setTime] = useState(durationSec)
  const [running, setRunning] = useState(false)
  const [over, setOver] = useState(false)
  const basketRef = useRef(basket); basketRef.current = basket
  const itemsRef = useRef(items); itemsRef.current = items
  const scoreRef = useRef(score); scoreRef.current = score

  useEffect(() => {
    if (!running || over) return
    const tick = window.setInterval(() => {
      const next = itemsRef.current.map(it => ({ ...it, r: it.r + 1 }))
      // Catch detection
      for (const it of next) {
        if (it.r === size - 1 && it.c === basketRef.current) {
          if (it.good) setScore(s => s + 1)
          else setScore(s => s - 2)
        }
      }
      // Random spawn at top
      if (Math.random() < 0.5) {
        next.push({ r: 0, c: randInt(0, size - 1), good: Math.random() > 0.25 })
      }
      // Filter caught + landed items
      setItems(next.filter(it => it.r < size - 1 || !(it.c === basketRef.current)))
    }, 500)
    const timer = window.setInterval(() => {
      setTime(t => {
        if (t <= 1) { setOver(true); setRunning(false); return 0 }
        return t - 1
      })
    }, 1000)
    return () => { window.clearInterval(tick); window.clearInterval(timer) }
  }, [running, over, size, durationSec])

  useEffect(() => {
    const h = (e: KeyboardEvent): void => {
      if (e.key === 'ArrowLeft') setBasket(b => Math.max(0, b - 1))
      else if (e.key === 'ArrowRight') setBasket(b => Math.min(size - 1, b + 1))
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  })

  const start = (): void => { setBasket(Math.floor(size / 2)); setItems([]); setScore(0); setTime(durationSec); setOver(false); setRunning(true) }

  return (
    <div className={css.wrap}>
      <Header title={t('catch.title')} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.score')}: <b>{score}</b></span><span>{t('asteroids.timeLabel')}: <b>{time}</b></span></div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: 'min(280px, 75vw)' }}>
        {range(size * size).map(i => {
          const r = Math.floor(i / size); const c = i % size
          const isBasket = r === size - 1 && c === basket
          const item = items.find(it => it.r === r && it.c === c)
          return (
            <div
              key={i}
              className={css.cell}
              style={{ background: isBasket ? '#4a9eff' : '#1a1d24', border: 'none', borderRadius: '2px', fontSize: '16px' }}
            >
              {item ? (item.good ? good : bad) : ''}
            </div>
          )
        })}
      </div>
      {over && <Banner kind="info" text={t('catch.timeUp', { score })} />}
      <div className={css.row}>
        {!running && !over && <button type="button" className={css.btn} onClick={start}>{t('common.start')}</button>}
        {over && <button type="button" className={css.btn} onClick={start}>{t('common.replay')}</button>}
        <button type="button" className={css.btn} onClick={() => setBasket(b => Math.max(0, b - 1))}>←</button>
        <button type="button" className={css.btn} onClick={() => setBasket(b => Math.min(size - 1, b + 1))}>→</button>
      </div>
    </div>
  )
}