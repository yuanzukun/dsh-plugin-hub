/**
 * Simple mini-game engines — click/reflex/quiz/chance. Each component is
 * parameterized via extra props; `bind(Engine, props)` produces a
 * `ComponentType<GameProps>` the registry accepts.
 *
 * All user-visible copy runs through the `t` prop (`ctx.locale.bind(NS)`);
 * per-engine content data (trivia banks, riddle/typing datasets, stroop
 * color names) lives in `shared.ts` and stays untouched.
 *
 * @module @huanlin/dsh-plugin-d399/client/games/mini/engines-simple
 */
import {
  type ComponentType,
  type ReactNode,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react'
import type { GameProps } from '../types.ts'
import type { Translate } from '../../locales.ts'
import css from './mini.module.css'
import {
  PALETTE,
  QUIZ_CODEBASE,
  RIDDLES_CLASSIC,
  TYPING_PANGRAMS,
  TYPING_PHRASES_LONG,
  TYPING_PHRASES_SHORT,
  TRIVIA_CODEBASE,
  TRIVIA_GEOGRAPHY,
  TRIVIA_HISTORY,
  TRIVIA_LITERATURE,
  TRIVIA_MOVIES,
  TRIVIA_SCIENCE,
  TRIVIA_SPORTS,
  WORDS_ANIMALS,
  WORDS_COUNTRIES,
  WORDS_FOOD,
  WORDS_MOVIES,
  WORDS_TECH,
  pick,
  randInt,
  range,
  shuffle,
} from './shared.ts'

/** Wrap an engine with bound props, producing a GameProps-only component. */
export function bind<P extends object>(
  Engine: ComponentType<GameProps & P>,
  props: P,
): ComponentType<GameProps> {
  function Bound(gameProps: GameProps) {
    return <Engine {...gameProps} {...props} />
  }
  Bound.displayName = `Bound(${Engine.displayName ?? Engine.name})`
  return Bound
}

/** Standard game header with title and close button. */
function Header({ title, onClose, t, children }: { title: string; onClose: () => void; t: Translate; children?: ReactNode }) {
  return (
    <div className={css.header}>
      <h2 className={css.title}>{title}</h2>
      {children}
      <button type="button" className={css.closeBtn} onClick={onClose} aria-label={t('common.close')}>✕</button>
    </div>
  )
}

/** Banner shown when game ends. */
function Banner({ kind, text }: { kind: 'win' | 'lose' | 'info'; text: string }) {
  return <div className={`${css.banner} ${css[kind]}`}>{text}</div>
}

// ─── Clicker ───────────────────────────────────────────────
export interface ClickerProps { target: number; label: string }
/** Click N times as fast as possible; measures elapsed time. */
export function Clicker({ target, onClose, t }: GameProps & ClickerProps) {
  const [count, setCount] = useState(0)
  const [elapsed, setElapsed] = useState<number | null>(null)
  const startRef = useRef<number | null>(null)
  const click = useCallback(() => {
    if (elapsed !== null) return
    if (startRef.current === null) startRef.current = Date.now()
    const next = count + 1
    if (next >= target) {
      setElapsed((Date.now() - (startRef.current ?? Date.now())) / 1000)
      setCount(target)
    } else {
      setCount(next)
    }
  }, [count, elapsed, target])
  const reset = useCallback(() => {
    setCount(0); setElapsed(null); startRef.current = null
  }, [])
  return (
    <div className={css.wrap}>
      <Header title={t('clicker.title', { target })} onClose={onClose} t={t} />
      {elapsed === null ? (
        <>
          <div className={css.huge}>{count} / {target}</div>
          <button type="button" className={css.btn} onClick={click}>{t('clicker.click')}</button>
        </>
      ) : (
        <>
          <Banner kind="win" text={t('common.doneElapsed', { s: elapsed.toFixed(2) })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      )}
    </div>
  )
}

// ─── Reaction ──────────────────────────────────────────────
export interface ReactionProps { rounds: number }
/** Wait for green, then click; measures reaction time over N rounds. */
export function Reaction({ rounds, onClose, t }: GameProps & ReactionProps) {
  const [state, setState] = useState<'idle' | 'waiting' | 'go' | 'tooEarly' | 'done'>('idle')
  const [times, setTimes] = useState<number[]>([])
  const goAtRef = useRef<number>(0)
  const timerRef = useRef<number | null>(null)

  const arm = useCallback(() => {
    setState('waiting')
    const delay = 1000 + Math.random() * 3000
    timerRef.current = window.setTimeout(() => {
      goAtRef.current = Date.now()
      setState('go')
    }, delay)
  }, [])

  useEffect(() => () => { if (timerRef.current !== null) window.clearTimeout(timerRef.current) }, [])

  const handleClick = useCallback(() => {
    if (state === 'idle' || state === 'tooEarly') {
      arm()
    } else if (state === 'waiting') {
      if (timerRef.current !== null) window.clearTimeout(timerRef.current)
      setState('tooEarly')
    } else if (state === 'go') {
      const rt = Date.now() - goAtRef.current
      const next = [...times, rt]
      setTimes(next)
      if (next.length >= rounds) {
        setState('done')
      } else {
        setState('idle')
      }
    }
  }, [state, times, rounds, arm])

  const reset = useCallback(() => {
    setTimes([]); setState('idle')
  }, [])

  const bg = state === 'go' ? '#2ecc71' : state === 'waiting' ? '#e74c3c' : '#2a2d36'
  const label = state === 'idle' ? t('reaction.round', { round: times.length + 1, total: rounds })
    : state === 'waiting' ? t('reaction.waiting')
    : state === 'go' ? t('reaction.go')
    : state === 'tooEarly' ? t('reaction.tooEarly')
    : t('common.done')
  const avg = times.length > 0 ? Math.round(times.reduce((a, b) => a + b, 0) / times.length) : 0

  return (
    <div className={css.wrap}>
      <Header title={t('reaction.title')} onClose={onClose} t={t} />
      {state === 'done' ? (
        <>
          <Banner kind="win" text={t('reaction.avg', { avg })} />
          <div className={css.hint}>{t('reaction.roundsList')}{times.map(x => `${x}ms`).join(' · ')}</div>
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <>
          <button
            type="button"
            className={css.btn}
            style={{ background: bg, padding: '40px 20px', fontSize: '16px', width: '100%' }}
            onClick={handleClick}
          >
            {label}
          </button>
          <div className={css.hint}>{t('reaction.hint')}</div>
        </>
      )}
    </div>
  )
}

// ─── Aim Trainer ───────────────────────────────────────────
export interface AimProps { targets: number }
/** Click N moving targets; measures total time. */
export function Aim({ targets, onClose, t }: GameProps & AimProps) {
  const [hit, setHit] = useState(0)
  const [pos, setPos] = useState({ x: 50, y: 50 })
  const [elapsed, setElapsed] = useState<number | null>(null)
  const startRef = useRef<number | null>(null)
  const move = useCallback(() => {
    setPos({ x: 5 + Math.random() * 90, y: 5 + Math.random() * 90 })
  }, [])
  const click = useCallback(() => {
    if (elapsed !== null) return
    if (startRef.current === null) startRef.current = Date.now()
    const next = hit + 1
    if (next >= targets) {
      setElapsed((Date.now() - (startRef.current ?? Date.now())) / 1000)
      setHit(targets)
    } else {
      setHit(next)
      move()
    }
  }, [hit, targets, elapsed, move])
  const reset = useCallback(() => {
    setHit(0); setElapsed(null); startRef.current = null; move()
  }, [move])
  useEffect(() => { move() }, [move])
  return (
    <div className={css.wrap}>
      <Header title={t('aim.title', { target: targets })} onClose={onClose} t={t} />
      {elapsed === null ? (
        <>
          <div className={css.stats}><span>{t('common.hits')}: <b>{hit}</b> / {targets}</span></div>
          <div className={css.canvasWrap}>
            <div className={css.canvas} style={{ position: 'relative' }}>
              <button
                type="button"
                onClick={click}
                aria-label="target"
                style={{
                  position: 'absolute',
                  left: `${pos.x}%`,
                  top: `${pos.y}%`,
                  transform: 'translate(-50%, -50%)',
                  width: '36px',
                  height: '36px',
                  borderRadius: '50%',
                  background: '#e74c3c',
                  border: '3px solid #fff',
                  cursor: 'crosshair',
                  padding: 0,
                }}
              />
            </div>
          </div>
        </>
      ) : (
        <>
          <Banner kind="win" text={t('common.doneElapsed', { s: elapsed.toFixed(2) })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      )}
    </div>
  )
}

// ─── Whack-a-Mole ──────────────────────────────────────────
export interface WhackProps { durationSec: number }
/** Whack moles for N seconds; counts hits. */
export function WhackAMole({ durationSec, onClose, t }: GameProps & WhackProps) {
  const [score, setScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(durationSec)
  const [moleAt, setMoleAt] = useState<number | null>(null)
  const [running, setRunning] = useState(false)
  const [done, setDone] = useState(false)
  const moleTimerRef = useRef<number | null>(null)
  const tickTimerRef = useRef<number | null>(null)

  const stop = useCallback(() => {
    if (moleTimerRef.current !== null) { window.clearTimeout(moleTimerRef.current); moleTimerRef.current = null }
    if (tickTimerRef.current !== null) { window.clearInterval(tickTimerRef.current); tickTimerRef.current = null }
  }, [])

  const startGame = useCallback(() => {
    setScore(0); setTimeLeft(durationSec); setRunning(true); setDone(false)
    const pop = (): void => {
      setMoleAt(Math.floor(Math.random() * 9))
      moleTimerRef.current = window.setTimeout(() => {
        setMoleAt(null)
        moleTimerRef.current = window.setTimeout(pop, 400 + Math.random() * 600)
      }, 600 + Math.random() * 500)
    }
    pop()
    tickTimerRef.current = window.setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) {
          stop(); setRunning(false); setDone(true); setMoleAt(null)
          return 0
        }
        return t - 1
      })
    }, 1000)
  }, [durationSec, stop])

  useEffect(() => () => stop(), [stop])

  const whack = (i: number): void => {
    if (!running || moleAt !== i) return
    setScore(s => s + 1)
    setMoleAt(null)
  }

  return (
    <div className={css.wrap}>
      <Header title={t('whack.title')} onClose={onClose} t={t} />
      <div className={css.stats}>
        <span>{t('common.score')}: <b>{score}</b></span>
        <span>{t('common.remaining')}: <b>{timeLeft}s</b></span>
      </div>
      <div className={css.grid} style={{ gridTemplateColumns: 'repeat(3, 1fr)', width: 'min(240px, 70vw)' }}>
        {range(9).map(i => (
          <button
            key={i}
            type="button"
            className={css.cell}
            onClick={() => whack(i)}
            disabled={!running}
          >
            {moleAt === i ? '🐹' : ''}
          </button>
        ))}
      </div>
      {done ? (
        <Banner kind="info" text={t('whack.timeUp', { score })} />
      ) : null}
      <button type="button" className={css.btn} onClick={startGame} disabled={running}>
        {done ? t('common.replay') : t('common.start')}
      </button>
    </div>
  )
}

// ─── Bubble Wrap ───────────────────────────────────────────
export interface BubbleWrapProps { size: number }
/** Pop all bubbles; measures satisfaction (no time pressure). */
export function BubbleWrap({ size, onClose, t }: GameProps & BubbleWrapProps) {
  const total = size * size
  const [popped, setPopped] = useState<Set<number>>(() => new Set())
  const toggle = (i: number): void => {
    setPopped(prev => {
      const next = new Set(prev)
      if (next.has(i)) next.delete(i)
      else next.add(i)
      return next
    })
  }
  const reset = (): void => setPopped(new Set())
  const allPopped = popped.size === total
  return (
    <div className={css.wrap}>
      <Header title={t('bubble.title', { size })} onClose={onClose} t={t} />
      <div className={css.stats}>
        <span>{t('bubble.popped')}: <b>{popped.size}</b> / {total}</span>
      </div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)` }}>
        {range(total).map(i => (
          <button
            key={i}
            type="button"
            className={css.cell}
            style={popped.has(i) ? { background: '#1a1d24', color: '#444' } : undefined}
            onClick={() => toggle(i)}
          >
            {popped.has(i) ? '·' : '○'}
          </button>
        ))}
      </div>
      {allPopped && <Banner kind="win" text={t('bubble.allDone')} />}
      <button type="button" className={css.btn} onClick={reset}>{t('common.reset')}</button>
    </div>
  )
}

// ─── Etch-a-Sketch ─────────────────────────────────────────
export interface EtchProps { size: number }
/** Drawing canvas with clear button. */
export function Etch({ size, onClose, t }: GameProps & EtchProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const drawingRef = useRef<boolean>(false)
  const cellSize = 320 / size

  const drawCell = (cx: number, cy: number): void => {
    const canvas = canvasRef.current
    if (canvas === null) return
    const ctx = canvas.getContext('2d')
    if (ctx === null) return
    const rect = canvas.getBoundingClientRect()
    const sx = canvas.width / rect.width
    const sy = canvas.height / rect.height
    const x = (cx - rect.left) * sx
    const y = (cy - rect.top) * sy
    ctx.fillStyle = '#4a9eff'
    ctx.fillRect(x - cellSize / 2, y - cellSize / 2, cellSize, cellSize)
  }

  const clear = (): void => {
    const canvas = canvasRef.current
    if (canvas === null) return
    const ctx = canvas.getContext('2d')
    if (ctx === null) return
    ctx.fillStyle = '#1a1d24'
    ctx.fillRect(0, 0, canvas.width, canvas.height)
  }

  useEffect(() => { clear() }, [size])

  return (
    <div className={css.wrap}>
      <Header title={t('etch.title', { size })} onClose={onClose} t={t} />
      <div className={css.canvasWrap}>
        <canvas
          ref={canvasRef}
          className={css.canvas}
          width={320}
          height={320}
          onPointerDown={(e) => { drawingRef.current = true; drawCell(e.clientX, e.clientY) }}
          onPointerMove={(e) => { if (drawingRef.current) drawCell(e.clientX, e.clientY) }}
          onPointerUp={() => { drawingRef.current = false }}
          onPointerLeave={() => { drawingRef.current = false }}
        />
      </div>
      <div className={css.row}>
        <button type="button" className={css.btn} onClick={clear}>{t('common.clear')}</button>
      </div>
    </div>
  )
}

// ─── Pixel Art ─────────────────────────────────────────────
export interface PixelArtProps { size: number }
/** Pixel editor with palette. */
export function PixelArt({ size, onClose, t }: GameProps & PixelArtProps) {
  const [grid, setGrid] = useState<number[]>(() => new Array(size * size).fill(-1))
  const [color, setColor] = useState(0)
  const paint = (i: number): void => {
    setGrid(prev => {
      const next = [...prev]
      next[i] = color
      return next
    })
  }
  const reset = (): void => setGrid(new Array(size * size).fill(-1))
  return (
    <div className={css.wrap}>
      <Header title={t('pixel.title', { size })} onClose={onClose} t={t} />
      <div className={css.row}>
        {PALETTE.slice(0, 6).map((c, i) => (
          <button
            key={i}
            type="button"
            onClick={() => setColor(i)}
            style={{ background: c, width: '24px', height: '24px', borderRadius: '4px', border: color === i ? '2px solid #fff' : '2px solid transparent', cursor: 'pointer' }}
            aria-label={`color ${i}`}
          />
        ))}
        <button type="button" onClick={() => setColor(-1)} style={{ width: '24px', height: '24px', borderRadius: '4px', background: '#1a1d24', border: color === -1 ? '2px solid #fff' : '2px solid transparent', cursor: 'pointer' }} aria-label="eraser">E</button>
      </div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)` }}>
        {grid.map((c, i) => (
          <button
            key={i}
            type="button"
            className={css.cell}
            style={{ background: c === -1 ? '#1a1d24' : PALETTE[c] }}
            onClick={() => paint(i)}
          />
        ))}
      </div>
      <button type="button" className={css.btn} onClick={reset}>{t('common.clear')}</button>
    </div>
  )
}

// ─── Number Guess ──────────────────────────────────────────
export interface NumberGuessProps { min: number; max: number }
/** Guess a number with higher/lower feedback. */
export function NumberGuess({ min, max, onClose, t }: GameProps & NumberGuessProps) {
  const [answer, setAnswer] = useState<number>(() => randInt(min, max))
  const [guesses, setGuesses] = useState<number>(0)
  const [input, setInput] = useState('')
  const [hint, setHint] = useState<string | null>(null)
  const [won, setWon] = useState(false)
  const submit = (): void => {
    const g = Number.parseInt(input, 10)
    if (!Number.isFinite(g)) { setHint(t('numguess.enterNumber')); return }
    if (g < min || g > max) { setHint(t('numguess.range', { min, max })); return }
    const n = guesses + 1
    setGuesses(n)
    if (g === answer) { setWon(true); setHint(null) }
    else if (g < answer) setHint(t('numguess.tooSmall', { g }))
    else setHint(t('numguess.tooBig', { g }))
    setInput('')
  }
  const reset = (): void => {
    setAnswer(randInt(min, max)); setGuesses(0); setInput(''); setHint(null); setWon(false)
  }
  return (
    <div className={css.wrap}>
      <Header title={t('numguess.title', { min, max })} onClose={onClose} t={t} />
      {won ? (
        <>
          <Banner kind="win" text={t('numguess.won', { answer, n: guesses })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <>
          <div className={css.stats}><span>{t('numguess.guessed')}: <b>{guesses}</b></span></div>
          {hint !== null && <div className={css.result}>{hint}</div>}
          <div className={css.row}>
            <input
              className={css.input}
              type="number"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') submit() }}
              placeholder={`${min}-${max}`}
            />
            <button type="button" className={css.btn} onClick={submit}>{t('common.guess')}</button>
          </div>
        </>
      )}
    </div>
  )
}

// ─── Math Quiz ─────────────────────────────────────────────
export type MathOp = '+' | '-' | '*' | '/'
export interface MathQuizProps { op: MathOp; maxOperand: number; questions: number }
/** Solve N math problems; counts correct. */
export function MathQuiz({ op, maxOperand, questions, onClose, t }: GameProps & MathQuizProps) {
  const makeProblem = useCallback((): { text: string; answer: number } => {
    if (op === '+') {
      const a = randInt(0, maxOperand); const b = randInt(0, maxOperand)
      return { text: `${a} + ${b}`, answer: a + b }
    }
    if (op === '-') {
      const a = randInt(0, maxOperand); const b = randInt(0, a)
      return { text: `${a} - ${b}`, answer: a - b }
    }
    if (op === '*') {
      const a = randInt(0, maxOperand); const b = randInt(0, maxOperand)
      return { text: `${a} × ${b}`, answer: a * b }
    }
    const b = randInt(1, maxOperand); const r = randInt(0, maxOperand); const a = b * r
    return { text: `${a} ÷ ${b}`, answer: r }
  }, [op, maxOperand])
  const [problem, setProblem] = useState(makeProblem)
  const [correct, setCorrect] = useState(0)
  const [done, setDone] = useState(0)
  const [input, setInput] = useState('')
  const [finished, setFinished] = useState(false)
  const submit = (): void => {
    const g = Number.parseInt(input, 10)
    if (!Number.isFinite(g)) return
    if (g === problem.answer) setCorrect(c => c + 1)
    const nextDone = done + 1
    setDone(nextDone)
    setInput('')
    if (nextDone >= questions) setFinished(true)
    else setProblem(makeProblem())
  }
  const reset = (): void => {
    setProblem(makeProblem()); setCorrect(0); setDone(0); setInput(''); setFinished(false)
  }
  const opLabel = op === '+' ? t('math.opAdd') : op === '-' ? t('math.opSub') : op === '*' ? t('math.opMul') : t('math.opDiv')
  return (
    <div className={css.wrap}>
      <Header title={t('math.title', { op: opLabel })} onClose={onClose} t={t} />
      {finished ? (
        <>
          <Banner kind="info" text={t('math.result', { total: questions, correct })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <>
          <div className={css.stats}><span>{t('math.progress', { n: done + 1, total: questions })}</span><span>{t('common.correctLabel')} <b>{correct}</b></span></div>
          <div className={css.huge}>{problem.text} = ?</div>
          <div className={css.row}>
            <input
              className={css.input}
              type="number"
              value={input}
              autoFocus
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') submit() }}
            />
            <button type="button" className={css.btn} onClick={submit}>{t('common.submit')}</button>
          </div>
        </>
      )}
    </div>
  )
}

// ─── Trivia ────────────────────────────────────────────────
export type TriviaCategory = 'history' | 'science' | 'geography' | 'sports' | 'movies' | 'literature' | 'codebase'
export interface TriviaProps { category: TriviaCategory; questions: number }
/** Multiple-choice trivia. */
export function Trivia({ category, questions, onClose, t }: GameProps & TriviaProps) {
  const pool = useMemo<ReadonlyArray<{ q: string; options: readonly string[]; answer: number }>>(() => {
    const src = category === 'history' ? TRIVIA_HISTORY
      : category === 'science' ? TRIVIA_SCIENCE
      : category === 'geography' ? TRIVIA_GEOGRAPHY
      : category === 'sports' ? TRIVIA_SPORTS
      : category === 'movies' ? TRIVIA_MOVIES
      : category === 'literature' ? TRIVIA_LITERATURE
      : TRIVIA_CODEBASE
    return shuffle(src).slice(0, Math.min(questions, src.length))
  }, [category, questions])
  const [idx, setIdx] = useState(0)
  const [score, setScore] = useState(0)
  const [chosen, setChosen] = useState<number | null>(null)
  const [finished, setFinished] = useState(false)
  const q = pool[idx]
  const catLabel = category === 'history' ? t('trivia.history') : category === 'science' ? t('trivia.science')
    : category === 'geography' ? t('trivia.geography') : category === 'sports' ? t('trivia.sports')
    : category === 'movies' ? t('trivia.movies') : category === 'literature' ? t('trivia.literature')
    : t('trivia.codebase')
  const choose = (i: number): void => {
    if (chosen !== null || q === undefined) return
    setChosen(i)
    if (i === q.answer) setScore(s => s + 1)
  }
  const next = (): void => {
    if (idx + 1 >= pool.length) { setFinished(true); return }
    setIdx(idx + 1); setChosen(null)
  }
  const reset = (): void => { setIdx(0); setScore(0); setChosen(null); setFinished(false) }
  if (q === undefined || finished) {
    return (
      <div className={css.wrap}>
        <Header title={t('trivia.title', { cat: catLabel })} onClose={onClose} t={t} />
        <Banner kind="info" text={t('trivia.result', { total: pool.length, score })} />
        <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
      </div>
    )
  }
  return (
    <div className={css.wrap}>
      <Header title={t('trivia.title', { cat: catLabel })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('trivia.progress', { n: idx + 1, total: pool.length })}</span><span>{t('common.correctLabel')} <b>{score}</b></span></div>
      <div className={css.big}>{q.q}</div>
      <div className={css.col}>
        {q.options.map((opt, i) => (
          <button
            key={i}
            type="button"
            className={css.btn}
            style={
              chosen !== null && i === q.answer ? { background: '#2ecc71' }
              : chosen === i ? { background: '#e74c3c' }
              : { background: '#2a2d36' }
            }
            onClick={() => choose(i)}
            disabled={chosen !== null}
          >
            {opt}
          </button>
        ))}
      </div>
      {chosen !== null && (
        <button type="button" className={css.btn} onClick={next}>{idx + 1 >= pool.length ? t('common.viewResult') : t('common.nextQuestion')}</button>
      )}
    </div>
  )
}

// ─── Hangman ───────────────────────────────────────────────
export interface HangmanProps { words: readonly string[]; lives: number }
/** Hangman: guess letters to reveal the word. */
export function Hangman({ words, lives, onClose, t }: GameProps & HangmanProps) {
  const [answer, setAnswer] = useState<string>(() => pick(words))
  const [guessed, setGuessed] = useState<Set<string>>(() => new Set())
  const [wrong, setWrong] = useState<number>(0)
  const display = [...answer].map(ch => ch === ' ' ? ' ' : (guessed.has(ch) || !/[A-Z]/.test(ch) ? ch : '_')).join(' ')
  const lost = wrong >= lives
  const won = !lost && [...answer].every(ch => !/[A-Z]/.test(ch) || guessed.has(ch))
  const guess = (letter: string): void => {
    if (lost || won || guessed.has(letter)) return
    const next = new Set(guessed); next.add(letter)
    setGuessed(next)
    if (!answer.includes(letter)) setWrong(w => w + 1)
  }
  const reset = (): void => { setAnswer(pick(words)); setGuessed(new Set()); setWrong(0) }
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')
  return (
    <div className={css.wrap}>
      <Header title={t('hangman.title')} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.remaining')}: <b>{lives - wrong}</b></span></div>
      <div className={css.huge} style={{ fontFamily: 'ui-monospace, monospace', letterSpacing: '4px' }}>{display}</div>
      {(lost || won) && (
        <Banner kind={won ? 'win' : 'lose'} text={won ? t('hangman.won') : t('common.revealAnswer', { answer })} />
      )}
      <div className={css.kbdRow} style={{ flexWrap: 'wrap' }}>
        {letters.map(l => (
          <button
            key={l}
            type="button"
            className={css.key}
            disabled={guessed.has(l) || lost || won}
            onClick={() => guess(l)}
            style={guessed.has(l) ? (answer.includes(l) ? { background: '#2ecc71', color: '#fff' } : { background: '#3a1a1a', color: '#e74c3c' }) : undefined}
          >
            {l}
          </button>
        ))}
      </div>
      {(lost || won) && <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>}
    </div>
  )
}

// ─── Word Scramble ─────────────────────────────────────────
export interface WordScrambleProps { words: readonly string[] }
/** Unscramble a shuffled word. */
export function WordScramble({ words, onClose, t }: GameProps & WordScrambleProps) {
  const [answer, setAnswer] = useState<string>(() => pick(words))
  const [input, setInput] = useState('')
  const [solved, setSolved] = useState(false)
  const [revealed, setRevealed] = useState(false)
  const scrambled = useMemo(() => {
    const arr = answer.split('')
    let s: string
    do {
      s = shuffle(arr).join('')
    } while (s === answer && arr.length > 1)
    return s
  }, [answer])
  const submit = (): void => {
    if (input.trim().toUpperCase() === answer) setSolved(true)
    setInput('')
  }
  const reset = (): void => { setAnswer(pick(words)); setInput(''); setSolved(false); setRevealed(false) }
  return (
    <div className={css.wrap}>
      <Header title={t('scramble.title')} onClose={onClose} t={t} />
      <div className={css.huge} style={{ fontFamily: 'ui-monospace, monospace', letterSpacing: '6px' }}>{scrambled}</div>
      {solved ? (
        <>
          <Banner kind="win" text={t('scramble.correct', { answer })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.nextOne')}</button>
        </>
      ) : revealed ? (
        <>
          <Banner kind="lose" text={t('common.revealAnswer', { answer })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.nextOne')}</button>
        </>
      ) : (
        <>
          <div className={css.row}>
            <input
              className={css.input}
              value={input}
              onChange={e => setInput(e.target.value.toUpperCase())}
              onKeyDown={e => { if (e.key === 'Enter') submit() }}
              placeholder={t('common.yourAnswer')}
            />
            <button type="button" className={css.btn} onClick={submit}>{t('common.submit')}</button>
          </div>
          <button type="button" className={css.btn + ' ' + css.secondary} onClick={() => setRevealed(true)}>{t('common.giveUp')}</button>
        </>
      )}
    </div>
  )
}

// ─── Typing ────────────────────────────────────────────────
export type TypingDifficulty = 'short' | 'long' | 'pangram'
export interface TypingProps { difficulty: TypingDifficulty; count: number }
/** Type the displayed text; measures WPM and accuracy. */
export function Typing({ difficulty, count, onClose, t }: GameProps & TypingProps) {
  const pool = useMemo(() => {
    const src = difficulty === 'short' ? TYPING_PHRASES_SHORT : difficulty === 'long' ? TYPING_PHRASES_LONG : TYPING_PANGRAMS
    return shuffle(src).slice(0, count)
  }, [difficulty, count])
  const [idx, setIdx] = useState(0)
  const [input, setInput] = useState('')
  const [startMs, setStartMs] = useState<number | null>(null)
  const [done, setDone] = useState<number[]>([])
  const target = pool[idx] ?? ''
  const finished = idx >= pool.length
  const onChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    if (startMs === null) setStartMs(Date.now())
    const v = e.target.value
    setInput(v)
    if (v === target) {
      const dur = (Date.now() - (startMs ?? Date.now())) / 1000
      const wpm = Math.round((target.length / 5) / (dur / 60))
      setDone(prev => [...prev, wpm])
      setIdx(idx + 1)
      setInput('')
      setStartMs(null)
    }
  }
  const reset = (): void => { setIdx(0); setInput(''); setStartMs(null); setDone([]) }
  if (finished) {
    const avg = done.length > 0 ? Math.round(done.reduce((a, b) => a + b, 0) / done.length) : 0
    return (
      <div className={css.wrap}>
        <Header title={t('typing.title')} onClose={onClose} t={t} />
        <Banner kind="win" text={t('typing.done', { avg })} />
        <div className={css.hint}>{t('typing.segments')}{done.map(w => `${w}`).join(' · ')}</div>
        <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
      </div>
    )
  }
  return (
    <div className={css.wrap}>
      <Header title={t('typing.title')} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('typing.progress', { n: idx + 1, total: pool.length })}</span></div>
      <div className={css.result} style={{ fontFamily: 'ui-monospace, monospace', fontSize: '14px' }}>{target}</div>
      <input
        className={css.input}
        style={{ width: '100%' }}
        value={input}
        onChange={onChange}
        autoFocus
      />
      <div className={css.hint}>{t('typing.hint')}</div>
    </div>
  )
}

// ─── Stroop ────────────────────────────────────────────────
export interface StroopProps { rounds: number; mode: 'word' | 'color' }
/** Stroop test: name the word's text or its color. */
export function Stroop({ rounds, mode, onClose, t }: GameProps & StroopProps) {
  const COLORS: ReadonlyArray<{ name: string; color: string }> = [
    { name: t('stroop.red'), color: '#e74c3c' },
    { name: t('stroop.green'), color: '#2ecc71' },
    { name: t('stroop.blue'), color: '#3498db' },
    { name: t('stroop.yellow'), color: '#f1c40f' },
    { name: t('stroop.purple'), color: '#9b59b6' },
    { name: t('stroop.orange'), color: '#e67e22' },
  ]
  const makeRound = useCallback((): { word: string; color: string; answer: string } => {
    const w = pick(COLORS)
    const c = pick(COLORS)
    return {
      word: w.name,
      color: c.color,
      answer: mode === 'word' ? w.name : c.name,
    }
  }, [mode])
  const [round, setRound] = useState(makeRound)
  const [idx, setIdx] = useState(0)
  const [score, setScore] = useState(0)
  const [finished, setFinished] = useState(false)
  const choose = (name: string): void => {
    if (finished) return
    if (name === round.answer) setScore(s => s + 1)
    if (idx + 1 >= rounds) { setFinished(true); return }
    setIdx(idx + 1)
    setRound(makeRound())
  }
  const reset = (): void => { setRound(makeRound()); setIdx(0); setScore(0); setFinished(false) }
  return (
    <div className={css.wrap}>
      <Header title={mode === 'word' ? t('stroop.titleWord') : t('stroop.titleColor')} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('stroop.progress', { n: idx + 1, total: rounds })}</span><span>{t('common.correctLabel')} <b>{score}</b></span></div>
      {finished ? (
        <>
          <Banner kind="info" text={t('stroop.result', { total: rounds, score })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <>
          <div className={css.huge} style={{ color: round.color }}>{round.word}</div>
          <div className={css.row}>
            {COLORS.map(c => (
              <button key={c.name} type="button" className={css.btn} style={{ background: c.color }} onClick={() => choose(c.name)}>
                {c.name}
              </button>
            ))}
          </div>
          <div className={css.hint}>{mode === 'word' ? t('stroop.hintWord') : t('stroop.hintColor')}</div>
        </>
      )}
    </div>
  )
}

// ─── Riddle / Fill-blank ───────────────────────────────────
export interface RiddleProps { riddles: readonly { q: string; a: string }[]; title?: string }
/** Solve text riddles (or any question-answer fill-in-the-blank quiz). */
export function Riddle({ riddles, title, onClose, t }: GameProps & RiddleProps) {
  const [pool, setPool] = useState<readonly { q: string; a: string }[]>(() => shuffle(riddles))
  const [idx, setIdx] = useState(0)
  const [input, setInput] = useState('')
  const [revealed, setRevealed] = useState(false)
  const [score, setScore] = useState(0)
  const r = pool[idx]
  const resolvedTitle = title ?? t('riddle.title')
  const submit = (): void => {
    if (r === undefined) return
    const normalized = (s: string): string => s.trim().toLowerCase()
    if (normalized(input) === normalized(r.a)) { setScore(s => s + 1); setRevealed(true) }
    else setInput('')
  }
  const next = (): void => { setIdx(idx + 1); setInput(''); setRevealed(false) }
  const reset = (): void => { setPool(shuffle(riddles)); setIdx(0); setInput(''); setRevealed(false); setScore(0) }
  if (r === undefined) {
    return (
      <div className={css.wrap}>
        <Header title={resolvedTitle} onClose={onClose} t={t} />
        <Banner kind="info" text={t('riddle.result', { score })} />
        <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
      </div>
    )
  }
  return (
    <div className={css.wrap}>
      <Header title={resolvedTitle} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('riddle.progress', { n: idx + 1 })}</span><span>{t('common.correctLabel')} <b>{score}</b></span></div>
      <div className={css.big}>{r.q}</div>
      {revealed ? (
        <>
          <Banner kind="win" text={t('riddle.revealed', { a: r.a })} />
          <button type="button" className={css.btn} onClick={next}>{t('common.nextQuestion')}</button>
        </>
      ) : (
        <>
          <div className={css.row}>
            <input
              className={css.input}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') submit() }}
              placeholder={t('common.yourAnswer')}
            />
            <button type="button" className={css.btn} onClick={submit}>{t('common.submit')}</button>
          </div>
          <button type="button" className={`${css.btn} ${css.secondary}`} onClick={() => setRevealed(true)}>{t('common.giveUp')}</button>
        </>
      )}
    </div>
  )
}

// ─── Coin Flip ─────────────────────────────────────────────
export interface CoinProps { streakTarget: number }
/** Flip a coin; try to build a streak of N. */
export function Coin({ streakTarget, onClose, t }: GameProps & CoinProps) {
  const [streak, setStreak] = useState(0)
  const [best, setBest] = useState(0)
  const [last, setLast] = useState<'H' | 'T' | null>(null)
  const [won, setWon] = useState(false)
  const flip = (g: 'H' | 'T'): void => {
    if (won) return
    const result: 'H' | 'T' = Math.random() < 0.5 ? 'H' : 'T'
    setLast(result)
    if (result === g) {
      const next = streak + 1
      setStreak(next)
      setBest(b => Math.max(b, next))
      if (next >= streakTarget) setWon(true)
    } else {
      setStreak(0)
    }
  }
  const reset = (): void => { setStreak(0); setLast(null); setWon(false) }
  return (
    <div className={css.wrap}>
      <Header title={t('coin.title', { target: streakTarget })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.current')}: <b>{streak}</b></span><span>{t('common.best')}: <b>{best}</b></span></div>
      <div className={css.huge}>{last === null ? '—' : last === 'H' ? `🪙 ${t('coin.heads')}` : `🪙 ${t('coin.tails')}`}</div>
      {won ? (
        <>
          <Banner kind="win" text={t('coin.won', { target: streakTarget })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <>
          <div className={css.row}>
            <button type="button" className={css.btn} onClick={() => flip('H')}>{t('coin.heads')}</button>
            <button type="button" className={css.btn} onClick={() => flip('T')}>{t('coin.tails')}</button>
          </div>
          <div className={css.hint}>{t('coin.hint')}</div>
        </>
      )}
    </div>
  )
}

// ─── Dice ──────────────────────────────────────────────────
export interface DiceProps { count: number; targetSum: number }
/** Roll N dice; reach target sum total. */
export function Dice({ count, targetSum, onClose, t }: GameProps & DiceProps) {
  const [rolls, setRolls] = useState<number[]>(() => Array.from({ length: count }, () => 1))
  const [total, setTotal] = useState(0)
  const [rollsCount, setRollsCount] = useState(0)
  const roll = (): void => {
    const next = Array.from({ length: count }, () => randInt(1, 6))
    setRolls(next)
    const sum = next.reduce((a, b) => a + b, 0)
    setTotal(t => t + sum)
    setRollsCount(r => r + 1)
  }
  const reset = (): void => { setRolls(Array.from({ length: count }, () => 1)); setTotal(0); setRollsCount(0) }
  const won = total >= targetSum
  return (
    <div className={css.wrap}>
      <Header title={t('dice.title', { count, target: targetSum })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.total')}: <b>{total}</b> / {targetSum}</span><span>{t('dice.rollsLabel')}: <b>{rollsCount}</b></span></div>
      <div className={css.row}>
        {rolls.map((v, i) => (
          <div key={i} style={{ width: '40px', height: '40px', background: '#2a2d36', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '22px', fontWeight: 700 }}>
            {['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'][v - 1]}
          </div>
        ))}
      </div>
      {won ? (
        <>
          <Banner kind="win" text={t('dice.won', { target: targetSum })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <button type="button" className={css.btn} onClick={roll}>{t('common.roll')}</button>
      )}
    </div>
  )
}

// ─── Spinner ───────────────────────────────────────────────
export interface SpinnerProps { segments: number }
/** Spin a wheel; land on target segment for the win. */
export function Spinner({ segments, onClose, t }: GameProps & SpinnerProps) {
  const [angle, setAngle] = useState(0)
  const [spinning, setSpinning] = useState(false)
  const [landed, setLanded] = useState<number | null>(null)
  const [target] = useState<number>(() => randInt(0, segments - 1))
  const spin = (): void => {
    if (spinning) return
    setSpinning(true)
    const turns = 4 + Math.random() * 3
    const finalAngle = angle + turns * 360
    setAngle(finalAngle)
    window.setTimeout(() => {
      const norm = ((360 - (finalAngle % 360)) % 360 + 360) % 360
      const seg = Math.floor(norm / (360 / segments)) % segments
      setLanded(seg)
      setSpinning(false)
    }, 1100)
  }
  const reset = (): void => { setLanded(null); spin() }
  const won = landed === target
  return (
    <div className={css.wrap}>
      <Header title={t('spinner.title', { segments })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.target')}: <b>{target + 1}</b></span></div>
      <div className={css.canvasWrap}>
        <div className={css.canvas} style={{ position: 'relative', background: 'transparent' }}>
          <div style={{
            position: 'absolute', inset: '0', borderRadius: '50%',
            background: `conic-gradient(${range(segments).map(i => i === target ? '#2ecc71 ' : '#4a9eff ').map((c, i) => `${c}${(i * 360) / segments}deg ${(i + 1) * 360 / segments}deg`).join(',')})`,
            transform: `rotate(${angle}deg)`,
            transition: 'transform 1.1s cubic-bezier(0.2, 0.7, 0.1, 1)',
          }} />
          <div style={{ position: 'absolute', top: '-6px', left: '50%', transform: 'translateX(-50%)', width: 0, height: 0, borderLeft: '8px solid transparent', borderRight: '8px solid transparent', borderTop: '14px solid #e74c3c' }} />
          <div style={{ position: 'absolute', inset: '40%', borderRadius: '50%', background: '#0f1117', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '18px', fontWeight: 700 }}>
            {landed === null ? '?' : landed + 1}
          </div>
        </div>
      </div>
      {landed !== null && (
        <Banner kind={won ? 'win' : 'lose'} text={won ? t('spinner.hit', { n: target + 1 }) : t('spinner.landed', { landed: landed + 1, target: target + 1 })} />
      )}
      <button type="button" className={css.btn} onClick={landed === null ? spin : reset} disabled={spinning}>
        {spinning ? t('spinner.spinning') : landed === null ? t('spinner.spin') : t('common.replay')}
      </button>
    </div>
  )
}

// ─── Color Pick ────────────────────────────────────────────
export interface ColorPickProps { rounds: number }
/** Guess the named color from swatches. */
export function ColorPick({ rounds, onClose, t }: GameProps & ColorPickProps) {
  const [round, setRound] = useState(() => {
    const all = shuffle([...PALETTE]).slice(0, 4)
    return { options: all, answer: pick(all), idx: 0 }
  })
  const [idx, setIdx] = useState(0)
  const [score, setScore] = useState(0)
  const [finished, setFinished] = useState(false)
  const [chosen, setChosen] = useState<string | null>(null)
  const choose = (c: string): void => {
    if (finished || chosen !== null) return
    setChosen(c)
    if (c === round.answer) setScore(s => s + 1)
    window.setTimeout(() => {
      if (idx + 1 >= rounds) { setFinished(true); return }
        const all = shuffle([...PALETTE]).slice(0, 4)
        setRound({ options: all, answer: pick(all), idx: idx + 1 })
        setIdx(idx + 1)
        setChosen(null)
    }, 600)
  }
  const reset = (): void => {
    const all = shuffle([...PALETTE]).slice(0, 4)
    setRound({ options: all, answer: pick(all), idx: 0 })
    setIdx(0); setScore(0); setFinished(false); setChosen(null)
  }
  return (
    <div className={css.wrap}>
      <Header title={t('colorpick.title')} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('colorpick.progress', { n: idx + 1, total: rounds })}</span><span>{t('common.correctLabel')} <b>{score}</b></span></div>
      {finished ? (
        <>
          <Banner kind="info" text={t('colorpick.result', { total: rounds, score })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <>
          <div className={css.huge} style={{ color: round.answer }}>{t('colorpick.word')}</div>
          <div className={css.row}>
            {round.options.map((c, i) => (
              <button
                key={i}
                type="button"
                onClick={() => choose(c)}
                disabled={chosen !== null}
                style={{
                  width: '60px', height: '60px', borderRadius: '8px', background: c, cursor: 'pointer', border: chosen === c ? '3px solid #fff' : '3px solid transparent',
                }}
                aria-label={`color ${i}`}
              />
            ))}
          </div>
          <div className={css.hint}>{t('colorpick.hint')}</div>
        </>
      )}
    </div>
  )
}

// ─── Slots ─────────────────────────────────────────────────
export interface SlotsProps { symbols: readonly string[]; credits: number }
/** Slot machine: spin 3 reels, win on triple match. */
export function Slots({ symbols, credits, onClose, t }: GameProps & SlotsProps) {
  const [reels, setReels] = useState<string[]>(() => [symbols[0]!, symbols[0]!, symbols[0]!])
  const [bal, setBal] = useState(credits)
  const [spinning, setSpinning] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)
  const spin = (): void => {
    if (spinning || bal < 1) return
    setSpinning(true); setBal(b => b - 1); setMsg(null)
    const next = [pick(symbols), pick(symbols), pick(symbols)]
    setReels(next)
    window.setTimeout(() => {
      setSpinning(false)
      if (next[0] === next[1] && next[1] === next[2]) {
        const win = 50
        setBal(b => b + win)
        setMsg(t('slots.triple', { win }))
      } else if (next[0] === next[1] || next[1] === next[2] || next[0] === next[2]) {
        const win = 2
        setBal(b => b + win)
        setMsg(t('slots.smallWin', { win }))
      } else {
        setMsg(t('slots.again'))
      }
    }, 600)
  }
  const reset = (): void => { setBal(credits); setReels([symbols[0]!, symbols[0]!, symbols[0]!]); setMsg(null) }
  return (
    <div className={css.wrap}>
      <Header title={t('slots.title')} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.balance')}: <b>{bal}</b></span></div>
      <div className={css.row}>
        {reels.map((s, i) => (
          <div key={i} style={{
            width: '60px', height: '80px', background: '#1a1d24', borderRadius: '8px',
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '32px',
            opacity: spinning ? 0.4 : 1,
          }}>
            {s}
          </div>
        ))}
      </div>
      {msg !== null && <div className={css.result}>{msg}</div>}
      {bal < 1 ? (
        <>
          <Banner kind="lose" text={t('common.broke')} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.reset')}</button>
        </>
      ) : (
        <button type="button" className={css.btn} onClick={spin} disabled={spinning}>{t('slots.spinOne')}</button>
      )}
    </div>
  )
}

// ─── Blackjack ─────────────────────────────────────────────
export interface BlackjackProps { credits: number }
const BJ_RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'] as const
const BJ_SUITS = ['♠', '♥', '♦', '♣'] as const
function cardValue(r: string): number {
  if (r === 'A') return 11
  if (r === 'K' || r === 'Q' || r === 'J') return 10
  return Number.parseInt(r, 10)
}
function bjScore(cards: ReadonlyArray<{ r: string; s: string }>): number {
  let sum = 0; let aces = 0
  for (const c of cards) { sum += cardValue(c.r); if (c.r === 'A') aces++ }
  while (sum > 21 && aces > 0) { sum -= 10; aces-- }
  return sum
}
function drawCard(): { r: string; s: string } {
  return { r: pick(BJ_RANKS as unknown as string[]), s: pick(BJ_SUITS as unknown as string[]) }
}

/** Result banner state: kind picked by game logic, not message text. */
interface BjResult { kind: 'win' | 'lose' | 'info'; text: string }
/** Blackjack vs dealer. */
export function Blackjack({ credits, onClose, t }: GameProps & BlackjackProps) {
  const [bal, setBal] = useState(credits)
  const [player, setPlayer] = useState<ReadonlyArray<{ r: string; s: string }>>([])
  const [dealer, setDealer] = useState<ReadonlyArray<{ r: string; s: string }>>([])
  const [phase, setPhase] = useState<'idle' | 'player' | 'dealer' | 'done'>('idle')
  const [result, setResult] = useState<BjResult | null>(null)
  const start = (): void => {
    if (bal < 1) return
    setBal(b => b - 1)
    const p = [drawCard(), drawCard()]
    const d = [drawCard(), drawCard()]
    setPlayer(p); setDealer(d)
    const ps = bjScore(p)
    if (ps === 21) {
      setPhase('done'); setResult({ kind: 'win', text: 'Blackjack! +3' })
      setBal(b => b + 3)
    } else {
      setPhase('player'); setResult(null)
    }
  }
  const hit = (): void => {
    if (phase !== 'player') return
    const p = [...player, drawCard()]
    setPlayer(p)
    const s = bjScore(p)
    if (s > 21) { setPhase('done'); setResult({ kind: 'lose', text: t('blackjack.bust') }) }
    else if (s === 21) stand(p)
  }
  const stand = (p: ReadonlyArray<{ r: string; s: string }> = player): void => {
    if (phase !== 'player') return
    setPhase('dealer')
    let d = [...dealer]
    while (bjScore(d) < 17) d = [...d, drawCard()]
    setDealer(d)
    const ps = bjScore(p); const ds = bjScore(d)
    let payout = 0; let res: BjResult
    if (ds > 21 || ps > ds) { payout = 2; res = { kind: 'win', text: t('blackjack.win', { n: 2 }) } }
    else if (ps === ds) { payout = 1; res = { kind: 'info', text: t('blackjack.push', { n: 1 }) } }
    else { res = { kind: 'lose', text: t('blackjack.dealerWins') } }
    if (payout > 0) setBal(b => b + payout)
    setResult(res); setPhase('done')
  }
  const reset = (): void => { setBal(credits); setPlayer([]); setDealer([]); setPhase('idle'); setResult(null) }
  return (
    <div className={css.wrap}>
      <Header title={t('blackjack.title')} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.balance')}: <b>{bal}</b></span></div>
      {phase !== 'idle' && (
        <>
          <div className={css.col}>
            <div className={css.hint}>{t('blackjack.dealerScore', { score: phase === 'dealer' || phase === 'done' ? bjScore(dealer) : '?' })}</div>
            <div className={css.row}>{dealer.map((c, i) => <span key={i} className={css.tag} style={{ fontSize: '20px', padding: '4px 10px' }}>{c.s}{c.r}</span>)}</div>
          </div>
          <div className={css.col}>
            <div className={css.hint}>{t('blackjack.playerScore', { score: bjScore(player) })}</div>
            <div className={css.row}>{player.map((c, i) => <span key={i} className={css.tag} style={{ fontSize: '20px', padding: '4px 10px' }}>{c.s}{c.r}</span>)}</div>
          </div>
        </>
      )}
      {result !== null && <Banner kind={result.kind} text={result.text} />}
      {phase === 'idle' && <button type="button" className={css.btn} onClick={start} disabled={bal < 1}>{t('blackjack.betStart')}</button>}
      {phase === 'player' && (
        <div className={css.row}>
          <button type="button" className={css.btn} onClick={hit}>{t('blackjack.hit')}</button>
          <button type="button" className={css.btn + ' ' + css.secondary} onClick={() => stand()}>{t('blackjack.stand')}</button>
        </div>
      )}
      {phase === 'done' && bal >= 1 && <button type="button" className={css.btn} onClick={start}>{t('common.replay')}</button>}
      {phase === 'done' && bal < 1 && <button type="button" className={css.btn} onClick={reset}>{t('common.reset')}</button>}
    </div>
  )
}

// ─── High or Low ───────────────────────────────────────────
export interface HighLowProps { credits: number }
/** Card high/low guess game. */
export function HighLow({ credits, onClose, t }: GameProps & HighLowProps) {
  const [bal, setBal] = useState(credits)
  const [card, setCard] = useState<{ r: string; s: string } | null>(null)
  const [msg, setMsg] = useState<string | null>(null)
  const [streak, setStreak] = useState(0)
  const start = (): void => {
    if (bal < 1) return
    setBal(b => b - 1)
    setCard(drawCard()); setMsg(null); setStreak(0)
  }
  const guess = (g: 'higher' | 'lower'): void => {
    if (card === null) return
    const next = drawCard()
    const cur = cardValue(card.r); const nxt = cardValue(next.r)
    const correct = g === 'higher' ? nxt > cur : nxt < cur
    setCard(next)
    if (correct) {
      setStreak(s => s + 1)
      setBal(b => b + 1)
      setMsg(t('highlow.correct', { n: streak + 1 }))
    } else {
      setMsg(t('highlow.wrong'))
      setStreak(0)
    }
  }
  const reset = (): void => { setBal(credits); setCard(null); setMsg(null); setStreak(0) }
  return (
    <div className={css.wrap}>
      <Header title={t('highlow.title')} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.balance')}: <b>{bal}</b></span><span>{t('highlow.streak')}: <b>{streak}</b></span></div>
      <div className={css.huge}>{card === null ? '—' : `${card.s}${card.r}`}</div>
      {msg !== null && <div className={css.result}>{msg}</div>}
      {card === null ? (
        <button type="button" className={css.btn} onClick={start} disabled={bal < 1}>{t('highlow.betDraw')}</button>
      ) : bal < 1 ? (
        <>
          <Banner kind="lose" text={t('common.broke')} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.reset')}</button>
        </>
      ) : (
        <div className={css.row}>
          <button type="button" className={css.btn} onClick={() => guess('higher')}>{t('highlow.higher')}</button>
          <button type="button" className={css.btn + ' ' + css.secondary} onClick={() => guess('lower')}>{t('highlow.lower')}</button>
        </div>
      )}
    </div>
  )
}

// ─── War ───────────────────────────────────────────────────
export interface WarProps { rounds: number }
/** War card game: higher card wins. */
export function War({ rounds, onClose, t }: GameProps & WarProps) {
  const [round, setRound] = useState(0)
  const [pCard, setPCard] = useState<{ r: string; s: string } | null>(null)
  const [dCard, setDCard] = useState<{ r: string; s: string } | null>(null)
  const [pScore, setPScore] = useState(0)
  const [dScore, setDScore] = useState(0)
  const [done, setDone] = useState(false)
  const play = (): void => {
    const p = drawCard(); const d = drawCard()
    setPCard(p); setDCard(d)
    if (cardValue(p.r) > cardValue(d.r)) setPScore(s => s + 1)
    else if (cardValue(p.r) < cardValue(d.r)) setDScore(s => s + 1)
    const r = round + 1
    setRound(r)
    if (r >= rounds) setDone(true)
  }
  const reset = (): void => { setRound(0); setPCard(null); setDCard(null); setPScore(0); setDScore(0); setDone(false) }
  return (
    <div className={css.wrap}>
      <Header title={t('war.title', { rounds })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.you')}: <b>{pScore}</b></span><span>{t('war.dealer')}: <b>{dScore}</b></span><span>{t('war.progress', { n: round, total: rounds })}</span></div>
      <div className={css.row}>
        <div className={css.col}>
          <div className={css.hint}>{t('common.you')}</div>
          <div className={css.huge}>{pCard === null ? '—' : `${pCard.s}${pCard.r}`}</div>
        </div>
        <div className={css.col}>
          <div className={css.hint}>{t('war.dealer')}</div>
          <div className={css.huge}>{dCard === null ? '—' : `${dCard.s}${dCard.r}`}</div>
        </div>
      </div>
      {done ? (
        <>
          <Banner kind={pScore > dScore ? 'win' : pScore < dScore ? 'lose' : 'info'} text={pScore > dScore ? t('war.won') : pScore < dScore ? t('blackjack.dealerWins') : t('common.draw')} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <button type="button" className={css.btn} onClick={play} disabled={done}>{t('war.drawCard')}</button>
      )}
    </div>
  )
}

// ─── Cat Clicker ───────────────────────────────────────────
export interface ClickerIdleProps { emoji: string; name: string }
/** Idle clicker with upgrade threshold. */
export function CatClicker({ emoji, name, onClose, t }: GameProps & ClickerIdleProps) {
  const [count, setCount] = useState(0)
  const [perClick, setPerClick] = useState(1)
  const upgradeCost = 10 + perClick * 5
  const click = (): void => setCount(c => c + perClick)
  const upgrade = (): void => {
    if (count < upgradeCost) return
    setCount(c => c - upgradeCost)
    setPerClick(p => p + 1)
  }
  return (
    <div className={css.wrap}>
      <Header title={name} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('catclick.total')}: <b>{count}</b></span><span>{t('catclick.perClick')}: <b>{perClick}</b></span></div>
      <button type="button" className={css.btn} style={{ fontSize: '48px', padding: '20px' }} onClick={click}>{emoji}</button>
      <button type="button" className={css.btn + ' ' + css.secondary} onClick={upgrade} disabled={count < upgradeCost}>
        {t('catclick.upgrade', { cost: upgradeCost })}
      </button>
      <div className={css.hint}>{t('catclick.hint', { emoji })}</div>
    </div>
  )
}

// Re-exports for catalog convenience.
export {
  WORDS_ANIMALS, WORDS_COUNTRIES, WORDS_FOOD, WORDS_MOVIES, WORDS_TECH, RIDDLES_CLASSIC,
  QUIZ_CODEBASE,
}