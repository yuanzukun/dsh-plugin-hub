/**
 * Mini-game catalog: 100+ game definitions, each binding an engine from
 * `engines-*.tsx` with concrete props. The `id` field doubles as React
 * key and registry dedup identity; `name` is shown in the menu.
 *
 * Catalog grouped by engine family:
 *   1. Clicker / Reaction / Aim       (1-7)
 *   2. Whack / Bubble / Etch / Pixel  (8-15)
 *   3. Number / Math / Trivia         (16-30)
 *   4. Hangman / Scramble / Typing    (31-50)
 *   5. Stroop / Riddle / Coin / Dice  (51-60)
 *   6. Spinner / Color / Slots / Cards(61-75)
 *   7. Strategy: TTT / Memory / Simon (76-85)
 *   8. Lights Out / Slide / Peg       (86-90)
 *   9. Mastermind / 24 / Water / Hanoi(91-100)
 *  10. Connect4 / Knight / Mines      (101-110)
 *  11. Sudoku / Nonogram / 2048       (111-120)
 *  12. NQueens / Pathfind             (121-125)
 *  13. Arcade: Snake/Breakout/etc     (126-145)
 *
 * @module @huanlin/dsh-plugin-d399/client/games/mini/catalog
 */
import type { Game } from '../../registry.ts'
import {
  bind, Clicker, Reaction, Aim, WhackAMole, BubbleWrap, Etch, PixelArt,
  NumberGuess, MathQuiz, Trivia,
  Hangman, WordScramble, Typing, Stroop, Riddle, Coin, Dice, Spinner, ColorPick, Slots,
  Blackjack, HighLow, War, CatClicker,
  WORDS_ANIMALS, WORDS_COUNTRIES, WORDS_FOOD, WORDS_MOVIES, WORDS_TECH, RIDDLES_CLASSIC,
  QUIZ_CODEBASE,
} from './engines-simple.tsx'
import type { GameGroup } from '../../registry.ts'
import {
  TicTacToe, Memory, Simon, LightsOut, SlidePuzzle, Peg, Mastermind,
  TwentyFour, Water, Hanoi, Connect4, Knight, Mines, Sudoku, Nonogram,
  Game2048, NQueens, Pathfind,
} from './engines-strategy.tsx'
import {
  Snake, Breakout, Pong, Flappy, Dodge, Dino, Asteroids, Maze, ColorSeq, Catch,
} from './engines-arcade.tsx'

/** Animal emojis for Memory. */
const EMOJI_ANIMALS = ['🐱', '🐶', '🐰', '🐻', '🐼', '🐨', '🦁', '🐯', '🐸', '🐵', '🦊', '🦉'] as const
/** Food emojis for Memory. */
const EMOJI_FOOD = ['🍎', '🍌', '🍕', '🍔', '🍟', '🌭', '🍿', '🍩', '🍪', '🍫', '🍭', '🥐'] as const
/** Symbol emojis for Memory. */
const EMOJI_SYMBOLS = ['⭐', '🌙', '☀️', '⚡', '🔥', '💧', '❄️', '🌈', '💎', '🎈', '🎁', '🎃'] as const
/** Fruit emojis for Memory. */
const EMOJI_FRUITS = ['🍓', '🍇', '🍊', '🍋', '🍉', '🍒', '🥝', '🍑', '🥭', '🍍', '🥥', '🍈'] as const

/**
 * Water-jug puzzle definitions. Each jug has its own capacity; the target must
 * be measurable (a positive multiple of gcd(caps), no larger than the biggest
 * jug) — guaranteed for every entry here, see tests/mini.spec.ts.
 */
export const WATER_PUZZLES: ReadonlyArray<{ id: string; name: string; caps: readonly number[]; target: number }> = [
  { id: 'water-2-3-1', name: '倒水 3·2 目标1L', caps: [3, 2], target: 1 },
  { id: 'water-3-5-4', name: '倒水 5·3·2 目标4L', caps: [5, 3, 2], target: 4 },
  { id: 'water-3-8-4', name: '倒水 8·5·3 目标4L', caps: [8, 5, 3], target: 4 },
  { id: 'water-4-6-3', name: '倒水 6·5·2·1 目标3L', caps: [6, 5, 2, 1], target: 3 },
]

/**
 * The catalog: a frozen array of Game entries. Each entry's Component is a
 * bound engine (GameProps-only) ready for the registry.
 */
export const MINI_CATALOG: readonly Game[] = Object.freeze([
  // ── 1. Clicker / Reaction / Aim ─────────────────────────
  { id: 'click-10', name: '连点 10', icon: '🖱️', Component: bind(Clicker, { target: 10, label: '次' }) },
  { id: 'click-25', name: '连点 25', icon: '🖱️', Component: bind(Clicker, { target: 25, label: '次' }) },
  { id: 'click-50', name: '连点 50', icon: '🖱️', Component: bind(Clicker, { target: 50, label: '次' }) },
  { id: 'click-100', name: '连点 100', icon: '🖱️', Component: bind(Clicker, { target: 100, label: '次' }) },
  { id: 'reaction-3', name: '反应 3 轮', icon: '⚡', Component: bind(Reaction, { rounds: 3 }) },
  { id: 'reaction-5', name: '反应 5 轮', icon: '⚡', Component: bind(Reaction, { rounds: 5 }) },
  { id: 'aim-15', name: '瞄准 15 靶', icon: '🎯', Component: bind(Aim, { targets: 15 }) },
  { id: 'aim-30', name: '瞄准 30 靶', icon: '🎯', Component: bind(Aim, { targets: 30 }) },

  // ── 2. Whack / Bubble / Etch / Pixel ────────────────────
  { id: 'whack-30', name: '打地鼠 30s', icon: '🐹', Component: bind(WhackAMole, { durationSec: 30 }) },
  { id: 'whack-60', name: '打地鼠 60s', icon: '🐹', Component: bind(WhackAMole, { durationSec: 60 }) },
  { id: 'bubble-4', name: '泡泡 4×4', icon: '🫧', Component: bind(BubbleWrap, { size: 4 }) },
  { id: 'bubble-6', name: '泡泡 6×6', icon: '🫧', Component: bind(BubbleWrap, { size: 6 }) },
  { id: 'bubble-8', name: '泡泡 8×8', icon: '🫧', Component: bind(BubbleWrap, { size: 8 }) },
  { id: 'etch-16', name: '画板 16', icon: '✏️', Component: bind(Etch, { size: 16 }) },
  { id: 'etch-32', name: '画板 32', icon: '✏️', Component: bind(Etch, { size: 32 }) },
  { id: 'pixel-8', name: '像素 8×8', icon: '🎨', Component: bind(PixelArt, { size: 8 }) },
  { id: 'pixel-12', name: '像素 12×12', icon: '🎨', Component: bind(PixelArt, { size: 12 }) },
  { id: 'pixel-16', name: '像素 16×16', icon: '🎨', Component: bind(PixelArt, { size: 16 }) },

  // ── 3. Number / Math / Trivia ───────────────────────────
  { id: 'numguess-1-100', name: '猜数字 1-100', icon: '🔢', Component: bind(NumberGuess, { min: 1, max: 100 }) },
  { id: 'numguess-1-500', name: '猜数字 1-500', icon: '🔢', Component: bind(NumberGuess, { min: 1, max: 500 }) },
  { id: 'numguess-1-1000', name: '猜数字 1-1000', icon: '🔢', Component: bind(NumberGuess, { min: 1, max: 1000 }) },
  { id: 'math-add-10', name: '加法 10 题', icon: '➕', Component: bind(MathQuiz, { op: '+', maxOperand: 20, questions: 10 }) },
  { id: 'math-add-20', name: '加法 20 题', icon: '➕', Component: bind(MathQuiz, { op: '+', maxOperand: 50, questions: 20 }) },
  { id: 'math-sub-10', name: '减法 10 题', icon: '➖', Component: bind(MathQuiz, { op: '-', maxOperand: 50, questions: 10 }) },
  { id: 'math-sub-20', name: '减法 20 题', icon: '➖', Component: bind(MathQuiz, { op: '-', maxOperand: 100, questions: 20 }) },
  { id: 'math-mul-10', name: '乘法 10 题', icon: '✖️', Component: bind(MathQuiz, { op: '*', maxOperand: 9, questions: 10 }) },
  { id: 'math-mul-20', name: '乘法 20 题', icon: '✖️', Component: bind(MathQuiz, { op: '*', maxOperand: 12, questions: 20 }) },
  { id: 'math-div-10', name: '除法 10 题', icon: '➗', Component: bind(MathQuiz, { op: '/', maxOperand: 9, questions: 10 }) },
  { id: 'math-div-20', name: '除法 20 题', icon: '➗', Component: bind(MathQuiz, { op: '/', maxOperand: 12, questions: 20 }) },
  { id: 'trivia-history', name: '历史问答', icon: '📜', Component: bind(Trivia, { category: 'history', questions: 6 }) },
  { id: 'trivia-science', name: '科学问答', icon: '🔬', Component: bind(Trivia, { category: 'science', questions: 6 }) },
  { id: 'trivia-geography', name: '地理问答', icon: '🌍', Component: bind(Trivia, { category: 'geography', questions: 6 }) },
  { id: 'trivia-sports', name: '体育问答', icon: '⚽', Component: bind(Trivia, { category: 'sports', questions: 6 }) },
  { id: 'trivia-movies', name: '电影问答', icon: '🎬', Component: bind(Trivia, { category: 'movies', questions: 6 }) },
  { id: 'trivia-literature', name: '文学问答', icon: '📚', Component: bind(Trivia, { category: 'literature', questions: 6 }) },

  // ── 4. Hangman / Scramble / Typing ──────────────────────
  { id: 'hangman-animals', name: '猜词·动物', icon: '🐾', Component: bind(Hangman, { words: WORDS_ANIMALS, lives: 6 }) },
  { id: 'hangman-countries', name: '猜词·国家', icon: '🗺️', Component: bind(Hangman, { words: WORDS_COUNTRIES, lives: 6 }) },
  { id: 'hangman-food', name: '猜词·食物', icon: '🍔', Component: bind(Hangman, { words: WORDS_FOOD, lives: 6 }) },
  { id: 'hangman-movies', name: '猜词·电影', icon: '🎥', Component: bind(Hangman, { words: WORDS_MOVIES, lives: 5 }) },
  { id: 'hangman-tech', name: '猜词·科技', icon: '💻', Component: bind(Hangman, { words: WORDS_TECH, lives: 6 }) },
  { id: 'hangman-animals-hard', name: '猜词·动物(难)', icon: '🐾', Component: bind(Hangman, { words: WORDS_ANIMALS, lives: 4 }) },
  { id: 'hangman-countries-hard', name: '猜词·国家(难)', icon: '🗺️', Component: bind(Hangman, { words: WORDS_COUNTRIES, lives: 4 }) },
  { id: 'hangman-food-hard', name: '猜词·食物(难)', icon: '🍔', Component: bind(Hangman, { words: WORDS_FOOD, lives: 4 }) },
  { id: 'scramble-animals', name: '重组·动物', icon: '🔤', Component: bind(WordScramble, { words: WORDS_ANIMALS }) },
  { id: 'scramble-countries', name: '重组·国家', icon: '🔤', Component: bind(WordScramble, { words: WORDS_COUNTRIES }) },
  { id: 'scramble-food', name: '重组·食物', icon: '🔤', Component: bind(WordScramble, { words: WORDS_FOOD }) },
  { id: 'scramble-movies', name: '重组·电影', icon: '🔤', Component: bind(WordScramble, { words: WORDS_MOVIES }) },
  { id: 'scramble-tech', name: '重组·科技', icon: '🔤', Component: bind(WordScramble, { words: WORDS_TECH }) },
  { id: 'typing-short-3', name: '打字·短 3 段', icon: '⌨️', Component: bind(Typing, { difficulty: 'short', count: 3 }) },
  { id: 'typing-short-5', name: '打字·短 5 段', icon: '⌨️', Component: bind(Typing, { difficulty: 'short', count: 5 }) },
  { id: 'typing-long-2', name: '打字·长 2 段', icon: '⌨️', Component: bind(Typing, { difficulty: 'long', count: 2 }) },
  { id: 'typing-long-3', name: '打字·长 3 段', icon: '⌨️', Component: bind(Typing, { difficulty: 'long', count: 3 }) },
  { id: 'typing-pangram-3', name: '打字·全字母句 3', icon: '⌨️', Component: bind(Typing, { difficulty: 'pangram', count: 3 }) },
  { id: 'typing-pangram-5', name: '打字·全字母句 5', icon: '⌨️', Component: bind(Typing, { difficulty: 'pangram', count: 5 }) },
  { id: 'stroop-word', name: '斯特鲁普·读字', icon: '🧠', Component: bind(Stroop, { rounds: 10, mode: 'word' }) },
  { id: 'stroop-color', name: '斯特鲁普·说色', icon: '🧠', Component: bind(Stroop, { rounds: 10, mode: 'color' }) },

  // ── 5. Riddle / Coin / Dice ─────────────────────────────
  { id: 'riddles', name: '脑筋急转弯', icon: '🤔', Component: bind(Riddle, { riddles: RIDDLES_CLASSIC }) },
  { id: 'coin-3', name: '硬币 3 连', icon: '🪙', Component: bind(Coin, { streakTarget: 3 }) },
  { id: 'coin-5', name: '硬币 5 连', icon: '🪙', Component: bind(Coin, { streakTarget: 5 }) },
  { id: 'coin-7', name: '硬币 7 连', icon: '🪙', Component: bind(Coin, { streakTarget: 7 }) },
  { id: 'dice-2-20', name: '双骰 20 分', icon: '🎲', Component: bind(Dice, { count: 2, targetSum: 20 }) },
  { id: 'dice-3-30', name: '三骰 30 分', icon: '🎲', Component: bind(Dice, { count: 3, targetSum: 30 }) },
  { id: 'dice-4-50', name: '四骰 50 分', icon: '🎲', Component: bind(Dice, { count: 4, targetSum: 50 }) },
  { id: 'dice-5-80', name: '五骰 80 分', icon: '🎲', Component: bind(Dice, { count: 5, targetSum: 80 }) },
  { id: 'spinner-4', name: '轮盘 4 格', icon: '🎡', Component: bind(Spinner, { segments: 4 }) },
  { id: 'spinner-6', name: '轮盘 6 格', icon: '🎡', Component: bind(Spinner, { segments: 6 }) },
  { id: 'spinner-8', name: '轮盘 8 格', icon: '🎡', Component: bind(Spinner, { segments: 8 }) },
  { id: 'spinner-12', name: '轮盘 12 格', icon: '🎡', Component: bind(Spinner, { segments: 12 }) },

  // ── 6. Color / Slots / Cards ────────────────────────────
  { id: 'color-5', name: '辨色 5 轮', icon: '🌈', Component: bind(ColorPick, { rounds: 5 }) },
  { id: 'color-10', name: '辨色 10 轮', icon: '🌈', Component: bind(ColorPick, { rounds: 10 }) },
  { id: 'slots-fruit', name: '水果机', icon: '🎰', Component: bind(Slots, { symbols: ['🍎', '🍊', '🍇', '🍋', '🍒'], credits: 20 }) },
  { id: 'slots-numbers', name: '数字机', icon: '🎰', Component: bind(Slots, { symbols: ['7', '8', '9', '★', '♦'], credits: 30 }) },
  { id: 'slots-emoji', name: '表情机', icon: '🎰', Component: bind(Slots, { symbols: ['😂', '😎', '🥳', '🤩', '😴'], credits: 25 }) },
  { id: 'blackjack', name: '21点', icon: '🃏', Component: bind(Blackjack, { credits: 20 }) },
  { id: 'highlow', name: '大小猜牌', icon: '🃏', Component: bind(HighLow, { credits: 20 }) },
  { id: 'war-5', name: '战争 5 轮', icon: '⚔️', Component: bind(War, { rounds: 5 }) },
  { id: 'war-10', name: '战争 10 轮', icon: '⚔️', Component: bind(War, { rounds: 10 }) },
  { id: 'cat-clicker', name: '摸猫计数', icon: '🐱', Component: bind(CatClicker, { emoji: '🐱', name: '摸猫计数' }) },
  { id: 'dog-clicker', name: '摸狗计数', icon: '🐶', Component: bind(CatClicker, { emoji: '🐶', name: '摸狗计数' }) },
  { id: 'panda-clicker', name: '摸熊猫计数', icon: '🐼', Component: bind(CatClicker, { emoji: '🐼', name: '摸熊猫计数' }) },
  { id: 'fox-clicker', name: '摸狐狸计数', icon: '🦊', Component: bind(CatClicker, { emoji: '🦊', name: '摸狐狸计数' }) },
  { id: 'frog-clicker', name: '摸青蛙计数', icon: '🐸', Component: bind(CatClicker, { emoji: '🐸', name: '摸青蛙计数' }) },
  { id: 'bear-clicker', name: '摸熊计数', icon: '🐻', Component: bind(CatClicker, { emoji: '🐻', name: '摸熊计数' }) },

  // ── 7. Strategy: TTT / Memory / Simon ───────────────────
  { id: 'ttt-3', name: '井字棋 3×3', icon: '⭕', Component: bind(TicTacToe, { size: 3, winLen: 3, ai: false }) },
  { id: 'ttt-3-ai', name: '井字棋 vs AI', icon: '⭕', Component: bind(TicTacToe, { size: 3, winLen: 3, ai: true }) },
  { id: 'ttt-4', name: '井字棋 4×4', icon: '⭕', Component: bind(TicTacToe, { size: 4, winLen: 4, ai: false }) },
  { id: 'ttt-5', name: '五子 5×5', icon: '⭕', Component: bind(TicTacToe, { size: 5, winLen: 4, ai: false }) },
  { id: 'ttt-6', name: '五子 6×6', icon: '⭕', Component: bind(TicTacToe, { size: 6, winLen: 5, ai: false }) },
  { id: 'memory-animals-6', name: '记忆·动物 6 对', icon: '🃏', Component: bind(Memory, { pairs: 6, emojiSet: EMOJI_ANIMALS }) },
  { id: 'memory-animals-8', name: '记忆·动物 8 对', icon: '🃏', Component: bind(Memory, { pairs: 8, emojiSet: EMOJI_ANIMALS }) },
  { id: 'memory-animals-12', name: '记忆·动物 12 对', icon: '🃏', Component: bind(Memory, { pairs: 12, emojiSet: EMOJI_ANIMALS }) },
  { id: 'memory-food-6', name: '记忆·食物 6 对', icon: '🃏', Component: bind(Memory, { pairs: 6, emojiSet: EMOJI_FOOD }) },
  { id: 'memory-food-8', name: '记忆·食物 8 对', icon: '🃏', Component: bind(Memory, { pairs: 8, emojiSet: EMOJI_FOOD }) },
  { id: 'memory-symbols-6', name: '记忆·符号 6 对', icon: '🃏', Component: bind(Memory, { pairs: 6, emojiSet: EMOJI_SYMBOLS }) },
  { id: 'memory-symbols-8', name: '记忆·符号 8 对', icon: '🃏', Component: bind(Memory, { pairs: 8, emojiSet: EMOJI_SYMBOLS }) },
  { id: 'memory-fruits-8', name: '记忆·水果 8 对', icon: '🃏', Component: bind(Memory, { pairs: 8, emojiSet: EMOJI_FRUITS }) },
  { id: 'memory-fruits-12', name: '记忆·水果 12 对', icon: '🃏', Component: bind(Memory, { pairs: 12, emojiSet: EMOJI_FRUITS }) },
  { id: 'simon-5', name: '西蒙 5 回合', icon: '🎵', Component: bind(Simon, { rounds: 5 }) },
  { id: 'simon-10', name: '西蒙 10 回合', icon: '🎵', Component: bind(Simon, { rounds: 10 }) },
  { id: 'simon-15', name: '西蒙 15 回合', icon: '🎵', Component: bind(Simon, { rounds: 15 }) },
  { id: 'colorseq-3', name: '色序 3', icon: '💡', Component: bind(ColorSeq, { length: 3 }) },
  { id: 'colorseq-5', name: '色序 5', icon: '💡', Component: bind(ColorSeq, { length: 5 }) },
  { id: 'colorseq-8', name: '色序 8', icon: '💡', Component: bind(ColorSeq, { length: 8 }) },

  // ── 8. Lights Out / Slide / Peg ─────────────────────────
  { id: 'lights-3', name: '熄灯 3×3', icon: '💡', Component: bind(LightsOut, { size: 3, scrambleMoves: 3 }) },
  { id: 'lights-4', name: '熄灯 4×4', icon: '💡', Component: bind(LightsOut, { size: 4, scrambleMoves: 5 }) },
  { id: 'lights-5', name: '熄灯 5×5', icon: '💡', Component: bind(LightsOut, { size: 5, scrambleMoves: 8 }) },
  { id: 'slide-3', name: '华容道 3×3', icon: '🔢', Component: bind(SlidePuzzle, { size: 3 }) },
  { id: 'slide-4', name: '华容道 4×4', icon: '🔢', Component: bind(SlidePuzzle, { size: 4 }) },
  { id: 'slide-5', name: '华容道 5×5', icon: '🔢', Component: bind(SlidePuzzle, { size: 5 }) },
  { id: 'peg-5', name: '钻石 5×5', icon: '💎', Component: bind(Peg, { size: 5 }) },
  { id: 'peg-7', name: '钻石 7×7', icon: '💎', Component: bind(Peg, { size: 7 }) },

  // ── 9. Mastermind / 24 / Water / Hanoi ──────────────────
  { id: 'mastermind-3-4', name: '大师码 3位4色', icon: '🧩', Component: bind(Mastermind, { length: 3, colors: 4, guesses: 8 }) },
  { id: 'mastermind-4-4', name: '大师码 4位4色', icon: '🧩', Component: bind(Mastermind, { length: 4, colors: 4, guesses: 8 }) },
  { id: 'mastermind-4-6', name: '大师码 4位6色', icon: '🧩', Component: bind(Mastermind, { length: 4, colors: 6, guesses: 10 }) },
  { id: 'mastermind-5-6', name: '大师码 5位6色', icon: '🧩', Component: bind(Mastermind, { length: 5, colors: 6, guesses: 12 }) },
  { id: '24game-3', name: '算24点 3 题', icon: '🔢', Component: bind(TwentyFour, { rounds: 3 }) },
  { id: '24game-5', name: '算24点 5 题', icon: '🔢', Component: bind(TwentyFour, { rounds: 5 }) },
  { id: '24game-10', name: '算24点 10 题', icon: '🔢', Component: bind(TwentyFour, { rounds: 10 }) },
  ...WATER_PUZZLES.map(p => ({ id: p.id, name: p.name, icon: '🚰', Component: bind(Water, { caps: [...p.caps], target: p.target }) })),
  { id: 'hanoi-3', name: '汉诺塔 3盘', icon: '🗼', Component: bind(Hanoi, { disks: 3 }) },
  { id: 'hanoi-4', name: '汉诺塔 4盘', icon: '🗼', Component: bind(Hanoi, { disks: 4 }) },
  { id: 'hanoi-5', name: '汉诺塔 5盘', icon: '🗼', Component: bind(Hanoi, { disks: 5 }) },
  { id: 'hanoi-6', name: '汉诺塔 6盘', icon: '🗼', Component: bind(Hanoi, { disks: 6 }) },

  // ── 10. Connect4 / Knight / Mines ───────────────────────
  { id: 'connect4-7-6', name: '四连棋 7×6', icon: '🔴', Component: bind(Connect4, { cols: 7, rows: 6, ai: false }) },
  { id: 'connect4-ai', name: '四连棋 vs AI', icon: '🔴', Component: bind(Connect4, { cols: 7, rows: 6, ai: true }) },
  { id: 'connect4-5-5', name: '四连棋 5×5', icon: '🔴', Component: bind(Connect4, { cols: 5, rows: 5, ai: false }) },
  { id: 'connect4-6-5', name: '四连棋 6×5', icon: '🔴', Component: bind(Connect4, { cols: 6, rows: 5, ai: false }) },
  { id: 'knight-5', name: '骑士 5×5', icon: '♞', Component: bind(Knight, { size: 5 }) },
  { id: 'knight-6', name: '骑士 6×6', icon: '♞', Component: bind(Knight, { size: 6 }) },
  { id: 'knight-7', name: '骑士 7×7', icon: '♞', Component: bind(Knight, { size: 7 }) },
  { id: 'knight-8', name: '骑士 8×8', icon: '♞', Component: bind(Knight, { size: 8 }) },
  { id: 'mines-5-3', name: '扫雷 5×5·3', icon: '💣', Component: bind(Mines, { size: 5, mines: 3 }) },
  { id: 'mines-5-5', name: '扫雷 5×5·5', icon: '💣', Component: bind(Mines, { size: 5, mines: 5 }) },
  { id: 'mines-6-6', name: '扫雷 6×6·6', icon: '💣', Component: bind(Mines, { size: 6, mines: 6 }) },
  { id: 'mines-6-8', name: '扫雷 6×6·8', icon: '💣', Component: bind(Mines, { size: 6, mines: 8 }) },
  { id: 'mines-7-8', name: '扫雷 7×7·8', icon: '💣', Component: bind(Mines, { size: 7, mines: 8 }) },
  { id: 'mines-7-10', name: '扫雷 7×7·10', icon: '💣', Component: bind(Mines, { size: 7, mines: 10 }) },
  { id: 'mines-8-10', name: '扫雷 8×8·10', icon: '💣', Component: bind(Mines, { size: 8, mines: 10 }) },
  { id: 'mines-8-15', name: '扫雷 8×8·15', icon: '💣', Component: bind(Mines, { size: 8, mines: 15 }) },

  // ── 11. Sudoku / Nonogram / 2048 ────────────────────────
  { id: 'sudoku-4', name: '数独 4×4', icon: '🔢', Component: bind(Sudoku, { size: 4 }) },
  { id: 'sudoku-6', name: '数独 6×6', icon: '🔢', Component: bind(Sudoku, { size: 6 }) },
  { id: 'nonogram-5', name: '数织 5×5', icon: '🖼️', Component: bind(Nonogram, { size: 5 }) },
  { id: 'nonogram-7', name: '数织 7×7', icon: '🖼️', Component: bind(Nonogram, { size: 7 }) },
  { id: 'nonogram-8', name: '数织 8×8', icon: '🖼️', Component: bind(Nonogram, { size: 8 }) },
  { id: '2048-3-128', name: '2048 目标128', icon: '🔢', Component: bind(Game2048, { size: 3, target: 128 }) },
  { id: '2048-4-256', name: '2048 目标256', icon: '🔢', Component: bind(Game2048, { size: 4, target: 256 }) },
  { id: '2048-4-512', name: '2048 目标512', icon: '🔢', Component: bind(Game2048, { size: 4, target: 512 }) },
  { id: '2048-4-1024', name: '2048 目标1024', icon: '🔢', Component: bind(Game2048, { size: 4, target: 1024 }) },
  { id: '2048-5-2048', name: '2048 目标2048', icon: '🔢', Component: bind(Game2048, { size: 5, target: 2048 }) },
  { id: 'nqueens-4', name: '4皇后', icon: '♛', Component: bind(NQueens, { size: 4 }) },
  { id: 'nqueens-5', name: '5皇后', icon: '♛', Component: bind(NQueens, { size: 5 }) },
  { id: 'nqueens-6', name: '6皇后', icon: '♛', Component: bind(NQueens, { size: 6 }) },
  { id: 'nqueens-7', name: '7皇后', icon: '♛', Component: bind(NQueens, { size: 7 }) },
  { id: 'nqueens-8', name: '8皇后', icon: '♛', Component: bind(NQueens, { size: 8 }) },
  { id: 'pathfind-4-16', name: '寻路 4×4·16', icon: '🛤️', Component: bind(Pathfind, { size: 4, length: 16 }) },
  { id: 'pathfind-5-25', name: '寻路 5×5·25', icon: '🛤️', Component: bind(Pathfind, { size: 5, length: 25 }) },
  { id: 'pathfind-6-36', name: '寻路 6×6·36', icon: '🛤️', Component: bind(Pathfind, { size: 6, length: 36 }) },
  { id: 'pathfind-7-49', name: '寻路 7×7·49', icon: '🛤️', Component: bind(Pathfind, { size: 7, length: 49 }) },

  // ── 12. Arcade ──────────────────────────────────────────
  { id: 'snake-10', name: '贪吃蛇 10×10', icon: '🐍', Component: bind(Snake, { size: 10, speedMs: 200 }) },
  { id: 'snake-12', name: '贪吃蛇 12×12', icon: '🐍', Component: bind(Snake, { size: 12, speedMs: 180 }) },
  { id: 'snake-15', name: '贪吃蛇 15×15', icon: '🐍', Component: bind(Snake, { size: 15, speedMs: 160 }) },
  { id: 'snake-15-fast', name: '贪吃蛇 15·快', icon: '🐍', Component: bind(Snake, { size: 15, speedMs: 100 }) },
  { id: 'snake-20', name: '贪吃蛇 20×20', icon: '🐍', Component: bind(Snake, { size: 20, speedMs: 140 }) },
  { id: 'breakout-easy', name: '打砖块·易', icon: '🧱', Component: bind(Breakout, { rows: 3, cols: 6, lives: 5 }) },
  { id: 'breakout-med', name: '打砖块·中', icon: '🧱', Component: bind(Breakout, { rows: 4, cols: 8, lives: 3 }) },
  { id: 'breakout-hard', name: '打砖块·难', icon: '🧱', Component: bind(Breakout, { rows: 5, cols: 10, lives: 2 }) },
  { id: 'pong-slow', name: '弹球·慢', icon: '🏓', Component: bind(Pong, { speedMs: 30 }) },
  { id: 'pong-fast', name: '弹球·快', icon: '🏓', Component: bind(Pong, { speedMs: 16 }) },
  { id: 'flappy-easy', name: '飞翔·易', icon: '🐤', Component: bind(Flappy, { gap: 120, speed: 2 }) },
  { id: 'flappy-med', name: '飞翔·中', icon: '🐤', Component: bind(Flappy, { gap: 90, speed: 3 }) },
  { id: 'flappy-hard', name: '飞翔·难', icon: '🐤', Component: bind(Flappy, { gap: 70, speed: 4 }) },
  { id: 'dodge-5', name: '闪避 5×5', icon: '⬇️', Component: bind(Dodge, { size: 5, obstacles: 1, speedMs: 500 }) },
  { id: 'dodge-7', name: '闪避 7×7', icon: '⬇️', Component: bind(Dodge, { size: 7, obstacles: 2, speedMs: 400 }) },
  { id: 'dodge-9', name: '闪避 9×9', icon: '⬇️', Component: bind(Dodge, { size: 9, obstacles: 3, speedMs: 300 }) },
  { id: 'dino-slow', name: '恐龙·慢', icon: '🦖', Component: bind(Dino, { speed: 3 }) },
  { id: 'dino-med', name: '恐龙·中', icon: '🦖', Component: bind(Dino, { speed: 5 }) },
  { id: 'dino-fast', name: '恐龙·快', icon: '🦖', Component: bind(Dino, { speed: 7 }) },
  { id: 'asteroids-3', name: '陨石·3 颗', icon: '☄️', Component: bind(Asteroids, { count: 3 }) },
  { id: 'asteroids-5', name: '陨石·5 颗', icon: '☄️', Component: bind(Asteroids, { count: 5 }) },
  { id: 'asteroids-8', name: '陨石·8 颗', icon: '☄️', Component: bind(Asteroids, { count: 8 }) },
  { id: 'maze-5', name: '迷宫 5×5', icon: '🌀', Component: bind(Maze, { size: 5 }) },
  { id: 'maze-8', name: '迷宫 8×8', icon: '🌀', Component: bind(Maze, { size: 8 }) },
  { id: 'maze-10', name: '迷宫 10×10', icon: '🌀', Component: bind(Maze, { size: 10 }) },
  { id: 'maze-12', name: '迷宫 12×12', icon: '🌀', Component: bind(Maze, { size: 12 }) },
  { id: 'catch-5', name: '接物品 5×5', icon: '🧺', Component: bind(Catch, { size: 5, good: '⭐', bad: '💣', durationSec: 30 }) },
  { id: 'catch-7', name: '接物品 7×7', icon: '🧺', Component: bind(Catch, { size: 7, good: '🍎', bad: '🍂', durationSec: 45 }) },
  { id: 'catch-9', name: '接物品 9×9', icon: '🧺', Component: bind(Catch, { size: 9, good: '🪙', bad: '💀', durationSec: 60 }) },

  // ── 13. Codebase quiz ────────────────────────────────────
  { id: 'codebase-trivia', name: '代码库选择题', icon: '🧑‍💻', Component: bind(Trivia, { category: 'codebase', questions: 10 }) },
  { id: 'codebase-fillblank', name: '代码库填空题', icon: '✍️', Component: bind(Riddle, { riddles: QUIZ_CODEBASE, title: '代码库填空' }) },
] satisfies Game[])

/** One prefix/suffix rule mapping catalog ids to a foldable menu group. */
export interface GroupRule {
  /** Match games whose id starts with this string. */
  prefix?: string
  /** Match games whose id ends with this string. */
  suffix?: string
  /** The foldable group these games collapse into. */
  group: GameGroup
}

/**
 * Fold rules: same-family variants collapse into one menu group.
 * Order matters — the FIRST matching rule wins, so longer/specific
 * prefixes (e.g. `colorseq-` before `color-`) must come first.
 * Games matching no rule render as standalone entries.
 */
export const GROUP_RULES: readonly GroupRule[] = Object.freeze([
  { prefix: 'click-', group: { id: 'grp-click', name: '连点', icon: '🖱️' } },
  { prefix: 'reaction-', group: { id: 'grp-reaction', name: '反应测试', icon: '⚡' } },
  { prefix: 'aim-', group: { id: 'grp-aim', name: '瞄准训练', icon: '🎯' } },
  { prefix: 'whack-', group: { id: 'grp-whack', name: '打地鼠', icon: '🐹' } },
  { prefix: 'bubble-', group: { id: 'grp-bubble', name: '泡泡纸', icon: '🫧' } },
  { prefix: 'etch-', group: { id: 'grp-etch', name: '画板', icon: '✏️' } },
  { prefix: 'pixel-', group: { id: 'grp-pixel', name: '像素画', icon: '🎨' } },
  { prefix: 'numguess-', group: { id: 'grp-numguess', name: '猜数字', icon: '🔢' } },
  { prefix: 'math-', group: { id: 'grp-math', name: '数学测验', icon: '➗' } },
  { prefix: 'trivia-', group: { id: 'grp-trivia', name: '知识问答', icon: '📚' } },
  { prefix: 'hangman-', group: { id: 'grp-hangman', name: '猜单词', icon: '🕵️' } },
  { prefix: 'scramble-', group: { id: 'grp-scramble', name: '字母重组', icon: '🔤' } },
  { prefix: 'typing-', group: { id: 'grp-typing', name: '打字测试', icon: '⌨️' } },
  { prefix: 'stroop-', group: { id: 'grp-stroop', name: '斯特鲁普', icon: '🧠' } },
  { prefix: 'coin-', group: { id: 'grp-coin', name: '硬币连胜', icon: '🪙' } },
  { prefix: 'dice-', group: { id: 'grp-dice', name: '骰子', icon: '🎲' } },
  { prefix: 'spinner-', group: { id: 'grp-spinner', name: '轮盘', icon: '🎡' } },
  { prefix: 'colorseq-', group: { id: 'grp-colorseq', name: '色序记忆', icon: '💡' } },
  { prefix: 'color-', group: { id: 'grp-colorpick', name: '辨色', icon: '🌈' } },
  { prefix: 'slots-', group: { id: 'grp-slots', name: '老虎机', icon: '🎰' } },
  { prefix: 'war-', group: { id: 'grp-war', name: '战争卡牌', icon: '⚔️' } },
  { suffix: '-clicker', group: { id: 'grp-clicker', name: '摸宠物', icon: '🐾' } },
  { prefix: 'riddles', group: { id: 'grp-riddles', name: '脑筋急转弯', icon: '🤔' } },
  { prefix: 'blackjack', group: { id: 'grp-blackjack', name: '21点', icon: '🃏' } },
  { prefix: 'highlow', group: { id: 'grp-highlow', name: '大小猜牌', icon: '🃏' } },
  { prefix: 'ttt-', group: { id: 'grp-ttt', name: '井字棋', icon: '⭕' } },
  { prefix: 'memory-', group: { id: 'grp-memory', name: '记忆翻牌', icon: '🃏' } },
  { prefix: 'simon-', group: { id: 'grp-simon', name: '西蒙', icon: '🎵' } },
  { prefix: 'lights-', group: { id: 'grp-lights', name: '熄灯', icon: '💡' } },
  { prefix: 'slide-', group: { id: 'grp-slide', name: '华容道', icon: '🔢' } },
  { prefix: 'peg-', group: { id: 'grp-peg', name: '独立钻石', icon: '💎' } },
  { prefix: 'mastermind-', group: { id: 'grp-mastermind', name: '大师码', icon: '🧩' } },
  { prefix: '24game-', group: { id: 'grp-24', name: '算24点', icon: '🔢' } },
  { prefix: 'water-', group: { id: 'grp-water', name: '倒水', icon: '🚰' } },
  { prefix: 'hanoi-', group: { id: 'grp-hanoi', name: '汉诺塔', icon: '🗼' } },
  { prefix: 'connect4-', group: { id: 'grp-connect4', name: '四连棋', icon: '🔴' } },
  { prefix: 'knight-', group: { id: 'grp-knight', name: '骑士巡游', icon: '♞' } },
  { prefix: 'mines-', group: { id: 'grp-mines', name: '扫雷', icon: '💣' } },
  { prefix: 'sudoku-', group: { id: 'grp-sudoku', name: '数独', icon: '🔢' } },
  { prefix: 'nonogram-', group: { id: 'grp-nonogram', name: '数织', icon: '🖼️' } },
  { prefix: '2048-', group: { id: 'grp-2048', name: '2048', icon: '🔢' } },
  { prefix: 'nqueens-', group: { id: 'grp-nqueens', name: 'N皇后', icon: '♛' } },
  { prefix: 'pathfind-', group: { id: 'grp-pathfind', name: '寻路', icon: '🛤️' } },
  { prefix: 'snake-', group: { id: 'grp-snake', name: '贪吃蛇', icon: '🐍' } },
  { prefix: 'breakout-', group: { id: 'grp-breakout', name: '打砖块', icon: '🧱' } },
  { prefix: 'pong-', group: { id: 'grp-pong', name: '弹球', icon: '🏓' } },
  { prefix: 'flappy-', group: { id: 'grp-flappy', name: '飞翔小鸟', icon: '🐤' } },
  { prefix: 'dodge-', group: { id: 'grp-dodge', name: '闪避', icon: '⬇️' } },
  { prefix: 'dino-', group: { id: 'grp-dino', name: '恐龙跑酷', icon: '🦖' } },
  { prefix: 'asteroids-', group: { id: 'grp-asteroids', name: '陨石躲避', icon: '☄️' } },
  { prefix: 'maze-', group: { id: 'grp-maze', name: '迷宫', icon: '🌀' } },
  { prefix: 'catch-', group: { id: 'grp-catch', name: '接物品', icon: '🧺' } },
  { prefix: 'codebase-', group: { id: 'grp-codebase', name: '代码库问答', icon: '🧑‍💻' } },
])

/** Resolve the fold group for a catalog id (first matching rule, or null). */
export function applyGroupRule(id: string): GameGroup | null {
  for (const rule of GROUP_RULES) {
    if (rule.prefix !== undefined && id.startsWith(rule.prefix)) return rule.group
    if (rule.suffix !== undefined && id.endsWith(rule.suffix)) return rule.group
  }
  return null
}
