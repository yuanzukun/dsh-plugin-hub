/**
 * Strategy/puzzle mini-game engines — sliding tiles, peg solitaire, lights
 * out, water-pouring, 24-game, knight's tour, mastermind, simon, etc.
 *
 * All user-visible copy runs through the `t` prop (`ctx.locale.bind(NS)`).
 *
 * @module @huanlin/dsh-plugin-d399/client/games/mini/engines-strategy
 */
import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from 'react'
import type { GameProps } from '../types.ts'
import type { Translate } from '../../locales.ts'
import css from './mini.module.css'
import {
  PALETTE,
  canSolveWater,
  pick,
  randInt,
  range,
  shuffle,
  solve24,
} from './shared.ts'

function Header({ title, onClose, t, children }: { title: string; onClose: () => void; t: Translate; children?: React.ReactNode }) {
  return (
    <div className={css.header}>
      <h2 className={css.title}>{title}</h2>
      {children}
      <button type="button" className={css.closeBtn} onClick={onClose} aria-label={t('common.close')}>✕</button>
    </div>
  )
}

function Banner({ kind, text }: { kind: 'win' | 'lose' | 'info'; text: string }) {
  return <div className={`${css.banner} ${css[kind]}`}>{text}</div>
}

// ─── Tic-Tac-Toe ───────────────────────────────────────────
export interface TicTacToeProps { size: number; winLen: number; ai: boolean }
/** Tic-tac-toe on NxN board; first to winLen in a row wins. */
export function TicTacToe({ size, winLen, ai, onClose, t }: GameProps & TicTacToeProps) {
  type Cell = 'X' | 'O' | null
  const [board, setBoard] = useState<Cell[]>(() => Array(size * size).fill(null))
  const [turn, setTurn] = useState<'X' | 'O'>('X')
  const [winner, setWinner] = useState<Cell | 'draw'>(null)

  const checkWin = (b: Cell[], lastIdx: number): Cell | 'draw' | null => {
    const v = b[lastIdx]
    if (v === null || v === undefined) return null
    const r = Math.floor(lastIdx / size); const c = lastIdx % size
    const dirs: ReadonlyArray<[number, number]> = [[0, 1], [1, 0], [1, 1], [1, -1]]
    for (const [dr, dc] of dirs) {
      let cnt = 1
      for (let i = 1; i < winLen; i++) {
        const nr = r + dr * i; const nc = c + dc * i
        if (nr < 0 || nr >= size || nc < 0 || nc >= size) break
        if (b[nr * size + nc] !== v) break
        cnt++
      }
      for (let i = 1; i < winLen; i++) {
        const nr = r - dr * i; const nc = c - dc * i
        if (nr < 0 || nr >= size || nc < 0 || nc >= size) break
        if (b[nr * size + nc] !== v) break
        cnt++
      }
      if (cnt >= winLen) return v
    }
    if (b.every(x => x !== null)) return 'draw'
    return null
  }

  const place = (i: number, mark: 'X' | 'O'): boolean => {
    if (board[i] !== null || winner !== null) return false
    const next = [...board]; next[i] = mark
    setBoard(next)
    const w = checkWin(next, i)
    if (w !== null) { setWinner(w); return true }
    setTurn(mark === 'X' ? 'O' : 'X')
    return true
  }

  // Simple AI: random valid move (good enough for variety).
  useEffect(() => {
    if (ai && turn === 'O' && winner === null) {
      const empties = board.map((v, i) => v === null ? i : -1).filter(i => i >= 0)
      if (empties.length > 0) {
        const to = window.setTimeout(() => place(pick(empties), 'O'), 400)
        return () => window.clearTimeout(to)
      }
    }
    return undefined
  }, [ai, turn, winner, board])

  const click = (i: number): void => {
    if (ai && turn === 'O') return
    place(i, 'X')
  }

  const reset = (): void => {
    setBoard(Array(size * size).fill(null)); setTurn('X'); setWinner(null)
  }

  return (
    <div className={css.wrap}>
      <Header title={t('ttt.title', { size })} onClose={onClose} t={t} />
      <div className={css.stats}>
        <span>{winner === null ? t('ttt.turn', { turn }) : winner === 'draw' ? t('common.draw') : t('ttt.winner', { winner })}</span>
      </div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: 'min(240px, 70vw)' }}>
        {board.map((v, i) => (
          <button
            key={i}
            type="button"
            className={`${css.cell} ${v === 'X' ? css.x : v === 'O' ? css.o : ''}`}
            onClick={() => click(i)}
            disabled={v !== null || winner !== null || (ai && turn === 'O')}
          >
            {v ?? ''}
          </button>
        ))}
      </div>
      {winner !== null && <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>}
      <div className={css.hint}>{ai ? t('ttt.hintAi') : t('ttt.hintPvp')} · {t('ttt.winLen', { n: winLen })}</div>
    </div>
  )
}

// ─── Memory / Concentration ────────────────────────────────
export interface MemoryProps { pairs: number; emojiSet: readonly string[] }
/** Memory match: find N pairs. */
export function Memory({ pairs, emojiSet, onClose, t }: GameProps & MemoryProps) {
  const [deck, setDeck] = useState<ReadonlyArray<string>>(() => {
    const chosen = shuffle([...emojiSet]).slice(0, pairs)
    return shuffle([...chosen, ...chosen])
  })
  const [flipped, setFlipped] = useState<number[]>([])
  const [matched, setMatched] = useState<Set<number>>(() => new Set())
  const [moves, setMoves] = useState(0)
  const won = matched.size === deck.length

  const flip = (i: number): void => {
    if (matched.has(i)) return
    if (flipped.length === 2) return
    if (flipped.includes(i)) return
    const next = [...flipped, i]
    setFlipped(next)
    if (next.length === 2) {
      setMoves(m => m + 1)
      const a = next[0]!
      const b = next[1]!
      if (deck[a] === deck[b]) {
        const nm = new Set(matched); nm.add(a); nm.add(b)
        setMatched(nm)
        setFlipped([])
      } else {
        window.setTimeout(() => setFlipped([]), 800)
      }
    }
  }

  const reset = (): void => {
    const chosen = shuffle([...emojiSet]).slice(0, pairs)
    setDeck(shuffle([...chosen, ...chosen]))
    setFlipped([]); setMatched(new Set()); setMoves(0)
  }

  const cols = Math.ceil(Math.sqrt(deck.length))

  return (
    <div className={css.wrap}>
      <Header title={t('memory.title', { pairs })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.moves')}: <b>{moves}</b></span><span>{t('memory.matchedLabel')}: <b>{matched.size / 2}</b>/{pairs}</span></div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${cols}, 1fr)`, width: 'min(320px, 80vw)' }}>
        {deck.map((emoji, i) => {
          const shown = flipped.includes(i) || matched.has(i)
          return (
            <button
              key={i}
              type="button"
              className={`${css.cell} ${shown ? css.on : ''}`}
              onClick={() => flip(i)}
              style={{ fontSize: '20px' }}
            >
              {shown ? emoji : '?'}
            </button>
          )
        })}
      </div>
      {won && (
        <>
          <Banner kind="win" text={t('memory.done', { n: moves })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      )}
    </div>
  )
}

// ─── Simon ─────────────────────────────────────────────────
export interface SimonProps { rounds: number }
/** Simon memory sequence game. */
export function Simon({ rounds, onClose, t }: GameProps & SimonProps) {
  const COLORS: ReadonlyArray<{ id: number; color: string; tone: string }> = [
    { id: 0, color: '#e74c3c', tone: '329.63' },
    { id: 1, color: '#2ecc71', tone: '261.63' },
    { id: 2, color: '#3498db', tone: '392.00' },
    { id: 3, color: '#f1c40f', tone: '440.00' },
  ]
  const [seq, setSeq] = useState<number[]>([])
  const [userIdx, setUserIdx] = useState(0)
  const [active, setActive] = useState<number | null>(null)
  const [playing, setPlaying] = useState(false)
  const [done, setDone] = useState<'win' | 'lose' | null>(null)
  const [started, setStarted] = useState(false)

  const playSequence = useCallback(async (s: number[]): Promise<void> => {
    setPlaying(true)
    for (const id of s) {
      await new Promise<void>(r => window.setTimeout(r, 350))
      setActive(id)
      await new Promise<void>(r => window.setTimeout(r, 500))
      setActive(null)
    }
    setPlaying(false)
  }, [])

  const next = useCallback(async (): Promise<void> => {
    const s = [...seq, randInt(0, 3)]
    setSeq(s); setUserIdx(0)
    await playSequence(s)
  }, [seq, playSequence])

  const start = useCallback(async (): Promise<void> => {
    setStarted(true); setDone(null); setSeq([])
    const s = [randInt(0, 3)]
    setSeq(s); setUserIdx(0)
    await playSequence(s)
  }, [playSequence])

  const tap = (id: number): void => {
    if (playing || done !== null) return
    setActive(id)
    window.setTimeout(() => setActive(null), 200)
    if (seq[userIdx] !== id) {
      setDone('lose')
      return
    }
    const nextIdx = userIdx + 1
    if (nextIdx >= seq.length) {
      if (seq.length >= rounds) {
        setDone('win')
      } else {
        window.setTimeout(() => { void next() }, 600)
      }
    } else {
      setUserIdx(nextIdx)
    }
  }

  return (
    <div className={css.wrap}>
      <Header title={t('simon.title')} onClose={onClose} t={t} />
      <div className={css.stats}>
        <span>{t('simon.roundsLabel')}: <b>{seq.length}</b>/{rounds}</span>
      </div>
      <div className={css.canvasWrap}>
        <div style={{ width: 'min(280px, 75vw)', aspectRatio: '1', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px' }}>
          {COLORS.map(c => (
            <button
              key={c.id}
              type="button"
              onClick={() => tap(c.id)}
              disabled={playing || done !== null || !started}
              style={{
                background: c.color,
                opacity: active === c.id ? 1 : 0.45,
                border: 'none', borderRadius: '8px', cursor: 'pointer', transition: 'opacity 0.1s ease',
              }}
              aria-label={`simon ${c.id}`}
            />
          ))}
        </div>
      </div>
      {done === 'win' && <Banner kind="win" text={t('simon.won', { n: rounds })} />}
      {done === 'lose' && <Banner kind="lose" text={t('simon.lost', { n: seq.length })} />}
      {(done !== null || !started) && <button type="button" className={css.btn} onClick={() => void start()}>{started ? t('common.replay') : t('common.start')}</button>}
      {started && done === null && <div className={css.hint}>{playing ? t('simon.memorize') : t('simon.tap')}</div>}
    </div>
  )
}

// ─── Lights Out ────────────────────────────────────────────
export interface LightsOutProps { size: number; scrambleMoves: number }
/** Lights Out puzzle: toggle cells to turn all off. */
export function LightsOut({ size, scrambleMoves, onClose, t }: GameProps & LightsOutProps) {
  const total = size * size
  const make = (): boolean[] => {
    const b = new Array(total).fill(false)
    for (let i = 0; i < scrambleMoves; i++) {
      const idx = randInt(0, total - 1)
      applyToggle(b, idx)
    }
    return b
  }
  function applyToggle(b: boolean[], idx: number): void {
    const r = Math.floor(idx / size); const c = idx % size
    const toggle = (rr: number, cc: number): void => {
      if (rr < 0 || rr >= size || cc < 0 || cc >= size) return
      b[rr * size + cc] = !b[rr * size + cc]
    }
    toggle(r, c); toggle(r - 1, c); toggle(r + 1, c); toggle(r, c - 1); toggle(r, c + 1)
  }
  const [board, setBoard] = useState<boolean[]>(make)
  const [moves, setMoves] = useState(0)
  const won = board.every(v => !v)

  const click = (i: number): void => {
    if (won) return
    const next = [...board]
    applyToggle(next, i)
    setBoard(next); setMoves(m => m + 1)
  }
  const reset = (): void => { setBoard(make()); setMoves(0) }

  return (
    <div className={css.wrap}>
      <Header title={t('lights.title', { size })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.moves')}: <b>{moves}</b></span></div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: 'min(280px, 75vw)' }}>
        {board.map((on, i) => (
          <button
            key={i}
            type="button"
            className={`${css.cell} ${on ? css.on : css.off}`}
            onClick={() => click(i)}
            disabled={won}
          />
        ))}
      </div>
      {won ? (
        <>
          <Banner kind="win" text={t('common.doneMoves', { n: moves })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
      )}
    </div>
  )
}

// ─── 15-Puzzle (Sliding) ───────────────────────────────────
export interface SlidePuzzleProps { size: number }
/** NxN sliding puzzle. */
export function SlidePuzzle({ size, onClose, t }: GameProps & SlidePuzzleProps) {
  const total = size * size
  const make = (): number[] => {
    const arr = range(total - 1).map(i => i + 1)
    arr.push(0)
    for (let i = 0; i < 200; i++) {
      const zero = arr.indexOf(0)
      const r = Math.floor(zero / size); const c = zero % size
      const moves: number[] = []
      if (r > 0) moves.push(zero - size)
      if (r < size - 1) moves.push(zero + size)
      if (c > 0) moves.push(zero - 1)
      if (c < size - 1) moves.push(zero + 1)
      const sw = pick(moves)
      const tmp = arr[zero]!; arr[zero] = arr[sw]!; arr[sw] = tmp
    }
    return arr
  }
  const [board, setBoard] = useState<number[]>(make)
  const [moves, setMoves] = useState(0)
  const won = board.every((v, i) => (i === total - 1 ? v === 0 : v === i + 1))

  const click = (i: number): void => {
    if (won) return
    const zero = board.indexOf(0)
    const r = Math.floor(i / size); const c = i % size
    const zr = Math.floor(zero / size); const zc = zero % size
    if (Math.abs(r - zr) + Math.abs(c - zc) !== 1) return
    const next = [...board]
    next[zero] = next[i]!; next[i] = 0
    setBoard(next); setMoves(m => m + 1)
  }
  const reset = (): void => { setBoard(make()); setMoves(0) }

  return (
    <div className={css.wrap}>
      <Header title={t('slide.title', { size })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.moves')}: <b>{moves}</b></span></div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: 'min(280px, 75vw)' }}>
        {board.map((v, i) => (
          <button
            key={i}
            type="button"
            className={`${css.cell} ${v === 0 ? css.empty : ''}`}
            onClick={() => click(i)}
            disabled={v === 0}
          >
            {v === 0 ? '' : v}
          </button>
        ))}
      </div>
      {won ? (
        <>
          <Banner kind="win" text={t('common.doneMoves', { n: moves })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
      )}
    </div>
  )
}

// ─── Peg Solitaire ─────────────────────────────────────────
export interface PegProps { size: number }
/** Cross peg solitaire (simplified to NxN with hole in middle). */
export function Peg({ size, onClose, t }: GameProps & PegProps) {
  type Cell = 'peg' | 'hole' | 'out'
  const make = (): Cell[] => {
    const b: Cell[] = new Array(size * size).fill('peg')
    const mid = Math.floor(size / 2)
    b[mid * size + mid] = 'hole'
    return b
  }
  const [board, setBoard] = useState<Cell[]>(make)
  const [sel, setSel] = useState<number | null>(null)
  const pegCount = board.filter(c => c === 'peg').length
  const won = pegCount === 1

  const adjacentHole = (from: number, dir: [number, number]): { jump: number; land: number } | null => {
    const r = Math.floor(from / size); const c = from % size
    const mid_r = r + dir[0]; const mid_c = c + dir[1]
    const end_r = r + 2 * dir[0]; const end_c = c + 2 * dir[1]
    if (mid_r < 0 || mid_r >= size || mid_c < 0 || mid_c >= size) return null
    if (end_r < 0 || end_r >= size || end_c < 0 || end_c >= size) return null
    const mid = mid_r * size + mid_c
    const end = end_r * size + end_c
    if (board[mid] !== 'peg' || board[end] !== 'hole') return null
    return { jump: mid, land: end }
  }

  const click = (i: number): void => {
    if (won) return
    if (board[i] !== 'peg') return
    if (sel === null) { setSel(i); return }
    if (sel === i) { setSel(null); return }
    // try jump
    const dirs: ReadonlyArray<[number, number]> = [[-1, 0], [1, 0], [0, -1], [0, 1]]
    for (const d of dirs) {
      const res = adjacentHole(sel, d)
      if (res !== null && res.land === i) {
        const next = [...board]
        next[sel] = 'hole'; next[res.jump] = 'hole'; next[i] = 'peg'
        setBoard(next); setSel(null); return
      }
    }
    setSel(i)
  }

  const reset = (): void => { setBoard(make()); setSel(null) }

  return (
    <div className={css.wrap}>
      <Header title={t('peg.title', { size })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.remaining')}: <b>{pegCount}</b></span></div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: 'min(280px, 75vw)' }}>
        {board.map((c, i) => (
          <button
            key={i}
            type="button"
            className={`${css.cell} ${sel === i ? css.flag : ''}`}
            onClick={() => click(i)}
            style={c === 'peg' ? { background: '#4a9eff' } : c === 'hole' ? { background: '#1a1d24' } : { background: 'transparent', border: 'none', cursor: 'default' }}
          >
            {c === 'peg' ? '●' : ''}
          </button>
        ))}
      </div>
      {won ? (
        <>
          <Banner kind="win" text={t('peg.perfect')} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
      )}
      <div className={css.hint}>{t('peg.hint')}</div>
    </div>
  )
}

// ─── Mastermind ────────────────────────────────────────────
export interface MastermindProps { length: number; colors: number; guesses: number }
/** Mastermind codebreaker. */
export function Mastermind({ length, colors, guesses, onClose, t }: GameProps & MastermindProps) {
  const [answer, setAnswer] = useState<number[]>(() => Array.from({ length }, () => randInt(0, colors - 1)))
  const [history, setHistory] = useState<ReadonlyArray<{ guess: number[]; black: number; white: number }>>([])
  const [current, setCurrent] = useState<number[]>(() => new Array(length).fill(-1))
  const [done, setDone] = useState<'win' | 'lose' | null>(null)

  const evaluate = (guess: number[]): { black: number; white: number } => {
    let black = 0; let white = 0
    const aPool = new Map<number, number>()
    const gPool = new Map<number, number>()
    for (let i = 0; i < length; i++) {
      if (guess[i] === answer[i]) black++
      else {
        aPool.set(answer[i]!, (aPool.get(answer[i]!) ?? 0) + 1)
        gPool.set(guess[i]!, (gPool.get(guess[i]!) ?? 0) + 1)
      }
    }
    for (const [k, v] of gPool) {
      const av = aPool.get(k) ?? 0
      white += Math.min(v, av)
    }
    return { black, white }
  }

  const setColor = (i: number, c: number): void => {
    if (done !== null) return
    const next = [...current]; next[i] = c; setCurrent(next)
  }
  const submit = (): void => {
    if (current.some(c => c === -1)) return
    const r = evaluate(current)
    const next = [...history, { guess: [...current], ...r }]
    setHistory(next)
    if (r.black === length) { setDone('win'); return }
    if (next.length >= guesses) { setDone('lose'); return }
    setCurrent(new Array(length).fill(-1))
  }
  const reset = (): void => {
    setAnswer(Array.from({ length }, () => randInt(0, colors - 1)))
    setHistory([]); setCurrent(new Array(length).fill(-1)); setDone(null)
  }

  return (
    <div className={css.wrap}>
      <Header title={t('mastermind.title', { length, colors })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('numguess.guessed')}: <b>{history.length}</b>/{guesses}</span></div>
      {history.map((h, i) => (
        <div key={i} className={css.row} style={{ justifyContent: 'space-between', padding: '4px 8px', background: '#1a1d24', borderRadius: '6px' }}>
          <div className={css.row} style={{ gap: '4px' }}>
            {h.guess.map((c, j) => (
              <span key={j} style={{ width: '20px', height: '20px', borderRadius: '50%', background: PALETTE[c] }} />
            ))}
          </div>
          <span style={{ fontSize: '11px' }}>{t('mastermind.hintRow', { black: h.black, white: h.white })}</span>
        </div>
      ))}
      {done === null && (
        <>
          <div className={css.row} style={{ gap: '6px' }}>
            {current.map((c, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setColor(i, (c + 1) % colors)}
                style={{ width: '32px', height: '32px', borderRadius: '6px', background: c === -1 ? '#1a1d24' : PALETTE[c], border: '1px solid #2a2d36', cursor: 'pointer' }}
              />
            ))}
          </div>
          <div className={css.hint}>{t('mastermind.clickColor')}</div>
          <div className={css.row}>
            <button type="button" className={css.btn} onClick={submit} disabled={current.some(c => c === -1)}>{t('common.submit')}</button>
          </div>
        </>
      )}
      {done === 'win' && <Banner kind="win" text={t('mastermind.won', { n: history.length })} />}
      {done === 'lose' && <Banner kind="lose" text={t('mastermind.lost', { answer: answer.join(' ') })} />}
      {done !== null && <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>}
      <div className={css.hint}>{t('mastermind.legend')}</div>
    </div>
  )
}

// ─── 24-Game ───────────────────────────────────────────────
export interface TwentyFourProps { rounds: number }
/** Make 24 from 4 numbers using +, -, *, /. */
export function TwentyFour({ rounds, onClose, t }: GameProps & TwentyFourProps) {
  const makeNums = (): number[] => {
    for (let i = 0; i < 100; i++) {
      const nums = Array.from({ length: 4 }, () => randInt(1, 13))
      if (solve24(nums)) return nums
    }
    return [3, 3, 8, 8]
  }
  const [round, setRound] = useState(0)
  const [nums, setNums] = useState<number[]>(makeNums)
  const [input, setInput] = useState('')
  const [correct, setCorrect] = useState(0)
  const [revealed, setRevealed] = useState(false)
  const [done, setDone] = useState(false)

  const submit = (): void => {
    let v: number
    try {
      const replaced = input.replace(/×/g, '*').replace(/÷/g, '/')
      const fn = new Function(`return (${replaced})`) as () => number
      v = fn()
    } catch {
      setInput('')
      return
    }
    if (Math.abs(v - 24) < 1e-6) {
      setCorrect(c => c + 1)
      setRevealed(true)
    } else {
      setInput('')
    }
  }
  const next = (): void => {
    if (round + 1 >= rounds) { setDone(true); return }
    setRound(round + 1)
    setNums(makeNums()); setInput(''); setRevealed(false)
  }
  const reset = (): void => {
    setRound(0); setNums(makeNums()); setInput(''); setCorrect(0); setRevealed(false); setDone(false)
  }
  if (done) {
    return (
      <div className={css.wrap}>
        <Header title={t('twentyfour.title')} onClose={onClose} t={t} />
        <Banner kind="info" text={t('twentyfour.result', { total: rounds, correct })} />
        <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
      </div>
    )
  }
  return (
    <div className={css.wrap}>
      <Header title={t('twentyfour.progress', { n: round + 1, total: rounds })} onClose={onClose} t={t} />
      <div className={css.row} style={{ gap: '12px' }}>
        {nums.map((n, i) => <div key={i} className={css.huge} style={{ fontSize: '32px' }}>{n}</div>)}
      </div>
      {revealed ? (
        <>
          <Banner kind="win" text={t('twentyfour.correct')} />
          <button type="button" className={css.btn} onClick={next}>{round + 1 >= rounds ? t('common.viewResult') : t('common.nextQuestion')}</button>
        </>
      ) : (
        <>
          <input
            className={css.input}
            style={{ width: '100%' }}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') submit() }}
            placeholder={t('twentyfour.placeholder')}
            autoFocus
          />
          <div className={css.row}>
            <button type="button" className={css.btn} onClick={submit}>{t('common.submit')}</button>
            <button type="button" className={`${css.btn} ${css.secondary}`} onClick={() => setRevealed(true)}>{t('common.giveUp')}</button>
          </div>
        </>
      )}
    </div>
  )
}

// ─── Water Pouring ─────────────────────────────────────────
export interface WaterProps { caps: number[]; target: number }
/**
 * Classic water-jug puzzle: measure exactly `target` L using jugs whose
 * capacities are given by `caps`. Jugs start empty; actions are fill (faucet),
 * empty (drain) and pour between two jugs. Solvable iff target is a positive
 * multiple of gcd(caps) and not larger than the biggest jug.
 */
export function Water({ caps, target, onClose, t }: GameProps & WaterProps) {
  const make = (): number[] => caps.map(() => 0)
  const [state, setState] = useState<number[]>(make)
  const [sel, setSel] = useState<number | null>(null)
  const [moves, setMoves] = useState(0)
  const won = state.some(v => v === target)
  const feasible = canSolveWater(caps, target)

  const apply = (next: number[]): void => { setState(next); setMoves(m => m + 1) }
  const pour = (from: number, to: number): void => {
    if (from === to) return
    const src = state[from] ?? 0
    if (src === 0) return
    const space = (caps[to] ?? 0) - (state[to] ?? 0)
    if (space <= 0) return
    const amount = Math.min(src, space)
    const next = [...state]
    next[from] = src - amount
    next[to] = (next[to] ?? 0) + amount
    apply(next)
  }
  const fill = (i: number): void => {
    if ((state[i] ?? 0) === (caps[i] ?? 0)) return
    const next = [...state]; next[i] = caps[i]!
    apply(next)
  }
  const empty = (i: number): void => {
    if ((state[i] ?? 0) === 0) return
    const next = [...state]; next[i] = 0
    apply(next)
  }
  const click = (i: number): void => {
    if (won || !feasible) return
    if (sel === null) { setSel(i); return }
    if (sel === i) { setSel(null); return }
    pour(sel, i); setSel(null)
  }
  const tool = (fn: (i: number) => void): void => { if (sel !== null) fn(sel) }
  const reset = (): void => { setState(make()); setSel(null); setMoves(0) }

  return (
    <div className={css.wrap}>
      <Header title={t('water.title', { target })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.moves')}: <b>{moves}</b></span></div>
      <div className={css.row} style={{ gap: '8px', alignItems: 'flex-end' }}>
        {caps.map((cap, i) => {
          const v = state[i] ?? 0
          return (
            <button
              key={i}
              type="button"
              onClick={() => click(i)}
              disabled={!feasible}
              style={{
                width: '44px', height: `${(v / cap) * 120 + 26}px`,
                background: sel === i ? '#4a9eff' : '#3498db',
                border: '2px solid #2a2d36', borderRadius: '6px',
                display: 'flex', flexDirection: 'column', justifyContent: 'flex-end',
                cursor: 'pointer', color: '#fff', fontSize: '12px', lineHeight: '1.1',
              }}
            >
              <span>{v}L</span>
              <span style={{ opacity: 0.7, fontSize: '10px' }}>/{cap}L</span>
            </button>
          )
        })}
      </div>
      <div className={css.row}>
        <button type="button" className={css.btn} disabled={sel === null || won || !feasible} onClick={() => tool(fill)}>{t('water.fill')}</button>
        <button type="button" className={css.btn} disabled={sel === null || won || !feasible} onClick={() => tool(empty)}>{t('water.empty')}</button>
        <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
      </div>
      {won ? (
        <Banner kind="win" text={t('common.doneMoves', { n: moves })} />
      ) : (
        sel !== null && <div className={css.hint}>{t('water.selected', { sel: sel + 1, cap: caps[sel] })}</div>
      )}
      {!feasible && <Banner kind="info" text={t('water.infeasible')} />}
      <div className={css.hint}>{t('water.hint')}</div>
    </div>
  )
}

// ─── Tower of Hanoi ────────────────────────────────────────
export interface HanoiProps { disks: number }
/** Tower of Hanoi. */
export function Hanoi({ disks, onClose, t }: GameProps & HanoiProps) {
  const [pegs, setPegs] = useState<number[][]>(() => [range(disks).map(i => disks - i).reverse(), [], []])
  const [sel, setSel] = useState<number | null>(null)
  const [moves, setMoves] = useState(0)
  const won = pegs[2]!.length === disks
  const minMoves = 2 ** disks - 1

  const click = (i: number): void => {
    if (won) return
    if (sel === null) {
      if (pegs[i]!.length === 0) return
      setSel(i); return
    }
    if (sel === i) { setSel(null); return }
    const from = pegs[sel]!; const to = pegs[i]!
    if (from.length === 0) { setSel(null); return }
    const top = from[from.length - 1]!
    if (to.length > 0 && to[to.length - 1]! < top) { setSel(null); return }
    const next = pegs.map(p => [...p])
    next[i]!.push(next[sel]!.pop()!)
    setPegs(next); setSel(null); setMoves(m => m + 1)
  }
  const reset = (): void => { setPegs([range(disks).map(i => disks - i).reverse(), [], []]); setSel(null); setMoves(0) }

  return (
    <div className={css.wrap}>
      <Header title={t('hanoi.title', { disks })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.moves')}: <b>{moves}</b></span><span>{t('hanoi.optimal')}: <b>{minMoves}</b></span></div>
      <div className={css.row} style={{ gap: '20px', alignItems: 'flex-end', minHeight: '140px' }}>
        {pegs.map((p, i) => (
          <button
            key={i}
            type="button"
            onClick={() => click(i)}
            style={{
              width: '90px', height: '140px', background: '#1a1d24', border: sel === i ? '2px solid #4a9eff' : '2px solid #2a2d36',
              borderRadius: '6px', display: 'flex', flexDirection: 'column-reverse', alignItems: 'center', padding: '4px', cursor: 'pointer',
            }}
          >
            {p.map((d, j) => (
              <div key={j} style={{ width: `${d * 8 + 20}px`, height: '12px', background: PALETTE[(d - 1) % PALETTE.length], borderRadius: '2px', marginTop: '2px' }} />
            ))}
          </button>
        ))}
      </div>
      {won ? (
        <>
          <Banner kind="win" text={t('hanoi.done', { n: moves, min: minMoves })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
      )}
    </div>
  )
}

// ─── Connect Four ──────────────────────────────────────────
export interface Connect4Props { cols: number; rows: number; ai: boolean }
/** Connect-4 drop game. */
export function Connect4({ cols, rows, ai, onClose, t }: GameProps & Connect4Props) {
  type Cell = 'R' | 'Y' | null
  const [board, setBoard] = useState<Cell[]>(() => new Array(cols * rows).fill(null))
  const [turn, setTurn] = useState<'R' | 'Y'>('R')
  const [winner, setWinner] = useState<Cell | 'draw'>(null)

  const dropIn = (col: number, mark: 'R' | 'Y', b: Cell[]): { ok: boolean; next: Cell[]; lastIdx: number } => {
    for (let r = rows - 1; r >= 0; r--) {
      const idx = r * cols + col
      if (b[idx] === null) {
        const next = [...b]; next[idx] = mark
        return { ok: true, next, lastIdx: idx }
      }
    }
    return { ok: false, next: b, lastIdx: -1 }
  }

  const checkWin = (b: Cell[], lastIdx: number): Cell | 'draw' | null => {
    const v = b[lastIdx]; if (v === null || v === undefined) return null
    const r = Math.floor(lastIdx / cols); const c = lastIdx % cols
    const dirs: ReadonlyArray<[number, number]> = [[0, 1], [1, 0], [1, 1], [1, -1]]
    for (const [dr, dc] of dirs) {
      let cnt = 1
      for (let i = 1; i < 4; i++) {
        const nr = r + dr * i; const nc = c + dc * i
        if (nr < 0 || nr >= rows || nc < 0 || nc >= cols) break
        if (b[nr * cols + nc] !== v) break
        cnt++
      }
      for (let i = 1; i < 4; i++) {
        const nr = r - dr * i; const nc = c - dc * i
        if (nr < 0 || nr >= rows || nc < 0 || nc >= cols) break
        if (b[nr * cols + nc] !== v) break
        cnt++
      }
      if (cnt >= 4) return v
    }
    if (b.every(x => x !== null)) return 'draw'
    return null
  }

  const play = (col: number, mark: 'R' | 'Y'): void => {
    if (winner !== null) return
    const { ok, next, lastIdx } = dropIn(col, mark, board)
    if (!ok) return
    setBoard(next)
    const w = checkWin(next, lastIdx)
    if (w !== null) { setWinner(w); return }
    setTurn(mark === 'R' ? 'Y' : 'R')
  }

  useEffect(() => {
    if (ai && turn === 'Y' && winner === null) {
      const to = window.setTimeout(() => {
        let col: number
        do { col = randInt(0, cols - 1) } while (board[col] !== null && board.some((v, i) => i % cols < cols && v === null))
        play(col, 'Y')
      }, 400)
      return () => window.clearTimeout(to)
    }
    return undefined
  }, [ai, turn, winner, board, cols])

  const click = (col: number): void => {
    if (ai && turn === 'Y') return
    play(col, 'R')
  }

  const reset = (): void => {
    setBoard(new Array(cols * rows).fill(null)); setTurn('R'); setWinner(null)
  }

  const colorName = (mark: 'R' | 'Y'): string => mark === 'R' ? t('connect4.red') : t('connect4.yellow')

  return (
    <div className={css.wrap}>
      <Header title={t('connect4.title', { cols, rows })} onClose={onClose} t={t} />
      <div className={css.stats}>
        <span>{winner === null ? t('connect4.turn', { color: colorName(turn) }) : winner === 'draw' ? t('common.draw') : t('connect4.winner', { color: colorName(winner) })}</span>
      </div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${cols}, 1fr)`, width: 'min(320px, 80vw)', gap: '2px' }}>
        {board.map((v, i) => {
          const col = i % cols
          return (
            <button
              key={i}
              type="button"
              className={css.cell}
              onClick={() => click(col)}
              disabled={winner !== null || (ai && turn === 'Y')}
              style={{
                background: '#1a1d24', border: '1px solid #2a2d36', borderRadius: '50%',
                color: v === 'R' ? '#e74c3c' : v === 'Y' ? '#f1c40f' : '#444', fontSize: '20px',
              }}
            >
              {v !== null ? '●' : '○'}
            </button>
          )
        })}
      </div>
      {winner !== null && <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>}
    </div>
  )
}

// ─── Knight's Tour ─────────────────────────────────────────
export interface KnightProps { size: number }
/** Knight's tour puzzle: visit every square. */
export function Knight({ size, onClose, t }: GameProps & KnightProps) {
  const [pos, setPos] = useState<{ r: number; c: number } | null>(null)
  const [visited, setVisited] = useState<Set<string>>(() => new Set())
  const won = visited.size === size * size

  const canMove = (r: number, c: number): boolean => {
    if (pos === null) return !visited.has(`${r},${c}`)
    const dr = Math.abs(r - pos.r); const dc = Math.abs(c - pos.c)
    return !visited.has(`${r},${c}`) && ((dr === 2 && dc === 1) || (dr === 1 && dc === 2))
  }
  const click = (r: number, c: number): void => {
    if (won) return
    if (!canMove(r, c)) return
    setPos({ r, c })
    setVisited(prev => new Set([...prev, `${r},${c}`]))
  }
  const reset = (): void => { setPos(null); setVisited(new Set()) }

  return (
    <div className={css.wrap}>
      <Header title={t('knight.title', { size })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('knight.visited')}: <b>{visited.size}</b>/{size * size}</span></div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: 'min(280px, 75vw)' }}>
        {range(size * size).map(i => {
          const r = Math.floor(i / size); const c = i % size
          const isHere = pos !== null && pos.r === r && pos.c === c
          const isVisited = visited.has(`${r},${c}`)
          const isLegal = canMove(r, c)
          return (
            <button
              key={i}
              type="button"
              className={css.cell}
              onClick={() => click(r, c)}
              disabled={won}
              style={{
                background: isHere ? '#4a9eff' : isVisited ? '#2ecc71' : isLegal ? '#2a2d46' : '#1a1d24',
                color: '#fff', cursor: isLegal || pos === null ? 'pointer' : 'default',
              }}
            >
              {isHere ? '♞' : ''}
            </button>
          )
        })}
      </div>
      {won ? (
        <>
          <Banner kind="win" text={t('knight.done')} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
      )}
      <div className={css.hint}>{t('knight.hint')}</div>
    </div>
  )
}

// ─── Minesweeper ───────────────────────────────────────────
export interface MinesProps { size: number; mines: number }
/** Minesweeper. */
export function Mines({ size, mines, onClose, t }: GameProps & MinesProps) {
  type Cell = { mine: boolean; revealed: boolean; flagged: boolean; count: number }
  const make = (): Cell[] => {
    const b: Cell[] = new Array(size * size).fill(0).map(() => ({ mine: false, revealed: false, flagged: false, count: 0 }))
    let placed = 0
    while (placed < mines) {
      const i = randInt(0, size * size - 1)
      if (b[i]!.mine) continue
      b[i]!.mine = true; placed++
    }
    for (let i = 0; i < size * size; i++) {
      if (b[i]!.mine) continue
      const r = Math.floor(i / size); const c = i % size
      let count = 0
      for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
        const nr = r + dr; const nc = c + dc
        if (nr < 0 || nr >= size || nc < 0 || nc >= size) continue
        if (b[nr * size + nc]!.mine) count++
      }
      b[i]!.count = count
    }
    return b
  }
  const [board, setBoard] = useState<Cell[]>(make)
  const [done, setDone] = useState<'win' | 'lose' | null>(null)

  const reveal = (idx: number, b: Cell[]): Cell[] => {
    if (b[idx]!.revealed || b[idx]!.flagged) return b
    const next = b.map(x => ({ ...x }))
    const stack = [idx]
    while (stack.length > 0) {
      const cur = stack.pop()!
      const cell = next[cur]!
      if (cell.revealed || cell.flagged) continue
      cell.revealed = true
      if (cell.count === 0 && !cell.mine) {
        const cr = Math.floor(cur / size); const cc = cur % size
        for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
          const nr = cr + dr; const nc = cc + dc
          if (nr < 0 || nr >= size || nc < 0 || nc >= size) continue
          stack.push(nr * size + nc)
        }
      }
    }
    return next
  }

  const click = (i: number): void => {
    if (done !== null) return
    if (board[i]!.flagged) return
    if (board[i]!.mine) {
      const next = board.map(x => ({ ...x, revealed: x.mine ? true : x.revealed }))
      setBoard(next); setDone('lose'); return
    }
    const next = reveal(i, board)
    setBoard(next)
    if (next.every(c => c.mine || c.revealed)) { setDone('win') }
  }
  const flag = (i: number, e: React.MouseEvent): void => {
    e.preventDefault()
    if (done !== null || board[i]!.revealed) return
    const next = [...board]
    next[i] = { ...next[i]!, flagged: !next[i]!.flagged }
    setBoard(next)
  }
  const reset = (): void => { setBoard(make()); setDone(null) }
  const flags = board.filter(c => c.flagged).length

  return (
    <div className={css.wrap}>
      <Header title={t('mines.title', { mines })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('mines.flagsLabel')}: <b>{flags}</b>/{mines}</span></div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: 'min(280px, 75vw)' }}>
        {board.map((c, i) => (
          <button
            key={i}
            type="button"
            className={`${css.cell} ${c.revealed ? (c.mine ? css.mine : c.count === 0 ? css.empty : '') : ''} ${c.flagged ? css.flag : ''}`}
            onClick={() => click(i)}
            onContextMenu={e => flag(i, e)}
            disabled={done !== null}
          >
            {c.revealed ? (c.mine ? '💣' : c.count > 0 ? c.count : '') : c.flagged ? '🚩' : ''}
          </button>
        ))}
      </div>
      {done !== null && (
        <>
          <Banner kind={done} text={done === 'win' ? t('mines.won') : t('mines.lost')} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      )}
      <div className={css.hint}>{t('mines.hint')}</div>
    </div>
  )
}

// ─── Sudoku (mini 4x4 / 6x6) ───────────────────────────────
export interface SudokuProps { size: number }
/** Small sudoku (4 or 6 size). */
export function Sudoku({ size, onClose, t }: GameProps & SudokuProps) {
  const boxW = size === 4 ? 2 : 3
  const boxH = size === 4 ? 2 : 2
  const make = (): number[] => {
    // Generate a valid Latin square (size N) using a base pattern.
    const base: number[] = []
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        const v = ((r * boxH + Math.floor(r / boxH)) + c) % size + 1
        base.push(v)
      }
    }
    // Shuffle rows within bands and columns within stacks for variety.
    // (Cheap; not strictly a perfect sudoku but visually distinct.)
    const sol = [...base]
    // Hide ~half of cells.
    const hide = new Set<number>()
    while (hide.size < size * size / 2) {
      hide.add(randInt(0, size * size - 1))
    }
    return sol.map((v, i) => hide.has(i) ? 0 : v)
  }
  const [puzzle, setPuzzle] = useState<number[]>(make)
  const [solution] = useState<number[]>(() => {
    // Solve via the same canonical pattern (cheap heuristic).
    const sol: number[] = []
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        sol.push(((r * boxH + Math.floor(r / boxH)) + c) % size + 1)
      }
    }
    return sol
  })
  const [user, setUser] = useState<number[]>(() => [...puzzle])
  const [sel, setSel] = useState<number | null>(null)
  const won = user.every((v, i) => v === solution[i])

  const setVal = (i: number, v: number): void => {
    if (puzzle[i] !== 0) return
    const next = [...user]; next[i] = v; setUser(next)
  }
  const reset = (): void => { setPuzzle(make()); setUser([...puzzle]) }

  return (
    <div className={css.wrap}>
      <Header title={t('sudoku.title', { size })} onClose={onClose} t={t} />
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: 'min(280px, 75vw)' }}>
        {user.map((v, i) => {
          const fixed = puzzle[i] !== 0
          return (
            <button
              key={i}
              type="button"
              className={css.cell}
              onClick={() => setSel(i)}
              style={{
                background: fixed ? '#2a2d36' : sel === i ? '#4a9eff44' : '#1a1d24',
                color: fixed ? '#aaa' : v === solution[i] ? '#4a9eff' : '#e74c3c',
                borderRight: (i % size + 1) % boxW === 0 ? '2px solid #4a9eff' : '1px solid #1a1d24',
                borderBottom: (Math.floor(i / size) + 1) % boxH === 0 ? '2px solid #4a9eff' : '1px solid #1a1d24',
              }}
            >
              {v === 0 ? '' : v}
            </button>
          )
        })}
      </div>
      <div className={css.row}>
        {range(size).map(n => (
          <button key={n} type="button" className={css.btn} style={{ minWidth: '36px' }} onClick={() => sel !== null && setVal(sel, n + 1)} disabled={sel === null}>
            {n + 1}
          </button>
        ))}
        <button type="button" className={`${css.btn} ${css.secondary}`} onClick={() => sel !== null && setVal(sel, 0)} disabled={sel === null}>{t('sudoku.erase')}</button>
      </div>
      {won && <Banner kind="win" text={t('common.complete')} />}
      <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.new')}</button>
    </div>
  )
}

// ─── Nonogram (mini 5x5) ───────────────────────────────────
export interface NonogramProps { size: number }
/** Mini nonogram puzzle. */
export function Nonogram({ size, onClose, t }: GameProps & NonogramProps) {
  const make = (): boolean[] => {
    const b = new Array(size * size).fill(false)
    for (let i = 0; i < size * size; i++) b[i] = Math.random() > 0.5
    // Make sure at least one true in each row/col.
    for (let r = 0; r < size; r++) {
      let has = false
      for (let c = 0; c < size; c++) if (b[r * size + c]) { has = true; break }
      if (!has) b[r * size + randInt(0, size - 1)] = true
    }
    return b
  }
  const [solution] = useState<boolean[]>(make)
  const [marks, setMarks] = useState<('fill' | 'x' | null)[]>(() => new Array(size * size).fill(null))

  const rowHints = useMemo(() => {
    const out: number[][] = []
    for (let r = 0; r < size; r++) {
      const run: number[] = []
      let cur = 0
      for (let c = 0; c < size; c++) {
        if (solution[r * size + c]) cur++
        else { if (cur > 0) run.push(cur); cur = 0 }
      }
      if (cur > 0) run.push(cur)
      out.push(run.length === 0 ? [0] : run)
    }
    return out
  }, [solution, size])

  const colHints = useMemo(() => {
    const out: number[][] = []
    for (let c = 0; c < size; c++) {
      const run: number[] = []
      let cur = 0
      for (let r = 0; r < size; r++) {
        if (solution[r * size + c]) cur++
        else { if (cur > 0) run.push(cur); cur = 0 }
      }
      if (cur > 0) run.push(cur)
      out.push(run.length === 0 ? [0] : run)
    }
    return out
  }, [solution, size])

  const cycle = (i: number): void => {
    const cur = marks[i]
    const next = [...marks]
    next[i] = cur === null ? 'fill' : cur === 'fill' ? 'x' : null
    setMarks(next)
  }
  const won = marks.every((m, i) => (m === 'fill') === solution[i])

  const reset = (): void => setMarks(new Array(size * size).fill(null))

  return (
    <div className={css.wrap}>
      <Header title={t('nonogram.title', { size })} onClose={onClose} t={t} />
      {won && <Banner kind="win" text={t('common.complete')} />}
      <div style={{ display: 'grid', gridTemplateColumns: `auto repeat(${size}, 24px)`, gap: '2px', justifyContent: 'center' }}>
        <div />
        {colHints.map((h, i) => (
          <div key={`c${i}`} style={{ display: 'flex', flexDirection: 'column', fontSize: '10px', color: '#aaa', textAlign: 'center', justifyContent: 'flex-end' }}>
            {h.map((n, j) => <div key={j}>{n}</div>)}
          </div>
        ))}
        {range(size).map(r => (
          <>
            <div key={`r${r}`} style={{ display: 'flex', fontSize: '10px', color: '#aaa', alignItems: 'center', gap: '2px', justifyContent: 'flex-end', paddingRight: '4px' }}>
              {rowHints[r]!.map((n, j) => <span key={j}>{n}</span>)}
            </div>
            {range(size).map(c => {
              const i = r * size + c
              return (
                <button
                  key={`cell${i}`}
                  type="button"
                  onClick={() => cycle(i)}
                  style={{
                    width: '24px', height: '24px', padding: 0,
                    background: marks[i] === 'fill' ? '#4a9eff' : '#1a1d24',
                    color: '#888', border: '1px solid #2a2d36', cursor: 'pointer', fontSize: '14px',
                  }}
                >
                  {marks[i] === 'x' ? '×' : ''}
                </button>
              )
            })}
          </>
        ))}
      </div>
      <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
      <div className={css.hint}>{t('nonogram.hint')}</div>
    </div>
  )
}

// ─── 2048 (mini) ───────────────────────────────────────────
export interface Game2048Props { size: number; target: number }
/** Mini 2048. */
export function Game2048({ size, target, onClose, t }: GameProps & Game2048Props) {
  type Grid = number[][]
  const empty = (): Grid => Array.from({ length: size }, () => new Array(size).fill(0))
  const addTile = (g: Grid): Grid => {
    const empties: [number, number][] = []
    for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) if (g[r]![c] === 0) empties.push([r, c])
    if (empties.length === 0) return g
    const [r, c] = pick(empties)
    const ng = g.map(row => [...row])
    ng[r]![c] = Math.random() < 0.9 ? 2 : 4
    return ng
  }
  const make = (): Grid => addTile(addTile(empty()))
  const [grid, setGrid] = useState<Grid>(make)
  const [score, setScore] = useState(0)
  const [won, setWon] = useState(false)
  const [over, setOver] = useState(false)

  const slide = (row: number[]): { row: number[]; gain: number } => {
    const filt = row.filter(v => v !== 0)
    const out: number[] = []
    let gain = 0
    for (let i = 0; i < filt.length; i++) {
      if (i + 1 < filt.length && filt[i] === filt[i + 1]) {
        const v = filt[i]! * 2
        out.push(v); gain += v; i++
      } else {
        out.push(filt[i]!)
      }
    }
    while (out.length < size) out.push(0)
    return { row: out, gain }
  }

  const move = (dir: 'left' | 'right' | 'up' | 'down'): void => {
    if (over) return
    let g = grid.map(r => [...r])
    if (dir === 'right') g = g.map(r => r.reverse())
    if (dir === 'up') g = g[0]!.map((_, c) => g.map(r => r[c]!))
    if (dir === 'down') g = g[0]!.map((_, c) => g.map(r => r[c]!).reverse())
    let totalGain = 0
    const slid = g.map(r => {
      const s = slide(r)
      totalGain += s.gain
      return s.row
    })
    let ng = slid
    if (dir === 'right') ng = ng.map(r => r.reverse())
    if (dir === 'up') ng = ng[0]!.map((_, c) => ng.map(r => r[c]!))
    if (dir === 'down') ng = ng[0]!.map((_, c) => ng.map(r => r[c]!).reverse())
    if (JSON.stringify(ng) === JSON.stringify(grid)) return
    ng = addTile(ng)
    setGrid(ng)
    setScore(s => s + totalGain)
    if (!won && ng.some(r => r.includes(target))) setWon(true)
    // Check game over
    const canMove = ng.some((row, r) => row.some((v, c) => v === 0 || (c + 1 < size && row[c + 1] === v) || (r + 1 < size && ng[r + 1]![c] === v)))
    if (!canMove) setOver(true)
  }

  useEffect(() => {
    const h = (e: KeyboardEvent): void => {
      if (e.key === 'ArrowLeft') { e.preventDefault(); move('left') }
      else if (e.key === 'ArrowRight') { e.preventDefault(); move('right') }
      else if (e.key === 'ArrowUp') { e.preventDefault(); move('up') }
      else if (e.key === 'ArrowDown') { e.preventDefault(); move('down') }
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  })

  const reset = (): void => { setGrid(make()); setScore(0); setWon(false); setOver(false) }
  const color = (v: number): string => v === 0 ? '#1a1d24' : PALETTE[(Math.log2(v) - 1) % PALETTE.length]!

  return (
    <div className={css.wrap}>
      <Header title={t('game2048.title', { target })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('common.score')}: <b>{score}</b></span></div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: 'min(280px, 75vw)' }}>
        {grid.flat().map((v, i) => (
          <div
            key={i}
            className={css.cell}
            style={{ background: color(v), color: '#fff', cursor: 'default' }}
          >
            {v === 0 ? '' : v}
          </div>
        ))}
      </div>
      {won && <Banner kind="win" text={t('game2048.won', { target })} />}
      {over && <Banner kind="lose" text={t('game2048.over')} />}
      <div className={css.row}>
        <button type="button" className={css.btn} onClick={() => move('up')}>↑</button>
        <div className={css.row}>
          <button type="button" className={css.btn} onClick={() => move('left')}>←</button>
          <button type="button" className={css.btn} onClick={() => move('down')}>↓</button>
          <button type="button" className={css.btn} onClick={() => move('right')}>→</button>
        </div>
      </div>
      <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
    </div>
  )
}

// ─── N-Queens Counter ──────────────────────────────────────
export interface NQueensProps { size: number }
/** Place N queens without threats. */
export function NQueens({ size, onClose, t }: GameProps & NQueensProps) {
  const [queens, setQueens] = useState<Set<number>>(() => new Set())
  const placed = queens.size
  const won = placed === size
  const isThreat = (a: number, b: number): boolean => {
    const ra = Math.floor(a / size); const ca = a % size
    const rb = Math.floor(b / size); const cb = b % size
    return ra === rb || ca === cb || Math.abs(ra - rb) === Math.abs(ca - cb)
  }
  const conflict = useMemo(() => {
    const arr = [...queens]
    for (let i = 0; i < arr.length; i++) for (let j = i + 1; j < arr.length; j++) if (isThreat(arr[i]!, arr[j]!)) return true
    return false
  }, [queens, size])

  const click = (i: number): void => {
    if (won) return
    const next = new Set(queens)
    if (next.has(i)) next.delete(i)
    else if (!conflict) {
      // Allow placement only if not threatened by any existing.
      const threatened = [...next].some(q => isThreat(q, i))
      if (threatened) return
      next.add(i)
    } else return
    setQueens(next)
  }
  const reset = (): void => setQueens(new Set())

  return (
    <div className={css.wrap}>
      <Header title={t('nqueens.title', { size })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('nqueens.placed')}: <b>{placed}</b>/{size}</span></div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: 'min(280px, 75vw)' }}>
        {range(size * size).map(i => {
          const r = Math.floor(i / size); const c = i % size
          const isQueen = queens.has(i)
          const threatened = [...queens].some(q => q !== i && isThreat(q, i))
          return (
            <button
              key={i}
              type="button"
              className={css.cell}
              onClick={() => click(i)}
              disabled={won}
              style={{
                background: isQueen ? '#4a9eff' : (r + c) % 2 === 0 ? '#1a1d24' : '#232631',
                color: '#fff', fontSize: '20px',
                cursor: threatened && !isQueen ? 'not-allowed' : 'pointer',
              }}
            >
              {isQueen ? '♛' : ''}
            </button>
          )
        })}
      </div>
      {won ? (
        <>
          <Banner kind="win" text={t('common.complete')} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
      )}
      <div className={css.hint}>{t('nqueens.hint', { n: size })}</div>
    </div>
  )
}

// ─── Sliding Snake Path ────────────────────────────────────
export interface PathfindProps { size: number; length: number }
/**
 * Hamiltonian-path puzzle: draw a single self-avoiding path that visits every
 * tile exactly once (a "one-stroke" path). Click a tile to extend the path
 * from the last tile; it can only continue onto an adjacent, unvisited tile.
 */
export function Pathfind({ size, length, onClose, t }: GameProps & PathfindProps) {
  const [path, setPath] = useState<number[]>([])
  const won = path.length === length
  const last = path[path.length - 1]
  const isAdj = (i: number): boolean => {
    if (path.length === 0) return true
    if (path.includes(i)) return false
    const r = Math.floor(i / size); const c = i % size
    const lr = Math.floor(last! / size); const lc = last! % size
    return Math.abs(r - lr) + Math.abs(c - lc) === 1
  }
  const stuck = !won && path.length > 0 && range(size * size).every(i => !isAdj(i))
  const click = (i: number): void => {
    if (won) return
    if (!isAdj(i)) return
    setPath([...path, i])
  }
  const undo = (): void => setPath(path.slice(0, -1))
  const reset = (): void => setPath([])

  return (
    <div className={css.wrap}>
      <Header title={t('pathfind.title', { length })} onClose={onClose} t={t} />
      <div className={css.stats}><span>{t('knight.visited')}: <b>{path.length}</b>/{length}</span></div>
      <div className={css.grid} style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: 'min(280px, 75vw)' }}>
        {range(size * size).map(i => {
          const idx = path.indexOf(i)
          return (
            <button
              key={i}
              type="button"
              className={css.cell}
              onClick={() => click(i)}
              disabled={won}
              style={{
                background: idx >= 0 ? '#4a9eff' : isAdj(i) ? '#2a2d46' : '#1a1d24',
                color: '#fff', cursor: isAdj(i) || won ? 'pointer' : 'default',
              }}
            >
              {idx >= 0 ? idx + 1 : ''}
            </button>
          )
        })}
      </div>
      {won ? (
        <>
          <Banner kind="win" text={t('pathfind.done', { n: path.length })} />
          <button type="button" className={css.btn} onClick={reset}>{t('common.replay')}</button>
        </>
      ) : (
        <div className={css.row}>
          <button type="button" className={`${css.btn} ${css.secondary}`} onClick={undo} disabled={path.length === 0}>{t('common.undo')}</button>
          <button type="button" className={`${css.btn} ${css.secondary}`} onClick={reset}>{t('common.reset')}</button>
        </div>
      )}
      {stuck && <Banner kind="info" text={t('pathfind.stuck')} />}
      <div className={css.hint}>{t('pathfind.hint', { length })}</div>
    </div>
  )
}