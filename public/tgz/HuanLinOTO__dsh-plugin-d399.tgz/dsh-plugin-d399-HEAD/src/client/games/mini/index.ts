/**
 * Mini-game bundle entry: registers all catalog games with the d399Games
 * service, attaching fold-group metadata from GROUP_RULES so same-family
 * variants collapse into one menu entry.
 *
 * @module @huanlin/dsh-plugin-d399/client/games/mini
 */
import type { D399GamesService, Game } from '../../registry.ts'
import { MINI_CATALOG, applyGroupRule } from './catalog.ts'

/** Register every game in the mini catalog; returns a disposer that removes all. */
export function registerMiniGames(registry: D399GamesService): () => void {
  const disposers: Array<() => void> = MINI_CATALOG.map((game): Game => {
    const group = applyGroupRule(game.id)
    return group === null ? game : { ...game, group }
  }).map(game => registry.register(game))
  return () => { for (const d of disposers) d() }
}

export { MINI_CATALOG } from './catalog.ts'
