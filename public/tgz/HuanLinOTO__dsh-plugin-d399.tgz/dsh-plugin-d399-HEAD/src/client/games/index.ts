/**
 * Built-in games: wordle + match-3. Each module exports its component;
 * this barrel registers them with the d399Games service.
 *
 * @module @huanlin/dsh-plugin-d399/client/games
 */
import type { D399GamesService } from '../registry.ts'
import { Wordle } from './wordle/Wordle.tsx'
import { Match3 } from './match3/Match3.tsx'
import { registerMiniGames } from './mini/index.ts'

/** Register the built-in game set; returns a disposer that removes all. */
export function registerBuiltinGames(registry: D399GamesService): () => void {
  const disposers: Array<() => void> = [
    registry.register({ id: 'wordle', name: 'Wordle', icon: '📖', Component: Wordle }),
    registry.register({ id: 'match3', name: '消消乐', icon: '💎', Component: Match3, titleKey: 'match3.title' }),
    registerMiniGames(registry),
  ]
  return () => { for (const d of disposers) d() }
}
