/**
 * WebFrame — embed an external webpage as an iframe "game".
 *
 * One WebFrame instance per saved bookmark. The URL is set at registration
 * time (from the bookmark store); the component just renders a sandboxed
 * iframe that fills the game body.
 *
 * @module @huanlin/dsh-plugin-d399/client/games/webframe/WebFrame
 */
import type { GameProps } from '../types.ts'
import css from './WebFrame.module.css'

/** Extra props WebFrame receives beyond the standard GameProps. */
export interface WebFrameProps extends GameProps {
  /** The URL to embed in the iframe. */
  url: string
  /** Whether to allow the iframe to open in a new tab (for sites that block embedding). */
  allowOpenExternal?: boolean
}

/**
 * @param url - the page URL to embed.
 * @param onClose - close the game modal (unused by the iframe itself, but required by GameProps).
 * @param t - locale translate function.
 */
export function WebFrame({ url, allowOpenExternal = true, t }: WebFrameProps) {
  return (
    <div className={css.wrap}>
      <iframe
        className={css.frame}
        src={url}
        title={url}
        sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-presentation"
        referrerPolicy="no-referrer"
        allow="clipboard-read; clipboard-write; fullscreen"
      />
      {allowOpenExternal && (
        <a
          className={css.openExternal}
          href={url}
          target="_blank"
          rel="noopener noreferrer"
        >
          ↗ {t('webframe.openExternal')}
        </a>
      )}
    </div>
  )
}
