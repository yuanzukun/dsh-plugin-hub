/**
 * BookmarkPanel — the "add custom webpage" UI inside the game menu.
 *
 * Lists existing bookmarks with delete buttons, plus a form to add a new
 * one (name + url). Bookmarks persist to localStorage via BookmarkStore
 * and immediately appear as game entries in the menu.
 *
 * @module @huanlin/dsh-plugin-d399/client/games/webframe/BookmarkPanel
 */
import { useEffect, useState } from 'react'
import type { BookmarkStore, Bookmark } from './bookmarks.ts'
import type { Translate } from '../../locales.ts'
import css from './BookmarkPanel.module.css'

/**
 * @param store - the live bookmark store.
 * @param t - locale translate function.
 * @param onOpenBookmark - callback to immediately open a just-added bookmark.
 */
export function BookmarkPanel({ store, t, onOpenBookmark }: {
  store: BookmarkStore
  t: Translate
  onOpenBookmark: (key: string) => void
}) {
  const [name, setName] = useState('')
  const [url, setUrl] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [bookmarks, setBookmarks] = useState<readonly Bookmark[]>(() => store.list())

  // Subscribe to store changes so the list updates live.
  useEffect(() => {
    const update = (): void => setBookmarks(store.list())
    update()
    return store.subscribe(update)
  }, [store])

  const handleAdd = (): void => {
    setError(null)
    try {
      const key = store.add({ name, url })
      setName('')
      setUrl('')
      onOpenBookmark(key)
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }

  const handleRemove = (key: string): void => {
    store.remove(key)
  }

  const handleKeyDown = (e: React.KeyboardEvent): void => {
    if (e.key === 'Enter' && name.trim() !== '' && url.trim() !== '') {
      handleAdd()
    }
  }

  return (
    <div className={css.wrap}>
      <div className={css.sectionTitle}>🌐 {t('webframe.sectionTitle')}</div>
      <div className={css.form}>
        <input
          className={css.input}
          type="text"
          placeholder={t('webframe.namePlaceholder')}
          value={name}
          onChange={e => setName(e.target.value)}
          onKeyDown={handleKeyDown}
        />
        <input
          className={css.input}
          type="text"
          placeholder={t('webframe.urlPlaceholder')}
          value={url}
          onChange={e => setUrl(e.target.value)}
          onKeyDown={handleKeyDown}
        />
        <button
          type="button"
          className={css.addBtn}
          onClick={handleAdd}
          disabled={name.trim() === '' || url.trim() === ''}
        >
          + {t('webframe.add')}
        </button>
      </div>
      {error !== null && <div className={css.error}>{error}</div>}
      {bookmarks.length > 0 && (
        <div className={css.list}>
          {bookmarks.map(b => (
            <div key={b.key} className={css.row}>
              <span className={css.rowIcon}>{b.icon ?? '🌐'}</span>
              <span className={css.rowName}>{b.name}</span>
              <button
                type="button"
                className={css.rowDelete}
                onClick={() => handleRemove(b.key)}
                aria-label={t('webframe.deleteAria', { name: b.name })}
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
