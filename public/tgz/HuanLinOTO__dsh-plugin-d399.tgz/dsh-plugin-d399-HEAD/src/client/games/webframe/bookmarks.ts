/**
 * Bookmark store: persists user-added webpage bookmarks to localStorage and
 * re-registers them as d399Games entries (one WebFrame per bookmark).
 *
 * Each bookmark becomes a game with id `webframe:<key>`, so the user can
 * add/remove/rename bookmarks at runtime and the menu updates live.
 *
 * @module @huanlin/dsh-plugin-d399/client/games/webframe/bookmarks
 */
import { createElement } from 'react'
import type { D399GamesService, Game } from '../../registry.ts'
import type { GameProps } from '../types.ts'
import { WebFrame } from './WebFrame.tsx'

/** One saved webpage bookmark. */
export interface Bookmark {
  /** Stable unique key (used in the game id `webframe:<key>`). */
  key: string
  /** Display name shown in the menu. */
  name: string
  /** The URL to embed. */
  url: string
  /** Optional emoji icon. */
  icon?: string
}

/** localStorage key for the bookmark list. */
const STORAGE_KEY = 'dsh-d399:bookmarks'

/** Read the persisted bookmark list (empty on first use / parse failure). */
export function loadBookmarks(): Bookmark[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw === null) return []
    const parsed: unknown = JSON.parse(raw)
    if (!Array.isArray(parsed)) return []
    return parsed.filter(isBookmark)
  } catch {
    return []
  }
}

/** Persist the bookmark list. */
function saveBookmarks(bookmarks: readonly Bookmark[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(bookmarks))
  } catch {
    // localStorage may be unavailable (private mode, quota) — degrade silently;
    // bookmarks still live in-memory for the session.
  }
}

/** Type guard for a persisted bookmark entry. */
function isBookmark(value: unknown): value is Bookmark {
  if (value === null || typeof value !== 'object') return false
  const v = value as Record<string, unknown>
  return typeof v.key === 'string' && v.key !== ''
    && typeof v.name === 'string' && v.name !== ''
    && typeof v.url === 'string' && v.url !== ''
}

/** Generate a unique key for a new bookmark. */
function newKey(): string {
  return `bm-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`
}

/**
 * The live bookmark store: holds the list, syncs to localStorage, and
 * re-registers game entries with the d399Games service on every change.
 */
export class BookmarkStore {
  private bookmarks: Bookmark[]
  private readonly registry: D399GamesService
  private readonly registered = new Map<string, () => void>()
  private readonly listeners = new Set<() => void>()

  constructor(registry: D399GamesService) {
    this.registry = registry
    this.bookmarks = loadBookmarks()
    this.syncRegistrations()
  }

  /** Current bookmark list snapshot. */
  list(): readonly Bookmark[] {
    return this.bookmarks
  }

  /** Subscribe to bookmark changes; returns unsubscribe. */
  subscribe(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => { this.listeners.delete(listener) }
  }

  /** Add a bookmark; returns the new bookmark's key. */
  add(input: { name: string; url: string; icon?: string }): string {
    const name = input.name.trim()
    let url = input.url.trim()
    if (name === '' || url === '') throw new Error('name and url are required')
    // Auto-add https:// if the user omitted the scheme.
    if (!/^https?:\/\//i.test(url)) url = `https://${url}`
    const bookmark: Bookmark = { key: newKey(), name, url, icon: input.icon }
    this.bookmarks = [...this.bookmarks, bookmark]
    this.persistAndSync()
    return bookmark.key
  }

  /** Remove a bookmark by key. */
  remove(key: string): void {
    this.bookmarks = this.bookmarks.filter(b => b.key !== key)
    this.persistAndSync()
  }

  /** Dispose all registrations (called on plugin teardown). */
  dispose(): void {
    for (const dispose of this.registered.values()) dispose()
    this.registered.clear()
  }

  private persistAndSync(): void {
    saveBookmarks(this.bookmarks)
    this.syncRegistrations()
    for (const fn of this.listeners) fn()
  }

  /** Reconcile the registry with the current bookmark list. */
  private syncRegistrations(): void {
    const seen = new Set<string>()
    for (const bookmark of this.bookmarks) {
      seen.add(bookmark.key)
      if (this.registered.has(bookmark.key)) continue
      const game = this.toGame(bookmark)
      const dispose = this.registry.register(game)
      this.registered.set(bookmark.key, dispose)
    }
    // Remove registrations for deleted bookmarks.
    for (const [key, dispose] of this.registered) {
      if (!seen.has(key)) {
        dispose()
        this.registered.delete(key)
      }
    }
  }

  /** Build a d399Games Game entry for one bookmark. */
  private toGame(bookmark: Bookmark): Game {
    const id = `webframe:${bookmark.key}`
    const name = bookmark.name
    const icon = bookmark.icon ?? '🌐'
    const url = bookmark.url
    // Component is created via createElement so we can pass the extra `url`
    // prop that WebFrame needs beyond the standard GameProps; the overlay's
    // `t` is forwarded so the iframe chrome follows the active locale.
    const Component = (_props: GameProps) =>
      createElement(WebFrame, { url, onClose: _props.onClose, t: _props.t })
    return { id, name, icon, Component }
  }
}
