/**
 * 消消乐 (Match-3) game component. 8×8 grid of colored tiles. Click one
 * tile then click an adjacent tile to swap; 3+ in a row/column clears them
 * and tiles fall down. Cascades chain automatically. Score = total cleared.
 *
 * @module @huanlin/dsh-plugin-d399/client/games/match3/Match3
 */
import { useCallback, useMemo, useState, type CSSProperties } from 'react'
import type { GameProps } from '../types.ts'
import {
  GRID_SIZE,
  TILE_COLORS,
  areAdjacent,
  generateBoard,
  trySwap,
  type Board,
} from './logic.ts'
import css from './Match3.module.css'

/**
 * @param onClose - close the game modal.
 * @param t - locale translate function.
 */
export function Match3({ onClose, t }: GameProps) {
  const [board, setBoard] = useState<Board>(() => generateBoard())
  const [score, setScore] = useState(0)
  const [moves, setMoves] = useState(0)
  const [selected, setSelected] = useState<{ r: number; c: number } | null>(null)

  const handleCellClick = useCallback((r: number, c: number) => {
    console.log('[dsh-d399] match3 click', r, c, 'selected=', selected)
    if (selected === null) {
      setSelected({ r, c })
      return
    }
    if (selected.r === r && selected.c === c) {
      setSelected(null)
      return
    }
    if (!areAdjacent(selected.r, selected.c, r, c)) {
      setSelected({ r, c })
      return
    }
    // Determine direction from selected → clicked.
    let dir: 'up' | 'down' | 'left' | 'right'
    if (r === selected.r) {
      dir = c > selected.c ? 'right' : 'left'
    } else {
      dir = r > selected.r ? 'down' : 'up'
    }
    const result = trySwap(board, selected.r, selected.c, dir)
    setSelected(null)
    if (result.matched) {
      setBoard(result.board)
      setScore(s => s + result.cleared)
      setMoves(m => m + 1)
    }
  }, [board, selected])

  const restart = useCallback(() => {
    setBoard(generateBoard())
    setScore(0)
    setMoves(0)
    setSelected(null)
  }, [])

  const tiles = useMemo(() => {
    const out: { r: number; c: number; color: number }[] = []
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        const color = board[r]![c]!
        if (color !== 0) out.push({ r, c, color })
      }
    }
    return out
  }, [board])

  return (
    <div className={css.wrap}>
      <div className={css.header}>
        <h2 className={css.title}>{t('match3.title')}</h2>
        <div className={css.stats}>
          <span>{t('common.score')}: <b>{score}</b></span>
          <span>{t('common.moves')}: <b>{moves}</b></span>
        </div>
        <button type="button" className={css.closeBtn} onClick={onClose} aria-label={t('common.close')}>✕</button>
      </div>
      <div
        className={css.grid}
        style={{ '--match3-size': String(GRID_SIZE) } as CSSProperties}
      >
        {tiles.map(({ r, c, color }) => {
          const isSelected = selected !== null && selected.r === r && selected.c === c
          return (
            <button
              key={`${r},${c}`}
              type="button"
              className={`${css.tile} ${isSelected ? css.selected : ''}`}
              style={{
                gridRow: `${r + 1}`,
                gridColumn: `${c + 1}`,
                background: TILE_COLORS[color],
              }}
              onClick={() => handleCellClick(r, c)}
              aria-label={`tile ${r},${c}`}
            />
          )
        })}
      </div>
      <div className={css.footer}>
        <span className={css.hint}>{t('match3.hint')}</span>
        <button type="button" className={css.actionBtn} onClick={restart}>{t('common.replay')}</button>
      </div>
    </div>
  )
}
