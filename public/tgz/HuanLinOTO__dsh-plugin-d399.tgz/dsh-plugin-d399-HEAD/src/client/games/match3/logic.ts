/**
 * 消消乐 (Match-3) game logic — pure functions, no React, for unit testing.
 * 8×8 grid, 6 colors. Swap adjacent cells; 3+ in a row/column clears them;
 * cleared cells are filled by gravity + new random tiles at the top.
 * Cascade chains continue until no more matches.
 *
 * @module @huanlin/dsh-plugin-d399/client/games/match3/logic
 */

/** Number of distinct tile colors. */
export const COLOR_COUNT = 6

/** Grid dimensions. */
export const GRID_SIZE = 8

/** A tile color id (1..COLOR_COUNT), or 0 for empty. */
export type Tile = number

/** Board = row-major 2D array of tiles, indexed [row][col]. */
export type Board = Tile[][]

/** One swap direction. */
export type Direction = 'up' | 'down' | 'left' | 'right'

/** Result of an attempted swap. */
export interface SwapResult {
  /** Whether the swap produced at least one match (and was kept). */
  matched: boolean
  /** The board after swap + cascade resolution (same ref if not matched). */
  board: Board
  /** Total tiles cleared across all cascade steps. */
  cleared: number
}

/** Create an empty grid. */
export function emptyBoard(size: number = GRID_SIZE): Board {
  return Array.from({ length: size }, () => new Array<Tile>(size).fill(0))
}

/** Random integer in [1, max]. */
function randColor(max: number = COLOR_COUNT): Tile {
  return 1 + Math.floor(Math.random() * max)
}

/**
 * Generate a fresh board with no pre-existing matches.
 * @param size - grid edge length.
 */
export function generateBoard(size: number = GRID_SIZE): Board {
  const board = emptyBoard(size)
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      // Pick a color that doesn't create a match with already-placed neighbors.
      let color: Tile
      let tries = 0
      do {
        color = randColor()
        tries++
      } while (tries < 20 && wouldMatchHere(board, r, c, color))
      board[r]![c] = color
    }
  }
  return board
}

/** Check if placing `color` at (r,c) would form an immediate 3-in-a-row. */
function wouldMatchHere(board: Board, r: number, c: number, color: Tile): boolean {
  // Horizontal: two to the left same color.
  if (c >= 2 && board[r]![c - 1] === color && board[r]![c - 2] === color) return true
  // Vertical: two above same color.
  if (r >= 2 && board[r - 1]![c] === color && board[r - 2]![c] === color) return true
  return false
}

/** Deep-copy a board. */
export function cloneBoard(board: Board): Board {
  return board.map(row => [...row])
}

/** Check that (r,c) is inside the grid. */
export function inBounds(r: number, c: number, size: number = GRID_SIZE): boolean {
  return r >= 0 && r < size && c >= 0 && c < size
}

/** Check two cells are orthogonally adjacent. */
export function areAdjacent(r1: number, c1: number, r2: number, c2: number): boolean {
  const dr = Math.abs(r1 - r2)
  const dc = Math.abs(c1 - c2)
  return (dr === 1 && dc === 0) || (dr === 0 && dc === 1)
}

/** Offset of each direction for computing the swap partner. */
const DIR_DELTA: Record<Direction, [number, number]> = {
  up: [-1, 0],
  down: [1, 0],
  left: [0, -1],
  right: [0, 1],
}

/**
 * Find all cells that are part of a horizontal or vertical run of 3+.
 * @returns a set of "r,c" strings.
 */
export function findMatches(board: Board, size: number = GRID_SIZE): Set<string> {
  const matched = new Set<string>()
  // Horizontal runs.
  for (let r = 0; r < size; r++) {
    let runStart = 0
    for (let c = 1; c <= size; c++) {
      const same = c < size && board[r]![c] !== 0 && board[r]![c] === board[r]![runStart]!
      if (!same) {
        if (c - runStart >= 3) {
          for (let k = runStart; k < c; k++) matched.add(`${r},${k}`)
        }
        runStart = c
      }
    }
  }
  // Vertical runs.
  for (let c = 0; c < size; c++) {
    let runStart = 0
    for (let r = 1; r <= size; r++) {
      const same = r < size && board[r]![c] !== 0 && board[r]![c] === board[runStart]![c]!
      if (!same) {
        if (r - runStart >= 3) {
          for (let k = runStart; k < r; k++) matched.add(`${k},${c}`)
        }
        runStart = r
      }
    }
  }
  return matched
}

/**
 * Clear matched cells (set to 0).
 * @returns the count of cleared tiles.
 */
export function clearMatches(board: Board, matched: Set<string>): number {
  let count = 0
  for (const key of matched) {
    const parts = key.split(',')
    const r = Number(parts[0])
    const c = Number(parts[1])
    if (Number.isNaN(r) || Number.isNaN(c)) continue
    if (board[r]?.[c] !== undefined && board[r]![c]! !== 0) {
      board[r]![c] = 0
      count++
    }
  }
  return count
}

/**
 * Apply gravity: non-zero tiles fall down into zero gaps; new random tiles
 * spawn at the top to refill.
 * @returns the board (mutated in place).
 */
export function applyGravity(board: Board, size: number = GRID_SIZE): Board {
  for (let c = 0; c < size; c++) {
    let writeRow = size - 1
    for (let r = size - 1; r >= 0; r--) {
      if (board[r]![c] !== 0) {
        if (writeRow !== r) {
          board[writeRow]![c] = board[r]![c]!
          board[r]![c] = 0
        }
        writeRow--
      }
    }
    // Fill the remaining top cells with new random tiles.
    for (let r = writeRow; r >= 0; r--) {
      board[r]![c] = randColor()
    }
  }
  return board
}

/**
 * Resolve all cascades: repeatedly clear matches and apply gravity until
 * the board stabilizes.
 * @returns total tiles cleared across all cascade steps.
 */
export function resolveCascades(board: Board, size: number = GRID_SIZE): number {
  let totalCleared = 0
  for (let step = 0; step < 64; step++) {
    const matched = findMatches(board, size)
    if (matched.size === 0) break
    totalCleared += clearMatches(board, matched)
    applyGravity(board, size)
  }
  return totalCleared
}

/**
 * Attempt a swap of (r,c) with its neighbor in the given direction. If the
 * swap produces matches, resolve cascades and return the result; otherwise
 * revert the swap.
 */
export function trySwap(board: Board, r: number, c: number, dir: Direction, size: number = GRID_SIZE): SwapResult {
  if (!inBounds(r, c, size)) return { matched: false, board, cleared: 0 }
  const [dr, dc] = DIR_DELTA[dir]
  const r2 = r + dr
  const c2 = c + dc
  if (!inBounds(r2, c2, size)) return { matched: false, board, cleared: 0 }
  const next = cloneBoard(board)
  const tmp = next[r]![c]!
  next[r]![c] = next[r2]![c2]!
  next[r2]![c2] = tmp
  const matched = findMatches(next, size)
  if (matched.size === 0) return { matched: false, board, cleared: 0 }
  clearMatches(next, matched)
  applyGravity(next, size)
  const cleared = matched.size + resolveCascades(next, size)
  return { matched: true, board: next, cleared }
}

/** Tile color palette (index 0 = empty, 1..6 = colors). */
export const TILE_COLORS: ReadonlyArray<string> = [
  'transparent',
  '#e74c3c',
  '#3498db',
  '#2ecc71',
  '#f39c12',
  '#9b59b6',
  '#1abc9c',
]
