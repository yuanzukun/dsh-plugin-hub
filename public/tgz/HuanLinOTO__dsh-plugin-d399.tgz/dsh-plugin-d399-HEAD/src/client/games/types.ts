/**
 * Shared game-component types (kept separate from the registry so game
 * modules do not pull the registry's runtime into their type graph).
 *
 * @module @huanlin/dsh-plugin-d399/client/games/types
 */
import type { Translate } from '../locales.ts'

/** Props every game component receives from the D399 overlay. */
export interface GameProps {
  /** Close the game modal and return to the menu (or hide the overlay). */
  onClose: () => void
  /** Locale-translate function (`ctx.locale.bind(NS)`); renders UI copy. */
  t: Translate
}