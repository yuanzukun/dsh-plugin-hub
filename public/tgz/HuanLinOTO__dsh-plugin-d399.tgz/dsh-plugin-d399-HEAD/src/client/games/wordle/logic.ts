/**
 * Wordle game logic — pure functions, no React, for unit testing.
 *
 * @module @huanlin/dsh-plugin-d399/client/games/wordle/logic
 */

/** Letter verdict for one guess letter. */
export type LetterState = 'correct' | 'present' | 'absent'

/** Per-letter result of one guess. */
export interface LetterResult {
  letter: string
  state: LetterState
}

/** Wordle game length config. */
export interface WordleConfig {
  wordLength: number
  maxGuesses: number
}

/** Default: 5 letters, 6 guesses (classic Wordle). */
export const DEFAULT_CONFIG: WordleConfig = {
  wordLength: 5,
  maxGuesses: 6,
}

/**
 * Evaluate a guess against the answer, returning per-letter verdicts.
 * Handles duplicate letters correctly (the classic two-pass algorithm):
 *  1. Mark exact matches (correct), decrementing the answer's letter pool.
 *  2. Mark remaining letters present (if the letter still has pool) or absent.
 * @param guess - uppercase letter string of the configured length.
 * @param answer - uppercase letter string of the configured length.
 * @returns per-letter results.
 */
export function evaluateGuess(guess: string, answer: string): LetterResult[] {
  const results: LetterResult[] = []
  const pool = new Map<string, number>()
  for (const ch of answer) {
    pool.set(ch, (pool.get(ch) ?? 0) + 1)
  }
  // Pass 1: exact matches.
  const states: LetterState[] = new Array(guess.length).fill('absent')
  for (let i = 0; i < guess.length; i++) {
    const letter = guess[i]!
    if (letter === answer[i]) {
      states[i] = 'correct'
      pool.set(letter, (pool.get(letter) ?? 0) - 1)
    }
  }
  // Pass 2: present (wrong position, but letter exists in remaining pool).
  for (let i = 0; i < guess.length; i++) {
    if (states[i] === 'correct') continue
    const letter = guess[i]!
    const remaining = pool.get(letter) ?? 0
    if (remaining > 0) {
      states[i] = 'present'
      pool.set(letter, remaining - 1)
    }
  }
  for (let i = 0; i < guess.length; i++) {
    results.push({ letter: guess[i]!, state: states[i]! })
  }
  return results
}

/** Game status after a guess. */
export type WordleStatus = 'playing' | 'won' | 'lost'

/**
 * Compute the game status after a guess.
 * @param lastGuess - the just-submitted guess.
 * @param answer - the target answer.
 * @param guessCount - total guesses submitted so far (including lastGuess).
 * @param maxGuesses - the guess cap.
 */
export function computeStatus(
  lastGuess: string,
  answer: string,
  guessCount: number,
  maxGuesses: number,
): WordleStatus {
  if (lastGuess === answer) return 'won'
  if (guessCount >= maxGuesses) return 'lost'
  return 'playing'
}

/**
 * Pick a random answer from the word list.
 * @param words - the answer word list.
 * @returns a random word (uppercased).
 */
export function pickAnswer(words: readonly string[]): string {
  if (words.length === 0) throw new Error('word list is empty')
  const idx = Math.floor(Math.random() * words.length)
  return words[idx]!.toUpperCase()
}

/**
 * Validate a guess: must be the right length and all letters.
 * @param guess - raw input.
 * @param wordLength - expected length.
 * @returns the uppercased guess if valid, otherwise null.
 */
export function validateGuess(guess: string, wordLength: number): string | null {
  const upper = guess.toUpperCase().trim()
  if (upper.length !== wordLength) return null
  if (!/^[A-Z]+$/.test(upper)) return null
  return upper
}
