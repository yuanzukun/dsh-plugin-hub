/**
 * Wordle game component. The player guesses a 5-letter word in 6 tries;
 * each guess gets per-letter feedback (correct/present/absent). Keyboard
 * input + on-screen keyboard both supported.
 *
 * @module @huanlin/dsh-plugin-d399/client/games/wordle/Wordle
 */
import { useCallback, useEffect, useMemo, useState } from 'react'
import type { GameProps } from '../types.ts'
import { DEFAULT_CONFIG, computeStatus, evaluateGuess, pickAnswer, validateGuess, type LetterResult, type WordleStatus } from './logic.ts'
import { ACCEPTED_WORDS, ANSWER_WORDS } from './words.ts'
import css from './Wordle.module.css'

/** One row of the guess grid. */
interface Row {
  guess: string
  results: LetterResult[] | null
}

/** On-screen keyboard layout. */
const KB_ROWS = [
  ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
  ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
  ['ENTER', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', 'BACK'],
]

/** Merge letter states across all guesses for keyboard coloring. */
function keyStates(rows: readonly Row[]): Record<string, 'correct' | 'present' | 'absent'> {
  const out: Record<string, 'correct' | 'present' | 'absent'> = {}
  const rank = { absent: 0, present: 1, correct: 2 }
  for (const row of rows) {
    if (row.results === null) continue
    for (const r of row.results) {
      const cur = out[r.letter]
      if (cur === undefined || rank[r.state] > rank[cur]) out[r.letter] = r.state
    }
  }
  return out
}

/**
 * @param onClose - close the game modal.
 * @param t - locale translate function.
 */
export function Wordle({ onClose, t }: GameProps) {
  const { wordLength, maxGuesses } = DEFAULT_CONFIG
  const [answer, setAnswer] = useState<string>(() => pickAnswer([...ANSWER_WORDS]))
  const [rows, setRows] = useState<Row[]>(() => Array.from({ length: maxGuesses }, () => ({ guess: '', results: null })))
  const [current, setCurrent] = useState('')
  const [activeRow, setActiveRow] = useState(0)
  const [status, setStatus] = useState<WordleStatus>('playing')
  const [shake, setShake] = useState(false)

  const keys = useMemo(() => keyStates(rows), [rows])

  const submit = useCallback((guess: string) => {
    const valid = validateGuess(guess, wordLength)
    if (valid === null) {
      setShake(true)
      window.setTimeout(() => setShake(false), 400)
      return
    }
    if (!ACCEPTED_WORDS.includes(valid)) {
      setShake(true)
      window.setTimeout(() => setShake(false), 400)
      return
    }
    const results = evaluateGuess(valid, answer)
    setRows(prev => {
      const next = [...prev]
      next[activeRow] = { guess: valid, results }
      return next
    })
    const nextStatus = computeStatus(valid, answer, activeRow + 1, maxGuesses)
    setStatus(nextStatus)
    setCurrent('')
    setActiveRow(r => r + 1)
  }, [activeRow, answer, maxGuesses, wordLength])

  const onKey = useCallback((key: string) => {
    if (status !== 'playing') return
    if (key === 'ENTER') {
      if (current.length === wordLength) submit(current)
      return
    }
    if (key === 'BACK') {
      setCurrent(c => c.slice(0, -1))
      return
    }
    if (current.length < wordLength && /^[A-Z]$/.test(key)) {
      setCurrent(c => c + key)
    }
  }, [current, status, submit, wordLength])

  // Physical keyboard.
  useEffect(() => {
    const handler = (e: KeyboardEvent): void => {
      if (e.key === 'Enter') { onKey('ENTER'); return }
      if (e.key === 'Backspace') { onKey('BACK'); return }
      const up = e.key.toUpperCase()
      if (/^[A-Z]$/.test(up)) onKey(up)
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [onKey])

  const restart = useCallback(() => {
    setAnswer(pickAnswer([...ANSWER_WORDS]))
    setRows(Array.from({ length: maxGuesses }, () => ({ guess: '', results: null })))
    setCurrent('')
    setActiveRow(0)
    setStatus('playing')
  }, [maxGuesses])

  return (
    <div className={css.wrap}>
      <div className={css.header}>
        <h2 className={css.title}>Wordle</h2>
        <button type="button" className={css.closeBtn} onClick={onClose} aria-label={t('common.close')}>✕</button>
      </div>
      <div className={css.grid}>
        {rows.map((row, ri) => (
          <div key={ri} className={`${css.row} ${ri === activeRow && shake ? css.shake : ''}`}>
            {Array.from({ length: wordLength }).map((_, ci) => {
              const letter = ri === activeRow ? current[ci] ?? '' : row.guess[ci] ?? ''
              const result = row.results?.[ci]
              const state = result?.state ?? 'empty'
              return (
                <div key={ci} className={`${css.cell} ${css[state]}`}>
                  {letter}
                </div>
              )
            })}
          </div>
        ))}
      </div>
      {status !== 'playing' && (
        <div className={css.footer}>
          <span className={css.resultText}>
            {status === 'won' ? `🎉 ${t('wordle.won')}` : t('wordle.answer', { answer })}
          </span>
          <button type="button" className={css.actionBtn} onClick={restart}>{t('common.replay')}</button>
        </div>
      )}
      <div className={css.keyboard}>
        {KB_ROWS.map((rrow, ri) => (
          <div key={ri} className={css.kbRow}>
            {rrow.map(key => {
              const isAction = key === 'ENTER' || key === 'BACK'
              const state = keys[key]
              return (
                <button
                  key={key}
                  type="button"
                  className={`${css.key} ${isAction ? css.keyAction : ''} ${state ? css[state] : ''}`}
                  onClick={() => onKey(key)}
                >
                  {key === 'BACK' ? '⌫' : key}
                </button>
              )
            })}
          </div>
        ))}
      </div>
    </div>
  )
}
