/**
 * dsh-d399 (贪玩蓝鲸) — own i18n dictionaries.
 *
 * All user-visible UI copy of the plugin lives in the `dsh-d399`
 * namespace, registered through `ctx.locale.register` so DSH's native
 * translate chain renders zh/en. Components receive a typed `t` function
 * (from `ctx.locale.bind(NS)` in the overlay) and route every visible
 * string through it.
 *
 * The better-locale override path reuses the SAME key set: when the user
 * selects an override language and DSH is on `'en'`, the patched lookup
 * returns the per-language dict from `dictionaries.ts` for this namespace,
 * so every key here must also exist in every language dictionary. The key
 * union `D399Key` is the compile-time guarantee for that parity.
 *
 * Game *content* data (Wordle word lists, trivia/riddle/typing banks,
 * the 192-entry mini-game catalog names) is intentionally NOT part of the
 * key set — those datasets stay Chinese and are outside the i18n scope.
 *
 * @module @huanlin/dsh-plugin-d399/client/locales
 */

/** All copy keys for the dsh-d399 namespace (matches the dictionary key sets). */
export type D399Key =
  // Menu / overlay chrome
  | 'menu.title' | 'menu.dismiss' | 'menu.back' | 'menu.expandAll' | 'menu.collapseAll' | 'menu.empty'
  // Wordle
  | 'wordle.won' | 'wordle.answer'
  // Match-3
  | 'match3.title' | 'match3.hint'
  // Custom webpage bookmarks
  | 'webframe.openExternal' | 'webframe.sectionTitle' | 'webframe.namePlaceholder'
  | 'webframe.urlPlaceholder' | 'webframe.add' | 'webframe.deleteAria'
  // Common game chrome (shared across engines)
  | 'common.close' | 'common.replay' | 'common.start' | 'common.reset' | 'common.submit'
  | 'common.giveUp' | 'common.clear' | 'common.nextQuestion' | 'common.viewResult' | 'common.pause'
  | 'common.undo' | 'common.new' | 'common.guess' | 'common.roll' | 'common.done'
  | 'common.score' | 'common.moves' | 'common.remaining' | 'common.hits' | 'common.current'
  | 'common.best' | 'common.total' | 'common.balance' | 'common.you' | 'common.dealer'
  | 'common.draw' | 'common.target' | 'common.broke' | 'common.doneElapsed' | 'common.doneMoves'
  | 'common.complete' | 'common.revealAnswer' | 'common.yourAnswer' | 'common.nextOne'
  | 'common.correctLabel'
  // Clicker
  | 'clicker.title' | 'clicker.click'
  // Reaction
  | 'reaction.title' | 'reaction.round' | 'reaction.waiting' | 'reaction.go' | 'reaction.tooEarly'
  | 'reaction.avg' | 'reaction.roundsList' | 'reaction.hint'
  // Aim trainer
  | 'aim.title'
  // Whack-a-Mole
  | 'whack.title' | 'whack.timeUp'
  // Bubble wrap
  | 'bubble.title' | 'bubble.popped' | 'bubble.allDone'
  // Etch-a-Sketch
  | 'etch.title'
  // Pixel art
  | 'pixel.title'
  // Number guess
  | 'numguess.title' | 'numguess.enterNumber' | 'numguess.range' | 'numguess.tooSmall'
  | 'numguess.tooBig' | 'numguess.won' | 'numguess.guessed'
  // Math quiz
  | 'math.opAdd' | 'math.opSub' | 'math.opMul' | 'math.opDiv' | 'math.title' | 'math.result'
  | 'math.progress'
  // Trivia
  | 'trivia.history' | 'trivia.science' | 'trivia.geography' | 'trivia.sports' | 'trivia.movies'
  | 'trivia.literature' | 'trivia.codebase' | 'trivia.title' | 'trivia.result' | 'trivia.progress'
  // Hangman
  | 'hangman.title' | 'hangman.won'
  // Word scramble
  | 'scramble.title' | 'scramble.correct'
  // Typing
  | 'typing.title' | 'typing.done' | 'typing.segments' | 'typing.progress' | 'typing.hint'
  // Stroop
  | 'stroop.red' | 'stroop.green' | 'stroop.blue' | 'stroop.yellow' | 'stroop.purple' | 'stroop.orange'
  | 'stroop.titleWord' | 'stroop.titleColor' | 'stroop.progress' | 'stroop.result'
  | 'stroop.hintWord' | 'stroop.hintColor'
  // Riddle / fill-blank
  | 'riddle.title' | 'riddle.result' | 'riddle.progress' | 'riddle.revealed'
  // Coin flip
  | 'coin.title' | 'coin.heads' | 'coin.tails' | 'coin.won' | 'coin.hint'
  // Dice
  | 'dice.title' | 'dice.rollsLabel' | 'dice.won'
  // Spinner
  | 'spinner.title' | 'spinner.hit' | 'spinner.landed' | 'spinner.spinning' | 'spinner.spin'
  // Color match
  | 'colorpick.title' | 'colorpick.progress' | 'colorpick.result' | 'colorpick.word' | 'colorpick.hint'
  // Slots
  | 'slots.title' | 'slots.triple' | 'slots.smallWin' | 'slots.again' | 'slots.spinOne'
  // Blackjack
  | 'blackjack.title' | 'blackjack.dealerScore' | 'blackjack.playerScore' | 'blackjack.bust'
  | 'blackjack.win' | 'blackjack.push' | 'blackjack.dealerWins' | 'blackjack.betStart'
  | 'blackjack.hit' | 'blackjack.stand'
  // High or Low
  | 'highlow.title' | 'highlow.streak' | 'highlow.correct' | 'highlow.wrong' | 'highlow.betDraw'
  | 'highlow.higher' | 'highlow.lower'
  // War
  | 'war.title' | 'war.dealer' | 'war.progress' | 'war.won' | 'war.drawCard'
  // Cat clicker (idle)
  | 'catclick.total' | 'catclick.perClick' | 'catclick.upgrade' | 'catclick.hint'
  // Tic-Tac-Toe
  | 'ttt.title' | 'ttt.turn' | 'ttt.winner' | 'ttt.hintAi' | 'ttt.hintPvp' | 'ttt.winLen'
  // Memory
  | 'memory.title' | 'memory.matchedLabel' | 'memory.done'
  // Simon
  | 'simon.title' | 'simon.roundsLabel' | 'simon.won' | 'simon.lost' | 'simon.memorize' | 'simon.tap'
  // Lights Out
  | 'lights.title'
  // 15-puzzle
  | 'slide.title'
  // Peg solitaire
  | 'peg.title' | 'peg.perfect' | 'peg.hint'
  // Mastermind
  | 'mastermind.title' | 'mastermind.hintRow' | 'mastermind.clickColor' | 'mastermind.won'
  | 'mastermind.lost' | 'mastermind.legend'
  // 24 Game
  | 'twentyfour.title' | 'twentyfour.result' | 'twentyfour.progress' | 'twentyfour.correct'
  | 'twentyfour.placeholder'
  // Water pouring
  | 'water.title' | 'water.fill' | 'water.empty' | 'water.selected' | 'water.infeasible' | 'water.hint'
  // Tower of Hanoi
  | 'hanoi.title' | 'hanoi.optimal' | 'hanoi.done'
  // Connect Four
  | 'connect4.title' | 'connect4.red' | 'connect4.yellow' | 'connect4.turn' | 'connect4.winner'
  // Knight's tour
  | 'knight.title' | 'knight.visited' | 'knight.done' | 'knight.hint'
  // Minesweeper
  | 'mines.title' | 'mines.flagsLabel' | 'mines.won' | 'mines.lost' | 'mines.hint'
  // Sudoku
  | 'sudoku.title' | 'sudoku.erase'
  // Nonogram
  | 'nonogram.title' | 'nonogram.hint'
  // 2048
  | 'game2048.title' | 'game2048.won' | 'game2048.over'
  // N-Queens
  | 'nqueens.title' | 'nqueens.placed' | 'nqueens.hint'
  // One-stroke path
  | 'pathfind.title' | 'pathfind.done' | 'pathfind.stuck' | 'pathfind.hint'
  // Snake
  | 'snake.title' | 'snake.over'
  // Breakout
  | 'breakout.title' | 'breakout.livesLabel' | 'breakout.over' | 'breakout.won' | 'breakout.hint'
  // Pong
  | 'pong.title' | 'arcade.best' | 'pong.done'
  // Flappy
  | 'flappy.title' | 'flappy.hint'
  // Dodge
  | 'dodge.title' | 'dodge.over'
  // Dino Run
  | 'dino.title' | 'dino.hint'
  // Asteroids
  | 'asteroids.title' | 'asteroids.timeLabel' | 'asteroids.survived' | 'asteroids.hint'
  // Maze
  | 'maze.title' | 'maze.done'
  // Color sequence
  | 'colorseq.title' | 'colorseq.memorize' | 'colorseq.input' | 'colorseq.failed'
  | 'colorseq.wrong' | 'colorseq.passed'
  // Catch
  | 'catch.title' | 'catch.timeUp'
  // Shared arcade result copy
  | 'arcade.crashed'

/** Locale namespace id (matches the `cordis.patch.yml` plugin `id`). */
export const NS = 'dsh-d399'

/** The translate function shape components receive (`ctx.locale.bind(NS)`). */
export type Translate = (key: D399Key, params?: Record<string, unknown>) => string

/** Structural locale-service face (the real provider is the DSH locale package). */
export interface LocaleLike {
  register(ns: string, dicts: Record<string, Record<string, string>>): () => void
  bind(ns: string): (key: string, params?: Record<string, unknown>) => string
  subscribe(listener: () => void): () => void
}

/** Structural face of the better-locale override store (`ctx.betterLocale`). */
export interface BetterLocaleStoreLike {
  register(ns: string, dicts: Record<string, Record<string, string>>): () => void
}

/** English dictionary. */
export const en: Record<D399Key, string> = {
  // Menu / overlay chrome
  'menu.title': '🎮 Playful Games',
  'menu.dismiss': 'Dismiss',
  'menu.back': 'Menu',
  'menu.expandAll': 'Expand all',
  'menu.collapseAll': 'Collapse all',
  'menu.empty': 'No games available',
  // Wordle
  'wordle.won': 'You got it!',
  'wordle.answer': 'Answer: {answer}',
  // Match-3
  'match3.title': 'Match-3',
  'match3.hint': 'Tap two adjacent tiles to swap · clear 3 in a row',
  // Custom webpage bookmarks
  'webframe.openExternal': 'Open in new tab',
  'webframe.sectionTitle': 'Custom webpages',
  'webframe.namePlaceholder': 'Name (e.g. 2048)',
  'webframe.urlPlaceholder': 'URL (e.g. play2048.co)',
  'webframe.add': 'Add',
  'webframe.deleteAria': 'Delete {name}',
  // Common game chrome
  'common.close': 'Close',
  'common.replay': 'Play again',
  'common.start': 'Start',
  'common.reset': 'Reset',
  'common.submit': 'Submit',
  'common.giveUp': 'Give up',
  'common.clear': 'Clear',
  'common.nextQuestion': 'Next question',
  'common.viewResult': 'See results',
  'common.pause': 'Pause',
  'common.undo': 'Undo',
  'common.new': 'New round',
  'common.guess': 'Guess',
  'common.roll': 'Roll',
  'common.done': 'Done',
  'common.score': 'Score',
  'common.moves': 'Moves',
  'common.remaining': 'Left',
  'common.hits': 'Hits',
  'common.current': 'Current',
  'common.best': 'Best',
  'common.total': 'Total',
  'common.balance': 'Balance',
  'common.you': 'You',
  'common.dealer': 'Dealer',
  'common.draw': 'Draw',
  'common.target': 'Target',
  'common.broke': 'Broke!',
  'common.doneElapsed': 'Done! Took {s}s',
  'common.doneMoves': 'Done! {n} moves',
  'common.complete': 'Complete!',
  'common.revealAnswer': 'The answer is {answer}',
  'common.yourAnswer': 'Your answer',
  'common.nextOne': 'Next one',
  'common.correctLabel': 'right',
  // Clicker
  'clicker.title': 'Click {target} times',
  'clicker.click': 'Click me!',
  // Reaction
  'reaction.title': 'Reaction',
  'reaction.round': 'Round {round}/{total} · click to start',
  'reaction.waiting': 'Wait for green…',
  'reaction.go': 'Now!',
  'reaction.tooEarly': 'Too early! Click to retry',
  'reaction.avg': 'Average {avg}ms',
  'reaction.roundsList': 'Rounds: ',
  'reaction.hint': 'Click the moment it turns green; clicking while red is a violation',
  // Aim trainer
  'aim.title': 'Aim at {target} targets',
  // Whack-a-Mole
  'whack.title': 'Whack-a-Mole',
  'whack.timeUp': 'Time up! Score {score}',
  // Bubble wrap
  'bubble.title': 'Bubble wrap {size}×{size}',
  'bubble.popped': 'Popped',
  'bubble.allDone': 'All popped! Satisfying~',
  // Etch-a-Sketch
  'etch.title': 'Etch-a-Sketch {size}×{size}',
  // Pixel art
  'pixel.title': 'Pixel art {size}×{size}',
  // Number guess
  'numguess.title': 'Guess the number {min}-{max}',
  'numguess.enterNumber': 'Enter a number',
  'numguess.range': 'Range {min}-{max}',
  'numguess.tooSmall': '{g} is too small',
  'numguess.tooBig': '{g} is too big',
  'numguess.won': 'Correct! The answer is {answer} ({n} tries)',
  'numguess.guessed': 'Guessed',
  // Math quiz
  'math.opAdd': 'Addition',
  'math.opSub': 'Subtraction',
  'math.opMul': 'Multiplication',
  'math.opDiv': 'Division',
  'math.title': '{op} quiz',
  'math.result': '{correct} of {total} correct',
  'math.progress': 'Question {n}/{total}',
  // Trivia
  'trivia.history': 'History',
  'trivia.science': 'Science',
  'trivia.geography': 'Geography',
  'trivia.sports': 'Sports',
  'trivia.movies': 'Movies',
  'trivia.literature': 'Literature',
  'trivia.codebase': 'Codebase',
  'trivia.title': '{cat} quiz',
  'trivia.result': 'Finished {total} questions, {score} correct',
  'trivia.progress': '{n}/{total}',
  // Hangman
  'hangman.title': 'Hangman',
  'hangman.won': 'You got it!',
  // Word scramble
  'scramble.title': 'Word scramble',
  'scramble.correct': 'Correct! {answer}',
  // Typing
  'typing.title': 'Typing test',
  'typing.done': 'Done! Average {avg} WPM',
  'typing.segments': 'Segments: ',
  'typing.progress': 'Passage {n}/{total}',
  'typing.hint': 'Type the text above (case-sensitive)',
  // Stroop
  'stroop.red': 'Red',
  'stroop.green': 'Green',
  'stroop.blue': 'Blue',
  'stroop.yellow': 'Yellow',
  'stroop.purple': 'Purple',
  'stroop.orange': 'Orange',
  'stroop.titleWord': 'Stroop: read the word',
  'stroop.titleColor': 'Stroop: name the color',
  'stroop.progress': 'Round {n}/{total}',
  'stroop.result': '{score}/{total} rounds',
  'stroop.hintWord': 'Click the word meaning',
  'stroop.hintColor': 'Click the color the word is shown in',
  // Riddle / fill-blank
  'riddle.title': 'Riddles',
  'riddle.result': '{score} correct',
  'riddle.progress': '#{n}',
  'riddle.revealed': 'Answer: {a}',
  // Coin flip
  'coin.title': 'Coin streak {target}',
  'coin.heads': 'Heads',
  'coin.tails': 'Tails',
  'coin.won': 'Reached {target} in a row!',
  'coin.hint': 'Guess right to keep the streak; wrong resets it',
  // Dice
  'dice.title': '{count} dice · {target} pts',
  'dice.rollsLabel': 'Rolls',
  'dice.won': 'Reached {target} points!',
  // Spinner
  'spinner.title': 'Spinner · {segments} segments',
  'spinner.hit': 'Hit! {n}',
  'spinner.landed': 'Landed on {landed}; target {target}',
  'spinner.spinning': 'Spinning…',
  'spinner.spin': 'Spin',
  // Color match
  'colorpick.title': 'Color match',
  'colorpick.progress': '{n}/{total}',
  'colorpick.result': '{score}/{total} rounds',
  'colorpick.word': 'Color',
  'colorpick.hint': 'Tap the swatch matching the word color',
  // Slots
  'slots.title': 'Slots',
  'slots.triple': 'Triple! +{win}',
  'slots.smallWin': 'Small win +{win}',
  'slots.again': 'Try again',
  'slots.spinOne': 'Bet 1 & spin',
  // Blackjack
  'blackjack.title': 'Blackjack',
  'blackjack.dealerScore': 'Dealer ({score})',
  'blackjack.playerScore': 'You ({score})',
  'blackjack.bust': 'Bust',
  'blackjack.win': 'You win +{n}',
  'blackjack.push': 'Push +{n}',
  'blackjack.dealerWins': 'Dealer wins',
  'blackjack.betStart': 'Bet 1 & deal',
  'blackjack.hit': 'Hit',
  'blackjack.stand': 'Stand',
  // High or Low
  'highlow.title': 'High or Low',
  'highlow.streak': 'Streak',
  'highlow.correct': 'Right! Streak {n}',
  'highlow.wrong': 'Wrong',
  'highlow.betDraw': 'Bet 1 & draw',
  'highlow.higher': 'Higher ↑',
  'highlow.lower': 'Lower ↓',
  // War
  'war.title': 'War · {rounds} rounds',
  'war.dealer': 'House',
  'war.progress': '{n}/{total}',
  'war.won': 'You win!',
  'war.drawCard': 'Draw',
  // Cat clicker (idle)
  'catclick.total': 'Total',
  'catclick.perClick': 'Per click',
  'catclick.upgrade': 'Upgrade (costs {cost})',
  'catclick.hint': 'Click {emoji} to accumulate; upgrades raise output per click',
  // Tic-Tac-Toe
  'ttt.title': '{size}×{size} Tic-Tac-Toe',
  'ttt.turn': '{turn} turn',
  'ttt.winner': '{winner} wins',
  'ttt.hintAi': 'vs AI (random)',
  'ttt.hintPvp': 'Two players',
  'ttt.winLen': '{n} in a row',
  // Memory
  'memory.title': 'Memory · {pairs} pairs',
  'memory.matchedLabel': 'Matched',
  'memory.done': 'Done in {n} moves',
  // Simon
  'simon.title': 'Simon',
  'simon.roundsLabel': 'Rounds',
  'simon.won': 'Passed all {n} rounds!',
  'simon.lost': 'Failed on round {n}',
  'simon.memorize': 'Memorize the sequence…',
  'simon.tap': 'Tap in order',
  // Lights Out
  'lights.title': 'Lights Out {size}×{size}',
  // 15-puzzle
  'slide.title': '15-puzzle {size}×{size}',
  // Peg solitaire
  'peg.title': 'Peg solitaire {size}×{size}',
  'peg.perfect': 'Perfect! One peg left',
  'peg.hint': 'Pick a peg, jump over an adjacent one into an empty hole',
  // Mastermind
  'mastermind.title': 'Mastermind · {length} slots, {colors} colors',
  'mastermind.hintRow': '{black} black · {white} white',
  'mastermind.clickColor': 'Click to cycle colors',
  'mastermind.won': 'Cracked in {n} guesses',
  'mastermind.lost': 'Failed! The answer is {answer}',
  'mastermind.legend': 'Black=right color & spot · White=right color, wrong spot',
  // 24 Game
  'twentyfour.title': '24 Game',
  'twentyfour.result': '{correct}/{total} rounds',
  'twentyfour.progress': '24 Game {n}/{total}',
  'twentyfour.correct': 'Correct!',
  'twentyfour.placeholder': 'e.g. (3+3)*8/2',
  // Water pouring
  'water.title': 'Pouring · target {target}L',
  'water.fill': 'Fill',
  'water.empty': 'Empty',
  'water.selected': 'Selected jug {sel} ({cap}L)',
  'water.infeasible': 'This setup cannot measure the target; choose another puzzle',
  'water.hint': 'Select a source jug, then a target to pour into; or use Fill / Empty on the selected jug',
  // Tower of Hanoi
  'hanoi.title': 'Hanoi · {disks} disks',
  'hanoi.optimal': 'Optimal',
  'hanoi.done': 'Done in {n} moves (optimal {min})',
  // Connect Four
  'connect4.title': 'Connect Four {cols}×{rows}',
  'connect4.red': 'Red',
  'connect4.yellow': 'Yellow',
  'connect4.turn': '{color} turn',
  'connect4.winner': '{color} wins',
  // Knight's tour
  'knight.title': 'Knight tour {size}×{size}',
  'knight.visited': 'Visited',
  'knight.done': 'Tour complete!',
  'knight.hint': 'Click a start square, then walk every square in L-shapes',
  // Minesweeper
  'mines.title': 'Minesweeper · {mines} mines',
  'mines.flagsLabel': 'Flags',
  'mines.won': 'Cleared!',
  'mines.lost': 'Boom!',
  'mines.hint': 'Left click reveals · right click flags',
  // Sudoku
  'sudoku.title': 'Sudoku {size}×{size}',
  'sudoku.erase': 'Erase',
  // Nonogram
  'nonogram.title': 'Nonogram {size}×{size}',
  'nonogram.hint': 'Click to cycle: empty → fill → mark',
  // 2048
  'game2048.title': '2048 · reach {target}',
  'game2048.won': 'Reached {target}!',
  'game2048.over': 'No moves left',
  // N-Queens
  'nqueens.title': '{size} Queens',
  'nqueens.placed': 'Placed',
  'nqueens.hint': 'Place {n} queens that do not attack each other',
  // One-stroke path
  'pathfind.title': 'One-stroke path · {length} tiles',
  'pathfind.done': 'Done! All {n} tiles linked in one line',
  'pathfind.stuck': 'No reachable tiles left — undo a few steps or reset',
  'pathfind.hint': 'Start anywhere, walk all {length} tiles consecutively (adjacent, no repeats); lit tiles are the next moves',
  // Snake
  'snake.title': 'Snake {size}×{size}',
  'snake.over': 'Game over! Score {score}',
  // Breakout
  'breakout.title': 'Breakout',
  'breakout.livesLabel': 'Lives',
  'breakout.over': 'Game over! {score} pts',
  'breakout.won': 'Cleared! {score} pts',
  'breakout.hint': 'Mouse controls the paddle · or use ← →',
  // Pong
  'pong.title': 'Pong',
  'arcade.best': 'Best',
  'pong.done': 'Kept the ball alive {score} times',
  // Flappy
  'flappy.title': 'Flappy',
  'flappy.hint': 'Click the canvas or press Space to fly',
  // Dodge
  'dodge.title': 'Dodge {size}×{size}',
  'dodge.over': 'Score {score}',
  // Dino Run
  'dino.title': 'Dino Run',
  'dino.hint': 'Click or press Space to jump',
  // Asteroids
  'asteroids.title': 'Asteroids',
  'asteroids.timeLabel': 'Time',
  'asteroids.survived': 'Survived {time}s',
  'asteroids.hint': '↑ thrust · ← → steer · Space to start',
  // Maze
  'maze.title': 'Maze {size}×{size}',
  'maze.done': 'Cleared! {n} steps',
  // Color sequence
  'colorseq.title': 'Color sequence · {length}',
  'colorseq.memorize': 'Memorize…',
  'colorseq.input': 'Enter {n}/{total}',
  'colorseq.failed': 'Failed',
  'colorseq.wrong': 'Wrong!',
  'colorseq.passed': 'Passed!',
  // Catch
  'catch.title': 'Catch',
  'catch.timeUp': 'Time up! {score} pts',
  // Shared arcade result copy
  'arcade.crashed': 'Crashed! {score} pts',
}

/** Chinese dictionary. */
export const zh: Record<D399Key, string> = {
  // Menu / overlay chrome
  'menu.title': '🎮 贪玩蓝鲸',
  'menu.dismiss': '关闭提醒',
  'menu.back': '菜单',
  'menu.expandAll': '全部展开',
  'menu.collapseAll': '全部收起',
  'menu.empty': '暂无可用游戏',
  // Wordle
  'wordle.won': '猜对了！',
  'wordle.answer': '答案: {answer}',
  // Match-3
  'match3.title': '消消乐',
  'match3.hint': '点选相邻方块交换 · 三个同色消除',
  // Custom webpage bookmarks
  'webframe.openExternal': '在新标签页打开',
  'webframe.sectionTitle': '自定义网页',
  'webframe.namePlaceholder': '名称（如：2048）',
  'webframe.urlPlaceholder': '网址（如：play2048.co）',
  'webframe.add': '添加',
  'webframe.deleteAria': '删除 {name}',
  // Common game chrome
  'common.close': '关闭',
  'common.replay': '再来',
  'common.start': '开始',
  'common.reset': '重置',
  'common.submit': '提交',
  'common.giveUp': '放弃',
  'common.clear': '清空',
  'common.nextQuestion': '下一题',
  'common.viewResult': '查看结果',
  'common.pause': '暂停',
  'common.undo': '撤销',
  'common.new': '新局',
  'common.guess': '猜',
  'common.roll': '投掷',
  'common.done': '完成',
  'common.score': '分数',
  'common.moves': '步数',
  'common.remaining': '剩余',
  'common.hits': '命中',
  'common.current': '当前',
  'common.best': '最佳',
  'common.total': '累计',
  'common.balance': '余额',
  'common.you': '你',
  'common.dealer': '庄家',
  'common.draw': '平局',
  'common.target': '目标',
  'common.broke': '破产！',
  'common.doneElapsed': '完成！用时 {s}s',
  'common.doneMoves': '完成！{n} 步',
  'common.complete': '完成！',
  'common.revealAnswer': '答案是 {answer}',
  'common.yourAnswer': '你的答案',
  'common.nextOne': '下一个',
  'common.correctLabel': '对',
  // Clicker
  'clicker.title': '连点 {target} 次',
  'clicker.click': '点我！',
  // Reaction
  'reaction.title': '反应速度',
  'reaction.round': '第 {round}/{total} 轮 · 点击开始',
  'reaction.waiting': '等待绿色…',
  'reaction.go': '点！',
  'reaction.tooEarly': '太早了！点击重试',
  'reaction.avg': '平均 {avg}ms',
  'reaction.roundsList': '各轮: ',
  'reaction.hint': '看到绿色立即点击；红时点算违规',
  // Aim trainer
  'aim.title': '瞄准 {target} 目标',
  // Whack-a-Mole
  'whack.title': '打地鼠',
  'whack.timeUp': '时间到！得分 {score}',
  // Bubble wrap
  'bubble.title': '泡泡纸 {size}×{size}',
  'bubble.popped': '已戳',
  'bubble.allDone': '全部戳完！治愈~',
  // Etch-a-Sketch
  'etch.title': '画板 {size}×{size}',
  // Pixel art
  'pixel.title': '像素画 {size}×{size}',
  // Number guess
  'numguess.title': '猜数字 {min}-{max}',
  'numguess.enterNumber': '请输入数字',
  'numguess.range': '范围 {min}-{max}',
  'numguess.tooSmall': '{g} 太小',
  'numguess.tooBig': '{g} 太大',
  'numguess.won': '猜对！答案是 {answer}（{n} 次）',
  'numguess.guessed': '已猜',
  // Math quiz
  'math.opAdd': '加法',
  'math.opSub': '减法',
  'math.opMul': '乘法',
  'math.opDiv': '除法',
  'math.title': '{op}测验',
  'math.result': '{total} 题对 {correct} 题',
  'math.progress': '第 {n}/{total} 题',
  // Trivia
  'trivia.history': '历史',
  'trivia.science': '科学',
  'trivia.geography': '地理',
  'trivia.sports': '体育',
  'trivia.movies': '电影',
  'trivia.literature': '文学',
  'trivia.codebase': '代码库',
  'trivia.title': '{cat}问答',
  'trivia.result': '完成 {total} 题，对 {score} 题',
  'trivia.progress': '第 {n}/{total}',
  // Hangman
  'hangman.title': '猜单词',
  'hangman.won': '猜对了！',
  // Word scramble
  'scramble.title': '字母重组',
  'scramble.correct': '对了！{answer}',
  // Typing
  'typing.title': '打字测试',
  'typing.done': '完成！平均 {avg} WPM',
  'typing.segments': '各段: ',
  'typing.progress': '第 {n}/{total} 段',
  'typing.hint': '输入上方文本（区分大小写）',
  // Stroop
  'stroop.red': '红',
  'stroop.green': '绿',
  'stroop.blue': '蓝',
  'stroop.yellow': '黄',
  'stroop.purple': '紫',
  'stroop.orange': '橙',
  'stroop.titleWord': '斯特鲁普：读字',
  'stroop.titleColor': '斯特鲁普：说色',
  'stroop.progress': '第 {n}/{total} 轮',
  'stroop.result': '{total} 轮对 {score} 轮',
  'stroop.hintWord': '点击字面意思',
  'stroop.hintColor': '点击字的显示颜色',
  // Riddle / fill-blank
  'riddle.title': '脑筋急转弯',
  'riddle.result': '答对 {score} 题',
  'riddle.progress': '第 {n}',
  'riddle.revealed': '答案：{a}',
  // Coin flip
  'coin.title': '硬币连胜 {target}',
  'coin.heads': '正',
  'coin.tails': '反',
  'coin.won': '达成 {target} 连胜！',
  'coin.hint': '猜对继续连胜，猜错归零',
  // Dice
  'dice.title': '{count}骰子 {target}分',
  'dice.rollsLabel': '投掷',
  'dice.won': '达成 {target} 分！',
  // Spinner
  'spinner.title': '轮盘 {segments} 格',
  'spinner.hit': '中了！{n}',
  'spinner.landed': '落在 {landed}，目标是 {target}',
  'spinner.spinning': '旋转中…',
  'spinner.spin': '旋转',
  // Color match
  'colorpick.title': '辨色',
  'colorpick.progress': '第 {n}/{total}',
  'colorpick.result': '{total} 轮对 {score}',
  'colorpick.word': '颜色',
  'colorpick.hint': '点击与文字颜色匹配的色块',
  // Slots
  'slots.title': '老虎机',
  'slots.triple': '三连！+{win}',
  'slots.smallWin': '小奖 +{win}',
  'slots.again': '再来一次',
  'slots.spinOne': '投 1 旋转',
  // Blackjack
  'blackjack.title': '21点',
  'blackjack.dealerScore': '庄家 ({score})',
  'blackjack.playerScore': '你 ({score})',
  'blackjack.bust': '爆牌',
  'blackjack.win': '你赢了 +{n}',
  'blackjack.push': '平局 +{n}',
  'blackjack.dealerWins': '庄家赢',
  'blackjack.betStart': '投 1 开始',
  'blackjack.hit': '要牌',
  'blackjack.stand': '停牌',
  // High or Low
  'highlow.title': '大小猜牌',
  'highlow.streak': '连胜',
  'highlow.correct': '对！连胜 {n}',
  'highlow.wrong': '错了',
  'highlow.betDraw': '投 1 抽牌',
  'highlow.higher': '更大 ↑',
  'highlow.lower': '更小 ↓',
  // War
  'war.title': '战争 {rounds} 轮',
  'war.dealer': '庄',
  'war.progress': '第 {n}/{total}',
  'war.won': '你赢了！',
  'war.drawCard': '抽牌',
  // Cat clicker (idle)
  'catclick.total': '总数',
  'catclick.perClick': '每次',
  'catclick.upgrade': '升级 (花费 {cost})',
  'catclick.hint': '点击 {emoji} 累计计数，升级提高每次产出',
  // Tic-Tac-Toe
  'ttt.title': '{size}×{size} 井字棋',
  'ttt.turn': '轮到 {turn}',
  'ttt.winner': '{winner} 胜',
  'ttt.hintAi': '对 AI（随机）',
  'ttt.hintPvp': '双人对战',
  'ttt.winLen': '{n} 连胜',
  // Memory
  'memory.title': '记忆翻牌 {pairs} 对',
  'memory.matchedLabel': '已配',
  'memory.done': '完成！用了 {n} 步',
  // Simon
  'simon.title': '西蒙记忆',
  'simon.roundsLabel': '回合',
  'simon.won': '通关！{n} 回合全过',
  'simon.lost': '失败于第 {n} 回合',
  'simon.memorize': '记住顺序…',
  'simon.tap': '按顺序点击',
  // Lights Out
  'lights.title': '熄灯 {size}×{size}',
  // 15-puzzle
  'slide.title': '数字华容道 {size}×{size}',
  // Peg solitaire
  'peg.title': '独立钻石 {size}×{size}',
  'peg.perfect': '完美！只剩一颗',
  'peg.hint': '选一颗，跳过相邻珠子到空位（吃掉中间）',
  // Mastermind
  'mastermind.title': '大师码 {length}位{colors}色',
  'mastermind.hintRow': '黑 {black} · 白 {white}',
  'mastermind.clickColor': '点击切换颜色',
  'mastermind.won': '破解！用了 {n} 次',
  'mastermind.lost': '失败！答案是 {answer}',
  'mastermind.legend': '黑=对色对位 · 白=对色错位',
  // 24 Game
  'twentyfour.title': '算24点',
  'twentyfour.result': '{total} 轮答对 {correct} 轮',
  'twentyfour.progress': '算24点 第{n}/{total}',
  'twentyfour.correct': '答对！',
  'twentyfour.placeholder': '如: (3+3)*8/2',
  // Water pouring
  'water.title': '倒水 目标{target}L',
  'water.fill': '灌满',
  'water.empty': '倒空',
  'water.selected': '已选 {sel} 号瓶（{cap}L）',
  'water.infeasible': '此配置无法量出目标，请选择其他谜题',
  'water.hint': '先选源瓶，再选目标瓶倒入；或对已选瓶「灌满 / 倒空」',
  // Tower of Hanoi
  'hanoi.title': '汉诺塔 {disks}盘',
  'hanoi.optimal': '最优',
  'hanoi.done': '完成！{n} 步（最优 {min}）',
  // Connect Four
  'connect4.title': '四连棋 {cols}×{rows}',
  'connect4.red': '红',
  'connect4.yellow': '黄',
  'connect4.turn': '轮到 {color}',
  'connect4.winner': '{color} 胜',
  // Knight's tour
  'knight.title': '骑士巡游 {size}×{size}',
  'knight.visited': '已走',
  'knight.done': '完成巡游！',
  'knight.hint': '点击起点 → 按 L 字走遍所有格子',
  // Minesweeper
  'mines.title': '扫雷 {mines}雷',
  'mines.flagsLabel': '旗',
  'mines.won': '通关！',
  'mines.lost': '踩雷了',
  'mines.hint': '左键揭示 · 右键插旗',
  // Sudoku
  'sudoku.title': '数独 {size}×{size}',
  'sudoku.erase': '清',
  // Nonogram
  'nonogram.title': '数织 {size}×{size}',
  'nonogram.hint': '点击循环：空 → 填 → 标记',
  // 2048
  'game2048.title': '2048 目标{target}',
  'game2048.won': '达成 {target}！',
  'game2048.over': '无可移动',
  // N-Queens
  'nqueens.title': '{size}皇后',
  'nqueens.placed': '已放',
  'nqueens.hint': '放 {n} 个皇后互不攻击',
  // One-stroke path
  'pathfind.title': '一笔画 {length}格',
  'pathfind.done': '完成！{n} 格全部连成一条线',
  'pathfind.stuck': '没有可走的格子了——撤销几步换条路线，或重置重来',
  'pathfind.hint': '从任意格子开始，一格接一格走完全部 {length} 格（必须相邻、不能重复），亮格是可走的下一点',
  // Snake
  'snake.title': '贪吃蛇 {size}×{size}',
  'snake.over': '游戏结束！分数 {score}',
  // Breakout
  'breakout.title': '打砖块',
  'breakout.livesLabel': '命',
  'breakout.over': '游戏结束！{score} 分',
  'breakout.won': '通关！{score} 分',
  'breakout.hint': '鼠标控制挡板 · 也可用 ← →',
  // Pong
  'pong.title': '弹球接龙',
  'arcade.best': '最高',
  'pong.done': '接了 {score} 下',
  // Flappy
  'flappy.title': '飞翔小鸟',
  'flappy.hint': '点击画布或空格起飞',
  // Dodge
  'dodge.title': '闪避 {size}×{size}',
  'dodge.over': '分数 {score}',
  // Dino Run
  'dino.title': '恐龙跑酷',
  'dino.hint': '点击或空格跳跃',
  // Asteroids
  'asteroids.title': '陨石躲避',
  'asteroids.timeLabel': '时间',
  'asteroids.survived': '存活 {time} 秒',
  'asteroids.hint': '↑ 推进 · ← → 转向 · 空格开始',
  // Maze
  'maze.title': '迷宫 {size}×{size}',
  'maze.done': '通关！{n} 步',
  // Color sequence
  'colorseq.title': '色序记忆 {length}',
  'colorseq.memorize': '记住…',
  'colorseq.input': '输入 {n}/{total}',
  'colorseq.failed': '失败',
  'colorseq.wrong': '错了！',
  'colorseq.passed': '通过！',
  // Catch
  'catch.title': '接物品',
  'catch.timeUp': '时间到！{score} 分',
  // Shared arcade result copy
  'arcade.crashed': '挂了！{score} 分',
}