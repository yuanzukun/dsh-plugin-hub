/**
 * D399Overlay — the main贪玩蓝鲸 overlay.
 *
 * Three display states:
 *   - `hidden`: nothing rendered.
 *   - `teaser`: model is generating; a small card pops up in the
 *     bottom-right corner with the configured message + button.
 *   - `menu`: the user clicked the teaser button; a game menu opens.
 *   - `playing`: a game is mounted.
 *
 * Lifecycle (per the design contract): the teaser auto-shows on the
 * `running: false→true` edge and auto-hides on `true→false`, UNLESS the
 * user has opened the menu or a game — in that case the overlay stays
 * until the user manually closes it. The next generation cycle re-arms
 * the teaser.
 *
 * @module @huanlin/dsh-plugin-d399/client/D399Overlay
 */
import { useEffect, useMemo, useState } from 'react'
import { createPortal } from 'react-dom'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import { useSyncExternalStore } from 'react'
import { getRegistrySnapshot, subscribeRegistry, type D399GamesService, type Game, type GameGroup } from './registry.ts'
import { useSessionRunning } from './useSessionRunning.ts'
import type { BookmarkStore } from './games/webframe/bookmarks.ts'
import { BookmarkPanel } from './games/webframe/BookmarkPanel.tsx'
import { NS, type Translate } from './locales.ts'
import css from './D399.module.css'

/** Display mode of the overlay. */
type Mode = 'hidden' | 'teaser' | 'menu' | 'playing'

/** Plugin config (mirrors cordis.patch.yml defaults, overridable per-deployment). */
export interface D399Config {
  enabled: boolean
  message: string
  buttonText: string
}

/**
 * Bind the plugin's translate function and re-render on locale changes
 * (DSH locale switch or a better-locale override bump both notify the
 * locale service subscribers). The bound `t` reads the active locale at
 * call time, so a fresh render picks up the new language immediately.
 */
function useLocaleT(ctx: ClientContext): Translate {
  const [revision, setRevision] = useState(0)
  useEffect(() => ctx.locale.subscribe(() => setRevision(r => r + 1)), [ctx])
  const t = useMemo(() => ctx.locale.bind(NS) as Translate, [ctx])
  void revision
  return t
}

/** Menu display name: localized titleKey (e.g. match3) or the literal name. */
function gameTitle(g: Game, t: Translate): string {
  return g.titleKey !== undefined ? t(g.titleKey) : g.name
}

/** Subscribe to the game registry snapshot (useSyncExternalStore glue). */
function useGames(registry: D399GamesService): readonly Game[] {
  return useSyncExternalStore(
    (cb) => subscribeRegistry(registry, cb),
    () => getRegistrySnapshot(registry),
    () => getRegistrySnapshot(registry),
  )
}

/** One foldable group plus its member games (insertion order kept). */
interface GameGroupEntry {
  group: GameGroup
  games: Game[]
}

/** Bucket games into foldable groups (group present + >1 member) and standalone games. */
function bucketGames(games: readonly Game[]): { groups: GameGroupEntry[]; standalone: Game[] } {
  const map = new Map<string, GameGroupEntry>()
  const standalone: Game[] = []
  for (const g of games) {
    if (g.group === undefined) {
      standalone.push(g)
      continue
    }
    let entry = map.get(g.group.id)
    if (entry === undefined) {
      entry = { group: g.group, games: [] }
      map.set(g.group.id, entry)
    }
    entry.games.push(g)
  }
  const groups: GameGroupEntry[] = []
  for (const entry of map.values()) {
    // A group with a single member is rendered as a standalone card instead.
    if (entry.games.length > 1) groups.push(entry)
    else standalone.push(entry.games[0]!)
  }
  return { groups, standalone }
}

/**
 * @param ctx - client root context.
 * @param registry - the d399Games service (games list source).
 * @param config - resolved plugin config.
 * @param bookmarkStore - the custom-webpage bookmark store (for the add-UI).
 */
export function D399Overlay({ ctx, registry, config, bookmarkStore }: {
  ctx: ClientContext
  registry: D399GamesService
  config: D399Config
  bookmarkStore: BookmarkStore
}) {
  const running = useSessionRunning(ctx)
  const games = useGames(registry)
  const t = useLocaleT(ctx)
  const [mode, setMode] = useState<Mode>('hidden')
  /** Whether the user dismissed the teaser this generation cycle. */
  const [dismissedThisCycle, setDismissedThisCycle] = useState(false)
  /** The currently-selected game id (when mode === 'playing'). */
  const [activeGameId, setActiveGameId] = useState<string | null>(null)

  // Bucket games into foldable groups + standalone entries.
  const { groups, standalone } = useMemo(() => bucketGames(games), [games])
  /** Collapsed group ids (all groups start collapsed). */
  const [collapsed, setCollapsed] = useState<Set<string>>(() => new Set(groups.map(g => g.group.id)))
  const allCollapsed = groups.length > 0 && groups.every(g => collapsed.has(g.group.id))

  const toggleGroup = (id: string): void => {
    setCollapsed(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }
  const toggleAll = (): void => {
    setCollapsed(allCollapsed ? new Set() : new Set(groups.map(g => g.group.id)))
  }

  // Arm the teaser on the running false→true edge; disarm on true→false
  // unless the user is in the menu or playing a game (those stay open).
  useEffect(() => {
    if (running) {
      if (!dismissedThisCycle && mode === 'hidden') {
        setMode('teaser')
      }
    } else {
      // Generation ended: hide the teaser, but keep menu/playing open.
      setDismissedThisCycle(false)
      setMode(prev => prev === 'teaser' ? 'hidden' : prev)
    }
    // We only want to react to `running` edges, not mode/dismissed changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running])

  // Reset everything when disabled.
  useEffect(() => {
    if (!config.enabled) setMode('hidden')
  }, [config.enabled])

  if (!config.enabled || mode === 'hidden') return null

  const openMenu = (): void => {
    setMode('menu')
    setDismissedThisCycle(true)
  }

  const closeAll = (): void => {
    setMode('hidden')
    setActiveGameId(null)
  }

  const startGame = (id: string): void => {
    setActiveGameId(id)
    setMode('playing')
  }

  const backToMenu = (): void => {
    setActiveGameId(null)
    setMode('menu')
  }

  const activeGame = activeGameId !== null ? games.find(g => g.id === activeGameId) : undefined

  return createPortal(
    <div className={css.overlay}>
      {mode === 'teaser' && (
        <div className={css.teaser}>
          <span className={css.teaserMsg}>{config.message}</span>
          <button type="button" className={css.teaserBtn} onClick={openMenu}>
            {config.buttonText}
          </button>
          <button type="button" className={css.teaserClose} onClick={() => { setMode('hidden'); setDismissedThisCycle(true) }} aria-label={t('menu.dismiss')}>✕</button>
        </div>
      )}
      {mode === 'menu' && (
        <div className={css.menu}>
          <div className={css.menuHeader}>
            <span className={css.menuTitle}>{t('menu.title')}</span>
            <button type="button" className={css.closeBtn} onClick={closeAll}>✕</button>
          </div>
          <div className={css.gameList}>
            {games.length === 0 && <span className={css.empty}>{t('menu.empty')}</span>}
            {groups.length > 1 && (
              <button type="button" className={css.foldAll} onClick={toggleAll}>
                {allCollapsed ? t('menu.expandAll') : t('menu.collapseAll')}
              </button>
            )}
            {standalone.map(g => (
              <button key={g.id} type="button" className={css.gameCard} onClick={() => startGame(g.id)}>
                {g.icon !== undefined && <span className={css.gameIcon}>{g.icon}</span>}
                <span className={css.gameName}>{gameTitle(g, t)}</span>
              </button>
            ))}
            {groups.map(({ group, games: memberGames }) => {
              const isCollapsed = collapsed.has(group.id)
              return (
                <div key={group.id} className={css.foldGroup}>
                  <button
                    type="button"
                    className={`${css.foldHeader} ${isCollapsed ? css.foldHeaderCollapsed : ''}`}
                    onClick={() => toggleGroup(group.id)}
                  >
                    <span className={css.foldCaret}>{isCollapsed ? '▸' : '▾'}</span>
                    {group.icon !== undefined && <span className={css.gameIcon}>{group.icon}</span>}
                    <span className={css.gameName}>{group.name}</span>
                    <span className={css.foldCount}>{memberGames.length}</span>
                  </button>
                  {!isCollapsed && (
                    <div className={css.foldBody}>
                      {memberGames.map(g => (
                        <button key={g.id} type="button" className={css.gameCardNested} onClick={() => startGame(g.id)}>
                          <span className={css.gameName}>{gameTitle(g, t)}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
          <BookmarkPanel
            store={bookmarkStore}
            t={t}
            onOpenBookmark={(key) => startGame(`webframe:${key}`)}
          />
        </div>
      )}
      {mode === 'playing' && activeGame !== undefined && (
        <div className={css.gameModal}>
          <div className={css.gameHeader}>
            <button type="button" className={css.backBtn} onClick={backToMenu}>← {t('menu.back')}</button>
            <span className={css.gameTitle}>{activeGame.icon !== undefined ? `${activeGame.icon} ` : ''}{activeGame.name}</span>
            <button type="button" className={css.closeBtn} onClick={closeAll}>✕</button>
          </div>
          <div className={css.gameBody}>
            <activeGame.Component onClose={backToMenu} t={t} />
          </div>
        </div>
      )}
    </div>,
    document.body,
  )
}
