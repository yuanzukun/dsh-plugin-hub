/**
 * dsh-d399 (贪玩蓝鲸) — browser half.
 *
 * Single bundle, dual entry: this is the client half (exports `./client`).
 * Host half ships via `.` (see `src/index.ts`).
 *
 * Responsibilities:
 *   - Expose the `d399Games` cordis service (`ctx.d399Games`) so third-party
 *     plugins can register more games (`inject: ['d399Games']`).
 *   - Register the built-in game set (wordle + match-3).
 *   - Mount the D399 overlay on `document.body`: watches the current
 *     session's `running` flag, pops a teaser while the model is generating,
 *     and opens a game menu when the user clicks the teaser button.
 *
 * @module @huanlin/dsh-plugin-d399/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import { createElement } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { D399Overlay, type D399Config } from './D399Overlay.tsx'
import { createGameRegistry, type D399GamesService } from './registry.ts'
import { registerBuiltinGames } from './games/index.ts'
import { BookmarkStore } from './games/webframe/bookmarks.ts'
import { NS, en, zh, type BetterLocaleStoreLike, type LocaleLike } from './locales.ts'
import { dicts } from './dictionaries.ts'

export type { D399GamesService } from './registry.ts'
export type { GameProps } from './games/types.ts'

/** Declaration merge: expose `ctx.d399Games` to consumers. */
declare module '@deepseek-ai/cordis' {
  interface Context {
    /** The d399 game registry service (provided by this plugin). */
    d399Games?: D399GamesService
    /**
     * DSH's locale service (provided by @deepseek-ai/dsh-client-locale),
     * merged structurally here — the locale package's own merge is not
     * imported into this bundle's compilation.
     */
    locale: LocaleLike
    /**
     * The better-locale override store (provided by dsh-plugin-better-locale),
     * read via `ctx.get` — absent when better-locale is not installed.
     */
    betterLocale?: BetterLocaleStoreLike
  }
}

/** Required services: the client runtime (sessions + effect + provide) + locale. */
export const inject = ['sessions', 'locale']

/** Default config (overridable via cordis.patch.yml `config` block). */
const DEFAULT_CONFIG: D399Config = {
  enabled: true,
  message: '❤深❤夜❤寂❤寞❤，❤来❤玩❤ D399❤',
  buttonText: '来♂',
}

/** Resolve the config from the (loosely-typed) cordis row config. */
function resolveConfig(raw: unknown): D399Config {
  if (raw === null || typeof raw !== 'object') return DEFAULT_CONFIG
  const r = raw as Record<string, unknown>
  return {
    enabled: typeof r.enabled === 'boolean' ? r.enabled : DEFAULT_CONFIG.enabled,
    message: typeof r.message === 'string' && r.message !== '' ? r.message : DEFAULT_CONFIG.message,
    buttonText: typeof r.buttonText === 'string' && r.buttonText !== '' ? r.buttonText : DEFAULT_CONFIG.buttonText,
  }
}

/**
 * Client plugin body: provide the d399Games service, register built-in
 * games, and mount the overlay.
 * @param ctx - client root context.
 * @param config - cordis row config (loosely typed; resolved to D399Config).
 */
export function apply(ctx: ClientContext, config?: unknown): void {
  const resolved = resolveConfig(config)
  const registry = createGameRegistry()
  const bookmarkStore = new BookmarkStore(registry)

  // Expose as a cordis service so third-party plugins can `inject: ['d399Games']`.
  ctx.provide('d399Games', registry)

  // Register the plugin's own copy namespace with DSH's locale service:
  // zh/en dictionaries (the DSH translate chain renders both languages).
  ctx.effect(
    () => ctx.locale.register(NS, { zh, en }),
    'dsh-d399: own copy namespace',
  )

  // Register the better-locale override dictionaries. Reuses the SAME key
  // set as the zh/en copy, so picking an override language (and DSH being
  // on `en`) renders every translation from dictionaries.ts. Optional —
  // no-op when better-locale is not installed.
  // Activation-order-safe: re-check ctx.get('betterLocale') on every locale
  // revision bump (better-locale bumps on activation + override switch).
  ctx.effect(() => {
    let dispose: (() => void) | undefined
    const sync = (): void => {
      dispose?.()
      dispose = undefined
      const store = ctx.get('betterLocale') as
        | { register(ns: string, dicts: Record<string, Record<string, string>>): () => void }
        | undefined
      if (store !== undefined) {
        dispose = store.register(NS, dicts as Record<string, Record<string, string>>)
      }
    }
    sync()
    const unsubscribe = ctx.locale.subscribe(sync)
    return () => {
      unsubscribe()
      dispose?.()
    }
  }, 'dsh-d399: better-locale override dicts')

  // Register the built-in game set; disposal rides ctx.effect.
  ctx.effect(() => registerBuiltinGames(registry), 'dsh-d399: built-in games')

  // Dispose the bookmark store on teardown (clears its game registrations).
  ctx.effect(() => () => bookmarkStore.dispose(), 'dsh-d399: bookmark store')

  // Mount the overlay on document.body (portal target set after mount).
  ctx.effect(() => {
    let disposed = false
    let root: Root | undefined
    let host: HTMLDivElement | undefined
    void (async () => {
      if (disposed) return
      try {
        host = document.createElement('div')
        host.setAttribute('data-dsh-d399', '')
        document.body.appendChild(host)
        root = createRoot(host)
        root.render(createElement(D399Overlay, { ctx, registry, config: resolved, bookmarkStore }))
        console.log('[dsh-d399] overlay mounted ✓ (games:', registry.list().map(g => g.id).join(','), ')')
      } catch (error) {
        console.error('[dsh-d399] mount error:', error)
      }
    })()
    return () => {
      disposed = true
      root?.unmount()
      host?.remove()
    }
  }, 'dsh-d399: overlay mount')
}
