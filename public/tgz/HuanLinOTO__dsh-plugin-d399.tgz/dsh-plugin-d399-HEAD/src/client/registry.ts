/**
 * The d399Games client service contract: a registry of mini-games that the
 * D399 overlay renders in its game menu. Built-in games (wordle, match-3)
 * register themselves in `apply`; third-party plugins register more through
 * `ctx.d399Games.register(...)` with `inject: ['d399Games']`.
 *
 * @module @huanlin/dsh-plugin-d399/client/registry
 */
import type { ComponentType } from 'react'
import type { GameProps } from './games/types.ts'
import type { D399Key } from './locales.ts'

export type { GameProps }

/** A foldable group of game variants shown as one menu entry. */
export interface GameGroup {
  /** Stable unique id (used as React key and collapse state identity). */
  id: string
  /** Display name shown in the group header. */
  name: string
  /** Optional emoji/icon glyph rendered before the group name. */
  icon?: string
}

/** One registrable game entry. */
export interface Game {
  /** Stable unique id (used as React key and dedup identity). */
  id: string
  /** Display name shown in the menu button. */
  name: string
  /** Optional emoji/icon glyph rendered before the name in the menu. */
  icon?: string
  /** The game component; mounted when the user picks this game. */
  Component: ComponentType<GameProps>
  /**
   * Optional localized menu name. When present, the overlay renders
   * `t(titleKey)` instead of `name` (names are otherwise content data —
   * third-party games and the mini catalog keep their literal display name).
   */
  titleKey?: D399Key
  /**
   * Optional group. Games sharing a group id collapse into one foldable
   * menu entry (header + expandable variant list); absent = standalone.
   */
  group?: GameGroup
}

/** The registry service face exposed as `ctx.d399Games`. */
export interface D399GamesService {
  /**
   * Register one game. Re-registering the same id replaces the entry.
   * @returns a disposer that removes the entry.
   */
  register(game: Game): () => void
  /** Snapshot of currently registered games (insertion order). */
  list(): readonly Game[]
  /** Subscribe to registry changes (add/replace/remove); returns unsubscribe. */
  subscribe(listener: () => void): () => void
}

/** Create a fresh registry instance (one per client plugin activation). */
export function createGameRegistry(): D399GamesService {
  const games = new Map<string, Game>()
  const order: string[] = []
  const listeners = new Set<() => void>()
  let version = 0
  let snapshotCache: readonly Game[] | null = null

  const notify = (): void => {
    version++
    snapshotCache = null
    for (const fn of listeners) fn()
  }

  return {
    register(game) {
      const existing = games.get(game.id)
      if (existing === undefined) order.push(game.id)
      games.set(game.id, game)
      notify()
      return () => {
        if (games.get(game.id) !== game) return
        games.delete(game.id)
        const at = order.indexOf(game.id)
        if (at !== -1) order.splice(at, 1)
        notify()
      }
    },
    list() {
      if (snapshotCache === null || snapshotCache.length !== games.size) {
        snapshotCache = order.map(id => games.get(id)).filter((g): g is Game => g !== undefined)
      }
      return snapshotCache
    },
    subscribe(listener) {
      listeners.add(listener)
      return () => { listeners.delete(listener) }
    },
  }
}

/** React hook helper: subscribe a component to registry snapshots via useSyncExternalStore. */
export function subscribeRegistry(registry: D399GamesService, fn: () => void): () => void {
  return registry.subscribe(fn)
}

/** React hook helper: read the current snapshot (stable reference until next change). */
export function getRegistrySnapshot(registry: D399GamesService): readonly Game[] {
  return registry.list()
}


