/**
 * React hook: subscribe to the current session's `running` flag via the
 * sessions list snapshot store. Returns `true` while the model is
 * generating a response for the currently selected session.
 *
 * Uses `useSyncExternalStore` directly on `ctx.sessions.list` — the overlay
 * is a `position: fixed` DOM contribution portaled to `document.body`, not
 * a slot registration, so it does not receive the framework's session-scoped
 * hooks and subscribes to the list store itself.
 *
 * @module @huanlin/dsh-plugin-d399/client/useSessionRunning
 */
import { useRef, useSyncExternalStore } from 'react'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'

/** Slice of the sessions list store the overlay reads. */
interface SessionListSlice {
  current?: string
  byId: Record<string, { running?: boolean }>
}

/** Cached snapshot: same reference until `running` actually flips. */
interface RunningCache {
  id: string | undefined
  running: boolean
}

/**
 * @param ctx - client root context (must carry `sessions`).
 * @returns whether the current session's model is generating.
 */
export function useSessionRunning(ctx: ClientContext): boolean {
  const list = ctx.sessions.list
  const cacheRef = useRef<RunningCache>({ id: undefined, running: false })

  const getSnapshot = (): RunningCache => {
    const snap = list.getSnapshot() as SessionListSlice
    const id = snap.current
    const running = id !== undefined ? (snap.byId[id]?.running ?? false) : false
    const cache = cacheRef.current
    if (cache.id === id && cache.running === running) return cache
    const next = { id, running }
    cacheRef.current = next
    return next
  }

  const cached = useSyncExternalStore(
    (cb) => list.subscribe(cb),
    getSnapshot,
    () => cacheRef.current,
  )
  return cached.running
}
