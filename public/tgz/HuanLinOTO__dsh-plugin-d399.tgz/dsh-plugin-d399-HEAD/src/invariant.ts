/**
 * Package-owned invariant companion for `@huanlin/dsh-plugin-d399`.
 *
 * @module @huanlin/dsh-plugin-d399/invariant
 */

/* jscpd:ignore-start */
import type { Context } from '@deepseek-ai/cordis'
import type { InvariantInstaller } from '@deepseek-ai/dsh-invariants'

const PACKAGE_NAME = '@huanlin/dsh-plugin-d399'

/** Cordis companion plugin name. */
export const name = 'dsh-d399-invariant'
/** Service required before the companion can reserve package ownership. */
export const inject = ['invariants']

/**
 * No runtime invariant: the overlay is a self-contained DOM contribution
 * whose disposal is exercised by unmount; the d399Games registry is a
 * plain in-memory list asserted by the registry unit spec. Neither owns a
 * cordis event protocol or cross-plugin mutable state.
 */
const install: InvariantInstaller = () => {}

/**
 * Register this package's invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export const apply = (ctx: Context): Promise<() => void> =>
  Promise.resolve(ctx.invariants.register(PACKAGE_NAME, install))
/* jscpd:ignore-end */
