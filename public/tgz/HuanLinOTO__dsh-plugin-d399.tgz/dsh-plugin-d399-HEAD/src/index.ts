/**
 * dsh-d399 (贪玩蓝鲸) — host plugin entry.
 *
 * Client-only plugin: the host half has no runtime work. The browser half
 * (`./client`) mounts a `position: fixed` overlay on `document.body` that
 * watches the current session's `running` flag (the model-generating
 * signal). While the model is generating, a teaser pops up in the
 * bottom-right corner; clicking the button opens a game menu. Built-in
 * games: wordle + match-3. Third-party plugins can register more games
 * through the `d399Games` client service (`ctx.d399Games.register(...)`).
 *
 * @module @huanlin/dsh-plugin-d399
 */

import type { Context } from '@deepseek-ai/cordis'

export const name = 'dsh-d399'
export const inject: string[] = []

/**
 * Host apply — no-op. The overlay is a pure client-side UI contribution.
 * @param _ctx - host context (unused).
 */
export function apply(_ctx: Context): void {
  // Client-only plugin: all work happens in src/client/index.tsx.
}
