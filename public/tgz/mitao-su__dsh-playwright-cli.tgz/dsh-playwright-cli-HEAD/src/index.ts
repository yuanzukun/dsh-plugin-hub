/**
 * dsh-playwright-cli — DeepSeek Harness host plugin wrapping the Playwright CLI.
 *
 * A host-only tool plugin: no client bundle. It injects the `tools`, `shell`
 * and `systemPrompt` services and registers four tools that drive the
 * Playwright command line through the harness shell executor (the same seam
 * the official bash/pwsh tools use), so sandbox policy, DSH_* environment
 * facts, output caps and timeout/abort classification all come from the
 * composition for free:
 *
 *   - playwright_version      probe CLI availability / version
 *   - playwright_install      install browsers (+ scaffold @playwright/test)
 *   - playwright_test         run the test suite with curated CLI options
 *   - playwright_show_report  serve/open the HTML report (loopback route when
 *                             a web server is mounted, file path otherwise)
 *
 * Commands run in the session workspace by default and inherit the shell
 * executor's sandbox: a browser-binary download or an OS-level write the
 * policy denies surfaces as a `[sandbox: file access denied ...]` marker,
 * exactly like the official shell tools.
 */
import { createReadStream, existsSync, statSync } from 'node:fs'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { isAbsolute, join, resolve, sep } from 'node:path'
import { randomUUID } from 'node:crypto'
import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import {
  defineTool,
  type ToolCallView,
  type ToolResultView,
  type ToolRunContext,
} from '@deepseek-ai/dsh-tools'
import { parseExitStatus, type ShellRunResult } from '@deepseek-ai/dsh-shell'
import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import {
  ESCALATION_TARGETS,
  approveEscalation,
  escalationHintMarker,
  sandboxDenialMarker,
  validateEscalationArgs,
  type SandboxExecutionPolicy,
  type SandboxMode,
} from '@deepseek-ai/dsh-sandbox'
// Type-only: pulls the `Context.webServer` augmentation; zero runtime cost.
import type {} from '@deepseek-ai/dsh-host-webserver'
// Type-only: pulls the `Context.sandboxPolicy` augmentation; zero runtime cost.
import type {} from '@deepseek-ai/dsh-sandbox-policy'
// Type-only: pulls the `Context.approval` augmentation; zero runtime cost.
import type {} from '@deepseek-ai/dsh-user-approval'

export const name = 'playwright-cli'
export const inject = ['tools', 'shell', 'systemPrompt']

export interface Config {
  /** Default per-run timeout for the foreground CLI calls, in milliseconds. */
  timeoutMs: number
  /** Directory (relative to the test workdir) the HTML report lands in. */
  reportDir: string
  /** URL prefix under which report routes are served when a web server is mounted. */
  reportRoute: string
  /** Scaffold `@playwright/test` with npm when the CLI is missing at install time. */
  autoInstallPackage: boolean
}

export const Config = z.object({
  timeoutMs: z.number().default(600_000),
  reportDir: z.string().default('playwright-report'),
  reportRoute: z.string().default('/playwright-report'),
  autoInstallPackage: z.boolean().default(true),
})

/** Playwright is always invoked through `npx --no-install` so no surprise download happens. */
const PW_PREFIX = ['npx', '--no-install', 'playwright']

/** Safe bare-token characters never need quoting in either bash or pwsh. */
const SAFE_TOKEN = /^[A-Za-z0-9_./:=+@,-]+$/

/** Shell kind of the mounted executor, used to pick the quoting dialect. */
function shellKind(ctx: Context): 'pwsh' | 'bash' {
  return /pwsh/i.test(ctx.shell.constructor.name) ? 'pwsh' : 'bash'
}

/**
 * Quote one argument so it is safe as a single shell token in the mounted
 * executor's dialect. Both dialects share single-quote syntax; they only
 * differ in how an embedded single quote is escaped (`''` in pwsh,
 * `'\''` in bash), which is exactly what `shellKind` selects.
 */
function quoteFor(value: string, kind: 'pwsh' | 'bash'): string {
  if (value.length === 0) return "''"
  if (SAFE_TOKEN.test(value)) return value
  const body = kind === 'pwsh' ? value.replace(/'/g, "''") : value.replace(/'/g, `'\\''`)
  return `'${body}'`
}

/**
 * Resolve the workdir for one call: an explicit relative path resolves against
 * the calling agent's session cwd; an absolute path passes through; absent
 * falls back to the session cwd and then to the executor's own default.
 */
function resolveWorkdir(modelWorkdir: string | undefined, exec: ToolRunContext): string | undefined {
  const headerCwd = exec.agent?.session.header.cwd
  if (modelWorkdir === undefined) return headerCwd
  if (headerCwd !== undefined && !isAbsolute(modelWorkdir)) return resolve(headerCwd, modelWorkdir)
  return modelWorkdir
}

/** The canonical lossless value every CLI tool returns. */
interface RunValue {
  command: string
  workdir: string
  exitCode: number | null
  signal: string | null
  timedOut: boolean
  aborted: boolean
  timeoutMs: number
  stdout: string
  stderr: string
  truncated: boolean
  sandboxMode?: SandboxMode
  sandboxDenied?: boolean
}

function canonicalRun(result: ShellRunResult, workdir: string, command: string): RunValue {
  return {
    command,
    workdir,
    exitCode: result.exitCode,
    signal: result.signal ?? null,
    timedOut: result.timedOut,
    aborted: result.aborted,
    timeoutMs: result.timeoutMs,
    stdout: result.stdout.text,
    stderr: result.stderr.text,
    truncated: result.stdout.truncated || result.stderr.truncated,
    ...(result.sandbox !== undefined
      ? { sandboxMode: result.sandbox.mode, sandboxDenied: result.sandbox.denied }
      : {}),
  }
}

function zeroRun(command: string, workdir: string, stdout: string): RunValue {
  return {
    command,
    workdir,
    exitCode: 0,
    signal: null,
    timedOut: false,
    aborted: false,
    timeoutMs: 0,
    stdout,
    stderr: '',
    truncated: false,
  }
}

/**
 * Model-facing rendering: output body, then stderr, then status markers.
 * Accepts the schema-inferred shape (`sandboxMode` widens to `string`).
 * When the composition advertises escalation targets, a denial also carries
 * the same-turn escalation hint, exactly like the official shell tools.
 */
function renderRun(
  value: {
    command: string
    workdir: string
    exitCode: number | null
    signal: string | null
    timedOut: boolean
    aborted: boolean
    timeoutMs: number
    stdout: string
    stderr: string
    truncated: boolean
    sandboxMode?: string
    sandboxDenied?: boolean
  },
  escalationModes: readonly SandboxMode[] = [],
): string {
  let body = value.stdout
  if (value.stderr.length > 0) {
    if (body.length > 0 && !body.endsWith('\n')) body += '\n'
    body += `[stderr]\n${value.stderr}`
  }
  if (body.length === 0) body = '(no output)'
  const markers: string[] = []
  if (value.sandboxDenied) {
    markers.push(sandboxDenialMarker((value.sandboxMode as SandboxMode | undefined) ?? 'read-only'))
    if (escalationModes.length > 0) markers.push(escalationHintMarker('command'))
  }
  if (value.timedOut) markers.push(`[timed out after ${value.timeoutMs}ms]`)
  if (value.signal !== null) markers.push(`[killed by signal: ${value.signal}]`)
  else if (value.exitCode !== 0) markers.push(`[exit code: ${value.exitCode}]`)
  if (markers.length === 0) return body
  if (!body.endsWith('\n')) body += '\n'
  return body + markers.join('\n')
}

const textBlock = (text: string): ContentBlock[] => [{ type: 'text', text }]

const workdirParam = {
  type: 'string',
  description:
    'Target directory (default: the session workspace; a relative path is resolved against it).',
} as const

/**
 * Present the pending call as a terminal card, mirroring the official shell
 * tools' presentation contract.
 */
function presentTerminal(title: string, description: string, workdir?: string): ToolCallView {
  return {
    card: 'terminal',
    title,
    description,
    ...(workdir !== undefined ? { cwd: workdir } : {}),
  }
}

/**
 * Present the completed call as a terminal card with an exit-status pill,
 * recovering the status from the rendered marker text (replay-safe).
 */
function presentRunResult(args: unknown, result: { content: ContentBlock[]; isError: boolean }): ToolResultView | undefined {
  const block = result.content.length === 1 ? result.content[0] : undefined
  if (block === undefined || block.type !== 'text') return undefined
  const raw = block.text
  if (result.isError) {
    return {
      card: 'generic',
      content: [{ type: 'text', text: `\`\`\`console\n${raw.replace(/\n+$/, '')}\n\`\`\`` }],
    }
  }
  const { body, ...exit } = parseExitStatus(raw)
  return { card: 'terminal', output: body, ...exit }
}

/** Output schema (supported JSON Schema subset) shared by the CLI tools. */
const runSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    command: { type: 'string', required: true },
    workdir: { type: 'string', required: true },
    exitCode: { required: true, oneOf: [{ type: 'integer' }, { type: 'null' }] },
    signal: { required: true, oneOf: [{ type: 'string' }, { type: 'null' }] },
    timedOut: { type: 'boolean', required: true },
    aborted: { type: 'boolean', required: true },
    timeoutMs: { type: 'number', required: true },
    stdout: { type: 'string', required: true },
    stderr: { type: 'string', required: true },
    truncated: { type: 'boolean', required: true },
    sandboxMode: { type: 'string' },
    sandboxDenied: { type: 'boolean' },
  },
} as const

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.pdf': 'application/pdf',
}

/**
 * Static file handler for one HTML report directory. Path traversal is
 * rejected, unknown paths 404, and responses are `no-cache` so a rerun is
 * visible after a refresh.
 */
function serveStatic(root: string) {
  return async (req: IncomingMessage, res: ServerResponse): Promise<void> => {
    try {
      const rawPath = (req.url ?? '/').split('?')[0]
      let pathname: string
      try {
        pathname = decodeURIComponent(rawPath)
      } catch {
        res.writeHead(400, { 'Content-Type': 'text/plain' })
        res.end('bad request')
        return
      }
      const segments = pathname.split('/').filter((segment) => segment.length > 0)
      const filePath = resolve(root, ...segments)
      if (filePath !== root && !filePath.startsWith(root + sep)) {
        res.writeHead(403, { 'Content-Type': 'text/plain' })
        res.end('forbidden')
        return
      }
      if (!existsSync(filePath) || !statSync(filePath).isFile()) {
        res.writeHead(404, { 'Content-Type': 'text/plain' })
        res.end('not found')
        return
      }
      const ext = filePath.slice(filePath.lastIndexOf('.')).toLowerCase()
      res.writeHead(200, {
        'Content-Type': MIME[ext] ?? 'application/octet-stream',
        'Cache-Control': 'no-cache',
      })
      const stream = createReadStream(filePath)
      stream.on('error', () => {
        res.destroy()
      })
      stream.pipe(res)
    } catch {
      if (!res.headersSent) res.writeHead(500, { 'Content-Type': 'text/plain' })
      res.end('internal error')
    }
  }
}

export function apply(ctx: Context, config: Config): void {
  const kind = shellKind(ctx)
  const quote = (value: string): string => quoteFor(value, kind)

  // The escalation ladder and per-session policy resolution, mirroring the
  // official shell tools: fields are advertised only when the mounted
  // executor confines, and each call resolves the session's standing policy
  // (its cwd is the workspace boundary) before anything executes.
  const defaultMode = ctx.shell.sandboxMode
  const escalationModes = defaultMode === void 0 ? [] : ESCALATION_TARGETS
  const sandboxPolicy = defaultMode === void 0 ? void 0 : ctx.get('sandboxPolicy')
  if (defaultMode !== void 0 && sandboxPolicy === void 0) {
    throw new Error('playwright-cli: the mounted shell executor confines but ctx.sandboxPolicy is missing')
  }
  const resolveSandboxPolicy = (exec: ToolRunContext): SandboxExecutionPolicy | undefined =>
    sandboxPolicy?.resolve(exec.agent === void 0 ? {} : { session: exec.agent.session })
  /** Resolve a `sandbox_permissions` request through the user-approval channel before anything executes. */
  const approvePlaywrightEscalation = (
    mode: string,
    justification: string,
    exec: ToolRunContext,
    standingPolicy: NonNullable<ReturnType<typeof resolveSandboxPolicy>>,
    toolName: string,
  ) => {
    if (escalationModes.length === 0) {
      throw new Error('sandbox_permissions is not available in this composition (no sandboxing executor to escalate)')
    }
    return approveEscalation(
      {
        requestedMode: mode,
        justification,
        effectiveMode: standingPolicy.mode,
        subject: 'command',
      },
      {
        approver: ctx.get('approval'),
        agent: exec.agent,
        callId: exec.callId,
        toolName,
        signal: exec.signal,
      },
    )
  }

  /** Run one foreground CLI call through the shell executor. */
  const run = async (
    exec: ToolRunContext,
    argv: string[],
    options: {
      workdir?: string
      timeoutMs?: number
      toolName: string
      escalation?: { sandboxPermissions?: string; justification?: string }
    },
  ): Promise<RunValue> => {
    if (options.escalation !== undefined) {
      validateEscalationArgs(options.escalation.sandboxPermissions, options.escalation.justification)
    }
    const workdir = resolveWorkdir(options.workdir, exec)
    const command = argv.map((arg) => quote(arg)).join(' ')
    // Resolve the per-session sandbox policy exactly like the official shell
    // tools: the executor's default policy keys on the harness cwd, which on
    // Windows can place the ACL temp root inside the workspace and make the
    // runner refuse to start. A session-resolved policy keeps the workspace
    // boundary at the calling session's cwd instead. An approved escalation
    // stamps the granted mode onto exactly this call, fail-closed before
    // anything executes.
    const standingPolicy = resolveSandboxPolicy(exec)
    let policy: SandboxExecutionPolicy | undefined = standingPolicy
    if (
      options.escalation !== undefined &&
      options.escalation.sandboxPermissions !== undefined &&
      options.escalation.justification !== undefined
    ) {
      if (escalationModes.length === 0) {
        throw new Error('sandbox_permissions is not available in this composition (no sandboxing executor to escalate)')
      }
      if (standingPolicy === undefined) {
        throw new Error('playwright-cli: sandbox escalation requested but no standing policy resolves for this call')
      }
      const approvedMode = await approvePlaywrightEscalation(
        options.escalation.sandboxPermissions,
        options.escalation.justification,
        exec,
        standingPolicy,
        options.toolName,
      )
      policy = { ...standingPolicy, mode: approvedMode }
    }
    const spec = ctx.shell.resolve({
      command,
      workdir,
      timeoutMs: options.timeoutMs ?? config.timeoutMs,
      signal: exec.signal,
      ...(policy !== void 0 ? { sandboxPolicy: policy } : {}),
    })
    const result = await ctx.shell.run(spec)
    return canonicalRun(result, spec.workdir, command)
  }

  /**
   * Escalation fields shared by every tool that runs a shell command. Always
   * advertised (the targets are a module constant); in a composition without a
   * sandboxing executor, `approvePlaywrightEscalation` still fails closed with
   * the official "not available" error before anything runs.
   */
  const escalationFields = {
    sandbox_permissions: {
      type: 'string',
      enum: [...ESCALATION_TARGETS],
      description:
        'The wider sandbox mode this command needs. Only valid as a one-shot retry of a command the sandbox just denied (e.g. a Playwright worker spawn or browser download the file sandbox blocked); requires justification and user approval.',
    },
    justification: {
      type: 'string',
      description:
        'Required with sandbox_permissions: one sentence for the user explaining why this exact command needs the wider access.',
    },
  } as const

  const ESCALATION_GUIDANCE =
    escalationModes.length > 0
      ? ' When the sandbox denies a run — a `[sandbox: file access denied ...]` marker — retry the same call with `sandbox_permissions` plus a `justification` (user approval is prompted before anything runs).'
      : ''

  /** Extract the raw escalation argument pair from a tool's arguments, when either is given. */
  const escalationOf = (args: { sandbox_permissions?: string; justification?: string }) =>
    args.sandbox_permissions !== undefined || args.justification !== undefined
      ? { sandboxPermissions: args.sandbox_permissions, justification: args.justification }
      : undefined

  ctx.systemPrompt.section({
    name: 'tool:playwright-cli',
    order: 106,
    text: `Playwright CLI tools run through the harness shell executor; check the [exit code: N] and [sandbox: file access denied ...] markers on every result before moving on. playwright_test writes the HTML report under playwright-report/ in the test workdir; open it with playwright_show_report.${ESCALATION_GUIDANCE}`,
  })

  ctx.tools.register(
    defineTool({
      name: 'playwright_version',
      description:
        'Check whether the Playwright CLI is available for the target project and print its version. Runs `npx --no-install playwright --version` in the target directory (never downloads anything); a non-zero exit means Playwright is not installed there — run playwright_install first. Note: `--no-install` resolves only the local `@playwright/test` inside the workdir (never the global CLI), so probe the project directory that has it installed. Use this to diagnose the environment before running tests.',
      parameters: { workdir: workdirParam, ...escalationFields },
      output: {
        schema: runSchema,
        render: (args, value) => textBlock(renderRun(value, escalationModes)),
      },
      isConcurrencySafe: () => true,
      execute: async (args, exec) =>
        run(exec, [...PW_PREFIX, '--version'], {
          workdir: args.workdir,
          toolName: 'playwright_version',
          escalation: escalationOf(args),
        }),
      presentCall: (args) =>
        presentTerminal('playwright --version', 'Check the Playwright CLI version', args.workdir),
      presentResult: presentRunResult,
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'playwright_install',
      description:
        'Install Playwright browsers for the target project, and (when autoInstallPackage is enabled, the default) scaffold the @playwright/test package first if the CLI is missing. Runs `npx --no-install playwright install [browsers...]` in the target directory; browsers default to chromium — pass chromium/firefox/webkit to install others. Scaffolding runs `npm install --save-dev @playwright/test` and mutates the project package.json. Browser binaries download to the user profile, which a file sandbox may deny: the result then reports a [sandbox: file access denied ...] marker instead of installing — retry with `sandbox_permissions` plus a `justification` so the download may run under the approved wider mode.',
      parameters: {
        browsers: {
          type: 'array',
          items: { type: 'string' },
          description: 'Browsers to install (chromium, firefox, webkit). Default: chromium.',
        },
        withDeps: {
          type: 'boolean',
          description:
            'Also install OS dependencies (requires admin/sudo on Linux; unsupported on Windows).',
        },
        workdir: workdirParam,
        ...escalationFields,
      },
      output: {
        schema: runSchema,
        render: (args, value) => textBlock(renderRun(value, escalationModes)),
      },
      isConcurrencySafe: () => false,
      execute: async (args, exec) => {
        const probe = await run(exec, [...PW_PREFIX, '--version'], {
          workdir: args.workdir,
          toolName: 'playwright_install',
        })
        if (probe.exitCode !== 0 && config.autoInstallPackage) {
          const scaffold = await run(
            exec,
            ['npm', 'install', '--save-dev', '@playwright/test'],
            {
              workdir: args.workdir,
              timeoutMs: Math.max(config.timeoutMs, 600_000),
              toolName: 'playwright_install',
            },
          )
          if (scaffold.exitCode !== 0) {
            return {
              ...scaffold,
              stdout: `Playwright CLI is missing and scaffolding @playwright/test failed:\n${scaffold.stdout}`,
              stderr: scaffold.stderr,
            }
          }
          const probeAfter = await run(exec, [...PW_PREFIX, '--version'], {
            workdir: args.workdir,
            toolName: 'playwright_install',
          })
          if (probeAfter.exitCode !== 0) return probeAfter
        }
        const argv = [
          ...PW_PREFIX,
          'install',
          ...(args.browsers ?? []),
          ...(args.withDeps ? ['--with-deps'] : []),
        ]
        return run(exec, argv, {
          workdir: args.workdir,
          toolName: 'playwright_install',
          escalation: escalationOf(args),
        })
      },
      presentCall: (args) =>
        presentTerminal(
          `playwright install ${(args.browsers ?? []).join(' ')}`.trimEnd(),
          'Install Playwright browsers',
          args.workdir,
        ),
      presentResult: presentRunResult,
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'playwright_test',
      description:
        'Run the Playwright test suite in the target project via `npx --no-install playwright test` with a curated set of CLI options. Non-zero exits are reported, not errored — the model decides how to react. On success the HTML report is written under playwright-report/ in the test workdir; open it with playwright_show_report. Prefer playwright_version first when the CLI availability is unknown. The runner forks worker child processes, which the file sandbox denies under confined modes: a `[sandbox: file access denied ...]` marker means the run never executed — retry with `sandbox_permissions` plus a `justification`. `--no-install` resolves only the workdir\'s local `@playwright/test` (never a global CLI), so run from the project directory that has it installed to keep the CLI and the spec files\' `@playwright/test` on the same copy.',
      parameters: {
        files: {
          type: 'array',
          items: { type: 'string' },
          description: 'Test file paths or glob patterns to run (default: the whole suite).',
        },
        config: { type: 'string', description: 'Path to the playwright config file.' },
        project: { type: 'string', description: 'Only run tests from this project (config projects).' },
        grep: { type: 'string', description: 'Only run tests matching this regular expression.' },
        workers: {
          type: 'integer',
          description: 'Number of parallel workers (0 = number of CPU cores).',
        },
        reporter: { type: 'string', description: 'Reporter(s), e.g. line, list, html, json.' },
        headed: { type: 'boolean', description: 'Run browsers in headed mode (requires a display).' },
        forbidOnly: { type: 'boolean', description: 'Fail if test.only / test.describe.only is used.' },
        updateSnapshots: { type: 'boolean', description: 'Update snapshots (--update-snapshots).' },
        trace: {
          type: 'string',
          enum: ['on', 'off', 'retain-on-failure'],
          description: 'Trace recording mode.',
        },
        retries: { type: 'integer', description: 'Retry count for failed tests.' },
        repeatEach: { type: 'integer', description: 'Run each test this many times.' },
        testTimeout: { type: 'integer', description: 'Per-test timeout in milliseconds (--timeout).' },
        list: { type: 'boolean', description: 'Only list the collected tests (--list), do not run.' },
        reportDir: {
          type: 'string',
          description: 'HTML report directory override (default: the config value playwright-report).',
        },
        workdir: workdirParam,
        ...escalationFields,
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            ...runSchema.properties,
            reportDir: { type: 'string', required: true },
          },
        } as const,
        render: (args, value) => textBlock(renderRun(value, escalationModes)),
      },
      isConcurrencySafe: () => false,
      execute: async (args, exec) => {
        const argv: string[] = ['test']
        if (args.list) argv.push('--list')
        if (args.files !== undefined && args.files.length > 0) argv.push(...args.files)
        if (args.config !== undefined) argv.push('--config', args.config)
        if (args.project !== undefined) argv.push('--project', args.project)
        if (args.grep !== undefined) argv.push('--grep', args.grep)
        if (args.workers !== undefined) argv.push('--workers', String(args.workers))
        if (args.reporter !== undefined) argv.push('--reporter', args.reporter)
        if (args.headed) argv.push('--headed')
        if (args.forbidOnly) argv.push('--forbid-only')
        if (args.updateSnapshots) argv.push('--update-snapshots')
        if (args.trace !== undefined) argv.push('--trace', args.trace)
        if (args.retries !== undefined) argv.push('--retries', String(args.retries))
        if (args.repeatEach !== undefined) argv.push('--repeat-each', String(args.repeatEach))
        if (args.testTimeout !== undefined) argv.push('--timeout', String(args.testTimeout))
        const value = await run(exec, [...PW_PREFIX, ...argv], {
          workdir: args.workdir,
          toolName: 'playwright_test',
          escalation: escalationOf(args),
        })
        return { ...value, reportDir: resolve(value.workdir, args.reportDir ?? config.reportDir) }
      },
      presentCall: (args) => {
        const files = args.files ?? []
        return presentTerminal(
          `playwright test${args.list ? ' --list' : ''}${files.length > 0 ? ` ${files.join(' ')}` : ''}`,
          'Run Playwright tests',
          args.workdir,
        )
      },
      presentResult: presentRunResult,
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'playwright_show_report',
      description:
        'Locate the HTML report produced by playwright_test and make it viewable: when a web server is mounted, register a loopback route for this report and return its URL (the route lives until the plugin unloads); otherwise return the absolute path of the report index. Run playwright_test first — a missing report yields a non-zero result.',
      parameters: {
        path: {
          type: 'string',
          description: 'Report directory relative to the target directory (default: playwright-report).',
        },
        workdir: workdirParam,
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            ...runSchema.properties,
            exists: { type: 'boolean', required: true },
            path: { type: 'string', required: true },
            url: { required: true, oneOf: [{ type: 'string' }, { type: 'null' }] },
          },
        } as const,
        render: (args, value) => textBlock(renderRun(value)),
      },
      isConcurrencySafe: () => true,
      execute: async (args, exec) => {
        const base = resolveWorkdir(args.workdir, exec) ?? exec.agent?.session.header.cwd ?? process.cwd()
        const reportRoot = resolve(base, args.path ?? config.reportDir)
        const indexHtml = join(reportRoot, 'index.html')
        if (!existsSync(indexHtml)) {
          return {
            ...zeroRun(
              'playwright show-report',
              base,
              `No HTML report found at ${indexHtml}. Run playwright_test first (the report lands in ${config.reportDir}/ under the test workdir).`,
            ),
            exists: false,
            path: indexHtml,
            url: null,
            exitCode: 1,
          }
        }
        const webServer = ctx.get('webServer')
        if (webServer) {
          const nonce = randomUUID().slice(0, 8)
          const routePath = `${config.reportRoute}/${nonce}`
          const disposer = webServer.register({
            kind: 'prefix',
            path: routePath,
            handler: serveStatic(reportRoot),
          })
          ctx.effect(() => disposer)
          const host = webServer.host === '0.0.0.0' ? '127.0.0.1' : webServer.host
          const url = `http://${host}:${webServer.port}${routePath}/`
          return {
            ...zeroRun(
              'playwright show-report',
              base,
              `HTML report served at:\n${url}\nOpen it in a browser; the route stays registered until the plugin unloads.`,
            ),
            exists: true,
            path: indexHtml,
            url,
          }
        }
        return {
          ...zeroRun(
            'playwright show-report',
            base,
            `HTML report at ${indexHtml} (no web server is mounted in this composition, so open the file directly in a browser).`,
          ),
          exists: true,
          path: indexHtml,
          url: null,
        }
      },
      presentCall: (args) =>
        presentTerminal('playwright show-report', 'Show the HTML test report', args.workdir),
      presentResult: presentRunResult,
    }),
  )
}
