import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "playwright-cli";
export declare const inject: string[];
export interface Config {
    /** Default per-run timeout for the foreground CLI calls, in milliseconds. */
    timeoutMs: number;
    /** Directory (relative to the test workdir) the HTML report lands in. */
    reportDir: string;
    /** URL prefix under which report routes are served when a web server is mounted. */
    reportRoute: string;
    /** Scaffold `@playwright/test` with npm when the CLI is missing at install time. */
    autoInstallPackage: boolean;
}
export declare const Config: z<Schemastery.ObjectS<{
    timeoutMs: z<number, number>;
    reportDir: z<string, string>;
    reportRoute: z<string, string>;
    autoInstallPackage: z<boolean, boolean>;
}>, Schemastery.ObjectT<{
    timeoutMs: z<number, number>;
    reportDir: z<string, string>;
    reportRoute: z<string, string>;
    autoInstallPackage: z<boolean, boolean>;
}>>;
export declare function apply(ctx: Context, config: Config): void;
