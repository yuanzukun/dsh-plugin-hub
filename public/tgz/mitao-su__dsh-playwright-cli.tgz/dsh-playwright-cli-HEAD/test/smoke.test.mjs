/**
 * Smoke tests for dsh-playwright-cli: load the built plugin, mount it on a
 * fake context, and assert the four tools register with valid schemas and
 * that their execute paths build the right commands / canonical values
 * through a stubbed shell executor. No harness, no real subprocess.
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { resolve } from 'node:path'
import { name, inject, Config, apply } from '../lib/index.js'
import { assertSupportedJsonSchema } from '@deepseek-ai/dsh-tools'

const DEFAULT_CONFIG = {
  timeoutMs: 600_000,
  reportDir: 'playwright-report',
  reportRoute: '/playwright-report',
  autoInstallPackage: true,
}

/** Fake ToolRunContext: a caller whose session cwd is C:/proj. */
function fakeExec(overrides = {}) {
  return {
    callId: 'test-call',
    name: 'x',
    arguments: {},
    agent: { session: { header: { cwd: 'C:/proj' } } },
    signal: new AbortController().signal,
    ...overrides,
  }
}

/** Fake ctx.shell capturing the specs it receives. */
function makeFakeCtx() {
  const tools = []
  const runs = []
  const shell = {
    constructor: { name: 'SandboxPwshExecutor' },
    resolve: (request) => ({
      ...request,
      workdir: request.workdir ?? 'C:/proj',
      timeoutMs: request.timeoutMs ?? DEFAULT_CONFIG.timeoutMs,
      stdoutMaxBytes: 1_000_000,
      sandboxPolicy: request.sandboxPolicy,
    }),
    run: async (spec) => {
      runs.push(spec)
      return {
        exitCode: 0,
        signal: null,
        timedOut: false,
        aborted: false,
        timeoutMs: spec.timeoutMs,
        stdout: { text: `ran: ${spec.command}`, truncated: false },
        stderr: { text: '', truncated: false },
      }
    },
  }
  const ctx = {
    shell,
    systemPrompt: { section: () => {} },
    tools: { register: (definition) => tools.push(definition) },
    get: () => undefined,
    effect: () => {},
    _tools: tools,
    _runs: runs,
  }
  return ctx
}

function mount() {
  const ctx = makeFakeCtx()
  apply(ctx, { ...DEFAULT_CONFIG })
  const byName = new Map(ctx._tools.map((tool) => [tool.name, tool]))
  return { ctx, byName }
}

test('plugin exports the function-plugin contract', () => {
  assert.equal(name, 'playwright-cli')
  assert.deepEqual(inject, ['tools', 'shell', 'systemPrompt'])
  assert.ok(Config, 'Config schema exists')
  assert.equal(typeof apply, 'function')
})

test('apply registers exactly the four playwright tools', () => {
  const { byName } = mount()
  assert.deepEqual(
    [...byName.keys()].sort(),
    [
      'playwright_install',
      'playwright_show_report',
      'playwright_test',
      'playwright_version',
    ].sort(),
  )
})

test('every tool parameter and output schema passes the harness JSON-schema gate', () => {
  const { byName } = mount()
  for (const tool of byName.values()) {
    assert.doesNotThrow(
      () => assertSupportedJsonSchema(tool.parameters),
      `${tool.name}: parameters`,
    )
    assert.doesNotThrow(
      () => assertSupportedJsonSchema(tool.output.schema),
      `${tool.name}: output.schema`,
    )
  }
})

test('playwright_version runs npx --no-install playwright --version in the session cwd', async () => {
  const { byName, ctx } = mount()
  const value = await byName.get('playwright_version').execute({}, fakeExec())
  assert.equal(ctx._runs.length, 1)
  assert.equal(ctx._runs[0].command, 'npx --no-install playwright --version')
  assert.equal(ctx._runs[0].workdir, 'C:/proj')
  assert.equal(value.exitCode, 0)
  assert.match(value.stdout, /npx --no-install playwright --version/)
})

test('playwright_test builds flags and quotes values with spaces', async () => {
  const { byName, ctx } = mount()
  const tool = byName.get('playwright_test')
  const value = await tool.execute(
    {
      files: ['tests/login flow.spec.ts'],
      project: 'chromium',
      grep: 'login',
      workers: 2,
      reporter: 'html',
      list: true,
      trace: 'on',
    },
    fakeExec(),
  )
  const command = ctx._runs[0].command
  assert.ok(command.startsWith('npx --no-install playwright test'), command)
  // A value with a space is single-quoted; a safe bare token stays bare.
  assert.ok(command.includes("'tests/login flow.spec.ts'"), command)
  assert.ok(command.includes('--project chromium'), command)
  assert.ok(command.includes('--grep login'), command)
  assert.ok(command.includes('--workers 2'), command)
  assert.ok(command.includes('--reporter html'), command)
  assert.ok(command.includes('--list'), command)
  assert.ok(command.includes('--trace on'), command)
  assert.equal(value.reportDir, resolve('C:/proj', 'playwright-report'))
})

test('playwright_install probes first, then installs the requested browsers', async () => {
  const { byName, ctx } = mount()
  const value = await byName.get('playwright_install').execute(
    { browsers: ['chromium', 'webkit'] },
    fakeExec(),
  )
  assert.equal(ctx._runs.length, 2)
  assert.equal(ctx._runs[0].command, 'npx --no-install playwright --version')
  assert.equal(
    ctx._runs[1].command,
    'npx --no-install playwright install chromium webkit',
  )
  assert.equal(value.exitCode, 0)
})

test('playwright_install scaffolds @playwright/test when the CLI probe fails', async () => {
  const ctx = makeFakeCtx()
  const originalRun = ctx.shell.run
  let versionProbes = 0
  ctx.shell.run = async (spec) => {
    const isVersion = spec.command === 'npx --no-install playwright --version'
    if (isVersion) versionProbes += 1
    const failed = isVersion && versionProbes === 1
    return failed
      ? {
          exitCode: 1,
          signal: null,
          timedOut: false,
          aborted: false,
          timeoutMs: spec.timeoutMs,
          stdout: { text: 'not found', truncated: false },
          stderr: { text: '', truncated: false },
        }
      : originalRun(spec)
  }
  apply(ctx, { ...DEFAULT_CONFIG })
  const tool = ctx._tools.find((t) => t.name === 'playwright_install')
  const value = await tool.execute({ browsers: ['chromium'] }, fakeExec())
  assert.equal(versionProbes, 2, 'probe once, scaffold, probe again')
  assert.equal(ctx._runs.length, 3)
  assert.equal(ctx._runs[0].command, 'npm install --save-dev @playwright/test')
  assert.equal(ctx._runs[1].command, 'npx --no-install playwright --version')
  assert.equal(ctx._runs[2].command, 'npx --no-install playwright install chromium')
  assert.equal(value.exitCode, 0)
})

test('playwright_show_report reports a missing report without touching a server', async () => {
  const { byName } = mount()
  const value = await byName.get('playwright_show_report').execute({}, fakeExec())
  assert.equal(value.exists, false)
  assert.equal(value.exitCode, 1)
  assert.equal(value.url, null)
  assert.equal(value.path, resolve('C:/proj', 'playwright-report', 'index.html'))
})

test('playwright_show_report resolves against the workdir argument', async () => {
  const { byName } = mount()
  // A missing report under a workdir other than the session cwd must be
  // looked up there, not in the session root.
  const value = await byName
    .get('playwright_show_report')
    .execute({ workdir: 'C:/proj/sub/project' }, fakeExec())
  assert.equal(value.path, resolve('C:/proj/sub/project', 'playwright-report', 'index.html'))
})

test('executor kind detection quotes for pwsh vs bash dialect', async () => {
  // pwsh dialect escapes an embedded single quote by doubling it.
  const ctxPwsh = makeFakeCtx()
  ctxPwsh.shell.constructor = { name: 'SandboxPwshExecutor' }
  apply(ctxPwsh, { ...DEFAULT_CONFIG })
  const testPwsh = ctxPwsh._tools.find((t) => t.name === 'playwright_test')
  await testPwsh.execute({ grep: "it's" }, fakeExec())
  assert.ok(ctxPwsh._runs[0].command.includes("'it''s'"), ctxPwsh._runs[0].command)

  // bash dialect escapes an embedded single quote with the '\'' sequence.
  const ctxBash = makeFakeCtx()
  ctxBash.shell.constructor = { name: 'BashSandboxExecutor' }
  apply(ctxBash, { ...DEFAULT_CONFIG })
  const testBash = ctxBash._tools.find((t) => t.name === 'playwright_test')
  await testBash.execute({ grep: "it's" }, fakeExec())
  assert.ok(ctxBash._runs[0].command.includes("'it'\\''s'"), ctxBash._runs[0].command)
})

test('a confining executor gets the per-session sandbox policy passed through', async () => {
  // The official shell tools resolve the policy per session and hand it to
  // shell.resolve; without that, the executor's default policy keys on the
  // harness cwd and the Windows ACL runner can refuse to start (temp root
  // inside the workspace).
  const policy = { mode: 'workspace-write', workspaceRoot: 'C:/sessions/ws' }
  const ctx = makeFakeCtx()
  ctx.shell.sandboxMode = 'workspace-write'
  ctx.get = (key) => (key === 'sandboxPolicy' ? { resolve: (request) => ({ ...policy, requested: request }) } : undefined)
  apply(ctx, { ...DEFAULT_CONFIG })
  const tool = ctx._tools.find((t) => t.name === 'playwright_version')
  await tool.execute({}, fakeExec())
  assert.equal(ctx._runs.length, 1)
  assert.equal(ctx._runs[0].sandboxPolicy.mode, 'workspace-write')
  assert.equal(ctx._runs[0].sandboxPolicy.workspaceRoot, 'C:/sessions/ws')
  // The session cwd travels into the policy resolution request.
  assert.equal(ctx._runs[0].sandboxPolicy.requested.session.header.cwd, 'C:/proj')
})

test('escalation fields are advertised on every command-running tool', () => {
  const { byName } = mount()
  const props = byName.get('playwright_test').parameters.properties
  assert.ok(props.sandbox_permissions, 'sandbox_permissions advertised')
  assert.deepEqual(props.sandbox_permissions.enum, ['workspace-write', 'danger-full-access'])
  assert.ok(props.justification, 'justification advertised')
})

test('escalation fails closed in a composition without a sandboxing executor', async () => {
  const ctx = makeFakeCtx() // no shell.sandboxMode: nothing confines
  apply(ctx, { ...DEFAULT_CONFIG })
  const tool = ctx._tools.find((t) => t.name === 'playwright_version')
  await assert.rejects(
    () => tool.execute({ sandbox_permissions: 'danger-full-access', justification: 'test' }, fakeExec()),
    /sandbox_permissions is not available in this composition/,
  )
  assert.equal(ctx._runs.length, 0, 'nothing ran')
})

test('an approved escalation stamps the granted mode onto the shell call', async () => {
  const asks = []
  const ctx = makeFakeCtx()
  ctx.shell.sandboxMode = 'workspace-write'
  ctx.get = (key) => {
    if (key === 'sandboxPolicy') return { resolve: () => ({ mode: 'workspace-write', workspaceRoot: 'C:/proj' }) }
    if (key === 'approval') return { request: async (req) => { asks.push(req); return 'allowed-once' } }
    return undefined
  }
  apply(ctx, { ...DEFAULT_CONFIG })
  const tool = ctx._tools.find((t) => t.name === 'playwright_test')
  const value = await tool.execute(
    { sandbox_permissions: 'danger-full-access', justification: 'workers fork child processes under the runner' },
    fakeExec(),
  )
  assert.equal(asks.length, 1)
  assert.equal(asks[0].toolName, 'playwright_test')
  assert.ok(asks[0].reason.includes('workers fork child processes under the runner'), asks[0].reason)
  assert.equal(ctx._runs[0].sandboxPolicy.mode, 'danger-full-access')
  assert.equal(value.exitCode, 0)
})

test('a justification without sandbox_permissions is rejected before anything runs', async () => {
  const ctx = makeFakeCtx()
  ctx.shell.sandboxMode = 'workspace-write'
  ctx.get = (key) =>
    key === 'sandboxPolicy' ? { resolve: () => ({ mode: 'workspace-write', workspaceRoot: 'C:/proj' }) } : undefined
  apply(ctx, { ...DEFAULT_CONFIG })
  const tool = ctx._tools.find((t) => t.name === 'playwright_version')
  await assert.rejects(
    () => tool.execute({ justification: 'no permissions' }, fakeExec()),
    /justification is only valid together with sandbox_permissions/,
  )
  assert.equal(ctx._runs.length, 0, 'nothing ran')
})

test('denial rendering carries the escalation hint when escalation is advertised', async () => {
  const ctx = makeFakeCtx()
  ctx.shell.sandboxMode = 'workspace-write'
  ctx.get = (key) =>
    key === 'sandboxPolicy' ? { resolve: () => ({ mode: 'workspace-write', workspaceRoot: 'C:/proj' }) } : undefined
  ctx.shell.run = async (spec) => ({
    exitCode: 0,
    signal: null,
    timedOut: false,
    aborted: false,
    timeoutMs: spec.timeoutMs,
    stdout: { text: '', truncated: false },
    stderr: { text: '', truncated: false },
    sandbox: { mode: 'workspace-write', denied: true, enforcement: 'full' },
  })
  apply(ctx, { ...DEFAULT_CONFIG })
  const tool = ctx._tools.find((t) => t.name === 'playwright_version')
  const value = await tool.execute({}, fakeExec())
  // The denial and hint markers are added by the output render, like the shell tools.
  const rendered = tool.output.render({}, value)
  const text = rendered[0].text
  assert.match(text, /\[sandbox: file access denied under workspace-write mode\]/)
  assert.match(text, /retry this exact command once with sandbox_permissions/)
})
