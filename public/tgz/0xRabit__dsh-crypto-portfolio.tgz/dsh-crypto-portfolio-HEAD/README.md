# dsh-crypto-portfolio

English | [中文](README.zh.md)

A free, 100% self-hosted [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) (DSH) plugin that unifies your **on-chain and CEX assets** into one self-contained web dashboard.

**Requires** `dsh` `0.1.1-rc.2` (Node `^22.19 || >=24`) · Python 3.9+ · `pip3 install requests pynacl`

```sh
dsh plugin --profile demo add dsh-crypto-portfolio   # npm
dsh --profile demo                                    # dashboard at http://127.0.0.1:8080
```

> **Twin project.** This dashboard is the twin of the [SmartFolio Chrome extension](https://chromewebstore.google.com/detail/smartfolio/ogiijkjoahbekjnjhnchjefllioelcin): the extension puts the same wallets in your toolbar, this one is the self-hosted, all-chains view that runs on your own machine. Same idea, two shells — the dashboard is a DSH plugin and follows the DSH plugin conventions, so it keeps its own name.

![Dashboard: total assets, wallet share and the health report](assets/screenshot-dashboard.png)

![Token details and the portfolio trend](assets/screenshot-tokens.png)

![Chain distribution](assets/screenshot-chains.png)

> Unofficial project, independently developed and maintained by community members.

---

## Why it exists / The pain points

I built it because the pain points are real.

### 1 · My money lives in seven places, and checking the total means opening six pages

EVM assets in DeBank, SOL and staking on-chain, BTC in a block explorer, plus Binance / Bybit / Backpack / OKX / Bitget — each with its own app. Checking "how much do I actually have" meant hopping between six pages, and it was easy to miss a wallet along the way.

**This plugin puts all of it on a single screen.**

### 2 · Assets that block explorers can't see

Some money is genuinely invisible: native Solana stake accounts (`getParsedStakeAccounts` misses them), Hyperliquid L1 staked HYPE and spot balances, exchange earn/funding accounts. None of these are plain SPL/ERC-20 tokens, so ordinary tools never read them.

**This plugin digs them out and prices them into your total** — including the 12.1 SOL staked in the account above and the ~318 HYPE staked on Hyperliquid.

### 3 · Dust coins and phishing tokens inflate the numbers

DeBank lists plenty of fake tokens — ETHG, for example, is a **phishing token with a manipulated price** that once inflated one account by $570K.

**One-click blacklisting**: every token you blacklist is removed from totals, trends and historical snapshots instantly.

### 4 · "How much did I have last week?"

Without history there's no peace of mind.

**Every refresh saves the last snapshot of the day** (SQLite, deduplicated by day); over time it draws a trend line that is uniquely yours:

![Daily snapshots become trend charts](assets/flow.svg)

---

## What it does

- **A zero-dependency web dashboard, launched from a real DSH plugin.** No framework, no CDN — Python stdlib + vanilla JS.
- **Covers BTC / EVM / Solana / Dogecoin / Cardano / Hyperliquid L1 / CEX.** DeBank's 73 chains, BTC P2SH+P2TR, native Solana staking, Dogecoin (BlockCypher), Cardano (Koios, incl. stake addresses), Hyperliquid's official API (staked HYPE + spot + perp equity + vault equity), and read-only CEX keys (named `<exchange>_read`). Five exchanges are supported (Binance, Bybit, Backpack, OKX, Bitget). Read-only CEX keys cover spot, OKX's funding sub-account and Backpack's futures collateral account, including tokenised equities; on Bitget the spot account is summed with the real futures accounts and the `S*` demo products are skipped, so play money never enters the total.
- **Global filters.** Category (BTC / EVM / Solana / Dogecoin / Cardano / CEX), wallet and chain dropdowns drive every panel — total, wallet-share pie, trend, chain distribution, token table.
- **Up to five block explorers per wallet.** Each wallet card ends in a row of explorer icons — the provider this app actually reads from comes first (DeBank · bitaps · Jupiter · Dogechain · Cardanoscan), then the other mainstream explorers in popularity order (Etherscan, mempool.space, Solscan, Blockchair, CExplorer, …). Dogecoin shows three and Cardano four, because that is how many credible explorers those chains have. CEX rows show the exchange mark instead, since an exchange account has no explorer page.
- **Free + paid data sources, clearly labeled.** EVM uses DeBank with two providers: paid `debank-pro` (badged "PAID", with a registration link) and free keyless `debank-public` fallback; CEX rows always show Binance/Bybit/Backpack/OKX/Bitget with "get API key" links to each exchange (OKX and Bitget also take the key's passphrase). Each source displays when it last succeeded.
- **Automatic API failover.** Each source has several providers (prices: CoinGecko → Binance → Coinbase → OKX; BTC: blockchain.info → mempool.space; multiple Solana RPCs; Hyperliquid dual endpoints). A dead provider is skipped and the last working one is remembered.
- **Scheduled daily refresh.** Every profile can auto-refresh at a local time (server-side daemon; closing the browser page does not stop it); per-source last-success timestamps are shown in Settings.
- **Multi-profile configs.** The `default` profile ships with public template wallets (vitalik.eth, genesis BTC, public SOL, public DOGE, public ADA) and empty keys; each profile can be renamed — its snapshots move with it — and keeps its own daily refresh time; your private wallets and keys live in a separately named profile with its own snapshot history.
- **Local-first by default.** The API binds to `127.0.0.1` and masks API keys in its responses; writes are refused for cross-site requests (`Sec-Fetch-Site: cross-site`, foreign or opaque `Origin`, non-JSON bodies) and refresh is rate-limited to one run per minute. Snapshot history is kept as a 90-day window plus one per month, so the database does not grow without bound.
- **Asset labels.** A second donut breaks the portfolio down by asset label, and the system detects stablecoins / bitcoin / ether / SOL / HYPE on its own (bridged, wrapped and staked forms included). Every token table row carries a one-label control, and you can define your own labels in Settings — a custom label gets its own slice and colour, and your rules always beat the built-in wildcards.
- **Asset health.** A panel above the token table grades the portfolio on the three questions that matter, one card each: **volatility risk** (stablecoins · bitcoin · everything else, scored on the volatile share), **concentration** (largest single wallet, drawn as a gauge with both thresholds marked) and **storage security** (cold · hot · exchange custody). Every row shows its balance and its share, and each failing check adds a plain sentence. All three thresholds are editable in Settings (per profile, validated, with the storage pair inverted) and the figures are derived from the same blacklist-filtered snapshot the dashboard shows. Mark a wallet *cold* in Settings and the storage verdict follows at once — the class is read from the live wallet list, with the snapshotted value as the fallback for wallets that have since been removed.
- **Manual protocol positions.** Not every protocol can be read: a brand-new one (Papertrade was the trigger) may have no balance API at all. Register it by hand under the wallet that holds it — protocol, symbol, amount, value in USD and the date of the estimate — and it joins the total, the wallet cards, the chain distribution and the health report as a normal position. It is deliberately a *dated estimate*, not a live value: it never follows the market and a refresh never overwrites it, so the dashboard keeps showing that number and that date (the token table tags the row `manual` with it) until you register it again. Registrations count from their own date onwards, so a position added today does not rewrite last month's history.
- **Plan tab — the portfolio's operating manual.** A third tab beside Dashboard and Settings turns a financial plan into today's instruction. Give it the shape of the plan once (per profile, in `plan.json`): where each coin's price tiers sit, what a week costs in every tier, how new money is split, which cash and equity positions count as ammo, and what the goals are. After every refresh it answers the only question that matters — *what do I do with the next dollar?* — with the week's buy per coin (BTC 40% / ETH 35% / HYPE+SOL 25%), the tier each coin sits in (judged on its own price; HYPE+SOL follows BTC), which ammo source pays for it and how much of that source is left, how much of the quarter's deployment cap is gone, where the portfolio sits against each goal's path and what CAGR is still needed, and every rule from the take-profit / rebalance / drawdown sets that applies right now. Executions are logged (`plan_log.jsonl`) and consume the pool by source, so "left to deploy" is a real number rather than a guess. Cash and equities the tracker cannot see are declared as manual assets, which is how they join the total and the goal maths. The shipped defaults are illustrative placeholders — the equities and amounts are examples you replace in Plan settings — and the tab reproduces the worked example it ships with exactly: BTC $80,422 sits in T2 and ETH $2,353 in T3, so the week costs $160 + $280 + $100 = $540.
- **Share card.** A *Share* button next to *Refresh* opens a dialog with a live preview of a 1200×630 PNG — total, day-over-day change, top holdings aggregated by symbol, the asset-label donut and the three health verdicts. Download it, copy the image, copy the generated text, or send it straight to X / Facebook / WhatsApp / Telegram. Drawn by hand on a canvas: no `html2canvas`, no CDN, and no wallet address in the image.
- **Author links + tip jar.** The settings footer carries the author's socials (X / Discord / GitHub) and a *Buy me a coffee* dialog with a tip.md badge and a Binance Pay QR — the badge is vendored locally, so the page still makes no third-party requests.
- **Linkable pages.** `#pagePlan` opens the plan, `#pageSettings` opens Settings and `#pageSettings/secWallets` opens one section, so a refresh (or a bookmark) returns you to the same place.
- **Themes & i18n**: light/dark theme toggle, EN / 中文 (English by default), chain/exchange logos throughout.


Every box in the diagram is a real data pipeline:

![Architecture](assets/arch.svg)

## How it integrates with DSH

Not a wrapper — a real plugin:

The dashboard also watches its own Python sources: editing `tracker/*.py` restarts
it within a couple of seconds (same process, no DSH restart), and static files are
read from disk on every request, so a UI change is a page reload. Settings → Service
has a *Restart the service* button for the cases where you want to force it.

- Declares a `dsh.bundle` manifest (`cordis.patch.yml`), so it installs with `dsh plugin add`.
- `apply(ctx)` hooks into the Cordis lifecycle: seeds user-local `profiles/default` from public templates on first run, spawns the dashboard as a child process, and stops it cleanly on `ctx.on('dispose')`.
- Exposes JSON APIs (`GET /api/refresh`, `/api/history`, `/api/tokens`, ...) that an agent can call directly, in addition to the web UI.

## Privacy (important)

This repository contains **no private keys, no private wallets, no balances** — `tracker/config.py` ships with `WALLETS = []` and empty keys. All private configs live in git-ignored local `profiles/`. Clone it, review it, run it with confidence.

## Install

### Requirements

- **`dsh` `0.1.1-rc.2`** (or a compatible release within the same pre-release line)
  and **Node `^22.19.0 || >=24.0.0`** — the range DSH itself declares.
- **Python 3.9+** with two pip packages:

  ```sh
  pip3 install requests pynacl
  ```

  These are ordinary runtime dependencies, not vendored, so `pip` can pick the
  build that matches your platform.

### From npm (recommended)

Installs prebuilt code and needs **no build permission**:

```sh
dsh plugin --profile demo add dsh-crypto-portfolio
dsh --profile demo
```

### From a tarball (offline / air-gapped)

```sh
pnpm pack                                    # produces dsh-crypto-portfolio-0.1.0.tgz
dsh plugin --profile demo add ./dsh-crypto-portfolio-0.1.0.tgz
```

### From GitHub

```sh
dsh plugin --profile demo add github:0xRabit/dsh-crypto-portfolio#<commit-sha>
```

This package is plain JavaScript + Python with **no build step**, so its
`prepare` is a no-op and pnpm does not need you to allowlist a build script —
unlike plugins that ship TypeScript sources. Pin a commit SHA anyway, so a
later push cannot change what runs on your machine.

### Verify the layer before booting

```sh
dsh --profile demo --dump-config      # look for: # == dsh-crypto-portfolio
```

If that line is missing, the bundle did not activate — the package installed as a
plain dependency instead. Re-run the `add` and check the warning it printed.

### Override the port

A patch replaces the whole `config` of a row, so restate every key you need.
Put this in `$DSH_HOME/profiles/demo/cordis.patch.yml`:

```yaml
- id: portfolio-tracker
  name: dsh-crypto-portfolio
  config:
    port: 8199
    host: 127.0.0.1
```

Or set `PORTFOLIO_PORT` in the environment.

### Standalone (no DSH)

```sh
python3 run.py --init-template --port 8080   # seeds profiles/default from public templates
```

## Layout

```
profiles/default/   sources.json + wallets.json (public template, auto-seeded)
templates/          public example configs (no secrets)
tracker/            backend fetchers (debank/btc/solana/hyperliquid/cex/prices)
static/             web dashboard (vanilla JS, no external deps)
run.py / fetch.py   web server / CLI snapshot
```

## Releasing

One command from the maintainer's working tree (the release scripts live there, not in
this published bundle), and the flow is deliberately split in two:

```sh
scripts/sync_public.sh --push                 # publish code — the version does NOT move
scripts/sync_public.sh --push --release       # bump + tag + refresh every market listing
```

| Action | Version | Changelog | Tag | Market listings |
| --- | --- | --- | --- | --- |
| `--push` | unchanged | unchanged | — | untouched |
| `--push --release` | bumped | `[Unreleased]` stamped | `vX.Y.Z` | branch pushed, PR prepared per market |

- **A push is not a release.** Publishing code leaves `package.json` exactly as it is, so
  installed users see no update until a version is cut on purpose.
- **A release refreshes every listing.** The wording for each market lives here, under
  [`market/`](market/), so it is versioned with the code it describes and always matches
  the version being shipped. A market whose text did not change is skipped instead of
  getting an empty pull request.

| Market | How it is fed | What the release does |
| --- | --- | --- |
| [awesome-dsh-plugin](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin) | one YAML file per plugin | [`market/awesome-dsh-plugin.yml`](market/awesome-dsh-plugin.yml) → `data/plugins/0xRabit__dsh-crypto-portfolio.yml` |
| [awesome-deepseek-harness](https://github.com/awesome-deepseekharness/awesome-deepseek-harness) | curated bilingual tables | [`market/awesome-deepseek-harness.json`](market/awesome-deepseek-harness.json) → the row in each language's `🧩 Tools, Workflows & Presets` table |
| [awesome-dsh-hub](https://github.com/ukinch605/awesome-dsh-hub) | hourly scrape of the `dsh-plugin` topic | nothing to submit — the release only verifies the entry is present and current |

## License

MIT — see [LICENSE](LICENSE).
