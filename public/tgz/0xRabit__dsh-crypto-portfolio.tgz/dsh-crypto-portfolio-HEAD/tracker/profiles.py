# -*- coding: utf-8 -*-
"""Profile management — multiple named portfolio configs.

Each profile is a directory under profiles/ holding its own:
  sources.json   (API URLs + keys)
  wallets.json   (wallets tracked)
  blacklist.json (blacklisted tokens)
  portfolio.db   (daily snapshots history)

The default profile is seeded from templates/ (public example wallets, empty
API keys). Private configs (the user's own wallets/keys) belong to a named
profile of their choosing and are never part of any published artifact.

The active profile is persisted in profiles/.active; switching it re-points
every config file and the SQLite database.
"""
import json
import os
import threading
import shutil

from . import atomicio, config

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _profiles_root():
    """Where the profiles live: `<package>/profiles` unless PORTFOLIO_PROFILES_DIR
    says otherwise.

    The override matters for installed plugins: `dsh plugin add`/`update` (i.e. pnpm)
    replaces the package directory, so profiles kept inside it would be lost on the
    next update. Keeping the data outside the package is the difference between
    "upgrade" and "start over".
    """
    override = (os.environ.get("PORTFOLIO_PROFILES_DIR") or "").strip()
    if override:
        return os.path.abspath(os.path.expanduser(override))
    return os.path.join(_ROOT, "profiles")


PROFILES_DIR = _profiles_root()
ACTIVE_FILE = os.path.join(PROFILES_DIR, ".active")

# One lock for the profile registry: the 11-byte .active pointer, the
# interrupted-refresh marker and the profile directories are read-modify-written
# from HTTP threads and the scheduler thread at the same time. RLock because
# recover_active()/rename_profile() call set_active() while already holding it.
_lock = threading.RLock()
TEMPLATES_DIR = os.path.join(_ROOT, "templates")

_BAD = set('/\\:\x00')


def _valid_name(name):
    name = str(name or "").strip()
    if not name or name in (".", "..") or any(c in _BAD for c in name):
        raise ValueError(f"invalid profile name: {name!r}")
    return name


def profiles_dir():
    return PROFILES_DIR


def list_profiles():
    if not os.path.isdir(PROFILES_DIR):
        return []
    return sorted(d for d in os.listdir(PROFILES_DIR)
                  if os.path.isdir(os.path.join(PROFILES_DIR, d)) and not d.startswith("."))


def profile_dir(name):
    return os.path.join(PROFILES_DIR, _valid_name(name))


def exists(name):
    return os.path.isdir(profile_dir(name))


# `.active` is read through a cache: every path helper (blacklist/wallets/labels/
# sources/health...) calls active(), and a history rebuild calls those once per
# token row — opening and reading the file each time measured ~85 µs per call
# against ~1 µs for a bare stat, and made up most of a 6 s page load.
_active_cache = {"key": None, "name": None}


def _active_key():
    """Identity of the .active pointer: (mtime_ns, size), or None when absent."""
    try:
        st = os.stat(ACTIVE_FILE)
        return (st.st_mtime_ns, st.st_size)
    except OSError:
        return None


def invalidate_active_cache():
    """Drop the cached name. Called from every profile mutation, so a rename or a
    delete is visible immediately instead of at the next mtime change."""
    with _lock:
        _active_cache["key"] = None
        _active_cache["name"] = None


def _read_active():
    try:
        with open(ACTIVE_FILE, "r", encoding="utf-8") as f:
            name = f.read().strip()
        if name and exists(name):
            return name
    except Exception:  # noqa: BLE001
        pass
    return "default" if exists("default") else (list_profiles() or [None])[0]


def active():
    global _active_cache
    with _lock:
        key = _active_key()
        if _active_cache["name"] is not None and _active_cache["key"] == key:
            return _active_cache["name"]
        name = _read_active()
        _active_cache = {"key": key, "name": name}
        return name


def set_active(name):
    with _lock:
        _valid_name(name)
        if not exists(name):
            raise ValueError(f"profile {name!r} does not exist")
        os.makedirs(PROFILES_DIR, exist_ok=True)
        # 11 bytes, but an empty or torn .active sends the dashboard to the wrong
        # profile — and the scheduler flips this around every refresh
        atomicio.write_text(ACTIVE_FILE, name)
        invalidate_active_cache()


# Interrupted-refresh recovery -------------------------------------------------
# The scheduler temporarily switches the active profile while it refreshes a
# profile, then switches back in a `finally`. If the process is killed during
# that window the `finally` never runs and the user's chosen profile is lost.
# We persist the intended target so startup can put it back.
def _restore_file():
    return os.path.join(PROFILES_DIR, ".active_restore")


def mark_restore_target(name):
    """Remember which profile to return to if we die mid-refresh."""
    with _lock:
        try:
            os.makedirs(PROFILES_DIR, exist_ok=True)
            atomicio.write_text(_restore_file(), str(name or ""))
        except Exception:  # noqa: BLE001
            pass


def clear_restore_target():
    with _lock:
        try:
            os.remove(_restore_file())
        except OSError:
            pass


def recover_active():
    """Startup hook: if a scheduled refresh was interrupted, restore the
    profile the user had selected. Returns the restored name, or None."""
    with _lock:            # spans the read, the clear and the restore: it is one step
        try:
            with open(_restore_file(), "r", encoding="utf-8") as f:
                name = f.read().strip()
        except OSError:
            return None
        clear_restore_target()
        if name and name != active() and exists(name):
            try:
                set_active(name)
                return name
            except Exception:  # noqa: BLE001
                return None
        return None


# per-profile file locations -------------------------------------------------
def sources_file():
    return os.path.join(profile_dir(active()), "sources.json")


def wallets_file():
    return os.path.join(profile_dir(active()), "wallets.json")


def labels_file():
    return os.path.join(profile_dir(active()), "labels.json")


def asset_labels_file():
    """Per-profile asset-label rules. Was stablecoins.json before labels became a
    general concept; `legacy_asset_labels_file` lets the loader migrate it once."""
    return os.path.join(profile_dir(active()), "asset_labels.json")


def legacy_asset_labels_file():
    return os.path.join(profile_dir(active()), "stablecoins.json")


def health_file():
    """Per-profile health thresholds (see tracker/healthconfig.py)."""
    return os.path.join(profile_dir(active()), "health.json")


def plan_file():
    """Per-profile asset plan (see tracker/plan.py): goals, tiers, ammo, equities."""
    return os.path.join(profile_dir(active()), "plan.json")


def plan_log_file():
    """Per-profile execution log of the plan (one JSON object per line)."""
    return os.path.join(profile_dir(active()), "plan_log.jsonl")


def manual_file():
    """Per-profile manually registered protocol positions (see tracker/manual.py)."""
    return os.path.join(profile_dir(active()), "manual_positions.json")


def blacklist_file():
    return os.path.join(profile_dir(active()), "blacklist.json")


def db_path():
    return os.path.join(profile_dir(active()), "portfolio.db")


# lifecycle ------------------------------------------------------------------
def create_profile(name, from_template=False, copy_from=None, wallets_seed=None):
    """Create a profile directory.

    from_template: seed sources.json+wallets.json from templates/ (public).
    copy_from:     copy an existing profile's config files (not its DB).
    wallets_seed:  optional wallet list to write into wallets.json.
    """
    name = _valid_name(name)
    if exists(name):
        raise ValueError(f"profile {name!r} already exists")
    d = profile_dir(name)
    os.makedirs(d, exist_ok=True)
    if from_template:
        for f in ("sources.json", "wallets.json"):
            src = os.path.join(TEMPLATES_DIR, "portfolio_" + f)
            if os.path.exists(src):
                shutil.copyfile(src, os.path.join(d, f))
    elif copy_from:
        src_dir = profile_dir(copy_from)
        for f in ("sources.json", "wallets.json", "blacklist.json"):
            src = os.path.join(src_dir, f)
            if os.path.exists(src):
                shutil.copyfile(src, os.path.join(d, f))
    if wallets_seed is not None:
        atomicio.write_json(os.path.join(d, "wallets.json"), wallets_seed)
    return name


def delete_profile(name):
    name = _valid_name(name)
    if name == "default":
        raise ValueError("cannot delete the default profile")
    if name == active():
        raise ValueError("cannot delete the active profile")
    shutil.rmtree(profile_dir(name), ignore_errors=True)
    invalidate_active_cache()


def rename_profile(old, new):
    """Rename a profile directory.

    The whole directory moves, so the profile's config AND its snapshot DB
    (portfolio.db) follow the new name. Renaming the active profile updates the
    active pointer. The public 'default' profile cannot be renamed (it is
    re-seeded from templates/ on startup).
    """
    old = _valid_name(old)
    new = _valid_name(new)
    if old == new:
        return new
    if old == "default":
        raise ValueError("cannot rename the default profile")
    if not exists(old):
        raise ValueError(f"profile {old!r} does not exist")
    if exists(new):
        raise ValueError(f"profile {new!r} already exists")
    was_active = (active() == old)
    os.rename(profile_dir(old), profile_dir(new))
    invalidate_active_cache()       # the old name is gone even when it was not active
    if was_active:
        set_active(new)
    return new


def ensure_profiles():
    """Create the default (public template) profile; migrate legacy root-level
    configs (old single-profile layout) into a profile named 'private'."""
    os.makedirs(PROFILES_DIR, exist_ok=True)
    if not exists("default"):
        create_profile("default", from_template=True)

    legacy = [("portfolio_sources.json", "sources.json"),
              ("portfolio_wallets.json", "wallets.json"),
              ("portfolio_blacklist.json", "blacklist.json"),
              ("portfolio.db", "portfolio.db")]
    if any(os.path.exists(os.path.join(_ROOT, src)) for src, _ in legacy) and not exists("private"):
        create_profile("private")
        pd = profile_dir("private")
        for src_name, dst_name in legacy:
            src = os.path.join(_ROOT, src_name)
            if os.path.exists(src):
                shutil.move(src, os.path.join(pd, dst_name))
        # seed wallets from config.py built-ins when the migrated list is empty
        wp = os.path.join(pd, "wallets.json")
        try:
            with open(wp, "r", encoding="utf-8") as f:
                wallets = json.load(f)
        except Exception:  # noqa: BLE001
            wallets = []
        if not wallets and config.WALLETS:
            atomicio.write_json(wp, config.WALLETS)
        set_active("private")
        print("[profiles] migrated legacy configs into profile 'private' (active)")

    if not exists(active()):
        set_active("default")
    return active()
