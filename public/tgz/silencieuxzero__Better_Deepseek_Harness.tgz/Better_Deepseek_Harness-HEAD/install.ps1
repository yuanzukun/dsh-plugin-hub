# install.ps1 — bootstrap better-deepseek-harness into a dsh profile (requires npm; no pnpm needed).
# Usage: .\install.ps1 [-Profile web]
param(
  [string]$Profile = "web"
)
$ErrorActionPreference = "Stop"

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$homeDir = if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $HOME ".dsh" }
$profilesModules = Join-Path $homeDir "profiles\node_modules"
$profileDir = Join-Path $homeDir ("profiles\" + $Profile)
$patchFile = Join-Path $profileDir "cordis.patch.yml"

if (-not (Test-Path $profileDir)) { throw "profile not found: $profileDir" }

New-Item -ItemType Directory -Force -Path $profilesModules | Out-Null
$target = Join-Path $profilesModules "better-deepseek-harness"
if (Test-Path $target) { Remove-Item -Recurse -Force $target }
New-Item -ItemType Directory -Force -Path $target | Out-Null
# This repository's root *is* the package — copy its contents (skip .git history
# and never copy into ourselves if $target happens to live under $here).
Get-ChildItem -Force -Path $here |
  Where-Object { $_.Name -ne ".git" -and $_.Name -ne "node_modules" -and $_.FullName -ne $target -and -not $_.FullName.StartsWith($target + [IO.Path]::DirectorySeparatorChar) } |
  ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $target -Recurse -Force }

# lib/ is not committed anymore: install the dependencies and generate the
# build output before the profile tries to load the package.
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
  throw "npm not found: better-deepseek-harness requires npm to build lib/ during installation"
}
Write-Host "Installing dependencies and building lib/ ..."
Push-Location $target
try {
  & npm ci --no-audit --no-fund
  if ($LASTEXITCODE -ne 0) { throw "npm ci failed (exit $LASTEXITCODE); could not install dependencies" }
  if (-not (Test-Path (Join-Path $target "lib\index.js"))) {
    & npm run build
    if ($LASTEXITCODE -ne 0) { throw "npm run build failed (exit $LASTEXITCODE); could not generate lib/" }
  }
} finally {
  Pop-Location
}

# Append the insert row if absent. Match the exact row id only — a substring
# match would also hit plugin-managed rows like `ext-center.mcp.<name>` and
# wrongly suppress re-adding the main row.
$row = @"
# --- better-deepseek-harness ---
- insert:
    - id: ext-center
      name: better-deepseek-harness
"@
$content = if (Test-Path $patchFile) { Get-Content $patchFile -Raw } else { "" }
if ($content -notmatch "(?m)^\s*-\s+id:\s*ext-center\s*$") {
  # Append as UTF-8 without BOM: Add-Content -Encoding UTF8 writes a BOM on
  # Windows PowerShell 5.1, which would corrupt an existing patch file mid-stream.
  # Keep the appended row on its own line even when the existing file does not
  # end with a newline — gluing it to the last row would corrupt the YAML.
  $separator = if ($content.Length -gt 0 -and -not $content.EndsWith("`n")) { "`n" } else { "" }
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::AppendAllText($patchFile, $separator + $row, $utf8NoBom)
}

Write-Host "better-deepseek-harness installed into profile '$Profile'."
Write-Host 'The config watcher activates it live; refresh the Web UI to see the "更好的 DeepSeek Harness" settings section.'
