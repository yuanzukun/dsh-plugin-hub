import { Buffer } from 'node:buffer'
import { TextDecoder } from 'node:util'
import { isLegacyDiffSource } from '../shared/annotation-source.ts'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { CommandDefinition, CommandInvocation, CommandResult } from '@deepseek-ai/dsh-commands'
import type { FileBlock, ImageBlock } from '@deepseek-ai/dsh-llm'
import type { UserMessage } from '@deepseek-ai/dsh-session'
import {
  formatSubmissionMessage,
  parseSubmissionPayload,
  sameAttachmentIdentities,
  validateSubmissionLimits,
} from '../shared/protocol.ts'
import { LEGACY_COMMAND_NAMES } from '../shared/config.ts'
import { submissionMessageId } from '../shared/ids.ts'
import { ATTACHMENT_PREPARE_INPUT, ATTACHMENT_IDENTITY_MISMATCH } from '../shared/types.ts'
import type {
  AnnotationConfig,
  AnnotationMessageSource,
  AnnotationSubmissionPayload,
  InlineCommentMessageSource,
  LegacyInlineAnnotationMessageSource,
  SubmittedAttachmentIdentity,
} from '../shared/types.ts'

/** Make the plugin's durable user provenance visible to DSH's merge-extensible source union. */
declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    annotationSubmission: AnnotationMessageSource
    inlineComments: InlineCommentMessageSource
    inlineAnnotations: LegacyInlineAnnotationMessageSource
  }
}

function decodePayload(rawInput: string, config: AnnotationConfig): AnnotationSubmissionPayload {
  const encoded = rawInput.trim()
  if (!/^[A-Za-z0-9_-]+$/u.test(encoded)) throw new Error('annotation payload is not base64url')
  const bytes = Buffer.from(encoded, 'base64url')
  if (bytes.byteLength > config.maxPayloadBytes) {
    throw new Error(`annotation payload is ${bytes.byteLength} bytes; maximum is ${config.maxPayloadBytes}`)
  }
  let text: string
  try {
    text = new TextDecoder('utf-8', { fatal: true }).decode(bytes)
  } catch (error: unknown) {
    throw new Error('annotation payload is not valid UTF-8', { cause: error })
  }
  let value: unknown
  try {
    value = JSON.parse(text)
  } catch (error: unknown) {
    throw new Error('annotation payload is not valid JSON', { cause: error })
  }
  const payload = parseSubmissionPayload(value)
  validateSubmissionLimits(payload, config, bytes.byteLength)
  return payload
}

function hasMessage(agent: Agent, messageId: string): boolean {
  if (agent.inbox.nextTurn.some((message) => message.id === messageId)) return true
  if (agent.inbox.nextStep.some((message) => message.id === messageId)) return true
  return agent.session
    .snapshotEvents()
    .some((event) => event.type === 'user/message' && event.data.id === messageId)
}

function identitiesOf(
  attachments: readonly (ImageBlock | FileBlock)[],
): readonly SubmittedAttachmentIdentity[] {
  return Object.freeze(
    attachments.map((block): SubmittedAttachmentIdentity => {
      const { attachmentId, bytes, name } = block.attachment
      return Object.freeze(
        block.type === 'file'
          ? { type: 'file', attachmentId, bytes, name: block.attachment.name }
          : {
              type: 'image',
              attachmentId,
              bytes,
              mediaType: block.attachment.mediaType,
              ...(name === undefined ? {} : { name }),
            },
      )
    }),
  )
}

function createAnnotationMessage(
  payload: AnnotationSubmissionPayload,
  attachments: readonly (ImageBlock | FileBlock)[],
): UserMessage {
  const source: AnnotationMessageSource = Object.freeze({
    kind: 'user',
    annotationSubmission: payload,
  })
  return Object.freeze({
    id: submissionMessageId(payload.submissionId) as unknown as UserMessage['id'],
    role: 'user',
    content: [{ type: 'text' as const, text: formatSubmissionMessage(payload) }, ...attachments],
    source,
  })
}

/** Validate and enqueue one idempotent annotation batch against the exact receiving agent. */
export function submitAnnotationPayload(
  agent: Agent,
  payload: AnnotationSubmissionPayload,
  attachments: readonly (ImageBlock | FileBlock)[] = [],
): { readonly duplicate: boolean; readonly messageId: string } {
  if (String(agent.id) !== payload.sessionId) {
    throw new Error(`annotation payload targets session ${payload.sessionId}, not ${String(agent.id)}`)
  }
  if (
    payload.attachmentIdentities !== undefined &&
    !sameAttachmentIdentities(payload.attachmentIdentities, identitiesOf(attachments))
  ) {
    throw new Error(ATTACHMENT_IDENTITY_MISMATCH)
  }
  if (payload.annotations.some((item) => isLegacyDiffSource(item)))
    throw new Error('Historical Git Diff annotations are read-only')
  const messageId = submissionMessageId(payload.submissionId)
  if (hasMessage(agent, messageId)) return Object.freeze({ duplicate: true, messageId })
  const message = createAnnotationMessage(payload, attachments)
  if (payload.delivery === 'steer') agent.steer(message)
  else agent.followup(message)
  return Object.freeze({ duplicate: false, messageId })
}

/** Build the internal command definition used by the browser half. */
export function createAnnotationCommand(config: AnnotationConfig): CommandDefinition {
  return Object.freeze({
    name: config.commandName,
    description: 'Submit an idempotent batch of annotations for an earlier assistant reply',
    input: { hint: '<internal-base64url-payload>', attachments: true },
    recordInput: false,
    handler(invocation: CommandInvocation): CommandResult | Promise<CommandResult> {
      if (invocation.signal.aborted) {
        throw invocation.signal.reason ?? new Error('annotation submission was aborted')
      }
      if (invocation.rawInput.trim() === ATTACHMENT_PREPARE_INPUT) {
        const text = JSON.stringify(identitiesOf(invocation.attachments))
        if (Buffer.byteLength(text) > config.maxPayloadBytes)
          throw new Error('Attachment identities exceed the submission-size limit.')
        return Object.freeze({ kind: 'success', text })
      }
      const payload = decodePayload(invocation.rawInput, config)
      const result = submitAnnotationPayload(invocation.agent, payload, invocation.attachments)
      return Object.freeze({
        kind: 'success',
        text: result.duplicate ? 'Annotation batch was already accepted.' : 'Annotation batch accepted.',
      })
    },
  })
}

/** Create the shared handler behind the new command and every invisible pre-rename alias. */
export function createLegacyAnnotationAliases(config: AnnotationConfig): readonly CommandDefinition[] {
  const primary = createAnnotationCommand(config)
  return Object.freeze(
    LEGACY_COMMAND_NAMES.map((name) =>
      Object.freeze({
        name,
        description: 'Compatibility alias for the internal annotation submission command',
        input: { hint: '<internal-base64url-payload>', attachments: true },
        recordInput: false,
        handler(invocation: CommandInvocation) {
          return primary.handler(invocation)
        },
      }),
    ),
  )
}
