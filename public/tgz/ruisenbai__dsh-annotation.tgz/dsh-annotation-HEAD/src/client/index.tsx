/** Browser half: selection capture, durable provenance cards, and local draft recovery. */

import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type { InboxState } from '@deepseek-ai/dsh-agent/types'
import type {} from '@deepseek-ai/dsh-api-remotes/client'
import type {} from '@deepseek-ai/dsh-api-workspace-files/remote'
import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client'
import type { ChatSnapshot, AssistantChatData } from '@deepseek-ai/dsh-client-ui-chat/client'
import type { IConversation } from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { SessionId } from '@deepseek-ai/dsh-session/types'
import type {
  CommandClaim,
  InputTriggerServiceContract,
  SubmitAttachment,
  SubmitOutcome,
} from '@deepseek-ai/dsh-client-ui-input-trigger/client'
import type { MessageId } from '@deepseek-ai/dsh-llm/brand'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar-right/client'
import type {} from '@deepseek-ai/dsh-client-ui-deliverables/client'
import { resolveConfig, LEGACY_COMMAND_NAMES } from '../shared/config.ts'
import { encodeSubmissionCommand } from '../shared/codec.ts'
import { parseAttachmentIdentities, sameAttachmentIdentities } from '../shared/protocol.ts'
import { isOutboxPayloadEntry, outboxSubmissionId } from '../shared/outbox-redaction.ts'
import { ATTACHMENT_PREPARE_INPUT, ATTACHMENT_IDENTITY_MISMATCH } from '../shared/types.ts'
import { ANNOTATION_SETTINGS_NAMESPACE, type AnnotationSettings } from '../shared/settings.ts'
import type {
  AnnotationConfig,
  MessageIdentity,
  OutboxAttachments,
  OutboxPayloadEntry,
  ProtocolLocale,
  SessionIdentity,
  SubmissionId,
} from '../shared/types.ts'
import {
  attachComposer,
  COMPOSER_ATTACHMENT_TOKEN,
  detachComposer,
  hasComposerAttachment,
  isSlashCommandLine,
  mergeLegacyRequirement,
  serializeComposerRequirement,
  stripComposerToken,
  visibleComposerDraft,
} from './composer-attachment.ts'
import {
  AnnotationController,
  SubmissionChangedError,
  retryEntry,
  selectedAnnotations,
  type AnnotationView,
  type AnnotationReconciliationSnapshot,
} from './controller.ts'
import type { AnnotationInjected, UserAnnotationProps } from './contract.ts'
import { AnnotationSettingsController } from './feature-toggle.ts'
import { MarketUpdateController } from './market-update.ts'
import { createFocusChatAdapter } from './focus-adapter.ts'
import { HighlightManager } from './highlight.ts'
import { AnnotationStorage } from './storage.ts'
import { AnnotationTrashController } from './annotation-trash.ts'
import { SourceSnapshotStore } from './source-snapshots.ts'
import { captureSourceContent, observeSourceSnapshots } from './snapshot-capture.ts'
import type { StorageCoordination, StorageLike } from './storage.ts'
import { styles } from './styles.ts'
import { en, zh } from './locales.ts'
import { decorateAssistantRenderers } from './assistant-renderer-decorator.tsx'
import { AnnotatedUserNode } from './components/AnnotatedUserNode.tsx'
import {
  AnnotationExperience,
  AnnotationRecordToggle,
  AnnotationComposerChip,
} from './components/AnnotationExperience.tsx'
import { AssistantAnnotationAction } from './components/AssistantAnnotationAction.tsx'
import { HiddenCommandRow } from './components/HiddenCommandRow.tsx'
import { AnnotationPluginCard } from './components/AnnotationPluginCard.tsx'
import { installDocumentIntegration } from './document-integration.tsx'
import {
  FileWholeAnnotationAction,
  OfficeWholeAnnotationAction,
} from './components/FileWholeAnnotationAction.tsx'
import type { FileAnnotationSource, OfficialDiffAnnotationSource } from '../shared/annotation-source.ts'
import { compactFileSource, compactOfficialDiffSource } from './official-adapters.ts'
import { createDiffReviewAction, installDiffIntegration } from './diff-integration.tsx'
import { AnnotationNoticeHub, AnnotationToastHost } from './notice.tsx'

declare module '@deepseek-ai/dsh-client-ui-sidebar-right/client' {
  interface SidebarRightResourceParamsMap {
    'changes-review': { readonly index?: number }
  }
}

/** Project only withdrawable turn entries, preserving an unavailable Inbox as unknown. */
function annotationQueue(inbox: InboxState | undefined): AnnotationReconciliationSnapshot['queue'] {
  return inbox?.['next-turn'].map((message) => ({ messageId: message.id }))
}

const NS = 'dshAnnotation'
const DOCUMENT_RENDERER_IDS = [
  '@deepseek-ai/dsh-client-ui-sidebar-documentpreview/text',
  '@deepseek-ai/dsh-client-ui-sidebar-documentpreview/markdown',
  '@deepseek-ai/dsh-client-ui-sidebar-documentpreview/code',
  '@deepseek-ai/dsh-client-ui-sidebar-documentpreview/html',
  '@deepseek-ai/dsh-client-ui-sidebar-documentpreview/image',
  '@deepseek-ai/dsh-client-ui-sidebar-documentpreview/pdf',
  '@deepseek-ai/dsh-client-ui-sidebar-documentpreview/excel',
] as const
const EMPTY_CHAT_NODES: AnnotationReconciliationSnapshot['chat']['nodes'] = {
  values: () => [],
}
export const inject = [
  'slots',
  'sessions',
  'uiConversation',
  'locale',
  'conversation',
  'inputTriggers',
  'configForms',
  'sidebarRight',
  'remote.workspaceFiles',
]

function UserNode(props: UserAnnotationProps<'user'>) {
  return <AnnotatedUserNode {...props} />
}

function SteeringNode(props: UserAnnotationProps<'steering'>) {
  return <AnnotatedUserNode {...props} />
}

function failureMessage(value: unknown): string {
  if (value instanceof Error) return value.message
  return String(value)
}

function transportMessage(result: unknown): string {
  const error =
    typeof result === 'object' && result !== null && 'error' in result
      ? (result as { readonly error: unknown }).error
      : undefined
  if (
    typeof error === 'object' &&
    error !== null &&
    'message' in error &&
    typeof error.message === 'string'
  ) {
    return error.message
  }
  return error === undefined ? 'command was not matched' : String(error)
}

/** Normalized admission outcome shared by the remote command bridge and its session fallback. */
interface CommandOutcome {
  readonly ok: boolean
  readonly errorText: string
  readonly text?: string
}

/** Structural mirror of the mounted `commands/execute` remote, typed without the attachment package. */
interface CommandRemoteFace {
  execute(
    sessionId: SessionId,
    line: string,
    attachments: readonly SubmitAttachment[],
    signal?: AbortSignal,
  ): Promise<{
    readonly ok: boolean
    readonly value?: { readonly result: { readonly kind: 'success' | 'error'; readonly text?: string } }
    readonly error?: unknown
  }>
}

/** Retry metadata excludes image bytes and temporary file-upload receipts. */
function attachmentMetadata(attachments: readonly SubmitAttachment[]): OutboxAttachments | undefined {
  if (attachments.length === 0) return undefined
  const images = attachments.filter((attachment) => attachment.type === 'image')
  return Object.freeze({
    count: attachments.length,
    kinds: Object.freeze(attachments.map((attachment) => attachment.type)),
    mediaTypes: Object.freeze(images.map((image) => image.mediaType)),
    names: Object.freeze(images.map((image) => image.name ?? '').filter((name) => name !== '')),
  })
}

/** Mount every UI contribution and bind one controller to each encountered Session. */
export function apply(ctx: ClientContext, input?: Partial<AnnotationConfig>): void {
  const config = resolveConfig(input)
  const sessions = ctx.sessions as unknown as ISessions
  const conversation = ctx.conversation as unknown as IConversation
  const inputTriggers = ctx.inputTriggers as unknown as InputTriggerServiceContract
  const unavailableStorage: StorageLike = {
    getItem(): never {
      throw new Error('localStorage is unavailable')
    },
    setItem(): never {
      throw new Error('localStorage is unavailable')
    },
    removeItem(): never {
      throw new Error('localStorage is unavailable')
    },
  }
  let browserStorage: StorageLike
  try {
    browserStorage = globalThis.localStorage
  } catch {
    // Browser privacy modes can deny the localStorage getter itself.
    browserStorage = unavailableStorage
  }
  const lockManager = globalThis.navigator?.locks
  const storageCoordination: StorageCoordination = {
    keys: () =>
      browserStorage.key === undefined || browserStorage.length === undefined
        ? []
        : Array.from({ length: browserStorage.length }, (_, index) => browserStorage.key!(index)).filter(
            (key): key is string => key !== null,
          ),
    ...(lockManager === undefined
      ? {}
      : {
          runExclusive: (name: string, task: () => void, signal: AbortSignal) =>
            lockManager.request(name, { mode: 'exclusive', signal }, () => task()),
        }),
  }
  const settingsController = new AnnotationSettingsController(
    ctx.configForms.get<AnnotationSettings>(ANNOTATION_SETTINGS_NAMESPACE),
    browserStorage,
  )
  const featureEnabled = settingsController.feature()
  const officialFileEnabled = settingsController.officialFileAnnotations()
  const officialDiffEnabled = settingsController.officialDiffAnnotations()
  const autoAttachEnabled = settingsController.autoAttach()
  const compactSummaryEnabled = settingsController.compactSummary()
  const marketUpdateController = new MarketUpdateController()
  const noticeHub = new AnnotationNoticeHub()
  ctx.effect(() => () => settingsController.dispose(), 'dsh-annotation: settings controller')
  ctx.effect(() => () => marketUpdateController.dispose(), 'dsh-annotation: market update controller')
  ctx.effect(() => () => noticeHub.dispose(), 'dsh-annotation: notice hub')
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-annotation: dictionaries')
  const annotationT = ctx.locale.bind(NS)
  ctx.effect(() => {
    const style = document.createElement('style')
    style.dataset.dshAnnotation = 'true'
    style.textContent = styles
    document.head.append(style)
    return () => style.remove()
  }, 'dsh-annotation: styles')

  // dsh-focus-chat 可选兼容：未安装时保持被动，适配失败不影响核心功能。
  const focusAdapter = createFocusChatAdapter()
  ctx.effect(() => {
    focusAdapter.start()
    return () => focusAdapter.dispose()
  }, 'dsh-annotation: focus-chat adapter')

  /** 模型协议语言：只读 DSH 当前 locale（已归一化为 zh/en，回退 en）。 */
  const resolveProtocolLocale = (): ProtocolLocale => {
    const locale = ctx.locale.getLocale?.().active
    return locale === 'zh' ? 'zh' : 'en'
  }

  const highlights = new HighlightManager()
  const controllers = new Map<
    SessionId,
    {
      controller: AnnotationController
      dispose: () => void
      commandReleased: boolean
      manualDetached: boolean
      submissionSnapshot: { readonly view: AnnotationView; readonly protocolLocale: ProtocolLocale } | null
    }
  >()
  const sourceSnapshots = new SourceSnapshotStore()
  const annotationTrash = new AnnotationTrashController(
    browserStorage,
    storageCoordination,
    config,
    sourceSnapshots,
    (sessionId) =>
      [...controllers.values()].find((entry) => entry.controller.sessionId === sessionId)?.controller,
  )
  const readFileSnapshot: import('./components/FileWholeAnnotationAction.tsx').ReadFileSnapshot = (
    sessionId,
    path,
    signal,
    range,
  ) =>
    ctx
      .get('remote.workspaceFiles')
      .readBytes(String(sessionId) as SessionId, path, range === undefined ? {} : { range }, signal)
  ctx.effect(() => {
    annotationTrash.refresh()
    return () => {
      annotationTrash.dispose()
      sourceSnapshots.dispose()
    }
  }, 'dsh-annotation: local source archive')
  const mirrorGroups = new Map<AnnotationController, Map<SubmissionId, ReadonlySet<AnnotationController>>>()
  const linkMirrors = (
    submissionId: SubmissionId,
    first: AnnotationController,
    second: AnnotationController,
  ) => {
    const group = new Set([first, second])
    for (const controller of group) {
      const submissions = mirrorGroups.get(controller) ?? new Map()
      submissions.set(submissionId, group)
      mirrorGroups.set(controller, submissions)
    }
    first.syncSubmissionState(second.getSnapshot(), submissionId, second.sessionId)
    second.syncSubmissionState(first.getSnapshot(), submissionId, first.sessionId)
  }
  const syncMirrors = (source: AnnotationController) => {
    const submissions = mirrorGroups.get(source)
    if (submissions === undefined) return
    const snapshot = source.getSnapshot()
    for (const [submissionId, group] of submissions) {
      for (const target of group) {
        if (target !== source) target.syncSubmissionState(snapshot, submissionId, source.sessionId)
      }
    }
  }
  const reconnectMirrors = (sessionId: SessionId, controller: AnnotationController) => {
    for (const [otherId, entry] of controllers) {
      if (entry.controller === controller) continue
      for (const outbox of controller.getSnapshot().outbox) {
        if (outbox.targetSessionId === (otherId as unknown as SessionIdentity)) {
          linkMirrors(outboxSubmissionId(outbox), controller, entry.controller)
        }
      }
      for (const outbox of entry.controller.getSnapshot().outbox) {
        if (outbox.targetSessionId === (sessionId as unknown as SessionIdentity)) {
          linkMirrors(outboxSubmissionId(outbox), entry.controller, controller)
        }
      }
    }
  }
  const dropController = (sessionId: SessionId) => {
    const entry = controllers.get(sessionId)
    if (entry === undefined) return
    entry.dispose()
    controllers.delete(sessionId)
    const submissions = mirrorGroups.get(entry.controller)
    mirrorGroups.delete(entry.controller)
    if (submissions === undefined) return
    for (const [submissionId, group] of submissions) {
      for (const peer of group) {
        if (peer !== entry.controller) mirrorGroups.get(peer)?.delete(submissionId)
      }
    }
  }
  ctx.effect(() => {
    const prune = () => {
      const list = sessions.list.getSnapshot()
      if (list.phase !== 'ready') return
      for (const sessionId of controllers.keys()) {
        if (!Object.prototype.hasOwnProperty.call(list.byId, sessionId)) dropController(sessionId)
      }
    }
    const unsubscribe = sessions.list.subscribe(prune)
    prune()
    return unsubscribe
  }, 'dsh-annotation: Session controller pruning')

  const controllerFor = (sessionId: SessionId): AnnotationController => {
    const existing = controllers.get(sessionId)
    if (existing !== undefined) return existing.controller
    const binding = sessions.binding(sessionId)
    if (binding === undefined) throw new Error(`Session ${String(sessionId)} has no client binding`)
    const controller = new AnnotationController(
      sessionId as unknown as SessionIdentity,
      new AnnotationStorage(browserStorage, sessionId as unknown as SessionIdentity, storageCoordination),
      binding.session,
      config,
    )
    controller.setSourceNavigator(async (annotationId) => {
      const item = controller
        .getSnapshot()
        .annotations.find((candidate) => candidate.annotationId === annotationId)
      const source = item?.source
      try {
        if (source?.kind === 'file') {
          ctx.sidebarRight.openResource(source.resourceAddress, {
            params: source.startLine === undefined ? undefined : { line: source.endLine ?? source.startLine },
          })
          const active = ctx.sidebarRight.active()
          if (active !== undefined) ctx.sidebarRight.focus(active.id)
          return true
        }
        if (source?.kind !== 'official-diff') return false
        const address = `dsh-resource://changes-review/session/${encodeURIComponent(String(source.snapshot.sessionId))}/${source.snapshot.seq}/${source.snapshot.turn}`
        ctx.sidebarRight.openResource(address, { params: { index: source.snapshot.fileIndex } })
        const active = ctx.sidebarRight.active()
        if (active !== undefined) ctx.sidebarRight.focus(active.id)
        return true
      } catch {
        return false
      }
    })
    const chat = ctx.uiConversation.binding(binding).target('chat')
    const stopSourceSnapshots = observeSourceSnapshots(
      controller,
      sourceSnapshots,
      (capture, signal) =>
        captureSourceContent(
          capture,
          readFileSnapshot,
          (messageId) => {
            for (const node of chat.getSnapshot()?.nodes.values() ?? []) {
              if (node.kind !== 'assistant-step') continue
              const data = node.data as AssistantChatData
              if (String(data.finalNode?.messageId) !== String(messageId)) continue
              return data.blocks.flatMap((block) => (block.kind === 'text' ? [block.text] : [])).join('\n')
            }
            return undefined
          },
          signal,
        ),
      annotationTrash.refresh,
      () => controller.setNotice('error', 'trash.error.cleanup'),
      () => {
        if (controller.getSnapshot().notice === null)
          controller.setNotice('error', 'trash.snapshotUnavailable')
      },
    )
    const inboxFace = binding.session.projections.faceOf('inbox')
    let reconciledChat: ChatSnapshot | undefined
    let reconciledInbox: InboxState | undefined
    let reconciled = false
    const reconcile = () => {
      const sessionSnapshot = binding.session.getSnapshot()
      const chatSnapshot = chat.getSnapshot()
      const inbox = inboxFace.getSnapshot() as InboxState | undefined
      const refreshChat = !reconciled || chatSnapshot !== reconciledChat
      if (reconciled && !refreshChat && inbox === reconciledInbox) return
      reconciled = true
      reconciledChat = chatSnapshot
      reconciledInbox = inbox
      controller.reconcile(
        {
          chat: { nodes: chatSnapshot?.nodes ?? EMPTY_CHAT_NODES },
          queue: annotationQueue(inbox),
          hasMore: sessionSnapshot.hasMore,
        },
        refreshChat,
      )
      syncMirrors(controller)
    }
    const input = conversation.input.for(binding.ctx)
    let repairing = false
    const repair = (): void => {
      if (repairing || !featureEnabled.getSnapshot() || !controllers.has(sessionId)) return
      repairing = true
      try {
        repairComposerAttachment(sessionId)
      } finally {
        repairing = false
      }
    }
    const observeInput = (): void => {
      const entry = controllers.get(sessionId)
      const state = input.state.getSnapshot()
      if (entry !== undefined) {
        if (state.phase === 'submitting' && hasComposerAttachment(state)) {
          entry.submissionSnapshot ??= Object.freeze({
            view: controller.getSnapshot(),
            protocolLocale: resolveProtocolLocale(),
          })
        } else {
          entry.submissionSnapshot = null
        }
      }
      repair()
    }
    const unsubscribeController = controller.subscribe(repair)
    const unsubscribeInput = input.state.subscribe(observeInput)
    const unsubscribeSession = binding.session.subscribe(reconcile)
    const unsubscribeChat = chat.subscribe(reconcile)
    const unsubscribeInbox = inboxFace.subscribe(reconcile)
    controllers.set(sessionId, {
      controller,
      commandReleased: false,
      manualDetached: false,
      submissionSnapshot: null,
      dispose: () => {
        stopSourceSnapshots()
        unsubscribeInput()
        unsubscribeController()
        unsubscribeInbox()
        unsubscribeChat()
        unsubscribeSession()
        controller.dispose()
      },
    })
    reconnectMirrors(sessionId, controller)
    reconcile()
    repair()
    return controller
  }

  /** Execute one slash-command line through the Session-addressed command Remote with ordered image and file attachments. */
  const executeCommand = async (
    targetId: SessionId,
    line: string,
    attachments: readonly SubmitAttachment[],
  ): Promise<CommandOutcome> => {
    const binding = sessions.binding(targetId)
    if (binding === undefined) {
      return { ok: false, errorText: `Target Session ${String(targetId)} is unavailable` }
    }
    const remoteCommands = ctx.get('remote.commands') as CommandRemoteFace | undefined
    if (remoteCommands !== undefined) {
      const result = await remoteCommands.execute(targetId, line, attachments)
      if (!result.ok) return { ok: false, errorText: transportMessage(result) }
      const value = result.value
      if (value === undefined) return { ok: false, errorText: 'command was not matched' }
      if (value.result.kind === 'error')
        return { ok: false, errorText: value.result.text ?? 'command failed' }
      return {
        ok: true,
        errorText: '',
        ...(value.result.text === undefined ? {} : { text: value.result.text }),
      }
    }
    if (attachments.length > 0) return { ok: false, errorText: 'attachments are unavailable' }
    const result = await binding.session.command(line)
    if (!result.ok) return { ok: false, errorText: transportMessage(result) }
    if (!result.value.matched) return { ok: false, errorText: 'command was not matched' }
    return { ok: true, errorText: '' }
  }

  const submitAttached = async (
    origin: AnnotationController,
    overallRequirement: string,
    attachments: readonly SubmitAttachment[],
    protocolLocale: ProtocolLocale,
    snapshot: AnnotationView,
  ): Promise<void> => {
    const selectedRetry = retryEntry(snapshot)
    const retry =
      selectedRetry === undefined
        ? undefined
        : origin
            .getSnapshot()
            .outbox.find(
              (item): item is OutboxPayloadEntry =>
                isOutboxPayloadEntry(item) &&
                item.payload.submissionId === selectedRetry.payload.submissionId,
            )
    if (selectedRetry !== undefined) {
      if (retry === undefined || retry.status === 'withdrawn') throw new SubmissionChangedError()
      if (retry.status !== 'ready' && retry.status !== 'failed') return
    }
    const draftCount = selectedAnnotations(snapshot).length
    if (retry === undefined && draftCount > config.maxAnnotationsPerSubmission) {
      origin.setNotice('error', 'error.items')
      throw new Error(`annotation batch exceeds ${config.maxAnnotationsPerSubmission} annotations`)
    }
    // 刷新后附件由用户重新选择；数量或类型不符时不能丢弃原批次的附件继续发送。
    const expectedAttachments = retry?.attachments ?? retry?.images
    if (retry !== undefined) {
      const count = expectedAttachments?.count ?? 0
      const kinds = retry?.attachments?.kinds
      const matches =
        attachments.length === count &&
        attachments.every((attachment, index) => attachment.type === (kinds?.[index] ?? 'image'))
      if (!matches) {
        const message =
          count === 0
            ? annotationT('error.retryAttachmentsAdded')
            : annotationT('error.attachmentsRequired', { count })
        origin.setNotice(
          'error',
          count === 0 ? 'error.retryAttachmentsAdded' : 'error.attachmentsRequired',
          count === 0 ? undefined : { count },
        )
        throw new Error(message)
      }
    }
    const targetId = (retry?.targetSessionId ?? origin.sessionId) as unknown as SessionId
    let attachmentIdentities = retry?.payload.attachmentIdentities
    if (retry === undefined || attachmentIdentities !== undefined) {
      let actual: ReturnType<typeof parseAttachmentIdentities> = Object.freeze([])
      if (attachments.length > 0) {
        const prepared = await executeCommand(
          targetId,
          `/${config.commandName} ${ATTACHMENT_PREPARE_INPUT}`,
          attachments,
        )
        if (!prepared.ok) throw new Error(prepared.errorText)
        try {
          actual = parseAttachmentIdentities(JSON.parse(prepared.text ?? 'null'))
          if (
            actual.length !== attachments.length ||
            actual.some((item, index) => item.type !== attachments[index]!.type)
          ) {
            throw new Error('Preflight attachment count or order does not match the request')
          }
        } catch (cause: unknown) {
          const message = annotationT('error.prepareAttachments')
          origin.setNotice('error', 'error.prepareAttachments')
          throw new Error(message, { cause })
        }
      }
      if (attachmentIdentities !== undefined && !sameAttachmentIdentities(attachmentIdentities, actual)) {
        const message = annotationT('error.retryAttachmentsChanged')
        origin.setNotice('error', 'error.retryAttachmentsChanged')
        throw new Error(message)
      }
      attachmentIdentities = actual
    }
    const entry = origin.createOutbox(
      'queue',
      targetId as unknown as SessionIdentity,
      overallRequirement,
      retry === undefined ? attachmentMetadata(attachments) : undefined,
      protocolLocale,
      snapshot,
      attachmentIdentities,
    )
    if (entry.status !== 'ready' && entry.status !== 'failed') return
    const target = targetId === (origin.sessionId as unknown as SessionId) ? origin : controllerFor(targetId)
    if (target !== origin) {
      target.adoptOutbox(entry)
      linkMirrors(entry.payload.submissionId, origin, target)
    }
    const rejectLocal = (notice: 'items' | 'payload', message: string): never => {
      origin.setNotice('error', notice === 'items' ? 'error.items' : 'error.payload')
      throw new Error(message)
    }
    if (entry.payload.annotations.length > config.maxAnnotationsPerSubmission) {
      rejectLocal('items', `annotation batch exceeds ${config.maxAnnotationsPerSubmission} annotations`)
    }
    const payloadBytes = new TextEncoder().encode(JSON.stringify(entry.payload)).byteLength
    if (payloadBytes > config.maxPayloadBytes) {
      rejectLocal('payload', `annotation payload exceeds ${config.maxPayloadBytes} bytes`)
    }
    const binding = sessions.binding(targetId)
    if (binding === undefined) {
      const message = `Target Session ${String(targetId)} is unavailable`
      origin.markFailed(entry.payload.submissionId, message)
      if (target !== origin) target.markFailed(entry.payload.submissionId, message)
      throw new Error(message)
    }
    origin.markSending(entry.payload.submissionId)
    if (target !== origin) target.markSending(entry.payload.submissionId)
    let outcome: CommandOutcome
    try {
      outcome = await executeCommand(
        targetId,
        encodeSubmissionCommand(config.commandName, entry.payload),
        attachments,
      )
    } catch (cause: unknown) {
      const message = failureMessage(cause)
      origin.markFailed(entry.payload.submissionId, message)
      if (target !== origin) target.markFailed(entry.payload.submissionId, message)
      throw cause instanceof Error ? cause : new Error(message)
    }
    if (!outcome.ok) {
      const message =
        outcome.errorText === ATTACHMENT_IDENTITY_MISMATCH
          ? annotationT('error.retryAttachmentsChanged')
          : outcome.errorText
      origin.markFailed(entry.payload.submissionId, message)
      if (target !== origin) target.markFailed(entry.payload.submissionId, message)
      throw new Error(message)
    }
    origin.markAccepted(entry.payload.submissionId)
    if (target !== origin) target.markAccepted(entry.payload.submissionId)
  }

  const withdraw = async (origin: AnnotationController, submissionId: SubmissionId): Promise<void> => {
    const entry = origin
      .getSnapshot()
      .outbox.find((item) => isOutboxPayloadEntry(item) && item.payload.submissionId === submissionId)
    if (
      entry === undefined ||
      entry.status !== 'queued' ||
      entry.payload.annotations.some((annotation) => annotation.source?.kind === 'diff')
    )
      return
    const targetId = entry.targetSessionId as unknown as SessionId
    const binding = sessions.binding(targetId)
    if (binding === undefined) {
      origin.setNotice('error', 'error.targetSessionUnavailable')
      return
    }
    const target = targetId === (origin.sessionId as unknown as SessionId) ? origin : controllerFor(targetId)
    const inbox = binding.session.projections.faceOf('inbox').getSnapshot() as InboxState | undefined
    if (inbox === undefined) return
    if (!inbox['next-turn'].some((message) => message.id === String(entry.messageId))) {
      origin.markQueueClaimed(submissionId)
      if (target !== origin) target.markQueueClaimed(submissionId)
      return
    }
    const result = await binding.session.updateQueue(entry.messageId as unknown as MessageId, {
      kind: 'remove',
    })
    if (!result.ok) {
      if (result.error.code === 'session/queue-item-not-found') {
        const sessionSnapshot = binding.session.getSnapshot()
        const chatSnapshot = ctx.uiConversation.binding(binding).target('chat').getSnapshot()
        target.reconcile({
          chat: { nodes: chatSnapshot?.nodes ?? EMPTY_CHAT_NODES },
          queue: annotationQueue(
            binding.session.projections.faceOf('inbox').getSnapshot() as InboxState | undefined,
          ),
          hasMore: sessionSnapshot.hasMore,
        })
        if (target !== origin) {
          origin.syncSubmissionState(target.getSnapshot(), submissionId, target.sessionId)
        }
        origin.markQueueClaimed(submissionId)
        if (target !== origin) target.markQueueClaimed(submissionId)
        return
      }
      origin.setNotice('error', 'error.send')
      return
    }
    origin.markWithdrawn(submissionId)
    if (target !== origin) target.markWithdrawn(submissionId)
  }

  const discardOutbox = (origin: AnnotationController, submissionId: SubmissionId): void => {
    const entry = origin
      .getSnapshot()
      .outbox.find((item) => isOutboxPayloadEntry(item) && item.payload.submissionId === submissionId)
    if (entry === undefined) return
    const targetId = entry.targetSessionId as unknown as SessionId
    const binding = sessions.binding(targetId)
    let target = origin
    if (binding !== undefined) {
      target = targetId === (origin.sessionId as unknown as SessionId) ? origin : controllerFor(targetId)
      const chat = ctx.uiConversation.binding(binding).target('chat').getSnapshot()
      target.reconcile({
        chat: { nodes: chat?.nodes ?? EMPTY_CHAT_NODES },
        queue: annotationQueue(
          binding.session.projections.faceOf('inbox').getSnapshot() as InboxState | undefined,
        ),
        hasMore: binding.session.getSnapshot().hasMore,
      })
      if (target !== origin) origin.syncSubmissionState(target.getSnapshot(), submissionId, target.sessionId)
    }
    origin.discardOutbox(submissionId)
    if (target !== origin) target.discardOutbox(submissionId)
  }

  const claimFor = (sessionId: SessionId): CommandClaim =>
    Object.freeze({
      name: config.commandName,
      token: COMPOSER_ATTACHMENT_TOKEN,
      attachments: true,
      async submit(
        args: string,
        actx: ClientContext,
        attachments: readonly SubmitAttachment[],
      ): Promise<SubmitOutcome> {
        if (sessions.scopeOf(actx) !== sessionId) {
          return { kind: 'error', text: 'Annotation attachment belongs to another Session.' }
        }
        const input = conversation.input.for(actx)
        const state = input.state.getSnapshot()
        // Re-check slash commands inside submit: an Enter that lands before the
        // command-release watcher must still route through the official command
        // interface without creating an outbox or marking annotations sent.
        const visible = stripComposerToken(args.trim() === '' ? visibleComposerDraft(state) : args).trim()
        if (visible.startsWith('/')) {
          return executeCommand(sessionId, visible, attachments).then(
            (outcome) =>
              outcome.ok ? { kind: 'success' as const } : { kind: 'error' as const, text: outcome.errorText },
            (cause: unknown) => ({ kind: 'error' as const, text: failureMessage(cause) }),
          )
        }
        const serialization = new AbortController()
        try {
          const controller = controllerFor(sessionId)
          const prepared = controllers.get(sessionId)?.submissionSnapshot
          const snapshot = prepared?.view ?? controller.getSnapshot()
          const hasAttachable = retryEntry(snapshot) !== undefined || selectedAnnotations(snapshot).length > 0
          if (!hasAttachable) {
            // 注解已被清空而 claim 仍被占用：不要用英文报错卡住发送。
            // 结算后释放 claim，下一次 Enter 走官方普通消息通道，文字不丢失。
            scheduleDetachRetry(sessionId)
            return { kind: 'error', text: annotationT('error.emptySubmit') }
          }
          const overallRequirement = await serializeComposerRequirement(
            state,
            inputTriggers.sessionOf(actx),
            serialization.signal,
          )
          await submitAttached(
            controller,
            overallRequirement,
            attachments,
            prepared?.protocolLocale ?? resolveProtocolLocale(),
            snapshot,
          )
          return { kind: 'success' }
        } catch (cause: unknown) {
          return {
            kind: 'error',
            text:
              cause instanceof SubmissionChangedError
                ? annotationT('error.submissionChanged')
                : failureMessage(cause),
          }
        } finally {
          serialization.abort()
        }
      },
    })

  const ensureComposerAttachment = (sessionId: SessionId): boolean => {
    if (!featureEnabled.getSnapshot()) return false
    const binding = sessions.binding(sessionId)
    if (binding === undefined) return false
    const controller = controllerFor(sessionId)
    const input = conversation.input.for(binding.ctx)
    const state = input.state.getSnapshot()
    if (state.phase === 'claimed' && state.claim?.token === COMPOSER_ATTACHMENT_TOKEN) return true
    if (state.phase !== 'plain') return false
    // Never arm the composer while it carries an official slash command.
    if (isSlashCommandLine(state)) return false
    const snapshot = controller.getSnapshot()
    const retry = retryEntry(snapshot)
    if (retry === undefined && selectedAnnotations(snapshot).length === 0) return false
    const legacy = snapshot.overallRequirementDraft
    if (legacy.trim() !== '') input.setDraft(mergeLegacyRequirement(state.draft, legacy))
    const attached = attachComposer(binding.ctx, input, claimFor(sessionId))
    if (attached) {
      const entry = controllers.get(sessionId)
      if (entry !== undefined) entry.manualDetached = false
    }
    if (attached && legacy.trim() !== '') controller.setOverallRequirementDraft('')
    return attached
  }

  const toggleComposerAttachment = (sessionId: SessionId): boolean => {
    const binding = sessions.binding(sessionId)
    if (binding === undefined) return false
    const input = conversation.input.for(binding.ctx)
    if (hasComposerAttachment(input.state.getSnapshot())) {
      const entry = controllers.get(sessionId)
      if (entry !== undefined) entry.manualDetached = true
      return detachComposer(binding.ctx, input)
    }
    return ensureComposerAttachment(sessionId)
  }

  /**
   * Keep the invisible attachment in sync with the composer on every input
   * change: release the claim while a slash command occupies the line (and
   * re-arm it once the command state ends), withdraw the token entirely when
   * nothing attachable remains, and never override a manual detach.
   */
  const repairComposerAttachment = (sessionId: SessionId): void => {
    const binding = sessions.binding(sessionId)
    if (binding === undefined) return
    const controller = controllerFor(sessionId)
    const entry = controllers.get(sessionId)
    if (entry === undefined) return
    const input = conversation.input.for(binding.ctx)
    const state = input.state.getSnapshot()
    const snapshot = controller.getSnapshot()
    const attachable = retryEntry(snapshot) !== undefined || selectedAnnotations(snapshot).length > 0
    const attached = hasComposerAttachment(state)
    if (isSlashCommandLine(state)) {
      // Command state: release the claim and drop the zero-width token, while
      // annotations stay logically attached. Only OUR automatic release marks
      // the command-exit re-arm; a manual detach never does.
      if (attached) {
        entry.commandReleased = true
        detachComposer(binding.ctx, input)
      }
      return
    }
    const commandReleased = entry.commandReleased
    entry.commandReleased = false
    // Nothing attachable remains (drafts cleared, retry discarded): withdraw
    // any surviving attachment, including one still in the claimed phase.
    if (!attachable) {
      if (attached) detachComposer(binding.ctx, input)
      return
    }
    if (state.phase !== 'plain' || entry.manualDetached) return
    // Arm the claim only when this plugin owns the release: a surviving
    // unclaimed token, or an exit from our slash-command release. A manual
    // detach stays detached until the user (or auto-attach) arms it again.
    if (state.claim?.token !== COMPOSER_ATTACHMENT_TOKEN) {
      if (
        state.draft.startsWith(COMPOSER_ATTACHMENT_TOKEN) ||
        commandReleased ||
        autoAttachEnabled.getSnapshot()
      ) {
        ensureComposerAttachment(sessionId)
      }
    }
  }

  const faceFor = (sessionId: SessionId): AnnotationInjected => {
    const controller = controllerFor(sessionId)
    const canEdit = (): boolean => {
      const binding = sessions.binding(sessionId)
      return (
        binding !== undefined &&
        conversation.input.for(binding.ctx).state.getSnapshot().phase !== 'submitting'
      )
    }
    const changeSendIntent = (change: () => void): void => {
      if (!canEdit()) return
      change()
      repairComposerAttachment(sessionId)
    }
    return {
      hooks: {
        annotations: controller,
        compactSummary: compactSummaryEnabled,
      },
      annotationT,
      bindNoticeHost: (anchor) => noticeHub.activate(controller, anchor),
      beginSelection: (capture) => changeSendIntent(() => controller.beginSelection(capture)),
      chooseOverlap: (annotationId) => changeSendIntent(() => controller.chooseOverlap(annotationId)),
      dismissOverlap: () => controller.dismissOverlap(),
      suspendEditor: () => controller.suspendEditor(),
      resumeEditor: (key) => changeSendIntent(() => controller.resumeEditor(key)),
      discardEditorDraft: (key) => changeSendIntent(() => controller.discardEditorDraft(key)),
      toggleSelected: (annotationId) =>
        changeSendIntent(() => {
          const selecting = !controller.getSnapshot().selectedAnnotationIds.includes(annotationId)
          if (selecting) {
            const entry = controllers.get(sessionId)
            if (entry !== undefined) entry.manualDetached = false
          }
          controller.toggleSelected(annotationId)
          if (selecting) ensureComposerAttachment(sessionId)
        }),
      setProcessingMode: (mode) => changeSendIntent(() => controller.setProcessingMode(mode)),
      selectRetry: (submissionId) =>
        changeSendIntent(() => {
          const binding = sessions.binding(sessionId)
          if (binding !== undefined) detachComposer(binding.ctx, conversation.input.for(binding.ctx))
          controller.selectRetry(submissionId)
          if (retryEntry(controller.getSnapshot()) !== undefined) ensureComposerAttachment(sessionId)
        }),
      openAnnotation: (annotationId, presentation) =>
        changeSendIntent(() => controller.openAnnotation(annotationId, presentation)),
      updateEditorText: (text) => changeSendIntent(() => controller.updateEditorText(text)),
      confirmLongSelection: () => changeSendIntent(() => controller.confirmLongSelection()),
      saveEditor: () => {
        if (!canEdit()) throw new Error(annotationT('error.submitting'))
        if (controller.getSnapshot().editor?.kind === 'new') {
          const entry = controllers.get(sessionId)
          if (entry !== undefined) entry.manualDetached = false
        }
        return controller.saveEditor()
      },
      closeEditor: (force) => (force === true && !canEdit() ? false : controller.closeEditor(force)),
      detachAnnotations: (ids) =>
        changeSendIntent(() => {
          if (!controller.detachAnnotations(ids)) controller.setNotice('error', 'trash.error.write')
        }),
      trashAnnotations: (ids) =>
        changeSendIntent(() => {
          try {
            if (!controller.trashAnnotations(ids)) controller.setNotice('error', 'trash.error.write')
          } catch (error) {
            controller.setNotice(
              'error',
              error instanceof Error && error.message === 'annotation-submission-locked'
                ? 'trash.error.locked'
                : 'trash.error.write',
            )
          }
        }),
      deleteDraft: (annotationId) => changeSendIntent(() => controller.deleteDraft(annotationId)),
      undoDelete: () => changeSendIntent(() => controller.undoDelete()),
      dismissDeleteUndo: () => controller.dismissDeleteUndo(),
      setPanelOpen: (open) => controller.setPanelOpen(open),
      setRecordExpanded: (expanded) => controller.setRecordExpanded(expanded),
      autoAttachEnabled: () => autoAttachEnabled.getSnapshot(),
      ensureComposerAttachment: () => ensureComposerAttachment(sessionId),
      toggleComposerAttachment: () => toggleComposerAttachment(sessionId),
      repairComposerAttachment: () => repairComposerAttachment(sessionId),
      withdraw: async (submissionId) => {
        if (canEdit()) await withdraw(controller, submissionId)
      },
      discardOutbox: (submissionId) => changeSendIntent(() => discardOutbox(controller, submissionId)),
      navigate: (annotationId) => controller.navigate(annotationId),
      annotateMessage: (messageId) => canEdit() && controller.annotateMessage(messageId),
      registerEndpoint: (messageId, endpoint) => controller.registerEndpoint(messageId, endpoint),
      updateHighlightRanges: (messageId, ranges) => highlights.update(messageId, ranges),
      activateHighlight: (messageId, range) => highlights.activate(messageId, range),
      removeHighlights: (messageId) => highlights.remove(messageId),
      highlightsSupported: () => highlights.supported(),
    }
  }

  ctx.slots.inject('shell.overlay', () =>
    ctx.slots.register(
      {
        name: 'shell.overlay',
        id: 'dsh-annotation-notice',
        locale: NS,
        inject: () => noticeHub.inject(),
      },
      AnnotationToastHost,
    ),
  )

  ctx.slots.inject('settings.section', () =>
    ctx.slots.register(
      {
        name: 'settings.section',
        id: ANNOTATION_SETTINGS_NAMESPACE,
        order: 22,
        label: () => annotationT('settings.title'),
        locale: NS,
        inject: () => {
          const settings = settingsController.inject()
          const market = marketUpdateController.inject()
          const trash = annotationTrash.inject()
          return {
            ...settings,
            ...market,
            ...trash,
            hooks: { ...settings.hooks, ...market.hooks, ...trash.hooks, sessionCatalog: sessions.list },
          }
        },
      },
      AnnotationPluginCard,
    ),
  )

  const beginFileAnnotation = (source: FileAnnotationSource, rect: DOMRect): void => {
    const entry = [...controllers.values()].find(
      (candidate) => String(candidate.controller.sessionId) === String(source.sessionId),
    )
    if (entry === undefined) return
    entry.controller.beginSelection({
      source: compactFileSource(source),
      quote: Object.freeze({ exact: '', prefix: '', suffix: '', start: 0, end: 0 }),
      rect: Object.freeze({ top: rect.top, left: rect.left, bottom: rect.bottom, right: rect.right }),
    })
  }

  const beginOfficialDiff = (source: OfficialDiffAnnotationSource, rect: DOMRect): void => {
    const entry = [...controllers.values()].find(
      (candidate) => String(candidate.controller.sessionId) === String(source.snapshot.sessionId),
    )
    if (entry === undefined) return
    entry.controller.beginSelection({
      source: compactOfficialDiffSource(source),
      quote: Object.freeze({ exact: '', prefix: '', suffix: '', start: 0, end: 0 }),
      rect: Object.freeze({ top: rect.top, left: rect.left, bottom: rect.bottom, right: rect.right }),
    })
  }

  const installConversationIntegrations = (): (() => void) => {
    const readFilePage: import('./components/FileWholeAnnotationAction.tsx').ReadFilePage = (
      sessionId,
      path,
      offset,
      limit,
      signal,
    ) =>
      ctx.get('remote.workspaceFiles').read(String(sessionId) as SessionId, path, { offset, limit }, signal)
    const previewSources = new Map<string, FileAnnotationSource>()
    const registerPreviewSource = (source: FileAnnotationSource): (() => void) => {
      previewSources.set(source.resourceAddress, source)
      return () => {
        if (previewSources.get(source.resourceAddress) === source)
          previewSources.delete(source.resourceAddress)
      }
    }
    const disposers = [
      ctx.slots.inject('deliverables.review.file.actions', () =>
        ctx.slots.register(
          {
            name: 'deliverables.review.file.actions',
            id: 'dsh-annotation-official-diff-action',
            locale: NS,
          },
          createDiffReviewAction(beginOfficialDiff, officialDiffEnabled),
        ),
      ),
      installDiffIntegration(
        {
          get: (sessionId) =>
            [...controllers.values()].find(
              (candidate) => String(candidate.controller.sessionId) === String(sessionId),
            )?.controller,
        },
        {
          t: annotationT,
          annotate: annotationT('selection.annotate'),
          title: annotationT('editor.editTitle'),
          annotation: annotationT('editor.annotationLabel'),
          save: annotationT('editor.save'),
          cancel: annotationT('editor.cancel'),
          edit: annotationT('source.edit'),
          locate: annotationT('source.locate'),
          wholeFile: annotationT('source.wholeFile'),
          failed: annotationT('editor.autosaveFailed'),
          status: {
            draft: annotationT('status.draft'),
            queued: annotationT('status.queued'),
            sent: annotationT('status.sent'),
            processed: annotationT('status.processed'),
          },
        },
        highlights,
        officialDiffEnabled,
      ),
      ctx.slots.inject('sidebar.right.tab.document.action', () =>
        DOCUMENT_RENDERER_IDS.map((key) =>
          ctx.slots.register(
            {
              name: 'sidebar.right.tab.document.action',
              key,
              locale: NS,
              registrant: 'dsh-annotation',
            },
            FileWholeAnnotationAction(
              beginFileAnnotation,
              readFileSnapshot,
              registerPreviewSource,
              readFilePage,
              officialFileEnabled,
            ),
          ),
        ),
      ),
      ctx.slots.inject('sidebar.right.tab.document.actions', () =>
        ctx.slots.register(
          {
            name: 'sidebar.right.tab.document.actions',
            id: 'dsh-annotation-office-whole-file',
            locale: NS,
          },
          OfficeWholeAnnotationAction(
            beginFileAnnotation,
            readFileSnapshot,
            registerPreviewSource,
            officialFileEnabled,
          ),
        ),
      ),
      installDocumentIntegration(
        {
          get: (sessionId) =>
            [...controllers.entries()].find(([id]) => String(id) === String(sessionId))?.[1]?.controller,
        },
        (key) => annotationT(key),
        (address) => previewSources.get(address),
        highlights,
        officialFileEnabled,
      ),
      ctx.slots.inject('conversation.chat.node', () => {
        const restoreAssistantRenderers = decorateAssistantRenderers(ctx, faceFor)
        const removeUser = ctx.slots.register(
          {
            name: 'conversation.chat.node',
            key: 'user',
            priority: -100,
            locale: NS,
            inject: faceFor,
          },
          UserNode,
        )
        const removeSteering = ctx.slots.register(
          {
            name: 'conversation.chat.node',
            key: 'steering',
            priority: -100,
            locale: NS,
            inject: faceFor,
          },
          SteeringNode,
        )
        return () => {
          restoreAssistantRenderers()
          removeSteering()
          removeUser()
        }
      }),
      ctx.slots.inject('conversation.input.dock', () =>
        ctx.slots.register(
          {
            name: 'conversation.input.dock',
            id: 'dsh-annotation',
            order: -20,
            locale: NS,
            inject: faceFor,
          },
          AnnotationExperience,
        ),
      ),
      ctx.slots.inject('conversation.input.right', () =>
        ctx.slots.register(
          {
            name: 'conversation.input.right',
            id: 'dsh-annotation-record-toggle',
            order: -20,
            locale: NS,
            inject: faceFor,
          },
          AnnotationRecordToggle,
        ),
      ),
      ctx.slots.inject('conversation.input.overlay', () =>
        ctx.slots.register(
          {
            name: 'conversation.input.overlay',
            id: 'dsh-annotation-composer-chip',
            order: -20,
            locale: NS,
            inject: faceFor,
          },
          AnnotationComposerChip,
        ),
      ),
      ctx.slots.inject('conversation.chat.assistant-actions', () =>
        ctx.slots.register(
          {
            name: 'conversation.chat.assistant-actions',
            id: 'dsh-annotation',
            order: 15,
            locale: NS,
            inject: faceFor,
          },
          AssistantAnnotationAction,
        ),
      ),
      ctx.slots.inject('conversation.chat.commandview', () => [
        ctx.slots.register(
          {
            name: 'conversation.chat.commandview',
            key: config.commandName,
            inject: faceFor,
          },
          HiddenCommandRow,
        ),
        ...LEGACY_COMMAND_NAMES.filter((name) => name !== config.commandName).map((name) =>
          ctx.slots.register(
            {
              name: 'conversation.chat.commandview',
              key: name,
              inject: faceFor,
            },
            HiddenCommandRow,
          ),
        ),
      ]),
    ]
    return () => {
      for (const dispose of disposers.reverse()) dispose()
    }
  }

  const pendingDetachRetries = new Map<SessionId, () => void>()

  const cancelPendingDetachRetries = (): void => {
    for (const cancel of pendingDetachRetries.values()) cancel()
    pendingDetachRetries.clear()
  }

  /**
   * Retry a submit-time attachment detach once the official input leaves `submitting`.
   *
   * A failed submit returns the composer to this plugin's claim; while disabled there is
   * no UI left to release it, so the invisible claim token would otherwise survive until
   * the plugin is re-enabled.
   */
  const scheduleDetachRetry = (sessionId: SessionId): void => {
    if (pendingDetachRetries.has(sessionId)) return
    const binding = sessions.binding(sessionId)
    if (binding === undefined) return
    const input = conversation.input.for(binding.ctx)
    let unsubscribe: () => void = () => undefined
    const cancel = () => {
      unsubscribe()
      pendingDetachRetries.delete(sessionId)
    }
    unsubscribe = input.state.subscribe(() => {
      if (sessions.binding(sessionId) === undefined) {
        cancel()
        return
      }
      if (input.state.getSnapshot().phase === 'submitting') return
      cancel()
      if (hasComposerAttachment(input.state.getSnapshot())) detachComposer(binding.ctx, input)
    })
    pendingDetachRetries.set(sessionId, cancel)
  }

  const detachAllComposerAttachments = (): void => {
    for (const [sessionId, entry] of controllers) {
      entry.commandReleased = false
      const binding = sessions.binding(sessionId)
      if (binding === undefined) continue
      const input = conversation.input.for(binding.ctx)
      if (!hasComposerAttachment(input.state.getSnapshot())) continue
      if (detachComposer(binding.ctx, input)) continue
      scheduleDetachRetry(sessionId)
    }
  }

  ctx.effect(() => {
    const flush = (): void => {
      for (const entry of controllers.values()) entry.controller.flush()
    }
    const visibility = (): void => {
      if (document.visibilityState === 'hidden') flush()
    }
    window.addEventListener('pagehide', flush)
    document.addEventListener('visibilitychange', visibility)
    return () => {
      window.removeEventListener('pagehide', flush)
      document.removeEventListener('visibilitychange', visibility)
      flush()
    }
  }, 'dsh-annotation: editor lifecycle persistence')

  ctx.effect(() => {
    const synchronize = (event: StorageEvent): void => {
      if (event.key === null || (event.storageArea !== null && event.storageArea !== browserStorage)) return
      for (const [sessionId, entry] of controllers) {
        const prefix = `dsh-annotation:v1:${sessionId}`
        if (event.key === prefix || event.key.startsWith(`${prefix}:journal:`))
          entry.controller.synchronizeStorage()
      }
      if (event.key.startsWith('dsh-annotation:')) annotationTrash.refresh()
    }
    window.addEventListener('storage', synchronize)
    return () => window.removeEventListener('storage', synchronize)
  }, 'dsh-annotation: cross-page storage synchronization')

  ctx.effect(
    () => () => {
      highlights.dispose()
      for (const entry of controllers.values()) entry.dispose()
      controllers.clear()
      mirrorGroups.clear()
    },
    'dsh-annotation: controller cleanup',
  )

  ctx.effect(() => {
    let disposeIntegrations: (() => void) | undefined
    const sync = (): void => {
      if (featureEnabled.getSnapshot()) {
        cancelPendingDetachRetries()
        disposeIntegrations ??= installConversationIntegrations()
        for (const sessionId of controllers.keys()) repairComposerAttachment(sessionId)
        return
      }
      for (const entry of controllers.values()) entry.controller.suspendEditor()
      detachAllComposerAttachments()
      const dispose = disposeIntegrations
      disposeIntegrations = undefined
      dispose?.()
      highlights.dispose()
    }
    const unsubscribeFeature = featureEnabled.subscribe(sync)
    sync()
    return () => {
      unsubscribeFeature()
      cancelPendingDetachRetries()
      disposeIntegrations?.()
    }
  }, 'dsh-annotation: dynamic conversation integrations')
}

export type { AnnotationConfig, MessageIdentity }
