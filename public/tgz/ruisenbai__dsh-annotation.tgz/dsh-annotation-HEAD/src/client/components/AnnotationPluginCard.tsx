/** Main-Settings section for Host-backed annotation settings. */

import { Button, Switch, Tag } from '@deepseek-ai/dsh-client-ui-primitives'
import type {
  InjectFace,
  PropsLocale,
  PropsRuntime,
  SnapshotSelectorHook,
} from '@deepseek-ai/dsh-client-ui-slots'
import type { SessionListState } from '@deepseek-ai/dsh-api-session-controller/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type { AnnotationSettingsInjected } from '../feature-toggle.ts'
import type { MarketUpdateInjected, MarketUpdateState } from '../market-update.ts'
import type { AnnotationTrashInjected } from '../annotation-trash.ts'
import { AnnotationTrashPanel } from './AnnotationTrashPanel.tsx'

/** Full props for the annotation section in main Settings. */
export type AnnotationPluginCardProps = PropsRuntime<'settings.section'> &
  PropsLocale<'dshAnnotation'> &
  InjectFace<AnnotationSettingsInjected & MarketUpdateInjected & AnnotationTrashInjected> & {
    readonly useSessionCatalog: SnapshotSelectorHook<SessionListState>
  }

function marketStatus(props: AnnotationPluginCardProps, state: MarketUpdateState) {
  if (state.phase === 'idle') return props.t('settings.updateIdle')
  if (state.phase === 'checking') return props.t('settings.updateChecking')
  if (state.phase === 'unavailable') return props.t('settings.marketUnavailable')
  if (state.phase === 'current') return props.t('settings.updateCurrent')
  if (state.phase === 'available') return props.t('settings.updateAvailable')
  if (state.phase === 'updating') {
    return state.progressPercent === null
      ? props.t('settings.updating')
      : props.t('settings.updatingPercent', { percent: state.progressPercent })
  }
  if (state.phase === 'succeeded') return props.t('settings.updateSucceeded')
  if (state.phase === 'rolling-back') return props.t('settings.rollingBack')
  if (state.phase === 'rolled-back') return props.t('settings.rolledBack')
  if (state.phase === 'restarting') return props.t('settings.restarting')
  return state.error ?? props.t('settings.updateFailed')
}

/**
 * Render staged annotation settings in the main Settings Plugins section.
 * @param props - composed Settings-section props.
 * @returns the card, or nothing while the Host namespace is unavailable.
 */
export function AnnotationPluginCard(props: AnnotationPluginCardProps) {
  const state = props.useSettingsCard((snapshot) => snapshot)
  const market = props.useMarketUpdate((snapshot) => snapshot)
  if (!state.available) return null
  return (
    <div className="dia-plugin-card">
      <div className="dia-plugin-card__body">
        <h2 className="dia-plugin-card__title">{props.t('settings.title')}</h2>
        <p className="dia-plugin-card__intro">{props.t('settings.cardDescription')}</p>
        <AnnotationTrashPanel {...props} />
        {state.dirty ? <Tag tone="neutral">{props.t('settings.unsaved')}</Tag> : null}
        {!state.writable ? (
          <p className="dia-plugin-card__read-only" role="status">
            {props.t('settings.readOnly')}
          </p>
        ) : null}
        <div className="dia-plugin-card__field">
          <div className="dia-plugin-card__field-head">
            <span className="dia-plugin-card__field-label">{props.t('settings.toggle')}</span>
            {state.overridden ? (
              <span className="dia-plugin-card__field-actions">
                <Tag tone="neutral">{props.t('settings.overridden')}</Tag>
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  className="dia-plugin-card__reset"
                  disabled={!state.writable || state.saving}
                  onClick={props.resetEnabled}
                >
                  {props.t('settings.reset')}
                </Button>
              </span>
            ) : null}
          </div>
          <span className="dia-plugin-card__switch-row">
            <span className="dia-plugin-card__switch-state">
              {props.t(state.enabled ? 'settings.on' : 'settings.off')}
            </span>
            <Switch
              checked={state.enabled}
              className="dia-plugin-card__switch"
              label={props.t('settings.toggle')}
              disabled={!state.writable || state.saving}
              onChange={props.setEnabled}
            />
          </span>
          <p className="dia-plugin-card__hint">{props.t('settings.description')}</p>
        </div>
        <div className="dia-plugin-card__field">
          <div className="dia-plugin-card__field-head">
            <span className="dia-plugin-card__field-label">{props.t('settings.officialFile')}</span>
            {state.officialFileAnnotationsOverridden ? (
              <span className="dia-plugin-card__field-actions">
                <Tag tone="neutral">{props.t('settings.overridden')}</Tag>
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  className="dia-plugin-card__reset"
                  disabled={!state.writable || state.saving}
                  onClick={props.resetOfficialFileAnnotations}
                >
                  {props.t('settings.reset')}
                </Button>
              </span>
            ) : null}
          </div>
          <span className="dia-plugin-card__switch-row">
            <span className="dia-plugin-card__switch-state">
              {props.t(state.officialFileAnnotations ? 'settings.on' : 'settings.off')}
            </span>
            <Switch
              checked={state.officialFileAnnotations}
              className="dia-plugin-card__switch"
              label={props.t('settings.officialFile')}
              disabled={!state.writable || state.saving}
              onChange={props.setOfficialFileAnnotations}
            />
          </span>
          <p className="dia-plugin-card__hint">{props.t('settings.officialHint')}</p>
        </div>
        <div className="dia-plugin-card__field">
          <div className="dia-plugin-card__field-head">
            <span className="dia-plugin-card__field-label">{props.t('settings.officialDiff')}</span>
            {state.officialDiffAnnotationsOverridden ? (
              <span className="dia-plugin-card__field-actions">
                <Tag tone="neutral">{props.t('settings.overridden')}</Tag>
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  className="dia-plugin-card__reset"
                  disabled={!state.writable || state.saving}
                  onClick={props.resetOfficialDiffAnnotations}
                >
                  {props.t('settings.reset')}
                </Button>
              </span>
            ) : null}
          </div>
          <span className="dia-plugin-card__switch-row">
            <span className="dia-plugin-card__switch-state">
              {props.t(state.officialDiffAnnotations ? 'settings.on' : 'settings.off')}
            </span>
            <Switch
              checked={state.officialDiffAnnotations}
              className="dia-plugin-card__switch"
              label={props.t('settings.officialDiff')}
              disabled={!state.writable || state.saving}
              onChange={props.setOfficialDiffAnnotations}
            />
          </span>
          <p className="dia-plugin-card__hint">{props.t('settings.officialHint')}</p>
        </div>
        <div className="dia-plugin-card__field">
          <div className="dia-plugin-card__field-head">
            <span className="dia-plugin-card__field-label">{props.t('settings.autoAttach')}</span>
            {state.autoAttachOverridden ? (
              <span className="dia-plugin-card__field-actions">
                <Tag tone="neutral">{props.t('settings.overridden')}</Tag>
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  className="dia-plugin-card__reset"
                  disabled={!state.writable || state.saving}
                  onClick={props.resetAutoAttach}
                >
                  {props.t('settings.reset')}
                </Button>
              </span>
            ) : null}
          </div>
          <span className="dia-plugin-card__switch-row">
            <span className="dia-plugin-card__switch-state">
              {props.t(state.autoAttach ? 'settings.on' : 'settings.off')}
            </span>
            <Switch
              checked={state.autoAttach}
              className="dia-plugin-card__switch"
              label={props.t('settings.autoAttach')}
              disabled={!state.writable || state.saving}
              onChange={props.setAutoAttach}
            />
          </span>
          <p className="dia-plugin-card__hint">{props.t('settings.autoAttachHint')}</p>
        </div>
        <div className="dia-plugin-card__field">
          <div className="dia-plugin-card__field-head">
            <span className="dia-plugin-card__field-label">{props.t('settings.updateTitle')}</span>
            {market.stability === 'beta' ? <Tag tone="warning">{props.t('settings.marketBeta')}</Tag> : null}
          </div>
          <p className="dia-plugin-card__hint">{props.t('settings.updateDescription')}</p>
          {market.installedVersion !== null || market.latestVersion !== null ? (
            <div className="dia-plugin-card__versions">
              {market.installedVersion !== null ? (
                <Tag tone="neutral">
                  {props.t('settings.installedVersion', { version: market.installedVersion })}
                </Tag>
              ) : null}
              {market.latestVersion !== null ? (
                <Tag tone={market.phase === 'available' ? 'info' : 'quiet'}>
                  {props.t('settings.latestVersion', { version: market.latestVersion })}
                </Tag>
              ) : null}
            </div>
          ) : null}
          <p
            className={
              market.phase === 'failed' ? 'dia-plugin-card__failed' : 'dia-plugin-card__market-status'
            }
            role="status"
          >
            {marketStatus(props, market)}
            {market.progressDetail === null ? null : ` · ${market.progressDetail}`}
          </p>
          {market.phase === 'unavailable' ? (
            <p className="dia-plugin-card__hint">{props.t('settings.marketFallback')}</p>
          ) : null}
          <div className="dia-plugin-card__market-actions">
            {market.phase === 'available' ? (
              <Button
                type="button"
                size="sm"
                variant="primary"
                className="dia-plugin-card__save"
                onClick={() => props.installUpdate()}
              >
                {props.t('settings.installUpdate')}
              </Button>
            ) : null}
            {market.forceAllowed ? (
              <Button
                type="button"
                size="sm"
                variant="primary"
                className="dia-plugin-card__save"
                onClick={() => props.installUpdate(true)}
              >
                {props.t('settings.forceUpdate')}
              </Button>
            ) : null}
            {market.rollbackAvailable ? (
              <Button
                type="button"
                size="sm"
                variant="outline"
                className="dia-plugin-card__discard"
                onClick={props.rollbackUpdate}
              >
                {props.t('settings.rollback')}
              </Button>
            ) : null}
            {market.refreshRequired ? (
              <Button
                type="button"
                size="sm"
                variant="primary"
                className="dia-plugin-card__save"
                onClick={props.refreshClient}
              >
                {props.t('settings.refresh')}
              </Button>
            ) : null}
            {market.restartRequired && market.restartSupported ? (
              <Button
                type="button"
                size="sm"
                variant="primary"
                className="dia-plugin-card__save"
                onClick={props.restartHost}
              >
                {props.t('settings.restart')}
              </Button>
            ) : null}
            {market.restartRequired && !market.restartSupported ? (
              <span className="dia-plugin-card__hint">{props.t('settings.restartManaged')}</span>
            ) : null}
            {market.phase !== 'updating' &&
            market.phase !== 'rolling-back' &&
            market.phase !== 'restarting' &&
            market.phase !== 'available' ? (
              <Button
                type="button"
                size="sm"
                variant="outline"
                className="dia-plugin-card__discard"
                onClick={props.checkUpdate}
              >
                {props.t(market.phase === 'idle' ? 'settings.checkUpdate' : 'settings.checkAgain')}
              </Button>
            ) : null}
          </div>
        </div>
        <div className="dia-plugin-card__footer">
          {state.failed ? (
            <p className="dia-plugin-card__failed" role="status">
              {props.t('settings.saveFailed')}
            </p>
          ) : null}
          <Button
            type="button"
            size="sm"
            variant="outline"
            className="dia-plugin-card__discard"
            disabled={!state.dirty || state.saving}
            onClick={props.discard}
          >
            {props.t('settings.discard')}
          </Button>
          <Button
            type="button"
            size="sm"
            variant="primary"
            className="dia-plugin-card__save"
            disabled={!state.writable || !state.dirty || state.saving}
            onClick={props.save}
          >
            {props.t(state.saving ? 'settings.saving' : 'settings.save')}
          </Button>
        </div>
      </div>
    </div>
  )
}
