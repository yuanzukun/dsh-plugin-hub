import type { PropsLocale, PropsRuntime, InjectFace, HostObservable } from '@deepseek-ai/dsh-client-ui-slots'
import type { AnnotationEndpoint, AnnotationPresentation, AnnotationView } from './controller.ts'
import type { SelectionCapture } from './selection.ts'
import type { AnnotationId, MessageIdentity, ProcessingMode, SubmissionId } from '../shared/types.ts'

export interface AnnotationInjected {
  readonly hooks: {
    readonly annotations: HostObservable<AnnotationView>
    /** 汇总条紧凑布局开关，Host 接受设置后响应式更新。 */
    readonly compactSummary: HostObservable<boolean>
  }
  /** 注解界面的翻译函数，避免覆盖原消息渲染器自己的 t。 */
  readonly annotationT: PropsLocale<'dshAnnotation'>['t']
  /** Bind the mounted composer to the root notice host for this Session. */
  readonly bindNoticeHost: (anchor: HTMLElement | null) => () => void
  readonly beginSelection: (capture: SelectionCapture) => void
  readonly chooseOverlap: (annotationId?: AnnotationId) => void
  readonly dismissOverlap: () => void
  readonly suspendEditor: () => void
  readonly resumeEditor: (key: string) => void
  readonly discardEditorDraft: (key: string) => void
  /** Explicit selection arms the composer even when automatic attachment is disabled. */
  readonly toggleSelected: (annotationId: AnnotationId) => void
  /** Cancel only the captured batch of composer attachments. */
  readonly detachAnnotations: (annotationIds: readonly AnnotationId[]) => void
  /** Move saved annotations into the durable recycle bin before removing them. */
  readonly trashAnnotations: (annotationIds: readonly AnnotationId[]) => void
  readonly setProcessingMode: (mode: ProcessingMode) => void
  readonly selectRetry: (submissionId: SubmissionId) => void
  readonly openAnnotation: (annotationId: AnnotationId, presentation?: AnnotationPresentation) => void
  readonly updateEditorText: (text: string) => void
  readonly confirmLongSelection: () => void
  readonly saveEditor: () => AnnotationId
  readonly closeEditor: (force?: boolean) => boolean
  readonly deleteDraft: (annotationId: AnnotationId) => void
  readonly undoDelete: () => void
  readonly dismissDeleteUndo: () => void
  readonly setPanelOpen: (open: boolean) => void
  readonly setRecordExpanded: (expanded: boolean) => void
  /** 当前是否需要在新增注解后自动附着。 */
  readonly autoAttachEnabled: () => boolean
  /** 只负责附加；已经附加时不会反向取消。 */
  readonly ensureComposerAttachment: () => boolean
  readonly toggleComposerAttachment: () => boolean
  /** 跟随输入状态修复附着：斜杠命令态放行、离开后重新附着、无可附着时移除令牌。 */
  readonly repairComposerAttachment: () => void
  readonly withdraw: (submissionId: SubmissionId) => Promise<void>
  /** 放弃一条从未入队的失败/待发送记录，注解回到草稿列表。 */
  readonly discardOutbox: (submissionId: SubmissionId) => void
  readonly navigate: (annotationId: AnnotationId) => Promise<boolean>
  readonly annotateMessage: (messageId: MessageIdentity) => boolean
  readonly registerEndpoint: (messageId: MessageIdentity, endpoint: AnnotationEndpoint) => () => void
  readonly updateHighlightRanges: (messageId: MessageIdentity, ranges: readonly Range[]) => void
  readonly activateHighlight: (messageId: MessageIdentity, range: Range | null) => void
  readonly removeHighlights: (messageId: MessageIdentity) => void
  readonly highlightsSupported: () => boolean
}

export type AnnotationBoundProps = InjectFace<AnnotationInjected>
export type AssistantAnnotationProps = PropsRuntime<'conversation.chat.node', 'assistant-step'> &
  PropsLocale<'dshAnnotation'> &
  AnnotationBoundProps
export type InputAnnotationProps = PropsRuntime<'conversation.input.dock'> &
  PropsLocale<'dshAnnotation'> &
  AnnotationBoundProps
export type UserAnnotationProps<Key extends 'user' | 'steering'> = PropsRuntime<
  'conversation.chat.node',
  Key
> &
  PropsLocale<'dshAnnotation'> &
  AnnotationBoundProps
export type AssistantActionAnnotationProps = PropsRuntime<'conversation.chat.assistant-actions'> &
  PropsLocale<'dshAnnotation'> &
  AnnotationBoundProps
export type CommandAnnotationProps = PropsRuntime<'conversation.chat.commandview'> & AnnotationBoundProps
