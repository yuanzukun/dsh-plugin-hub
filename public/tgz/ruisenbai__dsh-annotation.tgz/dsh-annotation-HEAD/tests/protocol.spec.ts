import { describe, expect, it } from 'vitest'
import { DEFAULT_CONFIG } from '../src/shared/config.ts'
import {
  formatSubmissionMessage,
  parseAnnotationSource,
  parseInlineCommentSource,
  parseProcessingMode,
  parseSubmissionPayload,
  parseSubmittedAnnotation,
  ProtocolError,
  submissionSummary,
  validateSubmissionLimits,
} from '../src/shared/protocol.ts'
import { fixturePayload, fixtureV1Payload } from './fixtures.ts'

describe('annotation wire protocol', () => {
  it('round-trips a valid immutable v2 payload', () => {
    const fixture = fixturePayload()
    const parsed = parseSubmissionPayload(JSON.parse(JSON.stringify(fixture)))
    expect(parsed).toEqual(fixture)
    expect(Object.isFrozen(parsed)).toBe(true)
    expect(Object.isFrozen(parsed.annotations)).toBe(true)
  })

  it.each([
    ['wrong version', { protocolVersion: 3 }],
    ['empty annotations', { annotations: [] }],
    ['wrong delivery', { delivery: 'now' }],
    ['wrong processing mode', { processingMode: 'summarize' }],
    ['wrong source', { source: 'dsh-other' }],
    ['missing source', { source: undefined }],
  ])('rejects %s', (_label, patch) => {
    expect(() => parseSubmissionPayload({ ...fixturePayload(), ...patch })).toThrow(ProtocolError)
  })

  it('reads a pre-rename v1 payload and converts it into the v2 model', () => {
    const parsed = parseSubmissionPayload(fixtureV1Payload())
    expect(parsed).toMatchObject({
      protocolVersion: 2,
      source: 'dsh-annotation',
      submissionId: 'sub-legacy',
      processingMode: 'answer',
      annotations: [{ annotationId: 'ann-legacy-1', annotation: 'Legacy comment.', ordinal: 1 }],
    })
    expect(parsed.annotations[0]).not.toHaveProperty('comment')
  })

  it('defaults a v2 payload without processingMode to answer and accepts every current mode', () => {
    const legacyV2 = { ...fixturePayload() } as Record<string, unknown>
    delete legacyV2.processingMode
    expect(parseSubmissionPayload(legacyV2).processingMode).toBe('answer')
    expect(parseProcessingMode(undefined)).toBe('answer')

    for (const mode of ['answer', 'rewrite', 'modify'] as const) {
      expect(parseProcessingMode(mode)).toBe(mode)
      expect(parseSubmissionPayload(fixturePayload({ processingMode: mode })).processingMode).toBe(mode)
    }
    expect(() => parseProcessingMode(null)).toThrow(ProtocolError)
  })

  it('restores bounded supplemental links without requiring the historical target in this batch', () => {
    const payload = fixturePayload()
    const item = payload.annotations[0]!
    const parsed = parseSubmissionPayload({
      ...payload,
      annotations: [{ ...item, supplementalTo: 'ann-from-history' }],
    })
    expect(parsed.annotations[0]?.supplementalTo).toBe('ann-from-history')
  })

  it.each([
    ['blank', '   '],
    ['too long', 'x'.repeat(257)],
    ['self-referencing', 'ann-test-1'],
  ])('rejects a %s supplemental annotation id', (_label, supplementalTo) => {
    const payload = fixturePayload()
    const item = payload.annotations[0]!
    expect(() =>
      parseSubmissionPayload({
        ...payload,
        annotations: [{ ...item, supplementalTo }],
      }),
    ).toThrow(ProtocolError)
  })

  it('rejects duplicate ids and non-contiguous ordinals', () => {
    const item = fixturePayload().annotations[0]!
    expect(() =>
      parseSubmissionPayload({
        ...fixturePayload(),
        annotations: [item, { ...item, ordinal: 2 }],
      }),
    ).toThrow('unique')
    expect(() =>
      parseSubmissionPayload({ ...fixturePayload(), annotations: [{ ...item, ordinal: 2 }] }),
    ).toThrow('contiguous')
  })

  it('rejects selectors whose offsets, context, or table order are inconsistent', () => {
    const item = fixturePayload().annotations[0]!
    expect(() =>
      parseSubmissionPayload({
        ...fixturePayload(),
        annotations: [{ ...item, quote: { ...item.quote, end: item.quote.end + 1 } }],
      }),
    ).toThrow('span exact text')
    expect(() =>
      parseSubmissionPayload({
        ...fixturePayload(),
        annotations: [{ ...item, quote: { ...item.quote, prefix: 'x'.repeat(33) } }],
      }),
    ).toThrow('32 characters')
    expect(() =>
      parseSubmissionPayload({
        ...fixturePayload(),
        annotations: [
          {
            ...item,
            structure: { kind: 'table', startRow: 2, startColumn: 1, endRow: 1, endColumn: 3 },
          },
        ],
      }),
    ).toThrow('precedes')
  })

  it('enforces complete decoded byte and item limits', () => {
    const payload = fixturePayload()
    expect(() => validateSubmissionLimits(payload, { ...DEFAULT_CONFIG, maxPayloadBytes: 3 }, 4)).toThrow(
      '4 bytes',
    )
    expect(() =>
      validateSubmissionLimits(payload, { ...DEFAULT_CONFIG, maxAnnotationsPerSubmission: 0 }, 1),
    ).toThrow('maximum is 0')
    expect(() => validateSubmissionLimits(payload, DEFAULT_CONFIG, 100)).not.toThrow()
  })

  it('formats model-visible text demanding ordered per-annotation replies with markers', () => {
    const text = formatSubmissionMessage(fixturePayload())
    expect(text).toContain('selected source')
    expect(text).toContain('Explain this claim.')
    expect(text).toContain('ann-test-1')
    expect(text).toContain('注解 1')
    expect(text).toContain('按编号逐条回答，不合并')
    expect(text).toContain('\n注解 1\n')
    expect(text).not.toContain('注解 1 (ann-test-1)')
    expect(text).toContain(
      '<!-- dsh-annotation-reply:{"submissionId":"sub-test","annotationId":"ann-test-1","ordinal":1} -->',
    )
    expect(text).toContain(
      '<!-- dsh-annotation:{"submissionId":"sub-test","processed":["annotation-id"]} -->',
    )
    expect(text).not.toContain('dsh-inline-comments:')
  })

  it('uses the Chinese protocol template when the payload locale is zh', () => {
    const text = formatSubmissionMessage(fixturePayload({ protocolLocale: 'zh' }))
    expect(text).toContain('[DSH 注解提交]')
    expect(text).toContain('「注解 N：」')
    expect(text).not.toContain('Annotation 1:')
  })

  it('uses the English protocol template when the payload locale is en', () => {
    const text = formatSubmissionMessage(fixturePayload({ protocolLocale: 'en' }))
    expect(text).toContain('[DSH annotation submission]')
    expect(text).toContain('Answer annotations in order without merging them')
    expect(text).toContain('Start each section with "Annotation N:"')
    expect(text).not.toContain('"Highlight only"')
    expect(text).not.toContain('注解')
  })

  it.each([
    ['zh', 'answer'],
    ['zh', 'rewrite'],
    ['zh', 'modify'],
    ['en', 'answer'],
    ['en', 'rewrite'],
    ['en', 'modify'],
  ] as const)('handles highlight-only items in %s %s mode', (protocolLocale, processingMode) => {
    const payload = fixturePayload({ protocolLocale, processingMode })
    const highlight = {
      ...payload.annotations[0]!,
      annotationId: 'ann-highlight' as (typeof payload.annotations)[number]['annotationId'],
      ordinal: 2,
      annotation: '',
      kind: 'highlight-only' as const,
    }
    const text = formatSubmissionMessage({ ...payload, annotations: [...payload.annotations, highlight] })
    expect(text).toContain(protocolLocale === 'zh' ? '（仅标记原文）' : '(Highlight only)')
    const instruction =
      protocolLocale === 'zh'
        ? '「仅标记原文」没有额外意见，仍须按交付方式处理原文。'
        : '"Highlight only" has no annotation text; still handle its quote in the current delivery mode.'
    expect(text.split(instruction)).toHaveLength(2)
    expect(text).toContain('"annotationId":"ann-highlight","ordinal":2')
    expect(text).toContain(highlight.quote.exact)
  })

  it.each([
    ['zh', ''],
    ['zh', ' \n '],
    ['en', ''],
    ['en', ' \n '],
  ] as const)('omits a blank overall requirement in %s: %j', (protocolLocale, overallRequirement) => {
    const text = formatSubmissionMessage(fixturePayload({ protocolLocale, overallRequirement }))
    expect(text).not.toContain(protocolLocale === 'zh' ? '总体要求' : 'Overall requirement')
    expect(text).not.toContain(protocolLocale === 'zh' ? '请求澄清' : 'ask for clarification')
    expect(text).toContain(protocolLocale === 'zh' ? '交付方式：逐条回答' : 'Delivery mode: answer')
  })

  it.each([
    ['zh', '', ''],
    ['zh', ' \n', ''],
    ['zh', '', '\n '],
    ['zh', ' \n', '\n '],
    ['en', '', ''],
    ['en', ' \n', ''],
    ['en', '', '\n '],
    ['en', ' \n', '\n '],
  ] as const)('preserves nonempty %s quote context %j / %j', (protocolLocale, prefix, suffix) => {
    const payload = fixturePayload({ protocolLocale })
    const item = payload.annotations[0]!
    const text = formatSubmissionMessage({
      ...payload,
      annotations: [{ ...item, quote: { ...item.quote, prefix, suffix } }],
    })
    const contexts =
      protocolLocale === 'zh'
        ? ([
            ['原文前文：', prefix],
            ['原文后文：', suffix],
          ] as const)
        : ([
            ['Quote prefix:', prefix],
            ['Quote suffix:', suffix],
          ] as const)
    for (const [label, value] of contexts) {
      if (value.length === 0) expect(text).not.toContain(label)
      else expect(text).toContain(`${label}\n${value}\n`)
    }
    expect(text).toContain(item.quote.exact)
    expect(text).toContain(item.annotation)
  })

  it('infers the annotation kind from content when kind is missing or inconsistent', () => {
    const item = fixturePayload().annotations[0]!
    expect(parseSubmittedAnnotation({ ...item, kind: undefined }, 0).kind).toBe('note')
    expect(parseSubmittedAnnotation({ ...item, annotation: '', kind: undefined }, 0).kind).toBe(
      'highlight-only',
    )
    // 显式 kind 与内容自相矛盾时按内容修正。
    expect(parseSubmittedAnnotation({ ...item, annotation: '', kind: 'note' }, 0).kind).toBe('highlight-only')
    expect(parseSubmittedAnnotation({ ...item, kind: 'highlight-only' }, 0).kind).toBe('highlight-only')
  })

  it('defaults missing protocolLocale to the legacy English protocol', () => {
    const parsed = parseSubmissionPayload(fixtureV1Payload())
    expect(parsed.protocolLocale).toBe('en')
    expect(parsed.annotations[0]).toMatchObject({ kind: 'note', annotation: 'Legacy comment.' })
  })

  it('reads current and historical provenance sources and builds summaries', () => {
    const payload = fixturePayload()
    const legacyV2 = { ...payload } as Record<string, unknown>
    delete legacyV2.processingMode
    const supplementalPayload = {
      ...payload,
      annotations: [{ ...payload.annotations[0]!, supplementalTo: 'ann-from-history' }],
    }

    expect(parseAnnotationSource({ kind: 'user', annotationSubmission: payload })).toEqual(payload)
    expect(
      parseAnnotationSource({ kind: 'user', annotationSubmission: supplementalPayload })?.annotations[0]
        ?.supplementalTo,
    ).toBe('ann-from-history')
    expect(parseAnnotationSource({ kind: 'user', inlineComments: legacyV2 })).toMatchObject({
      submissionId: payload.submissionId,
      processingMode: 'answer',
    })
    expect(parseAnnotationSource({ kind: 'user', inlineAnnotations: fixtureV1Payload() })).toMatchObject({
      submissionId: 'sub-legacy',
      processingMode: 'answer',
    })
    expect(parseAnnotationSource({ kind: 'user' })).toBeNull()
    expect(parseAnnotationSource({ kind: 'plugin', annotationSubmission: payload })).toBeNull()
    expect(parseInlineCommentSource({ kind: 'user', annotationSubmission: payload })).toEqual(payload)
    expect(submissionSummary(payload, 'zh')).toContain('1 条')
    expect(submissionSummary(payload, 'en')).toContain('1 annotation')
  })
})
