// Regression test for the host half's deriveMessages projection.
//
// Drives the REAL host.v8.js (the live entry declared by package.json "main")
// through its HTTP handlers with a fake session, and asserts the derived model
// history. Guards the class of bug that broke a whole session:
// `message.content.some is not a function` — an assistant edit or retraction
// used to replace `content` (a block array) with a bare string.
//
// Run: node test/host.test.mjs   (no dependencies)

import { apply } from '../host.v8.js'

const routes = new Map()
const events = []

function pushEvent(event) {
  event.seq = events.length
  events.push(event)
  return event
}

pushEvent({ type: 'system/message', data: { message: { role: 'system', content: [{ type: 'text', text: 'sys' }] } } })
pushEvent({ type: 'user/message', data: { role: 'user', content: [{ type: 'text', text: 'hello' }], id: 'u1' } })
pushEvent({
  type: 'assistant/message',
  data: { turn: 1, step: 1, message: { role: 'assistant', content: [{ type: 'text', text: 'ORIGINAL REPLY' }], id: 'a1' } },
})
pushEvent({ type: 'turn/end', data: { turn: 1, reason: { kind: 'completed' } } })

const session = {
  id: 'sess-1',
  events,
  seq: events.length,
  // The live turn boundary. rebuild() drops a pending rewind whose mark landed
  // before it, so the fake session needs one or every pending looks stale.
  firstLiveSeq: 0,
  surface: { nodes: [0, 1, 2], contentGeneration: 1 },
  snapshotEvents() { return events },
  eventAt(seq) { return events[seq] },
  append(type, data) {
    const rec = { type, data }
    rec.seq = events.length
    events.push(rec)
    this.seq = events.length
    return rec
  },
  deriveEventMessage(event) {
    if (event.type === 'user/message') return event.data
    if (event.type === 'assistant/message') return event.data.message
    if (event.type === 'tool/result') return { role: 'tool', content: event.data?.content ?? [] }
    return null
  },
  deriveMessages() {
    return this.surface.nodes.map((seq) => this.deriveEventMessage(events[seq])).filter(Boolean)
  },
}

const handlers = new Map()
const followups = []
const fakeAgent = {
  id: 'sess-1',
  session,
  status: 'idle',
  followup(message) { followups.push(message) },
  cancel() {},
}
const ctx = {
  get() { return undefined },
  effect(fn) { const d = fn(); return typeof d === 'function' ? d : () => {} },
  on(name, handler) { handlers.set(name, handler) },
  webServer: {
    register(route) { routes.set(route.path, route.handler); return () => routes.delete(route.path) },
  },
  sessions: { get: (id) => (id === 'sess-1' ? session : undefined) },
  agents: { get: (id) => (id === 'sess-1' ? fakeAgent : undefined) },
}

apply(ctx)

function makeReq(method, url, body) {
  const listeners = {}
  const req = {
    method,
    url,
    on(name, cb) { (listeners[name] ??= []).push(cb); return req },
    destroy() {},
  }
  setImmediate(() => {
    if (body !== undefined) {
      const buf = Buffer.from(JSON.stringify(body), 'utf8')
      for (const cb of listeners.data ?? []) cb(buf)
    }
    for (const cb of listeners.end ?? []) cb()
  })
  return req
}

function call(method, path, body, query = '') {
  return new Promise((resolve) => {
    const res = {
      status: 0,
      payload: undefined,
      writeHead(status) { this.status = status },
      end(text) { this.payload = JSON.parse(text); resolve(this) },
    }
    routes.get(path)(makeReq(method, path + query, body), res)
  })
}

function blockText(content) {
  if (typeof content === 'string') throw new Error('REGRESSION: derived content is a bare string')
  return content.filter((c) => c.type === 'text').map((c) => c.text).join('')
}

let failed = 0
function check(label, ok) {
  if (!ok) failed++
  console.log(`  ${ok ? 'ok  ' : 'FAIL'}  ${label}`)
}

console.log('host deriveMessages projection — regression against host.v8.js\n')

// /state must install the projection after a restart, before any edit exists.
const state1 = await call('GET', '/api/time-weaver/state', undefined, '?sessionId=sess-1')
check('/state answers and installs the projection', state1.status === 200 && state1.payload.ok === true)
check('baseline history intact', blockText(session.deriveMessages().at(-1).content) === 'ORIGINAL REPLY')

const editRes = await call('POST', '/api/time-weaver/edit', { sessionId: 'sess-1', seq: 2, content: 'EDITED REPLY' })
check('edit accepted', editRes.status === 200 && editRes.payload.ok === true)

let derived
let error = null
try { derived = session.deriveMessages() } catch (e) { error = e }
check('no crash while deriving after an edit', error === null)
if (derived !== undefined) {
  const last = derived.at(-1)
  check('edited text reaches model history', blockText(last.content) === 'EDITED REPLY')
  check('content stays a block array', Array.isArray(last.content) && typeof last.content[0] === 'object')
}

await call('POST', '/api/time-weaver/edit', { sessionId: 'sess-1', seq: 2, content: 'EDITED AGAIN' })
check('second edit to the same seq invalidates the cache', blockText(session.deriveMessages().at(-1).content) === 'EDITED AGAIN')

const state2 = await call('GET', '/api/time-weaver/state', undefined, '?sessionId=sess-1')
const entry = state2.payload.edits.find((e) => e.seq === 2)
check('/state exposes the pristine originalText', entry?.originalText === 'ORIGINAL REPLY')
check('/state exposes the effective content', entry?.content === 'EDITED AGAIN')

await call('POST', '/api/time-weaver/retract', { sessionId: 'sess-1', seq: 2, placeholder: '[已撤回]' })
check('retraction keeps a block array', blockText(session.deriveMessages().at(-1).content) === '[已撤回]')

const regenRes = await call('POST', '/api/time-weaver/regenerate', { sessionId: 'sess-1', seq: 2 })
check('regenerate drops the reply from context', session.deriveMessages().every((m) => m.role !== 'assistant'))
check('regenerate answers with a started turn', regenRes.payload.ok === true && regenRes.payload.started === true)
check('regenerate wakes the agent exactly once', followups.length === 1)
check('the wake message is a user-role notice', followups[0]?.role === 'user' && followups[0]?.source?.form === 'notice')
check('the wake message carries an id', typeof followups[0]?.id === 'string' && followups[0].id.length > 0)
check('regenerate reports the pristine text', regenRes.payload.originalText === 'ORIGINAL REPLY')
check('regenerate reports the turn', regenRes.payload.turn === 1)

const stateRegen = await call('GET', '/api/time-weaver/state', undefined, '?sessionId=sess-1')
const regenEntry = (stateRegen.payload.regenerates ?? []).find((r) => r && r.seq === 2)
check('/state exposes the regenerate turn anchor', regenEntry?.turn === 1)
check('/state exposes the regenerate pristine text', regenEntry?.originalText === 'ORIGINAL REPLY')

// ---------------------------------------------------------- rewind commit --
// A rewind is marked on the user prompt; the next turn commits a hidden range.
// The range must stop at the tail captured at mark time — the freshly appended
// prompt (and the reply it produces) stay visible.
console.log('\nrewind commit range')
const markRes = await call('POST', '/api/time-weaver/mark', { sessionId: 'sess-1', seq: 1 })
check('re-mark accepted', markRes.status === 200 && markRes.payload.ok === true)
const tailAtIndex = markRes.payload.markSeq - 1
pushEvent({ type: 'user/message', data: { role: 'user', content: [{ type: 'text', text: 'fresh prompt' }], id: 'u2' } })
const freshSeq = session.seq - 1
const preStep = handlers.get('agent/pre-step')
check('pre-step handler registered', typeof preStep === 'function')
await preStep({ agent: { id: 'sess-1', session }, messages: [{ role: 'user' }] }, () => ({ kind: 'continue', messages: [] }))
const state3 = await call('GET', '/api/time-weaver/state', undefined, '?sessionId=sess-1')
const range = state3.payload.ranges.at(-1)
check('committed range ends at the mark-time tail', range?.end === tailAtIndex)
check('the fresh prompt is outside the hidden range', freshSeq > (range?.end ?? -1))
check('committed range starts at the rewound prompt', range?.start === 1)

// ------------------------------------------------- editing a user prompt --
// A sent prompt can be corrected in place: the model must read the new words
// from the next turn on, and any attachment must survive the rewrite.
console.log('\nediting a user prompt')
const userSeq = pushEvent({
  type: 'user/message',
  data: {
    role: 'user',
    id: 'u9',
    content: [
      { type: 'text', text: '原始提问' },
      { type: 'image', attachment: { attachmentId: 'img-1', mediaType: 'image/png' } },
    ],
  },
}).seq
session.seq = events.length
session.surface.nodes.push(userSeq)
session.surface.contentGeneration = 2

const rejectAsst = await call('POST', '/api/time-weaver/edit-user', { sessionId: 'sess-1', seq: 2, content: 'nope' })
check('a reply cannot be edited through the user channel', rejectAsst.status === 400)

const editUserRes = await call('POST', '/api/time-weaver/edit-user', { sessionId: 'sess-1', seq: userSeq, content: '改过的提问' })
check('user edit accepted', editUserRes.status === 200 && editUserRes.payload.ok === true)
check('user edit reports the pristine text', editUserRes.payload.originalText === '原始提问')

const derivedUser = session.deriveMessages().find((m) => m.role === 'user' && Array.isArray(m.content) && m.content.some((c) => c.type === 'image'))
check('the edited prompt reaches model history', derivedUser !== undefined && blockText(derivedUser.content) === '改过的提问')
check(
  'the attachment block survives the rewrite',
  derivedUser !== undefined && derivedUser.content.some((c) => c.type === 'image' && c.attachment?.attachmentId === 'img-1'),
)
check('user content stays a block array', Array.isArray(derivedUser?.content))

const stateUser = await call('GET', '/api/time-weaver/state', undefined, '?sessionId=sess-1')
const userEntry = (stateUser.payload.userEdits ?? []).find((e) => e.seq === userSeq)
check('/state exposes the user edit', userEntry?.content === '改过的提问' && userEntry?.originalText === '原始提问')

const msgUser = await call('GET', '/api/time-weaver/message', undefined, '?sessionId=sess-1&seq=' + userSeq)
check('/message marks the role as user', msgUser.payload.role === 'user')
check('/message returns the edited text', msgUser.payload.text === '改过的提问')
check('/message reports it as edited', msgUser.payload.isEdited === true)

// Edit-and-re-ask: the corrected words become the next prompt while the
// original prompt and its reply fall into a rewind range.
console.log('\nedit and re-ask')
const beforeFollowups = followups.length
const resendRes = await call('POST', '/api/time-weaver/edit-user', {
  sessionId: 'sess-1', seq: userSeq, content: '再问一次', resend: true,
})
check('resend accepted and restarted', resendRes.payload.ok === true && resendRes.payload.restarted === true)
check('resend wakes the agent once', followups.length === beforeFollowups + 1)
const reask = followups.at(-1)
check('the re-ask carries the edited words', reask !== undefined && blockText(reask.content) === '再问一次')
check('the re-ask is a real user message, not a notice', reask !== undefined && reask.source === undefined)
const statePending = await call('GET', '/api/time-weaver/state', undefined, '?sessionId=sess-1')
check('a rewind range is pending for the re-ask', statePending.payload.pending?.targetSeq === userSeq)

// ------------------------------------- regenerate must keep tool pairing --
// Dropping the whole assistant message leaves its tool/result events orphaned.
// Strict Anthropic-compatible endpoints answer that with 400 (2013), and the
// marker is replayed from the journal, so the session never recovers.
console.log('\nregenerate keeps tool calls paired with their results')
const toolAsstSeq = pushEvent({
  type: 'assistant/message',
  data: {
    turn: 9,
    step: 1,
    message: {
      role: 'assistant',
      id: 'a9',
      content: [
        { type: 'text', text: '我来查一下这个文件' },
        { type: 'tool_use', id: 'call_1', name: 'read', input: { path: 'a.txt' } },
        { type: 'tool_use', id: 'call_2', name: 'read', input: { path: 'b.txt' } },
      ],
    },
  },
}).seq
session.seq = events.length
session.surface.nodes.push(toolAsstSeq)

const toolResSeq = pushEvent({
  type: 'tool/result',
  data: {
    turn: 9,
    content: [
      { type: 'tool_result', tool_use_id: 'call_1', content: 'A' },
      { type: 'tool_result', tool_use_id: 'call_2', content: 'B' },
    ],
  },
}).seq
session.seq = events.length
session.surface.nodes.push(toolResSeq)
session.surface.contentGeneration = 3

const regenToolRes = await call('POST', '/api/time-weaver/regenerate', { sessionId: 'sess-1', seq: toolAsstSeq })
check('regenerate accepted for a tool-carrying reply', regenToolRes.payload.ok === true)

const projected = session.deriveMessages()
const callIds = []
const resultIds = []
for (const m of projected) {
  const blocks = Array.isArray(m.content) ? m.content : []
  for (const b of blocks) {
    if (b.type === 'tool_use') callIds.push(b.id)
    if (b.type === 'tool_result') resultIds.push(b.tool_use_id)
  }
}
check('the tool calls survive the regenerate', callIds.includes('call_1') && callIds.includes('call_2'))
check('every tool result still has its call', resultIds.every((id) => callIds.includes(id)))
check('both tool results are kept', String(resultIds.length), '2')
check(
  'the regenerated prose is gone from context',
  projected.every((m) => !blockText(m.content).includes('我来查一下这个文件')),
)

// A reply that carried no tool call still disappears entirely, as before.
const plainRegenSeq = pushEvent({
  type: 'assistant/message',
  data: { turn: 10, step: 1, message: { role: 'assistant', id: 'a10', content: [{ type: 'text', text: 'PLAIN REPLY' }] } },
}).seq
session.seq = events.length
session.surface.nodes.push(plainRegenSeq)
session.surface.contentGeneration = 4
await call('POST', '/api/time-weaver/regenerate', { sessionId: 'sess-1', seq: plainRegenSeq })
check(
  'a text-only reply is still dropped whole',
  session.deriveMessages().every((m) => !blockText(m.content).includes('PLAIN REPLY')),
)

console.log(failed === 0 ? '\nall checks passed' : `\n${failed} check(s) FAILED`)
process.exit(failed === 0 ? 0 : 1)
