/**
 * The DeepSeek Harness ACP bridge — an editor-grade Agent Client Protocol
 * server over JSON-RPC stdio, mounted as a cordis plugin inside a booted
 * harness composition.
 *
 * Where the in-repo `@deepseek-ai/dsh-acp` bridge is automation-only
 * (committed text, nothing else), this bridge maps the full session-event
 * stream onto the ACP vocabulary:
 *
 * - streamed assistant text and reasoning (`agent_message_chunk` /
 *   `agent_thought_chunk`), with assembled-message fallback
 * - tool calls with kinds, titles, file locations, raw I/O, and fs diffs
 * - `todo_write` plans, token usage, session titles
 * - real cancellation (`agent.cancel`), permission requests, sandbox-mode
 *   session modes, model switching via session config options
 * - `session/resume` without transcript replay, `session/load` with full
 *   history replay from JSONL persistence, `session/list` from the same store
 * - `session/fork` (`unstable_forkSession`): a new session with the source
 *   log, or an inclusive cut at one persisted assistant message
 */

import { randomUUID } from "node:crypto";
import { AsyncLocalStorage } from "node:async_hooks";
import { isAbsolute } from "node:path";
import { Readable, Writable } from "node:stream";
import {
    AgentSideConnection,
    ndJsonStream,
    PROTOCOL_VERSION,
    RequestError,
    type Agent as AcpAgent,
    type AuthenticateRequest,
    type AuthMethod,
    type CancelNotification,
    type CloseSessionRequest,
    type ForkSessionRequest,
    type ForkSessionResponse,
    type InitializeRequest,
    type InitializeResponse,
    type ListSessionsRequest,
    type ListSessionsResponse,
    type LoadSessionRequest,
    type LoadSessionResponse,
    type LogoutRequest,
    type NewSessionRequest,
    type NewSessionResponse,
    type PromptRequest,
    type PromptResponse,
    type ResumeSessionRequest,
    type ResumeSessionResponse,
    type SessionConfigOption,
    type SessionInfo,
    type SessionModeState,
    type SetSessionConfigOptionRequest,
    type SetSessionConfigOptionResponse,
    type SetSessionModeRequest,
    type SetSessionModeResponse,
    type StopReason,
    type Stream,
} from "@agentclientprotocol/sdk";
import { z } from "zod";
import type { Context } from "@deepseek-ai/cordis";
import { credentialRef } from "@deepseek-ai/dsh-credentials";
import type { Agent } from "@deepseek-ai/dsh-agent";
import { ReasoningEffortId, type createUserMessage, type errorChain } from "@deepseek-ai/dsh-llm";
import { buildForkSeed, SessionLogOffset, SessionSeq, type SessionEvent, type SessionId } from "@deepseek-ai/dsh-session";
import type { foldSessionTitle } from "@deepseek-ai/dsh-session-title";
import type { setSandboxMode } from "@deepseek-ai/dsh-sandbox-policy";
import type { SandboxMode } from "@deepseek-ai/dsh-sandbox";
// Side-effect type imports: declaration-merge the approval waterfall and agent events.
import type {} from "@deepseek-ai/dsh-user-approval";
import type {} from "@deepseek-ai/dsh-session-persistence";
import type {} from "@deepseek-ai/dsh-commands";
import type {} from "@deepseek-ai/dsh-skill";
import type {} from "@deepseek-ai/dsh-agent-default-model";
import type {} from "@deepseek-ai/dsh-permission-presets";
import type {} from "@deepseek-ai/dsh-agent-preset-registry";
import type {} from "@deepseek-ai/dsh-tools";
import type { SubagentRunEndInfo, SubagentRunInfo } from "@deepseek-ai/dsh-subagent";

import { VERSION } from "../version.ts";
import {
    advertisedAuthMethods,
    apiKeyFromAuthenticate,
    clientSupportsUrlElicitation,
    credentialBaseUrlName,
    credentialEnvNames,
    gatewayFromAuthenticate,
    isApiKeyAuthMethod,
    isBrowserAuthMethod,
    isGatewayAuthMethod,
    isTerminalAuthMethod,
    looksLikeAuthFailure,
    primaryCredentialName,
    providerFromAuthMethodId,
    shouldOfferLocalAuthPage,
    type ClientAuthCapabilities,
    type ProviderRoute,
} from "../auth.ts";
import { openLocalAuthPage, startLocalAuthPage } from "../auth-page.ts";
import { AuthLoginCancelled, runBrowserLogin } from "./auth-flow.ts";
import { RequestIdTracker, tapRequestIds } from "./request-ids.ts";
import { logDebug, logWarn } from "../log.ts";
import {
    acpInclusiveForkCapabilityMeta,
    inclusiveHistoryPrefix,
    locateForkPoint,
    parseForkRequest,
    type ForkLogEvent,
    type JetbrainsAirForkRequest,
} from "./fork.ts";
import { buildReplay, buildResumeMetadata } from "./history.ts";
import { LatestPublication } from "./latest-publication.ts";
import {
    interactionModeFromClientMeta,
    type AcpInteractionMode,
    withInteractionMode,
} from "./interaction-mode.ts";
import {
    attachmentIngestOf,
    convertPrompt,
    deliverPrompt,
    PromptImageError,
    UnsupportedPromptContentError,
} from "./prompt.ts";
import { SessionProjection, turnEndToStopReason, type HarnessEvent, type SessionUpdate } from "./translate.ts";
import { advertisesCordis, CORDIS_CAPABILITY } from "./cordis-protocol.ts";
import { AcpRpc, muxAcpStream } from "./rpc.ts";
import type { TuiClientAdvertisement } from "./tui-client.ts";
import * as tuiClientPlugin from "./tui-client-plugin.ts";
import * as userQuestionsPlugin from "./user-questions-plugin.ts";
import { substituteUnavailableModel } from "./model-catalog.ts";
import { presetDisplayName, type PresetRow } from "./presets.ts";
export {
    answerFromElicitation,
    askUserQuestionsOverAcp,
    createElicitation,
    installAcpUserQuestionProvider,
    questionsToElicitation,
} from "./user-questions.ts";

export const name = "acp-bridge";
// dsh 0.1.7 keeps this settings section but no longer exports its namespace.
const PERMISSION_SETTINGS_NAMESPACE = "permission";
/** Wait for the dsh-base services this bridge captures during apply. */
export const inject = ["agents", "credentials", "llm", "agentDefaultModel", "sessionPersistence", "approval", "permissionPresets", "commands", "agentPresets", "skills", "subagents", "userQuestions"];

/** Host functions the bridge needs beyond the plugin tree (see loadKit). */
export interface BridgeHarness {
    createUserMessage: typeof createUserMessage;
    errorChain: typeof errorChain;
    sessionId: typeof SessionId;
    foldSessionTitle: typeof foldSessionTitle;
    setSandboxMode: typeof setSandboxMode;
    sandboxModes: readonly SandboxMode[];
    /**
     * `installModelSelection` from `@deepseek-ai/dsh-agent` (optional seam):
     * couples one mutable selection to the agent's prompt assembly so
     * provider/model/reasoning-effort switches apply on the next step without
     * recreating the agent. Older hosts may not export it; the bridge then
     * hides the effort option and keeps resume-based model switching only.
     */
    installModelSelection?: (agentCtx: unknown, selection: ModelSelectionRef) => () => void;
    /**
     * The `@deepseek-ai/dsh-mcp-client` plugin module (optional seam). One
     * mounted instance connects to one MCP server and registers its tools on
     * `ctx.tools` as `mcp__<serverName>__<rawName>`; disposal disconnects and
     * unregisters. Absent on installations that predate the plugin.
     */
    mcpClient?: { apply: (ctx: never, config: never) => void };
}

function readSessionEvents(session: { snapshotEvents?: () => readonly unknown[]; events?: readonly unknown[] }): readonly unknown[] {
    return session.snapshotEvents?.() ?? session.events ?? [];
}

/** Metadata returned directly by rc stores and wrapped in alpha snapshots. */
interface StoredHeader {
    id: SessionId;
    cwd?: string;
    createdAt?: number;
    /**
     * Coarse classification written by DSH when the session is a subagent
     * child. The Web sidebar hides rows carrying this value.
     */
    origin?: string;
}

/** A persisted subagent child is not an ACP-visible session. */
function isSubagentHeader(header: { origin?: string } | undefined): boolean {
    return header?.origin === "subagent";
}

/** Read-only title lookup; alpha handles must close even if reading fails. */
async function readStoredEvents(persistence: unknown, id: SessionId): Promise<readonly SessionEvent[]> {
    const store = persistence as {
        open?: (id: SessionId, access: "read") => Promise<{
            read(): Promise<{ events: readonly SessionEvent[] }>;
            close(): Promise<void>;
        }>;
        inspect: (id: SessionId) => Promise<{ events: readonly SessionEvent[] }>;
    };
    if (typeof store.open !== "function") return (await store.inspect(id)).events;
    const handle = await store.open(id, "read");
    try {
        return (await handle.read()).events;
    } finally {
        await handle.close();
    }
}

export interface AcpBridgeConfig {
    /** Provider route for ACP-created agents; omitted = the composition's default. */
    provider?: string;
    /** Default model for ACP-created agents; omitted = the composition's default. */
    model?: string;
    /** Selectable model candidates surfaced as a session config option. */
    models?: string[];
    /** Optional per-request output-token cap. */
    maxTokens?: number;
    /** Initial sandbox mode advertised as the current ACP session mode. */
    permissionMode?: SandboxMode;
    /** Runtime-only transport override; production uses stdio. */
    stream?: Stream;
    /**
     * Environment for the browser-login gate (`shouldOfferLocalAuthPage`) and
     * auth-method advertisement; tests substitute a production-looking env.
     */
    env?: NodeJS.ProcessEnv;
    /**
     * Host functions resolved from the DeepSeek Harness installation. The
     * standalone CLI injects these; bundle/profile mounts omit them and the
     * bridge imports its own copies (src/bridge/self-harness.ts).
     */
    harness?: BridgeHarness;
}

interface Inflight {
    resolve: (reason: StopReason) => void;
    reject: (error: Error) => void;
    messageId: string;
    turn: number | undefined;
}

/** One live model selection: provider route, model id, optional adapter-owned effort. */
export interface ModelSelectionValue {
    provider: string;
    model: string;
    reasoningEffort?: string;
}

/** Mutable selection snapshotted by prompt assembly (dsh-agent model-selection seam). */
export interface ModelSelectionRef {
    current: ModelSelectionValue | undefined;
    assembled: ModelSelectionValue | undefined;
}

type ApprovalPolicy = "ask" | "never";

interface SessionRecord {
    agent: Agent;
    dispose: () => Promise<void>;
    projection: SessionProjection;
    modeId: SandboxMode;
    /** Selected model; undefined = the composition's default route. */
    model: string | undefined;
    /** Selected provider route; undefined = the configured default. */
    provider?: string;
    /** User-picked reasoning effort for this session; undefined = adapter/default behavior. */
    effort?: string;
    /** Current permission policy: "ask" prompts, "never" auto-approves. */
    approvals: ApprovalPolicy;
    /** Installed model-selection ref (lazy; created on the first effort/model pick). */
    selection?: ModelSelectionRef;
    /** Agent preset joined at creation; undefined = deployment without a roster. */
    preset?: string;
    cancelled: boolean;
    inflight: Inflight | undefined;
    /** Serializes agent rebuilds requested concurrently by ACP clients. */
    mutationTail: Promise<void>;
}

// Extension requests bypass the SDK's core prompt schema validation.
const steeringRequestSchema = z.object({
    sessionId: z.string().min(1),
    prompt: z.array(z.discriminatedUnion("type", [
        z.object({ type: z.literal("text"), text: z.string() }),
        z.object({ type: z.literal("image"), data: z.string(), mimeType: z.string(), uri: z.string().nullable().default(null) }),
        z.object({ type: z.literal("resource_link"), name: z.string(), uri: z.string() }),
        z.object({ type: z.literal("resource"), resource: z.object({ uri: z.string(), text: z.string() }) }),
    ])).min(1).refine((blocks) => blocks.some((block) => block.type !== "text" || block.text.length > 0)),
    _meta: z.object({
        steering: z.object({ idleBehavior: z.literal("promptRequired").optional() }).optional(),
    }).optional(),
});

function invalidParams(detail: string): RequestError {
    // Detail travels in the wire error message (second arg); the first is data.
    return RequestError.invalidParams(undefined, detail);
}

function internalError(detail: string): RequestError {
    return RequestError.internalError(undefined, detail);
}

/**
 * Native auth slash commands are never advertised or delivered over ACP (the
 * claude-agent-acp `UNSUPPORTED_COMMANDS` contract): the client owns the
 * login surface through the advertised auth methods, and a typed `/login` or
 * `/logout` ends the turn with auth_required so it can show its auth UI — it
 * must never reach the model or change credentials.
 */
const NATIVE_AUTH_COMMANDS = new Set(["login", "logout"]);

/** Per-provider entry pushed in `_auth/status_update`. */
interface AuthStatusProvider {
    providerId: string;
    name?: string;
    /** How the credential is supplied: stored key, gateway key+URL, or ambient env. */
    kind: "api_key" | "gateway" | "environment" | "other";
    /** The credential-store name backing the credential (never its value). */
    label: string;
}

/** `_auth/status_update` payload: which providers are usable, via which method. */
interface AuthStatus {
    kind: "none" | "authenticated";
    label: string;
    providers: AuthStatusProvider[];
}

/** Runtime identity provided by the standalone launcher; absent in profile mounts. */
export function dshAcpRuntimeOf(
    host: unknown,
): { base: string; version: string | undefined; source: string } | undefined {
    if (typeof host !== "object" || host === null) return undefined;
    const record = host as { base?: unknown; version?: unknown; source?: unknown };
    if (typeof record.base !== "string" || typeof record.source !== "string") return undefined;
    return {
        base: record.base,
        version: typeof record.version === "string" ? record.version : undefined,
        source: record.source,
    };
}

const MODE_LABELS: Record<SandboxMode, { name: string; description: string }> = {
    "read-only": { name: "Read-only", description: "Bash and file mutations are denied by the sandbox" },
    "workspace-write": {
        name: "Workspace write",
        description: "Writes are confined to the session workspace; wider access asks for permission",
    },
    "danger-full-access": {
        name: "Full access",
        description: "No sandbox confinement and no permission prompts",
    },
};

/**
 * Mount the ACP bridge.
 *
 * @param ctx - cordis context carrying the injected dsh-base services.
 * @param config - provider/model selection and optional test transport.
 */
export async function apply(ctx: Context, config: AcpBridgeConfig = {}): Promise<void> {
    // Capture injected services during apply; handlers run outside the scope.
    const agents = ctx.agents;
    const credentials = ctx.credentials;
    const llm = ctx.llm;
    const agentDefaultModel = ctx.agentDefaultModel;
    const sessionPersistence = ctx.sessionPersistence;
    const approval = ctx.approval;
    const permissionPresets = ctx.permissionPresets;
    const commandRuntime = ctx.commands;
    const agentPresets = ctx.agentPresets;
    const skillRegistry = ctx.skills;
    const subagents = ctx.subagents;
    const harness = config.harness ?? (await import("./self-harness.ts")).selfHarness();
    const { createUserMessage, errorChain, sessionId: SessionId, foldSessionTitle, setSandboxMode } = harness;
    const SANDBOX_MODES = harness.sandboxModes;
    const bridgeEnv = config.env ?? process.env;
    const sessions = new Map<string, SessionRecord>();
    const commandPublications = new LatestPublication();
    interface LiveSubagent {
        rootSessionId: string;
        childSessionId: string;
        runId: string;
        provider: string;
        toolCallId: string;
        projection: SessionProjection;
    }
    const subagentByChild = new Map<string, LiveSubagent>();
    const subagentByRun = new Map<string, LiveSubagent>();
    const watchedSubagentParents = new WeakSet<object>();
    let closed = false;
    let conn: AgentSideConnection;
    /** Whether the client renders `_meta.terminal_output` display terminals. */
    let clientTerminalOutput = false;
    /** Whether the client wants nested child text/thought/tool updates. */
    let clientSubagentTranscript = false;
    /** Whether the client can render standard ACP form elicitation. */
    let clientElicitationForm = false;
    /** Explicit interaction semantics negotiated from ACP client `_meta`. */
    let clientInteractionMode: AcpInteractionMode | undefined;
    const tuiClient: TuiClientAdvertisement = { advertised: false };
    /** Client capabilities as of initialize; drives auth-method advertisement. */
    let clientAuthCapabilities: ClientAuthCapabilities | undefined;
    /** Live provider routes as of the latest `llm.listProviders()` success. */
    let latestProviders: ProviderRoute[] = [];
    /** Inbound JSON-RPC ids for request-scoped url elicitation. */
    const requestIds = new RequestIdTracker();
    /** Sequence for url-elicitation ids opened by browser login. */
    let authPageSeq = 0;
    /** Last pushed `_auth/status_update` payload, deduplicated by JSON. */
    let lastAuthStatus: string | undefined;
    const rpc = new AcpRpc();
    const findAgent = (agentId: string): Agent | undefined => {
        const fromRegistry = agents.get(agentId as never);
        if (fromRegistry !== undefined) return fromRegistry;
        for (const record of sessions.values()) {
            if (record.agent.id === agentId) return record.agent;
        }
        return undefined;
    };
    const executeCommand = (
        agent: Agent,
        line: string,
        signal: AbortSignal,
    ): ReturnType<typeof commandRuntime.execute> => {
        const execute = commandRuntime.execute as unknown as (...args: unknown[]) => ReturnType<
            typeof commandRuntime.execute
        >;
        return execute.length >= 4
            ? execute.call(commandRuntime, agent, line, [], signal)
            : execute.call(commandRuntime, agent, line, signal);
    };
    await ctx.plugin(tuiClientPlugin, { rpc, findAgent, advertisement: tuiClient });

    const modelCandidates = (): string[] => {
        const seen = new Set<string>();
        if (config.model !== undefined) seen.add(config.model);
        for (const model of config.models ?? []) if (model.trim().length > 0) seen.add(model.trim());
        return [...seen];
    };

    // ------------------------------------------------------------------ //
    // Model catalog (static config ∪ live adapter directory)              //
    // ------------------------------------------------------------------ //

    /**
     * One selectable model. With a single registered provider values are bare
     * model ids (stable for existing clients); once several providers are
     * registered every value is `provider::model` — which is how third-party
     * providers configured in the dsh Web UI (an `llm-pi-ai:` settings
     * section) become selectable here the moment their routes register.
     * The encoding never depends on the *default* provider: a successful
     * switch rewrites that default, so ids keyed on it went stale (#24).
     */
    interface ModelChoice {
        provider: string | undefined;
        model: string;
        label: string;
    }

    let standaloneDefaultSelection: { provider: string; model: string; reasoningEffort?: string } | undefined;

    /** The composition's default selection, with the standalone save fallback. */
    const defaultSelection = (): { provider?: string; model?: string; reasoningEffort?: string } => {
        if (standaloneDefaultSelection !== undefined) return standaloneDefaultSelection;
        try {
            return agentDefaultModel.currentSelection();
        } catch (error: unknown) {
            logDebug(`agentDefaultModel.currentSelection failed: ${String(error)}`);
            return {};
        }
    };

    /** Match Web: a successful session selection also becomes the live product default. */
    const saveDefaultSelection = async (record: SessionRecord): Promise<void> => {
        const selected = ensureSelection(record)?.current;
        if (selected === undefined) return;
        try {
            await agentDefaultModel.saveSelection({
                provider: selected.provider,
                model: selected.model,
                ...(selected.reasoningEffort === undefined
                    ? {}
                    : { reasoningEffort: ReasoningEffortId(selected.reasoningEffort) }),
            });
            const save = ctx.get("dshAcpSaveModel") as ((selection: {
                provider: string;
                model: string;
                reasoningEffort?: string;
            }) => Promise<void>) | undefined;
            if (save !== undefined && selected.provider !== undefined) {
                const next = {
                    provider: selected.provider,
                    model: selected.model,
                    ...(selected.reasoningEffort === undefined ? {} : { reasoningEffort: selected.reasoningEffort }),
                };
                await save(next);
                standaloneDefaultSelection = next;
            }
        } catch (error: unknown) {
            // The current-session switch remains valid when settings are
            // read-only or no settings provider is mounted.
            logWarn(`model switch applied to the session but was not saved as the default: ${String(error)}`);
        }
    };

    const defaultProvider = (): string | undefined => config.provider ?? defaultSelection().provider;

    const multiProvider = (): boolean => {
        try {
            return llm.listProviders().length > 1;
        } catch {
            return false;
        }
    };

    const encodeChoice = (provider: string | undefined, model: string): string => {
        const resolved = provider ?? defaultProvider();
        return resolved !== undefined && multiProvider() ? `${resolved}::${model}` : model;
    };

    /** Split `provider::model` (or a bare id) without resolving the provider. */
    const splitChoice = (value: string): { provider: string | undefined; model: string } => {
        const i = value.indexOf("::");
        if (i <= 0) return { provider: undefined, model: value };
        return { provider: value.slice(0, i), model: value.slice(i + 2) };
    };

    /**
     * A bare id (older clients, cached lists) names the model on whichever
     * provider serves it: the default provider when it does, else the single
     * provider that does. Only an id no provider serves stays on the default.
     */
    const decodeChoice = (
        value: string,
        catalog: ModelChoice[],
    ): { provider: string | undefined; model: string } => {
        const split = splitChoice(value);
        if (split.provider !== undefined) return split;
        const owners = new Set(
            catalog.filter((entry) => entry.model === split.model && entry.provider !== undefined)
                .map((entry) => entry.provider as string),
        );
        const fallback = defaultProvider();
        if (fallback !== undefined && owners.has(fallback)) return { provider: fallback, model: split.model };
        if (owners.size === 1) return { provider: [...owners][0], model: split.model };
        return { provider: fallback, model: split.model };
    };

    /** Cached adapter directory; invalidated by `llm/adapters-updated`. */
    let liveCatalog: ModelChoice[] | undefined;

    /** Per-route reasoning-effort metadata; invalidated with the catalog. */
    interface EffortCatalog {
        efforts: { id: string; name: string; description?: string }[];
        defaultEffort?: string;
    }
    const effortCache = new Map<string, EffortCatalog | undefined>();

    const discoverModels = async (): Promise<ModelChoice[]> => {
        if (liveCatalog !== undefined) return liveCatalog;
        const found: ModelChoice[] = [];
        try {
            const providers = llm.listProviders();
            const multi = providers.length > 1;
            logDebug(`model discovery: providers ${providers.map((provider) => provider.id).join(", ") || "(none)"}`);
            for (const provider of providers) {
                const models = await llm.listModels(provider.id).catch((error: unknown) => {
                    logDebug(`listModels(${provider.id}) failed: ${String(error)}`);
                    return [];
                });
                logDebug(`model discovery: ${provider.id} lists ${models.length} model(s)`);
                for (const model of models) {
                    found.push({
                        provider: provider.id,
                        model: model.id,
                        label: multi ? `${model.name} (${provider.name})` : model.name,
                    });
                }
            }
        } catch (error: unknown) {
            logDebug(`model discovery failed: ${String(error)}`);
        }
        liveCatalog = found;
        return found;
    };

    /**
     * Persisted and configured ids that a dsh upgrade removed.
     *
     * A listed successor wins, including when the official adapter would still
     * describe the old id and pass it through. An id the adapter refuses and
     * that has no successor falls back to that provider's first live model.
     * An unlisted id the adapter can still describe is left alone.
     */
    const resolvedModels = new Map<string, string>();
    ctx.on("llm/adapters-updated", () => {
        resolvedModels.clear();
    });
    const resolveUsableModel = async (provider: string, model: string): Promise<string> => {
        const key = `${provider}\0${model}`;
        const cached = resolvedModels.get(key);
        if (cached !== undefined) return cached;
        const catalog = await discoverModels();
        let described = catalog.some((entry) => entry.provider === provider && entry.model === model);
        if (!described) {
            try {
                await llm.resolveModelInfo(provider, model);
                described = true;
            } catch (error: unknown) {
                logDebug(`resolveModelInfo(${provider}/${model}) failed: ${String(error)}`);
                described = false;
            }
        }
        const decision = substituteUnavailableModel(provider, model, catalog, described);
        if (decision.replaced && decision.reason !== undefined) logWarn(decision.reason);
        resolvedModels.set(key, decision.model);
        return decision.model;
    };

    const reconcileModel = async (record: SessionRecord): Promise<void> => {
        // The live selection prefers the logged request header over routeOf,
        // so a persisted removed id has to be read from there.
        const selection = ensureSelection(record);
        const selected = selection?.current;
        const route = selected ?? routeOf(record);
        if (route.provider === undefined || route.model === undefined) return;
        const usable = await resolveUsableModel(route.provider, route.model);
        if (usable === route.model) return;
        record.model = usable;
        if (selection === undefined) return;
        selection.current = {
            provider: route.provider,
            model: usable,
            ...(selected?.reasoningEffort !== undefined ? { reasoningEffort: selected.reasoningEffort } : {}),
        };
    };

    ctx.on("llm/adapters-updated", () => {
        // A settings edit (Web UI Models page) registered or withdrew routes;
        // rebuild on next use so new third-party models appear immediately.
        liveCatalog = undefined;
        effortCache.clear();
    });

    /**
     * The session's effective provider/model route: explicit session picks
     * first, then bridge config, then the composition default, then the last
     * logged request header (accurate once a request ran).
     */
    const routeOf = (record: SessionRecord): { provider?: string; model?: string } => {
        const logged = loggedConfig(record);
        const provider = record.provider ?? defaultProvider() ?? logged?.provider;
        const model =
            record.model ??
            config.model ??
            defaultSelection().model ??
            logged?.model ??
            record.agent.options.model;
        return {
            ...(provider !== undefined ? { provider } : {}),
            ...(model !== undefined ? { model } : {}),
        };
    };

    /** The conversation's last logged call config (provider/model/effort), when any request ran. */
    const loggedConfig = (
        record: SessionRecord,
    ): { provider: string; model: string; reasoningEffort?: string } | undefined => {
        try {
            const header = (
                record.agent.session as unknown as {
                    requestHeader?: () => { config?: { provider: string; model: string; reasoningEffort?: unknown } } | undefined;
                }
            ).requestHeader?.();
            const cfg = header?.config;
            if (cfg === undefined) return undefined;
            return {
                provider: cfg.provider,
                model: cfg.model,
                ...(cfg.reasoningEffort !== undefined ? { reasoningEffort: String(cfg.reasoningEffort) } : {}),
            };
        } catch {
            return undefined;
        }
    };

    /** Selectable reasoning efforts for one exact route, from the owning adapter. */
    const effortCatalog = async (
        provider: string | undefined,
        model: string | undefined,
    ): Promise<EffortCatalog | undefined> => {
        if (provider === undefined || model === undefined) return undefined;
        const key = `${provider}::${model}`;
        if (effortCache.has(key)) return effortCache.get(key);
        let catalog: EffortCatalog | undefined;
        try {
            const reasoning = (await llm.resolveModelInfo(provider, model)).reasoning;
            if (reasoning !== undefined && reasoning.efforts.length > 0) {
                catalog = {
                    efforts: reasoning.efforts.map((effort) => ({
                        id: String(effort.id),
                        name: effort.name,
                        ...(effort.description !== undefined ? { description: effort.description } : {}),
                    })),
                    ...(reasoning.defaultEffort !== undefined
                        ? { defaultEffort: String(reasoning.defaultEffort) }
                        : {}),
                };
            }
        } catch (error: unknown) {
            logDebug(`resolveModelInfo(${key}) failed: ${String(error)}`);
        }
        effortCache.set(key, catalog);
        return catalog;
    };

    /**
     * Install (once per live agent) the mutable selection prompt assembly
     * snapshots. Reads fall back to the logged header, then the session's
     * route composed with the product-default reasoning effort (the Web UI
     * saved selection), so an untouched session runs exactly what the other
     * dsh entry points (web, headless) would run.
     */
    const ensureSelection = (record: SessionRecord): ModelSelectionRef | undefined => {
        const install = harness.installModelSelection;
        if (install === undefined) return undefined;
        if (record.selection !== undefined) return record.selection;
        let picked: ModelSelectionValue | undefined;
        const selection: ModelSelectionRef = {
            get current(): ModelSelectionValue | undefined {
                if (picked !== undefined) return picked;
                const logged = loggedConfig(record);
                if (logged !== undefined) return logged;
                const { provider, model } = routeOf(record);
                if (provider === undefined || model === undefined) return undefined;
                const defaults = defaultSelection();
                // Effort applies when the route is the default selection's own
                // model (or the default names no model): a explicitly pinned
                // different model keeps its adapter-default behavior.
                const effort =
                    defaults.model === undefined || defaults.model === model
                        ? defaults.reasoningEffort
                        : undefined;
                return { provider, model, ...(effort !== undefined ? { reasoningEffort: effort } : {}) };
            },
            set current(next: ModelSelectionValue | undefined) {
                picked = next;
            },
            assembled: undefined,
        };
        try {
            install((record.agent as unknown as { ctx: unknown }).ctx, selection);
        } catch (error: unknown) {
            logWarn(`installModelSelection failed: ${String(error)}`);
            return undefined;
        }
        record.selection = selection;
        return selection;
    };

    /**
     * Resume-based model switching: model options are fixed at agent
     * construction, so swap by resuming the same durable session under new
     * options. A picked reasoning effort survives when the new route offers it.
     */
    const switchModel = async (record: SessionRecord, acpSessionId: string, value: string): Promise<void> => {
        if (record.inflight !== undefined) {
            throw invalidParams("cannot switch models while a prompt is running");
        }
        const discovered = await discoverModels();
        const choice = decodeChoice(value, discovered);
        const known = new Set<string>([
            ...modelCandidates().map((model) => encodeChoice(undefined, model)),
            ...discovered.map((entry) => encodeChoice(entry.provider, entry.model)),
            encodeChoice(record.provider, record.model ?? ""),
        ]);
        if (!known.has(value) && !known.has(encodeChoice(choice.provider, choice.model))) {
            throw invalidParams(`unknown model: ${value}`);
        }
        if (choice.model === record.model && choice.provider === (record.provider ?? defaultProvider())) return;
        const sessionId = record.agent.session.id;
        await record.dispose().catch((error: unknown) => {
            logWarn(`dispose during model switch failed: ${String(error)}`);
        });
        let handle;
        try {
            const presets = presetsService();
            handle = await agents.resume({
                resumeSessionId: sessionId,
                agentOptions: agentOptionsFor(choice.model, choice.provider),
                ...(presetSetup(presets, record.preset) !== undefined
                    ? { setup: presetSetup(presets, record.preset) }
                    : {}),
            } as Parameters<typeof agents.resume>[0]);
        } catch (error: unknown) {
            sessions.delete(acpSessionId);
            throw internalError(`model switch failed: ${errorChain(error)}`);
        }
        record.agent = handle.agent;
        record.dispose = () => handle.dispose();
        record.model = choice.model;
        // Keep the provider explicit even when it is today's default: the
        // default moves with every switch, the session's route must not.
        if (choice.provider !== undefined) {
            record.provider = choice.provider;
        } else {
            delete record.provider;
        }
        // The old selection ref died with the disposed agent's scope; reinstall
        // immediately so the default reasoning effort keeps applying.
        delete record.selection;
        const route = routeOf(record);
        const catalog = await effortCatalog(route.provider, route.model);
        if (record.effort !== undefined && catalog?.efforts.some((effort) => effort.id === record.effort) !== true) {
            // The new route does not offer the picked effort; fall back to
            // its adapter-owned default instead of failing every request.
            delete record.effort;
        }
        const effort = record.effort ?? catalog?.defaultEffort;
        const selection = ensureSelection(record);
        if (selection !== undefined && route.provider !== undefined && route.model !== undefined) {
            selection.current = {
                provider: route.provider,
                model: route.model,
                ...(effort !== undefined ? { reasoningEffort: effort } : {}),
            };
        }
        await saveDefaultSelection(record);
        // Approval policy is agent-scoped state; re-apply it to the new agent.
        setApprovalPolicy(record, record.approvals);
    };

    /** Run one agent-rebuilding mutation after earlier mutations for this session. */
    const mutateSession = (record: SessionRecord, mutation: () => Promise<void>): Promise<void> => {
        const run = record.mutationTail.then(mutation);
        record.mutationTail = run.catch(() => undefined);
        return run;
    };

    /**
     * Live adapter directory. Third-party routes configured in the dsh Web UI
     * (`llm-pi-ai:` settings) show up here the moment they register.
     */
    const listProviderRoutes = async (): Promise<ProviderRoute[]> => {
        try {
            const raw = llm.listProviders();
            if (!Array.isArray(raw)) return [];
            const routes = raw.flatMap((entry) => {
                if (!entry || typeof entry !== "object") return [];
                const id = (entry as { id?: unknown }).id;
                if (typeof id !== "string" || id.length === 0) return [];
                const name = (entry as { name?: unknown }).name;
                return [{ id, ...(typeof name === "string" && name.length > 0 ? { name } : {}) }];
            });
            latestProviders = routes;
            return routes;
        } catch (error: unknown) {
            logDebug(`listProviders failed: ${String(error)}`);
            return [];
        }
    };

    /**
     * auth_required carrying the methods the client can render as a picker —
     * recomputed from the live provider routes and declared client
     * capabilities, so the error always lists what initialize advertised.
     */
    const authError = (detail: string): RequestError =>
        RequestError.authRequired(
            { authMethods: advertisedAuthMethods(latestProviders, clientAuthCapabilities, bridgeEnv) as AuthMethod[] },
            detail,
        );

    const credentialPresent = async (provider?: string): Promise<boolean> => {
        const names = credentialEnvNames(provider).filter((name) => !name.endsWith("_BASE_URL"));
        for (const name of names) {
            try {
                if ((await credentials.resolve(credentialRef(name))) !== undefined) return true;
            } catch (error: unknown) {
                logWarn(`credential lookup failed: ${String(error)}`);
            }
        }
        return false;
    };

    const requireCredential = async (provider?: string): Promise<void> => {
        if (await credentialPresent(provider)) return;
        throw authError(
            "no credential found for this provider: call authenticate with `_meta[\"api-key\"].apiKey` or `_meta.gateway`, pick an advertised auth method, run `dsh-acp login`, or save a key in the dsh Web UI (Settings → Models)",
        );
    };

    const agentOptionsFor = (
        model: string | undefined,
        provider?: string,
    ): { provider?: string; model?: string; maxTokens?: number; interactionMode?: AcpInteractionMode } => {
        const defaults = defaultSelection();
        const resolvedProvider = provider ?? config.provider ?? defaults.provider;
        const resolvedModel = model ?? config.model ?? defaults.model;
        return withInteractionMode({
            ...(resolvedProvider !== undefined ? { provider: resolvedProvider } : {}),
            ...(resolvedModel !== undefined ? { model: resolvedModel } : {}),
            ...(config.maxTokens !== undefined ? { maxTokens: config.maxTokens } : {}),
        }, clientInteractionMode);
    };

    /** Return the bridge-owned record for an agent, rejecting same-id impostors. */
    const ownedRecord = (agent: Agent): SessionRecord | undefined => {
        const record = sessions.get(String(agent.session.id));
        return record?.agent === agent ? record : undefined;
    };

    const requireSession = (sessionId: string): SessionRecord => {
        const record = sessions.get(sessionId);
        if (record === undefined) throw invalidParams(`unknown session: ${sessionId}`);
        return record;
    };

    const storedHeaders = async (): Promise<StoredHeader[]> => {
        const persistence = requirePersistence();
        return (await persistence.list() as unknown as readonly (StoredHeader | { header: StoredHeader })[])
            .map((entry) => "header" in entry ? entry.header : entry);
    };

    /**
     * Subagent children stay in the shared session store so the Web sidebar
     * can hide them, but ACP clients must not list, load, resume, or silently
     * restore them as ordinary sessions.
     */
    const assertAcpVisibleSession = async (sessionId: string): Promise<void> => {
        const header = (await storedHeaders()).find((item) => String(item.id) === sessionId);
        if (isSubagentHeader(header)) throw invalidParams(`session is a subagent child: ${sessionId}`);
    };

    /**
     * The session record, restored from the persisted log when the process
     * no longer holds it live. Zed keeps threads across agent restarts and
     * may prompt an old session without `session/load` first; recovering
     * silently (no history replay — the client already renders it) beats
     * failing the turn with `unknown session`. A persisted subagent child is
     * refused before that restore so it is not promoted into an ACP session.
     */
    const requireOrRestoreSession = async (sessionId: string): Promise<SessionRecord> => {
        const record = sessions.get(sessionId);
        if (record !== undefined) return record;
        await assertAcpVisibleSession(sessionId);
        logWarn(`restoring session ${sessionId} from the persisted log`);
        try {
            return await restoreSession(sessionId, { replay: false });
        } catch (error: unknown) {
            if (error instanceof RequestError && error.code !== -32602) throw error;
            throw invalidParams(`unknown session: ${sessionId} (${errorChain(error)})`);
        }
    };

    /**
     * Resume one persisted session into a live record: acquire ownership,
     * rebuild the agent and replay its history to the client with
     * its stored preset, and fold logged permission facts. Shared by
     * `session/load` (replay: true) and silent restore (replay: false).
     */
    const restoreSession = async (
        sessionId: string,
        options: { replay: boolean; cwd?: string },
    ): Promise<SessionRecord> => {
        requirePersistence();
        const existing = sessions.get(sessionId);
        if (existing !== undefined) {
            // Reloading an open session: drop the live agent first so
            // resume owns the log exclusively.
            sessions.delete(sessionId);
            existing.agent.cancel({ kind: "user" });
            settlePrompt(existing, "cancelled");
            await existing.dispose().catch((error: unknown) => {
                logWarn(`dispose before reload failed: ${String(error)}`);
            });
        }
        let events: readonly SessionEvent[] = [];
        let replay: ReturnType<typeof buildReplay> | undefined;
        let storedHeader: { agentPreset?: string; cwd?: string } | undefined;
        let presetId: string | undefined;
        const presets = presetsService();
        let handle: Awaited<ReturnType<typeof agents.resume>>;
        try {
            // The host acquires write ownership and migrates historical formats
            // before setup. Read the restored session there, never a separate
            // pre-resume snapshot that could be stale or require migration.
            handle = await agents.resume({
                resumeSessionId: SessionId(sessionId),
                agentOptions: agentOptionsFor(config.model),
                setup: async (agentCtx: Context, restoredAgent?: Agent) => {
                    // Alpha passes Agent explicitly; rc hosts expose ctx.agent.
                    const agent = restoredAgent ?? (agentCtx as unknown as { agent: Agent }).agent;
                    storedHeader = agent.session.header;
                    events = readSessionEvents(agent.session) as readonly SessionEvent[];
                    if (options.replay) replay = buildReplay(events as unknown as HarnessEvent[]);
                    presetId = (await presets.resolve(presetFromLog(storedHeader, events))).id;
                    await presets.mount(agentCtx, presetId);
                },
            } as Parameters<typeof agents.resume>[0]);
        } catch (error: unknown) {
            const detail = errorChain(error);
            if (detail.includes(`session "${sessionId}" not found`) || (error as NodeJS.ErrnoException)?.code === "ENOENT") throw invalidParams(`session not found: ${sessionId} (${detail})`);
            throw internalError(`cannot restore session ${sessionId}: ${detail}`);
        }
        const restored = replay ?? buildResumeMetadata(events as unknown as HarnessEvent[]);
        const cwd = options.cwd ?? storedHeader?.cwd;
        const projection = new SessionProjection(restored.contextWindow, {
            terminalOutput: clientTerminalOutput,
            ...(cwd !== undefined ? { cwd } : {}),
        });
        projection.title = restored.title;
        const record = registerRecord(
            sessionId,
            handle.agent,
            () => handle.dispose(),
            config.model,
            config.permissionMode ?? "workspace-write",
            projection,
        );
        if (presetId !== undefined) record.preset = presetId;
        // Permission facts are logged and replayed (permission/preset,
        // sandbox/mode, approval/policy events); mirror the service folds
        // so the advertised state matches what is enforced.
        {
            const storedMode = currentPermission(record);
            if (storedMode !== undefined) record.modeId = storedMode as SandboxMode;
            for (let index = events.length - 1; index >= 0; index -= 1) {
                const event = events[index] as unknown as { type?: string; data?: { policy?: string } };
                if (event?.type === "approval/policy") {
                    const policy = event.data?.policy;
                    if (policy === "ask" || policy === "never") record.approvals = policy;
                    break;
                }
            }
        }
        // A failed ownership claim publishes no transcript or title updates.
        if (replay !== undefined) {
            for (const update of replay.updates) notify(sessionId, update);
            if (restored.title !== undefined) {
                notify(sessionId, { sessionUpdate: "session_info_update", title: restored.title });
            }
        }
        ensureSelection(record);
        queueMicrotask(() => publishCommands(sessionId));
        return record;
    };

    /**
     * Committed session log for a fork. A running turn contributes only
     * assistant messages already appended; the live token stream is not a
     * fork point. Subagent children are refused before this read.
     */
    const readForkSource = async (
        sessionId: string,
    ): Promise<{ events: readonly SessionEvent[]; header: { cwd?: string; origin?: string; agentPreset?: string } }> => {
        await assertAcpVisibleSession(sessionId);
        const live = sessions.get(sessionId);
        if (live !== undefined) {
            return {
                events: readSessionEvents(live.agent.session) as readonly SessionEvent[],
                header: live.agent.session.header,
            };
        }
        const header = (await storedHeaders()).find((item) => String(item.id) === sessionId);
        if (header === undefined) throw invalidParams(`unknown session: ${sessionId}`);
        try {
            return {
                events: await readStoredEvents(sessionPersistence, SessionId(sessionId)),
                header,
            };
        } catch (error: unknown) {
            throw invalidParams(`unknown session: ${sessionId} (${errorChain(error)})`);
        }
    };

    const lastRequestRoute = (
        events: readonly ForkLogEvent[],
    ): { provider?: string; model?: string } => {
        for (let index = events.length - 1; index >= 0; index -= 1) {
            const event = events[index];
            if (event?.type !== "request/header" || event.data === null || typeof event.data !== "object") continue;
            const header = (event.data as { header?: unknown }).header;
            if (header === null || typeof header !== "object") continue;
            const config = (header as { config?: unknown }).config;
            if (config === null || typeof config !== "object") continue;
            const provider = (config as { provider?: unknown }).provider;
            const model = (config as { model?: unknown }).model;
            return {
                ...(typeof provider === "string" && provider.length > 0 ? { provider } : {}),
                ...(typeof model === "string" && model.length > 0 ? { model } : {}),
            };
        }
        return {};
    };

    /**
     * Build the child seed. Message fork cuts at the assistant message and
     * drops that message's own tool calls (results are logged after it).
     * Whole-session fork copies the committed log, including an open tail
     * that `buildForkSeed` closes.
     */
    const forkSeedFor = (
        events: readonly SessionEvent[],
        request: JetbrainsAirForkRequest | undefined,
        sessionId: string,
    ): { seed: SessionEvent[]; inherited: ReturnType<typeof SessionLogOffset>; kept: readonly ForkLogEvent[] } => {
        const kept = request === undefined
            ? events
            : inclusiveHistoryPrefix(events, locateForkPoint(events, request, sessionId).index);
        if (kept.length === 0) {
            return { seed: [], inherited: SessionLogOffset(0), kept };
        }
        const prefix = structuredClone(kept) as SessionEvent[];
        const boundary = prefix.length - 1;
        const last = prefix[boundary];
        if (last === undefined || Number(last.seq) !== boundary) {
            throw internalError("cannot fork: session log seqs are not contiguous");
        }
        return {
            seed: buildForkSeed(prefix, SessionSeq(boundary)),
            inherited: SessionLogOffset(boundary + 1),
            kept,
        };
    };

    const assertOpen = (): void => {
        if (closed) throw internalError("the ACP bridge has been disposed");
    };

    /** Send one update without letting a disconnected client fail an agent turn. */
    const notify = (sessionId: string, update: SessionUpdate): void => {
        void conn.sessionUpdate({ sessionId, update }).catch((error: unknown) => {
            logWarn(`session/update failed: ${String(error)}`);
        });
    };

    const settlePrompt = (record: SessionRecord, reason: StopReason): void => {
        const inflight = record.inflight;
        if (inflight === undefined) return;
        record.inflight = undefined;
        inflight.resolve(reason);
    };

    /** Observe one parent agent's scoped subagent lifecycle. */
    const watchSubagentParent = (parent: Agent): void => {
        if (watchedSubagentParents.has(parent as object)) return;
        watchedSubagentParents.add(parent as object);

        parent.ctx.on("subagent/start", (info: SubagentRunInfo) => {
            const parentLink = subagentByChild.get(String(parent.id));
            const rootSessionId = parentLink?.rootSessionId ?? String(parent.session.id);
            const record = sessions.get(rootSessionId);
            if (record === undefined) return;

            const runId = String(info.runId);
            const childSessionId = String(info.id);
            const toolCallId = `subagent:${runId}`;
            const payload: Record<string, unknown> = {
                runId,
                provider: info.provider,
                id: childSessionId,
                local: info.local,
                ...(parentLink !== undefined ? { parentToolCallId: parentLink.toolCallId } : {}),
            };
            for (const update of record.projection.onEvent({ type: "subagent/start", data: payload })) {
                notify(rootSessionId, update);
            }

            const child = agents.get(info.id);
            const link: LiveSubagent = {
                rootSessionId,
                childSessionId,
                runId,
                provider: info.provider,
                toolCallId,
                projection: new SessionProjection(undefined, {
                    terminalOutput: clientTerminalOutput,
                    ...(child?.session.header.cwd !== undefined ? { cwd: child.session.header.cwd } : {}),
                    subagent: { childSessionId, parentToolCallId: toolCallId, provider: info.provider },
                }),
            };
            subagentByChild.set(childSessionId, link);
            subagentByRun.set(runId, link);
            if (child !== undefined) watchSubagentParent(child);
        });

        parent.ctx.on("subagent/end", (info: SubagentRunEndInfo) => {
            const runId = String(info.runId);
            const link = subagentByRun.get(runId);
            if (link === undefined) return;
            const record = sessions.get(link.rootSessionId);
            if (record !== undefined) {
                const parentLink = subagentByChild.get(String(parent.id));
                const payload: Record<string, unknown> = {
                    runId,
                    provider: info.provider,
                    id: String(info.id),
                    local: info.local,
                    stopReason: info.stopReason,
                    ...(info.lastAssistantMessage !== undefined
                        ? { lastAssistantMessage: info.lastAssistantMessage }
                        : {}),
                    ...(parentLink !== undefined ? { parentToolCallId: parentLink.toolCallId } : {}),
                };
                for (const update of record.projection.onEvent({ type: "subagent/end", data: payload })) {
                    notify(link.rootSessionId, update);
                }
            }
            subagentByRun.delete(runId);
            if (subagentByChild.get(link.childSessionId)?.runId === runId) {
                subagentByChild.delete(link.childSessionId);
            }
        });
    };

    // ------------------------------------------------------------------ //
    // Agent presets (session modes → preset compositions)                 //
    // ------------------------------------------------------------------ //

    /**
     * The optional `agentPresets` roster (mounted by the profile patch; the
     * dsh CLI injects its shipped root — standard/code/minimal/creator — into
     * any row with this id). Each preset is one model-facing composition
     * (persona, tools, compaction) that an agent joins at creation, so ACP
     * session modes map onto it: pick "minimal" in the client and the next
     * turn runs the two-tool fixed-prompt agent, exactly like the Web UI.
     */
    interface AgentPresetsService {
        list(): Promise<PresetRow[]>;
        resolve(id?: string): Promise<{ id: string }>;
        mount(agentCtx: unknown, id: string): Promise<void>;
    }

    const presetsService = (): AgentPresetsService => agentPresets as unknown as AgentPresetsService;

    /** Agent-create/resume `setup` joining one preset; undefined without a roster. */
    const presetSetup = (
        presets: AgentPresetsService,
        presetId: string | undefined,
    ): ((agentCtx: unknown) => Promise<void>) | undefined => {
        if (presetId === undefined) return undefined;
        return async (agentCtx: unknown) => {
            const started = performance.now();
            logDebug(`preset setup: mounting "${presetId}"`);
            await presets.mount(agentCtx, presetId);
            logDebug(`preset setup: mounted "${presetId}" in ${(performance.now() - started).toFixed(1)}ms`);
        };
    };

    /** Last selected preset in a stored log, else the creation-time header fact. */
    const presetFromLog = (
        header: { agentPreset?: string } | undefined,
        events: readonly { type?: string; data?: unknown }[],
    ): string | undefined => {
        for (let index = events.length - 1; index >= 0; index -= 1) {
            const event = events[index];
            if (event?.type === "agent-preset/selected") {
                return (event.data as { agentPreset?: string } | undefined)?.agentPreset;
            }
        }
        return header?.agentPreset;
    };

    /** Sandbox confinement levels: the session-mode selector, always. */
    const modeState = (record: SessionRecord): SessionModeState => {
        const permission = permissionService();
        if (permission.names.length > 0) {
            return {
                currentModeId: record.modeId,
                availableModes: permission.names.map((name) => {
                    const presentation = permissionPresentation(name);
                    return { id: name, ...presentation };
                }),
            };
        }
        return {
            currentModeId: record.modeId,
            availableModes: SANDBOX_MODES.map((mode) => {
                const label = MODE_LABELS[mode] ?? { name: mode, description: "" };
                return { id: mode, name: label.name, description: label.description };
            }),
        };
    };

    /**
     * Switch the agent preset: rebuild the agent over the same session so the
     * new composition joins from the next turn. Record the durable
     * `agent-preset/selected` fact only after the new composition mounts — a
     * failed mount must not poison the log or drop the live session.
     */
    const switchPreset = async (record: SessionRecord, acpSessionId: string, presetId: string): Promise<void> => {
        if (record.inflight !== undefined) {
            throw invalidParams("cannot switch presets while a prompt is running");
        }
        const presets = presetsService();
        let resolved: string;
        try {
            resolved = (await presets.resolve(presetId)).id;
        } catch (error: unknown) {
            throw invalidParams(`unknown preset: ${presetId} (${errorChain(error)})`);
        }
        if (resolved === record.preset) return;
        const previous = record.preset;
        const sessionId = record.agent.session.id;
        const resumeWith = (id: string | undefined) =>
            agents.resume({
                resumeSessionId: sessionId,
                agentOptions: agentOptionsFor(record.model ?? config.model, record.provider),
                ...(presetSetup(presets, id) !== undefined ? { setup: presetSetup(presets, id) } : {}),
            } as Parameters<typeof agents.resume>[0]);
        await record.dispose().catch((error: unknown) => {
            logWarn(`dispose during preset switch failed: ${String(error)}`);
        });
        let handle: Awaited<ReturnType<typeof resumeWith>>;
        try {
            handle = await resumeWith(resolved);
        } catch (error: unknown) {
            try {
                handle = await resumeWith(previous);
            } catch (restoreError: unknown) {
                sessions.delete(acpSessionId);
                throw internalError(
                    `preset switch failed: ${errorChain(error)}; restore also failed: ${errorChain(restoreError)}`,
                );
            }
            record.agent = handle.agent;
            record.dispose = () => handle.dispose();
            delete record.selection;
            ensureSelection(record);
            setApprovalPolicy(record, record.approvals);
            publishCommands(acpSessionId, record);
            throw invalidParams(`preset "${resolved}" failed to mount: ${errorChain(error)}`);
        }
        record.agent = handle.agent;
        record.dispose = () => handle.dispose();
        record.preset = resolved;
        try {
            (
                handle.agent.session as unknown as {
                    append(type: string, data: unknown): unknown;
                }
            ).append("agent-preset/selected", { agentPreset: resolved });
        } catch (error: unknown) {
            logWarn(`recording preset selection failed: ${String(error)}`);
        }
        delete record.selection;
        ensureSelection(record);
        // Approval policy is agent-scoped state; re-apply it to the new agent.
        setApprovalPolicy(record, record.approvals);
        publishCommands(acpSessionId, record);
    };

    /** Flip the per-agent approval policy, mirroring the result on the record. */
    const setApprovalPolicy = (record: SessionRecord, policy: ApprovalPolicy): void => {
        try {
            approval.setPolicy(record.agent, policy);
        } catch (error: unknown) {
            logWarn(`approval policy switch failed: ${String(error)}`);
        }
        record.approvals = policy;
    };

    /** Apply one sandbox mode: confinement, coupled approval default, mode update. */
    /**
     * The permission-presets service: the product's ONE user-facing
     * permission concept. Each named preset bundles a sandbox confinement
     * with its approval policy (read-only/ask, workspace-write/ask,
     * danger-full-access/never by default — deployments can reconfigure the
     * table). The Web UI and TUI surface exactly these presets and never a
     * standalone approval toggle; the session-mode selector mirrors that.
     */
    interface PermissionPresetsService {
        names: string[];
        defaultPreset: string;
        resolve(name: string): { sandbox: SandboxMode; approval: ApprovalPolicy; name: string; description: string };
        current(sessionOrEvents: unknown): string | undefined;
        apply(
            session: unknown,
            name: string,
            setApproval: (policy: ApprovalPolicy) => void,
            origin?: string,
        ): void;
    }

    const permissionService = (): PermissionPresetsService =>
        permissionPresets as unknown as PermissionPresetsService;

    const currentPermission = (record: SessionRecord): string | undefined => {
        const session = record.agent.session as { snapshotEvents?: () => readonly unknown[]; events?: readonly unknown[] };
        return permissionService().current(typeof session.snapshotEvents === "function" ? session : readSessionEvents(session));
    };

    /** ACP requires labels even when a deployment configures only preset behavior. */
    const permissionPresentation = (id: string): { name: string; description: string } => {
        const spec = permissionService().resolve(id);
        const stock = MODE_LABELS[id as SandboxMode];
        const fallbackName = stock?.name
            ?? id.split("-").map((part) => part.length > 0 ? `${part[0]!.toUpperCase()}${part.slice(1)}` : part).join(" ");
        return {
            name: typeof spec.name === "string" && spec.name.trim().length > 0 ? spec.name : fallbackName,
            description: typeof spec.description === "string"
                ? spec.description
                : (stock?.description ?? ""),
        };
    };

    /** Match model selection: a successful preset switch becomes the default for future sessions. */
    const saveDefaultPermission = async (modeId: string): Promise<void> => {
        if (!permissionService().names.includes(modeId)) return;
        try {
            const settings = ctx.get("settings");
            if (settings !== undefined) {
                await settings.update(PERMISSION_SETTINGS_NAMESPACE, { defaultPreset: modeId });
            } else {
                const save = ctx.get("dshAcpSavePermission") as ((mode: string) => Promise<void>) | undefined;
                await save?.(modeId);
            }
        } catch (error: unknown) {
            // The current-session switch remains valid when settings are
            // read-only or no settings provider is mounted.
            logWarn(`permission switch applied to the session but was not saved as the default: ${String(error)}`);
        }
    };

    const applyMode = (record: SessionRecord, sessionId: string, modeId: string): void => {
        const permission = permissionService();
        if (permission.names.includes(modeId)) {
            // The authoritative path: records the durable permission/preset
            // fact, applies the sandbox, and writes the bundled approval
            // policy through the live agent.
            let bundledApproval: ApprovalPolicy = record.approvals;
            permission.apply(
                record.agent.session,
                modeId,
                (policy) => {
                    bundledApproval = policy;
                },
                "selection",
            );
            setApprovalPolicy(record, bundledApproval);
            record.modeId = permission.resolve(modeId).sandbox;
            notify(sessionId, { sessionUpdate: "current_mode_update", currentModeId: modeId });
            return;
        }
        const mode = SANDBOX_MODES.find((candidate) => candidate === modeId);
        if (mode === undefined) throw invalidParams(`unknown mode: ${modeId}`);
        setSandboxMode(record.agent.session, mode);
        setApprovalPolicy(record, mode === "danger-full-access" ? "never" : "ask");
        record.modeId = mode;
        notify(sessionId, { sessionUpdate: "current_mode_update", currentModeId: mode });
    };

    /** The model-select entries: adapter directory first, then static config. */
    const modelChoices = async (record: SessionRecord): Promise<{ value: string; name: string }[]> => {
        await reconcileModel(record);
        const seen = new Set<string>();
        const options: { value: string; name: string }[] = [];
        const push = (value: string, name: string): void => {
            if (seen.has(value)) return;
            seen.add(value);
            options.push({ value, name });
        };
        const current = encodeChoice(
            record.provider,
            record.model ?? config.model ?? defaultSelection().model ?? record.agent.options.model ?? "",
        );
        if (current.length === 0) return [];
        // Adapter directory first: it carries human names and third-party
        // routes. Static config and the current selection are backstops.
        const discovered = await discoverModels();
        push(current, discovered.find((c) => encodeChoice(c.provider, c.model) === current)?.label ?? current);
        for (const choice of discovered) {
            push(encodeChoice(choice.provider, choice.model), choice.label);
        }
        for (const model of modelCandidates()) push(encodeChoice(undefined, model), model);
        return options;
    };

    /**
     * Session config options: sandbox mode, model, reasoning effort, and
     * approvals. Everything lives here (not only in `modes`) because clients
     * that support config options — Zed — drop the `modes` state entirely
     * when any config option is present.
     */
    const configOptions = async (record: SessionRecord): Promise<SessionConfigOption[]> => {
        const result: SessionConfigOption[] = [];

        // The permission level (the product's one user-facing {sandbox,
        // approval} dimension) ALSO travels as a config option: session modes
        // carry the same state for clients that render them, but some (Zed
        // among them) only surface config options.
        {
            const permission = permissionService();
            const levels =
                permission.names.length > 0
                    ? permission.names.map((name) => {
                          const presentation = permissionPresentation(name);
                          return { value: name, ...presentation };
                      })
                    : SANDBOX_MODES.map((mode) => {
                          const label = MODE_LABELS[mode] ?? { name: mode, description: "" };
                          return { value: mode, name: label.name, description: label.description };
                      });
            result.push({
                type: "select",
                id: "mode",
                name: "Permissions",
                category: "mode",
                currentValue: record.modeId,
                options: levels,
            });
        }

        if (commandRuntime.list(record.agent).some((command) => command.name === "plan")) {
            const active = [...readSessionEvents(record.agent.session)]
                .reverse()
                .map((event) => event as unknown as HarnessEvent)
                .find((event) => event.type === "plan/mode")?.data?.["active"] === true;
            result.push({
                type: "select",
                id: "collaboration_mode",
                name: "Collaboration mode",
                currentValue: active ? "plan" : "default",
                options: [
                    { value: "default", name: "Default" },
                    { value: "plan", name: "Plan" },
                ],
            });
        }

        const models = await modelChoices(record);
        if (models.length >= 2) {
            result.push({
                type: "select",
                id: "model",
                name: "Model",
                category: "model",
                currentValue: models[0]!.value,
                options: models,
            });
        }

        const route = routeOf(record);
        const efforts = await effortCatalog(route.provider, route.model);
        if (efforts !== undefined && efforts.efforts.length >= 2) {
            const known = new Set(efforts.efforts.map((effort) => effort.id));
            const preferred = [
                record.effort,
                loggedConfig(record)?.reasoningEffort,
                // The user's saved product default (Web UI → settings.yaml),
                // e.g. reasoningEffort: max, outranks the adapter's default.
                defaultSelection().reasoningEffort,
                efforts.defaultEffort,
            ].find(
                (candidate): candidate is string => candidate !== undefined && known.has(candidate),
            );
            result.push({
                type: "select",
                id: "effort",
                name: "Reasoning",
                category: "thought_level",
                currentValue: preferred ?? efforts.efforts[0]!.id,
                options: efforts.efforts.map((effort) => ({
                    value: effort.id,
                    name: effort.name,
                    ...(effort.description !== undefined ? { description: effort.description } : {}),
                })),
            });
        }

        // Agent presets: one model-facing composition (persona, tool surface,
        // compaction) per entry. ACP has no icon on configOptions; clients
        // special-case `id: "agent"` / `name: "Agent"`.
        const presets = presetsService();
        if (record.preset !== undefined) {
            try {
                const roster = await presets.list();
                if (roster.length >= 2) {
                    result.push({
                        type: "select",
                        id: "agent",
                        name: "Agent",
                        currentValue: record.preset,
                        options: roster.map((preset) => ({
                            value: preset.id,
                            name: presetDisplayName(preset),
                            description: `Agent preset “${preset.id}”`,
                        })),
                    });
                }
            } catch (error: unknown) {
                logWarn(`preset roster unavailable: ${String(error)}`);
            }
        }

        return result;
    };

    /** Built-in adapter commands, always first and never shadowed. */
    const BUILTIN_COMMANDS = [
        { name: "status", description: "Show adapter, model, mode, and token status" },
        {
            name: "model",
            description: "Select the model for this conversation",
            input: { hint: "[model] — blank lists available models" },
        },
    ];

    /**
     * The full command surface for one live agent: adapter built-ins, the
     * harness command registry (compact/goal/permission/plan/… — whatever
     * the composition mounts, scoped per agent), and user-invocable skills.
     * A skill needs no dispatch here: `/name` in a user message is the
     * harness's own invocation gesture, handled inside the agent.
     */
    const availableCommandsFor = async (
        record: SessionRecord,
    ): Promise<
        {
            name: string;
            description: string;
            input?: { hint: string };
            _meta?: Record<string, unknown>;
        }[]
    > => {
        const list: {
            name: string;
            description: string;
            input?: { hint: string };
            _meta?: Record<string, unknown>;
        }[] = [...BUILTIN_COMMANDS];
        if (tuiClient.advertised) {
            list.push({
                name: "plan-view",
                description: "Open the current ACP plan",
                _meta: {
                    commandAction: {
                        kind: "clientCommand",
                        presentation: "view",
                    },
                },
            });
        }
        const seen = new Set(list.map((command) => command.name));
        try {
            for (const descriptor of commandRuntime.list(record.agent)) {
                // Auth commands are never advertised over ACP, even when a
                // composition registers one (claude-agent-acp UNSUPPORTED_COMMANDS).
                if (NATIVE_AUTH_COMMANDS.has(descriptor.name)) continue;
                if (seen.has(descriptor.name)) continue;
                seen.add(descriptor.name);
                list.push({
                    name: descriptor.name,
                    description: descriptor.description,
                    ...(descriptor.input !== undefined ? { input: { hint: descriptor.input.hint } } : {}),
                    ...(descriptor.name === "plan"
                        ? {
                              _meta: {
                                  commandAction: {
                                      kind: "setConfigOption",
                                      configId: "collaboration_mode",
                                      value: "plan",
                                      resetValue: "default",
                                      presentation: "state",
                                  },
                              },
                          }
                        : {}),
                });
            }
        } catch (error: unknown) {
            logWarn(`command listing failed: ${String(error)}`);
        }
        try {
            const skills = await skillRegistry.list({
                ...(record.agent.session.header.cwd !== undefined
                    ? { cwd: record.agent.session.header.cwd }
                    : {}),
                scope: record.agent,
            });
            for (const skill of skills) {
                if (skill.invocation.userInvocable !== true) continue;
                if (NATIVE_AUTH_COMMANDS.has(skill.name)) continue;
                if (seen.has(skill.name)) continue;
                seen.add(skill.name);
                list.push({
                    name: skill.name,
                    description: skill.description,
                    input: { hint: "instructions for the skill" },
                });
            }
        } catch (error: unknown) {
            logDebug(`skill listing failed: ${String(error)}`);
        }
        return list;
    };

    const publishCommands = (sessionId: string, record?: SessionRecord): void => {
        const target = record ?? sessions.get(sessionId);
        if (target === undefined) return;
        void commandPublications
            .run(sessionId, () => availableCommandsFor(target), (availableCommands) => {
                if (sessions.get(sessionId) !== target) return;
                logDebug(
                    `available commands ${sessionId}: ${availableCommands.map((command) => command.name).join(", ")}`,
                );
                notify(sessionId, { sessionUpdate: "available_commands_update", availableCommands });
            })
            .catch((error: unknown) => {
                logWarn(`publishing commands failed: ${String(error)}`);
            });
    };

    ctx.on("commands/change", () => {
        logDebug(`commands/change: ${sessions.size} live ACP session(s)`);
        for (const [sessionId, record] of sessions) publishCommands(sessionId, record);
    });

    /** Push the current config-option surface (Zed re-renders its selectors). */
    const publishConfigOptions = (sessionId: string, record: SessionRecord): void => {
        void configOptions(record)
            .then((options) => {
                notify(sessionId, {
                    sessionUpdate: "config_option_update",
                    configOptions: options,
                } as unknown as SessionUpdate);
            })
            .catch((error: unknown) => {
                logWarn(`publishing config options failed: ${String(error)}`);
            });
    };

    /**
     * Re-read session-logged permission facts into the record. Harness
     * commands (e.g. /permission) change durable state behind the adapter's
     * back; the advertised mode must follow the log, not our last write.
     */
    const syncPermissionState = (record: SessionRecord, sessionId: string): void => {
        const events = readSessionEvents(record.agent.session);
        const storedMode = currentPermission(record);
        for (let index = events.length - 1; index >= 0; index -= 1) {
            const event = events[index] as { type?: string; data?: { policy?: string } };
            if (event?.type === "approval/policy") {
                const policy = event.data?.policy;
                if (policy === "ask" || policy === "never") record.approvals = policy;
                break;
            }
        }
        if (storedMode !== undefined && storedMode !== record.modeId) {
            record.modeId = storedMode as SandboxMode;
            notify(sessionId, {
                sessionUpdate: "current_mode_update",
                currentModeId: record.modeId,
            } as unknown as SessionUpdate);
        }
    };

    // ------------------------------------------------------------------ //
    // Host credential seam (`ctx.credentials` / dsh-credentials-local)     //
    // ------------------------------------------------------------------ //

    const describeCredential = async (provider?: string): Promise<string> => {
        const names = credentialEnvNames(provider).filter((candidate) => !candidate.endsWith("_BASE_URL"));
        for (const name of names) {
            try {
                const info = await credentials.describe(credentialRef(name));
                if (info.configured) return info.source ?? "credential store";
            } catch (error: unknown) {
                logWarn(`credential describe failed: ${String(error)}`);
            }
        }
        return "not configured";
    };

    const saveCredential = async (provider: string | undefined, key: string): Promise<void> => {
        await credentials.set(credentialRef(primaryCredentialName(provider)), key);
    };

    const saveGateway = async (
        provider: string | undefined,
        key: string,
        baseUrl: string,
    ): Promise<void> => {
        await saveCredential(provider, key);
        await credentials.set(credentialRef(credentialBaseUrlName(provider)), baseUrl);
    };

    /**
     * Scoped ACP logout: clears the stored key and gateway base-URL of one
     * provider — the configured route, or the one named by `logout`'s
     * `_meta.provider` — never every provider's credentials.
     */
    const logoutScopedProvider = async (provider: string | undefined): Promise<void> => {
        for (const name of new Set([primaryCredentialName(provider), credentialBaseUrlName(provider)])) {
            try {
                await credentials.unset(credentialRef(name));
            } catch (error: unknown) {
                logWarn(`credential unset failed: ${String(error)}`);
            }
        }
    };

    /** Routes to report on: the live directory, else the one configured route. */
    const authStatusRoutes = async (): Promise<ProviderRoute[]> => {
        if (latestProviders.length > 0) return latestProviders;
        const routes = await listProviderRoutes();
        return routes.length > 0 ? routes : [{ id: config.provider ?? "deepseek-official" }];
    };

    /** Which providers are usable and through which method — no secret values. */
    const computeAuthStatus = async (): Promise<AuthStatus> => {
        const providers: AuthStatusProvider[] = [];
        for (const route of await authStatusRoutes()) {
            const credentialName = primaryCredentialName(route.id);
            let info: { configured: boolean; source?: string };
            try {
                info = await credentials.describe(credentialRef(credentialName));
            } catch (error: unknown) {
                logWarn(`auth status describe failed for ${route.id}: ${String(error)}`);
                continue;
            }
            if (!info.configured) continue;
            let baseUrlConfigured = false;
            try {
                baseUrlConfigured = (
                    await credentials.describe(credentialRef(credentialBaseUrlName(route.id)))
                ).configured;
            } catch (error: unknown) {
                logDebug(`auth status base-url describe failed for ${route.id}: ${String(error)}`);
            }
            providers.push({
                providerId: route.id,
                ...(route.name !== undefined ? { name: route.name } : {}),
                kind: baseUrlConfigured
                    ? "gateway"
                    : info.source === "env"
                      ? "environment"
                      : "api_key",
                label: credentialName,
            });
        }
        providers.sort((a, b) => a.providerId.localeCompare(b.providerId));
        const label =
            providers.length === 0
                ? "Not logged in"
                : providers.length === 1 && providers[0] !== undefined
                  ? `${providers[0].name ?? providers[0].providerId} · ${providers[0].label}`
                  : `${providers.length} providers`;
        return {
            kind: providers.length > 0 ? "authenticated" : "none",
            label,
            providers,
        };
    };

    /** Push `_auth/status_update` when the credential picture changed since the last push. */
    const publishAuthStatus = async (): Promise<void> => {
        if (closed) return;
        const status = await computeAuthStatus();
        const json = JSON.stringify(status);
        if (json === lastAuthStatus) return;
        lastAuthStatus = json;
        try {
            await conn.extNotification("_auth/status_update", { authStatus: status });
        } catch (error: unknown) {
            logDebug(`_auth/status_update failed: ${String(error)}`);
        }
    };

    // The terminal login, the Web UI, or a re-authenticate can change the
    // store outside this connection: republish on any credential update.
    ctx.on("credentials/reference-updated", () => {
        void publishAuthStatus().catch((error: unknown) => {
            logDebug(`auth status republish failed: ${String(error)}`);
        });
    });

    /** Browser login through url elicitation (src/bridge/auth-flow.ts). */
    const runBridgeBrowserLogin = async (provider: string | undefined): Promise<void> => {
        const credentialName = primaryCredentialName(provider);
        authPageSeq += 1;
        try {
            await runBrowserLogin(
                {
                    createElicitation: (request) => conn.createElicitation(request),
                    completeElicitation: (params) => conn.completeElicitation(params),
                    startPage: (options) => startLocalAuthPage(options),
                    openPage: (url) => openLocalAuthPage(url),
                    saveCredential: (key) => saveCredential(provider, key),
                    requestId: requestIds.latestFor("authenticate"),
                    provider,
                    elicitationId: `dsh-acp-auth-${authPageSeq}`,
                    logDebug,
                },
                credentialName,
            );
        } catch (error: unknown) {
            if (error instanceof AuthLoginCancelled) {
                throw authError("browser login was cancelled by the client");
            }
            if (error instanceof RequestError) throw error;
            throw authError(
                `browser login did not complete: ${errorChain(error)} — supply the key with authenticate \`_meta["api-key"].apiKey\`, a gateway, or the terminal login method`,
            );
        }
    };

    /**
     * The /model command: no argument lists the live catalog with the current
     * route marked; an argument switches by exact id (`provider::model` or
     * model id) or unique case-insensitive substring of the id or label.
     */
    const modelCommandText = async (
        record: SessionRecord,
        acpSessionId: string,
        query: string,
    ): Promise<string> => {
        const discovered = await discoverModels();
        const catalog: { value: string; label: string }[] = [
            ...discovered.map((entry) => ({
                value: encodeChoice(entry.provider, entry.model),
                label: entry.label,
            })),
            ...modelCandidates()
                .filter((model) => !discovered.some((entry) => entry.model === model))
                .map((model) => ({ value: encodeChoice(undefined, model), label: model })),
        ];
        const route = routeOf(record);
        const currentValue = encodeChoice(record.provider, record.model ?? route.model ?? "");
        if (query === "") {
            const lines = catalog.map(
                (entry) => `${entry.value === currentValue ? "→" : " "} ${entry.label} — ${entry.value}`,
            );
            return [
                `model: ${route.model ?? "(product default)"}${record.effort !== undefined ? ` (effort ${record.effort})` : ""}`,
                "",
                ...(lines.length > 0 ? lines : ["no models discovered — check credentials with /status"]),
                "",
                "switch with /model <name>",
            ].join("\n");
        }
        const lowered = query.toLowerCase();
        const exact = catalog.filter(
            (entry) =>
                entry.value.toLowerCase() === lowered ||
                splitChoice(entry.value).model.toLowerCase() === lowered,
        );
        const matches =
            exact.length > 0
                ? exact
                : catalog.filter(
                      (entry) =>
                          entry.value.toLowerCase().includes(lowered) ||
                          entry.label.toLowerCase().includes(lowered),
                  );
        if (matches.length === 0) return `no model matches "${query}" — see /model`;
        if (matches.length > 1) {
            return [`"${query}" is ambiguous:`, ...matches.map((entry) => `  ${entry.label} — ${entry.value}`)].join(
                "\n",
            );
        }
        const target = matches[0] as { value: string; label: string };
        if (target.value === currentValue) return `already on ${target.label}`;
        await mutateSession(record, () => switchModel(record, acpSessionId, target.value));
        publishCommands(acpSessionId, record);
        publishConfigOptions(acpSessionId, record);
        return `model → ${target.label}`;
    };

    const statusText = async (record: SessionRecord): Promise<string> => {
        const used = record.projection.contextWindow;
        const route = routeOf(record);
        const effort = record.effort ?? loggedConfig(record)?.reasoningEffort;
        const lines = [
            `**dsh-acp** ${VERSION} — DeepSeek Harness ACP bridge`,
            "",
            `| | |`,
            `|---|---|`,
            `| Provider | ${route.provider ?? "(composition default)"} |`,
            `| Model | ${route.model ?? "(composition default)"} |`,
            `| Reasoning | ${effort ?? "(adapter default)"} |`,
            `| Credential | ${await describeCredential(route.provider)} |`,
            ...(record.preset !== undefined ? [`| Preset | ${record.preset} |`] : []),
            `| Permission mode | ${record.modeId} |`,
            `| Approvals | ${record.approvals} |`,
            `| Workspace | ${record.agent.session.header.cwd ?? process.cwd()} |`,
            `| Session | ${String(record.agent.session.id)} |`,
            ...(used !== undefined ? [`| Context window | ${used.toLocaleString()} tokens |`] : []),
        ];
        return lines.join("\n");
    };

    const registerRecord = (
        sessionId: string,
        agent: Agent,
        dispose: () => Promise<void>,
        model: string | undefined,
        modeId: SandboxMode,
        projection?: SessionProjection,
    ): SessionRecord => {
        const record: SessionRecord = {
            agent,
            dispose,
            projection:
                projection ??
                new SessionProjection(undefined, {
                    terminalOutput: clientTerminalOutput,
                    ...(agent.session.header.cwd !== undefined ? { cwd: agent.session.header.cwd } : {}),
                }),
            modeId,
            model,
            approvals: modeId === "danger-full-access" ? "never" : "ask",
            cancelled: false,
            inflight: undefined,
            mutationTail: Promise.resolve(),
        };
        sessions.set(sessionId, record);
        watchSubagentParent(agent);
        return record;
    };

    // ------------------------------------------------------------------ //
    // Live event routing                                                  //
    // ------------------------------------------------------------------ //

    // Current dsh exposes running tool output through its job ring. Pair
    // registration with the tool dispatch that created it, then observe the
    // ring with an independent cursor so the model's own cursor is untouched.
    // Hosts without this capability keep the final-result content path.
    const liveTool = new AsyncLocalStorage<{ agent: Agent; callId: string }>();
    ctx.on("tools/execute", (exec, next) =>
        exec.agent === undefined
            ? next()
            : liveTool.run({ agent: exec.agent, callId: String(exec.callId) }, next));
    ctx.inject(["jobs"], (jobCtx) => {
        const jobs = jobCtx.get("jobs") as {
            events?: { subscribe(filter: { owners: "all" }, listener: (event: Record<string, unknown>) => void): () => void };
            readAt(id: never, from: number, owner: never): {
                chunks: readonly { text: string }[];
                next: number;
                lossy: boolean;
            };
        } | undefined;
        if (jobs?.events?.subscribe === undefined || typeof jobs.readAt !== "function") return;
        const active = new Map<string, { agent: Agent; callId: string; offset: number }>();
        const publish = (id: string): void => {
            const source = active.get(id);
            if (source === undefined) return;
            const record = ownedRecord(source.agent);
            if (record === undefined) return;
            const read = jobs.readAt(id as never, source.offset, source.agent.id as never);
            source.offset = read.next;
            if (read.lossy) {
                for (const update of record.projection.streamToolOutput(source.callId, "\n[earlier output was truncated]\n")) {
                    notify(String(source.agent.session.id), update);
                }
            }
            for (const chunk of read.chunks) {
                for (const update of record.projection.streamToolOutput(source.callId, chunk.text)) {
                    notify(String(source.agent.session.id), update);
                }
            }
        };
        const dispose = jobs.events.subscribe({ owners: "all" }, (event) => {
            const type = event["type"];
            if (type === "registered") {
                const job = event["job"] as { id?: unknown; owner?: unknown } | undefined;
                const tool = liveTool.getStore();
                if (tool !== undefined && job?.owner === tool.agent.id && typeof job.id === "string") {
                    active.set(job.id, { ...tool, offset: 0 });
                }
                return;
            }
            if (type !== "output" && type !== "settled") return;
            const id = type === "output"
                ? event["id"]
                : (event["job"] as { id?: unknown } | undefined)?.id;
            if (typeof id !== "string") return;
            publish(id);
            if (type === "settled") active.delete(id);
        });
        jobCtx.effect(() => dispose);
    });

    // DSH intentionally omits structured tool values from durable session events.
    // Observe the finalized execution result one layer earlier and stage its value
    // by call id so the following `tool/result` projection can publish it as
    // generic ACP metadata. Nested Code Mode dispatches have no matching
    // top-level ACP tool call and therefore stay on their own log surface.
    ctx.on("tools/result", (exec, result) => {
        if (exec.parent !== undefined || exec.agent === undefined || result.isError) return;
        const projection =
            ownedRecord(exec.agent)?.projection
            ?? subagentByChild.get(String(exec.agent.session.id))?.projection;
        projection?.recordToolResult(String(exec.callId), result.value);
    });

    ctx.on("session/event", (session, event: SessionEvent) => {
        const sessionId = String(session.header.id);
        const record = sessions.get(sessionId);
        if (record === undefined || record.agent.session !== session) {
            const child = subagentByChild.get(sessionId);
            if (child !== undefined && clientSubagentTranscript) {
                for (const update of child.projection.onEvent(event as unknown as HarnessEvent)) {
                    notify(child.rootSessionId, update);
                }
            }
            return;
        }
        try {
            const harnessEvent = event as unknown as HarnessEvent;
            for (const update of record.projection.onEvent(harnessEvent)) {
                notify(sessionId, update);
            }
            if (harnessEvent.type === "plan/mode") publishConfigOptions(sessionId, record);
        } finally {
            const inflight = record.inflight;
            if (inflight !== undefined && event.type === "turn/end" && inflight.turn === event.data.turn) {
                // Model failures surface immediately as prompt errors; other
                // endings settle at whole-agent idle.
                if (event.data.reason.kind === "error") {
                    record.inflight = undefined;
                    const detail = `turn failed: ${event.data.reason.error.message}`;
                    // A provider auth failure is auth_required (-32000) with
                    // the advertised methods, not a bare internal error —
                    // the client needs it to open its auth UI (issue #160).
                    inflight.reject(looksLikeAuthFailure(detail) ? authError(detail) : internalError(detail));
                }
            }
        }
    });

    // dsh 0.2 emits token deltas here. Durable `assistant/chunk` events are
    // no longer appended; the final `assistant/message` still dedupes text
    // that this stream already published.
    ctx.on("agent/assistant-stream", ({ agent, frame }) => {
        const sessionId = String(agent.session.id);
        const record = ownedRecord(agent);
        if (record !== undefined) {
            for (const update of record.projection.onAssistantStream(frame)) notify(sessionId, update);
            return;
        }
        const child = subagentByChild.get(sessionId);
        if (child !== undefined && clientSubagentTranscript) {
            for (const update of child.projection.onAssistantStream(frame)) notify(child.rootSessionId, update);
        }
    });

    ctx.on("agent/inbox/claimed", ({ agent, message, turn }) => {
        const record = ownedRecord(agent);
        const inflight = record?.inflight;
        if (inflight !== undefined && inflight.messageId === message.id) inflight.turn = turn;
    });

    ctx.on("agent/error", ({ agent, turn, error }) => {
        const record = ownedRecord(agent);
        const inflight = record?.inflight;
        if (record === undefined || inflight === undefined || inflight.turn === turn) return;
        record.inflight = undefined;
        const detail = `turn failed: ${errorChain(error)}`;
        inflight.reject(looksLikeAuthFailure(detail) ? authError(detail) : internalError(detail));
    });

    // Permission requests: one-shot decisions, with an "always for this
    // session" convenience that flips the harness approval policy to 'never'.
    ctx.on("approval/request", (request, next) => {
        const record = ownedRecord(request.agent);
        if (record === undefined || request.callId === undefined) return next();
        return conn
            .requestPermission({
                sessionId: String(record.agent.session.id),
                toolCall: { toolCallId: request.callId },
                options: [
                    { optionId: "allow-once", name: "Allow once", kind: "allow_once" },
                    { optionId: "allow-always", name: "Always allow (this session)", kind: "allow_always" },
                    { optionId: "reject-once", name: "Reject", kind: "reject_once" },
                ],
            })
            .then(({ outcome }) => {
                if (outcome.outcome === "cancelled") return "cancelled" as const;
                if (outcome.optionId === "allow-always") {
                    setApprovalPolicy(record, "never");
                    return "allowed-once" as const;
                }
                return outcome.optionId === "allow-once" ? ("allowed-once" as const) : ("rejected" as const);
            });
    });

    // ------------------------------------------------------------------ //
    // The ACP agent                                                       //
    // ------------------------------------------------------------------ //

    const makeAgent = (connection: AgentSideConnection): AcpAgent => {
        conn = connection;
        return {
            async initialize(params: InitializeRequest): Promise<InitializeResponse> {
                const requested = params.protocolVersion;
                // Zed's display-terminal extension: command tool calls embed a
                // presentation terminal when the client advertises it in the
                // capability _meta (the codex-acp contract).
                const capsMeta = (params.clientCapabilities as { _meta?: Record<string, unknown> } | undefined)?.[
                    "_meta"
                ];
                clientTerminalOutput =
                    capsMeta !== null && typeof capsMeta === "object"
                        ? capsMeta["terminal_output"] === true
                        : false;
                clientSubagentTranscript =
                    capsMeta !== null && typeof capsMeta === "object"
                        ? capsMeta["subagent-transcript"] === true
                        : false;
                clientInteractionMode = interactionModeFromClientMeta(capsMeta);
                clientElicitationForm =
                    params.clientCapabilities?.elicitation?.form !== undefined &&
                    params.clientCapabilities.elicitation.form !== null;
                clientAuthCapabilities = params.clientCapabilities as ClientAuthCapabilities | undefined;
                tuiClient.advertised = advertisesCordis(capsMeta);
                const providers = await listProviderRoutes();
                // Clients ignore notifications arriving before this response;
                // push the initial auth report right after it lands.
                setTimeout(() => void publishAuthStatus(), 0);
                return {
                    protocolVersion:
                        typeof requested === "number" && requested >= 1 && requested < PROTOCOL_VERSION
                            ? requested
                            : PROTOCOL_VERSION,
                    _meta: { steering: { supported: true } },
                    agentInfo: { name: "dsh-acp", title: "DeepSeek Harness", version: VERSION },
                    agentCapabilities: {
                        // Deep-merge: dsh.cordis and the inclusive fork capability stay siblings.
                        // dsh.runtime carries the resolved host identity so clients
                        // can display which dsh booted (standalone provides it;
                        // absent when mounted inside a dsh profile). `authStatus`
                        // announces that this agent pushes `_auth/status_update`
                        // whenever the credential picture changes (the openma
                        // auth-status convention).
                        _meta: {
                            dsh: {
                                cordis: { ...CORDIS_CAPABILITY },
                                ...(dshAcpRuntimeOf(ctx.get("dshAcpHost")) !== undefined
                                    ? { runtime: dshAcpRuntimeOf(ctx.get("dshAcpHost")) }
                                    : {}),
                            },
                            authStatus: {},
                            ...acpInclusiveForkCapabilityMeta(),
                        },
                        loadSession: true,
                        promptCapabilities: {
                            image: attachmentIngestOf(ctx.get("attachments")) !== undefined,
                            audio: false,
                            embeddedContext: true,
                        },
                        // Stdio servers always work; streamable HTTP maps onto
                        // mcp-client's second transport. Legacy SSE does not.
                        mcpCapabilities: { http: true, sse: false },
                        auth: { logout: {} },
                        sessionCapabilities: { list: {}, resume: {}, fork: {} },
                    },
                    authMethods: advertisedAuthMethods(
                        providers,
                        clientAuthCapabilities,
                        bridgeEnv,
                    ) as AuthMethod[],
                };
            },

            async authenticate(params: AuthenticateRequest): Promise<void> {
                const gateway = gatewayFromAuthenticate(params);
                if (isGatewayAuthMethod(params.methodId) || gateway.baseUrl) {
                    if (!gateway.baseUrl || !gateway.key) {
                        throw authError(
                            "authenticate gateway requires `_meta.gateway.baseUrl` and an Authorization header",
                        );
                    }
                    await saveGateway(
                        gateway.providerName ?? config.provider,
                        gateway.key,
                        gateway.baseUrl,
                    );
                    await publishAuthStatus();
                    return;
                }
                const submitted = apiKeyFromAuthenticate(params);
                const provider =
                    submitted.provider ?? providerFromAuthMethodId(params.methodId) ?? config.provider;
                if (submitted.key) {
                    await saveCredential(provider, submitted.key);
                    await publishAuthStatus();
                    return;
                }
                // Terminal methods are never sent to `authenticate` — the
                // client spawns the advertised command itself. A client that
                // sends one anyway gets the same answer whether or not a
                // credential is already present, so the out-of-band path
                // cannot be mistaken for a successful terminal login.
                if (isTerminalAuthMethod(params.methodId)) {
                    throw authError(
                        "terminal login runs out of band: the client runs the advertised `dsh-acp login` command itself — run it, then retry authenticate or session/new",
                    );
                }
                if (await credentialPresent(provider)) {
                    await publishAuthStatus();
                    return;
                }
                // Spec-compliant secret path without `_meta`: the api-key
                // (or browser) method falls back to the local page whose URL
                // the client receives through url elicitation.
                if (
                    (isBrowserAuthMethod(params.methodId) || isApiKeyAuthMethod(params.methodId)) &&
                    clientSupportsUrlElicitation(clientAuthCapabilities) &&
                    shouldOfferLocalAuthPage(bridgeEnv)
                ) {
                    await runBridgeBrowserLogin(provider);
                    await publishAuthStatus();
                    return;
                }
                if (isBrowserAuthMethod(params.methodId)) {
                    throw authError(
                        "browser login needs a client that supports URL elicitation: supply the key with authenticate `_meta[\"api-key\"].apiKey`, a gateway, or the terminal login method",
                    );
                }
                await requireCredential(provider);
            },

            async logout(params: LogoutRequest): Promise<void> {
                // Scoped to one provider: `_meta.provider` when sent, else the
                // configured route or the first live route — never every
                // provider's credentials.
                const meta = params._meta;
                const requested =
                    meta !== null &&
                    typeof meta === "object" &&
                    typeof (meta as { provider?: unknown }).provider === "string"
                        ? (meta as { provider: string }).provider.trim()
                        : undefined;
                const provider =
                    (requested !== undefined && requested.length > 0 ? requested : undefined) ??
                    config.provider ??
                    defaultProvider() ??
                    latestProviders[0]?.id;
                await logoutScopedProvider(provider);
                await publishAuthStatus();
            },

            async newSession(params: NewSessionRequest): Promise<NewSessionResponse> {
                assertOpen();
                const started = performance.now();
                let checkpoint = started;
                const mark = (name: string): void => {
                    const now = performance.now();
                    logDebug(`session/new ${name}: ${(now - checkpoint).toFixed(1)}ms (+${(now - started).toFixed(1)}ms)`);
                    checkpoint = now;
                };
                await requireCredential(config.provider);
                mark("credential");
                validateCwd(params.cwd);
                validateAdditionalDirectories(params.additionalDirectories);
                syncMcpServers(params.mcpServers, params.cwd);
                mark("request setup");
                const sessionId = SessionId(randomUUID());
                const presets = presetsService();
                const presetId = (await presets.resolve(undefined)).id;
                mark("preset resolve");
                const handle = await agents.create({
                    sessionId,
                    meta: { cwd: params.cwd, ...(presetId !== undefined ? { agentPreset: presetId } : {}) },
                    agentOptions: agentOptionsFor(config.model),
                    ...(presetSetup(presets, presetId) !== undefined
                        ? { setup: presetSetup(presets, presetId) }
                        : {}),
                } as Parameters<typeof agents.create>[0]);
                mark("agent create");
                if (closed) {
                    await handle.dispose();
                    throw internalError("connection closed during session/new");
                }
                const record = registerRecord(
                    String(sessionId),
                    handle.agent,
                    () => handle.dispose(),
                    config.model,
                    config.permissionMode ?? (permissionService().defaultPreset as SandboxMode),
                );
                if (presetId !== undefined) record.preset = presetId;
                if (config.permissionMode !== undefined) {
                    applyMode(record, String(sessionId), config.permissionMode);
                } else {
                    // session/created pins the Host's permission default into
                    // durable facts; advertise that fact instead of a client
                    // or adapter fallback.
                    syncPermissionState(record, String(sessionId));
                }
                ensureSelection(record);
                queueMicrotask(() => publishCommands(String(sessionId)));
                const options = await configOptions(record);
                mark("response surface");
                return {
                    sessionId: String(sessionId),
                    modes: modeState(record),
                    ...(options.length > 0 ? { configOptions: options } : {}),
                };
            },

            async loadSession(params: LoadSessionRequest): Promise<LoadSessionResponse> {
                assertOpen();
                await requireCredential(config.provider);
                validateCwd(params.cwd);
                validateAdditionalDirectories(params.additionalDirectories);
                syncMcpServers(params.mcpServers, params.cwd);
                requirePersistence();
                await assertAcpVisibleSession(params.sessionId);
                const record = await restoreSession(params.sessionId, { replay: true, cwd: params.cwd });
                const options = await configOptions(record);
                return {
                    modes: modeState(record),
                    ...(options.length > 0 ? { configOptions: options } : {}),
                };
            },

            async unstable_forkSession(params: ForkSessionRequest): Promise<ForkSessionResponse> {
                assertOpen();
                await requireCredential(config.provider);
                validateCwd(params.cwd);
                validateAdditionalDirectories(params.additionalDirectories);
                syncMcpServers(params.mcpServers, params.cwd);
                // Invalid fork meta fails before a missing session can hide it,
                // and never degrades into a whole-session copy.
                const request = parseForkRequest(params._meta);
                const source = await readForkSource(params.sessionId);
                const seeded = forkSeedFor(source.events, request, params.sessionId);
                const route = lastRequestRoute(seeded.kept);
                const live = sessions.get(params.sessionId);
                const model = route.model ?? (live !== undefined ? routeOf(live).model : undefined);
                const provider = route.provider ?? (live !== undefined ? routeOf(live).provider : undefined);
                const presets = presetsService();
                let presetId: string | undefined;
                try {
                    presetId = (await presets.resolve(presetFromLog(source.header, seeded.kept))).id;
                } catch (error: unknown) {
                    throw internalError(`cannot fork session ${params.sessionId}: ${errorChain(error)}`);
                }
                const sessionId = SessionId(randomUUID());
                let handle: Awaited<ReturnType<typeof agents.create>>;
                try {
                    handle = await agents.create({
                        sessionId,
                        meta: {
                            cwd: params.cwd,
                            parentSession: SessionId(params.sessionId),
                            isSeeded: true,
                            ...(presetId !== undefined ? { agentPreset: presetId } : {}),
                        },
                        inheritedEventCount: seeded.inherited,
                        seed: seeded.seed,
                        agentOptions: agentOptionsFor(model, provider),
                        ...(presetSetup(presets, presetId) !== undefined
                            ? { setup: presetSetup(presets, presetId) }
                            : {}),
                    } as Parameters<typeof agents.create>[0]);
                } catch (error: unknown) {
                    throw internalError(`cannot fork session ${params.sessionId}: ${errorChain(error)}`);
                }
                if (closed) {
                    await handle.dispose();
                    throw internalError("connection closed during session/fork");
                }
                const childId = String(sessionId);
                const record = registerRecord(
                    childId,
                    handle.agent,
                    () => handle.dispose(),
                    model,
                    config.permissionMode ?? (permissionService().defaultPreset as SandboxMode),
                );
                if (provider !== undefined) record.provider = provider;
                if (presetId !== undefined) record.preset = presetId;
                const recordedMode = currentPermission(record);
                if (
                    recordedMode !== undefined &&
                    recordedMode !== record.modeId &&
                    permissionService().names.includes(recordedMode)
                ) {
                    applyMode(record, childId, recordedMode);
                }
                ensureSelection(record);
                queueMicrotask(() => publishCommands(childId));
                const options = await configOptions(record);
                return {
                    sessionId: childId,
                    modes: modeState(record),
                    ...(options.length > 0 ? { configOptions: options } : {}),
                };
            },

            async resumeSession(params: ResumeSessionRequest): Promise<ResumeSessionResponse> {
                assertOpen();
                await requireCredential(config.provider);
                validateCwd(params.cwd);
                validateAdditionalDirectories(params.additionalDirectories);
                syncMcpServers(params.mcpServers, params.cwd);
                requirePersistence();
                await assertAcpVisibleSession(params.sessionId);
                const record = await restoreSession(params.sessionId, { replay: false, cwd: params.cwd });
                const options = await configOptions(record);
                return {
                    modes: modeState(record),
                    ...(options.length > 0 ? { configOptions: options } : {}),
                };
            },

            async listSessions(params: ListSessionsRequest): Promise<ListSessionsResponse> {
                assertOpen();
                const persistence = requirePersistence();
                const headers = await storedHeaders();
                headers.sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0));
                const filtered = (params.cwd !== undefined && params.cwd !== null
                    ? headers.filter((header) => header.cwd === params.cwd)
                    : headers).filter((header) => !isSubagentHeader(header));
                const page = filtered.slice(0, 100);
                const withTitles = await Promise.allSettled(
                    page.slice(0, 20).map(async (header) => {
                        const events = await readStoredEvents(persistence, header.id);
                        return foldSessionTitle(events)?.title;
                    }),
                );
                const sessionsInfo: SessionInfo[] = page.map((header, index) => {
                    const settled = withTitles[index];
                    const title = settled !== undefined && settled.status === "fulfilled" ? settled.value : undefined;
                    return {
                        sessionId: String(header.id),
                        cwd: header.cwd ?? "",
                        ...(title !== undefined ? { title } : {}),
                        ...(header.createdAt !== undefined
                            ? { updatedAt: new Date(header.createdAt).toISOString() }
                            : {}),
                    };
                });
                return { sessions: sessionsInfo };
            },

            async extMethod(method, params): Promise<Record<string, unknown>> {
                if (method !== "_session/steering") throw RequestError.methodNotFound(method);
                assertOpen();
                const parsed = steeringRequestSchema.safeParse(params);
                if (!parsed.success) throw invalidParams("invalid steering request");
                const record = requireSession(parsed.data.sessionId);
                const inflight = record.inflight;
                const promptRequired = { outcome: "promptRequired", reason: "noRunningTurn" };
                const stillRunning = () => inflight !== undefined
                    && record.inflight === inflight
                    && !record.cancelled
                    && record.agent.status === "running"
                    && (inflight.turn === undefined || record.projection.turnEndFor(inflight.turn) === undefined);
                // No detached prompt, even when idleBehavior was omitted. The
                // client owns the ordinary prompt lifecycle and event window.
                if (!stillRunning()) {
                    return promptRequired;
                }
                let converted;
                try {
                    converted = await convertPrompt(parsed.data.prompt, attachmentIngestOf(ctx.get("attachments")));
                } catch (error: unknown) {
                    if (error instanceof UnsupportedPromptContentError || error instanceof PromptImageError) {
                        throw invalidParams(error.message);
                    }
                    throw error;
                }
                if (converted.blocks.length === 0) throw invalidParams("empty prompt");
                await requireCredential(record.provider ?? config.provider);
                assertOpen();
                if (agents.get(record.agent.id) !== record.agent) {
                    throw internalError("steering failed: the agent was disposed outside the bridge");
                }
                // Conversion/auth may yield through completion, cancellation,
                // or even admission of another prompt. Never cross that turn
                // boundary. Check native idle too: whenIdle settles later.
                if (!stillRunning()) {
                    return promptRequired;
                }
                try {
                    deliverPrompt(record.agent, createUserMessage({
                        content: converted.blocks,
                        source: { kind: "user" },
                    }), true);
                } catch (error: unknown) {
                    const detail = error instanceof Error ? error.message : String(error);
                    throw internalError(`steering failed: ${detail}`);
                }
                return { outcome: "injected" };
            },

            async prompt(params: PromptRequest): Promise<PromptResponse> {
                assertOpen();
                const record = await requireOrRestoreSession(params.sessionId);
                let converted;
                try {
                    converted = await convertPrompt(
                        params.prompt,
                        attachmentIngestOf(ctx.get("attachments")),
                    );
                } catch (error: unknown) {
                    if (
                        error instanceof UnsupportedPromptContentError ||
                        error instanceof PromptImageError
                    ) {
                        throw invalidParams(error.message);
                    }
                    throw error;
                }
                if (converted.blocks.length === 0) throw invalidParams("empty prompt");

                // Adapter-level slash commands never reach the model.
                const trimmed = converted.displayText.trim();
                const commandMatch = trimmed.match(/^\/(\w[\w-]*)\b/);

                const respond = (text: string): PromptResponse => {
                    notify(params.sessionId, {
                        sessionUpdate: "agent_message_chunk",
                        content: { type: "text", text },
                    });
                    return { stopReason: "end_turn" };
                };

                // Native auth commands are never delivered — not to the
                // model, not to the harness registry, and not injected into a
                // running turn (this check must precede the steer branch).
                // The turn answers with a plain notice and end_turn — never
                // auth_required, which is reserved for turns that genuinely
                // lack a credential — and typing them changes nothing.
                if (commandMatch !== null && commandMatch[1] !== undefined && NATIVE_AUTH_COMMANDS.has(commandMatch[1])) {
                    return respond(
                        commandMatch[1] === "login"
                            ? "/login isn't available in this environment — use your client's sign-in (ACP auth methods)."
                            : "/logout isn't available in this environment — use your client's sign-out (ACP logout).",
                    );
                }

                // ACP clients steer by issuing another session/prompt while
                // the active one is still in flight. Queueing is client-side;
                // the bridge must deliver an immediate second prompt to the
                // harness's next-step inbox without disturbing the active
                // request or its projection window.
                if (record.inflight !== undefined) {
                    await requireCredential(record.provider ?? config.provider);
                    if (agents.get(record.agent.id) !== record.agent) {
                        throw internalError("prompt was not steered: the agent was disposed outside the bridge");
                    }
                    const message = createUserMessage({
                        content: converted.blocks,
                        source: { kind: "user" },
                    });
                    try {
                        deliverPrompt(record.agent, message, true);
                    } catch (error: unknown) {
                        const detail = error instanceof Error ? error.message : String(error);
                        throw internalError(`prompt was not steered: ${detail}`);
                    }
                    return { stopReason: "end_turn" };
                }

                if (commandMatch?.[1] === "status") return respond(await statusText(record));
                if (commandMatch?.[1] === "model") {
                    return respond(
                        await modelCommandText(
                            record,
                            params.sessionId,
                            trimmed.slice(commandMatch[0].length).trim(),
                        ),
                    );
                }
                if (commandMatch !== null && commandMatch[1] !== undefined) {
                    // The harness command registry (compact/goal/permission/…)
                    // executes without a model turn. An unresolved slash falls
                    // through: /skill-name is the harness's own skill gesture
                    // and is claimed inside the agent's next step.
                    let execution;
                    try {
                        execution = await executeCommand(
                            record.agent,
                            trimmed,
                            new AbortController().signal,
                        );
                    } catch (error: unknown) {
                        return respond(`⚠ /${commandMatch[1]} failed: ${errorChain(error)}`);
                    }
                    if (execution !== undefined) {
                        const { result } = execution;
                        const text =
                            result.text ??
                            (result.kind === "success" ? `/${commandMatch[1]} ✓` : `/${commandMatch[1]} failed`);
                        // Commands can change agent-visible state (permission
                        // preset, plan mode); follow the session log and
                        // refresh every advertised surface.
                        syncPermissionState(record, params.sessionId);
                        publishCommands(params.sessionId, record);
                        publishConfigOptions(params.sessionId, record);
                        return respond(result.kind === "error" ? `⚠ ${text}` : text);
                    }
                }

                // Gate model turns (not slash commands) on a usable credential
                // for the session's current provider route.
                await requireCredential(record.provider ?? config.provider);

                // Never drive a retired agent: an agent-loop reload disposes
                // agents while bridge records survive.
                if (agents.get(record.agent.id) !== record.agent) {
                    throw internalError("prompt was not queued: the agent was disposed outside the bridge");
                }

                record.cancelled = false;
                await reconcileModel(record);
                const message = createUserMessage({
                    content: converted.blocks,
                    source: { kind: "user" },
                });

                // Prompt conversion and credential lookup can yield. A second
                // request may have won the turn slot while this one awaited;
                // re-check immediately before admission so it becomes steer
                // instead of overwriting the active inflight record.
                if (record.inflight !== undefined) {
                    try {
                        deliverPrompt(record.agent, message, true);
                    } catch (error: unknown) {
                        const detail = error instanceof Error ? error.message : String(error);
                        throw internalError(`prompt was not steered: ${detail}`);
                    }
                    return { stopReason: "end_turn" };
                }

                record.projection.beginPrompt();

                const stopReason = await new Promise<StopReason>((resolve, reject) => {
                    const inflight: Inflight = { resolve, reject, messageId: message.id, turn: undefined };
                    record.inflight = inflight;
                    try {
                        deliverPrompt(record.agent, message, false);
                    } catch (error: unknown) {
                        record.inflight = undefined;
                        const detail = error instanceof Error ? error.message : String(error);
                        throw internalError(`prompt was not queued: ${detail}`);
                    }
                    // Settle at whole-agent idle: a correlated turn/end decides
                    // the stop reason; a turnless slot means admission discarded
                    // the prompt (reported as cancelled).
                    void record.agent.whenIdle().then(() => {
                        if (record.inflight !== inflight) return;
                        record.inflight = undefined;
                        if (record.cancelled) {
                            resolve("cancelled");
                            return;
                        }
                        const end =
                            inflight.turn !== undefined
                                ? record.projection.turnEndFor(inflight.turn) ?? record.projection.lastTurnEnd
                                : record.projection.lastTurnEnd;
                        resolve(end === undefined ? "cancelled" : turnEndToStopReason(end));
                    });
                });

                const usage = record.projection.promptUsage();
                return { stopReason, ...(usage !== undefined ? { usage } : {}) };
            },

            async setSessionMode(params: SetSessionModeRequest): Promise<SetSessionModeResponse> {
                const record = await requireOrRestoreSession(params.sessionId);
                applyMode(record, params.sessionId, params.modeId);
                await saveDefaultPermission(params.modeId);
                notify(params.sessionId, {
                    sessionUpdate: "config_option_update",
                    configOptions: await configOptions(record),
                });
                return {};
            },

            async setSessionConfigOption(
                params: SetSessionConfigOptionRequest,
            ): Promise<SetSessionConfigOptionResponse> {
                const record = await requireOrRestoreSession(params.sessionId);
                const value = typeof params.value === "string" ? params.value : undefined;
                if (value === undefined) throw invalidParams(`invalid value: ${String(params.value)}`);

                switch (params.configId) {
                    case "mode": {
                        applyMode(record, params.sessionId, value);
                        await saveDefaultPermission(value);
                        break;
                    }
                    case "agent":
                    case "preset": {
                        await mutateSession(record, () => switchPreset(record, params.sessionId, value));
                        break;
                    }
                    case "effort": {
                        const route = routeOf(record);
                        const catalog = await effortCatalog(route.provider, route.model);
                        if (catalog === undefined || !catalog.efforts.some((effort) => effort.id === value)) {
                            throw invalidParams(`unknown effort: ${value}`);
                        }
                        const selection = ensureSelection(record);
                        if (selection === undefined || route.provider === undefined || route.model === undefined) {
                            throw invalidParams("reasoning effort switching is unavailable on this host");
                        }
                        // Snapshotted at the next step's prompt assembly; a
                        // running turn keeps its captured selection.
                        selection.current = {
                            provider: route.provider,
                            model: route.model,
                            reasoningEffort: value,
                        };
                        record.effort = value;
                        await saveDefaultSelection(record);
                        break;
                    }
                    case "collaboration_mode": {
                        if (value !== "default" && value !== "plan") {
                            throw invalidParams(`unknown collaboration mode: ${value}`);
                        }
                        const execution = await executeCommand(
                            record.agent,
                            value === "plan" ? "/plan" : "/plan off",
                            new AbortController().signal,
                        );
                        if (execution === undefined) {
                            throw invalidParams("plan mode is unavailable on this session");
                        }
                        if (execution.result.kind === "error") {
                            throw invalidParams(execution.result.text);
                        }
                        break;
                    }
                    case "model": {
                        await mutateSession(record, () => switchModel(record, params.sessionId, value));
                        break;
                    }
                    default:
                        throw invalidParams(`unknown config option: ${params.configId}`);
                }
                return { configOptions: await configOptions(record) };
            },

            async closeSession(params: CloseSessionRequest): Promise<void> {
                const record = sessions.get(params.sessionId);
                if (record === undefined) return;
                sessions.delete(params.sessionId);
                record.agent.cancel({ kind: "user" });
                settlePrompt(record, "cancelled");
                await record.dispose().catch((error: unknown) => {
                    logWarn(`session close failed: ${String(error)}`);
                });
            },

            cancel(params: CancelNotification): Promise<void> {
                const record = sessions.get(params.sessionId);
                if (record === undefined) return Promise.resolve();
                record.cancelled = true;
                record.agent.cancel({ kind: "user" });
                settlePrompt(record, "cancelled");
                return Promise.resolve();
            },
        };
    };

    function requirePersistence(): Context["sessionPersistence"] {
        return sessionPersistence;
    }

    function validateCwd(cwd: string): void {
        if (!isAbsolute(cwd)) throw invalidParams(`cwd must be an absolute path: ${cwd}`);
    }

    function validateAdditionalDirectories(additionalDirectories: string[] | undefined): void {
        if (additionalDirectories !== undefined && additionalDirectories.length > 0) {
            throw invalidParams("additionalDirectories is not supported");
        }
    }

    // ------------------------------------------------------------------ //
    // MCP servers (session mcpServers → dsh-mcp-client instances)         //
    // ------------------------------------------------------------------ //

    /**
     * Live mcp-client mounts by server name. ACP has no session/close, so a
     * mount lives until the process exits or a later session re-declares the
     * same name with a different config (the client edited its settings —
     * replace, so new sessions and the next turns of old ones see the new
     * server). Same name + same config is reused across sessions: clients
     * send one configured list to every session, and tool names
     * (`mcp__<name>__…`) stay stable for prompt caching.
     */
    const mcpMounts = new Map<string, { configJson: string; fiber: { dispose(): unknown } }>();
    let warnedNoMcpClient = false;

    /** mcp-client requires `[A-Za-z0-9_-]{1,32}`; ACP names are free-form. */
    const sanitizeServerName = (raw: string): string => {
        const cleaned = raw.replace(/[^A-Za-z0-9_-]/g, "_").slice(0, 32);
        return cleaned.length > 0 ? cleaned : "server";
    };

    /** Projects one ACP McpServer onto an mcp-client config, if supported. */
    const mcpConfigFor = (
        server: Record<string, unknown>,
        cwd: string,
        serverName: string,
    ): Record<string, unknown> | undefined => {
        const envList = (list: unknown): Record<string, string> =>
            Object.fromEntries(
                (Array.isArray(list) ? (list as { name: string; value: string }[]) : []).map((e) => [
                    e.name,
                    e.value,
                ]),
            );
        if (typeof server["command"] === "string") {
            return {
                transport: "stdio",
                serverName,
                command: server["command"],
                args: Array.isArray(server["args"]) ? server["args"] : [],
                env: envList(server["env"]),
                cwd: typeof server["cwd"] === "string" ? server["cwd"] : cwd,
                // A dead or misconfigured server must not take the session
                // down; the client surfaces missing tools on its own.
                failOnStartupError: false,
            };
        }
        if (server["type"] === "http" && typeof server["url"] === "string") {
            return {
                transport: "streamable-http",
                serverName,
                url: server["url"],
                headers: envList(server["headers"]),
                failOnStartupError: false,
            };
        }
        return undefined;
    };

    /** Mounts/reuses/replaces mcp-client instances for a session's server list. */
    const syncMcpServers = (servers: NewSessionRequest["mcpServers"] | undefined, cwd: string): void => {
        if (servers === undefined || servers.length === 0) return;
        const mcpClient = harness.mcpClient;
        if (mcpClient === undefined) {
            if (!warnedNoMcpClient) {
                warnedNoMcpClient = true;
                logWarn(
                    `ignoring ${servers.length} MCP server(s): this DeepSeek Harness installation lacks @deepseek-ai/dsh-mcp-client`,
                );
            }
            return;
        }
        const taken = new Set<string>();
        for (const entry of servers) {
            const server = entry as unknown as Record<string, unknown>;
            const base = sanitizeServerName(typeof server["name"] === "string" ? server["name"] : "server");
            let serverName = base;
            for (let n = 2; taken.has(serverName); n += 1) serverName = `${base.slice(0, 28)}_${n}`;
            const cfg = mcpConfigFor(server, cwd, serverName);
            if (cfg === undefined) {
                logWarn(`skipping MCP server "${serverName}": unsupported transport`);
                continue;
            }
            const configJson = JSON.stringify(cfg);
            const existing = mcpMounts.get(serverName);
            if (existing !== undefined) {
                if (existing.configJson === configJson) {
                    taken.add(serverName);
                    continue;
                }
                try {
                    void existing.fiber.dispose();
                } catch (error: unknown) {
                    logWarn(`disposing MCP server "${serverName}": ${String(error)}`);
                }
                mcpMounts.delete(serverName);
            }
            try {
                const fiber = (
                    ctx as unknown as { plugin(module: unknown, config: unknown): { dispose(): unknown } }
                ).plugin(mcpClient, cfg);
                mcpMounts.set(serverName, { configJson, fiber });
                taken.add(serverName);
                logDebug(`mounted MCP server "${serverName}" (${String(cfg["transport"])})`);
            } catch (error: unknown) {
                logWarn(`failed to mount MCP server "${serverName}": ${String(error)}`);
            }
        }
    };

    // ------------------------------------------------------------------ //
    // Transport wiring and teardown                                       //
    // ------------------------------------------------------------------ //

    // Complete fallible plugin setup before the SDK starts reading requests.
    // Cordis rolls back listeners on failure, but cannot stop an unowned SDK
    // connection that was already started (e.g. a legacy Web provider clash).
    await ctx.plugin(userQuestionsPlugin, {
        formSupported: () => clientElicitationForm,
        sessionIdForRequest: (request) => {
            if (request.agent === undefined) return undefined;
            const record = ownedRecord(request.agent);
            return record === undefined ? undefined : String(record.agent.session.id);
        },
        create: (request) => userQuestionsPlugin.createElicitation(conn, request),
    });

    let quiescing: Promise<void> | undefined;
    const quiesce = (): Promise<void> => {
        if (quiescing !== undefined) return quiescing;
        closed = true;
        const records = [...sessions.values()];
        sessions.clear();
        subagentByChild.clear();
        subagentByRun.clear();
        for (const record of records) {
            record.agent.cancel({ kind: "user" });
            settlePrompt(record, "cancelled");
        }
        quiescing = (async () => {
            // Continuable subagents (when composed) own descendant teardown;
            // drain them child-first before disposing the top-level agents.
            try {
                await subagents.drainContinuableDescendants(records.map((record) => record.agent));
            } catch (error: unknown) {
                logWarn(`continuable subagent teardown failed: ${String(error)}`);
            }
            const disposals = await Promise.allSettled(records.map((record) => record.dispose()));
            const failures = disposals.filter(
                (result): result is PromiseRejectedResult => result.status === "rejected",
            );
            if (failures.length > 0) {
                const detail = failures.map((failure) => errorChain(failure.reason)).join("; ");
                throw new AggregateError(
                    failures.map((failure) => failure.reason as unknown),
                    `ACP agent teardown failed for ${failures.length} session(s): ${detail}`,
                );
            }
        })();
        return quiescing;
    };

    ctx.effect(() => quiesce, "acp-bridge.connection");

    const raw: Stream =
        config.stream ??
        ndJsonStream(
            Writable.toWeb(process.stdout) as WritableStream<Uint8Array>,
            Readable.toWeb(process.stdin) as ReadableStream<Uint8Array>,
        );
    // The tap records inbound request ids for request-scoped url elicitation
    // (browser login during `authenticate`, which has no session).
    const stream = muxAcpStream(tapRequestIds(raw, requestIds), rpc);
    conn = new AgentSideConnection(makeAgent, stream);

    void conn.closed
        .catch((error: unknown) => {
            logWarn(`connection closed with an error: ${String(error)}`);
        })
        .then(quiesce)
        .catch((error: unknown) => {
            logWarn(`connection-close teardown failed: ${String(error)}`);
        });
}
