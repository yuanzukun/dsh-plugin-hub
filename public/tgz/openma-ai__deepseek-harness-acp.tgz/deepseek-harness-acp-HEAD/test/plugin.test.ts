import { fileURLToPath, pathToFileURL } from "node:url";
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterAll, describe, expect, it, vi } from "vitest";

const bridge = { inject: [] as string[] };
const server = { name: "acp-server" };

vi.mock("../src/bridge/index.ts", () => bridge);
vi.mock("../src/server.ts", () => server);

// Keep the legacy capability test independent of another local checkout:
// CI installs only the current dsh generation in this package's node_modules.
const legacyHost = mkdtempSync(join(tmpdir(), "dsh-acp-legacy-host-"));
for (const name of ["dsh-cordis-host-runner", "dsh-agent-presets"]) {
    const packageRoot = join(legacyHost, "node_modules", "@deepseek-ai", name);
    mkdirSync(join(packageRoot, "lib"), { recursive: true });
    writeFileSync(join(packageRoot, "package.json"), JSON.stringify({ name: `@deepseek-ai/${name}`, main: "lib/index.js" }));
    writeFileSync(join(packageRoot, "lib", "index.js"), "module.exports = {};\n");
    if (name === "dsh-agent-presets") mkdirSync(join(packageRoot, "presets"));
}
writeFileSync(join(legacyHost, "host.js"), "");

// A host dsh outside the supported range: plugin mode must refuse it with a
// clear message rather than failing deep inside the composition (#157).
const staleHost = mkdtempSync(join(tmpdir(), "dsh-acp-stale-host-"));
mkdirSync(join(staleHost, "node_modules", "@deepseek-ai", "dsh"), { recursive: true });
writeFileSync(
    join(staleHost, "node_modules", "@deepseek-ai", "dsh", "package.json"),
    JSON.stringify({ name: "@deepseek-ai/dsh", version: "0.1.1-rc.2" }),
);
writeFileSync(join(staleHost, "host.js"), "");
// A host dsh whose manifest carries no parseable version: refused as unknown.
const versionlessHost = mkdtempSync(join(tmpdir(), "dsh-acp-versionless-host-"));
mkdirSync(join(versionlessHost, "node_modules", "@deepseek-ai", "dsh"), { recursive: true });
writeFileSync(
    join(versionlessHost, "node_modules", "@deepseek-ai", "dsh", "package.json"),
    JSON.stringify({ name: "@deepseek-ai/dsh" }),
);
writeFileSync(join(versionlessHost, "host.js"), "");
afterAll(() => {
    rmSync(legacyHost, { recursive: true, force: true });
    rmSync(staleHost, { recursive: true, force: true });
    rmSync(versionlessHost, { recursive: true, force: true });
});

describe("embeddable ACP Host plugin", () => {
    it.each(["current", "legacy"] as const)("resolves %s Host preset capabilities", async (generation) => {
        const imports: string[] = [];
        const bases: string[] = [];
        const services = new Map<string, unknown>();
        const hostBase = generation === "current"
            ? new URL("../node_modules/@deepseek-ai/dsh/", import.meta.url).href
            : pathToFileURL(join(legacyHost, "host.js")).href;
        services.set("dshAcpHostBaseUrl", hostBase);
        const agentPresets = { name: "agent-presets" };
        const dynamicCordisRunner = { name: "dynamic-cordis-runner" };
        const subagentModelSelection = { name: "subagent-model-selection-settings" };
        const preset = { name: "agent-preset" };
        const loaded = [agentPresets, dynamicCordisRunner, subagentModelSelection, preset];
        const ctx = {
            baseUrl: import.meta.url,
            extend(meta: Record<string, unknown>) {
                return Object.assign(Object.create(this), meta);
            },
            get(name: string) {
                return services.get(name);
            },
            loader: {
                async import(specifier: string) {
                    imports.push(specifier);
                    if (specifier.includes("dsh-tool-subagent")) return subagentModelSelection;
                    if (specifier.includes("dsh-cordis-host-runner")) return dynamicCordisRunner;
                    if (specifier.includes("dsh-agent-preset-registry") || specifier.includes("dsh-agent-presets")) return agentPresets;
                    if (specifier.includes("dsh-agent-preset/")) return preset;
                    if (specifier.includes("dsh-app-boot")) return import("@deepseek-ai/dsh-app-boot");
                    throw new Error(`unexpected import: ${specifier}`);
                },
                unwrapExports(exports: unknown) {
                    return exports;
                },
            },
            async plugin(plugin: unknown) {
                if (loaded.includes(plugin as never)) bases.push(this.baseUrl);
                if (plugin === agentPresets) services.set("agentPresets", {});
                if (plugin === dynamicCordisRunner) services.set("dynamicCordisRunner", {});
                if (plugin === subagentModelSelection) services.set("subagentModelSelection", {});
                if ((plugin as { name?: string }).name === "acp-server") services.set("acpServer", {});
            },
        };
        const plugin = await import("../src/plugin.ts");

        await plugin.apply(ctx as never);

        expect(imports.every((specifier) => specifier.startsWith("file:"))).toBe(true);
        const names = imports.map((specifier) => fileURLToPath(specifier).replaceAll("\\", "/"));
        expect(names).toEqual(expect.arrayContaining([
            expect.stringMatching(/\/dsh-cordis-host-runner\/lib\/index\.js$/),
            expect.stringMatching(generation === "current"
                ? /\/dsh-agent-preset-registry\/lib\/index\.js$/
                : /\/dsh-agent-presets\/lib\/index\.js$/),
        ]));
        expect(names.some((name) => name.includes("dsh-agent-preset-registry"))).toBe(generation === "current");
        expect(names.some((name) => name.includes("dsh-tool-subagent"))).toBe(generation === "current");
        expect(services.has("acpServer")).toBe(true);
        expect(bases).toEqual(Array(generation === "current" ? 7 : 2).fill(hostBase));
    });

    it("refuses a host dsh outside the supported range, naming version, source and range", async () => {
        const services = new Map<string, unknown>();
        const ctx = {
            baseUrl: pathToFileURL(join(staleHost, "host.js")).href,
            get(name: string) {
                return services.get(name);
            },
            loader: {
                async import() {
                    throw new Error("no mount should be attempted for an incompatible host");
                },
                unwrapExports(exports: unknown) {
                    return exports;
                },
            },
            async plugin() {
                throw new Error("no mount should be attempted for an incompatible host");
            },
        };
        const plugin = await import("../src/plugin.ts");
        await expect(plugin.apply(ctx as never)).rejects.toThrow(/incompatible DeepSeek Harness/);
        await expect(plugin.apply(ctx as never)).rejects.toThrow(/0\.1\.1-rc\.2/);
        await expect(plugin.apply(ctx as never)).rejects.toThrow(/0\.1\.7-rc\.2 \|\| 0\.2\.0-rc\.1 \|\| 0\.2\.0-rc\.2/);
        await expect(plugin.apply(ctx as never)).rejects.toThrow(/dsh plugin host/);
    });

    it("reports an unversioned host dsh as 'unknown version' in the refusal", async () => {
        const services = new Map<string, unknown>();
        const ctx = {
            baseUrl: pathToFileURL(join(versionlessHost, "host.js")).href,
            get(name: string) {
                return services.get(name);
            },
            loader: {
                async import() {
                    throw new Error("no mount should be attempted for an incompatible host");
                },
                unwrapExports(exports: unknown) {
                    return exports;
                },
            },
            async plugin() {
                throw new Error("no mount should be attempted for an incompatible host");
            },
        };
        const plugin = await import("../src/plugin.ts");
        await expect(plugin.apply(ctx as never)).rejects.toThrow(/unknown version/);
        await expect(plugin.apply(ctx as never)).rejects.toThrow(/incompatible DeepSeek Harness/);
    });

    it("falls back to the module's own url when the context carries no baseUrl", async () => {
        const services = new Map<string, unknown>();
        const ctx = {
            get(name: string) {
                return services.get(name);
            },
            loader: {
                async import(specifier: string) {
                    throw new Error(`stop after the gate: ${specifier}`);
                },
                unwrapExports(exports: unknown) {
                    return exports;
                },
            },
            async plugin() {
                throw new Error("stop after the gate");
            },
        };
        const plugin = await import("../src/plugin.ts");
        // baseUrl is absent: the check anchors on import.meta.url, which
        // resolves this repo's supported @deepseek-ai/dsh — so the failure
        // comes from the mount path, never the compatibility refusal.
        await expect(plugin.apply(ctx as never)).rejects.not.toThrow(/incompatible DeepSeek Harness/);
    });

    it("mounts only the ACP server when the surface already provides agentPresets and dynamicCordisRunner", async () => {
        // dsh 0.1.2-era surfaces (and profiles that carry the ACP bundle rows)
        // already supply both Host services; the fallback mount must be skipped
        // entirely so its preset-root discovery can never run or fail.
        const imports: string[] = [];
        const services = new Map<string, unknown>();
        const ctx = {
            baseUrl: import.meta.url,
            get(name: string) {
                return services.get(name);
            },
            loader: {
                async import(specifier: string) {
                    imports.push(specifier);
                    throw new Error(`unexpected fallback import of ${specifier}`);
                },
                unwrapExports(exports: unknown) {
                    return exports;
                },
            },
            async plugin(plugin: unknown) {
                if ((plugin as { name?: string }).name === "acp-server") services.set("acpServer", {});
            },
        };
        services.set("agentPresets", {});
        services.set("dynamicCordisRunner", {});
        services.set("subagentModelSelection", {});
        const plugin = await import("../src/plugin.ts");

        await plugin.apply(ctx as never);

        expect(imports).toEqual([]);
        expect(services.has("acpServer")).toBe(true);
    });
});
