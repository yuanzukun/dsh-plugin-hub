import { readFileSync } from "node:fs";
import { join } from "node:path";
import semver from "semver";
import { describe, expect, it } from "vitest";

describe("ACP package manifest", () => {
    it("keeps Host dsh out of npm resolution while publishing a locked standalone runtime", () => {
        const manifest = JSON.parse(readFileSync(join(import.meta.dirname, "../package.json"), "utf8")) as {
            dependencies?: Record<string, string>;
            devDependencies?: Record<string, string>;
            peerDependencies?: Record<string, string>;
            peerDependenciesMeta?: Record<string, { optional?: boolean }>;
            exports?: Record<string, string>;
            files?: string[];
            scripts?: Record<string, string>;
            bin?: Record<string, string>;
            dshAcp?: {
                standaloneDsh?: string;
                hostCompatibility?: { cordisProtocol?: number; policy?: string };
            };
        };
        expect(manifest.dependencies).toEqual({
            "@agentclientprotocol/sdk": "2.0.2",
            semver: "^7.8.5",
            tar: "7.5.22",
            yaml: "^2.9.1",
            zod: "4.4.3",
        });
        expect(manifest.dependencies).not.toHaveProperty("@deepseek-ai/dsh");
        // The declared compatibility range is a real semver union of the tested
        // profile matrix (runtime/compatibility.json), enforced at resolution
        // time by src/harness.ts and at mount time by src/plugin.ts.
        const compatibility = JSON.parse(
            readFileSync(join(import.meta.dirname, "../runtime/compatibility.json"), "utf8"),
        ) as string[];
        // A minimum-version floor, mirrored in engines.dsh (what dsh's own
        // plugin loader reads), never an exact-version allow-list.
        const floor = (manifest as { engines?: Record<string, string> }).engines?.["dsh"];
        expect(floor).toMatch(/^>=\d+\.\d+\.\d+(?:-rc\.\d+)?$/);
        for (const version of compatibility) expect(semver.satisfies(version, floor!, { includePrerelease: true })).toBe(true);
        // No @deepseek-ai/dsh peer: npm/pnpm evaluate peers without
        // prereleases, so a peer floor would reject every dsh prerelease.
        expect(manifest.peerDependencies?.["@deepseek-ai/dsh"]).toBeUndefined();
        expect(manifest.peerDependenciesMeta?.["@deepseek-ai/dsh"]).toBeUndefined();
        expect(manifest.exports?.["./plugin"]).toBe("./dist/plugin.js");
        expect(manifest.bin?.["dsh-acp"]).toBe("dist/bin.js");
        expect(manifest.files).toEqual(expect.arrayContaining(["vendor/*.json", "vendor/*.tgz"]));
        expect(manifest.scripts?.["prepack"]).toContain("runtime:pack");
        expect(manifest.dshAcp?.standaloneDsh).toMatch(/^\d+\.\d+\.\d+(?:-rc\.\d+)?$/);
        expect(manifest.dshAcp?.hostCompatibility).toEqual({ cordisProtocol: 0, policy: "capability-negotiated" });

        // Most @deepseek-ai/dsh* pins track standaloneDsh. Some packages lag the
        // CLI release when npm never published that version (e.g. dsh-invariants
        // stopped at 0.2.0-rc.2) — scripts/update-dsh.mjs keeps those older pins.
        const standalone = manifest.dshAcp?.standaloneDsh;
        const dshDevelopmentPins = Object.entries(manifest.devDependencies ?? {})
            .filter(([name]) => name === "@deepseek-ai/dsh" || name.startsWith("@deepseek-ai/dsh-"));
        expect(dshDevelopmentPins.some(([, range]) => range === standalone)).toBe(true);
        for (const [name, range] of dshDevelopmentPins) {
            if (range === standalone) continue;
            expect(semver.valid(range), `${name} pin ${range} must be an exact version`).toBeTruthy();
            // lt/compare ignore includePrerelease (RangeOptions only); prerelease
            // ordering is already part of the SemVer compare algorithm.
            expect(
                semver.lt(range, standalone!),
                `${name}@${range} must be older than standaloneDsh ${standalone}`,
            ).toBe(true);
        }

        const runtime = JSON.parse(readFileSync(join(import.meta.dirname, "../runtime/package.json"), "utf8")) as {
            dependencies?: Record<string, string>;
        };
        expect(runtime.dependencies?.["@deepseek-ai/dsh"]).toBe(manifest.dshAcp?.standaloneDsh);

        // External native packages are pruned from the bundled runtime and redeclared
        // as optionalDependencies so npm installs the host platform binary. Keep the
        // pins exact matches of the versions locked under runtime/package-lock.json
        // (scripts/pack-runtime.mjs asserts the same at pack time).
        const runtimeLock = JSON.parse(
            readFileSync(join(import.meta.dirname, "../runtime/package-lock.json"), "utf8"),
        ) as { packages?: Record<string, { optional?: boolean; version?: string }> };
        const external: Record<string, string> = {};
        for (const [pkgPath, pkg] of Object.entries(runtimeLock.packages ?? {})) {
            if (!pkg.optional || typeof pkg.version !== "string") continue;
            if (
                !pkgPath.startsWith("node_modules/@deepseek-ai/libreoffice-kit-")
                && !pkgPath.startsWith("node_modules/sherpa-onnx-")
            ) continue;
            const name = pkgPath.slice("node_modules/".length);
            if (name.startsWith("@") ? name.split("/").length !== 2 : name.includes("/")) continue;
            external[name] = pkg.version;
        }
        expect((manifest as { optionalDependencies?: Record<string, string> }).optionalDependencies)
            .toEqual(external);
    });
});
