/**
 * End-to-end smoke test: boots the real dsh-acp server (full harness
 * composition) as a child process and speaks ACP over its stdio.
 *
 * No model calls are made: session/new only constructs an agent, and the
 * /status prompt is intercepted by the adapter before it would reach the
 * model. A dummy DEEPSEEK_API_KEY plus a fake DEEPSEEK_BASE_URL satisfy
 * the credential gate without ever dialing a provider.
 */

import { createHash } from "node:crypto";
import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, statSync, symlinkSync, writeFileSync } from "node:fs";
import { zstdDecompressSync } from "node:zlib";
import { tmpdir } from "node:os";
import { createServer, type Server, type ServerResponse } from "node:http";
import { delimiter, join } from "node:path";
import { afterAll, beforeAll, describe, expect, it } from "vitest";

const ROOT = join(import.meta.dirname, "..");

function mockModelStream(text: string, path: string | undefined): string {
    if (!path?.endsWith("/messages")) {
        return [
            { id: "acp-test", object: "chat.completion.chunk", choices: [{ index: 0, delta: { role: "assistant", content: text }, finish_reason: null }] },
            { id: "acp-test", object: "chat.completion.chunk", choices: [{ index: 0, delta: {}, finish_reason: "stop" }] },
        ].map((chunk) => `data: ${JSON.stringify(chunk)}\n\n`).join("") + "data: [DONE]\n\n";
    }
    return [
        { type: "message_start", message: { usage: { input_tokens: 10, output_tokens: 0 } } },
        { type: "content_block_start", index: 0, content_block: { type: "text", text: "" } },
        { type: "content_block_delta", index: 0, delta: { type: "text_delta", text } },
        { type: "content_block_stop", index: 0 },
        { type: "message_delta", delta: { stop_reason: "end_turn" }, usage: { output_tokens: 3 } },
        { type: "message_stop" },
    ].map((event) => `event: ${event.type}\ndata: ${JSON.stringify(event)}\n\n`).join("");
}

function mockSubagentToolStream(name: "subagent" | "subagent_fork"): string {
    return [
        { type: "message_start", message: { usage: { input_tokens: 10, output_tokens: 0 } } },
        {
            type: "content_block_start",
            index: 0,
            content_block: {
                type: "tool_use",
                id: `call-${name}`,
                name,
                input: { description: `${name} child`, prompt: "Reply as the child", run_in_background: false },
            },
        },
        { type: "content_block_stop", index: 0 },
        { type: "message_delta", delta: { stop_reason: "tool_use" }, usage: { output_tokens: 3 } },
        { type: "message_stop" },
    ].map((event) => `event: ${event.type}\ndata: ${JSON.stringify(event)}\n\n`).join("");
}

function mockToolUseStream(command: string, name = "bash"): string {
    return [
        { type: "message_start", message: { usage: { input_tokens: 10, output_tokens: 0 } } },
        { type: "content_block_start", index: 0, content_block: { type: "tool_use", id: "live-command-call", name, input: { command, description: "Print output before and after a pause" } } },
        { type: "content_block_stop", index: 0 },
        { type: "message_delta", delta: { stop_reason: "tool_use" }, usage: { output_tokens: 3 } },
        { type: "message_stop" },
    ].map((event) => `event: ${event.type}\ndata: ${JSON.stringify(event)}\n\n`).join("");
}

function countSentText(body: string, needle: string): number {
    const payload = JSON.parse(body) as { messages?: Array<{ content?: unknown }> };
    const sent = (payload.messages ?? []).flatMap((message) => {
        if (typeof message.content === "string") return [message.content];
        if (!Array.isArray(message.content)) return [];
        return message.content.flatMap((block: unknown) =>
            block !== null && typeof block === "object" && typeof (block as { text?: unknown }).text === "string"
                ? [(block as { text: string }).text] : []);
    }).join("\n");
    return sent.split(needle).length - 1;
}

interface Pending {
    resolve: (value: unknown) => void;
    reject: (error: Error) => void;
}

class AcpTestClient {
    private child: ChildProcessWithoutNullStreams;
    private nextId = 1;
    private pending = new Map<number, Pending>();
    readonly notifications: Array<{ method: string; params: Record<string, unknown> }> = [];
    private buffer = "";
    private stderr = "";
    private closePromise?: Promise<void>;

    constructor(
        sessionRoot: string,
        workspace: string,
        dshPath?: string,
        envPatch?: Record<string, string | undefined>,
        serverArgs: string[] = [],
    ) {
        const env: Record<string, string | undefined> = {
            ...process.env,
            DEEPSEEK_API_KEY: "sk-test-e2e-not-a-real-key",
            DEEPSEEK_BASE_URL: "http://127.0.0.1:1", // credential gate only; never dialed
            DSH_SESSION_ROOT: sessionRoot,
            DSH_HOME: join(sessionRoot, "home"),
            DSH_ACP_WORKSPACE: workspace,
            // Host-default tests must not inherit the developer shell's
            // explicit per-process override.
            DSH_PERMISSION_MODE: undefined,
            // The dev checkout's own node_modules is the explicit host for
            // e2e; without it the launcher would (correctly) use only the
            // packaged runtime, which isn't installed in a checkout.
            DSH_PATH: dshPath ?? ROOT,
            ...(envPatch ?? {}),
        };
        for (const [key, value] of Object.entries(env)) if (value === undefined) delete env[key];
        this.child = spawn(process.execPath, ["--import", "tsx", "src/bin.ts", ...serverArgs], {
            cwd: ROOT,
            env: env as Record<string, string>,
            stdio: ["pipe", "pipe", "pipe"],
        });
        this.child.stdout.setEncoding("utf8");
        this.child.stderr.setEncoding("utf8");
        this.child.stderr.on("data", (chunk: string) => {
            this.stderr += chunk;
        });
        this.child.on("exit", (code, signal) => {
            if (this.pending.size === 0) return;
            const error = new Error(
                `dsh-acp exited before replying (code ${String(code)}, signal ${String(signal)})\n`
                    + `stderr:\n${this.stderr.slice(-2000)}`,
            );
            for (const pending of this.pending.values()) pending.reject(error);
            this.pending.clear();
        });
        this.child.stdout.on("data", (chunk: string) => {
            this.buffer += chunk;
            let index = this.buffer.indexOf("\n");
            while (index >= 0) {
                const line = this.buffer.slice(0, index).trim();
                this.buffer = this.buffer.slice(index + 1);
                if (line.length > 0) this.dispatch(line);
                index = this.buffer.indexOf("\n");
            }
        });
    }

    private dispatch(line: string): void {
        let message: Record<string, unknown>;
        try {
            message = JSON.parse(line) as Record<string, unknown>;
        } catch {
            return;
        }
        const id = message["id"];
        if (typeof id === "number" && this.pending.has(id)) {
            const pending = this.pending.get(id);
            this.pending.delete(id);
            if (message["error"] !== undefined && message["error"] !== null) {
                const error = message["error"] as { code?: number; message?: string; data?: unknown };
                const detail = error.data === undefined ? "" : ` — ${JSON.stringify(error.data)}`;
                pending?.reject(Object.assign(
                    new Error(`${error.message ?? "JSON-RPC error"}${detail}`),
                    { code: error.code },
                ));
            } else {
                pending?.resolve(message["result"]);
            }
            return;
        }
        const method = message["method"];
        if (typeof method === "string") {
            this.notifications.push({
                method,
                params: (message["params"] as Record<string, unknown>) ?? {},
            });
        }
    }

    request(method: string, params: unknown, timeoutMs = 30_000): Promise<unknown> {
        const id = this.nextId;
        this.nextId += 1;
        const promise = new Promise<unknown>((resolve, reject) => {
            this.pending.set(id, { resolve, reject });
            setTimeout(() => {
                if (this.pending.delete(id)) {
                    reject(new Error(`${method} timed out\nstderr:\n${this.stderr.slice(-2000)}`));
                }
            }, timeoutMs).unref();
        });
        this.child.stdin.write(`${JSON.stringify({ jsonrpc: "2.0", id, method, params })}\n`);
        return promise;
    }

    notify(method: string, params: unknown): void {
        this.child.stdin.write(`${JSON.stringify({ jsonrpc: "2.0", method, params })}\n`);
    }

    updatesFor(sessionId: string): Array<Record<string, unknown>> {
        return this.notifications
            .filter(
                (notification) =>
                    notification.method === "session/update" && notification.params["sessionId"] === sessionId,
            )
            .map((notification) => notification.params["update"] as Record<string, unknown>);
    }


    async crash(): Promise<void> {
        if (this.child.exitCode !== null || this.child.signalCode !== null) return;
        await new Promise<void>((resolve) => {
            this.child.once("exit", () => resolve());
            this.child.kill("SIGKILL");
        });
        this.closePromise = Promise.resolve();
    }

    async close(): Promise<void> {
        if (this.closePromise !== undefined) return this.closePromise;
        this.child.stdin.end();
        this.closePromise = new Promise<void>((resolve) => {
            const timer = setTimeout(() => {
                this.child.kill("SIGKILL");
                resolve();
            }, 5000);
            this.child.on("exit", () => {
                clearTimeout(timer);
                resolve();
            });
        });
        return this.closePromise;
    }
}

describe("dsh-acp bundle overlays", () => {
    let client: AcpTestClient;
    const roots: string[] = [];

    function testBundle(name: string): { root: string; marker: string } {
        const root = mkdtempSync(join(tmpdir(), "dsh-acp-bundle-"));
        roots.push(root);
        const marker = join(root, "activated.txt");
        writeFileSync(join(root, "package.json"), JSON.stringify({
            name,
            type: "module",
            main: "./index.js",
            dsh: { bundle: { patch: "./cordis.patch.yml" } },
        }));
        writeFileSync(
            join(root, "cordis.patch.yml"),
            JSON.stringify([{
                insert: [{ id: `${name}-marker`, name, config: { marker } }],
            }]),
        );
        writeFileSync(
            join(root, "index.js"),
            "import { writeFileSync } from 'node:fs'\n"
                + "export function apply(_ctx, config) { writeFileSync(config.marker, 'active') }\n",
        );
        return { root, marker };
    }

    afterAll(async () => {
        await client?.close();
        for (const root of roots) rmSync(root, { recursive: true, force: true });
    });

    it("activates every bundle supplied on the command line", async () => {
        const sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-bundle-sessions-"));
        const workspace = mkdtempSync(join(tmpdir(), "dsh-acp-bundle-workspace-"));
        roots.push(sessionRoot, workspace);
        const first = testBundle("dsh-acp-test-first");
        const second = testBundle("dsh-acp-test-second");
        client = new AcpTestClient(
            sessionRoot,
            workspace,
            undefined,
            undefined,
            ["--bundle", first.root, "--bundle", second.root],
        );

        await client.request("initialize", { protocolVersion: 1 }, 60_000);
        expect(existsSync(first.marker)).toBe(true);
        expect(existsSync(second.marker)).toBe(true);
    }, 90_000);
});

describe("dsh-acp live command catalogue", () => {
    let client: AcpTestClient;
    const roots: string[] = [];

    afterAll(async () => {
        await client?.close();
        for (const root of roots) rmSync(root, { recursive: true, force: true });
    });

    it("republishes commands registered after session creation", async () => {
        const sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-command-change-sessions-"));
        const workspace = mkdtempSync(join(tmpdir(), "dsh-acp-command-change-workspace-"));
        const bundle = mkdtempSync(join(tmpdir(), "dsh-acp-command-change-bundle-"));
        const trigger = join(bundle, "register-late-command");
        roots.push(sessionRoot, workspace, bundle);
        writeFileSync(join(bundle, "package.json"), JSON.stringify({
            name: "dsh-acp-test-command-change",
            type: "module",
            main: "./index.js",
            dsh: { bundle: { patch: "./cordis.patch.yml" } },
        }));
        writeFileSync(join(bundle, "cordis.patch.yml"), JSON.stringify([{
            insert: [{
                id: "dsh-acp-test-command-change",
                name: "dsh-acp-test-command-change",
                config: { trigger },
            }],
        }]));
        writeFileSync(join(bundle, "index.js"), [
            "import { existsSync } from 'node:fs'",
            "export const inject = ['agents']",
            "export function apply(ctx, config) {",
            "  const timers = new Set()",
            "  ctx.on('agent/created', ({ agent }) => {",
            "    const timer = setInterval(() => {",
            "      if (!existsSync(config.trigger)) return",
            "      clearInterval(timer)",
            "      timers.delete(timer)",
            "      agent.ctx.inject(['commands'], commandCtx => commandCtx.commands.register({",
            "        name: 'late-fixture-command',",
            "        description: 'Registered after the ACP session snapshot',",
            "        handler: () => ({ kind: 'success', text: 'late command ready' }),",
            "      }))",
            "    }, 20)",
            "    timers.add(timer)",
            "  })",
            "  ctx.effect(() => () => { for (const timer of timers) clearInterval(timer) })",
            "}",
        ].join("\n"));

        client = new AcpTestClient(
            sessionRoot,
            workspace,
            undefined,
            undefined,
            ["--bundle", bundle],
        );
        await client.request("initialize", { protocolVersion: 1 }, 60_000);
        const created = await client.request("session/new", { cwd: workspace, mcpServers: [] }) as {
            sessionId: string;
        };

        let initialNames: string[] = [];
        for (let attempt = 0; attempt < 80; attempt += 1) {
            const update = [...client.updatesFor(created.sessionId)]
                .reverse()
                .find((entry) => entry["sessionUpdate"] === "available_commands_update");
            initialNames = ((update?.["availableCommands"] ?? []) as Array<{ name: string }>).map(({ name }) => name);
            if (initialNames.length > 0) break;
            await new Promise((resolve) => setTimeout(resolve, 25));
        }
        expect(initialNames).not.toContain("late-fixture-command");

        writeFileSync(trigger, "register");
        let liveNames = initialNames;
        for (let attempt = 0; attempt < 120; attempt += 1) {
            const update = [...client.updatesFor(created.sessionId)]
                .reverse()
                .find((entry) => entry["sessionUpdate"] === "available_commands_update");
            liveNames = ((update?.["availableCommands"] ?? []) as Array<{ name: string }>).map(({ name }) => name);
            if (liveNames.includes("late-fixture-command")) break;
            await new Promise((resolve) => setTimeout(resolve, 25));
        }
        expect(liveNames).toContain("late-fixture-command");
    }, 90_000);
});

describe("dsh-acp Host-owned defaults", () => {
    const roots: string[] = [];
    const clients: AcpTestClient[] = [];

    afterAll(async () => {
        await Promise.all(clients.map((entry) => entry.close()));
        for (const root of roots) rmSync(root, { recursive: true, force: true });
    });

    it("materializes the Host default route on the parent agent for subagent inheritance", async () => {
        const sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-inherited-model-sessions-"));
        const workspace = mkdtempSync(join(tmpdir(), "dsh-acp-inherited-model-workspace-"));
        const bundle = mkdtempSync(join(tmpdir(), "dsh-acp-inherited-model-bundle-"));
        const marker = join(bundle, "agent-options.json");
        roots.push(sessionRoot, workspace, bundle);

        const harnessHome = join(sessionRoot, "home");
        mkdirSync(harnessHome, { recursive: true });
        writeFileSync(
            join(harnessHome, "settings.yaml"),
            "agent-default-model:\n  provider: deepseek-official\n  model: deepseek-v4-pro\n",
        );
        writeFileSync(join(bundle, "package.json"), JSON.stringify({
            name: "dsh-acp-test-agent-options",
            type: "module",
            main: "./index.js",
            dsh: { bundle: { patch: "./cordis.patch.yml" } },
        }));
        writeFileSync(join(bundle, "cordis.patch.yml"), JSON.stringify([{
            insert: [{
                id: "dsh-acp-test-agent-options",
                name: "dsh-acp-test-agent-options",
                config: { marker },
            }],
        }]));
        writeFileSync(join(bundle, "index.js"), [
            "import { writeFileSync } from 'node:fs'",
            "export const inject = ['agents']",
            "export function apply(ctx, config) {",
            "  ctx.on('agent/created', ({ agent }) => {",
            "    if (agent.session.header.parentSession === undefined) {",
            "      writeFileSync(config.marker, JSON.stringify(agent.options))",
            "    }",
            "  })",
            "}",
        ].join("\n"));

        const client = new AcpTestClient(
            sessionRoot,
            workspace,
            undefined,
            undefined,
            ["--bundle", bundle],
        );
        clients.push(client);

        await client.request("initialize", { protocolVersion: 1 }, 60_000);
        await client.request("session/new", { cwd: workspace, mcpServers: [] });

        expect(JSON.parse(readFileSync(marker, "utf8")))
            .toMatchObject({ provider: "deepseek-official", model: "deepseek-v4-pro" });
    }, 90_000);

    it("saves the selected model and effort as the default for later sessions", async () => {
        const sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-default-model-sessions-"));
        const workspace = mkdtempSync(join(tmpdir(), "dsh-acp-default-model-workspace-"));
        roots.push(sessionRoot, workspace);
        const client = new AcpTestClient(sessionRoot, workspace);
        clients.push(client);

        await client.request("initialize", { protocolVersion: 1 }, 60_000);
        const first = (await client.request("session/new", {
            cwd: workspace,
            mcpServers: [],
        })) as { sessionId: string };
        await client.request("session/set_config_option", {
            sessionId: first.sessionId,
            configId: "model",
            value: "deepseek-v4-pro",
        });
        await client.request("session/set_config_option", {
            sessionId: first.sessionId,
            configId: "effort",
            value: "max",
        });

        const later = (await client.request("session/new", {
            cwd: workspace,
            mcpServers: [],
        })) as { configOptions: Array<Record<string, unknown>> };
        const options = new Map(later.configOptions.map((option) => [option["id"], option]));
        expect((options.get("model")?.["currentValue"] as string).split("::").at(-1)).toBe("deepseek-v4-pro");
        expect(options.get("effort")).toMatchObject({ currentValue: "max" });
    }, 90_000);

    it("keeps model option ids stable while switches move the default provider (#24)", async () => {
        const sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-model-ids-sessions-"));
        const workspace = mkdtempSync(join(tmpdir(), "dsh-acp-model-ids-workspace-"));
        const bundle = mkdtempSync(join(tmpdir(), "dsh-acp-model-ids-bundle-"));
        roots.push(sessionRoot, workspace, bundle);

        // A second, catalog-only provider: enough for switching (no request
        // is ever streamed), and it serves an id the default provider also has.
        writeFileSync(join(bundle, "package.json"), JSON.stringify({
            name: "dsh-acp-test-acme-provider",
            type: "module",
            main: "./index.js",
            dsh: { bundle: { patch: "./cordis.patch.yml" } },
        }));
        writeFileSync(join(bundle, "cordis.patch.yml"), JSON.stringify([{
            insert: [{ id: "dsh-acp-test-acme-provider", name: "dsh-acp-test-acme-provider" }],
        }]));
        writeFileSync(join(bundle, "index.js"), [
            "import { LlmAdapter } from '@deepseek-ai/dsh-llm'",
            "class AcmeAdapter extends LlmAdapter {",
            "  providerInfo(provider) { return { id: provider, name: 'Acme Gateway' } }",
            "  listModels(provider) {",
            "    return Promise.resolve([",
            "      { provider, id: 'deepseek-v4-pro', name: 'DeepSeek V4 Pro via Acme' },",
            "      { provider, id: 'acme-think', name: 'Acme Think' },",
            "    ])",
            "  }",
            "  async *stream() { throw new Error('acme is a catalog-only test provider') }",
            "}",
            "export const inject = ['llm']",
            "export function apply(ctx) { ctx.llm.registerAdapter(['acme'], new AcmeAdapter()) }",
        ].join("\n"));

        const client = new AcpTestClient(sessionRoot, workspace, undefined, undefined, ["--bundle", bundle]);
        clients.push(client);
        await client.request("initialize", { protocolVersion: 1 }, 60_000);

        const modelOption = (response: unknown): { currentValue: string; values: string[] } => {
            const options = (response as { configOptions: Array<Record<string, unknown>> }).configOptions;
            const option = options.find((entry) => entry["id"] === "model") as
                | { currentValue: string; options: Array<{ value: string }> }
                | undefined;
            expect(option).toBeDefined();
            return { currentValue: option!.currentValue, values: option!.options.map((entry) => entry.value) };
        };
        const setModel = (sessionId: string, value: string) =>
            client.request("session/set_config_option", { sessionId, configId: "model", value });

        const first = (await client.request("session/new", { cwd: workspace, mcpServers: [] })) as {
            sessionId: string;
        };
        const initial = modelOption(first);
        // Two providers: every value is fully qualified, none depends on the default.
        expect(initial.currentValue).toMatch(/^deepseek-official::/);
        for (const value of initial.values) expect(value).toMatch(/^[^:]+::./);
        expect(initial.values).toEqual(expect.arrayContaining([
            "deepseek-official::deepseek-v4-pro",
            "acme::deepseek-v4-pro",
            "acme::acme-think",
        ]));

        // Switching to the other provider rewrites the product default…
        expect(modelOption(await setModel(first.sessionId, "acme::acme-think")).currentValue).toBe("acme::acme-think");

        // …and a later session still lists the very same ids.
        const second = (await client.request("session/new", { cwd: workspace, mcpServers: [] })) as {
            sessionId: string;
        };
        const later = modelOption(second);
        expect(later.currentValue).toBe("acme::acme-think");
        expect(new Set(later.values)).toEqual(new Set(initial.values));

        // The ids that worked before the default moved keep working after it.
        expect(modelOption(await setModel(second.sessionId, "acme::acme-think")).currentValue).toBe("acme::acme-think");
        expect(modelOption(await setModel(second.sessionId, "deepseek-official::deepseek-v4-pro")).currentValue)
            .toBe("deepseek-official::deepseek-v4-pro");

        // Bare ids (older clients) resolve to the provider that serves them:
        // the default when it does, otherwise the unique owner.
        expect(modelOption(await setModel(second.sessionId, "acme-think")).currentValue).toBe("acme::acme-think");
        expect(modelOption(await setModel(second.sessionId, "deepseek-v4-pro")).currentValue).toBe("acme::deepseek-v4-pro");
        await expect(setModel(second.sessionId, "acme::nope")).rejects.toThrow(/unknown model/);

        await expect(client.request("session/prompt", {
            sessionId: second.sessionId,
            prompt: [{ type: "text", text: "/status" }],
        })).resolves.toMatchObject({ stopReason: "end_turn" });
        const status = client.updatesFor(second.sessionId).find(
            (update) =>
                update["sessionUpdate"] === "agent_message_chunk" &&
                (update["content"] as { text?: string } | undefined)?.text?.includes("**dsh-acp**"),
        );
        expect((status?.["content"] as { text: string }).text).toContain("| Provider | acme |");
        expect((status?.["content"] as { text: string }).text).toContain("| Model | deepseek-v4-pro |");
    }, 120_000);

    it("restores the selected permission after the ACP Host restarts", async () => {
        const sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-default-permission-switch-sessions-"));
        const workspace = mkdtempSync(join(tmpdir(), "dsh-acp-default-permission-switch-workspace-"));
        roots.push(sessionRoot, workspace);
        const client = new AcpTestClient(sessionRoot, workspace);
        clients.push(client);

        await client.request("initialize", { protocolVersion: 1 }, 60_000);
        const first = (await client.request("session/new", {
            cwd: workspace,
            mcpServers: [],
        })) as { sessionId: string };
        await client.request("session/set_mode", {
            sessionId: first.sessionId,
            modeId: "danger-full-access",
        });
        await client.close();

        const restarted = new AcpTestClient(sessionRoot, workspace);
        clients.push(restarted);
        await restarted.request("initialize", { protocolVersion: 1 }, 60_000);
        const later = (await restarted.request("session/new", {
            cwd: workspace,
            mcpServers: [],
        })) as Record<string, unknown>;
        expect(later["modes"]).toMatchObject({ currentModeId: "danger-full-access" });
        const options = new Map(
            (later["configOptions"] as Array<Record<string, unknown>>)
                .map((option) => [option["id"], option]),
        );
        expect(options.get("mode")).toMatchObject({ currentValue: "danger-full-access" });
        const availableModes = (later["modes"] as { availableModes: Array<Record<string, unknown>> })
            .availableModes;
        expect(availableModes.every((mode) =>
            typeof mode["name"] === "string" && mode["name"].length > 0,
        )).toBe(true);
        const modeChoices = (options.get("mode")?.["options"] ?? []) as Array<Record<string, unknown>>;
        expect(modeChoices.every((choice) =>
            typeof choice["name"] === "string" && choice["name"].length > 0,
        )).toBe(true);
    }, 90_000);

    it("starts a new session from the Host permission default", async () => {
        const sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-default-permission-sessions-"));
        const workspace = mkdtempSync(join(tmpdir(), "dsh-acp-default-permission-workspace-"));
        roots.push(sessionRoot, workspace);
        const harnessHome = join(sessionRoot, "home");
        mkdirSync(harnessHome, { recursive: true });
        writeFileSync(join(harnessHome, "settings.yaml"), "permission:\n  defaultPreset: read-only\n");
        const client = new AcpTestClient(sessionRoot, workspace);
        clients.push(client);

        await client.request("initialize", { protocolVersion: 1 }, 60_000);
        const created = (await client.request("session/new", {
            cwd: workspace,
            mcpServers: [],
        })) as Record<string, unknown>;
        expect(created["modes"]).toMatchObject({ currentModeId: "read-only" });
        const options = new Map(
            (created["configOptions"] as Array<Record<string, unknown>>)
                .map((option) => [option["id"], option]),
        );
        expect(options.get("mode")).toMatchObject({ currentValue: "read-only" });
    }, 90_000);

    it("does not let a stale installed ACP profile override the standalone Host defaults", async () => {
        const sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-stale-profile-sessions-"));
        const workspace = mkdtempSync(join(tmpdir(), "dsh-acp-stale-profile-workspace-"));
        roots.push(sessionRoot, workspace);
        const harnessHome = join(sessionRoot, "home");
        const staleProfile = join(harnessHome, "profiles", "acp");
        mkdirSync(staleProfile, { recursive: true });
        writeFileSync(
            join(staleProfile, "package.json"),
            JSON.stringify({
                name: "stale-acp-profile",
                private: true,
                dependencies: { "@openma/deepseek-harness-acp": "0.0.1" },
                dsh: { profile: { bundles: ["definitely-missing-stale-acp-bundle"] } },
            }),
        );
        writeFileSync(join(staleProfile, "cordis.yml"), "[]\n");
        writeFileSync(join(staleProfile, "cordis.patch.yml"), "[]\n");
        writeFileSync(
            join(harnessHome, "settings.yaml"),
            "permission:\n  defaultPreset: danger-full-access\n",
        );

        const client = new AcpTestClient(sessionRoot, workspace);
        clients.push(client);
        await client.request("initialize", { protocolVersion: 1 }, 60_000);
        const created = (await client.request("session/new", {
            cwd: workspace,
            mcpServers: [],
        })) as Record<string, unknown>;

        expect(created["modes"]).toMatchObject({ currentModeId: "danger-full-access" });
    }, 90_000);

    it("lets an explicit CLI permission override the Host default", async () => {
        const sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-explicit-permission-sessions-"));
        const workspace = mkdtempSync(join(tmpdir(), "dsh-acp-explicit-permission-workspace-"));
        roots.push(sessionRoot, workspace);
        const harnessHome = join(sessionRoot, "home");
        mkdirSync(harnessHome, { recursive: true });
        writeFileSync(join(harnessHome, "settings.yaml"), "permission:\n  defaultPreset: read-only\n");
        const client = new AcpTestClient(
            sessionRoot,
            workspace,
            undefined,
            undefined,
            ["--permission-mode", "danger-full-access"],
        );
        clients.push(client);

        await client.request("initialize", { protocolVersion: 1 }, 60_000);
        const created = (await client.request("session/new", {
            cwd: workspace,
            mcpServers: [],
        })) as Record<string, unknown>;
        expect(created["modes"]).toMatchObject({ currentModeId: "danger-full-access" });
    }, 90_000);
});

describe("live tool output", () => {
    it("sends bash output before the command finishes", async () => {
        const root = mkdtempSync(join(tmpdir(), "dsh-acp-live-output-"));
        const workspace = mkdtempSync(join(tmpdir(), "dsh-acp-live-workspace-"));
        let agentCalls = 0;
        const provider = createServer(async (request, response) => {
            let body = "";
            for await (const chunk of request) body += String(chunk);
            const payload = JSON.parse(body) as { system?: unknown };
            response.writeHead(200, { "content-type": "text/event-stream" });
            if (typeof payload.system === "string" && payload.system.startsWith("Create a concise title")) {
                response.end(mockModelStream("Live output test", request.url));
                return;
            }
            agentCalls += 1;
            response.end(agentCalls === 1
                ? mockToolUseStream(
                    "node -e \"process.stdout.write('first'); setTimeout(() => process.stdout.write('second'), 2000)\"",
                    process.platform === "win32" ? "pwsh" : "bash",
                )
                : mockModelStream("Finished.", request.url));
        });
        await new Promise<void>((resolve) => provider.listen(0, "127.0.0.1", resolve));
        const address = provider.address() as { port: number };
        const client = new AcpTestClient(root, workspace, undefined, {
            DEEPSEEK_BASE_URL: `http://127.0.0.1:${address.port}`,
            DSH_PERMISSION_MODE: "danger-full-access",
        });
        try {
            await client.request("initialize", { protocolVersion: 1 }, 60_000);
            const { sessionId } = await client.request("session/new", { cwd: workspace, mcpServers: [] }) as { sessionId: string };
            let settled = false;
            const prompt = client.request("session/prompt", { sessionId, prompt: [{ type: "text", text: "Run the live output test." }] }, 60_000);
            void prompt.then(() => { settled = true; }, () => { settled = true; });
            const output = () => client.updatesFor(sessionId)
                .filter((update) => update["sessionUpdate"] === "tool_call_update")
                .flatMap((update) => (update["content"] as Array<{ content?: { text?: string } }> | undefined) ?? [])
                .map((block) => block.content?.text ?? "")
                .join("");
            await expect.poll(() => output().includes("first"), { timeout: 8_000 }).toBe(true);
            expect(settled).toBe(false);
            await expect(prompt).resolves.toMatchObject({ stopReason: "end_turn" });
            expect(output()).toContain("second");
        } finally {
            await client.close();
            provider.closeAllConnections();
            await new Promise<void>((resolve) => provider.close(() => resolve()));
            rmSync(root, { recursive: true, force: true });
            rmSync(workspace, { recursive: true, force: true });
        }
    }, 90_000);
});

function persistedSessionHeaders(sessionRoot: string): Array<Record<string, unknown>> {
    const headers: Array<Record<string, unknown>> = [];
    const walk = (dir: string): void => {
        if (!existsSync(dir)) return;
        for (const name of readdirSync(dir)) {
            const path = join(dir, name);
            if (statSync(path).isDirectory()) {
                walk(path);
                continue;
            }
            if (!name.endsWith(".jsonl") && !name.endsWith(".jsonl.zstd")) continue;
            const bytes = readFileSync(path);
            const text = name.endsWith(".zstd") ? zstdDecompressSync(bytes).toString("utf8") : bytes.toString("utf8");
            const line = text.split("\n").find((entry) => entry.length > 0);
            if (line !== undefined) headers.push(JSON.parse(line) as Record<string, unknown>);
        }
    };
    walk(join(sessionRoot, "home"));
    return headers;
}

describe("subagent session origin", () => {
    it("keeps child sessions out of the ACP session list and refuses to open them", async () => {
        const sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-subagent-origin-"));
        const workspace = mkdtempSync(join(tmpdir(), "dsh-acp-subagent-origin-ws-"));
        let parentTurns = 0;
        const provider = createServer(async (request, response) => {
            let body = "";
            for await (const chunk of request) body += String(chunk);
            const payload = JSON.parse(body) as { system?: unknown; messages?: unknown };
            const system = typeof payload.system === "string" ? payload.system : "";
            const transcript = system + JSON.stringify(payload.messages ?? []);
            response.writeHead(200, { "content-type": "text/event-stream" });
            if (system.startsWith("Create a concise title")) {
                response.end(mockModelStream("Origin probe", request.url));
                return;
            }
            if (transcript.includes("You are a delegated subagent")) {
                response.end(mockModelStream("CHILD", request.url));
                return;
            }
            parentTurns += 1;
            const tool = parentTurns === 1 ? "subagent" : parentTurns === 3 ? "subagent_fork" : undefined;
            response.end(tool === undefined ? mockModelStream("parent done", request.url) : mockSubagentToolStream(tool));
        });
        await new Promise<void>((resolve) => provider.listen(0, "127.0.0.1", resolve));
        const address = provider.address() as { port: number };
        const client = new AcpTestClient(sessionRoot, workspace, undefined, {
            DEEPSEEK_BASE_URL: `http://127.0.0.1:${address.port}`,
            DSH_PERMISSION_MODE: "danger-full-access",
        });
        try {
            await client.request("initialize", { protocolVersion: 1 }, 60_000);
            const { sessionId } = await client.request("session/new", { cwd: workspace, mcpServers: [] }) as { sessionId: string };
            await client.request("session/prompt", {
                sessionId,
                prompt: [{ type: "text", text: "Delegate with the subagent tool." }],
            }, 90_000);
            await client.request("session/prompt", {
                sessionId,
                prompt: [{ type: "text", text: "Delegate with the subagent_fork tool." }],
            }, 90_000);

            const headers = persistedSessionHeaders(sessionRoot);
            const children = headers.filter((header) => header["parentSession"] === sessionId);
            expect(children).toHaveLength(2);
            expect(children.every((header) => header["origin"] === "subagent" && header["delegationDepth"] === 1)).toBe(true);
            expect(children.map((header) => header["isSeeded"]).sort()).toEqual([false, true]);

            const listed = await client.request("session/list", { cwd: workspace }) as {
                sessions: Array<{ sessionId: string }>;
            };
            const listedIds = listed.sessions.map((session) => session.sessionId);
            expect(listedIds).toContain(sessionId);
            for (const child of children) expect(listedIds).not.toContain(child["id"]);

            for (const child of children) {
                const childId = String(child["id"]);
                await expect(client.request("session/load", { sessionId: childId, cwd: workspace, mcpServers: [] }))
                    .rejects.toThrow(/subagent child/);
                await expect(client.request("session/resume", { sessionId: childId, cwd: workspace, mcpServers: [] }))
                    .rejects.toThrow(/subagent child/);
                await expect(client.request("session/prompt", {
                    sessionId: childId,
                    prompt: [{ type: "text", text: "open the child" }],
                })).rejects.toThrow(/subagent child/);
            }
        } finally {
            await client.close();
            provider.closeAllConnections();
            await new Promise<void>((resolve) => provider.close(() => resolve()));
            rmSync(sessionRoot, { recursive: true, force: true });
            rmSync(workspace, { recursive: true, force: true });
        }
    }, 120_000);
});

describe("dsh-acp server (e2e smoke)", () => {
    let client: AcpTestClient;
    let sessionRoot: string;
    let workspace: string;

    beforeAll(() => {
        sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-sessions-"));
        workspace = mkdtempSync(join(tmpdir(), "dsh-acp-workspace-"));
        client = new AcpTestClient(sessionRoot, workspace);
    });

    afterAll(async () => {
        await client.close();
        rmSync(sessionRoot, { recursive: true, force: true });
        rmSync(workspace, { recursive: true, force: true });
    });

    let sessionId: string;

    it("initializes with Agent Auth and logout", async () => {
        const result = (await client.request("initialize", {
            protocolVersion: 1,
            clientCapabilities: {
                fs: { readTextFile: false, writeTextFile: false },
                _meta: { dsh: { cordis: { protocol: 0 } } },
            },
        })) as Record<string, unknown>;
        expect(result["protocolVersion"]).toBe(1);
        expect(result["agentInfo"]).toMatchObject({ name: "dsh-acp" });
        const capabilities = result["agentCapabilities"] as Record<string, unknown>;
        expect(capabilities["loadSession"]).toBe(true);
        expect(capabilities["promptCapabilities"]).toMatchObject({ embeddedContext: true, image: true });
        expect(capabilities["auth"]).toEqual({ logout: {} });
        expect(capabilities["sessionCapabilities"]).toMatchObject({ list: {}, resume: {}, fork: {} });
        expect(capabilities["_meta"]).toMatchObject({
            dsh: {
                cordis: { protocol: 0 },
                // The resolved runtime identity — the client can display which
                // dsh actually booted (issue #157); this e2e host came from DSH_PATH.
                runtime: {
                    version: "0.2.0-rc.2",
                    source: `--dsh-path/DSH_PATH (${ROOT})`,
                    base: expect.any(String),
                },
            },
            jetbrains: { air: { fork: { version: 1, inclusive: true } } },
        });
        const methods = result["authMethods"] as Array<Record<string, unknown>>;
        expect(methods.length).toBeGreaterThanOrEqual(1);
        expect(methods.every((method) => method["type"] === undefined || method["type"] === "agent")).toBe(true);
        expect(methods.some((method) => {
            const id = method["id"];
            return typeof id === "string" && id.startsWith("api-key");
        })).toBe(true);
        expect(methods[0]?.["_meta"]).toMatchObject({ "api-key": {} });
    }, 60_000);

    it("creates a session with sandbox modes and config options (model, effort)", async () => {
        const result = (await client.request("session/new", {
            cwd: workspace,
            mcpServers: [],
        })) as Record<string, unknown>;
        sessionId = result["sessionId"] as string;
        expect(sessionId).toBeTruthy();
        expect(result["modes"]).toMatchObject({ currentModeId: "workspace-write" });
        const modes = (result["modes"] as { availableModes: Array<{ id: string }> }).availableModes.map(
            (mode) => mode.id,
        );
        expect(modes).toEqual(["read-only", "workspace-write", "danger-full-access"]);
        const configOptions = result["configOptions"] as Array<Record<string, unknown>>;
        const byId = new Map(configOptions.map((option) => [option["id"], option]));
        // The permission level is both the session-mode state and a config
        // option (some clients only render the latter); approval policy stays
        // bundled inside it, never a standalone option (matching the Web UI).
        expect(byId.get("mode")).toMatchObject({ type: "select", category: "mode", currentValue: "workspace-write" });
        expect(byId.has("approvals")).toBe(false);
        expect(byId.get("model")).toMatchObject({ type: "select", category: "model", currentValue: expect.stringMatching(/^(?:deepseek-official::)?deepseek-(?:v4-)?flash$/) });
        expect(byId.get("effort")).toMatchObject({ type: "select", category: "thought_level" });
        expect(byId.get("collaboration_mode")).toMatchObject({
            type: "select",
            currentValue: "default",
            options: [
                { value: "default", name: "Default" },
                { value: "plan", name: "Plan" },
            ],
        });
        const efforts = (byId.get("effort") as { options: Array<{ value: string }> }).options.map((o) => o.value);
        expect(efforts).toContain("high");
        expect(byId.get("agent")).toMatchObject({ type: "select", currentValue: "standard" });
        const agents = (byId.get("agent") as { options: Array<{ value: string }> }).options.map((o) => o.value);
        expect(agents).toEqual(expect.arrayContaining(["standard", "ptc", "minimal", "cordis"]));
    }, 60_000);

    it("rejects relative cwds", async () => {
        await expect(client.request("session/new", { cwd: "relative/path", mcpServers: [] })).rejects.toThrow(
            /absolute/,
        );
    }, 60_000);

    it("rejects non-empty additional directories instead of silently narrowing the workspace", async () => {
        await expect(client.request("session/new", {
            cwd: workspace,
            additionalDirectories: [join(workspace, "other-root")],
            mcpServers: [],
        })).rejects.toMatchObject({
            code: -32602,
            message: expect.stringContaining("additionalDirectories is not supported"),
        });
    }, 60_000);

    it("keeps a new session registered while Zed applies config defaults concurrently", async () => {
        const created = (await client.request("session/new", {
            cwd: workspace,
            mcpServers: [],
        })) as Record<string, unknown>;
        const createdSessionId = created["sessionId"];

        const defaults = Promise.all([
            client.request("session/set_config_option", {
                sessionId: createdSessionId,
                configId: "agent",
                value: "ptc",
            }),
            client.request("session/set_config_option", {
                sessionId: createdSessionId,
                configId: "model",
                value: "deepseek-v4-pro",
            }),
        ]);

        await expect(defaults).resolves.toEqual([expect.any(Object), expect.any(Object)]);
        await expect(client.request("session/prompt", {
            sessionId: createdSessionId,
            prompt: [{ type: "text", text: "/status" }],
        })).resolves.toMatchObject({ stopReason: "end_turn" });
        const status = client.updatesFor(String(createdSessionId)).find(
            (update) =>
                update["sessionUpdate"] === "agent_message_chunk" &&
                (update["content"] as { text?: string } | undefined)?.text?.includes("**dsh-acp**"),
        );
        expect((status?.["content"] as { text: string }).text).toContain("| Preset | ptc |");
        expect((status?.["content"] as { text: string }).text).toContain("| Model | deepseek-v4-pro |");
    }, 60_000);

    it("accepts mcpServers, tolerating dead servers and unknown transports", async () => {
        // failOnStartupError is off: a server that cannot start must not take
        // the session down, and an unsupported transport is skipped. The name
        // is sanitized onto mcp-client's [A-Za-z0-9_-]{1,32} charset.
        const result = (await client.request("session/new", {
            cwd: workspace,
            mcpServers: [
                {
                    name: "dead server! (test)",
                    command: "/nonexistent/dsh-acp-mcp-e2e",
                    args: [],
                    env: [{ name: "X", value: "1" }],
                },
                { type: "sse", name: "legacy", url: "http://127.0.0.1:1/sse" },
            ],
        })) as Record<string, unknown>;
        expect(result["sessionId"]).toBeTruthy();
    }, 60_000);

    it("serves the /status command without touching the model", async () => {
        const result = (await client.request("session/prompt", {
            sessionId,
            prompt: [{ type: "text", text: "/status" }],
        })) as Record<string, unknown>;
        expect(result["stopReason"]).toBe("end_turn");
        const updates = client.updatesFor(sessionId);
        const status = updates.find((update) => update["sessionUpdate"] === "agent_message_chunk");
        expect(status).toBeDefined();
        const content = (status as { content: { text: string } }).content;
        expect(content.text).toContain("dsh-acp");
        // This session has no logged model request, so it follows the live
        // product default saved by the earlier model selection, matching Web.
        expect(content.text).toContain("deepseek-v4-pro");
        expect(content.text).toContain("workspace-write");
    }, 60_000);

    it("publishes available commands (builtins + harness registry)", async () => {
        let names: string[] = [];
        for (let attempt = 0; attempt < 40; attempt += 1) {
            const updates = client.updatesFor(sessionId);
            const commands = [...updates]
                .reverse()
                .find((update) => update["sessionUpdate"] === "available_commands_update");
            const list = commands?.["availableCommands"] as Array<{ name: string }> | undefined;
            names = list?.map((c) => c.name) ?? [];
            if (names.length > 0) break;
            await new Promise((resolve) => setTimeout(resolve, 250));
        }
        // Adapter built-ins always lead. Login/logout are ACP methods, not
        // slash commands — putting `/login` in the catalogue made clients
        // treat credential setup as a chat command.
        expect(names.slice(0, 2)).toEqual(["status", "model"]);
        expect(names).not.toContain("login");
        expect(names).not.toContain("logout");
        // …followed by the composition's own registry (dsh-base mounts
        // compact among others).
        expect(names).toContain("compact");
        const commands = [...client.updatesFor(sessionId)]
            .reverse()
            .find((update) => update["sessionUpdate"] === "available_commands_update")?.[
                "availableCommands"
            ] as Array<Record<string, unknown>> | undefined;
        expect(commands?.find((command) => command["name"] === "plan")).toMatchObject({
            _meta: {
                commandAction: {
                    kind: "setConfigOption",
                    configId: "collaboration_mode",
                    value: "plan",
                    resetValue: "default",
                    presentation: "state",
                },
            },
        });
        expect(commands?.find((command) => command["name"] === "plan-view")).toMatchObject({
            description: "Open the current ACP plan",
            _meta: {
                commandAction: {
                    kind: "clientCommand",
                    presentation: "view",
                },
            },
        });
    }, 60_000);

    it("switches plan mode through the standard collaboration config option", async () => {
        const on = (await client.request("session/set_config_option", {
            sessionId,
            configId: "collaboration_mode",
            value: "plan",
        })) as Record<string, unknown>;
        const onById = new Map(
            (on["configOptions"] as Array<Record<string, unknown>>).map((option) => [option["id"], option]),
        );
        expect(onById.get("collaboration_mode")).toMatchObject({ currentValue: "plan" });

        const off = (await client.request("session/set_config_option", {
            sessionId,
            configId: "collaboration_mode",
            value: "default",
        })) as Record<string, unknown>;
        const offById = new Map(
            (off["configOptions"] as Array<Record<string, unknown>>).map((option) => [option["id"], option]),
        );
        expect(offById.get("collaboration_mode")).toMatchObject({ currentValue: "default" });
    }, 60_000);

    it("switches session modes", async () => {
        const result = await client.request("session/set_mode", { sessionId, modeId: "read-only" });
        expect(result).toEqual({});
        const updates = client.updatesFor(sessionId);
        expect(
            updates.some(
                (update) =>
                    update["sessionUpdate"] === "current_mode_update" && update["currentModeId"] === "read-only",
            ),
        ).toBe(true);
        // Mode changes also republish config options so config-option clients stay in sync.
        expect(updates.some((update) => update["sessionUpdate"] === "config_option_update")).toBe(true);
        await expect(client.request("session/set_mode", { sessionId, modeId: "bogus" })).rejects.toThrow(
            /unknown mode/,
        );
    }, 60_000);

    it("switches effort through config options; permission knobs are not options", async () => {
        const effort = (await client.request("session/set_config_option", {
            sessionId,
            configId: "effort",
            value: "high",
        })) as Record<string, unknown>;
        const byId = new Map(
            (effort["configOptions"] as Array<Record<string, unknown>>).map((option) => [option["id"], option]),
        );
        expect(byId.get("effort")).toMatchObject({ currentValue: "high" });

        // Permission facts travel through the mode option or session modes;
        // a standalone approvals knob stays rejected.
        const modeSet = (await client.request("session/set_config_option", {
            sessionId,
            configId: "mode",
            value: "read-only",
        })) as Record<string, unknown>;
        const modeById = new Map(
            (modeSet["configOptions"] as Array<Record<string, unknown>>).map((option) => [option["id"], option]),
        );
        expect(modeById.get("mode")).toMatchObject({ currentValue: "read-only" });
        const approvalsError = await client
            .request("session/set_config_option", { sessionId, configId: "approvals", value: "never" })
            .then(
                () => undefined,
                (error: unknown) => error,
            );
        expect(String(approvalsError)).toMatch(/unknown config option/);

        await expect(
            client.request("session/set_config_option", { sessionId, configId: "effort", value: "bogus" }),
        ).rejects.toThrow(/unknown effort/);
        await expect(
            client.request("session/set_config_option", { sessionId, configId: "bogus", value: "x" }),
        ).rejects.toThrow(/unknown config option/);

        // Restore for the later status/mode assertions.
        await client.request("session/set_mode", { sessionId, modeId: "read-only" });
    }, 60_000);

    it("switches models through the config option and lists sessions", async () => {
        const result = (await client.request("session/set_config_option", {
            sessionId,
            configId: "model",
            value: "deepseek-v4-pro",
        })) as Record<string, unknown>;
        const configOptions = result["configOptions"] as Array<Record<string, unknown>>;
        const model = configOptions.find((option) => option["id"] === "model");
        expect((model?.["currentValue"] as string).split("::").at(-1)).toBe("deepseek-v4-pro");
        // The picked effort survives the resume-based model switch.
        const effort = configOptions.find((option) => option["id"] === "effort");
        expect(effort).toMatchObject({ currentValue: "high" });

        const list = (await client.request("session/list", {})) as Record<string, unknown>;
        const sessions = list["sessions"] as Array<Record<string, unknown>>;
        expect(sessions.some((session) => session["sessionId"] === sessionId)).toBe(true);
    }, 60_000);

    it("switches the Agent preset to cordis without dropping the session", async () => {
        const result = (await client.request("session/set_config_option", {
            sessionId,
            configId: "agent",
            value: "cordis",
        })) as Record<string, unknown>;
        const configOptions = result["configOptions"] as Array<Record<string, unknown>>;
        const agent = configOptions.find((option) => option["id"] === "agent");
        expect(agent).toMatchObject({ id: "agent", currentValue: "cordis" });

        const status = (await client.request("session/prompt", {
            sessionId,
            prompt: [{ type: "text", text: "/status" }],
        })) as Record<string, unknown>;
        expect(status["stopReason"]).toBe("end_turn");
    }, 60_000);

    it("cancels idle sessions without error and answers unknown sessions loudly", async () => {
        await expect(
            client.request("session/prompt", { sessionId: "nope", prompt: [{ type: "text", text: "hi" }] }),
        ).rejects.toThrow(/unknown session/);
    }, 60_000);

    it("rejects additional directories when loading a session", async () => {
        const created = await client.request("session/new", {
            cwd: workspace,
            mcpServers: [],
        }) as { sessionId: string };
        await expect(client.request("session/load", {
            sessionId: created.sessionId,
            cwd: workspace,
            additionalDirectories: [join(workspace, "other-root")],
            mcpServers: [],
        })).rejects.toMatchObject({
            code: -32602,
            message: expect.stringContaining("additionalDirectories is not supported"),
        });
    }, 60_000);

    it("loads a persisted session from a fresh server process", async () => {
        // End the first server so the second owns the JSONL store exclusively.
        await client.close();
        client = new AcpTestClient(sessionRoot, workspace);
        await client.request("initialize", { protocolVersion: 1 });
        const result = (await client.request("session/load", {
            sessionId,
            cwd: workspace,
            mcpServers: [],
        })) as Record<string, unknown>;
        // The mode switched to read-only earlier in this suite; the durable
        // permission/preset fact must fold back on load (a fresh process).
        expect(result["modes"]).toMatchObject({ currentModeId: "read-only" });
        // The reloaded session accepts adapter commands again.
        const status = (await client.request("session/prompt", {
            sessionId,
            prompt: [{ type: "text", text: "/status" }],
        })) as Record<string, unknown>;
        expect(status["stopReason"]).toBe("end_turn");
        await expect(
            client.request("session/load", { sessionId: "missing", cwd: workspace, mcpServers: [] }),
        ).rejects.toThrow(/session not found/);
    }, 60_000);

    it("resumes a persisted session without replaying its history", async () => {
        await client.close();
        client = new AcpTestClient(sessionRoot, workspace);
        const initialized = (await client.request("initialize", { protocolVersion: 1 })) as Record<string, unknown>;
        expect(initialized["agentCapabilities"]).toMatchObject({
            sessionCapabilities: { resume: {} },
        });

        const result = (await client.request("session/resume", {
            sessionId,
            cwd: workspace,
            mcpServers: [],
        })) as Record<string, unknown>;
        expect(result["modes"]).toMatchObject({ currentModeId: "read-only" });

        const replayKinds = new Set([
            "user_message_chunk",
            "agent_message_chunk",
            "agent_thought_chunk",
            "tool_call",
            "tool_call_update",
        ]);
        expect(client.updatesFor(sessionId).filter((update) => replayKinds.has(String(update["sessionUpdate"])))).toEqual([]);

        await expect(client.request("session/prompt", {
            sessionId,
            prompt: [{ type: "text", text: "/status" }],
        })).resolves.toMatchObject({ stopReason: "end_turn" });
    }, 60_000);

    it("restores a persisted session on direct prompt without session/load", async () => {
        // Zed keeps threads across agent restarts and may prompt an old
        // session id directly; the adapter restores it from the log.
        await client.close();
        client = new AcpTestClient(sessionRoot, workspace);
        await client.request("initialize", { protocolVersion: 1 });
        const status = (await client.request("session/prompt", {
            sessionId,
            prompt: [{ type: "text", text: "/status" }],
        })) as Record<string, unknown>;
        expect(status["stopReason"]).toBe("end_turn");
        // Truly unknown ids still fail loudly.
        await expect(
            client.request("session/prompt", {
                sessionId: "11111111-1111-4111-8111-111111111111",
                prompt: [{ type: "text", text: "hi" }],
            }),
        ).rejects.toThrow(/unknown session/);
    }, 60_000);
});

// Optional: run the same handshake against a real standalone host install
// (`npm install @deepseek-ai/dsh`) when one is available. Set
// DSH_ACP_TEST_HOST to its directory; CI without one skips this block.
const HOST_TREE = process.env["DSH_ACP_TEST_HOST"];

describe.skipIf(HOST_TREE === undefined)("dsh-acp against a standalone host install", () => {
    let client: AcpTestClient;
    let sessionRoot: string;
    let workspace: string;

    beforeAll(() => {
        sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-host-sessions-"));
        workspace = mkdtempSync(join(tmpdir(), "dsh-acp-host-workspace-"));
        client = new AcpTestClient(sessionRoot, workspace, HOST_TREE);
    });

    afterAll(async () => {
        await client.close();
        rmSync(sessionRoot, { recursive: true, force: true });
        rmSync(workspace, { recursive: true, force: true });
    });

    it("serves session controls through the host tree", async () => {
        const init = (await client.request("initialize", { protocolVersion: 1 })) as Record<string, unknown>;
        expect(init["agentInfo"]).toMatchObject({ name: "dsh-acp" });
        const created = (await client.request("session/new", { cwd: workspace, mcpServers: [] })) as Record<
            string,
            unknown
        >;
        const hostSessionId = created["sessionId"] as string;
        expect(hostSessionId).toBeTruthy();

        await expect(
            client.request("session/set_mode", { sessionId: hostSessionId, modeId: "read-only" }),
        ).resolves.toEqual({});

        const plan = (await client.request("session/set_config_option", {
            sessionId: hostSessionId,
            configId: "collaboration_mode",
            value: "plan",
        })) as Record<string, unknown>;
        const planById = new Map(
            (plan["configOptions"] as Array<Record<string, unknown>>).map((option) => [option["id"], option]),
        );
        expect(planById.get("collaboration_mode")).toMatchObject({ currentValue: "plan" });

        const updateStart = client.updatesFor(hostSessionId).length;
        const compact = (await client.request("session/prompt", {
            sessionId: hostSessionId,
            prompt: [{ type: "text", text: "/compact" }],
        })) as Record<string, unknown>;
        expect(compact["stopReason"]).toBe("end_turn");
        const compactText = client
            .updatesFor(hostSessionId)
            .slice(updateStart)
            .filter((update) => update["sessionUpdate"] === "agent_message_chunk")
            .map((update) => (update["content"] as { text?: string } | undefined)?.text ?? "")
            .join("");
        expect(compactText).toMatch(/No compactable history|compact/i);
        expect(compactText).not.toContain("failed:");

        const status = (await client.request("session/prompt", {
            sessionId: hostSessionId,
            prompt: [{ type: "text", text: "/status" }],
        })) as Record<string, unknown>;
        expect(status["stopReason"]).toBe("end_turn");
    }, 120_000);
});

// Harness selection (Martty issue #157): ambient dsh installs must never
// hijack the runtime, and an explicit out-of-range selection is refused
// with a message naming version, source and supported range.
describe("harness selection", () => {
    function spawnLauncher(env: Record<string, string | undefined>): Promise<{ code: number; stderr: string }> {
        const merged: Record<string, string | undefined> = {
            ...process.env,
            DEEPSEEK_API_KEY: "sk-test-e2e-not-a-real-key",
            ...env,
        };
        for (const [key, value] of Object.entries(merged)) if (value === undefined) delete merged[key];
        return new Promise((resolve, reject) => {
            const child = spawn(process.execPath, ["--import", "tsx", "src/bin.ts"], {
                cwd: ROOT,
                env: merged as Record<string, string>,
                stdio: ["ignore", "ignore", "pipe"],
            });
            let stderr = "";
            child.stderr.on("data", (chunk: string) => {
                stderr += chunk;
            });
            child.on("error", reject);
            child.on("exit", (code) => resolve({ code: code ?? -1, stderr }));
        });
    }

    it("uses the bundled runtime even with a stale dsh on PATH — never the ambient one", async () => {
        const ambient = mkdtempSync(join(tmpdir(), "dsh-acp-ambient-"));
        const stalePkg = join(ambient, "prefix", "lib", "node_modules", "@deepseek-ai");
        mkdirSync(join(stalePkg, "dsh", "lib"), { recursive: true });
        writeFileSync(join(stalePkg, "dsh", "package.json"), JSON.stringify({ name: "@deepseek-ai/dsh", version: "0.1.1-rc.2" }));
        writeFileSync(join(stalePkg, "dsh", "lib", "bin.js"), "// stale launcher");
        mkdirSync(join(stalePkg, "dsh-agent"), { recursive: true });
        writeFileSync(join(stalePkg, "dsh-agent", "package.json"), JSON.stringify({ name: "@deepseek-ai/dsh-agent", version: "0.1.1-rc.2" }));
        mkdirSync(join(ambient, "prefix", "bin"), { recursive: true });
        symlinkSync(join(stalePkg, "dsh", "lib", "bin.js"), join(ambient, "prefix", "bin", "dsh"));
        try {
            const result = await spawnLauncher({
                DSH_PATH: undefined,
                DSH_ACP_HOST: undefined,
                PATH: `${join(ambient, "prefix", "bin")}${delimiter}${process.env["PATH"] ?? ""}`,
            });
            // The dev checkout has no packaged runtime, so the launcher must
            // fail on the bundled probe alone — proving the stale dsh on PATH
            // was never consulted (its version must not appear anywhere).
            expect(result.code).not.toBe(0);
            expect(result.stderr).toContain("bundled standalone runtime");
            expect(result.stderr).not.toContain("0.1.1-rc.2");
        } finally {
            rmSync(ambient, { recursive: true, force: true });
        }
    }, 60_000);

    it("refuses an explicit out-of-range dsh path, naming version, source and supported range", async () => {
        const stale = mkdtempSync(join(tmpdir(), "dsh-acp-stale-"));
        const scope = join(stale, "node_modules", "@deepseek-ai");
        mkdirSync(join(scope, "dsh"), { recursive: true });
        writeFileSync(join(scope, "dsh", "package.json"), JSON.stringify({ name: "@deepseek-ai/dsh", version: "0.1.1-rc.2" }));
        mkdirSync(join(scope, "dsh-agent"), { recursive: true });
        writeFileSync(join(scope, "dsh-agent", "package.json"), JSON.stringify({ name: "@deepseek-ai/dsh-agent", version: "0.1.1-rc.2" }));
        try {
            const result = await spawnLauncher({ DSH_PATH: stale });
            expect(result.code).not.toBe(0);
            expect(result.stderr).toContain("incompatible DeepSeek Harness");
            expect(result.stderr).toContain("0.1.1-rc.2");
            expect(result.stderr).toContain(stale);
            expect(result.stderr).toContain("supported versions: >=0.1.7-rc.2");
        } finally {
            rmSync(stale, { recursive: true, force: true });
        }
    }, 60_000);
});

// Only fixed backends participate in cross-process ownership. Older hosts
// remain covered by the ordinary host and bundled-runtime suites above.
const WRITE_HOST = process.env["DSH_ACP_TEST_WRITE_HOST"] ?? ROOT;
const LEGACY_HOST = process.env["DSH_ACP_TEST_LEGACY_HOST"];
describe("session ownership", () => {
    const clients: AcpTestClient[] = [];
    let sessionRoot: string;
    let workspace: string;

    let provider: Server;
    let baseUrl: string;
    beforeAll(async () => {
        sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-alpha-sessions-"));
        workspace = mkdtempSync(join(tmpdir(), "dsh-acp-alpha-workspace-"));
        // Exercise a complete model turn without contacting a real provider.
        provider = createServer((request, response) => {
            request.resume();
            response.writeHead(200, { "Content-Type": "text/event-stream" });
            response.end(mockModelStream("Alpha reply.", request.url));
        });
        await new Promise<void>((resolve) => provider.listen(0, "127.0.0.1", resolve));
        baseUrl = `http://127.0.0.1:${(provider.address() as { port: number }).port}`;
    });
    afterAll(async () => {
        await Promise.all(clients.map((client) => client.close()));
        await new Promise<void>((resolve, reject) => provider.close((error) => error ? reject(error) : resolve()));
        rmSync(sessionRoot, { recursive: true, force: true });
        rmSync(workspace, { recursive: true, force: true });
    });
    async function connect(host = WRITE_HOST): Promise<AcpTestClient> {
        const client = new AcpTestClient(sessionRoot, workspace, host, { DEEPSEEK_BASE_URL: baseUrl });
        clients.push(client);
        await client.request("initialize", { protocolVersion: 1 });
        return client;
    }
    async function seed(host = WRITE_HOST, preset?: string): Promise<string> {
        const client = await connect(host);
        const { sessionId } = await client.request("session/new", { cwd: workspace, mcpServers: [] }) as { sessionId: string };
        if (preset !== undefined) await client.request("session/set_config_option", { sessionId, configId: "agent", value: preset });
        await expect(client.request("session/prompt", { sessionId, prompt: [{ type: "text", text: "Remember the alpha test." }] }))
            .resolves.toMatchObject({ stopReason: "end_turn" });
        expect(client.updatesFor(sessionId)).toContainEqual(expect.objectContaining({
            sessionUpdate: "agent_message_chunk", content: { type: "text", text: "Alpha reply." },
        }));
        await client.request("session/set_mode", { sessionId, modeId: "read-only" });
        await client.request("session/close", { sessionId });
        await client.close();
        return sessionId;
    }
    it("lists and reloads persisted metadata through the handle API", async () => {
        const sessionId = await seed();
        const client = await connect();
        const listed = await client.request("session/list", { cwd: workspace }) as { sessions: unknown[] };
        expect(listed.sessions).toContainEqual(expect.objectContaining({ sessionId, cwd: workspace, title: expect.any(String) }));
        await expect(client.request("session/load", { sessionId, cwd: workspace, mcpServers: [] }))
            .resolves.toMatchObject({ modes: { currentModeId: "read-only" } });
        expect(client.updatesFor(sessionId)).toContainEqual(expect.objectContaining({
            sessionUpdate: "user_message_chunk", content: { type: "text", text: "Remember the alpha test." },
        }));
        expect(client.updatesFor(sessionId)).toContainEqual(expect.objectContaining({
            sessionUpdate: "agent_message_chunk", content: { type: "text", text: "Alpha reply." },
        }));
        await expect(client.request("session/prompt", { sessionId, prompt: [{ type: "text", text: "/status" }] }))
            .resolves.toMatchObject({ stopReason: "end_turn" });
        await client.close();
    }, 120_000);
    it.skipIf(LEGACY_HOST === undefined)("migrates an rc session and preserves its preset before replay", async () => {
        // An independent pre-V3 host writes the historical session.
        const sessionId = await seed(LEGACY_HOST, "ptc");
        const client = await connect();
        const loaded = await client.request("session/load", { sessionId, cwd: workspace, mcpServers: [] }) as {
            modes: { currentModeId: string }; configOptions: Array<{ id: string; currentValue: string }>;
        };
        expect(loaded.modes.currentModeId).toBe("read-only");
        expect(loaded.configOptions).toContainEqual(expect.objectContaining({ id: "agent", currentValue: "ptc" }));
        expect(client.updatesFor(sessionId)).toContainEqual(expect.objectContaining({
            sessionUpdate: "agent_message_chunk", content: { type: "text", text: "Alpha reply." },
        }));
        await expect(client.request("session/prompt", { sessionId, prompt: [{ type: "text", text: "Continue after migration." }] }))
            .resolves.toMatchObject({ stopReason: "end_turn" });
        await client.close();
    }, 120_000);
    it.each(["close", "crash"] as const)("rejects a competing resume and permits handoff after %s", async (release) => {
        const sessionId = await seed();
        const owner = await connect();
        const contender = await connect();
        const params = { sessionId, cwd: workspace, mcpServers: [] };
        await owner.request("session/resume", params);
        await expect(contender.request("session/load", params)).rejects.toMatchObject({
            code: -32603, message: expect.stringContaining("already owned"),
        });
        await expect(contender.request("session/resume", params)).rejects.toMatchObject({ code: -32603 });
        await expect(contender.request("session/prompt", { sessionId, prompt: [{ type: "text", text: "/status" }] }))
            .rejects.toMatchObject({ code: -32603 });
        // A rejected load must not publish history for a session it failed to own.
        expect(contender.updatesFor(sessionId)).toEqual([]);
        await expect(owner.request("session/prompt", { sessionId, prompt: [{ type: "text", text: "/status" }] }))
            .resolves.toMatchObject({ stopReason: "end_turn" });
        if (release === "crash") await owner.crash();
        else await owner.request("session/close", { sessionId });
        await expect(contender.request("session/resume", params))
            .resolves.toMatchObject({ modes: { currentModeId: "read-only" } });
        await expect(contender.request("session/prompt", { sessionId, prompt: [{ type: "text", text: "Continue after handoff." }] }))
            .resolves.toMatchObject({ stopReason: "end_turn" });
        await contender.request("session/close", { sessionId });
        // Re-read the log after both writers: no seq collision or corruption.
        await expect(contender.request("session/load", params))
            .resolves.toMatchObject({ modes: { currentModeId: "read-only" } });
        await contender.close();
        await owner.close();
    }, 120_000);
});

describe("ACP authentication (Agent Auth + logout)", () => {
    let client: AcpTestClient;
    let sessionRoot: string;
    let workspace: string;
    let home: string;

    beforeAll(async () => {
        sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-login-sessions-"));
        workspace = mkdtempSync(join(tmpdir(), "dsh-acp-login-workspace-"));
        home = mkdtempSync(join(tmpdir(), "dsh-acp-login-home-"));
        // No ambient credential at all; the harness credential store lives in
        // an isolated DSH_HOME.
        client = new AcpTestClient(sessionRoot, workspace, undefined, {
            DEEPSEEK_BASE_URL: undefined,
            DEEPSEEK_API_KEY: undefined,
            DSH_HOME: home,
        });
        await client.request("initialize", { protocolVersion: 1 });
    }, 120_000);

    afterAll(async () => {
        await client.close();
        for (const dir of [sessionRoot, workspace, home]) rmSync(dir, { recursive: true, force: true });
    });

    it("refuses session/new without a credential via auth_required", async () => {
        await expect(client.request("session/new", { cwd: workspace, mcpServers: [] })).rejects.toMatchObject({
            message: expect.stringMatching(/Authentication required/i),
            code: -32000,
        });
    }, 60_000);

    it("refuses authenticate until a credential is in the harness store", async () => {
        await expect(client.request("authenticate", { methodId: "api-key" })).rejects.toMatchObject({
            message: expect.stringMatching(/Authentication required/i),
            code: -32000,
        });
    }, 60_000);

    it("accepts authenticate with an API key in _meta and then allows session/new", async () => {
        await expect(client.request("authenticate", {
            methodId: "api-key",
            _meta: { "api-key": { apiKey: "sk-test-abcdef1234567890" } },
        })).resolves.toEqual({});
        expect(existsSync(join(home, ".credentials.yaml"))).toBe(true);
        const created = (await client.request("session/new", { cwd: workspace, mcpServers: [] })) as Record<
            string,
            unknown
        >;
        expect(created["sessionId"]).toBeTruthy();

        await expect(client.request("logout", {})).resolves.toEqual({});
        await expect(client.request("session/new", { cwd: workspace, mcpServers: [] })).rejects.toMatchObject({
            code: -32000,
        });
    }, 120_000);

    it("accepts authenticate with gateway _meta and then allows session/new", async () => {
        await expect(client.request("authenticate", {
            methodId: "gateway",
            _meta: {
                gateway: {
                    baseUrl: "https://api.example.com/v1",
                    headers: { Authorization: "Bearer sk-gateway-abcdef1234567890" },
                },
            },
        })).resolves.toEqual({});
        expect(existsSync(join(home, ".credentials.yaml"))).toBe(true);
        const created = (await client.request("session/new", { cwd: workspace, mcpServers: [] })) as Record<
            string,
            unknown
        >;
        expect(created["sessionId"]).toBeTruthy();
    }, 120_000);
});


describe("ACP steering extension", () => {
    let client: AcpTestClient;
    let root: string;
    const calls: Array<{ body: string; path: string | undefined; response: ServerResponse }> = [];
    const server = createServer(async (request, response) => {
        let body = "";
        for await (const chunk of request) body += String(chunk);
        // The profile also requests session titles; these are not agent steps.
        const payload = JSON.parse(body) as { system?: unknown; messages?: Array<{ content?: unknown }> };
        const isTitle = (typeof payload.system === "string" && payload.system.startsWith("Create a concise title"))
            || (typeof payload.messages?.[0]?.content === "string"
                && payload.messages[0].content.startsWith("Create a concise title"));
        if (isTitle) {
            response.writeHead(200, { "content-type": "text/event-stream" });
            response.end(mockModelStream("Steering test", request.url));
            return;
        }
        calls.push({ body, path: request.url, response });
    });
    const idleMeta = { steering: { idleBehavior: "promptRequired" } };

    function reply(index: number, text: string): void {
        const response = calls[index]!.response;
        response.writeHead(200, { "content-type": "text/event-stream" });
        response.end(mockModelStream(text, calls[index]!.path));
    }

    beforeAll(async () => {
        root = mkdtempSync(join(tmpdir(), "dsh-acp-steering-"));
        await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
        const address = server.address();
        if (!address || typeof address === "string") throw new Error("missing server address");
        const bundle = join(root, "test-bundle");
        mkdirSync(bundle);
        writeFileSync(join(bundle, "package.json"), JSON.stringify({
            name: "dsh-acp-test-steering", version: "0.0.0", type: "module", main: "./index.js",
            dsh: { bundle: { patch: "./cordis.patch.yml" } },
        }));
        writeFileSync(join(bundle, "cordis.patch.yml"), JSON.stringify([{
            insert: [{ id: "steering-fixture", name: "dsh-acp-test-steering", config: { root } }],
        }]));
        writeFileSync(join(bundle, "index.js"), `
            import { existsSync, writeFileSync, appendFileSync } from 'node:fs';
            import { join } from 'node:path';
            import { setTimeout } from 'node:timers/promises';
            export const inject = ['agents', 'attachments'];
            export function apply(ctx, { root }) {
                const validate = ctx.attachments.validateImage.bind(ctx.attachments);
                ctx.attachments.validateImage = async (input) => {
                    if (existsSync(join(root, 'hold-image'))) {
                        writeFileSync(join(root, 'image-entered'), '1');
                        while (existsSync(join(root, 'hold-image'))) await setTimeout(10);
                    }
                    return validate(input);
                };
                ctx.on('agent/created', ({ agent }) => {
                    const steer = agent.steer.bind(agent);
                    agent.steer = (message) => {
                        if (existsSync(join(root, 'fail-steer'))) throw new Error('injection rejected');
                        return steer(message);
                    };
                });
                ctx.on('session/event', (_session, event) => {
                    if (event.type === 'turn/start') appendFileSync(join(root, 'turns'), 'turn\\n');
                });
            }
        `);
        client = new AcpTestClient(root, root, undefined, {
            DEEPSEEK_BASE_URL: `http://127.0.0.1:${address.port}`,
        }, ["--bundle", bundle]);
    });
    afterAll(async () => {
        await client?.close();
        server.closeAllConnections();
        await new Promise<void>((resolve) => server.close(() => resolve()));
        rmSync(root, { recursive: true, force: true });
    });

    it("advertises steering on the initialize response", async () => {
        expect(await client.request("initialize", { protocolVersion: 1 })).toMatchObject({
            _meta: { steering: { supported: true } },
        });
    }, 60_000);

    it("rejects malformed input and unknown methods with JSON-RPC errors", async () => {
        const { sessionId } = await client.request("session/new", { cwd: root, mcpServers: [] }) as { sessionId: string };
        for (const params of [
            {}, { sessionId, prompt: "bad" }, { sessionId, prompt: [] },
            { sessionId, prompt: [{ type: "text", text: "" }] },
            { sessionId, prompt: [null] }, { sessionId, prompt: [{ type: "text", text: 1 }] },
            { sessionId, prompt: [{ type: "audio", data: "aA==", mimeType: "audio/wav" }] },
            { sessionId: "missing-session", prompt: [{ type: "text", text: "hello" }] },
            { sessionId, prompt: [{ type: "text", text: "hello" }], _meta: { steering: { idleBehavior: "unsupported" } } },
        ]) {
            await expect(client.request("_session/steering", params)).rejects.toMatchObject({ code: -32602 });
        }
        await expect(client.request("_session/unknown", {})).rejects.toMatchObject({ code: -32601 });
        expect(calls).toHaveLength(0);
    }, 60_000);

    it("returns idle input to the client and injects active input exactly once in the original turn", async () => {
        const { sessionId } = await client.request("session/new", { cwd: root, mcpServers: [] }) as { sessionId: string };
        const turnsBefore = existsSync(join(root, "turns")) ? readFileSync(join(root, "turns"), "utf8") : "";
        const prompt = [{ type: "text", text: "original steering test" }];
        expect(await client.request("_session/steering", { sessionId, prompt, _meta: idleMeta })).toEqual({
            outcome: "promptRequired", reason: "noRunningTurn",
        });
        expect(calls).toHaveLength(0);
        let settled = false;
        const original = client.request("session/prompt", { sessionId, prompt });
        void original.then(() => { settled = true; });
        await expect.poll(() => calls.length).toBe(1);
        expect(await client.request("_session/steering", {
            sessionId, prompt: [{ type: "text", text: "unique-steering-input" }], _meta: idleMeta,
        })).toEqual({ outcome: "injected" });
        expect(settled).toBe(false);
        reply(0, "first step");
        await expect.poll(() => calls.length).toBe(2);
        expect(countSentText(calls[1]!.body, "unique-steering-input")).toBe(1);
        reply(1, "steered continuation");
        await expect(original).resolves.toMatchObject({ stopReason: "end_turn" });
        expect(client.updatesFor(sessionId)).toContainEqual(expect.objectContaining({
            sessionUpdate: "agent_message_chunk", content: { type: "text", text: "steered continuation" },
        }));
        expect(await client.request("_session/steering", { sessionId, prompt, _meta: idleMeta })).toEqual({
            outcome: "promptRequired", reason: "noRunningTurn",
        });
        const followup = client.request("session/prompt", { sessionId, prompt: [{ type: "text", text: "next ordinary turn" }] });
        await expect.poll(() => calls.length).toBe(3);
        // Older clients can still steer with concurrent session/prompt.
        await expect(client.request("session/prompt", {
            sessionId, prompt: [{ type: "text", text: "legacy-steering-input" }],
        })).resolves.toMatchObject({ stopReason: "end_turn" });
        reply(2, "second turn");
        await expect.poll(() => calls.length).toBe(4);
        expect(countSentText(calls[3]!.body, "legacy-steering-input")).toBe(1);
        reply(3, "legacy continuation");
        await expect(followup).resolves.toMatchObject({ stopReason: "end_turn" });
        expect(calls).toHaveLength(4);
        expect(readFileSync(join(root, "turns"), "utf8").slice(turnsBefore.length)).toBe("turn\nturn\n");
    }, 60_000);
    it.each([false, true])("returns promptRequired when conversion crosses turn completion (replacement turn: %s)", async (replacement) => {
        const { sessionId } = await client.request("session/new", { cwd: root, mcpServers: [] }) as { sessionId: string };
        const start = calls.length;
        const original = client.request("session/prompt", { sessionId, prompt: [{ type: "text", text: "race original" }] });
        await expect.poll(() => calls.length).toBe(start + 1);
        rmSync(join(root, "image-entered"), { force: true });
        writeFileSync(join(root, "hold-image"), "1");
        const steering = client.request("_session/steering", {
            sessionId, _meta: idleMeta, prompt: [
                { type: "text", text: "race-input" },
                { type: "image", mimeType: "image/png", data: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGP4z8AAAAMBAQDJ/pLvAAAAAElFTkSuQmCC" },
            ],
        });
        await expect.poll(() => existsSync(join(root, "image-entered"))).toBe(true);
        reply(start, "finished before steering");
        await expect(original).resolves.toMatchObject({ stopReason: "end_turn" });
        let next: Promise<unknown> | undefined;
        if (replacement) {
            next = client.request("session/prompt", { sessionId, prompt: [{ type: "text", text: "race-input" }] });
            await expect.poll(() => calls.length).toBe(start + 2);
        }
        rmSync(join(root, "hold-image"));
        await expect(steering).resolves.toEqual({ outcome: "promptRequired", reason: "noRunningTurn" });
        const followup = next ?? client.request("session/prompt", { sessionId, prompt: [{ type: "text", text: "race-input" }] });
        await expect.poll(() => calls.length).toBe(start + 2);
        expect(countSentText(calls[start + 1]!.body, "race-input")).toBe(1);
        reply(start + 1, "client-owned followup");
        await expect(followup).resolves.toMatchObject({ stopReason: "end_turn" });
        expect(calls).toHaveLength(start + 2);
    }, 60_000);

    it("does not claim delivery on injection failure or after cancellation", async () => {
        const { sessionId } = await client.request("session/new", { cwd: root, mcpServers: [] }) as { sessionId: string };
        const start = calls.length;
        const original = client.request("session/prompt", { sessionId, prompt: [{ type: "text", text: "cancel original" }] });
        await expect.poll(() => calls.length).toBe(start + 1);
        writeFileSync(join(root, "fail-steer"), "1");
        await expect(client.request("_session/steering", {
            sessionId, prompt: [{ type: "text", text: "rejected-input" }],
        })).rejects.toMatchObject({ code: -32603 });
        rmSync(join(root, "fail-steer"));
        client.notify("session/cancel", { sessionId });
        await expect(original).resolves.toMatchObject({ stopReason: "cancelled" });
        expect(await client.request("_session/steering", {
            sessionId, prompt: [{ type: "text", text: "cancelled-input" }], _meta: idleMeta,
        })).toEqual({ outcome: "promptRequired", reason: "noRunningTurn" });
        expect(calls).toHaveLength(start + 1);
    }, 60_000);

});

function messageFingerprint(text: string): string {
    return `sha256:${createHash("sha256").update(text, "utf8").digest("hex")}`;
}

function isTitleRequest(body: string): boolean {
    try {
        const payload = JSON.parse(body) as { system?: unknown; messages?: Array<{ content?: unknown }> };
        return (typeof payload.system === "string" && payload.system.startsWith("Create a concise title"))
            || (typeof payload.messages?.[0]?.content === "string"
                && payload.messages[0].content.startsWith("Create a concise title"));
    } catch {
        return false;
    }
}

function scriptedReply(body: string): string {
    const markers = ["FORK_ONE", "FORK_TWO", "FORK_THREE", "FORK_AFTER", "FORK_SOURCE_AGAIN"] as const;
    const replies: Record<(typeof markers)[number], string> = {
        FORK_ONE: "Same",
        FORK_TWO: "Second",
        FORK_THREE: "Same",
        FORK_AFTER: "Continued",
        FORK_SOURCE_AGAIN: "Source still open",
    };
    let bestAt = -1;
    let best = "UNEXPECTED";
    for (const marker of markers) {
        const at = body.lastIndexOf(marker);
        if (at >= bestAt) {
            bestAt = at;
            best = replies[marker];
        }
    }
    return bestAt < 0 ? "UNEXPECTED" : best;
}

function assistantMessages(updates: Array<Record<string, unknown>>): Array<{ messageId: string; text: string }> {
    const textById = new Map<string, string>();
    const order: string[] = [];
    for (const update of updates) {
        if (update["sessionUpdate"] !== "agent_message_chunk") continue;
        const messageId = update["messageId"];
        if (typeof messageId !== "string" || messageId.length === 0) continue;
        const text = (update["content"] as { text?: string } | undefined)?.text ?? "";
        if (text.length === 0) continue;
        if (!textById.has(messageId)) order.push(messageId);
        textById.set(messageId, `${textById.get(messageId) ?? ""}${text}`);
    }
    return order.map((messageId) => ({ messageId, text: textById.get(messageId) ?? "" }));
}

function updatesSince(
    client: AcpTestClient,
    sessionId: string,
    start: number,
): Array<Record<string, unknown>> {
    return client.notifications.slice(start).flatMap((notification) => {
        if (notification.method !== "session/update" || notification.params["sessionId"] !== sessionId) return [];
        const update = notification.params["update"];
        return update !== null && typeof update === "object" ? [update as Record<string, unknown>] : [];
    });
}

function userTexts(updates: Array<Record<string, unknown>>): string[] {
    return updates.flatMap((update) => {
        if (update["sessionUpdate"] !== "user_message_chunk") return [];
        const text = (update["content"] as { text?: string } | undefined)?.text;
        return typeof text === "string" && text.length > 0 ? [text] : [];
    });
}

describe("inclusive session/fork against a local mock model", () => {
    let client: AcpTestClient;
    let sessionRoot: string;
    let workspace: string;
    let provider: Server;
    const promptBodies: string[] = [];

    beforeAll(async () => {
        sessionRoot = mkdtempSync(join(tmpdir(), "dsh-acp-fork-sessions-"));
        workspace = mkdtempSync(join(tmpdir(), "dsh-acp-fork-workspace-"));
        provider = createServer(async (request, response) => {
            let body = "";
            for await (const chunk of request) body += String(chunk);
            response.writeHead(200, { "content-type": "text/event-stream" });
            if (isTitleRequest(body)) {
                response.end(mockModelStream("Fork title", request.url));
                return;
            }
            promptBodies.push(body);
            response.end(mockModelStream(scriptedReply(body), request.url));
        });
        await new Promise<void>((resolve) => provider.listen(0, "127.0.0.1", resolve));
        const address = provider.address();
        if (address === null || typeof address === "string") throw new Error("missing mock port");
        client = new AcpTestClient(sessionRoot, workspace, undefined, {
            DEEPSEEK_BASE_URL: `http://127.0.0.1:${address.port}`,
        });
    });

    afterAll(async () => {
        await client.close();
        await new Promise<void>((resolve) => provider.close(() => resolve()));
        rmSync(sessionRoot, { recursive: true, force: true });
        rmSync(workspace, { recursive: true, force: true });
    });

    it("forks a whole session and an inclusive message, and rejects an unknown point", async () => {
        const initialized = await client.request("initialize", { protocolVersion: 1 }) as {
            agentCapabilities: {
                sessionCapabilities?: { fork?: unknown };
                _meta?: { dsh?: { cordis?: { protocol?: number } }; jetbrains?: { air?: { fork?: unknown } } };
            };
        };
        expect(initialized.agentCapabilities.sessionCapabilities?.fork).toEqual({});
        expect(initialized.agentCapabilities._meta?.dsh?.cordis).toEqual({ protocol: 0 });
        expect(initialized.agentCapabilities._meta?.jetbrains?.air?.fork).toEqual({ version: 1, inclusive: true });

        const created = await client.request("session/new", { cwd: workspace, mcpServers: [] }) as {
            sessionId: string;
            modes: { currentModeId: string };
            configOptions?: unknown[];
        };
        const sessionId = created.sessionId;
        expect(created.modes.currentModeId).toBeTruthy();
        expect(created.configOptions?.length).toBeGreaterThan(0);

        await expect(client.request("session/fork", {
            sessionId,
            cwd: workspace,
            additionalDirectories: [join(workspace, "other-root")],
            mcpServers: [],
        })).rejects.toMatchObject({
            code: -32602,
            message: expect.stringContaining("additionalDirectories is not supported"),
        });

        const prompts = ["FORK_ONE tell me one", "FORK_TWO tell me two", "FORK_THREE tell me three"];
        for (const text of prompts) {
            await expect(client.request("session/prompt", {
                sessionId,
                prompt: [{ type: "text", text }],
            })).resolves.toMatchObject({ stopReason: "end_turn" });
        }
        const original = assistantMessages(client.updatesFor(sessionId));
        expect(original.map((message) => message.text)).toEqual(["Same", "Second", "Same"]);
        const second = original[1];
        expect(second).toBeDefined();

        const whole = await client.request("session/fork", {
            sessionId,
            cwd: workspace,
            mcpServers: [],
        }) as { sessionId: string; modes: { currentModeId: string }; configOptions?: unknown[] };
        expect(whole.sessionId).not.toBe(sessionId);
        expect(whole.modes.currentModeId).toBeTruthy();
        expect(whole.configOptions?.length).toBeGreaterThan(0);

        const inclusive = await client.request("session/fork", {
            sessionId,
            cwd: workspace,
            mcpServers: [],
            _meta: {
                jetbrains: {
                    air: {
                        fork: {
                            version: 1,
                            messageId: second!.messageId,
                            messageFingerprint: messageFingerprint(second!.text),
                            messageOccurrence: 1,
                        },
                    },
                },
            },
        }) as { sessionId: string; modes: unknown; configOptions?: unknown[] };
        expect(inclusive.sessionId).not.toBe(sessionId);
        expect(inclusive.sessionId).not.toBe(whole.sessionId);
        expect(inclusive.modes).toBeTruthy();
        expect(inclusive.configOptions?.length).toBeGreaterThan(0);

        const secondSame = await client.request("session/fork", {
            sessionId,
            cwd: workspace,
            mcpServers: [],
            _meta: {
                jetbrains: {
                    air: {
                        fork: {
                            version: 1,
                            messageId: `${second!.messageId}:segment:0`,
                            messageFingerprint: messageFingerprint("Same"),
                            messageOccurrence: 2,
                        },
                    },
                },
            },
        }) as { sessionId: string };
        expect(secondSame.sessionId).not.toBe(sessionId);

        await expect(client.request("session/fork", {
            sessionId,
            cwd: workspace,
            mcpServers: [],
            _meta: {
                jetbrains: {
                    air: {
                        fork: {
                            version: 1,
                            messageId: "missing-point",
                            messageFingerprint: messageFingerprint("no such reply"),
                        },
                    },
                },
            },
        })).rejects.toMatchObject({
            code: -32602,
            message: expect.stringContaining("Fork point message missing-point was not found in session"),
        });

        await expect(client.request("session/fork", {
            sessionId,
            cwd: workspace,
            mcpServers: [],
            _meta: { jetbrains: { air: { fork: { version: 2, messageId: second!.messageId } } } },
        })).rejects.toMatchObject({
            code: -32602,
            message: expect.stringContaining("Unsupported jetbrains.air.fork version"),
        });

        await expect(client.request("session/fork", {
            sessionId: "11111111-1111-4111-8111-111111111111",
            cwd: workspace,
            mcpServers: [],
        })).rejects.toMatchObject({
            code: -32602,
            message: expect.stringContaining("unknown session"),
        });

        const listed = await client.request("session/list", { cwd: workspace }) as {
            sessions: Array<{ sessionId: string }>;
        };
        const listedIds = listed.sessions.map((session) => session.sessionId);
        expect(listedIds).toEqual(expect.arrayContaining([sessionId, whole.sessionId, inclusive.sessionId, secondSame.sessionId]));

        await expect(client.request("session/load", {
            sessionId: inclusive.sessionId,
            cwd: workspace,
            mcpServers: [],
        })).resolves.toMatchObject({ modes: expect.any(Object) });
        const replay = assistantMessages(client.updatesFor(inclusive.sessionId));
        expect(replay.map((message) => message.text)).toEqual(["Same", "Second"]);
        expect(replay.at(-1)?.messageId).toBe(second!.messageId);
        const replayUsers = userTexts(client.updatesFor(inclusive.sessionId));
        expect(replayUsers.some((text) => text.includes("FORK_ONE"))).toBe(true);
        expect(replayUsers.some((text) => text.includes("FORK_TWO"))).toBe(true);
        expect(replayUsers.some((text) => text.includes("FORK_THREE"))).toBe(false);

        const beforeContinue = promptBodies.length;
        await expect(client.request("session/prompt", {
            sessionId: inclusive.sessionId,
            prompt: [{ type: "text", text: "FORK_AFTER continue" }],
        })).resolves.toMatchObject({ stopReason: "end_turn" });
        expect(assistantMessages(client.updatesFor(inclusive.sessionId)).map((message) => message.text)).toEqual([
            "Same",
            "Second",
            "Continued",
        ]);
        const continued = promptBodies[beforeContinue];
        expect(continued).toBeDefined();
        expect(continued).toContain("FORK_TWO");
        expect(continued).toContain("Second");
        expect(continued).not.toContain("FORK_THREE");

        await expect(client.request("session/load", {
            sessionId: whole.sessionId,
            cwd: workspace,
            mcpServers: [],
        })).resolves.toMatchObject({ modes: expect.any(Object) });
        expect(assistantMessages(client.updatesFor(whole.sessionId)).map((message) => message.text)).toEqual([
            "Same",
            "Second",
            "Same",
        ]);
        await expect(client.request("session/resume", {
            sessionId: whole.sessionId,
            cwd: workspace,
            mcpServers: [],
        })).resolves.toMatchObject({ modes: expect.any(Object) });
        await expect(client.request("session/prompt", {
            sessionId: whole.sessionId,
            prompt: [{ type: "text", text: "/status" }],
        })).resolves.toMatchObject({ stopReason: "end_turn" });

        await expect(client.request("session/load", {
            sessionId: secondSame.sessionId,
            cwd: workspace,
            mcpServers: [],
        })).resolves.toMatchObject({ modes: expect.any(Object) });
        expect(assistantMessages(client.updatesFor(secondSame.sessionId)).map((message) => message.text)).toEqual([
            "Same",
            "Second",
            "Same",
        ]);
        expect(userTexts(client.updatesFor(secondSame.sessionId)).some((text) => text.includes("FORK_THREE"))).toBe(true);

        const sourceReplayAt = client.notifications.length;
        await expect(client.request("session/load", {
            sessionId,
            cwd: workspace,
            mcpServers: [],
        })).resolves.toMatchObject({ modes: expect.any(Object) });
        expect(assistantMessages(updatesSince(client, sessionId, sourceReplayAt)).map((message) => message.text)).toEqual([
            "Same",
            "Second",
            "Same",
        ]);
        const beforeSource = promptBodies.length;
        await expect(client.request("session/prompt", {
            sessionId,
            prompt: [{ type: "text", text: "FORK_SOURCE_AGAIN still here" }],
        })).resolves.toMatchObject({ stopReason: "end_turn" });
        expect(promptBodies[beforeSource]).toContain("FORK_THREE");
        expect(assistantMessages(client.updatesFor(sessionId)).at(-1)?.text).toBe("Source still open");
    }, 180_000);
});
