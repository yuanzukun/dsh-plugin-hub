# ACP `_meta` registry

This file is the source of truth for every `_meta` field read or emitted by
`@openma/deepseek-harness-acp`. It documents adapter-owned DSH extensions and
the compatibility extensions the adapter implements for existing ACP clients.
Standard ACP fields remain sufficient unless a client explicitly opts into one
of the capabilities below.

Clients must ignore unknown `_meta` fields. Every block is optional unless the
client selected an authentication method whose request requires that block.
Several blocks can coexist on one object; for example, a completed command can
carry both `_meta.dsh.toolResult` and `_meta.terminal_exit`.

DSH-owned JSON keys use camelCase below `_meta.dsh`. Keys outside that namespace
retain the spelling of the external contract they implement, including
`terminal_output`, `terminal_info`, `terminal_exit`, `commandAction`, and
`dsh.userQuestions`.

## Initialization and capability negotiation

The client sends capability metadata in `initialize.params.clientCapabilities`.
The adapter reads only the paths listed here; omission keeps the corresponding
extension disabled.

| Path | Type | Effect |
|---|---|---|
| `clientCapabilities._meta.terminal_output` | literal `true` | Enables display-terminal content and the `terminal_*` metadata blocks. This is the Codex/Zed terminal extension. |
| `clientCapabilities._meta["subagent-transcript"]` | literal `true` | Forwards child-agent session updates onto the root ACP session with `_meta.dsh.subagent` attribution. |
| `clientCapabilities._meta.dsh.interaction.mode` | `"interactive" \| "rpc"` | Selects the DSH interaction mode passed to newly created agents. Unknown values are ignored. |
| `clientCapabilities._meta.dsh.cordis.protocol` | literal `0` | Negotiates the private `_dsh/cordis/*` TUI Client plane. Both peers must advertise the same protocol. |
| `clientCapabilities.auth._meta.gateway` | literal `true` | Requests advertisement of the custom gateway authentication method. |
| `clientCapabilities.auth.terminal` | literal `true` | Standard ACP terminal-auth capability; enables the `terminal-login` auth method (the client runs the advertised command itself). |
| `clientCapabilities._meta["terminal-auth"]` | literal `true` | Adds a `_meta["terminal-auth"]` launch spec (`command`, `args`, `label`) to the advertised terminal method for clients that launch the spec verbatim. |
| `clientCapabilities.elicitation.url` | non-null object | Enables the `browser` auth method. Browser login hands the local page URL to the client through `elicitation/create` `mode: "url"`; without this capability the method is not advertised and selecting `browser` fails fast. |

The adapter advertises the Cordis protocol and inclusive session fork in the
initialize response. The objects are deep-merged under `agentCapabilities._meta`;
neither replaces the other. `_meta.dsh.runtime` identifies the DeepSeek
Harness installation actually in use (`{base, version, source}`), so clients
can display which dsh booted; it is present on the standalone and plugin
mounts and absent only where no host identity was provided.

```json
{
  "agentCapabilities": {
    "sessionCapabilities": {
      "fork": {}
    },
    "_meta": {
      "dsh": {
        "cordis": {
          "protocol": 0
        },
        "runtime": {
          "version": "0.2.0-rc.2",
          "source": "bundled standalone runtime",
          "base": "/home/user/.cache/dsh-acp/0.2.0-rc.2-a1b2c3d4e5f6"
        }
      },
      "authStatus": {},
      "jetbrains": {
        "air": {
          "fork": {
            "version": 1,
            "inclusive": true
          }
        }
      }
    }
  }
}
```

`_meta.dsh.cordis.protocol` only negotiates the package-private TUI plane. It
does not synchronize Cordis plugin ids, services, or fibers between processes.

`agentCapabilities._meta.jetbrains.air.fork` is a nested object, the same path
the client uses on `session/fork` requests. It is not a flat dotted key.
`version` is `1` and `inclusive` is `true`: a message fork keeps the selected
assistant message. The capability is advertised only together with
`sessionCapabilities.fork: {}`.

## `session/fork` request metadata

`session/fork` with no `jetbrains.air.fork` block copies the source session's
committed log into a new session. The source session is not modified.

When the client sends `_meta.jetbrains.air.fork`, the adapter cuts the copy at
one persisted top-level assistant message:

```json
{
  "jetbrains": {
    "air": {
      "fork": {
        "version": 1,
        "messageId": "1:0",
        "messageFingerprint": "sha256:<64 lowercase hex>",
        "messageOccurrence": 1
      }
    }
  }
}
```

| Field | Required | Rule |
|---|---|---|
| `version` | yes | Must be `1`. Any other value, or a non-object block, is JSON-RPC `-32602` with message `Unsupported jetbrains.air.fork version`. The adapter does not fall back to a whole-session fork. |
| `messageId` | yes | Trimmed non-empty string. This is the ACP `messageId` on `agent_message_chunk` (`<turn>:<step>`). A client segment id `<id>:segment:<n>` is also tried as `<id>`. |
| `messageFingerprint` | no | When present, `sha256:` plus the SHA-256 hex of the assistant message's UTF-8 text (the `agent_message_chunk` texts for that id, in order; no thoughts, no tool output). |
| `messageOccurrence` | no | Positive safe integer, default `1`. 1-based index among assistant messages with the same fingerprint, in log order. |

Lookup order:

1. Exact `messageId`, then the id with a trailing `:segment:<n>` removed.
2. If that message's fingerprint does not match a provided fingerprint, the id is treated as a miss.
3. With a fingerprint: one matching assistant message wins; otherwise the `messageOccurrence` match wins.
4. Otherwise `-32602`: `Fork point message <messageId> was not found in session <sessionId>`. No silent whole-session fork.

Only completed `assistant/message` events in the source log are candidates. A
running turn's in-flight stream is ignored. Subagent child sessions are not
forkable. The new session's `session/load` replay ends at the selected
assistant message. Tool-call blocks on that message are dropped, because their
results are logged after the message; earlier tool calls and results stay.

## Authentication metadata

Authentication metadata appears on advertised `authMethods` and on the
client's `authenticate` request. API keys and gateway authorization headers are
secrets; clients must not log or persist the request metadata as transcript
content.

### Advertised auth methods

Methods are advertised per declared client capability; a capability the client
does not declare hides the method it gates.

| Method | Gated on | Advertised metadata | Meaning |
|---|---|---|---|
| `api-key` | always (per provider: `api-key:<provider>`) | `_meta["api-key"] = {}` or `.provider: string` | Save an API key to the harness credential store. |
| `api-key:<provider>` | always | `_meta["api-key"].provider: string` | The API key belongs to the named provider route. |
| `terminal-login` | `clientCapabilities.auth.terminal === true` or `clientCapabilities._meta["terminal-auth"] === true` | standard terminal fields `args: ["login"]`, `env: {}` | Spec terminal login: the client appends `args` to its own configured agent command and runs it out of band; the method is never sent back to `authenticate`. |
| `terminal-login` | `clientCapabilities._meta["terminal-auth"] === true` | `_meta["terminal-auth"] = { command: string, args: string[], label: "dsh-acp login" }` | Optional verbatim launch spec for clients that run a concrete command (Zed's `terminal-auth` convention). `command`/`args` resolve to the running `dsh-acp` process. |
| `browser` | `clientCapabilities.elicitation.url` non-null | none | Local-page login whose URL is surfaced to the client via `elicitation/create` `mode: "url"` (see below). |
| `gateway` | `clientCapabilities.auth._meta.gateway === true` | `_meta.gateway.protocol: "openai"` | The gateway must expose an OpenAI-compatible endpoint. |
| `gateway` | same | `_meta.gateway.restartRequired: "false"` | Authentication takes effect without restarting the ACP process. The value is the compatibility contract's string literal, not a boolean. |

### `authenticate` request

An API-key request uses this shape:

```json
{
  "methodId": "api-key:anthropic",
  "_meta": {
    "api-key": {
      "apiKey": "<secret>",
      "provider": "anthropic"
    }
  }
}
```

`apiKey` is required when the client supplies credentials over ACP. `provider`
is optional when it is already encoded in `methodId`.

A custom gateway request uses this shape:

```json
{
  "methodId": "gateway",
  "_meta": {
    "gateway": {
      "baseUrl": "https://gateway.example.com/v1",
      "headers": {
        "Authorization": "Bearer <secret>"
      },
      "providerName": "company-gateway"
    }
  }
}
```

`baseUrl` and an `Authorization` header are required. `headers` accepts a
string-to-string record. `providerName` is an optional display and route name.

### Browser login url elicitation

When the client picks `browser` (or sends an `api-key` method without `_meta`
while url elicitation is supported), the adapter starts its local auth page
and sends a request-scoped `elicitation/create` in `mode: "url"`:

```json
{
  "mode": "url",
  "requestId": <id of the inbound authenticate request>,
  "elicitationId": "dsh-acp-auth-<n>",
  "url": "http://127.0.0.1:<port>/",
  "message": "Save your API key for DEEPSEEK_API_KEY. …",
  "_meta": {
    "dsh": {
      "auth": {
        "credential": "DEEPSEEK_API_KEY",
        "provider": "deepseek-official"
      }
    }
  }
}
```

`_meta.dsh.auth.provider` is omitted when the request targets the default
route. An `accept` response only means the client surfaced the URL; the
credential arrives through the page's own POST inside the page's bounded
timeout. A `decline`, `cancel`, page timeout, or any other failure ends the
request with `auth_required` (`-32000`) carrying `data.authMethods`, and the
adapter sends `elicitation/complete` with `{ "elicitationId": "dsh-acp-auth-<n>" }`
as the flow ends. Without `clientCapabilities.elicitation.url` the `browser`
method is not advertised and selecting it fails fast with the same error shape.

### `logout` request

`logout` is scoped to one provider route — the one named by
`_meta.provider` (a non-empty string) or, when omitted, the active provider
route. It removes that provider's stored API key and gateway base-URL
credential references only; other providers' credentials are untouched.

```json
{ "method": "logout", "params": { "_meta": { "provider": "anthropic" } } }
```

### `data.authMethods` on auth errors

Every auth-related `-32000` (`auth_required`) — from `initialize`,
`session/new`, `session/prompt`, or `authenticate` — carries
`error.data.authMethods`, the same capability-filtered list `initialize`
advertised, so the client can render its auth UI from any failure.

Typing a native auth command (`/login`, `/logout`, with or without
arguments) instead ends the turn normally: the adapter emits one
`agent_message_chunk` saying the command isn't available in this
environment — pointing at the client's sign-in (ACP auth methods) or
sign-out (ACP `logout`) — and returns `stopReason: "end_turn"`.
`auth_required` is never the answer to a typed auth command; the commands
are never in `availableCommands`, never reach the model or the harness
command registry, and typing them does not change credentials.

### `_auth/status_update` notification

The adapter pushes the current credential picture over `_meta.authStatus`
(ext-method `_auth/status_update`) after `initialize` and whenever the
credential store changes (a successful `authenticate`, `logout`, or an
out-of-band update such as terminal login or the Web UI). The marker
`agentCapabilities._meta.authStatus: {}` advertises the feed.

```json
{
  "authStatus": {
    "kind": "authenticated",
    "label": "DeepSeek · DEEPSEEK_API_KEY",
    "providers": [
      {
        "providerId": "deepseek-official",
        "name": "DeepSeek",
        "kind": "api_key",
        "label": "DEEPSEEK_API_KEY"
      }
    ]
  }
}
```

`kind` is `"none"` or `"authenticated"`. Each entry reports the active
method per provider: `kind` is `"api_key"` (stored key), `"gateway"` (stored
key plus base-URL), `"environment"` (ambient env), or `"other"`. `label` is
the credential-store name, never the secret. `kind: "none"` carries
`label: "Not logged in"` and an empty `providers` list; a single configured
provider is labelled `<name> · <credential name>`; several are labelled
`"<n> providers"`. The notification is deduplicated on the serialized
payload, so unchanged state is never re-pushed.

## Session update metadata

These blocks annotate standard ACP `session/update` payloads. Clients that do
not consume them still receive the normal ACP message, tool-call, terminal,
plan, and session fields.

### Native DSH tool result value

A successful `tool_call_update` can carry the tool's structured value before
DSH renders it into model-readable content:

```json
{
  "sessionUpdate": "tool_call_update",
  "toolCallId": "call_123",
  "status": "completed",
  "content": [
    {
      "type": "content",
      "content": {
        "type": "text",
        "text": "```sh\nstarted background job bash-1\n```\n"
      }
    }
  ],
  "rawOutput": {
    "output": "started background job bash-1",
    "isError": false
  },
  "_meta": {
    "dsh": {
      "toolResult": {
        "value": {
          "kind": "background",
          "jobId": "bash-1"
        }
      }
    }
  }
}
```

`content` and `rawOutput` are the normalized ACP result. They remain the result
shown to the model and to ordinary clients. `_meta.dsh.toolResult.value` is the
optional native value for programmatic clients; it is not a second model-visible
result.

Live updates use the exact `value` observed from DSH's `tools/result` event.
DSH deliberately omits that execution-local value from its durable session
event. During history replay, the adapter can restore the block only for the
documented background bash, background subagent, and continuable subagent
acknowledgements. Clients must not assume the block exists on every successful
result or replayed tool call.

### DSH event annotations

`_meta.dsh.event` discriminates metadata-only facts that have no dedicated ACP
session update. The accompanying fields depend on the event value.

| Event value | ACP update | Accompanying fields |
|---|---|---|
| `"assistant_message"` | `agent_message_chunk` | `model?: string`. The adapter emits this on the assembled-message boundary, including an empty chunk when text already streamed. |
| `"user/message"` | `session_info_update` | `source: string`, `preview: string`. This represents non-user context injected by a plugin or another harness source; `preview` is capped at 160 Unicode code points. |
| `"prompt/usage"` | `session_info_update` | `usage`, using ACP `Usage` fields: `totalTokens`, `inputTokens`, `outputTokens`, and optional `thoughtTokens`, `cachedReadTokens`, `cachedWriteTokens`. This is the final aggregate restored by history replay. |
| `"subagent/lifecycle"` | `session_info_update` | `subagent`, using the lifecycle shape below. |

The subagent lifecycle shape is:

```json
{
  "state": "started",
  "runId": "run-1",
  "childSessionId": "child-1",
  "provider": "local",
  "local": true,
  "parentToolCallId": "subagent:run-1"
}
```

`state` is `"started"` or `"finished"`. `parentToolCallId` is optional. A
finished lifecycle adds `stopReason: string`.

### Child transcript attribution

When the client advertises
`clientCapabilities._meta["subagent-transcript"]: true`, each forwarded child
update carries:

```json
{
  "_meta": {
    "dsh": {
      "subagent": {
        "childSessionId": "child-1",
        "parentToolCallId": "subagent:run-1",
        "provider": "local"
      }
    }
  }
}
```

The annotation lets a client group child output beneath the parent subagent
tool call without changing the standard ACP update type.

### Display terminal metadata

The terminal blocks are emitted only when the client advertises
`clientCapabilities._meta.terminal_output: true`.

| Block | ACP update | Shape |
|---|---|---|
| `_meta.terminal_info` | Initial `tool_call` | `{ terminal_id: string, cwd?: string }` |
| `_meta.terminal_output` | Streaming `tool_call_update` | `{ terminal_id: string, data: string }` |
| `_meta.terminal_exit` | Final `tool_call_update` | `{ terminal_id: string, exit_code: number, signal: string \| null }` |

These snake_case names belong to the existing display-terminal compatibility
contract. They are not DSH-owned names and must not be converted to camelCase.

## Command metadata

Entries in `available_commands_update.availableCommands` can carry
`_meta.commandAction`. This compatibility extension tells capable clients to
render a command as a UI action instead of inserting its slash command into the
prompt.

The plan-mode command uses:

```json
{
  "commandAction": {
    "kind": "setConfigOption",
    "configId": "collaboration_mode",
    "value": "plan",
    "resetValue": "default",
    "presentation": "state"
  }
}
```

The TUI-only plan viewer, advertised after Cordis protocol negotiation, uses:

```json
{
  "commandAction": {
    "kind": "clientCommand",
    "presentation": "view"
  }
}
```

## User-question elicitation metadata

A standard ACP `elicitation/create` form generated for a DSH user-question
request includes `_meta["dsh.userQuestions"]`. The standard form schema is
complete on its own; this block preserves the original DSH questions for
clients that provide a specialized renderer.

```json
{
  "_meta": {
    "dsh.userQuestions": {
      "version": 1,
      "questions": [
        {
          "id": "target",
          "question": "Where should this run?",
          "header": "Target",
          "detail": "Choose the deployment target.",
          "options": [
            {
              "label": "Local",
              "description": "Run on this machine."
            }
          ],
          "multiSelect": false
        }
      ]
    }
  }
}
```

Each question has required `id` and `question` strings. `header`, `detail`,
`options`, `multiSelect`, and `intent` are optional. Each option requires
`label` and can include `description`. The currently defined intent is
`{ kind: "plan-review", approve: string }`; unknown future intents must fall
back to the standard form presentation.

## Compatibility checklist

An ordinary ACP client can ignore this entire document and use the standard
fields. A client that consumes an extension should advertise its capability
when one exists, branch on the complete metadata path rather than display text,
treat every annotation as optional, and ignore fields it does not understand.
Authentication request metadata is the exception to ordinary transcript data:
it can contain secrets and must be handled as credential material.
