import assert from "node:assert/strict";
import { createServer } from "node:http";
import { spawn, execFileSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { createInterface } from "node:readline";

const [binary, archive] = process.argv.slice(2).map((path) => resolve(path));
assert(binary && archive, "usage: node scripts/profile-smoke.mjs DSH_BIN ACP_TARBALL");
const root = mkdtempSync(join(tmpdir(), "dsh-acp-profile-"));
const provider = createServer((request, response) => {
    request.resume();
    response.writeHead(200, { "Content-Type": "text/event-stream" });
    if (request.url?.endsWith("/messages")) {
        response.end([
            { type: "message_start", message: { usage: { input_tokens: 10, output_tokens: 0 } } },
            { type: "content_block_start", index: 0, content_block: { type: "text", text: "" } },
            { type: "content_block_delta", index: 0, delta: { type: "text_delta", text: "Saved." } },
            { type: "content_block_stop", index: 0 },
            { type: "message_delta", delta: { stop_reason: "end_turn" }, usage: { output_tokens: 3 } },
            { type: "message_stop" },
        ].map((event) => `event: ${event.type}\ndata: ${JSON.stringify(event)}\n\n`).join(""));
    } else {
        response.end([
            { id: "smoke", choices: [{ index: 0, delta: { role: "assistant", content: "Saved." }, finish_reason: null }] },
            { id: "smoke", choices: [{ index: 0, delta: {}, finish_reason: "stop" }] },
        ].map((chunk) => `data: ${JSON.stringify(chunk)}\n\n`).join("") + "data: [DONE]\n\n");
    }
});
await new Promise((resolve) => provider.listen(0, "127.0.0.1", resolve));
const env = {
    ...process.env,
    DSH_HOME: join(root, "home"),
    DSH_SESSION_ROOT: join(root, "sessions"),
    DEEPSEEK_API_KEY: "sk-test-profile-not-a-real-key",
    DEEPSEEK_BASE_URL: `http://127.0.0.1:${provider.address().port}`,
    DSH_TELEMETRY_DISABLED: "1",
};
delete env.DSH_PATH;
delete env.DSH_PERMISSION_MODE;
let child;
try {
    execFileSync(process.execPath, [binary, "plugin", "--profile", "acp", "add", archive], {
        cwd: root, env, stdio: "inherit", timeout: 180_000,
    });
    child = spawn(process.execPath, [binary, "--profile", "acp"], {
        cwd: root, env, stdio: ["pipe", "pipe", "pipe"],
    });
    child.stderr.pipe(process.stderr);
    const pending = new Map();
    let id = 0;
    const lines = createInterface({ input: child.stdout });
    lines.on("line", (line) => {
        let message;
        try { message = JSON.parse(line); } catch { return; }
        const waiter = pending.get(message.id);
        if (!waiter) return;
        pending.delete(message.id);
        clearTimeout(waiter.timer);
        if (message.error) waiter.reject(new Error(JSON.stringify(message.error)));
        else waiter.resolve(message.result);
    });
    child.on("exit", (code) => {
        for (const waiter of pending.values()) {
            clearTimeout(waiter.timer);
            waiter.reject(new Error(`dsh --profile exited: ${code}`));
        }
        pending.clear();
    });
    const request = (method, params) => new Promise((resolve, reject) => {
        const requestId = ++id;
        const timer = setTimeout(() => {
            pending.delete(requestId);
            reject(new Error(`timeout: ${method}`));
        }, 60_000);
        pending.set(requestId, { resolve, reject, timer });
        child.stdin.write(`${JSON.stringify({ jsonrpc: "2.0", id: requestId, method, params })}\n`);
    });
    const init = await request("initialize", { protocolVersion: 1, clientCapabilities: {} });
    assert.equal(init.agentInfo.name, "dsh-acp");
    const session = await request("session/new", { cwd: root, mcpServers: [] });
    assert(session.sessionId);
    await request("session/set_mode", { sessionId: session.sessionId, modeId: "read-only" });
    const plan = await request("session/set_config_option", {
        sessionId: session.sessionId, configId: "collaboration_mode", value: "plan",
    });
    assert.equal(plan.configOptions.find((option) => option.id === "collaboration_mode")?.currentValue, "plan");
    const status = await request("session/prompt", {
        sessionId: session.sessionId, prompt: [{ type: "text", text: "/status" }],
    });
    assert.equal(status.stopReason, "end_turn");
    // Older stores do not materialize command-only sessions. Commit a real
    // model turn before asserting cross-process persistence behavior.
    const turn = await request("session/prompt", {
        sessionId: session.sessionId, prompt: [{ type: "text", text: "Remember this session." }],
    });
    assert.equal(turn.stopReason, "end_turn");
    await request("session/close", { sessionId: session.sessionId });
    const listed = await request("session/list", { cwd: root });
    assert(listed.sessions.some((entry) => entry.sessionId === session.sessionId && entry.cwd === root));
    const loaded = await request("session/load", { sessionId: session.sessionId, cwd: root, mcpServers: [] });
    assert.equal(loaded.modes.currentModeId, "read-only");
    await request("session/close", { sessionId: session.sessionId });
    const resumed = await request("session/resume", { sessionId: session.sessionId, cwd: root, mcpServers: [] });
    assert.equal(resumed.modes.currentModeId, "read-only");
    console.log("PROFILE_SMOKE_OK");
} finally {
    if (child && child.exitCode === null && child.signalCode === null) {
        const exited = new Promise((resolve) => child.once("exit", resolve));
        child.kill("SIGKILL");
        await exited;
    }
    await new Promise((resolve) => provider.close(resolve));
    rmSync(root, { recursive: true, force: true });
}
