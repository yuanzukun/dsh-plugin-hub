# dsh-qwen38-local-qol 设计稿

> 一个 DSH 插件，让 **stock dsh（零核心补丁、零 pi-ai patchfile）** 跑好本地
> Qwen3.8 线（27B + Flash-Next；四服务器线：llama-server / NInfer / TabbyAPI / oMLX）：
> 逐请求 thinking 预算 + 长会话 compaction 不再被 thinking 吃满帽子。
>
> 内容来源 = 现网验证过的两条补丁链（compaction 9-file + reasoning 13-file），
> 从"每版 dsh 重切核心 diff"改造成"依赖公共缝的插件"。

## 1. 名字（已定）

**`dsh-qwen38-local-qol`**（用户两轮定名：先留 27b 防 Flash-Next 混淆 → 用户本机
Flash-Next 也好用 → 家族级命名，不锁尺寸；"qol" = 定位诚实：本地 Qwen 线的
生活质量层，不抢 dsh-dcp（确定性压缩）/ dsh-llamacpp（text-only adapter）生态位）。

- 仓库：`Yunado/dsh-qwen38-local-qol`（单包）
- tagline: "Local Qwen3.8 line for DeepSeek Harness: per-request thinking
  budgets + compaction that survives long thinking sessions. Four server lines
  (llama.cpp / NInfer / TabbyAPI / oMLX); Qwen3.8-Flash-Next runs on the same
  llama.cpp / TabbyAPI dialects (user-verified)."

### 家族兼容（Qwen3.8-Flash-Next，2026-08-26 发布）

Flash-Next = 超稀疏 MoE（125B 主模型 + 51B n-gram embedding，6B active/token，
"Qwen4 architecture preview"，262K ctx）。兼容 = **配置级**：

| 维度 | Flash-Next |
|---|---|
| server 路由 | llama.cpp（Unsloth `qwen4exp` 分支）/ vLLM / SGLang，全是 OpenAI 兼容 `/v1/chat/completions`，adapter 同 wire，改 `baseURL`/`model` |
| effort 方言 | Qwen3.8 家族模板统一支持 `reasoning_effort`/`enable_thinking`（家族默认 xhigh = 过度思考问题本身） |
| thinking budget | 服务端执行（llama `--reasoning-budget` / vLLM 机制）；服务端不支持则优雅降级（发送不报错） |
| compaction 半区 | summarizer 层行为，模型/架构无关 |
| NInfer | 暂无 Flash-Next 工件（0.5.0 只有 27B NVFP4）；Flash-Next 走 **TabbyAPI 线**（exllamav3，用户生产线验证）/ llama.cpp 线 |

## 2. 架构：一个包，两个 registration（都是 effects）

DSH 插件契约（cookbook `adding-a-package.md`）：plugin = `name/inject/apply/Config`，
所有贡献走 `ctx.effect()` / `ctx.on()`，registry `register()` 返回 disposer。

| 半区 | 缝 | 做法 |
|---|---|---|
| A：reasoning/effort | `ctx.llm.registerAdapter(['qwen38'], adapter)`（dsh-llamacpp 同款缝） | 自研 provider adapter：多方言 wire（llama.cpp / NInfer / TabbyAPI / oMLX，§5）+ 逐请求 thinking budget + vision + tools + reasoning_tokens usage。**不走 pi-ai**（pi-ai 补丁是 build-time 的，插件够不着） |
| B：compaction | compaction backend 缝（docs/subsystems/compaction.md："a tokenizer- or template-based backend is a sibling package implementing the same interface"；`summarize()` = sole subclass hook） | **subclass compaction-basic backend**，override `summarize(input, owner, abort)`：reasoning-off 派发 + 三裁剪（剥图 / 近 5 轮 reasoning / tool 结果 2000 字，逻辑从现有补丁原样搬），复用导出的 `frameSummary` / `summarizeWithLlm` 保住 warm-prefix 缓存重放 |

### 挂载（M0 判定后定稿。web profile 的 compaction 活体在 per-session preset，profile patch 够不着）

> **[已被 §13 取代]** 0.2.0-rc.2 起 agent preset 可被 bundle patch 直接声明：
> qwen38 preset（roster + compaction 行 + registry default）= `presets/qwen38.patch.yml`，
> boot 零写盘，setup 脚本退役。下面 M0 时代的目录生成方案保留作历史。

**M0 证据**（dump + 源码）：web profile root 层的 compaction 行（compaction-basic /
command-compact / tool-result-pruner）全被 dsh-web-app 补丁 `disabled: true`；
真正压缩 = standard agent preset 的 isolated group（preset 文件按原样 standing
mount，agent-presets 无 patch 流）。dsh-dcp 的 root 层接管只在 root 行开启的
profile（其 tui profile）有效。

因此两半区两个落点：

```yaml
# 用户 profile 的 cordis.patch.yml（示例 = 生产 ninfer 线：patch 行可显式声明各线几何）
- insert:
    - id: qwen38
      name: dsh-qwen38-local-qol
      config:
        baseURL: http://localhost:8082/v1
        model: qwen3.8-27b-nvfp4
        dialect: ninfer
        contextWindow: 262144
        maxTokens: 52428
        thinkingBudgets: { low: 4096, medium: 8192, xhigh: 16384 }   # 漏配档位回退 xhigh 值（thinking 开的请求永远带帽）
```

**包内 bundle patch 自带的新装块只有两个锚点字段**（`dialect: llamacpp` + `baseURL:
http://localhost:8080/v1`，c95e226 的"新装开在 llama 线"意图）；其余数值一律走 config.js
缺省单一事实源，plugin.test 的契约测试钉死这个形状防再漂移（历史上整块复制漂移进过 27B
残骸）。上面这种**完整几何块是用户在自己 profile 里手写/设置 tab 保存的形状**。内置新装默认统一 `{131072, 16384}`
（starter 值，任何本地服务都扛得住；用户按服务端真实 ctx 上调；client `LINE_WINDOW_DEFAULTS`
与 `DEFAULT_*` 常量同源，§13 的滑杆联动保证任何几何下触发点精确）。其余三线同形状，
仅 endpoint/model/dialect 不同。

```yaml
# compaction backend 行 → 用户 preset 缝（~/.dsh/.agent-presets/qwen38/agent.cordis.yml）
# 由 setup 脚本从【当前安装的】standard preset 生成（抄全量 + compaction 组内
# compaction-basic 行替换为我们的 backend 行）→ 跟版无手工漂移
- id: compaction
  name: cordis:group
  group: true
  isolate:
    compaction: true
    toolResultPruner: true
  config:
    - id: compaction-basic
      name: dsh-qwen38-local-qol      # ← 我们的 backend（subclass basic）
    - id: command-compact
      name: '@deepseek-ai/dsh-command-compact'
    - id: tool-result-pruner
      name: '@deepseek-ai/dsh-compaction-tool-result-pruner'
      config: { thresholdChars: 8192, headChars: 4096, tailChars: 1024 }
```

- `package.json` 带 `dsh.bundle.patch: ./cordis.patch.yml` → `dsh plugin add
  github:Yunado/dsh-qwen38-local-qol` 挂 provider 行；`npx dsh-qwen38-local-qol-setup`
  生成用户 preset（幂等 + 备份，dsh-dcp setup 同款）；GUI 选 `qwen38` preset。
- 离线验证 = `dsh --profile web --patch <yml> --dump-config`（root 层行落位已验：
  dump 538 行基线 provenance 全对；preset 层 = M1 headless boot 验证）。
- **M1 待核**：preset 目录的插件名解析（向上 node_modules 走查到不到
  profiles/web/node_modules）→ 备选 = 行内相对路径（preset 自带 lib，
  discovery.ts L246 "a row naming a file the preset ships resolves the way the mount will"）。

## 3. 缝证据（全部核实过）

| 缝 | 证据 |
|---|---|
| `summarize()` subclass hook | rc.2（b150a551b8）**与** alpha.3 都有：`protected async summarize(` + "sole subclass customization hook"；`summarizer.ts` 导出 `SummarizationInput` / `SummaryResult` / `summarizeWithLlm` / `frameSummary` |
| compaction 挂载语法 | fan56/dsh-dcp `cordis.patch.yml`：`- id: compaction-basic, disabled: true` + `- insert: - id: dsh-dcp, name: '@aiwayds/dsh-dcp'`；README："挂在 dsh 的压缩接口上，只替换'摘要'这一环，继承官方触发/保留/锁/tool-pairing"，65 测试 |
| provider adapter 缝 | jwilson411/dsh-llamacpp：`ctx.llm.registerAdapter(['llamacpp'], adapter)`；`LlmAdapter`/`LlmError`/`attributionHeaders`/`errorChain` 来自 `@deepseek-ai/dsh-llm`；text-only（vision/tool 块显式拒）；我们要做的正是它没做的部分 |
| 外部插件包结构 | 两个样板一致：`package.json`（type module、`dsh.bundle.patch`、peer+dev 双列 dsh 依赖、`overrides` 钉版、`node --test`）+ `cordis.patch.yml` + `lib/`（dsh-dcp）或 `src/`（dsh-llamacpp）+ README + LICENSE(MIT) |
| token meter 图像计价缝 | alpha.3 `LlmRuntime.imageRequestPricing`（packages/llm/llm/src/index.ts L659-660）对注册 adapter **无守卫调用** `adapter.imageRequestPricing(provider, model)`；rc.2 `LlmAdapter` 基类**没有**该方法 → rc.2 系 adapter 在 alpha.3 树下 `tokenMeter.measure()` 抛 `not a function`，被 compaction pre-step 的 catch 吞掉（`TargetPressureConfigError` 之外的错误只 warn 后继续）→ **压力压缩静默永不触发**（2026-09 长会话真机实测坐实，已补 adapter 实现） |

## 4. 配置 schema

### Provider `qwen38`

| 键 | 类型 | 默认 | 说明 |
|---|---|---|---|
| `baseURL` | string | `http://localhost:8080/v1`（llama）；四线缺省端口阶梯 8080/8081/8082/8083 | 含 `/v1`，不重复拼 |
| `model` | string | 必填 | 服务端 alias |
| `apiKey` | string | 无（不发 Authorization） | 或服务端 `--api-key` 同值 |
| `dialect` | `'ninfer' \| 'llamacpp' \| 'tabbyapi' \| 'omlx'` | 必填 | 决定 effort/budget 的 wire 位置（见 §5） |
| `contextWindow` | int | 必填 | 透传给 harness 路由 |
| `maxTokens` | int | 必填 | 映射 `max_tokens`（llama-server 不读 `max_completion_tokens`） |
| `thinkingBudgets` | `{low, medium, xhigh}` | `{4096, 8192, 16384}` | 逐请求预算，wire 字段名按方言分道（§5：llama `reasoning_budget_tokens`（需服务端带 `--reasoning-budget` 补丁/消息）/ NInfer 发送但由服务端 `--default-thinking-budget` 封顶 / TabbyAPI 原生接受 / oMLX 顶层 `thinking_budget`）；漏配档位回退 xhigh 值，thinking 开的请求永远带硬帽 |
| `vision` | bool | `true` | 图片块 → `image_url`（data URL） |

### Compaction `qwen38-compaction`

| 键 | 默认 | 说明 |
|---|---|---|
| `summarizeImages` | `'strip'` | 现有补丁 3 knob 原样（`'strip'\|'keep'`） |
| `summarizeReasoningKeepTurns` | `5` | `0` = 全剥 |
| `summarizeToolResultMaxChars` | `2000` | `0` = 不截 |
| `maxTokens` | 该线输出帽（starter `16384`） | 摘要帽 = 插件输出帽（绕开 preset isolated group 的 8192 死角：后端自持；联动几何见 §13） |

## 5. Wire 映射（多方言分道）

| 请求件 | `dialect: 'llamacpp'`（llama-server + froggeric v22.1 jinja 模板） | `dialect: 'ninfer'`（0.5.0） | `dialect: 'tabbyapi'`（ExLlamaV3） | `dialect: 'omlx'`（Apple Silicon MLX） |
|---|---|---|---|---|
| effort | `chat_template_kwargs.reasoning_effort`（模板 kwargs 白名单；顶层被忽略） | 顶层 `reasoning_effort` | 顶层 `reasoning_effort` | 顶层 `reasoning_effort` |
| effort off | `chat_template_kwargs.enable_thinking: false` | `reasoning_effort: 'none'` | `reasoning_effort: 'none'` | `chat_template_kwargs.enable_thinking: false` |
| thinking budget | `reasoning_budget_tokens`（服务端补丁输出 `completion_tokens_details.reasoning_tokens`） | 发送即忽略（服务端默认帽 16384） | `reasoning_budget_tokens`（原生按请求执行） | 顶层 `thinking_budget`（原生按请求执行，Pydantic model ChatCompletionRequest） |
| vision | `image_url`（服务端 `--image-min/max-tokens` 强制 resize） | `image_url`（客户端预缩 ≤1024 长边） | `image_url`（token meter 未钉，请求正常） | `image_url`（token meter 未钉，请求正常） |
| tools | 标准 `tools` 数组 + `tool_calls` 流 | 同左 | 同左 | 同左（OpenAI 兼容 `tool_calls` stream deltas） |
| maxTokens | `max_tokens` | `max_tokens` | `max_tokens` | `max_tokens` |

finish_reason 映射：`stop`→stop、`tool_calls`→tool-calls、`length`→**max-tokens**
（截断不当完成报，dsh-llamacpp 同款）。错误 = `LlmError` 稳定 code 表
（PROVIDER_UNREACHABLE / _HTTP_ERROR / _ERROR / _PROTOCOL_ERROR / UNSUPPORTED_CONTENT）。

## 6. 文件布局

```
dsh-qwen38-local-qol/                      （raw ESM + JSDoc，src 全 .js，无 TS）
  package.json        # dsh.bundle.patch + client.inject(locale) + peers(^0.1.1-rc.2) + node --test
  cordis.patch.yml    # §3 挂载（provider 行）
  src/
    index.js          # plugin：name/inject/apply/Config；adapter + settings 两个 effect
    adapter.js        # qwen38 LlmAdapter（stream 解析 + usage 映射 + imageRequestPricing）
    wire.js           # 四方言请求构建（§5 表）+ budget 回退/字段分道
    backend.js        # Qwen38CompactionBackend extends compaction-basic（override summarize）
    prepare.js        # summarize 前三裁剪（剥图 / 近 5 轮 reasoning / tool 结果 2000 字帽）
    config.js         # 两半区 schemastery schema + DEFAULT_* 常量
    settings-section.js # settings ns 注册（schema/entry/validate，跨字段 fail-loud）
    client.js         # 设置 tab 组件（四线记忆 + 按线 apiKey 掩码/眼睛 + 裁剪旋钮 + 压缩触发滑杆/帽联动）
    client-entry.js / client.css  # client 半区入口 + 样式
  lib/client.js       # esbuild 产物（CJS + load() 包装，web loader 按字节执行；改 src/client.js 后 scripts/build-client.mjs 重建并提交）
  test/               # node --test：wire/stream/prepare/settings-section/client-built/plugin/setup（142 用例）
  docs/               # 六图（server/tab/preset × en/cn）
  README.md           # 中英双语：安装/四线/wire 说明/验证
  DESIGN.md           # 本稿
  LICENSE             # MIT
```

## 7. 版本钉定

- peer/dev/overrides 钉 **`0.1.1-rc.2`**（npm latest；dsh-dcp 钉 rc.6、dsh-llamacpp
  钉 rc.2 同款策略）；`summarize()` 缝在 rc.2 已核实存在，alpha.3 树兼容性
  M0 实测（在 0.1.2-alpha.3 生产 profile 装插件跑一遍）。
- dsh 升版时：缝未变 → 只升 peer 钉定 + 跑测试；缝变了 → 单文件适配。
  **对比现状：每版重切 9+13-file 核心 diff（已切 3 次）。**

## 8. 测试计划（keyless，`node --test`）

1. dialect 构建：双方言 × {off, low, xhigh} 快照（含 enable_thinking:false 路径）
2. stream：mock server 覆盖 text-only / tool_calls 流 / usage(含 reasoning_tokens) /
   `length`→max-tokens / 非 2xx / 非 JSON frame / 图片块 / abort 透传
3. compaction：trim 三 knob（含 0 禁用）、reasoning-off 断言、frameSummary 输出
4. 挂载：patch 文件解析 + 行结构断言
5. 集成（M4，真机）：NInfer 线长会话 → compaction 触发 → checkpoint 无 thinking
   标签 + budget 逐请求生效证据（服务端日志）

## 9. 里程碑

| M | 内容 | 出口 |
|---|---|---|
| M0 | 缝验证 spike：① preset isolated compaction group 的 patch 语义（`id: compaction-basic` 行是否同时命中 isolated 组实例，Vali-D 8192 坑）② alpha.3 profile 装 rc.2-钉定插件的兼容性 | 结论 + 必要时挂载语法调整 |
| M1 | provider MVP：text + 双方言 effort/budget + 错误表 + 测试 | 真机 NInfer 一轮对话 |
| M2 | vision + tools round-trip + usage.reasoning_tokens + 测试补齐 | 真机带图 + 带工具轮 |
| M3 | compaction subclass + 挂载 + 测试 | 真机 /compact 手动触发成功 |
| M4 | 长会话压力：thinking 大帽下自动 compaction 通过 | 会话继续、checkpoint 干净 |
| M5 | README/keywords/发布（GitHub 仓 + npm 可选）+ discussion 3465 补评论 | 朋友 `dsh plugin add` 一条命令 |

## 10. 风险 / 开放项

1. **isolated compaction group**（最高风险）：standard preset 的 isolated 组若不受
   顶层 patch 行控制 → 挂载语法需按组定位（M0 定死）。
2. GUI 内置 effort picker 不显示（插件线 composer 无 effort 选项）→ 插件配置
   默认值兜底；要 picker 就还是走现网 pi-ai 补丁链（两条线可并存）。
3. 我们生产线迁移：插件与 pi-ai 链并存，迁移 = 后续 GO（不阻塞发布）。
4. dsh-dcp 生态位重叠：它是"零 LLM 确定性压缩"（不同卖点），我们在 README
   写明差异（我们要语义摘要 + 本地 thinking 模型场景）。
5. llama 线 `reasoning_tokens` usage 依赖 llama.cpp 服务端补丁（我们的 7 文件
   补丁）。无补丁时 usage 缺字段，插件容错（不报错，GUI 无逐轮 thinking 数）。

## 11. M6：设置 tab（配置全进 UI，2026-09）

> **[部分被 §13 取代]** rc.2 移除了 `SettingsProvider.installSection` 与
> `settings.get(ns)` 活读缝：设置存储迁到 profile 插件配置（Cordis patch +
> volatile 热提交），backend 经 entry-fiber 模块镜像读活配置。本节保留作 0.1.x 史。

用户诉求：设置里新一个 tab：**选 llama or ninfer** + 全参数表单（effort 预算 =
"reasoning effort 单独的 cap" + compaction 旋钮 + baseURL/model 等）。参考
样板 = dsh-ads（外部插件 client 半区 + settings.section 槽）。源码验证后的缝：

| 半区 | 缝 | 做法 |
|---|---|---|
| 宿主 | `SettingsProvider.installSection(owner, ns, schema, entry, {setSource, onChange, validate?})`（settings/src/index.ts L472，llm-pi-ai L296-310 同款惯用法） | `apply()` 内 `ctx.inject` 后注册 ns `qwen38-local-qol`；schema = schemastery 对象（字段名与 `resolveConfig` 输出一一对应，默认值镜像生产线；partial 自动填默认、未知键透传、错类型拒）；entry/base = **全量 resolved 行**（detach fallback 原样使用，必须含全字段）；跨字段校验（dialect / defaultEffort∈off+预算键 / summarize 旋钮）走 `validate`，写入时 fail-loud |
| 宿主 | adapter / compaction 活读 | `QwenLocalAdapter` 构造收**配置源 thunk**（`#config` 变 private getter，6 个读取点零改动）；`QwenLocalCompaction.summarize` 每次调用 `this.ctx.get('settings').get(NS)` 活读 `summarize` 块（无 ns 时落 env 链）。**不重注册**（route id 永不变，比 pi-ai 的动态重注册路径简单）→ 保存即下一请求生效，无需重启 |
| 浏览器 | `settings.section` 槽（ui-settings contract：owner 只给 `close`，数据自携） | `./client` 导出（raw ESM 无 JSX，settings.section 槽 + dsh.client manifest 自动发现，**不需要 web-app cordis 行**）；locale 注入 hook（zh/en 双字典，label 随 locale 重注册）。**bundle 格式坑（2026-09 真机坐实）**：web loader（client/modules Node 半区）把 `./client` 文件的**字节原样当 classic script 执行**，靠文件自己调 `window.__ModuleLoader__.load({ id, factory: require => {...} })` 注册；顶层 `import`/`export` 是 syntax error（dsh-ads 的 tsdown clientBundle 就是此格式）→ 我们的 raw ESM 必须经 esbuild（CJS、react external）+ load() 包装成 `lib/client.js`（scripts/build-client.mjs，产物提交，改 src/client.js 后 `pnpm run build:client`） |
| 浏览器 | 读写 | `ctx.remote.settings.describe()` 读 ns view（value+revision）；`update(ns, patch, revision)` 乐观写（响应 = 新 view，fold 回本地）；`settings/conflict` → 重新 describe + 提示；页内展示 revision |

schema 字段 = 配置表全量（dialect/baseURL/model/displayName/apiKey/contextWindow/
maxTokens/thinkingBudgets{low,medium,xhigh}/defaultEffort/thinkingLevelMap/includeUsage/
summarize{images,keepTurns,toolChars}）。优先级：tab（user 层）> 行/env > 内置默认；
无 settings provider（headless）时行为与 M5 完全一致。测试：settings-section 12
（schema 默认/校验）+ client 4（注册/load/save/conflict）+ plugin 活读 1（改源 →
下一 wire body 变）。

## 12. 发布态（release，v0.3.3 = 本 commit；M0-M6 全部落地后的现状注记）

- **四线**：ninfer / llamacpp / tabbyapi / oMLX（§5 表即现网 wire）；新装默认
  统一 `{131072, 16384}`（v0.3.1 starter，patch 行按服务端显式覆盖）；漏配档位回退 xhigh（thinking 开 = 永远带硬帽）。
- **新装块只带两行锚点**（v0.3.2）：bundle `cordis.patch.yml` 仅 `dialect: llamacpp` + `baseURL:
  http://localhost:8080/v1`，数值单一事实源 = config.js；四线缺省端口 8080/8081/8082/8083 互不撞车；
  plugin.test 契约测试禁止 patch 再出现数值。
- **preset 由 bundle patch 声明**（不再 boot 写盘：老 auto-apply 已退役）：qwen38
  preset + `default: qwen38` 注册行都随 patch insert，升级同 id 自动接管；GUI 选 qwen38 preset。
- **设置 tab（M6）已发布**：四线各自独立记忆（连接/窗口/预算/裁剪旋钮/**各自
  apiKey**（掩码输入 + 显隐眼睛））；summarize 图片处理默认 strip（旋钮默认关 = 裁图）、按线存
  值；热加载免重启；zh/en 双语。suite = 142 用例全绿。
- **视觉容量守卫**：adapter 实现 `imageRequestPricing`（ninfer (W/32)×(H/32)+2、
  llamacpp 钉 1536；ImageBlock 尺寸在 `attachment` 上、offloaded→0、缺维 ??1024，
  NaN 修复 7d67f1a，alpha.3 token meter 无守卫调用下压死静默压缩的毒源）。
- **公开露出**：discussion 3465 评论锚点 + plugin showcase #5390 活帖（release 内容
  + 徽章行 + awesome-dsh-plugin 深链）+ README 双徽章矩阵（awesome/dsh-plugin.org/
  MIT + dsh.so risk&install×2）+ topics 五件（dsh-plugin/deepseek-harness/qwen/
  llama-cpp/local-llm）。
- **遗留**（与 §10 一致）：GUI 内置 effort picker 不显示插件线（composer 无选项，
  配置默认值兜底）；TabbyAPI/oMLX 线 vision token 计价未钉（请求正常，仅预检容量
  投影缺失）；preset 缝 web-surface only（headless profile 仍走 core patch 路线）。

## 13. v0.3.x 发布态（DSH 0.2.0-rc.2 适配，2026-09-30）

- **兼容声明**：tested = 0.2.0-rc.2 与 0.2.1-alpha.1/alpha.2/rc.2 与 0.2.2-alpha.2（生产，v0.3.3 起；10-18 生产宿主升 `dsh-v0.2.1-rc.2`，10-30 升 `dsh-v0.2.2-alpha.2`，preset/设置 tab/活动线三缝生产实跑，压缩后端首触发待自然观察）；0.1.7-alpha.1..0.2.0-rc.1 = 同缝批次应可用未实测；
  ≤0.1.6-alpha.2 钉 v0.2.0。peer 钉 `^0.2.0-rc.2`；main 面向 0.2.2 名册线（v0.3.4 起）。
  **0.2.1-alpha.1 起上游移除内置 `{{cwd}}` 提示词变量**（upgrade guide：working-directory），preset persona suffix
  曾手写该变量 → alpha 宿主上每轮请求组装 fail-closed（"unknown prompt variable"，生产实炸）；v0.3.3 删 suffix
  （目录由宿主 working-directory 服务作为 user context 注入，手写子句既炸又冗余），plugin.test 加"仅允许
  provider/model 白名单变量"结构守卫。教训：宿主兼容核查 = 接口缝 diff **+ 本包文案对照上游 upgrade guide 的变量/键移除**，只看接口会漏。
- **v0.3.4（0.2.2-alpha.2 适配，2026-10-30）**：上游 4df09d37d5（首个含该提交的宿主 tag = `dsh-v0.2.2-alpha.2`）把 `list_agents` 并入 `tool-subagent-control` 主插件并删除 `./list-agents` 子路径导出（官方 standard 名册同步删行）；v0.3.3 的 qwen38 preset 仍引用该导出，条目 never started，preset 整体挂载被拒（registry default=qwen38 时新建会话全炸）。v0.3.4 删该行，并把 tool-subagent 已移除的 `backgroundMode`/`modelSelectionSettings` 键换成现行的 `modelSelection` + `modelDiscovery`（旧键被 schema 静默过滤，症状 = 丢失逐子模型选择与 `list_subagent_models`）。教训：宿主升级除接口缝 diff 外必须对照上游 preset 名册与工具 Config 键变更（工具打包重构对第三方 preset 是 breaking，与 `{{cwd}}` 事故同类）；plugin.test 已加退役导出/键结构守卫。
- **v0.3.5（插件图标，2026-10-31）**：`assets/icon.png`（256×256 PNG）+ package.json `icon` 字段；宿主 `app-boot/package-meta.ts` 读取规则 = 包内相对路径、SVG/PNG/JPEG/WebP、≤256KB，插件管理页与市场卡片展示。设计 = Qwen 官方花形 94% 占幅 + 中调靛蓝渐变（#7C86FF→#3D4BE8）、透明底无底板无角标，深浅主题对比全靠自发光中调图形（对齐官方插件 artwork 规范）；白色线稿源自 qwen-dark-white 压平版亮度→alpha 提取再着色。
- **preset 全声明化**：`presets/qwen38.patch.yml`（bundle patch list 第二件）声明完整 roster、
  卡片文案（rc.2 单串双语 "A / B"）、registry default。setup.js/`~/.dsh/.agent-presets` 生成链退役
  （v0.2.0 用户升级后旧目录惰性无害，可删）。
- **设置存储迁移**：真身 = profile 插件配置（Cordis patch + volatile 热提交）；client 读写
  `ctx.remote.settings.describe()/update(ns='qwen38'/*profile entry id*/, patch, revision)`；
  apply(ctx,config) 收到的是每个 .volatile() 叶子包成的 cosmokit 只读引用（plainConfig 解包）。
- **compaction 活读修复（v0.3.0 核心 fix）**：rc.2 的 SettingsForms 无 `get(ns)`，旧缝读恒
  undefined → 滑杆/trim 旋钮曾静默失效。修复 = entry-fiber apply() 把活 config 引用发布到
  backend 模块镜像（dispose 以引用相等守卫清理），settingsSection() = 镜像优先（每读 plainConfig
  解 volatile）→ legacy get(NS) → env。教训：rc.2 起插件配置只经 profile 条目 id，不按包 NS。
- **触发公式（滑杆=真实触发比例，帽双向联动）**：引擎判定 `floor(min(window×thresholdRatio, window − reserved − headroomTokens))`；
  qwen38 preset 行 `headroomTokens: 0`（stock 65536 会 clamp 触发点），backend 每轮评估覆盖为**线性墙护** `guard(O) = max(1024, min(O/4, (W−O)/4))`
  （O=W 输出帽；guard 是帽的安全 wiggle——帽大 guard 大、小窗帽被同步压小 guard 自动小，(W−O)/4 夹保证窄线/畸形配置触发点 ≥ ¾ 预算引擎永不抛错；
  1024 地板只护极小帽），ratio 直接 = `pct/100`（滑杆就是触发比例）。要让 `pct×W` 精确落地，须 `O + guard(O) = W×(100−pct)/100`，
  即 `O = floor(W×(100−pct)/125)`——**滑杆 onChange 双向写 maxTokens 到这个同步帽**，两分支恰好相交，**每一格都精确等于 pct%×W**：
  262K 线 50→帽 104,857/触发 131,072；80→41,943/209,715；83→35,651/217,582（=83.0%）。开环控制:判定尺子=上次请求 meter,
  guard=判定后增长(工具结果+注入,实测最坏单步 ~23K)的补偿带；pct 越高 guard 越小，超长单步偶触墙时宿主的 context-overflow
  重触发兜底。滑杆 `compactThresholdPct` UI 固定 50..90（schema 50..99 向后兼容），热生效每 step。
   **pct 随线**（v0.3.2）：`lines.<线>.compactThresholdPct` 可选字段（无 schema 默认，缺省 = 继承顶层），tab 保存写活动线的
   `lines` 块并把活动线值 mirror 到顶层（backend 只读顶层 leaf，零改动）；旧单值 profile 升级后各线先继承顶层旧值、行为不变，
   哪条线拖过滑杆才 park 自己的数。
- **帽联动的红 checker + budget<cap 校验**：同步帽若 < thinking 预算所需 room（`max(thinkingBudgets)+2048`，思考与回答共用帽），
  该触发点在此几何**根本落不了地**：cap park 在 room、状态区红 checker 点名所需帽值、**保存被拒**，直到调低预算或把滑杆调低。
  262K 线 xhigh 32768（room 34,816）：pct ≤83 全绿；84 起红（neededCap 33,554），park 34,816 → 有效触发 218,624（83.4%）。
  校验 fail-closed：`validateSection` 在写入即拒（顶层 + 每线：每个 thinkingBudgets 档与 defaultThinkingBudget 必须严格 <
  该线 maxTokens；每线 `compactThresholdPct` 若存在必须整数 50..99；trim 两旋钮 keepTurns/toolChars 为**非负**整数，0 = 关
  是该字段的文档化模式），client 保存路径同规则报错（budgetCap 文案；数字门与之对齐：几何与预算要求正、trim 旋钮允许 0，
  issue #4 的 tab 单边锁死已修）。既有生产 patch 全部通过（最紧 ninfer default 57344 < 65536），升级不破。
   `defaultThinkingBudget` = 服务端 thinking 上限的**申报值**（不发 wire；room 与校验读它）。仅 ninfer 线在设置页渲染该格
   （ninfer 无视逐请求预算，真实值只在启动参数里，申报是唯一真相渠道）；其他线三档表全覆盖，字段不渲染、保留存储兼容。
- **wire**：rc.2 一等 ToolResultMessage（role:'tool'）投影 + 摘要区 tool 消息上限 + control-token
  全角 scrub（strata #150 类事故上游已在 0.1.27 修复，scrub 保留护其余引擎）。
- **定案不做 wire 400 自愈**：上下文 400 的文案每引擎不同（strata `prompt (N tokens) + max tokens (M)
  exceeds the context (C)`、llama.cpp/NInfer/TabbyAPI/oMLX 各自另一套），解析错误文本不可靠；guard
  已在触发层掐死越墙路径，真越墙时宿主的 context-overflow 重触发（引擎无关）兜底。
- **待办候选（v0.3.x）**：guard 系数 1/4 常数的实测校准（读宿主每步注入量，替代拍定系数）；0.1.7-alpha 线实测升格兼容行 + dsh.so 矩阵刷新；
  GUI 编辑 patch-declared preset 的存储落点待测。
