/**
 * The user-settings section: namespace id, schema defaults mirroring the
 * production line, and the cross-field validation the schema cannot express.
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { NS, sectionSchema, validateSection } from '../src/settings-section.js'
import {
  DEFAULT_BASE_URL,
  DEFAULT_CONTEXT_WINDOW,
  DEFAULT_LLAMA_BASE_URL,
  DEFAULT_LLAMA_MODEL,
  DEFAULT_MAX_TOKENS,
  DEFAULT_MODEL,
  DEFAULT_OMLX_BASE_URL,
  DEFAULT_OMLX_CONTEXT_WINDOW,
  DEFAULT_OMLX_MAX_TOKENS,
  DEFAULT_OMLX_MODEL,
  DEFAULT_THINKING_BUDGETS,
} from '../src/config.js'
import { DEFAULT_TRIM_KNOBS } from '../src/prepare.js'

test('NS: the plugin owns one lowercase hyphenated namespace', () => {
  assert.equal(NS, 'qwen38-local-qol')
})

test('validateSection: an out-of-range compaction trigger fails loud', () => {
  assert.throws(() => validateSection({ compactThresholdPct: 49 }), /compactThresholdPct/)
  assert.throws(() => validateSection({ compactThresholdPct: 100 }), /compactThresholdPct/)
  assert.throws(() => validateSection({ compactThresholdPct: 80.5 }), /compactThresholdPct/)
  validateSection({ compactThresholdPct: 50 })
  validateSection({ compactThresholdPct: 99 })
})

test('validateSection: every thinking budget must stay below the output cap', () => {
  // Top level: a budget at or over the cap shares the same wire cap as the
  // answer, so it is refused at the write.
  assert.throws(() => validateSection({ maxTokens: 20480, thinkingBudgets: { xhigh: 32768 } }), /thinkingBudgets\["xhigh"\]/)
  assert.throws(() => validateSection({ maxTokens: 20480, thinkingBudgets: { xhigh: 20480 } }), /thinkingBudgets\["xhigh"\]/)
  assert.throws(() => validateSection({ maxTokens: 8192, thinkingBudgets: { low: 4096 }, defaultThinkingBudget: 8192 }), /defaultThinkingBudget/)
  validateSection({ maxTokens: 20480, thinkingBudgets: { low: 4096, medium: 8192, xhigh: 16384 }, defaultThinkingBudget: 8192 })
  // Per line: the same check rides each parked line's own cap.
  assert.throws(() => validateSection({ lines: { ninfer: { maxTokens: 40960, thinkingBudgets: { xhigh: 57344 } } } }), /lines\.ninfer\.thinkingBudgets/)
  assert.throws(() => validateSection({ lines: { ninfer: { maxTokens: 57344, defaultThinkingBudget: 57344 } } }), /lines\.ninfer\.defaultThinkingBudget/)
  // The production ninfer shape (hardcoded 57344 default under a 65536 cap) passes.
  validateSection({ lines: { ninfer: { maxTokens: 65536, thinkingBudgets: { low: 8192, medium: 32768, xhigh: 32768 }, defaultThinkingBudget: 57344 } } })
})

test('sectionSchema: a fully-default value opens on the general default (llama.cpp line)', () => {
  const schema = sectionSchema()
  const resolved = schema({})
  assert.equal(resolved.dialect, 'llamacpp')
  assert.equal(resolved.baseURL, DEFAULT_LLAMA_BASE_URL)
  assert.equal(resolved.model, DEFAULT_LLAMA_MODEL)
  assert.equal(resolved.displayName, '')
  assert.equal(resolved.apiKey, '')
  assert.equal(resolved.contextWindow, DEFAULT_CONTEXT_WINDOW)
  assert.equal(resolved.maxTokens, DEFAULT_MAX_TOKENS)
  assert.deepEqual(resolved.thinkingBudgets, DEFAULT_THINKING_BUDGETS)
  assert.equal(resolved.defaultThinkingBudget, DEFAULT_THINKING_BUDGETS.xhigh)
  assert.equal(resolved.defaultEffort, 'medium')
  assert.deepEqual(resolved.thinkingLevelMap, {})
  assert.equal(resolved.includeUsage, true)
  assert.equal(resolved.summarize.images, DEFAULT_TRIM_KNOBS.images)
  assert.equal(resolved.summarize.keepTurns, DEFAULT_TRIM_KNOBS.keepTurns)
  assert.equal(resolved.summarize.toolChars, DEFAULT_TRIM_KNOBS.toolChars)
})

test('sectionSchema: partial user layers fill the missing fields', () => {
  const schema = sectionSchema()
  const resolved = schema({ dialect: 'llamacpp', baseURL: 'http://localhost:8080/v1' })
  assert.equal(resolved.dialect, 'llamacpp')
  assert.equal(resolved.baseURL, 'http://localhost:8080/v1')
  assert.equal(resolved.model, DEFAULT_LLAMA_MODEL)
  assert.equal(resolved.contextWindow, DEFAULT_CONTEXT_WINDOW)
})

test('sectionSchema: lines carry each dialect production defaults (connection + window + thinking budget + trim knobs)', () => {
  const resolved = sectionSchema()({})
  assert.deepEqual(resolved.lines.ninfer, {
    baseURL: DEFAULT_BASE_URL,
    model: DEFAULT_MODEL,
    displayName: '',
    apiKey: '',
    contextWindow: DEFAULT_CONTEXT_WINDOW,
    maxTokens: DEFAULT_MAX_TOKENS,
    thinkingBudgets: { ...DEFAULT_THINKING_BUDGETS },
    defaultThinkingBudget: DEFAULT_THINKING_BUDGETS.xhigh,
    summarize: { ...DEFAULT_TRIM_KNOBS },
  })
  assert.equal(resolved.lines.llamacpp.baseURL, DEFAULT_LLAMA_BASE_URL)
  assert.equal(resolved.lines.llamacpp.model, DEFAULT_LLAMA_MODEL)
  assert.equal(resolved.lines.llamacpp.contextWindow, DEFAULT_CONTEXT_WINDOW)
  assert.equal(resolved.lines.llamacpp.maxTokens, DEFAULT_MAX_TOKENS)
  assert.equal(resolved.lines.omlx.baseURL, DEFAULT_OMLX_BASE_URL)
  assert.equal(resolved.lines.omlx.model, DEFAULT_OMLX_MODEL)
  assert.equal(resolved.lines.omlx.contextWindow, DEFAULT_OMLX_CONTEXT_WINDOW)
  assert.equal(resolved.lines.omlx.maxTokens, DEFAULT_OMLX_MAX_TOKENS)
})

test('sectionSchema: a user-saved line persists over its own defaults', () => {
  const resolved = sectionSchema()({
    lines: { llamacpp: { baseURL: 'http://localhost:9999/v1', model: 'some-alias', displayName: 'LLM', apiKey: 'sk-line-key', contextWindow: 131072, defaultThinkingBudget: 32768, summarize: { images: 'keep', keepTurns: 3, toolChars: 1000 } } },
  })
  assert.equal(resolved.lines.llamacpp.baseURL, 'http://localhost:9999/v1')
  assert.equal(resolved.lines.llamacpp.model, 'some-alias')
  assert.equal(resolved.lines.llamacpp.displayName, 'LLM')
  assert.equal(resolved.lines.llamacpp.apiKey, 'sk-line-key')
  assert.equal(resolved.lines.ninfer.apiKey, '')
  assert.equal(resolved.lines.llamacpp.contextWindow, 131072)
  assert.equal(resolved.lines.llamacpp.maxTokens, DEFAULT_MAX_TOKENS)
  assert.equal(resolved.lines.llamacpp.defaultThinkingBudget, 32768)
  assert.equal(resolved.lines.llamacpp.summarize.images, 'keep')
  assert.equal(resolved.lines.llamacpp.summarize.keepTurns, 3)
  assert.equal(resolved.lines.llamacpp.summarize.toolChars, 1000)
  // The untouched line keeps its defaults.
  assert.equal(resolved.lines.ninfer.contextWindow, DEFAULT_CONTEXT_WINDOW)
  assert.equal(resolved.lines.ninfer.defaultThinkingBudget, DEFAULT_THINKING_BUDGETS.xhigh)
  assert.equal(resolved.lines.omlx.contextWindow, DEFAULT_OMLX_CONTEXT_WINDOW)
  assert.equal(resolved.lines.omlx.maxTokens, DEFAULT_OMLX_MAX_TOKENS)
})

test('sectionSchema: a wrong-typed line field is rejected', () => {
  assert.throws(() => sectionSchema()({ lines: { ninfer: { baseURL: 42 } } }))
  assert.throws(() => sectionSchema()({ lines: { ninfer: { contextWindow: 'wide' } } }))
})

test('validateSection: a non-positive parked line window fails loud', () => {
  const value = { ...sectionSchema()({}), lines: { llamacpp: { ...sectionSchema()({}).lines.llamacpp, maxTokens: 0 } } }
  assert.throws(() => validateSection(value), /lines\.llamacpp\.maxTokens/)
})

test('validateSection: a non-positive parked line budget fails loud', () => {
  const value = {
    ...sectionSchema()({}),
    lines: { ninfer: { ...sectionSchema()({}).lines.ninfer, thinkingBudgets: { low: 4096, medium: -1, xhigh: 16384 } } },
  }
  assert.throws(() => validateSection(value), /lines\.ninfer\.thinkingBudgets\["medium"\]/)
})

test('validateSection: a non-positive parked line defaultThinkingBudget fails loud', () => {
  const value = { ...sectionSchema()({}), lines: { llamacpp: { ...sectionSchema()({}).lines.llamacpp, defaultThinkingBudget: 0 } } }
  assert.throws(() => validateSection(value), /lines\.llamacpp\.defaultThinkingBudget must be a positive integer/)
})

test('sectionSchema: a line block carries NO trigger percent default (absent = follow the top level)', () => {
  const resolved = sectionSchema()({})
  assert.equal(resolved.lines.ninfer.compactThresholdPct, undefined)
  assert.equal(resolved.lines.omlx.compactThresholdPct, undefined)
})

test('validateSection: a parked line trigger percent out of range fails loud', () => {
  const withPct = (pct) => ({
    ...sectionSchema()({}),
    lines: { ninfer: { ...sectionSchema()({}).lines.ninfer, compactThresholdPct: pct } },
  })
  assert.throws(() => validateSection(withPct(49)), /lines\.ninfer\.compactThresholdPct must be an integer 50\.\.99/)
  assert.throws(() => validateSection(withPct(100)), /lines\.ninfer\.compactThresholdPct/)
  assert.throws(() => validateSection(withPct(70.5)), /lines\.ninfer\.compactThresholdPct/)
  assert.doesNotThrow(() => validateSection(withPct(71)))
})

test('validateSection: an unknown parked line summarize.images policy fails loud', () => {
  const value = {
    ...sectionSchema()({}),
    lines: { ninfer: { ...sectionSchema()({}).lines.ninfer, summarize: { images: 'squish', keepTurns: 5, toolChars: 2000 } } },
  }
  assert.throws(() => validateSection(value), /lines\.ninfer\.summarize\.images must be/)
})

test('sectionSchema: wrong-typed fields are rejected', () => {
  const schema = sectionSchema()
  assert.throws(() => schema({ contextWindow: 'wide' }))
  assert.throws(() => schema({ includeUsage: 'yes' }))
})

test('sectionSchema: unknown keys pass through (a row base may carry `provider`)', () => {
  const schema = sectionSchema()
  const resolved = schema({ provider: ['qwen38'] })
  assert.deepEqual(resolved.provider, ['qwen38'])
})

test('validateSection: the production line passes', () => {
  const defaults = sectionSchema()({})
  assert.doesNotThrow(() => validateSection(defaults))
})

test('validateSection: the omlx dialect line passes', () => {
  const omlxSection = {
    ...sectionSchema()({}),
    dialect: 'omlx',
    baseURL: DEFAULT_OMLX_BASE_URL,
    model: DEFAULT_OMLX_MODEL,
    contextWindow: DEFAULT_OMLX_CONTEXT_WINDOW,
    maxTokens: DEFAULT_OMLX_MAX_TOKENS,
  }
  assert.doesNotThrow(() => validateSection(omlxSection))
})

test('validateSection: an invalid omlx line knob fails loud', () => {
  const bad = {
    ...sectionSchema()({}),
    lines: {
      ...sectionSchema()({}).lines,
      omlx: { ...sectionSchema()({}).lines.omlx, contextWindow: -1 },
    },
  }
  assert.throws(() => validateSection(bad), /lines\.omlx\.contextWindow/)
})

test('validateSection: an unknown dialect fails loud', () => {
  const value = { ...sectionSchema()({}), dialect: 'mistral' }
  assert.throws(() => validateSection(value), /dialect must be/)
})

test('validateSection: a defaultEffort without a declared budget fails loud', () => {
  const value = { ...sectionSchema()({}), defaultEffort: 'high' }
  assert.throws(() => validateSection(value), /defaultEffort "high" is not a declared effort/)
})

test('validateSection: off is always a valid defaultEffort', () => {
  const value = { ...sectionSchema()({}), defaultEffort: 'off' }
  assert.doesNotThrow(() => validateSection(value))
})

test('validateSection: a non-positive budget fails loud', () => {
  const value = { ...sectionSchema()({}), thinkingBudgets: { low: 0, medium: 8192, xhigh: 16384 } }
  assert.throws(() => validateSection(value), /thinkingBudgets\["low"\]/)
})

test('validateSection: a non-positive defaultThinkingBudget fails loud', () => {
  const value = { ...sectionSchema()({}), defaultThinkingBudget: 0 }
  assert.throws(() => validateSection(value), /defaultThinkingBudget must be a positive integer/)
})

test('validateSection: an unknown summarize.images policy fails loud', () => {
  const value = { ...sectionSchema()({}), summarize: { images: 'squish', keepTurns: 5, toolChars: 2000 } }
  assert.throws(() => validateSection(value), /summarize\.images must be/)
})

test('validateSection: negative summarize knobs fail loud', () => {
  const value = { ...sectionSchema()({}), summarize: { images: 'strip', keepTurns: -1, toolChars: 2000 } }
  assert.throws(() => validateSection(value), /summarize\.keepTurns must be/)
})

test('sectionSchema: the compaction wiring status defaults to unset', () => {
  const resolved = sectionSchema()({})
  assert.deepEqual(resolved.compaction, { presetGenerated: false, defaultPreset: 'standard' })
})

test('validateSection: a hand-edited compaction status fails loud', () => {
  assert.throws(() => validateSection({ ...sectionSchema()({}), compaction: { presetGenerated: 'yes', defaultPreset: 'standard' } }), /presetGenerated must be a boolean/)
  assert.throws(() => validateSection({ ...sectionSchema()({}), compaction: { presetGenerated: true, defaultPreset: '' } }), /defaultPreset must be a non-empty string/)
})
