import { Context } from '@deepseek-ai/cordis'
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest'
import { startPowerContextServer } from '../../scripts/e2e-server.mjs'
import {
  FIBER_ACTIVE,
  FIBER_PENDING,
  mountRequiredServices,
  registeredNames,
  registryOf,
  remountCommands,
} from '../helpers/cordis-host.ts'

vi.mock('../../src/peers.ts', () => ({
  loadPeer: async (specifier: string) => {
    if (specifier === '@deepseek-ai/dsh-tools') return { defineTool: (definition: unknown) => definition }
    if (specifier === '@deepseek-ai/dsh-llm') return { createUserMessage: (input: unknown) => input }
    throw new Error(`unexpected peer ${specifier}`)
  },
  profileNodeModulesDir: () => '',
}))

const { apply, inject, name } = await import('../../src/index.ts')

const plugin = { name, inject, apply }
const SCOPE_ID = 'project:dsh-e2e-lifecycle'

describe('Cordis lifecycle against a real PowerContext server', () => {
  let server: Awaited<ReturnType<typeof startPowerContextServer>>

  beforeAll(async () => {
    server = await startPowerContextServer()
  }, 60_000)

  afterAll(async () => {
    await server?.stop()
  })

  it('keeps /pc working after commands unload and remount', async () => {
    const ctx = new Context()
    const services = await mountRequiredServices(ctx)
    const loaded = await ctx.plugin(plugin, {
      baseUrl: server.baseUrl,
      scopeId: SCOPE_ID,
      requestTimeoutMs: 5000,
    })
    expect(loaded.state).toBe(FIBER_ACTIVE)
    await expectDoctor(ctx)

    await services.commands.dispose()
    await loaded.await()
    expect(loaded.state).toBe(FIBER_PENDING)
    expect(registeredNames(ctx, 'commands')).toEqual([])

    await remountCommands(ctx)
    await loaded.await()
    expect(loaded.state).toBe(FIBER_ACTIVE)
    expect(registeredNames(ctx, 'commands')).toEqual(['pc'])
    expect(registeredNames(ctx, 'skills')).toEqual(['project-context'])
    expect(registeredNames(ctx, 'systemPrompt')).toEqual(['tool:powercontext'])
    await expectDoctor(ctx)
    await ctx.fiber.dispose()
  })
})

async function expectDoctor(ctx: Context): Promise<void> {
  const command = registryOf(ctx, 'commands')?.items.get('pc') as {
    handler: (invocation: {
      rawInput: string
      signal: AbortSignal
      agent: { session: { header: { cwd?: string } } }
    }) => Promise<{ kind: string; text: string }>
  } | undefined
  if (!command) throw new Error('expected /pc after remount')
  const result = await command.handler({
    rawInput: 'doctor',
    signal: AbortSignal.timeout(5000),
    agent: { session: { header: {} } },
  })
  expect(result.kind).toBe('success')
  expect(JSON.parse(result.text).ok).toBe(true)
}
