import { Context, Service, type Fiber } from '@deepseek-ai/cordis'

export const FIBER_PENDING = 0
export const FIBER_ACTIVE = 2

type NamedItem = Record<string, unknown> & { name: string }

function createRegistryHost(serviceName: string) {
  return class RegistryHost extends Service {
    readonly items = new Map<string, NamedItem>()

    constructor(ctx: Context) {
      super(ctx, serviceName)
    }

    register(item: NamedItem) {
      return this.ctx.effect(() => {
        this.items.set(item.name, item)
        return () => {
          this.items.delete(item.name)
        }
      })
    }

    section(item: NamedItem) {
      return this.register(item)
    }
  }
}

export const CommandsHost = createRegistryHost('commands')
export const SkillsHost = createRegistryHost('skills')
export const ToolsHost = createRegistryHost('tools')
export const SystemPromptHost = createRegistryHost('systemPrompt')

export type RegistryHost = InstanceType<typeof CommandsHost>

export function registryOf(ctx: Context, name: string): RegistryHost | undefined {
  return ctx.get(name) as RegistryHost | undefined
}

export function registeredNames(ctx: Context, name: string): string[] {
  return [...(registryOf(ctx, name)?.items.keys() ?? [])]
}

export async function mountRequiredServices(ctx: Context): Promise<{
  commands: Fiber
  skills: Fiber
  tools: Fiber
  systemPrompt: Fiber
}> {
  const commands = await ctx.plugin(CommandsHost)
  const skills = await ctx.plugin(SkillsHost)
  const tools = await ctx.plugin(ToolsHost)
  const systemPrompt = await ctx.plugin(SystemPromptHost)
  ctx.provide('agents', { name: 'agents' })
  return { commands, skills, tools, systemPrompt }
}

export async function remountCommands(ctx: Context): Promise<Fiber> {
  return ctx.plugin(CommandsHost)
}
