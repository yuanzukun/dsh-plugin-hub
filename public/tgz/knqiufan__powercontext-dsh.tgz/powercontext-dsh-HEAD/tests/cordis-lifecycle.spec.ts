import { Context } from '@deepseek-ai/cordis'
import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  CommandsHost,
  FIBER_ACTIVE,
  FIBER_PENDING,
  mountRequiredServices,
  registeredNames,
  remountCommands,
} from './helpers/cordis-host.ts'

vi.mock('../src/peers.ts', () => ({
  loadPeer: async (specifier: string) => {
    if (specifier === '@deepseek-ai/dsh-tools') return { defineTool: (definition: unknown) => definition }
    if (specifier === '@deepseek-ai/dsh-llm') return { createUserMessage: (input: unknown) => input }
    throw new Error(`unexpected peer ${specifier}`)
  },
  profileNodeModulesDir: () => '',
}))

const { apply, inject, name } = await import('../src/index.ts')

const plugin = { name, inject, apply }

describe('real Cordis apply → unload → remount', () => {
  const fibers: Array<{ dispose: () => Promise<void> }> = []

  afterEach(async () => {
    for (const fiber of [...fibers].reverse()) {
      await fiber.dispose().catch(() => undefined)
    }
    fibers.length = 0
  })

  it('waits for injected services before apply registers surfaces', async () => {
    const ctx = new Context()
    fibers.push(ctx.fiber)
    const partial = await mountRequiredServices(ctx)
    await partial.commands.dispose()
    const pending = await ctx.plugin(plugin, { scopeId: 'project:lifecycle' })
    expect(pending.state).toBe(FIBER_PENDING)
    expect(registeredNames(ctx, 'skills')).toEqual([])
    expect(registeredNames(ctx, 'systemPrompt')).toEqual([])

    await ctx.plugin(CommandsHost)
    await pending.await()
    expect(pending.state).toBe(FIBER_ACTIVE)
    expectSurfaces(ctx)
  })

  it('unloads and remounts /pc, skill, and guidance when commands disappears', async () => {
    const ctx = new Context()
    fibers.push(ctx.fiber)
    const services = await mountRequiredServices(ctx)
    const loaded = await ctx.plugin(plugin, { scopeId: 'project:lifecycle' })
    expect(loaded.state).toBe(FIBER_ACTIVE)
    expectSurfaces(ctx)

    await services.commands.dispose()
    await loaded.await()
    expect(loaded.state).toBe(FIBER_PENDING)
    expect(registeredNames(ctx, 'commands')).toEqual([])
    expect(registeredNames(ctx, 'skills')).toEqual([])
    expect(registeredNames(ctx, 'systemPrompt')).toEqual([])

    await remountCommands(ctx)
    await loaded.await()
    expect(loaded.state).toBe(FIBER_ACTIVE)
    expectSurfaces(ctx)
    expect(registeredNames(ctx, 'tools')).toContain('pc_search')
  })
})

function expectSurfaces(ctx: Context): void {
  expect(registeredNames(ctx, 'commands')).toEqual(['pc'])
  expect(registeredNames(ctx, 'skills')).toEqual(['project-context'])
  expect(registeredNames(ctx, 'systemPrompt')).toEqual(['tool:powercontext'])
}
