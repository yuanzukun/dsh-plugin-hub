import { PLUGIN_NAME } from './errors.ts'

export function requireService<T>(
  ctx: { get: (name: string) => unknown },
  name: string,
): T {
  const service = ctx.get(name)
  if (service == null) {
    throw new Error(`${PLUGIN_NAME} requires the "${name}" service`)
  }
  return service as T
}
