// host/dsh-port.ts 适配层的规格测试（M4 Step 2 · 测试先行）。
//
// makeDshPort 把宿主服务面（src/host/dsh-api.ts，A 路线进程内范式）
// 适配成 core 的 DshPort 契约（M3 冻结：createSession/getSessionStatus/ask）。
// 规格全部来自实测事实：
// - 探针互证：活会话 get / 冷会话 resume / ghost 抛
//   SessionPersistenceNotFoundError / create 必带 agentOptions / rename 收
//   Session 对象 / attach 前目录必须存在
// - 源码事实：text-delta 增量拼接、turn/end 五态、abort 后会话不污染
//
// 测试策略：makeFakeDshHost 驱动（回调签名与真宿主一致，适配层代码
// 可无差异复用）；mkdir 注入为记录型 no-op（host 层允许真 IO，但测试
// 不落盘）。

import { describe, expect, it } from 'vitest';
import { asSessionId } from '@/core/types/dsh';
import { asHostSessionId } from '@/host/dsh-api';
import type { HostAgent } from '@/host/dsh-api';
import { makeDshPort } from '@/host/dsh-port';
import { makeFakeDshHost } from '../helpers/fake-dsh-api';

// ---------------------------------------------------------------------------
// 组装
// ---------------------------------------------------------------------------

function makePort(options: { askTimeoutMs?: number } = {}) {
  const host = makeFakeDshHost();
  const mkdirCalls: string[] = [];
  const port = makeDshPort({
    services: host.services,
    events: host, // fake 的 on 与真宿主 ctx.on 同签名
    dataRoot: '/data/root',
    ...(options.askTimeoutMs === undefined ? {} : { askTimeoutMs: options.askTimeoutMs }),
    // 注入 no-op mkdir：只记录路径，不真建目录
    mkdir: async (dir) => {
      mkdirCalls.push(dir);
    },
  });
  return { host, port, mkdirCalls };
}

/** 跑完一次 ask 并收集片段。 */
async function collectAsk(
  stream: AsyncIterable<string>,
): Promise<{ parts: string[]; text: string }> {
  const parts: string[] = [];
  for await (const part of stream) parts.push(part);
  return { parts, text: parts.join('') };
}

/** 带 agentPresets fake 的组装（preset 用例）。 */
function makePortWithPresets(
  options: {
    readonly resolveThrows?: Error;
  } = {},
) {
  const base = makePort();
  const calls: { resolved?: string; mounted?: { id: string } } = {};
  (base.host.services as { agentPresets: unknown }).agentPresets = {
    resolve: async (id?: string) => {
      calls.resolved = id;
      if (options.resolveThrows) throw options.resolveThrows;
      return { id: id ?? 'host-default' };
    },
    mount: async (_ctx: unknown, id: string) => {
      calls.mounted = { id };
      return undefined;
    },
  };
  const warnings: Array<{ event: string; fields?: Record<string, unknown> }> = [];
  const port = makeDshPort({
    services: base.host.services,
    events: base.host,
    dataRoot: '/data/root',
    mkdir: async () => undefined,
    log: { warn: (event, fields) => warnings.push({ event, fields: { ...fields } }) },
  });
  return { ...base, calls, warnings, port };
}

describe('dsh-port · createSession with agent preset', () => {
  it('resolves and mounts the preset, recording it in session meta', async () => {
    const h = makePortWithPresets();

    await h.port.createSession({ workspaceDir: 'ws/a', name: 'imessage a', preset: 'dafeiyu' });

    expect(h.calls.resolved).toBe('dafeiyu');
    expect(h.calls.mounted).toEqual({ id: 'dafeiyu' });
    // 会话创建带上了 meta.agentPreset（持久化记账，resume 保持同组合）
    const create = h.host.log.find((c) => c.kind === 'agents.create');
    expect(create?.meta).toMatchObject({ agentPreset: 'dafeiyu' });
    // setup 真的被调用了（组合挂载是人设生效的唯一路径）
    expect(create?.setupRan).toBe(true);
  });

  it('falls back to the host default when the preset service is absent', async () => {
    const { host } = makePort();
    // fake 宿主默认带 agentPresets：本用例显式摘除，模拟无该服务的宿主
    delete (host.services as { agentPresets?: unknown }).agentPresets;
    const warnings: Array<{ event: string; fields?: Record<string, unknown> }> = [];
    const logged = makeDshPort({
      services: host.services,
      events: host,
      dataRoot: '/data/root',
      mkdir: async () => undefined,
      log: { warn: (event, fields) => warnings.push({ event, fields: { ...fields } }) },
    });

    await logged.createSession({ workspaceDir: 'ws/a', name: 'imessage a', preset: 'dafeiyu' });

    // 预设服务不存在：会话照常创建（无预设 = 宿主默认），留一条 warn
    const create = host.log.find((c) => c.kind === 'agents.create');
    expect(create?.meta).toEqual({ cwd: '/data/root/ws/a' });
    expect(warnings[0]).toMatchObject({ event: 'preset-unavailable' });
  });

  it('still creates the session when preset resolution fails', async () => {
    const h = makePortWithPresets({ resolveThrows: new Error('agent-preset/not-found') });

    // resolve 失败不许炸通道：降级无预设创建 + warn 留痕
    const sessionId = await h.port.createSession({
      workspaceDir: 'ws/a',
      name: 'imessage a',
      preset: 'dafeiyu',
    });

    expect(String(sessionId)).toMatch(/^imessage-/u);
    expect(h.calls.mounted).toBeUndefined();
    const create = h.host.log.find((c) => c.kind === 'agents.create');
    expect(create?.meta).toEqual({ cwd: '/data/root/ws/a' });
    expect(h.warnings[0]).toMatchObject({ event: 'preset-resolve-failed' });
  });

  it('does not touch the preset service when no preset is requested', async () => {
    const h = makePortWithPresets();

    await h.port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });

    expect(h.calls.resolved).toBeUndefined();
    const create = h.host.log.find((c) => c.kind === 'agents.create');
    expect(create?.meta).toEqual({ cwd: '/data/root/ws/a' });
  });
});

describe('dsh-port · createSession', () => {
  it('creates workspace, session, attach and rename in order', async () => {
    const { host, port, mkdirCalls } = makePort();

    const sessionId = await port.createSession({
      workspaceDir: 'ws/+8613800000000',
      name: 'imessage +8613800000000',
    });

    // mkdir 先行（探针：realpath 校验要求目录已存在）
    expect(mkdirCalls).toEqual(['/data/root/ws/+8613800000000']);
    // 台账顺序：workspace.create → agents.create → attach → rename
    expect(host.log.map((c) => c.kind)).toEqual([
      'workspaceRegistry.create',
      'agents.create',
      'workspace.attachSession',
      'sessionTitle.rename',
    ]);
    // workspace 用的是数据根下的绝对路径
    expect(host.log[0]?.path).toBe('/data/root/ws/+8613800000000');
    // 会话命名对齐 webhook 惯例（imessage- 前缀）
    expect(String(sessionId)).toMatch(/^imessage-/u);
    expect(host.log[2]?.sessionId).toBe(sessionId);
  });

  it('creates the session with the current model selection', async () => {
    const { host, port } = makePort();
    host.setModelSelection({ provider: 'deepseek-official', model: 'deepseek-chat' });

    await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });

    // 探针事实：agents.create 必带 agentOptions（无默认兜底）
    expect(host.log[1]?.options).toEqual({ provider: 'deepseek-official', model: 'deepseek-chat' });
  });

  it('propagates create failures as-is', async () => {
    const { host, port } = makePort();
    host.failNextCreate(new Error('boom'));

    await expect(port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' })).rejects.toThrow(
      'boom',
    );
  });

  it('disposes the agent and rethrows when attach fails', async () => {
    const { host, port } = makePort();
    host.failNextAttach(new Error('attach rejected'));

    await expect(port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' })).rejects.toThrow(
      'attach rejected',
    );
    // 回滚：不留孤儿活 agent（webhook 事务语义）
    expect(host.log.map((c) => c.kind)).toContain('agents.dispose');
    expect(
      host.services.agents.get(asHostSessionId(String(host.log[1]?.sessionId))),
    ).toBeUndefined();
  });
});

describe('dsh-port · getSessionStatus', () => {
  it('reports active for a live session', async () => {
    const { port } = makePort();
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });

    await expect(port.getSessionStatus(sessionId)).resolves.toBe('active');
  });

  it('reports archived even when the agent is live', async () => {
    // 归档集与活动状态独立（源码事实：archived gate 只冻结模型步）
    const { host, port } = makePort();
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });
    host.archivedSessionIds.push(asHostSessionId(String(sessionId)));

    await expect(port.getSessionStatus(sessionId)).resolves.toBe('archived');
  });

  it('resumes a cold persisted session and reports active', async () => {
    const { host, port } = makePort();
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });
    // 模拟宿主重启：活句柄消失、持久层仍在
    await host.disposeAgent(String(sessionId));

    await expect(port.getSessionStatus(sessionId)).resolves.toBe('active');
    // 探针事实：冷会话经 resume 复活（sameSession true）
    expect(host.log.map((c) => c.kind)).toContain('agents.resume');
  });

  it('reports missing for an unknown session id', async () => {
    const { host, port } = makePort();

    await expect(port.getSessionStatus(asSessionId('imessage-ghost'))).resolves.toBe('missing');
    // 判定路径：get 落空后 resume 试探（探针：SessionPersistenceNotFoundError）
    expect(host.log.map((c) => c.kind)).toEqual(['agents.resume']);
  });

  it('propagates non-notfound resume failures as-is', async () => {
    // 磁盘 IO 等非 NotFound 失败不能误判 missing（否则 router 会重建会话丢上下文）
    const { host, port } = makePort();
    host.failNextResume(new Error('disk io error'));

    await expect(port.getSessionStatus(asSessionId('imessage-any'))).rejects.toThrow(
      'disk io error',
    );
  });
});

describe('dsh-port · ask', () => {
  it('streams ordered text deltas and completes', async () => {
    const { host, port } = makePort();
    host.scriptReply({ text: 'Hello' });
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });

    const { parts, text } = await collectAsk(port.ask({ sessionId, prompt: 'hi' }));

    // fake 把脚本文本拆两半发 text-delta：两条片段、拼接还原
    expect(parts).toEqual(['He', 'llo']);
    expect(text).toBe('Hello');
  });

  it('supports consecutive asks in fifo script order', async () => {
    const { host, port } = makePort();
    host.scriptReply({ text: 'first' });
    host.scriptReply({ text: 'second' });
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });

    const one = await collectAsk(port.ask({ sessionId, prompt: 'q1' }));
    const two = await collectAsk(port.ask({ sessionId, prompt: 'q2' }));

    expect(one.text).toBe('first');
    expect(two.text).toBe('second');
  });

  it('throws a structured error carrying the llm failure code when the turn fails', async () => {
    const { host, port } = makePort();
    host.scriptFailure({
      attempts: 2,
      failure: { message: 'DeepSeek Messages transport failed', code: 'TRANSPORT' },
    });
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });

    // 错误要带稳定 code（B+ 重试预算与日志按 code 归因）
    await expect(collectAsk(port.ask({ sessionId, prompt: 'hi' }))).rejects.toMatchObject({
      code: 'TRANSPORT',
      message: expect.stringContaining('transport failed') as unknown,
    });
  });

  it('cancels the agent and rejects with the abort reason when signal fires mid-stream', async () => {
    const { host, port } = makePort();
    host.scriptReply({ text: 'slow reply', chunkPauseMs: 50 });
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });
    const controller = new AbortController();

    const stream = port.ask({ sessionId, prompt: 'hi', signal: controller.signal });
    const collected: string[] = [];
    // 迭代中途触发 abort（第一片到达后）
    const consumption = (async () => {
      for await (const part of stream) {
        collected.push(part);
        controller.abort(new Error('user stopped'));
      }
    })();

    await expect(consumption).rejects.toThrow('user stopped');
    // 宿主侧收到了 cancel（源码事实：cancel({kind:'user'}) 中止活动 turn）
    expect(host.log).toContainEqual(
      expect.objectContaining({ kind: 'agent.cancel', cause: 'user' }),
    );
  });

  it('accepts the next ask after an aborted one without pollution', async () => {
    // 源码事实（waking-after-abort）：中止后下一条消息正常开新 turn
    const { host, port } = makePort();
    host.scriptReply({ text: 'interrupted', chunkPauseMs: 50 });
    host.scriptReply({ text: 'all good' });
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });
    const controller = new AbortController();

    const first = (async () => {
      for await (const _part of port.ask({ sessionId, prompt: 'hi', signal: controller.signal })) {
        controller.abort(new Error('stop'));
      }
    })();
    await expect(first).rejects.toThrow('stop');

    const { text } = await collectAsk(port.ask({ sessionId, prompt: 'again' }));
    expect(text).toBe('all good');
  });

  it('resumes a cold session transparently before asking', async () => {
    const { host, port } = makePort();
    host.scriptReply({ text: 'revived' });
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });
    await host.disposeAgent(String(sessionId));

    const { text } = await collectAsk(port.ask({ sessionId, prompt: 'hi' }));

    expect(text).toBe('revived');
    expect(host.log.map((c) => c.kind)).toContain('agents.resume');
  });

  it('removes event listeners after the stream completes', async () => {
    const { host, port } = makePort();
    host.scriptReply({ text: 'done' });
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });

    await collectAsk(port.ask({ sessionId, prompt: 'hi' }));

    // 监听器必须卸载：长跑进程里泄漏的监听会拖垮宿主
    expect(host.listenerCount('session/event')).toBe(0);
    expect(host.listenerCount('agent/assistant-stream')).toBe(0);
  });

  it('removes event listeners when the consumer breaks early', async () => {
    const { host, port } = makePort();
    host.scriptReply({ text: 'long reply text' });
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });

    for await (const _part of port.ask({ sessionId, prompt: 'hi' })) {
      break; // 消费者提前退出
    }
    // AsyncGenerator 的 return 钩子也要卸载监听
    await new Promise((resolve) => setImmediate(resolve));
    expect(host.listenerCount('session/event')).toBe(0);
    expect(host.listenerCount('agent/assistant-stream')).toBe(0);
  });

  it('rejects with a TIMEOUT error when the turn never ends', async () => {
    // 真机事故回归（2026-11-12）：turn/end 收不到 → 流永不结束 →
    // 通道被单条消息永久堵死。必须有超时兜底。
    const { host, port } = makePort({ askTimeoutMs: 80 });
    host.scriptHang({ text: '半截回复' });
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });

    const failure = await collectAsk(port.ask({ sessionId, prompt: 'hi' })).catch(
      (e: unknown) => e,
    );

    expect(failure).toMatchObject({ code: 'TIMEOUT' });
  });

  it('cancels the host turn after a timeout so it stops burning tokens', async () => {
    const { host, port } = makePort({ askTimeoutMs: 80 });
    host.scriptHang({ text: '半截' });
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });

    await collectAsk(port.ask({ sessionId, prompt: 'hi' })).catch(() => undefined);

    // 超时后宿主侧 turn 被取消（官方类型只承诺裸 Agent，故按运行时面收窄）
    const live = host.services.agents.get(
      asHostSessionId(String(sessionId)),
    ) as unknown as HostAgent;
    await live.whenIdle();
    expect(host.log.some((c) => c.kind === 'agent.cancel')).toBe(true);
  });

  it('accepts the next ask after a timed-out turn', async () => {
    // 超时后不能污染后续问答（监听器已卸载、无残留队列）
    const { host, port } = makePort({ askTimeoutMs: 80 });
    host.scriptHang({ text: '半截' });
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });
    await collectAsk(port.ask({ sessionId, prompt: 'hi' })).catch(() => undefined);

    host.scriptReply({ text: '好', chunkPauseMs: 0 });
    const second = await collectAsk(port.ask({ sessionId, prompt: 'again' }));

    expect(second.text).toBe('好');
    expect(host.listenerCount('session/event')).toBe(0);
  });

  it('ignores session events belonging to another session', async () => {
    const { host, port } = makePort();
    host.scriptReply({ text: '收到', chunkPauseMs: 30 });
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });

    const parts: string[] = [];
    for await (const part of port.ask({ sessionId, prompt: 'hi' })) {
      parts.push(part);
      // 他会话的收口事件不能终结本轮
      host.emitSessionEvent(
        'turn/end',
        { turn: 1, reason: { kind: 'completed' } },
        'other-session',
      );
      host.emitSessionEvent('turn/start', { turn: 99 }, 'other-session');
    }

    expect(parts.join('')).toBe('收到');
  });

  it('ignores a late turn/end from an earlier turn', async () => {
    // 超时/取消的上一轮可能迟到收口：不能让它收掉本轮
    const { host, port } = makePort();
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });
    // 先跑完一轮（turn=1），本轮即 turn=2
    host.scriptReply({ text: '第一轮', chunkPauseMs: 0 });
    await collectAsk(port.ask({ sessionId, prompt: 'first' }));
    host.scriptReply({ text: '本轮回复', chunkPauseMs: 30 });

    const parts: string[] = [];
    for await (const part of port.ask({ sessionId, prompt: 'hi' })) {
      parts.push(part);
      const key = String(sessionId);
      // 旧轮（turn=1）迟到的收口 + 重复的 turn/start
      host.emitSessionEvent('turn/end', { turn: 1, reason: { kind: 'aborted' } }, key);
      host.emitSessionEvent('turn/start', { turn: 1 }, key);
    }

    expect(parts.join('')).toBe('本轮回复');
  });

  it('rejects when the host cancels the turn externally', async () => {
    // 非本方 signal 的中止（宿主侧外部取消）：按 abort 语义上抛
    const { host, port } = makePort();
    host.scriptReply({ text: 'interrupted externally', chunkPauseMs: 50 });
    const sessionId = await port.createSession({ workspaceDir: 'ws/a', name: 'imessage a' });

    const consumption = (async () => {
      for await (const _part of port.ask({ sessionId, prompt: 'hi' })) {
        // 第一片到达后从宿主侧外部取消（不经 signal）
        (
          host.services.agents.get(asHostSessionId(String(sessionId))) as unknown as HostAgent
        )?.cancel({
          kind: 'parent',
        });
      }
    })();

    await expect(consumption).rejects.toThrow('ask aborted by host');
  });
});
