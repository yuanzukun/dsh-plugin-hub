# Changelog

## 0.2.1 — 2026-08-23

### Fixed

- `package.json`: declare the **`dsh.bundle`** manifest (`patch: ./cordis.patch.yml`).
  With only `dsh.client` declared, the package cannot be installed via
  `dsh plugin add`; the bundle manifest is what the plugin tooling reads.
- `package.json`: add `repository` / `homepage` / `bugs` metadata.
- Smoke checks were stale relative to 0.2.0: `boot-check` gated on the removed
  floating pill, and `panel-check` tried to click it. Boot now gates on the
  injected panel CSS + `__DSH_BOOT__` entry, and the drawer is opened via the
  documented Ctrl/Cmd+Alt+B shortcut. Target URL and chrome binary are read
  from `DSH_BTW_URL` / `DSH_BTW_CHROME` instead of a hardcoded loopback
  deployment.

## 0.2.0 — 2026-08-21

- **Per-message follow-up action**: every completed answer gets a `?` (BTW) icon
  in its action row — the entry point for anchored follow-up questions. The
  floating `⚡ BTW` pill is removed.
- **Per-anchor history**: re-opening the `?` on the same answer continues that
  anchor's thread (including earlier questions); different anchors are
  independent. The header `归档` action clears one anchor's history.
- Hidden reference context: the answer's preceding completed conversation text
  (user + assistant, capped at 48 KB) is sent as read-only context with the
  first question; the main session is never written.
- Side sessions inherit the main session's current `provider/model` by default;
  a model chip in the drawer switches it for the hidden session only
  (`persistDefault: false`).
- Composer styled like the main conversation: auto-growing input (no inner
  scrollbar up to 180 px) and a context ring reading the side session's real
  `contextPressure` projection.

## 0.1.0 — initial shape

- Floating BTW panel opened per tab, first question forking a side session from
  the main conversation's completed turns; Ctrl/Cmd+Alt+B toggle; archived side
  sessions kept out of the normal session list.
