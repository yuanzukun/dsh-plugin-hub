# dsh-btw — BTW 侧问面板（DHS Web GUI 客户端插件）

> 痛点：对话进行中想随手问一个问题，又不想污染主会话的上下文。
> 解决：随时弹出一个浮动面板（Ctrl/⌘+Alt+B），从当前主会话的已完成历史创建一个**独立的一次性会话**提问——
> 回答在分支会话中流式生成，主对话一行都不新增。

![BTW 侧问抽屉：左侧为主会话，右侧以某条回答为锚点的独立追问](docs/screenshot.png)

## 原理

- 这是一个**纯客户端插件**（dsh.client / platform web），无任何服务端改动。
- 每次打开面板后的第一条提问会读取主会话当前窗口中的已完成用户／助手文本，创建一个新的空会话，并把这段内容作为隐藏的只读参考上下文随首问发送。
- 不复制主会话的 goal、计划、工具调用、权限状态或待处理队列；BTW 的内部上下文只用于模型回答，面板只渲染实际问题和回答。
- 新会话继承主会话的 cwd，创建后、首问前立即归档，因此不会出现在左侧普通会话历史；发送后先显示本地问题和等待状态，再接收侧问会话事件。
- 主会话不会被写入；
- 回答通过会话事件快照（`session.subscribe` / `getSnapshot` 的 uSES 通道）实时渲染，
  过程中可以看到"思考中 / 输出中"。

## 配置

BTW 默认创建 `minimal` preset，并选择 `opencode-go/deepseek-v4-flash` 的 `off` 推理强度。插件配置可以在 Web profile 的 Cordis patch 中覆盖：

```yaml
- insert:
    - id: dsh-btw
      name: dsh-btw
      config:
        agentPreset: minimal
        provider: opencode-go
        model: deepseek-v4-flash
        reasoningEffort: off
```

模型选择使用 `persistDefault: false`，因此只作用于 BTW 的隐藏会话，不修改主会话或部署默认模型。配置项必须是非空字符串；提供方、模型或 preset 不可用时，首问会失败并显示错误。

## 使用

| 操作 | 效果 |
|---|---|
| 点击某条回答底部图标组里的 **`?`（BTW 追问）** 按钮 | 打开侧问抽屉，**以该回答及其之前的已完成对话作为参考上下文**，开启一条**独立的**追问会话 |
| **Ctrl/⌘ + Alt + B** | 开关侧问面板（任意页面均可；不用 Shift+B 是因它会撞浏览器书签快捷键） |
| 输入问题按 `Enter` | 发送（`Shift+Enter` 换行） |
| 面板头部 `归档` | 清除当前侧窗并归档其上下文会话 |
| `Esc` / 点击遮罩 / `收起` | 收起面板（隐藏分支仍在当前标签页内复用） |

> 侧问会话会以 `BTW: <问题前30字>` 命名并自动归档，不进入左侧普通会话历史。页面刷新后，面板会基于刷新时的主会话创建新的侧问会话；已归档会话仍保留在会话数据中。

### 按回答追问（每消息 BTW 动作）

在每条已完成回答的图标组里（`复制 … 好的回答 … ?`），有一个 `?` 图标，它是「针对该回答追问问句」的唯一入口
（右下角的 `⚡ BTW` 胶囊按钮已移除）。点击后打开侧问抽屉，以该回答为锚点追问。
**历史按锚点回答保留**：再点同一条回答的 `?` 会续接之前的追问（含此前的问答历史），不同锚点各自独立；
点面板头的「归档」才会清空该锚点的历史。首个问题会携带该回答及其之前的已完成对话
（用户 + 助手文本，最多 48KB）作为只读参考上下文，主会话不被动用。通过向 DSH 的
`conversation.chat.assistant-actions` 插槽注册（`order: 20`，位于 `复制`/`好的回答` 之后）实现。

### 发送区：主会话风格卡片 + 上下文圈

BTW 抽屉底部的发送区改成了主会话同款样式：圆角卡片内是随内容自适应的输入框（无内部滚动条），
卡片下方的工具行里是模型胶囊和**上下文圈**。「上下文圈」读取侧问会话的**真实 `contextPressure`
投影**（与主会话的 ContextMeter 一致），以百分比环展示当前侧问上下文占用量，点开可看已用/窗口 token——
侧问会话首次 LLM 调用回报用量后才会出现。发送按钮为圆形图标，与主会话一致。

### 模型：默认继承主会话 + 抽屉内切换

BTW 侧问会话的模型**默认与主会话当前所选模型一致**（打开抽屉时自动读取主会话的当前
`provider/model` 并作为默认）。抽屉底部输入框上方有一个**模型胶囊**，点击展开可用模型列表，
可随时为 BTW 侧问会话单独切换 `provider/model`（沿用其默认推理强度）。切换仅作用于 BTW
隐藏会话（`persistDefault: false`），不会改动主会话或部署默认模型；若主会话当前模型读取失败
或尚无模型，则回退到插件配置中的默认模型。

### 输入框：无内部滚动条（随内容自适应增高）

BTW 抽屉的提问输入框采用与主会话一致的 auto-grow 方案：输入框随内容自动增高，
内容不超过上限（180px）时**内部不出现滚动条**；超过上限后由输入框外层容器整体滚动。

## 文件结构

```
dsh-btw/
├── package.json     # dsh.client 清单 + exports["./client"]
└── lib/
    ├── index.js     # 节点侧空实现（让插件成为合法的 Loader entry）
    └── client.js    # 浏览器端 bundle（手写 window.__ModuleLoader__.load 格式）
```

## 安装 / 卸载

BTW 是纯客户端插件（`dsh.client` / platform web），`package.json` 自 0.2.1 起声明
`dsh.bundle` manifest，可被 `dsh plugin add` 直接安装（安装 = 拷贝插件包 +
在 web profile 的 `cordis.patch.yml` 插入 Loader entry + 重启 dsh-web）。任选其一：

**方式 A：从 GitHub 安装（推荐）**

> ⚠️ npm 上的 `dsh-btw` 已被他方占用，**不要用裸名 `dsh plugin add dsh-btw`**——会装到别人的包。请始终用带 `github:` 前缀的地址指向本仓库。

```bash
dsh plugin --profile web add github:LuckVd/dsh-btw
# 然后重启 dsh-web 服务
```

**方式 B：手动部署**
```bash
# 1) 把本仓库放到 profile 的 node_modules
git clone https://github.com/LuckVd/dsh-btw ~/.dsh/profiles/node_modules/dsh-btw
# 2) 在 ~/.dsh/profiles/web/cordis.patch.yml 插入（与仓库根的 cordis.patch.yml 一致）：
#    - insert:
#        - id: dsh-btw
#          name: 'dsh-btw'
# 3) 重启 dsh-web 服务（systemctl restart dsh-web 等价）
```

**验证安装**：刷新页面后，任一已完成回答的图标组里出现 `?`（BTW 追问）按钮，
或按 Ctrl/⌘+Alt+B 能弹出「BTW · 侧问」抽屉，即已生效。仓库自带 4 个
smoke 检查（`smoke/*.mjs`，无外部依赖），可在部署机上运行验证。
**卸载**：删除 patch 中的 `dsh-btw` 行 + 删除
`~/.dsh/profiles/node_modules/dsh-btw` 目录 + 重启服务即可。

## 已知限制

- 会话只能归档不能删除（DSH 平台限制）；侧问分支的日志仍持久化，但不显示在普通会话树中。
- 每个浏览器标签页各自维护自己的侧问会话（互不共享）。
- 首个问题会先读取主会话窗口、创建并配置侧问会话、再归档它，故比后续追问略慢。
- 上下文只包含浏览器当前已打开窗口中的已完成文本；更早历史需要先在主会话中加载后才会作为 BTW 参考。
- 上下文圈读取侧问会话的 `contextPressure` 投影，首次 LLM 调用回报用量后才显示。

## 发布信息

- 本仓库打 **`dsh-plugin`** GitHub 话题（官方的插件可发现性约定；社区 `awesome-*` 列表会索引该话题）。
- 针对 **DeepSeek Harness `0.1.0-rc.6`** 开发验证（v0.1 预览版可能有不兼容变更，更新时请关注上游变更公告）。
- License: MIT（见 [LICENSE](./LICENSE)）。
