// dsh-btw smoke test #4 — per-message BTW action boot verification.
// Confirms the new code boots cleanly: the plugin entry is in the boot graph,
// the per-message action styles are injected, the floating pill is REMOVED,
// and no console errors / exceptions surface. Rendering the actual `?` button
// requires an active finalized assistant message in the DOM; this test verifies
// registration + bootstrap health.
// Usage: node smoke/per-message-check.mjs
import { spawn } from "node:child_process";

const CHROME = process.env.DSH_BTW_CHROME || "/root/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome";
const APP_URL = process.env.DSH_BTW_URL || "http://127.0.0.1:28080/";
const ORIGIN = new URL(APP_URL).origin;
const PORT = 9331;
const BOOT_TIMEOUT_MS = 60000;

const chrome = spawn(CHROME, [
  "--headless=new", "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage",
  "--remote-allow-origins=*", `--remote-debugging-port=${PORT}`,
  "--user-data-dir=/tmp/btw-cdp4-profile", APP_URL
], { stdio: "ignore" });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function getTargets() {
  try { return await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json(); } catch { return []; }
}
async function waitTarget() {
  const deadline = Date.now() + 30000;
  while (Date.now() < deadline) {
    const t = (await getTargets()).find((x) => x.type === "page" && x.url.startsWith(ORIGIN));
    if (t) return t;
    await sleep(500);
  }
  throw new Error("no page target");
}
let nextId = 1;
function send(ws, method, params) {
  const id = nextId++;
  return new Promise((resolve, reject) => {
    const onMsg = (ev) => {
      const m = JSON.parse(ev.data);
      if (m.id === id) { ws.removeEventListener("message", onMsg); m.error ? reject(new Error(JSON.stringify(m.error))) : resolve(m.result); }
    };
    ws.addEventListener("message", onMsg);
    ws.send(JSON.stringify({ id, method, params: params || {} }));
  });
}
async function evalJs(ws, expression) {
  const r = await send(ws, "Runtime.evaluate", { expression, returnByValue: true });
  return r.result?.value;
}

async function main() {
  const target = await waitTarget();
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.addEventListener("open", res); ws.addEventListener("error", rej); });

  const consoleErrors = [];
  const exceptions = [];
  ws.addEventListener("message", (ev) => {
    const m = JSON.parse(ev.data);
    if (m.method === "Runtime.exceptionThrown") exceptions.push(m.params.exceptionDetails?.text || m.params.exceptionDetails?.exception?.description || "exception");
    if (m.method === "Runtime.consoleAPICalled" && m.params.type === "error") {
      consoleErrors.push((m.params.args || []).map((a) => a.value ?? a.description ?? "").join(" "));
    }
  });
  await send(ws, "Runtime.enable");

  let boot = null;
  for (let i = 0; i < BOOT_TIMEOUT_MS / 1000; i++) {
    const v = await evalJs(ws, `({
      pill: !!document.querySelector('.btw-pill'),
      actionCss: !!document.querySelector('style[data-plugin-css="dsh-btw/action.css"]'),
      panelCss: !!document.querySelector('style[data-plugin-css="dsh-btw/panel.css"]'),
      boot: !!(window.__DSH_BOOT__ && window.__DSH_BOOT__.entries)
    })`);
    if (v && v.actionCss && v.boot) { boot = v; break; }
    await sleep(1000);
  }

  let detail = null;
  if (boot) {
    detail = await evalJs(ws, `({
      hasBtwEntry: (window.__DSH_BOOT__.entries || []).some(e => e.id === 'dsh-btw'),
      btwUrl: (window.__DSH_BOOT__.entries || []).find(e => e.id === 'dsh-btw')?.url || null
    })`);
  }

  console.log(JSON.stringify({ boot, detail, consoleErrors, exceptions }, null, 2));
  ws.close();
  chrome.kill("SIGKILL");
  const healthy = boot
    && boot.actionCss
    && boot.boot
    && boot.pill === false           // floating pill must be REMOVED
    && detail?.hasBtwEntry
    && consoleErrors.length === 0
    && exceptions.length === 0;
  process.exit(healthy ? 0 : 1);
}
main().catch((e) => { console.error("SMOKE-FAIL:", e.message); chrome.kill("SIGKILL"); process.exit(1); });
