// Probe: call session.create via the page's own origin to see the full error.
import { spawn } from "node:child_process";

const CHROME = process.env.DSH_BTW_CHROME || "/root/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome";
const APP_URL = process.env.DSH_BTW_URL || "http://127.0.0.1:28080/";
const ORIGIN = new URL(APP_URL).origin;
const PORT = 9225;

const chrome = spawn(CHROME, [
  "--headless=new", "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage",
  "--remote-allow-origins=*", `--remote-debugging-port=${PORT}`,
  "--user-data-dir=/tmp/btw-probe-profile", APP_URL
], { stdio: "ignore" });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function getTargets() {
  try { return await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json(); } catch { return []; }
}
async function waitTarget() {
  const deadline = Date.now() + 30000;
  while (Date.now() < deadline) {
    const t = (await getTargets()).find((x) => x.type === "page" && x.url.startsWith(ORIGIN));
    if (t) return t;
    await sleep(500);
  }
  throw new Error("no page target");
}
let nextId = 1;
function send(ws, method, params) {
  const id = nextId++;
  return new Promise((resolve, reject) => {
    const onMsg = (ev) => {
      const m = JSON.parse(ev.data);
      if (m.id === id) { ws.removeEventListener("message", onMsg); m.error ? reject(new Error(JSON.stringify(m.error))) : resolve(m.result); }
    };
    ws.addEventListener("message", onMsg);
    ws.send(JSON.stringify({ id, method, params: params || {} }));
  });
}
async function evalJs(ws, expression) {
  const r = await send(ws, "Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true });
  return r.result?.value;
}

async function main() {
  const target = await waitTarget();
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.addEventListener("open", res); ws.addEventListener("error", rej); });
  await send(ws, "Runtime.enable");

  // wait until the app is up (session list baseline available)
  for (let i = 0; i < 60; i++) {
    if (await evalJs(ws, `!!(window.__DSH_MODULES__)`)) break;
    await sleep(1000);
  }
  await sleep(2000);

  const probe = await evalJs(ws, `(async () => {
    const out = {};
    for (const payload of [{}, { cwd: '/root' }]) {
      try {
        const r = await fetch('/api/session.create', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type: 'client-request', rpcId: 'probe-' + Math.random().toString(36).slice(2), method: 'session.create', payload })
        });
        const text = await r.text();
        out[JSON.stringify(payload)] = { status: r.status, body: text.slice(0, 600) };
      } catch (e) {
        out[JSON.stringify(payload)] = { fetchError: String(e) };
      }
    }
    return out;
  })()`);

  console.log(JSON.stringify({ probe }, null, 2));
  ws.close();
  chrome.kill("SIGKILL");
}
main().catch((e) => { console.error("FAIL:", e.message); chrome.kill("SIGKILL"); process.exit(1); });