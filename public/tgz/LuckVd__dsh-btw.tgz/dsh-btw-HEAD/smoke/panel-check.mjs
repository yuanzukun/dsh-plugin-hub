// dsh-btw smoke test #2 — open the drawer via Ctrl/Cmd+Alt+B, close with Esc.
// Usage: node smoke/panel-check.mjs
import { spawn } from "node:child_process";

const CHROME = process.env.DSH_BTW_CHROME || "/root/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome";
const APP_URL = process.env.DSH_BTW_URL || "http://127.0.0.1:28080/";
const ORIGIN = new URL(APP_URL).origin;
const PORT = 9223;

const chrome = spawn(CHROME, [
  "--headless=new", "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage",
  "--remote-allow-origins=*", `--remote-debugging-port=${PORT}`,
  "--user-data-dir=/tmp/btw-cdp2-profile", APP_URL
], { stdio: "ignore" });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function getTargets() {
  try { return await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json(); } catch { return []; }
}
async function waitTarget() {
  const deadline = Date.now() + 30000;
  while (Date.now() < deadline) {
    const t = (await getTargets()).find((x) => x.type === "page" && x.url.startsWith(ORIGIN));
    if (t) return t;
    await sleep(500);
  }
  throw new Error("no page target");
}
let nextId = 1;
function send(ws, method, params) {
  const id = nextId++;
  return new Promise((resolve, reject) => {
    const onMsg = (ev) => {
      const m = JSON.parse(ev.data);
      if (m.id === id) { ws.removeEventListener("message", onMsg); m.error ? reject(new Error(JSON.stringify(m.error))) : resolve(m.result); }
    };
    ws.addEventListener("message", onMsg);
    ws.send(JSON.stringify({ id, method, params: params || {} }));
  });
}
async function evalJs(ws, expression) {
  const r = await send(ws, "Runtime.evaluate", { expression, returnByValue: true });
  return r.result?.value;
}

async function main() {
  const target = await waitTarget();
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.addEventListener("open", res); ws.addEventListener("error", rej); });
  await send(ws, "Runtime.enable");

  let ready = false;
  for (let i = 0; i < 60; i++) {
    ready = await evalJs(ws, `document.querySelector('style[data-plugin-css="dsh-btw/panel.css"]') !== null`);
    if (ready) break;
    await sleep(1000);
  }

  await evalJs(ws, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'b', code: 'KeyB', ctrlKey: true, altKey: true })); true`);
  await sleep(1500);
  const opened = await evalJs(ws, `(() => {
    const drawer = document.querySelector('.btw-drawer');
    const ta = document.querySelector('.btw-foot textarea');
    return {
      drawerOpen: !!drawer,
      title: drawer ? (document.querySelector('.btw-title')?.textContent || '').trim() : null,
      placeholder: ta ? ta.placeholder : null,
      hint: (document.querySelector('.btw-hint')?.textContent || '').trim(),
      emptyText: (document.querySelector('.btw-empty')?.textContent || '').trim()
    };
  })()`);

  await evalJs(ws, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' })); true`);
  await sleep(800);
  const closed = await evalJs(ws, `!document.querySelector('.btw-drawer')`);

  console.log(JSON.stringify({ ready, opened, drawerClosedAfterEscape: closed }, null, 2));
  ws.close();
  chrome.kill("SIGKILL");
  process.exit(opened && opened.drawerOpen && closed ? 0 : 1);
}
main().catch((e) => { console.error("FAIL:", e.message); chrome.kill("SIGKILL"); process.exit(1); });