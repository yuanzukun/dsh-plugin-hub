// dsh-btw smoke test #3 — end-to-end: type a question, send, wait for the
// independent session to be created and the model to answer.
// NOTE: performs one real (tiny) LLM call through the deployment's default model.
// Usage: node smoke/ask-check.mjs
import { spawn } from "node:child_process";

const CHROME = process.env.DSH_BTW_CHROME || "/root/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome";
const APP_URL = process.env.DSH_BTW_URL || "http://127.0.0.1:28080/";
const ORIGIN = new URL(APP_URL).origin;
const PORT = 9224;
const ANSWER_TIMEOUT_MS = 150000;

const chrome = spawn(CHROME, [
  "--headless=new", "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage",
  "--remote-allow-origins=*", `--remote-debugging-port=${PORT}`,
  "--user-data-dir=/tmp/btw-cdp3-profile", APP_URL
], { stdio: "ignore" });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function getTargets() {
  try { return await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json(); } catch { return []; }
}
async function waitTarget() {
  const deadline = Date.now() + 30000;
  while (Date.now() < deadline) {
    const t = (await getTargets()).find((x) => x.type === "page" && x.url.startsWith(ORIGIN));
    if (t) return t;
    await sleep(500);
  }
  throw new Error("no page target");
}
let nextId = 1;
function send(ws, method, params) {
  const id = nextId++;
  return new Promise((resolve, reject) => {
    const onMsg = (ev) => {
      const m = JSON.parse(ev.data);
      if (m.id === id) { ws.removeEventListener("message", onMsg); m.error ? reject(new Error(JSON.stringify(m.error))) : resolve(m.result); }
    };
    ws.addEventListener("message", onMsg);
    ws.send(JSON.stringify({ id, method, params: params || {} }));
  });
}
async function evalJs(ws, expression) {
  const r = await send(ws, "Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true });
  return r.result?.value;
}
const consoleErrors = [];
async function collectErrors(ws) {
  ws.addEventListener("message", (ev) => {
    const m = JSON.parse(ev.data);
    if (m.method === "Runtime.exceptionThrown") consoleErrors.push(m.params.exceptionDetails?.text || "exception");
    if (m.method === "Runtime.consoleAPICalled" && m.params.type === "error") {
      consoleErrors.push((m.params.args || []).map((a) => a.value ?? a.description ?? "").join(" "));
    }
  });
  await send(ws, "Runtime.enable");
  return consoleErrors;
}

async function main() {
  const target = await waitTarget();
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.addEventListener("open", res); ws.addEventListener("error", rej); });
  collectErrors(ws);

  // open the panel
  let ready = false;
  for (let i = 0; i < 60; i++) {
    ready = await evalJs(ws, `document.querySelector('style[data-plugin-css="dsh-btw/panel.css"]') !== null`);
    if (ready) break;
    await sleep(1000);
  }
  await evalJs(ws, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'b', code: 'KeyB', ctrlKey: true, altKey: true })); true`);
  await sleep(1000);

  // type into the React-controlled textarea via the native value setter
  const typed = await evalJs(ws, `(() => {
    const ta = document.querySelector('.btw-foot textarea');
    if (!ta) return false;
    const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
    setter.call(ta, '测试：1+1 等于几？请用一句话回答');
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    return ta.value;
  })()`);

  // send (Enter)
  await evalJs(ws, `(() => {
    const ta = document.querySelector('.btw-foot textarea');
    ta.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true }));
    return true;
  })()`);

  // poll for the assistant answer row
  let state = null;
  const deadline = Date.now() + ANSWER_TIMEOUT_MS;
  while (Date.now() < deadline) {
    state = await evalJs(ws, `(() => {
      const rows = Array.from(document.querySelectorAll('.btw-row'));
      return {
        rowCount: rows.length,
        userText: rows.filter(r => r.classList.contains('user')).map(r => r.textContent.trim()).join(' | '),
        assistantText: rows.filter(r => r.classList.contains('assistant')).map(r => r.textContent.trim()).join(' | '),
        streaming: !!document.querySelector('.btw-streaming'),
        error: (document.querySelector('.btw-row.error')?.textContent || '').trim(),
        hint: (document.querySelector('.btw-hint')?.textContent || '').trim()
      };
    })()`);
    if (state.assistantText && !state.streaming && state.assistantText !== "思考中…") break;
    await sleep(2000);
  }

  console.log(JSON.stringify({ typed, state, consoleErrors }, null, 2));
  ws.close();
  chrome.kill("SIGKILL");
  const ok = typed === "测试：1+1 等于几？请用一句话回答" && state && state.assistantText && !state.error;
  process.exit(ok ? 0 : 1);
}
main().catch((e) => { console.error("FAIL:", e.message); chrome.kill("SIGKILL"); process.exit(1); });