# `@deepseek-ai/dsh-sandbox-nono`

[English](README.md) | 中文

nono（Landlock/Seatbelt）后端的可安装 DSH profile 组合包。这个 standalone package 包含沙箱 provider、不变式 companion、bundle patch，以及 vendored `@dsh-external/nono-ts` 原生执行器载体。

## 仓库结构

```text
package.json              # standalone package 与 dsh.bundle 清单
cordis.patch.yml          # 显式 sandbox-nono provider 行
docs/                     # 双语 Nono 详细文档
src/                      # provider 与 invariant companion
tests/                    # 单元测试和真实 wrapper 集成测试
vendor-nono-ts/           # 固定版本的原生绑定与执行器 wrapper
lib/                      # 生成的安装产物
```

组合包会加入一个默认禁用的 `sandbox-nono` 行。部署需要 Nono 后端时，可以通过 profile overlay 启用它；已有 DSH `sandbox` 行不会被静默重命名或替换。

```yaml
- id: sandbox-nono
  name: '@deepseek-ai/dsh-sandbox-nono'
  disabled: false
  config:
    probeTimeoutMs: 5000
```

当宿主没有 vendored 绑定、平台没有对应后端，或功能性通道探测无法证明隔离有效时，provider 会以 `SANDBOX_UNAVAILABLE` fail-closed。绑定解析、启动 argv 拼装、wrapper 失败分类和通道验收由 SDK 负责。

详细行为与限制见 [`docs/nono.md`](docs/nono.md)。

## 开发

完整 typecheck 需要把 DSH checkout 放在本仓库旁边：

```text
../../deepseek-harness
```

```sh
pnpm install
pnpm run typecheck
pnpm test
pnpm run build
pnpm run test:e2e
```

`prepare` 直接从 `src/` 构建，因此安装后的 package 运行时不依赖 sibling checkout。目前 vendored carrier 只包含 Linux x64 GNU 绑定；不支持的宿主会明确 fail-closed。

## Model Experience

间接地，经由 `@deepseek-ai/dsh-bash-sandbox` 与 `@deepseek-ai/dsh-tool-bash` 呈现 enforcement 和 denial 事实。`@deepseek-ai/dsh-sandbox` seam 拥有 `SANDBOX_UNAVAILABLE` 文案。

## 已知限制与延后工作

- 目前只提交了 `linux-x64-gnu` 原生绑定；其他平台需要在 `vendor-nono-ts/native/` 下加入匹配的 carrier。
- Windows 没有 Nono 后端，会 fail-closed。
- 功能性探测结论会在 provider 生命周期内缓存；修复绑定后需要重新加载插件。
