import { fileURLToPath } from 'node:url'
import { defineConfig } from 'vitest/config'

const dsh = (path: string): string => fileURLToPath(new URL(`../../deepseek-harness/${path}`, import.meta.url))
const root = (path: string): string => fileURLToPath(new URL(`./${path}`, import.meta.url))

export default defineConfig({
  resolve: {
    alias: {
      '@deepseek-ai/dsh-sandbox-nono': root('src/index.ts'),
      '@deepseek-ai/dsh-sandbox-nono/src/index.ts': root('src/index.ts'),
      '@deepseek-ai/dsh-sandbox': dsh('packages/sandbox/sandbox/src/index.ts'),
      '@deepseek-ai/dsh-invariants': dsh('packages/support/invariants/src/index.ts'),
      '@deepseek-ai/dsh-llm': dsh('packages/llm/llm/src/index.ts'),
      '@deepseek-ai/dsh-session': dsh('packages/core/session/src/index.ts'),
      '@deepseek-ai/dsh-sandbox-policy': dsh('packages/sandbox/sandbox-policy/src/index.ts'),
      '@deepseek-ai/dsh-bash-sandbox': dsh('packages/bash/bash-sandbox/src/index.ts'),
      '@deepseek-ai/dsh-subprocess': dsh('packages/subprocess/subprocess/src/index.ts'),
      '@deepseek-ai/dsh-subprocess-local': dsh('packages/subprocess/subprocess-local/src/index.ts'),
    },
  },
  test: {
    include: ['tests/**/*.spec.ts'],
    environment: 'node',
  },
})
