import { mergeConfig } from 'vitest/config'
import base from './vitest.config.ts'

export default mergeConfig(base, {
  test: {
    include: ['tests/**/*.e2e.ts'],
    exclude: ['tests/**/*.spec.ts'],
  },
})
