# @dsh-external/nono-ts( vendored )

[English](README.md) | 中文

Vendored nono-ts 原生绑定(Apache-2.0)加 DSH seam 执行器 wrapper。绝不从 registry 解析:包在 `native/<platform>-<arch>/` 下自带构建好的 `.node` 绑定,在 `dist/` 下自带 seam 的 wrapper,由沙箱提供方以
`"@dsh-external/nono-ts": "file:./vendor-nono-ts"` 引用。

## 上游源码

- 绑定:[`nolabs-ai/nono-ts`](https://github.com/nolabs-ai/nono-ts),
  提交 `86b1b5f`(main,2026-08-07),包 `nono-node` v0.4.2。
- 底层库:[`nolabs-ai/nono`](https://github.com/nolabs-ai/nono)
  crate `nono` v0.61.1(crates.io),以 `default-features = false` 编译
  (无系统 keyring 后端 — 纯 Rust secret-service/zbus 路径未被使用;DSH seam 不应用凭据特性)。
- 许可证:Apache-2.0(`LICENSE.md`)。

## 为何 vendored

上游 npm 分发按现状不可用: `nono-ts@0.3.0`(唯一 npm 版本)声明的平台包(`nono-ts-linux-x64-gnu`
等)在 registry 上不存在,主 tarball 只内嵌发布者自己的 `darwin-arm64` 二进制。当前源码(0.4.x)
完全没有发布到 npm。本地从源码构建可得到可工作的绑定;checkout 加构建工具链(`cargo`、`napi`)
并非每个部署都有,因此构建产物在此提交、钉住上面的源码提交。

## 构建流程

```sh
git clone --depth 1 https://github.com/nolabs-ai/nono-ts.git
cd nono-ts
# Pin the wrapper build to the upstream commit recorded above; then:
sed -i 's|nono = { version = "0.61.1" }|nono = { version = "0.61.1", default-features = false }|' Cargo.toml
cargo build --release
cp target/release/libnono_node.so native/linux-x64-gnu/nono.linux-x64-gnu.node
```

然后重跑 sandbox-nono 单测(它们只在绑定存在时 spawn 真实 wrapper;否则提供方 fail-closed)。

## 产物校验和

`native/linux-x64-gnu/nono.linux-x64-gnu.node`:
`f16a4ad7ed3b3f3351e4bb7386290d591c98a25cce082d32f1cc3ae2e1268c0a`

## Wrapper 契约

`dist/wrapper.js` 是被 spawn 的执行器。SDK 层(`dist/index.js`)拥有绑定解析、启动 argv 拼装与
通道探测;沙箱提供方只调用这些 API。

- 启动 argv:`[node, wrapper.js, '--binding', <dir>, '--config-base64',
  <b64>, ['--probe'], '--', <payload argv...>]`
- 配置即 nono capability wire 形状:`{ readRoots, writeRoots, readFiles,
  writeFiles, blockNetwork }`。
- wrapper 失败:stderr `nono-ts: <detail>` 加退出码 `125`
  (`NONO_WRAPPER_FAILURE_EXIT`);负载绝不会无限制地启动。
- probe 模式:应用最小只读配置并验证强制真正生效(授予根之外的写入失败);stdout
  `{"usable":true,"enforcement":"full"}`。

## 平台支持

当前仅 vendored `linux-x64-gnu`(构建宿主)。Linux arm64 与 macOS darwin 绑定以同样方式构建并
放入 `native/`,当匹配宿主或交叉工具链可用时;没有任何 vendored 绑定的平台由提供方 fail-closed。
