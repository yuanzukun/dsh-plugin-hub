# @dsh-external/nono-ts (vendored)

English | [中文](README.zh.md)

Vendored nono-ts native binding (Apache-2.0) plus the DSH seam executor
wrapper. Never resolved from a registry: the package ships the built
`.node` binding under `native/<platform>-<arch>/` and the seam's wrapper
under `dist/`, referenced by the sandbox provider as
`"@dsh-external/nono-ts": "file:./vendor-nono-ts"`.

## Upstream source

- Binding: [`nolabs-ai/nono-ts`](https://github.com/nolabs-ai/nono-ts),
  commit `86b1b5f` (main, 2026-08-07), package `nono-node` v0.4.2.
- Underlying library: [`nolabs-ai/nono`](https://github.com/nolabs-ai/nono)
  crate `nono` v0.61.1 (crates.io), compiled with `default-features = false`
  (no system keyring backend — the pure-Rust secret-service/zbus path is
  unused; the DSH seam applies no credential features).
- License: Apache-2.0 (`LICENSE.md`).

## Why vendored

The upstream npm distribution is unusable as published: `nono-ts@0.3.0`
(the only npm version) declares platform packages (`nono-ts-linux-x64-gnu`,
etc.) that do not exist on the registry, and the main tarball embeds only
the publisher's own `darwin-arm64` binary. The current source (0.4.x) is
not published to npm at all. Building from source locally yields a working
binding; the checkout plus build toolchain (`cargo`, `napi`) is not
available in every deployment, so the built artifact is committed here,
pinned to the source commit above.

## Build procedure

```sh
git clone --depth 1 https://github.com/nolabs-ai/nono-ts.git
cd nono-ts
# Pin the wrapper build to the upstream commit recorded above; then:
sed -i 's|nono = { version = "0.61.1" }|nono = { version = "0.61.1", default-features = false }|' Cargo.toml
cargo build --release
cp target/release/libnono_node.so native/linux-x64-gnu/nono.linux-x64-gnu.node
```

Then re-run the sandbox-nono unit tests (they spawn the real wrapper only
when the binding exists; the provider fails closed otherwise).

## Artifact checksum

`native/linux-x64-gnu/nono.linux-x64-gnu.node`:
`f16a4ad7ed3b3f3351e4bb7386290d591c98a25cce082d32f1cc3ae2e1268c0a`

## Wrapper contract

`dist/wrapper.js` is the spawned executor. The SDK layer
(`dist/index.js`) owns binding resolution, launch argv composition, and
channel qualification; the sandbox provider calls only those APIs.

- Launch argv: `[node, wrapper.js, '--binding', <dir>, '--config-base64',
  <b64>, ['--probe'], '--', <payload argv...>]`
- The config is the nono capability wire shape: `{ readRoots, writeRoots,
  blockNetwork }`.
- Wrapper failure: stderr `nono-ts: <detail>` plus exit `125`
  (`NONO_WRAPPER_FAILURE_EXIT`); the payload is never spawned unrestricted.
- Probe mode: applies a minimal read-only config and verifies enforcement
  bites (a write outside granted roots fails); stdout
  `{"usable":true,"enforcement":"full"}`.

## Platform support

Only `linux-x64-gnu` is currently vendored (the build host). Linux arm64
and macOS darwin bindings are built the same way and dropped into
`native/` when a matching host or cross toolchain is available; the
provider fails closed on any platform without a vendored binding.
