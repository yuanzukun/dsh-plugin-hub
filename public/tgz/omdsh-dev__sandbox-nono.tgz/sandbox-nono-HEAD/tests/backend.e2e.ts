/**
 * Keyless backend integration through `confine()` and the real vendored
 * nono wrapper. Skips when the vendored binding is absent (a host without
 * the linux-x64-gnu artifact) or the channel probe fails — the provider
 * itself fails closed in that case, which is the product behavior.
 */

import { spawnSync } from 'node:child_process'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { Context } from 'cordis'
import { probeNonoChannel } from '@dsh-external/nono-ts'
import type { SandboxPolicy } from '@deepseek-ai/dsh-sandbox'
import { NonoSandboxProvider } from '@deepseek-ai/dsh-sandbox-nono'

/** The real channel must qualify before any integration test runs (skip otherwise). */
const channelUsable = probeNonoChannel({ timeoutMs: 15_000 }).usable

const tempDirs: string[] = []

afterEach(() => {
  for (const dir of tempDirs.splice(0)) rmSync(dir, { recursive: true, force: true })
})

function tempDir(): string {
  const dir = mkdtempSync(join(tmpdir(), 'dsh-nono-e2e-'))
  tempDirs.push(dir)
  return dir
}

/** Confine a shell command under `policy` and run it for real; returns the spawn result and the wrap's facts. */
function runConfined(sandbox: NonoSandboxProvider, command: string, policy: SandboxPolicy) {
  const confined = sandbox.confine(['bash', '-c', command], policy)
  const result = spawnSync(confined.argv[0] as string, confined.argv.slice(1), { timeout: 30_000, encoding: 'utf8' })
  return { result, confined }
}

describe.skipIf(!channelUsable)('nono backend integration (real vendored binding)', () => {
  it('probe passes on a supported host with the vendored binding', async () => {
    const ctx = new Context()
    await ctx.plugin(NonoSandboxProvider, { probeTimeoutMs: 15_000 })
    const sandbox = ctx.sandbox as NonoSandboxProvider
    const confined = sandbox.confine(['bash', '-c', 'true'], { mode: 'read-only', workspaceRoot: '/' })
    await ctx.fiber.dispose()
    // The real probe must have qualified the channel before serving.
    expect(confined.enforcement).toBe('full')
  })

  it('read-only: workspace write is denied, reads pass, exit code passes through', async () => {
    const ws = tempDir()
    const ctx = new Context()
    await ctx.plugin(NonoSandboxProvider, { probeTimeoutMs: 15_000 })
    const sandbox = ctx.sandbox as NonoSandboxProvider
    const { result, confined } = runConfined(sandbox, `echo ok; echo x > ${ws}/nope.txt; exit 0`, { mode: 'read-only', workspaceRoot: ws })
    await ctx.fiber.dispose()
    expect(result.status).toBe(0)
    expect(result.stdout).toContain('ok')
    expect(result.stderr).toMatch(/read-only file system|permission denied/i)
    // Denial classification matches the advertised dialect.
    const denied = confined.denialSignatures.some(sig => result.stderr!.toLowerCase().includes(sig))
    expect(denied).toBe(true)
  })

  it('workspace-write: the workspace is writable', async () => {
    const ws = tempDir()
    const ctx = new Context()
    await ctx.plugin(NonoSandboxProvider, { probeTimeoutMs: 15_000 })
    const sandbox = ctx.sandbox as NonoSandboxProvider
    const { result } = runConfined(sandbox, `echo data > ${ws}/w.txt && cat ${ws}/w.txt`, { mode: 'workspace-write', workspaceRoot: ws })
    await ctx.fiber.dispose()
    expect(result.status).toBe(0)
    expect(result.stdout).toContain('data')
  })

  it('payload exit codes pass through the wrapper', async () => {
    const ctx = new Context()
    await ctx.plugin(NonoSandboxProvider, { probeTimeoutMs: 15_000 })
    const sandbox = ctx.sandbox as NonoSandboxProvider
    const { result } = runConfined(sandbox, 'exit 42', { mode: 'read-only', workspaceRoot: '/' })
    await ctx.fiber.dispose()
    expect(result.status).toBe(42)
  })
})
