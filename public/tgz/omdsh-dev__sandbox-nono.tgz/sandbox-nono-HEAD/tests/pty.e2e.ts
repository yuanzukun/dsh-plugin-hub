/**
 * KEYLESS PTY-consumer proof: the REAL `NonoSandboxProvider` argv spawned
 * through node-pty (the same spawn the `pty-local` backend uses for
 * `confined.argv`). Verifies the wrapper's payload runs attached to a real
 * PTY with bytes flowing and the exit code landing. Self-skips when the
 * vendored nono channel does not qualify on this host.
 */

import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { createRequire } from 'node:module'
import { afterEach, describe, expect, it } from 'vitest'
import { Context } from 'cordis'
import { probeNonoChannel } from '@dsh-external/nono-ts'
import { NonoSandboxProvider } from '@deepseek-ai/dsh-sandbox-nono'

// Resolve the package-local test dependency so the standalone checkout has no
// hard-coded path into the DSH monorepo. A host without a Linux node-pty
// native build skips this optional PTY proof just like an unavailable Nono channel.
const require = createRequire(new URL('../package.json', import.meta.url))
const pty: { spawn: (file: string, args: string[], options: Record<string, unknown>) => { onData: (listener: (data: string) => void) => void; onExit: (listener: (event: { exitCode: number }) => void) => void } } | undefined = (() => {
  try {
    return require('node-pty')
  } catch {
    return undefined
  }
})()

const channelUsable = pty !== undefined && probeNonoChannel({ timeoutMs: 15_000 }).usable

let ctx: Context | undefined
const tempDirs: string[] = []

afterEach(async () => {
  await ctx?.fiber.dispose()
  ctx = undefined
  await Promise.all(tempDirs.splice(0).map(dir => rm(dir, { recursive: true, force: true })))
})

async function tempDir(base: string): Promise<string> {
  const dir = await mkdtemp(join(base, 'dsh-nono-pty-'))
  tempDirs.push(dir)
  return dir
}

/** Spawn confined argv under a real PTY and collect output until exit. */
function runConfinedPty(sandbox: NonoSandboxProvider, command: string, cwd: string): Promise<{ exitCode: number; output: string }> {
  const confined = sandbox.confine(['bash', '-c', command], { mode: 'read-only', workspaceRoot: cwd })
  return new Promise((resolve, reject) => {
    const proc = pty!.spawn(confined.argv[0] as string, confined.argv.slice(1), {
      name: 'xterm', cols: 80, rows: 24, cwd, env: process.env,
    })
    let output = ''
    proc.onData((data: string) => { output += data })
    proc.onExit((event: { exitCode: number }) => resolve({ exitCode: event.exitCode, output }))
    setTimeout(() => reject(new Error(`PTY run timed out; collected: ${output.slice(0, 120)}`)), 30_000)
  })
}

describe.skipIf(!channelUsable)('pty spawn: nono-confined argv under a real PTY', () => {
  it('payload runs under the PTY with output flowing and exit code landing', async () => {
    const workdir = await tempDir(tmpdir())
    ctx = new Context()
    await ctx.plugin(NonoSandboxProvider, { probeTimeoutMs: 15_000 })
    const sandbox = ctx.sandbox as NonoSandboxProvider
    const { exitCode, output } = await runConfinedPty(sandbox, 'echo pty-ok; exit 0', workdir)
    expect(exitCode).toBe(0)
    expect(output).toContain('pty-ok')
  })
})
