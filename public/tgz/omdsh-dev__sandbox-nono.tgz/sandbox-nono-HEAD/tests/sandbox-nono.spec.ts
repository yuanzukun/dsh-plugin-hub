/**
 * NonoSandboxProvider tests. No real nono channel is assumed to exist on the
 * test host: `internals.probe` injects deterministic verdicts and
 * `internals.platform` exercises fail-closed surfaces, so policy
 * compilation, verdict caching, per-platform denial signatures,
 * runner-failure rules, and fail-closed behavior are all exercised through
 * the real `confine()` path. The vendored SDK's argv composition is
 * asserted structurally (config wire round-trip), not by spawning.
 */

import { describe, expect, it, vi } from 'vitest'
import { Context } from 'cordis'
import { SANDBOX_UNAVAILABLE, SandboxUnavailableError } from '@deepseek-ai/dsh-sandbox'
import type { SandboxPolicy } from '@deepseek-ai/dsh-sandbox'
import { NonoSandboxProvider } from '@deepseek-ai/dsh-sandbox-nono'
import type { Config } from '@deepseek-ai/dsh-sandbox-nono'
import type { NonoProbeVerdict } from '../src/index.ts'

const RO: SandboxPolicy = { mode: 'read-only', workspaceRoot: '/ws' }
const WW: SandboxPolicy = { mode: 'workspace-write', workspaceRoot: '/ws' }

const USABLE: NonoProbeVerdict = { usable: true, enforcement: 'full' }

async function setup(config: Config = {}, internals: NonoSandboxProvider['internals'] = {}) {
  const ctx = new Context()
  await ctx.plugin(NonoSandboxProvider, config)
  const sandbox = ctx.sandbox as NonoSandboxProvider
  sandbox.internals = internals
  return { ctx, sandbox }
}

/** Decode the `--config-base64` payload of a wrapped argv. */
function decodeConfig(argv: readonly string[]): unknown {
  const index = argv.indexOf('--config-base64')
  expect(index).toBeGreaterThan(-1)
  const encoded = argv[index + 1]
  expect(encoded).toBeDefined()
  return JSON.parse(Buffer.from(encoded as string, 'base64').toString('utf8'))
}

describe('policy compilation', () => {
  it('read-only: whole tree readable, /dev/null writable, nothing else', async () => {
    const { sandbox } = await setup({}, { probe: () => USABLE })
    const confined = sandbox.confine(['bash', '-c', 'true'], RO)
    const config = decodeConfig(confined.argv) as { readRoots: string[]; writeRoots: string[]; writeFiles: string[] }
    expect(config.readRoots).toEqual(['/'])
    expect(config.writeRoots).toEqual([])
    expect(config.writeFiles).toEqual(['/dev/null'])
  })

  it('workspace-write: adds the shared writable roots to /dev/null', async () => {
    const { sandbox } = await setup({}, { probe: () => USABLE })
    const confined = sandbox.confine(['bash', '-c', 'true'], WW)
    const config = decodeConfig(confined.argv) as { readRoots: string[]; writeRoots: string[]; writeFiles: string[] }
    expect(config.readRoots).toEqual(['/'])
    expect(config.writeRoots).toEqual(expect.arrayContaining(['/ws']))
    expect(config.writeFiles).toEqual(['/dev/null'])
  })

  it('payload argv travels verbatim after the separator', async () => {
    const { sandbox } = await setup({}, { probe: () => USABLE })
    const payload = ['bash', '-c', 'echo hi; exit 3']
    const confined = sandbox.confine(payload, RO)
    const separator = confined.argv.indexOf('--')
    expect(separator).toBeGreaterThan(-1)
    expect(confined.argv.slice(separator + 1)).toEqual(payload)
  })
})

describe('channel qualification', () => {
  it('probes once and caches the verdict for the provider lifetime', async () => {
    const probe = vi.fn(() => USABLE)
    const { sandbox } = await setup({}, { probe })
    sandbox.confine(['true'], RO)
    sandbox.confine(['true'], WW)
    expect(probe).toHaveBeenCalledTimes(1)
  })

  it('fails closed with SANDBOX_UNAVAILABLE when the probe reports unusable', async () => {
    const { sandbox } = await setup({}, { probe: () => ({ usable: false, enforcement: 'full', detail: 'no kernel support' }) })
    expect(() => sandbox.confine(['true'], RO)).toThrow(expect.objectContaining({ name: 'SandboxUnavailableError', code: SANDBOX_UNAVAILABLE }))
  })

  it('fails closed with SANDBOX_UNAVAILABLE when the probe throws', async () => {
    const { sandbox } = await setup({}, { probe: () => { throw new Error('binding missing') } })
    expect(() => sandbox.confine(['true'], RO)).toThrow(expect.objectContaining({ name: 'SandboxUnavailableError', code: SANDBOX_UNAVAILABLE }))
  })

  it('reports partial enforcement when the probe says partial', async () => {
    const { sandbox } = await setup({}, { probe: () => ({ usable: true, enforcement: 'partial' }) })
    const confined = sandbox.confine(['true'], RO)
    expect(confined.enforcement).toBe('partial')
  })
})

describe('wrap facts', () => {
  it('carries the Landlock denial dialect on linux', async () => {
    const { sandbox } = await setup({}, { probe: () => USABLE, platform: 'linux' })
    const confined = sandbox.confine(['true'], RO)
    expect(confined.denialSignatures).toEqual(['permission denied', 'read-only file system'])
  })

  it('carries the Seatbelt denial dialect on darwin', async () => {
    const { sandbox } = await setup({}, { probe: () => USABLE, platform: 'darwin' })
    const confined = sandbox.confine(['true'], RO)
    expect(confined.denialSignatures).toEqual(['operation not permitted'])
  })

  it('carries the wrapper runner-failure rule (exit 125 + nono-ts: signature)', async () => {
    const { sandbox } = await setup({}, { probe: () => USABLE })
    const confined = sandbox.confine(['true'], RO)
    expect(confined.runnerFailureRules).toEqual([
      { allowedExitCodes: [125], fatalSignatures: ['nono-ts: '] },
    ])
  })

  it('fails closed on a platform without a nono backend', async () => {
    const { sandbox } = await setup({}, { probe: () => USABLE, platform: 'win32' })
    expect(() => sandbox.confine(['true'], RO)).toThrow(SandboxUnavailableError)
    expect(() => sandbox.confine(['true'], RO)).toThrow(/no backend for win32/)
  })
})

describe('config validation', () => {
  it('rejects a non-positive probe timeout at construction', async () => {
    const ctx = new Context()
    await expect(ctx.plugin(NonoSandboxProvider, { probeTimeoutMs: 0 })).rejects.toThrow(/positive finite/)
  })
})
