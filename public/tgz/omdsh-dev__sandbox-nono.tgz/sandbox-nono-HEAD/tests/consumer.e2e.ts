/**
 * KEYLESS consumer-integration proof: the REAL `NonoSandboxProvider` under
 * the REAL `SandboxBashExecutor`, driven through the executor's public
 * run/start paths. Verifies the WORLD (files exist or don't) plus the
 * stamped result facts; the backend-only confinement proofs live with
 * `@deepseek-ai/dsh-sandbox-nono`'s own e2e.
 *
 * Self-skips when the vendored nono channel does not qualify on this host.
 */

import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { Context } from 'cordis'
import { probeNonoChannel } from '@dsh-external/nono-ts'
import { NonoSandboxProvider } from '@deepseek-ai/dsh-sandbox-nono'
import { SandboxPolicyService } from '@deepseek-ai/dsh-sandbox-policy'
import { SandboxBashExecutor } from '@deepseek-ai/dsh-bash-sandbox'
import LocalSubprocessService from '@deepseek-ai/dsh-subprocess-local'

const channelUsable = probeNonoChannel({ timeoutMs: 15_000 }).usable

let ctx: Context | undefined
const tempDirs: string[] = []

afterEach(async () => {
  await ctx?.fiber.dispose()
  ctx = undefined
  await Promise.all(tempDirs.splice(0).map(dir => rm(dir, { recursive: true, force: true })))
})

async function tempDir(base: string): Promise<string> {
  const dir = await mkdtemp(join(base, 'dsh-nono-consumer-'))
  tempDirs.push(dir)
  return dir
}

async function sandboxedBash(workspace: string, mode: 'read-only' | 'workspace-write'): Promise<SandboxBashExecutor> {
  ctx = new Context()
  await ctx.plugin(NonoSandboxProvider, { probeTimeoutMs: 15_000 })
  await ctx.plugin(SandboxPolicyService, { mode, workspaceRoot: workspace })
  await ctx.plugin(LocalSubprocessService)
  await ctx.plugin(SandboxBashExecutor, { cwd: workspace, timeoutMs: 30_000 })
  return ctx.bash as SandboxBashExecutor
}

describe.skipIf(!channelUsable)('bash-sandbox: real nono confinement through ctx.bash', () => {
  it('read-only denies a write — the file must NOT exist, the result carries denial + enforcement facts', async () => {
    const workdir = await tempDir(tmpdir())
    const bash = await sandboxedBash(workdir, 'read-only')
    const result = await bash.run(bash.resolve({ command: `echo hi > ${workdir}/denied.txt` }))
    // The redirect is denied; bash reports the failure with exit 1.
    expect(result.exitCode).toBe(1)
    expect(result.sandbox).toMatchObject({ mode: 'read-only', denied: true, enforcement: 'full' })
    const { access } = await import('node:fs/promises')
    await expect(access(join(workdir, 'denied.txt'))).rejects.toThrow()
  })

  it('workspace-write allows the workspace — the file exists, no denial is stamped', async () => {
    const workdir = await tempDir(tmpdir())
    const bash = await sandboxedBash(workdir, 'workspace-write')
    const result = await bash.run(bash.resolve({ command: `echo data > ${workdir}/ok.txt && cat ${workdir}/ok.txt` }))
    expect(result.exitCode).toBe(0)
    expect(result.stdout.text).toContain('data')
    expect(result.sandbox).toMatchObject({ mode: 'workspace-write', denied: false })
    const { readFile } = await import('node:fs/promises')
    expect(await readFile(join(workdir, 'ok.txt'), 'utf8')).toBe('data\n')
  })

  it('payload exit codes and stderr pass through the confined bash run', async () => {
    const workdir = await tempDir(tmpdir())
    const bash = await sandboxedBash(workdir, 'read-only')
    const result = await bash.run(bash.resolve({ command: 'echo err >&2; exit 7' }))
    expect(result.exitCode).toBe(7)
    expect(result.stderr.text).toContain('err')
    expect(result.sandbox).toMatchObject({ mode: 'read-only', denied: false })
  })
})
