/**
 * nono (Landlock/Seatbelt) backend for the sandbox seam.
 * It pins `@dsh-external/nono-ts` exactly (vendored, never registry-resolved)
 * and lets the SDK own executor resolution AND invocation
 * (`buildLaunchArgv` / `probeNonoChannel`), compiles the DSH file-effect
 * policy into an explicit nono capability config, and qualifies the executor
 * channel functionally before serving. Activation is composition-driven:
 * registering this provider as `ctx.sandbox` is the deployment's explicit
 * opt-in; the provider itself fails closed with `SANDBOX_UNAVAILABLE` on any
 * host without a vendored binding or a passing probe.
 *
 * The vendored SDK carries the platform binding under `native/<target>/`
 * (only linux-x64-gnu is currently committed), the exact-argv wrapper
 * (`dist/wrapper.js`), and the probe contract; the provider never spells the
 * wrapper's CLI. Linux and macOS are the supported host surfaces (nono
 * Landlock / Seatbelt); any other platform fails closed. Denials surface
 * through the kernel's dialect (EACCES/EROFS text under Landlock,
 * EPERM text under Seatbelt), carried per wrap as `denialSignatures`, and
 * wrapper-side failures carry the `nono-ts: ` stderr signature gated on the
 * wrapper's reserved exit 125.
 * @module @deepseek-ai/dsh-sandbox-nono
 */

import { Context } from 'cordis'
import z from 'schemastery'
import { buildLaunchArgv, probeNonoChannel } from '@dsh-external/nono-ts'
import type { NonoCapabilityConfig } from '@dsh-external/nono-ts'
import { SandboxProvider, SandboxUnavailableError } from '@deepseek-ai/dsh-sandbox'
import type { ConfinedArgv, RunnerFailureRule, SandboxPolicy } from '@deepseek-ai/dsh-sandbox'
import { canonicalPath, writableRoots } from '@deepseek-ai/dsh-sandbox'

/** The wrapper's reserved failure exit (its own contract; the seam gates on it). */
const NONO_WRAPPER_FAILURE_EXIT = 125

/**
 * The kernel denial dialect per host platform: case-insensitive stderr
 * substrings a denied file effect produces under nono's backend. Landlock
 * denies reads with EACCES text and writes with EROFS text; Seatbelt denies
 * with EPERM text. A platform outside the map fails closed before any wrap.
 */
const DENIAL_SIGNATURES: Partial<Record<NodeJS.Platform, readonly string[]>> = {
  linux: ['permission denied', 'read-only file system'],
  darwin: ['operation not permitted'],
}

/** Wrapper-side fatal diagnostics: the reserved exit plus the `nono-ts: ` stderr signature. */
const RUNNER_FAILURE_RULES: readonly RunnerFailureRule[] = [
  { allowedExitCodes: [NONO_WRAPPER_FAILURE_EXIT], fatalSignatures: ['nono-ts: '] },
]

/** Plugin config. All optional — `static Config` supplies the defaults. */
export interface Config {
  /** Positive timeout for the functional channel probe; zero would mean unbounded to Node. */
  probeTimeoutMs?: number
}

/** Test seam: inject probe verdicts and a platform without a real binding (mirrors `dsh-sandbox-local`). */
export interface NonoSandboxInternals {
  /** Replaces the functional channel qualification (a fake verdict). */
  probe?: () => NonoProbeVerdict
  /** Replaces `process.platform` for backend/denial resolution. */
  platform?: NodeJS.Platform
}

/** The probe verdict shape the provider consumes (mirrors the SDK's). */
export interface NonoProbeVerdict {
  usable: boolean
  enforcement: 'full' | 'partial'
  detail?: string
}

/**
 * A probe bound must be a positive finite number: Node treats
 * `spawnSync({ timeout: 0 })` as NO timeout, so an unvalidated 0 would
 * silently mean "unbounded" — the opposite of what the field promises.
 */
function assertPositiveFinite(name: string, value: number): void {
  if (!Number.isFinite(value) || value <= 0) {
    throw new Error(`sandbox-nono: ${name} must be a positive finite number`)
  }
}

/**
 * Compile the DSH file-effect policy into an explicit nono capability
 * config. Omission never means permissive: every promised effect is stated
 * — the whole tree readable, the mode's writable roots (shared
 * `writableRoots` derivation, canonicalized), and the `/dev/null` sink the
 * landlock profile family always grants (`/dev/null` is a FILE, so it is
 * granted through the `writeFiles` channel — `allowPath` rejects files).
 * The config is the SDK's wire shape; the wrapper turns it into a
 * `CapabilitySet`.
 * @param policy - the confined DSH file-effect mode and workspace root.
 * @returns the nono capability wire config.
 */
function compileConfig(policy: SandboxPolicy): NonoCapabilityConfig {
  const writeRoots = writableRoots(policy)
  return {
    readRoots: ['/'],
    writeRoots: writeRoots.map(canonicalPath),
    writeFiles: ['/dev/null'],
  }
}

/**
 * nono process-sandbox provider. Registers as `ctx.sandbox`. Qualifies the
 * vendored executor channel once (functional probe: apply + enforcement
 * bite) and caches the verdict for the provider lifetime; a host without a
 * vendored binding, an unsupported platform, or a failing probe fails
 * closed at `confine()` with `SANDBOX_UNAVAILABLE`.
 */
export class NonoSandboxProvider extends SandboxProvider {
  static Config: z<Config> = z.object({
    probeTimeoutMs: z.natural().default(5_000),
  })

  /** Test hook (mirrors the bash executors' `internals`). */
  internals: NonoSandboxInternals = {}

  private readonly probeTimeoutMs: number
  /** Cached channel verdict; undefined until the first confined wrap needs it. */
  private channelVerdict: NonoProbeVerdict | undefined

  constructor(ctx: Context, config: Config) {
    super(ctx)
    this.probeTimeoutMs = config.probeTimeoutMs as number
    assertPositiveFinite('probeTimeoutMs', this.probeTimeoutMs)
  }

  /**
   * Wrap `argv` so it executes confined under `policy` on this host. The
   * returned argv spawns the vendored nono wrapper (through
   * `process.execPath`), which applies the compiled capability set and then
   * execs the payload under the kernel restrictions; the caller spawns it in
   * place of its own argv.
   * @param argv - the exact argv the caller is about to spawn.
   * @param policy - the file-effect policy this execution runs under.
   * @returns the wrapped argv plus enforcement, denial signatures, and
   *   runner-failure rules; throws the fail-closed `SANDBOX_UNAVAILABLE`
   *   error when the host has no usable channel.
   */
  confine(argv: readonly string[], policy: SandboxPolicy): ConfinedArgv {
    const platform = this.internals.platform ?? process.platform
    const denialSignatures = DENIAL_SIGNATURES[platform]
    if (denialSignatures === undefined) throw new SandboxUnavailableError(policy.mode, `nono has no backend for ${platform}`)
    const verdict = this.selectChannel()
    if (!verdict.usable) throw new SandboxUnavailableError(policy.mode, verdict.detail)
    return {
      argv: buildLaunchArgv(compileConfig(policy), argv),
      enforcement: verdict.enforcement === 'partial' ? 'partial' : 'full',
      denialSignatures,
      runnerFailureRules: RUNNER_FAILURE_RULES,
    }
  }

  /**
   * The qualified channel verdict, once, for the provider's lifetime: the
   * functional probe through the SDK's `probeNonoChannel` (apply a minimal
   * read-only config and verify enforcement bites), or the injected test
   * verdict. A failing or throwing probe fails closed — the command never
   * runs unconfined.
   */
  private selectChannel(): NonoProbeVerdict {
    if (this.channelVerdict === undefined) {
      const probe = this.internals.probe ?? (() => probeNonoChannel({ timeoutMs: this.probeTimeoutMs }))
      try {
        this.channelVerdict = probe()
      } catch (error) {
        this.channelVerdict = { usable: false, enforcement: 'full', detail: error instanceof Error ? error.message : String(error) }
      }
    }
    return this.channelVerdict
  }
}

export default NonoSandboxProvider
