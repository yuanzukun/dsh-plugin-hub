# @deepseek-ai/dsh-sandbox-nono

[English](nono.md) | 中文

[nono](https://nono.sh) 沙箱 seam（`@deepseek-ai/dsh-sandbox`）后端。它用 seam 执行器包装 vendored [`@dsh-external/nono-ts`](../vendor-nono-ts/README.md) 原生绑定（nono 0.61.1，Apache-2.0）：SDK 拥有绑定解析、启动 argv 拼装与功能性通道探测；本 provider 把 DSH 文件效应策略编译为显式 nono capability 配置并提供 confine seam。

包根导出默认与具名 `NonoSandboxProvider` 插件及 `Config`。

## 如何隔离

`confine()` 返回经 `process.execPath` 启动 vendored wrapper 的 argv:

```
[node, wrapper.js, '--binding', <dir>, '--config-base64', <b64>, '--', ...payload]
```

wrapper 加载原生绑定,应用由策略编译的 `CapabilitySet`,然后在内核限制下(Linux=Landlock,macOS=Seatbelt) spawn 负载,负载 stdio 原样继承、退出码镜像透传。策略编译是显式的 — 遗漏绝不等于放行:

- `read-only`:整棵树可读(`readRoots: ['/']`),除 `/dev/null` sink(`writeFiles`)外不可写。
- `workspace-write`:追加共享可写根(`dsh-sandbox` 的 `writableRoots` 推导 — workspace 根、`/tmp` 与用户临时目录,canonical 化)。

无 vendored 绑定的平台(如 Windows)、缺失绑定或功能探测失败都以 `SANDBOX_UNAVAILABLE` fail-closed; 负载绝不会无限制地启动。

```yaml
- id: sandbox-nono
  name: '@deepseek-ai/dsh-sandbox-nono'
  disabled: false
  config:
    probeTimeoutMs: 5000
```

## Wrap 事实

- `enforcement`:探测通过后为 `full`(仅当探测报告时才为 `partial`)。
- `denialSignatures`:各宿主的内核方言 — Linux 为 `permission denied` / `read-only file system` (Landlock EACCES/EROFS),macOS 为 `operation not permitted`(Seatbelt EPERM)。
- `runnerFailureRules`:wrapper 保留退出码 `125` 加 `nono-ts: ` stderr 签名 — wrapper 侧失败 (绑定缺失、apply 被拒)是 runner 失败,绝不是命令结果。

## Model Experience

间接地，经由 `@deepseek-ai/dsh-bash-sandbox` 与 `@deepseek-ai/dsh-tool-bash` 呈现本 provider 的 enforcement 与 denial 事实，而 `@deepseek-ai/dsh-sandbox` seam 拥有 `SANDBOX_UNAVAILABLE` 文案。

#### KV Cache 影响

无直接失效;具名消费方拥有任何请求前缀变更。

## 已知限制与延后工作

- **仅 vendored linux-x64-gnu** — 已提交的原生绑定覆盖 Linux x64 构建宿主;其他平台在绑定构建并 加入 `vendor-nono-ts/native/` 之前 fail-closed(构建流程见 vendor README)。
- **Windows 无 nono 后端** — nono-ts 没有 Windows 绑定(nono 本身仅 WSL2);`win32` 以 `SANDBOX_UNAVAILABLE` fail-closed。
- **探测结论在 provider 生命周期内缓存** — 安装或修复绑定需要重载插件。
- **wrapper 失败退出码 125 被保留** — 负载自身以 125 退出且 stderr 含 `nono-ts: ` 会被归类为 runner 失败;退出码门控的签名使该情况不太可能。
