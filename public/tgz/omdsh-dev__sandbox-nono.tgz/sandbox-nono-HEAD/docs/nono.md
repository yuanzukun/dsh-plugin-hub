# @deepseek-ai/dsh-sandbox-nono

English | [中文](nono.zh.md)

[nono](https://nono.sh) backend for the `@deepseek-ai/dsh-sandbox` seam. It wraps the vendored [`@dsh-external/nono-ts`](../vendor-nono-ts/README.md) native binding (nono 0.61.1, Apache-2.0) with a seam executor: the SDK owns binding resolution, launch argv composition, and functional channel qualification; this provider compiles the DSH file-effect policy into an explicit nono capability config and serves the confine seam.

The package root exports the default and named `NonoSandboxProvider` plugin and `Config`.

## How it confines

`confine()` returns argv that spawns the vendored wrapper through `process.execPath`:

```
[node, wrapper.js, '--binding', <dir>, '--config-base64', <b64>, '--', ...payload]
```

The wrapper loads the native binding, applies a `CapabilitySet` compiled from the policy, then spawns the payload under the kernel restrictions (Landlock on Linux, Seatbelt on macOS) with the payload's stdio inherited and its exit code mirrored. Policy compilation is explicit — omission never means permissive:

- `read-only`: whole tree readable (`readRoots: ['/']`), nothing writable except the `/dev/null` sink (`writeFiles`).
- `workspace-write`: adds the shared writable roots (`writableRoots` derivation from `dsh-sandbox` — workspace root, `/tmp`, and the per-user temp dir, canonicalized).

Unsupported platforms (no vendored binding, e.g. Windows), a missing binding, or a failing functional probe fail closed with `SANDBOX_UNAVAILABLE`; the payload is never spawned unrestricted.

```yaml
- id: sandbox-nono
  name: '@deepseek-ai/dsh-sandbox-nono'
  disabled: false
  config:
    probeTimeoutMs: 5000
```

## Wrap facts

- `enforcement`: `full` after a passing probe (`partial` only if the probe reports it).
- `denialSignatures`: the kernel's dialect per host — `permission denied` / `read-only file system` (Landlock EACCES/EROFS) on Linux, `operation not permitted` (Seatbelt EPERM) on macOS.
- `runnerFailureRules`: the wrapper's reserved exit `125` plus the `nono-ts: ` stderr signature — a wrapper-side failure (missing binding, apply rejection) is a runner failure, never a command outcome.

## Model Experience

Indirectly, through `@deepseek-ai/dsh-bash-sandbox` and `@deepseek-ai/dsh-tool-bash`, which render this provider's enforcement and denial facts while `@deepseek-ai/dsh-sandbox` owns the `SANDBOX_UNAVAILABLE` text.

#### KV Cache effect

No direct invalidation; the named consumer owns any request-prefix changes.

## Known Limitations and Deferred Work

- **Only linux-x64-gnu is vendored** — the committed native binding covers the Linux x64 build host; other platforms fail closed until their bindings are built and added to `vendor-nono-ts/native/` (see the vendor README for the build procedure).
- **Windows has no nono backend** — nono-ts has no Windows binding (nono itself is WSL2-only); `win32` fails closed with `SANDBOX_UNAVAILABLE`.
- **Probe verdict is cached for the provider lifetime** — installing or repairing a binding requires reloading the plugin.
- **Wrapper failure exit 125 is reserved** — a payload that itself exits 125 with `nono-ts: ` on stderr would be classified as a runner failure; the exit-gated signature keeps that unlikely.
