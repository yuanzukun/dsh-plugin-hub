# dsh-upload-file 展示优化设计方案

> 目标：解决「导入成功后对话/草稿里显示的是路径与 JSON 原文，UI 不美观」的问题。

## 一、问题根因（已核实）

1. 目前插入草稿的文本是 [file attachment {…JSON…}] 📎 [名称](/dsh-upload/raw/<id>)。
2. shell 的 markdown 渲染器（dsh-client-ui-primitives）对不受信输出禁用相对链接——
   [名称](/dsh-upload/raw/…) 这种相对 URL 不渲染成链接，而是按字面文本显示，
   于是用户看到的就是 /dsh-upload/raw/sha256:… 路径原文。
3. 整段 JSON 注释对用户无意义，纯属噪音。

## 二、约束调研结论（已核实，决定了方案边界）

| 约束 | 结论 |
| --- | --- |
| markdown 语法扩展 | ❌ 无插件扩展点：micromark 语法集（gfm/math）在 ui-primitives 里写死，消息渲染管线不可插拔自定义语法 |
| 绝对 http(s) 链接 | ✅ 通过协议白名单，[label](http://…/raw/…) 会渲染成真正的可点击链接 |
| 用户消息渲染槽位 conversation.chat.node（keyed） | ⚠️ 同一 key 只有一个胜者（按 priority 升序，最低者胜出，其余被影子化）——想加“卡片”只有两条路：接管全部用户消息渲染（priority -1 影子化官方渲染器），或不动它 |
| 官方 UserMessageNodeView | ❌ 未从包的公共入口导出，接管后必须手写复刻官方气泡视图 |
| composer 草稿 | ⚠️ 输入框内无插件化富渲染（装饰系统只支持 slash/mention 词表高亮）；但 composer **周边**有槽位：`conversation.input.dock`（输入卡上方）可挂插件 UI，且 `conversation.sendSession` 可被结构性包装（describe-image 同款发送钩子）——据此可实现「待发送文件条」：上传后文件以胶囊 chip 显示在输入框上方（类图片条），发送时钩子把链接并入消息文本（v0.4.0 已验证） |
| MarkdownText 组件 | ✅ 从 dsh-client-ui-primitives 公共导出，可在自定义渲染中复用 |
| 模型侧 | ✅ read_uploaded_file 已支持从 URL 提取 id（parseFileReference 处理 /dsh-upload/raw/<id> 形式），消息里不再需要 JSON |

## 三、方案 A（推荐，最小改动，本次实施）

### 改动点

1. 插入文本改为干净链接（去掉 JSON note）：

   📎 [报告.pdf（12.3 KiB）](http://127.0.0.1:3080/dsh-upload/raw/sha256:abc…)

   - origin 在插入时取 location.origin 动态拼接（跟随实际 GUI 地址/端口/反代域名），保证是绝对 URL、能通过渲染白名单。
   - 链接 label 携带文件名 + 人类可读大小（文件字节数客户端已知），多文件每行一个链接。
   - 可选：link title 放类型信息（如 报告.pdf · application/pdf），仅作 hover tooltip，不影响渲染。
2. host 不改（serveRaw 已返回附件下载；parseFileReference 已解析 URL）。
3. README 同步更新示例与说明。

### 效果

| 位置 | 现状 | 方案 A 后 |
| --- | --- | --- |
| 会话消息 | 显示 /dsh-upload/raw/… 路径 + JSON | 显示蓝色链接 📎 报告.pdf（12.3 KiB），点击下载 |
| 草稿 | JSON + 路径原文 | 📎 [报告.pdf（12.3 KiB）](…) 一行 markdown（纯文本输入框限制，已是最优） |
| 模型 | 从 JSON 取元数据 | 从 URL 取 id（能力不变，name 在 label、大小在 label） |

### 风险

- 低。不触碰渲染管线与槽位，只改插入文本格式；shell 升级无影响。
- 局限：草稿内仍显示一行 markdown 原文（shell 能力限制，非本插件可改）——见方案 A2 已进一步消除。

## 三·五、方案 A2（已实施 v0.4.0：待发送文件条，类图片上传）

在方案 A（干净链接）基础上，把「拼进草稿」升级为「待发送文件条」：

### 机制（均已在真机验证）

1. **上传即进条**：附件按钮/拖放上传成功后，文件以胶囊 chip 显示在 composer 上方的 `conversation.input.dock` 槽位（`role="group" aria-label="待发送文件"`），chip = 回形针 SVG + 文件名 + 大小 + × 移除；草稿保持干净。
2. **仅发文件可用**：条非空且草稿为空时，往草稿写入一个不可见占位符 U+200B（shell 的发送按钮 `empty` 判定只看草稿文本与图片附件），使发送按钮可用；条清空即恢复空草稿。
3. **发送钩子**：结构性包装 `conversation.sendSession`（describe-image 同款、幂等 marker、可卸载、失败恢复条内容），发送时把条内链接并入消息文本（并剥离 U+200B）；无待发文件时原样穿透。
4. 发送成功后条清空；会话里仍是方案 A 的干净蓝色链接（消息渲染零改动）。

### 与方案 B 的关系

- A2 ≠ B：B 是**会话消息内**的文件卡片（`conversation.chat.node` 接管渲染，高漂移风险，仍为独立可选二期）；A2 只作用于**发送前**的 composer 区，走原生槽位 + 服务包装，不触碰消息渲染。
- 若用户问“像图片上传那样” → 指的就是 A2 这类发送前附件条（shell 图片条「待发送图片」是同一交互范式）。

### 风险

- 低。不触碰渲染管线；发送钩子仅在条非空时介入；无条时行为与 v0.3.x 完全一致。
- 局限：条渲染在输入卡上方（无输入卡内部槽位）；刷新页面后条清空（已上传字节仍在，内容寻址无害）；U+200B 占位符若钩子失效会以空文本发出（shell 忽略空消息）。

## 四、方案 B（已实施 v0.5.0：会话内文件卡片）

### 思路（实施版）

注册 `conversation.chat.node`（key=user 与 key=steering，priority=-1）接管用户消息渲染（低优先级胜出，影子官方渲染器）：

1. 解析消息文本，命中本插件的文件链接（`📎 [名称（大小）](http(s)://…/dsh-upload/raw/sha256:hex)`，绝对 URL + sha256 id）时：
   - 渲染成卡片行（`role="group" aria-label="待发送文件"`）：回形针图标 + 文件名 + 大小 + 打开链接；纯链接消息不显示气泡（类图片附件条）；
   - 消息其余文本用官方 `MessageText`（primitives 公共导出）照常渲染进气泡；
   - 卡片不占对话文本——原始文本仍发给模型（URL 含 id，能力不变），复制按钮复制原文。
2. 未命中文件链接时：**逐条复刻官方用户气泡**（`.userRow/.userStack/.bubble` 的令牌级 CSS + 图片画廊 `ImageGallery`（attachment 公共导出）+ `MessageText` + 时钟 + 复制按钮）。

### 关键调研结论（v0.5.0 核实）

- 官方 `UserMessageNodeView` / `UserStyleBubble` **未从公共入口导出**，但 `@deepseek-ai/dsh-client-ui-primitives` 与 `@deepseek-ai/dsh-client-ui-attachment` 是模块系统的 **seed 模块**（`__DSH_MODULES__.seed`），插件工厂可直接 `require` 拿到 `MessageText / JsonBlock / Tooltip / writeClipboard / IconCopyOutline16 / IconCheckOutline16 / IconPaperclipOutline16 / IconDownloadOutline16 / ImageGallery`——复刻面大幅缩小。
- slots 的 keyed 槽位按 **priority 升序取第一个**为胜者；官方注册 key=user/steering 无 priority（默认 0），本插件注册 -1 胜出。
- **内置安全网**：若本插件 entry 渲染崩溃，slots 会 `reportEntryError` 退役该 entry（abdicate），出口自动回退到下一个幸存者（官方渲染器），不会白屏。
- 官方气泡 CSS 类名是构建期哈希（`gdEzaW_*` 等），**不能引用**；本插件用相同设计令牌（`--dsw-specific-bubble`、`--dsw-alias-*`）自写 `.dsh-uf-*` 规则，随主题/暗色自动适配。

### 代价与风险（实施后评估）

- 官方 UserMessageNodeView 未从公共入口导出，接管后必须手写复刻整个用户消息视图（气泡、图片块、时钟、复制按钮、/ @ 词条 chip）。
- shell 升级可能漂移：官方 CSS 类名与内部结构变更需同步 `.dsh-uf-*` 规则；渲染崩溃时自动回退官方渲染器兜底。
- 收益：真正的“文件卡片”视觉，与图片附件同一范式，最符合美观诉求。

## 实施状态

- 方案 A：✅ 已实施（v0.3.0，2026-08-17）：客户端改为干净链接格式，宿主零改动（parseFileReference 原生支持绝对 URL）。
- 方案 A2：✅ 已实施（v0.4.0，2026-08-17）：待发送文件条（dock 槽位）+ sendSession 发送钩子；按钮与拖放均进条，草稿干净，仅发文件可用，发送后消息为方案 A 的蓝色链接。
- 方案 B：✅ 已实施（v0.5.0，2026-08-17）：chat.node 接管（key=user/steering，priority -1）；含文件链接 → 卡片行 + 剩余文本气泡；否则复刻官方用户气泡（MessageText + ImageGallery + 时钟/复制）。渲染崩溃自动回退官方。

## 五、明确不做的事

- ❌ 自定义 markdown 语法隐藏原始文本：无扩展点，不可行。
- ❌ 输入框内联富渲染（draft 内 chip/卡片）：装饰系统只支持 slash/mention 词表高亮，不可行；但发送前附件条（A2，dock 槽位）与发送钩子已覆盖同样诉求。
- ❌ 按扩展名定制卡片图标库：当前统一回形针图标，保持与附件按钮视觉一致；如需按类型换图标可在 FileCard 中扩展。
- ❌ 把 JSON 塞进 link title 隐藏：虽可行（单引号 title），但草稿仍显示、且模型解析成本更高，收益不抵复杂度。

## 六、验收标准

### 方案 A（已验收，v0.3.0）

1. 上传/拖入文件后，插入文本为 📎 [名称（大小）](http(s)://…/dsh-upload/raw/<id>)，无 JSON。
2. 发送后，会话里显示为可点击的蓝色链接（不再出现 /dsh-upload/raw/… 路径文字）。
3. 点击链接可下载文件；旧消息（已用旧格式发送）渲染不受影响。
4. 模型仍能调用 read_uploaded_file 读取（URL 形式 id）。
5. 多文件拖入：每文件一行链接。

### 方案 A2（已验收，v0.4.0）

6. 按钮/拖放上传后，文件以胶囊 chip 出现在 composer 上方的「待发送文件」条，草稿不含 markdown（仅一个不可见占位符）。
7. 条非空且草稿为空时发送按钮可用；发送后消息包含对应链接、条被清空。
8. chip 的 × 可移除单个文件，移除后占位符恢复为空草稿。
9. 多文件共存于条内（flex wrap）；无待发文件时发送路径与无插件时一致（钩子穿透）。

### 方案 B（已验收，v0.5.0）

10. 含本插件文件链接的用户消息渲染为卡片行（图标 + 文件名 + 大小 + 打开），纯链接消息无气泡。
11. 文字 + 链接的混合消息：文字气泡 + 卡片行；链接不在气泡内重复显示。
12. 不含文件链接的用户消息渲染与官方气泡一致（同令牌同几何：气泡底色/圆角/字号、图片画廊、时钟、复制按钮）。
13. 复制按钮复制原始文本（含链接）；时钟显示 HH:MM（跨天加日期）。
14. 卡片点击打开 raw URL；旧格式消息（相对路径/JSON）按普通文本渲染。
15. 渲染异常时自动回退官方渲染器（slots abdicate 兜底），不白屏。
