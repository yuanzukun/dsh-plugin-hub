/**
 * @dsh-external/donsetch : first-class DonSeTch web access for
 * DeepSeek Harness.
 *
 * The plugin spawns ONE supervised `donsetch mcp` daemon, registers
 * every tool the daemon lists (tool parity with the standard
 * donsetch MCP server is guaranteed by construction), and proxies
 * calls with the same JSON-RPC discipline as the pi extension: real
 * cancellation, per-call timeouts, clean restart on daemon loss.
 *
 * Native-feel pieces:
 * - tools are registered in-process on ctx.tools with clean names
 *   (donsetch_web_fetch, not mcp__donsetch__web_fetch) and flow
 *   through dsh's full permission/timeout/cancellation pipeline;
 * - each tool carries call/result cards for the Web workbench;
 * - the donsetch config file (the one `donsetch keys add` writes) is
 *   watched, so CLI changes from any terminal reach the live daemon;
 * - a donsetch_status tool reports version, daemon state, and the
 *   doctor output so the agent can self-diagnose;
 * - the binary auto-updates from GitHub Releases on the configured
 *   channel, SHA256-verified, swapped only between in-flight calls;
 * - the harness's native web_search tool is routed through a donsetch
 *   search provider (the bundle patch selects it), so ordinary
 *   web_search calls work with no DeepSeek API key.
 *
 * Zero runtime imports from the host train: the plugin talks to the
 * harness exclusively through the ctx handed to apply().
 */

import type { Context } from '@deepseek-ai/cordis'
import type { ContentBlock, ToolDefinition, ToolRunContext } from '@deepseek-ai/dsh-tools'
import type { WebRuntime, WebSearchProvider, WebSearchRequest, WebSearchResult, WebSearchSource } from '@deepseek-ai/dsh-web'

import { spawnSync } from 'node:child_process'
import { existsSync, statSync, unwatchFile, watchFile } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

import { cacheDir, checkForUpdate, downloadBinary, installedVersions, resolveBinary, type ResolvedBinary } from './binary.js'
import { McpClient, type McpResult } from './mcp.js'
import { callKind, callTitle, firstLine, isValidPrefix, publicToolName, specToJsonSchema, toDshSpec } from './schemas.js'
import { PINNED_DONSETCH_VERSION, PLUGIN_VERSION } from './version.js'

export const name = 'donsetch'
export const inject = ['tools'] as const

export type UpdateChannel = 'stable' | 'latest'

export interface DonsetchConfig {
  /** Model-facing tool prefix; default donsetch. */
  toolPrefix?: string
  /** Release channel for auto-updates. */
  channel?: UpdateChannel
  /** Auto-download+swap newer donsetch releases. Default true. */
  autoUpdate?: boolean
  /** Minimum gap between update checks, hours. Default 24. */
  updateIntervalHours?: number
  /** Per-call MCP timeout, ms. Default 180000. */
  callTimeoutMs?: number
  /** Initialize + tools/list timeout, ms. Default 20000. */
  bootTimeoutMs?: number
  /** Fall back to a donsetch already on PATH when download fails. */
  fallbackToPath?: boolean
  /** donsetch release pinned for fresh installs (floor, not ceiling). */
  pinnedVersion?: string
}

interface ResolvedConfig {
  toolPrefix: string
  channel: UpdateChannel
  autoUpdate: boolean
  updateIntervalHours: number
  callTimeoutMs: number
  bootTimeoutMs: number
  fallbackToPath: boolean
  pinnedVersion: string
}

/** Time to add on top of a call's own budget before the client gives up. */
const CALL_DEADLINE_SLACK_MS = 20_000
/** The largest legal budget (600s) plus slack. */
const MAX_CALL_TIMEOUT_MS = 620_000

function positiveNumber(value: unknown): number | null {
  const n = typeof value === 'number' ? value : typeof value === 'string' ? Number(value) : NaN
  return Number.isFinite(n) && n > 0 ? n : null
}

/**
 * Per-call timeout for one tools/call. The configured callTimeoutMs is a
 * single bound for every tool, but the binary's own budgets are larger
 * than it: web_crawl accepts deadline_s up to 600 and web_fetch
 * deadline_ms up to 600000, so a legal call was being killed by the
 * client while the server was still inside its documented deadline (the
 * crawl default of 120s already sat inside the 180s default, racing
 * it). Derive the timeout from the call's own budget plus slack, capped
 * at the largest budget the schemas allow so a hostile argument cannot
 * hold a slot forever.
 */
export function callTimeoutFor(name: string, args: unknown, baseMs: number): number {
  const a = (args ?? {}) as Record<string, unknown>
  let budgetMs: number | null = null
  if (name === 'web_crawl') {
    const secs = positiveNumber(a.deadline_s)
    // No budget (or an unusable one) means the binary's own default.
    budgetMs = secs !== null ? secs * 1000 : 120_000
  } else if (name === 'web_fetch') {
    budgetMs = positiveNumber(a.deadline_ms)
  }
  if (budgetMs === null) return baseMs
  return Math.min(budgetMs + CALL_DEADLINE_SLACK_MS, MAX_CALL_TIMEOUT_MS)
}

function resolveConfig(raw: DonsetchConfig): ResolvedConfig {
  const prefix = raw.toolPrefix ?? process.env.DONSETCH_DSH_PREFIX ?? 'donsetch'
  if (!isValidPrefix(prefix)) {
    throw new Error(`donsetch plugin: toolPrefix ${JSON.stringify(prefix)} must match [A-Za-z0-9_]{1,16}`)
  }
  const channel: UpdateChannel = process.env.DONSETCH_DSH_CHANNEL === 'latest' || raw.channel === 'latest' ? 'latest' : 'stable'
  const autoUpdate = process.env.DONSETCH_DSH_AUTOUPDATE === 'off' ? false : (raw.autoUpdate ?? true)
  return {
    toolPrefix: prefix,
    channel,
    autoUpdate,
    updateIntervalHours: clampInt(raw.updateIntervalHours, 1, 24 * 30, 24),
    callTimeoutMs: clampInt(raw.callTimeoutMs, 5000, 900_000, 180_000),
    bootTimeoutMs: clampInt(raw.bootTimeoutMs, 5000, 120_000, 20_000),
    fallbackToPath: raw.fallbackToPath ?? true,
    pinnedVersion: raw.pinnedVersion ?? PINNED_DONSETCH_VERSION,
  }
}

function clampInt(value: unknown, min: number, max: number, fallback: number): number {
  const n = typeof value === 'number' && Number.isFinite(value) ? Math.round(value) : fallback
  return Math.min(max, Math.max(min, n))
}

/** Resolve the config file the real donsetch CLI reads, per OS. */
export function donsetchConfigPath(): string {
  const override = process.env.DONSETCH_DSH_HOME?.trim()
  const home = donsetchHome()
  if (process.platform === 'win32') {
    const base = override
      ? join(home, 'AppData', 'Roaming')
      : process.env.APPDATA?.trim() || join(home, 'AppData', 'Roaming')
    return join(base, 'donsetch', 'config.json')
  }
  if (process.platform === 'darwin') {
    return join(home, 'Library', 'Application Support', 'donsetch', 'config.json')
  }
  return join(home, '.config', 'donsetch', 'config.json')
}

/**
 * The file the real CLI writes provider keys into (`donsetch keys
 * add` -> cache_dir/byok-keys.json). This is the state Dondai
 * expects to carry over: watch it, and surface its path in status.
 */
export function donsetchKeysPath(): string {
  const override = process.env.DONSETCH_DSH_HOME?.trim()
  const home = donsetchHome()
  if (process.platform === 'win32') {
    const base = override
      ? join(home, 'AppData', 'Local')
      : process.env.LOCALAPPDATA?.trim() || join(home, 'AppData', 'Local')
    return join(base, 'donsetch', 'byok-keys.json')
  }
  if (process.platform === 'darwin') {
    return join(home, 'Library', 'Caches', 'donsetch', 'byok-keys.json')
  }
  return join(home, '.cache', 'donsetch', 'byok-keys.json')
}

function donsetchHome(): string {
  const override = process.env.DONSETCH_DSH_HOME?.trim()
  if (override) return override
  const forceHome = process.env.HOME?.trim()
  if (process.platform === 'win32') {
    return forceHome || process.env.USERPROFILE?.trim() || homedir()
  }
  return forceHome || homedir()
}

interface BootedState {
  bin: ResolvedBinary
  client: McpClient
}

/**
 * Render the canonical tool result (the raw MCP result object) into
 * model-facing content blocks. Text blocks pass through; exotic block
 * types are stringified so no content is ever silently dropped.
 */
function renderContent(value: unknown): ContentBlock[] {
  const result = (value ?? {}) as Partial<McpResult>
  const blocks = Array.isArray(result.content)
    ? result.content.map((block) => {
        const b = (block ?? {}) as Record<string, unknown>
        if (typeof b.text === 'string') return { type: 'text', text: b.text } as ContentBlock
        try {
          return { type: 'text', text: JSON.stringify(b) } as ContentBlock
        } catch {
          return { type: 'text', text: String(b) } as ContentBlock
        }
      })
    : []
  if (blocks.length === 0) return [{ type: 'text', text: 'donsetch returned no content' }]
  return blocks
}

/** Provider-side error shape the web seam surfaces in tool metadata. */
class DonsetchWebError extends Error {
  readonly code: string

  constructor(message: string, code: string) {
    super(message)
    this.name = 'DonsetchWebError'
    this.code = code
  }
}

function webSearchError(message: string, code = 'WEB_PROVIDER_ERROR'): DonsetchWebError {
  return new DonsetchWebError(message, code)
}

/**
 * Project one donsetch `web_search` MCP result into the seam's
 * WebSearchResult. Sources come from the daemon's full machine view
 * (_meta["com.donsetch/search-debug"].results carries title and
 * snippet), with the lightweight structuredContent list as fallback;
 * an instant answer becomes the result's optional content.
 */
function webSearchResultFrom(result: unknown): WebSearchResult {
  const r = (result ?? {}) as Record<string, unknown>
  const sources: WebSearchSource[] = []
  const seen = new Set<string>()
  const take = (row: Record<string, unknown>): void => {
    const url = typeof row.url === 'string' && row.url.length > 0 ? row.url : undefined
    if (url === undefined || seen.has(url)) return
    seen.add(url)
    sources.push({
      url,
      ...(typeof row.title === 'string' && row.title.length > 0 ? { title: row.title } : {}),
      ...(typeof row.snippet === 'string' && row.snippet.length > 0 ? { snippet: row.snippet } : {}),
    })
  }
  const meta = r._meta as Record<string, unknown> | undefined
  const debug = meta?.['com.donsetch/search-debug'] as { results?: unknown } | undefined
  const rawDebug = debug?.results
  const debugRows = Array.isArray(rawDebug) ? (rawDebug as Array<Record<string, unknown>>) : []
  const structured = r.structuredContent as { results?: unknown; instant?: unknown } | undefined
  const rawStructured = structured?.results
  const structuredRows = Array.isArray(rawStructured)
    ? (rawStructured as Array<Record<string, unknown>>)
    : []
  for (const row of debugRows.length > 0 ? debugRows : structuredRows) take(row)
  const instant = structured?.instant as { text?: unknown } | undefined
  const instantText = instant?.text
  const content = typeof instantText === 'string' && instantText.length > 0 ? instantText : undefined
  return content === undefined ? { sources, truncated: false } : { sources, truncated: false, content }
}

export function apply(ctx: Context, rawConfig: DonsetchConfig = {}): { dispose(): Promise<void> } {
  let config: ResolvedConfig
  const inert: { dispose(): Promise<void> } = { dispose: async () => {} }
  try {
    config = resolveConfig(rawConfig)
  } catch (err) {
    ctx.logger?.error(`donsetch plugin rejecting configuration: ${err instanceof Error ? err.message : String(err)}`)
    return inert
  }

  if (typeof ctx.tools?.register !== 'function') {
    ctx.logger?.error('donsetch plugin: this DeepSeek Harness build has no ctx.tools registry (missing @deepseek-ai/dsh-tools)')
    return inert
  }

  const log = (msg: string): void => {
    ctx.logger?.info(`[donsetch] ${msg}`)
  }
  const warn = (msg: string): void => {
    ctx.logger?.warn(`[donsetch] ${msg}`)
  }

  const disposers: Array<() => void> = []
  const registeredNames = new Set<string>()
  const registrationFailures: string[] = []
  let booted: BootedState | null = null
  let bootError: string | null = null
  let status: 'starting' | 'ready' | 'degraded' | 'failed' = 'starting'
  let bootLock: Promise<void> | null = null
  let generation = 0
  let pendingUpdateVersion: string | null = null
  let activeCalls = 0
  let statusRegistrations: Array<() => void> = []
  let disposed = false

  function makeSearchProvider(): WebSearchProvider {
    return {
      id: 'donsetch',
      // Cheap local check; the daemon boots on demand inside search().
      available: () => !disposed,
      search: async (request: WebSearchRequest, signal?: AbortSignal): Promise<WebSearchResult> => {
        const healthy = await ensureDaemon(signal)
        if (!healthy) {
          throw webSearchError(
            `donsetch is unavailable (${bootError ?? 'not running'}); check ${config.toolPrefix}_status for diagnostics`,
          )
        }
        const args: Record<string, unknown> = { query: request.query }
        if (request.maxResults !== undefined) args.max_results = request.maxResults
        let result: McpResult
        try {
          result = await booted!.client.callTool(
            'web_search',
            args,
            signal,
            callTimeoutFor('web_search', args, config.callTimeoutMs),
          )
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err)
          throw webSearchError(message, signal?.aborted === true ? 'WEB_ABORTED' : 'WEB_PROVIDER_ERROR')
        }
        if (result?.isError === true) {
          throw webSearchError(joinBlocks(result) || 'donsetch web_search failed')
        }
        return webSearchResultFrom(result)
      },
    }
  }

  // ── Native web_search routing (donsetch-dsh#4) ──
  // The harness's own `web_search` tool executes through the ctx.web
  // seam. Registering the "donsetch" provider here makes that id
  // resolvable, and the bundle patch points the web row's searchProvider
  // at it, so the native tool runs through the same daemon (and the same
  // BYOK keys) as the donsetch_* tools, with no DeepSeek API key
  // required. Zero runtime imports from the host train: the seam arrives
  // through ctx, exactly like the tools registry.
  const registerWebProvider = (web: WebRuntime | undefined): void => {
    if (web === undefined || typeof web.registerSearchProvider !== 'function') return
    try {
      web.registerSearchProvider(makeSearchProvider())
      log('native web_search routes through the donsetch provider')
    } catch (err) {
      warn(`could not register the web search provider: ${err instanceof Error ? err.message : String(err)}`)
    }
  }
  const seamNow = typeof ctx.get === 'function' ? ctx.get<WebRuntime>('web') : undefined
  if (seamNow !== undefined) {
    registerWebProvider(seamNow)
  } else if (typeof ctx.inject === 'function') {
    // The seam may activate after this plugin; wait for it. A profile
    // with no seam at all simply never fires this; the donsetch_* tools
    // are unaffected either way.
    ctx.inject(['web'], (c) => {
      registerWebProvider(typeof c.get === 'function' ? c.get<WebRuntime>('web') : undefined)
    })
  } else {
    log('no ctx.web seam in this profile; the native web_search tool is not rerouted')
  }

  function runDoctor(binPath: string | null): string {
    const cmd = binPath ?? 'donsetch'
    try {
      const result = spawnSync(cmd, ['doctor'], { encoding: 'utf8', timeout: 30_000 })
      const out = `${result.stdout ?? ''}${result.stderr ?? ''}`.trim()
      return out || '(doctor produced no output)'
    } catch {
      return '(donsetch binary not callable yet)'
    }
  }

  function registerStatusTools(): void {
    for (const dispose of statusRegistrations.splice(0)) {
      try {
        dispose()
      } catch {
        // Disposer already ran; ignore.
      }
    }

    const def: ToolDefinition = {
      name: publicToolName(config.toolPrefix, 'status') ?? `${config.toolPrefix}_status`,
      description:
        'DonSeTch status and self-diagnostics: binary version, daemon state, registered tools, registration failures, provider keys file, config file path, and the output of `donsetch doctor`. Read this when a donsetch_* tool fails or is missing.',
      // register() does not compile parameters: it copies them onto the
      // model request verbatim, so this must already be a JSON Schema
      // document (a bare `{}` is not one either).
      parameters: { type: 'object', properties: {} },
      output: { schema: {}, render: (_args, value) => renderContent(value) },
      execute: async () => {
        const lines: string[] = []
        lines.push(`DonSeTch plugin status: ${status}`)
        if (status === 'failed') {
          lines.push(`state: ${bootError ?? 'unknown failure'}`)
        } else {
          lines.push('state: daemon starting in background; re-check shortly')
        }
        lines.push(`config file: ${donsetchConfigPath()}${existsSync(donsetchConfigPath()) ? '' : ' (not written yet)'}`)
        const keysPath = donsetchKeysPath()
        lines.push(`provider keys: ${keysPath}${existsSync(keysPath) ? '' : ' (missing: `donsetch keys add` has not been run for this home)'}`)
        lines.push(`registered tools (${registeredNames.size}): ${[...registeredNames].sort().join(', ') || '(none)'}`)
        if (registrationFailures.length > 0) {
          lines.push(`registration failures (${registrationFailures.length}):`)
          for (const failure of registrationFailures) lines.push(`  - ${failure}`)
        }
        lines.push(`binary cache: ${cacheDir()}`)
        lines.push(`pinned release: v${config.pinnedVersion}`)
        if (booted) {
          lines.push(`binary: ${booted.bin.path} (source: ${booted.bin.source})`)
          lines.push(`donsetch version: ${booted.client.serverVersion ?? 'unknown'}`)
        }
        lines.push('---')
        lines.push(...runDoctor(booted?.bin.path ?? null).split('\n'))
        return { content: [{ type: 'text', text: lines.join('\n') + '\n' }] }
      },
      presentCall: () => ({ card: 'generic', title: `${config.toolPrefix}_status` }),
      presentResult: (_args, value) => ({
        card: 'generic',
        title: `donsetch ${status}`,
        content: renderContent(value),
      }),
    }
    let dispose: () => void
    try {
      dispose = ctx.tools.register(def)
    } catch (err) {
      warn(`could not register status tool: ${err instanceof Error ? err.message : String(err)}`)
      return
    }
    statusRegistrations.push(dispose)
  }

  function registerTool(rawName: string, description: string | undefined, inputSchema: Record<string, unknown> | undefined): boolean {
    const pub = publicToolName(config.toolPrefix, rawName)
    if (pub === null) {
      const reason = `skipping tool ${JSON.stringify(rawName)}: name does not fit the tool-name contract`
      registrationFailures.push(reason)
      warn(reason)
      return false
    }
    if (registeredNames.has(pub)) {
      const reason = `skipping duplicate tool name ${pub}`
      registrationFailures.push(reason)
      warn(reason)
      return false
    }
    // Sanitize the hostile MCP inputSchema into the author form, then
    // project that into the JSON Schema document register() must receive.
    // Handing register() the bare property map is silently accepted here
    // and rejected by the provider with 11129, killing every request.
    const parameters = specToJsonSchema(toDshSpec(inputSchema))
    const def: ToolDefinition = {
      name: pub,
      description: description || `${rawName} via DonSeTch`,
      parameters,
      output: { schema: {}, render: (_args, value) => renderContent(value) },
      execute: async (args: unknown, exec: ToolRunContext) => {
        const healthy = await ensureDaemon(exec.signal)
        if (!healthy) {
          const hint = bootError ?? 'not running'
          throw new Error(`donsetch is unavailable (${hint}); check ${config.toolPrefix}_status for diagnostics`)
        }
        activeCalls++
        try {
          const result = await booted!.client.callTool(
            rawName,
            args,
            exec?.signal,
            callTimeoutFor(rawName, args, config.callTimeoutMs)
          )
          if (result?.isError === true) {
            const text = joinBlocks(result)
            throw new Error(text || `donsetch ${rawName} failed`)
          }
          return result ?? { content: [{ type: 'text', text: 'No output' }] }
        } finally {
          activeCalls--
          refreshWatchBaseline()
          void maybeSwapUpdate()
        }
      },
      presentCall: (args: unknown) => ({ card: 'generic', kind: callKind(pub), title: callTitle(pub, args), rawInput: args }),
      presentResult: (_args: unknown, value: unknown) => ({
        card: 'generic',
        title: resultTitle(pub, value),
        content: renderContent(value).slice(0, 4),
      }),
    }
    let dispose: () => void
    try {
      dispose = ctx.tools.register(def)
    } catch (err) {
      const reason = `tool ${pub} rejected by the registry: ${err instanceof Error ? err.message : String(err)}`
      registrationFailures.push(reason)
      warn(reason)
      return false
    }
    disposers.push(dispose)
    registeredNames.add(pub)
    return true
  }

  function joinBlocks(result: Partial<McpResult>): string {
    return ((result.content ?? []) as Array<{ text?: unknown }>)
      .map((b) => (typeof b?.text === 'string' ? b.text : ''))
      .join('')
      .trim()
  }

  function resultTitle(pub: string, value: unknown): string {
    const text = (value as Partial<McpResult>)?.content ? joinBlocks(value as Partial<McpResult>) : ''
    const line = text ? firstLine(text, 80) : ''
    return line ? `${pub} \u00B7 ${line}` : pub
  }

  async function boot(): Promise<void> {
    const myGen = ++generation
    status = 'starting'
    const bin = await resolveBinary(config.pinnedVersion, config.fallbackToPath)
    const fresh = new McpClient({
      cmd: [bin.path, 'mcp'],
      callTimeoutMs: config.callTimeoutMs,
      bootTimeoutMs: config.bootTimeoutMs,
    })
    try {
      await fresh.start()
    } catch (err) {
      // Never leak children from a failed boot path.
      await fresh.dispose(500).catch(() => undefined)
      throw err
    }
    if (disposed) {
      // Unload overtook an in-flight boot; kill the fresh child.
      await fresh.dispose(500).catch(() => undefined)
      return
    }
    if (myGen !== generation) {
      // A config restart overtook this boot; discard it.
      await fresh.dispose(500).catch(() => undefined)
      return
    }
    booted = { bin, client: fresh }
    status = bin.source === 'path' ? 'degraded' : 'ready'
    bootError = null
    registerStatusTools()
    // The daemon may rewrite byok-keys.json during startup (key
    // rotation/retirement bookkeeping): consume that write.
    refreshWatchBaseline()
    for (const tool of fresh.tools) {
      registerTool(tool.name, tool.description, tool.inputSchema)
    }
    log(
      `ready: donsetch v${fresh.serverVersion ?? '?'} via ${bin.source} (${bin.path}), ${registeredNames.size} tools as ${config.toolPrefix}_*`,
    )
  }

  async function ensureDaemon(signal?: AbortSignal): Promise<boolean> {
    if (disposed) return false
    if (booted !== null && booted.client.healthy) return true
    if (bootLock === null) {
      bootLock = (async () => {
        try {
          await boot()
        } catch (err) {
          bootError = err instanceof Error ? err.message : String(err)
          status = 'failed'
          registerStatusTools()
        } finally {
          bootLock = null
        }
      })()
    }
    await bootLock
    if (signal?.aborted) return false
    return booted !== null && booted.client.healthy
  }

  function restartDaemon(): void {
    const old = booted
    booted = null
    status = 'starting'
    if (old !== null) {
      old.client.kill()
    }
  }

  /**
   * Install a downloaded update: restart the daemon only when no tool
   * call is in flight; otherwise defer until the counter drains.
   */
  async function maybeSwapUpdate(): Promise<void> {
    if (disposed) return
    if (pendingUpdateVersion === null) return
    if (activeCalls > 0) return
    const version = pendingUpdateVersion
    pendingUpdateVersion = null
    if (booted?.bin.version === version) return
    // Ensure the release is materialized and verified in the cache.
    if (await downloadBinaryIfMissing(version)) {
      restartDaemon()
      void ensureDaemon()
      log(`swapped to donsetch v${version}`)
    }
  }

  async function downloadBinaryIfMissing(version: string): Promise<boolean> {
    if (installedVersions().some((v) => versionString(v) === version)) {
      return true
    }
    try {
      await downloadBinary(version, { timeoutMs: 300_000 })
      return true
    } catch (err) {
      warn(`update download for v${version} failed: ${err instanceof Error ? err.message : String(err)}`)
      return false
    }
  }

  function versionString(v: { major: number; minor: number; patch: number; prerelease: string[] }): string {
    const pre = v.prerelease.length > 0 ? `-${v.prerelease.join('.')}` : ''
    return `${v.major}.${v.minor}.${v.patch}${pre}`
  }

  // ── Side effects, owned by the plugin fiber ──

  const teardown = async (): Promise<void> => {
    if (disposed) return
    disposed = true
    generation++
    for (const dispose of disposers.splice(0)) {
      try {
        dispose()
      } catch {
        // Already run.
      }
    }
    for (const dispose of statusRegistrations.splice(0)) {
      try {
        dispose()
      } catch {
        // Already run.
      }
    }
    const client = booted?.client
    booted = null
    if (client) await client.dispose(1500)
    if (restartTimer !== null) {
      clearTimeout(restartTimer)
      restartTimer = null
      armedMtime = null
    }
  }

  ctx.effect(() => {
    registerStatusTools()
    void boot().catch((err: unknown) => {
      bootError = err instanceof Error ? err.message : String(err)
      status = 'failed'
      registerStatusTools()
    })
    return () => {
      void teardown()
    }
  }, 'donsetch-lifecycle')

  // CLI config + provider keys from the terminal reach the live
  // daemon via watching the files the real donsetch CLI writes. The
  // daemon itself rewrites byok-keys.json around boot and calls (key
  // rotation/retirement bookkeeping), so restart discipline is:
  //   - watchFile fires per CHANGE, not per poll: each change arms a
  //     debounced restart;
  //   - busy windows swallow the event (the daemon's own writes
  //     always happen while calls run or during boot);
  //   - refreshWatchBaseline() runs after boot and after every call:
  //     it re-baselines mtimes AND cancels any armed timer, so the
  //     daemon's own writes can never restart-loop it;
  //   - a change landing during the debounce window invalidates the
  //     timer instead of restarting on potentially younger bytes.
  interface WatchEntry {
    path: string
    lastMtime: number | null
  }
  const watchEntries: WatchEntry[] = [
    { path: donsetchConfigPath(), lastMtime: null },
    { path: donsetchKeysPath(), lastMtime: null },
  ]
  let restartTimer: ReturnType<typeof setTimeout> | null = null
  let armedMtime: number | null = null
  const recordMtime = (path: string): number | null => {
    try {
      return statSync(path).mtimeMs
    } catch {
      return null
    }
  }
  const refreshWatchBaseline = (): void => {
    for (const entry of watchEntries) {
      entry.lastMtime = recordMtime(entry.path)
    }
    if (restartTimer !== null) {
      clearTimeout(restartTimer)
      restartTimer = null
      armedMtime = null
    }
  }
  for (const entry of watchEntries) {
    entry.lastMtime = recordMtime(entry.path)
  }
  for (const entry of watchEntries) {
    try {
      watchFile(entry.path, { persistent: false, interval: 1200 }, () => {
        const mtime = recordMtime(entry.path)
        if (mtime === null) {
          // Missing at this event (including the attach probe):
          // nothing real to restart for.
          entry.lastMtime = null
          return
        }
        entry.lastMtime = mtime
        if (activeCalls > 0 || disposed) return
        if (restartTimer !== null) return
        armedMtime = mtime
        restartTimer = setTimeout(() => {
          restartTimer = null
          const latest = recordMtime(entry.path)
          if (latest !== armedMtime) {
            // Written again during the debounce: drop this event; the
            // next change fires a fresh callback.
            armedMtime = null
            return
          }
          armedMtime = null
          if (disposed) return
          log(`donsetch state changed on disk (${entry.path}); restarting daemon`)
          restartDaemon()
          void ensureDaemon()
        }, 800)
      })
    } catch {
      warn(`could not watch ${entry.path}; CLI config changes will apply after the next dsh restart`)
    }
  }
  ctx.effect(() => {
    return () => {
      for (const entry of watchEntries) {
        try {
          unwatchFile(entry.path)
        } catch {
          // Never watched.
        }
      }
      if (restartTimer !== null) {
        clearTimeout(restartTimer)
        restartTimer = null
      }
    }
  }, 'donsetch-config-watch')

  // Throttled, non-blocking update check once the daemon is up.
  if (config.autoUpdate) {
    ctx.effect(() => {
      let cancelled = false
      void (async () => {
        try {
          await ensureDaemon()
          if (cancelled || booted === null) return
          const current = booted.bin.source === 'release' ? booted.bin.version : config.pinnedVersion
          const info = await checkForUpdate(current, config.channel, config.updateIntervalHours)
          if (cancelled) return
          if (info?.newer === true) {
            pendingUpdateVersion = info.latest
            log(`newer donsetch v${info.latest} found (running v${current}); will swap between calls`)
            void maybeSwapUpdate()
          }
        } catch {
          // Updates are best-effort; tool service is unaffected.
        }
      })()
      return () => {
        cancelled = true
      }
    }, 'donsetch-update-check')
  }

  log(`plugin v${PLUGIN_VERSION} loaded; donsetch v${config.pinnedVersion}+ via the ${config.toolPrefix}_* tools`)

  // Manual teardown seam for embedders and tests; the harness normally
  // owns disposal through the lifecycle effect above.
  return { dispose: () => teardown() }
}