/**
 * 交付物投递 — present 声明的文件在轮末发送到当前推推会话
 *
 * 宿主契约：`deliverables/presented` 事件先于 turn/end 到达；文件按引用交付
 * （不复制内容），读取发生在投递时刻；外层轮次失败不撤销已完成的声明。
 * 每个文件独立投递，失败降级为文字提示，不阻断其余文件。
 *
 * 发送器侧推推合并了文本/媒体通道（im.sendFile 按内容判定图片还是附件），
 * 构造参数因此保留 (sender, mediaBot) 双形态，实际由 bootstrap 传同一个
 * TuituiSender——保留形态是为了让 send-file 工具与交付物共用同一套扩展名
 * 分类与路径白名单（media/send-media.ts 是单一事实源）。
 */
import { basename, isAbsolute, resolve } from 'node:path';
import type { ImTuituiConfig } from '../config.ts';
import type { SessionRecord } from '../session/index.ts';
import type { Logger, TuituiSender } from '../types.ts';
import { resolveAgentCwd } from '../shared/dirs.ts';
import { isPathAllowed, sendMediaFile } from '../media/send-media.ts';
import type { PresentedFileRef } from './events.ts';
import { chunkMarkdownText } from './chunker.ts';

/** 交付物投递器（outbound 路由只依赖此接口，便于测试注入） */
export interface DeliverablesDelivererLike {
  deliver(record: SessionRecord, files: PresentedFileRef[]): Promise<void>;
}

export class DeliverablesDeliverer implements DeliverablesDelivererLike {
  private readonly sender: TuituiSender;
  private readonly mediaBot: TuituiSender;
  private readonly config: ImTuituiConfig;
  private readonly logger: Logger;

  public constructor(
    sender: TuituiSender,
    mediaBot: TuituiSender,
    config: ImTuituiConfig,
    logger: Logger,
  ) {
    this.sender = sender;
    this.mediaBot = mediaBot;
    this.config = config;
    this.logger = logger;
  }

  /** 轮末投递一批声明文件：逐个发送，未送达的聚合为一条文字提示 */
  public async deliver(record: SessionRecord, files: PresentedFileRef[]): Promise<void> {
    const limit = Math.max(1, this.config.sendFile?.maxFiles ?? 4);
    const cwd = resolveAgentCwd(this.config.cwd);
    const missed: string[] = [];
    let sent = 0;

    for (const [index, file] of files.entries()) {
      // 新声明记录绝对路径；历史相对路径按 agent 工作目录（workspace）兜底解析
      const absPath = isAbsolute(file.path) ? file.path : resolve(cwd, file.path);
      const display = basename(absPath);
      if (index >= limit) {
        missed.push(`${display}（超出单轮投递上限，未发送）`);
        continue;
      }
      if (!isPathAllowed(absPath, this.config.sendFile, cwd)) {
        missed.push(`${display}（路径不在允许范围）`);
        continue;
      }
      const result = await sendMediaFile(this.mediaBot, record.replyTarget, absPath);
      if (result.outcome === 'sent') {
        sent++;
        this.logger.info(
          `im-tuitui: 交付物已发送 ${display} (${result.size} bytes) → `
          + `${record.replyTarget.scope}:${record.replyTarget.targetId}`,
        );
      } else if (result.outcome === 'failed') {
        this.logger.warn(`im-tuitui: 交付物发送失败 ${display}: ${result.error}`);
        missed.push(display);
      } else {
        missed.push(display);
      }
    }

    if (missed.length > 0) {
      const text = ['📎 已生成文件（未能直接发送）：', ...missed.map((name) => `- ${name}`)].join('\n');
      for (const chunk of chunkMarkdownText(text, this.config.textChunkLimit)) {
        try {
          await this.sender.sendMarkdown(record.replyTarget, chunk);
        } catch (err) {
          this.logger.error(
            `im-tuitui: deliverables notice failed: ${err instanceof Error ? err.message : String(err)}`,
          );
        }
      }
    }
    this.logger.debug(`im-tuitui: deliverables delivered sent=${sent} missed=${missed.length}`);
  }
}
