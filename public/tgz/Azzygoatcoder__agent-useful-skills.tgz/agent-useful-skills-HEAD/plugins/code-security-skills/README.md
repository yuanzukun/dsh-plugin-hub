# Code Security Skills

[![verify](https://github.com/Azzygoatcoder/agent-useful-skills/actions/workflows/verify.yml/badge.svg?branch=master)](https://github.com/Azzygoatcoder/agent-useful-skills/actions/workflows/verify.yml)

> Claude Code 插件 — 系统化代码安全审计技能集，覆盖漏洞发现、验证、报告、修复、重审计全流程。**v1.5.1**

![安全审计 skill 工作流](assets/audit-workflow.svg)

<sub>图源 `assets/audit-workflow.html`（单文件内联 SVG），`audit-workflow.svg` / `.png` 由它导出。注解状态模型另见 `assets/verdict-model.svg`。</sub>

## 技能概览

```mermaid
graph TD
    CSA[code-security-audit<br/>4 阶段安全审计]
    A[audit<br/>/audit 快捷命令]
    R[reaudit<br/>/reaudit + mark-fixed/status]
    SF[security-fix-skill<br/>按优先级批量修复]

    A -->|委托 Phase 1-3| CSA
    R -->|委托 Phase 4 / 状态追踪| CSA
    SF -->|调用 mark-fixed| R
    R --> CSA
```

| 技能 | 触发方式 | 功能 |
|------|----------|------|
| `code-security-audit` | "audit this repo", "安全审计" | 系统安全审计：并行探索 → 验证 → 报告 → 增量重审计 |
| `audit` | `/audit` | 快捷入口，委托到 code-security-audit Phase 1-3 |
| `reaudit` | `/reaudit`, "再审计" | **v1.1 新增**：全量/增量重审计、`mark-fixed`、`mark-deferred`、`status` |
| `security-fix-skill` | "/security-fix", "修安全漏洞" | 按 P1-P4 优先级批量修复，每批自动更新 finding 状态 |

## v1.1.0 新特性

### 状态追踪

每个 finding 现在包含机读状态注解：

```markdown
### SSRF-1 — tool_fetch_url 无 URL 校验
<!-- AUDIT:STATUS=fixed SEVERITY=high FILE=your-project/src/module.py LINES=100-120 COMMIT=abc1234 -->
```

**轻量操作**（不改代码，只改注解行）：

| 命令 | 作用 |
|------|------|
| `/reaudit mark-fixed SSRF-1` | 标记为已修复 |
| `/reaudit mark-deferred M4` | 标记为结构性延期 |
| `/reaudit status` | 显示修复进度（3 fixed / 2 open / 1 deferred） |

### 稳定 Finding ID

使用分类前缀替代顺序编号。新增 finding 不会改变已有 ID：

| 前缀 | 类别 | 示例 |
|------|------|------|
| `SSRF` | SSRF / URL 注入 | `SSRF-1`, `SSRF-2` |
| `PATH` | 路径穿越 | `PATH-1` |
| `AUTH` | 鉴权缺失 | `AUTH-1` |
| `CMD` | 命令注入 | `CMD-1` |

### 增量 Re-audit

Phase 4 不再全量重读所有文件。通过 `git diff <audit-commit>..HEAD` 只验证变更文件中的 finding，未变更文件的 finding 自动跳过。

### Phase 2 去重

3 个 Agent 经常重复报同一问题——Phase 2 现在自动合并同文件/同行范围的重复发现。

## v1.4.0 新特性（2026-08-12）

### 场景判定表

对齐科研骨架新 skill 范式，顶部四路分流：快速扫描（L1）／全面审计（默认）／增量重审／单 PR 委托 `dev-workflow`。深度宁高勿低。

### 跨模型对抗验证

Phase 2 加 review.py（ARIS 对抗范式，不同模型）攻击 findings——自动化解决 30-40% 误报全靠人工判断的瓶颈。被对抗模型批倒且无反驳依据的 finding 必须重新验证。

### 脚本化状态追踪：`bin/security_audit_tools.py`

不再手动 grep/Edit 注解，状态管理脚本化（对齐 arxiv_fetch/latex_build 模式）：

> **前置**：脚本在 monorepo 根 `bin/`，不在本插件目录内。先 `pip install -e .`（控制台命令），或从仓库根用 `python bin/security_audit_tools.py <子命令>`。

```bash
security-audit-tools list [--status open] [--severity high]
security-audit-tools status
security-audit-tools diff-filter --commit <上次审计hash>   # 变更文件→涉及 findings
security-audit-tools mark-fixed SSRF-1 PATH-1              # 改注解行+记当前 HEAD
security-audit-tools mark-deferred AUTH-1
```

mark-* 直接改写 `<!-- AUDIT:STATUS=... -->` 注解行，彻底解决 Edit 工具 Unicode/空白匹配摩擦；diff-filter 让增量 re-audit 真正可跑。

## 安装

**要求：** Claude Code >= 1.0.37（支持插件系统）

### 方式一：从 GitHub 安装（推荐）

```bash
claude plugins install https://github.com/Azzygoatcoder/agent-useful-skills --path plugins/code-security-skills
```

Claude Code 会自动克隆仓库并注册 `plugins/code-security-skills/skills/` 目录下的全部技能。安装后重启 Claude Code 会话即可生效。

### 方式二：手动安装

将 `skills/` 下各技能目录复制或符号链接到用户级技能目录：

#### macOS / Linux

```bash
ln -s "$(pwd)/skills/code-security-audit" ~/.claude/skills/code-security-audit
ln -s "$(pwd)/skills/audit" ~/.claude/skills/audit
ln -s "$(pwd)/skills/reaudit" ~/.claude/skills/reaudit
ln -s "$(pwd)/skills/security-fix-skill" ~/.claude/skills/security-fix-skill
```

#### Windows (PowerShell)

```powershell
New-Item -ItemType Junction -Path "$env:USERPROFILE\.claude\skills\code-security-audit" -Target "$pwd\skills\code-security-audit"
# 对 audit、reaudit、security-fix-skill 重复
```

### 验证安装

安装后，在 Claude Code 中输入以下命令确认技能已加载：

```bash
/audit    # 应触发安全审计流程
/reaudit  # 应触发重审计流程
```

或直接说 "audit this repo" 测试自然语言触发。

## 审计工作流

![审计注解状态模型](assets/verdict-model.svg)

<sub>图源 `assets/verdict-model.html`；完整流程图见顶部 `audit-workflow.svg`。两图均为 HTML 唯一图源、SVG/PNG 由 `bin/export_diagram.py` 派生。</sub>

**两条正交轴**（规范见 `references/vulnerability-patterns.md` §18）：

- **认识态 `VERDICT`** —— `confirmed`（缺省）/ `needs-validation` / `rejected`。
  **只有 `confirmed` 允许带 `SEVERITY`**；`needs-validation` 必须写 `BLOCKER=` 且**禁止定级**；`rejected` 必须写 `REASON=` 并**留档**，以免下一轮重打同一枪。
  注解缺省即 `confirmed` ⇒ **旧报告零改动兼容**。
- **修复态 `STATUS`** —— `open` → `fixed` / `not-fixed` / `partial` / `deferred`。**只有 `confirmed` 进得了修复队列**；`needs-validation` 等仓库外事实澄清。

契约由 `bin/security_audit_tools.py validate` 执行（8 条检查，已接入 CI）：
**标题↔注解对账**（先跑，防止"解析不了的注解整条跳过检查却仍打印 PASS"）→ ID 前缀 → `VERDICT`↔`SEVERITY` 互斥 → `BLOCKER`/`REASON` 必填 → `FILE` 存在且是安全仓库根相对路径（含 `realpath` 包含性） → `LINES` 不越界 → `fixed` 的 `COMMIT` 须为 HEAD 祖先 → `## Coverage` 段非空。

Phase 1 是 3 个并行 Explore agent（L2/L3 另加 Agent D：业务逻辑 / 功能滥用 / 链式信任边界 / Wildcard），Phase 2 先过「不算 Finding 判别表」再回读去重、跑 5 点 Self-Check，**Critical/High 另由没参与该条发现的 agent 回读源码复核** —— 发现者不得复核自己。

> **不声明完整覆盖。** 报告必须含非空 `## Coverage` 段，交代审了哪些面、哪些面**未审计及原因**。单次运行 ≠ 完整覆盖。

## 漏洞覆盖

17 类漏洞模式，每类提供 grep 搜索模式、典型漏洞代码形态、修复代码模板、CVSS 评分参考：

| 类别 | 类别 | 类别 |
|------|------|------|
| 路径遍历 | XSS | SQL 注入 |
| 命令注入 | SSRF | 不安全反序列化 |
| CSRF/CORS | 文件权限 | 明文凭据 |
| 子进程注入 | 认证与会话 | 加密弱点 |
| 依赖管理 | 临时文件处理 | 环境变量泄露 |
| 日志伪造 | 竞态条件 (TOCTOU) | — |

## 优势

### 并行化设计，减少审计盲区

传统单 agent 审计受限于单一的搜索策略和思维模型。本技能集采用 3 个独立 agent 并行扫描——密钥凭据、输入验证与注入、认证加密依赖——每个 agent 使用不同的 grep 模式和心理模型，覆盖彼此盲区。

### 4 阶段递进，每步有明确产出

不是"让 AI 扫一遍就出报告"。探索 → 验证 → 报告 → 重审计，阶段间有明确的质量门：

- **Phase 1**：覆盖广度（3 agent 并行）
- **Phase 2**：覆盖深度（人工核实每条发现）
- **Phase 3**：结构化交付（含修复代码的完整报告）
- **Phase 4**：闭环验证（确认修复到位、无回归）

### 可演进的漏洞知识库

`vulnerability-patterns.md` 不是静态的检查清单——每次审计后补充新发现的漏洞模式，grep 模式持续丰富，修复模板持续完善。**技能随着使用变强。**

### 正交分工，组合灵活

- 快速审计：`/audit`
- 全面审计 + 修复：`code-security-audit` → `security-fix-skill`
- 验证修复：`/reaudit`
- 持续集成：将 audit 作为发布前检查步骤

### 实战验证

`security-fix-skill` 的工作流在真实 Python Web 应用项目中打磨，历经 16 个真实漏洞发现和修复（P1-P4），覆盖路径遍历、命令注入、XSS、CSRF、SSRF、明文凭据等。

## 待改进

### 语言覆盖

`vulnerability-patterns.md` 的 grep 模式和代码示例目前偏重 Python 和 JavaScript。Go、Rust、Java、C# 的特定模式尚待补充。

### SAST 工具集成

当前纯靠 LLM agent 的语义理解和 grep 搜索。未来可集成 semgrep、CodeQL 等 SAST 工具作为 Phase 1 的补充信号源，提高低层漏洞（硬编码密钥、不安全函数调用）的检出率。

### 输出格式

审计报告目前仅输出 Markdown（注解即契约，由 `bin/security_audit_tools.py validate` 校验）。**刻意不引入 `findings.json` + JSON Schema** —— 那会让结论变成"第二份真相"，两份不一致时的排查成本高于收益。若将来要接 GitHub Code Scanning，再考虑从注解派生 SARIF。

### 自动化测试与 Eval 基准

技能的 SKILL.md 内容变更后，缺乏自动化验证手段——无法确认改动的 prompt 是否仍然产生一致的审计质量。**注解契约已有回归保护**（`tests/test_bin_contracts.py` 的 validate 用例），但 prompt 质量本身仍无 eval 基准。未来可建立含已知漏洞的样例仓库，量化变更对审计召回率和精确率的影响。

### 依赖校验

技能间通过 `name` 字段字符串引用（如 "load and follow `code-security-audit`"），`bin/check_skills.py` 能抓悬空引用（曾抓出 `review-skill` 已归档却仍被 3 处引用），但没有编译时保证。

## 版本历史

| 版本 | 日期 | 变更 |
| ---- | ---- | ---- |
| **1.5.1** | 2026-09-21 | **重验轮**。按「发现者不得复核自己」请独立 agent 复核 1.5.0 的新代码，它用可执行证据报出 5 条并全部修复：**META-2**（一条解析不了的注解会让该 finding **整条跳过全部逐条检查**，而 `validate` 仍打印 `PASS` —— 门禁退化成摆设，故定 P1）、**PATH-3**（路径围栏只报错不拦读，越界读出仓库外文件的行数）、**CMD-1**（`--commit=--output=…` 被当成 git 选项：写文件 + diff-filter 静默返回「0 个变更」）、**RES-1**（`LINES` 无位数上界，py3.11+ 抛异常把门禁搞崩、py3.9 二次方）、**META-3**（prose 声称 `validate` 会抓出「标记了 fixed 但改的是另一个文件」，实际只查 COMMIT 是不是 HEAD 祖先）。并**补完两处我自己重验时误判为「已修」的半修**：PATH-2（agent 的读取路径上没有任何包含性指令）、DEP-1（`security-fix-skill` 速查表仍写 `atexit` 清理 "even on crash paths" —— 该 finding 点名的是两个文件）。另：`check_skills.py` 悬空引用检测去盲区（改为只认反引号，即可覆盖 v1.4.3 声称修过、实际只改了 SVG 没改正文的 `code-review`）；修复 `export_diagram.py` 的 PNG 导出在 Windows 上**恒失败**（`shutil.which` 返回 `…rsvg-convert.EXE`，`endswith("rsvg-convert")` 为假 → 走成 magick 的 argv 形式）；工作流图按新流程重制、新增注解状态模型图 `verdict-model.svg`；README 里那段声称「Phase 4 只验证变更文件」的 stale Mermaid 换成实图。**本轮教训已入档**：只核对注解里那一个 `FILE`/`LINES` 会漏掉「同一句话在别处还有一份」，多文件 finding 必须逐个文件核 |
| **1.5.0** | 2026-09-20 | 对标 `cloudflare/security-audit-skill` 的**轻量升级：只取认识论，不取工程学**（未采纳其 132 KB 的 `findings.json`+Schema+双校验器、覆盖率账本 JSON、11 步 artifact promotion、OS 沙箱前置）。①注解加 `VERDICT`（`confirmed` 缺省 / `needs-validation` / `rejected`）—— 认识态与修复态拆成两条正交轴，**不确定就不许定级**，`rejected` 留档以免下轮重打；缺省值保证旧报告零改动兼容。②`security_audit_tools.py validate` 七类契约检查接 CI；给"历史被重写"留唯一显式豁免 `**Provenance:** baseline-rewritten`。③`vulnerability-patterns.md` 加「不算 Finding 判别表」17 行 + 4 条全局规则，直击 30–40% 误报。④报告模板加必填 `## Coverage`、`## Needs Validation` 与「未重验」表。⑤Phase 2 独立性：发现者不得复核自己，Critical/High 换新 agent 回读源码。⑥Phase 4 修两个洞（修复落在别的文件时 `fixed` 认不出、静默沿用旧结论）。⑦新增 `attack-surfaces.md`（AI/供应链/桌面-IPC/资源耗尽/数据隔离，懒加载）与 Agent D（业务逻辑/功能滥用/链式信任边界/Wildcard）。**validate 上线当天在自身仓库抓出 3 个真 bug**：`SECRET-3` 因 `LINES=475,510` 被旧正则静默丢弃、报告 `FILE` 为子目录基准会让 diff-filter 静默漏判、`PATH-2` 行号随 SKILL.md 瘦身失效 |
| **1.4.3** | 2026-09-12 | 工作流图用 diagram-design 重制（`audit-workflow.{html,svg,png}`），替换 v14 三件套：①修图里的**幽灵引用**——分流框原写"单 PR → code-review"，而 `code-review` 是全仓库不存在的技能，改为 `dev-workflow`；②补齐导出规范——旧 `.svg` 缺 `xmlns`，作为 `<img>` 嵌入时不会渲染，且 HTML/SVG 两件是孤儿；现在 HTML 为唯一图源、SVG/PNG 由它导出，README 只引用 SVG |
| **1.4.2** | 2026-09-12 | 修复：`security-audit-tools` 控制台命令此前从未可用——文件名为连字符，无法作为 `security_audit_tools` 模块导入，导致 `pip install -e .` 整个失败。文件改名为 `bin/security_audit_tools.py`；README 补 monorepo-root 前置说明 |
| **1.4.1** | 2026-08-30 | SKILL.md 详细阶段拆到 references/audit-workflow.md，主文件瘦身；description 去掉流程摘要 |
| **1.4.0** | 2026-08-12 | 场景判定表四路分流；review.py 跨模型对抗验证进 Phase 2；security-audit-tools.py 脚本化状态追踪（mark-*/status/diff-filter） |
| **1.3.0** | 2026-06-21 | FABLE-5 风格指令重写：Pre-Flight Gate、Confidence 标注、Self-Check Gate、严重性动作绑定、Meta-Cognition Trap |
| **1.2.0** | 2026-06-19 | Step 0 自动 diff 变更文件、单 Agent 并行失败兜底、Agent C 依赖冲突/CVE 检查 |
| **1.1.1** | 2026-06-18 | 自审计修复：XSS 单引号转义、git add -u、示例占位符化、plugin.json 元数据、路径校验、atexit 文档 |
| **1.1.0** | 2026-06-18 | 状态追踪注解、分类前缀 ID、增量 re-audit、Phase 2 去重、mark-fixed/status 轻量操作 |
| **1.0.0** | 2026-06-14 | 初始版本：4 阶段审计、17 类漏洞模式、批量修复工作流 |

## 许可证

[MIT](../../LICENSE)
