/**
 * Wire protocol shared by the host routes and the browser transport.
 *
 * The browser talks to the host through plain same-origin fetch against
 * {@link CUSTOM_PLUGIN_API_PREFIX}; every handler answers with the `{ ok }`
 * envelope below so the client can surface host errors without coupling to
 * route details. Types here are the JSON currency only — no Cordis or React
 * objects cross this boundary.
 * @module @alexpeng/dsh-custom-plugin/protocol
 */

/** Prefix of every host route this plugin registers. */
export const CUSTOM_PLUGIN_API_PREFIX = '/api/custom-plugin'

/** Path the host serves the fetched Mermaid engine at (script src). */
export const MERMAID_SCRIPT_PATH = '/custom-plugin/mermaid.js'

/** Plugin appearance and behavior configuration, persisted in the host state file. */
export interface CustomPluginConfig {
  /** Background preset: 'default' (no color) or one of the 20 palette names.
   * The removed 'aurora' value migrates to 'default' on load. */
  bg?: string
  /** Weather overlay: 'none' | 'snow' | 'rain' | 'sakura'. */
  weather?: string
  /** Master glass toggle for the plugin's own surfaces. */
  glass?: boolean
  /** 'frost' frosted glass or 'liquid' displacement glass. */
  glassMode?: 'frost' | 'liquid'
  /** Apply backdrop blur to global dialogs/menus/tooltips as well. */
  globalGlass?: boolean
  /** Enable the selection-quote-reply feature. */
  quote?: boolean
  /** Force `scroll-behavior: auto` to stop automatic jump-to-bottom. */
  antiScroll?: boolean
  /** Show LaTeX / MathML copy chips under matching messages. */
  formula?: boolean
  /** Show Mermaid render chips under matching messages. */
  mermaid?: boolean
  /** Monthly estimated-cost budget in CNY; zero disables it. */
  monthlyBudgetCny?: number
  /** Percentage at which the monthly budget enters warning state. */
  budgetWarningPercent?: number
}

/** Default configuration (also the composition-layer default). */
export const DEFAULT_CONFIG: CustomPluginConfig = {
  bg: '天青灰',
  weather: 'none',
  glass: true,
  glassMode: 'frost',
  globalGlass: true,
  quote: true,
  antiScroll: false,
  mermaid: true,
  formula: true,
  monthlyBudgetCny: 0,
  budgetWarningPercent: 80,
}

/** One folder node in the multi-level project tree. */
export interface FolderNode {
  id: string
  name: string
  children: FolderNode[]
  sessionIds: string[]
  workspaceIds: string[]
  prompts: string[]
}

/** One saved prompt. */
export interface PromptItem {
  id: string
  name: string
  text: string
  tags?: string[]
  favorite?: boolean
  useCount?: number
  lastUsedAt?: number
}

/** Portable, secret-free backup document. */
export interface CustomPluginBackupV1 {
  format: 'dsh-custom-plugin-backup'
  version: 1
  exportedAt: string
  data: Pick<CustomPluginState, 'cfg' | 'folders' | 'prompts' | 'stars' | 'usage'>
}

export type BackupImportMode = 'merge' | 'replace'

export interface BackupConflictStats {
  folders: number
  prompts: number
  usageDays: number
}

export interface BackupImportPreview {
  folders: number
  prompts: number
  starredSessions: number
  usageDays: number
  conflicts: BackupConflictStats
}

/** Starred timeline nodes, keyed by session id then by user-message seq. */
export type StarsMap = Record<string, Record<string, boolean>>

/** Per-model token counters for one day. */
export interface UsageRow {
  in: number
  out: number
  cacheIn: number
  cacheW: number
  reason: number
  calls: number
  /** Peak-hour (Beijing Monday-Friday 09-12 / 14-18) portion of each counter;
   * the rest, including weekends, is off-peak. Optional because rows persisted
   * before the peak/off-peak split predate these fields. */
  peakIn?: number
  peakCacheIn?: number
  peakCacheW?: number
  peakOut?: number
  /** True when the complete row was rebuilt or recorded with an exact
   * peak/off-peak split. Omitted/false marks legacy rows whose historical
   * portion cannot be assigned to either tariff from persisted counters. */
  peakSplitKnown?: boolean
}

/** Day -> model -> counters. */
export type UsageMap = Record<string, Record<string, UsageRow>>

/** Where the balance API key was resolved from, without exposing its value. */
export type CredentialStorage = 'system' | 'legacy-state' | 'environment' | 'dsh' | 'none'

/** The complete persisted state file shape. */
export interface CustomPluginState {
  cfg: CustomPluginConfig
  folders: FolderNode[]
  prompts: PromptItem[]
  stars: StarsMap
  /** DeepSeek API key for the balance panel; kept out of settings config. */
  apiKey: string
  usage: UsageMap
}

/** Browser-safe state projection; the API key itself never crosses this boundary. */
export type CustomPluginPublicState = Omit<CustomPluginState, 'apiKey'> & {
  apiKeyConfigured: boolean
  credentialStorage: CredentialStorage
}

/** One timeline node: one direct user message in a session. */
export interface TimelineItem {
  seq: number
  time: number
  turn: number
  text: string
  imageCount: number
  hasLatex: boolean
  hasMathml: boolean
  hasMermaid: boolean
}

export type ConversationSearchKind = 'user' | 'assistant' | 'tool'

export interface ConversationSearchRequest {
  sessionId: string
  query: string
  kinds?: ConversationSearchKind[]
}

export interface ConversationSearchItem {
  /** Session used for the indexed hit; protects against stale cross-session clicks. */
  sessionId: string
  seq: number
  anchorSeq: number
  kind: ConversationSearchKind
  time: number
  snippet: string
}

export interface ConversationSearchResult {
  items: ConversationSearchItem[]
  hasMore: boolean
  /** 'index' when dsh's event index answered, 'scan' when the session log was searched directly. */
  source: 'index' | 'scan'
}

/** Balance payload returned by the DeepSeek balance endpoint. */
export interface BalanceInfo {
  currency: string
  total: string
  granted: string
  toppedUp: string
}
