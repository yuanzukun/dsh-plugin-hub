/**
 * HTTP routes for dsh-custom-plugin.
 *
 * Every route sits behind the loopback trust fence (shared `loopback.ts`,
 * semantics aligned with the platform's own request fence); the browser talks
 * to these handlers with plain fetch. The mermaid engine script is served at
 * its own non-API path because the browser loads it as a `<script src>`.
 * @module @alexpeng/dsh-custom-plugin/routes
 */

import type { IncomingMessage, ServerResponse } from 'node:http'
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver'
import type { CustomPluginHost } from './host-service.ts'
import { isLoopbackRequest } from './loopback.ts'
import { CUSTOM_PLUGIN_API_PREFIX, MERMAID_SCRIPT_PATH } from './protocol.ts'
import { BACKUP_BODY_LIMIT } from './backup.ts'

export const STATE_BODY_LIMIT = 1024 * 1024
const TIMELINE_LIMIT = 64 * 1024
// The request envelope contains JSON keys around the document. Keep a small
// reserve so a document at the documented 5 MiB limit is not rejected solely
// because of that envelope; the document itself is checked below as well.
const BACKUP_REQUEST_LIMIT = BACKUP_BODY_LIMIT + 64 * 1024

function json(res: ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
  res.end(JSON.stringify(body))
}

/**
 * The request fence. Trust is decided by `isLoopbackRequest` alone: a loopback
 * socket with a loopback Host, a non-`cross-site` fetch marker, and an Origin
 * that is absent or matches the Host authority. Absent markers are *accepted*
 * — that is the exact header shape dsh Desktop's shell produces when it
 * forwards renderer requests to its own Host (it deletes `host`, `origin`,
 * `sec-fetch-site` and `cookie` first), and the same shape the platform fence
 * treats as trusted. A foreign origin, a cross-site marker, or a non-loopback
 * peer is rejected.
 */
function guard(req: IncomingMessage, res: ServerResponse): boolean {
  if (isLoopbackRequest(req)) return true
  json(res, 403, { ok: false, error: 'forbidden' })
  return false
}

async function readBody(req: IncomingMessage, limit: number): Promise<unknown> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    const buffer = chunk as Buffer
    size += buffer.length
    if (size > limit) throw new Error('body-too-large')
    chunks.push(buffer)
  }
  if (chunks.length === 0) return {}
  return JSON.parse(Buffer.concat(chunks).toString('utf8')) as unknown
}

function isMethod(req: IncomingMessage, method: string, res: ServerResponse): boolean {
  if (req.method === method) return true
  json(res, 405, { ok: false, error: 'method-not-allowed' })
  return false
}

/** Build the plugin's route set. */
export function makeCustomPluginRoutes(host: CustomPluginHost, ready: Promise<void> = Promise.resolve()): WebRoute[] {
  const stateRoute: WebRoute = {
    kind: 'exact',
    path: `${CUSTOM_PLUGIN_API_PREFIX}/state`,
    handler: async (req, res): Promise<void> => {
      if (!guard(req, res)) return
      await ready
      if (req.method === 'GET') {
        json(res, 200, { ok: true, data: await host.stateView() })
        return
      }
      if (req.method !== 'POST') {
        json(res, 405, { ok: false, error: 'method-not-allowed' })
        return
      }
      try {
        const rawBody = await readBody(req, STATE_BODY_LIMIT)
        if (rawBody === null || typeof rawBody !== 'object' || Array.isArray(rawBody)) {
          json(res, 400, { ok: false, error: '状态请求结构无效' })
          return
        }
        const body = rawBody as Record<string, unknown>
        await host.applyEdit({
          cfg: body.cfg as never,
          folders: Array.isArray(body.folders) ? (body.folders as never) : undefined,
          prompts: Array.isArray(body.prompts) ? (body.prompts as never) : undefined,
          stars: body.stars as never,
          apiKey: typeof body.apiKey === 'string' ? body.apiKey : undefined,
        })
        await host.persistWhenIdle()
        json(res, 200, { ok: true, ...(await host.credentialStatus()) })
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error)
        json(res, message === 'body-too-large' ? 413 : 400, { ok: false, error: message })
      }
    },
  }

  const timelineRoute: WebRoute = {
    kind: 'exact',
    path: `${CUSTOM_PLUGIN_API_PREFIX}/timeline`,
    handler: async (req, res): Promise<void> => {
      if (!guard(req, res)) return
      if (!isMethod(req, 'GET', res)) return
      const url = new URL(req.url ?? '/', 'http://localhost')
      const sessionId = url.searchParams.get('sessionId') ?? ''
      if (sessionId === '') {
        json(res, 400, { ok: false, error: 'no sessionId' })
        return
      }
      const result = await host.timelineGet(sessionId)
      json(res, result.ok ? 200 : 500, result)
    },
  }

  const backupRoute: WebRoute = {
    kind: 'exact',
    path: `${CUSTOM_PLUGIN_API_PREFIX}/backup`,
    handler: async (req, res): Promise<void> => {
      if (!guard(req, res)) return
      await ready
      if (req.method === 'GET') {
        json(res, 200, { ok: true, data: host.backupExport() })
        return
      }
      if (!isMethod(req, 'POST', res)) return
      try {
        const rawBody = await readBody(req, BACKUP_REQUEST_LIMIT)
        if (rawBody === null || typeof rawBody !== 'object' || Array.isArray(rawBody)) {
          json(res, 400, { ok: false, error: '备份请求结构无效' })
          return
        }
        const body = rawBody as Record<string, unknown>
        if (body.mode !== 'merge' && body.mode !== 'replace') {
          json(res, 400, { ok: false, error: '导入模式无效' })
          return
        }
        if (!Object.prototype.hasOwnProperty.call(body, 'document')) {
          json(res, 400, { ok: false, error: '备份文档缺失' })
          return
        }
        if (body.dryRun !== undefined && typeof body.dryRun !== 'boolean') {
          json(res, 400, { ok: false, error: 'dryRun 字段无效' })
          return
        }
        const encodedDocument = JSON.stringify(body.document)
        if (encodedDocument === undefined) {
          json(res, 400, { ok: false, error: '备份文档无效' })
          return
        }
        if (Buffer.byteLength(encodedDocument, 'utf8') > BACKUP_BODY_LIMIT) {
          json(res, 413, { ok: false, error: '备份文档不能超过 5 MB' })
          return
        }
        const result = await host.backupImport(body.document, body.mode, body.dryRun === true)
        json(res, result.ok ? 200 : 400, result)
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error)
        json(res, message === 'body-too-large' ? 413 : 400, { ok: false, error: message })
      }
    },
  }

  const searchRoute: WebRoute = {
    kind: 'exact',
    path: `${CUSTOM_PLUGIN_API_PREFIX}/search`,
    handler: async (req, res): Promise<void> => {
      if (!guard(req, res)) return
      if (!isMethod(req, 'POST', res)) return
      try {
        const body = (await readBody(req, TIMELINE_LIMIT)) as { sessionId?: string; query?: string; kinds?: unknown }
        if (typeof body.sessionId !== 'string' || body.sessionId === '' || typeof body.query !== 'string' || body.query.trim() === '') {
          json(res, 400, { ok: false, error: '会话或搜索词为空' })
          return
        }
        const allowed = new Set(['user', 'assistant', 'tool'])
        if (body.kinds !== undefined && !Array.isArray(body.kinds)) {
          json(res, 400, { ok: false, error: '角色筛选无效' })
          return
        }
        if (Array.isArray(body.kinds) && body.kinds.some((kind) => typeof kind !== 'string' || !allowed.has(kind))) {
          json(res, 400, { ok: false, error: '角色筛选无效' })
          return
        }
        const kinds = Array.isArray(body.kinds) ? body.kinds as Array<'user' | 'assistant' | 'tool'> : []
        const result = await host.conversationSearch(body.sessionId, body.query.trim(), kinds)
        json(res, result.ok ? 200 : 500, result)
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error)
        json(res, message === 'body-too-large' ? 413 : 400, { ok: false, error: message })
      }
    },
  }

  const exportRoute: WebRoute = {
    kind: 'exact',
    path: `${CUSTOM_PLUGIN_API_PREFIX}/export`,
    handler: async (req, res): Promise<void> => {
      if (!guard(req, res)) return
      if (!isMethod(req, 'POST', res)) return
      try {
        const body = (await readBody(req, TIMELINE_LIMIT)) as { sessionId?: string; format?: string }
        if (typeof body.sessionId !== 'string' || body.sessionId === '') {
          json(res, 400, { ok: false, error: 'no sessionId' })
          return
        }
        const result = await host.exportRun(body.sessionId, body.format ?? 'json')
        json(res, result.ok ? 200 : 500, result)
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error)
        json(res, message === 'body-too-large' ? 413 : 400, { ok: false, error: message })
      }
    },
  }

  const balanceRoute: WebRoute = {
    kind: 'exact',
    path: `${CUSTOM_PLUGIN_API_PREFIX}/balance`,
    handler: async (req, res): Promise<void> => {
      if (!guard(req, res)) return
      await ready
      if (!isMethod(req, 'GET', res)) return
      try {
        const result = await host.balanceGet()
        // 200 either way: the { ok, error } envelope carries the failure detail
        // (e.g. "key not configured") the panel renders.
        json(res, 200, result)
      } catch (error) {
        json(res, 500, { ok: false, keyConfigured: false, error: String((error as Error)?.message ?? error) })
      }
    },
  }

  const usageScanRoute: WebRoute = {
    kind: 'exact',
    path: `${CUSTOM_PLUGIN_API_PREFIX}/usage-scan`,
    handler: async (req, res): Promise<void> => {
      if (!guard(req, res)) return
      await ready
      if (!isMethod(req, 'POST', res)) return
      try {
        const result = await host.usageScan()
        json(res, result.ok ? 200 : 500, result)
      } catch (error) {
        json(res, 500, { ok: false, error: String((error as Error)?.message ?? error) })
      }
    },
  }

  const mermaidFetchRoute: WebRoute = {
    kind: 'exact',
    path: `${CUSTOM_PLUGIN_API_PREFIX}/mermaid`,
    handler: async (req, res): Promise<void> => {
      if (!guard(req, res)) return
      if (!isMethod(req, 'POST', res)) return
      try {
        const result = await host.mermaidFetch()
        json(res, result.ok ? 200 : 502, result)
      } catch (error) {
        json(res, 502, { ok: false, error: String((error as Error)?.message ?? error) })
      }
    },
  }

  const mermaidScriptRoute: WebRoute = {
    kind: 'exact',
    path: MERMAID_SCRIPT_PATH,
    handler: (req, res): void => {
      // Same fence as the API routes: a same-origin or unmarked loopback load
      // passes (web pages send sec-fetch-site: same-origin; dsh Desktop's
      // shell forwards the load without markers), a cross-site page does not.
      if (!guard(req, res)) return
      const script = host.mermaidScript()
      if (script === '') {
        res.statusCode = 503
        res.end('mermaid bundle not ready')
        return
      }
      const etag = `"${host.mermaidEtag()}"`
      res.setHeader('ETag', etag)
      res.setHeader('Cache-Control', 'no-cache')
      const ifNoneMatch = req.headers['if-none-match']
      if (typeof ifNoneMatch === 'string' && ifNoneMatch.split(',').some((value) => value.trim() === etag)) {
        // Reloads revalidate instead of re-transferring the 3.5 MB engine;
        // the hash changes only when the engine content does.
        res.statusCode = 304
        res.end()
        return
      }
      res.statusCode = 200
      res.setHeader('Content-Type', 'text/javascript; charset=utf-8')
      res.setHeader('Content-Length', String(Buffer.byteLength(script, 'utf8')))
      res.end(script)
    },
  }

  const diagRoute: WebRoute = {
    kind: 'exact',
    path: `${CUSTOM_PLUGIN_API_PREFIX}/diag`,
    handler: async (req, res): Promise<void> => {
      if (!guard(req, res)) return
      if (!isMethod(req, 'POST', res)) return
      try {
        const body = (await readBody(req, 4 * 1024)) as { msg?: string }
        if (typeof body.msg === 'string') host.pushDiag(body.msg)
      } catch {
        // diagnostics are best-effort
      }
      json(res, 200, { ok: true })
    },
  }

  const debugRoute: WebRoute = {
    kind: 'exact',
    path: `${CUSTOM_PLUGIN_API_PREFIX}/debug`,
    handler: (req, res): void => {
      if (!guard(req, res)) return
      if (!isMethod(req, 'GET', res)) return
      void ready.then(() => host.debugInfo()).then((info) => { json(res, 200, { ok: true, ...info }) }).catch(() => { json(res, 200, { ok: false, error: '调试信息不可用' }) })
    },
  }

  return [stateRoute, timelineRoute, backupRoute, searchRoute, exportRoute, balanceRoute, usageScanRoute, mermaidFetchRoute, mermaidScriptRoute, diagRoute, debugRoute]
}
