/**
 * Loopback trust fence for the host routes: socket address, Host header, and
 * browser same-origin markers.
 *
 * Semantics: RFC 5735 IPv4 127/8, ::1, IPv4-mapped ::ffff:127/8, localhost
 * hostnames. The request-level fence mirrors the platform's own API fence: a
 * loopback peer naming a loopback Host is trusted unless a marker says
 * otherwise — `sec-fetch-site: cross-site` rejects, and a present Origin must
 * match the Host authority. Absent markers are trusted: that is the header
 * shape dsh Desktop's shell produces when it forwards renderer requests to
 * its Host (it deletes `origin`, `sec-fetch-site` and `cookie` first), and
 * the shape the platform fence accepts for the same reason.
 * @module @alexpeng/dsh-custom-plugin/loopback
 */

import type { IncomingMessage } from 'node:http'

/** IPv4 127/8 predicate (four decimal octets, first == 127). */
export function isIPv4Loopback(v4: string): boolean {
  const parts = v4.split('.')
  return parts.length === 4
    && parts[0] === '127'
    && parts.every(part => /^\d{1,3}$/.test(part) && Number(part) <= 255)
}

/** Whether a socket remote address names the loopback range (127/8, ::1, IPv4-mapped). */
export function isLoopbackAddress(address: string | undefined): boolean {
  if (address === undefined) return false
  const normalized = address.toLowerCase()
  if (normalized === '::1') return true
  if (normalized.startsWith('::ffff:')) return isIPv4Loopback(normalized.slice('::ffff:'.length))
  return isIPv4Loopback(normalized)
}

/** Whether a normalized URL hostname names the loopback authority (localhost, [::1], 127/8). */
export function isLoopbackHostname(hostname: string): boolean {
  if (hostname === 'localhost' || hostname === '[::1]') return true
  return isIPv4Loopback(hostname)
}

/**
 * Request-level trust fence, mirroring the platform fence's semantics: a
 * loopback socket address AND a loopback Host header, non-`cross-site` fetch
 * marker, and an Origin that is absent (trusted — the dsh Desktop forward
 * shape) or matches the Host authority. The socket address is authoritative;
 * X-Forwarded-For is never trusted.
 */
export function isLoopbackRequest(request: IncomingMessage): boolean {
  if (!isLoopbackAddress(request.socket.remoteAddress)) return false
  const host = request.headers.host
  if (typeof host !== 'string') return false
  let hostUrl: URL
  try {
    hostUrl = new URL('http://' + host)
  } catch {
    return false
  }
  if (!isLoopbackHostname(hostUrl.hostname)) return false
  if (request.headers['sec-fetch-site'] === 'cross-site') return false
  const origin = request.headers.origin
  if (origin === undefined) return true
  try {
    return new URL(origin).host === hostUrl.host
  } catch {
    return false
  }
}
