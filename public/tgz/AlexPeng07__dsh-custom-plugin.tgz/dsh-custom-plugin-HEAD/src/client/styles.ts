/**
 * Static styles for the Custom suite, injected as one owned <style> tag at
 * install time (removed by the disposer). Global class names are prefixed
 * vx- and must not be scoped by CSS Modules.
 * @module @alexpeng/dsh-custom-plugin/client/styles
 */

export const STATIC_CSS = `/* dsh-custom-plugin static styles. Every rule is global by design: the UI
 * mounts into product slots and overlays, so class names are prefixed vx-
 * and must not be scoped by CSS Modules. Dynamic rules (body background,
 * global-glass blur) are managed at runtime by a style
 * element in custom.tsx and do not live here. */
.vx-root {
    position: fixed;
    inset: 0;
    pointer-events: none;
    z-index: 2147483000;
    font-family: ui-sans-serif, system-ui, 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  }
  .vx-fx {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
  }
  .vx-anchor {
    display: inline-block;
    width: 0;
    height: 1px;
    vertical-align: bottom;
  }
  .vx-turn-actions {
    display: inline-flex;
    gap: 4px;
    margin-left: 10px;
    vertical-align: middle;
    align-items: center;
  }
  .vx-chip {
    pointer-events: auto;
    border: 1px solid rgba(128, 140, 160, .4);
    background: rgba(255, 255, 255, .16);
    color: inherit;
    border-radius: 8px;
    padding: 2px 8px;
    font-size: 11px;
    cursor: pointer;
    backdrop-filter: blur(6px);
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 3px;
  }
  .vx-chip:hover {
    background: rgba(255, 255, 255, .28);
  }
  .vx-link {
    text-decoration: none;
  }
  .vx-glass {
    border-radius: 16px;
    background: rgba(255, 255, 255, .64);
    -webkit-backdrop-filter: blur(9px) saturate(1.22);
    backdrop-filter: blur(9px) saturate(1.22);
    box-shadow: 0 0 1px 1px rgba(17, 17, 26, .07) inset, 0 1px 2px rgba(17, 17, 26, .05) inset, 0px 4px 16px rgba(17, 17, 26, .05), 0px 8px 24px rgba(17, 17, 26, .05), 0px 16px 56px rgba(17, 17, 26, .05);
  }
  @media (prefers-color-scheme: dark) {
    .vx-glass {
      background: rgba(13, 17, 25, .62);
      color: #eef1f7;
    }
  }
  /* The GUI theme can disagree with the OS scheme (dsh selects light/dark
     independently — dark GUI on a light OS left these surfaces frosted
     light), so the frost fills and panel text colors key on the mirrored
     root classes, not the OS alone. The media queries above remain the
     pre-boot fallback, before the client has applied the classes; the liquid
     rules below out-rank these by specificity, not by order. */
  :root.vx-light .vx-glass {
    background: rgba(255, 255, 255, .64);
    color: inherit;
  }
  :root.vx-dark .vx-glass {
    background: rgba(13, 17, 25, .62);
    color: #eef1f7;
  }
  :root.vx-light .vx-panel,
  :root.vx-light .vx-modal,
  :root.vx-light .vx-folders {
    color: #20242e;
  }
  :root.vx-dark .vx-panel,
  :root.vx-dark .vx-modal,
  :root.vx-dark .vx-folders {
    color: #e8ebf2;
  }
  :root.vx-light .vx-balance-hover {
    color: #20242e;
  }
  :root.vx-dark .vx-balance-hover {
    color: #e8ebf2;
  }
  /* Liquid glass: the SVG displacement filter bends the backdrop at the
     surface's edges; the chained blur+saturate keeps text over the middle of
     large panels readable (pure displacement leaves the mid-area untouched,
     which read as "nothing happened"). Chromium runs this chain; engines
     without SVG-referencing backdrop filters fall back to frost below. */
  .vx-liquid .vx-glass {
    background: rgba(255, 255, 255, .1);
    backdrop-filter: url(#vx-lg) blur(2.5px) saturate(1.12);
    -webkit-backdrop-filter: url(#vx-lg) blur(2.5px) saturate(1.12);
  }
  @media (prefers-color-scheme: dark) {
    .vx-liquid .vx-glass {
      background: rgba(0, 0, 0, .1);
    }
  }
  /* The GUI theme classes are mirrored onto <html> by the client, so the
     liquid fill has to out-rank the theme frost fills *inside* .vx-root as
     well. The previous ".vx-root.* .vx-liquid .vx-glass" rules never matched
     anything — vx-liquid lives on <html>, an ANCESTOR of .vx-root, not a
     descendant — which left the big panels at the 64% frost fill while the
     balance hover (mounted outside .vx-root) sat at 10%: the "panel is not
     liquid, the balance card is" report, verbatim. */
  :root.vx-liquid.vx-dark .vx-glass {
    background: rgba(0, 0, 0, .1);
  }
  :root.vx-liquid.vx-light .vx-glass {
    background: rgba(255, 255, 255, .1);
  }
  :root.vx-liquid .vx-root.vx-dark .vx-glass {
    background: rgba(0, 0, 0, .1);
  }
  :root.vx-liquid .vx-root.vx-light .vx-glass {
    background: rgba(255, 255, 255, .1);
  }
  @supports not (backdrop-filter: url(#vx-lg)) {
    .vx-liquid .vx-glass {
      background: rgba(255, 255, 255, .64);
      backdrop-filter: blur(9px) saturate(1.22);
      -webkit-backdrop-filter: blur(9px) saturate(1.22);
    }
    @media (prefers-color-scheme: dark) {
      .vx-liquid .vx-glass {
        background: rgba(13, 17, 25, .62);
      }
    }
  }
  .vx-balance-wrap {
    display: inline-flex;
    align-items: center;
    position: relative;
  }
  .vx-balance-text {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 3px 10px;
    border-radius: 8px;
    font-size: 12.5px;
    color: inherit;
    background: rgba(127, 164, 224, .16);
    border: 1px solid rgba(127, 164, 224, .4);
    cursor: default;
    white-space: nowrap;
  }
  .vx-balance-text:hover {
    background: rgba(127, 164, 224, .28);
  }
  .vx-balance-text.vx-balance-open {
    background: rgba(127, 164, 224, .36);
    border-color: rgba(127, 164, 224, .8);
  }
  .vx-balance-today {
    opacity: .75;
    font-size: 11.5px;
  }
  .vx-balance-hover {
    position: absolute;
    top: calc(100% + 8px);
    right: 0;
    z-index: 70;
    width: 360px;
    max-height: 480px;
    overflow: auto;
    padding: 12px;
    color: #20242e;
    font-size: 12px;
    pointer-events: auto;
  }
  @media (prefers-color-scheme: dark) {
    .vx-balance-hover {
      color: #e8ebf2;
    }
  }
  .vx-balance-lines {
    font-size: 13px;
    margin: 6px 0;
  }
  .vx-header-btn {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 4px 10px;
    border-radius: 8px;
    font-size: 12.5px;
    color: inherit;
    background: rgba(127, 164, 224, .16);
    border: 1px solid rgba(127, 164, 224, .4);
    cursor: pointer;
    white-space: nowrap;
  }
  .vx-header-btn:hover {
    background: rgba(127, 164, 224, .3);
  }
  .vx-quote-btn {
    position: absolute;
    transform: translate(-50%, -100%);
    pointer-events: auto;
    background: rgba(40, 48, 64, .96);
    color: #eef1f7;
    border: 1px solid rgba(255, 255, 255, .25);
    padding: 5px 12px;
    border-radius: 9px;
    font-size: 12px;
    cursor: pointer;
    box-shadow: 0 6px 18px rgba(0, 0, 0, .28);
    display: inline-flex;
    align-items: center;
    gap: 5px;
  }
  .vx-panel {
    position: absolute;
    width: 430px;
    max-width: calc(100vw - 40px);
    height: min(660px, calc(100vh - 110px));
    display: flex;
    flex-direction: column;
    overflow: hidden;
    pointer-events: auto;
    color: #20242e;
  }
  @media (prefers-color-scheme: dark) {
    .vx-panel, .vx-modal, .vx-folders {
      color: #e8ebf2;
    }
  }
  .vx-panel-head {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 14px;
    cursor: move;
    user-select: none;
    border-bottom: 1px solid rgba(150, 160, 180, .25);
    position: relative;
    z-index: 1;
  }
  .vx-panel-title {
    font-weight: 600;
    font-size: 13px;
  }
  .vx-panel-sub {
    font-size: 11px;
    opacity: .62;
    white-space: nowrap;
  }
  .vx-tabs {
    display: flex;
    flex-wrap: wrap;
    gap: 2px;
    padding: 8px 10px 4px;
    border-bottom: 1px solid rgba(150, 160, 180, .2);
    position: relative;
    z-index: 1;
  }
  .vx-tab {
    border: none;
    background: transparent;
    color: inherit;
    opacity: .75;
    font-size: 12px;
    padding: 5px 9px;
    border-radius: 8px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }
  .vx-tab.on {
    opacity: 1;
    background: rgba(255, 255, 255, .28);
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, .35);
  }
  .vx-panel-body {
    flex: 1;
    overflow: auto;
    padding: 12px 14px;
    position: relative;
    z-index: 1;
  }
  .vx-col {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .vx-row {
    display: flex;
    gap: 8px;
    align-items: center;
  }
  .vx-row.wrap {
    flex-wrap: wrap;
  }
  .vx-flex1 {
    flex: 1;
  }
  .vx-section-title {
    font-weight: 600;
    font-size: 12.5px;
    margin-top: 4px;
    opacity: .9;
  }
  .vx-swatches {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 6px;
  }
  .vx-swatch {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 3px;
    border: none;
    background: transparent;
    color: inherit;
    cursor: pointer;
    padding: 0;
  }
  .vx-swatch-box {
    width: 34px;
    height: 26px;
    border-radius: 8px;
    border: 2px solid rgba(120, 130, 150, .4);
    box-sizing: border-box;
  }
  .vx-swatch.on .vx-swatch-box {
    border-color: #7fa4e0;
    box-shadow: 0 0 0 2px rgba(127, 164, 224, .35);
  }
  .vx-swatch-label {
    font-size: 10px;
    opacity: .85;
  }
  .vx-btn {
    pointer-events: auto;
    border: 1px solid rgba(128, 140, 160, .4);
    background: rgba(255, 255, 255, .16);
    color: inherit;
    border-radius: 9px;
    padding: 6px 12px;
    font-size: 12px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 5px;
  }
  .vx-btn:hover {
    background: rgba(255, 255, 255, .28);
  }
  .vx-btn.on {
    background: rgba(127, 164, 224, .35);
    border-color: rgba(127, 164, 224, .8);
  }
  .vx-btn:disabled {
    opacity: .5;
    cursor: default;
  }
  .vx-btn-sm {
    padding: 2px 8px;
    font-size: 11px;
  }
  .vx-btn-danger {
    background: rgba(214, 88, 88, .22);
    border-color: rgba(214, 88, 88, .55);
  }
  .vx-btn.big {
    padding: 10px 16px;
    font-size: 13px;
  }
  .vx-input {
    flex: 1;
    min-width: 0;
    border: 1px solid rgba(128, 140, 160, .4);
    background: rgba(255, 255, 255, .16);
    color: inherit;
    border-radius: 9px;
    padding: 6px 10px;
    font-size: 12px;
  }
  .vx-toggle-row {
    display: flex;
    gap: 8px;
    align-items: center;
    font-size: 12.5px;
  }
  .vx-muted {
    color: rgba(120, 128, 148, .95);
    font-size: 11.5px;
  }
  .vx-error {
    color: #d85858;
    font-size: 12px;
  }
  .vx-pad {
    padding: 12px;
  }
  .vx-pad-sm {
    padding: 6px 2px;
  }
  .vx-list {
    display: flex;
    flex-direction: column;
    gap: 4px;
    max-height: 300px;
    overflow: auto;
  }
  .vx-list-item {
    text-align: left;
    border: none;
    background: rgba(255, 255, 255, .1);
    color: inherit;
    border-radius: 8px;
    padding: 6px 10px;
    font-size: 12px;
    cursor: pointer;
  }
  .vx-list-item:hover {
    background: rgba(255, 255, 255, .22);
  }
  .vx-list-item.on {
    background: rgba(127, 164, 224, .28);
    box-shadow: inset 0 0 0 1px rgba(127, 164, 224, .45);
  }
  .vx-list-item:disabled {
    opacity: .55;
    cursor: not-allowed;
  }
  .vx-check-row {
    display: flex;
    gap: 8px;
    align-items: center;
    font-size: 12.5px;
    padding: 4px 2px;
  }
  .vx-check-title {
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .vx-badge {
    background: rgba(127, 164, 224, .3);
    border-radius: 8px;
    padding: 0 6px;
    font-size: 10px;
  }
  .vx-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 11.5px;
  }
  .vx-table th, .vx-table td {
    border: 1px solid rgba(128, 140, 160, .3);
    padding: 4px 6px;
    text-align: right;
  }
  .vx-table th:first-child, .vx-table td:first-child {
    text-align: left;
  }
  .vx-folder {
    display: flex;
    flex-direction: column;
  }
  .vx-folder-head {
    display: flex;
    gap: 5px;
    align-items: center;
    padding: 5px 4px;
    border-radius: 9px;
    cursor: grab;
  }
  .vx-folder-head:hover {
    background: rgba(255, 255, 255, .14);
  }
  .vx-folder-head.drop-inside {
    background: rgba(127, 164, 224, .3);
    outline: 1px dashed rgba(127, 164, 224, .8);
  }
  .vx-folder-head.drop-before {
    box-shadow: 0 -2px 0 0 rgba(127, 164, 224, .9);
  }
  .vx-folder-head.drop-after {
    box-shadow: 0 2px 0 0 rgba(127, 164, 224, .9);
  }
  .vx-folder-name {
    font-size: 12.5px;
    font-weight: 600;
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .vx-folder-body {
    border-left: 1px dashed rgba(128, 140, 160, .35);
    margin-left: 14px;
    padding-left: 6px;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .vx-item-row {
    display: flex;
    gap: 5px;
    align-items: center;
    padding: 3px 4px;
    border-radius: 8px;
  }
  .vx-item-row:hover {
    background: rgba(255, 255, 255, .12);
  }
  .vx-item-name {
    flex: 1;
    text-align: left;
    border: none;
    background: transparent;
    color: inherit;
    font-size: 12px;
    cursor: pointer;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    padding: 0;
  }
  .vx-mini {
    border: none;
    background: transparent;
    color: inherit;
    opacity: .75;
    cursor: pointer;
    padding: 2px;
    border-radius: 6px;
    display: inline-flex;
    align-items: center;
  }
  .vx-mini:hover {
    opacity: 1;
    background: rgba(255, 255, 255, .2);
  }
  .vx-form {
    display: flex;
    flex-direction: column;
    gap: 6px;
    border: 1px dashed rgba(128, 140, 160, .4);
    border-radius: 10px;
    padding: 8px;
  }
  .vx-prompt-card {
    border: 1px solid rgba(128, 140, 160, .3);
    background: rgba(255, 255, 255, .1);
    border-radius: 10px;
    padding: 8px 10px;
  }
  .vx-prompt-title {
    font-weight: 600;
    font-size: 12.5px;
  }
  .vx-prompt-body {
    margin-top: 4px;
    font-size: 11.5px;
    opacity: .85;
    white-space: pre-wrap;
    word-break: break-word;
    max-height: 72px;
    overflow: hidden;
  }
  .vx-modal-mask {
    position: absolute;
    inset: 0;
    pointer-events: auto;
    background: rgba(8, 10, 16, .4);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 60;
  }
  .vx-modal {
    position: relative;
    width: min(760px, 92vw);
    max-height: 82vh;
    overflow: auto;
    padding: 16px;
    color: #20242e;
    pointer-events: auto;
  }
  .vx-pop-head {
    display: flex;
    gap: 8px;
    align-items: center;
    margin-bottom: 8px;
    font-weight: 600;
    font-size: 13px;
  }
  .vx-svgbox {
    overflow: auto;
    background: rgba(12, 14, 20, .6);
    border-radius: 12px;
    padding: 14px;
  }
  .vx-svgbox svg {
    max-width: 100%;
    height: auto;
  }
  .vx-pre {
    white-space: pre-wrap;
    word-break: break-all;
    font-size: 10.5px;
    opacity: .85;
  }
  .vx-toasts {
    position: absolute;
    left: 50%;
    bottom: 26px;
    transform: translateX(-50%);
    display: flex;
    flex-direction: column;
    gap: 8px;
    align-items: center;
    pointer-events: auto;
    z-index: 80;
  }
  .vx-toast {
    display: flex;
    gap: 10px;
    align-items: center;
    color: #f2f4f8;
    background: rgba(26, 32, 44, .92);
    border: 1px solid rgba(255, 255, 255, .12);
    padding: 8px 14px;
    border-radius: 12px;
    font-size: 12.5px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, .3);
    max-width: 560px;
    backdrop-filter: blur(9px);
    -webkit-backdrop-filter: blur(9px);
  }
  @media (prefers-color-scheme: dark) {
    .vx-toast {
      background: rgba(18, 22, 30, .94);
    }
  }
  .vx-foot-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    border: 1px solid rgba(127, 164, 224, .4);
    background: rgba(127, 164, 224, .14);
    color: inherit;
    cursor: pointer;
    padding: 4px 10px;
    border-radius: 10px;
    margin: 2px;
  }
  .vx-foot-btn:hover {
    background: rgba(127, 164, 224, .3);
  }
  .vx-foot-label {
    font-size: 12px;
  }
  .vx-folders {
    position: fixed;
    left: 12px;
    bottom: 60px;
    width: 272px;
    max-height: min(560px, calc(100vh - 220px));
    display: flex;
    flex-direction: column;
    overflow: hidden;
    pointer-events: auto;
    color: #20242e;
    z-index: 55;
  }
  /* 头部行（图标 + 标题 + 按钮）下移并拉开与容器边缘的间距 */
  .vx-folders .vx-pop-head {
    padding: 14px 14px 0;
  }
  .vx-folders-body {
    flex: 1;
    overflow: auto;
    padding: 4px 14px 12px;
    position: relative;
    z-index: 1;
  }
  .vx-prompt-pop {
    position: fixed;
    width: 320px;
    max-height: 420px;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    pointer-events: auto;
    color: #20242e;
    z-index: 65;
    padding: 10px 12px;
  }
  .vx-settings-page {
    display: flex;
    flex-direction: column;
    gap: 14px;
    max-width: 720px;
  }
  .vx-mmd-wrap {
    position: relative;
    margin: 6px 0;
    border: 1px solid rgba(127, 164, 224, .35);
    border-radius: 12px;
    overflow: hidden;
    background: rgba(127, 164, 224, .05);
  }
  .vx-mmd-bar {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 4px 6px;
    border-bottom: 1px solid rgba(127, 164, 224, .25);
    background: rgba(127, 164, 224, .08);
  }
  .vx-mmd-btn {
    border: none;
    background: transparent;
    color: inherit;
    opacity: .65;
    font-size: 12px;
    padding: 3px 10px;
    border-radius: 8px;
    cursor: pointer;
  }
  .vx-mmd-btn:hover {
    opacity: 1;
    background: rgba(127, 164, 224, .18);
  }
  .vx-mmd-btn.active {
    opacity: 1;
    background: rgba(127, 164, 224, .28);
    font-weight: 600;
  }
  .vx-mmd-live {
    margin-left: auto;
    font-size: 11px;
    opacity: .6;
    color: inherit;
    text-decoration: none;
    padding: 3px 8px;
  }
  .vx-mmd-live:hover {
    opacity: 1;
  }
  .vx-mmd-stage {
    padding: 16px 12px;
    overflow-x: auto;
    text-align: center;
  }
  .vx-mmd-stage svg {
    max-width: 100%;
    height: auto;
  }

  /* DSH can select a theme independently of the operating system. The root
     classes are applied from the resolved GUI theme and intentionally win
     over the media-query fallback above. */
  .vx-root.vx-dark .vx-glass {
    background: rgba(13, 17, 25, .62);
    color: #eef1f7;
  }
  .vx-root.vx-dark .vx-balance-hover,
  .vx-root.vx-dark .vx-panel,
  .vx-root.vx-dark .vx-modal,
  .vx-root.vx-dark .vx-folders {
    color: #e8ebf2;
  }
  .vx-root.vx-dark .vx-toast {
    background: rgba(18, 22, 30, .94);
  }

  .vx-root.vx-light .vx-glass {
    background: rgba(255, 255, 255, .64);
    color: #20242e;
  }
  .vx-root.vx-light .vx-balance-hover,
  .vx-root.vx-light .vx-panel,
  .vx-root.vx-light .vx-modal,
  .vx-root.vx-light .vx-folders {
    color: #20242e;
  }
  .vx-root.vx-light .vx-toast {
    background: rgba(26, 32, 44, .92);
  }
`
