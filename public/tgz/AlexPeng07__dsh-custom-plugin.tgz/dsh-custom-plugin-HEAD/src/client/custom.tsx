/**
 * Browser half of dsh-custom-plugin: the Custom convenience suite UI.
 *
 * A single mutable store (`S`) drives every surface through a lightweight
 * listener set; components re-render on `setS`. The file ports the earlier
 * dynamic-plugin implementation: React is a platform import, static styles
 * are injected through one owned style element (styles.ts), dynamic body
 * styles (background / global glass) extend it, and host calls go
 * over `/api/custom-plugin` fetch routes.
 * @module @alexpeng/dsh-custom-plugin/client/custom
 */

import * as React from 'react'
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots'
import type { ThemeRuntime } from '@deepseek-ai/dsh-client-ui-theme/client'
import type { Context } from '@deepseek-ai/cordis'
import { DEFAULT_CONFIG, type ConversationSearchItem, type ConversationSearchKind, type CredentialStorage, type CustomPluginConfig, type FolderNode, type PromptItem, type TimelineItem, type UsageRow } from '../protocol.ts'
import { createUsageRow, dayKey, mergeUsageRow } from '../usage.ts'
import { DEEPSEEK_PRICING_CHECKED_ON, DEEPSEEK_PRICING_SOURCE_URL, estimateUsageCostCny, usageCostBreakdown } from '../pricing.ts'
import { DARK_CANVAS_LIGHTNESS, hexToRgb, PALETTE, toDarkRamp } from './palette.ts'
import {
  apiBalanceGet,
  apiBackupExport,
  apiBackupImport,
  apiConversationSearch,
  apiDebugInfo,
  apiDiagReport,
  apiExportRun,
  apiMermaidFetch,
  apiStateGet,
  apiStateSave,
  apiTimelineGet,
  apiUsageScan,
} from './api.ts'
import { archiveBatch, budgetState, fillPromptTemplate, isCommandPaletteShortcut, normalizePromptItem, parsePromptsMarkdown, promptsMarkdown, promptVariables, summarizeUsage, usageCsv } from '../productivity.ts'
import { MERMAID_SCRIPT_PATH } from '../protocol.ts'
import { isGenericInfostring, isMermaidCode, normalizeMermaidText } from './mermaid-code.ts'
import { mermaidLiveUrl } from './mermaid-url.ts'
import { mermaidCodeKey, reuseTimelineItems } from './timeline-diff.ts'
import { STATIC_CSS } from './styles.ts'

/** Minimal input-state face the input dock owner provides. */
interface InputStateLike {
  draft?: string
}

/** Minimal input-actions face the framework injects into input-region slots. */
interface InputActionsLike {
  setDraft(text: string): void
}

/** Minimal workspace row face (official WorkspaceView carries workspaceId). */
interface WorkspaceRowLike {
  workspaceId: string
  title?: string
  path?: string
}

/**
 * The slot-prop data shapes below are declared locally on purpose: the harness
 * controller packages that own them rename and re-shape them across releases,
 * and importing their types would couple this bundle to modules it never loads
 * at runtime. Only the fields actually read are declared.
 */
/** One Session row of the `useSessions()` list snapshot. */
interface SessionRowLike {
  readonly id: string
  readonly displayTitle?: string
  readonly title?: string
  readonly running?: boolean
}

/** The `useSessions()` snapshot. `phase` is monotone: `ready` never steps back. */
interface SessionListLike {
  readonly ids: readonly string[]
  readonly byId: Readonly<Record<string, SessionRowLike>>
  readonly phase: 'pending' | 'ready'
}

/** The `useWorkspaces()` snapshot. */
interface WorkspaceListLike {
  readonly items?: readonly WorkspaceRowLike[]
  readonly state: 'idle' | 'loading' | 'error'
}

/** Turn placement the Chat turnTail slot hands to its entries. */
interface TurnLocationLike {
  readonly turn: number
  readonly status?: 'open' | 'closed' | 'unknown'
}

/** Standard prop every `scope: 'session'` slot entry receives. */
interface SessionScopedProps {
  readonly sessionId?: string | null
}

/** The `ctx.remote.session` methods this plugin calls. */
interface SessionRemoteLike {
  fork(request: { sessionId: string; atSeq?: number }): Promise<{ ok: true; value: { sessionId: string } } | { ok: false; error?: unknown }>
  search(request: { query: string }, signal?: AbortSignal): Promise<{ ok: true; value: { items: Array<{ sessionId: string; snippet: string }> } } | { ok: false; error?: unknown }>
}

/** The `ctx.uiWorkspace` navigation methods this plugin calls. */
interface WorkspaceNavLike {
  openSession(id: string): void
  connectWorkspace(id: string): Promise<string>
}

/**
 * dsh's shipped web profile configures the session index with `openAt: never`,
 * so cross-session full-text search can legitimately be unavailable. Say what
 * still works instead of leaving a bare error that reads as a broken palette.
 */
const CROSS_SEARCH_UNAVAILABLE = '跨会话全文搜索不可用；下方结果仍按标题匹配会话与工作区。'

function formatTokenCount(value: number): string {
  return Math.round(value).toLocaleString('zh-CN')
}

/** Shared mutable store. */
interface Store {
  cfg: CustomPluginConfig
  folders: FolderNode[]
  prompts: PromptItem[]
  stars: Record<string, Record<string, boolean>>
  apiKey: string
  apiKeyDirty: boolean
  apiKeyConfigured: boolean
  credentialStorage: CredentialStorage
  usage: Record<string, Record<string, UsageRow>>
  sessionId: string | null
  turns: { sessionId: string; items: TimelineItem[] } | null
  /** seq → item index over `turns.items`, built once per fetch: one
   * TurnTailEntry per rendered turn reads it on every store change, and a
   * linear `find` per entry made each store event cost O(turns × entries). */
  turnsBySeq: Map<number, TimelineItem> | null
  anchors: Map<number, { el: HTMLElement; turn: TurnLocationLike | null }>
  panelOpen: boolean
  panelTab: string
  panelPos: { x: number; y: number } | null
  foldersOpen: boolean
  folderAdd: string | null
  folderWsPick: string | null
  dragFolder: string | null
  dropHint: { id: string; zone: string } | null
  promptOpen: { x: number; y: number } | null
  promptQuery: string
  balanceOpen: boolean
  batchModal: boolean
  mermaidModal: { title: string; codes: string[]; index: number } | null
  quoteSel: { text: string; x: number; y: number } | null
  ask: { title: string; value: string; cb: (text: string) => void; allowEmpty?: boolean } | null
  confirmAsk: { message: string; cb: (ok: boolean) => void } | null
  toasts: Array<{ id: number; text: string; kind: string; action: { label: string; run: () => void } | null }>
  booted: boolean
  dark: boolean
  balance: Record<string, unknown> | null
  exporting: boolean
  usageRange: 7 | 30 | 90
  templatePrompt: PromptItem | null
  templateValues: Record<string, string>
  commandOpen: boolean
  insertDraft: ((text: string, replace: boolean) => boolean) | null
  greeted: boolean
}

/** Neutral glass tokens used when no palette color is active. */
const NEUTRAL_TOKENS: Record<string, { light: string; dark: string }> = {
  '--dsw-alias-bg-base': { light: 'rgba(248,249,251,.5)', dark: 'rgba(15,17,23,.5)' },
  '--dsw-alias-bg-layer-1': { light: 'rgba(255,255,255,.58)', dark: 'rgba(22,25,32,.58)' },
  '--dsw-alias-bg-layer-2': { light: 'rgba(242,244,247,.66)', dark: 'rgba(28,31,40,.66)' },
  '--dsw-alias-bg-overlay': { light: 'rgba(255,255,255,.78)', dark: 'rgba(18,21,28,.78)' },
  '--dsw-specific-sidebar-fill': { light: 'rgba(245,247,250,.56)', dark: 'rgba(13,15,21,.56)' },
}

/** SVG displacement map + filter for the liquid glass (single-channel, no color dispersion). */
const LG_MAP =
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">'
  + '<defs><linearGradient id="r" x1="100%" y1="0%" x2="0%" y2="0%"><stop offset="0%" stop-color="#0000"/><stop offset="100%" stop-color="red"/></linearGradient>'
  + '<linearGradient id="b" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" stop-color="#0000"/><stop offset="100%" stop-color="blue"/></linearGradient></defs>'
  + '<rect width="100" height="100" fill="black"/>'
  + '<rect width="100" height="100" rx="16" fill="url(#r)"/>'
  + '<rect width="100" height="100" rx="16" fill="url(#b)" style="mix-blend-mode: difference"/>'
  + '<rect x="3.5" y="3.5" width="93" height="93" rx="16" fill="hsl(0 0% 50% / 0.93)" style="filter: blur(11px)"/></svg>'
const LG_URI = 'data:image/svg+xml,' + encodeURIComponent(LG_MAP)
const LG_FILTER =
  '<filter id="vx-lg" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB">'
  + '<feImage href="' + LG_URI + '" result="map" x="0" y="0" width="100%" height="100%" preserveAspectRatio="none"/>'
  + '<feDisplacementMap in="SourceGraphic" in2="map" xChannelSelector="R" yChannelSelector="B" scale="-180" result="d"/>'
  + '<feGaussianBlur in="d" stdDeviation="4"/></filter>'

function ensureLiquidGlass(): void {
  const d = typeof document !== 'undefined' ? document : null
  if (d === null || d.getElementById('vx-lg-filter') !== null) return
  try {
    const svg = d.createElementNS('http://www.w3.org/2000/svg', 'svg')
    svg.setAttribute('id', 'vx-lg-filter')
    svg.setAttribute('width', '0')
    svg.setAttribute('height', '0')
    svg.setAttribute('style', 'position:absolute;width:0;height:0;overflow:hidden')
    svg.innerHTML = LG_FILTER
    d.documentElement.appendChild(svg)
  } catch (error) {
    apiDiagReport('ensureLiquidGlass: ' + String((error as Error)?.message ?? error))
  }
}

/** One owned style element carrying the static rules plus the dynamic body rules. */
let dynStyle: HTMLStyleElement | null = null
function setDynCss(css: string): void {
  const d = typeof document !== 'undefined' ? document : null
  if (d === null) return
  if (dynStyle === null || !dynStyle.isConnected) {
    dynStyle = d.createElement('style')
    dynStyle.setAttribute('data-custom-plugin-css', '')
    d.head.appendChild(dynStyle)
  }
  dynStyle.textContent = STATIC_CSS + '\n' + css
}
function removeDynCss(): void {
  if (dynStyle !== null && dynStyle.isConnected) {
    try { dynStyle.remove() } catch { /* style already gone */ }
  }
  dynStyle = null
}

/** Public component props (the product slot system injects these). */
export interface OverlayProps {
  useSessions: SnapshotSelectorHook<SessionListLike>
  useWorkspaces: SnapshotSelectorHook<WorkspaceListLike>
}
export interface QuoteDockProps extends SessionScopedProps {
  input: InputStateLike
  inputActions: InputActionsLike
}
export interface TurnTailProps extends SessionScopedProps {
  turn: TurnLocationLike
  seq: number
  openFile: (path: string) => void
}

/** Install the whole Custom UI into the client context. Returns a disposer that unregisters every slot entry. */
export function installCustomPlugin(ctx: Context, reportDiag: (message: string) => void): () => void {
  const C = ctx

  const S: Store = {
    cfg: { ...DEFAULT_CONFIG },
    folders: [],
    prompts: [],
    stars: {},
    apiKey: '',
    apiKeyDirty: false,
    apiKeyConfigured: false,
    credentialStorage: 'none',
    usage: {},
    sessionId: null,
    turns: null,
    turnsBySeq: null,
    anchors: new Map(),
    panelOpen: false,
    panelTab: 'look',
    panelPos: null,
    foldersOpen: false,
    folderAdd: null,
    folderWsPick: null,
    dragFolder: null,
    dropHint: null,
    promptOpen: null,
    promptQuery: '',
    balanceOpen: false,
    batchModal: false,
    mermaidModal: null,
    quoteSel: null,
    ask: null,
    confirmAsk: null,
    toasts: [],
    booted: false,
    dark: false,
    balance: null,
    exporting: false,
    usageRange: 7,
    templatePrompt: null,
    templateValues: {},
    commandOpen: false,
    insertDraft: null,
    greeted: false,
  }

  let listeners: Array<() => void> = []
  function setS(patch: Partial<Store>): void {
    Object.assign(S, patch)
    for (const listener of listeners) {
      try { listener() } catch { /* listener errors never take the GUI down */ }
    }
  }
  function useS(): Store {
    const [, force] = React.useReducer((x: number) => x + 1, 0)
    React.useEffect(() => {
      listeners.push(force)
      return () => { listeners = listeners.filter((l) => l !== force) }
    }, [])
    return S
  }
  /** Shallow object equality for selector results. */
  function shallowEqual<T extends object>(a: T, b: T): boolean {
    if (a === b) return true
    const aKeys = Object.keys(a)
    if (aKeys.length !== Object.keys(b).length) return false
    for (const key of aKeys) {
      if (!Object.is((a as Record<string, unknown>)[key], (b as Record<string, unknown>)[key])) return false
    }
    return true
  }
  /**
   * Subscribe to a slice of the store. The store fan-out is intentionally
   * simple (one listener set), but per-turn entries are the hot path: a
   * balance tick or a toast must not re-render 400 turn-tail rows. The
   * selector runs on every store write; only an unequal result forces a
   * render.
   */
  function useSSelector<T>(selector: (state: Store) => T, equal: (a: T, b: T) => boolean = Object.is): T {
    const [, force] = React.useReducer((x: number) => x + 1, 0)
    const selectorRef = React.useRef(selector)
    selectorRef.current = selector
    const equalRef = React.useRef(equal)
    equalRef.current = equal
    const current = selector(S)
    const currentRef = React.useRef(current)
    currentRef.current = current
    React.useEffect(() => {
      const listener = (): void => {
        const next = selectorRef.current(S)
        if (!equalRef.current(currentRef.current, next)) {
          currentRef.current = next
          force()
        }
      }
      listeners.push(listener)
      // A store write can land between this render and effect registration;
      // compare once so that update is not lost.
      listener()
      return () => { listeners = listeners.filter((l) => l !== listener) }
    }, [])
    return current
  }
  function useSessionsSafe(props: { useSessions: OverlayProps['useSessions'] }): SessionListLike | null {
    try { return props.useSessions(st => st) } catch { return null }
  }
  function useWorkspacesSafe(props: { useWorkspaces: OverlayProps['useWorkspaces'] }): WorkspaceListLike | null {
    try { return props.useWorkspaces(st => st) } catch { return null }
  }
  /**
   * Follow the Session the conversation is showing. The 0.1.7 session list
   * snapshot dropped its `current` field — view selection moved to the
   * Workspace browser — so the plugin reads the identity off the standard
   * `sessionId` prop that every session-scoped slot entry receives.
   *
   * Several entries carry it at once (two header actions, the utilities entry,
   * the quote dock, and one tail entry per turn), and a turn-level entry can
   * unmount while the same Session stays open. Only the LAST mounted holder may
   * clear the identity, otherwise the rail would go blank under the surviving
   * entries, whose props never change and so never re-run their effect.
   *
   * A holder that reports no session id claims nothing at all: it must not
   * count toward the holders, because one entry flipping to null while the
   * others still carry the session would otherwise wipe the identity they are
   * still rendering — and their effects never re-run to restore it.
   */
  let sessionScopeHolders = 0
  function useViewedSession(props: { sessionId?: string | null }): void {
    const id = typeof props.sessionId === 'string' && props.sessionId !== '' ? props.sessionId : null
    React.useEffect(() => {
      if (id === null) return
      sessionScopeHolders++
      if (S.sessionId !== id) {
        S.anchors.clear()
        setS({ sessionId: id, turns: null, turnsBySeq: null })
        void fetchTurns(id)
      }
      return () => {
        sessionScopeHolders--
        // Clearing the identity has to clear everything loaded under it, maps
        // included: a stale anchor element would let a search jump land on a
        // node the next session never rendered.
        if (sessionScopeHolders === 0 && S.sessionId === id) {
          S.anchors.clear()
          setS({ sessionId: null, turns: null, turnsBySeq: null })
        }
      }
    }, [id])
  }

  const ICONS: Record<string, Array<[string, Record<string, unknown>]>> = {
    sliders: [['line', { x1: 21, y1: 4, x2: 14, y2: 4 }], ['line', { x1: 10, y1: 4, x2: 3, y2: 4 }], ['line', { x1: 21, y1: 12, x2: 12, y2: 12 }], ['line', { x1: 8, y1: 12, x2: 3, y2: 12 }], ['line', { x1: 21, y1: 20, x2: 16, y2: 20 }], ['line', { x1: 12, y1: 20, x2: 3, y2: 20 }], ['line', { x1: 14, y1: 2, x2: 14, y2: 6 }], ['line', { x1: 8, y1: 10, x2: 8, y2: 14 }], ['line', { x1: 16, y1: 18, x2: 16, y2: 22 }]],
    folder: [['path', { d: 'M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z' }]],
    folderPlus: [['path', { d: 'M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z' }], ['line', { x1: 12, y1: 10, x2: 12, y2: 16 }], ['line', { x1: 9, y1: 13, x2: 15, y2: 13 }]],
    zap: [['path', { d: 'M13 2 3 14h9l-1 8 10-12h-9l1-8z' }]],
    download: [['path', { d: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4' }], ['polyline', { points: '7 10 12 15 17 10' }], ['line', { x1: 12, y1: 15, x2: 12, y2: 3 }]],
    gitBranch: [['line', { x1: 6, y1: 3, x2: 6, y2: 15 }], ['circle', { cx: 18, cy: 6, r: 3 }], ['circle', { cx: 6, cy: 18, r: 3 }], ['path', { d: 'M18 9a9 9 0 0 1-9 9' }]],
    wrench: [['path', { d: 'M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z' }]],
    wallet: [['path', { d: 'M21 12V7H5a2 2 0 0 1 0-4h14v4' }], ['path', { d: 'M3 5v14a2 2 0 0 0 2 2h16v-5' }], ['path', { d: 'M18 12a2 2 0 0 0 0 4h4v-4Z' }]],
    info: [['circle', { cx: 12, cy: 12, r: 10 }], ['line', { x1: 12, y1: 16, x2: 12, y2: 12 }], ['line', { x1: 12, y1: 8, x2: 12.01, y2: 8 }]],
    x: [['line', { x1: 18, y1: 6, x2: 6, y2: 18 }], ['line', { x1: 6, y1: 6, x2: 18, y2: 18 }]],
    star: [['path', { d: 'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z' }]],
    copy: [['rect', { x: 9, y: 9, width: 13, height: 13, rx: 2 }], ['path', { d: 'M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1' }]],
    check: [['polyline', { points: '20 6 9 17 4 12' }]],
    quote: [['path', { d: 'M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z' }]],
    search: [['circle', { cx: 11, cy: 11, r: 8 }], ['line', { x1: 21, y1: 21, x2: 16.65, y2: 16.65 }]],
    trash: [['polyline', { points: '3 6 5 6 21 6' }], ['path', { d: 'M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2' }], ['line', { x1: 10, y1: 11, x2: 10, y2: 17 }], ['line', { x1: 14, y1: 11, x2: 14, y2: 17 }]],
    plus: [['line', { x1: 12, y1: 5, x2: 12, y2: 19 }], ['line', { x1: 5, y1: 12, x2: 19, y2: 12 }]],
    chevronDown: [['polyline', { points: '6 9 12 15 18 9' }]],
    chevronRight: [['polyline', { points: '9 18 15 12 9 6' }]],
    refresh: [['polyline', { points: '23 4 23 10 17 10' }], ['polyline', { points: '1 20 1 14 7 14' }], ['path', { d: 'M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15' }]],
    briefcase: [['rect', { x: 2, y: 7, width: 20, height: 14, rx: 2 }], ['path', { d: 'M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16' }]],
    message: [['path', { d: 'M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z' }]],
    snowflake: [['line', { x1: 2, y1: 12, x2: 22, y2: 12 }], ['line', { x1: 12, y1: 2, x2: 12, y2: 22 }], ['path', { d: 'm20 16-4-4 4-4' }], ['path', { d: 'm4 8 4 4-4 4' }], ['path', { d: 'm16 4-4 4-4-4' }], ['path', { d: 'm8 20 4-4 4 4' }]],
    cloudRain: [['path', { d: 'M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242' }], ['line', { x1: 16, y1: 14, x2: 16, y2: 20 }], ['line', { x1: 8, y1: 14, x2: 8, y2: 20 }], ['line', { x1: 12, y1: 16, x2: 12, y2: 22 }]],
    flower: [['circle', { cx: 12, cy: 12, r: 3 }], ['circle', { cx: 12, cy: 4.5, r: 2.1 }], ['circle', { cx: 18.5, cy: 8.3, r: 2.1 }], ['circle', { cx: 16, cy: 15.7, r: 2.1 }], ['circle', { cx: 8, cy: 15.7, r: 2.1 }], ['circle', { cx: 5.5, cy: 8.3, r: 2.1 }]],
    minimize: [['polyline', { points: '4 14 10 14 10 20' }], ['polyline', { points: '20 10 14 10 14 4' }], ['line', { x1: 14, y1: 10, x2: 21, y2: 3 }], ['line', { x1: 3, y1: 21, x2: 10, y2: 14 }]],
    list: [['line', { x1: 8, y1: 6, x2: 21, y2: 6 }], ['line', { x1: 8, y1: 12, x2: 21, y2: 12 }], ['line', { x1: 8, y1: 18, x2: 21, y2: 18 }], ['line', { x1: 3, y1: 6, x2: 3.01, y2: 6 }], ['line', { x1: 3, y1: 12, x2: 3.01, y2: 12 }], ['line', { x1: 3, y1: 18, x2: 3.01, y2: 18 }]],
  }

  function Icon(props: { n: string; size?: number; filled?: boolean; sw?: number; cls?: string; style?: React.CSSProperties }): React.ReactElement {
    const defs = ICONS[props.n] ?? ICONS.info
    const size = props.size ?? 14
    return React.createElement('svg', {
      viewBox: '0 0 24 24',
      width: size,
      height: size,
      fill: props.filled === true ? 'currentColor' : 'none',
      stroke: props.filled === true ? 'none' : 'currentColor',
      strokeWidth: props.sw ?? 1.8,
      strokeLinecap: 'round',
      strokeLinejoin: 'round',
      className: props.cls ?? '',
      style: props.style ?? null,
    }, defs.map((def, index) => {
      const tag = def[0]
      const attrs = def[1]
      if (tag === 'circle') return React.createElement('circle', { key: index, ...attrs })
      if (tag === 'line') return React.createElement('line', { key: index, ...attrs })
      if (tag === 'rect') return React.createElement('rect', { key: index, ...attrs })
      if (tag === 'polyline') return React.createElement('polyline', { key: index, ...attrs })
      return React.createElement('path', { key: index, ...attrs })
    }))
  }

  function toast(text: string, kind?: string, action?: { label: string; run: () => void } | null): void {
    const id = Date.now() + Math.floor(Math.random() * 9999)
    const item = { id, text, kind: kind ?? 'info', action: action ?? null }
    S.toasts = S.toasts.concat(item).slice(-4)
    setS({ toasts: S.toasts })
    void new Promise<void>((resolve) => setTimeout(resolve, kind === 'error' ? 6000 : 3800)).then(() => {
      S.toasts = S.toasts.filter((t) => t.id !== id)
      setS({ toasts: S.toasts })
    }).catch(() => {})
  }

  function askText(title: string, value: string, cb: (text: string) => void, allowEmpty = false): void {
    setS({ ask: { title, value: value ?? '', cb, allowEmpty } })
  }
  function askConfirm(message: string, cb: (ok: boolean) => void): void {
    setS({ confirmAsk: { message, cb } })
  }

  function rgbaOf(hex: string, alpha: number): string {
    const c = hexToRgb(hex)
    return `rgba(${c[0]},${c[1]},${c[2]},${alpha})`
  }
  function shade(hex: string, factor: number): string {
    const c = hexToRgb(hex)
    const mix = (v: number): number => Math.max(0, Math.min(255, Math.round(v * factor)))
    return '#' + [mix(c[0]), mix(c[1]), mix(c[2])].map((v) => v.toString(16).padStart(2, '0')).join('')
  }

  let tokenDisposer: (() => void) | null = null
  function applyAppearance(): void {
    const cfg = S.cfg
    const dEl = typeof document !== 'undefined' ? document.documentElement : null
    if (dEl !== null) {
      try { dEl.classList.toggle('vx-liquid', cfg.glass === true && cfg.glassMode === 'liquid') } catch { /* classList unavailable */ }
    }
    const theme = C.get('theme') as ThemeRuntime | undefined
    if (tokenDisposer !== null) {
      try { tokenDisposer() } catch { /* best effort */ }
      tokenDisposer = null
    }
    if (theme !== undefined && typeof theme.overrideTokens === 'function') {
      if (cfg.bg !== undefined && cfg.bg !== 'default') {
        const entry = PALETTE.find((p) => p[0] === cfg.bg) ?? PALETTE[0]
        const base = entry[1]
        const tab = entry[2] ?? shade(base, 0.94)
        const glassOn = cfg.glass === true
        const mk = (c: string, a: number): string => (glassOn ? rgbaOf(c, a) : c)
        // Dark variants are derived onto the same hue family's dark ramp (the
        // light pastels themselves would glare on a dark canvas).
        const darkBase = toDarkRamp(base, 0.14)
        const darkTab = toDarkRamp(tab, 0.18)
        tokenDisposer = theme.overrideTokens('custom-plugin-appearance', {
          '--dsw-alias-bg-base': { light: mk(base, 0.5), dark: mk(darkBase, 0.5) },
          '--dsw-alias-bg-layer-1': { light: mk(tab, 0.6), dark: mk(darkTab, 0.6) },
          '--dsw-alias-bg-layer-2': { light: mk(shade(base, 0.96), 0.7), dark: mk(shade(darkBase, 0.94), 0.7) },
          '--dsw-alias-bg-overlay': { light: mk(shade(base, 1.04), 0.8), dark: mk(shade(darkBase, 0.86), 0.8) },
          '--dsw-specific-sidebar-fill': { light: mk(tab, 0.62), dark: mk(darkTab, 0.62) },
        })
      } else if (cfg.glass === true) {
        tokenDisposer = theme.overrideTokens('custom-plugin-appearance', NEUTRAL_TOKENS)
      }
    }
    let dyn = ''
    if (cfg.bg !== undefined && cfg.bg !== 'default') {
      const base = (PALETTE.find((p) => p[0] === cfg.bg) ?? PALETTE[0])[1]
      // Dark mode derives the same family's dark variant; S.dark is kept in
      // step with the GUI theme (applyDark) and re-runs this painter.
      const surface = S.dark === true ? toDarkRamp(base, DARK_CANVAS_LIGHTNESS) : base
      dyn += ` body { background-color: ${surface} !important; }`
    }
    if (cfg.globalGlass === true) {
      // In liquid mode the same SVG displacement chain as the plugin's own
      // surfaces extends to shell overlays (dialogs, menus, tooltips, the
      // settings window is a dialog too). Engines that cannot reference an
      // SVG filter from backdrop-filter keep the plain frost blur.
      const liquidGlobal = cfg.glass === true && cfg.glassMode === 'liquid'
        && typeof CSS !== 'undefined' && typeof CSS.supports === 'function'
        && CSS.supports('backdrop-filter', 'url(#vx-lg)')
      const filter = liquidGlobal ? 'url(#vx-lg) blur(2.5px) saturate(1.12)' : 'blur(8px) saturate(1.2)'
      dyn += ` [role='dialog'], [role='menu'], [role='tooltip'], [role='listbox'], [data-radix-popper-content-wrapper] { backdrop-filter: ${filter} !important; -webkit-backdrop-filter: ${filter} !important; }`
    }
    setDynCss(dyn)
  }

  function syncAntiScroll(on: boolean): void {
    const d = typeof document !== 'undefined' ? document : null
    const w = typeof window !== 'undefined' ? window : null
    if (d === null) return
    const scrollables = d.querySelectorAll('*')
    for (const el of scrollables) {
      try {
        const cs = w !== null && w.getComputedStyle !== undefined ? w.getComputedStyle(el) : null
        if (cs === null) continue
        if (cs.overflowY === 'auto' || cs.overflowY === 'scroll') {
          if (on) {
            (el as HTMLElement).setAttribute('data-vx-anti', (el as HTMLElement).style.scrollBehavior ?? '')
            ;(el as HTMLElement).style.scrollBehavior = 'auto'
          } else if (el.hasAttribute('data-vx-anti')) {
            ;(el as HTMLElement).style.scrollBehavior = el.getAttribute('data-vx-anti') === 'smooth' ? 'smooth' : ''
            el.removeAttribute('data-vx-anti')
          }
        }
      } catch { /* individual element failure is harmless */ }
    }
  }

  // A desktop shell page can load (and this client can boot) before the host
  // has finished registering the plugin routes: the first state read then
  // fails and, without a retry, the client would run — and any later saveCfg
  // would PERSIST — factory defaults over the user's stored configuration.
  const LOAD_RETRY_DELAYS = [1500, 3000, 6000]
  let loadCfgAttempt = 0
  let loadRetryTimer: ReturnType<typeof setTimeout> | null = null
  let greetTimer: ReturnType<typeof setTimeout> | null = null
  let disposed = false
  // Whether a state read has ever succeeded. A save built on unloaded
  // defaults would replace stored folders/prompts/stars with factory
  // empties, so saveCfg refuses to POST until this is true.
  let cfgLoaded = false
  async function loadCfg(): Promise<void> {
    if (disposed) return
    if (loadRetryTimer !== null) {
      clearTimeout(loadRetryTimer)
      loadRetryTimer = null
    }
    let failure: string | null = null
    try {
      const result = await apiStateGet()
      if (result.ok === true && result.data !== undefined) {
        const data = result.data
        if (data.cfg !== undefined && data.cfg !== null) {
          const cfg = { ...S.cfg, ...data.cfg }
          delete (cfg as Record<string, unknown>).clouds
          delete (cfg as Record<string, unknown>).wind
          // Keys removed from the config surface: an old state file may still
          // carry them, and a merge would re-persist them forever.
          delete (cfg as Record<string, unknown>).timeline
          delete (cfg as Record<string, unknown>).timelineLeft
          delete (cfg as Record<string, unknown>).starsOnly
          // The aurora preset was removed; treat a stored value as "no color".
          if (cfg.bg === 'aurora') cfg.bg = 'default'
          S.cfg = cfg
        }
        if (Array.isArray(data.folders)) S.folders = data.folders
        if (Array.isArray(data.prompts)) S.prompts = data.prompts
        if (data.stars !== undefined && data.stars !== null && typeof data.stars === 'object') S.stars = data.stars
        if (typeof data.apiKeyConfigured === 'boolean') S.apiKeyConfigured = data.apiKeyConfigured
        if (data.credentialStorage === 'system' || data.credentialStorage === 'legacy-state' || data.credentialStorage === 'environment' || data.credentialStorage === 'dsh' || data.credentialStorage === 'none') S.credentialStorage = data.credentialStorage
        if (data.usage !== undefined && data.usage !== null && typeof data.usage === 'object') S.usage = data.usage
        loadCfgAttempt = 0
        cfgLoaded = true
      } else if (result.ok !== true) {
        // A rejected state read used to be swallowed, which let a broken host
        // path read as "settings silently reset". Surface it.
        failure = result.error ?? '状态读取失败'
      }
    } catch (error) {
      failure = String((error as Error)?.message ?? error)
    }
    if (failure !== null) {
      apiDiagReport('loadCfg: ' + failure)
      if (loadCfgAttempt < LOAD_RETRY_DELAYS.length) {
        const delay = LOAD_RETRY_DELAYS[loadCfgAttempt]
        loadCfgAttempt++
        if (loadRetryTimer !== null) clearTimeout(loadRetryTimer)
        loadRetryTimer = setTimeout(() => {
          loadRetryTimer = null
          void loadCfg()
        }, delay)
      } else if (S.booted) {
        // Retries exhausted: now it is a real, user-visible failure.
        toast('配置读取失败：' + failure, 'error')
      }
    }
    if (disposed) return
    S.booted = true
    setS({})
    if (!S.greeted) {
      S.greeted = true
      if (greetTimer !== null) clearTimeout(greetTimer)
      greetTimer = setTimeout(() => {
        greetTimer = null
        if (disposed) return
        toast(failure !== null ? 'Custom 便利套件加载失败：' + failure : 'Custom 便利套件已就绪', failure !== null ? 'error' : 'info')
      }, 1200)
    }
  }

  function saveCfg(): void {
    if (disposed) return
    if (!cfgLoaded) {
      // The host can come up after the retry ladder has exhausted; saving
      // the factory snapshot then would wipe everything stored. Reload
      // instead of saving.
      toast('配置尚未读取完成，已重新加载，请重试', 'error')
      loadCfgAttempt = 0
      void loadCfg()
      return
    }
    const cfg = { ...S.cfg }
    delete (cfg as Record<string, unknown>).clouds
    delete (cfg as Record<string, unknown>).wind
    const keyDirty = S.apiKeyDirty
    const edit = { cfg, folders: S.folders, prompts: S.prompts, stars: S.stars, ...(keyDirty ? { apiKey: S.apiKey } : {}) }
    void apiStateSave(edit).then((result) => {
      if (result.ok !== true) {
        // Saving used to stay quiet unless an API key was involved, so a
        // rejected write looked like a toggle that "worked". Make it loud.
        const message = result.error ?? '设置保存失败'
        apiDiagReport('saveCfg: ' + message)
        toast(message, 'error')
        return
      }
      if (keyDirty && S.apiKeyDirty && S.apiKey === (edit.apiKey ?? '')) {
        setS({
          apiKeyDirty: false,
          apiKeyConfigured: result.apiKeyConfigured ?? S.apiKey.trim() !== '',
          credentialStorage: result.credentialStorage ?? S.credentialStorage,
        })
      }
    }).catch((error) => {
      const message = String((error as Error)?.message ?? error)
      apiDiagReport('saveCfg: ' + message)
      toast('设置保存失败：' + message, 'error')
    })
  }

  // ================= weather FX =================
  interface FxParticle {
    x: number
    y: number
    radius: number
    opacity: number
    speedY: number
    drift: number
    driftFreq: number
    phase: number
    length: number
    speed: number
    lineWidth: number
    canSplash: boolean
    size: number
    swayFreq: number
    spin: number
    wobble: number
    spriteIndex: number
  }
  const FX: { snow: FxParticle[]; rain: FxParticle[]; sakura: FxParticle[]; splashes: Array<{ x: number; y: number; vx: number; vy: number; life: number; decay: number; w: number; h: number }>; rainWind?: { dx: number; dy: number } } = { snow: [], rain: [], sakura: [], splashes: [] }
  const SAKURA_PALETTE = [
    'hsla(340, 45%, 90%, 0.8)', 'hsla(342, 50%, 91%, 0.8)', 'hsla(344, 55%, 92%, 0.8)', 'hsla(346, 60%, 93%, 0.8)',
    'hsla(348, 65%, 94%, 0.8)', 'hsla(350, 60%, 95%, 0.8)', 'hsla(352, 55%, 93%, 0.8)', 'hsla(348, 40%, 88%, 0.8)',
  ]
  /** 浅色背景变体：90% 亮度的淡粉在近白的调色板背景上会消失，
   * 换成更深的玫瑰粉保持可辨识度。 */
  const SAKURA_PALETTE_LIGHT = [
    'hsla(340, 60%, 72%, 0.9)', 'hsla(342, 64%, 70%, 0.9)', 'hsla(344, 66%, 68%, 0.9)', 'hsla(346, 68%, 66%, 0.9)',
    'hsla(348, 70%, 64%, 0.9)', 'hsla(350, 66%, 66%, 0.9)', 'hsla(352, 60%, 68%, 0.9)', 'hsla(348, 52%, 70%, 0.9)',
  ]
  const SAKURA_IMAGES: HTMLImageElement[] = []
  const SAKURA_IMAGES_LIGHT: HTMLImageElement[] = []

  function rand(a: number, b: number): number {
    return a + Math.random() * (b - a)
  }
  function tracePetal(g: CanvasRenderingContext2D, x: number, y: number, s: number, rot: number): void {
    g.save()
    g.translate(x, y)
    g.rotate(rot ?? 0)
    g.scale(s, s)
    g.beginPath()
    g.moveTo(0, -1)
    g.bezierCurveTo(0.85, -0.9, 0.8, 0.4, 0, 0.8)
    g.bezierCurveTo(-0.8, 0.4, -0.85, -0.9, 0, -1)
    g.closePath()
    g.restore()
  }
  function buildSakuraSpriteSet(palette: string[], target: HTMLImageElement[]): void {
    if (target.length > 0) return
    const d = typeof document !== 'undefined' ? document : null
    const cvs = d?.createElement('canvas')
    if (cvs === undefined || cvs === null) return
    cvs.width = 48
    cvs.height = 48
    const g = cvs.getContext('2d')
    if (g === null) return
    for (const color of palette) {
      g.clearRect(0, 0, 48, 48)
      g.fillStyle = color
      tracePetal(g, 24, 24, 10, 0)
      g.fill()
      try {
        const image = new Image()
        image.src = cvs.toDataURL()
        target.push(image)
      } catch { /* toDataURL 不可用；向量路径兜底 */ }
    }
  }
  function buildSakuraSprites(): void {
    buildSakuraSpriteSet(SAKURA_PALETTE, SAKURA_IMAGES)
    buildSakuraSpriteSet(SAKURA_PALETTE_LIGHT, SAKURA_IMAGES_LIGHT)
  }
  function initFx(weather: string, w: number, h: number): void {
    FX.snow = []
    FX.rain = []
    FX.sakura = []
    FX.splashes = []
    if (weather === 'snow') {
      const LAYERS = [
        { count: 100, radius: [0.15, 0.45], speed: [0.15, 0.4], opacity: [0.15, 0.35], drift: [0.05, 0.2] },
        { count: 80, radius: [0.5, 1.0], speed: [0.4, 1.0], opacity: [0.3, 0.6], drift: [0.15, 0.45] },
        { count: 60, radius: [1.2, 2.5], speed: [0.8, 1.6], opacity: [0.5, 0.8], drift: [0.25, 0.6] },
      ]
      for (const layer of LAYERS) {
        for (let i = 0; i < layer.count; i++) {
          FX.snow.push({ x: Math.random() * w, y: Math.random() * h, radius: rand(layer.radius[0], layer.radius[1]), opacity: rand(layer.opacity[0], layer.opacity[1]), speedY: rand(layer.speed[0], layer.speed[1]), drift: rand(layer.drift[0], layer.drift[1]), driftFreq: rand(0.0003, 0.0012), phase: Math.random() * Math.PI * 2 } as FxParticle)
        }
      }
      FX.snow.sort((a, b) => a.opacity - b.opacity)
    }
    if (weather === 'rain') {
      FX.rainWind = { dx: Math.sin(0.14), dy: Math.cos(0.14) }
      const LAYERS = [
        { count: 80, length: [6, 14], speed: [3, 6], opacity: [0.06, 0.14], width: [0.3, 0.6] },
        { count: 60, length: [14, 28], speed: [7, 13], opacity: [0.12, 0.25], width: [0.5, 1.0] },
        { count: 30, length: [26, 48], speed: [12, 20], opacity: [0.2, 0.38], width: [0.8, 1.5] },
      ]
      for (let li = 0; li < LAYERS.length; li++) {
        const layer = LAYERS[li]
        const canSplash = li >= 1
        for (let i = 0; i < layer.count; i++) {
          FX.rain.push({ x: Math.random() * (w + 100) - 50, y: Math.random() * h, length: rand(layer.length[0], layer.length[1]), speed: rand(layer.speed[0], layer.speed[1]), opacity: rand(layer.opacity[0], layer.opacity[1]), lineWidth: rand(layer.width[0], layer.width[1]), canSplash } as FxParticle)
        }
      }
    }
    if (weather === 'sakura') {
      buildSakuraSprites()
      const LAYERS = [
        { count: 40, size: [2.5, 4.5], speed: [0.1, 0.3], opacity: [0.1, 0.25], drift: [0.15, 0.4] },
        { count: 32, size: [4.5, 7.5], speed: [0.25, 0.55], opacity: [0.25, 0.5], drift: [0.35, 0.8] },
        { count: 16, size: [7.5, 11], speed: [0.4, 0.75], opacity: [0.4, 0.65], drift: [0.5, 1.0] },
      ]
      for (const layer of LAYERS) {
        for (let i = 0; i < layer.count; i++) {
          FX.sakura.push({
            x: Math.random() * w, y: Math.random() * h, size: rand(layer.size[0], layer.size[1]), opacity: rand(layer.opacity[0], layer.opacity[1]), speedY: rand(layer.speed[0], layer.speed[1]), drift: rand(layer.drift[0], layer.drift[1]), driftFreq: rand(0.0003, 0.001), swayFreq: rand(0.0004, 0.0014), phase: Math.random() * Math.PI * 2, spin: rand(-0.004, 0.004), wobble: rand(0.8, 1.2), spriteIndex: SAKURA_IMAGES.length > 0 ? Math.floor(Math.random() * SAKURA_IMAGES.length) : -1,
          } as FxParticle)
        }
      }
    }
  }
  function spawnSplash(x: number, y: number): void {
    if (FX.splashes.length >= 24) return
    const n = 2 + Math.floor(Math.random() * 4)
    for (let i = 0; i < n; i++) {
      FX.splashes.push({ x: x + rand(-5, 5), y: y - rand(0, 3), vx: rand(-0.9, 0.9), vy: rand(-1.6, -0.4), life: 1, decay: rand(0.02, 0.05), w: rand(0.6, 1.6), h: rand(0.4, 1.1) })
    }
  }
  function fxFrame(g: CanvasRenderingContext2D, cvs: HTMLCanvasElement, weather: string, time: number, light: boolean): void {
    const w = cvs.clientWidth || 0
    const h = cvs.clientHeight || 0
    if (w === 0 || h === 0) return
    if (cvs.width !== Math.round(w) || cvs.height !== Math.round(h)) {
      cvs.width = Math.round(w)
      cvs.height = Math.round(h)
      initFx(weather, w, h)
    }
    g.clearRect(0, 0, w, h)
    if (weather === 'snow') {
      let currentOpacity = -1
      for (const f of FX.snow) {
        f.y += f.speedY
        f.x += Math.sin(f.phase + time * f.driftFreq) * f.drift
        if (f.y > h + f.radius) { f.y = -f.radius; f.x = Math.random() * w }
        if (f.x > w + f.radius) f.x = -f.radius
        else if (f.x < -f.radius) f.x = w + f.radius
        // 浅色背景：纯白雪花换成冷调石板灰并抬高透明度下限——近白背景上
        // 15% 透明度的白色基本不可见。
        const q = Math.round((light ? Math.min(0.9, f.opacity + 0.15) : f.opacity) * 50) / 50
        if (q !== currentOpacity) { currentOpacity = q; g.fillStyle = light ? `rgba(125,146,170,${q})` : `rgba(255,255,255,${q})` }
        g.beginPath(); g.arc(f.x, f.y, f.radius, 0, Math.PI * 2); g.fill()
      }
    } else if (weather === 'rain') {
      const WIND = FX.rainWind ?? { dx: 0.14, dy: 0.99 }
      g.lineCap = 'round'
      let currentOpacity = -1
      let currentWidth = -1
      for (const d of FX.rain) {
        d.x += d.speed * WIND.dx
        d.y += d.speed * WIND.dy
        if (d.y > h + d.length) {
          if (d.canSplash && Math.random() < 0.35) spawnSplash(d.x, h - 1)
          d.y = -(d.length + Math.random() * h * 0.2)
          d.x = Math.random() * (w + 100) - 50
        }
        if (d.x > w + 50) d.x = -50
        const qo = Math.round((light ? Math.min(0.5, d.opacity + 0.08) : d.opacity) * 30) / 30
        if (qo !== currentOpacity) { currentOpacity = qo; g.strokeStyle = light ? `rgba(104,130,156,${qo})` : `rgba(180,200,220,${qo})` }
        const qw = Math.round(d.lineWidth * 4) / 4
        if (qw !== currentWidth) { currentWidth = qw; g.lineWidth = qw }
        g.beginPath(); g.moveTo(d.x, d.y); g.lineTo(d.x - d.length * WIND.dx, d.y - d.length * WIND.dy); g.stroke()
      }
      for (let i = FX.splashes.length - 1; i >= 0; i--) {
        const sp = FX.splashes[i]
        sp.x += sp.vx
        sp.y += sp.vy
        sp.vy += 0.06
        sp.life -= sp.decay
        if (sp.life <= 0) { FX.splashes.splice(i, 1); continue }
        g.save()
        g.globalAlpha = Math.max(0, sp.life)
        g.strokeStyle = light ? 'rgba(104,130,156,0.8)' : 'rgba(180,200,220,0.8)'
        g.lineWidth = 0.8
        g.beginPath(); g.ellipse(sp.x, sp.y, sp.w, sp.h, 0, 0, Math.PI * 2); g.stroke()
        g.restore()
      }
    } else if (weather === 'sakura') {
      const imgs = light ? SAKURA_IMAGES_LIGHT : SAKURA_IMAGES
      const alpha = (f: FxParticle): number => (light ? Math.min(1, f.opacity + 0.2) : f.opacity)
      for (const f of FX.sakura) {
        f.y += f.speedY
        f.x += Math.sin(f.phase + time * f.swayFreq) * f.drift
        if (f.y > h + f.size) { f.y = -f.size; f.x = Math.random() * w }
        if (f.x > w + f.size) f.x = -f.size
        else if (f.x < -f.size) f.x = w + f.size
        const rot = Math.sin(f.phase + time * f.swayFreq * 1.7) * 0.9 + time * f.spin
        const wob = 1 + 0.12 * Math.sin(f.phase * 2 + time * f.swayFreq * 2.3)
        const img = f.spriteIndex >= 0 ? imgs[f.spriteIndex] : undefined
        if (img !== undefined) {
          g.save()
          g.globalAlpha = alpha(f)
          g.translate(f.x, f.y)
          g.rotate(rot)
          g.scale((f.size * f.wobble * wob) / 18, (f.size * f.wobble) / 18)
          g.drawImage(img, -18, -18, 36, 36)
          g.restore()
        } else {
          g.save()
          g.globalAlpha = alpha(f)
          g.translate(f.x, f.y)
          g.rotate(rot)
          g.scale((f.size * f.wobble * wob) / 10, (f.size * f.wobble) / 10)
          g.fillStyle = light ? SAKURA_PALETTE_LIGHT[0] : SAKURA_PALETTE[0]
          tracePetal(g, 0, 0, 1, 0)
          g.fill()
          g.restore()
        }
      }
    }
  }
  function FxCanvas(): React.ReactElement {
    const { weather, dark } = useSSelector(
      (state) => ({ weather: state.cfg.weather ?? 'none', dark: state.dark === true }),
      shallowEqual,
    )
    const ref = React.useRef<HTMLCanvasElement | null>(null)
    /** 粒子配色跟随背景亮度：浅色主题需要更深的粒子颜色才可辨识。
     * ref 让 RAF 循环每帧读到最新值，主题/背景切换时无需重建粒子场。 */
    const lightRef = React.useRef(!dark)
    React.useEffect(() => { lightRef.current = !dark }, [dark])
    React.useEffect(() => {
      const cvs = ref.current
      if (cvs === null) return
      const g = cvs.getContext('2d')
      if (g === null) return
      const w = cvs.clientWidth || 0
      const h = cvs.clientHeight || 0
      initFx(weather, w, h)
      let raf = 0
      const t0 = Date.now()
      const loop = (): void => {
        if (weather === 'none') {
          // Baseline behaviour: switching to "off" wipes the last painted frame
          // instead of leaving it frozen on the canvas.
          try { g.clearRect(0, 0, cvs.width, cvs.height) } catch { /* context lost */ }
          return // no particles scheduled: stay idle
        }
        raf = requestAnimationFrame(loop)
        fxFrame(g, cvs, weather, Date.now() - t0, lightRef.current)
      }
      loop()
      return () => { try { cancelAnimationFrame(raf) } catch { /* already cancelled */ } }
    }, [weather])
    return React.createElement('canvas', { ref, className: 'vx-fx' })
  }

  // ================= timeline data (turn chips + search reveal) =================
  let turnsRequestSerial = 0
  const diagAtByKey = new Map<string, number>()
  function diagThrottled(message: string): void {
    // Throttle per diagnostic kind — but a kind is not a reading. Keying on the
    // first word let an unchanged reading swallow a changed one five seconds
    // later, which once read as "broken" when it was a transition nobody could
    // see. Twenty-four characters carry the counts of every throttled line we
    // emit, so identical repeats dedup while a change of reading gets through.
    const key = message.slice(0, 24)
    const now = Date.now()
    const at = diagAtByKey.get(key)
    if (at !== undefined && now - at < 5000) return
    // Session-scoped keys make this map grow with every session viewed; a
    // bounded ring is enough for a throttle table.
    if (diagAtByKey.size > 200) diagAtByKey.clear()
    diagAtByKey.set(key, now)
    reportDiag(message)
  }
  async function fetchTurns(sessionId: string): Promise<void> {
    const requestSerial = ++turnsRequestSerial
    try {
      const result = await apiTimelineGet(sessionId)
      // A slower fetch for a previously open session must not paint its turns
      // onto the newly opened one's rows.
      // The serial also protects the same session from an older polling result
      // arriving after a newer one.
      if (sessionId !== S.sessionId || requestSerial !== turnsRequestSerial || disposed) return
      if (result.ok === true) {
        const items = result.items ?? []
        const previous = S.turns !== null && S.turns.sessionId === sessionId ? S.turns : null
        // Reuse unchanged item objects: every turn-tail row subscribes to its
        // own item, so a poll that only appends one turn must not re-render
        // the other 399.
        const diff = reuseTimelineItems(previous?.items ?? null, previous !== null ? S.turnsBySeq : null, items)
        if (!diff.changed) return
        S.turns = { sessionId, items: diff.items }
        S.turnsBySeq = diff.bySeq
        setS({ turns: S.turns, turnsBySeq: diff.bySeq })
        diagThrottled('timeline ' + items.length + ' items ' + sessionId.slice(0, 24))
      } else {
        diagThrottled('timeline failed: ' + String(result.error ?? 'unknown'))
      }
    } catch (error) {
      diagThrottled('timeline fetch error: ' + String((error as Error)?.message ?? error))
    }
  }
  function findScrollerFrom(el: HTMLElement): HTMLElement | null {
    const w = typeof window !== 'undefined' ? window : null
    if (w === null) return null
    let node = el.parentElement
    while (node !== null) {
      try {
        const cs = w.getComputedStyle(node)
        if (cs.overflowY === 'auto' || cs.overflowY === 'scroll') return node
      } catch { /* style read failed */ }
      node = node.parentElement
    }
    return null
  }
  /** Resolve the real chat scrollport: query the shell's
   * semantic attribute directly instead of walking up from turnTail anchors
   * (the turnTail chain seat may be taken by another plugin, leaving no
   * anchors at all). ChatView itself resolves the same attribute, so this is
   * the shell's stable contract; the anchor walk stays only as a fallback. */
  function resolveScroller(): HTMLElement | null {
    const d = typeof document !== 'undefined' ? document : null
    if (d === null) return null
    try {
      const host = d.querySelector('[data-conversation-scroll]')
      if (host instanceof HTMLElement && host.isConnected) return host
    } catch { /* selector unsupported */ }
    for (const anchor of S.anchors.values()) {
      if (anchor === undefined || anchor.el === undefined) continue
      try {
        const host = anchor.el.closest('[data-conversation-scroll]') as HTMLElement | null
        if (host !== null) return host
      } catch { /* selector unsupported */ }
      const found = findScrollerFrom(anchor.el)
      if (found !== null) return found
    }
    return null
  }
  /** Scroll the rendered message row for `seq` to the viewport center. The
   * element comes from the turnTail anchor map (our own chips register it);
   * the scrollport is resolved at call time from the shell's semantic
   * attribute, with scrollIntoView as the fallback. */
  function scrollToSeq(seq: number): void {
    const el = S.anchors.get(seq)?.el ?? null
    if (el === null) {
      toast('该消息尚未渲染，请稍后重试', 'error')
      return
    }
    const scroller = resolveScroller()
    let done = false
    if (scroller !== null) {
      try {
        const er = el.getBoundingClientRect()
        const sr = scroller.getBoundingClientRect()
        const floor = Math.max(0, (scroller.scrollHeight ?? 0) - (scroller.clientHeight ?? 0))
        const target = (scroller.scrollTop ?? 0) + (er.top + er.height / 2) - (sr.top + sr.height / 2)
        scroller.scrollTop = Math.max(0, Math.min(floor, target))
        done = true
      } catch { /* rect read failed */ }
    }
    if (!done) {
      try { el.scrollIntoView({ behavior: 'auto', block: 'center' }) } catch { try { el.scrollIntoView(true) } catch { /* scroll unavailable */ } }
    }
  }
  function extractLatex(text: string): string[] {
    const out: string[] = []
    let i = 0
    const n = text.length
    while (i < n) {
      const a = text.indexOf('\\[', i)
      const b = text.indexOf('\\(', i)
      const c = text.indexOf('$$', i)
      let start = -1
      let endTok = ''
      if (a >= 0 && (b < 0 || a < b) && (c < 0 || a < c)) { start = a; endTok = '\\]' }
      else if (b >= 0 && (c < 0 || b < c)) { start = b; endTok = '\\)' }
      else if (c >= 0) { start = c; endTok = '$$' }
      if (start < 0) break
      const end = text.indexOf(endTok, start + 2)
      if (end < 0) { i = start + 2; continue }
      out.push(text.slice(start + 2, end).trim())
      i = end + endTok.length
    }
    const re2 = /\$([^$\n]{1,600}?)\$/g
    let m: RegExpExecArray | null
    while ((m = re2.exec(text)) !== null) out.push(m[1].trim())
    return out
  }
  function extractMathml(text: string): string[] {
    const out: string[] = []
    const lower = text.toLowerCase()
    let i = 0
    while (true) {
      const s = lower.indexOf('<math', i)
      if (s < 0) break
      const e = lower.indexOf('</math>', s)
      if (e < 0) break
      out.push(text.slice(s, e + 7))
      i = e + 7
    }
    return out
  }
  async function copyText(text: string): Promise<boolean> {
    try {
      const d = typeof document !== 'undefined' ? document : null
      if (d !== null && navigator.clipboard !== undefined && typeof navigator.clipboard.writeText === 'function') {
        await navigator.clipboard.writeText(text)
        return true
      }
      if (d === null) return false
      const ta = d.createElement('textarea')
      ta.value = text
      ta.style.position = 'fixed'
      ta.style.opacity = '0'
      d.body.appendChild(ta)
      ta.select()
      const ok = d.execCommand('copy')
      ta.remove()
      return ok
    } catch { return false }
  }
  async function copyLatexOf(item: TimelineItem): Promise<void> {
    const codes = extractLatex(item.text)
    if (codes.length === 0) { toast('未找到 LaTeX 公式', 'error'); return }
    const ok = await copyText(codes.join('\n\n'))
    toast(ok ? `已复制 ${codes.length} 个 LaTeX 公式` : '复制失败', ok ? 'info' : 'error')
  }
  async function copyMathmlOf(item: TimelineItem): Promise<void> {
    const codes = extractMathml(item.text)
    if (codes.length === 0) { toast('未找到 MathML', 'error'); return }
    const ok = await copyText(codes.join('\n\n'))
    toast(ok ? `已复制 ${codes.length} 个 MathML（可粘贴到 Word）` : '复制失败', ok ? 'info' : 'error')
  }
  let mermaidState: { status: 'idle' | 'loading' | 'ready' | 'failed'; error?: string } = { status: 'idle' }
  async function ensureMermaid(): Promise<boolean> {
    if (mermaidState.status === 'ready') return true
    if (mermaidState.status === 'loading') {
      while (mermaidState.status === 'loading') await new Promise((resolve) => setTimeout(resolve, 120))
      return mermaidState.status === 'ready'
    }
    mermaidState = { status: 'loading' }
    // A stalled script load (a network black hole where neither onload nor
    // onerror ever fires) would park every later caller in the poll loop
    // forever — each new block during streaming adds another 120 ms waiter.
    // The watchdog fails the load after 30 s and drops the script tag so a
    // retry can re-add it.
    const d0 = typeof document !== 'undefined' ? document : null
    const watchdog = setTimeout(() => {
      if (mermaidState.status !== 'loading') return
      mermaidState = { status: 'failed', error: '脚本加载超时' }
      try {
        if (d0 !== null) for (const el of d0.querySelectorAll(`script[src="${MERMAID_SCRIPT_PATH}"]`)) el.remove()
      } catch { /* selector/query failed; the tag is inert without the state */ }
    }, 30000)
    try {
      const result = await apiMermaidFetch()
      if (result.ok === true) {
        await new Promise<void>((resolve, reject) => {
          const d = typeof document !== 'undefined' ? document : null
          if (d === null) { reject(new Error('no document')); return }
          const script = d.createElement('script')
          script.src = MERMAID_SCRIPT_PATH
          script.onload = () => resolve()
          script.onerror = () => {
            // Drop the failed tag so a retry does not accumulate dead scripts.
            script.remove()
            reject(new Error('script load failed'))
          }
          d.head.appendChild(script)
        })
        mermaidState = { status: 'ready' }
        // Blocks that failed while the engine was unavailable carry a fail
        // marker; now that it is ready, let them render on the next scan.
        if (d0 !== null) {
          for (const el of Array.from(d0.querySelectorAll<HTMLElement>('[data-vx-mmd-fail]'))) delete el.dataset.vxMmdFail
          if (S.cfg.mermaid === true) void scanMermaidBlocks(S.dark)
        }
        return true
      }
      mermaidState = { status: 'failed', error: result.error ?? 'unknown' }
      return false
    } catch (error) {
      mermaidState = { status: 'failed', error: String((error as Error)?.message ?? error) }
      return false
    } finally {
      clearTimeout(watchdog)
    }
  }
  async function renderMermaid(code: string, dark = false): Promise<{ ok: true; svg: string } | { ok: false; error: string }> {
    try {
      const w = typeof window !== 'undefined' ? window : null
      const mermaid = (w as unknown as { mermaid?: { initialize(opts: Record<string, unknown>): void; render(id: string, code: string): Promise<string | { svg: string }> } }).mermaid
      if (mermaid === undefined) return { ok: false, error: '引擎未就绪' }
      mermaid.initialize({ startOnLoad: false, theme: dark ? 'dark' : 'default', securityLevel: 'strict' })
      const id = 'vx-mmd-' + Date.now() + Math.floor(Math.random() * 9999)
      const out = await mermaid.render(id, code)
      const svg = typeof out === 'string' ? out : (out?.svg ?? '')
      if (svg === '') return { ok: false, error: '引擎未返回 SVG' }
      return { ok: true, svg }
    } catch (error) {
      return { ok: false, error: String((error as Error)?.message ?? error) }
    }
  }
  function extractMermaid(text: string): string[] {
    const out: string[] = []
    const re = /```mermaid\s*\n([\s\S]*?)```/gi
    let m: RegExpExecArray | null
    while ((m = re.exec(text)) !== null) out.push(m[1].trim())
    return out
  }
  function openMermaidOf(item: TimelineItem): void {
    const codes = extractMermaid(item.text)
    if (codes.length === 0) { toast('未找到 Mermaid 代码块', 'error'); return }
    setS({ mermaidModal: { title: item.text.slice(0, 40), codes, index: 0 } })
  }

  // ================= mermaid in-place (chat DOM) =================
  /** Blocks with a render already in flight (WeakSet: dead blocks drop out). */
  const mmdInflight = new WeakSet<HTMLElement>()
  /** Previous scan theme; a flip invalidates rendered-SVG memoization. */
  let mmdLastDark: boolean | null = null

  /** The banner's language label: `.md-code-block > bannerWrap > banner >
   * infostring` is the GUI CodeBlock's stable shape (its CSS classes are
   * hashed, the structure is not). */
  function blockInfostring(block: HTMLElement): string | null {
    const info = block.querySelector(':scope > div:first-child > div:first-child > div:first-child')
    return info !== null ? info.textContent ?? '' : null
  }

  /** Raw fence text: the GUI keeps unknown languages (mermaid among them) on
   * the plain `<pre><code>` path, so `pre` always carries the source. */
  function blockCodeText(block: HTMLElement): string | null {
    const pre = block.querySelector('pre')
    return pre !== null ? pre.textContent ?? '' : null
  }

  /** Insert/refresh the diagram wrapper before one code block. Never moves
   * GUI-owned nodes — React keeps reconciling its tree; the block is only
   * visually swapped with the diagram stage via display. */
  async function renderInPlace(block: HTMLElement, code: string, dark: boolean): Promise<void> {
    const key = mermaidCodeKey(code)
    const existingWrap = block.previousElementSibling
    if (block.dataset.vxMmd === key && existingWrap !== null && existingWrap.classList.contains('vx-mmd-wrap')) return
    const ready = await ensureMermaid()
    if (!ready) {
      // Engine unreachable: keep the code visible; a later scan retries once
      // the engine becomes ready (ensureMermaid clears the fail marker then).
      block.dataset.vxMmdFail = key
      return
    }
    const r = await renderMermaid(code, dark)
    if (!r.ok) { block.dataset.vxMmdFail = key; return }
    delete block.dataset.vxMmdFail
    const d = typeof document !== 'undefined' ? document : null
    if (d === null) return
    // Re-read the sibling after the awaits: React may have re-rendered the
    // conversation and detached the wrapper observed before ensureMermaid.
    let wrap = block.previousElementSibling as HTMLElement | null
    if (wrap === null || !wrap.classList.contains('vx-mmd-wrap')) {
      wrap = d.createElement('div')
      wrap.className = 'vx-mmd-wrap'
      block.parentElement?.insertBefore(wrap, block)
      const bar = d.createElement('div')
      bar.className = 'vx-mmd-bar'
      const diagramBtn = d.createElement('button')
      diagramBtn.type = 'button'
      diagramBtn.className = 'vx-mmd-btn active'
      diagramBtn.textContent = '图表'
      const codeBtn = d.createElement('button')
      codeBtn.type = 'button'
      codeBtn.className = 'vx-mmd-btn'
      codeBtn.textContent = '代码'
      const live = d.createElement('a')
      live.className = 'vx-mmd-live'
      live.target = '_blank'
      live.rel = 'noopener noreferrer'
      live.textContent = 'mermaid.live'
      void mermaidLiveUrl(code).then((url) => { live.href = url }).catch(() => {})
      bar.append(diagramBtn, codeBtn, live)
      const stage = d.createElement('div')
      stage.className = 'vx-mmd-stage'
      wrap.append(bar, stage)
      const showDiagram = (): void => {
        stage.style.display = ''
        block.style.display = 'none'
        diagramBtn.classList.add('active')
        codeBtn.classList.remove('active')
      }
      const showCode = (): void => {
        stage.style.display = 'none'
        block.style.display = ''
        diagramBtn.classList.remove('active')
        codeBtn.classList.add('active')
      }
      diagramBtn.addEventListener('click', showDiagram)
      codeBtn.addEventListener('click', showCode)
      showDiagram()
    }
    const stage = wrap.querySelector('.vx-mmd-stage')
    if (stage === null) return
    stage.innerHTML = r.svg
    block.dataset.vxMmd = key
  }

  /** Scan every chat code block and render the mermaid ones in place. */
  async function scanMermaidBlocks(dark: boolean): Promise<void> {
    const d = typeof document !== 'undefined' ? document : null
    if (d === null) return
    // Drop wrappers whose code block left the DOM (history switch / unmount).
    for (const wrap of Array.from(d.querySelectorAll<HTMLElement>('.vx-mmd-wrap'))) {
      const next = wrap.nextElementSibling
      if (next === null || !next.classList.contains('md-code-block')) wrap.remove()
    }
    for (const block of Array.from(d.querySelectorAll<HTMLElement>('.md-code-block'))) {
      if (mmdInflight.has(block)) continue
      const codeRaw = blockCodeText(block)
      if (codeRaw === null) continue
      const code = normalizeMermaidText(codeRaw).trim()
      if (code === '') continue
      const key = mermaidCodeKey(code)
      const info = blockInfostring(block)
      const definite = info !== null && info.trim().toLowerCase() === 'mermaid'
      if (definite) {
        // Settled ```mermaid fence: only guard against a lone keyword line.
        if (code.split('\n').filter((l) => l.trim() !== '').length < 2) continue
      } else {
        // Blank (streaming) or generic banner: content heuristics decide, so a
        // streaming mindmap previews as soon as it is complete enough and a
        // named foreign language (python etc.) is never touched.
        if (!isGenericInfostring(info)) continue
        if (!isMermaidCode(codeRaw)) continue
      }
      if (block.dataset.vxMmd === key || block.dataset.vxMmdFail === key) continue
      mmdInflight.add(block)
      try {
        await renderInPlace(block, code, dark)
      } finally {
        mmdInflight.delete(block)
      }
    }
  }

  /** Undo in-place rendering (feature toggled off): remove wrappers, unhide
   * code blocks. Diagram DOM is plugin-owned, so removal is safe. */
  function restoreMermaidBlocks(): void {
    const d = typeof document !== 'undefined' ? document : null
    if (d === null) return
    for (const wrap of Array.from(d.querySelectorAll<HTMLElement>('.vx-mmd-wrap'))) {
      const next = wrap.nextElementSibling as HTMLElement | null
      if (next !== null && next.classList.contains('md-code-block')) next.style.display = ''
      wrap.remove()
    }
    for (const block of Array.from(d.querySelectorAll<HTMLElement>('.md-code-block'))) {
      delete block.dataset.vxMmd
      delete block.dataset.vxMmdFail
    }
  }

  // The host's outbound balance call shares the machine's network path with
  // TLS-intercepting proxies and security suites, so a failure is often
  // transient — retry on a short backoff before the pill settles on the last
  // error (the 60s poll in HeaderBalance keeps healing after that).
  let balanceRetryTimer: ReturnType<typeof setTimeout> | null = null
  let balanceRetries = 0
  async function refreshBalance(): Promise<void> {
    if (balanceRetryTimer !== null) { clearTimeout(balanceRetryTimer); balanceRetryTimer = null }
    try {
      const result = await apiBalanceGet()
      S.balance = result as unknown as Record<string, unknown>
      S.apiKeyConfigured = result.keyConfigured === true
      balanceRetries = 0
      // The route also carries the host's live usage ledger; fold today's row
      // in so the 「今日 N 次」 badge refreshes together with the figure.
      const usageToday = result.usageToday
      if (usageToday !== undefined && usageToday !== null && typeof usageToday === 'object') {
        S.usage = { ...S.usage }
        S.usage[dayKey()] = usageToday as Store['usage'][string]
        setS({ balance: S.balance, usage: S.usage, apiKeyConfigured: S.apiKeyConfigured })
      } else {
        setS({ balance: S.balance, apiKeyConfigured: S.apiKeyConfigured })
      }
    } catch (error) {
      // Keep the configured flag: a route-level failure with a key present is
      // "额度" (retry-worthy), not "no key" (which would read as an estimate).
      S.balance = { ok: false, keyConfigured: S.apiKeyConfigured === true, error: String((error as Error)?.message ?? error) }
      setS({ balance: S.balance })
    }
    const failed = (S.balance as { ok?: boolean }).ok === false
    const keyPresent = (S.balance as { keyConfigured?: boolean }).keyConfigured === true
    if (failed && keyPresent && balanceRetries < 3) {
      balanceRetries++
      balanceRetryTimer = setTimeout(() => { balanceRetryTimer = null; void refreshBalance() }, balanceRetries === 1 ? 8000 : 30000)
    }
  }
  async function refreshUsageScan(): Promise<void> {
    try {
      const result = await apiUsageScan()
      if (result.ok === true) {
        S.usage = { ...S.usage }
        const scanDay = result.day || dayKey()
        S.usage[scanDay] = result.usageToday as Store['usage'][string]
        setS({ usage: S.usage })
        toast(`已扫描 ${scanDay} 会话日志（${String(result.scannedSessions)} 个活跃会话）`, 'info')
      } else {
        toast(result.error ?? '扫描失败', 'error')
      }
    } catch (error) {
      toast('扫描失败: ' + String((error as Error)?.message ?? error), 'error')
    }
  }
  function downloadText(content: string, fileName: string, mime: string): void {
    const d = typeof document !== 'undefined' ? document : null
    if (d === null) throw new Error('no document')
    const url = URL.createObjectURL(new Blob([content], { type: mime }))
    const a = d.createElement('a')
    a.href = url
    a.download = fileName
    d.body.appendChild(a)
    a.click()
    a.remove()
    setTimeout(() => { try { URL.revokeObjectURL(url) } catch { /* revoked already */ } }, 30000)
  }

  function insertPrompt(prompt: PromptItem): void {
    const vars = promptVariables(prompt.text)
    if (vars.length > 0) {
      const values: Record<string, string> = {}
      for (const name of vars) values[name] = ''
      setS({ templatePrompt: prompt, templateValues: values, promptOpen: null })
      return
    }
    const ok = S.insertDraft !== null ? S.insertDraft(prompt.text, false) : false
    if (!ok) { toast('请在会话输入框中重试', 'error'); return }
    S.prompts = S.prompts.map((item) => item.id === prompt.id ? { ...item, useCount: (item.useCount ?? 0) + 1, lastUsedAt: Date.now() } : item)
    setS({ prompts: S.prompts, promptOpen: null })
    saveCfg()
    toast('已插入提示词: ' + prompt.name, 'info')
  }

  function runExport(format: string): void {
    if (S.sessionId === null) { toast('当前没有打开的会话', 'error'); return }
    setS({ exporting: true })
    void apiExportRun(S.sessionId, format).then((result) => {
      if (result.ok !== true) {
        toast(result.error ?? '导出失败', 'error')
        return
      }
      try {
        downloadText(result.content, result.fileName, result.mime)
        toast('已导出 ' + result.fileName, 'info')
      } catch (error) {
        toast('导出失败: ' + String((error as Error)?.message ?? error), 'error')
      }
    }).catch((error) => toast('导出失败: ' + String((error as Error)?.message ?? error), 'error')).finally(() => setS({ exporting: false }))
  }
  function findFolder(arr: FolderNode[], id: string): FolderNode | null {
    for (const f of arr) {
      if (f.id === id) return f
      const child = findFolder(f.children ?? [], id)
      if (child !== null) return child
    }
    return null
  }
  function folderCount(node: FolderNode): number {
    let n = (node.sessionIds ?? []).length + (node.workspaceIds ?? []).length
    for (const child of node.children ?? []) n += folderCount(child)
    return n
  }
  /**
   * The `ctx.remote` namespaces this plugin calls, read fail-soft so a profile
   * without the Session Remote degrades to a toast instead of throwing.
   */
  function sessionRemote(): SessionRemoteLike | undefined {
    const session = (C.get('remote') as { session?: Record<string, unknown> } | undefined)?.session
    if (session === undefined) return undefined
    if (typeof session.fork !== 'function' || typeof session.search !== 'function') return undefined
    return session as unknown as SessionRemoteLike
  }

  /** Render a Remote failure envelope as one readable line. */
  function remoteErrorMessage(error: unknown, fallback: string): string {
    if (typeof error === 'string') return error
    if (error !== null && typeof error === 'object') {
      const code = String((error as { code?: unknown }).code ?? '')
      const message = String((error as { message?: unknown }).message ?? '')
      const joined = [code, message].filter((part) => part !== '').join(': ')
      if (joined !== '') return joined
    }
    return fallback
  }

  /**
   * Navigation moved to the Workspace browser's `uiWorkspace` service: the
   * Session Controller no longer opens or selects a Session for a caller.
   */
  function workspaceNav(): WorkspaceNavLike | undefined {
    const nav = C.get('uiWorkspace') as { openSession?: unknown; connectWorkspace?: unknown } | undefined
    if (nav === undefined || typeof nav.openSession !== 'function' || typeof nav.connectWorkspace !== 'function') return undefined
    return nav as WorkspaceNavLike
  }
  async function openWorkspaceItem(id: string): Promise<void> {
    const nav = workspaceNav()
    if (nav === undefined) { toast('工作区导航服务不可用', 'error'); return }
    try {
      const sid = await nav.connectWorkspace(id)
      nav.openSession(sid)
      toast('已打开项目', 'info')
    } catch (error) {
      toast('打开项目失败: ' + String((error as Error)?.message ?? error), 'error')
    }
  }
  function openSessionItem(id: string): void {
    const nav = workspaceNav()
    if (nav === undefined) { toast('会话导航服务不可用', 'error'); return }
    try { nav.openSession(id) } catch (error) { toast('打开会话失败: ' + String((error as Error)?.message ?? error), 'error') }
  }

  // ================= components =================
  function Toggle(props: { label: string; checked: boolean; onChange: (v: boolean) => void; hint?: string }): React.ReactElement {
    return React.createElement('label', { className: 'vx-toggle-row' },
      React.createElement('span', null, props.label),
      React.createElement('input', { type: 'checkbox', checked: props.checked === true, onChange: (e: React.ChangeEvent<HTMLInputElement>) => { props.onChange(e.target.checked); saveCfg() } }),
      props.hint !== undefined ? React.createElement('span', { className: 'vx-muted' }, props.hint) : null,
    )
  }

  /** `sidebar.footer.action` hands the column state down. In the 56px rail the
   * two-character label wrapped into a vertical stack beside the icon, so the
   * text renders only while the sidebar is wide; a host that passes no `wide`
   * keeps the label. */
  function FolderSidebarButton(props: { wide?: boolean }): React.ReactElement {
    return React.createElement('button', {
      className: 'vx-foot-btn',
      title: '项目文件夹',
      onClick: () => setS({ foldersOpen: !S.foldersOpen, panelOpen: false, promptOpen: null, balanceOpen: false }),
    }, React.createElement(Icon, { n: 'folder', size: 15 }), props.wide === false ? null : React.createElement('span', { className: 'vx-foot-label' }, '项目'))
  }

  function HeaderPanelButton(props: SessionScopedProps): React.ReactElement {
    useViewedSession(props)
    return React.createElement('button', {
      className: 'vx-header-btn',
      title: '个性化中心',
      onClick: () => setS({ panelOpen: !S.panelOpen, foldersOpen: false, promptOpen: null, balanceOpen: false }),
    }, React.createElement(Icon, { n: 'sliders', size: 13 }), React.createElement('span', null, '个性化'))
  }

  function PromptQuickButton(props: SessionScopedProps): React.ReactElement {
    useViewedSession(props)
    return React.createElement('button', {
      className: 'vx-header-btn',
      title: '快速调用提示词',
      onClick: (e: React.MouseEvent<HTMLButtonElement>) => {
        // Same contract as the other header surfaces: click toggles, and
        // opening one closes the others.
        const open = S.promptOpen !== null
        const r = e.currentTarget.getBoundingClientRect()
        setS({ promptOpen: open ? null : { x: Math.max(8, r.left), y: r.bottom + 6 }, promptQuery: '', panelOpen: false, foldersOpen: false, balanceOpen: false })
      },
    }, React.createElement(Icon, { n: 'zap', size: 13 }), React.createElement('span', null, '提示词'))
  }

  function PromptPopover(): React.ReactElement | null {
    const s = useS()
    if (s.promptOpen === null) return null
    const p = s.promptOpen
    const q = (s.promptQuery ?? '').toLowerCase()
    const list = s.prompts.filter((x) => q === '' || String(x.name ?? '').toLowerCase().includes(q) || String(x.text ?? '').toLowerCase().includes(q) || (x.tags ?? []).some((tag) => tag.toLowerCase().includes(q)))
      .sort((a, b) => Number(b.favorite === true) - Number(a.favorite === true) || (b.lastUsedAt ?? 0) - (a.lastUsedAt ?? 0))
    return React.createElement('div', { className: 'vx-glass vx-prompt-pop', style: { left: p.x, top: p.y } },
      React.createElement('div', { className: 'vx-pop-head' },
        React.createElement('span', null, '提示词库'),
        React.createElement('button', { className: 'vx-chip', title: '关闭', onClick: () => setS({ promptOpen: null }) }, React.createElement(Icon, { n: 'x', size: 12 })),
      ),
      React.createElement('div', { className: 'vx-row vx-pad-sm' },
        React.createElement(Icon, { n: 'search', size: 13 }),
        React.createElement('input', { className: 'vx-input', placeholder: '搜索提示词…', value: s.promptQuery, onChange: (e: React.ChangeEvent<HTMLInputElement>) => setS({ promptQuery: e.target.value }) }),
      ),
      React.createElement('div', { className: 'vx-list' },
        list.length > 0
          ? list.map((x) => React.createElement('button', {
            key: x.id,
            className: 'vx-list-item',
            title: x.text,
            onClick: () => insertPrompt(x),
          },
          React.createElement('div', { className: 'vx-prompt-title' }, x.name),
          React.createElement('div', { className: 'vx-prompt-body' }, x.text)))
          : React.createElement('div', { className: 'vx-muted vx-pad-sm' }, '暂无匹配提示词'),
      ),
    )
  }

  function HeaderBalance(props: SessionScopedProps): React.ReactElement {
    useViewedSession(props)
    const s = useS()
    const b = s.balance
    // Initial fetch plus a refresh every minute, so the balance figure and the
    // today-usage badge stay current without pressing 刷新.
    React.useEffect(() => {
      if (S.balance === null) void refreshBalance()
      const timer = setInterval(() => { void refreshBalance() }, 60_000)
      return () => { clearInterval(timer) }
    }, [])
    const usageToday = s.usage[dayKey()] ?? {}
    const calls = Object.keys(usageToday).reduce((n, k) => n + (usageToday[k].calls ?? 0), 0)
    const estimate = Object.entries(usageToday).reduce((sum, [model, row]) => sum + estimateUsageCostCny(row, model), 0)
    const bal = (b?.ok === true && b.balance !== null && b.balance !== undefined)
      ? b.balance as { currency?: string, total?: string }
      : null
    const keyConfigured = b?.ok === false && (b as { keyConfigured?: boolean }).keyConfigured === true
    // With a working key the real balance shows as before; without one the
    // pill falls back to the local cost estimate (today's tokens priced from
    // the official tariff — no key, no network). '额度' keeps meaning "a key
    // exists but the upstream call failed".
    const balance = bal !== null
      ? ((bal.currency ?? 'CNY') === 'CNY' ? '¥' + (bal.total ?? '') : `${bal.total ?? ''} ${bal.currency ?? ''}`)
      : (keyConfigured ? '额度' : b === null ? '额度…' : `≈¥${estimate.toFixed(2)}`)
    const estimateTitle = `按本机 token 用量与官方价目表折算的估算值（${DEEPSEEK_PRICING_CHECKED_ON} 核对），非账号账单；配置 API Key 后显示真实余额`
    const balanceError = keyConfigured && b?.ok === false ? String((b as { error?: unknown }).error ?? '未知错误') : null
    const pillTitle = bal !== null ? undefined
      : balanceError !== null ? `余额查询失败：${balanceError}（失败后会自动重试，也可在面板中手动刷新）`
      : b === null ? undefined
      : estimateTitle
    // Same contract as the other header surfaces: click toggles, hover does
    // nothing, and opening this closes the others.
    const open = s.balanceOpen === true
    return React.createElement('span', { className: 'vx-balance-wrap' },
      React.createElement('span', {
        className: 'vx-balance-text' + (open ? ' vx-balance-open' : ''),
        title: open ? '再次点击收起面板' : '点击打开面板',
        onClick: () => setS({ balanceOpen: !open, panelOpen: false, promptOpen: null, foldersOpen: false }),
      },
        React.createElement(Icon, { n: 'wallet', size: 13 }),
        React.createElement('span', { title: pillTitle }, balance),
        calls > 0 ? React.createElement('span', { className: 'vx-balance-today' }, `今日 ${calls} 次`) : null,
      ),
      open
        ? React.createElement('div', { className: 'vx-glass vx-balance-hover' },
          React.createElement(BalancePanelContent, null),
        )
        : null,
    )
  }

  function UsageTable(): React.ReactElement {
    const s = useS()
    const day = s.usage[dayKey()] ?? {}
    const models = Object.keys(day)
    if (models.length === 0) return React.createElement('div', { className: 'vx-muted' }, '今日暂无 token 用量记录')
    const rows = models.map((model) => ({ model, row: day[model], breakdown: usageCostBreakdown(day[model], model) }))
    const allSplitsKnown = rows.every((item) => item.breakdown.exact)
    const totalPeakTokens = rows.reduce((sum, item) => sum + item.breakdown.peakTokens, 0)
    const totalOffPeakTokens = rows.reduce((sum, item) => sum + item.breakdown.offPeakTokens, 0)
    const totalPeakCost = rows.reduce((sum, item) => sum + item.breakdown.peakCostCny, 0)
    const totalOffPeakCost = rows.reduce((sum, item) => sum + item.breakdown.offPeakCostCny, 0)
    return React.createElement('div', null,
      React.createElement('table', { className: 'vx-table' },
        React.createElement('thead', null, React.createElement('tr', null,
          React.createElement('th', null, '模型'), React.createElement('th', null, '输入'), React.createElement('th', null, '缓存'), React.createElement('th', null, '输出'), React.createElement('th', null, '调用'), React.createElement('th', null, '费用 ¥'),
        )),
        React.createElement('tbody', null, rows.map(({ model, row, breakdown }) => {
          return React.createElement('tr', { key: model },
            React.createElement('td', null, model),
            React.createElement('td', null, row.in ?? 0),
            React.createElement('td', null, row.cacheIn ?? 0),
            React.createElement('td', null, row.out ?? 0),
            React.createElement('td', null, row.calls ?? 0),
            React.createElement('td', { title: breakdown.exact ? `峰 ¥${breakdown.peakCostCny.toFixed(4)} · 闲 ¥${breakdown.offPeakCostCny.toFixed(4)}` : '旧用量缺少峰闲时拆分，请先扫描今日会话日志' }, breakdown.exact ? breakdown.totalCostCny.toFixed(4) : '—'),
          )
        })),
      ),
      allSplitsKnown
        ? React.createElement('div', { className: 'vx-muted' }, `峰 token ${formatTokenCount(totalPeakTokens)} · 闲 token ${formatTokenCount(totalOffPeakTokens)} · 峰费用 ¥${totalPeakCost.toFixed(4)} · 闲费用 ¥${totalOffPeakCost.toFixed(4)}`)
        : React.createElement('div', { className: 'vx-muted' }, '部分旧用量缺少峰闲时拆分，费用暂不估算；请先扫描今日会话日志。'),
      React.createElement('div', { className: 'vx-muted' }, `规则核对于 ${DEEPSEEK_PRICING_CHECKED_ON} · `,
        React.createElement('a', { href: DEEPSEEK_PRICING_SOURCE_URL, target: '_blank', rel: 'noreferrer' }, 'DeepSeek 官方价目'),
        ' · 费用仅供参考',
      ),
    )
  }

  function recentDayKeys(count: number): string[] {
    const keys: string[] = []
    for (let i = count - 1; i >= 0; i--) keys.push(dayKey(Date.now() - i * 86_400_000))
    return keys
  }

  function UsageHistory(): React.ReactElement {
    const s = useS()
    // summarizeUsage walks every day/model row once per call; with the 90-day
    // range that is dozens of passes, and the budget inputs re-render this
    // component on every keystroke. The memo keys cover both inputs that
    // change the result; budget keystrokes change neither.
    const { summary, daily, maxTokens, byModel, month } = React.useMemo(() => {
      const keys = recentDayKeys(s.usageRange)
      const selected = new Set(keys)
      const summary = summarizeUsage(s.usage, selected)
      const daily = keys.map((day) => ({ day, ...summarizeUsage(s.usage, new Set([day])) }))
      const maxTokens = Math.max(1, ...daily.map((row) => row.tokens))
      const byModel: Record<string, UsageRow> = Object.create(null) as Record<string, UsageRow>
      for (const day of keys) {
        for (const [model, row] of Object.entries(s.usage[day] ?? {})) {
          const target = byModel[model] ?? (byModel[model] = createUsageRow())
          mergeUsageRow(target, row)
        }
      }
      const monthPrefix = dayKey().slice(0, 7) + '-'
      const monthDays = new Set(Object.keys(s.usage).filter((day) => day.startsWith(monthPrefix)))
      const month = summarizeUsage(s.usage, monthDays)
      return { summary, daily, maxTokens, byModel, month }
    }, [s.usage, s.usageRange])
    const budget = Math.max(0, Number(s.cfg.monthlyBudgetCny ?? 0))
    const warning = Math.max(1, Math.min(100, Number(s.cfg.budgetWarningPercent ?? 80)))
    const ratio = budget > 0 && month.exact ? month.costCny / budget * 100 : 0
    const state = budgetState(month, budget, warning)
    const budgetText = state === 'disabled' ? '预算提醒已关闭' : state === 'unknown' ? '历史峰闲数据不完整，无法判断预算' : state === 'over' ? `已超出月预算（${ratio.toFixed(0)}%）` : state === 'warning' ? `已达到月预算 ${ratio.toFixed(0)}%` : `本月预算使用 ${ratio.toFixed(0)}%`
    return React.createElement('div', { className: 'vx-col' },
      React.createElement('div', { className: 'vx-row wrap' },
        ([7, 30, 90] as const).map((range) => React.createElement('button', { key: range, className: 'vx-btn' + (s.usageRange === range ? ' on' : ''), onClick: () => setS({ usageRange: range }) }, `${range} 天`)),
        React.createElement('span', { className: 'vx-flex1' }),
        React.createElement('button', { className: 'vx-btn', onClick: () => { try { downloadText(usageCsv(s.usage), `custom-usage-${dayKey()}.csv`, 'text/csv;charset=utf-8') } catch { toast('CSV 导出失败', 'error') } } }, React.createElement(Icon, { n: 'download', size: 12 }), ' CSV'),
      ),
      React.createElement('div', { className: 'vx-balance-lines' },
        React.createElement('div', null, `${formatTokenCount(summary.tokens)} token · ${summary.calls} 次调用 · ${summary.exact ? `¥${summary.costCny.toFixed(4)}` : '费用不精确'}`),
      ),
      React.createElement('div', { className: 'vx-col', style: { gap: 3 } }, daily.map((row) => React.createElement('div', { key: row.day, className: 'vx-row', title: `${row.day} · ${formatTokenCount(row.tokens)} token · ${row.calls} 次` },
        React.createElement('span', { className: 'vx-muted', style: { width: 46 } }, row.day.slice(5)),
        React.createElement('span', { style: { height: 7, borderRadius: 8, minWidth: 2, width: `${Math.max(1, row.tokens / maxTokens * 100)}%`, background: 'var(--dsw-alias-color-primary, #4876d9)' } }),
      ))),
      Object.keys(byModel).length > 0 ? React.createElement('table', { className: 'vx-table' },
        React.createElement('thead', null, React.createElement('tr', null, React.createElement('th', null, '模型'), React.createElement('th', null, 'Token'), React.createElement('th', null, '调用'), React.createElement('th', null, '费用 ¥'))),
        React.createElement('tbody', null, Object.entries(byModel).map(([model, row]) => { const cost = usageCostBreakdown(row, model); return React.createElement('tr', { key: model }, React.createElement('td', null, model), React.createElement('td', null, formatTokenCount(row.in + row.out + row.cacheIn + row.cacheW)), React.createElement('td', null, row.calls), React.createElement('td', null, cost.exact ? cost.totalCostCny.toFixed(4) : '—')) })),
      ) : null,
      React.createElement('div', { className: state === 'over' ? 'vx-error' : 'vx-muted' }, budgetText),
      React.createElement('div', { className: 'vx-row wrap' },
        React.createElement('label', { className: 'vx-muted' }, '月预算 ¥ ', React.createElement('input', { className: 'vx-input', style: { width: 100 }, type: 'number', min: 0, step: 1, value: budget, onChange: (e: React.ChangeEvent<HTMLInputElement>) => setS({ cfg: { ...S.cfg, monthlyBudgetCny: Math.max(0, Number(e.target.value) || 0) } }), onBlur: saveCfg })),
        React.createElement('label', { className: 'vx-muted' }, '预警 ', React.createElement('input', { className: 'vx-input', style: { width: 72 }, type: 'number', min: 1, max: 100, value: warning, onChange: (e: React.ChangeEvent<HTMLInputElement>) => setS({ cfg: { ...S.cfg, budgetWarningPercent: Math.max(1, Math.min(100, Number(e.target.value) || 80)) } }), onBlur: saveCfg }), ' %'),
      ),
    )
  }

  function BalancePanelContent(): React.ReactElement {
    const s = useS()
    const b = s.balance
    // The balance query needs a personal sk- key that account-login Desktop
    // installs never have, so it is an opt-in section; everything else (usage,
    // cost estimate, budget) works key-free. A configured key starts expanded.
    const configured = s.apiKeyConfigured === true
    const [balanceOpen, setBalanceOpen] = React.useState(configured)
    const keyConfigured = b?.ok === false && (b as { keyConfigured?: boolean }).keyConfigured === true
    return React.createElement('div', { className: 'vx-col' },
      React.createElement('div', { className: 'vx-muted' }, '以下用量与费用全部来自本机会话记录，不需要 API Key；费用为按官方价目表折算的估算值，可能与账号账单有差异。'),
      React.createElement('div', { className: 'vx-section-title' }, '用量趋势与预算'),
      React.createElement(UsageHistory, null),
      React.createElement('div', { className: 'vx-section-title' }, '今日模型明细'),
      React.createElement(UsageTable, null),
      React.createElement('button', { className: 'vx-btn', onClick: () => { void refreshUsageScan() } }, React.createElement(Icon, { n: 'list', size: 13 }), ' 扫描今日会话日志更新用量'),
      React.createElement('div', { className: 'vx-row' },
        React.createElement('button', { className: 'vx-chip', onClick: () => setBalanceOpen(!balanceOpen) },
          React.createElement(Icon, { n: balanceOpen ? 'chevronDown' : 'chevronRight', size: 11 }),
          balanceOpen ? ' 收起余额查询' : ' 余额查询（可选，需要 API Key）'),
      ),
      balanceOpen
        ? React.createElement('div', { className: 'vx-col' },
          React.createElement('div', { className: 'vx-row' },
            React.createElement('input', {
              className: 'vx-input',
              type: 'password',
              placeholder: configured ? '已配置 Key；输入新 Key 覆盖' : 'DeepSeek API Key (sk-…)',
              value: s.apiKey,
              onChange: (e: React.ChangeEvent<HTMLInputElement>) => { setS({ apiKey: e.target.value, apiKeyDirty: true }) },
              onBlur: () => { if (S.apiKeyDirty) saveCfg() },
            }),
            React.createElement('button', { className: 'vx-btn', onClick: () => { if (S.apiKeyDirty) saveCfg() } }, '保存'),
            React.createElement('button', { className: 'vx-btn', onClick: () => { void refreshBalance() } }, React.createElement(Icon, { n: 'refresh', size: 13 }), ' 刷新'),
          ),
          React.createElement('div', { className: 'vx-muted' }, configured
            ? `Key 不回传浏览器；当前来源：${s.credentialStorage === 'system' ? '系统凭据' : s.credentialStorage === 'legacy-state' ? '旧状态文件（待迁移）' : s.credentialStorage === 'environment' ? '环境变量' : s.credentialStorage === 'dsh' ? 'DSH 凭据' : '未配置'}。留空后保存可清除插件自定义 Key。`
            : '填写 sk- 开头的 DeepSeek API Key 即可查询官方余额；Key 不回传浏览器，留空保存可清除已存 Key。'),
          b !== null && b.ok === true && b.balance !== null && b.balance !== undefined
            ? (() => {
              const info = b.balance as { currency?: string, total?: string, granted?: string, toppedUp?: string }
              const sym = (info.currency ?? 'CNY') === 'CNY' ? '¥' : `${info.currency ?? ''} `
              return React.createElement('div', { className: 'vx-balance-lines' },
                React.createElement('div', null, `可用额度: ${sym}${info.total ?? ''}`),
                React.createElement('div', { className: 'vx-muted' }, `赠送 ${sym}${info.granted ?? ''} · 充值 ${sym}${info.toppedUp ?? ''}${(b as { available?: boolean }).available === false ? ' · 余额不足不可用' : ''}`),
              )
            })()
            : null,
          // A real upstream failure (401/403, network) is worth showing; an
          // unconfigured key is the normal desktop state, not an error.
          keyConfigured && b !== null && b.ok === false
            ? React.createElement('div', { className: 'vx-error' }, String((b as { error?: unknown }).error ?? '未知错误'))
            : null,
        )
        : null,
    )
  }

  function QuoteDock(props: QuoteDockProps): React.ReactElement | null {
    useViewedSession(props)
    const s = useS()
    const inputRef = React.useRef(props.input)
    inputRef.current = props.input
    const actionsRef = React.useRef(props.inputActions)
    actionsRef.current = props.inputActions
    React.useEffect(() => {
      S.insertDraft = (text: string, replace: boolean): boolean => {
        const actions = actionsRef.current
        if (actions === undefined || typeof actions.setDraft !== 'function') return false
        try {
          const current = (inputRef.current?.draft ?? '') as string
          actions.setDraft(replace ? text : (current !== '' ? current + '\n\n' + text : text))
          return true
        } catch (error) {
          console.error('[custom-plugin] insertDraft', error)
          return false
        }
      }
      return () => { S.insertDraft = null }
    }, [])
    React.useEffect(() => {
      if (s.cfg.quote !== true) {
        if (S.quoteSel !== null) setS({ quoteSel: null })
        return
      }
      const d = typeof document !== 'undefined' ? document : null
      if (d === null) return
      const inVxRoot = (node: Node | null): boolean => {
        let n: Node | null = node
        while (n !== null && n.nodeType === 1) {
          if ((n as HTMLElement).classList !== undefined && (n as HTMLElement).classList.contains('vx-root')) return true
          n = n.parentNode
        }
        return false
      }
      const onSel = (): void => {
        try {
          const sel = d.getSelection?.() ?? null
          if (sel === null || sel.isCollapsed) {
            if (S.quoteSel !== null) setS({ quoteSel: null })
            return
          }
          const text = String(sel.toString() ?? '').trim()
          if (text === '') {
            if (S.quoteSel !== null) setS({ quoteSel: null })
            return
          }
          if (sel.rangeCount === 0) return
          const range = sel.getRangeAt(0)
          if (inVxRoot(range.commonAncestorContainer)) return
          const node = sel.anchorNode
          if (node !== null && node.nodeType === 1 && /TEXTAREA|INPUT/.test((node as HTMLElement).nodeName)) return
          const r = range.getBoundingClientRect()
          const next = { text: text.slice(0, 8000), x: r.left + r.width / 2, y: r.top - 6 }
          // selectionchange fires continuously while a selection is being
          // dragged; a sub-pixel move over unchanged text must not re-render
          // every store subscriber (one TurnTailEntry per rendered turn).
          const prev = S.quoteSel
          if (prev !== null && prev.text === next.text && Math.abs(prev.x - next.x) < 1 && Math.abs(prev.y - next.y) < 1) return
          setS({ quoteSel: next })
        } catch { /* selection read failed */ }
      }
      d.addEventListener('selectionchange', onSel)
      return () => d.removeEventListener('selectionchange', onSel)
    }, [s.cfg.quote])
    return null
  }

  function QuoteButton(): React.ReactElement | null {
    const s = useS()
    if (s.quoteSel === null) return null
    const q = s.quoteSel
    const fmt = q.text.split('\n').map((l) => '> ' + l).join('\n')
    return React.createElement('button', {
      className: 'vx-quote-btn',
      style: { left: q.x, top: q.y },
      onClick: () => {
        const text = fmt + '\n\n'
        const ok = S.insertDraft !== null ? S.insertDraft(text, false) : false
        if (!ok) toast('输入框不可用（当前不在会话中）', 'error')
        try {
          const d = typeof document !== 'undefined' ? document : null
          d?.getSelection()?.removeAllRanges()
        } catch { /* selection clear failed */ }
        setS({ quoteSel: null })
        if (ok) toast('已引用到输入框', 'info')
      },
    }, React.createElement(Icon, { n: 'quote', size: 12 }), React.createElement('span', null, '引用回复'))
  }

  function TurnTailEntry(props: TurnTailProps): React.ReactElement {
    useViewedSession(props)
    const seq = typeof props.seq === 'number' ? props.seq : null
    const turn = props.turn
    const { item, formula, mermaid } = useSSelector((state) => ({
      item: seq !== null && state.turns !== null && state.turns.sessionId === state.sessionId
        ? state.turnsBySeq?.get(seq) ?? null
        : null,
      formula: state.cfg.formula === true,
      mermaid: state.cfg.mermaid === true,
    }), shallowEqual)
    let registered: HTMLElement | null = null
    const btns: React.ReactElement[] = []
    if (item !== null && formula) {
      if (item.hasLatex === true) btns.push(React.createElement('button', { key: 'lx', className: 'vx-chip', title: '复制 LaTeX 公式', onClick: () => void copyLatexOf(item) }, React.createElement(Icon, { n: 'copy', size: 11 }), ' LaTeX'))
      if (item.hasMathml === true) btns.push(React.createElement('button', { key: 'mm', className: 'vx-chip', title: '复制 MathML（可粘贴到 Word）', onClick: () => void copyMathmlOf(item) }, React.createElement(Icon, { n: 'copy', size: 11 }), ' MathML'))
    }
    if (item !== null && mermaid && item.hasMermaid === true) {
      btns.push(React.createElement('button', { key: 'md', className: 'vx-chip', title: '渲染 Mermaid 图表', onClick: () => openMermaidOf(item) }, React.createElement(Icon, { n: 'gitBranch', size: 11 }), ' Mermaid'))
    }
    return React.createElement('span', {
      className: 'vx-anchor',
      'data-vx-seq': seq === null ? '' : String(seq),
      ref: (el: HTMLSpanElement | null): void => {
        if (el !== null && seq !== null) {
          registered = el
          S.anchors.set(seq, { el, turn: turn ?? null })
        } else if (el === null && seq !== null) {
          // A session switch can unmount an old row after a new row with the
          // same sequence has mounted. Delete only the element this callback
          // registered, never the replacement anchor.
          if (S.anchors.get(seq)?.el === registered) S.anchors.delete(seq)
          registered = null
        }
      },
    }, btns.length > 0 ? React.createElement('span', { className: 'vx-turn-actions' }, btns) : null)
  }
  function AppearanceTab(): React.ReactElement {
    const s = useS()
    const dark = s.dark === true
    const set = (k: keyof CustomPluginConfig, v: string | boolean): void => {
      setS({ cfg: { ...s.cfg, [k]: v } })
      saveCfg()
    }
    return React.createElement('div', { className: 'vx-col' },
      React.createElement('div', { className: 'vx-muted' }, '主题背景、天气特效与玻璃质感，选择后即时生效。'),
      React.createElement('div', { className: 'vx-section-title' }, '背景颜色'),
      React.createElement('div', { className: 'vx-muted' }, '20 组低饱和色板，深浅色模式均可用；深色下自动使用同色系的深色变体（预览即实际效果）。'),
      React.createElement('div', { className: 'vx-swatches' },
        React.createElement('button', { key: 'default', className: 'vx-swatch' + (s.cfg.bg === 'default' ? ' on' : ''), onClick: () => set('bg', 'default'), title: '无颜色（默认主题）' },
          React.createElement('span', { className: 'vx-swatch-box', style: { background: 'repeating-conic-gradient(#ccc 0 25%, #eee 0 50%) 0 0/10px 10px' } }),
          React.createElement('span', { className: 'vx-swatch-label' }, '无颜色')),
        PALETTE.map((p) => {
          // Preview shows what the canvas will actually paint in the current
          // theme: the light pastel in light mode, its same-hue dark variant
          // in dark mode.
          const preview = dark ? toDarkRamp(p[1], DARK_CANVAS_LIGHTNESS) : p[1]
          return React.createElement('button', { key: p[0], className: 'vx-swatch' + (s.cfg.bg === p[0] ? ' on' : ''), onClick: () => set('bg', p[0]), title: p[0] + ' ' + p[1] },
            React.createElement('span', { className: 'vx-swatch-box', style: { background: preview } }),
            React.createElement('span', { className: 'vx-swatch-label' }, p[0]))
        }),
      ),
      React.createElement('div', { className: 'vx-section-title' }, '天气特效'),
      React.createElement('div', { className: 'vx-row wrap' },
        (['none', 'snow', 'rain', 'sakura'] as const).map((w) => {
          const iconNames: Record<string, string> = { none: 'minimize', snow: 'snowflake', rain: 'cloudRain', sakura: 'flower' }
          const weatherNames: Record<string, string> = { none: '无', snow: '飘雪', rain: '电影感雨滴', sakura: '樱花飘落' }
          return React.createElement('button', {
            key: w,
            className: 'vx-btn' + (s.cfg.weather === w ? ' on' : ''),
            onClick: () => set('weather', w),
          },
          React.createElement(Icon, { n: iconNames[w], size: 12 }),
          ' ' + weatherNames[w])
        }),
      ),
      React.createElement('div', { className: 'vx-section-title' }, '玻璃效果'),
      React.createElement(Toggle, { label: '启用玻璃', checked: s.cfg.glass === true, onChange: (v) => set('glass', v) }),
      React.createElement('div', { className: 'vx-row wrap' },
        React.createElement('button', { className: 'vx-btn' + (s.cfg.glassMode !== 'liquid' ? ' on' : ''), onClick: () => set('glassMode', 'frost') }, '毛玻璃'),
        React.createElement('button', { className: 'vx-btn' + (s.cfg.glassMode === 'liquid' ? ' on' : ''), onClick: () => set('glassMode', 'liquid') }, '液态玻璃'),
      ),
      React.createElement(Toggle, { label: '全局浮层玻璃', checked: s.cfg.globalGlass === true, onChange: (v) => set('globalGlass', v), hint: '对弹窗/菜单等浮层应用玻璃质感；液态玻璃模式下浮层同样位移折射' }),
    )
  }

  function FolderNode(props: { node: FolderNode; useSessions: OverlayProps['useSessions']; useWorkspaces: OverlayProps['useWorkspaces'] }): React.ReactElement {
    const s = useS()
    const node = props.node
    const [open, setOpen] = React.useState(true)
    const sessions = useSessionsSafe(props)
    const byId = sessions !== null ? (sessions.byId as unknown as Record<string, { displayTitle?: string; title?: string; running?: boolean }>) : {}
    const workspaces = useWorkspacesSafe(props)
    const wsItems = workspaces !== null && workspaces.items !== undefined ? (workspaces.items as unknown as WorkspaceRowLike[]) : []
    const wsTitle = (w: WorkspaceRowLike): string => w.title || w.path || w.workspaceId
    const addChildFolder = (): void => {
      askText('文件夹名称：', '', (name) => {
        const folders = JSON.parse(JSON.stringify(S.folders)) as FolderNode[]
        const target = findFolder(folders, node.id)
        if (target === null) return
        target.children = target.children ?? []
        target.children.push({ id: 'f' + Date.now() + Math.floor(Math.random() * 9999), name, children: [], sessionIds: [], workspaceIds: [], prompts: [] })
        setS({ folders })
        saveCfg()
      })
    }
    const renameFolder = (): void => {
      askText('重命名文件夹：', node.name, (name) => {
        const folders = JSON.parse(JSON.stringify(S.folders)) as FolderNode[]
        const target = findFolder(folders, node.id)
        if (target !== null) target.name = name
        setS({ folders })
        saveCfg()
      })
    }
    const delFolder = (): void => {
      askConfirm(`删除文件夹「${node.name}」及其子文件夹？（会话与提示词不会被删除）`, (ok) => {
        if (!ok) return
        const folders = JSON.parse(JSON.stringify(S.folders)) as FolderNode[]
        const cut = (arr: FolderNode[]): boolean => {
          for (let i = 0; i < arr.length; i++) {
            if (arr[i].id === node.id) { arr.splice(i, 1); return true }
            if (cut(arr[i].children ?? [])) return true
          }
          return false
        }
        cut(folders)
        setS({ folders })
        saveCfg()
      })
    }
    const removeRef = (kind: 'session' | 'workspace', id: string): void => {
      const folders = JSON.parse(JSON.stringify(S.folders)) as FolderNode[]
      const target = findFolder(folders, node.id)
      if (target === null) return
      if (kind === 'session') target.sessionIds = (target.sessionIds ?? []).filter((x) => x !== id)
      else target.workspaceIds = (target.workspaceIds ?? []).filter((x) => x !== id)
      setS({ folders })
      saveCfg()
    }
    const moveNode = (srcId: string, targetId: string, mode: string): void => {
      if (srcId === '' || srcId === targetId) return
      const folders = JSON.parse(JSON.stringify(S.folders)) as FolderNode[]
      let src: FolderNode | null = null
      const take = (arr: FolderNode[]): boolean => {
        for (let i = 0; i < arr.length; i++) {
          if (arr[i].id === srcId) { src = arr.splice(i, 1)[0]; return true }
          if (take(arr[i].children ?? [])) return true
        }
        return false
      }
      const place = (arr: FolderNode[]): boolean => {
        for (const f of arr) {
          if (f.id === targetId) {
            if (mode === 'inside') (f.children = f.children ?? []).push(src as FolderNode)
            else if (mode === 'before') arr.splice(arr.indexOf(f), 0, src as FolderNode)
            else arr.splice(arr.indexOf(f) + 1, 0, src as FolderNode)
            return true
          }
          if (place(f.children ?? [])) return true
        }
        return false
      }
      if (src !== null && take(folders) && place(folders)) { setS({ folders }); saveCfg() }
    }
    const rowDrop = (e: React.DragEvent): void => {
      e.preventDefault()
      e.stopPropagation()
      const srcId = S.dragFolder
      const hint = S.dropHint
      setS({ dragFolder: null, dropHint: null })
      if (srcId !== null) moveNode(srcId, node.id, hint !== null && hint.zone !== null ? hint.zone : 'inside')
    }
    const rowOver = (e: React.DragEvent): void => {
      e.preventDefault()
      e.stopPropagation()
      const r = e.currentTarget.getBoundingClientRect()
      const y = e.clientY - r.top
      const zone = y < r.height * 0.28 ? 'before' : (y > r.height * 0.72 ? 'after' : 'inside')
      if (S.dropHint === null || S.dropHint.id !== node.id || S.dropHint.zone !== zone) setS({ dropHint: { id: node.id, zone } })
    }
    const rowLeave = (): void => { if (S.dropHint !== null && S.dropHint.id === node.id) setS({ dropHint: null }) }
    const adding = s.folderAdd === node.id
    const pickingWs = s.folderWsPick === node.id
    const hintZone = s.dropHint !== null && s.dropHint.id === node.id ? s.dropHint.zone : null
    const children = node.children ?? []
    const sessIds = node.sessionIds ?? []
    const wsIds = node.workspaceIds ?? []
    return React.createElement('div', { className: 'vx-folder' },
      React.createElement('div', {
        className: 'vx-folder-head' + (hintZone === 'inside' ? ' drop-inside' : (hintZone === 'before' ? ' drop-before' : (hintZone === 'after' ? ' drop-after' : ''))),
        draggable: true,
        onDragStart: (e: React.DragEvent) => { setS({ dragFolder: node.id }); try { e.dataTransfer.setData('text/plain', node.id) } catch { /* dataTransfer unavailable */ } },
        onDragEnd: () => setS({ dragFolder: null, dropHint: null }),
        onDragOver: rowOver,
        onDragLeave: rowLeave,
        onDrop: rowDrop,
      },
        React.createElement('button', { className: 'vx-mini', title: open ? '折叠' : '展开', onClick: (e: React.MouseEvent) => { e.stopPropagation(); setOpen(!open) } },
          React.createElement(Icon, { n: open ? 'chevronDown' : 'chevronRight', size: 12 })),
        React.createElement(Icon, { n: 'folder', size: 14 }),
        React.createElement('span', { className: 'vx-folder-name', title: node.name }, node.name),
        React.createElement('span', { className: 'vx-badge' }, folderCount(node)),
        React.createElement('button', { className: 'vx-mini', title: '重命名', onClick: (e: React.MouseEvent) => { e.stopPropagation(); renameFolder() } }, React.createElement(Icon, { n: 'sliders', size: 11 })),
        React.createElement('button', { className: 'vx-mini', title: '删除', onClick: (e: React.MouseEvent) => { e.stopPropagation(); delFolder() } }, React.createElement(Icon, { n: 'trash', size: 11 })),
      ),
      open
        ? React.createElement('div', { className: 'vx-folder-body' },
          children.map((c) => React.createElement(FolderNode, { key: c.id, node: c, useSessions: props.useSessions, useWorkspaces: props.useWorkspaces })),
          wsIds.map((wid) => {
            const w = wsItems.find((x) => x.workspaceId === wid)
            if (w === undefined) return null
            return React.createElement('div', { key: 'w' + wid, className: 'vx-item-row' },
              React.createElement(Icon, { n: 'briefcase', size: 12 }),
              React.createElement('button', { className: 'vx-item-name', title: wsTitle(w), onClick: () => void openWorkspaceItem(wid) }, wsTitle(w)),
              React.createElement('button', { className: 'vx-mini', title: '移出', onClick: () => removeRef('workspace', wid) }, React.createElement(Icon, { n: 'x', size: 10 })),
            )
          }),
          sessIds.map((sid) => {
            const sum = byId[sid]
            const name = sum !== undefined ? (sum.displayTitle || sum.title || sid) : sid
            return React.createElement('div', { key: 's' + sid, className: 'vx-item-row' },
              React.createElement(Icon, { n: 'message', size: 12 }),
              React.createElement('button', { className: 'vx-item-name', title: name, onClick: () => openSessionItem(sid) }, name),
              React.createElement('button', { className: 'vx-mini', title: '移出', onClick: () => removeRef('session', sid) }, React.createElement(Icon, { n: 'x', size: 10 })),
            )
          }),
          React.createElement('div', { className: 'vx-row vx-pad-sm' },
            React.createElement('button', { className: 'vx-btn vx-btn-sm', onClick: () => setS({ folderAdd: adding ? null : node.id, folderWsPick: null }) },
              React.createElement(Icon, { n: 'plus', size: 11 }), ' 添加'),
            adding ? React.createElement('button', { className: 'vx-btn vx-btn-sm', onClick: () => setS({ folderWsPick: pickingWs ? null : node.id }) },
              React.createElement(Icon, { n: 'briefcase', size: 11 }), ' 工作区') : null,
          ),
          adding
            ? React.createElement('div', { className: 'vx-form' },
              React.createElement('button', { className: 'vx-btn vx-btn-sm', onClick: addChildFolder }, React.createElement(Icon, { n: 'folderPlus', size: 11 }), ' 新建子文件夹'),
              S.sessionId !== null
                ? React.createElement('button', { className: 'vx-btn vx-btn-sm', onClick: () => {
                  const folders = JSON.parse(JSON.stringify(S.folders)) as FolderNode[]
                  const target = findFolder(folders, node.id)
                  if (target !== null) {
                    target.sessionIds = target.sessionIds ?? []
                    if (target.sessionIds.indexOf(S.sessionId as string) < 0) target.sessionIds.push(S.sessionId as string)
                  }
                  setS({ folders, folderAdd: null })
                  saveCfg()
                } }, React.createElement(Icon, { n: 'message', size: 11 }), ' 添加当前会话')
                : null,
              pickingWs
                ? React.createElement('div', { className: 'vx-list' },
                  wsItems.filter((w) => wsIds.indexOf(w.workspaceId) < 0).map((w) => React.createElement('button', {
                    key: w.workspaceId,
                    className: 'vx-list-item',
                    onClick: () => {
                      const folders = JSON.parse(JSON.stringify(S.folders)) as FolderNode[]
                      const target = findFolder(folders, node.id)
                      if (target !== null) {
                        target.workspaceIds = target.workspaceIds ?? []
                        if (target.workspaceIds.indexOf(w.workspaceId) < 0) target.workspaceIds.push(w.workspaceId)
                      }
                      setS({ folders, folderAdd: null, folderWsPick: null })
                      saveCfg()
                    },
                  }, wsTitle(w))))
                : null,
            )
            : null,
        )
        : null,
    )
  }

  function FoldersTab(props: { useSessions: OverlayProps['useSessions']; useWorkspaces: OverlayProps['useWorkspaces'] }): React.ReactElement {
    const addRoot = (): void => {
      askText('文件夹名称：', '', (name) => {
        const folders = JSON.parse(JSON.stringify(S.folders)) as FolderNode[]
        folders.push({ id: 'f' + Date.now() + Math.floor(Math.random() * 9999), name, children: [], sessionIds: [], workspaceIds: [], prompts: [] })
        setS({ folders })
        saveCfg()
      })
    }
    return React.createElement('div', { className: 'vx-col' },
      React.createElement('div', { className: 'vx-muted' }, '跨工作区共享的会话与工作区收藏夹，支持多级嵌套与拖拽排序；数据保存在本机状态文件。'),
      S.folders.length === 0 ? React.createElement('div', { className: 'vx-muted vx-pad-sm' }, '暂无文件夹，点击下方按钮创建。') : null,
      S.folders.map((f) => React.createElement(FolderNode, { key: f.id, node: f, useSessions: props.useSessions, useWorkspaces: props.useWorkspaces })),
      React.createElement('div', { className: 'vx-row vx-pad-sm' },
        React.createElement('button', { className: 'vx-btn', onClick: addRoot }, React.createElement(Icon, { n: 'folderPlus', size: 13 }), ' 新建文件夹'),
      ),
    )
  }

  function PromptsTab(): React.ReactElement {
    const s = useS()
    const [query, setQuery] = React.useState('')
    const dragId = React.useRef<string | null>(null)
    const addPrompt = (): void => {
      askText('提示词名称：', '', (name) => {
        askText('提示词内容：', '', (text) => {
          if (text.trim() === '') { toast('内容不能为空', 'error'); return }
          S.prompts = S.prompts.concat({ id: 'p' + Date.now() + Math.floor(Math.random() * 9999), name: name || '未命名', text, tags: [], favorite: false, useCount: 0 })
          setS({ prompts: S.prompts })
          saveCfg()
        })
      })
    }
    const delPrompt = (id: string): void => {
      S.prompts = S.prompts.filter((x) => x.id !== id)
      setS({ prompts: S.prompts })
      saveCfg()
    }
    const editPrompt = (prompt: PromptItem): void => {
      askText('提示词名称：', prompt.name, (name) => askText('提示词内容：', prompt.text, (text) => askText('标签（逗号分隔）：', (prompt.tags ?? []).join(', '), (tags) => {
        if (text.trim() === '') { toast('内容不能为空', 'error'); return }
        S.prompts = S.prompts.map((item) => item.id === prompt.id ? { ...item, name: name.trim() || '未命名', text, tags: [...new Set(tags.split(/[,，]/).map((tag) => tag.trim()).filter(Boolean))] } : item)
        setS({ prompts: S.prompts }); saveCfg()
      }, true)))
    }
    const importPrompts = async (file: File): Promise<void> => {
      try {
        const text = await file.text()
        let incoming: PromptItem[]
        let skipped = 0
        if (/\.md$/i.test(file.name)) incoming = parsePromptsMarkdown(text)
        else {
          const doc = JSON.parse(text) as { format?: unknown; version?: unknown; prompts?: unknown }
          if (doc.format !== 'dsh-custom-plugin-prompts' || doc.version !== 1 || !Array.isArray(doc.prompts)) throw new Error('不支持的提示词文件')
          incoming = doc.prompts.map(normalizePromptItem).filter((item): item is PromptItem => item !== null)
          skipped = doc.prompts.length - incoming.length
        }
        // A portable file may repeat an id; use its last occurrence once so
        // the conflict result is deterministic and the count is not inflated.
        incoming = [...new Map(incoming.map((item) => [item.id, item])).values()]
        const map = new Map(incoming.map((item) => [item.id, item]))
        S.prompts = S.prompts.map((item) => map.get(item.id) ?? item)
        for (const item of incoming) if (!S.prompts.some((old) => old.id === item.id)) S.prompts.push(item)
        setS({ prompts: S.prompts }); saveCfg(); toast(skipped > 0 ? `已导入 ${incoming.length} 条提示词，跳过 ${skipped} 条无效记录` : `已导入 ${incoming.length} 条提示词`, skipped > 0 ? 'error' : 'info')
      } catch (error) { toast('提示词导入失败: ' + String((error as Error)?.message ?? error), 'error') }
    }
    const visible = s.prompts.filter((prompt) => query === '' || prompt.name.toLowerCase().includes(query.toLowerCase()) || prompt.text.toLowerCase().includes(query.toLowerCase()) || (prompt.tags ?? []).some((tag) => tag.toLowerCase().includes(query.toLowerCase())))
    return React.createElement('div', { className: 'vx-col' },
      React.createElement('div', { className: 'vx-muted' }, '支持收藏、标签、变量模板与拖拽排序；同 ID 导入项会更新现有内容。'),
      React.createElement('input', { className: 'vx-input', placeholder: '搜索名称、内容或标签…', value: query, onChange: (e: React.ChangeEvent<HTMLInputElement>) => setQuery(e.target.value) }),
      visible.map((p) => React.createElement('div', { key: p.id, className: 'vx-prompt-card', draggable: true, onDragStart: () => { dragId.current = p.id }, onDragOver: (e: React.DragEvent) => e.preventDefault(), onDrop: (e: React.DragEvent) => { e.preventDefault(); const from = dragId.current; if (from === null || from === p.id) return; const next = [...S.prompts]; const oldIndex = next.findIndex((item) => item.id === from); const newIndex = next.findIndex((item) => item.id === p.id); if (oldIndex < 0 || newIndex < 0) return; const moved = next.splice(oldIndex, 1)[0]; next.splice(newIndex, 0, moved); setS({ prompts: next }); saveCfg() } },
        React.createElement('div', { className: 'vx-row' },
          React.createElement('button', { className: 'vx-mini', title: p.favorite ? '取消收藏' : '收藏', onClick: () => { S.prompts = S.prompts.map((item) => item.id === p.id ? { ...item, favorite: !item.favorite } : item); setS({ prompts: S.prompts }); saveCfg() } }, React.createElement(Icon, { n: 'star', size: 11, filled: p.favorite === true })),
          React.createElement('span', { className: 'vx-prompt-title' }, p.name),
          React.createElement('span', { className: 'vx-flex1' }),
          React.createElement('span', { className: 'vx-muted' }, `使用 ${p.useCount ?? 0} 次`),
          React.createElement('button', { className: 'vx-mini', title: '插入', onClick: () => insertPrompt(p) }, React.createElement(Icon, { n: 'zap', size: 11 })),
          React.createElement('button', { className: 'vx-mini', title: '编辑', onClick: () => editPrompt(p) }, React.createElement(Icon, { n: 'wrench', size: 11 })),
          React.createElement('button', { className: 'vx-mini', title: '复制', onClick: () => void copyText(p.text).then((ok) => toast(ok ? '已复制提示词' : '复制失败', ok ? 'info' : 'error')) }, React.createElement(Icon, { n: 'copy', size: 11 })),
          React.createElement('button', { className: 'vx-mini', title: '删除', onClick: () => delPrompt(p.id) }, React.createElement(Icon, { n: 'trash', size: 11 })),
        ),
        (p.tags ?? []).length > 0 ? React.createElement('div', { className: 'vx-muted' }, (p.tags ?? []).map((tag) => `#${tag}`).join(' ')) : null,
        React.createElement('div', { className: 'vx-prompt-body' }, p.text),
      )),
      React.createElement('div', { className: 'vx-row vx-pad-sm' },
        React.createElement('button', { className: 'vx-btn', onClick: addPrompt }, React.createElement(Icon, { n: 'plus', size: 13 }), ' 新增提示词'),
        React.createElement('button', { className: 'vx-btn', onClick: () => downloadText(JSON.stringify({ format: 'dsh-custom-plugin-prompts', version: 1, prompts: S.prompts }, null, 2), `custom-prompts-${dayKey()}.json`, 'application/json') }, '导出 JSON'),
        React.createElement('button', { className: 'vx-btn', onClick: () => downloadText(promptsMarkdown(S.prompts), `custom-prompts-${dayKey()}.md`, 'text/markdown') }, '导出 Markdown'),
        React.createElement('label', { className: 'vx-btn' }, '导入', React.createElement('input', { type: 'file', accept: '.json,.md,application/json,text/markdown', style: { display: 'none' }, onChange: (e: React.ChangeEvent<HTMLInputElement>) => { const file = e.target.files?.[0]; if (file !== undefined) void importPrompts(file); e.target.value = '' } })),
      ),
    )
  }

  function BackupControls(): React.ReactElement {
    const [mode, setMode] = React.useState<'merge' | 'replace'>('merge')
    const exportBackup = async (): Promise<void> => {
      try {
        const result = await apiBackupExport()
        if (!result.ok) { toast(result.error ?? '备份导出失败', 'error'); return }
        downloadText(JSON.stringify(result.data, null, 2), `custom-backup-${dayKey()}.json`, 'application/json')
        toast('已导出无密钥备份', 'info')
      } catch (error) { toast(String((error as Error)?.message ?? error), 'error') }
    }
    const importFile = async (file: File): Promise<void> => {
      if (file.size > 5 * 1024 * 1024) { toast('备份文件不能超过 5 MB', 'error'); return }
      let documentValue: unknown
      try { documentValue = JSON.parse(await file.text()) as unknown } catch { toast('备份文件不是有效 JSON', 'error'); return }
      try {
        const preview = await apiBackupImport(documentValue, mode, true)
        if (!preview.ok) { toast(preview.error ?? '备份校验失败', 'error'); return }
        const p = preview.preview
        askConfirm(`导入 ${p.folders} 个文件夹、${p.prompts} 条提示词、${p.starredSessions} 个星标会话、${p.usageDays} 天用量？冲突：文件夹 ${p.conflicts.folders}、提示词 ${p.conflicts.prompts}、用量 ${p.conflicts.usageDays}。`, (ok) => {
          if (!ok) return
          void apiBackupImport(documentValue, mode, false).then(async (result) => {
            if (!result.ok) { toast(result.error ?? '备份导入失败', 'error'); return }
            await loadCfg()
            toast('备份导入完成；原状态已生成恢复副本', 'info')
          }).catch((error) => toast(String((error as Error)?.message ?? error), 'error'))
        })
      } catch (error) { toast(String((error as Error)?.message ?? error), 'error') }
    }
    return React.createElement('div', { className: 'vx-col' },
      React.createElement('div', { className: 'vx-section-title' }, '本地状态备份'),
      React.createElement('div', { className: 'vx-muted' }, '包含外观、文件夹、提示词、星标、用量和预算；不会包含 API Key。'),
      React.createElement('div', { className: 'vx-row wrap' },
        React.createElement('button', { className: 'vx-btn', onClick: () => { void exportBackup() } }, React.createElement(Icon, { n: 'download', size: 12 }), ' 导出 JSON 备份'),
        React.createElement('select', { className: 'vx-input', value: mode, onChange: (e: React.ChangeEvent<HTMLSelectElement>) => setMode(e.target.value === 'replace' ? 'replace' : 'merge') }, React.createElement('option', { value: 'merge' }, '合并导入'), React.createElement('option', { value: 'replace' }, '覆盖非敏感状态')),
        React.createElement('label', { className: 'vx-btn' }, '选择备份文件', React.createElement('input', { type: 'file', accept: 'application/json,.json', style: { display: 'none' }, onChange: (e: React.ChangeEvent<HTMLInputElement>) => { const file = e.target.files?.[0]; if (file !== undefined) void importFile(file); e.target.value = '' } })),
      ),
    )
  }

  async function revealSearchResult(item: ConversationSearchItem): Promise<void> {
    try {
      if (S.sessionId !== item.sessionId) { toast('搜索结果所属会话已切换，请重新搜索', 'error'); return }
      const expectedSessionId = item.sessionId
      const sessions = C.get('sessions') as { binding(id: string): { session: { loadOlder(): Promise<void>; getSnapshot(): { hasMore: boolean } } } | undefined } | undefined
      const face = sessions?.binding(expectedSessionId)?.session
      if (face === undefined) { toast('目标会话不可用', 'error'); return }
      const rendered = (): boolean => S.anchors.get(item.anchorSeq)?.el !== undefined
      for (let page = 0; !rendered() && face.getSnapshot().hasMore && page < 20; page++) {
        if (S.sessionId !== expectedSessionId) { toast('会话已切换，搜索结果已失效', 'error'); return }
        await face.loadOlder()
        await new Promise<void>((resolve) => setTimeout(resolve, 60))
      }
      if (S.sessionId !== expectedSessionId) { toast('会话已切换，搜索结果已失效', 'error'); return }
      if (!rendered()) { toast('结果所在消息尚未加载，请继续加载历史后重试', 'error'); return }
      scrollToSeq(item.anchorSeq)
    } catch (error) {
      toast('加载搜索结果失败: ' + String((error as Error)?.message ?? error), 'error')
    }
  }

  function Highlight(props: { text: string; query: string }): React.ReactElement {
    const q = props.query.trim()
    const index = q === '' ? -1 : props.text.toLowerCase().indexOf(q.toLowerCase())
    if (index < 0) return React.createElement('span', null, props.text)
    return React.createElement('span', null, props.text.slice(0, index), React.createElement('mark', null, props.text.slice(index, index + q.length)), props.text.slice(index + q.length))
  }

  function SearchTab(): React.ReactElement {
    const [query, setQuery] = React.useState('')
    const [kinds, setKinds] = React.useState<ConversationSearchKind[]>(['user', 'assistant', 'tool'])
    const [items, setItems] = React.useState<ConversationSearchItem[]>([])
    const [status, setStatus] = React.useState('')
    const [hasMore, setHasMore] = React.useState(false)
    const [scanned, setScanned] = React.useState(false)
    React.useEffect(() => {
      if (query.trim() === '' || S.sessionId === null) { setItems([]); setStatus(''); setHasMore(false); setScanned(false); return }
      const controller = new AbortController()
      const timer = setTimeout(() => {
        setStatus('搜索中…')
        void apiConversationSearch(S.sessionId as string, query.trim(), kinds, controller.signal).then((result) => {
          if (controller.signal.aborted) return
          if (!result.ok) { setItems([]); setStatus(result.error ?? '搜索不可用'); return }
          setItems(result.items); setHasMore(result.hasMore); setScanned(result.source === 'scan'); setStatus(result.items.length === 0 ? '没有匹配结果' : '')
        })
      }, 250)
      return () => { clearTimeout(timer); controller.abort() }
    }, [query, kinds.join(','), S.sessionId])
    const toggle = (kind: ConversationSearchKind): void => setKinds((old) => old.includes(kind) ? (old.length > 1 ? old.filter((item) => item !== kind) : old) : [...old, kind])
    const names: Record<ConversationSearchKind, string> = { user: '用户', assistant: '助手', tool: '工具' }
    return React.createElement('div', { className: 'vx-col' },
      React.createElement('div', { className: 'vx-muted' }, '搜索当前会话的消息与工具记录；结果只在本次请求中使用。'),
      scanned ? React.createElement('div', { className: 'vx-muted' }, '本部署未开启 dsh 的事件全文索引，已改为直接扫描会话日志（结果按出现顺序，最多 100 条）。') : null,
      React.createElement('input', { className: 'vx-input', autoFocus: true, placeholder: '输入搜索词…', value: query, onChange: (e: React.ChangeEvent<HTMLInputElement>) => setQuery(e.target.value) }),
      React.createElement('div', { className: 'vx-row' }, (['user', 'assistant', 'tool'] as const).map((kind) => React.createElement('label', { key: kind, className: 'vx-muted' }, React.createElement('input', { type: 'checkbox', checked: kinds.includes(kind), onChange: () => toggle(kind) }), ' ', names[kind]))),
      status !== '' ? React.createElement('div', { className: 'vx-muted' }, status) : null,
      React.createElement('div', { className: 'vx-list' }, items.map((item) => React.createElement('button', { key: `${item.seq}-${item.kind}`, className: 'vx-list-item', onClick: () => { void revealSearchResult(item) } },
        React.createElement('div', { className: 'vx-row' }, React.createElement('span', { className: 'vx-badge' }, names[item.kind]), React.createElement('span', { className: 'vx-muted' }, new Date(item.time).toLocaleString('zh-CN'))),
        React.createElement('div', { className: 'vx-prompt-body' }, React.createElement(Highlight, { text: item.snippet, query })),
      ))),
      hasMore ? React.createElement('div', { className: 'vx-muted' }, '结果超过 100 条，请缩小搜索范围。') : null,
    )
  }

  function ExportTab(): React.ReactElement {
    const s = useS()
    return React.createElement('div', { className: 'vx-col' },
      React.createElement('div', { className: 'vx-muted' }, '将当前会话导出为文件：JSON 可导入其他工具，Markdown 便于阅读分享，HTML 内嵌图片（导出 .html 文件，浏览器打开后打印即可另存为 PDF）。'),
      React.createElement('div', { className: 'vx-row wrap' },
        React.createElement('button', { className: 'vx-btn big', disabled: s.exporting === true, onClick: () => runExport('json') }, React.createElement(Icon, { n: 'download', size: 14 }), ' JSON'),
        React.createElement('button', { className: 'vx-btn big', disabled: s.exporting === true, onClick: () => runExport('markdown') }, React.createElement(Icon, { n: 'download', size: 14 }), ' Markdown'),
        React.createElement('button', { className: 'vx-btn big', disabled: s.exporting === true, onClick: () => runExport('pdf') }, React.createElement(Icon, { n: 'download', size: 14 }), ' HTML（含图片）'),
      ),
      s.exporting === true ? React.createElement('div', { className: 'vx-muted vx-pad-sm' }, '导出中…') : null,
      React.createElement(BackupControls, null),
    )
  }

  function MermaidTab(): React.ReactElement {
    const [engine, setEngine] = React.useState(mermaidState.status)
    const aliveRef = React.useRef(true)
    React.useEffect(() => {
      const t = new Promise<void>((resolve) => setTimeout(resolve, 300)).then(() => { if (aliveRef.current) setEngine(mermaidState.status) }).catch(() => {})
      return () => { aliveRef.current = false; try { void t.catch(() => {}) } catch { /* timer disposed */ } }
    }, [])
    const load = async (): Promise<void> => {
      setEngine('loading')
      const ok = await ensureMermaid()
      if (!aliveRef.current) return
      setEngine(ok ? 'ready' : 'failed')
      toast(ok ? 'Mermaid 引擎已就绪' : '加载失败：可改用 mermaid.live 按钮', ok ? 'info' : 'error')
    }
    return React.createElement('div', { className: 'vx-col' },
      React.createElement('div', { className: 'vx-muted vx-pad-sm' }, '助手回复与用户消息中的 Mermaid 代码块会自动就地渲染为图表（支持思维导图、流程图等），可随时切回代码视图；渲染引擎优先取本地依赖，失败时回退 CDN，也可一键跳转 mermaid.live 在线编辑。'),
      React.createElement(Toggle, { label: '自动渲染 Mermaid 图表', checked: S.cfg.mermaid === true, onChange: (v) => { setS({ cfg: { ...S.cfg, mermaid: v } }); saveCfg() } }),
      React.createElement('div', { className: 'vx-row' },
        React.createElement('button', { className: 'vx-btn', onClick: () => void load() },
          React.createElement(Icon, { n: 'gitBranch', size: 12 }),
          engine === 'ready' ? ' 引擎已就绪' : (engine === 'loading' ? ' 加载中…' : ' 预加载渲染引擎')),
        React.createElement('span', { className: 'vx-muted' }, engine === 'failed' ? '加载失败（本地依赖缺失且网络不可达）' : ''),
      ),
    )
  }

  function ToolsTab(): React.ReactElement {
    const s = useS()
    const set = (k: keyof CustomPluginConfig, v: boolean): void => {
      setS({ cfg: { ...s.cfg, [k]: v } })
      saveCfg()
    }
    return React.createElement('div', { className: 'vx-col' },
      React.createElement('div', { className: 'vx-section-title' }, '效率工具'),
      React.createElement(Toggle, { label: '引用回复', checked: s.cfg.quote === true, onChange: (v) => set('quote', v), hint: '选中对话文本后出现引用按钮（个性化面板内不触发）' }),
      React.createElement(Toggle, { label: '防自动跳转', checked: s.cfg.antiScroll === true, onChange: (v) => set('antiScroll', v), hint: '拦截发送后强制滚动到底部' }),
      React.createElement(Toggle, { label: '公式复制', checked: s.cfg.formula === true, onChange: (v) => set('formula', v), hint: '消息下方显示 LaTeX/MathML 复制按钮' }),
      React.createElement('div', { className: 'vx-row vx-pad-sm' },
        React.createElement('button', { className: 'vx-btn', onClick: () => setS({ commandOpen: true }) }, React.createElement(Icon, { n: 'search', size: 13 }), ' 打开快捷面板（Ctrl/⌘ K）'),
        React.createElement('button', { className: 'vx-btn vx-btn-danger', onClick: () => setS({ batchModal: true }) },
          React.createElement(Icon, { n: 'trash', size: 13 }), ' 批量归档会话'),
      ),
    )
  }

  function AboutTab(): React.ReactElement {
    const [info, setInfo] = React.useState<Record<string, unknown> | null>(null)
    const loadInfo = async (): Promise<void> => {
      try { setInfo(await apiDebugInfo()) } catch { setInfo({ ok: false }) }
    }
    React.useEffect(() => { void loadInfo() }, [])
    return React.createElement('div', { className: 'vx-col vx-pad' },
      React.createElement('div', null, 'Custom 便利套件'),
      React.createElement('div', { className: 'vx-muted' }, '外观与天气特效 · 项目文件夹 · 提示词 · 会话导出 · Mermaid 渲染 · 额度面板'),
      info !== null && info.ok === true
        ? React.createElement('pre', { className: 'vx-pre' },
          `状态文件: ${String(info.statePath ?? '')}\n今日: ${String(info.today ?? '')}\nMermaid: ${String(info.mermaidBytes ?? 0)} bytes\n今日用量: ${JSON.stringify(info.usageToday ?? {})}\n客户端诊断: ${Array.isArray(info.diagReports) ? `${String(info.diagReports.length)} 条` : '0 条'}`)
        : null,
      React.createElement('button', { className: 'vx-btn', onClick: () => void loadInfo() }, React.createElement(Icon, { n: 'refresh', size: 12 }), ' 刷新调试信息'),
    )
  }

  function AskModal(): React.ReactElement | null {
    const s = useS()
    const [val, setVal] = React.useState('')
    React.useEffect(() => { if (s.ask !== null) setVal(s.ask.value ?? '') }, [s.ask?.title])
    const ask = s.ask
    if (ask === null) return null
    const submit = (): void => {
      const cb = ask.cb
      setS({ ask: null })
      if (ask.allowEmpty === true || val.trim() !== '') cb(ask.allowEmpty === true ? val : val.trim())
    }
    return React.createElement('div', { className: 'vx-modal-mask', onClick: () => setS({ ask: null }) },
      React.createElement('div', { className: 'vx-glass vx-modal', style: { width: 'min(360px, 92vw)' }, onClick: (e: React.MouseEvent) => e.stopPropagation() },
        React.createElement('div', { className: 'vx-pop-head' }, React.createElement('span', null, ask.title)),
        React.createElement('input', { className: 'vx-input', value: val, autoFocus: true, onChange: (e: React.ChangeEvent<HTMLInputElement>) => setVal(e.target.value), onKeyDown: (e: React.KeyboardEvent) => { if (e.key === 'Enter') submit() } }),
        React.createElement('div', { className: 'vx-row vx-pad-sm' },
          React.createElement('button', { className: 'vx-btn', onClick: submit }, '确定'),
          React.createElement('button', { className: 'vx-btn', onClick: () => setS({ ask: null }) }, '取消'),
        ),
      ),
    )
  }

  function ConfirmModal(): React.ReactElement | null {
    const s = useS()
    if (s.confirmAsk === null) return null
    const c = s.confirmAsk
    const answer = (ok: boolean): void => {
      const cb = c.cb
      setS({ confirmAsk: null })
      cb(ok)
    }
    return React.createElement('div', { className: 'vx-modal-mask', onClick: () => answer(false) },
      React.createElement('div', { className: 'vx-glass vx-modal', style: { width: 'min(380px, 92vw)' }, onClick: (e: React.MouseEvent) => e.stopPropagation() },
        React.createElement('div', { className: 'vx-pad' }, c.message),
        React.createElement('div', { className: 'vx-row vx-pad-sm' },
          React.createElement('button', { className: 'vx-btn vx-btn-danger', onClick: () => answer(true) }, '确定'),
          React.createElement('button', { className: 'vx-btn', onClick: () => answer(false) }, '取消'),
        ),
      ),
    )
  }

  function TemplateModal(): React.ReactElement | null {
    const s = useS()
    const prompt = s.templatePrompt
    if (prompt === null) return null
    const names = promptVariables(prompt.text)
    const submit = (): void => {
      if (names.some((name) => (S.templateValues[name] ?? '').trim() === '')) { toast('请填写所有变量', 'error'); return }
      const text = fillPromptTemplate(prompt.text, S.templateValues)
      const ok = S.insertDraft !== null ? S.insertDraft(text, false) : false
      if (!ok) { toast('请在会话输入框中重试', 'error'); return }
      S.prompts = S.prompts.map((item) => item.id === prompt.id ? { ...item, useCount: (item.useCount ?? 0) + 1, lastUsedAt: Date.now() } : item)
      setS({ prompts: S.prompts, templatePrompt: null, templateValues: {} }); saveCfg(); toast('已插入提示词: ' + prompt.name, 'info')
    }
    return React.createElement('div', { className: 'vx-modal-mask', onClick: () => setS({ templatePrompt: null, templateValues: {} }) },
      React.createElement('div', { className: 'vx-glass vx-modal', style: { width: 'min(440px, 92vw)' }, onClick: (e: React.MouseEvent) => e.stopPropagation() },
        React.createElement('div', { className: 'vx-pop-head' }, React.createElement('span', null, `填写变量 · ${prompt.name}`)),
        names.map((name) => React.createElement('label', { key: name, className: 'vx-col' }, React.createElement('span', { className: 'vx-muted' }, name), React.createElement('input', { className: 'vx-input', value: s.templateValues[name] ?? '', onChange: (e: React.ChangeEvent<HTMLInputElement>) => setS({ templateValues: { ...S.templateValues, [name]: e.target.value } }) }))),
        React.createElement('div', { className: 'vx-row vx-pad-sm' }, React.createElement('button', { className: 'vx-btn', onClick: submit }, '插入'), React.createElement('button', { className: 'vx-btn', onClick: () => setS({ templatePrompt: null, templateValues: {} }) }, '取消')),
      ),
    )
  }

  function MermaidInPlace(): React.ReactElement | null {
    const s = useS()
    const enabled = s.cfg.mermaid === true
    const dark = s.dark
    React.useEffect(() => {
      if (!enabled) {
        restoreMermaidBlocks()
        return
      }
      const d = typeof document !== 'undefined' ? document : null
      const w = typeof window !== 'undefined' ? window : null
      if (d === null || d.body === null || w === null || w.MutationObserver === undefined) return
      let timer: ReturnType<typeof setTimeout> | null = null
      let stopped = false
      const scan = (): void => { if (!stopped) void scanMermaidBlocks(dark) }
      const schedule = (): void => {
        if (timer !== null) clearTimeout(timer)
        timer = setTimeout(scan, 400)
      }
      if (mmdLastDark !== null && mmdLastDark !== dark) {
        // Theme flipped: drop the memo so existing diagrams re-render.
        for (const block of Array.from(d.querySelectorAll<HTMLElement>('.md-code-block'))) delete block.dataset.vxMmd
      }
      mmdLastDark = dark
      scan()
      // Chat history loads, streaming fences and re-renders all mutate the
      // conversation subtree; one debounced body-wide observer covers them.
      const observer = new MutationObserver(schedule)
      observer.observe(d.body, { childList: true, subtree: true, characterData: true })
      return () => {
        stopped = true
        observer.disconnect()
        if (timer !== null) { clearTimeout(timer); timer = null }
      }
      // dark re-runs the effect: diagrams re-render under the flipped theme.
    }, [enabled, dark])
    return null
  }

  function MermaidModal(): React.ReactElement | null {
    const s = useS()
    const mm = s.mermaidModal
    const [svg, setSvg] = React.useState<string | null>(null)
    const [err, setErr] = React.useState<string | null>(null)
    const [loading, setLoading] = React.useState(false)
    const [liveUrl, setLiveUrl] = React.useState('#')
    React.useEffect(() => {
      if (mm === null) return
      let alive = true
      setSvg(null)
      setErr(null)
      setLoading(true)
      void (async () => {
        const url = await mermaidLiveUrl(mm.codes[mm.index])
        if (!alive) return
        setLiveUrl(url)
        const ready = await ensureMermaid()
        if (!alive) return
        if (!ready) { setErr('Mermaid 引擎加载失败（网络不可达？）。可点击下方按钮在 mermaid.live 打开'); setLoading(false); return }
        const r = await renderMermaid(mm.codes[mm.index], S.dark)
        if (!alive) return
        if (r.ok === true) setSvg(r.svg)
        else setErr(r.error)
        setLoading(false)
      })()
      return () => { alive = false }
    }, [mm])
    if (mm === null) return null
    return React.createElement('div', { className: 'vx-modal-mask', onClick: () => setS({ mermaidModal: null }) },
      React.createElement('div', { className: 'vx-glass vx-modal', onClick: (e: React.MouseEvent) => e.stopPropagation() },
        React.createElement('div', { className: 'vx-pop-head' },
          React.createElement('span', null, `${mm.title} (${mm.index + 1}/${mm.codes.length})`),
          React.createElement('span', { className: 'vx-row' },
            mm.codes.length > 1 ? React.createElement('button', { className: 'vx-chip', title: '上一个', onClick: () => setS({ mermaidModal: { ...mm, index: (mm.index + mm.codes.length - 1) % mm.codes.length } }) }, React.createElement(Icon, { n: 'chevronRight', size: 12, style: { transform: 'rotate(180deg)' } })) : null,
            mm.codes.length > 1 ? React.createElement('button', { className: 'vx-chip', title: '下一个', onClick: () => setS({ mermaidModal: { ...mm, index: (mm.index + 1) % mm.codes.length } }) }, React.createElement(Icon, { n: 'chevronRight', size: 12 })) : null,
            React.createElement('a', { className: 'vx-chip vx-link', href: liveUrl, target: '_blank', rel: 'noopener noreferrer' }, '在 mermaid.live 打开'),
            React.createElement('button', { className: 'vx-chip', title: '关闭', onClick: () => setS({ mermaidModal: null }) }, React.createElement(Icon, { n: 'x', size: 12 })),
          ),
        ),
        loading ? React.createElement('div', { className: 'vx-muted vx-pad' }, '渲染中…') : null,
        err !== null ? React.createElement('div', { className: 'vx-error vx-pad' }, err) : null,
        svg !== null ? React.createElement('div', { className: 'vx-svgbox', dangerouslySetInnerHTML: { __html: svg } }) : null,
      ),
    )
  }

  function CommandPalette(props: { useSessions: OverlayProps['useSessions']; useWorkspaces: OverlayProps['useWorkspaces'] }): React.ReactElement | null {
    const s = useS()
    const sessionsState = useSessionsSafe(props)
    const workspacesState = useWorkspacesSafe(props)
    // The session list snapshot intentionally exposes only the monotone
    // `phase` (errors stay on the service's internal state axis), so a null
    // hook result is the only reliable unavailable signal here.
    const sessionsUnavailable = sessionsState === null
    const workspacesUnavailable = workspacesState === null || workspacesState.state === 'error'
    const [query, setQuery] = React.useState('')
    const [index, setIndex] = React.useState(0)
    const [remote, setRemote] = React.useState<Array<{ sessionId: string; snippet: string }>>([])
    const [remoteStatus, setRemoteStatus] = React.useState('')
    React.useEffect(() => {
      if (!s.commandOpen || query.trim().length < 2) { setRemote([]); setRemoteStatus(''); return }
      const controller = new AbortController()
      const timer = setTimeout(() => {
        const sessionSearch = sessionRemote()
        if (sessionSearch === undefined) { setRemoteStatus(CROSS_SEARCH_UNAVAILABLE); return }
        setRemoteStatus('跨会话搜索中…')
        try {
          void sessionSearch.search({ query: query.trim() }, controller.signal).then((result) => {
            if (controller.signal.aborted) return
            if (result.ok) { setRemote(result.value.items); setRemoteStatus('') }
            else {
              setRemote([]); setRemoteStatus(remoteErrorMessage(result.error, CROSS_SEARCH_UNAVAILABLE))
            }
          }).catch(() => { if (!controller.signal.aborted) { setRemote([]); setRemoteStatus(CROSS_SEARCH_UNAVAILABLE) } })
        } catch { if (!controller.signal.aborted) { setRemote([]); setRemoteStatus(CROSS_SEARCH_UNAVAILABLE) } }
      }, 250)
      return () => { clearTimeout(timer); controller.abort() }
    }, [query, s.commandOpen])
    if (!s.commandOpen) return null
    interface Command { key: string; label: string; detail: string; run: () => void; disabled?: boolean }
    const commands: Command[] = [
      { key: 'balance', label: '打开额度与用量', detail: '功能', run: () => setS({ commandOpen: false, panelOpen: true, panelTab: 'balance' }) },
      { key: 'export', label: '导出当前会话', detail: S.sessionId === null ? '当前没有打开的会话' : 'Markdown', disabled: S.sessionId === null, run: () => { setS({ commandOpen: false }); runExport('markdown') } },
      { key: 'search-current', label: '搜索当前会话', detail: S.sessionId === null ? '当前没有打开的会话' : '功能', disabled: S.sessionId === null, run: () => setS({ commandOpen: false, panelOpen: true, panelTab: 'search' }) },
      { key: 'folders', label: '打开项目文件夹', detail: '功能', run: () => setS({ commandOpen: false, foldersOpen: true, panelOpen: false }) },
      { key: 'prompts', label: '打开提示词库', detail: '功能', run: () => setS({ commandOpen: false, panelOpen: true, panelTab: 'prompt' }) },
      { key: 'tools', label: '打开效率工具', detail: '功能', run: () => setS({ commandOpen: false, panelOpen: true, panelTab: 'tools' }) },
      ...(sessionsUnavailable ? [{ key: 'sessions-unavailable', label: '打开会话', detail: sessionsState === null ? '会话服务不可用' : '会话列表加载失败', disabled: true, run: () => {} }] : []),
      ...(workspacesUnavailable ? [{ key: 'workspaces-unavailable', label: '打开工作区', detail: workspacesState === null ? '工作区服务不可用' : '工作区列表加载失败', disabled: true, run: () => {} }] : []),
      ...S.prompts.map((prompt) => ({ key: `prompt-${prompt.id}`, label: prompt.name, detail: S.insertDraft === null ? '当前没有可用输入框' : '提示词', disabled: S.insertDraft === null, run: () => { setS({ commandOpen: false }); insertPrompt(prompt) } })),
      ...(sessionsUnavailable ? [] : (sessionsState?.ids ?? []).map((id) => ({ key: `session-${id}`, label: sessionsState?.byId[id]?.displayTitle || sessionsState?.byId[id]?.title || id, detail: '会话', run: () => { setS({ commandOpen: false }); openSessionItem(id) } }))),
      ...(workspacesUnavailable ? [] : (workspacesState?.items ?? []).map((workspace) => ({ key: `workspace-${workspace.workspaceId}`, label: workspace.title || workspace.path || workspace.workspaceId, detail: '工作区', run: () => { setS({ commandOpen: false }); void openWorkspaceItem(workspace.workspaceId) } }))),
      ...remote.map((item) => ({ key: `remote-${item.sessionId}`, label: item.snippet || item.sessionId, detail: '全文搜索结果', run: () => { setS({ commandOpen: false }); openSessionItem(item.sessionId) } })),
    ]
    const q = query.toLowerCase()
    const visible = commands.filter((item) => q === '' || item.label.toLowerCase().includes(q) || item.detail.toLowerCase().includes(q)).slice(0, 50)
    const chosen = Math.max(0, Math.min(index, visible.length - 1))
    return React.createElement('div', { className: 'vx-modal-mask', onClick: () => setS({ commandOpen: false }) },
      React.createElement('div', { className: 'vx-glass vx-modal', style: { width: 'min(620px, 94vw)' }, onClick: (e: React.MouseEvent) => e.stopPropagation() },
        React.createElement('input', { className: 'vx-input', autoFocus: true, placeholder: '搜索会话、工作区、提示词或功能…', value: query, onChange: (e: React.ChangeEvent<HTMLInputElement>) => { setQuery(e.target.value); setIndex(0) }, onKeyDown: (e: React.KeyboardEvent) => { if (e.key === 'ArrowDown') { e.preventDefault(); setIndex(Math.min(visible.length - 1, chosen + 1)) } else if (e.key === 'ArrowUp') { e.preventDefault(); setIndex(Math.max(0, chosen - 1)) } else if (e.key === 'Enter') { e.preventDefault(); const command = visible[chosen]; if (command !== undefined && command.disabled !== true) command.run() } else if (e.key === 'Escape') setS({ commandOpen: false }) } }),
        React.createElement('div', { className: 'vx-list' }, visible.map((command, itemIndex) => React.createElement('button', { key: command.key, className: 'vx-list-item' + (itemIndex === chosen ? ' on' : ''), disabled: command.disabled === true, onMouseEnter: () => setIndex(itemIndex), onClick: command.run }, React.createElement('span', null, command.label), React.createElement('span', { className: 'vx-muted' }, command.detail)))),
        remoteStatus !== '' ? React.createElement('div', { className: 'vx-muted vx-pad-sm' }, remoteStatus) : null,
        visible.length === 0 ? React.createElement('div', { className: 'vx-muted vx-pad-sm' }, '没有匹配项') : null,
      ),
    )
  }

  function BatchModal(props: { useSessions: OverlayProps['useSessions'] }): React.ReactElement | null {
    const s = useS()
    const [sel, setSel] = React.useState<Record<string, boolean>>({})
    const [q, setQ] = React.useState('')
    const sessions = useSessionsSafe(props)
    const ids = sessions !== null ? (sessions.ids ?? []) : []
    const byId = sessions !== null ? (sessions.byId as unknown as Record<string, { displayTitle?: string; title?: string; running?: boolean }>) : {}
    const filtered = ids.filter((id) => {
      const sum = byId[id]
      if (sum === undefined) return false
      if (q !== '') {
        const t = String(sum.displayTitle || sum.title || id).toLowerCase()
        if (!t.includes(q.toLowerCase())) return false
      }
      return true
    })
    const selCount = Object.keys(sel).length
    const batchArchive = async (targetIds: string[]): Promise<void> => {
      const workspaces = C.get('workspaces') as { archiveSession(id: string): Promise<void> } | undefined
      if (workspaces === undefined || typeof workspaces.archiveSession !== 'function') { toast('归档服务不可用', 'error'); return }
      const running = new Set(Object.keys(byId).filter((id) => byId[id]?.running === true))
      const { succeeded, failed, results } = await archiveBatch(targetIds, running, (id) => workspaces.archiveSession(id))
      setS({ batchModal: false })
      if (failed === 0) toast(`已归档 ${succeeded} 个会话`, 'info')
      else {
        const details = results.filter((item) => !item.ok).slice(0, 3).map((item) => `${item.id}: ${item.error ?? '失败'}`).join('；')
        toast(`归档完成：成功 ${succeeded}，失败 ${failed}${details === '' ? '' : `；${details}`}`, 'error')
      }
    }
    return React.createElement('div', { className: 'vx-modal-mask', onClick: () => setS({ batchModal: false }) },
      React.createElement('div', { className: 'vx-glass vx-modal', style: { width: 'min(560px, 92vw)' }, onClick: (e: React.MouseEvent) => e.stopPropagation() },
        React.createElement('div', { className: 'vx-pop-head' },
          React.createElement('span', null, '批量归档会话'),
          React.createElement('button', { className: 'vx-chip', title: '关闭', onClick: () => setS({ batchModal: false }) }, React.createElement(Icon, { n: 'x', size: 12 })),
        ),
        React.createElement('div', { className: 'vx-muted vx-pad-sm' }, '将选中的会话归档；运行中的会话不可选。DSH 当前未公开恢复接口，本插件不提供恢复入口。'),
        React.createElement('div', { className: 'vx-row vx-pad-sm' },
          React.createElement(Icon, { n: 'search', size: 13 }),
          React.createElement('input', { className: 'vx-input', placeholder: '搜索会话…', value: q, onChange: (e: React.ChangeEvent<HTMLInputElement>) => setQ(e.target.value) }),
          React.createElement('button', { className: 'vx-btn', onClick: () => { const all: Record<string, boolean> = {}; for (const id of filtered) if (byId[id]?.running !== true) all[id] = true; setSel(all) } }, '全选可归档'),
          React.createElement('button', { className: 'vx-btn', onClick: () => setSel({}) }, '清空'),
        ),
        React.createElement('div', { className: 'vx-list' },
          filtered.map((id) => {
            const sum = byId[id]
            const running = sum?.running === true
            return React.createElement('label', { key: id, className: 'vx-check-row' },
              React.createElement('input', { type: 'checkbox', disabled: running, checked: sel[id] === true, onChange: (e: React.ChangeEvent<HTMLInputElement>) => { const next = { ...sel }; if (e.target.checked) next[id] = true; else delete next[id]; setSel(next) } }),
              React.createElement('span', { className: 'vx-check-title' }, sum !== undefined ? (sum.displayTitle || sum.title || id) : id),
              running ? React.createElement('span', { className: 'vx-badge' }, '运行中，不可归档') : null,
            )
          }),
        ),
        React.createElement('div', { className: 'vx-row vx-pad-sm' },
          React.createElement('button', { className: 'vx-btn vx-btn-danger', disabled: selCount === 0, onClick: () => askConfirm(`确认归档选中的 ${selCount} 个会话？`, (ok) => { if (ok) void batchArchive(Object.keys(sel)) }) },
            React.createElement(Icon, { n: 'trash', size: 12 }), ` 归档选中 (${selCount})`),
          React.createElement('button', { className: 'vx-btn', onClick: () => setS({ batchModal: false }) }, '取消'),
        ),
      ),
    )
  }

  function PanelBody(props: { useSessions: OverlayProps['useSessions']; useWorkspaces: OverlayProps['useWorkspaces'] }): React.ReactElement {
    const s = useS()
    if (s.panelTab === 'look') return React.createElement(AppearanceTab, null)
    if (s.panelTab === 'folder') return React.createElement(FoldersTab, { useSessions: props.useSessions, useWorkspaces: props.useWorkspaces })
    if (s.panelTab === 'prompt') return React.createElement(PromptsTab, null)
    if (s.panelTab === 'search') return React.createElement(SearchTab, null)
    if (s.panelTab === 'export') return React.createElement(ExportTab, null)
    if (s.panelTab === 'mermaid') return React.createElement(MermaidTab, null)
    if (s.panelTab === 'tools') return React.createElement(ToolsTab, null)
    if (s.panelTab === 'balance') return React.createElement(BalancePanelContent, null)
    return React.createElement(AboutTab, null)
  }

  function PersonalizePanel(props: { useSessions: OverlayProps['useSessions']; useWorkspaces: OverlayProps['useWorkspaces'] }): React.ReactElement {
    const s = useS()
    const ref = React.useRef<HTMLDivElement | null>(null)
    const TABS: Array<[string, string, string]> = [['look', 'sliders', '外观'], ['folder', 'folder', '项目'], ['prompt', 'zap', '提示词'], ['search', 'search', '搜索'], ['export', 'download', '导出'], ['mermaid', 'gitBranch', 'Mermaid'], ['tools', 'wrench', '效率'], ['balance', 'wallet', '额度'], ['about', 'info', '关于']]
    const onHeadDown = (e: React.MouseEvent): void => {
      const target = e.target as HTMLElement
      if (target.tagName === 'BUTTON' || target.tagName === 'A' || target.tagName === 'INPUT') return
      const el = ref.current
      if (el === null) return
      const rect = el.getBoundingClientRect()
      const start = { mx: e.clientX, my: e.clientY, x: rect.left, y: rect.top }
      const d = typeof document !== 'undefined' ? document : null
      if (d === null) return
      let final: { x: number; y: number } | null = null
      const move = (ev: MouseEvent): void => {
        // Direct DOM writes during the drag: publishing through the store
        // would re-render every subscriber at mousemove rate for one
        // element's position. The store only learns the resting place.
        final = { x: start.x + ev.clientX - start.mx, y: start.y + ev.clientY - start.my }
        el.style.left = `${final.x}px`
        el.style.top = `${final.y}px`
        el.style.right = 'auto'
      }
      const up = (): void => {
        d.removeEventListener('mousemove', move)
        d.removeEventListener('mouseup', up)
        if (final !== null) setS({ panelPos: final })
      }
      d.addEventListener('mousemove', move)
      d.addEventListener('mouseup', up)
    }
    const style: React.CSSProperties = { top: 74, left: undefined, right: undefined }
    if (s.panelPos !== null) { style.top = s.panelPos.y; style.left = s.panelPos.x; style.right = undefined }
    else style.right = 76
    return React.createElement('div', { ref, className: 'vx-glass vx-panel', style },
      React.createElement('div', { className: 'vx-panel-head', onMouseDown: onHeadDown },
        React.createElement(Icon, { n: 'sliders', size: 14 }),
        React.createElement('span', { className: 'vx-panel-title' }, '个性化中心'),
        React.createElement('span', { className: 'vx-panel-sub' }, '外观 · 效率 · 额度'),
        React.createElement('span', { className: 'vx-flex1' }),
        React.createElement('button', { className: 'vx-chip', title: '关闭', onClick: () => setS({ panelOpen: false }) }, React.createElement(Icon, { n: 'x', size: 12 })),
      ),
      React.createElement('div', { className: 'vx-tabs' },
        TABS.map((t) => React.createElement('button', { key: t[0], className: 'vx-tab' + (s.panelTab === t[0] ? ' on' : ''), onClick: () => setS({ panelTab: t[0] }) },
          React.createElement(Icon, { n: t[1], size: 12 }), ' ' + t[2])),
      ),
      React.createElement('div', { className: 'vx-panel-body' },
        React.createElement(PanelBody, { useSessions: props.useSessions, useWorkspaces: props.useWorkspaces }),
      ),
    )
  }

  function SidebarFoldersPanel(props: { useSessions: OverlayProps['useSessions']; useWorkspaces: OverlayProps['useWorkspaces'] }): React.ReactElement | null {
    const s = useS()
    if (s.foldersOpen !== true) return null
    return React.createElement('div', { className: 'vx-glass vx-folders' },
      React.createElement('div', { className: 'vx-pop-head' },
        React.createElement(Icon, { n: 'folder', size: 14 }),
        React.createElement('span', null, '项目文件夹'),
        React.createElement('span', { className: 'vx-flex1' }),
        React.createElement('button', { className: 'vx-chip', title: '新建文件夹', onClick: () => askText('文件夹名称：', '', (name) => {
          if (name.trim() === '') return
          S.folders = S.folders.concat({ id: 'f' + Date.now() + Math.floor(Math.random() * 9999), name, children: [], sessionIds: [], workspaceIds: [], prompts: [] })
          setS({ folders: S.folders })
          saveCfg()
        }) }, React.createElement(Icon, { n: 'folderPlus', size: 12 })),
        React.createElement('button', { className: 'vx-chip', title: '关闭', onClick: () => setS({ foldersOpen: false }) }, React.createElement(Icon, { n: 'x', size: 12 })),
      ),
      React.createElement('div', { className: 'vx-folders-body' },
        S.folders.length === 0 ? React.createElement('div', { className: 'vx-muted vx-pad-sm' }, '暂无文件夹。在个性化中心可管理，或点击右上角新建。') : null,
        S.folders.map((f) => React.createElement(FolderNode, { key: f.id, node: f, useSessions: props.useSessions, useWorkspaces: props.useWorkspaces })),
      ),
    )
  }

  function SettingsPage(): React.ReactElement {
    return React.createElement('div', { className: 'vx-settings-page' },
      React.createElement(AppearanceTab, null),
      React.createElement('div', { className: 'vx-section-title' }, '功能开关'),
      React.createElement(ToolsTab, null),
      React.createElement(MermaidTab, null),
    )
  }

  function Toasts(): React.ReactElement {
    const s = useS()
    return React.createElement('div', { className: 'vx-toasts' },
      s.toasts.map((t) => React.createElement('div', { key: t.id, className: 'vx-toast' + (t.kind === 'error' ? ' err' : '') },
        React.createElement(Icon, { n: t.kind === 'error' ? 'x' : (t.kind === 'success' ? 'check' : 'info'), size: 13 }),
        React.createElement('span', null, t.text),
        t.action !== null ? React.createElement('button', { className: 'vx-chip', onClick: () => { try { t.action?.run() } catch { /* action failed */ } } }, t.action.label) : null,
      )),
    )
  }

  function OverlayRoot(props: OverlayProps): React.ReactElement {
    const s = useS()
    /** 当前 GUI 实际配色。主题服务已解析的快照最权威（覆盖 GUI 内全局深色
     * 切换，与 OS 偏好无关）；其次 body 上呈现器维护的 data-ds-dark-theme；
     * 最后兜底操作系统 prefers-color-scheme。 */
    const readDark = (): boolean => {
      try {
        const theme = C.get('theme')
        if (theme !== undefined) {
          const scheme = theme.getTheme()?.active?.colorScheme
          if (scheme === 'dark') return true
          if (scheme === 'light') return false
        }
      } catch { /* theme service not ready yet */ }
      const d = typeof document !== 'undefined' ? document : null
      if (d !== null && d.body !== null && d.body.hasAttribute('data-ds-dark-theme')) return true
      const w = typeof window !== 'undefined' ? window : null
      if (w !== null && w.matchMedia !== undefined && w.matchMedia('(prefers-color-scheme: dark)').matches) return true
      return false
    }
    React.useEffect(() => { void loadCfg() }, [])
    React.useEffect(() => {
      const d = typeof document !== 'undefined' ? document : null
      if (d === null) return
      const onKey = (event: KeyboardEvent): void => {
        const target = event.target as HTMLElement | null
        if (!isCommandPaletteShortcut(event, target)) return
        event.preventDefault()
        setS({ commandOpen: !S.commandOpen })
      }
      d.addEventListener('keydown', onKey)
      return () => d.removeEventListener('keydown', onKey)
    }, [])
    React.useEffect(() => { if (s.booted) applyAppearance() }, [s.booted, s.cfg.bg, s.cfg.glass, s.cfg.glassMode, s.cfg.globalGlass, s.dark])
    React.useEffect(() => {
      syncAntiScroll(s.cfg.antiScroll === true)
      // Unmount/disable must restore scroll-behavior on every element this
      // page-global effect touched; otherwise the GUI keeps the forced
      // `auto` behavior after the plugin is gone.
      return () => { syncAntiScroll(false) }
    }, [s.cfg.antiScroll])
    React.useEffect(() => {
      const w = typeof window !== 'undefined' ? window : null
      const d = typeof document !== 'undefined' ? document : null
      const applyDark = (dark: boolean): void => {
        // Palette backgrounds follow the theme now (dark variants are
        // derived), so a flip only needs to re-render and re-paint.
        S.dark = dark
        setS({ dark })
      }
      applyDark(readDark())
      // GUI 全局主题切换（权威：主题服务事件，覆盖浅/深/system 偏好）
      let offTheme: (() => boolean) | undefined
      try {
        offTheme = C.on('theme/change', (snap) => applyDark(snap.active?.colorScheme === 'dark'))
      } catch { /* theme event unavailable */ }
      // OS 配色变化（system 偏好时主题服务也会重发 theme/change，此处幂等兜底）
      let mq: MediaQueryList | undefined
      let onMq: ((e: MediaQueryListEvent) => void) | undefined
      if (w !== null && w.matchMedia !== undefined) {
        mq = w.matchMedia('(prefers-color-scheme: dark)')
        onMq = (): void => applyDark(readDark())
        if (typeof mq.addEventListener === 'function') mq.addEventListener('change', onMq)
        else if (typeof mq.addListener === 'function') mq.addListener(onMq as () => void)
      }
      // DOM 兜底：body[data-ds-dark-theme] 由主题呈现器按快照维护
      let observer: MutationObserver | null = null
      if (d !== null && d.body !== null && typeof MutationObserver === 'function') {
        observer = new MutationObserver(() => applyDark(readDark()))
        observer.observe(d.body, { attributes: true, attributeFilter: ['data-ds-dark-theme'] })
      }
      return () => {
        if (offTheme !== undefined) { try { offTheme() } catch { /* already removed */ } }
        if (mq !== undefined && onMq !== undefined) {
          if (typeof mq.removeEventListener === 'function') mq.removeEventListener('change', onMq)
          else if (typeof mq.removeListener === 'function') mq.removeListener(onMq as () => void)
        }
        if (observer !== null) observer.disconnect()
      }
    }, [])
    React.useEffect(() => {
      // boot 时再对一次表：此刻主题服务必然就绪，避免启动窗口期的误判
      const dark = readDark()
      S.dark = dark
      setS({ dark })
    }, [s.booted])
    // Mirror the resolved GUI theme onto <html>: the glass fill rules are
    // theme-scoped at :root so they reach every surface with one selector —
    // including ones mounted outside .vx-root (the balance hover), which the
    // .vx-root-scoped rules can never match.
    React.useEffect(() => {
      const d = typeof document !== 'undefined' ? document : null
      if (d === null) return
      d.documentElement.classList.toggle('vx-dark', s.dark === true)
      d.documentElement.classList.toggle('vx-light', s.dark !== true)
    }, [s.dark])
    // Refresh the turns data while the session is streaming: the turn-tail
    // chips (LaTeX / MathML / Mermaid) appear as soon as the next fetch lands,
    // without waiting for a session switch to trigger one.
    const sessions = useSessionsSafe(props)
    const summary = sessions !== null && s.sessionId !== null ? sessions.byId[s.sessionId] : null
    React.useEffect(() => {
      const watchedId = S.sessionId
      if (watchedId === null) return
      const running = summary?.running === true
      if (!running) return
      let inFlight = false
      const tick = (): void => {
        if (inFlight) return
        const d = typeof document !== 'undefined' ? document : null
        // Background tabs do not need a full log replay every 3 seconds; the
        // visibility handler catches up immediately on return.
        if (d !== null && d.hidden) return
        const id = S.sessionId
        if (id === null) return
        inFlight = true
        void fetchTurns(id).finally(() => { inFlight = false })
      }
      const handle = setInterval(tick, 3000)
      const onVisibility = (): void => {
        const d = typeof document !== 'undefined' ? document : null
        if (d === null || !d.hidden) tick()
      }
      if (typeof document !== 'undefined') document.addEventListener('visibilitychange', onVisibility)
      return () => {
        clearInterval(handle)
        if (typeof document !== 'undefined') document.removeEventListener('visibilitychange', onVisibility)
        // The run just ended (or the effect re-ran): take one final snapshot
        // so the last streamed turn's chips land without a manual session
        // switch. A session switch is handled by useViewedSession, so only
        // fetch when the watched session is still the selected one.
        if (!disposed && S.sessionId === watchedId) void fetchTurns(watchedId)
      }
    }, [s.sessionId, summary?.running])
    const children: React.ReactElement[] = [React.createElement(FxCanvas, { key: 'fx' })]
    children.push(React.createElement(MermaidInPlace, { key: 'mmd' }))
    if (s.panelOpen === true) children.push(React.createElement(PersonalizePanel, { key: 'panel', useSessions: props.useSessions, useWorkspaces: props.useWorkspaces }))
    if (s.foldersOpen === true) children.push(React.createElement(SidebarFoldersPanel, { key: 'folders', useSessions: props.useSessions, useWorkspaces: props.useWorkspaces }))
    if (s.promptOpen !== null) children.push(React.createElement(PromptPopover, { key: 'prompt' }))
    if (s.mermaidModal !== null) children.push(React.createElement(MermaidModal, { key: 'mermaid' }))
    if (s.batchModal === true) children.push(React.createElement(BatchModal, { key: 'batch', useSessions: props.useSessions }))
    if (s.commandOpen === true) children.push(React.createElement(CommandPalette, { key: 'command', useSessions: props.useSessions, useWorkspaces: props.useWorkspaces }))
    if (s.quoteSel !== null && s.cfg.quote === true) children.push(React.createElement(QuoteButton, { key: 'quote' }))
    if (s.ask !== null) children.push(React.createElement(AskModal, { key: 'ask' }))
    if (s.confirmAsk !== null) children.push(React.createElement(ConfirmModal, { key: 'confirm' }))
    if (s.templatePrompt !== null) children.push(React.createElement(TemplateModal, { key: 'template' }))
    children.push(React.createElement(Toasts, { key: 'toasts' }))
    return React.createElement('div', { className: `vx-root ${s.dark ? 'vx-dark' : 'vx-light'}` }, children)
  }

  // ================= install =================
  setDynCss('')
  try { ensureLiquidGlass() } catch (error) { reportDiag('ensureLiquidGlass: ' + String((error as Error)?.message ?? error)) }
  const slots = C.get('slots') as { inject(key: string, fn: () => (() => void) | void): (() => void) | void; register(options: Record<string, unknown>, component: unknown): () => void } | undefined
  if (slots === undefined) {
    console.error('[custom-plugin] slots service unavailable')
    reportDiag('slots service unavailable; surfaces skipped')
    return () => {}
  }
  const unregisterAll: Array<() => void> = []
  const injectedKeys = new Set<string>()
  let injectedCount = 0
  const injectOne = (key: string, id: string, options: Record<string, unknown>, comp: unknown): void => {
    try {
      slots.inject(key, () => {
        try {
          const unregister = slots.register({ name: key, ...options }, comp)
          unregisterAll.push(unregister)
          return unregister
        } catch (error) {
          // `register` runs later, when the host materializes the slot, so it is
          // outside the try below: without this guard a rejected registration
          // (wrong slot kind, bad options) would take the surface down silently
          // while the ring still read green.
          reportDiag('register ' + key + ' (' + id + '): ' + String((error as Error)?.message ?? error))
          return () => {}
        }
      })
      reportDiag('ok ' + key + ' (' + id + ')')
      injectedCount++
      injectedKeys.add(key)
    } catch (error) {
      const message = 'inject ' + key + ' (' + id + '): ' + String((error as Error)?.message ?? error)
      console.error('[custom-plugin] ' + message)
      reportDiag(message)
    }
  }
  injectOne('sidebar.footer.action', 'custom-plugin-folders', { id: 'custom-plugin-folders', order: -100, label: '项目' }, FolderSidebarButton)
  injectOne('shell.overlay', 'custom-plugin-overlay', { id: 'custom-plugin-overlay', order: 10, label: 'Custom 便利套件' }, OverlayRoot)
  injectOne('conversation.input.dock', 'custom-plugin-quote', { id: 'custom-plugin-quote', order: 30, label: '引用回复' }, QuoteDock)
  injectOne('conversation.chat.turnTail', 'custom-plugin-turn-tail', { id: 'custom-plugin-turn-tail', order: 10 }, TurnTailEntry)
  injectOne('settings.section', 'custom-plugin-appearance', { id: 'custom-plugin-appearance', order: 30, label: '个性化' }, SettingsPage)
  injectOne('conversation.session.header.actions', 'custom-plugin-panel-open', { id: 'custom-plugin-panel-open', order: 5, label: '个性化' }, HeaderPanelButton)
  injectOne('conversation.session.header.actions', 'custom-plugin-prompts', { id: 'custom-plugin-prompts', order: 6, label: '提示词' }, PromptQuickButton)
  injectOne('conversation.session.header.utilities', 'custom-plugin-balance', { id: 'custom-plugin-balance', order: -5, label: '额度' }, HeaderBalance)
  // Requests submitted, not surfaces proven: dsh defers the callback above until
  // the slot is declared, so nothing here knows yet whether the host accepted
  // any of them. Materialization reports itself, per slot, through the `ok` /
  // `register` lines this one follows.
  reportDiag(`client installed: ${injectedCount} injection requests / ${injectedKeys.size} slots`)
  return () => {
    disposed = true
    for (const unregister of unregisterAll.splice(0)) {
      try { unregister() } catch { /* already unregistered */ }
    }
    if (loadRetryTimer !== null) {
      clearTimeout(loadRetryTimer)
      loadRetryTimer = null
    }
    if (greetTimer !== null) {
      clearTimeout(greetTimer)
      greetTimer = null
    }
    // Slot teardown unmounts only the React surfaces; the appearance
    // painter's page-global side effects — theme token overrides, root
    // classes, the liquid-glass SVG filter, a pending balance retry — live
    // outside those surfaces and outlive a live disable/re-declare unless
    // reverted here.
    if (tokenDisposer !== null) {
      try { tokenDisposer() } catch { /* best effort */ }
      tokenDisposer = null
    }
    if (balanceRetryTimer !== null) {
      clearTimeout(balanceRetryTimer)
      balanceRetryTimer = null
    }
    // Both settle DOM the plugin owns rather than styles: the anti-scroll
    // attributes and the in-place Mermaid wrappers would otherwise outlive
    // the plugin (the React effect cleanup does not run for entries the host
    // unmounts after this disposer).
    try { syncAntiScroll(false) } catch { /* best effort */ }
    try { restoreMermaidBlocks() } catch { /* best effort */ }
    const d = typeof document !== 'undefined' ? document : null
    if (d !== null) {
      for (const cls of ['vx-liquid', 'vx-dark', 'vx-light']) {
        try { d.documentElement.classList.remove(cls) } catch { /* classList unavailable */ }
      }
      try { d.getElementById('vx-lg-filter')?.remove() } catch { /* node already gone */ }
    }
    removeDynCss()
  }
}
