/**
 * Host service for dsh-custom-plugin: owns the state document and every
 * browser-facing capability (timeline, export, balance, usage scan, Mermaid).
 * The routes in `routes.ts` are a thin HTTP fence over this class.
 * @module @alexpeng/dsh-custom-plugin/host-service
 */

import type { AttachmentStore } from '@deepseek-ai/dsh-attachment'
import type { SessionEventSearchRequest, SessionLogSnapshot, SessionQueryEngine } from '@deepseek-ai/dsh-session-query'
import type { SessionEvent, SessionId } from '@deepseek-ai/dsh-session'
import { createRequire } from 'node:module'
import { readFileSync } from 'node:fs'
import { readFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { buildExportRows, buildMarkdown, buildPdfHtml, eventSearchText, extractTurns, searchKindOf, snippetAround } from './extract.ts'
import { readDeepSeekCredential } from './credentials.ts'
import { SystemCredentialStore, type CredentialStore } from './system-credentials.ts'
import type { BackupImportMode, BalanceInfo, ConversationSearchItem, ConversationSearchKind, ConversationSearchResult, CredentialStorage, CustomPluginBackupV1, CustomPluginPublicState, CustomPluginState, TimelineItem, UsageRow } from './protocol.ts'
import { aggregateDayUsage, createUsageRow, dayKey, foldUsageRecord, isPeakHour, mergeUsageRow, pruneUsage, type UsageRecord } from './usage.ts'
import { backupPreview, createBackup, importedState, parseBackup, writeRecoveryBackup } from './backup.ts'
import { normalizeCfg, normalizeFolders, normalizePrompt, normalizeStars } from './state.ts'

const USAGE_SCAN_CONCURRENCY = 4

/** CDN fallback version: the exact package this build ships. A hardcoded
 * `mermaid@11.6.0` while the local dependency resolved 11.17.x made the
 * offline and fallback engines diverge in behavior. */
const MERMAID_CDN_VERSION = resolveMermaidVersion()

function resolveMermaidVersion(): string {
  try {
    const require = createRequire(import.meta.url)
    const pkg = JSON.parse(readFileSync(require.resolve('mermaid/package.json'), 'utf8')) as { version?: unknown }
    if (typeof pkg.version === 'string' && /^\d+\.\d+\.\d+/.test(pkg.version)) return pkg.version
  } catch {
    // dependency absent (e.g. an installed package missing the optional tree)
  }
  return '11.6.0'
}

type UsageScanResult = { ok: true; day: string; usageToday: unknown; scannedSessions: number } | { ok: false; error: string }
type MermaidFetchResult = { ok: true; bytes: number } | { ok: false; error: string }

interface ScanEntry {
  readable: boolean
  /** Live usage arrived before this session's read: the whole replay is
   * already invalidated, later sessions were not even read. */
  stale?: boolean
  usage: Record<string, UsageRow>
}

async function mapConcurrent<T, R>(items: readonly T[], limit: number, worker: (item: T) => Promise<R>): Promise<R[]> {
  const results = new Array<R>(items.length)
  let next = 0
  const run = async (): Promise<void> => {
    while (true) {
      const index = next++
      if (index >= items.length) return
      results[index] = await worker(items[index])
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, () => run()))
  return results
}

/** Options the loader entry supplies to the host service. */
export interface CustomPluginHostOptions {
  sessionQuery: SessionQueryEngine
  /** Persisted state document (mutated in place; the loader owns saving). */
  state: CustomPluginState
  /** Resolve the absolute state file path for diagnostics. */
  statePath: () => string
  /** Persist the state document now. */
  saveNow: () => Promise<void>
  /** Record a bounded client diagnostic line. */
  reportDiag: (message: string) => void
  /** Bounded diagnostic ring for the status tool. */
  diagReports: string[]
  /** Optional attachment store used to embed images into PDF exports. */
  attachments?: AttachmentStore | undefined
  /** Test seam: return the local mermaid engine file path (or null). */
  localMermaidPath?: () => string | null
  /** Test seam: read the DeepSeek credential from DSH's credentials file. */
  readCredential?: () => Promise<string>
  /** Test seam and optional platform adapter for OS credential storage. */
  credentialStore?: CredentialStore
}

/** Host capabilities behind the routes and the agent tool. */
export class CustomPluginHost {
  private readonly sessionQuery: SessionQueryEngine
  private readonly state: CustomPluginState
  private readonly statePath: () => string
  private readonly persistNow: () => Promise<void>
  private readonly diagReports: string[]
  private readonly attachments: AttachmentStore | undefined
  private readonly credentialStore: CredentialStore
  private readonly sessionModel = new Map<string, string | null>()
  // Serialize asynchronous state mutations (edits, imports, and scans).
  // Session events are synchronous, so they are queued while an operation is
  // waiting on disk or session I/O and folded before the next operation.
  private stateOperation: Promise<void> = Promise.resolve()
  private stateOperationActive = false
  private stateOperationPending = 0
  private readonly queuedUsage: Array<{ usage: UsageRecord; time?: number; model: string }> = []
  private usageScanPromise: Promise<UsageScanResult> | null = null
  private usageRevision = 0
  private lastUsagePruneDay = ''
  private mermaidFetchPromise: Promise<MermaidFetchResult> | null = null
  private mermaidBytesValue = 0
  private mermaidJs = ''
  private mermaidSource = ''
  private mermaidEtagValue = ''
  private localMermaidPath: () => string | null
  private readCredential: () => Promise<string>
  // The credential resolution hits the OS keychain plus a file read; both
  // /state GET and every save response report it, so the *source* verdict
  // (never the key) is cached briefly. applyEdit and the legacy migration
  // invalidate, which keeps a save response truthful about the edit just
  // applied.
  private credentialCache: { at: number; status: Pick<CustomPluginPublicState, 'apiKeyConfigured' | 'credentialStorage'> } | null = null
  private static readonly CREDENTIAL_CACHE_TTL_MS = 5000

  constructor(options: CustomPluginHostOptions) {
    this.sessionQuery = options.sessionQuery
    this.state = options.state
    this.statePath = options.statePath
    this.persistNow = options.saveNow
    this.diagReports = options.diagReports
    this.attachments = options.attachments
    this.credentialStore = options.credentialStore ?? new SystemCredentialStore()
    this.localMermaidPath = options.localMermaidPath ?? defaultLocalMermaidPath
    this.readCredential = options.readCredential ?? readDeepSeekCredential
  }

  /** Persisted state document (debounced by the loader entry). */
  async persist(): Promise<void> {
    await this.persistNow()
  }

  /** Read one complete session log snapshot. `readSession` replay-validates
   * through a snapshot-mode constructor that rejects any seeded (forked or
   * resumed) session whose log outgrew its seed boundary — newer dsh builds
   * then fail every read with "seeded session constructor seed must equal its
   * inherited prefix". `observeSession` serves the same log through its
   * live/restore paths without that constructor, so fall back to it before
   * surfacing the error. */
  private async readSessionLog(sessionId: string): Promise<SessionLogSnapshot> {
    const id = sessionId as SessionId
    try {
      return await this.sessionQuery.readSession(id)
    } catch (error) {
      // The guard stays on purpose: a host without this observation API must
      // still surface readSession's own error, not a TypeError about a method.
      const { observeSession } = this.sessionQuery
      if (typeof observeSession !== 'function') throw error
      const lease = await observeSession.call(this.sessionQuery, id, { projectionMode: 'none' })
      const events = [...lease.events]
      const disposeSymbol = (Symbol as { dispose?: symbol }).dispose
      if (disposeSymbol !== undefined) {
        const dispose = (lease as unknown as Record<symbol, unknown>)[disposeSymbol]
        if (typeof dispose === 'function') (dispose as () => void).call(lease)
      }
      return { session: lease.header, events } as unknown as SessionLogSnapshot
    }
  }

  /** Persist after all queued state mutations have reached a stable point. */
  async persistWhenIdle(): Promise<void> {
    await this.runStateOperation(() => this.persist())
  }

  private runStateOperation<T>(operation: () => Promise<T>): Promise<T> {
    this.stateOperationPending++
    // Mark the gate synchronously, before the promise continuation runs. A
    // session event delivered in the same turn as an import/edit must not
    // slip into a stale snapshot between scheduling and execution.
    this.stateOperationActive = true
    const run = this.stateOperation.catch(() => {}).then(async () => {
      try {
        return await operation()
      } finally {
        // Keep the gate closed while persisting the queued events. This
        // avoids a tiny window in which a new event could bypass the flush.
        while (this.queuedUsage.length > 0) {
          const pending = this.queuedUsage.splice(0)
          for (const item of pending) this.foldUsageNow(item.usage, item.time, item.model)
          try {
            await this.persist()
          } catch (error) {
            this.pushDiag(`queued usage save failed: ${String((error as Error)?.message ?? error)}`)
          }
        }
        this.stateOperationPending--
        if (this.stateOperationPending === 0) this.stateOperationActive = false
      }
    })
    this.stateOperation = run.then(() => {}, () => {})
    return run
  }

  /** Record a bounded client diagnostic line. */
  pushDiag(message: string): void {
    this.diagReports.push(String(message ?? '').slice(0, 400))
    if (this.diagReports.length > 20) this.diagReports.splice(0, this.diagReports.length - 20)
  }

  /** Track the model of each session's latest request. */
  rememberModel(sessionId: string, model: string | null): void {
    this.sessionModel.set(sessionId, model)
  }

  forgetSession(sessionId: string): void {
    this.sessionModel.delete(sessionId)
  }

  /** Fold one assistant/message usage record into the ledger. The event time
   * decides both the day bucket and the peak/off-peak portion. */
  foldUsage(sessionId: string, usage: UsageRecord, time?: number, modelOverride?: string | null): void {
    const model = modelOverride !== undefined ? (modelOverride ?? 'unknown') : (this.sessionModel.get(sessionId) ?? 'unknown')
    if (this.stateOperationActive) {
      this.queuedUsage.push({ usage, time, model })
      // Count the arrival immediately so an in-flight replay cannot replace
      // the ledger with a snapshot that predates this event.
      this.usageRevision++
      return
    }
    this.foldUsageNow(usage, time, model)
  }

  private foldUsageNow(usage: UsageRecord, time: number | undefined, model: string): void {
    const at = time ?? Date.now()
    const dayName = dayKey(at)
    const day = this.state.usage[dayName] ?? (this.state.usage[dayName] = {})
    if (this.lastUsagePruneDay !== dayName) {
      pruneUsage(this.state.usage, at)
      this.lastUsagePruneDay = dayName
    }
    const row = day[model] ?? (day[model] = createUsageRow())
    foldUsageRecord(row, usage, isPeakHour(at))
    this.usageRevision++
  }

  /** Snapshot of browser-safe state; the API key value never crosses this boundary. */
  async stateView(): Promise<CustomPluginPublicState> {
    const credential = await this.credentialStatus()
    return {
      cfg: this.state.cfg,
      folders: this.state.folders,
      prompts: this.state.prompts,
      stars: this.state.stars,
      usage: this.state.usage,
      ...credential,
    }
  }

  /** Apply a browser-side state edit (config, folders, prompts, stars, api key). */
  async applyEdit(edit: { cfg?: Partial<CustomPluginState['cfg']>; folders?: CustomPluginState['folders']; prompts?: CustomPluginState['prompts']; stars?: CustomPluginState['stars']; apiKey?: string }): Promise<void> {
    this.credentialCache = null
    await this.runStateOperation(async () => {
      // Only the edited sections can change, and every setter replaces its
      // section wholesale. A shallow snapshot is therefore a complete rollback
      // point; deep-cloning the usage ledger here made every toggle O(ledger)
      // and grew worse with retention.
      const previous = {
        cfg: this.state.cfg,
        folders: this.state.folders,
        prompts: this.state.prompts,
        stars: this.state.stars,
        apiKey: this.state.apiKey,
      }
      try {
        await this.applyEditNow(edit)
      } catch (error) {
        // A credential-store failure must not leave the non-sensitive fields
        // half-applied in memory while the route reports an error.
        Object.assign(this.state, previous)
        throw error
      }
    })
  }

  private async applyEditNow(edit: { cfg?: Partial<CustomPluginState['cfg']>; folders?: CustomPluginState['folders']; prompts?: CustomPluginState['prompts']; stars?: CustomPluginState['stars']; apiKey?: string }): Promise<void> {
    if (edit.cfg !== undefined && edit.cfg !== null && typeof edit.cfg === 'object') this.state.cfg = normalizeCfg({ ...this.state.cfg, ...edit.cfg })
    if (Array.isArray(edit.folders)) {
      const folders = normalizeFolders(edit.folders)
      // Reject rather than persist: a shape beyond the validators could make
      // every later save's JSON.stringify throw, and the client owns the full
      // document, so silent truncation would drop parts of it.
      if (folders === null) throw new Error('文件夹数据无效')
      this.state.folders = folders
    }
    if (Array.isArray(edit.prompts)) this.state.prompts = edit.prompts.map(normalizePrompt).filter((item): item is NonNullable<ReturnType<typeof normalizePrompt>> => item !== null)
    if (edit.stars !== undefined && edit.stars !== null && typeof edit.stars === 'object') {
      const stars = normalizeStars(edit.stars)
      if (stars === null) throw new Error('星标数据无效')
      this.state.stars = stars
    }
    if (typeof edit.apiKey === 'string') {
      const key = edit.apiKey.trim()
      if (key === '') {
        const cleared = await this.credentialStore.clear()
        if (this.credentialStore.available && !cleared) throw new Error('系统凭据清除失败，请重试')
        this.state.apiKey = ''
      } else {
        if (!/^sk-/.test(key)) throw new Error('DeepSeek API Key 必须以 sk- 开头')
        this.state.apiKey = await this.credentialStore.set(key) ? '' : key
      }
    }
  }

  /** Build the portable backup projection; credentials never enter it. */
  backupExport(): CustomPluginBackupV1 {
    return createBackup(this.state)
  }

  /** Validate/preview or atomically apply a portable backup. */
  async backupImport(raw: unknown, mode: BackupImportMode, dryRun: boolean): Promise<{ ok: true; preview: ReturnType<typeof backupPreview>; recoveryPath?: string } | { ok: false; error: string }> {
    return await this.runStateOperation(() => this.backupImportNow(raw, mode, dryRun))
  }

  private async backupImportNow(raw: unknown, mode: BackupImportMode, dryRun: boolean): Promise<{ ok: true; preview: ReturnType<typeof backupPreview>; recoveryPath?: string } | { ok: false; error: string }> {
    try {
      if (mode !== 'merge' && mode !== 'replace') return { ok: false, error: '导入模式无效' }
      const backup = parseBackup(raw)
      const preview = backupPreview(this.state, backup)
      if (dryRun) return { ok: true, preview }
      // Same shallow-rollback reasoning as applyEdit: importedState builds
      // fresh objects, so section references are enough to undo the commit.
      const previous = {
        cfg: this.state.cfg,
        folders: this.state.folders,
        prompts: this.state.prompts,
        stars: this.state.stars,
        usage: this.state.usage,
        apiKey: this.state.apiKey,
      }
      const recoveryPath = await writeRecoveryBackup(this.statePath(), previous)
      const next = importedState(previous, backup, mode)
      Object.assign(this.state, next)
      try {
        await this.persist()
      } catch (error) {
        Object.assign(this.state, previous)
        throw error
      }
      return { ok: true, preview, recoveryPath }
    } catch (error) {
      return { ok: false, error: String((error as Error)?.message ?? error) }
    }
  }

  /** Move a legacy plaintext state key into the OS store when available. */
  async migrateLegacyApiKey(): Promise<boolean> {
    this.credentialCache = null
    const key = (this.state.apiKey ?? '').trim()
    if (!/^sk-/.test(key) || !this.credentialStore.available) return false
    let existing = ''
    try {
      existing = (await this.credentialStore.get()).trim()
    } catch {
      // Do not overwrite a credential that could not be read safely.
      return false
    }
    if (existing !== '') {
      if (/^sk-/.test(existing)) {
        this.state.apiKey = ''
        return true
      }
      // Keep the legacy value as a compatibility fallback rather than
      // overwriting an unexpected non-empty OS-store entry.
      return false
    }
    if (!await this.credentialStore.set(key)) return false
    this.state.apiKey = ''
    return true
  }

  /** Timeline nodes for one session, capped to the 400-node tail. The tail cap
   * bounds the payload (each item carries up to 4k of preview text); 400 keeps
   * dots available when the GUI deep-loads history. */
  async timelineGet(sessionId: string): Promise<{ ok: true; sessionId: string; items: TimelineItem[] } | { ok: false; error: string }> {
    try {
      const snapshot = await this.readSessionLog(sessionId)
      return { ok: true, sessionId, items: extractTurns(snapshot.events).slice(-400) }
    } catch (error) {
      return { ok: false, error: String((error as Error)?.message ?? error) }
    }
  }

  /** Export one session as JSON / Markdown / print-ready HTML. */
  async exportRun(sessionId: string, format: string): Promise<{ ok: true; content: string; fileName: string; mime: string } | { ok: false; error: string }> {
    let snapshot
    try {
      snapshot = await this.readSessionLog(sessionId)
    } catch (error) {
      return { ok: false, error: `读取会话失败: ${String((error as Error)?.message ?? error)}` }
    }
    let title = ''
    try {
      const titleSnapshot = await this.sessionQuery.readTitle(sessionId as SessionId)
      if (titleSnapshot !== undefined) title = String((titleSnapshot as { title?: unknown }).title ?? '')
    } catch {
      title = ''
    }
    const readImage = this.attachments !== undefined
      ? (ref: Parameters<AttachmentStore['readImage']>[0]) => this.attachments!.readImage(ref)
      : undefined
    try {
      const rows = await buildExportRows(snapshot, format === 'pdf' ? 'pdf' : format === 'json' ? 'json' : 'markdown', readImage)
      const stamp = `${dayKey()}-${String(Date.now() % 86400000)}`
      if (format === 'json') {
        const messages = rows.map((row) => {
          if (row.kind === 'user') {
            return { role: 'user', content: row.text, images: (row.images ?? []).map((image) => ({ name: image.name, mediaType: image.mediaType, width: image.width, height: image.height, bytes: image.bytes })) }
          }
          if (row.kind === 'assistant') return { role: 'assistant', content: row.text }
          if (row.kind === 'tool-call') return { role: 'tool', name: row.toolName, arguments: row.toolArgs, content: '' }
          if (row.kind === 'tool-result') return { role: 'tool', name: row.toolName ?? '', content: row.text }
          return { role: 'system', content: row.text }
        })
        const doc = {
          meta: {
            exporter: 'dsh-custom-plugin',
            version: 1,
            id: sessionId,
            title,
            createdAt: snapshot.session.createdAt ?? null,
            cwd: snapshot.session.cwd ?? null,
            exportedAt: new Date().toISOString(),
            count: messages.length,
          },
          messages,
        }
        return { ok: true, content: JSON.stringify(doc, null, 2), fileName: `custom-conversation-${stamp}.json`, mime: 'application/json' }
      }
      if (format === 'markdown') {
        return { ok: true, content: buildMarkdown(rows, sessionId), fileName: `custom-conversation-${stamp}.md`, mime: 'text/markdown' }
      }
      if (format === 'pdf') {
        return { ok: true, content: buildPdfHtml(rows, sessionId), fileName: `custom-conversation-${stamp}.html`, mime: 'text/html' }
      }
      return { ok: false, error: 'unknown format' }
    } catch (error) {
      return { ok: false, error: `构建导出失败: ${String((error as Error)?.message ?? error)}` }
    }
  }

  /** Resolve the key and its source without returning either value to the browser. */
  private async resolveApiKeyWithSource(): Promise<{ key: string; source: CredentialStorage }> {
    try {
      const system = (await this.credentialStore.get()).trim()
      if (/^sk-/.test(system)) return { key: system, source: 'system' }
    } catch {
      // OS credential store unavailable — continue through compatibility tiers.
    }
    const key = (this.state.apiKey ?? '').trim()
    if (/^sk-/.test(key)) return { key, source: 'legacy-state' }
    try {
      const env = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env
      // First valid candidate wins: an unset, empty, or non-sk value for one
      // name must not shadow the next name (mirrors the credential-file tier,
      // where each ref is checked individually).
      for (const name of ['DEEPSEEK_API_KEY', 'DEEPSEEK_KEY', 'DEEPSEEK_TOKEN']) {
        const value = env?.[name]
        if (typeof value === 'string' && /^sk-/.test(value.trim())) return { key: value.trim(), source: 'environment' }
      }
    } catch {
      // environment unavailable
    }
    try {
      // DSH keeps model keys in $DSH_HOME/.credentials.yaml and never exports
      // them to the process environment; reuse the same file so a key
      // configured once in DSH is picked up automatically here.
      const candidate = await this.readCredential()
      if (/^sk-/.test(candidate)) return { key: candidate.trim(), source: 'dsh' }
    } catch {
      // credential refs unavailable
    }
    return { key: '', source: 'none' }
  }

  /** Search one session and bind hits to a user-turn anchor.
   *
   * DSH's indexed event search is the preferred path, but its shipped web
   * profile composes `session-query-sqlite` with `openAt: never`, so the index
   * is absent by default and `searchEvents()` rejects. The full log is read for
   * the anchor map anyway, so a rejected index degrades to a literal scan of
   * that log instead of failing the whole feature. */
  async conversationSearch(sessionId: string, query: string, kinds: readonly ConversationSearchKind[]): Promise<{ ok: true; } & ConversationSearchResult | { ok: false; error: string }> {
    const wanted = new Set(kinds.length > 0 ? kinds : ['user', 'assistant', 'tool'])
    const eventTypes: Array<SessionEvent['type']> = kinds.length > 0
      ? kinds.flatMap((kind): Array<SessionEvent['type']> =>
        kind === 'user' ? ['user/message'] : kind === 'assistant' ? ['assistant/message'] : ['tool/call', 'tool/result'])
      : []
    // Typed request, and a synchronous throw must degrade the same way a
    // rejection does: an engine without the index can fail on the call itself
    // rather than returning a rejected promise.
    const request: SessionEventSearchRequest = {
      sessionId: sessionId as SessionId,
      query,
      limit: 100,
      ...(eventTypes.length > 0 ? { filters: [{ kind: 'type', values: eventTypes }] } : {}),
    }
    const indexRead = Promise.resolve()
      .then(() => this.sessionQuery.searchEvents(request))
      .then((page) => page, () => null)
    let snapshot: SessionLogSnapshot
    let page: Awaited<typeof indexRead>
    try {
      const both = await Promise.all([this.readSessionLog(sessionId), indexRead])
      snapshot = both[0]
      page = both[1]
    } catch (error) {
      return { ok: false, error: String((error as Error)?.message ?? error) }
    }
    const anchors = new Map<number, number>()
    let anchor: number | undefined
    for (const event of snapshot.events) {
      if (event.type === 'user/message') anchor = event.seq
      if (anchor !== undefined) anchors.set(event.seq, anchor)
    }
    const items: ConversationSearchItem[] = []
    if (page !== null) {
      for (const hit of page.items) {
        const kind = searchKindOf(hit.type)
        if (kind === null || !wanted.has(kind)) continue
        const anchorSeq = anchors.get(hit.seq)
        if (anchorSeq === undefined) continue
        items.push({ sessionId, seq: hit.seq, anchorSeq, kind, time: hit.time, snippet: hit.snippet.slice(0, 500) })
      }
      return { ok: true, items, hasMore: page.nextCursor !== undefined, source: 'index' }
    }
    const needle = query.toLowerCase()
    let truncated = false
    for (const event of snapshot.events) {
      const kind = searchKindOf(event.type)
      if (kind === null || !wanted.has(kind)) continue
      const anchorSeq = anchors.get(event.seq)
      if (anchorSeq === undefined) continue
      const text = eventSearchText(event)
      const at = text.toLowerCase().indexOf(needle)
      if (at < 0) continue
      // Fill to the cap, and only claim there is more once a match shows up
      // past it — a log with exactly 100 hits must not report hasMore.
      if (items.length >= 100) { truncated = true; break }
      items.push({ sessionId, seq: event.seq, anchorSeq, kind, time: event.time, snippet: snippetAround(text, at, needle.length, 500) })
    }
    return { ok: true, items, hasMore: truncated, source: 'scan' }
  }

  private async resolveApiKey(): Promise<string> {
    return (await this.resolveApiKeyWithSource()).key
  }

  /** Browser-safe credential status used by state and save responses. */
  async credentialStatus(): Promise<Pick<CustomPluginPublicState, 'apiKeyConfigured' | 'credentialStorage'>> {
    const now = Date.now()
    if (this.credentialCache !== null && now - this.credentialCache.at < CustomPluginHost.CREDENTIAL_CACHE_TTL_MS) return this.credentialCache.status
    const resolved = await this.resolveApiKeyWithSource()
    const status = { apiKeyConfigured: resolved.key !== '', credentialStorage: resolved.source }
    this.credentialCache = { at: now, status }
    return status
  }

  /** Query the DeepSeek balance endpoint (15s timeout). */
  async balanceGet(): Promise<{ ok: boolean; keyConfigured: boolean; balance?: BalanceInfo | null; error?: string | null; usageToday?: unknown; available?: boolean }> {
    const usageToday = this.state.usage[dayKey()] ?? {}
    const key = await this.resolveApiKey()
    if (key === '') return { ok: false, keyConfigured: false, error: '未配置 DeepSeek API Key（请在额度面板粘贴 sk- 开头的密钥）', usageToday }
    let response
    try {
      response = await this.httpJson('https://api.deepseek.com/user/balance', { Authorization: `Bearer ${key}`, Accept: 'application/json' })
    } catch (error) {
      return { ok: false, keyConfigured: true, error: String((error as Error)?.message ?? error), usageToday }
    }
    if (!response.ok) return { ok: false, keyConfigured: true, error: response.error ?? '请求失败', usageToday }
    const json = (response.json ?? {}) as { is_available?: boolean; balance_infos?: Array<{ currency?: string; total_balance?: string; granted_balance?: string; topped_up_balance?: string }> }
    const infos = json.balance_infos ?? []
    const info = infos.find((item) => item.currency === 'CNY') ?? infos[0]
    return {
      ok: true,
      keyConfigured: true,
      available: json.is_available !== false,
      balance: info !== undefined ? { currency: info.currency ?? '', total: info.total_balance ?? '0', granted: info.granted_balance ?? '0', toppedUp: info.topped_up_balance ?? '0' } : null,
      error: infos.length > 0 ? null : '响应中无余额信息',
      usageToday,
    }
  }

  /** Re-scan the session logs and rebuild today's usage ledger. Every session
   * is replayed but only usage events whose own timestamp falls on today are
   * folded, so sessions created before midnight keep contributing the usage
   * they produced today. */
  async usageScan(): Promise<UsageScanResult> {
    if (this.usageScanPromise !== null) return await this.usageScanPromise
    const run = this.runStateOperation(() => this.usageScanImpl())
    this.usageScanPromise = run
    try {
      return await run
    } finally {
      if (this.usageScanPromise === run) this.usageScanPromise = null
    }
  }

  private async usageScanImpl(): Promise<UsageScanResult> {
    const revisionAtStart = this.usageRevision
    let records
    try {
      records = await this.sessionQuery.listSessions()
    } catch {
      return { ok: false, error: '列会话失败' }
    }
    const today = dayKey()
    const agg: Record<string, UsageRow> = {}
    let scanned = 0
    const entries = await mapConcurrent(records, USAGE_SCAN_CONCURRENCY, async (record): Promise<ScanEntry> => {
      // Live usage arriving mid-replay invalidates the whole snapshot anyway;
      // checking per item (not once at the end) stops paying for session
      // reads that are already doomed to be discarded — exactly the window
      // where a streaming conversation invites rescan retries.
      if (this.usageRevision !== revisionAtStart) return { readable: false, stale: true, usage: {} }
      try {
        const snapshot = await this.readSessionLog(record.header.id)
        const dayUsage = aggregateDayUsage(snapshot.events, today)
        return { readable: true, usage: dayUsage }
      } catch {
        // skip unreadable session
        return { readable: false, usage: {} }
      }
    })
    let failedSessions = 0
    for (const entry of entries) {
      if (entry.stale === true) continue
      if (!entry.readable) {
        failedSessions++
        continue
      }
      const models = Object.keys(entry.usage)
      if (models.length === 0) continue
      scanned++
      for (const model of models) {
        const row = agg[model] ?? (agg[model] = createUsageRow())
        mergeUsageRow(row, entry.usage[model])
      }
    }
    // Never replace a complete live ledger with a partial replay. The caller
    // can retry after the unreadable sessions recover.
    if (failedSessions > 0) return { ok: false, error: '部分会话读取失败，未覆盖现有用量，请稍后重试' }
    // Live session events may arrive while the asynchronous replay is in
    // flight. Keep them rather than replacing them with an older snapshot.
    if (this.usageRevision !== revisionAtStart) return { ok: false, error: '扫描期间产生了新用量，未覆盖现有用量，请稍后重试' }
    const previousUsage = JSON.parse(JSON.stringify(this.state.usage)) as CustomPluginState['usage']
    pruneUsage(this.state.usage)
    this.state.usage[today] = agg
    try {
      await this.persist()
    } catch (error) {
      this.state.usage = previousUsage
      return { ok: false, error: `用量保存失败: ${String((error as Error)?.message ?? error)}` }
    }
    return { ok: true, day: today, usageToday: this.state.usage[today] ?? {}, scannedSessions: scanned }
  }

  /** Resolve the Mermaid engine: the bundled `mermaid` dependency on disk
   * first (no runtime network), CDN mirrors only as a fallback (cached for
   * the host lifetime). */
  async mermaidFetch(): Promise<MermaidFetchResult> {
    if (this.mermaidBytesValue > 0) return { ok: true, bytes: this.mermaidBytesValue }
    if (this.mermaidFetchPromise !== null) return await this.mermaidFetchPromise
    const run = this.mermaidFetchImpl()
    this.mermaidFetchPromise = run
    try {
      return await run
    } finally {
      if (this.mermaidFetchPromise === run) this.mermaidFetchPromise = null
    }
  }

  private async mermaidFetchImpl(): Promise<MermaidFetchResult> {
    const localPath = this.localMermaidPath()
    if (localPath !== null && localPath !== '') {
      try {
        // Async read: the bundled engine is ~3.5 MB, and a synchronous read
        // here stalls every Host request behind it during boot.
        const text = await readFile(localPath, 'utf8')
        if (text.length > 0) {
          this.cacheMermaid(text, 'local')
          return { ok: true, bytes: this.mermaidBytesValue }
        }
      } catch {
        // unreadable local bundle: fall through to the CDN mirrors
      }
    }
    const urls = [
      `https://cdn.jsdelivr.net/npm/mermaid@${MERMAID_CDN_VERSION}/dist/mermaid.min.js`,
      `https://fastly.jsdelivr.net/npm/mermaid@${MERMAID_CDN_VERSION}/dist/mermaid.min.js`,
      `https://unpkg.com/mermaid@${MERMAID_CDN_VERSION}/dist/mermaid.min.js`,
    ]
    let text = ''
    let lastError = ''
    for (const url of urls) {
      try {
        const result = await this.httpText(url)
        if (result.ok) {
          if (looksLikeMermaidBundle(result.text)) { text = result.text; break }
          lastError = `镜像返回了非脚本内容 (${result.text.length} bytes)`
          continue
        }
        lastError = result.error ?? ''
      } catch (error) {
        lastError = String((error as Error)?.message ?? error)
      }
    }
    if (text === '') return { ok: false, error: `无法获取 Mermaid 引擎: ${lastError}` }
    this.cacheMermaid(text, 'cdn')
    return { ok: true, bytes: this.mermaidBytesValue }
  }

  /** Cache the engine and its validators. `bytes` is UTF-8 length, not the
   * JavaScript string length: the status/debug payloads call it bytes, and a
   * non-ASCII bundle would otherwise under-report the transfer size. */
  private cacheMermaid(text: string, source: 'local' | 'cdn'): void {
    this.mermaidJs = text
    this.mermaidBytesValue = Buffer.byteLength(text, 'utf8')
    this.mermaidSource = source
    this.mermaidEtagValue = createHash('sha256').update(text).digest('hex').slice(0, 32)
  }

  /** The cached Mermaid engine script (served at the script path). */
  mermaidScript(): string {
    return this.mermaidJs
  }

  /** Mermaid engine byte count for diagnostics. */
  mermaidBytes(): number {
    return this.mermaidBytesValue
  }

  /** Cache validator for the engine script ('' while unloaded). */
  mermaidEtag(): string {
    return this.mermaidEtagValue
  }

  /** Where the engine came from: 'local', 'cdn', or '' while unloaded. */
  mermaidLoadedSource(): string {
    return this.mermaidSource
  }

  /** Whether any DeepSeek key source resolves (state, environment, credential
   * file) — the honest answer behind the panel's "key configured" badge.
   * Goes through the 5s source cache: the status tool and About tab call this
   * independently of `/state`, and each miss hits the OS keychain plus a file. */
  async hasApiKey(): Promise<boolean> {
    return (await this.credentialStatus()).apiKeyConfigured
  }

  /** Diagnostics snapshot for the status tool and the About tab. */
  async debugInfo(): Promise<{ statePath: string; today: string; usageToday: unknown; mermaidBytes: number; mermaidSource: string; apiKeySet: boolean; diagReports: string[] }> {
    return {
      statePath: this.statePath(),
      today: dayKey(),
      usageToday: this.state.usage[dayKey()] ?? {},
      mermaidBytes: this.mermaidBytesValue,
      mermaidSource: this.mermaidSource,
      apiKeySet: await this.hasApiKey(),
      diagReports: [...this.diagReports],
    }
  }

  private async httpText(url: string): Promise<{ ok: true; text: string } | { ok: false; error?: string }> {
    try {
      const response = await fetch(url, { method: 'GET', signal: AbortSignal.timeout(15000) })
      if (!response.ok) {
        if (response.status === 401 || response.status === 403) return { ok: false, error: `认证失败 (HTTP ${response.status})` }
        return { ok: false, error: `HTTP ${response.status}` }
      }
      return { ok: true, text: await response.text() }
    } catch (error) {
      return { ok: false, error: String((error as Error)?.message ?? error) }
    }
  }

  private async httpJson(url: string, headers: Record<string, string>): Promise<{ ok: true; json: unknown } | { ok: false; error?: string }> {
    try {
      const response = await fetch(url, { method: 'GET', headers, signal: AbortSignal.timeout(15000) })
      if (!response.ok) {
        if (response.status === 401 || response.status === 403) return { ok: false, error: '认证失败 (HTTP ' + response.status + ')，请检查 API Key 是否正确' }
        return { ok: false, error: `HTTP ${response.status}` }
      }
      try {
        return { ok: true, json: await response.json() }
      } catch {
        return { ok: false, error: '非 JSON 响应' }
      }
    } catch (error) {
      return { ok: false, error: readableFetchError(error) }
    }
  }
}

/**
 * Translate a Node `fetch` connection-level failure into a message a user can
 * act on. Node reports "fetch failed" with the real reason in `error.cause`
 * (e.g. `SELF_SIGNED_CERT_IN_CHAIN` — a local TLS-intercepting proxy or
 * security suite, which makes outbound calls fail *intermittently* whenever
 * the interceptor takes the connection), and passing the bare TypeError
 * through once read as a mysterious network that "sometimes does not exist".
 */
export function readableFetchError(error: unknown): string {
  const cause = (error as { cause?: { code?: string; message?: string } })?.cause
  const code = cause?.code ?? ''
  if (code === 'SELF_SIGNED_CERT_IN_CHAIN' || code === 'DEPTH_ZERO_SELF_SIGNED_CERT' || code === 'UNABLE_TO_GET_ISSUER_CERT_LOCALLY' || code === 'UNABLE_TO_VERIFY_LEAF_SIGNATURE') {
    return 'TLS 证书校验失败：本机代理或安全软件可能正在解密 HTTPS——请对 api.deepseek.com 放行直连，或将该软件的根证书装入系统信任'
  }
  if (code === 'ENOTFOUND' || code === 'EAI_AGAIN') return 'DNS 解析失败：请检查本机网络与代理配置'
  if (code === 'ETIMEDOUT' || code === 'ECONNRESET' || code === 'ECONNREFUSED' || code === 'EHOSTUNREACH' || code === 'ENETUNREACH') {
    return `连接失败（${code}）：请检查本机网络与代理配置`
  }
  const message = String(cause?.message ?? (error as Error)?.message ?? error)
  return message === 'fetch failed' ? '网络请求失败：请检查本机网络与代理配置' : message
}

/** A 200 from a mirror is not proof of the engine: captive portals and
 * misconfigured mirrors happily serve an HTML interstitial with status 200.
 * The real bundle is a multi-megabyte script that never starts with a
 * document tag; anything else must not poison the host-lifetime cache. */
function looksLikeMermaidBundle(text: string): boolean {
  const head = text.slice(0, 64).replace(/^\uFEFF/, '').trimStart()
  return text.length >= 1000 && !head.startsWith('<')
}

/** Resolve `mermaid/dist/mermaid.min.js` from the package's own dependency
 * tree (works for `link:` checkouts and registry installs alike); null when
 * the dependency is absent, which falls mermaidFetch back to the CDN. */
export function defaultLocalMermaidPath(): string | null {
  try {
    const require = createRequire(import.meta.url)
    return require.resolve('mermaid/dist/mermaid.min.js')
  } catch {
    return null
  }
}
