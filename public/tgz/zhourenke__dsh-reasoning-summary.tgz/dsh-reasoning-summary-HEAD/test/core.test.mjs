import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import {
  Config,
  MISSING_TEXT,
  PARTIAL_TEXT,
  SETTINGS_NAMESPACE,
  inspectSummary,
  normalizeTextBlocks,
  routeKey,
} from '../lib/index.js'

test('the default settings leave the feature inactive', () => {
  // A volatile field resolves to a live box rather than to an array: `get()` is
  // the read path, and it answers the current value. Empty is the documented
  // default, which is what keeps the feature off until a route is chosen.
  assert.deepEqual(Config().models.get(), [])
})

test('the models field is declared volatile so a save reaches the next step', () => {
  // The loader re-reads a volatile field on every load instead of freezing the
  // value captured at activation, and schemastery records the marker on the
  // field's own ref (measured on 3.18.4 — the API does not exist in 3.18.2, so
  // the dependency range is load-bearing). This asserts the exact envelope that
  // a dependency bump could otherwise change silently.
  const envelope = Config.toJSON()
  const models = envelope.refs[envelope.refs[envelope.uid].dict.models]
  assert.equal(models.type, 'array')
  assert.equal(models.meta.volatile, true)
})

test('settings accept exact model routes and reject an empty provider', () => {
  assert.deepEqual(
    Config({ models: [{ provider: 'cotton-codex', model: 'gpt-5.6-luna' }] }).models.get(),
    [{ provider: 'cotton-codex', model: 'gpt-5.6-luna' }],
  )
  assert.throws(() => Config({ models: [{ provider: '', model: 'x' }] }))
})

test('the row id is one spelling across the patch, the host half and the browser half', () => {
  // Three consumers read this id: the profile patch entry's `id`, the namespace
  // the browser half passes to `ctx.configForms` (and declares as its seat's
  // locale), and the `<row id>` half of the `plugins.row.config` key. A mismatch
  // leaves the row's page permanently form-less with only a warning, so the
  // spellings are pinned against each other here rather than trusted.
  const patch = readFileSync(new URL('../cordis.patch.yml', import.meta.url), 'utf8')
  const patched = [...patch.matchAll(/^\s*- id:\s*(\S+)\s*$/gm)].map((match) => match[1])
  assert.deepEqual(patched, [SETTINGS_NAMESPACE])

  const client = readFileSync(new URL('../src/client.ts', import.meta.url), 'utf8')
  assert.match(client, new RegExp(`const NS = '${SETTINGS_NAMESPACE}'`))
  assert.match(client, /key: `\$\{PLUGIN_ID\}#\$\{NS\}`/)
  const manifest = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))
  assert.equal(manifest.dsh.bundle.patch, './cordis.patch.yml')
})

test('route matching uses provider and model as one exact key', () => {
  assert.equal(routeKey('cotton-codex', 'gpt-5.6-luna'), 'cotton-codex\0gpt-5.6-luna')
  assert.notEqual(routeKey('cotton-codex', 'gpt-5.6-luna'), routeKey('other', 'gpt-5.6-luna'))
})

test('the first summary is normalized for relay and removed from assistant text', () => {
  const result = normalizeTextBlocks(['Before <summary>  inspected files  </summary> after'], true)
  assert.equal(result.summary.status, 'complete')
  assert.equal(result.summary.content, 'inspected files')
  assert.equal(result.texts[0], 'Before  after')
  assert.doesNotMatch(result.texts[0], /source="reasoning-summary"/)
})

test('a stray opening tag cannot steal the nearest complete summary pair', () => {
  const result = normalizeTextBlocks([
    'The literal <summary> token is documentation. <summary>inspected files</summary> after',
  ], true)
  assert.equal(result.summary.status, 'complete')
  assert.equal(result.summary.content, 'inspected files')
  assert.equal(result.texts[0], 'The literal <summary> token is documentation.  after')
})

test('a partial opening tag in an earlier text block cannot preempt a later complete pair', () => {
  const result = normalizeTextBlocks([
    'Documentation mentions a literal <summary> token.',
    '<summary>inspected src/index.ts</summary>',
  ], true)
  assert.equal(result.summary.status, 'complete')
  assert.equal(result.summary.content, 'inspected src/index.ts')
  assert.deepEqual(result.texts, ['Documentation mentions a literal <summary> token.', ''])
})

test('later duplicate summaries remain literal output', () => {
  const result = normalizeTextBlocks(['<summary>first</summary> body <summary status="wrong">second</summary>'], true)
  assert.equal(result.summary.status, 'complete')
  assert.equal(result.texts[0], ' body <summary status="wrong">second</summary>')
  assert.match(result.texts[0], /<summary status="wrong">second<\/summary>/)
  assert.equal((result.texts[0].match(/<summary/g) ?? []).length, 1)
})

test('removing a boundary summary does not leave a blank line', () => {
  const leading = normalizeTextBlocks(['<summary>planned the answer</summary>\nAnswer'], true)
  assert.deepEqual(leading.texts, ['Answer'])

  const trailing = normalizeTextBlocks(['Answer\n<summary>planned the answer</summary>\n'], true)
  assert.deepEqual(trailing.texts, ['Answer'])

  const between = normalizeTextBlocks(['Before\n<summary>planned the answer</summary>\nAfter'], true)
  assert.deepEqual(between.texts, ['Before\nAfter'])
})

test('missing required summaries produce relay metadata without visible markers', () => {
  const result = normalizeTextBlocks(['final answer'], true)
  assert.equal(result.summary.status, 'missing')
  assert.equal(result.summary.content, MISSING_TEXT)
  assert.deepEqual(result.texts, ['final answer'])
  assert.doesNotMatch(result.texts[0], /source="reasoning-summary"/)
})

test('an unclosed summary becomes partial while its received prefix stays relay-only', () => {
  const found = inspectSummary('body <summary>still working')
  assert.equal(found.info, 'partial')
  const result = normalizeTextBlocks(['body <summary>still working'], true)
  assert.equal(result.summary.status, 'partial')
  assert.match(result.summary.content, /still working/)
  assert.ok(
    result.summary.content.includes(PARTIAL_TEXT),
    'the partial relay carries the canonical notice verbatim',
  )
  assert.deepEqual(result.texts, ['body '])
  assert.doesNotMatch(result.texts[0], /<summary/)
})

test('a final step does not add a summary when it has no tool call', () => {
  const result = normalizeTextBlocks(['ordinary final answer'], false)
  assert.deepEqual(result, { texts: ['ordinary final answer'] })
})

test('peerDependencies and README compatibility declarations stay in step across host baselines', () => {
  const manifest = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))
  // All @deepseek-ai/dsh-* peerDependencies must declare the exact same range of host baselines
  const dshPeers = Object.entries(manifest.peerDependencies ?? {})
    .filter(([name]) => name.startsWith('@deepseek-ai/dsh-'))
  assert.ok(dshPeers.length > 0, 'must declare dsh-* peerDependencies')

  const expectedRange = dshPeers[0][1]
  for (const [name, range] of dshPeers) {
    assert.equal(range, expectedRange, `${name} peer range must match other dsh-* packages`)
  }

  // Extract version tokens from the peer range, e.g. "^0.2.0-rc.2 || ^0.2.1-rc.2" -> ['0.2.0-rc.2', '0.2.1-rc.2']
  const peerVersions = expectedRange
    .split('||')
    .map((arm) => arm.trim().replace(/^\^/, ''))
    .sort()

  // Verify README.md compatibility section has exactly one matching line per peer baseline
  const readmeZh = readFileSync(new URL('../README.md', import.meta.url), 'utf8')
  const zhMatches = [...readmeZh.matchAll(/在 v([0-9a-zA-Z.-]+)（\d{4}-\d{2}）下测试通过。/g)]
    .map((m) => m[1])
    .sort()
  assert.deepEqual(zhMatches, peerVersions, 'README.md compatibility lines must match peerDependencies baselines')

  // Verify README.en.md compatibility section matches as well
  const readmeEn = readFileSync(new URL('../README.en.md', import.meta.url), 'utf8')
  const enMatches = [...readmeEn.matchAll(/Tested with v([0-9a-zA-Z.-]+) \([A-Za-z]+ \d{4}\)\./g)]
    .map((m) => m[1])
    .sort()
  assert.deepEqual(enMatches, peerVersions, 'README.en.md compatibility lines must match peerDependencies baselines')
})
