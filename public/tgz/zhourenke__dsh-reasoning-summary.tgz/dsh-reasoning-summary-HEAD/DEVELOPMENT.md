# 开发注意事项（Development Notes）

面向维护者。使用者请看 [README.md](README.md)——那里只回答"能不能用、怎么调、哪里会踩坑"，实现内部细节一律放在本文档。

本插件是**双半边**插件：`src/index.ts` 跑在宿主 Node 进程里，`src/client.ts` 是浏览器侧由 ModuleLoader 加载的普通脚本。两半不能互相 `import`，所有跨半边的身份字符串都靠**逐字一致**维持（见实现要点 8）。

## 仓库结构

| 路径 | 说明 |
|---|---|
| `src/index.ts` | 宿主半边全部实现：设置读取、每 Session 一次的普通上下文提示注入、流拦截、摘要规范化、relay 与 continuation |
| `src/client.ts` | 浏览器半边：插件页里本插件那一行的配置页（纯脚本，无 `import`） |
| `lib/index.js` | 宿主编译产物，**必须提交**（路线 A） |
| `lib/client.js` | 浏览器编译产物，**必须提交** |
| `lib/types/index.d.ts` | 宿主类型声明，**必须提交** |
| `lib/types/client.d.ts` | 浏览器类型声明，**必须提交** |
| `icon.svg` | 插件行图标，`package.json` 的 `icon` 指向它，**必须提交** |
| `locale/zh.json`、`locale/en.json` | 插件行的显示名称与描述（`meta.title` / `meta.description`），**必须提交** |
| `test/core.test.mjs` | 纯函数与解析器（14 项）：`inspectSummary`、`normalizeTextBlocks`、`routeKey`、摘要素、`Config` 的 volatile 声明、行 id 在三处拼写的漂移守卫，以及 peerDependencies 与 README 兼容声明双向一致性守卫 |
| `test/runtime.test.mjs` | 宿主事件链（63 项）：模拟 ctx 走完整 step 生命周期 |
| `test/client.test.mjs` | 浏览器半边（20 项）：**真正执行** `lib/client.js` |
| `tools/inspect-session.mjs` | 开发期工具，**不随包发布**（不在 `files` 里）：直读某个 Session 的持久日志，回答"插件在这个 Session 里到底做了什么" |
| `cordis.patch.yml` | profile 层插入声明 |
| `tsconfig.json` | 宿主半边配置（Node，无 DOM） |
| `tsconfig.client.json` | 浏览器半边配置（DOM，无 Node 类型） |
| `pnpm-workspace.yaml` | pnpm 自管的 `minimumReleaseAgeExclude` 允许清单，**一并提交**，不要手改（「供应链策略」） |

上表三个测试文件的项数用**逐文件**命令重新产出，例如 `node --test test/core.test.mjs`；三者之和当前为 **97**（14 + 63 + 20），同时也写在 `pnpm test` 输出的 `tests N` 行里。改过测试后请用这两条命令更新数字，不要手改——过期计数比没有计数更糟，它会被当成核对过的结论引用。

## 本地开发与构建

```powershell
pnpm install
pnpm run typecheck   # 两份 tsconfig 都要过
pnpm run build       # 两个 tsc：src/index.ts → lib/index.js，src/client.ts → lib/client.js
pnpm test            # 先 build，再 node --test
```

**两份 tsconfig 不能合并。** `tsconfig.json` 给宿主半边 `lib: ["ES2022"]` + `types: ["node"]` 且不含 DOM；`tsconfig.client.json` 给浏览器半边 `lib: ["ES2022", "DOM"]` + `types: []`。这样 `window`、`document` 不会误入宿主代码，`node:` 内置模块也不会误入浏览器半边。浏览器半边的 `require` 由 ModuleLoader 的工厂参数注入，因此那里没有 Node 类型可用。

`pnpm test` 不是可选项。`tsc` 只做类型检查与转译，漂移检查只看 git 状态——**没有任何一步执行过产物**。于是「模块在 import 时抛错」可以一路绿灯，直到用户重启 DSH 才在启动日志里爆出来。测试直接 `import` 编译产物，用模拟 ctx 走一遍加载、事件注册与整条 relay 时序。

`test` 脚本写作 `"pnpm run build && node --test"`，两点都不能省：`node --test` 不带参数才会递归发现全部测试文件；串上构建则保证执行的永远是源码当前编译出的产物，而不是上一次的残留。

**每次修改 `src/` 后必须运行 `pnpm run build`，并把 `lib/` 一并提交**：

```powershell
pnpm run build
git status --porcelain   # 必须为空；有输出说明产物没跟上源码
```

**产物上的"已修改"有一种假阳性，判据要用内容哈希。** 出现条件：先有一步 **git 写产物**的操作（`git checkout -- lib/index.js`、`git stash`、还原产物），随后又跑了一次 `pnpm run build`。本机 `core.autocrlf=true`，前一步按 CRLF 写文件并把 **CRLF 的尺寸**记进索引，`tsc` 重写的是 LF——本次实测索引 56764 字节、实际 55538 字节。stat 对不上，`git status` 就报 `M lib/index.js`，而 `git diff` / `git diff --numstat` 是**空的**：clean 过滤后的内容与 blob 完全一致。发布指南「提交前验证清单」第 3 步那条判据会遇到同样的情形。

```powershell
git hash-object --path=lib/index.js lib/index.js   # 经 clean filter，等于提交时的内容
git rev-parse HEAD:lib/index.js                    # 与上一行相同即无漂移
```

**不要用"再 checkout 一次"或重写产物去"修"它**——那只会重新写出 CRLF 状态。刷新索引即可，blob 相同时不会暂存任何东西：

```powershell
git add lib/index.js
```

反方向还有一种**正常**情况：`src/` 改了而 `lib/` **字节未变**。纯类型改动（例如只加一行 `import type {} from '…'`）会被 `tsc` 完全擦除，产物与源码仍然一致，此时"把 `lib/` 一并提交"根本没有东西可提交。先看 `git status` 里有没有 `lib/`，不要为了凑这条规矩去重写产物。

## 开发挂载：让 DSH 加载你改的代码

用目录连接点把插件挂进 profile 的 `node_modules`，改完 `pnpm run build` 再重启即可，不必每次重新安装：

```powershell
$prof = "$env:USERPROFILE\.dsh\profiles\web"
[System.IO.Directory]::CreateDirectory("$prof\node_modules\@zhourenke") | Out-Null
New-Item -ItemType Junction -Path "$prof\node_modules\@zhourenke\dsh-reasoning-summary" -Target $PWD
```

**连接点会绕过 profile 里已提升的依赖**：Node 按 realpath 解析后沿工作区路径向上找 `node_modules`，所以插件目录里必须自己 `pnpm install` 一份，否则启动时报 `Cannot find package '@deepseek-ai/schemastery'`。

**代码改动的生效方式分两半**：宿主半边改完必须**重启 DSH**；浏览器半边改完在重启后还需要**刷新页面**（`lib/client.js` 由 ModuleLoader 在页面加载时取用）。只测宿主半边时不必管卡片，但反过来只刷新页面不会让宿主改动生效。

**配置改动则与重启无关**：profile 补丁层是热重载的，改完立刻生效，两边都不用重启。把这条与上面的代码改动分开记，就不会写出"改配置要重启"这种文档错误。

## 配置落点：profile 里的插件条目

**`<harness home>/settings.yaml` 这一层已经不存在了**：0.1.7 起设置按插件行归属，`~/.dsh/settings.yaml` 不再被读取。现在只有一个落点——profile 里本插件那一行条目，两种写法都是热重载：

| 落点 | 谁写它 | 形态 | 生效 |
|---|---|---|---|
| profile 的插件条目（页面的「配置 推理摘要」） | 使用者点保存，经 Host form 的 revision-fenced 写入 | 这份配置由 loader 交给 `apply(ctx, config)`，不再有插件自己去注册的设置服务 | 保存即生效（补丁层热重载） |
| `<profile>/cordis.patch.yml` | 用户或 profile 维护者 | `- id: reasoning-summary` 覆盖条目，其下 `config:` | 保存即生效（补丁层热重载） |

页面这一侧由 `dsh-client-ui-plugin-manager` 声明座位 `plugins.row.config`（`kind: 'keyed'`、`scope: 'root'`），**按 `<包名>#<行 id>` 分派**：本插件是 `@zhourenke/dsh-reasoning-summary#reasoning-summary`，其中行 id 必须与 `cordis.patch.yml` 的 `- id:` 逐字一致，否则页面永远分派不到我们的配置页。写值走 `form.mutate([{ op: 'set', path: ['models'], value }], 期望 revision)`，因此并发写入会让本次保存失败而不是静默覆盖。

`cordis.patch.yml` 里**必须用 `- id:` 的覆盖写法，不要写 `- insert:`**：bundle 自带的 patch 已经把这个条目插进去了，再 `insert` 一次不报错，而是多出一个同 id 的实例——插件跑两遍、摘要逻辑算两遍。覆盖只看 `id`，所以 `name` 可省，但一旦写了就必须逐字一致，写错只会静默不生效。

**不要把这个 `id` 当成配置的一部分写进 README 的用户指引**：使用者面对的是插件页里那一行，那里没有 `id`、也没有 `name`。

连接点挂载的插件**无法用 `dsh plugin remove` 卸载**（它不在 profile 的 `dependencies` 里），需要手工删连接点再摘掉 `dsh.profile.bundles` 条目。挂载状态可用 `Get-Item … -Force | Select-Object LinkType, Target` 核对，`Target` 必须等于你正在改的仓库路径（「连接点安装 ≠ 正式安装」）。

## 实现要点（为什么这样做）

### 1. 宿主 `inject` 只列真正读取的服务

当前是 `['agents']`。**配置不经过服务**：0.1.7 起设置由 loader 从插件行的条目读出后直接交给 `apply(ctx, config)`，插件不再自己 `register` 一个 namespace，因此 `settings` 不再是本项目读取的服务，也就不能列进 `inject`（`inject` 是硬门禁，声明了却没读是宽而无害的，但把"配置从哪来"记错会写坏文档）。**事件订阅不经过服务**：监听 `llm/stream`、`tools/result` 不需要把 `llm`、`tools` 写进 `inject`——官方 `dsh-repeat-tool-reminder` 一个宿主 inject 都不声明，照样在同一个流上监听。协议提示也不依赖 `systemPrompt`：模型选择仍在 `system-prompt/assemble` 中取最终 route，真正的提示通过 enabled、非 warmup 且每个 Session 的首个有效步骤的 `agent/pre-step` 返回值追加到 `decision.messages`，作为无 `form` 的、以本插件自声明 kind 标注的普通上下文消息；宿主随后将它写入 durable `user/message` 历史。后续步骤和后续 turn 都不会重复追加；插件重新激活时会从已有 durable history 识别协议上下文并继续抑制注入。它不会调用 `agent.inject()`，也不会写成 relay 或 next-step inbox 消息。未选中或预热步骤不会追加。这条通道取代了早期的 `systemPrompt.context()` 注册与 `system-prompt/assemble` 里的 `contexts` 改写，因此也不再产生 `source.form: 'snapshot'` 的运行时快照；当前步骤已有的用户消息与 durable relay 保持原顺序，协议提示位于它们之后。

### 2. 状态挂在 WeakMap 上，准入快照另存一份

`states` 以 live Agent 对象为键，不挂到 Agent 上、也不用全局 `Map`（那会让 Agent 无法回收）。`runtimeStates` 则以 Agent 的 Session 对象为键，保存纯内存的路由、最近成功工具步骤和预热待观察状态；它同样不会写回 Session。另一个 `WeakMap`（`admissionSnapshots`）单独存“本步骤准入时采样到的路由、开关与 warmup 决策”：设置和模型选择可能在流进行期间变化，而**已准入的步骤必须按准入时的快照跑完**，不能被中途改写。三者都是 `WeakMap`，所以 profile 用 `patchReload: live` 重载时，新实例不会复用旧实例留下的状态。

### 2.1 运行时预热的事件契约

预热观察器只消费宿主已有的 `session/event` 生命周期：`step/start` 记录实际进入的 Provider/Model 路由，`assistant/message` 与 `tool/call` 识别结构化工具调用，`tool/result` 结算调用，`step/end` 提交最近工具时间。只要工具步骤完整成功，证据与准入时是否勾选无关；未勾选只绕过插件输出，不会丢弃这条工具证据。助手中断、请求/Agent 错误、取消信号或缺少完整生命周期都会使待观察步骤失效；请求重试会清空失败尝试的调用计数。模型切换始终创建透明预热步骤，同一路由只有在最近一次成功工具步骤距当前严格少于 30 分钟时才跳过预热。这里不能通过 `Session.append()` 添加插件自定义记录，否则会改变历史协议并污染用户会话。

### 3. relay 一律 `surfaceOp: 'append'`，不用 replacement

`session.append('user/message', message, { surfaceOp: 'append' })` 把摘要作为**正常 durable 历史**写入，任何后续 provider/model 都能从 `Session.deriveMessages()` 读到；插件不安装路由过滤器、不追加空的 assistant replacement、不做二次遮蔽。旧版本曾用 replacement 遮蔽结束 turn 的 relay，结果是**不可逆的**：即便 raw log 里还在，当前 surface/derived history 已经被隐藏，移除代码也换不回来。这正是新代码不再使用 replacement 的原因。

### 4. reasoning-only 走 `agent.steer()`，同一 turn 内最多 3 次

模型只输出推理、既没有工具调用也没有用户可见答复时，插件用公开的 `agent.steer()` 在**同一 turn** 内排队一条 continuation notice，而不是新建用户 turn。上限 `MAX_REASONING_CONTINUATIONS = 3`，防止一个反复只输出推理的模型把 turn 拖成死循环。`continuationBlocked` 有**五条**置位路径，缺一条就会多推一次无谓的 notice：`max-tokens` 结束、流错误、流被中止、`agent/turn-stopping` 时 turn 已被中断、以及 `session/event` 上 `interrupted === true`。

消息对象缓存在 `state.continuationMessage` 上（同一 turn 内复用同一条），`relayAttempts >= 2` 是 relay 自己的上限——两者都是"失败不重试到天荒地老"的同一类护栏。

### 5. 文案常量集中在宿主半边，README 是第二落点

`PROMPT`、`MISSING_TEXT`、`PARTIAL_TEXT`、`REASONING_CONTINUATION_TEXT` 都定义在 `src/index.ts`，其中 `MISSING_TEXT` 与 `PARTIAL_TEXT` 被导出，供测试**按同一个字符串**断言（测试不重复写一遍文案，否则改文案就会静默失去覆盖）。README 的「插件要求模型做什么」一节里也抄了一份 `MISSING_TEXT` 与 `PARTIAL_TEXT` 的全文——那是**第二落点，不会自动同步**，见下面「面向模型的文案」。

### 6. 不依赖 `isAgentLoopRequest()`

`dsh-llm` 自带的 `isAgentLoopRequest()` 标记集是**模块局部**的。profile 插件可能解析到另一份物理副本，于是"宿主认得的标记"在插件这边可能不存在。插件改为自己判定：只处理没有 `purpose` 的主 Agent Loop 请求，并用当前步骤的取消信号确认请求归属，因此标题生成、压缩等复用同一 `sessionId` 的辅助调用不会进入摘要状态。durable `assistant/message` 上那条检查只是对"未经过本插件 stream hook"的调用方提供的防御性回退。

### 7. 标签配对取最近邻，且首个完整配对权威

`inspectSummary` 在**同一个文本块内**找最近邻的开/闭标签配对：前面的孤立开标签不会抢走后续的完整配对（模型常见的手误），而一旦出现完整配对该步骤的记录就定了。标签只在 text 通道里找——reasoning/thinking 内容一律不计为可用文本，摘要在插件看来是"缺失"。这条规则的落点是 README 的「插件要求模型做什么」：模型必须在可见文本里输出字面标签。

### 8. 客户端半边有两条身份字面量，必须与宿主逐字一致

`NS = 'reasoning-summary'` 必须与 `src/index.ts` 的 `SETTINGS_NAMESPACE` 逐字相同：宿主半边用它读配置文档，浏览器半边用它注册 locale namespace、并组成座位 key 的后半段；`PLUGIN_ID = '@zhourenke/dsh-reasoning-summary'` 必须与 `package.json` 的包名相同，组成座位 key 的前半段——`plugins.row.config` 是按 `<包名>#<行 id>` 分派的，所以 `NS` 还必须与 `cordis.patch.yml` 的 `- id:` 一致，三者错一个页面就分派不到。浏览器半边不能 `import` 宿主半边，所以这两个字符串只能各写一份——`test/client.test.mjs` 会把两种拼写和拼出来的 key 都断言一次，防止它们悄悄分叉。

### 9. 客户端 `inject` 同时列 `remote` 与 `remote.session`

`['slots', 'configForms', 'locale', 'remote', 'remote.session']`。`configForms` 是 0.2.0 取代 `settingsScope` 的服务（`get(ns)` / `whileServed([ns], …)`），客户端 `inject` 是**硬门禁**：漏声明的服务在运行期访问会被直接拒绝（`service "X" is not declared by your plugin`），名字不存在则插件停在 parked 状态并在装载结果里报 `waitingFor`——这与 `package.json` 的 `dsh.client.inject` 写错名字时**静默跳过**完全不同。两个都列有官方先例：同构的 `dsh-client-ui-settings-plugins` 与 `dsh-client-ui-model-selection` 同样同时声明这两个名字。

`sessionFace()` 因此保留三条解析路径——`ctx.get('remote.session')`、`ctx.get('remote').session`、`ctx.remote.session`——按"容器查找优先、属性访问兜底"排序。三者都有测试覆盖，**不要当成死代码删除**。

### 10. 插槽注册用 generator 形式，effect 交还给 `ctx.effect`

注册写成 `ctx.effect(() => configForms.whileServed([NS], () => ctx.slots.inject('plugins.row.config', () => ctx.slots.register({…}, Card))), …)`：`slots.inject` 在插槽的注册作用域里跑回调，返回值就是 disposer；`whileServed` 让注册只在宿主仍在服务这个 namespace 时存在，否则页面会跟着一个已经不在的条目留在那儿。**注册只声明 `locale: NS`，不要自己 bind 一个翻译器**——渲染器读到 `locale` 后会组合出座位上的 `t`，自己 bind 只会遮蔽同一个 prop（`test/client.test.mjs` 的假 `locale` 服务故意不提供 `bind`，写回 `locale.bind` 会立刻抛错）。locale 字典同理走 `ctx.effect(() => locale.register(NS, { zh, en }), …)`，把 disposer 交给 fiber，卸载时自动回收。**凡是返回 disposer 的注册都要交还**，否则重载后会留下重复注册。

### 11. 配置 schema 的 `models` 必须是 volatile 字段

`Config` 是 `z.object({ models: z.array(ModelSelectionSchema).default([]).volatile() })`。`.volatile()` 让 loader 每次装载都**重新读**这个字段，而不是把激活时取到的值冻住；交给 `apply` 的形式因此是一个带 `get()` 的盒子，`apply` 里按需读 `config.models.get()`。`src/index.ts` 的 `liveModels()` 同时接受盒子和裸数组，所以这个契约不会因为哪次版本变动就悄悄失效。空列表仍是唯一的关闭状态。

三条纪律：**依赖范围不能低于 `~3.18.4`**——`.volatile()` 在 3.18.2 里不存在（实测 `typeof z.array(item).volatile === 'undefined'`），宿主与兄弟插件都写 `~3.18.4`；**不要为了"顺手丢掉旧字段"在这层套 `z.transform`**，那会把 volatile 标记挪到包装层上，`test/core.test.mjs` 里那条 `Config.toJSON()` 断言（字段自身的 ref 上 `type: 'array'` 且 `meta.volatile: true`）就会失败；**文档里与本插件无关的字段现在会原样留在配置文档里**（实测 `retired: true` 仍然存在），插件只读 `models`，因此无害，但不要再写"读取时会被归一化丢弃"。

### 12. `\u0000` 是路由键的分隔符，宿主与客户端各有一份

宿主 `routeKey(provider, model)` 与客户端 `keyOf({ provider, model })` 都用 `\u0000` 拼接：`provider` 与 `model` 都可能含 `/`、`-` 这类字符，用可打印分隔符会出现"两个不同的路由拼出同一个键"。两份实现必须保持一致，否则卡片勾选的路由与宿主匹配的路由会错位。

### 13. 输出被缓冲成"伪非流式"，这是换稳定性与准确性付出的代价

`llm/stream` 的每个 chunk 都先进 `state.deferred`，直到步骤结束才由 `finishState` 一次性 `yield` 出去。缓冲换来两件做不到就要出错的事：**标签配对要在整段文本上做最近邻判断**（边流边判会在标签跨 chunk 时误判），以及**界面流的过滤必须在判定完成之后**（否则漏写标签的模型会把内部进度直接喷到界面上）。代价是被选中路由的回复不再逐字流式，用户感知为"伪非流式"——README 因此把它写在开头，作为安装前的衡量项。

**不要为了"恢复流式输出"把缓冲拆掉**：先确认上面两个前提能同时满足，再谈改动。

**2026-09 追加：缓冲不再"永远等到 finish"。** 实测某个 Codex 系 Provider 组合会把工具调用写成 claude-code 文本语法（`to=... (commentary) json {}`），DSH 不执行，模型于是在同一次输出里反复"思考→写摘要→重写坏调用→再思考"，直到输出预算耗尽（单步 output 可达 1.4–2 万 token、耗时 4–7 分钟，Provider 侧没有第二次请求）。这类自旋步会在同一输出内产生多个完整 `<summary>` 标签却零工具调用。插件据此判定疑似空转（`SPIN_RELEASE_SUMMARIES = 2`，最近邻配对计数）：立即放行本步已缓冲文本（用户可实时看到错误并中断止损），把本轮标记 finalized（避免 finish 再次走 relay/continuation 路径），向后续上下文注入插件自己的提示（`[No tool call received]`，**不是**模型的未执行摘要），并在 Session 运行时状态中置位自旋抑制。抑制期间后续已勾选步骤强制透明预热；只有没有再次触发自旋且完整成功的工具步骤到达 `step/end` 后才清除，下一步恢复提示。回滚快照会在该工具步骤后续报错时恢复抑制状态。放行只发生在 `sawToolCall === false` 的步骤，带真实工具调用的步骤完全不受影响；TTL 兜底留作后续，视效果再定。

`transformStream` 必须保持 Provider 的原始顺序，但不必把完整 reasoning block 留到 `finish`：`flushCompletedReasoningPrefix` 只会释放 `state.deferred` 开头连续、且 `block-start`/`block-end` index 相同的完整 reasoning block。这样 reasoning-merge 可实时收到合法的 start → delta → end 序列。普通文本、工具帧或 usage 一旦位于前缀，就仍是屏障并继续缓冲到摘要判定，因为它们可能需要被工具步骤过滤；让后续 reasoning 越过屏障会重排流。正常 finish 统一处理剩余缓冲区；自旋达到两个完整摘要时仍立即 flush 并切换直通，error/aborted finish 仍先对剩余缓冲区执行工具文本隐藏再保留非文本顺序。

### 14. 自旋判据只用插件自己的契约，不抓模型的外部特征

第一版方案是检测可见文本里的 `to=functions.pwsh`、`(commentary)`、`json {}` 这类 claude-code 文本工具调用痕迹。它被否掉的原因是**判据的归属**：这些字符串由模型与 Provider 定义，不在插件控制范围内，换模型、换 Provider、换版本就可能变样或消失，而失效是**静默的**——不报错，只是再也匹配不上，插件从"能识别"退化成"从不识别"，没有任何信号提示。

最终判据是"同一次输出里出现两个完整、互不包含的 `<summary>` 标签，且没有任何工具调用"（`countCompleteSummaryPairs` + `SPIN_RELEASE_SUMMARIES`）：`<summary>` 是插件自己要求模型产出的协议信号，模型是谁、坏调用写成什么形式都不影响判据成立，契约在判据就在。**新增任何"识别异常"的判断时，先找插件自身契约里有没有语义等价的信号，没有再看宿主稳定 API 与事件，最后才考虑外部特征**；采用外部特征时必须写明它是针对哪个模型的临时判据。

### 15. `missing` 大多来自机械执行步；用户中断不会丢掉注入的提示

某个 Codex 系 Provider 上的实测（8 个 turn、364 个工具步）：`[Action summary: missing]` 共 110 步（30%），其中 73 步是"有 reasoning 但没写可见摘要"（模型把计划留在思考里），37 步是**纯工具调用步**（`blocks` 只有 `tool-call`，连 reasoning 都没有，典型是连续 `edit` 的机械执行）；纯工具调用步 100% 记为 missing，单个 64 步的 turn 里 missing 占 23 步（36%）。这类步没有新的目标或思路，要求它输出摘要没有信息价值，**因此不增加"连续 missing 升级提醒"之类的机制**；观察指标是 missing 占比与纯工具调用步占比，等模型或 Provider 变化后再复核。

**用户中断的语义与类型注释给人的印象相反。** `inject()` 的实现是 `send(input, "next-step", false)`（进 `next-step` 队列、不唤醒 driver），`cancel(cause, options)` 只在 `!options.keepInbox` 时才 `inbox.clear()`——**丢弃是不传选项时的默认值**，而用户中断路径显式传 `keepInbox: true`（出处：`@deepseek-ai/dsh-agent-loop`、`@deepseek-ai/dsh-api-session-controller`，见 guide/contracts-with-host.md「inject 的队列在中断后仍活着」）。因此空转放行注入的 `[No tool call received]` 在用户中断后**仍留在队列里**，用户的下一条消息会唤醒模型并在同一个 pre-step 把它送进上下文（紧跟那条消息）——用户只需随口说一句，不必自己复述细节。凡是准备写进 README 的"用户操作后果"，都必须有实测或实现级调用点作证，不能只凭 `.d.ts` 里 `may` 的措辞推断。

### 16. 0.2.0-rc.2 迁移：删掉与官方重复的实现，接上官方范式

**三处硬不兼容**，任何一处都会让插件在运行期直接失效，且都不报"版本不对"这种明确错误：

1. **启动准入被拦**：peer 范围写着 `^0.1.5-rc.1`，宿主的准入闸门用 `semver.satisfies(运行时版本, 范围, { includePrerelease: true })` 判定，`0.2.0-rc.2` 不满足 → 整个 bundle 不加载。实测从 CONFLICT 变为 compatible 就是这个字段的功劳，改完用宿主自己的 `evaluatePluginCompatibility` 复核。
2. **座位被删**：`settings.plugin.item` 在 0.2.0 已不存在，插件列表也从"设置 → 插件"搬到了左侧边栏「插件」。自造卡片注册到不存在的座位不会报错，只是永远不出现。现在注册 `plugins.row.config`，按 `<包名>#<行 id>` 分派。
3. **图标被删**：`IconChevronDownOutline14` 在 primitives 里已移除（改名 `IconChevronDownOutlineRegular`），`require` 得到 `undefined`，渲染时才抛 —— 属于"绿灯通过类型检查、重启后才炸"的那一类。删掉自造卡片的外壳后这个图标也不再需要。

**一处类型层硬变更：消息来源不再有万能 `'plugin'`。** 0.2.0 把 `MessageSourceMap` 改成 merge-extensible，**每个生产者在自己模块里声明自己的 kind**，`'plugin'` 这个共用兜底被删除（官方 `dsh-repeat-tool-reminder` 就是自己声明 `'repeat-tool-reminder'` 的样板）。本插件用 `declare module '@deepseek-ai/dsh-llm'` 声明 `'reasoning-summary'`，运行时用 `const MESSAGE_SOURCE = { kind: 'reasoning-summary' }` 拼上各自的 `form`。这不是纯粹的改名——它同时保住了界面标签：chat 的 `contextProducer(source)` 只在少数已知 kind 上特判，其余走 `default: { role: 'inject', label: kind }`，所以这一行仍显示 **「上下文注入 · reasoning-summary」**；若把旧形状原样留着，标签会退化成「… · plugin」。`isProtocolContextMessage` 的判据也随之简化成"`kind` 是本插件的 + 没有 `form`"（kind 已唯一标识生产者，不再需要额外的 `plugin` 字段）。

**删掉的自造轮子（官方已有实现）**：卡片外壳、展开箭头、页脚、保存/放弃按钮与失败提示（官方 `SettingsForm` 全包）；`locale.bind(NS)` + 自铺 `t`（座位按注册里的 `locale` 组合 `t`）；`settingsScope`（换成 `configForms`）。`test/client.test.mjs` 与 `test/runtime.test.mjs` 都断言这些名字**不会再出现**，避免某次重构把它们带回来。

**保留的自造部分与理由**：行内的裸 `<input type="checkbox">` **不是**该删的重复——官方 `Checkbox` 必须自带一个 `label` 字符串，用在这条"勾选框 + 名称 + 路由"的两行行里会套出第二层 label，兄弟插件在同一界面上也是手写 input；路由列表的 `.rs-*` 样式（边框、分组、三列网格）同理，官方没有等价物。`SPIN_NOTICE_TEXT` 与官方 `dsh-repeat-tool-reminder` 的提醒也不重复：后者按连续相同调用的次数（默认 3/5/8）在 `tools/post-execute` 上计数，本插件的提示由"同一次输出两个完整摘要且零工具调用"触发，判据、时机与措辞都不同。

**显示元数据**：插件行现在从包里读 `icon` 与 `locale/*.json`（`meta.title` / `meta.description`），因此这两样必须进 `files` 与 `exports`；实测 `readPluginMeta` 返回两种语言的 title/description 与一个 `data:image/svg+xml;base64,…` 图标。缺 description 时列表会静默退回包名，所以这两件事要一起改。

### 17. 一轮审计：剩下来的"死代码"其实在测试桩里

**审计方法先划掉一半可能性**：两个 tsconfig 都开了 `noUnusedLocals` / `noUnusedParameters`，所以"没人用的局部声明"编译期就不可能存在。真正的死代码只剩四类：没人用的导出、没人用的 locale 键、没人用的 CSS、不可达分支，以及**守着早已不存在的宿主版本或已删除实现名的断言**。

**删掉的**：宿主半边的 `export interface ReasoningSummaryConfig`（源码、测试、文档里 0 引用，`ModelSelection` 仍在用所以留下）；`test/runtime.test.mjs` 里三个只属于上一代浏览器半边的用例（chat 行隐藏过滤器、走 `remote.session` 读目录、以及那个把 `rs-card|…` 全部外壳名一次断言的用例）——它们守的是 `connection.api`、`api.llm` 这类旧宿主 API 和 `rs-select`、`IconTrashOutline16`、`.rs-refresh` 这类被官方原语取代的实现名，以及随之孤立的 `readFileSync` import。

**留下并加固的**：`SETTINGS_NAMESPACE` 看着像只给浏览器半边用的常量，其实是座位键的一半——行 id 在**三处**拼写：`cordis.patch.yml` 的 `- id:`、`client.ts` 的 `NS`、注册时的 `key: \`${PLUGIN_ID}#${NS}\``。任一处不一致的结果是一个**永远拿不到 form 的页面**，而且只在控制台留一行警告，界面看起来只是"没渲染配置"。所以这里不该删，而该补一条漂移守卫：`test/core.test.mjs` 现在把 patch 的 `- id:` 列表、`client.ts` 里的 `NS` 字面量、`key` 模板与 `manifest.dsh.bundle.patch` 一起断言。

**真正的死代码在测试桩里**：`test/client.test.mjs` 的 `useState` setter 原本是空函数，注释还写着 "keeps no state between renders"。代价是两处断言降级成"读源码正则"——既看不到目录加载完成后的渲染，也看不到 `failed` 标志。现在桩按 hook 槽位保存状态，`renderSettled()` 重放状态更新引发的渲染轮次（`renderPass()` 每轮重置槽位游标并清空本轮 elements）。于是**源码正则换成行为断言**：拒绝写入后官方表单的 `state.failed === true`；暂存一次勾选让 `dirty` 变真、接受写入后变假，且暂存期间不产生任何写入。

**四类里剩下的都逐项查过，结论是干净的**：客户端那份样式表 14 个 `rs-*` 类**两头都对得上**（定义了都在用，用了都有定义，没有悬空引用）；客户端两份字典各 15 个键，与 `t()` 的 15 处引用**一对一**，且 `zh` / `en` 键名完全一致、没有只在一侧的键（漏一个键会让界面直接显示键名，而 `tsc` 看不出来）；`locale/*.json` 里只有 `meta`，它是插件行的显示元数据（`readPluginMeta` 读 `meta.title` / `meta.description`），不是界面字典，所以"没被 `t()` 用到"是正常的；两个宿主导出类型 `PluginConfig` 与 `ModelSelection` 出现在产出的 `lib/types/index.d.ts` 公共签名里（`apply(ctx: Context, config: PluginConfig)` 与 `PluginConfig.models: Volatile<ModelSelection[]>`），是活类型而非死导出——同一个位置原先那个没人引用的 `ReasoningSummaryConfig` 才是死的，已删。

**顺手补上的覆盖缺口**：原来的"未就绪"用例传的是 `form: undefined`，于是 `status !== 'ready'` 那条分支**根本没被覆盖**，配套的 `loading` fixture 是死设置。现在拆成三条：入口未挂载 → 什么都不渲染；`loading` → 什么都不渲染（否则每次开行都会闪一下"不可用"）；`unavailable` → 交给官方 `SettingsForm` 的 `state.available` 与 `labels.unavailable`，插件不再自己画提示。

### 18. "看不到上下文注入"是 0.2.0-rc.2 的预期行为，不是故障

**先说结论**：本插件注入的文本**不会**出现在聊天记录里，这是宿主当前版本的渲染规则，任何插件侧改动都做不到，伪装成工具增删块只会污染徽标语义。

**依据**：`dsh-client-ui-chat/lib/client.js` 的 `isVisibleChatNode` 要求 `node.kind !== "system-prompt"`，且 context 行必须含 `tool-addition` / `tool-removal` 内容块才可见——**纯文本注入的上下文行与 `system-prompt` 行一律不渲染**，与 `transcriptView` 模式无关（compact / standard / detailed / verbose 只控制 `foldCompletedTurns`、`stepGrouping`、`liveProcessDetail`、`settledReasoningPreview`）。`contextProducer(source)` 的 `default` 分支仍把 `reasoning-summary` 标成「上下文注入 · reasoning-summary」，但那条行现在只对带工具增删的 context 成立；系统提示词同理，它的行在列表构建阶段就被过滤掉了。

**所以判据是持久日志，不是界面**：`tools/inspect-session.mjs` 直读 `$DSH_HOME/sessions/--<cwd>--/<id>/session.v4.jsonl.zstd`（也接受导出 `.zip` 与已解压的 `.jsonl`），按 `source.kind === 'reasoning-summary'` 分类，打印会话/路由/配置行/插件活动/投递/kinds 与一条 verdict；退出码 `0` 活跃、`1` 未活动、`2` 读不出来。用法：

```bash
node tools/inspect-session.mjs                 # 当前会话（读 DSH_SESSION_ID）
node tools/inspect-session.mjs <session-id>    # 按 id 找实时日志
node tools/inspect-session.mjs <日志或 zip 路径>
node tools/inspect-session.mjs <目标> --json   # 机读输出
```

**它踩过并固化了四个坑，改这个工具时不要退回去**：

1. 实时日志是**多帧 zstd 流**（追加写），`zstdDecompressSync` 一次只解第一帧——必须按帧魔数 `28 b5 2f fd` 切分后逐帧解压。实测 30 个候选帧、0 个失败，拼出的 78 行与导出 zip 里的内容**逐字节一致**（311092 字节）。
2. 导出 zip 是**流式单条目**：本地头里的 `compressedSize` / `uncompressedSize` 都是 0，长度只在 data descriptor（`50 4b 07 08`）里，不能按头解。
3. 同一消息**既有 `agent/inbox/spliced` 投递又有 `user/message` 持久记录**（两者的 `message.id` 相同），两边都数会让每次 relay 翻倍。现在以持久记录为准，投递单独统计，并核对"每个投递都有持久对应"——这条检查本身有意义：投递了却没有持久记录，意味着这一步消费了记录里看不到的东西。
4. 路由要读**最后一次** `model/selection`。会话中途可以换模型，只读第一次会把一个早已离开配置路由的会话判成"已选中"（本工作区的会话实测有 17 次选择）。

**实测（2026-09-30，宿主 0.2.0-rc.2）**：新会话 `session-6a9059a5-…` 判 ACTIVE——协议上下文 1 段（seq 24，1166 字符，无 `form`）、relay 6 次（5 完整 + 1 `missing`）、投递 6 次全部有持久对应、kinds 去重后 `reasoning-summary` 7 条、旧形状 `plugin` 0 条。而**本工作区的长会话判 INACTIVE 且不是故障**：它当前路由 `parkgarden/deepseek-v4.1-flash` 不在配置的两条里，插件按设计不介入（该会话里 460 条 `plugin:reasoning-summary` 是迁移前形状，工具会单独标出来）。这两条合起来正好说明为什么"界面没动静"不能拿来当判据。

## 测试要点

- **`core.test.mjs`**：纯函数。`inspectSummary` 的 complete/partial/missing 三态、最近邻配对与孤立标签、`normalizeTextBlocks` 的 `forcedStatus` 分支、`routeKey` 的分隔符语义。
- **`runtime.test.mjs`**：用模拟 ctx 调 `apply`，这是唯一能覆盖事件注册路径的办法。重点是**时序**——relay 必须等所有根工具调用的 durable `tool/result` 提交后才进 inbox；`session/event` 在 `Session.append` 的发布边界内触发，所以改写 inbox 要放进 `queueMicrotask`，否则会撞上 append 自身。另有跨路由可见性、A/B/C/D 序列、设置禁用与重新启用、已准入步骤中途切换后仍跑完、同 session 标题/异信号辅助流隔离、工具结果去重、失败步骤隐藏文本但不建 relay、`prepared-call` 防御性回退；另有三个用例覆盖疑似空转放行：两个完整摘要且零工具调用时放行并注入插件提示（断言注入文本不含模型自己的摘要）、带真实工具调用的步骤不触发、单个摘要不触发。
- **`client.test.mjs`**：唯一**真正执行** `lib/client.js` 的测试。先注入 `window.__ModuleLoader__` 捕获注册定义，再用桩 `require` 调用工厂、用模拟 ctx 调 `apply`，最后真的挂载一次两种视图。文件头把实测到的宿主契约写进注释与桩里（`plugins.row.config` 按 `<包名>#<行 id>` 分派、owner props 是 `{ view, form? }`、`configForms.whileServed` 限定注册存活、`mutate(ops, revision)` 返回是否被接受、`SettingsForm` 的 `labels`/`state`/`onSave`/`onDiscard` 形状）——**桩一旦与真实契约漂移，测试就从"发现缺陷"变成"掩盖缺陷"**（guide/verification-method.md「验证本身也会骗你」）。桩里的假 `locale` 服务**故意不提供 `bind`**，这样"自己 bind 一个翻译器"会立刻抛错而不是静默遮蔽座位组合出来的 `t`。
- **跨插件契约**：用**真实的** `dsh-repeat-tool-reminder` 代码验证"注入的消息不会重置它的重复计数"（该守卫只注册两个 handler、不依赖其它服务，所以能用两行 `ctx.on` 装进同一进程），并配一条**反向对照**——同样大小的 pre-step 批次里换成 `source.kind === 'user'` 的消息时链确实会被清除。没有这条对照，主测试可能因为"清除分支从未执行"而通过。这也是 `@deepseek-ai/dsh-repeat-tool-reminder` 出现在 `devDependencies` 里的**唯一**原因：本包从不 import 它，只有测试加载它，请勿当成未使用的残留删除。
- **检查器必须先验红**：断言里凡是出现"用正则/转义去匹配常量"的写法，都要先拿一个必然含元字符的样本确认它真的会失败。本项目就抓到过一条：`new RegExp(TEXT.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\$&'))` 的字符类提前闭合，实测一个字符都不转义，只因为常量里唯一的元字符是 `.`（不转义也能以通配符匹配自己）才一直通过。现在改用 `includes`。

## 面向模型的文案（两处落点，互不同步）

下面五段文案决定模型看到什么，其中三段在 README 里有一份副本：

| 常量 | 定义处 | README 副本 | 谁读它 |
|---|---|---|---|
| `PROMPT` | `src/index.ts` | 无（README 只描述协议） | 每个 Session 首个 enabled、非 warmup 步骤的普通上下文消息；宿主随后将其写入正常 `user/message` 历史，后续步骤和 turn 不重复注入；插件重新激活时从 durable history 识别已有协议上下文 |
| `MISSING_TEXT` | `src/index.ts`（导出） | 有，全文 | relay 的 `[Action summary: missing]` 附注 |
| `PARTIAL_TEXT` | `src/index.ts`（导出） | 有，全文 | relay 的 `[Action summary: partial]` 附注 |
| `REASONING_CONTINUATION_TEXT` | `src/index.ts` | 无 | reasoning-only continuation 的正文 |
| `SPIN_NOTICE_TEXT` | `src/index.ts` | 有，全文 | 疑似空转放行后注入的 `[No tool call received]` 提示 |

**改任何一段都必须回头核对 README**，反之亦然：副本不会自动同步，而它恰恰是使用者（和检索到 README 的 Agent）据以判断"模型该输出什么"的唯一依据。文案本身也有纪律：只说**要求与后果**，不描述内部实现，且改文案后必须重跑 `pnpm test`（测试按字符串断言）。

## 发布纪律

- **`lib/` 的四个产物必须与 `src/` 同一次提交。** `dsh plugin add github:...` 只接收 git 跟踪的文件，本仓库不在安装时构建，所以产物不同步会让 GitHub 安装静默运行旧代码。只提交 `.js` 而漏掉 `lib/types/` 会造成「装得上但没有类型声明」的半发布状态。
- **不要添加 `prepare` 脚本。** git 托管的包会在安装时执行它，而 pnpm 默认拦截依赖的构建脚本，这会让 `dsh plugin add` 直接失败，直到用户手动在 profile 的 `pnpm-workspace.yaml` 中放行。
- **`files` 只列不会被自动包含的产物。** 当前为 `lib/index.js`、`lib/client.js`、`lib/types/**/*.d.ts`、`cordis.patch.yml`、`icon.svg`、`locale/*.json`。`package.json` / `README*` / `LICEN[CS]E*` 以及 `main` 指向的文件无论如何都会装上，列了是空操作；而 `types` 与 `exports` 的目标**不在**自动包含集里，`.d.ts` 一旦漏出 `files` 就会被静默丢弃；`icon` 与 `locale/*.json` 是宿主读显示元数据的入口，漏掉只会让插件行退回包名，不会报错，所以更要靠这份清单兜住。`DEVELOPMENT.md` 同样不在自动包含集里（`README*` 不等于所有 `.md`），所以它不会进入安装载荷。
- 新增产物（第二入口、运行时读取的数据文件）时，必须同步放宽 `files`，并用 `pnpm pack --dry-run` 核对真实载荷。

## 运行时依赖（与 DSH 版本匹配）

宿主提供的包走 `peerDependencies` 并全部标 `optional: true`（阻止 pnpm 引入第二份副本）：

| 包 | 版本 | 用途 |
|---|---|---|
| `@deepseek-ai/cordis` | `^4.0.4` | 插件框架、`Volatile` 类型（走自己的版本线） |
| `@deepseek-ai/dsh-agent` | `^0.2.0-rc.2 \|\| ^0.2.1-rc.2` | `Agent`、`agent/pre-step` 等事件、`steer()` |
| `@deepseek-ai/dsh-llm` | `^0.2.0-rc.2 \|\| ^0.2.1-rc.2` | `llm/stream` 瀑布、`StreamChunk`、`createUserMessage`、`MessageSourceMap`（本插件往它上面合并自己的 kind） |
| `@deepseek-ai/dsh-system-prompt` | `^0.2.0-rc.2 \|\| ^0.2.1-rc.2` | `system-prompt/assemble` 里取最终 route |
| `@deepseek-ai/dsh-tools` | `^0.2.0-rc.2 \|\| ^0.2.1-rc.2` | `tools/result` 事件 |
| `@deepseek-ai/schemastery` | `~3.18.4` | 配置校验，**唯一真实的 `dependencies`**；用 `~` 是硬要求，`.volatile()` 在 3.18.2 里不存在 |

已测试版本：**DSH v0.2.0-rc.2**（2026-09）与 **v0.2.1-rc.2**（2026-10），双轨支持。升级 DSH 后逐个核对**值导入**是否仍是宿主导出（过渡 API 会悄悄变成内部符号，插件解析到自己的私有副本时永远看不见）。

`dsh-settings` 已从 peer 与 devDeps 一起移除：配置不再经服务，宿主也不再需要我们声明它的类型增强。

`devDependencies` 里的宿主包**钉死到基线精确版本**（`4.0.4` / `0.2.0-rc.2`）：连接点安装时插件解析到的是自己 `node_modules` 里的副本，写范围就会对着与线上不同的宿主做类型检查与测试；`0.2.1-rc.2` 的类型校验与端到端在 `_next-compat/` 隔离环境中复核。`@deepseek-ai/dsh-client-ui-primitives`（浏览器半边现在只取它的 `SettingsForm`）与 `@deepseek-ai/dsh-repeat-tool-reminder`（跨插件契约测试）同样只在 `devDependencies` 里。

`import type {} from '@deepseek-ai/dsh-…'` 是**类型增强导入**，只在类型层存在：这些包把各自的事件并进 Cordis 的 `Events` 接口，不加载声明文件就没有订阅事件名的类型。当前 `dsh-agent` 与 `dsh-llm` 是真的在导入类型（`Agent`、`PreStepDecision`、`StreamChunk`、`ConversationMessage`、`ContextFormed`），**只有 `dsh-system-prompt` 与 `dsh-tools` 是纯增强**——`system-prompt/assemble` 只由 `dsh-system-prompt` 声明，它若只作为 `dsh-agent` 的传递依赖出现就属于巧合而非依赖。`import type {}` 在运行时被完全擦除，因此不会拉进宿主包的私有副本，也不会被 `noUnusedLocals` 报为未使用；反过来，这些行看起来"没用到"也不要删。

DSH 升级后按 `PLUGIN_RELEASE_GUIDE.md`「DSH 升级后的复核」重新核对事件名、宿主符号与 peer 范围。

工作区级文档 `PLUGIN_RELEASE_GUIDE.md`（位于仓库外的 `DSH_Workspace/CreatePlugin/`，**不随 git 分发**）收录了更完整的开发、发布与排错经验：构建提交纪律、连接点安装的连带后果、模型文案的落点与取证、`tsc` 拼接缝等。开发时对照查阅。

**版本号怎么算、什么时候改，也以它为准**（「插件版本号」一节）：号写成「支持窗口下界的宿主版本收掉预发布里的点 + `.<n>`」（双轨支持下仍为 `0.2.0-rc2.2`，窗口上界由 `peerDependencies` 与 README 表达；下次 tuple 迁移至 `0.2.1` 时采用保留点的 `rc.2.N` 形状，如 `0.2.1-rc.2.1`），而**改号只在用户要求时发生**——用户会在推送前提出，没提就不要动 `package.json` 的 `version`，也不要追问"要不要升号／要不要推送"。

## 许可证

MIT
