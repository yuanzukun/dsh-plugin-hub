// 小说助手 · 正文铁律确定性检查引擎
// -----------------------------------------------------------------------------
// 纯函数、零依赖、零模型调用：输入一段正文，输出硬/软违规清单。
//
// 从 novel-tools.mjs 拆出为独立模块，原因有两个：
//   1. 可被 tools/test-lint.mjs 直接 import 做单测（规则改动的回归保障）；
//   2. 检查引擎与工具装配解耦，novel_lint 与 novel_project 的保存门禁共用同一份实现。
//
// 分级约定：
//   hard = 必须修的硬违规（标点、引号、Markdown 残留、结构错配），修复后才允许落盘；
//   soft = 建议逐条核对的软违规（禁词、频次、句式密度），语境误报可忽略。
//

// ---------------- 词库 ----------------

// 禁用词与模板化表达（一级套路化，出现即改；分级词库见 novel-ai-lexicon skill）
const BANNED = [
  '心中一沉', '瞳孔骤缩', '瞳孔微缩', '倒吸一口凉气', '后背发凉', '心脏漏跳', '他的心一跳', '指尖微颤', '眼底闪过', '嘴角勾起', '勾起一抹', '嘴角微微上扬', '嘴角扬起', '勾唇一笑', '扯出一个笑', '面色一变', '神色复杂', '眼中闪过', '心中一凛', '心中一动', '心中一片平静', '心下了然', '心中了然', '指节泛白', '指节发白', '后槽牙咬紧', '微微挑眉', '不容置疑', '不可置疑', '不可置信', '行云流水', '话锋一转', '眼神深邃', '眼神坚定', '眼神锐利', '眼神热切', '目瞪口呆', '嘴巴张得能塞下', '时间仿佛', '像淬了毒', '重重砸在', '眼中流露出', '空气凝滞', '空气安静', '空气瞬间安静', '脸上堆满了笑', '世界都安静', '远没有这么简单', '不知过了多久', '一室寂静', '难以言喻', '无法形容', '意味深长', '耐人寻味', '他不知道的是', '复杂的情绪', '眼眸', '薄唇', '不卑不亢', '隐隐有了猜测', '近乎偏执', '力道大得惊人', '让空气的温度都下降', '透露出的寒意', '像在看一个',
  // 第二代伪外化与套话（AI 味新特征，见 novel-ai-lexicon 结构层）
  '呼吸一滞', '呼吸一窒', '心头一紧', '喉结滚动', '指腹摩挲', '眸光', '眸色', '眸子', '眸底', '笑意不达眼底', '几不可察', '几不可闻', '气氛降到', '沉默蔓延', '过了一个世纪', '才刚刚开始', '深不可测', '高深莫测',
  // 生理与状态套话（skill 一级区第 6 节，短语级低误伤）
  '僵住了', '声音平静', '声音坚定',
  // 心动套话（novel-style-romance「心里一颤」家族——言情流反复交差的心动模板反应；
  // 所有题材通用：真实心动写感官细节与专属动作，见 novel-style-romance 心动可感条）
  '心里一颤', '心中一颤', '心头一颤', '心里一紧', '心尖一颤',
  // 仙侠空镜套话（novel-style-xianxia「一剑斩出，天地变色」家族——用天地异象替代具体
  // 攻防画面；所有题材通用：招式与斗法写具体画面与攻防逻辑，见 novel-style-xianxia 打斗写意境条）
  '天地变色', '风云变色', '风云为之变色', '万物失色', '众生噤声', '万籁俱寂', '日月无光',
  // 悬疑氛围点名词（novel-style-mystery「恐怖写感受不写名词」条：恐怖来自感官细节与生理反应，
  // 不来自“恐怖/诡异”这类词本身）。只收搭配腔（感到/十分+氛围名词=情绪标签），裸词走 ATMOS 限频——
  // 悬疑流正当氛围词禁用会误伤。
  '感到一阵恐怖', '感到恐怖', '感到一阵诡谲', '十分诡异', '说不出的恐怖', '诡谲可怖', '可怖',
  // 数字装具体（秒表式计时与“第 N 次”模板）
  '沉默了三秒', '沉默了几秒', '停顿了几秒', '停顿了三秒', '三秒后', '几秒钟后', '两秒钟', '第无数次', '数不清第几次',
  // 万能群像反应（围观/对视全是模板）
  '四目相对', '交换了一个眼神', '交换眼神', '相视一笑', '相视而笑', '心照不宣', '不约而同', '异口同声', '默契地', '会心一笑',
  // 情绪成语标签（tell 不 show，一个成语打包一种情绪）
  '如释重负', '恍如隔世', '五味杂陈', '百感交集', '百般滋味', '思绪万千', '感慨万千',
  // 生理反应第三代（学习“写身体”之后的模板化身体）
  '头皮发麻', '大脑一片空白', '头脑一片空白', '血液凝固', '浑身一震', '浑身一僵', '背后一凉', '后背一凉', '脊背发凉', '背脊发凉', '太阳穴突突', '太阳穴狂跳', '眼皮狂跳',
  // 声音/寂静万能框架
  '回荡着', '回荡在', '弥漫着', '空气中弥漫', '空气里弥漫', '落针可闻', '针落可闻', '时间静止', '世界仿佛只剩', '整个世界安静',
  // 翻译腔弱动词（“进行了”系列，动作被抽象化）
  '进行了一次', '进行了一番', '进行了一场', '作出了', '作出反应', '作出回应', '给予了一个',
  // 看似实则（先立假象再反转的评论腔）
  '看似', '实则', '表面上看',
  // 嘴角眼尾系补充（第一代特征的残余变体）
  '嘴角的笑意', '嘴角挂着', '嘴边噙着', '噙着笑', '眼尾泛红', '眼尾上挑', '眼底藏着', '眸中闪过', '骨节分明',
  // 拟声滥用（skill 一级区第 8 节：写结果不写声）
  '轰', '炸雷', '闷响',
  // skill 一级区补收（tools/check-lexicon-sync.mjs 校验出的漂移：眼神/声音框架、伪具体比喻、反应套话）
  '锐利的眼睛', '目光扫过', '目光里毫不遮掩', '声音不大', '缓缓地说', '的口吻', '还要冰冷', '刺入', '炸开', '波涛汹涌', '沉默在两人之间蔓延', '一只无形的手', '凝固',
  // prose-standards 禁用表补收（2026-11 对照）：「纤长的手指」直接删——手写动作，不写长度
  '纤长',
];

// 万能量词（全砍）
const QUANTIFIERS = ['一丝', '一抹', '几分', '一股', '些许', '带着一丝'];

// 副词/高频词（每词上限 2 次）
const ADVERBS = ['缓缓', '轻轻', '微微', '不由得', '忍不住', '下意识地', '突然', '忽然', '猛地', '顿时', '瞬间', '立刻', '连忙', '渐渐', '显然', '果然', '沉吟', '小心翼翼', '不动声色', '似乎', '淡淡', '不禁', '深吸一口气', '下一秒', '下一瞬', '随即', '旋即', '闻言', '见状', '听罢', '注视', '凝视', '目光落在', '视线落在', '收回视线', '愣了愣', '怔住'];

// 次高频词（每词上限 3 次）
// 末 8 个心理动词出自 skill 二级区「心理动词」小节（tell 类，换行为展示）：
// 「他/她/我知道」收三字模板形，裸「知道」是白名单词不收；「不知道」不含「我知道」子串，互不干扰。
const SOFT_FREQ = ['顿了顿', '沉默', '苦笑', '无奈', '半晌', '回过神', '一时间', '若有所思', '似笑非笑', '攥紧', '片刻后',
  '觉得', '感觉到', '意识到', '察觉到', '注意到', '他知道', '她知道', '我知道'];

// 迂回缓冲关联词（skill 二级区「迂回定义关联词」小节：句式层零容忍的词级兜底）
// 叙述层合计 ≤2（对话豁免——人物口语里「严格来说」是正常表达）；长词包含短词时只计长词，避免双计。
const ROUNDABOUT_CONN = ['似乎更', '更像是', '更确切地说', '确切地说', '更准确地说', '准确地说', '严格来说', '在某种程度上', '某种程度上', '有那么一瞬间', '仿佛在说'];

// 高浓度氛围词（skill 二级区「高浓度氛围词」：堆砌即油腻，单个正常）
// 与其他二级词的按词限频不同，这组的病灶是合计密度——19 个词各来一次照样油腻，故按每千字 ≤2 计。
const ATMOS = ['冰冷', '冰凉', '清冷', '漆黑', '沉重', '窒息', '扭曲', '撕裂', '沸腾', '剧痛', '甜腻', '闪烁', '电弧', '裹挟', '郑重', '精准地', '微妙', '古怪', '僵硬',
  // 悬疑流氛围名词（novel-style-mystery：恐怖写感受不写名词）——悬疑文正当用词不禁用，
  // 但作为氛围标签堆砌即偷懒，与其他高浓度氛围词同按合计密度 ≤2/千字限频
  '恐怖', '诡异', '诡谲', '阴森'];

// 极端词（密度制：每千字 ≤2）
const EXTREME = ['非常', '极其', '极大', '无比', '十分', '瞬间', '顿时', '刹那'];

// AI 转折词/书面连接词
const AI_CONN = ['然而，', '与此同时', '不仅如此', '值得一提的是', '不得不说', '综上所述', '由此可见', '某种意义上', '总而言之', '换句话说', '换句话说来说', '总得来说', '总体而言', '一般而言'];

// 万能举例框架（“例如/比如”后接抽象名词的解释腔）
const EXAMPLE_CONN = ['比如说，', '举个例子', '简而言之', '说白了就是', '换言之'];

// 章末模板收尾（气氛句/升华句当钩子）
const TAIL_TEMPLATES = ['才刚刚开始', '夜，深了', '夜色渐深', '故事，才', '他知道，这一切', '他不知道的是'];

// 对话标签
const DIALOGUE_TAGS = ['说道', '问道', '答道', '应道', '开口道', '开口说道', '沉声道', '冷声道', '淡淡道', '低声道', '轻声道', '缓缓开口', '笑道', '叹道', '应了一声'];

// 常用主语/人称（连续同句式开头检测用）
const SUBJECT_START = /^(他|她|它|我|你|林|苏|叶|楚|萧|陈|秦|李|张|王|刘|周|赵)/;

// 段尾总结句
const TAIL_SUMMARY = /^(他知道|她知道|他明白|她明白|这一刻，|这一次，|或许，|也许，|仿佛)/;

// 默认章节字数区间（与 persona 的「单章默认标准」一致）
const CHAPTER_MIN = 2000;
const CHAPTER_MAX = 4000;

// ---------------- 引擎 ----------------

// 正则元字符转义（迂回关联词等纯字面量词条安全地拼进 RegExp 用）
function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * 检查正文。
 * @param {string} body 正文纯文本
 * @returns {{hardCount: number, softCount: number, issues: Array<[string,string,string]>, report: string}}
 */
export function lintText(body) {
  const text = typeof body === 'string' ? body : '';
  const issues = [];
  const occurs = (w) => text.split(w).length - 1;
  const countRe = (re) => (text.match(re) || []).length;
  const chars = text.replace(/\s+/g, '').length;
  const push = (level, name, detail) => issues.push([level, name, detail]);

  // ── 一、标点纪律（整章级） ──────────────────────────────────────────
  const dash = countRe(/——/g);
  if (dash > 1) push('hard', `破折号（——）出现 ${dash} 次`, '整章上限 1 次，且只用于对话被打断');
  const ellipsis = countRe(/……/g);
  if (ellipsis > 2) push('hard', `省略号（……）出现 ${ellipsis} 次`, '整章上限 2 次，只用于对话犹豫');
  const semis = countRe(/；/g);
  if (semis > 0) push('hard', `正文出现分号 ${semis} 处`, '正文不用分号；一句话说不完拆成两句');

  // 感叹号按段（一段最多 1 个）
  const badPara = [];
  for (const p of text.split(/\n+/)) {
    if (!p.trim()) continue;
    const n = (p.match(/[！!]/g) || []).length;
    if (n > 1) badPara.push(p.trim().slice(0, 14));
  }
  if (badPara.length) push('hard', `${badPara.length} 个段落感叹号超过 1 个`, `如“${badPara[0]}…”`);

  const stacked = countRe(/[？！]{2,}|[。]{3,}/g);
  if (stacked > 0) push('hard', `标点堆砌（？？/！！等）${stacked} 处`, '禁止用标点堆砌情绪');

  // 正文残留 Markdown
  if (/^#{1,6}\s|\*\*|```/m.test(text)) push('hard', '正文残留 Markdown 符号（#/```/加粗）', '正文必须纯文本');

  // 简体网文标点规范——直角引号/英文引号/错误省略号/装饰符号
  const cornerQuotes = countRe(/[「」『』]/g);
  if (cornerQuotes > 0) push('hard', `直角引号「」『』出现 ${cornerQuotes} 处`, '简体网文用弯双引号“”（嵌套用‘’），不用直角引号');
  const engQuotes = countRe(/"[^"\n]{1,40}"/g);
  if (engQuotes > 0) push('hard', `疑似英文直引号 "…" 出现 ${engQuotes} 处`, '一律改为中文弯引号“”');
  const badEllipsis = countRe(/\.\.\.|。。。/g);
  if (badEllipsis > 0) push('hard', `错误省略号（.../。。。）出现 ${badEllipsis} 处`, '中文省略号用 ……（六点一个标点）');
  const decorations = countRe(/[✦✨◆●★☆♦❖✳✴]/g);
  if (decorations > 0) push('hard', `装饰符号（✦✨◆★等）出现 ${decorations} 处`, '正文与标题一律不撒装饰符号，分隔用空行');

  // 引号/括号配对：数量不等必然是漏写或错位，落盘前必须修
  const openQuote = countRe(/“/g);
  const closeQuote = countRe(/”/g);
  if (openQuote !== closeQuote) push('hard', `弯双引号不配对（“${openQuote} 个 / ”${closeQuote} 个）`, '补齐或删除多余的引号，引号必须成对出现');
  const openSingle = countRe(/‘/g);
  const closeSingle = countRe(/’/g);
  if (openSingle !== closeSingle) push('hard', `弯单引号不配对（‘${openSingle} 个 / ’${closeSingle} 个）`, '引语内嵌套的单引号必须成对');
  const openParen = countRe(/（/g);
  const closeParen = countRe(/）/g);
  if (openParen !== closeParen) push('hard', `圆括号不配对（（${openParen} 个 / ）${closeParen} 个）`, '补齐或删除多余的括号');

  // 半角标点混入中文句子（中文后紧跟 , ; ! ? 一律改全角）
  const halfWidth = countRe(/[\u4e00-\u9fff][,;!?]/g);
  if (halfWidth > 0) push('hard', `中文句子里的半角标点 ${halfWidth} 处（如“他,然后”）`, '中文正文一律用全角标点：，；！？');

  // ── 二、禁用词与模板化表达 ──────────────────────────────────────────
  const bannedTerms = BANNED.map((w) => [w, occurs(w)]).filter(([, n]) => n > 0);
  // 长短词重叠时只报长词（“空气瞬间安静”不再重复报“空气安静”）
  const bannedHits = bannedTerms
    .filter(([w, n]) => !bannedTerms.some(([w2, n2]) => w2 !== w && w2.includes(w) && n2 === n))
    .map(([w, n]) => `“${w}”×${n}`);
  if (bannedHits.length) push('soft', '禁用词/模板化表达', bannedHits.join('、'));

  const quantHits = QUANTIFIERS
    .map((w) => [w, occurs(w)])
    .filter(([, n]) => n > 0)
    // 长短词重叠只报长词（“带着一丝”出现时不再重复报“一丝”）
    .filter(([w, n]) => !QUANTIFIERS.some((w2) => w2 !== w && w2.includes(w) && occurs(w2) === n))
    .map(([w, n]) => `“${w}”×${n}`);
  if (quantHits.length) push('soft', '万能量词', `${quantHits.join('、')}（全砍）`);

  const advHits = ADVERBS.map((w) => [w, occurs(w)]).filter(([, n]) => n > 2).map(([w, n]) => `“${w}”×${n}`);
  if (advHits.length) push('soft', '副词/高频词频次超限（每词上限 2 次）', advHits.join('、'));

  const softHits = SOFT_FREQ.map((w) => [w, occurs(w)]).filter(([, n]) => n > 3).map(([w, n]) => `“${w}”×${n}`);
  if (softHits.length) push('soft', '次高频词密度超限（每词上限 3 次）', `${softHits.join('、')}——正常词限频不限用，超限说明写成了模板反应`);

  // ── 三、密度与句式 ──────────────────────────────────────────────────
  // 叙述层文本：把成对引号及其内文整体替换成一个句号。句式套路只查叙述层——
  // 引语是人物语言，对话里的自然澄清（“我说的不是这个意思”）不该按叙述腔挨罚；
  // 替换成句号还能挡住「不是……“引语”……而是」这类跨引号拼接出的假匹配。
  const narrative = text.replace(/“[^“”]*”/g, '。');
  const countNarrative = (re) => (narrative.match(re) || []).length;
  const kChars = Math.max(1, Math.round(chars / 1000));
  const extremeTotal = EXTREME.reduce((s, w) => s + occurs(w), 0);
  if (extremeTotal > kChars * 2) push('soft', `极端词 ${extremeTotal} 个（约 ${kChars} 千字）`, '密度应 ≤2/千字；程度靠具体画面给，删九成');

  // 「不是……而是……」归入下方迂回定义句式家族统一报出（避免同一句式双重计数）
  const jiuZai = countRe(/就在这时|刹那间|的瞬间|此刻|这一刻|一时之间/g);
  if (jiuZai > 2) push('soft', `“就在这时/刹那间/的瞬间/此刻/这一刻”合计 ${jiuZai} 次`, '整章合计上限 2 次');

  // 高浓度氛围词（skill 二级区）：合计密度制，每千字 ≤2（单次不报，堆砌才报）
  const atmosHits = ATMOS.map((w) => [w, occurs(w)]).filter(([, n]) => n > 0);
  const atmosTotal = atmosHits.reduce((s, [, n]) => s + n, 0);
  if (atmosTotal > kChars * 2) push('soft', `高浓度氛围词 ${atmosTotal} 个（约 ${kChars} 千字）`, `命中：${atmosHits.map(([w, n]) => `“${w}”×${n}`).join('、')}——合计密度应 ≤2/千字，单个正常，堆砌即油腻；改具体物证`);

  // 迂回缓冲关联词（skill 二级区）：叙述层合计 ≤2（对话豁免；长词包含短词只计长词）
  const rbConnCount = (w) => countNarrative(new RegExp(escapeRegExp(w), 'g'));
  const rbConnHits = ROUNDABOUT_CONN.map((w) => [w, rbConnCount(w)])
    // 「更确切地说」含「确切地说」，两处命中数相同则短词是长词的子串重复，丢弃
    .filter(([w, n]) => n > 0 && !ROUNDABOUT_CONN.some((w2) => w2 !== w && w2.includes(w) && rbConnCount(w2) === n));
  const rbConnTotal = rbConnHits.reduce((s, [, n]) => s + n, 0);
  if (rbConnTotal > 2) push('soft', `迂回缓冲关联词合计 ${rbConnTotal} 次`, `命中：${rbConnHits.map(([w, n]) => `“${w}”×${n}`).join('、')}——叙述层合计上限 2 次，都是缓冲腔：删掉句意无损，直接说结论`);

  // ── 迂回定义句式家族（零容忍：先否定/迂回再给结论，全是废话） ────
  // 「不是X，(而)是Y」丢掉否定半边句意无损；「并非/从来不是」是评论腔；
  // 「不仅仅是」扩围、「与其说是A不如说是B」比较修辞，同为 AI 高频迂回。
  // 无可信理由——真正的对比（两个选项摆在天平上）写法见 skill 文档。
  // 只查叙述层：对话内澄清（“我说的不是这个意思”“我不只是你的搭档”）
  // 是人物在说话，不是作者的迂回腔，不许罚。
  const roundabout = [];
  const rbPairs = [
    [/不是[^。！？\n]{0,24}?[，,][^。！？\n]{0,4}?而是/g, '不是……而是……'],
    [/不是[^。！？\n]{0,20}?[，,]是/g, '不是……，是……'],
    [/(从来|并|绝|从)不是|并非/g, '从来不是/并不是/并非'],
    [/不仅仅?是|不只是/g, '不仅仅是/不只是'],
    [/与其说是[^。！？\n]{0,20}?，不如说是/g, '与其说是……不如说是……'],
  ];
  for (const [re, name] of rbPairs) {
    const n = countNarrative(re);
    if (n > 0) roundabout.push(`“${name}”×${n}`);
  }
  if (roundabout.length) {
    push('soft', `迂回定义句式（先否定/绕弯再给结论）${roundabout.length} 类`, `零容忍：${roundabout.join('、')}——直接说重点，是什么就写什么，删掉否定和绕弯的半边`);
  }

  // ── 伪修饰/伪列举句式（有条件使用：可信理由成立时整章 ≤1） ────────
  // 可信理由必须来自故事世界（视角受限/情节需要/真实节点），不来自修辞冲动。
  // 「当X的时候」（≤1 次）：普通事件直接写，只有真正的节点才配时间框架
  const dangShi = countNarrative(/当[^。！？\n]{1,20}的时候/g);
  if (dangShi > 1) push('soft', `“当……的时候”框架出现 ${dangShi} 次`, '上限 1 次（留给真正的节点：退伍/离乡/接手那天）；普通事件直接写发生了什么');
  // 「不知是X还是Y」（≤1 次）：POV 真的无法分辨时可用，装纠结不可
  const buZhi = countNarrative(/(不知|不知道)是[^。！？\n]{2,20}还是/g);
  if (buZhi > 1) push('soft', `“不知是……还是……”出现 ${buZhi} 次`, '上限 1 次（留给 POV 真无法分辨：隔着毛玻璃/天太黑）；装纠结的直接写他实际做了什么');
  // 「或许A，或许B」（≤1 次）：真实推测且后文验证其一，否则写确定的
  const huoXu = countNarrative(/或许[^。！？\n]{2,20}[，,]或许/g);
  if (huoXu > 1) push('soft', `“或许……，或许……”出现 ${huoXu} 次`, '上限 1 次（留给后文会验证的真实推测）；回避式抒情删掉，写确定的那个');
  // 「像是A，又像是B」（≤1 次）：对象确实介于两者之间，否则选一个
  const xiangShi = countNarrative(/像是[^。！？\n]{2,20}[，,]又像是/g);
  if (xiangShi > 1) push('soft', `“像是……，又像是……”出现 ${xiangShi} 次`, '上限 1 次（对象真介于两者间才可用）；多数情况选准一个写');
  // 「一种难以X的Y」（零容忍）：万能量词+不可名状=什么都没写
  const nanYi = countNarrative(/一[种股抹]难以[^。！？\n]{0,10}(的感觉|的情绪|的滋味|的预感)/g);
  if (nanYi > 0) push('soft', `“一种难以……的感觉/情绪”出现 ${nanYi} 次`, '零容忍：不可名状=没写；写具体的身体反应或行为');
  // 「有一种X的感觉/情绪」（零容忍，prose-standards 禁模糊词）：与上一条同族但无「难以」限定——
  // 「有一种他要走了的感觉」照样什么都没写。只查叙述层（人物口头说感觉是自然语言）。
  const youYiZhong = countNarrative(/有一种[^。！？\n]{0,12}?(的感觉|的情绪)/g);
  if (youYiZhong > 0) push('soft', `“有一种……的感觉”出现 ${youYiZhong} 次`, '零容忍：模糊感觉=没写；写让他产生这感觉的具体事');
  // 「在这个……的世界里」（零容忍，prose-standards 万能套话）：AI 世界观开场框。
  // 「世界」不限定死——「在这个冰冷的都市里」同框架同病灶，一并抓。
  const inWorld = countNarrative(/在这个[^。！？\n]{0,16}的(世界|世界线|都市|时代|世界里)/g);
  if (inWorld > 0) push('soft', `“在这个……的世界里”出现 ${inWorld} 次`, '零容忍：世界观说明书腔；设定放进事件与对话，不搭空框架');
  // 万能举例框架（≤1 次）：正文不该有解释腔
  const liJu = EXAMPLE_CONN.reduce((s, w) => s + occurs(w), 0);
  if (liJu > 1) push('soft', `举例/解释框架（比如说/简而言之等）${liJu} 处`, '正文是叙事不是说明文；信息放进事件和对话里');

  const simileHits = [];
  const likeCount = countRe(/(?<![画肖雕影录照相])像/g);
  if (likeCount > 3) simileHits.push(`“像”×${likeCount}`);
  for (const w of ['仿佛', '如同', '宛如', '恰似']) {
    const n = occurs(w);
    if (n > 3) simileHits.push(`“${w}”×${n}`);
  }
  // 连续两句「……，像……」（prose-standards 比喻纪律）：比喻连发是模板节奏
  // 「好像」不算（更像“似乎”，且「，像」匹配不到它）——只抓逗号后直接接比喻引导的写法
  const simileSentences = narrative.split(/[。！？\n]+/).map((s) => /，(就)?像(是)?/.test(s));
  for (let i = 1; i < simileSentences.length; i += 1) {
    if (simileSentences[i] && simileSentences[i - 1]) {
      push('soft', '连续两句“……，像……”', '比喻连发是模板节奏；第二个比喻删掉或改成直写');
      break;
    }
  }
  if (simileHits.length) push('soft', '比喻引导词频次（同一引导词上限 3，一段最多一个比喻）', simileHits.join('、'));

  const aiConnHits = AI_CONN.filter((w) => occurs(w) > 0).map((w) => `“${w.replace(/，$/, '')}”`);
  if (aiConnHits.length) push('soft', 'AI 转折词/书面连接词', `${aiConnHits.join('、')}——删掉或换成口语衔接`);

  // ── 四、句子层：长度、开头、重复 ────────────────────────────────────
  const sentences = text.split(/[。！？\n]+/).map((s) => s.trim()).filter((s) => s.length > 1);

  // 句长过于均匀（段内长短句应有落差）
  if (sentences.length >= 8) {
    const lens = sentences.map((s) => s.length);
    const avg = lens.reduce((a, b) => a + b, 0) / lens.length;
    const variance = lens.reduce((s, l) => s + (l - avg) ** 2, 0) / lens.length;
    const cv = Math.sqrt(variance) / avg; // 变异系数
    const shortCount = lens.filter((l) => l <= 8).length;
    if (cv < 0.35 && shortCount < 3) {
      push('soft', `句长过于均匀（变异系数 ${cv.toFixed(2)}，短句仅 ${shortCount} 个）`, '长短句要有落差：加碎句/单句成段，偶尔来一个 40 字长句');
    }
  }

  // 连续同句式开头（连续 4+ 句以相同人称代词/人名开头）
  const starts = sentences.map((s) => (s.match(SUBJECT_START) || [])[1] || null);
  let run = 0;
  let maxRun = 0;
  let runStarter = null;
  for (let i = 0; i < starts.length; i += 1) {
    if (starts[i] && starts[i] === starts[i - 1]) run += 1;
    else run = starts[i] ? 1 : 0;
    if (run > maxRun) { maxRun = run; runStarter = starts[i]; }
  }
  if (maxRun >= 4) push('soft', `连续 ${maxRun} 句以“${runStarter || '同一人称'}”类开头`, '连续同句式是强 AI 特征：换主语、倒装、或用动作句切入');

  // 整句重复（同一句出现两次以上，多半是复制粘贴残留）
  const dupMap = new Map();
  for (const s of sentences) {
    const key = s.replace(/[“”‘’\s]/g, '');
    if (key.length < 12) continue;
    dupMap.set(key, (dupMap.get(key) || 0) + 1);
  }
  const dups = [...dupMap.entries()].filter(([, n]) => n > 1).sort((a, b) => b[1] - a[1]);
  if (dups.length) {
    const sample = dups.slice(0, 3).map(([s, n]) => `“${s.slice(0, 18)}…”×${n}`).join('、');
    push('soft', `整句重复 ${dups.length} 组`, `${sample}——确认是否复制粘贴残留；有意重复也要改写`);
  }

  // 段落开头雷同（连续 4 段以同两个字开头）
  const paraHeads = text.split(/\n+/)
    .map((p) => p.trim().replace(/^[“”‘’"'\s]+/, ''))
    .filter((p) => p.length >= 4)
    .map((p) => p.slice(0, 2));
  let pRun = 0;
  let pMaxRun = 0;
  let pStarter = null;
  for (let i = 0; i < paraHeads.length; i += 1) {
    if (paraHeads[i] === paraHeads[i - 1]) pRun += 1;
    else pRun = 1;
    if (pRun > pMaxRun) { pMaxRun = pRun; pStarter = paraHeads[i]; }
  }
  if (pMaxRun >= 4) push('soft', `连续 ${pMaxRun} 段以“${pStarter}”开头`, '段落开头要有变化：换视角人物、先给动作或环境、把短句单独成段');

  // ── 五、描写层：心理、对话标签、段尾 ────────────────────────────────
  const psych = countRe(/心中|心头|涌上|感到/g);
  if (psych > 5) push('soft', `心理/情绪标签类表达约 ${psych} 处`, '心理描写一章不超 5 处，改用行为外化');

  const quoteLines = Math.floor(countRe(/[“”]/g) / 2);
  const tagTotal = DIALOGUE_TAGS.reduce((s, w) => s + occurs(w), 0);
  if (tagTotal > Math.max(6, quoteLines * 0.5)) {
    push('soft', `对话标签约 ${tagTotal} 个（引号句约 ${quoteLines} 句）`, '半数以上对话挂“X道”类标签是 AI 特征：能删则删，用动作行代替');
  }

  const tailSummary = text.split(/\n+/).map((p) => p.trim()).filter(Boolean)
    .map((p) => (p.split(/(?<=[。！？…])/).pop() || '').trim())
    .filter((s) => TAIL_SUMMARY.test(s)).length;
  if (tailSummary > 2) push('soft', `${tailSummary} 个段落以总结/点题句收尾`, '段尾停在动作、台词或物证上，不要每段都收束');

  const tailText = text.slice(-80);
  const hookTpl = TAIL_TEMPLATES.filter((w) => tailText.includes(w));
  if (hookTpl.length) push('soft', `章末疑似模板收尾（${hookTpl.join('、')}）`, '钩子必须是具体事件或具体台词，不是气氛句');

  // ── 六、篇幅（默认标准 2000–4000 字） ───────────────────────────────
  // 只在正文已具章节体量（≥1000 字）时提示，避免片段检查刷屏
  if (chars >= 1000 && chars < CHAPTER_MIN) {
    push('soft', `本章 ${chars} 字，低于默认区间 ${CHAPTER_MIN}–${CHAPTER_MAX}`, '补足场景细节或增写一个推进情节的场面；用户另有要求则忽略');
  } else if (chars > CHAPTER_MAX) {
    push('soft', `本章 ${chars} 字，超出默认区间 ${CHAPTER_MIN}–${CHAPTER_MAX}`, '确认是否需要拆章；单章过长读者容易疲劳');
  }

  // ---------------- 汇总 ----------------
  const hardCount = issues.filter((i) => i[0] === 'hard').length;
  const softCount = issues.length - hardCount;
  const lines = [];
  if (!issues.length) lines.push('通过：未发现可量化的铁律违规（视角越界、说明书腔、情绪太平均等不可量化项仍需人工/模型自查）。');
  for (const [level, name, detail] of issues) {
    lines.push(`- ${level === 'hard' ? '【必须修】' : '【建议查】'}${name}——${detail}`);
  }
  return { hardCount, softCount, issues, report: lines.join('\n') };
}
