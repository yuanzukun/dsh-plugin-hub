# Changelog

## [1.0.46] - 2026-11-19

### Host Compatibility Matrix & Stability

- **DeepSeek Harness >=0.2.2-rc.1 support**: Upgraded host support matrix to DeepSeek Harness `>=0.2.2-rc.1 <0.3.0-0`, fully verified on official release candidates `0.2.2-rc.1` through `0.2.2-rc.5`.
- **Legacy migration notice**: Host environments running earlier `0.2.0`–`0.2.1` releases will be rejected by the version gate; users on those versions should stay on plugin version `1.0.45`.
- **Status & thinking progress display**: Improved the timeout handling for status progress feedback so that the final status banner duration aligns cleanly with the overall feedback budget, ensuring status notices remain visible without premature dismissal during long-running tasks.

## [1.0.45] - 2026-11-18

### Sidebar Tab Strip & Layout Stability

- **Sidebar single-strip layout fix (#73)**: Resolved an issue where multiple stacked tab bars could occasionally appear in the sidebar under duplicate plugin initialization or repeated view re-entry, which compressed and truncated the workspace and session list. The sidebar now strictly maintains a single unified tab strip across all view transitions, ensuring uninterrupted visibility for workspace sessions.

## [1.0.44] - 2026-11-17

### Feishu & Lark Thread Session Settings Experience

- **Standard dropdown picker & tooltip**: The "Thread session isolation" setting in Feishu and Lark account details has been upgraded to a standard select picker (with "Off" and "Isolated sessions" options), accompanied by a helpful tooltip explaining that threads maintain isolated conversation context when enabled and share group context when disabled.
- **Full multilingual localization**: Added localized labels and explanation tooltips for thread session isolation across all 8 supported languages (German, English, Spanish, French, Japanese, Portuguese, Russian, and Simplified Chinese).
- **Reliable account settings synchronization**: Refined account detail saving and configuration synchronization to ensure platform-specific options (such as thread session isolation and thinking process display) take effect reliably with smooth account reloading.

## [1.0.43] - 2026-11-17

### Feishu & Lark Thinking Process

- **Native thinking process bubbles**: Added support for displaying model reasoning (Thinking Process) in Feishu and Lark. Direct messages and main group chats use official native thinking process bubbles that can be expanded to review the complete chain of thought.
- **In-thread collapsible fallback**: In group message threads, reasoning automatically falls back to an expandable card panel (`collapsible_panel`), ensuring thought processes stay within the thread without leaking to the main lobby; smoothly falls back to cards if the tenant lacks native permissions.
- **Long reasoning & complex emoji display**: Improved presentation for long reasoning steps and composite emojis (such as diverse family and skin-tone emoji sequences), preventing split characters, garbled text, or corrupted symbols when displaying lengthy thought processes.
- **How to enable**: Navigate to Settings → IM Connect → Feishu/Lark account settings, and set "Thinking process display" to "Collapsed" (defaults to system preference).

## [1.0.42] - 2026-11-17

### Feishu Threads & Reply Experience

- **Thread session isolation**: Added a "Thread session isolation" toggle in Feishu and Lark account settings. When enabled, group message threads maintain isolated conversation sessions and context bounded by each thread; disabled by default (shares group context).
- **Accurate in-thread replies**: Improved reply routing for Feishu group messages and threads, ensuring responses stay strictly within the original thread and eliminating unintended fallbacks to the main lobby.
- **Interactive cards & buttons**: Added parsing support for Feishu interactive card messages; button interactions within a thread retain full thread context, ensuring approvals and option choices resolve in place.

### Delivery & Silent Protocol

- **Silent reply protocol**: Added support for `NO_REPLY` (and `<<<NO_REPLY>>>`) silent markers. When the assistant determines no user-visible response is needed, it finishes the turn silently without sending fallback notice cards.

## [1.0.41] - 2026-11-15

### UI & Layout Fixes

- The Task / Channel tab strip no longer scrolls out of view when the sidebar workspace list is scrolled: the sidebar shell now matches the scroll area exactly, so the tabs stay in place while the list scrolls beneath them.

## [1.0.40] - 2026-11-14

### Host Compatibility

- Verified against the full DSH `0.2.2` line (`0.2.2-rc.1` through `0.2.2-rc.3`), including the uploaded-file receipt and session model-selection contracts that generation changed.

## [1.0.39] - 2026-11-14

### Host Compatibility

- DSH host support now covers `0.2.2-rc.3`; the verified host list, development baseline and localized README badges follow the same version.

## [1.0.38] - 2026-11-13

### Settings UI Standardization

- Unified settings header card: wrapped the header in an elevated card container for seamless visual consistency across settings.
- Native button and icon styling: updated the issue feedback action to use the host's native pen icon and outline button primitive.

## [1.0.37] - 2026-11-12

### Compatibility & Dependencies

- Verified full compatibility with DeepSeek Harness `0.2.2-rc.2`, covering `0.2.0-rc.1` through `0.2.2-rc.2` and subsequent `0.2.x` pre-releases.
- Align development dependencies with official `0.2.2-rc.2` and Schemastery `3.19.0`, and update documentation compatibility lists and CI contract test coverage (`0.2.0-rc.1` through `0.2.1-rc.5`).

## [1.0.35] - 2026-11-10

### Telegram connection resilience, reaction reliability, and delivery safeguards

- Improve Telegram long-polling resilience: in constrained networking environments (such as NAT or containers), long-polling automatically recovers and resumes message dispatch after aborted or stalled connections, preventing silent bot hang-ups (#64, #68).
- Enhance status reactions and typing heartbeat stability: status reactions (thinking, finished, etc.) now retry on transient network errors or rate limits with atomic replacement, preventing missing delivery emojis; typing heartbeats feature expanded budgets and quota isolation, preventing premature cancellations over slow connections (#67).
- Safeguard final replies and unclaimed turns: protect historical requests from accidental matching during cold starts, and serialize final reply settlement to ensure long assistant responses are fully delivered before turn cleanup (#66).
- Documentation and settings streamlining: remove obsolete updater options now handled directly by the host plugin system, and align configuration section numbering across all localized README manuals.

## [1.0.34] - 2026-11-09

### Mobile sidebar interaction & channel session routing improvements

- Fix session opening from inserted channel tabs on mobile: clicking an IM channel session row in mobile drawers or external sidebar shells now properly restores and switches into the IM conversation, instead of falling back to a regular task session (#65).
- Fix duplicate icon display in mobile drawer navigation: when viewing sidebar shortcuts within mobile drawer sheets, the IM assistant entry cleanly displays its single icon with natural spacing, avoiding duplicate icon rendering.

## [1.0.33] - 2026-11-09

### Clean header navigation & documentation streamlining

- Two-tier navigation layout: split the README header links into two clean rows — the top row focuses on 8-language switching, while the second row clearly presents the Changelog and License.
- Prune internal handover links: remove internal development handover links from public documentation for a cleaner and more professional presentation.

## [1.0.32] - 2026-11-09

### Full multi-language README documentation & language navigation

- Dedicated documentation across 8 languages: provide comprehensive native README files for Japanese (`README.ja.md`), Spanish (`README.es.md`), French (`README.fr.md`), German (`README.de.md`), Russian (`README.ru.md`), and Portuguese (`README.pt.md`).
- Accurate localized detail display: plugin marketplace and details view now match the host's active locale with its dedicated native manual.
- Header language switcher: add an 8-language switcher navigation bar at the top of all README files for quick access.

## [1.0.31] - 2026-11-09

### Full 8-language i18n & streamlined plugin management

- Native 8-language support: provide full interface and manifest localization across Simplified Chinese, English, Japanese, Spanish, French, German, Russian, and Portuguese (Brazil), offering a seamless native experience across all supported host locales.
- Document fallback for global users: align plugin detail pages with host language fallbacks, ensuring non-Chinese environments display the comprehensive English documentation.
- Streamlined settings experience: remove obsolete update controls and buttons from the settings header, fully delegating plugin lifecycles and updates to the official DSH plugin manager.

## [1.0.30] - 2026-11-08

### Telegram collapsible thinking message & visual settings

- Collapsible thinking messages in Telegram: support sending the model's reasoning chain as a native collapsible quote block (`<blockquote expandable>`), allowing chat participants to tap and expand the thought process (#63).
- Visual dropdown setting: add a native "Show thinking process" dropdown (Off / Collapsed) in **Settings → IM Assistant → Telegram Account**, allowing quick per-account toggling or falling back to plugin defaults.
- Harmonized form layout: place the thinking process setting next to "Idle session rotation" in a balanced two-column grid with an inline privacy and display guidance tooltip.

## [1.0.29] - 2026-11-08

### Telegram group mention policy & visual configuration

- Telegram group mention policy: support choosing group chat trigger policy in account settings — "Mention or reply only (default)", "Always reply to all group messages", and "Free chat in specific groups only" (#62).
- Visual configuration for group whitelist: when choosing specific groups, enter group IDs directly in the visual settings panel. Draft inputs are retained when toggling between policies to prevent accidental input loss.
- Smart group ID parsing and link tolerance: support pasting Telegram Web group URLs directly (e.g. `web.telegram.org` and private links `t.me/c/...`), automatically normalize Unicode full-width minus signs, dashes, and topic suffixes, and provide real-time validation warnings for unrecognized entries.
- Group ID discovery guide: add clear instructions in README for discovering Telegram group IDs via browser address bar or query bots.

## [1.0.28] - 2026-11-06

### Telegram delivery reliability

- New Telegram messages and file uploads are now retried only when the platform explicitly rate-limits them. Network failures, timeouts and server errors are treated as unknown delivery instead of being resent, so a reply can no longer arrive twice.
- Edits to an existing reply keep retrying temporary errors on the same message. A reply whose delivery was unknown is no longer replaced by a second message when the placeholder becomes uneditable.
- Rate limits are tracked per chat: a busy group no longer delays replies in other conversations, and reconnecting clears stale cooldowns.
- Deleting a placeholder no longer disables rich formatting for every later message in that account.
- If a reply is finalized while the conversation has been muted, unbound or switched, an empty placeholder is removed instead of staying in the chat.
- Approval and question prompts are no longer retried as a whole while the platform is still asking to wait.

## [1.0.27] - 2026-11-04

### Compatibility & Dependencies

- Align with official DSH `0.2.2-rc.1` release; upgrade development dependencies to `0.2.2-rc.1`.
- Clean up obsolete alpha versions from the host compatibility matrix; support all `0.2.x` RC hosts (`0.2.0-rc.1` through `0.2.2-rc.1`).
- Update documentation badges and verified build ranges.


## 1.0.26 - 2026-11-04

- Telegram reply placeholders now display intermediate assistant progress: when handling requests on Telegram, the reply message dynamically shows a concise header for thinking status with cumulative character counts, as well as tool execution steps with parameters and duration (#57).
- Automatic status cleanup on answer delivery: the progress header is cleared immediately once real answer text begins streaming, ensuring finished replies only retain the final content.
- Clean placeholder disposal: turns ending without text output automatically remove temporary status-only messages, preventing leftover intermediate bubbles in the chat.
- Delivery safety and admission enforcement: status events strictly follow existing permission and offline delivery gates, and race conditions between placeholder resets and fresh replies are resolved to safeguard against answer loss.

## 1.0.25 - 2026-11-04

- Fix settings navigation icon compatibility across host generations: ensure the IM Assistant icon correctly appears in older DSH hosts without falling back to the default gear glyph, while cleanly using the native icon slot without duplicates on newer hosts.
- Graceful fallback for slot registration: ensure settings icon registration errors are isolated and automatically retried when switching views, preventing host settings dialog interruptions.

## 1.0.24 - 2026-11-03

- Integrate official native settings navigation icon slot: present dedicated instant messaging vector icon on newer hosts while maintaining graceful compatibility with older hosts to prevent dual icons.

## 1.0.23 - 2026-11-03

- Fix Telegram status emoji reactions not appearing on incoming messages (#55, PR #56): when sending messages to the Telegram bot, original messages now properly show status reactions (👀 processing / 🤔 waiting / 👍 finished / 👎 failed) as the assistant makes progress, resolving an issue where reaction updates were silently swallowed due to targeting event cursors instead of user message IDs.
- Skip reactions on interactive callbacks: button clicks and menu selections no longer attempt redundant status reactions, eliminating unnecessary background warning logs.

## 1.0.22 - 2026-11-03

- File delivery now sends only what the assistant explicitly delivers (#54): previously, any file the assistant touched (a memory note, a config edit, a log write) could be treated as this turn's output and pushed into the chat, which is especially awkward in group conversations. Only files the assistant declares as deliverables are returned now; ordinary file writes, code edits and state files no longer appear in chat.
- Upgrade note: if you relied on "the assistant writes a file and it arrives automatically", ask the assistant to deliver that file explicitly. `/export` for session logs is unaffected.
- New three-way entry location setting: the plugin details page switch became "Entry location" with Both / Sidebar only / Settings only, applied immediately without a reload. The default stays "Settings only", matching the previous behavior; accounts that had the sidebar entry enabled carry over to Both and keep their icon.
- In "Sidebar only" mode the duplicated **Settings → IM Assistant** tab is no longer shown and configuration happens in the sidebar panel; switch back to Both on the plugin details page to bring the settings tab back.
- Accessibility hardening: the new control now carries the identifiers and accessible names the host primitive requires, so screen readers announce the control and its three options.
- Documentation: both READMEs now describe the entry location states, its default value, and the file-delivery rule as implemented.

## 1.0.21 - 2026-10-30

- Add idle session auto-rotation: After a long pause in conversation, incoming messages can automatically start a fresh session, preventing previous conversation context from polluting new topics; previous sessions are preserved in history and can be resumed anytime via `/sessions` (PR #52).
- Per-account configuration: Added an "Idle session rotation" dropdown right below "Send mode" in each account's settings modal, supporting customizable thresholds (30 min, 1 hr, 2 hrs, 6 hrs, 12 hrs, 24 hrs, or Disabled); existing accounts default to Disabled to preserve original behavior.
- Running task safety protection: Sessions currently executing tasks are never interrupted or rotated, ensuring follow-up instructions for long tasks remain in the same context; slash commands such as `/sessions`, `/workspace`, and `/help` automatically refresh activity timing.
- Account settings UI polish: Removed redundant explanatory text beneath the segmented reply interval inputs, cleanly aligning the two-column settings form for a more compact layout.

## 1.0.20 - 2026-10-29

- Fix missing settings navigation icon in latest DSH Alpha Web host: Eliminate dynamic React rendering and `<use>` sprite references, resolving an issue where browser SVG Data URL security sandboxing produced a 100% transparent mask.
- Align settings nav icon implementation with ecosystem standards: Adopt self-contained vector masks generated directly from official host `ChatLinesOutlineArtwork` paths, paired with pure attribute markers and standard CSS `mask` pseudo-element rules for robust visual consistency across host versions and skins.

## 1.0.19 - 2026-10-27

- Add segmented replies: when set to "Send in segments" in an account's settings, the assistant splits one reply into several short messages at a line-exclusive separator (default `<<<MSG>>>`) and sends them sequentially; defaults to "Send as whole", preserving original behavior (#49).
- Send-gap interval control: each message, including the first, waits a random gap drawn from the minimum/maximum range configured for that account (0–60 seconds), rejecting saves where the maximum is lower than the minimum; the first segment uses stream finish, subsequent segments are sent sequentially, and any failure halts further delivery without resending the entire reply.
- Code block isolation and channel gating: separators inside fenced code blocks never split a reply, keeping code examples intact; currently enabled for QQ only (with support for account ID resolution), while unverified channels display no option, inject no system prompt, and never split.
- Segmented reply UI polish: refactor the control into a standard Select dropdown aligned side-by-side with Send mode; move long description copy into a native Tooltip hover icon (`ⓘ`) beside the label, eliminating awkward full-width notes and obsolete preset helper text.
- Add task tree session filter switch: introduce a `taskTreeSessions` switch in the plugin bundle configuration page (`plugins.bundle.config`), defaulting to off, which dynamically filters and hides messaging sessions from the official workspace task tree via `NativeTabRegistry.sessionFilters` while preserving them in the sidebar Channels tab.
- Unify IM session ID format: normalize newly created channel sessions to `dsh-im-session-<uuid>`, aligning with cross-plugin namespaces while preserving seamless backward compatibility for existing `im:` prefixed session records.

## 1.0.18 - 2026-10-26

- Distinguish `max-tokens` turn truncation from user cancellation: when a turn ends due to output token limits (`reason.kind === 'max-tokens'`), notify the user that the maximum output length was reached and prompt them to send "continue" to proceed, instead of incorrectly reporting that the turn was stopped (#48).
- Harmonize original message status reaction for truncated turns: map message progress status to `ended` (Done `✅`) rather than `cancelled` (`🚫`) when output tokens are exhausted without delivery failure, resolving visual contradictions between the status emoji and the turn completion notice.
- Preserve backward-compatible fallback: manual stops, aborted turns, and older host versions smoothly fall back to the standard cancellation copy.

## 1.0.17 - 2026-10-24

- Upgrade host admission policy: Declare `engines.dsh: ">=0.2.0-rc.1 <0.3.0-0"` to support the entire DeepSeek Harness `0.2.x` line (including `0.2.0-rc.1` onwards, future alphas, RCs, and stable releases) without requiring routine plugin version bumps.
- Decouple peerDependencies locks: Broaden all `@deepseek-ai/dsh-*` peer dependencies to the `0.2.x` generation range.
- Upgrade build-time development dependencies: Synchronize all `@deepseek-ai/dsh-*` devDependencies to latest `0.2.1-rc.3`.

## 1.0.15 - 2026-10-24

- Support DeepSeek Harness `0.2.1-rc.3` while retaining all existing supported versions.

## 1.0.14 - 2026-10-23

- Deliver outbound images on Feishu / Lark as real image messages: upload through `im/v1/images` with `image_type=message`, then send with `msg_type=image` so pictures render inline instead of arriving as file attachments (PR #47).
- Route by extension and size: only PNG/JPG/JPEG/WEBP/GIF/BMP/ICO/TIFF/HEIC up to 10 MB use image messages; larger files and non-images keep the existing file path.
- Fall back to a file message when the image upload or send is rejected by the platform so the picture is never lost; an explicit cancellation or timeout still aborts instead of silently re-sending.

## 1.0.13 - 2026-10-23

- Support per-account outbound proxy configuration for Telegram and Discord: choose between following host proxy (default), connecting directly, or configuring custom HTTP/HTTPS proxies.
- Route all Telegram and Discord outbound traffic through the configured proxy, including REST APIs, Telegram long polling, Discord Gateway WebSocket connections, file transfers, connection diagnostics, and inbound media/attachment downloads.
- Display proxy addresses as standard text fields with reflection and draft retention while keeping credentials securely stored in the local vault, and avoid unnecessary channel restarts when editing unrelated account settings.
- Improve Discord Gateway reconnection resilience: dynamically recreate closed dispatchers on reconnect, and automatically clear expired session cursors to fall back to a fresh Identify immediately when receiving Opcode 9 (`Invalid Session`).

## 1.0.11 - 2026-10-21

- Fix Feishu and Lark replies failing to fall back to plain text when a card is rejected with HTTP 400, such as a reply containing a local inline image. The fallback preserves the full text, image description, and path; it does not upload or render the local image.
- Add safe HTTP status and platform error-code diagnostics to distinguish a rejected card from a failed plain-text fallback. Rate limits still use the existing retry mechanism, and uncertain network outcomes are not automatically resent.

## 1.0.10 - 2026-10-20

- Telegram topics now receive the first generated session title automatically, while later title changes leave the topic name stable. `/rename` also updates the topic name; ordinary chats are unaffected.
- Add `/topicname` to check, lock, or unlock automatic naming for the current topic. The plugin configuration supports naming once (default), following title changes, or turning automatic naming off; topic locks survive restarts.
- Preserve detected manual topic names and avoid duplicate renames when titles arrive together or a naming request is still in progress. For private topics, use `/topicname off` to protect a manually chosen name.
- Fix `/export` failing to generate and send a session ZIP on supported DSH `0.2.1` RC hosts.

## 1.0.9 - 2026-10-20

- The Channels tab now adopts the host's native tree browser: sessions default to By channel grouping with platform brand icons on group headers and rows, supporting official search, sorting, and archive filtering.
- Improved channel shortcuts: single-channel workspaces show their platform brand icon instead of the folder icon, channel group menus offer a direct shortcut to Channel settings, and the header add button now opens IM settings.
- Seamless sidebar tab coordination: Tasks, Channels, and Scheduled tabs match the host segmented tab styling with adaptive padding that prevents label wrapping. Tab selection is shared and preserved alongside the automation plugin across reloads and host changes.
- Integrated channel and task sessions: channel sessions now appear in the official task tree and open without unexpectedly switching the active tab; newly created channel sessions display immediately without requiring a page reload.
- Fix the Add channel button failing to open IM settings when the sidebar only provides the Settings trigger within the official account menu.
- UI glyphs now align with the host icon system to ensure visual consistency across themes.

## 1.0.8 - 2026-10-19

- Let the account settings page fill the host content column by removing the 1080px cap.
- Only decorate settings nav buttons that render the host `svg` as a direct child, so wrapped icons keep the host layout.

## 1.0.7 - 2026-10-19

- Fix the Add account / Account settings dialog not scrolling when its content is taller than the window: once the dialog is capped to the viewport, the content area scrolls normally with the wheel or a trackpad, keeping the QR code and the Cancel / Confirm buttons reachable (Issue #40).

## 1.0.6 - 2026-10-19

- Fix the "IM Assistant" icon in Settings disappearing when a third-party skin is enabled; the icon now follows the host theme and layout.
- Improve the Quick setup / Manual setup switch in the bind dialog: screen readers now identify both setup panels correctly, channels with only one setup method no longer present a misleading tab control, and the selection indicator aligns with the labels.

## 1.0.5 - 2026-10-19

- Fix native sidebar tab registry discovery: strictly inspect the current occupant component instead of relying on stale entry references.
- Clean up own tab contributions immediately when the foreign sidebar host unregisters its native tab registry, and re-attach cleanly upon sidebar change notifications.

## 1.0.4 - 2026-10-18

- Fix file delivery error handling: do not skip `not-regular-file` (e.g. directory paths), ensuring non-regular files report actionable delivery errors while missing deleted files remain silently skipped.

## 1.0.3 - 2026-10-18

- New per-account **Send mode** setting with two options, matching Chat's own send modes: **Queue** (default, current behavior) and **Steer**. With Steer, an ordinary chat message is handed to the running task as additional instructions at its next step (the same mechanism as `/steer`) instead of waiting for the current turn to finish; images and files follow the same mode through Chat's prompt admission. On Hosts whose Agent does not expose step-boundary injection, Steer gracefully falls back to queueing so no message is lost. Existing accounts keep queueing until the setting is changed.
- Adapt Telegram supergroup forum topics (Topics / Forum): messages and button callbacks in different topics are now isolated into independent sessions, and outbound replies and streams strictly include `message_thread_id` to stay within the original topic. Non-forum supergroups and private chats are unaffected; for forum supergroups, existing sessions previously registered at group level will not be migrated automatically into individual topics. Messages in each topic will create a new session, while old sessions remain accessible directly in web Chat.
- QQ rich media file upload: infer `file_type` (image/video/audio/file) from file signatures and extension fallbacks; silently skip files that were generated and deleted within the same turn without failing message delivery.
- Align sidebar and settings rail tabs with host standard `HostSegmentedTabs`.

## 1.0.2 - 2026-10-18

- Remove legacy custom `Alert` component and align pending access approval banner (`ima-pending`) with Skills Manager feedback container patterns.
- Fix issue where pending IM access request rows and \"Approve / Deny\" buttons were omitted due to unhandled `description` prop in custom Alert (Issue #35).
- Add warning state theme colors and responsive vertical list layout for pending items.

## 1.0.1 - 2026-10-18

- Upgrade Feishu normal reply cards to Interactive Card Schema 2.0 (`schema: "2.0"` + `body.elements`), fixing Markdown table rendering issues on modern Feishu clients. Interactive question choices and status patch updates retain Schema 1.0 structure for compatibility with existing card instances.
- Align select dropdown menu width dynamically with the trigger button across responsive viewport resize events.
- Align modal confirmation dialogs for destructive actions (e.g., account removal) strictly with host danger button specifications (`variant="outline"`, red border and text, red hover background).
- Revert modal bottom inspector action buttons to host default medium size (`md`, 36px height) to match Skills Manager layout standards.
- Add CSS rule for `.ima-tag-info` to ensure info-state tags (such as official model checkpoint badges) render with the correct theme primary color instead of neutral gray.
- Feishu and Lark can now be bound with a self-built bot's App ID / App Secret in addition to the existing QR flow. The App Secret is stored in the credential vault instead of the channel config file.

## 1.0.0 - 2026-10-17

- Supported hosts now match the skills plugin: DeepSeek Harness `0.2.0-rc.1`, `0.2.0-rc.2`, `0.2.1-rc.1`, and `0.2.1-rc.2`. Hosts `0.2.1-alpha.1` through `0.2.1-alpha.5`, and anything before `0.2.0`, are refused by the version gate, so the plugin will not run; existing IM settings in the profile are not deleted. If you still use a `0.1.x` host, install plugin `0.1.78` instead of `@latest`. This is not “every release after `0.2.0`”: stable `0.2.0` and any prerelease outside this list are refused too.
- Widen channel binding and account settings dialogs to `720px`, aligning with Automation to prevent cramped form layouts.
- Add footer action to workspace select dropdown with a divider. Adding workspaces now strictly uses the host native system directory picker without manual path inputs, automatically creating and selecting the picked workspace. Hosts without native picker capabilities show "This Host cannot create workspaces" (upgrade to one of the supported host releases listed in Requirements, or add via the host sidebar).
- Top action buttons ("GitHub", "Issues", "Check for updates") now strictly match Skills Manager's host outline small button styles and icon layouts, removing custom size and color overrides from update button.

## 0.1.78 - 2026-10-17

- Support DSH `0.2.1-alpha.4` and `0.2.1-alpha.5` while retaining all existing supported versions; pin development `@deepseek-ai/dsh*` dependencies to host `0.2.1-alpha.5`. Cordis stays at `4.0.5-alpha.2`.
- No production plugin API breaks. Declared host packages have no removed or renamed exports from `0.2.1-alpha.3` to `0.2.1-alpha.5`. Peer still includes `0.1.2-rc.1` and the `0.1.5` release candidates, so the older icon, slot, session-open, and file-read paths stay.

## 0.1.77 - 2026-10-15

- Fix duplicated question option lists in native-button prompts for WeCom, Feishu/Lark, DingTalk, Telegram, Discord, and Slack. Keep option descriptions, multi-select checkmarks and submission buttons, ordinary menus, approvals, and text fallback intact.
- Place the multi-select submit action in the numbered option list, before the reply instruction, so number-only buttons still match the list.
- WeChat suppresses transition text in assistant messages that also contain tool calls, reducing reply-window consumption during long tasks. Text-only replies, approvals, questions, and result files keep their existing delivery behavior.
- Suppressed text is not counted as a successful delivery. A final reply explicitly rejected by the platform remains eligible for redelivery after a new message in the original chat; text recovered from history follows the same filtering rule.
- This does not remove WeChat server-side sending limits. Long reply fragments and necessary interactions may still exhaust the window; ambiguous failures and partial deliveries retain the conservative manual-retry policy.
- Empty assistant content no longer interrupts delivery or history recovery.

## 0.1.76 - 2026-10-15

- Support DSH `0.2.1-alpha.3` while retaining all existing supported versions; pin development `@deepseek-ai/dsh*` dependencies to host `0.2.1-alpha.3` and Cordis to `4.0.5-alpha.2`.
- No production plugin API breaks for this release (peer / documentation / development dependency alignment only).

## 0.1.75 - 2026-10-14

- Adjust settings navigation section order to ensure stable placement and avoid conflicts with other plugins.

## 0.1.74 - 2026-10-12

- Directly quoted text from official QQ bot direct and group messages is now included in the model context alongside the current message. Only the immediate quote is retained, without expanding older quote history. Quote-only messages are accepted and carry an explicit quote label.
- Quotes without text retain a placeholder, with attachment placeholders taking precedence. Repeated anonymous nested elements without direct text or attachments retain one placeholder and a folded-count notice. Actual text, author information, and attachments are not deduplicated by content.
- QQ incoming message text and quoted text now normalize both CRLF and lone CR line endings to LF, preserving multiline text, code, and legitimate mentions in quoted content.
- Oversized quotes include an explicit truncation notice while retaining complete outer quote labels and UTF-16 pairs. Unknown, incomplete, or multiple-top-level-message quote content is preserved verbatim within the same size limit; truncation does not guarantee complete brackets or code syntax inside that content.

## 0.1.73 - 2026-10-12

- Support DSH `0.2.1-alpha.2` while retaining all existing supported versions.

[简体中文](CHANGELOG.zh-CN.md)

Recent published versions are listed below. Git tags and GitHub Releases now mirror these entries; historical sections retain links to their original release commits.

## 0.1.72 - 2026-10-11

- WeChat replies no longer go missing when the platform briefly refuses a send (`ret=-2 prepare failed`). The reply is retried for up to about 30 seconds, and if it still cannot go out it is queued for automatic redelivery instead of being dropped.
- Telegram, Slack, Discord, Feishu, DingTalk and QQ get the same protection when the platform rate-limits a reply. Only failures where the platform clearly did not accept the message are retried, so a timeout or a dropped connection never produces a duplicate message.
- A long reply that was already partly delivered is not resent in full, even if a later part is refused.
- Restart DSH and refresh the page after upgrading.

## 0.1.71 - 2026-10-09

- Saving an account now requires a workspace that is already registered in DSH. If there are none, QR setup and manual confirm stay disabled until you add one.
- A folder that is not in the workspace list, including the Desktop profile data directory, can no longer be saved as the account workspace. That was dropping incoming messages when the session could not be attached.
- If an existing account is still bound to that default folder, open its settings after upgrading, choose a real project workspace, and save.
- Restart DSH and refresh the page after upgrading.

## 0.1.69 - 2026-10-08

- New Slack channel. Add a Bot Token and an App Token on the Slack card in **Settings → IM Assistant**; it connects over Socket Mode and needs no public URL.
- Slack DMs still use the allowlist. Mentions in public and private channels answer inside that message's thread. The 512 most recently joined threads are saved per account, so follow-ups still need no mention after a restart. Switching the bot identity does not inherit the old records. Multi-person DMs are not supported.
- Outgoing text is converted to Slack mrkdwn: headings become bold whole lines, Markdown tables go vertical, `**bold**` becomes `*bold*`, links become `<url|label>`, and code fences stay untouched. Long replies split with structure awareness.
- Native button choices, emoji status reactions, image and file transfer, `/stop`, approvals, and interactive questions are supported; **Diagnose connection** verifies bot identity.
- Existing channels are unaffected: Slack uses its own channel id `slack`, and its sessions stay separate from web tasks.
- Slack and Discord icons now use the official marks instead of a gray dot.
- Opening IM Assistant no longer expands WeChat by default. Every channel starts collapsed.
- Slack accepts `!help`, `!m`, and fullwidth `／help` the same way Discord does. An unknown `!hello` stays an ordinary message. A slash command that opens a channel thread counts as participation, so a later reply in that thread needs no new mention.
- Slack choice cards keep the full text and the closed status. If delivery is unknown, the plugin does not send a second copy.
- Restart DSH and refresh the page after upgrading.

## 0.1.68 - 2026-10-08

- The channel sidebar keeps its layout when another plugin reloads. Its runtime styles now belong to this plugin.
- Restart DSH and refresh the page after upgrading.

## 0.1.67 - 2026-10-08

- Creating a session from the channels tab returns the sidebar to Tasks, including the host New session button. Channels cannot hold a newly created task, and a refresh no longer leaves that task hidden on Channels (#23).
- Restart DSH and refresh the page after upgrading.

## 0.1.66 - 2026-10-07

- Each connected account can have a local name remark. Click the account name on the settings row, or edit it in account settings. The remark is display-only. Leaving it blank restores the original automatic number instead of renumbering by the current account count. Remarks longer than 40 characters or containing line breaks are rejected.
- Restart DSH and refresh the page after upgrading.

## 0.1.65 - 2026-10-07

- Official Desktop can update this plugin in place. It no longer targets the web profile by mistake.
- A new version is marked with a warning color. Version numbers keep their normal color.
- After updating, fully quit and reopen DSH Desktop.

## 0.1.64 - 2026-10-06

- The installed-plugin list shows “IM Connect” and a localized description instead of the package name. Titles and descriptions come from `meta.title` and `meta.description` in `locale/zh.json` and `locale/en.json`.

## 0.1.63 - 2026-10-04

- Switching through `/new`, `/clear`, `/session`, `/workspace`, `/preset`, or `/fork` stops previous sessions from pushing output to the same chat. Detached registrations persist across restarts without hiding web history, and session handles remain managed until channel teardown.
- Added `/unbind [number|ID|all]`, `/mute number-or-ID`, and `/unmute number-or-ID`. Invalid numbers point to `/unbind`; explicitly selecting a session restores its output. Mute pauses assistant text and files while approvals, questions, and task status notices remain available.
- Reply streams track their owning session. Switching or muting the owner discards stale queued updates; clearing other historical registrations does not interrupt the current reply. Session-event routing no longer sorts the full history on each streamed chunk.
- Channel panels share polling and group sessions once per refresh, avoiding overlapping polling from multiple panels.
- Added Feishu message-to-reply end-to-end coverage for session switching, mute/unmute, and restart recovery. CI now includes real Host export contracts alongside session, command, image, file, and authentication contracts.
- Existing registrations from an older installation are cleared on the next session switch; `/unbind all` can clear old registrations immediately while keeping the current session. Already sent partial cards may remain visible. Restart DSH and refresh the page after upgrading.

## 0.1.62 - 2026-10-02

- Long replies no longer exceed a channel's length limit after the (n/m) marker is added. Tables and code fences still use the full limit and keep their structure; only prose chunks reserve room for the marker.
- Telegram and Feishu no longer send a second plain-text copy when a rich or card send times out or the connection drops. A plain-text fallback happens only when the platform explicitly rejects the rich message.
- Discord keeps code fences intact when a long reply is split, including the final streamed message. A chunk that already fits is not split again, so part numbers are not nested. Tables that grow past 2000 characters after vertical formatting are still split.
- DSH 0.2.0-rc.2, 0.2.0-rc.1, 0.1.7-rc.2, 0.1.7-rc.1, 0.1.2-rc.1, and the 0.1.5 release candidates remain supported.
- Restart DSH and refresh the page after upgrading.

## 0.1.61 - 2026-10-01

- Tool approvals now wait at most 5 minutes on every channel. On expiry the action is canceled, not treated as a user denial, and the original chat is told it did not run. `/stop` or a disconnect still cancels immediately and does not send the timeout notice.
- While an approval is waiting, other text is not submitted as the next turn; the chat is asked to reply allow or reject. Images and files are still submitted as content and are not treated as the approval reply. Questions have no such timeout.
- DSH 0.2.0-rc.2, 0.2.0-rc.1, 0.1.7-rc.2, 0.1.7-rc.1, 0.1.2-rc.1, and the 0.1.5 release candidates remain supported.
- Restart DSH and refresh the page after upgrading.

## 0.1.60 - 2026-10-01

- Added Discord. Connect with a Developer Portal Bot Token. Direct messages are answered in place; the first mention in a guild text or announcement channel continues in a thread. Text commands, buttons, files, and streamed replies follow the existing channels.
- Enable the Message Content Intent and grant Send Messages, Create Public Threads, Send Messages in Threads, Read Message History, and Attach Files. Do not configure an Interactions Endpoint URL.
- Discord keeps retrying on recoverable gateway closes (4000, 1006, and similar) instead of stopping the account; only an invalid token or missing intents stop it.
- Discord has no Markdown tables, so pipe tables become a vertical block per row (first two columns as a bold title, remaining columns as `header: value`), which avoids the mobile code-block border and horizontal overflow. Headings and other text are sent verbatim; tables inside code fences stay as they are.
- Long replies now split with structure awareness: table chunks repeat the header and separator, code fences are re-closed per chunk, and the `(n/m)` marker only prefixes prose chunks instead of cutting tables or code blocks in half.
- Telegram replies use Rich Messages with Markdown so headings, bold text, and tables render; the channel falls back to plain text when that method is unavailable and remembers the result instead of retrying.
- Feishu normal replies use card Markdown so headings and tables render, split so no card holds more than five tables, with a plain-text fallback.
- QQ replies keep Markdown tables instead of downgrading them to lists; the engine splitter repeats the header across chunks, and plain text is only used when the platform rejects markdown.
- `/help` reorganised into getting around / sessions and workspaces / models and reasoning / tasks and delivery, with 24 commands and no duplicates: one entry per feature (/sessions lists, /session continues directly), the repeated model-switch line removed, and the numbering hint rewritten as the channel-neutral "tap a button or reply with the number". `/export` is now documented and `/delivery` is grouped. Group titles are bold so they are easier to scan on a phone, and the extension section no longer repeats commands already listed in the base help nor the command name inside its descriptions.
- Telegram rich Markdown now hardens plain prose line breaks so command lists are no longer joined into one run-on line; lists, headings, quotes, tables, and code fences are left untouched. Telegram parses a single newline as a CommonMark soft break.
- Tool approvals no longer fall back to the web because of DM admission, the allowlist, or an incomplete prompt. Approvals stay in the chat that started the task; groups accept only the task initiator, and a failed prompt is treated as a denial instead of being silently allowed.
- Channel copy and command errors now follow the host language everywhere: the DingTalk AI Card placeholder and empty-reply fallback, and the engine errors shown through "command failed" all use the Chinese/English table, and Discord slash-command descriptions carry zh-CN and en-US localizations.
- Continue to support DSH 0.2.0-rc.2, 0.2.0-rc.1, 0.1.7-rc.2, 0.1.7-rc.1, 0.1.2-rc.1, and the 0.1.5 release candidates.
- Restart DSH and refresh the page after upgrading.

## 0.1.59 - 2026-09-30

- QQ replies now show headings, bold text, and links instead of the raw markers. Tables are sent as lists.
- If a WeChat question or approval prompt fails to send, it is sent once more and the answer is still collected in WeChat.
- Continue to support DSH 0.2.0-rc.2, 0.2.0-rc.1, 0.1.7-rc.2, 0.1.7-rc.1, 0.1.2-rc.1, and the 0.1.5 release candidates.
- Restart DSH and refresh the page after upgrading.

## 0.1.58 - 2026-09-30

- Support DSH 0.2.0-rc.2, and keep 0.2.0-rc.1, 0.1.7-rc.2, 0.1.7-rc.1, 0.1.2-rc.1, and the 0.1.5 release candidates working.
- Restart DSH and refresh the page after upgrading.

## 0.1.57 - 2026-09-28

- Support DSH 0.2.0-rc.1, and keep 0.1.7-rc.2, 0.1.7-rc.1, 0.1.2-rc.1, and the 0.1.5 release candidates working.
- Restart DSH and refresh the page after upgrading.

## 0.1.56 - 2026-09-28

- Bot shell text follows the global language saved in Settings. Commands, menus, approvals, questions, image failure notices, the WeCom thinking placeholder, and the channel status in `/status` use English when English is saved.
- If a language has never been saved, the bot stays in Chinese. A page that only looks English because of the browser does not change the bot.
- Assistant replies are written by the model and are not translated by this plugin.
- Still supports DSH 0.1.7-rc.2, 0.1.7-rc.1, 0.1.2-rc.1, and the 0.1.5 release candidates.
- Restart DSH and refresh the page after upgrading.

## 0.1.55 - 2026-09-25

- Support DSH 0.1.7-rc.2, and keep 0.1.7-rc.1, 0.1.2-rc.1, and the 0.1.5 release candidates working.
- Fix the left session list going blank after installing the plugin. On hosts without the 0.1.7 sidebar interfaces (0.1.2, 0.1.5), the plugin no longer asks the host for sidebar slots it does not declare, and if the plugin's own sidebar layer fails it falls back to the host's native session list instead of showing nothing.
- Restart DSH and refresh the page after upgrading.

## 0.1.54 - 2026-09-24

- Support DSH 0.1.7-rc.1, and keep 0.1.2-rc.1 and the 0.1.5 release candidates. The 0.1.6 and 0.1.7 preview builds are no longer supported; move to 0.1.7-rc.1.
- The older 0.1.2 and 0.1.5 builds stay available because they are published release candidates.
- On 0.1.2 and 0.1.5, grouping the channel list by workspace tree can show a single ungrouped list, and showing only archived sessions can be empty.
- Restart DSH and refresh the page after upgrading.

## 0.1.53 - 2026-09-23

- Support DSH 0.1.7, and keep working on 0.1.2, 0.1.5, and 0.1.6.
- The channel list and account settings follow the current host interface.
- Channel groups keep their channel icons. A running session shows that it is in progress.
- The channel list can group by workspace, filter archived sessions, and rename on double-click. A long title scrolls when you hover it. Pin and manual sorting are not available.
- Archiving a running session asks you to stop it first.
- A failed tool run is no longer sent out to the channel.
- Command replies follow the interface language.
- Restart DSH and refresh the page after upgrading.

## 0.1.51 - 2026-09-18

- Add support for DSH 0.1.6-alpha.2 while retaining compatibility with 0.1.2-rc.1, 0.1.5-rc.1, 0.1.5-rc.2 and 0.1.6-alpha.1.
- Open channel sessions through official workspace navigation on hosts that no longer expose `sessions.open`.
- Folder menus can open that channel’s settings.
- Align the channel session list with official WorkspaceBrowser chrome. Folder icons stay channel logos; hover still swaps to the official chevron.
- Open listed sessions with the official workspace id and read session state at render time, so task-tree clicks still work on alpha.2.
- Restart DSH and refresh the page after upgrading.

## 0.1.50 - 2026-09-16

- Add support for DSH 0.1.6-alpha.1 while retaining compatibility with 0.1.2-rc.1, 0.1.5-rc.1 and 0.1.5-rc.2.
- Prefer official inspect for session history. An empty persisted prefix no longer overwrites existing permissions, and file delivery still uses the live turn log.
- Restart DSH and refresh the page after upgrading.

## 0.1.49 - 2026-09-14

- Fix an older sidebar tab registration removing its replacement during cleanup, preserving shared tabs when plugins hand over ownership.

## 0.1.48 - 2026-09-14

- Fix the Channels sidebar entry disappearing when used with the archive and automation plugins.

## 0.1.47 - 2026-09-13

- Diagnose account connections through platform APIs or an existing connection heartbeat. Results distinguish passed, failed and unverified checks, with specific guidance for credentials, local state, network failures and Telegram Webhook conflicts; no test messages are sent.
- Correct online status and receiving indicators. Unknown states no longer appear healthy, and older backends prompt a restart instead of presenting an unavailable receiving setting as editable.
- Restart DSH and refresh the page after upgrading. Passing diagnostics does not verify all message delivery permissions.

## 0.1.46 - 2026-09-12

- Fix WeCom menus showing duplicate options, long questions being truncated in cards, and extra completion notes plus numbered cards after a successful reply.
- Fix WeCom replies going missing or being sent twice after a button tap. Only expired callbacks are resent proactively; unknown errors no longer trigger a full automatic retry.
- Fix DingTalk incremental reply completion order, Feishu business errors being treated as success, and Telegram long replies being truncated.
- Restore native sidebar channel tabs that previously showed only Tasks and Scheduled.
- Restart DSH and refresh the page after upgrading.

## 0.1.45 - 2026-09-11

- Fix stale channel entries remaining after archived sessions are deleted, which made those sessions impossible to open or archive. The plugin now removes its channel index after the Host confirms deletion and retains it when storage state cannot be verified.
- Restart DSH and refresh the page after upgrading.

## 0.1.44 - 2026-09-11

- Receive assistant-generated files across channels and export the current session with `/export`. Incoming files follow Chat admission rules, with fewer duplicate file deliveries.
- Added `/menu`, Agent preset and reasoning choices, plus cards for commands, approvals and questions on supported channels. Related actions and task status are clearer; `/help` now uses plain text everywhere.
- Recover text results after disconnects or restarts with `/delivery` and manual retries, without rerunning tasks. Results with unknown delivery status are not resent automatically; manual retries may duplicate a message. Files remain available in the original session.
- Fixed unresponsive DingTalk card buttons, missing incremental replies on newer DSH versions, and loss of existing reply text when stopping. Improved `/stop` status messages after restarts.
- Continues to support DSH 0.1.2-rc.1, 0.1.5-rc.1 and 0.1.5-rc.2. Restart DSH and refresh the page after upgrading.

## 0.1.43 - 2026-09-11

- Add support for DSH 0.1.5-rc.2 while retaining compatibility with 0.1.2-rc.1 and 0.1.5-rc.1.
- Restart DSH and refresh the page after upgrading.

## 0.1.42 - 2026-09-10

- Support DSH 0.1.2-rc.1 and 0.1.5-rc.1. Fix session creation, workspace switching, and session restoration on the newer DSH version.
- Fix IM tool approvals failing to show operation details and requiring users to approve on the web.
- Improve history recovery: an unrecognized record no longer blocks other sessions from being restored, and existing history entries are preserved when their logs cannot be reliably checked.
- Fix account setup and settings dialogs appearing behind the chat area on narrow screens.
- Restart DSH and refresh the page after upgrading.


## 0.1.41 - 2026-09-10

- Add independent command switches for private and group chats on each account. Normal chat remains available when commands are disabled, and existing private-chat admission rules still apply.
- Manage sessions, workspaces, models, and reasoning levels from IM. View history, rename or fork sessions, stop tasks, add instructions, and manage queued messages. `/help` also lists the Chat extension commands currently available.
- Improve account settings with full-width channel cards, settings dialogs, and receive-message switches on account rows. Add Agent preset selection and fix the unresponsive Add Workspace action.
- Fix previous sessions failing to open on the web after `/new`, and missing replies after switching workspaces. New sessions use the selected workspace and account settings while preserving previous sessions.
- Make command replies clearer with results, current settings, and suggested next actions. Lists identify archived sessions and sessions connected to another chat. Support Chinese and English using the language saved in web settings.
- Preserve line breaks in DingTalk command replies. If AI Card creation fails, replies fall back to plain text with line breaks intact.
- Restart DSH and refresh the page after upgrading.

## 0.1.40 - 2026-09-10

- Fix #12: previous sessions stay in the channel list after `/new`, `/clear`, or a workspace change. Open, rename, or archive them without changing the new session used by your current chat.
- After upgrading, automatically restore historical sessions whose local chat logs are still available and whose channel can be identified, while preserving their archive status.
- Session names follow DSH title updates without overwriting manually set names. New sessions use the first message or attachment name by default.
- Fix session entries disappearing when archiving or deletion fails, and deleted sessions remaining in the list.
- Restart DSH and refresh the page after upgrading.

## 0.1.39 - 2026-09-09

- Remove the unused legacy composer component while preserving the current host composer entry.

- Unified settings headings, descriptions, and action layouts; maintenance controls no longer squeeze titles or versions. The layout adapts to native DSH settings without Codex UI.
- Keep account lists and details side by side in equal-width columns with compact channel rows; fix box sizing that caused horizontal overflow in the native settings dialog.

## 0.1.38 - 2026-09-08

- Fix #11: move the settings API to `/api/dsh-im-connect`, following the REST prefix used by other DSH plugins. The route uses DSH’s public `connection.requestRejection`, preserving trusted-host, Origin, and authority-bound browser-cookie checks behind reverse proxies. Local requests also require login; unavailable authentication fails closed with retry/upgrade guidance.
- Keep account, model, pairing, and session routes unchanged; send same-origin credentials explicitly, disable management caching, and cover real Host authentication plus frontend transport regressions.

- Add native inbound images for WeChat, WeCom, DingTalk, Feishu, Lark, QQ, and Telegram through DSH Chat's current-session model checks and durable attachment admission; prevent account defaults from overriding Chat's selected model.
- Route QQ image downloads through the DNS-validated downloader while preserving whole-message budgets, cancellation, and deadlines. Allow administrators to configure additional exact image hosts per account instead of patching region-specific COS/OSS origins.
- Reuse DingTalk access tokens per account, coalesce concurrent token requests, and invalidate the cache on expiry, stop, or restart.
- Classify WeChat image failures and retry transient network/server failures within a bounded budget. Never downgrade failed image captions to text commands or retry/deliver stale input after stop.
- Extend image security, ordering, lifecycle, real host-admission, and durable-storage regression tests. Track live channel and vision-model verification separately from transport fixtures.

## 0.1.37 - 2026-09-07

- Withdraw the unfinished proactive delivery feature, including account delivery settings, `im-send`, Agent tools, and delivery HTTP endpoints. Existing IM replies and plugin update controls are retained.

## 0.1.36 - 2026-09-07

- Aligned the DSH webserver peer and development dependency at `0.1.2-rc.1` so CI can resolve the package dependency graph.

## 0.1.35 - 2026-09-07

- Added independent in-product update checks with automatic updates when a verified DSH update service is available and a profile-specific manual fallback otherwise.
- Removed the update-button dependency on `react-dom/client` so the client can load on Hosts that do not register that module id.

## 0.1.34 — 2026-09-03

- Added compatibility with DeepSeek Harness `0.1.2-rc.1`.

## 0.1.33 — 2026-09-03

- Added GitHub and Issues links beside the IM Assistant settings title, matching the Archive Manager's icon size, button sizing, interaction states, and responsive layout.
- Declared the DSH client and Agent modules used by the plugin as peer dependencies for `>=0.1.0-rc.5 <0.2.0`, and added the published DSH development modules at `0.1.2-alpha.5` alongside the Cordis and Schemastery baseline update.

## 0.1.32 — 2026-09-02

- Rebuilt an account's IM session mapping after a real workspace change, preserving Host history while ensuring the next inbound message creates a session in the new workspace. Equivalent Windows paths do not reset sessions, while Linux path case changes do.
- Made account updates and QR pairing wait for persistence and channel reload to finish, so a reported successful bind is fully saved. Saving now resists cancellation controls and captures Escape before the Host settings page can close.

Published package: [`@michengai/dsh-im-connect@0.1.32`](https://www.npmjs.com/package/@michengai/dsh-im-connect/v/0.1.32).

## 0.1.30 — 2026-09-01

- Fixed account model switches so models without reasoning-effort support no longer inherit a stale Low, Medium, or High value, and automatically clean invalid values persisted by earlier versions.

Published package: [`@michengai/dsh-im-connect@0.1.30`](https://www.npmjs.com/package/@michengai/dsh-im-connect/v/0.1.30).

## 0.1.29 — 2026-09-01

- Completed Host-language localization across the multi-account settings flow, including account setup, selectors, status, actions, empty states, confirmations, and actionable server errors.
- Localized automatically generated account names without migrating stored account data, while preserving custom account names unchanged.
- Fixed narrow account inspectors so concise English connection actions remain aligned on one row, with whole-button wrapping as a safe fallback.

Published package: [`@michengai/dsh-im-connect@0.1.29`](https://www.npmjs.com/package/@michengai/dsh-im-connect/v/0.1.29).

## 0.1.28 — 2026-09-01

- Added multiple isolated accounts for WeChat, WeCom, QQ, DingTalk, Feishu, Lark, and Telegram, with independent workspace, model, permission, private-access, credential, allowlist, and session state.
- Redesigned IM Assistant settings around channel-local account creation, persistent account selection, account-specific configuration, clear empty states, on-demand QR pairing, and responsive desktop layouts.
- Hardened public private chats so unapproved users cannot approve local tool calls, made legacy approval routes fail closed when an account is ambiguous, and explicitly cancelled pending approvals and questions when an account reloads.

Published package: [`@michengai/dsh-im-connect@0.1.28`](https://www.npmjs.com/package/@michengai/dsh-im-connect/v/0.1.28).

## 0.1.27 — 2026-08-31

- Routed DSH tool approvals and structured user questions through the originating IM conversation, with text replies for approvals, single-choice, multiple-choice, and custom answers.
- Kept current and legacy DSH interaction contracts compatible while serializing same-session prompts and restricting group replies to the initiating user.
- Hardened prompt delivery and cancellation so partial sends, failed deliveries, aborts, session resets, and plugin disposal cannot leave an active stale interaction.

Published package: [`@michengai/dsh-im-connect@0.1.27`](https://www.npmjs.com/package/@michengai/dsh-im-connect/v/0.1.27).

## 0.1.25 — 2026-08-27

- Fixed the sidebar wrapper so the official workspace tree keeps its Host translator, only one Channels tab renders, and registry labels follow live locale changes without leaking subscriptions.
- Removed the external QR-code fallback. Pairing payloads are now rendered locally only, and pairing fails closed if local rasterization fails.
- Revoked runtime authorization and cleared stored credentials plus WeChat identity, context, and QR state when a channel is removed.
- Made multi-field IM Assistant settings updates atomic so invalid requests cannot partially change the active configuration.
- Added regression coverage and pull-request CI for tests and package verification.

Published package: [`@michengai/dsh-im-connect@0.1.25`](https://www.npmjs.com/package/@michengai/dsh-im-connect/v/0.1.25).

## 0.1.24 — 2026-08-26

- Restored localized built-in permission labels in IM Assistant settings instead of exposing missing `preset.*` translation keys.
- Kept full-access confirmation copy in the Host-owned permission namespace while moving display labels into IM Connect's bilingual dictionary.
- Moved the Changelog link from the README footer into the top navigation in both languages.

Published package: [`@michengai/dsh-im-connect@0.1.24`](https://www.npmjs.com/package/@michengai/dsh-im-connect/v/0.1.24).

## 0.1.23 — 2026-08-23

- Added bilingual changelogs covering the five most recent releases.
- Linked the release history from both README editions and included it in the npm package.

Published package: [`@michengai/dsh-im-connect@0.1.23`](https://www.npmjs.com/package/@michengai/dsh-im-connect/v/0.1.23).

## 0.1.22 — 2026-08-23

- Refreshed approval state handling.
- Allowed the QQ connector scanner required by the current login flow.

Release commit: [`47d1936`](https://github.com/MichengAI/dsh-im-connect/commit/47d1936).

## 0.1.21 — 2026-08-23

- Trusted validated WeCom group callbacks.
- Hardened IM channel runtime behavior.

Release commit: [`be07643`](https://github.com/MichengAI/dsh-im-connect/commit/be07643).
