import type { ChannelAdapter } from '../engine/types.js'
import type { ChannelId } from '../engine/session-id.js'
import { createDingtalkChannel } from './dingtalk.js'
import { createFeishuChannel } from './feishu.js'
import { createDiscordChannel } from './discord.js'
import { createTelegramChannel } from './telegram.js'
import { createWecomChannel } from './wecom.js'
import { createWeixinChannel } from './weixin.js'
import { createQqChannel } from './qq.js'
import { createSlackChannel } from './slack.js'
import { parseAdditionalImageHosts } from './image-host-policy.js'

export function createChannelAdapter(
  id: ChannelId,
  config: Record<string, string>,
  log: (line: string) => void,
  stateDir: string,
  options?: { accountId?: string; accountLabel?: string; host?: { get(name: string): unknown }; onWeixinBotToken?: (token: string | undefined) => void | Promise<void> },
): ChannelAdapter | undefined {
  let adapter: ChannelAdapter | undefined
  const imageOptions = ['qq', 'wecom', 'dingtalk'].includes(id)
    ? { additionalImageHosts: parseAdditionalImageHosts(config.additionalImageHosts) } : {}
  switch (id) {
    case 'telegram':
      adapter = createTelegramChannel({ token: config.token, stateDir, host: options?.host }, log); break
    case 'discord':
      adapter = createDiscordChannel({ token: config.token, stateDir, host: options?.host }, log); break
    case 'feishu':
      adapter = createFeishuChannel('feishu', { appId: config.appId, appSecret: config.appSecret, host: options?.host }, log); break
    case 'lark':
      adapter = createFeishuChannel('lark', { appId: config.appId, appSecret: config.appSecret, domain: 'lark', host: options?.host }, log); break
    case 'weixin':
      adapter = createWeixinChannel({ enabled: true, stateDir, botToken: config.botToken, onBotToken: options?.onWeixinBotToken, host: options?.host }, log, stateDir); break
    case 'wecom':
      adapter = createWecomChannel({ botId: config.botId, secret: config.secret, ...imageOptions, host: options?.host }, log); break
    case 'dingtalk':
      adapter = createDingtalkChannel({ clientId: config.clientId, clientSecret: config.clientSecret, ...imageOptions, host: options?.host }, log); break
    case 'qq':
      adapter = createQqChannel({ appId: config.appId, appSecret: config.appSecret, ...imageOptions, host: options?.host }, log); break
    case 'slack':
      adapter = createSlackChannel({ token: config.token, appToken: config.appToken, stateDir, host: options?.host }, log); break
    default:
      return undefined
  }
  if (!adapter) return undefined
  return {
    ...adapter,
    id: options?.accountId ?? adapter.id,
    label: options?.accountLabel ?? adapter.label,
  }
}

