import assert from 'node:assert/strict'
import { mkdtemp, readdir, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'
import { isDshCliEntry, isNewerVersion, isTrustedUpdateRequest, mergeMinimumReleaseAgeExclude, PLUGIN_UPDATE_HEADER, recordReleaseAgeExclude, resolveUpdateRuntime, shouldNotifyParent } from '../lib/plugin-updater.js'

test('IM 独立更新只接受同源专用请求', () => {
  assert.equal(isNewerVersion('0.1.34', '0.1.35'), true)
  assert.equal(isNewerVersion('0.1.34', '0.1.34'), false)
  assert.equal(isNewerVersion('0.1.0-rc.2', '0.1.0-rc.10'), true)
  assert.equal(isNewerVersion('0.1.0-rc.10', '0.1.0-rc.2'), false)
  assert.equal(isTrustedUpdateRequest({ headers: { [PLUGIN_UPDATE_HEADER]: '1', origin: 'http://localhost:3000', host: 'localhost:3000' }, socket: { remoteAddress: '::1' } }), true)
  assert.equal(isTrustedUpdateRequest({ headers: { origin: 'http://localhost:3000', host: 'localhost:3000' } }), false)
  assert.equal(isTrustedUpdateRequest({ headers: { [PLUGIN_UPDATE_HEADER]: '1', host: '127.0.0.1:19387' }, socket: { remoteAddress: '::1' } }), true)
  assert.equal(isTrustedUpdateRequest({ headers: { [PLUGIN_UPDATE_HEADER]: '1', origin: 'http://localhost:3000', host: 'localhost:3000' }, socket: { remoteAddress: '192.168.1.8' } }), false)
  assert.equal(isDshCliEntry('C:/tools/dsh/lib/bin.js', { name: '@deepseek-ai/dsh', bin: { dsh: 'lib/bin.js' } }, 'C:/tools/dsh'), true)
  assert.equal(isDshCliEntry('C:/tools/dsh/lib/bin.js', { name: '@deepseek-ai/dsh', bin: { dsh: 'lib/other.js' } }, 'C:/tools/dsh'), false)
  assert.equal(isDshCliEntry('C:/tools/dsh/lib/bin.js', { name: 'other-cli', bin: { dsh: 'lib/bin.js' } }, 'C:/tools/dsh'), false)
})

test('IM 客户端设置页面不再绑定自身更新入口', async () => {
  const client = await readFile(new URL('../client.js', import.meta.url), 'utf8')
  const host = await readFile(new URL('../src/index.ts', import.meta.url), 'utf8')
  assert.doesNotMatch(client, /titleRowSelector: "\.ima-title-row"/)
  assert.doesNotMatch(client, /createIcon: createPluginUpdateIcon/)
  assert.doesNotMatch(client, /const UPDATE_ICONS = \{/)
  assert.doesNotMatch(client, /channelMarkup\(h\(UPDATE_ICONS\[name\]/)
  assert.doesNotMatch(client, /ctx\.effect\(\(\) => observePluginUpdate/)
  assert.doesNotMatch(client, /UPDATE_ICON_PATHS/)
  assert.doesNotMatch(client, /document\.createElementNS\("http:\/\/www\.w3\.org\/2000\/svg", "svg"\)/)
  assert.doesNotMatch(client, /react-dom\/client/)
  assert.match(host, /endpoint: '\/api\/michengai\/dsh-im-connect\/update'/)
  assert.match(await readFile(new URL('../src/plugin-updater.ts', import.meta.url), 'utf8'), /const notifyParent = shouldNotifyParent\(target\)/)
  assert.match(await readFile(new URL('../src/plugin-updater.ts', import.meta.url), 'utf8'), /isDshCliEntry/)
})

test('官方 Desktop 在线更新指向 desktop profile，且不通知父进程', () => {
  const runtime = resolveUpdateRuntime({
    get(name) {
      if (name === 'profileContext') return {
        name: 'desktop',
        dir: 'D:/profile/desktop',
        packageManager: { command: 'D:/Tools/DeepSeek Harness/DeepSeek Harness.exe', args: ['--expose-internals', 'D:/runtime/pnpm.mjs'], env: { ELECTRON_RUN_AS_NODE: '1' } },
      }
      return undefined
    },
  }, {
    argv: ['node', 'D:/app/dsh/node_modules/@deepseek-ai/dsh-desktop-host/lib/index.js'],
    env: {},
    cwd: 'D:/profile/desktop',
    homeDir: 'C:/Users/YUJIYU',
  })
  assert.equal(runtime.profileName, 'desktop')
  assert.equal(runtime.officialDesktop, true)
  assert.equal(runtime.canAutoUpdate, true)
  assert.equal(shouldNotifyParent(runtime, () => {}), false)
})

test('自更新把刚安装的版本并进已有发布年龄白名单，不另起一行', () => {
  const created = mergeMinimumReleaseAgeExclude('packages:\n  - .\n', '@michengai/dsh-im-connect@1.0.1')
  assert.match(created, /minimumReleaseAgeExclude:\n  - '@michengai\/dsh-im-connect@1\.0\.1'\n/)
  assert.doesNotMatch(created, /minimumReleaseAgeExclude:\n  - '@michengai\/dsh-im-connect'\n/)

  const merged = mergeMinimumReleaseAgeExclude(
    "minimumReleaseAgeExclude:\n  - '@michengai/dsh-im-connect@0.1.77 || 0.1.78 || 1.0.0'\n  - keep@1.0.0\n",
    '@michengai/dsh-im-connect@1.0.1',
  )
  assert.match(merged, /'@michengai\/dsh-im-connect@0\.1\.77 \|\| 0\.1\.78 \|\| 1\.0\.0 \|\| 1\.0\.1'/)
  assert.match(merged, /keep@1\.0\.0/)
  assert.equal(merged.split('@michengai/dsh-im-connect').length - 1, 1)
})

test('同名白名单多行先并进第一条，读不懂的块则停止更新', () => {
  const merged = mergeMinimumReleaseAgeExclude(
    "minimumReleaseAgeExclude:\n  - '@michengai/dsh-im-connect@0.1.77'\n  - keep@1.0.0\n  - '@michengai/dsh-im-connect@1.0.0'\n",
    '@michengai/dsh-im-connect@1.0.1',
  )
  assert.match(merged, /'@michengai\/dsh-im-connect@0\.1\.77 \|\| 1\.0\.0 \|\| 1\.0\.1'/)
  assert.equal(merged.split('@michengai/dsh-im-connect').length - 1, 1)
  assert.match(merged, /keep@1\.0\.0/)
  assert.throws(() => mergeMinimumReleaseAgeExclude('minimumReleaseAgeExclude: [keep@1.0.0]\n', '@michengai/dsh-im-connect@1.0.1'), /无法安全合并/)
})

test('合并白名单保留行内注释、CRLF 和文件结尾换行', () => {
  const crlf = String.fromCharCode(13, 10)
  const merged = mergeMinimumReleaseAgeExclude(
    "minimumReleaseAgeExclude:" + crlf + "  - '@michengai/dsh-im-connect@1.0.0' # 保留" + crlf + "  - keep@1.0.0" + crlf,
    '@michengai/dsh-im-connect@1.0.1',
  )
  assert.match(merged, /'@michengai\/dsh-im-connect@1\.0\.0 \|\| 1\.0\.1' # 保留/)
  assert.ok(merged.includes(crlf))
  assert.equal(merged.at(-1), '\n')
  const noEol = mergeMinimumReleaseAgeExclude('packages:\n  - .', '@michengai/dsh-im-connect@1.0.1')
  assert.equal(noEol.endsWith('\n'), true)
  assert.match(noEol, /'@michengai\/dsh-im-connect@1\.0\.1'\n$/)
})

test('pluginManager 安装前先检查白名单，成功后才写入', async () => {
  const source = await readFile(new URL('../src/plugin-updater.ts', import.meta.url), 'utf8')
  const start = source.indexOf('if (target.pluginManager !== undefined)')
  const branch = source.slice(start, source.indexOf('await runCliInstall', start))
  assert.match(branch, /await guardReleaseAgeExclude[\s\S]*installBundle[\s\S]*await recordReleaseAgeExclude/)
})

test('白名单先写临时文件再替换，不留下临时文件', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-im-age-'))
  try {
    await writeFile(join(dir, 'pnpm-workspace.yaml'), "packages:\n  - .\nminimumReleaseAgeExclude:\n  - '@michengai/dsh-im-connect@1.0.0' # 保留\n", 'utf8')
    await recordReleaseAgeExclude(dir, '@michengai/dsh-im-connect@1.0.1')
    const text = await readFile(join(dir, 'pnpm-workspace.yaml'), 'utf8')
    assert.match(text, /1\.0\.0 \|\| 1\.0\.1' # 保留/)
    assert.deepEqual(await readdir(dir), ['pnpm-workspace.yaml'])
  } finally {
    await rm(dir, { recursive: true, force: true })
  }
})
