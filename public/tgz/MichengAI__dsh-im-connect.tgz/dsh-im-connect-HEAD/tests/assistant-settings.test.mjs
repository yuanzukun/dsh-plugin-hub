import assert from 'node:assert/strict'
import test from 'node:test'
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { normalizeAssistantModel, normalizeEffort, normalizePermission, normalizeWorkspacePath, pickAssistantModel } from '../lib/engine/assistant-settings.js'
import { ChannelManager } from '../lib/manager.js'

test('初始化期间卸载后不得恢复会话或访问失效服务', async t => {
  const manager = makeManager(t)
  let release
  const waiting = new Promise(resolve => { release = resolve })
  manager.migrateLegacyWeixinToken = () => waiting
  manager.clearUnsupportedReasoningEfforts = async () => { assert.fail('卸载后仍读取服务') }
  const work = manager.initEnabled()
  manager.disposeApi()
  release()
  await work
  manager.engine.attachMappedSessions = async () => { assert.fail('卸载后仍恢复会话') }
  await manager.attachMappedSessions()
})

test('DSH 子包依赖声明与客户端和服务端实际使用保持一致', () => {
  const manifest = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))
  assert.equal(manifest.engines?.node, '^22.19.0 || >=24.0.0')
  assert.equal(manifest.engines?.dsh, '>=0.2.0-rc.1 <0.3.0-0')
  assert.equal(manifest.packageManager, 'pnpm@11.22.0')
  const dshPackages = [
    '@deepseek-ai/dsh-agent',
    '@deepseek-ai/dsh-client-locale',
    '@deepseek-ai/dsh-client-ui-primitives',
    '@deepseek-ai/dsh-client-ui-settings',
    '@deepseek-ai/dsh-client-ui-slots',
    '@deepseek-ai/dsh-host-webserver',
  ]
  const hostUnion = '>=0.2.0-rc.1 <0.3.0-0'
  for (const packageName of dshPackages) {
    assert.equal(manifest.peerDependencies[packageName], hostUnion)
    assert.equal(manifest.devDependencies[packageName], '0.2.2-rc.2')
  }
  assert.equal(manifest.devDependencies['@deepseek-ai/cordis'], '4.1.0')
  assert.equal(
    manifest.peerDependencies['@deepseek-ai/dsh-client-runtime'],
    undefined,
    '上游已停更该包，客户端也不再 require 它，不得保留这条 peer',
  )
  assert.equal(manifest.dependencies?.antd, undefined)
  assert.equal(manifest.dependencies?.['react-dom'], undefined)
  assert.equal(manifest.devDependencies?.antd, undefined, '彻底移除 antd 开发依赖')
  assert.equal(manifest.devDependencies['react-dom'], '^18.3.1')
})

test('client.js 依赖的宿主模块必须在 dsh.client.inject 中声明', () => {
  // ModuleLoader 只解析 manifest 声明的宿主模块。漏声明时 require 会走 catch 返回 {}，
  // 组件拿到 undefined 类型后在渲染期直接崩溃（primitives 就是这样漏掉的）。
  const manifest = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  const injected = new Set(manifest.dsh?.client?.inject || [])
  const required = [...client.matchAll(/require\("(@deepseek-ai\/[^"]+)"\)/g)].map((match) => match[1])
  assert.ok(required.length > 0, 'client.js 应至少依赖一个宿主模块')
  for (const name of new Set(required)) assert.ok(injected.has(name), `${name} 未在 dsh.client.inject 中声明`)
})

function makeManager(t, ctx = {}, engineOverrides = {}) {
  const stateDir = mkdtempSync(join(tmpdir(), 'im-connect-assistant-'))
  const permissionPresets = {
    names: ['review', 'workspace-write', 'danger-full-access'],
    defaultPreset: 'review',
    optionOf: (name) => ({ value: name, name }),
  }
  const engineConfig = {
    cwd: stateDir,
    provider: 'initial-provider',
    model: 'initial-model',
    agentPreset: 'standard',
    mergeTimeoutSecs: 5,
    permissionPreset: 'review',
    ...engineOverrides,
  }
  const manager = new ChannelManager({ ctx: { ...ctx, permissionPresets }, stateDir, log: () => undefined, engineConfig })
  t.after(() => {
    manager.disposeApi()
    rmSync(stateDir, { recursive: true, force: true })
  })
  return manager
}

/** connect 只回账号 ID；账号视图统一从列表取。 */
function accountOf(manager, accountId) {
  return manager.list().flatMap((channel) => channel.accounts).find((account) => account.id === accountId)
}

test('账号在线统计只接受明确就绪状态，连接中与异常不算在线', t => {
  const manager = makeManager(t)
  manager.store.channels['telegram:test'] = { platform: 'telegram', enabled: true, config: {} }
  for (const status of ['连接中', '等待网关握手', '鉴权中', '重连中', '已断开（code 1006）', '连接错误', '轮询异常（详情见本机日志）', '未登录', '等待扫码', '已停止', '未知新状态']) {
    manager.running.set('telegram:test', { status: () => status, stop() {} })
    const channel = manager.list().find(item => item.id === 'telegram')
    assert.equal(channel.accounts[0].connected, false, status)
    assert.equal(channel.online, 0, status)
  }
  for (const status of ['已连接', 'Stream 已连接', '长连接已建立', '轮询中', '已登录', '已登录（自动恢复）']) {
    manager.running.set('telegram:test', { status: () => status, stop() {} })
    assert.equal(manager.list().find(item => item.id === 'telegram').online, 1, status)
  }
})

test('状态检查调用诊断并返回接收配置，不启动渠道或发送消息', async t => {
  const manager = makeManager(t)
  manager.store.channels['telegram:test'] = { platform: 'telegram', enabled: true, receiveEnabled: false, config: {} }
  manager.running.set('telegram:test', {
    status: () => '轮询中',
    stop() {},
    start: () => assert.fail('不应启动渠道'),
    send: () => assert.fail('不应发送消息'),
  })
  const result = await manager.checkAccount('telegram:test')
  assert.equal(result.ok, true)
  assert.equal(result.account.connectionState, 'connected')
  assert.equal(result.account.receiveConfigured, false)
  assert.ok(Number.isFinite(Date.parse(result.account.lastCheckedAt)))
  assert.equal((await manager.checkAccount('missing')).ok, false)
  manager.running.get('telegram:test').status = () => { throw new Error('secret-token') }
  const failed = await manager.checkAccount('telegram:test')
  assert.equal(failed.account.connectionState, 'unknown')
  assert.equal(failed.account.connected, false)
  assert.ok(!JSON.stringify(failed).includes('secret-token'))
})

test('状态检查保留离线账号的接收选择，暂停与断开分别返回，落盘失败不更新时间', async t => {
  const manager = makeManager(t)
  const id = 'telegram:offline'
  manager.store.channels[id] = { platform: 'telegram', enabled: true, receiveEnabled: true, config: {} }
  const offline = (await manager.checkAccount(id)).account
  assert.equal(offline.connectionState, 'disconnected')
  assert.equal(offline.receiveConfigured, true)
  assert.equal(offline.receiveEnabled, false)
  manager.store.channels[id].receiveEnabled = false
  const paused = (await manager.checkAccount(id)).account
  assert.equal(paused.connectionState, 'stopped')
  assert.equal(paused.receiveConfigured, false)
  manager.store.channels[id].lastCheckedAt = '2026-01-01T00:00:00Z'
  manager.flush = () => { throw new Error('disk failure') }
  await assert.rejects(() => manager.checkAccount(id), /disk failure/)
  assert.equal(manager.store.channels[id].lastCheckedAt, '2026-01-01T00:00:00Z')
})

test('取密异常归为本地状态失败，不误导检查网络或暴露秘密', async t => {
  const manager = makeManager(t)
  const id = 'telegram:local-failure'
  manager.store.channels[id] = { platform: 'telegram', enabled: true, config: {} }
  manager.resolveSecrets = async () => { throw new Error('private-secret') }
  const result = await manager.checkAccount(id)
  assert.equal(result.diagnostics.checks[0].reason, 'local-state')
  assert.equal(result.diagnostics.checks[0].status, 'failed')
  assert.ok(!JSON.stringify(result).includes('private-secret'))
})

test('同账号诊断请求合并，卸载取消诊断且不保存过期结果', async t => {
  const manager = makeManager(t)
  const id = 'telegram:diagnostic'
  manager.store.channels[id] = { platform: 'telegram', enabled: true, config: {} }
  let calls = 0, began
  const started = new Promise(resolve => { began = resolve })
  manager.running.set(id, { status: () => '轮询中', stop() {}, diagnose: signal => {
    calls++
    began()
    return new Promise((_, reject) => signal.addEventListener('abort', () => reject(signal.reason), { once: true }))
  } })
  const first = manager.checkAccount(id)
  const second = manager.checkAccount(id)
  assert.equal(first, second)
  await started
  manager.disposeApi()
  assert.equal((await first).ok, false)
  assert.equal(calls, 1)
  assert.equal(manager.store.channels[id].lastCheckedAt, undefined)
})

test('账号 Agent 预设复用 Host 名册，验证后保存并保留旧会话预设', async t => {
  const manager = makeManager(t, { get: name => name === 'agentPresets' ? { remoteExportList: async () => ({ presets: [{ id: 'standard' }, { id: 'research', name: '研究' }, { id: 'broken', broken: 'missing plugin' }] }) } : undefined })
  manager.startOne = async () => undefined
  const created = await manager.connect('telegram', { token: 'preset-test' }, { agentPreset: 'standard' })
  assert.equal(created.ok, true)
  manager.sessions.upsert('old-key', { sessionId: 'old-session', channel: created.accountId, kind: 'dm', chatId: 'u', title: '旧会话', updatedAt: new Date().toISOString() })
  const reloads = []
  manager.engine.reloadChannel = async (id, options) => reloads.push({ id, options })
  const result = await manager.updateAccount(created.accountId, { agentPreset: 'research' })
  assert.equal(result.account.agentPreset, 'research')
  assert.equal(manager.accountEngineConfig(created.accountId).agentPreset, 'research')
  assert.equal(manager.sessions.list()[0].agentPreset, 'standard')
  assert.equal(reloads[0].options.resetSessions, true)
  for (const agentPreset of ['unknown', 'broken', 42]) assert.equal((await manager.updateAccount(created.accountId, { agentPreset })).ok, false)
  assert.equal(manager.accountEngineConfig(created.accountId).agentPreset, 'research')
})

test('助手模型必须同时有提供商和模型 id', () => {
  assert.equal(normalizeAssistantModel({ provider: ' deepseek ', model: ' ' }), undefined)
  assert.deepEqual(
    normalizeAssistantModel({ provider: 'deepseek', model: 'deepseek-chat' }),
    { provider: 'deepseek', model: 'deepseek-chat' },
  )
})

test('页面已保存的模型优先于插件配置和 Host 默认', () => {
  assert.deepEqual(
    pickAssistantModel(
      { provider: 'openai', model: 'gpt-4.1' },
      { provider: 'deepseek', model: 'deepseek-chat' },
    ),
    { provider: 'openai', model: 'gpt-4.1' },
  )
  assert.deepEqual(
    pickAssistantModel(undefined, { provider: 'deepseek', model: 'deepseek-v4-flash' }),
    { provider: 'deepseek', model: 'deepseek-v4-flash' },
  )
})

test('工作区路径去掉空白，空值视为未设置', () => {
  assert.equal(normalizeWorkspacePath('  D:\\\\repo\\\\app  '), 'D:\\\\repo\\\\app')
  assert.equal(normalizeWorkspacePath('   '), undefined)
  assert.equal(normalizeWorkspacePath(1), undefined)
})

test('权限接受 Host 官方列表并迁移旧值', () => {
  const official = ['review', 'workspace-write', 'danger-full-access']
  assert.equal(normalizePermission('review', official), 'review')
  assert.equal(normalizePermission('workspace-write', official), 'workspace-write')
  assert.equal(normalizePermission('danger-full-access', official), 'danger-full-access')
  assert.equal(normalizePermission('full-access', official), 'danger-full-access')
  assert.equal(normalizePermission('admin', official), undefined)
  assert.equal(normalizePermission(''), undefined)
})

test('权限菜单直接使用 Host 官方列表与官方文案', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  const manager = readFileSync(new URL('../src/manager.ts', import.meta.url), 'utf8')
  const router = readFileSync(new URL('../src/engine/router.ts', import.meta.url), 'utf8')
  assert.doesNotMatch(client, /const PERMISSIONS =/)
  assert.match(client, /permissions: data\.permissions \|\| \[\]/)
  assert.match(client, /permissionLabel\(item, t\)/)
  assert.match(client, /"permission\.readOnly": "只读"/)
  assert.match(client, /"permission\.workspaceWrite": "工作区写入"/)
  assert.match(client, /"permission\.fullAccess": "完全访问"/)
  assert.match(client, /ctx\.locale\.bind\("permission\.access"\)/)
  assert.match(client, /ctx\.locale\.bind\("model"\)/)
  assert.match(client, /modelT\("menu\.model"\)/)
  assert.match(client, /modelT\("menu\.effort"\)/)
  assert.doesNotMatch(client, /label: "Model"|label: "Effort"/, '模型选择器必须使用 Chat 的官方国际化词条')
  assert.match(manager, /official\.names\.map\(\(name\) => official\.optionOf\(name\)\)/)
  assert.match(manager, /permissions: this\.permissionOptions\(\)/)
  assert.match(router, /permissionPresets\.set\(agent\.session, permission\)/)
  assert.doesNotMatch(router, /setSandboxMode/)
  assert.match(client, /require\("@deepseek-ai\/dsh-client-ui-primitives"\)/)
  assert.doesNotMatch(client, /h\(RiskConfirmation/)
  assert.match(client, /h\(Checkbox, \{ checked: fullAccessAcknowledged/)
  assert.match(client, /permissionT\("confirm.title"\)/)
  assert.match(client, /okButtonProps: \{ disabled: !fullAccessAcknowledged \}/)
  assert.match(client, /if \(next === "danger-full-access"\)/)
  assert.doesNotMatch(client, /function openFullAccessConfirmation/)
  assert.doesNotMatch(client, /ima-risk-warning|ima-full-access-dialog/)
  assert.doesNotMatch(client, /\.ima-chip-row\.is-risk|is-risk/, '权限菜单必须完全沿用官方样式')
})

test('添加账号使用 Host 风格选择器且二维码按需生成', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /function AccountSettingsPicker\(props\)/)
  assert.match(client, /h\(AccountSettingsPicker, \{[\s\S]*showAutoNameNote: true/)
  const bind = client.slice(client.indexOf('function BindModal'), client.indexOf('function AccountSettingsPicker'))
  assert.doesNotMatch(bind, /compact: true/, '新增账号应使用和设置页相同的两列布局')
  assert.match(bind, /width: 720/)
  assert.match(client, /function mainSessionModel\(state\)/)
  assert.match(client, /modelSelection/)
  assert.match(client, /readMainSessionModel: \(\) => readMainSessionModel\(ctx\)/)
  assert.match(client, /className: "ima-account-picker ima-model-select"/)
  assert.match(client, /props\.createWorkspace/)
  assert.match(client, /props\.pickDirectory/)
  assert.doesNotMatch(client, /h\("input", \{[^\n]*settings\.name/)
  assert.doesNotMatch(client, /ima-qrph|等待二维码/)
  assert.match(client, /src\s*\? h\("div", \{ className: "ima-qrbox" \}/)
  assert.match(client, /qrStarted \? t\("bind\.refresh"\) : t\("action\.generateQr"\)/)
  assert.match(client, /if \(tab !== "qr" \|\| !qrStarted\) return undefined/)
})

test('渠道展开状态不叠加 hover，空渠道不可展开', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /\.ima-platform:not\(\.open\):not\(\.empty\) \.ima-platform-head:hover/)
  assert.doesNotMatch(client, /(^|\n)\.ima-platform-head:hover\{/)
  assert.match(client, /const canExpand = \(ch\.accounts \|\| \[\]\)\.length > 0/)
  assert.match(client, /const open = canExpand && Boolean\(expanded\[ch\.id\]\)/)
  assert.match(client, /role: canExpand \? "button" : undefined/)
  assert.match(client, /"aria-expanded": canExpand \? open : undefined/)
  assert.match(client, /canExpand && h\(IconChevron\)/)
  assert.doesNotMatch(client, /useState\(\{ weixin: true \}\)/)
  assert.match(client, /const \[expanded, setExpanded\] = useState\(\{\}\)/)
})

test('渠道分组只显示账号数量，账号子行保留状态和独立操作', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  const start = client.indexOf('...(ch.accounts || []).map((account)')
  const end = client.indexOf('selectedAccount &&', start)
  const rows = client.slice(start, end)
  assert.ok(start > 0 && end > start)
  assert.doesNotMatch(rows, /h\(Logo|className: "ima-account-id"/)
  assert.match(rows, /role: "switch"/)
  assert.match(rows, /setSettingsAccount\(account.id\)/)
  assert.match(rows, /account.connectionState/)
  assert.match(rows, /connection.paused/)
  assert.match(client, /t\("account.count", \{ count: ch.total \}\)/)
})

test('账号详情操作按钮允许换行，保持标签可读', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /\.ima-inspector-actions\{[^}]*flex-wrap:wrap/)
  assert.match(client, /\.ima-inspector-actions>button\{[^}]*flex:none[^}]*white-space:nowrap/)
})

test('企业微信侧边栏小图标移除白色应用底板并放大有效标记', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /function BrandMark\(\{ id, compact \}\)/)
  assert.match(client, /return svg\(compact \? "4 6 39 34" : "0 0 46 46"/)
  assert.match(client, /!compact && h\("path", \{ key: "bg"/)
  assert.match(client, /h\(BrandMark, \{ id, compact: small \}\)/)
})

test('账号弹窗使用 Ant Modal，不再自制遮罩', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /selectedAccount && h\(Modal,/)
  assert.match(client, /className: "ima-account-modal"/)
  assert.match(client, /className: "ima-bind-modal"/)
  assert.doesNotMatch(client, /function AccountModalLayer/)
  assert.doesNotMatch(client, /ima-page ima-mask/)
  assert.doesNotMatch(client, /h\("div", \{ className: "ima-mask"/)
})

test('新增与设置弹窗对齐定时任务宽度 720px，工作区下拉支持 footer 新增工作区', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /\.ima-bind-modal,\.ima-account-modal\{width:min\(720px,100%\) !important;max-height:100%;min-height:0\}/)
  assert.match(client, /className: "ima-bind-modal",\s*title:[^,]*,[\s\S]*?width: 720/)
  assert.match(client, /className: "ima-account-modal",\s*title:[^,]*,[\s\S]*?width: 720/)
  assert.match(client, /footer:\s*\[\{\s*value:\s*"add-workspace",\s*label:\s*t\("composer\.addWorkspace"\)/)
  assert.match(client, /onFooter:\s*\(\)\s*=>\s*\{\s*onAddWorkspace\(\);\s*\}/)
})

test('设置页占满宿主内容区，不再限制 1080px', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /\.ima-page\.ima-account-page\{[^}]*width:100%/)
  assert.doesNotMatch(client, /\.ima-page\.ima-account-page\{[^}]*max-width:1080px/)
})

test('弹窗内容超出视口时内容区滚动，footer 保持可见', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /contentClassName: \["ima-modal-content", contentClassName\]\.filter\(Boolean\)\.join\(" "\)/)
  assert.match(client, /\.ima-bind-modal>\.ima-modal-content,\.ima-account-modal>\.ima-modal-content\{[^}]*overflow-y:auto/)
})

test('账号弹窗继承成功色变量，已连接和诊断通过用绿色 Tag，支持 info 状态', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /\.ima-page,\.ima-account-modal,\.ima-bind-modal,\.ima-inspector\{[^}]*--ima-ok/)
  assert.match(client, /h\(Tag, \{\s*color: account\.receiveConfigured === false \? "warning" : account\.connectionState === "connected" \? "success"/)
  assert.match(client, /h\(Tag, \{ color: item\.status === "passed" \? "success"/)
  assert.match(client, /\.ima-tag-info/)
  assert.doesNotMatch(client, /function ChannelCard|\.ima-chip|ima-inspector-empty|ima-diagnostic-passed|\.ima-control\{/)
})

test('账号通过设置按钮打开弹窗，不再占用列表侧栏', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /const ACCOUNT_SELECTION_KEY = "dsh-im-connect\.settings\.selected-account"/)
  assert.match(client, /useState\(storedAccountSelection\)/)
  assert.match(client, /const next = all\.some\(\(item\) => item\.id === current\) \? current : ""/)
  assert.doesNotMatch(client, /\? current : \(\(data\.channels[\s\S]*all\[0\]\?\.id/, '首次进入不能自动选中第一个账号')
  assert.doesNotMatch(client, /settings\.selectAccountTitle/)
  assert.doesNotMatch(client, /settings\.noAccountsTitle/)
  assert.match(client, /selectedAccount && h\(Modal,/)
  assert.match(client, /if \(action === "remove" && selected === id\) selectAccount\(removalFallback\)/)
})

test('公开私聊提示审批边界，账号详情保存只接受最新结果', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /settings\.publicChatNotice": "未批准用户可以发起聊天，但不能批准工具调用。"/)
  assert.match(client, /privateAccess === "all" && h\("div", \{ className: "ima-picker-note warning" \}, t\("settings\.publicChatNotice"\)\)/)
  assert.match(client, /account\.assistant && account\.assistant\.reasoningEffort/)
  assert.match(client, /const saveSeq = useRef\(0\)/)
  assert.match(client, /const seq = \+\+saveSeq\.current/)
  assert.match(client, /if \(seq === saveSeq\.current\) setNote/)
  assert.match(client, /data\.newIdentity \? t\("bind\.newIdentity"\) : t\("bind\.success"\)/)
})

test('IM 自有界面注册双语词典并随 Host 语言刷新', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /const IM_LOCALE_NS = "im-connect"/)
  assert.match(client, /const IM_LOCALES = \{[\s\S]*zh:[\s\S]*en:/)
  assert.match(client, /ctx\.locale\.register\(IM_LOCALE_NS, IM_LOCALES\)/)
  assert.match(client, /locale: IM_LOCALE_NS/)
  assert.match(client, /label: \(\) => t\("settings\.label"\)/, '设置菜单必须在 Host 语言确定后再解析标签')
  assert.match(client, /function LocalizedChannelRail\(\)[\s\S]*useSyncExternalStore/)
  assert.match(client, /function LocalizedSessionSwitcher\(props\)[\s\S]*useSyncExternalStore/)
  assert.match(client, /function LocalizedSettingsPage\(props\)[\s\S]*useSyncExternalStore/)
  assert.match(client, /}, LocalizedSettingsPage\)\)/, '设置页本身必须订阅语言变化，模型词条才能立即刷新')
  assert.match(client, /"settings\.label": "IM Assistant"/)
  assert.match(client, /"settings\.label": "IM助理"/, '中文设置区标题是 Codex UI 的跨插件导航兼容标识')
  assert.match(client, /"settings\.title": "IM Assistant"/)
  assert.match(client, /"settings\.title": "IM助理"/)
  assert.match(client, /"action\.addAccount": "Add account"/)
  assert.match(client, /"action\.checkConnection": "Diagnose connection"/)
  assert.match(client, /"action\.removeAccount": "Remove"/)
  assert.match(client, /"account\.privateAll": "Allow all DM users"/)
  assert.match(client, /"account\.removeConfirm": "Remove this account\? Its saved settings and credentials will also be deleted\."/)
  assert.match(client, /"server\.accountMissing": "Account does not exist"/)
  assert.match(client, /\["账号不存在", "server\.accountMissing"\]/)
  assert.match(client, /\["请选择提供商和模型", "server\.selectModel"\]/)
  assert.match(client, /"rail\.channels": "Channels"/)
  assert.match(client, /t\("settings\.title"\)/)
  assert.match(client, /t\("action\.addAccount"\)/)
  assert.match(client, /t\("account\.privateAccess"\)/)
  assert.match(client, /t\("account\.receive"\)/)
  assert.match(client, /description: t\("account\.removeConfirm"\)/)
  assert.match(client, /okButtonProps: \{ danger: true \}/)
  assert.match(client, /hostModalButton\(okText \|\| "确定", handleOk, okButtonProps\?\.danger \? "danger" : "primary"/)
  assert.doesNotMatch(client, /ima-n-danger-button/)
  assert.match(client, /function accountLabel\(account, t\)/)
  assert.match(client, /t\("error\.detailsInLog"\)/)

  const bindAndPicker = client.slice(client.indexOf('function BindModal'), client.indexOf('function AccountInspector'))
  const accountPage = client.slice(client.indexOf('function AccountInspector'), client.indexOf('const CHANNEL_WORKSPACE_PREFIX'))
  assert.doesNotMatch(
    bindAndPicker + accountPage,
    /生成二维码|请选择工作区|请选择模型|请选择权限|私聊准入|绑定成功后会自动生成账号名|保存中|已保存|运行正常|当前工作区|接收消息|检查连接|重新连接|移除接入|IM助理|添加账号|处理中|在线|离线/,
    '多账号设置页的用户可见文案必须通过 Host i18n 解析',
  )
})

test('设置标题旁提供项目主页与问题反馈入口', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /className: "ima-title-row"/)
  assert.match(client, /window\.open\("https:\/\/github\.com\/MichengAI\/dsh-im-connect", "_blank", "noreferrer"\)/)
  assert.match(client, /window\.open\("https:\/\/github\.com\/MichengAI\/dsh-im-connect\/issues", "_blank", "noreferrer"\)/)
  assert.match(client, /function GithubMark16\(\)/)
  assert.match(client, /"settings\.viewProject": "GitHub"/)
  assert.match(client, /"settings\.feedback": "问题反馈"/)
  assert.match(client, /"settings\.feedback": "Issues"/)
  assert.match(client, /className: "ima-title-links"/)
  assert.match(client, /variant: "outline"[\s\S]*?size: "sm"[\s\S]*?"aria-label": t\("settings\.viewProject"\)/)
  assert.match(client, /variant: "outline"[\s\S]*?size: "sm"[\s\S]*?"aria-label": t\("settings\.feedback"\)/)
  assert.match(client, /\.ima-title-links\{display:flex;align-items:center;gap:8px/)
  assert.match(client, /installSettingsNavIcon\(ctx, \(\) => t\("settings\.label"\)\)/)
  assert.match(client, /data-ima-nav-icon/)
  assert.match(client, /\.ima-btn\{display:inline-flex;align-items:center;justify-content:center/)
  assert.match(client, /@media\(max-width:720px\)\{\.ima-title-row\{flex-wrap:wrap\}\}/)
})

test('设置导航图标走通用 mask 注入，不改宿主 svg 内容', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.doesNotMatch(client, /data-orca-link-icon|NAV_ICON_SKIN/, '不得写死任何皮肤属性')
  assert.match(client, /\[data-ima-nav-icon\]>svg\{display:none!important\}/)
  assert.match(client, /\[data-ima-nav-icon\]::before\{/)

  const start = client.indexOf('const NAV_ICON_MARKER')
  const end = client.indexOf('function installSettingsNavIcon', start)
  assert.ok(start >= 0 && end > start, '必须能提取设置导航图标补丁')
  const document = {}
  const { applySettingsNavIcon, restoreSettingsNavIcon } = new Function('document', 'settingsNavIconMask', `${client.slice(start, end)}\nreturn { applySettingsNavIcon, restoreSettingsNavIcon };`)(document, () => 'url("data:image/svg+xml,x")')

  const svg = { innerHTML: '<path d="host"/>' }
  const button = {
    textContent: 'IM 助理',
    attributes: new Map(),
    children: [svg],
    style: { setProperty() {} },
    hasAttribute(name) { return this.attributes.has(name) },
    getAttribute(name) { return this.attributes.has(name) ? this.attributes.get(name) : null },
    setAttribute(name, value) { this.attributes.set(name, String(value)) },
    removeAttribute(name) { this.attributes.delete(name) },
  }

  assert.equal(applySettingsNavIcon(button, () => 'IM 助理'), true)
  assert.equal(button.getAttribute('data-ima-nav-icon'), '')
  assert.equal(button.children.length, 1, '禁止向 button 插入任何真实 DOM 节点')
  assert.equal(svg.innerHTML, '<path d="host"/>', '不得改写宿主 svg 内容')
  assert.equal(applySettingsNavIcon(button, () => 'IM 助理'), false, '重复同步必须幂等')
  assert.equal(applySettingsNavIcon(button, () => '其他'), true, '非本插件项清除 marker')
  assert.equal(button.hasAttribute('data-ima-nav-icon'), false)

  applySettingsNavIcon(button, () => 'IM 助理')
  assert.equal(button.hasAttribute('data-ima-nav-icon'), true)
  assert.equal(restoreSettingsNavIcon(button), true)
  assert.equal(button.getAttribute('data-ima-nav-icon'), null)

  // 跨版本与空白容错回归：宿主在 Alpha/Web 或不同语言下空格不一致、带 span 标签
  const span = { textContent: 'IM 助理' }
  const buttonWithSpan = {
    textContent: '   IM 助理   ',
    attributes: new Map(),
    children: [svg, span],
    style: { setProperty() {} },
    querySelector(selector) { return selector === 'span' ? span : null },
    hasAttribute(name) { return this.attributes.has(name) },
    getAttribute(name) { return this.attributes.has(name) ? this.attributes.get(name) : null },
    setAttribute(name, value) { this.attributes.set(name, String(value)) },
    removeAttribute(name) { this.attributes.delete(name) },
  }
  // 字典返回无空格 "IM助理"，DOM 渲染带空格 "IM 助理"
  assert.equal(applySettingsNavIcon(buttonWithSpan, () => 'IM助理'), true, '无空格字典必须匹配带空格导航行')
  assert.equal(buttonWithSpan.hasAttribute('data-ima-nav-icon'), true)
  buttonWithSpan.attributes.clear()

  // 英文与大小写容错
  span.textContent = 'IM Assistant'
  buttonWithSpan.textContent = 'IM Assistant'
  assert.equal(applySettingsNavIcon(buttonWithSpan, () => 'IM助理'), true, '英文导航行在中文配置下也能识别')
  assert.equal(buttonWithSpan.hasAttribute('data-ima-nav-icon'), true)
  buttonWithSpan.attributes.clear()

  // 词典未就绪（返回 key "settings.label"）也能通过自身别名识别
  span.textContent = 'IM 助理'
  buttonWithSpan.textContent = 'IM 助理'
  assert.equal(applySettingsNavIcon(buttonWithSpan, () => 'settings.label'), true, '词典未就绪时也能通过自身别名识别')
  assert.equal(buttonWithSpan.hasAttribute('data-ima-nav-icon'), true)
  buttonWithSpan.attributes.clear()

  // 老宿主回归：老宿主原生图标为 <svg class="...navIcon">，不得被误判为新版插槽容器导致 marker 被移除
  const oldHostSvgWithNavIcon = {
    tagName: 'SVG',
    className: 'dcu-nav-item-navIcon',
    innerHTML: '<path d="gear"/>',
  }
  const oldHostButton = {
    textContent: 'IM 助理',
    attributes: new Map(),
    children: [oldHostSvgWithNavIcon, span],
    querySelector(selector) {
      if (selector === 'span') return span
      if (selector === 'span[class*="navIcon"]') return null
      if (selector === '[class*="navIcon"]') return oldHostSvgWithNavIcon
      return null
    },
    hasAttribute(name) { return this.attributes.has(name) },
    getAttribute(name) { return this.attributes.has(name) ? this.attributes.get(name) : null },
    setAttribute(name, value) { this.attributes.set(name, String(value)) },
    removeAttribute(name) { this.attributes.delete(name) },
  }
  assert.equal(applySettingsNavIcon(oldHostButton, () => 'IM 助理'), true, '老宿主带 navIcon 类名的 svg 不得误判为插槽容器，必须打上 marker')
  assert.equal(oldHostButton.hasAttribute('data-ima-nav-icon'), true)

  // 新宿主防御：带 navIcon 类的容器被识别为已有插槽，不打 marker 且移除残留
  const newHostIconSpan = {
    tagName: 'SPAN',
    className: 'navIcon dcu-nav-icon',
    getAttribute() { return null },
  }
  const newHostButton = {
    textContent: 'IM 助理',
    attributes: new Map([['data-ima-nav-icon', '']]),
    children: [newHostIconSpan, span],
    querySelector(selector) {
      if (selector === 'span') return span
      if (selector.includes('navIcon')) return newHostIconSpan
      return null
    },
    hasAttribute(name) { return this.attributes.has(name) },
    getAttribute(name) { return this.attributes.has(name) ? this.attributes.get(name) : null },
    setAttribute(name, value) { this.attributes.set(name, String(value)) },
    removeAttribute(name) { this.attributes.delete(name) },
  }
  assert.equal(applySettingsNavIcon(newHostButton, () => 'IM 助理'), true, '新版宿主插槽容器存在时必须移除 DOM marker')
  assert.equal(newHostButton.hasAttribute('data-ima-nav-icon'), false)
  assert.equal(applySettingsNavIcon(newHostButton, () => 'IM 助理'), false, '新宿主下不重复打 marker')

  // 移动端抽屉/侧栏入口防御：在移动端 role="dialog" 抽屉下，侧栏按钮绝不能被打上 marker，且已有残留必须自愈清理
  const sidebarGlyph = {
    tagName: 'SPAN',
    className: 'dcu-sb-glyph',
    getAttribute(name) { return name === 'aria-hidden' ? 'true' : null },
  }
  const sidebarTitle = { textContent: 'IM 助理' }
  const mobileSidebarButton = {
    className: 'dcu-sb-row dcu-sb-more-item',
    textContent: 'IM 助理',
    attributes: new Map([['data-ima-nav-icon', '']]),
    children: [sidebarGlyph, sidebarTitle],
    closest(selector) {
      if (selector.includes('.dcu-sb-root') || selector.includes('.dcu-sidebar-nav-root')) return {}
      return null
    },
    matches(selector) {
      return selector.includes('.dcu-sb-row')
    },
    querySelector(selector) {
      if (selector === 'span') return sidebarTitle
      if (selector.includes('glyph') || selector.includes('dcu-sb-glyph')) return sidebarGlyph
      return null
    },
    hasAttribute(name) { return this.attributes.has(name) },
    getAttribute(name) { return this.attributes.has(name) ? this.attributes.get(name) : null },
    setAttribute(name, value) { this.attributes.set(name, String(value)) },
    removeAttribute(name) { this.attributes.delete(name) },
  }

  assert.equal(applySettingsNavIcon(mobileSidebarButton, () => 'IM 助理'), true, '侧边栏按钮即使位于移动端 dialog 抽屉下也必须清除残留 marker')
  assert.equal(mobileSidebarButton.hasAttribute('data-ima-nav-icon'), false)
  assert.equal(applySettingsNavIcon(mobileSidebarButton, () => 'IM 助理'), false, '侧栏按钮不重复打 marker')
  assert.equal(mobileSidebarButton.hasAttribute('data-ima-nav-icon'), false)

  // 必须精确限定属性，不得无差别清空侧栏行的所有伪元素（保护侧栏拖拽线等自身样式）
  assert.match(client, /\.dcu-sb-row\[\$\{NAV_ICON_MARKER\}\]::before\{content:none!important\}/)
  assert.doesNotMatch(client, /\.dcu-sb-row::before\{content:none!important\}/, '不得包含无属性限定的侧栏行伪元素清空规则')

  // 必须兼容 Alpha/新版的全屏快捷键设置面板选择器与固化 SVG 遮罩
  assert.match(client, /\[data-shortcut-modal="settings"\] nav button/, '必须兼容宿主新版设置工作台选择器')
  assert.match(client, /\.slots\.inject\("settings\.section\.icon"/, '必须通过 inject 声明式门控注册图标插槽')
  assert.match(client, /specDynamic\("settings\.section\.icon"\)/, '必须具备图标插槽服务层先验门控')
  assert.match(client, /ima-settings-nav-icon-style/, '必须具备独立导航图标样式表 ID 保障')
  assert.match(client, /QUEUE_ICON_PATHS/, '必须具备固化的对话气泡矢量路径，杜绝空 mask')
  assert.match(client, /QUEUE_ICON_MASK/, '样式表默认 mask 必须直接固化气泡 Data URL')
})

test('设置导航图标服务层门控：宿主声明插槽时不挂 DOM 观察器，未声明时挂载兜底', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  const start = client.indexOf('const NAV_ICON_MARKER')
  const end = client.indexOf('function ImNavIcon', start)
  assert.ok(start >= 0 && end > start, '必须能提取导航图标初始化闭包')
  const code = client.slice(start, end)

  const createHarness = (slotsSpec) => {
    const tracker = { effectCount: 0, effectLabel: '' }
    const ctx = {
      slots: slotsSpec,
      effect: (fn, label) => {
        tracker.effectCount++
        tracker.effectLabel = label
      },
    }
    const document = {
      getElementById: () => null,
      createElement: () => ({ setAttribute() {} }),
      head: { appendChild() {} },
      querySelectorAll: () => [],
      documentElement: {},
    }
    class MockMutationObserver {
      observe() {}
      disconnect() {}
    }
    const runner = new Function(
      'ctx', 't', 'document', 'MutationObserver', 'queueMicrotask', 'tracker',
      `${code}; return { hasIconSlot, tracker };`
    )
    return runner(ctx, key => key, document, MockMutationObserver, () => {}, tracker)
  }

  // 1. 老宿主（无 specDynamic，也无 spec）：探不到插槽，挂载 DOM 补丁
  const oldHost1 = createHarness({})
  assert.equal(oldHost1.hasIconSlot, false)
  assert.equal(oldHost1.tracker.effectCount, 1, '老宿主下必须挂载 DOM 补丁 effect')
  assert.equal(oldHost1.tracker.effectLabel, 'im-connect: settings nav icon')

  // 2. 老宿主返回 null（防御性硬化测试）：仍然挂载 DOM 补丁
  const oldHost2 = createHarness({
    specDynamic: () => null,
    spec: () => null,
  })
  assert.equal(oldHost2.hasIconSlot, false)
  assert.equal(oldHost2.tracker.effectCount, 1, '返回 null 时也必须视为老宿主并挂载兜底')

  // 3. 新宿主（真实公开面只有 spec，声明了 settings.section.icon）：不挂载 DOM 补丁
  const newHost = createHarness({
    spec: (name) => name === 'settings.section.icon' ? { kind: 'list' } : undefined,
  })
  assert.equal(newHost.hasIconSlot, true)
  assert.equal(newHost.tracker.effectCount, 0, '新宿主声明插槽时坚决不挂载 DOM 观察器')

  // 4. 向前兼容：将来若宿主把 specDynamic 提到公开面，也要识别
  const newHostWide = createHarness({
    specDynamic: (name) => name === 'settings.section.icon' ? { kind: 'list' } : undefined,
  })
  assert.equal(newHostWide.hasIconSlot, true)
  assert.equal(newHostWide.tracker.effectCount, 0, 'specDynamic 形式命中也必须跳过 DOM 观察器')

  // 5. 其它槽位有声明不等于本插件槽位有声明
  const otherSlotOnly = createHarness({
    spec: (name) => name === 'settings.section' ? { kind: 'list' } : undefined,
  })
  assert.equal(otherSlotOnly.hasIconSlot, false, '不得因为别的槽位存在就跳过图标兜底')
  assert.equal(otherSlotOnly.tracker.effectCount, 1)
})

test('图标插槽注册随入口位置启停，声明撤销时自清理且注册失败不带崩宿主', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  const start = client.indexOf('function installSettingsIconSlot')
  const end = client.indexOf('let unregSettings', start)
  assert.ok(start >= 0 && end > start, '必须能提取图标插槽注册函数')
  const factory = new Function('IM_LOCALE_NS', `${client.slice(start, end)}; return installSettingsIconSlot;`)('im-assistant')

  const makeController = () => {
    const state = { enabled: true }
    const taps = new Set()
    return {
      state,
      taps,
      controller: {
        isSettingsSectionEnabled: () => state.enabled,
        onLocationChange(fn) {
          taps.add(fn)
          return () => { taps.delete(fn) }
        },
      },
      fire() { for (const fn of [...taps]) fn() },
    }
  }

  // 1. 声明后：注册；切 sidebar：注销；切回：重新注册；撤销声明：摘监听 + 注销
  const registered = []
  const disposed = []
  let injectCallback = null
  const ctx = {
    slots: {
      inject(name, callback) {
        injectCallback = callback
        return () => {}
      },
      register(options) {
        registered.push(options)
        return () => { disposed.push(options.id) }
      },
    },
  }
  const host = makeController()
  factory(ctx, host.controller, () => null)
  assert.equal(typeof injectCallback, 'function', '必须注册 settings.section.icon 的 inject 回调')
  assert.equal(registered.length, 0, '槽位声明之前不得注册图标')

  const dispose = injectCallback()
  assert.equal(registered.length, 1, '槽位声明后必须注册图标')
  assert.equal(registered[0].name, 'settings.section.icon')
  assert.equal(registered[0].id, 'im-assistant', '注册 id 必须等于 settings.section 的 id')

  host.state.enabled = false
  host.fire()
  assert.equal(disposed.length, 1, '入口位置改成仅侧栏时必须注销图标')

  host.state.enabled = true
  host.fire()
  assert.equal(registered.length, 2, '切回设置入口时必须重新注册图标')

  dispose()
  assert.equal(host.taps.size, 0, '声明撤销时必须摘掉入口位置监听')
  assert.equal(disposed.length, 2, '声明撤销时必须注销图标')

  // 2. 注册抛错：必须被吞掉（不能带崩宿主 settings 壳的注册流程），且下次位置变化可重试
  let attempts = 0
  let injected = null
  const ctxFailing = {
    slots: {
      inject(name, callback) { injected = callback },
      register() {
        attempts += 1
        if (attempts === 1) throw new Error('duplicate id')
        return () => {}
      },
    },
  }
  const host2 = makeController()
  factory(ctxFailing, host2.controller, () => null)
  const dispose2 = injected()
  assert.equal(attempts, 1, '注册失败必须被吞掉而不是抛给宿主')
  host2.state.enabled = false
  host2.fire()
  host2.state.enabled = true
  host2.fire()
  assert.equal(attempts, 2, '失败后必须在下次位置变化时重试注册')
  dispose2()
})

test('设置页账号行和账号设置都能填写名称备注', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /"account\.remark": "名称备注"/)
  assert.match(client, /"account\.remark": "Name remark"/)
  assert.match(client, /"account\.remarkNote": "只在本机设置页区分账号，留空恢复自动名称。"/)
  assert.match(client, /"account\.remarkNote": "Shown only in settings to tell accounts apart\. Leave blank to restore the automatic name\."/)
  assert.match(client, /\["账号备注不能超过 40 个字符", "server\.remarkTooLong"\]/)
  assert.match(client, /\["账号备注不能包含换行或控制字符", "server\.remarkControl"\]/)
  const accountPage = client.slice(client.indexOf('function AccountInspector'), client.indexOf('const CHANNEL_WORKSPACE_PREFIX'))
  assert.match(accountPage, /function AccountRemarkEditor/)
  assert.match(accountPage, /t\("account\.remark"\)/)
  assert.match(accountPage, /t\("account\.rename"\)/)
  assert.match(accountPage, /maxLength: 40/)
  assert.match(accountPage, /onAction\(account\.id, "settings", \{ name \}\)/)
  assert.match(accountPage, /save\(\{ name \}\)/)
  assert.doesNotMatch(accountPage, /名称备注|留空恢复自动名称/)
})

test('账号页渠道行与账号行用网格对齐，表单单列', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /className: "ima-platform-meta"/)
  assert.match(client, /\.ima-platform-head\{display:grid;grid-template-columns:auto minmax\(0,1fr\) auto/)
  assert.match(client, /\.ima-account-row\{display:grid;grid-template-columns:minmax\(0,1fr\) auto auto auto/)
  assert.match(client, /\.ima-account-settings\{display:grid;grid-template-columns:repeat\(2,minmax\(0,1fr\)\);gap:14px 16px/)
  assert.match(client, /\.ima-account-settings\.compact\{grid-template-columns:1fr\}/)
  assert.match(client, /h\(Button, \{ onClick: \(e\) => \{ e\.stopPropagation\(\); setEditing\(ch\.id\); \}/)
  assert.match(client, /h\(Button, \{ onClick: \(\) => \{ selectAccount\(account\.id\); setSettingsAccount\(account\.id\); \}/)
  assert.match(client, /variant: mappedVariant/);
  assert.match(client, /function isHostComponent\(component\)/);
  assert.match(client, /typeof component\.render === "function"/);
  assert.doesNotMatch(client, /typeof PrimitiveButton === "function"/, '宿主 Button 是 forwardRef 对象，不能只用 typeof function 判断');
  assert.match(client, /PrimitiveButton/);
  assert.match(client, /className: "ima-model-effort"/)
  assert.match(client, /\.ima-model-effort\{display:grid;grid-template-columns:1fr 1fr/)
  assert.doesNotMatch(client, /field\("workspace",[\s\S]*?\}\), true\)/)
  assert.match(client, /ctx\.locale\.bind\("settings\.agentPreset"\)/)
  assert.match(client, /presetT\("nav"\)/)
  assert.match(client, /presetStandardName/)
})

test('账号命令权限沿用旧版两列下拉，控件换成 Ant Select', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  const command = client.slice(client.indexOf('function CommandPermissionSettings'), client.indexOf('function AccountConnectionCheck'))
  assert.match(command, /className: "ima-command-permissions ima-account-settings"/)
  assert.match(command, /h\(Select, \{/)
  assert.match(command, /t\("command\.enabled"\)/)
  assert.match(command, /t\("command\.disabled"\)/)
  assert.doesNotMatch(command, /h\(Switch/)
})

test('IM 模型菜单只使用适配器声明的模型与推理等级', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  const manager = readFileSync(new URL('../src/manager.ts', import.meta.url), 'utf8')
  assert.doesNotMatch(client, /DEFAULT_EFFORTS/, '不能在客户端伪造 Low、Medium、High')
  assert.match(client, /const modelGroups = providers\.map/)
  assert.match(client, /reasoning && field\("effort", modelT\("menu\.effort"\)/)
  assert.match(client, /modelT\("empty\.models"\)/)
  assert.match(client, /reasoning\.defaultEffort \? \[\] : \[\{ id: "", name: modelT\("effort\.providerDefault"\) \}\]/)
  assert.match(manager, /resolveModelInfo\?/)
  assert.match(manager, /resolved\.reasoning\.efforts\.map/)
})

test('思考强度空值和 none 视为未设置', () => {
  assert.equal(normalizeEffort('high'), 'high')
  assert.equal(normalizeEffort(' none '), undefined)
  assert.equal(normalizeEffort('default'), undefined)
  assert.deepEqual(
    normalizeAssistantModel({ provider: 'deepseek', model: 'v4', reasoningEffort: 'high' }),
    { provider: 'deepseek', model: 'v4', reasoningEffort: 'high' },
  )
})
test('权限默认值直接取 Host 官方默认预设', () => {
  const index = readFileSync(new URL('../src/index.ts', import.meta.url), 'utf8')
  assert.match(index, /permissionPreset: permissionPresets\.defaultPreset/)
  assert.match(index, /'permissionPresets'/)
})

test('助手多字段配置先完整校验，失败时不部分切换模型', (t) => {
  const manager = makeManager(t)
  const result = manager.setAssistant({
    provider: 'next-provider',
    model: 'next-model',
    cwd: '   ',
  })
  assert.deepEqual(result, { ok: false, error: '请选择工作区' })
  assert.deepEqual(manager.currentAssistant(), { provider: 'initial-provider', model: 'initial-model' })
  assert.equal(manager.currentWorkspace().includes('im-connect-assistant-'), true)
})

test('助手多字段配置全部合法时一次保存完整结果', (t) => {
  const manager = makeManager(t)
  const result = manager.setAssistant({
    provider: 'next-provider',
    model: 'next-model',
    cwd: ' D:\\repo\\next ',
    permission: 'workspace-write',
  })
  assert.equal(result.ok, true)
  assert.deepEqual(result.assistant, { provider: 'next-provider', model: 'next-model' })
  assert.equal(result.cwd, 'D:\\repo\\next')
  assert.equal(result.permission, 'workspace-write')
})

test('账号推理等级省略时保留，显式传 null 时清空', async (t) => {
  const manager = makeManager(t)
  manager.startOne = async () => undefined
  const created = await manager.connect('telegram', { token: 'reasoning-token' }, {
    provider: 'reasoning-provider',
    model: 'reasoning-model',
    reasoningEffort: 'high',
    cwd: 'D:\\repo\\reasoning',
    permission: 'review',
    privateAccess: 'approved',
  })

  const preserved = await manager.updateAccount(created.accountId, {
    provider: 'next-provider',
    model: 'next-reasoning-model',
  })
  assert.equal(preserved.account.assistant.reasoningEffort, 'high')

  const cleared = await manager.updateAccount(created.accountId, {
    provider: 'local-provider',
    model: 'local-model',
    reasoningEffort: null,
  })
  assert.deepEqual(cleared.account.assistant, {
    provider: 'local-provider',
    model: 'local-model',
  })
})

test('账号修改工作区时等待旧会话重置完成再返回保存成功', async (t) => {
  const descriptor = Object.getOwnPropertyDescriptor(process, 'platform')
  Object.defineProperty(process, 'platform', { ...descriptor, value: 'win32' })
  t.after(() => Object.defineProperty(process, 'platform', descriptor))

  const manager = makeManager(t)
  manager.startOne = async () => undefined
  const created = await manager.connect('telegram', { token: 'workspace-token' }, {
    provider: 'workspace-provider',
    model: 'workspace-model',
    cwd: 'D:\\repo\\old',
    permission: 'review',
    privateAccess: 'approved',
  })
  let releaseReset
  const resetGate = new Promise((resolve) => { releaseReset = resolve })
  const reloads = []
  manager.engine.reloadChannel = async (accountId, options) => {
    reloads.push({ accountId, options })
    await resetGate
  }

  let settled = false
  const updating = manager.updateAccount(created.accountId, { cwd: 'D:\\repo\\new' })
    .then((result) => {
      settled = true
      return result
    })
  await new Promise((resolve) => setImmediate(resolve))

  assert.equal(settled, false)
  assert.deepEqual(reloads, [{ accountId: created.accountId, options: { resetSessions: true } }])
  releaseReset()
  const result = await updating
  assert.equal(result.ok, true)
  assert.equal(result.account.cwd, 'D:\\repo\\new')
  const persisted = JSON.parse(readFileSync(manager.file, 'utf8'))
  assert.equal(persisted.channels[created.accountId].cwd, 'D:\\repo\\new')

  reloads.length = 0
  manager.engine.reloadChannel = async (accountId, options) => { reloads.push({ accountId, options }) }
  await manager.updateAccount(created.accountId, { cwd: 'd:/repo/new/' })
  assert.deepEqual(reloads, [])
})

test('Linux 工作区路径大小写变化必须重置旧会话', async (t) => {
  const descriptor = Object.getOwnPropertyDescriptor(process, 'platform')
  Object.defineProperty(process, 'platform', { ...descriptor, value: 'linux' })
  t.after(() => Object.defineProperty(process, 'platform', descriptor))

  const manager = makeManager(t)
  manager.startOne = async () => undefined
  const created = await manager.connect('telegram', { token: 'linux-workspace-token' }, {
    provider: 'workspace-provider',
    model: 'workspace-model',
    cwd: '/srv/Repo',
    permission: 'review',
    privateAccess: 'approved',
  })
  const reloads = []
  manager.engine.reloadChannel = async (accountId, options) => { reloads.push({ accountId, options }) }

  await manager.updateAccount(created.accountId, { cwd: '/srv/repo' })

  assert.deepEqual(reloads, [{ accountId: created.accountId, options: { resetSessions: true } }])
})

test('只修改账号名称或私聊策略不重载会话', async (t) => {
  const manager = makeManager(t)
  manager.startOne = async () => undefined
  const created = await manager.connect('telegram', { token: 'metadata-only-token' }, {
    provider: 'workspace-provider',
    model: 'workspace-model',
    cwd: 'D:\\repo\\metadata',
    permission: 'review',
    privateAccess: 'approved',
  })
  const reloads = []
  manager.engine.reloadChannel = async (accountId, options) => { reloads.push({ accountId, options }) }

  const result = await manager.updateAccount(created.accountId, {
    name: '新名称',
    privateAccess: 'all',
  })

  assert.equal(result.ok, true)
  assert.equal(result.account.name, '新名称')
  assert.equal(result.account.privateAccess, 'all')
  assert.deepEqual(reloads, [])
})

test('清空账号备注后恢复原来的自动序号，不按当前账号数重编', async (t) => {
  const manager = makeManager(t)
  manager.startOne = async () => undefined
  const settings = {
    provider: 'deepseek',
    model: 'deepseek-chat',
    cwd: 'D:/repo/remark',
    permission: 'review',
    privateAccess: 'approved',
  }
  const created = []
  for (let index = 1; index <= 4; index += 1) {
    const result = await manager.connect('weixin', { allowedUserId: `wx-user-${index}`, bound: '1' }, settings)
    assert.equal(result.ok, true, result.error)
    created.push(result.accountId)
  }

  const renamed = await manager.updateAccount(created[1], { name: '  华东销售-王敏  ' })
  assert.equal(renamed.ok, true)
  assert.equal(renamed.account.name, '华东销售-王敏')
  assert.equal(renamed.account.autoName, false)
  assert.equal(renamed.account.nameOrdinal, 2)
  const persisted = JSON.parse(readFileSync(manager.file, 'utf8'))
  assert.equal(persisted.channels[created[1]].nameOrdinal, 2)

  const extra = await manager.connect('weixin', { allowedUserId: 'wx-user-5', bound: '1' }, settings)
  assert.equal(extra.ok, true, extra.error)
  const cleared = await manager.updateAccount(created[1], { name: '   ' })
  assert.equal(cleared.ok, true)
  assert.equal(cleared.account.name, '微信账号 2')
  assert.equal(cleared.account.autoName, true)
  assert.equal(cleared.account.nameOrdinal, 2)
  const accounts = manager.list().find((item) => item.id === 'weixin').accounts
  assert.equal(accounts.find((item) => item.id === created[0]).name, '微信账号 1')
  assert.equal(accounts.find((item) => item.id === extra.accountId).name, '微信账号 5')
})

test('过长或含控制字符的账号备注会被拒绝，原名称不变', async (t) => {
  const manager = makeManager(t)
  manager.startOne = async () => undefined
  const created = await manager.connect('weixin', { allowedUserId: 'wx-remark-limit', bound: '1' }, {
    provider: 'deepseek',
    model: 'deepseek-chat',
    cwd: 'D:/repo/remark-limit',
    permission: 'review',
    privateAccess: 'approved',
  })
  assert.equal(created.ok, true, created.error)

  const tooLong = await manager.updateAccount(created.accountId, { name: '名'.repeat(41) })
  assert.equal(tooLong.ok, false)
  assert.match(tooLong.error, /40/)
  const newline = await manager.updateAccount(created.accountId, { name: '王敏\n客服' })
  assert.equal(newline.ok, false)
  const kept = manager.list().find((item) => item.id === 'weixin').accounts[0]
  assert.equal(kept.name, '微信账号 1')
  assert.equal(kept.autoName, true)

  const accepted = await manager.updateAccount(created.accountId, { name: '名'.repeat(40) })
  assert.equal(accepted.ok, true)
  assert.equal(accepted.account.name, '名'.repeat(40))
  assert.equal(accepted.account.autoName, false)
})

test('启动时清理旧版本为无推理模型残留的推理等级', async (t) => {
  const manager = makeManager(t, {
    get: (name) => name === 'llm'
      ? { resolveModelInfo: async () => ({ description: 'local model' }) }
      : undefined,
  })
  manager.startOne = async () => undefined
  const created = await manager.connect('telegram', { token: 'legacy-reasoning-token' }, {
    provider: 'local-provider',
    model: 'local-model',
    reasoningEffort: 'high',
    cwd: 'D:\\repo\\local',
    permission: 'review',
    privateAccess: 'approved',
  })

  await manager.initEnabled()

  const account = manager.list()
    .flatMap((channel) => channel.accounts)
    .find((item) => item.id === created.accountId)
  assert.deepEqual(account.assistant, {
    provider: 'local-provider',
    model: 'local-model',
  })
})

test('重复凭据复用账号，Telegram 更换 token 会明确标记新身份', async (t) => {
  const manager = makeManager(t)
  manager.startOne = async () => undefined
  const settings = {
    provider: 'deepseek',
    model: 'deepseek-chat',
    cwd: 'D:\\repo\\telegram',
    permission: 'review',
    privateAccess: 'approved',
  }

  const first = await manager.connect('telegram', { token: 'token-a' }, settings)
  const repeated = await manager.connect('telegram', { token: 'token-a' }, settings)
  const rotated = await manager.connect('telegram', { token: 'token-b' }, settings)

  assert.equal(first.ok, true)
  assert.equal(first.created, true)
  assert.equal(first.newIdentity, false)
  assert.equal(repeated.accountId, first.accountId)
  assert.equal(repeated.created, false)
  assert.equal(rotated.created, true)
  assert.equal(rotated.newIdentity, true)
  assert.notEqual(rotated.accountId, first.accountId)
  const custom = await manager.connect('telegram', { token: 'token-c' }, { ...settings, name: 'Ops bot' })
  const accounts = manager.list().find((item) => item.id === 'telegram').accounts
  assert.equal(accounts.length, 3)
  assert.equal(accounts[0].autoName, true)
  assert.equal(accounts[0].nameOrdinal, 1)
  assert.equal(accounts[1].autoName, true)
  assert.equal(accounts[1].nameOrdinal, 2)
  assert.equal(accounts.find((account) => account.id === custom.accountId).name, 'Ops bot')
  assert.equal(accounts.find((account) => account.id === custom.accountId).autoName, false)
  assert.equal(accounts.find((account) => account.id === custom.accountId).nameOrdinal, 3)
  assert.equal(manager.approve('telegram', 'ambiguous-user'), false)
  assert.equal(manager.approve(first.accountId, 'approved-user'), true)
})


test('账号命令权限整组校验保存，失败不改变原有准入与权限', async t => {
  const manager = makeManager(t)
  manager.startOne = async () => undefined
  const created = await manager.connect('telegram', { token: 'command-policy-test' }, { privateAccess: 'approved' })
  const commandPermissions = { dm: { enabled: false, users: [{ userId: 'owner', enabled: true }] }, group: { enabled: true, users: [] } }
  const saved = await manager.updateAccount(created.accountId, { commandPermissions })
  assert.equal(saved.ok, true)
  assert.deepEqual(saved.account.commandPermissions, commandPermissions)
  assert.equal(saved.account.privateAccess, 'approved')
  const failed = await manager.updateAccount(created.accountId, { privateAccess: 'all', commandPermissions: null })
  assert.equal(failed.ok, false)
  const preserved = await manager.updateAccount(created.accountId, { name: 'renamed' })
  assert.deepEqual(preserved.account.commandPermissions, commandPermissions)
  assert.equal(preserved.account.privateAccess, 'approved')
})

test('账号发送方式默认排队，可切换插话并按账号持久化，未知值回落排队', async t => {
  const manager = makeManager(t)
  manager.startOne = async () => undefined
  const created = await manager.connect('telegram', { token: 'send-mode-token' }, {
    provider: 'send-mode-provider',
    model: 'send-mode-model',
    cwd: 'D:\\repo\\send-mode',
    permission: 'review',
  })
  assert.equal(created.ok, true, created.error)
  assert.equal(accountOf(manager, created.accountId).sendMode, 'queue', '省略发送方式时默认排队发送')

  const steered = await manager.updateAccount(created.accountId, { sendMode: 'steer' })
  assert.equal(steered.ok, true)
  assert.equal(steered.account.sendMode, 'steer')
  const persisted = JSON.parse(readFileSync(manager.file, 'utf8'))
  assert.equal(persisted.channels[created.accountId].sendMode, 'steer')

  const invalid = await manager.updateAccount(created.accountId, { sendMode: 'auto' })
  assert.equal(invalid.ok, true)
  assert.equal(invalid.account.sendMode, 'queue', '未知值必须回落为排队发送')

  // 省略字段的后续保存保留当前值，与私聊准入一致。
  const preserved = await manager.updateAccount(created.accountId, { sendMode: 'steer' })
  assert.equal(preserved.account.sendMode, 'steer')
  const untouched = await manager.updateAccount(created.accountId, { name: 'send-mode-renamed' })
  assert.equal(untouched.account.sendMode, 'steer')
})

test('账号分段回复默认关闭，可开关并按账号持久化，省略字段保留', async t => {
  const manager = makeManager(t)
  manager.startOne = async () => undefined
  const created = await manager.connect('qq', { appId: 'segmented-app', appSecret: 'segmented-secret' }, {
    provider: 'segmented-provider',
    model: 'segmented-model',
    cwd: 'D:\\repo\\segmented',
    permission: 'review',
  })
  assert.equal(created.ok, true, created.error)
  assert.equal(accountOf(manager, created.accountId).segmentReplySupported, true, 'QQ 已开放分段回复')
  assert.equal(accountOf(manager, created.accountId).segmentReply, false, '插件级默认关闭')

  const enabled = await manager.updateAccount(created.accountId, { segmentReply: true })
  assert.equal(enabled.ok, true)
  assert.equal(enabled.account.segmentReply, true)
  const persisted = JSON.parse(readFileSync(manager.file, 'utf8'))
  assert.equal(persisted.channels[created.accountId].segmentReply, true)

  // 省略字段的后续保存保留当前开关状态。
  const untouched = await manager.updateAccount(created.accountId, { name: 'segmented-renamed' })
  assert.equal(untouched.account.segmentReply, true)

  const disabled = await manager.updateAccount(created.accountId, { segmentReply: false })
  assert.equal(disabled.account.segmentReply, false)
})

test('分段间隔区间可按账号保存，非法值与颠倒的上下界被纠正', async t => {
  const manager = makeManager(t)
  manager.startOne = async () => undefined
  const created = await manager.connect('telegram', { token: 'segment-gap-token' }, {
    provider: 'segment-gap-provider',
    model: 'segment-gap-model',
    cwd: 'D:\\repo\\segment-gap',
    permission: 'review',
  })
  assert.equal(created.ok, true, created.error)
  assert.equal(accountOf(manager, created.accountId).segmentDelayMinSecs, 1, '插件默认下界 1 秒')
  assert.equal(accountOf(manager, created.accountId).segmentDelayMaxSecs, 2, '插件默认上界 2 秒')

  const saved = await manager.updateAccount(created.accountId, { segmentDelayMinSecs: 2, segmentDelayMaxSecs: 4 })
  assert.equal(saved.ok, true)
  assert.equal(saved.account.segmentDelayMinSecs, 2)
  assert.equal(saved.account.segmentDelayMaxSecs, 4)
  const persisted = JSON.parse(readFileSync(manager.file, 'utf8'))
  assert.equal(persisted.channels[created.accountId].segmentDelayMaxSecs, 4)

  // 上下界颠倒时自动对调，保证下界不大于上界。
  const swapped = await manager.updateAccount(created.accountId, { segmentDelayMinSecs: 5, segmentDelayMaxSecs: 3 })
  assert.equal(swapped.account.segmentDelayMinSecs, 3)
  assert.equal(swapped.account.segmentDelayMaxSecs, 5)

  // 越界值夹到 0–60 秒并取整。
  const clamped = await manager.updateAccount(created.accountId, { segmentDelayMinSecs: -2, segmentDelayMaxSecs: 99 })
  assert.equal(clamped.account.segmentDelayMinSecs, 0)
  assert.equal(clamped.account.segmentDelayMaxSecs, 60)

  // 省略字段的后续保存保留区间。
  const untouched = await manager.updateAccount(created.accountId, { name: 'segment-gap-renamed' })
  assert.equal(untouched.account.segmentDelayMinSecs, 0)
  assert.equal(untouched.account.segmentDelayMaxSecs, 60)
})

test('账号空闲新开会话阈值可配置与持久化，缺省为 0（关闭）', async t => {
  const manager = makeManager(t)
  manager.startOne = async () => undefined
  const created = await manager.connect('telegram', { token: 'idle-account-token' }, {
    provider: 'idle-provider',
    model: 'idle-model',
    cwd: 'D:\
epo\\idle-test',
    permission: 'review',
  })
  assert.equal(created.ok, true, created.error)
  assert.equal(accountOf(manager, created.accountId).sessionIdleMinutes, 0, '账号未显式指定时默认关闭（0）')

  // 账号单独修改为 120 分钟
  const updated = await manager.updateAccount(created.accountId, { sessionIdleMinutes: 120 })
  assert.equal(updated.ok, true)
  assert.equal(updated.account.sessionIdleMinutes, 120)
  const persisted = JSON.parse(readFileSync(manager.file, 'utf8'))
  assert.equal(persisted.channels[created.accountId].sessionIdleMinutes, 120)

  // 账号修改为 0（关闭）
  const disabled = await manager.updateAccount(created.accountId, { sessionIdleMinutes: 0 })
  assert.equal(disabled.ok, true)
  assert.equal(disabled.account.sessionIdleMinutes, 0)

  // 负数与非法值纠正为 0
  const clamped = await manager.updateAccount(created.accountId, { sessionIdleMinutes: -10 })
  assert.equal(clamped.account.sessionIdleMinutes, 0)

  // 只修改其他属性时保留原 sessionIdleMinutes
  const renamed = await manager.updateAccount(created.accountId, { name: 'idle-renamed' })
  assert.equal(renamed.account.sessionIdleMinutes, 0)
})

test('插件级分段回复作为账号默认值，账号可单独关闭', async t => {
  const manager = makeManager(t, {}, { segmentReply: true })
  manager.startOne = async () => undefined
  const created = await manager.connect('qq', { appId: 'segmented-default-app', appSecret: 'segmented-default-secret' }, {
    provider: 'segmented-default-provider',
    model: 'segmented-default-model',
    cwd: 'D:\\repo\\segmented-default',
    permission: 'review',
  })
  assert.equal(created.ok, true, created.error)
  assert.equal(accountOf(manager, created.accountId).segmentReply, true)
  const disabled = await manager.updateAccount(created.accountId, { segmentReply: false })
  assert.equal(disabled.account.segmentReply, false)
})

test('未开放分段回复的渠道不展示开关，也不保存为开启', async t => {
  const manager = makeManager(t, {}, { segmentReply: true })
  manager.startOne = async () => undefined
  const created = await manager.connect('telegram', { token: 'segment-unsupported-token' }, {
    provider: 'segment-unsupported-provider',
    model: 'segment-unsupported-model',
    cwd: 'D:\\repo\\segment-unsupported',
    permission: 'review',
  })
  assert.equal(created.ok, true, created.error)
  const account = accountOf(manager, created.accountId)
  assert.equal(account.segmentReplySupported, false)
  assert.equal(account.segmentReply, false, '插件级默认也不会落到未验证渠道上')

  const saved = await manager.updateAccount(created.accountId, { segmentReply: true })
  assert.equal(saved.ok, true)
  assert.equal(saved.account.segmentReply, false)
  const persisted = JSON.parse(readFileSync(manager.file, 'utf8'))
  assert.equal(persisted.channels[created.accountId].segmentReply, false)
})

test('绑定时携带的发送方式随账号保存，只修改发送方式不重载会话', async t => {
  const manager = makeManager(t)
  manager.startOne = async () => undefined
  const created = await manager.connect('telegram', { token: 'send-mode-reload' }, {
    provider: 'send-mode-provider',
    model: 'send-mode-model',
    cwd: 'D:\\repo\\send-mode-reload',
    permission: 'review',
    sendMode: 'steer',
  })
  assert.equal(created.ok, true, created.error)
  assert.equal(accountOf(manager, created.accountId).sendMode, 'steer')
  const reloads = []
  manager.engine.reloadChannel = async (accountId, options) => { reloads.push({ accountId, options }) }

  const result = await manager.updateAccount(created.accountId, { sendMode: 'queue' })

  assert.equal(result.ok, true)
  assert.equal(result.account.sendMode, 'queue')
  assert.deepEqual(reloads, [], '发送方式按注入时机读取，不需要重载会话')
})

test('发送方式选择器有双语词条，保存请求带上所选值', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /"account\.sendMode": "发送方式"/)
  assert.match(client, /"account\.sendMode": "Send mode"/)
  assert.match(client, /"account\.sendQueue": "排队发送"/)
  assert.match(client, /"account\.sendSteer": "插话发送"/)
  assert.match(client, /"account\.sendQueue": "Queue"/)
  assert.match(client, /"account\.sendSteer": "Steer"/)
  assert.match(client, /"account\.sendSteerNote": "插话发送会把消息作为补充指令立即交给运行中的任务/)
  assert.match(client, /"account\.sendSteerNote": "Steer hands the message to the running task/)
  assert.match(client, /const sendMode = value\.sendMode === "steer" \? "steer" : "queue"/)
  assert.match(client, /field\("sendMode", t\("account\.sendMode"\)/)
  assert.match(client, /onChange: \(next\) => update\(\{ sendMode: next \}\)/)
  assert.match(client, /sendMode: next\.sendMode,/)
  assert.match(client, /account\.privateAccess, account\.sendMode,/)
  assert.match(client, /sendMode: "queue",/)
})

test('空闲新开会话选项放置在发送方式字段之后，具备预设与Tooltip提示', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /"account\.sessionIdle": "空闲新开会话"/)
  assert.match(client, /"account\.sessionIdle": "Idle session rotation"/)
  assert.match(client, /"account\.sessionIdleOff": "关闭（保持原会话）"/)
  assert.match(client, /"account\.sessionIdleOff": "Disabled \(keep session\)"/)
  assert.match(client, /"account\.sessionIdleNote": "距上一条消息超过该时间后再收到新消息/)
  assert.match(client, /"account\.sessionIdleNote": "Start a new session when the next message arrives/)
  // 严格校验字段排布顺序：sendMode 之后紧接着是 sessionIdle
  assert.match(client, /field\("sendMode"[\s\S]*?\)\),\s*field\("sessionIdle"/)
  assert.match(client, /field\("sessionIdle", sessionIdleLabel, h\(Select, \{/)
  assert.match(client, /h\(HostTooltip,\s*\{\s*label:\s*sessionIdleTip,\s*portal:\s*true/)
  assert.match(client, /onChange: \(next\) => update\(\{ sessionIdleMinutes: Number\(next\) \}\)/)
  assert.match(client, /sessionIdleMinutes: Number\.isFinite\(next\.sessionIdleMinutes\)/)
})

test('分段回复选择器使用 Select，首选项为「完整发送」，映射布尔状态', () => {
  const client = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
  assert.match(client, /"account\.segmentReply": "分段回复"/)
  assert.match(client, /"account\.segmentReply": "Segmented replies"/)
  assert.match(client, /"account\.segmentFull": "完整发送"/)
  assert.match(client, /"account\.segmentSplit": "分段发送"/)
  assert.match(client, /"account\.segmentFull": "Send as whole"/)
  assert.match(client, /"account\.segmentSplit": "Send in segments"/)
  assert.match(client, /field\("sendMode"[\s\S]*?\)\),\s*segmentSupported && field\("segmentReply"/)
  assert.match(client, /field\("segmentReply", segmentReplyLabel, h\(Select, \{/)
  assert.match(client, /h\(HostTooltip,\s*\{\s*label:\s*segmentReplyTip,\s*portal:\s*true/)
  assert.match(client, /IconInfoOutline/)
  assert.match(client, /t\("account\.segmentReplyNote"\)/)
  assert.doesNotMatch(client, /className: "ima-picker-note" \}, t\("account\.segmentReplyNote"\)/)
  assert.match(client, /value: segmentReply \? "segmented" : "full"/)
  assert.match(client, /\{ value: "full", label: t\("account\.segmentFull"\) \}/)
  assert.match(client, /\{ value: "segmented", label: t\("account\.segmentSplit"\) \}/)
  assert.match(client, /onChange: \(next\) => update\(\{ segmentReply: next === "segmented" \}\)/)
})
