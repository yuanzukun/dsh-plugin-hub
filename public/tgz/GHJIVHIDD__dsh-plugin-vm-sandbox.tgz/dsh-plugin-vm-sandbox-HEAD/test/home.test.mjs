// 单元测试:v0.5.0 — DSH 主目录改用 `$DSH_HOME`(与 @deepseek-ai/dsh-home-paths 一致)
//
// 回归目标:插件曾把状态目录硬编码为 `$HOME/.dsh/vm-sandbox`,忽略 DSH 自己
// 支持的 `$DSH_HOME` 覆盖,导致测试/便携主目录与真实安装共享并互相改写状态。
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'

const FAKE_HOME = mkdtempSync(join(tmpdir(), 'vmsb-home-'))
process.env.HOME = FAKE_HOME
delete process.env.DSH_HOME

const { __vmsb } = await import('../dsh-plugin-vm-sandbox/src/index.js')
const { resolveDshHome, STATE_DIR } = __vmsb

test('DSH_HOME 未设置时回退到 ~/.dsh(与历史行为一致)', () => {
  delete process.env.DSH_HOME
  assert.equal(resolveDshHome(), resolve(join(FAKE_HOME, '.dsh')))
})

test('DSH_HOME 为空或纯空白时视为未设置', () => {
  process.env.DSH_HOME = ''
  assert.equal(resolveDshHome(), resolve(join(FAKE_HOME, '.dsh')))
  process.env.DSH_HOME = '   '
  assert.equal(resolveDshHome(), resolve(join(FAKE_HOME, '.dsh')))
  delete process.env.DSH_HOME
})

test('DSH_HOME 为绝对路径时原样采用', () => {
  const custom = join(tmpdir(), 'vmsb-custom-home')
  process.env.DSH_HOME = custom
  assert.equal(resolveDshHome(), resolve(custom))
  delete process.env.DSH_HOME
})

test('DSH_HOME 以 ~ 开头时展开到当前 HOME', () => {
  process.env.DSH_HOME = '~/portable-dsh'
  assert.equal(resolveDshHome(), resolve(join(FAKE_HOME, 'portable-dsh')))
  process.env.DSH_HOME = '~'
  assert.equal(resolveDshHome(), resolve(FAKE_HOME))
  delete process.env.DSH_HOME
})

test('模块级 STATE_DIR 落在解析出的主目录下(默认 ~/.dsh/vm-sandbox)', () => {
  assert.equal(STATE_DIR, join(resolve(join(FAKE_HOME, '.dsh')), 'vm-sandbox'))
})
