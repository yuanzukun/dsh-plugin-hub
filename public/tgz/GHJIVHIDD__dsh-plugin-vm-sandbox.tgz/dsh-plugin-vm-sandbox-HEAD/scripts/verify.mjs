// Verify the VM sandbox plugin surface without starting DSH.
// It loads the real host module, registers all tools through the same plugin
// entry point, and asserts the required tool schemas/parameters exist.
import { execFileSync } from 'node:child_process'
import { existsSync, mkdtempSync, readFileSync, readdirSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const root = dirname(dirname(fileURLToPath(import.meta.url)))
// `src/` is the source of truth in a checkout; a published tarball ships only
// `lib/` (built by `prepare`), so fall back to it instead of failing.
const src = existsSync(join(root, 'dsh-plugin-vm-sandbox', 'src', 'index.js'))
  ? join(root, 'dsh-plugin-vm-sandbox', 'src', 'index.js')
  : join(root, 'dsh-plugin-vm-sandbox', 'lib', 'index.js')

// 纯结构校验:这一步只注册工具/路由,不应该碰任何真实状态。
// apply() 会读写状态目录,所以先把主目录指到临时目录 —— 否则 `npm run verify`
// 会在开发者机器(以及 dsh 导出了 $DSH_HOME 的环境)里创建/改写
// <DSH 主目录>/vm-sandbox/。必须在动态 import 之前改,模块在加载时解析路径。
const sandboxHome = mkdtempSync(join(tmpdir(), 'vmsb-verify-'))
process.env.HOME = sandboxHome
delete process.env.DSH_HOME
process.on('exit', () => {
  try { rmSync(sandboxHome, { recursive: true, force: true }) } catch (e) { /* best effort */ }
})

const { apply } = await import(pathToFileURL(src).href)

const toolsMap = {}
const tools = {
  register(tool) {
    toolsMap[tool.name] = tool
    return () => {}
  },
}
const webServer = {
  register() {
    return () => {}
  },
}
const ctx = {
  get(key) {
    if (key === 'tools') return tools
    if (key === 'webServer') return webServer
    return null
  },
  on() {},
  effect(fn, key) {
    // Do not start real interval sweeps during verification.
    if (key && (key.startsWith('vmsb: idle') || key.startsWith('vmsb: cron') || key.startsWith('vmsb: metrics'))) return
    return fn()
  },
}

apply(ctx)

const requiredTools = [
  'vm_list', 'vm_create', 'vm_exec', 'vm_delete',
  'vm_status', 'vm_start', 'vm_stop', 'vm_restart',
  'vm_snapshot', 'vm_snapshot_list', 'vm_restore', 'vm_snapshot_delete',
  'vm_upload', 'vm_download',
  'vm_port_forward', 'vm_port_forward_list', 'vm_port_forward_stop',
  'vm_job_submit', 'vm_job_list', 'vm_job_status', 'vm_job_stop', 'vm_job_output', 'vm_job_log',
  'vm_audit', 'vm_share', 'vm_unshare', 'vm_policy', 'vm_network',
  'vm_cron', 'vm_template', 'vm_resize', 'vm_metrics', 'vm_export', 'vm_import',
  'vm_service_discover', 'vm_service_register',
  'vm_harden', 'vm_secret', 'vm_alert',
  'vm_scp', 'vm_logs', 'vm_env', 'vm_withdraw', 'vm_queue', 'vm_report',
]

const missing = requiredTools.filter((name) => !toolsMap[name])
if (missing.length) {
  console.error('Missing tools:', missing.join(', '))
  process.exit(1)
}

const requiredParams = {
  vm_create: ['cpus', 'memory', 'disk', 'init_script', 'cloud_init', 'isolated', 'isolate_network', 'template', 'harden', 'queue'],
  vm_exec: ['machines', 'groups', 'strategy'],
  vm_snapshot: ['machine', 'note'],
  vm_restore: ['snapshot'],
  vm_snapshot_delete: ['snapshot'],
  vm_upload: ['local_path', 'remote_path'],
  vm_download: ['remote_path', 'local_path'],
  vm_port_forward: ['vm_port', 'host_port', 'bind_host'],
  vm_job_submit: ['command'],
  vm_job_status: ['job_id'],
  vm_job_log: ['job_id', 'operation', 'max_bytes'],
  vm_job_stop: ['job_id'],
  vm_audit: ['machine', 'operation', 'limit'],
  vm_share: ['machine', 'session', 'mode'],
  vm_network: ['public_access', 'internal_access', 'isolated', 'isolate_network'],
  vm_policy: ['max_machines', 'idle_sleep_minutes', 'idle_delete_days', 'snapshot_interval_hours', 'snapshot_retention', 'cpu_quota', 'memory_quota'],
  vm_cron: ['operation', 'machine', 'command', 'expr'],
  vm_template: ['operation', 'name', 'init_script', 'cloud_init'],
  vm_resize: ['machine', 'cpus', 'memory', 'disk'],
  vm_metrics: ['machine', 'limit'],
  vm_export: ['machine', 'output_path'],
  vm_import: ['machine', 'input_path'],
  vm_service_discover: ['machine'],
  vm_service_register: ['machine', 'service'],
  vm_network: ['public_access', 'internal_access', 'isolated', 'isolate_network', 'allowlist'],
  vm_harden: ['operation', 'machine'],
  vm_secret: ['operation', 'name', 'value'],
  vm_alert: ['operation', 'name', 'metric', 'op', 'value'],
  vm_scp: ['direction', 'machines', 'files', 'local_path', 'remote_path'],
  vm_logs: ['machine', 'job_id', 'limit', 'max_bytes'],
  vm_env: ['operation', 'name', 'value'],
  vm_withdraw: ['machine', 'keep_snapshot', 'note'],
  vm_queue: ['operation', 'queue_id'],
  vm_report: ['machine'],
}

const failures = []
for (const [toolName, params] of Object.entries(requiredParams)) {
  const tool = toolsMap[toolName]
  const props = tool && tool.parameters && tool.parameters.properties ? Object.keys(tool.parameters.properties) : []
  for (const p of params) {
    if (!props.includes(p)) failures.push(`${toolName}.${p}`)
  }
}

if (failures.length) {
  console.error('Missing tool parameters:', failures.join(', '))
  process.exit(1)
}

execFileSync(process.execPath, ['--check', src], { stdio: 'inherit' })
execFileSync(
  process.execPath,
  ['--check', existsSync(join(root, 'dsh-plugin-vm-sandbox', 'src', 'client.js'))
    ? join(root, 'dsh-plugin-vm-sandbox', 'src', 'client.js')
    : join(root, 'dsh-plugin-vm-sandbox', 'lib', 'client.js')],
  { stdio: 'inherit' },
)

// ---------- DSH 客户端模块图依赖(v0.5.0 回归闸门) ----------
// 背景:本插件的 `dsh.client.inject` 曾指向 @deepseek-ai/dsh-client-runtime。
// 该包在 0.1.1-rc.2 之后被移除;0.2.0-rc.2 的启动图里只有 66 个条目,没有它。
// `dsh-client-modules` 对解析不到的 inject 目标**静默跳过**,插件照常加载,
// 但声明的加载顺序保证已经失效 —— 这类退化不会报错,只会悄悄发生。
// 因此把「inject 目标必须真实存在」变成可执行断言。
const manifest = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))
/** 已从 DSH 中移除、不允许再出现在 inject / peerDependencies 里的包。 */
const REMOVED_DSH_PACKAGES = ['@deepseek-ai/dsh-client-runtime']
/** 提供 `slots` 服务的客户端入口包(0.2.0-rc.2 起由 ui-renderer 承担)。 */
const SLOTS_PROVIDER = '@deepseek-ai/dsh-client-ui-renderer'
/** `conversation.view` Slot 的宿主包。 */
const VIEW_HOST = '@deepseek-ai/dsh-client-ui-conversation'

const compatFailures = []
const clientInject = manifest?.dsh?.client?.inject
if (!Array.isArray(clientInject) || clientInject.length === 0 || clientInject.some((n) => typeof n !== 'string')) {
  compatFailures.push('package.json dsh.client.inject 必须是非空字符串数组')
} else {
  for (const name of clientInject) {
    if (REMOVED_DSH_PACKAGES.includes(name)) compatFailures.push(`dsh.client.inject 仍引用已移除的 ${name}`)
  }
  if (!clientInject.includes(SLOTS_PROVIDER)) compatFailures.push(`dsh.client.inject 缺少 slots 服务提供者 ${SLOTS_PROVIDER}`)
  if (!clientInject.includes(VIEW_HOST)) compatFailures.push(`dsh.client.inject 缺少 conversation.view 宿主 ${VIEW_HOST}`)
}

for (const name of REMOVED_DSH_PACKAGES) {
  if (Object.hasOwn(manifest.peerDependencies ?? {}, name)) compatFailures.push(`peerDependencies 仍引用已移除的 ${name}`)
}

// DSH 自身用 peerDependencies 做版本闸门(startswith '@deepseek-ai/dsh-'),
// 不满足时直接拒绝装载 bundle。这里要求闸门真实存在,而不是只写在注释里。
const peers = manifest.peerDependencies ?? {}
const gated = Object.keys(peers).filter((n) => n === '@deepseek-ai/dsh' || n.startsWith('@deepseek-ai/dsh-'))
if (gated.length === 0) compatFailures.push('peerDependencies 未声明任何 @deepseek-ai/dsh-* 版本闸门')
for (const [name, range] of Object.entries(peers)) {
  if (typeof range !== 'string' || range.trim() === '') compatFailures.push(`peerDependencies[${name}] 必须是版本范围字符串`)
}

// 当能定位到一个真实的 DSH 安装时,做完整核对:inject 目标存在、peer 版本满足。
// 用法:DSH_NODE_MODULES=<dsh>/node_modules npm run verify
const dshNodeModules = process.env.DSH_NODE_MODULES
if (compatFailures.length === 0 && dshNodeModules && existsSync(dshNodeModules)) {
  const appBoot = join(dshNodeModules, '@deepseek-ai', 'dsh-app-boot', 'lib', 'index.js')
  if (!existsSync(appBoot)) {
    compatFailures.push(`DSH_NODE_MODULES 下找不到 dsh-app-boot: ${appBoot}`)
  } else {
    for (const name of clientInject) {
      if (!existsSync(join(dshNodeModules, ...name.split('/')))) {
        compatFailures.push(`dsh.client.inject 的 ${name} 在 DSH 安装中不存在`)
      }
    }
    const { evaluatePluginCompatibility, pluginCompatibilityWarning } = await import(pathToFileURL(appBoot).href)
    const issue = evaluatePluginCompatibility(manifest)
    if (issue) compatFailures.push(pluginCompatibilityWarning(issue))
    else console.log(`[vm-sandbox] DSH 兼容性核对通过(${clientInject.length} 个客户端依赖 + ${gated.length} 个 peer 闸门)`)
  }
} else if (compatFailures.length === 0) {
  console.log('[vm-sandbox] 未设置 DSH_NODE_MODULES,跳过真实 DSH 安装核对(离线清单检查已通过)')
}

if (compatFailures.length) {
  console.error('DSH compatibility failures:\n  - ' + compatFailures.join('\n  - '))
  process.exit(1)
}

// ---------- 单元测试的主目录隔离 ----------
// 状态目录遵循 $DSH_HOME,而 `dsh` 本身就会把它导出给子进程。任何只隔离
// `process.env.HOME` 却不清除 `$DSH_HOME` 的测试,都会把 Vault/state 写到
// **真实**主目录 —— 静默污染用户数据,且测试自身仍然「通过」。
// 这里把这条约束变成硬性检查。
const testDir = join(root, 'test')
if (existsSync(testDir)) {
  const leaky = readdirSync(testDir)
    .filter((name) => name.endsWith('.test.mjs'))
    .filter((name) => {
      const body = readFileSync(join(testDir, name), 'utf8')
      return /\bprocess\.env\.HOME\s*=/.test(body) && !/delete\s+process\.env\.DSH_HOME/.test(body)
    })
  if (leaky.length) {
    console.error('测试隔离失败:以下测试覆盖了 HOME 但未清除 DSH_HOME,会写入真实主目录:\n  - ' + leaky.join('\n  - '))
    process.exit(1)
  }
}

console.log(`[vm-sandbox] verify OK: ${requiredTools.length} tools, host/client syntax, parameter schemas, DSH client graph`)
