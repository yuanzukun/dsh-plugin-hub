# Contributing

Thank you for improving `dsh-memory-graph`. Keep changes focused on the plugin: new behavior should use DeepSeek Harness extension points and must not require modifications to Harness itself.

## Development setup

```bash
git clone https://github.com/zmh2000829/dsh-memory-graph.git
cd dsh-memory-graph
npm ci
npm run check
```

To exercise a local checkout in DSH Web:

```bash
dsh plugin --profile web add "$PWD"
dsh web
```

## Pull requests

- Add focused tests for behavior changes.
- Keep schema upgrades monotonic and transactional.
- Preserve provenance for any data that becomes model-visible.
- Treat automatic recall and summarization as fail-open additions to the original Harness flow.
- Update both `README.md` and `README.zh-CN.md` when public behavior or configuration changes.
- Run `npm run check` and `npm pack --dry-run` before opening a pull request.

Do not commit API keys, conversation data, SQLite databases, JSONL backups, build output, or package archives.
