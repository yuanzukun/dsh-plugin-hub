/** Recoverable local outbox for transient SQLite memory writes. */

import { randomUUID } from 'node:crypto'
import { chmodSync, mkdirSync, readFileSync, readdirSync, renameSync, unlinkSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import type { MemoryGraphStore } from './store.ts'
import type { MemoryInput, SummaryCommitInput } from './types.ts'

type OutboxEntry =
  | { version: 1; type: 'remember'; createdAt: number; payload: MemoryInput }
  | { version: 1; type: 'commitSummary'; createdAt: number; payload: SummaryCommitInput }

/** Only transient storage failures are safe to replay without operator repair. */
export function isRetryableStoreError(error: unknown): boolean {
  const code = typeof error === 'object' && error !== null && 'code' in error ? String(error.code) : ''
  const message = error instanceof Error ? error.message : String(error)
  return /SQLITE_(BUSY|LOCKED|IOERR|FULL|CANTOPEN|PROTOCOL)/u.test(`${code} ${message}`)
}

/** Files are one operation each so a crash cannot corrupt the whole queue. */
export class MemoryOutbox {
  readonly deadLetterDirectory: string

  constructor(readonly directory: string) {
    this.deadLetterDirectory = join(directory, 'dead-letter')
    mkdirSync(this.directory, { recursive: true, mode: 0o700 })
    mkdirSync(this.deadLetterDirectory, { recursive: true, mode: 0o700 })
  }

  /** Persist a retryable operation atomically. */
  enqueue(entry: Omit<OutboxEntry, 'version' | 'createdAt'>): string {
    const stem = `${Date.now()}-${randomUUID()}`
    const temporary = join(this.directory, `.${stem}.tmp`)
    const target = join(this.directory, `${stem}.json`)
    const value = { version: 1, createdAt: Date.now(), ...entry } as OutboxEntry
    writeFileSync(temporary, `${JSON.stringify(value)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    renameSync(temporary, target)
    chmodSync(target, 0o600)
    return target
  }

  /** Replay in creation order; malformed or permanent entries become dead letters. */
  replay(store: MemoryGraphStore): { replayed: number; pending: number; deadLettered: number } {
    let replayed = 0
    let deadLettered = 0
    for (const file of this.files()) {
      const path = join(this.directory, file)
      try {
        const entry = JSON.parse(readFileSync(path, 'utf8')) as OutboxEntry
        if (entry.version !== 1 || (entry.type !== 'remember' && entry.type !== 'commitSummary')) {
          throw new Error('unsupported outbox entry')
        }
        if (entry.type === 'remember') store.remember(entry.payload)
        else store.commitSummary(entry.payload)
        unlinkSync(path)
        replayed++
      } catch (error: unknown) {
        if (isRetryableStoreError(error)) break
        renameSync(path, join(this.deadLetterDirectory, file))
        deadLettered++
      }
    }
    return { replayed, pending: this.files().length, deadLettered }
  }

  /** Number of operations still awaiting replay. */
  size(): number {
    return this.files().length
  }

  private files(): string[] {
    return readdirSync(this.directory).filter(file => /^\d+-.+\.json$/u.test(file)).sort()
  }
}
