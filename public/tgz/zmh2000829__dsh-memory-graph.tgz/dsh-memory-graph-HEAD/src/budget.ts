/** CJK-aware token budgeting for model-visible memory text. */

const CJK = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/u

/** Estimate model tokens conservatively without binding the plugin to one tokenizer. */
export function estimateTokens(value: string): number {
  let cjk = 0
  let other = 0
  for (const character of value) {
    if (CJK.test(character)) cjk++
    else other += character.length
  }
  return Math.ceil(cjk * 1.5 + other / 4)
}

/** Clip text to an estimated token budget and mark a clipped value with an ellipsis. */
export function clipTokens(value: string, maxTokens: number): { text: string; truncated: boolean } {
  if (estimateTokens(value) <= maxTokens) return { text: value, truncated: false }
  const characters = [...value]
  let low = 0
  let high = characters.length
  while (low < high) {
    const middle = Math.ceil((low + high) / 2)
    if (estimateTokens(`${characters.slice(0, middle).join('')}…`) <= maxTokens) low = middle
    else high = middle - 1
  }
  return { text: `${characters.slice(0, low).join('')}…`, truncated: true }
}
