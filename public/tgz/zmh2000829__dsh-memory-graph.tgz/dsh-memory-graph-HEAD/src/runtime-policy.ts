/** Per-session, one-turn memory policy selected from the DSH composer. */

export type TurnMemoryMode = 'default' | 'on' | 'off'

export interface TurnMemoryState {
  pendingMode: TurnMemoryMode
  active?: { turn: number; mode: Exclude<TurnMemoryMode, 'default'> | 'default' }
}

/** Latches a pending choice at turn start and consumes it after turn end. */
export class TurnMemoryPolicy {
  private readonly pending = new Map<string, TurnMemoryMode>()
  private readonly active = new Map<string, { turn: number; mode: TurnMemoryMode }>()
  private version = 0

  /** Stage the choice consumed by the next turn in one session. */
  set(sessionId: string, mode: TurnMemoryMode): void {
    if (mode === 'default') this.pending.delete(sessionId)
    else this.pending.set(sessionId, mode)
    this.version++
  }

  /** Freeze the pending mode for a concrete turn. */
  latch(sessionId: string, turn: number): TurnMemoryMode {
    const existing = this.active.get(sessionId)
    if (existing?.turn === turn) return existing.mode
    const mode = this.pending.get(sessionId) ?? 'default'
    this.pending.delete(sessionId)
    this.active.set(sessionId, { turn, mode })
    this.version++
    return mode
  }

  /** Resolve a feature's global default through the latched turn choice. */
  enabled(sessionId: string, turn: number, defaultEnabled: boolean): boolean {
    const mode = this.latch(sessionId, turn)
    return mode === 'default' ? defaultEnabled : mode === 'on'
  }

  /** Release one completed turn; the next turn starts from the global default. */
  finish(sessionId: string, turn: number): void {
    if (this.active.get(sessionId)?.turn !== turn) return
    this.active.delete(sessionId)
    this.version++
  }

  /** Browser-safe state for one session. */
  snapshot(sessionId: string): TurnMemoryState {
    const active = this.active.get(sessionId)
    return {
      pendingMode: this.pending.get(sessionId) ?? 'default',
      ...(active === undefined ? {} : { active: { ...active } }),
    }
  }

  /** Revision included in dashboard validators. */
  revision(): number {
    return this.version
  }
}
