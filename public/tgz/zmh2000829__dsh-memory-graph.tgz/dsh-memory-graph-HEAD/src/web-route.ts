/** Same-origin Web routes for the standalone memory dashboard. */

import type { IncomingHttpHeaders, IncomingMessage, ServerResponse } from 'node:http'
import type { MemoryGraphStore } from './store.ts'
import type { TurnMemoryMode, TurnMemoryPolicy } from './runtime-policy.ts'

export const VISUALIZATION_PATH = '/memory-graph/snapshot'
export const ACTION_PATH = '/memory-graph/action'

/** Browser dashboard settings returned with every graph snapshot. */
export interface VisualizationSettings {
  autoOpen: boolean
  refreshMs: number
  hops: number
  limit: number
  trustedHosts: readonly string[]
  token: string
  defaults: {
    autoRecall: boolean
    autoSummarize: boolean
    archiveTurns: boolean
    captureToolResults: boolean
    semanticEnabled: boolean
    semanticAvailable: () => boolean
    summaryLanguage: 'auto' | 'zh-CN' | 'en'
  }
  runtime: TurnMemoryPolicy
  outboxSize: () => number
}

interface RequestHeaders {
  headers: IncomingHttpHeaders
}

function header(headers: IncomingHttpHeaders, name: string): string | undefined {
  const value = headers[name]
  return typeof value === 'string' ? value : undefined
}

function authority(value: string): URL | undefined {
  try {
    return new URL(`http://${value}`)
  } catch {
    return undefined
  }
}

function loopback(hostname: string): boolean {
  const value = hostname.toLocaleLowerCase('en-US')
  if (value === 'localhost' || value.endsWith('.localhost') || value === '[::1]') return true
  const parts = value.split('.')
  return parts.length === 4 && parts[0] === '127' && parts.every(part => /^\d{1,3}$/.test(part))
}

/** Validate one explicit non-loopback authority at configuration load. */
export function validateTrustedHost(value: string): void {
  if (value.trim() !== value || value === '' || /[/@]/.test(value)) {
    throw new Error(`memory-graph: visualizationTrustedHosts entry ${JSON.stringify(value)} must be host or host:port`)
  }
  const parsed = authority(value)
  if (parsed === undefined || parsed.hostname === '') {
    throw new Error(`memory-graph: visualizationTrustedHosts entry ${JSON.stringify(value)} must be host or host:port`)
  }
}

/** Same-origin and Host fence for local memory reads. */
export function isTrustedVisualizationRequest(
  request: RequestHeaders,
  trustedHosts: readonly string[],
): boolean {
  const rawHost = header(request.headers, 'host')
  if (rawHost === undefined) return false
  const host = authority(rawHost)
  if (host === undefined) return false
  const allowed = loopback(host.hostname) || trustedHosts.some((entry) => {
    const trusted = authority(entry)
    if (trusted === undefined) return false
    return trusted.port === '' ? trusted.hostname === host.hostname : trusted.host === host.host
  })
  if (!allowed || header(request.headers, 'sec-fetch-site') === 'cross-site') return false
  const origin = header(request.headers, 'origin')
  if (origin === undefined) return true
  try {
    return new URL(origin).host === host.host
  } catch {
    return false
  }
}

function json(response: ServerResponse, status: number, body: unknown, headers: Record<string, string> = {}): void {
  const value = JSON.stringify(body)
  response.writeHead(status, {
    'cache-control': 'no-store',
    'content-type': 'application/json; charset=utf-8',
    'content-length': String(Buffer.byteLength(value)),
    'x-content-type-options': 'nosniff',
    ...headers,
  })
  response.end(value)
}

/** Create the GET-only response handler bound to one store and resolved policy. */
export function visualizationHandler(store: MemoryGraphStore, settings: VisualizationSettings) {
  return (request: IncomingMessage, response: ServerResponse): void => {
    if (request.method !== 'GET') {
      response.writeHead(405, { allow: 'GET' })
      response.end()
      return
    }
    if (!isTrustedVisualizationRequest(request, settings.trustedHosts)) {
      response.writeHead(403)
      response.end('forbidden')
      return
    }
    const url = new URL(request.url ?? VISUALIZATION_PATH, 'http://memory-graph.local')
    const sessionId = url.searchParams.get('sessionId')?.slice(0, 200)
    const etag = `${store.visualizationEtag().slice(0, -1)}-${settings.runtime.revision()}"`
    if (header(request.headers, 'if-none-match') === etag) {
      response.writeHead(304, {
        'cache-control': 'no-store',
        etag,
        'x-content-type-options': 'nosniff',
      })
      response.end()
      return
    }
    const body = JSON.stringify({
      graph: store.graph('', settings.hops, settings.limit),
      config: {
        autoOpen: settings.autoOpen,
        refreshMs: settings.refreshMs,
        ...settings.defaults,
        semanticAvailable: settings.defaults.semanticAvailable(),
        graphScope: 'profile',
        outboxPending: settings.outboxSize(),
        archiveStatus: store.archiveStatusCounts(),
        token: settings.token,
      },
      ...(sessionId === undefined ? {} : { runtime: settings.runtime.snapshot(sessionId) }),
    })
    response.writeHead(200, {
      'cache-control': 'no-store',
      'content-type': 'application/json; charset=utf-8',
      'content-length': Buffer.byteLength(body),
      etag,
      'x-content-type-options': 'nosniff',
    })
    response.end(body)
  }
}

function mode(value: unknown): TurnMemoryMode | undefined {
  return value === 'default' || value === 'on' || value === 'off' ? value : undefined
}

async function requestBody(request: IncomingMessage): Promise<unknown> {
  let body = ''
  for await (const chunk of request) {
    body += Buffer.isBuffer(chunk) ? chunk.toString('utf8') : String(chunk)
    if (Buffer.byteLength(body) > 8192) throw new Error('request body exceeds 8192 bytes')
  }
  return JSON.parse(body) as unknown
}

/** Same-origin mutation endpoint for explicit turn policy and confirmed deletion. */
export function actionHandler(store: MemoryGraphStore, settings: VisualizationSettings) {
  return async (request: IncomingMessage, response: ServerResponse): Promise<void> => {
    if (request.method !== 'POST') {
      response.writeHead(405, { allow: 'POST' })
      response.end()
      return
    }
    if (!isTrustedVisualizationRequest(request, settings.trustedHosts)
      || header(request.headers, 'x-memory-graph-token') !== settings.token
      || !header(request.headers, 'content-type')?.toLocaleLowerCase('en-US').startsWith('application/json')) {
      response.writeHead(403)
      response.end('forbidden')
      return
    }
    try {
      const body = await requestBody(request)
      if (typeof body !== 'object' || body === null || Array.isArray(body)) throw new Error('request must be an object')
      const record = body as Record<string, unknown>
      if (record.action === 'set-turn-mode') {
        if (typeof record.sessionId !== 'string' || record.sessionId.trim() === '' || record.sessionId.length > 200) {
          throw new Error('sessionId is invalid')
        }
        const selected = mode(record.mode)
        if (selected === undefined) throw new Error('mode is invalid')
        settings.runtime.set(record.sessionId, selected)
        json(response, 200, { ok: true, runtime: settings.runtime.snapshot(record.sessionId) })
        return
      }
      if (record.action === 'forget-memory') {
        if (typeof record.memoryId !== 'string' || record.memoryId.trim() === '' || record.memoryId.length > 100) {
          throw new Error('memoryId is invalid')
        }
        json(response, 200, { ok: true, deleted: store.forget(record.memoryId) })
        return
      }
      throw new Error('action is unsupported')
    } catch (error: unknown) {
      json(response, 400, { ok: false, error: error instanceof Error ? error.message : String(error) })
    }
  }
}
