/** Replay-safe interactive graph card for the memory_graph tool. */

import { useEffect, useMemo, useRef, useState } from 'react'
import type { CSSProperties, PointerEvent as ReactPointerEvent } from 'react'
import type { Context } from '@deepseek-ai/cordis'
import type { ToolCallViewProps } from '@deepseek-ai/dsh-client-ui-tool/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { GraphResult } from '../types.ts'

const SNAPSHOT_PATH = '/memory-graph/snapshot'
const ACTION_PATH = '/memory-graph/action'
const CLOSE_DASHBOARD_EVENT = 'dsh-memory-graph:close-dashboard'

interface DashboardSnapshot {
  graph: GraphResult
  config: {
    autoOpen: boolean
    refreshMs: number
    autoRecall: boolean
    autoSummarize: boolean
    archiveTurns: boolean
    captureToolResults: boolean
    semanticEnabled: boolean
    semanticAvailable: boolean
    summaryLanguage: 'auto' | 'zh-CN' | 'en'
    graphScope: 'profile'
    outboxPending: number
    archiveStatus: { pending: number; summarized: number; failed: number; archived: number }
    token: string
  }
  runtime?: {
    pendingMode: 'default' | 'on' | 'off'
    active?: { turn: number; mode: 'default' | 'on' | 'off' }
  }
}

interface DashboardReadResult {
  snapshot: DashboardSnapshot
  etag?: string
}

export type MemoryDefaultState = 'on' | 'off' | 'mixed'

/** Resolve the profile defaults into the status shown beside the composer. */
export function memoryDefaultState(config: Pick<DashboardSnapshot['config'], 'autoRecall' | 'autoSummarize' | 'archiveTurns'>): MemoryDefaultState {
  const values = [config.autoRecall, config.autoSummarize, config.archiveTurns]
  if (values.every(Boolean)) return 'on'
  if (values.every(value => !value)) return 'off'
  return 'mixed'
}

/** Describe how one durable memory category can affect a later answer. */
export function memoryImpact(kind: string): string {
  switch (kind.toLocaleLowerCase()) {
    case 'preference': return '影响回答风格与偏好'
    case 'constraint': return '相关任务中作为规则执行'
    case 'decision': return '保持先前决定一致'
    case 'fact': return '补充已知背景信息'
    case 'lesson': return '复用过去验证过的经验'
    case 'event': return '提供时间线与事件背景'
    default: return '在相关问题中补充上下文'
  }
}

type PositionedNode = GraphResult['nodes'][number] & {
  x: number
  y: number
  degree: number
}

function object(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function string(value: unknown): value is string {
  return typeof value === 'string'
}

function number(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value)
}

function archiveStatus(value: unknown): value is DashboardSnapshot['config']['archiveStatus'] {
  if (!object(value)) return false
  return ['pending', 'summarized', 'failed', 'archived'].every(key => number(value[key])
    && Number.isSafeInteger(value[key]) && value[key] >= 0)
}

/** Narrow persisted tool metadata before rendering a replayed graph. */
export function graphFromMeta(value: unknown): GraphResult | undefined {
  if (!object(value) || !Array.isArray(value.nodes) || !Array.isArray(value.edges)
    || !Array.isArray(value.memories) || !Array.isArray(value.summaries)) return undefined
  const nodes = value.nodes.filter(object)
  const edges = value.edges.filter(object)
  const memories = value.memories.filter(object)
  const summaries = value.summaries.filter(object)
  if (nodes.length !== value.nodes.length || edges.length !== value.edges.length
    || memories.length !== value.memories.length || summaries.length !== value.summaries.length) return undefined
  if (!nodes.every(node => string(node.id) && string(node.name) && string(node.kind) && number(node.distance))) return undefined
  if (!edges.every(edge => string(edge.source) && string(edge.predicate) && string(edge.target) && number(edge.confidence)
    && (edge.mentions === undefined || (number(edge.mentions) && Number.isSafeInteger(edge.mentions) && edge.mentions >= 1)))) return undefined
  if (!memories.every(memory => string(memory.id) && string(memory.content) && string(memory.kind)
    && number(memory.importance) && number(memory.confidence) && Array.isArray(memory.entities)
    && memory.entities.every(string))) return undefined
  if (!summaries.every(summary => string(summary.id) && string(summary.sessionId) && number(summary.turn)
    && string(summary.summary) && Array.isArray(summary.sourceEventSeqs)
    && summary.sourceEventSeqs.every(number) && string(summary.provider) && string(summary.model)
    && number(summary.createdAt))) return undefined
  return value as unknown as GraphResult
}

/** Validate the Host dashboard envelope separately from replayed tool metadata. */
export function dashboardSnapshot(value: unknown): DashboardSnapshot | undefined {
  if (!object(value) || !object(value.config)) return undefined
  const graph = graphFromMeta(value.graph)
  if (graph === undefined || typeof value.config.autoOpen !== 'boolean'
    || !number(value.config.refreshMs) || value.config.refreshMs < 1000
    || typeof value.config.autoRecall !== 'boolean' || typeof value.config.autoSummarize !== 'boolean'
    || typeof value.config.archiveTurns !== 'boolean' || typeof value.config.captureToolResults !== 'boolean'
    || typeof value.config.semanticEnabled !== 'boolean' || typeof value.config.semanticAvailable !== 'boolean'
    || (value.config.summaryLanguage !== 'auto' && value.config.summaryLanguage !== 'zh-CN' && value.config.summaryLanguage !== 'en')
    || value.config.graphScope !== 'profile'
    || !number(value.config.outboxPending) || !Number.isSafeInteger(value.config.outboxPending)
    || !archiveStatus(value.config.archiveStatus)
    || !string(value.config.token)) return undefined
  let runtime: DashboardSnapshot['runtime']
  if (value.runtime !== undefined) {
    if (!object(value.runtime) || (value.runtime.pendingMode !== 'default' && value.runtime.pendingMode !== 'on'
      && value.runtime.pendingMode !== 'off')) return undefined
    runtime = { pendingMode: value.runtime.pendingMode }
    if (value.runtime.active !== undefined) {
      if (!object(value.runtime.active) || !number(value.runtime.active.turn)
        || (value.runtime.active.mode !== 'default' && value.runtime.active.mode !== 'on' && value.runtime.active.mode !== 'off')) return undefined
      runtime.active = { turn: value.runtime.active.turn, mode: value.runtime.active.mode }
    }
  }
  return { graph, config: value.config as unknown as DashboardSnapshot['config'], ...(runtime === undefined ? {} : { runtime }) }
}

async function readDashboard(etag?: string, sessionId?: string): Promise<DashboardReadResult | undefined> {
  const path = sessionId === undefined ? SNAPSHOT_PATH : `${SNAPSHOT_PATH}?sessionId=${encodeURIComponent(sessionId)}`
  const response = await fetch(path, {
    headers: { accept: 'application/json', ...(etag === undefined ? {} : { 'if-none-match': etag }) },
  })
  if (response.status === 304) return undefined
  if (!response.ok) throw new Error(`memory graph snapshot failed (${response.status})`)
  const snapshot = dashboardSnapshot(await response.json() as unknown)
  if (snapshot === undefined) throw new Error('memory graph snapshot is invalid')
  const responseEtag = response.headers.get('etag')
  return { snapshot, ...(responseEtag === null ? {} : { etag: responseEtag }) }
}

async function mutate(token: string, body: object): Promise<Record<string, unknown>> {
  const response = await fetch(ACTION_PATH, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-memory-graph-token': token },
    body: JSON.stringify(body),
  })
  const value = await response.json() as unknown
  if (!response.ok || !object(value) || value.ok !== true) {
    throw new Error(object(value) && string(value.error) ? value.error : `memory graph action failed (${response.status})`)
  }
  return value
}

function hash(value: string): number {
  let result = 2166136261
  for (const char of value) result = Math.imul(result ^ char.charCodeAt(0), 16777619)
  return result >>> 0
}

/** Deterministic bounded force layout; identical durable output replays identically. */
export function layoutGraph(graph: GraphResult, width = 900, height = 460): PositionedNode[] {
  const nodes = graph.nodes.slice(0, 100).map((node, index, all): PositionedNode => {
    const angle = ((hash(node.id) % 360) / 180) * Math.PI
    const ring = 75 + (index % Math.max(1, Math.ceil(Math.sqrt(all.length)))) * 26
    return { ...node, x: width / 2 + Math.cos(angle) * ring, y: height / 2 + Math.sin(angle) * ring, degree: 0 }
  })
  const byName = new Map(nodes.map(node => [node.name, node]))
  for (const edge of graph.edges) {
    const source = byName.get(edge.source)
    const target = byName.get(edge.target)
    if (source !== undefined) source.degree++
    if (target !== undefined) target.degree++
  }
  for (let iteration = 0; iteration < 90; iteration++) {
    const cooling = 1 - iteration / 100
    for (let left = 0; left < nodes.length; left++) {
      const a = nodes[left]
      if (a === undefined) continue
      for (let right = left + 1; right < nodes.length; right++) {
        const b = nodes[right]
        if (b === undefined) continue
        const dx = a.x - b.x || 0.01
        const dy = a.y - b.y || 0.01
        const distance2 = Math.max(100, dx * dx + dy * dy)
        const force = 850 / distance2 * cooling
        a.x += dx * force
        a.y += dy * force
        b.x -= dx * force
        b.y -= dy * force
      }
    }
    for (const edge of graph.edges) {
      const source = byName.get(edge.source)
      const target = byName.get(edge.target)
      if (source === undefined || target === undefined) continue
      const dx = target.x - source.x
      const dy = target.y - source.y
      const distance = Math.max(1, Math.hypot(dx, dy))
      const force = (distance - 115) * 0.018 * cooling
      source.x += dx / distance * force
      source.y += dy / distance * force
      target.x -= dx / distance * force
      target.y -= dy / distance * force
    }
    for (const node of nodes) {
      node.x += (width / 2 - node.x) * 0.009
      node.y += (height / 2 - node.y) * 0.009
      node.x = Math.min(width - 35, Math.max(35, node.x))
      node.y = Math.min(height - 35, Math.max(35, node.y))
    }
  }
  return nodes
}

const card: CSSProperties = {
  border: '1px solid color-mix(in srgb, currentColor 14%, transparent)', borderRadius: 12,
  overflow: 'hidden', background: 'color-mix(in srgb, Canvas 96%, #6d5dfc 4%)', color: 'CanvasText',
  font: '13px/1.45 ui-sans-serif, system-ui, sans-serif', margin: '6px 0',
}
const button: CSSProperties = {
  border: '1px solid color-mix(in srgb, currentColor 18%, transparent)', borderRadius: 7,
  background: 'color-mix(in srgb, Canvas 88%, currentColor 4%)', color: 'inherit', cursor: 'pointer', padding: '4px 9px',
}

function color(kind: string): string {
  const palette = ['#6d5dfc', '#0f9d8a', '#dd7a2b', '#cf4f7c', '#3687d8', '#8b6d43']
  return palette[hash(kind) % palette.length] ?? palette[0]!
}

function short(value: string, max = 110): string {
  return value.length <= max ? value : `${value.slice(0, max - 1)}…`
}

function GraphCard({ graph, onForget }: { graph: GraphResult; onForget?: (id: string) => void }) {
  const [expanded, setExpanded] = useState(false)
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState<string>()
  const [zoom, setZoom] = useState(1)
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const drag = useRef<{ x: number; y: number; panX: number; panY: number }>()
  const svgRef = useRef<SVGSVGElement>(null)
  const nodes = useMemo(() => layoutGraph(graph), [graph])
  const byName = useMemo(() => new Map(nodes.map(node => [node.name, node])), [nodes])
  const selectedNode = nodes.find(node => node.id === selected)
  const term = query.trim().toLocaleLowerCase()
  const matched = (value: string): boolean => term === '' || value.toLocaleLowerCase().includes(term)
  const related = selectedNode === undefined ? graph.memories : graph.memories.filter(memory => memory.entities.includes(selectedNode.name))
  const pointerDown = (event: ReactPointerEvent<SVGSVGElement>): void => {
    drag.current = { x: event.clientX, y: event.clientY, panX: pan.x, panY: pan.y }
    event.currentTarget.setPointerCapture(event.pointerId)
  }
  const pointerMove = (event: ReactPointerEvent<SVGSVGElement>): void => {
    if (drag.current === undefined) return
    setPan({ x: drag.current.panX + event.clientX - drag.current.x, y: drag.current.panY + event.clientY - drag.current.y })
  }
  useEffect(() => {
    const svg = svgRef.current
    if (svg === null) return undefined
    const wheel = (event: globalThis.WheelEvent): void => {
      event.preventDefault()
      event.stopPropagation()
      setZoom(current => Math.min(2.5, Math.max(0.45, current * (event.deltaY > 0 ? 0.9 : 1.1))))
    }
    svg.addEventListener('wheel', wheel, { passive: false })
    return () => { svg.removeEventListener('wheel', wheel) }
  }, [])
  return <section style={card} data-testid="memory-graph-card">
    <button type="button" onClick={() => setExpanded(value => !value)} style={{ ...button, width: '100%', border: 0, borderRadius: 0, padding: '10px 12px', textAlign: 'left', display: 'flex', gap: 10, alignItems: 'center' }}>
      <span style={{ color: '#6d5dfc', fontSize: 17 }}>⬡</span>
      <span style={{ flex: 1 }}><strong>知识图谱</strong> <small style={{ opacity: 0.58 }}>高级视图</small></span>
      <span style={{ opacity: 0.65 }}>{graph.nodes.length} nodes · {graph.edges.length} relations · {graph.memories.length} memories</span>
      <span>{expanded ? '▾' : '▸'}</span>
    </button>
    {expanded && <div style={{ borderTop: '1px solid color-mix(in srgb, currentColor 10%, transparent)' }}>
      <div style={{ padding: '8px 10px 0', opacity: 0.68, fontSize: 12 }}>
        它展示所有对话中“谁、什么、彼此有什么关系”，适合发现关联、重复或错误实体；它不是单轮对话流程图。节点 = 实体，连线 = 关系，×N = 有 N 条记忆支持。
      </div>
      <div style={{ padding: '8px 10px', display: 'flex', gap: 7, alignItems: 'center' }}>
        <input aria-label="Search graph" value={query} onChange={event => setQuery(event.target.value)} placeholder="Search entities or relations" style={{ ...button, cursor: 'text', flex: 1, minWidth: 120 }} />
        <button type="button" style={button} onClick={() => setZoom(value => Math.min(2.5, value * 1.2))}>＋</button>
        <button type="button" style={button} onClick={() => setZoom(value => Math.max(0.45, value / 1.2))}>－</button>
        <button type="button" style={button} onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }) }}>Reset</button>
      </div>
      {nodes.length === 0 ? <div style={{ padding: 24, textAlign: 'center', opacity: 0.65 }}>No graph data yet. Ask the agent to remember a durable fact.</div> : <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) minmax(190px, 28%)', minHeight: 350 }}>
        <svg ref={svgRef} role="img" aria-label="Interactive memory knowledge graph" viewBox="0 0 900 460" onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={() => { drag.current = undefined }} style={{ width: '100%', height: 390, touchAction: 'none', cursor: drag.current === undefined ? 'grab' : 'grabbing', background: 'radial-gradient(circle, color-mix(in srgb, currentColor 5%, transparent) 1px, transparent 1px)', backgroundSize: '18px 18px' }}>
          <g transform={`translate(${pan.x} ${pan.y}) scale(${zoom})`}>
            {graph.edges.map((edge, index) => {
              const source = byName.get(edge.source)
              const target = byName.get(edge.target)
              if (source === undefined || target === undefined) return null
              const visible = matched(edge.predicate) || matched(edge.source) || matched(edge.target)
              return <g key={`${edge.source}-${edge.predicate}-${edge.target}-${index}`} opacity={visible ? 0.72 : 0.1}>
                <line x1={source.x} y1={source.y} x2={target.x} y2={target.y} stroke="currentColor" strokeWidth={0.8 + edge.confidence} />
                {zoom >= 0.75 && <text x={(source.x + target.x) / 2} y={(source.y + target.y) / 2 - 4} fill="currentColor" fontSize="10" textAnchor="middle" style={{ paintOrder: 'stroke', stroke: 'Canvas', strokeWidth: 4 }}>{short(`${edge.predicate}${(edge.mentions ?? 1) > 1 ? ` ×${edge.mentions}` : ''}`, 24)}</text>}
              </g>
            })}
            {nodes.map(node => {
              const visible = matched(node.name) || graph.edges.some(edge => matched(edge.predicate) && (edge.source === node.name || edge.target === node.name))
              const radius = Math.min(20, 10 + node.degree * 1.7)
              return <g key={node.id} transform={`translate(${node.x} ${node.y})`} opacity={visible ? 1 : 0.13} onPointerDown={event => event.stopPropagation()} onClick={() => setSelected(node.id)} style={{ cursor: 'pointer' }}>
                <circle r={radius + (selected === node.id ? 4 : 0)} fill={color(node.kind)} stroke={selected === node.id ? 'currentColor' : 'Canvas'} strokeWidth={selected === node.id ? 2 : 1.5} />
                <text y={radius + 15} fill="currentColor" fontSize="11" textAnchor="middle" style={{ paintOrder: 'stroke', stroke: 'Canvas', strokeWidth: 4 }}>{short(node.name, 26)}</text>
              </g>
            })}
          </g>
        </svg>
        <aside style={{ borderLeft: '1px solid color-mix(in srgb, currentColor 10%, transparent)', padding: 12, overflow: 'auto', maxHeight: 390 }}>
          <strong>{selectedNode?.name ?? 'Conversation summaries'}</strong>
          {selectedNode !== undefined && <div style={{ marginTop: 4, opacity: 0.6 }}>{selectedNode.kind} · {selectedNode.degree} relations</div>}
          <div style={{ marginTop: 12, display: 'grid', gap: 8 }}>
            {(selectedNode === undefined ? graph.summaries.map(summary => ({ id: summary.id, text: summary.summary, note: `turn ${summary.turn} · ${summary.model}`, memory: false })) : related.map(memory => ({ id: memory.id, text: memory.content, note: `${memory.kind} · confidence ${Math.round(memory.confidence * 100)}%`, memory: true }))).slice(0, 8).map(item => <article key={item.id} style={{ padding: 9, borderRadius: 8, background: 'color-mix(in srgb, currentColor 6%, transparent)' }}>
              <div>{short(item.text, 220)}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}><small style={{ opacity: 0.58, flex: 1 }}>{item.note}</small>
                {item.memory && onForget !== undefined && <button type="button" style={{ ...button, color: '#c94848', padding: '2px 6px' }} onClick={() => onForget(item.id)}>Delete</button>}
              </div>
            </article>)}
            {selectedNode !== undefined && related.length === 0 && <span style={{ opacity: 0.6 }}>No active memory attached.</span>}
            {selectedNode === undefined && graph.summaries.length === 0 && <span style={{ opacity: 0.6 }}>No dialogue summary yet.</span>}
          </div>
        </aside>
      </div>}
    </div>}
  </section>
}

function MemoryDashboard({ wide, initial, initialEtag }: { wide: boolean; initial: DashboardSnapshot; initialEtag?: string }) {
  const [open, setOpen] = useState(initial.config.autoOpen)
  const [snapshot, setSnapshot] = useState(initial)
  const [error, setError] = useState<string>()
  const etag = useRef(initialEtag)
  const refresh = async (): Promise<void> => {
    try {
      const result = await readDashboard(etag.current)
      if (result !== undefined) {
        etag.current = result.etag
        setSnapshot(result.snapshot)
      }
      setError(undefined)
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason))
    }
  }
  useEffect(() => {
    if (!open) return undefined
    const update = (): void => { if (!document.hidden) void refresh() }
    const timer = window.setInterval(update, snapshot.config.refreshMs)
    document.addEventListener('visibilitychange', update)
    return () => { window.clearInterval(timer); document.removeEventListener('visibilitychange', update) }
  }, [open, snapshot.config.refreshMs])
  useEffect(() => {
    const close = (): void => { setOpen(false) }
    window.addEventListener(CLOSE_DASHBOARD_EVENT, close)
    return () => { window.removeEventListener(CLOSE_DASHBOARD_EVENT, close) }
  }, [])
  const total = snapshot.graph.memories.length + snapshot.graph.summaries.length
  const defaultState = memoryDefaultState(snapshot.config)
  const forget = async (memoryId: string): Promise<void> => {
    if (!window.confirm('Permanently delete this memory and its sourced graph relations?')) return
    try {
      await mutate(snapshot.config.token, { action: 'forget-memory', memoryId })
      etag.current = undefined
      await refresh()
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason))
    }
  }
  return <div style={{ position: 'relative', width: '100%', height: wide ? 44 : 36, flex: 'none' }}>
    {open && <section aria-label="Memory" data-testid="memory-dashboard" style={{ position: 'fixed', left: 12, bottom: 116, zIndex: 40, width: 'min(920px, calc(100vw - 24px))', maxHeight: 'calc(100vh - 140px)', overflow: 'auto', padding: 10, boxSizing: 'border-box', border: '1px solid color-mix(in srgb, currentColor 16%, transparent)', borderRadius: 14, background: 'Canvas', color: 'CanvasText', boxShadow: '0 18px 55px rgba(0,0,0,.22)', fontFamily: 'var(--dsw-font-family, ui-sans-serif, system-ui, sans-serif)' }}>
      <header style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '2px 4px 8px' }}>
        <span style={{ flex: 1 }}><strong>Memory</strong><small style={{ display: 'block', opacity: 0.58 }}>DSH 跨对话记住的长期信息</small></span>
        <span style={{ opacity: 0.6, fontSize: 12 }}>{snapshot.graph.memories.length} memories · {snapshot.graph.summaries.length} summaries</span>
        <button type="button" style={button} onClick={() => { void refresh() }}>Refresh</button>
        <button type="button" aria-label="Close memory" style={button} onClick={() => setOpen(false)}>×</button>
      </header>
      {error !== undefined && <div role="alert" style={{ padding: 8, color: '#c94848' }}>{error}</div>}
      <section style={{ ...card, padding: 12, display: 'grid', gap: 10 }}>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <span aria-hidden="true" style={{ width: 10, height: 10, flex: 'none', borderRadius: 99, background: defaultState === 'on' ? '#0f9d8a' : defaultState === 'off' ? '#8b9098' : '#dd7a2b' }} />
          <div style={{ flex: 1 }}><strong>Profile 默认：{defaultState === 'on' ? '已开启' : defaultState === 'off' ? '已关闭' : '部分开启'}</strong><div style={{ opacity: 0.62, fontSize: 12 }}>作用范围：当前 profile 的所有对话，不是单个对话</div></div>
          <small style={{ opacity: 0.7 }}>Recall {snapshot.config.autoRecall ? 'On' : 'Off'} · Learn {snapshot.config.autoSummarize ? 'On' : 'Off'} · Archive {snapshot.config.archiveTurns ? 'On' : 'Off'}</small>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 8 }}>
          <div style={{ padding: 9, borderRadius: 8, background: 'color-mix(in srgb, #0f9d8a 9%, transparent)' }}><strong>回答前</strong><div style={{ opacity: 0.68 }}>只召回与当前问题相关的偏好、事实和经验，注入回答上下文。</div></div>
          <div style={{ padding: 9, borderRadius: 8, background: 'color-mix(in srgb, #6d5dfc 9%, transparent)' }}><strong>回答后</strong><div style={{ opacity: 0.68 }}>把值得复用的信息提炼为长期记忆；不会把每句话都当作记忆。</div></div>
        </div>
        <small style={{ opacity: 0.62 }}>因此它通常是“安静地”改善后续相关回答；无关问题不会强行使用记忆。输入框下方可为下一轮临时开启或关闭。</small>
        {(snapshot.config.archiveStatus.failed > 0 || snapshot.config.archiveStatus.pending > 0) && <div role="status" style={{ padding: 9, borderRadius: 8, color: '#9a5a16', background: 'color-mix(in srgb, #dd7a2b 12%, transparent)' }}>
          有 {snapshot.config.archiveStatus.pending} 轮等待提炼，{snapshot.config.archiveStatus.failed} 轮提炼失败。失败或等待中的轮次尚未形成可召回的长期记忆；可用 <code>memory_archive_retry</code> 重试失败轮次。
        </div>}
      </section>
      <section style={{ ...card, padding: 10 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}><strong style={{ flex: 1 }}>DSH 记住了什么</strong><small style={{ opacity: 0.58 }}>这些内容可能影响未来相关回答</small></div>
        <div style={{ display: 'grid', gap: 6, marginTop: 8 }}>
          {snapshot.graph.memories.slice(0, 12).map(memory => <article key={memory.id} style={{ display: 'flex', gap: 8, alignItems: 'center', padding: 8, borderRadius: 8, background: 'color-mix(in srgb, currentColor 6%, transparent)' }}>
            <span style={{ flex: 1 }}><span>{short(memory.content, 240)}</span><small style={{ display: 'block', opacity: 0.55 }}>{memoryImpact(memory.kind)} · {memory.kind}</small></span>
            <button type="button" style={{ ...button, color: '#c94848' }} onClick={() => { void forget(memory.id) }}>Delete</button>
          </article>)}
          {snapshot.graph.memories.length === 0 && <div style={{ padding: 18, textAlign: 'center', opacity: 0.62 }}>还没有可召回的长期记忆。{snapshot.graph.summaries.length > 0 ? `现有 ${snapshot.graph.summaries.length} 条对话摘要只是审计记录，不等于长期记忆。` : '完成几轮包含稳定偏好、决定或经验的对话后会出现。'}</div>}
        </div>
      </section>
      <GraphCard graph={snapshot.graph} onForget={(id) => { void forget(id) }} />
      <details style={{ ...card, padding: 10 }}>
        <summary style={{ cursor: 'pointer' }}><strong>运行详情</strong></summary>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, paddingTop: 8 }}>
          <span style={button}>Tool results: {snapshot.config.captureToolResults ? 'on' : 'off'}</span>
          <span style={button}>Semantic: {snapshot.config.semanticEnabled ? (snapshot.config.semanticAvailable ? 'ready' : 'fallback') : 'off'}</span>
          <span style={button}>Summary language: {snapshot.config.summaryLanguage === 'auto' ? 'auto (跟随用户)' : snapshot.config.summaryLanguage}</span>
          {snapshot.config.outboxPending > 0 && <span style={{ ...button, color: '#c47b20' }}>Outbox: {snapshot.config.outboxPending}</span>}
        </div>
      </details>
    </section>}
    <button type="button" aria-label="Memory" aria-expanded={open} onClick={() => { setOpen(value => !value); if (!open) void refresh() }} style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: wide ? 'flex-start' : 'center', gap: 8, padding: wide ? '0 8px' : 0, border: 0, borderRadius: 10, background: open ? 'color-mix(in srgb, #6d5dfc 14%, transparent)' : 'transparent', color: 'inherit', cursor: 'pointer', font: '13px var(--dsw-font-family, ui-sans-serif, system-ui, sans-serif)' }}>
      <span style={{ color: '#6d5dfc', fontSize: 18 }}>⬡</span>
      {wide && <><span style={{ flex: 1, textAlign: 'left' }}>Memory</span><span style={{ opacity: 0.55 }}>{total}</span></>}
    </button>
  </div>
}

function MemoryTurnControl({ sessionId, session }: { sessionId: string; session: { running: boolean } }) {
  const [snapshot, setSnapshot] = useState<DashboardSnapshot>()
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [hovered, setHovered] = useState(false)
  const load = async (): Promise<void> => {
    try {
      const result = await readDashboard(undefined, sessionId)
      if (result !== undefined) setSnapshot(result.snapshot)
      setError(false)
    } catch {
      setError(true)
    }
  }
  useEffect(() => { void load() }, [sessionId, session.running])
  if (snapshot === undefined) return error ? <span title="Memory graph unavailable" style={{ opacity: 0.5 }}>Memory unavailable</span> : null
  const selected = snapshot.runtime?.pendingMode ?? 'default'
  const profileState = memoryDefaultState(snapshot.config)
  const visibleState = selected === 'default' ? profileState : selected
  const triggerLabel = selected === 'default'
    ? `Memory · ${visibleState === 'on' ? 'On' : visibleState === 'off' ? 'Off' : 'Mixed'}`
    : `Memory · ${visibleState === 'on' ? 'On once' : 'Off once'}`
  const defaults = `Recall ${snapshot.config.autoRecall ? 'on' : 'off'} · Learn ${snapshot.config.autoSummarize ? 'on' : 'off'} · Archive ${snapshot.config.archiveTurns ? 'on' : 'off'}`
  const setMode = async (mode: 'default' | 'on' | 'off'): Promise<void> => {
    const previous = snapshot
    setSaving(true)
    setSnapshot({ ...snapshot, runtime: { ...snapshot.runtime, pendingMode: mode } })
    try {
      await mutate(snapshot.config.token, { action: 'set-turn-mode', sessionId, mode })
      setError(false)
    } catch {
      setSnapshot(previous)
      setError(true)
    } finally {
      setSaving(false)
    }
  }
  const option = (mode: 'default' | 'on' | 'off', title: string, description: string) => <button key={mode} type="button" role="menuitemradio" aria-checked={selected === mode} disabled={saving}
    onClick={() => { setMenuOpen(false); void setMode(mode) }}
    style={{ width: '100%', display: 'grid', gridTemplateColumns: '18px minmax(0, 1fr)', gap: 8, padding: '8px 10px', border: 0, borderRadius: 8, background: selected === mode ? 'var(--dsw-alias-interactive-bg-selected, color-mix(in srgb, #6d5dfc 12%, transparent))' : 'transparent', color: 'inherit', textAlign: 'left', cursor: saving ? 'wait' : 'pointer', fontFamily: 'var(--dsw-font-family, ui-sans-serif, system-ui, sans-serif)' }}>
    <span aria-hidden="true" style={{ color: '#6d5dfc', paddingTop: 1 }}>{selected === mode ? '✓' : ''}</span>
    <span><strong style={{ display: 'block', fontSize: 13, lineHeight: '18px', fontWeight: 500 }}>{title}</strong><small style={{ display: 'block', marginTop: 2, opacity: 0.58, lineHeight: '16px' }}>{description}</small></span>
  </button>
  return <div style={{ position: 'relative', display: 'inline-flex', alignItems: 'center' }}>
    <button type="button" aria-label={`${triggerLabel}. ${selected === 'default' ? `Profile default: ${defaults}` : 'Applies to the next turn only'}`} aria-haspopup="menu" aria-expanded={menuOpen}
      disabled={saving || session.running} onClick={() => {
        if (!menuOpen) window.dispatchEvent(new Event(CLOSE_DASHBOARD_EVENT))
        setMenuOpen(value => !value)
      }}
      onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 4, minWidth: 0, maxWidth: 220, height: 28, padding: '0 4px 0 8px', border: 0, borderRadius: 24, outline: 'none', background: hovered || menuOpen ? 'var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 7%, transparent))' : 'transparent', color: 'var(--dsw-alias-label-secondary, currentColor)', cursor: saving ? 'wait' : session.running ? 'default' : 'pointer', fontFamily: 'var(--dsw-font-family, ui-sans-serif, system-ui, sans-serif)', fontSize: 13, lineHeight: '20px', fontWeight: 500, opacity: session.running ? 0.45 : 1 }}>
      <span aria-hidden="true" style={{ width: 7, height: 7, borderRadius: 99, flex: 'none', background: visibleState === 'on' ? '#0f9d8a' : visibleState === 'off' ? '#8b9098' : '#dd7a2b' }} />
      <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{triggerLabel}</span>
      <span aria-hidden="true" style={{ width: 14, textAlign: 'center', opacity: 0.62, transform: menuOpen ? 'rotate(180deg)' : undefined, transition: 'transform 120ms' }}>⌄</span>
    </button>
    {menuOpen && <div role="menu" aria-label="Memory for next turn" style={{ position: 'absolute', left: 0, bottom: 'calc(100% + 8px)', zIndex: 50, width: 280, padding: 6, border: '1px solid var(--dsw-alias-border-l2, color-mix(in srgb, currentColor 14%, transparent))', borderRadius: 12, background: 'var(--dsw-alias-bg-elevated, Canvas)', color: 'var(--dsw-alias-label-primary, CanvasText)', boxShadow: '0 10px 32px rgba(0,0,0,.18)', boxSizing: 'border-box' }}>
      <div style={{ padding: '5px 10px 7px', fontSize: 11, opacity: 0.55 }}>下一轮对话</div>
      {option('default', `使用 Profile 默认（${profileState === 'on' ? 'On' : profileState === 'off' ? 'Off' : 'Mixed'}）`, defaults)}
      {option('on', '仅下一轮开启', '召回已有记忆，并学习这一轮的新信息')}
      {option('off', '仅下一轮关闭', '这一轮不自动召回、学习或归档；手动工具仍可用')}
    </div>}
    {error && <span aria-label="Memory setting failed" title="Memory setting failed" style={{ color: '#c94848', marginLeft: 3 }}>!</span>}
  </div>
}

/** Tool row owner for running, failed, and successful graph calls. */
export function MemoryGraphRow({ block }: ToolCallViewProps) {
  if (!('kind' in block)) return <div style={{ ...card, padding: 11 }}>Building memory graph…</div>
  if (block.isError) return <div style={{ ...card, padding: 11 }}>Memory graph failed.</div>
  const graph = graphFromMeta(block.meta)
  return graph === undefined
    ? <div style={{ ...card, padding: 11 }}>Memory graph metadata is unavailable for this result.</div>
    : <GraphCard graph={graph} />
}

/** Client runtime dependencies. */
export const inject = ['slots']

/** Register the keyed memory_graph presentation without replacing generic tools. */
export async function apply(ctx: Context): Promise<void> {
  ctx.slots.inject('tool.call.toolview', () => ctx.slots.register({
    name: 'tool.call.toolview', key: 'memory_graph',
  }, MemoryGraphRow))
  ctx.slots.inject('conversation.input.left', () => ctx.slots.register({
    name: 'conversation.input.left', id: 'memory-graph-turn', order: 90, label: 'Memory for next turn',
  }, MemoryTurnControl))
  let initial: DashboardReadResult | undefined
  try {
    initial = await readDashboard()
  } catch {
    return
  }
  if (initial === undefined) return
  ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
    name: 'sidebar.footer.action', id: 'memory-graph', order: 80, label: 'Memory',
  }, props => <MemoryDashboard wide={props.wide} initial={initial.snapshot}
    {...initial.etag === undefined ? {} : { initialEtag: initial.etag }} />))
}
