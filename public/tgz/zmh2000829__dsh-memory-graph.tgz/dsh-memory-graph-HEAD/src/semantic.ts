/** Optional OpenAI-compatible embedding client with lexical-only fallback. */

export interface SemanticConfig {
  enabled: boolean
  endpoint: string
  model: string
  apiKeyEnv: string
  timeoutMs: number
  failureCooldownMs: number
}

interface EmbeddingResponse {
  data?: Array<{ index?: number; embedding?: number[] }>
}

/** Remote embedding adapter; no call is made unless explicitly enabled. */
export class SemanticEmbeddingClient {
  private warnedMissingKey = false
  private cooldownUntil = 0

  constructor(readonly config: SemanticConfig, private readonly warn: (message: string) => void) {}

  /** Whether current configuration can attempt an embedding request. */
  available(): boolean {
    if (!this.config.enabled) return false
    if (Date.now() < this.cooldownUntil) return false
    if (this.config.apiKeyEnv === '') return true
    return (process.env[this.config.apiKeyEnv]?.trim().length ?? 0) > 0
  }

  /** Embed text in input order; undefined means the caller must use lexical recall. */
  async embed(input: readonly string[], signal?: AbortSignal, timeoutMs = this.config.timeoutMs): Promise<number[][] | undefined> {
    if (!this.config.enabled || input.length === 0) return undefined
    const key = this.config.apiKeyEnv === '' ? undefined : process.env[this.config.apiKeyEnv]?.trim()
    if (this.config.apiKeyEnv !== '' && !key) {
      if (!this.warnedMissingKey) {
        this.warnedMissingKey = true
        this.warn(`memory-graph: semantic recall is configured but ${this.config.apiKeyEnv} is unset; using lexical recall`)
      }
      return undefined
    }
    if (Date.now() < this.cooldownUntil) return undefined
    const timeout = AbortSignal.timeout(timeoutMs)
    const combined = signal === undefined ? timeout : AbortSignal.any([signal, timeout])
    try {
      const response = await fetch(this.config.endpoint, {
        method: 'POST',
        headers: {
          accept: 'application/json',
          'content-type': 'application/json',
          ...(key === undefined ? {} : { authorization: `Bearer ${key}` }),
        },
        body: JSON.stringify({ model: this.config.model, input }),
        signal: combined,
      })
      if (!response.ok) {
        this.cooldownUntil = Date.now() + this.config.failureCooldownMs
        this.warn(`memory-graph: embedding request failed (${response.status}); using lexical recall`)
        return undefined
      }
      const body = await response.json() as EmbeddingResponse
      const rows = body.data
      if (!Array.isArray(rows) || rows.length !== input.length) {
        this.cooldownUntil = Date.now() + this.config.failureCooldownMs
        this.warn('memory-graph: embedding response has an invalid item count; using lexical recall')
        return undefined
      }
      const ordered = rows.map((row, index) => ({ index: row.index ?? index, embedding: row.embedding }))
        .sort((left, right) => left.index - right.index)
      if (ordered.some(row => !Array.isArray(row.embedding) || row.embedding.length === 0
        || row.embedding.some(value => !Number.isFinite(value)))) {
        this.cooldownUntil = Date.now() + this.config.failureCooldownMs
        this.warn('memory-graph: embedding response contains an invalid vector; using lexical recall')
        return undefined
      }
      const dimensions = ordered[0]!.embedding!.length
      if (ordered.some(row => row.embedding!.length !== dimensions)) {
        this.cooldownUntil = Date.now() + this.config.failureCooldownMs
        this.warn('memory-graph: embedding response dimensions differ; using lexical recall')
        return undefined
      }
      return ordered.map(row => row.embedding!)
    } catch (error: unknown) {
      if (!signal?.aborted) this.cooldownUntil = Date.now() + this.config.failureCooldownMs
      if (!combined.aborted) this.warn(`memory-graph: embedding request failed; using lexical recall (${String(error)})`)
      return undefined
    }
  }
}

/** Small TTL/LRU cache for repeated query embeddings on recall hot paths. */
export class SemanticQueryCache {
  private readonly values = new Map<string, { expiresAt: number; vector: number[] }>()

  constructor(private readonly ttlMs: number, private readonly limit = 128) {}

  /** Return a cached vector or load and retain one successful result. */
  async get(query: string, load: () => Promise<number[] | undefined>): Promise<number[] | undefined> {
    const key = query.normalize('NFKC').trim().toLocaleLowerCase('en-US')
    const cached = this.values.get(key)
    const now = Date.now()
    if (cached !== undefined && cached.expiresAt > now) {
      this.values.delete(key)
      this.values.set(key, cached)
      return cached.vector
    }
    if (cached !== undefined) this.values.delete(key)
    const vector = await load()
    if (vector === undefined || this.ttlMs === 0) return vector
    this.values.set(key, { expiresAt: now + this.ttlMs, vector })
    while (this.values.size > this.limit) this.values.delete(this.values.keys().next().value!)
    return vector
  }
}

/** Serial, deduplicating background queue for write-side embedding indexing. */
export class SemanticIndexQueue {
  private readonly pending = new Set<string>()
  private readonly lifecycle = new AbortController()
  private running: Promise<void> | undefined

  constructor(private readonly index: (ids: readonly string[], signal: AbortSignal) => Promise<void>) {}

  /** Schedule memory ids without delaying the caller's write result. */
  enqueue(ids: readonly string[]): void {
    if (this.lifecycle.signal.aborted) return
    ids.forEach(id => this.pending.add(id))
    if (this.running !== undefined) return
    this.running = this.drain().finally(() => { this.running = undefined })
  }

  private async drain(): Promise<void> {
    while (!this.lifecycle.signal.aborted && this.pending.size > 0) {
      const ids = [...this.pending].slice(0, 32)
      ids.forEach(id => this.pending.delete(id))
      try {
        await this.index(ids, this.lifecycle.signal)
      } catch {
        // The embedding adapter already reports failures; lexical recall remains available.
      }
    }
  }

  /** Stop new work, abort the current request, and settle the contained task. */
  async dispose(): Promise<void> {
    this.lifecycle.abort('memory-graph semantic index disposed')
    this.pending.clear()
    await Promise.allSettled(this.running === undefined ? [] : [this.running])
  }
}
