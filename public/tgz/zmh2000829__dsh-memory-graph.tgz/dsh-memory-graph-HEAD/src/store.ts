/** SQLite-backed temporal memory store with FTS5 retrieval and bounded graph expansion. */

import { randomUUID } from 'node:crypto'
import { chmodSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname } from 'node:path'
import { DatabaseSync } from 'node:sqlite'
import type {
  ConversationSummary, DuplicateEntityCandidate, EntityConflict, EntityInput, EntityMergeResult, GraphMemory, GraphResult,
  MemoryInput, MemoryKind, OrphanEntity, RecallResult, RememberResult, RetrievalWeights,
  RevertResult, SummaryCommitInput, TurnArchive, ArchivedMessage,
} from './types.ts'

const APPLICATION_ID = 0x44534d47
const SCHEMA_VERSION = 6
const BACKUP_FORMAT_VERSION = 1

interface MemoryRow {
  id: string
  content: string
  importance: number
  confidence: number
  kind: MemoryKind
  stable_key: string | null
  status: 'active' | 'superseded'
  created_at: number
  accessed_at: number
  access_count: number
  valid_from: number
  valid_to: number | null
  supersedes_id: string | null
  source: string | null
  source_session: string | null
  source_turn: number | null
  source_event_seqs: string | null
  tags: string
  graph_json: string
}

interface EntityRow {
  id: string
  normalized: string
  name: string
  kind: string
}

interface RelationRow {
  id: number
  source_id: string
  source_name: string
  predicate: string
  target_id: string
  target_name: string
  confidence: number
  mentions: number
}

interface SummaryRow {
  id: string
  session_id: string
  turn: number
  summary: string
  source_event_seqs: string
  provider: string
  model: string
  created_at: number
}

interface ArchiveRow {
  id: string
  session_id: string
  turn: number
  source_event_seqs: string
  messages_json: string
  truncated: number
  original_message_count: number
  provider: string
  model: string
  status: TurnArchive['status']
  error: string | null
  created_at: number
  updated_at: number
}

interface WalkResult {
  distances: Map<string, number>
  entities: Map<string, EntityRow>
  relations: RelationRow[]
}

/** Normalize an entity identity while preserving its display spelling separately. */
export function normalizeEntity(value: string): string {
  return value.normalize('NFKC').trim().replace(/\s+/g, ' ').toLocaleLowerCase('en-US')
}

const PREDICATE_ALIASES = new Map<string, string>([
  ['use', 'uses'],
])

function predicateToken(value: string): string {
  return value.normalize('NFKC').trim().toLocaleLowerCase('en-US')
    .replace(/[^\p{L}\p{N}]+/gu, '_').replace(/^_+|_+$/g, '')
}

/** Normalize graph predicates to lowercase snake_case and apply conservative aliases. */
export function normalizePredicate(value: string): string {
  const normalized = predicateToken(value)
  return PREDICATE_ALIASES.get(normalized) ?? normalized
}

function compactEntityIdentity(value: string): string {
  return normalizeEntity(value).replace(/[^\p{L}\p{N}]+/gu, '')
}

function boundedLevenshtein(left: string, right: string, maximum: number): number | undefined {
  const a = [...left]
  const b = [...right]
  if (Math.abs(a.length - b.length) > maximum) return undefined
  const unavailable = maximum + 1
  let previous = Array.from({ length: b.length + 1 }, (_, index) => index <= maximum ? index : unavailable)
  for (let row = 1; row <= a.length; row++) {
    const current = Array<number>(b.length + 1).fill(unavailable)
    if (row <= maximum) current[0] = row
    let minimum = unavailable
    const start = Math.max(1, row - maximum)
    const end = Math.min(b.length, row + maximum)
    for (let column = start; column <= end; column++) {
      const substitution = previous[column - 1]! + (a[row - 1] === b[column - 1] ? 0 : 1)
      const value = Math.min(previous[column]! + 1, current[column - 1]! + 1, substitution)
      current[column] = value
      minimum = Math.min(minimum, value)
    }
    if (minimum > maximum) return undefined
    previous = current
  }
  const distance = previous[b.length]!
  return distance <= maximum ? distance : undefined
}

/** Store-level policy that does not belong to one recall request. */
export interface MemoryGraphStoreOptions {
  predicateAliases?: Readonly<Record<string, string>>
}

function normalizeStableKey(value: string): string {
  return value.normalize('NFKC').trim().replace(/\s+/g, '-').toLocaleLowerCase('en-US')
}

function trigrams(value: string): Set<string> {
  const result = new Set<string>()
  const terms = value.normalize('NFKC').trim().toLocaleLowerCase('en-US').match(/[\p{L}\p{N}]+/gu) ?? []
  for (const term of terms) {
    const characters = [...term]
    for (let index = 0; index <= characters.length - 3; index++) {
      result.add(characters.slice(index, index + 3).join(''))
    }
  }
  return result
}

function ftsQuery(value: string): string | undefined {
  const values = [...trigrams(value)]
  if (values.length === 0) return undefined
  return values.slice(0, 48).map(value => `"${value.replaceAll('"', '""')}"`).join(' OR ')
}

function searchTerms(value: string): string[] {
  return [...new Set(value.normalize('NFKC').toLocaleLowerCase('en-US').match(/[\p{L}\p{N}]+/gu) ?? [])]
}

function parseStringArray(value: string | null): string[] {
  if (value === null) return []
  const parsed = JSON.parse(value) as unknown
  return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === 'string') : []
}

function parseNumberArray(value: string): number[] {
  const parsed = JSON.parse(value) as unknown
  return Array.isArray(parsed)
    ? parsed.filter((item): item is number => Number.isSafeInteger(item) && item >= 0)
    : []
}

function backupSqlValue(value: unknown, table: string, column: string): string | number | null | Uint8Array {
  if (value === null || typeof value === 'string' || typeof value === 'number') return value
  if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
    const record = value as Record<string, unknown>
    if (Object.keys(record).length === 1 && typeof record.$blob === 'string' && /^[A-Za-z0-9+/]*={0,2}$/u.test(record.$blob)) {
      const decoded = Buffer.from(record.$blob, 'base64')
      if (decoded.toString('base64') === record.$blob) return decoded
    }
  }
  throw new Error(`memory graph: invalid JSONL value for ${table}.${column}`)
}

function backupRow(row: Record<string, unknown>): Record<string, unknown> {
  return Object.fromEntries(Object.entries(row).map(([column, value]) => [
    column,
    value instanceof Uint8Array ? { $blob: Buffer.from(value).toString('base64') } : value,
  ]))
}

/** Options controlling one hybrid search. */
export interface RecallOptions {
  limit: number
  hops: number
  halfLifeDays: number
  weights: RetrievalWeights
  semanticScores?: ReadonlyMap<string, number>
  preferenceBoost?: number
  temporalBoost?: number
  lexicalOverlapBoost?: number
  reinforce?: boolean
  now?: number
}

/** Result of committing one model-produced dialogue summary. */
export interface SummaryCommitResult {
  summaryId: string
  memoryResults: RememberResult[]
  skipped: boolean
}

/** Durable local memory graph. The caller owns and closes the instance. */
export class MemoryGraphStore {
  private readonly db: DatabaseSync
  private readonly instanceId = randomUUID()
  private readonly predicateAliases: ReadonlyMap<string, string>
  private revision = 0
  private semanticScanOffset = 0
  private closed = false

  /** Open or initialize one plugin-owned database. */
  constructor(readonly path: string, options: MemoryGraphStoreOptions = {}) {
    const aliases = new Map(PREDICATE_ALIASES)
    for (const [source, target] of Object.entries(options.predicateAliases ?? {})) {
      const normalizedSource = predicateToken(source)
      const normalizedTarget = predicateToken(target)
      if (normalizedSource === '' || normalizedTarget === '') {
        throw new Error('memory graph: predicate aliases must normalize to non-empty predicates')
      }
      aliases.set(normalizedSource, normalizedTarget)
    }
    for (const source of aliases.keys()) {
      const visited = new Set<string>()
      let current = source
      while (aliases.has(current)) {
        if (visited.has(current)) throw new Error(`memory graph: cyclic predicate alias at "${current}"`)
        visited.add(current)
        const next = aliases.get(current)!
        if (next === current) break
        current = next
      }
    }
    this.predicateAliases = aliases
    if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true, mode: 0o700 })
    this.db = new DatabaseSync(path)
    try {
      this.configure()
      if (path !== ':memory:') chmodSync(path, 0o600)
    } catch (error: unknown) {
      this.db.close()
      throw error
    }
  }

  private configure(): void {
    this.db.exec('PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000')
    let began = false
    try {
      this.db.exec('BEGIN IMMEDIATE')
      began = true
      const { user_version: version } = this.db.prepare('PRAGMA user_version').get() as { user_version: number }
      const { application_id: applicationId } = this.db.prepare('PRAGMA application_id').get() as { application_id: number }
      const { count } = this.db.prepare(
        "SELECT COUNT(*) AS count FROM sqlite_schema WHERE name NOT GLOB 'sqlite_*'",
      ).get() as { count: number }
      if (version === 0 && (applicationId !== 0 || count > 0)) {
        throw new Error(`memory graph database at "${this.path}" is not an empty plugin database`)
      }
      if (version !== 0 && applicationId !== APPLICATION_ID) {
        throw new Error(`memory graph database has application id ${applicationId}, expected ${APPLICATION_ID}`)
      }
      if (version !== 0 && version !== 1 && version !== 2 && version !== 3 && version !== 4 && version !== 5 && version !== SCHEMA_VERSION) {
        throw new Error(`memory graph schema ${version} is incompatible with ${SCHEMA_VERSION}`)
      }
      this.createBaseSchema()
      if (version === 1) this.migrateV1ToV2()
      this.createV2Schema()
      if (version === 1 || version === 2) this.migrateV2ToV3()
      this.createV3Schema()
      this.createV4Schema()
      this.createV5Schema()
      this.createV6Schema()
      this.pruneInactiveEmbeddings()
      if (version === 0) this.db.exec(`PRAGMA application_id = ${APPLICATION_ID}`)
      if (version !== SCHEMA_VERSION) this.db.exec(`PRAGMA user_version = ${SCHEMA_VERSION}`)
      this.db.exec('COMMIT')
      began = false
    } catch (error: unknown) {
      if (began) {
        try {
          this.db.exec('ROLLBACK')
        } catch {
          // The schema error remains the actionable failure.
        }
      }
      throw error
    }
    this.db.exec('PRAGMA journal_mode = WAL')
  }

  private createBaseSchema(): void {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS memories (
        id                TEXT PRIMARY KEY,
        content           TEXT NOT NULL,
        importance        REAL NOT NULL CHECK (importance >= 0 AND importance <= 1),
        created_at        INTEGER NOT NULL,
        accessed_at       INTEGER NOT NULL,
        access_count      INTEGER NOT NULL DEFAULT 0,
        source            TEXT,
        tags              TEXT NOT NULL,
        confidence        REAL NOT NULL DEFAULT 1 CHECK (confidence >= 0 AND confidence <= 1),
        kind              TEXT NOT NULL DEFAULT 'fact',
        stable_key        TEXT,
        status            TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'superseded')),
        valid_from        INTEGER NOT NULL DEFAULT 0,
        valid_to          INTEGER,
        supersedes_id     TEXT REFERENCES memories(id) ON DELETE SET NULL,
        source_session    TEXT,
        source_turn       INTEGER,
        source_event_seqs TEXT
        ,graph_json       TEXT NOT NULL DEFAULT '{"entities":[],"relations":[]}'
      ) STRICT;

      CREATE TABLE IF NOT EXISTS entities (
        id         TEXT PRIMARY KEY,
        normalized TEXT NOT NULL UNIQUE,
        name       TEXT NOT NULL,
        kind       TEXT NOT NULL
      ) STRICT;

      CREATE TABLE IF NOT EXISTS memory_entities (
        memory_id TEXT NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
        entity_id TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
        PRIMARY KEY (memory_id, entity_id)
      ) STRICT;

      CREATE TABLE IF NOT EXISTS relations (
        id               INTEGER PRIMARY KEY,
        source_id        TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
        predicate        TEXT NOT NULL,
        target_id        TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
        confidence       REAL NOT NULL CHECK (confidence >= 0 AND confidence <= 1),
        source_memory_id TEXT REFERENCES memories(id) ON DELETE CASCADE,
        UNIQUE (source_id, predicate, target_id, source_memory_id)
      ) STRICT;

      CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
        content, tags, content='memories', content_rowid='rowid',
        tokenize='trigram'
      );

      CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
        INSERT INTO memory_fts(rowid, content, tags) VALUES (new.rowid, new.content, new.tags);
      END;
      CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
        INSERT INTO memory_fts(memory_fts, rowid, content, tags)
        VALUES ('delete', old.rowid, old.content, old.tags);
      END;
      CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories BEGIN
        INSERT INTO memory_fts(memory_fts, rowid, content, tags)
        VALUES ('delete', old.rowid, old.content, old.tags);
        INSERT INTO memory_fts(rowid, content, tags) VALUES (new.rowid, new.content, new.tags);
      END;
    `)
  }

  private migrateV1ToV2(): void {
    const columns = new Set((this.db.prepare('PRAGMA table_info(memories)').all() as Array<{ name: string }>).map(row => row.name))
    const additions = [
      ['confidence', "REAL NOT NULL DEFAULT 1 CHECK (confidence >= 0 AND confidence <= 1)"],
      ['kind', "TEXT NOT NULL DEFAULT 'fact'"],
      ['stable_key', 'TEXT'],
      ['status', "TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'superseded'))"],
      ['valid_from', 'INTEGER NOT NULL DEFAULT 0'],
      ['valid_to', 'INTEGER'],
      ['supersedes_id', 'TEXT REFERENCES memories(id) ON DELETE SET NULL'],
      ['source_session', 'TEXT'],
      ['source_turn', 'INTEGER'],
      ['source_event_seqs', 'TEXT'],
    ] as const
    for (const [name, declaration] of additions) {
      if (!columns.has(name)) this.db.exec(`ALTER TABLE memories ADD COLUMN ${name} ${declaration}`)
    }
    this.db.exec('UPDATE memories SET valid_from = created_at WHERE valid_from = 0')
  }

  private createV2Schema(): void {
    this.db.exec(`
      CREATE UNIQUE INDEX IF NOT EXISTS memories_active_stable_key
      ON memories(stable_key) WHERE stable_key IS NOT NULL AND status = 'active';
      CREATE INDEX IF NOT EXISTS memories_source_turn ON memories(source_session, source_turn);

      CREATE TABLE IF NOT EXISTS summaries (
        id                TEXT PRIMARY KEY,
        session_id        TEXT NOT NULL,
        turn              INTEGER NOT NULL,
        summary           TEXT NOT NULL,
        source_event_seqs TEXT NOT NULL,
        provider          TEXT NOT NULL,
        model             TEXT NOT NULL,
        request_json      TEXT NOT NULL,
        response_json     TEXT NOT NULL,
        created_at        INTEGER NOT NULL,
        UNIQUE (session_id, turn)
      ) STRICT;
      CREATE INDEX IF NOT EXISTS summaries_created_at ON summaries(created_at DESC);
    `)
  }

  private migrateV2ToV3(): void {
    const columns = new Set((this.db.prepare('PRAGMA table_info(memories)').all() as Array<{ name: string }>).map(row => row.name))
    if (!columns.has('graph_json')) {
      this.db.exec(`ALTER TABLE memories ADD COLUMN graph_json TEXT NOT NULL DEFAULT '{"entities":[],"relations":[]}'`)
      const memories = this.db.prepare('SELECT id FROM memories').all() as Array<{ id: string }>
      for (const memory of memories) {
        const entities = this.db.prepare(`
          SELECT e.name, e.kind FROM memory_entities me JOIN entities e ON e.id = me.entity_id
          WHERE me.memory_id = ? ORDER BY e.name
        `).all(memory.id)
        const relations = this.db.prepare(`
          SELECT s.name AS source, r.predicate, t.name AS target, r.confidence
          FROM relations r JOIN entities s ON s.id = r.source_id JOIN entities t ON t.id = r.target_id
          WHERE r.source_memory_id = ? ORDER BY r.id
        `).all(memory.id)
        this.db.prepare('UPDATE memories SET graph_json = ? WHERE id = ?')
          .run(JSON.stringify({ entities, relations }), memory.id)
      }
    }
    this.db.exec(`
      DROP TRIGGER IF EXISTS memories_ai;
      DROP TRIGGER IF EXISTS memories_ad;
      DROP TRIGGER IF EXISTS memories_au;
      DROP TABLE IF EXISTS memory_fts;
      CREATE VIRTUAL TABLE memory_fts USING fts5(
        content, tags, content='memories', content_rowid='rowid', tokenize='trigram'
      );
      INSERT INTO memory_fts(rowid, content, tags) SELECT rowid, content, tags FROM memories;
    `)
  }

  private createV3Schema(): void {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS entity_aliases (
        alias_normalized TEXT PRIMARY KEY,
        entity_id        TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
        display_name     TEXT NOT NULL,
        mentions         INTEGER NOT NULL DEFAULT 1 CHECK (mentions >= 0)
      ) STRICT;
      CREATE INDEX IF NOT EXISTS entity_aliases_entity ON entity_aliases(entity_id);

      CREATE TABLE IF NOT EXISTS entity_kind_votes (
        entity_id TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
        kind      TEXT NOT NULL,
        mentions  INTEGER NOT NULL DEFAULT 1 CHECK (mentions > 0),
        PRIMARY KEY (entity_id, kind)
      ) STRICT;

      INSERT OR IGNORE INTO entity_aliases(alias_normalized, entity_id, display_name, mentions)
      SELECT normalized, id, name, 1 FROM entities;
      INSERT OR IGNORE INTO entity_kind_votes(entity_id, kind, mentions)
      SELECT id, kind, 1 FROM entities;

      CREATE INDEX IF NOT EXISTS relations_source ON relations(source_id);
      CREATE INDEX IF NOT EXISTS relations_target ON relations(target_id);
      CREATE INDEX IF NOT EXISTS memory_entities_entity ON memory_entities(entity_id);

      CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
        INSERT INTO memory_fts(rowid, content, tags) VALUES (new.rowid, new.content, new.tags);
      END;
      CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
        INSERT INTO memory_fts(memory_fts, rowid, content, tags)
        VALUES ('delete', old.rowid, old.content, old.tags);
      END;
      CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories BEGIN
        INSERT INTO memory_fts(memory_fts, rowid, content, tags)
        VALUES ('delete', old.rowid, old.content, old.tags);
        INSERT INTO memory_fts(rowid, content, tags) VALUES (new.rowid, new.content, new.tags);
      END;
    `)
  }

  private createV4Schema(): void {
    const columns = new Set((this.db.prepare('PRAGMA table_info(entity_aliases)').all() as Array<{ name: string }>).map(row => row.name))
    if (!columns.has('preferred')) {
      this.db.exec('ALTER TABLE entity_aliases ADD COLUMN preferred INTEGER NOT NULL DEFAULT 0 CHECK (preferred IN (0, 1))')
    }
  }

  private createV5Schema(): void {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS turn_transcripts (
        id                TEXT PRIMARY KEY,
        session_id        TEXT NOT NULL,
        turn              INTEGER NOT NULL,
        source_event_seqs TEXT NOT NULL,
        messages_json     TEXT NOT NULL,
        provider          TEXT NOT NULL,
        model             TEXT NOT NULL,
        status            TEXT NOT NULL CHECK (status IN ('pending', 'summarized', 'failed', 'archived')),
        error             TEXT,
        created_at        INTEGER NOT NULL,
        updated_at        INTEGER NOT NULL,
        UNIQUE (session_id, turn)
      ) STRICT;
      CREATE INDEX IF NOT EXISTS turn_transcripts_status ON turn_transcripts(status, updated_at);

      CREATE TABLE IF NOT EXISTS memory_embeddings (
        memory_id  TEXT PRIMARY KEY REFERENCES memories(id) ON DELETE CASCADE,
        provider   TEXT NOT NULL,
        model      TEXT NOT NULL,
        dimensions INTEGER NOT NULL CHECK (dimensions > 0),
        vector     BLOB NOT NULL,
        updated_at INTEGER NOT NULL
      ) STRICT;
      CREATE INDEX IF NOT EXISTS memory_embeddings_model ON memory_embeddings(provider, model);
    `)
  }

  private createV6Schema(): void {
    const columns = new Set((this.db.prepare('PRAGMA table_info(turn_transcripts)').all() as Array<{ name: string }>).map(row => row.name))
    if (!columns.has('truncated')) {
      this.db.exec('ALTER TABLE turn_transcripts ADD COLUMN truncated INTEGER NOT NULL DEFAULT 0 CHECK (truncated IN (0, 1))')
    }
    if (!columns.has('original_message_count')) {
      this.db.exec('ALTER TABLE turn_transcripts ADD COLUMN original_message_count INTEGER NOT NULL DEFAULT 0 CHECK (original_message_count >= 0)')
    }
  }

  /** Store one memory and its entity/relation graph atomically. */
  remember(input: MemoryInput): RememberResult {
    this.assertOpen()
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const result = this.insertMemory(input)
      this.db.exec('COMMIT')
      if (!result.deduplicated) this.bumpRevision()
      return result
    } catch (error: unknown) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  /** Atomically persist a turn summary and every accepted extracted memory. */
  commitSummary(input: SummaryCommitInput): SummaryCommitResult {
    this.assertOpen()
    const now = input.now ?? Date.now()
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const summaryId = randomUUID()
      const inserted = this.db.prepare(`
        INSERT OR IGNORE INTO summaries(
          id, session_id, turn, summary, source_event_seqs, provider, model,
          request_json, response_json, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        summaryId,
        input.sessionId,
        input.turn,
        input.extracted.summary,
        JSON.stringify(input.sourceEventSeqs),
        input.provider,
        input.model,
        input.requestJson,
        input.responseJson,
        now,
      )
      if (Number(inserted.changes) === 0) {
        const existing = this.db.prepare(
          'SELECT id FROM summaries WHERE session_id = ? AND turn = ?',
        ).get(input.sessionId, input.turn) as { id: string }
        this.db.exec('COMMIT')
        return { summaryId: existing.id, memoryResults: [], skipped: true }
      }
      const memoryResults = input.extracted.memories
        .filter(memory => memory.confidence >= input.minConfidence)
        .map(memory => this.insertMemory({
          ...memory,
          tags: [...new Set([...memory.tags, 'auto-summary', memory.kind])],
          source: `summary:${summaryId}`,
          sourceSession: input.sessionId,
          sourceTurn: input.turn,
          sourceEventSeqs: input.sourceEventSeqs,
          now,
        }))
      this.db.prepare(`
        UPDATE turn_transcripts SET status = 'summarized', error = NULL, updated_at = ?
        WHERE session_id = ? AND turn = ?
      `).run(now, input.sessionId, input.turn)
      this.db.exec('COMMIT')
      this.bumpRevision()
      return { summaryId, memoryResults, skipped: false }
    } catch (error: unknown) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  /** Whether one session turn already has a committed summary. */
  hasSummary(sessionId: string, turn: number): boolean {
    this.assertOpen()
    return this.db.prepare('SELECT 1 FROM summaries WHERE session_id = ? AND turn = ?')
      .get(sessionId, turn) !== undefined
  }

  /** Upsert the raw source transcript retained for one completed turn. */
  archiveTurn(input: {
    sessionId: string; turn: number; sourceEventSeqs: number[]; messages: ArchivedMessage[]
    truncated?: boolean; originalMessageCount?: number
    provider: string; model: string; status?: TurnArchive['status']; now?: number
  }): TurnArchive {
    this.assertOpen()
    const now = input.now ?? Date.now()
    const existing = this.db.prepare('SELECT id, created_at FROM turn_transcripts WHERE session_id = ? AND turn = ?')
      .get(input.sessionId, input.turn) as { id: string; created_at: number } | undefined
    const id = existing?.id ?? randomUUID()
    this.db.prepare(`
      INSERT INTO turn_transcripts(
        id, session_id, turn, source_event_seqs, messages_json, truncated, original_message_count,
        provider, model, status, error, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?)
      ON CONFLICT(session_id, turn) DO UPDATE SET
        source_event_seqs = excluded.source_event_seqs, messages_json = excluded.messages_json,
        truncated = excluded.truncated, original_message_count = excluded.original_message_count,
        provider = excluded.provider, model = excluded.model,
        status = CASE WHEN turn_transcripts.status = 'summarized' THEN 'summarized' ELSE excluded.status END,
        error = CASE WHEN turn_transcripts.status = 'summarized' THEN turn_transcripts.error ELSE NULL END,
        updated_at = excluded.updated_at
    `).run(
      id, input.sessionId, input.turn, JSON.stringify(input.sourceEventSeqs), JSON.stringify(input.messages),
      input.truncated === true ? 1 : 0, input.originalMessageCount ?? input.messages.length,
      input.provider, input.model, input.status ?? 'archived', existing?.created_at ?? now, now,
    )
    this.bumpRevision()
    return this.archive(id)!
  }

  /** Update extraction state while retaining the original turn. */
  markArchive(id: string, status: TurnArchive['status'], error?: string): void {
    this.assertOpen()
    this.db.prepare('UPDATE turn_transcripts SET status = ?, error = ?, updated_at = ? WHERE id = ?')
      .run(status, error ?? null, Date.now(), id)
    this.bumpRevision()
  }

  /** Read one archive by id, or by exact session and turn. */
  archive(id: string): TurnArchive | undefined
  archive(sessionId: string, turn: number): TurnArchive | undefined
  archive(idOrSession: string, turn?: number): TurnArchive | undefined {
    this.assertOpen()
    const row = (turn === undefined
      ? this.db.prepare('SELECT * FROM turn_transcripts WHERE id = ?').get(idOrSession)
      : this.db.prepare('SELECT * FROM turn_transcripts WHERE session_id = ? AND turn = ?').get(idOrSession, turn)) as ArchiveRow | undefined
    return row === undefined ? undefined : this.turnArchive(row)
  }

  /** Most recent failed archives available for offline extraction retry. */
  failedArchives(limit: number): TurnArchive[] {
    this.assertOpen()
    return (this.db.prepare(`
      SELECT * FROM turn_transcripts WHERE status = 'failed' ORDER BY updated_at, created_at LIMIT ?
    `).all(limit) as unknown as ArchiveRow[]).map(row => this.turnArchive(row))
  }

  /** Count retained turns by extraction state for dashboard diagnostics. */
  archiveStatusCounts(): Record<TurnArchive['status'], number> {
    this.assertOpen()
    const counts: Record<TurnArchive['status'], number> = { pending: 0, summarized: 0, failed: 0, archived: 0 }
    const rows = this.db.prepare('SELECT status, COUNT(*) AS count FROM turn_transcripts GROUP BY status')
      .all() as Array<{ status: TurnArchive['status']; count: number }>
    for (const row of rows) counts[row.status] = row.count
    return counts
  }

  private turnArchive(row: ArchiveRow): TurnArchive {
    const messages = JSON.parse(row.messages_json) as unknown
    return {
      id: row.id,
      sessionId: row.session_id,
      turn: row.turn,
      sourceEventSeqs: parseNumberArray(row.source_event_seqs),
      messages: Array.isArray(messages) ? messages as ArchivedMessage[] : [],
      truncated: row.truncated === 1,
      originalMessageCount: row.original_message_count,
      provider: row.provider,
      model: row.model,
      status: row.status,
      ...(row.error === null ? {} : { error: row.error }),
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    }
  }

  /** Delete expired archives and retain only the newest configured turns per session. */
  pruneArchives(retentionDays: number, maxTurnsPerSession: number, now = Date.now()): number {
    this.assertOpen()
    const cutoff = now - retentionDays * 86_400_000
    const expired = this.db.prepare('DELETE FROM turn_transcripts WHERE created_at < ?').run(cutoff)
    const overflow = this.db.prepare(`
      DELETE FROM turn_transcripts WHERE id IN (
        SELECT id FROM (
          SELECT id, ROW_NUMBER() OVER (PARTITION BY session_id ORDER BY turn DESC, created_at DESC) AS position
          FROM turn_transcripts
        ) WHERE position > ?
      )
    `).run(maxTurnsPerSession)
    const deleted = Number(expired.changes) + Number(overflow.changes)
    if (deleted > 0) this.bumpRevision()
    return deleted
  }

  /** Active stable facts supplied to the summarizer to keep replacement keys consistent. */
  stableFacts(limit: number): Array<{ stableKey: string; content: string; kind: MemoryKind }> {
    this.assertOpen()
    const rows = this.db.prepare(`
      SELECT stable_key, content, kind FROM memories
      WHERE stable_key IS NOT NULL AND status = 'active'
      ORDER BY importance DESC, created_at DESC LIMIT ?
    `).all(limit) as Array<{ stable_key: string; content: string; kind: MemoryKind }>
    return rows.map(row => ({
      stableKey: row.stable_key,
      content: row.content.length <= 400 ? row.content : `${row.content.slice(0, 399)}…`,
      kind: row.kind,
    }))
  }

  /** Active memory text requiring an embedding for this configured adapter. */
  memoriesForEmbedding(provider: string, model: string, limit: number): Array<{ id: string; content: string }> {
    this.assertOpen()
    return this.db.prepare(`
      SELECT m.id, m.content FROM memories m
      LEFT JOIN memory_embeddings e ON e.memory_id = m.id AND e.provider = ? AND e.model = ?
      WHERE m.status = 'active' AND e.memory_id IS NULL
      ORDER BY m.importance DESC, m.created_at DESC LIMIT ?
    `).all(provider, model, limit) as Array<{ id: string; content: string }>
  }

  /** Persist one normalized Float32 embedding for a memory. */
  putEmbedding(memoryId: string, provider: string, model: string, values: readonly number[]): void {
    this.assertOpen()
    if (values.length === 0 || values.some(value => !Number.isFinite(value))) {
      throw new Error('memory graph: embedding must contain finite values')
    }
    const magnitude = Math.hypot(...values)
    if (!Number.isFinite(magnitude) || magnitude === 0) throw new Error('memory graph: embedding magnitude must be positive')
    const normalized = Float32Array.from(values, value => value / magnitude)
    const vector = Buffer.from(normalized.buffer, normalized.byteOffset, normalized.byteLength)
    this.db.prepare(`
      INSERT INTO memory_embeddings(memory_id, provider, model, dimensions, vector, updated_at)
      VALUES (?, ?, ?, ?, ?, ?)
      ON CONFLICT(memory_id) DO UPDATE SET provider = excluded.provider, model = excluded.model,
        dimensions = excluded.dimensions, vector = excluded.vector, updated_at = excluded.updated_at
    `).run(memoryId, provider, model, normalized.length, vector, Date.now())
  }

  /** Cosine scores for a rotating bounded slice of active-memory embeddings. */
  semanticScores(provider: string, model: string, query: readonly number[], scanLimit: number): Map<string, number> {
    this.assertOpen()
    if (query.length === 0) return new Map()
    const magnitude = Math.hypot(...query)
    if (!Number.isFinite(magnitude) || magnitude === 0) return new Map()
    const normalized = Float32Array.from(query, value => value / magnitude)
    const count = (this.db.prepare(`
      SELECT COUNT(*) AS count FROM memory_embeddings e
      JOIN memories m ON m.id = e.memory_id
      WHERE e.provider = ? AND e.model = ? AND m.status = 'active'
    `).get(provider, model) as { count: number }).count
    if (count === 0) return new Map()
    const offset = this.semanticScanOffset % count
    const read = (limit: number, rowOffset: number) => this.db.prepare(`
      SELECT m.id, e.dimensions, e.vector FROM memory_embeddings e
      JOIN memories m ON m.id = e.memory_id
      WHERE e.provider = ? AND e.model = ? AND m.status = 'active'
      ORDER BY e.updated_at, m.id LIMIT ? OFFSET ?
    `).all(provider, model, limit, rowOffset) as Array<{ id: string; dimensions: number; vector: Uint8Array }>
    const first = read(Math.min(scanLimit, count), offset)
    const rows = first.length < Math.min(scanLimit, count)
      ? [...first, ...read(Math.min(scanLimit, count) - first.length, 0)]
      : first
    this.semanticScanOffset = (offset + rows.length) % count
    const scored = rows.flatMap(row => {
      if (row.dimensions !== normalized.length || row.vector.byteLength !== row.dimensions * 4) return []
      const stored = new Float32Array(row.vector.buffer, row.vector.byteOffset, row.dimensions)
      let cosine = 0
      for (let index = 0; index < stored.length; index++) cosine += stored[index]! * normalized[index]!
      return [{ id: row.id, score: Math.max(0, Math.min(1, (cosine + 1) / 2)) }]
    }).sort((left, right) => right.score - left.score)
    return new Map(scored.map(row => [row.id, row.score]))
  }

  /** Remove embeddings for memories that hybrid retrieval can no longer return. */
  pruneInactiveEmbeddings(): number {
    const result = this.db.prepare(`
      DELETE FROM memory_embeddings WHERE memory_id IN (
        SELECT id FROM memories WHERE status <> 'active'
      )
    `).run()
    return Number(result.changes)
  }

  private insertMemory(input: MemoryInput): RememberResult {
    const now = input.now ?? Date.now()
    const stableKey = input.stableKey === undefined ? null : normalizeStableKey(input.stableKey)
    const existing = stableKey === null ? undefined : this.db.prepare(`
      SELECT * FROM memories WHERE stable_key = ? AND status = 'active'
    `).get(stableKey) as MemoryRow | undefined
    if (existing !== undefined && normalizeEntity(existing.content) === normalizeEntity(input.content)) {
      return {
        memoryId: existing.id,
        entityCount: 0,
        relationCount: 0,
        deduplicated: true,
        entityConflicts: [],
      }
    }
    if (existing !== undefined) {
      this.db.prepare("UPDATE memories SET status = 'superseded', valid_to = ? WHERE id = ?")
        .run(now, existing.id)
      this.db.prepare('DELETE FROM memory_embeddings WHERE memory_id = ?').run(existing.id)
    }
    const memoryId = randomUUID()
    this.db.prepare(`
      INSERT INTO memories(
        id, content, importance, confidence, kind, stable_key, status,
        created_at, accessed_at, access_count, valid_from, valid_to, supersedes_id,
        source, source_session, source_turn, source_event_seqs, tags, graph_json
      ) VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?, 0, ?, NULL, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      memoryId,
      input.content,
      input.importance,
      input.confidence,
      input.kind,
      stableKey,
      now,
      now,
      now,
      existing?.id ?? null,
      input.source ?? null,
      input.sourceSession ?? null,
      input.sourceTurn ?? null,
      input.sourceEventSeqs === undefined ? null : JSON.stringify(input.sourceEventSeqs),
      JSON.stringify(input.tags),
      JSON.stringify({ entities: input.entities, relations: input.relations }),
    )
    const entityIds = new Map<string, string>()
    const createdEntityIds = new Set<string>()
    const entityConflicts: EntityConflict[] = []
    const ensure = (entity: EntityInput): string => {
      const normalized = normalizeEntity(entity.name)
      const cached = entityIds.get(normalized)
      if (cached !== undefined) return cached
      const ensured = this.ensureEntity(entity, entityConflicts)
      entityIds.set(normalized, ensured.id)
      for (const alias of entity.aliases ?? []) entityIds.set(normalizeEntity(alias), ensured.id)
      if (entity.canonical !== undefined) entityIds.set(normalizeEntity(entity.canonical), ensured.id)
      if (ensured.created) createdEntityIds.add(ensured.id)
      return ensured.id
    }
    for (const entity of input.entities) {
      const entityId = ensure(entity)
      this.db.prepare('INSERT OR IGNORE INTO memory_entities(memory_id, entity_id) VALUES (?, ?)')
        .run(memoryId, entityId)
    }
    let relationCount = 0
    for (const relation of input.relations) {
      const sourceId = ensure({ name: relation.source })
      const targetId = ensure({ name: relation.target })
      this.db.prepare('INSERT OR IGNORE INTO memory_entities(memory_id, entity_id) VALUES (?, ?)')
        .run(memoryId, sourceId)
      this.db.prepare('INSERT OR IGNORE INTO memory_entities(memory_id, entity_id) VALUES (?, ?)')
        .run(memoryId, targetId)
      const result = this.db.prepare(`
        INSERT OR IGNORE INTO relations(source_id, predicate, target_id, confidence, source_memory_id)
        VALUES (?, ?, ?, ?, ?)
      `).run(sourceId, this.normalizePredicate(relation.predicate), targetId, relation.confidence ?? 1, memoryId)
      relationCount += Number(result.changes)
    }
    if (existing !== undefined) this.detachInactiveMemory(existing.id)
    this.collectOrphanEntities()
    return {
      memoryId,
      entityCount: createdEntityIds.size,
      relationCount,
      deduplicated: false,
      ...(existing === undefined ? {} : { supersededMemoryId: existing.id }),
      entityConflicts,
    }
  }

  private ensureEntity(input: EntityInput, conflicts: EntityConflict[]): { id: string; created: boolean } {
    const canonical = normalizeEntity(input.canonical ?? input.name)
    const incomingName = normalizeEntity(input.name)
    const spellings = new Map<string, { display: string; mentions: number }>()
    spellings.set(incomingName, { display: input.name.trim(), mentions: 1 })
    spellings.set(canonical, { display: (input.canonical ?? input.name).trim(), mentions: canonical === incomingName ? 1 : 0 })
    for (const alias of input.aliases ?? []) {
      const normalized = normalizeEntity(alias)
      if (normalized !== '' && !spellings.has(normalized)) spellings.set(normalized, { display: alias.trim(), mentions: 0 })
    }
    if (canonical === '' || incomingName === '') throw new Error('memory graph: entity name must not be empty')
    const ownerOf = (normalized: string): string | undefined => {
      const alias = this.db.prepare('SELECT entity_id FROM entity_aliases WHERE alias_normalized = ?')
        .get(normalized) as { entity_id: string } | undefined
      if (alias !== undefined) return alias.entity_id
      const entity = this.db.prepare('SELECT id FROM entities WHERE normalized = ?').get(normalized) as { id: string } | undefined
      return entity?.id
    }
    const canonicalOwner = ownerOf(canonical)
    const nameOwner = ownerOf(incomingName)
    let id = canonicalOwner ?? nameOwner
    const created = id === undefined
    if (id === undefined) {
      id = randomUUID()
      this.db.prepare('INSERT INTO entities(id, normalized, name, kind) VALUES (?, ?, ?, ?)')
        .run(id, canonical, input.name.trim(), input.kind ?? 'concept')
    }
    for (const [alias, spelling] of spellings) {
      const current = this.db.prepare('SELECT entity_id FROM entity_aliases WHERE alias_normalized = ?')
        .get(alias) as { entity_id: string } | undefined
      if (current !== undefined && current.entity_id !== id) {
        const owner = this.db.prepare('SELECT name FROM entities WHERE id = ?').get(current.entity_id) as { name: string }
        conflicts.push({ entityId: id, field: 'alias', kept: owner.name, incoming: spelling.display })
        continue
      }
      this.db.prepare(`
        INSERT INTO entity_aliases(alias_normalized, entity_id, display_name, mentions)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(alias_normalized) DO UPDATE SET
          entity_id = excluded.entity_id,
          display_name = CASE WHEN excluded.mentions > 0 THEN excluded.display_name ELSE entity_aliases.display_name END,
          mentions = entity_aliases.mentions + excluded.mentions
      `).run(alias, id, spelling.display, spelling.mentions)
    }
    const entity = this.db.prepare('SELECT id, normalized, name, kind FROM entities WHERE id = ?').get(id) as unknown as EntityRow
    const winningName = this.db.prepare(`
      SELECT display_name FROM entity_aliases WHERE entity_id = ?
      ORDER BY preferred DESC, mentions DESC, CASE WHEN display_name = ? THEN 0 ELSE 1 END, length(display_name), display_name LIMIT 1
    `).get(id, entity.name) as { display_name: string }
    if (winningName.display_name !== entity.name) {
      this.db.prepare('UPDATE entities SET name = ? WHERE id = ?').run(winningName.display_name, id)
    }
    if (input.name.trim() !== winningName.display_name) {
      conflicts.push({ entityId: id, field: 'name', kept: winningName.display_name, incoming: input.name.trim() })
    }
    if (input.kind !== undefined) {
      this.db.prepare(`
        INSERT INTO entity_kind_votes(entity_id, kind, mentions) VALUES (?, ?, 1)
        ON CONFLICT(entity_id, kind) DO UPDATE SET mentions = mentions + 1
      `).run(id, input.kind)
      const winningKind = this.db.prepare(`
        SELECT kind FROM entity_kind_votes WHERE entity_id = ?
        ORDER BY mentions DESC, CASE WHEN kind = ? THEN 0 ELSE 1 END, kind LIMIT 1
      `).get(id, entity.kind) as { kind: string }
      if (winningKind.kind !== entity.kind) this.db.prepare('UPDATE entities SET kind = ? WHERE id = ?').run(winningKind.kind, id)
      if (input.kind !== winningKind.kind) {
        conflicts.push({ entityId: id, field: 'kind', kept: winningKind.kind, incoming: input.kind })
      }
    }
    return { id, created }
  }

  private normalizePredicate(value: string): string {
    let normalized = predicateToken(value)
    const visited = new Set<string>()
    while (this.predicateAliases.has(normalized)) {
      const next = this.predicateAliases.get(normalized)!
      if (next === normalized) return normalized
      if (visited.has(normalized)) throw new Error(`memory graph: cyclic predicate alias at "${normalized}"`)
      visited.add(normalized)
      normalized = next
    }
    return normalized
  }

  private detachInactiveMemory(memoryId: string): void {
    this.db.prepare('DELETE FROM relations WHERE source_memory_id = ?').run(memoryId)
    this.db.prepare('DELETE FROM memory_entities WHERE memory_id = ?').run(memoryId)
  }

  private collectOrphanEntities(): number {
    return Number(this.db.prepare(`
      DELETE FROM entities
      WHERE NOT EXISTS (
        SELECT 1 FROM memory_entities me JOIN memories m ON m.id = me.memory_id
        WHERE me.entity_id = entities.id AND m.status = 'active'
      ) AND NOT EXISTS (
        SELECT 1 FROM relations r LEFT JOIN memories m ON m.id = r.source_memory_id
        WHERE (r.source_id = entities.id OR r.target_id = entities.id)
          AND (r.source_memory_id IS NULL OR m.status = 'active')
      )
    `).run().changes)
  }

  /** Search active memories by lexical relevance, graph proximity, importance, recency, and prior use. */
  recall(query: string, options: RecallOptions): RecallResult[] {
    this.assertOpen()
    const now = options.now ?? Date.now()
    const candidates = new Map<string, {
      row: MemoryRow; lexical: number; semantic: number; graph: number; intent: number; reasons: Set<string>
    }>()
    const match = ftsQuery(query)
    const rawFtsRows = match === undefined ? [] : this.db.prepare(`
      SELECT m.*, bm25(memory_fts, 1.0, 0.2) AS rank
      FROM memory_fts JOIN memories m ON m.rowid = memory_fts.rowid
      WHERE memory_fts MATCH ? AND m.status = 'active' ORDER BY rank LIMIT ?
    `).all(match, Math.max(options.limit * 4, 20)) as unknown as Array<MemoryRow & { rank: number }>
    const queryTrigrams = trigrams(query)
    const ftsRows = rawFtsRows.map(row => {
      const text = `${row.content} ${parseStringArray(row.tags).join(' ')}`.normalize('NFKC').toLocaleLowerCase('en-US')
      const searchable = trigrams(text)
      const overlap = [...queryTrigrams].filter(value => searchable.has(value)).length
      const trigramCoverage = queryTrigrams.size === 0 ? 0 : overlap / queryTrigrams.size
      const terms = searchTerms(query)
      const termCoverage = terms.length === 0 ? 0 : terms.filter(term => text.includes(term)).length / terms.length
      return { row, coverage: termCoverage * 0.7 + trigramCoverage * 0.3, trigramCoverage }
    }).filter(value => value.trigramCoverage >= 0.34)
      .sort((a, b) => b.coverage - a.coverage || a.row.rank - b.row.rank)
    const normalizedQuery = normalizeEntity(query)
    const substringRows = normalizedQuery.length > 0 && normalizedQuery.length < 3
      ? this.db.prepare(`
          SELECT * FROM memories
          WHERE status = 'active' AND (instr(lower(content), ?) > 0 OR instr(lower(tags), ?) > 0)
          ORDER BY created_at DESC LIMIT ?
        `).all(normalizedQuery, normalizedQuery, Math.max(options.limit * 4, 20)) as unknown as MemoryRow[]
      : []
    const lexicalRows = [
      ...ftsRows.map(value => ({ row: value.row, score: value.coverage })),
      ...substringRows.filter(row => !ftsRows.some(value => value.row.id === row.id)).map(row => ({ row, score: 1 })),
    ]
    lexicalRows.forEach(({ row, score }) => {
      candidates.set(row.id, {
        row, lexical: Math.min(1, score * (1 + (options.lexicalOverlapBoost ?? 0))), semantic: 0, graph: 0, intent: 0,
        reasons: new Set(['lexical']),
      })
    })

    if (options.semanticScores !== undefined && options.semanticScores.size > 0) {
      const ids = [...options.semanticScores.keys()]
      const placeholders = ids.map(() => '?').join(', ')
      const rows = this.db.prepare(`SELECT * FROM memories WHERE status = 'active' AND id IN (${placeholders})`)
        .all(...ids) as unknown as MemoryRow[]
      for (const row of rows) {
        const current = candidates.get(row.id) ?? { row, lexical: 0, semantic: 0, graph: 0, intent: 0, reasons: new Set<string>() }
        current.semantic = options.semanticScores.get(row.id) ?? 0
        current.reasons.add('semantic')
        candidates.set(row.id, current)
      }
    }

    const seeds = new Set<string>()
    if (normalizedQuery.length > 0) {
      const rows = this.searchEntityIds(normalizedQuery, 12)
      rows.forEach(row => seeds.add(row.id))
    }
    const lexicalMemoryIds = lexicalRows.slice(0, options.limit * 2).map(value => value.row.id)
    if (lexicalMemoryIds.length > 0) {
      const placeholders = lexicalMemoryIds.map(() => '?').join(', ')
      const entityRows = this.db.prepare(`
        SELECT DISTINCT entity_id FROM memory_entities WHERE memory_id IN (${placeholders})
      `).all(...lexicalMemoryIds) as Array<{ entity_id: string }>
      entityRows.forEach(entity => seeds.add(entity.entity_id))
    }
    if (seeds.size > 0) {
      const walk = this.walk([...seeds], options.hops, 160)
      const entityIds = [...walk.distances.keys()]
      const placeholders = entityIds.map(() => '?').join(', ')
      const linkedRows = this.db.prepare(`
        SELECT me.entity_id, m.* FROM memory_entities me JOIN memories m ON m.id = me.memory_id
        WHERE me.entity_id IN (${placeholders}) AND m.status = 'active'
      `).all(...entityIds) as unknown as Array<MemoryRow & { entity_id: string }>
      for (const row of linkedRows) {
        const distance = walk.distances.get(row.entity_id) ?? options.hops
        const current = candidates.get(row.id) ?? { row, lexical: 0, semantic: 0, graph: 0, intent: 0, reasons: new Set<string>() }
        current.graph = Math.max(current.graph, 1 / (distance + 1))
        current.reasons.add(distance === 0 ? 'entity' : `graph:${distance}`)
        candidates.set(row.id, current)
      }
    }

    const preferenceIntent = /(?:偏好|喜欢|习惯|倾向|prefer|preference|like\b)/iu.test(query)
    const temporalIntent = /(?:何时|什么时候|最近|之前|上次|when\b|recent|previous|last time)/iu.test(query)
    for (const candidate of candidates.values()) {
      if (preferenceIntent && candidate.row.kind === 'preference') {
        candidate.intent += options.preferenceBoost ?? 0
        candidate.reasons.add('intent:preference')
      }
      if (temporalIntent && candidate.row.kind === 'event') {
        candidate.intent += options.temporalBoost ?? 0
        candidate.reasons.add('intent:temporal')
      }
    }
    const semanticActive = options.semanticScores !== undefined && options.semanticScores.size > 0
    const totalWeight = Object.entries(options.weights)
      .filter(([key]) => key !== 'semantic' || semanticActive)
      .reduce((sum, [, value]) => sum + value, 0)
    const ranked = [...candidates.values()].map((candidate) => {
      const ageDays = Math.max(0, now - candidate.row.created_at) / 86_400_000
      const recency = Math.pow(0.5, ageDays / options.halfLifeDays)
      const access = Math.min(1, Math.log1p(candidate.row.access_count) / Math.log(11))
      const baseScore = totalWeight <= 0 ? 0 : (
        candidate.lexical * options.weights.lexical
        + candidate.semantic * (semanticActive ? options.weights.semantic : 0)
        + candidate.graph * options.weights.graph
        + candidate.row.importance * options.weights.importance
        + recency * options.weights.recency
        + access * options.weights.access
      ) / totalWeight
      const intent = candidate.intent <= 0 ? 0 : candidate.intent / (1 + candidate.intent)
      const score = baseScore + (1 - baseScore) * intent
      return { candidate, score }
    }).sort((a, b) => b.score - a.score || b.candidate.row.created_at - a.candidate.row.created_at)
    const seenContent = new Set<string>()
    const deduplicated = ranked.filter(({ candidate }) => {
      const key = normalizeEntity(candidate.row.content).replace(/[^\p{L}\p{N}]+/gu, '')
      if (seenContent.has(key)) return false
      seenContent.add(key)
      return true
    }).slice(0, options.limit)

    if (options.reinforce !== false && deduplicated.length > 0) {
      const touch = this.db.prepare('UPDATE memories SET accessed_at = ?, access_count = access_count + 1 WHERE id = ?')
      this.db.exec('BEGIN IMMEDIATE')
      try {
        deduplicated.forEach(item => touch.run(now, item.candidate.row.id))
        this.db.exec('COMMIT')
      } catch (error: unknown) {
        this.db.exec('ROLLBACK')
        throw error
      }
    }

    const entitiesByMemory = this.entitiesForMemories(deduplicated.map(item => item.candidate.row.id))
    return deduplicated.map(({ candidate, score }) => ({
      id: candidate.row.id,
      content: candidate.row.content,
      score: Number(Math.min(1, score).toFixed(6)),
      importance: candidate.row.importance,
      confidence: candidate.row.confidence,
      kind: candidate.row.kind,
      ...(candidate.row.stable_key === null ? {} : { stableKey: candidate.row.stable_key }),
      createdAt: candidate.row.created_at,
      tags: parseStringArray(candidate.row.tags),
      entities: (entitiesByMemory.get(candidate.row.id) ?? []).map(entity => ({ name: entity.name, kind: entity.kind })),
      reasons: [...candidate.reasons].sort(),
    }))
  }

  /** Return a bounded entity neighborhood, or a bounded global snapshot when entity is empty. */
  graph(entity: string, hops: number, limit: number): GraphResult {
    this.assertOpen()
    const normalized = normalizeEntity(entity)
    const seeds = normalized.length === 0 ? this.globalSeeds(limit) : this.searchEntityIds(normalized, 8)
    if (seeds.length === 0) return { nodes: [], edges: [], memories: [], summaries: this.recentSummaries(8) }
    const walk = this.walk(seeds.map(seed => seed.id), hops, limit)
    const entityIds = [...walk.distances.keys()]
    const placeholders = entityIds.map(() => '?').join(', ')
    const rows = this.db.prepare(`
      SELECT m.* FROM memory_entities me JOIN memories m ON m.id = me.memory_id
      WHERE me.entity_id IN (${placeholders}) AND m.status = 'active'
      ORDER BY m.importance DESC, m.created_at DESC
    `).all(...entityIds) as unknown as MemoryRow[]
    const memoryRows = new Map<string, MemoryRow>()
    rows.forEach(row => memoryRows.set(row.id, row))
    const selectedRows = [...memoryRows.values()].slice(0, limit)
    const entitiesByMemory = this.entitiesForMemories(selectedRows.map(row => row.id))
    return {
      nodes: [...walk.entities.values()].map(row => ({
        id: row.id, name: row.name, kind: row.kind, distance: walk.distances.get(row.id) ?? 0,
      })).sort((a, b) => a.distance - b.distance || a.name.localeCompare(b.name)),
      edges: walk.relations.map(row => ({
        source: row.source_name,
        predicate: row.predicate,
        target: row.target_name,
        confidence: row.confidence,
        mentions: row.mentions,
      })),
      memories: selectedRows.map(row => this.graphMemory(row, entitiesByMemory.get(row.id) ?? [])),
      summaries: this.recentSummaries(8),
    }
  }

  private globalSeeds(limit: number): Array<{ id: string }> {
    return this.db.prepare(`
      SELECT e.id, COUNT(DISTINCT m.id) AS memory_count
      FROM entities e
      JOIN memory_entities me ON me.entity_id = e.id
      JOIN memories m ON m.id = me.memory_id AND m.status = 'active'
      GROUP BY e.id
      ORDER BY memory_count DESC, e.name
      LIMIT ?
    `).all(Math.min(limit, 24)) as Array<{ id: string }>
  }

  private searchEntityIds(normalized: string, limit: number): Array<{ id: string }> {
    const exact = this.db.prepare(`
      SELECT entity_id AS id FROM entity_aliases WHERE alias_normalized = ? LIMIT ?
    `).all(normalized, limit) as Array<{ id: string }>
    if (exact.length > 0) return exact
    return this.db.prepare(`
      SELECT DISTINCT entity_id AS id FROM entity_aliases
      WHERE instr(alias_normalized, ?) > 0 OR instr(?, alias_normalized) > 0
      ORDER BY length(alias_normalized) DESC, alias_normalized LIMIT ?
    `).all(normalized, normalized, limit) as Array<{ id: string }>
  }

  private graphMemory(row: MemoryRow, entities: EntityRow[]): GraphMemory {
    return {
      id: row.id,
      content: row.content,
      kind: row.kind,
      importance: row.importance,
      confidence: row.confidence,
      entities: entities.map(entity => entity.name),
      ...(row.source_session === null ? {} : { sourceSession: row.source_session }),
      ...(row.source_turn === null ? {} : { sourceTurn: row.source_turn }),
    }
  }

  private recentSummaries(limit: number): ConversationSummary[] {
    const rows = this.db.prepare(`
      SELECT id, session_id, turn, summary, source_event_seqs, provider, model, created_at
      FROM summaries ORDER BY created_at DESC LIMIT ?
    `).all(limit) as unknown as SummaryRow[]
    return rows.map(row => ({
      id: row.id,
      sessionId: row.session_id,
      turn: row.turn,
      summary: row.summary,
      sourceEventSeqs: parseNumberArray(row.source_event_seqs),
      provider: row.provider,
      model: row.model,
      createdAt: row.created_at,
    }))
  }

  /** Delete one memory and graph facts whose provenance is that memory. */
  forget(memoryId: string): boolean {
    this.assertOpen()
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const deleted = Number(this.db.prepare('DELETE FROM memories WHERE id = ?').run(memoryId).changes) > 0
      this.collectOrphanEntities()
      this.db.exec('COMMIT')
      if (deleted) this.bumpRevision()
      return deleted
    } catch (error: unknown) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  /** Read one active or superseded memory in full for explicit expansion. */
  memory(memoryId: string): GraphMemory | undefined {
    this.assertOpen()
    const row = this.db.prepare('SELECT * FROM memories WHERE id = ?').get(memoryId) as unknown as MemoryRow | undefined
    if (row === undefined) return undefined
    return this.graphMemory(row, this.entitiesForMemories([row.id]).get(row.id) ?? [])
  }

  /** Suggest likely duplicate entities without changing identity or aliases. */
  findDuplicateEntities(entity: string | undefined, limit: number, minScore: number): DuplicateEntityCandidate[] {
    this.assertOpen()
    const rows = this.db.prepare(`
      SELECT id, name, kind FROM entities ORDER BY name, id LIMIT 1000
    `).all() as unknown as EntityRow[]
    const aliases = this.db.prepare(`
      SELECT entity_id, display_name FROM entity_aliases ORDER BY entity_id, display_name
    `).all() as Array<{ entity_id: string; display_name: string }>
    const names = new Map<string, string[]>()
    for (const row of rows) names.set(row.id, [row.name])
    for (const alias of aliases) {
      const values = names.get(alias.entity_id)
      if (values !== undefined && !values.includes(alias.display_name)) values.push(alias.display_name)
    }
    const anchorId = entity === undefined ? undefined : this.resolveEntityId(entity)
    if (entity !== undefined && anchorId === undefined) throw new Error(`memory graph: entity "${entity}" was not found`)
    if (anchorId !== undefined && !rows.some(row => row.id === anchorId)) {
      const anchor = this.db.prepare('SELECT id, normalized, name, kind FROM entities WHERE id = ?')
        .get(anchorId) as unknown as EntityRow
      rows.splice(Math.max(0, rows.length - 1), 1, anchor)
      names.set(anchor.id, [anchor.name])
      for (const alias of aliases.filter(value => value.entity_id === anchor.id)) names.get(anchor.id)?.push(alias.display_name)
    }
    const result: DuplicateEntityCandidate[] = []
    for (let leftIndex = 0; leftIndex < rows.length; leftIndex++) {
      const left = rows[leftIndex]!
      if (anchorId !== undefined && left.id !== anchorId) continue
      for (let rightIndex = anchorId === undefined ? leftIndex + 1 : 0; rightIndex < rows.length; rightIndex++) {
        const right = rows[rightIndex]!
        if (left.id === right.id) continue
        const leftCompact = [...new Set((names.get(left.id) ?? [left.name]).map(compactEntityIdentity).filter(value => value.length >= 3))]
        const rightCompact = [...new Set((names.get(right.id) ?? [right.name]).map(compactEntityIdentity).filter(value => value.length >= 3))]
        const exact = leftCompact.some(value => rightCompact.includes(value))
        let score = exact ? 1 : 0
        let reason: DuplicateEntityCandidate['reason'] = exact ? 'separator_insensitive' : 'name_similarity'
        if (!exact) {
          const leftName = compactEntityIdentity(left.name)
          const rightName = compactEntityIdentity(right.name)
          if ([...leftName][0] !== [...rightName][0]) continue
          const maximumLength = Math.max([...leftName].length, [...rightName].length)
          if (maximumLength < 4) continue
          const maximumDistance = Math.floor(maximumLength * (1 - minScore))
          const distance = boundedLevenshtein(leftName, rightName, maximumDistance)
          if (distance === undefined) continue
          score = 1 - distance / maximumLength
          reason = 'name_similarity'
        }
        if (score < minScore) continue
        result.push({
          left: { id: left.id, name: left.name, kind: left.kind },
          right: { id: right.id, name: right.name, kind: right.kind },
          score: Number(score.toFixed(4)),
          reason,
        })
      }
    }
    return result.sort((a, b) => b.score - a.score || a.left.name.localeCompare(b.left.name)
      || a.right.name.localeCompare(b.right.name)).slice(0, limit)
  }

  /** Fold a source entity into a target entity and redirect every alias and graph edge. */
  mergeEntities(target: string, source: string): EntityMergeResult {
    this.assertOpen()
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const targetId = this.resolveEntityId(target)
      const sourceId = this.resolveEntityId(source)
      if (targetId === undefined) throw new Error(`memory graph: target entity "${target}" was not found`)
      if (sourceId === undefined) throw new Error(`memory graph: source entity "${source}" was not found`)
      if (targetId === sourceId) {
        this.db.exec('COMMIT')
        return { entityId: targetId, memoryLinksMoved: 0, relationsMoved: 0 }
      }
      const moved = this.mergeEntityIds(targetId, sourceId)
      this.db.exec('COMMIT')
      this.bumpRevision()
      return { entityId: targetId, mergedEntityId: sourceId, ...moved }
    } catch (error: unknown) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  /** Change an entity's preferred display name while retaining old and new aliases. */
  renameEntity(entity: string, name: string): { entityId: string; previousName: string; name: string } {
    this.assertOpen()
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const id = this.resolveEntityId(entity)
      if (id === undefined) throw new Error(`memory graph: entity "${entity}" was not found`)
      const row = this.db.prepare('SELECT name FROM entities WHERE id = ?').get(id) as { name: string }
      const alias = normalizeEntity(name)
      const owner = this.db.prepare('SELECT entity_id FROM entity_aliases WHERE alias_normalized = ?').get(alias) as
        | { entity_id: string }
        | undefined
      if (owner !== undefined && owner.entity_id !== id) {
        throw new Error(`memory graph: alias "${name}" belongs to another entity; merge the entities instead`)
      }
      this.db.prepare('UPDATE entity_aliases SET preferred = 0 WHERE entity_id = ?').run(id)
      this.db.prepare(`
        INSERT INTO entity_aliases(alias_normalized, entity_id, display_name, mentions, preferred) VALUES (?, ?, ?, 0, 1)
        ON CONFLICT(alias_normalized) DO UPDATE SET display_name = excluded.display_name, preferred = 1
      `).run(alias, id, name)
      this.db.prepare('UPDATE entities SET name = ? WHERE id = ?').run(name, id)
      this.db.exec('COMMIT')
      this.bumpRevision()
      return { entityId: id, previousName: row.name, name }
    } catch (error: unknown) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  /** Delete one graph entity without deleting the text memories that mentioned it. */
  deleteEntity(entity: string): { deleted: boolean; memoryLinksDeleted: number; relationsDeleted: number } {
    this.assertOpen()
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const id = this.resolveEntityId(entity)
      if (id === undefined) {
        this.db.exec('COMMIT')
        return { deleted: false, memoryLinksDeleted: 0, relationsDeleted: 0 }
      }
      const memoryLinksDeleted = (this.db.prepare('SELECT COUNT(*) AS count FROM memory_entities WHERE entity_id = ?')
        .get(id) as { count: number }).count
      const relationsDeleted = (this.db.prepare('SELECT COUNT(*) AS count FROM relations WHERE source_id = ? OR target_id = ?')
        .get(id, id) as { count: number }).count
      this.db.prepare('DELETE FROM entities WHERE id = ?').run(id)
      this.db.exec('COMMIT')
      this.bumpRevision()
      return { deleted: true, memoryLinksDeleted, relationsDeleted }
    } catch (error: unknown) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  /** List entities that are not reachable from any active memory or active relation. */
  listOrphans(limit: number): OrphanEntity[] {
    this.assertOpen()
    return this.db.prepare(`
      SELECT e.id, e.name, e.kind FROM entities e
      WHERE NOT EXISTS (
        SELECT 1 FROM memory_entities me JOIN memories m ON m.id = me.memory_id
        WHERE me.entity_id = e.id AND m.status = 'active'
      ) AND NOT EXISTS (
        SELECT 1 FROM relations r LEFT JOIN memories m ON m.id = r.source_memory_id
        WHERE (r.source_id = e.id OR r.target_id = e.id)
          AND (r.source_memory_id IS NULL OR m.status = 'active')
      ) ORDER BY e.name LIMIT ?
    `).all(limit) as unknown as OrphanEntity[]
  }

  /** Restore the directly superseded value of one currently active stable fact. */
  revert(memoryId: string, now = Date.now()): RevertResult {
    this.assertOpen()
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const current = this.db.prepare(`
        SELECT * FROM memories WHERE id = ? AND status = 'active' AND stable_key IS NOT NULL
      `).get(memoryId) as MemoryRow | undefined
      if (current === undefined) throw new Error('memory graph: active stable memory was not found')
      if (current.supersedes_id === null) throw new Error('memory graph: memory has no previous version')
      const previous = this.db.prepare('SELECT * FROM memories WHERE id = ?').get(current.supersedes_id) as MemoryRow | undefined
      if (previous === undefined || previous.stable_key !== current.stable_key) {
        throw new Error('memory graph: previous stable memory is unavailable')
      }
      this.db.prepare("UPDATE memories SET status = 'superseded', valid_to = ? WHERE id = ?").run(now, current.id)
      this.db.prepare('DELETE FROM memory_embeddings WHERE memory_id = ?').run(current.id)
      this.detachInactiveMemory(current.id)
      this.db.prepare("UPDATE memories SET status = 'active', valid_to = NULL WHERE id = ?").run(previous.id)
      const graph = JSON.parse(previous.graph_json) as { entities: EntityInput[]; relations: Array<{ source: string; predicate: string; target: string; confidence?: number }> }
      this.attachGraph(previous.id, graph.entities, graph.relations)
      this.collectOrphanEntities()
      this.db.exec('COMMIT')
      this.bumpRevision()
      return { restoredMemoryId: previous.id, supersededMemoryId: current.id }
    } catch (error: unknown) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  /** Export an exact, empty-database-restorable JSONL snapshot. */
  exportJsonl(path: string): { path: string; records: number } {
    this.assertOpen()
    const tables = [
      'entities', 'entity_aliases', 'entity_kind_votes', 'memories', 'memory_entities', 'relations', 'summaries',
      'turn_transcripts', 'memory_embeddings',
    ] as const
    const lines = [JSON.stringify({
      type: 'header', format: 'dsh-memory-graph-jsonl', version: BACKUP_FORMAT_VERSION, schemaVersion: SCHEMA_VERSION,
    })]
    for (const table of tables) {
      const order = table === 'memories' ? ' ORDER BY created_at, rowid' : table === 'relations' ? ' ORDER BY id' : ''
      const rows = this.db.prepare(`SELECT * FROM ${table}${order}`).all() as Array<Record<string, unknown>>
      for (const row of rows) lines.push(JSON.stringify({ type: table, row: backupRow(row) }))
    }
    mkdirSync(dirname(path), { recursive: true, mode: 0o700 })
    writeFileSync(path, `${lines.join('\n')}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    return { path, records: lines.length - 1 }
  }

  /** Restore a JSONL snapshot only when the current database contains no user data. */
  importJsonl(path: string): { path: string; records: number } {
    this.assertOpen()
    const dataCount = (this.db.prepare('SELECT COUNT(*) AS count FROM memories').get() as { count: number }).count
      + (this.db.prepare('SELECT COUNT(*) AS count FROM entities').get() as { count: number }).count
      + (this.db.prepare('SELECT COUNT(*) AS count FROM summaries').get() as { count: number }).count
      + (this.db.prepare('SELECT COUNT(*) AS count FROM turn_transcripts').get() as { count: number }).count
    if (dataCount !== 0) throw new Error('memory graph: JSONL restore requires an empty database')
    const lines = readFileSync(path, 'utf8').split(/\r?\n/u).filter(line => line.trim() !== '')
    const parsed = lines.map((line, index) => {
      try {
        return JSON.parse(line) as {
          type: string; row?: Record<string, unknown>; format?: string; version?: number; schemaVersion?: number
        }
      } catch {
        throw new Error(`memory graph: invalid JSONL at line ${index + 1}`)
      }
    })
    const header = parsed.shift()
    if (header?.type !== 'header' || header.format !== 'dsh-memory-graph-jsonl' || header.version !== BACKUP_FORMAT_VERSION) {
      throw new Error('memory graph: unsupported JSONL backup header')
    }
    if (header.schemaVersion !== undefined && header.schemaVersion > SCHEMA_VERSION) {
      throw new Error(`memory graph: backup schema ${header.schemaVersion} is newer than ${SCHEMA_VERSION}`)
    }
    const order = [
      'entities', 'entity_aliases', 'entity_kind_votes', 'memories', 'memory_entities', 'relations', 'summaries',
      'turn_transcripts', 'memory_embeddings',
    ] as const
    this.db.exec('BEGIN IMMEDIATE')
    try {
      let records = 0
      for (const table of order) {
        const schema = this.db.prepare(`PRAGMA table_info(${table})`).all() as Array<{
          name: string; notnull: number; dflt_value: string | null; pk: number
        }>
        const allowed = new Set(schema.map(column => column.name))
        const inserts = new Map<string, ReturnType<DatabaseSync['prepare']>>()
        for (const record of parsed.filter(value => value.type === table)) {
          if (record.row === undefined) throw new Error(`memory graph: ${table} backup record has no row`)
          const row = { ...record.row }
          if (table === 'memories' && !Object.hasOwn(row, 'valid_from') && typeof row.created_at === 'number') {
            row.valid_from = row.created_at
          }
          const unknownColumn = Object.keys(row).find(column => !allowed.has(column))
          if (unknownColumn !== undefined) {
            throw new Error(`memory graph: ${table} backup contains unknown column "${unknownColumn}"`)
          }
          const missing = schema.find(column => !Object.hasOwn(row, column.name)
            && (column.pk > 0 || (column.notnull === 1 && column.dflt_value === null)))
          if (missing !== undefined) {
            throw new Error(`memory graph: ${table} backup is missing required column "${missing.name}"`)
          }
          const columns = schema.map(column => column.name).filter(column => Object.hasOwn(row, column))
          const key = columns.join(',')
          let insert = inserts.get(key)
          if (insert === undefined) {
            const placeholders = columns.map(() => '?').join(', ')
            insert = this.db.prepare(`INSERT INTO ${table}(${columns.join(', ')}) VALUES (${placeholders})`)
            inserts.set(key, insert)
          }
          insert.run(...columns.map(column => backupSqlValue(row[column], table, column)))
          records++
        }
      }
      const known = new Set<string>(['header', ...order])
      const unknown = parsed.find(record => !known.has(record.type))
      if (unknown !== undefined) throw new Error(`memory graph: unknown JSONL record type "${unknown.type}"`)
      this.db.exec('COMMIT')
      if (records > 0) this.bumpRevision()
      return { path, records }
    } catch (error: unknown) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  private attachGraph(
    memoryId: string,
    entities: EntityInput[],
    relations: Array<{ source: string; predicate: string; target: string; confidence?: number }>,
  ): void {
    const conflicts: EntityConflict[] = []
    const cache = new Map<string, string>()
    const ensure = (entity: EntityInput): string => {
      const key = normalizeEntity(entity.name)
      const cached = cache.get(key)
      if (cached !== undefined) return cached
      const result = this.ensureEntity(entity, conflicts)
      cache.set(key, result.id)
      return result.id
    }
    for (const entity of entities) {
      const id = ensure(entity)
      this.db.prepare('INSERT OR IGNORE INTO memory_entities(memory_id, entity_id) VALUES (?, ?)').run(memoryId, id)
    }
    for (const relation of relations) {
      const sourceId = ensure({ name: relation.source })
      const targetId = ensure({ name: relation.target })
      this.db.prepare('INSERT OR IGNORE INTO memory_entities(memory_id, entity_id) VALUES (?, ?)').run(memoryId, sourceId)
      this.db.prepare('INSERT OR IGNORE INTO memory_entities(memory_id, entity_id) VALUES (?, ?)').run(memoryId, targetId)
      this.db.prepare(`
        INSERT OR IGNORE INTO relations(source_id, predicate, target_id, confidence, source_memory_id)
        VALUES (?, ?, ?, ?, ?)
      `).run(sourceId, this.normalizePredicate(relation.predicate), targetId, relation.confidence ?? 1, memoryId)
    }
  }

  private resolveEntityId(value: string): string | undefined {
    const direct = this.db.prepare('SELECT id FROM entities WHERE id = ?').get(value) as { id: string } | undefined
    if (direct !== undefined) return direct.id
    const alias = this.db.prepare('SELECT entity_id FROM entity_aliases WHERE alias_normalized = ?')
      .get(normalizeEntity(value)) as { entity_id: string } | undefined
    return alias?.entity_id
  }

  private mergeEntityIds(targetId: string, sourceId: string): { memoryLinksMoved: number; relationsMoved: number } {
    if (targetId === sourceId) return { memoryLinksMoved: 0, relationsMoved: 0 }
    const target = this.db.prepare('SELECT id FROM entities WHERE id = ?').get(targetId)
    const source = this.db.prepare('SELECT id FROM entities WHERE id = ?').get(sourceId)
    if (target === undefined || source === undefined) throw new Error('memory graph: cannot merge a missing entity')
    const memoryLinksMoved = Number(this.db.prepare(`
      INSERT OR IGNORE INTO memory_entities(memory_id, entity_id)
      SELECT memory_id, ? FROM memory_entities WHERE entity_id = ?
    `).run(targetId, sourceId).changes)
    this.db.prepare('DELETE FROM memory_entities WHERE entity_id = ?').run(sourceId)
    const relationRows = this.db.prepare(`
      SELECT source_id, predicate, target_id, confidence, source_memory_id
      FROM relations WHERE source_id = ? OR target_id = ?
    `).all(sourceId, sourceId) as Array<{
      source_id: string; predicate: string; target_id: string; confidence: number; source_memory_id: string | null
    }>
    const insertRelation = this.db.prepare(`
      INSERT OR IGNORE INTO relations(source_id, predicate, target_id, confidence, source_memory_id)
      VALUES (?, ?, ?, ?, ?)
    `)
    let relationsMoved = 0
    for (const relation of relationRows) {
      relationsMoved += Number(insertRelation.run(
        relation.source_id === sourceId ? targetId : relation.source_id,
        relation.predicate,
        relation.target_id === sourceId ? targetId : relation.target_id,
        relation.confidence,
        relation.source_memory_id,
      ).changes)
    }
    this.db.prepare('DELETE FROM relations WHERE source_id = ? OR target_id = ?').run(sourceId, sourceId)
    this.db.prepare('UPDATE entity_aliases SET preferred = 0 WHERE entity_id = ?').run(sourceId)
    this.db.prepare('UPDATE entity_aliases SET entity_id = ? WHERE entity_id = ?').run(targetId, sourceId)
    const kinds = this.db.prepare('SELECT kind, mentions FROM entity_kind_votes WHERE entity_id = ?')
      .all(sourceId) as Array<{ kind: string; mentions: number }>
    for (const kind of kinds) {
      this.db.prepare(`
        INSERT INTO entity_kind_votes(entity_id, kind, mentions) VALUES (?, ?, ?)
        ON CONFLICT(entity_id, kind) DO UPDATE SET mentions = mentions + excluded.mentions
      `).run(targetId, kind.kind, kind.mentions)
    }
    this.db.prepare('DELETE FROM entity_kind_votes WHERE entity_id = ?').run(sourceId)
    this.db.prepare('DELETE FROM entities WHERE id = ?').run(sourceId)
    this.refreshEntityIdentity(targetId)
    return { memoryLinksMoved, relationsMoved }
  }

  private refreshEntityIdentity(entityId: string): void {
    const current = this.db.prepare('SELECT name, kind FROM entities WHERE id = ?').get(entityId) as
      | { name: string; kind: string }
      | undefined
    if (current === undefined) return
    const name = this.db.prepare(`
      SELECT display_name FROM entity_aliases WHERE entity_id = ?
      ORDER BY preferred DESC, mentions DESC, CASE WHEN display_name = ? THEN 0 ELSE 1 END, length(display_name), display_name LIMIT 1
    `).get(entityId, current.name) as { display_name: string } | undefined
    const kind = this.db.prepare(`
      SELECT kind FROM entity_kind_votes WHERE entity_id = ?
      ORDER BY mentions DESC, CASE WHEN kind = ? THEN 0 ELSE 1 END, kind LIMIT 1
    `).get(entityId, current.kind) as { kind: string } | undefined
    this.db.prepare('UPDATE entities SET name = ?, kind = ? WHERE id = ?')
      .run(name?.display_name ?? current.name, kind?.kind ?? current.kind, entityId)
  }

  private entitiesForMemories(memoryIds: string[]): Map<string, EntityRow[]> {
    const result = new Map<string, EntityRow[]>()
    if (memoryIds.length === 0) return result
    const placeholders = memoryIds.map(() => '?').join(', ')
    const rows = this.db.prepare(`
      SELECT me.memory_id, e.id, e.normalized, e.name, e.kind FROM memory_entities me
      JOIN entities e ON e.id = me.entity_id
      WHERE me.memory_id IN (${placeholders}) ORDER BY me.memory_id, e.name
    `).all(...memoryIds) as unknown as Array<EntityRow & { memory_id: string }>
    for (const row of rows) {
      const values = result.get(row.memory_id) ?? []
      values.push(row)
      result.set(row.memory_id, values)
    }
    return result
  }

  private walk(seedIds: string[], hops: number, limit: number): WalkResult {
    const distances = new Map<string, number>()
    const entities = new Map<string, EntityRow>()
    const relations = new Map<number, RelationRow>()
    let frontier = [...new Set(seedIds)]
    frontier.forEach(id => distances.set(id, 0))
    for (let depth = 0; depth <= hops && frontier.length > 0 && entities.size < limit; depth++) {
      const next: string[] = []
      const placeholders = frontier.map(() => '?').join(', ')
      const entityRows = this.db.prepare(`
        SELECT id, normalized, name, kind FROM entities WHERE id IN (${placeholders})
      `).all(...frontier) as unknown as EntityRow[]
      entityRows.forEach(row => entities.set(row.id, row))
      if (depth < hops) {
        const adjacentRows = this.db.prepare(`
          SELECT MIN(r.id) AS id, r.source_id, s.name AS source_name, r.predicate,
                 r.target_id, t.name AS target_name, MAX(r.confidence) AS confidence,
                 COUNT(*) AS mentions
          FROM relations r
          JOIN entities s ON s.id = r.source_id
          JOIN entities t ON t.id = r.target_id
          LEFT JOIN memories m ON m.id = r.source_memory_id
          WHERE (r.source_id IN (${placeholders}) OR r.target_id IN (${placeholders}))
            AND (r.source_memory_id IS NULL OR m.status = 'active')
          GROUP BY r.source_id, r.predicate, r.target_id
          ORDER BY MIN(r.id) LIMIT ?
        `).all(...frontier, ...frontier, Math.max(limit * 4, 32)) as unknown as RelationRow[]
        const frontierSet = new Set(frontier)
        for (const row of adjacentRows) {
          relations.set(row.id, row)
          const neighbor = frontierSet.has(row.source_id) ? row.target_id : row.source_id
          if (!distances.has(neighbor) && distances.size < limit) {
            distances.set(neighbor, depth + 1)
            next.push(neighbor)
          }
        }
      }
      frontier = [...new Set(next)]
    }
    const missing = [...distances.keys()].filter(id => !entities.has(id))
    if (missing.length > 0) {
      const placeholders = missing.map(() => '?').join(', ')
      const rows = this.db.prepare(`SELECT id, normalized, name, kind FROM entities WHERE id IN (${placeholders})`)
        .all(...missing) as unknown as EntityRow[]
      rows.forEach(row => entities.set(row.id, row))
    }
    const visible = new Set(entities.keys())
    return {
      distances,
      entities,
      relations: [...relations.values()].filter(row => visible.has(row.source_id) && visible.has(row.target_id)),
    }
  }

  /** Close the database idempotently. */
  close(): void {
    if (this.closed) return
    this.closed = true
    try {
      this.db.exec('PRAGMA optimize')
    } finally {
      this.db.close()
    }
  }

  /** Stable validator for one process lifetime and graph-visible revision. */
  visualizationEtag(): string {
    this.assertOpen()
    const { data_version: dataVersion } = this.db.prepare('PRAGMA data_version').get() as { data_version: number }
    return `"${this.instanceId}-${this.revision}-${dataVersion}"`
  }

  private bumpRevision(): void {
    this.revision++
  }

  private assertOpen(): void {
    if (this.closed) throw new Error('memory graph store is closed')
  }
}
