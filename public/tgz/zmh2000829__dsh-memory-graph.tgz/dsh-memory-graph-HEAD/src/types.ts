/** One entity attached to a memory. */
export interface EntityInput {
  name: string
  kind?: string
  /** Stable preferred identity used to fold this spelling into an existing entity. */
  canonical?: string
  /** Other known spellings that should resolve to the same entity. */
  aliases?: string[]
}

/** One directed knowledge-graph relation. */
export interface RelationInput {
  source: string
  predicate: string
  target: string
  confidence?: number
}

/** Durable memory categories produced by people or the dialogue summarizer. */
export type MemoryKind = 'preference' | 'fact' | 'decision' | 'constraint' | 'lesson' | 'event' | 'summary'

/** One memory accepted by the durable store. */
export interface MemoryInput {
  content: string
  importance: number
  confidence: number
  kind: MemoryKind
  stableKey?: string
  tags: string[]
  entities: EntityInput[]
  relations: RelationInput[]
  source?: string
  sourceSession?: string
  sourceTurn?: number
  sourceEventSeqs?: number[]
  now?: number
}

/** Result of inserting or deterministically deduplicating one memory. */
export interface RememberResult {
  memoryId: string
  entityCount: number
  relationCount: number
  deduplicated: boolean
  supersededMemoryId?: string
  entityConflicts: EntityConflict[]
}

/** One entity display-name or kind vote that did not become the current winner. */
export interface EntityConflict {
  entityId: string
  field: 'name' | 'kind' | 'alias'
  kept: string
  incoming: string
}

/** Result of folding one entity and all of its aliases and graph edges into another. */
export interface EntityMergeResult {
  entityId: string
  mergedEntityId?: string
  memoryLinksMoved: number
  relationsMoved: number
}

/** One conservative duplicate-entity suggestion that still requires an explicit merge. */
export interface DuplicateEntityCandidate {
  left: { id: string; name: string; kind: string }
  right: { id: string; name: string; kind: string }
  score: number
  reason: 'separator_insensitive' | 'name_similarity'
}

/** One entity without any active memory or relation reference. */
export interface OrphanEntity {
  id: string
  name: string
  kind: string
}

/** Result of restoring the previous value of a stable fact. */
export interface RevertResult {
  restoredMemoryId: string
  supersededMemoryId: string
}

/** Ranking weights for hybrid retrieval. */
export interface RetrievalWeights {
  lexical: number
  semantic: number
  graph: number
  importance: number
  recency: number
  access: number
}

/** One stored memory returned by hybrid retrieval. */
export interface RecallResult {
  id: string
  content: string
  score: number
  importance: number
  confidence: number
  kind: MemoryKind
  stableKey?: string
  createdAt: number
  tags: string[]
  entities: Array<{ name: string; kind: string }>
  reasons: string[]
}

/** One archived source message retained locally for later inspection or retry. */
export interface ArchivedMessage {
  seq: number
  role: 'user' | 'assistant' | 'tool'
  text: string
  toolName?: string
}

/** One locally archived completed turn. */
export interface TurnArchive {
  id: string
  sessionId: string
  turn: number
  sourceEventSeqs: number[]
  messages: ArchivedMessage[]
  /** Whether the retained source was clipped by the configured archive budget. */
  truncated: boolean
  /** Message count before the archive budget was applied. */
  originalMessageCount: number
  provider: string
  model: string
  status: 'pending' | 'summarized' | 'failed' | 'archived'
  error?: string
  createdAt: number
  updatedAt: number
}

/** One model-produced summary of a completed conversation turn. */
export interface ConversationSummary {
  id: string
  sessionId: string
  turn: number
  summary: string
  sourceEventSeqs: number[]
  provider: string
  model: string
  createdAt: number
}

/** One memory displayed alongside a graph snapshot. */
export interface GraphMemory {
  id: string
  content: string
  kind: MemoryKind
  importance: number
  confidence: number
  entities: string[]
  sourceSession?: string
  sourceTurn?: number
}

/** A bounded graph neighborhood plus recent dialogue summaries. */
export interface GraphResult {
  nodes: Array<{ id: string; name: string; kind: string; distance: number }>
  edges: Array<{ source: string; predicate: string; target: string; confidence: number; mentions?: number }>
  memories: GraphMemory[]
  summaries: ConversationSummary[]
}

/** Validated structured output from one background dialogue-summary call. */
export interface ExtractedTurnSummary {
  summary: string
  memories: Array<{
    content: string
    kind: MemoryKind
    importance: number
    confidence: number
    stableKey?: string
    tags: string[]
    entities: EntityInput[]
    relations: RelationInput[]
  }>
}

/** Exact durable provenance for one automatic summary transaction. */
export interface SummaryCommitInput {
  sessionId: string
  turn: number
  sourceEventSeqs: number[]
  provider: string
  model: string
  requestJson: string
  responseJson: string
  extracted: ExtractedTurnSummary
  minConfidence: number
  now?: number
}
