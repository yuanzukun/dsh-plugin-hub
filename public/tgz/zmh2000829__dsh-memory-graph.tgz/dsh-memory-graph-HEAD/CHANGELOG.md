# Changelog

All notable changes to `dsh-memory-graph` are documented here.

## 0.8.1 - 2026-08-23

### Changed

- The Memory dashboard now starts collapsed by default and remains available from the sidebar.

## 0.8.0 - 2026-08-20

### Changed

- The sidebar is now a value-first Memory dashboard that explains recall, learning, scope, and the effect of each stored memory category.
- The knowledge graph is a collapsed advanced inspection view instead of the primary dashboard content.
- The composer control now matches native DSH picker dimensions and typography, and shows the effective `On`, `Off`, or `Mixed` state instead of an ambiguous `Default` label.
- The dashboard distinguishes durable memories from audit summaries and reports pending or failed turn extraction instead of presenting an unexplained empty memory list.
- Extraction accepts an optional exact-model reasoning effort and defaults to a 3,200-token output budget after real profile archives showed structured extraction reaching the former cap. The effort remains unset unless the selected model advertises it.

## 0.7.0 - 2026-08-19

### Added

- Profile-wide graph scope, entity/edge legend, archive clipping state, and dominant-user-language summary guidance in DSH Web.
- Configurable archive token/character budgets, 30-day retention, per-session archive caps, and bounded startup retry for failed extraction.
- Query embedding TTL cache, short query timeout, endpoint failure cooldown, and deduplicating background write-side indexing.

### Changed

- Database schema v6 records archive clipping and the original message count.
- Semantic candidate scans rotate through the index instead of permanently favoring high-importance recent rows.
- Intent signals now use a bounded monotonic boost that preserves ordering instead of saturating high scores at `1.0`.
- Supersede and revert remove inactive embeddings; restored memories are scheduled for reindexing.
- Semantic-only weight configurations are rejected because fail-open recall requires at least one local ranking signal. Store-level scoring also guards against a zero denominator.

## 0.6.0 - 2026-08-19

### Added

- DSH composer control for `Default`, `On this turn`, and `Off this turn`, with one-turn latching and automatic reset.
- Dashboard configuration status and confirmed memory deletion through a same-origin token-protected action route.
- Optional OpenAI-compatible semantic embeddings, incremental indexing, manual reindexing, and lexical/graph fallback.
- Local raw turn archives, optional bounded tool-result capture, `memory_archive_expand`, and offline extraction retry.
- Retryable SQLite write outbox with ordered startup replay and dead-letter handling.
- CJK-aware token budgets, preference/temporal intent boost, lexical overlap boost, recall deduplication, and layered `memory_expand` reads.

### Changed

- Database schema v5 stores turn transcripts and memory embeddings; exact JSONL backup now includes both tables.
- Deterministic summary-validation failures are no longer retried; transient provider and transport failures retain bounded retry.
- DSH Web now exposes global defaults and failure/fallback status instead of requiring users to inspect `cordis.patch.yml`.

### Security

- Semantic text leaves the host only when explicitly enabled; tool-result capture remains off by default.
- Dashboard mutations require same-origin JSON POST plus a process-random token returned only by the protected snapshot route.

## 0.5.0 - 2026-08-19

### Added

- Conservative `memory_entity_find_duplicates` suggestions that never mutate the graph.
- Configurable predicate aliases.
- Global summary concurrency and bounded retry policy.
- Snapshot ETags and mention counts for aggregated logical edges.

### Changed

- Shared supplemental aliases report a conflict instead of implicitly merging entities.
- Manual entity rename uses an explicit preferred spelling rather than synthetic occurrence counts.
- JSONL restore uses schema defaults for compatible missing columns and records the source schema version.
- Exact alias lookup avoids substring scans on the common path; SQLite statistics are optimized on clean shutdown.
- Dashboard polling pauses in hidden pages and skips unchanged React state updates.

### Security

- JSONL import rejects backup-file symlinks that resolve outside the configured real backup directory.

## 0.4.0 - 2026-08-18

- Added canonical entities and aliases, CJK trigram retrieval, entity maintenance tools, stable-memory revert, JSONL backup, automatic dialogue summaries, and the standalone DSH Web graph.
