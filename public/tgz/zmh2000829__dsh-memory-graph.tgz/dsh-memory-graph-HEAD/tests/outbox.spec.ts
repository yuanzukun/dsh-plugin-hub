import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'
import { MemoryOutbox, isRetryableStoreError } from '../src/outbox.ts'
import { MemoryGraphStore } from '../src/store.ts'

describe('memory write outbox', () => {
  it('replays a queued write once and removes it', () => {
    const directory = join(mkdtempSync(join(tmpdir(), 'memory-outbox-')), 'pending')
    const outbox = new MemoryOutbox(directory)
    outbox.enqueue({
      type: 'remember',
      payload: {
        content: 'Replay this memory.', importance: 0.5, confidence: 1, kind: 'fact',
        tags: [], entities: [], relations: [],
      },
    })
    const store = new MemoryGraphStore(':memory:')
    expect(outbox.replay(store)).toEqual({ replayed: 1, pending: 0, deadLettered: 0 })
    expect(store.recall('Replay memory', {
      limit: 2, hops: 0, halfLifeDays: 30,
      weights: { lexical: 1, semantic: 0, graph: 0, importance: 0, recency: 0, access: 0 },
    })).toHaveLength(1)
    store.close()
  })

  it('classifies transient SQLite failures without retrying constraints', () => {
    expect(isRetryableStoreError(Object.assign(new Error('database is locked'), { code: 'SQLITE_BUSY' }))).toBe(true)
    expect(isRetryableStoreError(Object.assign(new Error('constraint failed'), { code: 'SQLITE_CONSTRAINT' }))).toBe(false)
  })
})
