import { Context } from '@deepseek-ai/cordis'
import AgentRegistry, { agentEvents } from '@deepseek-ai/dsh-agent'
import type { Agent } from '@deepseek-ai/dsh-agent'
import LlmRuntime, { CallId, createMessage, createToolResultMessage, createUserMessage, LlmAdapter } from '@deepseek-ai/dsh-llm'
import type { GenerateOptions, StreamChunk } from '@deepseek-ai/dsh-llm'
import SessionStore, { SessionId } from '@deepseek-ai/dsh-session'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import { mkdirSync, mkdtempSync, symlinkSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it, vi } from 'vitest'
import * as MemoryGraph from '../src/index.ts'
import type { Config } from '../src/index.ts'
import { MemoryGraphStore } from '../src/store.ts'
import { AutoSummarizer, collectTurnTranscript } from '../src/summarizer.ts'

const config = (autoRecall: boolean, overrides: Partial<Config> = {}): Config => ({
  enabled: true,
  path: ':memory:',
  outboxDirectory: join(mkdtempSync(join(tmpdir(), 'dsh-memory-outbox-')), 'outbox'),
  autoRecall,
  autoRecallLimit: 4,
  autoRecallMinScore: 0,
  maxContextChars: 2000,
  maxContextTokens: 1000,
  recallPreviewTokens: 220,
  maxQueryChars: 1000,
  halfLifeDays: 30,
  maxGraphHops: 2,
  predicateAliases: {},
  preferenceBoost: 0.12,
  temporalBoost: 0.08,
  lexicalOverlapBoost: 0.15,
  autoSummarize: false,
  archiveTurns: true,
  archiveMaxInputChars: 100_000,
  archiveMaxInputTokens: 30_000,
  archiveRetentionDays: 30,
  archiveMaxTurnsPerSession: 200,
  captureToolResults: false,
  toolResultMaxTokens: 500,
  summarizeEveryTurns: 1,
  summaryMaxInputChars: 16_000,
  summaryMaxInputTokens: 6000,
  summaryMaxOutputTokens: 1800,
  summaryTimeoutMs: 60_000,
  summaryMaxMemories: 8,
  summaryMinConfidence: 0.65,
  summaryBackfillTurns: 3,
  summaryConcurrency: 2,
  summaryMaxAttempts: 2,
  summaryRetryBaseMs: 0,
  summaryRetryFailedOnStart: 0,
  summaryLanguage: 'auto',
  semanticEnabled: false,
  semanticEndpoint: 'https://api.openai.com/v1/embeddings',
  semanticModel: 'text-embedding-3-small',
  semanticApiKeyEnv: 'OPENAI_API_KEY',
  semanticTimeoutMs: 20_000,
  semanticQueryTimeoutMs: 3500,
  semanticQueryCacheMs: 300_000,
  semanticFailureCooldownMs: 60_000,
  semanticScanLimit: 2000,
  visualizationEnabled: true,
  visualizationAutoOpen: false,
  visualizationRefreshMs: 5000,
  visualizationHops: 2,
  visualizationLimit: 100,
  visualizationTrustedHosts: [],
  weights: { lexical: 0.4, semantic: 0.3, graph: 0.25, importance: 0.2, recency: 0.1, access: 0.05 },
  ...overrides,
})

async function setup(autoRecall: boolean, overrides: Partial<Config> = {}) {
  const ctx = new Context()
  await ctx.plugin(LlmRuntime)
  await ctx.plugin(SessionStore)
  await ctx.plugin(AgentRegistry)
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  const fiber = await ctx.plugin(MemoryGraph, config(autoRecall, overrides))
  return { ctx, fiber }
}

class SummaryAdapter extends LlmAdapter {
  readonly requests: GenerateOptions[] = []

  override async * stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    this.requests.push(options)
    const value = JSON.stringify({
      summary: 'The user chose the balanced profile and wants concise answers.',
      memories: [{
        content: 'The user prefers concise answers.', kind: 'preference', importance: 0.9, confidence: 0.96,
        stableKey: 'user.preference.answer-style', tags: ['style'],
        entities: [{ name: 'User', kind: 'person' }, { name: 'concise answers', kind: 'preference' }],
        relations: [{ source: 'User', predicate: 'prefers', target: 'concise answers', confidence: 0.96 }],
      }],
    })
    yield { type: 'block-start', index: 0, blockType: 'text' }
    yield { type: 'text-delta', index: 0, text: value }
    yield { type: 'finish', reason: { kind: 'stop' } }
  }
}

class BlockingAdapter extends LlmAdapter {
  started!: () => void
  readonly startedPromise = new Promise<void>((resolve) => { this.started = resolve })

  override async * stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    this.started()
    yield { type: 'block-start', index: 0, blockType: 'text' }
    if (options.signal === undefined) throw new Error('expected summary cancellation signal')
    await new Promise<void>(resolve => options.signal?.addEventListener('abort', () => resolve(), { once: true }))
    options.signal.throwIfAborted()
  }
}

class RetryAdapter extends LlmAdapter {
  attempts = 0

  override async * stream(): AsyncIterable<StreamChunk> {
    this.attempts++
    if (this.attempts === 1) throw new Error('transient summary failure')
    yield { type: 'block-start', index: 0, blockType: 'text' }
    yield { type: 'text-delta', index: 0, text: '{"summary":"Recovered summary.","memories":[]}' }
    yield { type: 'finish', reason: { kind: 'stop' } }
  }
}

class ControlledAdapter extends LlmAdapter {
  active = 0
  maximumActive = 0
  started = 0
  private readonly releases: Array<() => void> = []

  override async * stream(): AsyncIterable<StreamChunk> {
    this.active++
    this.started++
    this.maximumActive = Math.max(this.maximumActive, this.active)
    try {
      yield { type: 'block-start', index: 0, blockType: 'text' }
      await new Promise<void>(resolve => this.releases.push(resolve))
      yield { type: 'text-delta', index: 0, text: '{"summary":"Controlled summary.","memories":[]}' }
      yield { type: 'finish', reason: { kind: 'stop' } }
    } finally {
      this.active--
    }
  }

  release(): void {
    this.releases.shift()?.()
  }
}

let callIndex = 0
function call(ctx: Context, tool: string, args: unknown) {
  return ctx.tools.execute({
    callId: CallId(`memory-test-${++callIndex}`),
    name: tool,
    arguments: args,
    signal: new AbortController().signal,
  })
}

function completedSession(ctx: Context, id: string) {
  const session = ctx.sessions.create(SessionId(id))
  session.append('request/header', {
    header: { config: { provider: 'summary-test', model: 'extractor' } }, reason: 'initial',
  })
  session.append('turn/start', { turn: 1 })
  session.append('user/message', createUserMessage({
    content: [{ type: 'text', text: `Remember ${id}.` }], source: { kind: 'user' },
  }), { surfaceOp: 'append' })
  session.append('turn/end', { turn: 1, reason: { kind: 'completed' } })
  return session
}

describe('memory-graph plugin', () => {
  it('supports a configuration-level master switch', async () => {
    const { ctx } = await setup(true, { enabled: false, autoSummarize: true })
    expect(ctx.tools.schemas()).toEqual([])
    await ctx.fiber.dispose()
  })

  it('rejects semantic-only weights because lexical fail-open would have no denominator', async () => {
    await expect(setup(false, {
      weights: { lexical: 0, semantic: 1, graph: 0, importance: 0, recency: 0, access: 0 },
    })).rejects.toThrow('non-semantic retrieval weight')
  })

  it('registers memory and entity-maintenance tools and removes them on disposal', async () => {
    const { ctx, fiber } = await setup(false)
    expect(ctx.tools.schemas().map(schema => schema.name).sort()).toEqual([
      'memory_archive_expand', 'memory_archive_retry',
      'memory_backup', 'memory_entity_delete', 'memory_entity_find_duplicates', 'memory_entity_merge', 'memory_entity_orphans',
      'memory_entity_rename', 'memory_expand', 'memory_forget', 'memory_graph', 'memory_recall', 'memory_remember', 'memory_revert',
      'memory_semantic_reindex',
    ])
    await fiber.dispose()
    expect(ctx.tools.schemas()).toEqual([])
    await ctx.fiber.dispose()
  })

  it('rejects backup-file symlinks that resolve outside the configured directory', async () => {
    const root = mkdtempSync(join(tmpdir(), 'dsh-memory-backup-path-'))
    const backups = join(root, 'backups')
    const outside = join(root, 'outside.jsonl')
    mkdirSync(backups)
    writeFileSync(outside, '{}\n')
    symlinkSync(outside, join(backups, 'escape.jsonl'))
    const { ctx } = await setup(false, { backupDirectory: backups })
    const result = await call(ctx, 'memory_backup', { action: 'import', fileName: 'escape.jsonl' })
    expect(result.isError).toBe(true)
    await ctx.fiber.dispose()
  })

  it('executes remember and recall through the real tool registry', async () => {
    const { ctx } = await setup(false)
    const remembered = await call(ctx, 'memory_remember', {
      content: 'Use the balanced deployment profile.',
      importance: 0.9,
      entities: [{ name: 'deployment', kind: 'topic' }],
      relations: [],
    })
    expect(remembered.isError).toBe(false)
    const recalled = await call(ctx, 'memory_recall', { query: 'balanced deployment', limit: 3, hops: 1 })
    expect(recalled.isError).toBe(false)
    if (recalled.isError) throw new Error('expected recall success')
    const value = recalled.value as { results: Array<{ content: string }> }
    expect(value.results[0]?.content).toContain('balanced deployment')
    await ctx.fiber.dispose()
  })

  it('returns memory_remember without waiting for a slow embedding endpoint', async () => {
    vi.stubGlobal('fetch', vi.fn((_input: unknown, init?: RequestInit) => new Promise<Response>((_resolve, reject) => {
      init?.signal?.addEventListener('abort', () => reject(init.signal?.reason), { once: true })
    })))
    const { ctx } = await setup(false, {
      semanticEnabled: true, semanticEndpoint: 'http://127.0.0.1:9999/embeddings', semanticApiKeyEnv: '',
    })
    const outcome = await Promise.race([
      call(ctx, 'memory_remember', {
        content: 'Background semantic indexing must not delay this write.',
        entities: [], relations: [],
      }),
      new Promise<'timeout'>(resolve => setTimeout(() => resolve('timeout'), 100)),
    ])
    expect(outcome).not.toBe('timeout')
    await ctx.fiber.dispose()
    vi.unstubAllGlobals()
  })

  it('adds bounded, source-attributed context only on the first step', async () => {
    const { ctx } = await setup(true)
    await call(ctx, 'memory_remember', {
      content: 'The user prefers concise answers.',
      importance: 1,
      entities: [{ name: 'user', kind: 'person' }],
      relations: [{ source: 'user', predicate: 'prefers', target: 'concise answers' }],
    })
    const agent = { id: 'memory-agent' } as unknown as Agent
    const message = createUserMessage({
      content: [{ type: 'text', text: 'How should I answer this user?' }],
      source: { kind: 'user' },
    })
    const dispatch = agentEvents(ctx, agent)
    const first = await dispatch.waterfall(
      'agent/pre-step',
      { messages: [message], turn: 1, step: 1, signal: new AbortController().signal },
      () => Promise.resolve({ kind: 'enter' as const, messages: [message] }),
    )
    expect(first.kind).toBe('enter')
    if (first.kind === 'reject') throw new Error('expected enter')
    expect(first.messages).toHaveLength(2)
    const injected = first.messages[1]
    expect(injected?.source).toMatchObject({ kind: 'plugin', plugin: 'memory-graph', form: 'snapshot' })
    expect(injected?.content[0]).toMatchObject({ type: 'text', text: expect.stringContaining('concise answers') })

    const second = await dispatch.waterfall(
      'agent/pre-step',
      { messages: [message], turn: 1, step: 2, signal: new AbortController().signal },
      () => Promise.resolve({ kind: 'enter' as const, messages: [message] }),
    )
    expect(second).toEqual({ kind: 'enter', messages: [message] })
    await ctx.fiber.dispose()
  })

  it('summarizes a completed durable turn in the background and exposes it in the graph', async () => {
    const { ctx } = await setup(false, { autoSummarize: true, summaryProvider: 'summary-test', summaryModel: 'extractor' })
    const adapter = new SummaryAdapter()
    ctx.llm.registerAdapter(['summary-test'], adapter)
    const session = ctx.sessions.create(SessionId('summary-session'))
    session.append('request/header', {
      header: { config: { provider: 'chat-provider', model: 'chat-model' } }, reason: 'initial',
    })
    session.append('turn/start', { turn: 1 })
    session.append('user/message', createUserMessage({
      content: [{ type: 'text', text: 'Use the balanced profile and keep answers concise.' }], source: { kind: 'user' },
    }), { surfaceOp: 'append' })
    session.append('assistant/message', {
      turn: 1, step: 1,
      message: createMessage({
        role: 'assistant', content: [{ type: 'text', text: 'Understood.' }],
        source: { kind: 'model', provider: 'chat-provider', model: 'chat-model' },
      }),
    }, { surfaceOp: 'append' })
    session.append('turn/end', { turn: 1, reason: { kind: 'completed' } })

    await vi.waitFor(async () => {
      const result = await call(ctx, 'memory_graph', { limit: 30, hops: 2 })
      if (result.isError) throw new Error('expected graph success')
      const value = result.value as { nodes: Array<{ name: string }>; summaries: Array<{ summary: string }> }
      expect(value.summaries[0]?.summary).toContain('balanced profile')
      expect(value.nodes.map(node => node.name)).toContain('User')
    }, { timeout: 2000, interval: 10 })
    expect(adapter.requests).toHaveLength(1)
    expect(adapter.requests[0]).toMatchObject({ provider: 'summary-test', model: 'extractor', maxTokens: 1800 })
    expect(adapter.requests[0]?.system).toContain('dominant language of the user messages')
    await ctx.fiber.dispose()
  })

  it('reconstructs durable turn input and serializes duplicate queue submissions', async () => {
    const { ctx } = await setup(false)
    const adapter = new SummaryAdapter()
    ctx.llm.registerAdapter(['summary-test'], adapter)
    const session = ctx.sessions.create(SessionId('queue-session'))
    session.append('request/header', {
      header: { config: { provider: 'summary-test', model: 'extractor' } }, reason: 'initial',
    })
    session.append('turn/start', { turn: 1 })
    session.append('user/message', createUserMessage({
      content: [{ type: 'text', text: 'Remember that DSH uses the balanced profile.' }], source: { kind: 'user' },
    }), { surfaceOp: 'append' })
    session.append('assistant/message', {
      turn: 1, step: 1,
      message: createMessage({
        role: 'assistant', content: [{ type: 'text', text: 'Recorded.' }],
        source: { kind: 'model', provider: 'summary-test', model: 'extractor' },
      }),
    }, { surfaceOp: 'append' })
    session.append('turn/end', { turn: 1, reason: { kind: 'completed' } })
    const transcript = collectTurnTranscript(session, 1, {
      maxInputChars: 2000, maxInputTokens: 1000, captureToolResults: false, toolResultMaxTokens: 500,
    })
    expect(transcript).toMatchObject({ sessionId: 'queue-session', turn: 1, provider: 'summary-test', model: 'extractor' })
    expect(transcript?.messages.map(message => message.role)).toEqual(['user', 'assistant'])
    const clipped = collectTurnTranscript(session, 1, {
      maxInputChars: 100, maxInputTokens: 30, captureToolResults: false, toolResultMaxTokens: 500,
    })
    expect(clipped).toMatchObject({ truncated: true, originalMessageCount: 2 })
    expect(clipped!.messages.length).toBeLessThanOrEqual(2)

    const store = new MemoryGraphStore(':memory:')
    const summarizer = new AutoSummarizer(ctx, store, {
      everyTurns: 1, maxInputChars: 2000, maxInputTokens: 1000,
      archiveMaxInputChars: 4000, archiveMaxInputTokens: 2000, archiveRetentionDays: 30, archiveMaxTurnsPerSession: 200,
      language: 'auto', maxOutputTokens: 1000, timeoutMs: 10_000,
      maxMemories: 8, minConfidence: 0.65, backfillTurns: 0,
      concurrency: 2, maxAttempts: 2, retryBaseMs: 0, captureToolResults: false, toolResultMaxTokens: 500,
    })
    summarizer.enqueue(session, 1)
    summarizer.enqueue(session, 1)
    await vi.waitFor(() => expect(store.hasSummary('queue-session', 1)).toBe(true))
    expect(adapter.requests).toHaveLength(1)
    await summarizer.dispose()
    store.close()
    await ctx.fiber.dispose()
  })

  it('captures bounded tool results only when explicitly enabled', async () => {
    const { ctx } = await setup(false)
    const session = ctx.sessions.create(SessionId('tool-transcript'))
    session.append('request/header', {
      header: { config: { provider: 'summary-test', model: 'extractor' } }, reason: 'initial',
    })
    session.append('turn/start', { turn: 1 })
    session.append('user/message', createUserMessage({
      content: [{ type: 'text', text: 'Inspect the service.' }], source: { kind: 'user' },
    }), { surfaceOp: 'append' })
    const callId = CallId('tool-call')
    session.append('tool/call', { turn: 1, step: 1, callId, name: 'service_status', arguments: '{}' })
    session.append('tool/result', {
      turn: 1, step: 1,
      message: createToolResultMessage({ callId, content: [{ type: 'text', text: 'healthy and ready' }], isError: false }),
    }, { surfaceOp: 'append' })
    session.append('turn/end', { turn: 1, reason: { kind: 'completed' } })
    const policy = { maxInputChars: 4000, maxInputTokens: 1000, toolResultMaxTokens: 50 }
    expect(collectTurnTranscript(session, 1, { ...policy, captureToolResults: false })?.messages.map(message => message.role))
      .toEqual(['user'])
    expect(collectTurnTranscript(session, 1, { ...policy, captureToolResults: true })?.messages)
      .toContainEqual(expect.objectContaining({ role: 'tool', toolName: 'service_status', text: 'healthy and ready' }))
    await ctx.fiber.dispose()
  })

  it('aborts an in-flight summary before closing its store', async () => {
    const { ctx } = await setup(false)
    const adapter = new BlockingAdapter()
    ctx.llm.registerAdapter(['blocking'], adapter)
    const session = ctx.sessions.create(SessionId('dispose-session'))
    session.append('request/header', {
      header: { config: { provider: 'blocking', model: 'extractor' } }, reason: 'initial',
    })
    session.append('turn/start', { turn: 1 })
    session.append('user/message', createUserMessage({
      content: [{ type: 'text', text: 'Remember this.' }], source: { kind: 'user' },
    }), { surfaceOp: 'append' })
    session.append('turn/end', { turn: 1, reason: { kind: 'completed' } })
    const store = new MemoryGraphStore(':memory:')
    const summarizer = new AutoSummarizer(ctx, store, {
      everyTurns: 1, maxInputChars: 2000, maxInputTokens: 1000,
      archiveMaxInputChars: 4000, archiveMaxInputTokens: 2000, archiveRetentionDays: 30, archiveMaxTurnsPerSession: 200,
      language: 'auto', maxOutputTokens: 1000, timeoutMs: 60_000,
      maxMemories: 8, minConfidence: 0.65, backfillTurns: 0,
      concurrency: 2, maxAttempts: 2, retryBaseMs: 0, captureToolResults: false, toolResultMaxTokens: 500,
    })
    summarizer.enqueue(session, 1)
    await adapter.startedPromise
    await summarizer.dispose()
    expect(store.hasSummary('dispose-session', 1)).toBe(false)
    store.close()
    await ctx.fiber.dispose()
  })

  it('retries transient summary failures within the configured attempt limit', async () => {
    const { ctx } = await setup(false)
    const adapter = new RetryAdapter()
    ctx.llm.registerAdapter(['summary-test'], adapter)
    const store = new MemoryGraphStore(':memory:')
    const summarizer = new AutoSummarizer(ctx, store, {
      everyTurns: 1, maxInputChars: 2000, maxInputTokens: 1000,
      archiveMaxInputChars: 4000, archiveMaxInputTokens: 2000, archiveRetentionDays: 30, archiveMaxTurnsPerSession: 200,
      language: 'auto', maxOutputTokens: 1000, timeoutMs: 10_000,
      maxMemories: 8, minConfidence: 0.65, backfillTurns: 0,
      concurrency: 1, maxAttempts: 2, retryBaseMs: 0, captureToolResults: false, toolResultMaxTokens: 500,
    })
    summarizer.enqueue(completedSession(ctx, 'retry-session'), 1)
    await vi.waitFor(() => expect(store.hasSummary('retry-session', 1)).toBe(true))
    expect(adapter.attempts).toBe(2)
    await summarizer.dispose()
    store.close()
    await ctx.fiber.dispose()
  })

  it('automatically retries a bounded number of failed archives after startup', async () => {
    const root = mkdtempSync(join(tmpdir(), 'dsh-memory-archive-retry-'))
    const path = join(root, 'memory.sqlite')
    const seed = new MemoryGraphStore(path)
    seed.archiveTurn({
      sessionId: 'startup-retry', turn: 1, sourceEventSeqs: [1],
      messages: [{ seq: 1, role: 'user', text: '请记住使用 balanced 配置。' }],
      provider: 'summary-test', model: 'extractor', status: 'failed',
    })
    seed.close()
    const { ctx } = await setup(false, { path, summaryRetryFailedOnStart: 1 })
    const adapter = new SummaryAdapter()
    ctx.llm.registerAdapter(['summary-test'], adapter)
    await vi.waitFor(async () => {
      const result = await call(ctx, 'memory_graph', { limit: 30, hops: 1 })
      if (result.isError) throw new Error('expected graph success')
      expect((result.value as { summaries: unknown[] }).summaries).toHaveLength(1)
    }, { timeout: 2000, interval: 10 })
    expect(adapter.requests).toHaveLength(1)
    await ctx.fiber.dispose()
  })

  it('bounds automatic summary calls across concurrent sessions', async () => {
    const { ctx } = await setup(false)
    const adapter = new ControlledAdapter()
    ctx.llm.registerAdapter(['summary-test'], adapter)
    const store = new MemoryGraphStore(':memory:')
    const summarizer = new AutoSummarizer(ctx, store, {
      everyTurns: 1, maxInputChars: 2000, maxInputTokens: 1000,
      archiveMaxInputChars: 4000, archiveMaxInputTokens: 2000, archiveRetentionDays: 30, archiveMaxTurnsPerSession: 200,
      language: 'auto', maxOutputTokens: 1000, timeoutMs: 10_000,
      maxMemories: 8, minConfidence: 0.65, backfillTurns: 0,
      concurrency: 2, maxAttempts: 1, retryBaseMs: 0, captureToolResults: false, toolResultMaxTokens: 500,
    })
    for (const id of ['concurrent-a', 'concurrent-b', 'concurrent-c']) {
      summarizer.enqueue(completedSession(ctx, id), 1)
    }
    await vi.waitFor(() => expect(adapter.started).toBe(2))
    expect(adapter.maximumActive).toBe(2)
    adapter.release()
    await vi.waitFor(() => expect(adapter.started).toBe(3))
    adapter.release()
    adapter.release()
    await vi.waitFor(() => expect(['concurrent-a', 'concurrent-b', 'concurrent-c']
      .every(id => store.hasSummary(id, 1))).toBe(true))
    expect(adapter.maximumActive).toBe(2)
    await summarizer.dispose()
    store.close()
    await ctx.fiber.dispose()
  })
})
