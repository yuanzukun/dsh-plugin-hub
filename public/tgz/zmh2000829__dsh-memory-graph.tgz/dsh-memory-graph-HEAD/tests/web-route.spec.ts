import { createServer } from 'node:http'
import type { AddressInfo } from 'node:net'
import { afterEach, describe, expect, it } from 'vitest'
import { MemoryGraphStore } from '../src/store.ts'
import { TurnMemoryPolicy } from '../src/runtime-policy.ts'
import {
  actionHandler, isTrustedVisualizationRequest, validateTrustedHost, visualizationHandler,
} from '../src/web-route.ts'

const stores: MemoryGraphStore[] = []

const settings = () => ({
  autoOpen: true,
  refreshMs: 5000,
  hops: 2,
  limit: 100,
  trustedHosts: [] as string[],
  token: 'test-token',
  defaults: {
    autoRecall: true, autoSummarize: true, archiveTurns: true, captureToolResults: false,
    semanticEnabled: false, semanticAvailable: () => false,
    summaryLanguage: 'auto' as const,
  },
  runtime: new TurnMemoryPolicy(),
  outboxSize: () => 0,
})

afterEach(() => {
  for (const store of stores.splice(0)) store.close()
})

describe('visualization snapshot route', () => {
  it('accepts loopback same-origin requests and rejects cross-site or unknown hosts', () => {
    expect(isTrustedVisualizationRequest({ headers: { host: '127.0.0.1:3080', 'sec-fetch-site': 'same-origin' } }, [])).toBe(true)
    expect(isTrustedVisualizationRequest({ headers: { host: 'localhost:3080', origin: 'http://localhost:3080' } }, [])).toBe(true)
    expect(isTrustedVisualizationRequest({ headers: { host: 'localhost:3080', origin: 'http://evil.example' } }, [])).toBe(false)
    expect(isTrustedVisualizationRequest({ headers: { host: 'harness.internal:3080' } }, [])).toBe(false)
    expect(isTrustedVisualizationRequest({ headers: { host: 'harness.internal:3080' } }, ['harness.internal:3080'])).toBe(true)
    expect(() => validateTrustedHost('harness.internal/path')).toThrow('must be host or host:port')
  })

  it('serves active memory without requiring an LLM tool call', async () => {
    const store = new MemoryGraphStore(':memory:')
    stores.push(store)
    store.remember({
      content: 'The user prefers concise answers.', importance: 1, confidence: 1, kind: 'preference',
      tags: [], entities: [{ name: 'User' }, { name: 'concise answers' }],
      relations: [{ source: 'User', predicate: 'prefers', target: 'concise answers' }],
    })
    const handler = visualizationHandler(store, settings())
    const server = createServer(handler)
    await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
    try {
      const port = (server.address() as AddressInfo).port
      const response = await fetch(`http://127.0.0.1:${port}/memory-graph/snapshot`)
      expect(response.status).toBe(200)
      expect(response.headers.get('cache-control')).toBe('no-store')
      const etag = response.headers.get('etag')
      expect(etag).toBeTruthy()
      const value = await response.json() as { graph: { nodes: Array<{ name: string }> }; config: unknown }
      expect(value.graph.nodes.map(node => node.name)).toEqual(expect.arrayContaining(['User', 'concise answers']))
      expect(value.config).toMatchObject({ autoOpen: true, refreshMs: 5000, autoRecall: true, token: 'test-token' })
      const unchanged = await fetch(`http://127.0.0.1:${port}/memory-graph/snapshot`, {
        headers: { 'if-none-match': etag! },
      })
      expect(unchanged.status).toBe(304)
      store.remember({
        content: 'A second graph revision.', importance: 0.5, confidence: 1, kind: 'fact',
        tags: [], entities: [{ name: 'Revision' }], relations: [],
      })
      const changed = await fetch(`http://127.0.0.1:${port}/memory-graph/snapshot`, {
        headers: { 'if-none-match': etag! },
      })
      expect(changed.status).toBe(200)
      expect(changed.headers.get('etag')).not.toBe(etag)
      const denied = await fetch(`http://127.0.0.1:${port}/memory-graph/snapshot`, {
        headers: { origin: 'http://evil.example' },
      })
      expect(denied.status).toBe(403)
    } finally {
      await new Promise<void>((resolve, reject) => server.close(error => error === undefined ? resolve() : reject(error)))
    }
  })

  it('requires the same-origin token for per-turn policy and memory deletion', async () => {
    const store = new MemoryGraphStore(':memory:')
    stores.push(store)
    const remembered = store.remember({
      content: 'Delete through the dashboard.', importance: 0.5, confidence: 1, kind: 'fact',
      tags: [], entities: [], relations: [],
    })
    const resolved = settings()
    const server = createServer(actionHandler(store, resolved))
    await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
    try {
      const port = (server.address() as AddressInfo).port
      const post = (body: object, token = 'test-token') => fetch(`http://127.0.0.1:${port}/memory-graph/action`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-memory-graph-token': token },
        body: JSON.stringify(body),
      })
      expect((await post({ action: 'set-turn-mode', sessionId: 's', mode: 'off' })).status).toBe(200)
      expect(resolved.runtime.snapshot('s').pendingMode).toBe('off')
      expect((await post({ action: 'forget-memory', memoryId: remembered.memoryId }, 'wrong')).status).toBe(403)
      expect((await post({ action: 'forget-memory', memoryId: remembered.memoryId })).status).toBe(200)
      expect(store.memory(remembered.memoryId)).toBeUndefined()
    } finally {
      await new Promise<void>((resolve, reject) => server.close(error => error === undefined ? resolve() : reject(error)))
    }
  })
})
