import { describe, expect, it, vi } from 'vitest'
import { SemanticEmbeddingClient, SemanticIndexQueue, SemanticQueryCache } from '../src/semantic.ts'

describe('semantic fail-open runtime', () => {
  it('uses an independent timeout and enters a bounded failure cooldown', async () => {
    vi.stubGlobal('fetch', vi.fn((_input: unknown, init?: RequestInit) => new Promise<Response>((_resolve, reject) => {
      init?.signal?.addEventListener('abort', () => reject(init.signal?.reason), { once: true })
    })))
    const client = new SemanticEmbeddingClient({
      enabled: true, endpoint: 'http://127.0.0.1:9999/embeddings', model: 'test', apiKeyEnv: '',
      timeoutMs: 1000, failureCooldownMs: 100,
    }, () => undefined)
    const started = Date.now()
    expect(await client.embed(['query'], undefined, 10)).toBeUndefined()
    expect(Date.now() - started).toBeLessThan(250)
    expect(client.available()).toBe(false)
    vi.unstubAllGlobals()
  })

  it('caches repeated query vectors and deduplicates background ids', async () => {
    const cache = new SemanticQueryCache(1000, 2)
    const load = vi.fn().mockResolvedValue([1, 2])
    expect(await cache.get(' Query ', load)).toEqual([1, 2])
    expect(await cache.get('query', load)).toEqual([1, 2])
    expect(load).toHaveBeenCalledTimes(1)

    const indexed: string[][] = []
    const queue = new SemanticIndexQueue(async (ids) => { indexed.push([...ids]) })
    queue.enqueue(['a', 'a', 'b'])
    await vi.waitFor(() => expect(indexed).toEqual([['a', 'b']]))
    await queue.dispose()
  })
})
