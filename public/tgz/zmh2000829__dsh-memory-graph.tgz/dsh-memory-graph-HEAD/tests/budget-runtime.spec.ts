import { describe, expect, it } from 'vitest'
import { clipTokens, estimateTokens } from '../src/budget.ts'
import { TurnMemoryPolicy } from '../src/runtime-policy.ts'

describe('token budget and turn memory policy', () => {
  it('budgets CJK more conservatively than Latin text and clips by tokens', () => {
    expect(estimateTokens('记忆知识图谱')).toBeGreaterThan(estimateTokens('memory'))
    const clipped = clipTokens('这是一个需要被安全裁剪的中文上下文', 6)
    expect(clipped.truncated).toBe(true)
    expect(estimateTokens(clipped.text)).toBeLessThanOrEqual(6)
  })

  it('latches one explicit choice and resets after that turn', () => {
    const policy = new TurnMemoryPolicy()
    policy.set('session', 'off')
    expect(policy.enabled('session', 1, true)).toBe(false)
    policy.set('session', 'on')
    expect(policy.enabled('session', 1, true)).toBe(false)
    policy.finish('session', 1)
    expect(policy.enabled('session', 2, false)).toBe(true)
    policy.finish('session', 2)
    expect(policy.enabled('session', 3, false)).toBe(false)
  })
})
