import { describe, expect, it } from 'vitest'
import { isRetryableSummaryError, parseExtractedSummary } from '../src/summarizer.ts'

describe('dialogue summary validation', () => {
  it('retries transport failures but not deterministic extraction validation', () => {
    expect(isRetryableSummaryError(new Error('network reset'))).toBe(true)
    expect(isRetryableSummaryError(new Error('memory summary: model output contains no JSON object'))).toBe(false)
  })
  it('accepts fenced structured output but rejects prompt-injected or invalid fields', () => {
    const valid = parseExtractedSummary('```json\n{"summary":"durable choice","memories":[]}\n```', 4)
    expect(valid).toEqual({ summary: 'durable choice', memories: [] })
    expect(() => parseExtractedSummary('{"summary":"x","memories":[{"content":"x","kind":"instruction","importance":1,"confidence":1,"tags":[],"entities":[],"relations":[]}]}', 4))
      .toThrow('kind is unsupported')
    expect(() => parseExtractedSummary('{"summary":"x","memories":[{"content":"x","kind":"fact","importance":1,"confidence":2,"tags":[],"entities":[],"relations":[]}]}', 4))
      .toThrow('confidence must be a number from 0 to 1')
  })

  it('validates canonical entity identities and aliases', () => {
    const parsed = parseExtractedSummary(JSON.stringify({
      summary: 'DSH was discussed.',
      memories: [{
        content: 'DeepSeek Harness is also called DSH.', kind: 'fact', importance: 0.8, confidence: 0.9,
        tags: [], entities: [{ name: 'DSH', canonical: 'DeepSeek Harness', aliases: ['DeepSeek', 'DSH'] }], relations: [],
      }],
    }), 4)
    expect(parsed.memories[0]?.entities[0]).toEqual({
      name: 'DSH', canonical: 'DeepSeek Harness', aliases: ['DeepSeek', 'DSH'],
    })
  })
})
