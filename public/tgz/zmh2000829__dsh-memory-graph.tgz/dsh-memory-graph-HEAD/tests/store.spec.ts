import { DatabaseSync } from 'node:sqlite'
import { mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'
import { MemoryGraphStore, normalizeEntity } from '../src/store.ts'
import type { RetrievalWeights } from '../src/types.ts'

const weights: RetrievalWeights = {
  lexical: 0.4,
  semantic: 0.3,
  graph: 0.25,
  importance: 0.2,
  recency: 0.1,
  access: 0.05,
}

function recall(store: MemoryGraphStore, query: string, hops = 2) {
  return store.recall(query, { limit: 10, hops, halfLifeDays: 30, weights, now: 1_800_000_000_000 })
}

describe('MemoryGraphStore', () => {
  it('stores turn archives and round-trips embedding cosine scores', () => {
    const store = new MemoryGraphStore(':memory:')
    const first = store.remember({
      content: 'The project uses a local graph.', importance: 0.8, confidence: 1, kind: 'fact',
      tags: [], entities: [], relations: [],
    })
    const second = store.remember({
      content: 'The user prefers concise answers.', importance: 0.8, confidence: 1, kind: 'preference',
      tags: [], entities: [], relations: [],
    })
    store.putEmbedding(first.memoryId, 'local', 'test', [1, 0])
    store.putEmbedding(second.memoryId, 'local', 'test', [0, 1])
    const semantic = store.semanticScores('local', 'test', [0.9, 0.1], 10)
    expect(semantic.get(first.memoryId)).toBeGreaterThan(semantic.get(second.memoryId)!)
    const archive = store.archiveTurn({
      sessionId: 's', turn: 2, sourceEventSeqs: [3, 4], provider: 'p', model: 'm',
      messages: [{ seq: 3, role: 'user', text: '请记住这个选择' }], status: 'failed', now: 100,
    })
    expect(store.archive('s', 2)).toEqual(archive)
    expect(store.failedArchives(5).map(value => value.id)).toEqual([archive.id])
    expect(store.archiveStatusCounts()).toEqual({ pending: 0, summarized: 0, failed: 1, archived: 0 })
    store.markArchive(archive.id, 'pending')
    expect(store.archive(archive.id)?.status).toBe('pending')
    expect(store.archiveStatusCounts()).toEqual({ pending: 1, summarized: 0, failed: 0, archived: 0 })
    const backup = join(mkdtempSync(join(tmpdir(), 'memory-semantic-backup-')), 'snapshot.jsonl')
    store.exportJsonl(backup)
    const restored = new MemoryGraphStore(':memory:')
    restored.importJsonl(backup)
    expect(restored.archive('s', 2)?.messages[0]?.text).toBe('请记住这个选择')
    expect(restored.semanticScores('local', 'test', [1, 0], 10).has(first.memoryId)).toBe(true)
    restored.close()
    store.close()
  })

  it('keeps fail-open scores finite when semantic candidates are unavailable', () => {
    const store = new MemoryGraphStore(':memory:')
    store.remember({
      content: 'A durable local fact.', importance: 0.8, confidence: 1, kind: 'fact',
      tags: ['durable'], entities: [], relations: [],
    })
    const results = store.recall('durable fact', {
      limit: 5, hops: 0, halfLifeDays: 30,
      weights: { lexical: 0, semantic: 1, graph: 0, importance: 0, recency: 0, access: 0 },
    })
    expect(results).toHaveLength(1)
    expect(results.every(result => Number.isFinite(result.score))).toBe(true)
    store.close()
  })

  it('rotates bounded semantic scans and removes inactive embeddings', () => {
    const store = new MemoryGraphStore(':memory:')
    const ids = Array.from({ length: 3 }, (_, index) => store.remember({
      content: `Rotating semantic memory ${index}.`, importance: 0.5, confidence: 1, kind: 'fact',
      tags: [], entities: [], relations: [],
    }).memoryId)
    ids.forEach((id, index) => store.putEmbedding(id, 'local', 'test', [index + 1, 1]))
    const visited = new Set<string>()
    for (let index = 0; index < 3; index++) {
      for (const id of store.semanticScores('local', 'test', [1, 1], 1).keys()) visited.add(id)
    }
    expect(visited).toEqual(new Set(ids))

    const first = store.remember({
      content: 'The profile is balanced.', importance: 0.8, confidence: 1, kind: 'fact', stableKey: 'profile',
      tags: [], entities: [], relations: [],
    })
    store.putEmbedding(first.memoryId, 'local', 'test', [1, 0])
    const current = store.remember({
      content: 'The profile is performance.', importance: 0.8, confidence: 1, kind: 'fact', stableKey: 'profile',
      tags: [], entities: [], relations: [],
    })
    expect(store.semanticScores('local', 'test', [1, 0], 20).has(first.memoryId)).toBe(false)
    store.putEmbedding(current.memoryId, 'local', 'test', [1, 0])
    const reverted = store.revert(current.memoryId)
    expect(store.semanticScores('local', 'test', [1, 0], 20).has(current.memoryId)).toBe(false)
    expect(store.memoriesForEmbedding('local', 'test', 20).map(memory => memory.id)).toContain(reverted.restoredMemoryId)
    store.close()
  })

  it('bounds archive retention by age and newest turns per session', () => {
    const store = new MemoryGraphStore(':memory:')
    const archive = (sessionId: string, turn: number, now: number) => store.archiveTurn({
      sessionId, turn, sourceEventSeqs: [turn], messages: [{ seq: turn, role: 'user', text: `turn ${turn}` }],
      provider: 'p', model: 'm', now,
    })
    archive('old', 1, 1)
    archive('active', 1, 200_000_000)
    archive('active', 2, 200_000_001)
    archive('active', 3, 200_000_002)
    expect(store.pruneArchives(1, 2, 200_000_003)).toBe(2)
    expect(store.archive('old', 1)).toBeUndefined()
    expect(store.archive('active', 1)).toBeUndefined()
    expect(store.archive('active', 2)).toBeDefined()
    expect(store.archive('active', 3)).toBeDefined()
    store.close()
  })

  it('deduplicates equivalent recall text and marks preference intent', () => {
    const store = new MemoryGraphStore(':memory:')
    const input = {
      content: 'The user likes concise answers.', importance: 0.5, confidence: 1, kind: 'preference' as const,
      tags: ['answer'], entities: [], relations: [],
    }
    store.remember(input)
    store.remember({ ...input, content: 'The user likes concise answers. ' })
    const results = store.recall('用户喜欢 concise answers', {
      limit: 10, hops: 0, halfLifeDays: 30, weights,
      preferenceBoost: 0.2, lexicalOverlapBoost: 0.1,
    })
    expect(results).toHaveLength(1)
    expect(results[0]?.reasons).toContain('intent:preference')
    store.close()
  })

  it('applies intent as a bounded monotonic boost without score saturation', () => {
    const store = new MemoryGraphStore(':memory:')
    for (const [content, importance] of [['用户偏好简洁回答。', 0.9], ['用户偏好详细回答。', 0.8]] as const) {
      store.remember({ content, importance, confidence: 1, kind: 'preference', tags: [], entities: [], relations: [] })
    }
    const results = store.recall('用户偏好回答', {
      limit: 5, hops: 0, halfLifeDays: 30,
      weights: { lexical: 0, semantic: 0, graph: 0, importance: 1, recency: 0, access: 0 },
      preferenceBoost: 1,
    })
    expect(results.map(result => result.score)).toEqual([0.95, 0.9])
    expect(results.every(result => result.score < 1)).toBe(true)
    store.close()
  })

  it('stores, retrieves, traverses, and forgets a provenance-linked graph', () => {
    const store = new MemoryGraphStore(':memory:')
    const first = store.remember({
      content: 'The deployment uses the balanced profile.',
      importance: 0.9,
      confidence: 1,
      kind: 'fact',
      tags: ['deployment'],
      entities: [{ name: 'DeepSeek Harness', kind: 'project' }, { name: 'balanced', kind: 'profile' }],
      relations: [{ source: 'DeepSeek Harness', predicate: 'uses-profile', target: 'balanced' }],
      now: 1_799_900_000_000,
    })
    store.remember({
      content: 'Cordis provides the plugin architecture for DeepSeek Harness.',
      importance: 0.8,
      confidence: 1,
      kind: 'fact',
      tags: ['architecture'],
      entities: [{ name: 'Cordis', kind: 'framework' }, { name: 'DeepSeek Harness', kind: 'project' }],
      relations: [{ source: 'DeepSeek Harness', predicate: 'built-on', target: 'Cordis', confidence: 0.95 }],
      now: 1_799_950_000_000,
    })
    store.remember({
      content: 'Ramen is served for lunch.',
      importance: 0.2,
      confidence: 1,
      kind: 'fact',
      tags: ['food'],
      entities: [{ name: 'Ramen', kind: 'food' }],
      relations: [],
      now: 1_799_990_000_000,
    })

    const recalled = recall(store, 'Harness profile')
    expect(recalled[0]?.content).toContain('balanced profile')
    expect(recalled.map(item => item.content)).not.toContain('Ramen is served for lunch.')
    expect(recalled[0]?.reasons).toContain('lexical')

    const graph = store.graph('DeepSeek Harness', 2, 20)
    expect(graph.nodes.map(node => node.name)).toEqual(expect.arrayContaining(['DeepSeek Harness', 'balanced', 'Cordis']))
    expect(graph.edges).toEqual(expect.arrayContaining([
      expect.objectContaining({ source: 'DeepSeek Harness', predicate: 'uses_profile', target: 'balanced' }),
      expect.objectContaining({ source: 'DeepSeek Harness', predicate: 'built_on', target: 'Cordis' }),
    ]))

    expect(store.forget(first.memoryId)).toBe(true)
    expect(store.forget(first.memoryId)).toBe(false)
    expect(recall(store, 'balanced profile')).toEqual([])
    expect(store.graph('balanced', 1, 10).nodes).toEqual([])
    store.close()
    expect(() => recall(store, 'Harness')).toThrow('store is closed')
  })

  it('normalizes Unicode entity identity and merges repeated entities', () => {
    const store = new MemoryGraphStore(':memory:')
    const result = store.remember({
      content: 'Two spellings identify one entity.',
      importance: 0.5,
      confidence: 1,
      kind: 'fact',
      tags: [],
      entities: [{ name: '  ＤＳＨ  ' }, { name: 'dsh' }],
      relations: [],
    })
    expect(normalizeEntity('  ＤＳＨ  ')).toBe('dsh')
    expect(result.entityCount).toBe(1)
    expect(store.graph('DSH', 0, 10).nodes).toHaveLength(1)
    store.close()
  })

  it('refuses a database owned by another application', () => {
    const root = mkdtempSync(join(tmpdir(), 'dsh-memory-graph-'))
    const path = join(root, 'foreign.sqlite')
    const db = new DatabaseSync(path)
    db.exec('CREATE TABLE foreign_data(value TEXT)')
    db.close()
    expect(() => new MemoryGraphStore(path)).toThrow('not an empty plugin database')
  })

  it('migrates a schema-v3 alias table to explicit preferred names', () => {
    const root = mkdtempSync(join(tmpdir(), 'dsh-memory-schema-v3-'))
    const path = join(root, 'memory.sqlite')
    const initial = new MemoryGraphStore(path)
    initial.remember({
      content: 'Schema migration entity.', importance: 0.5, confidence: 1, kind: 'fact', tags: [],
      entities: [{ name: 'Migration Entity' }], relations: [],
    })
    initial.close()
    const legacy = new DatabaseSync(path)
    legacy.exec('ALTER TABLE entity_aliases DROP COLUMN preferred; PRAGMA user_version = 3')
    legacy.close()
    const migrated = new MemoryGraphStore(path)
    migrated.renameEntity('Migration Entity', 'Preferred Migration Entity')
    expect(migrated.graph('Migration Entity', 0, 10).nodes[0]?.name).toBe('Preferred Migration Entity')
    migrated.close()
  })

  it('deduplicates stable facts, supersedes changed values, and keeps summary provenance', () => {
    const store = new MemoryGraphStore(':memory:')
    const base = {
      importance: 0.9, confidence: 0.95, kind: 'preference' as const,
      stableKey: 'user.preference.profile', tags: ['profile'],
      entities: [{ name: 'User', kind: 'person' }], relations: [],
    }
    const first = store.remember({ ...base, content: 'The user prefers balanced.', now: 100 })
    const duplicate = store.remember({ ...base, content: ' The user prefers balanced. ', now: 200 })
    const changed = store.remember({ ...base, content: 'The user prefers performance.', now: 300 })
    expect(duplicate).toMatchObject({ memoryId: first.memoryId, deduplicated: true })
    expect(changed).toMatchObject({ deduplicated: false, supersededMemoryId: first.memoryId })
    expect(store.recall('balanced', { limit: 10, hops: 0, halfLifeDays: 30, weights, reinforce: false, now: 400 })).toEqual([])
    expect(store.recall('performance', { limit: 10, hops: 0, halfLifeDays: 30, weights, reinforce: false, now: 400 })[0]?.id).toBe(changed.memoryId)

    const committed = store.commitSummary({
      sessionId: 'session-1', turn: 4, sourceEventSeqs: [11, 12], provider: 'mock', model: 'extractor',
      requestJson: '{"request":true}', responseJson: '{"response":true}', minConfidence: 0.7, now: 500,
      extracted: {
        summary: 'The user chose a deployment profile.',
        memories: [{
          content: 'DeepSeek Harness uses performance.', kind: 'decision', importance: 0.8, confidence: 0.9,
          tags: ['deployment'], entities: [{ name: 'DeepSeek Harness', kind: 'project' }, { name: 'performance' }],
          relations: [{ source: 'DeepSeek Harness', predicate: 'uses-profile', target: 'performance' }],
        }],
      },
    })
    expect(committed.skipped).toBe(false)
    const graph = store.graph('', 2, 30)
    expect(graph.summaries[0]).toMatchObject({ sessionId: 'session-1', turn: 4, sourceEventSeqs: [11, 12] })
    expect(graph.memories).toEqual(expect.arrayContaining([
      expect.objectContaining({ sourceSession: 'session-1', sourceTurn: 4, confidence: 0.9 }),
    ]))
    expect(store.commitSummary({
      sessionId: 'session-1', turn: 4, sourceEventSeqs: [11, 12], provider: 'mock', model: 'extractor',
      requestJson: '{}', responseJson: '{}', minConfidence: 0.7, now: 600,
      extracted: { summary: 'duplicate', memories: [] },
    }).skipped).toBe(true)
    store.close()
  })

  it('recalls Chinese text with trigram indexing and a short-query fallback', () => {
    const store = new MemoryGraphStore(':memory:')
    store.remember({
      content: '用户偏好详细回答，并且希望解释采用自顶向下结构。',
      importance: 0.9,
      confidence: 1,
      kind: 'preference',
      tags: ['回答风格'],
      entities: [{ name: '用户', kind: 'person' }],
      relations: [],
    })
    expect(recall(store, '用户偏好详细回答')[0]?.content).toContain('详细回答')
    expect(recall(store, '回答')[0]?.content).toContain('详细回答')
    store.close()
  })

  it('folds aliases, converges names and kinds, normalizes predicates, and supports entity maintenance', () => {
    const store = new MemoryGraphStore(':memory:')
    const first = store.remember({
      content: 'DeepSeek Harness uses the web profile.', importance: 0.8, confidence: 1, kind: 'fact', tags: [],
      entities: [{ name: 'DeepSeek Harness', kind: 'project', aliases: ['DeepSeek', 'DSH'] }, { name: 'web', kind: 'profile' }],
      relations: [{ source: 'DSH', predicate: 'Uses Profile', target: 'web' }],
    })
    const second = store.remember({
      content: 'DSh is maintained as an organization project.', importance: 0.5, confidence: 1, kind: 'fact', tags: [],
      entities: [{ name: 'DSh', kind: 'organization' }], relations: [],
    })
    const third = store.remember({
      content: 'DSh publishes harness releases.', importance: 0.5, confidence: 1, kind: 'fact', tags: [],
      entities: [{ name: 'DSh', kind: 'organization' }], relations: [],
    })
    expect(first.entityCount).toBe(2)
    expect(second.entityCount).toBe(0)
    expect(second.entityConflicts).toEqual(expect.arrayContaining([expect.objectContaining({ field: 'kind' })]))
    expect(third.entityCount).toBe(0)
    const aliasGraph = store.graph('DeepSeek', 1, 20)
    expect(aliasGraph.nodes.filter(node => node.id === aliasGraph.nodes.find(value => value.name === 'DSh')?.id)).toHaveLength(1)
    expect(aliasGraph.nodes).toEqual(expect.arrayContaining([expect.objectContaining({ name: 'DSh', kind: 'organization' })]))
    expect(aliasGraph.edges).toEqual(expect.arrayContaining([expect.objectContaining({ predicate: 'uses_profile' })]))

    store.remember({
      content: 'Open AI is another spelling.', importance: 0.4, confidence: 1, kind: 'fact', tags: [],
      entities: [{ name: 'Open AI', kind: 'organization' }], relations: [],
    })
    store.remember({
      content: 'OpenAI is a canonical spelling.', importance: 0.4, confidence: 1, kind: 'fact', tags: [],
      entities: [{ name: 'OpenAI', kind: 'organization' }], relations: [],
    })
    const merged = store.mergeEntities('OpenAI', 'Open AI')
    expect(merged.mergedEntityId).toBeDefined()
    expect(store.graph('Open AI', 0, 10).nodes).toHaveLength(1)
    const renamed = store.renameEntity('OpenAI', 'OpenAI Platform')
    expect(renamed.previousName).toBe('OpenAI')
    for (let index = 0; index < 4; index++) {
      store.remember({
        content: `OpenAI spelling observation ${index}.`, importance: 0.2, confidence: 1, kind: 'fact', tags: [],
        entities: [{ name: 'OpenAI', kind: 'organization' }], relations: [],
      })
    }
    expect(store.graph('OpenAI', 0, 10).nodes[0]?.name).toBe('OpenAI Platform')
    expect(store.deleteEntity('OpenAI Platform').deleted).toBe(true)
    expect(store.graph('OpenAI', 0, 10).nodes).toEqual([])
    expect(store.listOrphans(20)).toEqual([])
    store.close()
  })

  it('reports shared aliases without implicitly merging unrelated entities', () => {
    const store = new MemoryGraphStore(':memory:')
    store.remember({
      content: 'Artificial Intelligence is abbreviated AI.', importance: 0.8, confidence: 1, kind: 'fact', tags: [],
      entities: [{ name: 'Artificial Intelligence', kind: 'concept', aliases: ['AI'] }], relations: [],
    })
    const apple = store.remember({
      content: 'Apple uses AI as an internal label.', importance: 0.4, confidence: 0.8, kind: 'fact', tags: [],
      entities: [{ name: 'Apple', kind: 'company', aliases: ['AI'] }], relations: [],
    })
    expect(apple.entityCount).toBe(1)
    expect(apple.entityConflicts).toEqual([
      expect.objectContaining({ field: 'alias', kept: 'Artificial Intelligence', incoming: 'AI' }),
    ])
    expect(store.graph('Apple', 0, 10).nodes).toEqual([expect.objectContaining({ name: 'Apple' })])
    expect(store.graph('AI', 0, 10).nodes).toEqual([expect.objectContaining({ name: 'Artificial Intelligence' })])
    store.close()
  })

  it('suggests separator variants and aggregates repeated logical edges', () => {
    const store = new MemoryGraphStore(':memory:', { predicateAliases: { 'created by': 'developed_by' } })
    store.remember({
      content: 'Open AI was created by User.', importance: 0.5, confidence: 0.8, kind: 'fact', tags: [],
      entities: [{ name: 'Open AI', kind: 'organization' }, { name: 'User', kind: 'person' }],
      relations: [{ source: 'Open AI', predicate: 'created by', target: 'User', confidence: 0.8 }],
    })
    store.remember({
      content: 'Open AI is developed by User.', importance: 0.6, confidence: 0.9, kind: 'fact', tags: [],
      entities: [{ name: 'Open AI', kind: 'organization' }, { name: 'User', kind: 'person' }],
      relations: [{ source: 'Open AI', predicate: 'developed-by', target: 'User', confidence: 0.9 }],
    })
    store.remember({
      content: 'OpenAI is a compact spelling.', importance: 0.4, confidence: 1, kind: 'fact', tags: [],
      entities: [{ name: 'OpenAI', kind: 'organization' }], relations: [],
    })
    const graph = store.graph('Open AI', 1, 20)
    expect(graph.edges).toEqual([expect.objectContaining({ predicate: 'developed_by', confidence: 0.9, mentions: 2 })])
    expect(store.findDuplicateEntities(undefined, 10, 0.88)).toEqual([
      expect.objectContaining({
        left: expect.objectContaining({ name: 'Open AI' }),
        right: expect.objectContaining({ name: 'OpenAI' }),
        score: 1,
        reason: 'separator_insensitive',
      }),
    ])
    store.close()
  })

  it('garbage-collects superseded graph nodes and can restore the previous graph version', () => {
    const store = new MemoryGraphStore(':memory:')
    const base = {
      importance: 0.9, confidence: 1, kind: 'preference' as const,
      stableKey: 'user.preference.profile', tags: ['profile'],
    }
    store.remember({
      ...base, content: 'The user prefers balanced.',
      entities: [{ name: 'balanced', kind: 'profile' }], relations: [], now: 100,
    })
    const current = store.remember({
      ...base, content: 'The user prefers performance.',
      entities: [{ name: 'performance', kind: 'profile' }], relations: [], now: 200,
    })
    expect(store.graph('balanced', 0, 10).nodes).toEqual([])
    expect(store.graph('performance', 0, 10).nodes).toHaveLength(1)
    const reverted = store.revert(current.memoryId, 300)
    expect(reverted.supersededMemoryId).toBe(current.memoryId)
    expect(store.graph('balanced', 0, 10).nodes).toHaveLength(1)
    expect(store.graph('performance', 0, 10).nodes).toEqual([])
    expect(recall(store, 'balanced')[0]?.id).toBe(reverted.restoredMemoryId)
    store.close()
  })

  it('resolves stale graph snapshots through retained aliases when reverting after a merge', () => {
    const store = new MemoryGraphStore(':memory:')
    const base = {
      importance: 0.8, confidence: 1, kind: 'fact' as const, stableKey: 'platform.name', tags: [], relations: [],
    }
    store.remember({ ...base, content: 'The platform is Open AI.', entities: [{ name: 'Open AI' }], now: 100 })
    store.remember({
      content: 'OpenAI has a persistent project record.', importance: 0.5, confidence: 1, kind: 'fact', tags: [],
      entities: [{ name: 'OpenAI', kind: 'project' }], relations: [], now: 150,
    })
    store.mergeEntities('OpenAI', 'Open AI')
    const current = store.remember({ ...base, content: 'The platform is Other.', entities: [{ name: 'Other' }], now: 200 })
    store.revert(current.memoryId, 300)
    expect(store.graph('OpenAI', 0, 10).nodes).toHaveLength(1)
    expect(store.graph('Open AI', 0, 10).nodes[0]?.id).toBe(store.graph('OpenAI', 0, 10).nodes[0]?.id)
    store.close()
  })

  it('keeps bounded graph edges deterministic and limited to visible endpoints', () => {
    const store = new MemoryGraphStore(':memory:')
    for (let index = 0; index < 6; index++) {
      store.remember({
        content: `Hub links node ${index}.`, importance: 0.5, confidence: 1, kind: 'fact', tags: [],
        entities: [{ name: 'Hub' }, { name: `Node ${index}` }],
        relations: [{ source: 'Hub', predicate: 'links', target: `Node ${index}` }],
      })
    }
    const first = store.graph('Hub', 1, 3)
    const names = new Set(first.nodes.map(node => node.name))
    expect(first.nodes).toHaveLength(3)
    expect(first.edges.every(edge => names.has(edge.source) && names.has(edge.target))).toBe(true)
    expect(store.graph('Hub', 1, 3)).toEqual(first)
    store.close()
  })

  it('exports and restores an exact JSONL snapshot into an empty database', () => {
    const root = mkdtempSync(join(tmpdir(), 'dsh-memory-backup-'))
    const backup = join(root, 'memory.jsonl')
    const source = new MemoryGraphStore(':memory:')
    source.remember({
      content: 'DSH uses Cordis.', importance: 0.8, confidence: 1, kind: 'fact', stableKey: 'dsh.framework', tags: ['architecture'],
      entities: [{ name: 'DeepSeek Harness', kind: 'project', aliases: ['DSH'] }, { name: 'Cordis', kind: 'framework' }],
      relations: [{ source: 'DSH', predicate: 'built on', target: 'Cordis' }],
    })
    const exported = source.exportJsonl(backup)
    expect(exported.records).toBeGreaterThan(0)
    const restored = new MemoryGraphStore(':memory:')
    expect(restored.importJsonl(backup).records).toBe(exported.records)
    expect(recall(restored, 'DSH Cordis')[0]?.content).toBe('DSH uses Cordis.')
    expect(restored.graph('DSH', 1, 10).edges).toEqual([
      expect.objectContaining({ source: 'DeepSeek Harness', predicate: 'built_on', target: 'Cordis' }),
    ])
    expect(() => restored.importJsonl(backup)).toThrow('requires an empty database')
    source.close()
    restored.close()
  })

  it('uses schema defaults when an older backup omits newly defaulted columns', () => {
    const root = mkdtempSync(join(tmpdir(), 'dsh-memory-legacy-backup-'))
    const current = join(root, 'current.jsonl')
    const legacy = join(root, 'legacy.jsonl')
    const source = new MemoryGraphStore(':memory:')
    source.remember({
      content: 'A legacy backup remains restorable.', importance: 0.7, confidence: 1, kind: 'fact', tags: [],
      entities: [{ name: 'Legacy Entity', kind: 'concept' }], relations: [],
    })
    source.exportJsonl(current)
    const records = readFileSync(current, 'utf8').trim().split('\n').map((line) => {
      const value = JSON.parse(line) as { type: string; row?: Record<string, unknown> }
      if (value.type === 'entity_aliases') delete value.row?.preferred
      if (value.type === 'memories') delete value.row?.graph_json
      return JSON.stringify(value)
    })
    writeFileSync(legacy, `${records.join('\n')}\n`)
    const restored = new MemoryGraphStore(':memory:')
    expect(restored.importJsonl(legacy).records).toBeGreaterThan(0)
    expect(recall(restored, 'legacy backup')[0]?.content).toBe('A legacy backup remains restorable.')
    source.close()
    restored.close()
  })
})
