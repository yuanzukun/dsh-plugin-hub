import type { Context } from '@deepseek-ai/cordis'
import { describe, expect, it, vi } from 'vitest'
import { apply, dashboardSnapshot, graphFromMeta, layoutGraph, memoryDefaultState, memoryImpact } from '../src/client/index.tsx'
import type { GraphResult } from '../src/types.ts'

const graph: GraphResult = {
  nodes: [
    { id: 'a', name: 'User', kind: 'person', distance: 0 },
    { id: 'b', name: 'concise answers', kind: 'preference', distance: 1 },
  ],
  edges: [{ source: 'User', predicate: 'prefers', target: 'concise answers', confidence: 0.95, mentions: 2 }],
  memories: [{ id: 'm', content: 'The user prefers concise answers.', kind: 'preference', importance: 0.9, confidence: 0.95, entities: ['User'] }],
  summaries: [{ id: 's', sessionId: 'session', turn: 1, summary: 'Preference confirmed.', sourceEventSeqs: [1, 2], provider: 'mock', model: 'extractor', createdAt: 1 }],
}

const dashboardConfig = {
  autoOpen: true, refreshMs: 5000, autoRecall: true, autoSummarize: true, archiveTurns: true,
  captureToolResults: false, semanticEnabled: false, semanticAvailable: false, outboxPending: 0, token: 'token',
  archiveStatus: { pending: 0, summarized: 1, failed: 0, archived: 0 },
  summaryLanguage: 'auto' as const, graphScope: 'profile' as const,
}

describe('memory graph client model', () => {
  it('validates replay metadata and lays it out deterministically', () => {
    expect(graphFromMeta(graph)).toEqual(graph)
    expect(graphFromMeta({ ...graph, nodes: [{ id: null }] })).toBeUndefined()
    const first = layoutGraph(graph)
    expect(layoutGraph(graph)).toEqual(first)
    expect(first.every(node => Number.isFinite(node.x) && Number.isFinite(node.y))).toBe(true)
    expect(first.find(node => node.name === 'User')?.degree).toBe(1)
  })

  it('validates dashboard configuration before mounting the sidebar', () => {
    expect(dashboardSnapshot({ graph, config: dashboardConfig })).toEqual({ graph, config: dashboardConfig })
    expect(dashboardSnapshot({ graph, config: { ...dashboardConfig, autoOpen: 'yes' } })).toBeUndefined()
    expect(dashboardSnapshot({ graph, config: { ...dashboardConfig, refreshMs: 100 } })).toBeUndefined()
  })

  it('shows the effective profile state instead of an ambiguous default label', () => {
    expect(memoryDefaultState(dashboardConfig)).toBe('on')
    expect(memoryDefaultState({ ...dashboardConfig, autoRecall: false, autoSummarize: false, archiveTurns: false })).toBe('off')
    expect(memoryDefaultState({ ...dashboardConfig, archiveTurns: false })).toBe('mixed')
  })

  it('explains how stored memory categories affect later answers', () => {
    expect(memoryImpact('preference')).toBe('影响回答风格与偏好')
    expect(memoryImpact('constraint')).toBe('相关任务中作为规则执行')
    expect(memoryImpact('custom')).toBe('在相关问题中补充上下文')
  })

  it('keeps replay tool rendering when the live dashboard endpoint is unavailable', async () => {
    const injected: string[] = []
    const ctx = {
      slots: {
        inject(name: string, register: () => void) {
          injected.push(name)
          register()
        },
        register() {
          return () => undefined
        },
      },
    } as unknown as Context
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new Error('dashboard offline')))
    await apply(ctx)
    expect(injected).toEqual(['tool.call.toolview', 'conversation.input.left'])
    vi.unstubAllGlobals()
  })
})
