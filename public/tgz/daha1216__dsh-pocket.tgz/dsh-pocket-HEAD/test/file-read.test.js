// 主机侧 fileRead RPC（issue #17：手机复制文件内容）功能测试。
// 不引 jsdom：直接捕获 installPocketRpc 注册的处理函数，喂真实文件验证读写。
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { tmpdir, homedir } from 'node:os';
import { join } from 'node:path';
import { writeFileSync, mkdtempSync, unlinkSync, realpathSync } from 'node:fs';
import { installPocketRpc } from '../lib/web-rpc.js';
import { POCKET_ENDPOINTS } from '../client/api.js';

/** 用 mock ctx 抓住注册进来的 RPC 处理函数。 */
function makeCtx(extra = {}) {
  let handler = null;
  const ctx = {
    connection: {
      rpc: {
        handle: (_channel, fn) => { handler = fn; return () => {}; },
      },
    },
    ...extra,
  };
  return { ctx, call: (endpoint, payload, signal) => handler(endpoint, payload, signal) };
}

test('fileRead 端点已定义', () => {
  assert.equal(POCKET_ENDPOINTS.fileRead, 'pocket.fileRead');
});

test('fileRead 读取真实文件返回正文', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'pocket-fr-'));
  const file = join(dir, 'hello.txt');
  writeFileSync(file, 'hello dsh-pocket\n');
  const { ctx, call } = makeCtx();
  installPocketRpc(ctx, { service: { status: async () => ({}) } });
  const res = await call(POCKET_ENDPOINTS.fileRead, { path: file });
  assert.equal(res.ok, true);
  assert.equal(res.value.content, 'hello dsh-pocket\n');
  // Windows 临时目录可能是 8.3 短名（C:\Users\ADMINI~1\...），而 RPC 返回的是
  // realpath 长名；用 native realpath 归一后再比，断言两者指向同一文件。
  assert.equal(realpathSync.native(res.value.path), realpathSync.native(file));
  assert.equal(res.value.size, 'hello dsh-pocket\n'.length);
});

test('fileRead 相对路径按 process.cwd() 解析', async () => {
  // 测试进程 cwd 即仓库根，相对路径应解析到根目录 package.json。
  const { ctx, call } = makeCtx();
  installPocketRpc(ctx, { service: { status: async () => ({}) } });
  const res = await call(POCKET_ENDPOINTS.fileRead, { path: 'package.json' });
  assert.equal(res.ok, true, '仓库根 package.json 应可读（相对路径按 cwd 解析）');
  assert.ok(res.value.content.includes('dsh-pocket'));
});

test('fileRead 相对路径按传入 cwd 解析', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'pocket-fr-'));
  const file = join(dir, 'nested.txt');
  writeFileSync(file, 'cwd-resolved\n');
  const { ctx, call } = makeCtx();
  installPocketRpc(ctx, { service: { status: async () => ({}) } });
  // 传相对名 + cwd，应解析到 dir/nested.txt，而非 process.cwd()。
  const res = await call(POCKET_ENDPOINTS.fileRead, { path: 'nested.txt', cwd: dir });
  assert.equal(res.ok, true, '相对路径应按传入 cwd 解析');
  assert.equal(res.value.content, 'cwd-resolved\n');
});

test('fileRead 相对路径优先按会话 header.cwd 解析（不是客户端猜的 cwd）', async () => {
  // 多工作区：手机端 getWorkspaceCwd 只会拿到 workspaces.list 的第一项，
  // 与当前会话无关。会话 id 是客户端真正知道的东西，主机按它查 header.cwd，
  // 相对路径才会落在"这条消息所属项目"里。
  const sessionDir = mkdtempSync(join(tmpdir(), 'pocket-fr-session-'));
  const otherDir = mkdtempSync(join(tmpdir(), 'pocket-fr-other-'));
  writeFileSync(join(sessionDir, 'same-name.txt'), 'from-session-cwd\n');
  writeFileSync(join(otherDir, 'same-name.txt'), 'from-client-cwd\n');
  const sessions = {
    get: (id) => (id === 'sess-1' ? { header: { cwd: sessionDir } } : undefined),
  };
  const { ctx, call } = makeCtx({ get: (key) => (key === 'sessions' ? sessions : undefined) });
  installPocketRpc(ctx, { service: { status: async () => ({}) } });
  const res = await call(POCKET_ENDPOINTS.fileRead, {
    path: 'same-name.txt',
    cwd: otherDir, // 客户端猜错的 cwd：不该被采用
    sessionId: 'sess-1',
  });
  assert.equal(res.ok, true);
  assert.equal(res.value.content, 'from-session-cwd\n', '应读会话自己目录里的同名文件');
});

test('fileRead 会话查不到 cwd 时退回客户端 cwd', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'pocket-fr-fallback-'));
  writeFileSync(join(dir, 'only-here.txt'), 'fallback\n');
  const sessions = { get: () => undefined };
  const { ctx, call } = makeCtx({ get: (key) => (key === 'sessions' ? sessions : undefined) });
  installPocketRpc(ctx, { service: { status: async () => ({}) } });
  const res = await call(POCKET_ENDPOINTS.fileRead, {
    path: 'only-here.txt',
    cwd: dir,
    sessionId: 'gone',
  });
  assert.equal(res.ok, true, '会话已删除/不在本进程时仍要能读');
  assert.equal(res.value.content, 'fallback\n');
});

test('fileRead ~/ 展开为用户 HOME', async () => {
  // HOME 下建一个临时文件，用 ~/ 相对形式读取（HOME 一定存在）。
  const home = homedir();
  const marker = `pocket-fr-home-${Date.now()}.txt`;
  const file = join(home, marker);
  writeFileSync(file, 'home-file\n');
  const { ctx, call } = makeCtx();
  installPocketRpc(ctx, { service: { status: async () => ({}) } });
  try {
    const res = await call(POCKET_ENDPOINTS.fileRead, { path: `~/${marker}` });
    assert.equal(res.ok, true, '~/ 形式应展开为 HOME 后读取');
    assert.equal(res.value.content, 'home-file\n');
  } finally {
    try { unlinkSync(file); } catch { /* ignore */ }
  }
});

test('fileRead 缺少路径 / 文件不存在 / 目录 均报错', async () => {
  const { ctx, call } = makeCtx();
  installPocketRpc(ctx, { service: { status: async () => ({}) } });
  const missing = await call(POCKET_ENDPOINTS.fileRead, { path: '/no/such/file-xyz.txt' });
  assert.equal(missing.ok, false, '不存在的文件应报错');
  const nodir = await call(POCKET_ENDPOINTS.fileRead, { path: tmpdir() });
  assert.equal(nodir.ok, false, '目录应报错');
  const empty = await call(POCKET_ENDPOINTS.fileRead, {});
  assert.equal(empty.ok, false, '缺 path 应报错');
});

test('fileRead 超过 4MB 的文件直接拒绝（不在主机上整包读进内存）', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'pocket-fr-'));
  const file = join(dir, 'big.txt');
  writeFileSync(file, 'x'.repeat(4 * 1024 * 1024 + 1));
  const { ctx, call } = makeCtx();
  installPocketRpc(ctx, { service: { status: async () => ({}) } });
  const res = await call(POCKET_ENDPOINTS.fileRead, { path: file });
  assert.equal(res.ok, false, '超过上限应报错');
  assert.match(res.error?.message ?? '', /过大|too large/i);
  unlinkSync(file);
});

test('fileRead 二进制文件报错（不复制无意义文本）', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'pocket-fr-'));
  const file = join(dir, 'x.bin');
  writeFileSync(file, Buffer.from([0x00, 0x01, 0x02, 0x03]));
  const { ctx, call } = makeCtx();
  installPocketRpc(ctx, { service: { status: async () => ({}) } });
  const res = await call(POCKET_ENDPOINTS.fileRead, { path: file });
  assert.equal(res.ok, false, '二进制文件应报错');
});
