// 真实链路冒烟测试：不注入任何 stub，验证「真实代理转发 + polyfill 注入 + 状态快照 + RPC」。
// 之前的教训：测试全用 stub 会漏掉真实环境才出现的 bug（如 require 崩溃、未处理 rejection）。

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import { createPocketService } from '../lib/service.mjs';
import { installPocketRpc } from '../lib/web-rpc.js';
import { POCKET_RPC_CHANNEL, POCKET_ENDPOINTS } from '../client/api.js';

/** 假 dsh web：返回一个简单 HTML 文档（走真实 qrcode / 真实代理，无 stub）。 */
async function fakeUpstream() {
  const server = createServer((req, res) => {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    res.end('<!doctype html><html><head><title>dsh</title></head><body>real-dsh</body></html>');
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  return server;
}

function fakeCtxConnection() {
  let handler = null;
  const handle = (channel, fn) => {
    assert.equal(channel, POCKET_RPC_CHANNEL);
    handler = fn;
    return () => { handler = null; };
  };
  return { rpc: { handle }, get handler() { return handler; } };
}

test('真实链路：代理转发 + polyfill 注入 + 状态快照（无 stub）', async () => {
  const up = await fakeUpstream();
  const home = await mkdtemp(join(tmpdir(), 'smoke-'));
  const service = createPocketService({ dshPort: up.address().port, port: 0, home });
  try {
    await service.startProxy();
    const st = await service.status();
    assert.equal(st.proxyRunning, true);
    assert.ok(st.proxyPort > 0, '拿到真实监听端口');

    // 真实代理转发到假 dsh web，且 HTML 被注入 randomUUID polyfill
    const res = await fetch(`http://127.0.0.1:${st.proxyPort}/`);
    assert.equal(res.status, 200);
    const html = await res.text();
    assert.ok(html.includes('real-dsh'), '代理转发到上游');
    assert.ok(html.includes('randomUUID'), '非安全上下文 polyfill 已注入');

    // 状态快照：局域网 URL + 真实 qrcode 生成的二维码
    assert.ok(st.lanUrl.startsWith('http://'), '局域网 URL');
    assert.ok(st.lanQr.startsWith('data:image/png;base64,'), '真实 qrcode 生成的二维码');
  } finally {
    await service.dispose();
    await new Promise((r) => up.close(r));
    await rm(home, { recursive: true, force: true });
  }
});

test('真实链路：RPC status 走真实 service（含 restartNotice）', async () => {
  const up = await fakeUpstream();
  const home = await mkdtemp(join(tmpdir(), 'smoke-rpc-'));
  const service = createPocketService({ dshPort: up.address().port, port: 0, home });
  const conn = fakeCtxConnection();
  installPocketRpc({ connection: conn }, { service, log: { error() {}, warn() {} } });
  try {
    await service.startProxy();
    const r = await conn.handler(POCKET_ENDPOINTS.status, {});
    assert.equal(r.ok, true);
    assert.equal(r.value.proxyRunning, true);
    assert.ok(r.value.proxyPort > 0);
    assert.ok(r.value.lanQr.startsWith('data:image/png;base64,'), 'RPC 返回真实二维码');
    assert.equal(r.value.restartNotice, null, '无重启标记');
  } finally {
    await service.dispose();
    await new Promise((r) => up.close(r));
    await rm(home, { recursive: true, force: true });
  }
});

test('client 双分包均注入 React 绑定（PR #1 回归：mobile 组件曾 React is not defined）', async () => {
  const { readFileSync } = await import('node:fs');
  const mainSrc = readFileSync(new URL('../client/client.js', import.meta.url), 'utf8');
  const mobileSrc = readFileSync(new URL('../client/client.mobile.js', import.meta.url), 'utf8');
  assert.ok(mainSrc.includes('var React = require("react")'), 'client.js factory 注入 React 绑定');
  assert.ok(mainSrc.includes('createElement('), 'client.js 内存在 JSX 编译产物');
  assert.ok(mobileSrc.includes('var React = require("react")'), 'client.mobile.js factory 注入 React 绑定');
  assert.ok(mobileSrc.includes('React.createElement('), 'client.mobile.js 内存在 JSX 编译产物');
  const injectIdx = mobileSrc.indexOf('var React = require("react")');
  const createIdx = mobileSrc.indexOf('React.createElement(');
  assert.ok(injectIdx !== -1 && createIdx !== -1 && injectIdx < createIdx, 'React 声明先于使用');
});

test('client bundle：status 访问必须可选链（回归：1.9.0 白屏——首次渲染 status=null 时裸 status.lanAuthEnabled 抛 TypeError）', async () => {
  const { readFileSync } = await import('node:fs');
  const { settingsSource } = await import('./helpers/settings-source.js');
  const src = settingsSource();
  const bundle = readFileSync(new URL('../client/client.js', import.meta.url), 'utf8');
  assert.ok(src.includes('status?.lanAuthEnabled'), '源码存在可选链访问');
  assert.ok(!/(?<!\?)status\.lanAuthEnabled/.test(src), '源码不允许裸 status.lanAuthEnabled（必须可选链）');
  assert.ok(!bundle.includes('status.lanAuthEnabled'), 'bundle 不允许裸 status.lanAuthEnabled');
});

test('移动导航 backdrop（issue #38 镜像层）：backdrop 标记存在 + 抽屉层级高于三方插件抬升', async () => {
  const { readFileSync } = await import('node:fs');
  const src = readFileSync(new URL('../client/client.mobile.js', import.meta.url), 'utf8');
  assert.ok(/\[data-mobile-nav="backdrop"\]/.test(src), 'backdrop CSS 规则存在');
  assert.ok(src.includes('z-index: 1300 !important'), '抽屉层 z-index 1300（高于 overlay 抬升 500 与 web-ui-all 的 1100/1050）');
  assert.ok(!src.includes('z-index: 40 !important'), '不再用 40（会被第三方抬升的 overlay 盖住）');
  assert.ok(!src.includes('z-index: 600 !important'), '不再用 600（会被 web-ui-all 的 1050 遮罩盖住）');
});

test('公网免责声明（issue #31）：bundle 含弹框与勾选逻辑，RPC 必须带 disclaimer 确认', async () => {
  const { readFileSync } = await import('node:fs');
  const src = readFileSync(new URL('../client/client.js', import.meta.url), 'utf8');
  const { settingsSource } = await import('./helpers/settings-source.js');
  const clientSrc = settingsSource();
  assert.ok(src.includes('disclaimer'), 'bundle 含免责声明逻辑');
  assert.ok(clientSrc.includes('disclaimer: true'), '开启公网带免责声明确认参数');
});

test('文件浏览（2026-11-12）：只走宿主官方右侧栏，点 Files 关抽屉', async () => {
  const { readFileSync } = await import('node:fs');
  const src = readFileSync(new URL('../client/client.mobile.js', import.meta.url), 'utf8');
  const helper = readFileSync(new URL('../client/mobile/upstream/components/open-files-panel.ts', import.meta.url), 'utf8');
  assert.ok(helper.includes("'[data-sidebar-right-expand]'"), '用宿主右侧栏展开按钮');
  assert.ok(helper.includes("'[data-sidebar-right-toggle]'"), '用宿主右侧栏收起按钮');
  assert.ok(!helper.includes('aionui'), '不再回退第三方 explorer 列（#17）');
  assert.ok(src.includes('[data-mobile-nav="files"]'), 'Files 纳入抽屉内导航关闭');
});

test('更新契约（2026-11-12）：不探测 npm registry，也不代跑 dsh plugin update', async () => {
  const { readFileSync } = await import('node:fs');
  const files = {
    'lib/index.js': readFileSync(new URL('../lib/index.js', import.meta.url), 'utf8'),
    'lib/web-rpc.js': readFileSync(new URL('../lib/web-rpc.js', import.meta.url), 'utf8'),
    'client/client.js': readFileSync(new URL('../client/client.js', import.meta.url), 'utf8'),
    'client/client.mobile.js': readFileSync(new URL('../client/client.mobile.js', import.meta.url), 'utf8'),
  };
  for (const [name, text] of Object.entries(files)) {
    assert.equal(text.includes('registry.npmjs.org'), false, name + ' 不再访问 npm registry');
    assert.equal(text.includes('update --latest'), false, name + ' 不再代跑一键更新');
  }
  assert.equal(files['lib/index.js'].includes('performUpdate'), false, 'lib/index.js 没有一键更新的 spawn 实现');
  assert.equal(files['lib/web-rpc.js'].includes('POCKET_ENDPOINTS.update'), false, 'web-rpc 不再注册 pocket.update 端点');
});
