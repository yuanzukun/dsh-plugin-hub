import assert from 'node:assert/strict'
import { after, test } from 'node:test'
import { SessionId, SessionLogOffset } from '@deepseek-ai/dsh-session'
import { argsOf, startNotificationHost } from './helpers/notification-host.mjs'
import { createMockChannel } from './helpers/harness.mjs'

const channel = createMockChannel()
after(() => { globalThis.__approvalMockChannel = undefined })
const completed = async (host, session, turn = 1) => {
  const before = channel.spawns.length
  host.runTurn(session, { turn, kind: 'completed', withStep: true })
  await new Promise(resolve => setImmediate(resolve))
  const spawns = channel.spawns.slice(before).filter(r => argsOf(r).script === 'toast.ps1')
  assert.equal(spawns.length, 1)
  const result = argsOf(spawns[0])
  spawns[0].child.emit('exit', 0)
  await new Promise(resolve => setImmediate(resolve))
  return result
}
const restored = (host, id, title) => host.ctx.sessions.create(SessionId(id), {
  seed: [{ type: 'session/title', seq: 0, time: 1, data: { title, messageSeqs: [], source: { kind: 'user' } } }],
  inheritedEventCount: SessionLogOffset(1), meta: { cwd: process.cwd(), isSeeded: true },
})

test('已有会话恢复后完成通知读取保存的标题，不依赖新标题事件', async () => {
  const host = await startNotificationHost({ titleService: true })
  try {
    const s = restored(host, 'session-cold-title', '已有任务标题')
    const toast = await completed(host, s)
    assert.equal(toast.message.split('\n')[0], '任务：已有任务标题')
  } finally { await host.unload() }
})

test('手动改名后通知立即使用最新标题', async () => {
  const host = await startNotificationHost({ titleService: true })
  try {
    const s = restored(host, 'session-rename-title', '旧任务名称')
    host.ctx.sessionTitle.rename(s, '用户修改后的任务名称')
    const toast = await completed(host, s)
    assert.equal(toast.message.split('\n')[0], '任务：用户修改后的任务名称')
  } finally { await host.unload() }
})

test('通知插件重新加载后仍能读取原会话标题', async () => {
  const host = await startNotificationHost({ titleService: true })
  try {
    const s = host.createRoot('session-reload-title', { title: '重载后应保留的任务名称' })
    await host.fiber.dispose()
    const module = await import('../../lib/index.js')
    const fresh = host.ctx.plugin(module, host.cfg)
    await fresh
    try {
      const toast = await completed(host, s)
      assert.equal(toast.message.split('\n')[0], '任务：重载后应保留的任务名称')
    } finally { await fresh.dispose() }
  } finally { await host.unload() }
})

test('标题缓存淘汰后通知仍读取会话当前标题', async () => {
  const host = await startNotificationHost({ titleService: true })
  try {
    const first = host.createRoot('session-evicted-title', { title: '最早的任务名称' })
    for (let i = 0; i < 260; i++) host.createRoot('eviction-' + i, { title: '其他任务' + i })
    const toast = await completed(host, first)
    assert.equal(toast.message.split('\n')[0], '任务：最早的任务名称')
  } finally { await host.unload() }
})

test('无标题时显示有区分度的会话编号，不显示共同的 session- 前缀', async () => {
  const host = await startNotificationHost({ titleService: true })
  try {
    const s = host.createRoot('session-12345678-abcd')
    const toast = await completed(host, s)
    assert.equal(toast.message.split('\n')[0], '任务：会话 12345678')
  } finally { await host.unload() }
})

test('隐藏标题配置仍生效，default 声音传给 Windows 发送器', async () => {
  const host = await startNotificationHost({ titleService: true, config: { taskNotificationShowTitle: false, taskNotificationSound: 'default' } })
  try {
    const s = restored(host, 'session-87654321-abcd', '隐藏的任务名称')
    const toast = await completed(host, s)
    assert.equal(toast.message.split('\n')[0], '任务：会话 87654321')
    assert.equal(toast.sound, 'default')
  } finally { await host.unload() }
})

test('未配置声音时默认发送 Windows 提示音', async () => {
  const host = await startNotificationHost({ titleService: true, config: { taskNotificationSound: undefined } })
  try {
    const s = restored(host, 'session-default-sound', '系统提示音测试')
    const toast = await completed(host, s)
    assert.equal(toast.sound, 'default')
  } finally { await host.unload() }
})
