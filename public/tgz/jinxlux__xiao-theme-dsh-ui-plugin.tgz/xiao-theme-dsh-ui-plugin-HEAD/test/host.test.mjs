/**
 * Host \u534a\u7eaf\u51fd\u6570\u5355\u6d4b\uff08node:test\uff0c\u96f6\u7b2c\u4e09\u65b9\u4f9d\u8d56\uff09\u3002
 * \u9700\u5148\u6784\u5efa\uff1a\`pnpm run build\`\uff08\`pnpm test\` \u5df2\u5305\u542b\uff09\u3002
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import yaml from 'js-yaml';
import {
  parseRange,
  isAnimatedGif,
  videoFormatMatches,
  yamlLiteralBlock,
  normalizeConfig,
  normalizeBackgroundList,
  roleplayComposition,
  roleplayPlugins,
  roleplayPresetDefinition,
  agentPresetsSupportsRegister,
} from '../lib/index.js';

test('parseRange: \u5408\u6cd5\u533a\u95f4', () => {
  assert.deepEqual(parseRange('bytes=0-99', 1000), { start: 0, end: 99 });
  assert.deepEqual(parseRange('bytes=100-', 1000), { start: 100, end: 999 });
  assert.deepEqual(parseRange('bytes=-100', 1000), { start: 900, end: 999 });
  assert.deepEqual(parseRange('bytes=0-99999', 1000), { start: 0, end: 999 });
});

test('parseRange: \u975e\u6cd5/\u4e0d\u53ef\u6ee1\u8db3\u8fd4\u56de null', () => {
  assert.equal(parseRange(undefined, 1000), null);
  assert.equal(parseRange('', 1000), null);
  assert.equal(parseRange('items=0-1', 1000), null);
  assert.equal(parseRange('bytes=2000-', 1000), null);
  assert.equal(parseRange('bytes=5-2', 1000), null);
  assert.equal(parseRange('bytes=-0', 1000), null);
  assert.equal(parseRange('bytes=0-9', 0), null);
});

function gifWithGce(count) {
  const bytes = [0x47, 0x49, 0x46, 0x38, 0x39, 0x61]; // GIF89a
  for (let i = 0; i < count; i += 1) bytes.push(0x21, 0xf9, 0x04, 0x00);
  return Buffer.from(bytes);
}

test('isAnimatedGif: \u591a\u5e27\u5224\u5b9a', () => {
  assert.equal(isAnimatedGif(gifWithGce(2)), true);
  assert.equal(isAnimatedGif(gifWithGce(3)), true);
  assert.equal(isAnimatedGif(gifWithGce(1)), false);
  assert.equal(isAnimatedGif(gifWithGce(0)), false);
  assert.equal(isAnimatedGif(Buffer.from('not a gif at all')), false);
  assert.equal(isAnimatedGif(Buffer.alloc(3)), false);
});

function ftypHeader() {
  const b = Buffer.alloc(16);
  b.write('ftyp', 4, 'latin1');
  return b;
}
const EBML = Buffer.from([0x1a, 0x45, 0xdf, 0xa3, 0, 0, 0, 0, 0, 0, 0, 0]);

test('videoFormatMatches: \u5bb9\u5668\u7b7e\u540d\u4e0e\u6269\u5c55\u540d', () => {
  assert.equal(videoFormatMatches('.mp4', ftypHeader()), true);
  assert.equal(videoFormatMatches('.mov', ftypHeader()), true);
  assert.equal(videoFormatMatches('.m4v', ftypHeader()), true);
  assert.equal(videoFormatMatches('.webm', EBML), true);
  assert.equal(videoFormatMatches('.mp4', EBML), false);
  assert.equal(videoFormatMatches('.webm', ftypHeader()), false);
  assert.equal(videoFormatMatches('.mp4', Buffer.alloc(8)), false);
});

test('yamlLiteralBlock: \u7f29\u8fdb/\u8f6c\u4e49/\u7a7a\u767d\u5904\u7406', () => {
  assert.equal(yamlLiteralBlock('a: 1\n\nb', '  '), '  a: 1\n\n  b');
  assert.equal(yamlLiteralBlock('x: "y" # z', '    '), '    x: "y" # z');
  assert.equal(yamlLiteralBlock('\tlead', '  '), '   lead');
  assert.equal(yamlLiteralBlock('mid\ttab', '  '), '  mid\ttab');
  assert.equal(yamlLiteralBlock('trail   ', '  '), '  trail');
  assert.equal(yamlLiteralBlock('a\r\nb', '  '), '  a\n  b');
});

test('normalizeConfig: \u9ed8\u8ba4\u503c\u4e0e\u8303\u56f4\u94b3\u5236', () => {
  const d = normalizeConfig({});
  assert.equal(d.enabled, true);
  assert.equal(d.avatarPath, 'resource/avatar.png');
  assert.equal(d.backgroundBlur, 22);
  assert.equal(d.panelOpacity, 0.5);
  assert.equal(d.sidebarOpacity, 0.85);
  assert.equal(d.themeColor, '#2E8B72');
  assert.equal(d.roleplayEnabled, false);
  assert.equal(d.roleplayNetwork, false);
  assert.equal(d.backgroundVideoAudio, false);
  assert.equal(d.backgroundVideoVolume, 1, '视频背景音量默认满音量（保持旧行为）');

  const c = normalizeConfig({ backgroundBlur: 999, panelOpacity: 5, sidebarOpacity: -3, themeColor: 'nope' });
  assert.equal(c.backgroundBlur, 60);
  assert.equal(c.panelOpacity, 0.9);
  assert.equal(c.sidebarOpacity, 0);
  assert.equal(c.themeColor, '#2E8B72');
});

test('normalizeConfig: 视频背景音量钳制到 0–1，非法值回默认', () => {
  assert.equal(normalizeConfig({ backgroundVideoVolume: 0.35 }).backgroundVideoVolume, 0.35);
  assert.equal(normalizeConfig({ backgroundVideoVolume: 0 }).backgroundVideoVolume, 0);
  assert.equal(normalizeConfig({ backgroundVideoVolume: 5 }).backgroundVideoVolume, 1);
  assert.equal(normalizeConfig({ backgroundVideoVolume: -2 }).backgroundVideoVolume, 0);
  // 非法 / 缺失（含字符串）一律回默认 1，不会因为 NaN 让 <video>.volume 变成 0。
  assert.equal(normalizeConfig({ backgroundVideoVolume: 'x' }).backgroundVideoVolume, 1);
  assert.equal(normalizeConfig({ backgroundVideoVolume: Number.NaN }).backgroundVideoVolume, 1);
});

test('normalizeConfig: \u65e7\u5b57\u6bb5\u8fc1\u79fb\u4e0e\u4f18\u5148\u7ea7', () => {
  assert.equal(normalizeConfig({ backgroundOpacity: 0.7 }).panelOpacity, 0.7);
  assert.equal(normalizeConfig({ backgroundDarkOpacity: 0.8 }).panelOpacity, 0.8);
  assert.equal(normalizeConfig({ backgroundOpacity: 0.5 }).panelOpacity, 0.5);
  assert.equal(normalizeConfig({ panelOpacity: 0.4, backgroundOpacity: 0.7 }).panelOpacity, 0.4);
});

test('normalizeConfig: roleplay \u5f00\u5173\u300c\u7f3a\u5931\u5373 false\u300d', () => {
  assert.equal(normalizeConfig({}).roleplayEnabled, false);
  assert.equal(normalizeConfig({ roleplayEnabled: 'yes' }).roleplayEnabled, false);
  assert.equal(normalizeConfig({ roleplayEnabled: true }).roleplayEnabled, true);
  assert.equal(normalizeConfig({ roleplayNetwork: 1 }).roleplayNetwork, false);
  assert.equal(normalizeConfig({ roleplayNetwork: true }).roleplayNetwork, true);
});

test('normalizeConfig: \u5409\u7965\u7269\u6587\u6848\u515c\u5e95', () => {
  assert.equal(normalizeConfig({ mascotTitle: '   ' }).mascotTitle, '\u9756\u5996\u50a9\u821e');
  assert.equal(normalizeConfig({ mascotTitle: 'X' }).mascotTitle, 'X');
  assert.equal(normalizeConfig({ mascotSubtitle: '' }).mascotSubtitle, '');
});

test('normalizeBackgroundList: filter invalid, dedupe by path', () => {
  assert.deepEqual(normalizeBackgroundList(undefined), []);
  assert.deepEqual(normalizeBackgroundList('nope'), []);
  assert.deepEqual(normalizeBackgroundList([null, 1, {}, { path: '' }, { path: '   ' }]), []);
  assert.deepEqual(
    normalizeBackgroundList([
      { path: 'a.png', dynamic: true },
      { path: 'a.png', dynamic: false },
      { path: ' b.gif ' },
      { path: 'c.mp4', dynamic: 1 },
    ]),
    [
      { path: 'a.png', dynamic: true },
      { path: 'b.gif', dynamic: false },
      { path: 'c.mp4', dynamic: false },
    ],
  );
});

test('normalizeConfig: multi-background synthesis and mirroring (backward compatible)', () => {
  // Legacy single-background config (no list): synthesized to exactly one entry; old fields untouched.
  const legacy = normalizeConfig({ backgroundImagePath: 'x.png', backgroundDynamic: true });
  assert.deepEqual(legacy.backgroundList, [{ path: 'x.png', dynamic: true }]);
  assert.equal(legacy.backgroundImagePath, 'x.png');
  assert.equal(legacy.backgroundDynamic, true);
  // Defaults: list length is always >= 1; interval default 30.
  const def = normalizeConfig({});
  assert.equal(def.backgroundList.length, 1);
  assert.equal(def.backgroundList[0].path, 'resource/avatar.png');
  assert.equal(def.backgroundList[0].dynamic, false);
  assert.equal(def.backgroundInterval, 30);
  // Explicit list: first entry is mirrored back onto the legacy single fields.
  const multi = normalizeConfig({
    backgroundImagePath: 'ignored.png',
    backgroundList: [{ path: 'a.png' }, { path: 'b.gif', dynamic: true }],
    backgroundInterval: 5,
  });
  assert.deepEqual(multi.backgroundList, [
    { path: 'a.png', dynamic: false },
    { path: 'b.gif', dynamic: true },
  ]);
  assert.equal(multi.backgroundImagePath, 'a.png');
  assert.equal(multi.backgroundDynamic, false);
  assert.equal(multi.backgroundInterval, 5);
  // Interval clamping and fallback.
  assert.equal(normalizeConfig({ backgroundInterval: 9999 }).backgroundInterval, 600);
  assert.equal(normalizeConfig({ backgroundInterval: 0 }).backgroundInterval, 2);
  assert.equal(normalizeConfig({ backgroundInterval: 'x' }).backgroundInterval, 30);
});

// —— 角色空间预设：DSH 0.1.7 起改为「服务声明」，老版本仍走目录文件，两条路线必须同构 ——

test('roleplayPresetDefinition: 网络开关决定是否多挂 tool-web', () => {
  const off = roleplayPresetDefinition('你是魈。', false);
  assert.equal(off.id, 'xiao-roleplay');
  assert.equal(off.order, 90);
  assert.equal(typeof off.name, 'string');
  assert.equal(typeof off.description, 'string');
  assert.equal(off.plugins.length, 1);
  assert.equal(off.plugins[0].id, 'persona');
  assert.equal(off.plugins[0].config.prefix, '你是魈。');
  assert.equal(off.plugins[0].config.complete, true);
  assert.equal(off.plugins[0].config.includeRuntimeContext, false);

  const on = roleplayPresetDefinition('你是魈。', true);
  assert.equal(on.plugins.length, 2);
  assert.deepEqual(on.plugins[1], {
    id: 'tool-web',
    name: '@deepseek-ai/dsh-tool-web',
    config: { search: true, fetch: true, searchTimeoutMs: 60000 },
  });
  // 网络开关只影响是否多这一行，persona 行不受影响。
  assert.deepEqual(on.plugins[0], off.plugins[0]);
  // 说明文字随开关变化（选择器里要能看出有没有网络）。
  assert.notEqual(on.description, off.description);
});

test('agent.cordis.yml 解析结果与 roleplayPlugins 完全同构（防两条路线漂移）', () => {
  const persona = '你是魈。\n\n留白与空行必须原样保留。\n网络：不需要。';
  for (const network of [false, true]) {
    assert.deepEqual(yaml.load(roleplayComposition(persona, network)), roleplayPlugins(persona, network));
  }
  // 首尾空白/尾随换行的边界：YAML 的 |2- 必须剥掉尾部换行，与对象路线一致。
  const edge = '角色设定  ';
  assert.deepEqual(yaml.load(roleplayComposition(edge, false)), roleplayPlugins(edge, false));
});
test('agentPresetsSupportsRegister: 认 0.1.7 的 registry，不认 0.1.5/0.1.6 的目录 roster', () => {
  // 0.1.7+：@deepseek-ai/dsh-agent-preset-registry 提供的 agentPresets 服务
  assert.equal(agentPresetsSupportsRegister({ register: async () => async () => {} }), true);
  // 0.1.5 / 0.1.6：同名服务但只有目录 roster 的方法，没有 register
  assert.equal(
    agentPresetsSupportsRegister({
      list: async () => [],
      read: async () => '',
      copy: async () => undefined,
      deletePreset: async () => undefined,
      select: async () => undefined,
    }),
    false,
  );
  assert.equal(agentPresetsSupportsRegister({}), false);
  assert.equal(agentPresetsSupportsRegister(null), false);
  assert.equal(agentPresetsSupportsRegister(undefined), false);
  assert.equal(agentPresetsSupportsRegister({ register: 'nope' }), false);
  assert.equal(agentPresetsSupportsRegister('agentPresets'), false);
});
