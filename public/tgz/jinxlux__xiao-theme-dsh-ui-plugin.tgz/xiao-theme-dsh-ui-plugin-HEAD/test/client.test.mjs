/**
 * Client \u534a\u7eaf\u51fd\u6570\u5355\u6d4b\uff08\u914d\u8272\u5de5\u5177\uff09\u3002
 * \u901a\u8fc7\u4f2a window.__ModuleLoader__ \u8f7d\u5165\u6784\u5efa\u4ea7\u7269 lib/client.js\uff0c\u518d\u7528
 * \u58f3\u7684 require \u6267\u884c\u5176 CJS \u5de5\u5382\uff0c\u56e0\u6b64\u4e0d\u89e6\u78b0 DOM\u3002
 * \u9700\u5148\u6784\u5efa\uff1a\`pnpm run build\`\uff08\`pnpm test\` \u5df2\u5305\u542b\uff09\u3002
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';

const nodeRequire = createRequire(import.meta.url);
// \u6d4b\u8bd5\u53ea\u8c03\u7eaf\u51fd\u6570\uff0cReact \u53ea\u9700\u80fd\u88ab import\uff08\u7ec4\u4ef6\u4e0d\u4f1a\u6e32\u67d3\uff09\uff0c\u6545\u7528\u6700\u5c0f\u6869\u4fdd\u6301\u65e0\u4f9d\u8d56\u3002
const reactStub = {
  createElement: () => null,
  Fragment: 'Fragment',
  useState: (initial) => [typeof initial === 'function' ? initial() : initial, () => {}],
  useEffect: () => {},
  useRef: (initial) => ({ current: initial }),
  useCallback: (fn) => fn,
};

let captured = null;
globalThis.window = { __ModuleLoader__: { load: (def) => { captured = def; } } };
await import('../lib/client.js');
assert.ok(captured && typeof captured.factory === 'function', 'lib/client.js \u5e94\u8c03\u7528 __ModuleLoader__.load');
const mod = captured.factory((spec) => (spec === 'react' ? reactStub : nodeRequire(spec)));

test('parseHex', () => {
  assert.deepEqual(mod.parseHex('#2E8B72'), [46, 139, 114]);
  assert.deepEqual(mod.parseHex('2e8b72'), [46, 139, 114]);
  assert.deepEqual(mod.parseHex('#abc'), [170, 187, 204]);
  assert.equal(mod.parseHex('#xyz'), null);
  assert.equal(mod.parseHex(''), null);
});

test('rgbToHsl', () => {
  const red = mod.rgbToHsl(255, 0, 0);
  assert.equal(Math.round(red[0]), 0);
  assert.equal(Math.round(red[1]), 100);
  assert.equal(Math.round(red[2]), 50);
  assert.equal(Math.round(mod.rgbToHsl(0, 255, 0)[0]), 120);
  const gray = mod.rgbToHsl(128, 128, 128);
  assert.equal(gray[0], 0);
  assert.equal(gray[1], 0);
});

test('hslToRgb', () => {
  assert.deepEqual(mod.hslToRgb(0, 100, 50), [255, 0, 0]);
  assert.deepEqual(mod.hslToRgb(120, 100, 50), [0, 255, 0]);
  assert.deepEqual(mod.hslToRgb(240, 100, 50), [0, 0, 255]);
  assert.deepEqual(mod.hslToRgb(0, 0, 50), [128, 128, 128]);
});

test('shiftLight / shiftSat', () => {
  assert.equal(mod.shiftLight('nope', 10), 'nope');
  assert.equal(mod.shiftLight('#000000', -50), '#000000');
  assert.equal(mod.shiftLight('#ffffff', 50), '#ffffff');
  const lighter = mod.shiftLight('#2E8B72', 20);
  const l0 = mod.rgbToHsl(...mod.parseHex('#2E8B72'))[2];
  const l1 = mod.rgbToHsl(...mod.parseHex(lighter))[2];
  assert.ok(l1 > l0, '\u8c03\u4eae\u540e\u660e\u5ea6\u5e94\u589e\u5927');
  assert.equal(mod.shiftSat('nope', 10), 'nope');
  const desat = mod.shiftSat('#2E8B72', -100);
  assert.equal(Math.round(mod.rgbToHsl(...mod.parseHex(desat))[1]), 0);
});

test('deriveSurfaces', () => {
  const d = mod.deriveSurfaces('#2E8B72');
  assert.equal(d.light.length, 3);
  assert.equal(d.dark.length, 3);
  for (const v of [...d.light, ...d.dark]) assert.ok(Number.isFinite(v) && v >= 0 && v <= 255);
  assert.equal(mod.deriveSurfaces('nope').light.length, 3);
});

test('mascotText: factory defaults follow the UI language', () => {
  const doc = { documentElement: { lang: 'zh-CN' } };
  globalThis.document = doc;
  assert.equal(mod.mascotText('', 'title'), '靖妖傩舞');
  assert.equal(mod.mascotText('靖妖傩舞', 'title'), '靖妖傩舞');
  assert.equal(mod.mascotText('Bane of All Evil', 'title'), '靖妖傩舞');
  assert.equal(mod.mascotText('别挡路', 'subtitle'), '别挡路');
  assert.equal(mod.mascotText('自定义', 'title'), '自定义');
  doc.documentElement.lang = 'en';
  assert.equal(mod.mascotText('', 'title'), 'Bane of All Evil');
  assert.equal(mod.mascotText('靖妖傩舞', 'title'), 'Bane of All Evil');
  assert.equal(mod.mascotText('别挡路', 'subtitle'), 'Out of my way');
  assert.equal(mod.mascotText('custom', 'subtitle'), 'custom');
});

test('composeThemeTitle: 主题名原样 + 语言后缀（设置页左侧标题）', () => {
  // 主题名按用户所给原样保留，不翻译；只有后缀随界面语言变化。
  assert.equal(mod.composeThemeTitle('爱情', 'zh'), '爱情主题');
  assert.equal(mod.composeThemeTitle('爱情', 'en'), '爱情 Theme');
  assert.equal(mod.composeThemeTitle('Love', 'en'), 'Love Theme');
  assert.equal(mod.composeThemeTitle('  爱情  ', 'zh'), '爱情主题');
  // 尚未取到主题名（空 / 全空白）时回退到内置静态标题。
  assert.equal(mod.composeThemeTitle('', 'zh'), '魈主题');
  assert.equal(mod.composeThemeTitle('', 'en'), 'Xiao Theme');
  assert.equal(mod.composeThemeTitle('   ', 'zh'), '魈主题');
  // 内置默认主题「魈」沿用双语静态标题（英文不拼成「魈 Theme」）。
  assert.equal(mod.composeThemeTitle('魈', 'zh'), '魈主题');
  assert.equal(mod.composeThemeTitle('魈', 'en'), 'Xiao Theme');
});

test('composeEnableThemeLabel: 总开关文案跟随主题名（默认主题=历史文案）', () => {
  globalThis.document = { documentElement: { lang: 'zh-CN' } };
  assert.equal(mod.composeEnableThemeLabel('白厄', 'zh'), '启用白厄主题');
  assert.equal(mod.composeEnableThemeLabel('白厄', 'en'), 'Enable 白厄 Theme');
  assert.equal(mod.composeEnableThemeLabel('Love', 'en'), 'Enable Love Theme');
  assert.equal(mod.composeEnableThemeLabel('  白厄  ', 'zh'), '启用白厄主题');
  // 内置默认主题「魈」/ 尚未取到主题名：与历史文案「启用魈主题 / Enable Xiao Theme」一致。
  assert.equal(mod.composeEnableThemeLabel('魈', 'zh'), '启用魈主题');
  assert.equal(mod.composeEnableThemeLabel('', 'zh'), '启用魈主题');
  assert.equal(mod.composeEnableThemeLabel('', 'en'), 'Enable Xiao Theme');
  // lang 传 '' 时走 t()，即按当前 <html lang> 判定。
  assert.equal(mod.composeEnableThemeLabel('白厄', ''), '启用白厄主题');
  globalThis.document.documentElement.lang = 'en';
  assert.equal(mod.composeEnableThemeLabel('白厄', ''), 'Enable 白厄 Theme');
  assert.equal(mod.composeEnableThemeLabel('', ''), 'Enable Xiao Theme');
});

test('liveBgConfig: 轮播延迟回调必须读到最新配置（静音不被旧闭包恢复）', () => {
  // 轮播启动那一轮捕获的旧 cfg（当时有声音），以及用户后来静音后的最新 cfg。
  const stale = { backgroundVideoAudio: true, backgroundVideoVolume: 1 };
  const muted = { backgroundVideoAudio: false, backgroundVideoVolume: 0.5 };
  // 尚未同步过任何配置：退回闭包里的值（行为与改动前一致）。
  mod.setLiveBgConfig(null);
  assert.equal(mod.liveBgConfig(stale), stale);
  // 同步过一次之后（syncBackground 每次变更都会调 setLiveBgConfig）：
  mod.setLiveBgConfig(muted);
  const resolved = mod.liveBgConfig(stale);
  assert.equal(resolved.backgroundVideoAudio, false);
  assert.equal(resolved.backgroundVideoVolume, 0.5);
  // 反向同理：先静音后开声音，延迟创建的新项也必须按最新配置「要声音」。
  mod.setLiveBgConfig(stale);
  assert.equal(mod.liveBgConfig(muted).backgroundVideoAudio, true);
  // 还原成「未同步」状态，避免影响后续用例。
  mod.setLiveBgConfig(null);
});

test('buildPalette', () => {
  const p = mod.buildPalette('#2E8B72');
  const keys = Object.keys(p);
  assert.ok(keys.length > 0);
  assert.ok(keys.includes('--dsw-alias-bg-base'));
  assert.ok(keys.includes('--dsw-alias-brand-primary'));
  for (const k of keys) {
    assert.equal(typeof p[k].light, 'string');
    assert.equal(typeof p[k].dark, 'string');
  }
});

test('videoPlaythroughPlan: switch time = max(interval, duration)', () => {
  // interval shorter than the clip -> must play to the end
  assert.deepEqual(mod.videoPlaythroughPlan(3000, 10000), { loop: false, waitForEnded: true, switchAfterMs: 10000 });
  // interval longer than the clip -> loop until the timer
  assert.deepEqual(mod.videoPlaythroughPlan(30000, 10000), { loop: true, waitForEnded: false, switchAfterMs: 30000 });
  // equal -> play to the end
  assert.deepEqual(mod.videoPlaythroughPlan(10000, 10000), { loop: false, waitForEnded: true, switchAfterMs: 10000 });
  // unknown / non-finite duration -> timer only
  assert.deepEqual(mod.videoPlaythroughPlan(5000, null), { loop: true, waitForEnded: false, switchAfterMs: 5000 });
  assert.deepEqual(mod.videoPlaythroughPlan(5000, Number.POSITIVE_INFINITY), {
    loop: true,
    waitForEnded: false,
    switchAfterMs: 5000,
  });
});

test('bgVolume: 0–1 钳制，缺失 / 非法回默认 1', () => {
  assert.equal(mod.bgVolume({ backgroundVideoVolume: 0.4 }), 0.4);
  assert.equal(mod.bgVolume({ backgroundVideoVolume: 0 }), 0);
  assert.equal(mod.bgVolume({ backgroundVideoVolume: 1 }), 1);
  assert.equal(mod.bgVolume({ backgroundVideoVolume: 9 }), 1);
  assert.equal(mod.bgVolume({ backgroundVideoVolume: -1 }), 0);
  assert.equal(mod.bgVolume({ backgroundVideoVolume: Number.NaN }), 1);
  assert.equal(mod.bgVolume({}), 1);
  assert.equal(mod.bgVolume({ backgroundVideoVolume: '0.2' }), 1);
});

test('backgroundHasVideo: 只有视频背景才显示喇叭按钮', () => {
  const cfg = (over) => ({
    enabled: true,
    backgroundEnabled: true,
    backgroundImagePath: '',
    backgroundDynamic: false,
    backgroundList: [],
    ...over,
  });
  // 单张快路径（判定与 syncBackgroundSingle 同源：backgroundImagePath + backgroundDynamic）
  assert.equal(mod.backgroundHasVideo(cfg({ backgroundImagePath: 'a.mp4', backgroundDynamic: true })), true);
  assert.equal(mod.backgroundHasVideo(cfg({ backgroundImagePath: 'a.webm', backgroundDynamic: true })), true);
  assert.equal(mod.backgroundHasVideo(cfg({ backgroundImagePath: 'a.gif', backgroundDynamic: true })), false);
  assert.equal(mod.backgroundHasVideo(cfg({ backgroundImagePath: 'a.png', backgroundDynamic: false })), false);
  assert.equal(mod.backgroundHasVideo(cfg({ backgroundImagePath: 'a.mp4', backgroundDynamic: false })), false);
  // 轮播（≥2 项）：任意一项是视频就显示 —— 静态 / GIF 项本身没有声音
  assert.equal(mod.backgroundHasVideo(cfg({ backgroundList: [{ path: 'a.png' }, { path: 'b.mp4', dynamic: true }] })), true);
  assert.equal(mod.backgroundHasVideo(cfg({ backgroundList: [{ path: 'a.mp4', dynamic: true }, { path: 'b.png' }] })), true);
  assert.equal(mod.backgroundHasVideo(cfg({ backgroundList: [{ path: 'a.png' }, { path: 'b.gif', dynamic: true }] })), false);
  // 门控：总开关 / 背景开关关掉时不该出现
  assert.equal(mod.backgroundHasVideo(cfg({ enabled: false, backgroundImagePath: 'a.mp4', backgroundDynamic: true })), false);
  assert.equal(mod.backgroundHasVideo(cfg({ backgroundEnabled: false, backgroundImagePath: 'a.mp4', backgroundDynamic: true })), false);
});

test('settingsOpacity: 0–1 钳制，缺失 / 非法回默认 0.4（与界面 / 侧栏不透明度无关）', () => {
  assert.equal(mod.settingsOpacity({ settingsOpacity: 0.75 }), 0.75);
  assert.equal(mod.settingsOpacity({ settingsOpacity: 0 }), 0);
  assert.equal(mod.settingsOpacity({ settingsOpacity: 1 }), 1);
  // 越界钳制（允许拉满 100%，不套用面板的 0.9 封顶）
  assert.equal(mod.settingsOpacity({ settingsOpacity: -3 }), 0);
  assert.equal(mod.settingsOpacity({ settingsOpacity: 9 }), 1);
  // 缺失 / 非法 -> 默认 0.4
  assert.equal(mod.settingsOpacity({}), 0.4);
  assert.equal(mod.settingsOpacity({ settingsOpacity: Number.NaN }), 0.4);
  assert.equal(mod.settingsOpacity({ settingsOpacity: '0.8' }), 0.4);
  // 独立性：界面 / 侧栏不透明度取值不影响它
  assert.equal(mod.settingsOpacity({ panelOpacity: 0.9, sidebarOpacity: 0 }), 0.4);
});
