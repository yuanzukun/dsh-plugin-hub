/**
 * 魈主题 —— Client 半：青玉配色 + 吉祥物徽章 + 磨砂背景 + 设置页（提示词语言/自定义、背景图路径与上传、磨砂参数）。
 * 静态部署插件 bundle：由 DSH 客户端 ModuleLoader 加载，随页面启动自动生效。
 * 设置经 fetch('/xiao-theme/settings') 读写（Host 半自管配置，绕过 settings 白名单）。
 *
 * TypeScript 实现：与 xiao-ui-theme 行为一致，但经 `client.types` 强类型约束。
 * 构建时由 tsc 产出 ModuleLoader 兼容的 CommonJS，再由 scripts/wrap-client.mjs 包裹。
 */
import * as React from 'react';
import type { BackgroundEntry, XiaoConfig, ThemeSummary, ThemeListResponse, ThemeActivateResponse, ThemeExport, UploadEntry, UploadListResponse } from './config';
import type { ClientCtx, ClientPlugin, ThemeTokenValue } from './client.types';

/**
 * 客户端保持自包含：以下默认值与范围常量在运行时不依赖任何相对模块，
 * 与 Host 半（src/config.ts）保持一致，便于 tsc 直接产出单一 lib/client.js。
 */
const CLIENT_DEFAULT_CONFIG: XiaoConfig = {
  enabled: true,
  voiceEnabled: true,
  avatarPath: 'resource/avatar.png',
  voiceLanguage: 'en',
  voicePrompt: '',
  backgroundEnabled: true,
  backgroundImagePath: 'resource/avatar.png',
  backgroundDynamic: false,
  backgroundVideoAudio: false,
  // 视频背景音量（0–1）：默认 1 = 满音量（打开声音开关即原音量，与旧版一致）。
  backgroundVideoVolume: 1,
  // 多背景：默认空列表 = 由 backgroundImagePath/backgroundDynamic 合成的单张（与旧版完全一致）。
  backgroundList: [],
  backgroundInterval: 30,
  backgroundBlur: 22,
  panelOpacity: 0.5,
  sidebarOpacity: 0.85,
  // 设置页（DSH 设置对话框）独立不透明度：0.4 = 旧版在 panelOpacity 默认 0.5 下的实际观感。
  settingsOpacity: 0.4,
  themeColor: '#2E8B72',
  mascotTitle: '靖妖傩舞',
  mascotSubtitle: '别挡路',
  // 角色空间：**默认关闭**（老用户升级不会凭空多出一个 agent preset）；空字符串 = 使用 Host 内置的英文默认角色（魈）。
  roleplayEnabled: false,
  roleplayPersona: '',
  roleplayNetwork: false,
};
const CLIENT_RANGES = {
  backgroundVideoVolume: { min: 0, max: 1 },
  backgroundBlur: { min: 0, max: 60 },
  backgroundInterval: { min: 2, max: 600 },
  panelOpacity: { min: 0.3, max: 0.9 },
  sidebarOpacity: { min: 0, max: 1 },
  settingsOpacity: { min: 0, max: 1 },
} as const;
const PANEL_OPACITY_MAX = 0.9;

/** 内置默认主题名（与 Host 的 DEFAULT_THEME_NAME 一致）：默认主题沿用双语静态标题「魈主题 / Xiao Theme」。 */
const DEFAULT_THEME_NAME = '魈';

let bgVersion = 0;
let avatarVersion = 0;

/** DSH 当前界面语言（<html lang>）：zh* => 中文，否则英文。 */
function currentLangZh(): boolean {
  const lang = (document.documentElement.lang || '').toLowerCase();
  return lang.startsWith('zh');
}

/** 把 DSH 界面语言随 x-xiao-lang 头发给 Host，用于错误文案本地化。 */
function xiaoLangHeader(): Record<string, string> {
  return { 'x-xiao-lang': currentLangZh() ? 'zh' : 'en' };
}

/**
 * 吉祥物标题 / 副标的内置默认文案（随界面语言）。
 * config 里持久化的仍是中文出厂默认（不改持久化格式，向后兼容）：显示时若值为空、或等于任一语言的
 * 出厂默认，就按当前界面语言取默认文案；用户自定义过的文本原样显示。
 */
const MASCOT_DEFAULT_TEXT = {
  zh: { title: '靖妖傩舞', subtitle: '别挡路' },
  en: { title: 'Bane of All Evil', subtitle: 'Out of my way' },
} as const;

/** 要显示的吉祥物文案：出厂默认（或空）时随界面语言，否则用用户自定义文本。 */
function mascotText(value: string | undefined, field: 'title' | 'subtitle'): string {
  const raw = typeof value === 'string' ? value : '';
  const d = MASCOT_DEFAULT_TEXT;
  const isFactoryDefault = raw === '' || raw === d.zh[field] || raw === d.en[field];
  if (!isFactoryDefault) return raw;
  return currentLangZh() ? d.zh[field] : d.en[field];
}

/** 设置页 / 主题管理 / 徽章提示的文案字典（跟随 DSH 界面语言）。 */
const STR: Record<string, { zh: string; en: string }> = {
  themeTitle: { zh: '魈主题', en: 'Xiao Theme' },
  // 设置页左侧分区标题的后缀：主题名原样 + 语言后缀（英文保留前导空格，与 'Xiao Theme' 风格一致）。
  themeTitleSuffix: { zh: '主题', en: ' Theme' },
  // 总开关文案的前缀：与 composeThemeTitle 拼成「启用{主题名}主题 / Enable {name} Theme」。
  enableThemePrefix: { zh: '启用', en: 'Enable ' },
  themeColor: { zh: '主题颜色', en: 'Theme color' },
  voiceSection: { zh: '语气（工作会话）', en: 'Voice (work sessions)' },
  voiceSectionHint: { zh: '只改变说话方式：内容、工具与执行方式完全不变，不注入任何角色身份。', en: 'Tone only: the substance, tools and execution stay exactly the same; no character identity is injected.' },
  injectVoice: { zh: '注入语气', en: 'Inject voice' },
  templateLang: { zh: '模板语言', en: 'Template language' },
  customPrompt: { zh: '自定义提示词', en: 'Custom prompt' },
  promptPlaceholder: { zh: '留空则使用所选语言的默认模板；填写后优先使用自定义文本。', en: 'Leave empty to use the default template of the selected language; a custom prompt is used when set.' },
  restorePrompt: { zh: '恢复提示词默认', en: 'Reset prompt' },
  restoreThemeColor: { zh: '恢复主题颜色默认', en: 'Reset theme color' },
  restoreMascot: { zh: '恢复吉祥物默认', en: 'Reset mascot' },
  mascotSection: { zh: '吉祥物', en: 'Mascot' },
  avatarPath: { zh: '头像图片路径', en: 'Avatar image path' },
  titleField: { zh: '标题', en: 'Title' },
  subtitleField: { zh: '副标', en: 'Subtitle' },
  bgSection: { zh: '磨砂背景', en: 'Frosted background' },
  enableBg: { zh: '启用磨砂背景', en: 'Enable frosted background' },
  bgPath: { zh: '背景图路径', en: 'Background image path' },
  uploadBg: { zh: '选择/上传背景图', en: 'Choose/upload background' },
  uploadAvatar: { zh: '选择/上传头像', en: 'Choose/upload avatar' },
  uploadsTitle: { zh: '管理上传文件', en: 'Manage uploads' },
  uploadsEmpty: { zh: '还没有上传文件。点下方「上传」即可新增，或打开文件夹放入文件后刷新。', en: 'No uploaded files yet. Tap "Upload" below to add one, or open the folder to drop files then refresh.' },
  uploadsUse: { zh: '使用此文件', en: 'Use this file' },
  uploadsOpenFolder: { zh: '打开上传文件夹', en: 'Open upload folder' },
  uploadsClose: { zh: '关闭', en: 'Close' },
  uploadsCurrent: { zh: '当前使用', en: 'In use' },
  uploadsUsedBy: { zh: '用于', en: 'Used by' },
  uploadsFetchError: { zh: '读取上传列表失败', en: 'Failed to load uploads' },
  uploadsUpload: { zh: '上传', en: 'Upload' },
  uploadsUploading: { zh: '上传中…', en: 'Uploading…' },
  uploadsUploadFailed: { zh: '上传失败', en: 'Upload failed' },
  uploadsFolderOpened: { zh: '已尝试打开上传文件夹', en: 'Attempted to open the upload folder' },
  uploadsFolderFailed: { zh: '打开失败，请手动前往此目录', en: 'Failed to open. Go to the folder manually:' },
  blurStrength: { zh: '磨砂强度', en: 'Blur strength' },
  uiOpacity: { zh: '界面不透明度', en: 'UI opacity' },
  sidebarOpacity: { zh: '侧栏不透明度', en: 'Sidebar opacity' },
  settingsOpacity: { zh: '设置页不透明度', en: 'Settings page opacity' },
  settingsOpacityHint: { zh: '只作用于 DSH 设置对话框本身（含面板里的卡片 / 输入框），与「界面不透明度」「侧栏不透明度」互不影响。拖动时即时预览，松开保存。', en: 'Applies only to the DSH settings dialog itself (including the cards and inputs inside it), independent of "UI opacity" and "Sidebar opacity". Drag to preview live, release to save.' },
  useStaticDefault: { zh: '使用静态背景默认', en: 'Use static background default' },
  useDynamicExample: { zh: '使用动态背景示例', en: 'Use dynamic GIF example' },
  videoAudio: { zh: '视频背景声音', en: 'Background video audio' },
  videoVolume: { zh: '视频背景音量', en: 'Background video volume' },
  videoVolumeHint: { zh: '0% 完全无声；拖动滑杆会自动取消静音。吉祥物徽章里也有同一根音量滑杆，两边随时同步。声音还需要页面加载后先交互一次才会响（浏览器自动播放策略）。', en: '0% is silent; moving the slider unmutes automatically. The mascot badge carries the same volume slider and stays in sync. Sound also needs one interaction after page load (browser autoplay policy).' },
  soundUnmute: { zh: '开启视频背景声音', en: 'Turn on background video sound' },
  soundMute: { zh: '关闭视频背景声音（静音）', en: 'Mute background video' },
  // —— 多背景轮播 ——
  bgPathFirstMulti: { zh: '背景图路径（第 1 项）', en: 'Background path (item 1)' },
  bgListTitle: { zh: '多背景轮播', en: 'Multi-background rotation' },
  bgAddFromUploads: { zh: '从已上传文件添加', en: 'Add from uploads' },
  bgDynamicTag: { zh: '动态', en: 'Dynamic' },
  bgStaticTag: { zh: '静态', en: 'Static' },
  bgPickerAddTitle: { zh: '选择要加入轮播的背景', en: 'Choose backgrounds to add' },
  bgAlreadyAdded: { zh: '已添加', en: 'Added' },
  uploadsDone: { zh: '完成', en: 'Done' },
  bgRemove: { zh: '移除', en: 'Remove' },
  bgMoveUp: { zh: '上移', en: 'Move up' },
  bgMoveDown: { zh: '下移', en: 'Move down' },
  bgInterval: { zh: '切换间隔', en: 'Switch interval' },
  bgAddDuplicate: { zh: '该文件已在列表中', en: 'Already in the list' },
  bgListHint: { zh: '列表 ≥ 2 项时按上方「切换间隔」轮播：静态图与 GIF 到点即切；视频在「间隔 ≤ 时长」时播完才切、「间隔 > 时长」时循环播到点再切。切换用固定约 0.7 秒的交叉渐变。只有 1 项时与旧版单背景完全一致。', en: 'With 2+ items the list rotates at the "Switch interval" above: static images and GIFs switch on the timer; a video is always played to the end when the interval is shorter than it, and loops until the timer when the interval is longer. Switching uses a fixed ~0.7s cross-fade. With a single item, behaviour is exactly the old single background.' },
  settingsHint: { zh: '改动即时生效。背景图/头像路径支持相对插件目录（如 resource/avatar.png）或本地绝对路径，也可直接上传图片/视频（保存到 ~/.dsh/xiao-theme-uploads/）。上传 GIF 动图或 MP4/WebM 视频会自动识别为动态背景（视频背景可在下方选择是否播放声音，并用音量滑杆调大小）；静态图片或单帧 GIF 仍按原静态磨砂背景处理。头像同样可通过上传替换。背景支持多张轮播：在上方列表里添加第 2 张起即进入轮播，切换间隔可调。', en: 'Changes take effect immediately. The background/avatar path supports a plugin-relative path (e.g. resource/avatar.png) or a local absolute path; you can also upload an image or video (saved to ~/.dsh/xiao-theme-uploads/). An uploaded animated GIF or MP4/WebM video is auto-detected as a dynamic background (video backgrounds can optionally play sound below, with a volume slider); static images or single-frame GIFs keep the static frosted treatment. The avatar can also be replaced by uploading. Multiple backgrounds rotate: add a second item in the list above to start rotating, with an adjustable interval.' },
  themeManager: { zh: '主题管理', en: 'Theme management' },
  themeManagerHint: { zh: '所有设置修改都会自动保存为当前主题修改。如果想创建新主题，请用「另存为新主题」创建，再在新主题下修改，才不会覆盖现在这个主题的设置。', en: 'All setting changes are automatically saved to the current theme. To create a new theme, use "Save as new theme" first, then edit under that new theme so you don\'t overwrite the current theme\'s settings.' },
  currentTheme: { zh: '当前主题', en: 'Current theme' },
  saveAsNewTheme: { zh: '另存为新主题', en: 'Save as new theme' },
  themeNamePlaceholder: { zh: '主题名称', en: 'Theme name' },
  save: { zh: '保存', en: 'Save' },
  restoreDefault: { zh: '恢复默认', en: 'Restore defaults' },
  restoreCurrentTheme: { zh: '恢复当前主题默认', en: 'Restore current theme to defaults' },
  confirmRestore: { zh: '确认恢复默认', en: 'Confirm restore' },
  restoreWarn: { zh: '注意：恢复默认会把【整个设置】重置回最初的「魈」主题（出厂默认值）。若当前使用的是其它主题，请谨慎使用。', en: 'Caution: restoring defaults resets the ENTIRE settings back to the original "Xiao" theme (factory defaults). If you are currently on another theme, use with care.' },
  rename: { zh: '重命名', en: 'Rename' },
  exportTheme: { zh: '导出', en: 'Export' },
  deleteTheme: { zh: '删除', en: 'Delete' },
  confirmDelete: { zh: '确认删除', en: 'Confirm delete' },
  builtinSuffix: { zh: '（内置）', en: ' (built-in)' },
  activeSuffix: { zh: '（当前）', en: ' (active)' },
  themeListTitle: { zh: '主题列表', en: 'Theme list' },
  activeTag: { zh: '当前', en: 'Active' },
  builtinTag: { zh: '内置', en: 'Built-in' },
  useTheme: { zh: '使用', en: 'Use' },
  useThemeHint: { zh: '切换为当前主题', en: 'Switch to this theme' },
  importTheme: { zh: '导入主题', en: 'Import theme' },
  importThemePrefix: { zh: '导入主题 ', en: 'Imported theme ' },
  refresh: { zh: '刷新', en: 'Refresh' },
  chooseFile: { zh: '选择文件', en: 'Choose file' },
  saveFailed: { zh: '保存失败，已恢复为服务器上的设置', en: 'Save failed; reverted to the settings on the server' },
  needThemeName: { zh: '请输入主题名称', en: 'Please enter a theme name' },
  invalidImportFile: { zh: '无效的导入文件', en: 'Invalid import file' },
  importMissingConfig: { zh: '导入文件缺少 config', en: 'Import file is missing config' },
  builtinNotDelete: { zh: '内置主题不可删除', en: 'Built-in theme cannot be deleted' },
  mascotDragClose: { zh: '按住拖动，点 × 关闭', en: 'Drag to move, click × to close' },
  mascotDragOpen: { zh: '按住拖动，轻点重新打开', en: 'Drag to move, tap to reopen' },
  mascotShow: { zh: '重新显示魈主题提示', en: 'Show the Xiao theme badge' },
  mascotClose: { zh: '关闭魈主题提示', en: 'Close the Xiao theme badge' },
  // —— 角色空间（娱乐）——
  roleplaySection: { zh: '角色空间（娱乐）', en: 'Roleplay (entertainment)' },
  roleplayEnable: { zh: '启用角色空间', en: 'Enable roleplay' },
  roleplayNetwork: { zh: '允许网络检索', en: 'Allow web lookup' },
  roleplayNetworkHint: { zh: '开启后，角色会话会挂载 DSH 的网络工具（web_search / web_fetch），让角色开演前能先查最新的剧情、形象与设定；文件、命令、任务权限仍然没有。默认关闭。', en: 'When on, the roleplay session mounts DSH web tools (web_search / web_fetch) so the character can look up the latest plot, design and lore before playing; file, command and task access stay blocked. Off by default.' },
  roleplayPersona: { zh: '角色系统提示词', en: 'Roleplay system prompt' },
  roleplayPersonaPlaceholder: { zh: '留空使用内置的「魈」角色设定（英文）；填入任意角色的完整设定即可换角色。', en: 'Leave empty to use the built-in Xiao role (English); paste any full character prompt to switch roles.' },
  roleplayApply: { zh: '应用/更新预设', en: 'Apply / update preset' },
  roleplayResetPersona: { zh: '恢复默认角色（魈）', en: 'Reset to default role (Xiao)' },
  roleplayOpenFolder: { zh: '打开预设文件夹', en: 'Open preset folder' },
  roleplayApplied: { zh: '已按当前角色文本更新预设', en: 'Preset updated from the current role text' },
  roleplayStatusInstalled: { zh: '预设已安装', en: 'Preset installed' },
  roleplayStatusMissing: { zh: '预设未安装', en: 'Preset not installed' },
  roleplayStatusOff: { zh: '角色空间已关闭（未安装预设）', en: 'Roleplay is off (no preset installed)' },
  roleplayStatusMasterOff: { zh: '主题总开关已关闭：角色空间不生效，预设已移除。', en: 'The theme master switch is off: roleplay is inactive and its preset has been removed.' },
  roleplayStatusUnknown: { zh: '读取预设状态失败', en: 'Failed to read preset status' },
  roleplayHint: { zh: '默认关闭：打开上面的开关才会安装预设。角色会话是一个独立会话：开一个新会话，在顶部选择「角色空间（娱乐）」预设即可进入角色。它使用上面的完整角色设定作为系统提示词，且不挂载任何文件/命令工具，因此不会影响也不需要牺牲工作会话的能力；两边的历史互不相通。', en: 'Off by default: turn the switch above on to install the preset. A roleplay session is a separate session: start a new session and pick the "Roleplay" preset at the top to enter character. It uses the full character prompt above as its system prompt and mounts no file or command tools, so a work session\'s capability is neither affected nor traded away; the two keep separate histories.' },
  roleplayHintWork: { zh: '工作会话只保留上方的「语气」注入，永不注入角色身份。', en: 'Work sessions keep only the tone injection above and never receive a character identity.' },
  mascotCloseTip: { zh: '关闭（可随时从风印重新打开）', en: 'Close (reopen anytime from the wind mark)' },
};

/** 取当前语言的文案；未知 key 原样返回。 */
function t(key: string): string {
  const entry = STR[key];
  if (!entry) return key;
  return currentLangZh() ? entry.zh : entry.en;
}

/** 带 webkit 厂商前缀的 style（@types/react 的 DOM lib 未覆盖该属性）。 */
interface StyleWithWebkit extends CSSStyleDeclaration {
  webkitBackdropFilter?: string;
}

/** 默认主题主色：魈的青玉绿。 */
const DEFAULT_THEME_COLOR = '#2E8B72';

/**
 * 由主色派生整套青玉系配色 token（浅色 + 深色）。
 * 语义功能色（state-error/warn/success）保持固定；青玉相关的 bg/border/brand/label/sidebar 跟随主色。
 */
function buildPalette(hex: string): Record<string, ThemeTokenValue> {
  const base = parseHex(hex) || parseHex(DEFAULT_THEME_COLOR)!;
  const [h, s, l] = rgbToHsl(base[0], base[1], base[2]);
  const tone = (lightSat: number, lightL: number, darkSat: number, darkL: number): [string, string] => {
    // 返回 [lightHex, darkHex]
    const li = hslToRgb(h, Math.max(8, Math.min(90, lightSat)), lightL);
    const dk = hslToRgb(h, Math.max(8, Math.min(80, darkSat)), darkL);
    return [toHex(li[0], li[1], li[2]), toHex(dk[0], dk[1], dk[2])];
  };
  const bgBase = tone(s * 0.12, 95, s * 0.4, 7);
  const bgLayer1 = tone(s * 0.16, 90, s * 0.5, 12);
  const bgLayer2 = tone(s * 0.2, 84, s * 0.55, 16);
  const bgOverlay = tone(s * 0.1, 97, s * 0.4, 9);
  const border1 = tone(s * 0.22, 78, s * 0.5, 26);
  const border2 = tone(s * 0.28, 70, s * 0.55, 34);
  const brandDark = hslToRgb(h, Math.min(100, Math.max(40, s * 0.85)), Math.max(64, l * 1.5));
  const brand: [string, string] = [toHex(base[0], base[1], base[2]), toHex(brandDark[0], brandDark[1], brandDark[2])];
  const labelPri = tone(s * 0.4, 24, s * 0.18, 92);
  const labelSec = tone(s * 0.3, 42, s * 0.2, 72);
  const sidebar = tone(s * 0.14, 92, s * 0.45, 8);
  return {
    '--dsw-alias-bg-base': { light: bgBase[0], dark: bgBase[1] },
    '--dsw-alias-bg-layer-1': { light: bgLayer1[0], dark: bgLayer1[1] },
    '--dsw-alias-bg-layer-2': { light: bgLayer2[0], dark: bgLayer2[1] },
    '--dsw-alias-bg-overlay': { light: bgOverlay[0], dark: bgOverlay[1] },
    // DSH 0.1.7 起文件预览/PDF 面吃这个 token（0.1.5 只吃 bg-base）；补进色板，避免它保留 DSH 的不透明中性色。
    '--dsw-alias-bg-document-preview': { light: bgLayer1[0], dark: bgLayer1[1] },
    '--dsw-alias-border-l1': { light: border1[0], dark: border1[1] },
    '--dsw-alias-border-l2': { light: border2[0], dark: border2[1] },
    '--dsw-alias-brand-primary': { light: brand[0], dark: brand[1] },
    '--dsw-alias-label-primary': { light: labelPri[0], dark: labelPri[1] },
    '--dsw-alias-label-secondary': { light: labelSec[0], dark: labelSec[1] },
    '--dsw-alias-state-error-primary': { light: '#B4442F', dark: '#D9694F' },
    '--dsw-alias-state-success-primary': { light: '#2F7D5C', dark: '#58B08C' },
    '--dsw-alias-state-warn-primary': { light: '#B0872E', dark: '#D4AB4F' },
    '--dsw-specific-sidebar-fill': { light: sidebar[0], dark: sidebar[1] },
  };
}

/** 当前主色对应的青玉系配色 token（默认魈青玉绿，主色变化时由 buildTokens 重建）。 */
function xiaoTokens(hex: string): Record<string, ThemeTokenValue> {
  return buildPalette(hex);
}

/** 极小可订阅 store：配置 + 订阅通知。 */
interface ConfigStore {
  getSnapshot(): XiaoConfig;
  set(next: XiaoConfig): void;
  subscribe(listener: () => void): () => void;
}

function createConfigStore(): ConfigStore {
  let value: XiaoConfig = { ...CLIENT_DEFAULT_CONFIG };
  const listeners = new Set<() => void>();
  return {
    getSnapshot: () => value,
    set: (next) => {
      value = next;
      for (const listener of [...listeners]) {
        try {
          listener();
        } catch (error) {
          console.error('[xiao-theme] listener failed:', error);
        }
      }
    },
    subscribe: (listener) => {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
  };
}

/** 一条用户可见提示的小订阅容器（设置页展示一行 warn；写入成功时清空）。 */
interface NoticeStore {
  get(): string | null;
  set(next: string | null): void;
  subscribe(listener: () => void): () => void;
}

function createNoticeStore(): NoticeStore {
  let value: string | null = null;
  const listeners = new Set<() => void>();
  return {
    get: () => value,
    set: (next) => {
      if (next === value) return;
      value = next;
      for (const listener of [...listeners]) {
        try {
          listener();
        } catch (error) {
          console.error('[xiao-theme] notice listener failed:', error);
        }
      }
    },
    subscribe: (listener) => {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
  };
}

/** 保存失败提示（模块级单例：saveConfig 上报，设置页展示）。 */
const saveError = createNoticeStore();

/**
 * 写入串行化 / 合并（纯优化，成功路径语义不变）：
 * 同一时刻至多一个在途 POST；期间的多次改动只标脏，由当前循环再写一次「最新快照」，
 * 避免高频改动（滑块 pointerup / blur）并发写、乱序覆盖。失败时回滚为服务器真值并给出可见提示。
 */
let saveDirty = false;
let saveRun: Promise<void> | null = null;
/** 上一次「服务器已确认」的背景 / 头像路径：只有真正变化才 +1 缓存指纹。 */
let savedBgPath: string = CLIENT_DEFAULT_CONFIG.backgroundImagePath;
let savedAvatarPath: string = CLIENT_DEFAULT_CONFIG.avatarPath;

/** 用服务器返回值刷新缓存指纹基线（读取 / 保存成功 / 重置共用）。 */
function rememberSavedPaths(cfg: XiaoConfig): void {
  if (typeof cfg.backgroundImagePath === 'string') savedBgPath = cfg.backgroundImagePath;
  if (typeof cfg.avatarPath === 'string') savedAvatarPath = cfg.avatarPath;
}

/** 从 Host 半读配置（同时用作保存失败后的回滚 / 重同步）。 */
async function loadConfig(store: ConfigStore): Promise<void> {
  try {
    const response = await fetch('/xiao-theme/settings', { cache: 'no-store', headers: xiaoLangHeader() });
    if (!response.ok) return;
    const cfg = (await response.json()) as XiaoConfig;
    rememberSavedPaths(cfg);
    store.set(cfg);
  } catch (error) {
    console.error('[xiao-theme] load settings failed:', error);
  }
}

/** 把待写改动落盘：串行 + 合并；失败则回滚为服务器真值并提示。 */
function drainSaves(store: ConfigStore): Promise<void> {
  if (saveRun !== null) return saveRun;
  saveRun = (async () => {
    try {
      while (saveDirty) {
        saveDirty = false;
        const sent = store.getSnapshot();
        let response: Response;
        try {
          response = await fetch('/xiao-theme/settings', {
            method: 'POST',
            headers: { 'content-type': 'application/json', ...xiaoLangHeader() },
            body: JSON.stringify(sent),
          });
        } catch (error) {
          saveDirty = false;
          saveError.set(t('saveFailed') + ': ' + (error instanceof Error ? error.message : String(error)));
          await loadConfig(store);
          return;
        }
        if (!response.ok) {
          saveDirty = false;
          saveError.set(t('saveFailed') + ': ' + (await errorText(response)));
          await loadConfig(store);
          return;
        }
        let saved: XiaoConfig;
        try {
          saved = (await response.json()) as XiaoConfig;
        } catch {
          saved = sent;
        }
        // 背景 / 头像路径真正变化时 +1 版本号，让 URL 缓存指纹变化，避免竞态拿到旧图。
        if (typeof saved.backgroundImagePath === 'string' && saved.backgroundImagePath !== savedBgPath) bgVersion++;
        if (typeof saved.avatarPath === 'string' && saved.avatarPath !== savedAvatarPath) avatarVersion++;
        rememberSavedPaths(saved);
        saveError.set(null);
        // 期间又产生新改动：这一份可能已过期，不用它覆盖刚做的乐观更新；下一轮写最新快照。
        if (!saveDirty) store.set(saved);
      }
    } finally {
      saveRun = null;
      // 兜底：循环退出与标脏之间若有错过，补一次。
      if (saveDirty) void drainSaves(store);
    }
  })();
  return saveRun;
}

/**
 * 保持「单张旧字段」与「多背景列表首项」一致 —— 它们是同一份数据的两种读法。
 * - patch 显式带了 backgroundList → 用其首项回写 backgroundImagePath / backgroundDynamic；
 * - patch 只带单张字段（旧交互：选择/上传背景、手动改路径）→ 只更新列表首项，其余项保留；
 * - 两者都没带 → 原样返回。
 * 这样旧的单张控件无需改动，就能在多背景下正确修改「第 1 张」，而不会让轮播列表失同步。
 */
function withBackgroundMirror(next: XiaoConfig, patch: Partial<XiaoConfig>): XiaoConfig {
  const hasList = Object.prototype.hasOwnProperty.call(patch, 'backgroundList');
  const hasSingle =
    Object.prototype.hasOwnProperty.call(patch, 'backgroundImagePath') ||
    Object.prototype.hasOwnProperty.call(patch, 'backgroundDynamic');
  if (!hasList && !hasSingle) return next;
  const list = effectiveBackgroundList(next).map((entry) => ({ ...entry }));
  if (hasSingle && !hasList) {
    list[0] = { path: next.backgroundImagePath, dynamic: next.backgroundDynamic === true };
  }
  const first = list[0]!;
  return { ...next, backgroundList: list, backgroundImagePath: first.path, backgroundDynamic: first.dynamic };
}

/** 写配置到 Host 半：本地立即乐观更新，实际写入走串行化队列（返回排空该队列的 promise）。 */
function saveConfig(store: ConfigStore, patch: Partial<XiaoConfig>): Promise<void> {
  store.set(withBackgroundMirror({ ...store.getSnapshot(), ...patch }, patch));
  saveDirty = true;
  return drainSaves(store);
}

/** 把「当前主题」整体重置为出厂默认配置（Host 侧 restoreDefaults=true）。 */
async function restoreConfig(store: ConfigStore): Promise<void> {
  await drainSaves(store); // 先把排队中的写入落盘，避免与重置交错
  const response = await fetch('/xiao-theme/settings', {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...xiaoLangHeader() },
    body: JSON.stringify({ restoreDefaults: true }),
  });
  if (!response.ok) throw new Error(await errorText(response));
  const saved = (await response.json()) as XiaoConfig;
  if (typeof saved.backgroundImagePath === 'string' && saved.backgroundImagePath !== savedBgPath) bgVersion++;
  if (typeof saved.avatarPath === 'string' && saved.avatarPath !== savedAvatarPath) avatarVersion++;
  rememberSavedPaths(saved);
  saveError.set(null);
  store.set(saved);
}

/** 从失败的响应里提取 Host 返回的本地化错误文案；解析不到则回退到 HTTP 状态码。 */
async function errorText(response: Response): Promise<string> {
  try {
    const data = (await response.json()) as { error?: unknown };
    if (data && typeof data.error === 'string' && data.error.length > 0) return data.error;
  } catch {
    /* body 非 JSON，忽略 */
  }
  return 'HTTP ' + response.status;
}

/**
 * 上传背景图/视频到 Host，成功后把返回路径写入配置。
 * 返回 null 表示成功；否则返回用户可见的错误信息（来自 Host 的本地化 error 字段）。
 */
/** 上传背景文件，返回 Host 给出的路径与动态标记（只上传、不写配置，由调用方决定用途）。 */
async function uploadBackgroundFile(file: File): Promise<{ path: string; dynamic: boolean } | { error: string }> {
  const match = /\.([a-zA-Z0-9]+)$/.exec(file.name || '');
  const ext = match ? match[1]!.toLowerCase() : 'png';
  try {
    const response = await fetch('/xiao-theme/upload?ext=.' + encodeURIComponent(ext), {
      method: 'POST',
      headers: xiaoLangHeader(),
      body: file,
    });
    if (!response.ok) {
      console.error('[xiao-theme] upload failed:', response.status);
      return { error: await errorText(response) };
    }
    const data = (await response.json()) as { imagePath?: unknown; dynamic?: unknown };
    if (data && typeof data.imagePath === 'string' && data.imagePath.length > 0) {
      // Host 已自动识别是否为动态背景：动画 GIF / 视频 => dynamic=true；静态图/单帧 GIF => false。
      return { path: data.imagePath, dynamic: data.dynamic === true };
    }
    return { error: 'HTTP ' + response.status };
  } catch (error) {
    console.error('[xiao-theme] upload failed:', error);
    return { error: error instanceof Error && error.message ? error.message : 'Upload failed' };
  }
}

/**
 * 上传背景图/视频到 Host，成功后把返回路径写入配置（替换「第 1 张」背景；多背景下其余项保留）。
 * 返回 null 表示成功；否则返回用户可见的错误信息（来自 Host 的本地化 error 字段）。
 */
async function uploadBackground(store: ConfigStore, file: File): Promise<string | null> {
  const result = await uploadBackgroundFile(file);
  if ('error' in result) return result.error;
  const patch: Partial<XiaoConfig> = { backgroundImagePath: result.path, backgroundDynamic: result.dynamic };
  await saveConfig(store, patch);
  return null;
}

/** 上传头像图到 Host，成功后把返回的路径写入配置（头像无“动态背景”概念，只取 imagePath）。返回 null=成功，否则返回错误信息。 */
async function uploadAvatar(store: ConfigStore, file: File): Promise<string | null> {
  const match = /\.([a-zA-Z0-9]+)$/.exec(file.name || '');
  const ext = match ? match[1]!.toLowerCase() : 'png';
  try {
    const response = await fetch('/xiao-theme/upload?ext=.' + encodeURIComponent(ext) + '&kind=avatar', {
      method: 'POST',
      headers: xiaoLangHeader(),
      body: file,
    });
    if (!response.ok) {
      console.error('[xiao-theme] avatar upload failed:', response.status);
      return await errorText(response);
    }
    const data = (await response.json()) as { imagePath?: unknown };
    if (data && typeof data.imagePath === 'string' && data.imagePath.length > 0) {
      await saveConfig(store, { avatarPath: data.imagePath });
      return null;
    }
    return 'HTTP ' + response.status;
  } catch (error) {
    console.error('[xiao-theme] avatar upload failed:', error);
    return error instanceof Error && error.message ? error.message : 'Upload failed';
  }
}

/** 取路径的文件名部分（用于列表展示；同时兼容 \\ 与 / 分隔）。 */
function shortBgName(pathValue: string): string {
  const parts = pathValue.replace(/\\/g, '/').split('/');
  return parts[parts.length - 1] || pathValue;
}

/**
 * 背景列表行的缩略图地址：
 * - 上传目录内的文件走 uploads-file（不依赖「启用磨砂背景」，把背景关掉也能看到预览）；
 * - 其余（插件内置 resource/…、本机绝对路径）走 /xiao-bg 的对应列表项。
 */
function bgThumbUrl(entry: BackgroundEntry, index: number): string {
  const normalized = entry.path.replace(/\\/g, '/');
  const name = shortBgName(entry.path);
  if (normalized.indexOf('xiao-theme-uploads') >= 0 && name.length > 0) {
    return '/xiao-theme/uploads-file?name=' + encodeURIComponent(name);
  }
  return '/xiao-bg?i=' + index + '&p=' + encodeURIComponent(entry.path) + '&v=' + bgVersion;
}

/** 通用 JSON fetch：非 2xx 抛出带 error 文本的异常。 */
async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, { ...init, headers: { ...(init && init.headers ? init.headers : {}), ...xiaoLangHeader() } });
  if (!response.ok) {
    let msg = 'HTTP ' + response.status;
    try {
      const data = (await response.json()) as { error?: unknown };
      if (data && typeof data.error === 'string' && data.error.length > 0) msg = data.error;
    } catch {
      /* 忽略解析失败 */
    }
    throw new Error(msg);
  }
  return (await response.json()) as T;
}

// —— 主题管理 API ——
async function listThemes(): Promise<ThemeListResponse> {
  return fetchJson<ThemeListResponse>('/xiao-theme/themes', { cache: 'no-store' });
}

/**
 * 当前活动主题名（设置页左侧分区标题 + 设置页内标题用）。
 * 主题切换 / 重命名 / 删除后由设置页的 refresh 写入，订阅者据此重注册 settings.section 更新标题
 * （设置页内的标题则直接订阅 activeThemeNameListeners 重渲染）。
 * 主题名以用户实际命名为准，**不做翻译**；只有「主题」/「 Theme」后缀随界面语言变化。
 */
let activeThemeName = '';
const activeThemeNameListeners = new Set<() => void>();

function setActiveThemeName(next: string): void {
  if (next === activeThemeName) return;
  activeThemeName = next;
  for (const listener of [...activeThemeNameListeners]) {
    try {
      listener();
    } catch (error) {
      console.error('[xiao-theme] active theme name listener failed:', error);
    }
  }
}

/** 当前活动主题名（尚未取到时为 `''`）。设置页内标题与左侧分区标题共用。 */
function getActiveThemeName(): string {
  return activeThemeName;
}

/** 从 Host 拉取当前活动主题名（失败保持原值）；插件启动时调用一次，补上设置页打开前的标题。 */
async function refreshActiveThemeName(): Promise<void> {
  try {
    const res = await listThemes();
    const active = res.themes.find((item) => item.id === res.activeThemeId);
    setActiveThemeName(active ? active.name : '');
  } catch (error) {
    console.error('[xiao-theme] load active theme name failed:', error);
  }
}

/**
 * 设置页左侧分区标题：{主题名} + 语言后缀。主题名原样使用（用户给「爱情」，英文界面也是「爱情」），
 * 后缀随界面语言：中文「主题」、英文「 Theme」。尚未取到主题名、或仍是内置默认主题「魈」时，
 * 沿用双语静态标题（「魈主题」/「Xiao Theme」），避免默认主题在英文界面被拼成「魈 Theme」。
 */
function composeThemeTitle(name: string, lang: 'zh' | 'en' | ''): string {
  const trimmed = typeof name === 'string' ? name.trim() : '';
  // 尚未取到主题名，或仍是内置默认主题「魈」：沿用双语静态标题，而不是「魈 Theme」。
  if (trimmed.length === 0 || trimmed === DEFAULT_THEME_NAME) {
    if (lang === 'zh') return STR.themeTitle!.zh;
    if (lang === 'en') return STR.themeTitle!.en;
    return t('themeTitle');
  }
  const suffix =
    lang === 'zh' ? STR.themeTitleSuffix!.zh : lang === 'en' ? STR.themeTitleSuffix!.en : t('themeTitleSuffix');
  return trimmed + suffix;
}

/**
 * 「总开关」勾选框的文案：`启用前缀 + 设置页标题`（即 `{前缀}{主题名}主题` / `{prefix}{name} Theme`）。
 * 默认主题 / 尚未取到主题名时与历史文案逐字一致：「启用魈主题」/「Enable Xiao Theme」。
 * `lang` 传 `''` 时前缀与标题都走 `t()`，即按当前 `<html lang>` 判语言。
 */
function composeEnableThemeLabel(name: string, lang: 'zh' | 'en' | ''): string {
  const prefix =
    lang === 'zh' ? STR.enableThemePrefix!.zh : lang === 'en' ? STR.enableThemePrefix!.en : t('enableThemePrefix');
  return prefix + composeThemeTitle(name, lang);
}

async function createTheme(name: string): Promise<ThemeSummary> {
  return fetchJson<ThemeSummary>('/xiao-theme/themes', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ name }),
  });
}
async function activateTheme(id: string): Promise<ThemeActivateResponse> {
  return fetchJson<ThemeActivateResponse>('/xiao-theme/themes-activate', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ id }),
  });
}
async function renameTheme(id: string, name: string): Promise<ThemeSummary> {
  return fetchJson<ThemeSummary>('/xiao-theme/themes-rename', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ id, name }),
  });
}
async function deleteTheme(id: string): Promise<{ activeThemeId: string }> {
  return fetchJson<{ activeThemeId: string }>('/xiao-theme/themes-delete', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ id }),
  });
}
async function exportTheme(id: string): Promise<ThemeExport> {
  return fetchJson<ThemeExport>('/xiao-theme/themes-export?id=' + encodeURIComponent(id), { cache: 'no-store' });
}
async function importTheme(name: string, config: XiaoConfig, version?: number): Promise<ThemeSummary> {
  return fetchJson<ThemeSummary>('/xiao-theme/themes-import', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(typeof version === 'number' ? { name, config, version } : { name, config }),
  });
}

// —— 角色空间（娱乐）API ——
/** GET /xiao-theme/roleplay：预设安装状态（设置页只读展示）。 */
interface RoleplayStatus {
  presetId: string;
  presetName: string;
  enabled: boolean;
  /** 预设当前是否挂了网络工具（Host 端 roleplayNetwork）。 */
  network?: boolean;
  installed: boolean;
  path: string;
}

async function getRoleplayStatus(): Promise<RoleplayStatus> {
  return fetchJson<RoleplayStatus>('/xiao-theme/roleplay', { cache: 'no-store' });
}
async function applyRoleplayPreset(): Promise<{ ok?: boolean; installed?: boolean }> {
  return fetchJson<{ ok?: boolean; installed?: boolean }>('/xiao-theme/roleplay-apply', { method: 'POST' });
}
async function openRoleplayFolder(): Promise<{ ok?: boolean; path?: string }> {
  return fetchJson<{ ok?: boolean; path?: string }>('/xiao-theme/roleplay-open-folder', { method: 'POST' });
}

/** 触发浏览器下载：导出主题为 .json 文件。 */
function downloadTheme(theme: ThemeExport): void {
  const blob = new Blob([JSON.stringify(theme, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  try {
    const a = document.createElement('a');
    a.href = url;
    a.download = (theme.name || 'xiao-theme') + '.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
  } finally {
    URL.revokeObjectURL(url);
  }
}
/** 根据配置构建主题 token 层：背景开启时把面板底色换成半透明（浅色/深色统一受 panelOpacity 控制）。 */
function buildTokens(cfg: XiaoConfig): Record<string, ThemeTokenValue> {
  const themeColor = typeof cfg.themeColor === 'string' && cfg.themeColor.length > 0 ? cfg.themeColor : DEFAULT_THEME_COLOR;
  const tokens: Record<string, ThemeTokenValue> = xiaoTokens(themeColor);
  if (cfg.backgroundEnabled !== false) {
    // panelOpacity 作用于界面底色；封顶 0.9，保证背景图恒有 ≥10% 透出（不再因拉满而糊死背景）。
    const p = clamp01(typeof cfg.panelOpacity === 'number' ? cfg.panelOpacity : 0.5);
    const light = Math.min(p, PANEL_OPACITY_MAX);
    const dark = Math.min(p, PANEL_OPACITY_MAX);
    // 半透明底色的浅深 RGB 随主题主色派生（不再是固定青玉 RGB）。
    const surf = deriveSurfaces(themeColor);
    const [lr, lg, lb] = surf.light;
    const [dr, dg, db] = surf.dark;
    tokens['--dsw-alias-bg-base'] = { light: rgba(lr, lg, lb, light), dark: rgba(dr, dg, db, dark) };
    tokens['--dsw-alias-bg-layer-1'] = {
      light: rgba(lr, lg, lb, Math.max(light - 0.06, 0.25)),
      dark: rgba(dr, dg, db, Math.max(dark - 0.06, 0.25)),
    };
    tokens['--dsw-alias-bg-layer-2'] = {
      light: rgba(lr, lg, lb, Math.max(light - 0.1, 0.2)),
      dark: rgba(dr, dg, db, Math.max(dark - 0.1, 0.2)),
    };
    // layer-3 原先是本主题的缺口（DSH 默认是不透明的静态中性色），better-sidebar 的卡片/标签条会用到它，
    // 不补的话右栏内部会留下一块「不跟主题、也不跟不透明度」的实色。透度取 1/2 之间（DSH 原层级顺序）。
    tokens['--dsw-alias-bg-layer-3'] = {
      light: rgba(lr, lg, lb, Math.max(light - 0.08, 0.22)),
      dark: rgba(dr, dg, db, Math.max(dark - 0.08, 0.22)),
    };
    tokens['--dsw-alias-bg-overlay'] = {
      light: rgba(lr, lg, lb, Math.min(light + 0.12, PANEL_OPACITY_MAX)),
      dark: rgba(dr, dg, db, Math.min(dark + 0.12, PANEL_OPACITY_MAX)),
    };
    tokens['--dsw-specific-sidebar-fill'] = {
      light: rgba(lr, lg, lb, Math.max(light - 0.14, 0.25)),
      dark: rgba(dr, dg, db, Math.max(dark - 0.14, 0.25)),
    };
    // 文件预览/PDF 面（0.1.7 的 --dsw-alias-bg-document-preview）随「界面不透明度」：与中列同档，
    // 保证代码/PDF 仍可读，同时不再是一块实色。
    tokens['--dsw-alias-bg-document-preview'] = {
      light: rgba(lr, lg, lb, light),
      dark: rgba(dr, dg, db, dark),
    };
  }
  return tokens;
}

/** 定位 shell 根框架（frame）：在带 gridTemplateColumns 的候选里挑子列数最多的那个，再兜底 #root 首子元素。 */
function findFrameElement(): HTMLElement | null {
  const candidates = document.querySelectorAll('div[style*="grid-template-columns"]');
  let best: HTMLElement | null = null;
  let bestCount = -1;
  for (const el of Array.from(candidates)) {
    if (!(el instanceof HTMLElement)) continue;
    const count = el.children.length;
    const w = el.getBoundingClientRect().width;
    if (count > bestCount && w > 0) {
      bestCount = count;
      best = el;
    }
  }
  if (best) return best;
  const root = document.getElementById('root');
  if (root && root.firstElementChild && root.firstElementChild.tagName === 'DIV') {
    const w = root.firstElementChild.getBoundingClientRect().width;
    if (w > 0) return root.firstElementChild as HTMLElement;
  }
  return (document.querySelector('#root > div') as HTMLElement | null) || null;
}

/** 判断背景路径是否为视频（mp4/webm/mov/m4v）：视频背景即动态背景，用 <video> 元素渲染。 */
function isVideoPath(pathValue: string): boolean {
  return /\.(mp4|webm|mov|m4v)$/i.test(pathValue || '');
}

/**
 * 每个背景 <video> 各自的「等首次用户交互」监听清理句柄。
 * 用 WeakMap 而不是单个全局变量：轮播里两层各有自己的 <video>，单一全局句柄会被后者覆盖，
 * 导致前一个元素的监听泄漏、声音恢复失效。
 */
const bgVideoGestureCleanup = new WeakMap<HTMLVideoElement, () => void>();
/** 同一 <video> 上待执行的交互动作（可与静音降级叠加，不互相覆盖）。 */
const bgVideoGestureActions = new WeakMap<HTMLVideoElement, Array<() => void>>();

/**
 * 浏览器是否已有用户激活（决定能否「带声音」自动播放）。
 * 缺失 navigator.userActivation 时保守返回 false —— 先静音播，等首次交互再恢复声音。
 */
function hasUserActivation(): boolean {
  try {
    const ua = (navigator as Navigator & { userActivation?: { hasBeenActive?: boolean } }).userActivation;
    return ua !== undefined && ua.hasBeenActive === true;
  } catch {
    return false;
  }
}

/** 清掉某个背景 <video> 上的交互监听与待执行动作。 */
function clearBgVideoGesture(video: HTMLVideoElement): void {
  const cleanup = bgVideoGestureCleanup.get(video);
  if (cleanup) {
    cleanup();
    bgVideoGestureCleanup.delete(video);
  }
  bgVideoGestureActions.delete(video);
}

/**
 * 挂一次性「首次用户交互」监听（pointerdown / keydown，捕获阶段）。
 * 同一个 <video> 上重复调用只追加动作、不覆盖已有监听，避免丢掉更早登记的动作
 * （例如「静音也播不动 → 交互后重播」与「有声音开关 → 交互后恢复声音」会同时登记）。
 */
function armBgVideoGesture(video: HTMLVideoElement, action: () => void): void {
  const pending = bgVideoGestureActions.get(video);
  if (pending) {
    pending.push(action);
    return;
  }
  const actions: Array<() => void> = [action];
  bgVideoGestureActions.set(video, actions);
  let done = false;
  const run = (): void => {
    if (done) return;
    done = true;
    cleanup();
    for (const act of actions) act();
  };
  const cleanup = (): void => {
    window.removeEventListener('pointerdown', run, true);
    window.removeEventListener('keydown', run, true);
    bgVideoGestureCleanup.delete(video);
    bgVideoGestureActions.delete(video);
  };
  window.addEventListener('pointerdown', run, true);
  window.addEventListener('keydown', run, true);
  bgVideoGestureCleanup.set(video, cleanup);
}

/** 取合法音量（0–1；缺失 / 非法回默认值 1）。导出供单测直接验证。 */
export function bgVolume(cfg: XiaoConfig): number {
  return clampNum(
    cfg.backgroundVideoVolume,
    CLIENT_RANGES.backgroundVideoVolume.min,
    CLIENT_RANGES.backgroundVideoVolume.max,
    CLIENT_DEFAULT_CONFIG.backgroundVideoVolume,
  );
}

/**
 * 让一个背景 <video> 播起来，并统一处理浏览器自动播放策略（单张快路径与轮播共用）。
 * - 目标静音：直接 play()。已在播放时再调 play() 是空操作，故可在每次配置同步时安全重调。
 * - 目标有声：已有用户激活 → 带声播；尚无激活 → 先静音播（背景不空窗），
 *   并登记「首次交互后恢复声音」。
 * - play() 被拒：有声被拦 → 降级静音重播；静音也被拦（站点禁用自动播放）→ 留首帧，等交互再试。
 *
 * ⚠️ 绝不可以在没有用户激活时把 muted 置为 false：Chromium 的自动播放策略不允许无激活的
 * 有声播放，会把已经在播的静音元素直接停住；而轮播在列表/间隔未变时不会重建 <video>，
 * 于是画面永远停住，直到用户手动切主题（既有激活、列表又变了才重新创建并播放）。
 * - volume：目标音量（0–1），写入 <video>.volume；为 0 时按静音处理，不请求有声自动播放。
 */
function playBgVideo(video: HTMLVideoElement, wantMuted: boolean, volume: number): void {
  clearBgVideoGesture(video);
  const vol = clamp01(volume);
  video.volume = vol;
  // 音量 0 等同静音：不为「有声音」去请求有声自动播放（必被浏览器拒绝，还白登记一次手势）。
  const audible = !wantMuted && vol > 0;
  const canBeAudible = audible && hasUserActivation();
  video.muted = !canBeAudible;
  const start = (): void => {
    const played = video.play();
    if (played && typeof played.catch === 'function') {
      played.catch(() => {
        if (!video.isConnected) return;
        if (!video.muted) {
          // 有声自动播放被拦：降级为静音循环，背景不放空。
          video.muted = true;
          start();
          return;
        }
        // 连静音自动播放都被拦（站点策略）：留首帧，等首次交互再试。
        armBgVideoGesture(video, start);
      });
    }
  };
  start();
  if (audible && !canBeAudible) {
    armBgVideoGesture(video, () => {
      if (!video.isConnected) return;
      video.muted = false;
      start();
    });
  }
}

/** 移除视频背景 <video> 元素并清理声音恢复监听。 */
function removeBgVideo(): void {
  const v = document.getElementById('xiao-theme-video') as HTMLVideoElement | null;
  if (v) {
    v.pause();
    clearBgVideoGesture(v);
    v.remove();
  }
}

/** 创建/更新视频背景 <video> 元素：铺满、循环、可选声音（默认静音以允许自动播放）。 */
function syncBgVideo(cfg: XiaoConfig, active: boolean): void {
  let v = document.getElementById('xiao-theme-video') as HTMLVideoElement | null;
  if (!active) {
    removeBgVideo();
    return;
  }
  if (!v) {
    v = document.createElement('video');
    v.id = 'xiao-theme-video';
    v.dataset.plugin = 'xiao-theme-ts';
    v.autoplay = true;
    v.loop = true;
    v.playsInline = true;
    v.setAttribute('playsinline', '');
    v.style.position = 'fixed';
    v.style.inset = '0';
    v.style.width = '100%';
    v.style.height = '100%';
    v.style.objectFit = 'cover';
    v.style.zIndex = '-1';
    v.style.pointerEvents = 'none';
    document.body.appendChild(v);
  }
  const src = '/xiao-bg?p=' + encodeURIComponent(cfg.backgroundImagePath || '') + '&v=' + bgVersion;
  if (v.dataset.src !== src) {
    v.dataset.src = src;
    v.src = src;
  }
  // 自动播放策略统一交给 playBgVideo：目标有声但尚无用户激活时，它会先静音播并登记
  // 「首次交互后恢复声音」，而不是直接写 muted=false（那会把已播放的元素停住）。
  playBgVideo(v, cfg.backgroundVideoAudio !== true, bgVolume(cfg));
}

/**
 * 写入「设置页不透明度」一族 CSS 变量。**只有 DSH 设置对话框的规则消费它们**（见 XIAO_CSS 里的
 * `[data-shortcut-modal="settings"]` 一族），与界面 / 侧栏两族完全并列、互不引用。
 *
 * 取值：面板本体 = sl；面板内表面（卡片 / 输入框 / 悬浮层）比面板高 0.04–0.12 一档，保证层次感，
 * 同时仍随滑杆**单调**变化（拖到 0 全透、拖到 1 全实）。每个变量都是当场算好的具体 rgba，
 * 不存在「把自己置空又去 var() 它」的自我引用陷阱（右栏曾踩过）。
 */
function writeSettingsOpacityVars(
  de: HTMLElement,
  surfaces: { light: [number, number, number]; dark: [number, number, number] },
  sl: number,
): void {
  const [lr, lg, lb] = surfaces.light;
  const [dr, dg, db] = surfaces.dark;
  const at = (delta: number): number => Math.min(sl + delta, 1);
  de.style.setProperty('--xiao-settings-ovl', rgba(lr, lg, lb, sl));
  de.style.setProperty('--xiao-settings-ovl-l1', rgba(lr, lg, lb, at(0.06)));
  de.style.setProperty('--xiao-settings-ovl-l3', rgba(lr, lg, lb, at(0.04)));
  de.style.setProperty('--xiao-settings-ovl-overlay', rgba(lr, lg, lb, at(0.12)));
  de.style.setProperty('--xiao-settings-ovl-dark', rgba(dr, dg, db, sl));
  de.style.setProperty('--xiao-settings-ovl-dark-l1', rgba(dr, dg, db, at(0.06)));
  de.style.setProperty('--xiao-settings-ovl-dark-l3', rgba(dr, dg, db, at(0.04)));
  de.style.setProperty('--xiao-settings-ovl-dark-overlay', rgba(dr, dg, db, at(0.12)));
}

/** 取合法的「设置页不透明度」（缺失 / 非法 / 非数回默认 0.4）。导出供单测直接验证。 */
export function settingsOpacity(cfg: XiaoConfig): number {
  return clampNum(cfg.settingsOpacity, CLIENT_RANGES.settingsOpacity.min, CLIENT_RANGES.settingsOpacity.max, CLIENT_DEFAULT_CONFIG.settingsOpacity);
}

/**
 * 写入磨砂背景的「公共视觉层」：模糊强度、主色渐变、面板 / 侧栏 / 设置页不透明度变量，以及根框架的
 * inline 兜底（CSS 选择器未命中时仍能透出并模糊）。单张背景与多背景轮播共用，因此每次配置变更
 * 都会调用 —— 拖滑杆 / 切明暗主题即时生效。不含路径、<video> 与图层本身（那些各自负责）。
 */
function applyBackgroundChrome(cfg: XiaoConfig): void {
  const de = document.documentElement;
  const blur = clampNum(typeof cfg.backgroundBlur === 'number' ? cfg.backgroundBlur : 22, 0, 60, 22);
  // 统一的不透明度：浅色/深色共用同一 alpha（封顶 0.9 保证背景图恒可见），仅 RGB 底色随主题区分。
  const p = clamp01(typeof cfg.panelOpacity === 'number' ? cfg.panelOpacity : 0.5);
  const ovl = Math.min(p, PANEL_OPACITY_MAX);
  // 侧栏独立不透明度：允许到 1.0（sidebar 可完全 100% 不透明），与主面板 0.9 封顶解耦。
  const so = clamp01(typeof cfg.sidebarOpacity === 'number' ? cfg.sidebarOpacity : 0.85);
  // 面板/侧栏底色的浅深 RGB 随主题主色派生。
  const surf = deriveSurfaces(typeof cfg.themeColor === 'string' ? cfg.themeColor : DEFAULT_THEME_COLOR);
  const [lr, lg, lb] = surf.light;
  const [dr, dg, db] = surf.dark;
  const themeColor = typeof cfg.themeColor === 'string' && cfg.themeColor.length > 0 ? cfg.themeColor : DEFAULT_THEME_COLOR;
  de.classList.add('xiao-bg-on');
  de.style.setProperty('--xiao-bg-blur', blur + 'px');
  // 背景渐变随主色：中段 = 主色，两端为同色暗/亮。
  de.style.setProperty('--xiao-theme-color', themeColor);
  de.style.setProperty('--xiao-grad-a', shiftLight(themeColor, -44));
  de.style.setProperty('--xiao-grad-b', shiftLight(themeColor, -30));
  de.style.setProperty('--xiao-bg-ovl', rgba(lr, lg, lb, ovl));
  de.style.setProperty('--xiao-bg-ovl-dark', rgba(dr, dg, db, ovl));
  // 侧栏杆：浅色/深色各一个变量，由 CSS 属性选择器套到 sidebarCol/detailsCol 上。
  de.style.setProperty('--xiao-sidebar-ovl', rgba(lr, lg, lb, so));
  de.style.setProperty('--xiao-sidebar-ovl-dark', rgba(dr, dg, db, so));
  // 右栏面板内部的语义 token 覆盖值（见 XIAO_CSS 的 [data-sidebar-right-panel] 规则）：面板内的
  // tab 条/卡片走 --dsw-alias-bg-layer-1/2/3，比面板底色略实一点，既保住内容可读性，又让整体
  // 仍随侧栏不透明度单调变化（so=0 近全透、so=1 完全不透明）。不设 0.25 之类下限，否则拖到 0 也不透。
  de.style.setProperty('--xiao-sidebar-ovl-l1', rgba(lr, lg, lb, Math.min(so + 0.04, 1)));
  de.style.setProperty('--xiao-sidebar-ovl-l2', rgba(lr, lg, lb, Math.min(so + 0.08, 1)));
  de.style.setProperty('--xiao-sidebar-ovl-l3', rgba(lr, lg, lb, Math.min(so + 0.06, 1)));
  de.style.setProperty('--xiao-sidebar-ovl-dark-l1', rgba(dr, dg, db, Math.min(so + 0.04, 1)));
  de.style.setProperty('--xiao-sidebar-ovl-dark-l2', rgba(dr, dg, db, Math.min(so + 0.08, 1)));
  de.style.setProperty('--xiao-sidebar-ovl-dark-l3', rgba(dr, dg, db, Math.min(so + 0.06, 1)));
  // 面板内层专用的一组值（**不自我引用**）：面板外框吃 --xiao-sidebar-ovl（与左栏同值），内层这些 token
  // 供给卡片 / tab 条 / 文件树。**绝不能让它们去 var() 一个会被同时置空的变量** —— 曾经那么写过：
  // 面板内部全部算成透明、「侧栏不透明度」对右栏失灵（踩过两次），所以单独发一份，名字带 panel。
  // ⚠️ 取值 = **so 再减一档**（-0.06/-0.02/-0.04）：外框已经是 so，卡片若 ≥ so 就会叠成"比底更实"的白，
  //    看着像不吃滑杆；比底略透一点，才有「底一层色、卡片再亮一点」的层次，且仍随滑杆单调变化。
  de.style.setProperty('--xiao-panel-ovl-l1', rgba(lr, lg, lb, Math.max(so - 0.06, 0)));
  de.style.setProperty('--xiao-panel-ovl-l2', rgba(lr, lg, lb, Math.max(so - 0.02, 0)));
  de.style.setProperty('--xiao-panel-ovl-l3', rgba(lr, lg, lb, Math.max(so - 0.04, 0)));
  de.style.setProperty('--xiao-panel-ovl-dark-l1', rgba(dr, dg, db, Math.max(so - 0.06, 0)));
  de.style.setProperty('--xiao-panel-ovl-dark-l2', rgba(dr, dg, db, Math.max(so - 0.02, 0)));
  de.style.setProperty('--xiao-panel-ovl-dark-l3', rgba(dr, dg, db, Math.max(so - 0.04, 0)));
  // 设置页（DSH 设置对话框）独立不透明度：单独一套变量，只被 [data-shortcut-modal="settings"] 一族规则消费，
  // 与上面的面板 / 侧栏两族互不引用 —— 调它不会再连带改界面或侧栏，反之亦然。
  writeSettingsOpacityVars(de, surf, settingsOpacity(cfg));
  // JS 兜底：若 CSS 选择器未命中根框架，直接给它设 inline 半透明 + 模糊
  const frame = findFrameElement();
  if (frame) {
    const isDark = document.body.hasAttribute('data-ds-dark-theme');
    frame.style.backgroundColor = isDark ? rgba(dr, dg, db, ovl) : rgba(lr, lg, lb, ovl);
    frame.style.backgroundImage = 'none';
    frame.style.backdropFilter = 'blur(' + blur + 'px)';
    (frame.style as StyleWithWebkit).webkitBackdropFilter = 'blur(' + blur + 'px)';
  }
}

/**
 * 单张背景：按配置应用 / 更新 / 移除整页磨砂背景。
 * 背景图铺在 body 上（一定可见），根框架强制半透明并加 backdrop-filter 模糊，
 * 让 body 背景图透出并产生磨砂效果——不依赖 z-index、不依赖主题服务。
 * 这是**向后兼容快路径**：backgroundList 只有 ≤1 项时原样走这里，行为与旧版逐字一致。
 */
function syncBackgroundSingle(cfg: XiaoConfig): void {
  const de = document.documentElement;
  const on = cfg.enabled !== false && cfg.backgroundEnabled !== false;
  const isVideoBg = cfg.backgroundDynamic === true && isVideoPath(cfg.backgroundImagePath || '');
  const frame = findFrameElement();
  if (!on) {
    de.classList.remove('xiao-bg-on');
    de.classList.remove('xiao-bg-dynamic');
    de.classList.remove('xiao-bg-video');
    removeBgVideo();
    de.style.removeProperty('--xiao-bg-img');
    de.style.removeProperty('--xiao-bg-blur');
    de.style.removeProperty('--xiao-bg-ovl');
    de.style.removeProperty('--xiao-bg-ovl-dark');
    de.style.removeProperty('--xiao-sidebar-ovl');
    de.style.removeProperty('--xiao-sidebar-ovl-dark');
    de.style.removeProperty('--xiao-sidebar-ovl-l1');
    de.style.removeProperty('--xiao-sidebar-ovl-l2');
    de.style.removeProperty('--xiao-sidebar-ovl-l3');
    de.style.removeProperty('--xiao-sidebar-ovl-dark-l1');
    de.style.removeProperty('--xiao-sidebar-ovl-dark-l2');
    de.style.removeProperty('--xiao-sidebar-ovl-dark-l3');
    de.style.removeProperty('--xiao-panel-ovl-l1');
    de.style.removeProperty('--xiao-panel-ovl-l2');
    de.style.removeProperty('--xiao-panel-ovl-l3');
    de.style.removeProperty('--xiao-panel-ovl-dark-l1');
    de.style.removeProperty('--xiao-panel-ovl-dark-l2');
    de.style.removeProperty('--xiao-panel-ovl-dark-l3');
    de.style.removeProperty('--xiao-settings-ovl');
    de.style.removeProperty('--xiao-settings-ovl-l1');
    de.style.removeProperty('--xiao-settings-ovl-l3');
    de.style.removeProperty('--xiao-settings-ovl-overlay');
    de.style.removeProperty('--xiao-settings-ovl-dark');
    de.style.removeProperty('--xiao-settings-ovl-dark-l1');
    de.style.removeProperty('--xiao-settings-ovl-dark-l3');
    de.style.removeProperty('--xiao-settings-ovl-dark-overlay');
    de.style.removeProperty('--xiao-theme-color');
    de.style.removeProperty('--xiao-grad-a');
    de.style.removeProperty('--xiao-grad-b');
    if (frame) {
      frame.style.backgroundColor = '';
      frame.style.backgroundImage = '';
      frame.style.backdropFilter = '';
      (frame.style as StyleWithWebkit).webkitBackdropFilter = '';
    }
    return;
  }
  applyBackgroundChrome(cfg);
  // 动态背景：GIF 动图走 CSS background-image；视频走 <video> 元素（CSS 背景无法渲染视频）。
  de.classList.toggle('xiao-bg-dynamic', cfg.backgroundDynamic === true);
  de.classList.toggle('xiao-bg-video', isVideoBg);
  // 追加背景路径作为缓存指纹：背景图一变化 URL 就变，浏览器立即重新拉取，无需手动刷新页面。
  // 注意：视频背景不能作为 CSS background-image，改用 <video> 元素渲染（见上方 syncBgVideo），故不设该变量。
  if (isVideoBg) {
    de.style.removeProperty('--xiao-bg-img');
  } else {
    de.style.setProperty('--xiao-bg-img', 'url("/xiao-bg?p=' + encodeURIComponent(cfg.backgroundImagePath || '') + '&v=' + bgVersion + '")');
  }
  // 视频背景：创建/更新 <video> 元素（铺满 + 循环 + 声音开关）。
  syncBgVideo(cfg, isVideoBg);
  // 强制重绘：背景挂在 background-attachment:fixed 下时，仅改 CSS 变量在某些浏览器不会刷新背景图层
  //（表现为必须整页刷新才生效）。这里显式移除再重加 xiao-bg-on 并触发一次重排，迫使浏览器重新取回并绘制新背景。
  de.classList.remove('xiao-bg-on');
  void de.offsetHeight;
  de.classList.add('xiao-bg-on');
}
// —— 多背景轮播（backgroundList 长度 ≥ 2 时启用）——
// 设计要点：
//   * 与「单张快路径」互斥：≤1 项时不创建图层、不挂定时器，完全走 syncBackgroundSingle。
//   * 轮播状态放模块级，signature 只含「列表 + 间隔」；拖不透明度滑杆、切明暗主题都不会把轮播
//     重置回第一张（原实现每次配置变更都会整体重跑背景）。
//   * 视频切换时间 = max(间隔, 视频时长)：间隔 > 时长时循环播到点再切；间隔 ≤ 时长时播完即切。
//     动画 GIF 与静态图一律按「间隔」调度（GIF 没有可靠的播放结束事件）。
//   * 切换用固定时长交叉渐变：新旧两层 opacity 互换，渐变结束后释放旧层（含视频缓冲）。
//     因此任意时刻最多只有 2 个背景（当前 + 即将上场），而非整列表。

/** 交叉渐变固定时长（ms）：旧层淡出 / 新层淡入在此时长内完成。 */
const BG_FADE_MS = 700;
/** 背景图层类名（CSS 见 XIAO_CSS）。 */
const BG_LAYER_CLASS = 'xiao-bg-layer';

interface RotationState {
  /** 轮播指纹（列表 + 间隔）：变化才重建，否则只做软更新。 */
  signature: string;
  /** 当前可见层下标（0 / 1）。 */
  visible: number;
  layers: [HTMLElement, HTMLElement] | null;
  timer: number | null;
  /** 世代号：异步回调（加载完成 / ended / 定时器）仅在世代未变时生效，避免竞态重复推进。 */
  token: number;
}

const rotation: RotationState = { signature: '', visible: 0, layers: null, timer: null, token: 0 };

/**
 * 最近一次 `syncBackground()` 收到的配置。
 * 轮播的**延迟回调**（定时器 advance / canplay / ended）持有的是**启动当轮的旧闭包 cfg**：
 * 用户在轮播中途静音（或改音量）时，`syncBackgroundRotation` 会因指纹（列表 + 间隔）未变而只做
 * `applyRotationAudio` 软更新 —— 它只作用在**已存在**的 `<video>` 上；而下一项仍由旧 cfg 创建，
 * 于是新 `<video>` 按旧配置「要声音」，且此时已有用户激活（点过按钮）→ 直接带声播放，
 * 表现就是「静音后轮播到下一个视频又自己响了」（反向同理：开了声音却每个新项都静音）。
 * 所以**延迟回调一律经 `liveBgConfig()` 取配置**，不要直接用闭包里的 cfg。
 */
let liveBgCfg: XiaoConfig | null = null;

/** 记录最新配置（`syncBackground()` 每次同步都调）。导出供单测直接验证。 */
export function setLiveBgConfig(cfg: XiaoConfig): void {
  liveBgCfg = cfg;
}

/** 延迟回调取配置：优先最新一次同步进来的，尚未同步过才退回闭包里的旧值。导出供单测直接验证。 */
export function liveBgConfig(fallback: XiaoConfig): XiaoConfig {
  return liveBgCfg ?? fallback;
}

/** 取「有效多背景列表」：配置里的合法项；为空时由旧字段合成单张，保证长度恒 ≥ 1。 */
function effectiveBackgroundList(cfg: XiaoConfig): BackgroundEntry[] {
  const raw = Array.isArray(cfg.backgroundList) ? cfg.backgroundList : [];
  const list: BackgroundEntry[] = [];
  const seen = new Set<string>();
  for (const item of raw) {
    if (item === null || typeof item !== 'object') continue;
    const path = typeof item.path === 'string' ? item.path.trim() : '';
    if (path.length === 0 || seen.has(path)) continue;
    seen.add(path);
    list.push({ path, dynamic: item.dynamic === true });
  }
  if (list.length === 0) {
    list.push({
      path: cfg.backgroundImagePath || CLIENT_DEFAULT_CONFIG.backgroundImagePath,
      dynamic: cfg.backgroundDynamic === true,
    });
  }
  return list;
}

/**
 * 当前背景里是否存在视频项 —— 决定最外层那个「喇叭」快捷按钮要不要出现。
 * 与 syncBackground 的判定保持同源：≥2 项走轮播（列表里任意一项是视频就显示，静态 / GIF 项本身没有声音），
 * 否则走单张快路径（以 backgroundImagePath / backgroundDynamic 为准，和 syncBackgroundSingle 一致）。
 * 关掉总开关或背景开关时一律不显示（那时根本没有背景在放）。
 */
export function backgroundHasVideo(cfg: XiaoConfig): boolean {
  if (cfg.enabled === false || cfg.backgroundEnabled === false) return false;
  const list = effectiveBackgroundList(cfg);
  if (list.length >= 2) return list.some((entry) => entry.dynamic === true && isVideoPath(entry.path));
  return cfg.backgroundDynamic === true && isVideoPath(cfg.backgroundImagePath || '');
}

/** 清空一层：暂停并释放可能存在的 <video>，清掉背景图（不删元素本身）。 */
function clearLayer(el: HTMLElement): void {
  const video = el.querySelector('video');
  if (video) {
    try {
      video.pause();
    } catch {
      /* 忽略：暂停失败不影响后续移除 */
    }
    clearBgVideoGesture(video);
    video.removeAttribute('src');
    try {
      video.load();
    } catch {
      /* 忽略：释放缓冲失败不影响后续移除 */
    }
    video.remove();
  }
  el.style.backgroundImage = '';
}

/** 创建 / 复用两个固定定位的背景层（挂在 body 下、#root 之前方，故框架磨砂仍能采样到）。 */
function ensureRotationLayers(): [HTMLElement, HTMLElement] {
  const existing = rotation.layers;
  if (existing !== null && existing[0].isConnected && existing[1].isConnected) return existing;
  if (existing !== null) {
    for (const el of existing) if (el.parentNode) el.parentNode.removeChild(el);
  }
  const make = (slot: number): HTMLElement => {
    const el = document.createElement('div');
    el.className = BG_LAYER_CLASS;
    el.dataset.plugin = 'xiao-theme-ts';
    el.dataset.slot = String(slot);
    el.style.opacity = '0';
    document.body.appendChild(el);
    return el;
  };
  const layers: [HTMLElement, HTMLElement] = [make(0), make(1)];
  rotation.layers = layers;
  return layers;
}

/**
 * 声音开关软更新：不重启轮播，只让现有 <video> 对齐「静音 / 播放」状态。
 * 走 playBgVideo 而不是直接写 muted：无用户激活时直接置 muted=false 会把正在播放的
 * 视频停住（Chromium 自动播放策略），而轮播在列表/间隔未变时不会重建元素，画面就此卡住；
 * playBgVideo 会保持静音并登记「首次交互后恢复声音」，同时把被停住的视频重新拉起。
 */
function applyRotationAudio(cfg: XiaoConfig): void {
  if (rotation.layers === null) return;
  const wantMuted = cfg.backgroundVideoAudio !== true;
  const volume = bgVolume(cfg);
  for (const el of rotation.layers) {
    const video = el.querySelector('video');
    if (video instanceof HTMLVideoElement) playBgVideo(video, wantMuted, volume);
  }
}

/** 对当前所有在放的背景 <video>（单张快路径 + 轮播两层）各执行一次操作。 */
function forEachBgVideo(fn: (video: HTMLVideoElement) => void): void {
  const single = document.getElementById('xiao-theme-video');
  if (single instanceof HTMLVideoElement) fn(single);
  if (rotation.layers !== null) {
    for (const el of rotation.layers) {
      const video = el.querySelector('video');
      if (video instanceof HTMLVideoElement) fn(video);
    }
  }
}

/**
 * 音量滑杆拖动中的即时预览：直接写 <video>.volume，不等配置写回，拖到哪儿听到哪儿。
 * 只在用户拖滑杆时调用（此时必有用户激活），故可按音量顺带解除静音；音量归零则置 muted。
 * 正式提交仍走 saveConfig（见设置页 / 徽章），本函数不碰配置。
 */
function previewBgVolume(volume: number): void {
  const vol = clamp01(volume);
  forEachBgVideo((video) => {
    video.volume = vol;
    if (vol <= 0) video.muted = true;
    else if (video.muted && hasUserActivation()) video.muted = false;
  });
}

/**
 * 设置页不透明度滑杆拖动中的即时预览：直接重写 --xiao-settings-ovl 一族变量，不等配置写回。
 * 用最近一次同步进来的配置（liveBgConfig）算浅深 RGB，因此跟随当前主题主色；本函数不碰配置。
 * 只在背景开启时有效（CSS 规则都挂在 html.xiao-bg-on 下）。
 */
function previewSettingsOpacity(store: ConfigStore, value: number): void {
  const cfg = liveBgConfig(store.getSnapshot());
  const themeColor = typeof cfg.themeColor === 'string' && cfg.themeColor.length > 0 ? cfg.themeColor : DEFAULT_THEME_COLOR;
  writeSettingsOpacityVars(document.documentElement, deriveSurfaces(themeColor), clamp01(value));
}

/** 停止轮播并移除全部图层（离开轮播模式 / 卸载 / 总开关关闭时调用）。 */
function stopRotation(): void {
  rotation.token += 1;
  if (rotation.timer !== null) {
    window.clearTimeout(rotation.timer);
    rotation.timer = null;
  }
  if (rotation.layers !== null) {
    for (const el of rotation.layers) {
      clearLayer(el);
      if (el.parentNode) el.parentNode.removeChild(el);
    }
  }
  rotation.layers = null;
  rotation.signature = '';
  rotation.visible = 0;
  document.documentElement.classList.remove('xiao-bg-layers');
}

/**
 * 视频项的切换策略（纯函数，供单测直接验证核心规则：切换时间 = max(间隔, 视频时长)）。
 * - 间隔 ≤ 时长：必须播完才切 —— loop=false，等 `ended`；
 * - 间隔 > 时长（或时长未知）：循环播到点再切 —— loop=true，定时器。
 */
function videoPlaythroughPlan(
  intervalMs: number,
  durationMs: number | null,
): { loop: boolean; waitForEnded: boolean; switchAfterMs: number } {
  if (durationMs !== null && Number.isFinite(durationMs) && intervalMs <= durationMs) {
    return { loop: false, waitForEnded: true, switchAfterMs: durationMs };
  }
  return { loop: true, waitForEnded: false, switchAfterMs: intervalMs };
}

/**
 * 把一项背景渲染进某一层；就绪后回调（携带视频时长 ms；静态图 / GIF 或读取失败为 null）。
 * 静态图 / 动画 GIF 走 CSS background-image + Image 预加载；视频走 <video>。
 */
function prepareLayer(
  cfg: XiaoConfig,
  el: HTMLElement,
  entry: BackgroundEntry,
  entryIndex: number,
  intervalMs: number,
  onReady: (durationMs: number | null) => void,
): void {
  clearLayer(el);
  // p= 是缓存指纹；i= 让 Host 在列表里取对应项。两者都带，Host 优先按 p 精确匹配（见 /xiao-bg 路由）。
  const url = '/xiao-bg?i=' + entryIndex + '&p=' + encodeURIComponent(entry.path) + '&v=' + bgVersion;
  if (entry.dynamic === true && isVideoPath(entry.path)) {
    const video = document.createElement('video');
    video.loop = true;
    video.autoplay = true;
    video.playsInline = true;
    video.setAttribute('playsinline', '');
    video.src = url;
    el.appendChild(video);
    let settled = false;
    const done = (durationMs: number | null): void => {
      if (settled) return;
      settled = true;
      onReady(durationMs);
    };
    const readDuration = (): number | null =>
      Number.isFinite(video.duration) && video.duration > 0 ? video.duration * 1000 : null;
    video.addEventListener('loadedmetadata', () => {
      // 元数据阶段先按同一规则定好 loop，避免短片段在还没轮到切换时就自己循环。
      video.loop = videoPlaythroughPlan(intervalMs, readDuration()).loop;
    });
    video.addEventListener('canplay', () => done(readDuration()));
    video.addEventListener('error', () => done(null));
    // 自动播放策略统一交给 playBgVideo：无用户激活时先静音播（轮播照常推进），
    // 有声被拦时降级静音，并在首次交互后恢复声音。绝不在这里直接写 muted=false。
    // ⚠️ 声音状态取**最新**配置：这一项是轮播中途延迟创建的，闭包 cfg 可能是「静音之前」的
    //    （否则静音后切到下一个视频又自己响了，见 liveBgCfg 的注释）。
    const live = liveBgConfig(cfg);
    playBgVideo(video, live.backgroundVideoAudio !== true, bgVolume(live));
    return;
  }
  const probe = new Image();
  probe.onload = () => onReady(null);
  probe.onerror = () => onReady(null);
  probe.src = url;
  el.style.backgroundImage = 'url("' + url + '")';
}

/**
 * 为「刚成为可见」的这一项安排下一次切换。
 * 视频：间隔 ≤ 时长 → loop=false + ended（播完即切，另加安全网）；间隔 > 时长 → 循环播到点。
 * 静态 / GIF / 时长未知：到点即切。
 */
function scheduleRotation(
  cfg: XiaoConfig,
  list: BackgroundEntry[],
  index: number,
  token: number,
  intervalMs: number,
  durationMs: number | null,
): void {
  if (token !== rotation.token) return;
  if (rotation.timer !== null) {
    window.clearTimeout(rotation.timer);
    rotation.timer = null;
  }
  const entry = list[index]!;
  const isVideo = entry.dynamic === true && isVideoPath(entry.path);
  let fired = false;
  const advance = (): void => {
    if (fired || token !== rotation.token) return;
    fired = true;
    if (rotation.timer !== null) {
      window.clearTimeout(rotation.timer);
      rotation.timer = null;
    }
    // 延迟回调里也重新取最新配置：`showRotationEntry` 会用它的声音 / 音量设置创建下一项。
    showRotationEntry(liveBgConfig(cfg), list, (index + 1) % list.length, token, false);
  };
  if (isVideo) {
    const plan = videoPlaythroughPlan(intervalMs, durationMs);
    if (plan.waitForEnded && durationMs !== null) {
      const current = rotation.layers === null ? null : (rotation.layers[rotation.visible] ?? null);
      const video = current === null ? null : current.querySelector('video');
      if (video instanceof HTMLVideoElement) {
        video.addEventListener('ended', advance, { once: true });
        // 安全网：个别容器 / 解码异常下 ended 可能不触发，按「时长 + 渐变 + 余量」兜底。
        rotation.timer = window.setTimeout(advance, plan.switchAfterMs + BG_FADE_MS + 1500);
        return;
      }
    }
    rotation.timer = window.setTimeout(advance, plan.switchAfterMs);
    return;
  }
  rotation.timer = window.setTimeout(advance, intervalMs);
}

/** 切换 / 首显某一项：先把新项渲染进「不可见层」，就绪后再交叉渐变并安排下一次。 */
function showRotationEntry(
  cfg: XiaoConfig,
  list: BackgroundEntry[],
  index: number,
  token: number,
  immediate: boolean,
): void {
  if (token !== rotation.token || rotation.layers === null) return;
  // 进入这一项时立刻取最新配置：本条可能是轮播中途（用户已改过静音 / 音量）才轮到的，
  // 用闭包 cfg 会把「静音」丢掉 —— 这正是「静音后又自己响」的根因。
  cfg = liveBgConfig(cfg);
  const layers = rotation.layers;
  const entry = list[index]!;
  const incoming = layers[rotation.visible ^ 1]!;
  const outgoing = layers[rotation.visible]!;
  const intervalSec = clampNum(
    typeof cfg.backgroundInterval === 'number' ? cfg.backgroundInterval : 30,
    CLIENT_RANGES.backgroundInterval.min,
    CLIENT_RANGES.backgroundInterval.max,
    30,
  );
  const intervalMs = intervalSec * 1000;
  let handedOver = false;
  const handOver = (durationMs: number | null): void => {
    if (token !== rotation.token || handedOver) return;
    handedOver = true;
    incoming.style.transition = immediate ? 'none' : '';
    incoming.style.opacity = '1';
    outgoing.style.opacity = '0';
    if (immediate) {
      void incoming.offsetHeight; // 强制重排：让「无过渡」的这一帧立即生效，避免闪白
      incoming.style.transition = '';
    }
    rotation.visible = rotation.visible ^ 1;
    // 渐变结束后释放旧层（含其视频缓冲），保证任意时刻最多 2 个背景资源。
    const oldLayer = outgoing;
    window.setTimeout(
      () => {
        if (token !== rotation.token) return;
        clearLayer(oldLayer);
      },
      immediate ? 0 : BG_FADE_MS + 80,
    );
    scheduleRotation(cfg, list, index, token, intervalMs, durationMs);
  };
  prepareLayer(cfg, incoming, entry, index, intervalMs, handOver);
}

/** 该层当前是否已有内容（有背景图或 <video>）。用于区分「首次铺层」与「已在轮播中」。 */
function layerHasContent(el: HTMLElement): boolean {
  return el.style.backgroundImage !== '' || el.querySelector('video') !== null;
}

/**
 * 启动 / 重启一轮轮播。
 * - 首次铺层（两层皆空）：第 0 项「无渐变」直接上屏，避免闪白；
 * - 已在进行中（列表 / 间隔变更导致重启）：保留当前可见层，把新的第 0 项淡入 —— 不闪、不空窗。
 */
function startRotation(cfg: XiaoConfig, list: BackgroundEntry[]): void {
  rotation.token += 1;
  const token = rotation.token;
  if (rotation.timer !== null) {
    window.clearTimeout(rotation.timer);
    rotation.timer = null;
  }
  const layers = ensureRotationLayers();
  const fresh = !layerHasContent(layers[0]) && !layerHasContent(layers[1]);
  if (!fresh) {
    // 已有可见背景：直接淡入新的第 0 项（showRotationEntry 会翻转到另一层）。
    showRotationEntry(cfg, list, 0, token, false);
    return;
  }
  layers[0].style.transition = 'none';
  layers[1].style.transition = 'none';
  layers[0].style.opacity = '0';
  layers[1].style.opacity = '0';
  rotation.visible = 0;
  showRotationEntry(cfg, list, 0, token, true);
}

/** 轮播模式：应用公共视觉层 + 图层渲染；配置只软变化（非列表/间隔）时不重启。 */
function syncBackgroundRotation(cfg: XiaoConfig, list: BackgroundEntry[]): void {
  const de = document.documentElement;
  applyBackgroundChrome(cfg);
  de.classList.add('xiao-bg-layers');
  de.classList.remove('xiao-bg-dynamic');
  de.classList.remove('xiao-bg-video');
  // 关掉 body 背景图（视觉交给图层）；`none` 与身后的渐变组合仍合法，只是被不透明图层盖住。
  de.style.setProperty('--xiao-bg-img', 'none');
  removeBgVideo();
  const signature = JSON.stringify({ list, interval: cfg.backgroundInterval });
  if (rotation.layers !== null && signature === rotation.signature) {
    applyRotationAudio(cfg);
    return;
  }
  rotation.signature = signature;
  startRotation(cfg, list);
}

/**
 * 磨砂背景总入口：≥2 项走轮播，否则走单张快路径。
 * 两者互斥；从轮播切回单张时先彻底移除图层，避免残留。
 */
function syncBackground(cfg: XiaoConfig): void {
  // 先记录最新配置：任何延迟回调（轮播定时器 / canplay / ended）都经 liveBgConfig() 读它，
  // 否则轮播中途静音 / 改音量会被旧闭包 cfg 覆盖（见 liveBgCfg 的注释）。
  setLiveBgConfig(cfg);
  const de = document.documentElement;
  const on = cfg.enabled !== false && cfg.backgroundEnabled !== false;
  const list = effectiveBackgroundList(cfg);
  if (on && list.length >= 2) {
    syncBackgroundRotation(cfg, list);
    return;
  }
  if (rotation.layers !== null) stopRotation();
  de.classList.remove('xiao-bg-layers');
  syncBackgroundSingle(cfg);
}

function clamp01(value: number): number {
  return Math.min(1, Math.max(0, value));
}

function clampNum(value: number, min: number, max: number, fallback: number): number {
  return typeof value === 'number' && Number.isFinite(value) ? Math.min(max, Math.max(min, value)) : fallback;
}

function rgba(r: number, g: number, b: number, a: number): string {
  return 'rgba(' + r + ',' + g + ',' + b + ',' + a.toFixed(3) + ')';
}

/** 解析 `#rgb` / `#rrggbb` 为 [r,g,b]。非法输入返回 null。 */
function parseHex(hex: string): [number, number, number] | null {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex) || /^#?([0-9a-f]{3})$/i.exec(hex);
  if (!m) return null;
  let h = m[1]!;
  if (h.length === 3) h = h[0]! + h[0]! + h[1]! + h[1]! + h[2]! + h[2]!;
  const n = parseInt(h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function toHex(r: number, g: number, b: number): string {
  const c = (v: number): string => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0');
  return '#' + c(r) + c(g) + c(b);
}

/** rgb -> [h(0-360), s(0-100), l(0-100)]。 */
function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const l = (max + min) / 2;
  let h = 0;
  let s = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    if (max === rn) h = (gn - bn) / d + (gn < bn ? 6 : 0);
    else if (max === gn) h = (bn - rn) / d + 2;
    else h = (rn - gn) / d + 4;
    h /= 6;
  }
  return [h * 360, s * 100, l * 100];
}

function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  const hn = ((h % 360) + 360) % 360 / 360;
  const sn = Math.max(0, Math.min(1, s / 100));
  const ln = Math.max(0, Math.min(1, l / 100));
  if (sn === 0) {
    const v = Math.round(ln * 255);
    return [v, v, v];
  }
  const hue2rgb = (p: number, q: number, t: number): number => {
    let tn = t;
    if (tn < 0) tn += 1;
    if (tn > 1) tn -= 1;
    if (tn < 1 / 6) return p + (q - p) * 6 * tn;
    if (tn < 1 / 2) return q;
    if (tn < 2 / 3) return p + (q - p) * (2 / 3 - tn) * 6;
    return p;
  };
  const q = ln < 0.5 ? ln * (1 + sn) : ln + sn - ln * sn;
  const p = 2 * ln - q;
  return [
    Math.round(hue2rgb(p, q, hn + 1 / 3) * 255),
    Math.round(hue2rgb(p, q, hn) * 255),
    Math.round(hue2rgb(p, q, hn - 1 / 3) * 255),
  ];
}

/** 调亮/调暗一个色（delta 为 0-100 的明度偏移）。 */
function shiftLight(hex: string, delta: number): string {
  const rgb = parseHex(hex);
  if (!rgb) return hex;
  const [h, s, l] = rgbToHsl(rgb[0], rgb[1], rgb[2]);
  return toHex(...hslToRgb(h, s, Math.max(0, Math.min(100, l + delta))));
}

/** 调整饱和度（sDelta 为 0-100 偏移）。 */
function shiftSat(hex: string, sDelta: number): string {
  const rgb = parseHex(hex);
  if (!rgb) return hex;
  const [h, s, l] = rgbToHsl(rgb[0], rgb[1], rgb[2]);
  return toHex(...hslToRgb(h, Math.max(0, Math.min(100, s + sDelta)), l));
}

/** 同一主色下，浅色/深色主题各自的 RGB 底（面板、侧栏半透明层用）。 */
function deriveSurfaces(hex: string): { light: [number, number, number]; dark: [number, number, number] } {
  const base = parseHex(hex) || parseHex('#2E8B72')!;
  // 浅色：高亮低饱和的青玉底；深色：极暗的青玉底。
  const [h, s, l] = rgbToHsl(base[0], base[1], base[2]);
  const light = hslToRgb(h, Math.max(12, s * 0.22), 95);
  const dark = hslToRgb(h, Math.min(48, s * 0.55), 8);
  return { light, dark };
}

/** 一个可拖拽的指针位置状态。 */
interface DragState {
  startX: number;
  startY: number;
  originLeft: number;
  originTop: number;
  moved: boolean;
}

/** 徽章位置 / 收起状态的本地持久化键（localStorage；仅本机，与插件配置文件无关）。 */
const MASCOT_POS_KEY = 'xiao-theme:mascot-position';
const MASCOT_HIDDEN_KEY = 'xiao-theme:mascot-hidden';

/** 读取本地保存的徽章位置 / 收起状态；不可用或损坏返回 null（回落到 CSS 默认位置）。 */
function readMascotStored(): { x: number; y: number; hidden: boolean } | null {
  try {
    const raw = window.localStorage.getItem(MASCOT_POS_KEY);
    if (raw === null) return null;
    const parsed = JSON.parse(raw) as { x?: unknown; y?: unknown };
    if (typeof parsed.x !== 'number' || typeof parsed.y !== 'number') return null;
    if (!Number.isFinite(parsed.x) || !Number.isFinite(parsed.y)) return null;
    return { x: parsed.x, y: parsed.y, hidden: window.localStorage.getItem(MASCOT_HIDDEN_KEY) === '1' };
  } catch {
    return null;
  }
}

/** 写入徽章位置 / 收起状态；localStorage 不可用（隐私模式等）时静默忽略，不影响功能。 */
function writeMascotStored(pos: { x: number; y: number } | null, hidden: boolean): void {
  try {
    if (pos === null) window.localStorage.removeItem(MASCOT_POS_KEY);
    else window.localStorage.setItem(MASCOT_POS_KEY, JSON.stringify({ x: Math.round(pos.x), y: Math.round(pos.y) }));
    window.localStorage.setItem(MASCOT_HIDDEN_KEY, hidden ? '1' : '0');
  } catch {
    /* 静默忽略 */
  }
}

/** 吉祥物徽章组件：青玉底金边 + 头像 + 可配置的标题/副标（位置与收起状态本地持久化）。 */
/** 徽章里的喇叭按钮（只有视频背景时才由调用方传进来；label 已按当前语言取好）。 */
interface BadgeSound {
  audible: boolean;
  label: string;
  onToggle: () => void;
  /** 当前音量（0–1）：音量滑杆的显示值，与设置页同一个字段。 */
  volume: number;
  /** 拖动中的即时预览：只改 <video>.volume，不写配置。 */
  onVolumePreview: (v: number) => void;
  /** 提交音量：写配置；>0 时顺带取消静音（拖到有声位置就该听得到）。 */
  onVolumeCommit: (v: number) => void;
}

/**
 * 吉祥物徽章里的音量滑杆（只有视频背景时由调用方渲染）。
 * 拖动时本地预览 + 直接写 <video>.volume（拖到哪儿听到哪儿），松开 / 失焦 / 回车才提交配置，
 * 与设置页 RangeRow 同一套提交语义，避免每动一格就发一次请求。
 */
function BadgeVolume({
  volume,
  label,
  onPreview,
  onCommit,
}: {
  volume: number;
  label: string;
  onPreview: (v: number) => void;
  onCommit: (v: number) => void;
}): React.ReactElement {
  const [val, setVal] = React.useState<number>(volume);
  React.useEffect(() => setVal(volume), [volume]);
  const stop = (e: React.SyntheticEvent): void => e.stopPropagation();
  return React.createElement('input', {
    className: 'xiao-volume',
    type: 'range',
    min: 0,
    max: 1,
    step: 0.01,
    value: val,
    'aria-label': label,
    title: label + ' ' + Math.round(val * 100) + '%',
    // 徽章整体可拖拽：滑杆必须吃掉 pointer 事件，否则一按就开始拖徽章。
    onPointerDown: stop,
    onClick: stop,
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
      const v = Number(e.target.value);
      setVal(v);
      onPreview(v);
    },
    onPointerUp: () => onCommit(val),
    onKeyUp: () => onCommit(val),
    onBlur: () => onCommit(val),
  });
}

function XiaoBadge({
  avatarPath,
  title,
  subtitle,
  sound,
}: {
  avatarPath: string;
  title: string;
  subtitle: string;
  /** 视频背景的快捷静音按钮；静态 / GIF 背景传 null（不占位）。 */
  sound: BadgeSound | null;
}): React.ReactElement {
  const rootRef = React.useRef<HTMLDivElement>(null);
  const [pos, setPos] = React.useState<{ x: number; y: number } | null>(() => {
    const stored = readMascotStored();
    return stored ? { x: stored.x, y: stored.y } : null;
  });
  const [drag, setDrag] = React.useState<DragState | null>(null);
  const [hidden, setHidden] = React.useState<boolean>(() => readMascotStored()?.hidden === true);

  /** 把坐标钳制在视口内，避免徽章被拖出屏幕（元素尺寸未知时用保守兜底）。 */
  const clampPos = (x: number, y: number): { x: number; y: number } => {
    const el = rootRef.current;
    const w = el && el.offsetWidth > 0 ? el.offsetWidth : 72;
    const h = el && el.offsetHeight > 0 ? el.offsetHeight : 72;
    return {
      x: Math.min(Math.max(0, x), Math.max(0, window.innerWidth - w)),
      y: Math.min(Math.max(0, y), Math.max(0, window.innerHeight - h)),
    };
  };

  // 挂载后用真实尺寸校正一次持久化坐标（窗口变小 / 换屏幕时不会落在视口外）。
  React.useEffect(() => {
    setPos((p) => (p === null ? p : clampPos(p.x, p.y)));
  }, []);
  // 视口尺寸变化时重新钳制。
  React.useEffect(() => {
    const onResize = (): void => setPos((p) => (p === null ? p : clampPos(p.x, p.y)));
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  // 位置 / 收起状态变化时持久化（失败静默）。
  React.useEffect(() => {
    writeMascotStored(pos, hidden);
  }, [pos, hidden]);

  const startDrag = (e: React.PointerEvent<HTMLDivElement>): void => {
    if (e.button !== 0) return;
    const rect = e.currentTarget.getBoundingClientRect();
    setDrag({
      startX: e.clientX,
      startY: e.clientY,
      originLeft: pos ? pos.x : rect.left,
      originTop: pos ? pos.y : rect.top,
      moved: false,
    });
    const el = e.currentTarget as HTMLElement;
    if (typeof el.setPointerCapture === 'function') {
      try {
        el.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    }
  };
  const onMove = (e: React.PointerEvent<HTMLDivElement>): void => {
    if (!drag) return;
    const dx = e.clientX - drag.startX;
    const dy = e.clientY - drag.startY;
    const moved = drag.moved || Math.abs(dx) + Math.abs(dy) > 4;
    if (moved) {
      setDrag({ ...drag, moved });
      setPos(clampPos(drag.originLeft + dx, drag.originTop + dy));
    }
  };
  const endDrag = (): void => setDrag(null);

  const tabDown = (e: React.PointerEvent<HTMLButtonElement>): void => {
    if (e.button !== 0) return;
    const rect = e.currentTarget.getBoundingClientRect();
    setDrag({
      startX: e.clientX,
      startY: e.clientY,
      originLeft: pos ? pos.x : rect.left,
      originTop: pos ? pos.y : rect.top,
      moved: false,
    });
    const el = e.currentTarget as HTMLElement;
    if (typeof el.setPointerCapture === 'function') {
      try {
        el.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    }
  };
  const tabMove = (e: React.PointerEvent<HTMLButtonElement>): void => {
    if (!drag) return;
    const dx = e.clientX - drag.startX;
    const dy = e.clientY - drag.startY;
    const moved = drag.moved || Math.abs(dx) + Math.abs(dy) > 4;
    if (moved) {
      setDrag({ ...drag, moved });
      setPos(clampPos(drag.originLeft + dx, drag.originTop + dy));
    }
  };
  const tabUp = (): void => {
    if (drag && !drag.moved) setHidden(false);
    setDrag(null);
  };
  const tabCancel = (): void => setDrag(null);

  const styleFor: React.CSSProperties | undefined = pos
    ? { left: pos.x, top: pos.y, right: 'auto', bottom: 'auto' }
    : undefined;

  if (hidden) {
    return React.createElement(
      'div',
      {
        className: 'xiao-mascot',
        style: styleFor,
        ref: rootRef,
        title: t('mascotDragOpen'),
      },
      React.createElement(
        'button',
        {
          className: 'xiao-tab',
          'aria-label': t('mascotShow'),
          onPointerDown: tabDown,
          onPointerMove: tabMove,
          onPointerUp: tabUp,
          onPointerCancel: tabCancel,
        },
        '\u{1F4A8}',
      ),
    );
  }

  return React.createElement(
    'div',
    {
      className: 'xiao-mascot',
      style: styleFor,
      ref: rootRef,
      title: t('mascotDragClose'),
      onPointerDown: startDrag,
      onPointerMove: onMove,
      onPointerUp: endDrag,
      onPointerCancel: endDrag,
    },
    React.createElement(
      'div',
      { className: 'xiao-badge' },
      React.createElement('img', {
        className: 'xiao-avatar',
        src: '/xiao-avatar.png?p=' + encodeURIComponent(avatarPath || '') + '&v=' + avatarVersion,
        alt: '魈',
        draggable: 'false',
      }),
      React.createElement(
        'div',
        null,
        React.createElement('div', { className: 'xiao-title' }, title),
        React.createElement('div', { className: 'xiao-sub' }, subtitle),
      ),
      sound
        ? React.createElement(BadgeVolume, {
            volume: sound.volume,
            label: t('videoVolume'),
            onPreview: sound.onVolumePreview,
            onCommit: sound.onVolumeCommit,
          })
        : null,
      sound
        ? React.createElement(
            'button',
            {
              type: 'button',
              className: 'xiao-close xiao-sound' + (sound.audible ? '' : ' xiao-sound-off'),
              'aria-pressed': sound.audible,
              'aria-label': sound.label,
              title: sound.label,
              // 徽章整体是可拖拽的：按钮必须吃掉 pointerdown，否则点一下就开始拖
              onPointerDown: (e: React.PointerEvent<HTMLButtonElement>) => e.stopPropagation(),
              onClick: (e: React.MouseEvent<HTMLButtonElement>) => {
                e.stopPropagation();
                sound.onToggle();
              },
            },
            sound.audible ? '\u{1F50A}' : '\u{1F507}',
          )
        : null,
      React.createElement(
        'button',
        {
          className: 'xiao-close',
          'aria-label': t('mascotClose'),
          title: t('mascotCloseTip'),
          onPointerDown: (e: React.PointerEvent<HTMLButtonElement>) => e.stopPropagation(),
          onClick: () => setHidden(true),
        },
        '\u00d7',
      ),
    ),
    React.createElement('div', { className: 'xiao-wind', 'aria-hidden': 'true' }, '\u{1F4A8} \u{1F4A8} \u{1F4A8}'),
  );
}

/**
 * 悬浮窗组件：订阅配置，enabled=false 时隐藏。
 * 背景是视频时，把喇叭按钮与音量滑杆**放进吉祥物徽章里**（不额外占屏幕位置）；静态图 / GIF 传 null。
 * 两者写的都是设置页同一组字段（backgroundVideoAudio / backgroundVideoVolume），两边永远同步。
 */
function XiaoOverlay({ store }: { store: ConfigStore }): React.ReactElement | null {
  const [snapshot, setSnapshot] = React.useState<XiaoConfig>(() => store.getSnapshot());
  React.useEffect(() => store.subscribe(() => setSnapshot(store.getSnapshot())), [store]);
  if (snapshot.enabled === false) return null;
  const audible = snapshot.backgroundVideoAudio === true;
  const volume = bgVolume(snapshot);
  return React.createElement(XiaoBadge, {
    avatarPath: snapshot.avatarPath || CLIENT_DEFAULT_CONFIG.avatarPath,
    title: mascotText(snapshot.mascotTitle, 'title'),
    subtitle: mascotText(snapshot.mascotSubtitle, 'subtitle'),
    sound: backgroundHasVideo(snapshot)
      ? {
          audible,
          label: t(audible ? 'soundMute' : 'soundUnmute'),
          onToggle: () => void saveConfig(store, { backgroundVideoAudio: !audible }),
          volume,
          onVolumePreview: previewBgVolume,
          onVolumeCommit: (v: number) => {
            const patch: Partial<XiaoConfig> = { backgroundVideoVolume: v };
            // 拖到有声位置却还静音着，等于「拖了没反应」：同一次保存里顺手取消静音。
            if (v > 0 && !audible) patch.backgroundVideoAudio = true;
            void saveConfig(store, patch);
          },
        }
      : null,
  });
}

/** 滑块行：拖动过程本地预览，松开 / 失焦 / 键盘确认时提交。 */
function RangeRow({
  label,
  value,
  min,
  max,
  step,
  format,
  onPreview,
  onCommit,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  format?: (v: number) => string;
  /** 可选：拖动中的即时预览（如视频音量直接写入 <video>），不写配置。 */
  onPreview?: (v: number) => void;
  onCommit: (v: number) => void;
}): React.ReactElement {
  const [val, setVal] = React.useState<number>(value);
  React.useEffect(() => setVal(value), [value]);
  const commit = (): void => onCommit(val);
  return React.createElement(
    'div',
    { className: 'xiao-settings-row' },
    React.createElement('label', { className: 'xiao-settings-label' }, label),
    React.createElement('input', {
      className: 'xiao-settings-range',
      type: 'range',
      min,
      max,
      step,
      value: val,
      onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
        const next = Number(e.target.value);
        setVal(next);
        if (onPreview) onPreview(next);
      },
      onPointerUp: commit,
      onKeyUp: commit,
      onBlur: commit,
    }),
    React.createElement('span', { className: 'xiao-settings-value' }, format ? format(val) : String(val)),
  );
}

/** 主题管理设置块：列出 / 新建 / 切换 / 重命名 / 删除 / 导入 / 导出（默认「魈」内置主题不可删除）。 */
function ThemeManager({ store }: { store: ConfigStore }): React.ReactElement {
  const [themes, setThemes] = React.useState<ThemeSummary[] | null>(null);
  const [activeId, setActiveId] = React.useState<string>('');
  const [newName, setNewName] = React.useState<string>('');
  const [editingId, setEditingId] = React.useState<string | null>(null);
  const [editingName, setEditingName] = React.useState<string>('');
  const [pendingDeleteId, setPendingDeleteId] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState<boolean>(false);
  const [error, setError] = React.useState<string | null>(null);
  const [pendingRestore, setPendingRestore] = React.useState<boolean>(false);
  const importRef = React.useRef<HTMLInputElement | null>(null);

  const refresh = React.useCallback(async (): Promise<void> => {
    try {
      const res = await listThemes();
      setThemes(res.themes);
      setActiveId(res.activeThemeId);
      // 同步给设置页左侧分区标题：主题切换 / 重命名 / 删除后标题立刻变成新主题名。
      const active = res.themes.find((item) => item.id === res.activeThemeId);
      setActiveThemeName(active ? active.name : '');
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }, []);

  React.useEffect(() => {
    void refresh();
  }, [refresh]);

  const fail = (e: unknown): void => setError(e instanceof Error ? e.message : String(e));

  const onActivate = async (id: string): Promise<void> => {
    if (busy || !id) return;
    setBusy(true);
    setError(null);
    try {
      const res = await activateTheme(id);
      store.set(res.config); // 触发主题/背景重同步；提示词由 Host 端 syncVoice 重刷
      setActiveId(res.activeThemeId);
      await refresh();
    } catch (e) {
      fail(e);
    }
    setBusy(false);
  };

  const onCreate = async (): Promise<void> => {
    if (busy) return;
    const name = newName.trim();
    if (!name) {
      setError(t('needThemeName'));
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await createTheme(name);
      setNewName('');
      await refresh();
    } catch (e) {
      fail(e);
    }
    setBusy(false);
  };

  const onRename = async (id: string, name: string): Promise<void> => {
    const trimmed = name.trim();
    setEditingId(null);
    setEditingName('');
    if (busy || !trimmed) return;
    setBusy(true);
    setError(null);
    try {
      await renameTheme(id, trimmed);
      await refresh();
    } catch (e) {
      fail(e);
    }
    setBusy(false);
  };

  const onDelete = async (id: string): Promise<void> => {
    if (busy) return;
    if (pendingDeleteId !== id) {
      setPendingDeleteId(id);
      return;
    }
    setBusy(true);
    setError(null);
    const wasActive = activeId === id;
    try {
      const res = await deleteTheme(id);
      setPendingDeleteId(null);
      if (wasActive) {
        await loadConfig(store); // 删除的是当前主题 → 回落默认并重拉配置
        setActiveId(res.activeThemeId);
      }
      await refresh();
    } catch (e) {
      fail(e);
      setPendingDeleteId(null);
    }
    setBusy(false);
  };

  const onExport = async (id: string): Promise<void> => {
    setError(null);
    try {
      downloadTheme(await exportTheme(id));
    } catch (e) {
      fail(e);
    }
  };

  const onImportFile = async (e: React.ChangeEvent<HTMLInputElement>): Promise<void> => {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!file) return;
    setError(null);
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as { name?: unknown; config?: unknown; version?: unknown };
      if (parsed === null || typeof parsed !== 'object') throw new Error(t('invalidImportFile'));
      const name =
        typeof parsed.name === 'string' && parsed.name.trim().length > 0 ? parsed.name.trim() : '';
      if (parsed.config === null || typeof parsed.config !== 'object' || Array.isArray(parsed.config)) {
        throw new Error(t('importMissingConfig'));
      }
      // 把导出文件里的版本号一并交给 Host 校验（旧文件没有该字段则不带）。
      const version =
        typeof parsed.version === 'number' && Number.isFinite(parsed.version) ? parsed.version : undefined;
      await importTheme(
        name || t('importThemePrefix') + ((themes ? themes.length : 0) + 1),
        parsed.config as XiaoConfig,
        version,
      );
      await refresh();
    } catch (ex) {
      fail(ex);
    }
  };

  const onRestoreDefaults = async (): Promise<void> => {
    if (busy) return;
    if (!pendingRestore) {
      setPendingRestore(true);
      return;
    }
    setBusy(true);
    setError(null);
    setPendingRestore(false);
    try {
      await restoreConfig(store);
      await refresh();
    } catch (e) {
      fail(e);
    }
    setBusy(false);
  };

  const themeList = themes || [];
  const selectOptions = themeList.map((t2) =>
    React.createElement('option', { key: t2.id, value: t2.id }, t2.name + (t2.builtin ? t('builtinSuffix') : '')),
  );
  const themeRows = themeList.map((t2) => {
    const editing = editingId === t2.id;
    // 紧凑行：名称占满剩余宽度并省略号，右侧只放「当前 / 内置」小胶囊 + 小号操作按钮。
    const nameContent = editing
      ? React.createElement('input', {
          className: 'xiao-settings-input xiao-theme-rename',
          value: editingName,
          autoFocus: true,
          onChange: (e: React.ChangeEvent<HTMLInputElement>) => setEditingName(e.target.value),
          onBlur: () => void onRename(t2.id, editingName),
          onKeyDown: (e: React.KeyboardEvent<HTMLInputElement>) => {
            if (e.key === 'Enter') void onRename(t2.id, editingName);
            else if (e.key === 'Escape') {
              setEditingId(null);
              setEditingName('');
            }
          },
        })
      : React.createElement(
          'span',
          { className: 'xiao-theme-namewrap' },
          React.createElement('span', { className: 'xiao-theme-name', title: t2.name }, t2.name),
          t2.active
            ? React.createElement('span', { className: 'xiao-theme-tag xiao-theme-tag-active' }, t('activeTag'))
            : null,
          t2.builtin
            ? React.createElement('span', { className: 'xiao-theme-tag', title: t('builtinNotDelete') }, t('builtinTag'))
            : null,
        );
    return React.createElement(
      'div',
      { className: 'xiao-theme-row' + (t2.active ? ' xiao-theme-row-active' : ''), key: t2.id },
      nameContent,
      // 行内切换：非当前主题才显示，且编辑名称时不渲染（避免 blur-rename 与 activate 并发）。
      editing || t2.active
        ? null
        : React.createElement(
            'button',
            {
              className: 'xiao-settings-btn xiao-theme-act xiao-theme-act-primary',
              type: 'button',
              disabled: busy,
              title: t('useThemeHint'),
              onClick: () => void onActivate(t2.id),
            },
            t('useTheme'),
          ),
      editing
        ? null
        : React.createElement(
            'button',
            {
              className: 'xiao-settings-btn xiao-theme-act',
              type: 'button',
              disabled: busy,
              onClick: () => {
                setEditingId(t2.id);
                setEditingName(t2.name);
              },
            },
            t('rename'),
          ),
      React.createElement(
        'button',
        { className: 'xiao-settings-btn xiao-theme-act', type: 'button', onClick: () => void onExport(t2.id) },
        t('exportTheme'),
      ),
      t2.builtin
        ? null
        : React.createElement(
            'button',
            {
              className: 'xiao-settings-btn xiao-theme-act' + (pendingDeleteId === t2.id ? ' xiao-settings-danger' : ''),
              type: 'button',
              disabled: busy,
              onClick: () => void onDelete(t2.id),
            },
            pendingDeleteId === t2.id ? t('confirmDelete') : t('deleteTheme'),
          ),
    );
  });

  return React.createElement(
    'div',
    { className: 'xiao-settings-section' },
    React.createElement('div', { className: 'xiao-settings-title' }, t('themeManager')),
    React.createElement('div', { className: 'xiao-settings-hint' }, t('themeManagerHint')),
    React.createElement(
      'div',
      { className: 'xiao-settings-row' },
      React.createElement('label', { className: 'xiao-settings-label' }, t('currentTheme')),
      React.createElement(
        'select',
        {
          className: 'xiao-settings-select',
          value: activeId || '',
          disabled: busy || themeList.length === 0,
          onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void onActivate(e.target.value),
        },
        ...selectOptions,
      ),
    ),
    React.createElement(
      'div',
      { className: 'xiao-settings-row' },
      React.createElement('label', { className: 'xiao-settings-label' }, t('saveAsNewTheme')),
      React.createElement('input', {
        className: 'xiao-settings-input',
        type: 'text',
        value: newName,
        placeholder: t('themeNamePlaceholder'),
        onChange: (e: React.ChangeEvent<HTMLInputElement>) => setNewName(e.target.value),
        onKeyDown: (e: React.KeyboardEvent<HTMLInputElement>) => {
          if (e.key === 'Enter') void onCreate();
        },
      }),
      React.createElement('button', { className: 'xiao-settings-btn', type: 'button', disabled: busy, onClick: () => void onCreate() }, t('save')),
    ),
    React.createElement(
      'div',
      { className: 'xiao-settings-row' },
      React.createElement('label', { className: 'xiao-settings-label' }, t('restoreDefault')),
      React.createElement(
        'button',
        {
          className: 'xiao-settings-btn' + (pendingRestore ? ' xiao-settings-danger' : ''),
          type: 'button',
          disabled: busy,
          onClick: () => void onRestoreDefaults(),
        },
        pendingRestore ? t('confirmRestore') : t('restoreCurrentTheme'),
      ),
    ),
    ...(pendingRestore
      ? [
          React.createElement(
            'div',
            { className: 'xiao-settings-warn' },
            t('restoreWarn'),
          ),
        ]
      : []),
    ...(themeList.length > 0
      ? [
          React.createElement(
            'div',
            { className: 'xiao-theme-list-head' },
            React.createElement('span', { className: 'xiao-theme-list-title' }, t('themeListTitle')),
            React.createElement('span', { className: 'xiao-theme-list-title' }, String(themeList.length)),
          ),
          // 自带滚动容器：块高与主题数量解耦（max-height 固定上限），主题多时在框内滚动，不顶长设置页。
          React.createElement('div', { className: 'xiao-theme-list' }, ...themeRows),
        ]
      : []),
    React.createElement(
      'div',
      { className: 'xiao-settings-row' },
      React.createElement('label', { className: 'xiao-settings-label' }, t('importTheme')),
      // 原生 file 控件的按钮与占位文字跟随「浏览器 UI 语言」（英文界面下仍显示「选择文件」），
      // 故隐藏它、改用插件自己的按钮触发；文案随 DSH 界面语言。
      React.createElement('input', {
        ref: importRef,
        className: 'xiao-settings-file',
        type: 'file',
        accept: '.json,application/json',
        style: { display: 'none' },
        onChange: (e: React.ChangeEvent<HTMLInputElement>) => void onImportFile(e),
      }),
      React.createElement(
        'button',
        {
          className: 'xiao-settings-btn',
          type: 'button',
          onClick: () => {
            if (importRef.current) importRef.current.click();
          },
        },
        t('chooseFile'),
      ),
      React.createElement(
        'button',
        {
          className: 'xiao-settings-btn',
          type: 'button',
          style: { marginLeft: 'auto' },
          onClick: () => void refresh(),
        },
        t('refresh'),
      ),
    ),
    ...(error ? [React.createElement('div', { className: 'xiao-settings-hint' }, error)] : []),
  );
}
/** 设置页组件：提示词（语言/自定义/恢复默认）+ 头像 + 磨砂背景（开关/路径/上传/参数）。 */
/** 把字节数格式化为可读大小。 */
function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1024 / 1024).toFixed(1) + ' MB';
}

/** 判断上传项是否为视频（用于缩略图渲染）：视频用 <video> 元素，其它用 <img>。 */
function isUploadVideo(item: UploadEntry): boolean {
  return item.isDynamic === true && /\.(mp4|webm|mov|m4v)$/i.test(item.ext || '');
}

/**
 * 上传选择器弹窗：列出已上传的背景/头像，可选中复用（写入当前主题配置），也可在窗口内上传并自动选中。
 * 提供「打开上传文件夹」让用户在系统文件管理器里直接增删改。全程不自动删除任何文件。
 */
function UploadPicker({
  kind,
  store,
  onClose,
  mode = 'replace',
  existingPaths,
  onAdd,
}: {
  kind: 'bg' | 'avatar';
  store: ConfigStore;
  onClose: () => void;
  /** replace：点选后写回「第 1 张」；add：点选即加入轮播列表（不写配置，走 onAdd）。 */
  mode?: 'replace' | 'add';
  /** add 模式：已在轮播列表里的路径，标记为「已添加」且不可重复点选。 */
  existingPaths?: string[];
  /** add 模式：点选（或上传）一项后的回调。 */
  onAdd?: (entry: { path: string; dynamic: boolean }) => void;
}): React.ReactElement {
  const addMode = mode === 'add';
  const [items, setItems] = React.useState<UploadEntry[] | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [selected, setSelected] = React.useState<string | null>(null);
  const [uploading, setUploading] = React.useState<boolean>(false);
  const [using, setUsing] = React.useState<boolean>(false);
  const [opening, setOpening] = React.useState<boolean>(false);
  const [folderHint, setFolderHint] = React.useState<string | null>(null);
  const fileRef = React.useRef<HTMLInputElement | null>(null);

  const accept =
    kind === 'avatar'
      ? 'image/png,image/jpeg,image/webp,image/gif,image/svg+xml'
      : 'image/png,image/jpeg,image/webp,image/gif,image/svg+xml,video/mp4,video/webm';
  const configKey = kind === 'avatar' ? 'avatarPath' : 'backgroundImagePath';
  const dynamicKey = kind === 'avatar' ? null : 'backgroundDynamic';

  /** 从 Host 拉取上传列表；失败时设 error 并返回 []。 */
  const loadList = React.useCallback(async (): Promise<UploadEntry[]> => {
    try {
      const response = await fetch('/xiao-theme/uploads?kind=' + kind, { cache: 'no-store', headers: xiaoLangHeader() });
      if (!response.ok) {
        setError('HTTP ' + response.status);
        return [];
      }
      const data = (await response.json()) as UploadListResponse;
      return data.uploads || [];
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      return [];
    }
  }, [kind]);

  /** 应用列表并保持选中态（选中项消失则回落第一个）。 */
  const applyList = React.useCallback((list: UploadEntry[]): void => {
    setItems(list);
    setSelected((prev) => (prev && list.some((u) => u.name === prev) ? prev : list[0] ? list[0].name : null));
  }, []);

  const refresh = React.useCallback(async (): Promise<void> => {
    setError(null);
    applyList(await loadList());
  }, [loadList, applyList]);

  React.useEffect(() => {
    void refresh();
  }, [refresh]);

  const thumbUrl = (item: UploadEntry): string =>
    '/xiao-theme/uploads-file?name=' + encodeURIComponent(item.name) + '&v=' + item.mtime;

  /** add 模式：该项是否已在轮播列表里（已添加的不可重复点）。 */
  const alreadyAdded = (item: UploadEntry): boolean =>
    existingPaths !== undefined && existingPaths.indexOf(item.path) >= 0;

  /** 选中并写回当前主题背景/头像配置。 */
  const useSelected = async (): Promise<void> => {
    const item = items && items.find((u) => u.name === selected);
    if (!item || using) return;
    setUsing(true);
    try {
      const patch: Partial<XiaoConfig> = { [configKey]: item.path };
      if (kind === 'bg' && dynamicKey !== null) patch[dynamicKey] = item.isDynamic;
      await saveConfig(store, patch);
      onClose();
    } finally {
      setUsing(false);
    }
  };

  /** 窗口内上传：成功后刷新列表 + 自动选中刚上传的文件。 */
  const onUpload = async (e: React.ChangeEvent<HTMLInputElement>): Promise<void> => {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      if (addMode) {
        // add 模式：上传后直接把文件加入轮播列表（不覆盖「第 1 张」背景）。
        const result = await uploadBackgroundFile(file);
        if ('error' in result) {
          setError(t('uploadsUploadFailed') + ': ' + result.error);
        } else {
          await refresh();
          if (onAdd) onAdd({ path: result.path, dynamic: result.dynamic });
        }
        return;
      }
      const err = kind === 'avatar' ? await uploadAvatar(store, file) : await uploadBackground(store, file);
      if (err !== null) {
        setError(t('uploadsUploadFailed') + ': ' + err);
      } else {
        const list = await loadList();
        applyList(list);
        const currentPath = store.getSnapshot()[configKey];
        const match = list.find((u) => u.path === currentPath);
        if (match) setSelected(match.name);
      }
    } finally {
      setUploading(false);
    }
  };

  const onOpenFolder = async (): Promise<void> => {
    setOpening(true);
    try {
      const response = await fetch('/xiao-theme/open-uploads', { method: 'POST', headers: xiaoLangHeader() });
      const data = (await response.json()) as { ok?: boolean; path?: string };
      if (data && data.ok) {
        setFolderHint(t('uploadsFolderOpened'));
      } else {
        setFolderHint(t('uploadsFolderFailed') + ' ' + (data && data.path ? data.path : ''));
      }
    } catch {
      setFolderHint(t('uploadsFolderFailed'));
    } finally {
      setOpening(false);
    }
  };

  const listBody =
    items === null
      ? React.createElement('div', { className: 'xiao-upload-empty' }, t('uploadsFetchError'))
      : items.length === 0
        ? React.createElement('div', { className: 'xiao-upload-empty' }, t('uploadsEmpty'))
        : React.createElement(
            'div',
            { className: 'xiao-upload-list' },
            items.map((item) =>
              React.createElement(
                'div',
                {
                  className:
                    'xiao-upload-item' +
                    (addMode
                      ? alreadyAdded(item)
                        ? ' xiao-upload-item-sel'
                        : ''
                      : selected === item.name
                        ? ' xiao-upload-item-sel'
                        : ''),
                  key: item.name,
                  onClick: () => {
                    if (!addMode) {
                      setSelected(item.name);
                      return;
                    }
                    // add 模式：点缩略图即加入轮播（已添加的忽略）。
                    if (alreadyAdded(item) || !onAdd) return;
                    onAdd({ path: item.path, dynamic: item.isDynamic });
                  },
                },
                isUploadVideo(item)
                  ? React.createElement('video', {
                      className: 'xiao-upload-thumb',
                      src: thumbUrl(item),
                      muted: true,
                      playsInline: true,
                      preload: 'metadata',
                    })
                  : React.createElement('img', { className: 'xiao-upload-thumb', src: thumbUrl(item) }),
                React.createElement(
                  'div',
                  { className: 'xiao-upload-info' },
                  React.createElement('div', { className: 'xiao-upload-name' }, item.name),
                  React.createElement('div', { className: 'xiao-upload-meta' }, formatFileSize(item.size) + ' · ' + (item.ext || '')),
                  React.createElement(
                    'div',
                    { className: 'xiao-upload-ref' },
                    addMode && alreadyAdded(item)
                      ? React.createElement('span', { className: 'xiao-upload-cur' }, t('bgAlreadyAdded'))
                      : null,
                    !addMode && item.active
                      ? React.createElement('span', { className: 'xiao-upload-cur' }, t('uploadsCurrent'))
                      : null,
                    !addMode && item.usedBy.length > 0
                      ? t('uploadsUsedBy') + ': ' + item.usedBy.join(', ')
                      : null,
                  ),
                ),
              ),
            ),
          );

  return React.createElement(
    'div',
    { className: 'xiao-upload-modal' },
    React.createElement(
      'div',
      { className: 'xiao-upload-panel' },
      React.createElement('div', { className: 'xiao-upload-head' }, addMode ? t('bgPickerAddTitle') : t('uploadsTitle')),
      error ? React.createElement('div', { className: 'xiao-settings-warn' }, error) : null,
      listBody,
      folderHint ? React.createElement('div', { className: 'xiao-settings-hint' }, folderHint) : null,
      React.createElement('input', {
        ref: fileRef,
        type: 'file',
        accept,
        style: { display: 'none' },
        onChange: onUpload,
      }),
      React.createElement(
        'div',
        { className: 'xiao-upload-foot' },
        React.createElement(
          'button',
          {
            className: 'xiao-settings-btn',
            type: 'button',
            disabled: uploading,
            onClick: () => {
              if (fileRef.current) fileRef.current.click();
            },
          },
          uploading ? t('uploadsUploading') : t('uploadsUpload'),
        ),
        React.createElement(
          'button',
          {
            className: 'xiao-settings-btn',
            type: 'button',
            disabled: opening,
            onClick: () => void onOpenFolder(),
          },
          t('uploadsOpenFolder'),
        ),
        addMode
          ? null
          : React.createElement(
              'button',
              {
                className: 'xiao-settings-btn',
                type: 'button',
                disabled: using || selected === null,
                onClick: () => void useSelected(),
              },
              t('uploadsUse'),
            ),
        React.createElement(
          'button',
          { className: 'xiao-settings-btn', type: 'button', onClick: onClose },
          addMode ? t('uploadsDone') : t('uploadsClose'),
        ),
      ),
    ),
  );
}

/**
 * 角色空间（娱乐）设置块：一键开关 + 角色 system prompt + 预设安装状态。
 * 与上方「语气」分组彻底分开：这里产出的是一个独立 agent preset，永不进工作会话。
 */
function RoleplayGroup({ cfg, store }: { cfg: XiaoConfig; store: ConfigStore }): React.ReactElement {
  // masterOn = 主题总开关（「启用{主题名}主题」）；featureOn = 角色空间自己的开关（用户的选择，不受总开关影响）；
  // active = 两者同时开才真正生效（Host 端同判断，总开关关闭时会移除预设）。
  const masterOn = cfg.enabled !== false;
  const featureOn = cfg.roleplayEnabled === true;
  const enabled = masterOn && featureOn;
  const persona = cfg.roleplayPersona || '';
  const [status, setStatus] = React.useState<RoleplayStatus | null>(null);
  const [busy, setBusy] = React.useState<boolean>(false);
  const [hint, setHint] = React.useState<string | null>(null);

  const refresh = React.useCallback(async (): Promise<void> => {
    try {
      setStatus(await getRoleplayStatus());
    } catch {
      setStatus(null);
    }
  }, []);

  React.useEffect(() => {
    void refresh();
  }, [refresh, enabled, persona]);

  const onApply = async (): Promise<void> => {
    if (busy) return;
    setBusy(true);
    setHint(null);
    try {
      await applyRoleplayPreset();
      await refresh();
      setHint(t('roleplayApplied'));
    } catch (e) {
      setHint(e instanceof Error ? e.message : String(e));
    }
    setBusy(false);
  };

  const onOpenFolder = async (): Promise<void> => {
    setHint(null);
    try {
      const data = await openRoleplayFolder();
      setHint(data.ok ? t('uploadsFolderOpened') : t('uploadsFolderFailed') + ' ' + (data.path || ''));
    } catch {
      setHint(t('uploadsFolderFailed'));
    }
  };

  const statusText =
    status === null
      ? t('roleplayStatusUnknown')
      : !masterOn
        ? t('roleplayStatusMasterOff')
        : !featureOn
          ? t('roleplayStatusOff')
          : (status.installed ? t('roleplayStatusInstalled') : t('roleplayStatusMissing')) +
            ' · ' + status.presetName + ' · ' + status.path;

  return React.createElement(
    'div',
    { className: 'xiao-settings-section' },
    React.createElement('div', { className: 'xiao-settings-title' }, t('roleplaySection')),
    React.createElement(
      'div',
      { className: 'xiao-settings-row' },
      React.createElement('label', { className: 'xiao-settings-label' }, t('roleplayEnable')),
      React.createElement('input', {
        type: 'checkbox',
        // 显示的是「用户自己的选择」，而不是合成结果：总开关关掉时不该把角色开关也画成关闭。
        checked: featureOn,
        disabled: !masterOn,
        onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
          void saveConfig(store, { roleplayEnabled: e.target.checked });
        },
      }),
    ),
    React.createElement(
      'div',
      { className: 'xiao-settings-row' },
      React.createElement('label', { className: 'xiao-settings-label' }, t('roleplayNetwork')),
      React.createElement('input', {
        type: 'checkbox',
        // 网络是运行时能力：只有角色空间真正生效（总开关 + 角色开关）时才可改。
        checked: cfg.roleplayNetwork === true,
        disabled: !enabled,
        onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
          void saveConfig(store, { roleplayNetwork: e.target.checked });
        },
      }),
    ),
    React.createElement('div', { className: 'xiao-settings-hint' }, t('roleplayNetworkHint')),
    React.createElement(
      'div',
      { className: 'xiao-settings-row xiao-settings-row-top' },
      React.createElement('label', { className: 'xiao-settings-label' }, t('roleplayPersona')),
      React.createElement('textarea', {
        className: 'xiao-settings-textarea',
        defaultValue: persona,
        key: persona,
        rows: 7,
        disabled: !enabled,
        placeholder: t('roleplayPersonaPlaceholder'),
        onBlur: (e: React.FocusEvent<HTMLTextAreaElement>) => {
          const next = e.target.value;
          if (next !== persona) void saveConfig(store, { roleplayPersona: next });
        },
      }),
    ),
    React.createElement(
      'div',
      { className: 'xiao-settings-row' },
      React.createElement(
        'button',
        {
          className: 'xiao-settings-btn',
          type: 'button',
          disabled: busy || !enabled,
          onClick: () => void onApply(),
        },
        t('roleplayApply'),
      ),
      React.createElement(
        'button',
        {
          className: 'xiao-settings-btn',
          type: 'button',
          disabled: !enabled,
          onClick: () => void saveConfig(store, { roleplayPersona: '' }),
        },
        t('roleplayResetPersona'),
      ),
      React.createElement(
        'button',
        { className: 'xiao-settings-btn', type: 'button', onClick: () => void onOpenFolder() },
        t('roleplayOpenFolder'),
      ),
    ),
    React.createElement('div', { className: 'xiao-settings-hint' }, statusText),
    React.createElement('div', { className: 'xiao-settings-hint' }, t('roleplayHint')),
    React.createElement('div', { className: 'xiao-settings-hint' }, t('roleplayHintWork')),
    hint ? React.createElement('div', { className: 'xiao-settings-hint' }, hint) : null,
  );
}

/**
 * 多背景列表编辑器：列出全部背景（路径 / 动态标记），支持上移 / 下移 / 移除，
 * 并从「已上传文件」下拉添加，或直接上传新文件后追加。
 * 列表只有 1 项时不渲染列表行（保持单背景界面简洁），只保留添加入口；
 * 一旦 ≥ 2 项即出现列表与上移/下移/移除控件，Host 端随即进入轮播。
 */
/**
 * 多背景列表编辑器：每条背景带缩略图，可上移 / 下移 / 移除；「从已上传文件添加」打开带缩略图的
 * 上传选择器（复用 UploadPicker 的 add 模式），按图挑选，不再靠文件名下拉。
 * 列表只有 1 项时不渲染列表行（保持单背景界面简洁），只保留添加入口；
 * 一旦 ≥ 2 项即出现列表与控件，Host 端随即进入轮播。
 */
function BackgroundListEditor({ list, store }: { list: BackgroundEntry[]; store: ConfigStore }): React.ReactElement {
  const [pickerOpen, setPickerOpen] = React.useState<boolean>(false);
  const [note, setNote] = React.useState<string | null>(null);

  // 写回列表：withBackgroundMirror 会把首项自动同步到单张旧字段，因此无需在这里手工镜像。
  const apply = (next: BackgroundEntry[]): void => {
    if (next.length === 0) return; // 至少保留 1 项，避免把背景清空
    void saveConfig(store, { backgroundList: next });
  };
  const move = (index: number, delta: number): void => {
    const target = index + delta;
    if (target < 0 || target >= list.length) return;
    const next = list.map((entry) => ({ ...entry }));
    const swap = next[index]!;
    next[index] = next[target]!;
    next[target] = swap;
    apply(next);
  };
  const removeAt = (index: number): void => {
    if (list.length <= 1) return;
    apply(list.filter((_entry, i) => i !== index));
  };
  const addPath = (path: string, dynamic: boolean): void => {
    if (list.some((entry) => entry.path === path)) {
      setNote(t('bgAddDuplicate'));
      return;
    }
    setNote(null);
    apply([...list, { path, dynamic }]);
  };

  /** 行缩略图：视频用 <video>（preload metadata 取首帧），静态图 / GIF 用 <img>。 */
  const thumbFor = (entry: BackgroundEntry, index: number): React.ReactElement => {
    const url = bgThumbUrl(entry, index);
    return entry.dynamic === true && isVideoPath(entry.path)
      ? React.createElement('video', {
          className: 'xiao-bg-thumb',
          src: url,
          muted: true,
          playsInline: true,
          preload: 'metadata',
        })
      : React.createElement('img', { className: 'xiao-bg-thumb', src: url, alt: '', loading: 'lazy' });
  };

  const rows =
    list.length < 2
      ? null
      : React.createElement(
          'div',
          { className: 'xiao-bg-rows' },
          list.map((entry, index) =>
            React.createElement(
              'div',
              { className: 'xiao-bg-row', key: entry.path },
              React.createElement('span', { className: 'xiao-bg-index' }, String(index + 1)),
              thumbFor(entry, index),
              React.createElement('span', { className: 'xiao-bg-name', title: entry.path }, shortBgName(entry.path)),
              React.createElement(
                'span',
                { className: 'xiao-bg-tag' },
                entry.dynamic ? t('bgDynamicTag') : t('bgStaticTag'),
              ),
              React.createElement(
                'button',
                { className: 'xiao-settings-btn xiao-bg-mini', type: 'button', disabled: index === 0, title: t('bgMoveUp'), onClick: () => move(index, -1) },
                '\u2191',
              ),
              React.createElement(
                'button',
                { className: 'xiao-settings-btn xiao-bg-mini', type: 'button', disabled: index === list.length - 1, title: t('bgMoveDown'), onClick: () => move(index, 1) },
                '\u2193',
              ),
              React.createElement(
                'button',
                { className: 'xiao-settings-btn xiao-bg-mini xiao-settings-danger', type: 'button', disabled: list.length <= 1, title: t('bgRemove'), onClick: () => removeAt(index) },
                '\u00d7',
              ),
            ),
          ),
        );

  return React.createElement(
    'div',
    { className: 'xiao-bg-editor' },
    React.createElement('div', { className: 'xiao-settings-label' }, t('bgListTitle')),
    rows,
    React.createElement(
      'div',
      { className: 'xiao-settings-row' },
      React.createElement(
        'button',
        { className: 'xiao-settings-btn', type: 'button', onClick: () => setPickerOpen(true) },
        t('bgAddFromUploads'),
      ),
    ),
    note !== null ? React.createElement('div', { className: 'xiao-settings-hint' }, note) : null,
    React.createElement('div', { className: 'xiao-settings-hint' }, t('bgListHint')),
    pickerOpen
      ? React.createElement(UploadPicker, {
          kind: 'bg',
          store,
          mode: 'add',
          existingPaths: list.map((entry) => entry.path),
          onAdd: (entry: { path: string; dynamic: boolean }) => addPath(entry.path, entry.dynamic),
          onClose: () => setPickerOpen(false),
        })
      : null,
  );
}

function XiaoSettingsPage({ store }: { store: ConfigStore }): React.ReactElement {
  const [snapshot, setSnapshot] = React.useState<XiaoConfig>(() => store.getSnapshot());
  React.useEffect(() => store.subscribe(() => setSnapshot(store.getSnapshot())), [store]);
  const [saveErr, setSaveErr] = React.useState<string | null>(() => saveError.get());
  React.useEffect(() => saveError.subscribe(() => setSaveErr(saveError.get())), []);
  // 设置页**内**标题也与左侧分区标题同源：跟随当前主题名（订阅 activeThemeNameListeners 重渲染）。
  const [themeName, setThemeName] = React.useState<string>(() => getActiveThemeName());
  React.useEffect(() => {
    const onThemeNameChange = (): void => setThemeName(getActiveThemeName());
    activeThemeNameListeners.add(onThemeNameChange);
    onThemeNameChange();
    return () => {
      activeThemeNameListeners.delete(onThemeNameChange);
    };
  }, []);
  const [pickerKind, setPickerKind] = React.useState<'bg' | 'avatar' | null>(null);
  const cfg = snapshot;
  const enabled = cfg.enabled !== false;
  const voiceEnabled = cfg.voiceEnabled !== false;
  const avatarPath = cfg.avatarPath || CLIENT_DEFAULT_CONFIG.avatarPath;
  const voiceLanguage = cfg.voiceLanguage === 'zh' ? 'zh' : 'en';
  const voicePrompt = cfg.voicePrompt || '';
  const bgEnabled = cfg.backgroundEnabled !== false;
  // 多背景列表（长度恒 ≥ 1；≤1 时走单张快路径，界面与旧版一致）。
  const bgList = effectiveBackgroundList(cfg);
  const isMultiList = bgList.length >= 2;
  const bgPath = bgList[0]!.path;
  // 是否含视频（在下方显示「视频背景声音」开关；仅视频背景可播声音）。
  const isVideoBg = bgList.some((entry) => entry.dynamic === true && isVideoPath(entry.path));
  const themeColor =
    typeof cfg.themeColor === 'string' && /^#[0-9a-fA-F]{6}$/.test(cfg.themeColor)
      ? cfg.themeColor
      : DEFAULT_THEME_COLOR;
  // 吉祥物文案按界面语言显示出厂默认（config 里仍存中文出厂默认，不改持久化格式）。
  const mascotTitleShown = mascotText(cfg.mascotTitle, 'title');
  const mascotSubtitleShown = mascotText(cfg.mascotSubtitle, 'subtitle');

  return React.createElement(
    'div',
    { className: 'xiao-settings' },
    React.createElement(ThemeManager, { store }),
    // —— 总开关 ——
    React.createElement(
      'div',
      { className: 'xiao-settings-section' },
      // 标题与左侧分区标题同源：{主题名} + 语言后缀（内置默认主题 / 尚未取到名字时回落「魈主题 / Xiao Theme」）。
      // 第二参传 '' 让它走 t()，即按当前 <html lang> 判语言，与页面内其它文案完全一致。
      React.createElement('div', { className: 'xiao-settings-title' }, composeThemeTitle(themeName, '')),
      React.createElement(
        'div',
        { className: 'xiao-settings-row' },
        // 总开关文案也跟随主题名：`启用{主题名}主题`（默认主题即历史文案「启用魈主题」）。
        React.createElement('label', { className: 'xiao-settings-label' }, composeEnableThemeLabel(themeName, '')),
        React.createElement('input', {
          type: 'checkbox',
          checked: enabled,
          onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
            void saveConfig(store, { enabled: e.target.checked });
          },
        }),
      ),
      React.createElement(
        'div',
        { className: 'xiao-settings-row' },
        React.createElement('label', { className: 'xiao-settings-label' }, t('themeColor')),
        React.createElement('input', {
          className: 'xiao-settings-color',
          type: 'color',
          value: themeColor,
          onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
            void saveConfig(store, { themeColor: e.target.value });
          },
        }),
        React.createElement(
          'button',
          {
            className: 'xiao-settings-btn',
            type: 'button',
            onClick: () => void saveConfig(store, { themeColor: CLIENT_DEFAULT_CONFIG.themeColor }),
          },
          t('restoreThemeColor'),
        ),
      ),
    ),

    // —— 提示词 ——
    React.createElement(
      'div',
      { className: 'xiao-settings-section' },
      React.createElement('div', { className: 'xiao-settings-title' }, t('voiceSection')),
      React.createElement('div', { className: 'xiao-settings-hint' }, t('voiceSectionHint')),
      React.createElement(
        'div',
        { className: 'xiao-settings-row' },
        React.createElement('label', { className: 'xiao-settings-label' }, t('injectVoice')),
        React.createElement('input', {
          type: 'checkbox',
          checked: voiceEnabled,
          onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
            void saveConfig(store, { voiceEnabled: e.target.checked });
          },
        }),
      ),
      React.createElement(
        'div',
        { className: 'xiao-settings-row' },
        React.createElement('label', { className: 'xiao-settings-label' }, t('templateLang')),
        React.createElement(
          'select',
          {
            className: 'xiao-settings-select',
            value: voiceLanguage,
            disabled: !voiceEnabled,
            onChange: (e: React.ChangeEvent<HTMLSelectElement>) => {
              void saveConfig(store, { voiceLanguage: e.target.value as 'en' | 'zh' });
            },
          },
          React.createElement('option', { value: 'en' }, 'English'),
          React.createElement('option', { value: 'zh' }, '中文'),
        ),
      ),
      React.createElement(
        'div',
        { className: 'xiao-settings-row xiao-settings-row-top' },
        React.createElement('label', { className: 'xiao-settings-label' }, t('customPrompt')),
        React.createElement('textarea', {
          className: 'xiao-settings-textarea',
          defaultValue: voicePrompt,
          key: voicePrompt,
          rows: 5,
          disabled: !voiceEnabled,
          placeholder: t('promptPlaceholder'),
          onBlur: (e: React.FocusEvent<HTMLTextAreaElement>) => {
            const next = e.target.value;
            if (next !== cfg.voicePrompt) void saveConfig(store, { voicePrompt: next });
          },
        }),
      ),
      React.createElement(
        'div',
        { className: 'xiao-settings-row' },
        React.createElement(
          'button',
          {
            className: 'xiao-settings-btn',
            type: 'button',
            disabled: !voiceEnabled,
            onClick: () => void saveConfig(store, { voiceLanguage: 'en', voicePrompt: '', voiceEnabled: true }),
          },
          t('restorePrompt'),
        ),
      ),
    ),

    // —— 角色空间（娱乐）——
    React.createElement(RoleplayGroup, { cfg, store }),

    // —— 吉祥物 ——
    React.createElement(
      'div',
      { className: 'xiao-settings-section' },
      React.createElement('div', { className: 'xiao-settings-title' }, t('mascotSection')),
      React.createElement(
        'div',
        { className: 'xiao-settings-row' },
        React.createElement('label', { className: 'xiao-settings-label' }, t('avatarPath')),
        React.createElement('input', {
          className: 'xiao-settings-input',
          type: 'text',
          defaultValue: avatarPath,
          key: avatarPath,
          onBlur: (e: React.FocusEvent<HTMLInputElement>) => {
            const next = e.target.value.trim();
            if (next.length > 0) void saveConfig(store, { avatarPath: next });
          },
        }),
      ),
      React.createElement(
        'div',
        { className: 'xiao-settings-row' },
        React.createElement('button', { className: 'xiao-settings-btn', type: 'button', onClick: () => setPickerKind('avatar') }, t('uploadAvatar')),
      ),
      React.createElement(
        'div',
        { className: 'xiao-settings-row' },
        React.createElement('label', { className: 'xiao-settings-label' }, t('titleField')),
        React.createElement('input', {
          className: 'xiao-settings-input',
          type: 'text',
          defaultValue: mascotTitleShown,
          key: mascotTitleShown,
          onBlur: (e: React.FocusEvent<HTMLInputElement>) => {
            const next = e.target.value;
            if (next !== mascotTitleShown) void saveConfig(store, { mascotTitle: next });
          },
        }),
      ),
      React.createElement(
        'div',
        { className: 'xiao-settings-row' },
        React.createElement('label', { className: 'xiao-settings-label' }, t('subtitleField')),
        React.createElement('input', {
          className: 'xiao-settings-input',
          type: 'text',
          defaultValue: mascotSubtitleShown,
          key: mascotSubtitleShown,
          onBlur: (e: React.FocusEvent<HTMLInputElement>) => {
            const next = e.target.value;
            if (next !== mascotSubtitleShown) void saveConfig(store, { mascotSubtitle: next });
          },
        }),
      ),
      React.createElement(
        'div',
        { className: 'xiao-settings-row' },
        React.createElement(
          'button',
          {
            className: 'xiao-settings-btn',
            type: 'button',
            onClick: () =>
              void saveConfig(store, {
                avatarPath: CLIENT_DEFAULT_CONFIG.avatarPath,
                mascotTitle: CLIENT_DEFAULT_CONFIG.mascotTitle,
                mascotSubtitle: CLIENT_DEFAULT_CONFIG.mascotSubtitle,
              }),
          },
          t('restoreMascot'),
        ),
      ),
    ),

    // —— 磨砂背景 ——
    React.createElement(
      'div',
      { className: 'xiao-settings-section' },
      React.createElement('div', { className: 'xiao-settings-title' }, t('bgSection')),
      React.createElement(
        'div',
        { className: 'xiao-settings-row' },
        React.createElement('label', { className: 'xiao-settings-label' }, t('enableBg')),
        React.createElement('input', {
          type: 'checkbox',
          checked: bgEnabled,
          onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
            void saveConfig(store, { backgroundEnabled: e.target.checked });
          },
        }),
      ),
      React.createElement(
        'div',
        { className: 'xiao-settings-row' },
        React.createElement('label', { className: 'xiao-settings-label' }, isMultiList ? t('bgPathFirstMulti') : t('bgPath')),
        React.createElement('input', {
          className: 'xiao-settings-input',
          type: 'text',
          defaultValue: bgPath,
          key: bgPath,
          onBlur: (e: React.FocusEvent<HTMLInputElement>) => {
            const next = e.target.value.trim();
            if (next.length > 0) {
              // GIF/视频即动态背景：手动填 .gif/.mp4/.webm/.mov/.m4v 路径时自动视为动态背景；其余按静态背景。
              const isDynamic = /\.(gif|mp4|webm|mov|m4v)$/i.test(next);
              void saveConfig(store, { backgroundImagePath: next, backgroundDynamic: isDynamic });
            }
          },
        }),
      ),
      React.createElement(
        'div',
        { className: 'xiao-settings-row' },
        React.createElement('button', { className: 'xiao-settings-btn', type: 'button', onClick: () => setPickerKind('bg') }, t('uploadBg')),
      ),
      // 多背景：始终提供「添加第 2 张」入口；≥2 项时展开列表与排序 / 删除，并显示切换间隔。
      React.createElement(BackgroundListEditor, { list: bgList, store }),
      isMultiList
        ? React.createElement(RangeRow, {
            label: t('bgInterval'),
            value: clampNum(cfg.backgroundInterval, CLIENT_RANGES.backgroundInterval.min, CLIENT_RANGES.backgroundInterval.max, 30),
            min: CLIENT_RANGES.backgroundInterval.min,
            max: CLIENT_RANGES.backgroundInterval.max,
            step: 1,
            format: (v) => v + 's',
            onCommit: (v) => {
              if (v !== cfg.backgroundInterval) void saveConfig(store, { backgroundInterval: v });
            },
          })
        : null,
      isVideoBg &&
        React.createElement(
          'div',
          { className: 'xiao-settings-row' },
          React.createElement('label', { className: 'xiao-settings-label' }, t('videoAudio')),
          React.createElement('input', {
            type: 'checkbox',
            checked: cfg.backgroundVideoAudio === true,
            onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
              void saveConfig(store, { backgroundVideoAudio: e.target.checked });
            },
          }),
        ),
      // 视频背景音量：仅视频背景显示；与徽章里的音量滑杆写同一个字段。
      isVideoBg &&
        React.createElement(RangeRow, {
          label: t('videoVolume'),
          value: bgVolume(cfg),
          min: CLIENT_RANGES.backgroundVideoVolume.min,
          max: CLIENT_RANGES.backgroundVideoVolume.max,
          step: 0.01,
          format: (v: number) => Math.round(v * 100) + '%',
          onPreview: previewBgVolume,
          onCommit: (v: number) => {
            const patch: Partial<XiaoConfig> = { backgroundVideoVolume: v };
            if (v > 0 && cfg.backgroundVideoAudio !== true) patch.backgroundVideoAudio = true;
            void saveConfig(store, patch);
          },
        }),
      isVideoBg &&
        React.createElement('div', { className: 'xiao-settings-hint' }, t('videoVolumeHint')),
      React.createElement(RangeRow, {
        label: t('blurStrength'),
        value: clampNum(cfg.backgroundBlur, CLIENT_RANGES.backgroundBlur.min, CLIENT_RANGES.backgroundBlur.max, 22),
        min: 0,
        max: 60,
        step: 1,
        format: (v) => v + 'px',
        onCommit: (v) => {
          if (v !== cfg.backgroundBlur) void saveConfig(store, { backgroundBlur: v });
        },
      }),
      React.createElement(RangeRow, {
        label: t('uiOpacity'),
        value: clampNum(cfg.panelOpacity, CLIENT_RANGES.panelOpacity.min, CLIENT_RANGES.panelOpacity.max, 0.5),
        min: 0.3,
        max: 0.9,
        step: 0.01,
        format: (v) => Math.round(v * 100) + '%',
        onCommit: (v) => {
          if (v !== cfg.panelOpacity) void saveConfig(store, { panelOpacity: v });
        },
      }),
      React.createElement(RangeRow, {
        label: t('sidebarOpacity'),
        value: clampNum(cfg.sidebarOpacity, CLIENT_RANGES.sidebarOpacity.min, CLIENT_RANGES.sidebarOpacity.max, 0.85),
        min: 0,
        max: 1,
        step: 0.01,
        format: (v) => Math.round(v * 100) + '%',
        onCommit: (v) => {
          if (v !== cfg.sidebarOpacity) void saveConfig(store, { sidebarOpacity: v });
        },
      }),
      // 设置页不透明度：只作用于 DSH 设置对话框本身（面板 + 面板内表面），与上面两根滑杆互不影响。
      // 拖动时用 onPreview 直接改 CSS 变量即时预览，松开 / 失焦 / 键盘确认才写配置。
      React.createElement(RangeRow, {
        label: t('settingsOpacity'),
        value: settingsOpacity(cfg),
        min: CLIENT_RANGES.settingsOpacity.min,
        max: CLIENT_RANGES.settingsOpacity.max,
        step: 0.01,
        format: (v) => Math.round(v * 100) + '%',
        onPreview: (v) => previewSettingsOpacity(store, v),
        onCommit: (v) => {
          if (v !== settingsOpacity(cfg)) void saveConfig(store, { settingsOpacity: v });
        },
      }),
      React.createElement('div', { className: 'xiao-settings-hint' }, t('settingsOpacityHint')),
      React.createElement(
        'div',
        { className: 'xiao-settings-row' },
        React.createElement(
          'button',
          {
            className: 'xiao-settings-btn',
            type: 'button',
            onClick: () =>
              void saveConfig(store, {
                backgroundEnabled: true,
                // 显式重置为「单张」：只改单张字段会保留列表其余项，轮播仍会继续。
                backgroundList: [{ path: 'resource/avatar.png', dynamic: false }],
                backgroundImagePath: 'resource/avatar.png',
                backgroundDynamic: false,
                backgroundBlur: 22,
                panelOpacity: 0.5,
                sidebarOpacity: 0.85,
                settingsOpacity: 0.4,
              }),
          },
          t('useStaticDefault'),
        ),
        React.createElement(
          'button',
          {
            className: 'xiao-settings-btn',
            type: 'button',
            onClick: () =>
              void saveConfig(store, {
                backgroundEnabled: true,
                backgroundList: [{ path: 'resource/xiao_dynamic.gif', dynamic: true }],
                backgroundImagePath: 'resource/xiao_dynamic.gif',
                backgroundDynamic: true,
              }),
          },
          t('useDynamicExample'),
        ),
      ),
    ),

    React.createElement(
      'div',
      { className: 'xiao-settings-hint' },
      t('settingsHint'),
    ),
    saveErr !== null ? React.createElement('div', { className: 'xiao-settings-warn' }, saveErr) : null,
    pickerKind !== null
      ? React.createElement(UploadPicker, { kind: pickerKind, store, onClose: () => setPickerKind(null) })
      : null,
  );
}

const XIAO_CSS: string[] = [
  'html.xiao-bg-on,html.xiao-bg-on body{background-color:transparent!important;}',
  'html.xiao-bg-on body{background-image:var(--xiao-bg-img),linear-gradient(135deg,var(--xiao-grad-a),var(--xiao-theme-color) 55%,var(--xiao-grad-b))!important;background-color:transparent!important;background-attachment:fixed!important;background-size:cover!important;background-position:center!important;background-repeat:no-repeat!important;}',
  // 动态背景（GIF 动图）：覆盖为纯动图（去掉渐变着色），让动画按原色铺满并随页面播放；static 维持上方「URL+渐变」磨砂处理。
  'html.xiao-bg-on.xiao-bg-dynamic body{background-image:var(--xiao-bg-img)!important;}',
  // 视频背景：body 背景图置空，仅留 <video> 元素（fixed 垫底）作为视觉层；磨砂层仍由 #root>div 透出并模糊。
  'html.xiao-bg-on.xiao-bg-video body{background-image:none!important;}',
  // —— 多背景轮播：两个固定垫底层做交叉渐变（旧层淡出 / 新层淡入），时长由 BG_FADE_MS 决定。 ——
  // 图层是 body 的子元素、位于 #root 之前方，因此根框架的 backdrop-filter 磨砂同样会采样到它们。
  'html.xiao-bg-layers .xiao-bg-layer{position:fixed;inset:0;z-index:-1;pointer-events:none;background-color:transparent;background-size:cover;background-position:center;background-repeat:no-repeat;opacity:0;transition:opacity ' + BG_FADE_MS + 'ms ease;}',
  'html.xiao-bg-layers .xiao-bg-layer>video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;}',
  // ⚠️ 三区域涂色模型（web 0.1.5 与 desktop 0.1.7 共用一套；别按版本分叉，也别让同一区域涂两层）：
  //   框架 #root>div      → 不涂色，只保留 backdrop-filter 能力（web 原本靠它铺整屏，desktop 会被 DSH 再叠一层）
  //   中列 centerCol      → --xiao-bg-ovl        (panelOpacity，界面不透明度)
  //   左栏 sidebarCol     → --xiao-sidebar-ovl   (sidebarOpacity，侧栏不透明度)
  //   右栏面板            → 外框透明 + **内部表面**吃 --xiao-panel-ovl-*（≈0.8 档）
  //      · 右栏不能直接吃 0.85：它常是空面板，0.85 的实色会变成一片平色块（实测 std=5 vs 左栏 44）；
  //        改由内部表面（卡片/tab 条/文件树/预览）着色后，它是「透出背景的面」而不是色块。
  // ⚠️ 改这一族规则必须遵守：① 同一选择器只允许一条 !important 规则（重复 = 后写者赢，踩过 4 次）；
  //   ② 要中和某层，改它消费的 CSS 变量，别抢 background；③ 合入前先 grep 一遍同名选择器。
  'html.xiao-bg-on body>#root>div{background-color:transparent!important;background-image:none!important;-webkit-backdrop-filter:blur(var(--xiao-bg-blur));backdrop-filter:blur(var(--xiao-bg-blur));}',
  'html.xiao-bg-on [class$="centerCol"]{background-color:var(--xiao-bg-ovl)!important;background-image:none!important;}',
  'html.xiao-bg-on body[data-ds-dark-theme] [class$="centerCol"]{background-color:var(--xiao-bg-ovl-dark)!important;}',
  // 右栏列（0.1.7 起空着的一条轨道）：保持透明，别让它抢色。
  'html.xiao-bg-on [class$="rightbarCol"]{background-color:transparent!important;background-image:none!important;}',
  // 左栏：列吃 --xiao-sidebar-ovl；同一子树里的 SidebarRoot 还会铺一次 --dsw-specific-sidebar-fill，
  // 把它在列上置为 transparent，消除「列 + 侧栏根」的双层叠加。detailsCol 是 0.1.5 之前的列名，留给老版本。
  'html.xiao-bg-on [class$="sidebarCol"],[class$="detailsCol"]{background:var(--xiao-sidebar-ovl)!important;--dsw-specific-sidebar-fill:transparent!important;}',
  'html.xiao-bg-on body[data-ds-dark-theme] [class$="sidebarCol"],body[data-ds-dark-theme] [class$="detailsCol"]{background:var(--xiao-sidebar-ovl-dark)!important;--dsw-specific-sidebar-fill:transparent!important;}',
  // —— DSH 设置对话框（设置页）：**独立**不透明度（settingsOpacity / 设置页不透明度） ——
  // 面板本体由 DSH 自己用 background:var(--dsw-alias-bg-layer-2) 画底（0.2.1-rc.5 的 .AnXs9G_panel，无 !important），
  // 所以这里**不抢 background**，而是在面板元素自身上重写它消费的语义 token：元素级自定义属性优先于
  // 从 :root 继承来的值（继承不参与级联，无需 !important），于是面板本体与面板内表面（卡片 / 输入框 /
  // 悬浮层 / 文件预览）一起跟着「设置页不透明度」走，与界面 / 侧栏两族彻底解耦。
  // ⚠️ 取值全部来自 applyBackgroundChrome 下发的 --xiao-settings-ovl*（具体 rgba，无自我引用）。
  'html.xiao-bg-on [data-shortcut-modal="settings"]{--dsw-alias-bg-base:var(--xiao-settings-ovl);--dsw-alias-bg-layer-1:var(--xiao-settings-ovl-l1);--dsw-alias-bg-layer-2:var(--xiao-settings-ovl);--dsw-alias-bg-layer-3:var(--xiao-settings-ovl-l3);--dsw-alias-bg-overlay:var(--xiao-settings-ovl-overlay);--dsw-alias-bg-document-preview:var(--xiao-settings-ovl-l1);}',
  'html.xiao-bg-on body[data-ds-dark-theme] [data-shortcut-modal="settings"]{--dsw-alias-bg-base:var(--xiao-settings-ovl-dark);--dsw-alias-bg-layer-1:var(--xiao-settings-ovl-dark-l1);--dsw-alias-bg-layer-2:var(--xiao-settings-ovl-dark);--dsw-alias-bg-layer-3:var(--xiao-settings-ovl-dark-l3);--dsw-alias-bg-overlay:var(--xiao-settings-ovl-dark-overlay);--dsw-alias-bg-document-preview:var(--xiao-settings-ovl-dark-l1);}',
  // 旧版 DSH（0.1.5-rc.3 / 0.1.7-rc.2 实测：`data-shortcut-modal` 还不存在）只能靠 role="dialog"+aria-modal="true" 认面板；
  // 用 :has(>nav) 把它与图片灯箱（唯一另一处 aria-modal，直接子节点是 img / button）区分开。
  // 单独成规则而不是并进上面一条选择器列表：万一某版本不认 :has()，只丢这两条旧版兜底，不会连带主命中一起失效。
  'html.xiao-bg-on [role="dialog"][aria-modal="true"]:has(>nav){--dsw-alias-bg-base:var(--xiao-settings-ovl);--dsw-alias-bg-layer-1:var(--xiao-settings-ovl-l1);--dsw-alias-bg-layer-2:var(--xiao-settings-ovl);--dsw-alias-bg-layer-3:var(--xiao-settings-ovl-l3);--dsw-alias-bg-overlay:var(--xiao-settings-ovl-overlay);--dsw-alias-bg-document-preview:var(--xiao-settings-ovl-l1);}',
  'html.xiao-bg-on body[data-ds-dark-theme] [role="dialog"][aria-modal="true"]:has(>nav){--dsw-alias-bg-base:var(--xiao-settings-ovl-dark);--dsw-alias-bg-layer-1:var(--xiao-settings-ovl-dark-l1);--dsw-alias-bg-layer-2:var(--xiao-settings-ovl-dark);--dsw-alias-bg-layer-3:var(--xiao-settings-ovl-dark-l3);--dsw-alias-bg-overlay:var(--xiao-settings-ovl-dark-overlay);--dsw-alias-bg-document-preview:var(--xiao-settings-ovl-dark-l1);}',
  // 右栏面板（DSH 原生 data-sidebar-right-panel；better-sidebar ≥0.19 的 tab 也注册在这里）：
  // 外框透明（消掉与框架/列的重叠），内部表面改用专门的一组值着色（--xiao-panel-ovl-l1/l2/l3，见 applyBackgroundChrome），
  // 这组值**不自我引用**（不再 var() 一个同时被置空的变量 —— 那样会让内部全透、滑杆失灵，踩过）。
  'html.xiao-bg-on [data-sidebar-right-panel]{background-color:transparent!important;--xiao-sidebar-ovl:transparent;--xiao-sidebar-ovl-dark:transparent;--dsw-alias-bg-base:var(--xiao-panel-ovl-l1);--dsw-alias-bg-layer-1:var(--xiao-panel-ovl-l1);--dsw-alias-bg-layer-2:var(--xiao-panel-ovl-l2);--dsw-alias-bg-layer-3:var(--xiao-panel-ovl-l3);--dsw-alias-bg-document-preview:var(--xiao-panel-ovl-l1);--dsw-alias-bg-mask-1:transparent;}',
  'html.xiao-bg-on body[data-ds-dark-theme] [data-sidebar-right-panel]{--dsw-alias-bg-base:var(--xiao-panel-ovl-dark-l1);--dsw-alias-bg-layer-1:var(--xiao-panel-ovl-dark-l1);--dsw-alias-bg-layer-2:var(--xiao-panel-ovl-dark-l2);--dsw-alias-bg-layer-3:var(--xiao-panel-ovl-dark-l3);--dsw-alias-bg-document-preview:var(--xiao-panel-ovl-dark-l1);}',
  // ⚠️ 旧版 DSH（≤0.1.6，例如 web 0.1.5-rc.3）右栏面板是**自绘**的：.P3OORG_panel{background:var(--dsw-alias-bg-base)}，
  // 而面板内部（panelBody / 文件树 / tab 体）没有任何背景 —— 所以上面「外框透明 + 内部表面着色」在旧版上等于整块全透（实测复现）。
  // 0.1.7 起相反：外框 .LdcXKW_panel 不再画底（改由内部 dock/surface 画），且外框多了 data-sidebar-right-session 标记 —— 正好当版本判别：
  //   [data-sidebar-right-panel]:not([data-sidebar-right-session]) 只有旧版命中 → 让外框自己吃 --xiao-panel-ovl-l1（同一档色，内部 token 覆盖照旧继承）。
  // 特异性 (0,3,1) > 上面那条 (0,2,1)，稳定取胜；两版各涂一层，不叠色。
  'html.xiao-bg-on [data-sidebar-right-panel]:not([data-sidebar-right-session]){background-color:var(--xiao-panel-ovl-l1)!important;background-image:none!important;}',
  'html.xiao-bg-on body[data-ds-dark-theme] [data-sidebar-right-panel]:not([data-sidebar-right-session]){background-color:var(--xiao-panel-ovl-dark-l1)!important;}',

  // 旧版 better-sidebar（<0.19）自绘的右侧面板：保留 data 属性锚点做向后兼容。
  // ⚠️ 新版把 data-dsh-panel 挪到了「底部工作台面板」上（同一元素还带 data-dsh-bottom-panel），
  // 用 :not() 把它摘掉——它压在对话区上，涂透会透出对话文字。没装该插件时匹配不到，天然无副作用。
  'html.xiao-bg-on [data-dsh-panel]:not([data-dsh-bottom-panel]){background:var(--xiao-sidebar-ovl)!important;}',
  'html.xiao-bg-on [data-dsh-panel]:not([data-dsh-bottom-panel]) [data-dsh-pane]{background:var(--xiao-sidebar-ovl)!important;}',
  'html.xiao-bg-on body[data-ds-dark-theme] [data-dsh-panel]:not([data-dsh-bottom-panel]){background:var(--xiao-sidebar-ovl-dark)!important;}',
  'html.xiao-bg-on body[data-ds-dark-theme] [data-dsh-panel]:not([data-dsh-bottom-panel]) [data-dsh-pane]{background:var(--xiao-sidebar-ovl-dark)!important;}',
  '.xiao-mascot{position:fixed;right:18px;bottom:18px;z-index:2147483000;pointer-events:auto;font-family:system-ui,-apple-system,sans-serif;display:flex;flex-direction:column;align-items:center;gap:6px;cursor:grab;user-select:none;-webkit-user-select:none;touch-action:none;}',
  '.xiao-badge{display:flex;align-items:center;gap:10px;padding:8px 12px 8px 10px;border-radius:999px;background:linear-gradient(135deg,var(--dsw-alias-bg-overlay),var(--dsw-alias-bg-layer-1));border:2px solid #C9A96B;box-shadow:0 6px 20px rgba(20,60,50,0.30);white-space:nowrap;}',
  '.xiao-avatar{width:42px;height:42px;border-radius:50%;object-fit:cover;border:2px solid #C9A96B;flex:none;}',
  '.xiao-title{font-size:14px;font-weight:700;color:var(--dsw-alias-label-primary);letter-spacing:1px;}',
  '.xiao-sub{font-size:11px;color:var(--dsw-alias-label-secondary);letter-spacing:2px;margin-top:1px;}',
  '.xiao-close{border:none;background:transparent;cursor:pointer;color:var(--dsw-alias-label-secondary);font-size:16px;line-height:1;padding:2px 6px;border-radius:50%;margin-left:2px;}',
  '.xiao-close:hover{color:var(--dsw-alias-state-error-primary);background:var(--dsw-alias-bg-layer-1);}',
  '.xiao-tab{border:2px solid #C9A96B;background:linear-gradient(135deg,var(--dsw-alias-bg-overlay),var(--dsw-alias-bg-layer-1));cursor:grab;width:44px;height:44px;border-radius:50%;font-size:20px;line-height:1;box-shadow:0 6px 20px rgba(20,60,50,0.30);animation:xiao-float 3s ease-in-out infinite alternate;}',
  '.xiao-tab:hover{border-color:var(--dsw-alias-state-warn-primary);}',
// 徽章内的喇叭：复用 .xiao-close 的小圆按钮外观，只在有视频背景时出现（不额外占屏幕位置）。
'.xiao-sound{font-size:15px;}',
'.xiao-sound[aria-pressed="true"]{color:var(--dsw-alias-brand-primary);}',
'.xiao-sound-off{opacity:0.55;}',
// 徽章内的音量滑杆：与喇叭按钮并排，只在有视频背景时出现（静态图 / GIF 不占位）。
'.xiao-volume{width:74px;flex:none;accent-color:var(--dsw-alias-brand-primary);cursor:pointer;touch-action:auto;}',
  '.xiao-wind{font-size:14px;letter-spacing:6px;opacity:0.9;animation:xiao-float 3s ease-in-out infinite alternate;}',
  '@keyframes xiao-float{from{transform:translateY(0);}to{transform:translateY(-5px);}}',
  '.xiao-settings{display:flex;flex-direction:column;gap:6px;padding:4px 0;max-width:640px;}',
  '.xiao-settings-section{display:flex;flex-direction:column;gap:10px;padding:12px 0;border-bottom:1px solid var(--dsw-alias-border-l2);}',
  '.xiao-settings-section:last-of-type{border-bottom:none;}',
  '.xiao-settings-title{font-size:13px;font-weight:700;color:var(--dsw-alias-brand-primary);letter-spacing:1px;}',
  '.xiao-settings-row{display:flex;align-items:center;gap:12px;}',
  '.xiao-settings-row-top{align-items:flex-start;}',
  '.xiao-settings-label{font-size:14px;color:var(--dsw-alias-label-primary);min-width:110px;flex:none;}',
  '.xiao-settings-input{flex:1;min-width:0;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);border:1px solid var(--dsw-alias-border-l2);border-radius:8px;padding:8px 10px;font-size:13px;}',
  '.xiao-settings-select{background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);border:1px solid var(--dsw-alias-border-l2);border-radius:8px;padding:7px 10px;font-size:13px;}',
  '.xiao-settings-textarea{flex:1;min-width:0;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);border:1px solid var(--dsw-alias-border-l2);border-radius:8px;padding:8px 10px;font-size:13px;font-family:inherit;resize:vertical;line-height:1.5;}',
  '.xiao-settings-range{flex:1;min-width:0;accent-color:var(--dsw-alias-brand-primary);}',
  '.xiao-settings-value{font-size:12px;color:var(--dsw-alias-label-secondary);min-width:44px;text-align:right;flex:none;}',
  // 该 class 现在挂在隐藏的原生 file input 上（导入行改为插件按钮触发），故规则无视觉效果，原样保留：
  // 它原本修正了 flex:1 让原生控件整盒可点的问题；若将来重新显示原生控件，规则仍然适用。
  '.xiao-settings-file{margin-right:auto;min-width:0;font-size:13px;color:var(--dsw-alias-label-secondary);}',
  '.xiao-settings-color{width:44px;height:44px;padding:0;border:1px solid var(--dsw-alias-border-l2);border-radius:50%;background:none;cursor:pointer;flex:none;}',
  '.xiao-settings-color::-webkit-color-swatch-wrapper{padding:0;}',
  '.xiao-settings-color::-webkit-color-swatch{border:none;border-radius:50%;}',
  '.xiao-settings-btn{border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);border-radius:8px;padding:7px 14px;font-size:13px;cursor:pointer;}',
  '.xiao-settings-btn:hover{border-color:var(--dsw-alias-brand-primary);color:var(--dsw-alias-brand-primary);}',
  // —— 主题管理列表：自带滚动容器，块高与主题数量解耦 ——
  '.xiao-theme-list-head{display:flex;align-items:center;justify-content:space-between;gap:8px;}',
  '.xiao-theme-list-title{font-size:12px;color:var(--dsw-alias-label-secondary);}',
  // 固定上限 min(40vh,280px)：宿主设置面板本身是 min(800px,100vh-48px)，用 px 上限 + vh 兜底，跨 DSH 版本都稳。
  '.xiao-theme-list{display:flex;flex-direction:column;gap:4px;max-height:min(40vh,280px);overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain;scrollbar-width:thin;border:1px solid var(--dsw-alias-border-l2);border-radius:10px;padding:6px;background:var(--dsw-alias-bg-layer-1);}',
  '.xiao-theme-row{display:flex;align-items:center;gap:8px;padding:5px 8px;border-radius:8px;}',
  '.xiao-theme-row:hover{background:var(--dsw-alias-bg-layer-2);}',
  '.xiao-theme-row-active{background:var(--dsw-alias-bg-layer-2);box-shadow:inset 2px 0 0 var(--dsw-alias-brand-primary);}',
  '.xiao-theme-namewrap{display:flex;align-items:center;gap:6px;flex:1;min-width:0;}',
  '.xiao-theme-name{min-width:0;font-size:13px;color:var(--dsw-alias-label-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
  '.xiao-theme-tag{flex:none;font-size:11px;color:var(--dsw-alias-label-secondary);border:1px solid var(--dsw-alias-border-l2);border-radius:999px;padding:1px 8px;}',
  '.xiao-theme-tag-active{color:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-brand-primary);}',
  '.xiao-theme-act{padding:3px 10px;font-size:12px;line-height:1.3;flex:none;}',
  '.xiao-theme-act-primary{color:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-brand-primary);}',
  '.xiao-theme-rename{flex:1;min-width:0;}',
  '.xiao-settings-danger{border-color:var(--dsw-alias-state-error-primary)!important;color:var(--dsw-alias-state-error-primary)!important;}',
  '.xiao-settings-warn{font-size:12px;color:var(--dsw-alias-state-warn-primary);line-height:1.6;padding:2px 0;}',
  '.xiao-settings-hint{font-size:12px;color:var(--dsw-alias-label-secondary);line-height:1.6;}',
  // —— 多背景列表编辑器 ——
  '.xiao-bg-editor{display:flex;flex-direction:column;gap:8px;}',
  '.xiao-bg-rows{display:flex;flex-direction:column;gap:6px;}',
  '.xiao-bg-row{display:flex;align-items:center;gap:8px;padding:6px 8px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;}',
  '.xiao-bg-thumb{width:40px;height:40px;object-fit:cover;border-radius:6px;flex:none;background:var(--dsw-alias-bg-overlay);}',
  '.xiao-bg-index{font-size:12px;color:var(--dsw-alias-label-secondary);min-width:16px;text-align:right;flex:none;}',
  '.xiao-bg-name{flex:1;min-width:0;font-size:13px;color:var(--dsw-alias-label-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
  '.xiao-bg-tag{font-size:11px;color:var(--dsw-alias-label-secondary);border:1px solid var(--dsw-alias-border-l2);border-radius:999px;padding:1px 8px;flex:none;}',
  '.xiao-bg-mini{padding:4px 10px;font-size:12px;line-height:1.2;}',
  '.xiao-upload-modal{position:fixed;inset:0;z-index:2147483600;background:rgba(10,24,20,0.55);display:flex;align-items:center;justify-content:center;padding:24px;font-family:system-ui,-apple-system,sans-serif;}',
  '.xiao-upload-panel{width:min(560px,92vw);max-height:78vh;display:flex;flex-direction:column;gap:12px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);border:1px solid var(--dsw-alias-border-l2);border-radius:12px;padding:16px;box-shadow:0 16px 50px rgba(0,0,0,0.4);overflow:hidden;}',
  '.xiao-upload-head{font-size:15px;font-weight:700;color:var(--dsw-alias-brand-primary);letter-spacing:1px;}',
  '.xiao-upload-list{display:flex;flex-direction:column;gap:8px;flex:1 1 auto;min-height:0;overflow-y:auto;}',
  '.xiao-upload-item{display:flex;align-items:center;gap:12px;padding:8px 10px;border:1px solid var(--dsw-alias-border-l2);border-radius:10px;cursor:pointer;}',
  '.xiao-upload-item:hover{border-color:var(--dsw-alias-brand-primary);}',
  '.xiao-upload-item-sel{border-color:var(--dsw-alias-brand-primary);background:var(--dsw-alias-bg-layer-2);}',
  '.xiao-upload-thumb{width:56px;height:56px;object-fit:cover;border-radius:8px;flex:none;background:var(--dsw-alias-bg-overlay);}',
  '.xiao-upload-info{display:flex;flex-direction:column;gap:3px;min-width:0;flex:1;}',
  '.xiao-upload-name{font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
  '.xiao-upload-meta{font-size:12px;color:var(--dsw-alias-label-secondary);}',
  '.xiao-upload-ref{font-size:11px;color:var(--dsw-alias-label-secondary);display:flex;flex-wrap:wrap;gap:6px;align-items:center;}',
  '.xiao-upload-cur{font-size:11px;color:var(--dsw-alias-state-success-primary);}',
  '.xiao-upload-empty{font-size:13px;color:var(--dsw-alias-label-secondary);text-align:center;padding:24px 8px;line-height:1.6;}',
  '.xiao-upload-foot{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end;border-top:1px solid var(--dsw-alias-border-l2);padding-top:12px;}',
];

const XIAO_CSS_STRING = XIAO_CSS.join('');

/** 注入包级样式（随插件卸载移除）。 */
function insertStyles(ctx: ClientCtx): void {
  const tag = document.createElement('style');
  tag.dataset.plugin = 'xiao-theme-ts';
  tag.dataset.pluginCss = 'xiao-theme-ts/styles.css';
  tag.textContent = XIAO_CSS_STRING;
  document.head.appendChild(tag);
  ctx.effect(
    () => () => {
      tag.remove();
    },
    'xiao-theme: styles',
  );
}

const inject = ['slots', 'theme'] as const;

function apply(ctx: ClientCtx): void {
  const store = createConfigStore();

  // 主题覆盖：单层动态合并（青玉配色 + 背景开启时的半透明面板色）
  const theme = ctx.get('theme');
  let themeDispose: (() => void) | null = null;
  const syncTheme = (): void => {
    const cfg = store.getSnapshot();
    const enabled = cfg.enabled !== false;
    if (!enabled) {
      if (themeDispose !== null) {
        themeDispose();
        themeDispose = null;
      }
      return;
    }
    if (theme === undefined) return;
    themeDispose = theme.overrideTokens('xiao-theme-static', buildTokens(cfg));
  };
  ctx.effect(() => store.subscribe(syncTheme), 'xiao-theme: theme sync');
  ctx.effect(
    () => () => {
      if (themeDispose !== null) themeDispose();
    },
    'xiao-theme: theme cleanup',
  );

  // 磨砂背景层
  const syncBg = (): void => syncBackground(store.getSnapshot());
  ctx.effect(() => store.subscribe(syncBg), 'xiao-theme: background sync');
  ctx.effect(
    () => () => {
      const de = document.documentElement;
      de.classList.remove('xiao-bg-on');
      de.classList.remove('xiao-bg-dynamic');
      de.classList.remove('xiao-bg-video');
      removeBgVideo();
      // 多背景轮播：卸载时同样要停定时器、移除图层，避免残留与后台空转。
      stopRotation();
      de.classList.remove('xiao-bg-layers');
      de.style.removeProperty('--xiao-bg-img');
      de.style.removeProperty('--xiao-bg-blur');
      de.style.removeProperty('--xiao-bg-ovl');
      de.style.removeProperty('--xiao-bg-ovl-dark');
      de.style.removeProperty('--xiao-sidebar-ovl');
      de.style.removeProperty('--xiao-sidebar-ovl-dark');
      de.style.removeProperty('--xiao-settings-ovl');
      de.style.removeProperty('--xiao-settings-ovl-l1');
      de.style.removeProperty('--xiao-settings-ovl-l3');
      de.style.removeProperty('--xiao-settings-ovl-overlay');
      de.style.removeProperty('--xiao-settings-ovl-dark');
      de.style.removeProperty('--xiao-settings-ovl-dark-l1');
      de.style.removeProperty('--xiao-settings-ovl-dark-l3');
      de.style.removeProperty('--xiao-settings-ovl-dark-overlay');
      de.style.removeProperty('--xiao-theme-color');
      de.style.removeProperty('--xiao-grad-a');
      de.style.removeProperty('--xiao-grad-b');
      const frame = findFrameElement();
      if (frame) {
        frame.style.backgroundColor = '';
        frame.style.backgroundImage = '';
        frame.style.backdropFilter = '';
        (frame.style as StyleWithWebkit).webkitBackdropFilter = '';
      }
    },
    'xiao-theme: background cleanup',
  );

  // DSH 主题偏好 / 系统明暗切换时重同步背景：syncBackground 的 JS 内联兜底底色取决于当前明暗模式
  // （body[data-ds-dark-theme]），仅靠配置变更不会重跑；这里补一个 theme/change 订阅（纯补偿，
  // 不改变配置与用户操作语义）。青玉 token 本身是明暗双值、由 theme 服务自动重组，无需重设。
  ctx.effect(() => {
    const off = ctx.on?.('theme/change', () => {
      syncBg();
    });
    return () => {
      if (typeof off === 'function') off();
    };
  }, 'xiao-theme: theme change background sync');

  // 初次读配置，读完后同步主题 + 背景 + 驱动 UI
  void loadConfig(store).then(() => {
    syncTheme();
    syncBg();
  });
  syncTheme();
  syncBg();

  insertStyles(ctx);

  const slots = ctx.get('slots');
  if (slots === undefined) return;
  slots.inject('shell.overlay', () =>
    slots.register({ name: 'shell.overlay', id: 'xiao-mascot' }, () =>
      React.createElement(XiaoOverlay, { store }),
    ),
  );
  // settings.section 标题需跟随 DSH 界面语言与当前主题名：用 slots.inject 声明该 slot（必须，否则 DSH 会报“slot 未声明”崩溃），
  // 并在语言变化（<html lang> 更新）或活动主题名变化时 dispose 旧 inject + 重 inject 以更新 label。
  const localeSvc = ctx.get('locale');
  let settingsInject: (() => void) | null = null;
  const sectionLabel = (): string => {
    const active = localeSvc ? localeSvc.getLocale().active : '';
    const lang: 'zh' | 'en' | '' = active === 'zh' ? 'zh' : active === 'en' ? 'en' : '';
    return composeThemeTitle(activeThemeName, lang);
  };
  const registerSettings = (): void => {
    try {
      if (settingsInject !== null) {
        settingsInject();
        settingsInject = null;
      }
      const d = slots.inject('settings.section', () =>
        slots.register({ name: 'settings.section', id: 'xiao-theme-ts', order: 100, label: sectionLabel() }, () =>
          React.createElement(XiaoSettingsPage, { store }),
        ),
      );
      settingsInject = typeof d === 'function' ? d : null;
    } catch (error) {
      console.error('[xiao-theme] settings.section register failed:', error);
    }
  };
  // 语言变化（DSH 更新 <html lang>）时重注册；覆盖初始时序（lang 尚未设置）与后续切换。
  const langObserver = new MutationObserver(() => registerSettings());
  langObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
  // 分区标题还要跟随「当前主题名」：主题切换 / 重命名后重注册，标题即变成「<主题名>主题 / <name> Theme」。
  const onActiveThemeNameChange = (): void => registerSettings();
  activeThemeNameListeners.add(onActiveThemeNameChange);
  registerSettings();
  // 先按内置静态标题渲染（避免空白），随后取到活动主题名再刷新一次。
  void refreshActiveThemeName();
  ctx.effect(
    () => () => {
      langObserver.disconnect();
      activeThemeNameListeners.delete(onActiveThemeNameChange);
      if (settingsInject !== null) settingsInject();
    },
    'xiao-theme: settings section title sync',
  );
}

// 纯色板工具额外具名导出：仅供测试直接调用，不影响 ModuleLoader 契约（只读 inject/apply/default）。
export {
  inject,
  apply,
  videoPlaythroughPlan,
  parseHex,
  rgbToHsl,
  hslToRgb,
  shiftLight,
  shiftSat,
  deriveSurfaces,
  buildPalette,
  mascotText,
  composeThemeTitle,
  composeEnableThemeLabel,
};
export default { inject, apply } satisfies ClientPlugin;
