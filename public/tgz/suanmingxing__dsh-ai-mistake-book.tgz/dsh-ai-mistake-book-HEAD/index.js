/**
 * AI 错题本 — host half.
 *
 * `/mistake` (or the `mistake_ingest` tool) turns an attached scan into a batch
 * under <archiveRoot>/inbox/<batchId>, then turns the calling session into the
 * analysis run: its tools are narrowed to the document type's own set, and a task
 * brief is queued (command) or handed back in the tool result (`mistake_ingest`).
 *
 * Composition lives in small registries so adding a second document type (notes)
 * does not touch this file: commands/ registers commands, tools/ registers tools,
 * doc-types.js owns type metadata, ingest.js is the shared pipeline.
 */
import { Config, liveConfig } from './lib/config.js'
import { registerCommands } from './lib/commands/index.js'
import { archivePaths, messageOf } from './lib/paths.js'
import { registerRoutes } from './lib/server.js'
import { reconcileBatch } from './lib/store.js'
import { registerTools } from './lib/tools/index.js'

export const name = 'ai-mistake-book'

/** Hard dependencies: without any of these the plugin must not pretend to work. */
export const inject = [
  'commands',
  'tools',
  'attachments',
  'workspaceRegistry',
  'sessionController',
  'agents',
  'llm',
  'agentDefaultModel',
  'webServer',
]

export { Config }

export function apply(ctx, config) {
  const state = { analysisSessions: new Map(), toolRestrictions: new Map() }
  const readConfig = () => liveConfig(ctx, config)
  const trackSession = (sessionId, batchId) => state.analysisSessions.set(sessionId, batchId)
  const trackRestriction = (sessionId, dispose) => state.toolRestrictions.set(sessionId, dispose)

  /** Give a session its tools back once its analysis has settled. */
  const liftRestriction = (sessionId) => {
    const dispose = state.toolRestrictions.get(sessionId)
    if (dispose === undefined) return
    state.toolRestrictions.delete(sessionId)
    try {
      dispose()
    } catch {
      /* already gone with the agent */
    }
  }

  ctx.effect(() => registerTools(ctx, readConfig, state), 'ai-mistake-book: agent tools')
  ctx.effect(() => registerRoutes(ctx, readConfig), 'ai-mistake-book: client routes')
  ctx.effect(() => registerCommands(ctx, readConfig, state, { trackSession, trackRestriction }), 'ai-mistake-book: commands')

  /**
   * Settle a batch when its session finishes a turn, and hand the session its
   * normal tools back. Without the settle, a session that ends without extracting
   * anything leaves the batch stuck on "analyzing" and the review page keeps
   * showing a run that is long over.
   */
  ctx.effect(() => ctx.on('session/event', (session, event) => {
    if (event?.type !== 'turn/end') return
    const batchId = state.analysisSessions.get(session?.id)
    if (batchId === undefined) return
    reconcileBatch(archivePaths(readConfig().archiveRoot), batchId)
      .then((status) => {
        // Settled states hand the session its normal tools back. `staged` is not
        // settled on purpose: the model still needs the type's decision tool to
        // finish, and every tool it needs is inside the allowlist.
        if (status === 'awaiting-confirmation' || status === 'analysis-ended' || status === 'archived' || status === 'cancelled') liftRestriction(session.id)
      })
      .catch((error) => {
        // The batch directory can be gone (mistake_discard from another session).
        // Lifting here matters anyway: without it the session would keep the
        // restricted tool surface forever, with no batch left to settle.
        liftRestriction(session.id)
        ctx.logger?.warn?.(`ai-mistake-book: 批次状态收口失败 ${batchId}: ${messageOf(error)}`)
      })
  }), 'ai-mistake-book: batch lifecycle')
}
